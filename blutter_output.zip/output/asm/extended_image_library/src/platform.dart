// lib: , url: package:extended_image_library/src/platform.dart

// class id: 1048957, size: 0x8
class :: {

  static _ keyToMd5(/* No info */) {
    // ** addr: 0xc34498, size: 0x5c
    // 0xc34498: EnterFrame
    //     0xc34498: stp             fp, lr, [SP, #-0x10]!
    //     0xc3449c: mov             fp, SP
    // 0xc344a0: CheckStackOverflow
    //     0xc344a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc344a4: cmp             SP, x16
    //     0xc344a8: b.ls            #0xc344ec
    // 0xc344ac: r16 = Instance_Utf8Codec
    //     0xc344ac: ldr             x16, [PP, #0xa30]  ; [pp+0xa30] Obj!Utf8Codec<String, List<int>>@b5f6a1
    // 0xc344b0: ldr             lr, [fp, #0x10]
    // 0xc344b4: stp             lr, x16, [SP, #-0x10]!
    // 0xc344b8: r0 = encode()
    //     0xc344b8: bl              #0xbfcc28  ; [dart:convert] Codec::encode
    // 0xc344bc: add             SP, SP, #0x10
    // 0xc344c0: r16 = Instance__MD5
    //     0xc344c0: add             x16, PP, #0xe, lsl #12  ; [pp+0xefb0] Obj!_MD5<List<int>, Digest>@b5f721
    //     0xc344c4: ldr             x16, [x16, #0xfb0]
    // 0xc344c8: stp             x0, x16, [SP, #-0x10]!
    // 0xc344cc: r0 = convert()
    //     0xc344cc: bl              #0xc20d20  ; [package:crypto/src/hash.dart] Hash::convert
    // 0xc344d0: add             SP, SP, #0x10
    // 0xc344d4: SaveReg r0
    //     0xc344d4: str             x0, [SP, #-8]!
    // 0xc344d8: r0 = toString()
    //     0xc344d8: bl              #0xac4b10  ; [package:crypto/src/digest.dart] Digest::toString
    // 0xc344dc: add             SP, SP, #8
    // 0xc344e0: LeaveFrame
    //     0xc344e0: mov             SP, fp
    //     0xc344e4: ldp             fp, lr, [SP], #0x10
    // 0xc344e8: ret
    //     0xc344e8: ret             
    // 0xc344ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc344ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc344f0: b               #0xc344ac
  }
}

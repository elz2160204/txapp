// lib: , url: package:extended_image_library/src/extended_image_provider.dart

// class id: 1048953, size: 0x8
class :: {

  static late Map<ExtendedImageProvider<dynamic>, Uint8List> rawImageDataMap; // offset: 0xbd4

  static Map<ExtendedImageProvider<dynamic>, Uint8List> rawImageDataMap() {
    // ** addr: 0xc3e28c, size: 0x40
    // 0xc3e28c: EnterFrame
    //     0xc3e28c: stp             fp, lr, [SP, #-0x10]!
    //     0xc3e290: mov             fp, SP
    // 0xc3e294: CheckStackOverflow
    //     0xc3e294: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3e298: cmp             SP, x16
    //     0xc3e29c: b.ls            #0xc3e2c4
    // 0xc3e2a0: r16 = <ExtendedImageProvider<Object>, Uint8List>
    //     0xc3e2a0: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ed80] TypeArguments: <ExtendedImageProvider<Object>, Uint8List>
    //     0xc3e2a4: ldr             x16, [x16, #0xd80]
    // 0xc3e2a8: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xc3e2ac: stp             lr, x16, [SP, #-0x10]!
    // 0xc3e2b0: r0 = Map._fromLiteral()
    //     0xc3e2b0: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc3e2b4: add             SP, SP, #0x10
    // 0xc3e2b8: LeaveFrame
    //     0xc3e2b8: mov             SP, fp
    //     0xc3e2bc: ldp             fp, lr, [SP], #0x10
    // 0xc3e2c0: ret
    //     0xc3e2c0: ret             
    // 0xc3e2c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3e2c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3e2c8: b               #0xc3e2a0
  }
}

// class id: 4469, size: 0xc, field offset: 0xc
abstract class ExtendedImageProvider<X0> extends ImageProvider<X0> {
}

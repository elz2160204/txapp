// lib: , url: package:auto_orientation/auto_orientation.dart

// class id: 1048683, size: 0x8
class :: {
}

// class id: 4979, size: 0x8, field offset: 0x8
abstract class AutoOrientation extends Object {

  static dynamic landscapeAutoMode() async {
    // ** addr: 0x9e28f0, size: 0xc8
    // 0x9e28f0: EnterFrame
    //     0x9e28f0: stp             fp, lr, [SP, #-0x10]!
    //     0x9e28f4: mov             fp, SP
    // 0x9e28f8: AllocStack(0x38)
    //     0x9e28f8: sub             SP, SP, #0x38
    // 0x9e28fc: SetupParameters()
    //     0x9e28fc: stur            NULL, [fp, #-8]
    // 0x9e2900: CheckStackOverflow
    //     0x9e2900: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9e2904: cmp             SP, x16
    //     0x9e2908: b.ls            #0x9e29b0
    // 0x9e290c: InitAsync() -> Future
    //     0x9e290c: mov             x0, NULL
    //     0x9e2910: bl              #0x4b92e4
    // 0x9e2914: r1 = Null
    //     0x9e2914: mov             x1, NULL
    // 0x9e2918: r2 = 4
    //     0x9e2918: mov             x2, #4
    // 0x9e291c: r0 = AllocateArray()
    //     0x9e291c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x9e2920: r17 = "forceSensor"
    //     0x9e2920: add             x17, PP, #0x52, lsl #12  ; [pp+0x52510] "forceSensor"
    //     0x9e2924: ldr             x17, [x17, #0x510]
    // 0x9e2928: StoreField: r0->field_f = r17
    //     0x9e2928: stur            w17, [x0, #0xf]
    // 0x9e292c: r17 = false
    //     0x9e292c: add             x17, NULL, #0x30  ; false
    // 0x9e2930: StoreField: r0->field_13 = r17
    //     0x9e2930: stur            w17, [x0, #0x13]
    // 0x9e2934: r16 = <String, bool>
    //     0x9e2934: add             x16, PP, #0xf, lsl #12  ; [pp+0xf340] TypeArguments: <String, bool>
    //     0x9e2938: ldr             x16, [x16, #0x340]
    // 0x9e293c: stp             x0, x16, [SP, #-0x10]!
    // 0x9e2940: r0 = Map._fromLiteral()
    //     0x9e2940: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x9e2944: add             SP, SP, #0x10
    // 0x9e2948: r16 = Instance_MethodChannel
    //     0x9e2948: add             x16, PP, #0x52, lsl #12  ; [pp+0x52500] Obj!MethodChannel@b34db1
    //     0x9e294c: ldr             x16, [x16, #0x500]
    // 0x9e2950: stp             x16, NULL, [SP, #-0x10]!
    // 0x9e2954: r16 = "setLandscapeAuto"
    //     0x9e2954: add             x16, PP, #0x52, lsl #12  ; [pp+0x52518] "setLandscapeAuto"
    //     0x9e2958: ldr             x16, [x16, #0x518]
    // 0x9e295c: stp             x0, x16, [SP, #-0x10]!
    // 0x9e2960: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x9e2960: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x9e2964: r0 = invokeMethod()
    //     0x9e2964: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0x9e2968: add             SP, SP, #0x20
    // 0x9e296c: mov             x1, x0
    // 0x9e2970: stur            x1, [fp, #-0x38]
    // 0x9e2974: r0 = Await()
    //     0x9e2974: bl              #0x4b8e6c  ; AwaitStub
    // 0x9e2978: r0 = Null
    //     0x9e2978: mov             x0, NULL
    // 0x9e297c: r0 = ReturnAsyncNotFuture()
    //     0x9e297c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x9e2980: sub             SP, fp, #0x38
    // 0x9e2984: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x9e2984: mov             x2, #0x76
    //     0x9e2988: tbz             w0, #0, #0x9e2998
    //     0x9e298c: ldur            x2, [x0, #-1]
    //     0x9e2990: ubfx            x2, x2, #0xc, #0x14
    //     0x9e2994: lsl             x2, x2, #1
    // 0x9e2998: cmp             w2, #0xf26
    // 0x9e299c: b.ne            #0x9e29a8
    // 0x9e29a0: r0 = Null
    //     0x9e29a0: mov             x0, NULL
    // 0x9e29a4: r0 = ReturnAsyncNotFuture()
    //     0x9e29a4: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x9e29a8: r0 = ReThrow()
    //     0x9e29a8: bl              #0xd67e14  ; ReThrowStub
    // 0x9e29ac: brk             #0
    // 0x9e29b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e29b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e29b4: b               #0x9e290c
  }
  static dynamic portraitUpMode() async {
    // ** addr: 0xa56ba8, size: 0x94
    // 0xa56ba8: EnterFrame
    //     0xa56ba8: stp             fp, lr, [SP, #-0x10]!
    //     0xa56bac: mov             fp, SP
    // 0xa56bb0: AllocStack(0x38)
    //     0xa56bb0: sub             SP, SP, #0x38
    // 0xa56bb4: SetupParameters()
    //     0xa56bb4: stur            NULL, [fp, #-8]
    // 0xa56bb8: CheckStackOverflow
    //     0xa56bb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa56bbc: cmp             SP, x16
    //     0xa56bc0: b.ls            #0xa56c34
    // 0xa56bc4: InitAsync() -> Future
    //     0xa56bc4: mov             x0, NULL
    //     0xa56bc8: bl              #0x4b92e4
    // 0xa56bcc: r16 = Instance_MethodChannel
    //     0xa56bcc: add             x16, PP, #0x52, lsl #12  ; [pp+0x52500] Obj!MethodChannel@b34db1
    //     0xa56bd0: ldr             x16, [x16, #0x500]
    // 0xa56bd4: stp             x16, NULL, [SP, #-0x10]!
    // 0xa56bd8: r16 = "setPortraitUp"
    //     0xa56bd8: add             x16, PP, #0x52, lsl #12  ; [pp+0x52508] "setPortraitUp"
    //     0xa56bdc: ldr             x16, [x16, #0x508]
    // 0xa56be0: SaveReg r16
    //     0xa56be0: str             x16, [SP, #-8]!
    // 0xa56be4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa56be4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa56be8: r0 = invokeMethod()
    //     0xa56be8: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xa56bec: add             SP, SP, #0x18
    // 0xa56bf0: mov             x1, x0
    // 0xa56bf4: stur            x1, [fp, #-0x38]
    // 0xa56bf8: r0 = Await()
    //     0xa56bf8: bl              #0x4b8e6c  ; AwaitStub
    // 0xa56bfc: r0 = Null
    //     0xa56bfc: mov             x0, NULL
    // 0xa56c00: r0 = ReturnAsyncNotFuture()
    //     0xa56c00: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xa56c04: sub             SP, fp, #0x38
    // 0xa56c08: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xa56c08: mov             x2, #0x76
    //     0xa56c0c: tbz             w0, #0, #0xa56c1c
    //     0xa56c10: ldur            x2, [x0, #-1]
    //     0xa56c14: ubfx            x2, x2, #0xc, #0x14
    //     0xa56c18: lsl             x2, x2, #1
    // 0xa56c1c: cmp             w2, #0xf26
    // 0xa56c20: b.ne            #0xa56c2c
    // 0xa56c24: r0 = Null
    //     0xa56c24: mov             x0, NULL
    // 0xa56c28: r0 = ReturnAsyncNotFuture()
    //     0xa56c28: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xa56c2c: r0 = ReThrow()
    //     0xa56c2c: bl              #0xd67e14  ; ReThrowStub
    // 0xa56c30: brk             #0
    // 0xa56c34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa56c34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa56c38: b               #0xa56bc4
  }
}

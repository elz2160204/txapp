// lib: , url: package:flustars_flutter3/src/screen_util.dart

// class id: 1049053, size: 0x8
class :: {
}

// class id: 4392, size: 0x2c, field offset: 0x8
class ScreenUtil extends Object {

  static late final ScreenUtil _singleton; // offset: 0xca4

  static ScreenUtil getInstance() {
    // ** addr: 0x89dc90, size: 0x60
    // 0x89dc90: EnterFrame
    //     0x89dc90: stp             fp, lr, [SP, #-0x10]!
    //     0x89dc94: mov             fp, SP
    // 0x89dc98: AllocStack(0x8)
    //     0x89dc98: sub             SP, SP, #8
    // 0x89dc9c: CheckStackOverflow
    //     0x89dc9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x89dca0: cmp             SP, x16
    //     0x89dca4: b.ls            #0x89dce8
    // 0x89dca8: r0 = InitLateStaticField(0xca4) // [package:flustars_flutter3/src/screen_util.dart] ScreenUtil::_singleton
    //     0x89dca8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x89dcac: ldr             x0, [x0, #0x1948]
    //     0x89dcb0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x89dcb4: cmp             w0, w16
    //     0x89dcb8: b.ne            #0x89dcc8
    //     0x89dcbc: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1c4e8] Field <ScreenUtil._singleton@570441392>: static late final (offset: 0xca4)
    //     0x89dcc0: ldr             x2, [x2, #0x4e8]
    //     0x89dcc4: bl              #0xd67cdc
    // 0x89dcc8: stur            x0, [fp, #-8]
    // 0x89dccc: SaveReg r0
    //     0x89dccc: str             x0, [SP, #-8]!
    // 0x89dcd0: r0 = _init()
    //     0x89dcd0: bl              #0x89dcf0  ; [package:flustars_flutter3/src/screen_util.dart] ScreenUtil::_init
    // 0x89dcd4: add             SP, SP, #8
    // 0x89dcd8: ldur            x0, [fp, #-8]
    // 0x89dcdc: LeaveFrame
    //     0x89dcdc: mov             SP, fp
    //     0x89dce0: ldp             fp, lr, [SP], #0x10
    // 0x89dce4: ret
    //     0x89dce4: ret             
    // 0x89dce8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89dce8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89dcec: b               #0x89dca8
  }
  _ _init(/* No info */) {
    // ** addr: 0x89dcf0, size: 0xf4
    // 0x89dcf0: EnterFrame
    //     0x89dcf0: stp             fp, lr, [SP, #-0x10]!
    //     0x89dcf4: mov             fp, SP
    // 0x89dcf8: AllocStack(0x10)
    //     0x89dcf8: sub             SP, SP, #0x10
    // 0x89dcfc: CheckStackOverflow
    //     0x89dcfc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x89dd00: cmp             SP, x16
    //     0x89dd04: b.ls            #0x89dddc
    // 0x89dd08: r0 = InitLateStaticField(0xa20) // [dart:ui] ::window
    //     0x89dd08: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x89dd0c: ldr             x0, [x0, #0x1440]
    //     0x89dd10: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x89dd14: cmp             w0, w16
    //     0x89dd18: b.ne            #0x89dd24
    //     0x89dd1c: ldr             x2, [PP, #0x4cb8]  ; [pp+0x4cb8] Field <::.window>: static late final (offset: 0xa20)
    //     0x89dd20: bl              #0xd67cdc
    // 0x89dd24: stur            x0, [fp, #-8]
    // 0x89dd28: r0 = MediaQueryData()
    //     0x89dd28: bl              #0x848418  ; AllocateMediaQueryDataStub -> MediaQueryData (size=0x54)
    // 0x89dd2c: stur            x0, [fp, #-0x10]
    // 0x89dd30: ldur            x16, [fp, #-8]
    // 0x89dd34: stp             x16, x0, [SP, #-0x10]!
    // 0x89dd38: r0 = MediaQueryData.fromWindow()
    //     0x89dd38: bl              #0x87f52c  ; [package:flutter/src/widgets/media_query.dart] MediaQueryData::MediaQueryData.fromWindow
    // 0x89dd3c: add             SP, SP, #0x10
    // 0x89dd40: ldr             x1, [fp, #0x10]
    // 0x89dd44: LoadField: r0 = r1->field_27
    //     0x89dd44: ldur            w0, [x1, #0x27]
    // 0x89dd48: DecompressPointer r0
    //     0x89dd48: add             x0, x0, HEAP, lsl #32
    // 0x89dd4c: r2 = LoadClassIdInstr(r0)
    //     0x89dd4c: ldur            x2, [x0, #-1]
    //     0x89dd50: ubfx            x2, x2, #0xc, #0x14
    // 0x89dd54: ldur            x16, [fp, #-0x10]
    // 0x89dd58: stp             x16, x0, [SP, #-0x10]!
    // 0x89dd5c: mov             x0, x2
    // 0x89dd60: mov             lr, x0
    // 0x89dd64: ldr             lr, [x21, lr, lsl #3]
    // 0x89dd68: blr             lr
    // 0x89dd6c: add             SP, SP, #0x10
    // 0x89dd70: tbz             w0, #4, #0x89ddcc
    // 0x89dd74: ldr             x1, [fp, #0x10]
    // 0x89dd78: ldur            x2, [fp, #-0x10]
    // 0x89dd7c: mov             x0, x2
    // 0x89dd80: StoreField: r1->field_27 = r0
    //     0x89dd80: stur            w0, [x1, #0x27]
    //     0x89dd84: ldurb           w16, [x1, #-1]
    //     0x89dd88: ldurb           w17, [x0, #-1]
    //     0x89dd8c: and             x16, x17, x16, lsr #2
    //     0x89dd90: tst             x16, HEAP, lsr #32
    //     0x89dd94: b.eq            #0x89dd9c
    //     0x89dd98: bl              #0xd6826c
    // 0x89dd9c: LoadField: r3 = r2->field_7
    //     0x89dd9c: ldur            w3, [x2, #7]
    // 0x89dda0: DecompressPointer r3
    //     0x89dda0: add             x3, x3, HEAP, lsl #32
    // 0x89dda4: LoadField: d0 = r3->field_7
    //     0x89dda4: ldur            d0, [x3, #7]
    // 0x89dda8: StoreField: r1->field_7 = d0
    //     0x89dda8: stur            d0, [x1, #7]
    // 0x89ddac: LoadField: d0 = r3->field_f
    //     0x89ddac: ldur            d0, [x3, #0xf]
    // 0x89ddb0: StoreField: r1->field_f = d0
    //     0x89ddb0: stur            d0, [x1, #0xf]
    // 0x89ddb4: LoadField: d0 = r2->field_b
    //     0x89ddb4: ldur            d0, [x2, #0xb]
    // 0x89ddb8: StoreField: r1->field_17 = d0
    //     0x89ddb8: stur            d0, [x1, #0x17]
    // 0x89ddbc: LoadField: r3 = r2->field_23
    //     0x89ddbc: ldur            w3, [x2, #0x23]
    // 0x89ddc0: DecompressPointer r3
    //     0x89ddc0: add             x3, x3, HEAP, lsl #32
    // 0x89ddc4: LoadField: d0 = r3->field_f
    //     0x89ddc4: ldur            d0, [x3, #0xf]
    // 0x89ddc8: StoreField: r1->field_1f = d0
    //     0x89ddc8: stur            d0, [x1, #0x1f]
    // 0x89ddcc: r0 = Null
    //     0x89ddcc: mov             x0, NULL
    // 0x89ddd0: LeaveFrame
    //     0x89ddd0: mov             SP, fp
    //     0x89ddd4: ldp             fp, lr, [SP], #0x10
    // 0x89ddd8: ret
    //     0x89ddd8: ret             
    // 0x89dddc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89dddc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89dde0: b               #0x89dd08
  }
  static ScreenUtil _singleton() {
    // ** addr: 0x89dde4, size: 0x2c
    // 0x89dde4: EnterFrame
    //     0x89dde4: stp             fp, lr, [SP, #-0x10]!
    //     0x89dde8: mov             fp, SP
    // 0x89ddec: r0 = ScreenUtil()
    //     0x89ddec: bl              #0x89de10  ; AllocateScreenUtilStub -> ScreenUtil (size=0x2c)
    // 0x89ddf0: d0 = 0.000000
    //     0x89ddf0: eor             v0.16b, v0.16b, v0.16b
    // 0x89ddf4: StoreField: r0->field_7 = d0
    //     0x89ddf4: stur            d0, [x0, #7]
    // 0x89ddf8: StoreField: r0->field_f = d0
    //     0x89ddf8: stur            d0, [x0, #0xf]
    // 0x89ddfc: StoreField: r0->field_17 = d0
    //     0x89ddfc: stur            d0, [x0, #0x17]
    // 0x89de00: StoreField: r0->field_1f = d0
    //     0x89de00: stur            d0, [x0, #0x1f]
    // 0x89de04: LeaveFrame
    //     0x89de04: mov             SP, fp
    //     0x89de08: ldp             fp, lr, [SP], #0x10
    // 0x89de0c: ret
    //     0x89de0c: ret             
  }
}

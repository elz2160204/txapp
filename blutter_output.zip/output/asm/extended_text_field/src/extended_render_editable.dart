// lib: , url: package:extended_text_field/src/extended_render_editable.dart

// class id: 1048970, size: 0x8
class :: {
}

// class id: 2530, size: 0x64, field offset: 0x60
class _RenderEditableCustomPaint extends RenderBox {

  _ paint(/* No info */) {
    // ** addr: 0x65ed2c, size: 0xb0
    // 0x65ed2c: EnterFrame
    //     0x65ed2c: stp             fp, lr, [SP, #-0x10]!
    //     0x65ed30: mov             fp, SP
    // 0x65ed34: AllocStack(0x10)
    //     0x65ed34: sub             SP, SP, #0x10
    // 0x65ed38: CheckStackOverflow
    //     0x65ed38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65ed3c: cmp             SP, x16
    //     0x65ed40: b.ls            #0x65edd0
    // 0x65ed44: ldr             x16, [fp, #0x20]
    // 0x65ed48: SaveReg r16
    //     0x65ed48: str             x16, [SP, #-8]!
    // 0x65ed4c: r0 = parent()
    //     0x65ed4c: bl              #0xa6b188  ; [package:extended_text_field/src/extended_render_editable.dart] _RenderEditableCustomPaint::parent
    // 0x65ed50: add             SP, SP, #8
    // 0x65ed54: mov             x1, x0
    // 0x65ed58: ldr             x0, [fp, #0x20]
    // 0x65ed5c: stur            x1, [fp, #-0x10]
    // 0x65ed60: LoadField: r2 = r0->field_5f
    //     0x65ed60: ldur            w2, [x0, #0x5f]
    // 0x65ed64: DecompressPointer r2
    //     0x65ed64: add             x2, x2, HEAP, lsl #32
    // 0x65ed68: stur            x2, [fp, #-8]
    // 0x65ed6c: cmp             w1, NULL
    // 0x65ed70: b.eq            #0x65edc0
    // 0x65ed74: SaveReg r1
    //     0x65ed74: str             x1, [SP, #-8]!
    // 0x65ed78: r0 = computeTextMetricsIfNeeded()
    //     0x65ed78: bl              #0x522fec  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::computeTextMetricsIfNeeded
    // 0x65ed7c: add             SP, SP, #8
    // 0x65ed80: ldr             x16, [fp, #0x18]
    // 0x65ed84: SaveReg r16
    //     0x65ed84: str             x16, [SP, #-8]!
    // 0x65ed88: r0 = canvas()
    //     0x65ed88: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x65ed8c: add             SP, SP, #8
    // 0x65ed90: mov             x1, x0
    // 0x65ed94: ldr             x0, [fp, #0x20]
    // 0x65ed98: LoadField: r2 = r0->field_57
    //     0x65ed98: ldur            w2, [x0, #0x57]
    // 0x65ed9c: DecompressPointer r2
    //     0x65ed9c: add             x2, x2, HEAP, lsl #32
    // 0x65eda0: cmp             w2, NULL
    // 0x65eda4: b.eq            #0x65edd8
    // 0x65eda8: ldur            x16, [fp, #-8]
    // 0x65edac: stp             x1, x16, [SP, #-0x10]!
    // 0x65edb0: ldur            x16, [fp, #-0x10]
    // 0x65edb4: SaveReg r16
    //     0x65edb4: str             x16, [SP, #-8]!
    // 0x65edb8: r0 = paint()
    //     0x65edb8: bl              #0xc4f410  ; [package:extended_text_field/src/extended_render_editable.dart] _CompositeRenderEditablePainter::paint
    // 0x65edbc: add             SP, SP, #0x18
    // 0x65edc0: r0 = Null
    //     0x65edc0: mov             x0, NULL
    // 0x65edc4: LeaveFrame
    //     0x65edc4: mov             SP, fp
    //     0x65edc8: ldp             fp, lr, [SP], #0x10
    // 0x65edcc: ret
    //     0x65edcc: ret             
    // 0x65edd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65edd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65edd4: b               #0x65ed44
    // 0x65edd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65edd8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ painter=(/* No info */) {
    // ** addr: 0x6de7f0, size: 0x118
    // 0x6de7f0: EnterFrame
    //     0x6de7f0: stp             fp, lr, [SP, #-0x10]!
    //     0x6de7f4: mov             fp, SP
    // 0x6de7f8: AllocStack(0x8)
    //     0x6de7f8: sub             SP, SP, #8
    // 0x6de7fc: CheckStackOverflow
    //     0x6de7fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6de800: cmp             SP, x16
    //     0x6de804: b.ls            #0x6de900
    // 0x6de808: ldr             x1, [fp, #0x18]
    // 0x6de80c: LoadField: r2 = r1->field_5f
    //     0x6de80c: ldur            w2, [x1, #0x5f]
    // 0x6de810: DecompressPointer r2
    //     0x6de810: add             x2, x2, HEAP, lsl #32
    // 0x6de814: ldr             x3, [fp, #0x10]
    // 0x6de818: stur            x2, [fp, #-8]
    // 0x6de81c: cmp             w3, w2
    // 0x6de820: b.ne            #0x6de834
    // 0x6de824: r0 = Null
    //     0x6de824: mov             x0, NULL
    // 0x6de828: LeaveFrame
    //     0x6de828: mov             SP, fp
    //     0x6de82c: ldp             fp, lr, [SP], #0x10
    // 0x6de830: ret
    //     0x6de830: ret             
    // 0x6de834: mov             x0, x3
    // 0x6de838: StoreField: r1->field_5f = r0
    //     0x6de838: stur            w0, [x1, #0x5f]
    //     0x6de83c: ldurb           w16, [x1, #-1]
    //     0x6de840: ldurb           w17, [x0, #-1]
    //     0x6de844: and             x16, x17, x16, lsr #2
    //     0x6de848: tst             x16, HEAP, lsr #32
    //     0x6de84c: b.eq            #0x6de854
    //     0x6de850: bl              #0xd6826c
    // 0x6de854: stp             x2, x3, [SP, #-0x10]!
    // 0x6de858: r0 = shouldRepaint()
    //     0x6de858: bl              #0xc50010  ; [package:extended_text_field/src/extended_render_editable.dart] _CompositeRenderEditablePainter::shouldRepaint
    // 0x6de85c: add             SP, SP, #0x10
    // 0x6de860: tbnz            w0, #4, #0x6de874
    // 0x6de864: ldr             x16, [fp, #0x18]
    // 0x6de868: SaveReg r16
    //     0x6de868: str             x16, [SP, #-8]!
    // 0x6de86c: r0 = markNeedsPaint()
    //     0x6de86c: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6de870: add             SP, SP, #8
    // 0x6de874: ldr             x0, [fp, #0x18]
    // 0x6de878: LoadField: r1 = r0->field_f
    //     0x6de878: ldur            w1, [x0, #0xf]
    // 0x6de87c: DecompressPointer r1
    //     0x6de87c: add             x1, x1, HEAP, lsl #32
    // 0x6de880: cmp             w1, NULL
    // 0x6de884: b.eq            #0x6de8f0
    // 0x6de888: r1 = 1
    //     0x6de888: mov             x1, #1
    // 0x6de88c: r0 = AllocateContext()
    //     0x6de88c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6de890: mov             x1, x0
    // 0x6de894: ldr             x0, [fp, #0x18]
    // 0x6de898: StoreField: r1->field_f = r0
    //     0x6de898: stur            w0, [x1, #0xf]
    // 0x6de89c: mov             x2, x1
    // 0x6de8a0: r1 = Function 'markNeedsPaint':.
    //     0x6de8a0: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x6de8a4: ldr             x1, [x1, #0xf60]
    // 0x6de8a8: r0 = AllocateClosure()
    //     0x6de8a8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6de8ac: ldur            x16, [fp, #-8]
    // 0x6de8b0: stp             x0, x16, [SP, #-0x10]!
    // 0x6de8b4: r0 = removeListener()
    //     0x6de8b4: bl              #0x6e7fb8  ; [package:extended_text_field/src/extended_render_editable.dart] _CompositeRenderEditablePainter::removeListener
    // 0x6de8b8: add             SP, SP, #0x10
    // 0x6de8bc: r1 = 1
    //     0x6de8bc: mov             x1, #1
    // 0x6de8c0: r0 = AllocateContext()
    //     0x6de8c0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6de8c4: mov             x1, x0
    // 0x6de8c8: ldr             x0, [fp, #0x18]
    // 0x6de8cc: StoreField: r1->field_f = r0
    //     0x6de8cc: stur            w0, [x1, #0xf]
    // 0x6de8d0: mov             x2, x1
    // 0x6de8d4: r1 = Function 'markNeedsPaint':.
    //     0x6de8d4: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x6de8d8: ldr             x1, [x1, #0xf60]
    // 0x6de8dc: r0 = AllocateClosure()
    //     0x6de8dc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6de8e0: ldr             x16, [fp, #0x10]
    // 0x6de8e4: stp             x0, x16, [SP, #-0x10]!
    // 0x6de8e8: r0 = addListener()
    //     0x6de8e8: bl              #0x6e76b0  ; [package:extended_text_field/src/extended_render_editable.dart] _CompositeRenderEditablePainter::addListener
    // 0x6de8ec: add             SP, SP, #0x10
    // 0x6de8f0: r0 = Null
    //     0x6de8f0: mov             x0, NULL
    // 0x6de8f4: LeaveFrame
    //     0x6de8f4: mov             SP, fp
    //     0x6de8f8: ldp             fp, lr, [SP], #0x10
    // 0x6de8fc: ret
    //     0x6de8fc: ret             
    // 0x6de900: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6de900: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6de904: b               #0x6de808
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bcf00, size: 0xbc
    // 0x9bcf00: EnterFrame
    //     0x9bcf00: stp             fp, lr, [SP, #-0x10]!
    //     0x9bcf04: mov             fp, SP
    // 0x9bcf08: AllocStack(0x8)
    //     0x9bcf08: sub             SP, SP, #8
    // 0x9bcf0c: CheckStackOverflow
    //     0x9bcf0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bcf10: cmp             SP, x16
    //     0x9bcf14: b.ls            #0x9bcfb4
    // 0x9bcf18: ldr             x0, [fp, #0x10]
    // 0x9bcf1c: r2 = Null
    //     0x9bcf1c: mov             x2, NULL
    // 0x9bcf20: r1 = Null
    //     0x9bcf20: mov             x1, NULL
    // 0x9bcf24: r4 = 59
    //     0x9bcf24: mov             x4, #0x3b
    // 0x9bcf28: branchIfSmi(r0, 0x9bcf34)
    //     0x9bcf28: tbz             w0, #0, #0x9bcf34
    // 0x9bcf2c: r4 = LoadClassIdInstr(r0)
    //     0x9bcf2c: ldur            x4, [x0, #-1]
    //     0x9bcf30: ubfx            x4, x4, #0xc, #0x14
    // 0x9bcf34: cmp             x4, #0x7e6
    // 0x9bcf38: b.eq            #0x9bcf4c
    // 0x9bcf3c: r8 = PipelineOwner
    //     0x9bcf3c: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9bcf40: r3 = Null
    //     0x9bcf40: add             x3, PP, #0x56, lsl #12  ; [pp+0x56908] Null
    //     0x9bcf44: ldr             x3, [x3, #0x908]
    // 0x9bcf48: r0 = DefaultTypeTest()
    //     0x9bcf48: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bcf4c: ldr             x16, [fp, #0x18]
    // 0x9bcf50: ldr             lr, [fp, #0x10]
    // 0x9bcf54: stp             lr, x16, [SP, #-0x10]!
    // 0x9bcf58: r0 = attach()
    //     0x9bcf58: bl              #0x9bf794  ; [package:flutter/src/rendering/object.dart] RenderObject::attach
    // 0x9bcf5c: add             SP, SP, #0x10
    // 0x9bcf60: ldr             x0, [fp, #0x18]
    // 0x9bcf64: LoadField: r1 = r0->field_5f
    //     0x9bcf64: ldur            w1, [x0, #0x5f]
    // 0x9bcf68: DecompressPointer r1
    //     0x9bcf68: add             x1, x1, HEAP, lsl #32
    // 0x9bcf6c: stur            x1, [fp, #-8]
    // 0x9bcf70: r1 = 1
    //     0x9bcf70: mov             x1, #1
    // 0x9bcf74: r0 = AllocateContext()
    //     0x9bcf74: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9bcf78: mov             x1, x0
    // 0x9bcf7c: ldr             x0, [fp, #0x18]
    // 0x9bcf80: StoreField: r1->field_f = r0
    //     0x9bcf80: stur            w0, [x1, #0xf]
    // 0x9bcf84: mov             x2, x1
    // 0x9bcf88: r1 = Function 'markNeedsPaint':.
    //     0x9bcf88: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x9bcf8c: ldr             x1, [x1, #0xf60]
    // 0x9bcf90: r0 = AllocateClosure()
    //     0x9bcf90: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9bcf94: ldur            x16, [fp, #-8]
    // 0x9bcf98: stp             x0, x16, [SP, #-0x10]!
    // 0x9bcf9c: r0 = addListener()
    //     0x9bcf9c: bl              #0x6e76b0  ; [package:extended_text_field/src/extended_render_editable.dart] _CompositeRenderEditablePainter::addListener
    // 0x9bcfa0: add             SP, SP, #0x10
    // 0x9bcfa4: r0 = Null
    //     0x9bcfa4: mov             x0, NULL
    // 0x9bcfa8: LeaveFrame
    //     0x9bcfa8: mov             SP, fp
    //     0x9bcfac: ldp             fp, lr, [SP], #0x10
    // 0x9bcfb0: ret
    //     0x9bcfb0: ret             
    // 0x9bcfb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bcfb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bcfb8: b               #0x9bcf18
  }
  _ detach(/* No info */) {
    // ** addr: 0xa68d64, size: 0x84
    // 0xa68d64: EnterFrame
    //     0xa68d64: stp             fp, lr, [SP, #-0x10]!
    //     0xa68d68: mov             fp, SP
    // 0xa68d6c: AllocStack(0x8)
    //     0xa68d6c: sub             SP, SP, #8
    // 0xa68d70: CheckStackOverflow
    //     0xa68d70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa68d74: cmp             SP, x16
    //     0xa68d78: b.ls            #0xa68de0
    // 0xa68d7c: ldr             x0, [fp, #0x10]
    // 0xa68d80: LoadField: r1 = r0->field_5f
    //     0xa68d80: ldur            w1, [x0, #0x5f]
    // 0xa68d84: DecompressPointer r1
    //     0xa68d84: add             x1, x1, HEAP, lsl #32
    // 0xa68d88: stur            x1, [fp, #-8]
    // 0xa68d8c: r1 = 1
    //     0xa68d8c: mov             x1, #1
    // 0xa68d90: r0 = AllocateContext()
    //     0xa68d90: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa68d94: mov             x1, x0
    // 0xa68d98: ldr             x0, [fp, #0x10]
    // 0xa68d9c: StoreField: r1->field_f = r0
    //     0xa68d9c: stur            w0, [x1, #0xf]
    // 0xa68da0: mov             x2, x1
    // 0xa68da4: r1 = Function 'markNeedsPaint':.
    //     0xa68da4: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0xa68da8: ldr             x1, [x1, #0xf60]
    // 0xa68dac: r0 = AllocateClosure()
    //     0xa68dac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa68db0: ldur            x16, [fp, #-8]
    // 0xa68db4: stp             x0, x16, [SP, #-0x10]!
    // 0xa68db8: r0 = removeListener()
    //     0xa68db8: bl              #0x6e7fb8  ; [package:extended_text_field/src/extended_render_editable.dart] _CompositeRenderEditablePainter::removeListener
    // 0xa68dbc: add             SP, SP, #0x10
    // 0xa68dc0: ldr             x16, [fp, #0x10]
    // 0xa68dc4: SaveReg r16
    //     0xa68dc4: str             x16, [SP, #-8]!
    // 0xa68dc8: r0 = detach()
    //     0xa68dc8: bl              #0xa6ade0  ; [package:flutter/src/foundation/node.dart] AbstractNode::detach
    // 0xa68dcc: add             SP, SP, #8
    // 0xa68dd0: r0 = Null
    //     0xa68dd0: mov             x0, NULL
    // 0xa68dd4: LeaveFrame
    //     0xa68dd4: mov             SP, fp
    //     0xa68dd8: ldp             fp, lr, [SP], #0x10
    // 0xa68ddc: ret
    //     0xa68ddc: ret             
    // 0xa68de0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa68de0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa68de4: b               #0xa68d7c
  }
  get _ parent(/* No info */) {
    // ** addr: 0xa6b188, size: 0x5c
    // 0xa6b188: EnterFrame
    //     0xa6b188: stp             fp, lr, [SP, #-0x10]!
    //     0xa6b18c: mov             fp, SP
    // 0xa6b190: AllocStack(0x8)
    //     0xa6b190: sub             SP, SP, #8
    // 0xa6b194: ldr             x0, [fp, #0x10]
    // 0xa6b198: LoadField: r3 = r0->field_13
    //     0xa6b198: ldur            w3, [x0, #0x13]
    // 0xa6b19c: DecompressPointer r3
    //     0xa6b19c: add             x3, x3, HEAP, lsl #32
    // 0xa6b1a0: mov             x0, x3
    // 0xa6b1a4: stur            x3, [fp, #-8]
    // 0xa6b1a8: r2 = Null
    //     0xa6b1a8: mov             x2, NULL
    // 0xa6b1ac: r1 = Null
    //     0xa6b1ac: mov             x1, NULL
    // 0xa6b1b0: r4 = LoadClassIdInstr(r0)
    //     0xa6b1b0: ldur            x4, [x0, #-1]
    //     0xa6b1b4: ubfx            x4, x4, #0xc, #0x14
    // 0xa6b1b8: cmp             x4, #0x9e9
    // 0xa6b1bc: b.eq            #0xa6b1d4
    // 0xa6b1c0: r8 = ExtendedRenderEditable?
    //     0xa6b1c0: add             x8, PP, #0x56, lsl #12  ; [pp+0x56928] Type: ExtendedRenderEditable?
    //     0xa6b1c4: ldr             x8, [x8, #0x928]
    // 0xa6b1c8: r3 = Null
    //     0xa6b1c8: add             x3, PP, #0x56, lsl #12  ; [pp+0x56930] Null
    //     0xa6b1cc: ldr             x3, [x3, #0x930]
    // 0xa6b1d0: r0 = DefaultNullableTypeTest()
    //     0xa6b1d0: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xa6b1d4: ldur            x0, [fp, #-8]
    // 0xa6b1d8: LeaveFrame
    //     0xa6b1d8: mov             SP, fp
    //     0xa6b1dc: ldp             fp, lr, [SP], #0x10
    // 0xa6b1e0: ret
    //     0xa6b1e0: ret             
  }
}

// class id: 2537, size: 0x17c, field offset: 0x98
class ExtendedRenderEditable extends ExtendedTextSelectionRenderObject {

  late final _FloatingCursorPainter _caretPainter; // offset: 0xac
  late Rect _caretPrototype; // offset: 0x154
  late TextPosition _floatingCursorTextPosition; // offset: 0x134

  get _ cursorHeight(/* No info */) {
    // ** addr: 0x518790, size: 0x40
    // 0x518790: EnterFrame
    //     0x518790: stp             fp, lr, [SP, #-0x10]!
    //     0x518794: mov             fp, SP
    // 0x518798: CheckStackOverflow
    //     0x518798: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x51879c: cmp             SP, x16
    //     0x5187a0: b.ls            #0x5187c8
    // 0x5187a4: ldr             x0, [fp, #0x10]
    // 0x5187a8: LoadField: r1 = r0->field_eb
    //     0x5187a8: ldur            w1, [x0, #0xeb]
    // 0x5187ac: DecompressPointer r1
    //     0x5187ac: add             x1, x1, HEAP, lsl #32
    // 0x5187b0: SaveReg r1
    //     0x5187b0: str             x1, [SP, #-8]!
    // 0x5187b4: r0 = preferredLineHeight()
    //     0x5187b4: bl              #0x51a438  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0x5187b8: add             SP, SP, #8
    // 0x5187bc: LeaveFrame
    //     0x5187bc: mov             SP, fp
    //     0x5187c0: ldp             fp, lr, [SP], #0x10
    // 0x5187c4: ret
    //     0x5187c4: ret             
    // 0x5187c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5187c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5187cc: b               #0x5187a4
  }
  _ getEndpointsForSelection(/* No info */) {
    // ** addr: 0x51f684, size: 0x438
    // 0x51f684: EnterFrame
    //     0x51f684: stp             fp, lr, [SP, #-0x10]!
    //     0x51f688: mov             fp, SP
    // 0x51f68c: AllocStack(0x40)
    //     0x51f68c: sub             SP, SP, #0x40
    // 0x51f690: CheckStackOverflow
    //     0x51f690: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x51f694: cmp             SP, x16
    //     0x51f698: b.ls            #0x51fa94
    // 0x51f69c: ldr             x16, [fp, #0x18]
    // 0x51f6a0: SaveReg r16
    //     0x51f6a0: str             x16, [SP, #-8]!
    // 0x51f6a4: r0 = computeTextMetricsIfNeeded()
    //     0x51f6a4: bl              #0x522fec  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::computeTextMetricsIfNeeded
    // 0x51f6a8: add             SP, SP, #8
    // 0x51f6ac: ldr             x16, [fp, #0x18]
    // 0x51f6b0: SaveReg r16
    //     0x51f6b0: str             x16, [SP, #-8]!
    // 0x51f6b4: r0 = _effectiveOffset()
    //     0x51f6b4: bl              #0x522e30  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_effectiveOffset
    // 0x51f6b8: add             SP, SP, #8
    // 0x51f6bc: stur            x0, [fp, #-8]
    // 0x51f6c0: ldr             x16, [fp, #0x18]
    // 0x51f6c4: SaveReg r16
    //     0x51f6c4: str             x16, [SP, #-8]!
    // 0x51f6c8: r0 = hasSpecialInlineSpanBase()
    //     0x51f6c8: bl              #0x522e08  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::hasSpecialInlineSpanBase
    // 0x51f6cc: add             SP, SP, #8
    // 0x51f6d0: tbnz            w0, #4, #0x51f70c
    // 0x51f6d4: ldr             x0, [fp, #0x18]
    // 0x51f6d8: LoadField: r1 = r0->field_eb
    //     0x51f6d8: ldur            w1, [x0, #0xeb]
    // 0x51f6dc: DecompressPointer r1
    //     0x51f6dc: add             x1, x1, HEAP, lsl #32
    // 0x51f6e0: LoadField: r2 = r1->field_f
    //     0x51f6e0: ldur            w2, [x1, #0xf]
    // 0x51f6e4: DecompressPointer r2
    //     0x51f6e4: add             x2, x2, HEAP, lsl #32
    // 0x51f6e8: cmp             w2, NULL
    // 0x51f6ec: b.eq            #0x51fa9c
    // 0x51f6f0: ldr             x16, [fp, #0x10]
    // 0x51f6f4: stp             x16, x2, [SP, #-0x10]!
    // 0x51f6f8: r0 = convertTextInputSelectionToTextPainterSelection()
    //     0x51f6f8: bl              #0x522478  ; [package:extended_text_library/src/extended_text_utils.dart] ::convertTextInputSelectionToTextPainterSelection
    // 0x51f6fc: add             SP, SP, #0x10
    // 0x51f700: mov             x1, x0
    // 0x51f704: ldr             x0, [fp, #0x10]
    // 0x51f708: b               #0x51f714
    // 0x51f70c: ldr             x0, [fp, #0x10]
    // 0x51f710: mov             x1, x0
    // 0x51f714: stur            x1, [fp, #-0x10]
    // 0x51f718: LoadField: r2 = r0->field_7
    //     0x51f718: ldur            x2, [x0, #7]
    // 0x51f71c: LoadField: r3 = r0->field_f
    //     0x51f71c: ldur            x3, [x0, #0xf]
    // 0x51f720: cmp             x2, x3
    // 0x51f724: b.ne            #0x51f8d0
    // 0x51f728: ldr             x2, [fp, #0x18]
    // 0x51f72c: r1 = 1
    //     0x51f72c: mov             x1, #1
    // 0x51f730: r0 = AllocateContext()
    //     0x51f730: bl              #0xd68aa4  ; AllocateContextStub
    // 0x51f734: mov             x1, x0
    // 0x51f738: ldur            x0, [fp, #-0x10]
    // 0x51f73c: stur            x1, [fp, #-0x20]
    // 0x51f740: LoadField: r2 = r0->field_1f
    //     0x51f740: ldur            x2, [x0, #0x1f]
    // 0x51f744: stur            x2, [fp, #-0x18]
    // 0x51f748: ldr             x16, [fp, #0x10]
    // 0x51f74c: SaveReg r16
    //     0x51f74c: str             x16, [SP, #-8]!
    // 0x51f750: r0 = extent()
    //     0x51f750: bl              #0x5223fc  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0x51f754: add             SP, SP, #8
    // 0x51f758: LoadField: r1 = r0->field_f
    //     0x51f758: ldur            w1, [x0, #0xf]
    // 0x51f75c: DecompressPointer r1
    //     0x51f75c: add             x1, x1, HEAP, lsl #32
    // 0x51f760: stur            x1, [fp, #-0x28]
    // 0x51f764: r0 = TextPosition()
    //     0x51f764: bl              #0x5223f0  ; AllocateTextPositionStub -> TextPosition (size=0x14)
    // 0x51f768: mov             x3, x0
    // 0x51f76c: ldur            x0, [fp, #-0x18]
    // 0x51f770: stur            x3, [fp, #-0x30]
    // 0x51f774: StoreField: r3->field_7 = r0
    //     0x51f774: stur            x0, [x3, #7]
    // 0x51f778: ldur            x0, [fp, #-0x28]
    // 0x51f77c: StoreField: r3->field_f = r0
    //     0x51f77c: stur            w0, [x3, #0xf]
    // 0x51f780: ldr             x0, [fp, #0x18]
    // 0x51f784: r17 = 339
    //     0x51f784: mov             x17, #0x153
    // 0x51f788: ldr             w4, [x0, x17]
    // 0x51f78c: DecompressPointer r4
    //     0x51f78c: add             x4, x4, HEAP, lsl #32
    // 0x51f790: r16 = Sentinel
    //     0x51f790: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x51f794: cmp             w4, w16
    // 0x51f798: b.eq            #0x51faa0
    // 0x51f79c: ldur            x2, [fp, #-0x20]
    // 0x51f7a0: stur            x4, [fp, #-0x28]
    // 0x51f7a4: r1 = Function '<anonymous closure>':.
    //     0x51f7a4: add             x1, PP, #0x37, lsl #12  ; [pp+0x37418] AnonymousClosure: (0x5243dc), in [package:flutter/src/widgets/framework.dart] Element::renderObject (0xcde04c)
    //     0x51f7a8: ldr             x1, [x1, #0x418]
    // 0x51f7ac: r0 = AllocateClosure()
    //     0x51f7ac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x51f7b0: ldr             x16, [fp, #0x18]
    // 0x51f7b4: ldur            lr, [fp, #-0x30]
    // 0x51f7b8: stp             lr, x16, [SP, #-0x10]!
    // 0x51f7bc: ldur            x16, [fp, #-0x28]
    // 0x51f7c0: stp             x0, x16, [SP, #-0x10]!
    // 0x51f7c4: ldur            x16, [fp, #-8]
    // 0x51f7c8: SaveReg r16
    //     0x51f7c8: str             x16, [SP, #-8]!
    // 0x51f7cc: r4 = const [0, 0x5, 0x5, 0x3, caretHeightCallBack, 0x3, effectiveOffset, 0x4, null]
    //     0x51f7cc: add             x4, PP, #0x37, lsl #12  ; [pp+0x37420] List(9) [0, 0x5, 0x5, 0x3, "caretHeightCallBack", 0x3, "effectiveOffset", 0x4, Null]
    //     0x51f7d0: ldr             x4, [x4, #0x420]
    // 0x51f7d4: r0 = getCaretOffset()
    //     0x51f7d4: bl              #0x5202b0  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::getCaretOffset
    // 0x51f7d8: add             SP, SP, #0x28
    // 0x51f7dc: mov             x1, x0
    // 0x51f7e0: ldur            x0, [fp, #-0x20]
    // 0x51f7e4: stur            x1, [fp, #-0x28]
    // 0x51f7e8: LoadField: r2 = r0->field_f
    //     0x51f7e8: ldur            w2, [x0, #0xf]
    // 0x51f7ec: DecompressPointer r2
    //     0x51f7ec: add             x2, x2, HEAP, lsl #32
    // 0x51f7f0: cmp             w2, NULL
    // 0x51f7f4: b.ne            #0x51f83c
    // 0x51f7f8: ldr             x2, [fp, #0x18]
    // 0x51f7fc: LoadField: r0 = r2->field_eb
    //     0x51f7fc: ldur            w0, [x2, #0xeb]
    // 0x51f800: DecompressPointer r0
    //     0x51f800: add             x0, x0, HEAP, lsl #32
    // 0x51f804: SaveReg r0
    //     0x51f804: str             x0, [SP, #-8]!
    // 0x51f808: r0 = preferredLineHeight()
    //     0x51f808: bl              #0x51a438  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0x51f80c: add             SP, SP, #8
    // 0x51f810: r0 = inline_Allocate_Double()
    //     0x51f810: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x51f814: add             x0, x0, #0x10
    //     0x51f818: cmp             x1, x0
    //     0x51f81c: b.ls            #0x51faac
    //     0x51f820: str             x0, [THR, #0x60]  ; THR::top
    //     0x51f824: sub             x0, x0, #0xf
    //     0x51f828: mov             x1, #0xd108
    //     0x51f82c: movk            x1, #3, lsl #16
    //     0x51f830: stur            x1, [x0, #-1]
    // 0x51f834: StoreField: r0->field_7 = d0
    //     0x51f834: stur            d0, [x0, #7]
    // 0x51f838: b               #0x51f840
    // 0x51f83c: mov             x0, x2
    // 0x51f840: stur            x0, [fp, #-0x20]
    // 0x51f844: r0 = Offset()
    //     0x51f844: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x51f848: d0 = 0.000000
    //     0x51f848: eor             v0.16b, v0.16b, v0.16b
    // 0x51f84c: StoreField: r0->field_7 = d0
    //     0x51f84c: stur            d0, [x0, #7]
    // 0x51f850: ldur            x1, [fp, #-0x20]
    // 0x51f854: LoadField: d0 = r1->field_7
    //     0x51f854: ldur            d0, [x1, #7]
    // 0x51f858: StoreField: r0->field_f = d0
    //     0x51f858: stur            d0, [x0, #0xf]
    // 0x51f85c: ldur            x16, [fp, #-0x28]
    // 0x51f860: stp             x16, x0, [SP, #-0x10]!
    // 0x51f864: r0 = +()
    //     0x51f864: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x51f868: add             SP, SP, #0x10
    // 0x51f86c: stur            x0, [fp, #-0x20]
    // 0x51f870: r0 = TextSelectionPoint()
    //     0x51f870: bl              #0x5202a4  ; AllocateTextSelectionPointStub -> TextSelectionPoint (size=0x10)
    // 0x51f874: mov             x3, x0
    // 0x51f878: ldur            x0, [fp, #-0x20]
    // 0x51f87c: stur            x3, [fp, #-0x28]
    // 0x51f880: StoreField: r3->field_7 = r0
    //     0x51f880: stur            w0, [x3, #7]
    // 0x51f884: r1 = Null
    //     0x51f884: mov             x1, NULL
    // 0x51f888: r2 = 2
    //     0x51f888: mov             x2, #2
    // 0x51f88c: r0 = AllocateArray()
    //     0x51f88c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x51f890: mov             x2, x0
    // 0x51f894: ldur            x0, [fp, #-0x28]
    // 0x51f898: stur            x2, [fp, #-0x20]
    // 0x51f89c: StoreField: r2->field_f = r0
    //     0x51f89c: stur            w0, [x2, #0xf]
    // 0x51f8a0: r1 = <TextSelectionPoint>
    //     0x51f8a0: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f468] TypeArguments: <TextSelectionPoint>
    //     0x51f8a4: ldr             x1, [x1, #0x468]
    // 0x51f8a8: r0 = AllocateGrowableArray()
    //     0x51f8a8: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x51f8ac: mov             x1, x0
    // 0x51f8b0: ldur            x0, [fp, #-0x20]
    // 0x51f8b4: StoreField: r1->field_f = r0
    //     0x51f8b4: stur            w0, [x1, #0xf]
    // 0x51f8b8: r0 = 2
    //     0x51f8b8: mov             x0, #2
    // 0x51f8bc: StoreField: r1->field_b = r0
    //     0x51f8bc: stur            w0, [x1, #0xb]
    // 0x51f8c0: mov             x0, x1
    // 0x51f8c4: LeaveFrame
    //     0x51f8c4: mov             SP, fp
    //     0x51f8c8: ldp             fp, lr, [SP], #0x10
    // 0x51f8cc: ret
    //     0x51f8cc: ret             
    // 0x51f8d0: ldr             x2, [fp, #0x18]
    // 0x51f8d4: mov             x0, x1
    // 0x51f8d8: LoadField: r1 = r2->field_eb
    //     0x51f8d8: ldur            w1, [x2, #0xeb]
    // 0x51f8dc: DecompressPointer r1
    //     0x51f8dc: add             x1, x1, HEAP, lsl #32
    // 0x51f8e0: stp             x0, x1, [SP, #-0x10]!
    // 0x51f8e4: r0 = getBoxesForSelection()
    //     0x51f8e4: bl              #0x51fabc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getBoxesForSelection
    // 0x51f8e8: add             SP, SP, #0x10
    // 0x51f8ec: stur            x0, [fp, #-0x10]
    // 0x51f8f0: SaveReg r0
    //     0x51f8f0: str             x0, [SP, #-8]!
    // 0x51f8f4: r0 = first()
    //     0x51f8f4: bl              #0x7192e8  ; [dart:core] _GrowableList::first
    // 0x51f8f8: add             SP, SP, #8
    // 0x51f8fc: LoadField: r1 = r0->field_27
    //     0x51f8fc: ldur            w1, [x0, #0x27]
    // 0x51f900: DecompressPointer r1
    //     0x51f900: add             x1, x1, HEAP, lsl #32
    // 0x51f904: r16 = Instance_TextDirection
    //     0x51f904: ldr             x16, [PP, #0x4808]  ; [pp+0x4808] Obj!TextDirection@b66e31
    // 0x51f908: cmp             w1, w16
    // 0x51f90c: b.ne            #0x51f918
    // 0x51f910: LoadField: d0 = r0->field_7
    //     0x51f910: ldur            d0, [x0, #7]
    // 0x51f914: b               #0x51f91c
    // 0x51f918: LoadField: d0 = r0->field_17
    //     0x51f918: ldur            d0, [x0, #0x17]
    // 0x51f91c: stur            d0, [fp, #-0x38]
    // 0x51f920: ldur            x16, [fp, #-0x10]
    // 0x51f924: SaveReg r16
    //     0x51f924: str             x16, [SP, #-8]!
    // 0x51f928: r0 = first()
    //     0x51f928: bl              #0x7192e8  ; [dart:core] _GrowableList::first
    // 0x51f92c: add             SP, SP, #8
    // 0x51f930: LoadField: d0 = r0->field_1f
    //     0x51f930: ldur            d0, [x0, #0x1f]
    // 0x51f934: stur            d0, [fp, #-0x40]
    // 0x51f938: r0 = Offset()
    //     0x51f938: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x51f93c: ldur            d0, [fp, #-0x38]
    // 0x51f940: StoreField: r0->field_7 = d0
    //     0x51f940: stur            d0, [x0, #7]
    // 0x51f944: ldur            d0, [fp, #-0x40]
    // 0x51f948: StoreField: r0->field_f = d0
    //     0x51f948: stur            d0, [x0, #0xf]
    // 0x51f94c: ldur            x16, [fp, #-8]
    // 0x51f950: stp             x16, x0, [SP, #-0x10]!
    // 0x51f954: r0 = +()
    //     0x51f954: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x51f958: add             SP, SP, #0x10
    // 0x51f95c: stur            x0, [fp, #-0x20]
    // 0x51f960: ldur            x16, [fp, #-0x10]
    // 0x51f964: SaveReg r16
    //     0x51f964: str             x16, [SP, #-8]!
    // 0x51f968: r0 = last()
    //     0x51f968: bl              #0x621d20  ; [dart:core] _GrowableList::last
    // 0x51f96c: add             SP, SP, #8
    // 0x51f970: LoadField: r1 = r0->field_27
    //     0x51f970: ldur            w1, [x0, #0x27]
    // 0x51f974: DecompressPointer r1
    //     0x51f974: add             x1, x1, HEAP, lsl #32
    // 0x51f978: r16 = Instance_TextDirection
    //     0x51f978: ldr             x16, [PP, #0x4808]  ; [pp+0x4808] Obj!TextDirection@b66e31
    // 0x51f97c: cmp             w1, w16
    // 0x51f980: b.ne            #0x51f98c
    // 0x51f984: LoadField: d0 = r0->field_17
    //     0x51f984: ldur            d0, [x0, #0x17]
    // 0x51f988: b               #0x51f990
    // 0x51f98c: LoadField: d0 = r0->field_7
    //     0x51f98c: ldur            d0, [x0, #7]
    // 0x51f990: ldur            x0, [fp, #-0x20]
    // 0x51f994: stur            d0, [fp, #-0x38]
    // 0x51f998: ldur            x16, [fp, #-0x10]
    // 0x51f99c: SaveReg r16
    //     0x51f99c: str             x16, [SP, #-8]!
    // 0x51f9a0: r0 = last()
    //     0x51f9a0: bl              #0x621d20  ; [dart:core] _GrowableList::last
    // 0x51f9a4: add             SP, SP, #8
    // 0x51f9a8: LoadField: d0 = r0->field_1f
    //     0x51f9a8: ldur            d0, [x0, #0x1f]
    // 0x51f9ac: stur            d0, [fp, #-0x40]
    // 0x51f9b0: r0 = Offset()
    //     0x51f9b0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x51f9b4: ldur            d0, [fp, #-0x38]
    // 0x51f9b8: StoreField: r0->field_7 = d0
    //     0x51f9b8: stur            d0, [x0, #7]
    // 0x51f9bc: ldur            d0, [fp, #-0x40]
    // 0x51f9c0: StoreField: r0->field_f = d0
    //     0x51f9c0: stur            d0, [x0, #0xf]
    // 0x51f9c4: ldur            x16, [fp, #-8]
    // 0x51f9c8: stp             x16, x0, [SP, #-0x10]!
    // 0x51f9cc: r0 = +()
    //     0x51f9cc: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x51f9d0: add             SP, SP, #0x10
    // 0x51f9d4: stur            x0, [fp, #-8]
    // 0x51f9d8: ldur            x16, [fp, #-0x10]
    // 0x51f9dc: SaveReg r16
    //     0x51f9dc: str             x16, [SP, #-8]!
    // 0x51f9e0: r0 = first()
    //     0x51f9e0: bl              #0x7192e8  ; [dart:core] _GrowableList::first
    // 0x51f9e4: add             SP, SP, #8
    // 0x51f9e8: LoadField: r1 = r0->field_27
    //     0x51f9e8: ldur            w1, [x0, #0x27]
    // 0x51f9ec: DecompressPointer r1
    //     0x51f9ec: add             x1, x1, HEAP, lsl #32
    // 0x51f9f0: stur            x1, [fp, #-0x28]
    // 0x51f9f4: r0 = TextSelectionPoint()
    //     0x51f9f4: bl              #0x5202a4  ; AllocateTextSelectionPointStub -> TextSelectionPoint (size=0x10)
    // 0x51f9f8: mov             x1, x0
    // 0x51f9fc: ldur            x0, [fp, #-0x20]
    // 0x51fa00: stur            x1, [fp, #-0x30]
    // 0x51fa04: StoreField: r1->field_7 = r0
    //     0x51fa04: stur            w0, [x1, #7]
    // 0x51fa08: ldur            x0, [fp, #-0x28]
    // 0x51fa0c: StoreField: r1->field_b = r0
    //     0x51fa0c: stur            w0, [x1, #0xb]
    // 0x51fa10: ldur            x16, [fp, #-0x10]
    // 0x51fa14: SaveReg r16
    //     0x51fa14: str             x16, [SP, #-8]!
    // 0x51fa18: r0 = last()
    //     0x51fa18: bl              #0x621d20  ; [dart:core] _GrowableList::last
    // 0x51fa1c: add             SP, SP, #8
    // 0x51fa20: LoadField: r1 = r0->field_27
    //     0x51fa20: ldur            w1, [x0, #0x27]
    // 0x51fa24: DecompressPointer r1
    //     0x51fa24: add             x1, x1, HEAP, lsl #32
    // 0x51fa28: stur            x1, [fp, #-0x10]
    // 0x51fa2c: r0 = TextSelectionPoint()
    //     0x51fa2c: bl              #0x5202a4  ; AllocateTextSelectionPointStub -> TextSelectionPoint (size=0x10)
    // 0x51fa30: mov             x3, x0
    // 0x51fa34: ldur            x0, [fp, #-8]
    // 0x51fa38: stur            x3, [fp, #-0x20]
    // 0x51fa3c: StoreField: r3->field_7 = r0
    //     0x51fa3c: stur            w0, [x3, #7]
    // 0x51fa40: ldur            x0, [fp, #-0x10]
    // 0x51fa44: StoreField: r3->field_b = r0
    //     0x51fa44: stur            w0, [x3, #0xb]
    // 0x51fa48: r1 = Null
    //     0x51fa48: mov             x1, NULL
    // 0x51fa4c: r2 = 4
    //     0x51fa4c: mov             x2, #4
    // 0x51fa50: r0 = AllocateArray()
    //     0x51fa50: bl              #0xd6987c  ; AllocateArrayStub
    // 0x51fa54: mov             x2, x0
    // 0x51fa58: ldur            x0, [fp, #-0x30]
    // 0x51fa5c: stur            x2, [fp, #-8]
    // 0x51fa60: StoreField: r2->field_f = r0
    //     0x51fa60: stur            w0, [x2, #0xf]
    // 0x51fa64: ldur            x0, [fp, #-0x20]
    // 0x51fa68: StoreField: r2->field_13 = r0
    //     0x51fa68: stur            w0, [x2, #0x13]
    // 0x51fa6c: r1 = <TextSelectionPoint>
    //     0x51fa6c: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f468] TypeArguments: <TextSelectionPoint>
    //     0x51fa70: ldr             x1, [x1, #0x468]
    // 0x51fa74: r0 = AllocateGrowableArray()
    //     0x51fa74: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x51fa78: ldur            x1, [fp, #-8]
    // 0x51fa7c: StoreField: r0->field_f = r1
    //     0x51fa7c: stur            w1, [x0, #0xf]
    // 0x51fa80: r1 = 4
    //     0x51fa80: mov             x1, #4
    // 0x51fa84: StoreField: r0->field_b = r1
    //     0x51fa84: stur            w1, [x0, #0xb]
    // 0x51fa88: LeaveFrame
    //     0x51fa88: mov             SP, fp
    //     0x51fa8c: ldp             fp, lr, [SP], #0x10
    // 0x51fa90: ret
    //     0x51fa90: ret             
    // 0x51fa94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x51fa94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x51fa98: b               #0x51f69c
    // 0x51fa9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x51fa9c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x51faa0: r9 = _caretPrototype
    //     0x51faa0: add             x9, PP, #0x37, lsl #12  ; [pp+0x37350] Field <ExtendedRenderEditable._caretPrototype@483409610>: late (offset: 0x154)
    //     0x51faa4: ldr             x9, [x9, #0x350]
    // 0x51faa8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x51faa8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x51faac: SaveReg d0
    //     0x51faac: str             q0, [SP, #-0x10]!
    // 0x51fab0: r0 = AllocateDouble()
    //     0x51fab0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x51fab4: RestoreReg d0
    //     0x51fab4: ldr             q0, [SP], #0x10
    // 0x51fab8: b               #0x51f834
  }
  get _ selectionHeightStyle(/* No info */) {
    // ** addr: 0x52237c, size: 0xc
    // 0x52237c: r0 = Instance_BoxHeightStyle
    //     0x52237c: add             x0, PP, #0x1f, lsl #12  ; [pp+0x1f280] Obj!BoxHeightStyle@b66db1
    //     0x522380: ldr             x0, [x0, #0x280]
    // 0x522384: ret
    //     0x522384: ret             
  }
  get _ selectionWidthStyle(/* No info */) {
    // ** addr: 0x522388, size: 0xc
    // 0x522388: r0 = Instance_BoxWidthStyle
    //     0x522388: add             x0, PP, #0x1f, lsl #12  ; [pp+0x1f288] Obj!BoxWidthStyle@b66d91
    //     0x52238c: ldr             x0, [x0, #0x288]
    // 0x522390: ret
    //     0x522390: ret             
  }
  get _ hasSpecialInlineSpanBase(/* No info */) {
    // ** addr: 0x522e08, size: 0x28
    // 0x522e08: ldr             x1, [SP]
    // 0x522e0c: LoadField: r2 = r1->field_97
    //     0x522e0c: ldur            w2, [x1, #0x97]
    // 0x522e10: DecompressPointer r2
    //     0x522e10: add             x2, x2, HEAP, lsl #32
    // 0x522e14: tbnz            w2, #4, #0x522e28
    // 0x522e18: LoadField: r2 = r1->field_77
    //     0x522e18: ldur            w2, [x1, #0x77]
    // 0x522e1c: DecompressPointer r2
    //     0x522e1c: add             x2, x2, HEAP, lsl #32
    // 0x522e20: mov             x0, x2
    // 0x522e24: b               #0x522e2c
    // 0x522e28: r0 = false
    //     0x522e28: add             x0, NULL, #0x30  ; false
    // 0x522e2c: ret
    //     0x522e2c: ret             
  }
  get _ _effectiveOffset(/* No info */) {
    // ** addr: 0x522e30, size: 0x68
    // 0x522e30: EnterFrame
    //     0x522e30: stp             fp, lr, [SP, #-0x10]!
    //     0x522e34: mov             fp, SP
    // 0x522e38: AllocStack(0x8)
    //     0x522e38: sub             SP, SP, #8
    // 0x522e3c: CheckStackOverflow
    //     0x522e3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x522e40: cmp             SP, x16
    //     0x522e44: b.ls            #0x522e90
    // 0x522e48: ldr             x0, [fp, #0x10]
    // 0x522e4c: r17 = 371
    //     0x522e4c: mov             x17, #0x173
    // 0x522e50: ldr             w1, [x0, x17]
    // 0x522e54: DecompressPointer r1
    //     0x522e54: add             x1, x1, HEAP, lsl #32
    // 0x522e58: cmp             w1, NULL
    // 0x522e5c: b.ne            #0x522e64
    // 0x522e60: r1 = Instance_Offset
    //     0x522e60: ldr             x1, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x522e64: stur            x1, [fp, #-8]
    // 0x522e68: SaveReg r0
    //     0x522e68: str             x0, [SP, #-8]!
    // 0x522e6c: r0 = paintOffset()
    //     0x522e6c: bl              #0x522e98  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::paintOffset
    // 0x522e70: add             SP, SP, #8
    // 0x522e74: ldur            x16, [fp, #-8]
    // 0x522e78: stp             x0, x16, [SP, #-0x10]!
    // 0x522e7c: r0 = +()
    //     0x522e7c: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x522e80: add             SP, SP, #0x10
    // 0x522e84: LeaveFrame
    //     0x522e84: mov             SP, fp
    //     0x522e88: ldp             fp, lr, [SP], #0x10
    // 0x522e8c: ret
    //     0x522e8c: ret             
    // 0x522e90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x522e90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x522e94: b               #0x522e48
  }
  get _ paintOffset(/* No info */) {
    // ** addr: 0x522e98, size: 0xe0
    // 0x522e98: EnterFrame
    //     0x522e98: stp             fp, lr, [SP, #-0x10]!
    //     0x522e9c: mov             fp, SP
    // 0x522ea0: AllocStack(0x8)
    //     0x522ea0: sub             SP, SP, #8
    // 0x522ea4: CheckStackOverflow
    //     0x522ea4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x522ea8: cmp             SP, x16
    //     0x522eac: b.ls            #0x522f68
    // 0x522eb0: ldr             x16, [fp, #0x10]
    // 0x522eb4: SaveReg r16
    //     0x522eb4: str             x16, [SP, #-8]!
    // 0x522eb8: r0 = _viewportAxis()
    //     0x522eb8: bl              #0x522f78  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_viewportAxis
    // 0x522ebc: add             SP, SP, #8
    // 0x522ec0: LoadField: r1 = r0->field_7
    //     0x522ec0: ldur            x1, [x0, #7]
    // 0x522ec4: cmp             x1, #0
    // 0x522ec8: b.gt            #0x522f18
    // 0x522ecc: ldr             x0, [fp, #0x10]
    // 0x522ed0: r17 = 275
    //     0x522ed0: mov             x17, #0x113
    // 0x522ed4: ldr             w1, [x0, x17]
    // 0x522ed8: DecompressPointer r1
    //     0x522ed8: add             x1, x1, HEAP, lsl #32
    // 0x522edc: LoadField: r0 = r1->field_43
    //     0x522edc: ldur            w0, [x1, #0x43]
    // 0x522ee0: DecompressPointer r0
    //     0x522ee0: add             x0, x0, HEAP, lsl #32
    // 0x522ee4: cmp             w0, NULL
    // 0x522ee8: b.eq            #0x522f70
    // 0x522eec: LoadField: d0 = r0->field_7
    //     0x522eec: ldur            d0, [x0, #7]
    // 0x522ef0: fneg            d1, d0
    // 0x522ef4: stur            d1, [fp, #-8]
    // 0x522ef8: r0 = Offset()
    //     0x522ef8: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x522efc: ldur            d0, [fp, #-8]
    // 0x522f00: StoreField: r0->field_7 = d0
    //     0x522f00: stur            d0, [x0, #7]
    // 0x522f04: d0 = 0.000000
    //     0x522f04: eor             v0.16b, v0.16b, v0.16b
    // 0x522f08: StoreField: r0->field_f = d0
    //     0x522f08: stur            d0, [x0, #0xf]
    // 0x522f0c: LeaveFrame
    //     0x522f0c: mov             SP, fp
    //     0x522f10: ldp             fp, lr, [SP], #0x10
    // 0x522f14: ret
    //     0x522f14: ret             
    // 0x522f18: ldr             x0, [fp, #0x10]
    // 0x522f1c: d0 = 0.000000
    //     0x522f1c: eor             v0.16b, v0.16b, v0.16b
    // 0x522f20: r17 = 275
    //     0x522f20: mov             x17, #0x113
    // 0x522f24: ldr             w1, [x0, x17]
    // 0x522f28: DecompressPointer r1
    //     0x522f28: add             x1, x1, HEAP, lsl #32
    // 0x522f2c: LoadField: r0 = r1->field_43
    //     0x522f2c: ldur            w0, [x1, #0x43]
    // 0x522f30: DecompressPointer r0
    //     0x522f30: add             x0, x0, HEAP, lsl #32
    // 0x522f34: cmp             w0, NULL
    // 0x522f38: b.eq            #0x522f74
    // 0x522f3c: LoadField: d1 = r0->field_7
    //     0x522f3c: ldur            d1, [x0, #7]
    // 0x522f40: fneg            d2, d1
    // 0x522f44: stur            d2, [fp, #-8]
    // 0x522f48: r0 = Offset()
    //     0x522f48: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x522f4c: d0 = 0.000000
    //     0x522f4c: eor             v0.16b, v0.16b, v0.16b
    // 0x522f50: StoreField: r0->field_7 = d0
    //     0x522f50: stur            d0, [x0, #7]
    // 0x522f54: ldur            d0, [fp, #-8]
    // 0x522f58: StoreField: r0->field_f = d0
    //     0x522f58: stur            d0, [x0, #0xf]
    // 0x522f5c: LeaveFrame
    //     0x522f5c: mov             SP, fp
    //     0x522f60: ldp             fp, lr, [SP], #0x10
    // 0x522f64: ret
    //     0x522f64: ret             
    // 0x522f68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x522f68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x522f6c: b               #0x522eb0
    // 0x522f70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x522f70: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x522f74: r0 = NullCastErrorSharedWithFPURegs()
    //     0x522f74: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  get _ _viewportAxis(/* No info */) {
    // ** addr: 0x522f78, size: 0x50
    // 0x522f78: EnterFrame
    //     0x522f78: stp             fp, lr, [SP, #-0x10]!
    //     0x522f7c: mov             fp, SP
    // 0x522f80: CheckStackOverflow
    //     0x522f80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x522f84: cmp             SP, x16
    //     0x522f88: b.ls            #0x522fc0
    // 0x522f8c: ldr             x16, [fp, #0x10]
    // 0x522f90: SaveReg r16
    //     0x522f90: str             x16, [SP, #-8]!
    // 0x522f94: r0 = _isMultiline()
    //     0x522f94: bl              #0x522fc8  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_isMultiline
    // 0x522f98: add             SP, SP, #8
    // 0x522f9c: tbnz            w0, #4, #0x522fac
    // 0x522fa0: r0 = Instance_Axis
    //     0x522fa0: add             x0, PP, #0xe, lsl #12  ; [pp+0xef00] Obj!Axis@b64ff1
    //     0x522fa4: ldr             x0, [x0, #0xf00]
    // 0x522fa8: b               #0x522fb4
    // 0x522fac: r0 = Instance_Axis
    //     0x522fac: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x522fb0: ldr             x0, [x0, #0x440]
    // 0x522fb4: LeaveFrame
    //     0x522fb4: mov             SP, fp
    //     0x522fb8: ldp             fp, lr, [SP], #0x10
    // 0x522fbc: ret
    //     0x522fbc: ret             
    // 0x522fc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x522fc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x522fc4: b               #0x522f8c
  }
  get _ _isMultiline(/* No info */) {
    // ** addr: 0x522fc8, size: 0x24
    // 0x522fc8: ldr             x1, [SP]
    // 0x522fcc: r17 = 259
    //     0x522fcc: mov             x17, #0x103
    // 0x522fd0: ldr             w2, [x1, x17]
    // 0x522fd4: DecompressPointer r2
    //     0x522fd4: add             x2, x2, HEAP, lsl #32
    // 0x522fd8: cmp             w2, #2
    // 0x522fdc: r16 = true
    //     0x522fdc: add             x16, NULL, #0x20  ; true
    // 0x522fe0: r17 = false
    //     0x522fe0: add             x17, NULL, #0x30  ; false
    // 0x522fe4: csel            x0, x16, x17, ne
    // 0x522fe8: ret
    //     0x522fe8: ret             
  }
  get _ _caretMargin(/* No info */) {
    // ** addr: 0x52418c, size: 0x20
    // 0x52418c: d1 = 1.000000
    //     0x52418c: fmov            d1, #1.00000000
    // 0x524190: ldr             x0, [SP]
    // 0x524194: r17 = 279
    //     0x524194: mov             x17, #0x117
    // 0x524198: ldr             w1, [x0, x17]
    // 0x52419c: DecompressPointer r1
    //     0x52419c: add             x1, x1, HEAP, lsl #32
    // 0x5241a0: LoadField: d2 = r1->field_7
    //     0x5241a0: ldur            d2, [x1, #7]
    // 0x5241a4: fadd            d0, d1, d2
    // 0x5241a8: ret
    //     0x5241a8: ret             
  }
  get _ textDirection(/* No info */) {
    // ** addr: 0x525930, size: 0x34
    // 0x525930: EnterFrame
    //     0x525930: stp             fp, lr, [SP, #-0x10]!
    //     0x525934: mov             fp, SP
    // 0x525938: ldr             x1, [fp, #0x10]
    // 0x52593c: LoadField: r2 = r1->field_eb
    //     0x52593c: ldur            w2, [x1, #0xeb]
    // 0x525940: DecompressPointer r2
    //     0x525940: add             x2, x2, HEAP, lsl #32
    // 0x525944: LoadField: r0 = r2->field_1b
    //     0x525944: ldur            w0, [x2, #0x1b]
    // 0x525948: DecompressPointer r0
    //     0x525948: add             x0, x0, HEAP, lsl #32
    // 0x52594c: cmp             w0, NULL
    // 0x525950: b.eq            #0x525960
    // 0x525954: LeaveFrame
    //     0x525954: mov             SP, fp
    //     0x525958: ldp             fp, lr, [SP], #0x10
    // 0x52595c: ret
    //     0x52595c: ret             
    // 0x525960: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x525960: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ computeDistanceToActualBaseline(/* No info */) {
    // ** addr: 0x63da3c, size: 0x54
    // 0x63da3c: EnterFrame
    //     0x63da3c: stp             fp, lr, [SP, #-0x10]!
    //     0x63da40: mov             fp, SP
    // 0x63da44: CheckStackOverflow
    //     0x63da44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63da48: cmp             SP, x16
    //     0x63da4c: b.ls            #0x63da88
    // 0x63da50: ldr             x16, [fp, #0x18]
    // 0x63da54: SaveReg r16
    //     0x63da54: str             x16, [SP, #-8]!
    // 0x63da58: r0 = computeTextMetricsIfNeeded()
    //     0x63da58: bl              #0x522fec  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::computeTextMetricsIfNeeded
    // 0x63da5c: add             SP, SP, #8
    // 0x63da60: ldr             x0, [fp, #0x18]
    // 0x63da64: LoadField: r1 = r0->field_eb
    //     0x63da64: ldur            w1, [x0, #0xeb]
    // 0x63da68: DecompressPointer r1
    //     0x63da68: add             x1, x1, HEAP, lsl #32
    // 0x63da6c: ldr             x16, [fp, #0x10]
    // 0x63da70: stp             x16, x1, [SP, #-0x10]!
    // 0x63da74: r0 = computeDistanceToActualBaseline()
    //     0x63da74: bl              #0x63da90  ; [package:flutter/src/painting/text_painter.dart] TextPainter::computeDistanceToActualBaseline
    // 0x63da78: add             SP, SP, #0x10
    // 0x63da7c: LeaveFrame
    //     0x63da7c: mov             SP, fp
    //     0x63da80: ldp             fp, lr, [SP], #0x10
    // 0x63da84: ret
    //     0x63da84: ret             
    // 0x63da88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63da88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63da8c: b               #0x63da50
  }
  _ assembleSemanticsNode(/* No info */) {
    // ** addr: 0x64523c, size: 0x1148
    // 0x64523c: EnterFrame
    //     0x64523c: stp             fp, lr, [SP, #-0x10]!
    //     0x645240: mov             fp, SP
    // 0x645244: AllocStack(0xf8)
    //     0x645244: sub             SP, SP, #0xf8
    // 0x645248: CheckStackOverflow
    //     0x645248: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64524c: cmp             SP, x16
    //     0x645250: b.ls            #0x646300
    // 0x645254: r16 = <SemanticsNode>
    //     0x645254: ldr             x16, [PP, #0x45e0]  ; [pp+0x45e0] TypeArguments: <SemanticsNode>
    // 0x645258: stp             xzr, x16, [SP, #-0x10]!
    // 0x64525c: r0 = _GrowableList()
    //     0x64525c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x645260: add             SP, SP, #0x10
    // 0x645264: mov             x2, x0
    // 0x645268: ldr             x0, [fp, #0x28]
    // 0x64526c: stur            x2, [fp, #-0x20]
    // 0x645270: LoadField: r3 = r0->field_eb
    //     0x645270: ldur            w3, [x0, #0xeb]
    // 0x645274: DecompressPointer r3
    //     0x645274: add             x3, x3, HEAP, lsl #32
    // 0x645278: stur            x3, [fp, #-0x18]
    // 0x64527c: LoadField: r4 = r3->field_1b
    //     0x64527c: ldur            w4, [x3, #0x1b]
    // 0x645280: DecompressPointer r4
    //     0x645280: add             x4, x4, HEAP, lsl #32
    // 0x645284: stur            x4, [fp, #-0x10]
    // 0x645288: cmp             w4, NULL
    // 0x64528c: b.eq            #0x646308
    // 0x645290: LoadField: r5 = r0->field_67
    //     0x645290: ldur            w5, [x0, #0x67]
    // 0x645294: DecompressPointer r5
    //     0x645294: add             x5, x5, HEAP, lsl #32
    // 0x645298: stur            x5, [fp, #-8]
    // 0x64529c: r1 = <SemanticsNode>
    //     0x64529c: ldr             x1, [PP, #0x45e0]  ; [pp+0x45e0] TypeArguments: <SemanticsNode>
    // 0x6452a0: r0 = ListQueue()
    //     0x6452a0: bl              #0x4ec788  ; AllocateListQueueStub -> ListQueue<X0> (size=0x28)
    // 0x6452a4: stur            x0, [fp, #-0x28]
    // 0x6452a8: SaveReg r0
    //     0x6452a8: str             x0, [SP, #-8]!
    // 0x6452ac: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6452ac: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6452b0: r0 = ListQueue()
    //     0x6452b0: bl              #0x4ec604  ; [dart:collection] ListQueue::ListQueue
    // 0x6452b4: add             SP, SP, #8
    // 0x6452b8: ldr             x0, [fp, #0x28]
    // 0x6452bc: LoadField: r1 = r0->field_f3
    //     0x6452bc: ldur            w1, [x0, #0xf3]
    // 0x6452c0: DecompressPointer r1
    //     0x6452c0: add             x1, x1, HEAP, lsl #32
    // 0x6452c4: cmp             w1, NULL
    // 0x6452c8: b.ne            #0x645314
    // 0x6452cc: r17 = 323
    //     0x6452cc: mov             x17, #0x143
    // 0x6452d0: ldr             w1, [x0, x17]
    // 0x6452d4: DecompressPointer r1
    //     0x6452d4: add             x1, x1, HEAP, lsl #32
    // 0x6452d8: cmp             w1, NULL
    // 0x6452dc: b.eq            #0x64630c
    // 0x6452e0: SaveReg r1
    //     0x6452e0: str             x1, [SP, #-8]!
    // 0x6452e4: r0 = combineSemanticsInfo()
    //     0x6452e4: bl              #0x64778c  ; [package:flutter/src/painting/inline_span.dart] ::combineSemanticsInfo
    // 0x6452e8: add             SP, SP, #8
    // 0x6452ec: mov             x1, x0
    // 0x6452f0: ldr             x2, [fp, #0x28]
    // 0x6452f4: StoreField: r2->field_f3 = r0
    //     0x6452f4: stur            w0, [x2, #0xf3]
    //     0x6452f8: ldurb           w16, [x2, #-1]
    //     0x6452fc: ldurb           w17, [x0, #-1]
    //     0x645300: and             x16, x17, x16, lsr #2
    //     0x645304: tst             x16, HEAP, lsr #32
    //     0x645308: b.eq            #0x645310
    //     0x64530c: bl              #0xd6828c
    // 0x645310: b               #0x645318
    // 0x645314: mov             x2, x0
    // 0x645318: stur            x1, [fp, #-0x60]
    // 0x64531c: LoadField: r3 = r1->field_7
    //     0x64531c: ldur            w3, [x1, #7]
    // 0x645320: DecompressPointer r3
    //     0x645320: add             x3, x3, HEAP, lsl #32
    // 0x645324: stur            x3, [fp, #-0x58]
    // 0x645328: LoadField: r0 = r1->field_b
    //     0x645328: ldur            w0, [x1, #0xb]
    // 0x64532c: DecompressPointer r0
    //     0x64532c: add             x0, x0, HEAP, lsl #32
    // 0x645330: r4 = LoadInt32Instr(r0)
    //     0x645330: sbfx            x4, x0, #1, #0x1f
    // 0x645334: stur            x4, [fp, #-0x50]
    // 0x645338: ldur            x13, [fp, #-0x10]
    // 0x64533c: ldur            x9, [fp, #-8]
    // 0x645340: ldur            x5, [fp, #-0x20]
    // 0x645344: d0 = 0.000000
    //     0x645344: eor             v0.16b, v0.16b, v0.16b
    // 0x645348: r12 = 0
    //     0x645348: mov             x12, #0
    // 0x64534c: r11 = 0
    //     0x64534c: mov             x11, #0
    // 0x645350: r10 = 0
    //     0x645350: mov             x10, #0
    // 0x645354: r8 = 0
    //     0x645354: mov             x8, #0
    // 0x645358: ldr             x7, [fp, #0x10]
    // 0x64535c: ldur            x6, [fp, #-0x18]
    // 0x645360: stur            x13, [fp, #-8]
    // 0x645364: stur            x12, [fp, #-0x30]
    // 0x645368: stur            x11, [fp, #-0x38]
    // 0x64536c: stur            x10, [fp, #-0x40]
    // 0x645370: stur            x9, [fp, #-0x10]
    // 0x645374: stur            x8, [fp, #-0x48]
    // 0x645378: stur            d0, [fp, #-0xd0]
    // 0x64537c: CheckStackOverflow
    //     0x64537c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x645380: cmp             SP, x16
    //     0x645384: b.ls            #0x646310
    // 0x645388: r0 = LoadClassIdInstr(r1)
    //     0x645388: ldur            x0, [x1, #-1]
    //     0x64538c: ubfx            x0, x0, #0xc, #0x14
    // 0x645390: SaveReg r1
    //     0x645390: str             x1, [SP, #-8]!
    // 0x645394: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x645394: mov             x17, #0xb8ea
    //     0x645398: add             lr, x0, x17
    //     0x64539c: ldr             lr, [x21, lr, lsl #3]
    //     0x6453a0: blr             lr
    // 0x6453a4: add             SP, SP, #8
    // 0x6453a8: r1 = LoadInt32Instr(r0)
    //     0x6453a8: sbfx            x1, x0, #1, #0x1f
    //     0x6453ac: tbz             w0, #0, #0x6453b4
    //     0x6453b0: ldur            x1, [x0, #7]
    // 0x6453b4: ldur            x2, [fp, #-0x50]
    // 0x6453b8: cmp             x2, x1
    // 0x6453bc: b.ne            #0x646288
    // 0x6453c0: ldur            x4, [fp, #-0x48]
    // 0x6453c4: ldur            x3, [fp, #-0x60]
    // 0x6453c8: cmp             x4, x1
    // 0x6453cc: b.lt            #0x645428
    // 0x6453d0: ldr             x5, [fp, #0x28]
    // 0x6453d4: ldur            x0, [fp, #-0x28]
    // 0x6453d8: r17 = 327
    //     0x6453d8: mov             x17, #0x147
    // 0x6453dc: str             w0, [x5, x17]
    // 0x6453e0: WriteBarrierInstr(obj = r5, val = r0)
    //     0x6453e0: ldurb           w16, [x5, #-1]
    //     0x6453e4: ldurb           w17, [x0, #-1]
    //     0x6453e8: and             x16, x17, x16, lsr #2
    //     0x6453ec: tst             x16, HEAP, lsr #32
    //     0x6453f0: b.eq            #0x6453f8
    //     0x6453f4: bl              #0xd682ec
    // 0x6453f8: ldr             x16, [fp, #0x20]
    // 0x6453fc: ldr             lr, [fp, #0x18]
    // 0x645400: stp             lr, x16, [SP, #-0x10]!
    // 0x645404: ldur            x16, [fp, #-0x20]
    // 0x645408: SaveReg r16
    //     0x645408: str             x16, [SP, #-8]!
    // 0x64540c: r4 = const [0, 0x3, 0x3, 0x2, childrenInInversePaintOrder, 0x2, null]
    //     0x64540c: ldr             x4, [PP, #0x7218]  ; [pp+0x7218] List(7) [0, 0x3, 0x3, 0x2, "childrenInInversePaintOrder", 0x2, Null]
    // 0x645410: r0 = updateWith()
    //     0x645410: bl              #0x6469d8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::updateWith
    // 0x645414: add             SP, SP, #0x18
    // 0x645418: r0 = Null
    //     0x645418: mov             x0, NULL
    // 0x64541c: LeaveFrame
    //     0x64541c: mov             SP, fp
    //     0x645420: ldp             fp, lr, [SP], #0x10
    // 0x645424: ret
    //     0x645424: ret             
    // 0x645428: ldr             x5, [fp, #0x28]
    // 0x64542c: r0 = BoxInt64Instr(r4)
    //     0x64542c: sbfiz           x0, x4, #1, #0x1f
    //     0x645430: cmp             x4, x0, asr #1
    //     0x645434: b.eq            #0x645440
    //     0x645438: bl              #0xd69bb8
    //     0x64543c: stur            x4, [x0, #7]
    // 0x645440: r1 = LoadClassIdInstr(r3)
    //     0x645440: ldur            x1, [x3, #-1]
    //     0x645444: ubfx            x1, x1, #0xc, #0x14
    // 0x645448: stp             x0, x3, [SP, #-0x10]!
    // 0x64544c: mov             x0, x1
    // 0x645450: r0 = GDT[cid_x0 + 0xd175]()
    //     0x645450: mov             x17, #0xd175
    //     0x645454: add             lr, x0, x17
    //     0x645458: ldr             lr, [x21, lr, lsl #3]
    //     0x64545c: blr             lr
    // 0x645460: add             SP, SP, #0x10
    // 0x645464: mov             x3, x0
    // 0x645468: ldur            x0, [fp, #-0x48]
    // 0x64546c: stur            x3, [fp, #-0x70]
    // 0x645470: add             x8, x0, #1
    // 0x645474: stur            x8, [fp, #-0x68]
    // 0x645478: cmp             w3, NULL
    // 0x64547c: b.ne            #0x6454b0
    // 0x645480: mov             x0, x3
    // 0x645484: ldur            x2, [fp, #-0x58]
    // 0x645488: r1 = Null
    //     0x645488: mov             x1, NULL
    // 0x64548c: cmp             w2, NULL
    // 0x645490: b.eq            #0x6454b0
    // 0x645494: LoadField: r4 = r2->field_17
    //     0x645494: ldur            w4, [x2, #0x17]
    // 0x645498: DecompressPointer r4
    //     0x645498: add             x4, x4, HEAP, lsl #32
    // 0x64549c: r8 = X0
    //     0x64549c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6454a0: LoadField: r9 = r4->field_7
    //     0x6454a0: ldur            x9, [x4, #7]
    // 0x6454a4: r3 = Null
    //     0x6454a4: add             x3, PP, #0x56, lsl #12  ; [pp+0x56860] Null
    //     0x6454a8: ldr             x3, [x3, #0x860]
    // 0x6454ac: blr             x9
    // 0x6454b0: ldur            x0, [fp, #-0x30]
    // 0x6454b4: ldur            x2, [fp, #-0x70]
    // 0x6454b8: LoadField: r3 = r2->field_7
    //     0x6454b8: ldur            w3, [x2, #7]
    // 0x6454bc: DecompressPointer r3
    //     0x6454bc: add             x3, x3, HEAP, lsl #32
    // 0x6454c0: stur            x3, [fp, #-0x90]
    // 0x6454c4: LoadField: r1 = r3->field_7
    //     0x6454c4: ldur            w1, [x3, #7]
    // 0x6454c8: DecompressPointer r1
    //     0x6454c8: add             x1, x1, HEAP, lsl #32
    // 0x6454cc: r4 = LoadInt32Instr(r1)
    //     0x6454cc: sbfx            x4, x1, #1, #0x1f
    // 0x6454d0: add             x5, x0, x4
    // 0x6454d4: stur            x5, [fp, #-0x48]
    // 0x6454d8: cmp             x0, x5
    // 0x6454dc: r16 = true
    //     0x6454dc: add             x16, NULL, #0x20  ; true
    // 0x6454e0: r17 = false
    //     0x6454e0: add             x17, NULL, #0x30  ; false
    // 0x6454e4: csel            x1, x16, x17, lt
    // 0x6454e8: tbnz            w1, #4, #0x6454f4
    // 0x6454ec: mov             x4, x0
    // 0x6454f0: b               #0x6454f8
    // 0x6454f4: mov             x4, x5
    // 0x6454f8: tbnz            w1, #4, #0x645504
    // 0x6454fc: mov             x6, x5
    // 0x645500: b               #0x645508
    // 0x645504: mov             x6, x0
    // 0x645508: LoadField: r0 = r2->field_13
    //     0x645508: ldur            w0, [x2, #0x13]
    // 0x64550c: DecompressPointer r0
    //     0x64550c: add             x0, x0, HEAP, lsl #32
    // 0x645510: tbnz            w0, #4, #0x645888
    // 0x645514: ldur            x2, [fp, #-0x38]
    // 0x645518: r0 = BoxInt64Instr(r2)
    //     0x645518: sbfiz           x0, x2, #1, #0x1f
    //     0x64551c: cmp             x2, x0, asr #1
    //     0x645520: b.eq            #0x64552c
    //     0x645524: bl              #0xd69bb8
    //     0x645528: stur            x2, [x0, #7]
    // 0x64552c: mov             x3, x0
    // 0x645530: stur            x3, [fp, #-0x80]
    // 0x645534: ldur            x8, [fp, #-0x40]
    // 0x645538: ldur            x4, [fp, #-0x20]
    // 0x64553c: ldr             x6, [fp, #0x10]
    // 0x645540: ldur            x7, [fp, #-0x10]
    // 0x645544: stur            x8, [fp, #-0x30]
    // 0x645548: CheckStackOverflow
    //     0x645548: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64554c: cmp             SP, x16
    //     0x645550: b.ls            #0x646318
    // 0x645554: LoadField: r0 = r6->field_b
    //     0x645554: ldur            w0, [x6, #0xb]
    // 0x645558: DecompressPointer r0
    //     0x645558: add             x0, x0, HEAP, lsl #32
    // 0x64555c: r1 = LoadInt32Instr(r0)
    //     0x64555c: sbfx            x1, x0, #1, #0x1f
    // 0x645560: cmp             x1, x8
    // 0x645564: b.le            #0x6457fc
    // 0x645568: mov             x0, x1
    // 0x64556c: mov             x1, x8
    // 0x645570: cmp             x1, x0
    // 0x645574: b.hs            #0x646320
    // 0x645578: LoadField: r0 = r6->field_f
    //     0x645578: ldur            w0, [x6, #0xf]
    // 0x64557c: DecompressPointer r0
    //     0x64557c: add             x0, x0, HEAP, lsl #32
    // 0x645580: ArrayLoad: r1 = r0[r8]  ; Unknown_4
    //     0x645580: add             x16, x0, x8, lsl #2
    //     0x645584: ldur            w1, [x16, #0xf]
    // 0x645588: DecompressPointer r1
    //     0x645588: add             x1, x1, HEAP, lsl #32
    // 0x64558c: stur            x1, [fp, #-0x78]
    // 0x645590: r0 = PlaceholderSpanIndexSemanticsTag()
    //     0x645590: bl              #0x6469cc  ; AllocatePlaceholderSpanIndexSemanticsTagStub -> PlaceholderSpanIndexSemanticsTag (size=0x14)
    // 0x645594: mov             x3, x0
    // 0x645598: ldur            x0, [fp, #-0x38]
    // 0x64559c: stur            x3, [fp, #-0x88]
    // 0x6455a0: StoreField: r3->field_b = r0
    //     0x6455a0: stur            x0, [x3, #0xb]
    // 0x6455a4: r1 = Null
    //     0x6455a4: mov             x1, NULL
    // 0x6455a8: r2 = 6
    //     0x6455a8: mov             x2, #6
    // 0x6455ac: r0 = AllocateArray()
    //     0x6455ac: bl              #0xd6987c  ; AllocateArrayStub
    // 0x6455b0: r17 = "PlaceholderSpanIndexSemanticsTag("
    //     0x6455b0: add             x17, PP, #0x15, lsl #12  ; [pp+0x15158] "PlaceholderSpanIndexSemanticsTag("
    //     0x6455b4: ldr             x17, [x17, #0x158]
    // 0x6455b8: StoreField: r0->field_f = r17
    //     0x6455b8: stur            w17, [x0, #0xf]
    // 0x6455bc: ldur            x1, [fp, #-0x80]
    // 0x6455c0: StoreField: r0->field_13 = r1
    //     0x6455c0: stur            w1, [x0, #0x13]
    // 0x6455c4: r17 = ")"
    //     0x6455c4: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0x6455c8: StoreField: r0->field_17 = r17
    //     0x6455c8: stur            w17, [x0, #0x17]
    // 0x6455cc: SaveReg r0
    //     0x6455cc: str             x0, [SP, #-8]!
    // 0x6455d0: r0 = _interpolate()
    //     0x6455d0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x6455d4: add             SP, SP, #8
    // 0x6455d8: ldur            x1, [fp, #-0x88]
    // 0x6455dc: StoreField: r1->field_7 = r0
    //     0x6455dc: stur            w0, [x1, #7]
    //     0x6455e0: ldurb           w16, [x1, #-1]
    //     0x6455e4: ldurb           w17, [x0, #-1]
    //     0x6455e8: and             x16, x17, x16, lsr #2
    //     0x6455ec: tst             x16, HEAP, lsr #32
    //     0x6455f0: b.eq            #0x6455f8
    //     0x6455f4: bl              #0xd6826c
    // 0x6455f8: ldur            x0, [fp, #-0x78]
    // 0x6455fc: LoadField: r2 = r0->field_63
    //     0x6455fc: ldur            w2, [x0, #0x63]
    // 0x645600: DecompressPointer r2
    //     0x645600: add             x2, x2, HEAP, lsl #32
    // 0x645604: cmp             w2, NULL
    // 0x645608: b.eq            #0x6457f0
    // 0x64560c: stp             x1, x2, [SP, #-0x10]!
    // 0x645610: r0 = contains()
    //     0x645610: bl              #0x787194  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x645614: add             SP, SP, #0x10
    // 0x645618: tbnz            w0, #4, #0x6457e4
    // 0x64561c: ldr             x4, [fp, #0x10]
    // 0x645620: ldur            x3, [fp, #-0x20]
    // 0x645624: ldur            x5, [fp, #-0x10]
    // 0x645628: ldur            x6, [fp, #-0x30]
    // 0x64562c: LoadField: r0 = r4->field_b
    //     0x64562c: ldur            w0, [x4, #0xb]
    // 0x645630: DecompressPointer r0
    //     0x645630: add             x0, x0, HEAP, lsl #32
    // 0x645634: r1 = LoadInt32Instr(r0)
    //     0x645634: sbfx            x1, x0, #1, #0x1f
    // 0x645638: mov             x0, x1
    // 0x64563c: mov             x1, x6
    // 0x645640: cmp             x1, x0
    // 0x645644: b.hs            #0x646324
    // 0x645648: LoadField: r0 = r4->field_f
    //     0x645648: ldur            w0, [x4, #0xf]
    // 0x64564c: DecompressPointer r0
    //     0x64564c: add             x0, x0, HEAP, lsl #32
    // 0x645650: ArrayLoad: r7 = r0[r6]  ; Unknown_4
    //     0x645650: add             x16, x0, x6, lsl #2
    //     0x645654: ldur            w7, [x16, #0xf]
    // 0x645658: DecompressPointer r7
    //     0x645658: add             x7, x7, HEAP, lsl #32
    // 0x64565c: stur            x7, [fp, #-0x88]
    // 0x645660: cmp             w5, NULL
    // 0x645664: b.eq            #0x646328
    // 0x645668: LoadField: r8 = r5->field_17
    //     0x645668: ldur            w8, [x5, #0x17]
    // 0x64566c: DecompressPointer r8
    //     0x64566c: add             x8, x8, HEAP, lsl #32
    // 0x645670: stur            x8, [fp, #-0x78]
    // 0x645674: cmp             w8, NULL
    // 0x645678: b.eq            #0x64632c
    // 0x64567c: mov             x0, x8
    // 0x645680: r2 = Null
    //     0x645680: mov             x2, NULL
    // 0x645684: r1 = Null
    //     0x645684: mov             x1, NULL
    // 0x645688: r4 = LoadClassIdInstr(r0)
    //     0x645688: ldur            x4, [x0, #-1]
    //     0x64568c: ubfx            x4, x4, #0xc, #0x14
    // 0x645690: cmp             x4, #0x808
    // 0x645694: b.eq            #0x6456ac
    // 0x645698: r8 = TextParentData<RenderBox>
    //     0x645698: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x64569c: ldr             x8, [x8, #0x298]
    // 0x6456a0: r3 = Null
    //     0x6456a0: add             x3, PP, #0x56, lsl #12  ; [pp+0x56870] Null
    //     0x6456a4: ldr             x3, [x3, #0x870]
    // 0x6456a8: r0 = DefaultTypeTest()
    //     0x6456a8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6456ac: ldur            x0, [fp, #-0x88]
    // 0x6456b0: LoadField: r1 = r0->field_2b
    //     0x6456b0: ldur            w1, [x0, #0x2b]
    // 0x6456b4: DecompressPointer r1
    //     0x6456b4: add             x1, x1, HEAP, lsl #32
    // 0x6456b8: LoadField: d0 = r1->field_7
    //     0x6456b8: ldur            d0, [x1, #7]
    // 0x6456bc: stur            d0, [fp, #-0xf0]
    // 0x6456c0: LoadField: d1 = r1->field_f
    //     0x6456c0: ldur            d1, [x1, #0xf]
    // 0x6456c4: stur            d1, [fp, #-0xe8]
    // 0x6456c8: LoadField: d2 = r1->field_17
    //     0x6456c8: ldur            d2, [x1, #0x17]
    // 0x6456cc: fsub            d3, d2, d0
    // 0x6456d0: ldur            x2, [fp, #-0x78]
    // 0x6456d4: LoadField: r3 = r2->field_17
    //     0x6456d4: ldur            w3, [x2, #0x17]
    // 0x6456d8: DecompressPointer r3
    //     0x6456d8: add             x3, x3, HEAP, lsl #32
    // 0x6456dc: cmp             w3, NULL
    // 0x6456e0: b.eq            #0x646330
    // 0x6456e4: LoadField: d2 = r3->field_7
    //     0x6456e4: ldur            d2, [x3, #7]
    // 0x6456e8: fmul            d4, d3, d2
    // 0x6456ec: LoadField: d3 = r1->field_1f
    //     0x6456ec: ldur            d3, [x1, #0x1f]
    // 0x6456f0: fsub            d5, d3, d1
    // 0x6456f4: fmul            d3, d5, d2
    // 0x6456f8: fadd            d2, d0, d4
    // 0x6456fc: stur            d2, [fp, #-0xe0]
    // 0x645700: fadd            d4, d1, d3
    // 0x645704: stur            d4, [fp, #-0xd8]
    // 0x645708: r0 = Rect()
    //     0x645708: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x64570c: ldur            d0, [fp, #-0xf0]
    // 0x645710: StoreField: r0->field_7 = d0
    //     0x645710: stur            d0, [x0, #7]
    // 0x645714: ldur            d0, [fp, #-0xe8]
    // 0x645718: StoreField: r0->field_f = d0
    //     0x645718: stur            d0, [x0, #0xf]
    // 0x64571c: ldur            d0, [fp, #-0xe0]
    // 0x645720: StoreField: r0->field_17 = d0
    //     0x645720: stur            d0, [x0, #0x17]
    // 0x645724: ldur            d0, [fp, #-0xd8]
    // 0x645728: StoreField: r0->field_1f = d0
    //     0x645728: stur            d0, [x0, #0x1f]
    // 0x64572c: ldur            x16, [fp, #-0x88]
    // 0x645730: stp             x0, x16, [SP, #-0x10]!
    // 0x645734: r0 = rect=()
    //     0x645734: bl              #0x6468c4  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::rect=
    // 0x645738: add             SP, SP, #0x10
    // 0x64573c: ldur            x0, [fp, #-0x20]
    // 0x645740: LoadField: r1 = r0->field_b
    //     0x645740: ldur            w1, [x0, #0xb]
    // 0x645744: DecompressPointer r1
    //     0x645744: add             x1, x1, HEAP, lsl #32
    // 0x645748: stur            x1, [fp, #-0x78]
    // 0x64574c: LoadField: r2 = r0->field_f
    //     0x64574c: ldur            w2, [x0, #0xf]
    // 0x645750: DecompressPointer r2
    //     0x645750: add             x2, x2, HEAP, lsl #32
    // 0x645754: LoadField: r3 = r2->field_b
    //     0x645754: ldur            w3, [x2, #0xb]
    // 0x645758: DecompressPointer r3
    //     0x645758: add             x3, x3, HEAP, lsl #32
    // 0x64575c: cmp             w1, w3
    // 0x645760: b.ne            #0x645770
    // 0x645764: SaveReg r0
    //     0x645764: str             x0, [SP, #-8]!
    // 0x645768: r0 = _growToNextCapacity()
    //     0x645768: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x64576c: add             SP, SP, #8
    // 0x645770: ldur            x3, [fp, #-0x20]
    // 0x645774: ldur            x4, [fp, #-0x30]
    // 0x645778: ldur            x0, [fp, #-0x78]
    // 0x64577c: r2 = LoadInt32Instr(r0)
    //     0x64577c: sbfx            x2, x0, #1, #0x1f
    // 0x645780: add             x0, x2, #1
    // 0x645784: lsl             x1, x0, #1
    // 0x645788: StoreField: r3->field_b = r1
    //     0x645788: stur            w1, [x3, #0xb]
    // 0x64578c: mov             x1, x2
    // 0x645790: cmp             x1, x0
    // 0x645794: b.hs            #0x646334
    // 0x645798: LoadField: r1 = r3->field_f
    //     0x645798: ldur            w1, [x3, #0xf]
    // 0x64579c: DecompressPointer r1
    //     0x64579c: add             x1, x1, HEAP, lsl #32
    // 0x6457a0: ldur            x0, [fp, #-0x88]
    // 0x6457a4: ArrayStore: r1[r2] = r0  ; List_4
    //     0x6457a4: add             x25, x1, x2, lsl #2
    //     0x6457a8: add             x25, x25, #0xf
    //     0x6457ac: str             w0, [x25]
    //     0x6457b0: tbz             w0, #0, #0x6457cc
    //     0x6457b4: ldurb           w16, [x1, #-1]
    //     0x6457b8: ldurb           w17, [x0, #-1]
    //     0x6457bc: and             x16, x17, x16, lsr #2
    //     0x6457c0: tst             x16, HEAP, lsr #32
    //     0x6457c4: b.eq            #0x6457cc
    //     0x6457c8: bl              #0xd67e5c
    // 0x6457cc: add             x8, x4, #1
    // 0x6457d0: mov             x4, x3
    // 0x6457d4: ldur            x2, [fp, #-0x38]
    // 0x6457d8: ldur            x5, [fp, #-0x48]
    // 0x6457dc: ldur            x3, [fp, #-0x80]
    // 0x6457e0: b               #0x64553c
    // 0x6457e4: ldur            x3, [fp, #-0x20]
    // 0x6457e8: ldur            x4, [fp, #-0x30]
    // 0x6457ec: b               #0x645804
    // 0x6457f0: ldur            x3, [fp, #-0x20]
    // 0x6457f4: ldur            x4, [fp, #-0x30]
    // 0x6457f8: b               #0x645804
    // 0x6457fc: mov             x3, x4
    // 0x645800: mov             x4, x8
    // 0x645804: ldur            x6, [fp, #-0x38]
    // 0x645808: ldur            x5, [fp, #-0x10]
    // 0x64580c: cmp             w5, NULL
    // 0x645810: b.eq            #0x646338
    // 0x645814: LoadField: r7 = r5->field_17
    //     0x645814: ldur            w7, [x5, #0x17]
    // 0x645818: DecompressPointer r7
    //     0x645818: add             x7, x7, HEAP, lsl #32
    // 0x64581c: stur            x7, [fp, #-0x78]
    // 0x645820: cmp             w7, NULL
    // 0x645824: b.eq            #0x64633c
    // 0x645828: mov             x0, x7
    // 0x64582c: r2 = Null
    //     0x64582c: mov             x2, NULL
    // 0x645830: r1 = Null
    //     0x645830: mov             x1, NULL
    // 0x645834: r4 = LoadClassIdInstr(r0)
    //     0x645834: ldur            x4, [x0, #-1]
    //     0x645838: ubfx            x4, x4, #0xc, #0x14
    // 0x64583c: cmp             x4, #0x808
    // 0x645840: b.eq            #0x645858
    // 0x645844: r8 = TextParentData<RenderBox>
    //     0x645844: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x645848: ldr             x8, [x8, #0x298]
    // 0x64584c: r3 = Null
    //     0x64584c: add             x3, PP, #0x56, lsl #12  ; [pp+0x56880] Null
    //     0x645850: ldr             x3, [x3, #0x880]
    // 0x645854: r0 = DefaultTypeTest()
    //     0x645854: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x645858: ldur            x0, [fp, #-0x78]
    // 0x64585c: LoadField: r1 = r0->field_13
    //     0x64585c: ldur            w1, [x0, #0x13]
    // 0x645860: DecompressPointer r1
    //     0x645860: add             x1, x1, HEAP, lsl #32
    // 0x645864: ldur            x7, [fp, #-0x38]
    // 0x645868: add             x0, x7, #1
    // 0x64586c: ldur            x3, [fp, #-8]
    // 0x645870: ldur            d0, [fp, #-0xd0]
    // 0x645874: mov             x2, x0
    // 0x645878: mov             x0, x1
    // 0x64587c: ldur            x1, [fp, #-0x30]
    // 0x645880: ldur            x7, [fp, #-0x20]
    // 0x645884: b               #0x64614c
    // 0x645888: ldur            x7, [fp, #-0x38]
    // 0x64588c: ldur            x5, [fp, #-0x10]
    // 0x645890: ldur            x8, [fp, #-0x18]
    // 0x645894: LoadField: r9 = r8->field_7
    //     0x645894: ldur            w9, [x8, #7]
    // 0x645898: DecompressPointer r9
    //     0x645898: add             x9, x9, HEAP, lsl #32
    // 0x64589c: cmp             w9, NULL
    // 0x6458a0: b.eq            #0x646340
    // 0x6458a4: r0 = BoxInt64Instr(r4)
    //     0x6458a4: sbfiz           x0, x4, #1, #0x1f
    //     0x6458a8: cmp             x4, x0, asr #1
    //     0x6458ac: b.eq            #0x6458b8
    //     0x6458b0: bl              #0xd69bb8
    //     0x6458b4: stur            x4, [x0, #7]
    // 0x6458b8: stp             x0, x9, [SP, #-0x10]!
    // 0x6458bc: r16 = Instance_BoxHeightStyle
    //     0x6458bc: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f280] Obj!BoxHeightStyle@b66db1
    //     0x6458c0: ldr             x16, [x16, #0x280]
    // 0x6458c4: stp             x16, x6, [SP, #-0x10]!
    // 0x6458c8: r0 = getBoxesForRange()
    //     0x6458c8: bl              #0x51fb34  ; [dart:ui] Paragraph::getBoxesForRange
    // 0x6458cc: add             SP, SP, #0x20
    // 0x6458d0: mov             x2, x0
    // 0x6458d4: stur            x2, [fp, #-0x88]
    // 0x6458d8: LoadField: r0 = r2->field_b
    //     0x6458d8: ldur            w0, [x2, #0xb]
    // 0x6458dc: DecompressPointer r0
    //     0x6458dc: add             x0, x0, HEAP, lsl #32
    // 0x6458e0: cbnz            w0, #0x645900
    // 0x6458e4: ldur            x13, [fp, #-8]
    // 0x6458e8: ldur            d0, [fp, #-0xd0]
    // 0x6458ec: ldur            x11, [fp, #-0x38]
    // 0x6458f0: ldur            x10, [fp, #-0x40]
    // 0x6458f4: ldur            x9, [fp, #-0x10]
    // 0x6458f8: ldur            x7, [fp, #-0x20]
    // 0x6458fc: b               #0x64615c
    // 0x645900: r1 = LoadInt32Instr(r0)
    //     0x645900: sbfx            x1, x0, #1, #0x1f
    // 0x645904: cmp             x1, #0
    // 0x645908: r16 = true
    //     0x645908: add             x16, NULL, #0x20  ; true
    // 0x64590c: r17 = false
    //     0x64590c: add             x17, NULL, #0x30  ; false
    // 0x645910: csel            x3, x16, x17, gt
    // 0x645914: stur            x3, [fp, #-0x80]
    // 0x645918: tbnz            w3, #4, #0x6462f4
    // 0x64591c: mov             x0, x1
    // 0x645920: r1 = 0
    //     0x645920: mov             x1, #0
    // 0x645924: cmp             x1, x0
    // 0x645928: b.hs            #0x646344
    // 0x64592c: LoadField: r0 = r2->field_f
    //     0x64592c: ldur            w0, [x2, #0xf]
    // 0x645930: DecompressPointer r0
    //     0x645930: add             x0, x0, HEAP, lsl #32
    // 0x645934: LoadField: r1 = r0->field_f
    //     0x645934: ldur            w1, [x0, #0xf]
    // 0x645938: DecompressPointer r1
    //     0x645938: add             x1, x1, HEAP, lsl #32
    // 0x64593c: stur            x1, [fp, #-0x78]
    // 0x645940: LoadField: d0 = r1->field_7
    //     0x645940: ldur            d0, [x1, #7]
    // 0x645944: stur            d0, [fp, #-0xf0]
    // 0x645948: LoadField: d1 = r1->field_f
    //     0x645948: ldur            d1, [x1, #0xf]
    // 0x64594c: stur            d1, [fp, #-0xe8]
    // 0x645950: LoadField: d2 = r1->field_17
    //     0x645950: ldur            d2, [x1, #0x17]
    // 0x645954: stur            d2, [fp, #-0xe0]
    // 0x645958: LoadField: d3 = r1->field_1f
    //     0x645958: ldur            d3, [x1, #0x1f]
    // 0x64595c: stur            d3, [fp, #-0xd8]
    // 0x645960: r0 = Rect()
    //     0x645960: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x645964: ldur            d0, [fp, #-0xf0]
    // 0x645968: stur            x0, [fp, #-0x98]
    // 0x64596c: StoreField: r0->field_7 = d0
    //     0x64596c: stur            d0, [x0, #7]
    // 0x645970: ldur            d0, [fp, #-0xe8]
    // 0x645974: StoreField: r0->field_f = d0
    //     0x645974: stur            d0, [x0, #0xf]
    // 0x645978: ldur            d0, [fp, #-0xe0]
    // 0x64597c: StoreField: r0->field_17 = d0
    //     0x64597c: stur            d0, [x0, #0x17]
    // 0x645980: ldur            d0, [fp, #-0xd8]
    // 0x645984: StoreField: r0->field_1f = d0
    //     0x645984: stur            d0, [x0, #0x1f]
    // 0x645988: ldur            x1, [fp, #-0x80]
    // 0x64598c: tbnz            w1, #4, #0x6462e8
    // 0x645990: ldur            x2, [fp, #-0x88]
    // 0x645994: ldur            x1, [fp, #-0x78]
    // 0x645998: LoadField: r3 = r1->field_27
    //     0x645998: ldur            w3, [x1, #0x27]
    // 0x64599c: DecompressPointer r3
    //     0x64599c: add             x3, x3, HEAP, lsl #32
    // 0x6459a0: stur            x3, [fp, #-0x80]
    // 0x6459a4: LoadField: r4 = r2->field_7
    //     0x6459a4: ldur            w4, [x2, #7]
    // 0x6459a8: DecompressPointer r4
    //     0x6459a8: add             x4, x4, HEAP, lsl #32
    // 0x6459ac: mov             x1, x4
    // 0x6459b0: stur            x4, [fp, #-0x78]
    // 0x6459b4: r0 = SubListIterable()
    //     0x6459b4: bl              #0x4c2748  ; AllocateSubListIterableStub -> SubListIterable<X0> (size=0x1c)
    // 0x6459b8: stur            x0, [fp, #-0xa0]
    // 0x6459bc: ldur            x16, [fp, #-0x88]
    // 0x6459c0: stp             x16, x0, [SP, #-0x10]!
    // 0x6459c4: r1 = 1
    //     0x6459c4: mov             x1, #1
    // 0x6459c8: stp             NULL, x1, [SP, #-0x10]!
    // 0x6459cc: r0 = SubListIterable()
    //     0x6459cc: bl              #0x4c25b4  ; [dart:_internal] SubListIterable::SubListIterable
    // 0x6459d0: add             SP, SP, #0x20
    // 0x6459d4: ldur            x16, [fp, #-0xa0]
    // 0x6459d8: SaveReg r16
    //     0x6459d8: str             x16, [SP, #-8]!
    // 0x6459dc: r0 = length()
    //     0x6459dc: bl              #0x6fd0f8  ; [dart:_internal] SubListIterable::length
    // 0x6459e0: add             SP, SP, #8
    // 0x6459e4: r1 = LoadInt32Instr(r0)
    //     0x6459e4: sbfx            x1, x0, #1, #0x1f
    //     0x6459e8: tbz             w0, #0, #0x6459f0
    //     0x6459ec: ldur            x1, [x0, #7]
    // 0x6459f0: stur            x1, [fp, #-0xa8]
    // 0x6459f4: ldur            x5, [fp, #-0x80]
    // 0x6459f8: ldur            x4, [fp, #-0x98]
    // 0x6459fc: r3 = 0
    //     0x6459fc: mov             x3, #0
    // 0x645a00: ldur            x2, [fp, #-0xa0]
    // 0x645a04: stur            x5, [fp, #-0x80]
    // 0x645a08: stur            x4, [fp, #-0x88]
    // 0x645a0c: stur            x3, [fp, #-0x30]
    // 0x645a10: CheckStackOverflow
    //     0x645a10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x645a14: cmp             SP, x16
    //     0x645a18: b.ls            #0x646348
    // 0x645a1c: r0 = LoadClassIdInstr(r2)
    //     0x645a1c: ldur            x0, [x2, #-1]
    //     0x645a20: ubfx            x0, x0, #0xc, #0x14
    // 0x645a24: SaveReg r2
    //     0x645a24: str             x2, [SP, #-8]!
    // 0x645a28: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x645a28: mov             x17, #0xb8ea
    //     0x645a2c: add             lr, x0, x17
    //     0x645a30: ldr             lr, [x21, lr, lsl #3]
    //     0x645a34: blr             lr
    // 0x645a38: add             SP, SP, #8
    // 0x645a3c: r1 = LoadInt32Instr(r0)
    //     0x645a3c: sbfx            x1, x0, #1, #0x1f
    //     0x645a40: tbz             w0, #0, #0x645a48
    //     0x645a44: ldur            x1, [x0, #7]
    // 0x645a48: ldur            x2, [fp, #-0xa8]
    // 0x645a4c: cmp             x2, x1
    // 0x645a50: b.ne            #0x6462a0
    // 0x645a54: ldur            x3, [fp, #-0xa0]
    // 0x645a58: ldur            x4, [fp, #-0x30]
    // 0x645a5c: cmp             x4, x1
    // 0x645a60: b.lt            #0x64617c
    // 0x645a64: ldur            x3, [fp, #-0x88]
    // 0x645a68: d0 = 0.000000
    //     0x645a68: eor             v0.16b, v0.16b, v0.16b
    // 0x645a6c: LoadField: d1 = r3->field_7
    //     0x645a6c: ldur            d1, [x3, #7]
    // 0x645a70: fcmp            d0, d1
    // 0x645a74: b.vs            #0x645a84
    // 0x645a78: b.le            #0x645a84
    // 0x645a7c: d2 = 0.000000
    //     0x645a7c: eor             v2.16b, v2.16b, v2.16b
    // 0x645a80: b               #0x645ac0
    // 0x645a84: fcmp            d0, d1
    // 0x645a88: b.vs            #0x645a98
    // 0x645a8c: b.ge            #0x645a98
    // 0x645a90: mov             v2.16b, v1.16b
    // 0x645a94: b               #0x645ac0
    // 0x645a98: fcmp            d0, d0
    // 0x645a9c: b.vs            #0x645aac
    // 0x645aa0: b.ne            #0x645aac
    // 0x645aa4: fadd            d2, d0, d1
    // 0x645aa8: b               #0x645ac0
    // 0x645aac: fcmp            d1, d1
    // 0x645ab0: b.vc            #0x645abc
    // 0x645ab4: mov             v2.16b, v1.16b
    // 0x645ab8: b               #0x645ac0
    // 0x645abc: d2 = 0.000000
    //     0x645abc: eor             v2.16b, v2.16b, v2.16b
    // 0x645ac0: stur            d2, [fp, #-0xf0]
    // 0x645ac4: LoadField: d3 = r3->field_f
    //     0x645ac4: ldur            d3, [x3, #0xf]
    // 0x645ac8: stur            d3, [fp, #-0xe8]
    // 0x645acc: fcmp            d0, d3
    // 0x645ad0: b.vs            #0x645ae0
    // 0x645ad4: b.le            #0x645ae0
    // 0x645ad8: d4 = 0.000000
    //     0x645ad8: eor             v4.16b, v4.16b, v4.16b
    // 0x645adc: b               #0x645b1c
    // 0x645ae0: fcmp            d0, d3
    // 0x645ae4: b.vs            #0x645af4
    // 0x645ae8: b.ge            #0x645af4
    // 0x645aec: mov             v4.16b, v3.16b
    // 0x645af0: b               #0x645b1c
    // 0x645af4: fcmp            d0, d0
    // 0x645af8: b.vs            #0x645b08
    // 0x645afc: b.ne            #0x645b08
    // 0x645b00: fadd            d4, d0, d3
    // 0x645b04: b               #0x645b1c
    // 0x645b08: fcmp            d3, d3
    // 0x645b0c: b.vc            #0x645b18
    // 0x645b10: mov             v4.16b, v3.16b
    // 0x645b14: b               #0x645b1c
    // 0x645b18: d4 = 0.000000
    //     0x645b18: eor             v4.16b, v4.16b, v4.16b
    // 0x645b1c: ldr             x4, [fp, #0x28]
    // 0x645b20: stur            d4, [fp, #-0xe0]
    // 0x645b24: LoadField: d5 = r3->field_17
    //     0x645b24: ldur            d5, [x3, #0x17]
    // 0x645b28: fsub            d6, d5, d1
    // 0x645b2c: stur            d6, [fp, #-0xd8]
    // 0x645b30: LoadField: r5 = r4->field_27
    //     0x645b30: ldur            w5, [x4, #0x27]
    // 0x645b34: DecompressPointer r5
    //     0x645b34: add             x5, x5, HEAP, lsl #32
    // 0x645b38: stur            x5, [fp, #-0x98]
    // 0x645b3c: cmp             w5, NULL
    // 0x645b40: b.eq            #0x6462b8
    // 0x645b44: r6 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x645b44: add             x6, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x645b48: ldr             x6, [x6, #0x1e8]
    // 0x645b4c: mov             x0, x5
    // 0x645b50: r2 = Null
    //     0x645b50: mov             x2, NULL
    // 0x645b54: r1 = Null
    //     0x645b54: mov             x1, NULL
    // 0x645b58: r4 = LoadClassIdInstr(r0)
    //     0x645b58: ldur            x4, [x0, #-1]
    //     0x645b5c: ubfx            x4, x4, #0xc, #0x14
    // 0x645b60: sub             x4, x4, #0x80d
    // 0x645b64: cmp             x4, #1
    // 0x645b68: b.ls            #0x645b80
    // 0x645b6c: r8 = BoxConstraints
    //     0x645b6c: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x645b70: ldr             x8, [x8, #0x1d0]
    // 0x645b74: r3 = Null
    //     0x645b74: add             x3, PP, #0x56, lsl #12  ; [pp+0x56890] Null
    //     0x645b78: ldr             x3, [x3, #0x890]
    // 0x645b7c: r0 = BoxConstraints()
    //     0x645b7c: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x645b80: ldur            x0, [fp, #-0x98]
    // 0x645b84: LoadField: d0 = r0->field_f
    //     0x645b84: ldur            d0, [x0, #0xf]
    // 0x645b88: ldur            d1, [fp, #-0xd8]
    // 0x645b8c: stur            d0, [fp, #-0xf8]
    // 0x645b90: fcmp            d1, d0
    // 0x645b94: b.vs            #0x645b9c
    // 0x645b98: b.gt            #0x645c40
    // 0x645b9c: fcmp            d1, d0
    // 0x645ba0: b.vs            #0x645bb0
    // 0x645ba4: b.ge            #0x645bb0
    // 0x645ba8: mov             v0.16b, v1.16b
    // 0x645bac: b               #0x645c40
    // 0x645bb0: d2 = 0.000000
    //     0x645bb0: eor             v2.16b, v2.16b, v2.16b
    // 0x645bb4: fcmp            d1, d2
    // 0x645bb8: b.vs            #0x645bc0
    // 0x645bbc: b.eq            #0x645bc8
    // 0x645bc0: r0 = false
    //     0x645bc0: add             x0, NULL, #0x30  ; false
    // 0x645bc4: b               #0x645bcc
    // 0x645bc8: r0 = true
    //     0x645bc8: add             x0, NULL, #0x20  ; true
    // 0x645bcc: tbnz            w0, #4, #0x645be4
    // 0x645bd0: fadd            d3, d1, d0
    // 0x645bd4: fmul            d4, d3, d1
    // 0x645bd8: fmul            d1, d4, d0
    // 0x645bdc: mov             v0.16b, v1.16b
    // 0x645be0: b               #0x645c40
    // 0x645be4: tbnz            w0, #4, #0x645c28
    // 0x645be8: r0 = inline_Allocate_Double()
    //     0x645be8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x645bec: add             x0, x0, #0x10
    //     0x645bf0: cmp             x1, x0
    //     0x645bf4: b.ls            #0x646350
    //     0x645bf8: str             x0, [THR, #0x60]  ; THR::top
    //     0x645bfc: sub             x0, x0, #0xf
    //     0x645c00: mov             x1, #0xd108
    //     0x645c04: movk            x1, #3, lsl #16
    //     0x645c08: stur            x1, [x0, #-1]
    // 0x645c0c: StoreField: r0->field_7 = d0
    //     0x645c0c: stur            d0, [x0, #7]
    // 0x645c10: SaveReg r0
    //     0x645c10: str             x0, [SP, #-8]!
    // 0x645c14: r0 = isNegative()
    //     0x645c14: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x645c18: add             SP, SP, #8
    // 0x645c1c: tbnz            w0, #4, #0x645c28
    // 0x645c20: ldur            d1, [fp, #-0xf8]
    // 0x645c24: b               #0x645c34
    // 0x645c28: ldur            d1, [fp, #-0xf8]
    // 0x645c2c: fcmp            d1, d1
    // 0x645c30: b.vc            #0x645c3c
    // 0x645c34: mov             v0.16b, v1.16b
    // 0x645c38: b               #0x645c40
    // 0x645c3c: ldur            d0, [fp, #-0xd8]
    // 0x645c40: ldr             x3, [fp, #0x28]
    // 0x645c44: ldur            x5, [fp, #-0x88]
    // 0x645c48: ldur            d1, [fp, #-0xe8]
    // 0x645c4c: stur            d0, [fp, #-0xf8]
    // 0x645c50: LoadField: d2 = r5->field_1f
    //     0x645c50: ldur            d2, [x5, #0x1f]
    // 0x645c54: fsub            d3, d2, d1
    // 0x645c58: stur            d3, [fp, #-0xd8]
    // 0x645c5c: LoadField: r4 = r3->field_27
    //     0x645c5c: ldur            w4, [x3, #0x27]
    // 0x645c60: DecompressPointer r4
    //     0x645c60: add             x4, x4, HEAP, lsl #32
    // 0x645c64: stur            x4, [fp, #-0x98]
    // 0x645c68: cmp             w4, NULL
    // 0x645c6c: b.eq            #0x6462d0
    // 0x645c70: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x645c70: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x645c74: ldr             x5, [x5, #0x1e8]
    // 0x645c78: mov             x0, x4
    // 0x645c7c: r2 = Null
    //     0x645c7c: mov             x2, NULL
    // 0x645c80: r1 = Null
    //     0x645c80: mov             x1, NULL
    // 0x645c84: r4 = LoadClassIdInstr(r0)
    //     0x645c84: ldur            x4, [x0, #-1]
    //     0x645c88: ubfx            x4, x4, #0xc, #0x14
    // 0x645c8c: sub             x4, x4, #0x80d
    // 0x645c90: cmp             x4, #1
    // 0x645c94: b.ls            #0x645cac
    // 0x645c98: r8 = BoxConstraints
    //     0x645c98: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x645c9c: ldr             x8, [x8, #0x1d0]
    // 0x645ca0: r3 = Null
    //     0x645ca0: add             x3, PP, #0x56, lsl #12  ; [pp+0x568a0] Null
    //     0x645ca4: ldr             x3, [x3, #0x8a0]
    // 0x645ca8: r0 = BoxConstraints()
    //     0x645ca8: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x645cac: ldur            x0, [fp, #-0x98]
    // 0x645cb0: LoadField: d0 = r0->field_1f
    //     0x645cb0: ldur            d0, [x0, #0x1f]
    // 0x645cb4: ldur            d1, [fp, #-0xd8]
    // 0x645cb8: stur            d0, [fp, #-0xe8]
    // 0x645cbc: fcmp            d1, d0
    // 0x645cc0: b.vs            #0x645cd0
    // 0x645cc4: b.le            #0x645cd0
    // 0x645cc8: mov             v4.16b, v0.16b
    // 0x645ccc: b               #0x645d74
    // 0x645cd0: fcmp            d1, d0
    // 0x645cd4: b.vs            #0x645ce4
    // 0x645cd8: b.ge            #0x645ce4
    // 0x645cdc: mov             v4.16b, v1.16b
    // 0x645ce0: b               #0x645d74
    // 0x645ce4: d2 = 0.000000
    //     0x645ce4: eor             v2.16b, v2.16b, v2.16b
    // 0x645ce8: fcmp            d1, d2
    // 0x645cec: b.vs            #0x645cf4
    // 0x645cf0: b.eq            #0x645cfc
    // 0x645cf4: r0 = false
    //     0x645cf4: add             x0, NULL, #0x30  ; false
    // 0x645cf8: b               #0x645d00
    // 0x645cfc: r0 = true
    //     0x645cfc: add             x0, NULL, #0x20  ; true
    // 0x645d00: tbnz            w0, #4, #0x645d18
    // 0x645d04: fadd            d3, d1, d0
    // 0x645d08: fmul            d4, d3, d1
    // 0x645d0c: fmul            d1, d4, d0
    // 0x645d10: mov             v4.16b, v1.16b
    // 0x645d14: b               #0x645d74
    // 0x645d18: tbnz            w0, #4, #0x645d5c
    // 0x645d1c: r0 = inline_Allocate_Double()
    //     0x645d1c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x645d20: add             x0, x0, #0x10
    //     0x645d24: cmp             x1, x0
    //     0x645d28: b.ls            #0x646368
    //     0x645d2c: str             x0, [THR, #0x60]  ; THR::top
    //     0x645d30: sub             x0, x0, #0xf
    //     0x645d34: mov             x1, #0xd108
    //     0x645d38: movk            x1, #3, lsl #16
    //     0x645d3c: stur            x1, [x0, #-1]
    // 0x645d40: StoreField: r0->field_7 = d0
    //     0x645d40: stur            d0, [x0, #7]
    // 0x645d44: SaveReg r0
    //     0x645d44: str             x0, [SP, #-8]!
    // 0x645d48: r0 = isNegative()
    //     0x645d48: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x645d4c: add             SP, SP, #8
    // 0x645d50: tbnz            w0, #4, #0x645d5c
    // 0x645d54: ldur            d1, [fp, #-0xe8]
    // 0x645d58: b               #0x645d68
    // 0x645d5c: ldur            d1, [fp, #-0xe8]
    // 0x645d60: fcmp            d1, d1
    // 0x645d64: b.vc            #0x645d70
    // 0x645d68: mov             v4.16b, v1.16b
    // 0x645d6c: b               #0x645d74
    // 0x645d70: ldur            d4, [fp, #-0xd8]
    // 0x645d74: ldur            d3, [fp, #-0xd0]
    // 0x645d78: ldur            d1, [fp, #-0xf0]
    // 0x645d7c: ldur            d2, [fp, #-0xe0]
    // 0x645d80: ldur            d0, [fp, #-0xf8]
    // 0x645d84: ldur            x0, [fp, #-0x70]
    // 0x645d88: fadd            d5, d1, d0
    // 0x645d8c: stur            d5, [fp, #-0xe8]
    // 0x645d90: fadd            d6, d2, d4
    // 0x645d94: mov             v0.16b, v1.16b
    // 0x645d98: stur            d6, [fp, #-0xd8]
    // 0x645d9c: stp             fp, lr, [SP, #-0x10]!
    // 0x645da0: mov             fp, SP
    // 0x645da4: CallRuntime_LibcFloor(double) -> double
    //     0x645da4: and             SP, SP, #0xfffffffffffffff0
    //     0x645da8: mov             sp, SP
    //     0x645dac: ldr             x16, [THR, #0x560]  ; THR::LibcFloor
    //     0x645db0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x645db4: blr             x16
    //     0x645db8: mov             x16, #8
    //     0x645dbc: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x645dc0: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x645dc4: sub             sp, x16, #1, lsl #12
    //     0x645dc8: mov             SP, fp
    //     0x645dcc: ldp             fp, lr, [SP], #0x10
    // 0x645dd0: d1 = 4.000000
    //     0x645dd0: fmov            d1, #4.00000000
    // 0x645dd4: fsub            d2, d0, d1
    // 0x645dd8: ldur            d0, [fp, #-0xe0]
    // 0x645ddc: stur            d2, [fp, #-0xf0]
    // 0x645de0: stp             fp, lr, [SP, #-0x10]!
    // 0x645de4: mov             fp, SP
    // 0x645de8: CallRuntime_LibcFloor(double) -> double
    //     0x645de8: and             SP, SP, #0xfffffffffffffff0
    //     0x645dec: mov             sp, SP
    //     0x645df0: ldr             x16, [THR, #0x560]  ; THR::LibcFloor
    //     0x645df4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x645df8: blr             x16
    //     0x645dfc: mov             x16, #8
    //     0x645e00: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x645e04: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x645e08: sub             sp, x16, #1, lsl #12
    //     0x645e0c: mov             SP, fp
    //     0x645e10: ldp             fp, lr, [SP], #0x10
    // 0x645e14: d1 = 4.000000
    //     0x645e14: fmov            d1, #4.00000000
    // 0x645e18: fsub            d2, d0, d1
    // 0x645e1c: ldur            d0, [fp, #-0xe8]
    // 0x645e20: stur            d2, [fp, #-0xe0]
    // 0x645e24: stp             fp, lr, [SP, #-0x10]!
    // 0x645e28: mov             fp, SP
    // 0x645e2c: CallRuntime_LibcCeil(double) -> double
    //     0x645e2c: and             SP, SP, #0xfffffffffffffff0
    //     0x645e30: mov             sp, SP
    //     0x645e34: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x645e38: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x645e3c: blr             x16
    //     0x645e40: mov             x16, #8
    //     0x645e44: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x645e48: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x645e4c: sub             sp, x16, #1, lsl #12
    //     0x645e50: mov             SP, fp
    //     0x645e54: ldp             fp, lr, [SP], #0x10
    // 0x645e58: d1 = 4.000000
    //     0x645e58: fmov            d1, #4.00000000
    // 0x645e5c: fadd            d2, d0, d1
    // 0x645e60: ldur            d0, [fp, #-0xd8]
    // 0x645e64: stur            d2, [fp, #-0xe8]
    // 0x645e68: stp             fp, lr, [SP, #-0x10]!
    // 0x645e6c: mov             fp, SP
    // 0x645e70: CallRuntime_LibcCeil(double) -> double
    //     0x645e70: and             SP, SP, #0xfffffffffffffff0
    //     0x645e74: mov             sp, SP
    //     0x645e78: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x645e7c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x645e80: blr             x16
    //     0x645e84: mov             x16, #8
    //     0x645e88: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x645e8c: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x645e90: sub             sp, x16, #1, lsl #12
    //     0x645e94: mov             SP, fp
    //     0x645e98: ldp             fp, lr, [SP], #0x10
    // 0x645e9c: mov             v1.16b, v0.16b
    // 0x645ea0: d0 = 4.000000
    //     0x645ea0: fmov            d0, #4.00000000
    // 0x645ea4: fadd            d2, d1, d0
    // 0x645ea8: stur            d2, [fp, #-0xd8]
    // 0x645eac: r0 = Rect()
    //     0x645eac: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x645eb0: ldur            d0, [fp, #-0xf0]
    // 0x645eb4: stur            x0, [fp, #-0x98]
    // 0x645eb8: StoreField: r0->field_7 = d0
    //     0x645eb8: stur            d0, [x0, #7]
    // 0x645ebc: ldur            d0, [fp, #-0xe0]
    // 0x645ec0: StoreField: r0->field_f = d0
    //     0x645ec0: stur            d0, [x0, #0xf]
    // 0x645ec4: ldur            d0, [fp, #-0xe8]
    // 0x645ec8: StoreField: r0->field_17 = d0
    //     0x645ec8: stur            d0, [x0, #0x17]
    // 0x645ecc: ldur            d0, [fp, #-0xd8]
    // 0x645ed0: StoreField: r0->field_1f = d0
    //     0x645ed0: stur            d0, [x0, #0x1f]
    // 0x645ed4: r0 = SemanticsConfiguration()
    //     0x645ed4: bl              #0x5102c0  ; AllocateSemanticsConfigurationStub -> SemanticsConfiguration (size=0x94)
    // 0x645ed8: stur            x0, [fp, #-0xb0]
    // 0x645edc: SaveReg r0
    //     0x645edc: str             x0, [SP, #-8]!
    // 0x645ee0: r0 = SemanticsConfiguration()
    //     0x645ee0: bl              #0x50fde0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::SemanticsConfiguration
    // 0x645ee4: add             SP, SP, #8
    // 0x645ee8: ldur            d1, [fp, #-0xd0]
    // 0x645eec: d0 = 1.000000
    //     0x645eec: fmov            d0, #1.00000000
    // 0x645ef0: fadd            d2, d1, d0
    // 0x645ef4: stur            d2, [fp, #-0xd8]
    // 0x645ef8: r0 = OrdinalSortKey()
    //     0x645ef8: bl              #0x6468b8  ; AllocateOrdinalSortKeyStub -> OrdinalSortKey (size=0x14)
    // 0x645efc: ldur            d0, [fp, #-0xd0]
    // 0x645f00: StoreField: r0->field_b = d0
    //     0x645f00: stur            d0, [x0, #0xb]
    // 0x645f04: ldur            x1, [fp, #-0xb0]
    // 0x645f08: StoreField: r1->field_23 = r0
    //     0x645f08: stur            w0, [x1, #0x23]
    //     0x645f0c: ldurb           w16, [x1, #-1]
    //     0x645f10: ldurb           w17, [x0, #-1]
    //     0x645f14: and             x16, x17, x16, lsr #2
    //     0x645f18: tst             x16, HEAP, lsr #32
    //     0x645f1c: b.eq            #0x645f24
    //     0x645f20: bl              #0xd6826c
    // 0x645f24: r2 = true
    //     0x645f24: add             x2, NULL, #0x20  ; true
    // 0x645f28: StoreField: r1->field_13 = r2
    //     0x645f28: stur            w2, [x1, #0x13]
    // 0x645f2c: ldur            x0, [fp, #-8]
    // 0x645f30: StoreField: r1->field_73 = r0
    //     0x645f30: stur            w0, [x1, #0x73]
    //     0x645f34: ldurb           w16, [x1, #-1]
    //     0x645f38: ldurb           w17, [x0, #-1]
    //     0x645f3c: and             x16, x17, x16, lsr #2
    //     0x645f40: tst             x16, HEAP, lsr #32
    //     0x645f44: b.eq            #0x645f4c
    //     0x645f48: bl              #0xd6826c
    // 0x645f4c: ldur            x0, [fp, #-0x70]
    // 0x645f50: LoadField: r3 = r0->field_b
    //     0x645f50: ldur            w3, [x0, #0xb]
    // 0x645f54: DecompressPointer r3
    //     0x645f54: add             x3, x3, HEAP, lsl #32
    // 0x645f58: cmp             w3, NULL
    // 0x645f5c: b.ne            #0x645f64
    // 0x645f60: ldur            x3, [fp, #-0x90]
    // 0x645f64: stur            x3, [fp, #-0xc0]
    // 0x645f68: LoadField: r4 = r0->field_1b
    //     0x645f68: ldur            w4, [x0, #0x1b]
    // 0x645f6c: DecompressPointer r4
    //     0x645f6c: add             x4, x4, HEAP, lsl #32
    // 0x645f70: stur            x4, [fp, #-0xb8]
    // 0x645f74: r0 = AttributedString()
    //     0x645f74: bl              #0x50ffbc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0x645f78: mov             x1, x0
    // 0x645f7c: ldur            x0, [fp, #-0xc0]
    // 0x645f80: StoreField: r1->field_7 = r0
    //     0x645f80: stur            w0, [x1, #7]
    // 0x645f84: ldur            x0, [fp, #-0xb8]
    // 0x645f88: StoreField: r1->field_b = r0
    //     0x645f88: stur            w0, [x1, #0xb]
    // 0x645f8c: mov             x0, x1
    // 0x645f90: ldur            x1, [fp, #-0xb0]
    // 0x645f94: StoreField: r1->field_47 = r0
    //     0x645f94: stur            w0, [x1, #0x47]
    //     0x645f98: ldurb           w16, [x1, #-1]
    //     0x645f9c: ldurb           w17, [x0, #-1]
    //     0x645fa0: and             x16, x17, x16, lsr #2
    //     0x645fa4: tst             x16, HEAP, lsr #32
    //     0x645fa8: b.eq            #0x645fb0
    //     0x645fac: bl              #0xd6826c
    // 0x645fb0: r0 = true
    //     0x645fb0: add             x0, NULL, #0x20  ; true
    // 0x645fb4: StoreField: r1->field_13 = r0
    //     0x645fb4: stur            w0, [x1, #0x13]
    // 0x645fb8: ldur            x6, [fp, #-0x70]
    // 0x645fbc: LoadField: r2 = r6->field_f
    //     0x645fbc: ldur            w2, [x6, #0xf]
    // 0x645fc0: DecompressPointer r2
    //     0x645fc0: add             x2, x2, HEAP, lsl #32
    // 0x645fc4: cmp             w2, NULL
    // 0x645fc8: b.eq            #0x646010
    // 0x645fcc: LoadField: r3 = r2->field_5b
    //     0x645fcc: ldur            w3, [x2, #0x5b]
    // 0x645fd0: DecompressPointer r3
    //     0x645fd0: add             x3, x3, HEAP, lsl #32
    // 0x645fd4: cmp             w3, NULL
    // 0x645fd8: b.eq            #0x646010
    // 0x645fdc: r16 = Instance_SemanticsAction
    //     0x645fdc: ldr             x16, [PP, #0x4850]  ; [pp+0x4850] Obj!SemanticsAction@b5ce01
    // 0x645fe0: stp             x16, x1, [SP, #-0x10]!
    // 0x645fe4: SaveReg r3
    //     0x645fe4: str             x3, [SP, #-8]!
    // 0x645fe8: r0 = _addArgumentlessAction()
    //     0x645fe8: bl              #0x6467e0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addArgumentlessAction
    // 0x645fec: add             SP, SP, #0x18
    // 0x645ff0: ldur            x16, [fp, #-0xb0]
    // 0x645ff4: r30 = Instance_SemanticsFlag
    //     0x645ff4: add             lr, PP, #0x22, lsl #12  ; [pp+0x222f0] Obj!SemanticsFlag@b5cb51
    //     0x645ff8: ldr             lr, [lr, #0x2f0]
    // 0x645ffc: stp             lr, x16, [SP, #-0x10]!
    // 0x646000: r16 = true
    //     0x646000: add             x16, NULL, #0x20  ; true
    // 0x646004: SaveReg r16
    //     0x646004: str             x16, [SP, #-8]!
    // 0x646008: r0 = _setFlag()
    //     0x646008: bl              #0x646790  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_setFlag
    // 0x64600c: add             SP, SP, #0x18
    // 0x646010: ldr             x0, [fp, #0x28]
    // 0x646014: r17 = 327
    //     0x646014: mov             x17, #0x147
    // 0x646018: ldr             w1, [x0, x17]
    // 0x64601c: DecompressPointer r1
    //     0x64601c: add             x1, x1, HEAP, lsl #32
    // 0x646020: cmp             w1, NULL
    // 0x646024: b.eq            #0x64604c
    // 0x646028: LoadField: r2 = r1->field_f
    //     0x646028: ldur            x2, [x1, #0xf]
    // 0x64602c: LoadField: r3 = r1->field_17
    //     0x64602c: ldur            x3, [x1, #0x17]
    // 0x646030: cmp             x2, x3
    // 0x646034: b.eq            #0x64604c
    // 0x646038: SaveReg r1
    //     0x646038: str             x1, [SP, #-8]!
    // 0x64603c: r0 = removeFirst()
    //     0x64603c: bl              #0x4ebdd0  ; [dart:collection] ListQueue::removeFirst
    // 0x646040: add             SP, SP, #8
    // 0x646044: mov             x1, x0
    // 0x646048: b               #0x646068
    // 0x64604c: r0 = SemanticsNode()
    //     0x64604c: bl              #0x646784  ; AllocateSemanticsNodeStub -> SemanticsNode (size=0xc8)
    // 0x646050: stur            x0, [fp, #-0xb8]
    // 0x646054: SaveReg r0
    //     0x646054: str             x0, [SP, #-8]!
    // 0x646058: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x646058: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x64605c: r0 = SemanticsNode()
    //     0x64605c: bl              #0x64642c  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::SemanticsNode
    // 0x646060: add             SP, SP, #8
    // 0x646064: ldur            x1, [fp, #-0xb8]
    // 0x646068: ldur            x0, [fp, #-0x20]
    // 0x64606c: stur            x1, [fp, #-0xb8]
    // 0x646070: ldur            x16, [fp, #-0xb0]
    // 0x646074: stp             x16, x1, [SP, #-0x10]!
    // 0x646078: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x646078: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x64607c: r0 = updateWith()
    //     0x64607c: bl              #0x6469d8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::updateWith
    // 0x646080: add             SP, SP, #0x10
    // 0x646084: ldur            x16, [fp, #-0xb8]
    // 0x646088: ldur            lr, [fp, #-0x98]
    // 0x64608c: stp             lr, x16, [SP, #-0x10]!
    // 0x646090: r0 = rect=()
    //     0x646090: bl              #0x6468c4  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::rect=
    // 0x646094: add             SP, SP, #0x10
    // 0x646098: ldur            x16, [fp, #-0x28]
    // 0x64609c: ldur            lr, [fp, #-0xb8]
    // 0x6460a0: stp             lr, x16, [SP, #-0x10]!
    // 0x6460a4: r0 = _add()
    //     0x6460a4: bl              #0x4eba10  ; [dart:collection] ListQueue::_add
    // 0x6460a8: add             SP, SP, #0x10
    // 0x6460ac: ldur            x0, [fp, #-0x20]
    // 0x6460b0: LoadField: r1 = r0->field_b
    //     0x6460b0: ldur            w1, [x0, #0xb]
    // 0x6460b4: DecompressPointer r1
    //     0x6460b4: add             x1, x1, HEAP, lsl #32
    // 0x6460b8: stur            x1, [fp, #-0x98]
    // 0x6460bc: LoadField: r2 = r0->field_f
    //     0x6460bc: ldur            w2, [x0, #0xf]
    // 0x6460c0: DecompressPointer r2
    //     0x6460c0: add             x2, x2, HEAP, lsl #32
    // 0x6460c4: LoadField: r3 = r2->field_b
    //     0x6460c4: ldur            w3, [x2, #0xb]
    // 0x6460c8: DecompressPointer r3
    //     0x6460c8: add             x3, x3, HEAP, lsl #32
    // 0x6460cc: cmp             w1, w3
    // 0x6460d0: b.ne            #0x6460e0
    // 0x6460d4: SaveReg r0
    //     0x6460d4: str             x0, [SP, #-8]!
    // 0x6460d8: r0 = _growToNextCapacity()
    //     0x6460d8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6460dc: add             SP, SP, #8
    // 0x6460e0: ldur            x7, [fp, #-0x20]
    // 0x6460e4: ldur            x0, [fp, #-0x98]
    // 0x6460e8: r2 = LoadInt32Instr(r0)
    //     0x6460e8: sbfx            x2, x0, #1, #0x1f
    // 0x6460ec: add             x0, x2, #1
    // 0x6460f0: lsl             x1, x0, #1
    // 0x6460f4: StoreField: r7->field_b = r1
    //     0x6460f4: stur            w1, [x7, #0xb]
    // 0x6460f8: mov             x1, x2
    // 0x6460fc: cmp             x1, x0
    // 0x646100: b.hs            #0x646380
    // 0x646104: LoadField: r1 = r7->field_f
    //     0x646104: ldur            w1, [x7, #0xf]
    // 0x646108: DecompressPointer r1
    //     0x646108: add             x1, x1, HEAP, lsl #32
    // 0x64610c: ldur            x0, [fp, #-0xb8]
    // 0x646110: ArrayStore: r1[r2] = r0  ; List_4
    //     0x646110: add             x25, x1, x2, lsl #2
    //     0x646114: add             x25, x25, #0xf
    //     0x646118: str             w0, [x25]
    //     0x64611c: tbz             w0, #0, #0x646138
    //     0x646120: ldurb           w16, [x1, #-1]
    //     0x646124: ldurb           w17, [x0, #-1]
    //     0x646128: and             x16, x17, x16, lsr #2
    //     0x64612c: tst             x16, HEAP, lsr #32
    //     0x646130: b.eq            #0x646138
    //     0x646134: bl              #0xd67e5c
    // 0x646138: ldur            x3, [fp, #-0x80]
    // 0x64613c: ldur            d0, [fp, #-0xd8]
    // 0x646140: ldur            x2, [fp, #-0x38]
    // 0x646144: ldur            x1, [fp, #-0x40]
    // 0x646148: ldur            x0, [fp, #-0x10]
    // 0x64614c: mov             x13, x3
    // 0x646150: mov             x11, x2
    // 0x646154: mov             x10, x1
    // 0x646158: mov             x9, x0
    // 0x64615c: ldur            x12, [fp, #-0x48]
    // 0x646160: ldur            x8, [fp, #-0x68]
    // 0x646164: ldr             x2, [fp, #0x28]
    // 0x646168: mov             x5, x7
    // 0x64616c: ldur            x3, [fp, #-0x58]
    // 0x646170: ldur            x4, [fp, #-0x50]
    // 0x646174: ldur            x1, [fp, #-0x60]
    // 0x646178: b               #0x645358
    // 0x64617c: ldur            x7, [fp, #-0x20]
    // 0x646180: ldur            d0, [fp, #-0xd0]
    // 0x646184: ldur            x5, [fp, #-0x88]
    // 0x646188: ldur            x6, [fp, #-0x70]
    // 0x64618c: r0 = BoxInt64Instr(r4)
    //     0x64618c: sbfiz           x0, x4, #1, #0x1f
    //     0x646190: cmp             x4, x0, asr #1
    //     0x646194: b.eq            #0x6461a0
    //     0x646198: bl              #0xd69c6c
    //     0x64619c: stur            x4, [x0, #7]
    // 0x6461a0: r1 = LoadClassIdInstr(r3)
    //     0x6461a0: ldur            x1, [x3, #-1]
    //     0x6461a4: ubfx            x1, x1, #0xc, #0x14
    // 0x6461a8: stp             x0, x3, [SP, #-0x10]!
    // 0x6461ac: mov             x0, x1
    // 0x6461b0: r0 = GDT[cid_x0 + 0xd175]()
    //     0x6461b0: mov             x17, #0xd175
    //     0x6461b4: add             lr, x0, x17
    //     0x6461b8: ldr             lr, [x21, lr, lsl #3]
    //     0x6461bc: blr             lr
    // 0x6461c0: add             SP, SP, #0x10
    // 0x6461c4: mov             x3, x0
    // 0x6461c8: ldur            x0, [fp, #-0x30]
    // 0x6461cc: stur            x3, [fp, #-0x80]
    // 0x6461d0: add             x4, x0, #1
    // 0x6461d4: stur            x4, [fp, #-0xc8]
    // 0x6461d8: cmp             w3, NULL
    // 0x6461dc: b.ne            #0x646210
    // 0x6461e0: mov             x0, x3
    // 0x6461e4: ldur            x2, [fp, #-0x78]
    // 0x6461e8: r1 = Null
    //     0x6461e8: mov             x1, NULL
    // 0x6461ec: cmp             w2, NULL
    // 0x6461f0: b.eq            #0x646210
    // 0x6461f4: LoadField: r4 = r2->field_17
    //     0x6461f4: ldur            w4, [x2, #0x17]
    // 0x6461f8: DecompressPointer r4
    //     0x6461f8: add             x4, x4, HEAP, lsl #32
    // 0x6461fc: r8 = X0
    //     0x6461fc: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x646200: LoadField: r9 = r4->field_7
    //     0x646200: ldur            x9, [x4, #7]
    // 0x646204: r3 = Null
    //     0x646204: add             x3, PP, #0x56, lsl #12  ; [pp+0x568b0] Null
    //     0x646208: ldr             x3, [x3, #0x8b0]
    // 0x64620c: blr             x9
    // 0x646210: ldur            x0, [fp, #-0x80]
    // 0x646214: LoadField: d0 = r0->field_7
    //     0x646214: ldur            d0, [x0, #7]
    // 0x646218: stur            d0, [fp, #-0xf0]
    // 0x64621c: LoadField: d1 = r0->field_f
    //     0x64621c: ldur            d1, [x0, #0xf]
    // 0x646220: stur            d1, [fp, #-0xe8]
    // 0x646224: LoadField: d2 = r0->field_17
    //     0x646224: ldur            d2, [x0, #0x17]
    // 0x646228: stur            d2, [fp, #-0xe0]
    // 0x64622c: LoadField: d3 = r0->field_1f
    //     0x64622c: ldur            d3, [x0, #0x1f]
    // 0x646230: stur            d3, [fp, #-0xd8]
    // 0x646234: r0 = Rect()
    //     0x646234: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x646238: ldur            d0, [fp, #-0xf0]
    // 0x64623c: StoreField: r0->field_7 = d0
    //     0x64623c: stur            d0, [x0, #7]
    // 0x646240: ldur            d0, [fp, #-0xe8]
    // 0x646244: StoreField: r0->field_f = d0
    //     0x646244: stur            d0, [x0, #0xf]
    // 0x646248: ldur            d0, [fp, #-0xe0]
    // 0x64624c: StoreField: r0->field_17 = d0
    //     0x64624c: stur            d0, [x0, #0x17]
    // 0x646250: ldur            d0, [fp, #-0xd8]
    // 0x646254: StoreField: r0->field_1f = d0
    //     0x646254: stur            d0, [x0, #0x1f]
    // 0x646258: ldur            x16, [fp, #-0x88]
    // 0x64625c: stp             x0, x16, [SP, #-0x10]!
    // 0x646260: r0 = expandToInclude()
    //     0x646260: bl              #0x5251a0  ; [dart:ui] Rect::expandToInclude
    // 0x646264: add             SP, SP, #0x10
    // 0x646268: mov             x1, x0
    // 0x64626c: ldur            x0, [fp, #-0x80]
    // 0x646270: LoadField: r5 = r0->field_27
    //     0x646270: ldur            w5, [x0, #0x27]
    // 0x646274: DecompressPointer r5
    //     0x646274: add             x5, x5, HEAP, lsl #32
    // 0x646278: mov             x4, x1
    // 0x64627c: ldur            x3, [fp, #-0xc8]
    // 0x646280: ldur            x1, [fp, #-0xa8]
    // 0x646284: b               #0x645a00
    // 0x646288: ldur            x0, [fp, #-0x60]
    // 0x64628c: r0 = ConcurrentModificationError()
    //     0x64628c: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x646290: ldur            x3, [fp, #-0x60]
    // 0x646294: StoreField: r0->field_b = r3
    //     0x646294: stur            w3, [x0, #0xb]
    // 0x646298: r0 = Throw()
    //     0x646298: bl              #0xd67e38  ; ThrowStub
    // 0x64629c: brk             #0
    // 0x6462a0: ldur            x0, [fp, #-0xa0]
    // 0x6462a4: r0 = ConcurrentModificationError()
    //     0x6462a4: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x6462a8: ldur            x3, [fp, #-0xa0]
    // 0x6462ac: StoreField: r0->field_b = r3
    //     0x6462ac: stur            w3, [x0, #0xb]
    // 0x6462b0: r0 = Throw()
    //     0x6462b0: bl              #0xd67e38  ; ThrowStub
    // 0x6462b4: brk             #0
    // 0x6462b8: r0 = StateError()
    //     0x6462b8: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6462bc: r6 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6462bc: add             x6, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6462c0: ldr             x6, [x6, #0x1e8]
    // 0x6462c4: StoreField: r0->field_b = r6
    //     0x6462c4: stur            w6, [x0, #0xb]
    // 0x6462c8: r0 = Throw()
    //     0x6462c8: bl              #0xd67e38  ; ThrowStub
    // 0x6462cc: brk             #0
    // 0x6462d0: r0 = StateError()
    //     0x6462d0: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6462d4: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6462d4: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6462d8: ldr             x5, [x5, #0x1e8]
    // 0x6462dc: StoreField: r0->field_b = r5
    //     0x6462dc: stur            w5, [x0, #0xb]
    // 0x6462e0: r0 = Throw()
    //     0x6462e0: bl              #0xd67e38  ; ThrowStub
    // 0x6462e4: brk             #0
    // 0x6462e8: r0 = noElement()
    //     0x6462e8: bl              #0x4c8048  ; [dart:_internal] IterableElementError::noElement
    // 0x6462ec: r0 = Throw()
    //     0x6462ec: bl              #0xd67e38  ; ThrowStub
    // 0x6462f0: brk             #0
    // 0x6462f4: r0 = noElement()
    //     0x6462f4: bl              #0x4c8048  ; [dart:_internal] IterableElementError::noElement
    // 0x6462f8: r0 = Throw()
    //     0x6462f8: bl              #0xd67e38  ; ThrowStub
    // 0x6462fc: brk             #0
    // 0x646300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x646300: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x646304: b               #0x645254
    // 0x646308: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x646308: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x64630c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x64630c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x646310: r0 = StackOverflowSharedWithFPURegs()
    //     0x646310: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x646314: b               #0x645388
    // 0x646318: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x646318: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64631c: b               #0x645554
    // 0x646320: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x646320: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x646324: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x646324: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x646328: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x646328: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x64632c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x64632c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x646330: r0 = NullCastErrorSharedWithFPURegs()
    //     0x646330: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x646334: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x646334: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x646338: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x646338: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x64633c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x64633c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x646340: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x646340: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x646344: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x646344: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x646348: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x646348: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64634c: b               #0x645a1c
    // 0x646350: stp             q1, q2, [SP, #-0x20]!
    // 0x646354: SaveReg d0
    //     0x646354: str             q0, [SP, #-0x10]!
    // 0x646358: r0 = AllocateDouble()
    //     0x646358: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x64635c: RestoreReg d0
    //     0x64635c: ldr             q0, [SP], #0x10
    // 0x646360: ldp             q1, q2, [SP], #0x20
    // 0x646364: b               #0x645c0c
    // 0x646368: stp             q1, q2, [SP, #-0x20]!
    // 0x64636c: SaveReg d0
    //     0x64636c: str             q0, [SP, #-0x10]!
    // 0x646370: r0 = AllocateDouble()
    //     0x646370: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x646374: RestoreReg d0
    //     0x646374: ldr             q0, [SP], #0x10
    // 0x646378: ldp             q1, q2, [SP], #0x20
    // 0x64637c: b               #0x645d40
    // 0x646380: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x646380: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0x64bf74, size: 0x958
    // 0x64bf74: EnterFrame
    //     0x64bf74: stp             fp, lr, [SP, #-0x10]!
    //     0x64bf78: mov             fp, SP
    // 0x64bf7c: AllocStack(0x70)
    //     0x64bf7c: sub             SP, SP, #0x70
    // 0x64bf80: CheckStackOverflow
    //     0x64bf80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64bf84: cmp             SP, x16
    //     0x64bf88: b.ls            #0x64c8a4
    // 0x64bf8c: ldr             x16, [fp, #0x18]
    // 0x64bf90: ldr             lr, [fp, #0x10]
    // 0x64bf94: stp             lr, x16, [SP, #-0x10]!
    // 0x64bf98: r0 = Shader._()
    //     0x64bf98: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x64bf9c: add             SP, SP, #0x10
    // 0x64bfa0: ldr             x0, [fp, #0x18]
    // 0x64bfa4: LoadField: r1 = r0->field_eb
    //     0x64bfa4: ldur            w1, [x0, #0xeb]
    // 0x64bfa8: DecompressPointer r1
    //     0x64bfa8: add             x1, x1, HEAP, lsl #32
    // 0x64bfac: stur            x1, [fp, #-8]
    // 0x64bfb0: LoadField: r2 = r1->field_f
    //     0x64bfb0: ldur            w2, [x1, #0xf]
    // 0x64bfb4: DecompressPointer r2
    //     0x64bfb4: add             x2, x2, HEAP, lsl #32
    // 0x64bfb8: cmp             w2, NULL
    // 0x64bfbc: b.eq            #0x64c8ac
    // 0x64bfc0: SaveReg r2
    //     0x64bfc0: str             x2, [SP, #-8]!
    // 0x64bfc4: r0 = getSemanticsInformation()
    //     0x64bfc4: bl              #0x64ce54  ; [package:flutter/src/painting/inline_span.dart] InlineSpan::getSemanticsInformation
    // 0x64bfc8: add             SP, SP, #8
    // 0x64bfcc: mov             x4, x0
    // 0x64bfd0: ldr             x3, [fp, #0x18]
    // 0x64bfd4: stur            x4, [fp, #-0x10]
    // 0x64bfd8: r17 = 323
    //     0x64bfd8: mov             x17, #0x143
    // 0x64bfdc: str             w0, [x3, x17]
    // 0x64bfe0: WriteBarrierInstr(obj = r3, val = r0)
    //     0x64bfe0: ldurb           w16, [x3, #-1]
    //     0x64bfe4: ldurb           w17, [x0, #-1]
    //     0x64bfe8: and             x16, x17, x16, lsr #2
    //     0x64bfec: tst             x16, HEAP, lsr #32
    //     0x64bff0: b.eq            #0x64bff8
    //     0x64bff4: bl              #0xd682ac
    // 0x64bff8: r1 = Function '<anonymous closure>':.
    //     0x64bff8: add             x1, PP, #0x56, lsl #12  ; [pp+0x568c0] AnonymousClosure: (0xc9fb98), in [package:flutter/src/rendering/paragraph.dart] RenderParagraph::describeSemanticsConfiguration (0x64d4cc)
    //     0x64bffc: ldr             x1, [x1, #0x8c0]
    // 0x64c000: r2 = Null
    //     0x64c000: mov             x2, NULL
    // 0x64c004: r0 = AllocateClosure()
    //     0x64c004: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x64c008: ldur            x16, [fp, #-0x10]
    // 0x64c00c: stp             x0, x16, [SP, #-0x10]!
    // 0x64c010: r0 = any()
    //     0x64c010: bl              #0x6f72b8  ; [dart:collection] _ListBase&Object&ListMixin::any
    // 0x64c014: add             SP, SP, #0x10
    // 0x64c018: tbnz            w0, #4, #0x64c058
    // 0x64c01c: r0 = defaultTargetPlatform()
    //     0x64c01c: bl              #0x59ed88  ; [package:flutter/src/foundation/_platform_io.dart] ::defaultTargetPlatform
    // 0x64c020: r16 = Instance_TargetPlatform
    //     0x64c020: ldr             x16, [PP, #0x43d0]  ; [pp+0x43d0] Obj!TargetPlatform@b65cf1
    // 0x64c024: cmp             w0, w16
    // 0x64c028: b.eq            #0x64c04c
    // 0x64c02c: ldr             x1, [fp, #0x10]
    // 0x64c030: r0 = true
    //     0x64c030: add             x0, NULL, #0x20  ; true
    // 0x64c034: StoreField: r1->field_7 = r0
    //     0x64c034: stur            w0, [x1, #7]
    // 0x64c038: StoreField: r1->field_b = r0
    //     0x64c038: stur            w0, [x1, #0xb]
    // 0x64c03c: r0 = Null
    //     0x64c03c: mov             x0, NULL
    // 0x64c040: LeaveFrame
    //     0x64c040: mov             SP, fp
    //     0x64c044: ldp             fp, lr, [SP], #0x10
    // 0x64c048: ret
    //     0x64c048: ret             
    // 0x64c04c: ldr             x1, [fp, #0x10]
    // 0x64c050: r0 = true
    //     0x64c050: add             x0, NULL, #0x20  ; true
    // 0x64c054: b               #0x64c060
    // 0x64c058: ldr             x1, [fp, #0x10]
    // 0x64c05c: r0 = true
    //     0x64c05c: add             x0, NULL, #0x20  ; true
    // 0x64c060: ldr             x2, [fp, #0x18]
    // 0x64c064: LoadField: r3 = r2->field_ef
    //     0x64c064: ldur            w3, [x2, #0xef]
    // 0x64c068: DecompressPointer r3
    //     0x64c068: add             x3, x3, HEAP, lsl #32
    // 0x64c06c: cmp             w3, NULL
    // 0x64c070: b.ne            #0x64c458
    // 0x64c074: r0 = StringBuffer()
    //     0x64c074: bl              #0x4d1e30  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x64c078: stur            x0, [fp, #-0x10]
    // 0x64c07c: SaveReg r0
    //     0x64c07c: str             x0, [SP, #-8]!
    // 0x64c080: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x64c080: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x64c084: r0 = StringBuffer()
    //     0x64c084: bl              #0x4d16e0  ; [dart:core] StringBuffer::StringBuffer
    // 0x64c088: add             SP, SP, #8
    // 0x64c08c: r16 = <StringAttribute>
    //     0x64c08c: ldr             x16, [PP, #0x48a0]  ; [pp+0x48a0] TypeArguments: <StringAttribute>
    // 0x64c090: stp             xzr, x16, [SP, #-0x10]!
    // 0x64c094: r0 = _GrowableList()
    //     0x64c094: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x64c098: add             SP, SP, #0x10
    // 0x64c09c: mov             x2, x0
    // 0x64c0a0: ldr             x1, [fp, #0x18]
    // 0x64c0a4: stur            x2, [fp, #-0x40]
    // 0x64c0a8: r17 = 323
    //     0x64c0a8: mov             x17, #0x143
    // 0x64c0ac: ldr             w3, [x1, x17]
    // 0x64c0b0: DecompressPointer r3
    //     0x64c0b0: add             x3, x3, HEAP, lsl #32
    // 0x64c0b4: stur            x3, [fp, #-0x38]
    // 0x64c0b8: cmp             w3, NULL
    // 0x64c0bc: b.eq            #0x64c8b0
    // 0x64c0c0: LoadField: r4 = r3->field_7
    //     0x64c0c0: ldur            w4, [x3, #7]
    // 0x64c0c4: DecompressPointer r4
    //     0x64c0c4: add             x4, x4, HEAP, lsl #32
    // 0x64c0c8: stur            x4, [fp, #-0x30]
    // 0x64c0cc: LoadField: r0 = r3->field_b
    //     0x64c0cc: ldur            w0, [x3, #0xb]
    // 0x64c0d0: DecompressPointer r0
    //     0x64c0d0: add             x0, x0, HEAP, lsl #32
    // 0x64c0d4: r5 = LoadInt32Instr(r0)
    //     0x64c0d4: sbfx            x5, x0, #1, #0x1f
    // 0x64c0d8: stur            x5, [fp, #-0x28]
    // 0x64c0dc: r7 = 0
    //     0x64c0dc: mov             x7, #0
    // 0x64c0e0: r6 = 0
    //     0x64c0e0: mov             x6, #0
    // 0x64c0e4: stur            x7, [fp, #-0x18]
    // 0x64c0e8: stur            x6, [fp, #-0x20]
    // 0x64c0ec: CheckStackOverflow
    //     0x64c0ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64c0f0: cmp             SP, x16
    //     0x64c0f4: b.ls            #0x64c8b4
    // 0x64c0f8: r0 = LoadClassIdInstr(r3)
    //     0x64c0f8: ldur            x0, [x3, #-1]
    //     0x64c0fc: ubfx            x0, x0, #0xc, #0x14
    // 0x64c100: SaveReg r3
    //     0x64c100: str             x3, [SP, #-8]!
    // 0x64c104: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x64c104: mov             x17, #0xb8ea
    //     0x64c108: add             lr, x0, x17
    //     0x64c10c: ldr             lr, [x21, lr, lsl #3]
    //     0x64c110: blr             lr
    // 0x64c114: add             SP, SP, #8
    // 0x64c118: r1 = LoadInt32Instr(r0)
    //     0x64c118: sbfx            x1, x0, #1, #0x1f
    //     0x64c11c: tbz             w0, #0, #0x64c124
    //     0x64c120: ldur            x1, [x0, #7]
    // 0x64c124: ldur            x2, [fp, #-0x28]
    // 0x64c128: cmp             x2, x1
    // 0x64c12c: b.ne            #0x64c88c
    // 0x64c130: ldur            x3, [fp, #-0x38]
    // 0x64c134: ldur            x4, [fp, #-0x20]
    // 0x64c138: cmp             x4, x1
    // 0x64c13c: b.lt            #0x64c1a4
    // 0x64c140: ldr             x0, [fp, #0x18]
    // 0x64c144: ldur            x1, [fp, #-0x40]
    // 0x64c148: ldur            x16, [fp, #-0x10]
    // 0x64c14c: SaveReg r16
    //     0x64c14c: str             x16, [SP, #-8]!
    // 0x64c150: r0 = toString()
    //     0x64c150: bl              #0xaba59c  ; [dart:core] StringBuffer::toString
    // 0x64c154: add             SP, SP, #8
    // 0x64c158: stur            x0, [fp, #-0x48]
    // 0x64c15c: r0 = AttributedString()
    //     0x64c15c: bl              #0x50ffbc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0x64c160: mov             x1, x0
    // 0x64c164: ldur            x0, [fp, #-0x48]
    // 0x64c168: StoreField: r1->field_7 = r0
    //     0x64c168: stur            w0, [x1, #7]
    // 0x64c16c: ldur            x5, [fp, #-0x40]
    // 0x64c170: StoreField: r1->field_b = r5
    //     0x64c170: stur            w5, [x1, #0xb]
    // 0x64c174: mov             x0, x1
    // 0x64c178: ldr             x6, [fp, #0x18]
    // 0x64c17c: StoreField: r6->field_ef = r0
    //     0x64c17c: stur            w0, [x6, #0xef]
    //     0x64c180: ldurb           w16, [x6, #-1]
    //     0x64c184: ldurb           w17, [x0, #-1]
    //     0x64c188: and             x16, x17, x16, lsr #2
    //     0x64c18c: tst             x16, HEAP, lsr #32
    //     0x64c190: b.eq            #0x64c198
    //     0x64c194: bl              #0xd6830c
    // 0x64c198: mov             x0, x1
    // 0x64c19c: mov             x1, x6
    // 0x64c1a0: b               #0x64c460
    // 0x64c1a4: ldr             x6, [fp, #0x18]
    // 0x64c1a8: ldur            x5, [fp, #-0x40]
    // 0x64c1ac: r0 = BoxInt64Instr(r4)
    //     0x64c1ac: sbfiz           x0, x4, #1, #0x1f
    //     0x64c1b0: cmp             x4, x0, asr #1
    //     0x64c1b4: b.eq            #0x64c1c0
    //     0x64c1b8: bl              #0xd69bb8
    //     0x64c1bc: stur            x4, [x0, #7]
    // 0x64c1c0: r1 = LoadClassIdInstr(r3)
    //     0x64c1c0: ldur            x1, [x3, #-1]
    //     0x64c1c4: ubfx            x1, x1, #0xc, #0x14
    // 0x64c1c8: stp             x0, x3, [SP, #-0x10]!
    // 0x64c1cc: mov             x0, x1
    // 0x64c1d0: r0 = GDT[cid_x0 + 0xd175]()
    //     0x64c1d0: mov             x17, #0xd175
    //     0x64c1d4: add             lr, x0, x17
    //     0x64c1d8: ldr             lr, [x21, lr, lsl #3]
    //     0x64c1dc: blr             lr
    // 0x64c1e0: add             SP, SP, #0x10
    // 0x64c1e4: mov             x3, x0
    // 0x64c1e8: ldur            x0, [fp, #-0x20]
    // 0x64c1ec: stur            x3, [fp, #-0x48]
    // 0x64c1f0: add             x6, x0, #1
    // 0x64c1f4: stur            x6, [fp, #-0x50]
    // 0x64c1f8: cmp             w3, NULL
    // 0x64c1fc: b.ne            #0x64c230
    // 0x64c200: mov             x0, x3
    // 0x64c204: ldur            x2, [fp, #-0x30]
    // 0x64c208: r1 = Null
    //     0x64c208: mov             x1, NULL
    // 0x64c20c: cmp             w2, NULL
    // 0x64c210: b.eq            #0x64c230
    // 0x64c214: LoadField: r4 = r2->field_17
    //     0x64c214: ldur            w4, [x2, #0x17]
    // 0x64c218: DecompressPointer r4
    //     0x64c218: add             x4, x4, HEAP, lsl #32
    // 0x64c21c: r8 = X0
    //     0x64c21c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x64c220: LoadField: r9 = r4->field_7
    //     0x64c220: ldur            x9, [x4, #7]
    // 0x64c224: r3 = Null
    //     0x64c224: add             x3, PP, #0x56, lsl #12  ; [pp+0x568c8] Null
    //     0x64c228: ldr             x3, [x3, #0x8c8]
    // 0x64c22c: blr             x9
    // 0x64c230: ldur            x0, [fp, #-0x48]
    // 0x64c234: LoadField: r1 = r0->field_b
    //     0x64c234: ldur            w1, [x0, #0xb]
    // 0x64c238: DecompressPointer r1
    //     0x64c238: add             x1, x1, HEAP, lsl #32
    // 0x64c23c: cmp             w1, NULL
    // 0x64c240: b.ne            #0x64c24c
    // 0x64c244: LoadField: r1 = r0->field_7
    //     0x64c244: ldur            w1, [x0, #7]
    // 0x64c248: DecompressPointer r1
    //     0x64c248: add             x1, x1, HEAP, lsl #32
    // 0x64c24c: stur            x1, [fp, #-0x58]
    // 0x64c250: LoadField: r2 = r0->field_1b
    //     0x64c250: ldur            w2, [x0, #0x1b]
    // 0x64c254: DecompressPointer r2
    //     0x64c254: add             x2, x2, HEAP, lsl #32
    // 0x64c258: r0 = LoadClassIdInstr(r2)
    //     0x64c258: ldur            x0, [x2, #-1]
    //     0x64c25c: ubfx            x0, x0, #0xc, #0x14
    // 0x64c260: SaveReg r2
    //     0x64c260: str             x2, [SP, #-8]!
    // 0x64c264: r0 = GDT[cid_x0 + 0xb940]()
    //     0x64c264: mov             x17, #0xb940
    //     0x64c268: add             lr, x0, x17
    //     0x64c26c: ldr             lr, [x21, lr, lsl #3]
    //     0x64c270: blr             lr
    // 0x64c274: add             SP, SP, #8
    // 0x64c278: mov             x1, x0
    // 0x64c27c: stur            x1, [fp, #-0x48]
    // 0x64c280: ldur            x2, [fp, #-0x40]
    // 0x64c284: ldur            x3, [fp, #-0x18]
    // 0x64c288: CheckStackOverflow
    //     0x64c288: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64c28c: cmp             SP, x16
    //     0x64c290: b.ls            #0x64c8bc
    // 0x64c294: r0 = LoadClassIdInstr(r1)
    //     0x64c294: ldur            x0, [x1, #-1]
    //     0x64c298: ubfx            x0, x0, #0xc, #0x14
    // 0x64c29c: SaveReg r1
    //     0x64c29c: str             x1, [SP, #-8]!
    // 0x64c2a0: r0 = GDT[cid_x0 + 0x541]()
    //     0x64c2a0: add             lr, x0, #0x541
    //     0x64c2a4: ldr             lr, [x21, lr, lsl #3]
    //     0x64c2a8: blr             lr
    // 0x64c2ac: add             SP, SP, #8
    // 0x64c2b0: tbnz            w0, #4, #0x64c3dc
    // 0x64c2b4: ldur            x2, [fp, #-0x40]
    // 0x64c2b8: ldur            x3, [fp, #-0x18]
    // 0x64c2bc: ldur            x1, [fp, #-0x48]
    // 0x64c2c0: r0 = LoadClassIdInstr(r1)
    //     0x64c2c0: ldur            x0, [x1, #-1]
    //     0x64c2c4: ubfx            x0, x0, #0xc, #0x14
    // 0x64c2c8: SaveReg r1
    //     0x64c2c8: str             x1, [SP, #-8]!
    // 0x64c2cc: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x64c2cc: add             lr, x0, #0x5ca
    //     0x64c2d0: ldr             lr, [x21, lr, lsl #3]
    //     0x64c2d4: blr             lr
    // 0x64c2d8: add             SP, SP, #8
    // 0x64c2dc: stur            x0, [fp, #-0x68]
    // 0x64c2e0: LoadField: r1 = r0->field_b
    //     0x64c2e0: ldur            w1, [x0, #0xb]
    // 0x64c2e4: DecompressPointer r1
    //     0x64c2e4: add             x1, x1, HEAP, lsl #32
    // 0x64c2e8: LoadField: r2 = r1->field_7
    //     0x64c2e8: ldur            x2, [x1, #7]
    // 0x64c2ec: ldur            x3, [fp, #-0x18]
    // 0x64c2f0: add             x4, x3, x2
    // 0x64c2f4: stur            x4, [fp, #-0x60]
    // 0x64c2f8: LoadField: r2 = r1->field_f
    //     0x64c2f8: ldur            x2, [x1, #0xf]
    // 0x64c2fc: add             x1, x3, x2
    // 0x64c300: stur            x1, [fp, #-0x20]
    // 0x64c304: r0 = TextRange()
    //     0x64c304: bl              #0x51026c  ; AllocateTextRangeStub -> TextRange (size=0x18)
    // 0x64c308: mov             x1, x0
    // 0x64c30c: ldur            x0, [fp, #-0x60]
    // 0x64c310: StoreField: r1->field_7 = r0
    //     0x64c310: stur            x0, [x1, #7]
    // 0x64c314: ldur            x0, [fp, #-0x20]
    // 0x64c318: StoreField: r1->field_f = r0
    //     0x64c318: stur            x0, [x1, #0xf]
    // 0x64c31c: ldur            x0, [fp, #-0x68]
    // 0x64c320: r2 = LoadClassIdInstr(r0)
    //     0x64c320: ldur            x2, [x0, #-1]
    //     0x64c324: ubfx            x2, x2, #0xc, #0x14
    // 0x64c328: stp             x1, x0, [SP, #-0x10]!
    // 0x64c32c: mov             x0, x2
    // 0x64c330: r0 = GDT[cid_x0 + -0xff3]()
    //     0x64c330: sub             lr, x0, #0xff3
    //     0x64c334: ldr             lr, [x21, lr, lsl #3]
    //     0x64c338: blr             lr
    // 0x64c33c: add             SP, SP, #0x10
    // 0x64c340: mov             x1, x0
    // 0x64c344: ldur            x0, [fp, #-0x40]
    // 0x64c348: stur            x1, [fp, #-0x70]
    // 0x64c34c: LoadField: r2 = r0->field_b
    //     0x64c34c: ldur            w2, [x0, #0xb]
    // 0x64c350: DecompressPointer r2
    //     0x64c350: add             x2, x2, HEAP, lsl #32
    // 0x64c354: stur            x2, [fp, #-0x68]
    // 0x64c358: LoadField: r3 = r0->field_f
    //     0x64c358: ldur            w3, [x0, #0xf]
    // 0x64c35c: DecompressPointer r3
    //     0x64c35c: add             x3, x3, HEAP, lsl #32
    // 0x64c360: LoadField: r4 = r3->field_b
    //     0x64c360: ldur            w4, [x3, #0xb]
    // 0x64c364: DecompressPointer r4
    //     0x64c364: add             x4, x4, HEAP, lsl #32
    // 0x64c368: cmp             w2, w4
    // 0x64c36c: b.ne            #0x64c37c
    // 0x64c370: SaveReg r0
    //     0x64c370: str             x0, [SP, #-8]!
    // 0x64c374: r0 = _growToNextCapacity()
    //     0x64c374: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x64c378: add             SP, SP, #8
    // 0x64c37c: ldur            x2, [fp, #-0x40]
    // 0x64c380: ldur            x0, [fp, #-0x68]
    // 0x64c384: r3 = LoadInt32Instr(r0)
    //     0x64c384: sbfx            x3, x0, #1, #0x1f
    // 0x64c388: add             x0, x3, #1
    // 0x64c38c: lsl             x1, x0, #1
    // 0x64c390: StoreField: r2->field_b = r1
    //     0x64c390: stur            w1, [x2, #0xb]
    // 0x64c394: mov             x1, x3
    // 0x64c398: cmp             x1, x0
    // 0x64c39c: b.hs            #0x64c8c4
    // 0x64c3a0: LoadField: r1 = r2->field_f
    //     0x64c3a0: ldur            w1, [x2, #0xf]
    // 0x64c3a4: DecompressPointer r1
    //     0x64c3a4: add             x1, x1, HEAP, lsl #32
    // 0x64c3a8: ldur            x0, [fp, #-0x70]
    // 0x64c3ac: ArrayStore: r1[r3] = r0  ; List_4
    //     0x64c3ac: add             x25, x1, x3, lsl #2
    //     0x64c3b0: add             x25, x25, #0xf
    //     0x64c3b4: str             w0, [x25]
    //     0x64c3b8: tbz             w0, #0, #0x64c3d4
    //     0x64c3bc: ldurb           w16, [x1, #-1]
    //     0x64c3c0: ldurb           w17, [x0, #-1]
    //     0x64c3c4: and             x16, x17, x16, lsr #2
    //     0x64c3c8: tst             x16, HEAP, lsr #32
    //     0x64c3cc: b.eq            #0x64c3d4
    //     0x64c3d0: bl              #0xd67e5c
    // 0x64c3d4: ldur            x1, [fp, #-0x48]
    // 0x64c3d8: b               #0x64c284
    // 0x64c3dc: ldur            x2, [fp, #-0x40]
    // 0x64c3e0: ldur            x16, [fp, #-0x58]
    // 0x64c3e4: SaveReg r16
    //     0x64c3e4: str             x16, [SP, #-8]!
    // 0x64c3e8: r0 = _interpolateSingle()
    //     0x64c3e8: bl              #0x4bdd98  ; [dart:core] _StringBase::_interpolateSingle
    // 0x64c3ec: add             SP, SP, #8
    // 0x64c3f0: stur            x0, [fp, #-0x48]
    // 0x64c3f4: LoadField: r1 = r0->field_7
    //     0x64c3f4: ldur            w1, [x0, #7]
    // 0x64c3f8: DecompressPointer r1
    //     0x64c3f8: add             x1, x1, HEAP, lsl #32
    // 0x64c3fc: cbz             w1, #0x64c424
    // 0x64c400: ldur            x16, [fp, #-0x10]
    // 0x64c404: SaveReg r16
    //     0x64c404: str             x16, [SP, #-8]!
    // 0x64c408: r0 = _consumeBuffer()
    //     0x64c408: bl              #0x4d1cf0  ; [dart:core] StringBuffer::_consumeBuffer
    // 0x64c40c: add             SP, SP, #8
    // 0x64c410: ldur            x16, [fp, #-0x10]
    // 0x64c414: ldur            lr, [fp, #-0x48]
    // 0x64c418: stp             lr, x16, [SP, #-0x10]!
    // 0x64c41c: r0 = _addPart()
    //     0x64c41c: bl              #0x4d18b0  ; [dart:core] StringBuffer::_addPart
    // 0x64c420: add             SP, SP, #0x10
    // 0x64c424: ldur            x0, [fp, #-0x18]
    // 0x64c428: ldur            x1, [fp, #-0x58]
    // 0x64c42c: LoadField: r2 = r1->field_7
    //     0x64c42c: ldur            w2, [x1, #7]
    // 0x64c430: DecompressPointer r2
    //     0x64c430: add             x2, x2, HEAP, lsl #32
    // 0x64c434: r1 = LoadInt32Instr(r2)
    //     0x64c434: sbfx            x1, x2, #1, #0x1f
    // 0x64c438: add             x7, x0, x1
    // 0x64c43c: ldur            x6, [fp, #-0x50]
    // 0x64c440: ldr             x1, [fp, #0x18]
    // 0x64c444: ldur            x2, [fp, #-0x40]
    // 0x64c448: ldur            x3, [fp, #-0x38]
    // 0x64c44c: ldur            x4, [fp, #-0x30]
    // 0x64c450: ldur            x5, [fp, #-0x28]
    // 0x64c454: b               #0x64c0e4
    // 0x64c458: mov             x0, x3
    // 0x64c45c: ldr             x1, [fp, #0x18]
    // 0x64c460: ldr             x3, [fp, #0x10]
    // 0x64c464: ldur            x4, [fp, #-8]
    // 0x64c468: r2 = true
    //     0x64c468: add             x2, NULL, #0x20  ; true
    // 0x64c46c: StoreField: r3->field_4b = r0
    //     0x64c46c: stur            w0, [x3, #0x4b]
    //     0x64c470: ldurb           w16, [x3, #-1]
    //     0x64c474: ldurb           w17, [x0, #-1]
    //     0x64c478: and             x16, x17, x16, lsr #2
    //     0x64c47c: tst             x16, HEAP, lsr #32
    //     0x64c480: b.eq            #0x64c488
    //     0x64c484: bl              #0xd682ac
    // 0x64c488: StoreField: r3->field_13 = r2
    //     0x64c488: stur            w2, [x3, #0x13]
    // 0x64c48c: r16 = Instance_SemanticsFlag
    //     0x64c48c: add             x16, PP, #0x50, lsl #12  ; [pp+0x501c8] Obj!SemanticsFlag@b5cbb1
    //     0x64c490: ldr             x16, [x16, #0x1c8]
    // 0x64c494: stp             x16, x3, [SP, #-0x10]!
    // 0x64c498: r16 = false
    //     0x64c498: add             x16, NULL, #0x30  ; false
    // 0x64c49c: SaveReg r16
    //     0x64c49c: str             x16, [SP, #-8]!
    // 0x64c4a0: r0 = _setFlag()
    //     0x64c4a0: bl              #0x646790  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_setFlag
    // 0x64c4a4: add             SP, SP, #0x18
    // 0x64c4a8: ldr             x0, [fp, #0x18]
    // 0x64c4ac: r17 = 259
    //     0x64c4ac: mov             x17, #0x103
    // 0x64c4b0: ldr             w1, [x0, x17]
    // 0x64c4b4: DecompressPointer r1
    //     0x64c4b4: add             x1, x1, HEAP, lsl #32
    // 0x64c4b8: cmp             w1, #2
    // 0x64c4bc: r16 = true
    //     0x64c4bc: add             x16, NULL, #0x20  ; true
    // 0x64c4c0: r17 = false
    //     0x64c4c0: add             x17, NULL, #0x30  ; false
    // 0x64c4c4: csel            x2, x16, x17, ne
    // 0x64c4c8: ldr             x16, [fp, #0x10]
    // 0x64c4cc: r30 = Instance_SemanticsFlag
    //     0x64c4cc: add             lr, PP, #0x50, lsl #12  ; [pp+0x501c0] Obj!SemanticsFlag@b5cba1
    //     0x64c4d0: ldr             lr, [lr, #0x1c0]
    // 0x64c4d4: stp             lr, x16, [SP, #-0x10]!
    // 0x64c4d8: SaveReg r2
    //     0x64c4d8: str             x2, [SP, #-8]!
    // 0x64c4dc: r0 = _setFlag()
    //     0x64c4dc: bl              #0x646790  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_setFlag
    // 0x64c4e0: add             SP, SP, #0x18
    // 0x64c4e4: ldur            x1, [fp, #-8]
    // 0x64c4e8: LoadField: r0 = r1->field_1b
    //     0x64c4e8: ldur            w0, [x1, #0x1b]
    // 0x64c4ec: DecompressPointer r0
    //     0x64c4ec: add             x0, x0, HEAP, lsl #32
    // 0x64c4f0: cmp             w0, NULL
    // 0x64c4f4: b.eq            #0x64c8c8
    // 0x64c4f8: ldr             x2, [fp, #0x10]
    // 0x64c4fc: StoreField: r2->field_73 = r0
    //     0x64c4fc: stur            w0, [x2, #0x73]
    //     0x64c500: ldurb           w16, [x2, #-1]
    //     0x64c504: ldurb           w17, [x0, #-1]
    //     0x64c508: and             x16, x17, x16, lsr #2
    //     0x64c50c: tst             x16, HEAP, lsr #32
    //     0x64c510: b.eq            #0x64c518
    //     0x64c514: bl              #0xd6828c
    // 0x64c518: r0 = true
    //     0x64c518: add             x0, NULL, #0x20  ; true
    // 0x64c51c: StoreField: r2->field_13 = r0
    //     0x64c51c: stur            w0, [x2, #0x13]
    // 0x64c520: ldr             x16, [fp, #0x18]
    // 0x64c524: SaveReg r16
    //     0x64c524: str             x16, [SP, #-8]!
    // 0x64c528: r0 = barrierDismissible()
    //     0x64c528: bl              #0xd0b788  ; [package:wechat_camera_picker/src/widgets/camera_picker_page_route.dart] CameraPickerPageRoute::barrierDismissible
    // 0x64c52c: add             SP, SP, #8
    // 0x64c530: ldr             x16, [fp, #0x10]
    // 0x64c534: r30 = Instance_SemanticsFlag
    //     0x64c534: add             lr, PP, #0x21, lsl #12  ; [pp+0x21bf8] Obj!SemanticsFlag@b5cb91
    //     0x64c538: ldr             lr, [lr, #0xbf8]
    // 0x64c53c: stp             lr, x16, [SP, #-0x10]!
    // 0x64c540: SaveReg r0
    //     0x64c540: str             x0, [SP, #-8]!
    // 0x64c544: r0 = _setFlag()
    //     0x64c544: bl              #0x646790  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_setFlag
    // 0x64c548: add             SP, SP, #0x18
    // 0x64c54c: ldr             x16, [fp, #0x10]
    // 0x64c550: r30 = Instance_SemanticsFlag
    //     0x64c550: add             lr, PP, #0x50, lsl #12  ; [pp+0x501b8] Obj!SemanticsFlag@b5cb81
    //     0x64c554: ldr             lr, [lr, #0x1b8]
    // 0x64c558: stp             lr, x16, [SP, #-0x10]!
    // 0x64c55c: r16 = true
    //     0x64c55c: add             x16, NULL, #0x20  ; true
    // 0x64c560: SaveReg r16
    //     0x64c560: str             x16, [SP, #-8]!
    // 0x64c564: r0 = _setFlag()
    //     0x64c564: bl              #0x646790  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_setFlag
    // 0x64c568: add             SP, SP, #0x18
    // 0x64c56c: ldr             x0, [fp, #0x18]
    // 0x64c570: LoadField: r1 = r0->field_ff
    //     0x64c570: ldur            w1, [x0, #0xff]
    // 0x64c574: DecompressPointer r1
    //     0x64c574: add             x1, x1, HEAP, lsl #32
    // 0x64c578: ldr             x16, [fp, #0x10]
    // 0x64c57c: r30 = Instance_SemanticsFlag
    //     0x64c57c: add             lr, PP, #0x50, lsl #12  ; [pp+0x501b0] Obj!SemanticsFlag@b5cb71
    //     0x64c580: ldr             lr, [lr, #0x1b0]
    // 0x64c584: stp             lr, x16, [SP, #-0x10]!
    // 0x64c588: SaveReg r1
    //     0x64c588: str             x1, [SP, #-8]!
    // 0x64c58c: r0 = _setFlag()
    //     0x64c58c: bl              #0x646790  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_setFlag
    // 0x64c590: add             SP, SP, #0x18
    // 0x64c594: ldr             x16, [fp, #0x18]
    // 0x64c598: SaveReg r16
    //     0x64c598: str             x16, [SP, #-8]!
    // 0x64c59c: r0 = barrierDismissible()
    //     0x64c59c: bl              #0xd0b788  ; [package:wechat_camera_picker/src/widgets/camera_picker_page_route.dart] CameraPickerPageRoute::barrierDismissible
    // 0x64c5a0: add             SP, SP, #8
    // 0x64c5a4: tbnz            w0, #4, #0x64c610
    // 0x64c5a8: ldr             x16, [fp, #0x18]
    // 0x64c5ac: SaveReg r16
    //     0x64c5ac: str             x16, [SP, #-8]!
    // 0x64c5b0: r0 = selectionEnabled()
    //     0x64c5b0: bl              #0x64ce40  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::selectionEnabled
    // 0x64c5b4: add             SP, SP, #8
    // 0x64c5b8: tbnz            w0, #4, #0x64c610
    // 0x64c5bc: ldr             x16, [fp, #0x18]
    // 0x64c5c0: SaveReg r16
    //     0x64c5c0: str             x16, [SP, #-8]!
    // 0x64c5c4: r0 = handleSetSelection()
    //     0x64c5c4: bl              #0xcf06d8  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::handleSetSelection
    // 0x64c5c8: add             SP, SP, #8
    // 0x64c5cc: stur            x0, [fp, #-0x10]
    // 0x64c5d0: r1 = 1
    //     0x64c5d0: mov             x1, #1
    // 0x64c5d4: r0 = AllocateContext()
    //     0x64c5d4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x64c5d8: mov             x1, x0
    // 0x64c5dc: ldur            x0, [fp, #-0x10]
    // 0x64c5e0: StoreField: r1->field_f = r0
    //     0x64c5e0: stur            w0, [x1, #0xf]
    // 0x64c5e4: mov             x2, x1
    // 0x64c5e8: r1 = Function '<anonymous closure>':.
    //     0x64c5e8: add             x1, PP, #0x50, lsl #12  ; [pp+0x50180] AnonymousClosure: (0x64d308), in [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onSetSelection= (0x64cae8)
    //     0x64c5ec: ldr             x1, [x1, #0x180]
    // 0x64c5f0: r0 = AllocateClosure()
    //     0x64c5f0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x64c5f4: ldr             x16, [fp, #0x10]
    // 0x64c5f8: r30 = Instance_SemanticsAction
    //     0x64c5f8: add             lr, PP, #0x50, lsl #12  ; [pp+0x50188] Obj!SemanticsAction@b5cd51
    //     0x64c5fc: ldr             lr, [lr, #0x188]
    // 0x64c600: stp             lr, x16, [SP, #-0x10]!
    // 0x64c604: SaveReg r0
    //     0x64c604: str             x0, [SP, #-8]!
    // 0x64c608: r0 = _addAction()
    //     0x64c608: bl              #0x646848  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addAction
    // 0x64c60c: add             SP, SP, #0x18
    // 0x64c610: ldr             x16, [fp, #0x18]
    // 0x64c614: SaveReg r16
    //     0x64c614: str             x16, [SP, #-8]!
    // 0x64c618: r0 = barrierDismissible()
    //     0x64c618: bl              #0xd0b788  ; [package:wechat_camera_picker/src/widgets/camera_picker_page_route.dart] CameraPickerPageRoute::barrierDismissible
    // 0x64c61c: add             SP, SP, #8
    // 0x64c620: tbnz            w0, #4, #0x64c684
    // 0x64c624: ldr             x0, [fp, #0x18]
    // 0x64c628: LoadField: r1 = r0->field_ff
    //     0x64c628: ldur            w1, [x0, #0xff]
    // 0x64c62c: DecompressPointer r1
    //     0x64c62c: add             x1, x1, HEAP, lsl #32
    // 0x64c630: tbz             w1, #4, #0x64c684
    // 0x64c634: SaveReg r0
    //     0x64c634: str             x0, [SP, #-8]!
    // 0x64c638: r0 = _handleSetText()
    //     0x64c638: bl              #0xcf0480  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_handleSetText
    // 0x64c63c: add             SP, SP, #8
    // 0x64c640: stur            x0, [fp, #-0x10]
    // 0x64c644: r1 = 1
    //     0x64c644: mov             x1, #1
    // 0x64c648: r0 = AllocateContext()
    //     0x64c648: bl              #0xd68aa4  ; AllocateContextStub
    // 0x64c64c: mov             x1, x0
    // 0x64c650: ldur            x0, [fp, #-0x10]
    // 0x64c654: StoreField: r1->field_f = r0
    //     0x64c654: stur            w0, [x1, #0xf]
    // 0x64c658: mov             x2, x1
    // 0x64c65c: r1 = Function '<anonymous closure>':.
    //     0x64c65c: add             x1, PP, #0x50, lsl #12  ; [pp+0x50158] AnonymousClosure: (0x64d24c), in [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onSetText= (0x64ca7c)
    //     0x64c660: ldr             x1, [x1, #0x158]
    // 0x64c664: r0 = AllocateClosure()
    //     0x64c664: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x64c668: ldr             x16, [fp, #0x10]
    // 0x64c66c: r30 = Instance_SemanticsAction
    //     0x64c66c: add             lr, PP, #0x50, lsl #12  ; [pp+0x50160] Obj!SemanticsAction@b5ccb1
    //     0x64c670: ldr             lr, [lr, #0x160]
    // 0x64c674: stp             lr, x16, [SP, #-0x10]!
    // 0x64c678: SaveReg r0
    //     0x64c678: str             x0, [SP, #-8]!
    // 0x64c67c: r0 = _addAction()
    //     0x64c67c: bl              #0x646848  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addAction
    // 0x64c680: add             SP, SP, #0x18
    // 0x64c684: ldr             x16, [fp, #0x18]
    // 0x64c688: SaveReg r16
    //     0x64c688: str             x16, [SP, #-8]!
    // 0x64c68c: r0 = selectionEnabled()
    //     0x64c68c: bl              #0x64ce40  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::selectionEnabled
    // 0x64c690: add             SP, SP, #8
    // 0x64c694: tbnz            w0, #4, #0x64c87c
    // 0x64c698: ldr             x1, [fp, #0x18]
    // 0x64c69c: r17 = 271
    //     0x64c69c: mov             x17, #0x10f
    // 0x64c6a0: ldr             w2, [x1, x17]
    // 0x64c6a4: DecompressPointer r2
    //     0x64c6a4: add             x2, x2, HEAP, lsl #32
    // 0x64c6a8: LoadField: r0 = r2->field_7
    //     0x64c6a8: ldur            x0, [x2, #7]
    // 0x64c6ac: tbnz            x0, #0x3f, #0x64c87c
    // 0x64c6b0: LoadField: r0 = r2->field_f
    //     0x64c6b0: ldur            x0, [x2, #0xf]
    // 0x64c6b4: tbnz            x0, #0x3f, #0x64c87c
    // 0x64c6b8: ldr             x3, [fp, #0x10]
    // 0x64c6bc: r4 = true
    //     0x64c6bc: add             x4, NULL, #0x20  ; true
    // 0x64c6c0: mov             x0, x2
    // 0x64c6c4: StoreField: r3->field_77 = r0
    //     0x64c6c4: stur            w0, [x3, #0x77]
    //     0x64c6c8: ldurb           w16, [x3, #-1]
    //     0x64c6cc: ldurb           w17, [x0, #-1]
    //     0x64c6d0: and             x16, x17, x16, lsr #2
    //     0x64c6d4: tst             x16, HEAP, lsr #32
    //     0x64c6d8: b.eq            #0x64c6e0
    //     0x64c6dc: bl              #0xd682ac
    // 0x64c6e0: StoreField: r3->field_13 = r4
    //     0x64c6e0: stur            w4, [x3, #0x13]
    // 0x64c6e4: LoadField: r0 = r2->field_1f
    //     0x64c6e4: ldur            x0, [x2, #0x1f]
    // 0x64c6e8: ldur            x16, [fp, #-8]
    // 0x64c6ec: stp             x0, x16, [SP, #-0x10]!
    // 0x64c6f0: r0 = getOffsetBefore()
    //     0x64c6f0: bl              #0x64cd88  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getOffsetBefore
    // 0x64c6f4: add             SP, SP, #0x10
    // 0x64c6f8: cmp             w0, NULL
    // 0x64c6fc: b.eq            #0x64c7a8
    // 0x64c700: ldr             x16, [fp, #0x18]
    // 0x64c704: SaveReg r16
    //     0x64c704: str             x16, [SP, #-8]!
    // 0x64c708: r0 = _handleMoveCursorBackwardByWord()
    //     0x64c708: bl              #0xcefe0c  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_handleMoveCursorBackwardByWord
    // 0x64c70c: add             SP, SP, #8
    // 0x64c710: stur            x0, [fp, #-0x10]
    // 0x64c714: r1 = 1
    //     0x64c714: mov             x1, #1
    // 0x64c718: r0 = AllocateContext()
    //     0x64c718: bl              #0xd68aa4  ; AllocateContextStub
    // 0x64c71c: mov             x1, x0
    // 0x64c720: ldur            x0, [fp, #-0x10]
    // 0x64c724: StoreField: r1->field_f = r0
    //     0x64c724: stur            w0, [x1, #0xf]
    // 0x64c728: mov             x2, x1
    // 0x64c72c: r1 = Function '<anonymous closure>':.
    //     0x64c72c: add             x1, PP, #0x50, lsl #12  ; [pp+0x50130] AnonymousClosure: (0x64d194), in [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onMoveCursorBackwardByWord= (0x64ca10)
    //     0x64c730: ldr             x1, [x1, #0x130]
    // 0x64c734: r0 = AllocateClosure()
    //     0x64c734: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x64c738: ldr             x16, [fp, #0x10]
    // 0x64c73c: r30 = Instance_SemanticsAction
    //     0x64c73c: add             lr, PP, #0x50, lsl #12  ; [pp+0x50138] Obj!SemanticsAction@b5ccc1
    //     0x64c740: ldr             lr, [lr, #0x138]
    // 0x64c744: stp             lr, x16, [SP, #-0x10]!
    // 0x64c748: SaveReg r0
    //     0x64c748: str             x0, [SP, #-8]!
    // 0x64c74c: r0 = _addAction()
    //     0x64c74c: bl              #0x646848  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addAction
    // 0x64c750: add             SP, SP, #0x18
    // 0x64c754: ldr             x16, [fp, #0x18]
    // 0x64c758: SaveReg r16
    //     0x64c758: str             x16, [SP, #-8]!
    // 0x64c75c: r0 = _handleMoveCursorBackwardByCharacter()
    //     0x64c75c: bl              #0xcf0158  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_handleMoveCursorBackwardByCharacter
    // 0x64c760: add             SP, SP, #8
    // 0x64c764: stur            x0, [fp, #-0x10]
    // 0x64c768: r1 = 1
    //     0x64c768: mov             x1, #1
    // 0x64c76c: r0 = AllocateContext()
    //     0x64c76c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x64c770: mov             x1, x0
    // 0x64c774: ldur            x0, [fp, #-0x10]
    // 0x64c778: StoreField: r1->field_f = r0
    //     0x64c778: stur            w0, [x1, #0xf]
    // 0x64c77c: mov             x2, x1
    // 0x64c780: r1 = Function '<anonymous closure>':.
    //     0x64c780: add             x1, PP, #0x50, lsl #12  ; [pp+0x50108] AnonymousClosure: (0x64d0dc), in [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onMoveCursorBackwardByCharacter= (0x64c9a4)
    //     0x64c784: ldr             x1, [x1, #0x108]
    // 0x64c788: r0 = AllocateClosure()
    //     0x64c788: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x64c78c: ldr             x16, [fp, #0x10]
    // 0x64c790: r30 = Instance_SemanticsAction
    //     0x64c790: add             lr, PP, #0x50, lsl #12  ; [pp+0x50110] Obj!SemanticsAction@b5cd61
    //     0x64c794: ldr             lr, [lr, #0x110]
    // 0x64c798: stp             lr, x16, [SP, #-0x10]!
    // 0x64c79c: SaveReg r0
    //     0x64c79c: str             x0, [SP, #-8]!
    // 0x64c7a0: r0 = _addAction()
    //     0x64c7a0: bl              #0x646848  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addAction
    // 0x64c7a4: add             SP, SP, #0x18
    // 0x64c7a8: ldr             x0, [fp, #0x18]
    // 0x64c7ac: r17 = 271
    //     0x64c7ac: mov             x17, #0x10f
    // 0x64c7b0: ldr             w1, [x0, x17]
    // 0x64c7b4: DecompressPointer r1
    //     0x64c7b4: add             x1, x1, HEAP, lsl #32
    // 0x64c7b8: LoadField: r2 = r1->field_1f
    //     0x64c7b8: ldur            x2, [x1, #0x1f]
    // 0x64c7bc: ldur            x16, [fp, #-8]
    // 0x64c7c0: stp             x2, x16, [SP, #-0x10]!
    // 0x64c7c4: r0 = getOffsetAfter()
    //     0x64c7c4: bl              #0x64ccd0  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getOffsetAfter
    // 0x64c7c8: add             SP, SP, #0x10
    // 0x64c7cc: cmp             w0, NULL
    // 0x64c7d0: b.eq            #0x64c87c
    // 0x64c7d4: ldr             x16, [fp, #0x18]
    // 0x64c7d8: SaveReg r16
    //     0x64c7d8: str             x16, [SP, #-8]!
    // 0x64c7dc: r0 = _handleMoveCursorForwardByWord()
    //     0x64c7dc: bl              #0xceffb4  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_handleMoveCursorForwardByWord
    // 0x64c7e0: add             SP, SP, #8
    // 0x64c7e4: stur            x0, [fp, #-8]
    // 0x64c7e8: r1 = 1
    //     0x64c7e8: mov             x1, #1
    // 0x64c7ec: r0 = AllocateContext()
    //     0x64c7ec: bl              #0xd68aa4  ; AllocateContextStub
    // 0x64c7f0: mov             x1, x0
    // 0x64c7f4: ldur            x0, [fp, #-8]
    // 0x64c7f8: StoreField: r1->field_f = r0
    //     0x64c7f8: stur            w0, [x1, #0xf]
    // 0x64c7fc: mov             x2, x1
    // 0x64c800: r1 = Function '<anonymous closure>':.
    //     0x64c800: add             x1, PP, #0x50, lsl #12  ; [pp+0x500e0] AnonymousClosure: (0x64d024), in [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onMoveCursorForwardByWord= (0x64c938)
    //     0x64c804: ldr             x1, [x1, #0xe0]
    // 0x64c808: r0 = AllocateClosure()
    //     0x64c808: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x64c80c: ldr             x16, [fp, #0x10]
    // 0x64c810: r30 = Instance_SemanticsAction
    //     0x64c810: add             lr, PP, #0x50, lsl #12  ; [pp+0x500e8] Obj!SemanticsAction@b5ccd1
    //     0x64c814: ldr             lr, [lr, #0xe8]
    // 0x64c818: stp             lr, x16, [SP, #-0x10]!
    // 0x64c81c: SaveReg r0
    //     0x64c81c: str             x0, [SP, #-8]!
    // 0x64c820: r0 = _addAction()
    //     0x64c820: bl              #0x646848  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addAction
    // 0x64c824: add             SP, SP, #0x18
    // 0x64c828: ldr             x16, [fp, #0x18]
    // 0x64c82c: SaveReg r16
    //     0x64c82c: str             x16, [SP, #-8]!
    // 0x64c830: r0 = _handleMoveCursorForwardByCharacter()
    //     0x64c830: bl              #0xcf02ec  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_handleMoveCursorForwardByCharacter
    // 0x64c834: add             SP, SP, #8
    // 0x64c838: stur            x0, [fp, #-8]
    // 0x64c83c: r1 = 1
    //     0x64c83c: mov             x1, #1
    // 0x64c840: r0 = AllocateContext()
    //     0x64c840: bl              #0xd68aa4  ; AllocateContextStub
    // 0x64c844: mov             x1, x0
    // 0x64c848: ldur            x0, [fp, #-8]
    // 0x64c84c: StoreField: r1->field_f = r0
    //     0x64c84c: stur            w0, [x1, #0xf]
    // 0x64c850: mov             x2, x1
    // 0x64c854: r1 = Function '<anonymous closure>':.
    //     0x64c854: add             x1, PP, #0x50, lsl #12  ; [pp+0x500b8] AnonymousClosure: (0x64cf6c), in [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onMoveCursorForwardByCharacter= (0x64c8cc)
    //     0x64c858: ldr             x1, [x1, #0xb8]
    // 0x64c85c: r0 = AllocateClosure()
    //     0x64c85c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x64c860: ldr             x16, [fp, #0x10]
    // 0x64c864: r30 = Instance_SemanticsAction
    //     0x64c864: add             lr, PP, #0x50, lsl #12  ; [pp+0x500c0] Obj!SemanticsAction@b5cd71
    //     0x64c868: ldr             lr, [lr, #0xc0]
    // 0x64c86c: stp             lr, x16, [SP, #-0x10]!
    // 0x64c870: SaveReg r0
    //     0x64c870: str             x0, [SP, #-8]!
    // 0x64c874: r0 = _addAction()
    //     0x64c874: bl              #0x646848  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addAction
    // 0x64c878: add             SP, SP, #0x18
    // 0x64c87c: r0 = Null
    //     0x64c87c: mov             x0, NULL
    // 0x64c880: LeaveFrame
    //     0x64c880: mov             SP, fp
    //     0x64c884: ldp             fp, lr, [SP], #0x10
    // 0x64c888: ret
    //     0x64c888: ret             
    // 0x64c88c: ldur            x0, [fp, #-0x38]
    // 0x64c890: r0 = ConcurrentModificationError()
    //     0x64c890: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x64c894: ldur            x3, [fp, #-0x38]
    // 0x64c898: StoreField: r0->field_b = r3
    //     0x64c898: stur            w3, [x0, #0xb]
    // 0x64c89c: r0 = Throw()
    //     0x64c89c: bl              #0xd67e38  ; ThrowStub
    // 0x64c8a0: brk             #0
    // 0x64c8a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64c8a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64c8a8: b               #0x64bf8c
    // 0x64c8ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x64c8ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x64c8b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x64c8b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x64c8b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64c8b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64c8b8: b               #0x64c0f8
    // 0x64c8bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64c8bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64c8c0: b               #0x64c294
    // 0x64c8c4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x64c8c4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x64c8c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x64c8c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ selectionEnabled(/* No info */) {
    // ** addr: 0x64ce40, size: 0x14
    // 0x64ce40: ldr             x1, [SP]
    // 0x64ce44: r17 = 311
    //     0x64ce44: mov             x17, #0x137
    // 0x64ce48: ldr             w0, [x1, x17]
    // 0x64ce4c: DecompressPointer r0
    //     0x64ce4c: add             x0, x0, HEAP, lsl #32
    // 0x64ce50: ret
    //     0x64ce50: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x652704, size: 0xe0
    // 0x652704: EnterFrame
    //     0x652704: stp             fp, lr, [SP, #-0x10]!
    //     0x652708: mov             fp, SP
    // 0x65270c: CheckStackOverflow
    //     0x65270c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x652710: cmp             SP, x16
    //     0x652714: b.ls            #0x6527dc
    // 0x652718: ldr             x0, [fp, #0x10]
    // 0x65271c: LoadField: r1 = r0->field_9b
    //     0x65271c: ldur            w1, [x0, #0x9b]
    // 0x652720: DecompressPointer r1
    //     0x652720: add             x1, x1, HEAP, lsl #32
    // 0x652724: cmp             w1, NULL
    // 0x652728: b.eq            #0x65273c
    // 0x65272c: SaveReg r1
    //     0x65272c: str             x1, [SP, #-8]!
    // 0x652730: r0 = dispose()
    //     0x652730: bl              #0x65378c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0x652734: add             SP, SP, #8
    // 0x652738: ldr             x0, [fp, #0x10]
    // 0x65273c: StoreField: r0->field_9b = rNULL
    //     0x65273c: stur            NULL, [x0, #0x9b]
    // 0x652740: LoadField: r1 = r0->field_9f
    //     0x652740: ldur            w1, [x0, #0x9f]
    // 0x652744: DecompressPointer r1
    //     0x652744: add             x1, x1, HEAP, lsl #32
    // 0x652748: cmp             w1, NULL
    // 0x65274c: b.eq            #0x652760
    // 0x652750: SaveReg r1
    //     0x652750: str             x1, [SP, #-8]!
    // 0x652754: r0 = dispose()
    //     0x652754: bl              #0x65378c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0x652758: add             SP, SP, #8
    // 0x65275c: ldr             x0, [fp, #0x10]
    // 0x652760: StoreField: r0->field_9f = rNULL
    //     0x652760: stur            NULL, [x0, #0x9f]
    // 0x652764: r17 = 375
    //     0x652764: mov             x17, #0x177
    // 0x652768: ldr             w1, [x0, x17]
    // 0x65276c: DecompressPointer r1
    //     0x65276c: add             x1, x1, HEAP, lsl #32
    // 0x652770: stp             NULL, x1, [SP, #-0x10]!
    // 0x652774: r0 = layer=()
    //     0x652774: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x652778: add             SP, SP, #0x10
    // 0x65277c: ldr             x0, [fp, #0x10]
    // 0x652780: LoadField: r1 = r0->field_b7
    //     0x652780: ldur            w1, [x0, #0xb7]
    // 0x652784: DecompressPointer r1
    //     0x652784: add             x1, x1, HEAP, lsl #32
    // 0x652788: cmp             w1, NULL
    // 0x65278c: b.eq            #0x6527a0
    // 0x652790: SaveReg r1
    //     0x652790: str             x1, [SP, #-8]!
    // 0x652794: r0 = dispose()
    //     0x652794: bl              #0xa6b240  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::dispose
    // 0x652798: add             SP, SP, #8
    // 0x65279c: ldr             x0, [fp, #0x10]
    // 0x6527a0: LoadField: r1 = r0->field_bb
    //     0x6527a0: ldur            w1, [x0, #0xbb]
    // 0x6527a4: DecompressPointer r1
    //     0x6527a4: add             x1, x1, HEAP, lsl #32
    // 0x6527a8: cmp             w1, NULL
    // 0x6527ac: b.eq            #0x6527bc
    // 0x6527b0: SaveReg r1
    //     0x6527b0: str             x1, [SP, #-8]!
    // 0x6527b4: r0 = dispose()
    //     0x6527b4: bl              #0xa6b240  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::dispose
    // 0x6527b8: add             SP, SP, #8
    // 0x6527bc: ldr             x16, [fp, #0x10]
    // 0x6527c0: SaveReg r16
    //     0x6527c0: str             x16, [SP, #-8]!
    // 0x6527c4: r0 = dispose()
    //     0x6527c4: bl              #0x65378c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0x6527c8: add             SP, SP, #8
    // 0x6527cc: r0 = Null
    //     0x6527cc: mov             x0, NULL
    // 0x6527d0: LeaveFrame
    //     0x6527d0: mov             SP, fp
    //     0x6527d4: ldp             fp, lr, [SP], #0x10
    // 0x6527d8: ret
    //     0x6527d8: ret             
    // 0x6527dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6527dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6527e0: b               #0x652718
  }
  _ paint(/* No info */) {
    // ** addr: 0x65c0c4, size: 0x1b0
    // 0x65c0c4: EnterFrame
    //     0x65c0c4: stp             fp, lr, [SP, #-0x10]!
    //     0x65c0c8: mov             fp, SP
    // 0x65c0cc: AllocStack(0x18)
    //     0x65c0cc: sub             SP, SP, #0x18
    // 0x65c0d0: CheckStackOverflow
    //     0x65c0d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65c0d4: cmp             SP, x16
    //     0x65c0d8: b.ls            #0x65c260
    // 0x65c0dc: ldr             x0, [fp, #0x10]
    // 0x65c0e0: ldr             x1, [fp, #0x20]
    // 0x65c0e4: r17 = 371
    //     0x65c0e4: mov             x17, #0x173
    // 0x65c0e8: str             w0, [x1, x17]
    // 0x65c0ec: WriteBarrierInstr(obj = r1, val = r0)
    //     0x65c0ec: ldurb           w16, [x1, #-1]
    //     0x65c0f0: ldurb           w17, [x0, #-1]
    //     0x65c0f4: and             x16, x17, x16, lsr #2
    //     0x65c0f8: tst             x16, HEAP, lsr #32
    //     0x65c0fc: b.eq            #0x65c104
    //     0x65c100: bl              #0xd6826c
    // 0x65c104: SaveReg r1
    //     0x65c104: str             x1, [SP, #-8]!
    // 0x65c108: r0 = computeTextMetricsIfNeeded()
    //     0x65c108: bl              #0x522fec  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::computeTextMetricsIfNeeded
    // 0x65c10c: add             SP, SP, #8
    // 0x65c110: ldr             x16, [fp, #0x20]
    // 0x65c114: SaveReg r16
    //     0x65c114: str             x16, [SP, #-8]!
    // 0x65c118: r0 = _hasVisualOverflow()
    //     0x65c118: bl              #0x65de68  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_hasVisualOverflow
    // 0x65c11c: add             SP, SP, #8
    // 0x65c120: tbnz            w0, #4, #0x65c1d8
    // 0x65c124: ldr             x0, [fp, #0x20]
    // 0x65c128: LoadField: r1 = r0->field_37
    //     0x65c128: ldur            w1, [x0, #0x37]
    // 0x65c12c: DecompressPointer r1
    //     0x65c12c: add             x1, x1, HEAP, lsl #32
    // 0x65c130: r16 = Sentinel
    //     0x65c130: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x65c134: cmp             w1, w16
    // 0x65c138: b.eq            #0x65c268
    // 0x65c13c: stur            x1, [fp, #-8]
    // 0x65c140: LoadField: r2 = r0->field_57
    //     0x65c140: ldur            w2, [x0, #0x57]
    // 0x65c144: DecompressPointer r2
    //     0x65c144: add             x2, x2, HEAP, lsl #32
    // 0x65c148: cmp             w2, NULL
    // 0x65c14c: b.eq            #0x65c270
    // 0x65c150: r16 = Instance_Offset
    //     0x65c150: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x65c154: stp             x2, x16, [SP, #-0x10]!
    // 0x65c158: r0 = &()
    //     0x65c158: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x65c15c: add             SP, SP, #0x10
    // 0x65c160: stur            x0, [fp, #-0x10]
    // 0x65c164: r1 = 1
    //     0x65c164: mov             x1, #1
    // 0x65c168: r0 = AllocateContext()
    //     0x65c168: bl              #0xd68aa4  ; AllocateContextStub
    // 0x65c16c: mov             x1, x0
    // 0x65c170: ldr             x0, [fp, #0x20]
    // 0x65c174: StoreField: r1->field_f = r0
    //     0x65c174: stur            w0, [x1, #0xf]
    // 0x65c178: r17 = 375
    //     0x65c178: mov             x17, #0x177
    // 0x65c17c: ldr             w2, [x0, x17]
    // 0x65c180: DecompressPointer r2
    //     0x65c180: add             x2, x2, HEAP, lsl #32
    // 0x65c184: LoadField: r3 = r2->field_b
    //     0x65c184: ldur            w3, [x2, #0xb]
    // 0x65c188: DecompressPointer r3
    //     0x65c188: add             x3, x3, HEAP, lsl #32
    // 0x65c18c: mov             x2, x1
    // 0x65c190: stur            x3, [fp, #-0x18]
    // 0x65c194: r1 = Function '_paintContents@483409610':.
    //     0x65c194: add             x1, PP, #0x56, lsl #12  ; [pp+0x56750] AnonymousClosure: (0x65dee0), in [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_paintContents (0x65c7bc)
    //     0x65c198: ldr             x1, [x1, #0x750]
    // 0x65c19c: r0 = AllocateClosure()
    //     0x65c19c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x65c1a0: ldr             x16, [fp, #0x18]
    // 0x65c1a4: ldur            lr, [fp, #-8]
    // 0x65c1a8: stp             lr, x16, [SP, #-0x10]!
    // 0x65c1ac: ldr             x16, [fp, #0x10]
    // 0x65c1b0: ldur            lr, [fp, #-0x10]
    // 0x65c1b4: stp             lr, x16, [SP, #-0x10]!
    // 0x65c1b8: r16 = Instance_Clip
    //     0x65c1b8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x65c1bc: ldr             x16, [x16, #0x678]
    // 0x65c1c0: stp             x16, x0, [SP, #-0x10]!
    // 0x65c1c4: ldur            x16, [fp, #-0x18]
    // 0x65c1c8: SaveReg r16
    //     0x65c1c8: str             x16, [SP, #-8]!
    // 0x65c1cc: r0 = pushClipRect()
    //     0x65c1cc: bl              #0x65b240  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRect
    // 0x65c1d0: add             SP, SP, #0x38
    // 0x65c1d4: b               #0x65c210
    // 0x65c1d8: ldr             x0, [fp, #0x20]
    // 0x65c1dc: r17 = 375
    //     0x65c1dc: mov             x17, #0x177
    // 0x65c1e0: ldr             w1, [x0, x17]
    // 0x65c1e4: DecompressPointer r1
    //     0x65c1e4: add             x1, x1, HEAP, lsl #32
    // 0x65c1e8: stp             NULL, x1, [SP, #-0x10]!
    // 0x65c1ec: r0 = layer=()
    //     0x65c1ec: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x65c1f0: add             SP, SP, #0x10
    // 0x65c1f4: ldr             x16, [fp, #0x20]
    // 0x65c1f8: ldr             lr, [fp, #0x18]
    // 0x65c1fc: stp             lr, x16, [SP, #-0x10]!
    // 0x65c200: ldr             x16, [fp, #0x10]
    // 0x65c204: SaveReg r16
    //     0x65c204: str             x16, [SP, #-8]!
    // 0x65c208: r0 = _paintContents()
    //     0x65c208: bl              #0x65c7bc  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_paintContents
    // 0x65c20c: add             SP, SP, #0x18
    // 0x65c210: ldr             x0, [fp, #0x20]
    // 0x65c214: r1 = 1
    //     0x65c214: mov             x1, #1
    // 0x65c218: r0 = AllocateContext()
    //     0x65c218: bl              #0xd68aa4  ; AllocateContextStub
    // 0x65c21c: mov             x1, x0
    // 0x65c220: ldr             x0, [fp, #0x20]
    // 0x65c224: StoreField: r1->field_f = r0
    //     0x65c224: stur            w0, [x1, #0xf]
    // 0x65c228: mov             x2, x1
    // 0x65c22c: r1 = Function 'paint':.
    //     0x65c22c: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4ff58] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x65c230: ldr             x1, [x1, #0xf58]
    // 0x65c234: r0 = AllocateClosure()
    //     0x65c234: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x65c238: ldr             x16, [fp, #0x20]
    // 0x65c23c: ldr             lr, [fp, #0x18]
    // 0x65c240: stp             lr, x16, [SP, #-0x10]!
    // 0x65c244: SaveReg r0
    //     0x65c244: str             x0, [SP, #-8]!
    // 0x65c248: r0 = paintHandleLayers()
    //     0x65c248: bl              #0x65c274  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::paintHandleLayers
    // 0x65c24c: add             SP, SP, #0x18
    // 0x65c250: r0 = Null
    //     0x65c250: mov             x0, NULL
    // 0x65c254: LeaveFrame
    //     0x65c254: mov             SP, fp
    //     0x65c258: ldp             fp, lr, [SP], #0x10
    // 0x65c25c: ret
    //     0x65c25c: ret             
    // 0x65c260: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65c260: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65c264: b               #0x65c0dc
    // 0x65c268: r9 = _needsCompositing
    //     0x65c268: ldr             x9, [PP, #0x4b28]  ; [pp+0x4b28] Field <RenderObject._needsCompositing@904266271>: late (offset: 0x38)
    // 0x65c26c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x65c26c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x65c270: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65c270: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _paintContents(/* No info */) {
    // ** addr: 0x65c7bc, size: 0x1a8
    // 0x65c7bc: EnterFrame
    //     0x65c7bc: stp             fp, lr, [SP, #-0x10]!
    //     0x65c7c0: mov             fp, SP
    // 0x65c7c4: AllocStack(0x18)
    //     0x65c7c4: sub             SP, SP, #0x18
    // 0x65c7c8: CheckStackOverflow
    //     0x65c7c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65c7cc: cmp             SP, x16
    //     0x65c7d0: b.ls            #0x65c95c
    // 0x65c7d4: ldr             x16, [fp, #0x20]
    // 0x65c7d8: SaveReg r16
    //     0x65c7d8: str             x16, [SP, #-8]!
    // 0x65c7dc: r0 = paintOffset()
    //     0x65c7dc: bl              #0x522e98  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::paintOffset
    // 0x65c7e0: add             SP, SP, #8
    // 0x65c7e4: ldr             x16, [fp, #0x10]
    // 0x65c7e8: stp             x0, x16, [SP, #-0x10]!
    // 0x65c7ec: r0 = +()
    //     0x65c7ec: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x65c7f0: add             SP, SP, #0x10
    // 0x65c7f4: mov             x4, x0
    // 0x65c7f8: ldr             x3, [fp, #0x20]
    // 0x65c7fc: stur            x4, [fp, #-0x10]
    // 0x65c800: LoadField: r0 = r3->field_b3
    //     0x65c800: ldur            w0, [x3, #0xb3]
    // 0x65c804: DecompressPointer r0
    //     0x65c804: add             x0, x0, HEAP, lsl #32
    // 0x65c808: LoadField: r5 = r0->field_2b
    //     0x65c808: ldur            w5, [x0, #0x2b]
    // 0x65c80c: DecompressPointer r5
    //     0x65c80c: add             x5, x5, HEAP, lsl #32
    // 0x65c810: stur            x5, [fp, #-8]
    // 0x65c814: cmp             w5, NULL
    // 0x65c818: b.eq            #0x65c87c
    // 0x65c81c: r17 = 303
    //     0x65c81c: mov             x17, #0x12f
    // 0x65c820: ldr             w0, [x3, x17]
    // 0x65c824: DecompressPointer r0
    //     0x65c824: add             x0, x0, HEAP, lsl #32
    // 0x65c828: tbz             w0, #4, #0x65c87c
    // 0x65c82c: mov             x0, x5
    // 0x65c830: r2 = Null
    //     0x65c830: mov             x2, NULL
    // 0x65c834: r1 = Null
    //     0x65c834: mov             x1, NULL
    // 0x65c838: r4 = LoadClassIdInstr(r0)
    //     0x65c838: ldur            x4, [x0, #-1]
    //     0x65c83c: ubfx            x4, x4, #0xc, #0x14
    // 0x65c840: r17 = 5018
    //     0x65c840: mov             x17, #0x139a
    // 0x65c844: cmp             x4, x17
    // 0x65c848: b.eq            #0x65c860
    // 0x65c84c: r8 = TextSelection
    //     0x65c84c: add             x8, PP, #0x56, lsl #12  ; [pp+0x56758] Type: TextSelection
    //     0x65c850: ldr             x8, [x8, #0x758]
    // 0x65c854: r3 = Null
    //     0x65c854: add             x3, PP, #0x56, lsl #12  ; [pp+0x56760] Null
    //     0x65c858: ldr             x3, [x3, #0x760]
    // 0x65c85c: r0 = DefaultTypeTest()
    //     0x65c85c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x65c860: ldr             x16, [fp, #0x20]
    // 0x65c864: ldur            lr, [fp, #-0x10]
    // 0x65c868: stp             lr, x16, [SP, #-0x10]!
    // 0x65c86c: ldur            x16, [fp, #-8]
    // 0x65c870: SaveReg r16
    //     0x65c870: str             x16, [SP, #-8]!
    // 0x65c874: r0 = _updateSelectionExtentsVisibility()
    //     0x65c874: bl              #0x65dca4  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_updateSelectionExtentsVisibility
    // 0x65c878: add             SP, SP, #0x18
    // 0x65c87c: ldr             x0, [fp, #0x20]
    // 0x65c880: LoadField: r1 = r0->field_9b
    //     0x65c880: ldur            w1, [x0, #0x9b]
    // 0x65c884: DecompressPointer r1
    //     0x65c884: add             x1, x1, HEAP, lsl #32
    // 0x65c888: stur            x1, [fp, #-8]
    // 0x65c88c: LoadField: r2 = r0->field_9f
    //     0x65c88c: ldur            w2, [x0, #0x9f]
    // 0x65c890: DecompressPointer r2
    //     0x65c890: add             x2, x2, HEAP, lsl #32
    // 0x65c894: cmp             w2, NULL
    // 0x65c898: b.eq            #0x65c8b4
    // 0x65c89c: ldr             x16, [fp, #0x18]
    // 0x65c8a0: stp             x2, x16, [SP, #-0x10]!
    // 0x65c8a4: ldr             x16, [fp, #0x10]
    // 0x65c8a8: SaveReg r16
    //     0x65c8a8: str             x16, [SP, #-8]!
    // 0x65c8ac: r0 = paintChild()
    //     0x65c8ac: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x65c8b0: add             SP, SP, #0x18
    // 0x65c8b4: ldr             x0, [fp, #0x20]
    // 0x65c8b8: ldur            x1, [fp, #-8]
    // 0x65c8bc: LoadField: r2 = r0->field_eb
    //     0x65c8bc: ldur            w2, [x0, #0xeb]
    // 0x65c8c0: DecompressPointer r2
    //     0x65c8c0: add             x2, x2, HEAP, lsl #32
    // 0x65c8c4: stur            x2, [fp, #-0x18]
    // 0x65c8c8: ldr             x16, [fp, #0x18]
    // 0x65c8cc: SaveReg r16
    //     0x65c8cc: str             x16, [SP, #-8]!
    // 0x65c8d0: r0 = canvas()
    //     0x65c8d0: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x65c8d4: add             SP, SP, #8
    // 0x65c8d8: ldur            x16, [fp, #-0x18]
    // 0x65c8dc: stp             x0, x16, [SP, #-0x10]!
    // 0x65c8e0: ldur            x16, [fp, #-0x10]
    // 0x65c8e4: SaveReg r16
    //     0x65c8e4: str             x16, [SP, #-8]!
    // 0x65c8e8: r0 = paint()
    //     0x65c8e8: bl              #0x65d820  ; [package:flutter/src/painting/text_painter.dart] TextPainter::paint
    // 0x65c8ec: add             SP, SP, #0x18
    // 0x65c8f0: ldr             x16, [fp, #0x20]
    // 0x65c8f4: ldr             lr, [fp, #0x18]
    // 0x65c8f8: stp             lr, x16, [SP, #-0x10]!
    // 0x65c8fc: ldur            x16, [fp, #-0x10]
    // 0x65c900: SaveReg r16
    //     0x65c900: str             x16, [SP, #-8]!
    // 0x65c904: r0 = paintWidgets()
    //     0x65c904: bl              #0x65ce48  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::paintWidgets
    // 0x65c908: add             SP, SP, #0x18
    // 0x65c90c: ldr             x16, [fp, #0x20]
    // 0x65c910: ldr             lr, [fp, #0x18]
    // 0x65c914: stp             lr, x16, [SP, #-0x10]!
    // 0x65c918: ldur            x16, [fp, #-0x10]
    // 0x65c91c: SaveReg r16
    //     0x65c91c: str             x16, [SP, #-8]!
    // 0x65c920: r0 = _paintSpecialText()
    //     0x65c920: bl              #0x65c964  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_paintSpecialText
    // 0x65c924: add             SP, SP, #0x18
    // 0x65c928: ldur            x0, [fp, #-8]
    // 0x65c92c: cmp             w0, NULL
    // 0x65c930: b.eq            #0x65c94c
    // 0x65c934: ldr             x16, [fp, #0x18]
    // 0x65c938: stp             x0, x16, [SP, #-0x10]!
    // 0x65c93c: ldr             x16, [fp, #0x10]
    // 0x65c940: SaveReg r16
    //     0x65c940: str             x16, [SP, #-8]!
    // 0x65c944: r0 = paintChild()
    //     0x65c944: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x65c948: add             SP, SP, #0x18
    // 0x65c94c: r0 = Null
    //     0x65c94c: mov             x0, NULL
    // 0x65c950: LeaveFrame
    //     0x65c950: mov             SP, fp
    //     0x65c954: ldp             fp, lr, [SP], #0x10
    // 0x65c958: ret
    //     0x65c958: ret             
    // 0x65c95c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65c95c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65c960: b               #0x65c7d4
  }
  _ _paintSpecialText(/* No info */) {
    // ** addr: 0x65c964, size: 0x188
    // 0x65c964: EnterFrame
    //     0x65c964: stp             fp, lr, [SP, #-0x10]!
    //     0x65c968: mov             fp, SP
    // 0x65c96c: AllocStack(0x20)
    //     0x65c96c: sub             SP, SP, #0x20
    // 0x65c970: CheckStackOverflow
    //     0x65c970: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65c974: cmp             SP, x16
    //     0x65c978: b.ls            #0x65cad0
    // 0x65c97c: ldr             x0, [fp, #0x20]
    // 0x65c980: LoadField: r1 = r0->field_97
    //     0x65c980: ldur            w1, [x0, #0x97]
    // 0x65c984: DecompressPointer r1
    //     0x65c984: add             x1, x1, HEAP, lsl #32
    // 0x65c988: tbnz            w1, #4, #0x65cac0
    // 0x65c98c: LoadField: r1 = r0->field_77
    //     0x65c98c: ldur            w1, [x0, #0x77]
    // 0x65c990: DecompressPointer r1
    //     0x65c990: add             x1, x1, HEAP, lsl #32
    // 0x65c994: tbnz            w1, #4, #0x65cac0
    // 0x65c998: ldr             x1, [fp, #0x10]
    // 0x65c99c: ldr             x16, [fp, #0x18]
    // 0x65c9a0: SaveReg r16
    //     0x65c9a0: str             x16, [SP, #-8]!
    // 0x65c9a4: r0 = canvas()
    //     0x65c9a4: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x65c9a8: add             SP, SP, #8
    // 0x65c9ac: stur            x0, [fp, #-8]
    // 0x65c9b0: SaveReg r0
    //     0x65c9b0: str             x0, [SP, #-8]!
    // 0x65c9b4: r0 = save()
    //     0x65c9b4: bl              #0x6595b0  ; [dart:ui] Canvas::save
    // 0x65c9b8: add             SP, SP, #8
    // 0x65c9bc: ldr             x0, [fp, #0x10]
    // 0x65c9c0: LoadField: d0 = r0->field_7
    //     0x65c9c0: ldur            d0, [x0, #7]
    // 0x65c9c4: LoadField: d1 = r0->field_f
    //     0x65c9c4: ldur            d1, [x0, #0xf]
    // 0x65c9c8: r0 = inline_Allocate_Double()
    //     0x65c9c8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x65c9cc: add             x0, x0, #0x10
    //     0x65c9d0: cmp             x1, x0
    //     0x65c9d4: b.ls            #0x65cad8
    //     0x65c9d8: str             x0, [THR, #0x60]  ; THR::top
    //     0x65c9dc: sub             x0, x0, #0xf
    //     0x65c9e0: mov             x1, #0xd108
    //     0x65c9e4: movk            x1, #3, lsl #16
    //     0x65c9e8: stur            x1, [x0, #-1]
    // 0x65c9ec: StoreField: r0->field_7 = d0
    //     0x65c9ec: stur            d0, [x0, #7]
    // 0x65c9f0: ldur            x16, [fp, #-8]
    // 0x65c9f4: stp             x0, x16, [SP, #-0x10]!
    // 0x65c9f8: SaveReg d1
    //     0x65c9f8: str             d1, [SP, #-8]!
    // 0x65c9fc: r0 = translate()
    //     0x65c9fc: bl              #0x6566d0  ; [dart:ui] Canvas::translate
    // 0x65ca00: add             SP, SP, #0x18
    // 0x65ca04: ldr             x0, [fp, #0x20]
    // 0x65ca08: LoadField: r1 = r0->field_57
    //     0x65ca08: ldur            w1, [x0, #0x57]
    // 0x65ca0c: DecompressPointer r1
    //     0x65ca0c: add             x1, x1, HEAP, lsl #32
    // 0x65ca10: cmp             w1, NULL
    // 0x65ca14: b.eq            #0x65cae8
    // 0x65ca18: r16 = Instance_Offset
    //     0x65ca18: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x65ca1c: stp             x1, x16, [SP, #-0x10]!
    // 0x65ca20: r0 = &()
    //     0x65ca20: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x65ca24: add             SP, SP, #0x10
    // 0x65ca28: mov             x3, x0
    // 0x65ca2c: ldr             x0, [fp, #0x20]
    // 0x65ca30: stur            x3, [fp, #-0x18]
    // 0x65ca34: LoadField: r1 = r0->field_eb
    //     0x65ca34: ldur            w1, [x0, #0xeb]
    // 0x65ca38: DecompressPointer r1
    //     0x65ca38: add             x1, x1, HEAP, lsl #32
    // 0x65ca3c: LoadField: r4 = r1->field_f
    //     0x65ca3c: ldur            w4, [x1, #0xf]
    // 0x65ca40: DecompressPointer r4
    //     0x65ca40: add             x4, x4, HEAP, lsl #32
    // 0x65ca44: stur            x4, [fp, #-0x10]
    // 0x65ca48: r1 = Null
    //     0x65ca48: mov             x1, NULL
    // 0x65ca4c: r2 = 2
    //     0x65ca4c: mov             x2, #2
    // 0x65ca50: r0 = AllocateArray()
    //     0x65ca50: bl              #0xd6987c  ; AllocateArrayStub
    // 0x65ca54: mov             x2, x0
    // 0x65ca58: ldur            x0, [fp, #-0x10]
    // 0x65ca5c: stur            x2, [fp, #-0x20]
    // 0x65ca60: StoreField: r2->field_f = r0
    //     0x65ca60: stur            w0, [x2, #0xf]
    // 0x65ca64: r1 = <InlineSpan?>
    //     0x65ca64: add             x1, PP, #0x56, lsl #12  ; [pp+0x56770] TypeArguments: <InlineSpan?>
    //     0x65ca68: ldr             x1, [x1, #0x770]
    // 0x65ca6c: r0 = AllocateGrowableArray()
    //     0x65ca6c: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x65ca70: mov             x1, x0
    // 0x65ca74: ldur            x0, [fp, #-0x20]
    // 0x65ca78: StoreField: r1->field_f = r0
    //     0x65ca78: stur            w0, [x1, #0xf]
    // 0x65ca7c: r0 = 2
    //     0x65ca7c: mov             x0, #2
    // 0x65ca80: StoreField: r1->field_b = r0
    //     0x65ca80: stur            w0, [x1, #0xb]
    // 0x65ca84: ldr             x16, [fp, #0x20]
    // 0x65ca88: stp             x1, x16, [SP, #-0x10]!
    // 0x65ca8c: ldur            x16, [fp, #-0x18]
    // 0x65ca90: SaveReg r16
    //     0x65ca90: str             x16, [SP, #-8]!
    // 0x65ca94: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x65ca94: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x65ca98: r0 = _paintSpecialTextChildren()
    //     0x65ca98: bl              #0x65caec  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_paintSpecialTextChildren
    // 0x65ca9c: add             SP, SP, #0x18
    // 0x65caa0: ldur            x16, [fp, #-8]
    // 0x65caa4: SaveReg r16
    //     0x65caa4: str             x16, [SP, #-8]!
    // 0x65caa8: r0 = restore()
    //     0x65caa8: bl              #0x65586c  ; [dart:ui] Canvas::restore
    // 0x65caac: add             SP, SP, #8
    // 0x65cab0: r0 = Null
    //     0x65cab0: mov             x0, NULL
    // 0x65cab4: LeaveFrame
    //     0x65cab4: mov             SP, fp
    //     0x65cab8: ldp             fp, lr, [SP], #0x10
    // 0x65cabc: ret
    //     0x65cabc: ret             
    // 0x65cac0: r0 = Null
    //     0x65cac0: mov             x0, NULL
    // 0x65cac4: LeaveFrame
    //     0x65cac4: mov             SP, fp
    //     0x65cac8: ldp             fp, lr, [SP], #0x10
    // 0x65cacc: ret
    //     0x65cacc: ret             
    // 0x65cad0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65cad0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65cad4: b               #0x65c97c
    // 0x65cad8: stp             q0, q1, [SP, #-0x20]!
    // 0x65cadc: r0 = AllocateDouble()
    //     0x65cadc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65cae0: ldp             q0, q1, [SP], #0x20
    // 0x65cae4: b               #0x65c9ec
    // 0x65cae8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65cae8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _paintSpecialTextChildren(/* No info */) {
    // ** addr: 0x65caec, size: 0x32c
    // 0x65caec: EnterFrame
    //     0x65caec: stp             fp, lr, [SP, #-0x10]!
    //     0x65caf0: mov             fp, SP
    // 0x65caf4: AllocStack(0x48)
    //     0x65caf4: sub             SP, SP, #0x48
    // 0x65caf8: SetupParameters(ExtendedRenderEditable this /* r3, fp-0x18 */, dynamic _ /* r4 */, dynamic _ /* r5, fp-0x10 */, {int textOffset = 0 /* r1, fp-0x8 */})
    //     0x65caf8: mov             x0, x4
    //     0x65cafc: ldur            w1, [x0, #0x13]
    //     0x65cb00: add             x1, x1, HEAP, lsl #32
    //     0x65cb04: sub             x2, x1, #6
    //     0x65cb08: add             x3, fp, w2, sxtw #2
    //     0x65cb0c: ldr             x3, [x3, #0x20]
    //     0x65cb10: stur            x3, [fp, #-0x18]
    //     0x65cb14: add             x4, fp, w2, sxtw #2
    //     0x65cb18: ldr             x4, [x4, #0x18]
    //     0x65cb1c: add             x5, fp, w2, sxtw #2
    //     0x65cb20: ldr             x5, [x5, #0x10]
    //     0x65cb24: stur            x5, [fp, #-0x10]
    //     0x65cb28: ldur            w2, [x0, #0x1f]
    //     0x65cb2c: add             x2, x2, HEAP, lsl #32
    //     0x65cb30: add             x16, PP, #0x56, lsl #12  ; [pp+0x56778] "textOffset"
    //     0x65cb34: ldr             x16, [x16, #0x778]
    //     0x65cb38: cmp             w2, w16
    //     0x65cb3c: b.ne            #0x65cb68
    //     0x65cb40: ldur            w2, [x0, #0x23]
    //     0x65cb44: add             x2, x2, HEAP, lsl #32
    //     0x65cb48: sub             w0, w1, w2
    //     0x65cb4c: add             x1, fp, w0, sxtw #2
    //     0x65cb50: ldr             x1, [x1, #8]
    //     0x65cb54: sbfx            x0, x1, #1, #0x1f
    //     0x65cb58: tbz             w1, #0, #0x65cb60
    //     0x65cb5c: ldur            x0, [x1, #7]
    //     0x65cb60: mov             x1, x0
    //     0x65cb64: b               #0x65cb6c
    //     0x65cb68: mov             x1, #0
    //     0x65cb6c: stur            x1, [fp, #-8]
    // 0x65cb70: CheckStackOverflow
    //     0x65cb70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65cb74: cmp             SP, x16
    //     0x65cb78: b.ls            #0x65ce04
    // 0x65cb7c: cmp             w4, NULL
    // 0x65cb80: b.ne            #0x65cb94
    // 0x65cb84: r0 = Null
    //     0x65cb84: mov             x0, NULL
    // 0x65cb88: LeaveFrame
    //     0x65cb88: mov             SP, fp
    //     0x65cb8c: ldp             fp, lr, [SP], #0x10
    // 0x65cb90: ret
    //     0x65cb90: ret             
    // 0x65cb94: r0 = LoadClassIdInstr(r4)
    //     0x65cb94: ldur            x0, [x4, #-1]
    //     0x65cb98: ubfx            x0, x0, #0xc, #0x14
    // 0x65cb9c: SaveReg r4
    //     0x65cb9c: str             x4, [SP, #-8]!
    // 0x65cba0: r0 = GDT[cid_x0 + 0xb940]()
    //     0x65cba0: mov             x17, #0xb940
    //     0x65cba4: add             lr, x0, x17
    //     0x65cba8: ldr             lr, [x21, lr, lsl #3]
    //     0x65cbac: blr             lr
    // 0x65cbb0: add             SP, SP, #8
    // 0x65cbb4: mov             x1, x0
    // 0x65cbb8: r0 = Instance_Offset
    //     0x65cbb8: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x65cbbc: stur            x1, [fp, #-0x20]
    // 0x65cbc0: LoadField: d0 = r0->field_7
    //     0x65cbc0: ldur            d0, [x0, #7]
    // 0x65cbc4: stur            d0, [fp, #-0x48]
    // 0x65cbc8: LoadField: d1 = r0->field_f
    //     0x65cbc8: ldur            d1, [x0, #0xf]
    // 0x65cbcc: stur            d1, [fp, #-0x40]
    // 0x65cbd0: ldur            x2, [fp, #-8]
    // 0x65cbd4: stur            x2, [fp, #-8]
    // 0x65cbd8: CheckStackOverflow
    //     0x65cbd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65cbdc: cmp             SP, x16
    //     0x65cbe0: b.ls            #0x65ce0c
    // 0x65cbe4: r0 = LoadClassIdInstr(r1)
    //     0x65cbe4: ldur            x0, [x1, #-1]
    //     0x65cbe8: ubfx            x0, x0, #0xc, #0x14
    // 0x65cbec: SaveReg r1
    //     0x65cbec: str             x1, [SP, #-8]!
    // 0x65cbf0: r0 = GDT[cid_x0 + 0x541]()
    //     0x65cbf0: add             lr, x0, #0x541
    //     0x65cbf4: ldr             lr, [x21, lr, lsl #3]
    //     0x65cbf8: blr             lr
    // 0x65cbfc: add             SP, SP, #8
    // 0x65cc00: tbnz            w0, #4, #0x65cdf4
    // 0x65cc04: ldur            x1, [fp, #-0x20]
    // 0x65cc08: ldur            x2, [fp, #-8]
    // 0x65cc0c: r0 = LoadClassIdInstr(r1)
    //     0x65cc0c: ldur            x0, [x1, #-1]
    //     0x65cc10: ubfx            x0, x0, #0xc, #0x14
    // 0x65cc14: SaveReg r1
    //     0x65cc14: str             x1, [SP, #-8]!
    // 0x65cc18: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x65cc18: add             lr, x0, #0x5ca
    //     0x65cc1c: ldr             lr, [x21, lr, lsl #3]
    //     0x65cc20: blr             lr
    // 0x65cc24: add             SP, SP, #8
    // 0x65cc28: stur            x0, [fp, #-0x28]
    // 0x65cc2c: r0 = TextPosition()
    //     0x65cc2c: bl              #0x5223f0  ; AllocateTextPositionStub -> TextPosition (size=0x14)
    // 0x65cc30: mov             x1, x0
    // 0x65cc34: ldur            x0, [fp, #-8]
    // 0x65cc38: StoreField: r1->field_7 = r0
    //     0x65cc38: stur            x0, [x1, #7]
    // 0x65cc3c: r2 = Instance_TextAffinity
    //     0x65cc3c: ldr             x2, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x65cc40: StoreField: r1->field_f = r2
    //     0x65cc40: stur            w2, [x1, #0xf]
    // 0x65cc44: ldur            x16, [fp, #-0x18]
    // 0x65cc48: stp             x1, x16, [SP, #-0x10]!
    // 0x65cc4c: ldur            x16, [fp, #-0x10]
    // 0x65cc50: SaveReg r16
    //     0x65cc50: str             x16, [SP, #-8]!
    // 0x65cc54: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x65cc54: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x65cc58: r0 = getCaretOffset()
    //     0x65cc58: bl              #0x5202b0  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::getCaretOffset
    // 0x65cc5c: add             SP, SP, #0x18
    // 0x65cc60: ldur            x2, [fp, #-8]
    // 0x65cc64: cbz             x2, #0x65cca8
    // 0x65cc68: ldur            d0, [fp, #-0x48]
    // 0x65cc6c: LoadField: d1 = r0->field_7
    //     0x65cc6c: ldur            d1, [x0, #7]
    // 0x65cc70: fcmp            d0, d1
    // 0x65cc74: b.vs            #0x65cca0
    // 0x65cc78: b.ne            #0x65cca0
    // 0x65cc7c: ldur            d1, [fp, #-0x40]
    // 0x65cc80: LoadField: d2 = r0->field_f
    //     0x65cc80: ldur            d2, [x0, #0xf]
    // 0x65cc84: fcmp            d1, d2
    // 0x65cc88: b.vs            #0x65ccb0
    // 0x65cc8c: b.ne            #0x65ccb0
    // 0x65cc90: r0 = Null
    //     0x65cc90: mov             x0, NULL
    // 0x65cc94: LeaveFrame
    //     0x65cc94: mov             SP, fp
    //     0x65cc98: ldp             fp, lr, [SP], #0x10
    // 0x65cc9c: ret
    //     0x65cc9c: ret             
    // 0x65cca0: ldur            d1, [fp, #-0x40]
    // 0x65cca4: b               #0x65ccb0
    // 0x65cca8: ldur            d1, [fp, #-0x40]
    // 0x65ccac: ldur            d0, [fp, #-0x48]
    // 0x65ccb0: ldur            x3, [fp, #-0x28]
    // 0x65ccb4: r4 = LoadTaggedClassIdMayBeSmiInstr(r3)
    //     0x65ccb4: mov             x4, #0x76
    //     0x65ccb8: tbz             w3, #0, #0x65ccc8
    //     0x65ccbc: ldur            x4, [x3, #-1]
    //     0x65ccc0: ubfx            x4, x4, #0xc, #0x14
    //     0x65ccc4: lsl             x4, x4, #1
    // 0x65ccc8: stur            x4, [fp, #-0x30]
    // 0x65cccc: r0 = LoadInt32Instr(r4)
    //     0x65cccc: sbfx            x0, x4, #1, #0x1f
    // 0x65ccd0: cmp             x0, #0xd91
    // 0x65ccd4: b.lt            #0x65cd24
    // 0x65ccd8: cmp             x0, #0xd93
    // 0x65ccdc: b.gt            #0x65cd24
    // 0x65cce0: LoadField: r5 = r3->field_f
    //     0x65cce0: ldur            w5, [x3, #0xf]
    // 0x65cce4: DecompressPointer r5
    //     0x65cce4: add             x5, x5, HEAP, lsl #32
    // 0x65cce8: cmp             w5, NULL
    // 0x65ccec: b.eq            #0x65cd24
    // 0x65ccf0: r0 = BoxInt64Instr(r2)
    //     0x65ccf0: sbfiz           x0, x2, #1, #0x1f
    //     0x65ccf4: cmp             x2, x0, asr #1
    //     0x65ccf8: b.eq            #0x65cd04
    //     0x65ccfc: bl              #0xd69c6c
    //     0x65cd00: stur            x2, [x0, #7]
    // 0x65cd04: ldur            x16, [fp, #-0x18]
    // 0x65cd08: stp             x5, x16, [SP, #-0x10]!
    // 0x65cd0c: ldur            x16, [fp, #-0x10]
    // 0x65cd10: stp             x0, x16, [SP, #-0x10]!
    // 0x65cd14: r4 = const [0, 0x4, 0x4, 0x3, textOffset, 0x3, null]
    //     0x65cd14: add             x4, PP, #0x56, lsl #12  ; [pp+0x56780] List(7) [0, 0x4, 0x4, 0x3, "textOffset", 0x3, Null]
    //     0x65cd18: ldr             x4, [x4, #0x780]
    // 0x65cd1c: r0 = _paintSpecialTextChildren()
    //     0x65cd1c: bl              #0x65caec  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_paintSpecialTextChildren
    // 0x65cd20: add             SP, SP, #0x20
    // 0x65cd24: ldur            x0, [fp, #-0x28]
    // 0x65cd28: ldur            x1, [fp, #-0x30]
    // 0x65cd2c: cmp             w0, NULL
    // 0x65cd30: b.eq            #0x65ce14
    // 0x65cd34: r0 = StringBuffer()
    //     0x65cd34: bl              #0x4d1e30  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x65cd38: stur            x0, [fp, #-0x38]
    // 0x65cd3c: SaveReg r0
    //     0x65cd3c: str             x0, [SP, #-8]!
    // 0x65cd40: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x65cd40: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x65cd44: r0 = StringBuffer()
    //     0x65cd44: bl              #0x4d16e0  ; [dart:core] StringBuffer::StringBuffer
    // 0x65cd48: add             SP, SP, #8
    // 0x65cd4c: ldur            x0, [fp, #-0x30]
    // 0x65cd50: r17 = 6958
    //     0x65cd50: mov             x17, #0x1b2e
    // 0x65cd54: cmp             w0, w17
    // 0x65cd58: b.gt            #0x65cd80
    // 0x65cd5c: r17 = 6954
    //     0x65cd5c: mov             x17, #0x1b2a
    // 0x65cd60: cmp             w0, w17
    // 0x65cd64: b.lt            #0x65cd80
    // 0x65cd68: ldur            x16, [fp, #-0x38]
    // 0x65cd6c: r30 = 131064
    //     0x65cd6c: mov             lr, #0x1fff8
    // 0x65cd70: stp             lr, x16, [SP, #-0x10]!
    // 0x65cd74: r0 = writeCharCode()
    //     0x65cd74: bl              #0x4d3a84  ; [dart:core] StringBuffer::writeCharCode
    // 0x65cd78: add             SP, SP, #0x10
    // 0x65cd7c: b               #0x65cdb8
    // 0x65cd80: ldur            x0, [fp, #-0x28]
    // 0x65cd84: r1 = LoadClassIdInstr(r0)
    //     0x65cd84: ldur            x1, [x0, #-1]
    //     0x65cd88: ubfx            x1, x1, #0xc, #0x14
    // 0x65cd8c: ldur            x16, [fp, #-0x38]
    // 0x65cd90: stp             x16, x0, [SP, #-0x10]!
    // 0x65cd94: r16 = true
    //     0x65cd94: add             x16, NULL, #0x20  ; true
    // 0x65cd98: SaveReg r16
    //     0x65cd98: str             x16, [SP, #-8]!
    // 0x65cd9c: mov             x0, x1
    // 0x65cda0: r4 = const [0, 0x3, 0x3, 0x2, includePlaceholders, 0x2, null]
    //     0x65cda0: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d410] List(7) [0, 0x3, 0x3, 0x2, "includePlaceholders", 0x2, Null]
    //     0x65cda4: ldr             x4, [x4, #0x410]
    // 0x65cda8: r0 = GDT[cid_x0 + -0xec2]()
    //     0x65cda8: sub             lr, x0, #0xec2
    //     0x65cdac: ldr             lr, [x21, lr, lsl #3]
    //     0x65cdb0: blr             lr
    // 0x65cdb4: add             SP, SP, #0x18
    // 0x65cdb8: ldur            x0, [fp, #-8]
    // 0x65cdbc: ldur            x16, [fp, #-0x38]
    // 0x65cdc0: SaveReg r16
    //     0x65cdc0: str             x16, [SP, #-8]!
    // 0x65cdc4: r0 = toString()
    //     0x65cdc4: bl              #0xaba59c  ; [dart:core] StringBuffer::toString
    // 0x65cdc8: add             SP, SP, #8
    // 0x65cdcc: LoadField: r1 = r0->field_7
    //     0x65cdcc: ldur            w1, [x0, #7]
    // 0x65cdd0: DecompressPointer r1
    //     0x65cdd0: add             x1, x1, HEAP, lsl #32
    // 0x65cdd4: r2 = LoadInt32Instr(r1)
    //     0x65cdd4: sbfx            x2, x1, #1, #0x1f
    // 0x65cdd8: ldur            x1, [fp, #-8]
    // 0x65cddc: add             x0, x1, x2
    // 0x65cde0: mov             x2, x0
    // 0x65cde4: ldur            x1, [fp, #-0x20]
    // 0x65cde8: ldur            d1, [fp, #-0x40]
    // 0x65cdec: ldur            d0, [fp, #-0x48]
    // 0x65cdf0: b               #0x65cbd4
    // 0x65cdf4: r0 = Null
    //     0x65cdf4: mov             x0, NULL
    // 0x65cdf8: LeaveFrame
    //     0x65cdf8: mov             SP, fp
    //     0x65cdfc: ldp             fp, lr, [SP], #0x10
    // 0x65ce00: ret
    //     0x65ce00: ret             
    // 0x65ce04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65ce04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65ce08: b               #0x65cb7c
    // 0x65ce0c: r0 = StackOverflowSharedWithFPURegs()
    //     0x65ce0c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x65ce10: b               #0x65cbe4
    // 0x65ce14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65ce14: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateSelectionExtentsVisibility(/* No info */) {
    // ** addr: 0x65dca4, size: 0x1c4
    // 0x65dca4: EnterFrame
    //     0x65dca4: stp             fp, lr, [SP, #-0x10]!
    //     0x65dca8: mov             fp, SP
    // 0x65dcac: AllocStack(0x28)
    //     0x65dcac: sub             SP, SP, #0x28
    // 0x65dcb0: CheckStackOverflow
    //     0x65dcb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65dcb4: cmp             SP, x16
    //     0x65dcb8: b.ls            #0x65de50
    // 0x65dcbc: ldr             x0, [fp, #0x20]
    // 0x65dcc0: LoadField: r1 = r0->field_57
    //     0x65dcc0: ldur            w1, [x0, #0x57]
    // 0x65dcc4: DecompressPointer r1
    //     0x65dcc4: add             x1, x1, HEAP, lsl #32
    // 0x65dcc8: cmp             w1, NULL
    // 0x65dccc: b.eq            #0x65de58
    // 0x65dcd0: r16 = Instance_Offset
    //     0x65dcd0: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x65dcd4: stp             x1, x16, [SP, #-0x10]!
    // 0x65dcd8: r0 = &()
    //     0x65dcd8: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x65dcdc: add             SP, SP, #0x10
    // 0x65dce0: mov             x1, x0
    // 0x65dce4: ldr             x0, [fp, #0x10]
    // 0x65dce8: stur            x1, [fp, #-0x18]
    // 0x65dcec: LoadField: r2 = r0->field_7
    //     0x65dcec: ldur            x2, [x0, #7]
    // 0x65dcf0: stur            x2, [fp, #-0x10]
    // 0x65dcf4: LoadField: r3 = r0->field_27
    //     0x65dcf4: ldur            w3, [x0, #0x27]
    // 0x65dcf8: DecompressPointer r3
    //     0x65dcf8: add             x3, x3, HEAP, lsl #32
    // 0x65dcfc: stur            x3, [fp, #-8]
    // 0x65dd00: r0 = TextPosition()
    //     0x65dd00: bl              #0x5223f0  ; AllocateTextPositionStub -> TextPosition (size=0x14)
    // 0x65dd04: mov             x1, x0
    // 0x65dd08: ldur            x0, [fp, #-0x10]
    // 0x65dd0c: StoreField: r1->field_7 = r0
    //     0x65dd0c: stur            x0, [x1, #7]
    // 0x65dd10: ldur            x0, [fp, #-8]
    // 0x65dd14: StoreField: r1->field_f = r0
    //     0x65dd14: stur            w0, [x1, #0xf]
    // 0x65dd18: ldr             x2, [fp, #0x20]
    // 0x65dd1c: r17 = 339
    //     0x65dd1c: mov             x17, #0x153
    // 0x65dd20: ldr             w3, [x2, x17]
    // 0x65dd24: DecompressPointer r3
    //     0x65dd24: add             x3, x3, HEAP, lsl #32
    // 0x65dd28: r16 = Sentinel
    //     0x65dd28: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x65dd2c: cmp             w3, w16
    // 0x65dd30: b.eq            #0x65de5c
    // 0x65dd34: stp             x1, x2, [SP, #-0x10]!
    // 0x65dd38: ldr             x16, [fp, #0x18]
    // 0x65dd3c: stp             x16, x3, [SP, #-0x10]!
    // 0x65dd40: r4 = const [0, 0x4, 0x4, 0x3, effectiveOffset, 0x3, null]
    //     0x65dd40: add             x4, PP, #0x56, lsl #12  ; [pp+0x567b0] List(7) [0, 0x4, 0x4, 0x3, "effectiveOffset", 0x3, Null]
    //     0x65dd44: ldr             x4, [x4, #0x7b0]
    // 0x65dd48: r0 = getCaretOffset()
    //     0x65dd48: bl              #0x5202b0  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::getCaretOffset
    // 0x65dd4c: add             SP, SP, #0x20
    // 0x65dd50: mov             x1, x0
    // 0x65dd54: ldr             x0, [fp, #0x20]
    // 0x65dd58: stur            x1, [fp, #-0x28]
    // 0x65dd5c: LoadField: r2 = r0->field_df
    //     0x65dd5c: ldur            w2, [x0, #0xdf]
    // 0x65dd60: DecompressPointer r2
    //     0x65dd60: add             x2, x2, HEAP, lsl #32
    // 0x65dd64: stur            x2, [fp, #-0x20]
    // 0x65dd68: ldur            x16, [fp, #-0x18]
    // 0x65dd6c: SaveReg r16
    //     0x65dd6c: str             x16, [SP, #-8]!
    // 0x65dd70: d0 = 0.500000
    //     0x65dd70: fmov            d0, #0.50000000
    // 0x65dd74: SaveReg d0
    //     0x65dd74: str             d0, [SP, #-8]!
    // 0x65dd78: r0 = inflate()
    //     0x65dd78: bl              #0x5d1480  ; [dart:ui] Rect::inflate
    // 0x65dd7c: add             SP, SP, #0x10
    // 0x65dd80: ldur            x16, [fp, #-0x28]
    // 0x65dd84: stp             x16, x0, [SP, #-0x10]!
    // 0x65dd88: r0 = contains()
    //     0x65dd88: bl              #0x627548  ; [dart:ui] Rect::contains
    // 0x65dd8c: add             SP, SP, #0x10
    // 0x65dd90: ldur            x16, [fp, #-0x20]
    // 0x65dd94: stp             x0, x16, [SP, #-0x10]!
    // 0x65dd98: r0 = value=()
    //     0x65dd98: bl              #0x500e7c  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0x65dd9c: add             SP, SP, #0x10
    // 0x65dda0: ldr             x0, [fp, #0x10]
    // 0x65dda4: LoadField: r1 = r0->field_f
    //     0x65dda4: ldur            x1, [x0, #0xf]
    // 0x65dda8: stur            x1, [fp, #-0x10]
    // 0x65ddac: r0 = TextPosition()
    //     0x65ddac: bl              #0x5223f0  ; AllocateTextPositionStub -> TextPosition (size=0x14)
    // 0x65ddb0: mov             x1, x0
    // 0x65ddb4: ldur            x0, [fp, #-0x10]
    // 0x65ddb8: StoreField: r1->field_7 = r0
    //     0x65ddb8: stur            x0, [x1, #7]
    // 0x65ddbc: ldur            x0, [fp, #-8]
    // 0x65ddc0: StoreField: r1->field_f = r0
    //     0x65ddc0: stur            w0, [x1, #0xf]
    // 0x65ddc4: ldr             x0, [fp, #0x20]
    // 0x65ddc8: r17 = 339
    //     0x65ddc8: mov             x17, #0x153
    // 0x65ddcc: ldr             w2, [x0, x17]
    // 0x65ddd0: DecompressPointer r2
    //     0x65ddd0: add             x2, x2, HEAP, lsl #32
    // 0x65ddd4: stp             x1, x0, [SP, #-0x10]!
    // 0x65ddd8: ldr             x16, [fp, #0x18]
    // 0x65dddc: stp             x16, x2, [SP, #-0x10]!
    // 0x65dde0: r4 = const [0, 0x4, 0x4, 0x3, effectiveOffset, 0x3, null]
    //     0x65dde0: add             x4, PP, #0x56, lsl #12  ; [pp+0x567b0] List(7) [0, 0x4, 0x4, 0x3, "effectiveOffset", 0x3, Null]
    //     0x65dde4: ldr             x4, [x4, #0x7b0]
    // 0x65dde8: r0 = getCaretOffset()
    //     0x65dde8: bl              #0x5202b0  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::getCaretOffset
    // 0x65ddec: add             SP, SP, #0x20
    // 0x65ddf0: mov             x1, x0
    // 0x65ddf4: ldr             x0, [fp, #0x20]
    // 0x65ddf8: stur            x1, [fp, #-0x20]
    // 0x65ddfc: LoadField: r2 = r0->field_e3
    //     0x65ddfc: ldur            w2, [x0, #0xe3]
    // 0x65de00: DecompressPointer r2
    //     0x65de00: add             x2, x2, HEAP, lsl #32
    // 0x65de04: stur            x2, [fp, #-8]
    // 0x65de08: ldur            x16, [fp, #-0x18]
    // 0x65de0c: SaveReg r16
    //     0x65de0c: str             x16, [SP, #-8]!
    // 0x65de10: d0 = 0.500000
    //     0x65de10: fmov            d0, #0.50000000
    // 0x65de14: SaveReg d0
    //     0x65de14: str             d0, [SP, #-8]!
    // 0x65de18: r0 = inflate()
    //     0x65de18: bl              #0x5d1480  ; [dart:ui] Rect::inflate
    // 0x65de1c: add             SP, SP, #0x10
    // 0x65de20: ldur            x16, [fp, #-0x20]
    // 0x65de24: stp             x16, x0, [SP, #-0x10]!
    // 0x65de28: r0 = contains()
    //     0x65de28: bl              #0x627548  ; [dart:ui] Rect::contains
    // 0x65de2c: add             SP, SP, #0x10
    // 0x65de30: ldur            x16, [fp, #-8]
    // 0x65de34: stp             x0, x16, [SP, #-0x10]!
    // 0x65de38: r0 = value=()
    //     0x65de38: bl              #0x500e7c  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0x65de3c: add             SP, SP, #0x10
    // 0x65de40: r0 = Null
    //     0x65de40: mov             x0, NULL
    // 0x65de44: LeaveFrame
    //     0x65de44: mov             SP, fp
    //     0x65de48: ldp             fp, lr, [SP], #0x10
    // 0x65de4c: ret
    //     0x65de4c: ret             
    // 0x65de50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65de50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65de54: b               #0x65dcbc
    // 0x65de58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65de58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x65de5c: r9 = _caretPrototype
    //     0x65de5c: add             x9, PP, #0x37, lsl #12  ; [pp+0x37350] Field <ExtendedRenderEditable._caretPrototype@483409610>: late (offset: 0x154)
    //     0x65de60: ldr             x9, [x9, #0x350]
    // 0x65de64: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x65de64: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ _hasVisualOverflow(/* No info */) {
    // ** addr: 0x65de68, size: 0x78
    // 0x65de68: EnterFrame
    //     0x65de68: stp             fp, lr, [SP, #-0x10]!
    //     0x65de6c: mov             fp, SP
    // 0x65de70: d0 = 0.000000
    //     0x65de70: eor             v0.16b, v0.16b, v0.16b
    // 0x65de74: CheckStackOverflow
    //     0x65de74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65de78: cmp             SP, x16
    //     0x65de7c: b.ls            #0x65ded8
    // 0x65de80: ldr             x0, [fp, #0x10]
    // 0x65de84: r17 = 315
    //     0x65de84: mov             x17, #0x13b
    // 0x65de88: ldr             w1, [x0, x17]
    // 0x65de8c: DecompressPointer r1
    //     0x65de8c: add             x1, x1, HEAP, lsl #32
    // 0x65de90: LoadField: d1 = r1->field_7
    //     0x65de90: ldur            d1, [x1, #7]
    // 0x65de94: fcmp            d1, d0
    // 0x65de98: b.vs            #0x65dea8
    // 0x65de9c: b.le            #0x65dea8
    // 0x65dea0: r0 = true
    //     0x65dea0: add             x0, NULL, #0x20  ; true
    // 0x65dea4: b               #0x65decc
    // 0x65dea8: SaveReg r0
    //     0x65dea8: str             x0, [SP, #-8]!
    // 0x65deac: r0 = paintOffset()
    //     0x65deac: bl              #0x522e98  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::paintOffset
    // 0x65deb0: add             SP, SP, #8
    // 0x65deb4: r16 = Instance_Offset
    //     0x65deb4: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x65deb8: stp             x16, x0, [SP, #-0x10]!
    // 0x65debc: r0 = ==()
    //     0x65debc: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0x65dec0: add             SP, SP, #0x10
    // 0x65dec4: eor             x1, x0, #0x10
    // 0x65dec8: mov             x0, x1
    // 0x65decc: LeaveFrame
    //     0x65decc: mov             SP, fp
    //     0x65ded0: ldp             fp, lr, [SP], #0x10
    // 0x65ded4: ret
    //     0x65ded4: ret             
    // 0x65ded8: r0 = StackOverflowSharedWithFPURegs()
    //     0x65ded8: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x65dedc: b               #0x65de80
  }
  [closure] void _paintContents(dynamic, PaintingContext, Offset) {
    // ** addr: 0x65dee0, size: 0x54
    // 0x65dee0: EnterFrame
    //     0x65dee0: stp             fp, lr, [SP, #-0x10]!
    //     0x65dee4: mov             fp, SP
    // 0x65dee8: ldr             x0, [fp, #0x20]
    // 0x65deec: LoadField: r1 = r0->field_17
    //     0x65deec: ldur            w1, [x0, #0x17]
    // 0x65def0: DecompressPointer r1
    //     0x65def0: add             x1, x1, HEAP, lsl #32
    // 0x65def4: CheckStackOverflow
    //     0x65def4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65def8: cmp             SP, x16
    //     0x65defc: b.ls            #0x65df2c
    // 0x65df00: LoadField: r0 = r1->field_f
    //     0x65df00: ldur            w0, [x1, #0xf]
    // 0x65df04: DecompressPointer r0
    //     0x65df04: add             x0, x0, HEAP, lsl #32
    // 0x65df08: ldr             x16, [fp, #0x18]
    // 0x65df0c: stp             x16, x0, [SP, #-0x10]!
    // 0x65df10: ldr             x16, [fp, #0x10]
    // 0x65df14: SaveReg r16
    //     0x65df14: str             x16, [SP, #-8]!
    // 0x65df18: r0 = _paintContents()
    //     0x65df18: bl              #0x65c7bc  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_paintContents
    // 0x65df1c: add             SP, SP, #0x18
    // 0x65df20: LeaveFrame
    //     0x65df20: mov             SP, fp
    //     0x65df24: ldp             fp, lr, [SP], #0x10
    // 0x65df28: ret
    //     0x65df28: ret             
    // 0x65df2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65df2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65df30: b               #0x65df00
  }
  _ describeApproximatePaintClip(/* No info */) {
    // ** addr: 0x675504, size: 0x6c
    // 0x675504: EnterFrame
    //     0x675504: stp             fp, lr, [SP, #-0x10]!
    //     0x675508: mov             fp, SP
    // 0x67550c: CheckStackOverflow
    //     0x67550c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x675510: cmp             SP, x16
    //     0x675514: b.ls            #0x675564
    // 0x675518: ldr             x16, [fp, #0x18]
    // 0x67551c: SaveReg r16
    //     0x67551c: str             x16, [SP, #-8]!
    // 0x675520: r0 = _hasVisualOverflow()
    //     0x675520: bl              #0x65de68  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_hasVisualOverflow
    // 0x675524: add             SP, SP, #8
    // 0x675528: tbnz            w0, #4, #0x675554
    // 0x67552c: ldr             x0, [fp, #0x18]
    // 0x675530: LoadField: r1 = r0->field_57
    //     0x675530: ldur            w1, [x0, #0x57]
    // 0x675534: DecompressPointer r1
    //     0x675534: add             x1, x1, HEAP, lsl #32
    // 0x675538: cmp             w1, NULL
    // 0x67553c: b.eq            #0x67556c
    // 0x675540: r16 = Instance_Offset
    //     0x675540: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x675544: stp             x1, x16, [SP, #-0x10]!
    // 0x675548: r0 = &()
    //     0x675548: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x67554c: add             SP, SP, #0x10
    // 0x675550: b               #0x675558
    // 0x675554: r0 = Null
    //     0x675554: mov             x0, NULL
    // 0x675558: LeaveFrame
    //     0x675558: mov             SP, fp
    //     0x67555c: ldp             fp, lr, [SP], #0x10
    // 0x675560: ret
    //     0x675560: ret             
    // 0x675564: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x675564: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x675568: b               #0x675518
    // 0x67556c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67556c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x68afb0, size: 0x718
    // 0x68afb0: EnterFrame
    //     0x68afb0: stp             fp, lr, [SP, #-0x10]!
    //     0x68afb4: mov             fp, SP
    // 0x68afb8: AllocStack(0x30)
    //     0x68afb8: sub             SP, SP, #0x30
    // 0x68afbc: CheckStackOverflow
    //     0x68afbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68afc0: cmp             SP, x16
    //     0x68afc4: b.ls            #0x68b658
    // 0x68afc8: ldr             x3, [fp, #0x10]
    // 0x68afcc: LoadField: r4 = r3->field_27
    //     0x68afcc: ldur            w4, [x3, #0x27]
    // 0x68afd0: DecompressPointer r4
    //     0x68afd0: add             x4, x4, HEAP, lsl #32
    // 0x68afd4: stur            x4, [fp, #-8]
    // 0x68afd8: cmp             w4, NULL
    // 0x68afdc: b.eq            #0x68b5d8
    // 0x68afe0: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68afe0: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68afe4: ldr             x5, [x5, #0x1e8]
    // 0x68afe8: mov             x0, x4
    // 0x68afec: r2 = Null
    //     0x68afec: mov             x2, NULL
    // 0x68aff0: r1 = Null
    //     0x68aff0: mov             x1, NULL
    // 0x68aff4: r4 = LoadClassIdInstr(r0)
    //     0x68aff4: ldur            x4, [x0, #-1]
    //     0x68aff8: ubfx            x4, x4, #0xc, #0x14
    // 0x68affc: sub             x4, x4, #0x80d
    // 0x68b000: cmp             x4, #1
    // 0x68b004: b.ls            #0x68b01c
    // 0x68b008: r8 = BoxConstraints
    //     0x68b008: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x68b00c: ldr             x8, [x8, #0x1d0]
    // 0x68b010: r3 = Null
    //     0x68b010: add             x3, PP, #0x56, lsl #12  ; [pp+0x567b8] Null
    //     0x68b014: ldr             x3, [x3, #0x7b8]
    // 0x68b018: r0 = BoxConstraints()
    //     0x68b018: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x68b01c: ldr             x16, [fp, #0x10]
    // 0x68b020: ldur            lr, [fp, #-8]
    // 0x68b024: stp             lr, x16, [SP, #-0x10]!
    // 0x68b028: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x68b028: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x68b02c: r0 = layoutChildren()
    //     0x68b02c: bl              #0x68c390  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::layoutChildren
    // 0x68b030: add             SP, SP, #0x10
    // 0x68b034: ldr             x3, [fp, #0x10]
    // 0x68b038: LoadField: r4 = r3->field_27
    //     0x68b038: ldur            w4, [x3, #0x27]
    // 0x68b03c: DecompressPointer r4
    //     0x68b03c: add             x4, x4, HEAP, lsl #32
    // 0x68b040: stur            x4, [fp, #-8]
    // 0x68b044: cmp             w4, NULL
    // 0x68b048: b.eq            #0x68b5f0
    // 0x68b04c: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68b04c: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68b050: ldr             x5, [x5, #0x1e8]
    // 0x68b054: mov             x0, x4
    // 0x68b058: r2 = Null
    //     0x68b058: mov             x2, NULL
    // 0x68b05c: r1 = Null
    //     0x68b05c: mov             x1, NULL
    // 0x68b060: r4 = LoadClassIdInstr(r0)
    //     0x68b060: ldur            x4, [x0, #-1]
    //     0x68b064: ubfx            x4, x4, #0xc, #0x14
    // 0x68b068: sub             x4, x4, #0x80d
    // 0x68b06c: cmp             x4, #1
    // 0x68b070: b.ls            #0x68b088
    // 0x68b074: r8 = BoxConstraints
    //     0x68b074: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x68b078: ldr             x8, [x8, #0x1d0]
    // 0x68b07c: r3 = Null
    //     0x68b07c: add             x3, PP, #0x56, lsl #12  ; [pp+0x567c8] Null
    //     0x68b080: ldr             x3, [x3, #0x7c8]
    // 0x68b084: r0 = BoxConstraints()
    //     0x68b084: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x68b088: ldur            x0, [fp, #-8]
    // 0x68b08c: LoadField: d0 = r0->field_7
    //     0x68b08c: ldur            d0, [x0, #7]
    // 0x68b090: LoadField: d1 = r0->field_f
    //     0x68b090: ldur            d1, [x0, #0xf]
    // 0x68b094: r0 = inline_Allocate_Double()
    //     0x68b094: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x68b098: add             x0, x0, #0x10
    //     0x68b09c: cmp             x1, x0
    //     0x68b0a0: b.ls            #0x68b660
    //     0x68b0a4: str             x0, [THR, #0x60]  ; THR::top
    //     0x68b0a8: sub             x0, x0, #0xf
    //     0x68b0ac: mov             x1, #0xd108
    //     0x68b0b0: movk            x1, #3, lsl #16
    //     0x68b0b4: stur            x1, [x0, #-1]
    // 0x68b0b8: StoreField: r0->field_7 = d0
    //     0x68b0b8: stur            d0, [x0, #7]
    // 0x68b0bc: r1 = inline_Allocate_Double()
    //     0x68b0bc: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x68b0c0: add             x1, x1, #0x10
    //     0x68b0c4: cmp             x2, x1
    //     0x68b0c8: b.ls            #0x68b670
    //     0x68b0cc: str             x1, [THR, #0x60]  ; THR::top
    //     0x68b0d0: sub             x1, x1, #0xf
    //     0x68b0d4: mov             x2, #0xd108
    //     0x68b0d8: movk            x2, #3, lsl #16
    //     0x68b0dc: stur            x2, [x1, #-1]
    // 0x68b0e0: StoreField: r1->field_7 = d1
    //     0x68b0e0: stur            d1, [x1, #7]
    // 0x68b0e4: ldr             x16, [fp, #0x10]
    // 0x68b0e8: stp             x0, x16, [SP, #-0x10]!
    // 0x68b0ec: r16 = true
    //     0x68b0ec: add             x16, NULL, #0x20  ; true
    // 0x68b0f0: stp             x16, x1, [SP, #-0x10]!
    // 0x68b0f4: r4 = const [0, 0x4, 0x4, 0x1, forceLayout, 0x3, maxWidth, 0x2, minWidth, 0x1, null]
    //     0x68b0f4: add             x4, PP, #0x56, lsl #12  ; [pp+0x567d8] List(11) [0, 0x4, 0x4, 0x1, "forceLayout", 0x3, "maxWidth", 0x2, "minWidth", 0x1, Null]
    //     0x68b0f8: ldr             x4, [x4, #0x7d8]
    // 0x68b0fc: r0 = layoutText()
    //     0x68b0fc: bl              #0x52312c  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::layoutText
    // 0x68b100: add             SP, SP, #0x20
    // 0x68b104: ldr             x16, [fp, #0x10]
    // 0x68b108: SaveReg r16
    //     0x68b108: str             x16, [SP, #-8]!
    // 0x68b10c: r0 = setParentData()
    //     0x68b10c: bl              #0x68c1cc  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::setParentData
    // 0x68b110: add             SP, SP, #8
    // 0x68b114: ldr             x16, [fp, #0x10]
    // 0x68b118: SaveReg r16
    //     0x68b118: str             x16, [SP, #-8]!
    // 0x68b11c: r0 = _computeCaretPrototype()
    //     0x68b11c: bl              #0x68c020  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_computeCaretPrototype
    // 0x68b120: add             SP, SP, #8
    // 0x68b124: ldr             x0, [fp, #0x10]
    // 0x68b128: LoadField: r1 = r0->field_eb
    //     0x68b128: ldur            w1, [x0, #0xeb]
    // 0x68b12c: DecompressPointer r1
    //     0x68b12c: add             x1, x1, HEAP, lsl #32
    // 0x68b130: stur            x1, [fp, #-8]
    // 0x68b134: LoadField: r2 = r1->field_7
    //     0x68b134: ldur            w2, [x1, #7]
    // 0x68b138: DecompressPointer r2
    //     0x68b138: add             x2, x2, HEAP, lsl #32
    // 0x68b13c: cmp             w2, NULL
    // 0x68b140: b.eq            #0x68b68c
    // 0x68b144: SaveReg r2
    //     0x68b144: str             x2, [SP, #-8]!
    // 0x68b148: r0 = width()
    //     0x68b148: bl              #0x520ee4  ; [dart:ui] Paragraph::width
    // 0x68b14c: add             SP, SP, #8
    // 0x68b150: stp             fp, lr, [SP, #-0x10]!
    // 0x68b154: mov             fp, SP
    // 0x68b158: CallRuntime_LibcCeil(double) -> double
    //     0x68b158: and             SP, SP, #0xfffffffffffffff0
    //     0x68b15c: mov             sp, SP
    //     0x68b160: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x68b164: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x68b168: blr             x16
    //     0x68b16c: mov             x16, #8
    //     0x68b170: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x68b174: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x68b178: sub             sp, x16, #1, lsl #12
    //     0x68b17c: mov             SP, fp
    //     0x68b180: ldp             fp, lr, [SP], #0x10
    // 0x68b184: ldur            x0, [fp, #-8]
    // 0x68b188: stur            d0, [fp, #-0x18]
    // 0x68b18c: LoadField: r1 = r0->field_7
    //     0x68b18c: ldur            w1, [x0, #7]
    // 0x68b190: DecompressPointer r1
    //     0x68b190: add             x1, x1, HEAP, lsl #32
    // 0x68b194: cmp             w1, NULL
    // 0x68b198: b.eq            #0x68b690
    // 0x68b19c: SaveReg r1
    //     0x68b19c: str             x1, [SP, #-8]!
    // 0x68b1a0: r0 = height()
    //     0x68b1a0: bl              #0x51a4dc  ; [dart:ui] Paragraph::height
    // 0x68b1a4: add             SP, SP, #8
    // 0x68b1a8: stp             fp, lr, [SP, #-0x10]!
    // 0x68b1ac: mov             fp, SP
    // 0x68b1b0: CallRuntime_LibcCeil(double) -> double
    //     0x68b1b0: and             SP, SP, #0xfffffffffffffff0
    //     0x68b1b4: mov             sp, SP
    //     0x68b1b8: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x68b1bc: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x68b1c0: blr             x16
    //     0x68b1c4: mov             x16, #8
    //     0x68b1c8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x68b1cc: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x68b1d0: sub             sp, x16, #1, lsl #12
    //     0x68b1d4: mov             SP, fp
    //     0x68b1d8: ldp             fp, lr, [SP], #0x10
    // 0x68b1dc: ldr             x3, [fp, #0x10]
    // 0x68b1e0: stur            d0, [fp, #-0x20]
    // 0x68b1e4: LoadField: r0 = r3->field_fb
    //     0x68b1e4: ldur            w0, [x3, #0xfb]
    // 0x68b1e8: DecompressPointer r0
    //     0x68b1e8: add             x0, x0, HEAP, lsl #32
    // 0x68b1ec: tbnz            w0, #4, #0x68b24c
    // 0x68b1f0: LoadField: r4 = r3->field_27
    //     0x68b1f0: ldur            w4, [x3, #0x27]
    // 0x68b1f4: DecompressPointer r4
    //     0x68b1f4: add             x4, x4, HEAP, lsl #32
    // 0x68b1f8: stur            x4, [fp, #-0x10]
    // 0x68b1fc: cmp             w4, NULL
    // 0x68b200: b.eq            #0x68b608
    // 0x68b204: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68b204: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68b208: ldr             x5, [x5, #0x1e8]
    // 0x68b20c: mov             x0, x4
    // 0x68b210: r2 = Null
    //     0x68b210: mov             x2, NULL
    // 0x68b214: r1 = Null
    //     0x68b214: mov             x1, NULL
    // 0x68b218: r4 = LoadClassIdInstr(r0)
    //     0x68b218: ldur            x4, [x0, #-1]
    //     0x68b21c: ubfx            x4, x4, #0xc, #0x14
    // 0x68b220: sub             x4, x4, #0x80d
    // 0x68b224: cmp             x4, #1
    // 0x68b228: b.ls            #0x68b240
    // 0x68b22c: r8 = BoxConstraints
    //     0x68b22c: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x68b230: ldr             x8, [x8, #0x1d0]
    // 0x68b234: r3 = Null
    //     0x68b234: add             x3, PP, #0x56, lsl #12  ; [pp+0x567e0] Null
    //     0x68b238: ldr             x3, [x3, #0x7e0]
    // 0x68b23c: r0 = BoxConstraints()
    //     0x68b23c: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x68b240: ldur            x0, [fp, #-0x10]
    // 0x68b244: LoadField: d0 = r0->field_f
    //     0x68b244: ldur            d0, [x0, #0xf]
    // 0x68b248: b               #0x68b378
    // 0x68b24c: LoadField: r4 = r3->field_27
    //     0x68b24c: ldur            w4, [x3, #0x27]
    // 0x68b250: DecompressPointer r4
    //     0x68b250: add             x4, x4, HEAP, lsl #32
    // 0x68b254: stur            x4, [fp, #-0x10]
    // 0x68b258: cmp             w4, NULL
    // 0x68b25c: b.eq            #0x68b620
    // 0x68b260: ldur            x6, [fp, #-8]
    // 0x68b264: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68b264: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68b268: ldr             x5, [x5, #0x1e8]
    // 0x68b26c: mov             x0, x4
    // 0x68b270: r2 = Null
    //     0x68b270: mov             x2, NULL
    // 0x68b274: r1 = Null
    //     0x68b274: mov             x1, NULL
    // 0x68b278: r4 = LoadClassIdInstr(r0)
    //     0x68b278: ldur            x4, [x0, #-1]
    //     0x68b27c: ubfx            x4, x4, #0xc, #0x14
    // 0x68b280: sub             x4, x4, #0x80d
    // 0x68b284: cmp             x4, #1
    // 0x68b288: b.ls            #0x68b2a0
    // 0x68b28c: r8 = BoxConstraints
    //     0x68b28c: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x68b290: ldr             x8, [x8, #0x1d0]
    // 0x68b294: r3 = Null
    //     0x68b294: add             x3, PP, #0x56, lsl #12  ; [pp+0x567f0] Null
    //     0x68b298: ldr             x3, [x3, #0x7f0]
    // 0x68b29c: r0 = BoxConstraints()
    //     0x68b29c: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x68b2a0: ldur            x0, [fp, #-8]
    // 0x68b2a4: LoadField: r1 = r0->field_7
    //     0x68b2a4: ldur            w1, [x0, #7]
    // 0x68b2a8: DecompressPointer r1
    //     0x68b2a8: add             x1, x1, HEAP, lsl #32
    // 0x68b2ac: cmp             w1, NULL
    // 0x68b2b0: b.eq            #0x68b694
    // 0x68b2b4: SaveReg r1
    //     0x68b2b4: str             x1, [SP, #-8]!
    // 0x68b2b8: r0 = width()
    //     0x68b2b8: bl              #0x520ee4  ; [dart:ui] Paragraph::width
    // 0x68b2bc: add             SP, SP, #8
    // 0x68b2c0: stp             fp, lr, [SP, #-0x10]!
    // 0x68b2c4: mov             fp, SP
    // 0x68b2c8: CallRuntime_LibcCeil(double) -> double
    //     0x68b2c8: and             SP, SP, #0xfffffffffffffff0
    //     0x68b2cc: mov             sp, SP
    //     0x68b2d0: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x68b2d4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x68b2d8: blr             x16
    //     0x68b2dc: mov             x16, #8
    //     0x68b2e0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x68b2e4: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x68b2e8: sub             sp, x16, #1, lsl #12
    //     0x68b2ec: mov             SP, fp
    //     0x68b2f0: ldp             fp, lr, [SP], #0x10
    // 0x68b2f4: ldur            x0, [fp, #-8]
    // 0x68b2f8: stur            d0, [fp, #-0x28]
    // 0x68b2fc: LoadField: r1 = r0->field_7
    //     0x68b2fc: ldur            w1, [x0, #7]
    // 0x68b300: DecompressPointer r1
    //     0x68b300: add             x1, x1, HEAP, lsl #32
    // 0x68b304: cmp             w1, NULL
    // 0x68b308: b.eq            #0x68b698
    // 0x68b30c: SaveReg r1
    //     0x68b30c: str             x1, [SP, #-8]!
    // 0x68b310: r0 = height()
    //     0x68b310: bl              #0x51a4dc  ; [dart:ui] Paragraph::height
    // 0x68b314: add             SP, SP, #8
    // 0x68b318: ldr             x0, [fp, #0x10]
    // 0x68b31c: r17 = 279
    //     0x68b31c: mov             x17, #0x117
    // 0x68b320: ldr             w1, [x0, x17]
    // 0x68b324: DecompressPointer r1
    //     0x68b324: add             x1, x1, HEAP, lsl #32
    // 0x68b328: LoadField: d0 = r1->field_7
    //     0x68b328: ldur            d0, [x1, #7]
    // 0x68b32c: d1 = 1.000000
    //     0x68b32c: fmov            d1, #1.00000000
    // 0x68b330: fadd            d2, d1, d0
    // 0x68b334: ldur            d0, [fp, #-0x28]
    // 0x68b338: fadd            d3, d0, d2
    // 0x68b33c: r1 = inline_Allocate_Double()
    //     0x68b33c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x68b340: add             x1, x1, #0x10
    //     0x68b344: cmp             x2, x1
    //     0x68b348: b.ls            #0x68b69c
    //     0x68b34c: str             x1, [THR, #0x60]  ; THR::top
    //     0x68b350: sub             x1, x1, #0xf
    //     0x68b354: mov             x2, #0xd108
    //     0x68b358: movk            x2, #3, lsl #16
    //     0x68b35c: stur            x2, [x1, #-1]
    // 0x68b360: StoreField: r1->field_7 = d3
    //     0x68b360: stur            d3, [x1, #7]
    // 0x68b364: ldur            x16, [fp, #-0x10]
    // 0x68b368: stp             x1, x16, [SP, #-0x10]!
    // 0x68b36c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x68b36c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x68b370: r0 = constrainWidth()
    //     0x68b370: bl              #0x62bc8c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0x68b374: add             SP, SP, #0x10
    // 0x68b378: ldr             x3, [fp, #0x10]
    // 0x68b37c: stur            d0, [fp, #-0x28]
    // 0x68b380: LoadField: r4 = r3->field_27
    //     0x68b380: ldur            w4, [x3, #0x27]
    // 0x68b384: DecompressPointer r4
    //     0x68b384: add             x4, x4, HEAP, lsl #32
    // 0x68b388: stur            x4, [fp, #-8]
    // 0x68b38c: cmp             w4, NULL
    // 0x68b390: b.eq            #0x68b638
    // 0x68b394: ldur            d2, [fp, #-0x18]
    // 0x68b398: ldur            d1, [fp, #-0x20]
    // 0x68b39c: mov             x0, x4
    // 0x68b3a0: r2 = Null
    //     0x68b3a0: mov             x2, NULL
    // 0x68b3a4: r1 = Null
    //     0x68b3a4: mov             x1, NULL
    // 0x68b3a8: r4 = LoadClassIdInstr(r0)
    //     0x68b3a8: ldur            x4, [x0, #-1]
    //     0x68b3ac: ubfx            x4, x4, #0xc, #0x14
    // 0x68b3b0: sub             x4, x4, #0x80d
    // 0x68b3b4: cmp             x4, #1
    // 0x68b3b8: b.ls            #0x68b3d0
    // 0x68b3bc: r8 = BoxConstraints
    //     0x68b3bc: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x68b3c0: ldr             x8, [x8, #0x1d0]
    // 0x68b3c4: r3 = Null
    //     0x68b3c4: add             x3, PP, #0x56, lsl #12  ; [pp+0x56800] Null
    //     0x68b3c8: ldr             x3, [x3, #0x800]
    // 0x68b3cc: r0 = BoxConstraints()
    //     0x68b3cc: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x68b3d0: ldur            x0, [fp, #-8]
    // 0x68b3d4: LoadField: d0 = r0->field_f
    //     0x68b3d4: ldur            d0, [x0, #0xf]
    // 0x68b3d8: ldr             x16, [fp, #0x10]
    // 0x68b3dc: SaveReg r16
    //     0x68b3dc: str             x16, [SP, #-8]!
    // 0x68b3e0: SaveReg d0
    //     0x68b3e0: str             d0, [SP, #-8]!
    // 0x68b3e4: r0 = _preferredHeight()
    //     0x68b3e4: bl              #0x68b97c  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_preferredHeight
    // 0x68b3e8: add             SP, SP, #0x10
    // 0x68b3ec: r0 = inline_Allocate_Double()
    //     0x68b3ec: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x68b3f0: add             x0, x0, #0x10
    //     0x68b3f4: cmp             x1, x0
    //     0x68b3f8: b.ls            #0x68b6b8
    //     0x68b3fc: str             x0, [THR, #0x60]  ; THR::top
    //     0x68b400: sub             x0, x0, #0xf
    //     0x68b404: mov             x1, #0xd108
    //     0x68b408: movk            x1, #3, lsl #16
    //     0x68b40c: stur            x1, [x0, #-1]
    // 0x68b410: StoreField: r0->field_7 = d0
    //     0x68b410: stur            d0, [x0, #7]
    // 0x68b414: ldur            x16, [fp, #-8]
    // 0x68b418: stp             x0, x16, [SP, #-0x10]!
    // 0x68b41c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x68b41c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x68b420: r0 = constrainHeight()
    //     0x68b420: bl              #0x62bc00  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0x68b424: add             SP, SP, #0x10
    // 0x68b428: stur            d0, [fp, #-0x30]
    // 0x68b42c: r0 = Size()
    //     0x68b42c: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x68b430: ldur            d0, [fp, #-0x28]
    // 0x68b434: StoreField: r0->field_7 = d0
    //     0x68b434: stur            d0, [x0, #7]
    // 0x68b438: ldur            d0, [fp, #-0x30]
    // 0x68b43c: StoreField: r0->field_f = d0
    //     0x68b43c: stur            d0, [x0, #0xf]
    // 0x68b440: ldr             x1, [fp, #0x10]
    // 0x68b444: StoreField: r1->field_57 = r0
    //     0x68b444: stur            w0, [x1, #0x57]
    //     0x68b448: ldurb           w16, [x1, #-1]
    //     0x68b44c: ldurb           w17, [x0, #-1]
    //     0x68b450: and             x16, x17, x16, lsr #2
    //     0x68b454: tst             x16, HEAP, lsr #32
    //     0x68b458: b.eq            #0x68b460
    //     0x68b45c: bl              #0xd6826c
    // 0x68b460: r17 = 279
    //     0x68b460: mov             x17, #0x117
    // 0x68b464: ldr             w0, [x1, x17]
    // 0x68b468: DecompressPointer r0
    //     0x68b468: add             x0, x0, HEAP, lsl #32
    // 0x68b46c: LoadField: d0 = r0->field_7
    //     0x68b46c: ldur            d0, [x0, #7]
    // 0x68b470: d1 = 1.000000
    //     0x68b470: fmov            d1, #1.00000000
    // 0x68b474: fadd            d2, d1, d0
    // 0x68b478: ldur            d0, [fp, #-0x18]
    // 0x68b47c: fadd            d1, d0, d2
    // 0x68b480: stur            d1, [fp, #-0x28]
    // 0x68b484: r0 = Size()
    //     0x68b484: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x68b488: ldur            d0, [fp, #-0x28]
    // 0x68b48c: stur            x0, [fp, #-8]
    // 0x68b490: StoreField: r0->field_7 = d0
    //     0x68b490: stur            d0, [x0, #7]
    // 0x68b494: ldur            d1, [fp, #-0x20]
    // 0x68b498: StoreField: r0->field_f = d1
    //     0x68b498: stur            d1, [x0, #0xf]
    // 0x68b49c: r0 = BoxConstraints()
    //     0x68b49c: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x68b4a0: ldur            d0, [fp, #-0x28]
    // 0x68b4a4: stur            x0, [fp, #-0x10]
    // 0x68b4a8: StoreField: r0->field_7 = d0
    //     0x68b4a8: stur            d0, [x0, #7]
    // 0x68b4ac: StoreField: r0->field_f = d0
    //     0x68b4ac: stur            d0, [x0, #0xf]
    // 0x68b4b0: ldur            d0, [fp, #-0x20]
    // 0x68b4b4: StoreField: r0->field_17 = d0
    //     0x68b4b4: stur            d0, [x0, #0x17]
    // 0x68b4b8: StoreField: r0->field_1f = d0
    //     0x68b4b8: stur            d0, [x0, #0x1f]
    // 0x68b4bc: ldr             x1, [fp, #0x10]
    // 0x68b4c0: LoadField: r2 = r1->field_9b
    //     0x68b4c0: ldur            w2, [x1, #0x9b]
    // 0x68b4c4: DecompressPointer r2
    //     0x68b4c4: add             x2, x2, HEAP, lsl #32
    // 0x68b4c8: cmp             w2, NULL
    // 0x68b4cc: b.ne            #0x68b4d8
    // 0x68b4d0: mov             x0, x1
    // 0x68b4d4: b               #0x68b4ec
    // 0x68b4d8: stp             x0, x2, [SP, #-0x10]!
    // 0x68b4dc: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x68b4dc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x68b4e0: r0 = layout()
    //     0x68b4e0: bl              #0x6e6cc0  ; [package:flutter/src/rendering/box.dart] RenderBox::layout
    // 0x68b4e4: add             SP, SP, #0x10
    // 0x68b4e8: ldr             x0, [fp, #0x10]
    // 0x68b4ec: LoadField: r1 = r0->field_9f
    //     0x68b4ec: ldur            w1, [x0, #0x9f]
    // 0x68b4f0: DecompressPointer r1
    //     0x68b4f0: add             x1, x1, HEAP, lsl #32
    // 0x68b4f4: cmp             w1, NULL
    // 0x68b4f8: b.eq            #0x68b514
    // 0x68b4fc: ldur            x16, [fp, #-0x10]
    // 0x68b500: stp             x16, x1, [SP, #-0x10]!
    // 0x68b504: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x68b504: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x68b508: r0 = layout()
    //     0x68b508: bl              #0x6e6cc0  ; [package:flutter/src/rendering/box.dart] RenderBox::layout
    // 0x68b50c: add             SP, SP, #0x10
    // 0x68b510: ldr             x0, [fp, #0x10]
    // 0x68b514: ldur            x16, [fp, #-8]
    // 0x68b518: stp             x16, x0, [SP, #-0x10]!
    // 0x68b51c: r0 = _getMaxScrollExtent()
    //     0x68b51c: bl              #0x68b7c0  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_getMaxScrollExtent
    // 0x68b520: add             SP, SP, #0x10
    // 0x68b524: ldr             x1, [fp, #0x10]
    // 0x68b528: r17 = 315
    //     0x68b528: mov             x17, #0x13b
    // 0x68b52c: str             w0, [x1, x17]
    // 0x68b530: WriteBarrierInstr(obj = r1, val = r0)
    //     0x68b530: ldurb           w16, [x1, #-1]
    //     0x68b534: ldurb           w17, [x0, #-1]
    //     0x68b538: and             x16, x17, x16, lsr #2
    //     0x68b53c: tst             x16, HEAP, lsr #32
    //     0x68b540: b.eq            #0x68b548
    //     0x68b544: bl              #0xd6826c
    // 0x68b548: r17 = 275
    //     0x68b548: mov             x17, #0x113
    // 0x68b54c: ldr             w0, [x1, x17]
    // 0x68b550: DecompressPointer r0
    //     0x68b550: add             x0, x0, HEAP, lsl #32
    // 0x68b554: stur            x0, [fp, #-8]
    // 0x68b558: SaveReg r1
    //     0x68b558: str             x1, [SP, #-8]!
    // 0x68b55c: r0 = _viewportExtent()
    //     0x68b55c: bl              #0x68b6c8  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_viewportExtent
    // 0x68b560: add             SP, SP, #8
    // 0x68b564: mov             x1, x0
    // 0x68b568: ldur            x0, [fp, #-8]
    // 0x68b56c: r2 = LoadClassIdInstr(r0)
    //     0x68b56c: ldur            x2, [x0, #-1]
    //     0x68b570: ubfx            x2, x2, #0xc, #0x14
    // 0x68b574: stp             x1, x0, [SP, #-0x10]!
    // 0x68b578: mov             x0, x2
    // 0x68b57c: r0 = GDT[cid_x0 + 0x112]()
    //     0x68b57c: add             lr, x0, #0x112
    //     0x68b580: ldr             lr, [x21, lr, lsl #3]
    //     0x68b584: blr             lr
    // 0x68b588: add             SP, SP, #0x10
    // 0x68b58c: ldr             x0, [fp, #0x10]
    // 0x68b590: r17 = 275
    //     0x68b590: mov             x17, #0x113
    // 0x68b594: ldr             w1, [x0, x17]
    // 0x68b598: DecompressPointer r1
    //     0x68b598: add             x1, x1, HEAP, lsl #32
    // 0x68b59c: r17 = 315
    //     0x68b59c: mov             x17, #0x13b
    // 0x68b5a0: ldr             w2, [x0, x17]
    // 0x68b5a4: DecompressPointer r2
    //     0x68b5a4: add             x2, x2, HEAP, lsl #32
    // 0x68b5a8: r0 = LoadClassIdInstr(r1)
    //     0x68b5a8: ldur            x0, [x1, #-1]
    //     0x68b5ac: ubfx            x0, x0, #0xc, #0x14
    // 0x68b5b0: stp             xzr, x1, [SP, #-0x10]!
    // 0x68b5b4: SaveReg r2
    //     0x68b5b4: str             x2, [SP, #-8]!
    // 0x68b5b8: r0 = GDT[cid_x0 + -0x217]()
    //     0x68b5b8: sub             lr, x0, #0x217
    //     0x68b5bc: ldr             lr, [x21, lr, lsl #3]
    //     0x68b5c0: blr             lr
    // 0x68b5c4: add             SP, SP, #0x18
    // 0x68b5c8: r0 = Null
    //     0x68b5c8: mov             x0, NULL
    // 0x68b5cc: LeaveFrame
    //     0x68b5cc: mov             SP, fp
    //     0x68b5d0: ldp             fp, lr, [SP], #0x10
    // 0x68b5d4: ret
    //     0x68b5d4: ret             
    // 0x68b5d8: r0 = StateError()
    //     0x68b5d8: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68b5dc: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68b5dc: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68b5e0: ldr             x5, [x5, #0x1e8]
    // 0x68b5e4: StoreField: r0->field_b = r5
    //     0x68b5e4: stur            w5, [x0, #0xb]
    // 0x68b5e8: r0 = Throw()
    //     0x68b5e8: bl              #0xd67e38  ; ThrowStub
    // 0x68b5ec: brk             #0
    // 0x68b5f0: r0 = StateError()
    //     0x68b5f0: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68b5f4: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68b5f4: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68b5f8: ldr             x5, [x5, #0x1e8]
    // 0x68b5fc: StoreField: r0->field_b = r5
    //     0x68b5fc: stur            w5, [x0, #0xb]
    // 0x68b600: r0 = Throw()
    //     0x68b600: bl              #0xd67e38  ; ThrowStub
    // 0x68b604: brk             #0
    // 0x68b608: r0 = StateError()
    //     0x68b608: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68b60c: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68b60c: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68b610: ldr             x5, [x5, #0x1e8]
    // 0x68b614: StoreField: r0->field_b = r5
    //     0x68b614: stur            w5, [x0, #0xb]
    // 0x68b618: r0 = Throw()
    //     0x68b618: bl              #0xd67e38  ; ThrowStub
    // 0x68b61c: brk             #0
    // 0x68b620: r0 = StateError()
    //     0x68b620: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68b624: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68b624: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68b628: ldr             x5, [x5, #0x1e8]
    // 0x68b62c: StoreField: r0->field_b = r5
    //     0x68b62c: stur            w5, [x0, #0xb]
    // 0x68b630: r0 = Throw()
    //     0x68b630: bl              #0xd67e38  ; ThrowStub
    // 0x68b634: brk             #0
    // 0x68b638: r0 = StateError()
    //     0x68b638: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68b63c: mov             x1, x0
    // 0x68b640: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68b640: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68b644: ldr             x0, [x0, #0x1e8]
    // 0x68b648: StoreField: r1->field_b = r0
    //     0x68b648: stur            w0, [x1, #0xb]
    // 0x68b64c: mov             x0, x1
    // 0x68b650: r0 = Throw()
    //     0x68b650: bl              #0xd67e38  ; ThrowStub
    // 0x68b654: brk             #0
    // 0x68b658: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68b658: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68b65c: b               #0x68afc8
    // 0x68b660: stp             q0, q1, [SP, #-0x20]!
    // 0x68b664: r0 = AllocateDouble()
    //     0x68b664: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68b668: ldp             q0, q1, [SP], #0x20
    // 0x68b66c: b               #0x68b0b8
    // 0x68b670: SaveReg d1
    //     0x68b670: str             q1, [SP, #-0x10]!
    // 0x68b674: SaveReg r0
    //     0x68b674: str             x0, [SP, #-8]!
    // 0x68b678: r0 = AllocateDouble()
    //     0x68b678: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68b67c: mov             x1, x0
    // 0x68b680: RestoreReg r0
    //     0x68b680: ldr             x0, [SP], #8
    // 0x68b684: RestoreReg d1
    //     0x68b684: ldr             q1, [SP], #0x10
    // 0x68b688: b               #0x68b0e0
    // 0x68b68c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68b68c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68b690: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68b690: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x68b694: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68b694: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68b698: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68b698: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x68b69c: stp             q1, q3, [SP, #-0x20]!
    // 0x68b6a0: SaveReg r0
    //     0x68b6a0: str             x0, [SP, #-8]!
    // 0x68b6a4: r0 = AllocateDouble()
    //     0x68b6a4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68b6a8: mov             x1, x0
    // 0x68b6ac: RestoreReg r0
    //     0x68b6ac: ldr             x0, [SP], #8
    // 0x68b6b0: ldp             q1, q3, [SP], #0x20
    // 0x68b6b4: b               #0x68b360
    // 0x68b6b8: SaveReg d0
    //     0x68b6b8: str             q0, [SP, #-0x10]!
    // 0x68b6bc: r0 = AllocateDouble()
    //     0x68b6bc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68b6c0: RestoreReg d0
    //     0x68b6c0: ldr             q0, [SP], #0x10
    // 0x68b6c4: b               #0x68b410
  }
  get _ _viewportExtent(/* No info */) {
    // ** addr: 0x68b6c8, size: 0xf8
    // 0x68b6c8: EnterFrame
    //     0x68b6c8: stp             fp, lr, [SP, #-0x10]!
    //     0x68b6cc: mov             fp, SP
    // 0x68b6d0: ldr             x1, [fp, #0x10]
    // 0x68b6d4: r17 = 259
    //     0x68b6d4: mov             x17, #0x103
    // 0x68b6d8: ldr             w2, [x1, x17]
    // 0x68b6dc: DecompressPointer r2
    //     0x68b6dc: add             x2, x2, HEAP, lsl #32
    // 0x68b6e0: cmp             w2, #2
    // 0x68b6e4: b.eq            #0x68b6f4
    // 0x68b6e8: r2 = Instance_Axis
    //     0x68b6e8: add             x2, PP, #0xe, lsl #12  ; [pp+0xef00] Obj!Axis@b64ff1
    //     0x68b6ec: ldr             x2, [x2, #0xf00]
    // 0x68b6f0: b               #0x68b6fc
    // 0x68b6f4: r2 = Instance_Axis
    //     0x68b6f4: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x68b6f8: ldr             x2, [x2, #0x440]
    // 0x68b6fc: LoadField: r3 = r2->field_7
    //     0x68b6fc: ldur            x3, [x2, #7]
    // 0x68b700: cmp             x3, #0
    // 0x68b704: b.gt            #0x68b750
    // 0x68b708: LoadField: r2 = r1->field_57
    //     0x68b708: ldur            w2, [x1, #0x57]
    // 0x68b70c: DecompressPointer r2
    //     0x68b70c: add             x2, x2, HEAP, lsl #32
    // 0x68b710: cmp             w2, NULL
    // 0x68b714: b.eq            #0x68b798
    // 0x68b718: LoadField: d0 = r2->field_7
    //     0x68b718: ldur            d0, [x2, #7]
    // 0x68b71c: r0 = inline_Allocate_Double()
    //     0x68b71c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x68b720: add             x0, x0, #0x10
    //     0x68b724: cmp             x2, x0
    //     0x68b728: b.ls            #0x68b79c
    //     0x68b72c: str             x0, [THR, #0x60]  ; THR::top
    //     0x68b730: sub             x0, x0, #0xf
    //     0x68b734: mov             x2, #0xd108
    //     0x68b738: movk            x2, #3, lsl #16
    //     0x68b73c: stur            x2, [x0, #-1]
    // 0x68b740: StoreField: r0->field_7 = d0
    //     0x68b740: stur            d0, [x0, #7]
    // 0x68b744: LeaveFrame
    //     0x68b744: mov             SP, fp
    //     0x68b748: ldp             fp, lr, [SP], #0x10
    // 0x68b74c: ret
    //     0x68b74c: ret             
    // 0x68b750: LoadField: r2 = r1->field_57
    //     0x68b750: ldur            w2, [x1, #0x57]
    // 0x68b754: DecompressPointer r2
    //     0x68b754: add             x2, x2, HEAP, lsl #32
    // 0x68b758: cmp             w2, NULL
    // 0x68b75c: b.eq            #0x68b7ac
    // 0x68b760: LoadField: d0 = r2->field_f
    //     0x68b760: ldur            d0, [x2, #0xf]
    // 0x68b764: r0 = inline_Allocate_Double()
    //     0x68b764: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x68b768: add             x0, x0, #0x10
    //     0x68b76c: cmp             x1, x0
    //     0x68b770: b.ls            #0x68b7b0
    //     0x68b774: str             x0, [THR, #0x60]  ; THR::top
    //     0x68b778: sub             x0, x0, #0xf
    //     0x68b77c: mov             x1, #0xd108
    //     0x68b780: movk            x1, #3, lsl #16
    //     0x68b784: stur            x1, [x0, #-1]
    // 0x68b788: StoreField: r0->field_7 = d0
    //     0x68b788: stur            d0, [x0, #7]
    // 0x68b78c: LeaveFrame
    //     0x68b78c: mov             SP, fp
    //     0x68b790: ldp             fp, lr, [SP], #0x10
    // 0x68b794: ret
    //     0x68b794: ret             
    // 0x68b798: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68b798: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68b79c: SaveReg d0
    //     0x68b79c: str             q0, [SP, #-0x10]!
    // 0x68b7a0: r0 = AllocateDouble()
    //     0x68b7a0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68b7a4: RestoreReg d0
    //     0x68b7a4: ldr             q0, [SP], #0x10
    // 0x68b7a8: b               #0x68b740
    // 0x68b7ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68b7ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68b7b0: SaveReg d0
    //     0x68b7b0: str             q0, [SP, #-0x10]!
    // 0x68b7b4: r0 = AllocateDouble()
    //     0x68b7b4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68b7b8: RestoreReg d0
    //     0x68b7b8: ldr             q0, [SP], #0x10
    // 0x68b7bc: b               #0x68b788
  }
  _ _getMaxScrollExtent(/* No info */) {
    // ** addr: 0x68b7c0, size: 0x1bc
    // 0x68b7c0: EnterFrame
    //     0x68b7c0: stp             fp, lr, [SP, #-0x10]!
    //     0x68b7c4: mov             fp, SP
    // 0x68b7c8: ldr             x1, [fp, #0x18]
    // 0x68b7cc: r17 = 259
    //     0x68b7cc: mov             x17, #0x103
    // 0x68b7d0: ldr             w2, [x1, x17]
    // 0x68b7d4: DecompressPointer r2
    //     0x68b7d4: add             x2, x2, HEAP, lsl #32
    // 0x68b7d8: cmp             w2, #2
    // 0x68b7dc: b.eq            #0x68b7ec
    // 0x68b7e0: r2 = Instance_Axis
    //     0x68b7e0: add             x2, PP, #0xe, lsl #12  ; [pp+0xef00] Obj!Axis@b64ff1
    //     0x68b7e4: ldr             x2, [x2, #0xf00]
    // 0x68b7e8: b               #0x68b7f4
    // 0x68b7ec: r2 = Instance_Axis
    //     0x68b7ec: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x68b7f0: ldr             x2, [x2, #0x440]
    // 0x68b7f4: LoadField: r3 = r2->field_7
    //     0x68b7f4: ldur            x3, [x2, #7]
    // 0x68b7f8: cmp             x3, #0
    // 0x68b7fc: b.gt            #0x68b8a8
    // 0x68b800: ldr             x2, [fp, #0x10]
    // 0x68b804: d0 = 0.000000
    //     0x68b804: eor             v0.16b, v0.16b, v0.16b
    // 0x68b808: LoadField: d1 = r2->field_7
    //     0x68b808: ldur            d1, [x2, #7]
    // 0x68b80c: LoadField: r3 = r1->field_57
    //     0x68b80c: ldur            w3, [x1, #0x57]
    // 0x68b810: DecompressPointer r3
    //     0x68b810: add             x3, x3, HEAP, lsl #32
    // 0x68b814: cmp             w3, NULL
    // 0x68b818: b.eq            #0x68b954
    // 0x68b81c: LoadField: d2 = r3->field_7
    //     0x68b81c: ldur            d2, [x3, #7]
    // 0x68b820: fsub            d3, d1, d2
    // 0x68b824: fcmp            d0, d3
    // 0x68b828: b.vs            #0x68b838
    // 0x68b82c: b.le            #0x68b838
    // 0x68b830: d1 = 0.000000
    //     0x68b830: eor             v1.16b, v1.16b, v1.16b
    // 0x68b834: b               #0x68b874
    // 0x68b838: fcmp            d0, d3
    // 0x68b83c: b.vs            #0x68b84c
    // 0x68b840: b.ge            #0x68b84c
    // 0x68b844: mov             v1.16b, v3.16b
    // 0x68b848: b               #0x68b874
    // 0x68b84c: fcmp            d0, d0
    // 0x68b850: b.vs            #0x68b860
    // 0x68b854: b.ne            #0x68b860
    // 0x68b858: fadd            d1, d0, d3
    // 0x68b85c: b               #0x68b874
    // 0x68b860: fcmp            d3, d3
    // 0x68b864: b.vc            #0x68b870
    // 0x68b868: mov             v1.16b, v3.16b
    // 0x68b86c: b               #0x68b874
    // 0x68b870: d1 = 0.000000
    //     0x68b870: eor             v1.16b, v1.16b, v1.16b
    // 0x68b874: r0 = inline_Allocate_Double()
    //     0x68b874: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x68b878: add             x0, x0, #0x10
    //     0x68b87c: cmp             x3, x0
    //     0x68b880: b.ls            #0x68b958
    //     0x68b884: str             x0, [THR, #0x60]  ; THR::top
    //     0x68b888: sub             x0, x0, #0xf
    //     0x68b88c: mov             x3, #0xd108
    //     0x68b890: movk            x3, #3, lsl #16
    //     0x68b894: stur            x3, [x0, #-1]
    // 0x68b898: StoreField: r0->field_7 = d1
    //     0x68b898: stur            d1, [x0, #7]
    // 0x68b89c: LeaveFrame
    //     0x68b89c: mov             SP, fp
    //     0x68b8a0: ldp             fp, lr, [SP], #0x10
    // 0x68b8a4: ret
    //     0x68b8a4: ret             
    // 0x68b8a8: ldr             x2, [fp, #0x10]
    // 0x68b8ac: d0 = 0.000000
    //     0x68b8ac: eor             v0.16b, v0.16b, v0.16b
    // 0x68b8b0: LoadField: d1 = r2->field_f
    //     0x68b8b0: ldur            d1, [x2, #0xf]
    // 0x68b8b4: LoadField: r2 = r1->field_57
    //     0x68b8b4: ldur            w2, [x1, #0x57]
    // 0x68b8b8: DecompressPointer r2
    //     0x68b8b8: add             x2, x2, HEAP, lsl #32
    // 0x68b8bc: cmp             w2, NULL
    // 0x68b8c0: b.eq            #0x68b968
    // 0x68b8c4: LoadField: d2 = r2->field_f
    //     0x68b8c4: ldur            d2, [x2, #0xf]
    // 0x68b8c8: fsub            d3, d1, d2
    // 0x68b8cc: fcmp            d0, d3
    // 0x68b8d0: b.vs            #0x68b8e0
    // 0x68b8d4: b.le            #0x68b8e0
    // 0x68b8d8: d0 = 0.000000
    //     0x68b8d8: eor             v0.16b, v0.16b, v0.16b
    // 0x68b8dc: b               #0x68b920
    // 0x68b8e0: fcmp            d0, d3
    // 0x68b8e4: b.vs            #0x68b8f4
    // 0x68b8e8: b.ge            #0x68b8f4
    // 0x68b8ec: mov             v0.16b, v3.16b
    // 0x68b8f0: b               #0x68b920
    // 0x68b8f4: fcmp            d0, d0
    // 0x68b8f8: b.vs            #0x68b90c
    // 0x68b8fc: b.ne            #0x68b90c
    // 0x68b900: fadd            d1, d0, d3
    // 0x68b904: mov             v0.16b, v1.16b
    // 0x68b908: b               #0x68b920
    // 0x68b90c: fcmp            d3, d3
    // 0x68b910: b.vc            #0x68b91c
    // 0x68b914: mov             v0.16b, v3.16b
    // 0x68b918: b               #0x68b920
    // 0x68b91c: d0 = 0.000000
    //     0x68b91c: eor             v0.16b, v0.16b, v0.16b
    // 0x68b920: r0 = inline_Allocate_Double()
    //     0x68b920: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x68b924: add             x0, x0, #0x10
    //     0x68b928: cmp             x1, x0
    //     0x68b92c: b.ls            #0x68b96c
    //     0x68b930: str             x0, [THR, #0x60]  ; THR::top
    //     0x68b934: sub             x0, x0, #0xf
    //     0x68b938: mov             x1, #0xd108
    //     0x68b93c: movk            x1, #3, lsl #16
    //     0x68b940: stur            x1, [x0, #-1]
    // 0x68b944: StoreField: r0->field_7 = d0
    //     0x68b944: stur            d0, [x0, #7]
    // 0x68b948: LeaveFrame
    //     0x68b948: mov             SP, fp
    //     0x68b94c: ldp             fp, lr, [SP], #0x10
    // 0x68b950: ret
    //     0x68b950: ret             
    // 0x68b954: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68b954: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x68b958: SaveReg d1
    //     0x68b958: str             q1, [SP, #-0x10]!
    // 0x68b95c: r0 = AllocateDouble()
    //     0x68b95c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68b960: RestoreReg d1
    //     0x68b960: ldr             q1, [SP], #0x10
    // 0x68b964: b               #0x68b898
    // 0x68b968: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68b968: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x68b96c: SaveReg d0
    //     0x68b96c: str             q0, [SP, #-0x10]!
    // 0x68b970: r0 = AllocateDouble()
    //     0x68b970: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68b974: RestoreReg d0
    //     0x68b974: ldr             q0, [SP], #0x10
    // 0x68b978: b               #0x68b944
  }
  _ _preferredHeight(/* No info */) {
    // ** addr: 0x68b97c, size: 0x440
    // 0x68b97c: EnterFrame
    //     0x68b97c: stp             fp, lr, [SP, #-0x10]!
    //     0x68b980: mov             fp, SP
    // 0x68b984: AllocStack(0x28)
    //     0x68b984: sub             SP, SP, #0x28
    // 0x68b988: CheckStackOverflow
    //     0x68b988: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68b98c: cmp             SP, x16
    //     0x68b990: b.ls            #0x68bd64
    // 0x68b994: ldr             x0, [fp, #0x18]
    // 0x68b998: r17 = 259
    //     0x68b998: mov             x17, #0x103
    // 0x68b99c: ldr             w1, [x0, x17]
    // 0x68b9a0: DecompressPointer r1
    //     0x68b9a0: add             x1, x1, HEAP, lsl #32
    // 0x68b9a4: cmp             w1, NULL
    // 0x68b9a8: b.eq            #0x68b9b4
    // 0x68b9ac: r2 = true
    //     0x68b9ac: add             x2, NULL, #0x20  ; true
    // 0x68b9b0: b               #0x68b9b8
    // 0x68b9b4: r2 = false
    //     0x68b9b4: add             x2, NULL, #0x30  ; false
    // 0x68b9b8: cmp             w1, #2
    // 0x68b9bc: b.eq            #0x68b9c4
    // 0x68b9c0: tbnz            w2, #4, #0x68ba0c
    // 0x68b9c4: LoadField: r1 = r0->field_eb
    //     0x68b9c4: ldur            w1, [x0, #0xeb]
    // 0x68b9c8: DecompressPointer r1
    //     0x68b9c8: add             x1, x1, HEAP, lsl #32
    // 0x68b9cc: SaveReg r1
    //     0x68b9cc: str             x1, [SP, #-8]!
    // 0x68b9d0: r0 = preferredLineHeight()
    //     0x68b9d0: bl              #0x51a438  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0x68b9d4: add             SP, SP, #8
    // 0x68b9d8: ldr             x0, [fp, #0x18]
    // 0x68b9dc: r17 = 259
    //     0x68b9dc: mov             x17, #0x103
    // 0x68b9e0: ldr             w1, [x0, x17]
    // 0x68b9e4: DecompressPointer r1
    //     0x68b9e4: add             x1, x1, HEAP, lsl #32
    // 0x68b9e8: cmp             w1, NULL
    // 0x68b9ec: b.eq            #0x68bd6c
    // 0x68b9f0: r16 = LoadInt32Instr(r1)
    //     0x68b9f0: sbfx            x16, x1, #1, #0x1f
    // 0x68b9f4: scvtf           d1, w16
    // 0x68b9f8: fmul            d2, d0, d1
    // 0x68b9fc: mov             v0.16b, v2.16b
    // 0x68ba00: LeaveFrame
    //     0x68ba00: mov             SP, fp
    //     0x68ba04: ldp             fp, lr, [SP], #0x10
    // 0x68ba08: ret
    //     0x68ba08: ret             
    // 0x68ba0c: cmp             w1, NULL
    // 0x68ba10: r16 = true
    //     0x68ba10: add             x16, NULL, #0x20  ; true
    // 0x68ba14: r17 = false
    //     0x68ba14: add             x17, NULL, #0x30  ; false
    // 0x68ba18: csel            x2, x16, x17, ne
    // 0x68ba1c: stur            x2, [fp, #-8]
    // 0x68ba20: tbnz            w2, #4, #0x68bb5c
    // 0x68ba24: ldr             d0, [fp, #0x10]
    // 0x68ba28: r1 = inline_Allocate_Double()
    //     0x68ba28: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x68ba2c: add             x1, x1, #0x10
    //     0x68ba30: cmp             x3, x1
    //     0x68ba34: b.ls            #0x68bd70
    //     0x68ba38: str             x1, [THR, #0x60]  ; THR::top
    //     0x68ba3c: sub             x1, x1, #0xf
    //     0x68ba40: mov             x3, #0xd108
    //     0x68ba44: movk            x3, #3, lsl #16
    //     0x68ba48: stur            x3, [x1, #-1]
    // 0x68ba4c: StoreField: r1->field_7 = d0
    //     0x68ba4c: stur            d0, [x1, #7]
    // 0x68ba50: stp             x1, x0, [SP, #-0x10]!
    // 0x68ba54: r4 = const [0, 0x2, 0x2, 0x1, maxWidth, 0x1, null]
    //     0x68ba54: add             x4, PP, #0x35, lsl #12  ; [pp+0x35c18] List(7) [0, 0x2, 0x2, 0x1, "maxWidth", 0x1, Null]
    //     0x68ba58: ldr             x4, [x4, #0xc18]
    // 0x68ba5c: r0 = layoutText()
    //     0x68ba5c: bl              #0x52312c  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::layoutText
    // 0x68ba60: add             SP, SP, #0x10
    // 0x68ba64: ldur            x0, [fp, #-8]
    // 0x68ba68: tbnz            w0, #4, #0x68bb58
    // 0x68ba6c: ldr             x0, [fp, #0x18]
    // 0x68ba70: LoadField: r1 = r0->field_eb
    //     0x68ba70: ldur            w1, [x0, #0xeb]
    // 0x68ba74: DecompressPointer r1
    //     0x68ba74: add             x1, x1, HEAP, lsl #32
    // 0x68ba78: stur            x1, [fp, #-8]
    // 0x68ba7c: LoadField: r2 = r1->field_7
    //     0x68ba7c: ldur            w2, [x1, #7]
    // 0x68ba80: DecompressPointer r2
    //     0x68ba80: add             x2, x2, HEAP, lsl #32
    // 0x68ba84: cmp             w2, NULL
    // 0x68ba88: b.eq            #0x68bd8c
    // 0x68ba8c: SaveReg r2
    //     0x68ba8c: str             x2, [SP, #-8]!
    // 0x68ba90: r0 = height()
    //     0x68ba90: bl              #0x51a4dc  ; [dart:ui] Paragraph::height
    // 0x68ba94: add             SP, SP, #8
    // 0x68ba98: stp             fp, lr, [SP, #-0x10]!
    // 0x68ba9c: mov             fp, SP
    // 0x68baa0: CallRuntime_LibcCeil(double) -> double
    //     0x68baa0: and             SP, SP, #0xfffffffffffffff0
    //     0x68baa4: mov             sp, SP
    //     0x68baa8: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x68baac: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x68bab0: blr             x16
    //     0x68bab4: mov             x16, #8
    //     0x68bab8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x68babc: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x68bac0: sub             sp, x16, #1, lsl #12
    //     0x68bac4: mov             SP, fp
    //     0x68bac8: ldp             fp, lr, [SP], #0x10
    // 0x68bacc: stur            d0, [fp, #-0x28]
    // 0x68bad0: ldur            x16, [fp, #-8]
    // 0x68bad4: SaveReg r16
    //     0x68bad4: str             x16, [SP, #-8]!
    // 0x68bad8: r0 = preferredLineHeight()
    //     0x68bad8: bl              #0x51a438  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0x68badc: add             SP, SP, #8
    // 0x68bae0: ldr             x0, [fp, #0x18]
    // 0x68bae4: r17 = 259
    //     0x68bae4: mov             x17, #0x103
    // 0x68bae8: ldr             w1, [x0, x17]
    // 0x68baec: DecompressPointer r1
    //     0x68baec: add             x1, x1, HEAP, lsl #32
    // 0x68baf0: cmp             w1, NULL
    // 0x68baf4: b.eq            #0x68bd90
    // 0x68baf8: r16 = LoadInt32Instr(r1)
    //     0x68baf8: sbfx            x16, x1, #1, #0x1f
    // 0x68bafc: scvtf           d1, w16
    // 0x68bb00: fmul            d2, d0, d1
    // 0x68bb04: ldur            d0, [fp, #-0x28]
    // 0x68bb08: fcmp            d0, d2
    // 0x68bb0c: b.vs            #0x68bb5c
    // 0x68bb10: b.le            #0x68bb5c
    // 0x68bb14: ldur            x16, [fp, #-8]
    // 0x68bb18: SaveReg r16
    //     0x68bb18: str             x16, [SP, #-8]!
    // 0x68bb1c: r0 = preferredLineHeight()
    //     0x68bb1c: bl              #0x51a438  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0x68bb20: add             SP, SP, #8
    // 0x68bb24: ldr             x0, [fp, #0x18]
    // 0x68bb28: r17 = 259
    //     0x68bb28: mov             x17, #0x103
    // 0x68bb2c: ldr             w1, [x0, x17]
    // 0x68bb30: DecompressPointer r1
    //     0x68bb30: add             x1, x1, HEAP, lsl #32
    // 0x68bb34: cmp             w1, NULL
    // 0x68bb38: b.eq            #0x68bd94
    // 0x68bb3c: r16 = LoadInt32Instr(r1)
    //     0x68bb3c: sbfx            x16, x1, #1, #0x1f
    // 0x68bb40: scvtf           d1, w16
    // 0x68bb44: fmul            d2, d0, d1
    // 0x68bb48: mov             v0.16b, v2.16b
    // 0x68bb4c: LeaveFrame
    //     0x68bb4c: mov             SP, fp
    //     0x68bb50: ldp             fp, lr, [SP], #0x10
    // 0x68bb54: ret
    //     0x68bb54: ret             
    // 0x68bb58: ldr             x0, [fp, #0x18]
    // 0x68bb5c: ldr             d0, [fp, #0x10]
    // 0x68bb60: d1 = inf
    //     0x68bb60: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x68bb64: fcmp            d0, d1
    // 0x68bb68: b.vs            #0x68bc58
    // 0x68bb6c: b.ne            #0x68bc58
    // 0x68bb70: SaveReg r0
    //     0x68bb70: str             x0, [SP, #-8]!
    // 0x68bb74: r0 = plainText()
    //     0x68bb74: bl              #0x68bdbc  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::plainText
    // 0x68bb78: add             SP, SP, #8
    // 0x68bb7c: mov             x2, x0
    // 0x68bb80: stur            x2, [fp, #-8]
    // 0x68bb84: LoadField: r0 = r2->field_7
    //     0x68bb84: ldur            w0, [x2, #7]
    // 0x68bb88: DecompressPointer r0
    //     0x68bb88: add             x0, x0, HEAP, lsl #32
    // 0x68bb8c: r3 = LoadInt32Instr(r0)
    //     0x68bb8c: sbfx            x3, x0, #1, #0x1f
    // 0x68bb90: stur            x3, [fp, #-0x20]
    // 0x68bb94: r5 = 1
    //     0x68bb94: mov             x5, #1
    // 0x68bb98: r4 = 0
    //     0x68bb98: mov             x4, #0
    // 0x68bb9c: stur            x5, [fp, #-0x10]
    // 0x68bba0: stur            x4, [fp, #-0x18]
    // 0x68bba4: CheckStackOverflow
    //     0x68bba4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68bba8: cmp             SP, x16
    //     0x68bbac: b.ls            #0x68bd98
    // 0x68bbb0: cmp             x4, x3
    // 0x68bbb4: b.ge            #0x68bc20
    // 0x68bbb8: r0 = BoxInt64Instr(r4)
    //     0x68bbb8: sbfiz           x0, x4, #1, #0x1f
    //     0x68bbbc: cmp             x4, x0, asr #1
    //     0x68bbc0: b.eq            #0x68bbcc
    //     0x68bbc4: bl              #0xd69bb8
    //     0x68bbc8: stur            x4, [x0, #7]
    // 0x68bbcc: r1 = LoadClassIdInstr(r2)
    //     0x68bbcc: ldur            x1, [x2, #-1]
    //     0x68bbd0: ubfx            x1, x1, #0xc, #0x14
    // 0x68bbd4: stp             x0, x2, [SP, #-0x10]!
    // 0x68bbd8: mov             x0, x1
    // 0x68bbdc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x68bbdc: sub             lr, x0, #1, lsl #12
    //     0x68bbe0: ldr             lr, [x21, lr, lsl #3]
    //     0x68bbe4: blr             lr
    // 0x68bbe8: add             SP, SP, #0x10
    // 0x68bbec: cmp             w0, #0x14
    // 0x68bbf0: b.ne            #0x68bc04
    // 0x68bbf4: ldur            x0, [fp, #-0x10]
    // 0x68bbf8: add             x1, x0, #1
    // 0x68bbfc: mov             x5, x1
    // 0x68bc00: b               #0x68bc0c
    // 0x68bc04: ldur            x0, [fp, #-0x10]
    // 0x68bc08: mov             x5, x0
    // 0x68bc0c: ldur            x0, [fp, #-0x18]
    // 0x68bc10: add             x4, x0, #1
    // 0x68bc14: ldur            x2, [fp, #-8]
    // 0x68bc18: ldur            x3, [fp, #-0x20]
    // 0x68bc1c: b               #0x68bb9c
    // 0x68bc20: ldr             x1, [fp, #0x18]
    // 0x68bc24: mov             x0, x5
    // 0x68bc28: LoadField: r2 = r1->field_eb
    //     0x68bc28: ldur            w2, [x1, #0xeb]
    // 0x68bc2c: DecompressPointer r2
    //     0x68bc2c: add             x2, x2, HEAP, lsl #32
    // 0x68bc30: SaveReg r2
    //     0x68bc30: str             x2, [SP, #-8]!
    // 0x68bc34: r0 = preferredLineHeight()
    //     0x68bc34: bl              #0x51a438  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0x68bc38: add             SP, SP, #8
    // 0x68bc3c: ldur            x0, [fp, #-0x10]
    // 0x68bc40: scvtf           d1, x0
    // 0x68bc44: fmul            d2, d0, d1
    // 0x68bc48: mov             v0.16b, v2.16b
    // 0x68bc4c: LeaveFrame
    //     0x68bc4c: mov             SP, fp
    //     0x68bc50: ldp             fp, lr, [SP], #0x10
    // 0x68bc54: ret
    //     0x68bc54: ret             
    // 0x68bc58: mov             x1, x0
    // 0x68bc5c: r0 = inline_Allocate_Double()
    //     0x68bc5c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x68bc60: add             x0, x0, #0x10
    //     0x68bc64: cmp             x2, x0
    //     0x68bc68: b.ls            #0x68bda0
    //     0x68bc6c: str             x0, [THR, #0x60]  ; THR::top
    //     0x68bc70: sub             x0, x0, #0xf
    //     0x68bc74: mov             x2, #0xd108
    //     0x68bc78: movk            x2, #3, lsl #16
    //     0x68bc7c: stur            x2, [x0, #-1]
    // 0x68bc80: StoreField: r0->field_7 = d0
    //     0x68bc80: stur            d0, [x0, #7]
    // 0x68bc84: stp             x0, x1, [SP, #-0x10]!
    // 0x68bc88: r4 = const [0, 0x2, 0x2, 0x1, maxWidth, 0x1, null]
    //     0x68bc88: add             x4, PP, #0x35, lsl #12  ; [pp+0x35c18] List(7) [0, 0x2, 0x2, 0x1, "maxWidth", 0x1, Null]
    //     0x68bc8c: ldr             x4, [x4, #0xc18]
    // 0x68bc90: r0 = layoutText()
    //     0x68bc90: bl              #0x52312c  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::layoutText
    // 0x68bc94: add             SP, SP, #0x10
    // 0x68bc98: ldr             x0, [fp, #0x18]
    // 0x68bc9c: LoadField: r1 = r0->field_eb
    //     0x68bc9c: ldur            w1, [x0, #0xeb]
    // 0x68bca0: DecompressPointer r1
    //     0x68bca0: add             x1, x1, HEAP, lsl #32
    // 0x68bca4: stur            x1, [fp, #-8]
    // 0x68bca8: SaveReg r1
    //     0x68bca8: str             x1, [SP, #-8]!
    // 0x68bcac: r0 = preferredLineHeight()
    //     0x68bcac: bl              #0x51a438  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0x68bcb0: add             SP, SP, #8
    // 0x68bcb4: ldur            x0, [fp, #-8]
    // 0x68bcb8: stur            d0, [fp, #-0x28]
    // 0x68bcbc: LoadField: r1 = r0->field_7
    //     0x68bcbc: ldur            w1, [x0, #7]
    // 0x68bcc0: DecompressPointer r1
    //     0x68bcc0: add             x1, x1, HEAP, lsl #32
    // 0x68bcc4: cmp             w1, NULL
    // 0x68bcc8: b.eq            #0x68bdb8
    // 0x68bccc: SaveReg r1
    //     0x68bccc: str             x1, [SP, #-8]!
    // 0x68bcd0: r0 = height()
    //     0x68bcd0: bl              #0x51a4dc  ; [dart:ui] Paragraph::height
    // 0x68bcd4: add             SP, SP, #8
    // 0x68bcd8: stp             fp, lr, [SP, #-0x10]!
    // 0x68bcdc: mov             fp, SP
    // 0x68bce0: CallRuntime_LibcCeil(double) -> double
    //     0x68bce0: and             SP, SP, #0xfffffffffffffff0
    //     0x68bce4: mov             sp, SP
    //     0x68bce8: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x68bcec: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x68bcf0: blr             x16
    //     0x68bcf4: mov             x16, #8
    //     0x68bcf8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x68bcfc: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x68bd00: sub             sp, x16, #1, lsl #12
    //     0x68bd04: mov             SP, fp
    //     0x68bd08: ldp             fp, lr, [SP], #0x10
    // 0x68bd0c: ldur            d1, [fp, #-0x28]
    // 0x68bd10: fcmp            d1, d0
    // 0x68bd14: b.vs            #0x68bd24
    // 0x68bd18: b.le            #0x68bd24
    // 0x68bd1c: mov             v0.16b, v1.16b
    // 0x68bd20: b               #0x68bd58
    // 0x68bd24: fcmp            d1, d0
    // 0x68bd28: b.vs            #0x68bd30
    // 0x68bd2c: b.lt            #0x68bd58
    // 0x68bd30: d2 = 0.000000
    //     0x68bd30: eor             v2.16b, v2.16b, v2.16b
    // 0x68bd34: fcmp            d1, d2
    // 0x68bd38: b.vs            #0x68bd4c
    // 0x68bd3c: b.ne            #0x68bd4c
    // 0x68bd40: fadd            d2, d1, d0
    // 0x68bd44: mov             v0.16b, v2.16b
    // 0x68bd48: b               #0x68bd58
    // 0x68bd4c: fcmp            d0, d0
    // 0x68bd50: b.vs            #0x68bd58
    // 0x68bd54: mov             v0.16b, v1.16b
    // 0x68bd58: LeaveFrame
    //     0x68bd58: mov             SP, fp
    //     0x68bd5c: ldp             fp, lr, [SP], #0x10
    // 0x68bd60: ret
    //     0x68bd60: ret             
    // 0x68bd64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68bd64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68bd68: b               #0x68b994
    // 0x68bd6c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68bd6c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x68bd70: SaveReg d0
    //     0x68bd70: str             q0, [SP, #-0x10]!
    // 0x68bd74: stp             x0, x2, [SP, #-0x10]!
    // 0x68bd78: r0 = AllocateDouble()
    //     0x68bd78: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68bd7c: mov             x1, x0
    // 0x68bd80: ldp             x0, x2, [SP], #0x10
    // 0x68bd84: RestoreReg d0
    //     0x68bd84: ldr             q0, [SP], #0x10
    // 0x68bd88: b               #0x68ba4c
    // 0x68bd8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68bd8c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68bd90: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68bd90: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x68bd94: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68bd94: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x68bd98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68bd98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68bd9c: b               #0x68bbb0
    // 0x68bda0: SaveReg d0
    //     0x68bda0: str             q0, [SP, #-0x10]!
    // 0x68bda4: SaveReg r1
    //     0x68bda4: str             x1, [SP, #-8]!
    // 0x68bda8: r0 = AllocateDouble()
    //     0x68bda8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68bdac: RestoreReg r1
    //     0x68bdac: ldr             x1, [SP], #8
    // 0x68bdb0: RestoreReg d0
    //     0x68bdb0: ldr             q0, [SP], #0x10
    // 0x68bdb4: b               #0x68bc80
    // 0x68bdb8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68bdb8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  get _ plainText(/* No info */) {
    // ** addr: 0x68bdbc, size: 0x94
    // 0x68bdbc: EnterFrame
    //     0x68bdbc: stp             fp, lr, [SP, #-0x10]!
    //     0x68bdc0: mov             fp, SP
    // 0x68bdc4: CheckStackOverflow
    //     0x68bdc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68bdc8: cmp             SP, x16
    //     0x68bdcc: b.ls            #0x68be44
    // 0x68bdd0: ldr             x0, [fp, #0x10]
    // 0x68bdd4: LoadField: r1 = r0->field_e7
    //     0x68bdd4: ldur            w1, [x0, #0xe7]
    // 0x68bdd8: DecompressPointer r1
    //     0x68bdd8: add             x1, x1, HEAP, lsl #32
    // 0x68bddc: cmp             w1, NULL
    // 0x68bde0: b.ne            #0x68be34
    // 0x68bde4: LoadField: r1 = r0->field_eb
    //     0x68bde4: ldur            w1, [x0, #0xeb]
    // 0x68bde8: DecompressPointer r1
    //     0x68bde8: add             x1, x1, HEAP, lsl #32
    // 0x68bdec: LoadField: r2 = r1->field_f
    //     0x68bdec: ldur            w2, [x1, #0xf]
    // 0x68bdf0: DecompressPointer r2
    //     0x68bdf0: add             x2, x2, HEAP, lsl #32
    // 0x68bdf4: cmp             w2, NULL
    // 0x68bdf8: b.eq            #0x68be4c
    // 0x68bdfc: SaveReg r2
    //     0x68bdfc: str             x2, [SP, #-8]!
    // 0x68be00: r0 = textSpanToActualText()
    //     0x68be00: bl              #0x68be50  ; [package:extended_text_library/src/extended_text_utils.dart] ::textSpanToActualText
    // 0x68be04: add             SP, SP, #8
    // 0x68be08: mov             x1, x0
    // 0x68be0c: ldr             x2, [fp, #0x10]
    // 0x68be10: StoreField: r2->field_e7 = r0
    //     0x68be10: stur            w0, [x2, #0xe7]
    //     0x68be14: ldurb           w16, [x2, #-1]
    //     0x68be18: ldurb           w17, [x0, #-1]
    //     0x68be1c: and             x16, x17, x16, lsr #2
    //     0x68be20: tst             x16, HEAP, lsr #32
    //     0x68be24: b.eq            #0x68be2c
    //     0x68be28: bl              #0xd6828c
    // 0x68be2c: mov             x0, x1
    // 0x68be30: b               #0x68be38
    // 0x68be34: mov             x0, x1
    // 0x68be38: LeaveFrame
    //     0x68be38: mov             SP, fp
    //     0x68be3c: ldp             fp, lr, [SP], #0x10
    // 0x68be40: ret
    //     0x68be40: ret             
    // 0x68be44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68be44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68be48: b               #0x68bdd0
    // 0x68be4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68be4c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _computeCaretPrototype(/* No info */) {
    // ** addr: 0x68c020, size: 0x1ac
    // 0x68c020: EnterFrame
    //     0x68c020: stp             fp, lr, [SP, #-0x10]!
    //     0x68c024: mov             fp, SP
    // 0x68c028: AllocStack(0x18)
    //     0x68c028: sub             SP, SP, #0x18
    // 0x68c02c: CheckStackOverflow
    //     0x68c02c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68c030: cmp             SP, x16
    //     0x68c034: b.ls            #0x68c1c4
    // 0x68c038: r0 = defaultTargetPlatform()
    //     0x68c038: bl              #0x59ed88  ; [package:flutter/src/foundation/_platform_io.dart] ::defaultTargetPlatform
    // 0x68c03c: LoadField: r1 = r0->field_7
    //     0x68c03c: ldur            x1, [x0, #7]
    // 0x68c040: cmp             x1, #2
    // 0x68c044: b.gt            #0x68c060
    // 0x68c048: cmp             x1, #1
    // 0x68c04c: b.gt            #0x68c080
    // 0x68c050: ldr             x1, [fp, #0x10]
    // 0x68c054: d0 = 2.000000
    //     0x68c054: fmov            d0, #2.00000000
    // 0x68c058: d1 = 0.000000
    //     0x68c058: eor             v1.16b, v1.16b, v1.16b
    // 0x68c05c: b               #0x68c124
    // 0x68c060: cmp             x1, #4
    // 0x68c064: b.gt            #0x68c118
    // 0x68c068: cmp             x1, #3
    // 0x68c06c: b.gt            #0x68c080
    // 0x68c070: ldr             x1, [fp, #0x10]
    // 0x68c074: d0 = 2.000000
    //     0x68c074: fmov            d0, #2.00000000
    // 0x68c078: d1 = 0.000000
    //     0x68c078: eor             v1.16b, v1.16b, v1.16b
    // 0x68c07c: b               #0x68c124
    // 0x68c080: ldr             x0, [fp, #0x10]
    // 0x68c084: r17 = 279
    //     0x68c084: mov             x17, #0x117
    // 0x68c088: ldr             w1, [x0, x17]
    // 0x68c08c: DecompressPointer r1
    //     0x68c08c: add             x1, x1, HEAP, lsl #32
    // 0x68c090: stur            x1, [fp, #-8]
    // 0x68c094: LoadField: r2 = r0->field_eb
    //     0x68c094: ldur            w2, [x0, #0xeb]
    // 0x68c098: DecompressPointer r2
    //     0x68c098: add             x2, x2, HEAP, lsl #32
    // 0x68c09c: SaveReg r2
    //     0x68c09c: str             x2, [SP, #-8]!
    // 0x68c0a0: r0 = preferredLineHeight()
    //     0x68c0a0: bl              #0x51a438  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0x68c0a4: add             SP, SP, #8
    // 0x68c0a8: mov             v1.16b, v0.16b
    // 0x68c0ac: d0 = 2.000000
    //     0x68c0ac: fmov            d0, #2.00000000
    // 0x68c0b0: fadd            d2, d1, d0
    // 0x68c0b4: ldur            x0, [fp, #-8]
    // 0x68c0b8: LoadField: d0 = r0->field_7
    //     0x68c0b8: ldur            d0, [x0, #7]
    // 0x68c0bc: d1 = 0.000000
    //     0x68c0bc: eor             v1.16b, v1.16b, v1.16b
    // 0x68c0c0: fadd            d3, d1, d0
    // 0x68c0c4: stur            d3, [fp, #-0x18]
    // 0x68c0c8: fadd            d0, d1, d2
    // 0x68c0cc: stur            d0, [fp, #-0x10]
    // 0x68c0d0: r0 = Rect()
    //     0x68c0d0: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x68c0d4: d1 = 0.000000
    //     0x68c0d4: eor             v1.16b, v1.16b, v1.16b
    // 0x68c0d8: StoreField: r0->field_7 = d1
    //     0x68c0d8: stur            d1, [x0, #7]
    // 0x68c0dc: StoreField: r0->field_f = d1
    //     0x68c0dc: stur            d1, [x0, #0xf]
    // 0x68c0e0: ldur            d0, [fp, #-0x18]
    // 0x68c0e4: StoreField: r0->field_17 = d0
    //     0x68c0e4: stur            d0, [x0, #0x17]
    // 0x68c0e8: ldur            d0, [fp, #-0x10]
    // 0x68c0ec: StoreField: r0->field_1f = d0
    //     0x68c0ec: stur            d0, [x0, #0x1f]
    // 0x68c0f0: ldr             x1, [fp, #0x10]
    // 0x68c0f4: r17 = 339
    //     0x68c0f4: mov             x17, #0x153
    // 0x68c0f8: str             w0, [x1, x17]
    // 0x68c0fc: WriteBarrierInstr(obj = r1, val = r0)
    //     0x68c0fc: ldurb           w16, [x1, #-1]
    //     0x68c100: ldurb           w17, [x0, #-1]
    //     0x68c104: and             x16, x17, x16, lsr #2
    //     0x68c108: tst             x16, HEAP, lsr #32
    //     0x68c10c: b.eq            #0x68c114
    //     0x68c110: bl              #0xd6826c
    // 0x68c114: b               #0x68c1b4
    // 0x68c118: ldr             x1, [fp, #0x10]
    // 0x68c11c: d0 = 2.000000
    //     0x68c11c: fmov            d0, #2.00000000
    // 0x68c120: d1 = 0.000000
    //     0x68c120: eor             v1.16b, v1.16b, v1.16b
    // 0x68c124: r17 = 279
    //     0x68c124: mov             x17, #0x117
    // 0x68c128: ldr             w0, [x1, x17]
    // 0x68c12c: DecompressPointer r0
    //     0x68c12c: add             x0, x0, HEAP, lsl #32
    // 0x68c130: stur            x0, [fp, #-8]
    // 0x68c134: SaveReg r1
    //     0x68c134: str             x1, [SP, #-8]!
    // 0x68c138: r0 = cursorHeight()
    //     0x68c138: bl              #0x518790  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::cursorHeight
    // 0x68c13c: add             SP, SP, #8
    // 0x68c140: mov             v1.16b, v0.16b
    // 0x68c144: d0 = 4.000000
    //     0x68c144: fmov            d0, #4.00000000
    // 0x68c148: fsub            d2, d1, d0
    // 0x68c14c: ldur            x0, [fp, #-8]
    // 0x68c150: LoadField: d0 = r0->field_7
    //     0x68c150: ldur            d0, [x0, #7]
    // 0x68c154: d1 = 0.000000
    //     0x68c154: eor             v1.16b, v1.16b, v1.16b
    // 0x68c158: fadd            d3, d1, d0
    // 0x68c15c: stur            d3, [fp, #-0x18]
    // 0x68c160: d0 = 2.000000
    //     0x68c160: fmov            d0, #2.00000000
    // 0x68c164: fadd            d4, d0, d2
    // 0x68c168: stur            d4, [fp, #-0x10]
    // 0x68c16c: r0 = Rect()
    //     0x68c16c: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x68c170: d0 = 0.000000
    //     0x68c170: eor             v0.16b, v0.16b, v0.16b
    // 0x68c174: StoreField: r0->field_7 = d0
    //     0x68c174: stur            d0, [x0, #7]
    // 0x68c178: d0 = 2.000000
    //     0x68c178: fmov            d0, #2.00000000
    // 0x68c17c: StoreField: r0->field_f = d0
    //     0x68c17c: stur            d0, [x0, #0xf]
    // 0x68c180: ldur            d0, [fp, #-0x18]
    // 0x68c184: StoreField: r0->field_17 = d0
    //     0x68c184: stur            d0, [x0, #0x17]
    // 0x68c188: ldur            d0, [fp, #-0x10]
    // 0x68c18c: StoreField: r0->field_1f = d0
    //     0x68c18c: stur            d0, [x0, #0x1f]
    // 0x68c190: ldr             x1, [fp, #0x10]
    // 0x68c194: r17 = 339
    //     0x68c194: mov             x17, #0x153
    // 0x68c198: str             w0, [x1, x17]
    // 0x68c19c: WriteBarrierInstr(obj = r1, val = r0)
    //     0x68c19c: ldurb           w16, [x1, #-1]
    //     0x68c1a0: ldurb           w17, [x0, #-1]
    //     0x68c1a4: and             x16, x17, x16, lsr #2
    //     0x68c1a8: tst             x16, HEAP, lsr #32
    //     0x68c1ac: b.eq            #0x68c1b4
    //     0x68c1b0: bl              #0xd6826c
    // 0x68c1b4: r0 = Null
    //     0x68c1b4: mov             x0, NULL
    // 0x68c1b8: LeaveFrame
    //     0x68c1b8: mov             SP, fp
    //     0x68c1bc: ldp             fp, lr, [SP], #0x10
    // 0x68c1c0: ret
    //     0x68c1c0: ret             
    // 0x68c1c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68c1c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68c1c8: b               #0x68c038
  }
  _ markNeedsPaint(/* No info */) {
    // ** addr: 0x6bef94, size: 0x7c
    // 0x6bef94: EnterFrame
    //     0x6bef94: stp             fp, lr, [SP, #-0x10]!
    //     0x6bef98: mov             fp, SP
    // 0x6bef9c: CheckStackOverflow
    //     0x6bef9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6befa0: cmp             SP, x16
    //     0x6befa4: b.ls            #0x6bf008
    // 0x6befa8: ldr             x16, [fp, #0x10]
    // 0x6befac: SaveReg r16
    //     0x6befac: str             x16, [SP, #-8]!
    // 0x6befb0: r0 = markNeedsPaint()
    //     0x6befb0: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6befb4: add             SP, SP, #8
    // 0x6befb8: ldr             x0, [fp, #0x10]
    // 0x6befbc: LoadField: r1 = r0->field_9b
    //     0x6befbc: ldur            w1, [x0, #0x9b]
    // 0x6befc0: DecompressPointer r1
    //     0x6befc0: add             x1, x1, HEAP, lsl #32
    // 0x6befc4: cmp             w1, NULL
    // 0x6befc8: b.eq            #0x6befdc
    // 0x6befcc: SaveReg r1
    //     0x6befcc: str             x1, [SP, #-8]!
    // 0x6befd0: r0 = markNeedsPaint()
    //     0x6befd0: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6befd4: add             SP, SP, #8
    // 0x6befd8: ldr             x0, [fp, #0x10]
    // 0x6befdc: LoadField: r1 = r0->field_9f
    //     0x6befdc: ldur            w1, [x0, #0x9f]
    // 0x6befe0: DecompressPointer r1
    //     0x6befe0: add             x1, x1, HEAP, lsl #32
    // 0x6befe4: cmp             w1, NULL
    // 0x6befe8: b.eq            #0x6beff8
    // 0x6befec: SaveReg r1
    //     0x6befec: str             x1, [SP, #-8]!
    // 0x6beff0: r0 = markNeedsPaint()
    //     0x6beff0: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6beff4: add             SP, SP, #8
    // 0x6beff8: r0 = Null
    //     0x6beff8: mov             x0, NULL
    // 0x6beffc: LeaveFrame
    //     0x6beffc: mov             SP, fp
    //     0x6bf000: ldp             fp, lr, [SP], #0x10
    // 0x6bf004: ret
    //     0x6bf004: ret             
    // 0x6bf008: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bf008: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bf00c: b               #0x6befa8
  }
  [closure] void markNeedsPaint(dynamic) {
    // ** addr: 0x6bf010, size: 0x48
    // 0x6bf010: EnterFrame
    //     0x6bf010: stp             fp, lr, [SP, #-0x10]!
    //     0x6bf014: mov             fp, SP
    // 0x6bf018: ldr             x0, [fp, #0x10]
    // 0x6bf01c: LoadField: r1 = r0->field_17
    //     0x6bf01c: ldur            w1, [x0, #0x17]
    // 0x6bf020: DecompressPointer r1
    //     0x6bf020: add             x1, x1, HEAP, lsl #32
    // 0x6bf024: CheckStackOverflow
    //     0x6bf024: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bf028: cmp             SP, x16
    //     0x6bf02c: b.ls            #0x6bf050
    // 0x6bf030: LoadField: r0 = r1->field_f
    //     0x6bf030: ldur            w0, [x1, #0xf]
    // 0x6bf034: DecompressPointer r0
    //     0x6bf034: add             x0, x0, HEAP, lsl #32
    // 0x6bf038: SaveReg r0
    //     0x6bf038: str             x0, [SP, #-8]!
    // 0x6bf03c: r0 = markNeedsPaint()
    //     0x6bf03c: bl              #0x6bef94  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::markNeedsPaint
    // 0x6bf040: add             SP, SP, #8
    // 0x6bf044: LeaveFrame
    //     0x6bf044: mov             SP, fp
    //     0x6bf048: ldp             fp, lr, [SP], #0x10
    // 0x6bf04c: ret
    //     0x6bf04c: ret             
    // 0x6bf050: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bf050: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bf054: b               #0x6bf030
  }
  _ visitChildren(/* No info */) {
    // ** addr: 0x6bf6b4, size: 0xa8
    // 0x6bf6b4: EnterFrame
    //     0x6bf6b4: stp             fp, lr, [SP, #-0x10]!
    //     0x6bf6b8: mov             fp, SP
    // 0x6bf6bc: AllocStack(0x8)
    //     0x6bf6bc: sub             SP, SP, #8
    // 0x6bf6c0: CheckStackOverflow
    //     0x6bf6c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bf6c4: cmp             SP, x16
    //     0x6bf6c8: b.ls            #0x6bf754
    // 0x6bf6cc: ldr             x1, [fp, #0x18]
    // 0x6bf6d0: LoadField: r0 = r1->field_9b
    //     0x6bf6d0: ldur            w0, [x1, #0x9b]
    // 0x6bf6d4: DecompressPointer r0
    //     0x6bf6d4: add             x0, x0, HEAP, lsl #32
    // 0x6bf6d8: LoadField: r2 = r1->field_9f
    //     0x6bf6d8: ldur            w2, [x1, #0x9f]
    // 0x6bf6dc: DecompressPointer r2
    //     0x6bf6dc: add             x2, x2, HEAP, lsl #32
    // 0x6bf6e0: stur            x2, [fp, #-8]
    // 0x6bf6e4: cmp             w0, NULL
    // 0x6bf6e8: b.eq            #0x6bf708
    // 0x6bf6ec: ldr             x16, [fp, #0x10]
    // 0x6bf6f0: stp             x0, x16, [SP, #-0x10]!
    // 0x6bf6f4: ldr             x0, [fp, #0x10]
    // 0x6bf6f8: ClosureCall
    //     0x6bf6f8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6bf6fc: ldur            x2, [x0, #0x1f]
    //     0x6bf700: blr             x2
    // 0x6bf704: add             SP, SP, #0x10
    // 0x6bf708: ldur            x0, [fp, #-8]
    // 0x6bf70c: cmp             w0, NULL
    // 0x6bf710: b.eq            #0x6bf730
    // 0x6bf714: ldr             x16, [fp, #0x10]
    // 0x6bf718: stp             x0, x16, [SP, #-0x10]!
    // 0x6bf71c: ldr             x0, [fp, #0x10]
    // 0x6bf720: ClosureCall
    //     0x6bf720: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6bf724: ldur            x2, [x0, #0x1f]
    //     0x6bf728: blr             x2
    // 0x6bf72c: add             SP, SP, #0x10
    // 0x6bf730: ldr             x16, [fp, #0x18]
    // 0x6bf734: ldr             lr, [fp, #0x10]
    // 0x6bf738: stp             lr, x16, [SP, #-0x10]!
    // 0x6bf73c: r0 = visitChildren()
    //     0x6bf73c: bl              #0x6bf75c  ; [package:flutter/src/rendering/paragraph.dart] _RenderParagraph&RenderBox&ContainerRenderObjectMixin::visitChildren
    // 0x6bf740: add             SP, SP, #0x10
    // 0x6bf744: r0 = Null
    //     0x6bf744: mov             x0, NULL
    // 0x6bf748: LeaveFrame
    //     0x6bf748: mov             SP, fp
    //     0x6bf74c: ldp             fp, lr, [SP], #0x10
    // 0x6bf750: ret
    //     0x6bf750: ret             
    // 0x6bf754: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bf754: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bf758: b               #0x6bf6cc
  }
  set _ cursorColor=(/* No info */) {
    // ** addr: 0x6de304, size: 0x60
    // 0x6de304: EnterFrame
    //     0x6de304: stp             fp, lr, [SP, #-0x10]!
    //     0x6de308: mov             fp, SP
    // 0x6de30c: CheckStackOverflow
    //     0x6de30c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6de310: cmp             SP, x16
    //     0x6de314: b.ls            #0x6de35c
    // 0x6de318: ldr             x1, [fp, #0x18]
    // 0x6de31c: LoadField: r0 = r1->field_ab
    //     0x6de31c: ldur            w0, [x1, #0xab]
    // 0x6de320: DecompressPointer r0
    //     0x6de320: add             x0, x0, HEAP, lsl #32
    // 0x6de324: r16 = Sentinel
    //     0x6de324: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6de328: cmp             w0, w16
    // 0x6de32c: b.ne            #0x6de33c
    // 0x6de330: r2 = _caretPainter
    //     0x6de330: add             x2, PP, #0x37, lsl #12  ; [pp+0x37348] Field <ExtendedRenderEditable._caretPainter@483409610>: late final (offset: 0xac)
    //     0x6de334: ldr             x2, [x2, #0x348]
    // 0x6de338: r0 = InitLateFinalInstanceField()
    //     0x6de338: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x6de33c: ldr             x16, [fp, #0x10]
    // 0x6de340: stp             x16, x0, [SP, #-0x10]!
    // 0x6de344: r0 = caretColor=()
    //     0x6de344: bl              #0x6dfe00  ; [package:extended_text_field/src/extended_render_editable.dart] _FloatingCursorPainter::caretColor=
    // 0x6de348: add             SP, SP, #0x10
    // 0x6de34c: r0 = Null
    //     0x6de34c: mov             x0, NULL
    // 0x6de350: LeaveFrame
    //     0x6de350: mov             SP, fp
    //     0x6de354: ldp             fp, lr, [SP], #0x10
    // 0x6de358: ret
    //     0x6de358: ret             
    // 0x6de35c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6de35c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6de360: b               #0x6de318
  }
  _ setPromptRectRange(/* No info */) {
    // ** addr: 0x6de364, size: 0x68
    // 0x6de364: EnterFrame
    //     0x6de364: stp             fp, lr, [SP, #-0x10]!
    //     0x6de368: mov             fp, SP
    // 0x6de36c: AllocStack(0x8)
    //     0x6de36c: sub             SP, SP, #8
    // 0x6de370: CheckStackOverflow
    //     0x6de370: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6de374: cmp             SP, x16
    //     0x6de378: b.ls            #0x6de3c4
    // 0x6de37c: ldr             x0, [fp, #0x18]
    // 0x6de380: LoadField: r1 = r0->field_b3
    //     0x6de380: ldur            w1, [x0, #0xb3]
    // 0x6de384: DecompressPointer r1
    //     0x6de384: add             x1, x1, HEAP, lsl #32
    // 0x6de388: stur            x1, [fp, #-8]
    // 0x6de38c: ldr             x16, [fp, #0x10]
    // 0x6de390: stp             x16, x0, [SP, #-0x10]!
    // 0x6de394: r4 = const [0, 0x2, 0x2, 0x1, newRange, 0x1, null]
    //     0x6de394: add             x4, PP, #0x55, lsl #12  ; [pp+0x55af0] List(7) [0, 0x2, 0x2, 0x1, "newRange", 0x1, Null]
    //     0x6de398: ldr             x4, [x4, #0xaf0]
    // 0x6de39c: r0 = getActualSelection()
    //     0x6de39c: bl              #0x6de46c  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::getActualSelection
    // 0x6de3a0: add             SP, SP, #0x10
    // 0x6de3a4: ldur            x16, [fp, #-8]
    // 0x6de3a8: stp             x0, x16, [SP, #-0x10]!
    // 0x6de3ac: r0 = highlightedRange=()
    //     0x6de3ac: bl              #0x6de3cc  ; [package:extended_text_library/src/selection/painter.dart] TextHighlightPainter::highlightedRange=
    // 0x6de3b0: add             SP, SP, #0x10
    // 0x6de3b4: r0 = Null
    //     0x6de3b4: mov             x0, NULL
    // 0x6de3b8: LeaveFrame
    //     0x6de3b8: mov             SP, fp
    //     0x6de3bc: ldp             fp, lr, [SP], #0x10
    // 0x6de3c0: ret
    //     0x6de3c0: ret             
    // 0x6de3c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6de3c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6de3c8: b               #0x6de37c
  }
  set _ promptRectColor=(/* No info */) {
    // ** addr: 0x6de5ac, size: 0x48
    // 0x6de5ac: EnterFrame
    //     0x6de5ac: stp             fp, lr, [SP, #-0x10]!
    //     0x6de5b0: mov             fp, SP
    // 0x6de5b4: CheckStackOverflow
    //     0x6de5b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6de5b8: cmp             SP, x16
    //     0x6de5bc: b.ls            #0x6de5ec
    // 0x6de5c0: ldr             x0, [fp, #0x18]
    // 0x6de5c4: LoadField: r1 = r0->field_b3
    //     0x6de5c4: ldur            w1, [x0, #0xb3]
    // 0x6de5c8: DecompressPointer r1
    //     0x6de5c8: add             x1, x1, HEAP, lsl #32
    // 0x6de5cc: ldr             x16, [fp, #0x10]
    // 0x6de5d0: stp             x16, x1, [SP, #-0x10]!
    // 0x6de5d4: r0 = highlightColor=()
    //     0x6de5d4: bl              #0x6de5f4  ; [package:extended_text_library/src/selection/painter.dart] TextHighlightPainter::highlightColor=
    // 0x6de5d8: add             SP, SP, #0x10
    // 0x6de5dc: r0 = Null
    //     0x6de5dc: mov             x0, NULL
    // 0x6de5e0: LeaveFrame
    //     0x6de5e0: mov             SP, fp
    //     0x6de5e4: ldp             fp, lr, [SP], #0x10
    // 0x6de5e8: ret
    //     0x6de5e8: ret             
    // 0x6de5ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6de5ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6de5f0: b               #0x6de5c0
  }
  set _ paintCursorAboveText=(/* No info */) {
    // ** addr: 0x6de694, size: 0x84
    // 0x6de694: EnterFrame
    //     0x6de694: stp             fp, lr, [SP, #-0x10]!
    //     0x6de698: mov             fp, SP
    // 0x6de69c: CheckStackOverflow
    //     0x6de69c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6de6a0: cmp             SP, x16
    //     0x6de6a4: b.ls            #0x6de710
    // 0x6de6a8: ldr             x0, [fp, #0x18]
    // 0x6de6ac: r17 = 287
    //     0x6de6ac: mov             x17, #0x11f
    // 0x6de6b0: ldr             w1, [x0, x17]
    // 0x6de6b4: DecompressPointer r1
    //     0x6de6b4: add             x1, x1, HEAP, lsl #32
    // 0x6de6b8: ldr             x2, [fp, #0x10]
    // 0x6de6bc: cmp             w1, w2
    // 0x6de6c0: b.ne            #0x6de6d4
    // 0x6de6c4: r0 = Null
    //     0x6de6c4: mov             x0, NULL
    // 0x6de6c8: LeaveFrame
    //     0x6de6c8: mov             SP, fp
    //     0x6de6cc: ldp             fp, lr, [SP], #0x10
    // 0x6de6d0: ret
    //     0x6de6d0: ret             
    // 0x6de6d4: add             x16, x0, #0x11f
    // 0x6de6d8: str             w2, [x16]
    // 0x6de6dc: StoreField: r0->field_b7 = rNULL
    //     0x6de6dc: stur            NULL, [x0, #0xb7]
    // 0x6de6e0: StoreField: r0->field_bb = rNULL
    //     0x6de6e0: stur            NULL, [x0, #0xbb]
    // 0x6de6e4: SaveReg r0
    //     0x6de6e4: str             x0, [SP, #-8]!
    // 0x6de6e8: r0 = _updateForegroundPainter()
    //     0x6de6e8: bl              #0x6deb44  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_updateForegroundPainter
    // 0x6de6ec: add             SP, SP, #8
    // 0x6de6f0: ldr             x16, [fp, #0x18]
    // 0x6de6f4: SaveReg r16
    //     0x6de6f4: str             x16, [SP, #-8]!
    // 0x6de6f8: r0 = _updatePainter()
    //     0x6de6f8: bl              #0x6de718  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_updatePainter
    // 0x6de6fc: add             SP, SP, #8
    // 0x6de700: r0 = Null
    //     0x6de700: mov             x0, NULL
    // 0x6de704: LeaveFrame
    //     0x6de704: mov             SP, fp
    //     0x6de708: ldp             fp, lr, [SP], #0x10
    // 0x6de70c: ret
    //     0x6de70c: ret             
    // 0x6de710: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6de710: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6de714: b               #0x6de6a8
  }
  _ _updatePainter(/* No info */) {
    // ** addr: 0x6de718, size: 0xd8
    // 0x6de718: EnterFrame
    //     0x6de718: stp             fp, lr, [SP, #-0x10]!
    //     0x6de71c: mov             fp, SP
    // 0x6de720: AllocStack(0x10)
    //     0x6de720: sub             SP, SP, #0x10
    // 0x6de724: CheckStackOverflow
    //     0x6de724: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6de728: cmp             SP, x16
    //     0x6de72c: b.ls            #0x6de7e8
    // 0x6de730: ldr             x16, [fp, #0x10]
    // 0x6de734: SaveReg r16
    //     0x6de734: str             x16, [SP, #-8]!
    // 0x6de738: r0 = _builtInPainters()
    //     0x6de738: bl              #0x6de914  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_builtInPainters
    // 0x6de73c: add             SP, SP, #8
    // 0x6de740: mov             x1, x0
    // 0x6de744: ldr             x0, [fp, #0x10]
    // 0x6de748: stur            x1, [fp, #-8]
    // 0x6de74c: LoadField: r2 = r0->field_9f
    //     0x6de74c: ldur            w2, [x0, #0x9f]
    // 0x6de750: DecompressPointer r2
    //     0x6de750: add             x2, x2, HEAP, lsl #32
    // 0x6de754: cmp             w2, NULL
    // 0x6de758: b.ne            #0x6de7b8
    // 0x6de75c: r0 = _RenderEditableCustomPaint()
    //     0x6de75c: bl              #0x6de908  ; Allocate_RenderEditableCustomPaintStub -> _RenderEditableCustomPaint (size=0x64)
    // 0x6de760: mov             x1, x0
    // 0x6de764: ldur            x0, [fp, #-8]
    // 0x6de768: stur            x1, [fp, #-0x10]
    // 0x6de76c: StoreField: r1->field_5f = r0
    //     0x6de76c: stur            w0, [x1, #0x5f]
    // 0x6de770: SaveReg r1
    //     0x6de770: str             x1, [SP, #-8]!
    // 0x6de774: r0 = RenderObject()
    //     0x6de774: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6de778: add             SP, SP, #8
    // 0x6de77c: ldr             x16, [fp, #0x10]
    // 0x6de780: ldur            lr, [fp, #-0x10]
    // 0x6de784: stp             lr, x16, [SP, #-0x10]!
    // 0x6de788: r0 = adoptChild()
    //     0x6de788: bl              #0x5e61d4  ; [package:flutter/src/rendering/object.dart] RenderObject::adoptChild
    // 0x6de78c: add             SP, SP, #0x10
    // 0x6de790: ldur            x0, [fp, #-0x10]
    // 0x6de794: ldr             x1, [fp, #0x10]
    // 0x6de798: StoreField: r1->field_9f = r0
    //     0x6de798: stur            w0, [x1, #0x9f]
    //     0x6de79c: ldurb           w16, [x1, #-1]
    //     0x6de7a0: ldurb           w17, [x0, #-1]
    //     0x6de7a4: and             x16, x17, x16, lsr #2
    //     0x6de7a8: tst             x16, HEAP, lsr #32
    //     0x6de7ac: b.eq            #0x6de7b4
    //     0x6de7b0: bl              #0xd6826c
    // 0x6de7b4: b               #0x6de7d4
    // 0x6de7b8: mov             x16, x1
    // 0x6de7bc: mov             x1, x0
    // 0x6de7c0: mov             x0, x16
    // 0x6de7c4: stp             x0, x2, [SP, #-0x10]!
    // 0x6de7c8: r0 = painter=()
    //     0x6de7c8: bl              #0x6de7f0  ; [package:extended_text_field/src/extended_render_editable.dart] _RenderEditableCustomPaint::painter=
    // 0x6de7cc: add             SP, SP, #0x10
    // 0x6de7d0: ldr             x1, [fp, #0x10]
    // 0x6de7d4: StoreField: r1->field_a7 = rNULL
    //     0x6de7d4: stur            NULL, [x1, #0xa7]
    // 0x6de7d8: r0 = Null
    //     0x6de7d8: mov             x0, NULL
    // 0x6de7dc: LeaveFrame
    //     0x6de7dc: mov             SP, fp
    //     0x6de7e0: ldp             fp, lr, [SP], #0x10
    // 0x6de7e4: ret
    //     0x6de7e4: ret             
    // 0x6de7e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6de7e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6de7ec: b               #0x6de730
  }
  get _ _builtInPainters(/* No info */) {
    // ** addr: 0x6de914, size: 0x78
    // 0x6de914: EnterFrame
    //     0x6de914: stp             fp, lr, [SP, #-0x10]!
    //     0x6de918: mov             fp, SP
    // 0x6de91c: CheckStackOverflow
    //     0x6de91c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6de920: cmp             SP, x16
    //     0x6de924: b.ls            #0x6de984
    // 0x6de928: ldr             x0, [fp, #0x10]
    // 0x6de92c: LoadField: r1 = r0->field_bb
    //     0x6de92c: ldur            w1, [x0, #0xbb]
    // 0x6de930: DecompressPointer r1
    //     0x6de930: add             x1, x1, HEAP, lsl #32
    // 0x6de934: cmp             w1, NULL
    // 0x6de938: b.ne            #0x6de974
    // 0x6de93c: SaveReg r0
    //     0x6de93c: str             x0, [SP, #-8]!
    // 0x6de940: r0 = _createBuiltInPainters()
    //     0x6de940: bl              #0x6de98c  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_createBuiltInPainters
    // 0x6de944: add             SP, SP, #8
    // 0x6de948: mov             x1, x0
    // 0x6de94c: ldr             x2, [fp, #0x10]
    // 0x6de950: StoreField: r2->field_bb = r0
    //     0x6de950: stur            w0, [x2, #0xbb]
    //     0x6de954: ldurb           w16, [x2, #-1]
    //     0x6de958: ldurb           w17, [x0, #-1]
    //     0x6de95c: and             x16, x17, x16, lsr #2
    //     0x6de960: tst             x16, HEAP, lsr #32
    //     0x6de964: b.eq            #0x6de96c
    //     0x6de968: bl              #0xd6828c
    // 0x6de96c: mov             x0, x1
    // 0x6de970: b               #0x6de978
    // 0x6de974: mov             x0, x1
    // 0x6de978: LeaveFrame
    //     0x6de978: mov             SP, fp
    //     0x6de97c: ldp             fp, lr, [SP], #0x10
    // 0x6de980: ret
    //     0x6de980: ret             
    // 0x6de984: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6de984: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6de988: b               #0x6de928
  }
  _ _createBuiltInPainters(/* No info */) {
    // ** addr: 0x6de98c, size: 0x1ac
    // 0x6de98c: EnterFrame
    //     0x6de98c: stp             fp, lr, [SP, #-0x10]!
    //     0x6de990: mov             fp, SP
    // 0x6de994: AllocStack(0x18)
    //     0x6de994: sub             SP, SP, #0x18
    // 0x6de998: r0 = 4
    //     0x6de998: mov             x0, #4
    // 0x6de99c: CheckStackOverflow
    //     0x6de99c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6de9a0: cmp             SP, x16
    //     0x6de9a4: b.ls            #0x6deb2c
    // 0x6de9a8: ldr             x3, [fp, #0x10]
    // 0x6de9ac: LoadField: r4 = r3->field_b3
    //     0x6de9ac: ldur            w4, [x3, #0xb3]
    // 0x6de9b0: DecompressPointer r4
    //     0x6de9b0: add             x4, x4, HEAP, lsl #32
    // 0x6de9b4: stur            x4, [fp, #-0x10]
    // 0x6de9b8: LoadField: r5 = r3->field_af
    //     0x6de9b8: ldur            w5, [x3, #0xaf]
    // 0x6de9bc: DecompressPointer r5
    //     0x6de9bc: add             x5, x5, HEAP, lsl #32
    // 0x6de9c0: mov             x2, x0
    // 0x6de9c4: stur            x5, [fp, #-8]
    // 0x6de9c8: r1 = Null
    //     0x6de9c8: mov             x1, NULL
    // 0x6de9cc: r0 = AllocateArray()
    //     0x6de9cc: bl              #0xd6987c  ; AllocateArrayStub
    // 0x6de9d0: mov             x2, x0
    // 0x6de9d4: ldur            x0, [fp, #-0x10]
    // 0x6de9d8: stur            x2, [fp, #-0x18]
    // 0x6de9dc: StoreField: r2->field_f = r0
    //     0x6de9dc: stur            w0, [x2, #0xf]
    // 0x6de9e0: ldur            x0, [fp, #-8]
    // 0x6de9e4: StoreField: r2->field_13 = r0
    //     0x6de9e4: stur            w0, [x2, #0x13]
    // 0x6de9e8: r1 = <ExtendedRenderEditablePainter>
    //     0x6de9e8: add             x1, PP, #0x55, lsl #12  ; [pp+0x55b40] TypeArguments: <ExtendedRenderEditablePainter>
    //     0x6de9ec: ldr             x1, [x1, #0xb40]
    // 0x6de9f0: r0 = AllocateGrowableArray()
    //     0x6de9f0: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x6de9f4: mov             x2, x0
    // 0x6de9f8: ldur            x0, [fp, #-0x18]
    // 0x6de9fc: stur            x2, [fp, #-8]
    // 0x6dea00: StoreField: r2->field_f = r0
    //     0x6dea00: stur            w0, [x2, #0xf]
    // 0x6dea04: r0 = 4
    //     0x6dea04: mov             x0, #4
    // 0x6dea08: StoreField: r2->field_b = r0
    //     0x6dea08: stur            w0, [x2, #0xb]
    // 0x6dea0c: ldr             x1, [fp, #0x10]
    // 0x6dea10: r17 = 287
    //     0x6dea10: mov             x17, #0x11f
    // 0x6dea14: ldr             w0, [x1, x17]
    // 0x6dea18: DecompressPointer r0
    //     0x6dea18: add             x0, x0, HEAP, lsl #32
    // 0x6dea1c: tbz             w0, #4, #0x6dead4
    // 0x6dea20: LoadField: r0 = r1->field_ab
    //     0x6dea20: ldur            w0, [x1, #0xab]
    // 0x6dea24: DecompressPointer r0
    //     0x6dea24: add             x0, x0, HEAP, lsl #32
    // 0x6dea28: r16 = Sentinel
    //     0x6dea28: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6dea2c: cmp             w0, w16
    // 0x6dea30: b.ne            #0x6dea40
    // 0x6dea34: r2 = _caretPainter
    //     0x6dea34: add             x2, PP, #0x37, lsl #12  ; [pp+0x37348] Field <ExtendedRenderEditable._caretPainter@483409610>: late final (offset: 0xac)
    //     0x6dea38: ldr             x2, [x2, #0x348]
    // 0x6dea3c: r0 = InitLateFinalInstanceField()
    //     0x6dea3c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x6dea40: mov             x1, x0
    // 0x6dea44: ldur            x0, [fp, #-8]
    // 0x6dea48: stur            x1, [fp, #-0x18]
    // 0x6dea4c: LoadField: r2 = r0->field_b
    //     0x6dea4c: ldur            w2, [x0, #0xb]
    // 0x6dea50: DecompressPointer r2
    //     0x6dea50: add             x2, x2, HEAP, lsl #32
    // 0x6dea54: stur            x2, [fp, #-0x10]
    // 0x6dea58: LoadField: r3 = r0->field_f
    //     0x6dea58: ldur            w3, [x0, #0xf]
    // 0x6dea5c: DecompressPointer r3
    //     0x6dea5c: add             x3, x3, HEAP, lsl #32
    // 0x6dea60: LoadField: r4 = r3->field_b
    //     0x6dea60: ldur            w4, [x3, #0xb]
    // 0x6dea64: DecompressPointer r4
    //     0x6dea64: add             x4, x4, HEAP, lsl #32
    // 0x6dea68: cmp             w2, w4
    // 0x6dea6c: b.ne            #0x6dea7c
    // 0x6dea70: SaveReg r0
    //     0x6dea70: str             x0, [SP, #-8]!
    // 0x6dea74: r0 = _growToNextCapacity()
    //     0x6dea74: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6dea78: add             SP, SP, #8
    // 0x6dea7c: ldur            x0, [fp, #-0x10]
    // 0x6dea80: ldur            x2, [fp, #-8]
    // 0x6dea84: r3 = LoadInt32Instr(r0)
    //     0x6dea84: sbfx            x3, x0, #1, #0x1f
    // 0x6dea88: add             x0, x3, #1
    // 0x6dea8c: lsl             x1, x0, #1
    // 0x6dea90: StoreField: r2->field_b = r1
    //     0x6dea90: stur            w1, [x2, #0xb]
    // 0x6dea94: mov             x1, x3
    // 0x6dea98: cmp             x1, x0
    // 0x6dea9c: b.hs            #0x6deb34
    // 0x6deaa0: LoadField: r1 = r2->field_f
    //     0x6deaa0: ldur            w1, [x2, #0xf]
    // 0x6deaa4: DecompressPointer r1
    //     0x6deaa4: add             x1, x1, HEAP, lsl #32
    // 0x6deaa8: ldur            x0, [fp, #-0x18]
    // 0x6deaac: ArrayStore: r1[r3] = r0  ; List_4
    //     0x6deaac: add             x25, x1, x3, lsl #2
    //     0x6deab0: add             x25, x25, #0xf
    //     0x6deab4: str             w0, [x25]
    //     0x6deab8: tbz             w0, #0, #0x6dead4
    //     0x6deabc: ldurb           w16, [x1, #-1]
    //     0x6deac0: ldurb           w17, [x0, #-1]
    //     0x6deac4: and             x16, x17, x16, lsr #2
    //     0x6deac8: tst             x16, HEAP, lsr #32
    //     0x6deacc: b.eq            #0x6dead4
    //     0x6dead0: bl              #0xd67e5c
    // 0x6dead4: r0 = _CompositeRenderEditablePainter()
    //     0x6dead4: bl              #0x6deb38  ; Allocate_CompositeRenderEditablePainterStub -> _CompositeRenderEditablePainter (size=0x28)
    // 0x6dead8: mov             x1, x0
    // 0x6deadc: ldur            x0, [fp, #-8]
    // 0x6deae0: stur            x1, [fp, #-0x10]
    // 0x6deae4: StoreField: r1->field_23 = r0
    //     0x6deae4: stur            w0, [x1, #0x23]
    // 0x6deae8: r0 = 0
    //     0x6deae8: mov             x0, #0
    // 0x6deaec: StoreField: r1->field_7 = r0
    //     0x6deaec: stur            x0, [x1, #7]
    // 0x6deaf0: StoreField: r1->field_13 = r0
    //     0x6deaf0: stur            x0, [x1, #0x13]
    // 0x6deaf4: StoreField: r1->field_1b = r0
    //     0x6deaf4: stur            x0, [x1, #0x1b]
    // 0x6deaf8: r0 = InitLateStaticField(0xac0) // [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_emptyListeners
    //     0x6deaf8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6deafc: ldr             x0, [x0, #0x1580]
    //     0x6deb00: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6deb04: cmp             w0, w16
    //     0x6deb08: b.ne            #0x6deb14
    //     0x6deb0c: ldr             x2, [PP, #0x44a0]  ; [pp+0x44a0] Field <ChangeNotifier._emptyListeners@171329750>: static late final (offset: 0xac0)
    //     0x6deb10: bl              #0xd67cdc
    // 0x6deb14: mov             x1, x0
    // 0x6deb18: ldur            x0, [fp, #-0x10]
    // 0x6deb1c: StoreField: r0->field_f = r1
    //     0x6deb1c: stur            w1, [x0, #0xf]
    // 0x6deb20: LeaveFrame
    //     0x6deb20: mov             SP, fp
    //     0x6deb24: ldp             fp, lr, [SP], #0x10
    // 0x6deb28: ret
    //     0x6deb28: ret             
    // 0x6deb2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6deb2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6deb30: b               #0x6de9a8
    // 0x6deb34: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6deb34: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _updateForegroundPainter(/* No info */) {
    // ** addr: 0x6deb44, size: 0xd8
    // 0x6deb44: EnterFrame
    //     0x6deb44: stp             fp, lr, [SP, #-0x10]!
    //     0x6deb48: mov             fp, SP
    // 0x6deb4c: AllocStack(0x10)
    //     0x6deb4c: sub             SP, SP, #0x10
    // 0x6deb50: CheckStackOverflow
    //     0x6deb50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6deb54: cmp             SP, x16
    //     0x6deb58: b.ls            #0x6dec14
    // 0x6deb5c: ldr             x16, [fp, #0x10]
    // 0x6deb60: SaveReg r16
    //     0x6deb60: str             x16, [SP, #-8]!
    // 0x6deb64: r0 = _builtInForegroundPainters()
    //     0x6deb64: bl              #0x6dec1c  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_builtInForegroundPainters
    // 0x6deb68: add             SP, SP, #8
    // 0x6deb6c: mov             x1, x0
    // 0x6deb70: ldr             x0, [fp, #0x10]
    // 0x6deb74: stur            x1, [fp, #-8]
    // 0x6deb78: LoadField: r2 = r0->field_9b
    //     0x6deb78: ldur            w2, [x0, #0x9b]
    // 0x6deb7c: DecompressPointer r2
    //     0x6deb7c: add             x2, x2, HEAP, lsl #32
    // 0x6deb80: cmp             w2, NULL
    // 0x6deb84: b.ne            #0x6debe4
    // 0x6deb88: r0 = _RenderEditableCustomPaint()
    //     0x6deb88: bl              #0x6de908  ; Allocate_RenderEditableCustomPaintStub -> _RenderEditableCustomPaint (size=0x64)
    // 0x6deb8c: mov             x1, x0
    // 0x6deb90: ldur            x0, [fp, #-8]
    // 0x6deb94: stur            x1, [fp, #-0x10]
    // 0x6deb98: StoreField: r1->field_5f = r0
    //     0x6deb98: stur            w0, [x1, #0x5f]
    // 0x6deb9c: SaveReg r1
    //     0x6deb9c: str             x1, [SP, #-8]!
    // 0x6deba0: r0 = RenderObject()
    //     0x6deba0: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6deba4: add             SP, SP, #8
    // 0x6deba8: ldr             x16, [fp, #0x10]
    // 0x6debac: ldur            lr, [fp, #-0x10]
    // 0x6debb0: stp             lr, x16, [SP, #-0x10]!
    // 0x6debb4: r0 = adoptChild()
    //     0x6debb4: bl              #0x5e61d4  ; [package:flutter/src/rendering/object.dart] RenderObject::adoptChild
    // 0x6debb8: add             SP, SP, #0x10
    // 0x6debbc: ldur            x0, [fp, #-0x10]
    // 0x6debc0: ldr             x1, [fp, #0x10]
    // 0x6debc4: StoreField: r1->field_9b = r0
    //     0x6debc4: stur            w0, [x1, #0x9b]
    //     0x6debc8: ldurb           w16, [x1, #-1]
    //     0x6debcc: ldurb           w17, [x0, #-1]
    //     0x6debd0: and             x16, x17, x16, lsr #2
    //     0x6debd4: tst             x16, HEAP, lsr #32
    //     0x6debd8: b.eq            #0x6debe0
    //     0x6debdc: bl              #0xd6826c
    // 0x6debe0: b               #0x6dec00
    // 0x6debe4: mov             x16, x1
    // 0x6debe8: mov             x1, x0
    // 0x6debec: mov             x0, x16
    // 0x6debf0: stp             x0, x2, [SP, #-0x10]!
    // 0x6debf4: r0 = painter=()
    //     0x6debf4: bl              #0x6de7f0  ; [package:extended_text_field/src/extended_render_editable.dart] _RenderEditableCustomPaint::painter=
    // 0x6debf8: add             SP, SP, #0x10
    // 0x6debfc: ldr             x1, [fp, #0x10]
    // 0x6dec00: StoreField: r1->field_a3 = rNULL
    //     0x6dec00: stur            NULL, [x1, #0xa3]
    // 0x6dec04: r0 = Null
    //     0x6dec04: mov             x0, NULL
    // 0x6dec08: LeaveFrame
    //     0x6dec08: mov             SP, fp
    //     0x6dec0c: ldp             fp, lr, [SP], #0x10
    // 0x6dec10: ret
    //     0x6dec10: ret             
    // 0x6dec14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6dec14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6dec18: b               #0x6deb5c
  }
  get _ _builtInForegroundPainters(/* No info */) {
    // ** addr: 0x6dec1c, size: 0x78
    // 0x6dec1c: EnterFrame
    //     0x6dec1c: stp             fp, lr, [SP, #-0x10]!
    //     0x6dec20: mov             fp, SP
    // 0x6dec24: CheckStackOverflow
    //     0x6dec24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6dec28: cmp             SP, x16
    //     0x6dec2c: b.ls            #0x6dec8c
    // 0x6dec30: ldr             x0, [fp, #0x10]
    // 0x6dec34: LoadField: r1 = r0->field_b7
    //     0x6dec34: ldur            w1, [x0, #0xb7]
    // 0x6dec38: DecompressPointer r1
    //     0x6dec38: add             x1, x1, HEAP, lsl #32
    // 0x6dec3c: cmp             w1, NULL
    // 0x6dec40: b.ne            #0x6dec7c
    // 0x6dec44: SaveReg r0
    //     0x6dec44: str             x0, [SP, #-8]!
    // 0x6dec48: r0 = _createBuiltInForegroundPainters()
    //     0x6dec48: bl              #0x6dec94  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_createBuiltInForegroundPainters
    // 0x6dec4c: add             SP, SP, #8
    // 0x6dec50: mov             x1, x0
    // 0x6dec54: ldr             x2, [fp, #0x10]
    // 0x6dec58: StoreField: r2->field_b7 = r0
    //     0x6dec58: stur            w0, [x2, #0xb7]
    //     0x6dec5c: ldurb           w16, [x2, #-1]
    //     0x6dec60: ldurb           w17, [x0, #-1]
    //     0x6dec64: and             x16, x17, x16, lsr #2
    //     0x6dec68: tst             x16, HEAP, lsr #32
    //     0x6dec6c: b.eq            #0x6dec74
    //     0x6dec70: bl              #0xd6828c
    // 0x6dec74: mov             x0, x1
    // 0x6dec78: b               #0x6dec80
    // 0x6dec7c: mov             x0, x1
    // 0x6dec80: LeaveFrame
    //     0x6dec80: mov             SP, fp
    //     0x6dec84: ldp             fp, lr, [SP], #0x10
    // 0x6dec88: ret
    //     0x6dec88: ret             
    // 0x6dec8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6dec8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6dec90: b               #0x6dec30
  }
  _ _createBuiltInForegroundPainters(/* No info */) {
    // ** addr: 0x6dec94, size: 0x164
    // 0x6dec94: EnterFrame
    //     0x6dec94: stp             fp, lr, [SP, #-0x10]!
    //     0x6dec98: mov             fp, SP
    // 0x6dec9c: AllocStack(0x18)
    //     0x6dec9c: sub             SP, SP, #0x18
    // 0x6deca0: CheckStackOverflow
    //     0x6deca0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6deca4: cmp             SP, x16
    //     0x6deca8: b.ls            #0x6dedec
    // 0x6decac: r16 = <ExtendedRenderEditablePainter>
    //     0x6decac: add             x16, PP, #0x55, lsl #12  ; [pp+0x55b40] TypeArguments: <ExtendedRenderEditablePainter>
    //     0x6decb0: ldr             x16, [x16, #0xb40]
    // 0x6decb4: stp             xzr, x16, [SP, #-0x10]!
    // 0x6decb8: r0 = _GrowableList()
    //     0x6decb8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x6decbc: add             SP, SP, #0x10
    // 0x6decc0: ldr             x1, [fp, #0x10]
    // 0x6decc4: stur            x0, [fp, #-8]
    // 0x6decc8: r17 = 287
    //     0x6decc8: mov             x17, #0x11f
    // 0x6deccc: ldr             w2, [x1, x17]
    // 0x6decd0: DecompressPointer r2
    //     0x6decd0: add             x2, x2, HEAP, lsl #32
    // 0x6decd4: tbnz            w2, #4, #0x6ded90
    // 0x6decd8: LoadField: r0 = r1->field_ab
    //     0x6decd8: ldur            w0, [x1, #0xab]
    // 0x6decdc: DecompressPointer r0
    //     0x6decdc: add             x0, x0, HEAP, lsl #32
    // 0x6dece0: r16 = Sentinel
    //     0x6dece0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6dece4: cmp             w0, w16
    // 0x6dece8: b.ne            #0x6decf8
    // 0x6decec: r2 = _caretPainter
    //     0x6decec: add             x2, PP, #0x37, lsl #12  ; [pp+0x37348] Field <ExtendedRenderEditable._caretPainter@483409610>: late final (offset: 0xac)
    //     0x6decf0: ldr             x2, [x2, #0x348]
    // 0x6decf4: r0 = InitLateFinalInstanceField()
    //     0x6decf4: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x6decf8: mov             x1, x0
    // 0x6decfc: ldur            x0, [fp, #-8]
    // 0x6ded00: stur            x1, [fp, #-0x18]
    // 0x6ded04: LoadField: r2 = r0->field_b
    //     0x6ded04: ldur            w2, [x0, #0xb]
    // 0x6ded08: DecompressPointer r2
    //     0x6ded08: add             x2, x2, HEAP, lsl #32
    // 0x6ded0c: stur            x2, [fp, #-0x10]
    // 0x6ded10: LoadField: r3 = r0->field_f
    //     0x6ded10: ldur            w3, [x0, #0xf]
    // 0x6ded14: DecompressPointer r3
    //     0x6ded14: add             x3, x3, HEAP, lsl #32
    // 0x6ded18: LoadField: r4 = r3->field_b
    //     0x6ded18: ldur            w4, [x3, #0xb]
    // 0x6ded1c: DecompressPointer r4
    //     0x6ded1c: add             x4, x4, HEAP, lsl #32
    // 0x6ded20: cmp             w2, w4
    // 0x6ded24: b.ne            #0x6ded34
    // 0x6ded28: SaveReg r0
    //     0x6ded28: str             x0, [SP, #-8]!
    // 0x6ded2c: r0 = _growToNextCapacity()
    //     0x6ded2c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6ded30: add             SP, SP, #8
    // 0x6ded34: ldur            x2, [fp, #-8]
    // 0x6ded38: ldur            x0, [fp, #-0x10]
    // 0x6ded3c: r3 = LoadInt32Instr(r0)
    //     0x6ded3c: sbfx            x3, x0, #1, #0x1f
    // 0x6ded40: add             x0, x3, #1
    // 0x6ded44: lsl             x1, x0, #1
    // 0x6ded48: StoreField: r2->field_b = r1
    //     0x6ded48: stur            w1, [x2, #0xb]
    // 0x6ded4c: mov             x1, x3
    // 0x6ded50: cmp             x1, x0
    // 0x6ded54: b.hs            #0x6dedf4
    // 0x6ded58: LoadField: r1 = r2->field_f
    //     0x6ded58: ldur            w1, [x2, #0xf]
    // 0x6ded5c: DecompressPointer r1
    //     0x6ded5c: add             x1, x1, HEAP, lsl #32
    // 0x6ded60: ldur            x0, [fp, #-0x18]
    // 0x6ded64: ArrayStore: r1[r3] = r0  ; List_4
    //     0x6ded64: add             x25, x1, x3, lsl #2
    //     0x6ded68: add             x25, x25, #0xf
    //     0x6ded6c: str             w0, [x25]
    //     0x6ded70: tbz             w0, #0, #0x6ded8c
    //     0x6ded74: ldurb           w16, [x1, #-1]
    //     0x6ded78: ldurb           w17, [x0, #-1]
    //     0x6ded7c: and             x16, x17, x16, lsr #2
    //     0x6ded80: tst             x16, HEAP, lsr #32
    //     0x6ded84: b.eq            #0x6ded8c
    //     0x6ded88: bl              #0xd67e5c
    // 0x6ded8c: b               #0x6ded94
    // 0x6ded90: mov             x2, x0
    // 0x6ded94: r0 = _CompositeRenderEditablePainter()
    //     0x6ded94: bl              #0x6deb38  ; Allocate_CompositeRenderEditablePainterStub -> _CompositeRenderEditablePainter (size=0x28)
    // 0x6ded98: mov             x1, x0
    // 0x6ded9c: ldur            x0, [fp, #-8]
    // 0x6deda0: stur            x1, [fp, #-0x10]
    // 0x6deda4: StoreField: r1->field_23 = r0
    //     0x6deda4: stur            w0, [x1, #0x23]
    // 0x6deda8: r0 = 0
    //     0x6deda8: mov             x0, #0
    // 0x6dedac: StoreField: r1->field_7 = r0
    //     0x6dedac: stur            x0, [x1, #7]
    // 0x6dedb0: StoreField: r1->field_13 = r0
    //     0x6dedb0: stur            x0, [x1, #0x13]
    // 0x6dedb4: StoreField: r1->field_1b = r0
    //     0x6dedb4: stur            x0, [x1, #0x1b]
    // 0x6dedb8: r0 = InitLateStaticField(0xac0) // [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_emptyListeners
    //     0x6dedb8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6dedbc: ldr             x0, [x0, #0x1580]
    //     0x6dedc0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6dedc4: cmp             w0, w16
    //     0x6dedc8: b.ne            #0x6dedd4
    //     0x6dedcc: ldr             x2, [PP, #0x44a0]  ; [pp+0x44a0] Field <ChangeNotifier._emptyListeners@171329750>: static late final (offset: 0xac0)
    //     0x6dedd0: bl              #0xd67cdc
    // 0x6dedd4: mov             x1, x0
    // 0x6dedd8: ldur            x0, [fp, #-0x10]
    // 0x6deddc: StoreField: r0->field_f = r1
    //     0x6deddc: stur            w1, [x0, #0xf]
    // 0x6dede0: LeaveFrame
    //     0x6dede0: mov             SP, fp
    //     0x6dede4: ldp             fp, lr, [SP], #0x10
    // 0x6dede8: ret
    //     0x6dede8: ret             
    // 0x6dedec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6dedec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6dedf0: b               #0x6decac
    // 0x6dedf4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6dedf4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  set _ devicePixelRatio=(/* No info */) {
    // ** addr: 0x6dedf8, size: 0x64
    // 0x6dedf8: EnterFrame
    //     0x6dedf8: stp             fp, lr, [SP, #-0x10]!
    //     0x6dedfc: mov             fp, SP
    // 0x6dee00: CheckStackOverflow
    //     0x6dee00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6dee04: cmp             SP, x16
    //     0x6dee08: b.ls            #0x6dee54
    // 0x6dee0c: ldr             x0, [fp, #0x18]
    // 0x6dee10: LoadField: d0 = r0->field_cb
    //     0x6dee10: ldur            d0, [x0, #0xcb]
    // 0x6dee14: ldr             d1, [fp, #0x10]
    // 0x6dee18: fcmp            d0, d1
    // 0x6dee1c: b.vs            #0x6dee34
    // 0x6dee20: b.ne            #0x6dee34
    // 0x6dee24: r0 = Null
    //     0x6dee24: mov             x0, NULL
    // 0x6dee28: LeaveFrame
    //     0x6dee28: mov             SP, fp
    //     0x6dee2c: ldp             fp, lr, [SP], #0x10
    // 0x6dee30: ret
    //     0x6dee30: ret             
    // 0x6dee34: StoreField: r0->field_cb = d1
    //     0x6dee34: stur            d1, [x0, #0xcb]
    // 0x6dee38: SaveReg r0
    //     0x6dee38: str             x0, [SP, #-8]!
    // 0x6dee3c: r0 = markNeedsTextLayout()
    //     0x6dee3c: bl              #0x6dee5c  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::markNeedsTextLayout
    // 0x6dee40: add             SP, SP, #8
    // 0x6dee44: r0 = Null
    //     0x6dee44: mov             x0, NULL
    // 0x6dee48: LeaveFrame
    //     0x6dee48: mov             SP, fp
    //     0x6dee4c: ldp             fp, lr, [SP], #0x10
    // 0x6dee50: ret
    //     0x6dee50: ret             
    // 0x6dee54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6dee54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6dee58: b               #0x6dee0c
  }
  set _ selectionWidthStyle=(/* No info */) {
    // ** addr: 0x6deea0, size: 0x4c
    // 0x6deea0: EnterFrame
    //     0x6deea0: stp             fp, lr, [SP, #-0x10]!
    //     0x6deea4: mov             fp, SP
    // 0x6deea8: CheckStackOverflow
    //     0x6deea8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6deeac: cmp             SP, x16
    //     0x6deeb0: b.ls            #0x6deee4
    // 0x6deeb4: ldr             x0, [fp, #0x18]
    // 0x6deeb8: LoadField: r1 = r0->field_af
    //     0x6deeb8: ldur            w1, [x0, #0xaf]
    // 0x6deebc: DecompressPointer r1
    //     0x6deebc: add             x1, x1, HEAP, lsl #32
    // 0x6deec0: r16 = Instance_BoxWidthStyle
    //     0x6deec0: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f288] Obj!BoxWidthStyle@b66d91
    //     0x6deec4: ldr             x16, [x16, #0x288]
    // 0x6deec8: stp             x16, x1, [SP, #-0x10]!
    // 0x6deecc: r0 = Shader._()
    //     0x6deecc: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x6deed0: add             SP, SP, #0x10
    // 0x6deed4: r0 = Null
    //     0x6deed4: mov             x0, NULL
    // 0x6deed8: LeaveFrame
    //     0x6deed8: mov             SP, fp
    //     0x6deedc: ldp             fp, lr, [SP], #0x10
    // 0x6deee0: ret
    //     0x6deee0: ret             
    // 0x6deee4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6deee4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6deee8: b               #0x6deeb4
  }
  set _ selectionHeightStyle=(/* No info */) {
    // ** addr: 0x6deeec, size: 0x4c
    // 0x6deeec: EnterFrame
    //     0x6deeec: stp             fp, lr, [SP, #-0x10]!
    //     0x6deef0: mov             fp, SP
    // 0x6deef4: CheckStackOverflow
    //     0x6deef4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6deef8: cmp             SP, x16
    //     0x6deefc: b.ls            #0x6def30
    // 0x6def00: ldr             x0, [fp, #0x18]
    // 0x6def04: LoadField: r1 = r0->field_af
    //     0x6def04: ldur            w1, [x0, #0xaf]
    // 0x6def08: DecompressPointer r1
    //     0x6def08: add             x1, x1, HEAP, lsl #32
    // 0x6def0c: r16 = Instance_BoxHeightStyle
    //     0x6def0c: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f280] Obj!BoxHeightStyle@b66db1
    //     0x6def10: ldr             x16, [x16, #0x280]
    // 0x6def14: stp             x16, x1, [SP, #-0x10]!
    // 0x6def18: r0 = Shader._()
    //     0x6def18: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x6def1c: add             SP, SP, #0x10
    // 0x6def20: r0 = Null
    //     0x6def20: mov             x0, NULL
    // 0x6def24: LeaveFrame
    //     0x6def24: mov             SP, fp
    //     0x6def28: ldp             fp, lr, [SP], #0x10
    // 0x6def2c: ret
    //     0x6def2c: ret             
    // 0x6def30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6def30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6def34: b               #0x6def00
  }
  set _ cursorOffset=(/* No info */) {
    // ** addr: 0x6def38, size: 0x60
    // 0x6def38: EnterFrame
    //     0x6def38: stp             fp, lr, [SP, #-0x10]!
    //     0x6def3c: mov             fp, SP
    // 0x6def40: CheckStackOverflow
    //     0x6def40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6def44: cmp             SP, x16
    //     0x6def48: b.ls            #0x6def90
    // 0x6def4c: ldr             x1, [fp, #0x18]
    // 0x6def50: LoadField: r0 = r1->field_ab
    //     0x6def50: ldur            w0, [x1, #0xab]
    // 0x6def54: DecompressPointer r0
    //     0x6def54: add             x0, x0, HEAP, lsl #32
    // 0x6def58: r16 = Sentinel
    //     0x6def58: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6def5c: cmp             w0, w16
    // 0x6def60: b.ne            #0x6def70
    // 0x6def64: r2 = _caretPainter
    //     0x6def64: add             x2, PP, #0x37, lsl #12  ; [pp+0x37348] Field <ExtendedRenderEditable._caretPainter@483409610>: late final (offset: 0xac)
    //     0x6def68: ldr             x2, [x2, #0x348]
    // 0x6def6c: r0 = InitLateFinalInstanceField()
    //     0x6def6c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x6def70: ldr             x16, [fp, #0x10]
    // 0x6def74: stp             x16, x0, [SP, #-0x10]!
    // 0x6def78: r0 = cursorOffset=()
    //     0x6def78: bl              #0x6def98  ; [package:extended_text_field/src/extended_render_editable.dart] _FloatingCursorPainter::cursorOffset=
    // 0x6def7c: add             SP, SP, #0x10
    // 0x6def80: r0 = Null
    //     0x6def80: mov             x0, NULL
    // 0x6def84: LeaveFrame
    //     0x6def84: mov             SP, fp
    //     0x6def88: ldp             fp, lr, [SP], #0x10
    // 0x6def8c: ret
    //     0x6def8c: ret             
    // 0x6def90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6def90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6def94: b               #0x6def4c
  }
  set _ cursorRadius=(/* No info */) {
    // ** addr: 0x6df024, size: 0x60
    // 0x6df024: EnterFrame
    //     0x6df024: stp             fp, lr, [SP, #-0x10]!
    //     0x6df028: mov             fp, SP
    // 0x6df02c: CheckStackOverflow
    //     0x6df02c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6df030: cmp             SP, x16
    //     0x6df034: b.ls            #0x6df07c
    // 0x6df038: ldr             x1, [fp, #0x18]
    // 0x6df03c: LoadField: r0 = r1->field_ab
    //     0x6df03c: ldur            w0, [x1, #0xab]
    // 0x6df040: DecompressPointer r0
    //     0x6df040: add             x0, x0, HEAP, lsl #32
    // 0x6df044: r16 = Sentinel
    //     0x6df044: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6df048: cmp             w0, w16
    // 0x6df04c: b.ne            #0x6df05c
    // 0x6df050: r2 = _caretPainter
    //     0x6df050: add             x2, PP, #0x37, lsl #12  ; [pp+0x37348] Field <ExtendedRenderEditable._caretPainter@483409610>: late final (offset: 0xac)
    //     0x6df054: ldr             x2, [x2, #0x348]
    // 0x6df058: r0 = InitLateFinalInstanceField()
    //     0x6df058: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x6df05c: ldr             x16, [fp, #0x10]
    // 0x6df060: stp             x16, x0, [SP, #-0x10]!
    // 0x6df064: r0 = cursorRadius=()
    //     0x6df064: bl              #0x6df084  ; [package:extended_text_field/src/extended_render_editable.dart] _FloatingCursorPainter::cursorRadius=
    // 0x6df068: add             SP, SP, #0x10
    // 0x6df06c: r0 = Null
    //     0x6df06c: mov             x0, NULL
    // 0x6df070: LeaveFrame
    //     0x6df070: mov             SP, fp
    //     0x6df074: ldp             fp, lr, [SP], #0x10
    // 0x6df078: ret
    //     0x6df078: ret             
    // 0x6df07c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6df07c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6df080: b               #0x6df038
  }
  set _ cursorWidth=(/* No info */) {
    // ** addr: 0x6df124, size: 0x7c
    // 0x6df124: EnterFrame
    //     0x6df124: stp             fp, lr, [SP, #-0x10]!
    //     0x6df128: mov             fp, SP
    // 0x6df12c: d0 = 2.000000
    //     0x6df12c: fmov            d0, #2.00000000
    // 0x6df130: CheckStackOverflow
    //     0x6df130: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6df134: cmp             SP, x16
    //     0x6df138: b.ls            #0x6df198
    // 0x6df13c: ldr             x0, [fp, #0x18]
    // 0x6df140: r17 = 279
    //     0x6df140: mov             x17, #0x117
    // 0x6df144: ldr             w1, [x0, x17]
    // 0x6df148: DecompressPointer r1
    //     0x6df148: add             x1, x1, HEAP, lsl #32
    // 0x6df14c: LoadField: d1 = r1->field_7
    //     0x6df14c: ldur            d1, [x1, #7]
    // 0x6df150: fcmp            d1, d0
    // 0x6df154: b.vs            #0x6df16c
    // 0x6df158: b.ne            #0x6df16c
    // 0x6df15c: r0 = Null
    //     0x6df15c: mov             x0, NULL
    // 0x6df160: LeaveFrame
    //     0x6df160: mov             SP, fp
    //     0x6df164: ldp             fp, lr, [SP], #0x10
    // 0x6df168: ret
    //     0x6df168: ret             
    // 0x6df16c: r1 = 2.000000
    //     0x6df16c: add             x1, PP, #0x25, lsl #12  ; [pp+0x259a8] 2
    //     0x6df170: ldr             x1, [x1, #0x9a8]
    // 0x6df174: add             x16, x0, #0x117
    // 0x6df178: str             w1, [x16]
    // 0x6df17c: SaveReg r0
    //     0x6df17c: str             x0, [SP, #-8]!
    // 0x6df180: r0 = markNeedsLayout()
    //     0x6df180: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6df184: add             SP, SP, #8
    // 0x6df188: r0 = Null
    //     0x6df188: mov             x0, NULL
    // 0x6df18c: LeaveFrame
    //     0x6df18c: mov             SP, fp
    //     0x6df190: ldp             fp, lr, [SP], #0x10
    // 0x6df194: ret
    //     0x6df194: ret             
    // 0x6df198: r0 = StackOverflowSharedWithFPURegs()
    //     0x6df198: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x6df19c: b               #0x6df13c
  }
  set _ offset=(/* No info */) {
    // ** addr: 0x6df1a0, size: 0x120
    // 0x6df1a0: EnterFrame
    //     0x6df1a0: stp             fp, lr, [SP, #-0x10]!
    //     0x6df1a4: mov             fp, SP
    // 0x6df1a8: AllocStack(0x8)
    //     0x6df1a8: sub             SP, SP, #8
    // 0x6df1ac: CheckStackOverflow
    //     0x6df1ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6df1b0: cmp             SP, x16
    //     0x6df1b4: b.ls            #0x6df2b8
    // 0x6df1b8: ldr             x0, [fp, #0x18]
    // 0x6df1bc: r17 = 275
    //     0x6df1bc: mov             x17, #0x113
    // 0x6df1c0: ldr             w1, [x0, x17]
    // 0x6df1c4: DecompressPointer r1
    //     0x6df1c4: add             x1, x1, HEAP, lsl #32
    // 0x6df1c8: ldr             x2, [fp, #0x10]
    // 0x6df1cc: stur            x1, [fp, #-8]
    // 0x6df1d0: cmp             w1, w2
    // 0x6df1d4: b.ne            #0x6df1e8
    // 0x6df1d8: r0 = Null
    //     0x6df1d8: mov             x0, NULL
    // 0x6df1dc: LeaveFrame
    //     0x6df1dc: mov             SP, fp
    //     0x6df1e0: ldp             fp, lr, [SP], #0x10
    // 0x6df1e4: ret
    //     0x6df1e4: ret             
    // 0x6df1e8: LoadField: r3 = r0->field_f
    //     0x6df1e8: ldur            w3, [x0, #0xf]
    // 0x6df1ec: DecompressPointer r3
    //     0x6df1ec: add             x3, x3, HEAP, lsl #32
    // 0x6df1f0: cmp             w3, NULL
    // 0x6df1f4: b.eq            #0x6df22c
    // 0x6df1f8: r1 = 1
    //     0x6df1f8: mov             x1, #1
    // 0x6df1fc: r0 = AllocateContext()
    //     0x6df1fc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6df200: mov             x1, x0
    // 0x6df204: ldr             x0, [fp, #0x18]
    // 0x6df208: StoreField: r1->field_f = r0
    //     0x6df208: stur            w0, [x1, #0xf]
    // 0x6df20c: mov             x2, x1
    // 0x6df210: r1 = Function 'markNeedsPaint':.
    //     0x6df210: add             x1, PP, #0x55, lsl #12  ; [pp+0x55b48] AnonymousClosure: (0x6bf010), in [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::markNeedsPaint (0x6bef94)
    //     0x6df214: ldr             x1, [x1, #0xb48]
    // 0x6df218: r0 = AllocateClosure()
    //     0x6df218: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6df21c: ldur            x16, [fp, #-8]
    // 0x6df220: stp             x0, x16, [SP, #-0x10]!
    // 0x6df224: r0 = removeListener()
    //     0x6df224: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x6df228: add             SP, SP, #0x10
    // 0x6df22c: ldr             x1, [fp, #0x18]
    // 0x6df230: ldr             x0, [fp, #0x10]
    // 0x6df234: r17 = 275
    //     0x6df234: mov             x17, #0x113
    // 0x6df238: str             w0, [x1, x17]
    // 0x6df23c: WriteBarrierInstr(obj = r1, val = r0)
    //     0x6df23c: ldurb           w16, [x1, #-1]
    //     0x6df240: ldurb           w17, [x0, #-1]
    //     0x6df244: and             x16, x17, x16, lsr #2
    //     0x6df248: tst             x16, HEAP, lsr #32
    //     0x6df24c: b.eq            #0x6df254
    //     0x6df250: bl              #0xd6826c
    // 0x6df254: LoadField: r0 = r1->field_f
    //     0x6df254: ldur            w0, [x1, #0xf]
    // 0x6df258: DecompressPointer r0
    //     0x6df258: add             x0, x0, HEAP, lsl #32
    // 0x6df25c: cmp             w0, NULL
    // 0x6df260: b.eq            #0x6df298
    // 0x6df264: r1 = 1
    //     0x6df264: mov             x1, #1
    // 0x6df268: r0 = AllocateContext()
    //     0x6df268: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6df26c: mov             x1, x0
    // 0x6df270: ldr             x0, [fp, #0x18]
    // 0x6df274: StoreField: r1->field_f = r0
    //     0x6df274: stur            w0, [x1, #0xf]
    // 0x6df278: mov             x2, x1
    // 0x6df27c: r1 = Function 'markNeedsPaint':.
    //     0x6df27c: add             x1, PP, #0x55, lsl #12  ; [pp+0x55b48] AnonymousClosure: (0x6bf010), in [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::markNeedsPaint (0x6bef94)
    //     0x6df280: ldr             x1, [x1, #0xb48]
    // 0x6df284: r0 = AllocateClosure()
    //     0x6df284: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6df288: ldr             x16, [fp, #0x10]
    // 0x6df28c: stp             x0, x16, [SP, #-0x10]!
    // 0x6df290: r0 = addListener()
    //     0x6df290: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x6df294: add             SP, SP, #0x10
    // 0x6df298: ldr             x16, [fp, #0x18]
    // 0x6df29c: SaveReg r16
    //     0x6df29c: str             x16, [SP, #-8]!
    // 0x6df2a0: r0 = markNeedsLayout()
    //     0x6df2a0: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6df2a4: add             SP, SP, #8
    // 0x6df2a8: r0 = Null
    //     0x6df2a8: mov             x0, NULL
    // 0x6df2ac: LeaveFrame
    //     0x6df2ac: mov             SP, fp
    //     0x6df2b0: ldp             fp, lr, [SP], #0x10
    // 0x6df2b4: ret
    //     0x6df2b4: ret             
    // 0x6df2b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6df2b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6df2bc: b               #0x6df1b8
  }
  set _ selection=(/* No info */) {
    // ** addr: 0x6df2c0, size: 0xd8
    // 0x6df2c0: EnterFrame
    //     0x6df2c0: stp             fp, lr, [SP, #-0x10]!
    //     0x6df2c4: mov             fp, SP
    // 0x6df2c8: AllocStack(0x8)
    //     0x6df2c8: sub             SP, SP, #8
    // 0x6df2cc: CheckStackOverflow
    //     0x6df2cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6df2d0: cmp             SP, x16
    //     0x6df2d4: b.ls            #0x6df390
    // 0x6df2d8: ldr             x0, [fp, #0x18]
    // 0x6df2dc: r17 = 271
    //     0x6df2dc: mov             x17, #0x10f
    // 0x6df2e0: ldr             w1, [x0, x17]
    // 0x6df2e4: DecompressPointer r1
    //     0x6df2e4: add             x1, x1, HEAP, lsl #32
    // 0x6df2e8: ldr             x16, [fp, #0x10]
    // 0x6df2ec: stp             x16, x1, [SP, #-0x10]!
    // 0x6df2f0: r0 = ==()
    //     0x6df2f0: bl              #0xc68a30  ; [package:flutter/src/services/text_editing.dart] TextSelection::==
    // 0x6df2f4: add             SP, SP, #0x10
    // 0x6df2f8: tbnz            w0, #4, #0x6df30c
    // 0x6df2fc: r0 = Null
    //     0x6df2fc: mov             x0, NULL
    // 0x6df300: LeaveFrame
    //     0x6df300: mov             SP, fp
    //     0x6df304: ldp             fp, lr, [SP], #0x10
    // 0x6df308: ret
    //     0x6df308: ret             
    // 0x6df30c: ldr             x1, [fp, #0x18]
    // 0x6df310: ldr             x0, [fp, #0x10]
    // 0x6df314: r17 = 271
    //     0x6df314: mov             x17, #0x10f
    // 0x6df318: str             w0, [x1, x17]
    // 0x6df31c: WriteBarrierInstr(obj = r1, val = r0)
    //     0x6df31c: ldurb           w16, [x1, #-1]
    //     0x6df320: ldurb           w17, [x0, #-1]
    //     0x6df324: and             x16, x17, x16, lsr #2
    //     0x6df328: tst             x16, HEAP, lsr #32
    //     0x6df32c: b.eq            #0x6df334
    //     0x6df330: bl              #0xd6826c
    // 0x6df334: LoadField: r0 = r1->field_af
    //     0x6df334: ldur            w0, [x1, #0xaf]
    // 0x6df338: DecompressPointer r0
    //     0x6df338: add             x0, x0, HEAP, lsl #32
    // 0x6df33c: stur            x0, [fp, #-8]
    // 0x6df340: SaveReg r1
    //     0x6df340: str             x1, [SP, #-8]!
    // 0x6df344: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6df344: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6df348: r0 = getActualSelection()
    //     0x6df348: bl              #0x6de46c  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::getActualSelection
    // 0x6df34c: add             SP, SP, #8
    // 0x6df350: ldur            x16, [fp, #-8]
    // 0x6df354: stp             x0, x16, [SP, #-0x10]!
    // 0x6df358: r0 = highlightedRange=()
    //     0x6df358: bl              #0x6de3cc  ; [package:extended_text_library/src/selection/painter.dart] TextHighlightPainter::highlightedRange=
    // 0x6df35c: add             SP, SP, #0x10
    // 0x6df360: ldr             x16, [fp, #0x18]
    // 0x6df364: SaveReg r16
    //     0x6df364: str             x16, [SP, #-8]!
    // 0x6df368: r0 = markNeedsPaint()
    //     0x6df368: bl              #0x6bef94  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::markNeedsPaint
    // 0x6df36c: add             SP, SP, #8
    // 0x6df370: ldr             x16, [fp, #0x18]
    // 0x6df374: SaveReg r16
    //     0x6df374: str             x16, [SP, #-8]!
    // 0x6df378: r0 = markNeedsSemanticsUpdate()
    //     0x6df378: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6df37c: add             SP, SP, #8
    // 0x6df380: r0 = Null
    //     0x6df380: mov             x0, NULL
    // 0x6df384: LeaveFrame
    //     0x6df384: mov             SP, fp
    //     0x6df388: ldp             fp, lr, [SP], #0x10
    // 0x6df38c: ret
    //     0x6df38c: ret             
    // 0x6df390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6df390: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6df394: b               #0x6df2d8
  }
  set _ locale=(/* No info */) {
    // ** addr: 0x6df398, size: 0xa4
    // 0x6df398: EnterFrame
    //     0x6df398: stp             fp, lr, [SP, #-0x10]!
    //     0x6df39c: mov             fp, SP
    // 0x6df3a0: AllocStack(0x8)
    //     0x6df3a0: sub             SP, SP, #8
    // 0x6df3a4: CheckStackOverflow
    //     0x6df3a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6df3a8: cmp             SP, x16
    //     0x6df3ac: b.ls            #0x6df434
    // 0x6df3b0: ldr             x1, [fp, #0x18]
    // 0x6df3b4: LoadField: r2 = r1->field_eb
    //     0x6df3b4: ldur            w2, [x1, #0xeb]
    // 0x6df3b8: DecompressPointer r2
    //     0x6df3b8: add             x2, x2, HEAP, lsl #32
    // 0x6df3bc: stur            x2, [fp, #-8]
    // 0x6df3c0: LoadField: r0 = r2->field_2b
    //     0x6df3c0: ldur            w0, [x2, #0x2b]
    // 0x6df3c4: DecompressPointer r0
    //     0x6df3c4: add             x0, x0, HEAP, lsl #32
    // 0x6df3c8: r3 = LoadClassIdInstr(r0)
    //     0x6df3c8: ldur            x3, [x0, #-1]
    //     0x6df3cc: ubfx            x3, x3, #0xc, #0x14
    // 0x6df3d0: ldr             x16, [fp, #0x10]
    // 0x6df3d4: stp             x16, x0, [SP, #-0x10]!
    // 0x6df3d8: mov             x0, x3
    // 0x6df3dc: mov             lr, x0
    // 0x6df3e0: ldr             lr, [x21, lr, lsl #3]
    // 0x6df3e4: blr             lr
    // 0x6df3e8: add             SP, SP, #0x10
    // 0x6df3ec: tbnz            w0, #4, #0x6df400
    // 0x6df3f0: r0 = Null
    //     0x6df3f0: mov             x0, NULL
    // 0x6df3f4: LeaveFrame
    //     0x6df3f4: mov             SP, fp
    //     0x6df3f8: ldp             fp, lr, [SP], #0x10
    // 0x6df3fc: ret
    //     0x6df3fc: ret             
    // 0x6df400: ldur            x16, [fp, #-8]
    // 0x6df404: ldr             lr, [fp, #0x10]
    // 0x6df408: stp             lr, x16, [SP, #-0x10]!
    // 0x6df40c: r0 = locale=()
    //     0x6df40c: bl              #0x6df43c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::locale=
    // 0x6df410: add             SP, SP, #0x10
    // 0x6df414: ldr             x16, [fp, #0x18]
    // 0x6df418: SaveReg r16
    //     0x6df418: str             x16, [SP, #-8]!
    // 0x6df41c: r0 = markNeedsTextLayout()
    //     0x6df41c: bl              #0x6dee5c  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::markNeedsTextLayout
    // 0x6df420: add             SP, SP, #8
    // 0x6df424: r0 = Null
    //     0x6df424: mov             x0, NULL
    // 0x6df428: LeaveFrame
    //     0x6df428: mov             SP, fp
    //     0x6df42c: ldp             fp, lr, [SP], #0x10
    // 0x6df430: ret
    //     0x6df430: ret             
    // 0x6df434: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6df434: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6df438: b               #0x6df3b0
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0x6df4dc, size: 0x88
    // 0x6df4dc: EnterFrame
    //     0x6df4dc: stp             fp, lr, [SP, #-0x10]!
    //     0x6df4e0: mov             fp, SP
    // 0x6df4e4: CheckStackOverflow
    //     0x6df4e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6df4e8: cmp             SP, x16
    //     0x6df4ec: b.ls            #0x6df55c
    // 0x6df4f0: ldr             x0, [fp, #0x18]
    // 0x6df4f4: LoadField: r1 = r0->field_eb
    //     0x6df4f4: ldur            w1, [x0, #0xeb]
    // 0x6df4f8: DecompressPointer r1
    //     0x6df4f8: add             x1, x1, HEAP, lsl #32
    // 0x6df4fc: LoadField: r2 = r1->field_1b
    //     0x6df4fc: ldur            w2, [x1, #0x1b]
    // 0x6df500: DecompressPointer r2
    //     0x6df500: add             x2, x2, HEAP, lsl #32
    // 0x6df504: ldr             x3, [fp, #0x10]
    // 0x6df508: cmp             w2, w3
    // 0x6df50c: b.ne            #0x6df520
    // 0x6df510: r0 = Null
    //     0x6df510: mov             x0, NULL
    // 0x6df514: LeaveFrame
    //     0x6df514: mov             SP, fp
    //     0x6df518: ldp             fp, lr, [SP], #0x10
    // 0x6df51c: ret
    //     0x6df51c: ret             
    // 0x6df520: stp             x3, x1, [SP, #-0x10]!
    // 0x6df524: r0 = textDirection=()
    //     0x6df524: bl              #0x673280  ; [package:flutter/src/painting/text_painter.dart] TextPainter::textDirection=
    // 0x6df528: add             SP, SP, #0x10
    // 0x6df52c: ldr             x16, [fp, #0x18]
    // 0x6df530: SaveReg r16
    //     0x6df530: str             x16, [SP, #-8]!
    // 0x6df534: r0 = markNeedsTextLayout()
    //     0x6df534: bl              #0x6dee5c  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::markNeedsTextLayout
    // 0x6df538: add             SP, SP, #8
    // 0x6df53c: ldr             x16, [fp, #0x18]
    // 0x6df540: SaveReg r16
    //     0x6df540: str             x16, [SP, #-8]!
    // 0x6df544: r0 = markNeedsSemanticsUpdate()
    //     0x6df544: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6df548: add             SP, SP, #8
    // 0x6df54c: r0 = Null
    //     0x6df54c: mov             x0, NULL
    // 0x6df550: LeaveFrame
    //     0x6df550: mov             SP, fp
    //     0x6df554: ldp             fp, lr, [SP], #0x10
    // 0x6df558: ret
    //     0x6df558: ret             
    // 0x6df55c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6df55c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6df560: b               #0x6df4f0
  }
  set _ textAlign=(/* No info */) {
    // ** addr: 0x6df564, size: 0x98
    // 0x6df564: EnterFrame
    //     0x6df564: stp             fp, lr, [SP, #-0x10]!
    //     0x6df568: mov             fp, SP
    // 0x6df56c: CheckStackOverflow
    //     0x6df56c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6df570: cmp             SP, x16
    //     0x6df574: b.ls            #0x6df5f4
    // 0x6df578: ldr             x0, [fp, #0x18]
    // 0x6df57c: LoadField: r1 = r0->field_eb
    //     0x6df57c: ldur            w1, [x0, #0xeb]
    // 0x6df580: DecompressPointer r1
    //     0x6df580: add             x1, x1, HEAP, lsl #32
    // 0x6df584: LoadField: r2 = r1->field_17
    //     0x6df584: ldur            w2, [x1, #0x17]
    // 0x6df588: DecompressPointer r2
    //     0x6df588: add             x2, x2, HEAP, lsl #32
    // 0x6df58c: r16 = Instance_TextAlign
    //     0x6df58c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14fe8] Obj!TextAlign@b66f71
    //     0x6df590: ldr             x16, [x16, #0xfe8]
    // 0x6df594: cmp             w2, w16
    // 0x6df598: b.ne            #0x6df5ac
    // 0x6df59c: r0 = Null
    //     0x6df59c: mov             x0, NULL
    // 0x6df5a0: LeaveFrame
    //     0x6df5a0: mov             SP, fp
    //     0x6df5a4: ldp             fp, lr, [SP], #0x10
    // 0x6df5a8: ret
    //     0x6df5a8: ret             
    // 0x6df5ac: r16 = Instance_TextAlign
    //     0x6df5ac: add             x16, PP, #0x14, lsl #12  ; [pp+0x14fe8] Obj!TextAlign@b66f71
    //     0x6df5b0: ldr             x16, [x16, #0xfe8]
    // 0x6df5b4: cmp             w2, w16
    // 0x6df5b8: b.eq            #0x6df5d4
    // 0x6df5bc: r2 = Instance_TextAlign
    //     0x6df5bc: add             x2, PP, #0x14, lsl #12  ; [pp+0x14fe8] Obj!TextAlign@b66f71
    //     0x6df5c0: ldr             x2, [x2, #0xfe8]
    // 0x6df5c4: StoreField: r1->field_17 = r2
    //     0x6df5c4: stur            w2, [x1, #0x17]
    // 0x6df5c8: SaveReg r1
    //     0x6df5c8: str             x1, [SP, #-8]!
    // 0x6df5cc: r0 = markNeedsLayout()
    //     0x6df5cc: bl              #0x62d54c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0x6df5d0: add             SP, SP, #8
    // 0x6df5d4: ldr             x16, [fp, #0x18]
    // 0x6df5d8: SaveReg r16
    //     0x6df5d8: str             x16, [SP, #-8]!
    // 0x6df5dc: r0 = markNeedsTextLayout()
    //     0x6df5dc: bl              #0x6dee5c  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::markNeedsTextLayout
    // 0x6df5e0: add             SP, SP, #8
    // 0x6df5e4: r0 = Null
    //     0x6df5e4: mov             x0, NULL
    // 0x6df5e8: LeaveFrame
    //     0x6df5e8: mov             SP, fp
    //     0x6df5ec: ldp             fp, lr, [SP], #0x10
    // 0x6df5f0: ret
    //     0x6df5f0: ret             
    // 0x6df5f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6df5f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6df5f8: b               #0x6df578
  }
  set _ selectionColor=(/* No info */) {
    // ** addr: 0x6df78c, size: 0x48
    // 0x6df78c: EnterFrame
    //     0x6df78c: stp             fp, lr, [SP, #-0x10]!
    //     0x6df790: mov             fp, SP
    // 0x6df794: CheckStackOverflow
    //     0x6df794: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6df798: cmp             SP, x16
    //     0x6df79c: b.ls            #0x6df7cc
    // 0x6df7a0: ldr             x0, [fp, #0x18]
    // 0x6df7a4: LoadField: r1 = r0->field_af
    //     0x6df7a4: ldur            w1, [x0, #0xaf]
    // 0x6df7a8: DecompressPointer r1
    //     0x6df7a8: add             x1, x1, HEAP, lsl #32
    // 0x6df7ac: ldr             x16, [fp, #0x10]
    // 0x6df7b0: stp             x16, x1, [SP, #-0x10]!
    // 0x6df7b4: r0 = highlightColor=()
    //     0x6df7b4: bl              #0x6de5f4  ; [package:extended_text_library/src/selection/painter.dart] TextHighlightPainter::highlightColor=
    // 0x6df7b8: add             SP, SP, #0x10
    // 0x6df7bc: r0 = Null
    //     0x6df7bc: mov             x0, NULL
    // 0x6df7c0: LeaveFrame
    //     0x6df7c0: mov             SP, fp
    //     0x6df7c4: ldp             fp, lr, [SP], #0x10
    // 0x6df7c8: ret
    //     0x6df7c8: ret             
    // 0x6df7cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6df7cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6df7d0: b               #0x6df7a0
  }
  set _ strutStyle=(/* No info */) {
    // ** addr: 0x6df7d4, size: 0xa4
    // 0x6df7d4: EnterFrame
    //     0x6df7d4: stp             fp, lr, [SP, #-0x10]!
    //     0x6df7d8: mov             fp, SP
    // 0x6df7dc: AllocStack(0x8)
    //     0x6df7dc: sub             SP, SP, #8
    // 0x6df7e0: CheckStackOverflow
    //     0x6df7e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6df7e4: cmp             SP, x16
    //     0x6df7e8: b.ls            #0x6df870
    // 0x6df7ec: ldr             x1, [fp, #0x18]
    // 0x6df7f0: LoadField: r2 = r1->field_eb
    //     0x6df7f0: ldur            w2, [x1, #0xeb]
    // 0x6df7f4: DecompressPointer r2
    //     0x6df7f4: add             x2, x2, HEAP, lsl #32
    // 0x6df7f8: stur            x2, [fp, #-8]
    // 0x6df7fc: LoadField: r0 = r2->field_33
    //     0x6df7fc: ldur            w0, [x2, #0x33]
    // 0x6df800: DecompressPointer r0
    //     0x6df800: add             x0, x0, HEAP, lsl #32
    // 0x6df804: r3 = LoadClassIdInstr(r0)
    //     0x6df804: ldur            x3, [x0, #-1]
    //     0x6df808: ubfx            x3, x3, #0xc, #0x14
    // 0x6df80c: ldr             x16, [fp, #0x10]
    // 0x6df810: stp             x16, x0, [SP, #-0x10]!
    // 0x6df814: mov             x0, x3
    // 0x6df818: mov             lr, x0
    // 0x6df81c: ldr             lr, [x21, lr, lsl #3]
    // 0x6df820: blr             lr
    // 0x6df824: add             SP, SP, #0x10
    // 0x6df828: tbnz            w0, #4, #0x6df83c
    // 0x6df82c: r0 = Null
    //     0x6df82c: mov             x0, NULL
    // 0x6df830: LeaveFrame
    //     0x6df830: mov             SP, fp
    //     0x6df834: ldp             fp, lr, [SP], #0x10
    // 0x6df838: ret
    //     0x6df838: ret             
    // 0x6df83c: ldur            x16, [fp, #-8]
    // 0x6df840: ldr             lr, [fp, #0x10]
    // 0x6df844: stp             lr, x16, [SP, #-0x10]!
    // 0x6df848: r0 = strutStyle=()
    //     0x6df848: bl              #0x6df878  ; [package:flutter/src/painting/text_painter.dart] TextPainter::strutStyle=
    // 0x6df84c: add             SP, SP, #0x10
    // 0x6df850: ldr             x16, [fp, #0x18]
    // 0x6df854: SaveReg r16
    //     0x6df854: str             x16, [SP, #-8]!
    // 0x6df858: r0 = markNeedsTextLayout()
    //     0x6df858: bl              #0x6dee5c  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::markNeedsTextLayout
    // 0x6df85c: add             SP, SP, #8
    // 0x6df860: r0 = Null
    //     0x6df860: mov             x0, NULL
    // 0x6df864: LeaveFrame
    //     0x6df864: mov             SP, fp
    //     0x6df868: ldp             fp, lr, [SP], #0x10
    // 0x6df86c: ret
    //     0x6df86c: ret             
    // 0x6df870: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6df870: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6df874: b               #0x6df7ec
  }
  set _ maxLines=(/* No info */) {
    // ** addr: 0x6df918, size: 0x6c
    // 0x6df918: EnterFrame
    //     0x6df918: stp             fp, lr, [SP, #-0x10]!
    //     0x6df91c: mov             fp, SP
    // 0x6df920: CheckStackOverflow
    //     0x6df920: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6df924: cmp             SP, x16
    //     0x6df928: b.ls            #0x6df97c
    // 0x6df92c: ldr             x0, [fp, #0x18]
    // 0x6df930: r17 = 259
    //     0x6df930: mov             x17, #0x103
    // 0x6df934: ldr             w1, [x0, x17]
    // 0x6df938: DecompressPointer r1
    //     0x6df938: add             x1, x1, HEAP, lsl #32
    // 0x6df93c: ldr             x2, [fp, #0x10]
    // 0x6df940: cmp             w1, w2
    // 0x6df944: b.ne            #0x6df958
    // 0x6df948: r0 = Null
    //     0x6df948: mov             x0, NULL
    // 0x6df94c: LeaveFrame
    //     0x6df94c: mov             SP, fp
    //     0x6df950: ldp             fp, lr, [SP], #0x10
    // 0x6df954: ret
    //     0x6df954: ret             
    // 0x6df958: add             x16, x0, #0x103
    // 0x6df95c: str             w2, [x16]
    // 0x6df960: SaveReg r0
    //     0x6df960: str             x0, [SP, #-8]!
    // 0x6df964: r0 = markNeedsTextLayout()
    //     0x6df964: bl              #0x6dee5c  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::markNeedsTextLayout
    // 0x6df968: add             SP, SP, #8
    // 0x6df96c: r0 = Null
    //     0x6df96c: mov             x0, NULL
    // 0x6df970: LeaveFrame
    //     0x6df970: mov             SP, fp
    //     0x6df974: ldp             fp, lr, [SP], #0x10
    // 0x6df978: ret
    //     0x6df978: ret             
    // 0x6df97c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6df97c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6df980: b               #0x6df92c
  }
  set _ readOnly=(/* No info */) {
    // ** addr: 0x6df9e8, size: 0x64
    // 0x6df9e8: EnterFrame
    //     0x6df9e8: stp             fp, lr, [SP, #-0x10]!
    //     0x6df9ec: mov             fp, SP
    // 0x6df9f0: CheckStackOverflow
    //     0x6df9f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6df9f4: cmp             SP, x16
    //     0x6df9f8: b.ls            #0x6dfa44
    // 0x6df9fc: ldr             x0, [fp, #0x18]
    // 0x6dfa00: LoadField: r1 = r0->field_ff
    //     0x6dfa00: ldur            w1, [x0, #0xff]
    // 0x6dfa04: DecompressPointer r1
    //     0x6dfa04: add             x1, x1, HEAP, lsl #32
    // 0x6dfa08: ldr             x2, [fp, #0x10]
    // 0x6dfa0c: cmp             w1, w2
    // 0x6dfa10: b.ne            #0x6dfa24
    // 0x6dfa14: r0 = Null
    //     0x6dfa14: mov             x0, NULL
    // 0x6dfa18: LeaveFrame
    //     0x6dfa18: mov             SP, fp
    //     0x6dfa1c: ldp             fp, lr, [SP], #0x10
    // 0x6dfa20: ret
    //     0x6dfa20: ret             
    // 0x6dfa24: StoreField: r0->field_ff = r2
    //     0x6dfa24: stur            w2, [x0, #0xff]
    // 0x6dfa28: SaveReg r0
    //     0x6dfa28: str             x0, [SP, #-8]!
    // 0x6dfa2c: r0 = markNeedsSemanticsUpdate()
    //     0x6dfa2c: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6dfa30: add             SP, SP, #8
    // 0x6dfa34: r0 = Null
    //     0x6dfa34: mov             x0, NULL
    // 0x6dfa38: LeaveFrame
    //     0x6dfa38: mov             SP, fp
    //     0x6dfa3c: ldp             fp, lr, [SP], #0x10
    // 0x6dfa40: ret
    //     0x6dfa40: ret             
    // 0x6dfa44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6dfa44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6dfa48: b               #0x6df9fc
  }
  set _ forceLine=(/* No info */) {
    // ** addr: 0x6dfa4c, size: 0x60
    // 0x6dfa4c: EnterFrame
    //     0x6dfa4c: stp             fp, lr, [SP, #-0x10]!
    //     0x6dfa50: mov             fp, SP
    // 0x6dfa54: CheckStackOverflow
    //     0x6dfa54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6dfa58: cmp             SP, x16
    //     0x6dfa5c: b.ls            #0x6dfaa4
    // 0x6dfa60: ldr             x0, [fp, #0x18]
    // 0x6dfa64: LoadField: r1 = r0->field_fb
    //     0x6dfa64: ldur            w1, [x0, #0xfb]
    // 0x6dfa68: DecompressPointer r1
    //     0x6dfa68: add             x1, x1, HEAP, lsl #32
    // 0x6dfa6c: tbnz            w1, #4, #0x6dfa80
    // 0x6dfa70: r0 = Null
    //     0x6dfa70: mov             x0, NULL
    // 0x6dfa74: LeaveFrame
    //     0x6dfa74: mov             SP, fp
    //     0x6dfa78: ldp             fp, lr, [SP], #0x10
    // 0x6dfa7c: ret
    //     0x6dfa7c: ret             
    // 0x6dfa80: r1 = true
    //     0x6dfa80: add             x1, NULL, #0x20  ; true
    // 0x6dfa84: StoreField: r0->field_fb = r1
    //     0x6dfa84: stur            w1, [x0, #0xfb]
    // 0x6dfa88: SaveReg r0
    //     0x6dfa88: str             x0, [SP, #-8]!
    // 0x6dfa8c: r0 = markNeedsLayout()
    //     0x6dfa8c: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6dfa90: add             SP, SP, #8
    // 0x6dfa94: r0 = Null
    //     0x6dfa94: mov             x0, NULL
    // 0x6dfa98: LeaveFrame
    //     0x6dfa98: mov             SP, fp
    //     0x6dfa9c: ldp             fp, lr, [SP], #0x10
    // 0x6dfaa0: ret
    //     0x6dfaa0: ret             
    // 0x6dfaa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6dfaa4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6dfaa8: b               #0x6dfa60
  }
  set _ showCursor=(/* No info */) {
    // ** addr: 0x6dfaac, size: 0x124
    // 0x6dfaac: EnterFrame
    //     0x6dfaac: stp             fp, lr, [SP, #-0x10]!
    //     0x6dfab0: mov             fp, SP
    // 0x6dfab4: AllocStack(0x8)
    //     0x6dfab4: sub             SP, SP, #8
    // 0x6dfab8: CheckStackOverflow
    //     0x6dfab8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6dfabc: cmp             SP, x16
    //     0x6dfac0: b.ls            #0x6dfbc8
    // 0x6dfac4: ldr             x0, [fp, #0x18]
    // 0x6dfac8: LoadField: r1 = r0->field_f7
    //     0x6dfac8: ldur            w1, [x0, #0xf7]
    // 0x6dfacc: DecompressPointer r1
    //     0x6dfacc: add             x1, x1, HEAP, lsl #32
    // 0x6dfad0: ldr             x2, [fp, #0x10]
    // 0x6dfad4: stur            x1, [fp, #-8]
    // 0x6dfad8: cmp             w1, w2
    // 0x6dfadc: b.ne            #0x6dfaf0
    // 0x6dfae0: r0 = Null
    //     0x6dfae0: mov             x0, NULL
    // 0x6dfae4: LeaveFrame
    //     0x6dfae4: mov             SP, fp
    //     0x6dfae8: ldp             fp, lr, [SP], #0x10
    // 0x6dfaec: ret
    //     0x6dfaec: ret             
    // 0x6dfaf0: LoadField: r3 = r0->field_f
    //     0x6dfaf0: ldur            w3, [x0, #0xf]
    // 0x6dfaf4: DecompressPointer r3
    //     0x6dfaf4: add             x3, x3, HEAP, lsl #32
    // 0x6dfaf8: cmp             w3, NULL
    // 0x6dfafc: b.eq            #0x6dfb34
    // 0x6dfb00: r1 = 1
    //     0x6dfb00: mov             x1, #1
    // 0x6dfb04: r0 = AllocateContext()
    //     0x6dfb04: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6dfb08: mov             x1, x0
    // 0x6dfb0c: ldr             x0, [fp, #0x18]
    // 0x6dfb10: StoreField: r1->field_f = r0
    //     0x6dfb10: stur            w0, [x1, #0xf]
    // 0x6dfb14: mov             x2, x1
    // 0x6dfb18: r1 = Function '_showHideCursor@483409610':.
    //     0x6dfb18: add             x1, PP, #0x55, lsl #12  ; [pp+0x55b50] AnonymousClosure: (0x6dfca8), in [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_showHideCursor (0x6dfbd0)
    //     0x6dfb1c: ldr             x1, [x1, #0xb50]
    // 0x6dfb20: r0 = AllocateClosure()
    //     0x6dfb20: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6dfb24: ldur            x16, [fp, #-8]
    // 0x6dfb28: stp             x0, x16, [SP, #-0x10]!
    // 0x6dfb2c: r0 = removeListener()
    //     0x6dfb2c: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x6dfb30: add             SP, SP, #0x10
    // 0x6dfb34: ldr             x1, [fp, #0x18]
    // 0x6dfb38: ldr             x0, [fp, #0x10]
    // 0x6dfb3c: StoreField: r1->field_f7 = r0
    //     0x6dfb3c: stur            w0, [x1, #0xf7]
    //     0x6dfb40: ldurb           w16, [x1, #-1]
    //     0x6dfb44: ldurb           w17, [x0, #-1]
    //     0x6dfb48: and             x16, x17, x16, lsr #2
    //     0x6dfb4c: tst             x16, HEAP, lsr #32
    //     0x6dfb50: b.eq            #0x6dfb58
    //     0x6dfb54: bl              #0xd6826c
    // 0x6dfb58: LoadField: r0 = r1->field_f
    //     0x6dfb58: ldur            w0, [x1, #0xf]
    // 0x6dfb5c: DecompressPointer r0
    //     0x6dfb5c: add             x0, x0, HEAP, lsl #32
    // 0x6dfb60: cmp             w0, NULL
    // 0x6dfb64: b.eq            #0x6dfbb8
    // 0x6dfb68: SaveReg r1
    //     0x6dfb68: str             x1, [SP, #-8]!
    // 0x6dfb6c: r0 = _showHideCursor()
    //     0x6dfb6c: bl              #0x6dfbd0  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_showHideCursor
    // 0x6dfb70: add             SP, SP, #8
    // 0x6dfb74: ldr             x0, [fp, #0x18]
    // 0x6dfb78: LoadField: r1 = r0->field_f7
    //     0x6dfb78: ldur            w1, [x0, #0xf7]
    // 0x6dfb7c: DecompressPointer r1
    //     0x6dfb7c: add             x1, x1, HEAP, lsl #32
    // 0x6dfb80: stur            x1, [fp, #-8]
    // 0x6dfb84: r1 = 1
    //     0x6dfb84: mov             x1, #1
    // 0x6dfb88: r0 = AllocateContext()
    //     0x6dfb88: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6dfb8c: mov             x1, x0
    // 0x6dfb90: ldr             x0, [fp, #0x18]
    // 0x6dfb94: StoreField: r1->field_f = r0
    //     0x6dfb94: stur            w0, [x1, #0xf]
    // 0x6dfb98: mov             x2, x1
    // 0x6dfb9c: r1 = Function '_showHideCursor@483409610':.
    //     0x6dfb9c: add             x1, PP, #0x55, lsl #12  ; [pp+0x55b50] AnonymousClosure: (0x6dfca8), in [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_showHideCursor (0x6dfbd0)
    //     0x6dfba0: ldr             x1, [x1, #0xb50]
    // 0x6dfba4: r0 = AllocateClosure()
    //     0x6dfba4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6dfba8: ldur            x16, [fp, #-8]
    // 0x6dfbac: stp             x0, x16, [SP, #-0x10]!
    // 0x6dfbb0: r0 = addListener()
    //     0x6dfbb0: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x6dfbb4: add             SP, SP, #0x10
    // 0x6dfbb8: r0 = Null
    //     0x6dfbb8: mov             x0, NULL
    // 0x6dfbbc: LeaveFrame
    //     0x6dfbbc: mov             SP, fp
    //     0x6dfbc0: ldp             fp, lr, [SP], #0x10
    // 0x6dfbc4: ret
    //     0x6dfbc4: ret             
    // 0x6dfbc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6dfbc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6dfbcc: b               #0x6dfac4
  }
  _ _showHideCursor(/* No info */) {
    // ** addr: 0x6dfbd0, size: 0x74
    // 0x6dfbd0: EnterFrame
    //     0x6dfbd0: stp             fp, lr, [SP, #-0x10]!
    //     0x6dfbd4: mov             fp, SP
    // 0x6dfbd8: CheckStackOverflow
    //     0x6dfbd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6dfbdc: cmp             SP, x16
    //     0x6dfbe0: b.ls            #0x6dfc3c
    // 0x6dfbe4: ldr             x1, [fp, #0x10]
    // 0x6dfbe8: LoadField: r0 = r1->field_ab
    //     0x6dfbe8: ldur            w0, [x1, #0xab]
    // 0x6dfbec: DecompressPointer r0
    //     0x6dfbec: add             x0, x0, HEAP, lsl #32
    // 0x6dfbf0: r16 = Sentinel
    //     0x6dfbf0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6dfbf4: cmp             w0, w16
    // 0x6dfbf8: b.ne            #0x6dfc08
    // 0x6dfbfc: r2 = _caretPainter
    //     0x6dfbfc: add             x2, PP, #0x37, lsl #12  ; [pp+0x37348] Field <ExtendedRenderEditable._caretPainter@483409610>: late final (offset: 0xac)
    //     0x6dfc00: ldr             x2, [x2, #0x348]
    // 0x6dfc04: r0 = InitLateFinalInstanceField()
    //     0x6dfc04: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x6dfc08: mov             x1, x0
    // 0x6dfc0c: ldr             x0, [fp, #0x10]
    // 0x6dfc10: LoadField: r2 = r0->field_f7
    //     0x6dfc10: ldur            w2, [x0, #0xf7]
    // 0x6dfc14: DecompressPointer r2
    //     0x6dfc14: add             x2, x2, HEAP, lsl #32
    // 0x6dfc18: LoadField: r0 = r2->field_27
    //     0x6dfc18: ldur            w0, [x2, #0x27]
    // 0x6dfc1c: DecompressPointer r0
    //     0x6dfc1c: add             x0, x0, HEAP, lsl #32
    // 0x6dfc20: stp             x0, x1, [SP, #-0x10]!
    // 0x6dfc24: r0 = shouldPaint=()
    //     0x6dfc24: bl              #0x6dfc44  ; [package:extended_text_field/src/extended_render_editable.dart] _FloatingCursorPainter::shouldPaint=
    // 0x6dfc28: add             SP, SP, #0x10
    // 0x6dfc2c: r0 = Null
    //     0x6dfc2c: mov             x0, NULL
    // 0x6dfc30: LeaveFrame
    //     0x6dfc30: mov             SP, fp
    //     0x6dfc34: ldp             fp, lr, [SP], #0x10
    // 0x6dfc38: ret
    //     0x6dfc38: ret             
    // 0x6dfc3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6dfc3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6dfc40: b               #0x6dfbe4
  }
  [closure] void _showHideCursor(dynamic) {
    // ** addr: 0x6dfca8, size: 0x48
    // 0x6dfca8: EnterFrame
    //     0x6dfca8: stp             fp, lr, [SP, #-0x10]!
    //     0x6dfcac: mov             fp, SP
    // 0x6dfcb0: ldr             x0, [fp, #0x10]
    // 0x6dfcb4: LoadField: r1 = r0->field_17
    //     0x6dfcb4: ldur            w1, [x0, #0x17]
    // 0x6dfcb8: DecompressPointer r1
    //     0x6dfcb8: add             x1, x1, HEAP, lsl #32
    // 0x6dfcbc: CheckStackOverflow
    //     0x6dfcbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6dfcc0: cmp             SP, x16
    //     0x6dfcc4: b.ls            #0x6dfce8
    // 0x6dfcc8: LoadField: r0 = r1->field_f
    //     0x6dfcc8: ldur            w0, [x1, #0xf]
    // 0x6dfccc: DecompressPointer r0
    //     0x6dfccc: add             x0, x0, HEAP, lsl #32
    // 0x6dfcd0: SaveReg r0
    //     0x6dfcd0: str             x0, [SP, #-8]!
    // 0x6dfcd4: r0 = _showHideCursor()
    //     0x6dfcd4: bl              #0x6dfbd0  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_showHideCursor
    // 0x6dfcd8: add             SP, SP, #8
    // 0x6dfcdc: LeaveFrame
    //     0x6dfcdc: mov             SP, fp
    //     0x6dfce0: ldp             fp, lr, [SP], #0x10
    // 0x6dfce4: ret
    //     0x6dfce4: ret             
    // 0x6dfce8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6dfce8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6dfcec: b               #0x6dfcc8
  }
  set _ endHandleLayerLink=(/* No info */) {
    // ** addr: 0x6dfcf0, size: 0x88
    // 0x6dfcf0: EnterFrame
    //     0x6dfcf0: stp             fp, lr, [SP, #-0x10]!
    //     0x6dfcf4: mov             fp, SP
    // 0x6dfcf8: CheckStackOverflow
    //     0x6dfcf8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6dfcfc: cmp             SP, x16
    //     0x6dfd00: b.ls            #0x6dfd70
    // 0x6dfd04: ldr             x1, [fp, #0x18]
    // 0x6dfd08: r17 = 295
    //     0x6dfd08: mov             x17, #0x127
    // 0x6dfd0c: ldr             w0, [x1, x17]
    // 0x6dfd10: DecompressPointer r0
    //     0x6dfd10: add             x0, x0, HEAP, lsl #32
    // 0x6dfd14: ldr             x2, [fp, #0x10]
    // 0x6dfd18: cmp             w0, w2
    // 0x6dfd1c: b.ne            #0x6dfd30
    // 0x6dfd20: r0 = Null
    //     0x6dfd20: mov             x0, NULL
    // 0x6dfd24: LeaveFrame
    //     0x6dfd24: mov             SP, fp
    //     0x6dfd28: ldp             fp, lr, [SP], #0x10
    // 0x6dfd2c: ret
    //     0x6dfd2c: ret             
    // 0x6dfd30: mov             x0, x2
    // 0x6dfd34: r17 = 295
    //     0x6dfd34: mov             x17, #0x127
    // 0x6dfd38: str             w0, [x1, x17]
    // 0x6dfd3c: WriteBarrierInstr(obj = r1, val = r0)
    //     0x6dfd3c: ldurb           w16, [x1, #-1]
    //     0x6dfd40: ldurb           w17, [x0, #-1]
    //     0x6dfd44: and             x16, x17, x16, lsr #2
    //     0x6dfd48: tst             x16, HEAP, lsr #32
    //     0x6dfd4c: b.eq            #0x6dfd54
    //     0x6dfd50: bl              #0xd6826c
    // 0x6dfd54: SaveReg r1
    //     0x6dfd54: str             x1, [SP, #-8]!
    // 0x6dfd58: r0 = markNeedsPaint()
    //     0x6dfd58: bl              #0x6bef94  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::markNeedsPaint
    // 0x6dfd5c: add             SP, SP, #8
    // 0x6dfd60: r0 = Null
    //     0x6dfd60: mov             x0, NULL
    // 0x6dfd64: LeaveFrame
    //     0x6dfd64: mov             SP, fp
    //     0x6dfd68: ldp             fp, lr, [SP], #0x10
    // 0x6dfd6c: ret
    //     0x6dfd6c: ret             
    // 0x6dfd70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6dfd70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6dfd74: b               #0x6dfd04
  }
  set _ startHandleLayerLink=(/* No info */) {
    // ** addr: 0x6dfd78, size: 0x88
    // 0x6dfd78: EnterFrame
    //     0x6dfd78: stp             fp, lr, [SP, #-0x10]!
    //     0x6dfd7c: mov             fp, SP
    // 0x6dfd80: CheckStackOverflow
    //     0x6dfd80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6dfd84: cmp             SP, x16
    //     0x6dfd88: b.ls            #0x6dfdf8
    // 0x6dfd8c: ldr             x1, [fp, #0x18]
    // 0x6dfd90: r17 = 291
    //     0x6dfd90: mov             x17, #0x123
    // 0x6dfd94: ldr             w0, [x1, x17]
    // 0x6dfd98: DecompressPointer r0
    //     0x6dfd98: add             x0, x0, HEAP, lsl #32
    // 0x6dfd9c: ldr             x2, [fp, #0x10]
    // 0x6dfda0: cmp             w0, w2
    // 0x6dfda4: b.ne            #0x6dfdb8
    // 0x6dfda8: r0 = Null
    //     0x6dfda8: mov             x0, NULL
    // 0x6dfdac: LeaveFrame
    //     0x6dfdac: mov             SP, fp
    //     0x6dfdb0: ldp             fp, lr, [SP], #0x10
    // 0x6dfdb4: ret
    //     0x6dfdb4: ret             
    // 0x6dfdb8: mov             x0, x2
    // 0x6dfdbc: r17 = 291
    //     0x6dfdbc: mov             x17, #0x123
    // 0x6dfdc0: str             w0, [x1, x17]
    // 0x6dfdc4: WriteBarrierInstr(obj = r1, val = r0)
    //     0x6dfdc4: ldurb           w16, [x1, #-1]
    //     0x6dfdc8: ldurb           w17, [x0, #-1]
    //     0x6dfdcc: and             x16, x17, x16, lsr #2
    //     0x6dfdd0: tst             x16, HEAP, lsr #32
    //     0x6dfdd4: b.eq            #0x6dfddc
    //     0x6dfdd8: bl              #0xd6826c
    // 0x6dfddc: SaveReg r1
    //     0x6dfddc: str             x1, [SP, #-8]!
    // 0x6dfde0: r0 = markNeedsPaint()
    //     0x6dfde0: bl              #0x6bef94  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::markNeedsPaint
    // 0x6dfde4: add             SP, SP, #8
    // 0x6dfde8: r0 = Null
    //     0x6dfde8: mov             x0, NULL
    // 0x6dfdec: LeaveFrame
    //     0x6dfdec: mov             SP, fp
    //     0x6dfdf0: ldp             fp, lr, [SP], #0x10
    // 0x6dfdf4: ret
    //     0x6dfdf4: ret             
    // 0x6dfdf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6dfdf8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6dfdfc: b               #0x6dfd8c
  }
  set _ text=(/* No info */) {
    // ** addr: 0x6dfefc, size: 0xd8
    // 0x6dfefc: EnterFrame
    //     0x6dfefc: stp             fp, lr, [SP, #-0x10]!
    //     0x6dff00: mov             fp, SP
    // 0x6dff04: AllocStack(0x8)
    //     0x6dff04: sub             SP, SP, #8
    // 0x6dff08: CheckStackOverflow
    //     0x6dff08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6dff0c: cmp             SP, x16
    //     0x6dff10: b.ls            #0x6dffcc
    // 0x6dff14: ldr             x1, [fp, #0x18]
    // 0x6dff18: LoadField: r2 = r1->field_eb
    //     0x6dff18: ldur            w2, [x1, #0xeb]
    // 0x6dff1c: DecompressPointer r2
    //     0x6dff1c: add             x2, x2, HEAP, lsl #32
    // 0x6dff20: stur            x2, [fp, #-8]
    // 0x6dff24: LoadField: r0 = r2->field_f
    //     0x6dff24: ldur            w0, [x2, #0xf]
    // 0x6dff28: DecompressPointer r0
    //     0x6dff28: add             x0, x0, HEAP, lsl #32
    // 0x6dff2c: r3 = LoadClassIdInstr(r0)
    //     0x6dff2c: ldur            x3, [x0, #-1]
    //     0x6dff30: ubfx            x3, x3, #0xc, #0x14
    // 0x6dff34: ldr             x16, [fp, #0x10]
    // 0x6dff38: stp             x16, x0, [SP, #-0x10]!
    // 0x6dff3c: mov             x0, x3
    // 0x6dff40: mov             lr, x0
    // 0x6dff44: ldr             lr, [x21, lr, lsl #3]
    // 0x6dff48: blr             lr
    // 0x6dff4c: add             SP, SP, #0x10
    // 0x6dff50: tbnz            w0, #4, #0x6dff64
    // 0x6dff54: r0 = Null
    //     0x6dff54: mov             x0, NULL
    // 0x6dff58: LeaveFrame
    //     0x6dff58: mov             SP, fp
    //     0x6dff5c: ldp             fp, lr, [SP], #0x10
    // 0x6dff60: ret
    //     0x6dff60: ret             
    // 0x6dff64: ldr             x0, [fp, #0x18]
    // 0x6dff68: ldur            x16, [fp, #-8]
    // 0x6dff6c: ldr             lr, [fp, #0x10]
    // 0x6dff70: stp             lr, x16, [SP, #-0x10]!
    // 0x6dff74: r0 = text=()
    //     0x6dff74: bl              #0x673330  ; [package:flutter/src/painting/text_painter.dart] TextPainter::text=
    // 0x6dff78: add             SP, SP, #0x10
    // 0x6dff7c: ldr             x0, [fp, #0x18]
    // 0x6dff80: StoreField: r0->field_e7 = rNULL
    //     0x6dff80: stur            NULL, [x0, #0xe7]
    // 0x6dff84: StoreField: r0->field_ef = rNULL
    //     0x6dff84: stur            NULL, [x0, #0xef]
    // 0x6dff88: StoreField: r0->field_f3 = rNULL
    //     0x6dff88: stur            NULL, [x0, #0xf3]
    // 0x6dff8c: ldr             x16, [fp, #0x10]
    // 0x6dff90: stp             x16, x0, [SP, #-0x10]!
    // 0x6dff94: r0 = extractPlaceholderSpans()
    //     0x6dff94: bl              #0x6dffd4  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::extractPlaceholderSpans
    // 0x6dff98: add             SP, SP, #0x10
    // 0x6dff9c: ldr             x16, [fp, #0x18]
    // 0x6dffa0: SaveReg r16
    //     0x6dffa0: str             x16, [SP, #-8]!
    // 0x6dffa4: r0 = markNeedsTextLayout()
    //     0x6dffa4: bl              #0x6dee5c  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::markNeedsTextLayout
    // 0x6dffa8: add             SP, SP, #8
    // 0x6dffac: ldr             x16, [fp, #0x18]
    // 0x6dffb0: SaveReg r16
    //     0x6dffb0: str             x16, [SP, #-8]!
    // 0x6dffb4: r0 = markNeedsSemanticsUpdate()
    //     0x6dffb4: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6dffb8: add             SP, SP, #8
    // 0x6dffbc: r0 = Null
    //     0x6dffbc: mov             x0, NULL
    // 0x6dffc0: LeaveFrame
    //     0x6dffc0: mov             SP, fp
    //     0x6dffc4: ldp             fp, lr, [SP], #0x10
    // 0x6dffc8: ret
    //     0x6dffc8: ret             
    // 0x6dffcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6dffcc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6dffd0: b               #0x6dff14
  }
  _FloatingCursorPainter _caretPainter(ExtendedRenderEditable) {
    // ** addr: 0x6e01b8, size: 0x78
    // 0x6e01b8: EnterFrame
    //     0x6e01b8: stp             fp, lr, [SP, #-0x10]!
    //     0x6e01bc: mov             fp, SP
    // 0x6e01c0: AllocStack(0x10)
    //     0x6e01c0: sub             SP, SP, #0x10
    // 0x6e01c4: CheckStackOverflow
    //     0x6e01c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e01c8: cmp             SP, x16
    //     0x6e01cc: b.ls            #0x6e0228
    // 0x6e01d0: ldr             x0, [fp, #0x10]
    // 0x6e01d4: r1 = 59
    //     0x6e01d4: mov             x1, #0x3b
    // 0x6e01d8: branchIfSmi(r0, 0x6e01e4)
    //     0x6e01d8: tbz             w0, #0, #0x6e01e4
    // 0x6e01dc: r1 = LoadClassIdInstr(r0)
    //     0x6e01dc: ldur            x1, [x0, #-1]
    //     0x6e01e0: ubfx            x1, x1, #0xc, #0x14
    // 0x6e01e4: SaveReg r0
    //     0x6e01e4: str             x0, [SP, #-8]!
    // 0x6e01e8: mov             x0, x1
    // 0x6e01ec: r0 = GDT[cid_x0 + -0xffb]()
    //     0x6e01ec: sub             lr, x0, #0xffb
    //     0x6e01f0: ldr             lr, [x21, lr, lsl #3]
    //     0x6e01f4: blr             lr
    // 0x6e01f8: add             SP, SP, #8
    // 0x6e01fc: stur            x0, [fp, #-8]
    // 0x6e0200: r0 = _FloatingCursorPainter()
    //     0x6e0200: bl              #0x6e0230  ; Allocate_FloatingCursorPainterStub -> _FloatingCursorPainter (size=0x4c)
    // 0x6e0204: stur            x0, [fp, #-0x10]
    // 0x6e0208: ldur            x16, [fp, #-8]
    // 0x6e020c: stp             x16, x0, [SP, #-0x10]!
    // 0x6e0210: r0 = _FloatingCursorPainter()
    //     0x6e0210: bl              #0x65323c  ; [package:extended_text_field/src/extended_render_editable.dart] _FloatingCursorPainter::_FloatingCursorPainter
    // 0x6e0214: add             SP, SP, #0x10
    // 0x6e0218: ldur            x0, [fp, #-0x10]
    // 0x6e021c: LeaveFrame
    //     0x6e021c: mov             SP, fp
    //     0x6e0220: ldp             fp, lr, [SP], #0x10
    // 0x6e0224: ret
    //     0x6e0224: ret             
    // 0x6e0228: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e0228: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e022c: b               #0x6e01d0
  }
  _ ExtendedRenderEditable(/* No info */) {
    // ** addr: 0x6f3090, size: 0x55c
    // 0x6f3090: EnterFrame
    //     0x6f3090: stp             fp, lr, [SP, #-0x10]!
    //     0x6f3094: mov             fp, SP
    // 0x6f3098: AllocStack(0x20)
    //     0x6f3098: sub             SP, SP, #0x20
    // 0x6f309c: r3 = Sentinel
    //     0x6f309c: ldr             x3, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6f30a0: r2 = false
    //     0x6f30a0: add             x2, NULL, #0x30  ; false
    // 0x6f30a4: r1 = 0.000000
    //     0x6f30a4: ldr             x1, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x6f30a8: r0 = Instance_Offset
    //     0x6f30a8: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x6f30ac: CheckStackOverflow
    //     0x6f30ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f30b0: cmp             SP, x16
    //     0x6f30b4: b.ls            #0x6f35e4
    // 0x6f30b8: ldr             x4, [fp, #0xd8]
    // 0x6f30bc: StoreField: r4->field_ab = r3
    //     0x6f30bc: stur            w3, [x4, #0xab]
    // 0x6f30c0: add             x16, x4, #0x12f
    // 0x6f30c4: str             w2, [x16]
    // 0x6f30c8: add             x16, x4, #0x133
    // 0x6f30cc: str             w3, [x16]
    // 0x6f30d0: add             x16, x4, #0x13b
    // 0x6f30d4: str             w1, [x16]
    // 0x6f30d8: add             x16, x4, #0x14b
    // 0x6f30dc: str             w3, [x16]
    // 0x6f30e0: add             x16, x4, #0x14f
    // 0x6f30e4: str             w3, [x16]
    // 0x6f30e8: add             x16, x4, #0x153
    // 0x6f30ec: str             w3, [x16]
    // 0x6f30f0: add             x16, x4, #0x157
    // 0x6f30f4: str             w0, [x16]
    // 0x6f30f8: add             x16, x4, #0x15f
    // 0x6f30fc: str             w2, [x16]
    // 0x6f3100: add             x16, x4, #0x163
    // 0x6f3104: str             w2, [x16]
    // 0x6f3108: add             x16, x4, #0x167
    // 0x6f310c: str             w2, [x16]
    // 0x6f3110: add             x16, x4, #0x16b
    // 0x6f3114: str             w2, [x16]
    // 0x6f3118: r0 = TextHighlightPainter()
    //     0x6f3118: bl              #0x6f36cc  ; AllocateTextHighlightPainterStub -> TextHighlightPainter (size=0x38)
    // 0x6f311c: stur            x0, [fp, #-8]
    // 0x6f3120: SaveReg r0
    //     0x6f3120: str             x0, [SP, #-8]!
    // 0x6f3124: r0 = TextHighlightPainter()
    //     0x6f3124: bl              #0x6f35ec  ; [package:extended_text_library/src/selection/painter.dart] TextHighlightPainter::TextHighlightPainter
    // 0x6f3128: add             SP, SP, #8
    // 0x6f312c: ldur            x0, [fp, #-8]
    // 0x6f3130: ldr             x1, [fp, #0xd8]
    // 0x6f3134: StoreField: r1->field_af = r0
    //     0x6f3134: stur            w0, [x1, #0xaf]
    //     0x6f3138: ldurb           w16, [x1, #-1]
    //     0x6f313c: ldurb           w17, [x0, #-1]
    //     0x6f3140: and             x16, x17, x16, lsr #2
    //     0x6f3144: tst             x16, HEAP, lsr #32
    //     0x6f3148: b.eq            #0x6f3150
    //     0x6f314c: bl              #0xd6826c
    // 0x6f3150: r0 = TextHighlightPainter()
    //     0x6f3150: bl              #0x6f36cc  ; AllocateTextHighlightPainterStub -> TextHighlightPainter (size=0x38)
    // 0x6f3154: stur            x0, [fp, #-0x10]
    // 0x6f3158: SaveReg r0
    //     0x6f3158: str             x0, [SP, #-8]!
    // 0x6f315c: r0 = TextHighlightPainter()
    //     0x6f315c: bl              #0x6f35ec  ; [package:extended_text_library/src/selection/painter.dart] TextHighlightPainter::TextHighlightPainter
    // 0x6f3160: add             SP, SP, #8
    // 0x6f3164: ldur            x0, [fp, #-0x10]
    // 0x6f3168: ldr             x2, [fp, #0xd8]
    // 0x6f316c: StoreField: r2->field_b3 = r0
    //     0x6f316c: stur            w0, [x2, #0xb3]
    //     0x6f3170: ldurb           w16, [x2, #-1]
    //     0x6f3174: ldurb           w17, [x0, #-1]
    //     0x6f3178: and             x16, x17, x16, lsr #2
    //     0x6f317c: tst             x16, HEAP, lsr #32
    //     0x6f3180: b.eq            #0x6f3188
    //     0x6f3184: bl              #0xd6828c
    // 0x6f3188: r1 = <bool>
    //     0x6f3188: ldr             x1, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0x6f318c: r0 = ValueNotifier()
    //     0x6f318c: bl              #0x515204  ; AllocateValueNotifierStub -> ValueNotifier<X0> (size=0x2c)
    // 0x6f3190: mov             x1, x0
    // 0x6f3194: r0 = true
    //     0x6f3194: add             x0, NULL, #0x20  ; true
    // 0x6f3198: stur            x1, [fp, #-0x18]
    // 0x6f319c: StoreField: r1->field_27 = r0
    //     0x6f319c: stur            w0, [x1, #0x27]
    // 0x6f31a0: r2 = 0
    //     0x6f31a0: mov             x2, #0
    // 0x6f31a4: StoreField: r1->field_7 = r2
    //     0x6f31a4: stur            x2, [x1, #7]
    // 0x6f31a8: StoreField: r1->field_13 = r2
    //     0x6f31a8: stur            x2, [x1, #0x13]
    // 0x6f31ac: StoreField: r1->field_1b = r2
    //     0x6f31ac: stur            x2, [x1, #0x1b]
    // 0x6f31b0: r0 = InitLateStaticField(0xac0) // [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_emptyListeners
    //     0x6f31b0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6f31b4: ldr             x0, [x0, #0x1580]
    //     0x6f31b8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6f31bc: cmp             w0, w16
    //     0x6f31c0: b.ne            #0x6f31cc
    //     0x6f31c4: ldr             x2, [PP, #0x44a0]  ; [pp+0x44a0] Field <ChangeNotifier._emptyListeners@171329750>: static late final (offset: 0xac0)
    //     0x6f31c8: bl              #0xd67cdc
    // 0x6f31cc: mov             x2, x0
    // 0x6f31d0: ldur            x0, [fp, #-0x18]
    // 0x6f31d4: stur            x2, [fp, #-0x20]
    // 0x6f31d8: StoreField: r0->field_f = r2
    //     0x6f31d8: stur            w2, [x0, #0xf]
    // 0x6f31dc: ldr             x3, [fp, #0xd8]
    // 0x6f31e0: StoreField: r3->field_df = r0
    //     0x6f31e0: stur            w0, [x3, #0xdf]
    //     0x6f31e4: ldurb           w16, [x3, #-1]
    //     0x6f31e8: ldurb           w17, [x0, #-1]
    //     0x6f31ec: and             x16, x17, x16, lsr #2
    //     0x6f31f0: tst             x16, HEAP, lsr #32
    //     0x6f31f4: b.eq            #0x6f31fc
    //     0x6f31f8: bl              #0xd682ac
    // 0x6f31fc: r1 = <bool>
    //     0x6f31fc: ldr             x1, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0x6f3200: r0 = ValueNotifier()
    //     0x6f3200: bl              #0x515204  ; AllocateValueNotifierStub -> ValueNotifier<X0> (size=0x2c)
    // 0x6f3204: r2 = true
    //     0x6f3204: add             x2, NULL, #0x20  ; true
    // 0x6f3208: StoreField: r0->field_27 = r2
    //     0x6f3208: stur            w2, [x0, #0x27]
    // 0x6f320c: r3 = 0
    //     0x6f320c: mov             x3, #0
    // 0x6f3210: StoreField: r0->field_7 = r3
    //     0x6f3210: stur            x3, [x0, #7]
    // 0x6f3214: StoreField: r0->field_13 = r3
    //     0x6f3214: stur            x3, [x0, #0x13]
    // 0x6f3218: StoreField: r0->field_1b = r3
    //     0x6f3218: stur            x3, [x0, #0x1b]
    // 0x6f321c: ldur            x1, [fp, #-0x20]
    // 0x6f3220: StoreField: r0->field_f = r1
    //     0x6f3220: stur            w1, [x0, #0xf]
    // 0x6f3224: ldr             x4, [fp, #0xd8]
    // 0x6f3228: StoreField: r4->field_e3 = r0
    //     0x6f3228: stur            w0, [x4, #0xe3]
    //     0x6f322c: ldurb           w16, [x4, #-1]
    //     0x6f3230: ldurb           w17, [x0, #-1]
    //     0x6f3234: and             x16, x17, x16, lsr #2
    //     0x6f3238: tst             x16, HEAP, lsr #32
    //     0x6f323c: b.eq            #0x6f3244
    //     0x6f3240: bl              #0xd682cc
    // 0x6f3244: r1 = <ClipRectLayer>
    //     0x6f3244: add             x1, PP, #0x15, lsl #12  ; [pp+0x15388] TypeArguments: <ClipRectLayer>
    //     0x6f3248: ldr             x1, [x1, #0x388]
    // 0x6f324c: r0 = LayerHandle()
    //     0x6f324c: bl              #0x5bbf28  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x6f3250: ldr             x1, [fp, #0xd8]
    // 0x6f3254: r17 = 375
    //     0x6f3254: mov             x17, #0x177
    // 0x6f3258: str             w0, [x1, x17]
    // 0x6f325c: WriteBarrierInstr(obj = r1, val = r0)
    //     0x6f325c: ldurb           w16, [x1, #-1]
    //     0x6f3260: ldurb           w17, [x0, #-1]
    //     0x6f3264: and             x16, x17, x16, lsr #2
    //     0x6f3268: tst             x16, HEAP, lsr #32
    //     0x6f326c: b.eq            #0x6f3274
    //     0x6f3270: bl              #0xd6826c
    // 0x6f3274: ldr             x0, [fp, #0x80]
    // 0x6f3278: StoreField: r1->field_c3 = r0
    //     0x6f3278: stur            w0, [x1, #0xc3]
    //     0x6f327c: ldurb           w16, [x1, #-1]
    //     0x6f3280: ldurb           w17, [x0, #-1]
    //     0x6f3284: and             x16, x17, x16, lsr #2
    //     0x6f3288: tst             x16, HEAP, lsr #32
    //     0x6f328c: b.eq            #0x6f3294
    //     0x6f3290: bl              #0xd6826c
    // 0x6f3294: r2 = true
    //     0x6f3294: add             x2, NULL, #0x20  ; true
    // 0x6f3298: StoreField: r1->field_c7 = r2
    //     0x6f3298: stur            w2, [x1, #0xc7]
    // 0x6f329c: r0 = Instance_EdgeInsets
    //     0x6f329c: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f998] Obj!EdgeInsets@b35b41
    //     0x6f32a0: ldr             x0, [x0, #0x998]
    // 0x6f32a4: add             x16, x1, #0x12b
    // 0x6f32a8: str             w0, [x16]
    // 0x6f32ac: ldr             x0, [fp, #0x10]
    // 0x6f32b0: StoreField: r1->field_db = r0
    //     0x6f32b0: stur            w0, [x1, #0xdb]
    //     0x6f32b4: ldurb           w16, [x1, #-1]
    //     0x6f32b8: ldurb           w17, [x0, #-1]
    //     0x6f32bc: and             x16, x17, x16, lsr #2
    //     0x6f32c0: tst             x16, HEAP, lsr #32
    //     0x6f32c4: b.eq            #0x6f32cc
    //     0x6f32c8: bl              #0xd6826c
    // 0x6f32cc: ldr             x0, [fp, #0x30]
    // 0x6f32d0: StoreField: r1->field_97 = r0
    //     0x6f32d0: stur            w0, [x1, #0x97]
    // 0x6f32d4: r0 = TextPainter()
    //     0x6f32d4: bl              #0x68dbc4  ; AllocateTextPainterStub -> TextPainter (size=0x68)
    // 0x6f32d8: r1 = true
    //     0x6f32d8: add             x1, NULL, #0x20  ; true
    // 0x6f32dc: StoreField: r0->field_b = r1
    //     0x6f32dc: stur            w1, [x0, #0xb]
    // 0x6f32e0: r2 = Sentinel
    //     0x6f32e0: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6f32e4: StoreField: r0->field_57 = r2
    //     0x6f32e4: stur            w2, [x0, #0x57]
    // 0x6f32e8: ldr             x3, [fp, #0x28]
    // 0x6f32ec: StoreField: r0->field_f = r3
    //     0x6f32ec: stur            w3, [x0, #0xf]
    // 0x6f32f0: r4 = Instance_TextAlign
    //     0x6f32f0: add             x4, PP, #0x14, lsl #12  ; [pp+0x14fe8] Obj!TextAlign@b66f71
    //     0x6f32f4: ldr             x4, [x4, #0xfe8]
    // 0x6f32f8: StoreField: r0->field_17 = r4
    //     0x6f32f8: stur            w4, [x0, #0x17]
    // 0x6f32fc: ldr             x4, [fp, #0x20]
    // 0x6f3300: StoreField: r0->field_1b = r4
    //     0x6f3300: stur            w4, [x0, #0x1b]
    // 0x6f3304: ldr             d0, [fp, #0x18]
    // 0x6f3308: StoreField: r0->field_1f = d0
    //     0x6f3308: stur            d0, [x0, #0x1f]
    // 0x6f330c: ldr             x4, [fp, #0x98]
    // 0x6f3310: StoreField: r0->field_2b = r4
    //     0x6f3310: stur            w4, [x0, #0x2b]
    // 0x6f3314: ldr             x4, [fp, #0x38]
    // 0x6f3318: StoreField: r0->field_33 = r4
    //     0x6f3318: stur            w4, [x0, #0x33]
    // 0x6f331c: r4 = Instance_TextWidthBasis
    //     0x6f331c: add             x4, PP, #0x15, lsl #12  ; [pp+0x15148] Obj!TextWidthBasis@b64d31
    //     0x6f3320: ldr             x4, [x4, #0x148]
    // 0x6f3324: StoreField: r0->field_37 = r4
    //     0x6f3324: stur            w4, [x0, #0x37]
    // 0x6f3328: ldr             x4, [fp, #0xd8]
    // 0x6f332c: StoreField: r4->field_eb = r0
    //     0x6f332c: stur            w0, [x4, #0xeb]
    //     0x6f3330: ldurb           w16, [x4, #-1]
    //     0x6f3334: ldurb           w17, [x0, #-1]
    //     0x6f3338: and             x16, x17, x16, lsr #2
    //     0x6f333c: tst             x16, HEAP, lsr #32
    //     0x6f3340: b.eq            #0x6f3348
    //     0x6f3344: bl              #0xd682cc
    // 0x6f3348: ldr             x0, [fp, #0x48]
    // 0x6f334c: StoreField: r4->field_f7 = r0
    //     0x6f334c: stur            w0, [x4, #0xf7]
    //     0x6f3350: ldurb           w16, [x4, #-1]
    //     0x6f3354: ldurb           w17, [x0, #-1]
    //     0x6f3358: and             x16, x17, x16, lsr #2
    //     0x6f335c: tst             x16, HEAP, lsr #32
    //     0x6f3360: b.eq            #0x6f3368
    //     0x6f3364: bl              #0xd682cc
    // 0x6f3368: ldr             x0, [fp, #0x90]
    // 0x6f336c: add             x16, x4, #0x103
    // 0x6f3370: str             w0, [x16]
    // 0x6f3374: r5 = false
    //     0x6f3374: add             x5, NULL, #0x30  ; false
    // 0x6f3378: add             x16, x4, #0x10b
    // 0x6f337c: str             w5, [x16]
    // 0x6f3380: ldr             x0, [fp, #0x58]
    // 0x6f3384: r17 = 271
    //     0x6f3384: mov             x17, #0x10f
    // 0x6f3388: str             w0, [x4, x17]
    // 0x6f338c: WriteBarrierInstr(obj = r4, val = r0)
    //     0x6f338c: ldurb           w16, [x4, #-1]
    //     0x6f3390: ldurb           w17, [x0, #-1]
    //     0x6f3394: and             x16, x17, x16, lsr #2
    //     0x6f3398: tst             x16, HEAP, lsr #32
    //     0x6f339c: b.eq            #0x6f33a4
    //     0x6f33a0: bl              #0xd682cc
    // 0x6f33a4: ldr             x0, [fp, #0x88]
    // 0x6f33a8: r17 = 275
    //     0x6f33a8: mov             x17, #0x113
    // 0x6f33ac: str             w0, [x4, x17]
    // 0x6f33b0: WriteBarrierInstr(obj = r4, val = r0)
    //     0x6f33b0: ldurb           w16, [x4, #-1]
    //     0x6f33b4: ldurb           w17, [x0, #-1]
    //     0x6f33b8: and             x16, x17, x16, lsr #2
    //     0x6f33bc: tst             x16, HEAP, lsr #32
    //     0x6f33c0: b.eq            #0x6f33c8
    //     0x6f33c4: bl              #0xd682cc
    // 0x6f33c8: r0 = 2.000000
    //     0x6f33c8: add             x0, PP, #0x25, lsl #12  ; [pp+0x259a8] 2
    //     0x6f33cc: ldr             x0, [x0, #0x9a8]
    // 0x6f33d0: add             x16, x4, #0x117
    // 0x6f33d4: str             w0, [x16]
    // 0x6f33d8: ldr             x0, [fp, #0x78]
    // 0x6f33dc: add             x16, x4, #0x11f
    // 0x6f33e0: str             w0, [x16]
    // 0x6f33e4: ldr             x0, [fp, #0xb0]
    // 0x6f33e8: add             x16, x4, #0x137
    // 0x6f33ec: str             w0, [x16]
    // 0x6f33f0: ldr             x0, [fp, #0xb8]
    // 0x6f33f4: LoadField: d0 = r0->field_7
    //     0x6f33f4: ldur            d0, [x0, #7]
    // 0x6f33f8: StoreField: r4->field_cb = d0
    //     0x6f33f8: stur            d0, [x4, #0xcb]
    // 0x6f33fc: ldr             x0, [fp, #0x40]
    // 0x6f3400: r17 = 291
    //     0x6f3400: mov             x17, #0x123
    // 0x6f3404: str             w0, [x4, x17]
    // 0x6f3408: WriteBarrierInstr(obj = r4, val = r0)
    //     0x6f3408: ldurb           w16, [x4, #-1]
    //     0x6f340c: ldurb           w17, [x0, #-1]
    //     0x6f3410: and             x16, x17, x16, lsr #2
    //     0x6f3414: tst             x16, HEAP, lsr #32
    //     0x6f3418: b.eq            #0x6f3420
    //     0x6f341c: bl              #0xd682cc
    // 0x6f3420: ldr             x0, [fp, #0xa8]
    // 0x6f3424: r17 = 295
    //     0x6f3424: mov             x17, #0x127
    // 0x6f3428: str             w0, [x4, x17]
    // 0x6f342c: WriteBarrierInstr(obj = r4, val = r0)
    //     0x6f342c: ldurb           w16, [x4, #-1]
    //     0x6f3430: ldurb           w17, [x0, #-1]
    //     0x6f3434: and             x16, x17, x16, lsr #2
    //     0x6f3438: tst             x16, HEAP, lsr #32
    //     0x6f343c: b.eq            #0x6f3444
    //     0x6f3440: bl              #0xd682cc
    // 0x6f3444: r0 = "•"
    //     0x6f3444: add             x0, PP, #0x1f, lsl #12  ; [pp+0x1f278] "•"
    //     0x6f3448: ldr             x0, [x0, #0x278]
    // 0x6f344c: StoreField: r4->field_d3 = r0
    //     0x6f344c: stur            w0, [x4, #0xd3]
    // 0x6f3450: StoreField: r4->field_d7 = r5
    //     0x6f3450: stur            w5, [x4, #0xd7]
    // 0x6f3454: ldr             x0, [fp, #0x60]
    // 0x6f3458: StoreField: r4->field_ff = r0
    //     0x6f3458: stur            w0, [x4, #0xff]
    // 0x6f345c: StoreField: r4->field_fb = r1
    //     0x6f345c: stur            w1, [x4, #0xfb]
    // 0x6f3460: r0 = Instance_Clip
    //     0x6f3460: add             x0, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x6f3464: ldr             x0, [x0, #0x678]
    // 0x6f3468: add             x16, x4, #0x13f
    // 0x6f346c: str             w0, [x16]
    // 0x6f3470: StoreField: r4->field_83 = r2
    //     0x6f3470: stur            w2, [x4, #0x83]
    // 0x6f3474: StoreField: r4->field_87 = r2
    //     0x6f3474: stur            w2, [x4, #0x87]
    // 0x6f3478: StoreField: r4->field_93 = r5
    //     0x6f3478: stur            w5, [x4, #0x93]
    // 0x6f347c: StoreField: r4->field_77 = r5
    //     0x6f347c: stur            w5, [x4, #0x77]
    // 0x6f3480: StoreField: r4->field_7b = r2
    //     0x6f3480: stur            w2, [x4, #0x7b]
    // 0x6f3484: r0 = 0
    //     0x6f3484: mov             x0, #0
    // 0x6f3488: StoreField: r4->field_5f = r0
    //     0x6f3488: stur            x0, [x4, #0x5f]
    // 0x6f348c: SaveReg r4
    //     0x6f348c: str             x4, [SP, #-8]!
    // 0x6f3490: r0 = RenderObject()
    //     0x6f3490: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6f3494: add             SP, SP, #8
    // 0x6f3498: ldr             x1, [fp, #0xd8]
    // 0x6f349c: LoadField: r0 = r1->field_93
    //     0x6f349c: ldur            w0, [x1, #0x93]
    // 0x6f34a0: DecompressPointer r0
    //     0x6f34a0: add             x0, x0, HEAP, lsl #32
    // 0x6f34a4: ldr             x2, [fp, #0xa0]
    // 0x6f34a8: cmp             w0, w2
    // 0x6f34ac: b.eq            #0x6f34c4
    // 0x6f34b0: StoreField: r1->field_93 = r2
    //     0x6f34b0: stur            w2, [x1, #0x93]
    // 0x6f34b4: SaveReg r1
    //     0x6f34b4: str             x1, [SP, #-8]!
    // 0x6f34b8: r0 = markNeedsSemanticsUpdate()
    //     0x6f34b8: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6f34bc: add             SP, SP, #8
    // 0x6f34c0: ldr             x1, [fp, #0xd8]
    // 0x6f34c4: ldur            x16, [fp, #-8]
    // 0x6f34c8: ldr             lr, [fp, #0x50]
    // 0x6f34cc: stp             lr, x16, [SP, #-0x10]!
    // 0x6f34d0: r0 = highlightColor=()
    //     0x6f34d0: bl              #0x6de5f4  ; [package:extended_text_library/src/selection/painter.dart] TextHighlightPainter::highlightColor=
    // 0x6f34d4: add             SP, SP, #0x10
    // 0x6f34d8: ldur            x16, [fp, #-8]
    // 0x6f34dc: ldr             lr, [fp, #0x58]
    // 0x6f34e0: stp             lr, x16, [SP, #-0x10]!
    // 0x6f34e4: r0 = highlightedRange=()
    //     0x6f34e4: bl              #0x6de3cc  ; [package:extended_text_library/src/selection/painter.dart] TextHighlightPainter::highlightedRange=
    // 0x6f34e8: add             SP, SP, #0x10
    // 0x6f34ec: ldur            x16, [fp, #-0x10]
    // 0x6f34f0: ldr             lr, [fp, #0x70]
    // 0x6f34f4: stp             lr, x16, [SP, #-0x10]!
    // 0x6f34f8: r0 = highlightColor=()
    //     0x6f34f8: bl              #0x6de5f4  ; [package:extended_text_library/src/selection/painter.dart] TextHighlightPainter::highlightColor=
    // 0x6f34fc: add             SP, SP, #0x10
    // 0x6f3500: ldur            x16, [fp, #-0x10]
    // 0x6f3504: ldr             lr, [fp, #0x68]
    // 0x6f3508: stp             lr, x16, [SP, #-0x10]!
    // 0x6f350c: r0 = highlightedRange=()
    //     0x6f350c: bl              #0x6de3cc  ; [package:extended_text_library/src/selection/painter.dart] TextHighlightPainter::highlightedRange=
    // 0x6f3510: add             SP, SP, #0x10
    // 0x6f3514: ldr             x1, [fp, #0xd8]
    // 0x6f3518: LoadField: r0 = r1->field_ab
    //     0x6f3518: ldur            w0, [x1, #0xab]
    // 0x6f351c: DecompressPointer r0
    //     0x6f351c: add             x0, x0, HEAP, lsl #32
    // 0x6f3520: r16 = Sentinel
    //     0x6f3520: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6f3524: cmp             w0, w16
    // 0x6f3528: b.ne            #0x6f3538
    // 0x6f352c: r2 = _caretPainter
    //     0x6f352c: add             x2, PP, #0x37, lsl #12  ; [pp+0x37348] Field <ExtendedRenderEditable._caretPainter@483409610>: late final (offset: 0xac)
    //     0x6f3530: ldr             x2, [x2, #0x348]
    // 0x6f3534: r0 = InitLateFinalInstanceField()
    //     0x6f3534: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x6f3538: ldr             x16, [fp, #0xd0]
    // 0x6f353c: stp             x16, x0, [SP, #-0x10]!
    // 0x6f3540: r0 = caretColor=()
    //     0x6f3540: bl              #0x6dfe00  ; [package:extended_text_field/src/extended_render_editable.dart] _FloatingCursorPainter::caretColor=
    // 0x6f3544: add             SP, SP, #0x10
    // 0x6f3548: ldr             x0, [fp, #0xd8]
    // 0x6f354c: LoadField: r1 = r0->field_ab
    //     0x6f354c: ldur            w1, [x0, #0xab]
    // 0x6f3550: DecompressPointer r1
    //     0x6f3550: add             x1, x1, HEAP, lsl #32
    // 0x6f3554: ldr             x16, [fp, #0xc0]
    // 0x6f3558: stp             x16, x1, [SP, #-0x10]!
    // 0x6f355c: r0 = cursorRadius=()
    //     0x6f355c: bl              #0x6df084  ; [package:extended_text_field/src/extended_render_editable.dart] _FloatingCursorPainter::cursorRadius=
    // 0x6f3560: add             SP, SP, #0x10
    // 0x6f3564: ldr             x0, [fp, #0xd8]
    // 0x6f3568: LoadField: r1 = r0->field_ab
    //     0x6f3568: ldur            w1, [x0, #0xab]
    // 0x6f356c: DecompressPointer r1
    //     0x6f356c: add             x1, x1, HEAP, lsl #32
    // 0x6f3570: ldr             x16, [fp, #0xc8]
    // 0x6f3574: stp             x16, x1, [SP, #-0x10]!
    // 0x6f3578: r0 = cursorOffset=()
    //     0x6f3578: bl              #0x6def98  ; [package:extended_text_field/src/extended_render_editable.dart] _FloatingCursorPainter::cursorOffset=
    // 0x6f357c: add             SP, SP, #0x10
    // 0x6f3580: ldr             x0, [fp, #0xd8]
    // 0x6f3584: LoadField: r1 = r0->field_ab
    //     0x6f3584: ldur            w1, [x0, #0xab]
    // 0x6f3588: DecompressPointer r1
    //     0x6f3588: add             x1, x1, HEAP, lsl #32
    // 0x6f358c: r16 = Instance_CupertinoDynamicColor
    //     0x6f358c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28dc8] Obj!CupertinoDynamicColor@b5e4f1
    //     0x6f3590: ldr             x16, [x16, #0xdc8]
    // 0x6f3594: stp             x16, x1, [SP, #-0x10]!
    // 0x6f3598: r0 = backgroundCursorColor=()
    //     0x6f3598: bl              #0x6e3d14  ; [package:extended_text_field/src/extended_render_editable.dart] _FloatingCursorPainter::backgroundCursorColor=
    // 0x6f359c: add             SP, SP, #0x10
    // 0x6f35a0: ldr             x16, [fp, #0xd8]
    // 0x6f35a4: SaveReg r16
    //     0x6f35a4: str             x16, [SP, #-8]!
    // 0x6f35a8: r0 = _updateForegroundPainter()
    //     0x6f35a8: bl              #0x6deb44  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_updateForegroundPainter
    // 0x6f35ac: add             SP, SP, #8
    // 0x6f35b0: ldr             x16, [fp, #0xd8]
    // 0x6f35b4: SaveReg r16
    //     0x6f35b4: str             x16, [SP, #-8]!
    // 0x6f35b8: r0 = _updatePainter()
    //     0x6f35b8: bl              #0x6de718  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_updatePainter
    // 0x6f35bc: add             SP, SP, #8
    // 0x6f35c0: ldr             x16, [fp, #0xd8]
    // 0x6f35c4: ldr             lr, [fp, #0x28]
    // 0x6f35c8: stp             lr, x16, [SP, #-0x10]!
    // 0x6f35cc: r0 = extractPlaceholderSpans()
    //     0x6f35cc: bl              #0x6dffd4  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::extractPlaceholderSpans
    // 0x6f35d0: add             SP, SP, #0x10
    // 0x6f35d4: r0 = Null
    //     0x6f35d4: mov             x0, NULL
    // 0x6f35d8: LeaveFrame
    //     0x6f35d8: mov             SP, fp
    //     0x6f35dc: ldp             fp, lr, [SP], #0x10
    // 0x6f35e0: ret
    //     0x6f35e0: ret             
    // 0x6f35e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f35e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f35e8: b               #0x6f30b8
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0x7159a8, size: 0x8c
    // 0x7159a8: EnterFrame
    //     0x7159a8: stp             fp, lr, [SP, #-0x10]!
    //     0x7159ac: mov             fp, SP
    // 0x7159b0: ldr             x0, [fp, #0x10]
    // 0x7159b4: r2 = Null
    //     0x7159b4: mov             x2, NULL
    // 0x7159b8: r1 = Null
    //     0x7159b8: mov             x1, NULL
    // 0x7159bc: r4 = 59
    //     0x7159bc: mov             x4, #0x3b
    // 0x7159c0: branchIfSmi(r0, 0x7159cc)
    //     0x7159c0: tbz             w0, #0, #0x7159cc
    // 0x7159c4: r4 = LoadClassIdInstr(r0)
    //     0x7159c4: ldur            x4, [x0, #-1]
    //     0x7159c8: ubfx            x4, x4, #0xc, #0x14
    // 0x7159cc: cmp             x4, #0x8f0
    // 0x7159d0: b.eq            #0x7159e8
    // 0x7159d4: r8 = BoxHitTestEntry<RenderBox>
    //     0x7159d4: add             x8, PP, #0xb, lsl #12  ; [pp+0xb198] Type: BoxHitTestEntry<RenderBox>
    //     0x7159d8: ldr             x8, [x8, #0x198]
    // 0x7159dc: r3 = Null
    //     0x7159dc: add             x3, PP, #0x56, lsl #12  ; [pp+0x56840] Null
    //     0x7159e0: ldr             x3, [x3, #0x840]
    // 0x7159e4: r0 = DefaultTypeTest()
    //     0x7159e4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x7159e8: ldr             x0, [fp, #0x18]
    // 0x7159ec: r2 = Null
    //     0x7159ec: mov             x2, NULL
    // 0x7159f0: r1 = Null
    //     0x7159f0: mov             x1, NULL
    // 0x7159f4: cmp             w0, NULL
    // 0x7159f8: b.eq            #0x715a18
    // 0x7159fc: branchIfSmi(r0, 0x715a18)
    //     0x7159fc: tbz             w0, #0, #0x715a18
    // 0x715a00: r3 = LoadClassIdInstr(r0)
    //     0x715a00: ldur            x3, [x0, #-1]
    //     0x715a04: ubfx            x3, x3, #0xc, #0x14
    // 0x715a08: cmp             x3, #0x90a
    // 0x715a0c: b.eq            #0x715a20
    // 0x715a10: cmp             x3, #0xb41
    // 0x715a14: b.eq            #0x715a20
    // 0x715a18: r0 = false
    //     0x715a18: add             x0, NULL, #0x30  ; false
    // 0x715a1c: b               #0x715a24
    // 0x715a20: r0 = true
    //     0x715a20: add             x0, NULL, #0x20  ; true
    // 0x715a24: r0 = Null
    //     0x715a24: mov             x0, NULL
    // 0x715a28: LeaveFrame
    //     0x715a28: mov             SP, fp
    //     0x715a2c: ldp             fp, lr, [SP], #0x10
    // 0x715a30: ret
    //     0x715a30: ret             
  }
  _ redepthChildren(/* No info */) {
    // ** addr: 0x792980, size: 0x88
    // 0x792980: EnterFrame
    //     0x792980: stp             fp, lr, [SP, #-0x10]!
    //     0x792984: mov             fp, SP
    // 0x792988: AllocStack(0x8)
    //     0x792988: sub             SP, SP, #8
    // 0x79298c: CheckStackOverflow
    //     0x79298c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x792990: cmp             SP, x16
    //     0x792994: b.ls            #0x792a00
    // 0x792998: ldr             x0, [fp, #0x10]
    // 0x79299c: LoadField: r1 = r0->field_9b
    //     0x79299c: ldur            w1, [x0, #0x9b]
    // 0x7929a0: DecompressPointer r1
    //     0x7929a0: add             x1, x1, HEAP, lsl #32
    // 0x7929a4: LoadField: r2 = r0->field_9f
    //     0x7929a4: ldur            w2, [x0, #0x9f]
    // 0x7929a8: DecompressPointer r2
    //     0x7929a8: add             x2, x2, HEAP, lsl #32
    // 0x7929ac: stur            x2, [fp, #-8]
    // 0x7929b0: cmp             w1, NULL
    // 0x7929b4: b.eq            #0x7929c4
    // 0x7929b8: stp             x1, x0, [SP, #-0x10]!
    // 0x7929bc: r0 = redepthChild()
    //     0x7929bc: bl              #0x5e631c  ; [package:flutter/src/foundation/node.dart] AbstractNode::redepthChild
    // 0x7929c0: add             SP, SP, #0x10
    // 0x7929c4: ldur            x0, [fp, #-8]
    // 0x7929c8: cmp             w0, NULL
    // 0x7929cc: b.eq            #0x7929e0
    // 0x7929d0: ldr             x16, [fp, #0x10]
    // 0x7929d4: stp             x0, x16, [SP, #-0x10]!
    // 0x7929d8: r0 = redepthChild()
    //     0x7929d8: bl              #0x5e631c  ; [package:flutter/src/foundation/node.dart] AbstractNode::redepthChild
    // 0x7929dc: add             SP, SP, #0x10
    // 0x7929e0: ldr             x16, [fp, #0x10]
    // 0x7929e4: SaveReg r16
    //     0x7929e4: str             x16, [SP, #-8]!
    // 0x7929e8: r0 = redepthChildren()
    //     0x7929e8: bl              #0x792a08  ; [package:flutter/src/rendering/paragraph.dart] _RenderParagraph&RenderBox&ContainerRenderObjectMixin::redepthChildren
    // 0x7929ec: add             SP, SP, #8
    // 0x7929f0: r0 = Null
    //     0x7929f0: mov             x0, NULL
    // 0x7929f4: LeaveFrame
    //     0x7929f4: mov             SP, fp
    //     0x7929f8: ldp             fp, lr, [SP], #0x10
    // 0x7929fc: ret
    //     0x7929fc: ret             
    // 0x792a00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x792a00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x792a04: b               #0x792998
  }
  _ getLocalRectForCaret(/* No info */) {
    // ** addr: 0x7a3e00, size: 0x18c
    // 0x7a3e00: EnterFrame
    //     0x7a3e00: stp             fp, lr, [SP, #-0x10]!
    //     0x7a3e04: mov             fp, SP
    // 0x7a3e08: AllocStack(0x20)
    //     0x7a3e08: sub             SP, SP, #0x20
    // 0x7a3e0c: CheckStackOverflow
    //     0x7a3e0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a3e10: cmp             SP, x16
    //     0x7a3e14: b.ls            #0x7a3f78
    // 0x7a3e18: ldr             x16, [fp, #0x18]
    // 0x7a3e1c: SaveReg r16
    //     0x7a3e1c: str             x16, [SP, #-8]!
    // 0x7a3e20: r0 = computeTextMetricsIfNeeded()
    //     0x7a3e20: bl              #0x522fec  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::computeTextMetricsIfNeeded
    // 0x7a3e24: add             SP, SP, #8
    // 0x7a3e28: ldr             x1, [fp, #0x18]
    // 0x7a3e2c: r17 = 339
    //     0x7a3e2c: mov             x17, #0x153
    // 0x7a3e30: ldr             w0, [x1, x17]
    // 0x7a3e34: DecompressPointer r0
    //     0x7a3e34: add             x0, x0, HEAP, lsl #32
    // 0x7a3e38: r16 = Sentinel
    //     0x7a3e38: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7a3e3c: cmp             w0, w16
    // 0x7a3e40: b.eq            #0x7a3f80
    // 0x7a3e44: ldr             x16, [fp, #0x10]
    // 0x7a3e48: stp             x16, x1, [SP, #-0x10]!
    // 0x7a3e4c: SaveReg r0
    //     0x7a3e4c: str             x0, [SP, #-8]!
    // 0x7a3e50: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x7a3e50: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x7a3e54: r0 = getCaretOffset()
    //     0x7a3e54: bl              #0x5202b0  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::getCaretOffset
    // 0x7a3e58: add             SP, SP, #0x18
    // 0x7a3e5c: ldr             x1, [fp, #0x18]
    // 0x7a3e60: stur            x0, [fp, #-0x10]
    // 0x7a3e64: r17 = 279
    //     0x7a3e64: mov             x17, #0x117
    // 0x7a3e68: ldr             w2, [x1, x17]
    // 0x7a3e6c: DecompressPointer r2
    //     0x7a3e6c: add             x2, x2, HEAP, lsl #32
    // 0x7a3e70: stur            x2, [fp, #-8]
    // 0x7a3e74: LoadField: r3 = r1->field_eb
    //     0x7a3e74: ldur            w3, [x1, #0xeb]
    // 0x7a3e78: DecompressPointer r3
    //     0x7a3e78: add             x3, x3, HEAP, lsl #32
    // 0x7a3e7c: SaveReg r3
    //     0x7a3e7c: str             x3, [SP, #-8]!
    // 0x7a3e80: r0 = preferredLineHeight()
    //     0x7a3e80: bl              #0x51a438  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0x7a3e84: add             SP, SP, #8
    // 0x7a3e88: ldur            x0, [fp, #-8]
    // 0x7a3e8c: LoadField: d1 = r0->field_7
    //     0x7a3e8c: ldur            d1, [x0, #7]
    // 0x7a3e90: d2 = 0.000000
    //     0x7a3e90: eor             v2.16b, v2.16b, v2.16b
    // 0x7a3e94: fadd            d3, d2, d1
    // 0x7a3e98: stur            d3, [fp, #-0x20]
    // 0x7a3e9c: fadd            d1, d2, d0
    // 0x7a3ea0: stur            d1, [fp, #-0x18]
    // 0x7a3ea4: r0 = Rect()
    //     0x7a3ea4: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x7a3ea8: d0 = 0.000000
    //     0x7a3ea8: eor             v0.16b, v0.16b, v0.16b
    // 0x7a3eac: stur            x0, [fp, #-8]
    // 0x7a3eb0: StoreField: r0->field_7 = d0
    //     0x7a3eb0: stur            d0, [x0, #7]
    // 0x7a3eb4: StoreField: r0->field_f = d0
    //     0x7a3eb4: stur            d0, [x0, #0xf]
    // 0x7a3eb8: ldur            d0, [fp, #-0x20]
    // 0x7a3ebc: StoreField: r0->field_17 = d0
    //     0x7a3ebc: stur            d0, [x0, #0x17]
    // 0x7a3ec0: ldur            d0, [fp, #-0x18]
    // 0x7a3ec4: StoreField: r0->field_1f = d0
    //     0x7a3ec4: stur            d0, [x0, #0x1f]
    // 0x7a3ec8: ldr             x16, [fp, #0x18]
    // 0x7a3ecc: SaveReg r16
    //     0x7a3ecc: str             x16, [SP, #-8]!
    // 0x7a3ed0: r0 = paintOffset()
    //     0x7a3ed0: bl              #0x522e98  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::paintOffset
    // 0x7a3ed4: add             SP, SP, #8
    // 0x7a3ed8: ldur            x16, [fp, #-0x10]
    // 0x7a3edc: stp             x0, x16, [SP, #-0x10]!
    // 0x7a3ee0: r0 = +()
    //     0x7a3ee0: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x7a3ee4: add             SP, SP, #0x10
    // 0x7a3ee8: ldur            x16, [fp, #-8]
    // 0x7a3eec: stp             x0, x16, [SP, #-0x10]!
    // 0x7a3ef0: r0 = shift()
    //     0x7a3ef0: bl              #0x51a0bc  ; [dart:ui] Rect::shift
    // 0x7a3ef4: add             SP, SP, #0x10
    // 0x7a3ef8: stur            x0, [fp, #-8]
    // 0x7a3efc: ldr             x16, [fp, #0x18]
    // 0x7a3f00: SaveReg r16
    //     0x7a3f00: str             x16, [SP, #-8]!
    // 0x7a3f04: r0 = cursorOffset()
    //     0x7a3f04: bl              #0x7a4168  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::cursorOffset
    // 0x7a3f08: add             SP, SP, #8
    // 0x7a3f0c: ldr             x1, [fp, #0x18]
    // 0x7a3f10: LoadField: r0 = r1->field_ab
    //     0x7a3f10: ldur            w0, [x1, #0xab]
    // 0x7a3f14: DecompressPointer r0
    //     0x7a3f14: add             x0, x0, HEAP, lsl #32
    // 0x7a3f18: r16 = Sentinel
    //     0x7a3f18: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7a3f1c: cmp             w0, w16
    // 0x7a3f20: b.ne            #0x7a3f30
    // 0x7a3f24: r2 = _caretPainter
    //     0x7a3f24: add             x2, PP, #0x37, lsl #12  ; [pp+0x37348] Field <ExtendedRenderEditable._caretPainter@483409610>: late final (offset: 0xac)
    //     0x7a3f28: ldr             x2, [x2, #0x348]
    // 0x7a3f2c: r0 = InitLateFinalInstanceField()
    //     0x7a3f2c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x7a3f30: LoadField: r1 = r0->field_3f
    //     0x7a3f30: ldur            w1, [x0, #0x3f]
    // 0x7a3f34: DecompressPointer r1
    //     0x7a3f34: add             x1, x1, HEAP, lsl #32
    // 0x7a3f38: ldur            x16, [fp, #-8]
    // 0x7a3f3c: stp             x1, x16, [SP, #-0x10]!
    // 0x7a3f40: r0 = shift()
    //     0x7a3f40: bl              #0x51a0bc  ; [dart:ui] Rect::shift
    // 0x7a3f44: add             SP, SP, #0x10
    // 0x7a3f48: stur            x0, [fp, #-8]
    // 0x7a3f4c: ldr             x16, [fp, #0x18]
    // 0x7a3f50: stp             x0, x16, [SP, #-0x10]!
    // 0x7a3f54: r0 = _getPixelPerfectCursorOffset()
    //     0x7a3f54: bl              #0x7a3f8c  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_getPixelPerfectCursorOffset
    // 0x7a3f58: add             SP, SP, #0x10
    // 0x7a3f5c: ldur            x16, [fp, #-8]
    // 0x7a3f60: stp             x0, x16, [SP, #-0x10]!
    // 0x7a3f64: r0 = shift()
    //     0x7a3f64: bl              #0x51a0bc  ; [dart:ui] Rect::shift
    // 0x7a3f68: add             SP, SP, #0x10
    // 0x7a3f6c: LeaveFrame
    //     0x7a3f6c: mov             SP, fp
    //     0x7a3f70: ldp             fp, lr, [SP], #0x10
    // 0x7a3f74: ret
    //     0x7a3f74: ret             
    // 0x7a3f78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a3f78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a3f7c: b               #0x7a3e18
    // 0x7a3f80: r9 = _caretPrototype
    //     0x7a3f80: add             x9, PP, #0x37, lsl #12  ; [pp+0x37350] Field <ExtendedRenderEditable._caretPrototype@483409610>: late (offset: 0x154)
    //     0x7a3f84: ldr             x9, [x9, #0x350]
    // 0x7a3f88: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7a3f88: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _getPixelPerfectCursorOffset(/* No info */) {
    // ** addr: 0x7a3f8c, size: 0x1dc
    // 0x7a3f8c: EnterFrame
    //     0x7a3f8c: stp             fp, lr, [SP, #-0x10]!
    //     0x7a3f90: mov             fp, SP
    // 0x7a3f94: AllocStack(0x30)
    //     0x7a3f94: sub             SP, SP, #0x30
    // 0x7a3f98: CheckStackOverflow
    //     0x7a3f98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a3f9c: cmp             SP, x16
    //     0x7a3fa0: b.ls            #0x7a4128
    // 0x7a3fa4: ldr             x0, [fp, #0x10]
    // 0x7a3fa8: LoadField: d0 = r0->field_7
    //     0x7a3fa8: ldur            d0, [x0, #7]
    // 0x7a3fac: stur            d0, [fp, #-0x20]
    // 0x7a3fb0: LoadField: d1 = r0->field_f
    //     0x7a3fb0: ldur            d1, [x0, #0xf]
    // 0x7a3fb4: stur            d1, [fp, #-0x18]
    // 0x7a3fb8: r0 = Offset()
    //     0x7a3fb8: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x7a3fbc: ldur            d0, [fp, #-0x20]
    // 0x7a3fc0: StoreField: r0->field_7 = d0
    //     0x7a3fc0: stur            d0, [x0, #7]
    // 0x7a3fc4: ldur            d0, [fp, #-0x18]
    // 0x7a3fc8: StoreField: r0->field_f = d0
    //     0x7a3fc8: stur            d0, [x0, #0xf]
    // 0x7a3fcc: ldr             x16, [fp, #0x18]
    // 0x7a3fd0: stp             x0, x16, [SP, #-0x10]!
    // 0x7a3fd4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x7a3fd4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x7a3fd8: r0 = localToGlobal()
    //     0x7a3fd8: bl              #0x64e820  ; [package:flutter/src/rendering/box.dart] RenderBox::localToGlobal
    // 0x7a3fdc: add             SP, SP, #0x10
    // 0x7a3fe0: mov             x1, x0
    // 0x7a3fe4: ldr             x0, [fp, #0x18]
    // 0x7a3fe8: stur            x1, [fp, #-8]
    // 0x7a3fec: LoadField: d0 = r0->field_cb
    //     0x7a3fec: ldur            d0, [x0, #0xcb]
    // 0x7a3ff0: d1 = 1.000000
    //     0x7a3ff0: fmov            d1, #1.00000000
    // 0x7a3ff4: fdiv            d2, d1, d0
    // 0x7a3ff8: stur            d2, [fp, #-0x20]
    // 0x7a3ffc: LoadField: d1 = r1->field_7
    //     0x7a3ffc: ldur            d1, [x1, #7]
    // 0x7a4000: stur            d1, [fp, #-0x18]
    // 0x7a4004: fdiv            d0, d1, d2
    // 0x7a4008: stp             fp, lr, [SP, #-0x10]!
    // 0x7a400c: mov             fp, SP
    // 0x7a4010: CallRuntime_LibcRound(double) -> double
    //     0x7a4010: and             SP, SP, #0xfffffffffffffff0
    //     0x7a4014: mov             sp, SP
    //     0x7a4018: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0x7a401c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x7a4020: blr             x16
    //     0x7a4024: mov             x16, #8
    //     0x7a4028: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x7a402c: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x7a4030: sub             sp, x16, #1, lsl #12
    //     0x7a4034: mov             SP, fp
    //     0x7a4038: ldp             fp, lr, [SP], #0x10
    // 0x7a403c: fcmp            d0, d0
    // 0x7a4040: b.vs            #0x7a4130
    // 0x7a4044: fcvtzs          x0, d0
    // 0x7a4048: asr             x16, x0, #0x1e
    // 0x7a404c: cmp             x16, x0, asr #63
    // 0x7a4050: b.ne            #0x7a4130
    // 0x7a4054: lsl             x0, x0, #1
    // 0x7a4058: ldur            x1, [fp, #-8]
    // 0x7a405c: stur            x0, [fp, #-0x10]
    // 0x7a4060: LoadField: d1 = r1->field_f
    //     0x7a4060: ldur            d1, [x1, #0xf]
    // 0x7a4064: ldur            d2, [fp, #-0x20]
    // 0x7a4068: stur            d1, [fp, #-0x28]
    // 0x7a406c: fdiv            d0, d1, d2
    // 0x7a4070: stp             fp, lr, [SP, #-0x10]!
    // 0x7a4074: mov             fp, SP
    // 0x7a4078: CallRuntime_LibcRound(double) -> double
    //     0x7a4078: and             SP, SP, #0xfffffffffffffff0
    //     0x7a407c: mov             sp, SP
    //     0x7a4080: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0x7a4084: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x7a4088: blr             x16
    //     0x7a408c: mov             x16, #8
    //     0x7a4090: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x7a4094: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x7a4098: sub             sp, x16, #1, lsl #12
    //     0x7a409c: mov             SP, fp
    //     0x7a40a0: ldp             fp, lr, [SP], #0x10
    // 0x7a40a4: fcmp            d0, d0
    // 0x7a40a8: b.vs            #0x7a414c
    // 0x7a40ac: fcvtzs          x0, d0
    // 0x7a40b0: asr             x16, x0, #0x1e
    // 0x7a40b4: cmp             x16, x0, asr #63
    // 0x7a40b8: b.ne            #0x7a414c
    // 0x7a40bc: lsl             x0, x0, #1
    // 0x7a40c0: ldur            x1, [fp, #-0x10]
    // 0x7a40c4: r2 = LoadInt32Instr(r1)
    //     0x7a40c4: sbfx            x2, x1, #1, #0x1f
    //     0x7a40c8: tbz             w1, #0, #0x7a40d0
    //     0x7a40cc: ldur            x2, [x1, #7]
    // 0x7a40d0: scvtf           d0, x2
    // 0x7a40d4: ldur            d1, [fp, #-0x20]
    // 0x7a40d8: fmul            d2, d0, d1
    // 0x7a40dc: ldur            d0, [fp, #-0x18]
    // 0x7a40e0: fsub            d3, d2, d0
    // 0x7a40e4: stur            d3, [fp, #-0x30]
    // 0x7a40e8: r1 = LoadInt32Instr(r0)
    //     0x7a40e8: sbfx            x1, x0, #1, #0x1f
    //     0x7a40ec: tbz             w0, #0, #0x7a40f4
    //     0x7a40f0: ldur            x1, [x0, #7]
    // 0x7a40f4: scvtf           d0, x1
    // 0x7a40f8: fmul            d2, d0, d1
    // 0x7a40fc: ldur            d0, [fp, #-0x28]
    // 0x7a4100: fsub            d1, d2, d0
    // 0x7a4104: stur            d1, [fp, #-0x18]
    // 0x7a4108: r0 = Offset()
    //     0x7a4108: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x7a410c: ldur            d0, [fp, #-0x30]
    // 0x7a4110: StoreField: r0->field_7 = d0
    //     0x7a4110: stur            d0, [x0, #7]
    // 0x7a4114: ldur            d0, [fp, #-0x18]
    // 0x7a4118: StoreField: r0->field_f = d0
    //     0x7a4118: stur            d0, [x0, #0xf]
    // 0x7a411c: LeaveFrame
    //     0x7a411c: mov             SP, fp
    //     0x7a4120: ldp             fp, lr, [SP], #0x10
    // 0x7a4124: ret
    //     0x7a4124: ret             
    // 0x7a4128: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a4128: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a412c: b               #0x7a3fa4
    // 0x7a4130: SaveReg d0
    //     0x7a4130: str             q0, [SP, #-0x10]!
    // 0x7a4134: r0 = 218
    //     0x7a4134: mov             x0, #0xda
    // 0x7a4138: r24 = DoubleToIntegerStub
    //     0x7a4138: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x7a413c: LoadField: r30 = r24->field_7
    //     0x7a413c: ldur            lr, [x24, #7]
    // 0x7a4140: blr             lr
    // 0x7a4144: RestoreReg d0
    //     0x7a4144: ldr             q0, [SP], #0x10
    // 0x7a4148: b               #0x7a4058
    // 0x7a414c: SaveReg d0
    //     0x7a414c: str             q0, [SP, #-0x10]!
    // 0x7a4150: r0 = 218
    //     0x7a4150: mov             x0, #0xda
    // 0x7a4154: r24 = DoubleToIntegerStub
    //     0x7a4154: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x7a4158: LoadField: r30 = r24->field_7
    //     0x7a4158: ldur            lr, [x24, #7]
    // 0x7a415c: blr             lr
    // 0x7a4160: RestoreReg d0
    //     0x7a4160: ldr             q0, [SP], #0x10
    // 0x7a4164: b               #0x7a40c0
  }
  get _ cursorOffset(/* No info */) {
    // ** addr: 0x7a4168, size: 0x58
    // 0x7a4168: EnterFrame
    //     0x7a4168: stp             fp, lr, [SP, #-0x10]!
    //     0x7a416c: mov             fp, SP
    // 0x7a4170: CheckStackOverflow
    //     0x7a4170: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a4174: cmp             SP, x16
    //     0x7a4178: b.ls            #0x7a41b8
    // 0x7a417c: ldr             x1, [fp, #0x10]
    // 0x7a4180: LoadField: r0 = r1->field_ab
    //     0x7a4180: ldur            w0, [x1, #0xab]
    // 0x7a4184: DecompressPointer r0
    //     0x7a4184: add             x0, x0, HEAP, lsl #32
    // 0x7a4188: r16 = Sentinel
    //     0x7a4188: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7a418c: cmp             w0, w16
    // 0x7a4190: b.ne            #0x7a41a0
    // 0x7a4194: r2 = _caretPainter
    //     0x7a4194: add             x2, PP, #0x37, lsl #12  ; [pp+0x37348] Field <ExtendedRenderEditable._caretPainter@483409610>: late final (offset: 0xac)
    //     0x7a4198: ldr             x2, [x2, #0x348]
    // 0x7a419c: r0 = InitLateFinalInstanceField()
    //     0x7a419c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x7a41a0: LoadField: r1 = r0->field_3f
    //     0x7a41a0: ldur            w1, [x0, #0x3f]
    // 0x7a41a4: DecompressPointer r1
    //     0x7a41a4: add             x1, x1, HEAP, lsl #32
    // 0x7a41a8: mov             x0, x1
    // 0x7a41ac: LeaveFrame
    //     0x7a41ac: mov             SP, fp
    //     0x7a41b0: ldp             fp, lr, [SP], #0x10
    // 0x7a41b4: ret
    //     0x7a41b4: ret             
    // 0x7a41b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a41b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a41bc: b               #0x7a417c
  }
  get _ text(/* No info */) {
    // ** addr: 0x7a9ce4, size: 0x18
    // 0x7a9ce4: ldr             x1, [SP]
    // 0x7a9ce8: LoadField: r2 = r1->field_eb
    //     0x7a9ce8: ldur            w2, [x1, #0xeb]
    // 0x7a9cec: DecompressPointer r2
    //     0x7a9cec: add             x2, x2, HEAP, lsl #32
    // 0x7a9cf0: LoadField: r0 = r2->field_f
    //     0x7a9cf0: ldur            w0, [x2, #0xf]
    // 0x7a9cf4: DecompressPointer r0
    //     0x7a9cf4: add             x0, x0, HEAP, lsl #32
    // 0x7a9cf8: ret
    //     0x7a9cf8: ret             
  }
  _ getPositionForPoint(/* No info */) {
    // ** addr: 0x7aba98, size: 0xa4
    // 0x7aba98: EnterFrame
    //     0x7aba98: stp             fp, lr, [SP, #-0x10]!
    //     0x7aba9c: mov             fp, SP
    // 0x7abaa0: AllocStack(0x8)
    //     0x7abaa0: sub             SP, SP, #8
    // 0x7abaa4: CheckStackOverflow
    //     0x7abaa4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7abaa8: cmp             SP, x16
    //     0x7abaac: b.ls            #0x7abb30
    // 0x7abab0: ldr             x16, [fp, #0x18]
    // 0x7abab4: SaveReg r16
    //     0x7abab4: str             x16, [SP, #-8]!
    // 0x7abab8: r0 = computeTextMetricsIfNeeded()
    //     0x7abab8: bl              #0x522fec  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::computeTextMetricsIfNeeded
    // 0x7ababc: add             SP, SP, #8
    // 0x7abac0: ldr             x16, [fp, #0x18]
    // 0x7abac4: SaveReg r16
    //     0x7abac4: str             x16, [SP, #-8]!
    // 0x7abac8: r0 = paintOffset()
    //     0x7abac8: bl              #0x522e98  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::paintOffset
    // 0x7abacc: add             SP, SP, #8
    // 0x7abad0: cmp             w0, NULL
    // 0x7abad4: b.eq            #0x7abb38
    // 0x7abad8: SaveReg r0
    //     0x7abad8: str             x0, [SP, #-8]!
    // 0x7abadc: r0 = unary-()
    //     0x7abadc: bl              #0x622a88  ; [dart:ui] Offset::unary-
    // 0x7abae0: add             SP, SP, #8
    // 0x7abae4: ldr             x16, [fp, #0x10]
    // 0x7abae8: stp             x0, x16, [SP, #-0x10]!
    // 0x7abaec: r0 = +()
    //     0x7abaec: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x7abaf0: add             SP, SP, #0x10
    // 0x7abaf4: mov             x1, x0
    // 0x7abaf8: ldr             x0, [fp, #0x18]
    // 0x7abafc: LoadField: r2 = r0->field_eb
    //     0x7abafc: ldur            w2, [x0, #0xeb]
    // 0x7abb00: DecompressPointer r2
    //     0x7abb00: add             x2, x2, HEAP, lsl #32
    // 0x7abb04: stur            x2, [fp, #-8]
    // 0x7abb08: stp             x1, x0, [SP, #-0x10]!
    // 0x7abb0c: r0 = globalToLocal()
    //     0x7abb0c: bl              #0x669450  ; [package:flutter/src/rendering/box.dart] RenderBox::globalToLocal
    // 0x7abb10: add             SP, SP, #0x10
    // 0x7abb14: ldur            x16, [fp, #-8]
    // 0x7abb18: stp             x0, x16, [SP, #-0x10]!
    // 0x7abb1c: r0 = getPositionForOffset()
    //     0x7abb1c: bl              #0x6246bc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getPositionForOffset
    // 0x7abb20: add             SP, SP, #0x10
    // 0x7abb24: LeaveFrame
    //     0x7abb24: mov             SP, fp
    //     0x7abb28: ldp             fp, lr, [SP], #0x10
    // 0x7abb2c: ret
    //     0x7abb2c: ret             
    // 0x7abb30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7abb30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7abb34: b               #0x7abab0
    // 0x7abb38: r0 = NullErrorSharedWithoutFPURegs()
    //     0x7abb38: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _getNextWord(/* No info */) {
    // ** addr: 0x83aeb4, size: 0x330
    // 0x83aeb4: EnterFrame
    //     0x83aeb4: stp             fp, lr, [SP, #-0x10]!
    //     0x83aeb8: mov             fp, SP
    // 0x83aebc: AllocStack(0x38)
    //     0x83aebc: sub             SP, SP, #0x38
    // 0x83aec0: CheckStackOverflow
    //     0x83aec0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83aec4: cmp             SP, x16
    //     0x83aec8: b.ls            #0x83b1c0
    // 0x83aecc: ldr             x0, [fp, #0x18]
    // 0x83aed0: LoadField: r1 = r0->field_eb
    //     0x83aed0: ldur            w1, [x0, #0xeb]
    // 0x83aed4: DecompressPointer r1
    //     0x83aed4: add             x1, x1, HEAP, lsl #32
    // 0x83aed8: ldr             x0, [fp, #0x10]
    // 0x83aedc: stur            x1, [fp, #-0x10]
    // 0x83aee0: stur            x0, [fp, #-8]
    // 0x83aee4: CheckStackOverflow
    //     0x83aee4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83aee8: cmp             SP, x16
    //     0x83aeec: b.ls            #0x83b1c8
    // 0x83aef0: r0 = TextPosition()
    //     0x83aef0: bl              #0x5223f0  ; AllocateTextPositionStub -> TextPosition (size=0x14)
    // 0x83aef4: mov             x1, x0
    // 0x83aef8: ldur            x0, [fp, #-8]
    // 0x83aefc: StoreField: r1->field_7 = r0
    //     0x83aefc: stur            x0, [x1, #7]
    // 0x83af00: r0 = Instance_TextAffinity
    //     0x83af00: ldr             x0, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x83af04: StoreField: r1->field_f = r0
    //     0x83af04: stur            w0, [x1, #0xf]
    // 0x83af08: ldur            x2, [fp, #-0x10]
    // 0x83af0c: LoadField: r3 = r2->field_7
    //     0x83af0c: ldur            w3, [x2, #7]
    // 0x83af10: DecompressPointer r3
    //     0x83af10: add             x3, x3, HEAP, lsl #32
    // 0x83af14: cmp             w3, NULL
    // 0x83af18: b.eq            #0x83b1d0
    // 0x83af1c: stp             x1, x3, [SP, #-0x10]!
    // 0x83af20: r0 = getWordBoundary()
    //     0x83af20: bl              #0x83b1e4  ; [dart:ui] Paragraph::getWordBoundary
    // 0x83af24: add             SP, SP, #0x10
    // 0x83af28: mov             x2, x0
    // 0x83af2c: stur            x2, [fp, #-0x30]
    // 0x83af30: LoadField: r0 = r2->field_7
    //     0x83af30: ldur            x0, [x2, #7]
    // 0x83af34: tbnz            x0, #0x3f, #0x83b1b0
    // 0x83af38: LoadField: r3 = r2->field_f
    //     0x83af38: ldur            x3, [x2, #0xf]
    // 0x83af3c: stur            x3, [fp, #-0x28]
    // 0x83af40: tbnz            x3, #0x3f, #0x83b1b0
    // 0x83af44: cmp             x0, x3
    // 0x83af48: b.eq            #0x83b1b0
    // 0x83af4c: mov             x5, x0
    // 0x83af50: ldur            x4, [fp, #-0x10]
    // 0x83af54: stur            x5, [fp, #-8]
    // 0x83af58: CheckStackOverflow
    //     0x83af58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83af5c: cmp             SP, x16
    //     0x83af60: b.ls            #0x83b1d4
    // 0x83af64: cmp             x5, x3
    // 0x83af68: b.ge            #0x83b1a4
    // 0x83af6c: LoadField: r6 = r4->field_f
    //     0x83af6c: ldur            w6, [x4, #0xf]
    // 0x83af70: DecompressPointer r6
    //     0x83af70: add             x6, x6, HEAP, lsl #32
    // 0x83af74: stur            x6, [fp, #-0x20]
    // 0x83af78: cmp             w6, NULL
    // 0x83af7c: b.eq            #0x83b1dc
    // 0x83af80: r0 = BoxInt64Instr(r5)
    //     0x83af80: sbfiz           x0, x5, #1, #0x1f
    //     0x83af84: cmp             x5, x0, asr #1
    //     0x83af88: b.eq            #0x83af94
    //     0x83af8c: bl              #0xd69bb8
    //     0x83af90: stur            x5, [x0, #7]
    // 0x83af94: stur            x0, [fp, #-0x18]
    // 0x83af98: r1 = 3
    //     0x83af98: mov             x1, #3
    // 0x83af9c: r0 = AllocateContext()
    //     0x83af9c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x83afa0: mov             x1, x0
    // 0x83afa4: ldur            x0, [fp, #-0x18]
    // 0x83afa8: stur            x1, [fp, #-0x38]
    // 0x83afac: StoreField: r1->field_f = r0
    //     0x83afac: stur            w0, [x1, #0xf]
    // 0x83afb0: ldur            x0, [fp, #-8]
    // 0x83afb4: tbz             x0, #0x3f, #0x83afc0
    // 0x83afb8: r1 = Null
    //     0x83afb8: mov             x1, NULL
    // 0x83afbc: b               #0x83b088
    // 0x83afc0: ldur            x2, [fp, #-0x20]
    // 0x83afc4: r0 = Accumulator()
    //     0x83afc4: bl              #0x522218  ; AllocateAccumulatorStub -> Accumulator (size=0x10)
    // 0x83afc8: mov             x1, x0
    // 0x83afcc: r0 = 0
    //     0x83afcc: mov             x0, #0
    // 0x83afd0: StoreField: r1->field_7 = r0
    //     0x83afd0: stur            x0, [x1, #7]
    // 0x83afd4: ldur            x2, [fp, #-0x38]
    // 0x83afd8: StoreField: r2->field_13 = r1
    //     0x83afd8: stur            w1, [x2, #0x13]
    // 0x83afdc: StoreField: r2->field_17 = rNULL
    //     0x83afdc: stur            NULL, [x2, #0x17]
    // 0x83afe0: ldur            x3, [fp, #-0x20]
    // 0x83afe4: r4 = LoadClassIdInstr(r3)
    //     0x83afe4: ldur            x4, [x3, #-1]
    //     0x83afe8: ubfx            x4, x4, #0xc, #0x14
    // 0x83afec: lsl             x4, x4, #1
    // 0x83aff0: r17 = 6958
    //     0x83aff0: mov             x17, #0x1b2e
    // 0x83aff4: cmp             w4, w17
    // 0x83aff8: b.gt            #0x83b038
    // 0x83affc: r17 = 6954
    //     0x83affc: mov             x17, #0x1b2a
    // 0x83b000: cmp             w4, w17
    // 0x83b004: b.lt            #0x83b02c
    // 0x83b008: r3 = 1
    //     0x83b008: mov             x3, #1
    // 0x83b00c: stp             x3, x1, [SP, #-0x10]!
    // 0x83b010: r0 = increment()
    //     0x83b010: bl              #0x5221fc  ; [package:flutter/src/painting/inline_span.dart] Accumulator::increment
    // 0x83b014: add             SP, SP, #0x10
    // 0x83b018: ldur            x0, [fp, #-0x38]
    // 0x83b01c: r4 = 131064
    //     0x83b01c: mov             x4, #0x1fff8
    // 0x83b020: StoreField: r0->field_17 = r4
    //     0x83b020: stur            w4, [x0, #0x17]
    // 0x83b024: mov             x1, x0
    // 0x83b028: b               #0x83b07c
    // 0x83b02c: mov             x0, x2
    // 0x83b030: r4 = 131064
    //     0x83b030: mov             x4, #0x1fff8
    // 0x83b034: b               #0x83b040
    // 0x83b038: mov             x0, x2
    // 0x83b03c: r4 = 131064
    //     0x83b03c: mov             x4, #0x1fff8
    // 0x83b040: mov             x2, x0
    // 0x83b044: r1 = Function '<anonymous closure>':.
    //     0x83b044: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f570] AnonymousClosure: (0x522224), in [package:flutter/src/painting/inline_span.dart] InlineSpan::codeUnitAt (0x522038)
    //     0x83b048: ldr             x1, [x1, #0x570]
    // 0x83b04c: r0 = AllocateClosure()
    //     0x83b04c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x83b050: mov             x1, x0
    // 0x83b054: ldur            x0, [fp, #-0x20]
    // 0x83b058: r2 = LoadClassIdInstr(r0)
    //     0x83b058: ldur            x2, [x0, #-1]
    //     0x83b05c: ubfx            x2, x2, #0xc, #0x14
    // 0x83b060: stp             x1, x0, [SP, #-0x10]!
    // 0x83b064: mov             x0, x2
    // 0x83b068: r0 = GDT[cid_x0 + -0x1000]()
    //     0x83b068: sub             lr, x0, #1, lsl #12
    //     0x83b06c: ldr             lr, [x21, lr, lsl #3]
    //     0x83b070: blr             lr
    // 0x83b074: add             SP, SP, #0x10
    // 0x83b078: ldur            x1, [fp, #-0x38]
    // 0x83b07c: LoadField: r2 = r1->field_17
    //     0x83b07c: ldur            w2, [x1, #0x17]
    // 0x83b080: DecompressPointer r2
    //     0x83b080: add             x2, x2, HEAP, lsl #32
    // 0x83b084: mov             x1, x2
    // 0x83b088: cmp             w1, NULL
    // 0x83b08c: b.eq            #0x83b1e0
    // 0x83b090: r2 = LoadInt32Instr(r1)
    //     0x83b090: sbfx            x2, x1, #1, #0x1f
    // 0x83b094: cmp             x2, #2, lsl #12
    // 0x83b098: b.gt            #0x83b124
    // 0x83b09c: cmp             x2, #0x1d
    // 0x83b0a0: b.gt            #0x83b0e4
    // 0x83b0a4: cmp             x2, #0xc
    // 0x83b0a8: b.gt            #0x83b0c8
    // 0x83b0ac: cmp             x2, #0xa
    // 0x83b0b0: b.gt            #0x83b180
    // 0x83b0b4: cmp             x2, #9
    // 0x83b0b8: b.gt            #0x83b180
    // 0x83b0bc: cmp             w1, #0x12
    // 0x83b0c0: b.ne            #0x83b194
    // 0x83b0c4: b               #0x83b180
    // 0x83b0c8: cmp             x2, #0x1c
    // 0x83b0cc: b.gt            #0x83b180
    // 0x83b0d0: cmp             x2, #0xd
    // 0x83b0d4: b.le            #0x83b180
    // 0x83b0d8: cmp             x2, #0x1c
    // 0x83b0dc: b.lt            #0x83b194
    // 0x83b0e0: b               #0x83b180
    // 0x83b0e4: cmp             x2, #0x20
    // 0x83b0e8: b.le            #0x83b180
    // 0x83b0ec: cmp             x2, #0xa0
    // 0x83b0f0: b.lt            #0x83b194
    // 0x83b0f4: r17 = 5760
    //     0x83b0f4: mov             x17, #0x1680
    // 0x83b0f8: cmp             x2, x17
    // 0x83b0fc: b.gt            #0x83b118
    // 0x83b100: cmp             x2, #0xa0
    // 0x83b104: b.le            #0x83b180
    // 0x83b108: r17 = 5760
    //     0x83b108: mov             x17, #0x1680
    // 0x83b10c: cmp             x2, x17
    // 0x83b110: b.lt            #0x83b194
    // 0x83b114: b               #0x83b180
    // 0x83b118: cmp             x2, #2, lsl #12
    // 0x83b11c: b.lt            #0x83b194
    // 0x83b120: b               #0x83b180
    // 0x83b124: r17 = 8199
    //     0x83b124: mov             x17, #0x2007
    // 0x83b128: cmp             x2, x17
    // 0x83b12c: b.le            #0x83b180
    // 0x83b130: r17 = 8202
    //     0x83b130: mov             x17, #0x200a
    // 0x83b134: cmp             x2, x17
    // 0x83b138: b.le            #0x83b180
    // 0x83b13c: r17 = 8239
    //     0x83b13c: mov             x17, #0x202f
    // 0x83b140: cmp             x2, x17
    // 0x83b144: b.lt            #0x83b194
    // 0x83b148: r17 = 8287
    //     0x83b148: mov             x17, #0x205f
    // 0x83b14c: cmp             x2, x17
    // 0x83b150: b.gt            #0x83b170
    // 0x83b154: r17 = 8239
    //     0x83b154: mov             x17, #0x202f
    // 0x83b158: cmp             x2, x17
    // 0x83b15c: b.le            #0x83b180
    // 0x83b160: r17 = 8287
    //     0x83b160: mov             x17, #0x205f
    // 0x83b164: cmp             x2, x17
    // 0x83b168: b.lt            #0x83b194
    // 0x83b16c: b               #0x83b180
    // 0x83b170: cmp             x2, #3, lsl #12
    // 0x83b174: b.lt            #0x83b194
    // 0x83b178: cmp             w1, #6, lsl #12
    // 0x83b17c: b.ne            #0x83b194
    // 0x83b180: ldur            x1, [fp, #-8]
    // 0x83b184: add             x5, x1, #1
    // 0x83b188: ldur            x2, [fp, #-0x30]
    // 0x83b18c: ldur            x3, [fp, #-0x28]
    // 0x83b190: b               #0x83af50
    // 0x83b194: ldur            x0, [fp, #-0x30]
    // 0x83b198: LeaveFrame
    //     0x83b198: mov             SP, fp
    //     0x83b19c: ldp             fp, lr, [SP], #0x10
    // 0x83b1a0: ret
    //     0x83b1a0: ret             
    // 0x83b1a4: ldur            x0, [fp, #-0x28]
    // 0x83b1a8: ldur            x1, [fp, #-0x10]
    // 0x83b1ac: b               #0x83aee0
    // 0x83b1b0: r0 = Null
    //     0x83b1b0: mov             x0, NULL
    // 0x83b1b4: LeaveFrame
    //     0x83b1b4: mov             SP, fp
    //     0x83b1b8: ldp             fp, lr, [SP], #0x10
    // 0x83b1bc: ret
    //     0x83b1bc: ret             
    // 0x83b1c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83b1c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83b1c4: b               #0x83aecc
    // 0x83b1c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83b1c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83b1cc: b               #0x83aef0
    // 0x83b1d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83b1d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83b1d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83b1d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83b1d8: b               #0x83af64
    // 0x83b1dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83b1dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83b1e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83b1e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getPreviousWord(/* No info */) {
    // ** addr: 0x83b6a4, size: 0x350
    // 0x83b6a4: EnterFrame
    //     0x83b6a4: stp             fp, lr, [SP, #-0x10]!
    //     0x83b6a8: mov             fp, SP
    // 0x83b6ac: AllocStack(0x40)
    //     0x83b6ac: sub             SP, SP, #0x40
    // 0x83b6b0: CheckStackOverflow
    //     0x83b6b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83b6b4: cmp             SP, x16
    //     0x83b6b8: b.ls            #0x83b9d0
    // 0x83b6bc: ldr             x0, [fp, #0x18]
    // 0x83b6c0: LoadField: r1 = r0->field_eb
    //     0x83b6c0: ldur            w1, [x0, #0xeb]
    // 0x83b6c4: DecompressPointer r1
    //     0x83b6c4: add             x1, x1, HEAP, lsl #32
    // 0x83b6c8: ldr             x0, [fp, #0x10]
    // 0x83b6cc: stur            x1, [fp, #-0x10]
    // 0x83b6d0: stur            x0, [fp, #-8]
    // 0x83b6d4: CheckStackOverflow
    //     0x83b6d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83b6d8: cmp             SP, x16
    //     0x83b6dc: b.ls            #0x83b9d8
    // 0x83b6e0: tbnz            x0, #0x3f, #0x83b9c0
    // 0x83b6e4: r0 = TextPosition()
    //     0x83b6e4: bl              #0x5223f0  ; AllocateTextPositionStub -> TextPosition (size=0x14)
    // 0x83b6e8: mov             x1, x0
    // 0x83b6ec: ldur            x0, [fp, #-8]
    // 0x83b6f0: StoreField: r1->field_7 = r0
    //     0x83b6f0: stur            x0, [x1, #7]
    // 0x83b6f4: r0 = Instance_TextAffinity
    //     0x83b6f4: ldr             x0, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x83b6f8: StoreField: r1->field_f = r0
    //     0x83b6f8: stur            w0, [x1, #0xf]
    // 0x83b6fc: ldur            x2, [fp, #-0x10]
    // 0x83b700: LoadField: r3 = r2->field_7
    //     0x83b700: ldur            w3, [x2, #7]
    // 0x83b704: DecompressPointer r3
    //     0x83b704: add             x3, x3, HEAP, lsl #32
    // 0x83b708: cmp             w3, NULL
    // 0x83b70c: b.eq            #0x83b9e0
    // 0x83b710: stp             x1, x3, [SP, #-0x10]!
    // 0x83b714: r0 = getWordBoundary()
    //     0x83b714: bl              #0x83b1e4  ; [dart:ui] Paragraph::getWordBoundary
    // 0x83b718: add             SP, SP, #0x10
    // 0x83b71c: mov             x2, x0
    // 0x83b720: stur            x2, [fp, #-0x38]
    // 0x83b724: LoadField: r3 = r2->field_7
    //     0x83b724: ldur            x3, [x2, #7]
    // 0x83b728: stur            x3, [fp, #-0x30]
    // 0x83b72c: tbnz            x3, #0x3f, #0x83b9b0
    // 0x83b730: LoadField: r4 = r2->field_f
    //     0x83b730: ldur            x4, [x2, #0xf]
    // 0x83b734: stur            x4, [fp, #-0x28]
    // 0x83b738: tbnz            x4, #0x3f, #0x83b9b0
    // 0x83b73c: cmp             x3, x4
    // 0x83b740: b.eq            #0x83b9b0
    // 0x83b744: mov             x6, x3
    // 0x83b748: ldur            x5, [fp, #-0x10]
    // 0x83b74c: stur            x6, [fp, #-8]
    // 0x83b750: CheckStackOverflow
    //     0x83b750: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83b754: cmp             SP, x16
    //     0x83b758: b.ls            #0x83b9e4
    // 0x83b75c: cmp             x6, x4
    // 0x83b760: b.ge            #0x83b9a0
    // 0x83b764: LoadField: r7 = r5->field_f
    //     0x83b764: ldur            w7, [x5, #0xf]
    // 0x83b768: DecompressPointer r7
    //     0x83b768: add             x7, x7, HEAP, lsl #32
    // 0x83b76c: stur            x7, [fp, #-0x20]
    // 0x83b770: cmp             w7, NULL
    // 0x83b774: b.eq            #0x83b9ec
    // 0x83b778: r0 = BoxInt64Instr(r6)
    //     0x83b778: sbfiz           x0, x6, #1, #0x1f
    //     0x83b77c: cmp             x6, x0, asr #1
    //     0x83b780: b.eq            #0x83b78c
    //     0x83b784: bl              #0xd69bb8
    //     0x83b788: stur            x6, [x0, #7]
    // 0x83b78c: stur            x0, [fp, #-0x18]
    // 0x83b790: r1 = 3
    //     0x83b790: mov             x1, #3
    // 0x83b794: r0 = AllocateContext()
    //     0x83b794: bl              #0xd68aa4  ; AllocateContextStub
    // 0x83b798: mov             x1, x0
    // 0x83b79c: ldur            x0, [fp, #-0x18]
    // 0x83b7a0: stur            x1, [fp, #-0x40]
    // 0x83b7a4: StoreField: r1->field_f = r0
    //     0x83b7a4: stur            w0, [x1, #0xf]
    // 0x83b7a8: ldur            x0, [fp, #-8]
    // 0x83b7ac: tbz             x0, #0x3f, #0x83b7b8
    // 0x83b7b0: r1 = Null
    //     0x83b7b0: mov             x1, NULL
    // 0x83b7b4: b               #0x83b880
    // 0x83b7b8: ldur            x2, [fp, #-0x20]
    // 0x83b7bc: r0 = Accumulator()
    //     0x83b7bc: bl              #0x522218  ; AllocateAccumulatorStub -> Accumulator (size=0x10)
    // 0x83b7c0: mov             x1, x0
    // 0x83b7c4: r0 = 0
    //     0x83b7c4: mov             x0, #0
    // 0x83b7c8: StoreField: r1->field_7 = r0
    //     0x83b7c8: stur            x0, [x1, #7]
    // 0x83b7cc: ldur            x2, [fp, #-0x40]
    // 0x83b7d0: StoreField: r2->field_13 = r1
    //     0x83b7d0: stur            w1, [x2, #0x13]
    // 0x83b7d4: StoreField: r2->field_17 = rNULL
    //     0x83b7d4: stur            NULL, [x2, #0x17]
    // 0x83b7d8: ldur            x3, [fp, #-0x20]
    // 0x83b7dc: r4 = LoadClassIdInstr(r3)
    //     0x83b7dc: ldur            x4, [x3, #-1]
    //     0x83b7e0: ubfx            x4, x4, #0xc, #0x14
    // 0x83b7e4: lsl             x4, x4, #1
    // 0x83b7e8: r17 = 6958
    //     0x83b7e8: mov             x17, #0x1b2e
    // 0x83b7ec: cmp             w4, w17
    // 0x83b7f0: b.gt            #0x83b830
    // 0x83b7f4: r17 = 6954
    //     0x83b7f4: mov             x17, #0x1b2a
    // 0x83b7f8: cmp             w4, w17
    // 0x83b7fc: b.lt            #0x83b824
    // 0x83b800: r3 = 1
    //     0x83b800: mov             x3, #1
    // 0x83b804: stp             x3, x1, [SP, #-0x10]!
    // 0x83b808: r0 = increment()
    //     0x83b808: bl              #0x5221fc  ; [package:flutter/src/painting/inline_span.dart] Accumulator::increment
    // 0x83b80c: add             SP, SP, #0x10
    // 0x83b810: ldur            x0, [fp, #-0x40]
    // 0x83b814: r4 = 131064
    //     0x83b814: mov             x4, #0x1fff8
    // 0x83b818: StoreField: r0->field_17 = r4
    //     0x83b818: stur            w4, [x0, #0x17]
    // 0x83b81c: mov             x1, x0
    // 0x83b820: b               #0x83b874
    // 0x83b824: mov             x0, x2
    // 0x83b828: r4 = 131064
    //     0x83b828: mov             x4, #0x1fff8
    // 0x83b82c: b               #0x83b838
    // 0x83b830: mov             x0, x2
    // 0x83b834: r4 = 131064
    //     0x83b834: mov             x4, #0x1fff8
    // 0x83b838: mov             x2, x0
    // 0x83b83c: r1 = Function '<anonymous closure>':.
    //     0x83b83c: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f570] AnonymousClosure: (0x522224), in [package:flutter/src/painting/inline_span.dart] InlineSpan::codeUnitAt (0x522038)
    //     0x83b840: ldr             x1, [x1, #0x570]
    // 0x83b844: r0 = AllocateClosure()
    //     0x83b844: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x83b848: mov             x1, x0
    // 0x83b84c: ldur            x0, [fp, #-0x20]
    // 0x83b850: r2 = LoadClassIdInstr(r0)
    //     0x83b850: ldur            x2, [x0, #-1]
    //     0x83b854: ubfx            x2, x2, #0xc, #0x14
    // 0x83b858: stp             x1, x0, [SP, #-0x10]!
    // 0x83b85c: mov             x0, x2
    // 0x83b860: r0 = GDT[cid_x0 + -0x1000]()
    //     0x83b860: sub             lr, x0, #1, lsl #12
    //     0x83b864: ldr             lr, [x21, lr, lsl #3]
    //     0x83b868: blr             lr
    // 0x83b86c: add             SP, SP, #0x10
    // 0x83b870: ldur            x1, [fp, #-0x40]
    // 0x83b874: LoadField: r2 = r1->field_17
    //     0x83b874: ldur            w2, [x1, #0x17]
    // 0x83b878: DecompressPointer r2
    //     0x83b878: add             x2, x2, HEAP, lsl #32
    // 0x83b87c: mov             x1, x2
    // 0x83b880: cmp             w1, NULL
    // 0x83b884: b.eq            #0x83b9f0
    // 0x83b888: r2 = LoadInt32Instr(r1)
    //     0x83b888: sbfx            x2, x1, #1, #0x1f
    // 0x83b88c: cmp             x2, #2, lsl #12
    // 0x83b890: b.gt            #0x83b91c
    // 0x83b894: cmp             x2, #0x1d
    // 0x83b898: b.gt            #0x83b8dc
    // 0x83b89c: cmp             x2, #0xc
    // 0x83b8a0: b.gt            #0x83b8c0
    // 0x83b8a4: cmp             x2, #0xa
    // 0x83b8a8: b.gt            #0x83b978
    // 0x83b8ac: cmp             x2, #9
    // 0x83b8b0: b.gt            #0x83b978
    // 0x83b8b4: cmp             w1, #0x12
    // 0x83b8b8: b.ne            #0x83b990
    // 0x83b8bc: b               #0x83b978
    // 0x83b8c0: cmp             x2, #0x1c
    // 0x83b8c4: b.gt            #0x83b978
    // 0x83b8c8: cmp             x2, #0xd
    // 0x83b8cc: b.le            #0x83b978
    // 0x83b8d0: cmp             x2, #0x1c
    // 0x83b8d4: b.lt            #0x83b990
    // 0x83b8d8: b               #0x83b978
    // 0x83b8dc: cmp             x2, #0x20
    // 0x83b8e0: b.le            #0x83b978
    // 0x83b8e4: cmp             x2, #0xa0
    // 0x83b8e8: b.lt            #0x83b990
    // 0x83b8ec: r17 = 5760
    //     0x83b8ec: mov             x17, #0x1680
    // 0x83b8f0: cmp             x2, x17
    // 0x83b8f4: b.gt            #0x83b910
    // 0x83b8f8: cmp             x2, #0xa0
    // 0x83b8fc: b.le            #0x83b978
    // 0x83b900: r17 = 5760
    //     0x83b900: mov             x17, #0x1680
    // 0x83b904: cmp             x2, x17
    // 0x83b908: b.lt            #0x83b990
    // 0x83b90c: b               #0x83b978
    // 0x83b910: cmp             x2, #2, lsl #12
    // 0x83b914: b.lt            #0x83b990
    // 0x83b918: b               #0x83b978
    // 0x83b91c: r17 = 8199
    //     0x83b91c: mov             x17, #0x2007
    // 0x83b920: cmp             x2, x17
    // 0x83b924: b.le            #0x83b978
    // 0x83b928: r17 = 8202
    //     0x83b928: mov             x17, #0x200a
    // 0x83b92c: cmp             x2, x17
    // 0x83b930: b.le            #0x83b978
    // 0x83b934: r17 = 8239
    //     0x83b934: mov             x17, #0x202f
    // 0x83b938: cmp             x2, x17
    // 0x83b93c: b.lt            #0x83b990
    // 0x83b940: r17 = 8287
    //     0x83b940: mov             x17, #0x205f
    // 0x83b944: cmp             x2, x17
    // 0x83b948: b.gt            #0x83b968
    // 0x83b94c: r17 = 8239
    //     0x83b94c: mov             x17, #0x202f
    // 0x83b950: cmp             x2, x17
    // 0x83b954: b.le            #0x83b978
    // 0x83b958: r17 = 8287
    //     0x83b958: mov             x17, #0x205f
    // 0x83b95c: cmp             x2, x17
    // 0x83b960: b.lt            #0x83b990
    // 0x83b964: b               #0x83b978
    // 0x83b968: cmp             x2, #3, lsl #12
    // 0x83b96c: b.lt            #0x83b990
    // 0x83b970: cmp             w1, #6, lsl #12
    // 0x83b974: b.ne            #0x83b990
    // 0x83b978: ldur            x1, [fp, #-8]
    // 0x83b97c: add             x6, x1, #1
    // 0x83b980: ldur            x2, [fp, #-0x38]
    // 0x83b984: ldur            x3, [fp, #-0x30]
    // 0x83b988: ldur            x4, [fp, #-0x28]
    // 0x83b98c: b               #0x83b748
    // 0x83b990: ldur            x0, [fp, #-0x38]
    // 0x83b994: LeaveFrame
    //     0x83b994: mov             SP, fp
    //     0x83b998: ldp             fp, lr, [SP], #0x10
    // 0x83b99c: ret
    //     0x83b99c: ret             
    // 0x83b9a0: mov             x1, x3
    // 0x83b9a4: sub             x0, x1, #1
    // 0x83b9a8: ldur            x1, [fp, #-0x10]
    // 0x83b9ac: b               #0x83b6d0
    // 0x83b9b0: r0 = Null
    //     0x83b9b0: mov             x0, NULL
    // 0x83b9b4: LeaveFrame
    //     0x83b9b4: mov             SP, fp
    //     0x83b9b8: ldp             fp, lr, [SP], #0x10
    // 0x83b9bc: ret
    //     0x83b9bc: ret             
    // 0x83b9c0: r0 = Null
    //     0x83b9c0: mov             x0, NULL
    // 0x83b9c4: LeaveFrame
    //     0x83b9c4: mov             SP, fp
    //     0x83b9c8: ldp             fp, lr, [SP], #0x10
    // 0x83b9cc: ret
    //     0x83b9cc: ret             
    // 0x83b9d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83b9d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83b9d4: b               #0x83b6bc
    // 0x83b9d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83b9d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83b9dc: b               #0x83b6e0
    // 0x83b9e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83b9e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83b9e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83b9e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83b9e8: b               #0x83b75c
    // 0x83b9ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83b9ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83b9f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83b9f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bc564, size: 0x15c
    // 0x9bc564: EnterFrame
    //     0x9bc564: stp             fp, lr, [SP, #-0x10]!
    //     0x9bc568: mov             fp, SP
    // 0x9bc56c: AllocStack(0x8)
    //     0x9bc56c: sub             SP, SP, #8
    // 0x9bc570: CheckStackOverflow
    //     0x9bc570: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bc574: cmp             SP, x16
    //     0x9bc578: b.ls            #0x9bc6b8
    // 0x9bc57c: ldr             x0, [fp, #0x10]
    // 0x9bc580: r2 = Null
    //     0x9bc580: mov             x2, NULL
    // 0x9bc584: r1 = Null
    //     0x9bc584: mov             x1, NULL
    // 0x9bc588: r4 = 59
    //     0x9bc588: mov             x4, #0x3b
    // 0x9bc58c: branchIfSmi(r0, 0x9bc598)
    //     0x9bc58c: tbz             w0, #0, #0x9bc598
    // 0x9bc590: r4 = LoadClassIdInstr(r0)
    //     0x9bc590: ldur            x4, [x0, #-1]
    //     0x9bc594: ubfx            x4, x4, #0xc, #0x14
    // 0x9bc598: cmp             x4, #0x7e6
    // 0x9bc59c: b.eq            #0x9bc5b0
    // 0x9bc5a0: r8 = PipelineOwner
    //     0x9bc5a0: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9bc5a4: r3 = Null
    //     0x9bc5a4: add             x3, PP, #0x56, lsl #12  ; [pp+0x56850] Null
    //     0x9bc5a8: ldr             x3, [x3, #0x850]
    // 0x9bc5ac: r0 = DefaultTypeTest()
    //     0x9bc5ac: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bc5b0: ldr             x16, [fp, #0x18]
    // 0x9bc5b4: ldr             lr, [fp, #0x10]
    // 0x9bc5b8: stp             lr, x16, [SP, #-0x10]!
    // 0x9bc5bc: r0 = attach()
    //     0x9bc5bc: bl              #0x9bc6c0  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::attach
    // 0x9bc5c0: add             SP, SP, #0x10
    // 0x9bc5c4: ldr             x0, [fp, #0x18]
    // 0x9bc5c8: LoadField: r1 = r0->field_9b
    //     0x9bc5c8: ldur            w1, [x0, #0x9b]
    // 0x9bc5cc: DecompressPointer r1
    //     0x9bc5cc: add             x1, x1, HEAP, lsl #32
    // 0x9bc5d0: cmp             w1, NULL
    // 0x9bc5d4: b.eq            #0x9bc5ec
    // 0x9bc5d8: ldr             x16, [fp, #0x10]
    // 0x9bc5dc: stp             x16, x1, [SP, #-0x10]!
    // 0x9bc5e0: r0 = attach()
    //     0x9bc5e0: bl              #0x9bcf00  ; [package:extended_text_field/src/extended_render_editable.dart] _RenderEditableCustomPaint::attach
    // 0x9bc5e4: add             SP, SP, #0x10
    // 0x9bc5e8: ldr             x0, [fp, #0x18]
    // 0x9bc5ec: LoadField: r1 = r0->field_9f
    //     0x9bc5ec: ldur            w1, [x0, #0x9f]
    // 0x9bc5f0: DecompressPointer r1
    //     0x9bc5f0: add             x1, x1, HEAP, lsl #32
    // 0x9bc5f4: cmp             w1, NULL
    // 0x9bc5f8: b.eq            #0x9bc610
    // 0x9bc5fc: ldr             x16, [fp, #0x10]
    // 0x9bc600: stp             x16, x1, [SP, #-0x10]!
    // 0x9bc604: r0 = attach()
    //     0x9bc604: bl              #0x9bcf00  ; [package:extended_text_field/src/extended_render_editable.dart] _RenderEditableCustomPaint::attach
    // 0x9bc608: add             SP, SP, #0x10
    // 0x9bc60c: ldr             x0, [fp, #0x18]
    // 0x9bc610: r17 = 275
    //     0x9bc610: mov             x17, #0x113
    // 0x9bc614: ldr             w1, [x0, x17]
    // 0x9bc618: DecompressPointer r1
    //     0x9bc618: add             x1, x1, HEAP, lsl #32
    // 0x9bc61c: stur            x1, [fp, #-8]
    // 0x9bc620: r1 = 1
    //     0x9bc620: mov             x1, #1
    // 0x9bc624: r0 = AllocateContext()
    //     0x9bc624: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9bc628: mov             x1, x0
    // 0x9bc62c: ldr             x0, [fp, #0x18]
    // 0x9bc630: StoreField: r1->field_f = r0
    //     0x9bc630: stur            w0, [x1, #0xf]
    // 0x9bc634: mov             x2, x1
    // 0x9bc638: r1 = Function 'markNeedsPaint':.
    //     0x9bc638: add             x1, PP, #0x55, lsl #12  ; [pp+0x55b48] AnonymousClosure: (0x6bf010), in [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::markNeedsPaint (0x6bef94)
    //     0x9bc63c: ldr             x1, [x1, #0xb48]
    // 0x9bc640: r0 = AllocateClosure()
    //     0x9bc640: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9bc644: ldur            x16, [fp, #-8]
    // 0x9bc648: stp             x0, x16, [SP, #-0x10]!
    // 0x9bc64c: r0 = addListener()
    //     0x9bc64c: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x9bc650: add             SP, SP, #0x10
    // 0x9bc654: ldr             x16, [fp, #0x18]
    // 0x9bc658: SaveReg r16
    //     0x9bc658: str             x16, [SP, #-8]!
    // 0x9bc65c: r0 = _showHideCursor()
    //     0x9bc65c: bl              #0x6dfbd0  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_showHideCursor
    // 0x9bc660: add             SP, SP, #8
    // 0x9bc664: ldr             x0, [fp, #0x18]
    // 0x9bc668: LoadField: r1 = r0->field_f7
    //     0x9bc668: ldur            w1, [x0, #0xf7]
    // 0x9bc66c: DecompressPointer r1
    //     0x9bc66c: add             x1, x1, HEAP, lsl #32
    // 0x9bc670: stur            x1, [fp, #-8]
    // 0x9bc674: r1 = 1
    //     0x9bc674: mov             x1, #1
    // 0x9bc678: r0 = AllocateContext()
    //     0x9bc678: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9bc67c: mov             x1, x0
    // 0x9bc680: ldr             x0, [fp, #0x18]
    // 0x9bc684: StoreField: r1->field_f = r0
    //     0x9bc684: stur            w0, [x1, #0xf]
    // 0x9bc688: mov             x2, x1
    // 0x9bc68c: r1 = Function '_showHideCursor@483409610':.
    //     0x9bc68c: add             x1, PP, #0x55, lsl #12  ; [pp+0x55b50] AnonymousClosure: (0x6dfca8), in [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_showHideCursor (0x6dfbd0)
    //     0x9bc690: ldr             x1, [x1, #0xb50]
    // 0x9bc694: r0 = AllocateClosure()
    //     0x9bc694: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9bc698: ldur            x16, [fp, #-8]
    // 0x9bc69c: stp             x0, x16, [SP, #-0x10]!
    // 0x9bc6a0: r0 = addListener()
    //     0x9bc6a0: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x9bc6a4: add             SP, SP, #0x10
    // 0x9bc6a8: r0 = Null
    //     0x9bc6a8: mov             x0, NULL
    // 0x9bc6ac: LeaveFrame
    //     0x9bc6ac: mov             SP, fp
    //     0x9bc6b0: ldp             fp, lr, [SP], #0x10
    // 0x9bc6b4: ret
    //     0x9bc6b4: ret             
    // 0x9bc6b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bc6b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bc6bc: b               #0x9bc57c
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5ce5c, size: 0x230
    // 0xa5ce5c: EnterFrame
    //     0xa5ce5c: stp             fp, lr, [SP, #-0x10]!
    //     0xa5ce60: mov             fp, SP
    // 0xa5ce64: AllocStack(0x18)
    //     0xa5ce64: sub             SP, SP, #0x18
    // 0xa5ce68: CheckStackOverflow
    //     0xa5ce68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5ce6c: cmp             SP, x16
    //     0xa5ce70: b.ls            #0xa5d050
    // 0xa5ce74: ldr             x16, [fp, #0x18]
    // 0xa5ce78: SaveReg r16
    //     0xa5ce78: str             x16, [SP, #-8]!
    // 0xa5ce7c: r0 = _canComputeDryLayout()
    //     0xa5ce7c: bl              #0xa5d08c  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_canComputeDryLayout
    // 0xa5ce80: add             SP, SP, #8
    // 0xa5ce84: tbz             w0, #4, #0xa5ce98
    // 0xa5ce88: r0 = Instance_Size
    //     0xa5ce88: ldr             x0, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0xa5ce8c: LeaveFrame
    //     0xa5ce8c: mov             SP, fp
    //     0xa5ce90: ldp             fp, lr, [SP], #0x10
    // 0xa5ce94: ret
    //     0xa5ce94: ret             
    // 0xa5ce98: ldr             x0, [fp, #0x18]
    // 0xa5ce9c: ldr             x16, [fp, #0x10]
    // 0xa5cea0: stp             x16, x0, [SP, #-0x10]!
    // 0xa5cea4: r16 = true
    //     0xa5cea4: add             x16, NULL, #0x20  ; true
    // 0xa5cea8: SaveReg r16
    //     0xa5cea8: str             x16, [SP, #-8]!
    // 0xa5ceac: r4 = const [0, 0x3, 0x3, 0x2, dry, 0x2, null]
    //     0xa5ceac: add             x4, PP, #0x22, lsl #12  ; [pp+0x22470] List(7) [0, 0x3, 0x3, 0x2, "dry", 0x2, Null]
    //     0xa5ceb0: ldr             x4, [x4, #0x470]
    // 0xa5ceb4: r0 = layoutChildren()
    //     0xa5ceb4: bl              #0x68c390  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::layoutChildren
    // 0xa5ceb8: add             SP, SP, #0x18
    // 0xa5cebc: ldr             x16, [fp, #0x18]
    // 0xa5cec0: SaveReg r16
    //     0xa5cec0: str             x16, [SP, #-8]!
    // 0xa5cec4: r0 = computeTextMetricsIfNeeded()
    //     0xa5cec4: bl              #0x522fec  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::computeTextMetricsIfNeeded
    // 0xa5cec8: add             SP, SP, #8
    // 0xa5cecc: ldr             x0, [fp, #0x18]
    // 0xa5ced0: LoadField: r1 = r0->field_fb
    //     0xa5ced0: ldur            w1, [x0, #0xfb]
    // 0xa5ced4: DecompressPointer r1
    //     0xa5ced4: add             x1, x1, HEAP, lsl #32
    // 0xa5ced8: tbnz            w1, #4, #0xa5ceec
    // 0xa5cedc: ldr             x1, [fp, #0x10]
    // 0xa5cee0: LoadField: d0 = r1->field_f
    //     0xa5cee0: ldur            d0, [x1, #0xf]
    // 0xa5cee4: mov             x0, x1
    // 0xa5cee8: b               #0xa5cfd4
    // 0xa5ceec: ldr             x1, [fp, #0x10]
    // 0xa5cef0: LoadField: r2 = r0->field_eb
    //     0xa5cef0: ldur            w2, [x0, #0xeb]
    // 0xa5cef4: DecompressPointer r2
    //     0xa5cef4: add             x2, x2, HEAP, lsl #32
    // 0xa5cef8: stur            x2, [fp, #-8]
    // 0xa5cefc: LoadField: r3 = r2->field_7
    //     0xa5cefc: ldur            w3, [x2, #7]
    // 0xa5cf00: DecompressPointer r3
    //     0xa5cf00: add             x3, x3, HEAP, lsl #32
    // 0xa5cf04: cmp             w3, NULL
    // 0xa5cf08: b.eq            #0xa5d058
    // 0xa5cf0c: SaveReg r3
    //     0xa5cf0c: str             x3, [SP, #-8]!
    // 0xa5cf10: r0 = width()
    //     0xa5cf10: bl              #0x520ee4  ; [dart:ui] Paragraph::width
    // 0xa5cf14: add             SP, SP, #8
    // 0xa5cf18: stp             fp, lr, [SP, #-0x10]!
    // 0xa5cf1c: mov             fp, SP
    // 0xa5cf20: CallRuntime_LibcCeil(double) -> double
    //     0xa5cf20: and             SP, SP, #0xfffffffffffffff0
    //     0xa5cf24: mov             sp, SP
    //     0xa5cf28: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0xa5cf2c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xa5cf30: blr             x16
    //     0xa5cf34: mov             x16, #8
    //     0xa5cf38: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xa5cf3c: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xa5cf40: sub             sp, x16, #1, lsl #12
    //     0xa5cf44: mov             SP, fp
    //     0xa5cf48: ldp             fp, lr, [SP], #0x10
    // 0xa5cf4c: ldur            x0, [fp, #-8]
    // 0xa5cf50: stur            d0, [fp, #-0x10]
    // 0xa5cf54: LoadField: r1 = r0->field_7
    //     0xa5cf54: ldur            w1, [x0, #7]
    // 0xa5cf58: DecompressPointer r1
    //     0xa5cf58: add             x1, x1, HEAP, lsl #32
    // 0xa5cf5c: cmp             w1, NULL
    // 0xa5cf60: b.eq            #0xa5d05c
    // 0xa5cf64: SaveReg r1
    //     0xa5cf64: str             x1, [SP, #-8]!
    // 0xa5cf68: r0 = height()
    //     0xa5cf68: bl              #0x51a4dc  ; [dart:ui] Paragraph::height
    // 0xa5cf6c: add             SP, SP, #8
    // 0xa5cf70: ldr             x0, [fp, #0x18]
    // 0xa5cf74: r17 = 279
    //     0xa5cf74: mov             x17, #0x117
    // 0xa5cf78: ldr             w1, [x0, x17]
    // 0xa5cf7c: DecompressPointer r1
    //     0xa5cf7c: add             x1, x1, HEAP, lsl #32
    // 0xa5cf80: LoadField: d0 = r1->field_7
    //     0xa5cf80: ldur            d0, [x1, #7]
    // 0xa5cf84: d1 = 1.000000
    //     0xa5cf84: fmov            d1, #1.00000000
    // 0xa5cf88: fadd            d2, d1, d0
    // 0xa5cf8c: ldur            d0, [fp, #-0x10]
    // 0xa5cf90: fadd            d1, d0, d2
    // 0xa5cf94: r1 = inline_Allocate_Double()
    //     0xa5cf94: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xa5cf98: add             x1, x1, #0x10
    //     0xa5cf9c: cmp             x2, x1
    //     0xa5cfa0: b.ls            #0xa5d060
    //     0xa5cfa4: str             x1, [THR, #0x60]  ; THR::top
    //     0xa5cfa8: sub             x1, x1, #0xf
    //     0xa5cfac: mov             x2, #0xd108
    //     0xa5cfb0: movk            x2, #3, lsl #16
    //     0xa5cfb4: stur            x2, [x1, #-1]
    // 0xa5cfb8: StoreField: r1->field_7 = d1
    //     0xa5cfb8: stur            d1, [x1, #7]
    // 0xa5cfbc: ldr             x16, [fp, #0x10]
    // 0xa5cfc0: stp             x1, x16, [SP, #-0x10]!
    // 0xa5cfc4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa5cfc4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa5cfc8: r0 = constrainWidth()
    //     0xa5cfc8: bl              #0x62bc8c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xa5cfcc: add             SP, SP, #0x10
    // 0xa5cfd0: ldr             x0, [fp, #0x10]
    // 0xa5cfd4: stur            d0, [fp, #-0x10]
    // 0xa5cfd8: LoadField: d1 = r0->field_f
    //     0xa5cfd8: ldur            d1, [x0, #0xf]
    // 0xa5cfdc: ldr             x16, [fp, #0x18]
    // 0xa5cfe0: SaveReg r16
    //     0xa5cfe0: str             x16, [SP, #-8]!
    // 0xa5cfe4: SaveReg d1
    //     0xa5cfe4: str             d1, [SP, #-8]!
    // 0xa5cfe8: r0 = _preferredHeight()
    //     0xa5cfe8: bl              #0x68b97c  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_preferredHeight
    // 0xa5cfec: add             SP, SP, #0x10
    // 0xa5cff0: r0 = inline_Allocate_Double()
    //     0xa5cff0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa5cff4: add             x0, x0, #0x10
    //     0xa5cff8: cmp             x1, x0
    //     0xa5cffc: b.ls            #0xa5d07c
    //     0xa5d000: str             x0, [THR, #0x60]  ; THR::top
    //     0xa5d004: sub             x0, x0, #0xf
    //     0xa5d008: mov             x1, #0xd108
    //     0xa5d00c: movk            x1, #3, lsl #16
    //     0xa5d010: stur            x1, [x0, #-1]
    // 0xa5d014: StoreField: r0->field_7 = d0
    //     0xa5d014: stur            d0, [x0, #7]
    // 0xa5d018: ldr             x16, [fp, #0x10]
    // 0xa5d01c: stp             x0, x16, [SP, #-0x10]!
    // 0xa5d020: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa5d020: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa5d024: r0 = constrainHeight()
    //     0xa5d024: bl              #0x62bc00  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xa5d028: add             SP, SP, #0x10
    // 0xa5d02c: stur            d0, [fp, #-0x18]
    // 0xa5d030: r0 = Size()
    //     0xa5d030: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xa5d034: ldur            d0, [fp, #-0x10]
    // 0xa5d038: StoreField: r0->field_7 = d0
    //     0xa5d038: stur            d0, [x0, #7]
    // 0xa5d03c: ldur            d0, [fp, #-0x18]
    // 0xa5d040: StoreField: r0->field_f = d0
    //     0xa5d040: stur            d0, [x0, #0xf]
    // 0xa5d044: LeaveFrame
    //     0xa5d044: mov             SP, fp
    //     0xa5d048: ldp             fp, lr, [SP], #0x10
    // 0xa5d04c: ret
    //     0xa5d04c: ret             
    // 0xa5d050: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5d050: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5d054: b               #0xa5ce74
    // 0xa5d058: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa5d058: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa5d05c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa5d05c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa5d060: SaveReg d1
    //     0xa5d060: str             q1, [SP, #-0x10]!
    // 0xa5d064: SaveReg r0
    //     0xa5d064: str             x0, [SP, #-8]!
    // 0xa5d068: r0 = AllocateDouble()
    //     0xa5d068: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa5d06c: mov             x1, x0
    // 0xa5d070: RestoreReg r0
    //     0xa5d070: ldr             x0, [SP], #8
    // 0xa5d074: RestoreReg d1
    //     0xa5d074: ldr             q1, [SP], #0x10
    // 0xa5d078: b               #0xa5cfb8
    // 0xa5d07c: SaveReg d0
    //     0xa5d07c: str             q0, [SP, #-0x10]!
    // 0xa5d080: r0 = AllocateDouble()
    //     0xa5d080: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa5d084: RestoreReg d0
    //     0xa5d084: ldr             q0, [SP], #0x10
    // 0xa5d088: b               #0xa5d014
  }
  _ _canComputeDryLayout(/* No info */) {
    // ** addr: 0xa5d08c, size: 0x1b0
    // 0xa5d08c: EnterFrame
    //     0xa5d08c: stp             fp, lr, [SP, #-0x10]!
    //     0xa5d090: mov             fp, SP
    // 0xa5d094: AllocStack(0x30)
    //     0xa5d094: sub             SP, SP, #0x30
    // 0xa5d098: CheckStackOverflow
    //     0xa5d098: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5d09c: cmp             SP, x16
    //     0xa5d0a0: b.ls            #0xa5d220
    // 0xa5d0a4: ldr             x0, [fp, #0x10]
    // 0xa5d0a8: LoadField: r1 = r0->field_7b
    //     0xa5d0a8: ldur            w1, [x0, #0x7b]
    // 0xa5d0ac: DecompressPointer r1
    //     0xa5d0ac: add             x1, x1, HEAP, lsl #32
    // 0xa5d0b0: r16 = Sentinel
    //     0xa5d0b0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa5d0b4: cmp             w1, w16
    // 0xa5d0b8: b.eq            #0xa5d228
    // 0xa5d0bc: stur            x1, [fp, #-0x20]
    // 0xa5d0c0: LoadField: r2 = r1->field_7
    //     0xa5d0c0: ldur            w2, [x1, #7]
    // 0xa5d0c4: DecompressPointer r2
    //     0xa5d0c4: add             x2, x2, HEAP, lsl #32
    // 0xa5d0c8: stur            x2, [fp, #-0x18]
    // 0xa5d0cc: LoadField: r0 = r1->field_b
    //     0xa5d0cc: ldur            w0, [x1, #0xb]
    // 0xa5d0d0: DecompressPointer r0
    //     0xa5d0d0: add             x0, x0, HEAP, lsl #32
    // 0xa5d0d4: r3 = LoadInt32Instr(r0)
    //     0xa5d0d4: sbfx            x3, x0, #1, #0x1f
    // 0xa5d0d8: stur            x3, [fp, #-0x10]
    // 0xa5d0dc: r4 = 0
    //     0xa5d0dc: mov             x4, #0
    // 0xa5d0e0: stur            x4, [fp, #-8]
    // 0xa5d0e4: CheckStackOverflow
    //     0xa5d0e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5d0e8: cmp             SP, x16
    //     0xa5d0ec: b.ls            #0xa5d234
    // 0xa5d0f0: r0 = LoadClassIdInstr(r1)
    //     0xa5d0f0: ldur            x0, [x1, #-1]
    //     0xa5d0f4: ubfx            x0, x0, #0xc, #0x14
    // 0xa5d0f8: SaveReg r1
    //     0xa5d0f8: str             x1, [SP, #-8]!
    // 0xa5d0fc: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa5d0fc: mov             x17, #0xb8ea
    //     0xa5d100: add             lr, x0, x17
    //     0xa5d104: ldr             lr, [x21, lr, lsl #3]
    //     0xa5d108: blr             lr
    // 0xa5d10c: add             SP, SP, #8
    // 0xa5d110: r1 = LoadInt32Instr(r0)
    //     0xa5d110: sbfx            x1, x0, #1, #0x1f
    //     0xa5d114: tbz             w0, #0, #0xa5d11c
    //     0xa5d118: ldur            x1, [x0, #7]
    // 0xa5d11c: ldur            x2, [fp, #-0x10]
    // 0xa5d120: cmp             x2, x1
    // 0xa5d124: b.ne            #0xa5d208
    // 0xa5d128: ldur            x3, [fp, #-0x20]
    // 0xa5d12c: ldur            x4, [fp, #-8]
    // 0xa5d130: cmp             x4, x1
    // 0xa5d134: b.lt            #0xa5d148
    // 0xa5d138: r0 = true
    //     0xa5d138: add             x0, NULL, #0x20  ; true
    // 0xa5d13c: LeaveFrame
    //     0xa5d13c: mov             SP, fp
    //     0xa5d140: ldp             fp, lr, [SP], #0x10
    // 0xa5d144: ret
    //     0xa5d144: ret             
    // 0xa5d148: r0 = BoxInt64Instr(r4)
    //     0xa5d148: sbfiz           x0, x4, #1, #0x1f
    //     0xa5d14c: cmp             x4, x0, asr #1
    //     0xa5d150: b.eq            #0xa5d15c
    //     0xa5d154: bl              #0xd69bb8
    //     0xa5d158: stur            x4, [x0, #7]
    // 0xa5d15c: r1 = LoadClassIdInstr(r3)
    //     0xa5d15c: ldur            x1, [x3, #-1]
    //     0xa5d160: ubfx            x1, x1, #0xc, #0x14
    // 0xa5d164: stp             x0, x3, [SP, #-0x10]!
    // 0xa5d168: mov             x0, x1
    // 0xa5d16c: r0 = GDT[cid_x0 + 0xd175]()
    //     0xa5d16c: mov             x17, #0xd175
    //     0xa5d170: add             lr, x0, x17
    //     0xa5d174: ldr             lr, [x21, lr, lsl #3]
    //     0xa5d178: blr             lr
    // 0xa5d17c: add             SP, SP, #0x10
    // 0xa5d180: mov             x3, x0
    // 0xa5d184: ldur            x0, [fp, #-8]
    // 0xa5d188: stur            x3, [fp, #-0x30]
    // 0xa5d18c: add             x4, x0, #1
    // 0xa5d190: stur            x4, [fp, #-0x28]
    // 0xa5d194: cmp             w3, NULL
    // 0xa5d198: b.ne            #0xa5d1cc
    // 0xa5d19c: mov             x0, x3
    // 0xa5d1a0: ldur            x2, [fp, #-0x18]
    // 0xa5d1a4: r1 = Null
    //     0xa5d1a4: mov             x1, NULL
    // 0xa5d1a8: cmp             w2, NULL
    // 0xa5d1ac: b.eq            #0xa5d1cc
    // 0xa5d1b0: LoadField: r4 = r2->field_17
    //     0xa5d1b0: ldur            w4, [x2, #0x17]
    // 0xa5d1b4: DecompressPointer r4
    //     0xa5d1b4: add             x4, x4, HEAP, lsl #32
    // 0xa5d1b8: r8 = X0
    //     0xa5d1b8: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa5d1bc: LoadField: r9 = r4->field_7
    //     0xa5d1bc: ldur            x9, [x4, #7]
    // 0xa5d1c0: r3 = Null
    //     0xa5d1c0: add             x3, PP, #0x56, lsl #12  ; [pp+0x56830] Null
    //     0xa5d1c4: ldr             x3, [x3, #0x830]
    // 0xa5d1c8: blr             x9
    // 0xa5d1cc: ldur            x1, [fp, #-0x30]
    // 0xa5d1d0: LoadField: r2 = r1->field_b
    //     0xa5d1d0: ldur            w2, [x1, #0xb]
    // 0xa5d1d4: DecompressPointer r2
    //     0xa5d1d4: add             x2, x2, HEAP, lsl #32
    // 0xa5d1d8: LoadField: r1 = r2->field_7
    //     0xa5d1d8: ldur            x1, [x2, #7]
    // 0xa5d1dc: cmp             x1, #2
    // 0xa5d1e0: b.gt            #0xa5d1f4
    // 0xa5d1e4: r0 = false
    //     0xa5d1e4: add             x0, NULL, #0x30  ; false
    // 0xa5d1e8: LeaveFrame
    //     0xa5d1e8: mov             SP, fp
    //     0xa5d1ec: ldp             fp, lr, [SP], #0x10
    // 0xa5d1f0: ret
    //     0xa5d1f0: ret             
    // 0xa5d1f4: ldur            x4, [fp, #-0x28]
    // 0xa5d1f8: ldur            x2, [fp, #-0x18]
    // 0xa5d1fc: ldur            x1, [fp, #-0x20]
    // 0xa5d200: ldur            x3, [fp, #-0x10]
    // 0xa5d204: b               #0xa5d0e0
    // 0xa5d208: ldur            x0, [fp, #-0x20]
    // 0xa5d20c: r0 = ConcurrentModificationError()
    //     0xa5d20c: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xa5d210: ldur            x3, [fp, #-0x20]
    // 0xa5d214: StoreField: r0->field_b = r3
    //     0xa5d214: stur            w3, [x0, #0xb]
    // 0xa5d218: r0 = Throw()
    //     0xa5d218: bl              #0xd67e38  ; ThrowStub
    // 0xa5d21c: brk             #0
    // 0xa5d220: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5d220: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5d224: b               #0xa5d0a4
    // 0xa5d228: r9 = _placeholderSpans
    //     0xa5d228: add             x9, PP, #0x37, lsl #12  ; [pp+0x37368] Field <ExtendedTextRenderBox._placeholderSpans@499234319>: late (offset: 0x7c)
    //     0xa5d22c: ldr             x9, [x9, #0x368]
    // 0xa5d230: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa5d230: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa5d234: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5d234: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5d238: b               #0xa5d0f0
  }
  _ detach(/* No info */) {
    // ** addr: 0xa68a08, size: 0x10c
    // 0xa68a08: EnterFrame
    //     0xa68a08: stp             fp, lr, [SP, #-0x10]!
    //     0xa68a0c: mov             fp, SP
    // 0xa68a10: AllocStack(0x8)
    //     0xa68a10: sub             SP, SP, #8
    // 0xa68a14: CheckStackOverflow
    //     0xa68a14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa68a18: cmp             SP, x16
    //     0xa68a1c: b.ls            #0xa68b0c
    // 0xa68a20: ldr             x0, [fp, #0x10]
    // 0xa68a24: r17 = 275
    //     0xa68a24: mov             x17, #0x113
    // 0xa68a28: ldr             w1, [x0, x17]
    // 0xa68a2c: DecompressPointer r1
    //     0xa68a2c: add             x1, x1, HEAP, lsl #32
    // 0xa68a30: stur            x1, [fp, #-8]
    // 0xa68a34: r1 = 1
    //     0xa68a34: mov             x1, #1
    // 0xa68a38: r0 = AllocateContext()
    //     0xa68a38: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa68a3c: mov             x1, x0
    // 0xa68a40: ldr             x0, [fp, #0x10]
    // 0xa68a44: StoreField: r1->field_f = r0
    //     0xa68a44: stur            w0, [x1, #0xf]
    // 0xa68a48: mov             x2, x1
    // 0xa68a4c: r1 = Function 'markNeedsPaint':.
    //     0xa68a4c: add             x1, PP, #0x55, lsl #12  ; [pp+0x55b48] AnonymousClosure: (0x6bf010), in [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::markNeedsPaint (0x6bef94)
    //     0xa68a50: ldr             x1, [x1, #0xb48]
    // 0xa68a54: r0 = AllocateClosure()
    //     0xa68a54: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa68a58: ldur            x16, [fp, #-8]
    // 0xa68a5c: stp             x0, x16, [SP, #-0x10]!
    // 0xa68a60: r0 = removeListener()
    //     0xa68a60: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa68a64: add             SP, SP, #0x10
    // 0xa68a68: ldr             x0, [fp, #0x10]
    // 0xa68a6c: LoadField: r1 = r0->field_f7
    //     0xa68a6c: ldur            w1, [x0, #0xf7]
    // 0xa68a70: DecompressPointer r1
    //     0xa68a70: add             x1, x1, HEAP, lsl #32
    // 0xa68a74: stur            x1, [fp, #-8]
    // 0xa68a78: r1 = 1
    //     0xa68a78: mov             x1, #1
    // 0xa68a7c: r0 = AllocateContext()
    //     0xa68a7c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa68a80: mov             x1, x0
    // 0xa68a84: ldr             x0, [fp, #0x10]
    // 0xa68a88: StoreField: r1->field_f = r0
    //     0xa68a88: stur            w0, [x1, #0xf]
    // 0xa68a8c: mov             x2, x1
    // 0xa68a90: r1 = Function '_showHideCursor@483409610':.
    //     0xa68a90: add             x1, PP, #0x55, lsl #12  ; [pp+0x55b50] AnonymousClosure: (0x6dfca8), in [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_showHideCursor (0x6dfbd0)
    //     0xa68a94: ldr             x1, [x1, #0xb50]
    // 0xa68a98: r0 = AllocateClosure()
    //     0xa68a98: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa68a9c: ldur            x16, [fp, #-8]
    // 0xa68aa0: stp             x0, x16, [SP, #-0x10]!
    // 0xa68aa4: r0 = removeListener()
    //     0xa68aa4: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa68aa8: add             SP, SP, #0x10
    // 0xa68aac: ldr             x16, [fp, #0x10]
    // 0xa68ab0: SaveReg r16
    //     0xa68ab0: str             x16, [SP, #-8]!
    // 0xa68ab4: r0 = detach()
    //     0xa68ab4: bl              #0xa68b14  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::detach
    // 0xa68ab8: add             SP, SP, #8
    // 0xa68abc: ldr             x0, [fp, #0x10]
    // 0xa68ac0: LoadField: r1 = r0->field_9b
    //     0xa68ac0: ldur            w1, [x0, #0x9b]
    // 0xa68ac4: DecompressPointer r1
    //     0xa68ac4: add             x1, x1, HEAP, lsl #32
    // 0xa68ac8: cmp             w1, NULL
    // 0xa68acc: b.eq            #0xa68ae0
    // 0xa68ad0: SaveReg r1
    //     0xa68ad0: str             x1, [SP, #-8]!
    // 0xa68ad4: r0 = detach()
    //     0xa68ad4: bl              #0xa68d64  ; [package:extended_text_field/src/extended_render_editable.dart] _RenderEditableCustomPaint::detach
    // 0xa68ad8: add             SP, SP, #8
    // 0xa68adc: ldr             x0, [fp, #0x10]
    // 0xa68ae0: LoadField: r1 = r0->field_9f
    //     0xa68ae0: ldur            w1, [x0, #0x9f]
    // 0xa68ae4: DecompressPointer r1
    //     0xa68ae4: add             x1, x1, HEAP, lsl #32
    // 0xa68ae8: cmp             w1, NULL
    // 0xa68aec: b.eq            #0xa68afc
    // 0xa68af0: SaveReg r1
    //     0xa68af0: str             x1, [SP, #-8]!
    // 0xa68af4: r0 = detach()
    //     0xa68af4: bl              #0xa68d64  ; [package:extended_text_field/src/extended_render_editable.dart] _RenderEditableCustomPaint::detach
    // 0xa68af8: add             SP, SP, #8
    // 0xa68afc: r0 = Null
    //     0xa68afc: mov             x0, NULL
    // 0xa68b00: LeaveFrame
    //     0xa68b00: mov             SP, fp
    //     0xa68b04: ldp             fp, lr, [SP], #0x10
    // 0xa68b08: ret
    //     0xa68b08: ret             
    // 0xa68b0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa68b0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa68b10: b               #0xa68a20
  }
  _ _snapToPhysicalPixel(/* No info */) {
    // ** addr: 0xc4f148, size: 0x20c
    // 0xc4f148: EnterFrame
    //     0xc4f148: stp             fp, lr, [SP, #-0x10]!
    //     0xc4f14c: mov             fp, SP
    // 0xc4f150: AllocStack(0x20)
    //     0xc4f150: sub             SP, SP, #0x20
    // 0xc4f154: CheckStackOverflow
    //     0xc4f154: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4f158: cmp             SP, x16
    //     0xc4f15c: b.ls            #0xc4f314
    // 0xc4f160: ldr             x16, [fp, #0x18]
    // 0xc4f164: ldr             lr, [fp, #0x10]
    // 0xc4f168: stp             lr, x16, [SP, #-0x10]!
    // 0xc4f16c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc4f16c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc4f170: r0 = localToGlobal()
    //     0xc4f170: bl              #0x64e820  ; [package:flutter/src/rendering/box.dart] RenderBox::localToGlobal
    // 0xc4f174: add             SP, SP, #0x10
    // 0xc4f178: mov             x1, x0
    // 0xc4f17c: ldr             x0, [fp, #0x18]
    // 0xc4f180: stur            x1, [fp, #-8]
    // 0xc4f184: LoadField: d0 = r0->field_cb
    //     0xc4f184: ldur            d0, [x0, #0xcb]
    // 0xc4f188: d1 = 1.000000
    //     0xc4f188: fmov            d1, #1.00000000
    // 0xc4f18c: fdiv            d2, d1, d0
    // 0xc4f190: stur            d2, [fp, #-0x18]
    // 0xc4f194: LoadField: d1 = r1->field_7
    //     0xc4f194: ldur            d1, [x1, #7]
    // 0xc4f198: stur            d1, [fp, #-0x10]
    // 0xc4f19c: mov             x0, v1.d[0]
    // 0xc4f1a0: and             x0, x0, #0x7fffffffffffffff
    // 0xc4f1a4: r17 = 9218868437227405312
    //     0xc4f1a4: mov             x17, #0x7ff0000000000000
    // 0xc4f1a8: cmp             x0, x17
    // 0xc4f1ac: b.eq            #0xc4f23c
    // 0xc4f1b0: fcmp            d1, d1
    // 0xc4f1b4: b.vs            #0xc4f234
    // 0xc4f1b8: fdiv            d0, d1, d2
    // 0xc4f1bc: stp             fp, lr, [SP, #-0x10]!
    // 0xc4f1c0: mov             fp, SP
    // 0xc4f1c4: CallRuntime_LibcRound(double) -> double
    //     0xc4f1c4: and             SP, SP, #0xfffffffffffffff0
    //     0xc4f1c8: mov             sp, SP
    //     0xc4f1cc: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0xc4f1d0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xc4f1d4: blr             x16
    //     0xc4f1d8: mov             x16, #8
    //     0xc4f1dc: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xc4f1e0: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xc4f1e4: sub             sp, x16, #1, lsl #12
    //     0xc4f1e8: mov             SP, fp
    //     0xc4f1ec: ldp             fp, lr, [SP], #0x10
    // 0xc4f1f0: fcmp            d0, d0
    // 0xc4f1f4: b.vs            #0xc4f31c
    // 0xc4f1f8: fcvtzs          x0, d0
    // 0xc4f1fc: asr             x16, x0, #0x1e
    // 0xc4f200: cmp             x16, x0, asr #63
    // 0xc4f204: b.ne            #0xc4f31c
    // 0xc4f208: lsl             x0, x0, #1
    // 0xc4f20c: r1 = LoadInt32Instr(r0)
    //     0xc4f20c: sbfx            x1, x0, #1, #0x1f
    //     0xc4f210: tbz             w0, #0, #0xc4f218
    //     0xc4f214: ldur            x1, [x0, #7]
    // 0xc4f218: scvtf           d0, x1
    // 0xc4f21c: ldur            d1, [fp, #-0x18]
    // 0xc4f220: fmul            d2, d0, d1
    // 0xc4f224: ldur            d0, [fp, #-0x10]
    // 0xc4f228: fsub            d3, d2, d0
    // 0xc4f22c: mov             v2.16b, v3.16b
    // 0xc4f230: b               #0xc4f244
    // 0xc4f234: mov             v1.16b, v2.16b
    // 0xc4f238: b               #0xc4f240
    // 0xc4f23c: mov             v1.16b, v2.16b
    // 0xc4f240: d2 = 0.000000
    //     0xc4f240: eor             v2.16b, v2.16b, v2.16b
    // 0xc4f244: ldur            x0, [fp, #-8]
    // 0xc4f248: stur            d2, [fp, #-0x20]
    // 0xc4f24c: LoadField: d3 = r0->field_f
    //     0xc4f24c: ldur            d3, [x0, #0xf]
    // 0xc4f250: stur            d3, [fp, #-0x10]
    // 0xc4f254: mov             x0, v3.d[0]
    // 0xc4f258: and             x0, x0, #0x7fffffffffffffff
    // 0xc4f25c: r17 = 9218868437227405312
    //     0xc4f25c: mov             x17, #0x7ff0000000000000
    // 0xc4f260: cmp             x0, x17
    // 0xc4f264: b.eq            #0xc4f2e8
    // 0xc4f268: fcmp            d3, d3
    // 0xc4f26c: b.vs            #0xc4f2e8
    // 0xc4f270: fdiv            d0, d3, d1
    // 0xc4f274: stp             fp, lr, [SP, #-0x10]!
    // 0xc4f278: mov             fp, SP
    // 0xc4f27c: CallRuntime_LibcRound(double) -> double
    //     0xc4f27c: and             SP, SP, #0xfffffffffffffff0
    //     0xc4f280: mov             sp, SP
    //     0xc4f284: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0xc4f288: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xc4f28c: blr             x16
    //     0xc4f290: mov             x16, #8
    //     0xc4f294: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xc4f298: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xc4f29c: sub             sp, x16, #1, lsl #12
    //     0xc4f2a0: mov             SP, fp
    //     0xc4f2a4: ldp             fp, lr, [SP], #0x10
    // 0xc4f2a8: fcmp            d0, d0
    // 0xc4f2ac: b.vs            #0xc4f338
    // 0xc4f2b0: fcvtzs          x0, d0
    // 0xc4f2b4: asr             x16, x0, #0x1e
    // 0xc4f2b8: cmp             x16, x0, asr #63
    // 0xc4f2bc: b.ne            #0xc4f338
    // 0xc4f2c0: lsl             x0, x0, #1
    // 0xc4f2c4: r1 = LoadInt32Instr(r0)
    //     0xc4f2c4: sbfx            x1, x0, #1, #0x1f
    //     0xc4f2c8: tbz             w0, #0, #0xc4f2d0
    //     0xc4f2cc: ldur            x1, [x0, #7]
    // 0xc4f2d0: scvtf           d0, x1
    // 0xc4f2d4: ldur            d1, [fp, #-0x18]
    // 0xc4f2d8: fmul            d2, d0, d1
    // 0xc4f2dc: ldur            d0, [fp, #-0x10]
    // 0xc4f2e0: fsub            d1, d2, d0
    // 0xc4f2e4: b               #0xc4f2ec
    // 0xc4f2e8: d1 = 0.000000
    //     0xc4f2e8: eor             v1.16b, v1.16b, v1.16b
    // 0xc4f2ec: ldur            d0, [fp, #-0x20]
    // 0xc4f2f0: stur            d1, [fp, #-0x10]
    // 0xc4f2f4: r0 = Offset()
    //     0xc4f2f4: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc4f2f8: ldur            d0, [fp, #-0x20]
    // 0xc4f2fc: StoreField: r0->field_7 = d0
    //     0xc4f2fc: stur            d0, [x0, #7]
    // 0xc4f300: ldur            d0, [fp, #-0x10]
    // 0xc4f304: StoreField: r0->field_f = d0
    //     0xc4f304: stur            d0, [x0, #0xf]
    // 0xc4f308: LeaveFrame
    //     0xc4f308: mov             SP, fp
    //     0xc4f30c: ldp             fp, lr, [SP], #0x10
    // 0xc4f310: ret
    //     0xc4f310: ret             
    // 0xc4f314: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4f314: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4f318: b               #0xc4f160
    // 0xc4f31c: SaveReg d0
    //     0xc4f31c: str             q0, [SP, #-0x10]!
    // 0xc4f320: r0 = 218
    //     0xc4f320: mov             x0, #0xda
    // 0xc4f324: r24 = DoubleToIntegerStub
    //     0xc4f324: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0xc4f328: LoadField: r30 = r24->field_7
    //     0xc4f328: ldur            lr, [x24, #7]
    // 0xc4f32c: blr             lr
    // 0xc4f330: RestoreReg d0
    //     0xc4f330: ldr             q0, [SP], #0x10
    // 0xc4f334: b               #0xc4f20c
    // 0xc4f338: SaveReg d0
    //     0xc4f338: str             q0, [SP, #-0x10]!
    // 0xc4f33c: r0 = 218
    //     0xc4f33c: mov             x0, #0xda
    // 0xc4f340: r24 = DoubleToIntegerStub
    //     0xc4f340: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0xc4f344: LoadField: r30 = r24->field_7
    //     0xc4f344: ldur            lr, [x24, #7]
    // 0xc4f348: blr             lr
    // 0xc4f34c: RestoreReg d0
    //     0xc4f34c: ldr             q0, [SP], #0x10
    // 0xc4f350: b               #0xc4f2c4
  }
  _ startVerticalCaretMovement(/* No info */) {
    // ** addr: 0xcc0458, size: 0xb4
    // 0xcc0458: EnterFrame
    //     0xcc0458: stp             fp, lr, [SP, #-0x10]!
    //     0xcc045c: mov             fp, SP
    // 0xcc0460: AllocStack(0x20)
    //     0xcc0460: sub             SP, SP, #0x20
    // 0xcc0464: CheckStackOverflow
    //     0xcc0464: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcc0468: cmp             SP, x16
    //     0xcc046c: b.ls            #0xcc0504
    // 0xcc0470: ldr             x0, [fp, #0x18]
    // 0xcc0474: LoadField: r1 = r0->field_eb
    //     0xcc0474: ldur            w1, [x0, #0xeb]
    // 0xcc0478: DecompressPointer r1
    //     0xcc0478: add             x1, x1, HEAP, lsl #32
    // 0xcc047c: SaveReg r1
    //     0xcc047c: str             x1, [SP, #-8]!
    // 0xcc0480: r0 = computeLineMetrics()
    //     0xcc0480: bl              #0xcc0a2c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::computeLineMetrics
    // 0xcc0484: add             SP, SP, #8
    // 0xcc0488: stur            x0, [fp, #-8]
    // 0xcc048c: ldr             x16, [fp, #0x18]
    // 0xcc0490: ldr             lr, [fp, #0x10]
    // 0xcc0494: stp             lr, x16, [SP, #-0x10]!
    // 0xcc0498: SaveReg r0
    //     0xcc0498: str             x0, [SP, #-8]!
    // 0xcc049c: r0 = _lineNumberFor()
    //     0xcc049c: bl              #0xcc070c  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_lineNumberFor
    // 0xcc04a0: add             SP, SP, #0x18
    // 0xcc04a4: LoadField: r2 = r0->field_b
    //     0xcc04a4: ldur            w2, [x0, #0xb]
    // 0xcc04a8: DecompressPointer r2
    //     0xcc04a8: add             x2, x2, HEAP, lsl #32
    // 0xcc04ac: stur            x2, [fp, #-0x18]
    // 0xcc04b0: LoadField: r3 = r0->field_f
    //     0xcc04b0: ldur            w3, [x0, #0xf]
    // 0xcc04b4: DecompressPointer r3
    //     0xcc04b4: add             x3, x3, HEAP, lsl #32
    // 0xcc04b8: stur            x3, [fp, #-0x10]
    // 0xcc04bc: r1 = <TextPosition>
    //     0xcc04bc: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f6f8] TypeArguments: <TextPosition>
    //     0xcc04c0: ldr             x1, [x1, #0x6f8]
    // 0xcc04c4: r0 = VerticalCaretMovementRun()
    //     0xcc04c4: bl              #0xcc0700  ; AllocateVerticalCaretMovementRunStub -> VerticalCaretMovementRun (size=0x2c)
    // 0xcc04c8: stur            x0, [fp, #-0x20]
    // 0xcc04cc: ldr             x16, [fp, #0x18]
    // 0xcc04d0: stp             x16, x0, [SP, #-0x10]!
    // 0xcc04d4: ldur            x16, [fp, #-8]
    // 0xcc04d8: ldr             lr, [fp, #0x10]
    // 0xcc04dc: stp             lr, x16, [SP, #-0x10]!
    // 0xcc04e0: ldur            x16, [fp, #-0x18]
    // 0xcc04e4: ldur            lr, [fp, #-0x10]
    // 0xcc04e8: stp             lr, x16, [SP, #-0x10]!
    // 0xcc04ec: r0 = VerticalCaretMovementRun._()
    //     0xcc04ec: bl              #0xcc050c  ; [package:extended_text_field/src/extended_render_editable.dart] VerticalCaretMovementRun::VerticalCaretMovementRun._
    // 0xcc04f0: add             SP, SP, #0x30
    // 0xcc04f4: ldur            x0, [fp, #-0x20]
    // 0xcc04f8: LeaveFrame
    //     0xcc04f8: mov             SP, fp
    //     0xcc04fc: ldp             fp, lr, [SP], #0x10
    // 0xcc0500: ret
    //     0xcc0500: ret             
    // 0xcc0504: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcc0504: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcc0508: b               #0xcc0470
  }
  _ _lineNumberFor(/* No info */) {
    // ** addr: 0xcc070c, size: 0x320
    // 0xcc070c: EnterFrame
    //     0xcc070c: stp             fp, lr, [SP, #-0x10]!
    //     0xcc0710: mov             fp, SP
    // 0xcc0714: AllocStack(0x50)
    //     0xcc0714: sub             SP, SP, #0x50
    // 0xcc0718: CheckStackOverflow
    //     0xcc0718: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcc071c: cmp             SP, x16
    //     0xcc0720: b.ls            #0xcc0a1c
    // 0xcc0724: ldr             x0, [fp, #0x20]
    // 0xcc0728: LoadField: r1 = r0->field_eb
    //     0xcc0728: ldur            w1, [x0, #0xeb]
    // 0xcc072c: DecompressPointer r1
    //     0xcc072c: add             x1, x1, HEAP, lsl #32
    // 0xcc0730: ldr             x16, [fp, #0x18]
    // 0xcc0734: stp             x16, x1, [SP, #-0x10]!
    // 0xcc0738: r16 = Instance_Rect
    //     0xcc0738: ldr             x16, [PP, #0x5e48]  ; [pp+0x5e48] Obj!Rect@b5ebc1
    // 0xcc073c: SaveReg r16
    //     0xcc073c: str             x16, [SP, #-8]!
    // 0xcc0740: r0 = getOffsetForCaret()
    //     0xcc0740: bl              #0x520800  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getOffsetForCaret
    // 0xcc0744: add             SP, SP, #0x18
    // 0xcc0748: mov             x2, x0
    // 0xcc074c: ldr             x1, [fp, #0x10]
    // 0xcc0750: stur            x2, [fp, #-0x20]
    // 0xcc0754: LoadField: r3 = r1->field_7
    //     0xcc0754: ldur            w3, [x1, #7]
    // 0xcc0758: DecompressPointer r3
    //     0xcc0758: add             x3, x3, HEAP, lsl #32
    // 0xcc075c: stur            x3, [fp, #-0x18]
    // 0xcc0760: LoadField: r0 = r1->field_b
    //     0xcc0760: ldur            w0, [x1, #0xb]
    // 0xcc0764: DecompressPointer r0
    //     0xcc0764: add             x0, x0, HEAP, lsl #32
    // 0xcc0768: r4 = LoadInt32Instr(r0)
    //     0xcc0768: sbfx            x4, x0, #1, #0x1f
    // 0xcc076c: stur            x4, [fp, #-0x10]
    // 0xcc0770: LoadField: d0 = r2->field_f
    //     0xcc0770: ldur            d0, [x2, #0xf]
    // 0xcc0774: stur            d0, [fp, #-0x40]
    // 0xcc0778: r5 = 0
    //     0xcc0778: mov             x5, #0
    // 0xcc077c: stur            x5, [fp, #-8]
    // 0xcc0780: CheckStackOverflow
    //     0xcc0780: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcc0784: cmp             SP, x16
    //     0xcc0788: b.ls            #0xcc0a24
    // 0xcc078c: r0 = LoadClassIdInstr(r1)
    //     0xcc078c: ldur            x0, [x1, #-1]
    //     0xcc0790: ubfx            x0, x0, #0xc, #0x14
    // 0xcc0794: SaveReg r1
    //     0xcc0794: str             x1, [SP, #-8]!
    // 0xcc0798: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xcc0798: mov             x17, #0xb8ea
    //     0xcc079c: add             lr, x0, x17
    //     0xcc07a0: ldr             lr, [x21, lr, lsl #3]
    //     0xcc07a4: blr             lr
    // 0xcc07a8: add             SP, SP, #8
    // 0xcc07ac: r1 = LoadInt32Instr(r0)
    //     0xcc07ac: sbfx            x1, x0, #1, #0x1f
    //     0xcc07b0: tbz             w0, #0, #0xcc07b8
    //     0xcc07b4: ldur            x1, [x0, #7]
    // 0xcc07b8: ldur            x2, [fp, #-0x10]
    // 0xcc07bc: cmp             x2, x1
    // 0xcc07c0: b.ne            #0xcc09fc
    // 0xcc07c4: ldr             x0, [fp, #0x10]
    // 0xcc07c8: ldur            x3, [fp, #-8]
    // 0xcc07cc: cmp             x3, x1
    // 0xcc07d0: b.lt            #0xcc08bc
    // 0xcc07d4: LoadField: r1 = r0->field_b
    //     0xcc07d4: ldur            w1, [x0, #0xb]
    // 0xcc07d8: DecompressPointer r1
    //     0xcc07d8: add             x1, x1, HEAP, lsl #32
    // 0xcc07dc: r2 = LoadInt32Instr(r1)
    //     0xcc07dc: sbfx            x2, x1, #1, #0x1f
    // 0xcc07e0: sub             x3, x2, #1
    // 0xcc07e4: tbz             x3, #0x3f, #0xcc07f0
    // 0xcc07e8: r2 = 0
    //     0xcc07e8: mov             x2, #0
    // 0xcc07ec: b               #0xcc0804
    // 0xcc07f0: cmp             x3, #0
    // 0xcc07f4: b.le            #0xcc0800
    // 0xcc07f8: mov             x2, x3
    // 0xcc07fc: b               #0xcc0804
    // 0xcc0800: r2 = 0
    //     0xcc0800: mov             x2, #0
    // 0xcc0804: ldur            x4, [fp, #-0x20]
    // 0xcc0808: stur            x2, [fp, #-0x28]
    // 0xcc080c: LoadField: d0 = r4->field_7
    //     0xcc080c: ldur            d0, [x4, #7]
    // 0xcc0810: stur            d0, [fp, #-0x48]
    // 0xcc0814: cbz             w1, #0xcc0850
    // 0xcc0818: SaveReg r0
    //     0xcc0818: str             x0, [SP, #-8]!
    // 0xcc081c: r0 = last()
    //     0xcc081c: bl              #0x621d20  ; [dart:core] _GrowableList::last
    // 0xcc0820: add             SP, SP, #8
    // 0xcc0824: LoadField: d0 = r0->field_3b
    //     0xcc0824: ldur            d0, [x0, #0x3b]
    // 0xcc0828: stur            d0, [fp, #-0x50]
    // 0xcc082c: ldr             x16, [fp, #0x10]
    // 0xcc0830: SaveReg r16
    //     0xcc0830: str             x16, [SP, #-8]!
    // 0xcc0834: r0 = last()
    //     0xcc0834: bl              #0x621d20  ; [dart:core] _GrowableList::last
    // 0xcc0838: add             SP, SP, #8
    // 0xcc083c: LoadField: d0 = r0->field_13
    //     0xcc083c: ldur            d0, [x0, #0x13]
    // 0xcc0840: ldur            d1, [fp, #-0x50]
    // 0xcc0844: fadd            d2, d1, d0
    // 0xcc0848: mov             v1.16b, v2.16b
    // 0xcc084c: b               #0xcc0854
    // 0xcc0850: d1 = 0.000000
    //     0xcc0850: eor             v1.16b, v1.16b, v1.16b
    // 0xcc0854: ldur            x0, [fp, #-0x28]
    // 0xcc0858: ldur            d0, [fp, #-0x48]
    // 0xcc085c: stur            d1, [fp, #-0x50]
    // 0xcc0860: r0 = Offset()
    //     0xcc0860: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xcc0864: ldur            d0, [fp, #-0x48]
    // 0xcc0868: stur            x0, [fp, #-0x30]
    // 0xcc086c: StoreField: r0->field_7 = d0
    //     0xcc086c: stur            d0, [x0, #7]
    // 0xcc0870: ldur            d0, [fp, #-0x50]
    // 0xcc0874: StoreField: r0->field_f = d0
    //     0xcc0874: stur            d0, [x0, #0xf]
    // 0xcc0878: r1 = <int, Offset>
    //     0xcc0878: add             x1, PP, #0x21, lsl #12  ; [pp+0x21490] TypeArguments: <int, Offset>
    //     0xcc087c: ldr             x1, [x1, #0x490]
    // 0xcc0880: r0 = MapEntry()
    //     0xcc0880: bl              #0x52a1c0  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0xcc0884: mov             x3, x0
    // 0xcc0888: ldur            x2, [fp, #-0x28]
    // 0xcc088c: r0 = BoxInt64Instr(r2)
    //     0xcc088c: sbfiz           x0, x2, #1, #0x1f
    //     0xcc0890: cmp             x2, x0, asr #1
    //     0xcc0894: b.eq            #0xcc08a0
    //     0xcc0898: bl              #0xd69bb8
    //     0xcc089c: stur            x2, [x0, #7]
    // 0xcc08a0: StoreField: r3->field_b = r0
    //     0xcc08a0: stur            w0, [x3, #0xb]
    // 0xcc08a4: ldur            x0, [fp, #-0x30]
    // 0xcc08a8: StoreField: r3->field_f = r0
    //     0xcc08a8: stur            w0, [x3, #0xf]
    // 0xcc08ac: mov             x0, x3
    // 0xcc08b0: LeaveFrame
    //     0xcc08b0: mov             SP, fp
    //     0xcc08b4: ldp             fp, lr, [SP], #0x10
    // 0xcc08b8: ret
    //     0xcc08b8: ret             
    // 0xcc08bc: mov             x5, x0
    // 0xcc08c0: ldur            x4, [fp, #-0x20]
    // 0xcc08c4: r0 = BoxInt64Instr(r3)
    //     0xcc08c4: sbfiz           x0, x3, #1, #0x1f
    //     0xcc08c8: cmp             x3, x0, asr #1
    //     0xcc08cc: b.eq            #0xcc08d8
    //     0xcc08d0: bl              #0xd69bb8
    //     0xcc08d4: stur            x3, [x0, #7]
    // 0xcc08d8: r1 = LoadClassIdInstr(r5)
    //     0xcc08d8: ldur            x1, [x5, #-1]
    //     0xcc08dc: ubfx            x1, x1, #0xc, #0x14
    // 0xcc08e0: stp             x0, x5, [SP, #-0x10]!
    // 0xcc08e4: mov             x0, x1
    // 0xcc08e8: r0 = GDT[cid_x0 + 0xd175]()
    //     0xcc08e8: mov             x17, #0xd175
    //     0xcc08ec: add             lr, x0, x17
    //     0xcc08f0: ldr             lr, [x21, lr, lsl #3]
    //     0xcc08f4: blr             lr
    // 0xcc08f8: add             SP, SP, #0x10
    // 0xcc08fc: mov             x3, x0
    // 0xcc0900: ldur            x0, [fp, #-8]
    // 0xcc0904: stur            x3, [fp, #-0x30]
    // 0xcc0908: add             x5, x0, #1
    // 0xcc090c: stur            x5, [fp, #-0x28]
    // 0xcc0910: cmp             w3, NULL
    // 0xcc0914: b.ne            #0xcc0948
    // 0xcc0918: mov             x0, x3
    // 0xcc091c: ldur            x2, [fp, #-0x18]
    // 0xcc0920: r1 = Null
    //     0xcc0920: mov             x1, NULL
    // 0xcc0924: cmp             w2, NULL
    // 0xcc0928: b.eq            #0xcc0948
    // 0xcc092c: LoadField: r4 = r2->field_17
    //     0xcc092c: ldur            w4, [x2, #0x17]
    // 0xcc0930: DecompressPointer r4
    //     0xcc0930: add             x4, x4, HEAP, lsl #32
    // 0xcc0934: r8 = X0
    //     0xcc0934: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xcc0938: LoadField: r9 = r4->field_7
    //     0xcc0938: ldur            x9, [x4, #7]
    // 0xcc093c: r3 = Null
    //     0xcc093c: add             x3, PP, #0x55, lsl #12  ; [pp+0x55a58] Null
    //     0xcc0940: ldr             x3, [x3, #0xa58]
    // 0xcc0944: blr             x9
    // 0xcc0948: ldur            d0, [fp, #-0x40]
    // 0xcc094c: ldur            x0, [fp, #-0x30]
    // 0xcc0950: LoadField: d1 = r0->field_3b
    //     0xcc0950: ldur            d1, [x0, #0x3b]
    // 0xcc0954: stur            d1, [fp, #-0x50]
    // 0xcc0958: LoadField: d2 = r0->field_13
    //     0xcc0958: ldur            d2, [x0, #0x13]
    // 0xcc095c: fadd            d3, d1, d2
    // 0xcc0960: fcmp            d3, d0
    // 0xcc0964: b.vs            #0xcc09e0
    // 0xcc0968: b.le            #0xcc09e0
    // 0xcc096c: ldur            x1, [fp, #-0x20]
    // 0xcc0970: LoadField: r2 = r0->field_43
    //     0xcc0970: ldur            x2, [x0, #0x43]
    // 0xcc0974: stur            x2, [fp, #-8]
    // 0xcc0978: LoadField: d0 = r1->field_7
    //     0xcc0978: ldur            d0, [x1, #7]
    // 0xcc097c: stur            d0, [fp, #-0x48]
    // 0xcc0980: r0 = Offset()
    //     0xcc0980: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xcc0984: mov             x2, x0
    // 0xcc0988: ldur            d0, [fp, #-0x48]
    // 0xcc098c: stur            x2, [fp, #-0x38]
    // 0xcc0990: StoreField: r2->field_7 = d0
    //     0xcc0990: stur            d0, [x2, #7]
    // 0xcc0994: ldur            d0, [fp, #-0x50]
    // 0xcc0998: StoreField: r2->field_f = d0
    //     0xcc0998: stur            d0, [x2, #0xf]
    // 0xcc099c: ldur            x3, [fp, #-8]
    // 0xcc09a0: r0 = BoxInt64Instr(r3)
    //     0xcc09a0: sbfiz           x0, x3, #1, #0x1f
    //     0xcc09a4: cmp             x3, x0, asr #1
    //     0xcc09a8: b.eq            #0xcc09b4
    //     0xcc09ac: bl              #0xd69bb8
    //     0xcc09b0: stur            x3, [x0, #7]
    // 0xcc09b4: r1 = <int, Offset>
    //     0xcc09b4: add             x1, PP, #0x21, lsl #12  ; [pp+0x21490] TypeArguments: <int, Offset>
    //     0xcc09b8: ldr             x1, [x1, #0x490]
    // 0xcc09bc: stur            x0, [fp, #-0x30]
    // 0xcc09c0: r0 = MapEntry()
    //     0xcc09c0: bl              #0x52a1c0  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0xcc09c4: ldur            x2, [fp, #-0x30]
    // 0xcc09c8: StoreField: r0->field_b = r2
    //     0xcc09c8: stur            w2, [x0, #0xb]
    // 0xcc09cc: ldur            x2, [fp, #-0x38]
    // 0xcc09d0: StoreField: r0->field_f = r2
    //     0xcc09d0: stur            w2, [x0, #0xf]
    // 0xcc09d4: LeaveFrame
    //     0xcc09d4: mov             SP, fp
    //     0xcc09d8: ldp             fp, lr, [SP], #0x10
    // 0xcc09dc: ret
    //     0xcc09dc: ret             
    // 0xcc09e0: ldur            x1, [fp, #-0x20]
    // 0xcc09e4: ldur            x5, [fp, #-0x28]
    // 0xcc09e8: mov             x2, x1
    // 0xcc09ec: ldr             x1, [fp, #0x10]
    // 0xcc09f0: ldur            x3, [fp, #-0x18]
    // 0xcc09f4: ldur            x4, [fp, #-0x10]
    // 0xcc09f8: b               #0xcc077c
    // 0xcc09fc: ldr             x0, [fp, #0x10]
    // 0xcc0a00: r0 = ConcurrentModificationError()
    //     0xcc0a00: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xcc0a04: mov             x1, x0
    // 0xcc0a08: ldr             x0, [fp, #0x10]
    // 0xcc0a0c: StoreField: r1->field_b = r0
    //     0xcc0a0c: stur            w0, [x1, #0xb]
    // 0xcc0a10: mov             x0, x1
    // 0xcc0a14: r0 = Throw()
    //     0xcc0a14: bl              #0xd67e38  ; ThrowStub
    // 0xcc0a18: brk             #0
    // 0xcc0a1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcc0a1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcc0a20: b               #0xcc0724
    // 0xcc0a24: r0 = StackOverflowSharedWithFPURegs()
    //     0xcc0a24: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcc0a28: b               #0xcc078c
  }
  _ calculateBoundedFloatingCursorOffset(/* No info */) {
    // ** addr: 0xcd11c4, size: 0x824
    // 0xcd11c4: EnterFrame
    //     0xcd11c4: stp             fp, lr, [SP, #-0x10]!
    //     0xcd11c8: mov             fp, SP
    // 0xcd11cc: AllocStack(0x48)
    //     0xcd11cc: sub             SP, SP, #0x48
    // 0xcd11d0: r0 = Instance_EdgeInsets
    //     0xcd11d0: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f998] Obj!EdgeInsets@b35b41
    //     0xcd11d4: ldr             x0, [x0, #0x998]
    // 0xcd11d8: CheckStackOverflow
    //     0xcd11d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd11dc: cmp             SP, x16
    //     0xcd11e0: b.ls            #0xcd1984
    // 0xcd11e4: LoadField: d0 = r0->field_f
    //     0xcd11e4: ldur            d0, [x0, #0xf]
    // 0xcd11e8: fneg            d1, d0
    // 0xcd11ec: ldr             x1, [fp, #0x18]
    // 0xcd11f0: stur            d1, [fp, #-0x10]
    // 0xcd11f4: LoadField: r2 = r1->field_eb
    //     0xcd11f4: ldur            w2, [x1, #0xeb]
    // 0xcd11f8: DecompressPointer r2
    //     0xcd11f8: add             x2, x2, HEAP, lsl #32
    // 0xcd11fc: stur            x2, [fp, #-8]
    // 0xcd1200: LoadField: r3 = r2->field_7
    //     0xcd1200: ldur            w3, [x2, #7]
    // 0xcd1204: DecompressPointer r3
    //     0xcd1204: add             x3, x3, HEAP, lsl #32
    // 0xcd1208: cmp             w3, NULL
    // 0xcd120c: b.eq            #0xcd198c
    // 0xcd1210: SaveReg r3
    //     0xcd1210: str             x3, [SP, #-8]!
    // 0xcd1214: r0 = height()
    //     0xcd1214: bl              #0x51a4dc  ; [dart:ui] Paragraph::height
    // 0xcd1218: add             SP, SP, #8
    // 0xcd121c: stp             fp, lr, [SP, #-0x10]!
    // 0xcd1220: mov             fp, SP
    // 0xcd1224: CallRuntime_LibcCeil(double) -> double
    //     0xcd1224: and             SP, SP, #0xfffffffffffffff0
    //     0xcd1228: mov             sp, SP
    //     0xcd122c: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0xcd1230: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcd1234: blr             x16
    //     0xcd1238: mov             x16, #8
    //     0xcd123c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcd1240: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xcd1244: sub             sp, x16, #1, lsl #12
    //     0xcd1248: mov             SP, fp
    //     0xcd124c: ldp             fp, lr, [SP], #0x10
    // 0xcd1250: stur            d0, [fp, #-0x18]
    // 0xcd1254: ldur            x16, [fp, #-8]
    // 0xcd1258: SaveReg r16
    //     0xcd1258: str             x16, [SP, #-8]!
    // 0xcd125c: r0 = preferredLineHeight()
    //     0xcd125c: bl              #0x51a438  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0xcd1260: add             SP, SP, #8
    // 0xcd1264: mov             v1.16b, v0.16b
    // 0xcd1268: ldur            d0, [fp, #-0x18]
    // 0xcd126c: fsub            d2, d0, d1
    // 0xcd1270: r0 = Instance_EdgeInsets
    //     0xcd1270: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f998] Obj!EdgeInsets@b35b41
    //     0xcd1274: ldr             x0, [x0, #0x998]
    // 0xcd1278: LoadField: d0 = r0->field_1f
    //     0xcd1278: ldur            d0, [x0, #0x1f]
    // 0xcd127c: fadd            d1, d2, d0
    // 0xcd1280: stur            d1, [fp, #-0x20]
    // 0xcd1284: LoadField: d0 = r0->field_7
    //     0xcd1284: ldur            d0, [x0, #7]
    // 0xcd1288: fneg            d2, d0
    // 0xcd128c: ldur            x1, [fp, #-8]
    // 0xcd1290: stur            d2, [fp, #-0x18]
    // 0xcd1294: LoadField: r2 = r1->field_7
    //     0xcd1294: ldur            w2, [x1, #7]
    // 0xcd1298: DecompressPointer r2
    //     0xcd1298: add             x2, x2, HEAP, lsl #32
    // 0xcd129c: cmp             w2, NULL
    // 0xcd12a0: b.eq            #0xcd1990
    // 0xcd12a4: SaveReg r2
    //     0xcd12a4: str             x2, [SP, #-8]!
    // 0xcd12a8: r0 = width()
    //     0xcd12a8: bl              #0x520ee4  ; [dart:ui] Paragraph::width
    // 0xcd12ac: add             SP, SP, #8
    // 0xcd12b0: stp             fp, lr, [SP, #-0x10]!
    // 0xcd12b4: mov             fp, SP
    // 0xcd12b8: CallRuntime_LibcCeil(double) -> double
    //     0xcd12b8: and             SP, SP, #0xfffffffffffffff0
    //     0xcd12bc: mov             sp, SP
    //     0xcd12c0: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0xcd12c4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcd12c8: blr             x16
    //     0xcd12cc: mov             x16, #8
    //     0xcd12d0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcd12d4: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xcd12d8: sub             sp, x16, #1, lsl #12
    //     0xcd12dc: mov             SP, fp
    //     0xcd12e0: ldp             fp, lr, [SP], #0x10
    // 0xcd12e4: r0 = Instance_EdgeInsets
    //     0xcd12e4: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f998] Obj!EdgeInsets@b35b41
    //     0xcd12e8: ldr             x0, [x0, #0x998]
    // 0xcd12ec: LoadField: d1 = r0->field_17
    //     0xcd12ec: ldur            d1, [x0, #0x17]
    // 0xcd12f0: fadd            d2, d0, d1
    // 0xcd12f4: ldr             x0, [fp, #0x18]
    // 0xcd12f8: stur            d2, [fp, #-0x28]
    // 0xcd12fc: r17 = 347
    //     0xcd12fc: mov             x17, #0x15b
    // 0xcd1300: ldr             w1, [x0, x17]
    // 0xcd1304: DecompressPointer r1
    //     0xcd1304: add             x1, x1, HEAP, lsl #32
    // 0xcd1308: cmp             w1, NULL
    // 0xcd130c: b.eq            #0xcd1328
    // 0xcd1310: ldr             x16, [fp, #0x10]
    // 0xcd1314: stp             x1, x16, [SP, #-0x10]!
    // 0xcd1318: r0 = -()
    //     0xcd1318: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xcd131c: add             SP, SP, #0x10
    // 0xcd1320: mov             x1, x0
    // 0xcd1324: b               #0xcd132c
    // 0xcd1328: r1 = Instance_Offset
    //     0xcd1328: ldr             x1, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xcd132c: ldr             x0, [fp, #0x18]
    // 0xcd1330: stur            x1, [fp, #-8]
    // 0xcd1334: r17 = 351
    //     0xcd1334: mov             x17, #0x15f
    // 0xcd1338: ldr             w2, [x0, x17]
    // 0xcd133c: DecompressPointer r2
    //     0xcd133c: add             x2, x2, HEAP, lsl #32
    // 0xcd1340: tbnz            w2, #4, #0xcd13d4
    // 0xcd1344: d0 = 0.000000
    //     0xcd1344: eor             v0.16b, v0.16b, v0.16b
    // 0xcd1348: LoadField: d1 = r1->field_7
    //     0xcd1348: ldur            d1, [x1, #7]
    // 0xcd134c: fcmp            d1, d0
    // 0xcd1350: b.vs            #0xcd13c8
    // 0xcd1354: b.le            #0xcd13c8
    // 0xcd1358: ldr             x2, [fp, #0x10]
    // 0xcd135c: ldur            d1, [fp, #-0x18]
    // 0xcd1360: LoadField: d2 = r2->field_7
    //     0xcd1360: ldur            d2, [x2, #7]
    // 0xcd1364: fsub            d3, d2, d1
    // 0xcd1368: stur            d3, [fp, #-0x38]
    // 0xcd136c: r17 = 343
    //     0xcd136c: mov             x17, #0x157
    // 0xcd1370: ldr             w3, [x0, x17]
    // 0xcd1374: DecompressPointer r3
    //     0xcd1374: add             x3, x3, HEAP, lsl #32
    // 0xcd1378: LoadField: d2 = r3->field_f
    //     0xcd1378: ldur            d2, [x3, #0xf]
    // 0xcd137c: stur            d2, [fp, #-0x30]
    // 0xcd1380: r0 = Offset()
    //     0xcd1380: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xcd1384: ldur            d0, [fp, #-0x38]
    // 0xcd1388: StoreField: r0->field_7 = d0
    //     0xcd1388: stur            d0, [x0, #7]
    // 0xcd138c: ldur            d0, [fp, #-0x30]
    // 0xcd1390: StoreField: r0->field_f = d0
    //     0xcd1390: stur            d0, [x0, #0xf]
    // 0xcd1394: ldr             x1, [fp, #0x18]
    // 0xcd1398: r17 = 343
    //     0xcd1398: mov             x17, #0x157
    // 0xcd139c: str             w0, [x1, x17]
    // 0xcd13a0: WriteBarrierInstr(obj = r1, val = r0)
    //     0xcd13a0: ldurb           w16, [x1, #-1]
    //     0xcd13a4: ldurb           w17, [x0, #-1]
    //     0xcd13a8: and             x16, x17, x16, lsr #2
    //     0xcd13ac: tst             x16, HEAP, lsr #32
    //     0xcd13b0: b.eq            #0xcd13b8
    //     0xcd13b4: bl              #0xd6826c
    // 0xcd13b8: r0 = false
    //     0xcd13b8: add             x0, NULL, #0x30  ; false
    // 0xcd13bc: add             x16, x1, #0x15f
    // 0xcd13c0: str             w0, [x16]
    // 0xcd13c4: b               #0xcd1470
    // 0xcd13c8: mov             x1, x0
    // 0xcd13cc: r0 = false
    //     0xcd13cc: add             x0, NULL, #0x30  ; false
    // 0xcd13d0: b               #0xcd13dc
    // 0xcd13d4: mov             x1, x0
    // 0xcd13d8: r0 = false
    //     0xcd13d8: add             x0, NULL, #0x30  ; false
    // 0xcd13dc: r17 = 355
    //     0xcd13dc: mov             x17, #0x163
    // 0xcd13e0: ldr             w2, [x1, x17]
    // 0xcd13e4: DecompressPointer r2
    //     0xcd13e4: add             x2, x2, HEAP, lsl #32
    // 0xcd13e8: tbnz            w2, #4, #0xcd1470
    // 0xcd13ec: ldur            x2, [fp, #-8]
    // 0xcd13f0: d0 = 0.000000
    //     0xcd13f0: eor             v0.16b, v0.16b, v0.16b
    // 0xcd13f4: LoadField: d1 = r2->field_7
    //     0xcd13f4: ldur            d1, [x2, #7]
    // 0xcd13f8: fcmp            d1, d0
    // 0xcd13fc: b.vs            #0xcd1470
    // 0xcd1400: b.ge            #0xcd1470
    // 0xcd1404: ldr             x3, [fp, #0x10]
    // 0xcd1408: ldur            d1, [fp, #-0x28]
    // 0xcd140c: LoadField: d2 = r3->field_7
    //     0xcd140c: ldur            d2, [x3, #7]
    // 0xcd1410: fsub            d3, d2, d1
    // 0xcd1414: stur            d3, [fp, #-0x38]
    // 0xcd1418: r17 = 343
    //     0xcd1418: mov             x17, #0x157
    // 0xcd141c: ldr             w4, [x1, x17]
    // 0xcd1420: DecompressPointer r4
    //     0xcd1420: add             x4, x4, HEAP, lsl #32
    // 0xcd1424: LoadField: d2 = r4->field_f
    //     0xcd1424: ldur            d2, [x4, #0xf]
    // 0xcd1428: stur            d2, [fp, #-0x30]
    // 0xcd142c: r0 = Offset()
    //     0xcd142c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xcd1430: ldur            d0, [fp, #-0x38]
    // 0xcd1434: StoreField: r0->field_7 = d0
    //     0xcd1434: stur            d0, [x0, #7]
    // 0xcd1438: ldur            d0, [fp, #-0x30]
    // 0xcd143c: StoreField: r0->field_f = d0
    //     0xcd143c: stur            d0, [x0, #0xf]
    // 0xcd1440: ldr             x1, [fp, #0x18]
    // 0xcd1444: r17 = 343
    //     0xcd1444: mov             x17, #0x157
    // 0xcd1448: str             w0, [x1, x17]
    // 0xcd144c: WriteBarrierInstr(obj = r1, val = r0)
    //     0xcd144c: ldurb           w16, [x1, #-1]
    //     0xcd1450: ldurb           w17, [x0, #-1]
    //     0xcd1454: and             x16, x17, x16, lsr #2
    //     0xcd1458: tst             x16, HEAP, lsr #32
    //     0xcd145c: b.eq            #0xcd1464
    //     0xcd1460: bl              #0xd6826c
    // 0xcd1464: r0 = false
    //     0xcd1464: add             x0, NULL, #0x30  ; false
    // 0xcd1468: add             x16, x1, #0x163
    // 0xcd146c: str             w0, [x16]
    // 0xcd1470: r17 = 359
    //     0xcd1470: mov             x17, #0x167
    // 0xcd1474: ldr             w2, [x1, x17]
    // 0xcd1478: DecompressPointer r2
    //     0xcd1478: add             x2, x2, HEAP, lsl #32
    // 0xcd147c: tbnz            w2, #4, #0xcd1508
    // 0xcd1480: ldur            x2, [fp, #-8]
    // 0xcd1484: d0 = 0.000000
    //     0xcd1484: eor             v0.16b, v0.16b, v0.16b
    // 0xcd1488: LoadField: d1 = r2->field_f
    //     0xcd1488: ldur            d1, [x2, #0xf]
    // 0xcd148c: fcmp            d1, d0
    // 0xcd1490: b.vs            #0xcd1508
    // 0xcd1494: b.le            #0xcd1508
    // 0xcd1498: ldr             x3, [fp, #0x10]
    // 0xcd149c: ldur            d1, [fp, #-0x10]
    // 0xcd14a0: r17 = 343
    //     0xcd14a0: mov             x17, #0x157
    // 0xcd14a4: ldr             w4, [x1, x17]
    // 0xcd14a8: DecompressPointer r4
    //     0xcd14a8: add             x4, x4, HEAP, lsl #32
    // 0xcd14ac: LoadField: d2 = r4->field_7
    //     0xcd14ac: ldur            d2, [x4, #7]
    // 0xcd14b0: stur            d2, [fp, #-0x38]
    // 0xcd14b4: LoadField: d3 = r3->field_f
    //     0xcd14b4: ldur            d3, [x3, #0xf]
    // 0xcd14b8: fsub            d4, d3, d1
    // 0xcd14bc: stur            d4, [fp, #-0x30]
    // 0xcd14c0: r0 = Offset()
    //     0xcd14c0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xcd14c4: ldur            d0, [fp, #-0x38]
    // 0xcd14c8: StoreField: r0->field_7 = d0
    //     0xcd14c8: stur            d0, [x0, #7]
    // 0xcd14cc: ldur            d0, [fp, #-0x30]
    // 0xcd14d0: StoreField: r0->field_f = d0
    //     0xcd14d0: stur            d0, [x0, #0xf]
    // 0xcd14d4: ldr             x1, [fp, #0x18]
    // 0xcd14d8: r17 = 343
    //     0xcd14d8: mov             x17, #0x157
    // 0xcd14dc: str             w0, [x1, x17]
    // 0xcd14e0: WriteBarrierInstr(obj = r1, val = r0)
    //     0xcd14e0: ldurb           w16, [x1, #-1]
    //     0xcd14e4: ldurb           w17, [x0, #-1]
    //     0xcd14e8: and             x16, x17, x16, lsr #2
    //     0xcd14ec: tst             x16, HEAP, lsr #32
    //     0xcd14f0: b.eq            #0xcd14f8
    //     0xcd14f4: bl              #0xd6826c
    // 0xcd14f8: r0 = false
    //     0xcd14f8: add             x0, NULL, #0x30  ; false
    // 0xcd14fc: add             x16, x1, #0x167
    // 0xcd1500: str             w0, [x16]
    // 0xcd1504: b               #0xcd159c
    // 0xcd1508: r17 = 363
    //     0xcd1508: mov             x17, #0x16b
    // 0xcd150c: ldr             w2, [x1, x17]
    // 0xcd1510: DecompressPointer r2
    //     0xcd1510: add             x2, x2, HEAP, lsl #32
    // 0xcd1514: tbnz            w2, #4, #0xcd159c
    // 0xcd1518: ldur            x2, [fp, #-8]
    // 0xcd151c: d0 = 0.000000
    //     0xcd151c: eor             v0.16b, v0.16b, v0.16b
    // 0xcd1520: LoadField: d1 = r2->field_f
    //     0xcd1520: ldur            d1, [x2, #0xf]
    // 0xcd1524: fcmp            d1, d0
    // 0xcd1528: b.vs            #0xcd159c
    // 0xcd152c: b.ge            #0xcd159c
    // 0xcd1530: ldr             x3, [fp, #0x10]
    // 0xcd1534: ldur            d1, [fp, #-0x20]
    // 0xcd1538: r17 = 343
    //     0xcd1538: mov             x17, #0x157
    // 0xcd153c: ldr             w4, [x1, x17]
    // 0xcd1540: DecompressPointer r4
    //     0xcd1540: add             x4, x4, HEAP, lsl #32
    // 0xcd1544: LoadField: d2 = r4->field_7
    //     0xcd1544: ldur            d2, [x4, #7]
    // 0xcd1548: stur            d2, [fp, #-0x38]
    // 0xcd154c: LoadField: d3 = r3->field_f
    //     0xcd154c: ldur            d3, [x3, #0xf]
    // 0xcd1550: fsub            d4, d3, d1
    // 0xcd1554: stur            d4, [fp, #-0x30]
    // 0xcd1558: r0 = Offset()
    //     0xcd1558: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xcd155c: ldur            d0, [fp, #-0x38]
    // 0xcd1560: StoreField: r0->field_7 = d0
    //     0xcd1560: stur            d0, [x0, #7]
    // 0xcd1564: ldur            d0, [fp, #-0x30]
    // 0xcd1568: StoreField: r0->field_f = d0
    //     0xcd1568: stur            d0, [x0, #0xf]
    // 0xcd156c: ldr             x1, [fp, #0x18]
    // 0xcd1570: r17 = 343
    //     0xcd1570: mov             x17, #0x157
    // 0xcd1574: str             w0, [x1, x17]
    // 0xcd1578: WriteBarrierInstr(obj = r1, val = r0)
    //     0xcd1578: ldurb           w16, [x1, #-1]
    //     0xcd157c: ldurb           w17, [x0, #-1]
    //     0xcd1580: and             x16, x17, x16, lsr #2
    //     0xcd1584: tst             x16, HEAP, lsr #32
    //     0xcd1588: b.eq            #0xcd1590
    //     0xcd158c: bl              #0xd6826c
    // 0xcd1590: r0 = false
    //     0xcd1590: add             x0, NULL, #0x30  ; false
    // 0xcd1594: add             x16, x1, #0x16b
    // 0xcd1598: str             w0, [x16]
    // 0xcd159c: ldr             x0, [fp, #0x10]
    // 0xcd15a0: ldur            d0, [fp, #-0x18]
    // 0xcd15a4: LoadField: d1 = r0->field_7
    //     0xcd15a4: ldur            d1, [x0, #7]
    // 0xcd15a8: r17 = 343
    //     0xcd15a8: mov             x17, #0x157
    // 0xcd15ac: ldr             w2, [x1, x17]
    // 0xcd15b0: DecompressPointer r2
    //     0xcd15b0: add             x2, x2, HEAP, lsl #32
    // 0xcd15b4: LoadField: d2 = r2->field_7
    //     0xcd15b4: ldur            d2, [x2, #7]
    // 0xcd15b8: fsub            d3, d1, d2
    // 0xcd15bc: stur            d3, [fp, #-0x40]
    // 0xcd15c0: LoadField: d1 = r0->field_f
    //     0xcd15c0: ldur            d1, [x0, #0xf]
    // 0xcd15c4: LoadField: d2 = r2->field_f
    //     0xcd15c4: ldur            d2, [x2, #0xf]
    // 0xcd15c8: fsub            d4, d1, d2
    // 0xcd15cc: stur            d4, [fp, #-0x38]
    // 0xcd15d0: fcmp            d3, d0
    // 0xcd15d4: b.vs            #0xcd15e8
    // 0xcd15d8: b.le            #0xcd15e8
    // 0xcd15dc: mov             v5.16b, v3.16b
    // 0xcd15e0: d1 = 0.000000
    //     0xcd15e0: eor             v1.16b, v1.16b, v1.16b
    // 0xcd15e4: b               #0xcd1630
    // 0xcd15e8: fcmp            d3, d0
    // 0xcd15ec: b.vs            #0xcd1600
    // 0xcd15f0: b.ge            #0xcd1600
    // 0xcd15f4: mov             v5.16b, v0.16b
    // 0xcd15f8: d1 = 0.000000
    //     0xcd15f8: eor             v1.16b, v1.16b, v1.16b
    // 0xcd15fc: b               #0xcd1630
    // 0xcd1600: d1 = 0.000000
    //     0xcd1600: eor             v1.16b, v1.16b, v1.16b
    // 0xcd1604: fcmp            d3, d1
    // 0xcd1608: b.vs            #0xcd161c
    // 0xcd160c: b.ne            #0xcd161c
    // 0xcd1610: fadd            d2, d3, d0
    // 0xcd1614: mov             v5.16b, v2.16b
    // 0xcd1618: b               #0xcd1630
    // 0xcd161c: fcmp            d0, d0
    // 0xcd1620: b.vc            #0xcd162c
    // 0xcd1624: mov             v5.16b, v0.16b
    // 0xcd1628: b               #0xcd1630
    // 0xcd162c: mov             v5.16b, v3.16b
    // 0xcd1630: ldur            d2, [fp, #-0x28]
    // 0xcd1634: stur            d5, [fp, #-0x30]
    // 0xcd1638: fcmp            d5, d2
    // 0xcd163c: b.vs            #0xcd1654
    // 0xcd1640: b.le            #0xcd1654
    // 0xcd1644: mov             v3.16b, v2.16b
    // 0xcd1648: mov             v0.16b, v2.16b
    // 0xcd164c: mov             v1.16b, v4.16b
    // 0xcd1650: b               #0xcd170c
    // 0xcd1654: fcmp            d5, d2
    // 0xcd1658: b.vs            #0xcd1670
    // 0xcd165c: b.ge            #0xcd1670
    // 0xcd1660: mov             v3.16b, v5.16b
    // 0xcd1664: mov             v0.16b, v2.16b
    // 0xcd1668: mov             v1.16b, v4.16b
    // 0xcd166c: b               #0xcd170c
    // 0xcd1670: fcmp            d5, d1
    // 0xcd1674: b.vs            #0xcd167c
    // 0xcd1678: b.eq            #0xcd1684
    // 0xcd167c: r2 = false
    //     0xcd167c: add             x2, NULL, #0x30  ; false
    // 0xcd1680: b               #0xcd1688
    // 0xcd1684: r2 = true
    //     0xcd1684: add             x2, NULL, #0x20  ; true
    // 0xcd1688: tbnz            w2, #4, #0xcd16a8
    // 0xcd168c: fadd            d6, d5, d2
    // 0xcd1690: fmul            d7, d6, d5
    // 0xcd1694: fmul            d5, d7, d2
    // 0xcd1698: mov             v3.16b, v5.16b
    // 0xcd169c: mov             v0.16b, v2.16b
    // 0xcd16a0: mov             v1.16b, v4.16b
    // 0xcd16a4: b               #0xcd170c
    // 0xcd16a8: tbnz            w2, #4, #0xcd16ec
    // 0xcd16ac: r2 = inline_Allocate_Double()
    //     0xcd16ac: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xcd16b0: add             x2, x2, #0x10
    //     0xcd16b4: cmp             x3, x2
    //     0xcd16b8: b.ls            #0xcd1994
    //     0xcd16bc: str             x2, [THR, #0x60]  ; THR::top
    //     0xcd16c0: sub             x2, x2, #0xf
    //     0xcd16c4: mov             x3, #0xd108
    //     0xcd16c8: movk            x3, #3, lsl #16
    //     0xcd16cc: stur            x3, [x2, #-1]
    // 0xcd16d0: StoreField: r2->field_7 = d2
    //     0xcd16d0: stur            d2, [x2, #7]
    // 0xcd16d4: SaveReg r2
    //     0xcd16d4: str             x2, [SP, #-8]!
    // 0xcd16d8: r0 = isNegative()
    //     0xcd16d8: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0xcd16dc: add             SP, SP, #8
    // 0xcd16e0: tbnz            w0, #4, #0xcd16ec
    // 0xcd16e4: ldur            d0, [fp, #-0x28]
    // 0xcd16e8: b               #0xcd16f8
    // 0xcd16ec: ldur            d0, [fp, #-0x28]
    // 0xcd16f0: fcmp            d0, d0
    // 0xcd16f4: b.vc            #0xcd1704
    // 0xcd16f8: mov             v3.16b, v0.16b
    // 0xcd16fc: ldur            d1, [fp, #-0x38]
    // 0xcd1700: b               #0xcd170c
    // 0xcd1704: ldur            d3, [fp, #-0x30]
    // 0xcd1708: ldur            d1, [fp, #-0x38]
    // 0xcd170c: ldur            d2, [fp, #-0x10]
    // 0xcd1710: stur            d3, [fp, #-0x48]
    // 0xcd1714: fcmp            d1, d2
    // 0xcd1718: b.vs            #0xcd172c
    // 0xcd171c: b.le            #0xcd172c
    // 0xcd1720: mov             v6.16b, v1.16b
    // 0xcd1724: d4 = 0.000000
    //     0xcd1724: eor             v4.16b, v4.16b, v4.16b
    // 0xcd1728: b               #0xcd1774
    // 0xcd172c: fcmp            d1, d2
    // 0xcd1730: b.vs            #0xcd1744
    // 0xcd1734: b.ge            #0xcd1744
    // 0xcd1738: mov             v6.16b, v2.16b
    // 0xcd173c: d4 = 0.000000
    //     0xcd173c: eor             v4.16b, v4.16b, v4.16b
    // 0xcd1740: b               #0xcd1774
    // 0xcd1744: d4 = 0.000000
    //     0xcd1744: eor             v4.16b, v4.16b, v4.16b
    // 0xcd1748: fcmp            d1, d4
    // 0xcd174c: b.vs            #0xcd1760
    // 0xcd1750: b.ne            #0xcd1760
    // 0xcd1754: fadd            d5, d1, d2
    // 0xcd1758: mov             v6.16b, v5.16b
    // 0xcd175c: b               #0xcd1774
    // 0xcd1760: fcmp            d2, d2
    // 0xcd1764: b.vc            #0xcd1770
    // 0xcd1768: mov             v6.16b, v2.16b
    // 0xcd176c: b               #0xcd1774
    // 0xcd1770: mov             v6.16b, v1.16b
    // 0xcd1774: ldur            d5, [fp, #-0x20]
    // 0xcd1778: stur            d6, [fp, #-0x30]
    // 0xcd177c: fcmp            d6, d5
    // 0xcd1780: b.vs            #0xcd1798
    // 0xcd1784: b.le            #0xcd1798
    // 0xcd1788: mov             v4.16b, v5.16b
    // 0xcd178c: mov             v0.16b, v5.16b
    // 0xcd1790: mov             v1.16b, v3.16b
    // 0xcd1794: b               #0xcd1850
    // 0xcd1798: fcmp            d6, d5
    // 0xcd179c: b.vs            #0xcd17b4
    // 0xcd17a0: b.ge            #0xcd17b4
    // 0xcd17a4: mov             v4.16b, v6.16b
    // 0xcd17a8: mov             v0.16b, v5.16b
    // 0xcd17ac: mov             v1.16b, v3.16b
    // 0xcd17b0: b               #0xcd1850
    // 0xcd17b4: fcmp            d6, d4
    // 0xcd17b8: b.vs            #0xcd17c0
    // 0xcd17bc: b.eq            #0xcd17c8
    // 0xcd17c0: r0 = false
    //     0xcd17c0: add             x0, NULL, #0x30  ; false
    // 0xcd17c4: b               #0xcd17cc
    // 0xcd17c8: r0 = true
    //     0xcd17c8: add             x0, NULL, #0x20  ; true
    // 0xcd17cc: tbnz            w0, #4, #0xcd17ec
    // 0xcd17d0: fadd            d7, d6, d5
    // 0xcd17d4: fmul            d8, d7, d6
    // 0xcd17d8: fmul            d6, d8, d5
    // 0xcd17dc: mov             v4.16b, v6.16b
    // 0xcd17e0: mov             v0.16b, v5.16b
    // 0xcd17e4: mov             v1.16b, v3.16b
    // 0xcd17e8: b               #0xcd1850
    // 0xcd17ec: tbnz            w0, #4, #0xcd1830
    // 0xcd17f0: r0 = inline_Allocate_Double()
    //     0xcd17f0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcd17f4: add             x0, x0, #0x10
    //     0xcd17f8: cmp             x1, x0
    //     0xcd17fc: b.ls            #0xcd19c0
    //     0xcd1800: str             x0, [THR, #0x60]  ; THR::top
    //     0xcd1804: sub             x0, x0, #0xf
    //     0xcd1808: mov             x1, #0xd108
    //     0xcd180c: movk            x1, #3, lsl #16
    //     0xcd1810: stur            x1, [x0, #-1]
    // 0xcd1814: StoreField: r0->field_7 = d5
    //     0xcd1814: stur            d5, [x0, #7]
    // 0xcd1818: SaveReg r0
    //     0xcd1818: str             x0, [SP, #-8]!
    // 0xcd181c: r0 = isNegative()
    //     0xcd181c: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0xcd1820: add             SP, SP, #8
    // 0xcd1824: tbnz            w0, #4, #0xcd1830
    // 0xcd1828: ldur            d0, [fp, #-0x20]
    // 0xcd182c: b               #0xcd183c
    // 0xcd1830: ldur            d0, [fp, #-0x20]
    // 0xcd1834: fcmp            d0, d0
    // 0xcd1838: b.vc            #0xcd1848
    // 0xcd183c: mov             v4.16b, v0.16b
    // 0xcd1840: ldur            d1, [fp, #-0x48]
    // 0xcd1844: b               #0xcd1850
    // 0xcd1848: ldur            d4, [fp, #-0x30]
    // 0xcd184c: ldur            d1, [fp, #-0x48]
    // 0xcd1850: ldur            d2, [fp, #-0x18]
    // 0xcd1854: ldur            d3, [fp, #-0x40]
    // 0xcd1858: stur            d4, [fp, #-0x30]
    // 0xcd185c: r0 = Offset()
    //     0xcd185c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xcd1860: mov             x1, x0
    // 0xcd1864: ldur            d0, [fp, #-0x48]
    // 0xcd1868: StoreField: r1->field_7 = d0
    //     0xcd1868: stur            d0, [x1, #7]
    // 0xcd186c: ldur            d0, [fp, #-0x30]
    // 0xcd1870: StoreField: r1->field_f = d0
    //     0xcd1870: stur            d0, [x1, #0xf]
    // 0xcd1874: ldur            d0, [fp, #-0x18]
    // 0xcd1878: ldur            d1, [fp, #-0x40]
    // 0xcd187c: fcmp            d1, d0
    // 0xcd1880: b.vs            #0xcd18c0
    // 0xcd1884: b.ge            #0xcd18c0
    // 0xcd1888: ldur            x2, [fp, #-8]
    // 0xcd188c: d0 = 0.000000
    //     0xcd188c: eor             v0.16b, v0.16b, v0.16b
    // 0xcd1890: LoadField: d2 = r2->field_7
    //     0xcd1890: ldur            d2, [x2, #7]
    // 0xcd1894: fcmp            d2, d0
    // 0xcd1898: b.vs            #0xcd18b4
    // 0xcd189c: b.ge            #0xcd18b4
    // 0xcd18a0: ldr             x3, [fp, #0x18]
    // 0xcd18a4: r4 = true
    //     0xcd18a4: add             x4, NULL, #0x20  ; true
    // 0xcd18a8: add             x16, x3, #0x15f
    // 0xcd18ac: str             w4, [x16]
    // 0xcd18b0: b               #0xcd18f8
    // 0xcd18b4: ldr             x3, [fp, #0x18]
    // 0xcd18b8: r4 = true
    //     0xcd18b8: add             x4, NULL, #0x20  ; true
    // 0xcd18bc: b               #0xcd18d0
    // 0xcd18c0: ldr             x3, [fp, #0x18]
    // 0xcd18c4: ldur            x2, [fp, #-8]
    // 0xcd18c8: r4 = true
    //     0xcd18c8: add             x4, NULL, #0x20  ; true
    // 0xcd18cc: d0 = 0.000000
    //     0xcd18cc: eor             v0.16b, v0.16b, v0.16b
    // 0xcd18d0: ldur            d2, [fp, #-0x28]
    // 0xcd18d4: fcmp            d1, d2
    // 0xcd18d8: b.vs            #0xcd18f8
    // 0xcd18dc: b.le            #0xcd18f8
    // 0xcd18e0: LoadField: d1 = r2->field_7
    //     0xcd18e0: ldur            d1, [x2, #7]
    // 0xcd18e4: fcmp            d1, d0
    // 0xcd18e8: b.vs            #0xcd18f8
    // 0xcd18ec: b.le            #0xcd18f8
    // 0xcd18f0: add             x16, x3, #0x163
    // 0xcd18f4: str             w4, [x16]
    // 0xcd18f8: ldur            d2, [fp, #-0x10]
    // 0xcd18fc: ldur            d1, [fp, #-0x38]
    // 0xcd1900: fcmp            d1, d2
    // 0xcd1904: b.vs            #0xcd1928
    // 0xcd1908: b.ge            #0xcd1928
    // 0xcd190c: LoadField: d2 = r2->field_f
    //     0xcd190c: ldur            d2, [x2, #0xf]
    // 0xcd1910: fcmp            d2, d0
    // 0xcd1914: b.vs            #0xcd1928
    // 0xcd1918: b.ge            #0xcd1928
    // 0xcd191c: add             x16, x3, #0x167
    // 0xcd1920: str             w4, [x16]
    // 0xcd1924: b               #0xcd1950
    // 0xcd1928: ldur            d2, [fp, #-0x20]
    // 0xcd192c: fcmp            d1, d2
    // 0xcd1930: b.vs            #0xcd1950
    // 0xcd1934: b.le            #0xcd1950
    // 0xcd1938: LoadField: d1 = r2->field_f
    //     0xcd1938: ldur            d1, [x2, #0xf]
    // 0xcd193c: fcmp            d1, d0
    // 0xcd1940: b.vs            #0xcd1950
    // 0xcd1944: b.le            #0xcd1950
    // 0xcd1948: add             x16, x3, #0x16b
    // 0xcd194c: str             w4, [x16]
    // 0xcd1950: ldr             x0, [fp, #0x10]
    // 0xcd1954: r17 = 347
    //     0xcd1954: mov             x17, #0x15b
    // 0xcd1958: str             w0, [x3, x17]
    // 0xcd195c: WriteBarrierInstr(obj = r3, val = r0)
    //     0xcd195c: ldurb           w16, [x3, #-1]
    //     0xcd1960: ldurb           w17, [x0, #-1]
    //     0xcd1964: and             x16, x17, x16, lsr #2
    //     0xcd1968: tst             x16, HEAP, lsr #32
    //     0xcd196c: b.eq            #0xcd1974
    //     0xcd1970: bl              #0xd682ac
    // 0xcd1974: mov             x0, x1
    // 0xcd1978: LeaveFrame
    //     0xcd1978: mov             SP, fp
    //     0xcd197c: ldp             fp, lr, [SP], #0x10
    // 0xcd1980: ret
    //     0xcd1980: ret             
    // 0xcd1984: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd1984: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd1988: b               #0xcd11e4
    // 0xcd198c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xcd198c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xcd1990: r0 = NullCastErrorSharedWithFPURegs()
    //     0xcd1990: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xcd1994: stp             q4, q5, [SP, #-0x20]!
    // 0xcd1998: stp             q2, q3, [SP, #-0x20]!
    // 0xcd199c: stp             q0, q1, [SP, #-0x20]!
    // 0xcd19a0: stp             x0, x1, [SP, #-0x10]!
    // 0xcd19a4: r0 = AllocateDouble()
    //     0xcd19a4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcd19a8: mov             x2, x0
    // 0xcd19ac: ldp             x0, x1, [SP], #0x10
    // 0xcd19b0: ldp             q0, q1, [SP], #0x20
    // 0xcd19b4: ldp             q2, q3, [SP], #0x20
    // 0xcd19b8: ldp             q4, q5, [SP], #0x20
    // 0xcd19bc: b               #0xcd16d0
    // 0xcd19c0: stp             q5, q6, [SP, #-0x20]!
    // 0xcd19c4: stp             q3, q4, [SP, #-0x20]!
    // 0xcd19c8: stp             q1, q2, [SP, #-0x20]!
    // 0xcd19cc: SaveReg d0
    //     0xcd19cc: str             q0, [SP, #-0x10]!
    // 0xcd19d0: r0 = AllocateDouble()
    //     0xcd19d0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcd19d4: RestoreReg d0
    //     0xcd19d4: ldr             q0, [SP], #0x10
    // 0xcd19d8: ldp             q1, q2, [SP], #0x20
    // 0xcd19dc: ldp             q3, q4, [SP], #0x20
    // 0xcd19e0: ldp             q5, q6, [SP], #0x20
    // 0xcd19e4: b               #0xcd1814
  }
  _ setFloatingCursor(/* No info */) {
    // ** addr: 0xcd19e8, size: 0x270
    // 0xcd19e8: EnterFrame
    //     0xcd19e8: stp             fp, lr, [SP, #-0x10]!
    //     0xcd19ec: mov             fp, SP
    // 0xcd19f0: AllocStack(0x20)
    //     0xcd19f0: sub             SP, SP, #0x20
    // 0xcd19f4: SetupParameters(ExtendedRenderEditable this /* r3, fp-0x10 */, dynamic _ /* r4 */, dynamic _ /* r5, fp-0x8 */, dynamic _ /* r6 */, {dynamic resetLerpValue = Null /* r1 */})
    //     0xcd19f4: mov             x0, x4
    //     0xcd19f8: ldur            w1, [x0, #0x13]
    //     0xcd19fc: add             x1, x1, HEAP, lsl #32
    //     0xcd1a00: sub             x2, x1, #8
    //     0xcd1a04: add             x3, fp, w2, sxtw #2
    //     0xcd1a08: ldr             x3, [x3, #0x28]
    //     0xcd1a0c: stur            x3, [fp, #-0x10]
    //     0xcd1a10: add             x4, fp, w2, sxtw #2
    //     0xcd1a14: ldr             x4, [x4, #0x20]
    //     0xcd1a18: add             x5, fp, w2, sxtw #2
    //     0xcd1a1c: ldr             x5, [x5, #0x18]
    //     0xcd1a20: stur            x5, [fp, #-8]
    //     0xcd1a24: add             x6, fp, w2, sxtw #2
    //     0xcd1a28: ldr             x6, [x6, #0x10]
    //     0xcd1a2c: ldur            w2, [x0, #0x1f]
    //     0xcd1a30: add             x2, x2, HEAP, lsl #32
    //     0xcd1a34: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f9a0] "resetLerpValue"
    //     0xcd1a38: ldr             x16, [x16, #0x9a0]
    //     0xcd1a3c: cmp             w2, w16
    //     0xcd1a40: b.ne            #0xcd1a5c
    //     0xcd1a44: ldur            w2, [x0, #0x23]
    //     0xcd1a48: add             x2, x2, HEAP, lsl #32
    //     0xcd1a4c: sub             w0, w1, w2
    //     0xcd1a50: add             x1, fp, w0, sxtw #2
    //     0xcd1a54: ldr             x1, [x1, #8]
    //     0xcd1a58: b               #0xcd1a60
    //     0xcd1a5c: mov             x1, NULL
    // 0xcd1a60: CheckStackOverflow
    //     0xcd1a60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd1a64: cmp             SP, x16
    //     0xcd1a68: b.ls            #0xcd1c40
    // 0xcd1a6c: r16 = Instance_FloatingCursorDragState
    //     0xcd1a6c: ldr             x16, [PP, #0x5e98]  ; [pp+0x5e98] Obj!FloatingCursorDragState@b63fb1
    // 0xcd1a70: cmp             w4, w16
    // 0xcd1a74: b.ne            #0xcd1aa8
    // 0xcd1a78: r2 = Instance_Offset
    //     0xcd1a78: ldr             x2, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xcd1a7c: r0 = false
    //     0xcd1a7c: add             x0, NULL, #0x30  ; false
    // 0xcd1a80: add             x16, x3, #0x157
    // 0xcd1a84: str             w2, [x16]
    // 0xcd1a88: add             x16, x3, #0x15b
    // 0xcd1a8c: str             NULL, [x16]
    // 0xcd1a90: add             x16, x3, #0x16b
    // 0xcd1a94: str             w0, [x16]
    // 0xcd1a98: add             x16, x3, #0x167
    // 0xcd1a9c: str             w0, [x16]
    // 0xcd1aa0: add             x16, x3, #0x163
    // 0xcd1aa4: str             w0, [x16]
    // 0xcd1aa8: r16 = Instance_FloatingCursorDragState
    //     0xcd1aa8: ldr             x16, [PP, #0x5eb0]  ; [pp+0x5eb0] Obj!FloatingCursorDragState@b63f91
    // 0xcd1aac: cmp             w4, w16
    // 0xcd1ab0: r16 = true
    //     0xcd1ab0: add             x16, NULL, #0x20  ; true
    // 0xcd1ab4: r17 = false
    //     0xcd1ab4: add             x17, NULL, #0x30  ; false
    // 0xcd1ab8: csel            x2, x16, x17, ne
    // 0xcd1abc: add             x16, x3, #0x12f
    // 0xcd1ac0: str             w2, [x16]
    // 0xcd1ac4: mov             x0, x1
    // 0xcd1ac8: r17 = 367
    //     0xcd1ac8: mov             x17, #0x16f
    // 0xcd1acc: str             w0, [x3, x17]
    // 0xcd1ad0: WriteBarrierInstr(obj = r3, val = r0)
    //     0xcd1ad0: ldurb           w16, [x3, #-1]
    //     0xcd1ad4: ldurb           w17, [x0, #-1]
    //     0xcd1ad8: and             x16, x17, x16, lsr #2
    //     0xcd1adc: tst             x16, HEAP, lsr #32
    //     0xcd1ae0: b.eq            #0xcd1ae8
    //     0xcd1ae4: bl              #0xd682ac
    // 0xcd1ae8: tbnz            w2, #4, #0xcd1bd4
    // 0xcd1aec: mov             x0, x6
    // 0xcd1af0: r17 = 307
    //     0xcd1af0: mov             x17, #0x133
    // 0xcd1af4: str             w0, [x3, x17]
    // 0xcd1af8: WriteBarrierInstr(obj = r3, val = r0)
    //     0xcd1af8: ldurb           w16, [x3, #-1]
    //     0xcd1afc: ldurb           w17, [x0, #-1]
    //     0xcd1b00: and             x16, x17, x16, lsr #2
    //     0xcd1b04: tst             x16, HEAP, lsr #32
    //     0xcd1b08: b.eq            #0xcd1b10
    //     0xcd1b0c: bl              #0xd682ac
    // 0xcd1b10: cmp             w1, NULL
    // 0xcd1b14: b.eq            #0xcd1b4c
    // 0xcd1b18: LoadField: d0 = r1->field_7
    //     0xcd1b18: ldur            d0, [x1, #7]
    // 0xcd1b1c: r16 = Instance_EdgeInsets
    //     0xcd1b1c: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f9a8] Obj!EdgeInsets@b37401
    //     0xcd1b20: ldr             x16, [x16, #0x9a8]
    // 0xcd1b24: r30 = Instance_EdgeInsets
    //     0xcd1b24: add             lr, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0xcd1b28: ldr             lr, [lr, #0xbd8]
    // 0xcd1b2c: stp             lr, x16, [SP, #-0x10]!
    // 0xcd1b30: SaveReg d0
    //     0xcd1b30: str             d0, [SP, #-8]!
    // 0xcd1b34: r0 = lerp()
    //     0xcd1b34: bl              #0xbf1e98  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::lerp
    // 0xcd1b38: add             SP, SP, #0x18
    // 0xcd1b3c: cmp             w0, NULL
    // 0xcd1b40: b.eq            #0xcd1c48
    // 0xcd1b44: mov             x2, x0
    // 0xcd1b48: b               #0xcd1b54
    // 0xcd1b4c: r2 = Instance_EdgeInsets
    //     0xcd1b4c: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f9a8] Obj!EdgeInsets@b37401
    //     0xcd1b50: ldr             x2, [x2, #0x9a8]
    // 0xcd1b54: ldur            x0, [fp, #-0x10]
    // 0xcd1b58: mov             x1, x0
    // 0xcd1b5c: stur            x2, [fp, #-0x18]
    // 0xcd1b60: LoadField: r0 = r1->field_ab
    //     0xcd1b60: ldur            w0, [x1, #0xab]
    // 0xcd1b64: DecompressPointer r0
    //     0xcd1b64: add             x0, x0, HEAP, lsl #32
    // 0xcd1b68: r16 = Sentinel
    //     0xcd1b68: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd1b6c: cmp             w0, w16
    // 0xcd1b70: b.ne            #0xcd1b80
    // 0xcd1b74: r2 = _caretPainter
    //     0xcd1b74: add             x2, PP, #0x37, lsl #12  ; [pp+0x37348] Field <ExtendedRenderEditable._caretPainter@483409610>: late final (offset: 0xac)
    //     0xcd1b78: ldr             x2, [x2, #0x348]
    // 0xcd1b7c: r0 = InitLateFinalInstanceField()
    //     0xcd1b7c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xcd1b80: ldur            x1, [fp, #-0x10]
    // 0xcd1b84: stur            x0, [fp, #-0x20]
    // 0xcd1b88: r17 = 339
    //     0xcd1b88: mov             x17, #0x153
    // 0xcd1b8c: ldr             w2, [x1, x17]
    // 0xcd1b90: DecompressPointer r2
    //     0xcd1b90: add             x2, x2, HEAP, lsl #32
    // 0xcd1b94: r16 = Sentinel
    //     0xcd1b94: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd1b98: cmp             w2, w16
    // 0xcd1b9c: b.eq            #0xcd1c4c
    // 0xcd1ba0: ldur            x16, [fp, #-0x18]
    // 0xcd1ba4: stp             x2, x16, [SP, #-0x10]!
    // 0xcd1ba8: r0 = inflateRect()
    //     0xcd1ba8: bl              #0x518864  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::inflateRect
    // 0xcd1bac: add             SP, SP, #0x10
    // 0xcd1bb0: ldur            x16, [fp, #-8]
    // 0xcd1bb4: stp             x16, x0, [SP, #-0x10]!
    // 0xcd1bb8: r0 = shift()
    //     0xcd1bb8: bl              #0x51a0bc  ; [dart:ui] Rect::shift
    // 0xcd1bbc: add             SP, SP, #0x10
    // 0xcd1bc0: ldur            x16, [fp, #-0x20]
    // 0xcd1bc4: stp             x0, x16, [SP, #-0x10]!
    // 0xcd1bc8: r0 = floatingCursorRect=()
    //     0xcd1bc8: bl              #0xcd1c58  ; [package:extended_text_field/src/extended_render_editable.dart] _FloatingCursorPainter::floatingCursorRect=
    // 0xcd1bcc: add             SP, SP, #0x10
    // 0xcd1bd0: b               #0xcd1c04
    // 0xcd1bd4: ldur            x1, [fp, #-0x10]
    // 0xcd1bd8: LoadField: r0 = r1->field_ab
    //     0xcd1bd8: ldur            w0, [x1, #0xab]
    // 0xcd1bdc: DecompressPointer r0
    //     0xcd1bdc: add             x0, x0, HEAP, lsl #32
    // 0xcd1be0: r16 = Sentinel
    //     0xcd1be0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd1be4: cmp             w0, w16
    // 0xcd1be8: b.ne            #0xcd1bf8
    // 0xcd1bec: r2 = _caretPainter
    //     0xcd1bec: add             x2, PP, #0x37, lsl #12  ; [pp+0x37348] Field <ExtendedRenderEditable._caretPainter@483409610>: late final (offset: 0xac)
    //     0xcd1bf0: ldr             x2, [x2, #0x348]
    // 0xcd1bf4: r0 = InitLateFinalInstanceField()
    //     0xcd1bf4: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xcd1bf8: stp             NULL, x0, [SP, #-0x10]!
    // 0xcd1bfc: r0 = floatingCursorRect=()
    //     0xcd1bfc: bl              #0xcd1c58  ; [package:extended_text_field/src/extended_render_editable.dart] _FloatingCursorPainter::floatingCursorRect=
    // 0xcd1c00: add             SP, SP, #0x10
    // 0xcd1c04: ldur            x1, [fp, #-0x10]
    // 0xcd1c08: LoadField: r2 = r1->field_ab
    //     0xcd1c08: ldur            w2, [x1, #0xab]
    // 0xcd1c0c: DecompressPointer r2
    //     0xcd1c0c: add             x2, x2, HEAP, lsl #32
    // 0xcd1c10: r17 = 367
    //     0xcd1c10: mov             x17, #0x16f
    // 0xcd1c14: ldr             w3, [x1, x17]
    // 0xcd1c18: DecompressPointer r3
    //     0xcd1c18: add             x3, x3, HEAP, lsl #32
    // 0xcd1c1c: cmp             w3, NULL
    // 0xcd1c20: r16 = true
    //     0xcd1c20: add             x16, NULL, #0x20  ; true
    // 0xcd1c24: r17 = false
    //     0xcd1c24: add             x17, NULL, #0x30  ; false
    // 0xcd1c28: csel            x1, x16, x17, eq
    // 0xcd1c2c: StoreField: r2->field_2b = r1
    //     0xcd1c2c: stur            w1, [x2, #0x2b]
    // 0xcd1c30: r0 = Null
    //     0xcd1c30: mov             x0, NULL
    // 0xcd1c34: LeaveFrame
    //     0xcd1c34: mov             SP, fp
    //     0xcd1c38: ldp             fp, lr, [SP], #0x10
    // 0xcd1c3c: ret
    //     0xcd1c3c: ret             
    // 0xcd1c40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd1c40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd1c44: b               #0xcd1a6c
    // 0xcd1c48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd1c48: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd1c4c: r9 = _caretPrototype
    //     0xcd1c4c: add             x9, PP, #0x37, lsl #12  ; [pp+0x37350] Field <ExtendedRenderEditable._caretPrototype@483409610>: late (offset: 0x154)
    //     0xcd1c50: ldr             x9, [x9, #0x350]
    // 0xcd1c54: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd1c54: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  dynamic _handleMoveCursorBackwardByWord(dynamic) {
    // ** addr: 0xcefe0c, size: 0x18
    // 0xcefe0c: r4 = 0
    //     0xcefe0c: mov             x4, #0
    // 0xcefe10: r1 = Function '_handleMoveCursorBackwardByWord@483409610':.
    //     0xcefe10: add             x17, PP, #0x56, lsl #12  ; [pp+0x568f0] AnonymousClosure: (0xcefe24), in [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_handleMoveCursorBackwardByWord (0xcefe70)
    //     0xcefe14: ldr             x1, [x17, #0x8f0]
    // 0xcefe18: r24 = BuildNonGenericMethodExtractorStub
    //     0xcefe18: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xcefe1c: LoadField: r0 = r24->field_17
    //     0xcefe1c: ldur            x0, [x24, #0x17]
    // 0xcefe20: br              x0
  }
  [closure] void _handleMoveCursorBackwardByWord(dynamic, bool) {
    // ** addr: 0xcefe24, size: 0x4c
    // 0xcefe24: EnterFrame
    //     0xcefe24: stp             fp, lr, [SP, #-0x10]!
    //     0xcefe28: mov             fp, SP
    // 0xcefe2c: ldr             x0, [fp, #0x18]
    // 0xcefe30: LoadField: r1 = r0->field_17
    //     0xcefe30: ldur            w1, [x0, #0x17]
    // 0xcefe34: DecompressPointer r1
    //     0xcefe34: add             x1, x1, HEAP, lsl #32
    // 0xcefe38: CheckStackOverflow
    //     0xcefe38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcefe3c: cmp             SP, x16
    //     0xcefe40: b.ls            #0xcefe68
    // 0xcefe44: LoadField: r0 = r1->field_f
    //     0xcefe44: ldur            w0, [x1, #0xf]
    // 0xcefe48: DecompressPointer r0
    //     0xcefe48: add             x0, x0, HEAP, lsl #32
    // 0xcefe4c: ldr             x16, [fp, #0x10]
    // 0xcefe50: stp             x16, x0, [SP, #-0x10]!
    // 0xcefe54: r0 = _handleMoveCursorBackwardByWord()
    //     0xcefe54: bl              #0xcefe70  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_handleMoveCursorBackwardByWord
    // 0xcefe58: add             SP, SP, #0x10
    // 0xcefe5c: LeaveFrame
    //     0xcefe5c: mov             SP, fp
    //     0xcefe60: ldp             fp, lr, [SP], #0x10
    // 0xcefe64: ret
    //     0xcefe64: ret             
    // 0xcefe68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcefe68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcefe6c: b               #0xcefe44
  }
  _ _handleMoveCursorBackwardByWord(/* No info */) {
    // ** addr: 0xcefe70, size: 0x144
    // 0xcefe70: EnterFrame
    //     0xcefe70: stp             fp, lr, [SP, #-0x10]!
    //     0xcefe74: mov             fp, SP
    // 0xcefe78: AllocStack(0x18)
    //     0xcefe78: sub             SP, SP, #0x18
    // 0xcefe7c: CheckStackOverflow
    //     0xcefe7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcefe80: cmp             SP, x16
    //     0xcefe84: b.ls            #0xceffac
    // 0xcefe88: ldr             x0, [fp, #0x18]
    // 0xcefe8c: LoadField: r1 = r0->field_eb
    //     0xcefe8c: ldur            w1, [x0, #0xeb]
    // 0xcefe90: DecompressPointer r1
    //     0xcefe90: add             x1, x1, HEAP, lsl #32
    // 0xcefe94: stur            x1, [fp, #-8]
    // 0xcefe98: r17 = 271
    //     0xcefe98: mov             x17, #0x10f
    // 0xcefe9c: ldr             w2, [x0, x17]
    // 0xcefea0: DecompressPointer r2
    //     0xcefea0: add             x2, x2, HEAP, lsl #32
    // 0xcefea4: SaveReg r2
    //     0xcefea4: str             x2, [SP, #-8]!
    // 0xcefea8: r0 = extent()
    //     0xcefea8: bl              #0x5223fc  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0xcefeac: add             SP, SP, #8
    // 0xcefeb0: ldur            x16, [fp, #-8]
    // 0xcefeb4: stp             x0, x16, [SP, #-0x10]!
    // 0xcefeb8: r0 = getWordBoundary()
    //     0xcefeb8: bl              #0x83bafc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getWordBoundary
    // 0xcefebc: add             SP, SP, #0x10
    // 0xcefec0: LoadField: r1 = r0->field_7
    //     0xcefec0: ldur            x1, [x0, #7]
    // 0xcefec4: sub             x0, x1, #1
    // 0xcefec8: ldr             x16, [fp, #0x18]
    // 0xcefecc: stp             x0, x16, [SP, #-0x10]!
    // 0xcefed0: r0 = _getPreviousWord()
    //     0xcefed0: bl              #0x83b6a4  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_getPreviousWord
    // 0xcefed4: add             SP, SP, #0x10
    // 0xcefed8: cmp             w0, NULL
    // 0xcefedc: b.ne            #0xcefef0
    // 0xcefee0: r0 = Null
    //     0xcefee0: mov             x0, NULL
    // 0xcefee4: LeaveFrame
    //     0xcefee4: mov             SP, fp
    //     0xcefee8: ldp             fp, lr, [SP], #0x10
    // 0xcefeec: ret
    //     0xcefeec: ret             
    // 0xcefef0: ldr             x1, [fp, #0x10]
    // 0xcefef4: tbnz            w1, #4, #0xceff14
    // 0xcefef8: ldr             x1, [fp, #0x18]
    // 0xcefefc: r17 = 271
    //     0xcefefc: mov             x17, #0x10f
    // 0xceff00: ldr             w2, [x1, x17]
    // 0xceff04: DecompressPointer r2
    //     0xceff04: add             x2, x2, HEAP, lsl #32
    // 0xceff08: LoadField: r3 = r2->field_17
    //     0xceff08: ldur            x3, [x2, #0x17]
    // 0xceff0c: mov             x2, x3
    // 0xceff10: b               #0xceff1c
    // 0xceff14: ldr             x1, [fp, #0x18]
    // 0xceff18: LoadField: r2 = r0->field_7
    //     0xceff18: ldur            x2, [x0, #7]
    // 0xceff1c: stur            x2, [fp, #-0x18]
    // 0xceff20: LoadField: r3 = r0->field_7
    //     0xceff20: ldur            x3, [x0, #7]
    // 0xceff24: stur            x3, [fp, #-0x10]
    // 0xceff28: r0 = TextSelection()
    //     0xceff28: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xceff2c: mov             x1, x0
    // 0xceff30: ldur            x0, [fp, #-0x18]
    // 0xceff34: StoreField: r1->field_17 = r0
    //     0xceff34: stur            x0, [x1, #0x17]
    // 0xceff38: ldur            x2, [fp, #-0x10]
    // 0xceff3c: StoreField: r1->field_1f = r2
    //     0xceff3c: stur            x2, [x1, #0x1f]
    // 0xceff40: r3 = Instance_TextAffinity
    //     0xceff40: ldr             x3, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0xceff44: StoreField: r1->field_27 = r3
    //     0xceff44: stur            w3, [x1, #0x27]
    // 0xceff48: r3 = false
    //     0xceff48: add             x3, NULL, #0x30  ; false
    // 0xceff4c: StoreField: r1->field_2b = r3
    //     0xceff4c: stur            w3, [x1, #0x2b]
    // 0xceff50: cmp             x0, x2
    // 0xceff54: r16 = true
    //     0xceff54: add             x16, NULL, #0x20  ; true
    // 0xceff58: r17 = false
    //     0xceff58: add             x17, NULL, #0x30  ; false
    // 0xceff5c: csel            x3, x16, x17, lt
    // 0xceff60: tbnz            w3, #4, #0xceff6c
    // 0xceff64: mov             x4, x0
    // 0xceff68: b               #0xceff70
    // 0xceff6c: mov             x4, x2
    // 0xceff70: tbnz            w3, #4, #0xceff78
    // 0xceff74: mov             x0, x2
    // 0xceff78: StoreField: r1->field_7 = r4
    //     0xceff78: stur            x4, [x1, #7]
    // 0xceff7c: StoreField: r1->field_f = r0
    //     0xceff7c: stur            x0, [x1, #0xf]
    // 0xceff80: ldr             x16, [fp, #0x18]
    // 0xceff84: stp             x1, x16, [SP, #-0x10]!
    // 0xceff88: r16 = Instance_SelectionChangedCause
    //     0xceff88: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6b8] Obj!SelectionChangedCause@b63e71
    //     0xceff8c: ldr             x16, [x16, #0x6b8]
    // 0xceff90: SaveReg r16
    //     0xceff90: str             x16, [SP, #-8]!
    // 0xceff94: r0 = setSelection()
    //     0xceff94: bl              #0x839de8  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::setSelection
    // 0xceff98: add             SP, SP, #0x18
    // 0xceff9c: r0 = Null
    //     0xceff9c: mov             x0, NULL
    // 0xceffa0: LeaveFrame
    //     0xceffa0: mov             SP, fp
    //     0xceffa4: ldp             fp, lr, [SP], #0x10
    // 0xceffa8: ret
    //     0xceffa8: ret             
    // 0xceffac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xceffac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xceffb0: b               #0xcefe88
  }
  dynamic _handleMoveCursorForwardByWord(dynamic) {
    // ** addr: 0xceffb4, size: 0x18
    // 0xceffb4: r4 = 0
    //     0xceffb4: mov             x4, #0
    // 0xceffb8: r1 = Function '_handleMoveCursorForwardByWord@483409610':.
    //     0xceffb8: add             x17, PP, #0x56, lsl #12  ; [pp+0x568e0] AnonymousClosure: (0xceffcc), in [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_handleMoveCursorForwardByWord (0xcf0018)
    //     0xceffbc: ldr             x1, [x17, #0x8e0]
    // 0xceffc0: r24 = BuildNonGenericMethodExtractorStub
    //     0xceffc0: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xceffc4: LoadField: r0 = r24->field_17
    //     0xceffc4: ldur            x0, [x24, #0x17]
    // 0xceffc8: br              x0
  }
  [closure] void _handleMoveCursorForwardByWord(dynamic, bool) {
    // ** addr: 0xceffcc, size: 0x4c
    // 0xceffcc: EnterFrame
    //     0xceffcc: stp             fp, lr, [SP, #-0x10]!
    //     0xceffd0: mov             fp, SP
    // 0xceffd4: ldr             x0, [fp, #0x18]
    // 0xceffd8: LoadField: r1 = r0->field_17
    //     0xceffd8: ldur            w1, [x0, #0x17]
    // 0xceffdc: DecompressPointer r1
    //     0xceffdc: add             x1, x1, HEAP, lsl #32
    // 0xceffe0: CheckStackOverflow
    //     0xceffe0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xceffe4: cmp             SP, x16
    //     0xceffe8: b.ls            #0xcf0010
    // 0xceffec: LoadField: r0 = r1->field_f
    //     0xceffec: ldur            w0, [x1, #0xf]
    // 0xcefff0: DecompressPointer r0
    //     0xcefff0: add             x0, x0, HEAP, lsl #32
    // 0xcefff4: ldr             x16, [fp, #0x10]
    // 0xcefff8: stp             x16, x0, [SP, #-0x10]!
    // 0xcefffc: r0 = _handleMoveCursorForwardByWord()
    //     0xcefffc: bl              #0xcf0018  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_handleMoveCursorForwardByWord
    // 0xcf0000: add             SP, SP, #0x10
    // 0xcf0004: LeaveFrame
    //     0xcf0004: mov             SP, fp
    //     0xcf0008: ldp             fp, lr, [SP], #0x10
    // 0xcf000c: ret
    //     0xcf000c: ret             
    // 0xcf0010: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0010: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf0014: b               #0xceffec
  }
  _ _handleMoveCursorForwardByWord(/* No info */) {
    // ** addr: 0xcf0018, size: 0x140
    // 0xcf0018: EnterFrame
    //     0xcf0018: stp             fp, lr, [SP, #-0x10]!
    //     0xcf001c: mov             fp, SP
    // 0xcf0020: AllocStack(0x18)
    //     0xcf0020: sub             SP, SP, #0x18
    // 0xcf0024: CheckStackOverflow
    //     0xcf0024: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf0028: cmp             SP, x16
    //     0xcf002c: b.ls            #0xcf0150
    // 0xcf0030: ldr             x0, [fp, #0x18]
    // 0xcf0034: LoadField: r1 = r0->field_eb
    //     0xcf0034: ldur            w1, [x0, #0xeb]
    // 0xcf0038: DecompressPointer r1
    //     0xcf0038: add             x1, x1, HEAP, lsl #32
    // 0xcf003c: stur            x1, [fp, #-8]
    // 0xcf0040: r17 = 271
    //     0xcf0040: mov             x17, #0x10f
    // 0xcf0044: ldr             w2, [x0, x17]
    // 0xcf0048: DecompressPointer r2
    //     0xcf0048: add             x2, x2, HEAP, lsl #32
    // 0xcf004c: SaveReg r2
    //     0xcf004c: str             x2, [SP, #-8]!
    // 0xcf0050: r0 = extent()
    //     0xcf0050: bl              #0x5223fc  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0xcf0054: add             SP, SP, #8
    // 0xcf0058: ldur            x16, [fp, #-8]
    // 0xcf005c: stp             x0, x16, [SP, #-0x10]!
    // 0xcf0060: r0 = getWordBoundary()
    //     0xcf0060: bl              #0x83bafc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getWordBoundary
    // 0xcf0064: add             SP, SP, #0x10
    // 0xcf0068: LoadField: r1 = r0->field_f
    //     0xcf0068: ldur            x1, [x0, #0xf]
    // 0xcf006c: ldr             x16, [fp, #0x18]
    // 0xcf0070: stp             x1, x16, [SP, #-0x10]!
    // 0xcf0074: r0 = _getNextWord()
    //     0xcf0074: bl              #0x83aeb4  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_getNextWord
    // 0xcf0078: add             SP, SP, #0x10
    // 0xcf007c: cmp             w0, NULL
    // 0xcf0080: b.ne            #0xcf0094
    // 0xcf0084: r0 = Null
    //     0xcf0084: mov             x0, NULL
    // 0xcf0088: LeaveFrame
    //     0xcf0088: mov             SP, fp
    //     0xcf008c: ldp             fp, lr, [SP], #0x10
    // 0xcf0090: ret
    //     0xcf0090: ret             
    // 0xcf0094: ldr             x1, [fp, #0x10]
    // 0xcf0098: tbnz            w1, #4, #0xcf00b8
    // 0xcf009c: ldr             x1, [fp, #0x18]
    // 0xcf00a0: r17 = 271
    //     0xcf00a0: mov             x17, #0x10f
    // 0xcf00a4: ldr             w2, [x1, x17]
    // 0xcf00a8: DecompressPointer r2
    //     0xcf00a8: add             x2, x2, HEAP, lsl #32
    // 0xcf00ac: LoadField: r3 = r2->field_17
    //     0xcf00ac: ldur            x3, [x2, #0x17]
    // 0xcf00b0: mov             x2, x3
    // 0xcf00b4: b               #0xcf00c0
    // 0xcf00b8: ldr             x1, [fp, #0x18]
    // 0xcf00bc: LoadField: r2 = r0->field_7
    //     0xcf00bc: ldur            x2, [x0, #7]
    // 0xcf00c0: stur            x2, [fp, #-0x18]
    // 0xcf00c4: LoadField: r3 = r0->field_7
    //     0xcf00c4: ldur            x3, [x0, #7]
    // 0xcf00c8: stur            x3, [fp, #-0x10]
    // 0xcf00cc: r0 = TextSelection()
    //     0xcf00cc: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xcf00d0: mov             x1, x0
    // 0xcf00d4: ldur            x0, [fp, #-0x18]
    // 0xcf00d8: StoreField: r1->field_17 = r0
    //     0xcf00d8: stur            x0, [x1, #0x17]
    // 0xcf00dc: ldur            x2, [fp, #-0x10]
    // 0xcf00e0: StoreField: r1->field_1f = r2
    //     0xcf00e0: stur            x2, [x1, #0x1f]
    // 0xcf00e4: r3 = Instance_TextAffinity
    //     0xcf00e4: ldr             x3, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0xcf00e8: StoreField: r1->field_27 = r3
    //     0xcf00e8: stur            w3, [x1, #0x27]
    // 0xcf00ec: r3 = false
    //     0xcf00ec: add             x3, NULL, #0x30  ; false
    // 0xcf00f0: StoreField: r1->field_2b = r3
    //     0xcf00f0: stur            w3, [x1, #0x2b]
    // 0xcf00f4: cmp             x0, x2
    // 0xcf00f8: r16 = true
    //     0xcf00f8: add             x16, NULL, #0x20  ; true
    // 0xcf00fc: r17 = false
    //     0xcf00fc: add             x17, NULL, #0x30  ; false
    // 0xcf0100: csel            x3, x16, x17, lt
    // 0xcf0104: tbnz            w3, #4, #0xcf0110
    // 0xcf0108: mov             x4, x0
    // 0xcf010c: b               #0xcf0114
    // 0xcf0110: mov             x4, x2
    // 0xcf0114: tbnz            w3, #4, #0xcf011c
    // 0xcf0118: mov             x0, x2
    // 0xcf011c: StoreField: r1->field_7 = r4
    //     0xcf011c: stur            x4, [x1, #7]
    // 0xcf0120: StoreField: r1->field_f = r0
    //     0xcf0120: stur            x0, [x1, #0xf]
    // 0xcf0124: ldr             x16, [fp, #0x18]
    // 0xcf0128: stp             x1, x16, [SP, #-0x10]!
    // 0xcf012c: r16 = Instance_SelectionChangedCause
    //     0xcf012c: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6b8] Obj!SelectionChangedCause@b63e71
    //     0xcf0130: ldr             x16, [x16, #0x6b8]
    // 0xcf0134: SaveReg r16
    //     0xcf0134: str             x16, [SP, #-8]!
    // 0xcf0138: r0 = setSelection()
    //     0xcf0138: bl              #0x839de8  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::setSelection
    // 0xcf013c: add             SP, SP, #0x18
    // 0xcf0140: r0 = Null
    //     0xcf0140: mov             x0, NULL
    // 0xcf0144: LeaveFrame
    //     0xcf0144: mov             SP, fp
    //     0xcf0148: ldp             fp, lr, [SP], #0x10
    // 0xcf014c: ret
    //     0xcf014c: ret             
    // 0xcf0150: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0150: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf0154: b               #0xcf0030
  }
  dynamic _handleMoveCursorBackwardByCharacter(dynamic) {
    // ** addr: 0xcf0158, size: 0x18
    // 0xcf0158: r4 = 0
    //     0xcf0158: mov             x4, #0
    // 0xcf015c: r1 = Function '_handleMoveCursorBackwardByCharacter@483409610':.
    //     0xcf015c: add             x17, PP, #0x56, lsl #12  ; [pp+0x568e8] AnonymousClosure: (0xcf0170), in [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_handleMoveCursorBackwardByCharacter (0xcf01bc)
    //     0xcf0160: ldr             x1, [x17, #0x8e8]
    // 0xcf0164: r24 = BuildNonGenericMethodExtractorStub
    //     0xcf0164: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xcf0168: LoadField: r0 = r24->field_17
    //     0xcf0168: ldur            x0, [x24, #0x17]
    // 0xcf016c: br              x0
  }
  [closure] void _handleMoveCursorBackwardByCharacter(dynamic, bool) {
    // ** addr: 0xcf0170, size: 0x4c
    // 0xcf0170: EnterFrame
    //     0xcf0170: stp             fp, lr, [SP, #-0x10]!
    //     0xcf0174: mov             fp, SP
    // 0xcf0178: ldr             x0, [fp, #0x18]
    // 0xcf017c: LoadField: r1 = r0->field_17
    //     0xcf017c: ldur            w1, [x0, #0x17]
    // 0xcf0180: DecompressPointer r1
    //     0xcf0180: add             x1, x1, HEAP, lsl #32
    // 0xcf0184: CheckStackOverflow
    //     0xcf0184: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf0188: cmp             SP, x16
    //     0xcf018c: b.ls            #0xcf01b4
    // 0xcf0190: LoadField: r0 = r1->field_f
    //     0xcf0190: ldur            w0, [x1, #0xf]
    // 0xcf0194: DecompressPointer r0
    //     0xcf0194: add             x0, x0, HEAP, lsl #32
    // 0xcf0198: ldr             x16, [fp, #0x10]
    // 0xcf019c: stp             x16, x0, [SP, #-0x10]!
    // 0xcf01a0: r0 = _handleMoveCursorBackwardByCharacter()
    //     0xcf01a0: bl              #0xcf01bc  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_handleMoveCursorBackwardByCharacter
    // 0xcf01a4: add             SP, SP, #0x10
    // 0xcf01a8: LeaveFrame
    //     0xcf01a8: mov             SP, fp
    //     0xcf01ac: ldp             fp, lr, [SP], #0x10
    // 0xcf01b0: ret
    //     0xcf01b0: ret             
    // 0xcf01b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf01b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf01b8: b               #0xcf0190
  }
  _ _handleMoveCursorBackwardByCharacter(/* No info */) {
    // ** addr: 0xcf01bc, size: 0x130
    // 0xcf01bc: EnterFrame
    //     0xcf01bc: stp             fp, lr, [SP, #-0x10]!
    //     0xcf01c0: mov             fp, SP
    // 0xcf01c4: AllocStack(0x10)
    //     0xcf01c4: sub             SP, SP, #0x10
    // 0xcf01c8: CheckStackOverflow
    //     0xcf01c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf01cc: cmp             SP, x16
    //     0xcf01d0: b.ls            #0xcf02e4
    // 0xcf01d4: ldr             x0, [fp, #0x18]
    // 0xcf01d8: LoadField: r1 = r0->field_eb
    //     0xcf01d8: ldur            w1, [x0, #0xeb]
    // 0xcf01dc: DecompressPointer r1
    //     0xcf01dc: add             x1, x1, HEAP, lsl #32
    // 0xcf01e0: r17 = 271
    //     0xcf01e0: mov             x17, #0x10f
    // 0xcf01e4: ldr             w2, [x0, x17]
    // 0xcf01e8: DecompressPointer r2
    //     0xcf01e8: add             x2, x2, HEAP, lsl #32
    // 0xcf01ec: LoadField: r3 = r2->field_1f
    //     0xcf01ec: ldur            x3, [x2, #0x1f]
    // 0xcf01f0: stp             x3, x1, [SP, #-0x10]!
    // 0xcf01f4: r0 = getOffsetBefore()
    //     0xcf01f4: bl              #0x64cd88  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getOffsetBefore
    // 0xcf01f8: add             SP, SP, #0x10
    // 0xcf01fc: stur            x0, [fp, #-0x10]
    // 0xcf0200: cmp             w0, NULL
    // 0xcf0204: b.ne            #0xcf0218
    // 0xcf0208: r0 = Null
    //     0xcf0208: mov             x0, NULL
    // 0xcf020c: LeaveFrame
    //     0xcf020c: mov             SP, fp
    //     0xcf0210: ldp             fp, lr, [SP], #0x10
    // 0xcf0214: ret
    //     0xcf0214: ret             
    // 0xcf0218: ldr             x1, [fp, #0x10]
    // 0xcf021c: tbz             w1, #4, #0xcf0238
    // 0xcf0220: r1 = LoadInt32Instr(r0)
    //     0xcf0220: sbfx            x1, x0, #1, #0x1f
    //     0xcf0224: tbz             w0, #0, #0xcf022c
    //     0xcf0228: ldur            x1, [x0, #7]
    // 0xcf022c: mov             x2, x1
    // 0xcf0230: ldr             x1, [fp, #0x18]
    // 0xcf0234: b               #0xcf0250
    // 0xcf0238: ldr             x1, [fp, #0x18]
    // 0xcf023c: r17 = 271
    //     0xcf023c: mov             x17, #0x10f
    // 0xcf0240: ldr             w2, [x1, x17]
    // 0xcf0244: DecompressPointer r2
    //     0xcf0244: add             x2, x2, HEAP, lsl #32
    // 0xcf0248: LoadField: r3 = r2->field_17
    //     0xcf0248: ldur            x3, [x2, #0x17]
    // 0xcf024c: mov             x2, x3
    // 0xcf0250: stur            x2, [fp, #-8]
    // 0xcf0254: r0 = TextSelection()
    //     0xcf0254: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xcf0258: mov             x1, x0
    // 0xcf025c: ldur            x0, [fp, #-8]
    // 0xcf0260: StoreField: r1->field_17 = r0
    //     0xcf0260: stur            x0, [x1, #0x17]
    // 0xcf0264: ldur            x2, [fp, #-0x10]
    // 0xcf0268: r3 = LoadInt32Instr(r2)
    //     0xcf0268: sbfx            x3, x2, #1, #0x1f
    //     0xcf026c: tbz             w2, #0, #0xcf0274
    //     0xcf0270: ldur            x3, [x2, #7]
    // 0xcf0274: StoreField: r1->field_1f = r3
    //     0xcf0274: stur            x3, [x1, #0x1f]
    // 0xcf0278: r2 = Instance_TextAffinity
    //     0xcf0278: ldr             x2, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0xcf027c: StoreField: r1->field_27 = r2
    //     0xcf027c: stur            w2, [x1, #0x27]
    // 0xcf0280: r2 = false
    //     0xcf0280: add             x2, NULL, #0x30  ; false
    // 0xcf0284: StoreField: r1->field_2b = r2
    //     0xcf0284: stur            w2, [x1, #0x2b]
    // 0xcf0288: cmp             x0, x3
    // 0xcf028c: r16 = true
    //     0xcf028c: add             x16, NULL, #0x20  ; true
    // 0xcf0290: r17 = false
    //     0xcf0290: add             x17, NULL, #0x30  ; false
    // 0xcf0294: csel            x2, x16, x17, lt
    // 0xcf0298: tbnz            w2, #4, #0xcf02a4
    // 0xcf029c: mov             x4, x0
    // 0xcf02a0: b               #0xcf02a8
    // 0xcf02a4: mov             x4, x3
    // 0xcf02a8: tbnz            w2, #4, #0xcf02b0
    // 0xcf02ac: mov             x0, x3
    // 0xcf02b0: StoreField: r1->field_7 = r4
    //     0xcf02b0: stur            x4, [x1, #7]
    // 0xcf02b4: StoreField: r1->field_f = r0
    //     0xcf02b4: stur            x0, [x1, #0xf]
    // 0xcf02b8: ldr             x16, [fp, #0x18]
    // 0xcf02bc: stp             x1, x16, [SP, #-0x10]!
    // 0xcf02c0: r16 = Instance_SelectionChangedCause
    //     0xcf02c0: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6b8] Obj!SelectionChangedCause@b63e71
    //     0xcf02c4: ldr             x16, [x16, #0x6b8]
    // 0xcf02c8: SaveReg r16
    //     0xcf02c8: str             x16, [SP, #-8]!
    // 0xcf02cc: r0 = setSelection()
    //     0xcf02cc: bl              #0x839de8  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::setSelection
    // 0xcf02d0: add             SP, SP, #0x18
    // 0xcf02d4: r0 = Null
    //     0xcf02d4: mov             x0, NULL
    // 0xcf02d8: LeaveFrame
    //     0xcf02d8: mov             SP, fp
    //     0xcf02dc: ldp             fp, lr, [SP], #0x10
    // 0xcf02e0: ret
    //     0xcf02e0: ret             
    // 0xcf02e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf02e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf02e8: b               #0xcf01d4
  }
  dynamic _handleMoveCursorForwardByCharacter(dynamic) {
    // ** addr: 0xcf02ec, size: 0x18
    // 0xcf02ec: r4 = 0
    //     0xcf02ec: mov             x4, #0
    // 0xcf02f0: r1 = Function '_handleMoveCursorForwardByCharacter@483409610':.
    //     0xcf02f0: add             x17, PP, #0x56, lsl #12  ; [pp+0x568d8] AnonymousClosure: (0xcf0304), in [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_handleMoveCursorForwardByCharacter (0xcf0350)
    //     0xcf02f4: ldr             x1, [x17, #0x8d8]
    // 0xcf02f8: r24 = BuildNonGenericMethodExtractorStub
    //     0xcf02f8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xcf02fc: LoadField: r0 = r24->field_17
    //     0xcf02fc: ldur            x0, [x24, #0x17]
    // 0xcf0300: br              x0
  }
  [closure] void _handleMoveCursorForwardByCharacter(dynamic, bool) {
    // ** addr: 0xcf0304, size: 0x4c
    // 0xcf0304: EnterFrame
    //     0xcf0304: stp             fp, lr, [SP, #-0x10]!
    //     0xcf0308: mov             fp, SP
    // 0xcf030c: ldr             x0, [fp, #0x18]
    // 0xcf0310: LoadField: r1 = r0->field_17
    //     0xcf0310: ldur            w1, [x0, #0x17]
    // 0xcf0314: DecompressPointer r1
    //     0xcf0314: add             x1, x1, HEAP, lsl #32
    // 0xcf0318: CheckStackOverflow
    //     0xcf0318: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf031c: cmp             SP, x16
    //     0xcf0320: b.ls            #0xcf0348
    // 0xcf0324: LoadField: r0 = r1->field_f
    //     0xcf0324: ldur            w0, [x1, #0xf]
    // 0xcf0328: DecompressPointer r0
    //     0xcf0328: add             x0, x0, HEAP, lsl #32
    // 0xcf032c: ldr             x16, [fp, #0x10]
    // 0xcf0330: stp             x16, x0, [SP, #-0x10]!
    // 0xcf0334: r0 = _handleMoveCursorForwardByCharacter()
    //     0xcf0334: bl              #0xcf0350  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_handleMoveCursorForwardByCharacter
    // 0xcf0338: add             SP, SP, #0x10
    // 0xcf033c: LeaveFrame
    //     0xcf033c: mov             SP, fp
    //     0xcf0340: ldp             fp, lr, [SP], #0x10
    // 0xcf0344: ret
    //     0xcf0344: ret             
    // 0xcf0348: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0348: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf034c: b               #0xcf0324
  }
  _ _handleMoveCursorForwardByCharacter(/* No info */) {
    // ** addr: 0xcf0350, size: 0x130
    // 0xcf0350: EnterFrame
    //     0xcf0350: stp             fp, lr, [SP, #-0x10]!
    //     0xcf0354: mov             fp, SP
    // 0xcf0358: AllocStack(0x10)
    //     0xcf0358: sub             SP, SP, #0x10
    // 0xcf035c: CheckStackOverflow
    //     0xcf035c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf0360: cmp             SP, x16
    //     0xcf0364: b.ls            #0xcf0478
    // 0xcf0368: ldr             x0, [fp, #0x18]
    // 0xcf036c: LoadField: r1 = r0->field_eb
    //     0xcf036c: ldur            w1, [x0, #0xeb]
    // 0xcf0370: DecompressPointer r1
    //     0xcf0370: add             x1, x1, HEAP, lsl #32
    // 0xcf0374: r17 = 271
    //     0xcf0374: mov             x17, #0x10f
    // 0xcf0378: ldr             w2, [x0, x17]
    // 0xcf037c: DecompressPointer r2
    //     0xcf037c: add             x2, x2, HEAP, lsl #32
    // 0xcf0380: LoadField: r3 = r2->field_1f
    //     0xcf0380: ldur            x3, [x2, #0x1f]
    // 0xcf0384: stp             x3, x1, [SP, #-0x10]!
    // 0xcf0388: r0 = getOffsetAfter()
    //     0xcf0388: bl              #0x64ccd0  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getOffsetAfter
    // 0xcf038c: add             SP, SP, #0x10
    // 0xcf0390: stur            x0, [fp, #-0x10]
    // 0xcf0394: cmp             w0, NULL
    // 0xcf0398: b.ne            #0xcf03ac
    // 0xcf039c: r0 = Null
    //     0xcf039c: mov             x0, NULL
    // 0xcf03a0: LeaveFrame
    //     0xcf03a0: mov             SP, fp
    //     0xcf03a4: ldp             fp, lr, [SP], #0x10
    // 0xcf03a8: ret
    //     0xcf03a8: ret             
    // 0xcf03ac: ldr             x1, [fp, #0x10]
    // 0xcf03b0: tbz             w1, #4, #0xcf03cc
    // 0xcf03b4: r1 = LoadInt32Instr(r0)
    //     0xcf03b4: sbfx            x1, x0, #1, #0x1f
    //     0xcf03b8: tbz             w0, #0, #0xcf03c0
    //     0xcf03bc: ldur            x1, [x0, #7]
    // 0xcf03c0: mov             x2, x1
    // 0xcf03c4: ldr             x1, [fp, #0x18]
    // 0xcf03c8: b               #0xcf03e4
    // 0xcf03cc: ldr             x1, [fp, #0x18]
    // 0xcf03d0: r17 = 271
    //     0xcf03d0: mov             x17, #0x10f
    // 0xcf03d4: ldr             w2, [x1, x17]
    // 0xcf03d8: DecompressPointer r2
    //     0xcf03d8: add             x2, x2, HEAP, lsl #32
    // 0xcf03dc: LoadField: r3 = r2->field_17
    //     0xcf03dc: ldur            x3, [x2, #0x17]
    // 0xcf03e0: mov             x2, x3
    // 0xcf03e4: stur            x2, [fp, #-8]
    // 0xcf03e8: r0 = TextSelection()
    //     0xcf03e8: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xcf03ec: mov             x1, x0
    // 0xcf03f0: ldur            x0, [fp, #-8]
    // 0xcf03f4: StoreField: r1->field_17 = r0
    //     0xcf03f4: stur            x0, [x1, #0x17]
    // 0xcf03f8: ldur            x2, [fp, #-0x10]
    // 0xcf03fc: r3 = LoadInt32Instr(r2)
    //     0xcf03fc: sbfx            x3, x2, #1, #0x1f
    //     0xcf0400: tbz             w2, #0, #0xcf0408
    //     0xcf0404: ldur            x3, [x2, #7]
    // 0xcf0408: StoreField: r1->field_1f = r3
    //     0xcf0408: stur            x3, [x1, #0x1f]
    // 0xcf040c: r2 = Instance_TextAffinity
    //     0xcf040c: ldr             x2, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0xcf0410: StoreField: r1->field_27 = r2
    //     0xcf0410: stur            w2, [x1, #0x27]
    // 0xcf0414: r2 = false
    //     0xcf0414: add             x2, NULL, #0x30  ; false
    // 0xcf0418: StoreField: r1->field_2b = r2
    //     0xcf0418: stur            w2, [x1, #0x2b]
    // 0xcf041c: cmp             x0, x3
    // 0xcf0420: r16 = true
    //     0xcf0420: add             x16, NULL, #0x20  ; true
    // 0xcf0424: r17 = false
    //     0xcf0424: add             x17, NULL, #0x30  ; false
    // 0xcf0428: csel            x2, x16, x17, lt
    // 0xcf042c: tbnz            w2, #4, #0xcf0438
    // 0xcf0430: mov             x4, x0
    // 0xcf0434: b               #0xcf043c
    // 0xcf0438: mov             x4, x3
    // 0xcf043c: tbnz            w2, #4, #0xcf0444
    // 0xcf0440: mov             x0, x3
    // 0xcf0444: StoreField: r1->field_7 = r4
    //     0xcf0444: stur            x4, [x1, #7]
    // 0xcf0448: StoreField: r1->field_f = r0
    //     0xcf0448: stur            x0, [x1, #0xf]
    // 0xcf044c: ldr             x16, [fp, #0x18]
    // 0xcf0450: stp             x1, x16, [SP, #-0x10]!
    // 0xcf0454: r16 = Instance_SelectionChangedCause
    //     0xcf0454: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6b8] Obj!SelectionChangedCause@b63e71
    //     0xcf0458: ldr             x16, [x16, #0x6b8]
    // 0xcf045c: SaveReg r16
    //     0xcf045c: str             x16, [SP, #-8]!
    // 0xcf0460: r0 = setSelection()
    //     0xcf0460: bl              #0x839de8  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::setSelection
    // 0xcf0464: add             SP, SP, #0x18
    // 0xcf0468: r0 = Null
    //     0xcf0468: mov             x0, NULL
    // 0xcf046c: LeaveFrame
    //     0xcf046c: mov             SP, fp
    //     0xcf0470: ldp             fp, lr, [SP], #0x10
    // 0xcf0474: ret
    //     0xcf0474: ret             
    // 0xcf0478: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0478: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf047c: b               #0xcf0368
  }
  dynamic _handleSetText(dynamic) {
    // ** addr: 0xcf0480, size: 0x18
    // 0xcf0480: r4 = 0
    //     0xcf0480: mov             x4, #0
    // 0xcf0484: r1 = Function '_handleSetText@483409610':.
    //     0xcf0484: add             x17, PP, #0x56, lsl #12  ; [pp+0x568f8] AnonymousClosure: (0xcf0498), in [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_handleSetText (0xcf04e4)
    //     0xcf0488: ldr             x1, [x17, #0x8f8]
    // 0xcf048c: r24 = BuildNonGenericMethodExtractorStub
    //     0xcf048c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xcf0490: LoadField: r0 = r24->field_17
    //     0xcf0490: ldur            x0, [x24, #0x17]
    // 0xcf0494: br              x0
  }
  [closure] void _handleSetText(dynamic, String) {
    // ** addr: 0xcf0498, size: 0x4c
    // 0xcf0498: EnterFrame
    //     0xcf0498: stp             fp, lr, [SP, #-0x10]!
    //     0xcf049c: mov             fp, SP
    // 0xcf04a0: ldr             x0, [fp, #0x18]
    // 0xcf04a4: LoadField: r1 = r0->field_17
    //     0xcf04a4: ldur            w1, [x0, #0x17]
    // 0xcf04a8: DecompressPointer r1
    //     0xcf04a8: add             x1, x1, HEAP, lsl #32
    // 0xcf04ac: CheckStackOverflow
    //     0xcf04ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf04b0: cmp             SP, x16
    //     0xcf04b4: b.ls            #0xcf04dc
    // 0xcf04b8: LoadField: r0 = r1->field_f
    //     0xcf04b8: ldur            w0, [x1, #0xf]
    // 0xcf04bc: DecompressPointer r0
    //     0xcf04bc: add             x0, x0, HEAP, lsl #32
    // 0xcf04c0: ldr             x16, [fp, #0x10]
    // 0xcf04c4: stp             x16, x0, [SP, #-0x10]!
    // 0xcf04c8: r0 = _handleSetText()
    //     0xcf04c8: bl              #0xcf04e4  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_handleSetText
    // 0xcf04cc: add             SP, SP, #0x10
    // 0xcf04d0: LeaveFrame
    //     0xcf04d0: mov             SP, fp
    //     0xcf04d4: ldp             fp, lr, [SP], #0x10
    // 0xcf04d8: ret
    //     0xcf04d8: ret             
    // 0xcf04dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf04dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf04e0: b               #0xcf04b8
  }
  _ _handleSetText(/* No info */) {
    // ** addr: 0xcf04e4, size: 0xc4
    // 0xcf04e4: EnterFrame
    //     0xcf04e4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf04e8: mov             fp, SP
    // 0xcf04ec: AllocStack(0x18)
    //     0xcf04ec: sub             SP, SP, #0x18
    // 0xcf04f0: CheckStackOverflow
    //     0xcf04f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf04f4: cmp             SP, x16
    //     0xcf04f8: b.ls            #0xcf05a0
    // 0xcf04fc: ldr             x0, [fp, #0x18]
    // 0xcf0500: LoadField: r1 = r0->field_db
    //     0xcf0500: ldur            w1, [x0, #0xdb]
    // 0xcf0504: DecompressPointer r1
    //     0xcf0504: add             x1, x1, HEAP, lsl #32
    // 0xcf0508: ldr             x0, [fp, #0x10]
    // 0xcf050c: stur            x1, [fp, #-0x10]
    // 0xcf0510: LoadField: r2 = r0->field_7
    //     0xcf0510: ldur            w2, [x0, #7]
    // 0xcf0514: DecompressPointer r2
    //     0xcf0514: add             x2, x2, HEAP, lsl #32
    // 0xcf0518: stur            x2, [fp, #-8]
    // 0xcf051c: r0 = TextSelection()
    //     0xcf051c: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xcf0520: mov             x1, x0
    // 0xcf0524: r0 = Instance_TextAffinity
    //     0xcf0524: ldr             x0, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0xcf0528: stur            x1, [fp, #-0x18]
    // 0xcf052c: StoreField: r1->field_27 = r0
    //     0xcf052c: stur            w0, [x1, #0x27]
    // 0xcf0530: ldur            x0, [fp, #-8]
    // 0xcf0534: r2 = LoadInt32Instr(r0)
    //     0xcf0534: sbfx            x2, x0, #1, #0x1f
    // 0xcf0538: StoreField: r1->field_17 = r2
    //     0xcf0538: stur            x2, [x1, #0x17]
    // 0xcf053c: StoreField: r1->field_1f = r2
    //     0xcf053c: stur            x2, [x1, #0x1f]
    // 0xcf0540: r0 = false
    //     0xcf0540: add             x0, NULL, #0x30  ; false
    // 0xcf0544: StoreField: r1->field_2b = r0
    //     0xcf0544: stur            w0, [x1, #0x2b]
    // 0xcf0548: StoreField: r1->field_7 = r2
    //     0xcf0548: stur            x2, [x1, #7]
    // 0xcf054c: StoreField: r1->field_f = r2
    //     0xcf054c: stur            x2, [x1, #0xf]
    // 0xcf0550: r0 = TextEditingValue()
    //     0xcf0550: bl              #0x5cb3f0  ; AllocateTextEditingValueStub -> TextEditingValue (size=0x14)
    // 0xcf0554: mov             x1, x0
    // 0xcf0558: ldr             x0, [fp, #0x10]
    // 0xcf055c: StoreField: r1->field_7 = r0
    //     0xcf055c: stur            w0, [x1, #7]
    // 0xcf0560: ldur            x0, [fp, #-0x18]
    // 0xcf0564: StoreField: r1->field_b = r0
    //     0xcf0564: stur            w0, [x1, #0xb]
    // 0xcf0568: r0 = Instance_TextRange
    //     0xcf0568: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c2e0] Obj!TextRange@b5c921
    //     0xcf056c: ldr             x0, [x0, #0x2e0]
    // 0xcf0570: StoreField: r1->field_f = r0
    //     0xcf0570: stur            w0, [x1, #0xf]
    // 0xcf0574: ldur            x16, [fp, #-0x10]
    // 0xcf0578: stp             x1, x16, [SP, #-0x10]!
    // 0xcf057c: r16 = Instance_SelectionChangedCause
    //     0xcf057c: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6b8] Obj!SelectionChangedCause@b63e71
    //     0xcf0580: ldr             x16, [x16, #0x6b8]
    // 0xcf0584: SaveReg r16
    //     0xcf0584: str             x16, [SP, #-8]!
    // 0xcf0588: r0 = userUpdateTextEditingValue()
    //     0xcf0588: bl              #0x7a9d78  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableTextState::userUpdateTextEditingValue
    // 0xcf058c: add             SP, SP, #0x18
    // 0xcf0590: r0 = Null
    //     0xcf0590: mov             x0, NULL
    // 0xcf0594: LeaveFrame
    //     0xcf0594: mov             SP, fp
    //     0xcf0598: ldp             fp, lr, [SP], #0x10
    // 0xcf059c: ret
    //     0xcf059c: ret             
    // 0xcf05a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf05a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf05a4: b               #0xcf04fc
  }
  dynamic _onCaretChanged(dynamic) {
    // ** addr: 0xcf05a8, size: 0x18
    // 0xcf05a8: r4 = 0
    //     0xcf05a8: mov             x4, #0
    // 0xcf05ac: r1 = Function '_onCaretChanged@483409610':.
    //     0xcf05ac: add             x17, PP, #0x56, lsl #12  ; [pp+0x56748] AnonymousClosure: (0xcf05c0), in [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_onCaretChanged (0xcf060c)
    //     0xcf05b0: ldr             x1, [x17, #0x748]
    // 0xcf05b4: r24 = BuildNonGenericMethodExtractorStub
    //     0xcf05b4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xcf05b8: LoadField: r0 = r24->field_17
    //     0xcf05b8: ldur            x0, [x24, #0x17]
    // 0xcf05bc: br              x0
  }
  [closure] void _onCaretChanged(dynamic, Rect) {
    // ** addr: 0xcf05c0, size: 0x4c
    // 0xcf05c0: EnterFrame
    //     0xcf05c0: stp             fp, lr, [SP, #-0x10]!
    //     0xcf05c4: mov             fp, SP
    // 0xcf05c8: ldr             x0, [fp, #0x18]
    // 0xcf05cc: LoadField: r1 = r0->field_17
    //     0xcf05cc: ldur            w1, [x0, #0x17]
    // 0xcf05d0: DecompressPointer r1
    //     0xcf05d0: add             x1, x1, HEAP, lsl #32
    // 0xcf05d4: CheckStackOverflow
    //     0xcf05d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf05d8: cmp             SP, x16
    //     0xcf05dc: b.ls            #0xcf0604
    // 0xcf05e0: LoadField: r0 = r1->field_f
    //     0xcf05e0: ldur            w0, [x1, #0xf]
    // 0xcf05e4: DecompressPointer r0
    //     0xcf05e4: add             x0, x0, HEAP, lsl #32
    // 0xcf05e8: ldr             x16, [fp, #0x10]
    // 0xcf05ec: stp             x16, x0, [SP, #-0x10]!
    // 0xcf05f0: r0 = _onCaretChanged()
    //     0xcf05f0: bl              #0xcf060c  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_onCaretChanged
    // 0xcf05f4: add             SP, SP, #0x10
    // 0xcf05f8: LeaveFrame
    //     0xcf05f8: mov             SP, fp
    //     0xcf05fc: ldp             fp, lr, [SP], #0x10
    // 0xcf0600: ret
    //     0xcf0600: ret             
    // 0xcf0604: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0604: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf0608: b               #0xcf05e0
  }
  _ _onCaretChanged(/* No info */) {
    // ** addr: 0xcf060c, size: 0xcc
    // 0xcf060c: EnterFrame
    //     0xcf060c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf0610: mov             fp, SP
    // 0xcf0614: CheckStackOverflow
    //     0xcf0614: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf0618: cmp             SP, x16
    //     0xcf061c: b.ls            #0xcf06d0
    // 0xcf0620: ldr             x1, [fp, #0x18]
    // 0xcf0624: LoadField: r0 = r1->field_bf
    //     0xcf0624: ldur            w0, [x1, #0xbf]
    // 0xcf0628: DecompressPointer r0
    //     0xcf0628: add             x0, x0, HEAP, lsl #32
    // 0xcf062c: r2 = LoadClassIdInstr(r0)
    //     0xcf062c: ldur            x2, [x0, #-1]
    //     0xcf0630: ubfx            x2, x2, #0xc, #0x14
    // 0xcf0634: ldr             x16, [fp, #0x10]
    // 0xcf0638: stp             x16, x0, [SP, #-0x10]!
    // 0xcf063c: mov             x0, x2
    // 0xcf0640: mov             lr, x0
    // 0xcf0644: ldr             lr, [x21, lr, lsl #3]
    // 0xcf0648: blr             lr
    // 0xcf064c: add             SP, SP, #0x10
    // 0xcf0650: tbz             w0, #4, #0xcf0680
    // 0xcf0654: ldr             x1, [fp, #0x18]
    // 0xcf0658: LoadField: r0 = r1->field_c3
    //     0xcf0658: ldur            w0, [x1, #0xc3]
    // 0xcf065c: DecompressPointer r0
    //     0xcf065c: add             x0, x0, HEAP, lsl #32
    // 0xcf0660: cmp             w0, NULL
    // 0xcf0664: b.eq            #0xcf0680
    // 0xcf0668: ldr             x16, [fp, #0x10]
    // 0xcf066c: stp             x16, x0, [SP, #-0x10]!
    // 0xcf0670: ClosureCall
    //     0xcf0670: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcf0674: ldur            x2, [x0, #0x1f]
    //     0xcf0678: blr             x2
    // 0xcf067c: add             SP, SP, #0x10
    // 0xcf0680: ldr             x1, [fp, #0x18]
    // 0xcf0684: LoadField: r2 = r1->field_c3
    //     0xcf0684: ldur            w2, [x1, #0xc3]
    // 0xcf0688: DecompressPointer r2
    //     0xcf0688: add             x2, x2, HEAP, lsl #32
    // 0xcf068c: cmp             w2, NULL
    // 0xcf0690: b.ne            #0xcf069c
    // 0xcf0694: r0 = Null
    //     0xcf0694: mov             x0, NULL
    // 0xcf0698: b               #0xcf06a4
    // 0xcf069c: ldr             x2, [fp, #0x10]
    // 0xcf06a0: mov             x0, x2
    // 0xcf06a4: StoreField: r1->field_bf = r0
    //     0xcf06a4: stur            w0, [x1, #0xbf]
    //     0xcf06a8: ldurb           w16, [x1, #-1]
    //     0xcf06ac: ldurb           w17, [x0, #-1]
    //     0xcf06b0: and             x16, x17, x16, lsr #2
    //     0xcf06b4: tst             x16, HEAP, lsr #32
    //     0xcf06b8: b.eq            #0xcf06c0
    //     0xcf06bc: bl              #0xd6826c
    // 0xcf06c0: r0 = Null
    //     0xcf06c0: mov             x0, NULL
    // 0xcf06c4: LeaveFrame
    //     0xcf06c4: mov             SP, fp
    //     0xcf06c8: ldp             fp, lr, [SP], #0x10
    // 0xcf06cc: ret
    //     0xcf06cc: ret             
    // 0xcf06d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf06d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf06d4: b               #0xcf0620
  }
}

// class id: 4838, size: 0x28, field offset: 0x24
class _CompositeRenderEditablePainter extends ExtendedRenderEditablePainter {

  _ addListener(/* No info */) {
    // ** addr: 0x6e76b0, size: 0x19c
    // 0x6e76b0: EnterFrame
    //     0x6e76b0: stp             fp, lr, [SP, #-0x10]!
    //     0x6e76b4: mov             fp, SP
    // 0x6e76b8: AllocStack(0x30)
    //     0x6e76b8: sub             SP, SP, #0x30
    // 0x6e76bc: CheckStackOverflow
    //     0x6e76bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e76c0: cmp             SP, x16
    //     0x6e76c4: b.ls            #0x6e783c
    // 0x6e76c8: ldr             x0, [fp, #0x18]
    // 0x6e76cc: LoadField: r1 = r0->field_23
    //     0x6e76cc: ldur            w1, [x0, #0x23]
    // 0x6e76d0: DecompressPointer r1
    //     0x6e76d0: add             x1, x1, HEAP, lsl #32
    // 0x6e76d4: stur            x1, [fp, #-0x20]
    // 0x6e76d8: LoadField: r2 = r1->field_7
    //     0x6e76d8: ldur            w2, [x1, #7]
    // 0x6e76dc: DecompressPointer r2
    //     0x6e76dc: add             x2, x2, HEAP, lsl #32
    // 0x6e76e0: stur            x2, [fp, #-0x18]
    // 0x6e76e4: LoadField: r0 = r1->field_b
    //     0x6e76e4: ldur            w0, [x1, #0xb]
    // 0x6e76e8: DecompressPointer r0
    //     0x6e76e8: add             x0, x0, HEAP, lsl #32
    // 0x6e76ec: r3 = LoadInt32Instr(r0)
    //     0x6e76ec: sbfx            x3, x0, #1, #0x1f
    // 0x6e76f0: stur            x3, [fp, #-0x10]
    // 0x6e76f4: r4 = 0
    //     0x6e76f4: mov             x4, #0
    // 0x6e76f8: stur            x4, [fp, #-8]
    // 0x6e76fc: CheckStackOverflow
    //     0x6e76fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e7700: cmp             SP, x16
    //     0x6e7704: b.ls            #0x6e7844
    // 0x6e7708: r0 = LoadClassIdInstr(r1)
    //     0x6e7708: ldur            x0, [x1, #-1]
    //     0x6e770c: ubfx            x0, x0, #0xc, #0x14
    // 0x6e7710: SaveReg r1
    //     0x6e7710: str             x1, [SP, #-8]!
    // 0x6e7714: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x6e7714: mov             x17, #0xb8ea
    //     0x6e7718: add             lr, x0, x17
    //     0x6e771c: ldr             lr, [x21, lr, lsl #3]
    //     0x6e7720: blr             lr
    // 0x6e7724: add             SP, SP, #8
    // 0x6e7728: r1 = LoadInt32Instr(r0)
    //     0x6e7728: sbfx            x1, x0, #1, #0x1f
    //     0x6e772c: tbz             w0, #0, #0x6e7734
    //     0x6e7730: ldur            x1, [x0, #7]
    // 0x6e7734: ldur            x2, [fp, #-0x10]
    // 0x6e7738: cmp             x2, x1
    // 0x6e773c: b.ne            #0x6e7824
    // 0x6e7740: ldur            x3, [fp, #-0x20]
    // 0x6e7744: ldur            x4, [fp, #-8]
    // 0x6e7748: cmp             x4, x1
    // 0x6e774c: b.lt            #0x6e7760
    // 0x6e7750: r0 = Null
    //     0x6e7750: mov             x0, NULL
    // 0x6e7754: LeaveFrame
    //     0x6e7754: mov             SP, fp
    //     0x6e7758: ldp             fp, lr, [SP], #0x10
    // 0x6e775c: ret
    //     0x6e775c: ret             
    // 0x6e7760: r0 = BoxInt64Instr(r4)
    //     0x6e7760: sbfiz           x0, x4, #1, #0x1f
    //     0x6e7764: cmp             x4, x0, asr #1
    //     0x6e7768: b.eq            #0x6e7774
    //     0x6e776c: bl              #0xd69bb8
    //     0x6e7770: stur            x4, [x0, #7]
    // 0x6e7774: r1 = LoadClassIdInstr(r3)
    //     0x6e7774: ldur            x1, [x3, #-1]
    //     0x6e7778: ubfx            x1, x1, #0xc, #0x14
    // 0x6e777c: stp             x0, x3, [SP, #-0x10]!
    // 0x6e7780: mov             x0, x1
    // 0x6e7784: r0 = GDT[cid_x0 + 0xd175]()
    //     0x6e7784: mov             x17, #0xd175
    //     0x6e7788: add             lr, x0, x17
    //     0x6e778c: ldr             lr, [x21, lr, lsl #3]
    //     0x6e7790: blr             lr
    // 0x6e7794: add             SP, SP, #0x10
    // 0x6e7798: mov             x3, x0
    // 0x6e779c: ldur            x0, [fp, #-8]
    // 0x6e77a0: stur            x3, [fp, #-0x30]
    // 0x6e77a4: add             x4, x0, #1
    // 0x6e77a8: stur            x4, [fp, #-0x28]
    // 0x6e77ac: cmp             w3, NULL
    // 0x6e77b0: b.ne            #0x6e77e4
    // 0x6e77b4: mov             x0, x3
    // 0x6e77b8: ldur            x2, [fp, #-0x18]
    // 0x6e77bc: r1 = Null
    //     0x6e77bc: mov             x1, NULL
    // 0x6e77c0: cmp             w2, NULL
    // 0x6e77c4: b.eq            #0x6e77e4
    // 0x6e77c8: LoadField: r4 = r2->field_17
    //     0x6e77c8: ldur            w4, [x2, #0x17]
    // 0x6e77cc: DecompressPointer r4
    //     0x6e77cc: add             x4, x4, HEAP, lsl #32
    // 0x6e77d0: r8 = X0
    //     0x6e77d0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6e77d4: LoadField: r9 = r4->field_7
    //     0x6e77d4: ldur            x9, [x4, #7]
    // 0x6e77d8: r3 = Null
    //     0x6e77d8: add             x3, PP, #0x55, lsl #12  ; [pp+0x55b00] Null
    //     0x6e77dc: ldr             x3, [x3, #0xb00]
    // 0x6e77e0: blr             x9
    // 0x6e77e4: ldur            x0, [fp, #-0x30]
    // 0x6e77e8: r1 = LoadClassIdInstr(r0)
    //     0x6e77e8: ldur            x1, [x0, #-1]
    //     0x6e77ec: ubfx            x1, x1, #0xc, #0x14
    // 0x6e77f0: ldr             x16, [fp, #0x10]
    // 0x6e77f4: stp             x16, x0, [SP, #-0x10]!
    // 0x6e77f8: mov             x0, x1
    // 0x6e77fc: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x6e77fc: mov             x17, #0xc3ab
    //     0x6e7800: add             lr, x0, x17
    //     0x6e7804: ldr             lr, [x21, lr, lsl #3]
    //     0x6e7808: blr             lr
    // 0x6e780c: add             SP, SP, #0x10
    // 0x6e7810: ldur            x4, [fp, #-0x28]
    // 0x6e7814: ldur            x1, [fp, #-0x20]
    // 0x6e7818: ldur            x2, [fp, #-0x18]
    // 0x6e781c: ldur            x3, [fp, #-0x10]
    // 0x6e7820: b               #0x6e76f8
    // 0x6e7824: ldur            x0, [fp, #-0x20]
    // 0x6e7828: r0 = ConcurrentModificationError()
    //     0x6e7828: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x6e782c: ldur            x3, [fp, #-0x20]
    // 0x6e7830: StoreField: r0->field_b = r3
    //     0x6e7830: stur            w3, [x0, #0xb]
    // 0x6e7834: r0 = Throw()
    //     0x6e7834: bl              #0xd67e38  ; ThrowStub
    // 0x6e7838: brk             #0
    // 0x6e783c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e783c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e7840: b               #0x6e76c8
    // 0x6e7844: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e7844: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e7848: b               #0x6e7708
  }
  _ removeListener(/* No info */) {
    // ** addr: 0x6e7fb8, size: 0x19c
    // 0x6e7fb8: EnterFrame
    //     0x6e7fb8: stp             fp, lr, [SP, #-0x10]!
    //     0x6e7fbc: mov             fp, SP
    // 0x6e7fc0: AllocStack(0x30)
    //     0x6e7fc0: sub             SP, SP, #0x30
    // 0x6e7fc4: CheckStackOverflow
    //     0x6e7fc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e7fc8: cmp             SP, x16
    //     0x6e7fcc: b.ls            #0x6e8144
    // 0x6e7fd0: ldr             x0, [fp, #0x18]
    // 0x6e7fd4: LoadField: r1 = r0->field_23
    //     0x6e7fd4: ldur            w1, [x0, #0x23]
    // 0x6e7fd8: DecompressPointer r1
    //     0x6e7fd8: add             x1, x1, HEAP, lsl #32
    // 0x6e7fdc: stur            x1, [fp, #-0x20]
    // 0x6e7fe0: LoadField: r2 = r1->field_7
    //     0x6e7fe0: ldur            w2, [x1, #7]
    // 0x6e7fe4: DecompressPointer r2
    //     0x6e7fe4: add             x2, x2, HEAP, lsl #32
    // 0x6e7fe8: stur            x2, [fp, #-0x18]
    // 0x6e7fec: LoadField: r0 = r1->field_b
    //     0x6e7fec: ldur            w0, [x1, #0xb]
    // 0x6e7ff0: DecompressPointer r0
    //     0x6e7ff0: add             x0, x0, HEAP, lsl #32
    // 0x6e7ff4: r3 = LoadInt32Instr(r0)
    //     0x6e7ff4: sbfx            x3, x0, #1, #0x1f
    // 0x6e7ff8: stur            x3, [fp, #-0x10]
    // 0x6e7ffc: r4 = 0
    //     0x6e7ffc: mov             x4, #0
    // 0x6e8000: stur            x4, [fp, #-8]
    // 0x6e8004: CheckStackOverflow
    //     0x6e8004: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e8008: cmp             SP, x16
    //     0x6e800c: b.ls            #0x6e814c
    // 0x6e8010: r0 = LoadClassIdInstr(r1)
    //     0x6e8010: ldur            x0, [x1, #-1]
    //     0x6e8014: ubfx            x0, x0, #0xc, #0x14
    // 0x6e8018: SaveReg r1
    //     0x6e8018: str             x1, [SP, #-8]!
    // 0x6e801c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x6e801c: mov             x17, #0xb8ea
    //     0x6e8020: add             lr, x0, x17
    //     0x6e8024: ldr             lr, [x21, lr, lsl #3]
    //     0x6e8028: blr             lr
    // 0x6e802c: add             SP, SP, #8
    // 0x6e8030: r1 = LoadInt32Instr(r0)
    //     0x6e8030: sbfx            x1, x0, #1, #0x1f
    //     0x6e8034: tbz             w0, #0, #0x6e803c
    //     0x6e8038: ldur            x1, [x0, #7]
    // 0x6e803c: ldur            x2, [fp, #-0x10]
    // 0x6e8040: cmp             x2, x1
    // 0x6e8044: b.ne            #0x6e812c
    // 0x6e8048: ldur            x3, [fp, #-0x20]
    // 0x6e804c: ldur            x4, [fp, #-8]
    // 0x6e8050: cmp             x4, x1
    // 0x6e8054: b.lt            #0x6e8068
    // 0x6e8058: r0 = Null
    //     0x6e8058: mov             x0, NULL
    // 0x6e805c: LeaveFrame
    //     0x6e805c: mov             SP, fp
    //     0x6e8060: ldp             fp, lr, [SP], #0x10
    // 0x6e8064: ret
    //     0x6e8064: ret             
    // 0x6e8068: r0 = BoxInt64Instr(r4)
    //     0x6e8068: sbfiz           x0, x4, #1, #0x1f
    //     0x6e806c: cmp             x4, x0, asr #1
    //     0x6e8070: b.eq            #0x6e807c
    //     0x6e8074: bl              #0xd69bb8
    //     0x6e8078: stur            x4, [x0, #7]
    // 0x6e807c: r1 = LoadClassIdInstr(r3)
    //     0x6e807c: ldur            x1, [x3, #-1]
    //     0x6e8080: ubfx            x1, x1, #0xc, #0x14
    // 0x6e8084: stp             x0, x3, [SP, #-0x10]!
    // 0x6e8088: mov             x0, x1
    // 0x6e808c: r0 = GDT[cid_x0 + 0xd175]()
    //     0x6e808c: mov             x17, #0xd175
    //     0x6e8090: add             lr, x0, x17
    //     0x6e8094: ldr             lr, [x21, lr, lsl #3]
    //     0x6e8098: blr             lr
    // 0x6e809c: add             SP, SP, #0x10
    // 0x6e80a0: mov             x3, x0
    // 0x6e80a4: ldur            x0, [fp, #-8]
    // 0x6e80a8: stur            x3, [fp, #-0x30]
    // 0x6e80ac: add             x4, x0, #1
    // 0x6e80b0: stur            x4, [fp, #-0x28]
    // 0x6e80b4: cmp             w3, NULL
    // 0x6e80b8: b.ne            #0x6e80ec
    // 0x6e80bc: mov             x0, x3
    // 0x6e80c0: ldur            x2, [fp, #-0x18]
    // 0x6e80c4: r1 = Null
    //     0x6e80c4: mov             x1, NULL
    // 0x6e80c8: cmp             w2, NULL
    // 0x6e80cc: b.eq            #0x6e80ec
    // 0x6e80d0: LoadField: r4 = r2->field_17
    //     0x6e80d0: ldur            w4, [x2, #0x17]
    // 0x6e80d4: DecompressPointer r4
    //     0x6e80d4: add             x4, x4, HEAP, lsl #32
    // 0x6e80d8: r8 = X0
    //     0x6e80d8: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6e80dc: LoadField: r9 = r4->field_7
    //     0x6e80dc: ldur            x9, [x4, #7]
    // 0x6e80e0: r3 = Null
    //     0x6e80e0: add             x3, PP, #0x55, lsl #12  ; [pp+0x55b10] Null
    //     0x6e80e4: ldr             x3, [x3, #0xb10]
    // 0x6e80e8: blr             x9
    // 0x6e80ec: ldur            x0, [fp, #-0x30]
    // 0x6e80f0: r1 = LoadClassIdInstr(r0)
    //     0x6e80f0: ldur            x1, [x0, #-1]
    //     0x6e80f4: ubfx            x1, x1, #0xc, #0x14
    // 0x6e80f8: ldr             x16, [fp, #0x10]
    // 0x6e80fc: stp             x16, x0, [SP, #-0x10]!
    // 0x6e8100: mov             x0, x1
    // 0x6e8104: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0x6e8104: mov             x17, #0xc2d6
    //     0x6e8108: add             lr, x0, x17
    //     0x6e810c: ldr             lr, [x21, lr, lsl #3]
    //     0x6e8110: blr             lr
    // 0x6e8114: add             SP, SP, #0x10
    // 0x6e8118: ldur            x4, [fp, #-0x28]
    // 0x6e811c: ldur            x1, [fp, #-0x20]
    // 0x6e8120: ldur            x2, [fp, #-0x18]
    // 0x6e8124: ldur            x3, [fp, #-0x10]
    // 0x6e8128: b               #0x6e8000
    // 0x6e812c: ldur            x0, [fp, #-0x20]
    // 0x6e8130: r0 = ConcurrentModificationError()
    //     0x6e8130: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x6e8134: ldur            x3, [fp, #-0x20]
    // 0x6e8138: StoreField: r0->field_b = r3
    //     0x6e8138: stur            w3, [x0, #0xb]
    // 0x6e813c: r0 = Throw()
    //     0x6e813c: bl              #0xd67e38  ; ThrowStub
    // 0x6e8140: brk             #0
    // 0x6e8144: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e8144: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e8148: b               #0x6e7fd0
    // 0x6e814c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e814c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e8150: b               #0x6e8010
  }
  _ paint(/* No info */) {
    // ** addr: 0xc4f410, size: 0x1a0
    // 0xc4f410: EnterFrame
    //     0xc4f410: stp             fp, lr, [SP, #-0x10]!
    //     0xc4f414: mov             fp, SP
    // 0xc4f418: AllocStack(0x30)
    //     0xc4f418: sub             SP, SP, #0x30
    // 0xc4f41c: CheckStackOverflow
    //     0xc4f41c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4f420: cmp             SP, x16
    //     0xc4f424: b.ls            #0xc4f5a0
    // 0xc4f428: ldr             x0, [fp, #0x20]
    // 0xc4f42c: LoadField: r1 = r0->field_23
    //     0xc4f42c: ldur            w1, [x0, #0x23]
    // 0xc4f430: DecompressPointer r1
    //     0xc4f430: add             x1, x1, HEAP, lsl #32
    // 0xc4f434: stur            x1, [fp, #-0x20]
    // 0xc4f438: LoadField: r2 = r1->field_7
    //     0xc4f438: ldur            w2, [x1, #7]
    // 0xc4f43c: DecompressPointer r2
    //     0xc4f43c: add             x2, x2, HEAP, lsl #32
    // 0xc4f440: stur            x2, [fp, #-0x18]
    // 0xc4f444: LoadField: r0 = r1->field_b
    //     0xc4f444: ldur            w0, [x1, #0xb]
    // 0xc4f448: DecompressPointer r0
    //     0xc4f448: add             x0, x0, HEAP, lsl #32
    // 0xc4f44c: r3 = LoadInt32Instr(r0)
    //     0xc4f44c: sbfx            x3, x0, #1, #0x1f
    // 0xc4f450: stur            x3, [fp, #-0x10]
    // 0xc4f454: r4 = 0
    //     0xc4f454: mov             x4, #0
    // 0xc4f458: stur            x4, [fp, #-8]
    // 0xc4f45c: CheckStackOverflow
    //     0xc4f45c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4f460: cmp             SP, x16
    //     0xc4f464: b.ls            #0xc4f5a8
    // 0xc4f468: r0 = LoadClassIdInstr(r1)
    //     0xc4f468: ldur            x0, [x1, #-1]
    //     0xc4f46c: ubfx            x0, x0, #0xc, #0x14
    // 0xc4f470: SaveReg r1
    //     0xc4f470: str             x1, [SP, #-8]!
    // 0xc4f474: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xc4f474: mov             x17, #0xb8ea
    //     0xc4f478: add             lr, x0, x17
    //     0xc4f47c: ldr             lr, [x21, lr, lsl #3]
    //     0xc4f480: blr             lr
    // 0xc4f484: add             SP, SP, #8
    // 0xc4f488: r1 = LoadInt32Instr(r0)
    //     0xc4f488: sbfx            x1, x0, #1, #0x1f
    //     0xc4f48c: tbz             w0, #0, #0xc4f494
    //     0xc4f490: ldur            x1, [x0, #7]
    // 0xc4f494: ldur            x2, [fp, #-0x10]
    // 0xc4f498: cmp             x2, x1
    // 0xc4f49c: b.ne            #0xc4f588
    // 0xc4f4a0: ldur            x3, [fp, #-0x20]
    // 0xc4f4a4: ldur            x4, [fp, #-8]
    // 0xc4f4a8: cmp             x4, x1
    // 0xc4f4ac: b.lt            #0xc4f4c0
    // 0xc4f4b0: r0 = Null
    //     0xc4f4b0: mov             x0, NULL
    // 0xc4f4b4: LeaveFrame
    //     0xc4f4b4: mov             SP, fp
    //     0xc4f4b8: ldp             fp, lr, [SP], #0x10
    // 0xc4f4bc: ret
    //     0xc4f4bc: ret             
    // 0xc4f4c0: r0 = BoxInt64Instr(r4)
    //     0xc4f4c0: sbfiz           x0, x4, #1, #0x1f
    //     0xc4f4c4: cmp             x4, x0, asr #1
    //     0xc4f4c8: b.eq            #0xc4f4d4
    //     0xc4f4cc: bl              #0xd69bb8
    //     0xc4f4d0: stur            x4, [x0, #7]
    // 0xc4f4d4: r1 = LoadClassIdInstr(r3)
    //     0xc4f4d4: ldur            x1, [x3, #-1]
    //     0xc4f4d8: ubfx            x1, x1, #0xc, #0x14
    // 0xc4f4dc: stp             x0, x3, [SP, #-0x10]!
    // 0xc4f4e0: mov             x0, x1
    // 0xc4f4e4: r0 = GDT[cid_x0 + 0xd175]()
    //     0xc4f4e4: mov             x17, #0xd175
    //     0xc4f4e8: add             lr, x0, x17
    //     0xc4f4ec: ldr             lr, [x21, lr, lsl #3]
    //     0xc4f4f0: blr             lr
    // 0xc4f4f4: add             SP, SP, #0x10
    // 0xc4f4f8: mov             x3, x0
    // 0xc4f4fc: ldur            x0, [fp, #-8]
    // 0xc4f500: stur            x3, [fp, #-0x30]
    // 0xc4f504: add             x4, x0, #1
    // 0xc4f508: stur            x4, [fp, #-0x28]
    // 0xc4f50c: cmp             w3, NULL
    // 0xc4f510: b.ne            #0xc4f544
    // 0xc4f514: mov             x0, x3
    // 0xc4f518: ldur            x2, [fp, #-0x18]
    // 0xc4f51c: r1 = Null
    //     0xc4f51c: mov             x1, NULL
    // 0xc4f520: cmp             w2, NULL
    // 0xc4f524: b.eq            #0xc4f544
    // 0xc4f528: LoadField: r4 = r2->field_17
    //     0xc4f528: ldur            w4, [x2, #0x17]
    // 0xc4f52c: DecompressPointer r4
    //     0xc4f52c: add             x4, x4, HEAP, lsl #32
    // 0xc4f530: r8 = X0
    //     0xc4f530: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xc4f534: LoadField: r9 = r4->field_7
    //     0xc4f534: ldur            x9, [x4, #7]
    // 0xc4f538: r3 = Null
    //     0xc4f538: add             x3, PP, #0x56, lsl #12  ; [pp+0x56918] Null
    //     0xc4f53c: ldr             x3, [x3, #0x918]
    // 0xc4f540: blr             x9
    // 0xc4f544: ldur            x0, [fp, #-0x30]
    // 0xc4f548: r1 = LoadClassIdInstr(r0)
    //     0xc4f548: ldur            x1, [x0, #-1]
    //     0xc4f54c: ubfx            x1, x1, #0xc, #0x14
    // 0xc4f550: ldr             x16, [fp, #0x18]
    // 0xc4f554: stp             x16, x0, [SP, #-0x10]!
    // 0xc4f558: ldr             x16, [fp, #0x10]
    // 0xc4f55c: SaveReg r16
    //     0xc4f55c: str             x16, [SP, #-8]!
    // 0xc4f560: mov             x0, x1
    // 0xc4f564: r0 = GDT[cid_x0 + 0x67c]()
    //     0xc4f564: add             lr, x0, #0x67c
    //     0xc4f568: ldr             lr, [x21, lr, lsl #3]
    //     0xc4f56c: blr             lr
    // 0xc4f570: add             SP, SP, #0x18
    // 0xc4f574: ldur            x4, [fp, #-0x28]
    // 0xc4f578: ldur            x1, [fp, #-0x20]
    // 0xc4f57c: ldur            x2, [fp, #-0x18]
    // 0xc4f580: ldur            x3, [fp, #-0x10]
    // 0xc4f584: b               #0xc4f458
    // 0xc4f588: ldur            x0, [fp, #-0x20]
    // 0xc4f58c: r0 = ConcurrentModificationError()
    //     0xc4f58c: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xc4f590: ldur            x3, [fp, #-0x20]
    // 0xc4f594: StoreField: r0->field_b = r3
    //     0xc4f594: stur            w3, [x0, #0xb]
    // 0xc4f598: r0 = Throw()
    //     0xc4f598: bl              #0xd67e38  ; ThrowStub
    // 0xc4f59c: brk             #0
    // 0xc4f5a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4f5a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4f5a4: b               #0xc4f428
    // 0xc4f5a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4f5a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4f5ac: b               #0xc4f468
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xc50010, size: 0x304
    // 0xc50010: EnterFrame
    //     0xc50010: stp             fp, lr, [SP, #-0x10]!
    //     0xc50014: mov             fp, SP
    // 0xc50018: AllocStack(0x50)
    //     0xc50018: sub             SP, SP, #0x50
    // 0xc5001c: CheckStackOverflow
    //     0xc5001c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc50020: cmp             SP, x16
    //     0xc50024: b.ls            #0xc50304
    // 0xc50028: ldr             x1, [fp, #0x18]
    // 0xc5002c: ldr             x0, [fp, #0x10]
    // 0xc50030: cmp             w0, w1
    // 0xc50034: b.ne            #0xc50048
    // 0xc50038: r0 = false
    //     0xc50038: add             x0, NULL, #0x30  ; false
    // 0xc5003c: LeaveFrame
    //     0xc5003c: mov             SP, fp
    //     0xc50040: ldp             fp, lr, [SP], #0x10
    // 0xc50044: ret
    //     0xc50044: ret             
    // 0xc50048: r2 = LoadClassIdInstr(r0)
    //     0xc50048: ldur            x2, [x0, #-1]
    //     0xc5004c: ubfx            x2, x2, #0xc, #0x14
    // 0xc50050: lsl             x2, x2, #1
    // 0xc50054: r17 = 9676
    //     0xc50054: mov             x17, #0x25cc
    // 0xc50058: cmp             w2, w17
    // 0xc5005c: b.ne            #0xc50090
    // 0xc50060: LoadField: r2 = r0->field_23
    //     0xc50060: ldur            w2, [x0, #0x23]
    // 0xc50064: DecompressPointer r2
    //     0xc50064: add             x2, x2, HEAP, lsl #32
    // 0xc50068: stur            x2, [fp, #-0x38]
    // 0xc5006c: LoadField: r0 = r2->field_b
    //     0xc5006c: ldur            w0, [x2, #0xb]
    // 0xc50070: DecompressPointer r0
    //     0xc50070: add             x0, x0, HEAP, lsl #32
    // 0xc50074: LoadField: r3 = r1->field_23
    //     0xc50074: ldur            w3, [x1, #0x23]
    // 0xc50078: DecompressPointer r3
    //     0xc50078: add             x3, x3, HEAP, lsl #32
    // 0xc5007c: stur            x3, [fp, #-0x30]
    // 0xc50080: LoadField: r1 = r3->field_b
    //     0xc50080: ldur            w1, [x3, #0xb]
    // 0xc50084: DecompressPointer r1
    //     0xc50084: add             x1, x1, HEAP, lsl #32
    // 0xc50088: cmp             w0, w1
    // 0xc5008c: b.eq            #0xc500a0
    // 0xc50090: r0 = true
    //     0xc50090: add             x0, NULL, #0x20  ; true
    // 0xc50094: LeaveFrame
    //     0xc50094: mov             SP, fp
    //     0xc50098: ldp             fp, lr, [SP], #0x10
    // 0xc5009c: ret
    //     0xc5009c: ret             
    // 0xc500a0: LoadField: r4 = r2->field_7
    //     0xc500a0: ldur            w4, [x2, #7]
    // 0xc500a4: DecompressPointer r4
    //     0xc500a4: add             x4, x4, HEAP, lsl #32
    // 0xc500a8: stur            x4, [fp, #-0x28]
    // 0xc500ac: r5 = LoadInt32Instr(r0)
    //     0xc500ac: sbfx            x5, x0, #1, #0x1f
    // 0xc500b0: stur            x5, [fp, #-0x20]
    // 0xc500b4: LoadField: r6 = r3->field_7
    //     0xc500b4: ldur            w6, [x3, #7]
    // 0xc500b8: DecompressPointer r6
    //     0xc500b8: add             x6, x6, HEAP, lsl #32
    // 0xc500bc: stur            x6, [fp, #-0x18]
    // 0xc500c0: r7 = LoadInt32Instr(r1)
    //     0xc500c0: sbfx            x7, x1, #1, #0x1f
    // 0xc500c4: stur            x7, [fp, #-0x10]
    // 0xc500c8: r1 = 0
    //     0xc500c8: mov             x1, #0
    // 0xc500cc: stur            x1, [fp, #-8]
    // 0xc500d0: CheckStackOverflow
    //     0xc500d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc500d4: cmp             SP, x16
    //     0xc500d8: b.ls            #0xc5030c
    // 0xc500dc: r0 = LoadClassIdInstr(r2)
    //     0xc500dc: ldur            x0, [x2, #-1]
    //     0xc500e0: ubfx            x0, x0, #0xc, #0x14
    // 0xc500e4: SaveReg r2
    //     0xc500e4: str             x2, [SP, #-8]!
    // 0xc500e8: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xc500e8: mov             x17, #0xb8ea
    //     0xc500ec: add             lr, x0, x17
    //     0xc500f0: ldr             lr, [x21, lr, lsl #3]
    //     0xc500f4: blr             lr
    // 0xc500f8: add             SP, SP, #8
    // 0xc500fc: r1 = LoadInt32Instr(r0)
    //     0xc500fc: sbfx            x1, x0, #1, #0x1f
    //     0xc50100: tbz             w0, #0, #0xc50108
    //     0xc50104: ldur            x1, [x0, #7]
    // 0xc50108: ldur            x2, [fp, #-0x20]
    // 0xc5010c: cmp             x2, x1
    // 0xc50110: b.ne            #0xc502d4
    // 0xc50114: ldur            x3, [fp, #-0x38]
    // 0xc50118: ldur            x4, [fp, #-8]
    // 0xc5011c: cmp             x4, x1
    // 0xc50120: b.ge            #0xc501c8
    // 0xc50124: ldur            x5, [fp, #-0x30]
    // 0xc50128: ldur            x6, [fp, #-0x10]
    // 0xc5012c: r0 = BoxInt64Instr(r4)
    //     0xc5012c: sbfiz           x0, x4, #1, #0x1f
    //     0xc50130: cmp             x4, x0, asr #1
    //     0xc50134: b.eq            #0xc50140
    //     0xc50138: bl              #0xd69bb8
    //     0xc5013c: stur            x4, [x0, #7]
    // 0xc50140: mov             x1, x0
    // 0xc50144: stur            x1, [fp, #-0x40]
    // 0xc50148: r0 = LoadClassIdInstr(r3)
    //     0xc50148: ldur            x0, [x3, #-1]
    //     0xc5014c: ubfx            x0, x0, #0xc, #0x14
    // 0xc50150: stp             x1, x3, [SP, #-0x10]!
    // 0xc50154: r0 = GDT[cid_x0 + 0xd175]()
    //     0xc50154: mov             x17, #0xd175
    //     0xc50158: add             lr, x0, x17
    //     0xc5015c: ldr             lr, [x21, lr, lsl #3]
    //     0xc50160: blr             lr
    // 0xc50164: add             SP, SP, #0x10
    // 0xc50168: mov             x2, x0
    // 0xc5016c: ldur            x1, [fp, #-8]
    // 0xc50170: stur            x2, [fp, #-0x50]
    // 0xc50174: add             x3, x1, #1
    // 0xc50178: ldur            x4, [fp, #-0x30]
    // 0xc5017c: stur            x3, [fp, #-0x48]
    // 0xc50180: r0 = LoadClassIdInstr(r4)
    //     0xc50180: ldur            x0, [x4, #-1]
    //     0xc50184: ubfx            x0, x0, #0xc, #0x14
    // 0xc50188: SaveReg r4
    //     0xc50188: str             x4, [SP, #-8]!
    // 0xc5018c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xc5018c: mov             x17, #0xb8ea
    //     0xc50190: add             lr, x0, x17
    //     0xc50194: ldr             lr, [x21, lr, lsl #3]
    //     0xc50198: blr             lr
    // 0xc5019c: add             SP, SP, #8
    // 0xc501a0: r1 = LoadInt32Instr(r0)
    //     0xc501a0: sbfx            x1, x0, #1, #0x1f
    //     0xc501a4: tbz             w0, #0, #0xc501ac
    //     0xc501a8: ldur            x1, [x0, #7]
    // 0xc501ac: ldur            x2, [fp, #-0x10]
    // 0xc501b0: cmp             x2, x1
    // 0xc501b4: b.ne            #0xc502ec
    // 0xc501b8: ldur            x3, [fp, #-0x30]
    // 0xc501bc: ldur            x0, [fp, #-8]
    // 0xc501c0: cmp             x0, x1
    // 0xc501c4: b.lt            #0xc501d8
    // 0xc501c8: r0 = false
    //     0xc501c8: add             x0, NULL, #0x30  ; false
    // 0xc501cc: LeaveFrame
    //     0xc501cc: mov             SP, fp
    //     0xc501d0: ldp             fp, lr, [SP], #0x10
    // 0xc501d4: ret
    //     0xc501d4: ret             
    // 0xc501d8: r0 = LoadClassIdInstr(r3)
    //     0xc501d8: ldur            x0, [x3, #-1]
    //     0xc501dc: ubfx            x0, x0, #0xc, #0x14
    // 0xc501e0: ldur            x16, [fp, #-0x40]
    // 0xc501e4: stp             x16, x3, [SP, #-0x10]!
    // 0xc501e8: r0 = GDT[cid_x0 + 0xd175]()
    //     0xc501e8: mov             x17, #0xd175
    //     0xc501ec: add             lr, x0, x17
    //     0xc501f0: ldr             lr, [x21, lr, lsl #3]
    //     0xc501f4: blr             lr
    // 0xc501f8: add             SP, SP, #0x10
    // 0xc501fc: mov             x3, x0
    // 0xc50200: stur            x3, [fp, #-0x40]
    // 0xc50204: cmp             w3, NULL
    // 0xc50208: b.ne            #0xc5023c
    // 0xc5020c: mov             x0, x3
    // 0xc50210: ldur            x2, [fp, #-0x18]
    // 0xc50214: r1 = Null
    //     0xc50214: mov             x1, NULL
    // 0xc50218: cmp             w2, NULL
    // 0xc5021c: b.eq            #0xc5023c
    // 0xc50220: LoadField: r4 = r2->field_17
    //     0xc50220: ldur            w4, [x2, #0x17]
    // 0xc50224: DecompressPointer r4
    //     0xc50224: add             x4, x4, HEAP, lsl #32
    // 0xc50228: r8 = X0
    //     0xc50228: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xc5022c: LoadField: r9 = r4->field_7
    //     0xc5022c: ldur            x9, [x4, #7]
    // 0xc50230: r3 = Null
    //     0xc50230: add             x3, PP, #0x55, lsl #12  ; [pp+0x55b20] Null
    //     0xc50234: ldr             x3, [x3, #0xb20]
    // 0xc50238: blr             x9
    // 0xc5023c: ldur            x3, [fp, #-0x50]
    // 0xc50240: cmp             w3, NULL
    // 0xc50244: b.ne            #0xc50278
    // 0xc50248: mov             x0, x3
    // 0xc5024c: ldur            x2, [fp, #-0x28]
    // 0xc50250: r1 = Null
    //     0xc50250: mov             x1, NULL
    // 0xc50254: cmp             w2, NULL
    // 0xc50258: b.eq            #0xc50278
    // 0xc5025c: LoadField: r4 = r2->field_17
    //     0xc5025c: ldur            w4, [x2, #0x17]
    // 0xc50260: DecompressPointer r4
    //     0xc50260: add             x4, x4, HEAP, lsl #32
    // 0xc50264: r8 = X0
    //     0xc50264: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xc50268: LoadField: r9 = r4->field_7
    //     0xc50268: ldur            x9, [x4, #7]
    // 0xc5026c: r3 = Null
    //     0xc5026c: add             x3, PP, #0x55, lsl #12  ; [pp+0x55b30] Null
    //     0xc50270: ldr             x3, [x3, #0xb30]
    // 0xc50274: blr             x9
    // 0xc50278: ldur            x0, [fp, #-0x40]
    // 0xc5027c: r1 = LoadClassIdInstr(r0)
    //     0xc5027c: ldur            x1, [x0, #-1]
    //     0xc50280: ubfx            x1, x1, #0xc, #0x14
    // 0xc50284: ldur            x16, [fp, #-0x50]
    // 0xc50288: stp             x16, x0, [SP, #-0x10]!
    // 0xc5028c: mov             x0, x1
    // 0xc50290: r0 = GDT[cid_x0 + 0x66c]()
    //     0xc50290: add             lr, x0, #0x66c
    //     0xc50294: ldr             lr, [x21, lr, lsl #3]
    //     0xc50298: blr             lr
    // 0xc5029c: add             SP, SP, #0x10
    // 0xc502a0: tbnz            w0, #4, #0xc502b4
    // 0xc502a4: r0 = true
    //     0xc502a4: add             x0, NULL, #0x20  ; true
    // 0xc502a8: LeaveFrame
    //     0xc502a8: mov             SP, fp
    //     0xc502ac: ldp             fp, lr, [SP], #0x10
    // 0xc502b0: ret
    //     0xc502b0: ret             
    // 0xc502b4: ldur            x1, [fp, #-0x48]
    // 0xc502b8: ldur            x2, [fp, #-0x38]
    // 0xc502bc: ldur            x3, [fp, #-0x30]
    // 0xc502c0: ldur            x4, [fp, #-0x28]
    // 0xc502c4: ldur            x6, [fp, #-0x18]
    // 0xc502c8: ldur            x5, [fp, #-0x20]
    // 0xc502cc: ldur            x7, [fp, #-0x10]
    // 0xc502d0: b               #0xc500cc
    // 0xc502d4: ldur            x0, [fp, #-0x38]
    // 0xc502d8: r0 = ConcurrentModificationError()
    //     0xc502d8: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xc502dc: ldur            x3, [fp, #-0x38]
    // 0xc502e0: StoreField: r0->field_b = r3
    //     0xc502e0: stur            w3, [x0, #0xb]
    // 0xc502e4: r0 = Throw()
    //     0xc502e4: bl              #0xd67e38  ; ThrowStub
    // 0xc502e8: brk             #0
    // 0xc502ec: ldur            x0, [fp, #-0x30]
    // 0xc502f0: r0 = ConcurrentModificationError()
    //     0xc502f0: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xc502f4: ldur            x3, [fp, #-0x30]
    // 0xc502f8: StoreField: r0->field_b = r3
    //     0xc502f8: stur            w3, [x0, #0xb]
    // 0xc502fc: r0 = Throw()
    //     0xc502fc: bl              #0xd67e38  ; ThrowStub
    // 0xc50300: brk             #0
    // 0xc50304: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc50304: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc50308: b               #0xc50028
    // 0xc5030c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5030c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc50310: b               #0xc500dc
  }
}

// class id: 4839, size: 0x4c, field offset: 0x24
class _FloatingCursorPainter extends ExtendedRenderEditablePainter {

  late final Paint floatingCursorPaint; // offset: 0x34

  _ _FloatingCursorPainter(/* No info */) {
    // ** addr: 0x65323c, size: 0x108
    // 0x65323c: EnterFrame
    //     0x65323c: stp             fp, lr, [SP, #-0x10]!
    //     0x653240: mov             fp, SP
    // 0x653244: AllocStack(0x8)
    //     0x653244: sub             SP, SP, #8
    // 0x653248: r3 = true
    //     0x653248: add             x3, NULL, #0x20  ; true
    // 0x65324c: r2 = false
    //     0x65324c: add             x2, NULL, #0x30  ; false
    // 0x653250: r1 = Sentinel
    //     0x653250: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x653254: r0 = Instance_Offset
    //     0x653254: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x653258: CheckStackOverflow
    //     0x653258: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65325c: cmp             SP, x16
    //     0x653260: b.ls            #0x65333c
    // 0x653264: ldr             x4, [fp, #0x18]
    // 0x653268: StoreField: r4->field_23 = r3
    //     0x653268: stur            w3, [x4, #0x23]
    // 0x65326c: StoreField: r4->field_2b = r2
    //     0x65326c: stur            w2, [x4, #0x2b]
    // 0x653270: StoreField: r4->field_33 = r1
    //     0x653270: stur            w1, [x4, #0x33]
    // 0x653274: StoreField: r4->field_3f = r0
    //     0x653274: stur            w0, [x4, #0x3f]
    // 0x653278: r16 = 112
    //     0x653278: mov             x16, #0x70
    // 0x65327c: stp             x16, NULL, [SP, #-0x10]!
    // 0x653280: r0 = ByteData()
    //     0x653280: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x653284: add             SP, SP, #0x10
    // 0x653288: stur            x0, [fp, #-8]
    // 0x65328c: r0 = Paint()
    //     0x65328c: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x653290: mov             x1, x0
    // 0x653294: ldur            x0, [fp, #-8]
    // 0x653298: StoreField: r1->field_7 = r0
    //     0x653298: stur            w0, [x1, #7]
    // 0x65329c: mov             x0, x1
    // 0x6532a0: ldr             x1, [fp, #0x18]
    // 0x6532a4: StoreField: r1->field_2f = r0
    //     0x6532a4: stur            w0, [x1, #0x2f]
    //     0x6532a8: ldurb           w16, [x1, #-1]
    //     0x6532ac: ldurb           w17, [x0, #-1]
    //     0x6532b0: and             x16, x17, x16, lsr #2
    //     0x6532b4: tst             x16, HEAP, lsr #32
    //     0x6532b8: b.eq            #0x6532c0
    //     0x6532bc: bl              #0xd6826c
    // 0x6532c0: ldr             x0, [fp, #0x10]
    // 0x6532c4: StoreField: r1->field_27 = r0
    //     0x6532c4: stur            w0, [x1, #0x27]
    //     0x6532c8: ldurb           w16, [x1, #-1]
    //     0x6532cc: ldurb           w17, [x0, #-1]
    //     0x6532d0: and             x16, x17, x16, lsr #2
    //     0x6532d4: tst             x16, HEAP, lsr #32
    //     0x6532d8: b.eq            #0x6532e0
    //     0x6532dc: bl              #0xd6826c
    // 0x6532e0: r0 = 0
    //     0x6532e0: mov             x0, #0
    // 0x6532e4: StoreField: r1->field_7 = r0
    //     0x6532e4: stur            x0, [x1, #7]
    // 0x6532e8: StoreField: r1->field_13 = r0
    //     0x6532e8: stur            x0, [x1, #0x13]
    // 0x6532ec: StoreField: r1->field_1b = r0
    //     0x6532ec: stur            x0, [x1, #0x1b]
    // 0x6532f0: r0 = InitLateStaticField(0xac0) // [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_emptyListeners
    //     0x6532f0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6532f4: ldr             x0, [x0, #0x1580]
    //     0x6532f8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6532fc: cmp             w0, w16
    //     0x653300: b.ne            #0x65330c
    //     0x653304: ldr             x2, [PP, #0x44a0]  ; [pp+0x44a0] Field <ChangeNotifier._emptyListeners@171329750>: static late final (offset: 0xac0)
    //     0x653308: bl              #0xd67cdc
    // 0x65330c: ldr             x1, [fp, #0x18]
    // 0x653310: StoreField: r1->field_f = r0
    //     0x653310: stur            w0, [x1, #0xf]
    //     0x653314: ldurb           w16, [x1, #-1]
    //     0x653318: ldurb           w17, [x0, #-1]
    //     0x65331c: and             x16, x17, x16, lsr #2
    //     0x653320: tst             x16, HEAP, lsr #32
    //     0x653324: b.eq            #0x65332c
    //     0x653328: bl              #0xd6826c
    // 0x65332c: r0 = Null
    //     0x65332c: mov             x0, NULL
    // 0x653330: LeaveFrame
    //     0x653330: mov             SP, fp
    //     0x653334: ldp             fp, lr, [SP], #0x10
    // 0x653338: ret
    //     0x653338: ret             
    // 0x65333c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65333c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x653340: b               #0x653264
  }
  set _ cursorOffset=(/* No info */) {
    // ** addr: 0x6def98, size: 0x8c
    // 0x6def98: EnterFrame
    //     0x6def98: stp             fp, lr, [SP, #-0x10]!
    //     0x6def9c: mov             fp, SP
    // 0x6defa0: CheckStackOverflow
    //     0x6defa0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6defa4: cmp             SP, x16
    //     0x6defa8: b.ls            #0x6df01c
    // 0x6defac: ldr             x0, [fp, #0x18]
    // 0x6defb0: LoadField: r1 = r0->field_3f
    //     0x6defb0: ldur            w1, [x0, #0x3f]
    // 0x6defb4: DecompressPointer r1
    //     0x6defb4: add             x1, x1, HEAP, lsl #32
    // 0x6defb8: ldr             x16, [fp, #0x10]
    // 0x6defbc: stp             x16, x1, [SP, #-0x10]!
    // 0x6defc0: r0 = ==()
    //     0x6defc0: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0x6defc4: add             SP, SP, #0x10
    // 0x6defc8: tbnz            w0, #4, #0x6defdc
    // 0x6defcc: r0 = Null
    //     0x6defcc: mov             x0, NULL
    // 0x6defd0: LeaveFrame
    //     0x6defd0: mov             SP, fp
    //     0x6defd4: ldp             fp, lr, [SP], #0x10
    // 0x6defd8: ret
    //     0x6defd8: ret             
    // 0x6defdc: ldr             x1, [fp, #0x18]
    // 0x6defe0: ldr             x0, [fp, #0x10]
    // 0x6defe4: StoreField: r1->field_3f = r0
    //     0x6defe4: stur            w0, [x1, #0x3f]
    //     0x6defe8: ldurb           w16, [x1, #-1]
    //     0x6defec: ldurb           w17, [x0, #-1]
    //     0x6deff0: and             x16, x17, x16, lsr #2
    //     0x6deff4: tst             x16, HEAP, lsr #32
    //     0x6deff8: b.eq            #0x6df000
    //     0x6deffc: bl              #0xd6826c
    // 0x6df000: SaveReg r1
    //     0x6df000: str             x1, [SP, #-8]!
    // 0x6df004: r0 = notifyListeners()
    //     0x6df004: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x6df008: add             SP, SP, #8
    // 0x6df00c: r0 = Null
    //     0x6df00c: mov             x0, NULL
    // 0x6df010: LeaveFrame
    //     0x6df010: mov             SP, fp
    //     0x6df014: ldp             fp, lr, [SP], #0x10
    // 0x6df018: ret
    //     0x6df018: ret             
    // 0x6df01c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6df01c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6df020: b               #0x6defac
  }
  set _ cursorRadius=(/* No info */) {
    // ** addr: 0x6df084, size: 0xa0
    // 0x6df084: EnterFrame
    //     0x6df084: stp             fp, lr, [SP, #-0x10]!
    //     0x6df088: mov             fp, SP
    // 0x6df08c: CheckStackOverflow
    //     0x6df08c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6df090: cmp             SP, x16
    //     0x6df094: b.ls            #0x6df11c
    // 0x6df098: ldr             x1, [fp, #0x18]
    // 0x6df09c: LoadField: r0 = r1->field_3b
    //     0x6df09c: ldur            w0, [x1, #0x3b]
    // 0x6df0a0: DecompressPointer r0
    //     0x6df0a0: add             x0, x0, HEAP, lsl #32
    // 0x6df0a4: r2 = LoadClassIdInstr(r0)
    //     0x6df0a4: ldur            x2, [x0, #-1]
    //     0x6df0a8: ubfx            x2, x2, #0xc, #0x14
    // 0x6df0ac: ldr             x16, [fp, #0x10]
    // 0x6df0b0: stp             x16, x0, [SP, #-0x10]!
    // 0x6df0b4: mov             x0, x2
    // 0x6df0b8: mov             lr, x0
    // 0x6df0bc: ldr             lr, [x21, lr, lsl #3]
    // 0x6df0c0: blr             lr
    // 0x6df0c4: add             SP, SP, #0x10
    // 0x6df0c8: tbnz            w0, #4, #0x6df0dc
    // 0x6df0cc: r0 = Null
    //     0x6df0cc: mov             x0, NULL
    // 0x6df0d0: LeaveFrame
    //     0x6df0d0: mov             SP, fp
    //     0x6df0d4: ldp             fp, lr, [SP], #0x10
    // 0x6df0d8: ret
    //     0x6df0d8: ret             
    // 0x6df0dc: ldr             x1, [fp, #0x18]
    // 0x6df0e0: ldr             x0, [fp, #0x10]
    // 0x6df0e4: StoreField: r1->field_3b = r0
    //     0x6df0e4: stur            w0, [x1, #0x3b]
    //     0x6df0e8: ldurb           w16, [x1, #-1]
    //     0x6df0ec: ldurb           w17, [x0, #-1]
    //     0x6df0f0: and             x16, x17, x16, lsr #2
    //     0x6df0f4: tst             x16, HEAP, lsr #32
    //     0x6df0f8: b.eq            #0x6df100
    //     0x6df0fc: bl              #0xd6826c
    // 0x6df100: SaveReg r1
    //     0x6df100: str             x1, [SP, #-8]!
    // 0x6df104: r0 = notifyListeners()
    //     0x6df104: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x6df108: add             SP, SP, #8
    // 0x6df10c: r0 = Null
    //     0x6df10c: mov             x0, NULL
    // 0x6df110: LeaveFrame
    //     0x6df110: mov             SP, fp
    //     0x6df114: ldp             fp, lr, [SP], #0x10
    // 0x6df118: ret
    //     0x6df118: ret             
    // 0x6df11c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6df11c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6df120: b               #0x6df098
  }
  set _ shouldPaint=(/* No info */) {
    // ** addr: 0x6dfc44, size: 0x64
    // 0x6dfc44: EnterFrame
    //     0x6dfc44: stp             fp, lr, [SP, #-0x10]!
    //     0x6dfc48: mov             fp, SP
    // 0x6dfc4c: CheckStackOverflow
    //     0x6dfc4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6dfc50: cmp             SP, x16
    //     0x6dfc54: b.ls            #0x6dfca0
    // 0x6dfc58: ldr             x0, [fp, #0x18]
    // 0x6dfc5c: LoadField: r1 = r0->field_23
    //     0x6dfc5c: ldur            w1, [x0, #0x23]
    // 0x6dfc60: DecompressPointer r1
    //     0x6dfc60: add             x1, x1, HEAP, lsl #32
    // 0x6dfc64: ldr             x2, [fp, #0x10]
    // 0x6dfc68: cmp             w1, w2
    // 0x6dfc6c: b.ne            #0x6dfc80
    // 0x6dfc70: r0 = Null
    //     0x6dfc70: mov             x0, NULL
    // 0x6dfc74: LeaveFrame
    //     0x6dfc74: mov             SP, fp
    //     0x6dfc78: ldp             fp, lr, [SP], #0x10
    // 0x6dfc7c: ret
    //     0x6dfc7c: ret             
    // 0x6dfc80: StoreField: r0->field_23 = r2
    //     0x6dfc80: stur            w2, [x0, #0x23]
    // 0x6dfc84: SaveReg r0
    //     0x6dfc84: str             x0, [SP, #-8]!
    // 0x6dfc88: r0 = notifyListeners()
    //     0x6dfc88: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x6dfc8c: add             SP, SP, #8
    // 0x6dfc90: r0 = Null
    //     0x6dfc90: mov             x0, NULL
    // 0x6dfc94: LeaveFrame
    //     0x6dfc94: mov             SP, fp
    //     0x6dfc98: ldp             fp, lr, [SP], #0x10
    // 0x6dfc9c: ret
    //     0x6dfc9c: ret             
    // 0x6dfca0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6dfca0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6dfca4: b               #0x6dfc58
  }
  set _ caretColor=(/* No info */) {
    // ** addr: 0x6dfe00, size: 0xfc
    // 0x6dfe00: EnterFrame
    //     0x6dfe00: stp             fp, lr, [SP, #-0x10]!
    //     0x6dfe04: mov             fp, SP
    // 0x6dfe08: CheckStackOverflow
    //     0x6dfe08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6dfe0c: cmp             SP, x16
    //     0x6dfe10: b.ls            #0x6dfef4
    // 0x6dfe14: ldr             x2, [fp, #0x18]
    // 0x6dfe18: LoadField: r0 = r2->field_37
    //     0x6dfe18: ldur            w0, [x2, #0x37]
    // 0x6dfe1c: DecompressPointer r0
    //     0x6dfe1c: add             x0, x0, HEAP, lsl #32
    // 0x6dfe20: cmp             w0, NULL
    // 0x6dfe24: b.ne            #0x6dfe30
    // 0x6dfe28: r4 = Null
    //     0x6dfe28: mov             x4, NULL
    // 0x6dfe2c: b               #0x6dfe4c
    // 0x6dfe30: LoadField: r3 = r0->field_7
    //     0x6dfe30: ldur            x3, [x0, #7]
    // 0x6dfe34: r0 = BoxInt64Instr(r3)
    //     0x6dfe34: sbfiz           x0, x3, #1, #0x1f
    //     0x6dfe38: cmp             x3, x0, asr #1
    //     0x6dfe3c: b.eq            #0x6dfe48
    //     0x6dfe40: bl              #0xd69bb8
    //     0x6dfe44: stur            x3, [x0, #7]
    // 0x6dfe48: mov             x4, x0
    // 0x6dfe4c: ldr             x3, [fp, #0x10]
    // 0x6dfe50: LoadField: r5 = r3->field_7
    //     0x6dfe50: ldur            x5, [x3, #7]
    // 0x6dfe54: r0 = BoxInt64Instr(r5)
    //     0x6dfe54: sbfiz           x0, x5, #1, #0x1f
    //     0x6dfe58: cmp             x5, x0, asr #1
    //     0x6dfe5c: b.eq            #0x6dfe68
    //     0x6dfe60: bl              #0xd69bb8
    //     0x6dfe64: stur            x5, [x0, #7]
    // 0x6dfe68: cmp             w4, w0
    // 0x6dfe6c: b.eq            #0x6dfea8
    // 0x6dfe70: and             w16, w4, w0
    // 0x6dfe74: branchIfSmi(r16, 0x6dfeb8)
    //     0x6dfe74: tbz             w16, #0, #0x6dfeb8
    // 0x6dfe78: r16 = LoadClassIdInstr(r4)
    //     0x6dfe78: ldur            x16, [x4, #-1]
    //     0x6dfe7c: ubfx            x16, x16, #0xc, #0x14
    // 0x6dfe80: cmp             x16, #0x3c
    // 0x6dfe84: b.ne            #0x6dfeb8
    // 0x6dfe88: r16 = LoadClassIdInstr(r0)
    //     0x6dfe88: ldur            x16, [x0, #-1]
    //     0x6dfe8c: ubfx            x16, x16, #0xc, #0x14
    // 0x6dfe90: cmp             x16, #0x3c
    // 0x6dfe94: b.ne            #0x6dfeb8
    // 0x6dfe98: LoadField: r16 = r4->field_7
    //     0x6dfe98: ldur            x16, [x4, #7]
    // 0x6dfe9c: LoadField: r17 = r0->field_7
    //     0x6dfe9c: ldur            x17, [x0, #7]
    // 0x6dfea0: cmp             x16, x17
    // 0x6dfea4: b.ne            #0x6dfeb8
    // 0x6dfea8: r0 = Null
    //     0x6dfea8: mov             x0, NULL
    // 0x6dfeac: LeaveFrame
    //     0x6dfeac: mov             SP, fp
    //     0x6dfeb0: ldp             fp, lr, [SP], #0x10
    // 0x6dfeb4: ret
    //     0x6dfeb4: ret             
    // 0x6dfeb8: mov             x0, x3
    // 0x6dfebc: StoreField: r2->field_37 = r0
    //     0x6dfebc: stur            w0, [x2, #0x37]
    //     0x6dfec0: ldurb           w16, [x2, #-1]
    //     0x6dfec4: ldurb           w17, [x0, #-1]
    //     0x6dfec8: and             x16, x17, x16, lsr #2
    //     0x6dfecc: tst             x16, HEAP, lsr #32
    //     0x6dfed0: b.eq            #0x6dfed8
    //     0x6dfed4: bl              #0xd6828c
    // 0x6dfed8: SaveReg r2
    //     0x6dfed8: str             x2, [SP, #-8]!
    // 0x6dfedc: r0 = notifyListeners()
    //     0x6dfedc: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x6dfee0: add             SP, SP, #8
    // 0x6dfee4: r0 = Null
    //     0x6dfee4: mov             x0, NULL
    // 0x6dfee8: LeaveFrame
    //     0x6dfee8: mov             SP, fp
    //     0x6dfeec: ldp             fp, lr, [SP], #0x10
    // 0x6dfef0: ret
    //     0x6dfef0: ret             
    // 0x6dfef4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6dfef4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6dfef8: b               #0x6dfe14
  }
  set _ backgroundCursorColor=(/* No info */) {
    // ** addr: 0x6e3d14, size: 0x100
    // 0x6e3d14: EnterFrame
    //     0x6e3d14: stp             fp, lr, [SP, #-0x10]!
    //     0x6e3d18: mov             fp, SP
    // 0x6e3d1c: CheckStackOverflow
    //     0x6e3d1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e3d20: cmp             SP, x16
    //     0x6e3d24: b.ls            #0x6e3e0c
    // 0x6e3d28: ldr             x2, [fp, #0x18]
    // 0x6e3d2c: LoadField: r0 = r2->field_43
    //     0x6e3d2c: ldur            w0, [x2, #0x43]
    // 0x6e3d30: DecompressPointer r0
    //     0x6e3d30: add             x0, x0, HEAP, lsl #32
    // 0x6e3d34: cmp             w0, NULL
    // 0x6e3d38: b.ne            #0x6e3d44
    // 0x6e3d3c: r3 = Null
    //     0x6e3d3c: mov             x3, NULL
    // 0x6e3d40: b               #0x6e3d68
    // 0x6e3d44: LoadField: r1 = r0->field_f
    //     0x6e3d44: ldur            w1, [x0, #0xf]
    // 0x6e3d48: DecompressPointer r1
    //     0x6e3d48: add             x1, x1, HEAP, lsl #32
    // 0x6e3d4c: LoadField: r3 = r1->field_7
    //     0x6e3d4c: ldur            x3, [x1, #7]
    // 0x6e3d50: r0 = BoxInt64Instr(r3)
    //     0x6e3d50: sbfiz           x0, x3, #1, #0x1f
    //     0x6e3d54: cmp             x3, x0, asr #1
    //     0x6e3d58: b.eq            #0x6e3d64
    //     0x6e3d5c: bl              #0xd69bb8
    //     0x6e3d60: stur            x3, [x0, #7]
    // 0x6e3d64: mov             x3, x0
    // 0x6e3d68: r0 = Instance_Color
    //     0x6e3d68: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3eb98] Obj!Color@b5d671
    //     0x6e3d6c: ldr             x0, [x0, #0xb98]
    // 0x6e3d70: LoadField: r4 = r0->field_7
    //     0x6e3d70: ldur            x4, [x0, #7]
    // 0x6e3d74: r0 = BoxInt64Instr(r4)
    //     0x6e3d74: sbfiz           x0, x4, #1, #0x1f
    //     0x6e3d78: cmp             x4, x0, asr #1
    //     0x6e3d7c: b.eq            #0x6e3d88
    //     0x6e3d80: bl              #0xd69bb8
    //     0x6e3d84: stur            x4, [x0, #7]
    // 0x6e3d88: cmp             w3, w0
    // 0x6e3d8c: b.eq            #0x6e3dc8
    // 0x6e3d90: and             w16, w3, w0
    // 0x6e3d94: branchIfSmi(r16, 0x6e3dd8)
    //     0x6e3d94: tbz             w16, #0, #0x6e3dd8
    // 0x6e3d98: r16 = LoadClassIdInstr(r3)
    //     0x6e3d98: ldur            x16, [x3, #-1]
    //     0x6e3d9c: ubfx            x16, x16, #0xc, #0x14
    // 0x6e3da0: cmp             x16, #0x3c
    // 0x6e3da4: b.ne            #0x6e3dd8
    // 0x6e3da8: r16 = LoadClassIdInstr(r0)
    //     0x6e3da8: ldur            x16, [x0, #-1]
    //     0x6e3dac: ubfx            x16, x16, #0xc, #0x14
    // 0x6e3db0: cmp             x16, #0x3c
    // 0x6e3db4: b.ne            #0x6e3dd8
    // 0x6e3db8: LoadField: r16 = r3->field_7
    //     0x6e3db8: ldur            x16, [x3, #7]
    // 0x6e3dbc: LoadField: r17 = r0->field_7
    //     0x6e3dbc: ldur            x17, [x0, #7]
    // 0x6e3dc0: cmp             x16, x17
    // 0x6e3dc4: b.ne            #0x6e3dd8
    // 0x6e3dc8: r0 = Null
    //     0x6e3dc8: mov             x0, NULL
    // 0x6e3dcc: LeaveFrame
    //     0x6e3dcc: mov             SP, fp
    //     0x6e3dd0: ldp             fp, lr, [SP], #0x10
    // 0x6e3dd4: ret
    //     0x6e3dd4: ret             
    // 0x6e3dd8: r0 = Instance_CupertinoDynamicColor
    //     0x6e3dd8: add             x0, PP, #0x28, lsl #12  ; [pp+0x28dc8] Obj!CupertinoDynamicColor@b5e4f1
    //     0x6e3ddc: ldr             x0, [x0, #0xdc8]
    // 0x6e3de0: StoreField: r2->field_43 = r0
    //     0x6e3de0: stur            w0, [x2, #0x43]
    // 0x6e3de4: LoadField: r0 = r2->field_2b
    //     0x6e3de4: ldur            w0, [x2, #0x2b]
    // 0x6e3de8: DecompressPointer r0
    //     0x6e3de8: add             x0, x0, HEAP, lsl #32
    // 0x6e3dec: tbnz            w0, #4, #0x6e3dfc
    // 0x6e3df0: SaveReg r2
    //     0x6e3df0: str             x2, [SP, #-8]!
    // 0x6e3df4: r0 = notifyListeners()
    //     0x6e3df4: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x6e3df8: add             SP, SP, #8
    // 0x6e3dfc: r0 = Null
    //     0x6e3dfc: mov             x0, NULL
    // 0x6e3e00: LeaveFrame
    //     0x6e3e00: mov             SP, fp
    //     0x6e3e04: ldp             fp, lr, [SP], #0x10
    // 0x6e3e08: ret
    //     0x6e3e08: ret             
    // 0x6e3e0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e3e0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e3e10: b               #0x6e3d28
  }
  _ paint(/* No info */) {
    // ** addr: 0xc4eaa4, size: 0x2a0
    // 0xc4eaa4: EnterFrame
    //     0xc4eaa4: stp             fp, lr, [SP, #-0x10]!
    //     0xc4eaa8: mov             fp, SP
    // 0xc4eaac: AllocStack(0x18)
    //     0xc4eaac: sub             SP, SP, #0x18
    // 0xc4eab0: CheckStackOverflow
    //     0xc4eab0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4eab4: cmp             SP, x16
    //     0xc4eab8: b.ls            #0xc4ed30
    // 0xc4eabc: ldr             x16, [fp, #0x10]
    // 0xc4eac0: SaveReg r16
    //     0xc4eac0: str             x16, [SP, #-8]!
    // 0xc4eac4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xc4eac4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xc4eac8: r0 = getActualSelection()
    //     0xc4eac8: bl              #0x6de46c  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::getActualSelection
    // 0xc4eacc: add             SP, SP, #8
    // 0xc4ead0: LoadField: r1 = r0->field_7
    //     0xc4ead0: ldur            x1, [x0, #7]
    // 0xc4ead4: LoadField: r2 = r0->field_f
    //     0xc4ead4: ldur            x2, [x0, #0xf]
    // 0xc4ead8: cmp             x1, x2
    // 0xc4eadc: b.eq            #0xc4eaf0
    // 0xc4eae0: r0 = Null
    //     0xc4eae0: mov             x0, NULL
    // 0xc4eae4: LeaveFrame
    //     0xc4eae4: mov             SP, fp
    //     0xc4eae8: ldp             fp, lr, [SP], #0x10
    // 0xc4eaec: ret
    //     0xc4eaec: ret             
    // 0xc4eaf0: ldr             x1, [fp, #0x20]
    // 0xc4eaf4: LoadField: r2 = r1->field_47
    //     0xc4eaf4: ldur            w2, [x1, #0x47]
    // 0xc4eaf8: DecompressPointer r2
    //     0xc4eaf8: add             x2, x2, HEAP, lsl #32
    // 0xc4eafc: stur            x2, [fp, #-0x10]
    // 0xc4eb00: cmp             w2, NULL
    // 0xc4eb04: b.ne            #0xc4eb14
    // 0xc4eb08: LoadField: r3 = r1->field_37
    //     0xc4eb08: ldur            w3, [x1, #0x37]
    // 0xc4eb0c: DecompressPointer r3
    //     0xc4eb0c: add             x3, x3, HEAP, lsl #32
    // 0xc4eb10: b               #0xc4eb30
    // 0xc4eb14: LoadField: r3 = r1->field_2b
    //     0xc4eb14: ldur            w3, [x1, #0x2b]
    // 0xc4eb18: DecompressPointer r3
    //     0xc4eb18: add             x3, x3, HEAP, lsl #32
    // 0xc4eb1c: tbnz            w3, #4, #0xc4eb2c
    // 0xc4eb20: LoadField: r3 = r1->field_43
    //     0xc4eb20: ldur            w3, [x1, #0x43]
    // 0xc4eb24: DecompressPointer r3
    //     0xc4eb24: add             x3, x3, HEAP, lsl #32
    // 0xc4eb28: b               #0xc4eb30
    // 0xc4eb2c: r3 = Null
    //     0xc4eb2c: mov             x3, NULL
    // 0xc4eb30: stur            x3, [fp, #-8]
    // 0xc4eb34: cmp             w2, NULL
    // 0xc4eb38: b.ne            #0xc4eb54
    // 0xc4eb3c: SaveReg r0
    //     0xc4eb3c: str             x0, [SP, #-8]!
    // 0xc4eb40: r0 = extent()
    //     0xc4eb40: bl              #0x5223fc  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0xc4eb44: add             SP, SP, #8
    // 0xc4eb48: mov             x2, x0
    // 0xc4eb4c: ldr             x0, [fp, #0x10]
    // 0xc4eb50: b               #0xc4eb74
    // 0xc4eb54: ldr             x0, [fp, #0x10]
    // 0xc4eb58: r17 = 307
    //     0xc4eb58: mov             x17, #0x133
    // 0xc4eb5c: ldr             w1, [x0, x17]
    // 0xc4eb60: DecompressPointer r1
    //     0xc4eb60: add             x1, x1, HEAP, lsl #32
    // 0xc4eb64: r16 = Sentinel
    //     0xc4eb64: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc4eb68: cmp             w1, w16
    // 0xc4eb6c: b.eq            #0xc4ed38
    // 0xc4eb70: mov             x2, x1
    // 0xc4eb74: ldur            x1, [fp, #-8]
    // 0xc4eb78: cmp             w1, NULL
    // 0xc4eb7c: b.eq            #0xc4eb9c
    // 0xc4eb80: ldr             x16, [fp, #0x20]
    // 0xc4eb84: ldr             lr, [fp, #0x18]
    // 0xc4eb88: stp             lr, x16, [SP, #-0x10]!
    // 0xc4eb8c: stp             x1, x0, [SP, #-0x10]!
    // 0xc4eb90: SaveReg r2
    //     0xc4eb90: str             x2, [SP, #-8]!
    // 0xc4eb94: r0 = paintRegularCursor()
    //     0xc4eb94: bl              #0xc4ed44  ; [package:extended_text_field/src/extended_render_editable.dart] _FloatingCursorPainter::paintRegularCursor
    // 0xc4eb98: add             SP, SP, #0x28
    // 0xc4eb9c: ldr             x1, [fp, #0x20]
    // 0xc4eba0: LoadField: r0 = r1->field_37
    //     0xc4eba0: ldur            w0, [x1, #0x37]
    // 0xc4eba4: DecompressPointer r0
    //     0xc4eba4: add             x0, x0, HEAP, lsl #32
    // 0xc4eba8: cmp             w0, NULL
    // 0xc4ebac: b.ne            #0xc4ebb8
    // 0xc4ebb0: r1 = Null
    //     0xc4ebb0: mov             x1, NULL
    // 0xc4ebb4: b               #0xc4ebd0
    // 0xc4ebb8: d0 = 0.750000
    //     0xc4ebb8: fmov            d0, #0.75000000
    // 0xc4ebbc: SaveReg r0
    //     0xc4ebbc: str             x0, [SP, #-8]!
    // 0xc4ebc0: SaveReg d0
    //     0xc4ebc0: str             d0, [SP, #-8]!
    // 0xc4ebc4: r0 = withOpacity()
    //     0xc4ebc4: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc4ebc8: add             SP, SP, #0x10
    // 0xc4ebcc: mov             x1, x0
    // 0xc4ebd0: ldur            x0, [fp, #-0x10]
    // 0xc4ebd4: stur            x1, [fp, #-8]
    // 0xc4ebd8: cmp             w0, NULL
    // 0xc4ebdc: b.eq            #0xc4ebf8
    // 0xc4ebe0: cmp             w1, NULL
    // 0xc4ebe4: b.eq            #0xc4ebf8
    // 0xc4ebe8: ldr             x2, [fp, #0x20]
    // 0xc4ebec: LoadField: r3 = r2->field_23
    //     0xc4ebec: ldur            w3, [x2, #0x23]
    // 0xc4ebf0: DecompressPointer r3
    //     0xc4ebf0: add             x3, x3, HEAP, lsl #32
    // 0xc4ebf4: tbz             w3, #4, #0xc4ec08
    // 0xc4ebf8: r0 = Null
    //     0xc4ebf8: mov             x0, NULL
    // 0xc4ebfc: LeaveFrame
    //     0xc4ebfc: mov             SP, fp
    //     0xc4ec00: ldp             fp, lr, [SP], #0x10
    // 0xc4ec04: ret
    //     0xc4ec04: ret             
    // 0xc4ec08: ldr             x16, [fp, #0x10]
    // 0xc4ec0c: SaveReg r16
    //     0xc4ec0c: str             x16, [SP, #-8]!
    // 0xc4ec10: r0 = paintOffset()
    //     0xc4ec10: bl              #0x522e98  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::paintOffset
    // 0xc4ec14: add             SP, SP, #8
    // 0xc4ec18: ldur            x16, [fp, #-0x10]
    // 0xc4ec1c: stp             x0, x16, [SP, #-0x10]!
    // 0xc4ec20: r0 = shift()
    //     0xc4ec20: bl              #0x51a0bc  ; [dart:ui] Rect::shift
    // 0xc4ec24: add             SP, SP, #0x10
    // 0xc4ec28: stur            x0, [fp, #-0x10]
    // 0xc4ec2c: r0 = RRect()
    //     0xc4ec2c: bl              #0x640078  ; AllocateRRectStub -> RRect (size=0x68)
    // 0xc4ec30: stur            x0, [fp, #-0x18]
    // 0xc4ec34: ldur            x16, [fp, #-0x10]
    // 0xc4ec38: stp             x16, x0, [SP, #-0x10]!
    // 0xc4ec3c: r16 = Instance_Radius
    //     0xc4ec3c: add             x16, PP, #0x52, lsl #12  ; [pp+0x52f18] Obj!Radius@b5eba1
    //     0xc4ec40: ldr             x16, [x16, #0xf18]
    // 0xc4ec44: SaveReg r16
    //     0xc4ec44: str             x16, [SP, #-8]!
    // 0xc4ec48: r0 = RRect.fromRectAndRadius()
    //     0xc4ec48: bl              #0x660380  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0xc4ec4c: add             SP, SP, #0x18
    // 0xc4ec50: ldr             x1, [fp, #0x20]
    // 0xc4ec54: LoadField: r0 = r1->field_33
    //     0xc4ec54: ldur            w0, [x1, #0x33]
    // 0xc4ec58: DecompressPointer r0
    //     0xc4ec58: add             x0, x0, HEAP, lsl #32
    // 0xc4ec5c: r16 = Sentinel
    //     0xc4ec5c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc4ec60: cmp             w0, w16
    // 0xc4ec64: b.ne            #0xc4ec74
    // 0xc4ec68: r2 = floatingCursorPaint
    //     0xc4ec68: add             x2, PP, #0x56, lsl #12  ; [pp+0x56f20] Field <_FloatingCursorPainter@483409610.floatingCursorPaint>: late final (offset: 0x34)
    //     0xc4ec6c: ldr             x2, [x2, #0xf20]
    // 0xc4ec70: r0 = InitLateFinalInstanceField()
    //     0xc4ec70: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc4ec74: mov             x1, x0
    // 0xc4ec78: ldur            x0, [fp, #-8]
    // 0xc4ec7c: LoadField: r2 = r0->field_7
    //     0xc4ec7c: ldur            x2, [x0, #7]
    // 0xc4ec80: eor             x0, x2, #0xff000000
    // 0xc4ec84: LoadField: r2 = r1->field_7
    //     0xc4ec84: ldur            w2, [x1, #7]
    // 0xc4ec88: DecompressPointer r2
    //     0xc4ec88: add             x2, x2, HEAP, lsl #32
    // 0xc4ec8c: LoadField: r3 = r2->field_13
    //     0xc4ec8c: ldur            w3, [x2, #0x13]
    // 0xc4ec90: DecompressPointer r3
    //     0xc4ec90: add             x3, x3, HEAP, lsl #32
    // 0xc4ec94: r4 = LoadInt32Instr(r3)
    //     0xc4ec94: sbfx            x4, x3, #1, #0x1f
    // 0xc4ec98: cmp             x4, #7
    // 0xc4ec9c: b.le            #0xc4ecec
    // 0xc4eca0: LoadField: r3 = r2->field_17
    //     0xc4eca0: ldur            w3, [x2, #0x17]
    // 0xc4eca4: DecompressPointer r3
    //     0xc4eca4: add             x3, x3, HEAP, lsl #32
    // 0xc4eca8: LoadField: r4 = r2->field_1b
    //     0xc4eca8: ldur            w4, [x2, #0x1b]
    // 0xc4ecac: DecompressPointer r4
    //     0xc4ecac: add             x4, x4, HEAP, lsl #32
    // 0xc4ecb0: r2 = LoadInt32Instr(r4)
    //     0xc4ecb0: sbfx            x2, x4, #1, #0x1f
    // 0xc4ecb4: add             x4, x2, #4
    // 0xc4ecb8: sxtw            x0, w0
    // 0xc4ecbc: LoadField: r2 = r3->field_7
    //     0xc4ecbc: ldur            x2, [x3, #7]
    // 0xc4ecc0: str             w0, [x2, x4]
    // 0xc4ecc4: ldr             x16, [fp, #0x18]
    // 0xc4ecc8: ldur            lr, [fp, #-0x18]
    // 0xc4eccc: stp             lr, x16, [SP, #-0x10]!
    // 0xc4ecd0: SaveReg r1
    //     0xc4ecd0: str             x1, [SP, #-8]!
    // 0xc4ecd4: r0 = drawRRect()
    //     0xc4ecd4: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0xc4ecd8: add             SP, SP, #0x18
    // 0xc4ecdc: r0 = Null
    //     0xc4ecdc: mov             x0, NULL
    // 0xc4ece0: LeaveFrame
    //     0xc4ece0: mov             SP, fp
    //     0xc4ece4: ldp             fp, lr, [SP], #0x10
    // 0xc4ece8: ret
    //     0xc4ece8: ret             
    // 0xc4ecec: sub             x0, x4, #4
    // 0xc4ecf0: lsl             x1, x0, #1
    // 0xc4ecf4: stur            x1, [fp, #-8]
    // 0xc4ecf8: r0 = RangeError()
    //     0xc4ecf8: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xc4ecfc: stur            x0, [fp, #-0x10]
    // 0xc4ed00: r16 = 8
    //     0xc4ed00: mov             x16, #8
    // 0xc4ed04: stp             x16, x0, [SP, #-0x10]!
    // 0xc4ed08: ldur            x16, [fp, #-8]
    // 0xc4ed0c: stp             x16, xzr, [SP, #-0x10]!
    // 0xc4ed10: r16 = "byteOffset"
    //     0xc4ed10: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xc4ed14: SaveReg r16
    //     0xc4ed14: str             x16, [SP, #-8]!
    // 0xc4ed18: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xc4ed18: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xc4ed1c: r0 = RangeError.range()
    //     0xc4ed1c: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xc4ed20: add             SP, SP, #0x28
    // 0xc4ed24: ldur            x0, [fp, #-0x10]
    // 0xc4ed28: r0 = Throw()
    //     0xc4ed28: bl              #0xd67e38  ; ThrowStub
    // 0xc4ed2c: brk             #0
    // 0xc4ed30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4ed30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4ed34: b               #0xc4eabc
    // 0xc4ed38: r9 = _floatingCursorTextPosition
    //     0xc4ed38: add             x9, PP, #0x56, lsl #12  ; [pp+0x56f28] Field <ExtendedRenderEditable._floatingCursorTextPosition@483409610>: late (offset: 0x134)
    //     0xc4ed3c: ldr             x9, [x9, #0xf28]
    // 0xc4ed40: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc4ed40: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ paintRegularCursor(/* No info */) {
    // ** addr: 0xc4ed44, size: 0x404
    // 0xc4ed44: EnterFrame
    //     0xc4ed44: stp             fp, lr, [SP, #-0x10]!
    //     0xc4ed48: mov             fp, SP
    // 0xc4ed4c: AllocStack(0x48)
    //     0xc4ed4c: sub             SP, SP, #0x48
    // 0xc4ed50: CheckStackOverflow
    //     0xc4ed50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4ed54: cmp             SP, x16
    //     0xc4ed58: b.ls            #0xc4f134
    // 0xc4ed5c: ldr             x0, [fp, #0x20]
    // 0xc4ed60: r17 = 339
    //     0xc4ed60: mov             x17, #0x153
    // 0xc4ed64: ldr             w1, [x0, x17]
    // 0xc4ed68: DecompressPointer r1
    //     0xc4ed68: add             x1, x1, HEAP, lsl #32
    // 0xc4ed6c: r16 = Sentinel
    //     0xc4ed6c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc4ed70: cmp             w1, w16
    // 0xc4ed74: b.eq            #0xc4f13c
    // 0xc4ed78: stur            x1, [fp, #-8]
    // 0xc4ed7c: ldr             x16, [fp, #0x10]
    // 0xc4ed80: stp             x16, x0, [SP, #-0x10]!
    // 0xc4ed84: SaveReg r1
    //     0xc4ed84: str             x1, [SP, #-8]!
    // 0xc4ed88: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xc4ed88: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xc4ed8c: r0 = getCaretOffset()
    //     0xc4ed8c: bl              #0x5202b0  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::getCaretOffset
    // 0xc4ed90: add             SP, SP, #0x18
    // 0xc4ed94: mov             x1, x0
    // 0xc4ed98: ldr             x0, [fp, #0x30]
    // 0xc4ed9c: LoadField: r2 = r0->field_3f
    //     0xc4ed9c: ldur            w2, [x0, #0x3f]
    // 0xc4eda0: DecompressPointer r2
    //     0xc4eda0: add             x2, x2, HEAP, lsl #32
    // 0xc4eda4: stp             x2, x1, [SP, #-0x10]!
    // 0xc4eda8: r0 = +()
    //     0xc4eda8: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0xc4edac: add             SP, SP, #0x10
    // 0xc4edb0: ldur            x16, [fp, #-8]
    // 0xc4edb4: stp             x0, x16, [SP, #-0x10]!
    // 0xc4edb8: r0 = shift()
    //     0xc4edb8: bl              #0x51a0bc  ; [dart:ui] Rect::shift
    // 0xc4edbc: add             SP, SP, #0x10
    // 0xc4edc0: mov             x1, x0
    // 0xc4edc4: ldr             x0, [fp, #0x20]
    // 0xc4edc8: stur            x1, [fp, #-0x10]
    // 0xc4edcc: LoadField: r2 = r0->field_eb
    //     0xc4edcc: ldur            w2, [x0, #0xeb]
    // 0xc4edd0: DecompressPointer r2
    //     0xc4edd0: add             x2, x2, HEAP, lsl #32
    // 0xc4edd4: ldr             x16, [fp, #0x10]
    // 0xc4edd8: stp             x16, x2, [SP, #-0x10]!
    // 0xc4eddc: ldur            x16, [fp, #-8]
    // 0xc4ede0: SaveReg r16
    //     0xc4ede0: str             x16, [SP, #-8]!
    // 0xc4ede4: r0 = getFullHeightForCaret()
    //     0xc4ede4: bl              #0xc4f354  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getFullHeightForCaret
    // 0xc4ede8: add             SP, SP, #0x18
    // 0xc4edec: stur            x0, [fp, #-8]
    // 0xc4edf0: cmp             w0, NULL
    // 0xc4edf4: b.eq            #0xc4ef1c
    // 0xc4edf8: r0 = defaultTargetPlatform()
    //     0xc4edf8: bl              #0x59ed88  ; [package:flutter/src/foundation/_platform_io.dart] ::defaultTargetPlatform
    // 0xc4edfc: LoadField: r1 = r0->field_7
    //     0xc4edfc: ldur            x1, [x0, #7]
    // 0xc4ee00: cmp             x1, #2
    // 0xc4ee04: b.gt            #0xc4ee20
    // 0xc4ee08: cmp             x1, #1
    // 0xc4ee0c: b.gt            #0xc4ee40
    // 0xc4ee10: ldur            x1, [fp, #-0x10]
    // 0xc4ee14: ldur            x0, [fp, #-8]
    // 0xc4ee18: d0 = 2.000000
    //     0xc4ee18: fmov            d0, #2.00000000
    // 0xc4ee1c: b               #0xc4eec0
    // 0xc4ee20: cmp             x1, #4
    // 0xc4ee24: b.gt            #0xc4eeb4
    // 0xc4ee28: cmp             x1, #3
    // 0xc4ee2c: b.gt            #0xc4ee40
    // 0xc4ee30: ldur            x1, [fp, #-0x10]
    // 0xc4ee34: ldur            x0, [fp, #-8]
    // 0xc4ee38: d0 = 2.000000
    //     0xc4ee38: fmov            d0, #2.00000000
    // 0xc4ee3c: b               #0xc4eec0
    // 0xc4ee40: ldur            x1, [fp, #-0x10]
    // 0xc4ee44: ldur            x0, [fp, #-8]
    // 0xc4ee48: d0 = 2.000000
    //     0xc4ee48: fmov            d0, #2.00000000
    // 0xc4ee4c: LoadField: d1 = r1->field_1f
    //     0xc4ee4c: ldur            d1, [x1, #0x1f]
    // 0xc4ee50: LoadField: d2 = r1->field_f
    //     0xc4ee50: ldur            d2, [x1, #0xf]
    // 0xc4ee54: fsub            d3, d1, d2
    // 0xc4ee58: LoadField: d1 = r0->field_7
    //     0xc4ee58: ldur            d1, [x0, #7]
    // 0xc4ee5c: fsub            d4, d1, d3
    // 0xc4ee60: LoadField: d1 = r1->field_7
    //     0xc4ee60: ldur            d1, [x1, #7]
    // 0xc4ee64: stur            d1, [fp, #-0x48]
    // 0xc4ee68: fdiv            d5, d4, d0
    // 0xc4ee6c: fadd            d0, d2, d5
    // 0xc4ee70: stur            d0, [fp, #-0x40]
    // 0xc4ee74: LoadField: d2 = r1->field_17
    //     0xc4ee74: ldur            d2, [x1, #0x17]
    // 0xc4ee78: fsub            d4, d2, d1
    // 0xc4ee7c: fadd            d2, d1, d4
    // 0xc4ee80: stur            d2, [fp, #-0x38]
    // 0xc4ee84: fadd            d4, d0, d3
    // 0xc4ee88: stur            d4, [fp, #-0x30]
    // 0xc4ee8c: r0 = Rect()
    //     0xc4ee8c: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0xc4ee90: ldur            d0, [fp, #-0x48]
    // 0xc4ee94: StoreField: r0->field_7 = d0
    //     0xc4ee94: stur            d0, [x0, #7]
    // 0xc4ee98: ldur            d0, [fp, #-0x40]
    // 0xc4ee9c: StoreField: r0->field_f = d0
    //     0xc4ee9c: stur            d0, [x0, #0xf]
    // 0xc4eea0: ldur            d0, [fp, #-0x38]
    // 0xc4eea4: StoreField: r0->field_17 = d0
    //     0xc4eea4: stur            d0, [x0, #0x17]
    // 0xc4eea8: ldur            d0, [fp, #-0x30]
    // 0xc4eeac: StoreField: r0->field_1f = d0
    //     0xc4eeac: stur            d0, [x0, #0x1f]
    // 0xc4eeb0: b               #0xc4ef14
    // 0xc4eeb4: ldur            x1, [fp, #-0x10]
    // 0xc4eeb8: ldur            x0, [fp, #-8]
    // 0xc4eebc: d0 = 2.000000
    //     0xc4eebc: fmov            d0, #2.00000000
    // 0xc4eec0: LoadField: d1 = r1->field_7
    //     0xc4eec0: ldur            d1, [x1, #7]
    // 0xc4eec4: stur            d1, [fp, #-0x48]
    // 0xc4eec8: LoadField: d2 = r1->field_f
    //     0xc4eec8: ldur            d2, [x1, #0xf]
    // 0xc4eecc: fsub            d3, d2, d0
    // 0xc4eed0: stur            d3, [fp, #-0x40]
    // 0xc4eed4: LoadField: d0 = r1->field_17
    //     0xc4eed4: ldur            d0, [x1, #0x17]
    // 0xc4eed8: fsub            d2, d0, d1
    // 0xc4eedc: fadd            d0, d1, d2
    // 0xc4eee0: stur            d0, [fp, #-0x38]
    // 0xc4eee4: LoadField: d2 = r0->field_7
    //     0xc4eee4: ldur            d2, [x0, #7]
    // 0xc4eee8: fadd            d4, d3, d2
    // 0xc4eeec: stur            d4, [fp, #-0x30]
    // 0xc4eef0: r0 = Rect()
    //     0xc4eef0: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0xc4eef4: ldur            d0, [fp, #-0x48]
    // 0xc4eef8: StoreField: r0->field_7 = d0
    //     0xc4eef8: stur            d0, [x0, #7]
    // 0xc4eefc: ldur            d0, [fp, #-0x40]
    // 0xc4ef00: StoreField: r0->field_f = d0
    //     0xc4ef00: stur            d0, [x0, #0xf]
    // 0xc4ef04: ldur            d0, [fp, #-0x38]
    // 0xc4ef08: StoreField: r0->field_17 = d0
    //     0xc4ef08: stur            d0, [x0, #0x17]
    // 0xc4ef0c: ldur            d0, [fp, #-0x30]
    // 0xc4ef10: StoreField: r0->field_1f = d0
    //     0xc4ef10: stur            d0, [x0, #0x1f]
    // 0xc4ef14: mov             x1, x0
    // 0xc4ef18: b               #0xc4ef20
    // 0xc4ef1c: ldur            x1, [fp, #-0x10]
    // 0xc4ef20: ldr             x0, [fp, #0x30]
    // 0xc4ef24: stur            x1, [fp, #-8]
    // 0xc4ef28: ldr             x16, [fp, #0x20]
    // 0xc4ef2c: SaveReg r16
    //     0xc4ef2c: str             x16, [SP, #-8]!
    // 0xc4ef30: r0 = paintOffset()
    //     0xc4ef30: bl              #0x522e98  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::paintOffset
    // 0xc4ef34: add             SP, SP, #8
    // 0xc4ef38: ldur            x16, [fp, #-8]
    // 0xc4ef3c: stp             x0, x16, [SP, #-0x10]!
    // 0xc4ef40: r0 = shift()
    //     0xc4ef40: bl              #0x51a0bc  ; [dart:ui] Rect::shift
    // 0xc4ef44: add             SP, SP, #0x10
    // 0xc4ef48: stur            x0, [fp, #-8]
    // 0xc4ef4c: LoadField: d0 = r0->field_7
    //     0xc4ef4c: ldur            d0, [x0, #7]
    // 0xc4ef50: stur            d0, [fp, #-0x38]
    // 0xc4ef54: LoadField: d1 = r0->field_f
    //     0xc4ef54: ldur            d1, [x0, #0xf]
    // 0xc4ef58: stur            d1, [fp, #-0x30]
    // 0xc4ef5c: r0 = Offset()
    //     0xc4ef5c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc4ef60: ldur            d0, [fp, #-0x38]
    // 0xc4ef64: StoreField: r0->field_7 = d0
    //     0xc4ef64: stur            d0, [x0, #7]
    // 0xc4ef68: ldur            d0, [fp, #-0x30]
    // 0xc4ef6c: StoreField: r0->field_f = d0
    //     0xc4ef6c: stur            d0, [x0, #0xf]
    // 0xc4ef70: ldr             x16, [fp, #0x20]
    // 0xc4ef74: stp             x0, x16, [SP, #-0x10]!
    // 0xc4ef78: r0 = _snapToPhysicalPixel()
    //     0xc4ef78: bl              #0xc4f148  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_snapToPhysicalPixel
    // 0xc4ef7c: add             SP, SP, #0x10
    // 0xc4ef80: ldur            x16, [fp, #-8]
    // 0xc4ef84: stp             x0, x16, [SP, #-0x10]!
    // 0xc4ef88: r0 = shift()
    //     0xc4ef88: bl              #0x51a0bc  ; [dart:ui] Rect::shift
    // 0xc4ef8c: add             SP, SP, #0x10
    // 0xc4ef90: mov             x1, x0
    // 0xc4ef94: ldr             x0, [fp, #0x30]
    // 0xc4ef98: stur            x1, [fp, #-0x18]
    // 0xc4ef9c: LoadField: r2 = r0->field_23
    //     0xc4ef9c: ldur            w2, [x0, #0x23]
    // 0xc4efa0: DecompressPointer r2
    //     0xc4efa0: add             x2, x2, HEAP, lsl #32
    // 0xc4efa4: tbnz            w2, #4, #0xc4f0b8
    // 0xc4efa8: ldr             x2, [fp, #0x18]
    // 0xc4efac: LoadField: r3 = r0->field_3b
    //     0xc4efac: ldur            w3, [x0, #0x3b]
    // 0xc4efb0: DecompressPointer r3
    //     0xc4efb0: add             x3, x3, HEAP, lsl #32
    // 0xc4efb4: stur            x3, [fp, #-0x28]
    // 0xc4efb8: LoadField: r4 = r0->field_2f
    //     0xc4efb8: ldur            w4, [x0, #0x2f]
    // 0xc4efbc: DecompressPointer r4
    //     0xc4efbc: add             x4, x4, HEAP, lsl #32
    // 0xc4efc0: stur            x4, [fp, #-0x20]
    // 0xc4efc4: r5 = LoadClassIdInstr(r2)
    //     0xc4efc4: ldur            x5, [x2, #-1]
    //     0xc4efc8: ubfx            x5, x5, #0xc, #0x14
    // 0xc4efcc: lsl             x5, x5, #1
    // 0xc4efd0: r17 = 10124
    //     0xc4efd0: mov             x17, #0x278c
    // 0xc4efd4: cmp             w5, w17
    // 0xc4efd8: b.gt            #0xc4efe8
    // 0xc4efdc: r17 = 10122
    //     0xc4efdc: mov             x17, #0x278a
    // 0xc4efe0: cmp             w5, w17
    // 0xc4efe4: b.ge            #0xc4f000
    // 0xc4efe8: r17 = 10114
    //     0xc4efe8: mov             x17, #0x2782
    // 0xc4efec: cmp             w5, w17
    // 0xc4eff0: b.eq            #0xc4f000
    // 0xc4eff4: r17 = 10118
    //     0xc4eff4: mov             x17, #0x2786
    // 0xc4eff8: cmp             w5, w17
    // 0xc4effc: b.ne            #0xc4f00c
    // 0xc4f000: LoadField: r5 = r2->field_7
    //     0xc4f000: ldur            x5, [x2, #7]
    // 0xc4f004: mov             x2, x5
    // 0xc4f008: b               #0xc4f018
    // 0xc4f00c: LoadField: r5 = r2->field_f
    //     0xc4f00c: ldur            w5, [x2, #0xf]
    // 0xc4f010: DecompressPointer r5
    //     0xc4f010: add             x5, x5, HEAP, lsl #32
    // 0xc4f014: LoadField: r2 = r5->field_7
    //     0xc4f014: ldur            x2, [x5, #7]
    // 0xc4f018: eor             x5, x2, #0xff000000
    // 0xc4f01c: LoadField: r2 = r4->field_7
    //     0xc4f01c: ldur            w2, [x4, #7]
    // 0xc4f020: DecompressPointer r2
    //     0xc4f020: add             x2, x2, HEAP, lsl #32
    // 0xc4f024: LoadField: r6 = r2->field_13
    //     0xc4f024: ldur            w6, [x2, #0x13]
    // 0xc4f028: DecompressPointer r6
    //     0xc4f028: add             x6, x6, HEAP, lsl #32
    // 0xc4f02c: r7 = LoadInt32Instr(r6)
    //     0xc4f02c: sbfx            x7, x6, #1, #0x1f
    // 0xc4f030: cmp             x7, #7
    // 0xc4f034: b.le            #0xc4f0f0
    // 0xc4f038: LoadField: r6 = r2->field_17
    //     0xc4f038: ldur            w6, [x2, #0x17]
    // 0xc4f03c: DecompressPointer r6
    //     0xc4f03c: add             x6, x6, HEAP, lsl #32
    // 0xc4f040: LoadField: r7 = r2->field_1b
    //     0xc4f040: ldur            w7, [x2, #0x1b]
    // 0xc4f044: DecompressPointer r7
    //     0xc4f044: add             x7, x7, HEAP, lsl #32
    // 0xc4f048: r2 = LoadInt32Instr(r7)
    //     0xc4f048: sbfx            x2, x7, #1, #0x1f
    // 0xc4f04c: add             x7, x2, #4
    // 0xc4f050: sxtw            x5, w5
    // 0xc4f054: LoadField: r2 = r6->field_7
    //     0xc4f054: ldur            x2, [x6, #7]
    // 0xc4f058: str             w5, [x2, x7]
    // 0xc4f05c: cmp             w3, NULL
    // 0xc4f060: b.ne            #0xc4f07c
    // 0xc4f064: ldr             x16, [fp, #0x28]
    // 0xc4f068: stp             x1, x16, [SP, #-0x10]!
    // 0xc4f06c: SaveReg r4
    //     0xc4f06c: str             x4, [SP, #-8]!
    // 0xc4f070: r0 = drawRect()
    //     0xc4f070: bl              #0x65e610  ; [dart:ui] Canvas::drawRect
    // 0xc4f074: add             SP, SP, #0x18
    // 0xc4f078: b               #0xc4f0b8
    // 0xc4f07c: r0 = RRect()
    //     0xc4f07c: bl              #0x640078  ; AllocateRRectStub -> RRect (size=0x68)
    // 0xc4f080: stur            x0, [fp, #-8]
    // 0xc4f084: ldur            x16, [fp, #-0x18]
    // 0xc4f088: stp             x16, x0, [SP, #-0x10]!
    // 0xc4f08c: ldur            x16, [fp, #-0x28]
    // 0xc4f090: SaveReg r16
    //     0xc4f090: str             x16, [SP, #-8]!
    // 0xc4f094: r0 = RRect.fromRectAndRadius()
    //     0xc4f094: bl              #0x660380  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0xc4f098: add             SP, SP, #0x18
    // 0xc4f09c: ldr             x16, [fp, #0x28]
    // 0xc4f0a0: ldur            lr, [fp, #-8]
    // 0xc4f0a4: stp             lr, x16, [SP, #-0x10]!
    // 0xc4f0a8: ldur            x16, [fp, #-0x20]
    // 0xc4f0ac: SaveReg r16
    //     0xc4f0ac: str             x16, [SP, #-8]!
    // 0xc4f0b0: r0 = drawRRect()
    //     0xc4f0b0: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0xc4f0b4: add             SP, SP, #0x18
    // 0xc4f0b8: ldr             x0, [fp, #0x30]
    // 0xc4f0bc: LoadField: r1 = r0->field_27
    //     0xc4f0bc: ldur            w1, [x0, #0x27]
    // 0xc4f0c0: DecompressPointer r1
    //     0xc4f0c0: add             x1, x1, HEAP, lsl #32
    // 0xc4f0c4: ldur            x16, [fp, #-0x18]
    // 0xc4f0c8: stp             x16, x1, [SP, #-0x10]!
    // 0xc4f0cc: mov             x0, x1
    // 0xc4f0d0: ClosureCall
    //     0xc4f0d0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xc4f0d4: ldur            x2, [x0, #0x1f]
    //     0xc4f0d8: blr             x2
    // 0xc4f0dc: add             SP, SP, #0x10
    // 0xc4f0e0: r0 = Null
    //     0xc4f0e0: mov             x0, NULL
    // 0xc4f0e4: LeaveFrame
    //     0xc4f0e4: mov             SP, fp
    //     0xc4f0e8: ldp             fp, lr, [SP], #0x10
    // 0xc4f0ec: ret
    //     0xc4f0ec: ret             
    // 0xc4f0f0: sub             x0, x7, #4
    // 0xc4f0f4: lsl             x1, x0, #1
    // 0xc4f0f8: stur            x1, [fp, #-8]
    // 0xc4f0fc: r0 = RangeError()
    //     0xc4f0fc: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xc4f100: stur            x0, [fp, #-0x10]
    // 0xc4f104: r16 = 8
    //     0xc4f104: mov             x16, #8
    // 0xc4f108: stp             x16, x0, [SP, #-0x10]!
    // 0xc4f10c: ldur            x16, [fp, #-8]
    // 0xc4f110: stp             x16, xzr, [SP, #-0x10]!
    // 0xc4f114: r16 = "byteOffset"
    //     0xc4f114: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xc4f118: SaveReg r16
    //     0xc4f118: str             x16, [SP, #-8]!
    // 0xc4f11c: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xc4f11c: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xc4f120: r0 = RangeError.range()
    //     0xc4f120: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xc4f124: add             SP, SP, #0x28
    // 0xc4f128: ldur            x0, [fp, #-0x10]
    // 0xc4f12c: r0 = Throw()
    //     0xc4f12c: bl              #0xd67e38  ; ThrowStub
    // 0xc4f130: brk             #0
    // 0xc4f134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4f134: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4f138: b               #0xc4ed5c
    // 0xc4f13c: r9 = _caretPrototype
    //     0xc4f13c: add             x9, PP, #0x37, lsl #12  ; [pp+0x37350] Field <ExtendedRenderEditable._caretPrototype@483409610>: late (offset: 0x154)
    //     0xc4f140: ldr             x9, [x9, #0x350]
    // 0xc4f144: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc4f144: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  Paint floatingCursorPaint(_FloatingCursorPainter) {
    // ** addr: 0xc4f3c4, size: 0x4c
    // 0xc4f3c4: EnterFrame
    //     0xc4f3c4: stp             fp, lr, [SP, #-0x10]!
    //     0xc4f3c8: mov             fp, SP
    // 0xc4f3cc: AllocStack(0x8)
    //     0xc4f3cc: sub             SP, SP, #8
    // 0xc4f3d0: CheckStackOverflow
    //     0xc4f3d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4f3d4: cmp             SP, x16
    //     0xc4f3d8: b.ls            #0xc4f408
    // 0xc4f3dc: r16 = 112
    //     0xc4f3dc: mov             x16, #0x70
    // 0xc4f3e0: stp             x16, NULL, [SP, #-0x10]!
    // 0xc4f3e4: r0 = ByteData()
    //     0xc4f3e4: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xc4f3e8: add             SP, SP, #0x10
    // 0xc4f3ec: stur            x0, [fp, #-8]
    // 0xc4f3f0: r0 = Paint()
    //     0xc4f3f0: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xc4f3f4: ldur            x1, [fp, #-8]
    // 0xc4f3f8: StoreField: r0->field_7 = r1
    //     0xc4f3f8: stur            w1, [x0, #7]
    // 0xc4f3fc: LeaveFrame
    //     0xc4f3fc: mov             SP, fp
    //     0xc4f400: ldp             fp, lr, [SP], #0x10
    // 0xc4f404: ret
    //     0xc4f404: ret             
    // 0xc4f408: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4f408: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4f40c: b               #0xc4f3dc
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xc4fe64, size: 0x1ac
    // 0xc4fe64: EnterFrame
    //     0xc4fe64: stp             fp, lr, [SP, #-0x10]!
    //     0xc4fe68: mov             fp, SP
    // 0xc4fe6c: CheckStackOverflow
    //     0xc4fe6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4fe70: cmp             SP, x16
    //     0xc4fe74: b.ls            #0xc50008
    // 0xc4fe78: ldr             x2, [fp, #0x18]
    // 0xc4fe7c: ldr             x1, [fp, #0x10]
    // 0xc4fe80: cmp             w2, w1
    // 0xc4fe84: b.ne            #0xc4fe98
    // 0xc4fe88: r0 = false
    //     0xc4fe88: add             x0, NULL, #0x30  ; false
    // 0xc4fe8c: LeaveFrame
    //     0xc4fe8c: mov             SP, fp
    //     0xc4fe90: ldp             fp, lr, [SP], #0x10
    // 0xc4fe94: ret
    //     0xc4fe94: ret             
    // 0xc4fe98: r0 = LoadClassIdInstr(r1)
    //     0xc4fe98: ldur            x0, [x1, #-1]
    //     0xc4fe9c: ubfx            x0, x0, #0xc, #0x14
    // 0xc4fea0: lsl             x0, x0, #1
    // 0xc4fea4: r17 = 9678
    //     0xc4fea4: mov             x17, #0x25ce
    // 0xc4fea8: cmp             w0, w17
    // 0xc4feac: b.ne            #0xc4ffb4
    // 0xc4feb0: LoadField: r0 = r1->field_23
    //     0xc4feb0: ldur            w0, [x1, #0x23]
    // 0xc4feb4: DecompressPointer r0
    //     0xc4feb4: add             x0, x0, HEAP, lsl #32
    // 0xc4feb8: LoadField: r3 = r2->field_23
    //     0xc4feb8: ldur            w3, [x2, #0x23]
    // 0xc4febc: DecompressPointer r3
    //     0xc4febc: add             x3, x3, HEAP, lsl #32
    // 0xc4fec0: cmp             w0, w3
    // 0xc4fec4: b.ne            #0xc4ffb4
    // 0xc4fec8: LoadField: r0 = r1->field_2b
    //     0xc4fec8: ldur            w0, [x1, #0x2b]
    // 0xc4fecc: DecompressPointer r0
    //     0xc4fecc: add             x0, x0, HEAP, lsl #32
    // 0xc4fed0: LoadField: r3 = r2->field_2b
    //     0xc4fed0: ldur            w3, [x2, #0x2b]
    // 0xc4fed4: DecompressPointer r3
    //     0xc4fed4: add             x3, x3, HEAP, lsl #32
    // 0xc4fed8: cmp             w0, w3
    // 0xc4fedc: b.ne            #0xc4ffb4
    // 0xc4fee0: LoadField: r0 = r1->field_37
    //     0xc4fee0: ldur            w0, [x1, #0x37]
    // 0xc4fee4: DecompressPointer r0
    //     0xc4fee4: add             x0, x0, HEAP, lsl #32
    // 0xc4fee8: LoadField: r3 = r2->field_37
    //     0xc4fee8: ldur            w3, [x2, #0x37]
    // 0xc4feec: DecompressPointer r3
    //     0xc4feec: add             x3, x3, HEAP, lsl #32
    // 0xc4fef0: r4 = LoadClassIdInstr(r0)
    //     0xc4fef0: ldur            x4, [x0, #-1]
    //     0xc4fef4: ubfx            x4, x4, #0xc, #0x14
    // 0xc4fef8: stp             x3, x0, [SP, #-0x10]!
    // 0xc4fefc: mov             x0, x4
    // 0xc4ff00: mov             lr, x0
    // 0xc4ff04: ldr             lr, [x21, lr, lsl #3]
    // 0xc4ff08: blr             lr
    // 0xc4ff0c: add             SP, SP, #0x10
    // 0xc4ff10: tbnz            w0, #4, #0xc4ffb4
    // 0xc4ff14: ldr             x2, [fp, #0x18]
    // 0xc4ff18: ldr             x1, [fp, #0x10]
    // 0xc4ff1c: LoadField: r0 = r1->field_3b
    //     0xc4ff1c: ldur            w0, [x1, #0x3b]
    // 0xc4ff20: DecompressPointer r0
    //     0xc4ff20: add             x0, x0, HEAP, lsl #32
    // 0xc4ff24: LoadField: r3 = r2->field_3b
    //     0xc4ff24: ldur            w3, [x2, #0x3b]
    // 0xc4ff28: DecompressPointer r3
    //     0xc4ff28: add             x3, x3, HEAP, lsl #32
    // 0xc4ff2c: r4 = LoadClassIdInstr(r0)
    //     0xc4ff2c: ldur            x4, [x0, #-1]
    //     0xc4ff30: ubfx            x4, x4, #0xc, #0x14
    // 0xc4ff34: stp             x3, x0, [SP, #-0x10]!
    // 0xc4ff38: mov             x0, x4
    // 0xc4ff3c: mov             lr, x0
    // 0xc4ff40: ldr             lr, [x21, lr, lsl #3]
    // 0xc4ff44: blr             lr
    // 0xc4ff48: add             SP, SP, #0x10
    // 0xc4ff4c: tbnz            w0, #4, #0xc4ffb4
    // 0xc4ff50: ldr             x1, [fp, #0x18]
    // 0xc4ff54: ldr             x0, [fp, #0x10]
    // 0xc4ff58: LoadField: r2 = r0->field_3f
    //     0xc4ff58: ldur            w2, [x0, #0x3f]
    // 0xc4ff5c: DecompressPointer r2
    //     0xc4ff5c: add             x2, x2, HEAP, lsl #32
    // 0xc4ff60: LoadField: r3 = r1->field_3f
    //     0xc4ff60: ldur            w3, [x1, #0x3f]
    // 0xc4ff64: DecompressPointer r3
    //     0xc4ff64: add             x3, x3, HEAP, lsl #32
    // 0xc4ff68: stp             x3, x2, [SP, #-0x10]!
    // 0xc4ff6c: r0 = ==()
    //     0xc4ff6c: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0xc4ff70: add             SP, SP, #0x10
    // 0xc4ff74: tbnz            w0, #4, #0xc4ffb4
    // 0xc4ff78: ldr             x2, [fp, #0x18]
    // 0xc4ff7c: ldr             x1, [fp, #0x10]
    // 0xc4ff80: LoadField: r0 = r1->field_43
    //     0xc4ff80: ldur            w0, [x1, #0x43]
    // 0xc4ff84: DecompressPointer r0
    //     0xc4ff84: add             x0, x0, HEAP, lsl #32
    // 0xc4ff88: LoadField: r3 = r2->field_43
    //     0xc4ff88: ldur            w3, [x2, #0x43]
    // 0xc4ff8c: DecompressPointer r3
    //     0xc4ff8c: add             x3, x3, HEAP, lsl #32
    // 0xc4ff90: r4 = LoadClassIdInstr(r0)
    //     0xc4ff90: ldur            x4, [x0, #-1]
    //     0xc4ff94: ubfx            x4, x4, #0xc, #0x14
    // 0xc4ff98: stp             x3, x0, [SP, #-0x10]!
    // 0xc4ff9c: mov             x0, x4
    // 0xc4ffa0: mov             lr, x0
    // 0xc4ffa4: ldr             lr, [x21, lr, lsl #3]
    // 0xc4ffa8: blr             lr
    // 0xc4ffac: add             SP, SP, #0x10
    // 0xc4ffb0: tbz             w0, #4, #0xc4ffbc
    // 0xc4ffb4: r0 = true
    //     0xc4ffb4: add             x0, NULL, #0x20  ; true
    // 0xc4ffb8: b               #0xc4fffc
    // 0xc4ffbc: ldr             x1, [fp, #0x18]
    // 0xc4ffc0: ldr             x0, [fp, #0x10]
    // 0xc4ffc4: LoadField: r2 = r0->field_47
    //     0xc4ffc4: ldur            w2, [x0, #0x47]
    // 0xc4ffc8: DecompressPointer r2
    //     0xc4ffc8: add             x2, x2, HEAP, lsl #32
    // 0xc4ffcc: LoadField: r0 = r1->field_47
    //     0xc4ffcc: ldur            w0, [x1, #0x47]
    // 0xc4ffd0: DecompressPointer r0
    //     0xc4ffd0: add             x0, x0, HEAP, lsl #32
    // 0xc4ffd4: r1 = LoadClassIdInstr(r2)
    //     0xc4ffd4: ldur            x1, [x2, #-1]
    //     0xc4ffd8: ubfx            x1, x1, #0xc, #0x14
    // 0xc4ffdc: stp             x0, x2, [SP, #-0x10]!
    // 0xc4ffe0: mov             x0, x1
    // 0xc4ffe4: mov             lr, x0
    // 0xc4ffe8: ldr             lr, [x21, lr, lsl #3]
    // 0xc4ffec: blr             lr
    // 0xc4fff0: add             SP, SP, #0x10
    // 0xc4fff4: eor             x1, x0, #0x10
    // 0xc4fff8: mov             x0, x1
    // 0xc4fffc: LeaveFrame
    //     0xc4fffc: mov             SP, fp
    //     0xc50000: ldp             fp, lr, [SP], #0x10
    // 0xc50004: ret
    //     0xc50004: ret             
    // 0xc50008: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc50008: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5000c: b               #0xc4fe78
  }
  set _ floatingCursorRect=(/* No info */) {
    // ** addr: 0xcd1c58, size: 0xa0
    // 0xcd1c58: EnterFrame
    //     0xcd1c58: stp             fp, lr, [SP, #-0x10]!
    //     0xcd1c5c: mov             fp, SP
    // 0xcd1c60: CheckStackOverflow
    //     0xcd1c60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd1c64: cmp             SP, x16
    //     0xcd1c68: b.ls            #0xcd1cf0
    // 0xcd1c6c: ldr             x1, [fp, #0x18]
    // 0xcd1c70: LoadField: r0 = r1->field_47
    //     0xcd1c70: ldur            w0, [x1, #0x47]
    // 0xcd1c74: DecompressPointer r0
    //     0xcd1c74: add             x0, x0, HEAP, lsl #32
    // 0xcd1c78: r2 = LoadClassIdInstr(r0)
    //     0xcd1c78: ldur            x2, [x0, #-1]
    //     0xcd1c7c: ubfx            x2, x2, #0xc, #0x14
    // 0xcd1c80: ldr             x16, [fp, #0x10]
    // 0xcd1c84: stp             x16, x0, [SP, #-0x10]!
    // 0xcd1c88: mov             x0, x2
    // 0xcd1c8c: mov             lr, x0
    // 0xcd1c90: ldr             lr, [x21, lr, lsl #3]
    // 0xcd1c94: blr             lr
    // 0xcd1c98: add             SP, SP, #0x10
    // 0xcd1c9c: tbnz            w0, #4, #0xcd1cb0
    // 0xcd1ca0: r0 = Null
    //     0xcd1ca0: mov             x0, NULL
    // 0xcd1ca4: LeaveFrame
    //     0xcd1ca4: mov             SP, fp
    //     0xcd1ca8: ldp             fp, lr, [SP], #0x10
    // 0xcd1cac: ret
    //     0xcd1cac: ret             
    // 0xcd1cb0: ldr             x1, [fp, #0x18]
    // 0xcd1cb4: ldr             x0, [fp, #0x10]
    // 0xcd1cb8: StoreField: r1->field_47 = r0
    //     0xcd1cb8: stur            w0, [x1, #0x47]
    //     0xcd1cbc: ldurb           w16, [x1, #-1]
    //     0xcd1cc0: ldurb           w17, [x0, #-1]
    //     0xcd1cc4: and             x16, x17, x16, lsr #2
    //     0xcd1cc8: tst             x16, HEAP, lsr #32
    //     0xcd1ccc: b.eq            #0xcd1cd4
    //     0xcd1cd0: bl              #0xd6826c
    // 0xcd1cd4: SaveReg r1
    //     0xcd1cd4: str             x1, [SP, #-8]!
    // 0xcd1cd8: r0 = notifyListeners()
    //     0xcd1cd8: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xcd1cdc: add             SP, SP, #8
    // 0xcd1ce0: r0 = Null
    //     0xcd1ce0: mov             x0, NULL
    // 0xcd1ce4: LeaveFrame
    //     0xcd1ce4: mov             SP, fp
    //     0xcd1ce8: ldp             fp, lr, [SP], #0x10
    // 0xcd1cec: ret
    //     0xcd1cec: ret             
    // 0xcd1cf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd1cf0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd1cf4: b               #0xcd1c6c
  }
}

// class id: 5699, size: 0x2c, field offset: 0xc
class VerticalCaretMovementRun extends BidirectionalIterator<TextPosition> {

  _ moveNext(/* No info */) {
    // ** addr: 0xc3800c, size: 0x114
    // 0xc3800c: EnterFrame
    //     0xc3800c: stp             fp, lr, [SP, #-0x10]!
    //     0xc38010: mov             fp, SP
    // 0xc38014: AllocStack(0x8)
    //     0xc38014: sub             SP, SP, #8
    // 0xc38018: CheckStackOverflow
    //     0xc38018: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3801c: cmp             SP, x16
    //     0xc38020: b.ls            #0xc38118
    // 0xc38024: ldr             x0, [fp, #0x10]
    // 0xc38028: LoadField: r1 = r0->field_f
    //     0xc38028: ldur            x1, [x0, #0xf]
    // 0xc3802c: add             x2, x1, #1
    // 0xc38030: LoadField: r1 = r0->field_1b
    //     0xc38030: ldur            w1, [x0, #0x1b]
    // 0xc38034: DecompressPointer r1
    //     0xc38034: add             x1, x1, HEAP, lsl #32
    // 0xc38038: LoadField: r3 = r1->field_b
    //     0xc38038: ldur            w3, [x1, #0xb]
    // 0xc3803c: DecompressPointer r3
    //     0xc3803c: add             x3, x3, HEAP, lsl #32
    // 0xc38040: r1 = LoadInt32Instr(r3)
    //     0xc38040: sbfx            x1, x3, #1, #0x1f
    // 0xc38044: cmp             x2, x1
    // 0xc38048: b.lt            #0xc3805c
    // 0xc3804c: r0 = false
    //     0xc3804c: add             x0, NULL, #0x30  ; false
    // 0xc38050: LeaveFrame
    //     0xc38050: mov             SP, fp
    //     0xc38054: ldp             fp, lr, [SP], #0x10
    // 0xc38058: ret
    //     0xc38058: ret             
    // 0xc3805c: stp             x2, x0, [SP, #-0x10]!
    // 0xc38060: r0 = _getTextPositionForLine()
    //     0xc38060: bl              #0xc38120  ; [package:extended_text_field/src/extended_render_editable.dart] VerticalCaretMovementRun::_getTextPositionForLine
    // 0xc38064: add             SP, SP, #0x10
    // 0xc38068: mov             x2, x0
    // 0xc3806c: ldr             x1, [fp, #0x10]
    // 0xc38070: stur            x2, [fp, #-8]
    // 0xc38074: LoadField: r0 = r1->field_f
    //     0xc38074: ldur            x0, [x1, #0xf]
    // 0xc38078: add             x3, x0, #1
    // 0xc3807c: StoreField: r1->field_f = r3
    //     0xc3807c: stur            x3, [x1, #0xf]
    // 0xc38080: r0 = LoadClassIdInstr(r2)
    //     0xc38080: ldur            x0, [x2, #-1]
    //     0xc38084: ubfx            x0, x0, #0xc, #0x14
    // 0xc38088: SaveReg r2
    //     0xc38088: str             x2, [SP, #-8]!
    // 0xc3808c: r0 = GDT[cid_x0 + -0xfba]()
    //     0xc3808c: sub             lr, x0, #0xfba
    //     0xc38090: ldr             lr, [x21, lr, lsl #3]
    //     0xc38094: blr             lr
    // 0xc38098: add             SP, SP, #8
    // 0xc3809c: ldr             x1, [fp, #0x10]
    // 0xc380a0: StoreField: r1->field_b = r0
    //     0xc380a0: stur            w0, [x1, #0xb]
    //     0xc380a4: tbz             w0, #0, #0xc380c0
    //     0xc380a8: ldurb           w16, [x1, #-1]
    //     0xc380ac: ldurb           w17, [x0, #-1]
    //     0xc380b0: and             x16, x17, x16, lsr #2
    //     0xc380b4: tst             x16, HEAP, lsr #32
    //     0xc380b8: b.eq            #0xc380c0
    //     0xc380bc: bl              #0xd6826c
    // 0xc380c0: ldur            x0, [fp, #-8]
    // 0xc380c4: r2 = LoadClassIdInstr(r0)
    //     0xc380c4: ldur            x2, [x0, #-1]
    //     0xc380c8: ubfx            x2, x2, #0xc, #0x14
    // 0xc380cc: SaveReg r0
    //     0xc380cc: str             x0, [SP, #-8]!
    // 0xc380d0: mov             x0, x2
    // 0xc380d4: r0 = GDT[cid_x0 + -0xfc4]()
    //     0xc380d4: sub             lr, x0, #0xfc4
    //     0xc380d8: ldr             lr, [x21, lr, lsl #3]
    //     0xc380dc: blr             lr
    // 0xc380e0: add             SP, SP, #8
    // 0xc380e4: ldr             x1, [fp, #0x10]
    // 0xc380e8: StoreField: r1->field_17 = r0
    //     0xc380e8: stur            w0, [x1, #0x17]
    //     0xc380ec: tbz             w0, #0, #0xc38108
    //     0xc380f0: ldurb           w16, [x1, #-1]
    //     0xc380f4: ldurb           w17, [x0, #-1]
    //     0xc380f8: and             x16, x17, x16, lsr #2
    //     0xc380fc: tst             x16, HEAP, lsr #32
    //     0xc38100: b.eq            #0xc38108
    //     0xc38104: bl              #0xd6826c
    // 0xc38108: r0 = true
    //     0xc38108: add             x0, NULL, #0x20  ; true
    // 0xc3810c: LeaveFrame
    //     0xc3810c: mov             SP, fp
    //     0xc38110: ldp             fp, lr, [SP], #0x10
    // 0xc38114: ret
    //     0xc38114: ret             
    // 0xc38118: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc38118: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3811c: b               #0xc38024
  }
  _ _getTextPositionForLine(/* No info */) {
    // ** addr: 0xc38120, size: 0x168
    // 0xc38120: EnterFrame
    //     0xc38120: stp             fp, lr, [SP, #-0x10]!
    //     0xc38124: mov             fp, SP
    // 0xc38128: AllocStack(0x38)
    //     0xc38128: sub             SP, SP, #0x38
    // 0xc3812c: CheckStackOverflow
    //     0xc3812c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc38130: cmp             SP, x16
    //     0xc38134: b.ls            #0xc3827c
    // 0xc38138: ldr             x2, [fp, #0x18]
    // 0xc3813c: LoadField: r3 = r2->field_27
    //     0xc3813c: ldur            w3, [x2, #0x27]
    // 0xc38140: DecompressPointer r3
    //     0xc38140: add             x3, x3, HEAP, lsl #32
    // 0xc38144: ldr             x4, [fp, #0x10]
    // 0xc38148: stur            x3, [fp, #-0x10]
    // 0xc3814c: r0 = BoxInt64Instr(r4)
    //     0xc3814c: sbfiz           x0, x4, #1, #0x1f
    //     0xc38150: cmp             x4, x0, asr #1
    //     0xc38154: b.eq            #0xc38160
    //     0xc38158: bl              #0xd69bb8
    //     0xc3815c: stur            x4, [x0, #7]
    // 0xc38160: stur            x0, [fp, #-8]
    // 0xc38164: stp             x0, x3, [SP, #-0x10]!
    // 0xc38168: r0 = _getValueOrData()
    //     0xc38168: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xc3816c: add             SP, SP, #0x10
    // 0xc38170: ldur            x2, [fp, #-0x10]
    // 0xc38174: LoadField: r1 = r2->field_f
    //     0xc38174: ldur            w1, [x2, #0xf]
    // 0xc38178: DecompressPointer r1
    //     0xc38178: add             x1, x1, HEAP, lsl #32
    // 0xc3817c: cmp             w1, w0
    // 0xc38180: b.ne            #0xc38188
    // 0xc38184: r0 = Null
    //     0xc38184: mov             x0, NULL
    // 0xc38188: cmp             w0, NULL
    // 0xc3818c: b.eq            #0xc3819c
    // 0xc38190: LeaveFrame
    //     0xc38190: mov             SP, fp
    //     0xc38194: ldp             fp, lr, [SP], #0x10
    // 0xc38198: ret
    //     0xc38198: ret             
    // 0xc3819c: ldr             x3, [fp, #0x18]
    // 0xc381a0: ldr             x4, [fp, #0x10]
    // 0xc381a4: LoadField: r0 = r3->field_b
    //     0xc381a4: ldur            w0, [x3, #0xb]
    // 0xc381a8: DecompressPointer r0
    //     0xc381a8: add             x0, x0, HEAP, lsl #32
    // 0xc381ac: LoadField: d0 = r0->field_7
    //     0xc381ac: ldur            d0, [x0, #7]
    // 0xc381b0: stur            d0, [fp, #-0x38]
    // 0xc381b4: LoadField: r5 = r3->field_1b
    //     0xc381b4: ldur            w5, [x3, #0x1b]
    // 0xc381b8: DecompressPointer r5
    //     0xc381b8: add             x5, x5, HEAP, lsl #32
    // 0xc381bc: LoadField: r0 = r5->field_b
    //     0xc381bc: ldur            w0, [x5, #0xb]
    // 0xc381c0: DecompressPointer r0
    //     0xc381c0: add             x0, x0, HEAP, lsl #32
    // 0xc381c4: r1 = LoadInt32Instr(r0)
    //     0xc381c4: sbfx            x1, x0, #1, #0x1f
    // 0xc381c8: mov             x0, x1
    // 0xc381cc: mov             x1, x4
    // 0xc381d0: cmp             x1, x0
    // 0xc381d4: b.hs            #0xc38284
    // 0xc381d8: LoadField: r0 = r5->field_f
    //     0xc381d8: ldur            w0, [x5, #0xf]
    // 0xc381dc: DecompressPointer r0
    //     0xc381dc: add             x0, x0, HEAP, lsl #32
    // 0xc381e0: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0xc381e0: add             x16, x0, x4, lsl #2
    //     0xc381e4: ldur            w1, [x16, #0xf]
    // 0xc381e8: DecompressPointer r1
    //     0xc381e8: add             x1, x1, HEAP, lsl #32
    // 0xc381ec: LoadField: d1 = r1->field_3b
    //     0xc381ec: ldur            d1, [x1, #0x3b]
    // 0xc381f0: stur            d1, [fp, #-0x30]
    // 0xc381f4: r0 = Offset()
    //     0xc381f4: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc381f8: ldur            d0, [fp, #-0x38]
    // 0xc381fc: stur            x0, [fp, #-0x18]
    // 0xc38200: StoreField: r0->field_7 = d0
    //     0xc38200: stur            d0, [x0, #7]
    // 0xc38204: ldur            d0, [fp, #-0x30]
    // 0xc38208: StoreField: r0->field_f = d0
    //     0xc38208: stur            d0, [x0, #0xf]
    // 0xc3820c: ldr             x1, [fp, #0x18]
    // 0xc38210: LoadField: r2 = r1->field_1f
    //     0xc38210: ldur            w2, [x1, #0x1f]
    // 0xc38214: DecompressPointer r2
    //     0xc38214: add             x2, x2, HEAP, lsl #32
    // 0xc38218: LoadField: r1 = r2->field_eb
    //     0xc38218: ldur            w1, [x2, #0xeb]
    // 0xc3821c: DecompressPointer r1
    //     0xc3821c: add             x1, x1, HEAP, lsl #32
    // 0xc38220: stp             x0, x1, [SP, #-0x10]!
    // 0xc38224: r0 = getPositionForOffset()
    //     0xc38224: bl              #0x6246bc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getPositionForOffset
    // 0xc38228: add             SP, SP, #0x10
    // 0xc3822c: r1 = <Offset, TextPosition>
    //     0xc3822c: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f6f0] TypeArguments: <Offset, TextPosition>
    //     0xc38230: ldr             x1, [x1, #0x6f0]
    // 0xc38234: stur            x0, [fp, #-0x20]
    // 0xc38238: r0 = MapEntry()
    //     0xc38238: bl              #0x52a1c0  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0xc3823c: mov             x1, x0
    // 0xc38240: ldur            x0, [fp, #-0x18]
    // 0xc38244: stur            x1, [fp, #-0x28]
    // 0xc38248: StoreField: r1->field_b = r0
    //     0xc38248: stur            w0, [x1, #0xb]
    // 0xc3824c: ldur            x0, [fp, #-0x20]
    // 0xc38250: StoreField: r1->field_f = r0
    //     0xc38250: stur            w0, [x1, #0xf]
    // 0xc38254: ldur            x16, [fp, #-0x10]
    // 0xc38258: ldur            lr, [fp, #-8]
    // 0xc3825c: stp             lr, x16, [SP, #-0x10]!
    // 0xc38260: SaveReg r1
    //     0xc38260: str             x1, [SP, #-8]!
    // 0xc38264: r0 = []=()
    //     0xc38264: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xc38268: add             SP, SP, #0x18
    // 0xc3826c: ldur            x0, [fp, #-0x28]
    // 0xc38270: LeaveFrame
    //     0xc38270: mov             SP, fp
    //     0xc38274: ldp             fp, lr, [SP], #0x10
    // 0xc38278: ret
    //     0xc38278: ret             
    // 0xc3827c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3827c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc38280: b               #0xc38138
    // 0xc38284: r0 = RangeErrorSharedWithFPURegs()
    //     0xc38284: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
  }
  _ movePrevious(/* No info */) {
    // ** addr: 0xcc0358, size: 0x100
    // 0xcc0358: EnterFrame
    //     0xcc0358: stp             fp, lr, [SP, #-0x10]!
    //     0xcc035c: mov             fp, SP
    // 0xcc0360: AllocStack(0x8)
    //     0xcc0360: sub             SP, SP, #8
    // 0xcc0364: CheckStackOverflow
    //     0xcc0364: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcc0368: cmp             SP, x16
    //     0xcc036c: b.ls            #0xcc0450
    // 0xcc0370: ldr             x0, [fp, #0x10]
    // 0xcc0374: LoadField: r1 = r0->field_f
    //     0xcc0374: ldur            x1, [x0, #0xf]
    // 0xcc0378: cmp             x1, #0
    // 0xcc037c: b.gt            #0xcc0390
    // 0xcc0380: r0 = false
    //     0xcc0380: add             x0, NULL, #0x30  ; false
    // 0xcc0384: LeaveFrame
    //     0xcc0384: mov             SP, fp
    //     0xcc0388: ldp             fp, lr, [SP], #0x10
    // 0xcc038c: ret
    //     0xcc038c: ret             
    // 0xcc0390: sub             x2, x1, #1
    // 0xcc0394: stp             x2, x0, [SP, #-0x10]!
    // 0xcc0398: r0 = _getTextPositionForLine()
    //     0xcc0398: bl              #0xc38120  ; [package:extended_text_field/src/extended_render_editable.dart] VerticalCaretMovementRun::_getTextPositionForLine
    // 0xcc039c: add             SP, SP, #0x10
    // 0xcc03a0: mov             x2, x0
    // 0xcc03a4: ldr             x1, [fp, #0x10]
    // 0xcc03a8: stur            x2, [fp, #-8]
    // 0xcc03ac: LoadField: r0 = r1->field_f
    //     0xcc03ac: ldur            x0, [x1, #0xf]
    // 0xcc03b0: sub             x3, x0, #1
    // 0xcc03b4: StoreField: r1->field_f = r3
    //     0xcc03b4: stur            x3, [x1, #0xf]
    // 0xcc03b8: r0 = LoadClassIdInstr(r2)
    //     0xcc03b8: ldur            x0, [x2, #-1]
    //     0xcc03bc: ubfx            x0, x0, #0xc, #0x14
    // 0xcc03c0: SaveReg r2
    //     0xcc03c0: str             x2, [SP, #-8]!
    // 0xcc03c4: r0 = GDT[cid_x0 + -0xfba]()
    //     0xcc03c4: sub             lr, x0, #0xfba
    //     0xcc03c8: ldr             lr, [x21, lr, lsl #3]
    //     0xcc03cc: blr             lr
    // 0xcc03d0: add             SP, SP, #8
    // 0xcc03d4: ldr             x1, [fp, #0x10]
    // 0xcc03d8: StoreField: r1->field_b = r0
    //     0xcc03d8: stur            w0, [x1, #0xb]
    //     0xcc03dc: tbz             w0, #0, #0xcc03f8
    //     0xcc03e0: ldurb           w16, [x1, #-1]
    //     0xcc03e4: ldurb           w17, [x0, #-1]
    //     0xcc03e8: and             x16, x17, x16, lsr #2
    //     0xcc03ec: tst             x16, HEAP, lsr #32
    //     0xcc03f0: b.eq            #0xcc03f8
    //     0xcc03f4: bl              #0xd6826c
    // 0xcc03f8: ldur            x0, [fp, #-8]
    // 0xcc03fc: r2 = LoadClassIdInstr(r0)
    //     0xcc03fc: ldur            x2, [x0, #-1]
    //     0xcc0400: ubfx            x2, x2, #0xc, #0x14
    // 0xcc0404: SaveReg r0
    //     0xcc0404: str             x0, [SP, #-8]!
    // 0xcc0408: mov             x0, x2
    // 0xcc040c: r0 = GDT[cid_x0 + -0xfc4]()
    //     0xcc040c: sub             lr, x0, #0xfc4
    //     0xcc0410: ldr             lr, [x21, lr, lsl #3]
    //     0xcc0414: blr             lr
    // 0xcc0418: add             SP, SP, #8
    // 0xcc041c: ldr             x1, [fp, #0x10]
    // 0xcc0420: StoreField: r1->field_17 = r0
    //     0xcc0420: stur            w0, [x1, #0x17]
    //     0xcc0424: tbz             w0, #0, #0xcc0440
    //     0xcc0428: ldurb           w16, [x1, #-1]
    //     0xcc042c: ldurb           w17, [x0, #-1]
    //     0xcc0430: and             x16, x17, x16, lsr #2
    //     0xcc0434: tst             x16, HEAP, lsr #32
    //     0xcc0438: b.eq            #0xcc0440
    //     0xcc043c: bl              #0xd6826c
    // 0xcc0440: r0 = true
    //     0xcc0440: add             x0, NULL, #0x20  ; true
    // 0xcc0444: LeaveFrame
    //     0xcc0444: mov             SP, fp
    //     0xcc0448: ldp             fp, lr, [SP], #0x10
    // 0xcc044c: ret
    //     0xcc044c: ret             
    // 0xcc0450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcc0450: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcc0454: b               #0xcc0370
  }
  _ VerticalCaretMovementRun._(/* No info */) {
    // ** addr: 0xcc050c, size: 0x108
    // 0xcc050c: EnterFrame
    //     0xcc050c: stp             fp, lr, [SP, #-0x10]!
    //     0xcc0510: mov             fp, SP
    // 0xcc0514: r0 = true
    //     0xcc0514: add             x0, NULL, #0x20  ; true
    // 0xcc0518: CheckStackOverflow
    //     0xcc0518: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcc051c: cmp             SP, x16
    //     0xcc0520: b.ls            #0xcc060c
    // 0xcc0524: ldr             x1, [fp, #0x38]
    // 0xcc0528: StoreField: r1->field_23 = r0
    //     0xcc0528: stur            w0, [x1, #0x23]
    // 0xcc052c: r16 = <int, MapEntry<Offset, TextPosition>>
    //     0xcc052c: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f700] TypeArguments: <int, MapEntry<Offset, TextPosition>>
    //     0xcc0530: ldr             x16, [x16, #0x700]
    // 0xcc0534: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xcc0538: stp             lr, x16, [SP, #-0x10]!
    // 0xcc053c: r0 = Map._fromLiteral()
    //     0xcc053c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xcc0540: add             SP, SP, #0x10
    // 0xcc0544: ldr             x1, [fp, #0x38]
    // 0xcc0548: StoreField: r1->field_27 = r0
    //     0xcc0548: stur            w0, [x1, #0x27]
    //     0xcc054c: tbz             w0, #0, #0xcc0568
    //     0xcc0550: ldurb           w16, [x1, #-1]
    //     0xcc0554: ldurb           w17, [x0, #-1]
    //     0xcc0558: and             x16, x17, x16, lsr #2
    //     0xcc055c: tst             x16, HEAP, lsr #32
    //     0xcc0560: b.eq            #0xcc0568
    //     0xcc0564: bl              #0xd6826c
    // 0xcc0568: ldr             x0, [fp, #0x30]
    // 0xcc056c: StoreField: r1->field_1f = r0
    //     0xcc056c: stur            w0, [x1, #0x1f]
    //     0xcc0570: ldurb           w16, [x1, #-1]
    //     0xcc0574: ldurb           w17, [x0, #-1]
    //     0xcc0578: and             x16, x17, x16, lsr #2
    //     0xcc057c: tst             x16, HEAP, lsr #32
    //     0xcc0580: b.eq            #0xcc0588
    //     0xcc0584: bl              #0xd6826c
    // 0xcc0588: ldr             x0, [fp, #0x28]
    // 0xcc058c: StoreField: r1->field_1b = r0
    //     0xcc058c: stur            w0, [x1, #0x1b]
    //     0xcc0590: ldurb           w16, [x1, #-1]
    //     0xcc0594: ldurb           w17, [x0, #-1]
    //     0xcc0598: and             x16, x17, x16, lsr #2
    //     0xcc059c: tst             x16, HEAP, lsr #32
    //     0xcc05a0: b.eq            #0xcc05a8
    //     0xcc05a4: bl              #0xd6826c
    // 0xcc05a8: ldr             x0, [fp, #0x20]
    // 0xcc05ac: StoreField: r1->field_17 = r0
    //     0xcc05ac: stur            w0, [x1, #0x17]
    //     0xcc05b0: ldurb           w16, [x1, #-1]
    //     0xcc05b4: ldurb           w17, [x0, #-1]
    //     0xcc05b8: and             x16, x17, x16, lsr #2
    //     0xcc05bc: tst             x16, HEAP, lsr #32
    //     0xcc05c0: b.eq            #0xcc05c8
    //     0xcc05c4: bl              #0xd6826c
    // 0xcc05c8: ldr             x2, [fp, #0x18]
    // 0xcc05cc: r3 = LoadInt32Instr(r2)
    //     0xcc05cc: sbfx            x3, x2, #1, #0x1f
    //     0xcc05d0: tbz             w2, #0, #0xcc05d8
    //     0xcc05d4: ldur            x3, [x2, #7]
    // 0xcc05d8: StoreField: r1->field_f = r3
    //     0xcc05d8: stur            x3, [x1, #0xf]
    // 0xcc05dc: ldr             x0, [fp, #0x10]
    // 0xcc05e0: StoreField: r1->field_b = r0
    //     0xcc05e0: stur            w0, [x1, #0xb]
    //     0xcc05e4: ldurb           w16, [x1, #-1]
    //     0xcc05e8: ldurb           w17, [x0, #-1]
    //     0xcc05ec: and             x16, x17, x16, lsr #2
    //     0xcc05f0: tst             x16, HEAP, lsr #32
    //     0xcc05f4: b.eq            #0xcc05fc
    //     0xcc05f8: bl              #0xd6826c
    // 0xcc05fc: r0 = Null
    //     0xcc05fc: mov             x0, NULL
    // 0xcc0600: LeaveFrame
    //     0xcc0600: mov             SP, fp
    //     0xcc0604: ldp             fp, lr, [SP], #0x10
    // 0xcc0608: ret
    //     0xcc0608: ret             
    // 0xcc060c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcc060c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcc0610: b               #0xcc0524
  }
  get _ isValid(/* No info */) {
    // ** addr: 0xcc11b4, size: 0x88
    // 0xcc11b4: EnterFrame
    //     0xcc11b4: stp             fp, lr, [SP, #-0x10]!
    //     0xcc11b8: mov             fp, SP
    // 0xcc11bc: CheckStackOverflow
    //     0xcc11bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcc11c0: cmp             SP, x16
    //     0xcc11c4: b.ls            #0xcc1234
    // 0xcc11c8: ldr             x0, [fp, #0x10]
    // 0xcc11cc: LoadField: r1 = r0->field_23
    //     0xcc11cc: ldur            w1, [x0, #0x23]
    // 0xcc11d0: DecompressPointer r1
    //     0xcc11d0: add             x1, x1, HEAP, lsl #32
    // 0xcc11d4: tbz             w1, #4, #0xcc11e8
    // 0xcc11d8: r0 = false
    //     0xcc11d8: add             x0, NULL, #0x30  ; false
    // 0xcc11dc: LeaveFrame
    //     0xcc11dc: mov             SP, fp
    //     0xcc11e0: ldp             fp, lr, [SP], #0x10
    // 0xcc11e4: ret
    //     0xcc11e4: ret             
    // 0xcc11e8: LoadField: r1 = r0->field_1f
    //     0xcc11e8: ldur            w1, [x0, #0x1f]
    // 0xcc11ec: DecompressPointer r1
    //     0xcc11ec: add             x1, x1, HEAP, lsl #32
    // 0xcc11f0: LoadField: r2 = r1->field_eb
    //     0xcc11f0: ldur            w2, [x1, #0xeb]
    // 0xcc11f4: DecompressPointer r2
    //     0xcc11f4: add             x2, x2, HEAP, lsl #32
    // 0xcc11f8: SaveReg r2
    //     0xcc11f8: str             x2, [SP, #-8]!
    // 0xcc11fc: r0 = computeLineMetrics()
    //     0xcc11fc: bl              #0xcc0a2c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::computeLineMetrics
    // 0xcc1200: add             SP, SP, #8
    // 0xcc1204: ldr             x1, [fp, #0x10]
    // 0xcc1208: LoadField: r2 = r1->field_1b
    //     0xcc1208: ldur            w2, [x1, #0x1b]
    // 0xcc120c: DecompressPointer r2
    //     0xcc120c: add             x2, x2, HEAP, lsl #32
    // 0xcc1210: cmp             w0, w2
    // 0xcc1214: b.eq            #0xcc1220
    // 0xcc1218: r2 = false
    //     0xcc1218: add             x2, NULL, #0x30  ; false
    // 0xcc121c: StoreField: r1->field_23 = r2
    //     0xcc121c: stur            w2, [x1, #0x23]
    // 0xcc1220: LoadField: r0 = r1->field_23
    //     0xcc1220: ldur            w0, [x1, #0x23]
    // 0xcc1224: DecompressPointer r0
    //     0xcc1224: add             x0, x0, HEAP, lsl #32
    // 0xcc1228: LeaveFrame
    //     0xcc1228: mov             SP, fp
    //     0xcc122c: ldp             fp, lr, [SP], #0x10
    // 0xcc1230: ret
    //     0xcc1230: ret             
    // 0xcc1234: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcc1234: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcc1238: b               #0xcc11c8
  }
}

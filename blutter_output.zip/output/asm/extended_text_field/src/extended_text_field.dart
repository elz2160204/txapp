// lib: , url: package:extended_text_field/src/extended_text_field.dart

// class id: 1048971, size: 0x8
class :: {
}

// class id: 3367, size: 0x24, field offset: 0x14
//   transformed mixin,
abstract class _ExtendedTextFieldState&State&RestorationMixin extends State<ExtendedTextField>
     with RestorationMixin<X0 bound StatefulWidget> {

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7ae5b4, size: 0x78
    // 0x7ae5b4: EnterFrame
    //     0x7ae5b4: stp             fp, lr, [SP, #-0x10]!
    //     0x7ae5b8: mov             fp, SP
    // 0x7ae5bc: CheckStackOverflow
    //     0x7ae5bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ae5c0: cmp             SP, x16
    //     0x7ae5c4: b.ls            #0x7ae624
    // 0x7ae5c8: ldr             x3, [fp, #0x18]
    // 0x7ae5cc: LoadField: r2 = r3->field_7
    //     0x7ae5cc: ldur            w2, [x3, #7]
    // 0x7ae5d0: DecompressPointer r2
    //     0x7ae5d0: add             x2, x2, HEAP, lsl #32
    // 0x7ae5d4: ldr             x0, [fp, #0x10]
    // 0x7ae5d8: r1 = Null
    //     0x7ae5d8: mov             x1, NULL
    // 0x7ae5dc: cmp             w2, NULL
    // 0x7ae5e0: b.eq            #0x7ae604
    // 0x7ae5e4: LoadField: r4 = r2->field_17
    //     0x7ae5e4: ldur            w4, [x2, #0x17]
    // 0x7ae5e8: DecompressPointer r4
    //     0x7ae5e8: add             x4, x4, HEAP, lsl #32
    // 0x7ae5ec: r8 = X0 bound StatefulWidget
    //     0x7ae5ec: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7ae5f0: ldr             x8, [x8, #0x858]
    // 0x7ae5f4: LoadField: r9 = r4->field_7
    //     0x7ae5f4: ldur            x9, [x4, #7]
    // 0x7ae5f8: r3 = Null
    //     0x7ae5f8: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4bc90] Null
    //     0x7ae5fc: ldr             x3, [x3, #0xc90]
    // 0x7ae600: blr             x9
    // 0x7ae604: ldr             x16, [fp, #0x18]
    // 0x7ae608: SaveReg r16
    //     0x7ae608: str             x16, [SP, #-8]!
    // 0x7ae60c: r0 = didUpdateRestorationId()
    //     0x7ae60c: bl              #0x7ae62c  ; [package:extended_text_field/src/extended_text_field.dart] _ExtendedTextFieldState&State&RestorationMixin::didUpdateRestorationId
    // 0x7ae610: add             SP, SP, #8
    // 0x7ae614: r0 = Null
    //     0x7ae614: mov             x0, NULL
    // 0x7ae618: LeaveFrame
    //     0x7ae618: mov             SP, fp
    //     0x7ae61c: ldp             fp, lr, [SP], #0x10
    // 0x7ae620: ret
    //     0x7ae620: ret             
    // 0x7ae624: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ae624: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ae628: b               #0x7ae5c8
  }
  _ didUpdateRestorationId(/* No info */) {
    // ** addr: 0x7ae62c, size: 0x40
    // 0x7ae62c: EnterFrame
    //     0x7ae62c: stp             fp, lr, [SP, #-0x10]!
    //     0x7ae630: mov             fp, SP
    // 0x7ae634: ldr             x1, [fp, #0x10]
    // 0x7ae638: LoadField: r2 = r1->field_1f
    //     0x7ae638: ldur            w2, [x1, #0x1f]
    // 0x7ae63c: DecompressPointer r2
    //     0x7ae63c: add             x2, x2, HEAP, lsl #32
    // 0x7ae640: cmp             w2, NULL
    // 0x7ae644: b.eq            #0x7ae658
    // 0x7ae648: LoadField: r2 = r1->field_b
    //     0x7ae648: ldur            w2, [x1, #0xb]
    // 0x7ae64c: DecompressPointer r2
    //     0x7ae64c: add             x2, x2, HEAP, lsl #32
    // 0x7ae650: cmp             w2, NULL
    // 0x7ae654: b.eq            #0x7ae668
    // 0x7ae658: r0 = Null
    //     0x7ae658: mov             x0, NULL
    // 0x7ae65c: LeaveFrame
    //     0x7ae65c: mov             SP, fp
    //     0x7ae660: ldp             fp, lr, [SP], #0x10
    // 0x7ae664: ret
    //     0x7ae664: ret             
    // 0x7ae668: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ae668: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4fe0c, size: 0x68
    // 0xa4fe0c: EnterFrame
    //     0xa4fe0c: stp             fp, lr, [SP, #-0x10]!
    //     0xa4fe10: mov             fp, SP
    // 0xa4fe14: AllocStack(0x8)
    //     0xa4fe14: sub             SP, SP, #8
    // 0xa4fe18: CheckStackOverflow
    //     0xa4fe18: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4fe1c: cmp             SP, x16
    //     0xa4fe20: b.ls            #0xa4fe6c
    // 0xa4fe24: ldr             x0, [fp, #0x10]
    // 0xa4fe28: LoadField: r3 = r0->field_17
    //     0xa4fe28: ldur            w3, [x0, #0x17]
    // 0xa4fe2c: DecompressPointer r3
    //     0xa4fe2c: add             x3, x3, HEAP, lsl #32
    // 0xa4fe30: stur            x3, [fp, #-8]
    // 0xa4fe34: r1 = Function '<anonymous closure>':.
    //     0xa4fe34: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bc88] AnonymousClosure: (0xa4f4b4), in [package:flutter/src/material/scaffold.dart] _ScaffoldState&State&TickerProviderStateMixin&RestorationMixin::dispose (0xa4f500)
    //     0xa4fe38: ldr             x1, [x1, #0xc88]
    // 0xa4fe3c: r2 = Null
    //     0xa4fe3c: mov             x2, NULL
    // 0xa4fe40: r0 = AllocateClosure()
    //     0xa4fe40: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa4fe44: ldur            x16, [fp, #-8]
    // 0xa4fe48: stp             x0, x16, [SP, #-0x10]!
    // 0xa4fe4c: r0 = forEach()
    //     0xa4fe4c: bl              #0xca3d28  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::forEach
    // 0xa4fe50: add             SP, SP, #0x10
    // 0xa4fe54: ldr             x1, [fp, #0x10]
    // 0xa4fe58: StoreField: r1->field_13 = rNULL
    //     0xa4fe58: stur            NULL, [x1, #0x13]
    // 0xa4fe5c: r0 = Null
    //     0xa4fe5c: mov             x0, NULL
    // 0xa4fe60: LeaveFrame
    //     0xa4fe60: mov             SP, fp
    //     0xa4fe64: ldp             fp, lr, [SP], #0x10
    // 0xa4fe68: ret
    //     0xa4fe68: ret             
    // 0xa4fe6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4fe6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4fe70: b               #0xa4fe24
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4fe74, size: 0x48
    // 0xa4fe74: EnterFrame
    //     0xa4fe74: stp             fp, lr, [SP, #-0x10]!
    //     0xa4fe78: mov             fp, SP
    // 0xa4fe7c: ldr             x0, [fp, #0x10]
    // 0xa4fe80: LoadField: r1 = r0->field_17
    //     0xa4fe80: ldur            w1, [x0, #0x17]
    // 0xa4fe84: DecompressPointer r1
    //     0xa4fe84: add             x1, x1, HEAP, lsl #32
    // 0xa4fe88: CheckStackOverflow
    //     0xa4fe88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4fe8c: cmp             SP, x16
    //     0xa4fe90: b.ls            #0xa4feb4
    // 0xa4fe94: LoadField: r0 = r1->field_f
    //     0xa4fe94: ldur            w0, [x1, #0xf]
    // 0xa4fe98: DecompressPointer r0
    //     0xa4fe98: add             x0, x0, HEAP, lsl #32
    // 0xa4fe9c: SaveReg r0
    //     0xa4fe9c: str             x0, [SP, #-8]!
    // 0xa4fea0: r0 = dispose()
    //     0xa4fea0: bl              #0xa4fe0c  ; [package:extended_text_field/src/extended_text_field.dart] _ExtendedTextFieldState&State&RestorationMixin::dispose
    // 0xa4fea4: add             SP, SP, #8
    // 0xa4fea8: LeaveFrame
    //     0xa4fea8: mov             SP, fp
    //     0xa4feac: ldp             fp, lr, [SP], #0x10
    // 0xa4feb0: ret
    //     0xa4feb0: ret             
    // 0xa4feb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4feb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4feb8: b               #0xa4fe94
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xa60acc, size: 0xd4
    // 0xa60acc: EnterFrame
    //     0xa60acc: stp             fp, lr, [SP, #-0x10]!
    //     0xa60ad0: mov             fp, SP
    // 0xa60ad4: AllocStack(0x8)
    //     0xa60ad4: sub             SP, SP, #8
    // 0xa60ad8: CheckStackOverflow
    //     0xa60ad8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa60adc: cmp             SP, x16
    //     0xa60ae0: b.ls            #0xa60b90
    // 0xa60ae4: ldr             x0, [fp, #0x10]
    // 0xa60ae8: LoadField: r1 = r0->field_1b
    //     0xa60ae8: ldur            w1, [x0, #0x1b]
    // 0xa60aec: DecompressPointer r1
    //     0xa60aec: add             x1, x1, HEAP, lsl #32
    // 0xa60af0: tbnz            w1, #4, #0xa60afc
    // 0xa60af4: r1 = true
    //     0xa60af4: add             x1, NULL, #0x20  ; true
    // 0xa60af8: b               #0xa60b10
    // 0xa60afc: LoadField: r1 = r0->field_b
    //     0xa60afc: ldur            w1, [x0, #0xb]
    // 0xa60b00: DecompressPointer r1
    //     0xa60b00: add             x1, x1, HEAP, lsl #32
    // 0xa60b04: cmp             w1, NULL
    // 0xa60b08: b.eq            #0xa60b98
    // 0xa60b0c: r1 = false
    //     0xa60b0c: add             x1, NULL, #0x30  ; false
    // 0xa60b10: stur            x1, [fp, #-8]
    // 0xa60b14: LoadField: r2 = r0->field_f
    //     0xa60b14: ldur            w2, [x0, #0xf]
    // 0xa60b18: DecompressPointer r2
    //     0xa60b18: add             x2, x2, HEAP, lsl #32
    // 0xa60b1c: cmp             w2, NULL
    // 0xa60b20: b.eq            #0xa60b9c
    // 0xa60b24: SaveReg r2
    //     0xa60b24: str             x2, [SP, #-8]!
    // 0xa60b28: r0 = maybeOf()
    //     0xa60b28: bl              #0x79e9e4  ; [package:flutter/src/widgets/restoration.dart] RestorationScope::maybeOf
    // 0xa60b2c: add             SP, SP, #8
    // 0xa60b30: mov             x2, x0
    // 0xa60b34: ldr             x1, [fp, #0x10]
    // 0xa60b38: StoreField: r1->field_1f = r0
    //     0xa60b38: stur            w0, [x1, #0x1f]
    //     0xa60b3c: ldurb           w16, [x1, #-1]
    //     0xa60b40: ldurb           w17, [x0, #-1]
    //     0xa60b44: and             x16, x17, x16, lsr #2
    //     0xa60b48: tst             x16, HEAP, lsr #32
    //     0xa60b4c: b.eq            #0xa60b54
    //     0xa60b50: bl              #0xd6826c
    // 0xa60b54: stp             x2, x1, [SP, #-0x10]!
    // 0xa60b58: ldur            x16, [fp, #-8]
    // 0xa60b5c: SaveReg r16
    //     0xa60b5c: str             x16, [SP, #-8]!
    // 0xa60b60: r0 = _updateBucketIfNecessary()
    //     0xa60b60: bl              #0xa60d9c  ; [package:extended_text_field/src/extended_text_field.dart] _ExtendedTextFieldState&State&RestorationMixin::_updateBucketIfNecessary
    // 0xa60b64: add             SP, SP, #0x18
    // 0xa60b68: ldur            x0, [fp, #-8]
    // 0xa60b6c: tbnz            w0, #4, #0xa60b80
    // 0xa60b70: ldr             x16, [fp, #0x10]
    // 0xa60b74: SaveReg r16
    //     0xa60b74: str             x16, [SP, #-8]!
    // 0xa60b78: r0 = _doRestore()
    //     0xa60b78: bl              #0xa60ba0  ; [package:extended_text_field/src/extended_text_field.dart] _ExtendedTextFieldState&State&RestorationMixin::_doRestore
    // 0xa60b7c: add             SP, SP, #8
    // 0xa60b80: r0 = Null
    //     0xa60b80: mov             x0, NULL
    // 0xa60b84: LeaveFrame
    //     0xa60b84: mov             SP, fp
    //     0xa60b88: ldp             fp, lr, [SP], #0x10
    // 0xa60b8c: ret
    //     0xa60b8c: ret             
    // 0xa60b90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa60b90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa60b94: b               #0xa60ae4
    // 0xa60b98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa60b98: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa60b9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa60b9c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _doRestore(/* No info */) {
    // ** addr: 0xa60ba0, size: 0x50
    // 0xa60ba0: EnterFrame
    //     0xa60ba0: stp             fp, lr, [SP, #-0x10]!
    //     0xa60ba4: mov             fp, SP
    // 0xa60ba8: CheckStackOverflow
    //     0xa60ba8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa60bac: cmp             SP, x16
    //     0xa60bb0: b.ls            #0xa60be8
    // 0xa60bb4: ldr             x0, [fp, #0x10]
    // 0xa60bb8: LoadField: r1 = r0->field_1b
    //     0xa60bb8: ldur            w1, [x0, #0x1b]
    // 0xa60bbc: DecompressPointer r1
    //     0xa60bbc: add             x1, x1, HEAP, lsl #32
    // 0xa60bc0: stp             x1, x0, [SP, #-0x10]!
    // 0xa60bc4: r0 = restoreState()
    //     0xa60bc4: bl              #0xa60bf0  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::restoreState
    // 0xa60bc8: add             SP, SP, #0x10
    // 0xa60bcc: ldr             x2, [fp, #0x10]
    // 0xa60bd0: r1 = false
    //     0xa60bd0: add             x1, NULL, #0x30  ; false
    // 0xa60bd4: StoreField: r2->field_1b = r1
    //     0xa60bd4: stur            w1, [x2, #0x1b]
    // 0xa60bd8: r0 = Null
    //     0xa60bd8: mov             x0, NULL
    // 0xa60bdc: LeaveFrame
    //     0xa60bdc: mov             SP, fp
    //     0xa60be0: ldp             fp, lr, [SP], #0x10
    // 0xa60be4: ret
    //     0xa60be4: ret             
    // 0xa60be8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa60be8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa60bec: b               #0xa60bb4
  }
  _ registerForRestoration(/* No info */) {
    // ** addr: 0xa60c8c, size: 0x110
    // 0xa60c8c: EnterFrame
    //     0xa60c8c: stp             fp, lr, [SP, #-0x10]!
    //     0xa60c90: mov             fp, SP
    // 0xa60c94: AllocStack(0x20)
    //     0xa60c94: sub             SP, SP, #0x20
    // 0xa60c98: CheckStackOverflow
    //     0xa60c98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa60c9c: cmp             SP, x16
    //     0xa60ca0: b.ls            #0xa60d94
    // 0xa60ca4: r1 = 2
    //     0xa60ca4: mov             x1, #2
    // 0xa60ca8: r0 = AllocateContext()
    //     0xa60ca8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa60cac: mov             x1, x0
    // 0xa60cb0: ldr             x0, [fp, #0x18]
    // 0xa60cb4: stur            x1, [fp, #-8]
    // 0xa60cb8: StoreField: r1->field_f = r0
    //     0xa60cb8: stur            w0, [x1, #0xf]
    // 0xa60cbc: ldr             x2, [fp, #0x10]
    // 0xa60cc0: StoreField: r1->field_13 = r2
    //     0xa60cc0: stur            w2, [x1, #0x13]
    // 0xa60cc4: SaveReg r2
    //     0xa60cc4: str             x2, [SP, #-8]!
    // 0xa60cc8: r0 = createDefaultValue()
    //     0xa60cc8: bl              #0xc3bcb8  ; [package:flutter/src/widgets/restoration_properties.dart] RestorableTextEditingController::createDefaultValue
    // 0xa60ccc: add             SP, SP, #8
    // 0xa60cd0: ldur            x2, [fp, #-8]
    // 0xa60cd4: stur            x0, [fp, #-0x10]
    // 0xa60cd8: LoadField: r1 = r2->field_13
    //     0xa60cd8: ldur            w1, [x2, #0x13]
    // 0xa60cdc: DecompressPointer r1
    //     0xa60cdc: add             x1, x1, HEAP, lsl #32
    // 0xa60ce0: LoadField: r3 = r1->field_2b
    //     0xa60ce0: ldur            w3, [x1, #0x2b]
    // 0xa60ce4: DecompressPointer r3
    //     0xa60ce4: add             x3, x3, HEAP, lsl #32
    // 0xa60ce8: cmp             w3, NULL
    // 0xa60cec: b.ne            #0xa60d68
    // 0xa60cf0: ldr             x3, [fp, #0x18]
    // 0xa60cf4: r16 = "controller"
    //     0xa60cf4: ldr             x16, [PP, #0x5018]  ; [pp+0x5018] "controller"
    // 0xa60cf8: stp             x16, x1, [SP, #-0x10]!
    // 0xa60cfc: SaveReg r3
    //     0xa60cfc: str             x3, [SP, #-8]!
    // 0xa60d00: r0 = _register()
    //     0xa60d00: bl              #0xa600bc  ; [package:flutter/src/widgets/restoration.dart] RestorableProperty::_register
    // 0xa60d04: add             SP, SP, #0x18
    // 0xa60d08: ldur            x0, [fp, #-8]
    // 0xa60d0c: LoadField: r3 = r0->field_13
    //     0xa60d0c: ldur            w3, [x0, #0x13]
    // 0xa60d10: DecompressPointer r3
    //     0xa60d10: add             x3, x3, HEAP, lsl #32
    // 0xa60d14: mov             x2, x0
    // 0xa60d18: stur            x3, [fp, #-0x18]
    // 0xa60d1c: r1 = Function 'listener':.
    //     0xa60d1c: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bca0] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0xa60d20: ldr             x1, [x1, #0xca0]
    // 0xa60d24: r0 = AllocateClosure()
    //     0xa60d24: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa60d28: stur            x0, [fp, #-0x20]
    // 0xa60d2c: ldur            x16, [fp, #-0x18]
    // 0xa60d30: stp             x0, x16, [SP, #-0x10]!
    // 0xa60d34: r0 = addListener()
    //     0xa60d34: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xa60d38: add             SP, SP, #0x10
    // 0xa60d3c: ldr             x0, [fp, #0x18]
    // 0xa60d40: LoadField: r1 = r0->field_17
    //     0xa60d40: ldur            w1, [x0, #0x17]
    // 0xa60d44: DecompressPointer r1
    //     0xa60d44: add             x1, x1, HEAP, lsl #32
    // 0xa60d48: ldur            x0, [fp, #-8]
    // 0xa60d4c: LoadField: r2 = r0->field_13
    //     0xa60d4c: ldur            w2, [x0, #0x13]
    // 0xa60d50: DecompressPointer r2
    //     0xa60d50: add             x2, x2, HEAP, lsl #32
    // 0xa60d54: stp             x2, x1, [SP, #-0x10]!
    // 0xa60d58: ldur            x16, [fp, #-0x20]
    // 0xa60d5c: SaveReg r16
    //     0xa60d5c: str             x16, [SP, #-8]!
    // 0xa60d60: r0 = []=()
    //     0xa60d60: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xa60d64: add             SP, SP, #0x18
    // 0xa60d68: ldur            x0, [fp, #-8]
    // 0xa60d6c: LoadField: r1 = r0->field_13
    //     0xa60d6c: ldur            w1, [x0, #0x13]
    // 0xa60d70: DecompressPointer r1
    //     0xa60d70: add             x1, x1, HEAP, lsl #32
    // 0xa60d74: ldur            x16, [fp, #-0x10]
    // 0xa60d78: stp             x16, x1, [SP, #-0x10]!
    // 0xa60d7c: r0 = initWithValue()
    //     0xa60d7c: bl              #0xc3ba4c  ; [package:flutter/src/widgets/restoration_properties.dart] RestorableChangeNotifier::initWithValue
    // 0xa60d80: add             SP, SP, #0x10
    // 0xa60d84: r0 = Null
    //     0xa60d84: mov             x0, NULL
    // 0xa60d88: LeaveFrame
    //     0xa60d88: mov             SP, fp
    //     0xa60d8c: ldp             fp, lr, [SP], #0x10
    // 0xa60d90: ret
    //     0xa60d90: ret             
    // 0xa60d94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa60d94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa60d98: b               #0xa60ca4
  }
  _ _updateBucketIfNecessary(/* No info */) {
    // ** addr: 0xa60d9c, size: 0x54
    // 0xa60d9c: EnterFrame
    //     0xa60d9c: stp             fp, lr, [SP, #-0x10]!
    //     0xa60da0: mov             fp, SP
    // 0xa60da4: CheckStackOverflow
    //     0xa60da4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa60da8: cmp             SP, x16
    //     0xa60dac: b.ls            #0xa60de4
    // 0xa60db0: ldr             x0, [fp, #0x20]
    // 0xa60db4: LoadField: r1 = r0->field_b
    //     0xa60db4: ldur            w1, [x0, #0xb]
    // 0xa60db8: DecompressPointer r1
    //     0xa60db8: add             x1, x1, HEAP, lsl #32
    // 0xa60dbc: cmp             w1, NULL
    // 0xa60dc0: b.eq            #0xa60dec
    // 0xa60dc4: stp             NULL, x0, [SP, #-0x10]!
    // 0xa60dc8: ldr             x16, [fp, #0x10]
    // 0xa60dcc: SaveReg r16
    //     0xa60dcc: str             x16, [SP, #-8]!
    // 0xa60dd0: r0 = _simpleInstanceOfFalse()
    //     0xa60dd0: bl              #0xd67368  ; [dart:core] Object::_simpleInstanceOfFalse
    // 0xa60dd4: add             SP, SP, #0x18
    // 0xa60dd8: LeaveFrame
    //     0xa60dd8: mov             SP, fp
    //     0xa60ddc: ldp             fp, lr, [SP], #0x10
    // 0xa60de0: ret
    //     0xa60de0: ret             
    // 0xa60de4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa60de4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa60de8: b               #0xa60db0
    // 0xa60dec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa60dec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3368, size: 0x40, field offset: 0x24
class ExtendedTextFieldState extends _ExtendedTextFieldState&State&RestorationMixin
    implements ExtendedTextSelectionGestureDetectorBuilderDelegate, AutofillClient {

  late CommonTextSelectionGestureDetectorBuilder _selectionGestureDetectorBuilder; // offset: 0x34
  late bool forcePressEnabled; // offset: 0x38

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7acad4, size: 0x11c
    // 0x7acad4: EnterFrame
    //     0x7acad4: stp             fp, lr, [SP, #-0x10]!
    //     0x7acad8: mov             fp, SP
    // 0x7acadc: AllocStack(0x8)
    //     0x7acadc: sub             SP, SP, #8
    // 0x7acae0: CheckStackOverflow
    //     0x7acae0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7acae4: cmp             SP, x16
    //     0x7acae8: b.ls            #0x7acbdc
    // 0x7acaec: ldr             x0, [fp, #0x10]
    // 0x7acaf0: r2 = Null
    //     0x7acaf0: mov             x2, NULL
    // 0x7acaf4: r1 = Null
    //     0x7acaf4: mov             x1, NULL
    // 0x7acaf8: r4 = 59
    //     0x7acaf8: mov             x4, #0x3b
    // 0x7acafc: branchIfSmi(r0, 0x7acb08)
    //     0x7acafc: tbz             w0, #0, #0x7acb08
    // 0x7acb00: r4 = LoadClassIdInstr(r0)
    //     0x7acb00: ldur            x4, [x0, #-1]
    //     0x7acb04: ubfx            x4, x4, #0xc, #0x14
    // 0x7acb08: r17 = 4188
    //     0x7acb08: mov             x17, #0x105c
    // 0x7acb0c: cmp             x4, x17
    // 0x7acb10: b.eq            #0x7acb28
    // 0x7acb14: r8 = ExtendedTextField
    //     0x7acb14: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4be88] Type: ExtendedTextField
    //     0x7acb18: ldr             x8, [x8, #0xe88]
    // 0x7acb1c: r3 = Null
    //     0x7acb1c: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4be90] Null
    //     0x7acb20: ldr             x3, [x3, #0xe90]
    // 0x7acb24: r0 = ExtendedTextField()
    //     0x7acb24: bl              #0x7ae66c  ; IsType_ExtendedTextField_Stub
    // 0x7acb28: ldr             x16, [fp, #0x18]
    // 0x7acb2c: ldr             lr, [fp, #0x10]
    // 0x7acb30: stp             lr, x16, [SP, #-0x10]!
    // 0x7acb34: r0 = didUpdateWidget()
    //     0x7acb34: bl              #0x7ae5b4  ; [package:extended_text_field/src/extended_text_field.dart] _ExtendedTextFieldState&State&RestorationMixin::didUpdateWidget
    // 0x7acb38: add             SP, SP, #0x10
    // 0x7acb3c: ldr             x0, [fp, #0x18]
    // 0x7acb40: LoadField: r1 = r0->field_b
    //     0x7acb40: ldur            w1, [x0, #0xb]
    // 0x7acb44: DecompressPointer r1
    //     0x7acb44: add             x1, x1, HEAP, lsl #32
    // 0x7acb48: cmp             w1, NULL
    // 0x7acb4c: b.eq            #0x7acbe4
    // 0x7acb50: SaveReg r0
    //     0x7acb50: str             x0, [SP, #-8]!
    // 0x7acb54: r0 = _effectiveFocusNode()
    //     0x7acb54: bl              #0x7ae50c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveFocusNode
    // 0x7acb58: add             SP, SP, #8
    // 0x7acb5c: stur            x0, [fp, #-8]
    // 0x7acb60: ldr             x16, [fp, #0x18]
    // 0x7acb64: SaveReg r16
    //     0x7acb64: str             x16, [SP, #-8]!
    // 0x7acb68: r0 = _canRequestFocus()
    //     0x7acb68: bl              #0x7ae418  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_canRequestFocus
    // 0x7acb6c: add             SP, SP, #8
    // 0x7acb70: ldur            x16, [fp, #-8]
    // 0x7acb74: stp             x0, x16, [SP, #-0x10]!
    // 0x7acb78: r0 = canRequestFocus=()
    //     0x7acb78: bl              #0x7acbf0  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::canRequestFocus=
    // 0x7acb7c: add             SP, SP, #0x10
    // 0x7acb80: ldr             x16, [fp, #0x18]
    // 0x7acb84: SaveReg r16
    //     0x7acb84: str             x16, [SP, #-8]!
    // 0x7acb88: r0 = _effectiveFocusNode()
    //     0x7acb88: bl              #0x7ae50c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveFocusNode
    // 0x7acb8c: add             SP, SP, #8
    // 0x7acb90: SaveReg r0
    //     0x7acb90: str             x0, [SP, #-8]!
    // 0x7acb94: r0 = hasFocus()
    //     0x7acb94: bl              #0x6f8fe4  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0x7acb98: add             SP, SP, #8
    // 0x7acb9c: tbnz            w0, #4, #0x7acbb8
    // 0x7acba0: ldr             x1, [fp, #0x18]
    // 0x7acba4: LoadField: r2 = r1->field_b
    //     0x7acba4: ldur            w2, [x1, #0xb]
    // 0x7acba8: DecompressPointer r2
    //     0x7acba8: add             x2, x2, HEAP, lsl #32
    // 0x7acbac: cmp             w2, NULL
    // 0x7acbb0: b.eq            #0x7acbe8
    // 0x7acbb4: b               #0x7acbbc
    // 0x7acbb8: ldr             x1, [fp, #0x18]
    // 0x7acbbc: LoadField: r2 = r1->field_b
    //     0x7acbbc: ldur            w2, [x1, #0xb]
    // 0x7acbc0: DecompressPointer r2
    //     0x7acbc0: add             x2, x2, HEAP, lsl #32
    // 0x7acbc4: cmp             w2, NULL
    // 0x7acbc8: b.eq            #0x7acbec
    // 0x7acbcc: r0 = Null
    //     0x7acbcc: mov             x0, NULL
    // 0x7acbd0: LeaveFrame
    //     0x7acbd0: mov             SP, fp
    //     0x7acbd4: ldp             fp, lr, [SP], #0x10
    // 0x7acbd8: ret
    //     0x7acbd8: ret             
    // 0x7acbdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7acbdc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7acbe0: b               #0x7acaec
    // 0x7acbe4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7acbe4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7acbe8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7acbe8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7acbec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7acbec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _canRequestFocus(/* No info */) {
    // ** addr: 0x7ae418, size: 0xb8
    // 0x7ae418: EnterFrame
    //     0x7ae418: stp             fp, lr, [SP, #-0x10]!
    //     0x7ae41c: mov             fp, SP
    // 0x7ae420: CheckStackOverflow
    //     0x7ae420: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ae424: cmp             SP, x16
    //     0x7ae428: b.ls            #0x7ae4c0
    // 0x7ae42c: ldr             x0, [fp, #0x10]
    // 0x7ae430: LoadField: r1 = r0->field_f
    //     0x7ae430: ldur            w1, [x0, #0xf]
    // 0x7ae434: DecompressPointer r1
    //     0x7ae434: add             x1, x1, HEAP, lsl #32
    // 0x7ae438: cmp             w1, NULL
    // 0x7ae43c: b.eq            #0x7ae4c8
    // 0x7ae440: SaveReg r1
    //     0x7ae440: str             x1, [SP, #-8]!
    // 0x7ae444: r0 = maybeOf()
    //     0x7ae444: bl              #0x5178bc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeOf
    // 0x7ae448: add             SP, SP, #8
    // 0x7ae44c: cmp             w0, NULL
    // 0x7ae450: b.ne            #0x7ae45c
    // 0x7ae454: r1 = Null
    //     0x7ae454: mov             x1, NULL
    // 0x7ae458: b               #0x7ae464
    // 0x7ae45c: r1 = Instance_NavigationMode
    //     0x7ae45c: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c4f0] Obj!NavigationMode@b63ab1
    //     0x7ae460: ldr             x1, [x1, #0x4f0]
    // 0x7ae464: cmp             w1, NULL
    // 0x7ae468: b.ne            #0x7ae474
    // 0x7ae46c: r1 = Instance_NavigationMode
    //     0x7ae46c: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c4f0] Obj!NavigationMode@b63ab1
    //     0x7ae470: ldr             x1, [x1, #0x4f0]
    // 0x7ae474: LoadField: r2 = r1->field_7
    //     0x7ae474: ldur            x2, [x1, #7]
    // 0x7ae478: cmp             x2, #0
    // 0x7ae47c: b.gt            #0x7ae4b0
    // 0x7ae480: ldr             x1, [fp, #0x10]
    // 0x7ae484: LoadField: r2 = r1->field_b
    //     0x7ae484: ldur            w2, [x1, #0xb]
    // 0x7ae488: DecompressPointer r2
    //     0x7ae488: add             x2, x2, HEAP, lsl #32
    // 0x7ae48c: cmp             w2, NULL
    // 0x7ae490: b.eq            #0x7ae4cc
    // 0x7ae494: LoadField: r1 = r2->field_1f
    //     0x7ae494: ldur            w1, [x2, #0x1f]
    // 0x7ae498: DecompressPointer r1
    //     0x7ae498: add             x1, x1, HEAP, lsl #32
    // 0x7ae49c: LoadField: r0 = r1->field_bf
    //     0x7ae49c: ldur            w0, [x1, #0xbf]
    // 0x7ae4a0: DecompressPointer r0
    //     0x7ae4a0: add             x0, x0, HEAP, lsl #32
    // 0x7ae4a4: LeaveFrame
    //     0x7ae4a4: mov             SP, fp
    //     0x7ae4a8: ldp             fp, lr, [SP], #0x10
    // 0x7ae4ac: ret
    //     0x7ae4ac: ret             
    // 0x7ae4b0: r0 = true
    //     0x7ae4b0: add             x0, NULL, #0x20  ; true
    // 0x7ae4b4: LeaveFrame
    //     0x7ae4b4: mov             SP, fp
    //     0x7ae4b8: ldp             fp, lr, [SP], #0x10
    // 0x7ae4bc: ret
    //     0x7ae4bc: ret             
    // 0x7ae4c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ae4c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ae4c4: b               #0x7ae42c
    // 0x7ae4c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ae4c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7ae4cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ae4cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _isEnabled(/* No info */) {
    // ** addr: 0x7ae4d0, size: 0x3c
    // 0x7ae4d0: EnterFrame
    //     0x7ae4d0: stp             fp, lr, [SP, #-0x10]!
    //     0x7ae4d4: mov             fp, SP
    // 0x7ae4d8: ldr             x1, [fp, #0x10]
    // 0x7ae4dc: LoadField: r2 = r1->field_b
    //     0x7ae4dc: ldur            w2, [x1, #0xb]
    // 0x7ae4e0: DecompressPointer r2
    //     0x7ae4e0: add             x2, x2, HEAP, lsl #32
    // 0x7ae4e4: cmp             w2, NULL
    // 0x7ae4e8: b.eq            #0x7ae508
    // 0x7ae4ec: LoadField: r1 = r2->field_1f
    //     0x7ae4ec: ldur            w1, [x2, #0x1f]
    // 0x7ae4f0: DecompressPointer r1
    //     0x7ae4f0: add             x1, x1, HEAP, lsl #32
    // 0x7ae4f4: LoadField: r0 = r1->field_bf
    //     0x7ae4f4: ldur            w0, [x1, #0xbf]
    // 0x7ae4f8: DecompressPointer r0
    //     0x7ae4f8: add             x0, x0, HEAP, lsl #32
    // 0x7ae4fc: LeaveFrame
    //     0x7ae4fc: mov             SP, fp
    //     0x7ae500: ldp             fp, lr, [SP], #0x10
    // 0x7ae504: ret
    //     0x7ae504: ret             
    // 0x7ae508: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ae508: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _effectiveFocusNode(/* No info */) {
    // ** addr: 0x7ae50c, size: 0x9c
    // 0x7ae50c: EnterFrame
    //     0x7ae50c: stp             fp, lr, [SP, #-0x10]!
    //     0x7ae510: mov             fp, SP
    // 0x7ae514: AllocStack(0x8)
    //     0x7ae514: sub             SP, SP, #8
    // 0x7ae518: CheckStackOverflow
    //     0x7ae518: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ae51c: cmp             SP, x16
    //     0x7ae520: b.ls            #0x7ae59c
    // 0x7ae524: ldr             x0, [fp, #0x10]
    // 0x7ae528: LoadField: r1 = r0->field_b
    //     0x7ae528: ldur            w1, [x0, #0xb]
    // 0x7ae52c: DecompressPointer r1
    //     0x7ae52c: add             x1, x1, HEAP, lsl #32
    // 0x7ae530: cmp             w1, NULL
    // 0x7ae534: b.eq            #0x7ae5a4
    // 0x7ae538: LoadField: r1 = r0->field_27
    //     0x7ae538: ldur            w1, [x0, #0x27]
    // 0x7ae53c: DecompressPointer r1
    //     0x7ae53c: add             x1, x1, HEAP, lsl #32
    // 0x7ae540: cmp             w1, NULL
    // 0x7ae544: b.ne            #0x7ae58c
    // 0x7ae548: r0 = FocusNode()
    //     0x7ae548: bl              #0x7ae5a8  ; AllocateFocusNodeStub -> FocusNode (size=0x64)
    // 0x7ae54c: stur            x0, [fp, #-8]
    // 0x7ae550: SaveReg r0
    //     0x7ae550: str             x0, [SP, #-8]!
    // 0x7ae554: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7ae554: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7ae558: r0 = FocusNode()
    //     0x7ae558: bl              #0x5bac08  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::FocusNode
    // 0x7ae55c: add             SP, SP, #8
    // 0x7ae560: ldur            x0, [fp, #-8]
    // 0x7ae564: ldr             x2, [fp, #0x10]
    // 0x7ae568: StoreField: r2->field_27 = r0
    //     0x7ae568: stur            w0, [x2, #0x27]
    //     0x7ae56c: ldurb           w16, [x2, #-1]
    //     0x7ae570: ldurb           w17, [x0, #-1]
    //     0x7ae574: and             x16, x17, x16, lsr #2
    //     0x7ae578: tst             x16, HEAP, lsr #32
    //     0x7ae57c: b.eq            #0x7ae584
    //     0x7ae580: bl              #0xd6828c
    // 0x7ae584: ldur            x0, [fp, #-8]
    // 0x7ae588: b               #0x7ae590
    // 0x7ae58c: mov             x0, x1
    // 0x7ae590: LeaveFrame
    //     0x7ae590: mov             SP, fp
    //     0x7ae594: ldp             fp, lr, [SP], #0x10
    // 0x7ae598: ret
    //     0x7ae598: ret             
    // 0x7ae59c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ae59c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ae5a0: b               #0x7ae524
    // 0x7ae5a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ae5a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x838588, size: 0x1014
    // 0x838588: EnterFrame
    //     0x838588: stp             fp, lr, [SP, #-0x10]!
    //     0x83858c: mov             fp, SP
    // 0x838590: AllocStack(0xf8)
    //     0x838590: sub             SP, SP, #0xf8
    // 0x838594: CheckStackOverflow
    //     0x838594: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x838598: cmp             SP, x16
    //     0x83859c: b.ls            #0x839548
    // 0x8385a0: r1 = 5
    //     0x8385a0: mov             x1, #5
    // 0x8385a4: r0 = AllocateContext()
    //     0x8385a4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8385a8: mov             x1, x0
    // 0x8385ac: ldr             x0, [fp, #0x18]
    // 0x8385b0: stur            x1, [fp, #-8]
    // 0x8385b4: StoreField: r1->field_f = r0
    //     0x8385b4: stur            w0, [x1, #0xf]
    // 0x8385b8: ldr             x16, [fp, #0x10]
    // 0x8385bc: SaveReg r16
    //     0x8385bc: str             x16, [SP, #-8]!
    // 0x8385c0: r0 = of()
    //     0x8385c0: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x8385c4: add             SP, SP, #8
    // 0x8385c8: stur            x0, [fp, #-0x10]
    // 0x8385cc: ldr             x16, [fp, #0x10]
    // 0x8385d0: SaveReg r16
    //     0x8385d0: str             x16, [SP, #-8]!
    // 0x8385d4: r0 = of()
    //     0x8385d4: bl              #0x83d55c  ; [package:flutter/src/material/text_selection_theme.dart] TextSelectionTheme::of
    // 0x8385d8: add             SP, SP, #8
    // 0x8385dc: mov             x1, x0
    // 0x8385e0: ldur            x0, [fp, #-0x10]
    // 0x8385e4: stur            x1, [fp, #-0x18]
    // 0x8385e8: LoadField: r2 = r0->field_93
    //     0x8385e8: ldur            w2, [x0, #0x93]
    // 0x8385ec: DecompressPointer r2
    //     0x8385ec: add             x2, x2, HEAP, lsl #32
    // 0x8385f0: LoadField: r3 = r2->field_23
    //     0x8385f0: ldur            w3, [x2, #0x23]
    // 0x8385f4: DecompressPointer r3
    //     0x8385f4: add             x3, x3, HEAP, lsl #32
    // 0x8385f8: cmp             w3, NULL
    // 0x8385fc: b.eq            #0x839550
    // 0x838600: ldr             x2, [fp, #0x18]
    // 0x838604: LoadField: r4 = r2->field_b
    //     0x838604: ldur            w4, [x2, #0xb]
    // 0x838608: DecompressPointer r4
    //     0x838608: add             x4, x4, HEAP, lsl #32
    // 0x83860c: cmp             w4, NULL
    // 0x838610: b.eq            #0x839554
    // 0x838614: LoadField: r5 = r4->field_2f
    //     0x838614: ldur            w5, [x4, #0x2f]
    // 0x838618: DecompressPointer r5
    //     0x838618: add             x5, x5, HEAP, lsl #32
    // 0x83861c: stp             x5, x3, [SP, #-0x10]!
    // 0x838620: r0 = merge()
    //     0x838620: bl              #0x6cdfe0  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x838624: add             SP, SP, #0x10
    // 0x838628: mov             x1, x0
    // 0x83862c: ldr             x0, [fp, #0x18]
    // 0x838630: stur            x1, [fp, #-0x30]
    // 0x838634: LoadField: r2 = r0->field_b
    //     0x838634: ldur            w2, [x0, #0xb]
    // 0x838638: DecompressPointer r2
    //     0x838638: add             x2, x2, HEAP, lsl #32
    // 0x83863c: cmp             w2, NULL
    // 0x838640: b.eq            #0x839558
    // 0x838644: ldur            x2, [fp, #-0x10]
    // 0x838648: LoadField: r3 = r2->field_3f
    //     0x838648: ldur            w3, [x2, #0x3f]
    // 0x83864c: DecompressPointer r3
    //     0x83864c: add             x3, x3, HEAP, lsl #32
    // 0x838650: stur            x3, [fp, #-0x28]
    // 0x838654: LoadField: r4 = r3->field_7
    //     0x838654: ldur            w4, [x3, #7]
    // 0x838658: DecompressPointer r4
    //     0x838658: add             x4, x4, HEAP, lsl #32
    // 0x83865c: stur            x4, [fp, #-0x20]
    // 0x838660: SaveReg r0
    //     0x838660: str             x0, [SP, #-8]!
    // 0x838664: r0 = pageController()
    //     0x838664: bl              #0x7bf758  ; [package:extended_image/src/gesture/page_view/gesture_page_view.dart] ExtendedImageGesturePageViewState::pageController
    // 0x838668: add             SP, SP, #8
    // 0x83866c: mov             x1, x0
    // 0x838670: ldur            x2, [fp, #-8]
    // 0x838674: stur            x1, [fp, #-0x38]
    // 0x838678: StoreField: r2->field_13 = r0
    //     0x838678: stur            w0, [x2, #0x13]
    //     0x83867c: ldurb           w16, [x2, #-1]
    //     0x838680: ldurb           w17, [x0, #-1]
    //     0x838684: and             x16, x17, x16, lsr #2
    //     0x838688: tst             x16, HEAP, lsr #32
    //     0x83868c: b.eq            #0x838694
    //     0x838690: bl              #0xd6828c
    // 0x838694: ldr             x16, [fp, #0x18]
    // 0x838698: SaveReg r16
    //     0x838698: str             x16, [SP, #-8]!
    // 0x83869c: r0 = _effectiveFocusNode()
    //     0x83869c: bl              #0x7ae50c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveFocusNode
    // 0x8386a0: add             SP, SP, #8
    // 0x8386a4: mov             x1, x0
    // 0x8386a8: ldur            x2, [fp, #-8]
    // 0x8386ac: stur            x1, [fp, #-0x40]
    // 0x8386b0: StoreField: r2->field_17 = r0
    //     0x8386b0: stur            w0, [x2, #0x17]
    //     0x8386b4: ldurb           w16, [x2, #-1]
    //     0x8386b8: ldurb           w17, [x0, #-1]
    //     0x8386bc: and             x16, x17, x16, lsr #2
    //     0x8386c0: tst             x16, HEAP, lsr #32
    //     0x8386c4: b.eq            #0x8386cc
    //     0x8386c8: bl              #0xd6828c
    // 0x8386cc: r16 = <TextInputFormatter>
    //     0x8386cc: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dc78] TypeArguments: <TextInputFormatter>
    //     0x8386d0: ldr             x16, [x16, #0xc78]
    // 0x8386d4: stp             xzr, x16, [SP, #-0x10]!
    // 0x8386d8: r0 = _GrowableList()
    //     0x8386d8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x8386dc: add             SP, SP, #0x10
    // 0x8386e0: mov             x1, x0
    // 0x8386e4: ldr             x0, [fp, #0x18]
    // 0x8386e8: stur            x1, [fp, #-0x50]
    // 0x8386ec: LoadField: r2 = r0->field_b
    //     0x8386ec: ldur            w2, [x0, #0xb]
    // 0x8386f0: DecompressPointer r2
    //     0x8386f0: add             x2, x2, HEAP, lsl #32
    // 0x8386f4: cmp             w2, NULL
    // 0x8386f8: b.eq            #0x83955c
    // 0x8386fc: LoadField: r3 = r2->field_77
    //     0x8386fc: ldur            w3, [x2, #0x77]
    // 0x838700: DecompressPointer r3
    //     0x838700: add             x3, x3, HEAP, lsl #32
    // 0x838704: stur            x3, [fp, #-0x48]
    // 0x838708: cmp             w3, NULL
    // 0x83870c: b.eq            #0x8387cc
    // 0x838710: SaveReg r0
    //     0x838710: str             x0, [SP, #-8]!
    // 0x838714: r0 = _effectiveMaxLengthEnforcement()
    //     0x838714: bl              #0x83d4b8  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveMaxLengthEnforcement
    // 0x838718: add             SP, SP, #8
    // 0x83871c: stur            x0, [fp, #-0x58]
    // 0x838720: r0 = LengthLimitingTextInputFormatter()
    //     0x838720: bl              #0x83d4ac  ; AllocateLengthLimitingTextInputFormatterStub -> LengthLimitingTextInputFormatter (size=0x10)
    // 0x838724: mov             x1, x0
    // 0x838728: ldur            x0, [fp, #-0x48]
    // 0x83872c: stur            x1, [fp, #-0x60]
    // 0x838730: StoreField: r1->field_7 = r0
    //     0x838730: stur            w0, [x1, #7]
    // 0x838734: ldur            x0, [fp, #-0x58]
    // 0x838738: StoreField: r1->field_b = r0
    //     0x838738: stur            w0, [x1, #0xb]
    // 0x83873c: ldur            x0, [fp, #-0x50]
    // 0x838740: LoadField: r2 = r0->field_b
    //     0x838740: ldur            w2, [x0, #0xb]
    // 0x838744: DecompressPointer r2
    //     0x838744: add             x2, x2, HEAP, lsl #32
    // 0x838748: stur            x2, [fp, #-0x48]
    // 0x83874c: LoadField: r3 = r0->field_f
    //     0x83874c: ldur            w3, [x0, #0xf]
    // 0x838750: DecompressPointer r3
    //     0x838750: add             x3, x3, HEAP, lsl #32
    // 0x838754: LoadField: r4 = r3->field_b
    //     0x838754: ldur            w4, [x3, #0xb]
    // 0x838758: DecompressPointer r4
    //     0x838758: add             x4, x4, HEAP, lsl #32
    // 0x83875c: cmp             w2, w4
    // 0x838760: b.ne            #0x838770
    // 0x838764: SaveReg r0
    //     0x838764: str             x0, [SP, #-8]!
    // 0x838768: r0 = _growToNextCapacity()
    //     0x838768: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x83876c: add             SP, SP, #8
    // 0x838770: ldur            x2, [fp, #-0x50]
    // 0x838774: ldur            x0, [fp, #-0x48]
    // 0x838778: r3 = LoadInt32Instr(r0)
    //     0x838778: sbfx            x3, x0, #1, #0x1f
    // 0x83877c: add             x0, x3, #1
    // 0x838780: lsl             x1, x0, #1
    // 0x838784: StoreField: r2->field_b = r1
    //     0x838784: stur            w1, [x2, #0xb]
    // 0x838788: mov             x1, x3
    // 0x83878c: cmp             x1, x0
    // 0x838790: b.hs            #0x839560
    // 0x838794: LoadField: r1 = r2->field_f
    //     0x838794: ldur            w1, [x2, #0xf]
    // 0x838798: DecompressPointer r1
    //     0x838798: add             x1, x1, HEAP, lsl #32
    // 0x83879c: ldur            x0, [fp, #-0x60]
    // 0x8387a0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8387a0: add             x25, x1, x3, lsl #2
    //     0x8387a4: add             x25, x25, #0xf
    //     0x8387a8: str             w0, [x25]
    //     0x8387ac: tbz             w0, #0, #0x8387c8
    //     0x8387b0: ldurb           w16, [x1, #-1]
    //     0x8387b4: ldurb           w17, [x0, #-1]
    //     0x8387b8: and             x16, x17, x16, lsr #2
    //     0x8387bc: tst             x16, HEAP, lsr #32
    //     0x8387c0: b.eq            #0x8387c8
    //     0x8387c4: bl              #0xd67e5c
    // 0x8387c8: b               #0x8387d0
    // 0x8387cc: mov             x2, x1
    // 0x8387d0: ldr             x0, [fp, #0x18]
    // 0x8387d4: ldur            x1, [fp, #-8]
    // 0x8387d8: ldur            x3, [fp, #-0x10]
    // 0x8387dc: LoadField: r4 = r0->field_b
    //     0x8387dc: ldur            w4, [x0, #0xb]
    // 0x8387e0: DecompressPointer r4
    //     0x8387e0: add             x4, x4, HEAP, lsl #32
    // 0x8387e4: cmp             w4, NULL
    // 0x8387e8: b.eq            #0x839564
    // 0x8387ec: StoreField: r1->field_1b = rNULL
    //     0x8387ec: stur            NULL, [x1, #0x1b]
    // 0x8387f0: LoadField: r4 = r3->field_1f
    //     0x8387f0: ldur            w4, [x3, #0x1f]
    // 0x8387f4: DecompressPointer r4
    //     0x8387f4: add             x4, x4, HEAP, lsl #32
    // 0x8387f8: LoadField: r3 = r4->field_7
    //     0x8387f8: ldur            x3, [x4, #7]
    // 0x8387fc: cmp             x3, #2
    // 0x838800: b.gt            #0x838af4
    // 0x838804: cmp             x3, #1
    // 0x838808: b.gt            #0x8388e0
    // 0x83880c: ldur            x3, [fp, #-0x18]
    // 0x838810: r4 = false
    //     0x838810: add             x4, NULL, #0x30  ; false
    // 0x838814: StoreField: r0->field_37 = r4
    //     0x838814: stur            w4, [x0, #0x37]
    // 0x838818: r0 = InitLateStaticField(0xe38) // [package:flutter/src/material/text_selection.dart] ::materialTextSelectionControls
    //     0x838818: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x83881c: ldr             x0, [x0, #0x1c70]
    //     0x838820: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x838824: cmp             w0, w16
    //     0x838828: b.ne            #0x838838
    //     0x83882c: add             x2, PP, #0x4b, lsl #12  ; [pp+0x4bcb0] Field <::.materialTextSelectionControls>: static late final (offset: 0xe38)
    //     0x838830: ldr             x2, [x2, #0xcb0]
    //     0x838834: bl              #0xd67cdc
    // 0x838838: mov             x1, x0
    // 0x83883c: ldr             x0, [fp, #0x18]
    // 0x838840: stur            x1, [fp, #-0x48]
    // 0x838844: LoadField: r2 = r0->field_b
    //     0x838844: ldur            w2, [x0, #0xb]
    // 0x838848: DecompressPointer r2
    //     0x838848: add             x2, x2, HEAP, lsl #32
    // 0x83884c: cmp             w2, NULL
    // 0x838850: b.eq            #0x839568
    // 0x838854: ldur            x2, [fp, #-0x18]
    // 0x838858: LoadField: r3 = r2->field_7
    //     0x838858: ldur            w3, [x2, #7]
    // 0x83885c: DecompressPointer r3
    //     0x83885c: add             x3, x3, HEAP, lsl #32
    // 0x838860: cmp             w3, NULL
    // 0x838864: b.ne            #0x838878
    // 0x838868: ldur            x5, [fp, #-0x28]
    // 0x83886c: LoadField: r3 = r5->field_b
    //     0x83886c: ldur            w3, [x5, #0xb]
    // 0x838870: DecompressPointer r3
    //     0x838870: add             x3, x3, HEAP, lsl #32
    // 0x838874: b               #0x83887c
    // 0x838878: ldur            x5, [fp, #-0x28]
    // 0x83887c: stur            x3, [fp, #-0x10]
    // 0x838880: LoadField: r4 = r2->field_b
    //     0x838880: ldur            w4, [x2, #0xb]
    // 0x838884: DecompressPointer r4
    //     0x838884: add             x4, x4, HEAP, lsl #32
    // 0x838888: cmp             w4, NULL
    // 0x83888c: b.ne            #0x8388b4
    // 0x838890: d0 = 0.400000
    //     0x838890: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d148] IMM: double(0.4) from 0x3fd999999999999a
    //     0x838894: ldr             d0, [x17, #0x148]
    // 0x838898: LoadField: r2 = r5->field_b
    //     0x838898: ldur            w2, [x5, #0xb]
    // 0x83889c: DecompressPointer r2
    //     0x83889c: add             x2, x2, HEAP, lsl #32
    // 0x8388a0: SaveReg r2
    //     0x8388a0: str             x2, [SP, #-8]!
    // 0x8388a4: SaveReg d0
    //     0x8388a4: str             d0, [SP, #-8]!
    // 0x8388a8: r0 = withOpacity()
    //     0x8388a8: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x8388ac: add             SP, SP, #0x10
    // 0x8388b0: b               #0x8388b8
    // 0x8388b4: mov             x0, x4
    // 0x8388b8: ldur            x9, [fp, #-0x48]
    // 0x8388bc: ldur            x5, [fp, #-0x10]
    // 0x8388c0: mov             x4, x0
    // 0x8388c4: ldur            x2, [fp, #-8]
    // 0x8388c8: r8 = false
    //     0x8388c8: add             x8, NULL, #0x30  ; false
    // 0x8388cc: r7 = false
    //     0x8388cc: add             x7, NULL, #0x30  ; false
    // 0x8388d0: r6 = Null
    //     0x8388d0: mov             x6, NULL
    // 0x8388d4: r3 = Null
    //     0x8388d4: mov             x3, NULL
    // 0x8388d8: r1 = Null
    //     0x8388d8: mov             x1, NULL
    // 0x8388dc: b               #0x838f44
    // 0x8388e0: ldur            x2, [fp, #-0x18]
    // 0x8388e4: d0 = 0.400000
    //     0x8388e4: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d148] IMM: double(0.4) from 0x3fd999999999999a
    //     0x8388e8: ldr             d0, [x17, #0x148]
    // 0x8388ec: ldr             x16, [fp, #0x10]
    // 0x8388f0: SaveReg r16
    //     0x8388f0: str             x16, [SP, #-8]!
    // 0x8388f4: r0 = of()
    //     0x8388f4: bl              #0x83d26c  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::of
    // 0x8388f8: add             SP, SP, #8
    // 0x8388fc: mov             x2, x0
    // 0x838900: ldr             x0, [fp, #0x18]
    // 0x838904: r1 = true
    //     0x838904: add             x1, NULL, #0x20  ; true
    // 0x838908: stur            x2, [fp, #-0x10]
    // 0x83890c: StoreField: r0->field_37 = r1
    //     0x83890c: stur            w1, [x0, #0x37]
    // 0x838910: r0 = InitLateStaticField(0xce8) // [package:flutter/src/cupertino/text_selection.dart] ::cupertinoTextSelectionControls
    //     0x838910: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x838914: ldr             x0, [x0, #0x19d0]
    //     0x838918: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x83891c: cmp             w0, w16
    //     0x838920: b.ne            #0x838930
    //     0x838924: add             x2, PP, #0x4b, lsl #12  ; [pp+0x4bcb8] Field <::.cupertinoTextSelectionControls>: static late final (offset: 0xce8)
    //     0x838928: ldr             x2, [x2, #0xcb8]
    //     0x83892c: bl              #0xd67cdc
    // 0x838930: mov             x1, x0
    // 0x838934: ldr             x0, [fp, #0x18]
    // 0x838938: stur            x1, [fp, #-0x58]
    // 0x83893c: LoadField: r2 = r0->field_b
    //     0x83893c: ldur            w2, [x0, #0xb]
    // 0x838940: DecompressPointer r2
    //     0x838940: add             x2, x2, HEAP, lsl #32
    // 0x838944: cmp             w2, NULL
    // 0x838948: b.eq            #0x83956c
    // 0x83894c: ldur            x2, [fp, #-0x18]
    // 0x838950: LoadField: r3 = r2->field_7
    //     0x838950: ldur            w3, [x2, #7]
    // 0x838954: DecompressPointer r3
    //     0x838954: add             x3, x3, HEAP, lsl #32
    // 0x838958: cmp             w3, NULL
    // 0x83895c: b.ne            #0x8389e0
    // 0x838960: ldur            x4, [fp, #-0x10]
    // 0x838964: r3 = LoadClassIdInstr(r4)
    //     0x838964: ldur            x3, [x4, #-1]
    //     0x838968: ubfx            x3, x3, #0xc, #0x14
    // 0x83896c: lsl             x3, x3, #1
    // 0x838970: r17 = 5322
    //     0x838970: mov             x17, #0x14ca
    // 0x838974: cmp             w3, w17
    // 0x838978: b.ne            #0x8389a4
    // 0x83897c: LoadField: r3 = r4->field_b
    //     0x83897c: ldur            w3, [x4, #0xb]
    // 0x838980: DecompressPointer r3
    //     0x838980: add             x3, x3, HEAP, lsl #32
    // 0x838984: cmp             w3, NULL
    // 0x838988: b.ne            #0x8389e4
    // 0x83898c: LoadField: r3 = r4->field_1f
    //     0x83898c: ldur            w3, [x4, #0x1f]
    // 0x838990: DecompressPointer r3
    //     0x838990: add             x3, x3, HEAP, lsl #32
    // 0x838994: LoadField: r5 = r3->field_b
    //     0x838994: ldur            w5, [x3, #0xb]
    // 0x838998: DecompressPointer r5
    //     0x838998: add             x5, x5, HEAP, lsl #32
    // 0x83899c: mov             x3, x5
    // 0x8389a0: b               #0x8389e4
    // 0x8389a4: LoadField: r3 = r4->field_27
    //     0x8389a4: ldur            w3, [x4, #0x27]
    // 0x8389a8: DecompressPointer r3
    //     0x8389a8: add             x3, x3, HEAP, lsl #32
    // 0x8389ac: LoadField: r5 = r3->field_b
    //     0x8389ac: ldur            w5, [x3, #0xb]
    // 0x8389b0: DecompressPointer r5
    //     0x8389b0: add             x5, x5, HEAP, lsl #32
    // 0x8389b4: cmp             w5, NULL
    // 0x8389b8: b.ne            #0x8389d8
    // 0x8389bc: LoadField: r3 = r4->field_23
    //     0x8389bc: ldur            w3, [x4, #0x23]
    // 0x8389c0: DecompressPointer r3
    //     0x8389c0: add             x3, x3, HEAP, lsl #32
    // 0x8389c4: LoadField: r5 = r3->field_3f
    //     0x8389c4: ldur            w5, [x3, #0x3f]
    // 0x8389c8: DecompressPointer r5
    //     0x8389c8: add             x5, x5, HEAP, lsl #32
    // 0x8389cc: LoadField: r3 = r5->field_b
    //     0x8389cc: ldur            w3, [x5, #0xb]
    // 0x8389d0: DecompressPointer r3
    //     0x8389d0: add             x3, x3, HEAP, lsl #32
    // 0x8389d4: b               #0x8389e4
    // 0x8389d8: mov             x3, x5
    // 0x8389dc: b               #0x8389e4
    // 0x8389e0: ldur            x4, [fp, #-0x10]
    // 0x8389e4: stur            x3, [fp, #-0x48]
    // 0x8389e8: LoadField: r5 = r2->field_b
    //     0x8389e8: ldur            w5, [x2, #0xb]
    // 0x8389ec: DecompressPointer r5
    //     0x8389ec: add             x5, x5, HEAP, lsl #32
    // 0x8389f0: cmp             w5, NULL
    // 0x8389f4: b.ne            #0x838a8c
    // 0x8389f8: r2 = LoadClassIdInstr(r4)
    //     0x8389f8: ldur            x2, [x4, #-1]
    //     0x8389fc: ubfx            x2, x2, #0xc, #0x14
    // 0x838a00: lsl             x2, x2, #1
    // 0x838a04: r17 = 5322
    //     0x838a04: mov             x17, #0x14ca
    // 0x838a08: cmp             w2, w17
    // 0x838a0c: b.ne            #0x838a38
    // 0x838a10: LoadField: r2 = r4->field_b
    //     0x838a10: ldur            w2, [x4, #0xb]
    // 0x838a14: DecompressPointer r2
    //     0x838a14: add             x2, x2, HEAP, lsl #32
    // 0x838a18: cmp             w2, NULL
    // 0x838a1c: b.ne            #0x838a70
    // 0x838a20: LoadField: r2 = r4->field_1f
    //     0x838a20: ldur            w2, [x4, #0x1f]
    // 0x838a24: DecompressPointer r2
    //     0x838a24: add             x2, x2, HEAP, lsl #32
    // 0x838a28: LoadField: r4 = r2->field_b
    //     0x838a28: ldur            w4, [x2, #0xb]
    // 0x838a2c: DecompressPointer r4
    //     0x838a2c: add             x4, x4, HEAP, lsl #32
    // 0x838a30: mov             x2, x4
    // 0x838a34: b               #0x838a70
    // 0x838a38: LoadField: r2 = r4->field_27
    //     0x838a38: ldur            w2, [x4, #0x27]
    // 0x838a3c: DecompressPointer r2
    //     0x838a3c: add             x2, x2, HEAP, lsl #32
    // 0x838a40: LoadField: r5 = r2->field_b
    //     0x838a40: ldur            w5, [x2, #0xb]
    // 0x838a44: DecompressPointer r5
    //     0x838a44: add             x5, x5, HEAP, lsl #32
    // 0x838a48: cmp             w5, NULL
    // 0x838a4c: b.ne            #0x838a6c
    // 0x838a50: LoadField: r2 = r4->field_23
    //     0x838a50: ldur            w2, [x4, #0x23]
    // 0x838a54: DecompressPointer r2
    //     0x838a54: add             x2, x2, HEAP, lsl #32
    // 0x838a58: LoadField: r4 = r2->field_3f
    //     0x838a58: ldur            w4, [x2, #0x3f]
    // 0x838a5c: DecompressPointer r4
    //     0x838a5c: add             x4, x4, HEAP, lsl #32
    // 0x838a60: LoadField: r2 = r4->field_b
    //     0x838a60: ldur            w2, [x4, #0xb]
    // 0x838a64: DecompressPointer r2
    //     0x838a64: add             x2, x2, HEAP, lsl #32
    // 0x838a68: b               #0x838a70
    // 0x838a6c: mov             x2, x5
    // 0x838a70: d0 = 0.400000
    //     0x838a70: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d148] IMM: double(0.4) from 0x3fd999999999999a
    //     0x838a74: ldr             d0, [x17, #0x148]
    // 0x838a78: SaveReg r2
    //     0x838a78: str             x2, [SP, #-8]!
    // 0x838a7c: SaveReg d0
    //     0x838a7c: str             d0, [SP, #-8]!
    // 0x838a80: r0 = withOpacity()
    //     0x838a80: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x838a84: add             SP, SP, #0x10
    // 0x838a88: b               #0x838a90
    // 0x838a8c: mov             x0, x5
    // 0x838a90: stur            x0, [fp, #-0x10]
    // 0x838a94: ldr             x16, [fp, #0x10]
    // 0x838a98: SaveReg r16
    //     0x838a98: str             x16, [SP, #-8]!
    // 0x838a9c: r0 = of()
    //     0x838a9c: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x838aa0: add             SP, SP, #8
    // 0x838aa4: LoadField: d0 = r0->field_b
    //     0x838aa4: ldur            d0, [x0, #0xb]
    // 0x838aa8: d1 = -2.000000
    //     0x838aa8: fmov            d1, #-2.00000000
    // 0x838aac: fdiv            d2, d1, d0
    // 0x838ab0: stur            d2, [fp, #-0xf8]
    // 0x838ab4: r0 = Offset()
    //     0x838ab4: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x838ab8: ldur            d0, [fp, #-0xf8]
    // 0x838abc: StoreField: r0->field_7 = d0
    //     0x838abc: stur            d0, [x0, #7]
    // 0x838ac0: d2 = 0.000000
    //     0x838ac0: eor             v2.16b, v2.16b, v2.16b
    // 0x838ac4: StoreField: r0->field_f = d2
    //     0x838ac4: stur            d2, [x0, #0xf]
    // 0x838ac8: ldur            x9, [fp, #-0x58]
    // 0x838acc: mov             x6, x0
    // 0x838ad0: ldur            x5, [fp, #-0x48]
    // 0x838ad4: ldur            x4, [fp, #-0x10]
    // 0x838ad8: ldur            x3, [fp, #-0x10]
    // 0x838adc: ldur            x2, [fp, #-8]
    // 0x838ae0: r8 = true
    //     0x838ae0: add             x8, NULL, #0x20  ; true
    // 0x838ae4: r7 = true
    //     0x838ae4: add             x7, NULL, #0x20  ; true
    // 0x838ae8: r1 = Instance_Radius
    //     0x838ae8: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dc90] Obj!Radius@b5e8a1
    //     0x838aec: ldr             x1, [x1, #0xc90]
    // 0x838af0: b               #0x838f44
    // 0x838af4: ldur            x2, [fp, #-0x18]
    // 0x838af8: ldur            x5, [fp, #-0x28]
    // 0x838afc: r4 = false
    //     0x838afc: add             x4, NULL, #0x30  ; false
    // 0x838b00: d1 = -2.000000
    //     0x838b00: fmov            d1, #-2.00000000
    // 0x838b04: d0 = 0.400000
    //     0x838b04: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d148] IMM: double(0.4) from 0x3fd999999999999a
    //     0x838b08: ldr             d0, [x17, #0x148]
    // 0x838b0c: d2 = 0.000000
    //     0x838b0c: eor             v2.16b, v2.16b, v2.16b
    // 0x838b10: cmp             x3, #4
    // 0x838b14: b.gt            #0x838e34
    // 0x838b18: cmp             x3, #3
    // 0x838b1c: b.gt            #0x838bf0
    // 0x838b20: ldr             x0, [fp, #0x18]
    // 0x838b24: StoreField: r0->field_37 = r4
    //     0x838b24: stur            w4, [x0, #0x37]
    // 0x838b28: r0 = InitLateStaticField(0xd78) // [package:flutter/src/material/desktop_text_selection.dart] ::desktopTextSelectionControls
    //     0x838b28: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x838b2c: ldr             x0, [x0, #0x1af0]
    //     0x838b30: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x838b34: cmp             w0, w16
    //     0x838b38: b.ne            #0x838b48
    //     0x838b3c: add             x2, PP, #0x4b, lsl #12  ; [pp+0x4bcc0] Field <::.desktopTextSelectionControls>: static late final (offset: 0xd78)
    //     0x838b40: ldr             x2, [x2, #0xcc0]
    //     0x838b44: bl              #0xd67cdc
    // 0x838b48: mov             x1, x0
    // 0x838b4c: ldr             x0, [fp, #0x18]
    // 0x838b50: stur            x1, [fp, #-0x48]
    // 0x838b54: LoadField: r2 = r0->field_b
    //     0x838b54: ldur            w2, [x0, #0xb]
    // 0x838b58: DecompressPointer r2
    //     0x838b58: add             x2, x2, HEAP, lsl #32
    // 0x838b5c: cmp             w2, NULL
    // 0x838b60: b.eq            #0x839570
    // 0x838b64: ldur            x2, [fp, #-0x18]
    // 0x838b68: LoadField: r3 = r2->field_7
    //     0x838b68: ldur            w3, [x2, #7]
    // 0x838b6c: DecompressPointer r3
    //     0x838b6c: add             x3, x3, HEAP, lsl #32
    // 0x838b70: cmp             w3, NULL
    // 0x838b74: b.ne            #0x838b88
    // 0x838b78: ldur            x4, [fp, #-0x28]
    // 0x838b7c: LoadField: r3 = r4->field_b
    //     0x838b7c: ldur            w3, [x4, #0xb]
    // 0x838b80: DecompressPointer r3
    //     0x838b80: add             x3, x3, HEAP, lsl #32
    // 0x838b84: b               #0x838b8c
    // 0x838b88: ldur            x4, [fp, #-0x28]
    // 0x838b8c: stur            x3, [fp, #-0x10]
    // 0x838b90: LoadField: r5 = r2->field_b
    //     0x838b90: ldur            w5, [x2, #0xb]
    // 0x838b94: DecompressPointer r5
    //     0x838b94: add             x5, x5, HEAP, lsl #32
    // 0x838b98: cmp             w5, NULL
    // 0x838b9c: b.ne            #0x838bc4
    // 0x838ba0: d0 = 0.400000
    //     0x838ba0: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d148] IMM: double(0.4) from 0x3fd999999999999a
    //     0x838ba4: ldr             d0, [x17, #0x148]
    // 0x838ba8: LoadField: r2 = r4->field_b
    //     0x838ba8: ldur            w2, [x4, #0xb]
    // 0x838bac: DecompressPointer r2
    //     0x838bac: add             x2, x2, HEAP, lsl #32
    // 0x838bb0: SaveReg r2
    //     0x838bb0: str             x2, [SP, #-8]!
    // 0x838bb4: SaveReg d0
    //     0x838bb4: str             d0, [SP, #-8]!
    // 0x838bb8: r0 = withOpacity()
    //     0x838bb8: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x838bbc: add             SP, SP, #0x10
    // 0x838bc0: b               #0x838bc8
    // 0x838bc4: mov             x0, x5
    // 0x838bc8: ldur            x9, [fp, #-0x48]
    // 0x838bcc: ldur            x5, [fp, #-0x10]
    // 0x838bd0: mov             x4, x0
    // 0x838bd4: ldur            x2, [fp, #-8]
    // 0x838bd8: r8 = false
    //     0x838bd8: add             x8, NULL, #0x30  ; false
    // 0x838bdc: r7 = false
    //     0x838bdc: add             x7, NULL, #0x30  ; false
    // 0x838be0: r6 = Null
    //     0x838be0: mov             x6, NULL
    // 0x838be4: r3 = Null
    //     0x838be4: mov             x3, NULL
    // 0x838be8: r1 = Null
    //     0x838be8: mov             x1, NULL
    // 0x838bec: b               #0x838f44
    // 0x838bf0: ldr             x0, [fp, #0x18]
    // 0x838bf4: ldr             x16, [fp, #0x10]
    // 0x838bf8: SaveReg r16
    //     0x838bf8: str             x16, [SP, #-8]!
    // 0x838bfc: r0 = of()
    //     0x838bfc: bl              #0x83d26c  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::of
    // 0x838c00: add             SP, SP, #8
    // 0x838c04: mov             x2, x0
    // 0x838c08: ldr             x1, [fp, #0x18]
    // 0x838c0c: r0 = false
    //     0x838c0c: add             x0, NULL, #0x30  ; false
    // 0x838c10: stur            x2, [fp, #-0x10]
    // 0x838c14: StoreField: r1->field_37 = r0
    //     0x838c14: stur            w0, [x1, #0x37]
    // 0x838c18: r0 = InitLateStaticField(0xccc) // [package:flutter/src/cupertino/desktop_text_selection.dart] ::cupertinoDesktopTextSelectionControls
    //     0x838c18: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x838c1c: ldr             x0, [x0, #0x1998]
    //     0x838c20: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x838c24: cmp             w0, w16
    //     0x838c28: b.ne            #0x838c38
    //     0x838c2c: add             x2, PP, #0x4b, lsl #12  ; [pp+0x4bcc8] Field <::.cupertinoDesktopTextSelectionControls>: static late final (offset: 0xccc)
    //     0x838c30: ldr             x2, [x2, #0xcc8]
    //     0x838c34: bl              #0xd67cdc
    // 0x838c38: mov             x1, x0
    // 0x838c3c: ldr             x0, [fp, #0x18]
    // 0x838c40: stur            x1, [fp, #-0x58]
    // 0x838c44: LoadField: r2 = r0->field_b
    //     0x838c44: ldur            w2, [x0, #0xb]
    // 0x838c48: DecompressPointer r2
    //     0x838c48: add             x2, x2, HEAP, lsl #32
    // 0x838c4c: cmp             w2, NULL
    // 0x838c50: b.eq            #0x839574
    // 0x838c54: ldur            x2, [fp, #-0x18]
    // 0x838c58: LoadField: r3 = r2->field_7
    //     0x838c58: ldur            w3, [x2, #7]
    // 0x838c5c: DecompressPointer r3
    //     0x838c5c: add             x3, x3, HEAP, lsl #32
    // 0x838c60: cmp             w3, NULL
    // 0x838c64: b.ne            #0x838ce8
    // 0x838c68: ldur            x4, [fp, #-0x10]
    // 0x838c6c: r3 = LoadClassIdInstr(r4)
    //     0x838c6c: ldur            x3, [x4, #-1]
    //     0x838c70: ubfx            x3, x3, #0xc, #0x14
    // 0x838c74: lsl             x3, x3, #1
    // 0x838c78: r17 = 5322
    //     0x838c78: mov             x17, #0x14ca
    // 0x838c7c: cmp             w3, w17
    // 0x838c80: b.ne            #0x838cac
    // 0x838c84: LoadField: r3 = r4->field_b
    //     0x838c84: ldur            w3, [x4, #0xb]
    // 0x838c88: DecompressPointer r3
    //     0x838c88: add             x3, x3, HEAP, lsl #32
    // 0x838c8c: cmp             w3, NULL
    // 0x838c90: b.ne            #0x838cec
    // 0x838c94: LoadField: r3 = r4->field_1f
    //     0x838c94: ldur            w3, [x4, #0x1f]
    // 0x838c98: DecompressPointer r3
    //     0x838c98: add             x3, x3, HEAP, lsl #32
    // 0x838c9c: LoadField: r5 = r3->field_b
    //     0x838c9c: ldur            w5, [x3, #0xb]
    // 0x838ca0: DecompressPointer r5
    //     0x838ca0: add             x5, x5, HEAP, lsl #32
    // 0x838ca4: mov             x3, x5
    // 0x838ca8: b               #0x838cec
    // 0x838cac: LoadField: r3 = r4->field_27
    //     0x838cac: ldur            w3, [x4, #0x27]
    // 0x838cb0: DecompressPointer r3
    //     0x838cb0: add             x3, x3, HEAP, lsl #32
    // 0x838cb4: LoadField: r5 = r3->field_b
    //     0x838cb4: ldur            w5, [x3, #0xb]
    // 0x838cb8: DecompressPointer r5
    //     0x838cb8: add             x5, x5, HEAP, lsl #32
    // 0x838cbc: cmp             w5, NULL
    // 0x838cc0: b.ne            #0x838ce0
    // 0x838cc4: LoadField: r3 = r4->field_23
    //     0x838cc4: ldur            w3, [x4, #0x23]
    // 0x838cc8: DecompressPointer r3
    //     0x838cc8: add             x3, x3, HEAP, lsl #32
    // 0x838ccc: LoadField: r5 = r3->field_3f
    //     0x838ccc: ldur            w5, [x3, #0x3f]
    // 0x838cd0: DecompressPointer r5
    //     0x838cd0: add             x5, x5, HEAP, lsl #32
    // 0x838cd4: LoadField: r3 = r5->field_b
    //     0x838cd4: ldur            w3, [x5, #0xb]
    // 0x838cd8: DecompressPointer r3
    //     0x838cd8: add             x3, x3, HEAP, lsl #32
    // 0x838cdc: b               #0x838cec
    // 0x838ce0: mov             x3, x5
    // 0x838ce4: b               #0x838cec
    // 0x838ce8: ldur            x4, [fp, #-0x10]
    // 0x838cec: stur            x3, [fp, #-0x48]
    // 0x838cf0: LoadField: r5 = r2->field_b
    //     0x838cf0: ldur            w5, [x2, #0xb]
    // 0x838cf4: DecompressPointer r5
    //     0x838cf4: add             x5, x5, HEAP, lsl #32
    // 0x838cf8: cmp             w5, NULL
    // 0x838cfc: b.ne            #0x838d94
    // 0x838d00: r2 = LoadClassIdInstr(r4)
    //     0x838d00: ldur            x2, [x4, #-1]
    //     0x838d04: ubfx            x2, x2, #0xc, #0x14
    // 0x838d08: lsl             x2, x2, #1
    // 0x838d0c: r17 = 5322
    //     0x838d0c: mov             x17, #0x14ca
    // 0x838d10: cmp             w2, w17
    // 0x838d14: b.ne            #0x838d40
    // 0x838d18: LoadField: r2 = r4->field_b
    //     0x838d18: ldur            w2, [x4, #0xb]
    // 0x838d1c: DecompressPointer r2
    //     0x838d1c: add             x2, x2, HEAP, lsl #32
    // 0x838d20: cmp             w2, NULL
    // 0x838d24: b.ne            #0x838d78
    // 0x838d28: LoadField: r2 = r4->field_1f
    //     0x838d28: ldur            w2, [x4, #0x1f]
    // 0x838d2c: DecompressPointer r2
    //     0x838d2c: add             x2, x2, HEAP, lsl #32
    // 0x838d30: LoadField: r4 = r2->field_b
    //     0x838d30: ldur            w4, [x2, #0xb]
    // 0x838d34: DecompressPointer r4
    //     0x838d34: add             x4, x4, HEAP, lsl #32
    // 0x838d38: mov             x2, x4
    // 0x838d3c: b               #0x838d78
    // 0x838d40: LoadField: r2 = r4->field_27
    //     0x838d40: ldur            w2, [x4, #0x27]
    // 0x838d44: DecompressPointer r2
    //     0x838d44: add             x2, x2, HEAP, lsl #32
    // 0x838d48: LoadField: r5 = r2->field_b
    //     0x838d48: ldur            w5, [x2, #0xb]
    // 0x838d4c: DecompressPointer r5
    //     0x838d4c: add             x5, x5, HEAP, lsl #32
    // 0x838d50: cmp             w5, NULL
    // 0x838d54: b.ne            #0x838d74
    // 0x838d58: LoadField: r2 = r4->field_23
    //     0x838d58: ldur            w2, [x4, #0x23]
    // 0x838d5c: DecompressPointer r2
    //     0x838d5c: add             x2, x2, HEAP, lsl #32
    // 0x838d60: LoadField: r4 = r2->field_3f
    //     0x838d60: ldur            w4, [x2, #0x3f]
    // 0x838d64: DecompressPointer r4
    //     0x838d64: add             x4, x4, HEAP, lsl #32
    // 0x838d68: LoadField: r2 = r4->field_b
    //     0x838d68: ldur            w2, [x4, #0xb]
    // 0x838d6c: DecompressPointer r2
    //     0x838d6c: add             x2, x2, HEAP, lsl #32
    // 0x838d70: b               #0x838d78
    // 0x838d74: mov             x2, x5
    // 0x838d78: d0 = 0.400000
    //     0x838d78: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d148] IMM: double(0.4) from 0x3fd999999999999a
    //     0x838d7c: ldr             d0, [x17, #0x148]
    // 0x838d80: SaveReg r2
    //     0x838d80: str             x2, [SP, #-8]!
    // 0x838d84: SaveReg d0
    //     0x838d84: str             d0, [SP, #-8]!
    // 0x838d88: r0 = withOpacity()
    //     0x838d88: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x838d8c: add             SP, SP, #0x10
    // 0x838d90: b               #0x838d98
    // 0x838d94: mov             x0, x5
    // 0x838d98: ldur            x2, [fp, #-8]
    // 0x838d9c: stur            x0, [fp, #-0x10]
    // 0x838da0: ldr             x16, [fp, #0x10]
    // 0x838da4: SaveReg r16
    //     0x838da4: str             x16, [SP, #-8]!
    // 0x838da8: r0 = of()
    //     0x838da8: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x838dac: add             SP, SP, #8
    // 0x838db0: LoadField: d0 = r0->field_b
    //     0x838db0: ldur            d0, [x0, #0xb]
    // 0x838db4: d1 = -2.000000
    //     0x838db4: fmov            d1, #-2.00000000
    // 0x838db8: fdiv            d2, d1, d0
    // 0x838dbc: stur            d2, [fp, #-0xf8]
    // 0x838dc0: r0 = Offset()
    //     0x838dc0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x838dc4: ldur            d0, [fp, #-0xf8]
    // 0x838dc8: stur            x0, [fp, #-0x60]
    // 0x838dcc: StoreField: r0->field_7 = d0
    //     0x838dcc: stur            d0, [x0, #7]
    // 0x838dd0: d0 = 0.000000
    //     0x838dd0: eor             v0.16b, v0.16b, v0.16b
    // 0x838dd4: StoreField: r0->field_f = d0
    //     0x838dd4: stur            d0, [x0, #0xf]
    // 0x838dd8: ldur            x2, [fp, #-8]
    // 0x838ddc: r1 = Function '<anonymous closure>':.
    //     0x838ddc: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bcd0] AnonymousClosure: (0x83eb74), in [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::build (0x838588)
    //     0x838de0: ldr             x1, [x1, #0xcd0]
    // 0x838de4: r0 = AllocateClosure()
    //     0x838de4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x838de8: ldur            x1, [fp, #-8]
    // 0x838dec: StoreField: r1->field_1b = r0
    //     0x838dec: stur            w0, [x1, #0x1b]
    //     0x838df0: ldurb           w16, [x1, #-1]
    //     0x838df4: ldurb           w17, [x0, #-1]
    //     0x838df8: and             x16, x17, x16, lsr #2
    //     0x838dfc: tst             x16, HEAP, lsr #32
    //     0x838e00: b.eq            #0x838e08
    //     0x838e04: bl              #0xd6826c
    // 0x838e08: ldur            x9, [fp, #-0x58]
    // 0x838e0c: ldur            x6, [fp, #-0x60]
    // 0x838e10: ldur            x5, [fp, #-0x48]
    // 0x838e14: ldur            x4, [fp, #-0x10]
    // 0x838e18: mov             x2, x1
    // 0x838e1c: r8 = true
    //     0x838e1c: add             x8, NULL, #0x20  ; true
    // 0x838e20: r7 = true
    //     0x838e20: add             x7, NULL, #0x20  ; true
    // 0x838e24: r3 = Null
    //     0x838e24: mov             x3, NULL
    // 0x838e28: r1 = Instance_Radius
    //     0x838e28: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dc90] Obj!Radius@b5e8a1
    //     0x838e2c: ldr             x1, [x1, #0xc90]
    // 0x838e30: b               #0x838f44
    // 0x838e34: ldr             x3, [fp, #0x18]
    // 0x838e38: ldur            x1, [fp, #-8]
    // 0x838e3c: mov             x0, x4
    // 0x838e40: mov             x4, x5
    // 0x838e44: StoreField: r3->field_37 = r0
    //     0x838e44: stur            w0, [x3, #0x37]
    // 0x838e48: r0 = InitLateStaticField(0xd78) // [package:flutter/src/material/desktop_text_selection.dart] ::desktopTextSelectionControls
    //     0x838e48: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x838e4c: ldr             x0, [x0, #0x1af0]
    //     0x838e50: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x838e54: cmp             w0, w16
    //     0x838e58: b.ne            #0x838e68
    //     0x838e5c: add             x2, PP, #0x4b, lsl #12  ; [pp+0x4bcc0] Field <::.desktopTextSelectionControls>: static late final (offset: 0xd78)
    //     0x838e60: ldr             x2, [x2, #0xcc0]
    //     0x838e64: bl              #0xd67cdc
    // 0x838e68: mov             x1, x0
    // 0x838e6c: ldr             x0, [fp, #0x18]
    // 0x838e70: stur            x1, [fp, #-0x48]
    // 0x838e74: LoadField: r2 = r0->field_b
    //     0x838e74: ldur            w2, [x0, #0xb]
    // 0x838e78: DecompressPointer r2
    //     0x838e78: add             x2, x2, HEAP, lsl #32
    // 0x838e7c: cmp             w2, NULL
    // 0x838e80: b.eq            #0x839578
    // 0x838e84: ldur            x2, [fp, #-0x18]
    // 0x838e88: LoadField: r3 = r2->field_7
    //     0x838e88: ldur            w3, [x2, #7]
    // 0x838e8c: DecompressPointer r3
    //     0x838e8c: add             x3, x3, HEAP, lsl #32
    // 0x838e90: cmp             w3, NULL
    // 0x838e94: b.ne            #0x838ea8
    // 0x838e98: ldur            x4, [fp, #-0x28]
    // 0x838e9c: LoadField: r3 = r4->field_b
    //     0x838e9c: ldur            w3, [x4, #0xb]
    // 0x838ea0: DecompressPointer r3
    //     0x838ea0: add             x3, x3, HEAP, lsl #32
    // 0x838ea4: b               #0x838eac
    // 0x838ea8: ldur            x4, [fp, #-0x28]
    // 0x838eac: stur            x3, [fp, #-0x10]
    // 0x838eb0: LoadField: r5 = r2->field_b
    //     0x838eb0: ldur            w5, [x2, #0xb]
    // 0x838eb4: DecompressPointer r5
    //     0x838eb4: add             x5, x5, HEAP, lsl #32
    // 0x838eb8: cmp             w5, NULL
    // 0x838ebc: b.ne            #0x838ee8
    // 0x838ec0: d0 = 0.400000
    //     0x838ec0: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d148] IMM: double(0.4) from 0x3fd999999999999a
    //     0x838ec4: ldr             d0, [x17, #0x148]
    // 0x838ec8: LoadField: r2 = r4->field_b
    //     0x838ec8: ldur            w2, [x4, #0xb]
    // 0x838ecc: DecompressPointer r2
    //     0x838ecc: add             x2, x2, HEAP, lsl #32
    // 0x838ed0: SaveReg r2
    //     0x838ed0: str             x2, [SP, #-8]!
    // 0x838ed4: SaveReg d0
    //     0x838ed4: str             d0, [SP, #-8]!
    // 0x838ed8: r0 = withOpacity()
    //     0x838ed8: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x838edc: add             SP, SP, #0x10
    // 0x838ee0: mov             x3, x0
    // 0x838ee4: b               #0x838eec
    // 0x838ee8: mov             x3, x5
    // 0x838eec: ldur            x0, [fp, #-8]
    // 0x838ef0: mov             x2, x0
    // 0x838ef4: stur            x3, [fp, #-0x18]
    // 0x838ef8: r1 = Function '<anonymous closure>':.
    //     0x838ef8: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bcd8] AnonymousClosure: (0x83eb74), in [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::build (0x838588)
    //     0x838efc: ldr             x1, [x1, #0xcd8]
    // 0x838f00: r0 = AllocateClosure()
    //     0x838f00: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x838f04: ldur            x2, [fp, #-8]
    // 0x838f08: StoreField: r2->field_1b = r0
    //     0x838f08: stur            w0, [x2, #0x1b]
    //     0x838f0c: ldurb           w16, [x2, #-1]
    //     0x838f10: ldurb           w17, [x0, #-1]
    //     0x838f14: and             x16, x17, x16, lsr #2
    //     0x838f18: tst             x16, HEAP, lsr #32
    //     0x838f1c: b.eq            #0x838f24
    //     0x838f20: bl              #0xd6828c
    // 0x838f24: ldur            x9, [fp, #-0x48]
    // 0x838f28: ldur            x5, [fp, #-0x10]
    // 0x838f2c: ldur            x4, [fp, #-0x18]
    // 0x838f30: r8 = false
    //     0x838f30: add             x8, NULL, #0x30  ; false
    // 0x838f34: r7 = false
    //     0x838f34: add             x7, NULL, #0x30  ; false
    // 0x838f38: r6 = Null
    //     0x838f38: mov             x6, NULL
    // 0x838f3c: r3 = Null
    //     0x838f3c: mov             x3, NULL
    // 0x838f40: r1 = Null
    //     0x838f40: mov             x1, NULL
    // 0x838f44: ldr             x0, [fp, #0x18]
    // 0x838f48: stur            x9, [fp, #-0x88]
    // 0x838f4c: stur            x8, [fp, #-0x90]
    // 0x838f50: stur            x7, [fp, #-0x98]
    // 0x838f54: stur            x6, [fp, #-0xa0]
    // 0x838f58: stur            x5, [fp, #-0xa8]
    // 0x838f5c: stur            x4, [fp, #-0xb0]
    // 0x838f60: stur            x3, [fp, #-0xb8]
    // 0x838f64: stur            x1, [fp, #-0xc0]
    // 0x838f68: LoadField: r10 = r0->field_3b
    //     0x838f68: ldur            w10, [x0, #0x3b]
    // 0x838f6c: DecompressPointer r10
    //     0x838f6c: add             x10, x10, HEAP, lsl #32
    // 0x838f70: stur            x10, [fp, #-0x80]
    // 0x838f74: LoadField: r11 = r0->field_b
    //     0x838f74: ldur            w11, [x0, #0xb]
    // 0x838f78: DecompressPointer r11
    //     0x838f78: add             x11, x11, HEAP, lsl #32
    // 0x838f7c: cmp             w11, NULL
    // 0x838f80: b.eq            #0x83957c
    // 0x838f84: LoadField: r12 = r11->field_13
    //     0x838f84: ldur            w12, [x11, #0x13]
    // 0x838f88: DecompressPointer r12
    //     0x838f88: add             x12, x12, HEAP, lsl #32
    // 0x838f8c: stur            x12, [fp, #-0x78]
    // 0x838f90: LoadField: r13 = r11->field_1f
    //     0x838f90: ldur            w13, [x11, #0x1f]
    // 0x838f94: DecompressPointer r13
    //     0x838f94: add             x13, x13, HEAP, lsl #32
    // 0x838f98: LoadField: r14 = r13->field_bf
    //     0x838f98: ldur            w14, [x13, #0xbf]
    // 0x838f9c: DecompressPointer r14
    //     0x838f9c: add             x14, x14, HEAP, lsl #32
    // 0x838fa0: eor             x13, x14, #0x10
    // 0x838fa4: stur            x13, [fp, #-0x70]
    // 0x838fa8: LoadField: r14 = r11->field_6f
    //     0x838fa8: ldur            w14, [x11, #0x6f]
    // 0x838fac: DecompressPointer r14
    //     0x838fac: add             x14, x14, HEAP, lsl #32
    // 0x838fb0: stur            x14, [fp, #-0x68]
    // 0x838fb4: LoadField: r19 = r0->field_2f
    //     0x838fb4: ldur            w19, [x0, #0x2f]
    // 0x838fb8: DecompressPointer r19
    //     0x838fb8: add             x19, x19, HEAP, lsl #32
    // 0x838fbc: stur            x19, [fp, #-0x60]
    // 0x838fc0: LoadField: r20 = r11->field_23
    //     0x838fc0: ldur            w20, [x11, #0x23]
    // 0x838fc4: DecompressPointer r20
    //     0x838fc4: add             x20, x20, HEAP, lsl #32
    // 0x838fc8: stur            x20, [fp, #-0x58]
    // 0x838fcc: LoadField: r23 = r11->field_43
    //     0x838fcc: ldur            w23, [x11, #0x43]
    // 0x838fd0: DecompressPointer r23
    //     0x838fd0: add             x23, x23, HEAP, lsl #32
    // 0x838fd4: stur            x23, [fp, #-0x48]
    // 0x838fd8: LoadField: r24 = r11->field_53
    //     0x838fd8: ldur            w24, [x11, #0x53]
    // 0x838fdc: DecompressPointer r24
    //     0x838fdc: add             x24, x24, HEAP, lsl #32
    // 0x838fe0: stur            x24, [fp, #-0x28]
    // 0x838fe4: LoadField: r25 = r11->field_57
    //     0x838fe4: ldur            w25, [x11, #0x57]
    // 0x838fe8: DecompressPointer r25
    //     0x838fe8: add             x25, x25, HEAP, lsl #32
    // 0x838fec: stur            x25, [fp, #-0x18]
    // 0x838ff0: LoadField: r0 = r11->field_5f
    //     0x838ff0: ldur            w0, [x11, #0x5f]
    // 0x838ff4: DecompressPointer r0
    //     0x838ff4: add             x0, x0, HEAP, lsl #32
    // 0x838ff8: stur            x0, [fp, #-0x10]
    // 0x838ffc: ldur            x16, [fp, #-0x40]
    // 0x839000: SaveReg r16
    //     0x839000: str             x16, [SP, #-8]!
    // 0x839004: r0 = hasFocus()
    //     0x839004: bl              #0x6f8fe4  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0x839008: add             SP, SP, #8
    // 0x83900c: tbnz            w0, #4, #0x839018
    // 0x839010: ldur            x1, [fp, #-0xb0]
    // 0x839014: b               #0x83901c
    // 0x839018: r1 = Null
    //     0x839018: mov             x1, NULL
    // 0x83901c: ldr             x0, [fp, #0x18]
    // 0x839020: stur            x1, [fp, #-0xd8]
    // 0x839024: LoadField: r2 = r0->field_b
    //     0x839024: ldur            w2, [x0, #0xb]
    // 0x839028: DecompressPointer r2
    //     0x839028: add             x2, x2, HEAP, lsl #32
    // 0x83902c: stur            x2, [fp, #-0xd0]
    // 0x839030: cmp             w2, NULL
    // 0x839034: b.eq            #0x839580
    // 0x839038: LoadField: r3 = r2->field_bb
    //     0x839038: ldur            w3, [x2, #0xbb]
    // 0x83903c: DecompressPointer r3
    //     0x83903c: add             x3, x3, HEAP, lsl #32
    // 0x839040: stur            x3, [fp, #-0xc8]
    // 0x839044: tbnz            w3, #4, #0x839050
    // 0x839048: ldur            x6, [fp, #-0x88]
    // 0x83904c: b               #0x839054
    // 0x839050: r6 = Null
    //     0x839050: mov             x6, NULL
    // 0x839054: ldur            x5, [fp, #-0x38]
    // 0x839058: ldur            x4, [fp, #-0x40]
    // 0x83905c: stur            x6, [fp, #-0xb0]
    // 0x839060: LoadField: r7 = r2->field_7f
    //     0x839060: ldur            w7, [x2, #0x7f]
    // 0x839064: DecompressPointer r7
    //     0x839064: add             x7, x7, HEAP, lsl #32
    // 0x839068: stur            x7, [fp, #-0x88]
    // 0x83906c: r1 = 1
    //     0x83906c: mov             x1, #1
    // 0x839070: r0 = AllocateContext()
    //     0x839070: bl              #0xd68aa4  ; AllocateContextStub
    // 0x839074: mov             x1, x0
    // 0x839078: ldr             x0, [fp, #0x18]
    // 0x83907c: stur            x1, [fp, #-0xe8]
    // 0x839080: StoreField: r1->field_f = r0
    //     0x839080: stur            w0, [x1, #0xf]
    // 0x839084: ldur            x2, [fp, #-0xd0]
    // 0x839088: LoadField: r3 = r2->field_87
    //     0x839088: ldur            w3, [x2, #0x87]
    // 0x83908c: DecompressPointer r3
    //     0x83908c: add             x3, x3, HEAP, lsl #32
    // 0x839090: stur            x3, [fp, #-0xe0]
    // 0x839094: r1 = 1
    //     0x839094: mov             x1, #1
    // 0x839098: r0 = AllocateContext()
    //     0x839098: bl              #0xd68aa4  ; AllocateContextStub
    // 0x83909c: mov             x3, x0
    // 0x8390a0: ldr             x0, [fp, #0x18]
    // 0x8390a4: stur            x3, [fp, #-0xd0]
    // 0x8390a8: StoreField: r3->field_f = r0
    //     0x8390a8: stur            w0, [x3, #0xf]
    // 0x8390ac: LoadField: r1 = r0->field_33
    //     0x8390ac: ldur            w1, [x0, #0x33]
    // 0x8390b0: DecompressPointer r1
    //     0x8390b0: add             x1, x1, HEAP, lsl #32
    // 0x8390b4: r16 = Sentinel
    //     0x8390b4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8390b8: cmp             w1, w16
    // 0x8390bc: b.eq            #0x839584
    // 0x8390c0: ldur            x2, [fp, #-0xe8]
    // 0x8390c4: r1 = Function '_handleSelectionChanged@479054530':.
    //     0x8390c4: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bce0] AnonymousClosure: (0x83e270), in [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_handleSelectionChanged (0x83e2c4)
    //     0x8390c8: ldr             x1, [x1, #0xce0]
    // 0x8390cc: r0 = AllocateClosure()
    //     0x8390cc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8390d0: ldur            x2, [fp, #-0xd0]
    // 0x8390d4: r1 = Function '_handleSelectionHandleTapped@479054530':.
    //     0x8390d4: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bce8] AnonymousClosure: (0x83e0fc), in [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_handleSelectionHandleTapped (0x83e144)
    //     0x8390d8: ldr             x1, [x1, #0xce8]
    // 0x8390dc: stur            x0, [fp, #-0xd0]
    // 0x8390e0: r0 = AllocateClosure()
    //     0x8390e0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8390e4: stur            x0, [fp, #-0xe8]
    // 0x8390e8: r0 = ExtendedEditableText()
    //     0x8390e8: bl              #0x83d258  ; AllocateExtendedEditableTextStub -> ExtendedEditableText (size=0x114)
    // 0x8390ec: stur            x0, [fp, #-0xf0]
    // 0x8390f0: ldur            x16, [fp, #-0xb8]
    // 0x8390f4: stp             x16, x0, [SP, #-0x10]!
    // 0x8390f8: ldr             x16, [fp, #0x18]
    // 0x8390fc: ldur            lr, [fp, #-0x48]
    // 0x839100: stp             lr, x16, [SP, #-0x10]!
    // 0x839104: ldur            x16, [fp, #-0x38]
    // 0x839108: ldur            lr, [fp, #-0xa8]
    // 0x83910c: stp             lr, x16, [SP, #-0x10]!
    // 0x839110: ldur            x16, [fp, #-0xa0]
    // 0x839114: ldur            lr, [fp, #-0x98]
    // 0x839118: stp             lr, x16, [SP, #-0x10]!
    // 0x83911c: ldur            x16, [fp, #-0xc0]
    // 0x839120: ldur            lr, [fp, #-0xc8]
    // 0x839124: stp             lr, x16, [SP, #-0x10]!
    // 0x839128: ldur            x16, [fp, #-0x40]
    // 0x83912c: ldur            lr, [fp, #-0x50]
    // 0x839130: stp             lr, x16, [SP, #-0x10]!
    // 0x839134: ldur            x16, [fp, #-0x80]
    // 0x839138: ldur            lr, [fp, #-0x20]
    // 0x83913c: stp             lr, x16, [SP, #-0x10]!
    // 0x839140: ldur            x16, [fp, #-0x58]
    // 0x839144: ldur            lr, [fp, #-0x10]
    // 0x839148: stp             lr, x16, [SP, #-0x10]!
    // 0x83914c: ldur            x16, [fp, #-0x88]
    // 0x839150: ldur            lr, [fp, #-0xd0]
    // 0x839154: stp             lr, x16, [SP, #-0x10]!
    // 0x839158: ldur            x16, [fp, #-0xe8]
    // 0x83915c: ldur            lr, [fp, #-0xe0]
    // 0x839160: stp             lr, x16, [SP, #-0x10]!
    // 0x839164: ldur            x16, [fp, #-0x90]
    // 0x839168: ldur            lr, [fp, #-0x70]
    // 0x83916c: stp             lr, x16, [SP, #-0x10]!
    // 0x839170: ldur            x16, [fp, #-0xd8]
    // 0x839174: ldur            lr, [fp, #-0xb0]
    // 0x839178: stp             lr, x16, [SP, #-0x10]!
    // 0x83917c: ldur            x16, [fp, #-0x60]
    // 0x839180: ldur            lr, [fp, #-0x28]
    // 0x839184: stp             lr, x16, [SP, #-0x10]!
    // 0x839188: ldur            x16, [fp, #-0x18]
    // 0x83918c: ldur            lr, [fp, #-0x78]
    // 0x839190: stp             lr, x16, [SP, #-0x10]!
    // 0x839194: ldur            x16, [fp, #-0x30]
    // 0x839198: ldur            lr, [fp, #-0x68]
    // 0x83919c: stp             lr, x16, [SP, #-0x10]!
    // 0x8391a0: r0 = ExtendedEditableText()
    //     0x8391a0: bl              #0x83cd88  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableText::ExtendedEditableText
    // 0x8391a4: add             SP, SP, #0xf0
    // 0x8391a8: r0 = UnmanagedRestorationScope()
    //     0x8391a8: bl              #0x83cd7c  ; AllocateUnmanagedRestorationScopeStub -> UnmanagedRestorationScope (size=0x14)
    // 0x8391ac: mov             x1, x0
    // 0x8391b0: ldur            x0, [fp, #-0xf0]
    // 0x8391b4: stur            x1, [fp, #-0x10]
    // 0x8391b8: StoreField: r1->field_b = r0
    //     0x8391b8: stur            w0, [x1, #0xb]
    // 0x8391bc: r0 = RepaintBoundary()
    //     0x8391bc: bl              #0x83cd70  ; AllocateRepaintBoundaryStub -> RepaintBoundary (size=0x10)
    // 0x8391c0: mov             x3, x0
    // 0x8391c4: ldur            x0, [fp, #-0x10]
    // 0x8391c8: stur            x3, [fp, #-0x18]
    // 0x8391cc: StoreField: r3->field_b = r0
    //     0x8391cc: stur            w0, [x3, #0xb]
    // 0x8391d0: ldr             x0, [fp, #0x18]
    // 0x8391d4: LoadField: r1 = r0->field_b
    //     0x8391d4: ldur            w1, [x0, #0xb]
    // 0x8391d8: DecompressPointer r1
    //     0x8391d8: add             x1, x1, HEAP, lsl #32
    // 0x8391dc: cmp             w1, NULL
    // 0x8391e0: b.eq            #0x839590
    // 0x8391e4: r1 = Null
    //     0x8391e4: mov             x1, NULL
    // 0x8391e8: r2 = 4
    //     0x8391e8: mov             x2, #4
    // 0x8391ec: r0 = AllocateArray()
    //     0x8391ec: bl              #0xd6987c  ; AllocateArrayStub
    // 0x8391f0: mov             x2, x0
    // 0x8391f4: ldur            x0, [fp, #-0x40]
    // 0x8391f8: stur            x2, [fp, #-0x10]
    // 0x8391fc: StoreField: r2->field_f = r0
    //     0x8391fc: stur            w0, [x2, #0xf]
    // 0x839200: ldur            x3, [fp, #-0x38]
    // 0x839204: StoreField: r2->field_13 = r3
    //     0x839204: stur            w3, [x2, #0x13]
    // 0x839208: r1 = <Listenable>
    //     0x839208: add             x1, PP, #0x28, lsl #12  ; [pp+0x28488] TypeArguments: <Listenable>
    //     0x83920c: ldr             x1, [x1, #0x488]
    // 0x839210: r0 = AllocateGrowableArray()
    //     0x839210: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x839214: mov             x1, x0
    // 0x839218: ldur            x0, [fp, #-0x10]
    // 0x83921c: stur            x1, [fp, #-0x20]
    // 0x839220: StoreField: r1->field_f = r0
    //     0x839220: stur            w0, [x1, #0xf]
    // 0x839224: r0 = 4
    //     0x839224: mov             x0, #4
    // 0x839228: StoreField: r1->field_b = r0
    //     0x839228: stur            w0, [x1, #0xb]
    // 0x83922c: r0 = _MergingListenable()
    //     0x83922c: bl              #0x83cd64  ; Allocate_MergingListenableStub -> _MergingListenable (size=0xc)
    // 0x839230: mov             x3, x0
    // 0x839234: ldur            x0, [fp, #-0x20]
    // 0x839238: stur            x3, [fp, #-0x10]
    // 0x83923c: StoreField: r3->field_7 = r0
    //     0x83923c: stur            w0, [x3, #7]
    // 0x839240: ldur            x2, [fp, #-8]
    // 0x839244: r1 = Function '<anonymous closure>':.
    //     0x839244: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bcf0] AnonymousClosure: (0x83dad4), in [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::build (0x838588)
    //     0x839248: ldr             x1, [x1, #0xcf0]
    // 0x83924c: r0 = AllocateClosure()
    //     0x83924c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x839250: stur            x0, [fp, #-0x20]
    // 0x839254: r0 = AnimatedBuilder()
    //     0x839254: bl              #0x822330  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x839258: mov             x1, x0
    // 0x83925c: ldur            x0, [fp, #-0x20]
    // 0x839260: stur            x1, [fp, #-0x28]
    // 0x839264: StoreField: r1->field_f = r0
    //     0x839264: stur            w0, [x1, #0xf]
    // 0x839268: ldur            x0, [fp, #-0x18]
    // 0x83926c: StoreField: r1->field_13 = r0
    //     0x83926c: stur            w0, [x1, #0x13]
    // 0x839270: ldur            x0, [fp, #-0x10]
    // 0x839274: StoreField: r1->field_b = r0
    //     0x839274: stur            w0, [x1, #0xb]
    // 0x839278: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x839278: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x83927c: ldr             x0, [x0, #0x598]
    //     0x839280: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x839284: cmp             w0, w16
    //     0x839288: b.ne            #0x839294
    //     0x83928c: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x839290: bl              #0xd67cdc
    // 0x839294: r1 = <MaterialState>
    //     0x839294: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dcf0] TypeArguments: <MaterialState>
    //     0x839298: ldr             x1, [x1, #0xcf0]
    // 0x83929c: stur            x0, [fp, #-0x10]
    // 0x8392a0: r0 = _Set()
    //     0x8392a0: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x8392a4: mov             x1, x0
    // 0x8392a8: ldur            x0, [fp, #-0x10]
    // 0x8392ac: stur            x1, [fp, #-0x18]
    // 0x8392b0: StoreField: r1->field_1b = r0
    //     0x8392b0: stur            w0, [x1, #0x1b]
    // 0x8392b4: StoreField: r1->field_b = rZR
    //     0x8392b4: stur            wzr, [x1, #0xb]
    // 0x8392b8: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x8392b8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x8392bc: ldr             x0, [x0, #0x5a0]
    //     0x8392c0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x8392c4: cmp             w0, w16
    //     0x8392c8: b.ne            #0x8392d4
    //     0x8392cc: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x8392d0: bl              #0xd67cdc
    // 0x8392d4: mov             x1, x0
    // 0x8392d8: ldur            x0, [fp, #-0x18]
    // 0x8392dc: StoreField: r0->field_f = r1
    //     0x8392dc: stur            w1, [x0, #0xf]
    // 0x8392e0: StoreField: r0->field_13 = rZR
    //     0x8392e0: stur            wzr, [x0, #0x13]
    // 0x8392e4: StoreField: r0->field_17 = rZR
    //     0x8392e4: stur            wzr, [x0, #0x17]
    // 0x8392e8: ldr             x1, [fp, #0x18]
    // 0x8392ec: LoadField: r2 = r1->field_b
    //     0x8392ec: ldur            w2, [x1, #0xb]
    // 0x8392f0: DecompressPointer r2
    //     0x8392f0: add             x2, x2, HEAP, lsl #32
    // 0x8392f4: cmp             w2, NULL
    // 0x8392f8: b.eq            #0x839594
    // 0x8392fc: LoadField: r3 = r2->field_1f
    //     0x8392fc: ldur            w3, [x2, #0x1f]
    // 0x839300: DecompressPointer r3
    //     0x839300: add             x3, x3, HEAP, lsl #32
    // 0x839304: LoadField: r2 = r3->field_bf
    //     0x839304: ldur            w2, [x3, #0xbf]
    // 0x839308: DecompressPointer r2
    //     0x839308: add             x2, x2, HEAP, lsl #32
    // 0x83930c: tbz             w2, #4, #0x839324
    // 0x839310: r16 = Instance_MaterialState
    //     0x839310: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x839314: ldr             x16, [x16, #0x2a0]
    // 0x839318: stp             x16, x0, [SP, #-0x10]!
    // 0x83931c: r0 = add()
    //     0x83931c: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x839320: add             SP, SP, #0x10
    // 0x839324: ldr             x0, [fp, #0x18]
    // 0x839328: LoadField: r1 = r0->field_2b
    //     0x839328: ldur            w1, [x0, #0x2b]
    // 0x83932c: DecompressPointer r1
    //     0x83932c: add             x1, x1, HEAP, lsl #32
    // 0x839330: tbnz            w1, #4, #0x83934c
    // 0x839334: ldur            x16, [fp, #-0x18]
    // 0x839338: r30 = Instance_MaterialState
    //     0x839338: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0x83933c: ldr             lr, [lr, #0xf78]
    // 0x839340: stp             lr, x16, [SP, #-0x10]!
    // 0x839344: r0 = add()
    //     0x839344: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x839348: add             SP, SP, #0x10
    // 0x83934c: ldur            x16, [fp, #-0x40]
    // 0x839350: SaveReg r16
    //     0x839350: str             x16, [SP, #-8]!
    // 0x839354: r0 = hasFocus()
    //     0x839354: bl              #0x6f8fe4  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0x839358: add             SP, SP, #8
    // 0x83935c: tbnz            w0, #4, #0x839378
    // 0x839360: ldur            x16, [fp, #-0x18]
    // 0x839364: r30 = Instance_MaterialState
    //     0x839364: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0x839368: ldr             lr, [lr, #0xf88]
    // 0x83936c: stp             lr, x16, [SP, #-0x10]!
    // 0x839370: r0 = add()
    //     0x839370: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x839374: add             SP, SP, #0x10
    // 0x839378: ldr             x16, [fp, #0x18]
    // 0x83937c: SaveReg r16
    //     0x83937c: str             x16, [SP, #-8]!
    // 0x839380: r0 = _hasError()
    //     0x839380: bl              #0x83cc14  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_hasError
    // 0x839384: add             SP, SP, #8
    // 0x839388: tbnz            w0, #4, #0x8393a4
    // 0x83938c: ldur            x16, [fp, #-0x18]
    // 0x839390: r30 = Instance_MaterialState
    //     0x839390: add             lr, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!MaterialState@b654b1
    //     0x839394: ldr             lr, [lr, #0x298]
    // 0x839398: stp             lr, x16, [SP, #-0x10]!
    // 0x83939c: r0 = add()
    //     0x83939c: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x8393a0: add             SP, SP, #0x10
    // 0x8393a4: ldur            x2, [fp, #-8]
    // 0x8393a8: r16 = <MouseCursor>
    //     0x8393a8: ldr             x16, [PP, #0x3980]  ; [pp+0x3980] TypeArguments: <MouseCursor>
    // 0x8393ac: r30 = Instance__EnabledAndDisabledMouseCursor
    //     0x8393ac: add             lr, PP, #0x2d, lsl #12  ; [pp+0x2dcf8] Obj!_EnabledAndDisabledMouseCursor@b48a11
    //     0x8393b0: ldr             lr, [lr, #0xcf8]
    // 0x8393b4: stp             lr, x16, [SP, #-0x10]!
    // 0x8393b8: ldur            x16, [fp, #-0x18]
    // 0x8393bc: SaveReg r16
    //     0x8393bc: str             x16, [SP, #-8]!
    // 0x8393c0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8393c0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8393c4: r0 = resolveAs()
    //     0x8393c4: bl              #0x5a6b88  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveAs
    // 0x8393c8: add             SP, SP, #0x18
    // 0x8393cc: ldur            x2, [fp, #-8]
    // 0x8393d0: stur            x0, [fp, #-0x10]
    // 0x8393d4: StoreField: r2->field_1f = rNULL
    //     0x8393d4: stur            NULL, [x2, #0x1f]
    // 0x8393d8: ldr             x16, [fp, #0x18]
    // 0x8393dc: SaveReg r16
    //     0x8393dc: str             x16, [SP, #-8]!
    // 0x8393e0: r0 = _effectiveMaxLengthEnforcement()
    //     0x8393e0: bl              #0x83d4b8  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveMaxLengthEnforcement
    // 0x8393e4: add             SP, SP, #8
    // 0x8393e8: r16 = Instance_MaxLengthEnforcement
    //     0x8393e8: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dd00] Obj!MaxLengthEnforcement@b64251
    //     0x8393ec: ldr             x16, [x16, #0xd00]
    // 0x8393f0: cmp             w0, w16
    // 0x8393f4: b.eq            #0x839444
    // 0x8393f8: ldr             x0, [fp, #0x18]
    // 0x8393fc: LoadField: r1 = r0->field_b
    //     0x8393fc: ldur            w1, [x0, #0xb]
    // 0x839400: DecompressPointer r1
    //     0x839400: add             x1, x1, HEAP, lsl #32
    // 0x839404: cmp             w1, NULL
    // 0x839408: b.eq            #0x839598
    // 0x83940c: LoadField: r2 = r1->field_77
    //     0x83940c: ldur            w2, [x1, #0x77]
    // 0x839410: DecompressPointer r2
    //     0x839410: add             x2, x2, HEAP, lsl #32
    // 0x839414: cmp             w2, NULL
    // 0x839418: b.eq            #0x83943c
    // 0x83941c: r1 = LoadInt32Instr(r2)
    //     0x83941c: sbfx            x1, x2, #1, #0x1f
    // 0x839420: cmp             x1, #0
    // 0x839424: b.le            #0x839434
    // 0x839428: ldur            x1, [fp, #-8]
    // 0x83942c: StoreField: r1->field_1f = r2
    //     0x83942c: stur            w2, [x1, #0x1f]
    // 0x839430: b               #0x839450
    // 0x839434: ldur            x1, [fp, #-8]
    // 0x839438: b               #0x83944c
    // 0x83943c: ldur            x1, [fp, #-8]
    // 0x839440: b               #0x83944c
    // 0x839444: ldr             x0, [fp, #0x18]
    // 0x839448: ldur            x1, [fp, #-8]
    // 0x83944c: StoreField: r1->field_1f = rNULL
    //     0x83944c: stur            NULL, [x1, #0x1f]
    // 0x839450: ldur            x3, [fp, #-0x38]
    // 0x839454: ldur            x2, [fp, #-0x10]
    // 0x839458: SaveReg r0
    //     0x839458: str             x0, [SP, #-8]!
    // 0x83945c: r0 = _isEnabled()
    //     0x83945c: bl              #0x7ae4d0  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_isEnabled
    // 0x839460: add             SP, SP, #8
    // 0x839464: eor             x1, x0, #0x10
    // 0x839468: ldr             x0, [fp, #0x18]
    // 0x83946c: stur            x1, [fp, #-0x18]
    // 0x839470: LoadField: r2 = r0->field_33
    //     0x839470: ldur            w2, [x0, #0x33]
    // 0x839474: DecompressPointer r2
    //     0x839474: add             x2, x2, HEAP, lsl #32
    // 0x839478: ldur            x16, [fp, #-0x28]
    // 0x83947c: stp             x16, x2, [SP, #-0x10]!
    // 0x839480: r0 = buildGestureDetector()
    //     0x839480: bl              #0x83959c  ; [package:extended_text_library/src/selection/extended_text_selection.dart] ExtendedTextSelectionGestureDetectorBuilder::buildGestureDetector
    // 0x839484: add             SP, SP, #0x10
    // 0x839488: ldur            x2, [fp, #-8]
    // 0x83948c: r1 = Function '<anonymous closure>':.
    //     0x83948c: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bcf8] AnonymousClosure: (0x83d790), in [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::build (0x838588)
    //     0x839490: ldr             x1, [x1, #0xcf8]
    // 0x839494: stur            x0, [fp, #-0x20]
    // 0x839498: r0 = AllocateClosure()
    //     0x839498: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x83949c: stur            x0, [fp, #-0x28]
    // 0x8394a0: r0 = AnimatedBuilder()
    //     0x8394a0: bl              #0x822330  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x8394a4: mov             x1, x0
    // 0x8394a8: ldur            x0, [fp, #-0x28]
    // 0x8394ac: stur            x1, [fp, #-0x30]
    // 0x8394b0: StoreField: r1->field_f = r0
    //     0x8394b0: stur            w0, [x1, #0xf]
    // 0x8394b4: ldur            x0, [fp, #-0x20]
    // 0x8394b8: StoreField: r1->field_13 = r0
    //     0x8394b8: stur            w0, [x1, #0x13]
    // 0x8394bc: ldur            x0, [fp, #-0x38]
    // 0x8394c0: StoreField: r1->field_b = r0
    //     0x8394c0: stur            w0, [x1, #0xb]
    // 0x8394c4: r0 = IgnorePointer()
    //     0x8394c4: bl              #0x8303bc  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0x8394c8: mov             x3, x0
    // 0x8394cc: ldur            x0, [fp, #-0x18]
    // 0x8394d0: stur            x3, [fp, #-0x20]
    // 0x8394d4: StoreField: r3->field_f = r0
    //     0x8394d4: stur            w0, [x3, #0xf]
    // 0x8394d8: ldur            x0, [fp, #-0x30]
    // 0x8394dc: StoreField: r3->field_b = r0
    //     0x8394dc: stur            w0, [x3, #0xb]
    // 0x8394e0: ldur            x2, [fp, #-8]
    // 0x8394e4: r1 = Function '<anonymous closure>':.
    //     0x8394e4: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bd00] AnonymousClosure: (0x83d744), in [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::build (0x838588)
    //     0x8394e8: ldr             x1, [x1, #0xd00]
    // 0x8394ec: r0 = AllocateClosure()
    //     0x8394ec: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8394f0: stur            x0, [fp, #-0x18]
    // 0x8394f4: r0 = MouseRegion()
    //     0x8394f4: bl              #0x834678  ; AllocateMouseRegionStub -> MouseRegion (size=0x28)
    // 0x8394f8: mov             x3, x0
    // 0x8394fc: ldur            x0, [fp, #-0x18]
    // 0x839500: stur            x3, [fp, #-0x28]
    // 0x839504: StoreField: r3->field_f = r0
    //     0x839504: stur            w0, [x3, #0xf]
    // 0x839508: ldur            x2, [fp, #-8]
    // 0x83950c: r1 = Function '<anonymous closure>':.
    //     0x83950c: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bd08] AnonymousClosure: (0x83d5c0), in [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::build (0x838588)
    //     0x839510: ldr             x1, [x1, #0xd08]
    // 0x839514: r0 = AllocateClosure()
    //     0x839514: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x839518: mov             x1, x0
    // 0x83951c: ldur            x0, [fp, #-0x28]
    // 0x839520: StoreField: r0->field_17 = r1
    //     0x839520: stur            w1, [x0, #0x17]
    // 0x839524: ldur            x1, [fp, #-0x10]
    // 0x839528: StoreField: r0->field_1b = r1
    //     0x839528: stur            w1, [x0, #0x1b]
    // 0x83952c: r1 = true
    //     0x83952c: add             x1, NULL, #0x20  ; true
    // 0x839530: StoreField: r0->field_1f = r1
    //     0x839530: stur            w1, [x0, #0x1f]
    // 0x839534: ldur            x1, [fp, #-0x20]
    // 0x839538: StoreField: r0->field_b = r1
    //     0x839538: stur            w1, [x0, #0xb]
    // 0x83953c: LeaveFrame
    //     0x83953c: mov             SP, fp
    //     0x839540: ldp             fp, lr, [SP], #0x10
    // 0x839544: ret
    //     0x839544: ret             
    // 0x839548: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x839548: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83954c: b               #0x8385a0
    // 0x839550: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x839550: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x839554: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x839554: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x839558: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x839558: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83955c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83955c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x839560: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x839560: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x839564: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x839564: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x839568: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x839568: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83956c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83956c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x839570: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x839570: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x839574: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x839574: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x839578: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x839578: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83957c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83957c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x839580: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x839580: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x839584: r9 = _selectionGestureDetectorBuilder
    //     0x839584: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4bd10] Field <ExtendedTextFieldState._selectionGestureDetectorBuilder@479054530>: late (offset: 0x34)
    //     0x839588: ldr             x9, [x9, #0xd10]
    // 0x83958c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x83958c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x839590: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x839590: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x839594: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x839594: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x839598: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x839598: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ renderEditable(/* No info */) {
    // ** addr: 0x839ff0, size: 0xb4
    // 0x839ff0: EnterFrame
    //     0x839ff0: stp             fp, lr, [SP, #-0x10]!
    //     0x839ff4: mov             fp, SP
    // 0x839ff8: AllocStack(0x8)
    //     0x839ff8: sub             SP, SP, #8
    // 0x839ffc: CheckStackOverflow
    //     0x839ffc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83a000: cmp             SP, x16
    //     0x83a004: b.ls            #0x83a094
    // 0x83a008: ldr             x0, [fp, #0x10]
    // 0x83a00c: LoadField: r1 = r0->field_3b
    //     0x83a00c: ldur            w1, [x0, #0x3b]
    // 0x83a010: DecompressPointer r1
    //     0x83a010: add             x1, x1, HEAP, lsl #32
    // 0x83a014: SaveReg r1
    //     0x83a014: str             x1, [SP, #-8]!
    // 0x83a018: r0 = currentState()
    //     0x83a018: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x83a01c: add             SP, SP, #8
    // 0x83a020: cmp             w0, NULL
    // 0x83a024: b.eq            #0x83a09c
    // 0x83a028: LoadField: r1 = r0->field_2b
    //     0x83a028: ldur            w1, [x0, #0x2b]
    // 0x83a02c: DecompressPointer r1
    //     0x83a02c: add             x1, x1, HEAP, lsl #32
    // 0x83a030: SaveReg r1
    //     0x83a030: str             x1, [SP, #-8]!
    // 0x83a034: r0 = _currentElement()
    //     0x83a034: bl              #0x5093d8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0x83a038: add             SP, SP, #8
    // 0x83a03c: cmp             w0, NULL
    // 0x83a040: b.eq            #0x83a0a0
    // 0x83a044: SaveReg r0
    //     0x83a044: str             x0, [SP, #-8]!
    // 0x83a048: r0 = findRenderObject()
    //     0x83a048: bl              #0x51ed34  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0x83a04c: add             SP, SP, #8
    // 0x83a050: mov             x3, x0
    // 0x83a054: r2 = Null
    //     0x83a054: mov             x2, NULL
    // 0x83a058: r1 = Null
    //     0x83a058: mov             x1, NULL
    // 0x83a05c: stur            x3, [fp, #-8]
    // 0x83a060: r4 = LoadClassIdInstr(r0)
    //     0x83a060: ldur            x4, [x0, #-1]
    //     0x83a064: ubfx            x4, x4, #0xc, #0x14
    // 0x83a068: cmp             x4, #0x9e9
    // 0x83a06c: b.eq            #0x83a084
    // 0x83a070: r8 = ExtendedRenderEditable
    //     0x83a070: add             x8, PP, #0x37, lsl #12  ; [pp+0x37300] Type: ExtendedRenderEditable
    //     0x83a074: ldr             x8, [x8, #0x300]
    // 0x83a078: r3 = Null
    //     0x83a078: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4bdd0] Null
    //     0x83a07c: ldr             x3, [x3, #0xdd0]
    // 0x83a080: r0 = DefaultTypeTest()
    //     0x83a080: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x83a084: ldur            x0, [fp, #-8]
    // 0x83a088: LeaveFrame
    //     0x83a088: mov             SP, fp
    //     0x83a08c: ldp             fp, lr, [SP], #0x10
    // 0x83a090: ret
    //     0x83a090: ret             
    // 0x83a094: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83a094: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83a098: b               #0x83a008
    // 0x83a09c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83a09c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83a0a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83a0a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ selectionEnabled(/* No info */) {
    // ** addr: 0x83a0a4, size: 0x34
    // 0x83a0a4: EnterFrame
    //     0x83a0a4: stp             fp, lr, [SP, #-0x10]!
    //     0x83a0a8: mov             fp, SP
    // 0x83a0ac: ldr             x1, [fp, #0x10]
    // 0x83a0b0: LoadField: r2 = r1->field_b
    //     0x83a0b0: ldur            w2, [x1, #0xb]
    // 0x83a0b4: DecompressPointer r2
    //     0x83a0b4: add             x2, x2, HEAP, lsl #32
    // 0x83a0b8: cmp             w2, NULL
    // 0x83a0bc: b.eq            #0x83a0d4
    // 0x83a0c0: LoadField: r0 = r2->field_bb
    //     0x83a0c0: ldur            w0, [x2, #0xbb]
    // 0x83a0c4: DecompressPointer r0
    //     0x83a0c4: add             x0, x0, HEAP, lsl #32
    // 0x83a0c8: LeaveFrame
    //     0x83a0c8: mov             SP, fp
    //     0x83a0cc: ldp             fp, lr, [SP], #0x10
    // 0x83a0d0: ret
    //     0x83a0d0: ret             
    // 0x83a0d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83a0d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _hasError(/* No info */) {
    // ** addr: 0x83cc14, size: 0x6c
    // 0x83cc14: EnterFrame
    //     0x83cc14: stp             fp, lr, [SP, #-0x10]!
    //     0x83cc18: mov             fp, SP
    // 0x83cc1c: CheckStackOverflow
    //     0x83cc1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83cc20: cmp             SP, x16
    //     0x83cc24: b.ls            #0x83cc74
    // 0x83cc28: ldr             x0, [fp, #0x10]
    // 0x83cc2c: LoadField: r1 = r0->field_b
    //     0x83cc2c: ldur            w1, [x0, #0xb]
    // 0x83cc30: DecompressPointer r1
    //     0x83cc30: add             x1, x1, HEAP, lsl #32
    // 0x83cc34: cmp             w1, NULL
    // 0x83cc38: b.eq            #0x83cc7c
    // 0x83cc3c: LoadField: r2 = r1->field_1f
    //     0x83cc3c: ldur            w2, [x1, #0x1f]
    // 0x83cc40: DecompressPointer r2
    //     0x83cc40: add             x2, x2, HEAP, lsl #32
    // 0x83cc44: LoadField: r1 = r2->field_3b
    //     0x83cc44: ldur            w1, [x2, #0x3b]
    // 0x83cc48: DecompressPointer r1
    //     0x83cc48: add             x1, x1, HEAP, lsl #32
    // 0x83cc4c: cmp             w1, NULL
    // 0x83cc50: b.eq            #0x83cc5c
    // 0x83cc54: r0 = true
    //     0x83cc54: add             x0, NULL, #0x20  ; true
    // 0x83cc58: b               #0x83cc68
    // 0x83cc5c: SaveReg r0
    //     0x83cc5c: str             x0, [SP, #-8]!
    // 0x83cc60: r0 = _hasIntrinsicError()
    //     0x83cc60: bl              #0x83cc80  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_hasIntrinsicError
    // 0x83cc64: add             SP, SP, #8
    // 0x83cc68: LeaveFrame
    //     0x83cc68: mov             SP, fp
    //     0x83cc6c: ldp             fp, lr, [SP], #0x10
    // 0x83cc70: ret
    //     0x83cc70: ret             
    // 0x83cc74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83cc74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83cc78: b               #0x83cc28
    // 0x83cc7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83cc7c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _hasIntrinsicError(/* No info */) {
    // ** addr: 0x83cc80, size: 0xe4
    // 0x83cc80: EnterFrame
    //     0x83cc80: stp             fp, lr, [SP, #-0x10]!
    //     0x83cc84: mov             fp, SP
    // 0x83cc88: CheckStackOverflow
    //     0x83cc88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83cc8c: cmp             SP, x16
    //     0x83cc90: b.ls            #0x83cd50
    // 0x83cc94: ldr             x0, [fp, #0x10]
    // 0x83cc98: LoadField: r1 = r0->field_b
    //     0x83cc98: ldur            w1, [x0, #0xb]
    // 0x83cc9c: DecompressPointer r1
    //     0x83cc9c: add             x1, x1, HEAP, lsl #32
    // 0x83cca0: cmp             w1, NULL
    // 0x83cca4: b.eq            #0x83cd58
    // 0x83cca8: LoadField: r2 = r1->field_77
    //     0x83cca8: ldur            w2, [x1, #0x77]
    // 0x83ccac: DecompressPointer r2
    //     0x83ccac: add             x2, x2, HEAP, lsl #32
    // 0x83ccb0: cmp             w2, NULL
    // 0x83ccb4: b.eq            #0x83cd40
    // 0x83ccb8: r3 = LoadInt32Instr(r2)
    //     0x83ccb8: sbfx            x3, x2, #1, #0x1f
    // 0x83ccbc: cmp             x3, #0
    // 0x83ccc0: b.le            #0x83cd40
    // 0x83ccc4: LoadField: r2 = r1->field_17
    //     0x83ccc4: ldur            w2, [x1, #0x17]
    // 0x83ccc8: DecompressPointer r2
    //     0x83ccc8: add             x2, x2, HEAP, lsl #32
    // 0x83cccc: LoadField: r1 = r2->field_27
    //     0x83cccc: ldur            w1, [x2, #0x27]
    // 0x83ccd0: DecompressPointer r1
    //     0x83ccd0: add             x1, x1, HEAP, lsl #32
    // 0x83ccd4: LoadField: r2 = r1->field_7
    //     0x83ccd4: ldur            w2, [x1, #7]
    // 0x83ccd8: DecompressPointer r2
    //     0x83ccd8: add             x2, x2, HEAP, lsl #32
    // 0x83ccdc: SaveReg r2
    //     0x83ccdc: str             x2, [SP, #-8]!
    // 0x83cce0: r0 = StringCharacters.characters()
    //     0x83cce0: bl              #0x5254a4  ; [package:characters/src/extensions.dart] ::StringCharacters.characters
    // 0x83cce4: add             SP, SP, #8
    // 0x83cce8: SaveReg r0
    //     0x83cce8: str             x0, [SP, #-8]!
    // 0x83ccec: r0 = length()
    //     0x83ccec: bl              #0x6fd6e8  ; [package:characters/src/characters_impl.dart] StringCharacters::length
    // 0x83ccf0: add             SP, SP, #8
    // 0x83ccf4: ldr             x1, [fp, #0x10]
    // 0x83ccf8: LoadField: r2 = r1->field_b
    //     0x83ccf8: ldur            w2, [x1, #0xb]
    // 0x83ccfc: DecompressPointer r2
    //     0x83ccfc: add             x2, x2, HEAP, lsl #32
    // 0x83cd00: cmp             w2, NULL
    // 0x83cd04: b.eq            #0x83cd5c
    // 0x83cd08: LoadField: r1 = r2->field_77
    //     0x83cd08: ldur            w1, [x2, #0x77]
    // 0x83cd0c: DecompressPointer r1
    //     0x83cd0c: add             x1, x1, HEAP, lsl #32
    // 0x83cd10: cmp             w1, NULL
    // 0x83cd14: b.eq            #0x83cd60
    // 0x83cd18: r2 = LoadInt32Instr(r0)
    //     0x83cd18: sbfx            x2, x0, #1, #0x1f
    //     0x83cd1c: tbz             w0, #0, #0x83cd24
    //     0x83cd20: ldur            x2, [x0, #7]
    // 0x83cd24: r3 = LoadInt32Instr(r1)
    //     0x83cd24: sbfx            x3, x1, #1, #0x1f
    // 0x83cd28: cmp             x2, x3
    // 0x83cd2c: r16 = true
    //     0x83cd2c: add             x16, NULL, #0x20  ; true
    // 0x83cd30: r17 = false
    //     0x83cd30: add             x17, NULL, #0x30  ; false
    // 0x83cd34: csel            x1, x16, x17, gt
    // 0x83cd38: mov             x0, x1
    // 0x83cd3c: b               #0x83cd44
    // 0x83cd40: r0 = false
    //     0x83cd40: add             x0, NULL, #0x30  ; false
    // 0x83cd44: LeaveFrame
    //     0x83cd44: mov             SP, fp
    //     0x83cd48: ldp             fp, lr, [SP], #0x10
    // 0x83cd4c: ret
    //     0x83cd4c: ret             
    // 0x83cd50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83cd50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83cd54: b               #0x83cc94
    // 0x83cd58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83cd58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83cd5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83cd5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83cd60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83cd60: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _effectiveMaxLengthEnforcement(/* No info */) {
    // ** addr: 0x83d4b8, size: 0xa4
    // 0x83d4b8: EnterFrame
    //     0x83d4b8: stp             fp, lr, [SP, #-0x10]!
    //     0x83d4bc: mov             fp, SP
    // 0x83d4c0: CheckStackOverflow
    //     0x83d4c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83d4c4: cmp             SP, x16
    //     0x83d4c8: b.ls            #0x83d54c
    // 0x83d4cc: ldr             x0, [fp, #0x10]
    // 0x83d4d0: LoadField: r1 = r0->field_b
    //     0x83d4d0: ldur            w1, [x0, #0xb]
    // 0x83d4d4: DecompressPointer r1
    //     0x83d4d4: add             x1, x1, HEAP, lsl #32
    // 0x83d4d8: cmp             w1, NULL
    // 0x83d4dc: b.eq            #0x83d554
    // 0x83d4e0: LoadField: r1 = r0->field_f
    //     0x83d4e0: ldur            w1, [x0, #0xf]
    // 0x83d4e4: DecompressPointer r1
    //     0x83d4e4: add             x1, x1, HEAP, lsl #32
    // 0x83d4e8: cmp             w1, NULL
    // 0x83d4ec: b.eq            #0x83d558
    // 0x83d4f0: SaveReg r1
    //     0x83d4f0: str             x1, [SP, #-8]!
    // 0x83d4f4: r0 = of()
    //     0x83d4f4: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x83d4f8: add             SP, SP, #8
    // 0x83d4fc: LoadField: r1 = r0->field_1f
    //     0x83d4fc: ldur            w1, [x0, #0x1f]
    // 0x83d500: DecompressPointer r1
    //     0x83d500: add             x1, x1, HEAP, lsl #32
    // 0x83d504: LoadField: r2 = r1->field_7
    //     0x83d504: ldur            x2, [x1, #7]
    // 0x83d508: cmp             x2, #2
    // 0x83d50c: b.gt            #0x83d524
    // 0x83d510: cmp             x2, #1
    // 0x83d514: b.gt            #0x83d52c
    // 0x83d518: cmp             x2, #0
    // 0x83d51c: b.gt            #0x83d52c
    // 0x83d520: b               #0x83d538
    // 0x83d524: cmp             x2, #4
    // 0x83d528: b.gt            #0x83d538
    // 0x83d52c: r0 = Instance_MaxLengthEnforcement
    //     0x83d52c: add             x0, PP, #0x2d, lsl #12  ; [pp+0x2df70] Obj!MaxLengthEnforcement@b64231
    //     0x83d530: ldr             x0, [x0, #0xf70]
    // 0x83d534: b               #0x83d540
    // 0x83d538: r0 = Instance_MaxLengthEnforcement
    //     0x83d538: add             x0, PP, #0x2d, lsl #12  ; [pp+0x2df78] Obj!MaxLengthEnforcement@b64211
    //     0x83d53c: ldr             x0, [x0, #0xf78]
    // 0x83d540: LeaveFrame
    //     0x83d540: mov             SP, fp
    //     0x83d544: ldp             fp, lr, [SP], #0x10
    // 0x83d548: ret
    //     0x83d548: ret             
    // 0x83d54c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83d54c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83d550: b               #0x83d4cc
    // 0x83d554: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83d554: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83d558: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83d558: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, PointerExitEvent) {
    // ** addr: 0x83d5c0, size: 0x4c
    // 0x83d5c0: EnterFrame
    //     0x83d5c0: stp             fp, lr, [SP, #-0x10]!
    //     0x83d5c4: mov             fp, SP
    // 0x83d5c8: ldr             x0, [fp, #0x18]
    // 0x83d5cc: LoadField: r1 = r0->field_17
    //     0x83d5cc: ldur            w1, [x0, #0x17]
    // 0x83d5d0: DecompressPointer r1
    //     0x83d5d0: add             x1, x1, HEAP, lsl #32
    // 0x83d5d4: CheckStackOverflow
    //     0x83d5d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83d5d8: cmp             SP, x16
    //     0x83d5dc: b.ls            #0x83d604
    // 0x83d5e0: LoadField: r0 = r1->field_f
    //     0x83d5e0: ldur            w0, [x1, #0xf]
    // 0x83d5e4: DecompressPointer r0
    //     0x83d5e4: add             x0, x0, HEAP, lsl #32
    // 0x83d5e8: r16 = false
    //     0x83d5e8: add             x16, NULL, #0x30  ; false
    // 0x83d5ec: stp             x16, x0, [SP, #-0x10]!
    // 0x83d5f0: r0 = _handleHover()
    //     0x83d5f0: bl              #0x83d60c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_handleHover
    // 0x83d5f4: add             SP, SP, #0x10
    // 0x83d5f8: LeaveFrame
    //     0x83d5f8: mov             SP, fp
    //     0x83d5fc: ldp             fp, lr, [SP], #0x10
    // 0x83d600: ret
    //     0x83d600: ret             
    // 0x83d604: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83d604: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83d608: b               #0x83d5e0
  }
  _ _handleHover(/* No info */) {
    // ** addr: 0x83d60c, size: 0x78
    // 0x83d60c: EnterFrame
    //     0x83d60c: stp             fp, lr, [SP, #-0x10]!
    //     0x83d610: mov             fp, SP
    // 0x83d614: CheckStackOverflow
    //     0x83d614: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83d618: cmp             SP, x16
    //     0x83d61c: b.ls            #0x83d67c
    // 0x83d620: r1 = 2
    //     0x83d620: mov             x1, #2
    // 0x83d624: r0 = AllocateContext()
    //     0x83d624: bl              #0xd68aa4  ; AllocateContextStub
    // 0x83d628: mov             x1, x0
    // 0x83d62c: ldr             x0, [fp, #0x18]
    // 0x83d630: StoreField: r1->field_f = r0
    //     0x83d630: stur            w0, [x1, #0xf]
    // 0x83d634: ldr             x2, [fp, #0x10]
    // 0x83d638: StoreField: r1->field_13 = r2
    //     0x83d638: stur            w2, [x1, #0x13]
    // 0x83d63c: LoadField: r3 = r0->field_2b
    //     0x83d63c: ldur            w3, [x0, #0x2b]
    // 0x83d640: DecompressPointer r3
    //     0x83d640: add             x3, x3, HEAP, lsl #32
    // 0x83d644: cmp             w2, w3
    // 0x83d648: b.eq            #0x83d66c
    // 0x83d64c: mov             x2, x1
    // 0x83d650: r1 = Function '<anonymous closure>':.
    //     0x83d650: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bd18] AnonymousClosure: (0x83d684), in [package:flutter/src/material/text_field.dart] _TextFieldState::_handleHover (0x83d6cc)
    //     0x83d654: ldr             x1, [x1, #0xd18]
    // 0x83d658: r0 = AllocateClosure()
    //     0x83d658: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x83d65c: ldr             x16, [fp, #0x18]
    // 0x83d660: stp             x0, x16, [SP, #-0x10]!
    // 0x83d664: r0 = setState()
    //     0x83d664: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x83d668: add             SP, SP, #0x10
    // 0x83d66c: r0 = Null
    //     0x83d66c: mov             x0, NULL
    // 0x83d670: LeaveFrame
    //     0x83d670: mov             SP, fp
    //     0x83d674: ldp             fp, lr, [SP], #0x10
    // 0x83d678: ret
    //     0x83d678: ret             
    // 0x83d67c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83d67c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83d680: b               #0x83d620
  }
  [closure] void <anonymous closure>(dynamic, PointerEnterEvent) {
    // ** addr: 0x83d744, size: 0x4c
    // 0x83d744: EnterFrame
    //     0x83d744: stp             fp, lr, [SP, #-0x10]!
    //     0x83d748: mov             fp, SP
    // 0x83d74c: ldr             x0, [fp, #0x18]
    // 0x83d750: LoadField: r1 = r0->field_17
    //     0x83d750: ldur            w1, [x0, #0x17]
    // 0x83d754: DecompressPointer r1
    //     0x83d754: add             x1, x1, HEAP, lsl #32
    // 0x83d758: CheckStackOverflow
    //     0x83d758: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83d75c: cmp             SP, x16
    //     0x83d760: b.ls            #0x83d788
    // 0x83d764: LoadField: r0 = r1->field_f
    //     0x83d764: ldur            w0, [x1, #0xf]
    // 0x83d768: DecompressPointer r0
    //     0x83d768: add             x0, x0, HEAP, lsl #32
    // 0x83d76c: r16 = true
    //     0x83d76c: add             x16, NULL, #0x20  ; true
    // 0x83d770: stp             x16, x0, [SP, #-0x10]!
    // 0x83d774: r0 = _handleHover()
    //     0x83d774: bl              #0x83d60c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_handleHover
    // 0x83d778: add             SP, SP, #0x10
    // 0x83d77c: LeaveFrame
    //     0x83d77c: mov             SP, fp
    //     0x83d780: ldp             fp, lr, [SP], #0x10
    // 0x83d784: ret
    //     0x83d784: ret             
    // 0x83d788: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83d788: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83d78c: b               #0x83d764
  }
  [closure] Semantics <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x83d790, size: 0xf0
    // 0x83d790: EnterFrame
    //     0x83d790: stp             fp, lr, [SP, #-0x10]!
    //     0x83d794: mov             fp, SP
    // 0x83d798: AllocStack(0x20)
    //     0x83d798: sub             SP, SP, #0x20
    // 0x83d79c: SetupParameters()
    //     0x83d79c: ldr             x0, [fp, #0x20]
    //     0x83d7a0: ldur            w2, [x0, #0x17]
    //     0x83d7a4: add             x2, x2, HEAP, lsl #32
    //     0x83d7a8: stur            x2, [fp, #-0x10]
    // 0x83d7ac: CheckStackOverflow
    //     0x83d7ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83d7b0: cmp             SP, x16
    //     0x83d7b4: b.ls            #0x83d874
    // 0x83d7b8: LoadField: r0 = r2->field_1f
    //     0x83d7b8: ldur            w0, [x2, #0x1f]
    // 0x83d7bc: DecompressPointer r0
    //     0x83d7bc: add             x0, x0, HEAP, lsl #32
    // 0x83d7c0: stur            x0, [fp, #-8]
    // 0x83d7c4: LoadField: r1 = r2->field_f
    //     0x83d7c4: ldur            w1, [x2, #0xf]
    // 0x83d7c8: DecompressPointer r1
    //     0x83d7c8: add             x1, x1, HEAP, lsl #32
    // 0x83d7cc: SaveReg r1
    //     0x83d7cc: str             x1, [SP, #-8]!
    // 0x83d7d0: r0 = _currentLength()
    //     0x83d7d0: bl              #0x83d880  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_currentLength
    // 0x83d7d4: add             SP, SP, #8
    // 0x83d7d8: mov             x3, x0
    // 0x83d7dc: ldur            x2, [fp, #-0x10]
    // 0x83d7e0: LoadField: r0 = r2->field_f
    //     0x83d7e0: ldur            w0, [x2, #0xf]
    // 0x83d7e4: DecompressPointer r0
    //     0x83d7e4: add             x0, x0, HEAP, lsl #32
    // 0x83d7e8: LoadField: r1 = r0->field_b
    //     0x83d7e8: ldur            w1, [x0, #0xb]
    // 0x83d7ec: DecompressPointer r1
    //     0x83d7ec: add             x1, x1, HEAP, lsl #32
    // 0x83d7f0: cmp             w1, NULL
    // 0x83d7f4: b.eq            #0x83d87c
    // 0x83d7f8: LoadField: r4 = r2->field_1b
    //     0x83d7f8: ldur            w4, [x2, #0x1b]
    // 0x83d7fc: DecompressPointer r4
    //     0x83d7fc: add             x4, x4, HEAP, lsl #32
    // 0x83d800: stur            x4, [fp, #-0x20]
    // 0x83d804: r0 = BoxInt64Instr(r3)
    //     0x83d804: sbfiz           x0, x3, #1, #0x1f
    //     0x83d808: cmp             x3, x0, asr #1
    //     0x83d80c: b.eq            #0x83d818
    //     0x83d810: bl              #0xd69bb8
    //     0x83d814: stur            x3, [x0, #7]
    // 0x83d818: stur            x0, [fp, #-0x18]
    // 0x83d81c: r0 = Semantics()
    //     0x83d81c: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0x83d820: ldur            x2, [fp, #-0x10]
    // 0x83d824: r1 = Function '<anonymous closure>':.
    //     0x83d824: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bd20] AnonymousClosure: (0x83d900), in [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::build (0x838588)
    //     0x83d828: ldr             x1, [x1, #0xd20]
    // 0x83d82c: stur            x0, [fp, #-0x10]
    // 0x83d830: r0 = AllocateClosure()
    //     0x83d830: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x83d834: ldur            x16, [fp, #-0x10]
    // 0x83d838: ldur            lr, [fp, #-8]
    // 0x83d83c: stp             lr, x16, [SP, #-0x10]!
    // 0x83d840: ldur            x16, [fp, #-0x18]
    // 0x83d844: stp             x0, x16, [SP, #-0x10]!
    // 0x83d848: ldur            x16, [fp, #-0x20]
    // 0x83d84c: ldr             lr, [fp, #0x10]
    // 0x83d850: stp             lr, x16, [SP, #-0x10]!
    // 0x83d854: r4 = const [0, 0x6, 0x6, 0x1, child, 0x5, currentValueLength, 0x2, maxValueLength, 0x1, onDidGainAccessibilityFocus, 0x4, onTap, 0x3, null]
    //     0x83d854: add             x4, PP, #0x2d, lsl #12  ; [pp+0x2dd38] List(15) [0, 0x6, 0x6, 0x1, "child", 0x5, "currentValueLength", 0x2, "maxValueLength", 0x1, "onDidGainAccessibilityFocus", 0x4, "onTap", 0x3, Null]
    //     0x83d858: ldr             x4, [x4, #0xd38]
    // 0x83d85c: r0 = Semantics()
    //     0x83d85c: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x83d860: add             SP, SP, #0x30
    // 0x83d864: ldur            x0, [fp, #-0x10]
    // 0x83d868: LeaveFrame
    //     0x83d868: mov             SP, fp
    //     0x83d86c: ldp             fp, lr, [SP], #0x10
    // 0x83d870: ret
    //     0x83d870: ret             
    // 0x83d874: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83d874: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83d878: b               #0x83d7b8
    // 0x83d87c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83d87c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _currentLength(/* No info */) {
    // ** addr: 0x83d880, size: 0x80
    // 0x83d880: EnterFrame
    //     0x83d880: stp             fp, lr, [SP, #-0x10]!
    //     0x83d884: mov             fp, SP
    // 0x83d888: CheckStackOverflow
    //     0x83d888: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83d88c: cmp             SP, x16
    //     0x83d890: b.ls            #0x83d8f4
    // 0x83d894: ldr             x0, [fp, #0x10]
    // 0x83d898: LoadField: r1 = r0->field_b
    //     0x83d898: ldur            w1, [x0, #0xb]
    // 0x83d89c: DecompressPointer r1
    //     0x83d89c: add             x1, x1, HEAP, lsl #32
    // 0x83d8a0: cmp             w1, NULL
    // 0x83d8a4: b.eq            #0x83d8fc
    // 0x83d8a8: LoadField: r0 = r1->field_17
    //     0x83d8a8: ldur            w0, [x1, #0x17]
    // 0x83d8ac: DecompressPointer r0
    //     0x83d8ac: add             x0, x0, HEAP, lsl #32
    // 0x83d8b0: LoadField: r1 = r0->field_27
    //     0x83d8b0: ldur            w1, [x0, #0x27]
    // 0x83d8b4: DecompressPointer r1
    //     0x83d8b4: add             x1, x1, HEAP, lsl #32
    // 0x83d8b8: LoadField: r0 = r1->field_7
    //     0x83d8b8: ldur            w0, [x1, #7]
    // 0x83d8bc: DecompressPointer r0
    //     0x83d8bc: add             x0, x0, HEAP, lsl #32
    // 0x83d8c0: SaveReg r0
    //     0x83d8c0: str             x0, [SP, #-8]!
    // 0x83d8c4: r0 = StringCharacters.characters()
    //     0x83d8c4: bl              #0x5254a4  ; [package:characters/src/extensions.dart] ::StringCharacters.characters
    // 0x83d8c8: add             SP, SP, #8
    // 0x83d8cc: SaveReg r0
    //     0x83d8cc: str             x0, [SP, #-8]!
    // 0x83d8d0: r0 = length()
    //     0x83d8d0: bl              #0x6fd6e8  ; [package:characters/src/characters_impl.dart] StringCharacters::length
    // 0x83d8d4: add             SP, SP, #8
    // 0x83d8d8: r1 = LoadInt32Instr(r0)
    //     0x83d8d8: sbfx            x1, x0, #1, #0x1f
    //     0x83d8dc: tbz             w0, #0, #0x83d8e4
    //     0x83d8e0: ldur            x1, [x0, #7]
    // 0x83d8e4: mov             x0, x1
    // 0x83d8e8: LeaveFrame
    //     0x83d8e8: mov             SP, fp
    //     0x83d8ec: ldp             fp, lr, [SP], #0x10
    // 0x83d8f0: ret
    //     0x83d8f0: ret             
    // 0x83d8f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83d8f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83d8f8: b               #0x83d894
    // 0x83d8fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83d8fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x83d900, size: 0xfc
    // 0x83d900: EnterFrame
    //     0x83d900: stp             fp, lr, [SP, #-0x10]!
    //     0x83d904: mov             fp, SP
    // 0x83d908: AllocStack(0x18)
    //     0x83d908: sub             SP, SP, #0x18
    // 0x83d90c: SetupParameters()
    //     0x83d90c: ldr             x0, [fp, #0x10]
    //     0x83d910: ldur            w1, [x0, #0x17]
    //     0x83d914: add             x1, x1, HEAP, lsl #32
    //     0x83d918: stur            x1, [fp, #-0x18]
    // 0x83d91c: CheckStackOverflow
    //     0x83d91c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83d920: cmp             SP, x16
    //     0x83d924: b.ls            #0x83d9f0
    // 0x83d928: LoadField: r0 = r1->field_f
    //     0x83d928: ldur            w0, [x1, #0xf]
    // 0x83d92c: DecompressPointer r0
    //     0x83d92c: add             x0, x0, HEAP, lsl #32
    // 0x83d930: LoadField: r2 = r0->field_b
    //     0x83d930: ldur            w2, [x0, #0xb]
    // 0x83d934: DecompressPointer r2
    //     0x83d934: add             x2, x2, HEAP, lsl #32
    // 0x83d938: cmp             w2, NULL
    // 0x83d93c: b.eq            #0x83d9f8
    // 0x83d940: LoadField: r0 = r2->field_17
    //     0x83d940: ldur            w0, [x2, #0x17]
    // 0x83d944: DecompressPointer r0
    //     0x83d944: add             x0, x0, HEAP, lsl #32
    // 0x83d948: stur            x0, [fp, #-0x10]
    // 0x83d94c: LoadField: r2 = r0->field_27
    //     0x83d94c: ldur            w2, [x0, #0x27]
    // 0x83d950: DecompressPointer r2
    //     0x83d950: add             x2, x2, HEAP, lsl #32
    // 0x83d954: LoadField: r3 = r2->field_b
    //     0x83d954: ldur            w3, [x2, #0xb]
    // 0x83d958: DecompressPointer r3
    //     0x83d958: add             x3, x3, HEAP, lsl #32
    // 0x83d95c: LoadField: r4 = r3->field_7
    //     0x83d95c: ldur            x4, [x3, #7]
    // 0x83d960: tbnz            x4, #0x3f, #0x83d974
    // 0x83d964: LoadField: r4 = r3->field_f
    //     0x83d964: ldur            x4, [x3, #0xf]
    // 0x83d968: tbnz            x4, #0x3f, #0x83d974
    // 0x83d96c: mov             x0, x1
    // 0x83d970: b               #0x83d9cc
    // 0x83d974: LoadField: r3 = r2->field_7
    //     0x83d974: ldur            w3, [x2, #7]
    // 0x83d978: DecompressPointer r3
    //     0x83d978: add             x3, x3, HEAP, lsl #32
    // 0x83d97c: LoadField: r2 = r3->field_7
    //     0x83d97c: ldur            w2, [x3, #7]
    // 0x83d980: DecompressPointer r2
    //     0x83d980: add             x2, x2, HEAP, lsl #32
    // 0x83d984: stur            x2, [fp, #-8]
    // 0x83d988: r0 = TextSelection()
    //     0x83d988: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x83d98c: mov             x1, x0
    // 0x83d990: r0 = Instance_TextAffinity
    //     0x83d990: ldr             x0, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x83d994: StoreField: r1->field_27 = r0
    //     0x83d994: stur            w0, [x1, #0x27]
    // 0x83d998: ldur            x0, [fp, #-8]
    // 0x83d99c: r2 = LoadInt32Instr(r0)
    //     0x83d99c: sbfx            x2, x0, #1, #0x1f
    // 0x83d9a0: StoreField: r1->field_17 = r2
    //     0x83d9a0: stur            x2, [x1, #0x17]
    // 0x83d9a4: StoreField: r1->field_1f = r2
    //     0x83d9a4: stur            x2, [x1, #0x1f]
    // 0x83d9a8: r0 = false
    //     0x83d9a8: add             x0, NULL, #0x30  ; false
    // 0x83d9ac: StoreField: r1->field_2b = r0
    //     0x83d9ac: stur            w0, [x1, #0x2b]
    // 0x83d9b0: StoreField: r1->field_7 = r2
    //     0x83d9b0: stur            x2, [x1, #7]
    // 0x83d9b4: StoreField: r1->field_f = r2
    //     0x83d9b4: stur            x2, [x1, #0xf]
    // 0x83d9b8: ldur            x16, [fp, #-0x10]
    // 0x83d9bc: stp             x1, x16, [SP, #-0x10]!
    // 0x83d9c0: r0 = selection=()
    //     0x83d9c0: bl              #0x79a43c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::selection=
    // 0x83d9c4: add             SP, SP, #0x10
    // 0x83d9c8: ldur            x0, [fp, #-0x18]
    // 0x83d9cc: LoadField: r1 = r0->field_f
    //     0x83d9cc: ldur            w1, [x0, #0xf]
    // 0x83d9d0: DecompressPointer r1
    //     0x83d9d0: add             x1, x1, HEAP, lsl #32
    // 0x83d9d4: SaveReg r1
    //     0x83d9d4: str             x1, [SP, #-8]!
    // 0x83d9d8: r0 = _requestKeyboard()
    //     0x83d9d8: bl              #0x83d9fc  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_requestKeyboard
    // 0x83d9dc: add             SP, SP, #8
    // 0x83d9e0: r0 = Null
    //     0x83d9e0: mov             x0, NULL
    // 0x83d9e4: LeaveFrame
    //     0x83d9e4: mov             SP, fp
    //     0x83d9e8: ldp             fp, lr, [SP], #0x10
    // 0x83d9ec: ret
    //     0x83d9ec: ret             
    // 0x83d9f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83d9f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83d9f4: b               #0x83d928
    // 0x83d9f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83d9f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _requestKeyboard(/* No info */) {
    // ** addr: 0x83d9fc, size: 0x50
    // 0x83d9fc: EnterFrame
    //     0x83d9fc: stp             fp, lr, [SP, #-0x10]!
    //     0x83da00: mov             fp, SP
    // 0x83da04: CheckStackOverflow
    //     0x83da04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83da08: cmp             SP, x16
    //     0x83da0c: b.ls            #0x83da44
    // 0x83da10: ldr             x16, [fp, #0x10]
    // 0x83da14: SaveReg r16
    //     0x83da14: str             x16, [SP, #-8]!
    // 0x83da18: r0 = _editableText()
    //     0x83da18: bl              #0x83da94  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_editableText
    // 0x83da1c: add             SP, SP, #8
    // 0x83da20: cmp             w0, NULL
    // 0x83da24: b.eq            #0x83da34
    // 0x83da28: SaveReg r0
    //     0x83da28: str             x0, [SP, #-8]!
    // 0x83da2c: r0 = requestKeyboard()
    //     0x83da2c: bl              #0x7ac2d4  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableTextState::requestKeyboard
    // 0x83da30: add             SP, SP, #8
    // 0x83da34: r0 = Null
    //     0x83da34: mov             x0, NULL
    // 0x83da38: LeaveFrame
    //     0x83da38: mov             SP, fp
    //     0x83da3c: ldp             fp, lr, [SP], #0x10
    // 0x83da40: ret
    //     0x83da40: ret             
    // 0x83da44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83da44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83da48: b               #0x83da10
  }
  [closure] void _requestKeyboard(dynamic) {
    // ** addr: 0x83da4c, size: 0x48
    // 0x83da4c: EnterFrame
    //     0x83da4c: stp             fp, lr, [SP, #-0x10]!
    //     0x83da50: mov             fp, SP
    // 0x83da54: ldr             x0, [fp, #0x10]
    // 0x83da58: LoadField: r1 = r0->field_17
    //     0x83da58: ldur            w1, [x0, #0x17]
    // 0x83da5c: DecompressPointer r1
    //     0x83da5c: add             x1, x1, HEAP, lsl #32
    // 0x83da60: CheckStackOverflow
    //     0x83da60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83da64: cmp             SP, x16
    //     0x83da68: b.ls            #0x83da8c
    // 0x83da6c: LoadField: r0 = r1->field_f
    //     0x83da6c: ldur            w0, [x1, #0xf]
    // 0x83da70: DecompressPointer r0
    //     0x83da70: add             x0, x0, HEAP, lsl #32
    // 0x83da74: SaveReg r0
    //     0x83da74: str             x0, [SP, #-8]!
    // 0x83da78: r0 = _requestKeyboard()
    //     0x83da78: bl              #0x83d9fc  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_requestKeyboard
    // 0x83da7c: add             SP, SP, #8
    // 0x83da80: LeaveFrame
    //     0x83da80: mov             SP, fp
    //     0x83da84: ldp             fp, lr, [SP], #0x10
    // 0x83da88: ret
    //     0x83da88: ret             
    // 0x83da8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83da8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83da90: b               #0x83da6c
  }
  get _ _editableText(/* No info */) {
    // ** addr: 0x83da94, size: 0x40
    // 0x83da94: EnterFrame
    //     0x83da94: stp             fp, lr, [SP, #-0x10]!
    //     0x83da98: mov             fp, SP
    // 0x83da9c: CheckStackOverflow
    //     0x83da9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83daa0: cmp             SP, x16
    //     0x83daa4: b.ls            #0x83dacc
    // 0x83daa8: ldr             x0, [fp, #0x10]
    // 0x83daac: LoadField: r1 = r0->field_3b
    //     0x83daac: ldur            w1, [x0, #0x3b]
    // 0x83dab0: DecompressPointer r1
    //     0x83dab0: add             x1, x1, HEAP, lsl #32
    // 0x83dab4: SaveReg r1
    //     0x83dab4: str             x1, [SP, #-8]!
    // 0x83dab8: r0 = currentState()
    //     0x83dab8: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x83dabc: add             SP, SP, #8
    // 0x83dac0: LeaveFrame
    //     0x83dac0: mov             SP, fp
    //     0x83dac4: ldp             fp, lr, [SP], #0x10
    // 0x83dac8: ret
    //     0x83dac8: ret             
    // 0x83dacc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83dacc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83dad0: b               #0x83daa8
  }
  [closure] InputDecorator <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x83dad4, size: 0x148
    // 0x83dad4: EnterFrame
    //     0x83dad4: stp             fp, lr, [SP, #-0x10]!
    //     0x83dad8: mov             fp, SP
    // 0x83dadc: AllocStack(0x30)
    //     0x83dadc: sub             SP, SP, #0x30
    // 0x83dae0: SetupParameters()
    //     0x83dae0: ldr             x0, [fp, #0x20]
    //     0x83dae4: ldur            w1, [x0, #0x17]
    //     0x83dae8: add             x1, x1, HEAP, lsl #32
    //     0x83daec: stur            x1, [fp, #-8]
    // 0x83daf0: CheckStackOverflow
    //     0x83daf0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83daf4: cmp             SP, x16
    //     0x83daf8: b.ls            #0x83dc0c
    // 0x83dafc: LoadField: r0 = r1->field_f
    //     0x83dafc: ldur            w0, [x1, #0xf]
    // 0x83db00: DecompressPointer r0
    //     0x83db00: add             x0, x0, HEAP, lsl #32
    // 0x83db04: SaveReg r0
    //     0x83db04: str             x0, [SP, #-8]!
    // 0x83db08: r0 = _getEffectiveDecoration()
    //     0x83db08: bl              #0x83dc28  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_getEffectiveDecoration
    // 0x83db0c: add             SP, SP, #8
    // 0x83db10: mov             x1, x0
    // 0x83db14: ldur            x0, [fp, #-8]
    // 0x83db18: stur            x1, [fp, #-0x20]
    // 0x83db1c: LoadField: r2 = r0->field_f
    //     0x83db1c: ldur            w2, [x0, #0xf]
    // 0x83db20: DecompressPointer r2
    //     0x83db20: add             x2, x2, HEAP, lsl #32
    // 0x83db24: LoadField: r3 = r2->field_b
    //     0x83db24: ldur            w3, [x2, #0xb]
    // 0x83db28: DecompressPointer r3
    //     0x83db28: add             x3, x3, HEAP, lsl #32
    // 0x83db2c: cmp             w3, NULL
    // 0x83db30: b.eq            #0x83dc14
    // 0x83db34: LoadField: r4 = r3->field_2f
    //     0x83db34: ldur            w4, [x3, #0x2f]
    // 0x83db38: DecompressPointer r4
    //     0x83db38: add             x4, x4, HEAP, lsl #32
    // 0x83db3c: stur            x4, [fp, #-0x18]
    // 0x83db40: LoadField: r3 = r2->field_2b
    //     0x83db40: ldur            w3, [x2, #0x2b]
    // 0x83db44: DecompressPointer r3
    //     0x83db44: add             x3, x3, HEAP, lsl #32
    // 0x83db48: stur            x3, [fp, #-0x10]
    // 0x83db4c: LoadField: r2 = r0->field_17
    //     0x83db4c: ldur            w2, [x0, #0x17]
    // 0x83db50: DecompressPointer r2
    //     0x83db50: add             x2, x2, HEAP, lsl #32
    // 0x83db54: SaveReg r2
    //     0x83db54: str             x2, [SP, #-8]!
    // 0x83db58: r0 = hasFocus()
    //     0x83db58: bl              #0x6f8fe4  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0x83db5c: add             SP, SP, #8
    // 0x83db60: mov             x1, x0
    // 0x83db64: ldur            x0, [fp, #-8]
    // 0x83db68: stur            x1, [fp, #-0x30]
    // 0x83db6c: LoadField: r2 = r0->field_13
    //     0x83db6c: ldur            w2, [x0, #0x13]
    // 0x83db70: DecompressPointer r2
    //     0x83db70: add             x2, x2, HEAP, lsl #32
    // 0x83db74: LoadField: r3 = r2->field_27
    //     0x83db74: ldur            w3, [x2, #0x27]
    // 0x83db78: DecompressPointer r3
    //     0x83db78: add             x3, x3, HEAP, lsl #32
    // 0x83db7c: LoadField: r2 = r3->field_7
    //     0x83db7c: ldur            w2, [x3, #7]
    // 0x83db80: DecompressPointer r2
    //     0x83db80: add             x2, x2, HEAP, lsl #32
    // 0x83db84: LoadField: r3 = r2->field_7
    //     0x83db84: ldur            w3, [x2, #7]
    // 0x83db88: DecompressPointer r3
    //     0x83db88: add             x3, x3, HEAP, lsl #32
    // 0x83db8c: cbz             w3, #0x83db98
    // 0x83db90: r2 = false
    //     0x83db90: add             x2, NULL, #0x30  ; false
    // 0x83db94: b               #0x83db9c
    // 0x83db98: r2 = true
    //     0x83db98: add             x2, NULL, #0x20  ; true
    // 0x83db9c: stur            x2, [fp, #-0x28]
    // 0x83dba0: LoadField: r3 = r0->field_f
    //     0x83dba0: ldur            w3, [x0, #0xf]
    // 0x83dba4: DecompressPointer r3
    //     0x83dba4: add             x3, x3, HEAP, lsl #32
    // 0x83dba8: LoadField: r0 = r3->field_b
    //     0x83dba8: ldur            w0, [x3, #0xb]
    // 0x83dbac: DecompressPointer r0
    //     0x83dbac: add             x0, x0, HEAP, lsl #32
    // 0x83dbb0: cmp             w0, NULL
    // 0x83dbb4: b.eq            #0x83dc18
    // 0x83dbb8: r0 = InputDecorator()
    //     0x83dbb8: bl              #0x83dc1c  ; AllocateInputDecoratorStub -> InputDecorator (size=0x30)
    // 0x83dbbc: ldur            x1, [fp, #-0x20]
    // 0x83dbc0: StoreField: r0->field_b = r1
    //     0x83dbc0: stur            w1, [x0, #0xb]
    // 0x83dbc4: ldur            x1, [fp, #-0x18]
    // 0x83dbc8: StoreField: r0->field_f = r1
    //     0x83dbc8: stur            w1, [x0, #0xf]
    // 0x83dbcc: r1 = Instance_TextAlign
    //     0x83dbcc: add             x1, PP, #0x14, lsl #12  ; [pp+0x14fe8] Obj!TextAlign@b66f71
    //     0x83dbd0: ldr             x1, [x1, #0xfe8]
    // 0x83dbd4: StoreField: r0->field_13 = r1
    //     0x83dbd4: stur            w1, [x0, #0x13]
    // 0x83dbd8: ldur            x1, [fp, #-0x30]
    // 0x83dbdc: StoreField: r0->field_1b = r1
    //     0x83dbdc: stur            w1, [x0, #0x1b]
    // 0x83dbe0: ldur            x1, [fp, #-0x10]
    // 0x83dbe4: StoreField: r0->field_1f = r1
    //     0x83dbe4: stur            w1, [x0, #0x1f]
    // 0x83dbe8: r1 = false
    //     0x83dbe8: add             x1, NULL, #0x30  ; false
    // 0x83dbec: StoreField: r0->field_23 = r1
    //     0x83dbec: stur            w1, [x0, #0x23]
    // 0x83dbf0: ldur            x1, [fp, #-0x28]
    // 0x83dbf4: StoreField: r0->field_27 = r1
    //     0x83dbf4: stur            w1, [x0, #0x27]
    // 0x83dbf8: ldr             x1, [fp, #0x10]
    // 0x83dbfc: StoreField: r0->field_2b = r1
    //     0x83dbfc: stur            w1, [x0, #0x2b]
    // 0x83dc00: LeaveFrame
    //     0x83dc00: mov             SP, fp
    //     0x83dc04: ldp             fp, lr, [SP], #0x10
    // 0x83dc08: ret
    //     0x83dc08: ret             
    // 0x83dc0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83dc0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83dc10: b               #0x83dafc
    // 0x83dc14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83dc14: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83dc18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83dc18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getEffectiveDecoration(/* No info */) {
    // ** addr: 0x83dc28, size: 0x404
    // 0x83dc28: EnterFrame
    //     0x83dc28: stp             fp, lr, [SP, #-0x10]!
    //     0x83dc2c: mov             fp, SP
    // 0x83dc30: AllocStack(0x30)
    //     0x83dc30: sub             SP, SP, #0x30
    // 0x83dc34: CheckStackOverflow
    //     0x83dc34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83dc38: cmp             SP, x16
    //     0x83dc3c: b.ls            #0x83dff4
    // 0x83dc40: ldr             x0, [fp, #0x10]
    // 0x83dc44: LoadField: r1 = r0->field_f
    //     0x83dc44: ldur            w1, [x0, #0xf]
    // 0x83dc48: DecompressPointer r1
    //     0x83dc48: add             x1, x1, HEAP, lsl #32
    // 0x83dc4c: cmp             w1, NULL
    // 0x83dc50: b.eq            #0x83dffc
    // 0x83dc54: SaveReg r1
    //     0x83dc54: str             x1, [SP, #-8]!
    // 0x83dc58: r0 = of()
    //     0x83dc58: bl              #0x832f90  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0x83dc5c: add             SP, SP, #8
    // 0x83dc60: mov             x1, x0
    // 0x83dc64: ldr             x0, [fp, #0x10]
    // 0x83dc68: stur            x1, [fp, #-8]
    // 0x83dc6c: LoadField: r2 = r0->field_f
    //     0x83dc6c: ldur            w2, [x0, #0xf]
    // 0x83dc70: DecompressPointer r2
    //     0x83dc70: add             x2, x2, HEAP, lsl #32
    // 0x83dc74: cmp             w2, NULL
    // 0x83dc78: b.eq            #0x83e000
    // 0x83dc7c: SaveReg r2
    //     0x83dc7c: str             x2, [SP, #-8]!
    // 0x83dc80: r0 = of()
    //     0x83dc80: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x83dc84: add             SP, SP, #8
    // 0x83dc88: mov             x1, x0
    // 0x83dc8c: ldr             x0, [fp, #0x10]
    // 0x83dc90: stur            x1, [fp, #-0x10]
    // 0x83dc94: LoadField: r2 = r0->field_b
    //     0x83dc94: ldur            w2, [x0, #0xb]
    // 0x83dc98: DecompressPointer r2
    //     0x83dc98: add             x2, x2, HEAP, lsl #32
    // 0x83dc9c: cmp             w2, NULL
    // 0x83dca0: b.eq            #0x83e004
    // 0x83dca4: LoadField: r3 = r2->field_1f
    //     0x83dca4: ldur            w3, [x2, #0x1f]
    // 0x83dca8: DecompressPointer r3
    //     0x83dca8: add             x3, x3, HEAP, lsl #32
    // 0x83dcac: SaveReg r3
    //     0x83dcac: str             x3, [SP, #-8]!
    // 0x83dcb0: r0 = applyDefaults()
    //     0x83dcb0: bl              #0x7b4a68  ; [package:flutter/src/material/input_decorator.dart] InputDecoration::applyDefaults
    // 0x83dcb4: add             SP, SP, #8
    // 0x83dcb8: mov             x1, x0
    // 0x83dcbc: ldr             x0, [fp, #0x10]
    // 0x83dcc0: LoadField: r2 = r0->field_b
    //     0x83dcc0: ldur            w2, [x0, #0xb]
    // 0x83dcc4: DecompressPointer r2
    //     0x83dcc4: add             x2, x2, HEAP, lsl #32
    // 0x83dcc8: cmp             w2, NULL
    // 0x83dccc: b.eq            #0x83e008
    // 0x83dcd0: LoadField: r3 = r2->field_1f
    //     0x83dcd0: ldur            w3, [x2, #0x1f]
    // 0x83dcd4: DecompressPointer r3
    //     0x83dcd4: add             x3, x3, HEAP, lsl #32
    // 0x83dcd8: LoadField: r4 = r3->field_bf
    //     0x83dcd8: ldur            w4, [x3, #0xbf]
    // 0x83dcdc: DecompressPointer r4
    //     0x83dcdc: add             x4, x4, HEAP, lsl #32
    // 0x83dce0: LoadField: r5 = r3->field_37
    //     0x83dce0: ldur            w5, [x3, #0x37]
    // 0x83dce4: DecompressPointer r5
    //     0x83dce4: add             x5, x5, HEAP, lsl #32
    // 0x83dce8: cmp             w5, NULL
    // 0x83dcec: b.ne            #0x83dd00
    // 0x83dcf0: LoadField: r3 = r2->field_5f
    //     0x83dcf0: ldur            w3, [x2, #0x5f]
    // 0x83dcf4: DecompressPointer r3
    //     0x83dcf4: add             x3, x3, HEAP, lsl #32
    // 0x83dcf8: mov             x2, x3
    // 0x83dcfc: b               #0x83dd04
    // 0x83dd00: mov             x2, x5
    // 0x83dd04: stp             x4, x1, [SP, #-0x10]!
    // 0x83dd08: SaveReg r2
    //     0x83dd08: str             x2, [SP, #-8]!
    // 0x83dd0c: r4 = const [0, 0x3, 0x3, 0x1, enabled, 0x1, hintMaxLines, 0x2, null]
    //     0x83dd0c: add             x4, PP, #0x2d, lsl #12  ; [pp+0x2dd40] List(9) [0, 0x3, 0x3, 0x1, "enabled", 0x1, "hintMaxLines", 0x2, Null]
    //     0x83dd10: ldr             x4, [x4, #0xd40]
    // 0x83dd14: r0 = copyWith()
    //     0x83dd14: bl              #0x7b4d38  ; [package:flutter/src/material/input_decorator.dart] InputDecoration::copyWith
    // 0x83dd18: add             SP, SP, #0x18
    // 0x83dd1c: stur            x0, [fp, #-0x28]
    // 0x83dd20: LoadField: r1 = r0->field_8f
    //     0x83dd20: ldur            w1, [x0, #0x8f]
    // 0x83dd24: DecompressPointer r1
    //     0x83dd24: add             x1, x1, HEAP, lsl #32
    // 0x83dd28: stur            x1, [fp, #-0x20]
    // 0x83dd2c: cmp             w1, NULL
    // 0x83dd30: b.ne            #0x83dd48
    // 0x83dd34: LoadField: r2 = r0->field_8b
    //     0x83dd34: ldur            w2, [x0, #0x8b]
    // 0x83dd38: DecompressPointer r2
    //     0x83dd38: add             x2, x2, HEAP, lsl #32
    // 0x83dd3c: stur            x2, [fp, #-0x18]
    // 0x83dd40: cmp             w2, NULL
    // 0x83dd44: b.eq            #0x83dd54
    // 0x83dd48: LeaveFrame
    //     0x83dd48: mov             SP, fp
    //     0x83dd4c: ldp             fp, lr, [SP], #0x10
    // 0x83dd50: ret
    //     0x83dd50: ret             
    // 0x83dd54: ldr             x16, [fp, #0x10]
    // 0x83dd58: SaveReg r16
    //     0x83dd58: str             x16, [SP, #-8]!
    // 0x83dd5c: r0 = _currentLength()
    //     0x83dd5c: bl              #0x83d880  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_currentLength
    // 0x83dd60: add             SP, SP, #8
    // 0x83dd64: mov             x2, x0
    // 0x83dd68: ldur            x0, [fp, #-0x20]
    // 0x83dd6c: stur            x2, [fp, #-0x30]
    // 0x83dd70: cmp             w0, NULL
    // 0x83dd74: b.ne            #0x83dda4
    // 0x83dd78: ldur            x0, [fp, #-0x18]
    // 0x83dd7c: cmp             w0, NULL
    // 0x83dd80: b.ne            #0x83dd9c
    // 0x83dd84: ldr             x3, [fp, #0x10]
    // 0x83dd88: LoadField: r0 = r3->field_b
    //     0x83dd88: ldur            w0, [x3, #0xb]
    // 0x83dd8c: DecompressPointer r0
    //     0x83dd8c: add             x0, x0, HEAP, lsl #32
    // 0x83dd90: cmp             w0, NULL
    // 0x83dd94: b.eq            #0x83e00c
    // 0x83dd98: b               #0x83dda8
    // 0x83dd9c: ldr             x3, [fp, #0x10]
    // 0x83dda0: b               #0x83dda8
    // 0x83dda4: ldr             x3, [fp, #0x10]
    // 0x83dda8: LoadField: r0 = r3->field_b
    //     0x83dda8: ldur            w0, [x3, #0xb]
    // 0x83ddac: DecompressPointer r0
    //     0x83ddac: add             x0, x0, HEAP, lsl #32
    // 0x83ddb0: cmp             w0, NULL
    // 0x83ddb4: b.eq            #0x83e010
    // 0x83ddb8: LoadField: r1 = r0->field_77
    //     0x83ddb8: ldur            w1, [x0, #0x77]
    // 0x83ddbc: DecompressPointer r1
    //     0x83ddbc: add             x1, x1, HEAP, lsl #32
    // 0x83ddc0: cmp             w1, NULL
    // 0x83ddc4: b.ne            #0x83ddd8
    // 0x83ddc8: ldur            x0, [fp, #-0x28]
    // 0x83ddcc: LeaveFrame
    //     0x83ddcc: mov             SP, fp
    //     0x83ddd0: ldp             fp, lr, [SP], #0x10
    // 0x83ddd4: ret
    //     0x83ddd4: ret             
    // 0x83ddd8: r0 = BoxInt64Instr(r2)
    //     0x83ddd8: sbfiz           x0, x2, #1, #0x1f
    //     0x83dddc: cmp             x2, x0, asr #1
    //     0x83dde0: b.eq            #0x83ddec
    //     0x83dde4: bl              #0xd69bb8
    //     0x83dde8: stur            x2, [x0, #7]
    // 0x83ddec: SaveReg r0
    //     0x83ddec: str             x0, [SP, #-8]!
    // 0x83ddf0: r0 = _interpolateSingle()
    //     0x83ddf0: bl              #0x4bdd98  ; [dart:core] _StringBase::_interpolateSingle
    // 0x83ddf4: add             SP, SP, #8
    // 0x83ddf8: mov             x3, x0
    // 0x83ddfc: ldr             x0, [fp, #0x10]
    // 0x83de00: stur            x3, [fp, #-0x20]
    // 0x83de04: LoadField: r1 = r0->field_b
    //     0x83de04: ldur            w1, [x0, #0xb]
    // 0x83de08: DecompressPointer r1
    //     0x83de08: add             x1, x1, HEAP, lsl #32
    // 0x83de0c: cmp             w1, NULL
    // 0x83de10: b.eq            #0x83e014
    // 0x83de14: LoadField: r4 = r1->field_77
    //     0x83de14: ldur            w4, [x1, #0x77]
    // 0x83de18: DecompressPointer r4
    //     0x83de18: add             x4, x4, HEAP, lsl #32
    // 0x83de1c: stur            x4, [fp, #-0x18]
    // 0x83de20: cmp             w4, NULL
    // 0x83de24: b.eq            #0x83e018
    // 0x83de28: r1 = LoadInt32Instr(r4)
    //     0x83de28: sbfx            x1, x4, #1, #0x1f
    // 0x83de2c: cmp             x1, #0
    // 0x83de30: b.le            #0x83def0
    // 0x83de34: ldur            x5, [fp, #-0x30]
    // 0x83de38: r1 = Null
    //     0x83de38: mov             x1, NULL
    // 0x83de3c: r2 = 4
    //     0x83de3c: mov             x2, #4
    // 0x83de40: r0 = AllocateArray()
    //     0x83de40: bl              #0xd6987c  ; AllocateArrayStub
    // 0x83de44: r17 = "/"
    //     0x83de44: ldr             x17, [PP, #0x768]  ; [pp+0x768] "/"
    // 0x83de48: StoreField: r0->field_f = r17
    //     0x83de48: stur            w17, [x0, #0xf]
    // 0x83de4c: ldur            x1, [fp, #-0x18]
    // 0x83de50: StoreField: r0->field_13 = r1
    //     0x83de50: stur            w1, [x0, #0x13]
    // 0x83de54: SaveReg r0
    //     0x83de54: str             x0, [SP, #-8]!
    // 0x83de58: r0 = _interpolate()
    //     0x83de58: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x83de5c: add             SP, SP, #8
    // 0x83de60: ldur            x16, [fp, #-0x20]
    // 0x83de64: stp             x0, x16, [SP, #-0x10]!
    // 0x83de68: r0 = +()
    //     0x83de68: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0x83de6c: add             SP, SP, #0x10
    // 0x83de70: mov             x3, x0
    // 0x83de74: ldr             x2, [fp, #0x10]
    // 0x83de78: stur            x3, [fp, #-0x18]
    // 0x83de7c: LoadField: r0 = r2->field_b
    //     0x83de7c: ldur            w0, [x2, #0xb]
    // 0x83de80: DecompressPointer r0
    //     0x83de80: add             x0, x0, HEAP, lsl #32
    // 0x83de84: cmp             w0, NULL
    // 0x83de88: b.eq            #0x83e01c
    // 0x83de8c: LoadField: r4 = r0->field_77
    //     0x83de8c: ldur            w4, [x0, #0x77]
    // 0x83de90: DecompressPointer r4
    //     0x83de90: add             x4, x4, HEAP, lsl #32
    // 0x83de94: cmp             w4, NULL
    // 0x83de98: b.eq            #0x83e020
    // 0x83de9c: r0 = LoadInt32Instr(r4)
    //     0x83de9c: sbfx            x0, x4, #1, #0x1f
    // 0x83dea0: ldur            x1, [fp, #-0x30]
    // 0x83dea4: sub             x5, x0, x1
    // 0x83dea8: r0 = BoxInt64Instr(r5)
    //     0x83dea8: sbfiz           x0, x5, #1, #0x1f
    //     0x83deac: cmp             x5, x0, asr #1
    //     0x83deb0: b.eq            #0x83debc
    //     0x83deb4: bl              #0xd69bb8
    //     0x83deb8: stur            x5, [x0, #7]
    // 0x83debc: stp             xzr, x0, [SP, #-0x10]!
    // 0x83dec0: SaveReg r4
    //     0x83dec0: str             x4, [SP, #-8]!
    // 0x83dec4: r0 = clamp()
    //     0x83dec4: bl              #0xd66d18  ; [dart:core] _IntegerImplementation::clamp
    // 0x83dec8: add             SP, SP, #0x18
    // 0x83decc: r1 = LoadInt32Instr(r0)
    //     0x83decc: sbfx            x1, x0, #1, #0x1f
    //     0x83ded0: tbz             w0, #0, #0x83ded8
    //     0x83ded4: ldur            x1, [x0, #7]
    // 0x83ded8: ldur            x16, [fp, #-8]
    // 0x83dedc: stp             x1, x16, [SP, #-0x10]!
    // 0x83dee0: r0 = remainingTextFieldCharacterCount()
    //     0x83dee0: bl              #0x83e02c  ; [package:flutter/src/material/material_localizations.dart] DefaultMaterialLocalizations::remainingTextFieldCharacterCount
    // 0x83dee4: add             SP, SP, #0x10
    // 0x83dee8: ldur            x1, [fp, #-0x18]
    // 0x83deec: b               #0x83def8
    // 0x83def0: ldur            x1, [fp, #-0x20]
    // 0x83def4: r0 = ""
    //     0x83def4: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x83def8: stur            x1, [fp, #-8]
    // 0x83defc: stur            x0, [fp, #-0x18]
    // 0x83df00: ldr             x16, [fp, #0x10]
    // 0x83df04: SaveReg r16
    //     0x83df04: str             x16, [SP, #-8]!
    // 0x83df08: r0 = _hasIntrinsicError()
    //     0x83df08: bl              #0x83cc80  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_hasIntrinsicError
    // 0x83df0c: add             SP, SP, #8
    // 0x83df10: tbnz            w0, #4, #0x83dfc4
    // 0x83df14: ldur            x0, [fp, #-0x28]
    // 0x83df18: LoadField: r1 = r0->field_3b
    //     0x83df18: ldur            w1, [x0, #0x3b]
    // 0x83df1c: DecompressPointer r1
    //     0x83df1c: add             x1, x1, HEAP, lsl #32
    // 0x83df20: cmp             w1, NULL
    // 0x83df24: b.ne            #0x83df2c
    // 0x83df28: r1 = ""
    //     0x83df28: ldr             x1, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x83df2c: stur            x1, [fp, #-0x20]
    // 0x83df30: LoadField: r2 = r0->field_3f
    //     0x83df30: ldur            w2, [x0, #0x3f]
    // 0x83df34: DecompressPointer r2
    //     0x83df34: add             x2, x2, HEAP, lsl #32
    // 0x83df38: cmp             w2, NULL
    // 0x83df3c: b.ne            #0x83df88
    // 0x83df40: ldur            x2, [fp, #-0x10]
    // 0x83df44: LoadField: r3 = r2->field_93
    //     0x83df44: ldur            w3, [x2, #0x93]
    // 0x83df48: DecompressPointer r3
    //     0x83df48: add             x3, x3, HEAP, lsl #32
    // 0x83df4c: LoadField: r4 = r3->field_33
    //     0x83df4c: ldur            w4, [x3, #0x33]
    // 0x83df50: DecompressPointer r4
    //     0x83df50: add             x4, x4, HEAP, lsl #32
    // 0x83df54: cmp             w4, NULL
    // 0x83df58: b.eq            #0x83e024
    // 0x83df5c: r17 = 355
    //     0x83df5c: mov             x17, #0x163
    // 0x83df60: ldr             w3, [x2, x17]
    // 0x83df64: DecompressPointer r3
    //     0x83df64: add             x3, x3, HEAP, lsl #32
    // 0x83df68: cmp             w3, NULL
    // 0x83df6c: b.eq            #0x83e028
    // 0x83df70: stp             x3, x4, [SP, #-0x10]!
    // 0x83df74: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0x83df74: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0x83df78: ldr             x4, [x4, #0x168]
    // 0x83df7c: r0 = copyWith()
    //     0x83df7c: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x83df80: add             SP, SP, #0x10
    // 0x83df84: b               #0x83df8c
    // 0x83df88: mov             x0, x2
    // 0x83df8c: ldur            x16, [fp, #-0x28]
    // 0x83df90: ldur            lr, [fp, #-0x20]
    // 0x83df94: stp             lr, x16, [SP, #-0x10]!
    // 0x83df98: ldur            x16, [fp, #-8]
    // 0x83df9c: stp             x16, x0, [SP, #-0x10]!
    // 0x83dfa0: ldur            x16, [fp, #-0x18]
    // 0x83dfa4: SaveReg r16
    //     0x83dfa4: str             x16, [SP, #-8]!
    // 0x83dfa8: r4 = const [0, 0x5, 0x5, 0x1, counterStyle, 0x2, counterText, 0x3, errorText, 0x1, semanticCounterText, 0x4, null]
    //     0x83dfa8: add             x4, PP, #0x2d, lsl #12  ; [pp+0x2dd48] List(13) [0, 0x5, 0x5, 0x1, "counterStyle", 0x2, "counterText", 0x3, "errorText", 0x1, "semanticCounterText", 0x4, Null]
    //     0x83dfac: ldr             x4, [x4, #0xd48]
    // 0x83dfb0: r0 = copyWith()
    //     0x83dfb0: bl              #0x7b4d38  ; [package:flutter/src/material/input_decorator.dart] InputDecoration::copyWith
    // 0x83dfb4: add             SP, SP, #0x28
    // 0x83dfb8: LeaveFrame
    //     0x83dfb8: mov             SP, fp
    //     0x83dfbc: ldp             fp, lr, [SP], #0x10
    // 0x83dfc0: ret
    //     0x83dfc0: ret             
    // 0x83dfc4: ldur            x16, [fp, #-0x28]
    // 0x83dfc8: ldur            lr, [fp, #-8]
    // 0x83dfcc: stp             lr, x16, [SP, #-0x10]!
    // 0x83dfd0: ldur            x16, [fp, #-0x18]
    // 0x83dfd4: SaveReg r16
    //     0x83dfd4: str             x16, [SP, #-8]!
    // 0x83dfd8: r4 = const [0, 0x3, 0x3, 0x1, counterText, 0x1, semanticCounterText, 0x2, null]
    //     0x83dfd8: add             x4, PP, #0x2d, lsl #12  ; [pp+0x2dd50] List(9) [0, 0x3, 0x3, 0x1, "counterText", 0x1, "semanticCounterText", 0x2, Null]
    //     0x83dfdc: ldr             x4, [x4, #0xd50]
    // 0x83dfe0: r0 = copyWith()
    //     0x83dfe0: bl              #0x7b4d38  ; [package:flutter/src/material/input_decorator.dart] InputDecoration::copyWith
    // 0x83dfe4: add             SP, SP, #0x18
    // 0x83dfe8: LeaveFrame
    //     0x83dfe8: mov             SP, fp
    //     0x83dfec: ldp             fp, lr, [SP], #0x10
    // 0x83dff0: ret
    //     0x83dff0: ret             
    // 0x83dff4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83dff4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83dff8: b               #0x83dc40
    // 0x83dffc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83dffc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83e000: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83e000: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83e004: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83e004: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83e008: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83e008: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83e00c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83e00c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83e010: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83e010: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83e014: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83e014: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83e018: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83e018: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83e01c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83e01c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83e020: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83e020: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83e024: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83e024: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83e028: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83e028: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleSelectionHandleTapped(dynamic) {
    // ** addr: 0x83e0fc, size: 0x48
    // 0x83e0fc: EnterFrame
    //     0x83e0fc: stp             fp, lr, [SP, #-0x10]!
    //     0x83e100: mov             fp, SP
    // 0x83e104: ldr             x0, [fp, #0x10]
    // 0x83e108: LoadField: r1 = r0->field_17
    //     0x83e108: ldur            w1, [x0, #0x17]
    // 0x83e10c: DecompressPointer r1
    //     0x83e10c: add             x1, x1, HEAP, lsl #32
    // 0x83e110: CheckStackOverflow
    //     0x83e110: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83e114: cmp             SP, x16
    //     0x83e118: b.ls            #0x83e13c
    // 0x83e11c: LoadField: r0 = r1->field_f
    //     0x83e11c: ldur            w0, [x1, #0xf]
    // 0x83e120: DecompressPointer r0
    //     0x83e120: add             x0, x0, HEAP, lsl #32
    // 0x83e124: SaveReg r0
    //     0x83e124: str             x0, [SP, #-8]!
    // 0x83e128: r0 = _handleSelectionHandleTapped()
    //     0x83e128: bl              #0x83e144  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_handleSelectionHandleTapped
    // 0x83e12c: add             SP, SP, #8
    // 0x83e130: LeaveFrame
    //     0x83e130: mov             SP, fp
    //     0x83e134: ldp             fp, lr, [SP], #0x10
    // 0x83e138: ret
    //     0x83e138: ret             
    // 0x83e13c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83e13c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83e140: b               #0x83e11c
  }
  _ _handleSelectionHandleTapped(/* No info */) {
    // ** addr: 0x83e144, size: 0x98
    // 0x83e144: EnterFrame
    //     0x83e144: stp             fp, lr, [SP, #-0x10]!
    //     0x83e148: mov             fp, SP
    // 0x83e14c: CheckStackOverflow
    //     0x83e14c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83e150: cmp             SP, x16
    //     0x83e154: b.ls            #0x83e1cc
    // 0x83e158: ldr             x0, [fp, #0x10]
    // 0x83e15c: LoadField: r1 = r0->field_b
    //     0x83e15c: ldur            w1, [x0, #0xb]
    // 0x83e160: DecompressPointer r1
    //     0x83e160: add             x1, x1, HEAP, lsl #32
    // 0x83e164: cmp             w1, NULL
    // 0x83e168: b.eq            #0x83e1d4
    // 0x83e16c: LoadField: r2 = r1->field_17
    //     0x83e16c: ldur            w2, [x1, #0x17]
    // 0x83e170: DecompressPointer r2
    //     0x83e170: add             x2, x2, HEAP, lsl #32
    // 0x83e174: LoadField: r1 = r2->field_27
    //     0x83e174: ldur            w1, [x2, #0x27]
    // 0x83e178: DecompressPointer r1
    //     0x83e178: add             x1, x1, HEAP, lsl #32
    // 0x83e17c: LoadField: r2 = r1->field_b
    //     0x83e17c: ldur            w2, [x1, #0xb]
    // 0x83e180: DecompressPointer r2
    //     0x83e180: add             x2, x2, HEAP, lsl #32
    // 0x83e184: LoadField: r1 = r2->field_7
    //     0x83e184: ldur            x1, [x2, #7]
    // 0x83e188: LoadField: r3 = r2->field_f
    //     0x83e188: ldur            x3, [x2, #0xf]
    // 0x83e18c: cmp             x1, x3
    // 0x83e190: b.ne            #0x83e1bc
    // 0x83e194: LoadField: r1 = r0->field_3b
    //     0x83e194: ldur            w1, [x0, #0x3b]
    // 0x83e198: DecompressPointer r1
    //     0x83e198: add             x1, x1, HEAP, lsl #32
    // 0x83e19c: SaveReg r1
    //     0x83e19c: str             x1, [SP, #-8]!
    // 0x83e1a0: r0 = currentState()
    //     0x83e1a0: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x83e1a4: add             SP, SP, #8
    // 0x83e1a8: cmp             w0, NULL
    // 0x83e1ac: b.eq            #0x83e1d8
    // 0x83e1b0: SaveReg r0
    //     0x83e1b0: str             x0, [SP, #-8]!
    // 0x83e1b4: r0 = toggleToolbar()
    //     0x83e1b4: bl              #0x83e1dc  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableTextState::toggleToolbar
    // 0x83e1b8: add             SP, SP, #8
    // 0x83e1bc: r0 = Null
    //     0x83e1bc: mov             x0, NULL
    // 0x83e1c0: LeaveFrame
    //     0x83e1c0: mov             SP, fp
    //     0x83e1c4: ldp             fp, lr, [SP], #0x10
    // 0x83e1c8: ret
    //     0x83e1c8: ret             
    // 0x83e1cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83e1cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83e1d0: b               #0x83e158
    // 0x83e1d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83e1d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83e1d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83e1d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleSelectionChanged(dynamic, TextSelection, SelectionChangedCause?) {
    // ** addr: 0x83e270, size: 0x54
    // 0x83e270: EnterFrame
    //     0x83e270: stp             fp, lr, [SP, #-0x10]!
    //     0x83e274: mov             fp, SP
    // 0x83e278: ldr             x0, [fp, #0x20]
    // 0x83e27c: LoadField: r1 = r0->field_17
    //     0x83e27c: ldur            w1, [x0, #0x17]
    // 0x83e280: DecompressPointer r1
    //     0x83e280: add             x1, x1, HEAP, lsl #32
    // 0x83e284: CheckStackOverflow
    //     0x83e284: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83e288: cmp             SP, x16
    //     0x83e28c: b.ls            #0x83e2bc
    // 0x83e290: LoadField: r0 = r1->field_f
    //     0x83e290: ldur            w0, [x1, #0xf]
    // 0x83e294: DecompressPointer r0
    //     0x83e294: add             x0, x0, HEAP, lsl #32
    // 0x83e298: ldr             x16, [fp, #0x18]
    // 0x83e29c: stp             x16, x0, [SP, #-0x10]!
    // 0x83e2a0: ldr             x16, [fp, #0x10]
    // 0x83e2a4: SaveReg r16
    //     0x83e2a4: str             x16, [SP, #-8]!
    // 0x83e2a8: r0 = _handleSelectionChanged()
    //     0x83e2a8: bl              #0x83e2c4  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_handleSelectionChanged
    // 0x83e2ac: add             SP, SP, #0x18
    // 0x83e2b0: LeaveFrame
    //     0x83e2b0: mov             SP, fp
    //     0x83e2b4: ldp             fp, lr, [SP], #0x10
    // 0x83e2b8: ret
    //     0x83e2b8: ret             
    // 0x83e2bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83e2bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83e2c0: b               #0x83e290
  }
  _ _handleSelectionChanged(/* No info */) {
    // ** addr: 0x83e2c4, size: 0x1c8
    // 0x83e2c4: EnterFrame
    //     0x83e2c4: stp             fp, lr, [SP, #-0x10]!
    //     0x83e2c8: mov             fp, SP
    // 0x83e2cc: AllocStack(0x8)
    //     0x83e2cc: sub             SP, SP, #8
    // 0x83e2d0: CheckStackOverflow
    //     0x83e2d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83e2d4: cmp             SP, x16
    //     0x83e2d8: b.ls            #0x83e480
    // 0x83e2dc: r1 = 2
    //     0x83e2dc: mov             x1, #2
    // 0x83e2e0: r0 = AllocateContext()
    //     0x83e2e0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x83e2e4: mov             x1, x0
    // 0x83e2e8: ldr             x0, [fp, #0x20]
    // 0x83e2ec: stur            x1, [fp, #-8]
    // 0x83e2f0: StoreField: r1->field_f = r0
    //     0x83e2f0: stur            w0, [x1, #0xf]
    // 0x83e2f4: ldr             x16, [fp, #0x10]
    // 0x83e2f8: stp             x16, x0, [SP, #-0x10]!
    // 0x83e2fc: r0 = _shouldShowSelectionHandles()
    //     0x83e2fc: bl              #0x83e48c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_shouldShowSelectionHandles
    // 0x83e300: add             SP, SP, #0x10
    // 0x83e304: ldur            x2, [fp, #-8]
    // 0x83e308: StoreField: r2->field_13 = r0
    //     0x83e308: stur            w0, [x2, #0x13]
    // 0x83e30c: ldr             x3, [fp, #0x20]
    // 0x83e310: LoadField: r1 = r3->field_2f
    //     0x83e310: ldur            w1, [x3, #0x2f]
    // 0x83e314: DecompressPointer r1
    //     0x83e314: add             x1, x1, HEAP, lsl #32
    // 0x83e318: cmp             w0, w1
    // 0x83e31c: b.eq            #0x83e33c
    // 0x83e320: r1 = Function '<anonymous closure>':.
    //     0x83e320: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bd40] AnonymousClosure: (0x83e594), in [package:flutter/src/material/text_field.dart] _TextFieldState::_handleSelectionChanged (0x83e5dc)
    //     0x83e324: ldr             x1, [x1, #0xd40]
    // 0x83e328: r0 = AllocateClosure()
    //     0x83e328: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x83e32c: ldr             x16, [fp, #0x20]
    // 0x83e330: stp             x0, x16, [SP, #-0x10]!
    // 0x83e334: r0 = setState()
    //     0x83e334: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x83e338: add             SP, SP, #0x10
    // 0x83e33c: ldr             x0, [fp, #0x20]
    // 0x83e340: LoadField: r1 = r0->field_f
    //     0x83e340: ldur            w1, [x0, #0xf]
    // 0x83e344: DecompressPointer r1
    //     0x83e344: add             x1, x1, HEAP, lsl #32
    // 0x83e348: cmp             w1, NULL
    // 0x83e34c: b.eq            #0x83e488
    // 0x83e350: SaveReg r1
    //     0x83e350: str             x1, [SP, #-8]!
    // 0x83e354: r0 = of()
    //     0x83e354: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x83e358: add             SP, SP, #8
    // 0x83e35c: LoadField: r1 = r0->field_1f
    //     0x83e35c: ldur            w1, [x0, #0x1f]
    // 0x83e360: DecompressPointer r1
    //     0x83e360: add             x1, x1, HEAP, lsl #32
    // 0x83e364: LoadField: r0 = r1->field_7
    //     0x83e364: ldur            x0, [x1, #7]
    // 0x83e368: cmp             x0, #2
    // 0x83e36c: b.gt            #0x83e384
    // 0x83e370: cmp             x0, #1
    // 0x83e374: b.gt            #0x83e3a0
    // 0x83e378: ldr             x1, [fp, #0x20]
    // 0x83e37c: ldr             x0, [fp, #0x10]
    // 0x83e380: b               #0x83e420
    // 0x83e384: cmp             x0, #4
    // 0x83e388: b.gt            #0x83e418
    // 0x83e38c: cmp             x0, #3
    // 0x83e390: b.gt            #0x83e3a0
    // 0x83e394: ldr             x1, [fp, #0x20]
    // 0x83e398: ldr             x0, [fp, #0x10]
    // 0x83e39c: b               #0x83e420
    // 0x83e3a0: ldr             x0, [fp, #0x10]
    // 0x83e3a4: r16 = Instance_SelectionChangedCause
    //     0x83e3a4: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6b0] Obj!SelectionChangedCause@b63e91
    //     0x83e3a8: ldr             x16, [x16, #0x6b0]
    // 0x83e3ac: cmp             w0, w16
    // 0x83e3b0: b.eq            #0x83e3c4
    // 0x83e3b4: r16 = Instance_SelectionChangedCause
    //     0x83e3b4: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6d0] Obj!SelectionChangedCause@b63eb1
    //     0x83e3b8: ldr             x16, [x16, #0x6d0]
    // 0x83e3bc: cmp             w0, w16
    // 0x83e3c0: b.ne            #0x83e408
    // 0x83e3c4: ldr             x1, [fp, #0x20]
    // 0x83e3c8: LoadField: r0 = r1->field_3b
    //     0x83e3c8: ldur            w0, [x1, #0x3b]
    // 0x83e3cc: DecompressPointer r0
    //     0x83e3cc: add             x0, x0, HEAP, lsl #32
    // 0x83e3d0: SaveReg r0
    //     0x83e3d0: str             x0, [SP, #-8]!
    // 0x83e3d4: r0 = currentState()
    //     0x83e3d4: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x83e3d8: add             SP, SP, #8
    // 0x83e3dc: stur            x0, [fp, #-8]
    // 0x83e3e0: cmp             w0, NULL
    // 0x83e3e4: b.eq            #0x83e408
    // 0x83e3e8: ldr             x16, [fp, #0x18]
    // 0x83e3ec: SaveReg r16
    //     0x83e3ec: str             x16, [SP, #-8]!
    // 0x83e3f0: r0 = extent()
    //     0x83e3f0: bl              #0x5223fc  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0x83e3f4: add             SP, SP, #8
    // 0x83e3f8: ldur            x16, [fp, #-8]
    // 0x83e3fc: stp             x0, x16, [SP, #-0x10]!
    // 0x83e400: r0 = bringIntoView()
    //     0x83e400: bl              #0x7a9b0c  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableTextState::bringIntoView
    // 0x83e404: add             SP, SP, #0x10
    // 0x83e408: r0 = Null
    //     0x83e408: mov             x0, NULL
    // 0x83e40c: LeaveFrame
    //     0x83e40c: mov             SP, fp
    //     0x83e410: ldp             fp, lr, [SP], #0x10
    // 0x83e414: ret
    //     0x83e414: ret             
    // 0x83e418: ldr             x1, [fp, #0x20]
    // 0x83e41c: ldr             x0, [fp, #0x10]
    // 0x83e420: r16 = Instance_SelectionChangedCause
    //     0x83e420: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6d0] Obj!SelectionChangedCause@b63eb1
    //     0x83e424: ldr             x16, [x16, #0x6d0]
    // 0x83e428: cmp             w0, w16
    // 0x83e42c: b.ne            #0x83e470
    // 0x83e430: LoadField: r0 = r1->field_3b
    //     0x83e430: ldur            w0, [x1, #0x3b]
    // 0x83e434: DecompressPointer r0
    //     0x83e434: add             x0, x0, HEAP, lsl #32
    // 0x83e438: SaveReg r0
    //     0x83e438: str             x0, [SP, #-8]!
    // 0x83e43c: r0 = currentState()
    //     0x83e43c: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x83e440: add             SP, SP, #8
    // 0x83e444: stur            x0, [fp, #-8]
    // 0x83e448: cmp             w0, NULL
    // 0x83e44c: b.eq            #0x83e470
    // 0x83e450: ldr             x16, [fp, #0x18]
    // 0x83e454: SaveReg r16
    //     0x83e454: str             x16, [SP, #-8]!
    // 0x83e458: r0 = extent()
    //     0x83e458: bl              #0x5223fc  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0x83e45c: add             SP, SP, #8
    // 0x83e460: ldur            x16, [fp, #-8]
    // 0x83e464: stp             x0, x16, [SP, #-0x10]!
    // 0x83e468: r0 = bringIntoView()
    //     0x83e468: bl              #0x7a9b0c  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableTextState::bringIntoView
    // 0x83e46c: add             SP, SP, #0x10
    // 0x83e470: r0 = Null
    //     0x83e470: mov             x0, NULL
    // 0x83e474: LeaveFrame
    //     0x83e474: mov             SP, fp
    //     0x83e478: ldp             fp, lr, [SP], #0x10
    // 0x83e47c: ret
    //     0x83e47c: ret             
    // 0x83e480: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83e480: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83e484: b               #0x83e2dc
    // 0x83e488: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83e488: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _shouldShowSelectionHandles(/* No info */) {
    // ** addr: 0x83e48c, size: 0x108
    // 0x83e48c: EnterFrame
    //     0x83e48c: stp             fp, lr, [SP, #-0x10]!
    //     0x83e490: mov             fp, SP
    // 0x83e494: ldr             x1, [fp, #0x18]
    // 0x83e498: LoadField: r2 = r1->field_b
    //     0x83e498: ldur            w2, [x1, #0xb]
    // 0x83e49c: DecompressPointer r2
    //     0x83e49c: add             x2, x2, HEAP, lsl #32
    // 0x83e4a0: cmp             w2, NULL
    // 0x83e4a4: b.eq            #0x83e584
    // 0x83e4a8: LoadField: r3 = r1->field_33
    //     0x83e4a8: ldur            w3, [x1, #0x33]
    // 0x83e4ac: DecompressPointer r3
    //     0x83e4ac: add             x3, x3, HEAP, lsl #32
    // 0x83e4b0: r16 = Sentinel
    //     0x83e4b0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x83e4b4: cmp             w3, w16
    // 0x83e4b8: b.eq            #0x83e588
    // 0x83e4bc: LoadField: r1 = r3->field_13
    //     0x83e4bc: ldur            w1, [x3, #0x13]
    // 0x83e4c0: DecompressPointer r1
    //     0x83e4c0: add             x1, x1, HEAP, lsl #32
    // 0x83e4c4: tbz             w1, #4, #0x83e4d8
    // 0x83e4c8: r0 = false
    //     0x83e4c8: add             x0, NULL, #0x30  ; false
    // 0x83e4cc: LeaveFrame
    //     0x83e4cc: mov             SP, fp
    //     0x83e4d0: ldp             fp, lr, [SP], #0x10
    // 0x83e4d4: ret
    //     0x83e4d4: ret             
    // 0x83e4d8: ldr             x1, [fp, #0x10]
    // 0x83e4dc: r16 = Instance_SelectionChangedCause
    //     0x83e4dc: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6b8] Obj!SelectionChangedCause@b63e71
    //     0x83e4e0: ldr             x16, [x16, #0x6b8]
    // 0x83e4e4: cmp             w1, w16
    // 0x83e4e8: b.ne            #0x83e4fc
    // 0x83e4ec: r0 = false
    //     0x83e4ec: add             x0, NULL, #0x30  ; false
    // 0x83e4f0: LeaveFrame
    //     0x83e4f0: mov             SP, fp
    //     0x83e4f4: ldp             fp, lr, [SP], #0x10
    // 0x83e4f8: ret
    //     0x83e4f8: ret             
    // 0x83e4fc: LoadField: r3 = r2->field_1f
    //     0x83e4fc: ldur            w3, [x2, #0x1f]
    // 0x83e500: DecompressPointer r3
    //     0x83e500: add             x3, x3, HEAP, lsl #32
    // 0x83e504: LoadField: r4 = r3->field_bf
    //     0x83e504: ldur            w4, [x3, #0xbf]
    // 0x83e508: DecompressPointer r4
    //     0x83e508: add             x4, x4, HEAP, lsl #32
    // 0x83e50c: tbz             w4, #4, #0x83e520
    // 0x83e510: r0 = false
    //     0x83e510: add             x0, NULL, #0x30  ; false
    // 0x83e514: LeaveFrame
    //     0x83e514: mov             SP, fp
    //     0x83e518: ldp             fp, lr, [SP], #0x10
    // 0x83e51c: ret
    //     0x83e51c: ret             
    // 0x83e520: r16 = Instance_SelectionChangedCause
    //     0x83e520: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6b0] Obj!SelectionChangedCause@b63e91
    //     0x83e524: ldr             x16, [x16, #0x6b0]
    // 0x83e528: cmp             w1, w16
    // 0x83e52c: b.ne            #0x83e540
    // 0x83e530: r0 = true
    //     0x83e530: add             x0, NULL, #0x20  ; true
    // 0x83e534: LeaveFrame
    //     0x83e534: mov             SP, fp
    //     0x83e538: ldp             fp, lr, [SP], #0x10
    // 0x83e53c: ret
    //     0x83e53c: ret             
    // 0x83e540: LoadField: r1 = r2->field_17
    //     0x83e540: ldur            w1, [x2, #0x17]
    // 0x83e544: DecompressPointer r1
    //     0x83e544: add             x1, x1, HEAP, lsl #32
    // 0x83e548: LoadField: r2 = r1->field_27
    //     0x83e548: ldur            w2, [x1, #0x27]
    // 0x83e54c: DecompressPointer r2
    //     0x83e54c: add             x2, x2, HEAP, lsl #32
    // 0x83e550: LoadField: r1 = r2->field_7
    //     0x83e550: ldur            w1, [x2, #7]
    // 0x83e554: DecompressPointer r1
    //     0x83e554: add             x1, x1, HEAP, lsl #32
    // 0x83e558: LoadField: r2 = r1->field_7
    //     0x83e558: ldur            w2, [x1, #7]
    // 0x83e55c: DecompressPointer r2
    //     0x83e55c: add             x2, x2, HEAP, lsl #32
    // 0x83e560: cbz             w2, #0x83e574
    // 0x83e564: r0 = true
    //     0x83e564: add             x0, NULL, #0x20  ; true
    // 0x83e568: LeaveFrame
    //     0x83e568: mov             SP, fp
    //     0x83e56c: ldp             fp, lr, [SP], #0x10
    // 0x83e570: ret
    //     0x83e570: ret             
    // 0x83e574: r0 = false
    //     0x83e574: add             x0, NULL, #0x30  ; false
    // 0x83e578: LeaveFrame
    //     0x83e578: mov             SP, fp
    //     0x83e57c: ldp             fp, lr, [SP], #0x10
    // 0x83e580: ret
    //     0x83e580: ret             
    // 0x83e584: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83e584: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83e588: r9 = _selectionGestureDetectorBuilder
    //     0x83e588: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4bd10] Field <ExtendedTextFieldState._selectionGestureDetectorBuilder@479054530>: late (offset: 0x34)
    //     0x83e58c: ldr             x9, [x9, #0xd10]
    // 0x83e590: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x83e590: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x83eb74, size: 0xb4
    // 0x83eb74: EnterFrame
    //     0x83eb74: stp             fp, lr, [SP, #-0x10]!
    //     0x83eb78: mov             fp, SP
    // 0x83eb7c: AllocStack(0x8)
    //     0x83eb7c: sub             SP, SP, #8
    // 0x83eb80: SetupParameters()
    //     0x83eb80: ldr             x0, [fp, #0x10]
    //     0x83eb84: ldur            w1, [x0, #0x17]
    //     0x83eb88: add             x1, x1, HEAP, lsl #32
    //     0x83eb8c: stur            x1, [fp, #-8]
    // 0x83eb90: CheckStackOverflow
    //     0x83eb90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83eb94: cmp             SP, x16
    //     0x83eb98: b.ls            #0x83ec20
    // 0x83eb9c: LoadField: r0 = r1->field_f
    //     0x83eb9c: ldur            w0, [x1, #0xf]
    // 0x83eba0: DecompressPointer r0
    //     0x83eba0: add             x0, x0, HEAP, lsl #32
    // 0x83eba4: SaveReg r0
    //     0x83eba4: str             x0, [SP, #-8]!
    // 0x83eba8: r0 = _effectiveFocusNode()
    //     0x83eba8: bl              #0x7ae50c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveFocusNode
    // 0x83ebac: add             SP, SP, #8
    // 0x83ebb0: SaveReg r0
    //     0x83ebb0: str             x0, [SP, #-8]!
    // 0x83ebb4: r0 = hasFocus()
    //     0x83ebb4: bl              #0x6f8fe4  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0x83ebb8: add             SP, SP, #8
    // 0x83ebbc: tbz             w0, #4, #0x83ec10
    // 0x83ebc0: ldur            x0, [fp, #-8]
    // 0x83ebc4: LoadField: r1 = r0->field_f
    //     0x83ebc4: ldur            w1, [x0, #0xf]
    // 0x83ebc8: DecompressPointer r1
    //     0x83ebc8: add             x1, x1, HEAP, lsl #32
    // 0x83ebcc: SaveReg r1
    //     0x83ebcc: str             x1, [SP, #-8]!
    // 0x83ebd0: r0 = _effectiveFocusNode()
    //     0x83ebd0: bl              #0x7ae50c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveFocusNode
    // 0x83ebd4: add             SP, SP, #8
    // 0x83ebd8: SaveReg r0
    //     0x83ebd8: str             x0, [SP, #-8]!
    // 0x83ebdc: r0 = canRequestFocus()
    //     0x83ebdc: bl              #0x7ae250  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::canRequestFocus
    // 0x83ebe0: add             SP, SP, #8
    // 0x83ebe4: tbnz            w0, #4, #0x83ec10
    // 0x83ebe8: ldur            x0, [fp, #-8]
    // 0x83ebec: LoadField: r1 = r0->field_f
    //     0x83ebec: ldur            w1, [x0, #0xf]
    // 0x83ebf0: DecompressPointer r1
    //     0x83ebf0: add             x1, x1, HEAP, lsl #32
    // 0x83ebf4: SaveReg r1
    //     0x83ebf4: str             x1, [SP, #-8]!
    // 0x83ebf8: r0 = _effectiveFocusNode()
    //     0x83ebf8: bl              #0x7ae50c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveFocusNode
    // 0x83ebfc: add             SP, SP, #8
    // 0x83ec00: SaveReg r0
    //     0x83ec00: str             x0, [SP, #-8]!
    // 0x83ec04: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x83ec04: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x83ec08: r0 = requestFocus()
    //     0x83ec08: bl              #0x6fed6c  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::requestFocus
    // 0x83ec0c: add             SP, SP, #8
    // 0x83ec10: r0 = Null
    //     0x83ec10: mov             x0, NULL
    // 0x83ec14: LeaveFrame
    //     0x83ec14: mov             SP, fp
    //     0x83ec18: ldp             fp, lr, [SP], #0x10
    // 0x83ec1c: ret
    //     0x83ec1c: ret             
    // 0x83ec20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83ec20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83ec24: b               #0x83eb9c
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d6f20, size: 0xe4
    // 0x9d6f20: EnterFrame
    //     0x9d6f20: stp             fp, lr, [SP, #-0x10]!
    //     0x9d6f24: mov             fp, SP
    // 0x9d6f28: AllocStack(0x8)
    //     0x9d6f28: sub             SP, SP, #8
    // 0x9d6f2c: CheckStackOverflow
    //     0x9d6f2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d6f30: cmp             SP, x16
    //     0x9d6f34: b.ls            #0x9d6ff4
    // 0x9d6f38: ldr             x16, [fp, #0x10]
    // 0x9d6f3c: SaveReg r16
    //     0x9d6f3c: str             x16, [SP, #-8]!
    // 0x9d6f40: r0 = _initGestureDetectorBuilder()
    //     0x9d6f40: bl              #0x9d7004  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_initGestureDetectorBuilder
    // 0x9d6f44: add             SP, SP, #8
    // 0x9d6f48: ldr             x0, [fp, #0x10]
    // 0x9d6f4c: LoadField: r1 = r0->field_b
    //     0x9d6f4c: ldur            w1, [x0, #0xb]
    // 0x9d6f50: DecompressPointer r1
    //     0x9d6f50: add             x1, x1, HEAP, lsl #32
    // 0x9d6f54: cmp             w1, NULL
    // 0x9d6f58: b.eq            #0x9d6ffc
    // 0x9d6f5c: SaveReg r0
    //     0x9d6f5c: str             x0, [SP, #-8]!
    // 0x9d6f60: r0 = _effectiveFocusNode()
    //     0x9d6f60: bl              #0x7ae50c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveFocusNode
    // 0x9d6f64: add             SP, SP, #8
    // 0x9d6f68: mov             x1, x0
    // 0x9d6f6c: ldr             x0, [fp, #0x10]
    // 0x9d6f70: LoadField: r2 = r0->field_b
    //     0x9d6f70: ldur            w2, [x0, #0xb]
    // 0x9d6f74: DecompressPointer r2
    //     0x9d6f74: add             x2, x2, HEAP, lsl #32
    // 0x9d6f78: cmp             w2, NULL
    // 0x9d6f7c: b.eq            #0x9d7000
    // 0x9d6f80: LoadField: r3 = r2->field_1f
    //     0x9d6f80: ldur            w3, [x2, #0x1f]
    // 0x9d6f84: DecompressPointer r3
    //     0x9d6f84: add             x3, x3, HEAP, lsl #32
    // 0x9d6f88: LoadField: r2 = r3->field_bf
    //     0x9d6f88: ldur            w2, [x3, #0xbf]
    // 0x9d6f8c: DecompressPointer r2
    //     0x9d6f8c: add             x2, x2, HEAP, lsl #32
    // 0x9d6f90: stp             x2, x1, [SP, #-0x10]!
    // 0x9d6f94: r0 = canRequestFocus=()
    //     0x9d6f94: bl              #0x7acbf0  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::canRequestFocus=
    // 0x9d6f98: add             SP, SP, #0x10
    // 0x9d6f9c: ldr             x16, [fp, #0x10]
    // 0x9d6fa0: SaveReg r16
    //     0x9d6fa0: str             x16, [SP, #-8]!
    // 0x9d6fa4: r0 = _effectiveFocusNode()
    //     0x9d6fa4: bl              #0x7ae50c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveFocusNode
    // 0x9d6fa8: add             SP, SP, #8
    // 0x9d6fac: stur            x0, [fp, #-8]
    // 0x9d6fb0: r1 = 1
    //     0x9d6fb0: mov             x1, #1
    // 0x9d6fb4: r0 = AllocateContext()
    //     0x9d6fb4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d6fb8: mov             x1, x0
    // 0x9d6fbc: ldr             x0, [fp, #0x10]
    // 0x9d6fc0: StoreField: r1->field_f = r0
    //     0x9d6fc0: stur            w0, [x1, #0xf]
    // 0x9d6fc4: mov             x2, x1
    // 0x9d6fc8: r1 = Function '_handleFocusChanged@479054530':.
    //     0x9d6fc8: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4be78] AnonymousClosure: (0x9d7230), in [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_handleFocusChanged (0x9d7278)
    //     0x9d6fcc: ldr             x1, [x1, #0xe78]
    // 0x9d6fd0: r0 = AllocateClosure()
    //     0x9d6fd0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d6fd4: ldur            x16, [fp, #-8]
    // 0x9d6fd8: stp             x0, x16, [SP, #-0x10]!
    // 0x9d6fdc: r0 = addListener()
    //     0x9d6fdc: bl              #0x71a4c4  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::addListener
    // 0x9d6fe0: add             SP, SP, #0x10
    // 0x9d6fe4: r0 = Null
    //     0x9d6fe4: mov             x0, NULL
    // 0x9d6fe8: LeaveFrame
    //     0x9d6fe8: mov             SP, fp
    //     0x9d6fec: ldp             fp, lr, [SP], #0x10
    // 0x9d6ff0: ret
    //     0x9d6ff0: ret             
    // 0x9d6ff4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d6ff4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d6ff8: b               #0x9d6f38
    // 0x9d6ffc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d6ffc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9d7000: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d7000: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _initGestureDetectorBuilder(/* No info */) {
    // ** addr: 0x9d7004, size: 0x110
    // 0x9d7004: EnterFrame
    //     0x9d7004: stp             fp, lr, [SP, #-0x10]!
    //     0x9d7008: mov             fp, SP
    // 0x9d700c: AllocStack(0x20)
    //     0x9d700c: sub             SP, SP, #0x20
    // 0x9d7010: r1 = 1
    //     0x9d7010: mov             x1, #1
    // 0x9d7014: r0 = AllocateContext()
    //     0x9d7014: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d7018: mov             x1, x0
    // 0x9d701c: ldr             x0, [fp, #0x10]
    // 0x9d7020: stur            x1, [fp, #-0x10]
    // 0x9d7024: StoreField: r1->field_f = r0
    //     0x9d7024: stur            w0, [x1, #0xf]
    // 0x9d7028: LoadField: r2 = r0->field_b
    //     0x9d7028: ldur            w2, [x0, #0xb]
    // 0x9d702c: DecompressPointer r2
    //     0x9d702c: add             x2, x2, HEAP, lsl #32
    // 0x9d7030: cmp             w2, NULL
    // 0x9d7034: b.eq            #0x9d710c
    // 0x9d7038: LoadField: r2 = r0->field_f
    //     0x9d7038: ldur            w2, [x0, #0xf]
    // 0x9d703c: DecompressPointer r2
    //     0x9d703c: add             x2, x2, HEAP, lsl #32
    // 0x9d7040: stur            x2, [fp, #-8]
    // 0x9d7044: cmp             w2, NULL
    // 0x9d7048: b.eq            #0x9d7110
    // 0x9d704c: r1 = 1
    //     0x9d704c: mov             x1, #1
    // 0x9d7050: r0 = AllocateContext()
    //     0x9d7050: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d7054: mov             x1, x0
    // 0x9d7058: ldr             x0, [fp, #0x10]
    // 0x9d705c: stur            x1, [fp, #-0x18]
    // 0x9d7060: StoreField: r1->field_f = r0
    //     0x9d7060: stur            w0, [x1, #0xf]
    // 0x9d7064: r0 = CommonTextSelectionGestureDetectorBuilder()
    //     0x9d7064: bl              #0x9d7114  ; AllocateCommonTextSelectionGestureDetectorBuilderStub -> CommonTextSelectionGestureDetectorBuilder (size=0x24)
    // 0x9d7068: mov             x3, x0
    // 0x9d706c: ldur            x0, [fp, #-8]
    // 0x9d7070: stur            x3, [fp, #-0x20]
    // 0x9d7074: StoreField: r3->field_1b = r0
    //     0x9d7074: stur            w0, [x3, #0x1b]
    // 0x9d7078: ldur            x2, [fp, #-0x18]
    // 0x9d707c: r1 = Function '_requestKeyboard@479054530':.
    //     0x9d707c: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bea0] AnonymousClosure: (0x83da4c), in [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_requestKeyboard (0x83d9fc)
    //     0x9d7080: ldr             x1, [x1, #0xea0]
    // 0x9d7084: r0 = AllocateClosure()
    //     0x9d7084: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d7088: mov             x1, x0
    // 0x9d708c: ldur            x0, [fp, #-0x20]
    // 0x9d7090: StoreField: r0->field_1f = r1
    //     0x9d7090: stur            w1, [x0, #0x1f]
    // 0x9d7094: r1 = true
    //     0x9d7094: add             x1, NULL, #0x20  ; true
    // 0x9d7098: StoreField: r0->field_13 = r1
    //     0x9d7098: stur            w1, [x0, #0x13]
    // 0x9d709c: ldr             x3, [fp, #0x10]
    // 0x9d70a0: StoreField: r0->field_7 = r3
    //     0x9d70a0: stur            w3, [x0, #7]
    // 0x9d70a4: ldur            x2, [fp, #-0x10]
    // 0x9d70a8: r1 = Function '<anonymous closure>':.
    //     0x9d70a8: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bea8] AnonymousClosure: (0x9d7190), in [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_initGestureDetectorBuilder (0x9d7004)
    //     0x9d70ac: ldr             x1, [x1, #0xea8]
    // 0x9d70b0: r0 = AllocateClosure()
    //     0x9d70b0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d70b4: mov             x1, x0
    // 0x9d70b8: ldur            x0, [fp, #-0x20]
    // 0x9d70bc: StoreField: r0->field_b = r1
    //     0x9d70bc: stur            w1, [x0, #0xb]
    // 0x9d70c0: ldur            x2, [fp, #-0x10]
    // 0x9d70c4: r1 = Function '<anonymous closure>':.
    //     0x9d70c4: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4beb0] AnonymousClosure: (0x9d7120), in [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_initGestureDetectorBuilder (0x9d7004)
    //     0x9d70c8: ldr             x1, [x1, #0xeb0]
    // 0x9d70cc: r0 = AllocateClosure()
    //     0x9d70cc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d70d0: mov             x1, x0
    // 0x9d70d4: ldur            x0, [fp, #-0x20]
    // 0x9d70d8: StoreField: r0->field_f = r1
    //     0x9d70d8: stur            w1, [x0, #0xf]
    // 0x9d70dc: ldr             x1, [fp, #0x10]
    // 0x9d70e0: StoreField: r1->field_33 = r0
    //     0x9d70e0: stur            w0, [x1, #0x33]
    //     0x9d70e4: ldurb           w16, [x1, #-1]
    //     0x9d70e8: ldurb           w17, [x0, #-1]
    //     0x9d70ec: and             x16, x17, x16, lsr #2
    //     0x9d70f0: tst             x16, HEAP, lsr #32
    //     0x9d70f4: b.eq            #0x9d70fc
    //     0x9d70f8: bl              #0xd6826c
    // 0x9d70fc: r0 = Null
    //     0x9d70fc: mov             x0, NULL
    // 0x9d7100: LeaveFrame
    //     0x9d7100: mov             SP, fp
    //     0x9d7104: ldp             fp, lr, [SP], #0x10
    // 0x9d7108: ret
    //     0x9d7108: ret             
    // 0x9d710c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d710c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9d7110: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d7110: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0x9d7120, size: 0x70
    // 0x9d7120: EnterFrame
    //     0x9d7120: stp             fp, lr, [SP, #-0x10]!
    //     0x9d7124: mov             fp, SP
    // 0x9d7128: ldr             x0, [fp, #0x10]
    // 0x9d712c: LoadField: r1 = r0->field_17
    //     0x9d712c: ldur            w1, [x0, #0x17]
    // 0x9d7130: DecompressPointer r1
    //     0x9d7130: add             x1, x1, HEAP, lsl #32
    // 0x9d7134: CheckStackOverflow
    //     0x9d7134: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d7138: cmp             SP, x16
    //     0x9d713c: b.ls            #0x9d7184
    // 0x9d7140: LoadField: r0 = r1->field_f
    //     0x9d7140: ldur            w0, [x1, #0xf]
    // 0x9d7144: DecompressPointer r0
    //     0x9d7144: add             x0, x0, HEAP, lsl #32
    // 0x9d7148: LoadField: r1 = r0->field_3b
    //     0x9d7148: ldur            w1, [x0, #0x3b]
    // 0x9d714c: DecompressPointer r1
    //     0x9d714c: add             x1, x1, HEAP, lsl #32
    // 0x9d7150: SaveReg r1
    //     0x9d7150: str             x1, [SP, #-8]!
    // 0x9d7154: r0 = currentState()
    //     0x9d7154: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x9d7158: add             SP, SP, #8
    // 0x9d715c: cmp             w0, NULL
    // 0x9d7160: b.eq            #0x9d718c
    // 0x9d7164: SaveReg r0
    //     0x9d7164: str             x0, [SP, #-8]!
    // 0x9d7168: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9d7168: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9d716c: r0 = hideToolbar()
    //     0x9d716c: bl              #0x836434  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableTextState::hideToolbar
    // 0x9d7170: add             SP, SP, #8
    // 0x9d7174: r0 = Null
    //     0x9d7174: mov             x0, NULL
    // 0x9d7178: LeaveFrame
    //     0x9d7178: mov             SP, fp
    //     0x9d717c: ldp             fp, lr, [SP], #0x10
    // 0x9d7180: ret
    //     0x9d7180: ret             
    // 0x9d7184: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d7184: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d7188: b               #0x9d7140
    // 0x9d718c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d718c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0x9d7190, size: 0xa0
    // 0x9d7190: EnterFrame
    //     0x9d7190: stp             fp, lr, [SP, #-0x10]!
    //     0x9d7194: mov             fp, SP
    // 0x9d7198: AllocStack(0x8)
    //     0x9d7198: sub             SP, SP, #8
    // 0x9d719c: SetupParameters()
    //     0x9d719c: ldr             x0, [fp, #0x10]
    //     0x9d71a0: ldur            w1, [x0, #0x17]
    //     0x9d71a4: add             x1, x1, HEAP, lsl #32
    //     0x9d71a8: stur            x1, [fp, #-8]
    // 0x9d71ac: CheckStackOverflow
    //     0x9d71ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d71b0: cmp             SP, x16
    //     0x9d71b4: b.ls            #0x9d7218
    // 0x9d71b8: LoadField: r0 = r1->field_f
    //     0x9d71b8: ldur            w0, [x1, #0xf]
    // 0x9d71bc: DecompressPointer r0
    //     0x9d71bc: add             x0, x0, HEAP, lsl #32
    // 0x9d71c0: LoadField: r2 = r0->field_3b
    //     0x9d71c0: ldur            w2, [x0, #0x3b]
    // 0x9d71c4: DecompressPointer r2
    //     0x9d71c4: add             x2, x2, HEAP, lsl #32
    // 0x9d71c8: SaveReg r2
    //     0x9d71c8: str             x2, [SP, #-8]!
    // 0x9d71cc: r0 = currentState()
    //     0x9d71cc: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x9d71d0: add             SP, SP, #8
    // 0x9d71d4: cmp             w0, NULL
    // 0x9d71d8: b.eq            #0x9d7220
    // 0x9d71dc: ldur            x1, [fp, #-8]
    // 0x9d71e0: LoadField: r2 = r1->field_f
    //     0x9d71e0: ldur            w2, [x1, #0xf]
    // 0x9d71e4: DecompressPointer r2
    //     0x9d71e4: add             x2, x2, HEAP, lsl #32
    // 0x9d71e8: LoadField: r1 = r2->field_33
    //     0x9d71e8: ldur            w1, [x2, #0x33]
    // 0x9d71ec: DecompressPointer r1
    //     0x9d71ec: add             x1, x1, HEAP, lsl #32
    // 0x9d71f0: r16 = Sentinel
    //     0x9d71f0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9d71f4: cmp             w1, w16
    // 0x9d71f8: b.eq            #0x9d7224
    // 0x9d71fc: SaveReg r0
    //     0x9d71fc: str             x0, [SP, #-8]!
    // 0x9d7200: r0 = showToolbar()
    //     0x9d7200: bl              #0xccdfac  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableTextState::showToolbar
    // 0x9d7204: add             SP, SP, #8
    // 0x9d7208: r0 = Null
    //     0x9d7208: mov             x0, NULL
    // 0x9d720c: LeaveFrame
    //     0x9d720c: mov             SP, fp
    //     0x9d7210: ldp             fp, lr, [SP], #0x10
    // 0x9d7214: ret
    //     0x9d7214: ret             
    // 0x9d7218: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d7218: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d721c: b               #0x9d71b8
    // 0x9d7220: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d7220: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9d7224: r9 = _selectionGestureDetectorBuilder
    //     0x9d7224: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4bd10] Field <ExtendedTextFieldState._selectionGestureDetectorBuilder@479054530>: late (offset: 0x34)
    //     0x9d7228: ldr             x9, [x9, #0xd10]
    // 0x9d722c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9d722c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleFocusChanged(dynamic) {
    // ** addr: 0x9d7230, size: 0x48
    // 0x9d7230: EnterFrame
    //     0x9d7230: stp             fp, lr, [SP, #-0x10]!
    //     0x9d7234: mov             fp, SP
    // 0x9d7238: ldr             x0, [fp, #0x10]
    // 0x9d723c: LoadField: r1 = r0->field_17
    //     0x9d723c: ldur            w1, [x0, #0x17]
    // 0x9d7240: DecompressPointer r1
    //     0x9d7240: add             x1, x1, HEAP, lsl #32
    // 0x9d7244: CheckStackOverflow
    //     0x9d7244: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d7248: cmp             SP, x16
    //     0x9d724c: b.ls            #0x9d7270
    // 0x9d7250: LoadField: r0 = r1->field_f
    //     0x9d7250: ldur            w0, [x1, #0xf]
    // 0x9d7254: DecompressPointer r0
    //     0x9d7254: add             x0, x0, HEAP, lsl #32
    // 0x9d7258: SaveReg r0
    //     0x9d7258: str             x0, [SP, #-8]!
    // 0x9d725c: r0 = _handleFocusChanged()
    //     0x9d725c: bl              #0x9d7278  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_handleFocusChanged
    // 0x9d7260: add             SP, SP, #8
    // 0x9d7264: LeaveFrame
    //     0x9d7264: mov             SP, fp
    //     0x9d7268: ldp             fp, lr, [SP], #0x10
    // 0x9d726c: ret
    //     0x9d726c: ret             
    // 0x9d7270: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d7270: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d7274: b               #0x9d7250
  }
  _ _handleFocusChanged(/* No info */) {
    // ** addr: 0x9d7278, size: 0x4c
    // 0x9d7278: EnterFrame
    //     0x9d7278: stp             fp, lr, [SP, #-0x10]!
    //     0x9d727c: mov             fp, SP
    // 0x9d7280: CheckStackOverflow
    //     0x9d7280: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d7284: cmp             SP, x16
    //     0x9d7288: b.ls            #0x9d72bc
    // 0x9d728c: r1 = Function '<anonymous closure>':.
    //     0x9d728c: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4be80] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x9d7290: ldr             x1, [x1, #0xe80]
    // 0x9d7294: r2 = Null
    //     0x9d7294: mov             x2, NULL
    // 0x9d7298: r0 = AllocateClosure()
    //     0x9d7298: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d729c: ldr             x16, [fp, #0x10]
    // 0x9d72a0: stp             x0, x16, [SP, #-0x10]!
    // 0x9d72a4: r0 = setState()
    //     0x9d72a4: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9d72a8: add             SP, SP, #0x10
    // 0x9d72ac: r0 = Null
    //     0x9d72ac: mov             x0, NULL
    // 0x9d72b0: LeaveFrame
    //     0x9d72b0: mov             SP, fp
    //     0x9d72b4: ldp             fp, lr, [SP], #0x10
    // 0x9d72b8: ret
    //     0x9d72b8: ret             
    // 0x9d72bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d72bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d72c0: b               #0x9d728c
  }
  _ ExtendedTextFieldState(/* No info */) {
    // ** addr: 0xa3fa7c, size: 0xb8
    // 0xa3fa7c: EnterFrame
    //     0xa3fa7c: stp             fp, lr, [SP, #-0x10]!
    //     0xa3fa80: mov             fp, SP
    // 0xa3fa84: r1 = false
    //     0xa3fa84: add             x1, NULL, #0x30  ; false
    // 0xa3fa88: r0 = Sentinel
    //     0xa3fa88: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa3fa8c: CheckStackOverflow
    //     0xa3fa8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa3fa90: cmp             SP, x16
    //     0xa3fa94: b.ls            #0xa3fb2c
    // 0xa3fa98: ldr             x2, [fp, #0x10]
    // 0xa3fa9c: StoreField: r2->field_2b = r1
    //     0xa3fa9c: stur            w1, [x2, #0x2b]
    // 0xa3faa0: StoreField: r2->field_2f = r1
    //     0xa3faa0: stur            w1, [x2, #0x2f]
    // 0xa3faa4: StoreField: r2->field_33 = r0
    //     0xa3faa4: stur            w0, [x2, #0x33]
    // 0xa3faa8: StoreField: r2->field_37 = r0
    //     0xa3faa8: stur            w0, [x2, #0x37]
    // 0xa3faac: r1 = <ExtendedEditableTextState<ExtendedEditableText>>
    //     0xa3faac: add             x1, PP, #0x40, lsl #12  ; [pp+0x40b60] TypeArguments: <ExtendedEditableTextState<ExtendedEditableText>>
    //     0xa3fab0: ldr             x1, [x1, #0xb60]
    // 0xa3fab4: r0 = LabeledGlobalKey()
    //     0xa3fab4: bl              #0x594e78  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State<StatefulWidget>> (size=0x10)
    // 0xa3fab8: ldr             x1, [fp, #0x10]
    // 0xa3fabc: StoreField: r1->field_3b = r0
    //     0xa3fabc: stur            w0, [x1, #0x3b]
    //     0xa3fac0: ldurb           w16, [x1, #-1]
    //     0xa3fac4: ldurb           w17, [x0, #-1]
    //     0xa3fac8: and             x16, x17, x16, lsr #2
    //     0xa3facc: tst             x16, HEAP, lsr #32
    //     0xa3fad0: b.eq            #0xa3fad8
    //     0xa3fad4: bl              #0xd6826c
    // 0xa3fad8: r0 = true
    //     0xa3fad8: add             x0, NULL, #0x20  ; true
    // 0xa3fadc: StoreField: r1->field_1b = r0
    //     0xa3fadc: stur            w0, [x1, #0x1b]
    // 0xa3fae0: r16 = <RestorableProperty<Object?>, (dynamic this) => void?>
    //     0xa3fae0: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cfb8] TypeArguments: <RestorableProperty<Object?>, (dynamic this) => void?>
    //     0xa3fae4: ldr             x16, [x16, #0xfb8]
    // 0xa3fae8: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xa3faec: stp             lr, x16, [SP, #-0x10]!
    // 0xa3faf0: r0 = Map._fromLiteral()
    //     0xa3faf0: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xa3faf4: add             SP, SP, #0x10
    // 0xa3faf8: ldr             x1, [fp, #0x10]
    // 0xa3fafc: StoreField: r1->field_17 = r0
    //     0xa3fafc: stur            w0, [x1, #0x17]
    //     0xa3fb00: tbz             w0, #0, #0xa3fb1c
    //     0xa3fb04: ldurb           w16, [x1, #-1]
    //     0xa3fb08: ldurb           w17, [x0, #-1]
    //     0xa3fb0c: and             x16, x17, x16, lsr #2
    //     0xa3fb10: tst             x16, HEAP, lsr #32
    //     0xa3fb14: b.eq            #0xa3fb1c
    //     0xa3fb18: bl              #0xd6826c
    // 0xa3fb1c: r0 = Null
    //     0xa3fb1c: mov             x0, NULL
    // 0xa3fb20: LeaveFrame
    //     0xa3fb20: mov             SP, fp
    //     0xa3fb24: ldp             fp, lr, [SP], #0x10
    // 0xa3fb28: ret
    //     0xa3fb28: ret             
    // 0xa3fb2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa3fb2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa3fb30: b               #0xa3fa98
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a408, size: 0x18
    // 0xa4a408: r4 = 7
    //     0xa4a408: mov             x4, #7
    // 0xa4a40c: r1 = Function 'dispose':.
    //     0xa4a40c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4bca8] AnonymousClosure: (0xa4a420), in [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::dispose (0xa4fd44)
    //     0xa4a410: ldr             x1, [x17, #0xca8]
    // 0xa4a414: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a414: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a418: LoadField: r0 = r24->field_17
    //     0xa4a418: ldur            x0, [x24, #0x17]
    // 0xa4a41c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a420, size: 0x48
    // 0xa4a420: EnterFrame
    //     0xa4a420: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a424: mov             fp, SP
    // 0xa4a428: ldr             x0, [fp, #0x10]
    // 0xa4a42c: LoadField: r1 = r0->field_17
    //     0xa4a42c: ldur            w1, [x0, #0x17]
    // 0xa4a430: DecompressPointer r1
    //     0xa4a430: add             x1, x1, HEAP, lsl #32
    // 0xa4a434: CheckStackOverflow
    //     0xa4a434: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a438: cmp             SP, x16
    //     0xa4a43c: b.ls            #0xa4a460
    // 0xa4a440: LoadField: r0 = r1->field_f
    //     0xa4a440: ldur            w0, [x1, #0xf]
    // 0xa4a444: DecompressPointer r0
    //     0xa4a444: add             x0, x0, HEAP, lsl #32
    // 0xa4a448: SaveReg r0
    //     0xa4a448: str             x0, [SP, #-8]!
    // 0xa4a44c: r0 = dispose()
    //     0xa4a44c: bl              #0xa4fd44  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::dispose
    // 0xa4a450: add             SP, SP, #8
    // 0xa4a454: LeaveFrame
    //     0xa4a454: mov             SP, fp
    //     0xa4a458: ldp             fp, lr, [SP], #0x10
    // 0xa4a45c: ret
    //     0xa4a45c: ret             
    // 0xa4a460: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a460: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a464: b               #0xa4a440
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4fd44, size: 0xc8
    // 0xa4fd44: EnterFrame
    //     0xa4fd44: stp             fp, lr, [SP, #-0x10]!
    //     0xa4fd48: mov             fp, SP
    // 0xa4fd4c: AllocStack(0x8)
    //     0xa4fd4c: sub             SP, SP, #8
    // 0xa4fd50: CheckStackOverflow
    //     0xa4fd50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4fd54: cmp             SP, x16
    //     0xa4fd58: b.ls            #0xa4fe04
    // 0xa4fd5c: ldr             x16, [fp, #0x10]
    // 0xa4fd60: SaveReg r16
    //     0xa4fd60: str             x16, [SP, #-8]!
    // 0xa4fd64: r0 = _effectiveFocusNode()
    //     0xa4fd64: bl              #0x7ae50c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveFocusNode
    // 0xa4fd68: add             SP, SP, #8
    // 0xa4fd6c: stur            x0, [fp, #-8]
    // 0xa4fd70: r1 = 1
    //     0xa4fd70: mov             x1, #1
    // 0xa4fd74: r0 = AllocateContext()
    //     0xa4fd74: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa4fd78: mov             x1, x0
    // 0xa4fd7c: ldr             x0, [fp, #0x10]
    // 0xa4fd80: StoreField: r1->field_f = r0
    //     0xa4fd80: stur            w0, [x1, #0xf]
    // 0xa4fd84: mov             x2, x1
    // 0xa4fd88: r1 = Function '_handleFocusChanged@479054530':.
    //     0xa4fd88: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4be78] AnonymousClosure: (0x9d7230), in [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_handleFocusChanged (0x9d7278)
    //     0xa4fd8c: ldr             x1, [x1, #0xe78]
    // 0xa4fd90: r0 = AllocateClosure()
    //     0xa4fd90: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa4fd94: ldur            x16, [fp, #-8]
    // 0xa4fd98: stp             x0, x16, [SP, #-0x10]!
    // 0xa4fd9c: r0 = removeListener()
    //     0xa4fd9c: bl              #0x786230  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::removeListener
    // 0xa4fda0: add             SP, SP, #0x10
    // 0xa4fda4: ldr             x0, [fp, #0x10]
    // 0xa4fda8: LoadField: r1 = r0->field_27
    //     0xa4fda8: ldur            w1, [x0, #0x27]
    // 0xa4fdac: DecompressPointer r1
    //     0xa4fdac: add             x1, x1, HEAP, lsl #32
    // 0xa4fdb0: cmp             w1, NULL
    // 0xa4fdb4: b.eq            #0xa4fdc8
    // 0xa4fdb8: SaveReg r1
    //     0xa4fdb8: str             x1, [SP, #-8]!
    // 0xa4fdbc: r0 = dispose()
    //     0xa4fdbc: bl              #0xa6b1e4  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::dispose
    // 0xa4fdc0: add             SP, SP, #8
    // 0xa4fdc4: ldr             x0, [fp, #0x10]
    // 0xa4fdc8: LoadField: r1 = r0->field_23
    //     0xa4fdc8: ldur            w1, [x0, #0x23]
    // 0xa4fdcc: DecompressPointer r1
    //     0xa4fdcc: add             x1, x1, HEAP, lsl #32
    // 0xa4fdd0: cmp             w1, NULL
    // 0xa4fdd4: b.eq            #0xa4fde4
    // 0xa4fdd8: SaveReg r1
    //     0xa4fdd8: str             x1, [SP, #-8]!
    // 0xa4fddc: r0 = dispose()
    //     0xa4fddc: bl              #0x9c29bc  ; [package:flutter/src/widgets/restoration_properties.dart] RestorableChangeNotifier::dispose
    // 0xa4fde0: add             SP, SP, #8
    // 0xa4fde4: ldr             x16, [fp, #0x10]
    // 0xa4fde8: SaveReg r16
    //     0xa4fde8: str             x16, [SP, #-8]!
    // 0xa4fdec: r0 = dispose()
    //     0xa4fdec: bl              #0xa4fe0c  ; [package:extended_text_field/src/extended_text_field.dart] _ExtendedTextFieldState&State&RestorationMixin::dispose
    // 0xa4fdf0: add             SP, SP, #8
    // 0xa4fdf4: r0 = Null
    //     0xa4fdf4: mov             x0, NULL
    // 0xa4fdf8: LeaveFrame
    //     0xa4fdf8: mov             SP, fp
    //     0xa4fdfc: ldp             fp, lr, [SP], #0x10
    // 0xa4fe00: ret
    //     0xa4fe00: ret             
    // 0xa4fe04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4fe04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4fe08: b               #0xa4fd5c
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xa60a58, size: 0x74
    // 0xa60a58: EnterFrame
    //     0xa60a58: stp             fp, lr, [SP, #-0x10]!
    //     0xa60a5c: mov             fp, SP
    // 0xa60a60: AllocStack(0x8)
    //     0xa60a60: sub             SP, SP, #8
    // 0xa60a64: CheckStackOverflow
    //     0xa60a64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa60a68: cmp             SP, x16
    //     0xa60a6c: b.ls            #0xa60ac4
    // 0xa60a70: ldr             x16, [fp, #0x10]
    // 0xa60a74: SaveReg r16
    //     0xa60a74: str             x16, [SP, #-8]!
    // 0xa60a78: r0 = didChangeDependencies()
    //     0xa60a78: bl              #0xa60acc  ; [package:extended_text_field/src/extended_text_field.dart] _ExtendedTextFieldState&State&RestorationMixin::didChangeDependencies
    // 0xa60a7c: add             SP, SP, #8
    // 0xa60a80: ldr             x16, [fp, #0x10]
    // 0xa60a84: SaveReg r16
    //     0xa60a84: str             x16, [SP, #-8]!
    // 0xa60a88: r0 = _effectiveFocusNode()
    //     0xa60a88: bl              #0x7ae50c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveFocusNode
    // 0xa60a8c: add             SP, SP, #8
    // 0xa60a90: stur            x0, [fp, #-8]
    // 0xa60a94: ldr             x16, [fp, #0x10]
    // 0xa60a98: SaveReg r16
    //     0xa60a98: str             x16, [SP, #-8]!
    // 0xa60a9c: r0 = _canRequestFocus()
    //     0xa60a9c: bl              #0x7ae418  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_canRequestFocus
    // 0xa60aa0: add             SP, SP, #8
    // 0xa60aa4: ldur            x16, [fp, #-8]
    // 0xa60aa8: stp             x0, x16, [SP, #-0x10]!
    // 0xa60aac: r0 = canRequestFocus=()
    //     0xa60aac: bl              #0x7acbf0  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::canRequestFocus=
    // 0xa60ab0: add             SP, SP, #0x10
    // 0xa60ab4: r0 = Null
    //     0xa60ab4: mov             x0, NULL
    // 0xa60ab8: LeaveFrame
    //     0xa60ab8: mov             SP, fp
    //     0xa60abc: ldp             fp, lr, [SP], #0x10
    // 0xa60ac0: ret
    //     0xa60ac0: ret             
    // 0xa60ac4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa60ac4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa60ac8: b               #0xa60a70
  }
  _ restoreState(/* No info */) {
    // ** addr: 0xa60bf0, size: 0x4c
    // 0xa60bf0: EnterFrame
    //     0xa60bf0: stp             fp, lr, [SP, #-0x10]!
    //     0xa60bf4: mov             fp, SP
    // 0xa60bf8: CheckStackOverflow
    //     0xa60bf8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa60bfc: cmp             SP, x16
    //     0xa60c00: b.ls            #0xa60c34
    // 0xa60c04: ldr             x0, [fp, #0x18]
    // 0xa60c08: LoadField: r1 = r0->field_23
    //     0xa60c08: ldur            w1, [x0, #0x23]
    // 0xa60c0c: DecompressPointer r1
    //     0xa60c0c: add             x1, x1, HEAP, lsl #32
    // 0xa60c10: cmp             w1, NULL
    // 0xa60c14: b.eq            #0xa60c24
    // 0xa60c18: SaveReg r0
    //     0xa60c18: str             x0, [SP, #-8]!
    // 0xa60c1c: r0 = _registerController()
    //     0xa60c1c: bl              #0xa60c3c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_registerController
    // 0xa60c20: add             SP, SP, #8
    // 0xa60c24: r0 = Null
    //     0xa60c24: mov             x0, NULL
    // 0xa60c28: LeaveFrame
    //     0xa60c28: mov             SP, fp
    //     0xa60c2c: ldp             fp, lr, [SP], #0x10
    // 0xa60c30: ret
    //     0xa60c30: ret             
    // 0xa60c34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa60c34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa60c38: b               #0xa60c04
  }
  _ _registerController(/* No info */) {
    // ** addr: 0xa60c3c, size: 0x50
    // 0xa60c3c: EnterFrame
    //     0xa60c3c: stp             fp, lr, [SP, #-0x10]!
    //     0xa60c40: mov             fp, SP
    // 0xa60c44: CheckStackOverflow
    //     0xa60c44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa60c48: cmp             SP, x16
    //     0xa60c4c: b.ls            #0xa60c80
    // 0xa60c50: ldr             x0, [fp, #0x10]
    // 0xa60c54: LoadField: r1 = r0->field_23
    //     0xa60c54: ldur            w1, [x0, #0x23]
    // 0xa60c58: DecompressPointer r1
    //     0xa60c58: add             x1, x1, HEAP, lsl #32
    // 0xa60c5c: cmp             w1, NULL
    // 0xa60c60: b.eq            #0xa60c88
    // 0xa60c64: stp             x1, x0, [SP, #-0x10]!
    // 0xa60c68: r0 = registerForRestoration()
    //     0xa60c68: bl              #0xa60c8c  ; [package:extended_text_field/src/extended_text_field.dart] _ExtendedTextFieldState&State&RestorationMixin::registerForRestoration
    // 0xa60c6c: add             SP, SP, #0x10
    // 0xa60c70: r0 = Null
    //     0xa60c70: mov             x0, NULL
    // 0xa60c74: LeaveFrame
    //     0xa60c74: mov             SP, fp
    //     0xa60c78: ldp             fp, lr, [SP], #0x10
    // 0xa60c7c: ret
    //     0xa60c7c: ret             
    // 0xa60c80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa60c80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa60c84: b               #0xa60c50
    // 0xa60c88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa60c88: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ textInputConfiguration(/* No info */) {
    // ** addr: 0xce1a38, size: 0x12c
    // 0xce1a38: EnterFrame
    //     0xce1a38: stp             fp, lr, [SP, #-0x10]!
    //     0xce1a3c: mov             fp, SP
    // 0xce1a40: AllocStack(0x28)
    //     0xce1a40: sub             SP, SP, #0x28
    // 0xce1a44: r0 = const []
    //     0xce1a44: ldr             x0, [PP, #0x6b40]  ; [pp+0x6b40] List<String>(0)
    // 0xce1a48: CheckStackOverflow
    //     0xce1a48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce1a4c: cmp             SP, x16
    //     0xce1a50: b.ls            #0xce1b50
    // 0xce1a54: ldr             x1, [fp, #0x10]
    // 0xce1a58: LoadField: r2 = r1->field_b
    //     0xce1a58: ldur            w2, [x1, #0xb]
    // 0xce1a5c: DecompressPointer r2
    //     0xce1a5c: add             x2, x2, HEAP, lsl #32
    // 0xce1a60: cmp             w2, NULL
    // 0xce1a64: b.eq            #0xce1b58
    // 0xce1a68: LoadField: r2 = r0->field_7
    //     0xce1a68: ldur            w2, [x0, #7]
    // 0xce1a6c: DecompressPointer r2
    //     0xce1a6c: add             x2, x2, HEAP, lsl #32
    // 0xce1a70: stur            x2, [fp, #-8]
    // 0xce1a74: SaveReg r1
    //     0xce1a74: str             x1, [SP, #-8]!
    // 0xce1a78: r0 = autofillId()
    //     0xce1a78: bl              #0xce1c50  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::autofillId
    // 0xce1a7c: add             SP, SP, #8
    // 0xce1a80: mov             x1, x0
    // 0xce1a84: ldr             x0, [fp, #0x10]
    // 0xce1a88: stur            x1, [fp, #-0x20]
    // 0xce1a8c: LoadField: r2 = r0->field_b
    //     0xce1a8c: ldur            w2, [x0, #0xb]
    // 0xce1a90: DecompressPointer r2
    //     0xce1a90: add             x2, x2, HEAP, lsl #32
    // 0xce1a94: cmp             w2, NULL
    // 0xce1a98: b.eq            #0xce1b5c
    // 0xce1a9c: LoadField: r3 = r2->field_17
    //     0xce1a9c: ldur            w3, [x2, #0x17]
    // 0xce1aa0: DecompressPointer r3
    //     0xce1aa0: add             x3, x3, HEAP, lsl #32
    // 0xce1aa4: LoadField: r4 = r3->field_27
    //     0xce1aa4: ldur            w4, [x3, #0x27]
    // 0xce1aa8: DecompressPointer r4
    //     0xce1aa8: add             x4, x4, HEAP, lsl #32
    // 0xce1aac: stur            x4, [fp, #-0x18]
    // 0xce1ab0: LoadField: r3 = r2->field_1f
    //     0xce1ab0: ldur            w3, [x2, #0x1f]
    // 0xce1ab4: DecompressPointer r3
    //     0xce1ab4: add             x3, x3, HEAP, lsl #32
    // 0xce1ab8: LoadField: r2 = r3->field_2b
    //     0xce1ab8: ldur            w2, [x3, #0x2b]
    // 0xce1abc: DecompressPointer r2
    //     0xce1abc: add             x2, x2, HEAP, lsl #32
    // 0xce1ac0: stur            x2, [fp, #-0x10]
    // 0xce1ac4: r0 = AutofillConfiguration()
    //     0xce1ac4: bl              #0xce19bc  ; AllocateAutofillConfigurationStub -> AutofillConfiguration (size=0x1c)
    // 0xce1ac8: mov             x3, x0
    // 0xce1acc: r0 = true
    //     0xce1acc: add             x0, NULL, #0x20  ; true
    // 0xce1ad0: stur            x3, [fp, #-0x28]
    // 0xce1ad4: StoreField: r3->field_7 = r0
    //     0xce1ad4: stur            w0, [x3, #7]
    // 0xce1ad8: ldur            x0, [fp, #-0x20]
    // 0xce1adc: StoreField: r3->field_b = r0
    //     0xce1adc: stur            w0, [x3, #0xb]
    // 0xce1ae0: ldur            x1, [fp, #-8]
    // 0xce1ae4: r2 = 0
    //     0xce1ae4: mov             x2, #0
    // 0xce1ae8: r0 = AllocateArray()
    //     0xce1ae8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xce1aec: mov             x1, x0
    // 0xce1af0: ldur            x0, [fp, #-0x28]
    // 0xce1af4: StoreField: r0->field_f = r1
    //     0xce1af4: stur            w1, [x0, #0xf]
    // 0xce1af8: ldur            x1, [fp, #-0x10]
    // 0xce1afc: StoreField: r0->field_17 = r1
    //     0xce1afc: stur            w1, [x0, #0x17]
    // 0xce1b00: ldur            x1, [fp, #-0x18]
    // 0xce1b04: StoreField: r0->field_13 = r1
    //     0xce1b04: stur            w1, [x0, #0x13]
    // 0xce1b08: ldr             x1, [fp, #0x10]
    // 0xce1b0c: LoadField: r2 = r1->field_3b
    //     0xce1b0c: ldur            w2, [x1, #0x3b]
    // 0xce1b10: DecompressPointer r2
    //     0xce1b10: add             x2, x2, HEAP, lsl #32
    // 0xce1b14: SaveReg r2
    //     0xce1b14: str             x2, [SP, #-8]!
    // 0xce1b18: r0 = currentState()
    //     0xce1b18: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0xce1b1c: add             SP, SP, #8
    // 0xce1b20: cmp             w0, NULL
    // 0xce1b24: b.eq            #0xce1b60
    // 0xce1b28: SaveReg r0
    //     0xce1b28: str             x0, [SP, #-8]!
    // 0xce1b2c: r0 = textInputConfiguration()
    //     0xce1b2c: bl              #0xce17f4  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableTextState::textInputConfiguration
    // 0xce1b30: add             SP, SP, #8
    // 0xce1b34: ldur            x16, [fp, #-0x28]
    // 0xce1b38: stp             x16, x0, [SP, #-0x10]!
    // 0xce1b3c: r0 = copyWith()
    //     0xce1b3c: bl              #0xce1b64  ; [package:flutter/src/services/text_input.dart] TextInputConfiguration::copyWith
    // 0xce1b40: add             SP, SP, #0x10
    // 0xce1b44: LeaveFrame
    //     0xce1b44: mov             SP, fp
    //     0xce1b48: ldp             fp, lr, [SP], #0x10
    // 0xce1b4c: ret
    //     0xce1b4c: ret             
    // 0xce1b50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce1b50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce1b54: b               #0xce1a54
    // 0xce1b58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xce1b58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xce1b5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xce1b5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xce1b60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xce1b60: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ autofillId(/* No info */) {
    // ** addr: 0xce1c50, size: 0x98
    // 0xce1c50: EnterFrame
    //     0xce1c50: stp             fp, lr, [SP, #-0x10]!
    //     0xce1c54: mov             fp, SP
    // 0xce1c58: AllocStack(0x10)
    //     0xce1c58: sub             SP, SP, #0x10
    // 0xce1c5c: CheckStackOverflow
    //     0xce1c5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce1c60: cmp             SP, x16
    //     0xce1c64: b.ls            #0xce1cdc
    // 0xce1c68: ldr             x0, [fp, #0x10]
    // 0xce1c6c: LoadField: r1 = r0->field_3b
    //     0xce1c6c: ldur            w1, [x0, #0x3b]
    // 0xce1c70: DecompressPointer r1
    //     0xce1c70: add             x1, x1, HEAP, lsl #32
    // 0xce1c74: SaveReg r1
    //     0xce1c74: str             x1, [SP, #-8]!
    // 0xce1c78: r0 = currentState()
    //     0xce1c78: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0xce1c7c: add             SP, SP, #8
    // 0xce1c80: stur            x0, [fp, #-8]
    // 0xce1c84: cmp             w0, NULL
    // 0xce1c88: b.eq            #0xce1ce4
    // 0xce1c8c: r1 = Null
    //     0xce1c8c: mov             x1, NULL
    // 0xce1c90: r2 = 4
    //     0xce1c90: mov             x2, #4
    // 0xce1c94: r0 = AllocateArray()
    //     0xce1c94: bl              #0xd6987c  ; AllocateArrayStub
    // 0xce1c98: stur            x0, [fp, #-0x10]
    // 0xce1c9c: r17 = "EditableText-"
    //     0xce1c9c: add             x17, PP, #0x2d, lsl #12  ; [pp+0x2dfb0] "EditableText-"
    //     0xce1ca0: ldr             x17, [x17, #0xfb0]
    // 0xce1ca4: StoreField: r0->field_f = r17
    //     0xce1ca4: stur            w17, [x0, #0xf]
    // 0xce1ca8: ldur            x16, [fp, #-8]
    // 0xce1cac: SaveReg r16
    //     0xce1cac: str             x16, [SP, #-8]!
    // 0xce1cb0: r0 = _getHash()
    //     0xce1cb0: bl              #0x5c2424  ; [dart:core] ::_getHash
    // 0xce1cb4: add             SP, SP, #8
    // 0xce1cb8: mov             x1, x0
    // 0xce1cbc: ldur            x0, [fp, #-0x10]
    // 0xce1cc0: StoreField: r0->field_13 = r1
    //     0xce1cc0: stur            w1, [x0, #0x13]
    // 0xce1cc4: SaveReg r0
    //     0xce1cc4: str             x0, [SP, #-8]!
    // 0xce1cc8: r0 = _interpolate()
    //     0xce1cc8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xce1ccc: add             SP, SP, #8
    // 0xce1cd0: LeaveFrame
    //     0xce1cd0: mov             SP, fp
    //     0xce1cd4: ldp             fp, lr, [SP], #0x10
    // 0xce1cd8: ret
    //     0xce1cd8: ret             
    // 0xce1cdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce1cdc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce1ce0: b               #0xce1c68
    // 0xce1ce4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xce1ce4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4188, size: 0xf0, field offset: 0xc
//   const constructor, 
class ExtendedTextField extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa3fa30, size: 0x4c
    // 0xa3fa30: EnterFrame
    //     0xa3fa30: stp             fp, lr, [SP, #-0x10]!
    //     0xa3fa34: mov             fp, SP
    // 0xa3fa38: AllocStack(0x8)
    //     0xa3fa38: sub             SP, SP, #8
    // 0xa3fa3c: CheckStackOverflow
    //     0xa3fa3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa3fa40: cmp             SP, x16
    //     0xa3fa44: b.ls            #0xa3fa74
    // 0xa3fa48: r1 = <ExtendedTextField>
    //     0xa3fa48: add             x1, PP, #0x40, lsl #12  ; [pp+0x40b58] TypeArguments: <ExtendedTextField>
    //     0xa3fa4c: ldr             x1, [x1, #0xb58]
    // 0xa3fa50: r0 = ExtendedTextFieldState()
    //     0xa3fa50: bl              #0xa3fb34  ; AllocateExtendedTextFieldStateStub -> ExtendedTextFieldState (size=0x40)
    // 0xa3fa54: stur            x0, [fp, #-8]
    // 0xa3fa58: SaveReg r0
    //     0xa3fa58: str             x0, [SP, #-8]!
    // 0xa3fa5c: r0 = ExtendedTextFieldState()
    //     0xa3fa5c: bl              #0xa3fa7c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::ExtendedTextFieldState
    // 0xa3fa60: add             SP, SP, #8
    // 0xa3fa64: ldur            x0, [fp, #-8]
    // 0xa3fa68: LeaveFrame
    //     0xa3fa68: mov             SP, fp
    //     0xa3fa6c: ldp             fp, lr, [SP], #0x10
    // 0xa3fa70: ret
    //     0xa3fa70: ret             
    // 0xa3fa74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa3fa74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa3fa78: b               #0xa3fa48
  }
}

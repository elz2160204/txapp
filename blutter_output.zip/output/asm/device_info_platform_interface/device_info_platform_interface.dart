// lib: , url: package:device_info_platform_interface/device_info_platform_interface.dart

// class id: 1048862, size: 0x8
class :: {
}

// class id: 4951, size: 0x8, field offset: 0x8
abstract class DeviceInfoPlatform extends PlatformInterface {

  static late DeviceInfoPlatform _instance; // offset: 0xb34
  static late final Object _token; // offset: 0xb30

  static DeviceInfoPlatform _instance() {
    // ** addr: 0xd159ac, size: 0x44
    // 0xd159ac: EnterFrame
    //     0xd159ac: stp             fp, lr, [SP, #-0x10]!
    //     0xd159b0: mov             fp, SP
    // 0xd159b4: AllocStack(0x8)
    //     0xd159b4: sub             SP, SP, #8
    // 0xd159b8: CheckStackOverflow
    //     0xd159b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd159bc: cmp             SP, x16
    //     0xd159c0: b.ls            #0xd159e8
    // 0xd159c4: r0 = MethodChannelDeviceInfo()
    //     0xd159c4: bl              #0xd15abc  ; AllocateMethodChannelDeviceInfoStub -> MethodChannelDeviceInfo (size=0xc)
    // 0xd159c8: stur            x0, [fp, #-8]
    // 0xd159cc: SaveReg r0
    //     0xd159cc: str             x0, [SP, #-8]!
    // 0xd159d0: r0 = MethodChannelDeviceInfo()
    //     0xd159d0: bl              #0xd159f0  ; [package:device_info_platform_interface/method_channel/method_channel_device_info.dart] MethodChannelDeviceInfo::MethodChannelDeviceInfo
    // 0xd159d4: add             SP, SP, #8
    // 0xd159d8: ldur            x0, [fp, #-8]
    // 0xd159dc: LeaveFrame
    //     0xd159dc: mov             SP, fp
    //     0xd159e0: ldp             fp, lr, [SP], #0x10
    // 0xd159e4: ret
    //     0xd159e4: ret             
    // 0xd159e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd159e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd159ec: b               #0xd159c4
  }
}

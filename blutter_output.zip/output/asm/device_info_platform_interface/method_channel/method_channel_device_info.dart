// lib: , url: package:device_info_platform_interface/method_channel/method_channel_device_info.dart

// class id: 1048863, size: 0x8
class :: {
}

// class id: 4952, size: 0xc, field offset: 0x8
class MethodChannelDeviceInfo extends DeviceInfoPlatform {

  _ iosInfo(/* No info */) async {
    // ** addr: 0xd15280, size: 0xa8
    // 0xd15280: EnterFrame
    //     0xd15280: stp             fp, lr, [SP, #-0x10]!
    //     0xd15284: mov             fp, SP
    // 0xd15288: AllocStack(0x10)
    //     0xd15288: sub             SP, SP, #0x10
    // 0xd1528c: SetupParameters(MethodChannelDeviceInfo this /* r1, fp-0x10 */)
    //     0xd1528c: stur            NULL, [fp, #-8]
    //     0xd15290: mov             x0, #0
    //     0xd15294: add             x1, fp, w0, sxtw #2
    //     0xd15298: ldr             x1, [x1, #0x10]
    //     0xd1529c: stur            x1, [fp, #-0x10]
    // 0xd152a0: CheckStackOverflow
    //     0xd152a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd152a4: cmp             SP, x16
    //     0xd152a8: b.ls            #0xd15320
    // 0xd152ac: InitAsync() -> Future<IosDeviceInfo>
    //     0xd152ac: add             x0, PP, #0x14, lsl #12  ; [pp+0x14b68] TypeArguments: <IosDeviceInfo>
    //     0xd152b0: ldr             x0, [x0, #0xb68]
    //     0xd152b4: bl              #0x4b92e4
    // 0xd152b8: ldur            x0, [fp, #-0x10]
    // 0xd152bc: LoadField: r1 = r0->field_7
    //     0xd152bc: ldur            w1, [x0, #7]
    // 0xd152c0: DecompressPointer r1
    //     0xd152c0: add             x1, x1, HEAP, lsl #32
    // 0xd152c4: r16 = <String, dynamic>
    //     0xd152c4: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xd152c8: stp             x1, x16, [SP, #-0x10]!
    // 0xd152cc: r16 = "getIosDeviceInfo"
    //     0xd152cc: add             x16, PP, #0x14, lsl #12  ; [pp+0x14b78] "getIosDeviceInfo"
    //     0xd152d0: ldr             x16, [x16, #0xb78]
    // 0xd152d4: SaveReg r16
    //     0xd152d4: str             x16, [SP, #-8]!
    // 0xd152d8: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0xd152d8: add             x4, PP, #0xb, lsl #12  ; [pp+0xb4d8] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    //     0xd152dc: ldr             x4, [x4, #0x4d8]
    // 0xd152e0: r0 = invokeMapMethod()
    //     0xd152e0: bl              #0x5a21c4  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMapMethod
    // 0xd152e4: add             SP, SP, #0x18
    // 0xd152e8: mov             x1, x0
    // 0xd152ec: stur            x1, [fp, #-0x10]
    // 0xd152f0: r0 = Await()
    //     0xd152f0: bl              #0x4b8e6c  ; AwaitStub
    // 0xd152f4: cmp             w0, NULL
    // 0xd152f8: b.ne            #0xd15310
    // 0xd152fc: r16 = <String, dynamic>
    //     0xd152fc: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xd15300: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xd15304: stp             lr, x16, [SP, #-0x10]!
    // 0xd15308: r0 = Map._fromLiteral()
    //     0xd15308: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xd1530c: add             SP, SP, #0x10
    // 0xd15310: SaveReg r0
    //     0xd15310: str             x0, [SP, #-8]!
    // 0xd15314: r0 = fromMap()
    //     0xd15314: bl              #0xd15328  ; [package:device_info_platform_interface/model/ios_device_info.dart] IosDeviceInfo::fromMap
    // 0xd15318: add             SP, SP, #8
    // 0xd1531c: r0 = ReturnAsyncNotFuture()
    //     0xd1531c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xd15320: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd15320: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd15324: b               #0xd152ac
  }
  _ MethodChannelDeviceInfo(/* No info */) {
    // ** addr: 0xd159f0, size: 0xcc
    // 0xd159f0: EnterFrame
    //     0xd159f0: stp             fp, lr, [SP, #-0x10]!
    //     0xd159f4: mov             fp, SP
    // 0xd159f8: AllocStack(0x8)
    //     0xd159f8: sub             SP, SP, #8
    // 0xd159fc: CheckStackOverflow
    //     0xd159fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd15a00: cmp             SP, x16
    //     0xd15a04: b.ls            #0xd15ab4
    // 0xd15a08: r0 = MethodChannel()
    //     0xd15a08: bl              #0x5a2760  ; AllocateMethodChannelStub -> MethodChannel (size=0x14)
    // 0xd15a0c: mov             x1, x0
    // 0xd15a10: r0 = "plugins.flutter.io/device_info"
    //     0xd15a10: add             x0, PP, #0x14, lsl #12  ; [pp+0x14cb8] "plugins.flutter.io/device_info"
    //     0xd15a14: ldr             x0, [x0, #0xcb8]
    // 0xd15a18: StoreField: r1->field_7 = r0
    //     0xd15a18: stur            w0, [x1, #7]
    // 0xd15a1c: r0 = Instance_StandardMethodCodec
    //     0xd15a1c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14cc0] Obj!StandardMethodCodec@b35011
    //     0xd15a20: ldr             x0, [x0, #0xcc0]
    // 0xd15a24: StoreField: r1->field_b = r0
    //     0xd15a24: stur            w0, [x1, #0xb]
    // 0xd15a28: mov             x0, x1
    // 0xd15a2c: ldr             x1, [fp, #0x10]
    // 0xd15a30: StoreField: r1->field_7 = r0
    //     0xd15a30: stur            w0, [x1, #7]
    //     0xd15a34: ldurb           w16, [x1, #-1]
    //     0xd15a38: ldurb           w17, [x0, #-1]
    //     0xd15a3c: and             x16, x17, x16, lsr #2
    //     0xd15a40: tst             x16, HEAP, lsr #32
    //     0xd15a44: b.eq            #0xd15a4c
    //     0xd15a48: bl              #0xd6826c
    // 0xd15a4c: r0 = InitLateStaticField(0xb30) // [package:device_info_platform_interface/device_info_platform_interface.dart] DeviceInfoPlatform::_token
    //     0xd15a4c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd15a50: ldr             x0, [x0, #0x1660]
    //     0xd15a54: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd15a58: cmp             w0, w16
    //     0xd15a5c: b.ne            #0xd15a6c
    //     0xd15a60: add             x2, PP, #0x14, lsl #12  ; [pp+0x14cc8] Field <DeviceInfoPlatform._token@333212227>: static late final (offset: 0xb30)
    //     0xd15a64: ldr             x2, [x2, #0xcc8]
    //     0xd15a68: bl              #0xd67cdc
    // 0xd15a6c: stur            x0, [fp, #-8]
    // 0xd15a70: r0 = InitLateStaticField(0xa64) // [package:plugin_platform_interface/plugin_platform_interface.dart] PlatformInterface::_instanceTokens
    //     0xd15a70: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd15a74: ldr             x0, [x0, #0x14c8]
    //     0xd15a78: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd15a7c: cmp             w0, w16
    //     0xd15a80: b.ne            #0xd15a8c
    //     0xd15a84: ldr             x2, [PP, #0x170]  ; [pp+0x170] Field <PlatformInterface._instanceTokens@187304592>: static late final (offset: 0xa64)
    //     0xd15a88: bl              #0xd67cdc
    // 0xd15a8c: ldr             x16, [fp, #0x10]
    // 0xd15a90: stp             x16, x0, [SP, #-0x10]!
    // 0xd15a94: ldur            x16, [fp, #-8]
    // 0xd15a98: SaveReg r16
    //     0xd15a98: str             x16, [SP, #-8]!
    // 0xd15a9c: r0 = []=()
    //     0xd15a9c: bl              #0x4b97f8  ; [dart:core] Expando::[]=
    // 0xd15aa0: add             SP, SP, #0x18
    // 0xd15aa4: r0 = Null
    //     0xd15aa4: mov             x0, NULL
    // 0xd15aa8: LeaveFrame
    //     0xd15aa8: mov             SP, fp
    //     0xd15aac: ldp             fp, lr, [SP], #0x10
    // 0xd15ab0: ret
    //     0xd15ab0: ret             
    // 0xd15ab4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd15ab4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd15ab8: b               #0xd15a08
  }
  _ androidInfo(/* No info */) async {
    // ** addr: 0xd15b8c, size: 0xa8
    // 0xd15b8c: EnterFrame
    //     0xd15b8c: stp             fp, lr, [SP, #-0x10]!
    //     0xd15b90: mov             fp, SP
    // 0xd15b94: AllocStack(0x10)
    //     0xd15b94: sub             SP, SP, #0x10
    // 0xd15b98: SetupParameters(MethodChannelDeviceInfo this /* r1, fp-0x10 */)
    //     0xd15b98: stur            NULL, [fp, #-8]
    //     0xd15b9c: mov             x0, #0
    //     0xd15ba0: add             x1, fp, w0, sxtw #2
    //     0xd15ba4: ldr             x1, [x1, #0x10]
    //     0xd15ba8: stur            x1, [fp, #-0x10]
    // 0xd15bac: CheckStackOverflow
    //     0xd15bac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd15bb0: cmp             SP, x16
    //     0xd15bb4: b.ls            #0xd15c2c
    // 0xd15bb8: InitAsync() -> Future<AndroidDeviceInfo>
    //     0xd15bb8: add             x0, PP, #0x14, lsl #12  ; [pp+0x14cd0] TypeArguments: <AndroidDeviceInfo>
    //     0xd15bbc: ldr             x0, [x0, #0xcd0]
    //     0xd15bc0: bl              #0x4b92e4
    // 0xd15bc4: ldur            x0, [fp, #-0x10]
    // 0xd15bc8: LoadField: r1 = r0->field_7
    //     0xd15bc8: ldur            w1, [x0, #7]
    // 0xd15bcc: DecompressPointer r1
    //     0xd15bcc: add             x1, x1, HEAP, lsl #32
    // 0xd15bd0: r16 = <String, dynamic>
    //     0xd15bd0: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xd15bd4: stp             x1, x16, [SP, #-0x10]!
    // 0xd15bd8: r16 = "getAndroidDeviceInfo"
    //     0xd15bd8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14cd8] "getAndroidDeviceInfo"
    //     0xd15bdc: ldr             x16, [x16, #0xcd8]
    // 0xd15be0: SaveReg r16
    //     0xd15be0: str             x16, [SP, #-8]!
    // 0xd15be4: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0xd15be4: add             x4, PP, #0xb, lsl #12  ; [pp+0xb4d8] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    //     0xd15be8: ldr             x4, [x4, #0x4d8]
    // 0xd15bec: r0 = invokeMapMethod()
    //     0xd15bec: bl              #0x5a21c4  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMapMethod
    // 0xd15bf0: add             SP, SP, #0x18
    // 0xd15bf4: mov             x1, x0
    // 0xd15bf8: stur            x1, [fp, #-0x10]
    // 0xd15bfc: r0 = Await()
    //     0xd15bfc: bl              #0x4b8e6c  ; AwaitStub
    // 0xd15c00: cmp             w0, NULL
    // 0xd15c04: b.ne            #0xd15c1c
    // 0xd15c08: r16 = <String, dynamic>
    //     0xd15c08: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xd15c0c: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xd15c10: stp             lr, x16, [SP, #-0x10]!
    // 0xd15c14: r0 = Map._fromLiteral()
    //     0xd15c14: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xd15c18: add             SP, SP, #0x10
    // 0xd15c1c: SaveReg r0
    //     0xd15c1c: str             x0, [SP, #-8]!
    // 0xd15c20: r0 = fromMap()
    //     0xd15c20: bl              #0xd15c34  ; [package:device_info_platform_interface/model/android_device_info.dart] AndroidDeviceInfo::fromMap
    // 0xd15c24: add             SP, SP, #8
    // 0xd15c28: r0 = ReturnAsyncNotFuture()
    //     0xd15c28: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xd15c2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd15c2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd15c30: b               #0xd15bb8
  }
}

// lib: , url: package:device_info_platform_interface/model/android_device_info.dart

// class id: 1048864, size: 0x8
class :: {
}

// class id: 4563, size: 0x8, field offset: 0x8
class AndroidBuildVersion extends Object {

  static _ _fromMap(/* No info */) {
    // ** addr: 0xd1663c, size: 0x2e8
    // 0xd1663c: EnterFrame
    //     0xd1663c: stp             fp, lr, [SP, #-0x10]!
    //     0xd16640: mov             fp, SP
    // 0xd16644: CheckStackOverflow
    //     0xd16644: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd16648: cmp             SP, x16
    //     0xd1664c: b.ls            #0xd1691c
    // 0xd16650: ldr             x1, [fp, #0x10]
    // 0xd16654: r0 = LoadClassIdInstr(r1)
    //     0xd16654: ldur            x0, [x1, #-1]
    //     0xd16658: ubfx            x0, x0, #0xc, #0x14
    // 0xd1665c: r16 = "baseOS"
    //     0xd1665c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e90] "baseOS"
    //     0xd16660: ldr             x16, [x16, #0xe90]
    // 0xd16664: stp             x16, x1, [SP, #-0x10]!
    // 0xd16668: r0 = GDT[cid_x0 + -0xef]()
    //     0xd16668: sub             lr, x0, #0xef
    //     0xd1666c: ldr             lr, [x21, lr, lsl #3]
    //     0xd16670: blr             lr
    // 0xd16674: add             SP, SP, #0x10
    // 0xd16678: r2 = Null
    //     0xd16678: mov             x2, NULL
    // 0xd1667c: r1 = Null
    //     0xd1667c: mov             x1, NULL
    // 0xd16680: r4 = 59
    //     0xd16680: mov             x4, #0x3b
    // 0xd16684: branchIfSmi(r0, 0xd16690)
    //     0xd16684: tbz             w0, #0, #0xd16690
    // 0xd16688: r4 = LoadClassIdInstr(r0)
    //     0xd16688: ldur            x4, [x0, #-1]
    //     0xd1668c: ubfx            x4, x4, #0xc, #0x14
    // 0xd16690: sub             x4, x4, #0x5d
    // 0xd16694: cmp             x4, #3
    // 0xd16698: b.ls            #0xd166ac
    // 0xd1669c: r8 = String?
    //     0xd1669c: ldr             x8, [PP, #0x2148]  ; [pp+0x2148] Type: String?
    // 0xd166a0: r3 = Null
    //     0xd166a0: add             x3, PP, #0x14, lsl #12  ; [pp+0x14e98] Null
    //     0xd166a4: ldr             x3, [x3, #0xe98]
    // 0xd166a8: r0 = String?()
    //     0xd166a8: bl              #0x4b2994  ; IsType_String?_Stub
    // 0xd166ac: ldr             x1, [fp, #0x10]
    // 0xd166b0: r0 = LoadClassIdInstr(r1)
    //     0xd166b0: ldur            x0, [x1, #-1]
    //     0xd166b4: ubfx            x0, x0, #0xc, #0x14
    // 0xd166b8: r16 = "previewSdkInt"
    //     0xd166b8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14ea8] "previewSdkInt"
    //     0xd166bc: ldr             x16, [x16, #0xea8]
    // 0xd166c0: stp             x16, x1, [SP, #-0x10]!
    // 0xd166c4: r0 = GDT[cid_x0 + -0xef]()
    //     0xd166c4: sub             lr, x0, #0xef
    //     0xd166c8: ldr             lr, [x21, lr, lsl #3]
    //     0xd166cc: blr             lr
    // 0xd166d0: add             SP, SP, #0x10
    // 0xd166d4: r2 = Null
    //     0xd166d4: mov             x2, NULL
    // 0xd166d8: r1 = Null
    //     0xd166d8: mov             x1, NULL
    // 0xd166dc: branchIfSmi(r0, 0xd16704)
    //     0xd166dc: tbz             w0, #0, #0xd16704
    // 0xd166e0: r4 = LoadClassIdInstr(r0)
    //     0xd166e0: ldur            x4, [x0, #-1]
    //     0xd166e4: ubfx            x4, x4, #0xc, #0x14
    // 0xd166e8: sub             x4, x4, #0x3b
    // 0xd166ec: cmp             x4, #1
    // 0xd166f0: b.ls            #0xd16704
    // 0xd166f4: r8 = int?
    //     0xd166f4: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xd166f8: r3 = Null
    //     0xd166f8: add             x3, PP, #0x14, lsl #12  ; [pp+0x14eb0] Null
    //     0xd166fc: ldr             x3, [x3, #0xeb0]
    // 0xd16700: r0 = int?()
    //     0xd16700: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xd16704: ldr             x1, [fp, #0x10]
    // 0xd16708: r0 = LoadClassIdInstr(r1)
    //     0xd16708: ldur            x0, [x1, #-1]
    //     0xd1670c: ubfx            x0, x0, #0xc, #0x14
    // 0xd16710: r16 = "securityPatch"
    //     0xd16710: add             x16, PP, #0x14, lsl #12  ; [pp+0x14ec0] "securityPatch"
    //     0xd16714: ldr             x16, [x16, #0xec0]
    // 0xd16718: stp             x16, x1, [SP, #-0x10]!
    // 0xd1671c: r0 = GDT[cid_x0 + -0xef]()
    //     0xd1671c: sub             lr, x0, #0xef
    //     0xd16720: ldr             lr, [x21, lr, lsl #3]
    //     0xd16724: blr             lr
    // 0xd16728: add             SP, SP, #0x10
    // 0xd1672c: r2 = Null
    //     0xd1672c: mov             x2, NULL
    // 0xd16730: r1 = Null
    //     0xd16730: mov             x1, NULL
    // 0xd16734: r4 = 59
    //     0xd16734: mov             x4, #0x3b
    // 0xd16738: branchIfSmi(r0, 0xd16744)
    //     0xd16738: tbz             w0, #0, #0xd16744
    // 0xd1673c: r4 = LoadClassIdInstr(r0)
    //     0xd1673c: ldur            x4, [x0, #-1]
    //     0xd16740: ubfx            x4, x4, #0xc, #0x14
    // 0xd16744: sub             x4, x4, #0x5d
    // 0xd16748: cmp             x4, #3
    // 0xd1674c: b.ls            #0xd16760
    // 0xd16750: r8 = String?
    //     0xd16750: ldr             x8, [PP, #0x2148]  ; [pp+0x2148] Type: String?
    // 0xd16754: r3 = Null
    //     0xd16754: add             x3, PP, #0x14, lsl #12  ; [pp+0x14ec8] Null
    //     0xd16758: ldr             x3, [x3, #0xec8]
    // 0xd1675c: r0 = String?()
    //     0xd1675c: bl              #0x4b2994  ; IsType_String?_Stub
    // 0xd16760: ldr             x1, [fp, #0x10]
    // 0xd16764: r0 = LoadClassIdInstr(r1)
    //     0xd16764: ldur            x0, [x1, #-1]
    //     0xd16768: ubfx            x0, x0, #0xc, #0x14
    // 0xd1676c: r16 = "codename"
    //     0xd1676c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14ed8] "codename"
    //     0xd16770: ldr             x16, [x16, #0xed8]
    // 0xd16774: stp             x16, x1, [SP, #-0x10]!
    // 0xd16778: r0 = GDT[cid_x0 + -0xef]()
    //     0xd16778: sub             lr, x0, #0xef
    //     0xd1677c: ldr             lr, [x21, lr, lsl #3]
    //     0xd16780: blr             lr
    // 0xd16784: add             SP, SP, #0x10
    // 0xd16788: cmp             w0, NULL
    // 0xd1678c: b.ne            #0xd16794
    // 0xd16790: r0 = ""
    //     0xd16790: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd16794: ldr             x3, [fp, #0x10]
    // 0xd16798: r2 = Null
    //     0xd16798: mov             x2, NULL
    // 0xd1679c: r1 = Null
    //     0xd1679c: mov             x1, NULL
    // 0xd167a0: r4 = 59
    //     0xd167a0: mov             x4, #0x3b
    // 0xd167a4: branchIfSmi(r0, 0xd167b0)
    //     0xd167a4: tbz             w0, #0, #0xd167b0
    // 0xd167a8: r4 = LoadClassIdInstr(r0)
    //     0xd167a8: ldur            x4, [x0, #-1]
    //     0xd167ac: ubfx            x4, x4, #0xc, #0x14
    // 0xd167b0: sub             x4, x4, #0x5d
    // 0xd167b4: cmp             x4, #3
    // 0xd167b8: b.ls            #0xd167cc
    // 0xd167bc: r8 = String
    //     0xd167bc: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd167c0: r3 = Null
    //     0xd167c0: add             x3, PP, #0x14, lsl #12  ; [pp+0x14ee0] Null
    //     0xd167c4: ldr             x3, [x3, #0xee0]
    // 0xd167c8: r0 = String()
    //     0xd167c8: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd167cc: ldr             x1, [fp, #0x10]
    // 0xd167d0: r0 = LoadClassIdInstr(r1)
    //     0xd167d0: ldur            x0, [x1, #-1]
    //     0xd167d4: ubfx            x0, x0, #0xc, #0x14
    // 0xd167d8: r16 = "incremental"
    //     0xd167d8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14ef0] "incremental"
    //     0xd167dc: ldr             x16, [x16, #0xef0]
    // 0xd167e0: stp             x16, x1, [SP, #-0x10]!
    // 0xd167e4: r0 = GDT[cid_x0 + -0xef]()
    //     0xd167e4: sub             lr, x0, #0xef
    //     0xd167e8: ldr             lr, [x21, lr, lsl #3]
    //     0xd167ec: blr             lr
    // 0xd167f0: add             SP, SP, #0x10
    // 0xd167f4: cmp             w0, NULL
    // 0xd167f8: b.ne            #0xd16800
    // 0xd167fc: r0 = ""
    //     0xd167fc: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd16800: ldr             x3, [fp, #0x10]
    // 0xd16804: r2 = Null
    //     0xd16804: mov             x2, NULL
    // 0xd16808: r1 = Null
    //     0xd16808: mov             x1, NULL
    // 0xd1680c: r4 = 59
    //     0xd1680c: mov             x4, #0x3b
    // 0xd16810: branchIfSmi(r0, 0xd1681c)
    //     0xd16810: tbz             w0, #0, #0xd1681c
    // 0xd16814: r4 = LoadClassIdInstr(r0)
    //     0xd16814: ldur            x4, [x0, #-1]
    //     0xd16818: ubfx            x4, x4, #0xc, #0x14
    // 0xd1681c: sub             x4, x4, #0x5d
    // 0xd16820: cmp             x4, #3
    // 0xd16824: b.ls            #0xd16838
    // 0xd16828: r8 = String
    //     0xd16828: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd1682c: r3 = Null
    //     0xd1682c: add             x3, PP, #0x14, lsl #12  ; [pp+0x14ef8] Null
    //     0xd16830: ldr             x3, [x3, #0xef8]
    // 0xd16834: r0 = String()
    //     0xd16834: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd16838: ldr             x1, [fp, #0x10]
    // 0xd1683c: r0 = LoadClassIdInstr(r1)
    //     0xd1683c: ldur            x0, [x1, #-1]
    //     0xd16840: ubfx            x0, x0, #0xc, #0x14
    // 0xd16844: r16 = "release"
    //     0xd16844: add             x16, PP, #0x14, lsl #12  ; [pp+0x14c68] "release"
    //     0xd16848: ldr             x16, [x16, #0xc68]
    // 0xd1684c: stp             x16, x1, [SP, #-0x10]!
    // 0xd16850: r0 = GDT[cid_x0 + -0xef]()
    //     0xd16850: sub             lr, x0, #0xef
    //     0xd16854: ldr             lr, [x21, lr, lsl #3]
    //     0xd16858: blr             lr
    // 0xd1685c: add             SP, SP, #0x10
    // 0xd16860: cmp             w0, NULL
    // 0xd16864: b.ne            #0xd1686c
    // 0xd16868: r0 = ""
    //     0xd16868: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd1686c: ldr             x3, [fp, #0x10]
    // 0xd16870: r2 = Null
    //     0xd16870: mov             x2, NULL
    // 0xd16874: r1 = Null
    //     0xd16874: mov             x1, NULL
    // 0xd16878: r4 = 59
    //     0xd16878: mov             x4, #0x3b
    // 0xd1687c: branchIfSmi(r0, 0xd16888)
    //     0xd1687c: tbz             w0, #0, #0xd16888
    // 0xd16880: r4 = LoadClassIdInstr(r0)
    //     0xd16880: ldur            x4, [x0, #-1]
    //     0xd16884: ubfx            x4, x4, #0xc, #0x14
    // 0xd16888: sub             x4, x4, #0x5d
    // 0xd1688c: cmp             x4, #3
    // 0xd16890: b.ls            #0xd168a4
    // 0xd16894: r8 = String
    //     0xd16894: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd16898: r3 = Null
    //     0xd16898: add             x3, PP, #0x14, lsl #12  ; [pp+0x14f08] Null
    //     0xd1689c: ldr             x3, [x3, #0xf08]
    // 0xd168a0: r0 = String()
    //     0xd168a0: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd168a4: ldr             x0, [fp, #0x10]
    // 0xd168a8: r1 = LoadClassIdInstr(r0)
    //     0xd168a8: ldur            x1, [x0, #-1]
    //     0xd168ac: ubfx            x1, x1, #0xc, #0x14
    // 0xd168b0: r16 = "sdkInt"
    //     0xd168b0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14f18] "sdkInt"
    //     0xd168b4: ldr             x16, [x16, #0xf18]
    // 0xd168b8: stp             x16, x0, [SP, #-0x10]!
    // 0xd168bc: mov             x0, x1
    // 0xd168c0: r0 = GDT[cid_x0 + -0xef]()
    //     0xd168c0: sub             lr, x0, #0xef
    //     0xd168c4: ldr             lr, [x21, lr, lsl #3]
    //     0xd168c8: blr             lr
    // 0xd168cc: add             SP, SP, #0x10
    // 0xd168d0: cmp             w0, NULL
    // 0xd168d4: b.ne            #0xd168dc
    // 0xd168d8: r0 = -2
    //     0xd168d8: mov             x0, #-2
    // 0xd168dc: r2 = Null
    //     0xd168dc: mov             x2, NULL
    // 0xd168e0: r1 = Null
    //     0xd168e0: mov             x1, NULL
    // 0xd168e4: branchIfSmi(r0, 0xd1690c)
    //     0xd168e4: tbz             w0, #0, #0xd1690c
    // 0xd168e8: r4 = LoadClassIdInstr(r0)
    //     0xd168e8: ldur            x4, [x0, #-1]
    //     0xd168ec: ubfx            x4, x4, #0xc, #0x14
    // 0xd168f0: sub             x4, x4, #0x3b
    // 0xd168f4: cmp             x4, #1
    // 0xd168f8: b.ls            #0xd1690c
    // 0xd168fc: r8 = int
    //     0xd168fc: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xd16900: r3 = Null
    //     0xd16900: add             x3, PP, #0x14, lsl #12  ; [pp+0x14f20] Null
    //     0xd16904: ldr             x3, [x3, #0xf20]
    // 0xd16908: r0 = int()
    //     0xd16908: bl              #0xd73714  ; IsType_int_Stub
    // 0xd1690c: r0 = AndroidBuildVersion()
    //     0xd1690c: bl              #0xd16924  ; AllocateAndroidBuildVersionStub -> AndroidBuildVersion (size=0x8)
    // 0xd16910: LeaveFrame
    //     0xd16910: mov             SP, fp
    //     0xd16914: ldp             fp, lr, [SP], #0x10
    // 0xd16918: ret
    //     0xd16918: ret             
    // 0xd1691c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1691c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd16920: b               #0xd16650
  }
}

// class id: 4564, size: 0xc, field offset: 0x8
class AndroidDeviceInfo extends Object {

  [closure] static bool <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x8792a0, size: 0x18
    // 0x8792a0: ldr             x1, [SP]
    // 0x8792a4: cmp             w1, NULL
    // 0x8792a8: r16 = true
    //     0x8792a8: add             x16, NULL, #0x20  ; true
    // 0x8792ac: r17 = false
    //     0x8792ac: add             x17, NULL, #0x30  ; false
    // 0x8792b0: csel            x0, x16, x17, eq
    // 0x8792b4: ret
    //     0x8792b4: ret             
  }
  static _ _fromList(/* No info */) {
    // ** addr: 0x8792b8, size: 0xd8
    // 0x8792b8: EnterFrame
    //     0x8792b8: stp             fp, lr, [SP, #-0x10]!
    //     0x8792bc: mov             fp, SP
    // 0x8792c0: AllocStack(0x8)
    //     0x8792c0: sub             SP, SP, #8
    // 0x8792c4: CheckStackOverflow
    //     0x8792c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8792c8: cmp             SP, x16
    //     0x8792cc: b.ls            #0x879388
    // 0x8792d0: ldr             x3, [fp, #0x10]
    // 0x8792d4: cmp             w3, NULL
    // 0x8792d8: b.ne            #0x8792f8
    // 0x8792dc: r16 = <String>
    //     0x8792dc: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x8792e0: stp             xzr, x16, [SP, #-0x10]!
    // 0x8792e4: r0 = _GrowableList()
    //     0x8792e4: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x8792e8: add             SP, SP, #0x10
    // 0x8792ec: LeaveFrame
    //     0x8792ec: mov             SP, fp
    //     0x8792f0: ldp             fp, lr, [SP], #0x10
    // 0x8792f4: ret
    //     0x8792f4: ret             
    // 0x8792f8: mov             x0, x3
    // 0x8792fc: r2 = Null
    //     0x8792fc: mov             x2, NULL
    // 0x879300: r1 = Null
    //     0x879300: mov             x1, NULL
    // 0x879304: r8 = Iterable
    //     0x879304: add             x8, PP, #0x14, lsl #12  ; [pp+0x14e70] Type: Iterable
    //     0x879308: ldr             x8, [x8, #0xe70]
    // 0x87930c: r3 = Null
    //     0x87930c: add             x3, PP, #0x14, lsl #12  ; [pp+0x14e78] Null
    //     0x879310: ldr             x3, [x3, #0xe78]
    // 0x879314: r0 = Iterable()
    //     0x879314: bl              #0x53322c  ; IsType_Iterable_Stub
    // 0x879318: ldr             x16, [fp, #0x10]
    // 0x87931c: stp             x16, NULL, [SP, #-0x10]!
    // 0x879320: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x879320: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x879324: r0 = List.from()
    //     0x879324: bl              #0x4c85f8  ; [dart:core] List::List.from
    // 0x879328: add             SP, SP, #0x10
    // 0x87932c: r1 = Function '<anonymous closure>': static.
    //     0x87932c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14e88] AnonymousClosure: static (0x8792a0), in [package:device_info_platform_interface/model/android_device_info.dart] AndroidDeviceInfo::_fromList (0x8792b8)
    //     0x879330: ldr             x1, [x1, #0xe88]
    // 0x879334: r2 = Null
    //     0x879334: mov             x2, NULL
    // 0x879338: stur            x0, [fp, #-8]
    // 0x87933c: r0 = AllocateClosure()
    //     0x87933c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x879340: ldur            x1, [fp, #-8]
    // 0x879344: r2 = LoadClassIdInstr(r1)
    //     0x879344: ldur            x2, [x1, #-1]
    //     0x879348: ubfx            x2, x2, #0xc, #0x14
    // 0x87934c: stp             x0, x1, [SP, #-0x10]!
    // 0x879350: mov             x0, x2
    // 0x879354: r0 = GDT[cid_x0 + -0xf7b]()
    //     0x879354: sub             lr, x0, #0xf7b
    //     0x879358: ldr             lr, [x21, lr, lsl #3]
    //     0x87935c: blr             lr
    // 0x879360: add             SP, SP, #0x10
    // 0x879364: r16 = <String>
    //     0x879364: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x879368: ldur            lr, [fp, #-8]
    // 0x87936c: stp             lr, x16, [SP, #-0x10]!
    // 0x879370: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x879370: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x879374: r0 = cast()
    //     0x879374: bl              #0x6fad9c  ; [dart:collection] ListMixin::cast
    // 0x879378: add             SP, SP, #0x10
    // 0x87937c: LeaveFrame
    //     0x87937c: mov             SP, fp
    //     0x879380: ldp             fp, lr, [SP], #0x10
    // 0x879384: ret
    //     0x879384: ret             
    // 0x879388: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x879388: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87938c: b               #0x8792d0
  }
  static _ fromMap(/* No info */) {
    // ** addr: 0xd15c34, size: 0x8dc
    // 0xd15c34: EnterFrame
    //     0xd15c34: stp             fp, lr, [SP, #-0x10]!
    //     0xd15c38: mov             fp, SP
    // 0xd15c3c: AllocStack(0x30)
    //     0xd15c3c: sub             SP, SP, #0x30
    // 0xd15c40: CheckStackOverflow
    //     0xd15c40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd15c44: cmp             SP, x16
    //     0xd15c48: b.ls            #0xd16508
    // 0xd15c4c: ldr             x1, [fp, #0x10]
    // 0xd15c50: r0 = LoadClassIdInstr(r1)
    //     0xd15c50: ldur            x0, [x1, #-1]
    //     0xd15c54: ubfx            x0, x0, #0xc, #0x14
    // 0xd15c58: r16 = "version"
    //     0xd15c58: add             x16, PP, #0xa, lsl #12  ; [pp+0xaca8] "version"
    //     0xd15c5c: ldr             x16, [x16, #0xca8]
    // 0xd15c60: stp             x16, x1, [SP, #-0x10]!
    // 0xd15c64: r0 = GDT[cid_x0 + -0xef]()
    //     0xd15c64: sub             lr, x0, #0xef
    //     0xd15c68: ldr             lr, [x21, lr, lsl #3]
    //     0xd15c6c: blr             lr
    // 0xd15c70: add             SP, SP, #0x10
    // 0xd15c74: cmp             w0, NULL
    // 0xd15c78: b.eq            #0xd15cd0
    // 0xd15c7c: ldr             x1, [fp, #0x10]
    // 0xd15c80: r0 = LoadClassIdInstr(r1)
    //     0xd15c80: ldur            x0, [x1, #-1]
    //     0xd15c84: ubfx            x0, x0, #0xc, #0x14
    // 0xd15c88: r16 = "version"
    //     0xd15c88: add             x16, PP, #0xa, lsl #12  ; [pp+0xaca8] "version"
    //     0xd15c8c: ldr             x16, [x16, #0xca8]
    // 0xd15c90: stp             x16, x1, [SP, #-0x10]!
    // 0xd15c94: r0 = GDT[cid_x0 + -0xef]()
    //     0xd15c94: sub             lr, x0, #0xef
    //     0xd15c98: ldr             lr, [x21, lr, lsl #3]
    //     0xd15c9c: blr             lr
    // 0xd15ca0: add             SP, SP, #0x10
    // 0xd15ca4: r16 = <String, dynamic>
    //     0xd15ca4: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xd15ca8: stp             x0, x16, [SP, #-0x10]!
    // 0xd15cac: r4 = 0
    //     0xd15cac: mov             x4, #0
    // 0xd15cb0: ldr             x0, [SP]
    // 0xd15cb4: r16 = UnlinkedCall_0x4aeefc
    //     0xd15cb4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14ce0] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0xd15cb8: add             x16, x16, #0xce0
    // 0xd15cbc: ldp             x5, lr, [x16]
    // 0xd15cc0: blr             lr
    // 0xd15cc4: add             SP, SP, #0x10
    // 0xd15cc8: mov             x4, x0
    // 0xd15ccc: b               #0xd15ce8
    // 0xd15cd0: r16 = <String, dynamic>
    //     0xd15cd0: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xd15cd4: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xd15cd8: stp             lr, x16, [SP, #-0x10]!
    // 0xd15cdc: r0 = Map._fromLiteral()
    //     0xd15cdc: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xd15ce0: add             SP, SP, #0x10
    // 0xd15ce4: mov             x4, x0
    // 0xd15ce8: ldr             x3, [fp, #0x10]
    // 0xd15cec: mov             x0, x4
    // 0xd15cf0: stur            x4, [fp, #-8]
    // 0xd15cf4: r2 = Null
    //     0xd15cf4: mov             x2, NULL
    // 0xd15cf8: r1 = Null
    //     0xd15cf8: mov             x1, NULL
    // 0xd15cfc: r8 = Map<String, dynamic>
    //     0xd15cfc: ldr             x8, [PP, #0x3da0]  ; [pp+0x3da0] Type: Map<String, dynamic>
    // 0xd15d00: r3 = Null
    //     0xd15d00: add             x3, PP, #0x14, lsl #12  ; [pp+0x14cf0] Null
    //     0xd15d04: ldr             x3, [x3, #0xcf0]
    // 0xd15d08: r0 = Map<String, dynamic>()
    //     0xd15d08: bl              #0x4e3b2c  ; IsType_Map<String, dynamic>_Stub
    // 0xd15d0c: ldur            x16, [fp, #-8]
    // 0xd15d10: SaveReg r16
    //     0xd15d10: str             x16, [SP, #-8]!
    // 0xd15d14: r0 = _fromMap()
    //     0xd15d14: bl              #0xd1663c  ; [package:device_info_platform_interface/model/android_device_info.dart] AndroidBuildVersion::_fromMap
    // 0xd15d18: add             SP, SP, #8
    // 0xd15d1c: ldr             x1, [fp, #0x10]
    // 0xd15d20: r0 = LoadClassIdInstr(r1)
    //     0xd15d20: ldur            x0, [x1, #-1]
    //     0xd15d24: ubfx            x0, x0, #0xc, #0x14
    // 0xd15d28: r16 = "board"
    //     0xd15d28: add             x16, PP, #0x14, lsl #12  ; [pp+0x14d00] "board"
    //     0xd15d2c: ldr             x16, [x16, #0xd00]
    // 0xd15d30: stp             x16, x1, [SP, #-0x10]!
    // 0xd15d34: r0 = GDT[cid_x0 + -0xef]()
    //     0xd15d34: sub             lr, x0, #0xef
    //     0xd15d38: ldr             lr, [x21, lr, lsl #3]
    //     0xd15d3c: blr             lr
    // 0xd15d40: add             SP, SP, #0x10
    // 0xd15d44: cmp             w0, NULL
    // 0xd15d48: b.ne            #0xd15d50
    // 0xd15d4c: r0 = ""
    //     0xd15d4c: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd15d50: ldr             x3, [fp, #0x10]
    // 0xd15d54: r2 = Null
    //     0xd15d54: mov             x2, NULL
    // 0xd15d58: r1 = Null
    //     0xd15d58: mov             x1, NULL
    // 0xd15d5c: r4 = 59
    //     0xd15d5c: mov             x4, #0x3b
    // 0xd15d60: branchIfSmi(r0, 0xd15d6c)
    //     0xd15d60: tbz             w0, #0, #0xd15d6c
    // 0xd15d64: r4 = LoadClassIdInstr(r0)
    //     0xd15d64: ldur            x4, [x0, #-1]
    //     0xd15d68: ubfx            x4, x4, #0xc, #0x14
    // 0xd15d6c: sub             x4, x4, #0x5d
    // 0xd15d70: cmp             x4, #3
    // 0xd15d74: b.ls            #0xd15d88
    // 0xd15d78: r8 = String
    //     0xd15d78: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd15d7c: r3 = Null
    //     0xd15d7c: add             x3, PP, #0x14, lsl #12  ; [pp+0x14d08] Null
    //     0xd15d80: ldr             x3, [x3, #0xd08]
    // 0xd15d84: r0 = String()
    //     0xd15d84: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd15d88: ldr             x1, [fp, #0x10]
    // 0xd15d8c: r0 = LoadClassIdInstr(r1)
    //     0xd15d8c: ldur            x0, [x1, #-1]
    //     0xd15d90: ubfx            x0, x0, #0xc, #0x14
    // 0xd15d94: r16 = "bootloader"
    //     0xd15d94: add             x16, PP, #0x14, lsl #12  ; [pp+0x14d18] "bootloader"
    //     0xd15d98: ldr             x16, [x16, #0xd18]
    // 0xd15d9c: stp             x16, x1, [SP, #-0x10]!
    // 0xd15da0: r0 = GDT[cid_x0 + -0xef]()
    //     0xd15da0: sub             lr, x0, #0xef
    //     0xd15da4: ldr             lr, [x21, lr, lsl #3]
    //     0xd15da8: blr             lr
    // 0xd15dac: add             SP, SP, #0x10
    // 0xd15db0: cmp             w0, NULL
    // 0xd15db4: b.ne            #0xd15dbc
    // 0xd15db8: r0 = ""
    //     0xd15db8: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd15dbc: ldr             x3, [fp, #0x10]
    // 0xd15dc0: r2 = Null
    //     0xd15dc0: mov             x2, NULL
    // 0xd15dc4: r1 = Null
    //     0xd15dc4: mov             x1, NULL
    // 0xd15dc8: r4 = 59
    //     0xd15dc8: mov             x4, #0x3b
    // 0xd15dcc: branchIfSmi(r0, 0xd15dd8)
    //     0xd15dcc: tbz             w0, #0, #0xd15dd8
    // 0xd15dd0: r4 = LoadClassIdInstr(r0)
    //     0xd15dd0: ldur            x4, [x0, #-1]
    //     0xd15dd4: ubfx            x4, x4, #0xc, #0x14
    // 0xd15dd8: sub             x4, x4, #0x5d
    // 0xd15ddc: cmp             x4, #3
    // 0xd15de0: b.ls            #0xd15df4
    // 0xd15de4: r8 = String
    //     0xd15de4: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd15de8: r3 = Null
    //     0xd15de8: add             x3, PP, #0x14, lsl #12  ; [pp+0x14d20] Null
    //     0xd15dec: ldr             x3, [x3, #0xd20]
    // 0xd15df0: r0 = String()
    //     0xd15df0: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd15df4: ldr             x1, [fp, #0x10]
    // 0xd15df8: r0 = LoadClassIdInstr(r1)
    //     0xd15df8: ldur            x0, [x1, #-1]
    //     0xd15dfc: ubfx            x0, x0, #0xc, #0x14
    // 0xd15e00: r16 = "brand"
    //     0xd15e00: add             x16, PP, #0x14, lsl #12  ; [pp+0x14d30] "brand"
    //     0xd15e04: ldr             x16, [x16, #0xd30]
    // 0xd15e08: stp             x16, x1, [SP, #-0x10]!
    // 0xd15e0c: r0 = GDT[cid_x0 + -0xef]()
    //     0xd15e0c: sub             lr, x0, #0xef
    //     0xd15e10: ldr             lr, [x21, lr, lsl #3]
    //     0xd15e14: blr             lr
    // 0xd15e18: add             SP, SP, #0x10
    // 0xd15e1c: cmp             w0, NULL
    // 0xd15e20: b.ne            #0xd15e28
    // 0xd15e24: r0 = ""
    //     0xd15e24: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd15e28: ldr             x3, [fp, #0x10]
    // 0xd15e2c: r2 = Null
    //     0xd15e2c: mov             x2, NULL
    // 0xd15e30: r1 = Null
    //     0xd15e30: mov             x1, NULL
    // 0xd15e34: r4 = 59
    //     0xd15e34: mov             x4, #0x3b
    // 0xd15e38: branchIfSmi(r0, 0xd15e44)
    //     0xd15e38: tbz             w0, #0, #0xd15e44
    // 0xd15e3c: r4 = LoadClassIdInstr(r0)
    //     0xd15e3c: ldur            x4, [x0, #-1]
    //     0xd15e40: ubfx            x4, x4, #0xc, #0x14
    // 0xd15e44: sub             x4, x4, #0x5d
    // 0xd15e48: cmp             x4, #3
    // 0xd15e4c: b.ls            #0xd15e60
    // 0xd15e50: r8 = String
    //     0xd15e50: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd15e54: r3 = Null
    //     0xd15e54: add             x3, PP, #0x14, lsl #12  ; [pp+0x14d38] Null
    //     0xd15e58: ldr             x3, [x3, #0xd38]
    // 0xd15e5c: r0 = String()
    //     0xd15e5c: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd15e60: ldr             x1, [fp, #0x10]
    // 0xd15e64: r0 = LoadClassIdInstr(r1)
    //     0xd15e64: ldur            x0, [x1, #-1]
    //     0xd15e68: ubfx            x0, x0, #0xc, #0x14
    // 0xd15e6c: r16 = "device"
    //     0xd15e6c: ldr             x16, [PP, #0x3990]  ; [pp+0x3990] "device"
    // 0xd15e70: stp             x16, x1, [SP, #-0x10]!
    // 0xd15e74: r0 = GDT[cid_x0 + -0xef]()
    //     0xd15e74: sub             lr, x0, #0xef
    //     0xd15e78: ldr             lr, [x21, lr, lsl #3]
    //     0xd15e7c: blr             lr
    // 0xd15e80: add             SP, SP, #0x10
    // 0xd15e84: cmp             w0, NULL
    // 0xd15e88: b.ne            #0xd15e90
    // 0xd15e8c: r0 = ""
    //     0xd15e8c: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd15e90: ldr             x3, [fp, #0x10]
    // 0xd15e94: r2 = Null
    //     0xd15e94: mov             x2, NULL
    // 0xd15e98: r1 = Null
    //     0xd15e98: mov             x1, NULL
    // 0xd15e9c: r4 = 59
    //     0xd15e9c: mov             x4, #0x3b
    // 0xd15ea0: branchIfSmi(r0, 0xd15eac)
    //     0xd15ea0: tbz             w0, #0, #0xd15eac
    // 0xd15ea4: r4 = LoadClassIdInstr(r0)
    //     0xd15ea4: ldur            x4, [x0, #-1]
    //     0xd15ea8: ubfx            x4, x4, #0xc, #0x14
    // 0xd15eac: sub             x4, x4, #0x5d
    // 0xd15eb0: cmp             x4, #3
    // 0xd15eb4: b.ls            #0xd15ec8
    // 0xd15eb8: r8 = String
    //     0xd15eb8: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd15ebc: r3 = Null
    //     0xd15ebc: add             x3, PP, #0x14, lsl #12  ; [pp+0x14d48] Null
    //     0xd15ec0: ldr             x3, [x3, #0xd48]
    // 0xd15ec4: r0 = String()
    //     0xd15ec4: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd15ec8: ldr             x1, [fp, #0x10]
    // 0xd15ecc: r0 = LoadClassIdInstr(r1)
    //     0xd15ecc: ldur            x0, [x1, #-1]
    //     0xd15ed0: ubfx            x0, x0, #0xc, #0x14
    // 0xd15ed4: r16 = "display"
    //     0xd15ed4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14d58] "display"
    //     0xd15ed8: ldr             x16, [x16, #0xd58]
    // 0xd15edc: stp             x16, x1, [SP, #-0x10]!
    // 0xd15ee0: r0 = GDT[cid_x0 + -0xef]()
    //     0xd15ee0: sub             lr, x0, #0xef
    //     0xd15ee4: ldr             lr, [x21, lr, lsl #3]
    //     0xd15ee8: blr             lr
    // 0xd15eec: add             SP, SP, #0x10
    // 0xd15ef0: cmp             w0, NULL
    // 0xd15ef4: b.ne            #0xd15efc
    // 0xd15ef8: r0 = ""
    //     0xd15ef8: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd15efc: ldr             x3, [fp, #0x10]
    // 0xd15f00: r2 = Null
    //     0xd15f00: mov             x2, NULL
    // 0xd15f04: r1 = Null
    //     0xd15f04: mov             x1, NULL
    // 0xd15f08: r4 = 59
    //     0xd15f08: mov             x4, #0x3b
    // 0xd15f0c: branchIfSmi(r0, 0xd15f18)
    //     0xd15f0c: tbz             w0, #0, #0xd15f18
    // 0xd15f10: r4 = LoadClassIdInstr(r0)
    //     0xd15f10: ldur            x4, [x0, #-1]
    //     0xd15f14: ubfx            x4, x4, #0xc, #0x14
    // 0xd15f18: sub             x4, x4, #0x5d
    // 0xd15f1c: cmp             x4, #3
    // 0xd15f20: b.ls            #0xd15f34
    // 0xd15f24: r8 = String
    //     0xd15f24: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd15f28: r3 = Null
    //     0xd15f28: add             x3, PP, #0x14, lsl #12  ; [pp+0x14d60] Null
    //     0xd15f2c: ldr             x3, [x3, #0xd60]
    // 0xd15f30: r0 = String()
    //     0xd15f30: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd15f34: ldr             x1, [fp, #0x10]
    // 0xd15f38: r0 = LoadClassIdInstr(r1)
    //     0xd15f38: ldur            x0, [x1, #-1]
    //     0xd15f3c: ubfx            x0, x0, #0xc, #0x14
    // 0xd15f40: r16 = "fingerprint"
    //     0xd15f40: add             x16, PP, #0x14, lsl #12  ; [pp+0x14d70] "fingerprint"
    //     0xd15f44: ldr             x16, [x16, #0xd70]
    // 0xd15f48: stp             x16, x1, [SP, #-0x10]!
    // 0xd15f4c: r0 = GDT[cid_x0 + -0xef]()
    //     0xd15f4c: sub             lr, x0, #0xef
    //     0xd15f50: ldr             lr, [x21, lr, lsl #3]
    //     0xd15f54: blr             lr
    // 0xd15f58: add             SP, SP, #0x10
    // 0xd15f5c: cmp             w0, NULL
    // 0xd15f60: b.ne            #0xd15f68
    // 0xd15f64: r0 = ""
    //     0xd15f64: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd15f68: ldr             x3, [fp, #0x10]
    // 0xd15f6c: r2 = Null
    //     0xd15f6c: mov             x2, NULL
    // 0xd15f70: r1 = Null
    //     0xd15f70: mov             x1, NULL
    // 0xd15f74: r4 = 59
    //     0xd15f74: mov             x4, #0x3b
    // 0xd15f78: branchIfSmi(r0, 0xd15f84)
    //     0xd15f78: tbz             w0, #0, #0xd15f84
    // 0xd15f7c: r4 = LoadClassIdInstr(r0)
    //     0xd15f7c: ldur            x4, [x0, #-1]
    //     0xd15f80: ubfx            x4, x4, #0xc, #0x14
    // 0xd15f84: sub             x4, x4, #0x5d
    // 0xd15f88: cmp             x4, #3
    // 0xd15f8c: b.ls            #0xd15fa0
    // 0xd15f90: r8 = String
    //     0xd15f90: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd15f94: r3 = Null
    //     0xd15f94: add             x3, PP, #0x14, lsl #12  ; [pp+0x14d78] Null
    //     0xd15f98: ldr             x3, [x3, #0xd78]
    // 0xd15f9c: r0 = String()
    //     0xd15f9c: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd15fa0: ldr             x1, [fp, #0x10]
    // 0xd15fa4: r0 = LoadClassIdInstr(r1)
    //     0xd15fa4: ldur            x0, [x1, #-1]
    //     0xd15fa8: ubfx            x0, x0, #0xc, #0x14
    // 0xd15fac: r16 = "hardware"
    //     0xd15fac: add             x16, PP, #0x14, lsl #12  ; [pp+0x14d88] "hardware"
    //     0xd15fb0: ldr             x16, [x16, #0xd88]
    // 0xd15fb4: stp             x16, x1, [SP, #-0x10]!
    // 0xd15fb8: r0 = GDT[cid_x0 + -0xef]()
    //     0xd15fb8: sub             lr, x0, #0xef
    //     0xd15fbc: ldr             lr, [x21, lr, lsl #3]
    //     0xd15fc0: blr             lr
    // 0xd15fc4: add             SP, SP, #0x10
    // 0xd15fc8: cmp             w0, NULL
    // 0xd15fcc: b.ne            #0xd15fd4
    // 0xd15fd0: r0 = ""
    //     0xd15fd0: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd15fd4: ldr             x3, [fp, #0x10]
    // 0xd15fd8: r2 = Null
    //     0xd15fd8: mov             x2, NULL
    // 0xd15fdc: r1 = Null
    //     0xd15fdc: mov             x1, NULL
    // 0xd15fe0: r4 = 59
    //     0xd15fe0: mov             x4, #0x3b
    // 0xd15fe4: branchIfSmi(r0, 0xd15ff0)
    //     0xd15fe4: tbz             w0, #0, #0xd15ff0
    // 0xd15fe8: r4 = LoadClassIdInstr(r0)
    //     0xd15fe8: ldur            x4, [x0, #-1]
    //     0xd15fec: ubfx            x4, x4, #0xc, #0x14
    // 0xd15ff0: sub             x4, x4, #0x5d
    // 0xd15ff4: cmp             x4, #3
    // 0xd15ff8: b.ls            #0xd1600c
    // 0xd15ffc: r8 = String
    //     0xd15ffc: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd16000: r3 = Null
    //     0xd16000: add             x3, PP, #0x14, lsl #12  ; [pp+0x14d90] Null
    //     0xd16004: ldr             x3, [x3, #0xd90]
    // 0xd16008: r0 = String()
    //     0xd16008: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd1600c: ldr             x1, [fp, #0x10]
    // 0xd16010: r0 = LoadClassIdInstr(r1)
    //     0xd16010: ldur            x0, [x1, #-1]
    //     0xd16014: ubfx            x0, x0, #0xc, #0x14
    // 0xd16018: r16 = "host"
    //     0xd16018: ldr             x16, [PP, #0x2680]  ; [pp+0x2680] "host"
    // 0xd1601c: stp             x16, x1, [SP, #-0x10]!
    // 0xd16020: r0 = GDT[cid_x0 + -0xef]()
    //     0xd16020: sub             lr, x0, #0xef
    //     0xd16024: ldr             lr, [x21, lr, lsl #3]
    //     0xd16028: blr             lr
    // 0xd1602c: add             SP, SP, #0x10
    // 0xd16030: cmp             w0, NULL
    // 0xd16034: b.ne            #0xd1603c
    // 0xd16038: r0 = ""
    //     0xd16038: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd1603c: ldr             x3, [fp, #0x10]
    // 0xd16040: r2 = Null
    //     0xd16040: mov             x2, NULL
    // 0xd16044: r1 = Null
    //     0xd16044: mov             x1, NULL
    // 0xd16048: r4 = 59
    //     0xd16048: mov             x4, #0x3b
    // 0xd1604c: branchIfSmi(r0, 0xd16058)
    //     0xd1604c: tbz             w0, #0, #0xd16058
    // 0xd16050: r4 = LoadClassIdInstr(r0)
    //     0xd16050: ldur            x4, [x0, #-1]
    //     0xd16054: ubfx            x4, x4, #0xc, #0x14
    // 0xd16058: sub             x4, x4, #0x5d
    // 0xd1605c: cmp             x4, #3
    // 0xd16060: b.ls            #0xd16074
    // 0xd16064: r8 = String
    //     0xd16064: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd16068: r3 = Null
    //     0xd16068: add             x3, PP, #0x14, lsl #12  ; [pp+0x14da0] Null
    //     0xd1606c: ldr             x3, [x3, #0xda0]
    // 0xd16070: r0 = String()
    //     0xd16070: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd16074: ldr             x1, [fp, #0x10]
    // 0xd16078: r0 = LoadClassIdInstr(r1)
    //     0xd16078: ldur            x0, [x1, #-1]
    //     0xd1607c: ubfx            x0, x0, #0xc, #0x14
    // 0xd16080: r16 = "id"
    //     0xd16080: ldr             x16, [PP, #0x2a60]  ; [pp+0x2a60] "id"
    // 0xd16084: stp             x16, x1, [SP, #-0x10]!
    // 0xd16088: r0 = GDT[cid_x0 + -0xef]()
    //     0xd16088: sub             lr, x0, #0xef
    //     0xd1608c: ldr             lr, [x21, lr, lsl #3]
    //     0xd16090: blr             lr
    // 0xd16094: add             SP, SP, #0x10
    // 0xd16098: cmp             w0, NULL
    // 0xd1609c: b.ne            #0xd160a4
    // 0xd160a0: r0 = ""
    //     0xd160a0: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd160a4: ldr             x3, [fp, #0x10]
    // 0xd160a8: r2 = Null
    //     0xd160a8: mov             x2, NULL
    // 0xd160ac: r1 = Null
    //     0xd160ac: mov             x1, NULL
    // 0xd160b0: r4 = 59
    //     0xd160b0: mov             x4, #0x3b
    // 0xd160b4: branchIfSmi(r0, 0xd160c0)
    //     0xd160b4: tbz             w0, #0, #0xd160c0
    // 0xd160b8: r4 = LoadClassIdInstr(r0)
    //     0xd160b8: ldur            x4, [x0, #-1]
    //     0xd160bc: ubfx            x4, x4, #0xc, #0x14
    // 0xd160c0: sub             x4, x4, #0x5d
    // 0xd160c4: cmp             x4, #3
    // 0xd160c8: b.ls            #0xd160dc
    // 0xd160cc: r8 = String
    //     0xd160cc: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd160d0: r3 = Null
    //     0xd160d0: add             x3, PP, #0x14, lsl #12  ; [pp+0x14db0] Null
    //     0xd160d4: ldr             x3, [x3, #0xdb0]
    // 0xd160d8: r0 = String()
    //     0xd160d8: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd160dc: ldr             x1, [fp, #0x10]
    // 0xd160e0: r0 = LoadClassIdInstr(r1)
    //     0xd160e0: ldur            x0, [x1, #-1]
    //     0xd160e4: ubfx            x0, x0, #0xc, #0x14
    // 0xd160e8: r16 = "manufacturer"
    //     0xd160e8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14dc0] "manufacturer"
    //     0xd160ec: ldr             x16, [x16, #0xdc0]
    // 0xd160f0: stp             x16, x1, [SP, #-0x10]!
    // 0xd160f4: r0 = GDT[cid_x0 + -0xef]()
    //     0xd160f4: sub             lr, x0, #0xef
    //     0xd160f8: ldr             lr, [x21, lr, lsl #3]
    //     0xd160fc: blr             lr
    // 0xd16100: add             SP, SP, #0x10
    // 0xd16104: cmp             w0, NULL
    // 0xd16108: b.ne            #0xd16110
    // 0xd1610c: r0 = ""
    //     0xd1610c: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd16110: ldr             x3, [fp, #0x10]
    // 0xd16114: r2 = Null
    //     0xd16114: mov             x2, NULL
    // 0xd16118: r1 = Null
    //     0xd16118: mov             x1, NULL
    // 0xd1611c: r4 = 59
    //     0xd1611c: mov             x4, #0x3b
    // 0xd16120: branchIfSmi(r0, 0xd1612c)
    //     0xd16120: tbz             w0, #0, #0xd1612c
    // 0xd16124: r4 = LoadClassIdInstr(r0)
    //     0xd16124: ldur            x4, [x0, #-1]
    //     0xd16128: ubfx            x4, x4, #0xc, #0x14
    // 0xd1612c: sub             x4, x4, #0x5d
    // 0xd16130: cmp             x4, #3
    // 0xd16134: b.ls            #0xd16148
    // 0xd16138: r8 = String
    //     0xd16138: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd1613c: r3 = Null
    //     0xd1613c: add             x3, PP, #0x14, lsl #12  ; [pp+0x14dc8] Null
    //     0xd16140: ldr             x3, [x3, #0xdc8]
    // 0xd16144: r0 = String()
    //     0xd16144: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd16148: ldr             x1, [fp, #0x10]
    // 0xd1614c: r0 = LoadClassIdInstr(r1)
    //     0xd1614c: ldur            x0, [x1, #-1]
    //     0xd16150: ubfx            x0, x0, #0xc, #0x14
    // 0xd16154: r16 = "model"
    //     0xd16154: add             x16, PP, #0x14, lsl #12  ; [pp+0x14bc0] "model"
    //     0xd16158: ldr             x16, [x16, #0xbc0]
    // 0xd1615c: stp             x16, x1, [SP, #-0x10]!
    // 0xd16160: r0 = GDT[cid_x0 + -0xef]()
    //     0xd16160: sub             lr, x0, #0xef
    //     0xd16164: ldr             lr, [x21, lr, lsl #3]
    //     0xd16168: blr             lr
    // 0xd1616c: add             SP, SP, #0x10
    // 0xd16170: cmp             w0, NULL
    // 0xd16174: b.ne            #0xd1617c
    // 0xd16178: r0 = ""
    //     0xd16178: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd1617c: ldr             x3, [fp, #0x10]
    // 0xd16180: r2 = Null
    //     0xd16180: mov             x2, NULL
    // 0xd16184: r1 = Null
    //     0xd16184: mov             x1, NULL
    // 0xd16188: r4 = 59
    //     0xd16188: mov             x4, #0x3b
    // 0xd1618c: branchIfSmi(r0, 0xd16198)
    //     0xd1618c: tbz             w0, #0, #0xd16198
    // 0xd16190: r4 = LoadClassIdInstr(r0)
    //     0xd16190: ldur            x4, [x0, #-1]
    //     0xd16194: ubfx            x4, x4, #0xc, #0x14
    // 0xd16198: sub             x4, x4, #0x5d
    // 0xd1619c: cmp             x4, #3
    // 0xd161a0: b.ls            #0xd161b4
    // 0xd161a4: r8 = String
    //     0xd161a4: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd161a8: r3 = Null
    //     0xd161a8: add             x3, PP, #0x14, lsl #12  ; [pp+0x14dd8] Null
    //     0xd161ac: ldr             x3, [x3, #0xdd8]
    // 0xd161b0: r0 = String()
    //     0xd161b0: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd161b4: ldr             x1, [fp, #0x10]
    // 0xd161b8: r0 = LoadClassIdInstr(r1)
    //     0xd161b8: ldur            x0, [x1, #-1]
    //     0xd161bc: ubfx            x0, x0, #0xc, #0x14
    // 0xd161c0: r16 = "product"
    //     0xd161c0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14de8] "product"
    //     0xd161c4: ldr             x16, [x16, #0xde8]
    // 0xd161c8: stp             x16, x1, [SP, #-0x10]!
    // 0xd161cc: r0 = GDT[cid_x0 + -0xef]()
    //     0xd161cc: sub             lr, x0, #0xef
    //     0xd161d0: ldr             lr, [x21, lr, lsl #3]
    //     0xd161d4: blr             lr
    // 0xd161d8: add             SP, SP, #0x10
    // 0xd161dc: cmp             w0, NULL
    // 0xd161e0: b.ne            #0xd161e8
    // 0xd161e4: r0 = ""
    //     0xd161e4: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd161e8: ldr             x3, [fp, #0x10]
    // 0xd161ec: r2 = Null
    //     0xd161ec: mov             x2, NULL
    // 0xd161f0: r1 = Null
    //     0xd161f0: mov             x1, NULL
    // 0xd161f4: r4 = 59
    //     0xd161f4: mov             x4, #0x3b
    // 0xd161f8: branchIfSmi(r0, 0xd16204)
    //     0xd161f8: tbz             w0, #0, #0xd16204
    // 0xd161fc: r4 = LoadClassIdInstr(r0)
    //     0xd161fc: ldur            x4, [x0, #-1]
    //     0xd16200: ubfx            x4, x4, #0xc, #0x14
    // 0xd16204: sub             x4, x4, #0x5d
    // 0xd16208: cmp             x4, #3
    // 0xd1620c: b.ls            #0xd16220
    // 0xd16210: r8 = String
    //     0xd16210: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd16214: r3 = Null
    //     0xd16214: add             x3, PP, #0x14, lsl #12  ; [pp+0x14df0] Null
    //     0xd16218: ldr             x3, [x3, #0xdf0]
    // 0xd1621c: r0 = String()
    //     0xd1621c: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd16220: ldr             x1, [fp, #0x10]
    // 0xd16224: r0 = LoadClassIdInstr(r1)
    //     0xd16224: ldur            x0, [x1, #-1]
    //     0xd16228: ubfx            x0, x0, #0xc, #0x14
    // 0xd1622c: r16 = "supported32BitAbis"
    //     0xd1622c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e00] "supported32BitAbis"
    //     0xd16230: ldr             x16, [x16, #0xe00]
    // 0xd16234: stp             x16, x1, [SP, #-0x10]!
    // 0xd16238: r0 = GDT[cid_x0 + -0xef]()
    //     0xd16238: sub             lr, x0, #0xef
    //     0xd1623c: ldr             lr, [x21, lr, lsl #3]
    //     0xd16240: blr             lr
    // 0xd16244: add             SP, SP, #0x10
    // 0xd16248: SaveReg r0
    //     0xd16248: str             x0, [SP, #-8]!
    // 0xd1624c: r0 = _fromList()
    //     0xd1624c: bl              #0x8792b8  ; [package:device_info_platform_interface/model/android_device_info.dart] AndroidDeviceInfo::_fromList
    // 0xd16250: add             SP, SP, #8
    // 0xd16254: mov             x2, x0
    // 0xd16258: ldr             x1, [fp, #0x10]
    // 0xd1625c: stur            x2, [fp, #-8]
    // 0xd16260: r0 = LoadClassIdInstr(r1)
    //     0xd16260: ldur            x0, [x1, #-1]
    //     0xd16264: ubfx            x0, x0, #0xc, #0x14
    // 0xd16268: r16 = "supported64BitAbis"
    //     0xd16268: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e08] "supported64BitAbis"
    //     0xd1626c: ldr             x16, [x16, #0xe08]
    // 0xd16270: stp             x16, x1, [SP, #-0x10]!
    // 0xd16274: r0 = GDT[cid_x0 + -0xef]()
    //     0xd16274: sub             lr, x0, #0xef
    //     0xd16278: ldr             lr, [x21, lr, lsl #3]
    //     0xd1627c: blr             lr
    // 0xd16280: add             SP, SP, #0x10
    // 0xd16284: SaveReg r0
    //     0xd16284: str             x0, [SP, #-8]!
    // 0xd16288: r0 = _fromList()
    //     0xd16288: bl              #0x8792b8  ; [package:device_info_platform_interface/model/android_device_info.dart] AndroidDeviceInfo::_fromList
    // 0xd1628c: add             SP, SP, #8
    // 0xd16290: mov             x2, x0
    // 0xd16294: ldr             x1, [fp, #0x10]
    // 0xd16298: stur            x2, [fp, #-0x10]
    // 0xd1629c: r0 = LoadClassIdInstr(r1)
    //     0xd1629c: ldur            x0, [x1, #-1]
    //     0xd162a0: ubfx            x0, x0, #0xc, #0x14
    // 0xd162a4: r16 = "supportedAbis"
    //     0xd162a4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e10] "supportedAbis"
    //     0xd162a8: ldr             x16, [x16, #0xe10]
    // 0xd162ac: stp             x16, x1, [SP, #-0x10]!
    // 0xd162b0: r0 = GDT[cid_x0 + -0xef]()
    //     0xd162b0: sub             lr, x0, #0xef
    //     0xd162b4: ldr             lr, [x21, lr, lsl #3]
    //     0xd162b8: blr             lr
    // 0xd162bc: add             SP, SP, #0x10
    // 0xd162c0: SaveReg r0
    //     0xd162c0: str             x0, [SP, #-8]!
    // 0xd162c4: r0 = _fromList()
    //     0xd162c4: bl              #0x8792b8  ; [package:device_info_platform_interface/model/android_device_info.dart] AndroidDeviceInfo::_fromList
    // 0xd162c8: add             SP, SP, #8
    // 0xd162cc: mov             x2, x0
    // 0xd162d0: ldr             x1, [fp, #0x10]
    // 0xd162d4: stur            x2, [fp, #-0x18]
    // 0xd162d8: r0 = LoadClassIdInstr(r1)
    //     0xd162d8: ldur            x0, [x1, #-1]
    //     0xd162dc: ubfx            x0, x0, #0xc, #0x14
    // 0xd162e0: r16 = "tags"
    //     0xd162e0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e18] "tags"
    //     0xd162e4: ldr             x16, [x16, #0xe18]
    // 0xd162e8: stp             x16, x1, [SP, #-0x10]!
    // 0xd162ec: r0 = GDT[cid_x0 + -0xef]()
    //     0xd162ec: sub             lr, x0, #0xef
    //     0xd162f0: ldr             lr, [x21, lr, lsl #3]
    //     0xd162f4: blr             lr
    // 0xd162f8: add             SP, SP, #0x10
    // 0xd162fc: cmp             w0, NULL
    // 0xd16300: b.ne            #0xd16308
    // 0xd16304: r0 = ""
    //     0xd16304: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd16308: ldr             x3, [fp, #0x10]
    // 0xd1630c: r2 = Null
    //     0xd1630c: mov             x2, NULL
    // 0xd16310: r1 = Null
    //     0xd16310: mov             x1, NULL
    // 0xd16314: r4 = 59
    //     0xd16314: mov             x4, #0x3b
    // 0xd16318: branchIfSmi(r0, 0xd16324)
    //     0xd16318: tbz             w0, #0, #0xd16324
    // 0xd1631c: r4 = LoadClassIdInstr(r0)
    //     0xd1631c: ldur            x4, [x0, #-1]
    //     0xd16320: ubfx            x4, x4, #0xc, #0x14
    // 0xd16324: sub             x4, x4, #0x5d
    // 0xd16328: cmp             x4, #3
    // 0xd1632c: b.ls            #0xd16340
    // 0xd16330: r8 = String
    //     0xd16330: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd16334: r3 = Null
    //     0xd16334: add             x3, PP, #0x14, lsl #12  ; [pp+0x14e20] Null
    //     0xd16338: ldr             x3, [x3, #0xe20]
    // 0xd1633c: r0 = String()
    //     0xd1633c: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd16340: ldr             x1, [fp, #0x10]
    // 0xd16344: r0 = LoadClassIdInstr(r1)
    //     0xd16344: ldur            x0, [x1, #-1]
    //     0xd16348: ubfx            x0, x0, #0xc, #0x14
    // 0xd1634c: r16 = "type"
    //     0xd1634c: ldr             x16, [PP, #0x1db8]  ; [pp+0x1db8] "type"
    // 0xd16350: stp             x16, x1, [SP, #-0x10]!
    // 0xd16354: r0 = GDT[cid_x0 + -0xef]()
    //     0xd16354: sub             lr, x0, #0xef
    //     0xd16358: ldr             lr, [x21, lr, lsl #3]
    //     0xd1635c: blr             lr
    // 0xd16360: add             SP, SP, #0x10
    // 0xd16364: cmp             w0, NULL
    // 0xd16368: b.ne            #0xd16370
    // 0xd1636c: r0 = ""
    //     0xd1636c: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd16370: ldr             x3, [fp, #0x10]
    // 0xd16374: r2 = Null
    //     0xd16374: mov             x2, NULL
    // 0xd16378: r1 = Null
    //     0xd16378: mov             x1, NULL
    // 0xd1637c: r4 = 59
    //     0xd1637c: mov             x4, #0x3b
    // 0xd16380: branchIfSmi(r0, 0xd1638c)
    //     0xd16380: tbz             w0, #0, #0xd1638c
    // 0xd16384: r4 = LoadClassIdInstr(r0)
    //     0xd16384: ldur            x4, [x0, #-1]
    //     0xd16388: ubfx            x4, x4, #0xc, #0x14
    // 0xd1638c: sub             x4, x4, #0x5d
    // 0xd16390: cmp             x4, #3
    // 0xd16394: b.ls            #0xd163a8
    // 0xd16398: r8 = String
    //     0xd16398: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd1639c: r3 = Null
    //     0xd1639c: add             x3, PP, #0x14, lsl #12  ; [pp+0x14e30] Null
    //     0xd163a0: ldr             x3, [x3, #0xe30]
    // 0xd163a4: r0 = String()
    //     0xd163a4: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd163a8: ldr             x1, [fp, #0x10]
    // 0xd163ac: r0 = LoadClassIdInstr(r1)
    //     0xd163ac: ldur            x0, [x1, #-1]
    //     0xd163b0: ubfx            x0, x0, #0xc, #0x14
    // 0xd163b4: r16 = "isPhysicalDevice"
    //     0xd163b4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14c08] "isPhysicalDevice"
    //     0xd163b8: ldr             x16, [x16, #0xc08]
    // 0xd163bc: stp             x16, x1, [SP, #-0x10]!
    // 0xd163c0: r0 = GDT[cid_x0 + -0xef]()
    //     0xd163c0: sub             lr, x0, #0xef
    //     0xd163c4: ldr             lr, [x21, lr, lsl #3]
    //     0xd163c8: blr             lr
    // 0xd163cc: add             SP, SP, #0x10
    // 0xd163d0: cmp             w0, NULL
    // 0xd163d4: b.ne            #0xd163dc
    // 0xd163d8: r0 = false
    //     0xd163d8: add             x0, NULL, #0x30  ; false
    // 0xd163dc: ldr             x3, [fp, #0x10]
    // 0xd163e0: r2 = Null
    //     0xd163e0: mov             x2, NULL
    // 0xd163e4: r1 = Null
    //     0xd163e4: mov             x1, NULL
    // 0xd163e8: r4 = 59
    //     0xd163e8: mov             x4, #0x3b
    // 0xd163ec: branchIfSmi(r0, 0xd163f8)
    //     0xd163ec: tbz             w0, #0, #0xd163f8
    // 0xd163f0: r4 = LoadClassIdInstr(r0)
    //     0xd163f0: ldur            x4, [x0, #-1]
    //     0xd163f4: ubfx            x4, x4, #0xc, #0x14
    // 0xd163f8: cmp             x4, #0x3e
    // 0xd163fc: b.eq            #0xd16410
    // 0xd16400: r8 = bool
    //     0xd16400: ldr             x8, [PP, #0x13e0]  ; [pp+0x13e0] Type: bool
    // 0xd16404: r3 = Null
    //     0xd16404: add             x3, PP, #0x14, lsl #12  ; [pp+0x14e40] Null
    //     0xd16408: ldr             x3, [x3, #0xe40]
    // 0xd1640c: r0 = bool()
    //     0xd1640c: bl              #0xd72a3c  ; IsType_bool_Stub
    // 0xd16410: ldr             x1, [fp, #0x10]
    // 0xd16414: r0 = LoadClassIdInstr(r1)
    //     0xd16414: ldur            x0, [x1, #-1]
    //     0xd16418: ubfx            x0, x0, #0xc, #0x14
    // 0xd1641c: r16 = "androidId"
    //     0xd1641c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e50] "androidId"
    //     0xd16420: ldr             x16, [x16, #0xe50]
    // 0xd16424: stp             x16, x1, [SP, #-0x10]!
    // 0xd16428: r0 = GDT[cid_x0 + -0xef]()
    //     0xd16428: sub             lr, x0, #0xef
    //     0xd1642c: ldr             lr, [x21, lr, lsl #3]
    //     0xd16430: blr             lr
    // 0xd16434: add             SP, SP, #0x10
    // 0xd16438: cmp             w0, NULL
    // 0xd1643c: b.ne            #0xd16448
    // 0xd16440: r4 = ""
    //     0xd16440: ldr             x4, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd16444: b               #0xd1644c
    // 0xd16448: mov             x4, x0
    // 0xd1644c: ldr             x3, [fp, #0x10]
    // 0xd16450: mov             x0, x4
    // 0xd16454: stur            x4, [fp, #-0x20]
    // 0xd16458: r2 = Null
    //     0xd16458: mov             x2, NULL
    // 0xd1645c: r1 = Null
    //     0xd1645c: mov             x1, NULL
    // 0xd16460: r4 = 59
    //     0xd16460: mov             x4, #0x3b
    // 0xd16464: branchIfSmi(r0, 0xd16470)
    //     0xd16464: tbz             w0, #0, #0xd16470
    // 0xd16468: r4 = LoadClassIdInstr(r0)
    //     0xd16468: ldur            x4, [x0, #-1]
    //     0xd1646c: ubfx            x4, x4, #0xc, #0x14
    // 0xd16470: sub             x4, x4, #0x5d
    // 0xd16474: cmp             x4, #3
    // 0xd16478: b.ls            #0xd1648c
    // 0xd1647c: r8 = String
    //     0xd1647c: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd16480: r3 = Null
    //     0xd16480: add             x3, PP, #0x14, lsl #12  ; [pp+0x14e58] Null
    //     0xd16484: ldr             x3, [x3, #0xe58]
    // 0xd16488: r0 = String()
    //     0xd16488: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd1648c: ldr             x0, [fp, #0x10]
    // 0xd16490: r1 = LoadClassIdInstr(r0)
    //     0xd16490: ldur            x1, [x0, #-1]
    //     0xd16494: ubfx            x1, x1, #0xc, #0x14
    // 0xd16498: r16 = "systemFeatures"
    //     0xd16498: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e68] "systemFeatures"
    //     0xd1649c: ldr             x16, [x16, #0xe68]
    // 0xd164a0: stp             x16, x0, [SP, #-0x10]!
    // 0xd164a4: mov             x0, x1
    // 0xd164a8: r0 = GDT[cid_x0 + -0xef]()
    //     0xd164a8: sub             lr, x0, #0xef
    //     0xd164ac: ldr             lr, [x21, lr, lsl #3]
    //     0xd164b0: blr             lr
    // 0xd164b4: add             SP, SP, #0x10
    // 0xd164b8: SaveReg r0
    //     0xd164b8: str             x0, [SP, #-8]!
    // 0xd164bc: r0 = _fromList()
    //     0xd164bc: bl              #0x8792b8  ; [package:device_info_platform_interface/model/android_device_info.dart] AndroidDeviceInfo::_fromList
    // 0xd164c0: add             SP, SP, #8
    // 0xd164c4: stur            x0, [fp, #-0x28]
    // 0xd164c8: r0 = AndroidDeviceInfo()
    //     0xd164c8: bl              #0xd16630  ; AllocateAndroidDeviceInfoStub -> AndroidDeviceInfo (size=0xc)
    // 0xd164cc: stur            x0, [fp, #-0x30]
    // 0xd164d0: ldur            x16, [fp, #-0x20]
    // 0xd164d4: stp             x16, x0, [SP, #-0x10]!
    // 0xd164d8: ldur            x16, [fp, #-8]
    // 0xd164dc: ldur            lr, [fp, #-0x10]
    // 0xd164e0: stp             lr, x16, [SP, #-0x10]!
    // 0xd164e4: ldur            x16, [fp, #-0x18]
    // 0xd164e8: ldur            lr, [fp, #-0x28]
    // 0xd164ec: stp             lr, x16, [SP, #-0x10]!
    // 0xd164f0: r0 = AndroidDeviceInfo()
    //     0xd164f0: bl              #0xd16510  ; [package:device_info_platform_interface/model/android_device_info.dart] AndroidDeviceInfo::AndroidDeviceInfo
    // 0xd164f4: add             SP, SP, #0x30
    // 0xd164f8: ldur            x0, [fp, #-0x30]
    // 0xd164fc: LeaveFrame
    //     0xd164fc: mov             SP, fp
    //     0xd16500: ldp             fp, lr, [SP], #0x10
    // 0xd16504: ret
    //     0xd16504: ret             
    // 0xd16508: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd16508: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1650c: b               #0xd15c4c
  }
  _ AndroidDeviceInfo(/* No info */) {
    // ** addr: 0xd16510, size: 0x120
    // 0xd16510: EnterFrame
    //     0xd16510: stp             fp, lr, [SP, #-0x10]!
    //     0xd16514: mov             fp, SP
    // 0xd16518: CheckStackOverflow
    //     0xd16518: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd1651c: cmp             SP, x16
    //     0xd16520: b.ls            #0xd16628
    // 0xd16524: ldr             x0, [fp, #0x30]
    // 0xd16528: ldr             x1, [fp, #0x38]
    // 0xd1652c: StoreField: r1->field_7 = r0
    //     0xd1652c: stur            w0, [x1, #7]
    //     0xd16530: ldurb           w16, [x1, #-1]
    //     0xd16534: ldurb           w17, [x0, #-1]
    //     0xd16538: and             x16, x17, x16, lsr #2
    //     0xd1653c: tst             x16, HEAP, lsr #32
    //     0xd16540: b.eq            #0xd16548
    //     0xd16544: bl              #0xd6826c
    // 0xd16548: r16 = <String>
    //     0xd16548: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xd1654c: ldr             lr, [fp, #0x28]
    // 0xd16550: stp             lr, x16, [SP, #-0x10]!
    // 0xd16554: r16 = false
    //     0xd16554: add             x16, NULL, #0x30  ; false
    // 0xd16558: SaveReg r16
    //     0xd16558: str             x16, [SP, #-8]!
    // 0xd1655c: r4 = const [0, 0x3, 0x3, 0x2, growable, 0x2, null]
    //     0xd1655c: ldr             x4, [PP, #0xc20]  ; [pp+0xc20] List(7) [0, 0x3, 0x3, 0x2, "growable", 0x2, Null]
    // 0xd16560: r0 = List.from()
    //     0xd16560: bl              #0x4c85f8  ; [dart:core] List::List.from
    // 0xd16564: add             SP, SP, #0x18
    // 0xd16568: r16 = <String>
    //     0xd16568: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xd1656c: stp             x0, x16, [SP, #-0x10]!
    // 0xd16570: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd16570: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd16574: r0 = makeFixedListUnmodifiable()
    //     0xd16574: bl              #0x5a58e4  ; [dart:_internal] ::makeFixedListUnmodifiable
    // 0xd16578: add             SP, SP, #0x10
    // 0xd1657c: r16 = <String>
    //     0xd1657c: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xd16580: ldr             lr, [fp, #0x20]
    // 0xd16584: stp             lr, x16, [SP, #-0x10]!
    // 0xd16588: r16 = false
    //     0xd16588: add             x16, NULL, #0x30  ; false
    // 0xd1658c: SaveReg r16
    //     0xd1658c: str             x16, [SP, #-8]!
    // 0xd16590: r4 = const [0, 0x3, 0x3, 0x2, growable, 0x2, null]
    //     0xd16590: ldr             x4, [PP, #0xc20]  ; [pp+0xc20] List(7) [0, 0x3, 0x3, 0x2, "growable", 0x2, Null]
    // 0xd16594: r0 = List.from()
    //     0xd16594: bl              #0x4c85f8  ; [dart:core] List::List.from
    // 0xd16598: add             SP, SP, #0x18
    // 0xd1659c: r16 = <String>
    //     0xd1659c: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xd165a0: stp             x0, x16, [SP, #-0x10]!
    // 0xd165a4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd165a4: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd165a8: r0 = makeFixedListUnmodifiable()
    //     0xd165a8: bl              #0x5a58e4  ; [dart:_internal] ::makeFixedListUnmodifiable
    // 0xd165ac: add             SP, SP, #0x10
    // 0xd165b0: r16 = <String>
    //     0xd165b0: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xd165b4: ldr             lr, [fp, #0x18]
    // 0xd165b8: stp             lr, x16, [SP, #-0x10]!
    // 0xd165bc: r16 = false
    //     0xd165bc: add             x16, NULL, #0x30  ; false
    // 0xd165c0: SaveReg r16
    //     0xd165c0: str             x16, [SP, #-8]!
    // 0xd165c4: r4 = const [0, 0x3, 0x3, 0x2, growable, 0x2, null]
    //     0xd165c4: ldr             x4, [PP, #0xc20]  ; [pp+0xc20] List(7) [0, 0x3, 0x3, 0x2, "growable", 0x2, Null]
    // 0xd165c8: r0 = List.from()
    //     0xd165c8: bl              #0x4c85f8  ; [dart:core] List::List.from
    // 0xd165cc: add             SP, SP, #0x18
    // 0xd165d0: r16 = <String>
    //     0xd165d0: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xd165d4: stp             x0, x16, [SP, #-0x10]!
    // 0xd165d8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd165d8: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd165dc: r0 = makeFixedListUnmodifiable()
    //     0xd165dc: bl              #0x5a58e4  ; [dart:_internal] ::makeFixedListUnmodifiable
    // 0xd165e0: add             SP, SP, #0x10
    // 0xd165e4: r16 = <String>
    //     0xd165e4: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xd165e8: ldr             lr, [fp, #0x10]
    // 0xd165ec: stp             lr, x16, [SP, #-0x10]!
    // 0xd165f0: r16 = false
    //     0xd165f0: add             x16, NULL, #0x30  ; false
    // 0xd165f4: SaveReg r16
    //     0xd165f4: str             x16, [SP, #-8]!
    // 0xd165f8: r4 = const [0, 0x3, 0x3, 0x2, growable, 0x2, null]
    //     0xd165f8: ldr             x4, [PP, #0xc20]  ; [pp+0xc20] List(7) [0, 0x3, 0x3, 0x2, "growable", 0x2, Null]
    // 0xd165fc: r0 = List.from()
    //     0xd165fc: bl              #0x4c85f8  ; [dart:core] List::List.from
    // 0xd16600: add             SP, SP, #0x18
    // 0xd16604: r16 = <String>
    //     0xd16604: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xd16608: stp             x0, x16, [SP, #-0x10]!
    // 0xd1660c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd1660c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd16610: r0 = makeFixedListUnmodifiable()
    //     0xd16610: bl              #0x5a58e4  ; [dart:_internal] ::makeFixedListUnmodifiable
    // 0xd16614: add             SP, SP, #0x10
    // 0xd16618: r0 = Null
    //     0xd16618: mov             x0, NULL
    // 0xd1661c: LeaveFrame
    //     0xd1661c: mov             SP, fp
    //     0xd16620: ldp             fp, lr, [SP], #0x10
    // 0xd16624: ret
    //     0xd16624: ret             
    // 0xd16628: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd16628: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1662c: b               #0xd16524
  }
}

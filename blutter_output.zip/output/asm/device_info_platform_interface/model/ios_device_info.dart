// lib: , url: package:device_info_platform_interface/model/ios_device_info.dart

// class id: 1048865, size: 0x8
class :: {
}

// class id: 4561, size: 0x8, field offset: 0x8
class IosUtsname extends Object {

  static _ _fromMap(/* No info */) {
    // ** addr: 0xd15758, size: 0x248
    // 0xd15758: EnterFrame
    //     0xd15758: stp             fp, lr, [SP, #-0x10]!
    //     0xd1575c: mov             fp, SP
    // 0xd15760: CheckStackOverflow
    //     0xd15760: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd15764: cmp             SP, x16
    //     0xd15768: b.ls            #0xd15998
    // 0xd1576c: ldr             x1, [fp, #0x10]
    // 0xd15770: r0 = LoadClassIdInstr(r1)
    //     0xd15770: ldur            x0, [x1, #-1]
    //     0xd15774: ubfx            x0, x0, #0xc, #0x14
    // 0xd15778: r16 = "sysname"
    //     0xd15778: add             x16, PP, #0x14, lsl #12  ; [pp+0x14c38] "sysname"
    //     0xd1577c: ldr             x16, [x16, #0xc38]
    // 0xd15780: stp             x16, x1, [SP, #-0x10]!
    // 0xd15784: r0 = GDT[cid_x0 + -0xef]()
    //     0xd15784: sub             lr, x0, #0xef
    //     0xd15788: ldr             lr, [x21, lr, lsl #3]
    //     0xd1578c: blr             lr
    // 0xd15790: add             SP, SP, #0x10
    // 0xd15794: cmp             w0, NULL
    // 0xd15798: b.ne            #0xd157a0
    // 0xd1579c: r0 = ""
    //     0xd1579c: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd157a0: ldr             x3, [fp, #0x10]
    // 0xd157a4: r2 = Null
    //     0xd157a4: mov             x2, NULL
    // 0xd157a8: r1 = Null
    //     0xd157a8: mov             x1, NULL
    // 0xd157ac: r4 = 59
    //     0xd157ac: mov             x4, #0x3b
    // 0xd157b0: branchIfSmi(r0, 0xd157bc)
    //     0xd157b0: tbz             w0, #0, #0xd157bc
    // 0xd157b4: r4 = LoadClassIdInstr(r0)
    //     0xd157b4: ldur            x4, [x0, #-1]
    //     0xd157b8: ubfx            x4, x4, #0xc, #0x14
    // 0xd157bc: sub             x4, x4, #0x5d
    // 0xd157c0: cmp             x4, #3
    // 0xd157c4: b.ls            #0xd157d8
    // 0xd157c8: r8 = String
    //     0xd157c8: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd157cc: r3 = Null
    //     0xd157cc: add             x3, PP, #0x14, lsl #12  ; [pp+0x14c40] Null
    //     0xd157d0: ldr             x3, [x3, #0xc40]
    // 0xd157d4: r0 = String()
    //     0xd157d4: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd157d8: ldr             x1, [fp, #0x10]
    // 0xd157dc: r0 = LoadClassIdInstr(r1)
    //     0xd157dc: ldur            x0, [x1, #-1]
    //     0xd157e0: ubfx            x0, x0, #0xc, #0x14
    // 0xd157e4: r16 = "nodename"
    //     0xd157e4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14c50] "nodename"
    //     0xd157e8: ldr             x16, [x16, #0xc50]
    // 0xd157ec: stp             x16, x1, [SP, #-0x10]!
    // 0xd157f0: r0 = GDT[cid_x0 + -0xef]()
    //     0xd157f0: sub             lr, x0, #0xef
    //     0xd157f4: ldr             lr, [x21, lr, lsl #3]
    //     0xd157f8: blr             lr
    // 0xd157fc: add             SP, SP, #0x10
    // 0xd15800: cmp             w0, NULL
    // 0xd15804: b.ne            #0xd1580c
    // 0xd15808: r0 = ""
    //     0xd15808: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd1580c: ldr             x3, [fp, #0x10]
    // 0xd15810: r2 = Null
    //     0xd15810: mov             x2, NULL
    // 0xd15814: r1 = Null
    //     0xd15814: mov             x1, NULL
    // 0xd15818: r4 = 59
    //     0xd15818: mov             x4, #0x3b
    // 0xd1581c: branchIfSmi(r0, 0xd15828)
    //     0xd1581c: tbz             w0, #0, #0xd15828
    // 0xd15820: r4 = LoadClassIdInstr(r0)
    //     0xd15820: ldur            x4, [x0, #-1]
    //     0xd15824: ubfx            x4, x4, #0xc, #0x14
    // 0xd15828: sub             x4, x4, #0x5d
    // 0xd1582c: cmp             x4, #3
    // 0xd15830: b.ls            #0xd15844
    // 0xd15834: r8 = String
    //     0xd15834: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd15838: r3 = Null
    //     0xd15838: add             x3, PP, #0x14, lsl #12  ; [pp+0x14c58] Null
    //     0xd1583c: ldr             x3, [x3, #0xc58]
    // 0xd15840: r0 = String()
    //     0xd15840: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd15844: ldr             x1, [fp, #0x10]
    // 0xd15848: r0 = LoadClassIdInstr(r1)
    //     0xd15848: ldur            x0, [x1, #-1]
    //     0xd1584c: ubfx            x0, x0, #0xc, #0x14
    // 0xd15850: r16 = "release"
    //     0xd15850: add             x16, PP, #0x14, lsl #12  ; [pp+0x14c68] "release"
    //     0xd15854: ldr             x16, [x16, #0xc68]
    // 0xd15858: stp             x16, x1, [SP, #-0x10]!
    // 0xd1585c: r0 = GDT[cid_x0 + -0xef]()
    //     0xd1585c: sub             lr, x0, #0xef
    //     0xd15860: ldr             lr, [x21, lr, lsl #3]
    //     0xd15864: blr             lr
    // 0xd15868: add             SP, SP, #0x10
    // 0xd1586c: cmp             w0, NULL
    // 0xd15870: b.ne            #0xd15878
    // 0xd15874: r0 = ""
    //     0xd15874: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd15878: ldr             x3, [fp, #0x10]
    // 0xd1587c: r2 = Null
    //     0xd1587c: mov             x2, NULL
    // 0xd15880: r1 = Null
    //     0xd15880: mov             x1, NULL
    // 0xd15884: r4 = 59
    //     0xd15884: mov             x4, #0x3b
    // 0xd15888: branchIfSmi(r0, 0xd15894)
    //     0xd15888: tbz             w0, #0, #0xd15894
    // 0xd1588c: r4 = LoadClassIdInstr(r0)
    //     0xd1588c: ldur            x4, [x0, #-1]
    //     0xd15890: ubfx            x4, x4, #0xc, #0x14
    // 0xd15894: sub             x4, x4, #0x5d
    // 0xd15898: cmp             x4, #3
    // 0xd1589c: b.ls            #0xd158b0
    // 0xd158a0: r8 = String
    //     0xd158a0: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd158a4: r3 = Null
    //     0xd158a4: add             x3, PP, #0x14, lsl #12  ; [pp+0x14c70] Null
    //     0xd158a8: ldr             x3, [x3, #0xc70]
    // 0xd158ac: r0 = String()
    //     0xd158ac: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd158b0: ldr             x1, [fp, #0x10]
    // 0xd158b4: r0 = LoadClassIdInstr(r1)
    //     0xd158b4: ldur            x0, [x1, #-1]
    //     0xd158b8: ubfx            x0, x0, #0xc, #0x14
    // 0xd158bc: r16 = "version"
    //     0xd158bc: add             x16, PP, #0xa, lsl #12  ; [pp+0xaca8] "version"
    //     0xd158c0: ldr             x16, [x16, #0xca8]
    // 0xd158c4: stp             x16, x1, [SP, #-0x10]!
    // 0xd158c8: r0 = GDT[cid_x0 + -0xef]()
    //     0xd158c8: sub             lr, x0, #0xef
    //     0xd158cc: ldr             lr, [x21, lr, lsl #3]
    //     0xd158d0: blr             lr
    // 0xd158d4: add             SP, SP, #0x10
    // 0xd158d8: cmp             w0, NULL
    // 0xd158dc: b.ne            #0xd158e4
    // 0xd158e0: r0 = ""
    //     0xd158e0: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd158e4: ldr             x3, [fp, #0x10]
    // 0xd158e8: r2 = Null
    //     0xd158e8: mov             x2, NULL
    // 0xd158ec: r1 = Null
    //     0xd158ec: mov             x1, NULL
    // 0xd158f0: r4 = 59
    //     0xd158f0: mov             x4, #0x3b
    // 0xd158f4: branchIfSmi(r0, 0xd15900)
    //     0xd158f4: tbz             w0, #0, #0xd15900
    // 0xd158f8: r4 = LoadClassIdInstr(r0)
    //     0xd158f8: ldur            x4, [x0, #-1]
    //     0xd158fc: ubfx            x4, x4, #0xc, #0x14
    // 0xd15900: sub             x4, x4, #0x5d
    // 0xd15904: cmp             x4, #3
    // 0xd15908: b.ls            #0xd1591c
    // 0xd1590c: r8 = String
    //     0xd1590c: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd15910: r3 = Null
    //     0xd15910: add             x3, PP, #0x14, lsl #12  ; [pp+0x14c80] Null
    //     0xd15914: ldr             x3, [x3, #0xc80]
    // 0xd15918: r0 = String()
    //     0xd15918: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd1591c: ldr             x0, [fp, #0x10]
    // 0xd15920: r1 = LoadClassIdInstr(r0)
    //     0xd15920: ldur            x1, [x0, #-1]
    //     0xd15924: ubfx            x1, x1, #0xc, #0x14
    // 0xd15928: r16 = "machine"
    //     0xd15928: add             x16, PP, #0x14, lsl #12  ; [pp+0x14c90] "machine"
    //     0xd1592c: ldr             x16, [x16, #0xc90]
    // 0xd15930: stp             x16, x0, [SP, #-0x10]!
    // 0xd15934: mov             x0, x1
    // 0xd15938: r0 = GDT[cid_x0 + -0xef]()
    //     0xd15938: sub             lr, x0, #0xef
    //     0xd1593c: ldr             lr, [x21, lr, lsl #3]
    //     0xd15940: blr             lr
    // 0xd15944: add             SP, SP, #0x10
    // 0xd15948: cmp             w0, NULL
    // 0xd1594c: b.ne            #0xd15954
    // 0xd15950: r0 = ""
    //     0xd15950: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd15954: r2 = Null
    //     0xd15954: mov             x2, NULL
    // 0xd15958: r1 = Null
    //     0xd15958: mov             x1, NULL
    // 0xd1595c: r4 = 59
    //     0xd1595c: mov             x4, #0x3b
    // 0xd15960: branchIfSmi(r0, 0xd1596c)
    //     0xd15960: tbz             w0, #0, #0xd1596c
    // 0xd15964: r4 = LoadClassIdInstr(r0)
    //     0xd15964: ldur            x4, [x0, #-1]
    //     0xd15968: ubfx            x4, x4, #0xc, #0x14
    // 0xd1596c: sub             x4, x4, #0x5d
    // 0xd15970: cmp             x4, #3
    // 0xd15974: b.ls            #0xd15988
    // 0xd15978: r8 = String
    //     0xd15978: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd1597c: r3 = Null
    //     0xd1597c: add             x3, PP, #0x14, lsl #12  ; [pp+0x14c98] Null
    //     0xd15980: ldr             x3, [x3, #0xc98]
    // 0xd15984: r0 = String()
    //     0xd15984: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd15988: r0 = IosUtsname()
    //     0xd15988: bl              #0xd159a0  ; AllocateIosUtsnameStub -> IosUtsname (size=0x8)
    // 0xd1598c: LeaveFrame
    //     0xd1598c: mov             SP, fp
    //     0xd15990: ldp             fp, lr, [SP], #0x10
    // 0xd15994: ret
    //     0xd15994: ret             
    // 0xd15998: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd15998: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1599c: b               #0xd1576c
  }
}

// class id: 4562, size: 0xc, field offset: 0x8
class IosDeviceInfo extends Object {

  static _ fromMap(/* No info */) {
    // ** addr: 0xd15328, size: 0x424
    // 0xd15328: EnterFrame
    //     0xd15328: stp             fp, lr, [SP, #-0x10]!
    //     0xd1532c: mov             fp, SP
    // 0xd15330: AllocStack(0x10)
    //     0xd15330: sub             SP, SP, #0x10
    // 0xd15334: CheckStackOverflow
    //     0xd15334: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd15338: cmp             SP, x16
    //     0xd1533c: b.ls            #0xd15744
    // 0xd15340: ldr             x1, [fp, #0x10]
    // 0xd15344: r0 = LoadClassIdInstr(r1)
    //     0xd15344: ldur            x0, [x1, #-1]
    //     0xd15348: ubfx            x0, x0, #0xc, #0x14
    // 0xd1534c: r16 = "name"
    //     0xd1534c: ldr             x16, [PP, #0x510]  ; [pp+0x510] "name"
    // 0xd15350: stp             x16, x1, [SP, #-0x10]!
    // 0xd15354: r0 = GDT[cid_x0 + -0xef]()
    //     0xd15354: sub             lr, x0, #0xef
    //     0xd15358: ldr             lr, [x21, lr, lsl #3]
    //     0xd1535c: blr             lr
    // 0xd15360: add             SP, SP, #0x10
    // 0xd15364: cmp             w0, NULL
    // 0xd15368: b.ne            #0xd15370
    // 0xd1536c: r0 = ""
    //     0xd1536c: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd15370: ldr             x3, [fp, #0x10]
    // 0xd15374: r2 = Null
    //     0xd15374: mov             x2, NULL
    // 0xd15378: r1 = Null
    //     0xd15378: mov             x1, NULL
    // 0xd1537c: r4 = 59
    //     0xd1537c: mov             x4, #0x3b
    // 0xd15380: branchIfSmi(r0, 0xd1538c)
    //     0xd15380: tbz             w0, #0, #0xd1538c
    // 0xd15384: r4 = LoadClassIdInstr(r0)
    //     0xd15384: ldur            x4, [x0, #-1]
    //     0xd15388: ubfx            x4, x4, #0xc, #0x14
    // 0xd1538c: sub             x4, x4, #0x5d
    // 0xd15390: cmp             x4, #3
    // 0xd15394: b.ls            #0xd153a8
    // 0xd15398: r8 = String
    //     0xd15398: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd1539c: r3 = Null
    //     0xd1539c: add             x3, PP, #0x14, lsl #12  ; [pp+0x14b80] Null
    //     0xd153a0: ldr             x3, [x3, #0xb80]
    // 0xd153a4: r0 = String()
    //     0xd153a4: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd153a8: ldr             x1, [fp, #0x10]
    // 0xd153ac: r0 = LoadClassIdInstr(r1)
    //     0xd153ac: ldur            x0, [x1, #-1]
    //     0xd153b0: ubfx            x0, x0, #0xc, #0x14
    // 0xd153b4: r16 = "systemName"
    //     0xd153b4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14b90] "systemName"
    //     0xd153b8: ldr             x16, [x16, #0xb90]
    // 0xd153bc: stp             x16, x1, [SP, #-0x10]!
    // 0xd153c0: r0 = GDT[cid_x0 + -0xef]()
    //     0xd153c0: sub             lr, x0, #0xef
    //     0xd153c4: ldr             lr, [x21, lr, lsl #3]
    //     0xd153c8: blr             lr
    // 0xd153cc: add             SP, SP, #0x10
    // 0xd153d0: cmp             w0, NULL
    // 0xd153d4: b.ne            #0xd153dc
    // 0xd153d8: r0 = ""
    //     0xd153d8: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd153dc: ldr             x3, [fp, #0x10]
    // 0xd153e0: r2 = Null
    //     0xd153e0: mov             x2, NULL
    // 0xd153e4: r1 = Null
    //     0xd153e4: mov             x1, NULL
    // 0xd153e8: r4 = 59
    //     0xd153e8: mov             x4, #0x3b
    // 0xd153ec: branchIfSmi(r0, 0xd153f8)
    //     0xd153ec: tbz             w0, #0, #0xd153f8
    // 0xd153f0: r4 = LoadClassIdInstr(r0)
    //     0xd153f0: ldur            x4, [x0, #-1]
    //     0xd153f4: ubfx            x4, x4, #0xc, #0x14
    // 0xd153f8: sub             x4, x4, #0x5d
    // 0xd153fc: cmp             x4, #3
    // 0xd15400: b.ls            #0xd15414
    // 0xd15404: r8 = String
    //     0xd15404: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd15408: r3 = Null
    //     0xd15408: add             x3, PP, #0x14, lsl #12  ; [pp+0x14b98] Null
    //     0xd1540c: ldr             x3, [x3, #0xb98]
    // 0xd15410: r0 = String()
    //     0xd15410: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd15414: ldr             x1, [fp, #0x10]
    // 0xd15418: r0 = LoadClassIdInstr(r1)
    //     0xd15418: ldur            x0, [x1, #-1]
    //     0xd1541c: ubfx            x0, x0, #0xc, #0x14
    // 0xd15420: r16 = "systemVersion"
    //     0xd15420: add             x16, PP, #0x14, lsl #12  ; [pp+0x14ba8] "systemVersion"
    //     0xd15424: ldr             x16, [x16, #0xba8]
    // 0xd15428: stp             x16, x1, [SP, #-0x10]!
    // 0xd1542c: r0 = GDT[cid_x0 + -0xef]()
    //     0xd1542c: sub             lr, x0, #0xef
    //     0xd15430: ldr             lr, [x21, lr, lsl #3]
    //     0xd15434: blr             lr
    // 0xd15438: add             SP, SP, #0x10
    // 0xd1543c: cmp             w0, NULL
    // 0xd15440: b.ne            #0xd15448
    // 0xd15444: r0 = ""
    //     0xd15444: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd15448: ldr             x3, [fp, #0x10]
    // 0xd1544c: r2 = Null
    //     0xd1544c: mov             x2, NULL
    // 0xd15450: r1 = Null
    //     0xd15450: mov             x1, NULL
    // 0xd15454: r4 = 59
    //     0xd15454: mov             x4, #0x3b
    // 0xd15458: branchIfSmi(r0, 0xd15464)
    //     0xd15458: tbz             w0, #0, #0xd15464
    // 0xd1545c: r4 = LoadClassIdInstr(r0)
    //     0xd1545c: ldur            x4, [x0, #-1]
    //     0xd15460: ubfx            x4, x4, #0xc, #0x14
    // 0xd15464: sub             x4, x4, #0x5d
    // 0xd15468: cmp             x4, #3
    // 0xd1546c: b.ls            #0xd15480
    // 0xd15470: r8 = String
    //     0xd15470: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd15474: r3 = Null
    //     0xd15474: add             x3, PP, #0x14, lsl #12  ; [pp+0x14bb0] Null
    //     0xd15478: ldr             x3, [x3, #0xbb0]
    // 0xd1547c: r0 = String()
    //     0xd1547c: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd15480: ldr             x1, [fp, #0x10]
    // 0xd15484: r0 = LoadClassIdInstr(r1)
    //     0xd15484: ldur            x0, [x1, #-1]
    //     0xd15488: ubfx            x0, x0, #0xc, #0x14
    // 0xd1548c: r16 = "model"
    //     0xd1548c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14bc0] "model"
    //     0xd15490: ldr             x16, [x16, #0xbc0]
    // 0xd15494: stp             x16, x1, [SP, #-0x10]!
    // 0xd15498: r0 = GDT[cid_x0 + -0xef]()
    //     0xd15498: sub             lr, x0, #0xef
    //     0xd1549c: ldr             lr, [x21, lr, lsl #3]
    //     0xd154a0: blr             lr
    // 0xd154a4: add             SP, SP, #0x10
    // 0xd154a8: cmp             w0, NULL
    // 0xd154ac: b.ne            #0xd154b4
    // 0xd154b0: r0 = ""
    //     0xd154b0: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd154b4: ldr             x3, [fp, #0x10]
    // 0xd154b8: r2 = Null
    //     0xd154b8: mov             x2, NULL
    // 0xd154bc: r1 = Null
    //     0xd154bc: mov             x1, NULL
    // 0xd154c0: r4 = 59
    //     0xd154c0: mov             x4, #0x3b
    // 0xd154c4: branchIfSmi(r0, 0xd154d0)
    //     0xd154c4: tbz             w0, #0, #0xd154d0
    // 0xd154c8: r4 = LoadClassIdInstr(r0)
    //     0xd154c8: ldur            x4, [x0, #-1]
    //     0xd154cc: ubfx            x4, x4, #0xc, #0x14
    // 0xd154d0: sub             x4, x4, #0x5d
    // 0xd154d4: cmp             x4, #3
    // 0xd154d8: b.ls            #0xd154ec
    // 0xd154dc: r8 = String
    //     0xd154dc: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd154e0: r3 = Null
    //     0xd154e0: add             x3, PP, #0x14, lsl #12  ; [pp+0x14bc8] Null
    //     0xd154e4: ldr             x3, [x3, #0xbc8]
    // 0xd154e8: r0 = String()
    //     0xd154e8: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd154ec: ldr             x1, [fp, #0x10]
    // 0xd154f0: r0 = LoadClassIdInstr(r1)
    //     0xd154f0: ldur            x0, [x1, #-1]
    //     0xd154f4: ubfx            x0, x0, #0xc, #0x14
    // 0xd154f8: r16 = "localizedModel"
    //     0xd154f8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14bd8] "localizedModel"
    //     0xd154fc: ldr             x16, [x16, #0xbd8]
    // 0xd15500: stp             x16, x1, [SP, #-0x10]!
    // 0xd15504: r0 = GDT[cid_x0 + -0xef]()
    //     0xd15504: sub             lr, x0, #0xef
    //     0xd15508: ldr             lr, [x21, lr, lsl #3]
    //     0xd1550c: blr             lr
    // 0xd15510: add             SP, SP, #0x10
    // 0xd15514: cmp             w0, NULL
    // 0xd15518: b.ne            #0xd15520
    // 0xd1551c: r0 = ""
    //     0xd1551c: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd15520: ldr             x3, [fp, #0x10]
    // 0xd15524: r2 = Null
    //     0xd15524: mov             x2, NULL
    // 0xd15528: r1 = Null
    //     0xd15528: mov             x1, NULL
    // 0xd1552c: r4 = 59
    //     0xd1552c: mov             x4, #0x3b
    // 0xd15530: branchIfSmi(r0, 0xd1553c)
    //     0xd15530: tbz             w0, #0, #0xd1553c
    // 0xd15534: r4 = LoadClassIdInstr(r0)
    //     0xd15534: ldur            x4, [x0, #-1]
    //     0xd15538: ubfx            x4, x4, #0xc, #0x14
    // 0xd1553c: sub             x4, x4, #0x5d
    // 0xd15540: cmp             x4, #3
    // 0xd15544: b.ls            #0xd15558
    // 0xd15548: r8 = String
    //     0xd15548: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd1554c: r3 = Null
    //     0xd1554c: add             x3, PP, #0x14, lsl #12  ; [pp+0x14be0] Null
    //     0xd15550: ldr             x3, [x3, #0xbe0]
    // 0xd15554: r0 = String()
    //     0xd15554: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd15558: ldr             x1, [fp, #0x10]
    // 0xd1555c: r0 = LoadClassIdInstr(r1)
    //     0xd1555c: ldur            x0, [x1, #-1]
    //     0xd15560: ubfx            x0, x0, #0xc, #0x14
    // 0xd15564: r16 = "identifierForVendor"
    //     0xd15564: add             x16, PP, #0x14, lsl #12  ; [pp+0x14bf0] "identifierForVendor"
    //     0xd15568: ldr             x16, [x16, #0xbf0]
    // 0xd1556c: stp             x16, x1, [SP, #-0x10]!
    // 0xd15570: r0 = GDT[cid_x0 + -0xef]()
    //     0xd15570: sub             lr, x0, #0xef
    //     0xd15574: ldr             lr, [x21, lr, lsl #3]
    //     0xd15578: blr             lr
    // 0xd1557c: add             SP, SP, #0x10
    // 0xd15580: cmp             w0, NULL
    // 0xd15584: b.ne            #0xd15590
    // 0xd15588: r4 = ""
    //     0xd15588: ldr             x4, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xd1558c: b               #0xd15594
    // 0xd15590: mov             x4, x0
    // 0xd15594: ldr             x3, [fp, #0x10]
    // 0xd15598: mov             x0, x4
    // 0xd1559c: stur            x4, [fp, #-8]
    // 0xd155a0: r2 = Null
    //     0xd155a0: mov             x2, NULL
    // 0xd155a4: r1 = Null
    //     0xd155a4: mov             x1, NULL
    // 0xd155a8: r4 = 59
    //     0xd155a8: mov             x4, #0x3b
    // 0xd155ac: branchIfSmi(r0, 0xd155b8)
    //     0xd155ac: tbz             w0, #0, #0xd155b8
    // 0xd155b0: r4 = LoadClassIdInstr(r0)
    //     0xd155b0: ldur            x4, [x0, #-1]
    //     0xd155b4: ubfx            x4, x4, #0xc, #0x14
    // 0xd155b8: sub             x4, x4, #0x5d
    // 0xd155bc: cmp             x4, #3
    // 0xd155c0: b.ls            #0xd155d4
    // 0xd155c4: r8 = String
    //     0xd155c4: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xd155c8: r3 = Null
    //     0xd155c8: add             x3, PP, #0x14, lsl #12  ; [pp+0x14bf8] Null
    //     0xd155cc: ldr             x3, [x3, #0xbf8]
    // 0xd155d0: r0 = String()
    //     0xd155d0: bl              #0xd72afc  ; IsType_String_Stub
    // 0xd155d4: ldr             x1, [fp, #0x10]
    // 0xd155d8: r0 = LoadClassIdInstr(r1)
    //     0xd155d8: ldur            x0, [x1, #-1]
    //     0xd155dc: ubfx            x0, x0, #0xc, #0x14
    // 0xd155e0: r16 = "isPhysicalDevice"
    //     0xd155e0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14c08] "isPhysicalDevice"
    //     0xd155e4: ldr             x16, [x16, #0xc08]
    // 0xd155e8: stp             x16, x1, [SP, #-0x10]!
    // 0xd155ec: r0 = GDT[cid_x0 + -0xef]()
    //     0xd155ec: sub             lr, x0, #0xef
    //     0xd155f0: ldr             lr, [x21, lr, lsl #3]
    //     0xd155f4: blr             lr
    // 0xd155f8: add             SP, SP, #0x10
    // 0xd155fc: cmp             w0, NULL
    // 0xd15600: b.eq            #0xd15658
    // 0xd15604: ldr             x1, [fp, #0x10]
    // 0xd15608: r0 = LoadClassIdInstr(r1)
    //     0xd15608: ldur            x0, [x1, #-1]
    //     0xd1560c: ubfx            x0, x0, #0xc, #0x14
    // 0xd15610: r16 = "isPhysicalDevice"
    //     0xd15610: add             x16, PP, #0x14, lsl #12  ; [pp+0x14c08] "isPhysicalDevice"
    //     0xd15614: ldr             x16, [x16, #0xc08]
    // 0xd15618: stp             x16, x1, [SP, #-0x10]!
    // 0xd1561c: r0 = GDT[cid_x0 + -0xef]()
    //     0xd1561c: sub             lr, x0, #0xef
    //     0xd15620: ldr             lr, [x21, lr, lsl #3]
    //     0xd15624: blr             lr
    // 0xd15628: add             SP, SP, #0x10
    // 0xd1562c: r1 = 59
    //     0xd1562c: mov             x1, #0x3b
    // 0xd15630: branchIfSmi(r0, 0xd1563c)
    //     0xd15630: tbz             w0, #0, #0xd1563c
    // 0xd15634: r1 = LoadClassIdInstr(r0)
    //     0xd15634: ldur            x1, [x0, #-1]
    //     0xd15638: ubfx            x1, x1, #0xc, #0x14
    // 0xd1563c: r16 = "true"
    //     0xd1563c: ldr             x16, [PP, #0x2300]  ; [pp+0x2300] "true"
    // 0xd15640: stp             x16, x0, [SP, #-0x10]!
    // 0xd15644: mov             x0, x1
    // 0xd15648: mov             lr, x0
    // 0xd1564c: ldr             lr, [x21, lr, lsl #3]
    // 0xd15650: blr             lr
    // 0xd15654: add             SP, SP, #0x10
    // 0xd15658: ldr             x1, [fp, #0x10]
    // 0xd1565c: r0 = LoadClassIdInstr(r1)
    //     0xd1565c: ldur            x0, [x1, #-1]
    //     0xd15660: ubfx            x0, x0, #0xc, #0x14
    // 0xd15664: r16 = "utsname"
    //     0xd15664: add             x16, PP, #0x14, lsl #12  ; [pp+0x14c10] "utsname"
    //     0xd15668: ldr             x16, [x16, #0xc10]
    // 0xd1566c: stp             x16, x1, [SP, #-0x10]!
    // 0xd15670: r0 = GDT[cid_x0 + -0xef]()
    //     0xd15670: sub             lr, x0, #0xef
    //     0xd15674: ldr             lr, [x21, lr, lsl #3]
    //     0xd15678: blr             lr
    // 0xd1567c: add             SP, SP, #0x10
    // 0xd15680: cmp             w0, NULL
    // 0xd15684: b.eq            #0xd156e0
    // 0xd15688: ldr             x0, [fp, #0x10]
    // 0xd1568c: r1 = LoadClassIdInstr(r0)
    //     0xd1568c: ldur            x1, [x0, #-1]
    //     0xd15690: ubfx            x1, x1, #0xc, #0x14
    // 0xd15694: r16 = "utsname"
    //     0xd15694: add             x16, PP, #0x14, lsl #12  ; [pp+0x14c10] "utsname"
    //     0xd15698: ldr             x16, [x16, #0xc10]
    // 0xd1569c: stp             x16, x0, [SP, #-0x10]!
    // 0xd156a0: mov             x0, x1
    // 0xd156a4: r0 = GDT[cid_x0 + -0xef]()
    //     0xd156a4: sub             lr, x0, #0xef
    //     0xd156a8: ldr             lr, [x21, lr, lsl #3]
    //     0xd156ac: blr             lr
    // 0xd156b0: add             SP, SP, #0x10
    // 0xd156b4: r16 = <String, dynamic>
    //     0xd156b4: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xd156b8: stp             x0, x16, [SP, #-0x10]!
    // 0xd156bc: r4 = 0
    //     0xd156bc: mov             x4, #0
    // 0xd156c0: ldr             x0, [SP]
    // 0xd156c4: r16 = UnlinkedCall_0x4aeefc
    //     0xd156c4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14c18] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0xd156c8: add             x16, x16, #0xc18
    // 0xd156cc: ldp             x5, lr, [x16]
    // 0xd156d0: blr             lr
    // 0xd156d4: add             SP, SP, #0x10
    // 0xd156d8: mov             x4, x0
    // 0xd156dc: b               #0xd156f8
    // 0xd156e0: r16 = <String, dynamic>
    //     0xd156e0: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xd156e4: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xd156e8: stp             lr, x16, [SP, #-0x10]!
    // 0xd156ec: r0 = Map._fromLiteral()
    //     0xd156ec: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xd156f0: add             SP, SP, #0x10
    // 0xd156f4: mov             x4, x0
    // 0xd156f8: ldur            x3, [fp, #-8]
    // 0xd156fc: mov             x0, x4
    // 0xd15700: stur            x4, [fp, #-0x10]
    // 0xd15704: r2 = Null
    //     0xd15704: mov             x2, NULL
    // 0xd15708: r1 = Null
    //     0xd15708: mov             x1, NULL
    // 0xd1570c: r8 = Map<String, dynamic>
    //     0xd1570c: ldr             x8, [PP, #0x3da0]  ; [pp+0x3da0] Type: Map<String, dynamic>
    // 0xd15710: r3 = Null
    //     0xd15710: add             x3, PP, #0x14, lsl #12  ; [pp+0x14c28] Null
    //     0xd15714: ldr             x3, [x3, #0xc28]
    // 0xd15718: r0 = Map<String, dynamic>()
    //     0xd15718: bl              #0x4e3b2c  ; IsType_Map<String, dynamic>_Stub
    // 0xd1571c: ldur            x16, [fp, #-0x10]
    // 0xd15720: SaveReg r16
    //     0xd15720: str             x16, [SP, #-8]!
    // 0xd15724: r0 = _fromMap()
    //     0xd15724: bl              #0xd15758  ; [package:device_info_platform_interface/model/ios_device_info.dart] IosUtsname::_fromMap
    // 0xd15728: add             SP, SP, #8
    // 0xd1572c: r0 = IosDeviceInfo()
    //     0xd1572c: bl              #0xd1574c  ; AllocateIosDeviceInfoStub -> IosDeviceInfo (size=0xc)
    // 0xd15730: ldur            x1, [fp, #-8]
    // 0xd15734: StoreField: r0->field_7 = r1
    //     0xd15734: stur            w1, [x0, #7]
    // 0xd15738: LeaveFrame
    //     0xd15738: mov             SP, fp
    //     0xd1573c: ldp             fp, lr, [SP], #0x10
    // 0xd15740: ret
    //     0xd15740: ret             
    // 0xd15744: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd15744: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd15748: b               #0xd15340
  }
}

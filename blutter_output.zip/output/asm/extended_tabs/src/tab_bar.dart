// lib: , url: package:extended_tabs/src/tab_bar.dart

// class id: 1048965, size: 0x8
class :: {

  static _ _indexChangeProgress(/* No info */) {
    // ** addr: 0xa6df20, size: 0x1f4
    // 0xa6df20: EnterFrame
    //     0xa6df20: stp             fp, lr, [SP, #-0x10]!
    //     0xa6df24: mov             fp, SP
    // 0xa6df28: AllocStack(0x10)
    //     0xa6df28: sub             SP, SP, #0x10
    // 0xa6df2c: CheckStackOverflow
    //     0xa6df2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6df30: cmp             SP, x16
    //     0xa6df34: b.ls            #0xa6e0ec
    // 0xa6df38: ldr             x2, [fp, #0x10]
    // 0xa6df3c: LoadField: r0 = r2->field_23
    //     0xa6df3c: ldur            w0, [x2, #0x23]
    // 0xa6df40: DecompressPointer r0
    //     0xa6df40: add             x0, x0, HEAP, lsl #32
    // 0xa6df44: cmp             w0, NULL
    // 0xa6df48: b.ne            #0xa6df50
    // 0xa6df4c: r0 = Null
    //     0xa6df4c: mov             x0, NULL
    // 0xa6df50: cmp             w0, NULL
    // 0xa6df54: b.eq            #0xa6e0f4
    // 0xa6df58: LoadField: r3 = r0->field_37
    //     0xa6df58: ldur            w3, [x0, #0x37]
    // 0xa6df5c: DecompressPointer r3
    //     0xa6df5c: add             x3, x3, HEAP, lsl #32
    // 0xa6df60: r16 = Sentinel
    //     0xa6df60: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa6df64: cmp             w3, w16
    // 0xa6df68: b.eq            #0xa6e0f8
    // 0xa6df6c: stur            x3, [fp, #-8]
    // 0xa6df70: LoadField: r4 = r2->field_3b
    //     0xa6df70: ldur            x4, [x2, #0x3b]
    // 0xa6df74: r0 = BoxInt64Instr(r4)
    //     0xa6df74: sbfiz           x0, x4, #1, #0x1f
    //     0xa6df78: cmp             x4, x0, asr #1
    //     0xa6df7c: b.eq            #0xa6df88
    //     0xa6df80: bl              #0xd69bb8
    //     0xa6df84: stur            x4, [x0, #7]
    // 0xa6df88: stp             x0, NULL, [SP, #-0x10]!
    // 0xa6df8c: r0 = _Double.fromInteger()
    //     0xa6df8c: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0xa6df90: add             SP, SP, #0x10
    // 0xa6df94: mov             x3, x0
    // 0xa6df98: ldr             x2, [fp, #0x10]
    // 0xa6df9c: stur            x3, [fp, #-0x10]
    // 0xa6dfa0: LoadField: r4 = r2->field_33
    //     0xa6dfa0: ldur            x4, [x2, #0x33]
    // 0xa6dfa4: r0 = BoxInt64Instr(r4)
    //     0xa6dfa4: sbfiz           x0, x4, #1, #0x1f
    //     0xa6dfa8: cmp             x4, x0, asr #1
    //     0xa6dfac: b.eq            #0xa6dfb8
    //     0xa6dfb0: bl              #0xd69bb8
    //     0xa6dfb4: stur            x4, [x0, #7]
    // 0xa6dfb8: stp             x0, NULL, [SP, #-0x10]!
    // 0xa6dfbc: r0 = _Double.fromInteger()
    //     0xa6dfbc: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0xa6dfc0: add             SP, SP, #0x10
    // 0xa6dfc4: mov             x1, x0
    // 0xa6dfc8: ldr             x0, [fp, #0x10]
    // 0xa6dfcc: LoadField: r2 = r0->field_43
    //     0xa6dfcc: ldur            x2, [x0, #0x43]
    // 0xa6dfd0: cbnz            x2, #0xa6e064
    // 0xa6dfd4: ldur            x0, [fp, #-8]
    // 0xa6dfd8: d0 = 0.000000
    //     0xa6dfd8: eor             v0.16b, v0.16b, v0.16b
    // 0xa6dfdc: LoadField: d1 = r0->field_7
    //     0xa6dfdc: ldur            d1, [x0, #7]
    // 0xa6dfe0: LoadField: d2 = r1->field_7
    //     0xa6dfe0: ldur            d2, [x1, #7]
    // 0xa6dfe4: fsub            d3, d2, d1
    // 0xa6dfe8: fcmp            d3, d0
    // 0xa6dfec: b.vs            #0xa6dffc
    // 0xa6dff0: b.ne            #0xa6dffc
    // 0xa6dff4: d0 = 0.000000
    //     0xa6dff4: eor             v0.16b, v0.16b, v0.16b
    // 0xa6dff8: b               #0xa6e014
    // 0xa6dffc: fcmp            d3, d0
    // 0xa6e000: b.vs            #0xa6e010
    // 0xa6e004: b.ge            #0xa6e010
    // 0xa6e008: fneg            d0, d3
    // 0xa6e00c: b               #0xa6e014
    // 0xa6e010: mov             v0.16b, v3.16b
    // 0xa6e014: r0 = inline_Allocate_Double()
    //     0xa6e014: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6e018: add             x0, x0, #0x10
    //     0xa6e01c: cmp             x1, x0
    //     0xa6e020: b.ls            #0xa6e104
    //     0xa6e024: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6e028: sub             x0, x0, #0xf
    //     0xa6e02c: mov             x1, #0xd108
    //     0xa6e030: movk            x1, #3, lsl #16
    //     0xa6e034: stur            x1, [x0, #-1]
    // 0xa6e038: StoreField: r0->field_7 = d0
    //     0xa6e038: stur            d0, [x0, #7]
    // 0xa6e03c: r16 = 0.000000
    //     0xa6e03c: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xa6e040: stp             x16, x0, [SP, #-0x10]!
    // 0xa6e044: r16 = 1.000000
    //     0xa6e044: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xa6e048: SaveReg r16
    //     0xa6e048: str             x16, [SP, #-8]!
    // 0xa6e04c: r0 = clamp()
    //     0xa6e04c: bl              #0xd66c00  ; [dart:core] _Double::clamp
    // 0xa6e050: add             SP, SP, #0x18
    // 0xa6e054: LoadField: d0 = r0->field_7
    //     0xa6e054: ldur            d0, [x0, #7]
    // 0xa6e058: LeaveFrame
    //     0xa6e058: mov             SP, fp
    //     0xa6e05c: ldp             fp, lr, [SP], #0x10
    // 0xa6e060: ret
    //     0xa6e060: ret             
    // 0xa6e064: ldur            x0, [fp, #-8]
    // 0xa6e068: d0 = 0.000000
    //     0xa6e068: eor             v0.16b, v0.16b, v0.16b
    // 0xa6e06c: LoadField: d1 = r0->field_7
    //     0xa6e06c: ldur            d1, [x0, #7]
    // 0xa6e070: LoadField: d2 = r1->field_7
    //     0xa6e070: ldur            d2, [x1, #7]
    // 0xa6e074: fsub            d3, d1, d2
    // 0xa6e078: fcmp            d3, d0
    // 0xa6e07c: b.vs            #0xa6e08c
    // 0xa6e080: b.ne            #0xa6e08c
    // 0xa6e084: d1 = 0.000000
    //     0xa6e084: eor             v1.16b, v1.16b, v1.16b
    // 0xa6e088: b               #0xa6e0a4
    // 0xa6e08c: fcmp            d3, d0
    // 0xa6e090: b.vs            #0xa6e0a0
    // 0xa6e094: b.ge            #0xa6e0a0
    // 0xa6e098: fneg            d1, d3
    // 0xa6e09c: b               #0xa6e0a4
    // 0xa6e0a0: mov             v1.16b, v3.16b
    // 0xa6e0a4: ldur            x0, [fp, #-0x10]
    // 0xa6e0a8: LoadField: d3 = r0->field_7
    //     0xa6e0a8: ldur            d3, [x0, #7]
    // 0xa6e0ac: fsub            d4, d2, d3
    // 0xa6e0b0: fcmp            d4, d0
    // 0xa6e0b4: b.vs            #0xa6e0c4
    // 0xa6e0b8: b.ne            #0xa6e0c4
    // 0xa6e0bc: d2 = 0.000000
    //     0xa6e0bc: eor             v2.16b, v2.16b, v2.16b
    // 0xa6e0c0: b               #0xa6e0dc
    // 0xa6e0c4: fcmp            d4, d0
    // 0xa6e0c8: b.vs            #0xa6e0d8
    // 0xa6e0cc: b.ge            #0xa6e0d8
    // 0xa6e0d0: fneg            d2, d4
    // 0xa6e0d4: b               #0xa6e0dc
    // 0xa6e0d8: mov             v2.16b, v4.16b
    // 0xa6e0dc: fdiv            d0, d1, d2
    // 0xa6e0e0: LeaveFrame
    //     0xa6e0e0: mov             SP, fp
    //     0xa6e0e4: ldp             fp, lr, [SP], #0x10
    // 0xa6e0e8: ret
    //     0xa6e0e8: ret             
    // 0xa6e0ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6e0ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6e0f0: b               #0xa6df38
    // 0xa6e0f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6e0f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa6e0f8: r9 = _value
    //     0xa6e0f8: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0xa6e0fc: ldr             x9, [x9, #0xbb0]
    // 0xa6e100: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa6e100: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa6e104: SaveReg d0
    //     0xa6e104: str             q0, [SP, #-0x10]!
    // 0xa6e108: r0 = AllocateDouble()
    //     0xa6e108: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6e10c: RestoreReg d0
    //     0xa6e10c: ldr             q0, [SP], #0x10
    // 0xa6e110: b               #0xa6e038
  }
}

// class id: 2543, size: 0xa4, field offset: 0xa0
class _TabLabelBarRenderer extends RenderFlex {

  _ performLayout(/* No info */) {
    // ** addr: 0x688fd0, size: 0x5f8
    // 0x688fd0: EnterFrame
    //     0x688fd0: stp             fp, lr, [SP, #-0x10]!
    //     0x688fd4: mov             fp, SP
    // 0x688fd8: AllocStack(0x20)
    //     0x688fd8: sub             SP, SP, #0x20
    // 0x688fdc: CheckStackOverflow
    //     0x688fdc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x688fe0: cmp             SP, x16
    //     0x688fe4: b.ls            #0x6894e4
    // 0x688fe8: ldr             x16, [fp, #0x10]
    // 0x688fec: SaveReg r16
    //     0x688fec: str             x16, [SP, #-8]!
    // 0x688ff0: r0 = performLayout()
    //     0x688ff0: bl              #0x6899c0  ; [package:flutter/src/rendering/flex.dart] RenderFlex::performLayout
    // 0x688ff4: add             SP, SP, #8
    // 0x688ff8: ldr             x0, [fp, #0x10]
    // 0x688ffc: LoadField: r1 = r0->field_67
    //     0x688ffc: ldur            w1, [x0, #0x67]
    // 0x689000: DecompressPointer r1
    //     0x689000: add             x1, x1, HEAP, lsl #32
    // 0x689004: stur            x1, [fp, #-8]
    // 0x689008: r16 = <double>
    //     0x689008: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x68900c: stp             xzr, x16, [SP, #-0x10]!
    // 0x689010: r0 = _GrowableList()
    //     0x689010: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x689014: add             SP, SP, #0x10
    // 0x689018: mov             x3, x0
    // 0x68901c: stur            x3, [fp, #-0x10]
    // 0x689020: ldur            x0, [fp, #-8]
    // 0x689024: ldr             x4, [fp, #0x10]
    // 0x689028: CheckStackOverflow
    //     0x689028: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68902c: cmp             SP, x16
    //     0x689030: b.ls            #0x6894ec
    // 0x689034: cmp             w0, NULL
    // 0x689038: b.eq            #0x689180
    // 0x68903c: LoadField: r5 = r0->field_17
    //     0x68903c: ldur            w5, [x0, #0x17]
    // 0x689040: DecompressPointer r5
    //     0x689040: add             x5, x5, HEAP, lsl #32
    // 0x689044: mov             x0, x5
    // 0x689048: stur            x5, [fp, #-8]
    // 0x68904c: r2 = Null
    //     0x68904c: mov             x2, NULL
    // 0x689050: r1 = Null
    //     0x689050: mov             x1, NULL
    // 0x689054: r4 = LoadClassIdInstr(r0)
    //     0x689054: ldur            x4, [x0, #-1]
    //     0x689058: ubfx            x4, x4, #0xc, #0x14
    // 0x68905c: cmp             x4, #0x809
    // 0x689060: b.eq            #0x689078
    // 0x689064: r8 = FlexParentData<RenderBox>
    //     0x689064: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x689068: ldr             x8, [x8, #0x248]
    // 0x68906c: r3 = Null
    //     0x68906c: add             x3, PP, #0x53, lsl #12  ; [pp+0x536a0] Null
    //     0x689070: ldr             x3, [x3, #0x6a0]
    // 0x689074: r0 = DefaultTypeTest()
    //     0x689074: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x689078: ldr             x0, [fp, #0x10]
    // 0x68907c: LoadField: r1 = r0->field_73
    //     0x68907c: ldur            w1, [x0, #0x73]
    // 0x689080: DecompressPointer r1
    //     0x689080: add             x1, x1, HEAP, lsl #32
    // 0x689084: r16 = Instance_Axis
    //     0x689084: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x689088: ldr             x16, [x16, #0x440]
    // 0x68908c: cmp             w1, w16
    // 0x689090: b.ne            #0x6890a8
    // 0x689094: ldur            x1, [fp, #-8]
    // 0x689098: LoadField: r2 = r1->field_7
    //     0x689098: ldur            w2, [x1, #7]
    // 0x68909c: DecompressPointer r2
    //     0x68909c: add             x2, x2, HEAP, lsl #32
    // 0x6890a0: LoadField: d0 = r2->field_7
    //     0x6890a0: ldur            d0, [x2, #7]
    // 0x6890a4: b               #0x6890b8
    // 0x6890a8: ldur            x1, [fp, #-8]
    // 0x6890ac: LoadField: r2 = r1->field_7
    //     0x6890ac: ldur            w2, [x1, #7]
    // 0x6890b0: DecompressPointer r2
    //     0x6890b0: add             x2, x2, HEAP, lsl #32
    // 0x6890b4: LoadField: d0 = r2->field_f
    //     0x6890b4: ldur            d0, [x2, #0xf]
    // 0x6890b8: ldur            x2, [fp, #-0x10]
    // 0x6890bc: stur            d0, [fp, #-0x20]
    // 0x6890c0: LoadField: r3 = r2->field_b
    //     0x6890c0: ldur            w3, [x2, #0xb]
    // 0x6890c4: DecompressPointer r3
    //     0x6890c4: add             x3, x3, HEAP, lsl #32
    // 0x6890c8: stur            x3, [fp, #-0x18]
    // 0x6890cc: LoadField: r4 = r2->field_f
    //     0x6890cc: ldur            w4, [x2, #0xf]
    // 0x6890d0: DecompressPointer r4
    //     0x6890d0: add             x4, x4, HEAP, lsl #32
    // 0x6890d4: LoadField: r5 = r4->field_b
    //     0x6890d4: ldur            w5, [x4, #0xb]
    // 0x6890d8: DecompressPointer r5
    //     0x6890d8: add             x5, x5, HEAP, lsl #32
    // 0x6890dc: cmp             w3, w5
    // 0x6890e0: b.ne            #0x6890f0
    // 0x6890e4: SaveReg r2
    //     0x6890e4: str             x2, [SP, #-8]!
    // 0x6890e8: r0 = _growToNextCapacity()
    //     0x6890e8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6890ec: add             SP, SP, #8
    // 0x6890f0: ldur            x3, [fp, #-0x10]
    // 0x6890f4: ldur            x2, [fp, #-8]
    // 0x6890f8: ldur            d0, [fp, #-0x20]
    // 0x6890fc: ldur            x0, [fp, #-0x18]
    // 0x689100: r4 = LoadInt32Instr(r0)
    //     0x689100: sbfx            x4, x0, #1, #0x1f
    // 0x689104: add             x0, x4, #1
    // 0x689108: lsl             x1, x0, #1
    // 0x68910c: StoreField: r3->field_b = r1
    //     0x68910c: stur            w1, [x3, #0xb]
    // 0x689110: mov             x1, x4
    // 0x689114: cmp             x1, x0
    // 0x689118: b.hs            #0x6894f4
    // 0x68911c: LoadField: r1 = r3->field_f
    //     0x68911c: ldur            w1, [x3, #0xf]
    // 0x689120: DecompressPointer r1
    //     0x689120: add             x1, x1, HEAP, lsl #32
    // 0x689124: r0 = inline_Allocate_Double()
    //     0x689124: ldp             x0, x5, [THR, #0x60]  ; THR::top
    //     0x689128: add             x0, x0, #0x10
    //     0x68912c: cmp             x5, x0
    //     0x689130: b.ls            #0x6894f8
    //     0x689134: str             x0, [THR, #0x60]  ; THR::top
    //     0x689138: sub             x0, x0, #0xf
    //     0x68913c: mov             x5, #0xd108
    //     0x689140: movk            x5, #3, lsl #16
    //     0x689144: stur            x5, [x0, #-1]
    // 0x689148: StoreField: r0->field_7 = d0
    //     0x689148: stur            d0, [x0, #7]
    // 0x68914c: ArrayStore: r1[r4] = r0  ; List_4
    //     0x68914c: add             x25, x1, x4, lsl #2
    //     0x689150: add             x25, x25, #0xf
    //     0x689154: str             w0, [x25]
    //     0x689158: tbz             w0, #0, #0x689174
    //     0x68915c: ldurb           w16, [x1, #-1]
    //     0x689160: ldurb           w17, [x0, #-1]
    //     0x689164: and             x16, x17, x16, lsr #2
    //     0x689168: tst             x16, HEAP, lsr #32
    //     0x68916c: b.eq            #0x689174
    //     0x689170: bl              #0xd67e5c
    // 0x689174: LoadField: r0 = r2->field_13
    //     0x689174: ldur            w0, [x2, #0x13]
    // 0x689178: DecompressPointer r0
    //     0x689178: add             x0, x0, HEAP, lsl #32
    // 0x68917c: b               #0x689024
    // 0x689180: mov             x0, x4
    // 0x689184: LoadField: r1 = r0->field_73
    //     0x689184: ldur            w1, [x0, #0x73]
    // 0x689188: DecompressPointer r1
    //     0x689188: add             x1, x1, HEAP, lsl #32
    // 0x68918c: r16 = Instance_Axis
    //     0x68918c: add             x16, PP, #0xe, lsl #12  ; [pp+0xef00] Obj!Axis@b64ff1
    //     0x689190: ldr             x16, [x16, #0xf00]
    // 0x689194: cmp             w1, w16
    // 0x689198: b.ne            #0x689290
    // 0x68919c: r16 = Instance_Axis
    //     0x68919c: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x6891a0: ldr             x16, [x16, #0x440]
    // 0x6891a4: cmp             w1, w16
    // 0x6891a8: b.ne            #0x6891c4
    // 0x6891ac: LoadField: r1 = r0->field_57
    //     0x6891ac: ldur            w1, [x0, #0x57]
    // 0x6891b0: DecompressPointer r1
    //     0x6891b0: add             x1, x1, HEAP, lsl #32
    // 0x6891b4: cmp             w1, NULL
    // 0x6891b8: b.eq            #0x689518
    // 0x6891bc: LoadField: d0 = r1->field_7
    //     0x6891bc: ldur            d0, [x1, #7]
    // 0x6891c0: b               #0x6891d8
    // 0x6891c4: LoadField: r1 = r0->field_57
    //     0x6891c4: ldur            w1, [x0, #0x57]
    // 0x6891c8: DecompressPointer r1
    //     0x6891c8: add             x1, x1, HEAP, lsl #32
    // 0x6891cc: cmp             w1, NULL
    // 0x6891d0: b.eq            #0x68951c
    // 0x6891d4: LoadField: d0 = r1->field_f
    //     0x6891d4: ldur            d0, [x1, #0xf]
    // 0x6891d8: stur            d0, [fp, #-0x20]
    // 0x6891dc: LoadField: r1 = r3->field_b
    //     0x6891dc: ldur            w1, [x3, #0xb]
    // 0x6891e0: DecompressPointer r1
    //     0x6891e0: add             x1, x1, HEAP, lsl #32
    // 0x6891e4: stur            x1, [fp, #-8]
    // 0x6891e8: LoadField: r2 = r3->field_f
    //     0x6891e8: ldur            w2, [x3, #0xf]
    // 0x6891ec: DecompressPointer r2
    //     0x6891ec: add             x2, x2, HEAP, lsl #32
    // 0x6891f0: LoadField: r4 = r2->field_b
    //     0x6891f0: ldur            w4, [x2, #0xb]
    // 0x6891f4: DecompressPointer r4
    //     0x6891f4: add             x4, x4, HEAP, lsl #32
    // 0x6891f8: cmp             w1, w4
    // 0x6891fc: b.ne            #0x68920c
    // 0x689200: SaveReg r3
    //     0x689200: str             x3, [SP, #-8]!
    // 0x689204: r0 = _growToNextCapacity()
    //     0x689204: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x689208: add             SP, SP, #8
    // 0x68920c: ldur            x2, [fp, #-0x10]
    // 0x689210: ldur            d0, [fp, #-0x20]
    // 0x689214: ldur            x0, [fp, #-8]
    // 0x689218: r3 = LoadInt32Instr(r0)
    //     0x689218: sbfx            x3, x0, #1, #0x1f
    // 0x68921c: add             x0, x3, #1
    // 0x689220: lsl             x1, x0, #1
    // 0x689224: StoreField: r2->field_b = r1
    //     0x689224: stur            w1, [x2, #0xb]
    // 0x689228: mov             x1, x3
    // 0x68922c: cmp             x1, x0
    // 0x689230: b.hs            #0x689520
    // 0x689234: LoadField: r1 = r2->field_f
    //     0x689234: ldur            w1, [x2, #0xf]
    // 0x689238: DecompressPointer r1
    //     0x689238: add             x1, x1, HEAP, lsl #32
    // 0x68923c: r0 = inline_Allocate_Double()
    //     0x68923c: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0x689240: add             x0, x0, #0x10
    //     0x689244: cmp             x4, x0
    //     0x689248: b.ls            #0x689524
    //     0x68924c: str             x0, [THR, #0x60]  ; THR::top
    //     0x689250: sub             x0, x0, #0xf
    //     0x689254: mov             x4, #0xd108
    //     0x689258: movk            x4, #3, lsl #16
    //     0x68925c: stur            x4, [x0, #-1]
    // 0x689260: StoreField: r0->field_7 = d0
    //     0x689260: stur            d0, [x0, #7]
    // 0x689264: ArrayStore: r1[r3] = r0  ; List_4
    //     0x689264: add             x25, x1, x3, lsl #2
    //     0x689268: add             x25, x25, #0xf
    //     0x68926c: str             w0, [x25]
    //     0x689270: tbz             w0, #0, #0x68928c
    //     0x689274: ldurb           w16, [x1, #-1]
    //     0x689278: ldurb           w17, [x0, #-1]
    //     0x68927c: and             x16, x17, x16, lsr #2
    //     0x689280: tst             x16, HEAP, lsr #32
    //     0x689284: b.eq            #0x68928c
    //     0x689288: bl              #0xd67e5c
    // 0x68928c: b               #0x689428
    // 0x689290: mov             x2, x3
    // 0x689294: LoadField: r3 = r0->field_83
    //     0x689294: ldur            w3, [x0, #0x83]
    // 0x689298: DecompressPointer r3
    //     0x689298: add             x3, x3, HEAP, lsl #32
    // 0x68929c: cmp             w3, NULL
    // 0x6892a0: b.eq            #0x689544
    // 0x6892a4: LoadField: r4 = r3->field_7
    //     0x6892a4: ldur            x4, [x3, #7]
    // 0x6892a8: cmp             x4, #0
    // 0x6892ac: b.gt            #0x68932c
    // 0x6892b0: r16 = Instance_Axis
    //     0x6892b0: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x6892b4: ldr             x16, [x16, #0x440]
    // 0x6892b8: cmp             w1, w16
    // 0x6892bc: b.ne            #0x6892d8
    // 0x6892c0: LoadField: r1 = r0->field_57
    //     0x6892c0: ldur            w1, [x0, #0x57]
    // 0x6892c4: DecompressPointer r1
    //     0x6892c4: add             x1, x1, HEAP, lsl #32
    // 0x6892c8: cmp             w1, NULL
    // 0x6892cc: b.eq            #0x689548
    // 0x6892d0: LoadField: d0 = r1->field_7
    //     0x6892d0: ldur            d0, [x1, #7]
    // 0x6892d4: b               #0x6892ec
    // 0x6892d8: LoadField: r1 = r0->field_57
    //     0x6892d8: ldur            w1, [x0, #0x57]
    // 0x6892dc: DecompressPointer r1
    //     0x6892dc: add             x1, x1, HEAP, lsl #32
    // 0x6892e0: cmp             w1, NULL
    // 0x6892e4: b.eq            #0x68954c
    // 0x6892e8: LoadField: d0 = r1->field_f
    //     0x6892e8: ldur            d0, [x1, #0xf]
    // 0x6892ec: r1 = inline_Allocate_Double()
    //     0x6892ec: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x6892f0: add             x1, x1, #0x10
    //     0x6892f4: cmp             x3, x1
    //     0x6892f8: b.ls            #0x689550
    //     0x6892fc: str             x1, [THR, #0x60]  ; THR::top
    //     0x689300: sub             x1, x1, #0xf
    //     0x689304: mov             x3, #0xd108
    //     0x689308: movk            x3, #3, lsl #16
    //     0x68930c: stur            x3, [x1, #-1]
    // 0x689310: StoreField: r1->field_7 = d0
    //     0x689310: stur            d0, [x1, #7]
    // 0x689314: stp             xzr, x2, [SP, #-0x10]!
    // 0x689318: SaveReg r1
    //     0x689318: str             x1, [SP, #-8]!
    // 0x68931c: r0 = insert()
    //     0x68931c: bl              #0x5f0388  ; [dart:core] _GrowableList::insert
    // 0x689320: add             SP, SP, #0x18
    // 0x689324: ldur            x2, [fp, #-0x10]
    // 0x689328: b               #0x689428
    // 0x68932c: r16 = Instance_Axis
    //     0x68932c: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x689330: ldr             x16, [x16, #0x440]
    // 0x689334: cmp             w1, w16
    // 0x689338: b.ne            #0x689358
    // 0x68933c: ldr             x0, [fp, #0x10]
    // 0x689340: LoadField: r1 = r0->field_57
    //     0x689340: ldur            w1, [x0, #0x57]
    // 0x689344: DecompressPointer r1
    //     0x689344: add             x1, x1, HEAP, lsl #32
    // 0x689348: cmp             w1, NULL
    // 0x68934c: b.eq            #0x68956c
    // 0x689350: LoadField: d0 = r1->field_7
    //     0x689350: ldur            d0, [x1, #7]
    // 0x689354: b               #0x689370
    // 0x689358: ldr             x0, [fp, #0x10]
    // 0x68935c: LoadField: r1 = r0->field_57
    //     0x68935c: ldur            w1, [x0, #0x57]
    // 0x689360: DecompressPointer r1
    //     0x689360: add             x1, x1, HEAP, lsl #32
    // 0x689364: cmp             w1, NULL
    // 0x689368: b.eq            #0x689570
    // 0x68936c: LoadField: d0 = r1->field_f
    //     0x68936c: ldur            d0, [x1, #0xf]
    // 0x689370: ldur            x1, [fp, #-0x10]
    // 0x689374: stur            d0, [fp, #-0x20]
    // 0x689378: LoadField: r2 = r1->field_b
    //     0x689378: ldur            w2, [x1, #0xb]
    // 0x68937c: DecompressPointer r2
    //     0x68937c: add             x2, x2, HEAP, lsl #32
    // 0x689380: stur            x2, [fp, #-8]
    // 0x689384: LoadField: r3 = r1->field_f
    //     0x689384: ldur            w3, [x1, #0xf]
    // 0x689388: DecompressPointer r3
    //     0x689388: add             x3, x3, HEAP, lsl #32
    // 0x68938c: LoadField: r4 = r3->field_b
    //     0x68938c: ldur            w4, [x3, #0xb]
    // 0x689390: DecompressPointer r4
    //     0x689390: add             x4, x4, HEAP, lsl #32
    // 0x689394: cmp             w2, w4
    // 0x689398: b.ne            #0x6893a8
    // 0x68939c: SaveReg r1
    //     0x68939c: str             x1, [SP, #-8]!
    // 0x6893a0: r0 = _growToNextCapacity()
    //     0x6893a0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6893a4: add             SP, SP, #8
    // 0x6893a8: ldur            x2, [fp, #-0x10]
    // 0x6893ac: ldur            d0, [fp, #-0x20]
    // 0x6893b0: ldur            x0, [fp, #-8]
    // 0x6893b4: r3 = LoadInt32Instr(r0)
    //     0x6893b4: sbfx            x3, x0, #1, #0x1f
    // 0x6893b8: add             x0, x3, #1
    // 0x6893bc: lsl             x1, x0, #1
    // 0x6893c0: StoreField: r2->field_b = r1
    //     0x6893c0: stur            w1, [x2, #0xb]
    // 0x6893c4: mov             x1, x3
    // 0x6893c8: cmp             x1, x0
    // 0x6893cc: b.hs            #0x689574
    // 0x6893d0: LoadField: r1 = r2->field_f
    //     0x6893d0: ldur            w1, [x2, #0xf]
    // 0x6893d4: DecompressPointer r1
    //     0x6893d4: add             x1, x1, HEAP, lsl #32
    // 0x6893d8: r0 = inline_Allocate_Double()
    //     0x6893d8: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0x6893dc: add             x0, x0, #0x10
    //     0x6893e0: cmp             x4, x0
    //     0x6893e4: b.ls            #0x689578
    //     0x6893e8: str             x0, [THR, #0x60]  ; THR::top
    //     0x6893ec: sub             x0, x0, #0xf
    //     0x6893f0: mov             x4, #0xd108
    //     0x6893f4: movk            x4, #3, lsl #16
    //     0x6893f8: stur            x4, [x0, #-1]
    // 0x6893fc: StoreField: r0->field_7 = d0
    //     0x6893fc: stur            d0, [x0, #7]
    // 0x689400: ArrayStore: r1[r3] = r0  ; List_4
    //     0x689400: add             x25, x1, x3, lsl #2
    //     0x689404: add             x25, x25, #0xf
    //     0x689408: str             w0, [x25]
    //     0x68940c: tbz             w0, #0, #0x689428
    //     0x689410: ldurb           w16, [x1, #-1]
    //     0x689414: ldurb           w17, [x0, #-1]
    //     0x689418: and             x16, x17, x16, lsr #2
    //     0x68941c: tst             x16, HEAP, lsr #32
    //     0x689420: b.eq            #0x689428
    //     0x689424: bl              #0xd67e5c
    // 0x689428: ldr             x0, [fp, #0x10]
    // 0x68942c: LoadField: r1 = r0->field_9f
    //     0x68942c: ldur            w1, [x0, #0x9f]
    // 0x689430: DecompressPointer r1
    //     0x689430: add             x1, x1, HEAP, lsl #32
    // 0x689434: cmp             w1, NULL
    // 0x689438: b.eq            #0x689598
    // 0x68943c: LoadField: r3 = r0->field_83
    //     0x68943c: ldur            w3, [x0, #0x83]
    // 0x689440: DecompressPointer r3
    //     0x689440: add             x3, x3, HEAP, lsl #32
    // 0x689444: cmp             w3, NULL
    // 0x689448: b.eq            #0x68959c
    // 0x68944c: LoadField: r4 = r0->field_73
    //     0x68944c: ldur            w4, [x0, #0x73]
    // 0x689450: DecompressPointer r4
    //     0x689450: add             x4, x4, HEAP, lsl #32
    // 0x689454: r16 = Instance_Axis
    //     0x689454: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x689458: ldr             x16, [x16, #0x440]
    // 0x68945c: cmp             w4, w16
    // 0x689460: b.ne            #0x68947c
    // 0x689464: LoadField: r4 = r0->field_57
    //     0x689464: ldur            w4, [x0, #0x57]
    // 0x689468: DecompressPointer r4
    //     0x689468: add             x4, x4, HEAP, lsl #32
    // 0x68946c: cmp             w4, NULL
    // 0x689470: b.eq            #0x6895a0
    // 0x689474: LoadField: d0 = r4->field_7
    //     0x689474: ldur            d0, [x4, #7]
    // 0x689478: b               #0x689490
    // 0x68947c: LoadField: r4 = r0->field_57
    //     0x68947c: ldur            w4, [x0, #0x57]
    // 0x689480: DecompressPointer r4
    //     0x689480: add             x4, x4, HEAP, lsl #32
    // 0x689484: cmp             w4, NULL
    // 0x689488: b.eq            #0x6895a4
    // 0x68948c: LoadField: d0 = r4->field_f
    //     0x68948c: ldur            d0, [x4, #0xf]
    // 0x689490: r0 = inline_Allocate_Double()
    //     0x689490: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0x689494: add             x0, x0, #0x10
    //     0x689498: cmp             x4, x0
    //     0x68949c: b.ls            #0x6895a8
    //     0x6894a0: str             x0, [THR, #0x60]  ; THR::top
    //     0x6894a4: sub             x0, x0, #0xf
    //     0x6894a8: mov             x4, #0xd108
    //     0x6894ac: movk            x4, #3, lsl #16
    //     0x6894b0: stur            x4, [x0, #-1]
    // 0x6894b4: StoreField: r0->field_7 = d0
    //     0x6894b4: stur            d0, [x0, #7]
    // 0x6894b8: stp             x2, x1, [SP, #-0x10]!
    // 0x6894bc: stp             x0, x3, [SP, #-0x10]!
    // 0x6894c0: mov             x0, x1
    // 0x6894c4: ClosureCall
    //     0x6894c4: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0x6894c8: ldur            x2, [x0, #0x1f]
    //     0x6894cc: blr             x2
    // 0x6894d0: add             SP, SP, #0x20
    // 0x6894d4: r0 = Null
    //     0x6894d4: mov             x0, NULL
    // 0x6894d8: LeaveFrame
    //     0x6894d8: mov             SP, fp
    //     0x6894dc: ldp             fp, lr, [SP], #0x10
    // 0x6894e0: ret
    //     0x6894e0: ret             
    // 0x6894e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6894e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6894e8: b               #0x688fe8
    // 0x6894ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6894ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6894f0: b               #0x689034
    // 0x6894f4: r0 = RangeErrorSharedWithFPURegs()
    //     0x6894f4: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x6894f8: SaveReg d0
    //     0x6894f8: str             q0, [SP, #-0x10]!
    // 0x6894fc: stp             x3, x4, [SP, #-0x10]!
    // 0x689500: stp             x1, x2, [SP, #-0x10]!
    // 0x689504: r0 = AllocateDouble()
    //     0x689504: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x689508: ldp             x1, x2, [SP], #0x10
    // 0x68950c: ldp             x3, x4, [SP], #0x10
    // 0x689510: RestoreReg d0
    //     0x689510: ldr             q0, [SP], #0x10
    // 0x689514: b               #0x689148
    // 0x689518: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689518: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68951c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68951c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689520: r0 = RangeErrorSharedWithFPURegs()
    //     0x689520: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x689524: SaveReg d0
    //     0x689524: str             q0, [SP, #-0x10]!
    // 0x689528: stp             x2, x3, [SP, #-0x10]!
    // 0x68952c: SaveReg r1
    //     0x68952c: str             x1, [SP, #-8]!
    // 0x689530: r0 = AllocateDouble()
    //     0x689530: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x689534: RestoreReg r1
    //     0x689534: ldr             x1, [SP], #8
    // 0x689538: ldp             x2, x3, [SP], #0x10
    // 0x68953c: RestoreReg d0
    //     0x68953c: ldr             q0, [SP], #0x10
    // 0x689540: b               #0x689260
    // 0x689544: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689544: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689548: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689548: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68954c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68954c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689550: SaveReg d0
    //     0x689550: str             q0, [SP, #-0x10]!
    // 0x689554: stp             x0, x2, [SP, #-0x10]!
    // 0x689558: r0 = AllocateDouble()
    //     0x689558: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68955c: mov             x1, x0
    // 0x689560: ldp             x0, x2, [SP], #0x10
    // 0x689564: RestoreReg d0
    //     0x689564: ldr             q0, [SP], #0x10
    // 0x689568: b               #0x689310
    // 0x68956c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68956c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689570: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689570: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689574: r0 = RangeErrorSharedWithFPURegs()
    //     0x689574: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x689578: SaveReg d0
    //     0x689578: str             q0, [SP, #-0x10]!
    // 0x68957c: stp             x2, x3, [SP, #-0x10]!
    // 0x689580: SaveReg r1
    //     0x689580: str             x1, [SP, #-8]!
    // 0x689584: r0 = AllocateDouble()
    //     0x689584: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x689588: RestoreReg r1
    //     0x689588: ldr             x1, [SP], #8
    // 0x68958c: ldp             x2, x3, [SP], #0x10
    // 0x689590: RestoreReg d0
    //     0x689590: ldr             q0, [SP], #0x10
    // 0x689594: b               #0x6893fc
    // 0x689598: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689598: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68959c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68959c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6895a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6895a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6895a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6895a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6895a8: SaveReg d0
    //     0x6895a8: str             q0, [SP, #-0x10]!
    // 0x6895ac: stp             x2, x3, [SP, #-0x10]!
    // 0x6895b0: SaveReg r1
    //     0x6895b0: str             x1, [SP, #-8]!
    // 0x6895b4: r0 = AllocateDouble()
    //     0x6895b4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6895b8: RestoreReg r1
    //     0x6895b8: ldr             x1, [SP], #8
    // 0x6895bc: ldp             x2, x3, [SP], #0x10
    // 0x6895c0: RestoreReg d0
    //     0x6895c0: ldr             q0, [SP], #0x10
    // 0x6895c4: b               #0x6894b4
  }
}

// class id: 3380, size: 0x2c, field offset: 0x14
class _ExtendedTabBarState extends State<ExtendedTabBar> {

  late List<GlobalKey<State<StatefulWidget>>> _tabKeys; // offset: 0x28
  late double _tabStripWidth; // offset: 0x24

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x79eb64, size: 0x50c
    // 0x79eb64: EnterFrame
    //     0x79eb64: stp             fp, lr, [SP, #-0x10]!
    //     0x79eb68: mov             fp, SP
    // 0x79eb6c: AllocStack(0x38)
    //     0x79eb6c: sub             SP, SP, #0x38
    // 0x79eb70: CheckStackOverflow
    //     0x79eb70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79eb74: cmp             SP, x16
    //     0x79eb78: b.ls            #0x79f030
    // 0x79eb7c: ldr             x0, [fp, #0x10]
    // 0x79eb80: r2 = Null
    //     0x79eb80: mov             x2, NULL
    // 0x79eb84: r1 = Null
    //     0x79eb84: mov             x1, NULL
    // 0x79eb88: r4 = 59
    //     0x79eb88: mov             x4, #0x3b
    // 0x79eb8c: branchIfSmi(r0, 0x79eb98)
    //     0x79eb8c: tbz             w0, #0, #0x79eb98
    // 0x79eb90: r4 = LoadClassIdInstr(r0)
    //     0x79eb90: ldur            x4, [x0, #-1]
    //     0x79eb94: ubfx            x4, x4, #0xc, #0x14
    // 0x79eb98: r17 = 4191
    //     0x79eb98: mov             x17, #0x105f
    // 0x79eb9c: cmp             x4, x17
    // 0x79eba0: b.eq            #0x79ebb8
    // 0x79eba4: r8 = ExtendedTabBar
    //     0x79eba4: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4bfc0] Type: ExtendedTabBar
    //     0x79eba8: ldr             x8, [x8, #0xfc0]
    // 0x79ebac: r3 = Null
    //     0x79ebac: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4bfc8] Null
    //     0x79ebb0: ldr             x3, [x3, #0xfc8]
    // 0x79ebb4: r0 = ExtendedTabBar()
    //     0x79ebb4: bl              #0x7a03f4  ; IsType_ExtendedTabBar_Stub
    // 0x79ebb8: ldr             x3, [fp, #0x18]
    // 0x79ebbc: LoadField: r2 = r3->field_7
    //     0x79ebbc: ldur            w2, [x3, #7]
    // 0x79ebc0: DecompressPointer r2
    //     0x79ebc0: add             x2, x2, HEAP, lsl #32
    // 0x79ebc4: ldr             x0, [fp, #0x10]
    // 0x79ebc8: r1 = Null
    //     0x79ebc8: mov             x1, NULL
    // 0x79ebcc: cmp             w2, NULL
    // 0x79ebd0: b.eq            #0x79ebf4
    // 0x79ebd4: LoadField: r4 = r2->field_17
    //     0x79ebd4: ldur            w4, [x2, #0x17]
    // 0x79ebd8: DecompressPointer r4
    //     0x79ebd8: add             x4, x4, HEAP, lsl #32
    // 0x79ebdc: r8 = X0 bound StatefulWidget
    //     0x79ebdc: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x79ebe0: ldr             x8, [x8, #0x858]
    // 0x79ebe4: LoadField: r9 = r4->field_7
    //     0x79ebe4: ldur            x9, [x4, #7]
    // 0x79ebe8: r3 = Null
    //     0x79ebe8: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4bfd8] Null
    //     0x79ebec: ldr             x3, [x3, #0xfd8]
    // 0x79ebf0: blr             x9
    // 0x79ebf4: ldr             x0, [fp, #0x18]
    // 0x79ebf8: LoadField: r1 = r0->field_b
    //     0x79ebf8: ldur            w1, [x0, #0xb]
    // 0x79ebfc: DecompressPointer r1
    //     0x79ebfc: add             x1, x1, HEAP, lsl #32
    // 0x79ec00: cmp             w1, NULL
    // 0x79ec04: b.eq            #0x79f038
    // 0x79ec08: LoadField: r2 = r1->field_13
    //     0x79ec08: ldur            w2, [x1, #0x13]
    // 0x79ec0c: DecompressPointer r2
    //     0x79ec0c: add             x2, x2, HEAP, lsl #32
    // 0x79ec10: ldr             x3, [fp, #0x10]
    // 0x79ec14: LoadField: r4 = r3->field_13
    //     0x79ec14: ldur            w4, [x3, #0x13]
    // 0x79ec18: DecompressPointer r4
    //     0x79ec18: add             x4, x4, HEAP, lsl #32
    // 0x79ec1c: cmp             w2, w4
    // 0x79ec20: b.eq            #0x79ec48
    // 0x79ec24: SaveReg r0
    //     0x79ec24: str             x0, [SP, #-8]!
    // 0x79ec28: r0 = _updateTabController()
    //     0x79ec28: bl              #0x79f430  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_updateTabController
    // 0x79ec2c: add             SP, SP, #8
    // 0x79ec30: ldr             x16, [fp, #0x18]
    // 0x79ec34: SaveReg r16
    //     0x79ec34: str             x16, [SP, #-8]!
    // 0x79ec38: r0 = _initIndicatorPainter()
    //     0x79ec38: bl              #0x79f070  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_initIndicatorPainter
    // 0x79ec3c: add             SP, SP, #8
    // 0x79ec40: ldr             x1, [fp, #0x18]
    // 0x79ec44: b               #0x79ecbc
    // 0x79ec48: d0 = 2.000000
    //     0x79ec48: fmov            d0, #2.00000000
    // 0x79ec4c: fcmp            d0, d0
    // 0x79ec50: b.ne            #0x79ec90
    // 0x79ec54: ldr             x0, [fp, #0x10]
    // 0x79ec58: LoadField: r2 = r1->field_33
    //     0x79ec58: ldur            w2, [x1, #0x33]
    // 0x79ec5c: DecompressPointer r2
    //     0x79ec5c: add             x2, x2, HEAP, lsl #32
    // 0x79ec60: LoadField: r3 = r0->field_33
    //     0x79ec60: ldur            w3, [x0, #0x33]
    // 0x79ec64: DecompressPointer r3
    //     0x79ec64: add             x3, x3, HEAP, lsl #32
    // 0x79ec68: cmp             w2, w3
    // 0x79ec6c: b.ne            #0x79ec90
    // 0x79ec70: LoadField: r2 = r1->field_2b
    //     0x79ec70: ldur            w2, [x1, #0x2b]
    // 0x79ec74: DecompressPointer r2
    //     0x79ec74: add             x2, x2, HEAP, lsl #32
    // 0x79ec78: LoadField: r1 = r0->field_2b
    //     0x79ec78: ldur            w1, [x0, #0x2b]
    // 0x79ec7c: DecompressPointer r1
    //     0x79ec7c: add             x1, x1, HEAP, lsl #32
    // 0x79ec80: stp             x1, x2, [SP, #-0x10]!
    // 0x79ec84: r0 = ==()
    //     0x79ec84: bl              #0xc80a04  ; [package:flutter/src/painting/box_decoration.dart] BoxDecoration::==
    // 0x79ec88: add             SP, SP, #0x10
    // 0x79ec8c: tbz             w0, #4, #0x79eca8
    // 0x79ec90: ldr             x16, [fp, #0x18]
    // 0x79ec94: SaveReg r16
    //     0x79ec94: str             x16, [SP, #-8]!
    // 0x79ec98: r0 = _initIndicatorPainter()
    //     0x79ec98: bl              #0x79f070  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_initIndicatorPainter
    // 0x79ec9c: add             SP, SP, #8
    // 0x79eca0: ldr             x1, [fp, #0x18]
    // 0x79eca4: b               #0x79ecbc
    // 0x79eca8: ldr             x1, [fp, #0x18]
    // 0x79ecac: LoadField: r0 = r1->field_b
    //     0x79ecac: ldur            w0, [x1, #0xb]
    // 0x79ecb0: DecompressPointer r0
    //     0x79ecb0: add             x0, x0, HEAP, lsl #32
    // 0x79ecb4: cmp             w0, NULL
    // 0x79ecb8: b.eq            #0x79f03c
    // 0x79ecbc: ldr             x2, [fp, #0x10]
    // 0x79ecc0: LoadField: r0 = r1->field_b
    //     0x79ecc0: ldur            w0, [x1, #0xb]
    // 0x79ecc4: DecompressPointer r0
    //     0x79ecc4: add             x0, x0, HEAP, lsl #32
    // 0x79ecc8: cmp             w0, NULL
    // 0x79eccc: b.eq            #0x79f040
    // 0x79ecd0: LoadField: r3 = r0->field_f
    //     0x79ecd0: ldur            w3, [x0, #0xf]
    // 0x79ecd4: DecompressPointer r3
    //     0x79ecd4: add             x3, x3, HEAP, lsl #32
    // 0x79ecd8: r0 = LoadClassIdInstr(r3)
    //     0x79ecd8: ldur            x0, [x3, #-1]
    //     0x79ecdc: ubfx            x0, x0, #0xc, #0x14
    // 0x79ece0: SaveReg r3
    //     0x79ece0: str             x3, [SP, #-8]!
    // 0x79ece4: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x79ece4: mov             x17, #0xb8ea
    //     0x79ece8: add             lr, x0, x17
    //     0x79ecec: ldr             lr, [x21, lr, lsl #3]
    //     0x79ecf0: blr             lr
    // 0x79ecf4: add             SP, SP, #8
    // 0x79ecf8: mov             x1, x0
    // 0x79ecfc: ldr             x0, [fp, #0x10]
    // 0x79ed00: stur            x1, [fp, #-0x10]
    // 0x79ed04: LoadField: r2 = r0->field_f
    //     0x79ed04: ldur            w2, [x0, #0xf]
    // 0x79ed08: DecompressPointer r2
    //     0x79ed08: add             x2, x2, HEAP, lsl #32
    // 0x79ed0c: stur            x2, [fp, #-8]
    // 0x79ed10: r0 = LoadClassIdInstr(r2)
    //     0x79ed10: ldur            x0, [x2, #-1]
    //     0x79ed14: ubfx            x0, x0, #0xc, #0x14
    // 0x79ed18: SaveReg r2
    //     0x79ed18: str             x2, [SP, #-8]!
    // 0x79ed1c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x79ed1c: mov             x17, #0xb8ea
    //     0x79ed20: add             lr, x0, x17
    //     0x79ed24: ldr             lr, [x21, lr, lsl #3]
    //     0x79ed28: blr             lr
    // 0x79ed2c: add             SP, SP, #8
    // 0x79ed30: mov             x1, x0
    // 0x79ed34: ldur            x0, [fp, #-0x10]
    // 0x79ed38: r2 = LoadInt32Instr(r0)
    //     0x79ed38: sbfx            x2, x0, #1, #0x1f
    // 0x79ed3c: r0 = LoadInt32Instr(r1)
    //     0x79ed3c: sbfx            x0, x1, #1, #0x1f
    // 0x79ed40: cmp             x2, x0
    // 0x79ed44: b.le            #0x79eedc
    // 0x79ed48: ldr             x2, [fp, #0x18]
    // 0x79ed4c: ldur            x1, [fp, #-8]
    // 0x79ed50: LoadField: r0 = r2->field_b
    //     0x79ed50: ldur            w0, [x2, #0xb]
    // 0x79ed54: DecompressPointer r0
    //     0x79ed54: add             x0, x0, HEAP, lsl #32
    // 0x79ed58: cmp             w0, NULL
    // 0x79ed5c: b.eq            #0x79f044
    // 0x79ed60: LoadField: r3 = r0->field_f
    //     0x79ed60: ldur            w3, [x0, #0xf]
    // 0x79ed64: DecompressPointer r3
    //     0x79ed64: add             x3, x3, HEAP, lsl #32
    // 0x79ed68: r0 = LoadClassIdInstr(r3)
    //     0x79ed68: ldur            x0, [x3, #-1]
    //     0x79ed6c: ubfx            x0, x0, #0xc, #0x14
    // 0x79ed70: SaveReg r3
    //     0x79ed70: str             x3, [SP, #-8]!
    // 0x79ed74: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x79ed74: mov             x17, #0xb8ea
    //     0x79ed78: add             lr, x0, x17
    //     0x79ed7c: ldr             lr, [x21, lr, lsl #3]
    //     0x79ed80: blr             lr
    // 0x79ed84: add             SP, SP, #8
    // 0x79ed88: mov             x2, x0
    // 0x79ed8c: ldur            x1, [fp, #-8]
    // 0x79ed90: stur            x2, [fp, #-0x10]
    // 0x79ed94: r0 = LoadClassIdInstr(r1)
    //     0x79ed94: ldur            x0, [x1, #-1]
    //     0x79ed98: ubfx            x0, x0, #0xc, #0x14
    // 0x79ed9c: SaveReg r1
    //     0x79ed9c: str             x1, [SP, #-8]!
    // 0x79eda0: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x79eda0: mov             x17, #0xb8ea
    //     0x79eda4: add             lr, x0, x17
    //     0x79eda8: ldr             lr, [x21, lr, lsl #3]
    //     0x79edac: blr             lr
    // 0x79edb0: add             SP, SP, #8
    // 0x79edb4: mov             x1, x0
    // 0x79edb8: ldur            x0, [fp, #-0x10]
    // 0x79edbc: r2 = LoadInt32Instr(r0)
    //     0x79edbc: sbfx            x2, x0, #1, #0x1f
    // 0x79edc0: r0 = LoadInt32Instr(r1)
    //     0x79edc0: sbfx            x0, x1, #1, #0x1f
    // 0x79edc4: sub             x1, x2, x0
    // 0x79edc8: ldr             x2, [fp, #0x18]
    // 0x79edcc: LoadField: r0 = r2->field_27
    //     0x79edcc: ldur            w0, [x2, #0x27]
    // 0x79edd0: DecompressPointer r0
    //     0x79edd0: add             x0, x0, HEAP, lsl #32
    // 0x79edd4: r16 = Sentinel
    //     0x79edd4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x79edd8: cmp             w0, w16
    // 0x79eddc: b.eq            #0x79f048
    // 0x79ede0: stur            x0, [fp, #-0x10]
    // 0x79ede4: r16 = <GlobalKey<State<StatefulWidget>>>
    //     0x79ede4: add             x16, PP, #0x37, lsl #12  ; [pp+0x37fb0] TypeArguments: <GlobalKey<State<StatefulWidget>>>
    //     0x79ede8: ldr             x16, [x16, #0xfb0]
    // 0x79edec: stp             x1, x16, [SP, #-0x10]!
    // 0x79edf0: r0 = _GrowableList()
    //     0x79edf0: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x79edf4: add             SP, SP, #0x10
    // 0x79edf8: stur            x0, [fp, #-0x30]
    // 0x79edfc: LoadField: r1 = r0->field_b
    //     0x79edfc: ldur            w1, [x0, #0xb]
    // 0x79ee00: DecompressPointer r1
    //     0x79ee00: add             x1, x1, HEAP, lsl #32
    // 0x79ee04: r2 = LoadInt32Instr(r1)
    //     0x79ee04: sbfx            x2, x1, #1, #0x1f
    // 0x79ee08: stur            x2, [fp, #-0x28]
    // 0x79ee0c: LoadField: r3 = r0->field_f
    //     0x79ee0c: ldur            w3, [x0, #0xf]
    // 0x79ee10: DecompressPointer r3
    //     0x79ee10: add             x3, x3, HEAP, lsl #32
    // 0x79ee14: stur            x3, [fp, #-0x20]
    // 0x79ee18: r4 = 0
    //     0x79ee18: mov             x4, #0
    // 0x79ee1c: stur            x4, [fp, #-0x18]
    // 0x79ee20: CheckStackOverflow
    //     0x79ee20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79ee24: cmp             SP, x16
    //     0x79ee28: b.ls            #0x79f054
    // 0x79ee2c: cmp             x4, x2
    // 0x79ee30: b.ge            #0x79eea8
    // 0x79ee34: r1 = <State<StatefulWidget>>
    //     0x79ee34: ldr             x1, [PP, #0x3b30]  ; [pp+0x3b30] TypeArguments: <State<StatefulWidget>>
    // 0x79ee38: r0 = LabeledGlobalKey()
    //     0x79ee38: bl              #0x594e78  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State<StatefulWidget>> (size=0x10)
    // 0x79ee3c: mov             x3, x0
    // 0x79ee40: r2 = Null
    //     0x79ee40: mov             x2, NULL
    // 0x79ee44: r1 = Null
    //     0x79ee44: mov             x1, NULL
    // 0x79ee48: stur            x3, [fp, #-0x38]
    // 0x79ee4c: r8 = GlobalKey<State<StatefulWidget>>
    //     0x79ee4c: add             x8, PP, #0x37, lsl #12  ; [pp+0x37fb8] Type: GlobalKey<State<StatefulWidget>>
    //     0x79ee50: ldr             x8, [x8, #0xfb8]
    // 0x79ee54: r3 = Null
    //     0x79ee54: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4bfe8] Null
    //     0x79ee58: ldr             x3, [x3, #0xfe8]
    // 0x79ee5c: r0 = DefaultTypeTest()
    //     0x79ee5c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x79ee60: ldur            x1, [fp, #-0x20]
    // 0x79ee64: ldur            x0, [fp, #-0x38]
    // 0x79ee68: ldur            x2, [fp, #-0x18]
    // 0x79ee6c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x79ee6c: add             x25, x1, x2, lsl #2
    //     0x79ee70: add             x25, x25, #0xf
    //     0x79ee74: str             w0, [x25]
    //     0x79ee78: tbz             w0, #0, #0x79ee94
    //     0x79ee7c: ldurb           w16, [x1, #-1]
    //     0x79ee80: ldurb           w17, [x0, #-1]
    //     0x79ee84: and             x16, x17, x16, lsr #2
    //     0x79ee88: tst             x16, HEAP, lsr #32
    //     0x79ee8c: b.eq            #0x79ee94
    //     0x79ee90: bl              #0xd67e5c
    // 0x79ee94: add             x4, x2, #1
    // 0x79ee98: ldur            x0, [fp, #-0x30]
    // 0x79ee9c: ldur            x3, [fp, #-0x20]
    // 0x79eea0: ldur            x2, [fp, #-0x28]
    // 0x79eea4: b               #0x79ee1c
    // 0x79eea8: ldur            x0, [fp, #-0x10]
    // 0x79eeac: r1 = LoadClassIdInstr(r0)
    //     0x79eeac: ldur            x1, [x0, #-1]
    //     0x79eeb0: ubfx            x1, x1, #0xc, #0x14
    // 0x79eeb4: ldur            x16, [fp, #-0x30]
    // 0x79eeb8: stp             x16, x0, [SP, #-0x10]!
    // 0x79eebc: mov             x0, x1
    // 0x79eec0: r0 = GDT[cid_x0 + 0x10267]()
    //     0x79eec0: mov             x17, #0x267
    //     0x79eec4: movk            x17, #1, lsl #16
    //     0x79eec8: add             lr, x0, x17
    //     0x79eecc: ldr             lr, [x21, lr, lsl #3]
    //     0x79eed0: blr             lr
    // 0x79eed4: add             SP, SP, #0x10
    // 0x79eed8: b               #0x79f020
    // 0x79eedc: ldr             x2, [fp, #0x18]
    // 0x79eee0: ldur            x1, [fp, #-8]
    // 0x79eee4: LoadField: r0 = r2->field_b
    //     0x79eee4: ldur            w0, [x2, #0xb]
    // 0x79eee8: DecompressPointer r0
    //     0x79eee8: add             x0, x0, HEAP, lsl #32
    // 0x79eeec: cmp             w0, NULL
    // 0x79eef0: b.eq            #0x79f05c
    // 0x79eef4: LoadField: r3 = r0->field_f
    //     0x79eef4: ldur            w3, [x0, #0xf]
    // 0x79eef8: DecompressPointer r3
    //     0x79eef8: add             x3, x3, HEAP, lsl #32
    // 0x79eefc: r0 = LoadClassIdInstr(r3)
    //     0x79eefc: ldur            x0, [x3, #-1]
    //     0x79ef00: ubfx            x0, x0, #0xc, #0x14
    // 0x79ef04: SaveReg r3
    //     0x79ef04: str             x3, [SP, #-8]!
    // 0x79ef08: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x79ef08: mov             x17, #0xb8ea
    //     0x79ef0c: add             lr, x0, x17
    //     0x79ef10: ldr             lr, [x21, lr, lsl #3]
    //     0x79ef14: blr             lr
    // 0x79ef18: add             SP, SP, #8
    // 0x79ef1c: mov             x2, x0
    // 0x79ef20: ldur            x1, [fp, #-8]
    // 0x79ef24: stur            x2, [fp, #-0x10]
    // 0x79ef28: r0 = LoadClassIdInstr(r1)
    //     0x79ef28: ldur            x0, [x1, #-1]
    //     0x79ef2c: ubfx            x0, x0, #0xc, #0x14
    // 0x79ef30: SaveReg r1
    //     0x79ef30: str             x1, [SP, #-8]!
    // 0x79ef34: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x79ef34: mov             x17, #0xb8ea
    //     0x79ef38: add             lr, x0, x17
    //     0x79ef3c: ldr             lr, [x21, lr, lsl #3]
    //     0x79ef40: blr             lr
    // 0x79ef44: add             SP, SP, #8
    // 0x79ef48: mov             x1, x0
    // 0x79ef4c: ldur            x0, [fp, #-0x10]
    // 0x79ef50: r2 = LoadInt32Instr(r0)
    //     0x79ef50: sbfx            x2, x0, #1, #0x1f
    // 0x79ef54: r0 = LoadInt32Instr(r1)
    //     0x79ef54: sbfx            x0, x1, #1, #0x1f
    // 0x79ef58: cmp             x2, x0
    // 0x79ef5c: b.ge            #0x79f020
    // 0x79ef60: ldr             x0, [fp, #0x18]
    // 0x79ef64: ldur            x1, [fp, #-8]
    // 0x79ef68: LoadField: r2 = r0->field_27
    //     0x79ef68: ldur            w2, [x0, #0x27]
    // 0x79ef6c: DecompressPointer r2
    //     0x79ef6c: add             x2, x2, HEAP, lsl #32
    // 0x79ef70: r16 = Sentinel
    //     0x79ef70: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x79ef74: cmp             w2, w16
    // 0x79ef78: b.eq            #0x79f060
    // 0x79ef7c: stur            x2, [fp, #-0x10]
    // 0x79ef80: LoadField: r3 = r0->field_b
    //     0x79ef80: ldur            w3, [x0, #0xb]
    // 0x79ef84: DecompressPointer r3
    //     0x79ef84: add             x3, x3, HEAP, lsl #32
    // 0x79ef88: cmp             w3, NULL
    // 0x79ef8c: b.eq            #0x79f06c
    // 0x79ef90: LoadField: r0 = r3->field_f
    //     0x79ef90: ldur            w0, [x3, #0xf]
    // 0x79ef94: DecompressPointer r0
    //     0x79ef94: add             x0, x0, HEAP, lsl #32
    // 0x79ef98: r3 = LoadClassIdInstr(r0)
    //     0x79ef98: ldur            x3, [x0, #-1]
    //     0x79ef9c: ubfx            x3, x3, #0xc, #0x14
    // 0x79efa0: SaveReg r0
    //     0x79efa0: str             x0, [SP, #-8]!
    // 0x79efa4: mov             x0, x3
    // 0x79efa8: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x79efa8: mov             x17, #0xb8ea
    //     0x79efac: add             lr, x0, x17
    //     0x79efb0: ldr             lr, [x21, lr, lsl #3]
    //     0x79efb4: blr             lr
    // 0x79efb8: add             SP, SP, #8
    // 0x79efbc: mov             x1, x0
    // 0x79efc0: ldur            x0, [fp, #-8]
    // 0x79efc4: stur            x1, [fp, #-0x20]
    // 0x79efc8: r2 = LoadClassIdInstr(r0)
    //     0x79efc8: ldur            x2, [x0, #-1]
    //     0x79efcc: ubfx            x2, x2, #0xc, #0x14
    // 0x79efd0: SaveReg r0
    //     0x79efd0: str             x0, [SP, #-8]!
    // 0x79efd4: mov             x0, x2
    // 0x79efd8: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x79efd8: mov             x17, #0xb8ea
    //     0x79efdc: add             lr, x0, x17
    //     0x79efe0: ldr             lr, [x21, lr, lsl #3]
    //     0x79efe4: blr             lr
    // 0x79efe8: add             SP, SP, #8
    // 0x79efec: r1 = LoadInt32Instr(r0)
    //     0x79efec: sbfx            x1, x0, #1, #0x1f
    // 0x79eff0: ldur            x0, [fp, #-0x10]
    // 0x79eff4: r2 = LoadClassIdInstr(r0)
    //     0x79eff4: ldur            x2, [x0, #-1]
    //     0x79eff8: ubfx            x2, x2, #0xc, #0x14
    // 0x79effc: ldur            x16, [fp, #-0x20]
    // 0x79f000: stp             x16, x0, [SP, #-0x10]!
    // 0x79f004: SaveReg r1
    //     0x79f004: str             x1, [SP, #-8]!
    // 0x79f008: mov             x0, x2
    // 0x79f00c: r0 = GDT[cid_x0 + 0x37f1]()
    //     0x79f00c: mov             x17, #0x37f1
    //     0x79f010: add             lr, x0, x17
    //     0x79f014: ldr             lr, [x21, lr, lsl #3]
    //     0x79f018: blr             lr
    // 0x79f01c: add             SP, SP, #0x18
    // 0x79f020: r0 = Null
    //     0x79f020: mov             x0, NULL
    // 0x79f024: LeaveFrame
    //     0x79f024: mov             SP, fp
    //     0x79f028: ldp             fp, lr, [SP], #0x10
    // 0x79f02c: ret
    //     0x79f02c: ret             
    // 0x79f030: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79f030: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79f034: b               #0x79eb7c
    // 0x79f038: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79f038: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79f03c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79f03c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79f040: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79f040: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79f044: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79f044: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79f048: r9 = _tabKeys
    //     0x79f048: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4bf80] Field <_ExtendedTabBarState@468487081._tabKeys@468487081>: late (offset: 0x28)
    //     0x79f04c: ldr             x9, [x9, #0xf80]
    // 0x79f050: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x79f050: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x79f054: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79f054: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79f058: b               #0x79ee2c
    // 0x79f05c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79f05c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79f060: r9 = _tabKeys
    //     0x79f060: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4bf80] Field <_ExtendedTabBarState@468487081._tabKeys@468487081>: late (offset: 0x28)
    //     0x79f064: ldr             x9, [x9, #0xf80]
    // 0x79f068: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x79f068: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x79f06c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79f06c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _initIndicatorPainter(/* No info */) {
    // ** addr: 0x79f070, size: 0x174
    // 0x79f070: EnterFrame
    //     0x79f070: stp             fp, lr, [SP, #-0x10]!
    //     0x79f074: mov             fp, SP
    // 0x79f078: AllocStack(0x30)
    //     0x79f078: sub             SP, SP, #0x30
    // 0x79f07c: CheckStackOverflow
    //     0x79f07c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79f080: cmp             SP, x16
    //     0x79f084: b.ls            #0x79f1c0
    // 0x79f088: ldr             x16, [fp, #0x10]
    // 0x79f08c: SaveReg r16
    //     0x79f08c: str             x16, [SP, #-8]!
    // 0x79f090: r0 = _controllerIsValid()
    //     0x79f090: bl              #0x79f3ec  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_controllerIsValid
    // 0x79f094: add             SP, SP, #8
    // 0x79f098: tbz             w0, #4, #0x79f0a4
    // 0x79f09c: r0 = Null
    //     0x79f09c: mov             x0, NULL
    // 0x79f0a0: b               #0x79f190
    // 0x79f0a4: ldr             x0, [fp, #0x10]
    // 0x79f0a8: LoadField: r1 = r0->field_17
    //     0x79f0a8: ldur            w1, [x0, #0x17]
    // 0x79f0ac: DecompressPointer r1
    //     0x79f0ac: add             x1, x1, HEAP, lsl #32
    // 0x79f0b0: stur            x1, [fp, #-8]
    // 0x79f0b4: cmp             w1, NULL
    // 0x79f0b8: b.eq            #0x79f1c8
    // 0x79f0bc: SaveReg r0
    //     0x79f0bc: str             x0, [SP, #-8]!
    // 0x79f0c0: r0 = restorationId()
    //     0x79f0c0: bl              #0x79ea64  ; [package:flutter/src/widgets/scrollable.dart] ScrollableState::restorationId
    // 0x79f0c4: add             SP, SP, #8
    // 0x79f0c8: mov             x1, x0
    // 0x79f0cc: ldr             x0, [fp, #0x10]
    // 0x79f0d0: stur            x1, [fp, #-0x10]
    // 0x79f0d4: LoadField: r2 = r0->field_b
    //     0x79f0d4: ldur            w2, [x0, #0xb]
    // 0x79f0d8: DecompressPointer r2
    //     0x79f0d8: add             x2, x2, HEAP, lsl #32
    // 0x79f0dc: cmp             w2, NULL
    // 0x79f0e0: b.eq            #0x79f1cc
    // 0x79f0e4: LoadField: r3 = r2->field_33
    //     0x79f0e4: ldur            w3, [x2, #0x33]
    // 0x79f0e8: DecompressPointer r3
    //     0x79f0e8: add             x3, x3, HEAP, lsl #32
    // 0x79f0ec: cmp             w3, NULL
    // 0x79f0f0: b.ne            #0x79f11c
    // 0x79f0f4: LoadField: r2 = r0->field_f
    //     0x79f0f4: ldur            w2, [x0, #0xf]
    // 0x79f0f8: DecompressPointer r2
    //     0x79f0f8: add             x2, x2, HEAP, lsl #32
    // 0x79f0fc: cmp             w2, NULL
    // 0x79f100: b.eq            #0x79f1d0
    // 0x79f104: SaveReg r2
    //     0x79f104: str             x2, [SP, #-8]!
    // 0x79f108: r0 = of()
    //     0x79f108: bl              #0x79f3a4  ; [package:flutter/src/material/tab_bar_theme.dart] TabBarTheme::of
    // 0x79f10c: add             SP, SP, #8
    // 0x79f110: LoadField: r1 = r0->field_f
    //     0x79f110: ldur            w1, [x0, #0xf]
    // 0x79f114: DecompressPointer r1
    //     0x79f114: add             x1, x1, HEAP, lsl #32
    // 0x79f118: b               #0x79f120
    // 0x79f11c: mov             x1, x3
    // 0x79f120: ldr             x0, [fp, #0x10]
    // 0x79f124: stur            x1, [fp, #-0x28]
    // 0x79f128: LoadField: r2 = r0->field_27
    //     0x79f128: ldur            w2, [x0, #0x27]
    // 0x79f12c: DecompressPointer r2
    //     0x79f12c: add             x2, x2, HEAP, lsl #32
    // 0x79f130: r16 = Sentinel
    //     0x79f130: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x79f134: cmp             w2, w16
    // 0x79f138: b.eq            #0x79f1d4
    // 0x79f13c: stur            x2, [fp, #-0x20]
    // 0x79f140: LoadField: r3 = r0->field_1b
    //     0x79f140: ldur            w3, [x0, #0x1b]
    // 0x79f144: DecompressPointer r3
    //     0x79f144: add             x3, x3, HEAP, lsl #32
    // 0x79f148: stur            x3, [fp, #-0x18]
    // 0x79f14c: LoadField: r4 = r0->field_b
    //     0x79f14c: ldur            w4, [x0, #0xb]
    // 0x79f150: DecompressPointer r4
    //     0x79f150: add             x4, x4, HEAP, lsl #32
    // 0x79f154: cmp             w4, NULL
    // 0x79f158: b.eq            #0x79f1e0
    // 0x79f15c: r0 = _IndicatorPainter()
    //     0x79f15c: bl              #0x79f398  ; Allocate_IndicatorPainterStub -> _IndicatorPainter (size=0x3c)
    // 0x79f160: stur            x0, [fp, #-0x30]
    // 0x79f164: ldur            x16, [fp, #-8]
    // 0x79f168: stp             x16, x0, [SP, #-0x10]!
    // 0x79f16c: ldur            x16, [fp, #-0x10]
    // 0x79f170: ldur            lr, [fp, #-0x28]
    // 0x79f174: stp             lr, x16, [SP, #-0x10]!
    // 0x79f178: ldur            x16, [fp, #-0x18]
    // 0x79f17c: ldur            lr, [fp, #-0x20]
    // 0x79f180: stp             lr, x16, [SP, #-0x10]!
    // 0x79f184: r0 = _IndicatorPainter()
    //     0x79f184: bl              #0x79f1e4  ; [package:extended_tabs/src/tab_bar.dart] _IndicatorPainter::_IndicatorPainter
    // 0x79f188: add             SP, SP, #0x30
    // 0x79f18c: ldur            x0, [fp, #-0x30]
    // 0x79f190: ldr             x1, [fp, #0x10]
    // 0x79f194: StoreField: r1->field_1b = r0
    //     0x79f194: stur            w0, [x1, #0x1b]
    //     0x79f198: ldurb           w16, [x1, #-1]
    //     0x79f19c: ldurb           w17, [x0, #-1]
    //     0x79f1a0: and             x16, x17, x16, lsr #2
    //     0x79f1a4: tst             x16, HEAP, lsr #32
    //     0x79f1a8: b.eq            #0x79f1b0
    //     0x79f1ac: bl              #0xd6826c
    // 0x79f1b0: r0 = Null
    //     0x79f1b0: mov             x0, NULL
    // 0x79f1b4: LeaveFrame
    //     0x79f1b4: mov             SP, fp
    //     0x79f1b8: ldp             fp, lr, [SP], #0x10
    // 0x79f1bc: ret
    //     0x79f1bc: ret             
    // 0x79f1c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79f1c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79f1c4: b               #0x79f088
    // 0x79f1c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79f1c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79f1cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79f1cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79f1d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79f1d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79f1d4: r9 = _tabKeys
    //     0x79f1d4: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4bf80] Field <_ExtendedTabBarState@468487081._tabKeys@468487081>: late (offset: 0x28)
    //     0x79f1d8: ldr             x9, [x9, #0xf80]
    // 0x79f1dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x79f1dc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x79f1e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79f1e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _controllerIsValid(/* No info */) {
    // ** addr: 0x79f3ec, size: 0x44
    // 0x79f3ec: ldr             x1, [SP]
    // 0x79f3f0: LoadField: r2 = r1->field_17
    //     0x79f3f0: ldur            w2, [x1, #0x17]
    // 0x79f3f4: DecompressPointer r2
    //     0x79f3f4: add             x2, x2, HEAP, lsl #32
    // 0x79f3f8: cmp             w2, NULL
    // 0x79f3fc: b.ne            #0x79f408
    // 0x79f400: r1 = Null
    //     0x79f400: mov             x1, NULL
    // 0x79f404: b               #0x79f41c
    // 0x79f408: LoadField: r1 = r2->field_23
    //     0x79f408: ldur            w1, [x2, #0x23]
    // 0x79f40c: DecompressPointer r1
    //     0x79f40c: add             x1, x1, HEAP, lsl #32
    // 0x79f410: cmp             w1, NULL
    // 0x79f414: b.ne            #0x79f41c
    // 0x79f418: r1 = Null
    //     0x79f418: mov             x1, NULL
    // 0x79f41c: cmp             w1, NULL
    // 0x79f420: r16 = true
    //     0x79f420: add             x16, NULL, #0x20  ; true
    // 0x79f424: r17 = false
    //     0x79f424: add             x17, NULL, #0x30  ; false
    // 0x79f428: csel            x0, x16, x17, ne
    // 0x79f42c: ret
    //     0x79f42c: ret             
  }
  _ _updateTabController(/* No info */) {
    // ** addr: 0x79f430, size: 0x26c
    // 0x79f430: EnterFrame
    //     0x79f430: stp             fp, lr, [SP, #-0x10]!
    //     0x79f434: mov             fp, SP
    // 0x79f438: AllocStack(0x10)
    //     0x79f438: sub             SP, SP, #0x10
    // 0x79f43c: CheckStackOverflow
    //     0x79f43c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79f440: cmp             SP, x16
    //     0x79f444: b.ls            #0x79f678
    // 0x79f448: ldr             x0, [fp, #0x10]
    // 0x79f44c: LoadField: r1 = r0->field_b
    //     0x79f44c: ldur            w1, [x0, #0xb]
    // 0x79f450: DecompressPointer r1
    //     0x79f450: add             x1, x1, HEAP, lsl #32
    // 0x79f454: cmp             w1, NULL
    // 0x79f458: b.eq            #0x79f680
    // 0x79f45c: LoadField: r2 = r1->field_13
    //     0x79f45c: ldur            w2, [x1, #0x13]
    // 0x79f460: DecompressPointer r2
    //     0x79f460: add             x2, x2, HEAP, lsl #32
    // 0x79f464: stur            x2, [fp, #-8]
    // 0x79f468: LoadField: r1 = r0->field_17
    //     0x79f468: ldur            w1, [x0, #0x17]
    // 0x79f46c: DecompressPointer r1
    //     0x79f46c: add             x1, x1, HEAP, lsl #32
    // 0x79f470: cmp             w2, w1
    // 0x79f474: b.ne            #0x79f488
    // 0x79f478: r0 = Null
    //     0x79f478: mov             x0, NULL
    // 0x79f47c: LeaveFrame
    //     0x79f47c: mov             SP, fp
    //     0x79f480: ldp             fp, lr, [SP], #0x10
    // 0x79f484: ret
    //     0x79f484: ret             
    // 0x79f488: SaveReg r0
    //     0x79f488: str             x0, [SP, #-8]!
    // 0x79f48c: r0 = _controllerIsValid()
    //     0x79f48c: bl              #0x79f3ec  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_controllerIsValid
    // 0x79f490: add             SP, SP, #8
    // 0x79f494: tbnz            w0, #4, #0x79f554
    // 0x79f498: ldr             x0, [fp, #0x10]
    // 0x79f49c: LoadField: r1 = r0->field_17
    //     0x79f49c: ldur            w1, [x0, #0x17]
    // 0x79f4a0: DecompressPointer r1
    //     0x79f4a0: add             x1, x1, HEAP, lsl #32
    // 0x79f4a4: cmp             w1, NULL
    // 0x79f4a8: b.eq            #0x79f684
    // 0x79f4ac: LoadField: r2 = r1->field_23
    //     0x79f4ac: ldur            w2, [x1, #0x23]
    // 0x79f4b0: DecompressPointer r2
    //     0x79f4b0: add             x2, x2, HEAP, lsl #32
    // 0x79f4b4: cmp             w2, NULL
    // 0x79f4b8: b.ne            #0x79f4c4
    // 0x79f4bc: r1 = Null
    //     0x79f4bc: mov             x1, NULL
    // 0x79f4c0: b               #0x79f4c8
    // 0x79f4c4: mov             x1, x2
    // 0x79f4c8: stur            x1, [fp, #-0x10]
    // 0x79f4cc: cmp             w1, NULL
    // 0x79f4d0: b.eq            #0x79f688
    // 0x79f4d4: r1 = 1
    //     0x79f4d4: mov             x1, #1
    // 0x79f4d8: r0 = AllocateContext()
    //     0x79f4d8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x79f4dc: mov             x1, x0
    // 0x79f4e0: ldr             x0, [fp, #0x10]
    // 0x79f4e4: StoreField: r1->field_f = r0
    //     0x79f4e4: stur            w0, [x1, #0xf]
    // 0x79f4e8: mov             x2, x1
    // 0x79f4ec: r1 = Function '_handleTabControllerAnimationTick@468487081':.
    //     0x79f4ec: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bfa0] AnonymousClosure: (0x79fc28), in [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_handleTabControllerAnimationTick (0x79fc70)
    //     0x79f4f0: ldr             x1, [x1, #0xfa0]
    // 0x79f4f4: r0 = AllocateClosure()
    //     0x79f4f4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x79f4f8: ldur            x16, [fp, #-0x10]
    // 0x79f4fc: stp             x0, x16, [SP, #-0x10]!
    // 0x79f500: r0 = removeListener()
    //     0x79f500: bl              #0x6f5e30  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::removeListener
    // 0x79f504: add             SP, SP, #0x10
    // 0x79f508: ldr             x0, [fp, #0x10]
    // 0x79f50c: LoadField: r1 = r0->field_17
    //     0x79f50c: ldur            w1, [x0, #0x17]
    // 0x79f510: DecompressPointer r1
    //     0x79f510: add             x1, x1, HEAP, lsl #32
    // 0x79f514: stur            x1, [fp, #-0x10]
    // 0x79f518: cmp             w1, NULL
    // 0x79f51c: b.eq            #0x79f68c
    // 0x79f520: r1 = 1
    //     0x79f520: mov             x1, #1
    // 0x79f524: r0 = AllocateContext()
    //     0x79f524: bl              #0xd68aa4  ; AllocateContextStub
    // 0x79f528: mov             x1, x0
    // 0x79f52c: ldr             x0, [fp, #0x10]
    // 0x79f530: StoreField: r1->field_f = r0
    //     0x79f530: stur            w0, [x1, #0xf]
    // 0x79f534: mov             x2, x1
    // 0x79f538: r1 = Function '_handleTabControllerTick@468487081':.
    //     0x79f538: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bfa8] AnonymousClosure: (0x79f6c4), in [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_handleTabControllerTick (0x79f70c)
    //     0x79f53c: ldr             x1, [x1, #0xfa8]
    // 0x79f540: r0 = AllocateClosure()
    //     0x79f540: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x79f544: ldur            x16, [fp, #-0x10]
    // 0x79f548: stp             x0, x16, [SP, #-0x10]!
    // 0x79f54c: r0 = removeListener()
    //     0x79f54c: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x79f550: add             SP, SP, #0x10
    // 0x79f554: ldr             x1, [fp, #0x10]
    // 0x79f558: ldur            x2, [fp, #-8]
    // 0x79f55c: mov             x0, x2
    // 0x79f560: StoreField: r1->field_17 = r0
    //     0x79f560: stur            w0, [x1, #0x17]
    //     0x79f564: ldurb           w16, [x1, #-1]
    //     0x79f568: ldurb           w17, [x0, #-1]
    //     0x79f56c: and             x16, x17, x16, lsr #2
    //     0x79f570: tst             x16, HEAP, lsr #32
    //     0x79f574: b.eq            #0x79f57c
    //     0x79f578: bl              #0xd6826c
    // 0x79f57c: LoadField: r0 = r2->field_23
    //     0x79f57c: ldur            w0, [x2, #0x23]
    // 0x79f580: DecompressPointer r0
    //     0x79f580: add             x0, x0, HEAP, lsl #32
    // 0x79f584: cmp             w0, NULL
    // 0x79f588: b.ne            #0x79f590
    // 0x79f58c: r0 = Null
    //     0x79f58c: mov             x0, NULL
    // 0x79f590: stur            x0, [fp, #-8]
    // 0x79f594: cmp             w0, NULL
    // 0x79f598: b.eq            #0x79f690
    // 0x79f59c: r1 = 1
    //     0x79f59c: mov             x1, #1
    // 0x79f5a0: r0 = AllocateContext()
    //     0x79f5a0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x79f5a4: mov             x1, x0
    // 0x79f5a8: ldr             x0, [fp, #0x10]
    // 0x79f5ac: StoreField: r1->field_f = r0
    //     0x79f5ac: stur            w0, [x1, #0xf]
    // 0x79f5b0: mov             x2, x1
    // 0x79f5b4: r1 = Function '_handleTabControllerAnimationTick@468487081':.
    //     0x79f5b4: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bfa0] AnonymousClosure: (0x79fc28), in [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_handleTabControllerAnimationTick (0x79fc70)
    //     0x79f5b8: ldr             x1, [x1, #0xfa0]
    // 0x79f5bc: r0 = AllocateClosure()
    //     0x79f5bc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x79f5c0: ldur            x16, [fp, #-8]
    // 0x79f5c4: stp             x0, x16, [SP, #-0x10]!
    // 0x79f5c8: r0 = addActionListener()
    //     0x79f5c8: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x79f5cc: add             SP, SP, #0x10
    // 0x79f5d0: ldr             x0, [fp, #0x10]
    // 0x79f5d4: LoadField: r1 = r0->field_17
    //     0x79f5d4: ldur            w1, [x0, #0x17]
    // 0x79f5d8: DecompressPointer r1
    //     0x79f5d8: add             x1, x1, HEAP, lsl #32
    // 0x79f5dc: stur            x1, [fp, #-8]
    // 0x79f5e0: cmp             w1, NULL
    // 0x79f5e4: b.eq            #0x79f694
    // 0x79f5e8: r1 = 1
    //     0x79f5e8: mov             x1, #1
    // 0x79f5ec: r0 = AllocateContext()
    //     0x79f5ec: bl              #0xd68aa4  ; AllocateContextStub
    // 0x79f5f0: mov             x1, x0
    // 0x79f5f4: ldr             x0, [fp, #0x10]
    // 0x79f5f8: StoreField: r1->field_f = r0
    //     0x79f5f8: stur            w0, [x1, #0xf]
    // 0x79f5fc: mov             x2, x1
    // 0x79f600: r1 = Function '_handleTabControllerTick@468487081':.
    //     0x79f600: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bfa8] AnonymousClosure: (0x79f6c4), in [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_handleTabControllerTick (0x79f70c)
    //     0x79f604: ldr             x1, [x1, #0xfa8]
    // 0x79f608: r0 = AllocateClosure()
    //     0x79f608: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x79f60c: ldur            x16, [fp, #-8]
    // 0x79f610: stp             x0, x16, [SP, #-0x10]!
    // 0x79f614: r0 = addListener()
    //     0x79f614: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x79f618: add             SP, SP, #0x10
    // 0x79f61c: ldr             x2, [fp, #0x10]
    // 0x79f620: LoadField: r3 = r2->field_17
    //     0x79f620: ldur            w3, [x2, #0x17]
    // 0x79f624: DecompressPointer r3
    //     0x79f624: add             x3, x3, HEAP, lsl #32
    // 0x79f628: cmp             w3, NULL
    // 0x79f62c: b.eq            #0x79f698
    // 0x79f630: LoadField: r4 = r3->field_33
    //     0x79f630: ldur            x4, [x3, #0x33]
    // 0x79f634: r0 = BoxInt64Instr(r4)
    //     0x79f634: sbfiz           x0, x4, #1, #0x1f
    //     0x79f638: cmp             x4, x0, asr #1
    //     0x79f63c: b.eq            #0x79f648
    //     0x79f640: bl              #0xd69bb8
    //     0x79f644: stur            x4, [x0, #7]
    // 0x79f648: StoreField: r2->field_1f = r0
    //     0x79f648: stur            w0, [x2, #0x1f]
    //     0x79f64c: tbz             w0, #0, #0x79f668
    //     0x79f650: ldurb           w16, [x2, #-1]
    //     0x79f654: ldurb           w17, [x0, #-1]
    //     0x79f658: and             x16, x17, x16, lsr #2
    //     0x79f65c: tst             x16, HEAP, lsr #32
    //     0x79f660: b.eq            #0x79f668
    //     0x79f664: bl              #0xd6828c
    // 0x79f668: r0 = Null
    //     0x79f668: mov             x0, NULL
    // 0x79f66c: LeaveFrame
    //     0x79f66c: mov             SP, fp
    //     0x79f670: ldp             fp, lr, [SP], #0x10
    // 0x79f674: ret
    //     0x79f674: ret             
    // 0x79f678: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79f678: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79f67c: b               #0x79f448
    // 0x79f680: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79f680: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79f684: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79f684: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79f688: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79f688: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79f68c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79f68c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79f690: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79f690: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79f694: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79f694: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79f698: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79f698: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleTabControllerTick(dynamic) {
    // ** addr: 0x79f6c4, size: 0x48
    // 0x79f6c4: EnterFrame
    //     0x79f6c4: stp             fp, lr, [SP, #-0x10]!
    //     0x79f6c8: mov             fp, SP
    // 0x79f6cc: ldr             x0, [fp, #0x10]
    // 0x79f6d0: LoadField: r1 = r0->field_17
    //     0x79f6d0: ldur            w1, [x0, #0x17]
    // 0x79f6d4: DecompressPointer r1
    //     0x79f6d4: add             x1, x1, HEAP, lsl #32
    // 0x79f6d8: CheckStackOverflow
    //     0x79f6d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79f6dc: cmp             SP, x16
    //     0x79f6e0: b.ls            #0x79f704
    // 0x79f6e4: LoadField: r0 = r1->field_f
    //     0x79f6e4: ldur            w0, [x1, #0xf]
    // 0x79f6e8: DecompressPointer r0
    //     0x79f6e8: add             x0, x0, HEAP, lsl #32
    // 0x79f6ec: SaveReg r0
    //     0x79f6ec: str             x0, [SP, #-8]!
    // 0x79f6f0: r0 = _handleTabControllerTick()
    //     0x79f6f0: bl              #0x79f70c  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_handleTabControllerTick
    // 0x79f6f4: add             SP, SP, #8
    // 0x79f6f8: LeaveFrame
    //     0x79f6f8: mov             SP, fp
    //     0x79f6fc: ldp             fp, lr, [SP], #0x10
    // 0x79f700: ret
    //     0x79f700: ret             
    // 0x79f704: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79f704: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79f708: b               #0x79f6e4
  }
  _ _handleTabControllerTick(/* No info */) {
    // ** addr: 0x79f70c, size: 0x104
    // 0x79f70c: EnterFrame
    //     0x79f70c: stp             fp, lr, [SP, #-0x10]!
    //     0x79f710: mov             fp, SP
    // 0x79f714: CheckStackOverflow
    //     0x79f714: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79f718: cmp             SP, x16
    //     0x79f71c: b.ls            #0x79f800
    // 0x79f720: ldr             x2, [fp, #0x10]
    // 0x79f724: LoadField: r0 = r2->field_17
    //     0x79f724: ldur            w0, [x2, #0x17]
    // 0x79f728: DecompressPointer r0
    //     0x79f728: add             x0, x0, HEAP, lsl #32
    // 0x79f72c: cmp             w0, NULL
    // 0x79f730: b.eq            #0x79f808
    // 0x79f734: LoadField: r3 = r0->field_33
    //     0x79f734: ldur            x3, [x0, #0x33]
    // 0x79f738: LoadField: r4 = r2->field_1f
    //     0x79f738: ldur            w4, [x2, #0x1f]
    // 0x79f73c: DecompressPointer r4
    //     0x79f73c: add             x4, x4, HEAP, lsl #32
    // 0x79f740: r0 = BoxInt64Instr(r3)
    //     0x79f740: sbfiz           x0, x3, #1, #0x1f
    //     0x79f744: cmp             x3, x0, asr #1
    //     0x79f748: b.eq            #0x79f754
    //     0x79f74c: bl              #0xd69bb8
    //     0x79f750: stur            x3, [x0, #7]
    // 0x79f754: cmp             w0, w4
    // 0x79f758: b.eq            #0x79f7d0
    // 0x79f75c: and             w16, w0, w4
    // 0x79f760: branchIfSmi(r16, 0x79f794)
    //     0x79f760: tbz             w16, #0, #0x79f794
    // 0x79f764: r16 = LoadClassIdInstr(r0)
    //     0x79f764: ldur            x16, [x0, #-1]
    //     0x79f768: ubfx            x16, x16, #0xc, #0x14
    // 0x79f76c: cmp             x16, #0x3c
    // 0x79f770: b.ne            #0x79f794
    // 0x79f774: r16 = LoadClassIdInstr(r4)
    //     0x79f774: ldur            x16, [x4, #-1]
    //     0x79f778: ubfx            x16, x16, #0xc, #0x14
    // 0x79f77c: cmp             x16, #0x3c
    // 0x79f780: b.ne            #0x79f794
    // 0x79f784: LoadField: r16 = r0->field_7
    //     0x79f784: ldur            x16, [x0, #7]
    // 0x79f788: LoadField: r17 = r4->field_7
    //     0x79f788: ldur            x17, [x4, #7]
    // 0x79f78c: cmp             x16, x17
    // 0x79f790: b.eq            #0x79f7d0
    // 0x79f794: StoreField: r2->field_1f = r0
    //     0x79f794: stur            w0, [x2, #0x1f]
    //     0x79f798: tbz             w0, #0, #0x79f7b4
    //     0x79f79c: ldurb           w16, [x2, #-1]
    //     0x79f7a0: ldurb           w17, [x0, #-1]
    //     0x79f7a4: and             x16, x17, x16, lsr #2
    //     0x79f7a8: tst             x16, HEAP, lsr #32
    //     0x79f7ac: b.eq            #0x79f7b4
    //     0x79f7b0: bl              #0xd6828c
    // 0x79f7b4: LoadField: r0 = r2->field_b
    //     0x79f7b4: ldur            w0, [x2, #0xb]
    // 0x79f7b8: DecompressPointer r0
    //     0x79f7b8: add             x0, x0, HEAP, lsl #32
    // 0x79f7bc: cmp             w0, NULL
    // 0x79f7c0: b.eq            #0x79f80c
    // 0x79f7c4: SaveReg r2
    //     0x79f7c4: str             x2, [SP, #-8]!
    // 0x79f7c8: r0 = _scrollToCurrentIndex()
    //     0x79f7c8: bl              #0x79f810  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_scrollToCurrentIndex
    // 0x79f7cc: add             SP, SP, #8
    // 0x79f7d0: r1 = Function '<anonymous closure>':.
    //     0x79f7d0: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bfb0] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x79f7d4: ldr             x1, [x1, #0xfb0]
    // 0x79f7d8: r2 = Null
    //     0x79f7d8: mov             x2, NULL
    // 0x79f7dc: r0 = AllocateClosure()
    //     0x79f7dc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x79f7e0: ldr             x16, [fp, #0x10]
    // 0x79f7e4: stp             x0, x16, [SP, #-0x10]!
    // 0x79f7e8: r0 = setState()
    //     0x79f7e8: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x79f7ec: add             SP, SP, #0x10
    // 0x79f7f0: r0 = Null
    //     0x79f7f0: mov             x0, NULL
    // 0x79f7f4: LeaveFrame
    //     0x79f7f4: mov             SP, fp
    //     0x79f7f8: ldp             fp, lr, [SP], #0x10
    // 0x79f7fc: ret
    //     0x79f7fc: ret             
    // 0x79f800: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79f800: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79f804: b               #0x79f720
    // 0x79f808: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79f808: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79f80c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79f80c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _scrollToCurrentIndex(/* No info */) {
    // ** addr: 0x79f810, size: 0x80
    // 0x79f810: EnterFrame
    //     0x79f810: stp             fp, lr, [SP, #-0x10]!
    //     0x79f814: mov             fp, SP
    // 0x79f818: CheckStackOverflow
    //     0x79f818: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79f81c: cmp             SP, x16
    //     0x79f820: b.ls            #0x79f884
    // 0x79f824: ldr             x0, [fp, #0x10]
    // 0x79f828: LoadField: r1 = r0->field_1f
    //     0x79f828: ldur            w1, [x0, #0x1f]
    // 0x79f82c: DecompressPointer r1
    //     0x79f82c: add             x1, x1, HEAP, lsl #32
    // 0x79f830: stp             x1, x0, [SP, #-0x10]!
    // 0x79f834: r0 = _tabCenteredScrollOffset()
    //     0x79f834: bl              #0x79f890  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_tabCenteredScrollOffset
    // 0x79f838: add             SP, SP, #0x10
    // 0x79f83c: ldr             x0, [fp, #0x10]
    // 0x79f840: LoadField: r1 = r0->field_13
    //     0x79f840: ldur            w1, [x0, #0x13]
    // 0x79f844: DecompressPointer r1
    //     0x79f844: add             x1, x1, HEAP, lsl #32
    // 0x79f848: cmp             w1, NULL
    // 0x79f84c: b.eq            #0x79f88c
    // 0x79f850: SaveReg r1
    //     0x79f850: str             x1, [SP, #-8]!
    // 0x79f854: SaveReg d0
    //     0x79f854: str             d0, [SP, #-8]!
    // 0x79f858: r16 = Instance_Cubic
    //     0x79f858: add             x16, PP, #0xa, lsl #12  ; [pp+0xafc8] Obj!Cubic<double>@b4f341
    //     0x79f85c: ldr             x16, [x16, #0xfc8]
    // 0x79f860: r30 = Instance_Duration
    //     0x79f860: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc88] Obj!Duration@b67ad1
    //     0x79f864: ldr             lr, [lr, #0xc88]
    // 0x79f868: stp             lr, x16, [SP, #-0x10]!
    // 0x79f86c: r0 = animateTo()
    //     0x79f86c: bl              #0x518ce0  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::animateTo
    // 0x79f870: add             SP, SP, #0x20
    // 0x79f874: r0 = Null
    //     0x79f874: mov             x0, NULL
    // 0x79f878: LeaveFrame
    //     0x79f878: mov             SP, fp
    //     0x79f87c: ldp             fp, lr, [SP], #0x10
    // 0x79f880: ret
    //     0x79f880: ret             
    // 0x79f884: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79f884: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79f888: b               #0x79f824
    // 0x79f88c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x79f88c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _tabCenteredScrollOffset(/* No info */) {
    // ** addr: 0x79f890, size: 0x108
    // 0x79f890: EnterFrame
    //     0x79f890: stp             fp, lr, [SP, #-0x10]!
    //     0x79f894: mov             fp, SP
    // 0x79f898: AllocStack(0x8)
    //     0x79f898: sub             SP, SP, #8
    // 0x79f89c: CheckStackOverflow
    //     0x79f89c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79f8a0: cmp             SP, x16
    //     0x79f8a4: b.ls            #0x79f96c
    // 0x79f8a8: ldr             x0, [fp, #0x18]
    // 0x79f8ac: LoadField: r1 = r0->field_13
    //     0x79f8ac: ldur            w1, [x0, #0x13]
    // 0x79f8b0: DecompressPointer r1
    //     0x79f8b0: add             x1, x1, HEAP, lsl #32
    // 0x79f8b4: cmp             w1, NULL
    // 0x79f8b8: b.eq            #0x79f974
    // 0x79f8bc: LoadField: r2 = r1->field_33
    //     0x79f8bc: ldur            w2, [x1, #0x33]
    // 0x79f8c0: DecompressPointer r2
    //     0x79f8c0: add             x2, x2, HEAP, lsl #32
    // 0x79f8c4: SaveReg r2
    //     0x79f8c4: str             x2, [SP, #-8]!
    // 0x79f8c8: r0 = single()
    //     0x79f8c8: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x79f8cc: add             SP, SP, #8
    // 0x79f8d0: mov             x1, x0
    // 0x79f8d4: stur            x1, [fp, #-8]
    // 0x79f8d8: r0 = LoadClassIdInstr(r1)
    //     0x79f8d8: ldur            x0, [x1, #-1]
    //     0x79f8dc: ubfx            x0, x0, #0xc, #0x14
    // 0x79f8e0: SaveReg r1
    //     0x79f8e0: str             x1, [SP, #-8]!
    // 0x79f8e4: r0 = GDT[cid_x0 + -0xfa2]()
    //     0x79f8e4: sub             lr, x0, #0xfa2
    //     0x79f8e8: ldr             lr, [x21, lr, lsl #3]
    //     0x79f8ec: blr             lr
    // 0x79f8f0: add             SP, SP, #8
    // 0x79f8f4: ldur            x0, [fp, #-8]
    // 0x79f8f8: LoadField: r1 = r0->field_33
    //     0x79f8f8: ldur            w1, [x0, #0x33]
    // 0x79f8fc: DecompressPointer r1
    //     0x79f8fc: add             x1, x1, HEAP, lsl #32
    // 0x79f900: cmp             w1, NULL
    // 0x79f904: b.eq            #0x79f978
    // 0x79f908: LoadField: r2 = r0->field_37
    //     0x79f908: ldur            w2, [x0, #0x37]
    // 0x79f90c: DecompressPointer r2
    //     0x79f90c: add             x2, x2, HEAP, lsl #32
    // 0x79f910: cmp             w2, NULL
    // 0x79f914: b.eq            #0x79f97c
    // 0x79f918: r0 = inline_Allocate_Double()
    //     0x79f918: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x79f91c: add             x0, x0, #0x10
    //     0x79f920: cmp             x3, x0
    //     0x79f924: b.ls            #0x79f980
    //     0x79f928: str             x0, [THR, #0x60]  ; THR::top
    //     0x79f92c: sub             x0, x0, #0xf
    //     0x79f930: mov             x3, #0xd108
    //     0x79f934: movk            x3, #3, lsl #16
    //     0x79f938: stur            x3, [x0, #-1]
    // 0x79f93c: StoreField: r0->field_7 = d0
    //     0x79f93c: stur            d0, [x0, #7]
    // 0x79f940: LoadField: d0 = r2->field_7
    //     0x79f940: ldur            d0, [x2, #7]
    // 0x79f944: ldr             x16, [fp, #0x18]
    // 0x79f948: ldr             lr, [fp, #0x10]
    // 0x79f94c: stp             lr, x16, [SP, #-0x10]!
    // 0x79f950: stp             x1, x0, [SP, #-0x10]!
    // 0x79f954: SaveReg d0
    //     0x79f954: str             d0, [SP, #-8]!
    // 0x79f958: r0 = _tabScrollOffset()
    //     0x79f958: bl              #0x79f998  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_tabScrollOffset
    // 0x79f95c: add             SP, SP, #0x28
    // 0x79f960: LeaveFrame
    //     0x79f960: mov             SP, fp
    //     0x79f964: ldp             fp, lr, [SP], #0x10
    // 0x79f968: ret
    //     0x79f968: ret             
    // 0x79f96c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79f96c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79f970: b               #0x79f8a8
    // 0x79f974: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79f974: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79f978: r0 = NullCastErrorSharedWithFPURegs()
    //     0x79f978: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x79f97c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x79f97c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x79f980: SaveReg d0
    //     0x79f980: str             q0, [SP, #-0x10]!
    // 0x79f984: stp             x1, x2, [SP, #-0x10]!
    // 0x79f988: r0 = AllocateDouble()
    //     0x79f988: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x79f98c: ldp             x1, x2, [SP], #0x10
    // 0x79f990: RestoreReg d0
    //     0x79f990: ldr             q0, [SP], #0x10
    // 0x79f994: b               #0x79f93c
  }
  _ _tabScrollOffset(/* No info */) {
    // ** addr: 0x79f998, size: 0x19c
    // 0x79f998: EnterFrame
    //     0x79f998: stp             fp, lr, [SP, #-0x10]!
    //     0x79f99c: mov             fp, SP
    // 0x79f9a0: AllocStack(0x8)
    //     0x79f9a0: sub             SP, SP, #8
    // 0x79f9a4: CheckStackOverflow
    //     0x79f9a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79f9a8: cmp             SP, x16
    //     0x79f9ac: b.ls            #0x79fae4
    // 0x79f9b0: ldr             x0, [fp, #0x30]
    // 0x79f9b4: LoadField: r1 = r0->field_b
    //     0x79f9b4: ldur            w1, [x0, #0xb]
    // 0x79f9b8: DecompressPointer r1
    //     0x79f9b8: add             x1, x1, HEAP, lsl #32
    // 0x79f9bc: cmp             w1, NULL
    // 0x79f9c0: b.eq            #0x79faec
    // 0x79f9c4: LoadField: r1 = r0->field_1b
    //     0x79f9c4: ldur            w1, [x0, #0x1b]
    // 0x79f9c8: DecompressPointer r1
    //     0x79f9c8: add             x1, x1, HEAP, lsl #32
    // 0x79f9cc: cmp             w1, NULL
    // 0x79f9d0: b.eq            #0x79faf0
    // 0x79f9d4: ldr             x2, [fp, #0x28]
    // 0x79f9d8: cmp             w2, NULL
    // 0x79f9dc: b.eq            #0x79faf4
    // 0x79f9e0: r3 = LoadInt32Instr(r2)
    //     0x79f9e0: sbfx            x3, x2, #1, #0x1f
    //     0x79f9e4: tbz             w2, #0, #0x79f9ec
    //     0x79f9e8: ldur            x3, [x2, #7]
    // 0x79f9ec: stp             x3, x1, [SP, #-0x10]!
    // 0x79f9f0: r0 = centerOf()
    //     0x79f9f0: bl              #0x79fb34  ; [package:extended_tabs/src/tab_bar.dart] _IndicatorPainter::centerOf
    // 0x79f9f4: add             SP, SP, #0x10
    // 0x79f9f8: ldr             x0, [fp, #0x30]
    // 0x79f9fc: stur            d0, [fp, #-8]
    // 0x79fa00: LoadField: r1 = r0->field_f
    //     0x79fa00: ldur            w1, [x0, #0xf]
    // 0x79fa04: DecompressPointer r1
    //     0x79fa04: add             x1, x1, HEAP, lsl #32
    // 0x79fa08: cmp             w1, NULL
    // 0x79fa0c: b.eq            #0x79faf8
    // 0x79fa10: SaveReg r1
    //     0x79fa10: str             x1, [SP, #-8]!
    // 0x79fa14: r0 = of()
    //     0x79fa14: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x79fa18: add             SP, SP, #8
    // 0x79fa1c: LoadField: r1 = r0->field_7
    //     0x79fa1c: ldur            x1, [x0, #7]
    // 0x79fa20: cmp             x1, #0
    // 0x79fa24: b.gt            #0x79fa50
    // 0x79fa28: ldr             x0, [fp, #0x30]
    // 0x79fa2c: ldur            d0, [fp, #-8]
    // 0x79fa30: LoadField: r1 = r0->field_23
    //     0x79fa30: ldur            w1, [x0, #0x23]
    // 0x79fa34: DecompressPointer r1
    //     0x79fa34: add             x1, x1, HEAP, lsl #32
    // 0x79fa38: r16 = Sentinel
    //     0x79fa38: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x79fa3c: cmp             w1, w16
    // 0x79fa40: b.eq            #0x79fafc
    // 0x79fa44: LoadField: d1 = r1->field_7
    //     0x79fa44: ldur            d1, [x1, #7]
    // 0x79fa48: fsub            d2, d1, d0
    // 0x79fa4c: b               #0x79fa58
    // 0x79fa50: ldur            d0, [fp, #-8]
    // 0x79fa54: mov             v2.16b, v0.16b
    // 0x79fa58: ldr             x0, [fp, #0x20]
    // 0x79fa5c: ldr             d1, [fp, #0x10]
    // 0x79fa60: d0 = 2.000000
    //     0x79fa60: fmov            d0, #2.00000000
    // 0x79fa64: LoadField: d3 = r0->field_7
    //     0x79fa64: ldur            d3, [x0, #7]
    // 0x79fa68: fdiv            d4, d3, d0
    // 0x79fa6c: fsub            d0, d2, d4
    // 0x79fa70: r0 = inline_Allocate_Double()
    //     0x79fa70: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x79fa74: add             x0, x0, #0x10
    //     0x79fa78: cmp             x1, x0
    //     0x79fa7c: b.ls            #0x79fb08
    //     0x79fa80: str             x0, [THR, #0x60]  ; THR::top
    //     0x79fa84: sub             x0, x0, #0xf
    //     0x79fa88: mov             x1, #0xd108
    //     0x79fa8c: movk            x1, #3, lsl #16
    //     0x79fa90: stur            x1, [x0, #-1]
    // 0x79fa94: StoreField: r0->field_7 = d1
    //     0x79fa94: stur            d1, [x0, #7]
    // 0x79fa98: r1 = inline_Allocate_Double()
    //     0x79fa98: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x79fa9c: add             x1, x1, #0x10
    //     0x79faa0: cmp             x2, x1
    //     0x79faa4: b.ls            #0x79fb18
    //     0x79faa8: str             x1, [THR, #0x60]  ; THR::top
    //     0x79faac: sub             x1, x1, #0xf
    //     0x79fab0: mov             x2, #0xd108
    //     0x79fab4: movk            x2, #3, lsl #16
    //     0x79fab8: stur            x2, [x1, #-1]
    // 0x79fabc: StoreField: r1->field_7 = d0
    //     0x79fabc: stur            d0, [x1, #7]
    // 0x79fac0: ldr             x16, [fp, #0x18]
    // 0x79fac4: stp             x16, x1, [SP, #-0x10]!
    // 0x79fac8: SaveReg r0
    //     0x79fac8: str             x0, [SP, #-8]!
    // 0x79facc: r0 = clamp()
    //     0x79facc: bl              #0xd66c00  ; [dart:core] _Double::clamp
    // 0x79fad0: add             SP, SP, #0x18
    // 0x79fad4: LoadField: d0 = r0->field_7
    //     0x79fad4: ldur            d0, [x0, #7]
    // 0x79fad8: LeaveFrame
    //     0x79fad8: mov             SP, fp
    //     0x79fadc: ldp             fp, lr, [SP], #0x10
    // 0x79fae0: ret
    //     0x79fae0: ret             
    // 0x79fae4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79fae4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79fae8: b               #0x79f9b0
    // 0x79faec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79faec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79faf0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79faf0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79faf4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79faf4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79faf8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x79faf8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x79fafc: r9 = _tabStripWidth
    //     0x79fafc: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4bfb8] Field <_ExtendedTabBarState@468487081._tabStripWidth@468487081>: late (offset: 0x24)
    //     0x79fb00: ldr             x9, [x9, #0xfb8]
    // 0x79fb04: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x79fb04: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x79fb08: stp             q0, q1, [SP, #-0x20]!
    // 0x79fb0c: r0 = AllocateDouble()
    //     0x79fb0c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x79fb10: ldp             q0, q1, [SP], #0x20
    // 0x79fb14: b               #0x79fa94
    // 0x79fb18: SaveReg d0
    //     0x79fb18: str             q0, [SP, #-0x10]!
    // 0x79fb1c: SaveReg r0
    //     0x79fb1c: str             x0, [SP, #-8]!
    // 0x79fb20: r0 = AllocateDouble()
    //     0x79fb20: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x79fb24: mov             x1, x0
    // 0x79fb28: RestoreReg r0
    //     0x79fb28: ldr             x0, [SP], #8
    // 0x79fb2c: RestoreReg d0
    //     0x79fb2c: ldr             q0, [SP], #0x10
    // 0x79fb30: b               #0x79fabc
  }
  [closure] void _handleTabControllerAnimationTick(dynamic) {
    // ** addr: 0x79fc28, size: 0x48
    // 0x79fc28: EnterFrame
    //     0x79fc28: stp             fp, lr, [SP, #-0x10]!
    //     0x79fc2c: mov             fp, SP
    // 0x79fc30: ldr             x0, [fp, #0x10]
    // 0x79fc34: LoadField: r1 = r0->field_17
    //     0x79fc34: ldur            w1, [x0, #0x17]
    // 0x79fc38: DecompressPointer r1
    //     0x79fc38: add             x1, x1, HEAP, lsl #32
    // 0x79fc3c: CheckStackOverflow
    //     0x79fc3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79fc40: cmp             SP, x16
    //     0x79fc44: b.ls            #0x79fc68
    // 0x79fc48: LoadField: r0 = r1->field_f
    //     0x79fc48: ldur            w0, [x1, #0xf]
    // 0x79fc4c: DecompressPointer r0
    //     0x79fc4c: add             x0, x0, HEAP, lsl #32
    // 0x79fc50: SaveReg r0
    //     0x79fc50: str             x0, [SP, #-8]!
    // 0x79fc54: r0 = _handleTabControllerAnimationTick()
    //     0x79fc54: bl              #0x79fc70  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_handleTabControllerAnimationTick
    // 0x79fc58: add             SP, SP, #8
    // 0x79fc5c: LeaveFrame
    //     0x79fc5c: mov             SP, fp
    //     0x79fc60: ldp             fp, lr, [SP], #0x10
    // 0x79fc64: ret
    //     0x79fc64: ret             
    // 0x79fc68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79fc68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79fc6c: b               #0x79fc48
  }
  _ _handleTabControllerAnimationTick(/* No info */) {
    // ** addr: 0x79fc70, size: 0xa4
    // 0x79fc70: EnterFrame
    //     0x79fc70: stp             fp, lr, [SP, #-0x10]!
    //     0x79fc74: mov             fp, SP
    // 0x79fc78: CheckStackOverflow
    //     0x79fc78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79fc7c: cmp             SP, x16
    //     0x79fc80: b.ls            #0x79fd04
    // 0x79fc84: ldr             x2, [fp, #0x10]
    // 0x79fc88: LoadField: r0 = r2->field_17
    //     0x79fc88: ldur            w0, [x2, #0x17]
    // 0x79fc8c: DecompressPointer r0
    //     0x79fc8c: add             x0, x0, HEAP, lsl #32
    // 0x79fc90: cmp             w0, NULL
    // 0x79fc94: b.eq            #0x79fd0c
    // 0x79fc98: LoadField: r1 = r0->field_43
    //     0x79fc98: ldur            x1, [x0, #0x43]
    // 0x79fc9c: cbnz            x1, #0x79fcf4
    // 0x79fca0: LoadField: r1 = r2->field_b
    //     0x79fca0: ldur            w1, [x2, #0xb]
    // 0x79fca4: DecompressPointer r1
    //     0x79fca4: add             x1, x1, HEAP, lsl #32
    // 0x79fca8: cmp             w1, NULL
    // 0x79fcac: b.eq            #0x79fd10
    // 0x79fcb0: LoadField: r3 = r0->field_33
    //     0x79fcb0: ldur            x3, [x0, #0x33]
    // 0x79fcb4: r0 = BoxInt64Instr(r3)
    //     0x79fcb4: sbfiz           x0, x3, #1, #0x1f
    //     0x79fcb8: cmp             x3, x0, asr #1
    //     0x79fcbc: b.eq            #0x79fcc8
    //     0x79fcc0: bl              #0xd69bb8
    //     0x79fcc4: stur            x3, [x0, #7]
    // 0x79fcc8: StoreField: r2->field_1f = r0
    //     0x79fcc8: stur            w0, [x2, #0x1f]
    //     0x79fccc: tbz             w0, #0, #0x79fce8
    //     0x79fcd0: ldurb           w16, [x2, #-1]
    //     0x79fcd4: ldurb           w17, [x0, #-1]
    //     0x79fcd8: and             x16, x17, x16, lsr #2
    //     0x79fcdc: tst             x16, HEAP, lsr #32
    //     0x79fce0: b.eq            #0x79fce8
    //     0x79fce4: bl              #0xd6828c
    // 0x79fce8: SaveReg r2
    //     0x79fce8: str             x2, [SP, #-8]!
    // 0x79fcec: r0 = _scrollToControllerValue()
    //     0x79fcec: bl              #0x79fd14  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_scrollToControllerValue
    // 0x79fcf0: add             SP, SP, #8
    // 0x79fcf4: r0 = Null
    //     0x79fcf4: mov             x0, NULL
    // 0x79fcf8: LeaveFrame
    //     0x79fcf8: mov             SP, fp
    //     0x79fcfc: ldp             fp, lr, [SP], #0x10
    // 0x79fd00: ret
    //     0x79fd00: ret             
    // 0x79fd04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79fd04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79fd08: b               #0x79fc84
    // 0x79fd0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79fd0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79fd10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79fd10: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _scrollToControllerValue(/* No info */) {
    // ** addr: 0x79fd14, size: 0x5d0
    // 0x79fd14: EnterFrame
    //     0x79fd14: stp             fp, lr, [SP, #-0x10]!
    //     0x79fd18: mov             fp, SP
    // 0x79fd1c: AllocStack(0x18)
    //     0x79fd1c: sub             SP, SP, #0x18
    // 0x79fd20: CheckStackOverflow
    //     0x79fd20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79fd24: cmp             SP, x16
    //     0x79fd28: b.ls            #0x7a019c
    // 0x79fd2c: ldr             x2, [fp, #0x10]
    // 0x79fd30: LoadField: r0 = r2->field_1f
    //     0x79fd30: ldur            w0, [x2, #0x1f]
    // 0x79fd34: DecompressPointer r0
    //     0x79fd34: add             x0, x0, HEAP, lsl #32
    // 0x79fd38: cmp             w0, NULL
    // 0x79fd3c: b.eq            #0x7a01a4
    // 0x79fd40: r1 = LoadInt32Instr(r0)
    //     0x79fd40: sbfx            x1, x0, #1, #0x1f
    //     0x79fd44: tbz             w0, #0, #0x79fd4c
    //     0x79fd48: ldur            x1, [x0, #7]
    // 0x79fd4c: cmp             x1, #0
    // 0x79fd50: b.le            #0x79fda8
    // 0x79fd54: sub             x3, x1, #1
    // 0x79fd58: r0 = BoxInt64Instr(r3)
    //     0x79fd58: sbfiz           x0, x3, #1, #0x1f
    //     0x79fd5c: cmp             x3, x0, asr #1
    //     0x79fd60: b.eq            #0x79fd6c
    //     0x79fd64: bl              #0xd69bb8
    //     0x79fd68: stur            x3, [x0, #7]
    // 0x79fd6c: stp             x0, x2, [SP, #-0x10]!
    // 0x79fd70: r0 = _tabCenteredScrollOffset()
    //     0x79fd70: bl              #0x79f890  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_tabCenteredScrollOffset
    // 0x79fd74: add             SP, SP, #0x10
    // 0x79fd78: r0 = inline_Allocate_Double()
    //     0x79fd78: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x79fd7c: add             x0, x0, #0x10
    //     0x79fd80: cmp             x1, x0
    //     0x79fd84: b.ls            #0x7a01a8
    //     0x79fd88: str             x0, [THR, #0x60]  ; THR::top
    //     0x79fd8c: sub             x0, x0, #0xf
    //     0x79fd90: mov             x1, #0xd108
    //     0x79fd94: movk            x1, #3, lsl #16
    //     0x79fd98: stur            x1, [x0, #-1]
    // 0x79fd9c: StoreField: r0->field_7 = d0
    //     0x79fd9c: stur            d0, [x0, #7]
    // 0x79fda0: mov             x1, x0
    // 0x79fda4: b               #0x79fdac
    // 0x79fda8: r1 = Null
    //     0x79fda8: mov             x1, NULL
    // 0x79fdac: ldr             x0, [fp, #0x10]
    // 0x79fdb0: stur            x1, [fp, #-8]
    // 0x79fdb4: LoadField: r2 = r0->field_1f
    //     0x79fdb4: ldur            w2, [x0, #0x1f]
    // 0x79fdb8: DecompressPointer r2
    //     0x79fdb8: add             x2, x2, HEAP, lsl #32
    // 0x79fdbc: stp             x2, x0, [SP, #-0x10]!
    // 0x79fdc0: r0 = _tabCenteredScrollOffset()
    //     0x79fdc0: bl              #0x79f890  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_tabCenteredScrollOffset
    // 0x79fdc4: add             SP, SP, #0x10
    // 0x79fdc8: ldr             x0, [fp, #0x10]
    // 0x79fdcc: stur            d0, [fp, #-0x18]
    // 0x79fdd0: LoadField: r1 = r0->field_1f
    //     0x79fdd0: ldur            w1, [x0, #0x1f]
    // 0x79fdd4: DecompressPointer r1
    //     0x79fdd4: add             x1, x1, HEAP, lsl #32
    // 0x79fdd8: stur            x1, [fp, #-0x10]
    // 0x79fddc: cmp             w1, NULL
    // 0x79fde0: b.eq            #0x7a01b8
    // 0x79fde4: SaveReg r0
    //     0x79fde4: str             x0, [SP, #-8]!
    // 0x79fde8: r0 = maxTabIndex()
    //     0x79fde8: bl              #0x7a02e4  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::maxTabIndex
    // 0x79fdec: add             SP, SP, #8
    // 0x79fdf0: mov             x1, x0
    // 0x79fdf4: ldur            x0, [fp, #-0x10]
    // 0x79fdf8: r2 = LoadInt32Instr(r0)
    //     0x79fdf8: sbfx            x2, x0, #1, #0x1f
    //     0x79fdfc: tbz             w0, #0, #0x79fe04
    //     0x79fe00: ldur            x2, [x0, #7]
    // 0x79fe04: cmp             x2, x1
    // 0x79fe08: b.ge            #0x79fe80
    // 0x79fe0c: ldr             x2, [fp, #0x10]
    // 0x79fe10: LoadField: r0 = r2->field_1f
    //     0x79fe10: ldur            w0, [x2, #0x1f]
    // 0x79fe14: DecompressPointer r0
    //     0x79fe14: add             x0, x0, HEAP, lsl #32
    // 0x79fe18: cmp             w0, NULL
    // 0x79fe1c: b.eq            #0x7a01bc
    // 0x79fe20: r1 = LoadInt32Instr(r0)
    //     0x79fe20: sbfx            x1, x0, #1, #0x1f
    //     0x79fe24: tbz             w0, #0, #0x79fe2c
    //     0x79fe28: ldur            x1, [x0, #7]
    // 0x79fe2c: add             x3, x1, #1
    // 0x79fe30: r0 = BoxInt64Instr(r3)
    //     0x79fe30: sbfiz           x0, x3, #1, #0x1f
    //     0x79fe34: cmp             x3, x0, asr #1
    //     0x79fe38: b.eq            #0x79fe44
    //     0x79fe3c: bl              #0xd69bb8
    //     0x79fe40: stur            x3, [x0, #7]
    // 0x79fe44: stp             x0, x2, [SP, #-0x10]!
    // 0x79fe48: r0 = _tabCenteredScrollOffset()
    //     0x79fe48: bl              #0x79f890  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_tabCenteredScrollOffset
    // 0x79fe4c: add             SP, SP, #0x10
    // 0x79fe50: r0 = inline_Allocate_Double()
    //     0x79fe50: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x79fe54: add             x0, x0, #0x10
    //     0x79fe58: cmp             x1, x0
    //     0x79fe5c: b.ls            #0x7a01c0
    //     0x79fe60: str             x0, [THR, #0x60]  ; THR::top
    //     0x79fe64: sub             x0, x0, #0xf
    //     0x79fe68: mov             x1, #0xd108
    //     0x79fe6c: movk            x1, #3, lsl #16
    //     0x79fe70: stur            x1, [x0, #-1]
    // 0x79fe74: StoreField: r0->field_7 = d0
    //     0x79fe74: stur            d0, [x0, #7]
    // 0x79fe78: mov             x3, x0
    // 0x79fe7c: b               #0x79fe84
    // 0x79fe80: r3 = Null
    //     0x79fe80: mov             x3, NULL
    // 0x79fe84: ldr             x2, [fp, #0x10]
    // 0x79fe88: stur            x3, [fp, #-0x10]
    // 0x79fe8c: LoadField: r0 = r2->field_17
    //     0x79fe8c: ldur            w0, [x2, #0x17]
    // 0x79fe90: DecompressPointer r0
    //     0x79fe90: add             x0, x0, HEAP, lsl #32
    // 0x79fe94: cmp             w0, NULL
    // 0x79fe98: b.eq            #0x7a01d0
    // 0x79fe9c: LoadField: r4 = r0->field_33
    //     0x79fe9c: ldur            x4, [x0, #0x33]
    // 0x79fea0: r0 = BoxInt64Instr(r4)
    //     0x79fea0: sbfiz           x0, x4, #1, #0x1f
    //     0x79fea4: cmp             x4, x0, asr #1
    //     0x79fea8: b.eq            #0x79feb4
    //     0x79feac: bl              #0xd69bb8
    //     0x79feb0: stur            x4, [x0, #7]
    // 0x79feb4: stp             x0, NULL, [SP, #-0x10]!
    // 0x79feb8: r0 = _Double.fromInteger()
    //     0x79feb8: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x79febc: add             SP, SP, #0x10
    // 0x79fec0: mov             x1, x0
    // 0x79fec4: ldr             x0, [fp, #0x10]
    // 0x79fec8: LoadField: r2 = r0->field_17
    //     0x79fec8: ldur            w2, [x0, #0x17]
    // 0x79fecc: DecompressPointer r2
    //     0x79fecc: add             x2, x2, HEAP, lsl #32
    // 0x79fed0: cmp             w2, NULL
    // 0x79fed4: b.eq            #0x7a01d4
    // 0x79fed8: LoadField: r3 = r2->field_23
    //     0x79fed8: ldur            w3, [x2, #0x23]
    // 0x79fedc: DecompressPointer r3
    //     0x79fedc: add             x3, x3, HEAP, lsl #32
    // 0x79fee0: cmp             w3, NULL
    // 0x79fee4: b.ne            #0x79fef0
    // 0x79fee8: r2 = Null
    //     0x79fee8: mov             x2, NULL
    // 0x79feec: b               #0x79fef4
    // 0x79fef0: mov             x2, x3
    // 0x79fef4: d0 = 1.000000
    //     0x79fef4: fmov            d0, #1.00000000
    // 0x79fef8: cmp             w2, NULL
    // 0x79fefc: b.eq            #0x7a01d8
    // 0x79ff00: LoadField: r3 = r2->field_37
    //     0x79ff00: ldur            w3, [x2, #0x37]
    // 0x79ff04: DecompressPointer r3
    //     0x79ff04: add             x3, x3, HEAP, lsl #32
    // 0x79ff08: r16 = Sentinel
    //     0x79ff08: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x79ff0c: cmp             w3, w16
    // 0x79ff10: b.eq            #0x7a01dc
    // 0x79ff14: LoadField: d1 = r1->field_7
    //     0x79ff14: ldur            d1, [x1, #7]
    // 0x79ff18: fsub            d2, d1, d0
    // 0x79ff1c: LoadField: d3 = r3->field_7
    //     0x79ff1c: ldur            d3, [x3, #7]
    // 0x79ff20: fcmp            d3, d2
    // 0x79ff24: b.vs            #0x79ff70
    // 0x79ff28: b.ne            #0x79ff70
    // 0x79ff2c: ldur            x1, [fp, #-8]
    // 0x79ff30: cmp             w1, NULL
    // 0x79ff34: b.ne            #0x79ff40
    // 0x79ff38: ldur            d0, [fp, #-0x18]
    // 0x79ff3c: b               #0x79ff44
    // 0x79ff40: LoadField: d0 = r1->field_7
    //     0x79ff40: ldur            d0, [x1, #7]
    // 0x79ff44: r1 = inline_Allocate_Double()
    //     0x79ff44: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x79ff48: add             x1, x1, #0x10
    //     0x79ff4c: cmp             x2, x1
    //     0x79ff50: b.ls            #0x7a01e8
    //     0x79ff54: str             x1, [THR, #0x60]  ; THR::top
    //     0x79ff58: sub             x1, x1, #0xf
    //     0x79ff5c: mov             x2, #0xd108
    //     0x79ff60: movk            x2, #3, lsl #16
    //     0x79ff64: stur            x2, [x1, #-1]
    // 0x79ff68: StoreField: r1->field_7 = d0
    //     0x79ff68: stur            d0, [x1, #7]
    // 0x79ff6c: b               #0x7a0160
    // 0x79ff70: ldur            x1, [fp, #-8]
    // 0x79ff74: fadd            d2, d1, d0
    // 0x79ff78: fcmp            d3, d2
    // 0x79ff7c: b.vs            #0x79ffcc
    // 0x79ff80: b.ne            #0x79ffcc
    // 0x79ff84: ldur            x2, [fp, #-0x10]
    // 0x79ff88: cmp             w2, NULL
    // 0x79ff8c: b.ne            #0x79ff98
    // 0x79ff90: ldur            d0, [fp, #-0x18]
    // 0x79ff94: b               #0x79ff9c
    // 0x79ff98: LoadField: d0 = r2->field_7
    //     0x79ff98: ldur            d0, [x2, #7]
    // 0x79ff9c: r1 = inline_Allocate_Double()
    //     0x79ff9c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x79ffa0: add             x1, x1, #0x10
    //     0x79ffa4: cmp             x2, x1
    //     0x79ffa8: b.ls            #0x7a0204
    //     0x79ffac: str             x1, [THR, #0x60]  ; THR::top
    //     0x79ffb0: sub             x1, x1, #0xf
    //     0x79ffb4: mov             x2, #0xd108
    //     0x79ffb8: movk            x2, #3, lsl #16
    //     0x79ffbc: stur            x2, [x1, #-1]
    // 0x79ffc0: StoreField: r1->field_7 = d0
    //     0x79ffc0: stur            d0, [x1, #7]
    // 0x79ffc4: mov             x0, x1
    // 0x79ffc8: b               #0x7a0158
    // 0x79ffcc: ldur            x2, [fp, #-0x10]
    // 0x79ffd0: fcmp            d3, d1
    // 0x79ffd4: b.vs            #0x7a0010
    // 0x79ffd8: b.ne            #0x7a0010
    // 0x79ffdc: ldur            d0, [fp, #-0x18]
    // 0x79ffe0: r1 = inline_Allocate_Double()
    //     0x79ffe0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x79ffe4: add             x1, x1, #0x10
    //     0x79ffe8: cmp             x2, x1
    //     0x79ffec: b.ls            #0x7a0220
    //     0x79fff0: str             x1, [THR, #0x60]  ; THR::top
    //     0x79fff4: sub             x1, x1, #0xf
    //     0x79fff8: mov             x2, #0xd108
    //     0x79fffc: movk            x2, #3, lsl #16
    //     0x7a0000: stur            x2, [x1, #-1]
    // 0x7a0004: StoreField: r1->field_7 = d0
    //     0x7a0004: stur            d0, [x1, #7]
    // 0x7a0008: mov             x0, x1
    // 0x7a000c: b               #0x7a0158
    // 0x7a0010: ldur            d0, [fp, #-0x18]
    // 0x7a0014: fcmp            d3, d1
    // 0x7a0018: b.vs            #0x7a00c0
    // 0x7a001c: b.ge            #0x7a00c0
    // 0x7a0020: cmp             w1, NULL
    // 0x7a0024: b.ne            #0x7a0058
    // 0x7a0028: r1 = inline_Allocate_Double()
    //     0x7a0028: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x7a002c: add             x1, x1, #0x10
    //     0x7a0030: cmp             x2, x1
    //     0x7a0034: b.ls            #0x7a023c
    //     0x7a0038: str             x1, [THR, #0x60]  ; THR::top
    //     0x7a003c: sub             x1, x1, #0xf
    //     0x7a0040: mov             x2, #0xd108
    //     0x7a0044: movk            x2, #3, lsl #16
    //     0x7a0048: stur            x2, [x1, #-1]
    // 0x7a004c: StoreField: r1->field_7 = d0
    //     0x7a004c: stur            d0, [x1, #7]
    // 0x7a0050: mov             x0, x1
    // 0x7a0054: b               #0x7a0158
    // 0x7a0058: fsub            d2, d1, d3
    // 0x7a005c: r2 = inline_Allocate_Double()
    //     0x7a005c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x7a0060: add             x2, x2, #0x10
    //     0x7a0064: cmp             x3, x2
    //     0x7a0068: b.ls            #0x7a0258
    //     0x7a006c: str             x2, [THR, #0x60]  ; THR::top
    //     0x7a0070: sub             x2, x2, #0xf
    //     0x7a0074: mov             x3, #0xd108
    //     0x7a0078: movk            x3, #3, lsl #16
    //     0x7a007c: stur            x3, [x2, #-1]
    // 0x7a0080: StoreField: r2->field_7 = d0
    //     0x7a0080: stur            d0, [x2, #7]
    // 0x7a0084: r3 = inline_Allocate_Double()
    //     0x7a0084: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x7a0088: add             x3, x3, #0x10
    //     0x7a008c: cmp             x4, x3
    //     0x7a0090: b.ls            #0x7a0274
    //     0x7a0094: str             x3, [THR, #0x60]  ; THR::top
    //     0x7a0098: sub             x3, x3, #0xf
    //     0x7a009c: mov             x4, #0xd108
    //     0x7a00a0: movk            x4, #3, lsl #16
    //     0x7a00a4: stur            x4, [x3, #-1]
    // 0x7a00a8: StoreField: r3->field_7 = d2
    //     0x7a00a8: stur            d2, [x3, #7]
    // 0x7a00ac: stp             x1, x2, [SP, #-0x10]!
    // 0x7a00b0: SaveReg r3
    //     0x7a00b0: str             x3, [SP, #-8]!
    // 0x7a00b4: r0 = lerpDouble()
    //     0x7a00b4: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0x7a00b8: add             SP, SP, #0x18
    // 0x7a00bc: b               #0x7a0158
    // 0x7a00c0: cmp             w2, NULL
    // 0x7a00c4: b.ne            #0x7a00f4
    // 0x7a00c8: r0 = inline_Allocate_Double()
    //     0x7a00c8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x7a00cc: add             x0, x0, #0x10
    //     0x7a00d0: cmp             x1, x0
    //     0x7a00d4: b.ls            #0x7a0298
    //     0x7a00d8: str             x0, [THR, #0x60]  ; THR::top
    //     0x7a00dc: sub             x0, x0, #0xf
    //     0x7a00e0: mov             x1, #0xd108
    //     0x7a00e4: movk            x1, #3, lsl #16
    //     0x7a00e8: stur            x1, [x0, #-1]
    // 0x7a00ec: StoreField: r0->field_7 = d0
    //     0x7a00ec: stur            d0, [x0, #7]
    // 0x7a00f0: b               #0x7a0158
    // 0x7a00f4: fsub            d2, d3, d1
    // 0x7a00f8: r0 = inline_Allocate_Double()
    //     0x7a00f8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x7a00fc: add             x0, x0, #0x10
    //     0x7a0100: cmp             x1, x0
    //     0x7a0104: b.ls            #0x7a02a8
    //     0x7a0108: str             x0, [THR, #0x60]  ; THR::top
    //     0x7a010c: sub             x0, x0, #0xf
    //     0x7a0110: mov             x1, #0xd108
    //     0x7a0114: movk            x1, #3, lsl #16
    //     0x7a0118: stur            x1, [x0, #-1]
    // 0x7a011c: StoreField: r0->field_7 = d0
    //     0x7a011c: stur            d0, [x0, #7]
    // 0x7a0120: r1 = inline_Allocate_Double()
    //     0x7a0120: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x7a0124: add             x1, x1, #0x10
    //     0x7a0128: cmp             x3, x1
    //     0x7a012c: b.ls            #0x7a02c0
    //     0x7a0130: str             x1, [THR, #0x60]  ; THR::top
    //     0x7a0134: sub             x1, x1, #0xf
    //     0x7a0138: mov             x3, #0xd108
    //     0x7a013c: movk            x3, #3, lsl #16
    //     0x7a0140: stur            x3, [x1, #-1]
    // 0x7a0144: StoreField: r1->field_7 = d2
    //     0x7a0144: stur            d2, [x1, #7]
    // 0x7a0148: stp             x2, x0, [SP, #-0x10]!
    // 0x7a014c: SaveReg r1
    //     0x7a014c: str             x1, [SP, #-8]!
    // 0x7a0150: r0 = lerpDouble()
    //     0x7a0150: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0x7a0154: add             SP, SP, #0x18
    // 0x7a0158: mov             x1, x0
    // 0x7a015c: ldr             x0, [fp, #0x10]
    // 0x7a0160: LoadField: r2 = r0->field_13
    //     0x7a0160: ldur            w2, [x0, #0x13]
    // 0x7a0164: DecompressPointer r2
    //     0x7a0164: add             x2, x2, HEAP, lsl #32
    // 0x7a0168: cmp             w2, NULL
    // 0x7a016c: b.eq            #0x7a02dc
    // 0x7a0170: cmp             w1, NULL
    // 0x7a0174: b.eq            #0x7a02e0
    // 0x7a0178: LoadField: d0 = r1->field_7
    //     0x7a0178: ldur            d0, [x1, #7]
    // 0x7a017c: SaveReg r2
    //     0x7a017c: str             x2, [SP, #-8]!
    // 0x7a0180: SaveReg d0
    //     0x7a0180: str             d0, [SP, #-8]!
    // 0x7a0184: r0 = jumpTo()
    //     0x7a0184: bl              #0x59dbf4  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::jumpTo
    // 0x7a0188: add             SP, SP, #0x10
    // 0x7a018c: r0 = Null
    //     0x7a018c: mov             x0, NULL
    // 0x7a0190: LeaveFrame
    //     0x7a0190: mov             SP, fp
    //     0x7a0194: ldp             fp, lr, [SP], #0x10
    // 0x7a0198: ret
    //     0x7a0198: ret             
    // 0x7a019c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a019c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a01a0: b               #0x79fd2c
    // 0x7a01a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a01a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7a01a8: SaveReg d0
    //     0x7a01a8: str             q0, [SP, #-0x10]!
    // 0x7a01ac: r0 = AllocateDouble()
    //     0x7a01ac: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7a01b0: RestoreReg d0
    //     0x7a01b0: ldr             q0, [SP], #0x10
    // 0x7a01b4: b               #0x79fd9c
    // 0x7a01b8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x7a01b8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x7a01bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a01bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7a01c0: SaveReg d0
    //     0x7a01c0: str             q0, [SP, #-0x10]!
    // 0x7a01c4: r0 = AllocateDouble()
    //     0x7a01c4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7a01c8: RestoreReg d0
    //     0x7a01c8: ldr             q0, [SP], #0x10
    // 0x7a01cc: b               #0x79fe74
    // 0x7a01d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a01d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7a01d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a01d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7a01d8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x7a01d8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x7a01dc: r9 = _value
    //     0x7a01dc: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x7a01e0: ldr             x9, [x9, #0xbb0]
    // 0x7a01e4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x7a01e4: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x7a01e8: SaveReg d0
    //     0x7a01e8: str             q0, [SP, #-0x10]!
    // 0x7a01ec: SaveReg r0
    //     0x7a01ec: str             x0, [SP, #-8]!
    // 0x7a01f0: r0 = AllocateDouble()
    //     0x7a01f0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7a01f4: mov             x1, x0
    // 0x7a01f8: RestoreReg r0
    //     0x7a01f8: ldr             x0, [SP], #8
    // 0x7a01fc: RestoreReg d0
    //     0x7a01fc: ldr             q0, [SP], #0x10
    // 0x7a0200: b               #0x79ff68
    // 0x7a0204: SaveReg d0
    //     0x7a0204: str             q0, [SP, #-0x10]!
    // 0x7a0208: SaveReg r0
    //     0x7a0208: str             x0, [SP, #-8]!
    // 0x7a020c: r0 = AllocateDouble()
    //     0x7a020c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7a0210: mov             x1, x0
    // 0x7a0214: RestoreReg r0
    //     0x7a0214: ldr             x0, [SP], #8
    // 0x7a0218: RestoreReg d0
    //     0x7a0218: ldr             q0, [SP], #0x10
    // 0x7a021c: b               #0x79ffc0
    // 0x7a0220: SaveReg d0
    //     0x7a0220: str             q0, [SP, #-0x10]!
    // 0x7a0224: SaveReg r0
    //     0x7a0224: str             x0, [SP, #-8]!
    // 0x7a0228: r0 = AllocateDouble()
    //     0x7a0228: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7a022c: mov             x1, x0
    // 0x7a0230: RestoreReg r0
    //     0x7a0230: ldr             x0, [SP], #8
    // 0x7a0234: RestoreReg d0
    //     0x7a0234: ldr             q0, [SP], #0x10
    // 0x7a0238: b               #0x7a0004
    // 0x7a023c: SaveReg d0
    //     0x7a023c: str             q0, [SP, #-0x10]!
    // 0x7a0240: SaveReg r0
    //     0x7a0240: str             x0, [SP, #-8]!
    // 0x7a0244: r0 = AllocateDouble()
    //     0x7a0244: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7a0248: mov             x1, x0
    // 0x7a024c: RestoreReg r0
    //     0x7a024c: ldr             x0, [SP], #8
    // 0x7a0250: RestoreReg d0
    //     0x7a0250: ldr             q0, [SP], #0x10
    // 0x7a0254: b               #0x7a004c
    // 0x7a0258: stp             q0, q2, [SP, #-0x20]!
    // 0x7a025c: stp             x0, x1, [SP, #-0x10]!
    // 0x7a0260: r0 = AllocateDouble()
    //     0x7a0260: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7a0264: mov             x2, x0
    // 0x7a0268: ldp             x0, x1, [SP], #0x10
    // 0x7a026c: ldp             q0, q2, [SP], #0x20
    // 0x7a0270: b               #0x7a0080
    // 0x7a0274: SaveReg d2
    //     0x7a0274: str             q2, [SP, #-0x10]!
    // 0x7a0278: stp             x1, x2, [SP, #-0x10]!
    // 0x7a027c: SaveReg r0
    //     0x7a027c: str             x0, [SP, #-8]!
    // 0x7a0280: r0 = AllocateDouble()
    //     0x7a0280: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7a0284: mov             x3, x0
    // 0x7a0288: RestoreReg r0
    //     0x7a0288: ldr             x0, [SP], #8
    // 0x7a028c: ldp             x1, x2, [SP], #0x10
    // 0x7a0290: RestoreReg d2
    //     0x7a0290: ldr             q2, [SP], #0x10
    // 0x7a0294: b               #0x7a00a8
    // 0x7a0298: SaveReg d0
    //     0x7a0298: str             q0, [SP, #-0x10]!
    // 0x7a029c: r0 = AllocateDouble()
    //     0x7a029c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7a02a0: RestoreReg d0
    //     0x7a02a0: ldr             q0, [SP], #0x10
    // 0x7a02a4: b               #0x7a00ec
    // 0x7a02a8: stp             q0, q2, [SP, #-0x20]!
    // 0x7a02ac: SaveReg r2
    //     0x7a02ac: str             x2, [SP, #-8]!
    // 0x7a02b0: r0 = AllocateDouble()
    //     0x7a02b0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7a02b4: RestoreReg r2
    //     0x7a02b4: ldr             x2, [SP], #8
    // 0x7a02b8: ldp             q0, q2, [SP], #0x20
    // 0x7a02bc: b               #0x7a011c
    // 0x7a02c0: SaveReg d2
    //     0x7a02c0: str             q2, [SP, #-0x10]!
    // 0x7a02c4: stp             x0, x2, [SP, #-0x10]!
    // 0x7a02c8: r0 = AllocateDouble()
    //     0x7a02c8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7a02cc: mov             x1, x0
    // 0x7a02d0: ldp             x0, x2, [SP], #0x10
    // 0x7a02d4: RestoreReg d2
    //     0x7a02d4: ldr             q2, [SP], #0x10
    // 0x7a02d8: b               #0x7a0144
    // 0x7a02dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a02dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7a02e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a02e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ maxTabIndex(/* No info */) {
    // ** addr: 0x7a02e4, size: 0x4c
    // 0x7a02e4: EnterFrame
    //     0x7a02e4: stp             fp, lr, [SP, #-0x10]!
    //     0x7a02e8: mov             fp, SP
    // 0x7a02ec: CheckStackOverflow
    //     0x7a02ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a02f0: cmp             SP, x16
    //     0x7a02f4: b.ls            #0x7a0324
    // 0x7a02f8: ldr             x0, [fp, #0x10]
    // 0x7a02fc: LoadField: r1 = r0->field_1b
    //     0x7a02fc: ldur            w1, [x0, #0x1b]
    // 0x7a0300: DecompressPointer r1
    //     0x7a0300: add             x1, x1, HEAP, lsl #32
    // 0x7a0304: cmp             w1, NULL
    // 0x7a0308: b.eq            #0x7a032c
    // 0x7a030c: SaveReg r1
    //     0x7a030c: str             x1, [SP, #-8]!
    // 0x7a0310: r0 = maxTabIndex()
    //     0x7a0310: bl              #0x7a0330  ; [package:extended_tabs/src/tab_bar.dart] _IndicatorPainter::maxTabIndex
    // 0x7a0314: add             SP, SP, #8
    // 0x7a0318: LeaveFrame
    //     0x7a0318: mov             SP, fp
    //     0x7a031c: ldp             fp, lr, [SP], #0x10
    // 0x7a0320: ret
    //     0x7a0320: ret             
    // 0x7a0324: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a0324: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a0328: b               #0x7a02f8
    // 0x7a032c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a032c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x831f1c, size: 0xf00
    // 0x831f1c: EnterFrame
    //     0x831f1c: stp             fp, lr, [SP, #-0x10]!
    //     0x831f20: mov             fp, SP
    // 0x831f24: AllocStack(0x58)
    //     0x831f24: sub             SP, SP, #0x58
    // 0x831f28: CheckStackOverflow
    //     0x831f28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x831f2c: cmp             SP, x16
    //     0x831f30: b.ls            #0x832d88
    // 0x831f34: r1 = 2
    //     0x831f34: mov             x1, #2
    // 0x831f38: r0 = AllocateContext()
    //     0x831f38: bl              #0xd68aa4  ; AllocateContextStub
    // 0x831f3c: mov             x1, x0
    // 0x831f40: ldr             x0, [fp, #0x18]
    // 0x831f44: stur            x1, [fp, #-8]
    // 0x831f48: StoreField: r1->field_f = r0
    //     0x831f48: stur            w0, [x1, #0xf]
    // 0x831f4c: ldr             x16, [fp, #0x10]
    // 0x831f50: SaveReg r16
    //     0x831f50: str             x16, [SP, #-8]!
    // 0x831f54: r0 = of()
    //     0x831f54: bl              #0x832f90  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0x831f58: add             SP, SP, #8
    // 0x831f5c: ldr             x0, [fp, #0x18]
    // 0x831f60: LoadField: r1 = r0->field_17
    //     0x831f60: ldur            w1, [x0, #0x17]
    // 0x831f64: DecompressPointer r1
    //     0x831f64: add             x1, x1, HEAP, lsl #32
    // 0x831f68: cmp             w1, NULL
    // 0x831f6c: b.eq            #0x832d90
    // 0x831f70: LoadField: r2 = r1->field_2b
    //     0x831f70: ldur            x2, [x1, #0x2b]
    // 0x831f74: lsl             x1, x2, #1
    // 0x831f78: cbnz            w1, #0x831fc0
    // 0x831f7c: LoadField: r1 = r0->field_b
    //     0x831f7c: ldur            w1, [x0, #0xb]
    // 0x831f80: DecompressPointer r1
    //     0x831f80: add             x1, x1, HEAP, lsl #32
    // 0x831f84: cmp             w1, NULL
    // 0x831f88: b.eq            #0x832d94
    // 0x831f8c: r0 = Container()
    //     0x831f8c: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x831f90: stur            x0, [fp, #-0x10]
    // 0x831f94: r16 = 48.000000
    //     0x831f94: add             x16, PP, #0x26, lsl #12  ; [pp+0x268e8] 48
    //     0x831f98: ldr             x16, [x16, #0x8e8]
    // 0x831f9c: stp             x16, x0, [SP, #-0x10]!
    // 0x831fa0: r4 = const [0, 0x2, 0x2, 0x1, height, 0x1, null]
    //     0x831fa0: add             x4, PP, #0x21, lsl #12  ; [pp+0x21620] List(7) [0, 0x2, 0x2, 0x1, "height", 0x1, Null]
    //     0x831fa4: ldr             x4, [x4, #0x620]
    // 0x831fa8: r0 = Container()
    //     0x831fa8: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x831fac: add             SP, SP, #0x10
    // 0x831fb0: ldur            x0, [fp, #-0x10]
    // 0x831fb4: LeaveFrame
    //     0x831fb4: mov             SP, fp
    //     0x831fb8: ldp             fp, lr, [SP], #0x10
    // 0x831fbc: ret
    //     0x831fbc: ret             
    // 0x831fc0: ldur            x2, [fp, #-8]
    // 0x831fc4: ldr             x16, [fp, #0x10]
    // 0x831fc8: SaveReg r16
    //     0x831fc8: str             x16, [SP, #-8]!
    // 0x831fcc: r0 = of()
    //     0x831fcc: bl              #0x79f3a4  ; [package:flutter/src/material/tab_bar_theme.dart] TabBarTheme::of
    // 0x831fd0: add             SP, SP, #8
    // 0x831fd4: ldur            x2, [fp, #-8]
    // 0x831fd8: StoreField: r2->field_13 = r0
    //     0x831fd8: stur            w0, [x2, #0x13]
    //     0x831fdc: ldurb           w16, [x2, #-1]
    //     0x831fe0: ldurb           w17, [x0, #-1]
    //     0x831fe4: and             x16, x17, x16, lsr #2
    //     0x831fe8: tst             x16, HEAP, lsr #32
    //     0x831fec: b.eq            #0x831ff4
    //     0x831ff0: bl              #0xd6828c
    // 0x831ff4: ldr             x1, [fp, #0x18]
    // 0x831ff8: LoadField: r0 = r1->field_b
    //     0x831ff8: ldur            w0, [x1, #0xb]
    // 0x831ffc: DecompressPointer r0
    //     0x831ffc: add             x0, x0, HEAP, lsl #32
    // 0x832000: cmp             w0, NULL
    // 0x832004: b.eq            #0x832d98
    // 0x832008: LoadField: r3 = r0->field_f
    //     0x832008: ldur            w3, [x0, #0xf]
    // 0x83200c: DecompressPointer r3
    //     0x83200c: add             x3, x3, HEAP, lsl #32
    // 0x832010: r0 = LoadClassIdInstr(r3)
    //     0x832010: ldur            x0, [x3, #-1]
    //     0x832014: ubfx            x0, x0, #0xc, #0x14
    // 0x832018: SaveReg r3
    //     0x832018: str             x3, [SP, #-8]!
    // 0x83201c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x83201c: mov             x17, #0xb8ea
    //     0x832020: add             lr, x0, x17
    //     0x832024: ldr             lr, [x21, lr, lsl #3]
    //     0x832028: blr             lr
    // 0x83202c: add             SP, SP, #8
    // 0x832030: ldur            x2, [fp, #-8]
    // 0x832034: r1 = Function '<anonymous closure>':.
    //     0x832034: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bf30] AnonymousClosure: (0x833198), in [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::build (0x831f1c)
    //     0x832038: ldr             x1, [x1, #0xf30]
    // 0x83203c: stur            x0, [fp, #-0x10]
    // 0x832040: r0 = AllocateClosure()
    //     0x832040: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x832044: mov             x1, x0
    // 0x832048: ldur            x0, [fp, #-0x10]
    // 0x83204c: stur            x1, [fp, #-0x18]
    // 0x832050: r2 = LoadInt32Instr(r0)
    //     0x832050: sbfx            x2, x0, #1, #0x1f
    // 0x832054: r16 = <Widget>
    //     0x832054: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x832058: ldr             x16, [x16, #0xea8]
    // 0x83205c: stp             x2, x16, [SP, #-0x10]!
    // 0x832060: r0 = _GrowableList()
    //     0x832060: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x832064: add             SP, SP, #0x10
    // 0x832068: mov             x2, x0
    // 0x83206c: stur            x2, [fp, #-0x10]
    // 0x832070: r3 = 0
    //     0x832070: mov             x3, #0
    // 0x832074: stur            x3, [fp, #-0x20]
    // 0x832078: CheckStackOverflow
    //     0x832078: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83207c: cmp             SP, x16
    //     0x832080: b.ls            #0x832d9c
    // 0x832084: LoadField: r0 = r2->field_b
    //     0x832084: ldur            w0, [x2, #0xb]
    // 0x832088: DecompressPointer r0
    //     0x832088: add             x0, x0, HEAP, lsl #32
    // 0x83208c: r4 = LoadInt32Instr(r0)
    //     0x83208c: sbfx            x4, x0, #1, #0x1f
    // 0x832090: stur            x4, [fp, #-0x30]
    // 0x832094: cmp             x3, x4
    // 0x832098: b.ge            #0x832170
    // 0x83209c: r0 = BoxInt64Instr(r3)
    //     0x83209c: sbfiz           x0, x3, #1, #0x1f
    //     0x8320a0: cmp             x3, x0, asr #1
    //     0x8320a4: b.eq            #0x8320b0
    //     0x8320a8: bl              #0xd69bb8
    //     0x8320ac: stur            x3, [x0, #7]
    // 0x8320b0: ldur            x16, [fp, #-0x18]
    // 0x8320b4: stp             x0, x16, [SP, #-0x10]!
    // 0x8320b8: ldur            x0, [fp, #-0x18]
    // 0x8320bc: ClosureCall
    //     0x8320bc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8320c0: ldur            x2, [x0, #0x1f]
    //     0x8320c4: blr             x2
    // 0x8320c8: add             SP, SP, #0x10
    // 0x8320cc: mov             x3, x0
    // 0x8320d0: r2 = Null
    //     0x8320d0: mov             x2, NULL
    // 0x8320d4: r1 = Null
    //     0x8320d4: mov             x1, NULL
    // 0x8320d8: stur            x3, [fp, #-0x28]
    // 0x8320dc: r4 = 59
    //     0x8320dc: mov             x4, #0x3b
    // 0x8320e0: branchIfSmi(r0, 0x8320ec)
    //     0x8320e0: tbz             w0, #0, #0x8320ec
    // 0x8320e4: r4 = LoadClassIdInstr(r0)
    //     0x8320e4: ldur            x4, [x0, #-1]
    //     0x8320e8: ubfx            x4, x4, #0xc, #0x14
    // 0x8320ec: sub             x4, x4, #0xd99
    // 0x8320f0: cmp             x4, #0x2ea
    // 0x8320f4: b.ls            #0x83210c
    // 0x8320f8: r8 = Widget
    //     0x8320f8: add             x8, PP, #0x30, lsl #12  ; [pp+0x304e0] Type: Widget
    //     0x8320fc: ldr             x8, [x8, #0x4e0]
    // 0x832100: r3 = Null
    //     0x832100: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4bf38] Null
    //     0x832104: ldr             x3, [x3, #0xf38]
    // 0x832108: r0 = Widget()
    //     0x832108: bl              #0x507a18  ; IsType_Widget_Stub
    // 0x83210c: ldur            x2, [fp, #-0x10]
    // 0x832110: LoadField: r0 = r2->field_b
    //     0x832110: ldur            w0, [x2, #0xb]
    // 0x832114: DecompressPointer r0
    //     0x832114: add             x0, x0, HEAP, lsl #32
    // 0x832118: r1 = LoadInt32Instr(r0)
    //     0x832118: sbfx            x1, x0, #1, #0x1f
    // 0x83211c: mov             x0, x1
    // 0x832120: ldur            x1, [fp, #-0x20]
    // 0x832124: cmp             x1, x0
    // 0x832128: b.hs            #0x832da4
    // 0x83212c: LoadField: r1 = r2->field_f
    //     0x83212c: ldur            w1, [x2, #0xf]
    // 0x832130: DecompressPointer r1
    //     0x832130: add             x1, x1, HEAP, lsl #32
    // 0x832134: ldur            x0, [fp, #-0x28]
    // 0x832138: ldur            x3, [fp, #-0x20]
    // 0x83213c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x83213c: add             x25, x1, x3, lsl #2
    //     0x832140: add             x25, x25, #0xf
    //     0x832144: str             w0, [x25]
    //     0x832148: tbz             w0, #0, #0x832164
    //     0x83214c: ldurb           w16, [x1, #-1]
    //     0x832150: ldurb           w17, [x0, #-1]
    //     0x832154: and             x16, x17, x16, lsr #2
    //     0x832158: tst             x16, HEAP, lsr #32
    //     0x83215c: b.eq            #0x832164
    //     0x832160: bl              #0xd67e5c
    // 0x832164: add             x0, x3, #1
    // 0x832168: mov             x3, x0
    // 0x83216c: b               #0x832074
    // 0x832170: ldr             x0, [fp, #0x18]
    // 0x832174: LoadField: r3 = r0->field_17
    //     0x832174: ldur            w3, [x0, #0x17]
    // 0x832178: DecompressPointer r3
    //     0x832178: add             x3, x3, HEAP, lsl #32
    // 0x83217c: stur            x3, [fp, #-0x18]
    // 0x832180: cmp             w3, NULL
    // 0x832184: b.eq            #0x8327c0
    // 0x832188: LoadField: r5 = r3->field_3b
    //     0x832188: ldur            x5, [x3, #0x3b]
    // 0x83218c: stur            x5, [fp, #-0x20]
    // 0x832190: LoadField: r1 = r3->field_43
    //     0x832190: ldur            x1, [x3, #0x43]
    // 0x832194: cbz             x1, #0x83230c
    // 0x832198: r1 = <double>
    //     0x832198: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x83219c: r0 = _ChangeAnimation()
    //     0x83219c: bl              #0x832f84  ; Allocate_ChangeAnimationStub -> _ChangeAnimation (size=0x10)
    // 0x8321a0: mov             x2, x0
    // 0x8321a4: ldur            x0, [fp, #-0x18]
    // 0x8321a8: stur            x2, [fp, #-0x28]
    // 0x8321ac: StoreField: r2->field_b = r0
    //     0x8321ac: stur            w0, [x2, #0xb]
    // 0x8321b0: ldr             x3, [fp, #0x18]
    // 0x8321b4: LoadField: r0 = r3->field_1f
    //     0x8321b4: ldur            w0, [x3, #0x1f]
    // 0x8321b8: DecompressPointer r0
    //     0x8321b8: add             x0, x0, HEAP, lsl #32
    // 0x8321bc: cmp             w0, NULL
    // 0x8321c0: b.eq            #0x832da8
    // 0x8321c4: r4 = LoadInt32Instr(r0)
    //     0x8321c4: sbfx            x4, x0, #1, #0x1f
    //     0x8321c8: tbz             w0, #0, #0x8321d0
    //     0x8321cc: ldur            x4, [x0, #7]
    // 0x8321d0: ldur            x0, [fp, #-0x30]
    // 0x8321d4: mov             x1, x4
    // 0x8321d8: stur            x4, [fp, #-0x38]
    // 0x8321dc: cmp             x1, x0
    // 0x8321e0: b.hs            #0x832dac
    // 0x8321e4: ldur            x0, [fp, #-0x10]
    // 0x8321e8: LoadField: r1 = r0->field_f
    //     0x8321e8: ldur            w1, [x0, #0xf]
    // 0x8321ec: DecompressPointer r1
    //     0x8321ec: add             x1, x1, HEAP, lsl #32
    // 0x8321f0: ArrayLoad: r5 = r1[r4]  ; Unknown_4
    //     0x8321f0: add             x16, x1, x4, lsl #2
    //     0x8321f4: ldur            w5, [x16, #0xf]
    // 0x8321f8: DecompressPointer r5
    //     0x8321f8: add             x5, x5, HEAP, lsl #32
    // 0x8321fc: stp             x5, x3, [SP, #-0x10]!
    // 0x832200: r16 = true
    //     0x832200: add             x16, NULL, #0x20  ; true
    // 0x832204: stp             x2, x16, [SP, #-0x10]!
    // 0x832208: r0 = _buildStyledTab()
    //     0x832208: bl              #0x832ef0  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_buildStyledTab
    // 0x83220c: add             SP, SP, #0x20
    // 0x832210: mov             x3, x0
    // 0x832214: ldur            x2, [fp, #-0x10]
    // 0x832218: LoadField: r0 = r2->field_b
    //     0x832218: ldur            w0, [x2, #0xb]
    // 0x83221c: DecompressPointer r0
    //     0x83221c: add             x0, x0, HEAP, lsl #32
    // 0x832220: r4 = LoadInt32Instr(r0)
    //     0x832220: sbfx            x4, x0, #1, #0x1f
    // 0x832224: mov             x0, x4
    // 0x832228: ldur            x1, [fp, #-0x38]
    // 0x83222c: cmp             x1, x0
    // 0x832230: b.hs            #0x832db0
    // 0x832234: LoadField: r5 = r2->field_f
    //     0x832234: ldur            w5, [x2, #0xf]
    // 0x832238: DecompressPointer r5
    //     0x832238: add             x5, x5, HEAP, lsl #32
    // 0x83223c: mov             x1, x5
    // 0x832240: mov             x0, x3
    // 0x832244: ldur            x3, [fp, #-0x38]
    // 0x832248: ArrayStore: r1[r3] = r0  ; List_4
    //     0x832248: add             x25, x1, x3, lsl #2
    //     0x83224c: add             x25, x25, #0xf
    //     0x832250: str             w0, [x25]
    //     0x832254: tbz             w0, #0, #0x832270
    //     0x832258: ldurb           w16, [x1, #-1]
    //     0x83225c: ldurb           w17, [x0, #-1]
    //     0x832260: and             x16, x17, x16, lsr #2
    //     0x832264: tst             x16, HEAP, lsr #32
    //     0x832268: b.eq            #0x832270
    //     0x83226c: bl              #0xd67e5c
    // 0x832270: mov             x0, x4
    // 0x832274: ldur            x1, [fp, #-0x20]
    // 0x832278: cmp             x1, x0
    // 0x83227c: b.hs            #0x832db4
    // 0x832280: ldur            x1, [fp, #-0x20]
    // 0x832284: ArrayLoad: r0 = r5[r1]  ; Unknown_4
    //     0x832284: add             x16, x5, x1, lsl #2
    //     0x832288: ldur            w0, [x16, #0xf]
    // 0x83228c: DecompressPointer r0
    //     0x83228c: add             x0, x0, HEAP, lsl #32
    // 0x832290: ldr             x16, [fp, #0x18]
    // 0x832294: stp             x0, x16, [SP, #-0x10]!
    // 0x832298: r16 = false
    //     0x832298: add             x16, NULL, #0x30  ; false
    // 0x83229c: ldur            lr, [fp, #-0x28]
    // 0x8322a0: stp             lr, x16, [SP, #-0x10]!
    // 0x8322a4: r0 = _buildStyledTab()
    //     0x8322a4: bl              #0x832ef0  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_buildStyledTab
    // 0x8322a8: add             SP, SP, #0x20
    // 0x8322ac: mov             x3, x0
    // 0x8322b0: ldur            x2, [fp, #-0x10]
    // 0x8322b4: LoadField: r0 = r2->field_b
    //     0x8322b4: ldur            w0, [x2, #0xb]
    // 0x8322b8: DecompressPointer r0
    //     0x8322b8: add             x0, x0, HEAP, lsl #32
    // 0x8322bc: r1 = LoadInt32Instr(r0)
    //     0x8322bc: sbfx            x1, x0, #1, #0x1f
    // 0x8322c0: mov             x0, x1
    // 0x8322c4: ldur            x1, [fp, #-0x20]
    // 0x8322c8: cmp             x1, x0
    // 0x8322cc: b.hs            #0x832db8
    // 0x8322d0: LoadField: r1 = r2->field_f
    //     0x8322d0: ldur            w1, [x2, #0xf]
    // 0x8322d4: DecompressPointer r1
    //     0x8322d4: add             x1, x1, HEAP, lsl #32
    // 0x8322d8: mov             x0, x3
    // 0x8322dc: ldur            x3, [fp, #-0x20]
    // 0x8322e0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8322e0: add             x25, x1, x3, lsl #2
    //     0x8322e4: add             x25, x25, #0xf
    //     0x8322e8: str             w0, [x25]
    //     0x8322ec: tbz             w0, #0, #0x832308
    //     0x8322f0: ldurb           w16, [x1, #-1]
    //     0x8322f4: ldurb           w17, [x0, #-1]
    //     0x8322f8: and             x16, x17, x16, lsr #2
    //     0x8322fc: tst             x16, HEAP, lsr #32
    //     0x832300: b.eq            #0x832308
    //     0x832304: bl              #0xd67e5c
    // 0x832308: b               #0x8327c0
    // 0x83230c: mov             x16, x3
    // 0x832310: mov             x3, x0
    // 0x832314: mov             x0, x16
    // 0x832318: LoadField: r4 = r3->field_1f
    //     0x832318: ldur            w4, [x3, #0x1f]
    // 0x83231c: DecompressPointer r4
    //     0x83231c: add             x4, x4, HEAP, lsl #32
    // 0x832320: stur            x4, [fp, #-0x28]
    // 0x832324: cmp             w4, NULL
    // 0x832328: b.eq            #0x832dbc
    // 0x83232c: r1 = <double>
    //     0x83232c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x832330: r0 = _DragAnimation()
    //     0x832330: bl              #0x832ee4  ; Allocate_DragAnimationStub -> _DragAnimation (size=0x18)
    // 0x832334: mov             x2, x0
    // 0x832338: ldur            x0, [fp, #-0x18]
    // 0x83233c: StoreField: r2->field_b = r0
    //     0x83233c: stur            w0, [x2, #0xb]
    // 0x832340: ldur            x0, [fp, #-0x28]
    // 0x832344: r3 = LoadInt32Instr(r0)
    //     0x832344: sbfx            x3, x0, #1, #0x1f
    //     0x832348: tbz             w0, #0, #0x832350
    //     0x83234c: ldur            x3, [x0, #7]
    // 0x832350: stur            x3, [fp, #-0x20]
    // 0x832354: StoreField: r2->field_f = r3
    //     0x832354: stur            x3, [x2, #0xf]
    // 0x832358: ldur            x0, [fp, #-0x30]
    // 0x83235c: mov             x1, x3
    // 0x832360: cmp             x1, x0
    // 0x832364: b.hs            #0x832dc0
    // 0x832368: ldur            x0, [fp, #-0x10]
    // 0x83236c: LoadField: r1 = r0->field_f
    //     0x83236c: ldur            w1, [x0, #0xf]
    // 0x832370: DecompressPointer r1
    //     0x832370: add             x1, x1, HEAP, lsl #32
    // 0x832374: ArrayLoad: r4 = r1[r3]  ; Unknown_4
    //     0x832374: add             x16, x1, x3, lsl #2
    //     0x832378: ldur            w4, [x16, #0xf]
    // 0x83237c: DecompressPointer r4
    //     0x83237c: add             x4, x4, HEAP, lsl #32
    // 0x832380: ldr             x16, [fp, #0x18]
    // 0x832384: stp             x4, x16, [SP, #-0x10]!
    // 0x832388: r16 = true
    //     0x832388: add             x16, NULL, #0x20  ; true
    // 0x83238c: stp             x2, x16, [SP, #-0x10]!
    // 0x832390: r0 = _buildStyledTab()
    //     0x832390: bl              #0x832ef0  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_buildStyledTab
    // 0x832394: add             SP, SP, #0x20
    // 0x832398: mov             x3, x0
    // 0x83239c: ldur            x2, [fp, #-0x10]
    // 0x8323a0: LoadField: r0 = r2->field_b
    //     0x8323a0: ldur            w0, [x2, #0xb]
    // 0x8323a4: DecompressPointer r0
    //     0x8323a4: add             x0, x0, HEAP, lsl #32
    // 0x8323a8: r1 = LoadInt32Instr(r0)
    //     0x8323a8: sbfx            x1, x0, #1, #0x1f
    // 0x8323ac: mov             x0, x1
    // 0x8323b0: ldur            x1, [fp, #-0x20]
    // 0x8323b4: cmp             x1, x0
    // 0x8323b8: b.hs            #0x832dc4
    // 0x8323bc: LoadField: r1 = r2->field_f
    //     0x8323bc: ldur            w1, [x2, #0xf]
    // 0x8323c0: DecompressPointer r1
    //     0x8323c0: add             x1, x1, HEAP, lsl #32
    // 0x8323c4: mov             x0, x3
    // 0x8323c8: ldur            x3, [fp, #-0x20]
    // 0x8323cc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8323cc: add             x25, x1, x3, lsl #2
    //     0x8323d0: add             x25, x25, #0xf
    //     0x8323d4: str             w0, [x25]
    //     0x8323d8: tbz             w0, #0, #0x8323f4
    //     0x8323dc: ldurb           w16, [x1, #-1]
    //     0x8323e0: ldurb           w17, [x0, #-1]
    //     0x8323e4: and             x16, x17, x16, lsr #2
    //     0x8323e8: tst             x16, HEAP, lsr #32
    //     0x8323ec: b.eq            #0x8323f4
    //     0x8323f0: bl              #0xd67e5c
    // 0x8323f4: ldr             x0, [fp, #0x18]
    // 0x8323f8: LoadField: r1 = r0->field_1f
    //     0x8323f8: ldur            w1, [x0, #0x1f]
    // 0x8323fc: DecompressPointer r1
    //     0x8323fc: add             x1, x1, HEAP, lsl #32
    // 0x832400: cmp             w1, NULL
    // 0x832404: b.eq            #0x832dc8
    // 0x832408: r3 = LoadInt32Instr(r1)
    //     0x832408: sbfx            x3, x1, #1, #0x1f
    //     0x83240c: tbz             w1, #0, #0x832414
    //     0x832410: ldur            x3, [x1, #7]
    // 0x832414: cmp             x3, #0
    // 0x832418: b.le            #0x8325a0
    // 0x83241c: sub             x4, x3, #1
    // 0x832420: stur            x4, [fp, #-0x20]
    // 0x832424: LoadField: r3 = r0->field_17
    //     0x832424: ldur            w3, [x0, #0x17]
    // 0x832428: DecompressPointer r3
    //     0x832428: add             x3, x3, HEAP, lsl #32
    // 0x83242c: stur            x3, [fp, #-0x18]
    // 0x832430: cmp             w3, NULL
    // 0x832434: b.eq            #0x832dcc
    // 0x832438: r1 = <double>
    //     0x832438: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x83243c: r0 = _DragAnimation()
    //     0x83243c: bl              #0x832ee4  ; Allocate_DragAnimationStub -> _DragAnimation (size=0x18)
    // 0x832440: mov             x2, x0
    // 0x832444: ldur            x0, [fp, #-0x18]
    // 0x832448: stur            x2, [fp, #-0x28]
    // 0x83244c: StoreField: r2->field_b = r0
    //     0x83244c: stur            w0, [x2, #0xb]
    // 0x832450: ldur            x0, [fp, #-0x20]
    // 0x832454: StoreField: r2->field_f = r0
    //     0x832454: stur            x0, [x2, #0xf]
    // 0x832458: r1 = <double>
    //     0x832458: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x83245c: r0 = ReverseAnimation()
    //     0x83245c: bl              #0x7b9ff0  ; AllocateReverseAnimationStub -> ReverseAnimation (size=0x1c)
    // 0x832460: mov             x2, x0
    // 0x832464: ldur            x0, [fp, #-0x28]
    // 0x832468: stur            x2, [fp, #-0x18]
    // 0x83246c: StoreField: r2->field_17 = r0
    //     0x83246c: stur            w0, [x2, #0x17]
    // 0x832470: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0x832470: add             x1, PP, #0xf, lsl #12  ; [pp+0xf3d8] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    //     0x832474: ldr             x1, [x1, #0x3d8]
    // 0x832478: r0 = ObserverList()
    //     0x832478: bl              #0x5a0e00  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0x83247c: mov             x1, x0
    // 0x832480: r0 = false
    //     0x832480: add             x0, NULL, #0x30  ; false
    // 0x832484: stur            x1, [fp, #-0x28]
    // 0x832488: StoreField: r1->field_f = r0
    //     0x832488: stur            w0, [x1, #0xf]
    // 0x83248c: r2 = Sentinel
    //     0x83248c: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x832490: StoreField: r1->field_13 = r2
    //     0x832490: stur            w2, [x1, #0x13]
    // 0x832494: r16 = <(dynamic this, AnimationStatus) => void?>
    //     0x832494: add             x16, PP, #0xf, lsl #12  ; [pp+0xf3d8] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    //     0x832498: ldr             x16, [x16, #0x3d8]
    // 0x83249c: stp             xzr, x16, [SP, #-0x10]!
    // 0x8324a0: r0 = _GrowableList()
    //     0x8324a0: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x8324a4: add             SP, SP, #0x10
    // 0x8324a8: ldur            x1, [fp, #-0x28]
    // 0x8324ac: StoreField: r1->field_b = r0
    //     0x8324ac: stur            w0, [x1, #0xb]
    //     0x8324b0: ldurb           w16, [x1, #-1]
    //     0x8324b4: ldurb           w17, [x0, #-1]
    //     0x8324b8: and             x16, x17, x16, lsr #2
    //     0x8324bc: tst             x16, HEAP, lsr #32
    //     0x8324c0: b.eq            #0x8324c8
    //     0x8324c4: bl              #0xd6826c
    // 0x8324c8: mov             x0, x1
    // 0x8324cc: ldur            x2, [fp, #-0x18]
    // 0x8324d0: StoreField: r2->field_13 = r0
    //     0x8324d0: stur            w0, [x2, #0x13]
    //     0x8324d4: ldurb           w16, [x2, #-1]
    //     0x8324d8: ldurb           w17, [x0, #-1]
    //     0x8324dc: and             x16, x17, x16, lsr #2
    //     0x8324e0: tst             x16, HEAP, lsr #32
    //     0x8324e4: b.eq            #0x8324ec
    //     0x8324e8: bl              #0xd6828c
    // 0x8324ec: r3 = 0
    //     0x8324ec: mov             x3, #0
    // 0x8324f0: StoreField: r2->field_b = r3
    //     0x8324f0: stur            x3, [x2, #0xb]
    // 0x8324f4: ldur            x4, [fp, #-0x10]
    // 0x8324f8: LoadField: r0 = r4->field_b
    //     0x8324f8: ldur            w0, [x4, #0xb]
    // 0x8324fc: DecompressPointer r0
    //     0x8324fc: add             x0, x0, HEAP, lsl #32
    // 0x832500: r1 = LoadInt32Instr(r0)
    //     0x832500: sbfx            x1, x0, #1, #0x1f
    // 0x832504: mov             x0, x1
    // 0x832508: ldur            x1, [fp, #-0x20]
    // 0x83250c: cmp             x1, x0
    // 0x832510: b.hs            #0x832dd0
    // 0x832514: LoadField: r0 = r4->field_f
    //     0x832514: ldur            w0, [x4, #0xf]
    // 0x832518: DecompressPointer r0
    //     0x832518: add             x0, x0, HEAP, lsl #32
    // 0x83251c: ldur            x1, [fp, #-0x20]
    // 0x832520: ArrayLoad: r5 = r0[r1]  ; Unknown_4
    //     0x832520: add             x16, x0, x1, lsl #2
    //     0x832524: ldur            w5, [x16, #0xf]
    // 0x832528: DecompressPointer r5
    //     0x832528: add             x5, x5, HEAP, lsl #32
    // 0x83252c: ldr             x16, [fp, #0x18]
    // 0x832530: stp             x5, x16, [SP, #-0x10]!
    // 0x832534: r16 = false
    //     0x832534: add             x16, NULL, #0x30  ; false
    // 0x832538: stp             x2, x16, [SP, #-0x10]!
    // 0x83253c: r0 = _buildStyledTab()
    //     0x83253c: bl              #0x832ef0  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_buildStyledTab
    // 0x832540: add             SP, SP, #0x20
    // 0x832544: mov             x3, x0
    // 0x832548: ldur            x2, [fp, #-0x10]
    // 0x83254c: LoadField: r0 = r2->field_b
    //     0x83254c: ldur            w0, [x2, #0xb]
    // 0x832550: DecompressPointer r0
    //     0x832550: add             x0, x0, HEAP, lsl #32
    // 0x832554: r1 = LoadInt32Instr(r0)
    //     0x832554: sbfx            x1, x0, #1, #0x1f
    // 0x832558: mov             x0, x1
    // 0x83255c: ldur            x1, [fp, #-0x20]
    // 0x832560: cmp             x1, x0
    // 0x832564: b.hs            #0x832dd4
    // 0x832568: LoadField: r1 = r2->field_f
    //     0x832568: ldur            w1, [x2, #0xf]
    // 0x83256c: DecompressPointer r1
    //     0x83256c: add             x1, x1, HEAP, lsl #32
    // 0x832570: mov             x0, x3
    // 0x832574: ldur            x3, [fp, #-0x20]
    // 0x832578: ArrayStore: r1[r3] = r0  ; List_4
    //     0x832578: add             x25, x1, x3, lsl #2
    //     0x83257c: add             x25, x25, #0xf
    //     0x832580: str             w0, [x25]
    //     0x832584: tbz             w0, #0, #0x8325a0
    //     0x832588: ldurb           w16, [x1, #-1]
    //     0x83258c: ldurb           w17, [x0, #-1]
    //     0x832590: and             x16, x17, x16, lsr #2
    //     0x832594: tst             x16, HEAP, lsr #32
    //     0x832598: b.eq            #0x8325a0
    //     0x83259c: bl              #0xd67e5c
    // 0x8325a0: ldr             x1, [fp, #0x18]
    // 0x8325a4: LoadField: r3 = r1->field_1f
    //     0x8325a4: ldur            w3, [x1, #0x1f]
    // 0x8325a8: DecompressPointer r3
    //     0x8325a8: add             x3, x3, HEAP, lsl #32
    // 0x8325ac: stur            x3, [fp, #-0x18]
    // 0x8325b0: cmp             w3, NULL
    // 0x8325b4: b.eq            #0x832dd8
    // 0x8325b8: LoadField: r0 = r1->field_b
    //     0x8325b8: ldur            w0, [x1, #0xb]
    // 0x8325bc: DecompressPointer r0
    //     0x8325bc: add             x0, x0, HEAP, lsl #32
    // 0x8325c0: cmp             w0, NULL
    // 0x8325c4: b.eq            #0x832ddc
    // 0x8325c8: LoadField: r4 = r0->field_f
    //     0x8325c8: ldur            w4, [x0, #0xf]
    // 0x8325cc: DecompressPointer r4
    //     0x8325cc: add             x4, x4, HEAP, lsl #32
    // 0x8325d0: r0 = LoadClassIdInstr(r4)
    //     0x8325d0: ldur            x0, [x4, #-1]
    //     0x8325d4: ubfx            x0, x0, #0xc, #0x14
    // 0x8325d8: SaveReg r4
    //     0x8325d8: str             x4, [SP, #-8]!
    // 0x8325dc: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x8325dc: mov             x17, #0xb8ea
    //     0x8325e0: add             lr, x0, x17
    //     0x8325e4: ldr             lr, [x21, lr, lsl #3]
    //     0x8325e8: blr             lr
    // 0x8325ec: add             SP, SP, #8
    // 0x8325f0: r1 = LoadInt32Instr(r0)
    //     0x8325f0: sbfx            x1, x0, #1, #0x1f
    // 0x8325f4: sub             x0, x1, #1
    // 0x8325f8: ldur            x1, [fp, #-0x18]
    // 0x8325fc: r2 = LoadInt32Instr(r1)
    //     0x8325fc: sbfx            x2, x1, #1, #0x1f
    //     0x832600: tbz             w1, #0, #0x832608
    //     0x832604: ldur            x2, [x1, #7]
    // 0x832608: cmp             x2, x0
    // 0x83260c: b.ge            #0x8327bc
    // 0x832610: ldr             x2, [fp, #0x18]
    // 0x832614: ldur            x0, [fp, #-0x10]
    // 0x832618: LoadField: r1 = r2->field_1f
    //     0x832618: ldur            w1, [x2, #0x1f]
    // 0x83261c: DecompressPointer r1
    //     0x83261c: add             x1, x1, HEAP, lsl #32
    // 0x832620: cmp             w1, NULL
    // 0x832624: b.eq            #0x832de0
    // 0x832628: r3 = LoadInt32Instr(r1)
    //     0x832628: sbfx            x3, x1, #1, #0x1f
    //     0x83262c: tbz             w1, #0, #0x832634
    //     0x832630: ldur            x3, [x1, #7]
    // 0x832634: add             x4, x3, #1
    // 0x832638: stur            x4, [fp, #-0x20]
    // 0x83263c: LoadField: r3 = r2->field_17
    //     0x83263c: ldur            w3, [x2, #0x17]
    // 0x832640: DecompressPointer r3
    //     0x832640: add             x3, x3, HEAP, lsl #32
    // 0x832644: stur            x3, [fp, #-0x18]
    // 0x832648: cmp             w3, NULL
    // 0x83264c: b.eq            #0x832de4
    // 0x832650: r1 = <double>
    //     0x832650: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x832654: r0 = _DragAnimation()
    //     0x832654: bl              #0x832ee4  ; Allocate_DragAnimationStub -> _DragAnimation (size=0x18)
    // 0x832658: mov             x2, x0
    // 0x83265c: ldur            x0, [fp, #-0x18]
    // 0x832660: stur            x2, [fp, #-0x28]
    // 0x832664: StoreField: r2->field_b = r0
    //     0x832664: stur            w0, [x2, #0xb]
    // 0x832668: ldur            x0, [fp, #-0x20]
    // 0x83266c: StoreField: r2->field_f = r0
    //     0x83266c: stur            x0, [x2, #0xf]
    // 0x832670: r1 = <double>
    //     0x832670: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x832674: r0 = ReverseAnimation()
    //     0x832674: bl              #0x7b9ff0  ; AllocateReverseAnimationStub -> ReverseAnimation (size=0x1c)
    // 0x832678: mov             x2, x0
    // 0x83267c: ldur            x0, [fp, #-0x28]
    // 0x832680: stur            x2, [fp, #-0x18]
    // 0x832684: StoreField: r2->field_17 = r0
    //     0x832684: stur            w0, [x2, #0x17]
    // 0x832688: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0x832688: add             x1, PP, #0xf, lsl #12  ; [pp+0xf3d8] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    //     0x83268c: ldr             x1, [x1, #0x3d8]
    // 0x832690: r0 = ObserverList()
    //     0x832690: bl              #0x5a0e00  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0x832694: mov             x1, x0
    // 0x832698: r0 = false
    //     0x832698: add             x0, NULL, #0x30  ; false
    // 0x83269c: stur            x1, [fp, #-0x28]
    // 0x8326a0: StoreField: r1->field_f = r0
    //     0x8326a0: stur            w0, [x1, #0xf]
    // 0x8326a4: r2 = Sentinel
    //     0x8326a4: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8326a8: StoreField: r1->field_13 = r2
    //     0x8326a8: stur            w2, [x1, #0x13]
    // 0x8326ac: r16 = <(dynamic this, AnimationStatus) => void?>
    //     0x8326ac: add             x16, PP, #0xf, lsl #12  ; [pp+0xf3d8] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    //     0x8326b0: ldr             x16, [x16, #0x3d8]
    // 0x8326b4: stp             xzr, x16, [SP, #-0x10]!
    // 0x8326b8: r0 = _GrowableList()
    //     0x8326b8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x8326bc: add             SP, SP, #0x10
    // 0x8326c0: ldur            x1, [fp, #-0x28]
    // 0x8326c4: StoreField: r1->field_b = r0
    //     0x8326c4: stur            w0, [x1, #0xb]
    //     0x8326c8: ldurb           w16, [x1, #-1]
    //     0x8326cc: ldurb           w17, [x0, #-1]
    //     0x8326d0: and             x16, x17, x16, lsr #2
    //     0x8326d4: tst             x16, HEAP, lsr #32
    //     0x8326d8: b.eq            #0x8326e0
    //     0x8326dc: bl              #0xd6826c
    // 0x8326e0: mov             x0, x1
    // 0x8326e4: ldur            x2, [fp, #-0x18]
    // 0x8326e8: StoreField: r2->field_13 = r0
    //     0x8326e8: stur            w0, [x2, #0x13]
    //     0x8326ec: ldurb           w16, [x2, #-1]
    //     0x8326f0: ldurb           w17, [x0, #-1]
    //     0x8326f4: and             x16, x17, x16, lsr #2
    //     0x8326f8: tst             x16, HEAP, lsr #32
    //     0x8326fc: b.eq            #0x832704
    //     0x832700: bl              #0xd6828c
    // 0x832704: r0 = 0
    //     0x832704: mov             x0, #0
    // 0x832708: StoreField: r2->field_b = r0
    //     0x832708: stur            x0, [x2, #0xb]
    // 0x83270c: ldur            x3, [fp, #-0x10]
    // 0x832710: LoadField: r0 = r3->field_b
    //     0x832710: ldur            w0, [x3, #0xb]
    // 0x832714: DecompressPointer r0
    //     0x832714: add             x0, x0, HEAP, lsl #32
    // 0x832718: r1 = LoadInt32Instr(r0)
    //     0x832718: sbfx            x1, x0, #1, #0x1f
    // 0x83271c: mov             x0, x1
    // 0x832720: ldur            x1, [fp, #-0x20]
    // 0x832724: cmp             x1, x0
    // 0x832728: b.hs            #0x832de8
    // 0x83272c: LoadField: r0 = r3->field_f
    //     0x83272c: ldur            w0, [x3, #0xf]
    // 0x832730: DecompressPointer r0
    //     0x832730: add             x0, x0, HEAP, lsl #32
    // 0x832734: ldur            x1, [fp, #-0x20]
    // 0x832738: ArrayLoad: r4 = r0[r1]  ; Unknown_4
    //     0x832738: add             x16, x0, x1, lsl #2
    //     0x83273c: ldur            w4, [x16, #0xf]
    // 0x832740: DecompressPointer r4
    //     0x832740: add             x4, x4, HEAP, lsl #32
    // 0x832744: ldr             x16, [fp, #0x18]
    // 0x832748: stp             x4, x16, [SP, #-0x10]!
    // 0x83274c: r16 = false
    //     0x83274c: add             x16, NULL, #0x30  ; false
    // 0x832750: stp             x2, x16, [SP, #-0x10]!
    // 0x832754: r0 = _buildStyledTab()
    //     0x832754: bl              #0x832ef0  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_buildStyledTab
    // 0x832758: add             SP, SP, #0x20
    // 0x83275c: mov             x3, x0
    // 0x832760: ldur            x2, [fp, #-0x10]
    // 0x832764: LoadField: r0 = r2->field_b
    //     0x832764: ldur            w0, [x2, #0xb]
    // 0x832768: DecompressPointer r0
    //     0x832768: add             x0, x0, HEAP, lsl #32
    // 0x83276c: r1 = LoadInt32Instr(r0)
    //     0x83276c: sbfx            x1, x0, #1, #0x1f
    // 0x832770: mov             x0, x1
    // 0x832774: ldur            x1, [fp, #-0x20]
    // 0x832778: cmp             x1, x0
    // 0x83277c: b.hs            #0x832dec
    // 0x832780: LoadField: r1 = r2->field_f
    //     0x832780: ldur            w1, [x2, #0xf]
    // 0x832784: DecompressPointer r1
    //     0x832784: add             x1, x1, HEAP, lsl #32
    // 0x832788: mov             x0, x3
    // 0x83278c: ldur            x3, [fp, #-0x20]
    // 0x832790: ArrayStore: r1[r3] = r0  ; List_4
    //     0x832790: add             x25, x1, x3, lsl #2
    //     0x832794: add             x25, x25, #0xf
    //     0x832798: str             w0, [x25]
    //     0x83279c: tbz             w0, #0, #0x8327b8
    //     0x8327a0: ldurb           w16, [x1, #-1]
    //     0x8327a4: ldurb           w17, [x0, #-1]
    //     0x8327a8: and             x16, x17, x16, lsr #2
    //     0x8327ac: tst             x16, HEAP, lsr #32
    //     0x8327b0: b.eq            #0x8327b8
    //     0x8327b4: bl              #0xd67e5c
    // 0x8327b8: b               #0x8327c0
    // 0x8327bc: ldur            x2, [fp, #-0x10]
    // 0x8327c0: ldr             x1, [fp, #0x18]
    // 0x8327c4: ldur            x3, [fp, #-8]
    // 0x8327c8: LoadField: r0 = r1->field_b
    //     0x8327c8: ldur            w0, [x1, #0xb]
    // 0x8327cc: DecompressPointer r0
    //     0x8327cc: add             x0, x0, HEAP, lsl #32
    // 0x8327d0: cmp             w0, NULL
    // 0x8327d4: b.eq            #0x832df0
    // 0x8327d8: LoadField: r4 = r0->field_f
    //     0x8327d8: ldur            w4, [x0, #0xf]
    // 0x8327dc: DecompressPointer r4
    //     0x8327dc: add             x4, x4, HEAP, lsl #32
    // 0x8327e0: r0 = LoadClassIdInstr(r4)
    //     0x8327e0: ldur            x0, [x4, #-1]
    //     0x8327e4: ubfx            x0, x0, #0xc, #0x14
    // 0x8327e8: SaveReg r4
    //     0x8327e8: str             x4, [SP, #-8]!
    // 0x8327ec: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x8327ec: mov             x17, #0xb8ea
    //     0x8327f0: add             lr, x0, x17
    //     0x8327f4: ldr             lr, [x21, lr, lsl #3]
    //     0x8327f8: blr             lr
    // 0x8327fc: add             SP, SP, #8
    // 0x832800: stur            x0, [fp, #-0x18]
    // 0x832804: r1 = 1
    //     0x832804: mov             x1, #1
    // 0x832808: r0 = AllocateContext()
    //     0x832808: bl              #0xd68aa4  ; AllocateContextStub
    // 0x83280c: mov             x1, x0
    // 0x832810: ldur            x0, [fp, #-8]
    // 0x832814: StoreField: r1->field_b = r0
    //     0x832814: stur            w0, [x1, #0xb]
    // 0x832818: StoreField: r1->field_f = rZR
    //     0x832818: stur            wzr, [x1, #0xf]
    // 0x83281c: ldur            x0, [fp, #-0x18]
    // 0x832820: r2 = LoadInt32Instr(r0)
    //     0x832820: sbfx            x2, x0, #1, #0x1f
    // 0x832824: stur            x2, [fp, #-0x30]
    // 0x832828: mov             x5, x1
    // 0x83282c: r4 = 0
    //     0x83282c: mov             x4, #0
    // 0x832830: ldr             x3, [fp, #0x18]
    // 0x832834: ldur            x1, [fp, #-0x10]
    // 0x832838: stur            x5, [fp, #-8]
    // 0x83283c: stur            x4, [fp, #-0x20]
    // 0x832840: CheckStackOverflow
    //     0x832840: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x832844: cmp             SP, x16
    //     0x832848: b.ls            #0x832df4
    // 0x83284c: cmp             x4, x2
    // 0x832850: b.ge            #0x832b94
    // 0x832854: LoadField: r6 = r3->field_b
    //     0x832854: ldur            w6, [x3, #0xb]
    // 0x832858: DecompressPointer r6
    //     0x832858: add             x6, x6, HEAP, lsl #32
    // 0x83285c: cmp             w6, NULL
    // 0x832860: b.eq            #0x832dfc
    // 0x832864: r0 = EdgeInsets()
    //     0x832864: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x832868: mov             x3, x0
    // 0x83286c: d0 = 0.000000
    //     0x83286c: eor             v0.16b, v0.16b, v0.16b
    // 0x832870: stur            x3, [fp, #-0x48]
    // 0x832874: StoreField: r3->field_7 = d0
    //     0x832874: stur            d0, [x3, #7]
    // 0x832878: StoreField: r3->field_f = d0
    //     0x832878: stur            d0, [x3, #0xf]
    // 0x83287c: StoreField: r3->field_17 = d0
    //     0x83287c: stur            d0, [x3, #0x17]
    // 0x832880: d1 = 2.000000
    //     0x832880: fmov            d1, #2.00000000
    // 0x832884: StoreField: r3->field_1f = d1
    //     0x832884: stur            d1, [x3, #0x1f]
    // 0x832888: ldur            x4, [fp, #-0x10]
    // 0x83288c: LoadField: r0 = r4->field_b
    //     0x83288c: ldur            w0, [x4, #0xb]
    // 0x832890: DecompressPointer r0
    //     0x832890: add             x0, x0, HEAP, lsl #32
    // 0x832894: r1 = LoadInt32Instr(r0)
    //     0x832894: sbfx            x1, x0, #1, #0x1f
    // 0x832898: mov             x0, x1
    // 0x83289c: ldur            x1, [fp, #-0x20]
    // 0x8328a0: cmp             x1, x0
    // 0x8328a4: b.hs            #0x832e00
    // 0x8328a8: LoadField: r0 = r4->field_f
    //     0x8328a8: ldur            w0, [x4, #0xf]
    // 0x8328ac: DecompressPointer r0
    //     0x8328ac: add             x0, x0, HEAP, lsl #32
    // 0x8328b0: ldur            x5, [fp, #-0x20]
    // 0x8328b4: ArrayLoad: r6 = r0[r5]  ; Unknown_4
    //     0x8328b4: add             x16, x0, x5, lsl #2
    //     0x8328b8: ldur            w6, [x16, #0xf]
    // 0x8328bc: DecompressPointer r6
    //     0x8328bc: add             x6, x6, HEAP, lsl #32
    // 0x8328c0: ldr             x7, [fp, #0x18]
    // 0x8328c4: stur            x6, [fp, #-0x40]
    // 0x8328c8: LoadField: r2 = r7->field_1f
    //     0x8328c8: ldur            w2, [x7, #0x1f]
    // 0x8328cc: DecompressPointer r2
    //     0x8328cc: add             x2, x2, HEAP, lsl #32
    // 0x8328d0: r0 = BoxInt64Instr(r5)
    //     0x8328d0: sbfiz           x0, x5, #1, #0x1f
    //     0x8328d4: cmp             x5, x0, asr #1
    //     0x8328d8: b.eq            #0x8328e4
    //     0x8328dc: bl              #0xd69c6c
    //     0x8328e0: stur            x5, [x0, #7]
    // 0x8328e4: cmp             w0, w2
    // 0x8328e8: b.eq            #0x83292c
    // 0x8328ec: and             w16, w0, w2
    // 0x8328f0: branchIfSmi(r16, 0x832924)
    //     0x8328f0: tbz             w16, #0, #0x832924
    // 0x8328f4: r16 = LoadClassIdInstr(r0)
    //     0x8328f4: ldur            x16, [x0, #-1]
    //     0x8328f8: ubfx            x16, x16, #0xc, #0x14
    // 0x8328fc: cmp             x16, #0x3c
    // 0x832900: b.ne            #0x832924
    // 0x832904: r16 = LoadClassIdInstr(r2)
    //     0x832904: ldur            x16, [x2, #-1]
    //     0x832908: ubfx            x16, x16, #0xc, #0x14
    // 0x83290c: cmp             x16, #0x3c
    // 0x832910: b.ne            #0x832924
    // 0x832914: LoadField: r16 = r0->field_7
    //     0x832914: ldur            x16, [x0, #7]
    // 0x832918: LoadField: r17 = r2->field_7
    //     0x832918: ldur            x17, [x2, #7]
    // 0x83291c: cmp             x16, x17
    // 0x832920: b.eq            #0x83292c
    // 0x832924: r8 = false
    //     0x832924: add             x8, NULL, #0x30  ; false
    // 0x832928: b               #0x832930
    // 0x83292c: r8 = true
    //     0x83292c: add             x8, NULL, #0x20  ; true
    // 0x832930: stur            x8, [fp, #-0x28]
    // 0x832934: add             x0, x5, #1
    // 0x832938: stur            x0, [fp, #-0x38]
    // 0x83293c: r1 = Null
    //     0x83293c: mov             x1, NULL
    // 0x832940: r2 = 8
    //     0x832940: mov             x2, #8
    // 0x832944: r0 = AllocateArray()
    //     0x832944: bl              #0xd6987c  ; AllocateArrayStub
    // 0x832948: mov             x2, x0
    // 0x83294c: r17 = "Tab "
    //     0x83294c: add             x17, PP, #0x37, lsl #12  ; [pp+0x37ee8] "Tab "
    //     0x832950: ldr             x17, [x17, #0xee8]
    // 0x832954: StoreField: r2->field_f = r17
    //     0x832954: stur            w17, [x2, #0xf]
    // 0x832958: ldur            x3, [fp, #-0x38]
    // 0x83295c: r0 = BoxInt64Instr(r3)
    //     0x83295c: sbfiz           x0, x3, #1, #0x1f
    //     0x832960: cmp             x3, x0, asr #1
    //     0x832964: b.eq            #0x832970
    //     0x832968: bl              #0xd69bb8
    //     0x83296c: stur            x3, [x0, #7]
    // 0x832970: StoreField: r2->field_13 = r0
    //     0x832970: stur            w0, [x2, #0x13]
    // 0x832974: r17 = " of "
    //     0x832974: ldr             x17, [PP, #0x3d20]  ; [pp+0x3d20] " of "
    // 0x832978: StoreField: r2->field_17 = r17
    //     0x832978: stur            w17, [x2, #0x17]
    // 0x83297c: ldur            x0, [fp, #-0x18]
    // 0x832980: StoreField: r2->field_1b = r0
    //     0x832980: stur            w0, [x2, #0x1b]
    // 0x832984: SaveReg r2
    //     0x832984: str             x2, [SP, #-8]!
    // 0x832988: r0 = _interpolate()
    //     0x832988: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x83298c: add             SP, SP, #8
    // 0x832990: stur            x0, [fp, #-0x50]
    // 0x832994: r0 = Semantics()
    //     0x832994: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0x832998: stur            x0, [fp, #-0x58]
    // 0x83299c: ldur            x16, [fp, #-0x28]
    // 0x8329a0: stp             x16, x0, [SP, #-0x10]!
    // 0x8329a4: ldur            x16, [fp, #-0x50]
    // 0x8329a8: SaveReg r16
    //     0x8329a8: str             x16, [SP, #-8]!
    // 0x8329ac: r4 = const [0, 0x3, 0x3, 0x1, label, 0x2, selected, 0x1, null]
    //     0x8329ac: add             x4, PP, #0x37, lsl #12  ; [pp+0x37ef0] List(9) [0, 0x3, 0x3, 0x1, "label", 0x2, "selected", 0x1, Null]
    //     0x8329b0: ldr             x4, [x4, #0xef0]
    // 0x8329b4: r0 = Semantics()
    //     0x8329b4: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x8329b8: add             SP, SP, #0x18
    // 0x8329bc: r1 = Null
    //     0x8329bc: mov             x1, NULL
    // 0x8329c0: r2 = 4
    //     0x8329c0: mov             x2, #4
    // 0x8329c4: r0 = AllocateArray()
    //     0x8329c4: bl              #0xd6987c  ; AllocateArrayStub
    // 0x8329c8: mov             x2, x0
    // 0x8329cc: ldur            x0, [fp, #-0x40]
    // 0x8329d0: stur            x2, [fp, #-0x28]
    // 0x8329d4: StoreField: r2->field_f = r0
    //     0x8329d4: stur            w0, [x2, #0xf]
    // 0x8329d8: ldur            x0, [fp, #-0x58]
    // 0x8329dc: StoreField: r2->field_13 = r0
    //     0x8329dc: stur            w0, [x2, #0x13]
    // 0x8329e0: r1 = <Widget>
    //     0x8329e0: add             x1, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x8329e4: ldr             x1, [x1, #0xea8]
    // 0x8329e8: r0 = AllocateGrowableArray()
    //     0x8329e8: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x8329ec: mov             x1, x0
    // 0x8329f0: ldur            x0, [fp, #-0x28]
    // 0x8329f4: stur            x1, [fp, #-0x40]
    // 0x8329f8: StoreField: r1->field_f = r0
    //     0x8329f8: stur            w0, [x1, #0xf]
    // 0x8329fc: r0 = 4
    //     0x8329fc: mov             x0, #4
    // 0x832a00: StoreField: r1->field_b = r0
    //     0x832a00: stur            w0, [x1, #0xb]
    // 0x832a04: r0 = Stack()
    //     0x832a04: bl              #0x821540  ; AllocateStackStub -> Stack (size=0x20)
    // 0x832a08: mov             x1, x0
    // 0x832a0c: r0 = Instance_AlignmentDirectional
    //     0x832a0c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14f70] Obj!AlignmentDirectional@b37971
    //     0x832a10: ldr             x0, [x0, #0xf70]
    // 0x832a14: stur            x1, [fp, #-0x28]
    // 0x832a18: StoreField: r1->field_f = r0
    //     0x832a18: stur            w0, [x1, #0xf]
    // 0x832a1c: r2 = Instance_StackFit
    //     0x832a1c: add             x2, PP, #0x14, lsl #12  ; [pp+0x14f78] Obj!StackFit@b64771
    //     0x832a20: ldr             x2, [x2, #0xf78]
    // 0x832a24: StoreField: r1->field_17 = r2
    //     0x832a24: stur            w2, [x1, #0x17]
    // 0x832a28: r3 = Instance_Clip
    //     0x832a28: add             x3, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x832a2c: ldr             x3, [x3, #0x678]
    // 0x832a30: StoreField: r1->field_1b = r3
    //     0x832a30: stur            w3, [x1, #0x1b]
    // 0x832a34: ldur            x4, [fp, #-0x40]
    // 0x832a38: StoreField: r1->field_b = r4
    //     0x832a38: stur            w4, [x1, #0xb]
    // 0x832a3c: r0 = Padding()
    //     0x832a3c: bl              #0x822c3c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x832a40: mov             x1, x0
    // 0x832a44: ldur            x0, [fp, #-0x48]
    // 0x832a48: stur            x1, [fp, #-0x40]
    // 0x832a4c: StoreField: r1->field_f = r0
    //     0x832a4c: stur            w0, [x1, #0xf]
    // 0x832a50: ldur            x0, [fp, #-0x28]
    // 0x832a54: StoreField: r1->field_b = r0
    //     0x832a54: stur            w0, [x1, #0xb]
    // 0x832a58: r0 = InkWell()
    //     0x832a58: bl              #0x832ed8  ; AllocateInkWellStub -> InkWell (size=0x7c)
    // 0x832a5c: mov             x3, x0
    // 0x832a60: ldur            x0, [fp, #-0x40]
    // 0x832a64: stur            x3, [fp, #-0x28]
    // 0x832a68: StoreField: r3->field_b = r0
    //     0x832a68: stur            w0, [x3, #0xb]
    // 0x832a6c: ldur            x2, [fp, #-8]
    // 0x832a70: r1 = Function '<anonymous closure>':.
    //     0x832a70: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bf48] AnonymousClosure: (0x8330bc), in [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::build (0x831f1c)
    //     0x832a74: ldr             x1, [x1, #0xf48]
    // 0x832a78: r0 = AllocateClosure()
    //     0x832a78: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x832a7c: ldur            x2, [fp, #-0x28]
    // 0x832a80: StoreField: r2->field_f = r0
    //     0x832a80: stur            w0, [x2, #0xf]
    // 0x832a84: r3 = Instance_SystemMouseCursor
    //     0x832a84: add             x3, PP, #0x25, lsl #12  ; [pp+0x25ea8] Obj!SystemMouseCursor@b489b1
    //     0x832a88: ldr             x3, [x3, #0xea8]
    // 0x832a8c: StoreField: r2->field_2f = r3
    //     0x832a8c: stur            w3, [x2, #0x2f]
    // 0x832a90: r4 = true
    //     0x832a90: add             x4, NULL, #0x20  ; true
    // 0x832a94: StoreField: r2->field_33 = r4
    //     0x832a94: stur            w4, [x2, #0x33]
    // 0x832a98: r6 = Instance_BoxShape
    //     0x832a98: add             x6, PP, #0xe, lsl #12  ; [pp+0xee68] Obj!BoxShape@b64e91
    //     0x832a9c: ldr             x6, [x6, #0xe68]
    // 0x832aa0: StoreField: r2->field_37 = r6
    //     0x832aa0: stur            w6, [x2, #0x37]
    // 0x832aa4: StoreField: r2->field_5f = r4
    //     0x832aa4: stur            w4, [x2, #0x5f]
    // 0x832aa8: r7 = false
    //     0x832aa8: add             x7, NULL, #0x30  ; false
    // 0x832aac: StoreField: r2->field_63 = r7
    //     0x832aac: stur            w7, [x2, #0x63]
    // 0x832ab0: StoreField: r2->field_73 = r4
    //     0x832ab0: stur            w4, [x2, #0x73]
    // 0x832ab4: StoreField: r2->field_6b = r7
    //     0x832ab4: stur            w7, [x2, #0x6b]
    // 0x832ab8: ldur            x8, [fp, #-0x10]
    // 0x832abc: LoadField: r0 = r8->field_b
    //     0x832abc: ldur            w0, [x8, #0xb]
    // 0x832ac0: DecompressPointer r0
    //     0x832ac0: add             x0, x0, HEAP, lsl #32
    // 0x832ac4: r1 = LoadInt32Instr(r0)
    //     0x832ac4: sbfx            x1, x0, #1, #0x1f
    // 0x832ac8: mov             x0, x1
    // 0x832acc: ldur            x1, [fp, #-0x20]
    // 0x832ad0: cmp             x1, x0
    // 0x832ad4: b.hs            #0x832e04
    // 0x832ad8: LoadField: r1 = r8->field_f
    //     0x832ad8: ldur            w1, [x8, #0xf]
    // 0x832adc: DecompressPointer r1
    //     0x832adc: add             x1, x1, HEAP, lsl #32
    // 0x832ae0: mov             x0, x2
    // 0x832ae4: ldur            x2, [fp, #-0x20]
    // 0x832ae8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x832ae8: add             x25, x1, x2, lsl #2
    //     0x832aec: add             x25, x25, #0xf
    //     0x832af0: str             w0, [x25]
    //     0x832af4: tbz             w0, #0, #0x832b10
    //     0x832af8: ldurb           w16, [x1, #-1]
    //     0x832afc: ldurb           w17, [x0, #-1]
    //     0x832b00: and             x16, x17, x16, lsr #2
    //     0x832b04: tst             x16, HEAP, lsr #32
    //     0x832b08: b.eq            #0x832b10
    //     0x832b0c: bl              #0xd67e5c
    // 0x832b10: ldr             x0, [fp, #0x18]
    // 0x832b14: LoadField: r1 = r0->field_b
    //     0x832b14: ldur            w1, [x0, #0xb]
    // 0x832b18: DecompressPointer r1
    //     0x832b18: add             x1, x1, HEAP, lsl #32
    // 0x832b1c: cmp             w1, NULL
    // 0x832b20: b.eq            #0x832e08
    // 0x832b24: ldur            x5, [fp, #-8]
    // 0x832b28: r0 = CloneContext()
    //     0x832b28: bl              #0xd684cc  ; CloneContextStub
    // 0x832b2c: mov             x2, x0
    // 0x832b30: LoadField: r0 = r2->field_f
    //     0x832b30: ldur            w0, [x2, #0xf]
    // 0x832b34: DecompressPointer r0
    //     0x832b34: add             x0, x0, HEAP, lsl #32
    // 0x832b38: cmp             w0, NULL
    // 0x832b3c: b.eq            #0x832e0c
    // 0x832b40: r1 = LoadInt32Instr(r0)
    //     0x832b40: sbfx            x1, x0, #1, #0x1f
    //     0x832b44: tbz             w0, #0, #0x832b4c
    //     0x832b48: ldur            x1, [x0, #7]
    // 0x832b4c: add             x4, x1, #1
    // 0x832b50: r0 = BoxInt64Instr(r4)
    //     0x832b50: sbfiz           x0, x4, #1, #0x1f
    //     0x832b54: cmp             x4, x0, asr #1
    //     0x832b58: b.eq            #0x832b64
    //     0x832b5c: bl              #0xd69bb8
    //     0x832b60: stur            x4, [x0, #7]
    // 0x832b64: StoreField: r2->field_f = r0
    //     0x832b64: stur            w0, [x2, #0xf]
    //     0x832b68: tbz             w0, #0, #0x832b84
    //     0x832b6c: ldurb           w16, [x2, #-1]
    //     0x832b70: ldurb           w17, [x0, #-1]
    //     0x832b74: and             x16, x17, x16, lsr #2
    //     0x832b78: tst             x16, HEAP, lsr #32
    //     0x832b7c: b.eq            #0x832b84
    //     0x832b80: bl              #0xd6828c
    // 0x832b84: mov             x5, x2
    // 0x832b88: ldur            x0, [fp, #-0x18]
    // 0x832b8c: ldur            x2, [fp, #-0x30]
    // 0x832b90: b               #0x832830
    // 0x832b94: mov             x0, x3
    // 0x832b98: LoadField: r1 = r0->field_b
    //     0x832b98: ldur            w1, [x0, #0xb]
    // 0x832b9c: DecompressPointer r1
    //     0x832b9c: add             x1, x1, HEAP, lsl #32
    // 0x832ba0: cmp             w1, NULL
    // 0x832ba4: b.eq            #0x832e10
    // 0x832ba8: LoadField: r2 = r0->field_1b
    //     0x832ba8: ldur            w2, [x0, #0x1b]
    // 0x832bac: DecompressPointer r2
    //     0x832bac: add             x2, x2, HEAP, lsl #32
    // 0x832bb0: stur            x2, [fp, #-0x40]
    // 0x832bb4: LoadField: r3 = r1->field_37
    //     0x832bb4: ldur            w3, [x1, #0x37]
    // 0x832bb8: DecompressPointer r3
    //     0x832bb8: add             x3, x3, HEAP, lsl #32
    // 0x832bbc: stur            x3, [fp, #-0x28]
    // 0x832bc0: LoadField: r4 = r1->field_3f
    //     0x832bc0: ldur            w4, [x1, #0x3f]
    // 0x832bc4: DecompressPointer r4
    //     0x832bc4: add             x4, x4, HEAP, lsl #32
    // 0x832bc8: stur            x4, [fp, #-0x18]
    // 0x832bcc: LoadField: r5 = r1->field_47
    //     0x832bcc: ldur            w5, [x1, #0x47]
    // 0x832bd0: DecompressPointer r5
    //     0x832bd0: add             x5, x5, HEAP, lsl #32
    // 0x832bd4: stur            x5, [fp, #-8]
    // 0x832bd8: r1 = 1
    //     0x832bd8: mov             x1, #1
    // 0x832bdc: r0 = AllocateContext()
    //     0x832bdc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x832be0: mov             x1, x0
    // 0x832be4: ldr             x0, [fp, #0x18]
    // 0x832be8: StoreField: r1->field_f = r0
    //     0x832be8: stur            w0, [x1, #0xf]
    // 0x832bec: mov             x2, x1
    // 0x832bf0: r1 = Function '_saveTabOffsets@468487081':.
    //     0x832bf0: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bf50] AnonymousClosure: (0x832fec), in [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_saveTabOffsets (0x833044)
    //     0x832bf4: ldr             x1, [x1, #0xf50]
    // 0x832bf8: r0 = AllocateClosure()
    //     0x832bf8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x832bfc: stur            x0, [fp, #-0x48]
    // 0x832c00: r0 = _TabLabelBar()
    //     0x832c00: bl              #0x832ecc  ; Allocate_TabLabelBarStub -> _TabLabelBar (size=0x34)
    // 0x832c04: stur            x0, [fp, #-0x50]
    // 0x832c08: ldur            x16, [fp, #-0x10]
    // 0x832c0c: stp             x16, x0, [SP, #-0x10]!
    // 0x832c10: ldur            x16, [fp, #-0x48]
    // 0x832c14: SaveReg r16
    //     0x832c14: str             x16, [SP, #-8]!
    // 0x832c18: r0 = _TabLabelBar()
    //     0x832c18: bl              #0x832e40  ; [package:extended_tabs/src/tab_bar.dart] _TabLabelBar::_TabLabelBar
    // 0x832c1c: add             SP, SP, #0x18
    // 0x832c20: r0 = _TabStyle()
    //     0x832c20: bl              #0x832e34  ; Allocate_TabStyleStub -> _TabStyle (size=0x28)
    // 0x832c24: mov             x1, x0
    // 0x832c28: r0 = false
    //     0x832c28: add             x0, NULL, #0x30  ; false
    // 0x832c2c: stur            x1, [fp, #-0x10]
    // 0x832c30: StoreField: r1->field_17 = r0
    //     0x832c30: stur            w0, [x1, #0x17]
    // 0x832c34: ldur            x2, [fp, #-0x28]
    // 0x832c38: StoreField: r1->field_1b = r2
    //     0x832c38: stur            w2, [x1, #0x1b]
    // 0x832c3c: r2 = Instance_Color
    //     0x832c3c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x832c40: ldr             x2, [x2, #0xbe8]
    // 0x832c44: StoreField: r1->field_1f = r2
    //     0x832c44: stur            w2, [x1, #0x1f]
    // 0x832c48: ldur            x2, [fp, #-0x18]
    // 0x832c4c: StoreField: r1->field_f = r2
    //     0x832c4c: stur            w2, [x1, #0xf]
    // 0x832c50: ldur            x2, [fp, #-8]
    // 0x832c54: StoreField: r1->field_13 = r2
    //     0x832c54: stur            w2, [x1, #0x13]
    // 0x832c58: ldur            x2, [fp, #-0x50]
    // 0x832c5c: StoreField: r1->field_23 = r2
    //     0x832c5c: stur            w2, [x1, #0x23]
    // 0x832c60: r2 = Instance__AlwaysDismissedAnimation
    //     0x832c60: add             x2, PP, #0xf, lsl #12  ; [pp+0xf3b8] Obj!_AlwaysDismissedAnimation<double>@b4fcc1
    //     0x832c64: ldr             x2, [x2, #0x3b8]
    // 0x832c68: StoreField: r1->field_b = r2
    //     0x832c68: stur            w2, [x1, #0xb]
    // 0x832c6c: r0 = CustomPaint()
    //     0x832c6c: bl              #0x822c30  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x832c70: mov             x1, x0
    // 0x832c74: ldur            x0, [fp, #-0x40]
    // 0x832c78: stur            x1, [fp, #-8]
    // 0x832c7c: StoreField: r1->field_f = r0
    //     0x832c7c: stur            w0, [x1, #0xf]
    // 0x832c80: r0 = Instance_Size
    //     0x832c80: ldr             x0, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0x832c84: StoreField: r1->field_17 = r0
    //     0x832c84: stur            w0, [x1, #0x17]
    // 0x832c88: r0 = false
    //     0x832c88: add             x0, NULL, #0x30  ; false
    // 0x832c8c: StoreField: r1->field_1b = r0
    //     0x832c8c: stur            w0, [x1, #0x1b]
    // 0x832c90: StoreField: r1->field_1f = r0
    //     0x832c90: stur            w0, [x1, #0x1f]
    // 0x832c94: ldur            x2, [fp, #-0x10]
    // 0x832c98: StoreField: r1->field_b = r2
    //     0x832c98: stur            w2, [x1, #0xb]
    // 0x832c9c: ldr             x2, [fp, #0x18]
    // 0x832ca0: LoadField: r3 = r2->field_b
    //     0x832ca0: ldur            w3, [x2, #0xb]
    // 0x832ca4: DecompressPointer r3
    //     0x832ca4: add             x3, x3, HEAP, lsl #32
    // 0x832ca8: cmp             w3, NULL
    // 0x832cac: b.eq            #0x832e14
    // 0x832cb0: LoadField: r3 = r2->field_13
    //     0x832cb0: ldur            w3, [x2, #0x13]
    // 0x832cb4: DecompressPointer r3
    //     0x832cb4: add             x3, x3, HEAP, lsl #32
    // 0x832cb8: cmp             w3, NULL
    // 0x832cbc: b.ne            #0x832d10
    // 0x832cc0: r0 = _TabBarScrollController()
    //     0x832cc0: bl              #0x832e28  ; Allocate_TabBarScrollControllerStub -> _TabBarScrollController (size=0x3c)
    // 0x832cc4: mov             x1, x0
    // 0x832cc8: ldr             x0, [fp, #0x18]
    // 0x832ccc: stur            x1, [fp, #-0x10]
    // 0x832cd0: StoreField: r1->field_37 = r0
    //     0x832cd0: stur            w0, [x1, #0x37]
    // 0x832cd4: SaveReg r1
    //     0x832cd4: str             x1, [SP, #-8]!
    // 0x832cd8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x832cd8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x832cdc: r0 = ScrollController()
    //     0x832cdc: bl              #0x51ee1c  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0x832ce0: add             SP, SP, #8
    // 0x832ce4: ldur            x0, [fp, #-0x10]
    // 0x832ce8: ldr             x1, [fp, #0x18]
    // 0x832cec: StoreField: r1->field_13 = r0
    //     0x832cec: stur            w0, [x1, #0x13]
    //     0x832cf0: ldurb           w16, [x1, #-1]
    //     0x832cf4: ldurb           w17, [x0, #-1]
    //     0x832cf8: and             x16, x17, x16, lsr #2
    //     0x832cfc: tst             x16, HEAP, lsr #32
    //     0x832d00: b.eq            #0x832d08
    //     0x832d04: bl              #0xd6826c
    // 0x832d08: ldur            x2, [fp, #-0x10]
    // 0x832d0c: b               #0x832d18
    // 0x832d10: mov             x1, x2
    // 0x832d14: mov             x2, x3
    // 0x832d18: ldur            x0, [fp, #-8]
    // 0x832d1c: stur            x2, [fp, #-0x10]
    // 0x832d20: LoadField: r3 = r1->field_b
    //     0x832d20: ldur            w3, [x1, #0xb]
    // 0x832d24: DecompressPointer r3
    //     0x832d24: add             x3, x3, HEAP, lsl #32
    // 0x832d28: cmp             w3, NULL
    // 0x832d2c: b.eq            #0x832e18
    // 0x832d30: r0 = SingleChildScrollView()
    //     0x832d30: bl              #0x832e1c  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x38)
    // 0x832d34: r1 = Instance_Axis
    //     0x832d34: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x832d38: ldr             x1, [x1, #0x440]
    // 0x832d3c: StoreField: r0->field_b = r1
    //     0x832d3c: stur            w1, [x0, #0xb]
    // 0x832d40: r1 = false
    //     0x832d40: add             x1, NULL, #0x30  ; false
    // 0x832d44: StoreField: r0->field_f = r1
    //     0x832d44: stur            w1, [x0, #0xf]
    // 0x832d48: ldur            x1, [fp, #-0x10]
    // 0x832d4c: StoreField: r0->field_17 = r1
    //     0x832d4c: stur            w1, [x0, #0x17]
    // 0x832d50: ldur            x1, [fp, #-8]
    // 0x832d54: StoreField: r0->field_23 = r1
    //     0x832d54: stur            w1, [x0, #0x23]
    // 0x832d58: r1 = Instance_DragStartBehavior
    //     0x832d58: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f88] Obj!DragStartBehavior@b65af1
    //     0x832d5c: ldr             x1, [x1, #0xf88]
    // 0x832d60: StoreField: r0->field_27 = r1
    //     0x832d60: stur            w1, [x0, #0x27]
    // 0x832d64: r1 = Instance_Clip
    //     0x832d64: add             x1, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x832d68: ldr             x1, [x1, #0x678]
    // 0x832d6c: StoreField: r0->field_2b = r1
    //     0x832d6c: stur            w1, [x0, #0x2b]
    // 0x832d70: r1 = Instance_ScrollViewKeyboardDismissBehavior
    //     0x832d70: add             x1, PP, #0x20, lsl #12  ; [pp+0x20210] Obj!ScrollViewKeyboardDismissBehavior@b63571
    //     0x832d74: ldr             x1, [x1, #0x210]
    // 0x832d78: StoreField: r0->field_33 = r1
    //     0x832d78: stur            w1, [x0, #0x33]
    // 0x832d7c: LeaveFrame
    //     0x832d7c: mov             SP, fp
    //     0x832d80: ldp             fp, lr, [SP], #0x10
    // 0x832d84: ret
    //     0x832d84: ret             
    // 0x832d88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x832d88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x832d8c: b               #0x831f34
    // 0x832d90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x832d90: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x832d94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x832d94: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x832d98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x832d98: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x832d9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x832d9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x832da0: b               #0x832084
    // 0x832da4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x832da4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x832da8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x832da8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x832dac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x832dac: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x832db0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x832db0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x832db4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x832db4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x832db8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x832db8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x832dbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x832dbc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x832dc0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x832dc0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x832dc4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x832dc4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x832dc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x832dc8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x832dcc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x832dcc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x832dd0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x832dd0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x832dd4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x832dd4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x832dd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x832dd8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x832ddc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x832ddc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x832de0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x832de0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x832de4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x832de4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x832de8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x832de8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x832dec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x832dec: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x832df0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x832df0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x832df4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x832df4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x832df8: b               #0x83284c
    // 0x832dfc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x832dfc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x832e00: r0 = RangeErrorSharedWithFPURegs()
    //     0x832e00: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x832e04: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x832e04: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x832e08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x832e08: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x832e0c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x832e0c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x832e10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x832e10: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x832e14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x832e14: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x832e18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x832e18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildStyledTab(/* No info */) {
    // ** addr: 0x832ef0, size: 0x94
    // 0x832ef0: EnterFrame
    //     0x832ef0: stp             fp, lr, [SP, #-0x10]!
    //     0x832ef4: mov             fp, SP
    // 0x832ef8: AllocStack(0x18)
    //     0x832ef8: sub             SP, SP, #0x18
    // 0x832efc: ldr             x0, [fp, #0x28]
    // 0x832f00: LoadField: r1 = r0->field_b
    //     0x832f00: ldur            w1, [x0, #0xb]
    // 0x832f04: DecompressPointer r1
    //     0x832f04: add             x1, x1, HEAP, lsl #32
    // 0x832f08: cmp             w1, NULL
    // 0x832f0c: b.eq            #0x832f80
    // 0x832f10: LoadField: r0 = r1->field_37
    //     0x832f10: ldur            w0, [x1, #0x37]
    // 0x832f14: DecompressPointer r0
    //     0x832f14: add             x0, x0, HEAP, lsl #32
    // 0x832f18: stur            x0, [fp, #-0x18]
    // 0x832f1c: LoadField: r2 = r1->field_3f
    //     0x832f1c: ldur            w2, [x1, #0x3f]
    // 0x832f20: DecompressPointer r2
    //     0x832f20: add             x2, x2, HEAP, lsl #32
    // 0x832f24: stur            x2, [fp, #-0x10]
    // 0x832f28: LoadField: r3 = r1->field_47
    //     0x832f28: ldur            w3, [x1, #0x47]
    // 0x832f2c: DecompressPointer r3
    //     0x832f2c: add             x3, x3, HEAP, lsl #32
    // 0x832f30: stur            x3, [fp, #-8]
    // 0x832f34: r0 = _TabStyle()
    //     0x832f34: bl              #0x832e34  ; Allocate_TabStyleStub -> _TabStyle (size=0x28)
    // 0x832f38: ldr             x1, [fp, #0x18]
    // 0x832f3c: StoreField: r0->field_17 = r1
    //     0x832f3c: stur            w1, [x0, #0x17]
    // 0x832f40: ldur            x1, [fp, #-0x18]
    // 0x832f44: StoreField: r0->field_1b = r1
    //     0x832f44: stur            w1, [x0, #0x1b]
    // 0x832f48: r1 = Instance_Color
    //     0x832f48: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x832f4c: ldr             x1, [x1, #0xbe8]
    // 0x832f50: StoreField: r0->field_1f = r1
    //     0x832f50: stur            w1, [x0, #0x1f]
    // 0x832f54: ldur            x1, [fp, #-0x10]
    // 0x832f58: StoreField: r0->field_f = r1
    //     0x832f58: stur            w1, [x0, #0xf]
    // 0x832f5c: ldur            x1, [fp, #-8]
    // 0x832f60: StoreField: r0->field_13 = r1
    //     0x832f60: stur            w1, [x0, #0x13]
    // 0x832f64: ldr             x1, [fp, #0x20]
    // 0x832f68: StoreField: r0->field_23 = r1
    //     0x832f68: stur            w1, [x0, #0x23]
    // 0x832f6c: ldr             x1, [fp, #0x10]
    // 0x832f70: StoreField: r0->field_b = r1
    //     0x832f70: stur            w1, [x0, #0xb]
    // 0x832f74: LeaveFrame
    //     0x832f74: mov             SP, fp
    //     0x832f78: ldp             fp, lr, [SP], #0x10
    // 0x832f7c: ret
    //     0x832f7c: ret             
    // 0x832f80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x832f80: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _saveTabOffsets(dynamic, List<double>, TextDirection, double) {
    // ** addr: 0x832fec, size: 0x58
    // 0x832fec: EnterFrame
    //     0x832fec: stp             fp, lr, [SP, #-0x10]!
    //     0x832ff0: mov             fp, SP
    // 0x832ff4: ldr             x0, [fp, #0x28]
    // 0x832ff8: LoadField: r1 = r0->field_17
    //     0x832ff8: ldur            w1, [x0, #0x17]
    // 0x832ffc: DecompressPointer r1
    //     0x832ffc: add             x1, x1, HEAP, lsl #32
    // 0x833000: CheckStackOverflow
    //     0x833000: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x833004: cmp             SP, x16
    //     0x833008: b.ls            #0x83303c
    // 0x83300c: LoadField: r0 = r1->field_f
    //     0x83300c: ldur            w0, [x1, #0xf]
    // 0x833010: DecompressPointer r0
    //     0x833010: add             x0, x0, HEAP, lsl #32
    // 0x833014: ldr             x16, [fp, #0x20]
    // 0x833018: stp             x16, x0, [SP, #-0x10]!
    // 0x83301c: ldr             x16, [fp, #0x18]
    // 0x833020: ldr             lr, [fp, #0x10]
    // 0x833024: stp             lr, x16, [SP, #-0x10]!
    // 0x833028: r0 = _saveTabOffsets()
    //     0x833028: bl              #0x833044  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_saveTabOffsets
    // 0x83302c: add             SP, SP, #0x20
    // 0x833030: LeaveFrame
    //     0x833030: mov             SP, fp
    //     0x833034: ldp             fp, lr, [SP], #0x10
    // 0x833038: ret
    //     0x833038: ret             
    // 0x83303c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83303c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x833040: b               #0x83300c
  }
  _ _saveTabOffsets(/* No info */) {
    // ** addr: 0x833044, size: 0x78
    // 0x833044: EnterFrame
    //     0x833044: stp             fp, lr, [SP, #-0x10]!
    //     0x833048: mov             fp, SP
    // 0x83304c: CheckStackOverflow
    //     0x83304c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x833050: cmp             SP, x16
    //     0x833054: b.ls            #0x8330b4
    // 0x833058: ldr             x0, [fp, #0x10]
    // 0x83305c: ldr             x1, [fp, #0x28]
    // 0x833060: StoreField: r1->field_23 = r0
    //     0x833060: stur            w0, [x1, #0x23]
    //     0x833064: ldurb           w16, [x1, #-1]
    //     0x833068: ldurb           w17, [x0, #-1]
    //     0x83306c: and             x16, x17, x16, lsr #2
    //     0x833070: tst             x16, HEAP, lsr #32
    //     0x833074: b.eq            #0x83307c
    //     0x833078: bl              #0xd6826c
    // 0x83307c: LoadField: r0 = r1->field_1b
    //     0x83307c: ldur            w0, [x1, #0x1b]
    // 0x833080: DecompressPointer r0
    //     0x833080: add             x0, x0, HEAP, lsl #32
    // 0x833084: cmp             w0, NULL
    // 0x833088: b.eq            #0x8330a4
    // 0x83308c: ldr             x16, [fp, #0x20]
    // 0x833090: stp             x16, x0, [SP, #-0x10]!
    // 0x833094: ldr             x16, [fp, #0x18]
    // 0x833098: SaveReg r16
    //     0x833098: str             x16, [SP, #-8]!
    // 0x83309c: r0 = saveTabOffsets()
    //     0x83309c: bl              #0x79f33c  ; [package:extended_tabs/src/tab_bar.dart] _IndicatorPainter::saveTabOffsets
    // 0x8330a0: add             SP, SP, #0x18
    // 0x8330a4: r0 = Null
    //     0x8330a4: mov             x0, NULL
    // 0x8330a8: LeaveFrame
    //     0x8330a8: mov             SP, fp
    //     0x8330ac: ldp             fp, lr, [SP], #0x10
    // 0x8330b0: ret
    //     0x8330b0: ret             
    // 0x8330b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8330b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8330b8: b               #0x833058
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8330bc, size: 0x68
    // 0x8330bc: EnterFrame
    //     0x8330bc: stp             fp, lr, [SP, #-0x10]!
    //     0x8330c0: mov             fp, SP
    // 0x8330c4: ldr             x0, [fp, #0x10]
    // 0x8330c8: LoadField: r1 = r0->field_17
    //     0x8330c8: ldur            w1, [x0, #0x17]
    // 0x8330cc: DecompressPointer r1
    //     0x8330cc: add             x1, x1, HEAP, lsl #32
    // 0x8330d0: CheckStackOverflow
    //     0x8330d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8330d4: cmp             SP, x16
    //     0x8330d8: b.ls            #0x83311c
    // 0x8330dc: LoadField: r0 = r1->field_b
    //     0x8330dc: ldur            w0, [x1, #0xb]
    // 0x8330e0: DecompressPointer r0
    //     0x8330e0: add             x0, x0, HEAP, lsl #32
    // 0x8330e4: LoadField: r2 = r0->field_f
    //     0x8330e4: ldur            w2, [x0, #0xf]
    // 0x8330e8: DecompressPointer r2
    //     0x8330e8: add             x2, x2, HEAP, lsl #32
    // 0x8330ec: LoadField: r0 = r1->field_f
    //     0x8330ec: ldur            w0, [x1, #0xf]
    // 0x8330f0: DecompressPointer r0
    //     0x8330f0: add             x0, x0, HEAP, lsl #32
    // 0x8330f4: r1 = LoadInt32Instr(r0)
    //     0x8330f4: sbfx            x1, x0, #1, #0x1f
    //     0x8330f8: tbz             w0, #0, #0x833100
    //     0x8330fc: ldur            x1, [x0, #7]
    // 0x833100: stp             x1, x2, [SP, #-0x10]!
    // 0x833104: r0 = _handleTap()
    //     0x833104: bl              #0x833124  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_handleTap
    // 0x833108: add             SP, SP, #0x10
    // 0x83310c: r0 = Null
    //     0x83310c: mov             x0, NULL
    // 0x833110: LeaveFrame
    //     0x833110: mov             SP, fp
    //     0x833114: ldp             fp, lr, [SP], #0x10
    // 0x833118: ret
    //     0x833118: ret             
    // 0x83311c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83311c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x833120: b               #0x8330dc
  }
  _ _handleTap(/* No info */) {
    // ** addr: 0x833124, size: 0x74
    // 0x833124: EnterFrame
    //     0x833124: stp             fp, lr, [SP, #-0x10]!
    //     0x833128: mov             fp, SP
    // 0x83312c: CheckStackOverflow
    //     0x83312c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x833130: cmp             SP, x16
    //     0x833134: b.ls            #0x833188
    // 0x833138: ldr             x0, [fp, #0x18]
    // 0x83313c: LoadField: r1 = r0->field_17
    //     0x83313c: ldur            w1, [x0, #0x17]
    // 0x833140: DecompressPointer r1
    //     0x833140: add             x1, x1, HEAP, lsl #32
    // 0x833144: cmp             w1, NULL
    // 0x833148: b.eq            #0x833190
    // 0x83314c: SaveReg r1
    //     0x83314c: str             x1, [SP, #-8]!
    // 0x833150: ldr             x1, [fp, #0x10]
    // 0x833154: SaveReg r1
    //     0x833154: str             x1, [SP, #-8]!
    // 0x833158: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x833158: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x83315c: r0 = animateTo()
    //     0x83315c: bl              #0x8262c8  ; [package:flutter/src/material/tab_controller.dart] TabController::animateTo
    // 0x833160: add             SP, SP, #0x10
    // 0x833164: ldr             x1, [fp, #0x18]
    // 0x833168: LoadField: r2 = r1->field_b
    //     0x833168: ldur            w2, [x1, #0xb]
    // 0x83316c: DecompressPointer r2
    //     0x83316c: add             x2, x2, HEAP, lsl #32
    // 0x833170: cmp             w2, NULL
    // 0x833174: b.eq            #0x833194
    // 0x833178: r0 = Null
    //     0x833178: mov             x0, NULL
    // 0x83317c: LeaveFrame
    //     0x83317c: mov             SP, fp
    //     0x833180: ldp             fp, lr, [SP], #0x10
    // 0x833184: ret
    //     0x833184: ret             
    // 0x833188: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x833188: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83318c: b               #0x833138
    // 0x833190: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x833190: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x833194: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x833194: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Center <anonymous closure>(dynamic, int) {
    // ** addr: 0x833198, size: 0x3e0
    // 0x833198: EnterFrame
    //     0x833198: stp             fp, lr, [SP, #-0x10]!
    //     0x83319c: mov             fp, SP
    // 0x8331a0: AllocStack(0x20)
    //     0x8331a0: sub             SP, SP, #0x20
    // 0x8331a4: SetupParameters()
    //     0x8331a4: ldr             x0, [fp, #0x18]
    //     0x8331a8: ldur            w1, [x0, #0x17]
    //     0x8331ac: add             x1, x1, HEAP, lsl #32
    //     0x8331b0: stur            x1, [fp, #-8]
    // 0x8331b4: CheckStackOverflow
    //     0x8331b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8331b8: cmp             SP, x16
    //     0x8331bc: b.ls            #0x83354c
    // 0x8331c0: LoadField: r0 = r1->field_f
    //     0x8331c0: ldur            w0, [x1, #0xf]
    // 0x8331c4: DecompressPointer r0
    //     0x8331c4: add             x0, x0, HEAP, lsl #32
    // 0x8331c8: LoadField: r2 = r0->field_b
    //     0x8331c8: ldur            w2, [x0, #0xb]
    // 0x8331cc: DecompressPointer r2
    //     0x8331cc: add             x2, x2, HEAP, lsl #32
    // 0x8331d0: cmp             w2, NULL
    // 0x8331d4: b.eq            #0x833554
    // 0x8331d8: LoadField: r0 = r2->field_f
    //     0x8331d8: ldur            w0, [x2, #0xf]
    // 0x8331dc: DecompressPointer r0
    //     0x8331dc: add             x0, x0, HEAP, lsl #32
    // 0x8331e0: r2 = LoadClassIdInstr(r0)
    //     0x8331e0: ldur            x2, [x0, #-1]
    //     0x8331e4: ubfx            x2, x2, #0xc, #0x14
    // 0x8331e8: ldr             x16, [fp, #0x10]
    // 0x8331ec: stp             x16, x0, [SP, #-0x10]!
    // 0x8331f0: mov             x0, x2
    // 0x8331f4: r0 = GDT[cid_x0 + -0xd83]()
    //     0x8331f4: sub             lr, x0, #0xd83
    //     0x8331f8: ldr             lr, [x21, lr, lsl #3]
    //     0x8331fc: blr             lr
    // 0x833200: add             SP, SP, #0x10
    // 0x833204: r2 = Null
    //     0x833204: mov             x2, NULL
    // 0x833208: r1 = Null
    //     0x833208: mov             x1, NULL
    // 0x83320c: cmp             w0, NULL
    // 0x833210: b.eq            #0x83329c
    // 0x833214: branchIfSmi(r0, 0x83329c)
    //     0x833214: tbz             w0, #0, #0x83329c
    // 0x833218: r3 = LoadClassIdInstr(r0)
    //     0x833218: ldur            x3, [x0, #-1]
    //     0x83321c: ubfx            x3, x3, #0xc, #0x14
    // 0x833220: r4 = LoadClassIdInstr(r0)
    //     0x833220: ldur            x4, [x0, #-1]
    //     0x833224: ubfx            x4, x4, #0xc, #0x14
    // 0x833228: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0x83322c: ldr             x3, [x3, #0x18]
    // 0x833230: ldr             x3, [x3, x4, lsl #3]
    // 0x833234: LoadField: r3 = r3->field_2b
    //     0x833234: ldur            w3, [x3, #0x2b]
    // 0x833238: DecompressPointer r3
    //     0x833238: add             x3, x3, HEAP, lsl #32
    // 0x83323c: cmp             w3, NULL
    // 0x833240: b.eq            #0x83329c
    // 0x833244: LoadField: r3 = r3->field_f
    //     0x833244: ldur            w3, [x3, #0xf]
    // 0x833248: lsr             x3, x3, #4
    // 0x83324c: r17 = 4450
    //     0x83324c: mov             x17, #0x1162
    // 0x833250: cmp             x3, x17
    // 0x833254: b.eq            #0x8332a4
    // 0x833258: r3 = SubtypeTestCache
    //     0x833258: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4bf58] SubtypeTestCache
    //     0x83325c: ldr             x3, [x3, #0xf58]
    // 0x833260: r24 = Subtype1TestCacheStub
    //     0x833260: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0x833264: LoadField: r30 = r24->field_7
    //     0x833264: ldur            lr, [x24, #7]
    // 0x833268: blr             lr
    // 0x83326c: cmp             w7, NULL
    // 0x833270: b.eq            #0x83327c
    // 0x833274: tbnz            w7, #4, #0x83329c
    // 0x833278: b               #0x8332a4
    // 0x83327c: r8 = PreferredSizeWidget
    //     0x83327c: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4bf60] Type: PreferredSizeWidget
    //     0x833280: ldr             x8, [x8, #0xf60]
    // 0x833284: r3 = SubtypeTestCache
    //     0x833284: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4bf68] SubtypeTestCache
    //     0x833288: ldr             x3, [x3, #0xf68]
    // 0x83328c: r24 = InstanceOfStub
    //     0x83328c: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x833290: LoadField: r30 = r24->field_7
    //     0x833290: ldur            lr, [x24, #7]
    // 0x833294: blr             lr
    // 0x833298: b               #0x8332a8
    // 0x83329c: r0 = false
    //     0x83329c: add             x0, NULL, #0x30  ; false
    // 0x8332a0: b               #0x8332a8
    // 0x8332a4: r0 = true
    //     0x8332a4: add             x0, NULL, #0x20  ; true
    // 0x8332a8: tbnz            w0, #4, #0x8333f0
    // 0x8332ac: ldur            x1, [fp, #-8]
    // 0x8332b0: LoadField: r0 = r1->field_f
    //     0x8332b0: ldur            w0, [x1, #0xf]
    // 0x8332b4: DecompressPointer r0
    //     0x8332b4: add             x0, x0, HEAP, lsl #32
    // 0x8332b8: LoadField: r2 = r0->field_b
    //     0x8332b8: ldur            w2, [x0, #0xb]
    // 0x8332bc: DecompressPointer r2
    //     0x8332bc: add             x2, x2, HEAP, lsl #32
    // 0x8332c0: cmp             w2, NULL
    // 0x8332c4: b.eq            #0x833558
    // 0x8332c8: LoadField: r0 = r2->field_f
    //     0x8332c8: ldur            w0, [x2, #0xf]
    // 0x8332cc: DecompressPointer r0
    //     0x8332cc: add             x0, x0, HEAP, lsl #32
    // 0x8332d0: r2 = LoadClassIdInstr(r0)
    //     0x8332d0: ldur            x2, [x0, #-1]
    //     0x8332d4: ubfx            x2, x2, #0xc, #0x14
    // 0x8332d8: ldr             x16, [fp, #0x10]
    // 0x8332dc: stp             x16, x0, [SP, #-0x10]!
    // 0x8332e0: mov             x0, x2
    // 0x8332e4: r0 = GDT[cid_x0 + -0xd83]()
    //     0x8332e4: sub             lr, x0, #0xd83
    //     0x8332e8: ldr             lr, [x21, lr, lsl #3]
    //     0x8332ec: blr             lr
    // 0x8332f0: add             SP, SP, #0x10
    // 0x8332f4: mov             x3, x0
    // 0x8332f8: r2 = Null
    //     0x8332f8: mov             x2, NULL
    // 0x8332fc: r1 = Null
    //     0x8332fc: mov             x1, NULL
    // 0x833300: stur            x3, [fp, #-0x10]
    // 0x833304: r8 = PreferredSizeWidget
    //     0x833304: add             x8, PP, #0x37, lsl #12  ; [pp+0x37f20] Type: PreferredSizeWidget
    //     0x833308: ldr             x8, [x8, #0xf20]
    // 0x83330c: r3 = Null
    //     0x83330c: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4bf70] Null
    //     0x833310: ldr             x3, [x3, #0xf70]
    // 0x833314: r0 = PreferredSizeWidget()
    //     0x833314: bl              #0x7a03a0  ; IsType_PreferredSizeWidget_Stub
    // 0x833318: ldur            x0, [fp, #-8]
    // 0x83331c: LoadField: r1 = r0->field_f
    //     0x83331c: ldur            w1, [x0, #0xf]
    // 0x833320: DecompressPointer r1
    //     0x833320: add             x1, x1, HEAP, lsl #32
    // 0x833324: LoadField: r2 = r1->field_b
    //     0x833324: ldur            w2, [x1, #0xb]
    // 0x833328: DecompressPointer r2
    //     0x833328: add             x2, x2, HEAP, lsl #32
    // 0x83332c: cmp             w2, NULL
    // 0x833330: b.eq            #0x83355c
    // 0x833334: SaveReg r2
    //     0x833334: str             x2, [SP, #-8]!
    // 0x833338: r0 = tabHasTextAndIcon()
    //     0x833338: bl              #0x833578  ; [package:extended_tabs/src/tab_bar.dart] ExtendedTabBar::tabHasTextAndIcon
    // 0x83333c: add             SP, SP, #8
    // 0x833340: tbnz            w0, #4, #0x8333e8
    // 0x833344: ldur            x0, [fp, #-0x10]
    // 0x833348: r1 = LoadClassIdInstr(r0)
    //     0x833348: ldur            x1, [x0, #-1]
    //     0x83334c: ubfx            x1, x1, #0xc, #0x14
    // 0x833350: SaveReg r0
    //     0x833350: str             x0, [SP, #-8]!
    // 0x833354: mov             x0, x1
    // 0x833358: r0 = GDT[cid_x0 + -0xf31]()
    //     0x833358: sub             lr, x0, #0xf31
    //     0x83335c: ldr             lr, [x21, lr, lsl #3]
    //     0x833360: blr             lr
    // 0x833364: add             SP, SP, #8
    // 0x833368: LoadField: d0 = r0->field_f
    //     0x833368: ldur            d0, [x0, #0xf]
    // 0x83336c: d1 = 46.000000
    //     0x83336c: add             x17, PP, #0x23, lsl #12  ; [pp+0x239f8] IMM: double(46) from 0x4047000000000000
    //     0x833370: ldr             d1, [x17, #0x9f8]
    // 0x833374: fcmp            d0, d1
    // 0x833378: b.vs            #0x8333e8
    // 0x83337c: b.ne            #0x8333e8
    // 0x833380: ldur            x1, [fp, #-8]
    // 0x833384: LoadField: r0 = r1->field_f
    //     0x833384: ldur            w0, [x1, #0xf]
    // 0x833388: DecompressPointer r0
    //     0x833388: add             x0, x0, HEAP, lsl #32
    // 0x83338c: LoadField: r2 = r0->field_b
    //     0x83338c: ldur            w2, [x0, #0xb]
    // 0x833390: DecompressPointer r2
    //     0x833390: add             x2, x2, HEAP, lsl #32
    // 0x833394: cmp             w2, NULL
    // 0x833398: b.eq            #0x833560
    // 0x83339c: LoadField: r0 = r1->field_13
    //     0x83339c: ldur            w0, [x1, #0x13]
    // 0x8333a0: DecompressPointer r0
    //     0x8333a0: add             x0, x0, HEAP, lsl #32
    // 0x8333a4: LoadField: r2 = r0->field_1b
    //     0x8333a4: ldur            w2, [x0, #0x1b]
    // 0x8333a8: DecompressPointer r2
    //     0x8333a8: add             x2, x2, HEAP, lsl #32
    // 0x8333ac: cmp             w2, NULL
    // 0x8333b0: b.eq            #0x8333dc
    // 0x8333b4: r0 = LoadClassIdInstr(r2)
    //     0x8333b4: ldur            x0, [x2, #-1]
    //     0x8333b8: ubfx            x0, x0, #0xc, #0x14
    // 0x8333bc: r16 = Instance_EdgeInsets
    //     0x8333bc: add             x16, PP, #0x37, lsl #12  ; [pp+0x37f38] Obj!EdgeInsets@b35c61
    //     0x8333c0: ldr             x16, [x16, #0xf38]
    // 0x8333c4: stp             x16, x2, [SP, #-0x10]!
    // 0x8333c8: r0 = GDT[cid_x0 + -0xfcc]()
    //     0x8333c8: sub             lr, x0, #0xfcc
    //     0x8333cc: ldr             lr, [x21, lr, lsl #3]
    //     0x8333d0: blr             lr
    // 0x8333d4: add             SP, SP, #0x10
    // 0x8333d8: b               #0x8333f4
    // 0x8333dc: r0 = Instance_EdgeInsets
    //     0x8333dc: add             x0, PP, #0x37, lsl #12  ; [pp+0x37f40] Obj!EdgeInsets@b35c31
    //     0x8333e0: ldr             x0, [x0, #0xf40]
    // 0x8333e4: b               #0x8333f4
    // 0x8333e8: r0 = Null
    //     0x8333e8: mov             x0, NULL
    // 0x8333ec: b               #0x8333f4
    // 0x8333f0: r0 = Null
    //     0x8333f0: mov             x0, NULL
    // 0x8333f4: cmp             w0, NULL
    // 0x8333f8: b.ne            #0x833420
    // 0x8333fc: ldur            x1, [fp, #-8]
    // 0x833400: LoadField: r0 = r1->field_f
    //     0x833400: ldur            w0, [x1, #0xf]
    // 0x833404: DecompressPointer r0
    //     0x833404: add             x0, x0, HEAP, lsl #32
    // 0x833408: LoadField: r2 = r0->field_b
    //     0x833408: ldur            w2, [x0, #0xb]
    // 0x83340c: DecompressPointer r2
    //     0x83340c: add             x2, x2, HEAP, lsl #32
    // 0x833410: cmp             w2, NULL
    // 0x833414: b.eq            #0x833564
    // 0x833418: r0 = Null
    //     0x833418: mov             x0, NULL
    // 0x83341c: b               #0x833424
    // 0x833420: ldur            x1, [fp, #-8]
    // 0x833424: cmp             w0, NULL
    // 0x833428: b.ne            #0x833440
    // 0x83342c: LoadField: r0 = r1->field_13
    //     0x83342c: ldur            w0, [x1, #0x13]
    // 0x833430: DecompressPointer r0
    //     0x833430: add             x0, x0, HEAP, lsl #32
    // 0x833434: LoadField: r2 = r0->field_1b
    //     0x833434: ldur            w2, [x0, #0x1b]
    // 0x833438: DecompressPointer r2
    //     0x833438: add             x2, x2, HEAP, lsl #32
    // 0x83343c: mov             x0, x2
    // 0x833440: cmp             w0, NULL
    // 0x833444: b.ne            #0x833454
    // 0x833448: r2 = Instance_EdgeInsets
    //     0x833448: add             x2, PP, #0xe, lsl #12  ; [pp+0xe438] Obj!EdgeInsets@b35c01
    //     0x83344c: ldr             x2, [x2, #0x438]
    // 0x833450: b               #0x833458
    // 0x833454: mov             x2, x0
    // 0x833458: stur            x2, [fp, #-0x10]
    // 0x83345c: LoadField: r0 = r1->field_f
    //     0x83345c: ldur            w0, [x1, #0xf]
    // 0x833460: DecompressPointer r0
    //     0x833460: add             x0, x0, HEAP, lsl #32
    // 0x833464: LoadField: r3 = r0->field_27
    //     0x833464: ldur            w3, [x0, #0x27]
    // 0x833468: DecompressPointer r3
    //     0x833468: add             x3, x3, HEAP, lsl #32
    // 0x83346c: r16 = Sentinel
    //     0x83346c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x833470: cmp             w3, w16
    // 0x833474: b.eq            #0x833568
    // 0x833478: r0 = LoadClassIdInstr(r3)
    //     0x833478: ldur            x0, [x3, #-1]
    //     0x83347c: ubfx            x0, x0, #0xc, #0x14
    // 0x833480: ldr             x16, [fp, #0x10]
    // 0x833484: stp             x16, x3, [SP, #-0x10]!
    // 0x833488: r0 = GDT[cid_x0 + -0xd83]()
    //     0x833488: sub             lr, x0, #0xd83
    //     0x83348c: ldr             lr, [x21, lr, lsl #3]
    //     0x833490: blr             lr
    // 0x833494: add             SP, SP, #0x10
    // 0x833498: mov             x1, x0
    // 0x83349c: ldur            x0, [fp, #-8]
    // 0x8334a0: stur            x1, [fp, #-0x18]
    // 0x8334a4: LoadField: r2 = r0->field_f
    //     0x8334a4: ldur            w2, [x0, #0xf]
    // 0x8334a8: DecompressPointer r2
    //     0x8334a8: add             x2, x2, HEAP, lsl #32
    // 0x8334ac: LoadField: r0 = r2->field_b
    //     0x8334ac: ldur            w0, [x2, #0xb]
    // 0x8334b0: DecompressPointer r0
    //     0x8334b0: add             x0, x0, HEAP, lsl #32
    // 0x8334b4: cmp             w0, NULL
    // 0x8334b8: b.eq            #0x833574
    // 0x8334bc: LoadField: r2 = r0->field_f
    //     0x8334bc: ldur            w2, [x0, #0xf]
    // 0x8334c0: DecompressPointer r2
    //     0x8334c0: add             x2, x2, HEAP, lsl #32
    // 0x8334c4: r0 = LoadClassIdInstr(r2)
    //     0x8334c4: ldur            x0, [x2, #-1]
    //     0x8334c8: ubfx            x0, x0, #0xc, #0x14
    // 0x8334cc: ldr             x16, [fp, #0x10]
    // 0x8334d0: stp             x16, x2, [SP, #-0x10]!
    // 0x8334d4: r0 = GDT[cid_x0 + -0xd83]()
    //     0x8334d4: sub             lr, x0, #0xd83
    //     0x8334d8: ldr             lr, [x21, lr, lsl #3]
    //     0x8334dc: blr             lr
    // 0x8334e0: add             SP, SP, #0x10
    // 0x8334e4: stur            x0, [fp, #-8]
    // 0x8334e8: r0 = KeyedSubtree()
    //     0x8334e8: bl              #0x7a1550  ; AllocateKeyedSubtreeStub -> KeyedSubtree (size=0x10)
    // 0x8334ec: mov             x1, x0
    // 0x8334f0: ldur            x0, [fp, #-8]
    // 0x8334f4: stur            x1, [fp, #-0x20]
    // 0x8334f8: StoreField: r1->field_b = r0
    //     0x8334f8: stur            w0, [x1, #0xb]
    // 0x8334fc: ldur            x0, [fp, #-0x18]
    // 0x833500: StoreField: r1->field_7 = r0
    //     0x833500: stur            w0, [x1, #7]
    // 0x833504: r0 = Padding()
    //     0x833504: bl              #0x822c3c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x833508: mov             x1, x0
    // 0x83350c: ldur            x0, [fp, #-0x10]
    // 0x833510: stur            x1, [fp, #-8]
    // 0x833514: StoreField: r1->field_f = r0
    //     0x833514: stur            w0, [x1, #0xf]
    // 0x833518: ldur            x0, [fp, #-0x20]
    // 0x83351c: StoreField: r1->field_b = r0
    //     0x83351c: stur            w0, [x1, #0xb]
    // 0x833520: r0 = Center()
    //     0x833520: bl              #0x826060  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x833524: r1 = Instance_Alignment
    //     0x833524: add             x1, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x833528: ldr             x1, [x1, #0xc70]
    // 0x83352c: StoreField: r0->field_f = r1
    //     0x83352c: stur            w1, [x0, #0xf]
    // 0x833530: r1 = 1.000000
    //     0x833530: ldr             x1, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x833534: StoreField: r0->field_17 = r1
    //     0x833534: stur            w1, [x0, #0x17]
    // 0x833538: ldur            x1, [fp, #-8]
    // 0x83353c: StoreField: r0->field_b = r1
    //     0x83353c: stur            w1, [x0, #0xb]
    // 0x833540: LeaveFrame
    //     0x833540: mov             SP, fp
    //     0x833544: ldp             fp, lr, [SP], #0x10
    // 0x833548: ret
    //     0x833548: ret             
    // 0x83354c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83354c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x833550: b               #0x8331c0
    // 0x833554: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x833554: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x833558: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x833558: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83355c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83355c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x833560: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x833560: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x833564: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x833564: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x833568: r9 = _tabKeys
    //     0x833568: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4bf80] Field <_ExtendedTabBarState@468487081._tabKeys@468487081>: late (offset: 0x28)
    //     0x83356c: ldr             x9, [x9, #0xf80]
    // 0x833570: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x833570: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x833574: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x833574: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d67e0, size: 0xb8
    // 0x9d67e0: EnterFrame
    //     0x9d67e0: stp             fp, lr, [SP, #-0x10]!
    //     0x9d67e4: mov             fp, SP
    // 0x9d67e8: AllocStack(0x8)
    //     0x9d67e8: sub             SP, SP, #8
    // 0x9d67ec: CheckStackOverflow
    //     0x9d67ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d67f0: cmp             SP, x16
    //     0x9d67f4: b.ls            #0x9d688c
    // 0x9d67f8: ldr             x0, [fp, #0x10]
    // 0x9d67fc: LoadField: r1 = r0->field_b
    //     0x9d67fc: ldur            w1, [x0, #0xb]
    // 0x9d6800: DecompressPointer r1
    //     0x9d6800: add             x1, x1, HEAP, lsl #32
    // 0x9d6804: cmp             w1, NULL
    // 0x9d6808: b.eq            #0x9d6894
    // 0x9d680c: LoadField: r3 = r1->field_f
    //     0x9d680c: ldur            w3, [x1, #0xf]
    // 0x9d6810: DecompressPointer r3
    //     0x9d6810: add             x3, x3, HEAP, lsl #32
    // 0x9d6814: stur            x3, [fp, #-8]
    // 0x9d6818: r1 = Function '<anonymous closure>':.
    //     0x9d6818: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c000] AnonymousClosure: (0x9d6898), in [package:flutter/src/material/tabs.dart] _TabBarState::initState (0x9dbd30)
    //     0x9d681c: ldr             x1, [x1]
    // 0x9d6820: r2 = Null
    //     0x9d6820: mov             x2, NULL
    // 0x9d6824: r0 = AllocateClosure()
    //     0x9d6824: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d6828: r16 = <GlobalKey<State<StatefulWidget>>>
    //     0x9d6828: add             x16, PP, #0x37, lsl #12  ; [pp+0x37fb0] TypeArguments: <GlobalKey<State<StatefulWidget>>>
    //     0x9d682c: ldr             x16, [x16, #0xfb0]
    // 0x9d6830: ldur            lr, [fp, #-8]
    // 0x9d6834: stp             lr, x16, [SP, #-0x10]!
    // 0x9d6838: SaveReg r0
    //     0x9d6838: str             x0, [SP, #-8]!
    // 0x9d683c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9d683c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9d6840: r0 = map()
    //     0x9d6840: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0x9d6844: add             SP, SP, #0x18
    // 0x9d6848: SaveReg r0
    //     0x9d6848: str             x0, [SP, #-8]!
    // 0x9d684c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9d684c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9d6850: r0 = toList()
    //     0x9d6850: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0x9d6854: add             SP, SP, #8
    // 0x9d6858: ldr             x1, [fp, #0x10]
    // 0x9d685c: StoreField: r1->field_27 = r0
    //     0x9d685c: stur            w0, [x1, #0x27]
    //     0x9d6860: tbz             w0, #0, #0x9d687c
    //     0x9d6864: ldurb           w16, [x1, #-1]
    //     0x9d6868: ldurb           w17, [x0, #-1]
    //     0x9d686c: and             x16, x17, x16, lsr #2
    //     0x9d6870: tst             x16, HEAP, lsr #32
    //     0x9d6874: b.eq            #0x9d687c
    //     0x9d6878: bl              #0xd6826c
    // 0x9d687c: r0 = Null
    //     0x9d687c: mov             x0, NULL
    // 0x9d6880: LeaveFrame
    //     0x9d6880: mov             SP, fp
    //     0x9d6884: ldp             fp, lr, [SP], #0x10
    // 0x9d6888: ret
    //     0x9d6888: ret             
    // 0x9d688c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d688c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d6890: b               #0x9d67f8
    // 0x9d6894: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d6894: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a2e8, size: 0x18
    // 0xa4a2e8: r4 = 7
    //     0xa4a2e8: mov             x4, #7
    // 0xa4a2ec: r1 = Function 'dispose':.
    //     0xa4a2ec: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4bf28] AnonymousClosure: (0xa4a300), in [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::dispose (0xa4f7d8)
    //     0xa4a2f0: ldr             x1, [x17, #0xf28]
    // 0xa4a2f4: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a2f4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a2f8: LoadField: r0 = r24->field_17
    //     0xa4a2f8: ldur            x0, [x24, #0x17]
    // 0xa4a2fc: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a300, size: 0x48
    // 0xa4a300: EnterFrame
    //     0xa4a300: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a304: mov             fp, SP
    // 0xa4a308: ldr             x0, [fp, #0x10]
    // 0xa4a30c: LoadField: r1 = r0->field_17
    //     0xa4a30c: ldur            w1, [x0, #0x17]
    // 0xa4a310: DecompressPointer r1
    //     0xa4a310: add             x1, x1, HEAP, lsl #32
    // 0xa4a314: CheckStackOverflow
    //     0xa4a314: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a318: cmp             SP, x16
    //     0xa4a31c: b.ls            #0xa4a340
    // 0xa4a320: LoadField: r0 = r1->field_f
    //     0xa4a320: ldur            w0, [x1, #0xf]
    // 0xa4a324: DecompressPointer r0
    //     0xa4a324: add             x0, x0, HEAP, lsl #32
    // 0xa4a328: SaveReg r0
    //     0xa4a328: str             x0, [SP, #-8]!
    // 0xa4a32c: r0 = dispose()
    //     0xa4a32c: bl              #0xa4f7d8  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::dispose
    // 0xa4a330: add             SP, SP, #8
    // 0xa4a334: LeaveFrame
    //     0xa4a334: mov             SP, fp
    //     0xa4a338: ldp             fp, lr, [SP], #0x10
    // 0xa4a33c: ret
    //     0xa4a33c: ret             
    // 0xa4a340: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a340: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a344: b               #0xa4a320
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4f7d8, size: 0x138
    // 0xa4f7d8: EnterFrame
    //     0xa4f7d8: stp             fp, lr, [SP, #-0x10]!
    //     0xa4f7dc: mov             fp, SP
    // 0xa4f7e0: AllocStack(0x8)
    //     0xa4f7e0: sub             SP, SP, #8
    // 0xa4f7e4: CheckStackOverflow
    //     0xa4f7e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4f7e8: cmp             SP, x16
    //     0xa4f7ec: b.ls            #0xa4f8f8
    // 0xa4f7f0: ldr             x0, [fp, #0x10]
    // 0xa4f7f4: LoadField: r1 = r0->field_1b
    //     0xa4f7f4: ldur            w1, [x0, #0x1b]
    // 0xa4f7f8: DecompressPointer r1
    //     0xa4f7f8: add             x1, x1, HEAP, lsl #32
    // 0xa4f7fc: cmp             w1, NULL
    // 0xa4f800: b.eq            #0xa4f900
    // 0xa4f804: SaveReg r1
    //     0xa4f804: str             x1, [SP, #-8]!
    // 0xa4f808: r0 = dispose()
    //     0xa4f808: bl              #0xa4f910  ; [package:extended_tabs/src/tab_bar.dart] _IndicatorPainter::dispose
    // 0xa4f80c: add             SP, SP, #8
    // 0xa4f810: ldr             x16, [fp, #0x10]
    // 0xa4f814: SaveReg r16
    //     0xa4f814: str             x16, [SP, #-8]!
    // 0xa4f818: r0 = _controllerIsValid()
    //     0xa4f818: bl              #0x79f3ec  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_controllerIsValid
    // 0xa4f81c: add             SP, SP, #8
    // 0xa4f820: tbnz            w0, #4, #0xa4f8e0
    // 0xa4f824: ldr             x0, [fp, #0x10]
    // 0xa4f828: LoadField: r1 = r0->field_17
    //     0xa4f828: ldur            w1, [x0, #0x17]
    // 0xa4f82c: DecompressPointer r1
    //     0xa4f82c: add             x1, x1, HEAP, lsl #32
    // 0xa4f830: cmp             w1, NULL
    // 0xa4f834: b.eq            #0xa4f904
    // 0xa4f838: LoadField: r2 = r1->field_23
    //     0xa4f838: ldur            w2, [x1, #0x23]
    // 0xa4f83c: DecompressPointer r2
    //     0xa4f83c: add             x2, x2, HEAP, lsl #32
    // 0xa4f840: cmp             w2, NULL
    // 0xa4f844: b.ne            #0xa4f850
    // 0xa4f848: r1 = Null
    //     0xa4f848: mov             x1, NULL
    // 0xa4f84c: b               #0xa4f854
    // 0xa4f850: mov             x1, x2
    // 0xa4f854: stur            x1, [fp, #-8]
    // 0xa4f858: cmp             w1, NULL
    // 0xa4f85c: b.eq            #0xa4f908
    // 0xa4f860: r1 = 1
    //     0xa4f860: mov             x1, #1
    // 0xa4f864: r0 = AllocateContext()
    //     0xa4f864: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa4f868: mov             x1, x0
    // 0xa4f86c: ldr             x0, [fp, #0x10]
    // 0xa4f870: StoreField: r1->field_f = r0
    //     0xa4f870: stur            w0, [x1, #0xf]
    // 0xa4f874: mov             x2, x1
    // 0xa4f878: r1 = Function '_handleTabControllerAnimationTick@468487081':.
    //     0xa4f878: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bfa0] AnonymousClosure: (0x79fc28), in [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_handleTabControllerAnimationTick (0x79fc70)
    //     0xa4f87c: ldr             x1, [x1, #0xfa0]
    // 0xa4f880: r0 = AllocateClosure()
    //     0xa4f880: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa4f884: ldur            x16, [fp, #-8]
    // 0xa4f888: stp             x0, x16, [SP, #-0x10]!
    // 0xa4f88c: r0 = removeListener()
    //     0xa4f88c: bl              #0x6f5e30  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::removeListener
    // 0xa4f890: add             SP, SP, #0x10
    // 0xa4f894: ldr             x0, [fp, #0x10]
    // 0xa4f898: LoadField: r1 = r0->field_17
    //     0xa4f898: ldur            w1, [x0, #0x17]
    // 0xa4f89c: DecompressPointer r1
    //     0xa4f89c: add             x1, x1, HEAP, lsl #32
    // 0xa4f8a0: stur            x1, [fp, #-8]
    // 0xa4f8a4: cmp             w1, NULL
    // 0xa4f8a8: b.eq            #0xa4f90c
    // 0xa4f8ac: r1 = 1
    //     0xa4f8ac: mov             x1, #1
    // 0xa4f8b0: r0 = AllocateContext()
    //     0xa4f8b0: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa4f8b4: mov             x1, x0
    // 0xa4f8b8: ldr             x0, [fp, #0x10]
    // 0xa4f8bc: StoreField: r1->field_f = r0
    //     0xa4f8bc: stur            w0, [x1, #0xf]
    // 0xa4f8c0: mov             x2, x1
    // 0xa4f8c4: r1 = Function '_handleTabControllerTick@468487081':.
    //     0xa4f8c4: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bfa8] AnonymousClosure: (0x79f6c4), in [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_handleTabControllerTick (0x79f70c)
    //     0xa4f8c8: ldr             x1, [x1, #0xfa8]
    // 0xa4f8cc: r0 = AllocateClosure()
    //     0xa4f8cc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa4f8d0: ldur            x16, [fp, #-8]
    // 0xa4f8d4: stp             x0, x16, [SP, #-0x10]!
    // 0xa4f8d8: r0 = removeListener()
    //     0xa4f8d8: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa4f8dc: add             SP, SP, #0x10
    // 0xa4f8e0: ldr             x1, [fp, #0x10]
    // 0xa4f8e4: StoreField: r1->field_17 = rNULL
    //     0xa4f8e4: stur            NULL, [x1, #0x17]
    // 0xa4f8e8: r0 = Null
    //     0xa4f8e8: mov             x0, NULL
    // 0xa4f8ec: LeaveFrame
    //     0xa4f8ec: mov             SP, fp
    //     0xa4f8f0: ldp             fp, lr, [SP], #0x10
    // 0xa4f8f4: ret
    //     0xa4f8f4: ret             
    // 0xa4f8f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4f8f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4f8fc: b               #0xa4f7f0
    // 0xa4f900: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa4f900: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa4f904: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa4f904: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa4f908: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa4f908: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa4f90c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa4f90c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xa604b4, size: 0x4c
    // 0xa604b4: EnterFrame
    //     0xa604b4: stp             fp, lr, [SP, #-0x10]!
    //     0xa604b8: mov             fp, SP
    // 0xa604bc: CheckStackOverflow
    //     0xa604bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa604c0: cmp             SP, x16
    //     0xa604c4: b.ls            #0xa604f8
    // 0xa604c8: ldr             x16, [fp, #0x10]
    // 0xa604cc: SaveReg r16
    //     0xa604cc: str             x16, [SP, #-8]!
    // 0xa604d0: r0 = _updateTabController()
    //     0xa604d0: bl              #0x79f430  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_updateTabController
    // 0xa604d4: add             SP, SP, #8
    // 0xa604d8: ldr             x16, [fp, #0x10]
    // 0xa604dc: SaveReg r16
    //     0xa604dc: str             x16, [SP, #-8]!
    // 0xa604e0: r0 = _initIndicatorPainter()
    //     0xa604e0: bl              #0x79f070  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_initIndicatorPainter
    // 0xa604e4: add             SP, SP, #8
    // 0xa604e8: r0 = Null
    //     0xa604e8: mov             x0, NULL
    // 0xa604ec: LeaveFrame
    //     0xa604ec: mov             SP, fp
    //     0xa604f0: ldp             fp, lr, [SP], #0x10
    // 0xa604f4: ret
    //     0xa604f4: ret             
    // 0xa604f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa604f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa604fc: b               #0xa604c8
  }
  _ _initialScrollOffset(/* No info */) {
    // ** addr: 0xc73ee4, size: 0x54
    // 0xc73ee4: EnterFrame
    //     0xc73ee4: stp             fp, lr, [SP, #-0x10]!
    //     0xc73ee8: mov             fp, SP
    // 0xc73eec: CheckStackOverflow
    //     0xc73eec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc73ef0: cmp             SP, x16
    //     0xc73ef4: b.ls            #0xc73f30
    // 0xc73ef8: ldr             x0, [fp, #0x28]
    // 0xc73efc: LoadField: r1 = r0->field_1f
    //     0xc73efc: ldur            w1, [x0, #0x1f]
    // 0xc73f00: DecompressPointer r1
    //     0xc73f00: add             x1, x1, HEAP, lsl #32
    // 0xc73f04: stp             x1, x0, [SP, #-0x10]!
    // 0xc73f08: ldr             x16, [fp, #0x20]
    // 0xc73f0c: ldr             lr, [fp, #0x18]
    // 0xc73f10: stp             lr, x16, [SP, #-0x10]!
    // 0xc73f14: ldr             d0, [fp, #0x10]
    // 0xc73f18: SaveReg d0
    //     0xc73f18: str             d0, [SP, #-8]!
    // 0xc73f1c: r0 = _tabScrollOffset()
    //     0xc73f1c: bl              #0x79f998  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_tabScrollOffset
    // 0xc73f20: add             SP, SP, #0x28
    // 0xc73f24: LeaveFrame
    //     0xc73f24: mov             SP, fp
    //     0xc73f28: ldp             fp, lr, [SP], #0x10
    // 0xc73f2c: ret
    //     0xc73f2c: ret             
    // 0xc73f30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc73f30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc73f34: b               #0xc73ef8
  }
}

// class id: 3589, size: 0x34, field offset: 0x30
class _TabLabelBar extends Flex {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0x6dd8e0, size: 0xac
    // 0x6dd8e0: EnterFrame
    //     0x6dd8e0: stp             fp, lr, [SP, #-0x10]!
    //     0x6dd8e4: mov             fp, SP
    // 0x6dd8e8: CheckStackOverflow
    //     0x6dd8e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6dd8ec: cmp             SP, x16
    //     0x6dd8f0: b.ls            #0x6dd984
    // 0x6dd8f4: ldr             x0, [fp, #0x10]
    // 0x6dd8f8: r2 = Null
    //     0x6dd8f8: mov             x2, NULL
    // 0x6dd8fc: r1 = Null
    //     0x6dd8fc: mov             x1, NULL
    // 0x6dd900: r4 = 59
    //     0x6dd900: mov             x4, #0x3b
    // 0x6dd904: branchIfSmi(r0, 0x6dd910)
    //     0x6dd904: tbz             w0, #0, #0x6dd910
    // 0x6dd908: r4 = LoadClassIdInstr(r0)
    //     0x6dd908: ldur            x4, [x0, #-1]
    //     0x6dd90c: ubfx            x4, x4, #0xc, #0x14
    // 0x6dd910: cmp             x4, #0x9ef
    // 0x6dd914: b.eq            #0x6dd92c
    // 0x6dd918: r8 = _TabLabelBarRenderer
    //     0x6dd918: add             x8, PP, #0x51, lsl #12  ; [pp+0x51160] Type: _TabLabelBarRenderer
    //     0x6dd91c: ldr             x8, [x8, #0x160]
    // 0x6dd920: r3 = Null
    //     0x6dd920: add             x3, PP, #0x51, lsl #12  ; [pp+0x51168] Null
    //     0x6dd924: ldr             x3, [x3, #0x168]
    // 0x6dd928: r0 = DefaultTypeTest()
    //     0x6dd928: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6dd92c: ldr             x16, [fp, #0x20]
    // 0x6dd930: ldr             lr, [fp, #0x18]
    // 0x6dd934: stp             lr, x16, [SP, #-0x10]!
    // 0x6dd938: ldr             x16, [fp, #0x10]
    // 0x6dd93c: SaveReg r16
    //     0x6dd93c: str             x16, [SP, #-8]!
    // 0x6dd940: r0 = updateRenderObject()
    //     0x6dd940: bl              #0x6dda38  ; [package:flutter/src/widgets/basic.dart] Flex::updateRenderObject
    // 0x6dd944: add             SP, SP, #0x18
    // 0x6dd948: ldr             x1, [fp, #0x20]
    // 0x6dd94c: LoadField: r0 = r1->field_2f
    //     0x6dd94c: ldur            w0, [x1, #0x2f]
    // 0x6dd950: DecompressPointer r0
    //     0x6dd950: add             x0, x0, HEAP, lsl #32
    // 0x6dd954: ldr             x1, [fp, #0x10]
    // 0x6dd958: StoreField: r1->field_9f = r0
    //     0x6dd958: stur            w0, [x1, #0x9f]
    //     0x6dd95c: ldurb           w16, [x1, #-1]
    //     0x6dd960: ldurb           w17, [x0, #-1]
    //     0x6dd964: and             x16, x17, x16, lsr #2
    //     0x6dd968: tst             x16, HEAP, lsr #32
    //     0x6dd96c: b.eq            #0x6dd974
    //     0x6dd970: bl              #0xd6826c
    // 0x6dd974: r0 = Null
    //     0x6dd974: mov             x0, NULL
    // 0x6dd978: LeaveFrame
    //     0x6dd978: mov             SP, fp
    //     0x6dd97c: ldp             fp, lr, [SP], #0x10
    // 0x6dd980: ret
    //     0x6dd980: ret             
    // 0x6dd984: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6dd984: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6dd988: b               #0x6dd8f4
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x6f289c, size: 0xe0
    // 0x6f289c: EnterFrame
    //     0x6f289c: stp             fp, lr, [SP, #-0x10]!
    //     0x6f28a0: mov             fp, SP
    // 0x6f28a4: AllocStack(0x38)
    //     0x6f28a4: sub             SP, SP, #0x38
    // 0x6f28a8: CheckStackOverflow
    //     0x6f28a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f28ac: cmp             SP, x16
    //     0x6f28b0: b.ls            #0x6f296c
    // 0x6f28b4: ldr             x0, [fp, #0x18]
    // 0x6f28b8: LoadField: r1 = r0->field_f
    //     0x6f28b8: ldur            w1, [x0, #0xf]
    // 0x6f28bc: DecompressPointer r1
    //     0x6f28bc: add             x1, x1, HEAP, lsl #32
    // 0x6f28c0: stur            x1, [fp, #-0x20]
    // 0x6f28c4: LoadField: r2 = r0->field_13
    //     0x6f28c4: ldur            w2, [x0, #0x13]
    // 0x6f28c8: DecompressPointer r2
    //     0x6f28c8: add             x2, x2, HEAP, lsl #32
    // 0x6f28cc: stur            x2, [fp, #-0x18]
    // 0x6f28d0: LoadField: r3 = r0->field_17
    //     0x6f28d0: ldur            w3, [x0, #0x17]
    // 0x6f28d4: DecompressPointer r3
    //     0x6f28d4: add             x3, x3, HEAP, lsl #32
    // 0x6f28d8: stur            x3, [fp, #-0x10]
    // 0x6f28dc: LoadField: r4 = r0->field_1b
    //     0x6f28dc: ldur            w4, [x0, #0x1b]
    // 0x6f28e0: DecompressPointer r4
    //     0x6f28e0: add             x4, x4, HEAP, lsl #32
    // 0x6f28e4: stur            x4, [fp, #-8]
    // 0x6f28e8: ldr             x16, [fp, #0x10]
    // 0x6f28ec: stp             x16, x0, [SP, #-0x10]!
    // 0x6f28f0: r0 = getEffectiveTextDirection()
    //     0x6f28f0: bl              #0x6ddc60  ; [package:flutter/src/widgets/basic.dart] Flex::getEffectiveTextDirection
    // 0x6f28f4: add             SP, SP, #0x10
    // 0x6f28f8: stur            x0, [fp, #-0x30]
    // 0x6f28fc: cmp             w0, NULL
    // 0x6f2900: b.eq            #0x6f2974
    // 0x6f2904: ldr             x1, [fp, #0x18]
    // 0x6f2908: LoadField: r2 = r1->field_2f
    //     0x6f2908: ldur            w2, [x1, #0x2f]
    // 0x6f290c: DecompressPointer r2
    //     0x6f290c: add             x2, x2, HEAP, lsl #32
    // 0x6f2910: stur            x2, [fp, #-0x28]
    // 0x6f2914: cmp             w2, NULL
    // 0x6f2918: b.eq            #0x6f2978
    // 0x6f291c: r0 = _TabLabelBarRenderer()
    //     0x6f291c: bl              #0x6f2c48  ; Allocate_TabLabelBarRendererStub -> _TabLabelBarRenderer (size=0xa4)
    // 0x6f2920: mov             x1, x0
    // 0x6f2924: ldur            x0, [fp, #-0x28]
    // 0x6f2928: stur            x1, [fp, #-0x38]
    // 0x6f292c: StoreField: r1->field_9f = r0
    //     0x6f292c: stur            w0, [x1, #0x9f]
    // 0x6f2930: ldur            x16, [fp, #-8]
    // 0x6f2934: stp             x16, x1, [SP, #-0x10]!
    // 0x6f2938: ldur            x16, [fp, #-0x20]
    // 0x6f293c: ldur            lr, [fp, #-0x18]
    // 0x6f2940: stp             lr, x16, [SP, #-0x10]!
    // 0x6f2944: ldur            x16, [fp, #-0x10]
    // 0x6f2948: ldur            lr, [fp, #-0x30]
    // 0x6f294c: stp             lr, x16, [SP, #-0x10]!
    // 0x6f2950: r4 = const [0, 0x6, 0x6, 0x6, null]
    //     0x6f2950: ldr             x4, [PP, #0x1228]  ; [pp+0x1228] List(5) [0, 0x6, 0x6, 0x6, Null]
    // 0x6f2954: r0 = RenderFlex()
    //     0x6f2954: bl              #0x6f297c  ; [package:flutter/src/rendering/flex.dart] RenderFlex::RenderFlex
    // 0x6f2958: add             SP, SP, #0x30
    // 0x6f295c: ldur            x0, [fp, #-0x38]
    // 0x6f2960: LeaveFrame
    //     0x6f2960: mov             SP, fp
    //     0x6f2964: ldp             fp, lr, [SP], #0x10
    // 0x6f2968: ret
    //     0x6f2968: ret             
    // 0x6f296c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f296c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f2970: b               #0x6f28b4
    // 0x6f2974: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6f2974: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6f2978: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6f2978: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _TabLabelBar(/* No info */) {
    // ** addr: 0x832e40, size: 0x8c
    // 0x832e40: EnterFrame
    //     0x832e40: stp             fp, lr, [SP, #-0x10]!
    //     0x832e44: mov             fp, SP
    // 0x832e48: CheckStackOverflow
    //     0x832e48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x832e4c: cmp             SP, x16
    //     0x832e50: b.ls            #0x832ec4
    // 0x832e54: ldr             x0, [fp, #0x10]
    // 0x832e58: ldr             x1, [fp, #0x20]
    // 0x832e5c: StoreField: r1->field_2f = r0
    //     0x832e5c: stur            w0, [x1, #0x2f]
    //     0x832e60: ldurb           w16, [x1, #-1]
    //     0x832e64: ldurb           w17, [x0, #-1]
    //     0x832e68: and             x16, x17, x16, lsr #2
    //     0x832e6c: tst             x16, HEAP, lsr #32
    //     0x832e70: b.eq            #0x832e78
    //     0x832e74: bl              #0xd6826c
    // 0x832e78: ldr             x16, [fp, #0x18]
    // 0x832e7c: stp             x16, x1, [SP, #-0x10]!
    // 0x832e80: r16 = Instance_CrossAxisAlignment
    //     0x832e80: add             x16, PP, #0xe, lsl #12  ; [pp+0xeed8] Obj!CrossAxisAlignment@b64a71
    //     0x832e84: ldr             x16, [x16, #0xed8]
    // 0x832e88: r30 = Instance_Axis
    //     0x832e88: add             lr, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x832e8c: ldr             lr, [lr, #0x440]
    // 0x832e90: stp             lr, x16, [SP, #-0x10]!
    // 0x832e94: r16 = Instance_MainAxisAlignment
    //     0x832e94: add             x16, PP, #0xe, lsl #12  ; [pp+0xeee8] Obj!MainAxisAlignment@b64b31
    //     0x832e98: ldr             x16, [x16, #0xee8]
    // 0x832e9c: r30 = Instance_MainAxisSize
    //     0x832e9c: add             lr, PP, #0xe, lsl #12  ; [pp+0xeef8] Obj!MainAxisSize@b64b51
    //     0x832ea0: ldr             lr, [lr, #0xef8]
    // 0x832ea4: stp             lr, x16, [SP, #-0x10]!
    // 0x832ea8: r4 = const [0, 0x6, 0x6, 0x6, null]
    //     0x832ea8: ldr             x4, [PP, #0x1228]  ; [pp+0x1228] List(5) [0, 0x6, 0x6, 0x6, Null]
    // 0x832eac: r0 = Flex()
    //     0x832eac: bl              #0x8234ec  ; [package:flutter/src/widgets/basic.dart] Flex::Flex
    // 0x832eb0: add             SP, SP, #0x30
    // 0x832eb4: r0 = Null
    //     0x832eb4: mov             x0, NULL
    // 0x832eb8: LeaveFrame
    //     0x832eb8: mov             SP, fp
    //     0x832ebc: ldp             fp, lr, [SP], #0x10
    // 0x832ec0: ret
    //     0x832ec0: ret             
    // 0x832ec4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x832ec4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x832ec8: b               #0x832e54
  }
}

// class id: 4191, size: 0x70, field offset: 0xc
//   const constructor, 
class ExtendedTabBar extends StatefulWidget
    implements PreferredSizeWidget {

  get _ tabHasTextAndIcon(/* No info */) {
    // ** addr: 0x833578, size: 0x1c4
    // 0x833578: EnterFrame
    //     0x833578: stp             fp, lr, [SP, #-0x10]!
    //     0x83357c: mov             fp, SP
    // 0x833580: AllocStack(0x10)
    //     0x833580: sub             SP, SP, #0x10
    // 0x833584: CheckStackOverflow
    //     0x833584: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x833588: cmp             SP, x16
    //     0x83358c: b.ls            #0x83372c
    // 0x833590: ldr             x0, [fp, #0x10]
    // 0x833594: LoadField: r1 = r0->field_f
    //     0x833594: ldur            w1, [x0, #0xf]
    // 0x833598: DecompressPointer r1
    //     0x833598: add             x1, x1, HEAP, lsl #32
    // 0x83359c: r0 = LoadClassIdInstr(r1)
    //     0x83359c: ldur            x0, [x1, #-1]
    //     0x8335a0: ubfx            x0, x0, #0xc, #0x14
    // 0x8335a4: SaveReg r1
    //     0x8335a4: str             x1, [SP, #-8]!
    // 0x8335a8: r0 = GDT[cid_x0 + 0xb940]()
    //     0x8335a8: mov             x17, #0xb940
    //     0x8335ac: add             lr, x0, x17
    //     0x8335b0: ldr             lr, [x21, lr, lsl #3]
    //     0x8335b4: blr             lr
    // 0x8335b8: add             SP, SP, #8
    // 0x8335bc: mov             x1, x0
    // 0x8335c0: stur            x1, [fp, #-8]
    // 0x8335c4: CheckStackOverflow
    //     0x8335c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8335c8: cmp             SP, x16
    //     0x8335cc: b.ls            #0x833734
    // 0x8335d0: r0 = LoadClassIdInstr(r1)
    //     0x8335d0: ldur            x0, [x1, #-1]
    //     0x8335d4: ubfx            x0, x0, #0xc, #0x14
    // 0x8335d8: SaveReg r1
    //     0x8335d8: str             x1, [SP, #-8]!
    // 0x8335dc: r0 = GDT[cid_x0 + 0x541]()
    //     0x8335dc: add             lr, x0, #0x541
    //     0x8335e0: ldr             lr, [x21, lr, lsl #3]
    //     0x8335e4: blr             lr
    // 0x8335e8: add             SP, SP, #8
    // 0x8335ec: tbnz            w0, #4, #0x83371c
    // 0x8335f0: ldur            x1, [fp, #-8]
    // 0x8335f4: r0 = LoadClassIdInstr(r1)
    //     0x8335f4: ldur            x0, [x1, #-1]
    //     0x8335f8: ubfx            x0, x0, #0xc, #0x14
    // 0x8335fc: SaveReg r1
    //     0x8335fc: str             x1, [SP, #-8]!
    // 0x833600: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x833600: add             lr, x0, #0x5ca
    //     0x833604: ldr             lr, [x21, lr, lsl #3]
    //     0x833608: blr             lr
    // 0x83360c: add             SP, SP, #8
    // 0x833610: mov             x3, x0
    // 0x833614: r2 = Null
    //     0x833614: mov             x2, NULL
    // 0x833618: r1 = Null
    //     0x833618: mov             x1, NULL
    // 0x83361c: stur            x3, [fp, #-0x10]
    // 0x833620: cmp             w0, NULL
    // 0x833624: b.eq            #0x8336b0
    // 0x833628: branchIfSmi(r0, 0x8336b0)
    //     0x833628: tbz             w0, #0, #0x8336b0
    // 0x83362c: r3 = LoadClassIdInstr(r0)
    //     0x83362c: ldur            x3, [x0, #-1]
    //     0x833630: ubfx            x3, x3, #0xc, #0x14
    // 0x833634: r4 = LoadClassIdInstr(r0)
    //     0x833634: ldur            x4, [x0, #-1]
    //     0x833638: ubfx            x4, x4, #0xc, #0x14
    // 0x83363c: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0x833640: ldr             x3, [x3, #0x18]
    // 0x833644: ldr             x3, [x3, x4, lsl #3]
    // 0x833648: LoadField: r3 = r3->field_2b
    //     0x833648: ldur            w3, [x3, #0x2b]
    // 0x83364c: DecompressPointer r3
    //     0x83364c: add             x3, x3, HEAP, lsl #32
    // 0x833650: cmp             w3, NULL
    // 0x833654: b.eq            #0x8336b0
    // 0x833658: LoadField: r3 = r3->field_f
    //     0x833658: ldur            w3, [x3, #0xf]
    // 0x83365c: lsr             x3, x3, #4
    // 0x833660: r17 = 4450
    //     0x833660: mov             x17, #0x1162
    // 0x833664: cmp             x3, x17
    // 0x833668: b.eq            #0x8336b8
    // 0x83366c: r3 = SubtypeTestCache
    //     0x83366c: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4bf88] SubtypeTestCache
    //     0x833670: ldr             x3, [x3, #0xf88]
    // 0x833674: r24 = Subtype1TestCacheStub
    //     0x833674: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0x833678: LoadField: r30 = r24->field_7
    //     0x833678: ldur            lr, [x24, #7]
    // 0x83367c: blr             lr
    // 0x833680: cmp             w7, NULL
    // 0x833684: b.eq            #0x833690
    // 0x833688: tbnz            w7, #4, #0x8336b0
    // 0x83368c: b               #0x8336b8
    // 0x833690: r8 = PreferredSizeWidget
    //     0x833690: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4bf90] Type: PreferredSizeWidget
    //     0x833694: ldr             x8, [x8, #0xf90]
    // 0x833698: r3 = SubtypeTestCache
    //     0x833698: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4bf98] SubtypeTestCache
    //     0x83369c: ldr             x3, [x3, #0xf98]
    // 0x8336a0: r24 = InstanceOfStub
    //     0x8336a0: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x8336a4: LoadField: r30 = r24->field_7
    //     0x8336a4: ldur            lr, [x24, #7]
    // 0x8336a8: blr             lr
    // 0x8336ac: b               #0x8336bc
    // 0x8336b0: r0 = false
    //     0x8336b0: add             x0, NULL, #0x30  ; false
    // 0x8336b4: b               #0x8336bc
    // 0x8336b8: r0 = true
    //     0x8336b8: add             x0, NULL, #0x20  ; true
    // 0x8336bc: tbnz            w0, #4, #0x83370c
    // 0x8336c0: ldur            x0, [fp, #-0x10]
    // 0x8336c4: r1 = LoadClassIdInstr(r0)
    //     0x8336c4: ldur            x1, [x0, #-1]
    //     0x8336c8: ubfx            x1, x1, #0xc, #0x14
    // 0x8336cc: SaveReg r0
    //     0x8336cc: str             x0, [SP, #-8]!
    // 0x8336d0: mov             x0, x1
    // 0x8336d4: r0 = GDT[cid_x0 + -0xf31]()
    //     0x8336d4: sub             lr, x0, #0xf31
    //     0x8336d8: ldr             lr, [x21, lr, lsl #3]
    //     0x8336dc: blr             lr
    // 0x8336e0: add             SP, SP, #8
    // 0x8336e4: LoadField: d0 = r0->field_f
    //     0x8336e4: ldur            d0, [x0, #0xf]
    // 0x8336e8: d1 = 72.000000
    //     0x8336e8: add             x17, PP, #0x26, lsl #12  ; [pp+0x26db0] IMM: double(72) from 0x4052000000000000
    //     0x8336ec: ldr             d1, [x17, #0xdb0]
    // 0x8336f0: fcmp            d0, d1
    // 0x8336f4: b.vs            #0x833714
    // 0x8336f8: b.ne            #0x833714
    // 0x8336fc: r0 = true
    //     0x8336fc: add             x0, NULL, #0x20  ; true
    // 0x833700: LeaveFrame
    //     0x833700: mov             SP, fp
    //     0x833704: ldp             fp, lr, [SP], #0x10
    // 0x833708: ret
    //     0x833708: ret             
    // 0x83370c: d1 = 72.000000
    //     0x83370c: add             x17, PP, #0x26, lsl #12  ; [pp+0x26db0] IMM: double(72) from 0x4052000000000000
    //     0x833710: ldr             d1, [x17, #0xdb0]
    // 0x833714: ldur            x1, [fp, #-8]
    // 0x833718: b               #0x8335c4
    // 0x83371c: r0 = false
    //     0x83371c: add             x0, NULL, #0x30  ; false
    // 0x833720: LeaveFrame
    //     0x833720: mov             SP, fp
    //     0x833724: ldp             fp, lr, [SP], #0x10
    // 0x833728: ret
    //     0x833728: ret             
    // 0x83372c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83372c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x833730: b               #0x833590
    // 0x833734: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x833734: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x833738: b               #0x8335d0
  }
  _ createState(/* No info */) {
    // ** addr: 0xa3f7cc, size: 0x2c
    // 0xa3f7cc: EnterFrame
    //     0xa3f7cc: stp             fp, lr, [SP, #-0x10]!
    //     0xa3f7d0: mov             fp, SP
    // 0xa3f7d4: r1 = <ExtendedTabBar>
    //     0xa3f7d4: add             x1, PP, #0x40, lsl #12  ; [pp+0x40d28] TypeArguments: <ExtendedTabBar>
    //     0xa3f7d8: ldr             x1, [x1, #0xd28]
    // 0xa3f7dc: r0 = _ExtendedTabBarState()
    //     0xa3f7dc: bl              #0xa3f7f8  ; Allocate_ExtendedTabBarStateStub -> _ExtendedTabBarState (size=0x2c)
    // 0xa3f7e0: r1 = Sentinel
    //     0xa3f7e0: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa3f7e4: StoreField: r0->field_23 = r1
    //     0xa3f7e4: stur            w1, [x0, #0x23]
    // 0xa3f7e8: StoreField: r0->field_27 = r1
    //     0xa3f7e8: stur            w1, [x0, #0x27]
    // 0xa3f7ec: LeaveFrame
    //     0xa3f7ec: mov             SP, fp
    //     0xa3f7f0: ldp             fp, lr, [SP], #0x10
    // 0xa3f7f4: ret
    //     0xa3f7f4: ret             
  }
  get _ preferredSize(/* No info */) {
    // ** addr: 0xcb954c, size: 0x230
    // 0xcb954c: EnterFrame
    //     0xcb954c: stp             fp, lr, [SP, #-0x10]!
    //     0xcb9550: mov             fp, SP
    // 0xcb9554: AllocStack(0x20)
    //     0xcb9554: sub             SP, SP, #0x20
    // 0xcb9558: CheckStackOverflow
    //     0xcb9558: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb955c: cmp             SP, x16
    //     0xcb9560: b.ls            #0xcb976c
    // 0xcb9564: ldr             x0, [fp, #0x10]
    // 0xcb9568: LoadField: r1 = r0->field_f
    //     0xcb9568: ldur            w1, [x0, #0xf]
    // 0xcb956c: DecompressPointer r1
    //     0xcb956c: add             x1, x1, HEAP, lsl #32
    // 0xcb9570: r0 = LoadClassIdInstr(r1)
    //     0xcb9570: ldur            x0, [x1, #-1]
    //     0xcb9574: ubfx            x0, x0, #0xc, #0x14
    // 0xcb9578: SaveReg r1
    //     0xcb9578: str             x1, [SP, #-8]!
    // 0xcb957c: r0 = GDT[cid_x0 + 0xb940]()
    //     0xcb957c: mov             x17, #0xb940
    //     0xcb9580: add             lr, x0, x17
    //     0xcb9584: ldr             lr, [x21, lr, lsl #3]
    //     0xcb9588: blr             lr
    // 0xcb958c: add             SP, SP, #8
    // 0xcb9590: mov             x1, x0
    // 0xcb9594: stur            x1, [fp, #-8]
    // 0xcb9598: d0 = 46.000000
    //     0xcb9598: add             x17, PP, #0x23, lsl #12  ; [pp+0x239f8] IMM: double(46) from 0x4047000000000000
    //     0xcb959c: ldr             d0, [x17, #0x9f8]
    // 0xcb95a0: stur            d0, [fp, #-0x18]
    // 0xcb95a4: CheckStackOverflow
    //     0xcb95a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb95a8: cmp             SP, x16
    //     0xcb95ac: b.ls            #0xcb9774
    // 0xcb95b0: r0 = LoadClassIdInstr(r1)
    //     0xcb95b0: ldur            x0, [x1, #-1]
    //     0xcb95b4: ubfx            x0, x0, #0xc, #0x14
    // 0xcb95b8: SaveReg r1
    //     0xcb95b8: str             x1, [SP, #-8]!
    // 0xcb95bc: r0 = GDT[cid_x0 + 0x541]()
    //     0xcb95bc: add             lr, x0, #0x541
    //     0xcb95c0: ldr             lr, [x21, lr, lsl #3]
    //     0xcb95c4: blr             lr
    // 0xcb95c8: add             SP, SP, #8
    // 0xcb95cc: tbnz            w0, #4, #0xcb973c
    // 0xcb95d0: ldur            x1, [fp, #-8]
    // 0xcb95d4: r0 = LoadClassIdInstr(r1)
    //     0xcb95d4: ldur            x0, [x1, #-1]
    //     0xcb95d8: ubfx            x0, x0, #0xc, #0x14
    // 0xcb95dc: SaveReg r1
    //     0xcb95dc: str             x1, [SP, #-8]!
    // 0xcb95e0: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xcb95e0: add             lr, x0, #0x5ca
    //     0xcb95e4: ldr             lr, [x21, lr, lsl #3]
    //     0xcb95e8: blr             lr
    // 0xcb95ec: add             SP, SP, #8
    // 0xcb95f0: mov             x3, x0
    // 0xcb95f4: r2 = Null
    //     0xcb95f4: mov             x2, NULL
    // 0xcb95f8: r1 = Null
    //     0xcb95f8: mov             x1, NULL
    // 0xcb95fc: stur            x3, [fp, #-0x10]
    // 0xcb9600: cmp             w0, NULL
    // 0xcb9604: b.eq            #0xcb9690
    // 0xcb9608: branchIfSmi(r0, 0xcb9690)
    //     0xcb9608: tbz             w0, #0, #0xcb9690
    // 0xcb960c: r3 = LoadClassIdInstr(r0)
    //     0xcb960c: ldur            x3, [x0, #-1]
    //     0xcb9610: ubfx            x3, x3, #0xc, #0x14
    // 0xcb9614: r4 = LoadClassIdInstr(r0)
    //     0xcb9614: ldur            x4, [x0, #-1]
    //     0xcb9618: ubfx            x4, x4, #0xc, #0x14
    // 0xcb961c: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xcb9620: ldr             x3, [x3, #0x18]
    // 0xcb9624: ldr             x3, [x3, x4, lsl #3]
    // 0xcb9628: LoadField: r3 = r3->field_2b
    //     0xcb9628: ldur            w3, [x3, #0x2b]
    // 0xcb962c: DecompressPointer r3
    //     0xcb962c: add             x3, x3, HEAP, lsl #32
    // 0xcb9630: cmp             w3, NULL
    // 0xcb9634: b.eq            #0xcb9690
    // 0xcb9638: LoadField: r3 = r3->field_f
    //     0xcb9638: ldur            w3, [x3, #0xf]
    // 0xcb963c: lsr             x3, x3, #4
    // 0xcb9640: r17 = 4450
    //     0xcb9640: mov             x17, #0x1162
    // 0xcb9644: cmp             x3, x17
    // 0xcb9648: b.eq            #0xcb9698
    // 0xcb964c: r3 = SubtypeTestCache
    //     0xcb964c: add             x3, PP, #0x40, lsl #12  ; [pp+0x40d30] SubtypeTestCache
    //     0xcb9650: ldr             x3, [x3, #0xd30]
    // 0xcb9654: r24 = Subtype1TestCacheStub
    //     0xcb9654: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xcb9658: LoadField: r30 = r24->field_7
    //     0xcb9658: ldur            lr, [x24, #7]
    // 0xcb965c: blr             lr
    // 0xcb9660: cmp             w7, NULL
    // 0xcb9664: b.eq            #0xcb9670
    // 0xcb9668: tbnz            w7, #4, #0xcb9690
    // 0xcb966c: b               #0xcb9698
    // 0xcb9670: r8 = PreferredSizeWidget
    //     0xcb9670: add             x8, PP, #0x40, lsl #12  ; [pp+0x40d38] Type: PreferredSizeWidget
    //     0xcb9674: ldr             x8, [x8, #0xd38]
    // 0xcb9678: r3 = SubtypeTestCache
    //     0xcb9678: add             x3, PP, #0x40, lsl #12  ; [pp+0x40d40] SubtypeTestCache
    //     0xcb967c: ldr             x3, [x3, #0xd40]
    // 0xcb9680: r24 = InstanceOfStub
    //     0xcb9680: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xcb9684: LoadField: r30 = r24->field_7
    //     0xcb9684: ldur            lr, [x24, #7]
    // 0xcb9688: blr             lr
    // 0xcb968c: b               #0xcb969c
    // 0xcb9690: r0 = false
    //     0xcb9690: add             x0, NULL, #0x30  ; false
    // 0xcb9694: b               #0xcb969c
    // 0xcb9698: r0 = true
    //     0xcb9698: add             x0, NULL, #0x20  ; true
    // 0xcb969c: tbnz            w0, #4, #0xcb9728
    // 0xcb96a0: ldur            d0, [fp, #-0x18]
    // 0xcb96a4: ldur            x0, [fp, #-0x10]
    // 0xcb96a8: r1 = LoadClassIdInstr(r0)
    //     0xcb96a8: ldur            x1, [x0, #-1]
    //     0xcb96ac: ubfx            x1, x1, #0xc, #0x14
    // 0xcb96b0: SaveReg r0
    //     0xcb96b0: str             x0, [SP, #-8]!
    // 0xcb96b4: mov             x0, x1
    // 0xcb96b8: r0 = GDT[cid_x0 + -0xf31]()
    //     0xcb96b8: sub             lr, x0, #0xf31
    //     0xcb96bc: ldr             lr, [x21, lr, lsl #3]
    //     0xcb96c0: blr             lr
    // 0xcb96c4: add             SP, SP, #8
    // 0xcb96c8: LoadField: d0 = r0->field_f
    //     0xcb96c8: ldur            d0, [x0, #0xf]
    // 0xcb96cc: ldur            d1, [fp, #-0x18]
    // 0xcb96d0: fcmp            d0, d1
    // 0xcb96d4: b.vs            #0xcb96e4
    // 0xcb96d8: b.le            #0xcb96e4
    // 0xcb96dc: d2 = 0.000000
    //     0xcb96dc: eor             v2.16b, v2.16b, v2.16b
    // 0xcb96e0: b               #0xcb9734
    // 0xcb96e4: fcmp            d0, d1
    // 0xcb96e8: b.vs            #0xcb96fc
    // 0xcb96ec: b.ge            #0xcb96fc
    // 0xcb96f0: mov             v0.16b, v1.16b
    // 0xcb96f4: d2 = 0.000000
    //     0xcb96f4: eor             v2.16b, v2.16b, v2.16b
    // 0xcb96f8: b               #0xcb9734
    // 0xcb96fc: d2 = 0.000000
    //     0xcb96fc: eor             v2.16b, v2.16b, v2.16b
    // 0xcb9700: fcmp            d0, d2
    // 0xcb9704: b.vs            #0xcb9718
    // 0xcb9708: b.ne            #0xcb9718
    // 0xcb970c: fadd            d3, d0, d1
    // 0xcb9710: mov             v0.16b, v3.16b
    // 0xcb9714: b               #0xcb9734
    // 0xcb9718: fcmp            d1, d1
    // 0xcb971c: b.vc            #0xcb9734
    // 0xcb9720: mov             v0.16b, v1.16b
    // 0xcb9724: b               #0xcb9734
    // 0xcb9728: ldur            d1, [fp, #-0x18]
    // 0xcb972c: d2 = 0.000000
    //     0xcb972c: eor             v2.16b, v2.16b, v2.16b
    // 0xcb9730: mov             v0.16b, v1.16b
    // 0xcb9734: ldur            x1, [fp, #-8]
    // 0xcb9738: b               #0xcb95a0
    // 0xcb973c: ldur            d1, [fp, #-0x18]
    // 0xcb9740: d0 = 2.000000
    //     0xcb9740: fmov            d0, #2.00000000
    // 0xcb9744: fadd            d2, d1, d0
    // 0xcb9748: stur            d2, [fp, #-0x20]
    // 0xcb974c: r0 = Size()
    //     0xcb974c: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xcb9750: d0 = inf
    //     0xcb9750: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xcb9754: StoreField: r0->field_7 = d0
    //     0xcb9754: stur            d0, [x0, #7]
    // 0xcb9758: ldur            d0, [fp, #-0x20]
    // 0xcb975c: StoreField: r0->field_f = d0
    //     0xcb975c: stur            d0, [x0, #0xf]
    // 0xcb9760: LeaveFrame
    //     0xcb9760: mov             SP, fp
    //     0xcb9764: ldp             fp, lr, [SP], #0x10
    // 0xcb9768: ret
    //     0xcb9768: ret             
    // 0xcb976c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb976c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb9770: b               #0xcb9564
    // 0xcb9774: r0 = StackOverflowSharedWithFPURegs()
    //     0xcb9774: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcb9778: b               #0xcb95b0
  }
}

// class id: 4202, size: 0x28, field offset: 0x10
//   const constructor, 
class _TabStyle extends AnimatedWidget {

  _ build(/* No info */) {
    // ** addr: 0xaeb0a8, size: 0x3c4
    // 0xaeb0a8: EnterFrame
    //     0xaeb0a8: stp             fp, lr, [SP, #-0x10]!
    //     0xaeb0ac: mov             fp, SP
    // 0xaeb0b0: AllocStack(0x30)
    //     0xaeb0b0: sub             SP, SP, #0x30
    // 0xaeb0b4: CheckStackOverflow
    //     0xaeb0b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaeb0b8: cmp             SP, x16
    //     0xaeb0bc: b.ls            #0xaeb450
    // 0xaeb0c0: ldr             x16, [fp, #0x10]
    // 0xaeb0c4: SaveReg r16
    //     0xaeb0c4: str             x16, [SP, #-8]!
    // 0xaeb0c8: r0 = of()
    //     0xaeb0c8: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xaeb0cc: add             SP, SP, #8
    // 0xaeb0d0: stur            x0, [fp, #-8]
    // 0xaeb0d4: ldr             x16, [fp, #0x10]
    // 0xaeb0d8: SaveReg r16
    //     0xaeb0d8: str             x16, [SP, #-8]!
    // 0xaeb0dc: r0 = of()
    //     0xaeb0dc: bl              #0x79f3a4  ; [package:flutter/src/material/tab_bar_theme.dart] TabBarTheme::of
    // 0xaeb0e0: add             SP, SP, #8
    // 0xaeb0e4: mov             x4, x0
    // 0xaeb0e8: ldr             x3, [fp, #0x18]
    // 0xaeb0ec: stur            x4, [fp, #-0x18]
    // 0xaeb0f0: LoadField: r5 = r3->field_b
    //     0xaeb0f0: ldur            w5, [x3, #0xb]
    // 0xaeb0f4: DecompressPointer r5
    //     0xaeb0f4: add             x5, x5, HEAP, lsl #32
    // 0xaeb0f8: mov             x0, x5
    // 0xaeb0fc: stur            x5, [fp, #-0x10]
    // 0xaeb100: r2 = Null
    //     0xaeb100: mov             x2, NULL
    // 0xaeb104: r1 = Null
    //     0xaeb104: mov             x1, NULL
    // 0xaeb108: r8 = Animation<double>
    //     0xaeb108: add             x8, PP, #0x2a, lsl #12  ; [pp+0x2aab0] Type: Animation<double>
    //     0xaeb10c: ldr             x8, [x8, #0xab0]
    // 0xaeb110: r3 = Null
    //     0xaeb110: add             x3, PP, #0x51, lsl #12  ; [pp+0x51178] Null
    //     0xaeb114: ldr             x3, [x3, #0x178]
    // 0xaeb118: r0 = Animation<double>()
    //     0xaeb118: bl              #0x5912f0  ; IsType_Animation<double>_Stub
    // 0xaeb11c: ldr             x0, [fp, #0x18]
    // 0xaeb120: LoadField: r1 = r0->field_f
    //     0xaeb120: ldur            w1, [x0, #0xf]
    // 0xaeb124: DecompressPointer r1
    //     0xaeb124: add             x1, x1, HEAP, lsl #32
    // 0xaeb128: stur            x1, [fp, #-0x20]
    // 0xaeb12c: cmp             w1, NULL
    // 0xaeb130: b.ne            #0xaeb144
    // 0xaeb134: ldur            x2, [fp, #-0x18]
    // 0xaeb138: LoadField: r3 = r2->field_1f
    //     0xaeb138: ldur            w3, [x2, #0x1f]
    // 0xaeb13c: DecompressPointer r3
    //     0xaeb13c: add             x3, x3, HEAP, lsl #32
    // 0xaeb140: b               #0xaeb14c
    // 0xaeb144: ldur            x2, [fp, #-0x18]
    // 0xaeb148: mov             x3, x1
    // 0xaeb14c: cmp             w3, NULL
    // 0xaeb150: b.ne            #0xaeb170
    // 0xaeb154: ldur            x4, [fp, #-8]
    // 0xaeb158: LoadField: r3 = r4->field_8f
    //     0xaeb158: ldur            w3, [x4, #0x8f]
    // 0xaeb15c: DecompressPointer r3
    //     0xaeb15c: add             x3, x3, HEAP, lsl #32
    // 0xaeb160: LoadField: r5 = r3->field_2b
    //     0xaeb160: ldur            w5, [x3, #0x2b]
    // 0xaeb164: DecompressPointer r5
    //     0xaeb164: add             x5, x5, HEAP, lsl #32
    // 0xaeb168: mov             x3, x5
    // 0xaeb16c: b               #0xaeb174
    // 0xaeb170: ldur            x4, [fp, #-8]
    // 0xaeb174: cmp             w3, NULL
    // 0xaeb178: b.eq            #0xaeb458
    // 0xaeb17c: r16 = true
    //     0xaeb17c: add             x16, NULL, #0x20  ; true
    // 0xaeb180: stp             x16, x3, [SP, #-0x10]!
    // 0xaeb184: r4 = const [0, 0x2, 0x2, 0x1, inherit, 0x1, null]
    //     0xaeb184: add             x4, PP, #0x40, lsl #12  ; [pp+0x40cd8] List(7) [0, 0x2, 0x2, 0x1, "inherit", 0x1, Null]
    //     0xaeb188: ldr             x4, [x4, #0xcd8]
    // 0xaeb18c: r0 = copyWith()
    //     0xaeb18c: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xaeb190: add             SP, SP, #0x10
    // 0xaeb194: mov             x1, x0
    // 0xaeb198: ldr             x0, [fp, #0x18]
    // 0xaeb19c: stur            x1, [fp, #-0x28]
    // 0xaeb1a0: LoadField: r2 = r0->field_13
    //     0xaeb1a0: ldur            w2, [x0, #0x13]
    // 0xaeb1a4: DecompressPointer r2
    //     0xaeb1a4: add             x2, x2, HEAP, lsl #32
    // 0xaeb1a8: cmp             w2, NULL
    // 0xaeb1ac: b.ne            #0xaeb1c0
    // 0xaeb1b0: ldur            x3, [fp, #-0x18]
    // 0xaeb1b4: LoadField: r2 = r3->field_27
    //     0xaeb1b4: ldur            w2, [x3, #0x27]
    // 0xaeb1b8: DecompressPointer r2
    //     0xaeb1b8: add             x2, x2, HEAP, lsl #32
    // 0xaeb1bc: b               #0xaeb1c4
    // 0xaeb1c0: ldur            x3, [fp, #-0x18]
    // 0xaeb1c4: cmp             w2, NULL
    // 0xaeb1c8: b.ne            #0xaeb1d0
    // 0xaeb1cc: ldur            x2, [fp, #-0x20]
    // 0xaeb1d0: cmp             w2, NULL
    // 0xaeb1d4: b.ne            #0xaeb1f4
    // 0xaeb1d8: ldur            x4, [fp, #-8]
    // 0xaeb1dc: LoadField: r2 = r4->field_8f
    //     0xaeb1dc: ldur            w2, [x4, #0x8f]
    // 0xaeb1e0: DecompressPointer r2
    //     0xaeb1e0: add             x2, x2, HEAP, lsl #32
    // 0xaeb1e4: LoadField: r5 = r2->field_2b
    //     0xaeb1e4: ldur            w5, [x2, #0x2b]
    // 0xaeb1e8: DecompressPointer r5
    //     0xaeb1e8: add             x5, x5, HEAP, lsl #32
    // 0xaeb1ec: mov             x2, x5
    // 0xaeb1f0: b               #0xaeb1f8
    // 0xaeb1f4: ldur            x4, [fp, #-8]
    // 0xaeb1f8: cmp             w2, NULL
    // 0xaeb1fc: b.eq            #0xaeb45c
    // 0xaeb200: r16 = true
    //     0xaeb200: add             x16, NULL, #0x20  ; true
    // 0xaeb204: stp             x16, x2, [SP, #-0x10]!
    // 0xaeb208: r4 = const [0, 0x2, 0x2, 0x1, inherit, 0x1, null]
    //     0xaeb208: add             x4, PP, #0x40, lsl #12  ; [pp+0x40cd8] List(7) [0, 0x2, 0x2, 0x1, "inherit", 0x1, Null]
    //     0xaeb20c: ldr             x4, [x4, #0xcd8]
    // 0xaeb210: r0 = copyWith()
    //     0xaeb210: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xaeb214: add             SP, SP, #0x10
    // 0xaeb218: mov             x2, x0
    // 0xaeb21c: ldr             x1, [fp, #0x18]
    // 0xaeb220: stur            x2, [fp, #-0x30]
    // 0xaeb224: LoadField: r3 = r1->field_17
    //     0xaeb224: ldur            w3, [x1, #0x17]
    // 0xaeb228: DecompressPointer r3
    //     0xaeb228: add             x3, x3, HEAP, lsl #32
    // 0xaeb22c: stur            x3, [fp, #-0x20]
    // 0xaeb230: tbnz            w3, #4, #0xaeb27c
    // 0xaeb234: ldur            x4, [fp, #-0x10]
    // 0xaeb238: r0 = LoadClassIdInstr(r4)
    //     0xaeb238: ldur            x0, [x4, #-1]
    //     0xaeb23c: ubfx            x0, x0, #0xc, #0x14
    // 0xaeb240: SaveReg r4
    //     0xaeb240: str             x4, [SP, #-8]!
    // 0xaeb244: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xaeb244: add             lr, x0, #0xb7c
    //     0xaeb248: ldr             lr, [x21, lr, lsl #3]
    //     0xaeb24c: blr             lr
    // 0xaeb250: add             SP, SP, #8
    // 0xaeb254: ldur            x16, [fp, #-0x28]
    // 0xaeb258: ldur            lr, [fp, #-0x30]
    // 0xaeb25c: stp             lr, x16, [SP, #-0x10]!
    // 0xaeb260: SaveReg r0
    //     0xaeb260: str             x0, [SP, #-8]!
    // 0xaeb264: r0 = lerp()
    //     0xaeb264: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xaeb268: add             SP, SP, #0x18
    // 0xaeb26c: cmp             w0, NULL
    // 0xaeb270: b.eq            #0xaeb460
    // 0xaeb274: mov             x2, x0
    // 0xaeb278: b               #0xaeb2c0
    // 0xaeb27c: ldur            x1, [fp, #-0x10]
    // 0xaeb280: r0 = LoadClassIdInstr(r1)
    //     0xaeb280: ldur            x0, [x1, #-1]
    //     0xaeb284: ubfx            x0, x0, #0xc, #0x14
    // 0xaeb288: SaveReg r1
    //     0xaeb288: str             x1, [SP, #-8]!
    // 0xaeb28c: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xaeb28c: add             lr, x0, #0xb7c
    //     0xaeb290: ldr             lr, [x21, lr, lsl #3]
    //     0xaeb294: blr             lr
    // 0xaeb298: add             SP, SP, #8
    // 0xaeb29c: ldur            x16, [fp, #-0x30]
    // 0xaeb2a0: ldur            lr, [fp, #-0x28]
    // 0xaeb2a4: stp             lr, x16, [SP, #-0x10]!
    // 0xaeb2a8: SaveReg r0
    //     0xaeb2a8: str             x0, [SP, #-8]!
    // 0xaeb2ac: r0 = lerp()
    //     0xaeb2ac: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xaeb2b0: add             SP, SP, #0x18
    // 0xaeb2b4: cmp             w0, NULL
    // 0xaeb2b8: b.eq            #0xaeb464
    // 0xaeb2bc: mov             x2, x0
    // 0xaeb2c0: ldr             x1, [fp, #0x18]
    // 0xaeb2c4: stur            x2, [fp, #-0x28]
    // 0xaeb2c8: LoadField: r0 = r1->field_1b
    //     0xaeb2c8: ldur            w0, [x1, #0x1b]
    // 0xaeb2cc: DecompressPointer r0
    //     0xaeb2cc: add             x0, x0, HEAP, lsl #32
    // 0xaeb2d0: cmp             w0, NULL
    // 0xaeb2d4: b.ne            #0xaeb2e8
    // 0xaeb2d8: ldur            x0, [fp, #-0x18]
    // 0xaeb2dc: LoadField: r3 = r0->field_17
    //     0xaeb2dc: ldur            w3, [x0, #0x17]
    // 0xaeb2e0: DecompressPointer r3
    //     0xaeb2e0: add             x3, x3, HEAP, lsl #32
    // 0xaeb2e4: mov             x0, x3
    // 0xaeb2e8: cmp             w0, NULL
    // 0xaeb2ec: b.ne            #0xaeb318
    // 0xaeb2f0: ldur            x0, [fp, #-8]
    // 0xaeb2f4: LoadField: r3 = r0->field_8f
    //     0xaeb2f4: ldur            w3, [x0, #0x8f]
    // 0xaeb2f8: DecompressPointer r3
    //     0xaeb2f8: add             x3, x3, HEAP, lsl #32
    // 0xaeb2fc: LoadField: r0 = r3->field_2b
    //     0xaeb2fc: ldur            w0, [x3, #0x2b]
    // 0xaeb300: DecompressPointer r0
    //     0xaeb300: add             x0, x0, HEAP, lsl #32
    // 0xaeb304: cmp             w0, NULL
    // 0xaeb308: b.eq            #0xaeb468
    // 0xaeb30c: LoadField: r3 = r0->field_b
    //     0xaeb30c: ldur            w3, [x0, #0xb]
    // 0xaeb310: DecompressPointer r3
    //     0xaeb310: add             x3, x3, HEAP, lsl #32
    // 0xaeb314: b               #0xaeb31c
    // 0xaeb318: mov             x3, x0
    // 0xaeb31c: ldur            x0, [fp, #-0x20]
    // 0xaeb320: stur            x3, [fp, #-8]
    // 0xaeb324: tbnz            w0, #4, #0xaeb370
    // 0xaeb328: ldur            x0, [fp, #-0x10]
    // 0xaeb32c: r4 = LoadClassIdInstr(r0)
    //     0xaeb32c: ldur            x4, [x0, #-1]
    //     0xaeb330: ubfx            x4, x4, #0xc, #0x14
    // 0xaeb334: SaveReg r0
    //     0xaeb334: str             x0, [SP, #-8]!
    // 0xaeb338: mov             x0, x4
    // 0xaeb33c: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xaeb33c: add             lr, x0, #0xb7c
    //     0xaeb340: ldr             lr, [x21, lr, lsl #3]
    //     0xaeb344: blr             lr
    // 0xaeb348: add             SP, SP, #8
    // 0xaeb34c: ldur            x16, [fp, #-8]
    // 0xaeb350: r30 = Instance_Color
    //     0xaeb350: add             lr, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0xaeb354: ldr             lr, [lr, #0xbe8]
    // 0xaeb358: stp             lr, x16, [SP, #-0x10]!
    // 0xaeb35c: SaveReg r0
    //     0xaeb35c: str             x0, [SP, #-8]!
    // 0xaeb360: r0 = lerp()
    //     0xaeb360: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xaeb364: add             SP, SP, #0x18
    // 0xaeb368: mov             x1, x0
    // 0xaeb36c: b               #0xaeb3b4
    // 0xaeb370: ldur            x0, [fp, #-0x10]
    // 0xaeb374: r1 = LoadClassIdInstr(r0)
    //     0xaeb374: ldur            x1, [x0, #-1]
    //     0xaeb378: ubfx            x1, x1, #0xc, #0x14
    // 0xaeb37c: SaveReg r0
    //     0xaeb37c: str             x0, [SP, #-8]!
    // 0xaeb380: mov             x0, x1
    // 0xaeb384: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xaeb384: add             lr, x0, #0xb7c
    //     0xaeb388: ldr             lr, [x21, lr, lsl #3]
    //     0xaeb38c: blr             lr
    // 0xaeb390: add             SP, SP, #8
    // 0xaeb394: r16 = Instance_Color
    //     0xaeb394: add             x16, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0xaeb398: ldr             x16, [x16, #0xbe8]
    // 0xaeb39c: ldur            lr, [fp, #-8]
    // 0xaeb3a0: stp             lr, x16, [SP, #-0x10]!
    // 0xaeb3a4: SaveReg r0
    //     0xaeb3a4: str             x0, [SP, #-8]!
    // 0xaeb3a8: r0 = lerp()
    //     0xaeb3a8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xaeb3ac: add             SP, SP, #0x18
    // 0xaeb3b0: mov             x1, x0
    // 0xaeb3b4: ldr             x0, [fp, #0x18]
    // 0xaeb3b8: stur            x1, [fp, #-8]
    // 0xaeb3bc: ldur            x16, [fp, #-0x28]
    // 0xaeb3c0: stp             x1, x16, [SP, #-0x10]!
    // 0xaeb3c4: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0xaeb3c4: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0xaeb3c8: ldr             x4, [x4, #0x168]
    // 0xaeb3cc: r0 = copyWith()
    //     0xaeb3cc: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xaeb3d0: add             SP, SP, #0x10
    // 0xaeb3d4: stur            x0, [fp, #-0x10]
    // 0xaeb3d8: r0 = IconThemeData()
    //     0xaeb3d8: bl              #0x83fd3c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x28)
    // 0xaeb3dc: mov             x1, x0
    // 0xaeb3e0: r0 = 24.000000
    //     0xaeb3e0: add             x0, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xaeb3e4: ldr             x0, [x0, #0x360]
    // 0xaeb3e8: StoreField: r1->field_7 = r0
    //     0xaeb3e8: stur            w0, [x1, #7]
    // 0xaeb3ec: ldur            x0, [fp, #-8]
    // 0xaeb3f0: StoreField: r1->field_1b = r0
    //     0xaeb3f0: stur            w0, [x1, #0x1b]
    // 0xaeb3f4: ldr             x0, [fp, #0x18]
    // 0xaeb3f8: LoadField: r2 = r0->field_23
    //     0xaeb3f8: ldur            w2, [x0, #0x23]
    // 0xaeb3fc: DecompressPointer r2
    //     0xaeb3fc: add             x2, x2, HEAP, lsl #32
    // 0xaeb400: stp             x1, x2, [SP, #-0x10]!
    // 0xaeb404: r0 = merge()
    //     0xaeb404: bl              #0x847e00  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::merge
    // 0xaeb408: add             SP, SP, #0x10
    // 0xaeb40c: stur            x0, [fp, #-8]
    // 0xaeb410: r0 = DefaultTextStyle()
    //     0xaeb410: bl              #0x83fd24  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0xaeb414: ldur            x1, [fp, #-0x10]
    // 0xaeb418: StoreField: r0->field_f = r1
    //     0xaeb418: stur            w1, [x0, #0xf]
    // 0xaeb41c: r1 = true
    //     0xaeb41c: add             x1, NULL, #0x20  ; true
    // 0xaeb420: StoreField: r0->field_17 = r1
    //     0xaeb420: stur            w1, [x0, #0x17]
    // 0xaeb424: r1 = Instance_TextOverflow
    //     0xaeb424: add             x1, PP, #0x15, lsl #12  ; [pp+0x15118] Obj!TextOverflow@b64d71
    //     0xaeb428: ldr             x1, [x1, #0x118]
    // 0xaeb42c: StoreField: r0->field_1b = r1
    //     0xaeb42c: stur            w1, [x0, #0x1b]
    // 0xaeb430: r1 = Instance_TextWidthBasis
    //     0xaeb430: add             x1, PP, #0x15, lsl #12  ; [pp+0x15148] Obj!TextWidthBasis@b64d31
    //     0xaeb434: ldr             x1, [x1, #0x148]
    // 0xaeb438: StoreField: r0->field_23 = r1
    //     0xaeb438: stur            w1, [x0, #0x23]
    // 0xaeb43c: ldur            x1, [fp, #-8]
    // 0xaeb440: StoreField: r0->field_b = r1
    //     0xaeb440: stur            w1, [x0, #0xb]
    // 0xaeb444: LeaveFrame
    //     0xaeb444: mov             SP, fp
    //     0xaeb448: ldp             fp, lr, [SP], #0x10
    // 0xaeb44c: ret
    //     0xaeb44c: ret             
    // 0xaeb450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaeb450: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaeb454: b               #0xaeb0c0
    // 0xaeb458: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaeb458: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xaeb45c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaeb45c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xaeb460: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaeb460: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xaeb464: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaeb464: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xaeb468: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaeb468: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4354, size: 0x18, field offset: 0xc
class _DragAnimation extends __ChangeAnimation&Animation&AnimationWithParentMixin {

  get _ value(/* No info */) {
    // ** addr: 0xc244ec, size: 0x188
    // 0xc244ec: EnterFrame
    //     0xc244ec: stp             fp, lr, [SP, #-0x10]!
    //     0xc244f0: mov             fp, SP
    // 0xc244f4: AllocStack(0x8)
    //     0xc244f4: sub             SP, SP, #8
    // 0xc244f8: CheckStackOverflow
    //     0xc244f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc244fc: cmp             SP, x16
    //     0xc24500: b.ls            #0xc2464c
    // 0xc24504: ldr             x2, [fp, #0x10]
    // 0xc24508: LoadField: r3 = r2->field_b
    //     0xc24508: ldur            w3, [x2, #0xb]
    // 0xc2450c: DecompressPointer r3
    //     0xc2450c: add             x3, x3, HEAP, lsl #32
    // 0xc24510: stur            x3, [fp, #-8]
    // 0xc24514: LoadField: r0 = r3->field_2b
    //     0xc24514: ldur            x0, [x3, #0x2b]
    // 0xc24518: sub             x4, x0, #1
    // 0xc2451c: r0 = BoxInt64Instr(r4)
    //     0xc2451c: sbfiz           x0, x4, #1, #0x1f
    //     0xc24520: cmp             x4, x0, asr #1
    //     0xc24524: b.eq            #0xc24530
    //     0xc24528: bl              #0xd69bb8
    //     0xc2452c: stur            x4, [x0, #7]
    // 0xc24530: stp             x0, NULL, [SP, #-0x10]!
    // 0xc24534: r0 = _Double.fromInteger()
    //     0xc24534: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0xc24538: add             SP, SP, #0x10
    // 0xc2453c: mov             x1, x0
    // 0xc24540: ldur            x0, [fp, #-8]
    // 0xc24544: LoadField: r2 = r0->field_23
    //     0xc24544: ldur            w2, [x0, #0x23]
    // 0xc24548: DecompressPointer r2
    //     0xc24548: add             x2, x2, HEAP, lsl #32
    // 0xc2454c: cmp             w2, NULL
    // 0xc24550: b.ne            #0xc24558
    // 0xc24554: r2 = Null
    //     0xc24554: mov             x2, NULL
    // 0xc24558: ldr             x0, [fp, #0x10]
    // 0xc2455c: cmp             w2, NULL
    // 0xc24560: b.eq            #0xc24654
    // 0xc24564: LoadField: r3 = r2->field_37
    //     0xc24564: ldur            w3, [x2, #0x37]
    // 0xc24568: DecompressPointer r3
    //     0xc24568: add             x3, x3, HEAP, lsl #32
    // 0xc2456c: r16 = Sentinel
    //     0xc2456c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc24570: cmp             w3, w16
    // 0xc24574: b.eq            #0xc24658
    // 0xc24578: r16 = 0.000000
    //     0xc24578: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xc2457c: stp             x16, x3, [SP, #-0x10]!
    // 0xc24580: SaveReg r1
    //     0xc24580: str             x1, [SP, #-8]!
    // 0xc24584: r0 = clamp()
    //     0xc24584: bl              #0xd66c00  ; [dart:core] _Double::clamp
    // 0xc24588: add             SP, SP, #0x18
    // 0xc2458c: mov             x2, x0
    // 0xc24590: ldr             x0, [fp, #0x10]
    // 0xc24594: stur            x2, [fp, #-8]
    // 0xc24598: LoadField: r3 = r0->field_f
    //     0xc24598: ldur            x3, [x0, #0xf]
    // 0xc2459c: r0 = BoxInt64Instr(r3)
    //     0xc2459c: sbfiz           x0, x3, #1, #0x1f
    //     0xc245a0: cmp             x3, x0, asr #1
    //     0xc245a4: b.eq            #0xc245b0
    //     0xc245a8: bl              #0xd69bb8
    //     0xc245ac: stur            x3, [x0, #7]
    // 0xc245b0: stp             x0, NULL, [SP, #-0x10]!
    // 0xc245b4: r0 = _Double.fromInteger()
    //     0xc245b4: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0xc245b8: add             SP, SP, #0x10
    // 0xc245bc: mov             x1, x0
    // 0xc245c0: ldur            x0, [fp, #-8]
    // 0xc245c4: LoadField: d0 = r0->field_7
    //     0xc245c4: ldur            d0, [x0, #7]
    // 0xc245c8: LoadField: d1 = r1->field_7
    //     0xc245c8: ldur            d1, [x1, #7]
    // 0xc245cc: fsub            d2, d0, d1
    // 0xc245d0: d0 = 0.000000
    //     0xc245d0: eor             v0.16b, v0.16b, v0.16b
    // 0xc245d4: fcmp            d2, d0
    // 0xc245d8: b.vs            #0xc245e8
    // 0xc245dc: b.ne            #0xc245e8
    // 0xc245e0: d0 = 0.000000
    //     0xc245e0: eor             v0.16b, v0.16b, v0.16b
    // 0xc245e4: b               #0xc24600
    // 0xc245e8: fcmp            d2, d0
    // 0xc245ec: b.vs            #0xc245fc
    // 0xc245f0: b.ge            #0xc245fc
    // 0xc245f4: fneg            d0, d2
    // 0xc245f8: b               #0xc24600
    // 0xc245fc: mov             v0.16b, v2.16b
    // 0xc24600: r0 = inline_Allocate_Double()
    //     0xc24600: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc24604: add             x0, x0, #0x10
    //     0xc24608: cmp             x1, x0
    //     0xc2460c: b.ls            #0xc24664
    //     0xc24610: str             x0, [THR, #0x60]  ; THR::top
    //     0xc24614: sub             x0, x0, #0xf
    //     0xc24618: mov             x1, #0xd108
    //     0xc2461c: movk            x1, #3, lsl #16
    //     0xc24620: stur            x1, [x0, #-1]
    // 0xc24624: StoreField: r0->field_7 = d0
    //     0xc24624: stur            d0, [x0, #7]
    // 0xc24628: r16 = 0.000000
    //     0xc24628: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xc2462c: stp             x16, x0, [SP, #-0x10]!
    // 0xc24630: r16 = 1.000000
    //     0xc24630: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xc24634: SaveReg r16
    //     0xc24634: str             x16, [SP, #-8]!
    // 0xc24638: r0 = clamp()
    //     0xc24638: bl              #0xd66c00  ; [dart:core] _Double::clamp
    // 0xc2463c: add             SP, SP, #0x18
    // 0xc24640: LeaveFrame
    //     0xc24640: mov             SP, fp
    //     0xc24644: ldp             fp, lr, [SP], #0x10
    // 0xc24648: ret
    //     0xc24648: ret             
    // 0xc2464c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2464c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc24650: b               #0xc24504
    // 0xc24654: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc24654: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc24658: r9 = _value
    //     0xc24658: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0xc2465c: ldr             x9, [x9, #0xbb0]
    // 0xc24660: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc24660: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc24664: SaveReg d0
    //     0xc24664: str             q0, [SP, #-0x10]!
    // 0xc24668: r0 = AllocateDouble()
    //     0xc24668: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc2466c: RestoreReg d0
    //     0xc2466c: ldr             q0, [SP], #0x10
    // 0xc24670: b               #0xc24624
  }
}

// class id: 4355, size: 0x10, field offset: 0xc
class _ChangeAnimation extends __ChangeAnimation&Animation&AnimationWithParentMixin {

  get _ value(/* No info */) {
    // ** addr: 0xc24474, size: 0x78
    // 0xc24474: EnterFrame
    //     0xc24474: stp             fp, lr, [SP, #-0x10]!
    //     0xc24478: mov             fp, SP
    // 0xc2447c: CheckStackOverflow
    //     0xc2447c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc24480: cmp             SP, x16
    //     0xc24484: b.ls            #0xc244d4
    // 0xc24488: ldr             x0, [fp, #0x10]
    // 0xc2448c: LoadField: r1 = r0->field_b
    //     0xc2448c: ldur            w1, [x0, #0xb]
    // 0xc24490: DecompressPointer r1
    //     0xc24490: add             x1, x1, HEAP, lsl #32
    // 0xc24494: SaveReg r1
    //     0xc24494: str             x1, [SP, #-8]!
    // 0xc24498: r0 = _indexChangeProgress()
    //     0xc24498: bl              #0xa6df20  ; [package:extended_tabs/src/tab_bar.dart] ::_indexChangeProgress
    // 0xc2449c: add             SP, SP, #8
    // 0xc244a0: r0 = inline_Allocate_Double()
    //     0xc244a0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc244a4: add             x0, x0, #0x10
    //     0xc244a8: cmp             x1, x0
    //     0xc244ac: b.ls            #0xc244dc
    //     0xc244b0: str             x0, [THR, #0x60]  ; THR::top
    //     0xc244b4: sub             x0, x0, #0xf
    //     0xc244b8: mov             x1, #0xd108
    //     0xc244bc: movk            x1, #3, lsl #16
    //     0xc244c0: stur            x1, [x0, #-1]
    // 0xc244c4: StoreField: r0->field_7 = d0
    //     0xc244c4: stur            d0, [x0, #7]
    // 0xc244c8: LeaveFrame
    //     0xc244c8: mov             SP, fp
    //     0xc244cc: ldp             fp, lr, [SP], #0x10
    // 0xc244d0: ret
    //     0xc244d0: ret             
    // 0xc244d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc244d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc244d8: b               #0xc24488
    // 0xc244dc: SaveReg d0
    //     0xc244dc: str             q0, [SP, #-0x10]!
    // 0xc244e0: r0 = AllocateDouble()
    //     0xc244e0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc244e4: RestoreReg d0
    //     0xc244e4: ldr             q0, [SP], #0x10
    // 0xc244e8: b               #0xc244c4
  }
}

// class id: 4380, size: 0x3c, field offset: 0xc
class _IndicatorPainter extends CustomPainter {

  late TextDirection _currentTextDirection; // offset: 0x2c

  _ _IndicatorPainter(/* No info */) {
    // ** addr: 0x79f1e4, size: 0x158
    // 0x79f1e4: EnterFrame
    //     0x79f1e4: stp             fp, lr, [SP, #-0x10]!
    //     0x79f1e8: mov             fp, SP
    // 0x79f1ec: r3 = Sentinel
    //     0x79f1ec: ldr             x3, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x79f1f0: r0 = false
    //     0x79f1f0: add             x0, NULL, #0x30  ; false
    // 0x79f1f4: r2 = Instance_EdgeInsets
    //     0x79f1f4: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0x79f1f8: ldr             x2, [x2, #0xbd8]
    // 0x79f1fc: r1 = Instance_Axis
    //     0x79f1fc: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x79f200: ldr             x1, [x1, #0x440]
    // 0x79f204: CheckStackOverflow
    //     0x79f204: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79f208: cmp             SP, x16
    //     0x79f20c: b.ls            #0x79f328
    // 0x79f210: ldr             x4, [fp, #0x38]
    // 0x79f214: StoreField: r4->field_2b = r3
    //     0x79f214: stur            w3, [x4, #0x2b]
    // 0x79f218: StoreField: r4->field_37 = r0
    //     0x79f218: stur            w0, [x4, #0x37]
    // 0x79f21c: ldr             x0, [fp, #0x30]
    // 0x79f220: StoreField: r4->field_b = r0
    //     0x79f220: stur            w0, [x4, #0xb]
    //     0x79f224: ldurb           w16, [x4, #-1]
    //     0x79f228: ldurb           w17, [x0, #-1]
    //     0x79f22c: and             x16, x17, x16, lsr #2
    //     0x79f230: tst             x16, HEAP, lsr #32
    //     0x79f234: b.eq            #0x79f23c
    //     0x79f238: bl              #0xd682cc
    // 0x79f23c: ldr             x0, [fp, #0x28]
    // 0x79f240: StoreField: r4->field_f = r0
    //     0x79f240: stur            w0, [x4, #0xf]
    //     0x79f244: ldurb           w16, [x4, #-1]
    //     0x79f248: ldurb           w17, [x0, #-1]
    //     0x79f24c: and             x16, x17, x16, lsr #2
    //     0x79f250: tst             x16, HEAP, lsr #32
    //     0x79f254: b.eq            #0x79f25c
    //     0x79f258: bl              #0xd682cc
    // 0x79f25c: ldr             x0, [fp, #0x20]
    // 0x79f260: StoreField: r4->field_13 = r0
    //     0x79f260: stur            w0, [x4, #0x13]
    //     0x79f264: ldurb           w16, [x4, #-1]
    //     0x79f268: ldurb           w17, [x0, #-1]
    //     0x79f26c: and             x16, x17, x16, lsr #2
    //     0x79f270: tst             x16, HEAP, lsr #32
    //     0x79f274: b.eq            #0x79f27c
    //     0x79f278: bl              #0xd682cc
    // 0x79f27c: ldr             x0, [fp, #0x10]
    // 0x79f280: StoreField: r4->field_17 = r0
    //     0x79f280: stur            w0, [x4, #0x17]
    //     0x79f284: ldurb           w16, [x4, #-1]
    //     0x79f288: ldurb           w17, [x0, #-1]
    //     0x79f28c: and             x16, x17, x16, lsr #2
    //     0x79f290: tst             x16, HEAP, lsr #32
    //     0x79f294: b.eq            #0x79f29c
    //     0x79f298: bl              #0xd682cc
    // 0x79f29c: StoreField: r4->field_23 = r2
    //     0x79f29c: stur            w2, [x4, #0x23]
    // 0x79f2a0: StoreField: r4->field_1b = r1
    //     0x79f2a0: stur            w1, [x4, #0x1b]
    // 0x79f2a4: ldr             x0, [fp, #0x30]
    // 0x79f2a8: LoadField: r1 = r0->field_23
    //     0x79f2a8: ldur            w1, [x0, #0x23]
    // 0x79f2ac: DecompressPointer r1
    //     0x79f2ac: add             x1, x1, HEAP, lsl #32
    // 0x79f2b0: cmp             w1, NULL
    // 0x79f2b4: b.ne            #0x79f2c0
    // 0x79f2b8: r0 = Null
    //     0x79f2b8: mov             x0, NULL
    // 0x79f2bc: b               #0x79f2c4
    // 0x79f2c0: mov             x0, x1
    // 0x79f2c4: ldr             x1, [fp, #0x18]
    // 0x79f2c8: StoreField: r4->field_7 = r0
    //     0x79f2c8: stur            w0, [x4, #7]
    //     0x79f2cc: ldurb           w16, [x4, #-1]
    //     0x79f2d0: ldurb           w17, [x0, #-1]
    //     0x79f2d4: and             x16, x17, x16, lsr #2
    //     0x79f2d8: tst             x16, HEAP, lsr #32
    //     0x79f2dc: b.eq            #0x79f2e4
    //     0x79f2e0: bl              #0xd682cc
    // 0x79f2e4: cmp             w1, NULL
    // 0x79f2e8: b.eq            #0x79f318
    // 0x79f2ec: LoadField: r0 = r1->field_27
    //     0x79f2ec: ldur            w0, [x1, #0x27]
    // 0x79f2f0: DecompressPointer r0
    //     0x79f2f0: add             x0, x0, HEAP, lsl #32
    // 0x79f2f4: LoadField: r2 = r1->field_2b
    //     0x79f2f4: ldur            w2, [x1, #0x2b]
    // 0x79f2f8: DecompressPointer r2
    //     0x79f2f8: add             x2, x2, HEAP, lsl #32
    // 0x79f2fc: r16 = Sentinel
    //     0x79f2fc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x79f300: cmp             w2, w16
    // 0x79f304: b.eq            #0x79f330
    // 0x79f308: stp             x0, x4, [SP, #-0x10]!
    // 0x79f30c: SaveReg r2
    //     0x79f30c: str             x2, [SP, #-8]!
    // 0x79f310: r0 = saveTabOffsets()
    //     0x79f310: bl              #0x79f33c  ; [package:extended_tabs/src/tab_bar.dart] _IndicatorPainter::saveTabOffsets
    // 0x79f314: add             SP, SP, #0x18
    // 0x79f318: r0 = Null
    //     0x79f318: mov             x0, NULL
    // 0x79f31c: LeaveFrame
    //     0x79f31c: mov             SP, fp
    //     0x79f320: ldp             fp, lr, [SP], #0x10
    // 0x79f324: ret
    //     0x79f324: ret             
    // 0x79f328: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79f328: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79f32c: b               #0x79f210
    // 0x79f330: r9 = _currentTextDirection
    //     0x79f330: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4bff8] Field <_IndicatorPainter@468487081._currentTextDirection@468487081>: late (offset: 0x2c)
    //     0x79f334: ldr             x9, [x9, #0xff8]
    // 0x79f338: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x79f338: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ saveTabOffsets(/* No info */) {
    // ** addr: 0x79f33c, size: 0x5c
    // 0x79f33c: EnterFrame
    //     0x79f33c: stp             fp, lr, [SP, #-0x10]!
    //     0x79f340: mov             fp, SP
    // 0x79f344: ldr             x0, [fp, #0x18]
    // 0x79f348: ldr             x1, [fp, #0x20]
    // 0x79f34c: StoreField: r1->field_27 = r0
    //     0x79f34c: stur            w0, [x1, #0x27]
    //     0x79f350: ldurb           w16, [x1, #-1]
    //     0x79f354: ldurb           w17, [x0, #-1]
    //     0x79f358: and             x16, x17, x16, lsr #2
    //     0x79f35c: tst             x16, HEAP, lsr #32
    //     0x79f360: b.eq            #0x79f368
    //     0x79f364: bl              #0xd6826c
    // 0x79f368: ldr             x0, [fp, #0x10]
    // 0x79f36c: StoreField: r1->field_2b = r0
    //     0x79f36c: stur            w0, [x1, #0x2b]
    //     0x79f370: ldurb           w16, [x1, #-1]
    //     0x79f374: ldurb           w17, [x0, #-1]
    //     0x79f378: and             x16, x17, x16, lsr #2
    //     0x79f37c: tst             x16, HEAP, lsr #32
    //     0x79f380: b.eq            #0x79f388
    //     0x79f384: bl              #0xd6826c
    // 0x79f388: r0 = Null
    //     0x79f388: mov             x0, NULL
    // 0x79f38c: LeaveFrame
    //     0x79f38c: mov             SP, fp
    //     0x79f390: ldp             fp, lr, [SP], #0x10
    // 0x79f394: ret
    //     0x79f394: ret             
  }
  _ centerOf(/* No info */) {
    // ** addr: 0x79fb34, size: 0xf4
    // 0x79fb34: EnterFrame
    //     0x79fb34: stp             fp, lr, [SP, #-0x10]!
    //     0x79fb38: mov             fp, SP
    // 0x79fb3c: AllocStack(0x8)
    //     0x79fb3c: sub             SP, SP, #8
    // 0x79fb40: CheckStackOverflow
    //     0x79fb40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79fb44: cmp             SP, x16
    //     0x79fb48: b.ls            #0x79fc18
    // 0x79fb4c: ldr             x2, [fp, #0x18]
    // 0x79fb50: LoadField: r3 = r2->field_27
    //     0x79fb50: ldur            w3, [x2, #0x27]
    // 0x79fb54: DecompressPointer r3
    //     0x79fb54: add             x3, x3, HEAP, lsl #32
    // 0x79fb58: cmp             w3, NULL
    // 0x79fb5c: b.eq            #0x79fc20
    // 0x79fb60: ldr             x4, [fp, #0x10]
    // 0x79fb64: r0 = BoxInt64Instr(r4)
    //     0x79fb64: sbfiz           x0, x4, #1, #0x1f
    //     0x79fb68: cmp             x4, x0, asr #1
    //     0x79fb6c: b.eq            #0x79fb78
    //     0x79fb70: bl              #0xd69bb8
    //     0x79fb74: stur            x4, [x0, #7]
    // 0x79fb78: r1 = LoadClassIdInstr(r3)
    //     0x79fb78: ldur            x1, [x3, #-1]
    //     0x79fb7c: ubfx            x1, x1, #0xc, #0x14
    // 0x79fb80: stp             x0, x3, [SP, #-0x10]!
    // 0x79fb84: mov             x0, x1
    // 0x79fb88: r0 = GDT[cid_x0 + -0xd83]()
    //     0x79fb88: sub             lr, x0, #0xd83
    //     0x79fb8c: ldr             lr, [x21, lr, lsl #3]
    //     0x79fb90: blr             lr
    // 0x79fb94: add             SP, SP, #0x10
    // 0x79fb98: mov             x2, x0
    // 0x79fb9c: ldr             x0, [fp, #0x18]
    // 0x79fba0: stur            x2, [fp, #-8]
    // 0x79fba4: LoadField: r3 = r0->field_27
    //     0x79fba4: ldur            w3, [x0, #0x27]
    // 0x79fba8: DecompressPointer r3
    //     0x79fba8: add             x3, x3, HEAP, lsl #32
    // 0x79fbac: cmp             w3, NULL
    // 0x79fbb0: b.eq            #0x79fc24
    // 0x79fbb4: ldr             x0, [fp, #0x10]
    // 0x79fbb8: add             x4, x0, #1
    // 0x79fbbc: r0 = BoxInt64Instr(r4)
    //     0x79fbbc: sbfiz           x0, x4, #1, #0x1f
    //     0x79fbc0: cmp             x4, x0, asr #1
    //     0x79fbc4: b.eq            #0x79fbd0
    //     0x79fbc8: bl              #0xd69bb8
    //     0x79fbcc: stur            x4, [x0, #7]
    // 0x79fbd0: r1 = LoadClassIdInstr(r3)
    //     0x79fbd0: ldur            x1, [x3, #-1]
    //     0x79fbd4: ubfx            x1, x1, #0xc, #0x14
    // 0x79fbd8: stp             x0, x3, [SP, #-0x10]!
    // 0x79fbdc: mov             x0, x1
    // 0x79fbe0: r0 = GDT[cid_x0 + -0xd83]()
    //     0x79fbe0: sub             lr, x0, #0xd83
    //     0x79fbe4: ldr             lr, [x21, lr, lsl #3]
    //     0x79fbe8: blr             lr
    // 0x79fbec: add             SP, SP, #0x10
    // 0x79fbf0: mov             x1, x0
    // 0x79fbf4: ldur            x0, [fp, #-8]
    // 0x79fbf8: LoadField: d1 = r0->field_7
    //     0x79fbf8: ldur            d1, [x0, #7]
    // 0x79fbfc: LoadField: d2 = r1->field_7
    //     0x79fbfc: ldur            d2, [x1, #7]
    // 0x79fc00: fadd            d3, d1, d2
    // 0x79fc04: d1 = 2.000000
    //     0x79fc04: fmov            d1, #2.00000000
    // 0x79fc08: fdiv            d0, d3, d1
    // 0x79fc0c: LeaveFrame
    //     0x79fc0c: mov             SP, fp
    //     0x79fc10: ldp             fp, lr, [SP], #0x10
    // 0x79fc14: ret
    //     0x79fc14: ret             
    // 0x79fc18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79fc18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79fc1c: b               #0x79fb4c
    // 0x79fc20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79fc20: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79fc24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79fc24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ maxTabIndex(/* No info */) {
    // ** addr: 0x7a0330, size: 0x70
    // 0x7a0330: EnterFrame
    //     0x7a0330: stp             fp, lr, [SP, #-0x10]!
    //     0x7a0334: mov             fp, SP
    // 0x7a0338: CheckStackOverflow
    //     0x7a0338: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a033c: cmp             SP, x16
    //     0x7a0340: b.ls            #0x7a0394
    // 0x7a0344: ldr             x0, [fp, #0x10]
    // 0x7a0348: LoadField: r1 = r0->field_27
    //     0x7a0348: ldur            w1, [x0, #0x27]
    // 0x7a034c: DecompressPointer r1
    //     0x7a034c: add             x1, x1, HEAP, lsl #32
    // 0x7a0350: cmp             w1, NULL
    // 0x7a0354: b.eq            #0x7a039c
    // 0x7a0358: r0 = LoadClassIdInstr(r1)
    //     0x7a0358: ldur            x0, [x1, #-1]
    //     0x7a035c: ubfx            x0, x0, #0xc, #0x14
    // 0x7a0360: SaveReg r1
    //     0x7a0360: str             x1, [SP, #-8]!
    // 0x7a0364: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x7a0364: mov             x17, #0xb8ea
    //     0x7a0368: add             lr, x0, x17
    //     0x7a036c: ldr             lr, [x21, lr, lsl #3]
    //     0x7a0370: blr             lr
    // 0x7a0374: add             SP, SP, #8
    // 0x7a0378: r1 = LoadInt32Instr(r0)
    //     0x7a0378: sbfx            x1, x0, #1, #0x1f
    //     0x7a037c: tbz             w0, #0, #0x7a0384
    //     0x7a0380: ldur            x1, [x0, #7]
    // 0x7a0384: sub             x0, x1, #2
    // 0x7a0388: LeaveFrame
    //     0x7a0388: mov             SP, fp
    //     0x7a038c: ldp             fp, lr, [SP], #0x10
    // 0x7a0390: ret
    //     0x7a0390: ret             
    // 0x7a0394: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a0394: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a0398: b               #0x7a0344
    // 0x7a039c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a039c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4f910, size: 0x5c
    // 0xa4f910: EnterFrame
    //     0xa4f910: stp             fp, lr, [SP, #-0x10]!
    //     0xa4f914: mov             fp, SP
    // 0xa4f918: CheckStackOverflow
    //     0xa4f918: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4f91c: cmp             SP, x16
    //     0xa4f920: b.ls            #0xa4f964
    // 0xa4f924: ldr             x0, [fp, #0x10]
    // 0xa4f928: LoadField: r1 = r0->field_33
    //     0xa4f928: ldur            w1, [x0, #0x33]
    // 0xa4f92c: DecompressPointer r1
    //     0xa4f92c: add             x1, x1, HEAP, lsl #32
    // 0xa4f930: cmp             w1, NULL
    // 0xa4f934: b.eq            #0xa4f954
    // 0xa4f938: r0 = LoadClassIdInstr(r1)
    //     0xa4f938: ldur            x0, [x1, #-1]
    //     0xa4f93c: ubfx            x0, x0, #0xc, #0x14
    // 0xa4f940: SaveReg r1
    //     0xa4f940: str             x1, [SP, #-8]!
    // 0xa4f944: r0 = GDT[cid_x0 + -0x3c5]()
    //     0xa4f944: sub             lr, x0, #0x3c5
    //     0xa4f948: ldr             lr, [x21, lr, lsl #3]
    //     0xa4f94c: blr             lr
    // 0xa4f950: add             SP, SP, #8
    // 0xa4f954: r0 = Null
    //     0xa4f954: mov             x0, NULL
    // 0xa4f958: LeaveFrame
    //     0xa4f958: mov             SP, fp
    //     0xa4f95c: ldp             fp, lr, [SP], #0x10
    // 0xa4f960: ret
    //     0xa4f960: ret             
    // 0xa4f964: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4f964: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4f968: b               #0xa4f924
  }
  _ paint(/* No info */) {
    // ** addr: 0xa6d830, size: 0x548
    // 0xa6d830: EnterFrame
    //     0xa6d830: stp             fp, lr, [SP, #-0x10]!
    //     0xa6d834: mov             fp, SP
    // 0xa6d838: AllocStack(0x38)
    //     0xa6d838: sub             SP, SP, #0x38
    // 0xa6d83c: r0 = false
    //     0xa6d83c: add             x0, NULL, #0x30  ; false
    // 0xa6d840: CheckStackOverflow
    //     0xa6d840: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6d844: cmp             SP, x16
    //     0xa6d848: b.ls            #0xa6dd44
    // 0xa6d84c: ldr             x1, [fp, #0x20]
    // 0xa6d850: StoreField: r1->field_37 = r0
    //     0xa6d850: stur            w0, [x1, #0x37]
    // 0xa6d854: LoadField: r0 = r1->field_33
    //     0xa6d854: ldur            w0, [x1, #0x33]
    // 0xa6d858: DecompressPointer r0
    //     0xa6d858: add             x0, x0, HEAP, lsl #32
    // 0xa6d85c: cmp             w0, NULL
    // 0xa6d860: b.ne            #0xa6d8dc
    // 0xa6d864: LoadField: r0 = r1->field_f
    //     0xa6d864: ldur            w0, [x1, #0xf]
    // 0xa6d868: DecompressPointer r0
    //     0xa6d868: add             x0, x0, HEAP, lsl #32
    // 0xa6d86c: stur            x0, [fp, #-8]
    // 0xa6d870: r1 = 1
    //     0xa6d870: mov             x1, #1
    // 0xa6d874: r0 = AllocateContext()
    //     0xa6d874: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa6d878: mov             x1, x0
    // 0xa6d87c: ldr             x0, [fp, #0x20]
    // 0xa6d880: StoreField: r1->field_f = r0
    //     0xa6d880: stur            w0, [x1, #0xf]
    // 0xa6d884: mov             x2, x1
    // 0xa6d888: r1 = Function 'markNeedsPaint':.
    //     0xa6d888: add             x1, PP, #0x51, lsl #12  ; [pp+0x511a0] AnonymousClosure: (0xa6e684), in [package:extended_tabs/src/tab_bar.dart] _IndicatorPainter::markNeedsPaint (0xa6e6cc)
    //     0xa6d88c: ldr             x1, [x1, #0x1a0]
    // 0xa6d890: r0 = AllocateClosure()
    //     0xa6d890: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa6d894: mov             x1, x0
    // 0xa6d898: ldur            x0, [fp, #-8]
    // 0xa6d89c: r2 = LoadClassIdInstr(r0)
    //     0xa6d89c: ldur            x2, [x0, #-1]
    //     0xa6d8a0: ubfx            x2, x2, #0xc, #0x14
    // 0xa6d8a4: stp             x1, x0, [SP, #-0x10]!
    // 0xa6d8a8: mov             x0, x2
    // 0xa6d8ac: r0 = GDT[cid_x0 + -0xc50]()
    //     0xa6d8ac: sub             lr, x0, #0xc50
    //     0xa6d8b0: ldr             lr, [x21, lr, lsl #3]
    //     0xa6d8b4: blr             lr
    // 0xa6d8b8: add             SP, SP, #0x10
    // 0xa6d8bc: ldr             x1, [fp, #0x20]
    // 0xa6d8c0: StoreField: r1->field_33 = r0
    //     0xa6d8c0: stur            w0, [x1, #0x33]
    //     0xa6d8c4: ldurb           w16, [x1, #-1]
    //     0xa6d8c8: ldurb           w17, [x0, #-1]
    //     0xa6d8cc: and             x16, x17, x16, lsr #2
    //     0xa6d8d0: tst             x16, HEAP, lsr #32
    //     0xa6d8d4: b.eq            #0xa6d8dc
    //     0xa6d8d8: bl              #0xd6826c
    // 0xa6d8dc: LoadField: r0 = r1->field_b
    //     0xa6d8dc: ldur            w0, [x1, #0xb]
    // 0xa6d8e0: DecompressPointer r0
    //     0xa6d8e0: add             x0, x0, HEAP, lsl #32
    // 0xa6d8e4: stur            x0, [fp, #-8]
    // 0xa6d8e8: LoadField: r2 = r0->field_43
    //     0xa6d8e8: ldur            x2, [x0, #0x43]
    // 0xa6d8ec: cbz             x2, #0xa6d980
    // 0xa6d8f0: LoadField: r2 = r0->field_33
    //     0xa6d8f0: ldur            x2, [x0, #0x33]
    // 0xa6d8f4: ldr             x16, [fp, #0x10]
    // 0xa6d8f8: stp             x16, x1, [SP, #-0x10]!
    // 0xa6d8fc: SaveReg r2
    //     0xa6d8fc: str             x2, [SP, #-8]!
    // 0xa6d900: r0 = indicatorRect()
    //     0xa6d900: bl              #0xa6e114  ; [package:extended_tabs/src/tab_bar.dart] _IndicatorPainter::indicatorRect
    // 0xa6d904: add             SP, SP, #0x18
    // 0xa6d908: mov             x1, x0
    // 0xa6d90c: ldr             x0, [fp, #0x20]
    // 0xa6d910: stur            x1, [fp, #-0x18]
    // 0xa6d914: LoadField: r2 = r0->field_2f
    //     0xa6d914: ldur            w2, [x0, #0x2f]
    // 0xa6d918: DecompressPointer r2
    //     0xa6d918: add             x2, x2, HEAP, lsl #32
    // 0xa6d91c: cmp             w2, NULL
    // 0xa6d920: b.ne            #0xa6d928
    // 0xa6d924: mov             x2, x1
    // 0xa6d928: stur            x2, [fp, #-0x10]
    // 0xa6d92c: ldur            x16, [fp, #-8]
    // 0xa6d930: SaveReg r16
    //     0xa6d930: str             x16, [SP, #-8]!
    // 0xa6d934: r0 = _indexChangeProgress()
    //     0xa6d934: bl              #0xa6df20  ; [package:extended_tabs/src/tab_bar.dart] ::_indexChangeProgress
    // 0xa6d938: add             SP, SP, #8
    // 0xa6d93c: ldur            x16, [fp, #-0x18]
    // 0xa6d940: ldur            lr, [fp, #-0x10]
    // 0xa6d944: stp             lr, x16, [SP, #-0x10]!
    // 0xa6d948: SaveReg d0
    //     0xa6d948: str             d0, [SP, #-8]!
    // 0xa6d94c: r0 = lerp()
    //     0xa6d94c: bl              #0xa6dd78  ; [dart:ui] Rect::lerp
    // 0xa6d950: add             SP, SP, #0x18
    // 0xa6d954: mov             x2, x0
    // 0xa6d958: ldr             x1, [fp, #0x20]
    // 0xa6d95c: StoreField: r1->field_2f = r0
    //     0xa6d95c: stur            w0, [x1, #0x2f]
    //     0xa6d960: ldurb           w16, [x1, #-1]
    //     0xa6d964: ldurb           w17, [x0, #-1]
    //     0xa6d968: and             x16, x17, x16, lsr #2
    //     0xa6d96c: tst             x16, HEAP, lsr #32
    //     0xa6d970: b.eq            #0xa6d978
    //     0xa6d974: bl              #0xd6826c
    // 0xa6d978: mov             x0, x2
    // 0xa6d97c: b               #0xa6dc64
    // 0xa6d980: LoadField: r2 = r0->field_33
    //     0xa6d980: ldur            x2, [x0, #0x33]
    // 0xa6d984: stur            x2, [fp, #-0x20]
    // 0xa6d988: cmp             x2, #0
    // 0xa6d98c: b.le            #0xa6d9b0
    // 0xa6d990: sub             x3, x2, #1
    // 0xa6d994: ldr             x16, [fp, #0x10]
    // 0xa6d998: stp             x16, x1, [SP, #-0x10]!
    // 0xa6d99c: SaveReg r3
    //     0xa6d99c: str             x3, [SP, #-8]!
    // 0xa6d9a0: r0 = indicatorRect()
    //     0xa6d9a0: bl              #0xa6e114  ; [package:extended_tabs/src/tab_bar.dart] _IndicatorPainter::indicatorRect
    // 0xa6d9a4: add             SP, SP, #0x18
    // 0xa6d9a8: mov             x2, x0
    // 0xa6d9ac: b               #0xa6d9b4
    // 0xa6d9b0: r2 = Null
    //     0xa6d9b0: mov             x2, NULL
    // 0xa6d9b4: ldr             x0, [fp, #0x20]
    // 0xa6d9b8: ldur            x1, [fp, #-0x20]
    // 0xa6d9bc: stur            x2, [fp, #-0x10]
    // 0xa6d9c0: ldr             x16, [fp, #0x10]
    // 0xa6d9c4: stp             x16, x0, [SP, #-0x10]!
    // 0xa6d9c8: SaveReg r1
    //     0xa6d9c8: str             x1, [SP, #-8]!
    // 0xa6d9cc: r0 = indicatorRect()
    //     0xa6d9cc: bl              #0xa6e114  ; [package:extended_tabs/src/tab_bar.dart] _IndicatorPainter::indicatorRect
    // 0xa6d9d0: add             SP, SP, #0x18
    // 0xa6d9d4: mov             x2, x0
    // 0xa6d9d8: ldr             x1, [fp, #0x20]
    // 0xa6d9dc: stur            x2, [fp, #-0x18]
    // 0xa6d9e0: LoadField: r0 = r1->field_27
    //     0xa6d9e0: ldur            w0, [x1, #0x27]
    // 0xa6d9e4: DecompressPointer r0
    //     0xa6d9e4: add             x0, x0, HEAP, lsl #32
    // 0xa6d9e8: cmp             w0, NULL
    // 0xa6d9ec: b.eq            #0xa6dd4c
    // 0xa6d9f0: r3 = LoadClassIdInstr(r0)
    //     0xa6d9f0: ldur            x3, [x0, #-1]
    //     0xa6d9f4: ubfx            x3, x3, #0xc, #0x14
    // 0xa6d9f8: SaveReg r0
    //     0xa6d9f8: str             x0, [SP, #-8]!
    // 0xa6d9fc: mov             x0, x3
    // 0xa6da00: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa6da00: mov             x17, #0xb8ea
    //     0xa6da04: add             lr, x0, x17
    //     0xa6da08: ldr             lr, [x21, lr, lsl #3]
    //     0xa6da0c: blr             lr
    // 0xa6da10: add             SP, SP, #8
    // 0xa6da14: r1 = LoadInt32Instr(r0)
    //     0xa6da14: sbfx            x1, x0, #1, #0x1f
    //     0xa6da18: tbz             w0, #0, #0xa6da20
    //     0xa6da1c: ldur            x1, [x0, #7]
    // 0xa6da20: sub             x0, x1, #2
    // 0xa6da24: ldur            x1, [fp, #-0x20]
    // 0xa6da28: cmp             x1, x0
    // 0xa6da2c: b.ge            #0xa6da54
    // 0xa6da30: add             x0, x1, #1
    // 0xa6da34: ldr             x16, [fp, #0x20]
    // 0xa6da38: ldr             lr, [fp, #0x10]
    // 0xa6da3c: stp             lr, x16, [SP, #-0x10]!
    // 0xa6da40: SaveReg r0
    //     0xa6da40: str             x0, [SP, #-8]!
    // 0xa6da44: r0 = indicatorRect()
    //     0xa6da44: bl              #0xa6e114  ; [package:extended_tabs/src/tab_bar.dart] _IndicatorPainter::indicatorRect
    // 0xa6da48: add             SP, SP, #0x18
    // 0xa6da4c: mov             x3, x0
    // 0xa6da50: b               #0xa6da58
    // 0xa6da54: r3 = Null
    //     0xa6da54: mov             x3, NULL
    // 0xa6da58: ldur            x2, [fp, #-8]
    // 0xa6da5c: stur            x3, [fp, #-0x28]
    // 0xa6da60: LoadField: r4 = r2->field_33
    //     0xa6da60: ldur            x4, [x2, #0x33]
    // 0xa6da64: r0 = BoxInt64Instr(r4)
    //     0xa6da64: sbfiz           x0, x4, #1, #0x1f
    //     0xa6da68: cmp             x4, x0, asr #1
    //     0xa6da6c: b.eq            #0xa6da78
    //     0xa6da70: bl              #0xd69bb8
    //     0xa6da74: stur            x4, [x0, #7]
    // 0xa6da78: stp             x0, NULL, [SP, #-0x10]!
    // 0xa6da7c: r0 = _Double.fromInteger()
    //     0xa6da7c: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0xa6da80: add             SP, SP, #0x10
    // 0xa6da84: mov             x1, x0
    // 0xa6da88: ldur            x0, [fp, #-8]
    // 0xa6da8c: LoadField: r2 = r0->field_23
    //     0xa6da8c: ldur            w2, [x0, #0x23]
    // 0xa6da90: DecompressPointer r2
    //     0xa6da90: add             x2, x2, HEAP, lsl #32
    // 0xa6da94: cmp             w2, NULL
    // 0xa6da98: b.ne            #0xa6daa4
    // 0xa6da9c: r0 = Null
    //     0xa6da9c: mov             x0, NULL
    // 0xa6daa0: b               #0xa6daa8
    // 0xa6daa4: mov             x0, x2
    // 0xa6daa8: d0 = 1.000000
    //     0xa6daa8: fmov            d0, #1.00000000
    // 0xa6daac: cmp             w0, NULL
    // 0xa6dab0: b.eq            #0xa6dd50
    // 0xa6dab4: LoadField: r2 = r0->field_37
    //     0xa6dab4: ldur            w2, [x0, #0x37]
    // 0xa6dab8: DecompressPointer r2
    //     0xa6dab8: add             x2, x2, HEAP, lsl #32
    // 0xa6dabc: r16 = Sentinel
    //     0xa6dabc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa6dac0: cmp             w2, w16
    // 0xa6dac4: b.eq            #0xa6dd54
    // 0xa6dac8: LoadField: d1 = r1->field_7
    //     0xa6dac8: ldur            d1, [x1, #7]
    // 0xa6dacc: fsub            d2, d1, d0
    // 0xa6dad0: LoadField: d3 = r2->field_7
    //     0xa6dad0: ldur            d3, [x2, #7]
    // 0xa6dad4: fcmp            d3, d2
    // 0xa6dad8: b.vs            #0xa6db24
    // 0xa6dadc: b.ne            #0xa6db24
    // 0xa6dae0: ldur            x0, [fp, #-0x10]
    // 0xa6dae4: cmp             w0, NULL
    // 0xa6dae8: b.ne            #0xa6daf4
    // 0xa6daec: ldur            x2, [fp, #-0x18]
    // 0xa6daf0: b               #0xa6daf8
    // 0xa6daf4: mov             x2, x0
    // 0xa6daf8: ldr             x1, [fp, #0x20]
    // 0xa6dafc: mov             x0, x2
    // 0xa6db00: StoreField: r1->field_2f = r0
    //     0xa6db00: stur            w0, [x1, #0x2f]
    //     0xa6db04: ldurb           w16, [x1, #-1]
    //     0xa6db08: ldurb           w17, [x0, #-1]
    //     0xa6db0c: and             x16, x17, x16, lsr #2
    //     0xa6db10: tst             x16, HEAP, lsr #32
    //     0xa6db14: b.eq            #0xa6db1c
    //     0xa6db18: bl              #0xd6826c
    // 0xa6db1c: mov             x0, x2
    // 0xa6db20: b               #0xa6dc64
    // 0xa6db24: ldr             x1, [fp, #0x20]
    // 0xa6db28: ldur            x0, [fp, #-0x10]
    // 0xa6db2c: fadd            d2, d1, d0
    // 0xa6db30: fcmp            d3, d2
    // 0xa6db34: b.vs            #0xa6db74
    // 0xa6db38: b.ne            #0xa6db74
    // 0xa6db3c: ldur            x2, [fp, #-0x28]
    // 0xa6db40: cmp             w2, NULL
    // 0xa6db44: b.ne            #0xa6db4c
    // 0xa6db48: ldur            x2, [fp, #-0x18]
    // 0xa6db4c: mov             x0, x2
    // 0xa6db50: StoreField: r1->field_2f = r0
    //     0xa6db50: stur            w0, [x1, #0x2f]
    //     0xa6db54: ldurb           w16, [x1, #-1]
    //     0xa6db58: ldurb           w17, [x0, #-1]
    //     0xa6db5c: and             x16, x17, x16, lsr #2
    //     0xa6db60: tst             x16, HEAP, lsr #32
    //     0xa6db64: b.eq            #0xa6db6c
    //     0xa6db68: bl              #0xd6826c
    // 0xa6db6c: mov             x0, x2
    // 0xa6db70: b               #0xa6dc64
    // 0xa6db74: ldur            x2, [fp, #-0x28]
    // 0xa6db78: fcmp            d3, d1
    // 0xa6db7c: b.vs            #0xa6dbac
    // 0xa6db80: b.ne            #0xa6dbac
    // 0xa6db84: ldur            x0, [fp, #-0x18]
    // 0xa6db88: StoreField: r1->field_2f = r0
    //     0xa6db88: stur            w0, [x1, #0x2f]
    //     0xa6db8c: ldurb           w16, [x1, #-1]
    //     0xa6db90: ldurb           w17, [x0, #-1]
    //     0xa6db94: and             x16, x17, x16, lsr #2
    //     0xa6db98: tst             x16, HEAP, lsr #32
    //     0xa6db9c: b.eq            #0xa6dba4
    //     0xa6dba0: bl              #0xd6826c
    // 0xa6dba4: ldur            x0, [fp, #-0x18]
    // 0xa6dba8: b               #0xa6dc64
    // 0xa6dbac: fcmp            d3, d1
    // 0xa6dbb0: b.vs            #0xa6dc10
    // 0xa6dbb4: b.ge            #0xa6dc10
    // 0xa6dbb8: cmp             w0, NULL
    // 0xa6dbbc: b.ne            #0xa6dbc8
    // 0xa6dbc0: ldur            x2, [fp, #-0x18]
    // 0xa6dbc4: b               #0xa6dbe8
    // 0xa6dbc8: fsub            d0, d1, d3
    // 0xa6dbcc: ldur            x16, [fp, #-0x18]
    // 0xa6dbd0: stp             x0, x16, [SP, #-0x10]!
    // 0xa6dbd4: SaveReg d0
    //     0xa6dbd4: str             d0, [SP, #-8]!
    // 0xa6dbd8: r0 = lerp()
    //     0xa6dbd8: bl              #0xa6dd78  ; [dart:ui] Rect::lerp
    // 0xa6dbdc: add             SP, SP, #0x18
    // 0xa6dbe0: mov             x2, x0
    // 0xa6dbe4: ldr             x1, [fp, #0x20]
    // 0xa6dbe8: mov             x0, x2
    // 0xa6dbec: StoreField: r1->field_2f = r0
    //     0xa6dbec: stur            w0, [x1, #0x2f]
    //     0xa6dbf0: ldurb           w16, [x1, #-1]
    //     0xa6dbf4: ldurb           w17, [x0, #-1]
    //     0xa6dbf8: and             x16, x17, x16, lsr #2
    //     0xa6dbfc: tst             x16, HEAP, lsr #32
    //     0xa6dc00: b.eq            #0xa6dc08
    //     0xa6dc04: bl              #0xd6826c
    // 0xa6dc08: mov             x0, x2
    // 0xa6dc0c: b               #0xa6dc64
    // 0xa6dc10: cmp             w2, NULL
    // 0xa6dc14: b.ne            #0xa6dc20
    // 0xa6dc18: ldur            x2, [fp, #-0x18]
    // 0xa6dc1c: b               #0xa6dc40
    // 0xa6dc20: fsub            d0, d3, d1
    // 0xa6dc24: ldur            x16, [fp, #-0x18]
    // 0xa6dc28: stp             x2, x16, [SP, #-0x10]!
    // 0xa6dc2c: SaveReg d0
    //     0xa6dc2c: str             d0, [SP, #-8]!
    // 0xa6dc30: r0 = lerp()
    //     0xa6dc30: bl              #0xa6dd78  ; [dart:ui] Rect::lerp
    // 0xa6dc34: add             SP, SP, #0x18
    // 0xa6dc38: mov             x2, x0
    // 0xa6dc3c: ldr             x1, [fp, #0x20]
    // 0xa6dc40: mov             x0, x2
    // 0xa6dc44: StoreField: r1->field_2f = r0
    //     0xa6dc44: stur            w0, [x1, #0x2f]
    //     0xa6dc48: ldurb           w16, [x1, #-1]
    //     0xa6dc4c: ldurb           w17, [x0, #-1]
    //     0xa6dc50: and             x16, x17, x16, lsr #2
    //     0xa6dc54: tst             x16, HEAP, lsr #32
    //     0xa6dc58: b.eq            #0xa6dc60
    //     0xa6dc5c: bl              #0xd6826c
    // 0xa6dc60: mov             x0, x2
    // 0xa6dc64: cmp             w0, NULL
    // 0xa6dc68: b.eq            #0xa6dd60
    // 0xa6dc6c: SaveReg r0
    //     0xa6dc6c: str             x0, [SP, #-8]!
    // 0xa6dc70: r0 = size()
    //     0xa6dc70: bl              #0x5bc584  ; [dart:ui] Rect::size
    // 0xa6dc74: add             SP, SP, #8
    // 0xa6dc78: mov             x1, x0
    // 0xa6dc7c: ldr             x0, [fp, #0x20]
    // 0xa6dc80: stur            x1, [fp, #-0x10]
    // 0xa6dc84: LoadField: r2 = r0->field_2b
    //     0xa6dc84: ldur            w2, [x0, #0x2b]
    // 0xa6dc88: DecompressPointer r2
    //     0xa6dc88: add             x2, x2, HEAP, lsl #32
    // 0xa6dc8c: r16 = Sentinel
    //     0xa6dc8c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa6dc90: cmp             w2, w16
    // 0xa6dc94: b.eq            #0xa6dd64
    // 0xa6dc98: stur            x2, [fp, #-8]
    // 0xa6dc9c: r0 = ImageConfiguration()
    //     0xa6dc9c: bl              #0x665610  ; AllocateImageConfigurationStub -> ImageConfiguration (size=0x20)
    // 0xa6dca0: mov             x1, x0
    // 0xa6dca4: ldur            x0, [fp, #-8]
    // 0xa6dca8: stur            x1, [fp, #-0x18]
    // 0xa6dcac: StoreField: r1->field_13 = r0
    //     0xa6dcac: stur            w0, [x1, #0x13]
    // 0xa6dcb0: ldur            x0, [fp, #-0x10]
    // 0xa6dcb4: StoreField: r1->field_17 = r0
    //     0xa6dcb4: stur            w0, [x1, #0x17]
    // 0xa6dcb8: ldr             x0, [fp, #0x20]
    // 0xa6dcbc: LoadField: r2 = r0->field_33
    //     0xa6dcbc: ldur            w2, [x0, #0x33]
    // 0xa6dcc0: DecompressPointer r2
    //     0xa6dcc0: add             x2, x2, HEAP, lsl #32
    // 0xa6dcc4: stur            x2, [fp, #-8]
    // 0xa6dcc8: cmp             w2, NULL
    // 0xa6dccc: b.eq            #0xa6dd70
    // 0xa6dcd0: LoadField: r3 = r0->field_2f
    //     0xa6dcd0: ldur            w3, [x0, #0x2f]
    // 0xa6dcd4: DecompressPointer r3
    //     0xa6dcd4: add             x3, x3, HEAP, lsl #32
    // 0xa6dcd8: cmp             w3, NULL
    // 0xa6dcdc: b.eq            #0xa6dd74
    // 0xa6dce0: LoadField: d0 = r3->field_7
    //     0xa6dce0: ldur            d0, [x3, #7]
    // 0xa6dce4: stur            d0, [fp, #-0x38]
    // 0xa6dce8: LoadField: d1 = r3->field_f
    //     0xa6dce8: ldur            d1, [x3, #0xf]
    // 0xa6dcec: stur            d1, [fp, #-0x30]
    // 0xa6dcf0: r0 = Offset()
    //     0xa6dcf0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa6dcf4: ldur            d0, [fp, #-0x38]
    // 0xa6dcf8: StoreField: r0->field_7 = d0
    //     0xa6dcf8: stur            d0, [x0, #7]
    // 0xa6dcfc: ldur            d0, [fp, #-0x30]
    // 0xa6dd00: StoreField: r0->field_f = d0
    //     0xa6dd00: stur            d0, [x0, #0xf]
    // 0xa6dd04: ldur            x1, [fp, #-8]
    // 0xa6dd08: r2 = LoadClassIdInstr(r1)
    //     0xa6dd08: ldur            x2, [x1, #-1]
    //     0xa6dd0c: ubfx            x2, x2, #0xc, #0x14
    // 0xa6dd10: ldr             x16, [fp, #0x18]
    // 0xa6dd14: stp             x16, x1, [SP, #-0x10]!
    // 0xa6dd18: ldur            x16, [fp, #-0x18]
    // 0xa6dd1c: stp             x16, x0, [SP, #-0x10]!
    // 0xa6dd20: mov             x0, x2
    // 0xa6dd24: r0 = GDT[cid_x0 + -0x3e]()
    //     0xa6dd24: sub             lr, x0, #0x3e
    //     0xa6dd28: ldr             lr, [x21, lr, lsl #3]
    //     0xa6dd2c: blr             lr
    // 0xa6dd30: add             SP, SP, #0x20
    // 0xa6dd34: r0 = Null
    //     0xa6dd34: mov             x0, NULL
    // 0xa6dd38: LeaveFrame
    //     0xa6dd38: mov             SP, fp
    //     0xa6dd3c: ldp             fp, lr, [SP], #0x10
    // 0xa6dd40: ret
    //     0xa6dd40: ret             
    // 0xa6dd44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6dd44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6dd48: b               #0xa6d84c
    // 0xa6dd4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6dd4c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa6dd50: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa6dd50: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa6dd54: r9 = _value
    //     0xa6dd54: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0xa6dd58: ldr             x9, [x9, #0xbb0]
    // 0xa6dd5c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xa6dd5c: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xa6dd60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6dd60: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa6dd64: r9 = _currentTextDirection
    //     0xa6dd64: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4bff8] Field <_IndicatorPainter@468487081._currentTextDirection@468487081>: late (offset: 0x2c)
    //     0xa6dd68: ldr             x9, [x9, #0xff8]
    // 0xa6dd6c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa6dd6c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa6dd70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6dd70: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa6dd74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6dd74: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ indicatorRect(/* No info */) {
    // ** addr: 0xa6e114, size: 0x514
    // 0xa6e114: EnterFrame
    //     0xa6e114: stp             fp, lr, [SP, #-0x10]!
    //     0xa6e118: mov             fp, SP
    // 0xa6e11c: AllocStack(0x28)
    //     0xa6e11c: sub             SP, SP, #0x28
    // 0xa6e120: CheckStackOverflow
    //     0xa6e120: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6e124: cmp             SP, x16
    //     0xa6e128: b.ls            #0xa6e5f0
    // 0xa6e12c: ldr             x2, [fp, #0x10]
    // 0xa6e130: r0 = BoxInt64Instr(r2)
    //     0xa6e130: sbfiz           x0, x2, #1, #0x1f
    //     0xa6e134: cmp             x2, x0, asr #1
    //     0xa6e138: b.eq            #0xa6e144
    //     0xa6e13c: bl              #0xd69bb8
    //     0xa6e140: stur            x2, [x0, #7]
    // 0xa6e144: mov             x4, x0
    // 0xa6e148: ldr             x3, [fp, #0x20]
    // 0xa6e14c: stur            x4, [fp, #-8]
    // 0xa6e150: LoadField: r0 = r3->field_2b
    //     0xa6e150: ldur            w0, [x3, #0x2b]
    // 0xa6e154: DecompressPointer r0
    //     0xa6e154: add             x0, x0, HEAP, lsl #32
    // 0xa6e158: r16 = Sentinel
    //     0xa6e158: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa6e15c: cmp             w0, w16
    // 0xa6e160: b.eq            #0xa6e5f8
    // 0xa6e164: LoadField: r1 = r0->field_7
    //     0xa6e164: ldur            x1, [x0, #7]
    // 0xa6e168: cmp             x1, #0
    // 0xa6e16c: b.gt            #0xa6e218
    // 0xa6e170: LoadField: r5 = r3->field_27
    //     0xa6e170: ldur            w5, [x3, #0x27]
    // 0xa6e174: DecompressPointer r5
    //     0xa6e174: add             x5, x5, HEAP, lsl #32
    // 0xa6e178: cmp             w5, NULL
    // 0xa6e17c: b.eq            #0xa6e604
    // 0xa6e180: add             x6, x2, #1
    // 0xa6e184: r0 = BoxInt64Instr(r6)
    //     0xa6e184: sbfiz           x0, x6, #1, #0x1f
    //     0xa6e188: cmp             x6, x0, asr #1
    //     0xa6e18c: b.eq            #0xa6e198
    //     0xa6e190: bl              #0xd69bb8
    //     0xa6e194: stur            x6, [x0, #7]
    // 0xa6e198: r1 = LoadClassIdInstr(r5)
    //     0xa6e198: ldur            x1, [x5, #-1]
    //     0xa6e19c: ubfx            x1, x1, #0xc, #0x14
    // 0xa6e1a0: stp             x0, x5, [SP, #-0x10]!
    // 0xa6e1a4: mov             x0, x1
    // 0xa6e1a8: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa6e1a8: sub             lr, x0, #0xd83
    //     0xa6e1ac: ldr             lr, [x21, lr, lsl #3]
    //     0xa6e1b0: blr             lr
    // 0xa6e1b4: add             SP, SP, #0x10
    // 0xa6e1b8: mov             x2, x0
    // 0xa6e1bc: ldr             x1, [fp, #0x20]
    // 0xa6e1c0: stur            x2, [fp, #-0x10]
    // 0xa6e1c4: LoadField: r0 = r1->field_27
    //     0xa6e1c4: ldur            w0, [x1, #0x27]
    // 0xa6e1c8: DecompressPointer r0
    //     0xa6e1c8: add             x0, x0, HEAP, lsl #32
    // 0xa6e1cc: cmp             w0, NULL
    // 0xa6e1d0: b.eq            #0xa6e608
    // 0xa6e1d4: r3 = LoadClassIdInstr(r0)
    //     0xa6e1d4: ldur            x3, [x0, #-1]
    //     0xa6e1d8: ubfx            x3, x3, #0xc, #0x14
    // 0xa6e1dc: ldur            x16, [fp, #-8]
    // 0xa6e1e0: stp             x16, x0, [SP, #-0x10]!
    // 0xa6e1e4: mov             x0, x3
    // 0xa6e1e8: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa6e1e8: sub             lr, x0, #0xd83
    //     0xa6e1ec: ldr             lr, [x21, lr, lsl #3]
    //     0xa6e1f0: blr             lr
    // 0xa6e1f4: add             SP, SP, #0x10
    // 0xa6e1f8: mov             x1, x0
    // 0xa6e1fc: ldur            x0, [fp, #-0x10]
    // 0xa6e200: LoadField: d0 = r0->field_7
    //     0xa6e200: ldur            d0, [x0, #7]
    // 0xa6e204: LoadField: d1 = r1->field_7
    //     0xa6e204: ldur            d1, [x1, #7]
    // 0xa6e208: mov             v31.16b, v1.16b
    // 0xa6e20c: mov             v1.16b, v0.16b
    // 0xa6e210: mov             v0.16b, v31.16b
    // 0xa6e214: b               #0xa6e2c4
    // 0xa6e218: mov             x1, x3
    // 0xa6e21c: LoadField: r0 = r1->field_27
    //     0xa6e21c: ldur            w0, [x1, #0x27]
    // 0xa6e220: DecompressPointer r0
    //     0xa6e220: add             x0, x0, HEAP, lsl #32
    // 0xa6e224: cmp             w0, NULL
    // 0xa6e228: b.eq            #0xa6e60c
    // 0xa6e22c: r3 = LoadClassIdInstr(r0)
    //     0xa6e22c: ldur            x3, [x0, #-1]
    //     0xa6e230: ubfx            x3, x3, #0xc, #0x14
    // 0xa6e234: ldur            x16, [fp, #-8]
    // 0xa6e238: stp             x16, x0, [SP, #-0x10]!
    // 0xa6e23c: mov             x0, x3
    // 0xa6e240: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa6e240: sub             lr, x0, #0xd83
    //     0xa6e244: ldr             lr, [x21, lr, lsl #3]
    //     0xa6e248: blr             lr
    // 0xa6e24c: add             SP, SP, #0x10
    // 0xa6e250: mov             x3, x0
    // 0xa6e254: ldr             x2, [fp, #0x20]
    // 0xa6e258: stur            x3, [fp, #-0x10]
    // 0xa6e25c: LoadField: r4 = r2->field_27
    //     0xa6e25c: ldur            w4, [x2, #0x27]
    // 0xa6e260: DecompressPointer r4
    //     0xa6e260: add             x4, x4, HEAP, lsl #32
    // 0xa6e264: cmp             w4, NULL
    // 0xa6e268: b.eq            #0xa6e610
    // 0xa6e26c: ldr             x0, [fp, #0x10]
    // 0xa6e270: add             x5, x0, #1
    // 0xa6e274: r0 = BoxInt64Instr(r5)
    //     0xa6e274: sbfiz           x0, x5, #1, #0x1f
    //     0xa6e278: cmp             x5, x0, asr #1
    //     0xa6e27c: b.eq            #0xa6e288
    //     0xa6e280: bl              #0xd69bb8
    //     0xa6e284: stur            x5, [x0, #7]
    // 0xa6e288: r1 = LoadClassIdInstr(r4)
    //     0xa6e288: ldur            x1, [x4, #-1]
    //     0xa6e28c: ubfx            x1, x1, #0xc, #0x14
    // 0xa6e290: stp             x0, x4, [SP, #-0x10]!
    // 0xa6e294: mov             x0, x1
    // 0xa6e298: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa6e298: sub             lr, x0, #0xd83
    //     0xa6e29c: ldr             lr, [x21, lr, lsl #3]
    //     0xa6e2a0: blr             lr
    // 0xa6e2a4: add             SP, SP, #0x10
    // 0xa6e2a8: mov             x1, x0
    // 0xa6e2ac: ldur            x0, [fp, #-0x10]
    // 0xa6e2b0: LoadField: d0 = r0->field_7
    //     0xa6e2b0: ldur            d0, [x0, #7]
    // 0xa6e2b4: LoadField: d1 = r1->field_7
    //     0xa6e2b4: ldur            d1, [x1, #7]
    // 0xa6e2b8: mov             v31.16b, v1.16b
    // 0xa6e2bc: mov             v1.16b, v0.16b
    // 0xa6e2c0: mov             v0.16b, v31.16b
    // 0xa6e2c4: ldr             x1, [fp, #0x20]
    // 0xa6e2c8: stur            d1, [fp, #-0x18]
    // 0xa6e2cc: stur            d0, [fp, #-0x20]
    // 0xa6e2d0: LoadField: r2 = r1->field_17
    //     0xa6e2d0: ldur            w2, [x1, #0x17]
    // 0xa6e2d4: DecompressPointer r2
    //     0xa6e2d4: add             x2, x2, HEAP, lsl #32
    // 0xa6e2d8: stur            x2, [fp, #-0x10]
    // 0xa6e2dc: r0 = LoadClassIdInstr(r2)
    //     0xa6e2dc: ldur            x0, [x2, #-1]
    //     0xa6e2e0: ubfx            x0, x0, #0xc, #0x14
    // 0xa6e2e4: ldur            x16, [fp, #-8]
    // 0xa6e2e8: stp             x16, x2, [SP, #-0x10]!
    // 0xa6e2ec: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa6e2ec: sub             lr, x0, #0xd83
    //     0xa6e2f0: ldr             lr, [x21, lr, lsl #3]
    //     0xa6e2f4: blr             lr
    // 0xa6e2f8: add             SP, SP, #0x10
    // 0xa6e2fc: SaveReg r0
    //     0xa6e2fc: str             x0, [SP, #-8]!
    // 0xa6e300: r0 = _currentElement()
    //     0xa6e300: bl              #0x5093d8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0xa6e304: add             SP, SP, #8
    // 0xa6e308: cmp             w0, NULL
    // 0xa6e30c: b.eq            #0xa6e614
    // 0xa6e310: SaveReg r0
    //     0xa6e310: str             x0, [SP, #-8]!
    // 0xa6e314: r0 = size()
    //     0xa6e314: bl              #0x9d8778  ; [package:flutter/src/widgets/framework.dart] Element::size
    // 0xa6e318: add             SP, SP, #8
    // 0xa6e31c: cmp             w0, NULL
    // 0xa6e320: b.eq            #0xa6e618
    // 0xa6e324: LoadField: d0 = r0->field_7
    //     0xa6e324: ldur            d0, [x0, #7]
    // 0xa6e328: ldr             x1, [fp, #0x20]
    // 0xa6e32c: stur            d0, [fp, #-0x28]
    // 0xa6e330: LoadField: r0 = r1->field_13
    //     0xa6e330: ldur            w0, [x1, #0x13]
    // 0xa6e334: DecompressPointer r0
    //     0xa6e334: add             x0, x0, HEAP, lsl #32
    // 0xa6e338: r16 = Instance_TabBarIndicatorSize
    //     0xa6e338: add             x16, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!TabBarIndicatorSize@b65191
    //     0xa6e33c: ldr             x16, [x16, #0xbe0]
    // 0xa6e340: cmp             w0, w16
    // 0xa6e344: b.ne            #0xa6e44c
    // 0xa6e348: ldur            x0, [fp, #-0x10]
    // 0xa6e34c: r2 = LoadClassIdInstr(r0)
    //     0xa6e34c: ldur            x2, [x0, #-1]
    //     0xa6e350: ubfx            x2, x2, #0xc, #0x14
    // 0xa6e354: ldur            x16, [fp, #-8]
    // 0xa6e358: stp             x16, x0, [SP, #-0x10]!
    // 0xa6e35c: mov             x0, x2
    // 0xa6e360: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa6e360: sub             lr, x0, #0xd83
    //     0xa6e364: ldr             lr, [x21, lr, lsl #3]
    //     0xa6e368: blr             lr
    // 0xa6e36c: add             SP, SP, #0x10
    // 0xa6e370: SaveReg r0
    //     0xa6e370: str             x0, [SP, #-8]!
    // 0xa6e374: r0 = _currentElement()
    //     0xa6e374: bl              #0x5093d8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0xa6e378: add             SP, SP, #8
    // 0xa6e37c: cmp             w0, NULL
    // 0xa6e380: b.eq            #0xa6e61c
    // 0xa6e384: r16 = <RenderPadding>
    //     0xa6e384: add             x16, PP, #0x51, lsl #12  ; [pp+0x511a8] TypeArguments: <RenderPadding>
    //     0xa6e388: ldr             x16, [x16, #0x1a8]
    // 0xa6e38c: stp             x0, x16, [SP, #-0x10]!
    // 0xa6e390: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xa6e390: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xa6e394: r0 = findAncestorRenderObjectOfType()
    //     0xa6e394: bl              #0x50919c  ; [package:flutter/src/widgets/framework.dart] Element::findAncestorRenderObjectOfType
    // 0xa6e398: add             SP, SP, #0x10
    // 0xa6e39c: cmp             w0, NULL
    // 0xa6e3a0: b.eq            #0xa6e620
    // 0xa6e3a4: LoadField: r1 = r0->field_67
    //     0xa6e3a4: ldur            w1, [x0, #0x67]
    // 0xa6e3a8: DecompressPointer r1
    //     0xa6e3a8: add             x1, x1, HEAP, lsl #32
    // 0xa6e3ac: ldr             x0, [fp, #0x20]
    // 0xa6e3b0: LoadField: r2 = r0->field_2b
    //     0xa6e3b0: ldur            w2, [x0, #0x2b]
    // 0xa6e3b4: DecompressPointer r2
    //     0xa6e3b4: add             x2, x2, HEAP, lsl #32
    // 0xa6e3b8: r0 = LoadClassIdInstr(r1)
    //     0xa6e3b8: ldur            x0, [x1, #-1]
    //     0xa6e3bc: ubfx            x0, x0, #0xc, #0x14
    // 0xa6e3c0: lsl             x0, x0, #1
    // 0xa6e3c4: r17 = 4206
    //     0xa6e3c4: mov             x17, #0x106e
    // 0xa6e3c8: cmp             w0, w17
    // 0xa6e3cc: b.ne            #0xa6e3d8
    // 0xa6e3d0: mov             x0, x1
    // 0xa6e3d4: b               #0xa6e3f4
    // 0xa6e3d8: r0 = LoadClassIdInstr(r1)
    //     0xa6e3d8: ldur            x0, [x1, #-1]
    //     0xa6e3dc: ubfx            x0, x0, #0xc, #0x14
    // 0xa6e3e0: stp             x2, x1, [SP, #-0x10]!
    // 0xa6e3e4: r0 = GDT[cid_x0 + -0xfdb]()
    //     0xa6e3e4: sub             lr, x0, #0xfdb
    //     0xa6e3e8: ldr             lr, [x21, lr, lsl #3]
    //     0xa6e3ec: blr             lr
    // 0xa6e3f0: add             SP, SP, #0x10
    // 0xa6e3f4: ldur            d0, [fp, #-0x28]
    // 0xa6e3f8: ldur            d2, [fp, #-0x18]
    // 0xa6e3fc: ldur            d1, [fp, #-0x20]
    // 0xa6e400: d4 = 0.000000
    //     0xa6e400: eor             v4.16b, v4.16b, v4.16b
    // 0xa6e404: d3 = 2.000000
    //     0xa6e404: fmov            d3, #2.00000000
    // 0xa6e408: fsub            d5, d1, d2
    // 0xa6e40c: cmp             w0, NULL
    // 0xa6e410: b.eq            #0xa6e624
    // 0xa6e414: LoadField: d1 = r0->field_7
    //     0xa6e414: ldur            d1, [x0, #7]
    // 0xa6e418: LoadField: d6 = r0->field_17
    //     0xa6e418: ldur            d6, [x0, #0x17]
    // 0xa6e41c: fadd            d7, d1, d6
    // 0xa6e420: fadd            d6, d7, d4
    // 0xa6e424: fadd            d7, d6, d4
    // 0xa6e428: fadd            d6, d0, d7
    // 0xa6e42c: fsub            d7, d5, d6
    // 0xa6e430: fdiv            d5, d7, d3
    // 0xa6e434: fadd            d3, d5, d1
    // 0xa6e438: fadd            d1, d2, d3
    // 0xa6e43c: fadd            d2, d1, d0
    // 0xa6e440: mov             v0.16b, v1.16b
    // 0xa6e444: mov             v1.16b, v2.16b
    // 0xa6e448: b               #0xa6e45c
    // 0xa6e44c: ldur            d2, [fp, #-0x18]
    // 0xa6e450: ldur            d1, [fp, #-0x20]
    // 0xa6e454: d4 = 0.000000
    //     0xa6e454: eor             v4.16b, v4.16b, v4.16b
    // 0xa6e458: mov             v0.16b, v2.16b
    // 0xa6e45c: ldr             x0, [fp, #0x18]
    // 0xa6e460: stur            d0, [fp, #-0x28]
    // 0xa6e464: fsub            d2, d1, d0
    // 0xa6e468: LoadField: d1 = r0->field_f
    //     0xa6e468: ldur            d1, [x0, #0xf]
    // 0xa6e46c: fadd            d3, d0, d2
    // 0xa6e470: stur            d3, [fp, #-0x20]
    // 0xa6e474: fadd            d2, d4, d1
    // 0xa6e478: stur            d2, [fp, #-0x18]
    // 0xa6e47c: r0 = Rect()
    //     0xa6e47c: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0xa6e480: ldur            d0, [fp, #-0x28]
    // 0xa6e484: stur            x0, [fp, #-8]
    // 0xa6e488: StoreField: r0->field_7 = d0
    //     0xa6e488: stur            d0, [x0, #7]
    // 0xa6e48c: d0 = 0.000000
    //     0xa6e48c: eor             v0.16b, v0.16b, v0.16b
    // 0xa6e490: StoreField: r0->field_f = d0
    //     0xa6e490: stur            d0, [x0, #0xf]
    // 0xa6e494: ldur            d0, [fp, #-0x20]
    // 0xa6e498: StoreField: r0->field_17 = d0
    //     0xa6e498: stur            d0, [x0, #0x17]
    // 0xa6e49c: ldur            d0, [fp, #-0x18]
    // 0xa6e4a0: StoreField: r0->field_1f = d0
    //     0xa6e4a0: stur            d0, [x0, #0x1f]
    // 0xa6e4a4: SaveReg r0
    //     0xa6e4a4: str             x0, [SP, #-8]!
    // 0xa6e4a8: r0 = size()
    //     0xa6e4a8: bl              #0x5bc584  ; [dart:ui] Rect::size
    // 0xa6e4ac: add             SP, SP, #8
    // 0xa6e4b0: stur            x0, [fp, #-0x10]
    // 0xa6e4b4: r16 = Instance_EdgeInsets
    //     0xa6e4b4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0xa6e4b8: ldr             x16, [x16, #0xbd8]
    // 0xa6e4bc: SaveReg r16
    //     0xa6e4bc: str             x16, [SP, #-8]!
    // 0xa6e4c0: r0 = collapsedSize()
    //     0xa6e4c0: bl              #0xa6e628  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::collapsedSize
    // 0xa6e4c4: add             SP, SP, #8
    // 0xa6e4c8: mov             x1, x0
    // 0xa6e4cc: ldur            x0, [fp, #-0x10]
    // 0xa6e4d0: LoadField: d0 = r0->field_7
    //     0xa6e4d0: ldur            d0, [x0, #7]
    // 0xa6e4d4: LoadField: d1 = r1->field_7
    //     0xa6e4d4: ldur            d1, [x1, #7]
    // 0xa6e4d8: fcmp            d0, d1
    // 0xa6e4dc: b.vs            #0xa6e52c
    // 0xa6e4e0: b.lt            #0xa6e52c
    // 0xa6e4e4: LoadField: d0 = r0->field_f
    //     0xa6e4e4: ldur            d0, [x0, #0xf]
    // 0xa6e4e8: LoadField: d1 = r1->field_f
    //     0xa6e4e8: ldur            d1, [x1, #0xf]
    // 0xa6e4ec: fcmp            d0, d1
    // 0xa6e4f0: b.vs            #0xa6e4f8
    // 0xa6e4f4: b.ge            #0xa6e500
    // 0xa6e4f8: r0 = false
    //     0xa6e4f8: add             x0, NULL, #0x30  ; false
    // 0xa6e4fc: b               #0xa6e504
    // 0xa6e500: r0 = true
    //     0xa6e500: add             x0, NULL, #0x20  ; true
    // 0xa6e504: tbnz            w0, #4, #0xa6e52c
    // 0xa6e508: r16 = Instance_EdgeInsets
    //     0xa6e508: add             x16, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0xa6e50c: ldr             x16, [x16, #0xbd8]
    // 0xa6e510: ldur            lr, [fp, #-8]
    // 0xa6e514: stp             lr, x16, [SP, #-0x10]!
    // 0xa6e518: r0 = deflateRect()
    //     0xa6e518: bl              #0x65ae60  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::deflateRect
    // 0xa6e51c: add             SP, SP, #0x10
    // 0xa6e520: LeaveFrame
    //     0xa6e520: mov             SP, fp
    //     0xa6e524: ldp             fp, lr, [SP], #0x10
    // 0xa6e528: ret
    //     0xa6e528: ret             
    // 0xa6e52c: r1 = Null
    //     0xa6e52c: mov             x1, NULL
    // 0xa6e530: r2 = 8
    //     0xa6e530: mov             x2, #8
    // 0xa6e534: r0 = AllocateArray()
    //     0xa6e534: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa6e538: stur            x0, [fp, #-0x10]
    // 0xa6e53c: r17 = "indicatorPadding insets should be less than Tab Size\nRect Size : "
    //     0xa6e53c: add             x17, PP, #0x40, lsl #12  ; [pp+0x40d18] "indicatorPadding insets should be less than Tab Size\nRect Size : "
    //     0xa6e540: ldr             x17, [x17, #0xd18]
    // 0xa6e544: StoreField: r0->field_f = r17
    //     0xa6e544: stur            w17, [x0, #0xf]
    // 0xa6e548: ldur            x16, [fp, #-8]
    // 0xa6e54c: SaveReg r16
    //     0xa6e54c: str             x16, [SP, #-8]!
    // 0xa6e550: r0 = size()
    //     0xa6e550: bl              #0x5bc584  ; [dart:ui] Rect::size
    // 0xa6e554: add             SP, SP, #8
    // 0xa6e558: ldur            x1, [fp, #-0x10]
    // 0xa6e55c: ArrayStore: r1[1] = r0  ; List_4
    //     0xa6e55c: add             x25, x1, #0x13
    //     0xa6e560: str             w0, [x25]
    //     0xa6e564: tbz             w0, #0, #0xa6e580
    //     0xa6e568: ldurb           w16, [x1, #-1]
    //     0xa6e56c: ldurb           w17, [x0, #-1]
    //     0xa6e570: and             x16, x17, x16, lsr #2
    //     0xa6e574: tst             x16, HEAP, lsr #32
    //     0xa6e578: b.eq            #0xa6e580
    //     0xa6e57c: bl              #0xd67e5c
    // 0xa6e580: ldur            x1, [fp, #-0x10]
    // 0xa6e584: r17 = ", Insets: "
    //     0xa6e584: add             x17, PP, #0x40, lsl #12  ; [pp+0x40d20] ", Insets: "
    //     0xa6e588: ldr             x17, [x17, #0xd20]
    // 0xa6e58c: StoreField: r1->field_17 = r17
    //     0xa6e58c: stur            w17, [x1, #0x17]
    // 0xa6e590: r16 = Instance_EdgeInsets
    //     0xa6e590: add             x16, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0xa6e594: ldr             x16, [x16, #0xbd8]
    // 0xa6e598: SaveReg r16
    //     0xa6e598: str             x16, [SP, #-8]!
    // 0xa6e59c: r0 = toString()
    //     0xa6e59c: bl              #0xae128c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::toString
    // 0xa6e5a0: add             SP, SP, #8
    // 0xa6e5a4: ldur            x1, [fp, #-0x10]
    // 0xa6e5a8: ArrayStore: r1[3] = r0  ; List_4
    //     0xa6e5a8: add             x25, x1, #0x1b
    //     0xa6e5ac: str             w0, [x25]
    //     0xa6e5b0: tbz             w0, #0, #0xa6e5cc
    //     0xa6e5b4: ldurb           w16, [x1, #-1]
    //     0xa6e5b8: ldurb           w17, [x0, #-1]
    //     0xa6e5bc: and             x16, x17, x16, lsr #2
    //     0xa6e5c0: tst             x16, HEAP, lsr #32
    //     0xa6e5c4: b.eq            #0xa6e5cc
    //     0xa6e5c8: bl              #0xd67e5c
    // 0xa6e5cc: ldur            x16, [fp, #-0x10]
    // 0xa6e5d0: SaveReg r16
    //     0xa6e5d0: str             x16, [SP, #-8]!
    // 0xa6e5d4: r0 = _interpolate()
    //     0xa6e5d4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa6e5d8: add             SP, SP, #8
    // 0xa6e5dc: stp             x0, NULL, [SP, #-0x10]!
    // 0xa6e5e0: r0 = FlutterError()
    //     0xa6e5e0: bl              #0x59ef18  ; [package:flutter/src/foundation/assertions.dart] FlutterError::FlutterError
    // 0xa6e5e4: add             SP, SP, #0x10
    // 0xa6e5e8: r0 = Throw()
    //     0xa6e5e8: bl              #0xd67e38  ; ThrowStub
    // 0xa6e5ec: brk             #0
    // 0xa6e5f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6e5f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6e5f4: b               #0xa6e12c
    // 0xa6e5f8: r9 = _currentTextDirection
    //     0xa6e5f8: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4bff8] Field <_IndicatorPainter@468487081._currentTextDirection@468487081>: late (offset: 0x2c)
    //     0xa6e5fc: ldr             x9, [x9, #0xff8]
    // 0xa6e600: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa6e600: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa6e604: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6e604: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa6e608: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6e608: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa6e60c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6e60c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa6e610: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6e610: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa6e614: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6e614: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa6e618: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6e618: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa6e61c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6e61c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa6e620: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6e620: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa6e624: r0 = NullErrorSharedWithFPURegs()
    //     0xa6e624: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
  }
  [closure] void markNeedsPaint(dynamic) {
    // ** addr: 0xa6e684, size: 0x48
    // 0xa6e684: EnterFrame
    //     0xa6e684: stp             fp, lr, [SP, #-0x10]!
    //     0xa6e688: mov             fp, SP
    // 0xa6e68c: ldr             x0, [fp, #0x10]
    // 0xa6e690: LoadField: r1 = r0->field_17
    //     0xa6e690: ldur            w1, [x0, #0x17]
    // 0xa6e694: DecompressPointer r1
    //     0xa6e694: add             x1, x1, HEAP, lsl #32
    // 0xa6e698: CheckStackOverflow
    //     0xa6e698: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6e69c: cmp             SP, x16
    //     0xa6e6a0: b.ls            #0xa6e6c4
    // 0xa6e6a4: LoadField: r0 = r1->field_f
    //     0xa6e6a4: ldur            w0, [x1, #0xf]
    // 0xa6e6a8: DecompressPointer r0
    //     0xa6e6a8: add             x0, x0, HEAP, lsl #32
    // 0xa6e6ac: SaveReg r0
    //     0xa6e6ac: str             x0, [SP, #-8]!
    // 0xa6e6b0: r0 = markNeedsPaint()
    //     0xa6e6b0: bl              #0xa6e6cc  ; [package:extended_tabs/src/tab_bar.dart] _IndicatorPainter::markNeedsPaint
    // 0xa6e6b4: add             SP, SP, #8
    // 0xa6e6b8: LeaveFrame
    //     0xa6e6b8: mov             SP, fp
    //     0xa6e6bc: ldp             fp, lr, [SP], #0x10
    // 0xa6e6c0: ret
    //     0xa6e6c0: ret             
    // 0xa6e6c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6e6c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6e6c8: b               #0xa6e6a4
  }
  _ markNeedsPaint(/* No info */) {
    // ** addr: 0xa6e6cc, size: 0x14
    // 0xa6e6cc: r1 = true
    //     0xa6e6cc: add             x1, NULL, #0x20  ; true
    // 0xa6e6d0: ldr             x2, [SP]
    // 0xa6e6d4: StoreField: r2->field_37 = r1
    //     0xa6e6d4: stur            w1, [x2, #0x37]
    // 0xa6e6d8: r0 = Null
    //     0xa6e6d8: mov             x0, NULL
    // 0xa6e6dc: ret
    //     0xa6e6dc: ret             
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xa7945c, size: 0x1c8
    // 0xa7945c: EnterFrame
    //     0xa7945c: stp             fp, lr, [SP, #-0x10]!
    //     0xa79460: mov             fp, SP
    // 0xa79464: AllocStack(0x8)
    //     0xa79464: sub             SP, SP, #8
    // 0xa79468: CheckStackOverflow
    //     0xa79468: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa7946c: cmp             SP, x16
    //     0xa79470: b.ls            #0xa79604
    // 0xa79474: ldr             x0, [fp, #0x10]
    // 0xa79478: r2 = Null
    //     0xa79478: mov             x2, NULL
    // 0xa7947c: r1 = Null
    //     0xa7947c: mov             x1, NULL
    // 0xa79480: r4 = 59
    //     0xa79480: mov             x4, #0x3b
    // 0xa79484: branchIfSmi(r0, 0xa79490)
    //     0xa79484: tbz             w0, #0, #0xa79490
    // 0xa79488: r4 = LoadClassIdInstr(r0)
    //     0xa79488: ldur            x4, [x0, #-1]
    //     0xa7948c: ubfx            x4, x4, #0xc, #0x14
    // 0xa79490: r17 = 4380
    //     0xa79490: mov             x17, #0x111c
    // 0xa79494: cmp             x4, x17
    // 0xa79498: b.eq            #0xa794b0
    // 0xa7949c: r8 = _IndicatorPainter
    //     0xa7949c: add             x8, PP, #0x51, lsl #12  ; [pp+0x51188] Type: _IndicatorPainter
    //     0xa794a0: ldr             x8, [x8, #0x188]
    // 0xa794a4: r3 = Null
    //     0xa794a4: add             x3, PP, #0x51, lsl #12  ; [pp+0x51190] Null
    //     0xa794a8: ldr             x3, [x3, #0x190]
    // 0xa794ac: r0 = DefaultTypeTest()
    //     0xa794ac: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa794b0: ldr             x1, [fp, #0x18]
    // 0xa794b4: LoadField: r0 = r1->field_37
    //     0xa794b4: ldur            w0, [x1, #0x37]
    // 0xa794b8: DecompressPointer r0
    //     0xa794b8: add             x0, x0, HEAP, lsl #32
    // 0xa794bc: tbz             w0, #4, #0xa795ec
    // 0xa794c0: ldr             x2, [fp, #0x10]
    // 0xa794c4: LoadField: r0 = r1->field_b
    //     0xa794c4: ldur            w0, [x1, #0xb]
    // 0xa794c8: DecompressPointer r0
    //     0xa794c8: add             x0, x0, HEAP, lsl #32
    // 0xa794cc: LoadField: r3 = r2->field_b
    //     0xa794cc: ldur            w3, [x2, #0xb]
    // 0xa794d0: DecompressPointer r3
    //     0xa794d0: add             x3, x3, HEAP, lsl #32
    // 0xa794d4: cmp             w0, w3
    // 0xa794d8: b.ne            #0xa795ec
    // 0xa794dc: LoadField: r0 = r1->field_f
    //     0xa794dc: ldur            w0, [x1, #0xf]
    // 0xa794e0: DecompressPointer r0
    //     0xa794e0: add             x0, x0, HEAP, lsl #32
    // 0xa794e4: LoadField: r3 = r2->field_f
    //     0xa794e4: ldur            w3, [x2, #0xf]
    // 0xa794e8: DecompressPointer r3
    //     0xa794e8: add             x3, x3, HEAP, lsl #32
    // 0xa794ec: r4 = LoadClassIdInstr(r0)
    //     0xa794ec: ldur            x4, [x0, #-1]
    //     0xa794f0: ubfx            x4, x4, #0xc, #0x14
    // 0xa794f4: stp             x3, x0, [SP, #-0x10]!
    // 0xa794f8: mov             x0, x4
    // 0xa794fc: mov             lr, x0
    // 0xa79500: ldr             lr, [x21, lr, lsl #3]
    // 0xa79504: blr             lr
    // 0xa79508: add             SP, SP, #0x10
    // 0xa7950c: tbnz            w0, #4, #0xa795ec
    // 0xa79510: ldr             x1, [fp, #0x18]
    // 0xa79514: ldr             x2, [fp, #0x10]
    // 0xa79518: LoadField: r0 = r1->field_17
    //     0xa79518: ldur            w0, [x1, #0x17]
    // 0xa7951c: DecompressPointer r0
    //     0xa7951c: add             x0, x0, HEAP, lsl #32
    // 0xa79520: r3 = LoadClassIdInstr(r0)
    //     0xa79520: ldur            x3, [x0, #-1]
    //     0xa79524: ubfx            x3, x3, #0xc, #0x14
    // 0xa79528: SaveReg r0
    //     0xa79528: str             x0, [SP, #-8]!
    // 0xa7952c: mov             x0, x3
    // 0xa79530: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa79530: mov             x17, #0xb8ea
    //     0xa79534: add             lr, x0, x17
    //     0xa79538: ldr             lr, [x21, lr, lsl #3]
    //     0xa7953c: blr             lr
    // 0xa79540: add             SP, SP, #8
    // 0xa79544: mov             x2, x0
    // 0xa79548: ldr             x1, [fp, #0x10]
    // 0xa7954c: stur            x2, [fp, #-8]
    // 0xa79550: LoadField: r0 = r1->field_17
    //     0xa79550: ldur            w0, [x1, #0x17]
    // 0xa79554: DecompressPointer r0
    //     0xa79554: add             x0, x0, HEAP, lsl #32
    // 0xa79558: r3 = LoadClassIdInstr(r0)
    //     0xa79558: ldur            x3, [x0, #-1]
    //     0xa7955c: ubfx            x3, x3, #0xc, #0x14
    // 0xa79560: SaveReg r0
    //     0xa79560: str             x0, [SP, #-8]!
    // 0xa79564: mov             x0, x3
    // 0xa79568: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa79568: mov             x17, #0xb8ea
    //     0xa7956c: add             lr, x0, x17
    //     0xa79570: ldr             lr, [x21, lr, lsl #3]
    //     0xa79574: blr             lr
    // 0xa79578: add             SP, SP, #8
    // 0xa7957c: mov             x1, x0
    // 0xa79580: ldur            x0, [fp, #-8]
    // 0xa79584: cmp             w0, w1
    // 0xa79588: b.ne            #0xa795ec
    // 0xa7958c: ldr             x1, [fp, #0x18]
    // 0xa79590: ldr             x0, [fp, #0x10]
    // 0xa79594: LoadField: r2 = r1->field_27
    //     0xa79594: ldur            w2, [x1, #0x27]
    // 0xa79598: DecompressPointer r2
    //     0xa79598: add             x2, x2, HEAP, lsl #32
    // 0xa7959c: LoadField: r3 = r0->field_27
    //     0xa7959c: ldur            w3, [x0, #0x27]
    // 0xa795a0: DecompressPointer r3
    //     0xa795a0: add             x3, x3, HEAP, lsl #32
    // 0xa795a4: stp             x3, x2, [SP, #-0x10]!
    // 0xa795a8: r0 = _tabOffsetsEqual()
    //     0xa795a8: bl              #0xa79624  ; [package:extended_tabs/src/tab_bar.dart] _IndicatorPainter::_tabOffsetsEqual
    // 0xa795ac: add             SP, SP, #0x10
    // 0xa795b0: tbnz            w0, #4, #0xa795ec
    // 0xa795b4: ldr             x2, [fp, #0x18]
    // 0xa795b8: ldr             x1, [fp, #0x10]
    // 0xa795bc: LoadField: r3 = r2->field_2b
    //     0xa795bc: ldur            w3, [x2, #0x2b]
    // 0xa795c0: DecompressPointer r3
    //     0xa795c0: add             x3, x3, HEAP, lsl #32
    // 0xa795c4: r16 = Sentinel
    //     0xa795c4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa795c8: cmp             w3, w16
    // 0xa795cc: b.eq            #0xa7960c
    // 0xa795d0: LoadField: r2 = r1->field_2b
    //     0xa795d0: ldur            w2, [x1, #0x2b]
    // 0xa795d4: DecompressPointer r2
    //     0xa795d4: add             x2, x2, HEAP, lsl #32
    // 0xa795d8: r16 = Sentinel
    //     0xa795d8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa795dc: cmp             w2, w16
    // 0xa795e0: b.eq            #0xa79618
    // 0xa795e4: cmp             w3, w2
    // 0xa795e8: b.eq            #0xa795f4
    // 0xa795ec: r0 = true
    //     0xa795ec: add             x0, NULL, #0x20  ; true
    // 0xa795f0: b               #0xa795f8
    // 0xa795f4: r0 = false
    //     0xa795f4: add             x0, NULL, #0x30  ; false
    // 0xa795f8: LeaveFrame
    //     0xa795f8: mov             SP, fp
    //     0xa795fc: ldp             fp, lr, [SP], #0x10
    // 0xa79600: ret
    //     0xa79600: ret             
    // 0xa79604: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa79604: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa79608: b               #0xa79474
    // 0xa7960c: r9 = _currentTextDirection
    //     0xa7960c: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4bff8] Field <_IndicatorPainter@468487081._currentTextDirection@468487081>: late (offset: 0x2c)
    //     0xa79610: ldr             x9, [x9, #0xff8]
    // 0xa79614: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa79614: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa79618: r9 = _currentTextDirection
    //     0xa79618: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4bff8] Field <_IndicatorPainter@468487081._currentTextDirection@468487081>: late (offset: 0x2c)
    //     0xa7961c: ldr             x9, [x9, #0xff8]
    // 0xa79620: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa79620: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  static _ _tabOffsetsEqual(/* No info */) {
    // ** addr: 0xa79624, size: 0x1c4
    // 0xa79624: EnterFrame
    //     0xa79624: stp             fp, lr, [SP, #-0x10]!
    //     0xa79628: mov             fp, SP
    // 0xa7962c: AllocStack(0x18)
    //     0xa7962c: sub             SP, SP, #0x18
    // 0xa79630: CheckStackOverflow
    //     0xa79630: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa79634: cmp             SP, x16
    //     0xa79638: b.ls            #0xa797d8
    // 0xa7963c: ldr             x1, [fp, #0x18]
    // 0xa79640: cmp             w1, NULL
    // 0xa79644: b.eq            #0xa796c8
    // 0xa79648: ldr             x2, [fp, #0x10]
    // 0xa7964c: cmp             w2, NULL
    // 0xa79650: b.eq            #0xa796c8
    // 0xa79654: r0 = LoadClassIdInstr(r1)
    //     0xa79654: ldur            x0, [x1, #-1]
    //     0xa79658: ubfx            x0, x0, #0xc, #0x14
    // 0xa7965c: SaveReg r1
    //     0xa7965c: str             x1, [SP, #-8]!
    // 0xa79660: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa79660: mov             x17, #0xb8ea
    //     0xa79664: add             lr, x0, x17
    //     0xa79668: ldr             lr, [x21, lr, lsl #3]
    //     0xa7966c: blr             lr
    // 0xa79670: add             SP, SP, #8
    // 0xa79674: mov             x2, x0
    // 0xa79678: ldr             x1, [fp, #0x10]
    // 0xa7967c: stur            x2, [fp, #-8]
    // 0xa79680: r0 = LoadClassIdInstr(r1)
    //     0xa79680: ldur            x0, [x1, #-1]
    //     0xa79684: ubfx            x0, x0, #0xc, #0x14
    // 0xa79688: SaveReg r1
    //     0xa79688: str             x1, [SP, #-8]!
    // 0xa7968c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa7968c: mov             x17, #0xb8ea
    //     0xa79690: add             lr, x0, x17
    //     0xa79694: ldr             lr, [x21, lr, lsl #3]
    //     0xa79698: blr             lr
    // 0xa7969c: add             SP, SP, #8
    // 0xa796a0: mov             x1, x0
    // 0xa796a4: ldur            x0, [fp, #-8]
    // 0xa796a8: r2 = LoadInt32Instr(r0)
    //     0xa796a8: sbfx            x2, x0, #1, #0x1f
    //     0xa796ac: tbz             w0, #0, #0xa796b4
    //     0xa796b0: ldur            x2, [x0, #7]
    // 0xa796b4: r0 = LoadInt32Instr(r1)
    //     0xa796b4: sbfx            x0, x1, #1, #0x1f
    //     0xa796b8: tbz             w1, #0, #0xa796c0
    //     0xa796bc: ldur            x0, [x1, #7]
    // 0xa796c0: cmp             x2, x0
    // 0xa796c4: b.eq            #0xa796d8
    // 0xa796c8: r0 = false
    //     0xa796c8: add             x0, NULL, #0x30  ; false
    // 0xa796cc: LeaveFrame
    //     0xa796cc: mov             SP, fp
    //     0xa796d0: ldp             fp, lr, [SP], #0x10
    // 0xa796d4: ret
    //     0xa796d4: ret             
    // 0xa796d8: r3 = 0
    //     0xa796d8: mov             x3, #0
    // 0xa796dc: ldr             x2, [fp, #0x18]
    // 0xa796e0: ldr             x1, [fp, #0x10]
    // 0xa796e4: stur            x3, [fp, #-0x10]
    // 0xa796e8: CheckStackOverflow
    //     0xa796e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa796ec: cmp             SP, x16
    //     0xa796f0: b.ls            #0xa797e0
    // 0xa796f4: r0 = LoadClassIdInstr(r2)
    //     0xa796f4: ldur            x0, [x2, #-1]
    //     0xa796f8: ubfx            x0, x0, #0xc, #0x14
    // 0xa796fc: SaveReg r2
    //     0xa796fc: str             x2, [SP, #-8]!
    // 0xa79700: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa79700: mov             x17, #0xb8ea
    //     0xa79704: add             lr, x0, x17
    //     0xa79708: ldr             lr, [x21, lr, lsl #3]
    //     0xa7970c: blr             lr
    // 0xa79710: add             SP, SP, #8
    // 0xa79714: r1 = LoadInt32Instr(r0)
    //     0xa79714: sbfx            x1, x0, #1, #0x1f
    //     0xa79718: tbz             w0, #0, #0xa79720
    //     0xa7971c: ldur            x1, [x0, #7]
    // 0xa79720: ldur            x2, [fp, #-0x10]
    // 0xa79724: cmp             x2, x1
    // 0xa79728: b.ge            #0xa797c8
    // 0xa7972c: ldr             x4, [fp, #0x18]
    // 0xa79730: ldr             x3, [fp, #0x10]
    // 0xa79734: r0 = BoxInt64Instr(r2)
    //     0xa79734: sbfiz           x0, x2, #1, #0x1f
    //     0xa79738: cmp             x2, x0, asr #1
    //     0xa7973c: b.eq            #0xa79748
    //     0xa79740: bl              #0xd69bb8
    //     0xa79744: stur            x2, [x0, #7]
    // 0xa79748: mov             x1, x0
    // 0xa7974c: stur            x1, [fp, #-8]
    // 0xa79750: r0 = LoadClassIdInstr(r4)
    //     0xa79750: ldur            x0, [x4, #-1]
    //     0xa79754: ubfx            x0, x0, #0xc, #0x14
    // 0xa79758: stp             x1, x4, [SP, #-0x10]!
    // 0xa7975c: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa7975c: sub             lr, x0, #0xd83
    //     0xa79760: ldr             lr, [x21, lr, lsl #3]
    //     0xa79764: blr             lr
    // 0xa79768: add             SP, SP, #0x10
    // 0xa7976c: mov             x2, x0
    // 0xa79770: ldr             x1, [fp, #0x10]
    // 0xa79774: stur            x2, [fp, #-0x18]
    // 0xa79778: r0 = LoadClassIdInstr(r1)
    //     0xa79778: ldur            x0, [x1, #-1]
    //     0xa7977c: ubfx            x0, x0, #0xc, #0x14
    // 0xa79780: ldur            x16, [fp, #-8]
    // 0xa79784: stp             x16, x1, [SP, #-0x10]!
    // 0xa79788: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa79788: sub             lr, x0, #0xd83
    //     0xa7978c: ldr             lr, [x21, lr, lsl #3]
    //     0xa79790: blr             lr
    // 0xa79794: add             SP, SP, #0x10
    // 0xa79798: ldur            x1, [fp, #-0x18]
    // 0xa7979c: LoadField: d0 = r1->field_7
    //     0xa7979c: ldur            d0, [x1, #7]
    // 0xa797a0: LoadField: d1 = r0->field_7
    //     0xa797a0: ldur            d1, [x0, #7]
    // 0xa797a4: fcmp            d0, d1
    // 0xa797a8: b.eq            #0xa797bc
    // 0xa797ac: r0 = false
    //     0xa797ac: add             x0, NULL, #0x30  ; false
    // 0xa797b0: LeaveFrame
    //     0xa797b0: mov             SP, fp
    //     0xa797b4: ldp             fp, lr, [SP], #0x10
    // 0xa797b8: ret
    //     0xa797b8: ret             
    // 0xa797bc: ldur            x1, [fp, #-0x10]
    // 0xa797c0: add             x3, x1, #1
    // 0xa797c4: b               #0xa796dc
    // 0xa797c8: r0 = true
    //     0xa797c8: add             x0, NULL, #0x20  ; true
    // 0xa797cc: LeaveFrame
    //     0xa797cc: mov             SP, fp
    //     0xa797d0: ldp             fp, lr, [SP], #0x10
    // 0xa797d4: ret
    //     0xa797d4: ret             
    // 0xa797d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa797d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa797dc: b               #0xa7963c
    // 0xa797e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa797e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa797e4: b               #0xa796f4
  }
}

// class id: 4849, size: 0x88, field offset: 0x80
class _TabBarScrollPosition extends ScrollPositionWithSingleContext {

  _ applyContentDimensions(/* No info */) {
    // ** addr: 0xc73d64, size: 0x180
    // 0xc73d64: EnterFrame
    //     0xc73d64: stp             fp, lr, [SP, #-0x10]!
    //     0xc73d68: mov             fp, SP
    // 0xc73d6c: AllocStack(0x8)
    //     0xc73d6c: sub             SP, SP, #8
    // 0xc73d70: CheckStackOverflow
    //     0xc73d70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc73d74: cmp             SP, x16
    //     0xc73d78: b.ls            #0xc73ea4
    // 0xc73d7c: ldr             x0, [fp, #0x20]
    // 0xc73d80: LoadField: r1 = r0->field_83
    //     0xc73d80: ldur            w1, [x0, #0x83]
    // 0xc73d84: DecompressPointer r1
    //     0xc73d84: add             x1, x1, HEAP, lsl #32
    // 0xc73d88: r16 = true
    //     0xc73d88: add             x16, NULL, #0x20  ; true
    // 0xc73d8c: cmp             w1, w16
    // 0xc73d90: b.eq            #0xc73e60
    // 0xc73d94: ldr             d1, [fp, #0x18]
    // 0xc73d98: ldr             x1, [fp, #0x10]
    // 0xc73d9c: d0 = 0.000000
    //     0xc73d9c: eor             v0.16b, v0.16b, v0.16b
    // 0xc73da0: LoadField: r2 = r0->field_47
    //     0xc73da0: ldur            w2, [x0, #0x47]
    // 0xc73da4: DecompressPointer r2
    //     0xc73da4: add             x2, x2, HEAP, lsl #32
    // 0xc73da8: cmp             w2, NULL
    // 0xc73dac: b.eq            #0xc73eac
    // 0xc73db0: LoadField: d2 = r2->field_7
    //     0xc73db0: ldur            d2, [x2, #7]
    // 0xc73db4: fcmp            d2, d0
    // 0xc73db8: r16 = true
    //     0xc73db8: add             x16, NULL, #0x20  ; true
    // 0xc73dbc: r17 = false
    //     0xc73dbc: add             x17, NULL, #0x30  ; false
    // 0xc73dc0: csel            x3, x16, x17, ne
    // 0xc73dc4: StoreField: r0->field_83 = r3
    //     0xc73dc4: stur            w3, [x0, #0x83]
    // 0xc73dc8: LoadField: r3 = r0->field_7f
    //     0xc73dc8: ldur            w3, [x0, #0x7f]
    // 0xc73dcc: DecompressPointer r3
    //     0xc73dcc: add             x3, x3, HEAP, lsl #32
    // 0xc73dd0: r4 = inline_Allocate_Double()
    //     0xc73dd0: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xc73dd4: add             x4, x4, #0x10
    //     0xc73dd8: cmp             x5, x4
    //     0xc73ddc: b.ls            #0xc73eb0
    //     0xc73de0: str             x4, [THR, #0x60]  ; THR::top
    //     0xc73de4: sub             x4, x4, #0xf
    //     0xc73de8: mov             x5, #0xd108
    //     0xc73dec: movk            x5, #3, lsl #16
    //     0xc73df0: stur            x5, [x4, #-1]
    // 0xc73df4: StoreField: r4->field_7 = d1
    //     0xc73df4: stur            d1, [x4, #7]
    // 0xc73df8: LoadField: d0 = r1->field_7
    //     0xc73df8: ldur            d0, [x1, #7]
    // 0xc73dfc: stp             x2, x3, [SP, #-0x10]!
    // 0xc73e00: SaveReg r4
    //     0xc73e00: str             x4, [SP, #-8]!
    // 0xc73e04: SaveReg d0
    //     0xc73e04: str             d0, [SP, #-8]!
    // 0xc73e08: r0 = _initialScrollOffset()
    //     0xc73e08: bl              #0xc73ee4  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_initialScrollOffset
    // 0xc73e0c: add             SP, SP, #0x20
    // 0xc73e10: r0 = inline_Allocate_Double()
    //     0xc73e10: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc73e14: add             x0, x0, #0x10
    //     0xc73e18: cmp             x1, x0
    //     0xc73e1c: b.ls            #0xc73ed4
    //     0xc73e20: str             x0, [THR, #0x60]  ; THR::top
    //     0xc73e24: sub             x0, x0, #0xf
    //     0xc73e28: mov             x1, #0xd108
    //     0xc73e2c: movk            x1, #3, lsl #16
    //     0xc73e30: stur            x1, [x0, #-1]
    // 0xc73e34: StoreField: r0->field_7 = d0
    //     0xc73e34: stur            d0, [x0, #7]
    // 0xc73e38: ldr             x1, [fp, #0x20]
    // 0xc73e3c: StoreField: r1->field_43 = r0
    //     0xc73e3c: stur            w0, [x1, #0x43]
    //     0xc73e40: ldurb           w16, [x1, #-1]
    //     0xc73e44: ldurb           w17, [x0, #-1]
    //     0xc73e48: and             x16, x17, x16, lsr #2
    //     0xc73e4c: tst             x16, HEAP, lsr #32
    //     0xc73e50: b.eq            #0xc73e58
    //     0xc73e54: bl              #0xd6826c
    // 0xc73e58: r0 = false
    //     0xc73e58: add             x0, NULL, #0x30  ; false
    // 0xc73e5c: b               #0xc73e68
    // 0xc73e60: mov             x1, x0
    // 0xc73e64: r0 = true
    //     0xc73e64: add             x0, NULL, #0x20  ; true
    // 0xc73e68: ldr             d0, [fp, #0x18]
    // 0xc73e6c: stur            x0, [fp, #-8]
    // 0xc73e70: SaveReg r1
    //     0xc73e70: str             x1, [SP, #-8]!
    // 0xc73e74: SaveReg d0
    //     0xc73e74: str             d0, [SP, #-8]!
    // 0xc73e78: ldr             x16, [fp, #0x10]
    // 0xc73e7c: SaveReg r16
    //     0xc73e7c: str             x16, [SP, #-8]!
    // 0xc73e80: r0 = applyContentDimensions()
    //     0xc73e80: bl              #0xc742d4  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::applyContentDimensions
    // 0xc73e84: add             SP, SP, #0x18
    // 0xc73e88: tbnz            w0, #4, #0xc73e94
    // 0xc73e8c: ldur            x0, [fp, #-8]
    // 0xc73e90: b               #0xc73e98
    // 0xc73e94: r0 = false
    //     0xc73e94: add             x0, NULL, #0x30  ; false
    // 0xc73e98: LeaveFrame
    //     0xc73e98: mov             SP, fp
    //     0xc73e9c: ldp             fp, lr, [SP], #0x10
    // 0xc73ea0: ret
    //     0xc73ea0: ret             
    // 0xc73ea4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc73ea4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc73ea8: b               #0xc73d7c
    // 0xc73eac: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc73eac: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc73eb0: SaveReg d1
    //     0xc73eb0: str             q1, [SP, #-0x10]!
    // 0xc73eb4: stp             x2, x3, [SP, #-0x10]!
    // 0xc73eb8: stp             x0, x1, [SP, #-0x10]!
    // 0xc73ebc: r0 = AllocateDouble()
    //     0xc73ebc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc73ec0: mov             x4, x0
    // 0xc73ec4: ldp             x0, x1, [SP], #0x10
    // 0xc73ec8: ldp             x2, x3, [SP], #0x10
    // 0xc73ecc: RestoreReg d1
    //     0xc73ecc: ldr             q1, [SP], #0x10
    // 0xc73ed0: b               #0xc73df4
    // 0xc73ed4: SaveReg d0
    //     0xc73ed4: str             q0, [SP, #-0x10]!
    // 0xc73ed8: r0 = AllocateDouble()
    //     0xc73ed8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc73edc: RestoreReg d0
    //     0xc73edc: ldr             q0, [SP], #0x10
    // 0xc73ee0: b               #0xc73e34
  }
}

// class id: 4856, size: 0x3c, field offset: 0x38
class _TabBarScrollController extends ScrollController {

  _ createScrollPosition(/* No info */) {
    // ** addr: 0xbebed4, size: 0x78
    // 0xbebed4: EnterFrame
    //     0xbebed4: stp             fp, lr, [SP, #-0x10]!
    //     0xbebed8: mov             fp, SP
    // 0xbebedc: AllocStack(0x10)
    //     0xbebedc: sub             SP, SP, #0x10
    // 0xbebee0: CheckStackOverflow
    //     0xbebee0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbebee4: cmp             SP, x16
    //     0xbebee8: b.ls            #0xbebf44
    // 0xbebeec: ldr             x0, [fp, #0x28]
    // 0xbebef0: LoadField: r1 = r0->field_37
    //     0xbebef0: ldur            w1, [x0, #0x37]
    // 0xbebef4: DecompressPointer r1
    //     0xbebef4: add             x1, x1, HEAP, lsl #32
    // 0xbebef8: stur            x1, [fp, #-8]
    // 0xbebefc: r0 = _TabBarScrollPosition()
    //     0xbebefc: bl              #0xbebf4c  ; Allocate_TabBarScrollPositionStub -> _TabBarScrollPosition (size=0x88)
    // 0xbebf00: mov             x1, x0
    // 0xbebf04: ldur            x0, [fp, #-8]
    // 0xbebf08: stur            x1, [fp, #-0x10]
    // 0xbebf0c: StoreField: r1->field_7f = r0
    //     0xbebf0c: stur            w0, [x1, #0x7f]
    // 0xbebf10: ldr             x16, [fp, #0x18]
    // 0xbebf14: stp             x16, x1, [SP, #-0x10]!
    // 0xbebf18: ldr             x16, [fp, #0x10]
    // 0xbebf1c: stp             x16, NULL, [SP, #-0x10]!
    // 0xbebf20: ldr             x16, [fp, #0x20]
    // 0xbebf24: SaveReg r16
    //     0xbebf24: str             x16, [SP, #-8]!
    // 0xbebf28: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xbebf28: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xbebf2c: r0 = ScrollPositionWithSingleContext()
    //     0xbebf2c: bl              #0xbeb8c8  ; [package:flutter/src/widgets/scroll_position_with_single_context.dart] ScrollPositionWithSingleContext::ScrollPositionWithSingleContext
    // 0xbebf30: add             SP, SP, #0x28
    // 0xbebf34: ldur            x0, [fp, #-0x10]
    // 0xbebf38: LeaveFrame
    //     0xbebf38: mov             SP, fp
    //     0xbebf3c: ldp             fp, lr, [SP], #0x10
    // 0xbebf40: ret
    //     0xbebf40: ret             
    // 0xbebf44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbebf44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbebf48: b               #0xbebeec
  }
}

// lib: , url: package:extended_tabs/src/page_view.dart

// class id: 1048963, size: 0x8
class :: {
}

// class id: 3381, size: 0x1c, field offset: 0x14
class _ExtendedPageViewState extends State<ExtendedPageView> {

  _ build(/* No info */) {
    // ** addr: 0x831b20, size: 0x1a0
    // 0x831b20: EnterFrame
    //     0x831b20: stp             fp, lr, [SP, #-0x10]!
    //     0x831b24: mov             fp, SP
    // 0x831b28: AllocStack(0x28)
    //     0x831b28: sub             SP, SP, #0x28
    // 0x831b2c: CheckStackOverflow
    //     0x831b2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x831b30: cmp             SP, x16
    //     0x831b34: b.ls            #0x831cb0
    // 0x831b38: r1 = 2
    //     0x831b38: mov             x1, #2
    // 0x831b3c: r0 = AllocateContext()
    //     0x831b3c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x831b40: mov             x1, x0
    // 0x831b44: ldr             x0, [fp, #0x18]
    // 0x831b48: stur            x1, [fp, #-8]
    // 0x831b4c: StoreField: r1->field_f = r0
    //     0x831b4c: stur            w0, [x1, #0xf]
    // 0x831b50: ldr             x16, [fp, #0x10]
    // 0x831b54: stp             x16, x0, [SP, #-0x10]!
    // 0x831b58: r0 = _getDirection()
    //     0x831b58: bl              #0x831cfc  ; [package:flutter/src/widgets/page_view.dart] _PageViewState::_getDirection
    // 0x831b5c: add             SP, SP, #0x10
    // 0x831b60: mov             x1, x0
    // 0x831b64: ldur            x2, [fp, #-8]
    // 0x831b68: stur            x1, [fp, #-0x18]
    // 0x831b6c: StoreField: r2->field_13 = r0
    //     0x831b6c: stur            w0, [x2, #0x13]
    //     0x831b70: ldurb           w16, [x2, #-1]
    //     0x831b74: ldurb           w17, [x0, #-1]
    //     0x831b78: and             x16, x17, x16, lsr #2
    //     0x831b7c: tst             x16, HEAP, lsr #32
    //     0x831b80: b.eq            #0x831b88
    //     0x831b84: bl              #0xd6828c
    // 0x831b88: ldr             x0, [fp, #0x18]
    // 0x831b8c: LoadField: r3 = r0->field_b
    //     0x831b8c: ldur            w3, [x0, #0xb]
    // 0x831b90: DecompressPointer r3
    //     0x831b90: add             x3, x3, HEAP, lsl #32
    // 0x831b94: stur            x3, [fp, #-0x10]
    // 0x831b98: cmp             w3, NULL
    // 0x831b9c: b.eq            #0x831cb8
    // 0x831ba0: r0 = _ForceImplicitScrollPhysics()
    //     0x831ba0: bl              #0x831cf0  ; Allocate_ForceImplicitScrollPhysicsStub -> _ForceImplicitScrollPhysics (size=0x10)
    // 0x831ba4: mov             x1, x0
    // 0x831ba8: r0 = false
    //     0x831ba8: add             x0, NULL, #0x30  ; false
    // 0x831bac: stur            x1, [fp, #-0x20]
    // 0x831bb0: StoreField: r1->field_b = r0
    //     0x831bb0: stur            w0, [x1, #0xb]
    // 0x831bb4: ldur            x2, [fp, #-0x10]
    // 0x831bb8: LoadField: r3 = r2->field_1f
    //     0x831bb8: ldur            w3, [x2, #0x1f]
    // 0x831bbc: DecompressPointer r3
    //     0x831bbc: add             x3, x3, HEAP, lsl #32
    // 0x831bc0: r16 = Instance_PageScrollPhysics
    //     0x831bc0: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2f408] Obj!PageScrollPhysics@b4fdc1
    //     0x831bc4: ldr             x16, [x16, #0x408]
    // 0x831bc8: stp             x3, x16, [SP, #-0x10]!
    // 0x831bcc: r0 = applyTo()
    //     0x831bcc: bl              #0xc3b304  ; [package:flutter/src/widgets/page_view.dart] PageScrollPhysics::applyTo
    // 0x831bd0: add             SP, SP, #0x10
    // 0x831bd4: ldur            x16, [fp, #-0x20]
    // 0x831bd8: stp             x0, x16, [SP, #-0x10]!
    // 0x831bdc: r0 = applyTo()
    //     0x831bdc: bl              #0xc3b254  ; [package:extended_tabs/src/page_view.dart] _ForceImplicitScrollPhysics::applyTo
    // 0x831be0: add             SP, SP, #0x10
    // 0x831be4: mov             x1, x0
    // 0x831be8: ldr             x0, [fp, #0x18]
    // 0x831bec: stur            x1, [fp, #-0x20]
    // 0x831bf0: LoadField: r2 = r0->field_b
    //     0x831bf0: ldur            w2, [x0, #0xb]
    // 0x831bf4: DecompressPointer r2
    //     0x831bf4: add             x2, x2, HEAP, lsl #32
    // 0x831bf8: cmp             w2, NULL
    // 0x831bfc: b.eq            #0x831cbc
    // 0x831c00: LoadField: r0 = r2->field_1b
    //     0x831c00: ldur            w0, [x2, #0x1b]
    // 0x831c04: DecompressPointer r0
    //     0x831c04: add             x0, x0, HEAP, lsl #32
    // 0x831c08: stur            x0, [fp, #-0x10]
    // 0x831c0c: r0 = ExtendedScrollable()
    //     0x831c0c: bl              #0x831ce4  ; AllocateExtendedScrollableStub -> ExtendedScrollable (size=0x3c)
    // 0x831c10: mov             x3, x0
    // 0x831c14: r0 = true
    //     0x831c14: add             x0, NULL, #0x20  ; true
    // 0x831c18: stur            x3, [fp, #-0x28]
    // 0x831c1c: StoreField: r3->field_37 = r0
    //     0x831c1c: stur            w0, [x3, #0x37]
    // 0x831c20: ldur            x0, [fp, #-0x18]
    // 0x831c24: StoreField: r3->field_b = r0
    //     0x831c24: stur            w0, [x3, #0xb]
    // 0x831c28: ldur            x0, [fp, #-0x10]
    // 0x831c2c: StoreField: r3->field_f = r0
    //     0x831c2c: stur            w0, [x3, #0xf]
    // 0x831c30: ldur            x0, [fp, #-0x20]
    // 0x831c34: StoreField: r3->field_13 = r0
    //     0x831c34: stur            w0, [x3, #0x13]
    // 0x831c38: ldur            x2, [fp, #-8]
    // 0x831c3c: r1 = Function '<anonymous closure>':.
    //     0x831c3c: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c008] AnonymousClosure: (0x831df8), in [package:extended_tabs/src/page_view.dart] _ExtendedPageViewState::build (0x831b20)
    //     0x831c40: ldr             x1, [x1, #8]
    // 0x831c44: r0 = AllocateClosure()
    //     0x831c44: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x831c48: mov             x1, x0
    // 0x831c4c: ldur            x0, [fp, #-0x28]
    // 0x831c50: StoreField: r0->field_17 = r1
    //     0x831c50: stur            w1, [x0, #0x17]
    // 0x831c54: r1 = false
    //     0x831c54: add             x1, NULL, #0x30  ; false
    // 0x831c58: StoreField: r0->field_1f = r1
    //     0x831c58: stur            w1, [x0, #0x1f]
    // 0x831c5c: r1 = Instance_DragStartBehavior
    //     0x831c5c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f88] Obj!DragStartBehavior@b65af1
    //     0x831c60: ldr             x1, [x1, #0xf88]
    // 0x831c64: StoreField: r0->field_27 = r1
    //     0x831c64: stur            w1, [x0, #0x27]
    // 0x831c68: r1 = Instance_Clip
    //     0x831c68: add             x1, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x831c6c: ldr             x1, [x1, #0x678]
    // 0x831c70: StoreField: r0->field_33 = r1
    //     0x831c70: stur            w1, [x0, #0x33]
    // 0x831c74: ldur            x2, [fp, #-8]
    // 0x831c78: r1 = Function '<anonymous closure>':.
    //     0x831c78: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c010] AnonymousClosure: (0x831dac), in [package:extended_tabs/src/page_view.dart] _ExtendedPageViewState::build (0x831b20)
    //     0x831c7c: ldr             x1, [x1, #0x10]
    // 0x831c80: r0 = AllocateClosure()
    //     0x831c80: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x831c84: r1 = <ScrollNotification>
    //     0x831c84: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2ccf8] TypeArguments: <ScrollNotification>
    //     0x831c88: ldr             x1, [x1, #0xcf8]
    // 0x831c8c: stur            x0, [fp, #-8]
    // 0x831c90: r0 = NotificationListener()
    //     0x831c90: bl              #0x7bb850  ; AllocateNotificationListenerStub -> NotificationListener<X0 bound Notification> (size=0x18)
    // 0x831c94: ldur            x1, [fp, #-8]
    // 0x831c98: StoreField: r0->field_13 = r1
    //     0x831c98: stur            w1, [x0, #0x13]
    // 0x831c9c: ldur            x1, [fp, #-0x28]
    // 0x831ca0: StoreField: r0->field_b = r1
    //     0x831ca0: stur            w1, [x0, #0xb]
    // 0x831ca4: LeaveFrame
    //     0x831ca4: mov             SP, fp
    //     0x831ca8: ldp             fp, lr, [SP], #0x10
    // 0x831cac: ret
    //     0x831cac: ret             
    // 0x831cb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x831cb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x831cb4: b               #0x831b38
    // 0x831cb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x831cb8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x831cbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x831cbc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, ScrollNotification) {
    // ** addr: 0x831dac, size: 0x4c
    // 0x831dac: EnterFrame
    //     0x831dac: stp             fp, lr, [SP, #-0x10]!
    //     0x831db0: mov             fp, SP
    // 0x831db4: ldr             x1, [fp, #0x18]
    // 0x831db8: LoadField: r2 = r1->field_17
    //     0x831db8: ldur            w2, [x1, #0x17]
    // 0x831dbc: DecompressPointer r2
    //     0x831dbc: add             x2, x2, HEAP, lsl #32
    // 0x831dc0: ldr             x1, [fp, #0x10]
    // 0x831dc4: LoadField: r3 = r1->field_7
    //     0x831dc4: ldur            x3, [x1, #7]
    // 0x831dc8: cbnz            x3, #0x831de4
    // 0x831dcc: LoadField: r1 = r2->field_f
    //     0x831dcc: ldur            w1, [x2, #0xf]
    // 0x831dd0: DecompressPointer r1
    //     0x831dd0: add             x1, x1, HEAP, lsl #32
    // 0x831dd4: LoadField: r2 = r1->field_b
    //     0x831dd4: ldur            w2, [x1, #0xb]
    // 0x831dd8: DecompressPointer r2
    //     0x831dd8: add             x2, x2, HEAP, lsl #32
    // 0x831ddc: cmp             w2, NULL
    // 0x831de0: b.eq            #0x831df4
    // 0x831de4: r0 = false
    //     0x831de4: add             x0, NULL, #0x30  ; false
    // 0x831de8: LeaveFrame
    //     0x831de8: mov             SP, fp
    //     0x831dec: ldp             fp, lr, [SP], #0x10
    // 0x831df0: ret
    //     0x831df0: ret             
    // 0x831df4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x831df4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Viewport <anonymous closure>(dynamic, BuildContext, ViewportOffset) {
    // ** addr: 0x831df8, size: 0x118
    // 0x831df8: EnterFrame
    //     0x831df8: stp             fp, lr, [SP, #-0x10]!
    //     0x831dfc: mov             fp, SP
    // 0x831e00: AllocStack(0x20)
    //     0x831e00: sub             SP, SP, #0x20
    // 0x831e04: SetupParameters()
    //     0x831e04: ldr             x0, [fp, #0x20]
    //     0x831e08: ldur            w1, [x0, #0x17]
    //     0x831e0c: add             x1, x1, HEAP, lsl #32
    //     0x831e10: stur            x1, [fp, #-0x10]
    // 0x831e14: LoadField: r0 = r1->field_f
    //     0x831e14: ldur            w0, [x1, #0xf]
    // 0x831e18: DecompressPointer r0
    //     0x831e18: add             x0, x0, HEAP, lsl #32
    // 0x831e1c: LoadField: r2 = r0->field_b
    //     0x831e1c: ldur            w2, [x0, #0xb]
    // 0x831e20: DecompressPointer r2
    //     0x831e20: add             x2, x2, HEAP, lsl #32
    // 0x831e24: cmp             w2, NULL
    // 0x831e28: b.eq            #0x831f0c
    // 0x831e2c: LoadField: r0 = r2->field_1b
    //     0x831e2c: ldur            w0, [x2, #0x1b]
    // 0x831e30: DecompressPointer r0
    //     0x831e30: add             x0, x0, HEAP, lsl #32
    // 0x831e34: LoadField: d0 = r0->field_43
    //     0x831e34: ldur            d0, [x0, #0x43]
    // 0x831e38: stur            d0, [fp, #-0x20]
    // 0x831e3c: LoadField: r0 = r2->field_2b
    //     0x831e3c: ldur            w0, [x2, #0x2b]
    // 0x831e40: DecompressPointer r0
    //     0x831e40: add             x0, x0, HEAP, lsl #32
    // 0x831e44: stur            x0, [fp, #-8]
    // 0x831e48: r0 = SliverFillViewport()
    //     0x831e48: bl              #0x831f10  ; AllocateSliverFillViewportStub -> SliverFillViewport (size=0x1c)
    // 0x831e4c: mov             x3, x0
    // 0x831e50: ldur            x0, [fp, #-8]
    // 0x831e54: stur            x3, [fp, #-0x18]
    // 0x831e58: StoreField: r3->field_17 = r0
    //     0x831e58: stur            w0, [x3, #0x17]
    // 0x831e5c: ldur            d0, [fp, #-0x20]
    // 0x831e60: StoreField: r3->field_b = d0
    //     0x831e60: stur            d0, [x3, #0xb]
    // 0x831e64: r0 = true
    //     0x831e64: add             x0, NULL, #0x20  ; true
    // 0x831e68: StoreField: r3->field_13 = r0
    //     0x831e68: stur            w0, [x3, #0x13]
    // 0x831e6c: r1 = Null
    //     0x831e6c: mov             x1, NULL
    // 0x831e70: r2 = 2
    //     0x831e70: mov             x2, #2
    // 0x831e74: r0 = AllocateArray()
    //     0x831e74: bl              #0xd6987c  ; AllocateArrayStub
    // 0x831e78: mov             x2, x0
    // 0x831e7c: ldur            x0, [fp, #-0x18]
    // 0x831e80: stur            x2, [fp, #-8]
    // 0x831e84: StoreField: r2->field_f = r0
    //     0x831e84: stur            w0, [x2, #0xf]
    // 0x831e88: r1 = <Widget>
    //     0x831e88: add             x1, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x831e8c: ldr             x1, [x1, #0xea8]
    // 0x831e90: r0 = AllocateGrowableArray()
    //     0x831e90: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x831e94: mov             x1, x0
    // 0x831e98: ldur            x0, [fp, #-8]
    // 0x831e9c: stur            x1, [fp, #-0x18]
    // 0x831ea0: StoreField: r1->field_f = r0
    //     0x831ea0: stur            w0, [x1, #0xf]
    // 0x831ea4: r0 = 2
    //     0x831ea4: mov             x0, #2
    // 0x831ea8: StoreField: r1->field_b = r0
    //     0x831ea8: stur            w0, [x1, #0xb]
    // 0x831eac: ldur            x0, [fp, #-0x10]
    // 0x831eb0: LoadField: r2 = r0->field_13
    //     0x831eb0: ldur            w2, [x0, #0x13]
    // 0x831eb4: DecompressPointer r2
    //     0x831eb4: add             x2, x2, HEAP, lsl #32
    // 0x831eb8: stur            x2, [fp, #-8]
    // 0x831ebc: r0 = Viewport()
    //     0x831ebc: bl              #0x82fea8  ; AllocateViewportStub -> Viewport (size=0x34)
    // 0x831ec0: ldur            x1, [fp, #-8]
    // 0x831ec4: StoreField: r0->field_f = r1
    //     0x831ec4: stur            w1, [x0, #0xf]
    // 0x831ec8: d0 = 0.000000
    //     0x831ec8: eor             v0.16b, v0.16b, v0.16b
    // 0x831ecc: StoreField: r0->field_17 = d0
    //     0x831ecc: stur            d0, [x0, #0x17]
    // 0x831ed0: ldr             x1, [fp, #0x10]
    // 0x831ed4: StoreField: r0->field_1f = r1
    //     0x831ed4: stur            w1, [x0, #0x1f]
    // 0x831ed8: r1 = 0.000000
    //     0x831ed8: ldr             x1, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x831edc: StoreField: r0->field_27 = r1
    //     0x831edc: stur            w1, [x0, #0x27]
    // 0x831ee0: r1 = Instance_CacheExtentStyle
    //     0x831ee0: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c018] Obj!CacheExtentStyle@b64731
    //     0x831ee4: ldr             x1, [x1, #0x18]
    // 0x831ee8: StoreField: r0->field_2b = r1
    //     0x831ee8: stur            w1, [x0, #0x2b]
    // 0x831eec: r1 = Instance_Clip
    //     0x831eec: add             x1, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x831ef0: ldr             x1, [x1, #0x678]
    // 0x831ef4: StoreField: r0->field_2f = r1
    //     0x831ef4: stur            w1, [x0, #0x2f]
    // 0x831ef8: ldur            x1, [fp, #-0x18]
    // 0x831efc: StoreField: r0->field_b = r1
    //     0x831efc: stur            w1, [x0, #0xb]
    // 0x831f00: LeaveFrame
    //     0x831f00: mov             SP, fp
    //     0x831f04: ldp             fp, lr, [SP], #0x10
    // 0x831f08: ret
    //     0x831f08: ret             
    // 0x831f0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x831f0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4203, size: 0x44, field offset: 0xc
class ExtendedPageView extends StatefulWidget {

  _ ExtendedPageView(/* No info */) {
    // ** addr: 0x833900, size: 0xf4
    // 0x833900: EnterFrame
    //     0x833900: stp             fp, lr, [SP, #-0x10]!
    //     0x833904: mov             fp, SP
    // 0x833908: AllocStack(0x8)
    //     0x833908: sub             SP, SP, #8
    // 0x83390c: r0 = Instance_Axis
    //     0x83390c: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x833910: ldr             x0, [x0, #0x440]
    // 0x833914: r5 = false
    //     0x833914: add             x5, NULL, #0x30  ; false
    // 0x833918: r4 = true
    //     0x833918: add             x4, NULL, #0x20  ; true
    // 0x83391c: r3 = Instance_DragStartBehavior
    //     0x83391c: add             x3, PP, #0x14, lsl #12  ; [pp+0x14f88] Obj!DragStartBehavior@b65af1
    //     0x833920: ldr             x3, [x3, #0xf88]
    // 0x833924: r2 = Instance_Clip
    //     0x833924: add             x2, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x833928: ldr             x2, [x2, #0x678]
    // 0x83392c: r1 = 0
    //     0x83392c: mov             x1, #0
    // 0x833930: CheckStackOverflow
    //     0x833930: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x833934: cmp             SP, x16
    //     0x833938: b.ls            #0x8339ec
    // 0x83393c: ldr             x6, [fp, #0x28]
    // 0x833940: StoreField: r6->field_13 = r0
    //     0x833940: stur            w0, [x6, #0x13]
    // 0x833944: StoreField: r6->field_17 = r5
    //     0x833944: stur            w5, [x6, #0x17]
    // 0x833948: ldr             x0, [fp, #0x10]
    // 0x83394c: StoreField: r6->field_1f = r0
    //     0x83394c: stur            w0, [x6, #0x1f]
    //     0x833950: ldurb           w16, [x6, #-1]
    //     0x833954: ldurb           w17, [x0, #-1]
    //     0x833958: and             x16, x17, x16, lsr #2
    //     0x83395c: tst             x16, HEAP, lsr #32
    //     0x833960: b.eq            #0x833968
    //     0x833964: bl              #0xd6830c
    // 0x833968: StoreField: r6->field_23 = r4
    //     0x833968: stur            w4, [x6, #0x23]
    // 0x83396c: StoreField: r6->field_2f = r3
    //     0x83396c: stur            w3, [x6, #0x2f]
    // 0x833970: StoreField: r6->field_b = r5
    //     0x833970: stur            w5, [x6, #0xb]
    // 0x833974: StoreField: r6->field_33 = r2
    //     0x833974: stur            w2, [x6, #0x33]
    // 0x833978: StoreField: r6->field_37 = r1
    //     0x833978: stur            x1, [x6, #0x37]
    // 0x83397c: StoreField: r6->field_3f = r4
    //     0x83397c: stur            w4, [x6, #0x3f]
    // 0x833980: ldr             x0, [fp, #0x18]
    // 0x833984: StoreField: r6->field_1b = r0
    //     0x833984: stur            w0, [x6, #0x1b]
    //     0x833988: ldurb           w16, [x6, #-1]
    //     0x83398c: ldurb           w17, [x0, #-1]
    //     0x833990: and             x16, x17, x16, lsr #2
    //     0x833994: tst             x16, HEAP, lsr #32
    //     0x833998: b.eq            #0x8339a0
    //     0x83399c: bl              #0xd6830c
    // 0x8339a0: r0 = SliverChildListDelegate()
    //     0x8339a0: bl              #0x825fe8  ; AllocateSliverChildListDelegateStub -> SliverChildListDelegate (size=0x28)
    // 0x8339a4: stur            x0, [fp, #-8]
    // 0x8339a8: ldr             x16, [fp, #0x20]
    // 0x8339ac: stp             x16, x0, [SP, #-0x10]!
    // 0x8339b0: r0 = SliverChildListDelegate()
    //     0x8339b0: bl              #0x825ef8  ; [package:flutter/src/widgets/sliver.dart] SliverChildListDelegate::SliverChildListDelegate
    // 0x8339b4: add             SP, SP, #0x10
    // 0x8339b8: ldur            x0, [fp, #-8]
    // 0x8339bc: ldr             x1, [fp, #0x28]
    // 0x8339c0: StoreField: r1->field_2b = r0
    //     0x8339c0: stur            w0, [x1, #0x2b]
    //     0x8339c4: ldurb           w16, [x1, #-1]
    //     0x8339c8: ldurb           w17, [x0, #-1]
    //     0x8339cc: and             x16, x17, x16, lsr #2
    //     0x8339d0: tst             x16, HEAP, lsr #32
    //     0x8339d4: b.eq            #0x8339dc
    //     0x8339d8: bl              #0xd6826c
    // 0x8339dc: r0 = Null
    //     0x8339dc: mov             x0, NULL
    // 0x8339e0: LeaveFrame
    //     0x8339e0: mov             SP, fp
    //     0x8339e4: ldp             fp, lr, [SP], #0x10
    // 0x8339e8: ret
    //     0x8339e8: ret             
    // 0x8339ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8339ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8339f0: b               #0x83393c
  }
  _ createState(/* No info */) {
    // ** addr: 0xa3f76c, size: 0x28
    // 0xa3f76c: EnterFrame
    //     0xa3f76c: stp             fp, lr, [SP, #-0x10]!
    //     0xa3f770: mov             fp, SP
    // 0xa3f774: r1 = <ExtendedPageView>
    //     0xa3f774: add             x1, PP, #0x40, lsl #12  ; [pp+0x40d48] TypeArguments: <ExtendedPageView>
    //     0xa3f778: ldr             x1, [x1, #0xd48]
    // 0xa3f77c: r0 = _ExtendedPageViewState()
    //     0xa3f77c: bl              #0xa3f794  ; Allocate_ExtendedPageViewStateStub -> _ExtendedPageViewState (size=0x1c)
    // 0xa3f780: r1 = 0
    //     0xa3f780: mov             x1, #0
    // 0xa3f784: StoreField: r0->field_13 = r1
    //     0xa3f784: stur            x1, [x0, #0x13]
    // 0xa3f788: LeaveFrame
    //     0xa3f788: mov             SP, fp
    //     0xa3f78c: ldp             fp, lr, [SP], #0x10
    // 0xa3f790: ret
    //     0xa3f790: ret             
  }
}

// class id: 4493, size: 0x10, field offset: 0xc
//   const constructor, 
class _ForceImplicitScrollPhysics extends ScrollPhysics {

  _ applyTo(/* No info */) {
    // ** addr: 0xc3b254, size: 0x58
    // 0xc3b254: EnterFrame
    //     0xc3b254: stp             fp, lr, [SP, #-0x10]!
    //     0xc3b258: mov             fp, SP
    // 0xc3b25c: AllocStack(0x8)
    //     0xc3b25c: sub             SP, SP, #8
    // 0xc3b260: CheckStackOverflow
    //     0xc3b260: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3b264: cmp             SP, x16
    //     0xc3b268: b.ls            #0xc3b2a4
    // 0xc3b26c: ldr             x16, [fp, #0x18]
    // 0xc3b270: ldr             lr, [fp, #0x10]
    // 0xc3b274: stp             lr, x16, [SP, #-0x10]!
    // 0xc3b278: r0 = buildParent()
    //     0xc3b278: bl              #0xc3b1d4  ; [package:flutter/src/widgets/scroll_physics.dart] ScrollPhysics::buildParent
    // 0xc3b27c: add             SP, SP, #0x10
    // 0xc3b280: stur            x0, [fp, #-8]
    // 0xc3b284: r0 = _ForceImplicitScrollPhysics()
    //     0xc3b284: bl              #0x831cf0  ; Allocate_ForceImplicitScrollPhysicsStub -> _ForceImplicitScrollPhysics (size=0x10)
    // 0xc3b288: r1 = false
    //     0xc3b288: add             x1, NULL, #0x30  ; false
    // 0xc3b28c: StoreField: r0->field_b = r1
    //     0xc3b28c: stur            w1, [x0, #0xb]
    // 0xc3b290: ldur            x1, [fp, #-8]
    // 0xc3b294: StoreField: r0->field_7 = r1
    //     0xc3b294: stur            w1, [x0, #7]
    // 0xc3b298: LeaveFrame
    //     0xc3b298: mov             SP, fp
    //     0xc3b29c: ldp             fp, lr, [SP], #0x10
    // 0xc3b2a0: ret
    //     0xc3b2a0: ret             
    // 0xc3b2a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3b2a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3b2a8: b               #0xc3b26c
  }
}

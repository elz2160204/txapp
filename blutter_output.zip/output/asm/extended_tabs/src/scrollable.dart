// lib: , url: package:extended_tabs/src/scrollable.dart

// class id: 1048964, size: 0x8
class :: {
}

// class id: 3391, size: 0x68, field offset: 0x68
class _ExtendedScrollableState extends ScrollableState {

  _ setIgnorePointer(/* No info */) {
    // ** addr: 0xce1d4c, size: 0x88
    // 0xce1d4c: EnterFrame
    //     0xce1d4c: stp             fp, lr, [SP, #-0x10]!
    //     0xce1d50: mov             fp, SP
    // 0xce1d54: CheckStackOverflow
    //     0xce1d54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce1d58: cmp             SP, x16
    //     0xce1d5c: b.ls            #0xce1dc8
    // 0xce1d60: ldr             x3, [fp, #0x18]
    // 0xce1d64: LoadField: r0 = r3->field_b
    //     0xce1d64: ldur            w0, [x3, #0xb]
    // 0xce1d68: DecompressPointer r0
    //     0xce1d68: add             x0, x0, HEAP, lsl #32
    // 0xce1d6c: cmp             w0, NULL
    // 0xce1d70: b.eq            #0xce1dd0
    // 0xce1d74: r2 = Null
    //     0xce1d74: mov             x2, NULL
    // 0xce1d78: r1 = Null
    //     0xce1d78: mov             x1, NULL
    // 0xce1d7c: r4 = LoadClassIdInstr(r0)
    //     0xce1d7c: ldur            x4, [x0, #-1]
    //     0xce1d80: ubfx            x4, x4, #0xc, #0x14
    // 0xce1d84: r17 = 4209
    //     0xce1d84: mov             x17, #0x1071
    // 0xce1d88: cmp             x4, x17
    // 0xce1d8c: b.eq            #0xce1da4
    // 0xce1d90: r8 = ExtendedScrollable
    //     0xce1d90: add             x8, PP, #0x53, lsl #12  ; [pp+0x536b0] Type: ExtendedScrollable
    //     0xce1d94: ldr             x8, [x8, #0x6b0]
    // 0xce1d98: r3 = Null
    //     0xce1d98: add             x3, PP, #0x53, lsl #12  ; [pp+0x536b8] Null
    //     0xce1d9c: ldr             x3, [x3, #0x6b8]
    // 0xce1da0: r0 = DefaultTypeTest()
    //     0xce1da0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xce1da4: ldr             x16, [fp, #0x18]
    // 0xce1da8: ldr             lr, [fp, #0x10]
    // 0xce1dac: stp             lr, x16, [SP, #-0x10]!
    // 0xce1db0: r0 = setIgnorePointer()
    //     0xce1db0: bl              #0xce1dd4  ; [package:flutter/src/widgets/scrollable.dart] ScrollableState::setIgnorePointer
    // 0xce1db4: add             SP, SP, #0x10
    // 0xce1db8: r0 = Null
    //     0xce1db8: mov             x0, NULL
    // 0xce1dbc: LeaveFrame
    //     0xce1dbc: mov             SP, fp
    //     0xce1dc0: ldp             fp, lr, [SP], #0x10
    // 0xce1dc4: ret
    //     0xce1dc4: ret             
    // 0xce1dc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce1dc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce1dcc: b               #0xce1d60
    // 0xce1dd0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xce1dd0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4209, size: 0x3c, field offset: 0x38
//   const constructor, 
class ExtendedScrollable extends Scrollable {

  _ createState(/* No info */) {
    // ** addr: 0xa3f61c, size: 0x4c
    // 0xa3f61c: EnterFrame
    //     0xa3f61c: stp             fp, lr, [SP, #-0x10]!
    //     0xa3f620: mov             fp, SP
    // 0xa3f624: AllocStack(0x8)
    //     0xa3f624: sub             SP, SP, #8
    // 0xa3f628: CheckStackOverflow
    //     0xa3f628: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa3f62c: cmp             SP, x16
    //     0xa3f630: b.ls            #0xa3f660
    // 0xa3f634: r1 = <Scrollable>
    //     0xa3f634: add             x1, PP, #0x38, lsl #12  ; [pp+0x38468] TypeArguments: <Scrollable>
    //     0xa3f638: ldr             x1, [x1, #0x468]
    // 0xa3f63c: r0 = _ExtendedScrollableState()
    //     0xa3f63c: bl              #0xa3f668  ; Allocate_ExtendedScrollableStateStub -> _ExtendedScrollableState (size=0x68)
    // 0xa3f640: stur            x0, [fp, #-8]
    // 0xa3f644: SaveReg r0
    //     0xa3f644: str             x0, [SP, #-8]!
    // 0xa3f648: r0 = ScrollableState()
    //     0xa3f648: bl              #0xa3f480  ; [package:flutter/src/widgets/scrollable.dart] ScrollableState::ScrollableState
    // 0xa3f64c: add             SP, SP, #8
    // 0xa3f650: ldur            x0, [fp, #-8]
    // 0xa3f654: LeaveFrame
    //     0xa3f654: mov             SP, fp
    //     0xa3f658: ldp             fp, lr, [SP], #0x10
    // 0xa3f65c: ret
    //     0xa3f65c: ret             
    // 0xa3f660: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa3f660: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa3f664: b               #0xa3f634
  }
}

// lib: , url: package:extended_tabs/src/tab_view.dart

// class id: 1048967, size: 0x8
class :: {
}

// class id: 3379, size: 0x38, field offset: 0x1c
class ExtendedTabBarViewState extends LinkScrollState<ExtendedTabBarView> {

  late LinkPageController _pageController; // offset: 0x20

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7a0418, size: 0x2ec
    // 0x7a0418: EnterFrame
    //     0x7a0418: stp             fp, lr, [SP, #-0x10]!
    //     0x7a041c: mov             fp, SP
    // 0x7a0420: AllocStack(0x10)
    //     0x7a0420: sub             SP, SP, #0x10
    // 0x7a0424: CheckStackOverflow
    //     0x7a0424: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a0428: cmp             SP, x16
    //     0x7a042c: b.ls            #0x7a06e8
    // 0x7a0430: ldr             x0, [fp, #0x10]
    // 0x7a0434: r2 = Null
    //     0x7a0434: mov             x2, NULL
    // 0x7a0438: r1 = Null
    //     0x7a0438: mov             x1, NULL
    // 0x7a043c: r4 = 59
    //     0x7a043c: mov             x4, #0x3b
    // 0x7a0440: branchIfSmi(r0, 0x7a044c)
    //     0x7a0440: tbz             w0, #0, #0x7a044c
    // 0x7a0444: r4 = LoadClassIdInstr(r0)
    //     0x7a0444: ldur            x4, [x0, #-1]
    //     0x7a0448: ubfx            x4, x4, #0xc, #0x14
    // 0x7a044c: r17 = 4190
    //     0x7a044c: mov             x17, #0x105e
    // 0x7a0450: cmp             x4, x17
    // 0x7a0454: b.eq            #0x7a046c
    // 0x7a0458: r8 = ExtendedTabBarView
    //     0x7a0458: add             x8, PP, #0x38, lsl #12  ; [pp+0x381c0] Type: ExtendedTabBarView
    //     0x7a045c: ldr             x8, [x8, #0x1c0]
    // 0x7a0460: r3 = Null
    //     0x7a0460: add             x3, PP, #0x38, lsl #12  ; [pp+0x381c8] Null
    //     0x7a0464: ldr             x3, [x3, #0x1c8]
    // 0x7a0468: r0 = ExtendedTabBarView()
    //     0x7a0468: bl              #0x7a24d0  ; IsType_ExtendedTabBarView_Stub
    // 0x7a046c: ldr             x0, [fp, #0x18]
    // 0x7a0470: LoadField: r1 = r0->field_b
    //     0x7a0470: ldur            w1, [x0, #0xb]
    // 0x7a0474: DecompressPointer r1
    //     0x7a0474: add             x1, x1, HEAP, lsl #32
    // 0x7a0478: cmp             w1, NULL
    // 0x7a047c: b.eq            #0x7a06f0
    // 0x7a0480: LoadField: r2 = r1->field_17
    //     0x7a0480: ldur            w2, [x1, #0x17]
    // 0x7a0484: DecompressPointer r2
    //     0x7a0484: add             x2, x2, HEAP, lsl #32
    // 0x7a0488: ldr             x1, [fp, #0x10]
    // 0x7a048c: LoadField: r3 = r1->field_17
    //     0x7a048c: ldur            w3, [x1, #0x17]
    // 0x7a0490: DecompressPointer r3
    //     0x7a0490: add             x3, x3, HEAP, lsl #32
    // 0x7a0494: cmp             w2, w3
    // 0x7a0498: b.eq            #0x7a0500
    // 0x7a049c: SaveReg r0
    //     0x7a049c: str             x0, [SP, #-8]!
    // 0x7a04a0: r0 = _updateTabController()
    //     0x7a04a0: bl              #0x7a1668  ; [package:extended_tabs/src/tab_view.dart] ExtendedTabBarViewState::_updateTabController
    // 0x7a04a4: add             SP, SP, #8
    // 0x7a04a8: ldr             x2, [fp, #0x18]
    // 0x7a04ac: LoadField: r0 = r2->field_1b
    //     0x7a04ac: ldur            w0, [x2, #0x1b]
    // 0x7a04b0: DecompressPointer r0
    //     0x7a04b0: add             x0, x0, HEAP, lsl #32
    // 0x7a04b4: cmp             w0, NULL
    // 0x7a04b8: b.ne            #0x7a04c4
    // 0x7a04bc: r0 = Null
    //     0x7a04bc: mov             x0, NULL
    // 0x7a04c0: b               #0x7a04dc
    // 0x7a04c4: LoadField: r3 = r0->field_33
    //     0x7a04c4: ldur            x3, [x0, #0x33]
    // 0x7a04c8: r0 = BoxInt64Instr(r3)
    //     0x7a04c8: sbfiz           x0, x3, #1, #0x1f
    //     0x7a04cc: cmp             x3, x0, asr #1
    //     0x7a04d0: b.eq            #0x7a04dc
    //     0x7a04d4: bl              #0xd69bb8
    //     0x7a04d8: stur            x3, [x0, #7]
    // 0x7a04dc: StoreField: r2->field_2b = r0
    //     0x7a04dc: stur            w0, [x2, #0x2b]
    //     0x7a04e0: tbz             w0, #0, #0x7a04fc
    //     0x7a04e4: ldurb           w16, [x2, #-1]
    //     0x7a04e8: ldurb           w17, [x0, #-1]
    //     0x7a04ec: and             x16, x17, x16, lsr #2
    //     0x7a04f0: tst             x16, HEAP, lsr #32
    //     0x7a04f4: b.eq            #0x7a04fc
    //     0x7a04f8: bl              #0xd6828c
    // 0x7a04fc: b               #0x7a0504
    // 0x7a0500: mov             x2, x0
    // 0x7a0504: d0 = 1.000000
    //     0x7a0504: fmov            d0, #1.00000000
    // 0x7a0508: LoadField: r0 = r2->field_b
    //     0x7a0508: ldur            w0, [x2, #0xb]
    // 0x7a050c: DecompressPointer r0
    //     0x7a050c: add             x0, x0, HEAP, lsl #32
    // 0x7a0510: cmp             w0, NULL
    // 0x7a0514: b.eq            #0x7a06f4
    // 0x7a0518: fcmp            d0, d0
    // 0x7a051c: b.eq            #0x7a05b0
    // 0x7a0520: LoadField: r0 = r2->field_2b
    //     0x7a0520: ldur            w0, [x2, #0x2b]
    // 0x7a0524: DecompressPointer r0
    //     0x7a0524: add             x0, x0, HEAP, lsl #32
    // 0x7a0528: cmp             w0, NULL
    // 0x7a052c: b.ne            #0x7a0538
    // 0x7a0530: r0 = 0
    //     0x7a0530: mov             x0, #0
    // 0x7a0534: b               #0x7a0548
    // 0x7a0538: r1 = LoadInt32Instr(r0)
    //     0x7a0538: sbfx            x1, x0, #1, #0x1f
    //     0x7a053c: tbz             w0, #0, #0x7a0544
    //     0x7a0540: ldur            x1, [x0, #7]
    // 0x7a0544: mov             x0, x1
    // 0x7a0548: stur            x0, [fp, #-8]
    // 0x7a054c: r0 = LinkPageController()
    //     0x7a054c: bl              #0x7a165c  ; AllocateLinkPageControllerStub -> LinkPageController (size=0x5c)
    // 0x7a0550: mov             x1, x0
    // 0x7a0554: r0 = Sentinel
    //     0x7a0554: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7a0558: stur            x1, [fp, #-0x10]
    // 0x7a055c: StoreField: r1->field_4b = r0
    //     0x7a055c: stur            w0, [x1, #0x4b]
    // 0x7a0560: ldur            x0, [fp, #-8]
    // 0x7a0564: StoreField: r1->field_37 = r0
    //     0x7a0564: stur            x0, [x1, #0x37]
    // 0x7a0568: r0 = true
    //     0x7a0568: add             x0, NULL, #0x20  ; true
    // 0x7a056c: StoreField: r1->field_3f = r0
    //     0x7a056c: stur            w0, [x1, #0x3f]
    // 0x7a0570: d0 = 1.000000
    //     0x7a0570: fmov            d0, #1.00000000
    // 0x7a0574: StoreField: r1->field_43 = d0
    //     0x7a0574: stur            d0, [x1, #0x43]
    // 0x7a0578: SaveReg r1
    //     0x7a0578: str             x1, [SP, #-8]!
    // 0x7a057c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7a057c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7a0580: r0 = ScrollController()
    //     0x7a0580: bl              #0x51ee1c  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0x7a0584: add             SP, SP, #8
    // 0x7a0588: ldur            x0, [fp, #-0x10]
    // 0x7a058c: ldr             x1, [fp, #0x18]
    // 0x7a0590: StoreField: r1->field_1f = r0
    //     0x7a0590: stur            w0, [x1, #0x1f]
    //     0x7a0594: ldurb           w16, [x1, #-1]
    //     0x7a0598: ldurb           w17, [x0, #-1]
    //     0x7a059c: and             x16, x17, x16, lsr #2
    //     0x7a05a0: tst             x16, HEAP, lsr #32
    //     0x7a05a4: b.eq            #0x7a05ac
    //     0x7a05a8: bl              #0xd6826c
    // 0x7a05ac: b               #0x7a05b4
    // 0x7a05b0: mov             x1, x2
    // 0x7a05b4: ldr             x2, [fp, #0x10]
    // 0x7a05b8: LoadField: r0 = r1->field_b
    //     0x7a05b8: ldur            w0, [x1, #0xb]
    // 0x7a05bc: DecompressPointer r0
    //     0x7a05bc: add             x0, x0, HEAP, lsl #32
    // 0x7a05c0: cmp             w0, NULL
    // 0x7a05c4: b.eq            #0x7a06f8
    // 0x7a05c8: LoadField: r3 = r0->field_1f
    //     0x7a05c8: ldur            w3, [x0, #0x1f]
    // 0x7a05cc: DecompressPointer r3
    //     0x7a05cc: add             x3, x3, HEAP, lsl #32
    // 0x7a05d0: LoadField: r4 = r2->field_1f
    //     0x7a05d0: ldur            w4, [x2, #0x1f]
    // 0x7a05d4: DecompressPointer r4
    //     0x7a05d4: add             x4, x4, HEAP, lsl #32
    // 0x7a05d8: stur            x4, [fp, #-0x10]
    // 0x7a05dc: r0 = LoadClassIdInstr(r3)
    //     0x7a05dc: ldur            x0, [x3, #-1]
    //     0x7a05e0: ubfx            x0, x0, #0xc, #0x14
    // 0x7a05e4: stp             x4, x3, [SP, #-0x10]!
    // 0x7a05e8: mov             lr, x0
    // 0x7a05ec: ldr             lr, [x21, lr, lsl #3]
    // 0x7a05f0: blr             lr
    // 0x7a05f4: add             SP, SP, #0x10
    // 0x7a05f8: tbz             w0, #4, #0x7a060c
    // 0x7a05fc: ldr             x16, [fp, #0x18]
    // 0x7a0600: SaveReg r16
    //     0x7a0600: str             x16, [SP, #-8]!
    // 0x7a0604: r0 = updatePhysics()
    //     0x7a0604: bl              #0x7a1568  ; [package:sync_scroll_library/src/gesture/gesture_state_mixin.dart] GestureStateMixin::updatePhysics
    // 0x7a0608: add             SP, SP, #8
    // 0x7a060c: ldr             x1, [fp, #0x18]
    // 0x7a0610: ldr             x2, [fp, #0x10]
    // 0x7a0614: LoadField: r0 = r1->field_b
    //     0x7a0614: ldur            w0, [x1, #0xb]
    // 0x7a0618: DecompressPointer r0
    //     0x7a0618: add             x0, x0, HEAP, lsl #32
    // 0x7a061c: cmp             w0, NULL
    // 0x7a0620: b.eq            #0x7a06fc
    // 0x7a0624: LoadField: r3 = r0->field_1b
    //     0x7a0624: ldur            w3, [x0, #0x1b]
    // 0x7a0628: DecompressPointer r3
    //     0x7a0628: add             x3, x3, HEAP, lsl #32
    // 0x7a062c: LoadField: r0 = r2->field_1b
    //     0x7a062c: ldur            w0, [x2, #0x1b]
    // 0x7a0630: DecompressPointer r0
    //     0x7a0630: add             x0, x0, HEAP, lsl #32
    // 0x7a0634: r4 = LoadClassIdInstr(r3)
    //     0x7a0634: ldur            x4, [x3, #-1]
    //     0x7a0638: ubfx            x4, x4, #0xc, #0x14
    // 0x7a063c: stp             x0, x3, [SP, #-0x10]!
    // 0x7a0640: mov             x0, x4
    // 0x7a0644: mov             lr, x0
    // 0x7a0648: ldr             lr, [x21, lr, lsl #3]
    // 0x7a064c: blr             lr
    // 0x7a0650: add             SP, SP, #0x10
    // 0x7a0654: tbz             w0, #4, #0x7a0670
    // 0x7a0658: ldr             x0, [fp, #0x18]
    // 0x7a065c: LoadField: r1 = r0->field_2f
    //     0x7a065c: ldur            x1, [x0, #0x2f]
    // 0x7a0660: cbnz            x1, #0x7a0670
    // 0x7a0664: SaveReg r0
    //     0x7a0664: str             x0, [SP, #-8]!
    // 0x7a0668: r0 = _updateChildren()
    //     0x7a0668: bl              #0x7a11d0  ; [package:extended_tabs/src/tab_view.dart] ExtendedTabBarViewState::_updateChildren
    // 0x7a066c: add             SP, SP, #8
    // 0x7a0670: ldr             x1, [fp, #0x18]
    // 0x7a0674: ldur            x0, [fp, #-0x10]
    // 0x7a0678: LoadField: r2 = r1->field_b
    //     0x7a0678: ldur            w2, [x1, #0xb]
    // 0x7a067c: DecompressPointer r2
    //     0x7a067c: add             x2, x2, HEAP, lsl #32
    // 0x7a0680: cmp             w2, NULL
    // 0x7a0684: b.eq            #0x7a0700
    // 0x7a0688: LoadField: r3 = r2->field_1f
    //     0x7a0688: ldur            w3, [x2, #0x1f]
    // 0x7a068c: DecompressPointer r3
    //     0x7a068c: add             x3, x3, HEAP, lsl #32
    // 0x7a0690: r2 = LoadClassIdInstr(r0)
    //     0x7a0690: ldur            x2, [x0, #-1]
    //     0x7a0694: ubfx            x2, x2, #0xc, #0x14
    // 0x7a0698: stp             x3, x0, [SP, #-0x10]!
    // 0x7a069c: mov             x0, x2
    // 0x7a06a0: mov             lr, x0
    // 0x7a06a4: ldr             lr, [x21, lr, lsl #3]
    // 0x7a06a8: blr             lr
    // 0x7a06ac: add             SP, SP, #0x10
    // 0x7a06b0: tbz             w0, #4, #0x7a06c4
    // 0x7a06b4: ldr             x16, [fp, #0x18]
    // 0x7a06b8: SaveReg r16
    //     0x7a06b8: str             x16, [SP, #-8]!
    // 0x7a06bc: r0 = initGestureRecognizers()
    //     0x7a06bc: bl              #0x7a0a00  ; [package:sync_scroll_library/src/gesture/gesture_state_mixin.dart] GestureStateMixin::initGestureRecognizers
    // 0x7a06c0: add             SP, SP, #8
    // 0x7a06c4: ldr             x16, [fp, #0x18]
    // 0x7a06c8: ldr             lr, [fp, #0x10]
    // 0x7a06cc: stp             lr, x16, [SP, #-0x10]!
    // 0x7a06d0: r0 = didUpdateWidget()
    //     0x7a06d0: bl              #0x7a0704  ; [package:sync_scroll_library/src/link/link_scroll_state.dart] LinkScrollState::didUpdateWidget
    // 0x7a06d4: add             SP, SP, #0x10
    // 0x7a06d8: r0 = Null
    //     0x7a06d8: mov             x0, NULL
    // 0x7a06dc: LeaveFrame
    //     0x7a06dc: mov             SP, fp
    //     0x7a06e0: ldp             fp, lr, [SP], #0x10
    // 0x7a06e4: ret
    //     0x7a06e4: ret             
    // 0x7a06e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a06e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a06ec: b               #0x7a0430
    // 0x7a06f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a06f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7a06f4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x7a06f4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x7a06f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a06f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7a06fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a06fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7a0700: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a0700: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ linkParent(/* No info */) {
    // ** addr: 0x7a0788, size: 0x48
    // 0x7a0788: EnterFrame
    //     0x7a0788: stp             fp, lr, [SP, #-0x10]!
    //     0x7a078c: mov             fp, SP
    // 0x7a0790: CheckStackOverflow
    //     0x7a0790: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a0794: cmp             SP, x16
    //     0x7a0798: b.ls            #0x7a07c8
    // 0x7a079c: r16 = <ExtendedTabBarView, ExtendedTabBarViewState<ExtendedTabBarView>>
    //     0x7a079c: add             x16, PP, #0x37, lsl #12  ; [pp+0x37e18] TypeArguments: <ExtendedTabBarView, ExtendedTabBarViewState<ExtendedTabBarView>>
    //     0x7a07a0: ldr             x16, [x16, #0xe18]
    // 0x7a07a4: ldr             lr, [fp, #0x10]
    // 0x7a07a8: stp             lr, x16, [SP, #-0x10]!
    // 0x7a07ac: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0x7a07ac: ldr             x4, [PP, #0xe90]  ; [pp+0xe90] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0x7a07b0: r0 = linkParent()
    //     0x7a07b0: bl              #0x7a07d0  ; [package:sync_scroll_library/src/link/link_scroll_state.dart] LinkScrollState::linkParent
    // 0x7a07b4: add             SP, SP, #0x10
    // 0x7a07b8: r0 = Null
    //     0x7a07b8: mov             x0, NULL
    // 0x7a07bc: LeaveFrame
    //     0x7a07bc: mov             SP, fp
    //     0x7a07c0: ldp             fp, lr, [SP], #0x10
    // 0x7a07c4: ret
    //     0x7a07c4: ret             
    // 0x7a07c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a07c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a07cc: b               #0x7a079c
  }
  get _ physics(/* No info */) {
    // ** addr: 0x7a0e28, size: 0x34
    // 0x7a0e28: EnterFrame
    //     0x7a0e28: stp             fp, lr, [SP, #-0x10]!
    //     0x7a0e2c: mov             fp, SP
    // 0x7a0e30: ldr             x1, [fp, #0x10]
    // 0x7a0e34: LoadField: r2 = r1->field_b
    //     0x7a0e34: ldur            w2, [x1, #0xb]
    // 0x7a0e38: DecompressPointer r2
    //     0x7a0e38: add             x2, x2, HEAP, lsl #32
    // 0x7a0e3c: cmp             w2, NULL
    // 0x7a0e40: b.eq            #0x7a0e58
    // 0x7a0e44: LoadField: r0 = r2->field_1f
    //     0x7a0e44: ldur            w0, [x2, #0x1f]
    // 0x7a0e48: DecompressPointer r0
    //     0x7a0e48: add             x0, x0, HEAP, lsl #32
    // 0x7a0e4c: LeaveFrame
    //     0x7a0e4c: mov             SP, fp
    //     0x7a0e50: ldp             fp, lr, [SP], #0x10
    // 0x7a0e54: ret
    //     0x7a0e54: ret             
    // 0x7a0e58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a0e58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateChildren(/* No info */) {
    // ** addr: 0x7a11d0, size: 0x98
    // 0x7a11d0: EnterFrame
    //     0x7a11d0: stp             fp, lr, [SP, #-0x10]!
    //     0x7a11d4: mov             fp, SP
    // 0x7a11d8: CheckStackOverflow
    //     0x7a11d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a11dc: cmp             SP, x16
    //     0x7a11e0: b.ls            #0x7a125c
    // 0x7a11e4: ldr             x1, [fp, #0x10]
    // 0x7a11e8: LoadField: r0 = r1->field_b
    //     0x7a11e8: ldur            w0, [x1, #0xb]
    // 0x7a11ec: DecompressPointer r0
    //     0x7a11ec: add             x0, x0, HEAP, lsl #32
    // 0x7a11f0: cmp             w0, NULL
    // 0x7a11f4: b.eq            #0x7a1264
    // 0x7a11f8: LoadField: r2 = r0->field_1b
    //     0x7a11f8: ldur            w2, [x0, #0x1b]
    // 0x7a11fc: DecompressPointer r2
    //     0x7a11fc: add             x2, x2, HEAP, lsl #32
    // 0x7a1200: mov             x0, x2
    // 0x7a1204: StoreField: r1->field_23 = r0
    //     0x7a1204: stur            w0, [x1, #0x23]
    //     0x7a1208: ldurb           w16, [x1, #-1]
    //     0x7a120c: ldurb           w17, [x0, #-1]
    //     0x7a1210: and             x16, x17, x16, lsr #2
    //     0x7a1214: tst             x16, HEAP, lsr #32
    //     0x7a1218: b.eq            #0x7a1220
    //     0x7a121c: bl              #0xd6826c
    // 0x7a1220: SaveReg r2
    //     0x7a1220: str             x2, [SP, #-8]!
    // 0x7a1224: r0 = ensureUniqueKeysForList()
    //     0x7a1224: bl              #0x7a1268  ; [package:flutter/src/widgets/basic.dart] KeyedSubtree::ensureUniqueKeysForList
    // 0x7a1228: add             SP, SP, #8
    // 0x7a122c: ldr             x1, [fp, #0x10]
    // 0x7a1230: StoreField: r1->field_27 = r0
    //     0x7a1230: stur            w0, [x1, #0x27]
    //     0x7a1234: ldurb           w16, [x1, #-1]
    //     0x7a1238: ldurb           w17, [x0, #-1]
    //     0x7a123c: and             x16, x17, x16, lsr #2
    //     0x7a1240: tst             x16, HEAP, lsr #32
    //     0x7a1244: b.eq            #0x7a124c
    //     0x7a1248: bl              #0xd6826c
    // 0x7a124c: r0 = Null
    //     0x7a124c: mov             x0, NULL
    // 0x7a1250: LeaveFrame
    //     0x7a1250: mov             SP, fp
    //     0x7a1254: ldp             fp, lr, [SP], #0x10
    // 0x7a1258: ret
    //     0x7a1258: ret             
    // 0x7a125c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a125c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a1260: b               #0x7a11e4
    // 0x7a1264: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a1264: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getScrollPhysics(/* No info */) {
    // ** addr: 0x7a15c4, size: 0x98
    // 0x7a15c4: EnterFrame
    //     0x7a15c4: stp             fp, lr, [SP, #-0x10]!
    //     0x7a15c8: mov             fp, SP
    // 0x7a15cc: CheckStackOverflow
    //     0x7a15cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a15d0: cmp             SP, x16
    //     0x7a15d4: b.ls            #0x7a1650
    // 0x7a15d8: ldr             x0, [fp, #0x10]
    // 0x7a15dc: LoadField: r1 = r0->field_b
    //     0x7a15dc: ldur            w1, [x0, #0xb]
    // 0x7a15e0: DecompressPointer r1
    //     0x7a15e0: add             x1, x1, HEAP, lsl #32
    // 0x7a15e4: cmp             w1, NULL
    // 0x7a15e8: b.eq            #0x7a1658
    // 0x7a15ec: LoadField: r0 = r1->field_1f
    //     0x7a15ec: ldur            w0, [x1, #0x1f]
    // 0x7a15f0: DecompressPointer r0
    //     0x7a15f0: add             x0, x0, HEAP, lsl #32
    // 0x7a15f4: cmp             w0, NULL
    // 0x7a15f8: b.ne            #0x7a161c
    // 0x7a15fc: r16 = Instance_PageScrollPhysics
    //     0x7a15fc: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2f408] Obj!PageScrollPhysics@b4fdc1
    //     0x7a1600: ldr             x16, [x16, #0x408]
    // 0x7a1604: r30 = Instance_ClampingScrollPhysics
    //     0x7a1604: add             lr, PP, #0x20, lsl #12  ; [pp+0x20200] Obj!ClampingScrollPhysics@b4fd31
    //     0x7a1608: ldr             lr, [lr, #0x200]
    // 0x7a160c: stp             lr, x16, [SP, #-0x10]!
    // 0x7a1610: r0 = applyTo()
    //     0x7a1610: bl              #0xc3b304  ; [package:flutter/src/widgets/page_view.dart] PageScrollPhysics::applyTo
    // 0x7a1614: add             SP, SP, #0x10
    // 0x7a1618: b               #0x7a1630
    // 0x7a161c: r16 = Instance_PageScrollPhysics
    //     0x7a161c: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2f408] Obj!PageScrollPhysics@b4fdc1
    //     0x7a1620: ldr             x16, [x16, #0x408]
    // 0x7a1624: stp             x0, x16, [SP, #-0x10]!
    // 0x7a1628: r0 = applyTo()
    //     0x7a1628: bl              #0xc3b304  ; [package:flutter/src/widgets/page_view.dart] PageScrollPhysics::applyTo
    // 0x7a162c: add             SP, SP, #0x10
    // 0x7a1630: r16 = Instance_NeverScrollableScrollPhysics
    //     0x7a1630: add             x16, PP, #0x26, lsl #12  ; [pp+0x26998] Obj!NeverScrollableScrollPhysics@b4fd11
    //     0x7a1634: ldr             x16, [x16, #0x998]
    // 0x7a1638: stp             x0, x16, [SP, #-0x10]!
    // 0x7a163c: r0 = applyTo()
    //     0x7a163c: bl              #0xc3b598  ; [package:flutter/src/widgets/scroll_physics.dart] NeverScrollableScrollPhysics::applyTo
    // 0x7a1640: add             SP, SP, #0x10
    // 0x7a1644: LeaveFrame
    //     0x7a1644: mov             SP, fp
    //     0x7a1648: ldp             fp, lr, [SP], #0x10
    // 0x7a164c: ret
    //     0x7a164c: ret             
    // 0x7a1650: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a1650: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a1654: b               #0x7a15d8
    // 0x7a1658: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a1658: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTabController(/* No info */) {
    // ** addr: 0x7a1668, size: 0x17c
    // 0x7a1668: EnterFrame
    //     0x7a1668: stp             fp, lr, [SP, #-0x10]!
    //     0x7a166c: mov             fp, SP
    // 0x7a1670: AllocStack(0x10)
    //     0x7a1670: sub             SP, SP, #0x10
    // 0x7a1674: CheckStackOverflow
    //     0x7a1674: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a1678: cmp             SP, x16
    //     0x7a167c: b.ls            #0x7a17cc
    // 0x7a1680: ldr             x0, [fp, #0x10]
    // 0x7a1684: LoadField: r1 = r0->field_b
    //     0x7a1684: ldur            w1, [x0, #0xb]
    // 0x7a1688: DecompressPointer r1
    //     0x7a1688: add             x1, x1, HEAP, lsl #32
    // 0x7a168c: cmp             w1, NULL
    // 0x7a1690: b.eq            #0x7a17d4
    // 0x7a1694: LoadField: r2 = r1->field_17
    //     0x7a1694: ldur            w2, [x1, #0x17]
    // 0x7a1698: DecompressPointer r2
    //     0x7a1698: add             x2, x2, HEAP, lsl #32
    // 0x7a169c: stur            x2, [fp, #-8]
    // 0x7a16a0: LoadField: r1 = r0->field_1b
    //     0x7a16a0: ldur            w1, [x0, #0x1b]
    // 0x7a16a4: DecompressPointer r1
    //     0x7a16a4: add             x1, x1, HEAP, lsl #32
    // 0x7a16a8: cmp             w2, w1
    // 0x7a16ac: b.ne            #0x7a16c0
    // 0x7a16b0: r0 = Null
    //     0x7a16b0: mov             x0, NULL
    // 0x7a16b4: LeaveFrame
    //     0x7a16b4: mov             SP, fp
    //     0x7a16b8: ldp             fp, lr, [SP], #0x10
    // 0x7a16bc: ret
    //     0x7a16bc: ret             
    // 0x7a16c0: SaveReg r0
    //     0x7a16c0: str             x0, [SP, #-8]!
    // 0x7a16c4: r0 = _controllerIsValid()
    //     0x7a16c4: bl              #0x7a17e4  ; [package:extended_tabs/src/tab_view.dart] ExtendedTabBarViewState::_controllerIsValid
    // 0x7a16c8: add             SP, SP, #8
    // 0x7a16cc: tbnz            w0, #4, #0x7a1740
    // 0x7a16d0: ldr             x0, [fp, #0x10]
    // 0x7a16d4: LoadField: r1 = r0->field_1b
    //     0x7a16d4: ldur            w1, [x0, #0x1b]
    // 0x7a16d8: DecompressPointer r1
    //     0x7a16d8: add             x1, x1, HEAP, lsl #32
    // 0x7a16dc: cmp             w1, NULL
    // 0x7a16e0: b.eq            #0x7a17d8
    // 0x7a16e4: LoadField: r2 = r1->field_23
    //     0x7a16e4: ldur            w2, [x1, #0x23]
    // 0x7a16e8: DecompressPointer r2
    //     0x7a16e8: add             x2, x2, HEAP, lsl #32
    // 0x7a16ec: cmp             w2, NULL
    // 0x7a16f0: b.ne            #0x7a16fc
    // 0x7a16f4: r1 = Null
    //     0x7a16f4: mov             x1, NULL
    // 0x7a16f8: b               #0x7a1700
    // 0x7a16fc: mov             x1, x2
    // 0x7a1700: stur            x1, [fp, #-0x10]
    // 0x7a1704: cmp             w1, NULL
    // 0x7a1708: b.eq            #0x7a17dc
    // 0x7a170c: r1 = 1
    //     0x7a170c: mov             x1, #1
    // 0x7a1710: r0 = AllocateContext()
    //     0x7a1710: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7a1714: mov             x1, x0
    // 0x7a1718: ldr             x0, [fp, #0x10]
    // 0x7a171c: StoreField: r1->field_f = r0
    //     0x7a171c: stur            w0, [x1, #0xf]
    // 0x7a1720: mov             x2, x1
    // 0x7a1724: r1 = Function '_handleTabControllerAnimationTick@470121374':.
    //     0x7a1724: add             x1, PP, #0x38, lsl #12  ; [pp+0x38198] AnonymousClosure: (0x7a1828), in [package:extended_tabs/src/tab_view.dart] ExtendedTabBarViewState::_handleTabControllerAnimationTick (0x7a1870)
    //     0x7a1728: ldr             x1, [x1, #0x198]
    // 0x7a172c: r0 = AllocateClosure()
    //     0x7a172c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7a1730: ldur            x16, [fp, #-0x10]
    // 0x7a1734: stp             x0, x16, [SP, #-0x10]!
    // 0x7a1738: r0 = removeListener()
    //     0x7a1738: bl              #0x6f5e30  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::removeListener
    // 0x7a173c: add             SP, SP, #0x10
    // 0x7a1740: ldr             x1, [fp, #0x10]
    // 0x7a1744: ldur            x2, [fp, #-8]
    // 0x7a1748: mov             x0, x2
    // 0x7a174c: StoreField: r1->field_1b = r0
    //     0x7a174c: stur            w0, [x1, #0x1b]
    //     0x7a1750: ldurb           w16, [x1, #-1]
    //     0x7a1754: ldurb           w17, [x0, #-1]
    //     0x7a1758: and             x16, x17, x16, lsr #2
    //     0x7a175c: tst             x16, HEAP, lsr #32
    //     0x7a1760: b.eq            #0x7a1768
    //     0x7a1764: bl              #0xd6826c
    // 0x7a1768: LoadField: r0 = r2->field_23
    //     0x7a1768: ldur            w0, [x2, #0x23]
    // 0x7a176c: DecompressPointer r0
    //     0x7a176c: add             x0, x0, HEAP, lsl #32
    // 0x7a1770: cmp             w0, NULL
    // 0x7a1774: b.ne            #0x7a177c
    // 0x7a1778: r0 = Null
    //     0x7a1778: mov             x0, NULL
    // 0x7a177c: stur            x0, [fp, #-8]
    // 0x7a1780: cmp             w0, NULL
    // 0x7a1784: b.eq            #0x7a17e0
    // 0x7a1788: r1 = 1
    //     0x7a1788: mov             x1, #1
    // 0x7a178c: r0 = AllocateContext()
    //     0x7a178c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7a1790: mov             x1, x0
    // 0x7a1794: ldr             x0, [fp, #0x10]
    // 0x7a1798: StoreField: r1->field_f = r0
    //     0x7a1798: stur            w0, [x1, #0xf]
    // 0x7a179c: mov             x2, x1
    // 0x7a17a0: r1 = Function '_handleTabControllerAnimationTick@470121374':.
    //     0x7a17a0: add             x1, PP, #0x38, lsl #12  ; [pp+0x38198] AnonymousClosure: (0x7a1828), in [package:extended_tabs/src/tab_view.dart] ExtendedTabBarViewState::_handleTabControllerAnimationTick (0x7a1870)
    //     0x7a17a4: ldr             x1, [x1, #0x198]
    // 0x7a17a8: r0 = AllocateClosure()
    //     0x7a17a8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7a17ac: ldur            x16, [fp, #-8]
    // 0x7a17b0: stp             x0, x16, [SP, #-0x10]!
    // 0x7a17b4: r0 = addActionListener()
    //     0x7a17b4: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x7a17b8: add             SP, SP, #0x10
    // 0x7a17bc: r0 = Null
    //     0x7a17bc: mov             x0, NULL
    // 0x7a17c0: LeaveFrame
    //     0x7a17c0: mov             SP, fp
    //     0x7a17c4: ldp             fp, lr, [SP], #0x10
    // 0x7a17c8: ret
    //     0x7a17c8: ret             
    // 0x7a17cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a17cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a17d0: b               #0x7a1680
    // 0x7a17d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a17d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7a17d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a17d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7a17dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a17dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7a17e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a17e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _controllerIsValid(/* No info */) {
    // ** addr: 0x7a17e4, size: 0x44
    // 0x7a17e4: ldr             x1, [SP]
    // 0x7a17e8: LoadField: r2 = r1->field_1b
    //     0x7a17e8: ldur            w2, [x1, #0x1b]
    // 0x7a17ec: DecompressPointer r2
    //     0x7a17ec: add             x2, x2, HEAP, lsl #32
    // 0x7a17f0: cmp             w2, NULL
    // 0x7a17f4: b.ne            #0x7a1800
    // 0x7a17f8: r1 = Null
    //     0x7a17f8: mov             x1, NULL
    // 0x7a17fc: b               #0x7a1814
    // 0x7a1800: LoadField: r1 = r2->field_23
    //     0x7a1800: ldur            w1, [x2, #0x23]
    // 0x7a1804: DecompressPointer r1
    //     0x7a1804: add             x1, x1, HEAP, lsl #32
    // 0x7a1808: cmp             w1, NULL
    // 0x7a180c: b.ne            #0x7a1814
    // 0x7a1810: r1 = Null
    //     0x7a1810: mov             x1, NULL
    // 0x7a1814: cmp             w1, NULL
    // 0x7a1818: r16 = true
    //     0x7a1818: add             x16, NULL, #0x20  ; true
    // 0x7a181c: r17 = false
    //     0x7a181c: add             x17, NULL, #0x30  ; false
    // 0x7a1820: csel            x0, x16, x17, ne
    // 0x7a1824: ret
    //     0x7a1824: ret             
  }
  [closure] void _handleTabControllerAnimationTick(dynamic) {
    // ** addr: 0x7a1828, size: 0x48
    // 0x7a1828: EnterFrame
    //     0x7a1828: stp             fp, lr, [SP, #-0x10]!
    //     0x7a182c: mov             fp, SP
    // 0x7a1830: ldr             x0, [fp, #0x10]
    // 0x7a1834: LoadField: r1 = r0->field_17
    //     0x7a1834: ldur            w1, [x0, #0x17]
    // 0x7a1838: DecompressPointer r1
    //     0x7a1838: add             x1, x1, HEAP, lsl #32
    // 0x7a183c: CheckStackOverflow
    //     0x7a183c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a1840: cmp             SP, x16
    //     0x7a1844: b.ls            #0x7a1868
    // 0x7a1848: LoadField: r0 = r1->field_f
    //     0x7a1848: ldur            w0, [x1, #0xf]
    // 0x7a184c: DecompressPointer r0
    //     0x7a184c: add             x0, x0, HEAP, lsl #32
    // 0x7a1850: SaveReg r0
    //     0x7a1850: str             x0, [SP, #-8]!
    // 0x7a1854: r0 = _handleTabControllerAnimationTick()
    //     0x7a1854: bl              #0x7a1870  ; [package:extended_tabs/src/tab_view.dart] ExtendedTabBarViewState::_handleTabControllerAnimationTick
    // 0x7a1858: add             SP, SP, #8
    // 0x7a185c: LeaveFrame
    //     0x7a185c: mov             SP, fp
    //     0x7a1860: ldp             fp, lr, [SP], #0x10
    // 0x7a1864: ret
    //     0x7a1864: ret             
    // 0x7a1868: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a1868: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a186c: b               #0x7a1848
  }
  _ _handleTabControllerAnimationTick(/* No info */) {
    // ** addr: 0x7a1870, size: 0xf4
    // 0x7a1870: EnterFrame
    //     0x7a1870: stp             fp, lr, [SP, #-0x10]!
    //     0x7a1874: mov             fp, SP
    // 0x7a1878: CheckStackOverflow
    //     0x7a1878: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a187c: cmp             SP, x16
    //     0x7a1880: b.ls            #0x7a1958
    // 0x7a1884: ldr             x2, [fp, #0x10]
    // 0x7a1888: LoadField: r0 = r2->field_2f
    //     0x7a1888: ldur            x0, [x2, #0x2f]
    // 0x7a188c: cmp             x0, #0
    // 0x7a1890: b.gt            #0x7a18ac
    // 0x7a1894: LoadField: r0 = r2->field_1b
    //     0x7a1894: ldur            w0, [x2, #0x1b]
    // 0x7a1898: DecompressPointer r0
    //     0x7a1898: add             x0, x0, HEAP, lsl #32
    // 0x7a189c: cmp             w0, NULL
    // 0x7a18a0: b.eq            #0x7a1960
    // 0x7a18a4: LoadField: r1 = r0->field_43
    //     0x7a18a4: ldur            x1, [x0, #0x43]
    // 0x7a18a8: cbnz            x1, #0x7a18bc
    // 0x7a18ac: r0 = Null
    //     0x7a18ac: mov             x0, NULL
    // 0x7a18b0: LeaveFrame
    //     0x7a18b0: mov             SP, fp
    //     0x7a18b4: ldp             fp, lr, [SP], #0x10
    // 0x7a18b8: ret
    //     0x7a18b8: ret             
    // 0x7a18bc: LoadField: r3 = r0->field_33
    //     0x7a18bc: ldur            x3, [x0, #0x33]
    // 0x7a18c0: LoadField: r4 = r2->field_2b
    //     0x7a18c0: ldur            w4, [x2, #0x2b]
    // 0x7a18c4: DecompressPointer r4
    //     0x7a18c4: add             x4, x4, HEAP, lsl #32
    // 0x7a18c8: r0 = BoxInt64Instr(r3)
    //     0x7a18c8: sbfiz           x0, x3, #1, #0x1f
    //     0x7a18cc: cmp             x3, x0, asr #1
    //     0x7a18d0: b.eq            #0x7a18dc
    //     0x7a18d4: bl              #0xd69bb8
    //     0x7a18d8: stur            x3, [x0, #7]
    // 0x7a18dc: cmp             w0, w4
    // 0x7a18e0: b.eq            #0x7a1948
    // 0x7a18e4: and             w16, w0, w4
    // 0x7a18e8: branchIfSmi(r16, 0x7a191c)
    //     0x7a18e8: tbz             w16, #0, #0x7a191c
    // 0x7a18ec: r16 = LoadClassIdInstr(r0)
    //     0x7a18ec: ldur            x16, [x0, #-1]
    //     0x7a18f0: ubfx            x16, x16, #0xc, #0x14
    // 0x7a18f4: cmp             x16, #0x3c
    // 0x7a18f8: b.ne            #0x7a191c
    // 0x7a18fc: r16 = LoadClassIdInstr(r4)
    //     0x7a18fc: ldur            x16, [x4, #-1]
    //     0x7a1900: ubfx            x16, x16, #0xc, #0x14
    // 0x7a1904: cmp             x16, #0x3c
    // 0x7a1908: b.ne            #0x7a191c
    // 0x7a190c: LoadField: r16 = r0->field_7
    //     0x7a190c: ldur            x16, [x0, #7]
    // 0x7a1910: LoadField: r17 = r4->field_7
    //     0x7a1910: ldur            x17, [x4, #7]
    // 0x7a1914: cmp             x16, x17
    // 0x7a1918: b.eq            #0x7a1948
    // 0x7a191c: StoreField: r2->field_2b = r0
    //     0x7a191c: stur            w0, [x2, #0x2b]
    //     0x7a1920: tbz             w0, #0, #0x7a193c
    //     0x7a1924: ldurb           w16, [x2, #-1]
    //     0x7a1928: ldurb           w17, [x0, #-1]
    //     0x7a192c: and             x16, x17, x16, lsr #2
    //     0x7a1930: tst             x16, HEAP, lsr #32
    //     0x7a1934: b.eq            #0x7a193c
    //     0x7a1938: bl              #0xd6828c
    // 0x7a193c: SaveReg r2
    //     0x7a193c: str             x2, [SP, #-8]!
    // 0x7a1940: r0 = _warpToCurrentIndex()
    //     0x7a1940: bl              #0x7a1964  ; [package:extended_tabs/src/tab_view.dart] ExtendedTabBarViewState::_warpToCurrentIndex
    // 0x7a1944: add             SP, SP, #8
    // 0x7a1948: r0 = Null
    //     0x7a1948: mov             x0, NULL
    // 0x7a194c: LeaveFrame
    //     0x7a194c: mov             SP, fp
    //     0x7a1950: ldp             fp, lr, [SP], #0x10
    // 0x7a1954: ret
    //     0x7a1954: ret             
    // 0x7a1958: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a1958: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a195c: b               #0x7a1884
    // 0x7a1960: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a1960: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _warpToCurrentIndex(/* No info */) async {
    // ** addr: 0x7a1964, size: 0x4b8
    // 0x7a1964: EnterFrame
    //     0x7a1964: stp             fp, lr, [SP, #-0x10]!
    //     0x7a1968: mov             fp, SP
    // 0x7a196c: AllocStack(0x20)
    //     0x7a196c: sub             SP, SP, #0x20
    // 0x7a1970: SetupParameters(ExtendedTabBarViewState<ExtendedTabBarView> this /* r1, fp-0x10 */)
    //     0x7a1970: stur            NULL, [fp, #-8]
    //     0x7a1974: mov             x0, #0
    //     0x7a1978: add             x1, fp, w0, sxtw #2
    //     0x7a197c: ldr             x1, [x1, #0x10]
    //     0x7a1980: stur            x1, [fp, #-0x10]
    // 0x7a1984: CheckStackOverflow
    //     0x7a1984: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a1988: cmp             SP, x16
    //     0x7a198c: b.ls            #0x7a1df8
    // 0x7a1990: r1 = 4
    //     0x7a1990: mov             x1, #4
    // 0x7a1994: r0 = AllocateContext()
    //     0x7a1994: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7a1998: mov             x2, x0
    // 0x7a199c: ldur            x1, [fp, #-0x10]
    // 0x7a19a0: stur            x2, [fp, #-0x18]
    // 0x7a19a4: StoreField: r2->field_f = r1
    //     0x7a19a4: stur            w1, [x2, #0xf]
    // 0x7a19a8: InitAsync() -> Future<void?>
    //     0x7a19a8: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x7a19ac: bl              #0x4b92e4
    // 0x7a19b0: ldur            x0, [fp, #-0x10]
    // 0x7a19b4: LoadField: r1 = r0->field_f
    //     0x7a19b4: ldur            w1, [x0, #0xf]
    // 0x7a19b8: DecompressPointer r1
    //     0x7a19b8: add             x1, x1, HEAP, lsl #32
    // 0x7a19bc: cmp             w1, NULL
    // 0x7a19c0: b.ne            #0x7a1a14
    // 0x7a19c4: r1 = <void?>
    //     0x7a19c4: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x7a19c8: r0 = _Future()
    //     0x7a19c8: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x7a19cc: r1 = 0
    //     0x7a19cc: mov             x1, #0
    // 0x7a19d0: stur            x0, [fp, #-0x20]
    // 0x7a19d4: StoreField: r0->field_b = r1
    //     0x7a19d4: stur            x1, [x0, #0xb]
    // 0x7a19d8: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x7a19d8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7a19dc: ldr             x0, [x0, #0xb58]
    //     0x7a19e0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7a19e4: cmp             w0, w16
    //     0x7a19e8: b.ne            #0x7a19f4
    //     0x7a19ec: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x7a19f0: bl              #0xd67d44
    // 0x7a19f4: mov             x1, x0
    // 0x7a19f8: ldur            x0, [fp, #-0x20]
    // 0x7a19fc: StoreField: r0->field_13 = r1
    //     0x7a19fc: stur            w1, [x0, #0x13]
    // 0x7a1a00: stp             NULL, x0, [SP, #-0x10]!
    // 0x7a1a04: r0 = _asyncComplete()
    //     0x7a1a04: bl              #0x4e2e60  ; [dart:async] _Future::_asyncComplete
    // 0x7a1a08: add             SP, SP, #0x10
    // 0x7a1a0c: ldur            x0, [fp, #-0x20]
    // 0x7a1a10: r0 = ReturnAsync()
    //     0x7a1a10: b               #0x501858  ; ReturnAsyncStub
    // 0x7a1a14: r1 = 0
    //     0x7a1a14: mov             x1, #0
    // 0x7a1a18: LoadField: r2 = r0->field_1f
    //     0x7a1a18: ldur            w2, [x0, #0x1f]
    // 0x7a1a1c: DecompressPointer r2
    //     0x7a1a1c: add             x2, x2, HEAP, lsl #32
    // 0x7a1a20: r16 = Sentinel
    //     0x7a1a20: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7a1a24: cmp             w2, w16
    // 0x7a1a28: b.eq            #0x7a1e00
    // 0x7a1a2c: LoadField: r3 = r2->field_33
    //     0x7a1a2c: ldur            w3, [x2, #0x33]
    // 0x7a1a30: DecompressPointer r3
    //     0x7a1a30: add             x3, x3, HEAP, lsl #32
    // 0x7a1a34: SaveReg r3
    //     0x7a1a34: str             x3, [SP, #-8]!
    // 0x7a1a38: r0 = single()
    //     0x7a1a38: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x7a1a3c: add             SP, SP, #8
    // 0x7a1a40: mov             x3, x0
    // 0x7a1a44: r2 = Null
    //     0x7a1a44: mov             x2, NULL
    // 0x7a1a48: r1 = Null
    //     0x7a1a48: mov             x1, NULL
    // 0x7a1a4c: stur            x3, [fp, #-0x20]
    // 0x7a1a50: r4 = LoadClassIdInstr(r0)
    //     0x7a1a50: ldur            x4, [x0, #-1]
    //     0x7a1a54: ubfx            x4, x4, #0xc, #0x14
    // 0x7a1a58: r17 = 4847
    //     0x7a1a58: mov             x17, #0x12ef
    // 0x7a1a5c: cmp             x4, x17
    // 0x7a1a60: b.eq            #0x7a1a78
    // 0x7a1a64: r8 = _PagePosition
    //     0x7a1a64: add             x8, PP, #0x32, lsl #12  ; [pp+0x32f98] Type: _PagePosition
    //     0x7a1a68: ldr             x8, [x8, #0xf98]
    // 0x7a1a6c: r3 = Null
    //     0x7a1a6c: add             x3, PP, #0x38, lsl #12  ; [pp+0x381a0] Null
    //     0x7a1a70: ldr             x3, [x3, #0x1a0]
    // 0x7a1a74: r0 = DefaultTypeTest()
    //     0x7a1a74: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x7a1a78: ldur            x16, [fp, #-0x20]
    // 0x7a1a7c: SaveReg r16
    //     0x7a1a7c: str             x16, [SP, #-8]!
    // 0x7a1a80: r0 = page()
    //     0x7a1a80: bl              #0x7a1f64  ; [package:flutter/src/widgets/page_view.dart] _PagePosition::page
    // 0x7a1a84: add             SP, SP, #8
    // 0x7a1a88: mov             x1, x0
    // 0x7a1a8c: ldur            x0, [fp, #-0x10]
    // 0x7a1a90: stur            x1, [fp, #-0x20]
    // 0x7a1a94: LoadField: r2 = r0->field_2b
    //     0x7a1a94: ldur            w2, [x0, #0x2b]
    // 0x7a1a98: DecompressPointer r2
    //     0x7a1a98: add             x2, x2, HEAP, lsl #32
    // 0x7a1a9c: cmp             w2, NULL
    // 0x7a1aa0: b.eq            #0x7a1e0c
    // 0x7a1aa4: stp             x2, NULL, [SP, #-0x10]!
    // 0x7a1aa8: r0 = _Double.fromInteger()
    //     0x7a1aa8: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x7a1aac: add             SP, SP, #0x10
    // 0x7a1ab0: mov             x1, x0
    // 0x7a1ab4: ldur            x0, [fp, #-0x20]
    // 0x7a1ab8: r2 = LoadClassIdInstr(r0)
    //     0x7a1ab8: ldur            x2, [x0, #-1]
    //     0x7a1abc: ubfx            x2, x2, #0xc, #0x14
    // 0x7a1ac0: stp             x1, x0, [SP, #-0x10]!
    // 0x7a1ac4: mov             x0, x2
    // 0x7a1ac8: mov             lr, x0
    // 0x7a1acc: ldr             lr, [x21, lr, lsl #3]
    // 0x7a1ad0: blr             lr
    // 0x7a1ad4: add             SP, SP, #0x10
    // 0x7a1ad8: tbnz            w0, #4, #0x7a1b2c
    // 0x7a1adc: r1 = <void?>
    //     0x7a1adc: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x7a1ae0: r0 = _Future()
    //     0x7a1ae0: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x7a1ae4: r2 = 0
    //     0x7a1ae4: mov             x2, #0
    // 0x7a1ae8: stur            x0, [fp, #-0x20]
    // 0x7a1aec: StoreField: r0->field_b = r2
    //     0x7a1aec: stur            x2, [x0, #0xb]
    // 0x7a1af0: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x7a1af0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7a1af4: ldr             x0, [x0, #0xb58]
    //     0x7a1af8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7a1afc: cmp             w0, w16
    //     0x7a1b00: b.ne            #0x7a1b0c
    //     0x7a1b04: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x7a1b08: bl              #0xd67d44
    // 0x7a1b0c: mov             x1, x0
    // 0x7a1b10: ldur            x0, [fp, #-0x20]
    // 0x7a1b14: StoreField: r0->field_13 = r1
    //     0x7a1b14: stur            w1, [x0, #0x13]
    // 0x7a1b18: stp             NULL, x0, [SP, #-0x10]!
    // 0x7a1b1c: r0 = _asyncComplete()
    //     0x7a1b1c: bl              #0x4e2e60  ; [dart:async] _Future::_asyncComplete
    // 0x7a1b20: add             SP, SP, #0x10
    // 0x7a1b24: ldur            x0, [fp, #-0x20]
    // 0x7a1b28: r0 = ReturnAsync()
    //     0x7a1b28: b               #0x501858  ; ReturnAsyncStub
    // 0x7a1b2c: ldur            x3, [fp, #-0x10]
    // 0x7a1b30: ldur            x4, [fp, #-0x18]
    // 0x7a1b34: r2 = 0
    //     0x7a1b34: mov             x2, #0
    // 0x7a1b38: LoadField: r0 = r3->field_1b
    //     0x7a1b38: ldur            w0, [x3, #0x1b]
    // 0x7a1b3c: DecompressPointer r0
    //     0x7a1b3c: add             x0, x0, HEAP, lsl #32
    // 0x7a1b40: cmp             w0, NULL
    // 0x7a1b44: b.eq            #0x7a1e10
    // 0x7a1b48: LoadField: r5 = r0->field_3b
    //     0x7a1b48: ldur            x5, [x0, #0x3b]
    // 0x7a1b4c: r0 = BoxInt64Instr(r5)
    //     0x7a1b4c: sbfiz           x0, x5, #1, #0x1f
    //     0x7a1b50: cmp             x5, x0, asr #1
    //     0x7a1b54: b.eq            #0x7a1b60
    //     0x7a1b58: bl              #0xd69bb8
    //     0x7a1b5c: stur            x5, [x0, #7]
    // 0x7a1b60: StoreField: r4->field_13 = r0
    //     0x7a1b60: stur            w0, [x4, #0x13]
    //     0x7a1b64: tbz             w0, #0, #0x7a1b80
    //     0x7a1b68: ldurb           w16, [x4, #-1]
    //     0x7a1b6c: ldurb           w17, [x0, #-1]
    //     0x7a1b70: and             x16, x17, x16, lsr #2
    //     0x7a1b74: tst             x16, HEAP, lsr #32
    //     0x7a1b78: b.eq            #0x7a1b80
    //     0x7a1b7c: bl              #0xd682cc
    // 0x7a1b80: LoadField: r0 = r3->field_2b
    //     0x7a1b80: ldur            w0, [x3, #0x2b]
    // 0x7a1b84: DecompressPointer r0
    //     0x7a1b84: add             x0, x0, HEAP, lsl #32
    // 0x7a1b88: cmp             w0, NULL
    // 0x7a1b8c: b.eq            #0x7a1e14
    // 0x7a1b90: r1 = LoadInt32Instr(r0)
    //     0x7a1b90: sbfx            x1, x0, #1, #0x1f
    //     0x7a1b94: tbz             w0, #0, #0x7a1b9c
    //     0x7a1b98: ldur            x1, [x0, #7]
    // 0x7a1b9c: sub             x0, x1, x5
    // 0x7a1ba0: tbz             x0, #0x3f, #0x7a1bac
    // 0x7a1ba4: neg             x6, x0
    // 0x7a1ba8: mov             x0, x6
    // 0x7a1bac: cmp             x0, #1
    // 0x7a1bb0: b.ne            #0x7a1c54
    // 0x7a1bb4: LoadField: r0 = r3->field_2f
    //     0x7a1bb4: ldur            x0, [x3, #0x2f]
    // 0x7a1bb8: add             x5, x0, #1
    // 0x7a1bbc: StoreField: r3->field_2f = r5
    //     0x7a1bbc: stur            x5, [x3, #0x2f]
    // 0x7a1bc0: LoadField: r0 = r3->field_1f
    //     0x7a1bc0: ldur            w0, [x3, #0x1f]
    // 0x7a1bc4: DecompressPointer r0
    //     0x7a1bc4: add             x0, x0, HEAP, lsl #32
    // 0x7a1bc8: stp             x1, x0, [SP, #-0x10]!
    // 0x7a1bcc: r16 = Instance_Cubic
    //     0x7a1bcc: add             x16, PP, #0xa, lsl #12  ; [pp+0xafc8] Obj!Cubic<double>@b4f341
    //     0x7a1bd0: ldr             x16, [x16, #0xfc8]
    // 0x7a1bd4: r30 = Instance_Duration
    //     0x7a1bd4: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc88] Obj!Duration@b67ad1
    //     0x7a1bd8: ldr             lr, [lr, #0xc88]
    // 0x7a1bdc: stp             lr, x16, [SP, #-0x10]!
    // 0x7a1be0: r0 = animateToPage()
    //     0x7a1be0: bl              #0x798030  ; [package:flutter/src/widgets/page_view.dart] PageController::animateToPage
    // 0x7a1be4: add             SP, SP, #0x20
    // 0x7a1be8: mov             x1, x0
    // 0x7a1bec: stur            x1, [fp, #-0x20]
    // 0x7a1bf0: r0 = Await()
    //     0x7a1bf0: bl              #0x4b8e6c  ; AwaitStub
    // 0x7a1bf4: ldur            x3, [fp, #-0x10]
    // 0x7a1bf8: LoadField: r0 = r3->field_2f
    //     0x7a1bf8: ldur            x0, [x3, #0x2f]
    // 0x7a1bfc: sub             x1, x0, #1
    // 0x7a1c00: StoreField: r3->field_2f = r1
    //     0x7a1c00: stur            x1, [x3, #0x2f]
    // 0x7a1c04: r1 = <void?>
    //     0x7a1c04: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x7a1c08: r0 = _Future()
    //     0x7a1c08: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x7a1c0c: r4 = 0
    //     0x7a1c0c: mov             x4, #0
    // 0x7a1c10: stur            x0, [fp, #-0x20]
    // 0x7a1c14: StoreField: r0->field_b = r4
    //     0x7a1c14: stur            x4, [x0, #0xb]
    // 0x7a1c18: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x7a1c18: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7a1c1c: ldr             x0, [x0, #0xb58]
    //     0x7a1c20: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7a1c24: cmp             w0, w16
    //     0x7a1c28: b.ne            #0x7a1c34
    //     0x7a1c2c: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x7a1c30: bl              #0xd67d44
    // 0x7a1c34: mov             x1, x0
    // 0x7a1c38: ldur            x0, [fp, #-0x20]
    // 0x7a1c3c: StoreField: r0->field_13 = r1
    //     0x7a1c3c: stur            w1, [x0, #0x13]
    // 0x7a1c40: stp             NULL, x0, [SP, #-0x10]!
    // 0x7a1c44: r0 = _asyncComplete()
    //     0x7a1c44: bl              #0x4e2e60  ; [dart:async] _Future::_asyncComplete
    // 0x7a1c48: add             SP, SP, #0x10
    // 0x7a1c4c: ldur            x0, [fp, #-0x20]
    // 0x7a1c50: r0 = ReturnAsync()
    //     0x7a1c50: b               #0x501858  ; ReturnAsyncStub
    // 0x7a1c54: mov             x4, x2
    // 0x7a1c58: cmp             x1, x5
    // 0x7a1c5c: b.le            #0x7a1c6c
    // 0x7a1c60: sub             x0, x1, #1
    // 0x7a1c64: mov             x2, x0
    // 0x7a1c68: b               #0x7a1c74
    // 0x7a1c6c: add             x0, x1, #1
    // 0x7a1c70: mov             x2, x0
    // 0x7a1c74: ldur            x5, [fp, #-0x18]
    // 0x7a1c78: r0 = BoxInt64Instr(r2)
    //     0x7a1c78: sbfiz           x0, x2, #1, #0x1f
    //     0x7a1c7c: cmp             x2, x0, asr #1
    //     0x7a1c80: b.eq            #0x7a1c8c
    //     0x7a1c84: bl              #0xd69bb8
    //     0x7a1c88: stur            x2, [x0, #7]
    // 0x7a1c8c: mov             x6, x0
    // 0x7a1c90: stur            x6, [fp, #-0x20]
    // 0x7a1c94: StoreField: r5->field_17 = r0
    //     0x7a1c94: stur            w0, [x5, #0x17]
    //     0x7a1c98: tbz             w0, #0, #0x7a1cb4
    //     0x7a1c9c: ldurb           w16, [x5, #-1]
    //     0x7a1ca0: ldurb           w17, [x0, #-1]
    //     0x7a1ca4: and             x16, x17, x16, lsr #2
    //     0x7a1ca8: tst             x16, HEAP, lsr #32
    //     0x7a1cac: b.eq            #0x7a1cb4
    //     0x7a1cb0: bl              #0xd682ec
    // 0x7a1cb4: LoadField: r0 = r3->field_27
    //     0x7a1cb4: ldur            w0, [x3, #0x27]
    // 0x7a1cb8: DecompressPointer r0
    //     0x7a1cb8: add             x0, x0, HEAP, lsl #32
    // 0x7a1cbc: StoreField: r5->field_1b = r0
    //     0x7a1cbc: stur            w0, [x5, #0x1b]
    //     0x7a1cc0: ldurb           w16, [x5, #-1]
    //     0x7a1cc4: ldurb           w17, [x0, #-1]
    //     0x7a1cc8: and             x16, x17, x16, lsr #2
    //     0x7a1ccc: tst             x16, HEAP, lsr #32
    //     0x7a1cd0: b.eq            #0x7a1cd8
    //     0x7a1cd4: bl              #0xd682ec
    // 0x7a1cd8: mov             x2, x5
    // 0x7a1cdc: r1 = Function '<anonymous closure>':.
    //     0x7a1cdc: add             x1, PP, #0x38, lsl #12  ; [pp+0x381b0] AnonymousClosure: (0x7a22f8), in [package:extended_tabs/src/tab_view.dart] ExtendedTabBarViewState::_warpToCurrentIndex (0x7a1964)
    //     0x7a1ce0: ldr             x1, [x1, #0x1b0]
    // 0x7a1ce4: r0 = AllocateClosure()
    //     0x7a1ce4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7a1ce8: ldur            x16, [fp, #-0x10]
    // 0x7a1cec: stp             x0, x16, [SP, #-0x10]!
    // 0x7a1cf0: r0 = setState()
    //     0x7a1cf0: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7a1cf4: add             SP, SP, #0x10
    // 0x7a1cf8: ldur            x0, [fp, #-0x10]
    // 0x7a1cfc: LoadField: r1 = r0->field_1f
    //     0x7a1cfc: ldur            w1, [x0, #0x1f]
    // 0x7a1d00: DecompressPointer r1
    //     0x7a1d00: add             x1, x1, HEAP, lsl #32
    // 0x7a1d04: ldur            x16, [fp, #-0x20]
    // 0x7a1d08: stp             x16, x1, [SP, #-0x10]!
    // 0x7a1d0c: r0 = jumpToPage()
    //     0x7a1d0c: bl              #0x7a1e1c  ; [package:flutter/src/widgets/page_view.dart] PageController::jumpToPage
    // 0x7a1d10: add             SP, SP, #0x10
    // 0x7a1d14: ldur            x0, [fp, #-0x10]
    // 0x7a1d18: LoadField: r1 = r0->field_1f
    //     0x7a1d18: ldur            w1, [x0, #0x1f]
    // 0x7a1d1c: DecompressPointer r1
    //     0x7a1d1c: add             x1, x1, HEAP, lsl #32
    // 0x7a1d20: LoadField: r2 = r0->field_2b
    //     0x7a1d20: ldur            w2, [x0, #0x2b]
    // 0x7a1d24: DecompressPointer r2
    //     0x7a1d24: add             x2, x2, HEAP, lsl #32
    // 0x7a1d28: cmp             w2, NULL
    // 0x7a1d2c: b.eq            #0x7a1e18
    // 0x7a1d30: r3 = LoadInt32Instr(r2)
    //     0x7a1d30: sbfx            x3, x2, #1, #0x1f
    //     0x7a1d34: tbz             w2, #0, #0x7a1d3c
    //     0x7a1d38: ldur            x3, [x2, #7]
    // 0x7a1d3c: stp             x3, x1, [SP, #-0x10]!
    // 0x7a1d40: r16 = Instance_Cubic
    //     0x7a1d40: add             x16, PP, #0xa, lsl #12  ; [pp+0xafc8] Obj!Cubic<double>@b4f341
    //     0x7a1d44: ldr             x16, [x16, #0xfc8]
    // 0x7a1d48: r30 = Instance_Duration
    //     0x7a1d48: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc88] Obj!Duration@b67ad1
    //     0x7a1d4c: ldr             lr, [lr, #0xc88]
    // 0x7a1d50: stp             lr, x16, [SP, #-0x10]!
    // 0x7a1d54: r0 = animateToPage()
    //     0x7a1d54: bl              #0x798030  ; [package:flutter/src/widgets/page_view.dart] PageController::animateToPage
    // 0x7a1d58: add             SP, SP, #0x20
    // 0x7a1d5c: mov             x1, x0
    // 0x7a1d60: stur            x1, [fp, #-0x20]
    // 0x7a1d64: r0 = Await()
    //     0x7a1d64: bl              #0x4b8e6c  ; AwaitStub
    // 0x7a1d68: ldur            x0, [fp, #-0x10]
    // 0x7a1d6c: LoadField: r1 = r0->field_f
    //     0x7a1d6c: ldur            w1, [x0, #0xf]
    // 0x7a1d70: DecompressPointer r1
    //     0x7a1d70: add             x1, x1, HEAP, lsl #32
    // 0x7a1d74: cmp             w1, NULL
    // 0x7a1d78: b.ne            #0x7a1dd0
    // 0x7a1d7c: r1 = <void?>
    //     0x7a1d7c: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x7a1d80: r0 = _Future()
    //     0x7a1d80: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x7a1d84: mov             x1, x0
    // 0x7a1d88: r0 = 0
    //     0x7a1d88: mov             x0, #0
    // 0x7a1d8c: stur            x1, [fp, #-0x20]
    // 0x7a1d90: StoreField: r1->field_b = r0
    //     0x7a1d90: stur            x0, [x1, #0xb]
    // 0x7a1d94: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x7a1d94: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7a1d98: ldr             x0, [x0, #0xb58]
    //     0x7a1d9c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7a1da0: cmp             w0, w16
    //     0x7a1da4: b.ne            #0x7a1db0
    //     0x7a1da8: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x7a1dac: bl              #0xd67d44
    // 0x7a1db0: mov             x1, x0
    // 0x7a1db4: ldur            x0, [fp, #-0x20]
    // 0x7a1db8: StoreField: r0->field_13 = r1
    //     0x7a1db8: stur            w1, [x0, #0x13]
    // 0x7a1dbc: stp             NULL, x0, [SP, #-0x10]!
    // 0x7a1dc0: r0 = _asyncComplete()
    //     0x7a1dc0: bl              #0x4e2e60  ; [dart:async] _Future::_asyncComplete
    // 0x7a1dc4: add             SP, SP, #0x10
    // 0x7a1dc8: ldur            x0, [fp, #-0x20]
    // 0x7a1dcc: r0 = ReturnAsync()
    //     0x7a1dcc: b               #0x501858  ; ReturnAsyncStub
    // 0x7a1dd0: ldur            x2, [fp, #-0x18]
    // 0x7a1dd4: r1 = Function '<anonymous closure>':.
    //     0x7a1dd4: add             x1, PP, #0x38, lsl #12  ; [pp+0x381b8] AnonymousClosure: (0x7a2210), in [package:extended_tabs/src/tab_view.dart] ExtendedTabBarViewState::_warpToCurrentIndex (0x7a1964)
    //     0x7a1dd8: ldr             x1, [x1, #0x1b8]
    // 0x7a1ddc: r0 = AllocateClosure()
    //     0x7a1ddc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7a1de0: ldur            x16, [fp, #-0x10]
    // 0x7a1de4: stp             x0, x16, [SP, #-0x10]!
    // 0x7a1de8: r0 = setState()
    //     0x7a1de8: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7a1dec: add             SP, SP, #0x10
    // 0x7a1df0: r0 = Null
    //     0x7a1df0: mov             x0, NULL
    // 0x7a1df4: r0 = ReturnAsyncNotFuture()
    //     0x7a1df4: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x7a1df8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a1df8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a1dfc: b               #0x7a1990
    // 0x7a1e00: r9 = _pageController
    //     0x7a1e00: add             x9, PP, #0x2f, lsl #12  ; [pp+0x2f3d8] Field <ExtendedTabBarViewState._pageController@470121374>: late (offset: 0x20)
    //     0x7a1e04: ldr             x9, [x9, #0x3d8]
    // 0x7a1e08: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7a1e08: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7a1e0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a1e0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7a1e10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a1e10: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7a1e14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a1e14: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7a1e18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a1e18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7a2210, size: 0xe8
    // 0x7a2210: EnterFrame
    //     0x7a2210: stp             fp, lr, [SP, #-0x10]!
    //     0x7a2214: mov             fp, SP
    // 0x7a2218: AllocStack(0x8)
    //     0x7a2218: sub             SP, SP, #8
    // 0x7a221c: SetupParameters()
    //     0x7a221c: ldr             x0, [fp, #0x10]
    //     0x7a2220: ldur            w1, [x0, #0x17]
    //     0x7a2224: add             x1, x1, HEAP, lsl #32
    //     0x7a2228: stur            x1, [fp, #-8]
    // 0x7a222c: CheckStackOverflow
    //     0x7a222c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a2230: cmp             SP, x16
    //     0x7a2234: b.ls            #0x7a22ec
    // 0x7a2238: LoadField: r0 = r1->field_f
    //     0x7a2238: ldur            w0, [x1, #0xf]
    // 0x7a223c: DecompressPointer r0
    //     0x7a223c: add             x0, x0, HEAP, lsl #32
    // 0x7a2240: LoadField: r2 = r0->field_2f
    //     0x7a2240: ldur            x2, [x0, #0x2f]
    // 0x7a2244: sub             x3, x2, #1
    // 0x7a2248: StoreField: r0->field_2f = r3
    //     0x7a2248: stur            x3, [x0, #0x2f]
    // 0x7a224c: LoadField: r2 = r0->field_b
    //     0x7a224c: ldur            w2, [x0, #0xb]
    // 0x7a2250: DecompressPointer r2
    //     0x7a2250: add             x2, x2, HEAP, lsl #32
    // 0x7a2254: cmp             w2, NULL
    // 0x7a2258: b.eq            #0x7a22f4
    // 0x7a225c: LoadField: r3 = r2->field_1b
    //     0x7a225c: ldur            w3, [x2, #0x1b]
    // 0x7a2260: DecompressPointer r3
    //     0x7a2260: add             x3, x3, HEAP, lsl #32
    // 0x7a2264: LoadField: r2 = r0->field_23
    //     0x7a2264: ldur            w2, [x0, #0x23]
    // 0x7a2268: DecompressPointer r2
    //     0x7a2268: add             x2, x2, HEAP, lsl #32
    // 0x7a226c: r0 = LoadClassIdInstr(r3)
    //     0x7a226c: ldur            x0, [x3, #-1]
    //     0x7a2270: ubfx            x0, x0, #0xc, #0x14
    // 0x7a2274: stp             x2, x3, [SP, #-0x10]!
    // 0x7a2278: mov             lr, x0
    // 0x7a227c: ldr             lr, [x21, lr, lsl #3]
    // 0x7a2280: blr             lr
    // 0x7a2284: add             SP, SP, #0x10
    // 0x7a2288: tbz             w0, #4, #0x7a22a8
    // 0x7a228c: ldur            x0, [fp, #-8]
    // 0x7a2290: LoadField: r1 = r0->field_f
    //     0x7a2290: ldur            w1, [x0, #0xf]
    // 0x7a2294: DecompressPointer r1
    //     0x7a2294: add             x1, x1, HEAP, lsl #32
    // 0x7a2298: SaveReg r1
    //     0x7a2298: str             x1, [SP, #-8]!
    // 0x7a229c: r0 = _updateChildren()
    //     0x7a229c: bl              #0x7a11d0  ; [package:extended_tabs/src/tab_view.dart] ExtendedTabBarViewState::_updateChildren
    // 0x7a22a0: add             SP, SP, #8
    // 0x7a22a4: b               #0x7a22dc
    // 0x7a22a8: ldur            x0, [fp, #-8]
    // 0x7a22ac: LoadField: r1 = r0->field_f
    //     0x7a22ac: ldur            w1, [x0, #0xf]
    // 0x7a22b0: DecompressPointer r1
    //     0x7a22b0: add             x1, x1, HEAP, lsl #32
    // 0x7a22b4: LoadField: r2 = r0->field_1b
    //     0x7a22b4: ldur            w2, [x0, #0x1b]
    // 0x7a22b8: DecompressPointer r2
    //     0x7a22b8: add             x2, x2, HEAP, lsl #32
    // 0x7a22bc: mov             x0, x2
    // 0x7a22c0: StoreField: r1->field_27 = r0
    //     0x7a22c0: stur            w0, [x1, #0x27]
    //     0x7a22c4: ldurb           w16, [x1, #-1]
    //     0x7a22c8: ldurb           w17, [x0, #-1]
    //     0x7a22cc: and             x16, x17, x16, lsr #2
    //     0x7a22d0: tst             x16, HEAP, lsr #32
    //     0x7a22d4: b.eq            #0x7a22dc
    //     0x7a22d8: bl              #0xd6826c
    // 0x7a22dc: r0 = Null
    //     0x7a22dc: mov             x0, NULL
    // 0x7a22e0: LeaveFrame
    //     0x7a22e0: mov             SP, fp
    //     0x7a22e4: ldp             fp, lr, [SP], #0x10
    // 0x7a22e8: ret
    //     0x7a22e8: ret             
    // 0x7a22ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a22ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a22f0: b               #0x7a2238
    // 0x7a22f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a22f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7a22f8, size: 0x1d8
    // 0x7a22f8: EnterFrame
    //     0x7a22f8: stp             fp, lr, [SP, #-0x10]!
    //     0x7a22fc: mov             fp, SP
    // 0x7a2300: AllocStack(0x28)
    //     0x7a2300: sub             SP, SP, #0x28
    // 0x7a2304: SetupParameters()
    //     0x7a2304: ldr             x0, [fp, #0x10]
    //     0x7a2308: ldur            w1, [x0, #0x17]
    //     0x7a230c: add             x1, x1, HEAP, lsl #32
    //     0x7a2310: stur            x1, [fp, #-0x10]
    // 0x7a2314: CheckStackOverflow
    //     0x7a2314: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a2318: cmp             SP, x16
    //     0x7a231c: b.ls            #0x7a24b8
    // 0x7a2320: LoadField: r0 = r1->field_f
    //     0x7a2320: ldur            w0, [x1, #0xf]
    // 0x7a2324: DecompressPointer r0
    //     0x7a2324: add             x0, x0, HEAP, lsl #32
    // 0x7a2328: stur            x0, [fp, #-8]
    // 0x7a232c: LoadField: r2 = r0->field_2f
    //     0x7a232c: ldur            x2, [x0, #0x2f]
    // 0x7a2330: add             x3, x2, #1
    // 0x7a2334: StoreField: r0->field_2f = r3
    //     0x7a2334: stur            x3, [x0, #0x2f]
    // 0x7a2338: LoadField: r2 = r0->field_27
    //     0x7a2338: ldur            w2, [x0, #0x27]
    // 0x7a233c: DecompressPointer r2
    //     0x7a233c: add             x2, x2, HEAP, lsl #32
    // 0x7a2340: cmp             w2, NULL
    // 0x7a2344: b.eq            #0x7a24c0
    // 0x7a2348: r16 = <Widget>
    //     0x7a2348: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x7a234c: ldr             x16, [x16, #0xea8]
    // 0x7a2350: stp             x2, x16, [SP, #-0x10]!
    // 0x7a2354: r16 = false
    //     0x7a2354: add             x16, NULL, #0x30  ; false
    // 0x7a2358: SaveReg r16
    //     0x7a2358: str             x16, [SP, #-8]!
    // 0x7a235c: r4 = const [0, 0x3, 0x3, 0x2, growable, 0x2, null]
    //     0x7a235c: ldr             x4, [PP, #0xc20]  ; [pp+0xc20] List(7) [0, 0x3, 0x3, 0x2, "growable", 0x2, Null]
    // 0x7a2360: r0 = List.from()
    //     0x7a2360: bl              #0x4c85f8  ; [dart:core] List::List.from
    // 0x7a2364: add             SP, SP, #0x18
    // 0x7a2368: ldur            x1, [fp, #-8]
    // 0x7a236c: StoreField: r1->field_27 = r0
    //     0x7a236c: stur            w0, [x1, #0x27]
    //     0x7a2370: tbz             w0, #0, #0x7a238c
    //     0x7a2374: ldurb           w16, [x1, #-1]
    //     0x7a2378: ldurb           w17, [x0, #-1]
    //     0x7a237c: and             x16, x17, x16, lsr #2
    //     0x7a2380: tst             x16, HEAP, lsr #32
    //     0x7a2384: b.eq            #0x7a238c
    //     0x7a2388: bl              #0xd6826c
    // 0x7a238c: ldur            x1, [fp, #-0x10]
    // 0x7a2390: LoadField: r0 = r1->field_f
    //     0x7a2390: ldur            w0, [x1, #0xf]
    // 0x7a2394: DecompressPointer r0
    //     0x7a2394: add             x0, x0, HEAP, lsl #32
    // 0x7a2398: LoadField: r2 = r0->field_27
    //     0x7a2398: ldur            w2, [x0, #0x27]
    // 0x7a239c: DecompressPointer r2
    //     0x7a239c: add             x2, x2, HEAP, lsl #32
    // 0x7a23a0: cmp             w2, NULL
    // 0x7a23a4: b.eq            #0x7a24c4
    // 0x7a23a8: LoadField: r3 = r1->field_17
    //     0x7a23a8: ldur            w3, [x1, #0x17]
    // 0x7a23ac: DecompressPointer r3
    //     0x7a23ac: add             x3, x3, HEAP, lsl #32
    // 0x7a23b0: stur            x3, [fp, #-8]
    // 0x7a23b4: r0 = LoadClassIdInstr(r2)
    //     0x7a23b4: ldur            x0, [x2, #-1]
    //     0x7a23b8: ubfx            x0, x0, #0xc, #0x14
    // 0x7a23bc: stp             x3, x2, [SP, #-0x10]!
    // 0x7a23c0: r0 = GDT[cid_x0 + -0xd83]()
    //     0x7a23c0: sub             lr, x0, #0xd83
    //     0x7a23c4: ldr             lr, [x21, lr, lsl #3]
    //     0x7a23c8: blr             lr
    // 0x7a23cc: add             SP, SP, #0x10
    // 0x7a23d0: mov             x2, x0
    // 0x7a23d4: ldur            x1, [fp, #-0x10]
    // 0x7a23d8: stur            x2, [fp, #-0x28]
    // 0x7a23dc: LoadField: r0 = r1->field_f
    //     0x7a23dc: ldur            w0, [x1, #0xf]
    // 0x7a23e0: DecompressPointer r0
    //     0x7a23e0: add             x0, x0, HEAP, lsl #32
    // 0x7a23e4: LoadField: r3 = r0->field_27
    //     0x7a23e4: ldur            w3, [x0, #0x27]
    // 0x7a23e8: DecompressPointer r3
    //     0x7a23e8: add             x3, x3, HEAP, lsl #32
    // 0x7a23ec: stur            x3, [fp, #-0x20]
    // 0x7a23f0: cmp             w3, NULL
    // 0x7a23f4: b.eq            #0x7a24c8
    // 0x7a23f8: LoadField: r4 = r1->field_13
    //     0x7a23f8: ldur            w4, [x1, #0x13]
    // 0x7a23fc: DecompressPointer r4
    //     0x7a23fc: add             x4, x4, HEAP, lsl #32
    // 0x7a2400: stur            x4, [fp, #-0x18]
    // 0x7a2404: r0 = LoadClassIdInstr(r3)
    //     0x7a2404: ldur            x0, [x3, #-1]
    //     0x7a2408: ubfx            x0, x0, #0xc, #0x14
    // 0x7a240c: stp             x4, x3, [SP, #-0x10]!
    // 0x7a2410: r0 = GDT[cid_x0 + -0xd83]()
    //     0x7a2410: sub             lr, x0, #0xd83
    //     0x7a2414: ldr             lr, [x21, lr, lsl #3]
    //     0x7a2418: blr             lr
    // 0x7a241c: add             SP, SP, #0x10
    // 0x7a2420: mov             x1, x0
    // 0x7a2424: ldur            x0, [fp, #-0x20]
    // 0x7a2428: r2 = LoadClassIdInstr(r0)
    //     0x7a2428: ldur            x2, [x0, #-1]
    //     0x7a242c: ubfx            x2, x2, #0xc, #0x14
    // 0x7a2430: ldur            x16, [fp, #-8]
    // 0x7a2434: stp             x16, x0, [SP, #-0x10]!
    // 0x7a2438: SaveReg r1
    //     0x7a2438: str             x1, [SP, #-8]!
    // 0x7a243c: mov             x0, x2
    // 0x7a2440: r0 = GDT[cid_x0 + 0x1015e]()
    //     0x7a2440: mov             x17, #0x15e
    //     0x7a2444: movk            x17, #1, lsl #16
    //     0x7a2448: add             lr, x0, x17
    //     0x7a244c: ldr             lr, [x21, lr, lsl #3]
    //     0x7a2450: blr             lr
    // 0x7a2454: add             SP, SP, #0x18
    // 0x7a2458: ldur            x0, [fp, #-0x10]
    // 0x7a245c: LoadField: r1 = r0->field_f
    //     0x7a245c: ldur            w1, [x0, #0xf]
    // 0x7a2460: DecompressPointer r1
    //     0x7a2460: add             x1, x1, HEAP, lsl #32
    // 0x7a2464: LoadField: r0 = r1->field_27
    //     0x7a2464: ldur            w0, [x1, #0x27]
    // 0x7a2468: DecompressPointer r0
    //     0x7a2468: add             x0, x0, HEAP, lsl #32
    // 0x7a246c: cmp             w0, NULL
    // 0x7a2470: b.eq            #0x7a24cc
    // 0x7a2474: r1 = LoadClassIdInstr(r0)
    //     0x7a2474: ldur            x1, [x0, #-1]
    //     0x7a2478: ubfx            x1, x1, #0xc, #0x14
    // 0x7a247c: ldur            x16, [fp, #-0x18]
    // 0x7a2480: stp             x16, x0, [SP, #-0x10]!
    // 0x7a2484: ldur            x16, [fp, #-0x28]
    // 0x7a2488: SaveReg r16
    //     0x7a2488: str             x16, [SP, #-8]!
    // 0x7a248c: mov             x0, x1
    // 0x7a2490: r0 = GDT[cid_x0 + 0x1015e]()
    //     0x7a2490: mov             x17, #0x15e
    //     0x7a2494: movk            x17, #1, lsl #16
    //     0x7a2498: add             lr, x0, x17
    //     0x7a249c: ldr             lr, [x21, lr, lsl #3]
    //     0x7a24a0: blr             lr
    // 0x7a24a4: add             SP, SP, #0x18
    // 0x7a24a8: r0 = Null
    //     0x7a24a8: mov             x0, NULL
    // 0x7a24ac: LeaveFrame
    //     0x7a24ac: mov             SP, fp
    //     0x7a24b0: ldp             fp, lr, [SP], #0x10
    // 0x7a24b4: ret
    //     0x7a24b4: ret             
    // 0x7a24b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a24b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a24bc: b               #0x7a2320
    // 0x7a24c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a24c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7a24c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a24c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7a24c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a24c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7a24cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a24cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x83373c, size: 0x158
    // 0x83373c: EnterFrame
    //     0x83373c: stp             fp, lr, [SP, #-0x10]!
    //     0x833740: mov             fp, SP
    // 0x833744: AllocStack(0x30)
    //     0x833744: sub             SP, SP, #0x30
    // 0x833748: CheckStackOverflow
    //     0x833748: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83374c: cmp             SP, x16
    //     0x833750: b.ls            #0x833878
    // 0x833754: r1 = 1
    //     0x833754: mov             x1, #1
    // 0x833758: r0 = AllocateContext()
    //     0x833758: bl              #0xd68aa4  ; AllocateContextStub
    // 0x83375c: mov             x1, x0
    // 0x833760: ldr             x0, [fp, #0x18]
    // 0x833764: stur            x1, [fp, #-8]
    // 0x833768: StoreField: r1->field_f = r0
    //     0x833768: stur            w0, [x1, #0xf]
    // 0x83376c: r1 = 1
    //     0x83376c: mov             x1, #1
    // 0x833770: r0 = AllocateContext()
    //     0x833770: bl              #0xd68aa4  ; AllocateContextStub
    // 0x833774: mov             x1, x0
    // 0x833778: ldr             x0, [fp, #0x18]
    // 0x83377c: stur            x1, [fp, #-0x28]
    // 0x833780: StoreField: r1->field_f = r0
    //     0x833780: stur            w0, [x1, #0xf]
    // 0x833784: LoadField: r2 = r0->field_b
    //     0x833784: ldur            w2, [x0, #0xb]
    // 0x833788: DecompressPointer r2
    //     0x833788: add             x2, x2, HEAP, lsl #32
    // 0x83378c: cmp             w2, NULL
    // 0x833790: b.eq            #0x833880
    // 0x833794: LoadField: r2 = r0->field_1f
    //     0x833794: ldur            w2, [x0, #0x1f]
    // 0x833798: DecompressPointer r2
    //     0x833798: add             x2, x2, HEAP, lsl #32
    // 0x83379c: r16 = Sentinel
    //     0x83379c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8337a0: cmp             w2, w16
    // 0x8337a4: b.eq            #0x833884
    // 0x8337a8: stur            x2, [fp, #-0x20]
    // 0x8337ac: LoadField: r3 = r0->field_17
    //     0x8337ac: ldur            w3, [x0, #0x17]
    // 0x8337b0: DecompressPointer r3
    //     0x8337b0: add             x3, x3, HEAP, lsl #32
    // 0x8337b4: stur            x3, [fp, #-0x18]
    // 0x8337b8: LoadField: r4 = r0->field_27
    //     0x8337b8: ldur            w4, [x0, #0x27]
    // 0x8337bc: DecompressPointer r4
    //     0x8337bc: add             x4, x4, HEAP, lsl #32
    // 0x8337c0: stur            x4, [fp, #-0x10]
    // 0x8337c4: cmp             w4, NULL
    // 0x8337c8: b.eq            #0x833890
    // 0x8337cc: r0 = ExtendedPageView()
    //     0x8337cc: bl              #0x8339f4  ; AllocateExtendedPageViewStub -> ExtendedPageView (size=0x44)
    // 0x8337d0: stur            x0, [fp, #-0x30]
    // 0x8337d4: ldur            x16, [fp, #-0x10]
    // 0x8337d8: stp             x16, x0, [SP, #-0x10]!
    // 0x8337dc: ldur            x16, [fp, #-0x20]
    // 0x8337e0: ldur            lr, [fp, #-0x18]
    // 0x8337e4: stp             lr, x16, [SP, #-0x10]!
    // 0x8337e8: r0 = ExtendedPageView()
    //     0x8337e8: bl              #0x833900  ; [package:extended_tabs/src/page_view.dart] ExtendedPageView::ExtendedPageView
    // 0x8337ec: add             SP, SP, #0x20
    // 0x8337f0: ldur            x2, [fp, #-0x28]
    // 0x8337f4: r1 = Function '_handleGlowNotification@470121374':.
    //     0x8337f4: add             x1, PP, #0x38, lsl #12  ; [pp+0x38130] AnonymousClosure: (0x83431c), in [package:extended_tabs/src/tab_view.dart] ExtendedTabBarViewState::_handleGlowNotification (0x834368)
    //     0x8337f8: ldr             x1, [x1, #0x130]
    // 0x8337fc: r0 = AllocateClosure()
    //     0x8337fc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x833800: r1 = <OverscrollIndicatorNotification>
    //     0x833800: add             x1, PP, #0x38, lsl #12  ; [pp+0x38138] TypeArguments: <OverscrollIndicatorNotification>
    //     0x833804: ldr             x1, [x1, #0x138]
    // 0x833808: stur            x0, [fp, #-0x10]
    // 0x83380c: r0 = NotificationListener()
    //     0x83380c: bl              #0x7bb850  ; AllocateNotificationListenerStub -> NotificationListener<X0 bound Notification> (size=0x18)
    // 0x833810: mov             x3, x0
    // 0x833814: ldur            x0, [fp, #-0x10]
    // 0x833818: stur            x3, [fp, #-0x18]
    // 0x83381c: StoreField: r3->field_13 = r0
    //     0x83381c: stur            w0, [x3, #0x13]
    // 0x833820: ldur            x0, [fp, #-0x30]
    // 0x833824: StoreField: r3->field_b = r0
    //     0x833824: stur            w0, [x3, #0xb]
    // 0x833828: ldur            x2, [fp, #-8]
    // 0x83382c: r1 = Function '_handleScrollNotification@470121374':.
    //     0x83382c: add             x1, PP, #0x38, lsl #12  ; [pp+0x38140] AnonymousClosure: (0x833a00), in [package:extended_tabs/src/tab_view.dart] ExtendedTabBarViewState::_handleScrollNotification (0x833a4c)
    //     0x833830: ldr             x1, [x1, #0x140]
    // 0x833834: r0 = AllocateClosure()
    //     0x833834: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x833838: r1 = <ScrollNotification>
    //     0x833838: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2ccf8] TypeArguments: <ScrollNotification>
    //     0x83383c: ldr             x1, [x1, #0xcf8]
    // 0x833840: stur            x0, [fp, #-8]
    // 0x833844: r0 = NotificationListener()
    //     0x833844: bl              #0x7bb850  ; AllocateNotificationListenerStub -> NotificationListener<X0 bound Notification> (size=0x18)
    // 0x833848: mov             x1, x0
    // 0x83384c: ldur            x0, [fp, #-8]
    // 0x833850: StoreField: r1->field_13 = r0
    //     0x833850: stur            w0, [x1, #0x13]
    // 0x833854: ldur            x0, [fp, #-0x18]
    // 0x833858: StoreField: r1->field_b = r0
    //     0x833858: stur            w0, [x1, #0xb]
    // 0x83385c: ldr             x16, [fp, #0x18]
    // 0x833860: stp             x1, x16, [SP, #-0x10]!
    // 0x833864: r0 = buildGestureDetector()
    //     0x833864: bl              #0x833894  ; [package:sync_scroll_library/src/gesture/gesture_state_mixin.dart] GestureStateMixin::buildGestureDetector
    // 0x833868: add             SP, SP, #0x10
    // 0x83386c: LeaveFrame
    //     0x83386c: mov             SP, fp
    //     0x833870: ldp             fp, lr, [SP], #0x10
    // 0x833874: ret
    //     0x833874: ret             
    // 0x833878: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x833878: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83387c: b               #0x833754
    // 0x833880: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x833880: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x833884: r9 = _pageController
    //     0x833884: add             x9, PP, #0x2f, lsl #12  ; [pp+0x2f3d8] Field <ExtendedTabBarViewState._pageController@470121374>: late (offset: 0x20)
    //     0x833888: ldr             x9, [x9, #0x3d8]
    // 0x83388c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x83388c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x833890: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x833890: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool _handleScrollNotification(dynamic, ScrollNotification) {
    // ** addr: 0x833a00, size: 0x4c
    // 0x833a00: EnterFrame
    //     0x833a00: stp             fp, lr, [SP, #-0x10]!
    //     0x833a04: mov             fp, SP
    // 0x833a08: ldr             x0, [fp, #0x18]
    // 0x833a0c: LoadField: r1 = r0->field_17
    //     0x833a0c: ldur            w1, [x0, #0x17]
    // 0x833a10: DecompressPointer r1
    //     0x833a10: add             x1, x1, HEAP, lsl #32
    // 0x833a14: CheckStackOverflow
    //     0x833a14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x833a18: cmp             SP, x16
    //     0x833a1c: b.ls            #0x833a44
    // 0x833a20: LoadField: r0 = r1->field_f
    //     0x833a20: ldur            w0, [x1, #0xf]
    // 0x833a24: DecompressPointer r0
    //     0x833a24: add             x0, x0, HEAP, lsl #32
    // 0x833a28: ldr             x16, [fp, #0x10]
    // 0x833a2c: stp             x16, x0, [SP, #-0x10]!
    // 0x833a30: r0 = _handleScrollNotification()
    //     0x833a30: bl              #0x833a4c  ; [package:extended_tabs/src/tab_view.dart] ExtendedTabBarViewState::_handleScrollNotification
    // 0x833a34: add             SP, SP, #0x10
    // 0x833a38: LeaveFrame
    //     0x833a38: mov             SP, fp
    //     0x833a3c: ldp             fp, lr, [SP], #0x10
    // 0x833a40: ret
    //     0x833a40: ret             
    // 0x833a44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x833a44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x833a48: b               #0x833a20
  }
  _ _handleScrollNotification(/* No info */) {
    // ** addr: 0x833a4c, size: 0x76c
    // 0x833a4c: EnterFrame
    //     0x833a4c: stp             fp, lr, [SP, #-0x10]!
    //     0x833a50: mov             fp, SP
    // 0x833a54: AllocStack(0x10)
    //     0x833a54: sub             SP, SP, #0x10
    // 0x833a58: CheckStackOverflow
    //     0x833a58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x833a5c: cmp             SP, x16
    //     0x833a60: b.ls            #0x8340c8
    // 0x833a64: ldr             x0, [fp, #0x18]
    // 0x833a68: LoadField: r1 = r0->field_2f
    //     0x833a68: ldur            x1, [x0, #0x2f]
    // 0x833a6c: cmp             x1, #0
    // 0x833a70: b.le            #0x833a84
    // 0x833a74: r0 = false
    //     0x833a74: add             x0, NULL, #0x30  ; false
    // 0x833a78: LeaveFrame
    //     0x833a78: mov             SP, fp
    //     0x833a7c: ldp             fp, lr, [SP], #0x10
    // 0x833a80: ret
    //     0x833a80: ret             
    // 0x833a84: ldr             x2, [fp, #0x10]
    // 0x833a88: LoadField: r3 = r2->field_7
    //     0x833a88: ldur            x3, [x2, #7]
    // 0x833a8c: cbz             x3, #0x833aa0
    // 0x833a90: r0 = false
    //     0x833a90: add             x0, NULL, #0x30  ; false
    // 0x833a94: LeaveFrame
    //     0x833a94: mov             SP, fp
    //     0x833a98: ldp             fp, lr, [SP], #0x10
    // 0x833a9c: ret
    //     0x833a9c: ret             
    // 0x833aa0: add             x3, x1, #1
    // 0x833aa4: StoreField: r0->field_2f = r3
    //     0x833aa4: stur            x3, [x0, #0x2f]
    // 0x833aa8: r1 = LoadClassIdInstr(r2)
    //     0x833aa8: ldur            x1, [x2, #-1]
    //     0x833aac: ubfx            x1, x1, #0xc, #0x14
    // 0x833ab0: lsl             x1, x1, #1
    // 0x833ab4: r2 = LoadInt32Instr(r1)
    //     0x833ab4: sbfx            x2, x1, #1, #0x1f
    // 0x833ab8: cmp             x2, #0x731
    // 0x833abc: b.lt            #0x833e2c
    // 0x833ac0: cmp             x2, #0x732
    // 0x833ac4: b.gt            #0x833e24
    // 0x833ac8: LoadField: r2 = r0->field_1b
    //     0x833ac8: ldur            w2, [x0, #0x1b]
    // 0x833acc: DecompressPointer r2
    //     0x833acc: add             x2, x2, HEAP, lsl #32
    // 0x833ad0: cmp             w2, NULL
    // 0x833ad4: b.eq            #0x8340d0
    // 0x833ad8: LoadField: r3 = r2->field_43
    //     0x833ad8: ldur            x3, [x2, #0x43]
    // 0x833adc: cbnz            x3, #0x833e1c
    // 0x833ae0: LoadField: r1 = r0->field_1f
    //     0x833ae0: ldur            w1, [x0, #0x1f]
    // 0x833ae4: DecompressPointer r1
    //     0x833ae4: add             x1, x1, HEAP, lsl #32
    // 0x833ae8: r16 = Sentinel
    //     0x833ae8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x833aec: cmp             w1, w16
    // 0x833af0: b.eq            #0x8340d4
    // 0x833af4: LoadField: r2 = r1->field_33
    //     0x833af4: ldur            w2, [x1, #0x33]
    // 0x833af8: DecompressPointer r2
    //     0x833af8: add             x2, x2, HEAP, lsl #32
    // 0x833afc: SaveReg r2
    //     0x833afc: str             x2, [SP, #-8]!
    // 0x833b00: r0 = single()
    //     0x833b00: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x833b04: add             SP, SP, #8
    // 0x833b08: mov             x3, x0
    // 0x833b0c: r2 = Null
    //     0x833b0c: mov             x2, NULL
    // 0x833b10: r1 = Null
    //     0x833b10: mov             x1, NULL
    // 0x833b14: stur            x3, [fp, #-8]
    // 0x833b18: r4 = LoadClassIdInstr(r0)
    //     0x833b18: ldur            x4, [x0, #-1]
    //     0x833b1c: ubfx            x4, x4, #0xc, #0x14
    // 0x833b20: r17 = 4847
    //     0x833b20: mov             x17, #0x12ef
    // 0x833b24: cmp             x4, x17
    // 0x833b28: b.eq            #0x833b40
    // 0x833b2c: r8 = _PagePosition
    //     0x833b2c: add             x8, PP, #0x32, lsl #12  ; [pp+0x32f98] Type: _PagePosition
    //     0x833b30: ldr             x8, [x8, #0xf98]
    // 0x833b34: r3 = Null
    //     0x833b34: add             x3, PP, #0x38, lsl #12  ; [pp+0x38148] Null
    //     0x833b38: ldr             x3, [x3, #0x148]
    // 0x833b3c: r0 = DefaultTypeTest()
    //     0x833b3c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x833b40: ldur            x16, [fp, #-8]
    // 0x833b44: SaveReg r16
    //     0x833b44: str             x16, [SP, #-8]!
    // 0x833b48: r0 = page()
    //     0x833b48: bl              #0x7a1f64  ; [package:flutter/src/widgets/page_view.dart] _PagePosition::page
    // 0x833b4c: add             SP, SP, #8
    // 0x833b50: cmp             w0, NULL
    // 0x833b54: b.eq            #0x8340e0
    // 0x833b58: ldr             x1, [fp, #0x18]
    // 0x833b5c: LoadField: r2 = r1->field_1b
    //     0x833b5c: ldur            w2, [x1, #0x1b]
    // 0x833b60: DecompressPointer r2
    //     0x833b60: add             x2, x2, HEAP, lsl #32
    // 0x833b64: stur            x2, [fp, #-8]
    // 0x833b68: cmp             w2, NULL
    // 0x833b6c: b.eq            #0x8340e4
    // 0x833b70: LoadField: r3 = r2->field_33
    //     0x833b70: ldur            x3, [x2, #0x33]
    // 0x833b74: scvtf           d0, x3
    // 0x833b78: LoadField: d1 = r0->field_7
    //     0x833b78: ldur            d1, [x0, #7]
    // 0x833b7c: fsub            d2, d1, d0
    // 0x833b80: d0 = 0.000000
    //     0x833b80: eor             v0.16b, v0.16b, v0.16b
    // 0x833b84: fcmp            d2, d0
    // 0x833b88: b.vs            #0x833b98
    // 0x833b8c: b.ne            #0x833b98
    // 0x833b90: d1 = 0.000000
    //     0x833b90: eor             v1.16b, v1.16b, v1.16b
    // 0x833b94: b               #0x833bb4
    // 0x833b98: fcmp            d2, d0
    // 0x833b9c: b.vs            #0x833bac
    // 0x833ba0: b.ge            #0x833bac
    // 0x833ba4: fneg            d0, d2
    // 0x833ba8: b               #0x833bb0
    // 0x833bac: mov             v0.16b, v2.16b
    // 0x833bb0: mov             v1.16b, v0.16b
    // 0x833bb4: d0 = 1.000000
    //     0x833bb4: fmov            d0, #1.00000000
    // 0x833bb8: fcmp            d1, d0
    // 0x833bbc: b.vs            #0x833cf8
    // 0x833bc0: b.le            #0x833cf8
    // 0x833bc4: LoadField: r0 = r1->field_1f
    //     0x833bc4: ldur            w0, [x1, #0x1f]
    // 0x833bc8: DecompressPointer r0
    //     0x833bc8: add             x0, x0, HEAP, lsl #32
    // 0x833bcc: LoadField: r3 = r0->field_33
    //     0x833bcc: ldur            w3, [x0, #0x33]
    // 0x833bd0: DecompressPointer r3
    //     0x833bd0: add             x3, x3, HEAP, lsl #32
    // 0x833bd4: SaveReg r3
    //     0x833bd4: str             x3, [SP, #-8]!
    // 0x833bd8: r0 = single()
    //     0x833bd8: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x833bdc: add             SP, SP, #8
    // 0x833be0: mov             x3, x0
    // 0x833be4: r2 = Null
    //     0x833be4: mov             x2, NULL
    // 0x833be8: r1 = Null
    //     0x833be8: mov             x1, NULL
    // 0x833bec: stur            x3, [fp, #-0x10]
    // 0x833bf0: r4 = LoadClassIdInstr(r0)
    //     0x833bf0: ldur            x4, [x0, #-1]
    //     0x833bf4: ubfx            x4, x4, #0xc, #0x14
    // 0x833bf8: r17 = 4847
    //     0x833bf8: mov             x17, #0x12ef
    // 0x833bfc: cmp             x4, x17
    // 0x833c00: b.eq            #0x833c18
    // 0x833c04: r8 = _PagePosition
    //     0x833c04: add             x8, PP, #0x32, lsl #12  ; [pp+0x32f98] Type: _PagePosition
    //     0x833c08: ldr             x8, [x8, #0xf98]
    // 0x833c0c: r3 = Null
    //     0x833c0c: add             x3, PP, #0x38, lsl #12  ; [pp+0x38158] Null
    //     0x833c10: ldr             x3, [x3, #0x158]
    // 0x833c14: r0 = DefaultTypeTest()
    //     0x833c14: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x833c18: ldur            x16, [fp, #-0x10]
    // 0x833c1c: SaveReg r16
    //     0x833c1c: str             x16, [SP, #-8]!
    // 0x833c20: r0 = page()
    //     0x833c20: bl              #0x7a1f64  ; [package:flutter/src/widgets/page_view.dart] _PagePosition::page
    // 0x833c24: add             SP, SP, #8
    // 0x833c28: cmp             w0, NULL
    // 0x833c2c: b.eq            #0x8340e8
    // 0x833c30: LoadField: d0 = r0->field_7
    //     0x833c30: ldur            d0, [x0, #7]
    // 0x833c34: stp             fp, lr, [SP, #-0x10]!
    // 0x833c38: mov             fp, SP
    // 0x833c3c: CallRuntime_LibcRound(double) -> double
    //     0x833c3c: and             SP, SP, #0xfffffffffffffff0
    //     0x833c40: mov             sp, SP
    //     0x833c44: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0x833c48: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x833c4c: blr             x16
    //     0x833c50: mov             x16, #8
    //     0x833c54: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x833c58: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x833c5c: sub             sp, x16, #1, lsl #12
    //     0x833c60: mov             SP, fp
    //     0x833c64: ldp             fp, lr, [SP], #0x10
    // 0x833c68: fcmp            d0, d0
    // 0x833c6c: b.vs            #0x8340ec
    // 0x833c70: fcvtzs          x0, d0
    // 0x833c74: asr             x16, x0, #0x1e
    // 0x833c78: cmp             x16, x0, asr #63
    // 0x833c7c: b.ne            #0x8340ec
    // 0x833c80: lsl             x0, x0, #1
    // 0x833c84: r1 = LoadInt32Instr(r0)
    //     0x833c84: sbfx            x1, x0, #1, #0x1f
    //     0x833c88: tbz             w0, #0, #0x833c90
    //     0x833c8c: ldur            x1, [x0, #7]
    // 0x833c90: ldur            x16, [fp, #-8]
    // 0x833c94: stp             x1, x16, [SP, #-0x10]!
    // 0x833c98: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x833c98: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x833c9c: r0 = _changeIndex()
    //     0x833c9c: bl              #0x82637c  ; [package:flutter/src/material/tab_controller.dart] TabController::_changeIndex
    // 0x833ca0: add             SP, SP, #0x10
    // 0x833ca4: ldr             x2, [fp, #0x18]
    // 0x833ca8: LoadField: r3 = r2->field_1b
    //     0x833ca8: ldur            w3, [x2, #0x1b]
    // 0x833cac: DecompressPointer r3
    //     0x833cac: add             x3, x3, HEAP, lsl #32
    // 0x833cb0: cmp             w3, NULL
    // 0x833cb4: b.eq            #0x834108
    // 0x833cb8: LoadField: r4 = r3->field_33
    //     0x833cb8: ldur            x4, [x3, #0x33]
    // 0x833cbc: r0 = BoxInt64Instr(r4)
    //     0x833cbc: sbfiz           x0, x4, #1, #0x1f
    //     0x833cc0: cmp             x4, x0, asr #1
    //     0x833cc4: b.eq            #0x833cd0
    //     0x833cc8: bl              #0xd69bb8
    //     0x833ccc: stur            x4, [x0, #7]
    // 0x833cd0: StoreField: r2->field_2b = r0
    //     0x833cd0: stur            w0, [x2, #0x2b]
    //     0x833cd4: tbz             w0, #0, #0x833cf0
    //     0x833cd8: ldurb           w16, [x2, #-1]
    //     0x833cdc: ldurb           w17, [x0, #-1]
    //     0x833ce0: and             x16, x17, x16, lsr #2
    //     0x833ce4: tst             x16, HEAP, lsr #32
    //     0x833ce8: b.eq            #0x833cf0
    //     0x833cec: bl              #0xd6828c
    // 0x833cf0: mov             x0, x3
    // 0x833cf4: b               #0x833d00
    // 0x833cf8: mov             x2, x1
    // 0x833cfc: ldur            x0, [fp, #-8]
    // 0x833d00: stur            x0, [fp, #-8]
    // 0x833d04: LoadField: r1 = r2->field_1f
    //     0x833d04: ldur            w1, [x2, #0x1f]
    // 0x833d08: DecompressPointer r1
    //     0x833d08: add             x1, x1, HEAP, lsl #32
    // 0x833d0c: LoadField: r3 = r1->field_33
    //     0x833d0c: ldur            w3, [x1, #0x33]
    // 0x833d10: DecompressPointer r3
    //     0x833d10: add             x3, x3, HEAP, lsl #32
    // 0x833d14: SaveReg r3
    //     0x833d14: str             x3, [SP, #-8]!
    // 0x833d18: r0 = single()
    //     0x833d18: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x833d1c: add             SP, SP, #8
    // 0x833d20: mov             x3, x0
    // 0x833d24: r2 = Null
    //     0x833d24: mov             x2, NULL
    // 0x833d28: r1 = Null
    //     0x833d28: mov             x1, NULL
    // 0x833d2c: stur            x3, [fp, #-0x10]
    // 0x833d30: r4 = LoadClassIdInstr(r0)
    //     0x833d30: ldur            x4, [x0, #-1]
    //     0x833d34: ubfx            x4, x4, #0xc, #0x14
    // 0x833d38: r17 = 4847
    //     0x833d38: mov             x17, #0x12ef
    // 0x833d3c: cmp             x4, x17
    // 0x833d40: b.eq            #0x833d58
    // 0x833d44: r8 = _PagePosition
    //     0x833d44: add             x8, PP, #0x32, lsl #12  ; [pp+0x32f98] Type: _PagePosition
    //     0x833d48: ldr             x8, [x8, #0xf98]
    // 0x833d4c: r3 = Null
    //     0x833d4c: add             x3, PP, #0x38, lsl #12  ; [pp+0x38168] Null
    //     0x833d50: ldr             x3, [x3, #0x168]
    // 0x833d54: r0 = DefaultTypeTest()
    //     0x833d54: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x833d58: ldur            x16, [fp, #-0x10]
    // 0x833d5c: SaveReg r16
    //     0x833d5c: str             x16, [SP, #-8]!
    // 0x833d60: r0 = page()
    //     0x833d60: bl              #0x7a1f64  ; [package:flutter/src/widgets/page_view.dart] _PagePosition::page
    // 0x833d64: add             SP, SP, #8
    // 0x833d68: cmp             w0, NULL
    // 0x833d6c: b.eq            #0x83410c
    // 0x833d70: ldr             x1, [fp, #0x18]
    // 0x833d74: LoadField: r2 = r1->field_1b
    //     0x833d74: ldur            w2, [x1, #0x1b]
    // 0x833d78: DecompressPointer r2
    //     0x833d78: add             x2, x2, HEAP, lsl #32
    // 0x833d7c: cmp             w2, NULL
    // 0x833d80: b.eq            #0x834110
    // 0x833d84: LoadField: r3 = r2->field_33
    //     0x833d84: ldur            x3, [x2, #0x33]
    // 0x833d88: scvtf           d0, x3
    // 0x833d8c: LoadField: d1 = r0->field_7
    //     0x833d8c: ldur            d1, [x0, #7]
    // 0x833d90: fsub            d2, d1, d0
    // 0x833d94: d0 = 1.000000
    //     0x833d94: fmov            d0, #1.00000000
    // 0x833d98: fneg            d1, d0
    // 0x833d9c: r0 = inline_Allocate_Double()
    //     0x833d9c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x833da0: add             x0, x0, #0x10
    //     0x833da4: cmp             x2, x0
    //     0x833da8: b.ls            #0x834114
    //     0x833dac: str             x0, [THR, #0x60]  ; THR::top
    //     0x833db0: sub             x0, x0, #0xf
    //     0x833db4: mov             x2, #0xd108
    //     0x833db8: movk            x2, #3, lsl #16
    //     0x833dbc: stur            x2, [x0, #-1]
    // 0x833dc0: StoreField: r0->field_7 = d2
    //     0x833dc0: stur            d2, [x0, #7]
    // 0x833dc4: r2 = inline_Allocate_Double()
    //     0x833dc4: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x833dc8: add             x2, x2, #0x10
    //     0x833dcc: cmp             x3, x2
    //     0x833dd0: b.ls            #0x83412c
    //     0x833dd4: str             x2, [THR, #0x60]  ; THR::top
    //     0x833dd8: sub             x2, x2, #0xf
    //     0x833ddc: mov             x3, #0xd108
    //     0x833de0: movk            x3, #3, lsl #16
    //     0x833de4: stur            x3, [x2, #-1]
    // 0x833de8: StoreField: r2->field_7 = d1
    //     0x833de8: stur            d1, [x2, #7]
    // 0x833dec: stp             x2, x0, [SP, #-0x10]!
    // 0x833df0: r16 = 1.000000
    //     0x833df0: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x833df4: SaveReg r16
    //     0x833df4: str             x16, [SP, #-8]!
    // 0x833df8: r0 = clamp()
    //     0x833df8: bl              #0xd66c00  ; [dart:core] _Double::clamp
    // 0x833dfc: add             SP, SP, #0x18
    // 0x833e00: LoadField: d0 = r0->field_7
    //     0x833e00: ldur            d0, [x0, #7]
    // 0x833e04: ldur            x16, [fp, #-8]
    // 0x833e08: SaveReg r16
    //     0x833e08: str             x16, [SP, #-8]!
    // 0x833e0c: SaveReg d0
    //     0x833e0c: str             d0, [SP, #-8]!
    // 0x833e10: r0 = offset=()
    //     0x833e10: bl              #0x8341b8  ; [package:flutter/src/material/tab_controller.dart] TabController::offset=
    // 0x833e14: add             SP, SP, #0x10
    // 0x833e18: b               #0x8340a8
    // 0x833e1c: d0 = 1.000000
    //     0x833e1c: fmov            d0, #1.00000000
    // 0x833e20: b               #0x833e30
    // 0x833e24: d0 = 1.000000
    //     0x833e24: fmov            d0, #1.00000000
    // 0x833e28: b               #0x833e30
    // 0x833e2c: d0 = 1.000000
    //     0x833e2c: fmov            d0, #1.00000000
    // 0x833e30: cmp             w1, #0xe5e
    // 0x833e34: b.ne            #0x8340a8
    // 0x833e38: ldr             x0, [fp, #0x18]
    // 0x833e3c: LoadField: r1 = r0->field_1b
    //     0x833e3c: ldur            w1, [x0, #0x1b]
    // 0x833e40: DecompressPointer r1
    //     0x833e40: add             x1, x1, HEAP, lsl #32
    // 0x833e44: stur            x1, [fp, #-8]
    // 0x833e48: cmp             w1, NULL
    // 0x833e4c: b.eq            #0x834148
    // 0x833e50: LoadField: r2 = r0->field_1f
    //     0x833e50: ldur            w2, [x0, #0x1f]
    // 0x833e54: DecompressPointer r2
    //     0x833e54: add             x2, x2, HEAP, lsl #32
    // 0x833e58: r16 = Sentinel
    //     0x833e58: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x833e5c: cmp             w2, w16
    // 0x833e60: b.eq            #0x83414c
    // 0x833e64: LoadField: r3 = r2->field_33
    //     0x833e64: ldur            w3, [x2, #0x33]
    // 0x833e68: DecompressPointer r3
    //     0x833e68: add             x3, x3, HEAP, lsl #32
    // 0x833e6c: SaveReg r3
    //     0x833e6c: str             x3, [SP, #-8]!
    // 0x833e70: r0 = single()
    //     0x833e70: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x833e74: add             SP, SP, #8
    // 0x833e78: mov             x3, x0
    // 0x833e7c: r2 = Null
    //     0x833e7c: mov             x2, NULL
    // 0x833e80: r1 = Null
    //     0x833e80: mov             x1, NULL
    // 0x833e84: stur            x3, [fp, #-0x10]
    // 0x833e88: r4 = LoadClassIdInstr(r0)
    //     0x833e88: ldur            x4, [x0, #-1]
    //     0x833e8c: ubfx            x4, x4, #0xc, #0x14
    // 0x833e90: r17 = 4847
    //     0x833e90: mov             x17, #0x12ef
    // 0x833e94: cmp             x4, x17
    // 0x833e98: b.eq            #0x833eb0
    // 0x833e9c: r8 = _PagePosition
    //     0x833e9c: add             x8, PP, #0x32, lsl #12  ; [pp+0x32f98] Type: _PagePosition
    //     0x833ea0: ldr             x8, [x8, #0xf98]
    // 0x833ea4: r3 = Null
    //     0x833ea4: add             x3, PP, #0x38, lsl #12  ; [pp+0x38178] Null
    //     0x833ea8: ldr             x3, [x3, #0x178]
    // 0x833eac: r0 = DefaultTypeTest()
    //     0x833eac: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x833eb0: ldur            x16, [fp, #-0x10]
    // 0x833eb4: SaveReg r16
    //     0x833eb4: str             x16, [SP, #-8]!
    // 0x833eb8: r0 = page()
    //     0x833eb8: bl              #0x7a1f64  ; [package:flutter/src/widgets/page_view.dart] _PagePosition::page
    // 0x833ebc: add             SP, SP, #8
    // 0x833ec0: cmp             w0, NULL
    // 0x833ec4: b.eq            #0x834158
    // 0x833ec8: LoadField: d0 = r0->field_7
    //     0x833ec8: ldur            d0, [x0, #7]
    // 0x833ecc: stp             fp, lr, [SP, #-0x10]!
    // 0x833ed0: mov             fp, SP
    // 0x833ed4: CallRuntime_LibcRound(double) -> double
    //     0x833ed4: and             SP, SP, #0xfffffffffffffff0
    //     0x833ed8: mov             sp, SP
    //     0x833edc: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0x833ee0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x833ee4: blr             x16
    //     0x833ee8: mov             x16, #8
    //     0x833eec: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x833ef0: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x833ef4: sub             sp, x16, #1, lsl #12
    //     0x833ef8: mov             SP, fp
    //     0x833efc: ldp             fp, lr, [SP], #0x10
    // 0x833f00: fcmp            d0, d0
    // 0x833f04: b.vs            #0x83415c
    // 0x833f08: fcvtzs          x0, d0
    // 0x833f0c: asr             x16, x0, #0x1e
    // 0x833f10: cmp             x16, x0, asr #63
    // 0x833f14: b.ne            #0x83415c
    // 0x833f18: lsl             x0, x0, #1
    // 0x833f1c: r1 = LoadInt32Instr(r0)
    //     0x833f1c: sbfx            x1, x0, #1, #0x1f
    //     0x833f20: tbz             w0, #0, #0x833f28
    //     0x833f24: ldur            x1, [x0, #7]
    // 0x833f28: ldur            x16, [fp, #-8]
    // 0x833f2c: stp             x1, x16, [SP, #-0x10]!
    // 0x833f30: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x833f30: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x833f34: r0 = _changeIndex()
    //     0x833f34: bl              #0x82637c  ; [package:flutter/src/material/tab_controller.dart] TabController::_changeIndex
    // 0x833f38: add             SP, SP, #0x10
    // 0x833f3c: ldr             x2, [fp, #0x18]
    // 0x833f40: LoadField: r3 = r2->field_1b
    //     0x833f40: ldur            w3, [x2, #0x1b]
    // 0x833f44: DecompressPointer r3
    //     0x833f44: add             x3, x3, HEAP, lsl #32
    // 0x833f48: stur            x3, [fp, #-8]
    // 0x833f4c: cmp             w3, NULL
    // 0x833f50: b.eq            #0x834178
    // 0x833f54: LoadField: r4 = r3->field_33
    //     0x833f54: ldur            x4, [x3, #0x33]
    // 0x833f58: r0 = BoxInt64Instr(r4)
    //     0x833f58: sbfiz           x0, x4, #1, #0x1f
    //     0x833f5c: cmp             x4, x0, asr #1
    //     0x833f60: b.eq            #0x833f6c
    //     0x833f64: bl              #0xd69bb8
    //     0x833f68: stur            x4, [x0, #7]
    // 0x833f6c: StoreField: r2->field_2b = r0
    //     0x833f6c: stur            w0, [x2, #0x2b]
    //     0x833f70: tbz             w0, #0, #0x833f8c
    //     0x833f74: ldurb           w16, [x2, #-1]
    //     0x833f78: ldurb           w17, [x0, #-1]
    //     0x833f7c: and             x16, x17, x16, lsr #2
    //     0x833f80: tst             x16, HEAP, lsr #32
    //     0x833f84: b.eq            #0x833f8c
    //     0x833f88: bl              #0xd6828c
    // 0x833f8c: LoadField: r0 = r3->field_43
    //     0x833f8c: ldur            x0, [x3, #0x43]
    // 0x833f90: cbnz            x0, #0x8340a8
    // 0x833f94: LoadField: r0 = r2->field_1f
    //     0x833f94: ldur            w0, [x2, #0x1f]
    // 0x833f98: DecompressPointer r0
    //     0x833f98: add             x0, x0, HEAP, lsl #32
    // 0x833f9c: LoadField: r1 = r0->field_33
    //     0x833f9c: ldur            w1, [x0, #0x33]
    // 0x833fa0: DecompressPointer r1
    //     0x833fa0: add             x1, x1, HEAP, lsl #32
    // 0x833fa4: SaveReg r1
    //     0x833fa4: str             x1, [SP, #-8]!
    // 0x833fa8: r0 = single()
    //     0x833fa8: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x833fac: add             SP, SP, #8
    // 0x833fb0: mov             x3, x0
    // 0x833fb4: r2 = Null
    //     0x833fb4: mov             x2, NULL
    // 0x833fb8: r1 = Null
    //     0x833fb8: mov             x1, NULL
    // 0x833fbc: stur            x3, [fp, #-0x10]
    // 0x833fc0: r4 = LoadClassIdInstr(r0)
    //     0x833fc0: ldur            x4, [x0, #-1]
    //     0x833fc4: ubfx            x4, x4, #0xc, #0x14
    // 0x833fc8: r17 = 4847
    //     0x833fc8: mov             x17, #0x12ef
    // 0x833fcc: cmp             x4, x17
    // 0x833fd0: b.eq            #0x833fe8
    // 0x833fd4: r8 = _PagePosition
    //     0x833fd4: add             x8, PP, #0x32, lsl #12  ; [pp+0x32f98] Type: _PagePosition
    //     0x833fd8: ldr             x8, [x8, #0xf98]
    // 0x833fdc: r3 = Null
    //     0x833fdc: add             x3, PP, #0x38, lsl #12  ; [pp+0x38188] Null
    //     0x833fe0: ldr             x3, [x3, #0x188]
    // 0x833fe4: r0 = DefaultTypeTest()
    //     0x833fe4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x833fe8: ldur            x16, [fp, #-0x10]
    // 0x833fec: SaveReg r16
    //     0x833fec: str             x16, [SP, #-8]!
    // 0x833ff0: r0 = page()
    //     0x833ff0: bl              #0x7a1f64  ; [package:flutter/src/widgets/page_view.dart] _PagePosition::page
    // 0x833ff4: add             SP, SP, #8
    // 0x833ff8: cmp             w0, NULL
    // 0x833ffc: b.eq            #0x83417c
    // 0x834000: ldr             x1, [fp, #0x18]
    // 0x834004: LoadField: r2 = r1->field_1b
    //     0x834004: ldur            w2, [x1, #0x1b]
    // 0x834008: DecompressPointer r2
    //     0x834008: add             x2, x2, HEAP, lsl #32
    // 0x83400c: cmp             w2, NULL
    // 0x834010: b.eq            #0x834180
    // 0x834014: LoadField: r3 = r2->field_33
    //     0x834014: ldur            x3, [x2, #0x33]
    // 0x834018: scvtf           d0, x3
    // 0x83401c: LoadField: d1 = r0->field_7
    //     0x83401c: ldur            d1, [x0, #7]
    // 0x834020: fsub            d2, d1, d0
    // 0x834024: d0 = 1.000000
    //     0x834024: fmov            d0, #1.00000000
    // 0x834028: fneg            d1, d0
    // 0x83402c: r0 = inline_Allocate_Double()
    //     0x83402c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x834030: add             x0, x0, #0x10
    //     0x834034: cmp             x2, x0
    //     0x834038: b.ls            #0x834184
    //     0x83403c: str             x0, [THR, #0x60]  ; THR::top
    //     0x834040: sub             x0, x0, #0xf
    //     0x834044: mov             x2, #0xd108
    //     0x834048: movk            x2, #3, lsl #16
    //     0x83404c: stur            x2, [x0, #-1]
    // 0x834050: StoreField: r0->field_7 = d2
    //     0x834050: stur            d2, [x0, #7]
    // 0x834054: r2 = inline_Allocate_Double()
    //     0x834054: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x834058: add             x2, x2, #0x10
    //     0x83405c: cmp             x3, x2
    //     0x834060: b.ls            #0x83419c
    //     0x834064: str             x2, [THR, #0x60]  ; THR::top
    //     0x834068: sub             x2, x2, #0xf
    //     0x83406c: mov             x3, #0xd108
    //     0x834070: movk            x3, #3, lsl #16
    //     0x834074: stur            x3, [x2, #-1]
    // 0x834078: StoreField: r2->field_7 = d1
    //     0x834078: stur            d1, [x2, #7]
    // 0x83407c: stp             x2, x0, [SP, #-0x10]!
    // 0x834080: r16 = 1.000000
    //     0x834080: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x834084: SaveReg r16
    //     0x834084: str             x16, [SP, #-8]!
    // 0x834088: r0 = clamp()
    //     0x834088: bl              #0xd66c00  ; [dart:core] _Double::clamp
    // 0x83408c: add             SP, SP, #0x18
    // 0x834090: LoadField: d0 = r0->field_7
    //     0x834090: ldur            d0, [x0, #7]
    // 0x834094: ldur            x16, [fp, #-8]
    // 0x834098: SaveReg r16
    //     0x834098: str             x16, [SP, #-8]!
    // 0x83409c: SaveReg d0
    //     0x83409c: str             d0, [SP, #-8]!
    // 0x8340a0: r0 = offset=()
    //     0x8340a0: bl              #0x8341b8  ; [package:flutter/src/material/tab_controller.dart] TabController::offset=
    // 0x8340a4: add             SP, SP, #0x10
    // 0x8340a8: ldr             x1, [fp, #0x18]
    // 0x8340ac: LoadField: r2 = r1->field_2f
    //     0x8340ac: ldur            x2, [x1, #0x2f]
    // 0x8340b0: sub             x3, x2, #1
    // 0x8340b4: StoreField: r1->field_2f = r3
    //     0x8340b4: stur            x3, [x1, #0x2f]
    // 0x8340b8: r0 = false
    //     0x8340b8: add             x0, NULL, #0x30  ; false
    // 0x8340bc: LeaveFrame
    //     0x8340bc: mov             SP, fp
    //     0x8340c0: ldp             fp, lr, [SP], #0x10
    // 0x8340c4: ret
    //     0x8340c4: ret             
    // 0x8340c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8340c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8340cc: b               #0x833a64
    // 0x8340d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8340d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8340d4: r9 = _pageController
    //     0x8340d4: add             x9, PP, #0x2f, lsl #12  ; [pp+0x2f3d8] Field <ExtendedTabBarViewState._pageController@470121374>: late (offset: 0x20)
    //     0x8340d8: ldr             x9, [x9, #0x3d8]
    // 0x8340dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8340dc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8340e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8340e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8340e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8340e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8340e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8340e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8340ec: SaveReg d0
    //     0x8340ec: str             q0, [SP, #-0x10]!
    // 0x8340f0: r0 = 218
    //     0x8340f0: mov             x0, #0xda
    // 0x8340f4: r24 = DoubleToIntegerStub
    //     0x8340f4: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x8340f8: LoadField: r30 = r24->field_7
    //     0x8340f8: ldur            lr, [x24, #7]
    // 0x8340fc: blr             lr
    // 0x834100: RestoreReg d0
    //     0x834100: ldr             q0, [SP], #0x10
    // 0x834104: b               #0x833c84
    // 0x834108: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x834108: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83410c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83410c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x834110: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x834110: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x834114: stp             q1, q2, [SP, #-0x20]!
    // 0x834118: SaveReg r1
    //     0x834118: str             x1, [SP, #-8]!
    // 0x83411c: r0 = AllocateDouble()
    //     0x83411c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x834120: RestoreReg r1
    //     0x834120: ldr             x1, [SP], #8
    // 0x834124: ldp             q1, q2, [SP], #0x20
    // 0x834128: b               #0x833dc0
    // 0x83412c: SaveReg d1
    //     0x83412c: str             q1, [SP, #-0x10]!
    // 0x834130: stp             x0, x1, [SP, #-0x10]!
    // 0x834134: r0 = AllocateDouble()
    //     0x834134: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x834138: mov             x2, x0
    // 0x83413c: ldp             x0, x1, [SP], #0x10
    // 0x834140: RestoreReg d1
    //     0x834140: ldr             q1, [SP], #0x10
    // 0x834144: b               #0x833de8
    // 0x834148: r0 = NullCastErrorSharedWithFPURegs()
    //     0x834148: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x83414c: r9 = _pageController
    //     0x83414c: add             x9, PP, #0x2f, lsl #12  ; [pp+0x2f3d8] Field <ExtendedTabBarViewState._pageController@470121374>: late (offset: 0x20)
    //     0x834150: ldr             x9, [x9, #0x3d8]
    // 0x834154: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x834154: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x834158: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x834158: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83415c: SaveReg d0
    //     0x83415c: str             q0, [SP, #-0x10]!
    // 0x834160: r0 = 218
    //     0x834160: mov             x0, #0xda
    // 0x834164: r24 = DoubleToIntegerStub
    //     0x834164: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x834168: LoadField: r30 = r24->field_7
    //     0x834168: ldur            lr, [x24, #7]
    // 0x83416c: blr             lr
    // 0x834170: RestoreReg d0
    //     0x834170: ldr             q0, [SP], #0x10
    // 0x834174: b               #0x833f1c
    // 0x834178: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x834178: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83417c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83417c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x834180: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x834180: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x834184: stp             q1, q2, [SP, #-0x20]!
    // 0x834188: SaveReg r1
    //     0x834188: str             x1, [SP, #-8]!
    // 0x83418c: r0 = AllocateDouble()
    //     0x83418c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x834190: RestoreReg r1
    //     0x834190: ldr             x1, [SP], #8
    // 0x834194: ldp             q1, q2, [SP], #0x20
    // 0x834198: b               #0x834050
    // 0x83419c: SaveReg d1
    //     0x83419c: str             q1, [SP, #-0x10]!
    // 0x8341a0: stp             x0, x1, [SP, #-0x10]!
    // 0x8341a4: r0 = AllocateDouble()
    //     0x8341a4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x8341a8: mov             x2, x0
    // 0x8341ac: ldp             x0, x1, [SP], #0x10
    // 0x8341b0: RestoreReg d1
    //     0x8341b0: ldr             q1, [SP], #0x10
    // 0x8341b4: b               #0x834078
  }
  [closure] bool _handleGlowNotification(dynamic, OverscrollIndicatorNotification) {
    // ** addr: 0x83431c, size: 0x4c
    // 0x83431c: EnterFrame
    //     0x83431c: stp             fp, lr, [SP, #-0x10]!
    //     0x834320: mov             fp, SP
    // 0x834324: ldr             x0, [fp, #0x18]
    // 0x834328: LoadField: r1 = r0->field_17
    //     0x834328: ldur            w1, [x0, #0x17]
    // 0x83432c: DecompressPointer r1
    //     0x83432c: add             x1, x1, HEAP, lsl #32
    // 0x834330: CheckStackOverflow
    //     0x834330: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x834334: cmp             SP, x16
    //     0x834338: b.ls            #0x834360
    // 0x83433c: LoadField: r0 = r1->field_f
    //     0x83433c: ldur            w0, [x1, #0xf]
    // 0x834340: DecompressPointer r0
    //     0x834340: add             x0, x0, HEAP, lsl #32
    // 0x834344: ldr             x16, [fp, #0x10]
    // 0x834348: stp             x16, x0, [SP, #-0x10]!
    // 0x83434c: r0 = _handleGlowNotification()
    //     0x83434c: bl              #0x834368  ; [package:extended_tabs/src/tab_view.dart] ExtendedTabBarViewState::_handleGlowNotification
    // 0x834350: add             SP, SP, #0x10
    // 0x834354: LeaveFrame
    //     0x834354: mov             SP, fp
    //     0x834358: ldp             fp, lr, [SP], #0x10
    // 0x83435c: ret
    //     0x83435c: ret             
    // 0x834360: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x834360: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x834364: b               #0x83433c
  }
  _ _handleGlowNotification(/* No info */) {
    // ** addr: 0x834368, size: 0x88
    // 0x834368: EnterFrame
    //     0x834368: stp             fp, lr, [SP, #-0x10]!
    //     0x83436c: mov             fp, SP
    // 0x834370: CheckStackOverflow
    //     0x834370: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x834374: cmp             SP, x16
    //     0x834378: b.ls            #0x8343dc
    // 0x83437c: ldr             x0, [fp, #0x10]
    // 0x834380: LoadField: r1 = r0->field_7
    //     0x834380: ldur            x1, [x0, #7]
    // 0x834384: cbnz            x1, #0x8343cc
    // 0x834388: ldr             x1, [fp, #0x18]
    // 0x83438c: LoadField: r2 = r1->field_1f
    //     0x83438c: ldur            w2, [x1, #0x1f]
    // 0x834390: DecompressPointer r2
    //     0x834390: add             x2, x2, HEAP, lsl #32
    // 0x834394: r16 = Sentinel
    //     0x834394: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x834398: cmp             w2, w16
    // 0x83439c: b.eq            #0x8343e4
    // 0x8343a0: LoadField: r1 = r2->field_53
    //     0x8343a0: ldur            w1, [x2, #0x53]
    // 0x8343a4: DecompressPointer r1
    //     0x8343a4: add             x1, x1, HEAP, lsl #32
    // 0x8343a8: cmp             w1, NULL
    // 0x8343ac: b.eq            #0x8343cc
    // 0x8343b0: SaveReg r0
    //     0x8343b0: str             x0, [SP, #-8]!
    // 0x8343b4: r0 = _doRestore()
    //     0x8343b4: bl              #0x8343f0  ; [package:flutter/src/widgets/restoration.dart] __RestorationScopeState&State&RestorationMixin::_doRestore
    // 0x8343b8: add             SP, SP, #8
    // 0x8343bc: r0 = true
    //     0x8343bc: add             x0, NULL, #0x20  ; true
    // 0x8343c0: LeaveFrame
    //     0x8343c0: mov             SP, fp
    //     0x8343c4: ldp             fp, lr, [SP], #0x10
    // 0x8343c8: ret
    //     0x8343c8: ret             
    // 0x8343cc: r0 = false
    //     0x8343cc: add             x0, NULL, #0x30  ; false
    // 0x8343d0: LeaveFrame
    //     0x8343d0: mov             SP, fp
    //     0x8343d4: ldp             fp, lr, [SP], #0x10
    // 0x8343d8: ret
    //     0x8343d8: ret             
    // 0x8343dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8343dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8343e0: b               #0x83437c
    // 0x8343e4: r9 = _pageController
    //     0x8343e4: add             x9, PP, #0x2f, lsl #12  ; [pp+0x2f3d8] Field <ExtendedTabBarViewState._pageController@470121374>: late (offset: 0x20)
    //     0x8343e8: ldr             x9, [x9, #0x3d8]
    // 0x8343ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8343ec: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d68b4, size: 0x3c
    // 0x9d68b4: EnterFrame
    //     0x9d68b4: stp             fp, lr, [SP, #-0x10]!
    //     0x9d68b8: mov             fp, SP
    // 0x9d68bc: CheckStackOverflow
    //     0x9d68bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d68c0: cmp             SP, x16
    //     0x9d68c4: b.ls            #0x9d68e8
    // 0x9d68c8: ldr             x16, [fp, #0x10]
    // 0x9d68cc: SaveReg r16
    //     0x9d68cc: str             x16, [SP, #-8]!
    // 0x9d68d0: r0 = _updateChildren()
    //     0x9d68d0: bl              #0x7a11d0  ; [package:extended_tabs/src/tab_view.dart] ExtendedTabBarViewState::_updateChildren
    // 0x9d68d4: add             SP, SP, #8
    // 0x9d68d8: r0 = Null
    //     0x9d68d8: mov             x0, NULL
    // 0x9d68dc: LeaveFrame
    //     0x9d68dc: mov             SP, fp
    //     0x9d68e0: ldp             fp, lr, [SP], #0x10
    // 0x9d68e4: ret
    //     0x9d68e4: ret             
    // 0x9d68e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d68e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d68ec: b               #0x9d68c8
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a348, size: 0x18
    // 0xa4a348: r4 = 7
    //     0xa4a348: mov             x4, #7
    // 0xa4a34c: r1 = Function 'dispose':.
    //     0xa4a34c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4bf20] AnonymousClosure: (0xa4a360), in [package:extended_tabs/src/tab_view.dart] ExtendedTabBarViewState::dispose (0xa4f96c)
    //     0xa4a350: ldr             x1, [x17, #0xf20]
    // 0xa4a354: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a354: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a358: LoadField: r0 = r24->field_17
    //     0xa4a358: ldur            x0, [x24, #0x17]
    // 0xa4a35c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a360, size: 0x48
    // 0xa4a360: EnterFrame
    //     0xa4a360: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a364: mov             fp, SP
    // 0xa4a368: ldr             x0, [fp, #0x10]
    // 0xa4a36c: LoadField: r1 = r0->field_17
    //     0xa4a36c: ldur            w1, [x0, #0x17]
    // 0xa4a370: DecompressPointer r1
    //     0xa4a370: add             x1, x1, HEAP, lsl #32
    // 0xa4a374: CheckStackOverflow
    //     0xa4a374: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a378: cmp             SP, x16
    //     0xa4a37c: b.ls            #0xa4a3a0
    // 0xa4a380: LoadField: r0 = r1->field_f
    //     0xa4a380: ldur            w0, [x1, #0xf]
    // 0xa4a384: DecompressPointer r0
    //     0xa4a384: add             x0, x0, HEAP, lsl #32
    // 0xa4a388: SaveReg r0
    //     0xa4a388: str             x0, [SP, #-8]!
    // 0xa4a38c: r0 = dispose()
    //     0xa4a38c: bl              #0xa4f96c  ; [package:extended_tabs/src/tab_view.dart] ExtendedTabBarViewState::dispose
    // 0xa4a390: add             SP, SP, #8
    // 0xa4a394: LeaveFrame
    //     0xa4a394: mov             SP, fp
    //     0xa4a398: ldp             fp, lr, [SP], #0x10
    // 0xa4a39c: ret
    //     0xa4a39c: ret             
    // 0xa4a3a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a3a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a3a4: b               #0xa4a380
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4f96c, size: 0xc4
    // 0xa4f96c: EnterFrame
    //     0xa4f96c: stp             fp, lr, [SP, #-0x10]!
    //     0xa4f970: mov             fp, SP
    // 0xa4f974: AllocStack(0x8)
    //     0xa4f974: sub             SP, SP, #8
    // 0xa4f978: CheckStackOverflow
    //     0xa4f978: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4f97c: cmp             SP, x16
    //     0xa4f980: b.ls            #0xa4fa20
    // 0xa4f984: ldr             x16, [fp, #0x10]
    // 0xa4f988: SaveReg r16
    //     0xa4f988: str             x16, [SP, #-8]!
    // 0xa4f98c: r0 = _controllerIsValid()
    //     0xa4f98c: bl              #0x7a17e4  ; [package:extended_tabs/src/tab_view.dart] ExtendedTabBarViewState::_controllerIsValid
    // 0xa4f990: add             SP, SP, #8
    // 0xa4f994: tbnz            w0, #4, #0xa4fa08
    // 0xa4f998: ldr             x0, [fp, #0x10]
    // 0xa4f99c: LoadField: r1 = r0->field_1b
    //     0xa4f99c: ldur            w1, [x0, #0x1b]
    // 0xa4f9a0: DecompressPointer r1
    //     0xa4f9a0: add             x1, x1, HEAP, lsl #32
    // 0xa4f9a4: cmp             w1, NULL
    // 0xa4f9a8: b.eq            #0xa4fa28
    // 0xa4f9ac: LoadField: r2 = r1->field_23
    //     0xa4f9ac: ldur            w2, [x1, #0x23]
    // 0xa4f9b0: DecompressPointer r2
    //     0xa4f9b0: add             x2, x2, HEAP, lsl #32
    // 0xa4f9b4: cmp             w2, NULL
    // 0xa4f9b8: b.ne            #0xa4f9c4
    // 0xa4f9bc: r1 = Null
    //     0xa4f9bc: mov             x1, NULL
    // 0xa4f9c0: b               #0xa4f9c8
    // 0xa4f9c4: mov             x1, x2
    // 0xa4f9c8: stur            x1, [fp, #-8]
    // 0xa4f9cc: cmp             w1, NULL
    // 0xa4f9d0: b.eq            #0xa4fa2c
    // 0xa4f9d4: r1 = 1
    //     0xa4f9d4: mov             x1, #1
    // 0xa4f9d8: r0 = AllocateContext()
    //     0xa4f9d8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa4f9dc: mov             x1, x0
    // 0xa4f9e0: ldr             x0, [fp, #0x10]
    // 0xa4f9e4: StoreField: r1->field_f = r0
    //     0xa4f9e4: stur            w0, [x1, #0xf]
    // 0xa4f9e8: mov             x2, x1
    // 0xa4f9ec: r1 = Function '_handleTabControllerAnimationTick@470121374':.
    //     0xa4f9ec: add             x1, PP, #0x38, lsl #12  ; [pp+0x38198] AnonymousClosure: (0x7a1828), in [package:extended_tabs/src/tab_view.dart] ExtendedTabBarViewState::_handleTabControllerAnimationTick (0x7a1870)
    //     0xa4f9f0: ldr             x1, [x1, #0x198]
    // 0xa4f9f4: r0 = AllocateClosure()
    //     0xa4f9f4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa4f9f8: ldur            x16, [fp, #-8]
    // 0xa4f9fc: stp             x0, x16, [SP, #-0x10]!
    // 0xa4fa00: r0 = removeListener()
    //     0xa4fa00: bl              #0x6f5e30  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::removeListener
    // 0xa4fa04: add             SP, SP, #0x10
    // 0xa4fa08: ldr             x1, [fp, #0x10]
    // 0xa4fa0c: StoreField: r1->field_1b = rNULL
    //     0xa4fa0c: stur            NULL, [x1, #0x1b]
    // 0xa4fa10: r0 = Null
    //     0xa4fa10: mov             x0, NULL
    // 0xa4fa14: LeaveFrame
    //     0xa4fa14: mov             SP, fp
    //     0xa4fa18: ldp             fp, lr, [SP], #0x10
    // 0xa4fa1c: ret
    //     0xa4fa1c: ret             
    // 0xa4fa20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4fa20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4fa24: b               #0xa4f984
    // 0xa4fa28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa4fa28: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa4fa2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa4fa2c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xa60500, size: 0x114
    // 0xa60500: EnterFrame
    //     0xa60500: stp             fp, lr, [SP, #-0x10]!
    //     0xa60504: mov             fp, SP
    // 0xa60508: AllocStack(0x10)
    //     0xa60508: sub             SP, SP, #0x10
    // 0xa6050c: CheckStackOverflow
    //     0xa6050c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa60510: cmp             SP, x16
    //     0xa60514: b.ls            #0xa60604
    // 0xa60518: ldr             x16, [fp, #0x10]
    // 0xa6051c: SaveReg r16
    //     0xa6051c: str             x16, [SP, #-8]!
    // 0xa60520: r0 = _updateTabController()
    //     0xa60520: bl              #0x7a1668  ; [package:extended_tabs/src/tab_view.dart] ExtendedTabBarViewState::_updateTabController
    // 0xa60524: add             SP, SP, #8
    // 0xa60528: ldr             x2, [fp, #0x10]
    // 0xa6052c: LoadField: r0 = r2->field_1b
    //     0xa6052c: ldur            w0, [x2, #0x1b]
    // 0xa60530: DecompressPointer r0
    //     0xa60530: add             x0, x0, HEAP, lsl #32
    // 0xa60534: cmp             w0, NULL
    // 0xa60538: b.eq            #0xa6060c
    // 0xa6053c: LoadField: r3 = r0->field_33
    //     0xa6053c: ldur            x3, [x0, #0x33]
    // 0xa60540: stur            x3, [fp, #-8]
    // 0xa60544: r0 = BoxInt64Instr(r3)
    //     0xa60544: sbfiz           x0, x3, #1, #0x1f
    //     0xa60548: cmp             x3, x0, asr #1
    //     0xa6054c: b.eq            #0xa60558
    //     0xa60550: bl              #0xd69bb8
    //     0xa60554: stur            x3, [x0, #7]
    // 0xa60558: StoreField: r2->field_2b = r0
    //     0xa60558: stur            w0, [x2, #0x2b]
    //     0xa6055c: tbz             w0, #0, #0xa60578
    //     0xa60560: ldurb           w16, [x2, #-1]
    //     0xa60564: ldurb           w17, [x0, #-1]
    //     0xa60568: and             x16, x17, x16, lsr #2
    //     0xa6056c: tst             x16, HEAP, lsr #32
    //     0xa60570: b.eq            #0xa60578
    //     0xa60574: bl              #0xd6828c
    // 0xa60578: LoadField: r0 = r2->field_b
    //     0xa60578: ldur            w0, [x2, #0xb]
    // 0xa6057c: DecompressPointer r0
    //     0xa6057c: add             x0, x0, HEAP, lsl #32
    // 0xa60580: cmp             w0, NULL
    // 0xa60584: b.eq            #0xa60610
    // 0xa60588: r0 = LinkPageController()
    //     0xa60588: bl              #0x7a165c  ; AllocateLinkPageControllerStub -> LinkPageController (size=0x5c)
    // 0xa6058c: mov             x1, x0
    // 0xa60590: r0 = Sentinel
    //     0xa60590: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa60594: stur            x1, [fp, #-0x10]
    // 0xa60598: StoreField: r1->field_4b = r0
    //     0xa60598: stur            w0, [x1, #0x4b]
    // 0xa6059c: ldur            x0, [fp, #-8]
    // 0xa605a0: StoreField: r1->field_37 = r0
    //     0xa605a0: stur            x0, [x1, #0x37]
    // 0xa605a4: r0 = true
    //     0xa605a4: add             x0, NULL, #0x20  ; true
    // 0xa605a8: StoreField: r1->field_3f = r0
    //     0xa605a8: stur            w0, [x1, #0x3f]
    // 0xa605ac: d0 = 1.000000
    //     0xa605ac: fmov            d0, #1.00000000
    // 0xa605b0: StoreField: r1->field_43 = d0
    //     0xa605b0: stur            d0, [x1, #0x43]
    // 0xa605b4: SaveReg r1
    //     0xa605b4: str             x1, [SP, #-8]!
    // 0xa605b8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa605b8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa605bc: r0 = ScrollController()
    //     0xa605bc: bl              #0x51ee1c  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0xa605c0: add             SP, SP, #8
    // 0xa605c4: ldur            x0, [fp, #-0x10]
    // 0xa605c8: ldr             x1, [fp, #0x10]
    // 0xa605cc: StoreField: r1->field_1f = r0
    //     0xa605cc: stur            w0, [x1, #0x1f]
    //     0xa605d0: ldurb           w16, [x1, #-1]
    //     0xa605d4: ldurb           w17, [x0, #-1]
    //     0xa605d8: and             x16, x17, x16, lsr #2
    //     0xa605dc: tst             x16, HEAP, lsr #32
    //     0xa605e0: b.eq            #0xa605e8
    //     0xa605e4: bl              #0xd6826c
    // 0xa605e8: SaveReg r1
    //     0xa605e8: str             x1, [SP, #-8]!
    // 0xa605ec: r0 = didChangeDependencies()
    //     0xa605ec: bl              #0xa60614  ; [package:sync_scroll_library/src/link/link_scroll_state.dart] LinkScrollState::didChangeDependencies
    // 0xa605f0: add             SP, SP, #8
    // 0xa605f4: r0 = Null
    //     0xa605f4: mov             x0, NULL
    // 0xa605f8: LeaveFrame
    //     0xa605f8: mov             SP, fp
    //     0xa605fc: ldp             fp, lr, [SP], #0x10
    // 0xa60600: ret
    //     0xa60600: ret             
    // 0xa60604: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa60604: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa60608: b               #0xa60518
    // 0xa6060c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6060c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa60610: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa60610: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4190, size: 0x3c, field offset: 0xc
//   const constructor, 
class ExtendedTabBarView extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa3f804, size: 0x30
    // 0xa3f804: EnterFrame
    //     0xa3f804: stp             fp, lr, [SP, #-0x10]!
    //     0xa3f808: mov             fp, SP
    // 0xa3f80c: r1 = <ExtendedTabBarView>
    //     0xa3f80c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2ee40] TypeArguments: <ExtendedTabBarView>
    //     0xa3f810: ldr             x1, [x1, #0xe40]
    // 0xa3f814: r0 = ExtendedTabBarViewState()
    //     0xa3f814: bl              #0xa3f834  ; AllocateExtendedTabBarViewStateStub -> ExtendedTabBarViewState (size=0x38)
    // 0xa3f818: r1 = Sentinel
    //     0xa3f818: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa3f81c: StoreField: r0->field_1f = r1
    //     0xa3f81c: stur            w1, [x0, #0x1f]
    // 0xa3f820: r1 = 0
    //     0xa3f820: mov             x1, #0
    // 0xa3f824: StoreField: r0->field_2f = r1
    //     0xa3f824: stur            x1, [x0, #0x2f]
    // 0xa3f828: LeaveFrame
    //     0xa3f828: mov             SP, fp
    //     0xa3f82c: ldp             fp, lr, [SP], #0x10
    // 0xa3f830: ret
    //     0xa3f830: ret             
  }
}

// lib: , url: package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart

// class id: 1049001, size: 0x8
class :: {
}

// class id: 4415, size: 0x8, field offset: 0x8
abstract class FFmpegKitConfig extends Object {

  static late FFmpegKitPlatform _platform; // offset: 0xc50
  static late LogRedirectionStrategy _globalLogRedirectionStrategy; // offset: 0xc54
  static late int _activeLogLevel; // offset: 0xc58

  static _ ffmpegExecute(/* No info */) async {
    // ** addr: 0xa353d4, size: 0x13c
    // 0xa353d4: EnterFrame
    //     0xa353d4: stp             fp, lr, [SP, #-0x10]!
    //     0xa353d8: mov             fp, SP
    // 0xa353dc: AllocStack(0x50)
    //     0xa353dc: sub             SP, SP, #0x50
    // 0xa353e0: SetupParameters(dynamic _ /* r1, fp-0x48 */)
    //     0xa353e0: stur            NULL, [fp, #-8]
    //     0xa353e4: mov             x0, #0
    //     0xa353e8: add             x1, fp, w0, sxtw #2
    //     0xa353ec: ldr             x1, [x1, #0x10]
    //     0xa353f0: stur            x1, [fp, #-0x48]
    // 0xa353f4: CheckStackOverflow
    //     0xa353f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa353f8: cmp             SP, x16
    //     0xa353fc: b.ls            #0xa35508
    // 0xa35400: InitAsync() -> Future<void?>
    //     0xa35400: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xa35404: bl              #0x4b92e4
    // 0xa35408: ldur            x0, [fp, #-0x48]
    // 0xa3540c: r0 = init()
    //     0xa3540c: bl              #0xa355ac  ; [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::init
    // 0xa35410: mov             x1, x0
    // 0xa35414: stur            x1, [fp, #-0x50]
    // 0xa35418: r0 = Await()
    //     0xa35418: bl              #0x4b8e6c  ; AwaitStub
    // 0xa3541c: r0 = InitLateStaticField(0xc50) // [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::_platform
    //     0xa3541c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa35420: ldr             x0, [x0, #0x18a0]
    //     0xa35424: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa35428: cmp             w0, w16
    //     0xa3542c: b.ne            #0xa3543c
    //     0xa35430: add             x2, PP, #0x2f, lsl #12  ; [pp+0x2fd58] Field <FFmpegKitConfig._platform@517022016>: static late (offset: 0xc50)
    //     0xa35434: ldr             x2, [x2, #0xd58]
    //     0xa35438: bl              #0xd67d44
    // 0xa3543c: mov             x1, x0
    // 0xa35440: ldur            x0, [fp, #-0x48]
    // 0xa35444: LoadField: r2 = r0->field_7
    //     0xa35444: ldur            w2, [x0, #7]
    // 0xa35448: DecompressPointer r2
    //     0xa35448: add             x2, x2, HEAP, lsl #32
    // 0xa3544c: stp             x2, x1, [SP, #-0x10]!
    // 0xa35450: r0 = ffmpegKitConfigFFmpegExecute()
    //     0xa35450: bl              #0xa35510  ; [package:ffmpeg_kit_flutter_platform_interface/method_channel_ffmpeg_kit_flutter.dart] MethodChannelFFmpegKit::ffmpegKitConfigFFmpegExecute
    // 0xa35454: add             SP, SP, #0x10
    // 0xa35458: r0 = ReturnAsync()
    //     0xa35458: b               #0x501858  ; ReturnAsyncStub
    // 0xa3545c: sub             SP, fp, #0x50
    // 0xa35460: mov             x3, x0
    // 0xa35464: stur            x0, [fp, #-0x48]
    // 0xa35468: mov             x0, x1
    // 0xa3546c: stur            x1, [fp, #-0x50]
    // 0xa35470: r1 = LoadTaggedClassIdMayBeSmiInstr(r3)
    //     0xa35470: mov             x1, #0x76
    //     0xa35474: tbz             w3, #0, #0xa35484
    //     0xa35478: ldur            x1, [x3, #-1]
    //     0xa3547c: ubfx            x1, x1, #0xc, #0x14
    //     0xa35480: lsl             x1, x1, #1
    // 0xa35484: cmp             w1, #0xf28
    // 0xa35488: b.ne            #0xa354f4
    // 0xa3548c: r1 = Null
    //     0xa3548c: mov             x1, NULL
    // 0xa35490: r2 = 4
    //     0xa35490: mov             x2, #4
    // 0xa35494: r0 = AllocateArray()
    //     0xa35494: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa35498: r17 = "Plugin ffmpegExecute error: "
    //     0xa35498: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2ffb8] "Plugin ffmpegExecute error: "
    //     0xa3549c: ldr             x17, [x17, #0xfb8]
    // 0xa354a0: StoreField: r0->field_f = r17
    //     0xa354a0: stur            w17, [x0, #0xf]
    // 0xa354a4: ldur            x1, [fp, #-0x48]
    // 0xa354a8: LoadField: r2 = r1->field_b
    //     0xa354a8: ldur            w2, [x1, #0xb]
    // 0xa354ac: DecompressPointer r2
    //     0xa354ac: add             x2, x2, HEAP, lsl #32
    // 0xa354b0: StoreField: r0->field_13 = r2
    //     0xa354b0: stur            w2, [x0, #0x13]
    // 0xa354b4: SaveReg r0
    //     0xa354b4: str             x0, [SP, #-8]!
    // 0xa354b8: r0 = _interpolate()
    //     0xa354b8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa354bc: add             SP, SP, #8
    // 0xa354c0: SaveReg r0
    //     0xa354c0: str             x0, [SP, #-8]!
    // 0xa354c4: r0 = print()
    //     0xa354c4: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xa354c8: add             SP, SP, #8
    // 0xa354cc: r16 = <void?>
    //     0xa354cc: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xa354d0: r30 = "ffmpegExecute failed."
    //     0xa354d0: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2ffc0] "ffmpegExecute failed."
    //     0xa354d4: ldr             lr, [lr, #0xfc0]
    // 0xa354d8: stp             lr, x16, [SP, #-0x10]!
    // 0xa354dc: ldur            x16, [fp, #-0x50]
    // 0xa354e0: SaveReg r16
    //     0xa354e0: str             x16, [SP, #-8]!
    // 0xa354e4: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa354e4: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa354e8: r0 = Future.error()
    //     0xa354e8: bl              #0x4e95bc  ; [dart:async] Future::Future.error
    // 0xa354ec: add             SP, SP, #0x18
    // 0xa354f0: r0 = ReturnAsync()
    //     0xa354f0: b               #0x501858  ; ReturnAsyncStub
    // 0xa354f4: mov             x1, x3
    // 0xa354f8: mov             x0, x1
    // 0xa354fc: ldur            x1, [fp, #-0x50]
    // 0xa35500: r0 = ReThrow()
    //     0xa35500: bl              #0xd67e14  ; ReThrowStub
    // 0xa35504: brk             #0
    // 0xa35508: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa35508: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa3550c: b               #0xa35400
  }
  static _ init(/* No info */) async {
    // ** addr: 0xa355ac, size: 0x44
    // 0xa355ac: EnterFrame
    //     0xa355ac: stp             fp, lr, [SP, #-0x10]!
    //     0xa355b0: mov             fp, SP
    // 0xa355b4: AllocStack(0x10)
    //     0xa355b4: sub             SP, SP, #0x10
    // 0xa355b8: SetupParameters()
    //     0xa355b8: stur            NULL, [fp, #-8]
    // 0xa355bc: CheckStackOverflow
    //     0xa355bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa355c0: cmp             SP, x16
    //     0xa355c4: b.ls            #0xa355e8
    // 0xa355c8: InitAsync() -> Future<void?>
    //     0xa355c8: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xa355cc: bl              #0x4b92e4
    // 0xa355d0: r0 = initialize()
    //     0xa355d0: bl              #0xa355f0  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_flutter_initializer.dart] FFmpegKitInitializer::initialize
    // 0xa355d4: mov             x1, x0
    // 0xa355d8: stur            x1, [fp, #-0x10]
    // 0xa355dc: r0 = Await()
    //     0xa355dc: bl              #0x4b8e6c  ; AwaitStub
    // 0xa355e0: r0 = Null
    //     0xa355e0: mov             x0, NULL
    // 0xa355e4: r0 = ReturnAsyncNotFuture()
    //     0xa355e4: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xa355e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa355e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa355ec: b               #0xa355c8
  }
  static _ isLTSBuild(/* No info */) async {
    // ** addr: 0xa358d4, size: 0x148
    // 0xa358d4: EnterFrame
    //     0xa358d4: stp             fp, lr, [SP, #-0x10]!
    //     0xa358d8: mov             fp, SP
    // 0xa358dc: AllocStack(0x48)
    //     0xa358dc: sub             SP, SP, #0x48
    // 0xa358e0: SetupParameters()
    //     0xa358e0: stur            NULL, [fp, #-8]
    // 0xa358e4: CheckStackOverflow
    //     0xa358e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa358e8: cmp             SP, x16
    //     0xa358ec: b.ls            #0xa35a14
    // 0xa358f0: InitAsync() -> Future<bool>
    //     0xa358f0: ldr             x0, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    //     0xa358f4: bl              #0x4b92e4
    // 0xa358f8: r0 = init()
    //     0xa358f8: bl              #0xa355ac  ; [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::init
    // 0xa358fc: mov             x1, x0
    // 0xa35900: stur            x1, [fp, #-0x40]
    // 0xa35904: r0 = Await()
    //     0xa35904: bl              #0x4b8e6c  ; AwaitStub
    // 0xa35908: r0 = InitLateStaticField(0xc50) // [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::_platform
    //     0xa35908: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa3590c: ldr             x0, [x0, #0x18a0]
    //     0xa35910: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa35914: cmp             w0, w16
    //     0xa35918: b.ne            #0xa35928
    //     0xa3591c: add             x2, PP, #0x2f, lsl #12  ; [pp+0x2fd58] Field <FFmpegKitConfig._platform@517022016>: static late (offset: 0xc50)
    //     0xa35920: ldr             x2, [x2, #0xd58]
    //     0xa35924: bl              #0xd67d44
    // 0xa35928: SaveReg r0
    //     0xa35928: str             x0, [SP, #-8]!
    // 0xa3592c: r0 = ffmpegKitConfigIsLTSBuild()
    //     0xa3592c: bl              #0xa35a1c  ; [package:ffmpeg_kit_flutter_platform_interface/method_channel_ffmpeg_kit_flutter.dart] MethodChannelFFmpegKit::ffmpegKitConfigIsLTSBuild
    // 0xa35930: add             SP, SP, #8
    // 0xa35934: r1 = Function '<anonymous closure>': static.
    //     0xa35934: add             x1, PP, #0x2f, lsl #12  ; [pp+0x2fd60] AnonymousClosure: static (0xa35a78), in [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::isLTSBuild (0xa358d4)
    //     0xa35938: ldr             x1, [x1, #0xd60]
    // 0xa3593c: r2 = Null
    //     0xa3593c: mov             x2, NULL
    // 0xa35940: stur            x0, [fp, #-0x40]
    // 0xa35944: r0 = AllocateClosure()
    //     0xa35944: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa35948: r16 = <bool>
    //     0xa35948: ldr             x16, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0xa3594c: ldur            lr, [fp, #-0x40]
    // 0xa35950: stp             lr, x16, [SP, #-0x10]!
    // 0xa35954: SaveReg r0
    //     0xa35954: str             x0, [SP, #-8]!
    // 0xa35958: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa35958: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa3595c: r0 = then()
    //     0xa3595c: bl              #0xca6124  ; [dart:async] _Future::then
    // 0xa35960: add             SP, SP, #0x18
    // 0xa35964: r0 = ReturnAsync()
    //     0xa35964: b               #0x501858  ; ReturnAsyncStub
    // 0xa35968: sub             SP, fp, #0x48
    // 0xa3596c: mov             x3, x0
    // 0xa35970: stur            x0, [fp, #-0x40]
    // 0xa35974: mov             x0, x1
    // 0xa35978: stur            x1, [fp, #-0x48]
    // 0xa3597c: r1 = LoadTaggedClassIdMayBeSmiInstr(r3)
    //     0xa3597c: mov             x1, #0x76
    //     0xa35980: tbz             w3, #0, #0xa35990
    //     0xa35984: ldur            x1, [x3, #-1]
    //     0xa35988: ubfx            x1, x1, #0xc, #0x14
    //     0xa3598c: lsl             x1, x1, #1
    // 0xa35990: cmp             w1, #0xf28
    // 0xa35994: b.ne            #0xa35a00
    // 0xa35998: r1 = Null
    //     0xa35998: mov             x1, NULL
    // 0xa3599c: r2 = 4
    //     0xa3599c: mov             x2, #4
    // 0xa359a0: r0 = AllocateArray()
    //     0xa359a0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa359a4: r17 = "Plugin isLTSBuild error: "
    //     0xa359a4: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2fd68] "Plugin isLTSBuild error: "
    //     0xa359a8: ldr             x17, [x17, #0xd68]
    // 0xa359ac: StoreField: r0->field_f = r17
    //     0xa359ac: stur            w17, [x0, #0xf]
    // 0xa359b0: ldur            x1, [fp, #-0x40]
    // 0xa359b4: LoadField: r2 = r1->field_b
    //     0xa359b4: ldur            w2, [x1, #0xb]
    // 0xa359b8: DecompressPointer r2
    //     0xa359b8: add             x2, x2, HEAP, lsl #32
    // 0xa359bc: StoreField: r0->field_13 = r2
    //     0xa359bc: stur            w2, [x0, #0x13]
    // 0xa359c0: SaveReg r0
    //     0xa359c0: str             x0, [SP, #-8]!
    // 0xa359c4: r0 = _interpolate()
    //     0xa359c4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa359c8: add             SP, SP, #8
    // 0xa359cc: SaveReg r0
    //     0xa359cc: str             x0, [SP, #-8]!
    // 0xa359d0: r0 = print()
    //     0xa359d0: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xa359d4: add             SP, SP, #8
    // 0xa359d8: r16 = <bool>
    //     0xa359d8: ldr             x16, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0xa359dc: r30 = "isLTSBuild failed."
    //     0xa359dc: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2fd70] "isLTSBuild failed."
    //     0xa359e0: ldr             lr, [lr, #0xd70]
    // 0xa359e4: stp             lr, x16, [SP, #-0x10]!
    // 0xa359e8: ldur            x16, [fp, #-0x48]
    // 0xa359ec: SaveReg r16
    //     0xa359ec: str             x16, [SP, #-8]!
    // 0xa359f0: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa359f0: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa359f4: r0 = Future.error()
    //     0xa359f4: bl              #0x4e95bc  ; [dart:async] Future::Future.error
    // 0xa359f8: add             SP, SP, #0x18
    // 0xa359fc: r0 = ReturnAsync()
    //     0xa359fc: b               #0x501858  ; ReturnAsyncStub
    // 0xa35a00: mov             x1, x3
    // 0xa35a04: mov             x0, x1
    // 0xa35a08: ldur            x1, [fp, #-0x48]
    // 0xa35a0c: r0 = ReThrow()
    //     0xa35a0c: bl              #0xd67e14  ; ReThrowStub
    // 0xa35a10: brk             #0
    // 0xa35a14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa35a14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa35a18: b               #0xa358f0
  }
  [closure] static bool <anonymous closure>(dynamic, bool?) {
    // ** addr: 0xa35a78, size: 0x18
    // 0xa35a78: ldr             x0, [SP]
    // 0xa35a7c: cmp             w0, NULL
    // 0xa35a80: b.ne            #0xa35a8c
    // 0xa35a84: r0 = false
    //     0xa35a84: add             x0, NULL, #0x30  ; false
    // 0xa35a88: ret
    //     0xa35a88: ret             
    // 0xa35a8c: ret
    //     0xa35a8c: ret             
  }
  static _ enableRedirection(/* No info */) async {
    // ** addr: 0xa35a90, size: 0x118
    // 0xa35a90: EnterFrame
    //     0xa35a90: stp             fp, lr, [SP, #-0x10]!
    //     0xa35a94: mov             fp, SP
    // 0xa35a98: AllocStack(0x48)
    //     0xa35a98: sub             SP, SP, #0x48
    // 0xa35a9c: SetupParameters()
    //     0xa35a9c: stur            NULL, [fp, #-8]
    // 0xa35aa0: CheckStackOverflow
    //     0xa35aa0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa35aa4: cmp             SP, x16
    //     0xa35aa8: b.ls            #0xa35ba0
    // 0xa35aac: InitAsync() -> Future<void?>
    //     0xa35aac: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xa35ab0: bl              #0x4b92e4
    // 0xa35ab4: r0 = init()
    //     0xa35ab4: bl              #0xa355ac  ; [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::init
    // 0xa35ab8: mov             x1, x0
    // 0xa35abc: stur            x1, [fp, #-0x40]
    // 0xa35ac0: r0 = Await()
    //     0xa35ac0: bl              #0x4b8e6c  ; AwaitStub
    // 0xa35ac4: r0 = InitLateStaticField(0xc50) // [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::_platform
    //     0xa35ac4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa35ac8: ldr             x0, [x0, #0x18a0]
    //     0xa35acc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa35ad0: cmp             w0, w16
    //     0xa35ad4: b.ne            #0xa35ae4
    //     0xa35ad8: add             x2, PP, #0x2f, lsl #12  ; [pp+0x2fd58] Field <FFmpegKitConfig._platform@517022016>: static late (offset: 0xc50)
    //     0xa35adc: ldr             x2, [x2, #0xd58]
    //     0xa35ae0: bl              #0xd67d44
    // 0xa35ae4: SaveReg r0
    //     0xa35ae4: str             x0, [SP, #-8]!
    // 0xa35ae8: r0 = ffmpegKitConfigEnableRedirection()
    //     0xa35ae8: bl              #0xa35ba8  ; [package:ffmpeg_kit_flutter_platform_interface/method_channel_ffmpeg_kit_flutter.dart] MethodChannelFFmpegKit::ffmpegKitConfigEnableRedirection
    // 0xa35aec: add             SP, SP, #8
    // 0xa35af0: r0 = ReturnAsync()
    //     0xa35af0: b               #0x501858  ; ReturnAsyncStub
    // 0xa35af4: sub             SP, fp, #0x48
    // 0xa35af8: mov             x3, x0
    // 0xa35afc: stur            x0, [fp, #-0x40]
    // 0xa35b00: mov             x0, x1
    // 0xa35b04: stur            x1, [fp, #-0x48]
    // 0xa35b08: r1 = LoadTaggedClassIdMayBeSmiInstr(r3)
    //     0xa35b08: mov             x1, #0x76
    //     0xa35b0c: tbz             w3, #0, #0xa35b1c
    //     0xa35b10: ldur            x1, [x3, #-1]
    //     0xa35b14: ubfx            x1, x1, #0xc, #0x14
    //     0xa35b18: lsl             x1, x1, #1
    // 0xa35b1c: cmp             w1, #0xf28
    // 0xa35b20: b.ne            #0xa35b8c
    // 0xa35b24: r1 = Null
    //     0xa35b24: mov             x1, NULL
    // 0xa35b28: r2 = 4
    //     0xa35b28: mov             x2, #4
    // 0xa35b2c: r0 = AllocateArray()
    //     0xa35b2c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa35b30: r17 = "Plugin enableRedirection error: "
    //     0xa35b30: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2fd90] "Plugin enableRedirection error: "
    //     0xa35b34: ldr             x17, [x17, #0xd90]
    // 0xa35b38: StoreField: r0->field_f = r17
    //     0xa35b38: stur            w17, [x0, #0xf]
    // 0xa35b3c: ldur            x1, [fp, #-0x40]
    // 0xa35b40: LoadField: r2 = r1->field_b
    //     0xa35b40: ldur            w2, [x1, #0xb]
    // 0xa35b44: DecompressPointer r2
    //     0xa35b44: add             x2, x2, HEAP, lsl #32
    // 0xa35b48: StoreField: r0->field_13 = r2
    //     0xa35b48: stur            w2, [x0, #0x13]
    // 0xa35b4c: SaveReg r0
    //     0xa35b4c: str             x0, [SP, #-8]!
    // 0xa35b50: r0 = _interpolate()
    //     0xa35b50: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa35b54: add             SP, SP, #8
    // 0xa35b58: SaveReg r0
    //     0xa35b58: str             x0, [SP, #-8]!
    // 0xa35b5c: r0 = print()
    //     0xa35b5c: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xa35b60: add             SP, SP, #8
    // 0xa35b64: r16 = <void?>
    //     0xa35b64: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xa35b68: r30 = "enableRedirection failed."
    //     0xa35b68: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2fd98] "enableRedirection failed."
    //     0xa35b6c: ldr             lr, [lr, #0xd98]
    // 0xa35b70: stp             lr, x16, [SP, #-0x10]!
    // 0xa35b74: ldur            x16, [fp, #-0x48]
    // 0xa35b78: SaveReg r16
    //     0xa35b78: str             x16, [SP, #-8]!
    // 0xa35b7c: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa35b7c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa35b80: r0 = Future.error()
    //     0xa35b80: bl              #0x4e95bc  ; [dart:async] Future::Future.error
    // 0xa35b84: add             SP, SP, #0x18
    // 0xa35b88: r0 = ReturnAsync()
    //     0xa35b88: b               #0x501858  ; ReturnAsyncStub
    // 0xa35b8c: mov             x1, x3
    // 0xa35b90: mov             x0, x1
    // 0xa35b94: ldur            x1, [fp, #-0x48]
    // 0xa35b98: r0 = ReThrow()
    //     0xa35b98: bl              #0xd67e14  ; ReThrowStub
    // 0xa35b9c: brk             #0
    // 0xa35ba0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa35ba0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa35ba4: b               #0xa35aac
  }
  static _ getPlatform(/* No info */) async {
    // ** addr: 0xa36014, size: 0x118
    // 0xa36014: EnterFrame
    //     0xa36014: stp             fp, lr, [SP, #-0x10]!
    //     0xa36018: mov             fp, SP
    // 0xa3601c: AllocStack(0x48)
    //     0xa3601c: sub             SP, SP, #0x48
    // 0xa36020: SetupParameters()
    //     0xa36020: stur            NULL, [fp, #-8]
    // 0xa36024: CheckStackOverflow
    //     0xa36024: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa36028: cmp             SP, x16
    //     0xa3602c: b.ls            #0xa36124
    // 0xa36030: InitAsync() -> Future<String?>
    //     0xa36030: ldr             x0, [PP, #0x1020]  ; [pp+0x1020] TypeArguments: <String?>
    //     0xa36034: bl              #0x4b92e4
    // 0xa36038: r0 = init()
    //     0xa36038: bl              #0xa355ac  ; [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::init
    // 0xa3603c: mov             x1, x0
    // 0xa36040: stur            x1, [fp, #-0x40]
    // 0xa36044: r0 = Await()
    //     0xa36044: bl              #0x4b8e6c  ; AwaitStub
    // 0xa36048: r0 = InitLateStaticField(0xc50) // [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::_platform
    //     0xa36048: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa3604c: ldr             x0, [x0, #0x18a0]
    //     0xa36050: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa36054: cmp             w0, w16
    //     0xa36058: b.ne            #0xa36068
    //     0xa3605c: add             x2, PP, #0x2f, lsl #12  ; [pp+0x2fd58] Field <FFmpegKitConfig._platform@517022016>: static late (offset: 0xc50)
    //     0xa36060: ldr             x2, [x2, #0xd58]
    //     0xa36064: bl              #0xd67d44
    // 0xa36068: SaveReg r0
    //     0xa36068: str             x0, [SP, #-8]!
    // 0xa3606c: r0 = ffmpegKitConfigGetPlatform()
    //     0xa3606c: bl              #0xa3612c  ; [package:ffmpeg_kit_flutter_platform_interface/method_channel_ffmpeg_kit_flutter.dart] MethodChannelFFmpegKit::ffmpegKitConfigGetPlatform
    // 0xa36070: add             SP, SP, #8
    // 0xa36074: r0 = ReturnAsync()
    //     0xa36074: b               #0x501858  ; ReturnAsyncStub
    // 0xa36078: sub             SP, fp, #0x48
    // 0xa3607c: mov             x3, x0
    // 0xa36080: stur            x0, [fp, #-0x40]
    // 0xa36084: mov             x0, x1
    // 0xa36088: stur            x1, [fp, #-0x48]
    // 0xa3608c: r1 = LoadTaggedClassIdMayBeSmiInstr(r3)
    //     0xa3608c: mov             x1, #0x76
    //     0xa36090: tbz             w3, #0, #0xa360a0
    //     0xa36094: ldur            x1, [x3, #-1]
    //     0xa36098: ubfx            x1, x1, #0xc, #0x14
    //     0xa3609c: lsl             x1, x1, #1
    // 0xa360a0: cmp             w1, #0xf28
    // 0xa360a4: b.ne            #0xa36110
    // 0xa360a8: r1 = Null
    //     0xa360a8: mov             x1, NULL
    // 0xa360ac: r2 = 4
    //     0xa360ac: mov             x2, #4
    // 0xa360b0: r0 = AllocateArray()
    //     0xa360b0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa360b4: r17 = "Plugin getPlatform error: "
    //     0xa360b4: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2fdf0] "Plugin getPlatform error: "
    //     0xa360b8: ldr             x17, [x17, #0xdf0]
    // 0xa360bc: StoreField: r0->field_f = r17
    //     0xa360bc: stur            w17, [x0, #0xf]
    // 0xa360c0: ldur            x1, [fp, #-0x40]
    // 0xa360c4: LoadField: r2 = r1->field_b
    //     0xa360c4: ldur            w2, [x1, #0xb]
    // 0xa360c8: DecompressPointer r2
    //     0xa360c8: add             x2, x2, HEAP, lsl #32
    // 0xa360cc: StoreField: r0->field_13 = r2
    //     0xa360cc: stur            w2, [x0, #0x13]
    // 0xa360d0: SaveReg r0
    //     0xa360d0: str             x0, [SP, #-8]!
    // 0xa360d4: r0 = _interpolate()
    //     0xa360d4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa360d8: add             SP, SP, #8
    // 0xa360dc: SaveReg r0
    //     0xa360dc: str             x0, [SP, #-8]!
    // 0xa360e0: r0 = print()
    //     0xa360e0: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xa360e4: add             SP, SP, #8
    // 0xa360e8: r16 = <String?>
    //     0xa360e8: ldr             x16, [PP, #0x1020]  ; [pp+0x1020] TypeArguments: <String?>
    // 0xa360ec: r30 = "getPlatform failed."
    //     0xa360ec: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2fdf8] "getPlatform failed."
    //     0xa360f0: ldr             lr, [lr, #0xdf8]
    // 0xa360f4: stp             lr, x16, [SP, #-0x10]!
    // 0xa360f8: ldur            x16, [fp, #-0x48]
    // 0xa360fc: SaveReg r16
    //     0xa360fc: str             x16, [SP, #-8]!
    // 0xa36100: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa36100: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa36104: r0 = Future.error()
    //     0xa36104: bl              #0x4e95bc  ; [dart:async] Future::Future.error
    // 0xa36108: add             SP, SP, #0x18
    // 0xa3610c: r0 = ReturnAsync()
    //     0xa3610c: b               #0x501858  ; ReturnAsyncStub
    // 0xa36110: mov             x1, x3
    // 0xa36114: mov             x0, x1
    // 0xa36118: ldur            x1, [fp, #-0x48]
    // 0xa3611c: r0 = ReThrow()
    //     0xa3611c: bl              #0xd67e14  ; ReThrowStub
    // 0xa36120: brk             #0
    // 0xa36124: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa36124: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa36128: b               #0xa36030
  }
  static _ setLogLevel(/* No info */) async {
    // ** addr: 0xa36184, size: 0x150
    // 0xa36184: EnterFrame
    //     0xa36184: stp             fp, lr, [SP, #-0x10]!
    //     0xa36188: mov             fp, SP
    // 0xa3618c: AllocStack(0x58)
    //     0xa3618c: sub             SP, SP, #0x58
    // 0xa36190: SetupParameters(dynamic _ /* r1, fp-0x48 */)
    //     0xa36190: stur            NULL, [fp, #-8]
    //     0xa36194: mov             x0, #0
    //     0xa36198: add             x1, fp, w0, sxtw #2
    //     0xa3619c: ldr             x1, [x1, #0x10]
    //     0xa361a0: stur            x1, [fp, #-0x48]
    // 0xa361a4: CheckStackOverflow
    //     0xa361a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa361a8: cmp             SP, x16
    //     0xa361ac: b.ls            #0xa362cc
    // 0xa361b0: InitAsync() -> Future<void?>
    //     0xa361b0: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xa361b4: bl              #0x4b92e4
    // 0xa361b8: ldur            x2, [fp, #-0x48]
    // 0xa361bc: r0 = BoxInt64Instr(r2)
    //     0xa361bc: sbfiz           x0, x2, #1, #0x1f
    //     0xa361c0: cmp             x2, x0, asr #1
    //     0xa361c4: b.eq            #0xa361d0
    //     0xa361c8: bl              #0xd69bb8
    //     0xa361cc: stur            x2, [x0, #7]
    // 0xa361d0: StoreStaticField(0xc58, r0)
    //     0xa361d0: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0xa361d4: str             x0, [x1, #0x18b0]
    // 0xa361d8: r0 = init()
    //     0xa361d8: bl              #0xa355ac  ; [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::init
    // 0xa361dc: mov             x1, x0
    // 0xa361e0: stur            x1, [fp, #-0x50]
    // 0xa361e4: r0 = Await()
    //     0xa361e4: bl              #0x4b8e6c  ; AwaitStub
    // 0xa361e8: r0 = InitLateStaticField(0xc50) // [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::_platform
    //     0xa361e8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa361ec: ldr             x0, [x0, #0x18a0]
    //     0xa361f0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa361f4: cmp             w0, w16
    //     0xa361f8: b.ne            #0xa36208
    //     0xa361fc: add             x2, PP, #0x2f, lsl #12  ; [pp+0x2fd58] Field <FFmpegKitConfig._platform@517022016>: static late (offset: 0xc50)
    //     0xa36200: ldr             x2, [x2, #0xd58]
    //     0xa36204: bl              #0xd67d44
    // 0xa36208: SaveReg r0
    //     0xa36208: str             x0, [SP, #-8]!
    // 0xa3620c: ldur            x0, [fp, #-0x48]
    // 0xa36210: SaveReg r0
    //     0xa36210: str             x0, [SP, #-8]!
    // 0xa36214: r0 = ffmpegKitConfigSetLogLevel()
    //     0xa36214: bl              #0xa362d4  ; [package:ffmpeg_kit_flutter_platform_interface/method_channel_ffmpeg_kit_flutter.dart] MethodChannelFFmpegKit::ffmpegKitConfigSetLogLevel
    // 0xa36218: add             SP, SP, #0x10
    // 0xa3621c: r0 = ReturnAsync()
    //     0xa3621c: b               #0x501858  ; ReturnAsyncStub
    // 0xa36220: sub             SP, fp, #0x58
    // 0xa36224: mov             x3, x0
    // 0xa36228: stur            x0, [fp, #-0x50]
    // 0xa3622c: mov             x0, x1
    // 0xa36230: stur            x1, [fp, #-0x58]
    // 0xa36234: r1 = LoadTaggedClassIdMayBeSmiInstr(r3)
    //     0xa36234: mov             x1, #0x76
    //     0xa36238: tbz             w3, #0, #0xa36248
    //     0xa3623c: ldur            x1, [x3, #-1]
    //     0xa36240: ubfx            x1, x1, #0xc, #0x14
    //     0xa36244: lsl             x1, x1, #1
    // 0xa36248: cmp             w1, #0xf28
    // 0xa3624c: b.ne            #0xa362b8
    // 0xa36250: r1 = Null
    //     0xa36250: mov             x1, NULL
    // 0xa36254: r2 = 4
    //     0xa36254: mov             x2, #4
    // 0xa36258: r0 = AllocateArray()
    //     0xa36258: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa3625c: r17 = "Plugin setLogLevel error: "
    //     0xa3625c: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2fe08] "Plugin setLogLevel error: "
    //     0xa36260: ldr             x17, [x17, #0xe08]
    // 0xa36264: StoreField: r0->field_f = r17
    //     0xa36264: stur            w17, [x0, #0xf]
    // 0xa36268: ldur            x1, [fp, #-0x50]
    // 0xa3626c: LoadField: r2 = r1->field_b
    //     0xa3626c: ldur            w2, [x1, #0xb]
    // 0xa36270: DecompressPointer r2
    //     0xa36270: add             x2, x2, HEAP, lsl #32
    // 0xa36274: StoreField: r0->field_13 = r2
    //     0xa36274: stur            w2, [x0, #0x13]
    // 0xa36278: SaveReg r0
    //     0xa36278: str             x0, [SP, #-8]!
    // 0xa3627c: r0 = _interpolate()
    //     0xa3627c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa36280: add             SP, SP, #8
    // 0xa36284: SaveReg r0
    //     0xa36284: str             x0, [SP, #-8]!
    // 0xa36288: r0 = print()
    //     0xa36288: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xa3628c: add             SP, SP, #8
    // 0xa36290: r16 = <void?>
    //     0xa36290: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xa36294: r30 = "setLogLevel failed."
    //     0xa36294: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2fe10] "setLogLevel failed."
    //     0xa36298: ldr             lr, [lr, #0xe10]
    // 0xa3629c: stp             lr, x16, [SP, #-0x10]!
    // 0xa362a0: ldur            x16, [fp, #-0x58]
    // 0xa362a4: SaveReg r16
    //     0xa362a4: str             x16, [SP, #-8]!
    // 0xa362a8: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa362a8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa362ac: r0 = Future.error()
    //     0xa362ac: bl              #0x4e95bc  ; [dart:async] Future::Future.error
    // 0xa362b0: add             SP, SP, #0x18
    // 0xa362b4: r0 = ReturnAsync()
    //     0xa362b4: b               #0x501858  ; ReturnAsyncStub
    // 0xa362b8: mov             x1, x3
    // 0xa362bc: mov             x0, x1
    // 0xa362c0: ldur            x1, [fp, #-0x58]
    // 0xa362c4: r0 = ReThrow()
    //     0xa362c4: bl              #0xd67e14  ; ReThrowStub
    // 0xa362c8: brk             #0
    // 0xa362cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa362cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa362d0: b               #0xa361b0
  }
  static LogRedirectionStrategy _globalLogRedirectionStrategy() {
    // ** addr: 0xa36a9c, size: 0xc
    // 0xa36a9c: r0 = Instance_LogRedirectionStrategy
    //     0xa36a9c: add             x0, PP, #0x30, lsl #12  ; [pp+0x30048] Obj!LogRedirectionStrategy@b65f91
    //     0xa36aa0: ldr             x0, [x0, #0x48]
    // 0xa36aa4: ret
    //     0xa36aa4: ret             
  }
  static _ parseArguments(/* No info */) {
    // ** addr: 0xa36acc, size: 0x558
    // 0xa36acc: EnterFrame
    //     0xa36acc: stp             fp, lr, [SP, #-0x10]!
    //     0xa36ad0: mov             fp, SP
    // 0xa36ad4: AllocStack(0x48)
    //     0xa36ad4: sub             SP, SP, #0x48
    // 0xa36ad8: CheckStackOverflow
    //     0xa36ad8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa36adc: cmp             SP, x16
    //     0xa36ae0: b.ls            #0xa3700c
    // 0xa36ae4: r0 = InitLateStaticField(0x0) // [dart:core] _GrowableList<X0>::_emptyList
    //     0xa36ae4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa36ae8: ldr             x0, [x0]
    //     0xa36aec: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa36af0: cmp             w0, w16
    //     0xa36af4: b.ne            #0xa36b00
    //     0xa36af8: ldr             x2, [PP, #0x7c8]  ; [pp+0x7c8] Field <_GrowableList@0150898._emptyList@0150898>: static late final (offset: 0x0)
    //     0xa36afc: bl              #0xd67cdc
    // 0xa36b00: r1 = <String>
    //     0xa36b00: ldr             x1, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xa36b04: stur            x0, [fp, #-8]
    // 0xa36b08: r0 = AllocateGrowableArray()
    //     0xa36b08: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xa36b0c: mov             x1, x0
    // 0xa36b10: ldur            x0, [fp, #-8]
    // 0xa36b14: stur            x1, [fp, #-0x10]
    // 0xa36b18: StoreField: r1->field_f = r0
    //     0xa36b18: stur            w0, [x1, #0xf]
    // 0xa36b1c: StoreField: r1->field_b = rZR
    //     0xa36b1c: stur            wzr, [x1, #0xb]
    // 0xa36b20: r0 = StringBuffer()
    //     0xa36b20: bl              #0x4d1e30  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0xa36b24: stur            x0, [fp, #-8]
    // 0xa36b28: SaveReg r0
    //     0xa36b28: str             x0, [SP, #-8]!
    // 0xa36b2c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa36b2c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa36b30: r0 = StringBuffer()
    //     0xa36b30: bl              #0x4d16e0  ; [dart:core] StringBuffer::StringBuffer
    // 0xa36b34: add             SP, SP, #8
    // 0xa36b38: ldr             x2, [fp, #0x10]
    // 0xa36b3c: LoadField: r0 = r2->field_7
    //     0xa36b3c: ldur            w0, [x2, #7]
    // 0xa36b40: DecompressPointer r0
    //     0xa36b40: add             x0, x0, HEAP, lsl #32
    // 0xa36b44: r3 = LoadInt32Instr(r0)
    //     0xa36b44: sbfx            x3, x0, #1, #0x1f
    // 0xa36b48: stur            x3, [fp, #-0x30]
    // 0xa36b4c: ldur            x8, [fp, #-8]
    // 0xa36b50: r7 = false
    //     0xa36b50: add             x7, NULL, #0x30  ; false
    // 0xa36b54: r6 = false
    //     0xa36b54: add             x6, NULL, #0x30  ; false
    // 0xa36b58: r5 = 0
    //     0xa36b58: mov             x5, #0
    // 0xa36b5c: ldur            x4, [fp, #-0x10]
    // 0xa36b60: stur            x8, [fp, #-8]
    // 0xa36b64: stur            x7, [fp, #-0x18]
    // 0xa36b68: stur            x6, [fp, #-0x20]
    // 0xa36b6c: stur            x5, [fp, #-0x28]
    // 0xa36b70: CheckStackOverflow
    //     0xa36b70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa36b74: cmp             SP, x16
    //     0xa36b78: b.ls            #0xa37014
    // 0xa36b7c: cmp             x5, x3
    // 0xa36b80: b.ge            #0xa36f38
    // 0xa36b84: cmp             x5, #0
    // 0xa36b88: b.le            #0xa36bcc
    // 0xa36b8c: sub             x9, x5, #1
    // 0xa36b90: r0 = BoxInt64Instr(r9)
    //     0xa36b90: sbfiz           x0, x9, #1, #0x1f
    //     0xa36b94: cmp             x9, x0, asr #1
    //     0xa36b98: b.eq            #0xa36ba4
    //     0xa36b9c: bl              #0xd69bb8
    //     0xa36ba0: stur            x9, [x0, #7]
    // 0xa36ba4: r1 = LoadClassIdInstr(r2)
    //     0xa36ba4: ldur            x1, [x2, #-1]
    //     0xa36ba8: ubfx            x1, x1, #0xc, #0x14
    // 0xa36bac: stp             x0, x2, [SP, #-0x10]!
    // 0xa36bb0: mov             x0, x1
    // 0xa36bb4: r0 = GDT[cid_x0 + -0x1000]()
    //     0xa36bb4: sub             lr, x0, #1, lsl #12
    //     0xa36bb8: ldr             lr, [x21, lr, lsl #3]
    //     0xa36bbc: blr             lr
    // 0xa36bc0: add             SP, SP, #0x10
    // 0xa36bc4: mov             x4, x0
    // 0xa36bc8: b               #0xa36bd0
    // 0xa36bcc: r4 = Null
    //     0xa36bcc: mov             x4, NULL
    // 0xa36bd0: ldr             x2, [fp, #0x10]
    // 0xa36bd4: ldur            x3, [fp, #-0x28]
    // 0xa36bd8: stur            x4, [fp, #-0x38]
    // 0xa36bdc: r0 = BoxInt64Instr(r3)
    //     0xa36bdc: sbfiz           x0, x3, #1, #0x1f
    //     0xa36be0: cmp             x3, x0, asr #1
    //     0xa36be4: b.eq            #0xa36bf0
    //     0xa36be8: bl              #0xd69bb8
    //     0xa36bec: stur            x3, [x0, #7]
    // 0xa36bf0: r1 = LoadClassIdInstr(r2)
    //     0xa36bf0: ldur            x1, [x2, #-1]
    //     0xa36bf4: ubfx            x1, x1, #0xc, #0x14
    // 0xa36bf8: stp             x0, x2, [SP, #-0x10]!
    // 0xa36bfc: mov             x0, x1
    // 0xa36c00: r0 = GDT[cid_x0 + -0x1000]()
    //     0xa36c00: sub             lr, x0, #1, lsl #12
    //     0xa36c04: ldr             lr, [x21, lr, lsl #3]
    //     0xa36c08: blr             lr
    // 0xa36c0c: add             SP, SP, #0x10
    // 0xa36c10: r1 = LoadInt32Instr(r0)
    //     0xa36c10: sbfx            x1, x0, #1, #0x1f
    // 0xa36c14: cmp             x1, #0x20
    // 0xa36c18: b.ne            #0xa36dbc
    // 0xa36c1c: ldur            x0, [fp, #-0x18]
    // 0xa36c20: tbnz            w0, #4, #0xa36c2c
    // 0xa36c24: ldur            x2, [fp, #-0x20]
    // 0xa36c28: b               #0xa36c34
    // 0xa36c2c: ldur            x2, [fp, #-0x20]
    // 0xa36c30: tbnz            w2, #4, #0xa36c7c
    // 0xa36c34: stp             x1, NULL, [SP, #-0x10]!
    // 0xa36c38: r0 = String.fromCharCode()
    //     0xa36c38: bl              #0x4d316c  ; [dart:core] String::String.fromCharCode
    // 0xa36c3c: add             SP, SP, #0x10
    // 0xa36c40: stur            x0, [fp, #-0x40]
    // 0xa36c44: LoadField: r1 = r0->field_7
    //     0xa36c44: ldur            w1, [x0, #7]
    // 0xa36c48: DecompressPointer r1
    //     0xa36c48: add             x1, x1, HEAP, lsl #32
    // 0xa36c4c: cbz             w1, #0xa36c74
    // 0xa36c50: ldur            x16, [fp, #-8]
    // 0xa36c54: SaveReg r16
    //     0xa36c54: str             x16, [SP, #-8]!
    // 0xa36c58: r0 = _consumeBuffer()
    //     0xa36c58: bl              #0x4d1cf0  ; [dart:core] StringBuffer::_consumeBuffer
    // 0xa36c5c: add             SP, SP, #8
    // 0xa36c60: ldur            x16, [fp, #-8]
    // 0xa36c64: ldur            lr, [fp, #-0x40]
    // 0xa36c68: stp             lr, x16, [SP, #-0x10]!
    // 0xa36c6c: r0 = _addPart()
    //     0xa36c6c: bl              #0x4d18b0  ; [dart:core] StringBuffer::_addPart
    // 0xa36c70: add             SP, SP, #0x10
    // 0xa36c74: ldur            x0, [fp, #-8]
    // 0xa36c78: b               #0xa36dac
    // 0xa36c7c: ldur            x0, [fp, #-8]
    // 0xa36c80: LoadField: r1 = r0->field_b
    //     0xa36c80: ldur            x1, [x0, #0xb]
    // 0xa36c84: LoadField: r2 = r0->field_27
    //     0xa36c84: ldur            x2, [x0, #0x27]
    // 0xa36c88: add             x3, x1, x2
    // 0xa36c8c: cmp             x3, #0
    // 0xa36c90: b.le            #0xa36dac
    // 0xa36c94: SaveReg r0
    //     0xa36c94: str             x0, [SP, #-8]!
    // 0xa36c98: r0 = _consumeBuffer()
    //     0xa36c98: bl              #0x4d1cf0  ; [dart:core] StringBuffer::_consumeBuffer
    // 0xa36c9c: add             SP, SP, #8
    // 0xa36ca0: ldur            x0, [fp, #-8]
    // 0xa36ca4: LoadField: r1 = r0->field_7
    //     0xa36ca4: ldur            w1, [x0, #7]
    // 0xa36ca8: DecompressPointer r1
    //     0xa36ca8: add             x1, x1, HEAP, lsl #32
    // 0xa36cac: LoadField: r2 = r0->field_b
    //     0xa36cac: ldur            x2, [x0, #0xb]
    // 0xa36cb0: cbz             x2, #0xa36cbc
    // 0xa36cb4: cmp             w1, NULL
    // 0xa36cb8: b.ne            #0xa36cc4
    // 0xa36cbc: r1 = ""
    //     0xa36cbc: ldr             x1, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xa36cc0: b               #0xa36ce4
    // 0xa36cc4: LoadField: r0 = r1->field_b
    //     0xa36cc4: ldur            w0, [x1, #0xb]
    // 0xa36cc8: DecompressPointer r0
    //     0xa36cc8: add             x0, x0, HEAP, lsl #32
    // 0xa36ccc: r2 = LoadInt32Instr(r0)
    //     0xa36ccc: sbfx            x2, x0, #1, #0x1f
    // 0xa36cd0: stp             xzr, x1, [SP, #-0x10]!
    // 0xa36cd4: SaveReg r2
    //     0xa36cd4: str             x2, [SP, #-8]!
    // 0xa36cd8: r0 = _concatRange()
    //     0xa36cd8: bl              #0x4d1bec  ; [dart:core] _StringBase::_concatRange
    // 0xa36cdc: add             SP, SP, #0x18
    // 0xa36ce0: mov             x1, x0
    // 0xa36ce4: ldur            x0, [fp, #-0x10]
    // 0xa36ce8: stur            x1, [fp, #-0x48]
    // 0xa36cec: LoadField: r2 = r0->field_b
    //     0xa36cec: ldur            w2, [x0, #0xb]
    // 0xa36cf0: DecompressPointer r2
    //     0xa36cf0: add             x2, x2, HEAP, lsl #32
    // 0xa36cf4: stur            x2, [fp, #-0x40]
    // 0xa36cf8: LoadField: r3 = r0->field_f
    //     0xa36cf8: ldur            w3, [x0, #0xf]
    // 0xa36cfc: DecompressPointer r3
    //     0xa36cfc: add             x3, x3, HEAP, lsl #32
    // 0xa36d00: LoadField: r4 = r3->field_b
    //     0xa36d00: ldur            w4, [x3, #0xb]
    // 0xa36d04: DecompressPointer r4
    //     0xa36d04: add             x4, x4, HEAP, lsl #32
    // 0xa36d08: cmp             w2, w4
    // 0xa36d0c: b.ne            #0xa36d1c
    // 0xa36d10: SaveReg r0
    //     0xa36d10: str             x0, [SP, #-8]!
    // 0xa36d14: r0 = _growToNextCapacity()
    //     0xa36d14: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa36d18: add             SP, SP, #8
    // 0xa36d1c: ldur            x0, [fp, #-0x40]
    // 0xa36d20: ldur            x2, [fp, #-0x10]
    // 0xa36d24: r3 = LoadInt32Instr(r0)
    //     0xa36d24: sbfx            x3, x0, #1, #0x1f
    // 0xa36d28: add             x0, x3, #1
    // 0xa36d2c: lsl             x1, x0, #1
    // 0xa36d30: StoreField: r2->field_b = r1
    //     0xa36d30: stur            w1, [x2, #0xb]
    // 0xa36d34: mov             x1, x3
    // 0xa36d38: cmp             x1, x0
    // 0xa36d3c: b.hs            #0xa3701c
    // 0xa36d40: LoadField: r1 = r2->field_f
    //     0xa36d40: ldur            w1, [x2, #0xf]
    // 0xa36d44: DecompressPointer r1
    //     0xa36d44: add             x1, x1, HEAP, lsl #32
    // 0xa36d48: ldur            x0, [fp, #-0x48]
    // 0xa36d4c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xa36d4c: add             x25, x1, x3, lsl #2
    //     0xa36d50: add             x25, x25, #0xf
    //     0xa36d54: str             w0, [x25]
    //     0xa36d58: tbz             w0, #0, #0xa36d74
    //     0xa36d5c: ldurb           w16, [x1, #-1]
    //     0xa36d60: ldurb           w17, [x0, #-1]
    //     0xa36d64: and             x16, x17, x16, lsr #2
    //     0xa36d68: tst             x16, HEAP, lsr #32
    //     0xa36d6c: b.eq            #0xa36d74
    //     0xa36d70: bl              #0xd67e5c
    // 0xa36d74: r0 = StringBuffer()
    //     0xa36d74: bl              #0x4d1e30  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0xa36d78: mov             x1, x0
    // 0xa36d7c: r0 = 0
    //     0xa36d7c: mov             x0, #0
    // 0xa36d80: stur            x1, [fp, #-0x40]
    // 0xa36d84: StoreField: r1->field_b = r0
    //     0xa36d84: stur            x0, [x1, #0xb]
    // 0xa36d88: StoreField: r1->field_13 = r0
    //     0xa36d88: stur            x0, [x1, #0x13]
    // 0xa36d8c: StoreField: r1->field_1b = r0
    //     0xa36d8c: stur            x0, [x1, #0x1b]
    // 0xa36d90: StoreField: r1->field_27 = r0
    //     0xa36d90: stur            x0, [x1, #0x27]
    // 0xa36d94: StoreField: r1->field_2f = r0
    //     0xa36d94: stur            x0, [x1, #0x2f]
    // 0xa36d98: r16 = ""
    //     0xa36d98: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xa36d9c: stp             x16, x1, [SP, #-0x10]!
    // 0xa36da0: r0 = write()
    //     0xa36da0: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xa36da4: add             SP, SP, #0x10
    // 0xa36da8: ldur            x0, [fp, #-0x40]
    // 0xa36dac: mov             x8, x0
    // 0xa36db0: ldur            x7, [fp, #-0x18]
    // 0xa36db4: ldur            x6, [fp, #-0x20]
    // 0xa36db8: b               #0xa36f24
    // 0xa36dbc: ldur            x0, [fp, #-8]
    // 0xa36dc0: cmp             x1, #0x27
    // 0xa36dc4: b.ne            #0xa36e4c
    // 0xa36dc8: ldur            x2, [fp, #-0x38]
    // 0xa36dcc: cmp             w2, NULL
    // 0xa36dd0: b.eq            #0xa36ddc
    // 0xa36dd4: cmp             w2, #0xb8
    // 0xa36dd8: b.eq            #0xa36e50
    // 0xa36ddc: ldur            x2, [fp, #-0x18]
    // 0xa36de0: tbnz            w2, #4, #0xa36dec
    // 0xa36de4: r0 = false
    //     0xa36de4: add             x0, NULL, #0x30  ; false
    // 0xa36de8: b               #0xa36e40
    // 0xa36dec: ldur            x3, [fp, #-0x20]
    // 0xa36df0: tbnz            w3, #4, #0xa36e3c
    // 0xa36df4: stp             x1, NULL, [SP, #-0x10]!
    // 0xa36df8: r0 = String.fromCharCode()
    //     0xa36df8: bl              #0x4d316c  ; [dart:core] String::String.fromCharCode
    // 0xa36dfc: add             SP, SP, #0x10
    // 0xa36e00: stur            x0, [fp, #-0x40]
    // 0xa36e04: LoadField: r1 = r0->field_7
    //     0xa36e04: ldur            w1, [x0, #7]
    // 0xa36e08: DecompressPointer r1
    //     0xa36e08: add             x1, x1, HEAP, lsl #32
    // 0xa36e0c: cbz             w1, #0xa36e34
    // 0xa36e10: ldur            x16, [fp, #-8]
    // 0xa36e14: SaveReg r16
    //     0xa36e14: str             x16, [SP, #-8]!
    // 0xa36e18: r0 = _consumeBuffer()
    //     0xa36e18: bl              #0x4d1cf0  ; [dart:core] StringBuffer::_consumeBuffer
    // 0xa36e1c: add             SP, SP, #8
    // 0xa36e20: ldur            x16, [fp, #-8]
    // 0xa36e24: ldur            lr, [fp, #-0x40]
    // 0xa36e28: stp             lr, x16, [SP, #-0x10]!
    // 0xa36e2c: r0 = _addPart()
    //     0xa36e2c: bl              #0x4d18b0  ; [dart:core] StringBuffer::_addPart
    // 0xa36e30: add             SP, SP, #0x10
    // 0xa36e34: ldur            x0, [fp, #-0x18]
    // 0xa36e38: b               #0xa36e40
    // 0xa36e3c: r0 = true
    //     0xa36e3c: add             x0, NULL, #0x20  ; true
    // 0xa36e40: mov             x1, x0
    // 0xa36e44: ldur            x0, [fp, #-0x20]
    // 0xa36e48: b               #0xa36f18
    // 0xa36e4c: ldur            x2, [fp, #-0x38]
    // 0xa36e50: cmp             x1, #0x22
    // 0xa36e54: b.ne            #0xa36ed0
    // 0xa36e58: cmp             w2, NULL
    // 0xa36e5c: b.eq            #0xa36e68
    // 0xa36e60: cmp             w2, #0xb8
    // 0xa36e64: b.eq            #0xa36ed0
    // 0xa36e68: ldur            x0, [fp, #-0x20]
    // 0xa36e6c: tbnz            w0, #4, #0xa36e78
    // 0xa36e70: r0 = false
    //     0xa36e70: add             x0, NULL, #0x30  ; false
    // 0xa36e74: b               #0xa36f14
    // 0xa36e78: ldur            x2, [fp, #-0x18]
    // 0xa36e7c: tbnz            w2, #4, #0xa36ec8
    // 0xa36e80: stp             x1, NULL, [SP, #-0x10]!
    // 0xa36e84: r0 = String.fromCharCode()
    //     0xa36e84: bl              #0x4d316c  ; [dart:core] String::String.fromCharCode
    // 0xa36e88: add             SP, SP, #0x10
    // 0xa36e8c: stur            x0, [fp, #-0x38]
    // 0xa36e90: LoadField: r1 = r0->field_7
    //     0xa36e90: ldur            w1, [x0, #7]
    // 0xa36e94: DecompressPointer r1
    //     0xa36e94: add             x1, x1, HEAP, lsl #32
    // 0xa36e98: cbz             w1, #0xa36ec0
    // 0xa36e9c: ldur            x16, [fp, #-8]
    // 0xa36ea0: SaveReg r16
    //     0xa36ea0: str             x16, [SP, #-8]!
    // 0xa36ea4: r0 = _consumeBuffer()
    //     0xa36ea4: bl              #0x4d1cf0  ; [dart:core] StringBuffer::_consumeBuffer
    // 0xa36ea8: add             SP, SP, #8
    // 0xa36eac: ldur            x16, [fp, #-8]
    // 0xa36eb0: ldur            lr, [fp, #-0x38]
    // 0xa36eb4: stp             lr, x16, [SP, #-0x10]!
    // 0xa36eb8: r0 = _addPart()
    //     0xa36eb8: bl              #0x4d18b0  ; [dart:core] StringBuffer::_addPart
    // 0xa36ebc: add             SP, SP, #0x10
    // 0xa36ec0: ldur            x0, [fp, #-0x20]
    // 0xa36ec4: b               #0xa36f14
    // 0xa36ec8: r0 = true
    //     0xa36ec8: add             x0, NULL, #0x20  ; true
    // 0xa36ecc: b               #0xa36f14
    // 0xa36ed0: stp             x1, NULL, [SP, #-0x10]!
    // 0xa36ed4: r0 = String.fromCharCode()
    //     0xa36ed4: bl              #0x4d316c  ; [dart:core] String::String.fromCharCode
    // 0xa36ed8: add             SP, SP, #0x10
    // 0xa36edc: stur            x0, [fp, #-0x38]
    // 0xa36ee0: LoadField: r1 = r0->field_7
    //     0xa36ee0: ldur            w1, [x0, #7]
    // 0xa36ee4: DecompressPointer r1
    //     0xa36ee4: add             x1, x1, HEAP, lsl #32
    // 0xa36ee8: cbz             w1, #0xa36f10
    // 0xa36eec: ldur            x16, [fp, #-8]
    // 0xa36ef0: SaveReg r16
    //     0xa36ef0: str             x16, [SP, #-8]!
    // 0xa36ef4: r0 = _consumeBuffer()
    //     0xa36ef4: bl              #0x4d1cf0  ; [dart:core] StringBuffer::_consumeBuffer
    // 0xa36ef8: add             SP, SP, #8
    // 0xa36efc: ldur            x16, [fp, #-8]
    // 0xa36f00: ldur            lr, [fp, #-0x38]
    // 0xa36f04: stp             lr, x16, [SP, #-0x10]!
    // 0xa36f08: r0 = _addPart()
    //     0xa36f08: bl              #0x4d18b0  ; [dart:core] StringBuffer::_addPart
    // 0xa36f0c: add             SP, SP, #0x10
    // 0xa36f10: ldur            x0, [fp, #-0x20]
    // 0xa36f14: ldur            x1, [fp, #-0x18]
    // 0xa36f18: ldur            x8, [fp, #-8]
    // 0xa36f1c: mov             x7, x1
    // 0xa36f20: mov             x6, x0
    // 0xa36f24: ldur            x0, [fp, #-0x28]
    // 0xa36f28: add             x5, x0, #1
    // 0xa36f2c: ldr             x2, [fp, #0x10]
    // 0xa36f30: ldur            x3, [fp, #-0x30]
    // 0xa36f34: b               #0xa36b5c
    // 0xa36f38: mov             x0, x8
    // 0xa36f3c: LoadField: r1 = r0->field_b
    //     0xa36f3c: ldur            x1, [x0, #0xb]
    // 0xa36f40: LoadField: r2 = r0->field_27
    //     0xa36f40: ldur            x2, [x0, #0x27]
    // 0xa36f44: add             x3, x1, x2
    // 0xa36f48: cmp             x3, #0
    // 0xa36f4c: b.le            #0xa36ff8
    // 0xa36f50: ldur            x1, [fp, #-0x10]
    // 0xa36f54: SaveReg r0
    //     0xa36f54: str             x0, [SP, #-8]!
    // 0xa36f58: r0 = toString()
    //     0xa36f58: bl              #0xaba59c  ; [dart:core] StringBuffer::toString
    // 0xa36f5c: add             SP, SP, #8
    // 0xa36f60: mov             x1, x0
    // 0xa36f64: ldur            x0, [fp, #-0x10]
    // 0xa36f68: stur            x1, [fp, #-0x18]
    // 0xa36f6c: LoadField: r2 = r0->field_b
    //     0xa36f6c: ldur            w2, [x0, #0xb]
    // 0xa36f70: DecompressPointer r2
    //     0xa36f70: add             x2, x2, HEAP, lsl #32
    // 0xa36f74: stur            x2, [fp, #-8]
    // 0xa36f78: LoadField: r3 = r0->field_f
    //     0xa36f78: ldur            w3, [x0, #0xf]
    // 0xa36f7c: DecompressPointer r3
    //     0xa36f7c: add             x3, x3, HEAP, lsl #32
    // 0xa36f80: LoadField: r4 = r3->field_b
    //     0xa36f80: ldur            w4, [x3, #0xb]
    // 0xa36f84: DecompressPointer r4
    //     0xa36f84: add             x4, x4, HEAP, lsl #32
    // 0xa36f88: cmp             w2, w4
    // 0xa36f8c: b.ne            #0xa36f9c
    // 0xa36f90: SaveReg r0
    //     0xa36f90: str             x0, [SP, #-8]!
    // 0xa36f94: r0 = _growToNextCapacity()
    //     0xa36f94: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa36f98: add             SP, SP, #8
    // 0xa36f9c: ldur            x3, [fp, #-8]
    // 0xa36fa0: ldur            x2, [fp, #-0x10]
    // 0xa36fa4: r4 = LoadInt32Instr(r3)
    //     0xa36fa4: sbfx            x4, x3, #1, #0x1f
    // 0xa36fa8: add             x0, x4, #1
    // 0xa36fac: lsl             x3, x0, #1
    // 0xa36fb0: StoreField: r2->field_b = r3
    //     0xa36fb0: stur            w3, [x2, #0xb]
    // 0xa36fb4: mov             x1, x4
    // 0xa36fb8: cmp             x1, x0
    // 0xa36fbc: b.hs            #0xa37020
    // 0xa36fc0: LoadField: r1 = r2->field_f
    //     0xa36fc0: ldur            w1, [x2, #0xf]
    // 0xa36fc4: DecompressPointer r1
    //     0xa36fc4: add             x1, x1, HEAP, lsl #32
    // 0xa36fc8: ldur            x0, [fp, #-0x18]
    // 0xa36fcc: ArrayStore: r1[r4] = r0  ; List_4
    //     0xa36fcc: add             x25, x1, x4, lsl #2
    //     0xa36fd0: add             x25, x25, #0xf
    //     0xa36fd4: str             w0, [x25]
    //     0xa36fd8: tbz             w0, #0, #0xa36ff4
    //     0xa36fdc: ldurb           w16, [x1, #-1]
    //     0xa36fe0: ldurb           w17, [x0, #-1]
    //     0xa36fe4: and             x16, x17, x16, lsr #2
    //     0xa36fe8: tst             x16, HEAP, lsr #32
    //     0xa36fec: b.eq            #0xa36ff4
    //     0xa36ff0: bl              #0xd67e5c
    // 0xa36ff4: b               #0xa36ffc
    // 0xa36ff8: ldur            x2, [fp, #-0x10]
    // 0xa36ffc: mov             x0, x2
    // 0xa37000: LeaveFrame
    //     0xa37000: mov             SP, fp
    //     0xa37004: ldp             fp, lr, [SP], #0x10
    // 0xa37008: ret
    //     0xa37008: ret             
    // 0xa3700c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa3700c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa37010: b               #0xa36ae4
    // 0xa37014: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa37014: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa37018: b               #0xa36b7c
    // 0xa3701c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa3701c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa37020: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa37020: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ getSession(/* No info */) async {
    // ** addr: 0xcb7004, size: 0x160
    // 0xcb7004: EnterFrame
    //     0xcb7004: stp             fp, lr, [SP, #-0x10]!
    //     0xcb7008: mov             fp, SP
    // 0xcb700c: AllocStack(0x58)
    //     0xcb700c: sub             SP, SP, #0x58
    // 0xcb7010: SetupParameters(dynamic _ /* r1, fp-0x48 */)
    //     0xcb7010: stur            NULL, [fp, #-8]
    //     0xcb7014: mov             x0, #0
    //     0xcb7018: add             x1, fp, w0, sxtw #2
    //     0xcb701c: ldr             x1, [x1, #0x10]
    //     0xcb7020: stur            x1, [fp, #-0x48]
    // 0xcb7024: CheckStackOverflow
    //     0xcb7024: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb7028: cmp             SP, x16
    //     0xcb702c: b.ls            #0xcb715c
    // 0xcb7030: InitAsync() -> Future<Session?>
    //     0xcb7030: add             x0, PP, #0x40, lsl #12  ; [pp+0x40728] TypeArguments: <Session?>
    //     0xcb7034: ldr             x0, [x0, #0x728]
    //     0xcb7038: bl              #0x4b92e4
    // 0xcb703c: ldur            x0, [fp, #-0x48]
    // 0xcb7040: r0 = init()
    //     0xcb7040: bl              #0xa355ac  ; [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::init
    // 0xcb7044: mov             x1, x0
    // 0xcb7048: stur            x1, [fp, #-0x50]
    // 0xcb704c: r0 = Await()
    //     0xcb704c: bl              #0x4b8e6c  ; AwaitStub
    // 0xcb7050: r0 = InitLateStaticField(0xc50) // [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::_platform
    //     0xcb7050: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb7054: ldr             x0, [x0, #0x18a0]
    //     0xcb7058: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb705c: cmp             w0, w16
    //     0xcb7060: b.ne            #0xcb7070
    //     0xcb7064: add             x2, PP, #0x2f, lsl #12  ; [pp+0x2fd58] Field <FFmpegKitConfig._platform@517022016>: static late (offset: 0xc50)
    //     0xcb7068: ldr             x2, [x2, #0xd58]
    //     0xcb706c: bl              #0xd67d44
    // 0xcb7070: SaveReg r0
    //     0xcb7070: str             x0, [SP, #-8]!
    // 0xcb7074: ldur            x0, [fp, #-0x48]
    // 0xcb7078: SaveReg r0
    //     0xcb7078: str             x0, [SP, #-8]!
    // 0xcb707c: r0 = ffmpegKitConfigGetSession()
    //     0xcb707c: bl              #0xcb7164  ; [package:ffmpeg_kit_flutter_platform_interface/method_channel_ffmpeg_kit_flutter.dart] MethodChannelFFmpegKit::ffmpegKitConfigGetSession
    // 0xcb7080: add             SP, SP, #0x10
    // 0xcb7084: r16 = <Session?>
    //     0xcb7084: add             x16, PP, #0x40, lsl #12  ; [pp+0x40728] TypeArguments: <Session?>
    //     0xcb7088: ldr             x16, [x16, #0x728]
    // 0xcb708c: stp             x0, x16, [SP, #-0x10]!
    // 0xcb7090: r16 = Closure: (Map<dynamic, dynamic>?) => Session? from Function 'mapToNullableSession': static.
    //     0xcb7090: add             x16, PP, #0x40, lsl #12  ; [pp+0x40730] Closure: (Map<dynamic, dynamic>?) => Session? from Function 'mapToNullableSession': static. (0x7fe6e24b721c)
    //     0xcb7094: ldr             x16, [x16, #0x730]
    // 0xcb7098: SaveReg r16
    //     0xcb7098: str             x16, [SP, #-8]!
    // 0xcb709c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xcb709c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xcb70a0: r0 = then()
    //     0xcb70a0: bl              #0xca6124  ; [dart:async] _Future::then
    // 0xcb70a4: add             SP, SP, #0x18
    // 0xcb70a8: r0 = ReturnAsync()
    //     0xcb70a8: b               #0x501858  ; ReturnAsyncStub
    // 0xcb70ac: sub             SP, fp, #0x58
    // 0xcb70b0: mov             x3, x0
    // 0xcb70b4: stur            x0, [fp, #-0x50]
    // 0xcb70b8: mov             x0, x1
    // 0xcb70bc: stur            x1, [fp, #-0x58]
    // 0xcb70c0: r1 = LoadTaggedClassIdMayBeSmiInstr(r3)
    //     0xcb70c0: mov             x1, #0x76
    //     0xcb70c4: tbz             w3, #0, #0xcb70d4
    //     0xcb70c8: ldur            x1, [x3, #-1]
    //     0xcb70cc: ubfx            x1, x1, #0xc, #0x14
    //     0xcb70d0: lsl             x1, x1, #1
    // 0xcb70d4: cmp             w1, #0xf28
    // 0xcb70d8: b.ne            #0xcb7148
    // 0xcb70dc: r1 = Null
    //     0xcb70dc: mov             x1, NULL
    // 0xcb70e0: r2 = 4
    //     0xcb70e0: mov             x2, #4
    // 0xcb70e4: r0 = AllocateArray()
    //     0xcb70e4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xcb70e8: r17 = "Plugin getSession error: "
    //     0xcb70e8: add             x17, PP, #0x40, lsl #12  ; [pp+0x40738] "Plugin getSession error: "
    //     0xcb70ec: ldr             x17, [x17, #0x738]
    // 0xcb70f0: StoreField: r0->field_f = r17
    //     0xcb70f0: stur            w17, [x0, #0xf]
    // 0xcb70f4: ldur            x1, [fp, #-0x50]
    // 0xcb70f8: LoadField: r2 = r1->field_b
    //     0xcb70f8: ldur            w2, [x1, #0xb]
    // 0xcb70fc: DecompressPointer r2
    //     0xcb70fc: add             x2, x2, HEAP, lsl #32
    // 0xcb7100: StoreField: r0->field_13 = r2
    //     0xcb7100: stur            w2, [x0, #0x13]
    // 0xcb7104: SaveReg r0
    //     0xcb7104: str             x0, [SP, #-8]!
    // 0xcb7108: r0 = _interpolate()
    //     0xcb7108: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xcb710c: add             SP, SP, #8
    // 0xcb7110: SaveReg r0
    //     0xcb7110: str             x0, [SP, #-8]!
    // 0xcb7114: r0 = print()
    //     0xcb7114: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xcb7118: add             SP, SP, #8
    // 0xcb711c: r16 = <Session?>
    //     0xcb711c: add             x16, PP, #0x40, lsl #12  ; [pp+0x40728] TypeArguments: <Session?>
    //     0xcb7120: ldr             x16, [x16, #0x728]
    // 0xcb7124: r30 = "getSession failed."
    //     0xcb7124: add             lr, PP, #0x40, lsl #12  ; [pp+0x40740] "getSession failed."
    //     0xcb7128: ldr             lr, [lr, #0x740]
    // 0xcb712c: stp             lr, x16, [SP, #-0x10]!
    // 0xcb7130: ldur            x16, [fp, #-0x58]
    // 0xcb7134: SaveReg r16
    //     0xcb7134: str             x16, [SP, #-8]!
    // 0xcb7138: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xcb7138: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xcb713c: r0 = Future.error()
    //     0xcb713c: bl              #0x4e95bc  ; [dart:async] Future::Future.error
    // 0xcb7140: add             SP, SP, #0x18
    // 0xcb7144: r0 = ReturnAsync()
    //     0xcb7144: b               #0x501858  ; ReturnAsyncStub
    // 0xcb7148: mov             x1, x3
    // 0xcb714c: mov             x0, x1
    // 0xcb7150: ldur            x1, [fp, #-0x58]
    // 0xcb7154: r0 = ReThrow()
    //     0xcb7154: bl              #0xd67e14  ; ReThrowStub
    // 0xcb7158: brk             #0
    // 0xcb715c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb715c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb7160: b               #0xcb7030
  }
  static int _activeLogLevel() {
    // ** addr: 0xcb9544, size: 0x8
    // 0xcb9544: r0 = 112
    //     0xcb9544: mov             x0, #0x70
    // 0xcb9548: ret
    //     0xcb9548: ret             
  }
}

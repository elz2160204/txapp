// lib: , url: package:ffmpeg_kit_flutter_min/log.dart

// class id: 1049007, size: 0x8
class :: {
}

// class id: 4414, size: 0xc, field offset: 0x8
class Log extends Object {
}

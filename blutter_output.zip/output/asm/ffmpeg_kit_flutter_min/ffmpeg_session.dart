// lib: , url: package:ffmpeg_kit_flutter_min/ffmpeg_session.dart

// class id: 1049002, size: 0x8
class :: {
}

// class id: 4422, size: 0xc, field offset: 0xc
class FFmpegSession extends AbstractSession {

  static _ create(/* No info */) async {
    // ** addr: 0xa36524, size: 0x60
    // 0xa36524: EnterFrame
    //     0xa36524: stp             fp, lr, [SP, #-0x10]!
    //     0xa36528: mov             fp, SP
    // 0xa3652c: AllocStack(0x10)
    //     0xa3652c: sub             SP, SP, #0x10
    // 0xa36530: SetupParameters(dynamic _ /* r1, fp-0x10 */)
    //     0xa36530: stur            NULL, [fp, #-8]
    //     0xa36534: mov             x0, #0
    //     0xa36538: add             x1, fp, w0, sxtw #2
    //     0xa3653c: ldr             x1, [x1, #0x10]
    //     0xa36540: stur            x1, [fp, #-0x10]
    // 0xa36544: CheckStackOverflow
    //     0xa36544: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa36548: cmp             SP, x16
    //     0xa3654c: b.ls            #0xa3657c
    // 0xa36550: InitAsync() -> Future<FFmpegSession>
    //     0xa36550: add             x0, PP, #0x2f, lsl #12  ; [pp+0x2ffb0] TypeArguments: <FFmpegSession>
    //     0xa36554: ldr             x0, [x0, #0xfb0]
    //     0xa36558: bl              #0x4b92e4
    // 0xa3655c: ldur            x16, [fp, #-0x10]
    // 0xa36560: SaveReg r16
    //     0xa36560: str             x16, [SP, #-8]!
    // 0xa36564: r0 = createFFmpegSession()
    //     0xa36564: bl              #0xa365a8  ; [package:ffmpeg_kit_flutter_min/abstract_session.dart] AbstractSession::createFFmpegSession
    // 0xa36568: add             SP, SP, #8
    // 0xa3656c: mov             x1, x0
    // 0xa36570: stur            x1, [fp, #-0x10]
    // 0xa36574: r0 = Await()
    //     0xa36574: bl              #0x4b8e6c  ; AwaitStub
    // 0xa36578: r0 = ReturnAsync()
    //     0xa36578: b               #0x501858  ; ReturnAsyncStub
    // 0xa3657c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa3657c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa36580: b               #0xa36550
  }
  _ getCompleteCallback(/* No info */) {
    // ** addr: 0xcb8128, size: 0x40
    // 0xcb8128: EnterFrame
    //     0xcb8128: stp             fp, lr, [SP, #-0x10]!
    //     0xcb812c: mov             fp, SP
    // 0xcb8130: CheckStackOverflow
    //     0xcb8130: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb8134: cmp             SP, x16
    //     0xcb8138: b.ls            #0xcb8160
    // 0xcb813c: ldr             x0, [fp, #0x10]
    // 0xcb8140: LoadField: r1 = r0->field_7
    //     0xcb8140: ldur            w1, [x0, #7]
    // 0xcb8144: DecompressPointer r1
    //     0xcb8144: add             x1, x1, HEAP, lsl #32
    // 0xcb8148: SaveReg r1
    //     0xcb8148: str             x1, [SP, #-8]!
    // 0xcb814c: r0 = getFFmpegSessionCompleteCallback()
    //     0xcb814c: bl              #0xcb8168  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] FFmpegKitFactory::getFFmpegSessionCompleteCallback
    // 0xcb8150: add             SP, SP, #8
    // 0xcb8154: LeaveFrame
    //     0xcb8154: mov             SP, fp
    //     0xcb8158: ldp             fp, lr, [SP], #0x10
    // 0xcb815c: ret
    //     0xcb815c: ret             
    // 0xcb8160: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb8160: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb8164: b               #0xcb813c
  }
}

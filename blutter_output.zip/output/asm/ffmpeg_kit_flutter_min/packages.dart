// lib: , url: package:ffmpeg_kit_flutter_min/packages.dart

// class id: 1049013, size: 0x8
class :: {
}

// class id: 4412, size: 0x8, field offset: 0x8
abstract class Packages extends Object {

  static late FFmpegKitPlatform _platform; // offset: 0xca0

  static _ getPackageName(/* No info */) async {
    // ** addr: 0xa35c00, size: 0x118
    // 0xa35c00: EnterFrame
    //     0xa35c00: stp             fp, lr, [SP, #-0x10]!
    //     0xa35c04: mov             fp, SP
    // 0xa35c08: AllocStack(0x48)
    //     0xa35c08: sub             SP, SP, #0x48
    // 0xa35c0c: SetupParameters()
    //     0xa35c0c: stur            NULL, [fp, #-8]
    // 0xa35c10: CheckStackOverflow
    //     0xa35c10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa35c14: cmp             SP, x16
    //     0xa35c18: b.ls            #0xa35d10
    // 0xa35c1c: InitAsync() -> Future<String?>
    //     0xa35c1c: ldr             x0, [PP, #0x1020]  ; [pp+0x1020] TypeArguments: <String?>
    //     0xa35c20: bl              #0x4b92e4
    // 0xa35c24: r0 = init()
    //     0xa35c24: bl              #0xa355ac  ; [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::init
    // 0xa35c28: mov             x1, x0
    // 0xa35c2c: stur            x1, [fp, #-0x40]
    // 0xa35c30: r0 = Await()
    //     0xa35c30: bl              #0x4b8e6c  ; AwaitStub
    // 0xa35c34: r0 = InitLateStaticField(0xca0) // [package:ffmpeg_kit_flutter_min/packages.dart] Packages::_platform
    //     0xa35c34: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa35c38: ldr             x0, [x0, #0x1940]
    //     0xa35c3c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa35c40: cmp             w0, w16
    //     0xa35c44: b.ne            #0xa35c54
    //     0xa35c48: add             x2, PP, #0x2f, lsl #12  ; [pp+0x2fda8] Field <Packages._platform@541460411>: static late (offset: 0xca0)
    //     0xa35c4c: ldr             x2, [x2, #0xda8]
    //     0xa35c50: bl              #0xd67d44
    // 0xa35c54: SaveReg r0
    //     0xa35c54: str             x0, [SP, #-8]!
    // 0xa35c58: r0 = getPackageName()
    //     0xa35c58: bl              #0xa35d18  ; [package:ffmpeg_kit_flutter_platform_interface/method_channel_ffmpeg_kit_flutter.dart] MethodChannelFFmpegKit::getPackageName
    // 0xa35c5c: add             SP, SP, #8
    // 0xa35c60: r0 = ReturnAsync()
    //     0xa35c60: b               #0x501858  ; ReturnAsyncStub
    // 0xa35c64: sub             SP, fp, #0x48
    // 0xa35c68: mov             x3, x0
    // 0xa35c6c: stur            x0, [fp, #-0x40]
    // 0xa35c70: mov             x0, x1
    // 0xa35c74: stur            x1, [fp, #-0x48]
    // 0xa35c78: r1 = LoadTaggedClassIdMayBeSmiInstr(r3)
    //     0xa35c78: mov             x1, #0x76
    //     0xa35c7c: tbz             w3, #0, #0xa35c8c
    //     0xa35c80: ldur            x1, [x3, #-1]
    //     0xa35c84: ubfx            x1, x1, #0xc, #0x14
    //     0xa35c88: lsl             x1, x1, #1
    // 0xa35c8c: cmp             w1, #0xf28
    // 0xa35c90: b.ne            #0xa35cfc
    // 0xa35c94: r1 = Null
    //     0xa35c94: mov             x1, NULL
    // 0xa35c98: r2 = 4
    //     0xa35c98: mov             x2, #4
    // 0xa35c9c: r0 = AllocateArray()
    //     0xa35c9c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa35ca0: r17 = "Plugin getPackageName error: "
    //     0xa35ca0: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2fdb0] "Plugin getPackageName error: "
    //     0xa35ca4: ldr             x17, [x17, #0xdb0]
    // 0xa35ca8: StoreField: r0->field_f = r17
    //     0xa35ca8: stur            w17, [x0, #0xf]
    // 0xa35cac: ldur            x1, [fp, #-0x40]
    // 0xa35cb0: LoadField: r2 = r1->field_b
    //     0xa35cb0: ldur            w2, [x1, #0xb]
    // 0xa35cb4: DecompressPointer r2
    //     0xa35cb4: add             x2, x2, HEAP, lsl #32
    // 0xa35cb8: StoreField: r0->field_13 = r2
    //     0xa35cb8: stur            w2, [x0, #0x13]
    // 0xa35cbc: SaveReg r0
    //     0xa35cbc: str             x0, [SP, #-8]!
    // 0xa35cc0: r0 = _interpolate()
    //     0xa35cc0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa35cc4: add             SP, SP, #8
    // 0xa35cc8: SaveReg r0
    //     0xa35cc8: str             x0, [SP, #-8]!
    // 0xa35ccc: r0 = print()
    //     0xa35ccc: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xa35cd0: add             SP, SP, #8
    // 0xa35cd4: r16 = <String?>
    //     0xa35cd4: ldr             x16, [PP, #0x1020]  ; [pp+0x1020] TypeArguments: <String?>
    // 0xa35cd8: r30 = "getPackageName failed."
    //     0xa35cd8: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2fdb8] "getPackageName failed."
    //     0xa35cdc: ldr             lr, [lr, #0xdb8]
    // 0xa35ce0: stp             lr, x16, [SP, #-0x10]!
    // 0xa35ce4: ldur            x16, [fp, #-0x48]
    // 0xa35ce8: SaveReg r16
    //     0xa35ce8: str             x16, [SP, #-8]!
    // 0xa35cec: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa35cec: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa35cf0: r0 = Future.error()
    //     0xa35cf0: bl              #0x4e95bc  ; [dart:async] Future::Future.error
    // 0xa35cf4: add             SP, SP, #0x18
    // 0xa35cf8: r0 = ReturnAsync()
    //     0xa35cf8: b               #0x501858  ; ReturnAsyncStub
    // 0xa35cfc: mov             x1, x3
    // 0xa35d00: mov             x0, x1
    // 0xa35d04: ldur            x1, [fp, #-0x48]
    // 0xa35d08: r0 = ReThrow()
    //     0xa35d08: bl              #0xd67e14  ; ReThrowStub
    // 0xa35d0c: brk             #0
    // 0xa35d10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa35d10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa35d14: b               #0xa35c1c
  }
}

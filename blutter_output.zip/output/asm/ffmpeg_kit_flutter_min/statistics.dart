// lib: , url: package:ffmpeg_kit_flutter_min/statistics.dart

// class id: 1049020, size: 0x8
class :: {
}

// class id: 4408, size: 0x10, field offset: 0x8
class Statistics extends Object {
}

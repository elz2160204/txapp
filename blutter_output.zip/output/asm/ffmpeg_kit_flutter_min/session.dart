// lib: , url: package:ffmpeg_kit_flutter_min/session.dart

// class id: 1049015, size: 0x8
class :: {
}

// class id: 4418, size: 0x8, field offset: 0x8
abstract class Session extends Object {
}

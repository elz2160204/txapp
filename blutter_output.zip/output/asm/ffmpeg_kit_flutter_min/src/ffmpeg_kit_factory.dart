// lib: , url: package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart

// class id: 1049018, size: 0x8
class :: {

  static late final Map<int, (dynamic, FFmpegSession) => void> ffmpegSessionCompleteCallbackMap; // offset: 0xc74
  static late final Map<int, (dynamic, MediaInformationSession) => void> mediaInformationSessionCompleteCallbackMap; // offset: 0xc7c
  static late final Map<int, (dynamic, FFprobeSession) => void> ffprobeSessionCompleteCallbackMap; // offset: 0xc78
  static late final Map<int, LogRedirectionStrategy> logRedirectionStrategyMap; // offset: 0xc88
  static late final Map<int, (dynamic, Statistics) => void> statisticsCallbackMap; // offset: 0xc84
  static late final Map<int, (dynamic, Log) => void> logCallbackMap; // offset: 0xc80

  static Map<int, LogRedirectionStrategy> logRedirectionStrategyMap() {
    // ** addr: 0xcb7614, size: 0xd0
    // 0xcb7614: EnterFrame
    //     0xcb7614: stp             fp, lr, [SP, #-0x10]!
    //     0xcb7618: mov             fp, SP
    // 0xcb761c: AllocStack(0x8)
    //     0xcb761c: sub             SP, SP, #8
    // 0xcb7620: CheckStackOverflow
    //     0xcb7620: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb7624: cmp             SP, x16
    //     0xcb7628: b.ls            #0xcb76dc
    // 0xcb762c: r1 = <int, LogRedirectionStrategy>
    //     0xcb762c: add             x1, PP, #0x40, lsl #12  ; [pp+0x407a0] TypeArguments: <int, LogRedirectionStrategy>
    //     0xcb7630: ldr             x1, [x1, #0x7a0]
    // 0xcb7634: r0 = _Map()
    //     0xcb7634: bl              #0x4b4914  ; Allocate_MapStub -> _Map<X0, X1> (size=-0x8)
    // 0xcb7638: stur            x0, [fp, #-8]
    // 0xcb763c: SaveReg r0
    //     0xcb763c: str             x0, [SP, #-8]!
    // 0xcb7640: r0 = Shader._()
    //     0xcb7640: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0xcb7644: add             SP, SP, #8
    // 0xcb7648: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0xcb7648: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb764c: ldr             x0, [x0, #0x598]
    //     0xcb7650: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb7654: cmp             w0, w16
    //     0xcb7658: b.ne            #0xcb7664
    //     0xcb765c: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0xcb7660: bl              #0xd67cdc
    // 0xcb7664: ldur            x1, [fp, #-8]
    // 0xcb7668: StoreField: r1->field_1b = r0
    //     0xcb7668: stur            w0, [x1, #0x1b]
    //     0xcb766c: ldurb           w16, [x1, #-1]
    //     0xcb7670: ldurb           w17, [x0, #-1]
    //     0xcb7674: and             x16, x17, x16, lsr #2
    //     0xcb7678: tst             x16, HEAP, lsr #32
    //     0xcb767c: b.eq            #0xcb7684
    //     0xcb7680: bl              #0xd6826c
    // 0xcb7684: StoreField: r1->field_b = rZR
    //     0xcb7684: stur            wzr, [x1, #0xb]
    // 0xcb7688: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0xcb7688: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb768c: ldr             x0, [x0, #0x5a0]
    //     0xcb7690: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb7694: cmp             w0, w16
    //     0xcb7698: b.ne            #0xcb76a4
    //     0xcb769c: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0xcb76a0: bl              #0xd67cdc
    // 0xcb76a4: ldur            x1, [fp, #-8]
    // 0xcb76a8: StoreField: r1->field_f = r0
    //     0xcb76a8: stur            w0, [x1, #0xf]
    //     0xcb76ac: ldurb           w16, [x1, #-1]
    //     0xcb76b0: ldurb           w17, [x0, #-1]
    //     0xcb76b4: and             x16, x17, x16, lsr #2
    //     0xcb76b8: tst             x16, HEAP, lsr #32
    //     0xcb76bc: b.eq            #0xcb76c4
    //     0xcb76c0: bl              #0xd6826c
    // 0xcb76c4: StoreField: r1->field_13 = rZR
    //     0xcb76c4: stur            wzr, [x1, #0x13]
    // 0xcb76c8: StoreField: r1->field_17 = rZR
    //     0xcb76c8: stur            wzr, [x1, #0x17]
    // 0xcb76cc: mov             x0, x1
    // 0xcb76d0: LeaveFrame
    //     0xcb76d0: mov             SP, fp
    //     0xcb76d4: ldp             fp, lr, [SP], #0x10
    // 0xcb76d8: ret
    //     0xcb76d8: ret             
    // 0xcb76dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb76dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb76e0: b               #0xcb762c
  }
  static Map<int, (dynamic, FFmpegSession) => void> ffmpegSessionCompleteCallbackMap() {
    // ** addr: 0xcb81e0, size: 0xd0
    // 0xcb81e0: EnterFrame
    //     0xcb81e0: stp             fp, lr, [SP, #-0x10]!
    //     0xcb81e4: mov             fp, SP
    // 0xcb81e8: AllocStack(0x8)
    //     0xcb81e8: sub             SP, SP, #8
    // 0xcb81ec: CheckStackOverflow
    //     0xcb81ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb81f0: cmp             SP, x16
    //     0xcb81f4: b.ls            #0xcb82a8
    // 0xcb81f8: r1 = <int, (dynamic this, FFmpegSession) => void?>
    //     0xcb81f8: add             x1, PP, #0x40, lsl #12  ; [pp+0x40700] TypeArguments: <int, (dynamic this, FFmpegSession) => void?>
    //     0xcb81fc: ldr             x1, [x1, #0x700]
    // 0xcb8200: r0 = _Map()
    //     0xcb8200: bl              #0x4b4914  ; Allocate_MapStub -> _Map<X0, X1> (size=-0x8)
    // 0xcb8204: stur            x0, [fp, #-8]
    // 0xcb8208: SaveReg r0
    //     0xcb8208: str             x0, [SP, #-8]!
    // 0xcb820c: r0 = Shader._()
    //     0xcb820c: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0xcb8210: add             SP, SP, #8
    // 0xcb8214: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0xcb8214: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb8218: ldr             x0, [x0, #0x598]
    //     0xcb821c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb8220: cmp             w0, w16
    //     0xcb8224: b.ne            #0xcb8230
    //     0xcb8228: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0xcb822c: bl              #0xd67cdc
    // 0xcb8230: ldur            x1, [fp, #-8]
    // 0xcb8234: StoreField: r1->field_1b = r0
    //     0xcb8234: stur            w0, [x1, #0x1b]
    //     0xcb8238: ldurb           w16, [x1, #-1]
    //     0xcb823c: ldurb           w17, [x0, #-1]
    //     0xcb8240: and             x16, x17, x16, lsr #2
    //     0xcb8244: tst             x16, HEAP, lsr #32
    //     0xcb8248: b.eq            #0xcb8250
    //     0xcb824c: bl              #0xd6826c
    // 0xcb8250: StoreField: r1->field_b = rZR
    //     0xcb8250: stur            wzr, [x1, #0xb]
    // 0xcb8254: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0xcb8254: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb8258: ldr             x0, [x0, #0x5a0]
    //     0xcb825c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb8260: cmp             w0, w16
    //     0xcb8264: b.ne            #0xcb8270
    //     0xcb8268: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0xcb826c: bl              #0xd67cdc
    // 0xcb8270: ldur            x1, [fp, #-8]
    // 0xcb8274: StoreField: r1->field_f = r0
    //     0xcb8274: stur            w0, [x1, #0xf]
    //     0xcb8278: ldurb           w16, [x1, #-1]
    //     0xcb827c: ldurb           w17, [x0, #-1]
    //     0xcb8280: and             x16, x17, x16, lsr #2
    //     0xcb8284: tst             x16, HEAP, lsr #32
    //     0xcb8288: b.eq            #0xcb8290
    //     0xcb828c: bl              #0xd6826c
    // 0xcb8290: StoreField: r1->field_13 = rZR
    //     0xcb8290: stur            wzr, [x1, #0x13]
    // 0xcb8294: StoreField: r1->field_17 = rZR
    //     0xcb8294: stur            wzr, [x1, #0x17]
    // 0xcb8298: mov             x0, x1
    // 0xcb829c: LeaveFrame
    //     0xcb829c: mov             SP, fp
    //     0xcb82a0: ldp             fp, lr, [SP], #0x10
    // 0xcb82a4: ret
    //     0xcb82a4: ret             
    // 0xcb82a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb82a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb82ac: b               #0xcb81f8
  }
  static Map<int, (dynamic, MediaInformationSession) => void> mediaInformationSessionCompleteCallbackMap() {
    // ** addr: 0xcb8368, size: 0xd0
    // 0xcb8368: EnterFrame
    //     0xcb8368: stp             fp, lr, [SP, #-0x10]!
    //     0xcb836c: mov             fp, SP
    // 0xcb8370: AllocStack(0x8)
    //     0xcb8370: sub             SP, SP, #8
    // 0xcb8374: CheckStackOverflow
    //     0xcb8374: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb8378: cmp             SP, x16
    //     0xcb837c: b.ls            #0xcb8430
    // 0xcb8380: r1 = <int, (dynamic this, MediaInformationSession) => void?>
    //     0xcb8380: add             x1, PP, #0x40, lsl #12  ; [pp+0x40710] TypeArguments: <int, (dynamic this, MediaInformationSession) => void?>
    //     0xcb8384: ldr             x1, [x1, #0x710]
    // 0xcb8388: r0 = _Map()
    //     0xcb8388: bl              #0x4b4914  ; Allocate_MapStub -> _Map<X0, X1> (size=-0x8)
    // 0xcb838c: stur            x0, [fp, #-8]
    // 0xcb8390: SaveReg r0
    //     0xcb8390: str             x0, [SP, #-8]!
    // 0xcb8394: r0 = Shader._()
    //     0xcb8394: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0xcb8398: add             SP, SP, #8
    // 0xcb839c: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0xcb839c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb83a0: ldr             x0, [x0, #0x598]
    //     0xcb83a4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb83a8: cmp             w0, w16
    //     0xcb83ac: b.ne            #0xcb83b8
    //     0xcb83b0: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0xcb83b4: bl              #0xd67cdc
    // 0xcb83b8: ldur            x1, [fp, #-8]
    // 0xcb83bc: StoreField: r1->field_1b = r0
    //     0xcb83bc: stur            w0, [x1, #0x1b]
    //     0xcb83c0: ldurb           w16, [x1, #-1]
    //     0xcb83c4: ldurb           w17, [x0, #-1]
    //     0xcb83c8: and             x16, x17, x16, lsr #2
    //     0xcb83cc: tst             x16, HEAP, lsr #32
    //     0xcb83d0: b.eq            #0xcb83d8
    //     0xcb83d4: bl              #0xd6826c
    // 0xcb83d8: StoreField: r1->field_b = rZR
    //     0xcb83d8: stur            wzr, [x1, #0xb]
    // 0xcb83dc: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0xcb83dc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb83e0: ldr             x0, [x0, #0x5a0]
    //     0xcb83e4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb83e8: cmp             w0, w16
    //     0xcb83ec: b.ne            #0xcb83f8
    //     0xcb83f0: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0xcb83f4: bl              #0xd67cdc
    // 0xcb83f8: ldur            x1, [fp, #-8]
    // 0xcb83fc: StoreField: r1->field_f = r0
    //     0xcb83fc: stur            w0, [x1, #0xf]
    //     0xcb8400: ldurb           w16, [x1, #-1]
    //     0xcb8404: ldurb           w17, [x0, #-1]
    //     0xcb8408: and             x16, x17, x16, lsr #2
    //     0xcb840c: tst             x16, HEAP, lsr #32
    //     0xcb8410: b.eq            #0xcb8418
    //     0xcb8414: bl              #0xd6826c
    // 0xcb8418: StoreField: r1->field_13 = rZR
    //     0xcb8418: stur            wzr, [x1, #0x13]
    // 0xcb841c: StoreField: r1->field_17 = rZR
    //     0xcb841c: stur            wzr, [x1, #0x17]
    // 0xcb8420: mov             x0, x1
    // 0xcb8424: LeaveFrame
    //     0xcb8424: mov             SP, fp
    //     0xcb8428: ldp             fp, lr, [SP], #0x10
    // 0xcb842c: ret
    //     0xcb842c: ret             
    // 0xcb8430: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb8430: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb8434: b               #0xcb8380
  }
  static Map<int, (dynamic, FFprobeSession) => void> ffprobeSessionCompleteCallbackMap() {
    // ** addr: 0xcb84f0, size: 0xd0
    // 0xcb84f0: EnterFrame
    //     0xcb84f0: stp             fp, lr, [SP, #-0x10]!
    //     0xcb84f4: mov             fp, SP
    // 0xcb84f8: AllocStack(0x8)
    //     0xcb84f8: sub             SP, SP, #8
    // 0xcb84fc: CheckStackOverflow
    //     0xcb84fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb8500: cmp             SP, x16
    //     0xcb8504: b.ls            #0xcb85b8
    // 0xcb8508: r1 = <int, (dynamic this, FFprobeSession) => void?>
    //     0xcb8508: add             x1, PP, #0x40, lsl #12  ; [pp+0x40720] TypeArguments: <int, (dynamic this, FFprobeSession) => void?>
    //     0xcb850c: ldr             x1, [x1, #0x720]
    // 0xcb8510: r0 = _Map()
    //     0xcb8510: bl              #0x4b4914  ; Allocate_MapStub -> _Map<X0, X1> (size=-0x8)
    // 0xcb8514: stur            x0, [fp, #-8]
    // 0xcb8518: SaveReg r0
    //     0xcb8518: str             x0, [SP, #-8]!
    // 0xcb851c: r0 = Shader._()
    //     0xcb851c: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0xcb8520: add             SP, SP, #8
    // 0xcb8524: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0xcb8524: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb8528: ldr             x0, [x0, #0x598]
    //     0xcb852c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb8530: cmp             w0, w16
    //     0xcb8534: b.ne            #0xcb8540
    //     0xcb8538: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0xcb853c: bl              #0xd67cdc
    // 0xcb8540: ldur            x1, [fp, #-8]
    // 0xcb8544: StoreField: r1->field_1b = r0
    //     0xcb8544: stur            w0, [x1, #0x1b]
    //     0xcb8548: ldurb           w16, [x1, #-1]
    //     0xcb854c: ldurb           w17, [x0, #-1]
    //     0xcb8550: and             x16, x17, x16, lsr #2
    //     0xcb8554: tst             x16, HEAP, lsr #32
    //     0xcb8558: b.eq            #0xcb8560
    //     0xcb855c: bl              #0xd6826c
    // 0xcb8560: StoreField: r1->field_b = rZR
    //     0xcb8560: stur            wzr, [x1, #0xb]
    // 0xcb8564: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0xcb8564: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb8568: ldr             x0, [x0, #0x5a0]
    //     0xcb856c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb8570: cmp             w0, w16
    //     0xcb8574: b.ne            #0xcb8580
    //     0xcb8578: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0xcb857c: bl              #0xd67cdc
    // 0xcb8580: ldur            x1, [fp, #-8]
    // 0xcb8584: StoreField: r1->field_f = r0
    //     0xcb8584: stur            w0, [x1, #0xf]
    //     0xcb8588: ldurb           w16, [x1, #-1]
    //     0xcb858c: ldurb           w17, [x0, #-1]
    //     0xcb8590: and             x16, x17, x16, lsr #2
    //     0xcb8594: tst             x16, HEAP, lsr #32
    //     0xcb8598: b.eq            #0xcb85a0
    //     0xcb859c: bl              #0xd6826c
    // 0xcb85a0: StoreField: r1->field_13 = rZR
    //     0xcb85a0: stur            wzr, [x1, #0x13]
    // 0xcb85a4: StoreField: r1->field_17 = rZR
    //     0xcb85a4: stur            wzr, [x1, #0x17]
    // 0xcb85a8: mov             x0, x1
    // 0xcb85ac: LeaveFrame
    //     0xcb85ac: mov             SP, fp
    //     0xcb85b0: ldp             fp, lr, [SP], #0x10
    // 0xcb85b4: ret
    //     0xcb85b4: ret             
    // 0xcb85b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb85b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb85bc: b               #0xcb8508
  }
  static Map<int, (dynamic, Statistics) => void> statisticsCallbackMap() {
    // ** addr: 0xcb89c4, size: 0xd0
    // 0xcb89c4: EnterFrame
    //     0xcb89c4: stp             fp, lr, [SP, #-0x10]!
    //     0xcb89c8: mov             fp, SP
    // 0xcb89cc: AllocStack(0x8)
    //     0xcb89cc: sub             SP, SP, #8
    // 0xcb89d0: CheckStackOverflow
    //     0xcb89d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb89d4: cmp             SP, x16
    //     0xcb89d8: b.ls            #0xcb8a8c
    // 0xcb89dc: r1 = <int, (dynamic this, Statistics) => void?>
    //     0xcb89dc: add             x1, PP, #0x40, lsl #12  ; [pp+0x408c0] TypeArguments: <int, (dynamic this, Statistics) => void?>
    //     0xcb89e0: ldr             x1, [x1, #0x8c0]
    // 0xcb89e4: r0 = _Map()
    //     0xcb89e4: bl              #0x4b4914  ; Allocate_MapStub -> _Map<X0, X1> (size=-0x8)
    // 0xcb89e8: stur            x0, [fp, #-8]
    // 0xcb89ec: SaveReg r0
    //     0xcb89ec: str             x0, [SP, #-8]!
    // 0xcb89f0: r0 = Shader._()
    //     0xcb89f0: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0xcb89f4: add             SP, SP, #8
    // 0xcb89f8: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0xcb89f8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb89fc: ldr             x0, [x0, #0x598]
    //     0xcb8a00: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb8a04: cmp             w0, w16
    //     0xcb8a08: b.ne            #0xcb8a14
    //     0xcb8a0c: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0xcb8a10: bl              #0xd67cdc
    // 0xcb8a14: ldur            x1, [fp, #-8]
    // 0xcb8a18: StoreField: r1->field_1b = r0
    //     0xcb8a18: stur            w0, [x1, #0x1b]
    //     0xcb8a1c: ldurb           w16, [x1, #-1]
    //     0xcb8a20: ldurb           w17, [x0, #-1]
    //     0xcb8a24: and             x16, x17, x16, lsr #2
    //     0xcb8a28: tst             x16, HEAP, lsr #32
    //     0xcb8a2c: b.eq            #0xcb8a34
    //     0xcb8a30: bl              #0xd6826c
    // 0xcb8a34: StoreField: r1->field_b = rZR
    //     0xcb8a34: stur            wzr, [x1, #0xb]
    // 0xcb8a38: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0xcb8a38: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb8a3c: ldr             x0, [x0, #0x5a0]
    //     0xcb8a40: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb8a44: cmp             w0, w16
    //     0xcb8a48: b.ne            #0xcb8a54
    //     0xcb8a4c: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0xcb8a50: bl              #0xd67cdc
    // 0xcb8a54: ldur            x1, [fp, #-8]
    // 0xcb8a58: StoreField: r1->field_f = r0
    //     0xcb8a58: stur            w0, [x1, #0xf]
    //     0xcb8a5c: ldurb           w16, [x1, #-1]
    //     0xcb8a60: ldurb           w17, [x0, #-1]
    //     0xcb8a64: and             x16, x17, x16, lsr #2
    //     0xcb8a68: tst             x16, HEAP, lsr #32
    //     0xcb8a6c: b.eq            #0xcb8a74
    //     0xcb8a70: bl              #0xd6826c
    // 0xcb8a74: StoreField: r1->field_13 = rZR
    //     0xcb8a74: stur            wzr, [x1, #0x13]
    // 0xcb8a78: StoreField: r1->field_17 = rZR
    //     0xcb8a78: stur            wzr, [x1, #0x17]
    // 0xcb8a7c: mov             x0, x1
    // 0xcb8a80: LeaveFrame
    //     0xcb8a80: mov             SP, fp
    //     0xcb8a84: ldp             fp, lr, [SP], #0x10
    // 0xcb8a88: ret
    //     0xcb8a88: ret             
    // 0xcb8a8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb8a8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb8a90: b               #0xcb89dc
  }
  static Map<int, (dynamic, Log) => void> logCallbackMap() {
    // ** addr: 0xcb931c, size: 0xd0
    // 0xcb931c: EnterFrame
    //     0xcb931c: stp             fp, lr, [SP, #-0x10]!
    //     0xcb9320: mov             fp, SP
    // 0xcb9324: AllocStack(0x8)
    //     0xcb9324: sub             SP, SP, #8
    // 0xcb9328: CheckStackOverflow
    //     0xcb9328: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb932c: cmp             SP, x16
    //     0xcb9330: b.ls            #0xcb93e4
    // 0xcb9334: r1 = <int, (dynamic this, Log) => void?>
    //     0xcb9334: add             x1, PP, #0x40, lsl #12  ; [pp+0x409c8] TypeArguments: <int, (dynamic this, Log) => void?>
    //     0xcb9338: ldr             x1, [x1, #0x9c8]
    // 0xcb933c: r0 = _Map()
    //     0xcb933c: bl              #0x4b4914  ; Allocate_MapStub -> _Map<X0, X1> (size=-0x8)
    // 0xcb9340: stur            x0, [fp, #-8]
    // 0xcb9344: SaveReg r0
    //     0xcb9344: str             x0, [SP, #-8]!
    // 0xcb9348: r0 = Shader._()
    //     0xcb9348: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0xcb934c: add             SP, SP, #8
    // 0xcb9350: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0xcb9350: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb9354: ldr             x0, [x0, #0x598]
    //     0xcb9358: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb935c: cmp             w0, w16
    //     0xcb9360: b.ne            #0xcb936c
    //     0xcb9364: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0xcb9368: bl              #0xd67cdc
    // 0xcb936c: ldur            x1, [fp, #-8]
    // 0xcb9370: StoreField: r1->field_1b = r0
    //     0xcb9370: stur            w0, [x1, #0x1b]
    //     0xcb9374: ldurb           w16, [x1, #-1]
    //     0xcb9378: ldurb           w17, [x0, #-1]
    //     0xcb937c: and             x16, x17, x16, lsr #2
    //     0xcb9380: tst             x16, HEAP, lsr #32
    //     0xcb9384: b.eq            #0xcb938c
    //     0xcb9388: bl              #0xd6826c
    // 0xcb938c: StoreField: r1->field_b = rZR
    //     0xcb938c: stur            wzr, [x1, #0xb]
    // 0xcb9390: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0xcb9390: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb9394: ldr             x0, [x0, #0x5a0]
    //     0xcb9398: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb939c: cmp             w0, w16
    //     0xcb93a0: b.ne            #0xcb93ac
    //     0xcb93a4: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0xcb93a8: bl              #0xd67cdc
    // 0xcb93ac: ldur            x1, [fp, #-8]
    // 0xcb93b0: StoreField: r1->field_f = r0
    //     0xcb93b0: stur            w0, [x1, #0xf]
    //     0xcb93b4: ldurb           w16, [x1, #-1]
    //     0xcb93b8: ldurb           w17, [x0, #-1]
    //     0xcb93bc: and             x16, x17, x16, lsr #2
    //     0xcb93c0: tst             x16, HEAP, lsr #32
    //     0xcb93c4: b.eq            #0xcb93cc
    //     0xcb93c8: bl              #0xd6826c
    // 0xcb93cc: StoreField: r1->field_13 = rZR
    //     0xcb93cc: stur            wzr, [x1, #0x13]
    // 0xcb93d0: StoreField: r1->field_17 = rZR
    //     0xcb93d0: stur            wzr, [x1, #0x17]
    // 0xcb93d4: mov             x0, x1
    // 0xcb93d8: LeaveFrame
    //     0xcb93d8: mov             SP, fp
    //     0xcb93dc: ldp             fp, lr, [SP], #0x10
    // 0xcb93e0: ret
    //     0xcb93e0: ret             
    // 0xcb93e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb93e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb93e8: b               #0xcb9334
  }
}

// class id: 4410, size: 0x8, field offset: 0x8
abstract class FFmpegKitFactory extends Object {

  static _ validDate(/* No info */) {
    // ** addr: 0xa36958, size: 0x98
    // 0xa36958: EnterFrame
    //     0xa36958: stp             fp, lr, [SP, #-0x10]!
    //     0xa3695c: mov             fp, SP
    // 0xa36960: AllocStack(0x10)
    //     0xa36960: sub             SP, SP, #0x10
    // 0xa36964: CheckStackOverflow
    //     0xa36964: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa36968: cmp             SP, x16
    //     0xa3696c: b.ls            #0xa369e8
    // 0xa36970: ldr             x0, [fp, #0x10]
    // 0xa36974: cmp             w0, NULL
    // 0xa36978: b.eq            #0xa36990
    // 0xa3697c: r1 = LoadInt32Instr(r0)
    //     0xa3697c: sbfx            x1, x0, #1, #0x1f
    //     0xa36980: tbz             w0, #0, #0xa36988
    //     0xa36984: ldur            x1, [x0, #7]
    // 0xa36988: cmp             x1, #0
    // 0xa3698c: b.gt            #0xa369a0
    // 0xa36990: r0 = Null
    //     0xa36990: mov             x0, NULL
    // 0xa36994: LeaveFrame
    //     0xa36994: mov             SP, fp
    //     0xa36998: ldp             fp, lr, [SP], #0x10
    // 0xa3699c: ret
    //     0xa3699c: ret             
    // 0xa369a0: SaveReg r1
    //     0xa369a0: str             x1, [SP, #-8]!
    // 0xa369a4: r0 = _validateMilliseconds()
    //     0xa369a4: bl              #0x8f5234  ; [dart:core] DateTime::_validateMilliseconds
    // 0xa369a8: add             SP, SP, #8
    // 0xa369ac: r16 = 1000
    //     0xa369ac: mov             x16, #0x3e8
    // 0xa369b0: mul             x1, x0, x16
    // 0xa369b4: stur            x1, [fp, #-8]
    // 0xa369b8: r0 = DateTime()
    //     0xa369b8: bl              #0x5321bc  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0xa369bc: stur            x0, [fp, #-0x10]
    // 0xa369c0: SaveReg r0
    //     0xa369c0: str             x0, [SP, #-8]!
    // 0xa369c4: ldur            x1, [fp, #-8]
    // 0xa369c8: r16 = false
    //     0xa369c8: add             x16, NULL, #0x30  ; false
    // 0xa369cc: stp             x16, x1, [SP, #-0x10]!
    // 0xa369d0: r0 = DateTime._withValue()
    //     0xa369d0: bl              #0x53205c  ; [dart:core] DateTime::DateTime._withValue
    // 0xa369d4: add             SP, SP, #0x18
    // 0xa369d8: ldur            x0, [fp, #-0x10]
    // 0xa369dc: LeaveFrame
    //     0xa369dc: mov             SP, fp
    //     0xa369e0: ldp             fp, lr, [SP], #0x10
    // 0xa369e4: ret
    //     0xa369e4: ret             
    // 0xa369e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa369e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa369ec: b               #0xa36970
  }
  [closure] static Session? mapToNullableSession(dynamic, Map<dynamic, dynamic>?) {
    // ** addr: 0xcb721c, size: 0x38
    // 0xcb721c: EnterFrame
    //     0xcb721c: stp             fp, lr, [SP, #-0x10]!
    //     0xcb7220: mov             fp, SP
    // 0xcb7224: CheckStackOverflow
    //     0xcb7224: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb7228: cmp             SP, x16
    //     0xcb722c: b.ls            #0xcb724c
    // 0xcb7230: ldr             x16, [fp, #0x10]
    // 0xcb7234: SaveReg r16
    //     0xcb7234: str             x16, [SP, #-8]!
    // 0xcb7238: r0 = mapToNullableSession()
    //     0xcb7238: bl              #0xcb7254  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] FFmpegKitFactory::mapToNullableSession
    // 0xcb723c: add             SP, SP, #8
    // 0xcb7240: LeaveFrame
    //     0xcb7240: mov             SP, fp
    //     0xcb7244: ldp             fp, lr, [SP], #0x10
    // 0xcb7248: ret
    //     0xcb7248: ret             
    // 0xcb724c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb724c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb7250: b               #0xcb7230
  }
  static _ mapToNullableSession(/* No info */) {
    // ** addr: 0xcb7254, size: 0xe4
    // 0xcb7254: EnterFrame
    //     0xcb7254: stp             fp, lr, [SP, #-0x10]!
    //     0xcb7258: mov             fp, SP
    // 0xcb725c: CheckStackOverflow
    //     0xcb725c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb7260: cmp             SP, x16
    //     0xcb7264: b.ls            #0xcb7330
    // 0xcb7268: ldr             x1, [fp, #0x10]
    // 0xcb726c: cmp             w1, NULL
    // 0xcb7270: b.eq            #0xcb7320
    // 0xcb7274: r0 = LoadClassIdInstr(r1)
    //     0xcb7274: ldur            x0, [x1, #-1]
    //     0xcb7278: ubfx            x0, x0, #0xc, #0x14
    // 0xcb727c: r16 = "type"
    //     0xcb727c: ldr             x16, [PP, #0x1db8]  ; [pp+0x1db8] "type"
    // 0xcb7280: stp             x16, x1, [SP, #-0x10]!
    // 0xcb7284: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb7284: sub             lr, x0, #0xef
    //     0xcb7288: ldr             lr, [x21, lr, lsl #3]
    //     0xcb728c: blr             lr
    // 0xcb7290: add             SP, SP, #0x10
    // 0xcb7294: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xcb7294: mov             x1, #0x76
    //     0xcb7298: tbz             w0, #0, #0xcb72a8
    //     0xcb729c: ldur            x1, [x0, #-1]
    //     0xcb72a0: ubfx            x1, x1, #0xc, #0x14
    //     0xcb72a4: lsl             x1, x1, #1
    // 0xcb72a8: cmp             w1, #0x76
    // 0xcb72ac: b.ne            #0xcb7304
    // 0xcb72b0: r1 = LoadInt32Instr(r0)
    //     0xcb72b0: sbfx            x1, x0, #1, #0x1f
    // 0xcb72b4: cmp             x1, #2
    // 0xcb72b8: b.gt            #0xcb72e0
    // 0xcb72bc: cmp             x1, #1
    // 0xcb72c0: b.le            #0xcb7304
    // 0xcb72c4: ldr             x16, [fp, #0x10]
    // 0xcb72c8: SaveReg r16
    //     0xcb72c8: str             x16, [SP, #-8]!
    // 0xcb72cc: r0 = createFFprobeSessionFromMap()
    //     0xcb72cc: bl              #0xcb79b4  ; [package:ffmpeg_kit_flutter_min/abstract_session.dart] AbstractSession::createFFprobeSessionFromMap
    // 0xcb72d0: add             SP, SP, #8
    // 0xcb72d4: LeaveFrame
    //     0xcb72d4: mov             SP, fp
    //     0xcb72d8: ldp             fp, lr, [SP], #0x10
    // 0xcb72dc: ret
    //     0xcb72dc: ret             
    // 0xcb72e0: cmp             w0, #6
    // 0xcb72e4: b.ne            #0xcb7304
    // 0xcb72e8: ldr             x16, [fp, #0x10]
    // 0xcb72ec: SaveReg r16
    //     0xcb72ec: str             x16, [SP, #-8]!
    // 0xcb72f0: r0 = createMediaInformationSessionFromMap()
    //     0xcb72f0: bl              #0xcb76e4  ; [package:ffmpeg_kit_flutter_min/abstract_session.dart] AbstractSession::createMediaInformationSessionFromMap
    // 0xcb72f4: add             SP, SP, #8
    // 0xcb72f8: LeaveFrame
    //     0xcb72f8: mov             SP, fp
    //     0xcb72fc: ldp             fp, lr, [SP], #0x10
    // 0xcb7300: ret
    //     0xcb7300: ret             
    // 0xcb7304: ldr             x16, [fp, #0x10]
    // 0xcb7308: SaveReg r16
    //     0xcb7308: str             x16, [SP, #-8]!
    // 0xcb730c: r0 = createFFmpegSessionFromMap()
    //     0xcb730c: bl              #0xcb7338  ; [package:ffmpeg_kit_flutter_min/abstract_session.dart] AbstractSession::createFFmpegSessionFromMap
    // 0xcb7310: add             SP, SP, #8
    // 0xcb7314: LeaveFrame
    //     0xcb7314: mov             SP, fp
    //     0xcb7318: ldp             fp, lr, [SP], #0x10
    // 0xcb731c: ret
    //     0xcb731c: ret             
    // 0xcb7320: r0 = Null
    //     0xcb7320: mov             x0, NULL
    // 0xcb7324: LeaveFrame
    //     0xcb7324: mov             SP, fp
    //     0xcb7328: ldp             fp, lr, [SP], #0x10
    // 0xcb732c: ret
    //     0xcb732c: ret             
    // 0xcb7330: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb7330: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb7334: b               #0xcb7268
  }
  static _ getLogRedirectionStrategy(/* No info */) {
    // ** addr: 0xcb759c, size: 0x78
    // 0xcb759c: EnterFrame
    //     0xcb759c: stp             fp, lr, [SP, #-0x10]!
    //     0xcb75a0: mov             fp, SP
    // 0xcb75a4: AllocStack(0x8)
    //     0xcb75a4: sub             SP, SP, #8
    // 0xcb75a8: CheckStackOverflow
    //     0xcb75a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb75ac: cmp             SP, x16
    //     0xcb75b0: b.ls            #0xcb760c
    // 0xcb75b4: r0 = InitLateStaticField(0xc88) // [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] ::logRedirectionStrategyMap
    //     0xcb75b4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb75b8: ldr             x0, [x0, #0x1910]
    //     0xcb75bc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb75c0: cmp             w0, w16
    //     0xcb75c4: b.ne            #0xcb75d4
    //     0xcb75c8: add             x2, PP, #0x40, lsl #12  ; [pp+0x40798] Field <::.logRedirectionStrategyMap>: static late final (offset: 0xc88)
    //     0xcb75cc: ldr             x2, [x2, #0x798]
    //     0xcb75d0: bl              #0xd67cdc
    // 0xcb75d4: stur            x0, [fp, #-8]
    // 0xcb75d8: ldr             x16, [fp, #0x10]
    // 0xcb75dc: stp             x16, x0, [SP, #-0x10]!
    // 0xcb75e0: r0 = _getValueOrData()
    //     0xcb75e0: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xcb75e4: add             SP, SP, #0x10
    // 0xcb75e8: ldur            x1, [fp, #-8]
    // 0xcb75ec: LoadField: r2 = r1->field_f
    //     0xcb75ec: ldur            w2, [x1, #0xf]
    // 0xcb75f0: DecompressPointer r2
    //     0xcb75f0: add             x2, x2, HEAP, lsl #32
    // 0xcb75f4: cmp             w2, w0
    // 0xcb75f8: b.ne            #0xcb7600
    // 0xcb75fc: r0 = Null
    //     0xcb75fc: mov             x0, NULL
    // 0xcb7600: LeaveFrame
    //     0xcb7600: mov             SP, fp
    //     0xcb7604: ldp             fp, lr, [SP], #0x10
    // 0xcb7608: ret
    //     0xcb7608: ret             
    // 0xcb760c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb760c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb7610: b               #0xcb75b4
  }
  static _ getFFmpegSessionCompleteCallback(/* No info */) {
    // ** addr: 0xcb8168, size: 0x78
    // 0xcb8168: EnterFrame
    //     0xcb8168: stp             fp, lr, [SP, #-0x10]!
    //     0xcb816c: mov             fp, SP
    // 0xcb8170: AllocStack(0x8)
    //     0xcb8170: sub             SP, SP, #8
    // 0xcb8174: CheckStackOverflow
    //     0xcb8174: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb8178: cmp             SP, x16
    //     0xcb817c: b.ls            #0xcb81d8
    // 0xcb8180: r0 = InitLateStaticField(0xc74) // [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] ::ffmpegSessionCompleteCallbackMap
    //     0xcb8180: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb8184: ldr             x0, [x0, #0x18e8]
    //     0xcb8188: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb818c: cmp             w0, w16
    //     0xcb8190: b.ne            #0xcb81a0
    //     0xcb8194: add             x2, PP, #0x40, lsl #12  ; [pp+0x406f8] Field <::.ffmpegSessionCompleteCallbackMap>: static late final (offset: 0xc74)
    //     0xcb8198: ldr             x2, [x2, #0x6f8]
    //     0xcb819c: bl              #0xd67cdc
    // 0xcb81a0: stur            x0, [fp, #-8]
    // 0xcb81a4: ldr             x16, [fp, #0x10]
    // 0xcb81a8: stp             x16, x0, [SP, #-0x10]!
    // 0xcb81ac: r0 = _getValueOrData()
    //     0xcb81ac: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xcb81b0: add             SP, SP, #0x10
    // 0xcb81b4: ldur            x1, [fp, #-8]
    // 0xcb81b8: LoadField: r2 = r1->field_f
    //     0xcb81b8: ldur            w2, [x1, #0xf]
    // 0xcb81bc: DecompressPointer r2
    //     0xcb81bc: add             x2, x2, HEAP, lsl #32
    // 0xcb81c0: cmp             w2, w0
    // 0xcb81c4: b.ne            #0xcb81cc
    // 0xcb81c8: r0 = Null
    //     0xcb81c8: mov             x0, NULL
    // 0xcb81cc: LeaveFrame
    //     0xcb81cc: mov             SP, fp
    //     0xcb81d0: ldp             fp, lr, [SP], #0x10
    // 0xcb81d4: ret
    //     0xcb81d4: ret             
    // 0xcb81d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb81d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb81dc: b               #0xcb8180
  }
  static _ getMediaInformationSessionCompleteCallback(/* No info */) {
    // ** addr: 0xcb82f0, size: 0x78
    // 0xcb82f0: EnterFrame
    //     0xcb82f0: stp             fp, lr, [SP, #-0x10]!
    //     0xcb82f4: mov             fp, SP
    // 0xcb82f8: AllocStack(0x8)
    //     0xcb82f8: sub             SP, SP, #8
    // 0xcb82fc: CheckStackOverflow
    //     0xcb82fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb8300: cmp             SP, x16
    //     0xcb8304: b.ls            #0xcb8360
    // 0xcb8308: r0 = InitLateStaticField(0xc7c) // [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] ::mediaInformationSessionCompleteCallbackMap
    //     0xcb8308: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb830c: ldr             x0, [x0, #0x18f8]
    //     0xcb8310: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb8314: cmp             w0, w16
    //     0xcb8318: b.ne            #0xcb8328
    //     0xcb831c: add             x2, PP, #0x40, lsl #12  ; [pp+0x40708] Field <::.mediaInformationSessionCompleteCallbackMap>: static late final (offset: 0xc7c)
    //     0xcb8320: ldr             x2, [x2, #0x708]
    //     0xcb8324: bl              #0xd67cdc
    // 0xcb8328: stur            x0, [fp, #-8]
    // 0xcb832c: ldr             x16, [fp, #0x10]
    // 0xcb8330: stp             x16, x0, [SP, #-0x10]!
    // 0xcb8334: r0 = _getValueOrData()
    //     0xcb8334: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xcb8338: add             SP, SP, #0x10
    // 0xcb833c: ldur            x1, [fp, #-8]
    // 0xcb8340: LoadField: r2 = r1->field_f
    //     0xcb8340: ldur            w2, [x1, #0xf]
    // 0xcb8344: DecompressPointer r2
    //     0xcb8344: add             x2, x2, HEAP, lsl #32
    // 0xcb8348: cmp             w2, w0
    // 0xcb834c: b.ne            #0xcb8354
    // 0xcb8350: r0 = Null
    //     0xcb8350: mov             x0, NULL
    // 0xcb8354: LeaveFrame
    //     0xcb8354: mov             SP, fp
    //     0xcb8358: ldp             fp, lr, [SP], #0x10
    // 0xcb835c: ret
    //     0xcb835c: ret             
    // 0xcb8360: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb8360: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb8364: b               #0xcb8308
  }
  static _ getFFprobeSessionCompleteCallback(/* No info */) {
    // ** addr: 0xcb8478, size: 0x78
    // 0xcb8478: EnterFrame
    //     0xcb8478: stp             fp, lr, [SP, #-0x10]!
    //     0xcb847c: mov             fp, SP
    // 0xcb8480: AllocStack(0x8)
    //     0xcb8480: sub             SP, SP, #8
    // 0xcb8484: CheckStackOverflow
    //     0xcb8484: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb8488: cmp             SP, x16
    //     0xcb848c: b.ls            #0xcb84e8
    // 0xcb8490: r0 = InitLateStaticField(0xc78) // [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] ::ffprobeSessionCompleteCallbackMap
    //     0xcb8490: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb8494: ldr             x0, [x0, #0x18f0]
    //     0xcb8498: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb849c: cmp             w0, w16
    //     0xcb84a0: b.ne            #0xcb84b0
    //     0xcb84a4: add             x2, PP, #0x40, lsl #12  ; [pp+0x40718] Field <::.ffprobeSessionCompleteCallbackMap>: static late final (offset: 0xc78)
    //     0xcb84a8: ldr             x2, [x2, #0x718]
    //     0xcb84ac: bl              #0xd67cdc
    // 0xcb84b0: stur            x0, [fp, #-8]
    // 0xcb84b4: ldr             x16, [fp, #0x10]
    // 0xcb84b8: stp             x16, x0, [SP, #-0x10]!
    // 0xcb84bc: r0 = _getValueOrData()
    //     0xcb84bc: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xcb84c0: add             SP, SP, #0x10
    // 0xcb84c4: ldur            x1, [fp, #-8]
    // 0xcb84c8: LoadField: r2 = r1->field_f
    //     0xcb84c8: ldur            w2, [x1, #0xf]
    // 0xcb84cc: DecompressPointer r2
    //     0xcb84cc: add             x2, x2, HEAP, lsl #32
    // 0xcb84d0: cmp             w2, w0
    // 0xcb84d4: b.ne            #0xcb84dc
    // 0xcb84d8: r0 = Null
    //     0xcb84d8: mov             x0, NULL
    // 0xcb84dc: LeaveFrame
    //     0xcb84dc: mov             SP, fp
    //     0xcb84e0: ldp             fp, lr, [SP], #0x10
    // 0xcb84e4: ret
    //     0xcb84e4: ret             
    // 0xcb84e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb84e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb84ec: b               #0xcb8490
  }
  static _ getStatisticsCallback(/* No info */) {
    // ** addr: 0xcb8934, size: 0x90
    // 0xcb8934: EnterFrame
    //     0xcb8934: stp             fp, lr, [SP, #-0x10]!
    //     0xcb8938: mov             fp, SP
    // 0xcb893c: AllocStack(0x8)
    //     0xcb893c: sub             SP, SP, #8
    // 0xcb8940: CheckStackOverflow
    //     0xcb8940: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb8944: cmp             SP, x16
    //     0xcb8948: b.ls            #0xcb89bc
    // 0xcb894c: r0 = InitLateStaticField(0xc84) // [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] ::statisticsCallbackMap
    //     0xcb894c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb8950: ldr             x0, [x0, #0x1908]
    //     0xcb8954: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb8958: cmp             w0, w16
    //     0xcb895c: b.ne            #0xcb896c
    //     0xcb8960: add             x2, PP, #0x40, lsl #12  ; [pp+0x408b8] Field <::.statisticsCallbackMap>: static late final (offset: 0xc84)
    //     0xcb8964: ldr             x2, [x2, #0x8b8]
    //     0xcb8968: bl              #0xd67cdc
    // 0xcb896c: mov             x3, x0
    // 0xcb8970: ldr             x2, [fp, #0x10]
    // 0xcb8974: stur            x3, [fp, #-8]
    // 0xcb8978: r0 = BoxInt64Instr(r2)
    //     0xcb8978: sbfiz           x0, x2, #1, #0x1f
    //     0xcb897c: cmp             x2, x0, asr #1
    //     0xcb8980: b.eq            #0xcb898c
    //     0xcb8984: bl              #0xd69bb8
    //     0xcb8988: stur            x2, [x0, #7]
    // 0xcb898c: stp             x0, x3, [SP, #-0x10]!
    // 0xcb8990: r0 = _getValueOrData()
    //     0xcb8990: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xcb8994: add             SP, SP, #0x10
    // 0xcb8998: ldur            x1, [fp, #-8]
    // 0xcb899c: LoadField: r2 = r1->field_f
    //     0xcb899c: ldur            w2, [x1, #0xf]
    // 0xcb89a0: DecompressPointer r2
    //     0xcb89a0: add             x2, x2, HEAP, lsl #32
    // 0xcb89a4: cmp             w2, w0
    // 0xcb89a8: b.ne            #0xcb89b0
    // 0xcb89ac: r0 = Null
    //     0xcb89ac: mov             x0, NULL
    // 0xcb89b0: LeaveFrame
    //     0xcb89b0: mov             SP, fp
    //     0xcb89b4: ldp             fp, lr, [SP], #0x10
    // 0xcb89b8: ret
    //     0xcb89b8: ret             
    // 0xcb89bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb89bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb89c0: b               #0xcb894c
  }
  static _ mapToStatistics(/* No info */) {
    // ** addr: 0xcb8a94, size: 0x318
    // 0xcb8a94: EnterFrame
    //     0xcb8a94: stp             fp, lr, [SP, #-0x10]!
    //     0xcb8a98: mov             fp, SP
    // 0xcb8a9c: AllocStack(0x10)
    //     0xcb8a9c: sub             SP, SP, #0x10
    // 0xcb8aa0: CheckStackOverflow
    //     0xcb8aa0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb8aa4: cmp             SP, x16
    //     0xcb8aa8: b.ls            #0xcb8da4
    // 0xcb8aac: ldr             x1, [fp, #0x10]
    // 0xcb8ab0: r0 = LoadClassIdInstr(r1)
    //     0xcb8ab0: ldur            x0, [x1, #-1]
    //     0xcb8ab4: ubfx            x0, x0, #0xc, #0x14
    // 0xcb8ab8: r16 = "sessionId"
    //     0xcb8ab8: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2fd10] "sessionId"
    //     0xcb8abc: ldr             x16, [x16, #0xd10]
    // 0xcb8ac0: stp             x16, x1, [SP, #-0x10]!
    // 0xcb8ac4: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb8ac4: sub             lr, x0, #0xef
    //     0xcb8ac8: ldr             lr, [x21, lr, lsl #3]
    //     0xcb8acc: blr             lr
    // 0xcb8ad0: add             SP, SP, #0x10
    // 0xcb8ad4: mov             x3, x0
    // 0xcb8ad8: r2 = Null
    //     0xcb8ad8: mov             x2, NULL
    // 0xcb8adc: r1 = Null
    //     0xcb8adc: mov             x1, NULL
    // 0xcb8ae0: stur            x3, [fp, #-8]
    // 0xcb8ae4: branchIfSmi(r0, 0xcb8b0c)
    //     0xcb8ae4: tbz             w0, #0, #0xcb8b0c
    // 0xcb8ae8: r4 = LoadClassIdInstr(r0)
    //     0xcb8ae8: ldur            x4, [x0, #-1]
    //     0xcb8aec: ubfx            x4, x4, #0xc, #0x14
    // 0xcb8af0: sub             x4, x4, #0x3b
    // 0xcb8af4: cmp             x4, #1
    // 0xcb8af8: b.ls            #0xcb8b0c
    // 0xcb8afc: r8 = int
    //     0xcb8afc: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xcb8b00: r3 = Null
    //     0xcb8b00: add             x3, PP, #0x40, lsl #12  ; [pp+0x408c8] Null
    //     0xcb8b04: ldr             x3, [x3, #0x8c8]
    // 0xcb8b08: r0 = int()
    //     0xcb8b08: bl              #0xd73714  ; IsType_int_Stub
    // 0xcb8b0c: ldr             x1, [fp, #0x10]
    // 0xcb8b10: r0 = LoadClassIdInstr(r1)
    //     0xcb8b10: ldur            x0, [x1, #-1]
    //     0xcb8b14: ubfx            x0, x0, #0xc, #0x14
    // 0xcb8b18: r16 = "videoFrameNumber"
    //     0xcb8b18: add             x16, PP, #0x40, lsl #12  ; [pp+0x408d8] "videoFrameNumber"
    //     0xcb8b1c: ldr             x16, [x16, #0x8d8]
    // 0xcb8b20: stp             x16, x1, [SP, #-0x10]!
    // 0xcb8b24: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb8b24: sub             lr, x0, #0xef
    //     0xcb8b28: ldr             lr, [x21, lr, lsl #3]
    //     0xcb8b2c: blr             lr
    // 0xcb8b30: add             SP, SP, #0x10
    // 0xcb8b34: r2 = Null
    //     0xcb8b34: mov             x2, NULL
    // 0xcb8b38: r1 = Null
    //     0xcb8b38: mov             x1, NULL
    // 0xcb8b3c: branchIfSmi(r0, 0xcb8b64)
    //     0xcb8b3c: tbz             w0, #0, #0xcb8b64
    // 0xcb8b40: r4 = LoadClassIdInstr(r0)
    //     0xcb8b40: ldur            x4, [x0, #-1]
    //     0xcb8b44: ubfx            x4, x4, #0xc, #0x14
    // 0xcb8b48: sub             x4, x4, #0x3b
    // 0xcb8b4c: cmp             x4, #1
    // 0xcb8b50: b.ls            #0xcb8b64
    // 0xcb8b54: r8 = int
    //     0xcb8b54: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xcb8b58: r3 = Null
    //     0xcb8b58: add             x3, PP, #0x40, lsl #12  ; [pp+0x408e0] Null
    //     0xcb8b5c: ldr             x3, [x3, #0x8e0]
    // 0xcb8b60: r0 = int()
    //     0xcb8b60: bl              #0xd73714  ; IsType_int_Stub
    // 0xcb8b64: ldr             x1, [fp, #0x10]
    // 0xcb8b68: r0 = LoadClassIdInstr(r1)
    //     0xcb8b68: ldur            x0, [x1, #-1]
    //     0xcb8b6c: ubfx            x0, x0, #0xc, #0x14
    // 0xcb8b70: r16 = "videoFps"
    //     0xcb8b70: add             x16, PP, #0x40, lsl #12  ; [pp+0x408f0] "videoFps"
    //     0xcb8b74: ldr             x16, [x16, #0x8f0]
    // 0xcb8b78: stp             x16, x1, [SP, #-0x10]!
    // 0xcb8b7c: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb8b7c: sub             lr, x0, #0xef
    //     0xcb8b80: ldr             lr, [x21, lr, lsl #3]
    //     0xcb8b84: blr             lr
    // 0xcb8b88: add             SP, SP, #0x10
    // 0xcb8b8c: r2 = Null
    //     0xcb8b8c: mov             x2, NULL
    // 0xcb8b90: r1 = Null
    //     0xcb8b90: mov             x1, NULL
    // 0xcb8b94: r4 = 59
    //     0xcb8b94: mov             x4, #0x3b
    // 0xcb8b98: branchIfSmi(r0, 0xcb8ba4)
    //     0xcb8b98: tbz             w0, #0, #0xcb8ba4
    // 0xcb8b9c: r4 = LoadClassIdInstr(r0)
    //     0xcb8b9c: ldur            x4, [x0, #-1]
    //     0xcb8ba0: ubfx            x4, x4, #0xc, #0x14
    // 0xcb8ba4: cmp             x4, #0x3d
    // 0xcb8ba8: b.eq            #0xcb8bbc
    // 0xcb8bac: r8 = double
    //     0xcb8bac: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0xcb8bb0: r3 = Null
    //     0xcb8bb0: add             x3, PP, #0x40, lsl #12  ; [pp+0x408f8] Null
    //     0xcb8bb4: ldr             x3, [x3, #0x8f8]
    // 0xcb8bb8: r0 = double()
    //     0xcb8bb8: bl              #0xd72bac  ; IsType_double_Stub
    // 0xcb8bbc: ldr             x1, [fp, #0x10]
    // 0xcb8bc0: r0 = LoadClassIdInstr(r1)
    //     0xcb8bc0: ldur            x0, [x1, #-1]
    //     0xcb8bc4: ubfx            x0, x0, #0xc, #0x14
    // 0xcb8bc8: r16 = "videoQuality"
    //     0xcb8bc8: add             x16, PP, #0x40, lsl #12  ; [pp+0x40908] "videoQuality"
    //     0xcb8bcc: ldr             x16, [x16, #0x908]
    // 0xcb8bd0: stp             x16, x1, [SP, #-0x10]!
    // 0xcb8bd4: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb8bd4: sub             lr, x0, #0xef
    //     0xcb8bd8: ldr             lr, [x21, lr, lsl #3]
    //     0xcb8bdc: blr             lr
    // 0xcb8be0: add             SP, SP, #0x10
    // 0xcb8be4: r2 = Null
    //     0xcb8be4: mov             x2, NULL
    // 0xcb8be8: r1 = Null
    //     0xcb8be8: mov             x1, NULL
    // 0xcb8bec: r4 = 59
    //     0xcb8bec: mov             x4, #0x3b
    // 0xcb8bf0: branchIfSmi(r0, 0xcb8bfc)
    //     0xcb8bf0: tbz             w0, #0, #0xcb8bfc
    // 0xcb8bf4: r4 = LoadClassIdInstr(r0)
    //     0xcb8bf4: ldur            x4, [x0, #-1]
    //     0xcb8bf8: ubfx            x4, x4, #0xc, #0x14
    // 0xcb8bfc: cmp             x4, #0x3d
    // 0xcb8c00: b.eq            #0xcb8c14
    // 0xcb8c04: r8 = double
    //     0xcb8c04: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0xcb8c08: r3 = Null
    //     0xcb8c08: add             x3, PP, #0x40, lsl #12  ; [pp+0x40910] Null
    //     0xcb8c0c: ldr             x3, [x3, #0x910]
    // 0xcb8c10: r0 = double()
    //     0xcb8c10: bl              #0xd72bac  ; IsType_double_Stub
    // 0xcb8c14: ldr             x1, [fp, #0x10]
    // 0xcb8c18: r0 = LoadClassIdInstr(r1)
    //     0xcb8c18: ldur            x0, [x1, #-1]
    //     0xcb8c1c: ubfx            x0, x0, #0xc, #0x14
    // 0xcb8c20: r16 = "size"
    //     0xcb8c20: add             x16, PP, #0x14, lsl #12  ; [pp+0x14fc0] "size"
    //     0xcb8c24: ldr             x16, [x16, #0xfc0]
    // 0xcb8c28: stp             x16, x1, [SP, #-0x10]!
    // 0xcb8c2c: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb8c2c: sub             lr, x0, #0xef
    //     0xcb8c30: ldr             lr, [x21, lr, lsl #3]
    //     0xcb8c34: blr             lr
    // 0xcb8c38: add             SP, SP, #0x10
    // 0xcb8c3c: r2 = Null
    //     0xcb8c3c: mov             x2, NULL
    // 0xcb8c40: r1 = Null
    //     0xcb8c40: mov             x1, NULL
    // 0xcb8c44: branchIfSmi(r0, 0xcb8c6c)
    //     0xcb8c44: tbz             w0, #0, #0xcb8c6c
    // 0xcb8c48: r4 = LoadClassIdInstr(r0)
    //     0xcb8c48: ldur            x4, [x0, #-1]
    //     0xcb8c4c: ubfx            x4, x4, #0xc, #0x14
    // 0xcb8c50: sub             x4, x4, #0x3b
    // 0xcb8c54: cmp             x4, #1
    // 0xcb8c58: b.ls            #0xcb8c6c
    // 0xcb8c5c: r8 = int
    //     0xcb8c5c: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xcb8c60: r3 = Null
    //     0xcb8c60: add             x3, PP, #0x40, lsl #12  ; [pp+0x40920] Null
    //     0xcb8c64: ldr             x3, [x3, #0x920]
    // 0xcb8c68: r0 = int()
    //     0xcb8c68: bl              #0xd73714  ; IsType_int_Stub
    // 0xcb8c6c: ldr             x1, [fp, #0x10]
    // 0xcb8c70: r0 = LoadClassIdInstr(r1)
    //     0xcb8c70: ldur            x0, [x1, #-1]
    //     0xcb8c74: ubfx            x0, x0, #0xc, #0x14
    // 0xcb8c78: r16 = "time"
    //     0xcb8c78: add             x16, PP, #0x14, lsl #12  ; [pp+0x14758] "time"
    //     0xcb8c7c: ldr             x16, [x16, #0x758]
    // 0xcb8c80: stp             x16, x1, [SP, #-0x10]!
    // 0xcb8c84: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb8c84: sub             lr, x0, #0xef
    //     0xcb8c88: ldr             lr, [x21, lr, lsl #3]
    //     0xcb8c8c: blr             lr
    // 0xcb8c90: add             SP, SP, #0x10
    // 0xcb8c94: r2 = Null
    //     0xcb8c94: mov             x2, NULL
    // 0xcb8c98: r1 = Null
    //     0xcb8c98: mov             x1, NULL
    // 0xcb8c9c: branchIfSmi(r0, 0xcb8cc4)
    //     0xcb8c9c: tbz             w0, #0, #0xcb8cc4
    // 0xcb8ca0: r4 = LoadClassIdInstr(r0)
    //     0xcb8ca0: ldur            x4, [x0, #-1]
    //     0xcb8ca4: ubfx            x4, x4, #0xc, #0x14
    // 0xcb8ca8: sub             x4, x4, #0x3b
    // 0xcb8cac: cmp             x4, #1
    // 0xcb8cb0: b.ls            #0xcb8cc4
    // 0xcb8cb4: r8 = int
    //     0xcb8cb4: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xcb8cb8: r3 = Null
    //     0xcb8cb8: add             x3, PP, #0x40, lsl #12  ; [pp+0x40930] Null
    //     0xcb8cbc: ldr             x3, [x3, #0x930]
    // 0xcb8cc0: r0 = int()
    //     0xcb8cc0: bl              #0xd73714  ; IsType_int_Stub
    // 0xcb8cc4: ldr             x1, [fp, #0x10]
    // 0xcb8cc8: r0 = LoadClassIdInstr(r1)
    //     0xcb8cc8: ldur            x0, [x1, #-1]
    //     0xcb8ccc: ubfx            x0, x0, #0xc, #0x14
    // 0xcb8cd0: r16 = "bitrate"
    //     0xcb8cd0: add             x16, PP, #0x40, lsl #12  ; [pp+0x40940] "bitrate"
    //     0xcb8cd4: ldr             x16, [x16, #0x940]
    // 0xcb8cd8: stp             x16, x1, [SP, #-0x10]!
    // 0xcb8cdc: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb8cdc: sub             lr, x0, #0xef
    //     0xcb8ce0: ldr             lr, [x21, lr, lsl #3]
    //     0xcb8ce4: blr             lr
    // 0xcb8ce8: add             SP, SP, #0x10
    // 0xcb8cec: r2 = Null
    //     0xcb8cec: mov             x2, NULL
    // 0xcb8cf0: r1 = Null
    //     0xcb8cf0: mov             x1, NULL
    // 0xcb8cf4: r4 = 59
    //     0xcb8cf4: mov             x4, #0x3b
    // 0xcb8cf8: branchIfSmi(r0, 0xcb8d04)
    //     0xcb8cf8: tbz             w0, #0, #0xcb8d04
    // 0xcb8cfc: r4 = LoadClassIdInstr(r0)
    //     0xcb8cfc: ldur            x4, [x0, #-1]
    //     0xcb8d00: ubfx            x4, x4, #0xc, #0x14
    // 0xcb8d04: cmp             x4, #0x3d
    // 0xcb8d08: b.eq            #0xcb8d1c
    // 0xcb8d0c: r8 = double
    //     0xcb8d0c: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0xcb8d10: r3 = Null
    //     0xcb8d10: add             x3, PP, #0x40, lsl #12  ; [pp+0x40948] Null
    //     0xcb8d14: ldr             x3, [x3, #0x948]
    // 0xcb8d18: r0 = double()
    //     0xcb8d18: bl              #0xd72bac  ; IsType_double_Stub
    // 0xcb8d1c: ldr             x0, [fp, #0x10]
    // 0xcb8d20: r1 = LoadClassIdInstr(r0)
    //     0xcb8d20: ldur            x1, [x0, #-1]
    //     0xcb8d24: ubfx            x1, x1, #0xc, #0x14
    // 0xcb8d28: r16 = "speed"
    //     0xcb8d28: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1ff90] "speed"
    //     0xcb8d2c: ldr             x16, [x16, #0xf90]
    // 0xcb8d30: stp             x16, x0, [SP, #-0x10]!
    // 0xcb8d34: mov             x0, x1
    // 0xcb8d38: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb8d38: sub             lr, x0, #0xef
    //     0xcb8d3c: ldr             lr, [x21, lr, lsl #3]
    //     0xcb8d40: blr             lr
    // 0xcb8d44: add             SP, SP, #0x10
    // 0xcb8d48: r2 = Null
    //     0xcb8d48: mov             x2, NULL
    // 0xcb8d4c: r1 = Null
    //     0xcb8d4c: mov             x1, NULL
    // 0xcb8d50: r4 = 59
    //     0xcb8d50: mov             x4, #0x3b
    // 0xcb8d54: branchIfSmi(r0, 0xcb8d60)
    //     0xcb8d54: tbz             w0, #0, #0xcb8d60
    // 0xcb8d58: r4 = LoadClassIdInstr(r0)
    //     0xcb8d58: ldur            x4, [x0, #-1]
    //     0xcb8d5c: ubfx            x4, x4, #0xc, #0x14
    // 0xcb8d60: cmp             x4, #0x3d
    // 0xcb8d64: b.eq            #0xcb8d78
    // 0xcb8d68: r8 = double
    //     0xcb8d68: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0xcb8d6c: r3 = Null
    //     0xcb8d6c: add             x3, PP, #0x40, lsl #12  ; [pp+0x40958] Null
    //     0xcb8d70: ldr             x3, [x3, #0x958]
    // 0xcb8d74: r0 = double()
    //     0xcb8d74: bl              #0xd72bac  ; IsType_double_Stub
    // 0xcb8d78: ldur            x0, [fp, #-8]
    // 0xcb8d7c: r1 = LoadInt32Instr(r0)
    //     0xcb8d7c: sbfx            x1, x0, #1, #0x1f
    //     0xcb8d80: tbz             w0, #0, #0xcb8d88
    //     0xcb8d84: ldur            x1, [x0, #7]
    // 0xcb8d88: stur            x1, [fp, #-0x10]
    // 0xcb8d8c: r0 = Statistics()
    //     0xcb8d8c: bl              #0xcb8dac  ; AllocateStatisticsStub -> Statistics (size=0x10)
    // 0xcb8d90: ldur            x1, [fp, #-0x10]
    // 0xcb8d94: StoreField: r0->field_7 = r1
    //     0xcb8d94: stur            x1, [x0, #7]
    // 0xcb8d98: LeaveFrame
    //     0xcb8d98: mov             SP, fp
    //     0xcb8d9c: ldp             fp, lr, [SP], #0x10
    // 0xcb8da0: ret
    //     0xcb8da0: ret             
    // 0xcb8da4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb8da4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb8da8: b               #0xcb8aac
  }
  static _ getLogCallback(/* No info */) {
    // ** addr: 0xcb928c, size: 0x90
    // 0xcb928c: EnterFrame
    //     0xcb928c: stp             fp, lr, [SP, #-0x10]!
    //     0xcb9290: mov             fp, SP
    // 0xcb9294: AllocStack(0x8)
    //     0xcb9294: sub             SP, SP, #8
    // 0xcb9298: CheckStackOverflow
    //     0xcb9298: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb929c: cmp             SP, x16
    //     0xcb92a0: b.ls            #0xcb9314
    // 0xcb92a4: r0 = InitLateStaticField(0xc80) // [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] ::logCallbackMap
    //     0xcb92a4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb92a8: ldr             x0, [x0, #0x1900]
    //     0xcb92ac: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb92b0: cmp             w0, w16
    //     0xcb92b4: b.ne            #0xcb92c4
    //     0xcb92b8: add             x2, PP, #0x40, lsl #12  ; [pp+0x409c0] Field <::.logCallbackMap>: static late final (offset: 0xc80)
    //     0xcb92bc: ldr             x2, [x2, #0x9c0]
    //     0xcb92c0: bl              #0xd67cdc
    // 0xcb92c4: mov             x3, x0
    // 0xcb92c8: ldr             x2, [fp, #0x10]
    // 0xcb92cc: stur            x3, [fp, #-8]
    // 0xcb92d0: r0 = BoxInt64Instr(r2)
    //     0xcb92d0: sbfiz           x0, x2, #1, #0x1f
    //     0xcb92d4: cmp             x2, x0, asr #1
    //     0xcb92d8: b.eq            #0xcb92e4
    //     0xcb92dc: bl              #0xd69bb8
    //     0xcb92e0: stur            x2, [x0, #7]
    // 0xcb92e4: stp             x0, x3, [SP, #-0x10]!
    // 0xcb92e8: r0 = _getValueOrData()
    //     0xcb92e8: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xcb92ec: add             SP, SP, #0x10
    // 0xcb92f0: ldur            x1, [fp, #-8]
    // 0xcb92f4: LoadField: r2 = r1->field_f
    //     0xcb92f4: ldur            w2, [x1, #0xf]
    // 0xcb92f8: DecompressPointer r2
    //     0xcb92f8: add             x2, x2, HEAP, lsl #32
    // 0xcb92fc: cmp             w2, w0
    // 0xcb9300: b.ne            #0xcb9308
    // 0xcb9304: r0 = Null
    //     0xcb9304: mov             x0, NULL
    // 0xcb9308: LeaveFrame
    //     0xcb9308: mov             SP, fp
    //     0xcb930c: ldp             fp, lr, [SP], #0x10
    // 0xcb9310: ret
    //     0xcb9310: ret             
    // 0xcb9314: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb9314: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb9318: b               #0xcb92a4
  }
  static _ mapToLog(/* No info */) {
    // ** addr: 0xcb93ec, size: 0x14c
    // 0xcb93ec: EnterFrame
    //     0xcb93ec: stp             fp, lr, [SP, #-0x10]!
    //     0xcb93f0: mov             fp, SP
    // 0xcb93f4: AllocStack(0x8)
    //     0xcb93f4: sub             SP, SP, #8
    // 0xcb93f8: CheckStackOverflow
    //     0xcb93f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb93fc: cmp             SP, x16
    //     0xcb9400: b.ls            #0xcb9530
    // 0xcb9404: ldr             x1, [fp, #0x10]
    // 0xcb9408: r0 = LoadClassIdInstr(r1)
    //     0xcb9408: ldur            x0, [x1, #-1]
    //     0xcb940c: ubfx            x0, x0, #0xc, #0x14
    // 0xcb9410: r16 = "sessionId"
    //     0xcb9410: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2fd10] "sessionId"
    //     0xcb9414: ldr             x16, [x16, #0xd10]
    // 0xcb9418: stp             x16, x1, [SP, #-0x10]!
    // 0xcb941c: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb941c: sub             lr, x0, #0xef
    //     0xcb9420: ldr             lr, [x21, lr, lsl #3]
    //     0xcb9424: blr             lr
    // 0xcb9428: add             SP, SP, #0x10
    // 0xcb942c: r2 = Null
    //     0xcb942c: mov             x2, NULL
    // 0xcb9430: r1 = Null
    //     0xcb9430: mov             x1, NULL
    // 0xcb9434: branchIfSmi(r0, 0xcb945c)
    //     0xcb9434: tbz             w0, #0, #0xcb945c
    // 0xcb9438: r4 = LoadClassIdInstr(r0)
    //     0xcb9438: ldur            x4, [x0, #-1]
    //     0xcb943c: ubfx            x4, x4, #0xc, #0x14
    // 0xcb9440: sub             x4, x4, #0x3b
    // 0xcb9444: cmp             x4, #1
    // 0xcb9448: b.ls            #0xcb945c
    // 0xcb944c: r8 = int
    //     0xcb944c: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xcb9450: r3 = Null
    //     0xcb9450: add             x3, PP, #0x40, lsl #12  ; [pp+0x409d0] Null
    //     0xcb9454: ldr             x3, [x3, #0x9d0]
    // 0xcb9458: r0 = int()
    //     0xcb9458: bl              #0xd73714  ; IsType_int_Stub
    // 0xcb945c: ldr             x1, [fp, #0x10]
    // 0xcb9460: r0 = LoadClassIdInstr(r1)
    //     0xcb9460: ldur            x0, [x1, #-1]
    //     0xcb9464: ubfx            x0, x0, #0xc, #0x14
    // 0xcb9468: r16 = "level"
    //     0xcb9468: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2fe18] "level"
    //     0xcb946c: ldr             x16, [x16, #0xe18]
    // 0xcb9470: stp             x16, x1, [SP, #-0x10]!
    // 0xcb9474: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb9474: sub             lr, x0, #0xef
    //     0xcb9478: ldr             lr, [x21, lr, lsl #3]
    //     0xcb947c: blr             lr
    // 0xcb9480: add             SP, SP, #0x10
    // 0xcb9484: r2 = Null
    //     0xcb9484: mov             x2, NULL
    // 0xcb9488: r1 = Null
    //     0xcb9488: mov             x1, NULL
    // 0xcb948c: branchIfSmi(r0, 0xcb94b4)
    //     0xcb948c: tbz             w0, #0, #0xcb94b4
    // 0xcb9490: r4 = LoadClassIdInstr(r0)
    //     0xcb9490: ldur            x4, [x0, #-1]
    //     0xcb9494: ubfx            x4, x4, #0xc, #0x14
    // 0xcb9498: sub             x4, x4, #0x3b
    // 0xcb949c: cmp             x4, #1
    // 0xcb94a0: b.ls            #0xcb94b4
    // 0xcb94a4: r8 = int
    //     0xcb94a4: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xcb94a8: r3 = Null
    //     0xcb94a8: add             x3, PP, #0x40, lsl #12  ; [pp+0x409e0] Null
    //     0xcb94ac: ldr             x3, [x3, #0x9e0]
    // 0xcb94b0: r0 = int()
    //     0xcb94b0: bl              #0xd73714  ; IsType_int_Stub
    // 0xcb94b4: ldr             x0, [fp, #0x10]
    // 0xcb94b8: r1 = LoadClassIdInstr(r0)
    //     0xcb94b8: ldur            x1, [x0, #-1]
    //     0xcb94bc: ubfx            x1, x1, #0xc, #0x14
    // 0xcb94c0: r16 = "message"
    //     0xcb94c0: ldr             x16, [PP, #0x62c8]  ; [pp+0x62c8] "message"
    // 0xcb94c4: stp             x16, x0, [SP, #-0x10]!
    // 0xcb94c8: mov             x0, x1
    // 0xcb94cc: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb94cc: sub             lr, x0, #0xef
    //     0xcb94d0: ldr             lr, [x21, lr, lsl #3]
    //     0xcb94d4: blr             lr
    // 0xcb94d8: add             SP, SP, #0x10
    // 0xcb94dc: mov             x3, x0
    // 0xcb94e0: r2 = Null
    //     0xcb94e0: mov             x2, NULL
    // 0xcb94e4: r1 = Null
    //     0xcb94e4: mov             x1, NULL
    // 0xcb94e8: stur            x3, [fp, #-8]
    // 0xcb94ec: r4 = 59
    //     0xcb94ec: mov             x4, #0x3b
    // 0xcb94f0: branchIfSmi(r0, 0xcb94fc)
    //     0xcb94f0: tbz             w0, #0, #0xcb94fc
    // 0xcb94f4: r4 = LoadClassIdInstr(r0)
    //     0xcb94f4: ldur            x4, [x0, #-1]
    //     0xcb94f8: ubfx            x4, x4, #0xc, #0x14
    // 0xcb94fc: sub             x4, x4, #0x5d
    // 0xcb9500: cmp             x4, #3
    // 0xcb9504: b.ls            #0xcb9518
    // 0xcb9508: r8 = String
    //     0xcb9508: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xcb950c: r3 = Null
    //     0xcb950c: add             x3, PP, #0x40, lsl #12  ; [pp+0x409f0] Null
    //     0xcb9510: ldr             x3, [x3, #0x9f0]
    // 0xcb9514: r0 = String()
    //     0xcb9514: bl              #0xd72afc  ; IsType_String_Stub
    // 0xcb9518: r0 = Log()
    //     0xcb9518: bl              #0xcb9538  ; AllocateLogStub -> Log (size=0xc)
    // 0xcb951c: ldur            x1, [fp, #-8]
    // 0xcb9520: StoreField: r0->field_7 = r1
    //     0xcb9520: stur            w1, [x0, #7]
    // 0xcb9524: LeaveFrame
    //     0xcb9524: mov             SP, fp
    //     0xcb9528: ldp             fp, lr, [SP], #0x10
    // 0xcb952c: ret
    //     0xcb952c: ret             
    // 0xcb9530: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb9530: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb9534: b               #0xcb9404
  }
}

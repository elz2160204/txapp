// lib: , url: package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_flutter_initializer.dart

// class id: 1049019, size: 0x8
class :: {
}

// class id: 4409, size: 0x8, field offset: 0x8
class FFmpegKitInitializer extends Object {

  static late FFmpegKitInitializer _instance; // offset: 0xc98
  static late FFmpegKitPlatform _platform; // offset: 0xc94

  static _ initialize(/* No info */) async {
    // ** addr: 0xa355f0, size: 0x88
    // 0xa355f0: EnterFrame
    //     0xa355f0: stp             fp, lr, [SP, #-0x10]!
    //     0xa355f4: mov             fp, SP
    // 0xa355f8: AllocStack(0x10)
    //     0xa355f8: sub             SP, SP, #0x10
    // 0xa355fc: SetupParameters()
    //     0xa355fc: stur            NULL, [fp, #-8]
    // 0xa35600: CheckStackOverflow
    //     0xa35600: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa35604: cmp             SP, x16
    //     0xa35608: b.ls            #0xa35670
    // 0xa3560c: InitAsync() -> Future<bool>
    //     0xa3560c: ldr             x0, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    //     0xa35610: bl              #0x4b92e4
    // 0xa35614: r0 = LoadStaticField(0xc9c)
    //     0xa35614: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa35618: ldr             x0, [x0, #0x1938]
    // 0xa3561c: tbz             w0, #4, #0xa35664
    // 0xa35620: r0 = true
    //     0xa35620: add             x0, NULL, #0x20  ; true
    // 0xa35624: StoreStaticField(0xc9c, r0)
    //     0xa35624: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0xa35628: str             x0, [x1, #0x1938]
    // 0xa3562c: r0 = InitLateStaticField(0xc98) // [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_flutter_initializer.dart] FFmpegKitInitializer::_instance
    //     0xa3562c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa35630: ldr             x0, [x0, #0x1930]
    //     0xa35634: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa35638: cmp             w0, w16
    //     0xa3563c: b.ne            #0xa3564c
    //     0xa35640: add             x2, PP, #0x2f, lsl #12  ; [pp+0x2fd28] Field <FFmpegKitInitializer._instance@538279298>: static late (offset: 0xc98)
    //     0xa35644: ldr             x2, [x2, #0xd28]
    //     0xa35648: bl              #0xd67d44
    // 0xa3564c: SaveReg r0
    //     0xa3564c: str             x0, [SP, #-8]!
    // 0xa35650: r0 = _initialize()
    //     0xa35650: bl              #0xa35678  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_flutter_initializer.dart] FFmpegKitInitializer::_initialize
    // 0xa35654: add             SP, SP, #8
    // 0xa35658: mov             x1, x0
    // 0xa3565c: stur            x1, [fp, #-0x10]
    // 0xa35660: r0 = Await()
    //     0xa35660: bl              #0x4b8e6c  ; AwaitStub
    // 0xa35664: r0 = LoadStaticField(0xc9c)
    //     0xa35664: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa35668: ldr             x0, [x0, #0x1938]
    // 0xa3566c: r0 = ReturnAsyncNotFuture()
    //     0xa3566c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xa35670: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa35670: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa35674: b               #0xa3560c
  }
  _ _initialize(/* No info */) async {
    // ** addr: 0xa35678, size: 0x25c
    // 0xa35678: EnterFrame
    //     0xa35678: stp             fp, lr, [SP, #-0x10]!
    //     0xa3567c: mov             fp, SP
    // 0xa35680: AllocStack(0x28)
    //     0xa35680: sub             SP, SP, #0x28
    // 0xa35684: SetupParameters(FFmpegKitInitializer this /* r1, fp-0x10 */)
    //     0xa35684: stur            NULL, [fp, #-8]
    //     0xa35688: mov             x0, #0
    //     0xa3568c: add             x1, fp, w0, sxtw #2
    //     0xa35690: ldr             x1, [x1, #0x10]
    //     0xa35694: stur            x1, [fp, #-0x10]
    // 0xa35698: CheckStackOverflow
    //     0xa35698: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa3569c: cmp             SP, x16
    //     0xa356a0: b.ls            #0xa358cc
    // 0xa356a4: InitAsync() -> Future<void?>
    //     0xa356a4: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xa356a8: bl              #0x4b92e4
    // 0xa356ac: r16 = "Loading ffmpeg-kit-flutter."
    //     0xa356ac: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2fd30] "Loading ffmpeg-kit-flutter."
    //     0xa356b0: ldr             x16, [x16, #0xd30]
    // 0xa356b4: SaveReg r16
    //     0xa356b4: str             x16, [SP, #-8]!
    // 0xa356b8: r0 = printToConsole()
    //     0xa356b8: bl              #0x4ffa98  ; [dart:_internal] ::printToConsole
    // 0xa356bc: add             SP, SP, #8
    // 0xa356c0: r16 = Instance_EventChannel
    //     0xa356c0: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2fd38] Obj!EventChannel@b34a71
    //     0xa356c4: ldr             x16, [x16, #0xd38]
    // 0xa356c8: SaveReg r16
    //     0xa356c8: str             x16, [SP, #-8]!
    // 0xa356cc: r0 = receiveBroadcastStream()
    //     0xa356cc: bl              #0x5a24c0  ; [package:flutter/src/services/platform_channel.dart] EventChannel::receiveBroadcastStream
    // 0xa356d0: add             SP, SP, #8
    // 0xa356d4: mov             x2, x0
    // 0xa356d8: ldur            x1, [fp, #-0x10]
    // 0xa356dc: stur            x2, [fp, #-0x18]
    // 0xa356e0: r0 = 59
    //     0xa356e0: mov             x0, #0x3b
    // 0xa356e4: branchIfSmi(r1, 0xa356f0)
    //     0xa356e4: tbz             w1, #0, #0xa356f0
    // 0xa356e8: r0 = LoadClassIdInstr(r1)
    //     0xa356e8: ldur            x0, [x1, #-1]
    //     0xa356ec: ubfx            x0, x0, #0xc, #0x14
    // 0xa356f0: SaveReg r1
    //     0xa356f0: str             x1, [SP, #-8]!
    // 0xa356f4: r0 = GDT[cid_x0 + -0xff2]()
    //     0xa356f4: sub             lr, x0, #0xff2
    //     0xa356f8: ldr             lr, [x21, lr, lsl #3]
    //     0xa356fc: blr             lr
    // 0xa35700: add             SP, SP, #8
    // 0xa35704: mov             x2, x0
    // 0xa35708: ldur            x1, [fp, #-0x10]
    // 0xa3570c: stur            x2, [fp, #-0x20]
    // 0xa35710: r0 = 59
    //     0xa35710: mov             x0, #0x3b
    // 0xa35714: branchIfSmi(r1, 0xa35720)
    //     0xa35714: tbz             w1, #0, #0xa35720
    // 0xa35718: r0 = LoadClassIdInstr(r1)
    //     0xa35718: ldur            x0, [x1, #-1]
    //     0xa3571c: ubfx            x0, x0, #0xc, #0x14
    // 0xa35720: SaveReg r1
    //     0xa35720: str             x1, [SP, #-8]!
    // 0xa35724: r0 = GDT[cid_x0 + -0xf42]()
    //     0xa35724: sub             lr, x0, #0xf42
    //     0xa35728: ldr             lr, [x21, lr, lsl #3]
    //     0xa3572c: blr             lr
    // 0xa35730: add             SP, SP, #8
    // 0xa35734: ldur            x16, [fp, #-0x18]
    // 0xa35738: ldur            lr, [fp, #-0x20]
    // 0xa3573c: stp             lr, x16, [SP, #-0x10]!
    // 0xa35740: SaveReg r0
    //     0xa35740: str             x0, [SP, #-8]!
    // 0xa35744: r4 = const [0, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0xa35744: ldr             x4, [PP, #0x7bb0]  ; [pp+0x7bb0] List(7) [0, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0xa35748: r0 = listen()
    //     0xa35748: bl              #0xc5694c  ; [dart:async] _StreamImpl::listen
    // 0xa3574c: add             SP, SP, #0x18
    // 0xa35750: ldur            x16, [fp, #-0x10]
    // 0xa35754: SaveReg r16
    //     0xa35754: str             x16, [SP, #-8]!
    // 0xa35758: r0 = _getLogLevel()
    //     0xa35758: bl              #0xa36384  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_flutter_initializer.dart] FFmpegKitInitializer::_getLogLevel
    // 0xa3575c: add             SP, SP, #8
    // 0xa35760: mov             x1, x0
    // 0xa35764: stur            x1, [fp, #-0x10]
    // 0xa35768: r0 = Await()
    //     0xa35768: bl              #0x4b8e6c  ; AwaitStub
    // 0xa3576c: cmp             w0, NULL
    // 0xa35770: b.eq            #0xa3578c
    // 0xa35774: r1 = LoadInt32Instr(r0)
    //     0xa35774: sbfx            x1, x0, #1, #0x1f
    //     0xa35778: tbz             w0, #0, #0xa35780
    //     0xa3577c: ldur            x1, [x0, #7]
    // 0xa35780: SaveReg r1
    //     0xa35780: str             x1, [SP, #-8]!
    // 0xa35784: r0 = setLogLevel()
    //     0xa35784: bl              #0xa36184  ; [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::setLogLevel
    // 0xa35788: add             SP, SP, #8
    // 0xa3578c: r0 = getPlatform()
    //     0xa3578c: bl              #0xa36014  ; [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::getPlatform
    // 0xa35790: mov             x1, x0
    // 0xa35794: stur            x1, [fp, #-0x10]
    // 0xa35798: r0 = Await()
    //     0xa35798: bl              #0x4b8e6c  ; AwaitStub
    // 0xa3579c: stur            x0, [fp, #-0x10]
    // 0xa357a0: r0 = getArch()
    //     0xa357a0: bl              #0xa35e58  ; [package:ffmpeg_kit_flutter_min/arch_detect.dart] ArchDetect::getArch
    // 0xa357a4: mov             x1, x0
    // 0xa357a8: stur            x1, [fp, #-0x18]
    // 0xa357ac: r0 = Await()
    //     0xa357ac: bl              #0x4b8e6c  ; AwaitStub
    // 0xa357b0: stur            x0, [fp, #-0x18]
    // 0xa357b4: r0 = getPackageName()
    //     0xa357b4: bl              #0xa35c00  ; [package:ffmpeg_kit_flutter_min/packages.dart] Packages::getPackageName
    // 0xa357b8: mov             x1, x0
    // 0xa357bc: stur            x1, [fp, #-0x20]
    // 0xa357c0: r0 = Await()
    //     0xa357c0: bl              #0x4b8e6c  ; AwaitStub
    // 0xa357c4: stur            x0, [fp, #-0x20]
    // 0xa357c8: r0 = enableRedirection()
    //     0xa357c8: bl              #0xa35a90  ; [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::enableRedirection
    // 0xa357cc: mov             x1, x0
    // 0xa357d0: stur            x1, [fp, #-0x28]
    // 0xa357d4: r0 = Await()
    //     0xa357d4: bl              #0x4b8e6c  ; AwaitStub
    // 0xa357d8: r0 = isLTSBuild()
    //     0xa357d8: bl              #0xa358d4  ; [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::isLTSBuild
    // 0xa357dc: mov             x1, x0
    // 0xa357e0: stur            x1, [fp, #-0x28]
    // 0xa357e4: r0 = Await()
    //     0xa357e4: bl              #0x4b8e6c  ; AwaitStub
    // 0xa357e8: mov             x1, x0
    // 0xa357ec: stur            x1, [fp, #-0x28]
    // 0xa357f0: tbnz            w0, #5, #0xa357f8
    // 0xa357f4: r0 = AssertBoolean()
    //     0xa357f4: bl              #0xd67df0  ; AssertBooleanStub
    // 0xa357f8: ldur            x0, [fp, #-0x28]
    // 0xa357fc: tbnz            w0, #4, #0xa3580c
    // 0xa35800: r5 = "-lts"
    //     0xa35800: add             x5, PP, #0x2f, lsl #12  ; [pp+0x2fd40] "-lts"
    //     0xa35804: ldr             x5, [x5, #0xd40]
    // 0xa35808: b               #0xa35810
    // 0xa3580c: r5 = ""
    //     0xa3580c: ldr             x5, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xa35810: ldur            x4, [fp, #-0x10]
    // 0xa35814: ldur            x3, [fp, #-0x18]
    // 0xa35818: ldur            x0, [fp, #-0x20]
    // 0xa3581c: stur            x5, [fp, #-0x28]
    // 0xa35820: r1 = Null
    //     0xa35820: mov             x1, NULL
    // 0xa35824: r2 = 16
    //     0xa35824: mov             x2, #0x10
    // 0xa35828: r0 = AllocateArray()
    //     0xa35828: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa3582c: mov             x1, x0
    // 0xa35830: ldur            x0, [fp, #-0x10]
    // 0xa35834: StoreField: r1->field_f = r0
    //     0xa35834: stur            w0, [x1, #0xf]
    // 0xa35838: r17 = "-"
    //     0xa35838: ldr             x17, [PP, #0x2e68]  ; [pp+0x2e68] "-"
    // 0xa3583c: StoreField: r1->field_13 = r17
    //     0xa3583c: stur            w17, [x1, #0x13]
    // 0xa35840: ldur            x0, [fp, #-0x20]
    // 0xa35844: StoreField: r1->field_17 = r0
    //     0xa35844: stur            w0, [x1, #0x17]
    // 0xa35848: r17 = "-"
    //     0xa35848: ldr             x17, [PP, #0x2e68]  ; [pp+0x2e68] "-"
    // 0xa3584c: StoreField: r1->field_1b = r17
    //     0xa3584c: stur            w17, [x1, #0x1b]
    // 0xa35850: ldur            x0, [fp, #-0x18]
    // 0xa35854: StoreField: r1->field_1f = r0
    //     0xa35854: stur            w0, [x1, #0x1f]
    // 0xa35858: r17 = "-"
    //     0xa35858: ldr             x17, [PP, #0x2e68]  ; [pp+0x2e68] "-"
    // 0xa3585c: StoreField: r1->field_23 = r17
    //     0xa3585c: stur            w17, [x1, #0x23]
    // 0xa35860: r17 = "5.1.0"
    //     0xa35860: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2fd48] "5.1.0"
    //     0xa35864: ldr             x17, [x17, #0xd48]
    // 0xa35868: StoreField: r1->field_27 = r17
    //     0xa35868: stur            w17, [x1, #0x27]
    // 0xa3586c: ldur            x0, [fp, #-0x28]
    // 0xa35870: StoreField: r1->field_2b = r0
    //     0xa35870: stur            w0, [x1, #0x2b]
    // 0xa35874: SaveReg r1
    //     0xa35874: str             x1, [SP, #-8]!
    // 0xa35878: r0 = _interpolate()
    //     0xa35878: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa3587c: add             SP, SP, #8
    // 0xa35880: r1 = Null
    //     0xa35880: mov             x1, NULL
    // 0xa35884: r2 = 6
    //     0xa35884: mov             x2, #6
    // 0xa35888: stur            x0, [fp, #-0x10]
    // 0xa3588c: r0 = AllocateArray()
    //     0xa3588c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa35890: r17 = "Loaded ffmpeg-kit-flutter-"
    //     0xa35890: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2fd50] "Loaded ffmpeg-kit-flutter-"
    //     0xa35894: ldr             x17, [x17, #0xd50]
    // 0xa35898: StoreField: r0->field_f = r17
    //     0xa35898: stur            w17, [x0, #0xf]
    // 0xa3589c: ldur            x1, [fp, #-0x10]
    // 0xa358a0: StoreField: r0->field_13 = r1
    //     0xa358a0: stur            w1, [x0, #0x13]
    // 0xa358a4: r17 = "."
    //     0xa358a4: ldr             x17, [PP, #0x6b8]  ; [pp+0x6b8] "."
    // 0xa358a8: StoreField: r0->field_17 = r17
    //     0xa358a8: stur            w17, [x0, #0x17]
    // 0xa358ac: SaveReg r0
    //     0xa358ac: str             x0, [SP, #-8]!
    // 0xa358b0: r0 = _interpolate()
    //     0xa358b0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa358b4: add             SP, SP, #8
    // 0xa358b8: SaveReg r0
    //     0xa358b8: str             x0, [SP, #-8]!
    // 0xa358bc: r0 = print()
    //     0xa358bc: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xa358c0: add             SP, SP, #8
    // 0xa358c4: r0 = Null
    //     0xa358c4: mov             x0, NULL
    // 0xa358c8: r0 = ReturnAsyncNotFuture()
    //     0xa358c8: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xa358cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa358cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa358d0: b               #0xa356a4
  }
  _ _getLogLevel(/* No info */) async {
    // ** addr: 0xa36384, size: 0x120
    // 0xa36384: EnterFrame
    //     0xa36384: stp             fp, lr, [SP, #-0x10]!
    //     0xa36388: mov             fp, SP
    // 0xa3638c: AllocStack(0x58)
    //     0xa3638c: sub             SP, SP, #0x58
    // 0xa36390: SetupParameters(FFmpegKitInitializer this /* r1, fp-0x50 */)
    //     0xa36390: stur            NULL, [fp, #-8]
    //     0xa36394: mov             x0, #0
    //     0xa36398: add             x1, fp, w0, sxtw #2
    //     0xa3639c: ldr             x1, [x1, #0x10]
    //     0xa363a0: stur            x1, [fp, #-0x50]
    // 0xa363a4: CheckStackOverflow
    //     0xa363a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa363a8: cmp             SP, x16
    //     0xa363ac: b.ls            #0xa3649c
    // 0xa363b0: InitAsync() -> Future<int?>
    //     0xa363b0: add             x0, PP, #0x10, lsl #12  ; [pp+0x10fd8] TypeArguments: <int?>
    //     0xa363b4: ldr             x0, [x0, #0xfd8]
    //     0xa363b8: bl              #0x4b92e4
    // 0xa363bc: r0 = InitLateStaticField(0xc94) // [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_flutter_initializer.dart] FFmpegKitInitializer::_platform
    //     0xa363bc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa363c0: ldr             x0, [x0, #0x1928]
    //     0xa363c4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa363c8: cmp             w0, w16
    //     0xa363cc: b.ne            #0xa363dc
    //     0xa363d0: add             x2, PP, #0x2f, lsl #12  ; [pp+0x2fe28] Field <FFmpegKitInitializer._platform@538279298>: static late (offset: 0xc94)
    //     0xa363d4: ldr             x2, [x2, #0xe28]
    //     0xa363d8: bl              #0xd67d44
    // 0xa363dc: SaveReg r0
    //     0xa363dc: str             x0, [SP, #-8]!
    // 0xa363e0: r0 = ffmpegKitFlutterInitializerGetLogLevel()
    //     0xa363e0: bl              #0xa364a4  ; [package:ffmpeg_kit_flutter_platform_interface/method_channel_ffmpeg_kit_flutter.dart] MethodChannelFFmpegKit::ffmpegKitFlutterInitializerGetLogLevel
    // 0xa363e4: add             SP, SP, #8
    // 0xa363e8: r0 = ReturnAsync()
    //     0xa363e8: b               #0x501858  ; ReturnAsyncStub
    // 0xa363ec: sub             SP, fp, #0x58
    // 0xa363f0: mov             x3, x0
    // 0xa363f4: stur            x0, [fp, #-0x50]
    // 0xa363f8: mov             x0, x1
    // 0xa363fc: stur            x1, [fp, #-0x58]
    // 0xa36400: r1 = LoadTaggedClassIdMayBeSmiInstr(r3)
    //     0xa36400: mov             x1, #0x76
    //     0xa36404: tbz             w3, #0, #0xa36414
    //     0xa36408: ldur            x1, [x3, #-1]
    //     0xa3640c: ubfx            x1, x1, #0xc, #0x14
    //     0xa36410: lsl             x1, x1, #1
    // 0xa36414: cmp             w1, #0xf28
    // 0xa36418: b.ne            #0xa36488
    // 0xa3641c: r1 = Null
    //     0xa3641c: mov             x1, NULL
    // 0xa36420: r2 = 4
    //     0xa36420: mov             x2, #4
    // 0xa36424: r0 = AllocateArray()
    //     0xa36424: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa36428: r17 = "Plugin _getLogLevel error: "
    //     0xa36428: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2fe30] "Plugin _getLogLevel error: "
    //     0xa3642c: ldr             x17, [x17, #0xe30]
    // 0xa36430: StoreField: r0->field_f = r17
    //     0xa36430: stur            w17, [x0, #0xf]
    // 0xa36434: ldur            x1, [fp, #-0x50]
    // 0xa36438: LoadField: r2 = r1->field_b
    //     0xa36438: ldur            w2, [x1, #0xb]
    // 0xa3643c: DecompressPointer r2
    //     0xa3643c: add             x2, x2, HEAP, lsl #32
    // 0xa36440: StoreField: r0->field_13 = r2
    //     0xa36440: stur            w2, [x0, #0x13]
    // 0xa36444: SaveReg r0
    //     0xa36444: str             x0, [SP, #-8]!
    // 0xa36448: r0 = _interpolate()
    //     0xa36448: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa3644c: add             SP, SP, #8
    // 0xa36450: SaveReg r0
    //     0xa36450: str             x0, [SP, #-8]!
    // 0xa36454: r0 = print()
    //     0xa36454: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xa36458: add             SP, SP, #8
    // 0xa3645c: r16 = <int?>
    //     0xa3645c: add             x16, PP, #0x10, lsl #12  ; [pp+0x10fd8] TypeArguments: <int?>
    //     0xa36460: ldr             x16, [x16, #0xfd8]
    // 0xa36464: r30 = "_getLogLevel failed."
    //     0xa36464: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2fe38] "_getLogLevel failed."
    //     0xa36468: ldr             lr, [lr, #0xe38]
    // 0xa3646c: stp             lr, x16, [SP, #-0x10]!
    // 0xa36470: ldur            x16, [fp, #-0x58]
    // 0xa36474: SaveReg r16
    //     0xa36474: str             x16, [SP, #-8]!
    // 0xa36478: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa36478: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa3647c: r0 = Future.error()
    //     0xa3647c: bl              #0x4e95bc  ; [dart:async] Future::Future.error
    // 0xa36480: add             SP, SP, #0x18
    // 0xa36484: r0 = ReturnAsync()
    //     0xa36484: b               #0x501858  ; ReturnAsyncStub
    // 0xa36488: mov             x1, x3
    // 0xa3648c: mov             x0, x1
    // 0xa36490: ldur            x1, [fp, #-0x58]
    // 0xa36494: r0 = ReThrow()
    //     0xa36494: bl              #0xd67e14  ; ReThrowStub
    // 0xa36498: brk             #0
    // 0xa3649c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa3649c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa364a0: b               #0xa363b0
  }
  static FFmpegKitInitializer _instance() {
    // ** addr: 0xa36500, size: 0x18
    // 0xa36500: EnterFrame
    //     0xa36500: stp             fp, lr, [SP, #-0x10]!
    //     0xa36504: mov             fp, SP
    // 0xa36508: r0 = FFmpegKitInitializer()
    //     0xa36508: bl              #0xa36518  ; AllocateFFmpegKitInitializerStub -> FFmpegKitInitializer (size=0x8)
    // 0xa3650c: LeaveFrame
    //     0xa3650c: mov             SP, fp
    //     0xa36510: ldp             fp, lr, [SP], #0x10
    // 0xa36514: ret
    //     0xa36514: ret             
  }
  dynamic _onError(dynamic) {
    // ** addr: 0xcb5af8, size: 0x18
    // 0xcb5af8: r4 = 0
    //     0xcb5af8: mov             x4, #0
    // 0xcb5afc: r1 = Function '_onError@538279298':.
    //     0xcb5afc: add             x17, PP, #0x40, lsl #12  ; [pp+0x40600] AnonymousClosure: (0xcb5b10), in [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_flutter_initializer.dart] FFmpegKitInitializer::_onError (0xcb5b5c)
    //     0xcb5b00: ldr             x1, [x17, #0x600]
    // 0xcb5b04: r24 = BuildNonGenericMethodExtractorStub
    //     0xcb5b04: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xcb5b08: LoadField: r0 = r24->field_17
    //     0xcb5b08: ldur            x0, [x24, #0x17]
    // 0xcb5b0c: br              x0
  }
  [closure] void _onError(dynamic, Object) {
    // ** addr: 0xcb5b10, size: 0x4c
    // 0xcb5b10: EnterFrame
    //     0xcb5b10: stp             fp, lr, [SP, #-0x10]!
    //     0xcb5b14: mov             fp, SP
    // 0xcb5b18: ldr             x0, [fp, #0x18]
    // 0xcb5b1c: LoadField: r1 = r0->field_17
    //     0xcb5b1c: ldur            w1, [x0, #0x17]
    // 0xcb5b20: DecompressPointer r1
    //     0xcb5b20: add             x1, x1, HEAP, lsl #32
    // 0xcb5b24: CheckStackOverflow
    //     0xcb5b24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb5b28: cmp             SP, x16
    //     0xcb5b2c: b.ls            #0xcb5b54
    // 0xcb5b30: LoadField: r0 = r1->field_f
    //     0xcb5b30: ldur            w0, [x1, #0xf]
    // 0xcb5b34: DecompressPointer r0
    //     0xcb5b34: add             x0, x0, HEAP, lsl #32
    // 0xcb5b38: ldr             x16, [fp, #0x10]
    // 0xcb5b3c: stp             x16, x0, [SP, #-0x10]!
    // 0xcb5b40: r0 = _onError()
    //     0xcb5b40: bl              #0xcb5b5c  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_flutter_initializer.dart] FFmpegKitInitializer::_onError
    // 0xcb5b44: add             SP, SP, #0x10
    // 0xcb5b48: LeaveFrame
    //     0xcb5b48: mov             SP, fp
    //     0xcb5b4c: ldp             fp, lr, [SP], #0x10
    // 0xcb5b50: ret
    //     0xcb5b50: ret             
    // 0xcb5b54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb5b54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb5b58: b               #0xcb5b30
  }
  _ _onError(/* No info */) {
    // ** addr: 0xcb5b5c, size: 0x64
    // 0xcb5b5c: EnterFrame
    //     0xcb5b5c: stp             fp, lr, [SP, #-0x10]!
    //     0xcb5b60: mov             fp, SP
    // 0xcb5b64: CheckStackOverflow
    //     0xcb5b64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb5b68: cmp             SP, x16
    //     0xcb5b6c: b.ls            #0xcb5bb8
    // 0xcb5b70: r1 = Null
    //     0xcb5b70: mov             x1, NULL
    // 0xcb5b74: r2 = 4
    //     0xcb5b74: mov             x2, #4
    // 0xcb5b78: r0 = AllocateArray()
    //     0xcb5b78: bl              #0xd6987c  ; AllocateArrayStub
    // 0xcb5b7c: r17 = "Event error: "
    //     0xcb5b7c: add             x17, PP, #0x40, lsl #12  ; [pp+0x40608] "Event error: "
    //     0xcb5b80: ldr             x17, [x17, #0x608]
    // 0xcb5b84: StoreField: r0->field_f = r17
    //     0xcb5b84: stur            w17, [x0, #0xf]
    // 0xcb5b88: ldr             x1, [fp, #0x10]
    // 0xcb5b8c: StoreField: r0->field_13 = r1
    //     0xcb5b8c: stur            w1, [x0, #0x13]
    // 0xcb5b90: SaveReg r0
    //     0xcb5b90: str             x0, [SP, #-8]!
    // 0xcb5b94: r0 = _interpolate()
    //     0xcb5b94: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xcb5b98: add             SP, SP, #8
    // 0xcb5b9c: SaveReg r0
    //     0xcb5b9c: str             x0, [SP, #-8]!
    // 0xcb5ba0: r0 = print()
    //     0xcb5ba0: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xcb5ba4: add             SP, SP, #8
    // 0xcb5ba8: r0 = Null
    //     0xcb5ba8: mov             x0, NULL
    // 0xcb5bac: LeaveFrame
    //     0xcb5bac: mov             SP, fp
    //     0xcb5bb0: ldp             fp, lr, [SP], #0x10
    // 0xcb5bb4: ret
    //     0xcb5bb4: ret             
    // 0xcb5bb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb5bb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb5bbc: b               #0xcb5b70
  }
  dynamic _onEvent(dynamic) {
    // ** addr: 0xcb6c6c, size: 0x18
    // 0xcb6c6c: r4 = 0
    //     0xcb6c6c: mov             x4, #0
    // 0xcb6c70: r1 = Function '_onEvent@538279298':.
    //     0xcb6c70: add             x17, PP, #0x40, lsl #12  ; [pp+0x40610] AnonymousClosure: (0xcb6c84), in [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_flutter_initializer.dart] FFmpegKitInitializer::_onEvent (0xcb6cd0)
    //     0xcb6c74: ldr             x1, [x17, #0x610]
    // 0xcb6c78: r24 = BuildNonGenericMethodExtractorStub
    //     0xcb6c78: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xcb6c7c: LoadField: r0 = r24->field_17
    //     0xcb6c7c: ldur            x0, [x24, #0x17]
    // 0xcb6c80: br              x0
  }
  [closure] void _onEvent(dynamic, dynamic) {
    // ** addr: 0xcb6c84, size: 0x4c
    // 0xcb6c84: EnterFrame
    //     0xcb6c84: stp             fp, lr, [SP, #-0x10]!
    //     0xcb6c88: mov             fp, SP
    // 0xcb6c8c: ldr             x0, [fp, #0x18]
    // 0xcb6c90: LoadField: r1 = r0->field_17
    //     0xcb6c90: ldur            w1, [x0, #0x17]
    // 0xcb6c94: DecompressPointer r1
    //     0xcb6c94: add             x1, x1, HEAP, lsl #32
    // 0xcb6c98: CheckStackOverflow
    //     0xcb6c98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb6c9c: cmp             SP, x16
    //     0xcb6ca0: b.ls            #0xcb6cc8
    // 0xcb6ca4: LoadField: r0 = r1->field_f
    //     0xcb6ca4: ldur            w0, [x1, #0xf]
    // 0xcb6ca8: DecompressPointer r0
    //     0xcb6ca8: add             x0, x0, HEAP, lsl #32
    // 0xcb6cac: ldr             x16, [fp, #0x10]
    // 0xcb6cb0: stp             x16, x0, [SP, #-0x10]!
    // 0xcb6cb4: r0 = _onEvent()
    //     0xcb6cb4: bl              #0xcb6cd0  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_flutter_initializer.dart] FFmpegKitInitializer::_onEvent
    // 0xcb6cb8: add             SP, SP, #0x10
    // 0xcb6cbc: LeaveFrame
    //     0xcb6cbc: mov             SP, fp
    //     0xcb6cc0: ldp             fp, lr, [SP], #0x10
    // 0xcb6cc4: ret
    //     0xcb6cc4: ret             
    // 0xcb6cc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb6cc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb6ccc: b               #0xcb6ca4
  }
  _ _onEvent(/* No info */) {
    // ** addr: 0xcb6cd0, size: 0x254
    // 0xcb6cd0: EnterFrame
    //     0xcb6cd0: stp             fp, lr, [SP, #-0x10]!
    //     0xcb6cd4: mov             fp, SP
    // 0xcb6cd8: AllocStack(0x18)
    //     0xcb6cd8: sub             SP, SP, #0x18
    // 0xcb6cdc: CheckStackOverflow
    //     0xcb6cdc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb6ce0: cmp             SP, x16
    //     0xcb6ce4: b.ls            #0xcb6f1c
    // 0xcb6ce8: ldr             x0, [fp, #0x10]
    // 0xcb6cec: r2 = Null
    //     0xcb6cec: mov             x2, NULL
    // 0xcb6cf0: r1 = Null
    //     0xcb6cf0: mov             x1, NULL
    // 0xcb6cf4: cmp             w0, NULL
    // 0xcb6cf8: b.eq            #0xcb6d90
    // 0xcb6cfc: branchIfSmi(r0, 0xcb6d90)
    //     0xcb6cfc: tbz             w0, #0, #0xcb6d90
    // 0xcb6d00: r3 = LoadClassIdInstr(r0)
    //     0xcb6d00: ldur            x3, [x0, #-1]
    //     0xcb6d04: ubfx            x3, x3, #0xc, #0x14
    // 0xcb6d08: r17 = 5696
    //     0xcb6d08: mov             x17, #0x1640
    // 0xcb6d0c: cmp             x3, x17
    // 0xcb6d10: b.eq            #0xcb6d98
    // 0xcb6d14: r4 = LoadClassIdInstr(r0)
    //     0xcb6d14: ldur            x4, [x0, #-1]
    //     0xcb6d18: ubfx            x4, x4, #0xc, #0x14
    // 0xcb6d1c: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xcb6d20: ldr             x3, [x3, #0x18]
    // 0xcb6d24: ldr             x3, [x3, x4, lsl #3]
    // 0xcb6d28: LoadField: r3 = r3->field_2b
    //     0xcb6d28: ldur            w3, [x3, #0x2b]
    // 0xcb6d2c: DecompressPointer r3
    //     0xcb6d2c: add             x3, x3, HEAP, lsl #32
    // 0xcb6d30: cmp             w3, NULL
    // 0xcb6d34: b.eq            #0xcb6d90
    // 0xcb6d38: LoadField: r3 = r3->field_f
    //     0xcb6d38: ldur            w3, [x3, #0xf]
    // 0xcb6d3c: lsr             x3, x3, #4
    // 0xcb6d40: r17 = 5696
    //     0xcb6d40: mov             x17, #0x1640
    // 0xcb6d44: cmp             x3, x17
    // 0xcb6d48: b.eq            #0xcb6d98
    // 0xcb6d4c: r3 = SubtypeTestCache
    //     0xcb6d4c: add             x3, PP, #0x40, lsl #12  ; [pp+0x40618] SubtypeTestCache
    //     0xcb6d50: ldr             x3, [x3, #0x618]
    // 0xcb6d54: r24 = Subtype1TestCacheStub
    //     0xcb6d54: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xcb6d58: LoadField: r30 = r24->field_7
    //     0xcb6d58: ldur            lr, [x24, #7]
    // 0xcb6d5c: blr             lr
    // 0xcb6d60: cmp             w7, NULL
    // 0xcb6d64: b.eq            #0xcb6d70
    // 0xcb6d68: tbnz            w7, #4, #0xcb6d90
    // 0xcb6d6c: b               #0xcb6d98
    // 0xcb6d70: r8 = Map
    //     0xcb6d70: add             x8, PP, #0x40, lsl #12  ; [pp+0x40620] Type: Map
    //     0xcb6d74: ldr             x8, [x8, #0x620]
    // 0xcb6d78: r3 = SubtypeTestCache
    //     0xcb6d78: add             x3, PP, #0x40, lsl #12  ; [pp+0x40628] SubtypeTestCache
    //     0xcb6d7c: ldr             x3, [x3, #0x628]
    // 0xcb6d80: r24 = InstanceOfStub
    //     0xcb6d80: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xcb6d84: LoadField: r30 = r24->field_7
    //     0xcb6d84: ldur            lr, [x24, #7]
    // 0xcb6d88: blr             lr
    // 0xcb6d8c: b               #0xcb6d9c
    // 0xcb6d90: r0 = false
    //     0xcb6d90: add             x0, NULL, #0x30  ; false
    // 0xcb6d94: b               #0xcb6d9c
    // 0xcb6d98: r0 = true
    //     0xcb6d98: add             x0, NULL, #0x20  ; true
    // 0xcb6d9c: tbnz            w0, #4, #0xcb6f0c
    // 0xcb6da0: ldr             x0, [fp, #0x10]
    // 0xcb6da4: r1 = LoadClassIdInstr(r0)
    //     0xcb6da4: ldur            x1, [x0, #-1]
    //     0xcb6da8: ubfx            x1, x1, #0xc, #0x14
    // 0xcb6dac: r16 = <String, dynamic>
    //     0xcb6dac: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xcb6db0: stp             x0, x16, [SP, #-0x10]!
    // 0xcb6db4: mov             x0, x1
    // 0xcb6db8: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0xcb6db8: ldr             x4, [PP, #0xe90]  ; [pp+0xe90] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0xcb6dbc: r0 = GDT[cid_x0 + 0x375]()
    //     0xcb6dbc: add             lr, x0, #0x375
    //     0xcb6dc0: ldr             lr, [x21, lr, lsl #3]
    //     0xcb6dc4: blr             lr
    // 0xcb6dc8: add             SP, SP, #0x10
    // 0xcb6dcc: mov             x1, x0
    // 0xcb6dd0: stur            x1, [fp, #-8]
    // 0xcb6dd4: r0 = LoadClassIdInstr(r1)
    //     0xcb6dd4: ldur            x0, [x1, #-1]
    //     0xcb6dd8: ubfx            x0, x0, #0xc, #0x14
    // 0xcb6ddc: r16 = "FFmpegKitLogCallbackEvent"
    //     0xcb6ddc: add             x16, PP, #0x40, lsl #12  ; [pp+0x40630] "FFmpegKitLogCallbackEvent"
    //     0xcb6de0: ldr             x16, [x16, #0x630]
    // 0xcb6de4: stp             x16, x1, [SP, #-0x10]!
    // 0xcb6de8: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb6de8: sub             lr, x0, #0xef
    //     0xcb6dec: ldr             lr, [x21, lr, lsl #3]
    //     0xcb6df0: blr             lr
    // 0xcb6df4: add             SP, SP, #0x10
    // 0xcb6df8: mov             x3, x0
    // 0xcb6dfc: r2 = Null
    //     0xcb6dfc: mov             x2, NULL
    // 0xcb6e00: r1 = Null
    //     0xcb6e00: mov             x1, NULL
    // 0xcb6e04: stur            x3, [fp, #-0x10]
    // 0xcb6e08: r8 = Map?
    //     0xcb6e08: add             x8, PP, #0x39, lsl #12  ; [pp+0x392b0] Type: Map?
    //     0xcb6e0c: ldr             x8, [x8, #0x2b0]
    // 0xcb6e10: r3 = Null
    //     0xcb6e10: add             x3, PP, #0x40, lsl #12  ; [pp+0x40638] Null
    //     0xcb6e14: ldr             x3, [x3, #0x638]
    // 0xcb6e18: r0 = Map?()
    //     0xcb6e18: bl              #0x5a2f04  ; IsType_Map?_Stub
    // 0xcb6e1c: ldur            x1, [fp, #-8]
    // 0xcb6e20: r0 = LoadClassIdInstr(r1)
    //     0xcb6e20: ldur            x0, [x1, #-1]
    //     0xcb6e24: ubfx            x0, x0, #0xc, #0x14
    // 0xcb6e28: r16 = "FFmpegKitStatisticsCallbackEvent"
    //     0xcb6e28: add             x16, PP, #0x40, lsl #12  ; [pp+0x40648] "FFmpegKitStatisticsCallbackEvent"
    //     0xcb6e2c: ldr             x16, [x16, #0x648]
    // 0xcb6e30: stp             x16, x1, [SP, #-0x10]!
    // 0xcb6e34: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb6e34: sub             lr, x0, #0xef
    //     0xcb6e38: ldr             lr, [x21, lr, lsl #3]
    //     0xcb6e3c: blr             lr
    // 0xcb6e40: add             SP, SP, #0x10
    // 0xcb6e44: mov             x3, x0
    // 0xcb6e48: r2 = Null
    //     0xcb6e48: mov             x2, NULL
    // 0xcb6e4c: r1 = Null
    //     0xcb6e4c: mov             x1, NULL
    // 0xcb6e50: stur            x3, [fp, #-0x18]
    // 0xcb6e54: r8 = Map?
    //     0xcb6e54: add             x8, PP, #0x39, lsl #12  ; [pp+0x392b0] Type: Map?
    //     0xcb6e58: ldr             x8, [x8, #0x2b0]
    // 0xcb6e5c: r3 = Null
    //     0xcb6e5c: add             x3, PP, #0x40, lsl #12  ; [pp+0x40650] Null
    //     0xcb6e60: ldr             x3, [x3, #0x650]
    // 0xcb6e64: r0 = Map?()
    //     0xcb6e64: bl              #0x5a2f04  ; IsType_Map?_Stub
    // 0xcb6e68: ldur            x0, [fp, #-8]
    // 0xcb6e6c: r1 = LoadClassIdInstr(r0)
    //     0xcb6e6c: ldur            x1, [x0, #-1]
    //     0xcb6e70: ubfx            x1, x1, #0xc, #0x14
    // 0xcb6e74: r16 = "FFmpegKitCompleteCallbackEvent"
    //     0xcb6e74: add             x16, PP, #0x40, lsl #12  ; [pp+0x40660] "FFmpegKitCompleteCallbackEvent"
    //     0xcb6e78: ldr             x16, [x16, #0x660]
    // 0xcb6e7c: stp             x16, x0, [SP, #-0x10]!
    // 0xcb6e80: mov             x0, x1
    // 0xcb6e84: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb6e84: sub             lr, x0, #0xef
    //     0xcb6e88: ldr             lr, [x21, lr, lsl #3]
    //     0xcb6e8c: blr             lr
    // 0xcb6e90: add             SP, SP, #0x10
    // 0xcb6e94: mov             x3, x0
    // 0xcb6e98: r2 = Null
    //     0xcb6e98: mov             x2, NULL
    // 0xcb6e9c: r1 = Null
    //     0xcb6e9c: mov             x1, NULL
    // 0xcb6ea0: stur            x3, [fp, #-8]
    // 0xcb6ea4: r8 = Map?
    //     0xcb6ea4: add             x8, PP, #0x39, lsl #12  ; [pp+0x392b0] Type: Map?
    //     0xcb6ea8: ldr             x8, [x8, #0x2b0]
    // 0xcb6eac: r3 = Null
    //     0xcb6eac: add             x3, PP, #0x40, lsl #12  ; [pp+0x40668] Null
    //     0xcb6eb0: ldr             x3, [x3, #0x668]
    // 0xcb6eb4: r0 = Map?()
    //     0xcb6eb4: bl              #0x5a2f04  ; IsType_Map?_Stub
    // 0xcb6eb8: ldur            x0, [fp, #-0x10]
    // 0xcb6ebc: cmp             w0, NULL
    // 0xcb6ec0: b.eq            #0xcb6ed4
    // 0xcb6ec4: ldr             x16, [fp, #0x18]
    // 0xcb6ec8: stp             x0, x16, [SP, #-0x10]!
    // 0xcb6ecc: r0 = _processLogCallbackEvent()
    //     0xcb6ecc: bl              #0xcb8db8  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_flutter_initializer.dart] FFmpegKitInitializer::_processLogCallbackEvent
    // 0xcb6ed0: add             SP, SP, #0x10
    // 0xcb6ed4: ldur            x0, [fp, #-0x18]
    // 0xcb6ed8: cmp             w0, NULL
    // 0xcb6edc: b.eq            #0xcb6ef0
    // 0xcb6ee0: ldr             x16, [fp, #0x18]
    // 0xcb6ee4: stp             x0, x16, [SP, #-0x10]!
    // 0xcb6ee8: r0 = _processStatisticsCallbackEvent()
    //     0xcb6ee8: bl              #0xcb85c0  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_flutter_initializer.dart] FFmpegKitInitializer::_processStatisticsCallbackEvent
    // 0xcb6eec: add             SP, SP, #0x10
    // 0xcb6ef0: ldur            x0, [fp, #-8]
    // 0xcb6ef4: cmp             w0, NULL
    // 0xcb6ef8: b.eq            #0xcb6f0c
    // 0xcb6efc: ldr             x16, [fp, #0x18]
    // 0xcb6f00: stp             x0, x16, [SP, #-0x10]!
    // 0xcb6f04: r0 = _processCompleteCallbackEvent()
    //     0xcb6f04: bl              #0xcb6f24  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_flutter_initializer.dart] FFmpegKitInitializer::_processCompleteCallbackEvent
    // 0xcb6f08: add             SP, SP, #0x10
    // 0xcb6f0c: r0 = Null
    //     0xcb6f0c: mov             x0, NULL
    // 0xcb6f10: LeaveFrame
    //     0xcb6f10: mov             SP, fp
    //     0xcb6f14: ldp             fp, lr, [SP], #0x10
    // 0xcb6f18: ret
    //     0xcb6f18: ret             
    // 0xcb6f1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb6f1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb6f20: b               #0xcb6ce8
  }
  _ _processCompleteCallbackEvent(/* No info */) {
    // ** addr: 0xcb6f24, size: 0xe0
    // 0xcb6f24: EnterFrame
    //     0xcb6f24: stp             fp, lr, [SP, #-0x10]!
    //     0xcb6f28: mov             fp, SP
    // 0xcb6f2c: AllocStack(0x8)
    //     0xcb6f2c: sub             SP, SP, #8
    // 0xcb6f30: CheckStackOverflow
    //     0xcb6f30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb6f34: cmp             SP, x16
    //     0xcb6f38: b.ls            #0xcb6ffc
    // 0xcb6f3c: ldr             x0, [fp, #0x10]
    // 0xcb6f40: r1 = LoadClassIdInstr(r0)
    //     0xcb6f40: ldur            x1, [x0, #-1]
    //     0xcb6f44: ubfx            x1, x1, #0xc, #0x14
    // 0xcb6f48: r16 = "sessionId"
    //     0xcb6f48: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2fd10] "sessionId"
    //     0xcb6f4c: ldr             x16, [x16, #0xd10]
    // 0xcb6f50: stp             x16, x0, [SP, #-0x10]!
    // 0xcb6f54: mov             x0, x1
    // 0xcb6f58: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb6f58: sub             lr, x0, #0xef
    //     0xcb6f5c: ldr             lr, [x21, lr, lsl #3]
    //     0xcb6f60: blr             lr
    // 0xcb6f64: add             SP, SP, #0x10
    // 0xcb6f68: mov             x3, x0
    // 0xcb6f6c: r2 = Null
    //     0xcb6f6c: mov             x2, NULL
    // 0xcb6f70: r1 = Null
    //     0xcb6f70: mov             x1, NULL
    // 0xcb6f74: stur            x3, [fp, #-8]
    // 0xcb6f78: branchIfSmi(r0, 0xcb6fa0)
    //     0xcb6f78: tbz             w0, #0, #0xcb6fa0
    // 0xcb6f7c: r4 = LoadClassIdInstr(r0)
    //     0xcb6f7c: ldur            x4, [x0, #-1]
    //     0xcb6f80: ubfx            x4, x4, #0xc, #0x14
    // 0xcb6f84: sub             x4, x4, #0x3b
    // 0xcb6f88: cmp             x4, #1
    // 0xcb6f8c: b.ls            #0xcb6fa0
    // 0xcb6f90: r8 = int
    //     0xcb6f90: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xcb6f94: r3 = Null
    //     0xcb6f94: add             x3, PP, #0x40, lsl #12  ; [pp+0x40678] Null
    //     0xcb6f98: ldr             x3, [x3, #0x678]
    // 0xcb6f9c: r0 = int()
    //     0xcb6f9c: bl              #0xd73714  ; IsType_int_Stub
    // 0xcb6fa0: ldur            x0, [fp, #-8]
    // 0xcb6fa4: r1 = LoadInt32Instr(r0)
    //     0xcb6fa4: sbfx            x1, x0, #1, #0x1f
    //     0xcb6fa8: tbz             w0, #0, #0xcb6fb0
    //     0xcb6fac: ldur            x1, [x0, #7]
    // 0xcb6fb0: SaveReg r1
    //     0xcb6fb0: str             x1, [SP, #-8]!
    // 0xcb6fb4: r0 = getSession()
    //     0xcb6fb4: bl              #0xcb7004  ; [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::getSession
    // 0xcb6fb8: add             SP, SP, #8
    // 0xcb6fbc: r1 = Function '<anonymous closure>':.
    //     0xcb6fbc: add             x1, PP, #0x40, lsl #12  ; [pp+0x40688] AnonymousClosure: (0xcb7c58), in [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_flutter_initializer.dart] FFmpegKitInitializer::_processCompleteCallbackEvent (0xcb6f24)
    //     0xcb6fc0: ldr             x1, [x1, #0x688]
    // 0xcb6fc4: r2 = Null
    //     0xcb6fc4: mov             x2, NULL
    // 0xcb6fc8: stur            x0, [fp, #-8]
    // 0xcb6fcc: r0 = AllocateClosure()
    //     0xcb6fcc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcb6fd0: r16 = <Null?>
    //     0xcb6fd0: ldr             x16, [PP, #0x348]  ; [pp+0x348] TypeArguments: <Null?>
    // 0xcb6fd4: ldur            lr, [fp, #-8]
    // 0xcb6fd8: stp             lr, x16, [SP, #-0x10]!
    // 0xcb6fdc: SaveReg r0
    //     0xcb6fdc: str             x0, [SP, #-8]!
    // 0xcb6fe0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xcb6fe0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xcb6fe4: r0 = then()
    //     0xcb6fe4: bl              #0xca6124  ; [dart:async] _Future::then
    // 0xcb6fe8: add             SP, SP, #0x18
    // 0xcb6fec: r0 = Null
    //     0xcb6fec: mov             x0, NULL
    // 0xcb6ff0: LeaveFrame
    //     0xcb6ff0: mov             SP, fp
    //     0xcb6ff4: ldp             fp, lr, [SP], #0x10
    // 0xcb6ff8: ret
    //     0xcb6ff8: ret             
    // 0xcb6ffc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb6ffc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb7000: b               #0xcb6f3c
  }
  [closure] Null <anonymous closure>(dynamic, Session?) {
    // ** addr: 0xcb7c58, size: 0x4d0
    // 0xcb7c58: EnterFrame
    //     0xcb7c58: stp             fp, lr, [SP, #-0x10]!
    //     0xcb7c5c: mov             fp, SP
    // 0xcb7c60: AllocStack(0x60)
    //     0xcb7c60: sub             SP, SP, #0x60
    // 0xcb7c64: CheckStackOverflow
    //     0xcb7c64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb7c68: cmp             SP, x16
    //     0xcb7c6c: b.ls            #0xcb8120
    // 0xcb7c70: ldr             x0, [fp, #0x10]
    // 0xcb7c74: cmp             w0, NULL
    // 0xcb7c78: b.eq            #0xcb80d4
    // 0xcb7c7c: r1 = LoadClassIdInstr(r0)
    //     0xcb7c7c: ldur            x1, [x0, #-1]
    //     0xcb7c80: ubfx            x1, x1, #0xc, #0x14
    // 0xcb7c84: lsl             x1, x1, #1
    // 0xcb7c88: r17 = 8840
    //     0xcb7c88: mov             x17, #0x2288
    // 0xcb7c8c: cmp             w1, w17
    // 0xcb7c90: b.eq            #0xcb7ca0
    // 0xcb7c94: r17 = 8842
    //     0xcb7c94: mov             x17, #0x228a
    // 0xcb7c98: cmp             w1, w17
    // 0xcb7c9c: b.ne            #0xcb7d40
    // 0xcb7ca0: r17 = 8840
    //     0xcb7ca0: mov             x17, #0x2288
    // 0xcb7ca4: cmp             w1, w17
    // 0xcb7ca8: b.eq            #0xcb7cf4
    // 0xcb7cac: r17 = 8842
    //     0xcb7cac: mov             x17, #0x228a
    // 0xcb7cb0: cmp             w1, w17
    // 0xcb7cb4: b.ne            #0xcb7cf4
    // 0xcb7cb8: SaveReg r0
    //     0xcb7cb8: str             x0, [SP, #-8]!
    // 0xcb7cbc: r0 = getCompleteCallback()
    //     0xcb7cbc: bl              #0xcb8438  ; [package:ffmpeg_kit_flutter_min/ffprobe_session.dart] FFprobeSession::getCompleteCallback
    // 0xcb7cc0: add             SP, SP, #8
    // 0xcb7cc4: mov             x1, x0
    // 0xcb7cc8: stur            x1, [fp, #-0x58]
    // 0xcb7ccc: cmp             w1, NULL
    // 0xcb7cd0: b.eq            #0xcb80d4
    // 0xcb7cd4: ldr             x16, [fp, #0x10]
    // 0xcb7cd8: stp             x16, x1, [SP, #-0x10]!
    // 0xcb7cdc: mov             x0, x1
    // 0xcb7ce0: ClosureCall
    //     0xcb7ce0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcb7ce4: ldur            x2, [x0, #0x1f]
    //     0xcb7ce8: blr             x2
    // 0xcb7cec: add             SP, SP, #0x10
    // 0xcb7cf0: b               #0xcb80d4
    // 0xcb7cf4: r17 = 8840
    //     0xcb7cf4: mov             x17, #0x2288
    // 0xcb7cf8: cmp             w1, w17
    // 0xcb7cfc: b.ne            #0xcb80d4
    // 0xcb7d00: ldr             x16, [fp, #0x10]
    // 0xcb7d04: SaveReg r16
    //     0xcb7d04: str             x16, [SP, #-8]!
    // 0xcb7d08: r0 = getCompleteCallback()
    //     0xcb7d08: bl              #0xcb82b0  ; [package:ffmpeg_kit_flutter_min/media_information_session.dart] MediaInformationSession::getCompleteCallback
    // 0xcb7d0c: add             SP, SP, #8
    // 0xcb7d10: mov             x1, x0
    // 0xcb7d14: stur            x1, [fp, #-0x58]
    // 0xcb7d18: cmp             w1, NULL
    // 0xcb7d1c: b.eq            #0xcb80d4
    // 0xcb7d20: ldr             x16, [fp, #0x10]
    // 0xcb7d24: stp             x16, x1, [SP, #-0x10]!
    // 0xcb7d28: mov             x0, x1
    // 0xcb7d2c: ClosureCall
    //     0xcb7d2c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcb7d30: ldur            x2, [x0, #0x1f]
    //     0xcb7d34: blr             x2
    // 0xcb7d38: add             SP, SP, #0x10
    // 0xcb7d3c: b               #0xcb80d4
    // 0xcb7d40: ldr             x0, [fp, #0x10]
    // 0xcb7d44: r2 = Null
    //     0xcb7d44: mov             x2, NULL
    // 0xcb7d48: r1 = Null
    //     0xcb7d48: mov             x1, NULL
    // 0xcb7d4c: r4 = LoadClassIdInstr(r0)
    //     0xcb7d4c: ldur            x4, [x0, #-1]
    //     0xcb7d50: ubfx            x4, x4, #0xc, #0x14
    // 0xcb7d54: r17 = 4422
    //     0xcb7d54: mov             x17, #0x1146
    // 0xcb7d58: cmp             x4, x17
    // 0xcb7d5c: b.eq            #0xcb7d74
    // 0xcb7d60: r8 = FFmpegSession
    //     0xcb7d60: add             x8, PP, #0x40, lsl #12  ; [pp+0x40690] Type: FFmpegSession
    //     0xcb7d64: ldr             x8, [x8, #0x690]
    // 0xcb7d68: r3 = Null
    //     0xcb7d68: add             x3, PP, #0x40, lsl #12  ; [pp+0x40698] Null
    //     0xcb7d6c: ldr             x3, [x3, #0x698]
    // 0xcb7d70: r0 = FFmpegSession()
    //     0xcb7d70: bl              #0xa36584  ; IsType_FFmpegSession_Stub
    // 0xcb7d74: ldr             x16, [fp, #0x10]
    // 0xcb7d78: SaveReg r16
    //     0xcb7d78: str             x16, [SP, #-8]!
    // 0xcb7d7c: r0 = getCompleteCallback()
    //     0xcb7d7c: bl              #0xcb8128  ; [package:ffmpeg_kit_flutter_min/ffmpeg_session.dart] FFmpegSession::getCompleteCallback
    // 0xcb7d80: add             SP, SP, #8
    // 0xcb7d84: mov             x1, x0
    // 0xcb7d88: stur            x1, [fp, #-0x58]
    // 0xcb7d8c: cmp             w1, NULL
    // 0xcb7d90: b.eq            #0xcb80d4
    // 0xcb7d94: ldr             x16, [fp, #0x10]
    // 0xcb7d98: stp             x16, x1, [SP, #-0x10]!
    // 0xcb7d9c: mov             x0, x1
    // 0xcb7da0: ClosureCall
    //     0xcb7da0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcb7da4: ldur            x2, [x0, #0x1f]
    //     0xcb7da8: blr             x2
    // 0xcb7dac: add             SP, SP, #0x10
    // 0xcb7db0: b               #0xcb80d4
    // 0xcb7db4: sub             SP, fp, #0x60
    // 0xcb7db8: mov             x4, x0
    // 0xcb7dbc: mov             x3, x1
    // 0xcb7dc0: stur            x0, [fp, #-0x58]
    // 0xcb7dc4: stur            x1, [fp, #-0x60]
    // 0xcb7dc8: r2 = Null
    //     0xcb7dc8: mov             x2, NULL
    // 0xcb7dcc: r1 = Null
    //     0xcb7dcc: mov             x1, NULL
    // 0xcb7dd0: cmp             w0, NULL
    // 0xcb7dd4: b.eq            #0xcb7e60
    // 0xcb7dd8: branchIfSmi(r0, 0xcb7e60)
    //     0xcb7dd8: tbz             w0, #0, #0xcb7e60
    // 0xcb7ddc: r3 = LoadClassIdInstr(r0)
    //     0xcb7ddc: ldur            x3, [x0, #-1]
    //     0xcb7de0: ubfx            x3, x3, #0xc, #0x14
    // 0xcb7de4: r4 = LoadClassIdInstr(r0)
    //     0xcb7de4: ldur            x4, [x0, #-1]
    //     0xcb7de8: ubfx            x4, x4, #0xc, #0x14
    // 0xcb7dec: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xcb7df0: ldr             x3, [x3, #0x18]
    // 0xcb7df4: ldr             x3, [x3, x4, lsl #3]
    // 0xcb7df8: LoadField: r3 = r3->field_2b
    //     0xcb7df8: ldur            w3, [x3, #0x2b]
    // 0xcb7dfc: DecompressPointer r3
    //     0xcb7dfc: add             x3, x3, HEAP, lsl #32
    // 0xcb7e00: cmp             w3, NULL
    // 0xcb7e04: b.eq            #0xcb7e60
    // 0xcb7e08: LoadField: r3 = r3->field_f
    //     0xcb7e08: ldur            w3, [x3, #0xf]
    // 0xcb7e0c: lsr             x3, x3, #4
    // 0xcb7e10: r17 = 5704
    //     0xcb7e10: mov             x17, #0x1648
    // 0xcb7e14: cmp             x3, x17
    // 0xcb7e18: b.eq            #0xcb7e68
    // 0xcb7e1c: r3 = SubtypeTestCache
    //     0xcb7e1c: add             x3, PP, #0x40, lsl #12  ; [pp+0x406a8] SubtypeTestCache
    //     0xcb7e20: ldr             x3, [x3, #0x6a8]
    // 0xcb7e24: r24 = Subtype1TestCacheStub
    //     0xcb7e24: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xcb7e28: LoadField: r30 = r24->field_7
    //     0xcb7e28: ldur            lr, [x24, #7]
    // 0xcb7e2c: blr             lr
    // 0xcb7e30: cmp             w7, NULL
    // 0xcb7e34: b.eq            #0xcb7e40
    // 0xcb7e38: tbnz            w7, #4, #0xcb7e60
    // 0xcb7e3c: b               #0xcb7e68
    // 0xcb7e40: r8 = Exception
    //     0xcb7e40: add             x8, PP, #0x40, lsl #12  ; [pp+0x406b0] Type: Exception
    //     0xcb7e44: ldr             x8, [x8, #0x6b0]
    // 0xcb7e48: r3 = SubtypeTestCache
    //     0xcb7e48: add             x3, PP, #0x40, lsl #12  ; [pp+0x406b8] SubtypeTestCache
    //     0xcb7e4c: ldr             x3, [x3, #0x6b8]
    // 0xcb7e50: r24 = InstanceOfStub
    //     0xcb7e50: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xcb7e54: LoadField: r30 = r24->field_7
    //     0xcb7e54: ldur            lr, [x24, #7]
    // 0xcb7e58: blr             lr
    // 0xcb7e5c: b               #0xcb7e6c
    // 0xcb7e60: r0 = false
    //     0xcb7e60: add             x0, NULL, #0x30  ; false
    // 0xcb7e64: b               #0xcb7e6c
    // 0xcb7e68: r0 = true
    //     0xcb7e68: add             x0, NULL, #0x20  ; true
    // 0xcb7e6c: tbnz            w0, #4, #0xcb80e4
    // 0xcb7e70: ldur            x0, [fp, #-0x58]
    // 0xcb7e74: r1 = Null
    //     0xcb7e74: mov             x1, NULL
    // 0xcb7e78: r2 = 4
    //     0xcb7e78: mov             x2, #4
    // 0xcb7e7c: r0 = AllocateArray()
    //     0xcb7e7c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xcb7e80: r17 = "Exception thrown inside session complete callback. "
    //     0xcb7e80: add             x17, PP, #0x40, lsl #12  ; [pp+0x406c0] "Exception thrown inside session complete callback. "
    //     0xcb7e84: ldr             x17, [x17, #0x6c0]
    // 0xcb7e88: StoreField: r0->field_f = r17
    //     0xcb7e88: stur            w17, [x0, #0xf]
    // 0xcb7e8c: ldur            x1, [fp, #-0x58]
    // 0xcb7e90: StoreField: r0->field_13 = r1
    //     0xcb7e90: stur            w1, [x0, #0x13]
    // 0xcb7e94: SaveReg r0
    //     0xcb7e94: str             x0, [SP, #-8]!
    // 0xcb7e98: r0 = _interpolate()
    //     0xcb7e98: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xcb7e9c: add             SP, SP, #8
    // 0xcb7ea0: SaveReg r0
    //     0xcb7ea0: str             x0, [SP, #-8]!
    // 0xcb7ea4: r0 = print()
    //     0xcb7ea4: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xcb7ea8: add             SP, SP, #8
    // 0xcb7eac: ldur            x16, [fp, #-0x60]
    // 0xcb7eb0: SaveReg r16
    //     0xcb7eb0: str             x16, [SP, #-8]!
    // 0xcb7eb4: r0 = print()
    //     0xcb7eb4: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xcb7eb8: add             SP, SP, #8
    // 0xcb7ebc: b               #0xcb80d4
    // 0xcb7ec0: sub             SP, fp, #0x60
    // 0xcb7ec4: mov             x4, x0
    // 0xcb7ec8: mov             x3, x1
    // 0xcb7ecc: stur            x0, [fp, #-0x58]
    // 0xcb7ed0: stur            x1, [fp, #-0x60]
    // 0xcb7ed4: r2 = Null
    //     0xcb7ed4: mov             x2, NULL
    // 0xcb7ed8: r1 = Null
    //     0xcb7ed8: mov             x1, NULL
    // 0xcb7edc: cmp             w0, NULL
    // 0xcb7ee0: b.eq            #0xcb7f6c
    // 0xcb7ee4: branchIfSmi(r0, 0xcb7f6c)
    //     0xcb7ee4: tbz             w0, #0, #0xcb7f6c
    // 0xcb7ee8: r3 = LoadClassIdInstr(r0)
    //     0xcb7ee8: ldur            x3, [x0, #-1]
    //     0xcb7eec: ubfx            x3, x3, #0xc, #0x14
    // 0xcb7ef0: r4 = LoadClassIdInstr(r0)
    //     0xcb7ef0: ldur            x4, [x0, #-1]
    //     0xcb7ef4: ubfx            x4, x4, #0xc, #0x14
    // 0xcb7ef8: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xcb7efc: ldr             x3, [x3, #0x18]
    // 0xcb7f00: ldr             x3, [x3, x4, lsl #3]
    // 0xcb7f04: LoadField: r3 = r3->field_2b
    //     0xcb7f04: ldur            w3, [x3, #0x2b]
    // 0xcb7f08: DecompressPointer r3
    //     0xcb7f08: add             x3, x3, HEAP, lsl #32
    // 0xcb7f0c: cmp             w3, NULL
    // 0xcb7f10: b.eq            #0xcb7f6c
    // 0xcb7f14: LoadField: r3 = r3->field_f
    //     0xcb7f14: ldur            w3, [x3, #0xf]
    // 0xcb7f18: lsr             x3, x3, #4
    // 0xcb7f1c: r17 = 5704
    //     0xcb7f1c: mov             x17, #0x1648
    // 0xcb7f20: cmp             x3, x17
    // 0xcb7f24: b.eq            #0xcb7f74
    // 0xcb7f28: r3 = SubtypeTestCache
    //     0xcb7f28: add             x3, PP, #0x40, lsl #12  ; [pp+0x406c8] SubtypeTestCache
    //     0xcb7f2c: ldr             x3, [x3, #0x6c8]
    // 0xcb7f30: r24 = Subtype1TestCacheStub
    //     0xcb7f30: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xcb7f34: LoadField: r30 = r24->field_7
    //     0xcb7f34: ldur            lr, [x24, #7]
    // 0xcb7f38: blr             lr
    // 0xcb7f3c: cmp             w7, NULL
    // 0xcb7f40: b.eq            #0xcb7f4c
    // 0xcb7f44: tbnz            w7, #4, #0xcb7f6c
    // 0xcb7f48: b               #0xcb7f74
    // 0xcb7f4c: r8 = Exception
    //     0xcb7f4c: add             x8, PP, #0x40, lsl #12  ; [pp+0x406d0] Type: Exception
    //     0xcb7f50: ldr             x8, [x8, #0x6d0]
    // 0xcb7f54: r3 = SubtypeTestCache
    //     0xcb7f54: add             x3, PP, #0x40, lsl #12  ; [pp+0x406d8] SubtypeTestCache
    //     0xcb7f58: ldr             x3, [x3, #0x6d8]
    // 0xcb7f5c: r24 = InstanceOfStub
    //     0xcb7f5c: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xcb7f60: LoadField: r30 = r24->field_7
    //     0xcb7f60: ldur            lr, [x24, #7]
    // 0xcb7f64: blr             lr
    // 0xcb7f68: b               #0xcb7f78
    // 0xcb7f6c: r0 = false
    //     0xcb7f6c: add             x0, NULL, #0x30  ; false
    // 0xcb7f70: b               #0xcb7f78
    // 0xcb7f74: r0 = true
    //     0xcb7f74: add             x0, NULL, #0x20  ; true
    // 0xcb7f78: tbnz            w0, #4, #0xcb80f8
    // 0xcb7f7c: ldur            x0, [fp, #-0x58]
    // 0xcb7f80: r1 = Null
    //     0xcb7f80: mov             x1, NULL
    // 0xcb7f84: r2 = 4
    //     0xcb7f84: mov             x2, #4
    // 0xcb7f88: r0 = AllocateArray()
    //     0xcb7f88: bl              #0xd6987c  ; AllocateArrayStub
    // 0xcb7f8c: r17 = "Exception thrown inside session complete callback. "
    //     0xcb7f8c: add             x17, PP, #0x40, lsl #12  ; [pp+0x406c0] "Exception thrown inside session complete callback. "
    //     0xcb7f90: ldr             x17, [x17, #0x6c0]
    // 0xcb7f94: StoreField: r0->field_f = r17
    //     0xcb7f94: stur            w17, [x0, #0xf]
    // 0xcb7f98: ldur            x1, [fp, #-0x58]
    // 0xcb7f9c: StoreField: r0->field_13 = r1
    //     0xcb7f9c: stur            w1, [x0, #0x13]
    // 0xcb7fa0: SaveReg r0
    //     0xcb7fa0: str             x0, [SP, #-8]!
    // 0xcb7fa4: r0 = _interpolate()
    //     0xcb7fa4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xcb7fa8: add             SP, SP, #8
    // 0xcb7fac: SaveReg r0
    //     0xcb7fac: str             x0, [SP, #-8]!
    // 0xcb7fb0: r0 = print()
    //     0xcb7fb0: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xcb7fb4: add             SP, SP, #8
    // 0xcb7fb8: ldur            x16, [fp, #-0x60]
    // 0xcb7fbc: SaveReg r16
    //     0xcb7fbc: str             x16, [SP, #-8]!
    // 0xcb7fc0: r0 = print()
    //     0xcb7fc0: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xcb7fc4: add             SP, SP, #8
    // 0xcb7fc8: b               #0xcb80d4
    // 0xcb7fcc: sub             SP, fp, #0x60
    // 0xcb7fd0: mov             x4, x0
    // 0xcb7fd4: mov             x3, x1
    // 0xcb7fd8: stur            x0, [fp, #-0x58]
    // 0xcb7fdc: stur            x1, [fp, #-0x60]
    // 0xcb7fe0: r2 = Null
    //     0xcb7fe0: mov             x2, NULL
    // 0xcb7fe4: r1 = Null
    //     0xcb7fe4: mov             x1, NULL
    // 0xcb7fe8: cmp             w0, NULL
    // 0xcb7fec: b.eq            #0xcb8078
    // 0xcb7ff0: branchIfSmi(r0, 0xcb8078)
    //     0xcb7ff0: tbz             w0, #0, #0xcb8078
    // 0xcb7ff4: r3 = LoadClassIdInstr(r0)
    //     0xcb7ff4: ldur            x3, [x0, #-1]
    //     0xcb7ff8: ubfx            x3, x3, #0xc, #0x14
    // 0xcb7ffc: r4 = LoadClassIdInstr(r0)
    //     0xcb7ffc: ldur            x4, [x0, #-1]
    //     0xcb8000: ubfx            x4, x4, #0xc, #0x14
    // 0xcb8004: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xcb8008: ldr             x3, [x3, #0x18]
    // 0xcb800c: ldr             x3, [x3, x4, lsl #3]
    // 0xcb8010: LoadField: r3 = r3->field_2b
    //     0xcb8010: ldur            w3, [x3, #0x2b]
    // 0xcb8014: DecompressPointer r3
    //     0xcb8014: add             x3, x3, HEAP, lsl #32
    // 0xcb8018: cmp             w3, NULL
    // 0xcb801c: b.eq            #0xcb8078
    // 0xcb8020: LoadField: r3 = r3->field_f
    //     0xcb8020: ldur            w3, [x3, #0xf]
    // 0xcb8024: lsr             x3, x3, #4
    // 0xcb8028: r17 = 5704
    //     0xcb8028: mov             x17, #0x1648
    // 0xcb802c: cmp             x3, x17
    // 0xcb8030: b.eq            #0xcb8080
    // 0xcb8034: r3 = SubtypeTestCache
    //     0xcb8034: add             x3, PP, #0x40, lsl #12  ; [pp+0x406e0] SubtypeTestCache
    //     0xcb8038: ldr             x3, [x3, #0x6e0]
    // 0xcb803c: r24 = Subtype1TestCacheStub
    //     0xcb803c: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xcb8040: LoadField: r30 = r24->field_7
    //     0xcb8040: ldur            lr, [x24, #7]
    // 0xcb8044: blr             lr
    // 0xcb8048: cmp             w7, NULL
    // 0xcb804c: b.eq            #0xcb8058
    // 0xcb8050: tbnz            w7, #4, #0xcb8078
    // 0xcb8054: b               #0xcb8080
    // 0xcb8058: r8 = Exception
    //     0xcb8058: add             x8, PP, #0x40, lsl #12  ; [pp+0x406e8] Type: Exception
    //     0xcb805c: ldr             x8, [x8, #0x6e8]
    // 0xcb8060: r3 = SubtypeTestCache
    //     0xcb8060: add             x3, PP, #0x40, lsl #12  ; [pp+0x406f0] SubtypeTestCache
    //     0xcb8064: ldr             x3, [x3, #0x6f0]
    // 0xcb8068: r24 = InstanceOfStub
    //     0xcb8068: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xcb806c: LoadField: r30 = r24->field_7
    //     0xcb806c: ldur            lr, [x24, #7]
    // 0xcb8070: blr             lr
    // 0xcb8074: b               #0xcb8084
    // 0xcb8078: r0 = false
    //     0xcb8078: add             x0, NULL, #0x30  ; false
    // 0xcb807c: b               #0xcb8084
    // 0xcb8080: r0 = true
    //     0xcb8080: add             x0, NULL, #0x20  ; true
    // 0xcb8084: tbnz            w0, #4, #0xcb810c
    // 0xcb8088: ldur            x0, [fp, #-0x58]
    // 0xcb808c: r1 = Null
    //     0xcb808c: mov             x1, NULL
    // 0xcb8090: r2 = 4
    //     0xcb8090: mov             x2, #4
    // 0xcb8094: r0 = AllocateArray()
    //     0xcb8094: bl              #0xd6987c  ; AllocateArrayStub
    // 0xcb8098: r17 = "Exception thrown inside session complete callback. "
    //     0xcb8098: add             x17, PP, #0x40, lsl #12  ; [pp+0x406c0] "Exception thrown inside session complete callback. "
    //     0xcb809c: ldr             x17, [x17, #0x6c0]
    // 0xcb80a0: StoreField: r0->field_f = r17
    //     0xcb80a0: stur            w17, [x0, #0xf]
    // 0xcb80a4: ldur            x1, [fp, #-0x58]
    // 0xcb80a8: StoreField: r0->field_13 = r1
    //     0xcb80a8: stur            w1, [x0, #0x13]
    // 0xcb80ac: SaveReg r0
    //     0xcb80ac: str             x0, [SP, #-8]!
    // 0xcb80b0: r0 = _interpolate()
    //     0xcb80b0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xcb80b4: add             SP, SP, #8
    // 0xcb80b8: SaveReg r0
    //     0xcb80b8: str             x0, [SP, #-8]!
    // 0xcb80bc: r0 = print()
    //     0xcb80bc: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xcb80c0: add             SP, SP, #8
    // 0xcb80c4: ldur            x16, [fp, #-0x60]
    // 0xcb80c8: SaveReg r16
    //     0xcb80c8: str             x16, [SP, #-8]!
    // 0xcb80cc: r0 = print()
    //     0xcb80cc: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xcb80d0: add             SP, SP, #8
    // 0xcb80d4: r0 = Null
    //     0xcb80d4: mov             x0, NULL
    // 0xcb80d8: LeaveFrame
    //     0xcb80d8: mov             SP, fp
    //     0xcb80dc: ldp             fp, lr, [SP], #0x10
    // 0xcb80e0: ret
    //     0xcb80e0: ret             
    // 0xcb80e4: ldur            x1, [fp, #-0x58]
    // 0xcb80e8: mov             x0, x1
    // 0xcb80ec: ldur            x1, [fp, #-0x60]
    // 0xcb80f0: r0 = ReThrow()
    //     0xcb80f0: bl              #0xd67e14  ; ReThrowStub
    // 0xcb80f4: brk             #0
    // 0xcb80f8: ldur            x1, [fp, #-0x58]
    // 0xcb80fc: mov             x0, x1
    // 0xcb8100: ldur            x1, [fp, #-0x60]
    // 0xcb8104: r0 = ReThrow()
    //     0xcb8104: bl              #0xd67e14  ; ReThrowStub
    // 0xcb8108: brk             #0
    // 0xcb810c: ldur            x1, [fp, #-0x58]
    // 0xcb8110: mov             x0, x1
    // 0xcb8114: ldur            x1, [fp, #-0x60]
    // 0xcb8118: r0 = ReThrow()
    //     0xcb8118: bl              #0xd67e14  ; ReThrowStub
    // 0xcb811c: brk             #0
    // 0xcb8120: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb8120: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb8124: b               #0xcb7c70
  }
  _ _processStatisticsCallbackEvent(/* No info */) {
    // ** addr: 0xcb85c0, size: 0x374
    // 0xcb85c0: EnterFrame
    //     0xcb85c0: stp             fp, lr, [SP, #-0x10]!
    //     0xcb85c4: mov             fp, SP
    // 0xcb85c8: AllocStack(0x70)
    //     0xcb85c8: sub             SP, SP, #0x70
    // 0xcb85cc: CheckStackOverflow
    //     0xcb85cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb85d0: cmp             SP, x16
    //     0xcb85d4: b.ls            #0xcb892c
    // 0xcb85d8: ldr             x16, [fp, #0x10]
    // 0xcb85dc: SaveReg r16
    //     0xcb85dc: str             x16, [SP, #-8]!
    // 0xcb85e0: r0 = mapToStatistics()
    //     0xcb85e0: bl              #0xcb8a94  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] FFmpegKitFactory::mapToStatistics
    // 0xcb85e4: add             SP, SP, #8
    // 0xcb85e8: mov             x1, x0
    // 0xcb85ec: ldr             x0, [fp, #0x10]
    // 0xcb85f0: stur            x1, [fp, #-0x60]
    // 0xcb85f4: r2 = LoadClassIdInstr(r0)
    //     0xcb85f4: ldur            x2, [x0, #-1]
    //     0xcb85f8: ubfx            x2, x2, #0xc, #0x14
    // 0xcb85fc: r16 = "sessionId"
    //     0xcb85fc: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2fd10] "sessionId"
    //     0xcb8600: ldr             x16, [x16, #0xd10]
    // 0xcb8604: stp             x16, x0, [SP, #-0x10]!
    // 0xcb8608: mov             x0, x2
    // 0xcb860c: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb860c: sub             lr, x0, #0xef
    //     0xcb8610: ldr             lr, [x21, lr, lsl #3]
    //     0xcb8614: blr             lr
    // 0xcb8618: add             SP, SP, #0x10
    // 0xcb861c: mov             x3, x0
    // 0xcb8620: r2 = Null
    //     0xcb8620: mov             x2, NULL
    // 0xcb8624: r1 = Null
    //     0xcb8624: mov             x1, NULL
    // 0xcb8628: stur            x3, [fp, #-0x68]
    // 0xcb862c: branchIfSmi(r0, 0xcb8654)
    //     0xcb862c: tbz             w0, #0, #0xcb8654
    // 0xcb8630: r4 = LoadClassIdInstr(r0)
    //     0xcb8630: ldur            x4, [x0, #-1]
    //     0xcb8634: ubfx            x4, x4, #0xc, #0x14
    // 0xcb8638: sub             x4, x4, #0x3b
    // 0xcb863c: cmp             x4, #1
    // 0xcb8640: b.ls            #0xcb8654
    // 0xcb8644: r8 = int
    //     0xcb8644: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xcb8648: r3 = Null
    //     0xcb8648: add             x3, PP, #0x40, lsl #12  ; [pp+0x40868] Null
    //     0xcb864c: ldr             x3, [x3, #0x868]
    // 0xcb8650: r0 = int()
    //     0xcb8650: bl              #0xd73714  ; IsType_int_Stub
    // 0xcb8654: ldur            x0, [fp, #-0x68]
    // 0xcb8658: r1 = LoadInt32Instr(r0)
    //     0xcb8658: sbfx            x1, x0, #1, #0x1f
    //     0xcb865c: tbz             w0, #0, #0xcb8664
    //     0xcb8660: ldur            x1, [x0, #7]
    // 0xcb8664: SaveReg r1
    //     0xcb8664: str             x1, [SP, #-8]!
    // 0xcb8668: r0 = getStatisticsCallback()
    //     0xcb8668: bl              #0xcb8934  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] FFmpegKitFactory::getStatisticsCallback
    // 0xcb866c: add             SP, SP, #8
    // 0xcb8670: mov             x1, x0
    // 0xcb8674: stur            x1, [fp, #-0x68]
    // 0xcb8678: cmp             w1, NULL
    // 0xcb867c: b.eq            #0xcb86a4
    // 0xcb8680: ldur            x16, [fp, #-0x60]
    // 0xcb8684: stp             x16, x1, [SP, #-0x10]!
    // 0xcb8688: mov             x0, x1
    // 0xcb868c: ClosureCall
    //     0xcb868c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcb8690: ldur            x2, [x0, #0x1f]
    //     0xcb8694: blr             x2
    // 0xcb8698: add             SP, SP, #0x10
    // 0xcb869c: ldur            x0, [fp, #-0x60]
    // 0xcb86a0: b               #0xcb87bc
    // 0xcb86a4: ldur            x0, [fp, #-0x60]
    // 0xcb86a8: b               #0xcb87bc
    // 0xcb86ac: sub             SP, fp, #0x70
    // 0xcb86b0: mov             x4, x0
    // 0xcb86b4: mov             x3, x1
    // 0xcb86b8: stur            x0, [fp, #-0x60]
    // 0xcb86bc: stur            x1, [fp, #-0x68]
    // 0xcb86c0: r2 = Null
    //     0xcb86c0: mov             x2, NULL
    // 0xcb86c4: r1 = Null
    //     0xcb86c4: mov             x1, NULL
    // 0xcb86c8: cmp             w0, NULL
    // 0xcb86cc: b.eq            #0xcb8758
    // 0xcb86d0: branchIfSmi(r0, 0xcb8758)
    //     0xcb86d0: tbz             w0, #0, #0xcb8758
    // 0xcb86d4: r3 = LoadClassIdInstr(r0)
    //     0xcb86d4: ldur            x3, [x0, #-1]
    //     0xcb86d8: ubfx            x3, x3, #0xc, #0x14
    // 0xcb86dc: r4 = LoadClassIdInstr(r0)
    //     0xcb86dc: ldur            x4, [x0, #-1]
    //     0xcb86e0: ubfx            x4, x4, #0xc, #0x14
    // 0xcb86e4: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xcb86e8: ldr             x3, [x3, #0x18]
    // 0xcb86ec: ldr             x3, [x3, x4, lsl #3]
    // 0xcb86f0: LoadField: r3 = r3->field_2b
    //     0xcb86f0: ldur            w3, [x3, #0x2b]
    // 0xcb86f4: DecompressPointer r3
    //     0xcb86f4: add             x3, x3, HEAP, lsl #32
    // 0xcb86f8: cmp             w3, NULL
    // 0xcb86fc: b.eq            #0xcb8758
    // 0xcb8700: LoadField: r3 = r3->field_f
    //     0xcb8700: ldur            w3, [x3, #0xf]
    // 0xcb8704: lsr             x3, x3, #4
    // 0xcb8708: r17 = 5704
    //     0xcb8708: mov             x17, #0x1648
    // 0xcb870c: cmp             x3, x17
    // 0xcb8710: b.eq            #0xcb8760
    // 0xcb8714: r3 = SubtypeTestCache
    //     0xcb8714: add             x3, PP, #0x40, lsl #12  ; [pp+0x40878] SubtypeTestCache
    //     0xcb8718: ldr             x3, [x3, #0x878]
    // 0xcb871c: r24 = Subtype1TestCacheStub
    //     0xcb871c: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xcb8720: LoadField: r30 = r24->field_7
    //     0xcb8720: ldur            lr, [x24, #7]
    // 0xcb8724: blr             lr
    // 0xcb8728: cmp             w7, NULL
    // 0xcb872c: b.eq            #0xcb8738
    // 0xcb8730: tbnz            w7, #4, #0xcb8758
    // 0xcb8734: b               #0xcb8760
    // 0xcb8738: r8 = Exception
    //     0xcb8738: add             x8, PP, #0x40, lsl #12  ; [pp+0x40880] Type: Exception
    //     0xcb873c: ldr             x8, [x8, #0x880]
    // 0xcb8740: r3 = SubtypeTestCache
    //     0xcb8740: add             x3, PP, #0x40, lsl #12  ; [pp+0x40888] SubtypeTestCache
    //     0xcb8744: ldr             x3, [x3, #0x888]
    // 0xcb8748: r24 = InstanceOfStub
    //     0xcb8748: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xcb874c: LoadField: r30 = r24->field_7
    //     0xcb874c: ldur            lr, [x24, #7]
    // 0xcb8750: blr             lr
    // 0xcb8754: b               #0xcb8764
    // 0xcb8758: r0 = false
    //     0xcb8758: add             x0, NULL, #0x30  ; false
    // 0xcb875c: b               #0xcb8764
    // 0xcb8760: r0 = true
    //     0xcb8760: add             x0, NULL, #0x20  ; true
    // 0xcb8764: tbnz            w0, #4, #0xcb8904
    // 0xcb8768: ldur            x0, [fp, #-0x60]
    // 0xcb876c: ldur            x3, [fp, #-0x30]
    // 0xcb8770: r1 = Null
    //     0xcb8770: mov             x1, NULL
    // 0xcb8774: r2 = 4
    //     0xcb8774: mov             x2, #4
    // 0xcb8778: r0 = AllocateArray()
    //     0xcb8778: bl              #0xd6987c  ; AllocateArrayStub
    // 0xcb877c: r17 = "Exception thrown inside session statistics callback. "
    //     0xcb877c: add             x17, PP, #0x40, lsl #12  ; [pp+0x40890] "Exception thrown inside session statistics callback. "
    //     0xcb8780: ldr             x17, [x17, #0x890]
    // 0xcb8784: StoreField: r0->field_f = r17
    //     0xcb8784: stur            w17, [x0, #0xf]
    // 0xcb8788: ldur            x1, [fp, #-0x60]
    // 0xcb878c: StoreField: r0->field_13 = r1
    //     0xcb878c: stur            w1, [x0, #0x13]
    // 0xcb8790: SaveReg r0
    //     0xcb8790: str             x0, [SP, #-8]!
    // 0xcb8794: r0 = _interpolate()
    //     0xcb8794: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xcb8798: add             SP, SP, #8
    // 0xcb879c: SaveReg r0
    //     0xcb879c: str             x0, [SP, #-8]!
    // 0xcb87a0: r0 = print()
    //     0xcb87a0: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xcb87a4: add             SP, SP, #8
    // 0xcb87a8: ldur            x16, [fp, #-0x68]
    // 0xcb87ac: SaveReg r16
    //     0xcb87ac: str             x16, [SP, #-8]!
    // 0xcb87b0: r0 = print()
    //     0xcb87b0: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xcb87b4: add             SP, SP, #8
    // 0xcb87b8: ldur            x0, [fp, #-0x30]
    // 0xcb87bc: r1 = LoadStaticField(0xc64)
    //     0xcb87bc: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0xcb87c0: ldr             x1, [x1, #0x18c8]
    // 0xcb87c4: stur            x1, [fp, #-0x70]
    // 0xcb87c8: cmp             w1, NULL
    // 0xcb87cc: b.eq            #0xcb88f4
    // 0xcb87d0: stp             x0, x1, [SP, #-0x10]!
    // 0xcb87d4: mov             x0, x1
    // 0xcb87d8: ClosureCall
    //     0xcb87d8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcb87dc: ldur            x2, [x0, #0x1f]
    //     0xcb87e0: blr             x2
    // 0xcb87e4: add             SP, SP, #0x10
    // 0xcb87e8: b               #0xcb88f4
    // 0xcb87ec: sub             SP, fp, #0x70
    // 0xcb87f0: mov             x4, x0
    // 0xcb87f4: mov             x3, x1
    // 0xcb87f8: stur            x0, [fp, #-0x60]
    // 0xcb87fc: stur            x1, [fp, #-0x68]
    // 0xcb8800: r2 = Null
    //     0xcb8800: mov             x2, NULL
    // 0xcb8804: r1 = Null
    //     0xcb8804: mov             x1, NULL
    // 0xcb8808: cmp             w0, NULL
    // 0xcb880c: b.eq            #0xcb8898
    // 0xcb8810: branchIfSmi(r0, 0xcb8898)
    //     0xcb8810: tbz             w0, #0, #0xcb8898
    // 0xcb8814: r3 = LoadClassIdInstr(r0)
    //     0xcb8814: ldur            x3, [x0, #-1]
    //     0xcb8818: ubfx            x3, x3, #0xc, #0x14
    // 0xcb881c: r4 = LoadClassIdInstr(r0)
    //     0xcb881c: ldur            x4, [x0, #-1]
    //     0xcb8820: ubfx            x4, x4, #0xc, #0x14
    // 0xcb8824: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xcb8828: ldr             x3, [x3, #0x18]
    // 0xcb882c: ldr             x3, [x3, x4, lsl #3]
    // 0xcb8830: LoadField: r3 = r3->field_2b
    //     0xcb8830: ldur            w3, [x3, #0x2b]
    // 0xcb8834: DecompressPointer r3
    //     0xcb8834: add             x3, x3, HEAP, lsl #32
    // 0xcb8838: cmp             w3, NULL
    // 0xcb883c: b.eq            #0xcb8898
    // 0xcb8840: LoadField: r3 = r3->field_f
    //     0xcb8840: ldur            w3, [x3, #0xf]
    // 0xcb8844: lsr             x3, x3, #4
    // 0xcb8848: r17 = 5704
    //     0xcb8848: mov             x17, #0x1648
    // 0xcb884c: cmp             x3, x17
    // 0xcb8850: b.eq            #0xcb88a0
    // 0xcb8854: r3 = SubtypeTestCache
    //     0xcb8854: add             x3, PP, #0x40, lsl #12  ; [pp+0x40898] SubtypeTestCache
    //     0xcb8858: ldr             x3, [x3, #0x898]
    // 0xcb885c: r24 = Subtype1TestCacheStub
    //     0xcb885c: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xcb8860: LoadField: r30 = r24->field_7
    //     0xcb8860: ldur            lr, [x24, #7]
    // 0xcb8864: blr             lr
    // 0xcb8868: cmp             w7, NULL
    // 0xcb886c: b.eq            #0xcb8878
    // 0xcb8870: tbnz            w7, #4, #0xcb8898
    // 0xcb8874: b               #0xcb88a0
    // 0xcb8878: r8 = Exception
    //     0xcb8878: add             x8, PP, #0x40, lsl #12  ; [pp+0x408a0] Type: Exception
    //     0xcb887c: ldr             x8, [x8, #0x8a0]
    // 0xcb8880: r3 = SubtypeTestCache
    //     0xcb8880: add             x3, PP, #0x40, lsl #12  ; [pp+0x408a8] SubtypeTestCache
    //     0xcb8884: ldr             x3, [x3, #0x8a8]
    // 0xcb8888: r24 = InstanceOfStub
    //     0xcb8888: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xcb888c: LoadField: r30 = r24->field_7
    //     0xcb888c: ldur            lr, [x24, #7]
    // 0xcb8890: blr             lr
    // 0xcb8894: b               #0xcb88a4
    // 0xcb8898: r0 = false
    //     0xcb8898: add             x0, NULL, #0x30  ; false
    // 0xcb889c: b               #0xcb88a4
    // 0xcb88a0: r0 = true
    //     0xcb88a0: add             x0, NULL, #0x20  ; true
    // 0xcb88a4: tbnz            w0, #4, #0xcb8918
    // 0xcb88a8: ldur            x0, [fp, #-0x60]
    // 0xcb88ac: r1 = Null
    //     0xcb88ac: mov             x1, NULL
    // 0xcb88b0: r2 = 4
    //     0xcb88b0: mov             x2, #4
    // 0xcb88b4: r0 = AllocateArray()
    //     0xcb88b4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xcb88b8: r17 = "Exception thrown inside global statistics callback. "
    //     0xcb88b8: add             x17, PP, #0x40, lsl #12  ; [pp+0x408b0] "Exception thrown inside global statistics callback. "
    //     0xcb88bc: ldr             x17, [x17, #0x8b0]
    // 0xcb88c0: StoreField: r0->field_f = r17
    //     0xcb88c0: stur            w17, [x0, #0xf]
    // 0xcb88c4: ldur            x1, [fp, #-0x60]
    // 0xcb88c8: StoreField: r0->field_13 = r1
    //     0xcb88c8: stur            w1, [x0, #0x13]
    // 0xcb88cc: SaveReg r0
    //     0xcb88cc: str             x0, [SP, #-8]!
    // 0xcb88d0: r0 = _interpolate()
    //     0xcb88d0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xcb88d4: add             SP, SP, #8
    // 0xcb88d8: SaveReg r0
    //     0xcb88d8: str             x0, [SP, #-8]!
    // 0xcb88dc: r0 = print()
    //     0xcb88dc: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xcb88e0: add             SP, SP, #8
    // 0xcb88e4: ldur            x16, [fp, #-0x68]
    // 0xcb88e8: SaveReg r16
    //     0xcb88e8: str             x16, [SP, #-8]!
    // 0xcb88ec: r0 = print()
    //     0xcb88ec: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xcb88f0: add             SP, SP, #8
    // 0xcb88f4: r0 = Null
    //     0xcb88f4: mov             x0, NULL
    // 0xcb88f8: LeaveFrame
    //     0xcb88f8: mov             SP, fp
    //     0xcb88fc: ldp             fp, lr, [SP], #0x10
    // 0xcb8900: ret
    //     0xcb8900: ret             
    // 0xcb8904: ldur            x1, [fp, #-0x60]
    // 0xcb8908: mov             x0, x1
    // 0xcb890c: ldur            x1, [fp, #-0x68]
    // 0xcb8910: r0 = ReThrow()
    //     0xcb8910: bl              #0xd67e14  ; ReThrowStub
    // 0xcb8914: brk             #0
    // 0xcb8918: ldur            x1, [fp, #-0x60]
    // 0xcb891c: mov             x0, x1
    // 0xcb8920: ldur            x1, [fp, #-0x68]
    // 0xcb8924: r0 = ReThrow()
    //     0xcb8924: bl              #0xd67e14  ; ReThrowStub
    // 0xcb8928: brk             #0
    // 0xcb892c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb892c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb8930: b               #0xcb85d8
  }
  _ _processLogCallbackEvent(/* No info */) {
    // ** addr: 0xcb8db8, size: 0x4d4
    // 0xcb8db8: EnterFrame
    //     0xcb8db8: stp             fp, lr, [SP, #-0x10]!
    //     0xcb8dbc: mov             fp, SP
    // 0xcb8dc0: AllocStack(0xc0)
    //     0xcb8dc0: sub             SP, SP, #0xc0
    // 0xcb8dc4: CheckStackOverflow
    //     0xcb8dc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb8dc8: cmp             SP, x16
    //     0xcb8dcc: b.ls            #0xcb9284
    // 0xcb8dd0: ldr             x16, [fp, #0x10]
    // 0xcb8dd4: SaveReg r16
    //     0xcb8dd4: str             x16, [SP, #-8]!
    // 0xcb8dd8: r0 = mapToLog()
    //     0xcb8dd8: bl              #0xcb93ec  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] FFmpegKitFactory::mapToLog
    // 0xcb8ddc: add             SP, SP, #8
    // 0xcb8de0: mov             x2, x0
    // 0xcb8de4: ldr             x1, [fp, #0x10]
    // 0xcb8de8: stur            x2, [fp, #-0xa0]
    // 0xcb8dec: r0 = LoadClassIdInstr(r1)
    //     0xcb8dec: ldur            x0, [x1, #-1]
    //     0xcb8df0: ubfx            x0, x0, #0xc, #0x14
    // 0xcb8df4: r16 = "sessionId"
    //     0xcb8df4: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2fd10] "sessionId"
    //     0xcb8df8: ldr             x16, [x16, #0xd10]
    // 0xcb8dfc: stp             x16, x1, [SP, #-0x10]!
    // 0xcb8e00: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb8e00: sub             lr, x0, #0xef
    //     0xcb8e04: ldr             lr, [x21, lr, lsl #3]
    //     0xcb8e08: blr             lr
    // 0xcb8e0c: add             SP, SP, #0x10
    // 0xcb8e10: mov             x3, x0
    // 0xcb8e14: r2 = Null
    //     0xcb8e14: mov             x2, NULL
    // 0xcb8e18: r1 = Null
    //     0xcb8e18: mov             x1, NULL
    // 0xcb8e1c: stur            x3, [fp, #-0xa8]
    // 0xcb8e20: branchIfSmi(r0, 0xcb8e48)
    //     0xcb8e20: tbz             w0, #0, #0xcb8e48
    // 0xcb8e24: r4 = LoadClassIdInstr(r0)
    //     0xcb8e24: ldur            x4, [x0, #-1]
    //     0xcb8e28: ubfx            x4, x4, #0xc, #0x14
    // 0xcb8e2c: sub             x4, x4, #0x3b
    // 0xcb8e30: cmp             x4, #1
    // 0xcb8e34: b.ls            #0xcb8e48
    // 0xcb8e38: r8 = int
    //     0xcb8e38: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xcb8e3c: r3 = Null
    //     0xcb8e3c: add             x3, PP, #0x40, lsl #12  ; [pp+0x40968] Null
    //     0xcb8e40: ldr             x3, [x3, #0x968]
    // 0xcb8e44: r0 = int()
    //     0xcb8e44: bl              #0xd73714  ; IsType_int_Stub
    // 0xcb8e48: ldr             x1, [fp, #0x10]
    // 0xcb8e4c: r0 = LoadClassIdInstr(r1)
    //     0xcb8e4c: ldur            x0, [x1, #-1]
    //     0xcb8e50: ubfx            x0, x0, #0xc, #0x14
    // 0xcb8e54: r16 = "level"
    //     0xcb8e54: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2fe18] "level"
    //     0xcb8e58: ldr             x16, [x16, #0xe18]
    // 0xcb8e5c: stp             x16, x1, [SP, #-0x10]!
    // 0xcb8e60: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb8e60: sub             lr, x0, #0xef
    //     0xcb8e64: ldr             lr, [x21, lr, lsl #3]
    //     0xcb8e68: blr             lr
    // 0xcb8e6c: add             SP, SP, #0x10
    // 0xcb8e70: mov             x3, x0
    // 0xcb8e74: r2 = Null
    //     0xcb8e74: mov             x2, NULL
    // 0xcb8e78: r1 = Null
    //     0xcb8e78: mov             x1, NULL
    // 0xcb8e7c: stur            x3, [fp, #-0xb0]
    // 0xcb8e80: branchIfSmi(r0, 0xcb8ea8)
    //     0xcb8e80: tbz             w0, #0, #0xcb8ea8
    // 0xcb8e84: r4 = LoadClassIdInstr(r0)
    //     0xcb8e84: ldur            x4, [x0, #-1]
    //     0xcb8e88: ubfx            x4, x4, #0xc, #0x14
    // 0xcb8e8c: sub             x4, x4, #0x3b
    // 0xcb8e90: cmp             x4, #1
    // 0xcb8e94: b.ls            #0xcb8ea8
    // 0xcb8e98: r8 = int
    //     0xcb8e98: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xcb8e9c: r3 = Null
    //     0xcb8e9c: add             x3, PP, #0x40, lsl #12  ; [pp+0x40978] Null
    //     0xcb8ea0: ldr             x3, [x3, #0x978]
    // 0xcb8ea4: r0 = int()
    //     0xcb8ea4: bl              #0xd73714  ; IsType_int_Stub
    // 0xcb8ea8: ldr             x0, [fp, #0x10]
    // 0xcb8eac: r1 = LoadClassIdInstr(r0)
    //     0xcb8eac: ldur            x1, [x0, #-1]
    //     0xcb8eb0: ubfx            x1, x1, #0xc, #0x14
    // 0xcb8eb4: r16 = "message"
    //     0xcb8eb4: ldr             x16, [PP, #0x62c8]  ; [pp+0x62c8] "message"
    // 0xcb8eb8: stp             x16, x0, [SP, #-0x10]!
    // 0xcb8ebc: mov             x0, x1
    // 0xcb8ec0: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb8ec0: sub             lr, x0, #0xef
    //     0xcb8ec4: ldr             lr, [x21, lr, lsl #3]
    //     0xcb8ec8: blr             lr
    // 0xcb8ecc: add             SP, SP, #0x10
    // 0xcb8ed0: mov             x3, x0
    // 0xcb8ed4: r2 = Null
    //     0xcb8ed4: mov             x2, NULL
    // 0xcb8ed8: r1 = Null
    //     0xcb8ed8: mov             x1, NULL
    // 0xcb8edc: stur            x3, [fp, #-0xb8]
    // 0xcb8ee0: r4 = 59
    //     0xcb8ee0: mov             x4, #0x3b
    // 0xcb8ee4: branchIfSmi(r0, 0xcb8ef0)
    //     0xcb8ee4: tbz             w0, #0, #0xcb8ef0
    // 0xcb8ee8: r4 = LoadClassIdInstr(r0)
    //     0xcb8ee8: ldur            x4, [x0, #-1]
    //     0xcb8eec: ubfx            x4, x4, #0xc, #0x14
    // 0xcb8ef0: sub             x4, x4, #0x5d
    // 0xcb8ef4: cmp             x4, #3
    // 0xcb8ef8: b.ls            #0xcb8f0c
    // 0xcb8efc: r8 = String
    //     0xcb8efc: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xcb8f00: r3 = Null
    //     0xcb8f00: add             x3, PP, #0x40, lsl #12  ; [pp+0x40988] Null
    //     0xcb8f04: ldr             x3, [x3, #0x988]
    // 0xcb8f08: r0 = String()
    //     0xcb8f08: bl              #0xd72afc  ; IsType_String_Stub
    // 0xcb8f0c: r0 = InitLateStaticField(0xc58) // [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::_activeLogLevel
    //     0xcb8f0c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb8f10: ldr             x0, [x0, #0x18b0]
    //     0xcb8f14: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb8f18: cmp             w0, w16
    //     0xcb8f1c: b.ne            #0xcb8f2c
    //     0xcb8f20: add             x2, PP, #0x40, lsl #12  ; [pp+0x40998] Field <FFmpegKitConfig._activeLogLevel@517022016>: static late (offset: 0xc58)
    //     0xcb8f24: ldr             x2, [x2, #0x998]
    //     0xcb8f28: bl              #0xd67d44
    // 0xcb8f2c: stur            x0, [fp, #-0xc0]
    // 0xcb8f30: r0 = InitLateStaticField(0xc54) // [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::_globalLogRedirectionStrategy
    //     0xcb8f30: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb8f34: ldr             x0, [x0, #0x18a8]
    //     0xcb8f38: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb8f3c: cmp             w0, w16
    //     0xcb8f40: b.ne            #0xcb8f50
    //     0xcb8f44: add             x2, PP, #0x30, lsl #12  ; [pp+0x30020] Field <FFmpegKitConfig._globalLogRedirectionStrategy@517022016>: static late (offset: 0xc54)
    //     0xcb8f48: ldr             x2, [x2, #0x20]
    //     0xcb8f4c: bl              #0xd67d44
    // 0xcb8f50: ldur            x0, [fp, #-0xc0]
    // 0xcb8f54: r1 = LoadInt32Instr(r0)
    //     0xcb8f54: sbfx            x1, x0, #1, #0x1f
    //     0xcb8f58: tbz             w0, #0, #0xcb8f60
    //     0xcb8f5c: ldur            x1, [x0, #7]
    // 0xcb8f60: cmn             x1, #8
    // 0xcb8f64: b.ne            #0xcb8f84
    // 0xcb8f68: ldur            x0, [fp, #-0xb0]
    // 0xcb8f6c: r2 = LoadInt32Instr(r0)
    //     0xcb8f6c: sbfx            x2, x0, #1, #0x1f
    //     0xcb8f70: tbz             w0, #0, #0xcb8f78
    //     0xcb8f74: ldur            x2, [x0, #7]
    // 0xcb8f78: cmn             x2, #0x10
    // 0xcb8f7c: b.eq            #0xcb8f88
    // 0xcb8f80: b               #0xcb8f9c
    // 0xcb8f84: ldur            x0, [fp, #-0xb0]
    // 0xcb8f88: r2 = LoadInt32Instr(r0)
    //     0xcb8f88: sbfx            x2, x0, #1, #0x1f
    //     0xcb8f8c: tbz             w0, #0, #0xcb8f94
    //     0xcb8f90: ldur            x2, [x0, #7]
    // 0xcb8f94: cmp             x2, x1
    // 0xcb8f98: b.le            #0xcb8fac
    // 0xcb8f9c: r0 = Null
    //     0xcb8f9c: mov             x0, NULL
    // 0xcb8fa0: LeaveFrame
    //     0xcb8fa0: mov             SP, fp
    //     0xcb8fa4: ldp             fp, lr, [SP], #0x10
    // 0xcb8fa8: ret
    //     0xcb8fa8: ret             
    // 0xcb8fac: ldur            x16, [fp, #-0xa8]
    // 0xcb8fb0: SaveReg r16
    //     0xcb8fb0: str             x16, [SP, #-8]!
    // 0xcb8fb4: r0 = getLogRedirectionStrategy()
    //     0xcb8fb4: bl              #0xcb759c  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] FFmpegKitFactory::getLogRedirectionStrategy
    // 0xcb8fb8: add             SP, SP, #8
    // 0xcb8fbc: cmp             w0, NULL
    // 0xcb8fc0: b.ne            #0xcb8fd0
    // 0xcb8fc4: r1 = Instance_LogRedirectionStrategy
    //     0xcb8fc4: add             x1, PP, #0x30, lsl #12  ; [pp+0x30048] Obj!LogRedirectionStrategy@b65f91
    //     0xcb8fc8: ldr             x1, [x1, #0x48]
    // 0xcb8fcc: b               #0xcb8fd4
    // 0xcb8fd0: mov             x1, x0
    // 0xcb8fd4: ldur            x0, [fp, #-0xa8]
    // 0xcb8fd8: stur            x1, [fp, #-0xc0]
    // 0xcb8fdc: r2 = LoadInt32Instr(r0)
    //     0xcb8fdc: sbfx            x2, x0, #1, #0x1f
    //     0xcb8fe0: tbz             w0, #0, #0xcb8fe8
    //     0xcb8fe4: ldur            x2, [x0, #7]
    // 0xcb8fe8: SaveReg r2
    //     0xcb8fe8: str             x2, [SP, #-8]!
    // 0xcb8fec: r0 = getLogCallback()
    //     0xcb8fec: bl              #0xcb928c  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] FFmpegKitFactory::getLogCallback
    // 0xcb8ff0: add             SP, SP, #8
    // 0xcb8ff4: mov             x1, x0
    // 0xcb8ff8: stur            x1, [fp, #-0xa8]
    // 0xcb8ffc: cmp             w1, NULL
    // 0xcb9000: b.eq            #0xcb9030
    // 0xcb9004: ldur            x16, [fp, #-0xa0]
    // 0xcb9008: stp             x16, x1, [SP, #-0x10]!
    // 0xcb900c: mov             x0, x1
    // 0xcb9010: ClosureCall
    //     0xcb9010: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcb9014: ldur            x2, [x0, #0x1f]
    //     0xcb9018: blr             x2
    // 0xcb901c: add             SP, SP, #0x10
    // 0xcb9020: ldur            x2, [fp, #-0xb0]
    // 0xcb9024: ldur            x1, [fp, #-0xb8]
    // 0xcb9028: ldur            x0, [fp, #-0xc0]
    // 0xcb902c: b               #0xcb9164
    // 0xcb9030: ldur            x3, [fp, #-0xb0]
    // 0xcb9034: ldur            x2, [fp, #-0xb8]
    // 0xcb9038: ldur            x1, [fp, #-0xc0]
    // 0xcb903c: r0 = false
    //     0xcb903c: add             x0, NULL, #0x30  ; false
    // 0xcb9040: b               #0xcb9174
    // 0xcb9044: sub             SP, fp, #0xc0
    // 0xcb9048: mov             x4, x0
    // 0xcb904c: mov             x3, x1
    // 0xcb9050: stur            x0, [fp, #-0xa0]
    // 0xcb9054: stur            x1, [fp, #-0xa8]
    // 0xcb9058: r2 = Null
    //     0xcb9058: mov             x2, NULL
    // 0xcb905c: r1 = Null
    //     0xcb905c: mov             x1, NULL
    // 0xcb9060: cmp             w0, NULL
    // 0xcb9064: b.eq            #0xcb90f0
    // 0xcb9068: branchIfSmi(r0, 0xcb90f0)
    //     0xcb9068: tbz             w0, #0, #0xcb90f0
    // 0xcb906c: r3 = LoadClassIdInstr(r0)
    //     0xcb906c: ldur            x3, [x0, #-1]
    //     0xcb9070: ubfx            x3, x3, #0xc, #0x14
    // 0xcb9074: r4 = LoadClassIdInstr(r0)
    //     0xcb9074: ldur            x4, [x0, #-1]
    //     0xcb9078: ubfx            x4, x4, #0xc, #0x14
    // 0xcb907c: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xcb9080: ldr             x3, [x3, #0x18]
    // 0xcb9084: ldr             x3, [x3, x4, lsl #3]
    // 0xcb9088: LoadField: r3 = r3->field_2b
    //     0xcb9088: ldur            w3, [x3, #0x2b]
    // 0xcb908c: DecompressPointer r3
    //     0xcb908c: add             x3, x3, HEAP, lsl #32
    // 0xcb9090: cmp             w3, NULL
    // 0xcb9094: b.eq            #0xcb90f0
    // 0xcb9098: LoadField: r3 = r3->field_f
    //     0xcb9098: ldur            w3, [x3, #0xf]
    // 0xcb909c: lsr             x3, x3, #4
    // 0xcb90a0: r17 = 5704
    //     0xcb90a0: mov             x17, #0x1648
    // 0xcb90a4: cmp             x3, x17
    // 0xcb90a8: b.eq            #0xcb90f8
    // 0xcb90ac: r3 = SubtypeTestCache
    //     0xcb90ac: add             x3, PP, #0x40, lsl #12  ; [pp+0x409a0] SubtypeTestCache
    //     0xcb90b0: ldr             x3, [x3, #0x9a0]
    // 0xcb90b4: r24 = Subtype1TestCacheStub
    //     0xcb90b4: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xcb90b8: LoadField: r30 = r24->field_7
    //     0xcb90b8: ldur            lr, [x24, #7]
    // 0xcb90bc: blr             lr
    // 0xcb90c0: cmp             w7, NULL
    // 0xcb90c4: b.eq            #0xcb90d0
    // 0xcb90c8: tbnz            w7, #4, #0xcb90f0
    // 0xcb90cc: b               #0xcb90f8
    // 0xcb90d0: r8 = Exception
    //     0xcb90d0: add             x8, PP, #0x40, lsl #12  ; [pp+0x409a8] Type: Exception
    //     0xcb90d4: ldr             x8, [x8, #0x9a8]
    // 0xcb90d8: r3 = SubtypeTestCache
    //     0xcb90d8: add             x3, PP, #0x40, lsl #12  ; [pp+0x409b0] SubtypeTestCache
    //     0xcb90dc: ldr             x3, [x3, #0x9b0]
    // 0xcb90e0: r24 = InstanceOfStub
    //     0xcb90e0: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xcb90e4: LoadField: r30 = r24->field_7
    //     0xcb90e4: ldur            lr, [x24, #7]
    // 0xcb90e8: blr             lr
    // 0xcb90ec: b               #0xcb90fc
    // 0xcb90f0: r0 = false
    //     0xcb90f0: add             x0, NULL, #0x30  ; false
    // 0xcb90f4: b               #0xcb90fc
    // 0xcb90f8: r0 = true
    //     0xcb90f8: add             x0, NULL, #0x20  ; true
    // 0xcb90fc: tbnz            w0, #4, #0xcb9270
    // 0xcb9100: ldur            x0, [fp, #-0xa0]
    // 0xcb9104: ldur            x5, [fp, #-0x50]
    // 0xcb9108: ldur            x4, [fp, #-0x58]
    // 0xcb910c: ldur            x3, [fp, #-0x78]
    // 0xcb9110: r1 = Null
    //     0xcb9110: mov             x1, NULL
    // 0xcb9114: r2 = 4
    //     0xcb9114: mov             x2, #4
    // 0xcb9118: r0 = AllocateArray()
    //     0xcb9118: bl              #0xd6987c  ; AllocateArrayStub
    // 0xcb911c: r17 = "Exception thrown inside session log callback. "
    //     0xcb911c: add             x17, PP, #0x40, lsl #12  ; [pp+0x409b8] "Exception thrown inside session log callback. "
    //     0xcb9120: ldr             x17, [x17, #0x9b8]
    // 0xcb9124: StoreField: r0->field_f = r17
    //     0xcb9124: stur            w17, [x0, #0xf]
    // 0xcb9128: ldur            x1, [fp, #-0xa0]
    // 0xcb912c: StoreField: r0->field_13 = r1
    //     0xcb912c: stur            w1, [x0, #0x13]
    // 0xcb9130: SaveReg r0
    //     0xcb9130: str             x0, [SP, #-8]!
    // 0xcb9134: r0 = _interpolate()
    //     0xcb9134: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xcb9138: add             SP, SP, #8
    // 0xcb913c: SaveReg r0
    //     0xcb913c: str             x0, [SP, #-8]!
    // 0xcb9140: r0 = print()
    //     0xcb9140: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xcb9144: add             SP, SP, #8
    // 0xcb9148: ldur            x16, [fp, #-0xa8]
    // 0xcb914c: SaveReg r16
    //     0xcb914c: str             x16, [SP, #-8]!
    // 0xcb9150: r0 = print()
    //     0xcb9150: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xcb9154: add             SP, SP, #8
    // 0xcb9158: ldur            x2, [fp, #-0x50]
    // 0xcb915c: ldur            x1, [fp, #-0x58]
    // 0xcb9160: ldur            x0, [fp, #-0x78]
    // 0xcb9164: mov             x3, x2
    // 0xcb9168: mov             x2, x1
    // 0xcb916c: mov             x1, x0
    // 0xcb9170: r0 = true
    //     0xcb9170: add             x0, NULL, #0x20  ; true
    // 0xcb9174: stur            x2, [fp, #-0xb0]
    // 0xcb9178: LoadField: r4 = r1->field_7
    //     0xcb9178: ldur            x4, [x1, #7]
    // 0xcb917c: cmp             x4, #2
    // 0xcb9180: b.gt            #0xcb91a8
    // 0xcb9184: cmp             x4, #1
    // 0xcb9188: b.gt            #0xcb91c4
    // 0xcb918c: cmp             x4, #0
    // 0xcb9190: b.le            #0xcb91c4
    // 0xcb9194: tbnz            w0, #4, #0xcb91c4
    // 0xcb9198: r0 = Null
    //     0xcb9198: mov             x0, NULL
    // 0xcb919c: LeaveFrame
    //     0xcb919c: mov             SP, fp
    //     0xcb91a0: ldp             fp, lr, [SP], #0x10
    // 0xcb91a4: ret
    //     0xcb91a4: ret             
    // 0xcb91a8: cmp             x4, #3
    // 0xcb91ac: b.gt            #0xcb9260
    // 0xcb91b0: tbnz            w0, #4, #0xcb91c4
    // 0xcb91b4: r0 = Null
    //     0xcb91b4: mov             x0, NULL
    // 0xcb91b8: LeaveFrame
    //     0xcb91b8: mov             SP, fp
    //     0xcb91bc: ldp             fp, lr, [SP], #0x10
    // 0xcb91c0: ret
    //     0xcb91c0: ret             
    // 0xcb91c4: r0 = LoadTaggedClassIdMayBeSmiInstr(r3)
    //     0xcb91c4: mov             x0, #0x76
    //     0xcb91c8: tbz             w3, #0, #0xcb91d8
    //     0xcb91cc: ldur            x0, [x3, #-1]
    //     0xcb91d0: ubfx            x0, x0, #0xc, #0x14
    //     0xcb91d4: lsl             x0, x0, #1
    // 0xcb91d8: cmp             w0, #0x76
    // 0xcb91dc: b.ne            #0xcb91e8
    // 0xcb91e0: cmn             w3, #0x10
    // 0xcb91e4: b.eq            #0xcb9250
    // 0xcb91e8: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xcb91e8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb91ec: ldr             x0, [x0, #0xb58]
    //     0xcb91f0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb91f4: cmp             w0, w16
    //     0xcb91f8: b.ne            #0xcb9204
    //     0xcb91fc: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xcb9200: bl              #0xd67d44
    // 0xcb9204: r0 = InitLateStaticField(0x6ec) // [dart:io] ::_ioOverridesToken
    //     0xcb9204: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb9208: ldr             x0, [x0, #0xdd8]
    //     0xcb920c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb9210: cmp             w0, w16
    //     0xcb9214: b.ne            #0xcb9220
    //     0xcb9218: ldr             x2, [PP, #0x2820]  ; [pp+0x2820] Field <::._ioOverridesToken@14069316>: static late final (offset: 0x6ec)
    //     0xcb921c: bl              #0xd67cdc
    // 0xcb9220: r0 = InitLateStaticField(0x6f4) // [dart:io] ::_stdout
    //     0xcb9220: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcb9224: ldr             x0, [x0, #0xde8]
    //     0xcb9228: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcb922c: cmp             w0, w16
    //     0xcb9230: b.ne            #0xcb9240
    //     0xcb9234: add             x2, PP, #0xa, lsl #12  ; [pp+0xad20] Field <::._stdout@14069316>: static late final (offset: 0x6f4)
    //     0xcb9238: ldr             x2, [x2, #0xd20]
    //     0xcb923c: bl              #0xd67cdc
    // 0xcb9240: ldur            x16, [fp, #-0xb0]
    // 0xcb9244: stp             x16, x0, [SP, #-0x10]!
    // 0xcb9248: r0 = write()
    //     0xcb9248: bl              #0xc25cd0  ; [dart:io] _StdSink::write
    // 0xcb924c: add             SP, SP, #0x10
    // 0xcb9250: r0 = Null
    //     0xcb9250: mov             x0, NULL
    // 0xcb9254: LeaveFrame
    //     0xcb9254: mov             SP, fp
    //     0xcb9258: ldp             fp, lr, [SP], #0x10
    // 0xcb925c: ret
    //     0xcb925c: ret             
    // 0xcb9260: r0 = Null
    //     0xcb9260: mov             x0, NULL
    // 0xcb9264: LeaveFrame
    //     0xcb9264: mov             SP, fp
    //     0xcb9268: ldp             fp, lr, [SP], #0x10
    // 0xcb926c: ret
    //     0xcb926c: ret             
    // 0xcb9270: ldur            x1, [fp, #-0xa0]
    // 0xcb9274: mov             x0, x1
    // 0xcb9278: ldur            x1, [fp, #-0xa8]
    // 0xcb927c: r0 = ReThrow()
    //     0xcb927c: bl              #0xd67e14  ; ReThrowStub
    // 0xcb9280: brk             #0
    // 0xcb9284: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb9284: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb9288: b               #0xcb8dd0
  }
}

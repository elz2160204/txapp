// lib: , url: package:ffmpeg_kit_flutter_min/ffprobe_session.dart

// class id: 1049004, size: 0x8
class :: {
}

// class id: 4421, size: 0xc, field offset: 0xc
class FFprobeSession extends AbstractSession {

  _ getCompleteCallback(/* No info */) {
    // ** addr: 0xcb8438, size: 0x40
    // 0xcb8438: EnterFrame
    //     0xcb8438: stp             fp, lr, [SP, #-0x10]!
    //     0xcb843c: mov             fp, SP
    // 0xcb8440: CheckStackOverflow
    //     0xcb8440: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb8444: cmp             SP, x16
    //     0xcb8448: b.ls            #0xcb8470
    // 0xcb844c: ldr             x0, [fp, #0x10]
    // 0xcb8450: LoadField: r1 = r0->field_7
    //     0xcb8450: ldur            w1, [x0, #7]
    // 0xcb8454: DecompressPointer r1
    //     0xcb8454: add             x1, x1, HEAP, lsl #32
    // 0xcb8458: SaveReg r1
    //     0xcb8458: str             x1, [SP, #-8]!
    // 0xcb845c: r0 = getFFprobeSessionCompleteCallback()
    //     0xcb845c: bl              #0xcb8478  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] FFmpegKitFactory::getFFprobeSessionCompleteCallback
    // 0xcb8460: add             SP, SP, #8
    // 0xcb8464: LeaveFrame
    //     0xcb8464: mov             SP, fp
    //     0xcb8468: ldp             fp, lr, [SP], #0x10
    // 0xcb846c: ret
    //     0xcb846c: ret             
    // 0xcb8470: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb8470: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb8474: b               #0xcb844c
  }
}

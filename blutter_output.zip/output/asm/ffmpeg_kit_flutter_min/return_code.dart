// lib: , url: package:ffmpeg_kit_flutter_min/return_code.dart

// class id: 1049014, size: 0x8
class :: {
}

// class id: 4411, size: 0x10, field offset: 0x8
class ReturnCode extends Object {

  static _ isCancel(/* No info */) {
    // ** addr: 0xa371f8, size: 0x54
    // 0xa371f8: EnterFrame
    //     0xa371f8: stp             fp, lr, [SP, #-0x10]!
    //     0xa371fc: mov             fp, SP
    // 0xa37200: ldr             x2, [fp, #0x10]
    // 0xa37204: cmp             w2, NULL
    // 0xa37208: b.ne            #0xa37214
    // 0xa3720c: r1 = Null
    //     0xa3720c: mov             x1, NULL
    // 0xa37210: b               #0xa37230
    // 0xa37214: LoadField: r3 = r2->field_7
    //     0xa37214: ldur            x3, [x2, #7]
    // 0xa37218: r0 = BoxInt64Instr(r3)
    //     0xa37218: sbfiz           x0, x3, #1, #0x1f
    //     0xa3721c: cmp             x3, x0, asr #1
    //     0xa37220: b.eq            #0xa3722c
    //     0xa37224: bl              #0xd69bb8
    //     0xa37228: stur            x3, [x0, #7]
    // 0xa3722c: mov             x1, x0
    // 0xa37230: cmp             w1, #0x1fe
    // 0xa37234: r16 = true
    //     0xa37234: add             x16, NULL, #0x20  ; true
    // 0xa37238: r17 = false
    //     0xa37238: add             x17, NULL, #0x30  ; false
    // 0xa3723c: csel            x0, x16, x17, eq
    // 0xa37240: LeaveFrame
    //     0xa37240: mov             SP, fp
    //     0xa37244: ldp             fp, lr, [SP], #0x10
    // 0xa37248: ret
    //     0xa37248: ret             
  }
  static _ isSuccess(/* No info */) {
    // ** addr: 0xa3766c, size: 0x54
    // 0xa3766c: EnterFrame
    //     0xa3766c: stp             fp, lr, [SP, #-0x10]!
    //     0xa37670: mov             fp, SP
    // 0xa37674: ldr             x2, [fp, #0x10]
    // 0xa37678: cmp             w2, NULL
    // 0xa3767c: b.ne            #0xa37688
    // 0xa37680: r1 = Null
    //     0xa37680: mov             x1, NULL
    // 0xa37684: b               #0xa376a4
    // 0xa37688: LoadField: r3 = r2->field_7
    //     0xa37688: ldur            x3, [x2, #7]
    // 0xa3768c: r0 = BoxInt64Instr(r3)
    //     0xa3768c: sbfiz           x0, x3, #1, #0x1f
    //     0xa37690: cmp             x3, x0, asr #1
    //     0xa37694: b.eq            #0xa376a0
    //     0xa37698: bl              #0xd69bb8
    //     0xa3769c: stur            x3, [x0, #7]
    // 0xa376a0: mov             x1, x0
    // 0xa376a4: cbz             w1, #0xa376b0
    // 0xa376a8: r0 = false
    //     0xa376a8: add             x0, NULL, #0x30  ; false
    // 0xa376ac: b               #0xa376b4
    // 0xa376b0: r0 = true
    //     0xa376b0: add             x0, NULL, #0x20  ; true
    // 0xa376b4: LeaveFrame
    //     0xa376b4: mov             SP, fp
    //     0xa376b8: ldp             fp, lr, [SP], #0x10
    // 0xa376bc: ret
    //     0xa376bc: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0xad41bc, size: 0x74
    // 0xad41bc: EnterFrame
    //     0xad41bc: stp             fp, lr, [SP, #-0x10]!
    //     0xad41c0: mov             fp, SP
    // 0xad41c4: CheckStackOverflow
    //     0xad41c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad41c8: cmp             SP, x16
    //     0xad41cc: b.ls            #0xad4228
    // 0xad41d0: ldr             x0, [fp, #0x10]
    // 0xad41d4: LoadField: r2 = r0->field_7
    //     0xad41d4: ldur            x2, [x0, #7]
    // 0xad41d8: r0 = BoxInt64Instr(r2)
    //     0xad41d8: sbfiz           x0, x2, #1, #0x1f
    //     0xad41dc: cmp             x2, x0, asr #1
    //     0xad41e0: b.eq            #0xad41ec
    //     0xad41e4: bl              #0xd69bb8
    //     0xad41e8: stur            x2, [x0, #7]
    // 0xad41ec: r1 = 59
    //     0xad41ec: mov             x1, #0x3b
    // 0xad41f0: branchIfSmi(r0, 0xad41fc)
    //     0xad41f0: tbz             w0, #0, #0xad41fc
    // 0xad41f4: r1 = LoadClassIdInstr(r0)
    //     0xad41f4: ldur            x1, [x0, #-1]
    //     0xad41f8: ubfx            x1, x1, #0xc, #0x14
    // 0xad41fc: SaveReg r0
    //     0xad41fc: str             x0, [SP, #-8]!
    // 0xad4200: mov             x0, x1
    // 0xad4204: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xad4204: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xad4208: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xad4208: mov             x17, #0x3f73
    //     0xad420c: add             lr, x0, x17
    //     0xad4210: ldr             lr, [x21, lr, lsl #3]
    //     0xad4214: blr             lr
    // 0xad4218: add             SP, SP, #8
    // 0xad421c: LeaveFrame
    //     0xad421c: mov             SP, fp
    //     0xad4220: ldp             fp, lr, [SP], #0x10
    // 0xad4224: ret
    //     0xad4224: ret             
    // 0xad4228: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad4228: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad422c: b               #0xad41d0
  }
}

// lib: , url: package:ffmpeg_kit_flutter_min/ffmpeg_kit.dart

// class id: 1049000, size: 0x8
class :: {
}

// class id: 4416, size: 0x8, field offset: 0x8
abstract class FFmpegKit extends Object {

  static late FFmpegKitPlatform _platform; // offset: 0xc90

  static _ execute(/* No info */) async {
    // ** addr: 0xa352f4, size: 0x60
    // 0xa352f4: EnterFrame
    //     0xa352f4: stp             fp, lr, [SP, #-0x10]!
    //     0xa352f8: mov             fp, SP
    // 0xa352fc: AllocStack(0x10)
    //     0xa352fc: sub             SP, SP, #0x10
    // 0xa35300: SetupParameters(dynamic _ /* r1, fp-0x10 */)
    //     0xa35300: stur            NULL, [fp, #-8]
    //     0xa35304: mov             x0, #0
    //     0xa35308: add             x1, fp, w0, sxtw #2
    //     0xa3530c: ldr             x1, [x1, #0x10]
    //     0xa35310: stur            x1, [fp, #-0x10]
    // 0xa35314: CheckStackOverflow
    //     0xa35314: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa35318: cmp             SP, x16
    //     0xa3531c: b.ls            #0xa3534c
    // 0xa35320: InitAsync() -> Future<FFmpegSession>
    //     0xa35320: add             x0, PP, #0x2f, lsl #12  ; [pp+0x2ffb0] TypeArguments: <FFmpegSession>
    //     0xa35324: ldr             x0, [x0, #0xfb0]
    //     0xa35328: bl              #0x4b92e4
    // 0xa3532c: ldur            x16, [fp, #-0x10]
    // 0xa35330: SaveReg r16
    //     0xa35330: str             x16, [SP, #-8]!
    // 0xa35334: r0 = parseArguments()
    //     0xa35334: bl              #0xa36acc  ; [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::parseArguments
    // 0xa35338: add             SP, SP, #8
    // 0xa3533c: SaveReg r0
    //     0xa3533c: str             x0, [SP, #-8]!
    // 0xa35340: r0 = executeWithArguments()
    //     0xa35340: bl              #0xa35354  ; [package:ffmpeg_kit_flutter_min/ffmpeg_kit.dart] FFmpegKit::executeWithArguments
    // 0xa35344: add             SP, SP, #8
    // 0xa35348: r0 = ReturnAsync()
    //     0xa35348: b               #0x501858  ; ReturnAsyncStub
    // 0xa3534c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa3534c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa35350: b               #0xa35320
  }
  static _ executeWithArguments(/* No info */) async {
    // ** addr: 0xa35354, size: 0x80
    // 0xa35354: EnterFrame
    //     0xa35354: stp             fp, lr, [SP, #-0x10]!
    //     0xa35358: mov             fp, SP
    // 0xa3535c: AllocStack(0x18)
    //     0xa3535c: sub             SP, SP, #0x18
    // 0xa35360: SetupParameters(dynamic _ /* r1, fp-0x10 */)
    //     0xa35360: stur            NULL, [fp, #-8]
    //     0xa35364: mov             x0, #0
    //     0xa35368: add             x1, fp, w0, sxtw #2
    //     0xa3536c: ldr             x1, [x1, #0x10]
    //     0xa35370: stur            x1, [fp, #-0x10]
    // 0xa35374: CheckStackOverflow
    //     0xa35374: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa35378: cmp             SP, x16
    //     0xa3537c: b.ls            #0xa353cc
    // 0xa35380: InitAsync() -> Future<FFmpegSession>
    //     0xa35380: add             x0, PP, #0x2f, lsl #12  ; [pp+0x2ffb0] TypeArguments: <FFmpegSession>
    //     0xa35384: ldr             x0, [x0, #0xfb0]
    //     0xa35388: bl              #0x4b92e4
    // 0xa3538c: ldur            x16, [fp, #-0x10]
    // 0xa35390: SaveReg r16
    //     0xa35390: str             x16, [SP, #-8]!
    // 0xa35394: r0 = create()
    //     0xa35394: bl              #0xa36524  ; [package:ffmpeg_kit_flutter_min/ffmpeg_session.dart] FFmpegSession::create
    // 0xa35398: add             SP, SP, #8
    // 0xa3539c: mov             x1, x0
    // 0xa353a0: stur            x1, [fp, #-0x10]
    // 0xa353a4: r0 = Await()
    //     0xa353a4: bl              #0x4b8e6c  ; AwaitStub
    // 0xa353a8: stur            x0, [fp, #-0x10]
    // 0xa353ac: SaveReg r0
    //     0xa353ac: str             x0, [SP, #-8]!
    // 0xa353b0: r0 = ffmpegExecute()
    //     0xa353b0: bl              #0xa353d4  ; [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::ffmpegExecute
    // 0xa353b4: add             SP, SP, #8
    // 0xa353b8: mov             x1, x0
    // 0xa353bc: stur            x1, [fp, #-0x18]
    // 0xa353c0: r0 = Await()
    //     0xa353c0: bl              #0x4b8e6c  ; AwaitStub
    // 0xa353c4: ldur            x0, [fp, #-0x10]
    // 0xa353c8: r0 = ReturnAsync()
    //     0xa353c8: b               #0x501858  ; ReturnAsyncStub
    // 0xa353cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa353cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa353d0: b               #0xa35380
  }
  static _ cancel(/* No info */) async {
    // ** addr: 0xa59b70, size: 0x134
    // 0xa59b70: EnterFrame
    //     0xa59b70: stp             fp, lr, [SP, #-0x10]!
    //     0xa59b74: mov             fp, SP
    // 0xa59b78: AllocStack(0x58)
    //     0xa59b78: sub             SP, SP, #0x58
    // 0xa59b7c: SetupParameters(dynamic _ /* r1, fp-0x48 */)
    //     0xa59b7c: stur            NULL, [fp, #-8]
    //     0xa59b80: mov             x0, #0
    //     0xa59b84: add             x1, fp, w0, sxtw #2
    //     0xa59b88: ldr             x1, [x1, #0x10]
    //     0xa59b8c: stur            x1, [fp, #-0x48]
    // 0xa59b90: CheckStackOverflow
    //     0xa59b90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa59b94: cmp             SP, x16
    //     0xa59b98: b.ls            #0xa59c9c
    // 0xa59b9c: InitAsync() -> Future<void?>
    //     0xa59b9c: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xa59ba0: bl              #0x4b92e4
    // 0xa59ba4: ldur            x0, [fp, #-0x48]
    // 0xa59ba8: r0 = init()
    //     0xa59ba8: bl              #0xa355ac  ; [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::init
    // 0xa59bac: mov             x1, x0
    // 0xa59bb0: stur            x1, [fp, #-0x50]
    // 0xa59bb4: r0 = Await()
    //     0xa59bb4: bl              #0x4b8e6c  ; AwaitStub
    // 0xa59bb8: r0 = InitLateStaticField(0xc90) // [package:ffmpeg_kit_flutter_min/ffmpeg_kit.dart] FFmpegKit::_platform
    //     0xa59bb8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa59bbc: ldr             x0, [x0, #0x1920]
    //     0xa59bc0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa59bc4: cmp             w0, w16
    //     0xa59bc8: b.ne            #0xa59bd8
    //     0xa59bcc: add             x2, PP, #0x2f, lsl #12  ; [pp+0x2fcf8] Field <FFmpegKit._platform@531327875>: static late (offset: 0xc90)
    //     0xa59bd0: ldr             x2, [x2, #0xcf8]
    //     0xa59bd4: bl              #0xd67d44
    // 0xa59bd8: SaveReg r0
    //     0xa59bd8: str             x0, [SP, #-8]!
    // 0xa59bdc: ldur            x0, [fp, #-0x48]
    // 0xa59be0: SaveReg r0
    //     0xa59be0: str             x0, [SP, #-8]!
    // 0xa59be4: r0 = ffmpegKitCancelSession()
    //     0xa59be4: bl              #0xa59ca4  ; [package:ffmpeg_kit_flutter_platform_interface/method_channel_ffmpeg_kit_flutter.dart] MethodChannelFFmpegKit::ffmpegKitCancelSession
    // 0xa59be8: add             SP, SP, #0x10
    // 0xa59bec: r0 = ReturnAsync()
    //     0xa59bec: b               #0x501858  ; ReturnAsyncStub
    // 0xa59bf0: sub             SP, fp, #0x58
    // 0xa59bf4: mov             x3, x0
    // 0xa59bf8: stur            x0, [fp, #-0x50]
    // 0xa59bfc: mov             x0, x1
    // 0xa59c00: stur            x1, [fp, #-0x58]
    // 0xa59c04: r1 = LoadTaggedClassIdMayBeSmiInstr(r3)
    //     0xa59c04: mov             x1, #0x76
    //     0xa59c08: tbz             w3, #0, #0xa59c18
    //     0xa59c0c: ldur            x1, [x3, #-1]
    //     0xa59c10: ubfx            x1, x1, #0xc, #0x14
    //     0xa59c14: lsl             x1, x1, #1
    // 0xa59c18: cmp             w1, #0xf28
    // 0xa59c1c: b.ne            #0xa59c88
    // 0xa59c20: r1 = Null
    //     0xa59c20: mov             x1, NULL
    // 0xa59c24: r2 = 4
    //     0xa59c24: mov             x2, #4
    // 0xa59c28: r0 = AllocateArray()
    //     0xa59c28: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa59c2c: r17 = "Plugin cancel error: "
    //     0xa59c2c: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2fd00] "Plugin cancel error: "
    //     0xa59c30: ldr             x17, [x17, #0xd00]
    // 0xa59c34: StoreField: r0->field_f = r17
    //     0xa59c34: stur            w17, [x0, #0xf]
    // 0xa59c38: ldur            x1, [fp, #-0x50]
    // 0xa59c3c: LoadField: r2 = r1->field_b
    //     0xa59c3c: ldur            w2, [x1, #0xb]
    // 0xa59c40: DecompressPointer r2
    //     0xa59c40: add             x2, x2, HEAP, lsl #32
    // 0xa59c44: StoreField: r0->field_13 = r2
    //     0xa59c44: stur            w2, [x0, #0x13]
    // 0xa59c48: SaveReg r0
    //     0xa59c48: str             x0, [SP, #-8]!
    // 0xa59c4c: r0 = _interpolate()
    //     0xa59c4c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa59c50: add             SP, SP, #8
    // 0xa59c54: SaveReg r0
    //     0xa59c54: str             x0, [SP, #-8]!
    // 0xa59c58: r0 = print()
    //     0xa59c58: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xa59c5c: add             SP, SP, #8
    // 0xa59c60: r16 = <void?>
    //     0xa59c60: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xa59c64: r30 = "cancel failed."
    //     0xa59c64: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2fd08] "cancel failed."
    //     0xa59c68: ldr             lr, [lr, #0xd08]
    // 0xa59c6c: stp             lr, x16, [SP, #-0x10]!
    // 0xa59c70: ldur            x16, [fp, #-0x58]
    // 0xa59c74: SaveReg r16
    //     0xa59c74: str             x16, [SP, #-8]!
    // 0xa59c78: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa59c78: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa59c7c: r0 = Future.error()
    //     0xa59c7c: bl              #0x4e95bc  ; [dart:async] Future::Future.error
    // 0xa59c80: add             SP, SP, #0x18
    // 0xa59c84: r0 = ReturnAsync()
    //     0xa59c84: b               #0x501858  ; ReturnAsyncStub
    // 0xa59c88: mov             x1, x3
    // 0xa59c8c: mov             x0, x1
    // 0xa59c90: ldur            x1, [fp, #-0x58]
    // 0xa59c94: r0 = ReThrow()
    //     0xa59c94: bl              #0xd67e14  ; ReThrowStub
    // 0xa59c98: brk             #0
    // 0xa59c9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa59c9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa59ca0: b               #0xa59b9c
  }
}

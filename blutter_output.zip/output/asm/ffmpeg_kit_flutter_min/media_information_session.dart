// lib: , url: package:ffmpeg_kit_flutter_min/media_information_session.dart

// class id: 1049011, size: 0x8
class :: {
}

// class id: 4420, size: 0xc, field offset: 0xc
class MediaInformationSession extends AbstractSession {

  _ getCompleteCallback(/* No info */) {
    // ** addr: 0xcb82b0, size: 0x40
    // 0xcb82b0: EnterFrame
    //     0xcb82b0: stp             fp, lr, [SP, #-0x10]!
    //     0xcb82b4: mov             fp, SP
    // 0xcb82b8: CheckStackOverflow
    //     0xcb82b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb82bc: cmp             SP, x16
    //     0xcb82c0: b.ls            #0xcb82e8
    // 0xcb82c4: ldr             x0, [fp, #0x10]
    // 0xcb82c8: LoadField: r1 = r0->field_7
    //     0xcb82c8: ldur            w1, [x0, #7]
    // 0xcb82cc: DecompressPointer r1
    //     0xcb82cc: add             x1, x1, HEAP, lsl #32
    // 0xcb82d0: SaveReg r1
    //     0xcb82d0: str             x1, [SP, #-8]!
    // 0xcb82d4: r0 = getMediaInformationSessionCompleteCallback()
    //     0xcb82d4: bl              #0xcb82f0  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] FFmpegKitFactory::getMediaInformationSessionCompleteCallback
    // 0xcb82d8: add             SP, SP, #8
    // 0xcb82dc: LeaveFrame
    //     0xcb82dc: mov             SP, fp
    //     0xcb82e0: ldp             fp, lr, [SP], #0x10
    // 0xcb82e4: ret
    //     0xcb82e4: ret             
    // 0xcb82e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb82e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb82ec: b               #0xcb82c4
  }
}

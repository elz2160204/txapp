// lib: , url: package:ffmpeg_kit_flutter_min/log_redirection_strategy.dart

// class id: 1049009, size: 0x8
class :: {
}

// class id: 5992, size: 0x14, field offset: 0x14
enum LogRedirectionStrategy extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb159ac, size: 0x5c
    // 0xb159ac: EnterFrame
    //     0xb159ac: stp             fp, lr, [SP, #-0x10]!
    //     0xb159b0: mov             fp, SP
    // 0xb159b4: CheckStackOverflow
    //     0xb159b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb159b8: cmp             SP, x16
    //     0xb159bc: b.ls            #0xb15a00
    // 0xb159c0: r1 = Null
    //     0xb159c0: mov             x1, NULL
    // 0xb159c4: r2 = 4
    //     0xb159c4: mov             x2, #4
    // 0xb159c8: r0 = AllocateArray()
    //     0xb159c8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb159cc: r17 = "LogRedirectionStrategy."
    //     0xb159cc: add             x17, PP, #0x40, lsl #12  ; [pp+0x40a00] "LogRedirectionStrategy."
    //     0xb159d0: ldr             x17, [x17, #0xa00]
    // 0xb159d4: StoreField: r0->field_f = r17
    //     0xb159d4: stur            w17, [x0, #0xf]
    // 0xb159d8: ldr             x1, [fp, #0x10]
    // 0xb159dc: LoadField: r2 = r1->field_f
    //     0xb159dc: ldur            w2, [x1, #0xf]
    // 0xb159e0: DecompressPointer r2
    //     0xb159e0: add             x2, x2, HEAP, lsl #32
    // 0xb159e4: StoreField: r0->field_13 = r2
    //     0xb159e4: stur            w2, [x0, #0x13]
    // 0xb159e8: SaveReg r0
    //     0xb159e8: str             x0, [SP, #-8]!
    // 0xb159ec: r0 = _interpolate()
    //     0xb159ec: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb159f0: add             SP, SP, #8
    // 0xb159f4: LeaveFrame
    //     0xb159f4: mov             SP, fp
    //     0xb159f8: ldp             fp, lr, [SP], #0x10
    // 0xb159fc: ret
    //     0xb159fc: ret             
    // 0xb15a00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15a00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15a04: b               #0xb159c0
  }
}

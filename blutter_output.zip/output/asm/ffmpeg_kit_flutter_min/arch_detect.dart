// lib: , url: package:ffmpeg_kit_flutter_min/arch_detect.dart

// class id: 1048998, size: 0x8
class :: {
}

// class id: 4417, size: 0x8, field offset: 0x8
abstract class ArchDetect extends Object {

  static late FFmpegKitPlatform _platform; // offset: 0xc8c

  static _ getArch(/* No info */) async {
    // ** addr: 0xa35e58, size: 0x118
    // 0xa35e58: EnterFrame
    //     0xa35e58: stp             fp, lr, [SP, #-0x10]!
    //     0xa35e5c: mov             fp, SP
    // 0xa35e60: AllocStack(0x48)
    //     0xa35e60: sub             SP, SP, #0x48
    // 0xa35e64: SetupParameters()
    //     0xa35e64: stur            NULL, [fp, #-8]
    // 0xa35e68: CheckStackOverflow
    //     0xa35e68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa35e6c: cmp             SP, x16
    //     0xa35e70: b.ls            #0xa35f68
    // 0xa35e74: InitAsync() -> Future<String>
    //     0xa35e74: ldr             x0, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    //     0xa35e78: bl              #0x4b92e4
    // 0xa35e7c: r0 = init()
    //     0xa35e7c: bl              #0xa355ac  ; [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::init
    // 0xa35e80: mov             x1, x0
    // 0xa35e84: stur            x1, [fp, #-0x40]
    // 0xa35e88: r0 = Await()
    //     0xa35e88: bl              #0x4b8e6c  ; AwaitStub
    // 0xa35e8c: r0 = InitLateStaticField(0xc8c) // [package:ffmpeg_kit_flutter_min/arch_detect.dart] ArchDetect::_platform
    //     0xa35e8c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa35e90: ldr             x0, [x0, #0x1918]
    //     0xa35e94: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa35e98: cmp             w0, w16
    //     0xa35e9c: b.ne            #0xa35eac
    //     0xa35ea0: add             x2, PP, #0x2f, lsl #12  ; [pp+0x2fdc8] Field <ArchDetect._platform@529394384>: static late (offset: 0xc8c)
    //     0xa35ea4: ldr             x2, [x2, #0xdc8]
    //     0xa35ea8: bl              #0xd67d44
    // 0xa35eac: SaveReg r0
    //     0xa35eac: str             x0, [SP, #-8]!
    // 0xa35eb0: r0 = archDetectGetArch()
    //     0xa35eb0: bl              #0xa35f70  ; [package:ffmpeg_kit_flutter_platform_interface/method_channel_ffmpeg_kit_flutter.dart] MethodChannelFFmpegKit::archDetectGetArch
    // 0xa35eb4: add             SP, SP, #8
    // 0xa35eb8: r0 = ReturnAsync()
    //     0xa35eb8: b               #0x501858  ; ReturnAsyncStub
    // 0xa35ebc: sub             SP, fp, #0x48
    // 0xa35ec0: mov             x3, x0
    // 0xa35ec4: stur            x0, [fp, #-0x40]
    // 0xa35ec8: mov             x0, x1
    // 0xa35ecc: stur            x1, [fp, #-0x48]
    // 0xa35ed0: r1 = LoadTaggedClassIdMayBeSmiInstr(r3)
    //     0xa35ed0: mov             x1, #0x76
    //     0xa35ed4: tbz             w3, #0, #0xa35ee4
    //     0xa35ed8: ldur            x1, [x3, #-1]
    //     0xa35edc: ubfx            x1, x1, #0xc, #0x14
    //     0xa35ee0: lsl             x1, x1, #1
    // 0xa35ee4: cmp             w1, #0xf28
    // 0xa35ee8: b.ne            #0xa35f54
    // 0xa35eec: r1 = Null
    //     0xa35eec: mov             x1, NULL
    // 0xa35ef0: r2 = 4
    //     0xa35ef0: mov             x2, #4
    // 0xa35ef4: r0 = AllocateArray()
    //     0xa35ef4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa35ef8: r17 = "Plugin getArch error: "
    //     0xa35ef8: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2fdd0] "Plugin getArch error: "
    //     0xa35efc: ldr             x17, [x17, #0xdd0]
    // 0xa35f00: StoreField: r0->field_f = r17
    //     0xa35f00: stur            w17, [x0, #0xf]
    // 0xa35f04: ldur            x1, [fp, #-0x40]
    // 0xa35f08: LoadField: r2 = r1->field_b
    //     0xa35f08: ldur            w2, [x1, #0xb]
    // 0xa35f0c: DecompressPointer r2
    //     0xa35f0c: add             x2, x2, HEAP, lsl #32
    // 0xa35f10: StoreField: r0->field_13 = r2
    //     0xa35f10: stur            w2, [x0, #0x13]
    // 0xa35f14: SaveReg r0
    //     0xa35f14: str             x0, [SP, #-8]!
    // 0xa35f18: r0 = _interpolate()
    //     0xa35f18: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa35f1c: add             SP, SP, #8
    // 0xa35f20: SaveReg r0
    //     0xa35f20: str             x0, [SP, #-8]!
    // 0xa35f24: r0 = print()
    //     0xa35f24: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xa35f28: add             SP, SP, #8
    // 0xa35f2c: r16 = <String>
    //     0xa35f2c: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xa35f30: r30 = "getArch failed."
    //     0xa35f30: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2fdd8] "getArch failed."
    //     0xa35f34: ldr             lr, [lr, #0xdd8]
    // 0xa35f38: stp             lr, x16, [SP, #-0x10]!
    // 0xa35f3c: ldur            x16, [fp, #-0x48]
    // 0xa35f40: SaveReg r16
    //     0xa35f40: str             x16, [SP, #-8]!
    // 0xa35f44: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa35f44: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa35f48: r0 = Future.error()
    //     0xa35f48: bl              #0x4e95bc  ; [dart:async] Future::Future.error
    // 0xa35f4c: add             SP, SP, #0x18
    // 0xa35f50: r0 = ReturnAsync()
    //     0xa35f50: b               #0x501858  ; ReturnAsyncStub
    // 0xa35f54: mov             x1, x3
    // 0xa35f58: mov             x0, x1
    // 0xa35f5c: ldur            x1, [fp, #-0x48]
    // 0xa35f60: r0 = ReThrow()
    //     0xa35f60: bl              #0xd67e14  ; ReThrowStub
    // 0xa35f64: brk             #0
    // 0xa35f68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa35f68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa35f6c: b               #0xa35e74
  }
}

// lib: , url: package:ffmpeg_kit_flutter_min/abstract_session.dart

// class id: 1048997, size: 0x8
class :: {
}

// class id: 4419, size: 0xc, field offset: 0x8
abstract class AbstractSession extends Session {

  static late FFmpegKitPlatform _platform; // offset: 0xc44

  static FFmpegKitPlatform _platform() {
    // ** addr: 0xa35d70, size: 0x48
    // 0xa35d70: EnterFrame
    //     0xa35d70: stp             fp, lr, [SP, #-0x10]!
    //     0xa35d74: mov             fp, SP
    // 0xa35d78: CheckStackOverflow
    //     0xa35d78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa35d7c: cmp             SP, x16
    //     0xa35d80: b.ls            #0xa35db0
    // 0xa35d84: r0 = InitLateStaticField(0xc4c) // [package:ffmpeg_kit_flutter_platform_interface/ffmpeg_kit_flutter_platform_interface.dart] FFmpegKitPlatform::_instance
    //     0xa35d84: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa35d88: ldr             x0, [x0, #0x1898]
    //     0xa35d8c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa35d90: cmp             w0, w16
    //     0xa35d94: b.ne            #0xa35da4
    //     0xa35d98: add             x2, PP, #0x2f, lsl #12  ; [pp+0x2fd80] Field <FFmpegKitPlatform._instance@516490792>: static late (offset: 0xc4c)
    //     0xa35d9c: ldr             x2, [x2, #0xd80]
    //     0xa35da0: bl              #0xd67d44
    // 0xa35da4: LeaveFrame
    //     0xa35da4: mov             SP, fp
    //     0xa35da8: ldp             fp, lr, [SP], #0x10
    // 0xa35dac: ret
    //     0xa35dac: ret             
    // 0xa35db0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa35db0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa35db4: b               #0xa35d84
  }
  static _ createFFmpegSession(/* No info */) async {
    // ** addr: 0xa365a8, size: 0x3b0
    // 0xa365a8: EnterFrame
    //     0xa365a8: stp             fp, lr, [SP, #-0x10]!
    //     0xa365ac: mov             fp, SP
    // 0xa365b0: AllocStack(0x68)
    //     0xa365b0: sub             SP, SP, #0x68
    // 0xa365b4: SetupParameters(dynamic _ /* r1, fp-0x58 */)
    //     0xa365b4: stur            NULL, [fp, #-8]
    //     0xa365b8: mov             x0, #0
    //     0xa365bc: add             x1, fp, w0, sxtw #2
    //     0xa365c0: ldr             x1, [x1, #0x10]
    //     0xa365c4: stur            x1, [fp, #-0x58]
    // 0xa365c8: CheckStackOverflow
    //     0xa365c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa365cc: cmp             SP, x16
    //     0xa365d0: b.ls            #0xa36950
    // 0xa365d4: InitAsync() -> Future<FFmpegSession>
    //     0xa365d4: add             x0, PP, #0x2f, lsl #12  ; [pp+0x2ffb0] TypeArguments: <FFmpegSession>
    //     0xa365d8: ldr             x0, [x0, #0xfb0]
    //     0xa365dc: bl              #0x4b92e4
    // 0xa365e0: r0 = init()
    //     0xa365e0: bl              #0xa355ac  ; [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::init
    // 0xa365e4: mov             x1, x0
    // 0xa365e8: stur            x1, [fp, #-0x60]
    // 0xa365ec: r0 = Await()
    //     0xa365ec: bl              #0x4b8e6c  ; AwaitStub
    // 0xa365f0: r0 = InitLateStaticField(0xc44) // [package:ffmpeg_kit_flutter_min/abstract_session.dart] AbstractSession::_platform
    //     0xa365f0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa365f4: ldr             x0, [x0, #0x1888]
    //     0xa365f8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa365fc: cmp             w0, w16
    //     0xa36600: b.ne            #0xa36610
    //     0xa36604: add             x2, PP, #0x2f, lsl #12  ; [pp+0x2ff78] Field <AbstractSession._platform@515409998>: static late (offset: 0xc44)
    //     0xa36608: ldr             x2, [x2, #0xf78]
    //     0xa3660c: bl              #0xd67d44
    // 0xa36610: ldur            x16, [fp, #-0x58]
    // 0xa36614: stp             x16, x0, [SP, #-0x10]!
    // 0xa36618: r0 = abstractSessionCreateFFmpegSession()
    //     0xa36618: bl              #0xa369fc  ; [package:ffmpeg_kit_flutter_platform_interface/method_channel_ffmpeg_kit_flutter.dart] MethodChannelFFmpegKit::abstractSessionCreateFFmpegSession
    // 0xa3661c: add             SP, SP, #0x10
    // 0xa36620: mov             x1, x0
    // 0xa36624: stur            x1, [fp, #-0x58]
    // 0xa36628: r0 = Await()
    //     0xa36628: bl              #0x4b8e6c  ; AwaitStub
    // 0xa3662c: stur            x0, [fp, #-0x58]
    // 0xa36630: r0 = FFmpegSession()
    //     0xa36630: bl              #0xa369f0  ; AllocateFFmpegSessionStub -> FFmpegSession (size=0xc)
    // 0xa36634: mov             x2, x0
    // 0xa36638: ldur            x1, [fp, #-0x58]
    // 0xa3663c: stur            x2, [fp, #-0x60]
    // 0xa36640: cmp             w1, NULL
    // 0xa36644: b.ne            #0xa36658
    // 0xa36648: mov             x3, x1
    // 0xa3664c: mov             x4, x2
    // 0xa36650: r5 = Null
    //     0xa36650: mov             x5, NULL
    // 0xa36654: b               #0xa36688
    // 0xa36658: r0 = LoadClassIdInstr(r1)
    //     0xa36658: ldur            x0, [x1, #-1]
    //     0xa3665c: ubfx            x0, x0, #0xc, #0x14
    // 0xa36660: r16 = "sessionId"
    //     0xa36660: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2fd10] "sessionId"
    //     0xa36664: ldr             x16, [x16, #0xd10]
    // 0xa36668: stp             x16, x1, [SP, #-0x10]!
    // 0xa3666c: r0 = GDT[cid_x0 + -0xef]()
    //     0xa3666c: sub             lr, x0, #0xef
    //     0xa36670: ldr             lr, [x21, lr, lsl #3]
    //     0xa36674: blr             lr
    // 0xa36678: add             SP, SP, #0x10
    // 0xa3667c: mov             x5, x0
    // 0xa36680: ldur            x3, [fp, #-0x58]
    // 0xa36684: ldur            x4, [fp, #-0x60]
    // 0xa36688: mov             x0, x5
    // 0xa3668c: stur            x5, [fp, #-0x68]
    // 0xa36690: r2 = Null
    //     0xa36690: mov             x2, NULL
    // 0xa36694: r1 = Null
    //     0xa36694: mov             x1, NULL
    // 0xa36698: branchIfSmi(r0, 0xa366c0)
    //     0xa36698: tbz             w0, #0, #0xa366c0
    // 0xa3669c: r4 = LoadClassIdInstr(r0)
    //     0xa3669c: ldur            x4, [x0, #-1]
    //     0xa366a0: ubfx            x4, x4, #0xc, #0x14
    // 0xa366a4: sub             x4, x4, #0x3b
    // 0xa366a8: cmp             x4, #1
    // 0xa366ac: b.ls            #0xa366c0
    // 0xa366b0: r8 = int?
    //     0xa366b0: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xa366b4: r3 = Null
    //     0xa366b4: add             x3, PP, #0x2f, lsl #12  ; [pp+0x2ffd0] Null
    //     0xa366b8: ldr             x3, [x3, #0xfd0]
    // 0xa366bc: r0 = int?()
    //     0xa366bc: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xa366c0: ldur            x0, [fp, #-0x68]
    // 0xa366c4: ldur            x1, [fp, #-0x60]
    // 0xa366c8: StoreField: r1->field_7 = r0
    //     0xa366c8: stur            w0, [x1, #7]
    //     0xa366cc: tbz             w0, #0, #0xa366e8
    //     0xa366d0: ldurb           w16, [x1, #-1]
    //     0xa366d4: ldurb           w17, [x0, #-1]
    //     0xa366d8: and             x16, x17, x16, lsr #2
    //     0xa366dc: tst             x16, HEAP, lsr #32
    //     0xa366e0: b.eq            #0xa366e8
    //     0xa366e4: bl              #0xd6826c
    // 0xa366e8: ldur            x2, [fp, #-0x58]
    // 0xa366ec: cmp             w2, NULL
    // 0xa366f0: b.ne            #0xa36700
    // 0xa366f4: mov             x3, x2
    // 0xa366f8: r4 = Null
    //     0xa366f8: mov             x4, NULL
    // 0xa366fc: b               #0xa3672c
    // 0xa36700: r0 = LoadClassIdInstr(r2)
    //     0xa36700: ldur            x0, [x2, #-1]
    //     0xa36704: ubfx            x0, x0, #0xc, #0x14
    // 0xa36708: r16 = "createTime"
    //     0xa36708: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2ffe0] "createTime"
    //     0xa3670c: ldr             x16, [x16, #0xfe0]
    // 0xa36710: stp             x16, x2, [SP, #-0x10]!
    // 0xa36714: r0 = GDT[cid_x0 + -0xef]()
    //     0xa36714: sub             lr, x0, #0xef
    //     0xa36718: ldr             lr, [x21, lr, lsl #3]
    //     0xa3671c: blr             lr
    // 0xa36720: add             SP, SP, #0x10
    // 0xa36724: mov             x4, x0
    // 0xa36728: ldur            x3, [fp, #-0x58]
    // 0xa3672c: mov             x0, x4
    // 0xa36730: stur            x4, [fp, #-0x68]
    // 0xa36734: r2 = Null
    //     0xa36734: mov             x2, NULL
    // 0xa36738: r1 = Null
    //     0xa36738: mov             x1, NULL
    // 0xa3673c: branchIfSmi(r0, 0xa36764)
    //     0xa3673c: tbz             w0, #0, #0xa36764
    // 0xa36740: r4 = LoadClassIdInstr(r0)
    //     0xa36740: ldur            x4, [x0, #-1]
    //     0xa36744: ubfx            x4, x4, #0xc, #0x14
    // 0xa36748: sub             x4, x4, #0x3b
    // 0xa3674c: cmp             x4, #1
    // 0xa36750: b.ls            #0xa36764
    // 0xa36754: r8 = int?
    //     0xa36754: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xa36758: r3 = Null
    //     0xa36758: add             x3, PP, #0x2f, lsl #12  ; [pp+0x2ffe8] Null
    //     0xa3675c: ldr             x3, [x3, #0xfe8]
    // 0xa36760: r0 = int?()
    //     0xa36760: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xa36764: ldur            x16, [fp, #-0x68]
    // 0xa36768: SaveReg r16
    //     0xa36768: str             x16, [SP, #-8]!
    // 0xa3676c: r0 = validDate()
    //     0xa3676c: bl              #0xa36958  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] FFmpegKitFactory::validDate
    // 0xa36770: add             SP, SP, #8
    // 0xa36774: ldur            x1, [fp, #-0x58]
    // 0xa36778: cmp             w1, NULL
    // 0xa3677c: b.ne            #0xa3678c
    // 0xa36780: mov             x3, x1
    // 0xa36784: r4 = Null
    //     0xa36784: mov             x4, NULL
    // 0xa36788: b               #0xa367b4
    // 0xa3678c: r0 = LoadClassIdInstr(r1)
    //     0xa3678c: ldur            x0, [x1, #-1]
    //     0xa36790: ubfx            x0, x0, #0xc, #0x14
    // 0xa36794: r16 = "startTime"
    //     0xa36794: ldr             x16, [PP, #0x2aa8]  ; [pp+0x2aa8] "startTime"
    // 0xa36798: stp             x16, x1, [SP, #-0x10]!
    // 0xa3679c: r0 = GDT[cid_x0 + -0xef]()
    //     0xa3679c: sub             lr, x0, #0xef
    //     0xa367a0: ldr             lr, [x21, lr, lsl #3]
    //     0xa367a4: blr             lr
    // 0xa367a8: add             SP, SP, #0x10
    // 0xa367ac: mov             x4, x0
    // 0xa367b0: ldur            x3, [fp, #-0x58]
    // 0xa367b4: mov             x0, x4
    // 0xa367b8: stur            x4, [fp, #-0x68]
    // 0xa367bc: r2 = Null
    //     0xa367bc: mov             x2, NULL
    // 0xa367c0: r1 = Null
    //     0xa367c0: mov             x1, NULL
    // 0xa367c4: branchIfSmi(r0, 0xa367ec)
    //     0xa367c4: tbz             w0, #0, #0xa367ec
    // 0xa367c8: r4 = LoadClassIdInstr(r0)
    //     0xa367c8: ldur            x4, [x0, #-1]
    //     0xa367cc: ubfx            x4, x4, #0xc, #0x14
    // 0xa367d0: sub             x4, x4, #0x3b
    // 0xa367d4: cmp             x4, #1
    // 0xa367d8: b.ls            #0xa367ec
    // 0xa367dc: r8 = int?
    //     0xa367dc: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xa367e0: r3 = Null
    //     0xa367e0: add             x3, PP, #0x2f, lsl #12  ; [pp+0x2fff8] Null
    //     0xa367e4: ldr             x3, [x3, #0xff8]
    // 0xa367e8: r0 = int?()
    //     0xa367e8: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xa367ec: ldur            x16, [fp, #-0x68]
    // 0xa367f0: SaveReg r16
    //     0xa367f0: str             x16, [SP, #-8]!
    // 0xa367f4: r0 = validDate()
    //     0xa367f4: bl              #0xa36958  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] FFmpegKitFactory::validDate
    // 0xa367f8: add             SP, SP, #8
    // 0xa367fc: ldur            x0, [fp, #-0x58]
    // 0xa36800: cmp             w0, NULL
    // 0xa36804: b.ne            #0xa36810
    // 0xa36808: r3 = Null
    //     0xa36808: mov             x3, NULL
    // 0xa3680c: b               #0xa3683c
    // 0xa36810: r1 = LoadClassIdInstr(r0)
    //     0xa36810: ldur            x1, [x0, #-1]
    //     0xa36814: ubfx            x1, x1, #0xc, #0x14
    // 0xa36818: r16 = "command"
    //     0xa36818: add             x16, PP, #0x30, lsl #12  ; [pp+0x30008] "command"
    //     0xa3681c: ldr             x16, [x16, #8]
    // 0xa36820: stp             x16, x0, [SP, #-0x10]!
    // 0xa36824: mov             x0, x1
    // 0xa36828: r0 = GDT[cid_x0 + -0xef]()
    //     0xa36828: sub             lr, x0, #0xef
    //     0xa3682c: ldr             lr, [x21, lr, lsl #3]
    //     0xa36830: blr             lr
    // 0xa36834: add             SP, SP, #0x10
    // 0xa36838: mov             x3, x0
    // 0xa3683c: mov             x0, x3
    // 0xa36840: stur            x3, [fp, #-0x58]
    // 0xa36844: r2 = Null
    //     0xa36844: mov             x2, NULL
    // 0xa36848: r1 = Null
    //     0xa36848: mov             x1, NULL
    // 0xa3684c: r4 = 59
    //     0xa3684c: mov             x4, #0x3b
    // 0xa36850: branchIfSmi(r0, 0xa3685c)
    //     0xa36850: tbz             w0, #0, #0xa3685c
    // 0xa36854: r4 = LoadClassIdInstr(r0)
    //     0xa36854: ldur            x4, [x0, #-1]
    //     0xa36858: ubfx            x4, x4, #0xc, #0x14
    // 0xa3685c: sub             x4, x4, #0x5d
    // 0xa36860: cmp             x4, #3
    // 0xa36864: b.ls            #0xa36878
    // 0xa36868: r8 = String?
    //     0xa36868: ldr             x8, [PP, #0x2148]  ; [pp+0x2148] Type: String?
    // 0xa3686c: r3 = Null
    //     0xa3686c: add             x3, PP, #0x30, lsl #12  ; [pp+0x30010] Null
    //     0xa36870: ldr             x3, [x3, #0x10]
    // 0xa36874: r0 = String?()
    //     0xa36874: bl              #0x4b2994  ; IsType_String?_Stub
    // 0xa36878: r0 = InitLateStaticField(0xc54) // [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::_globalLogRedirectionStrategy
    //     0xa36878: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa3687c: ldr             x0, [x0, #0x18a8]
    //     0xa36880: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa36884: cmp             w0, w16
    //     0xa36888: b.ne            #0xa36898
    //     0xa3688c: add             x2, PP, #0x30, lsl #12  ; [pp+0x30020] Field <FFmpegKitConfig._globalLogRedirectionStrategy@517022016>: static late (offset: 0xc54)
    //     0xa36890: ldr             x2, [x2, #0x20]
    //     0xa36894: bl              #0xd67d44
    // 0xa36898: ldur            x0, [fp, #-0x60]
    // 0xa3689c: r0 = ReturnAsyncNotFuture()
    //     0xa3689c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xa368a0: sub             SP, fp, #0x68
    // 0xa368a4: mov             x3, x0
    // 0xa368a8: stur            x0, [fp, #-0x58]
    // 0xa368ac: mov             x0, x1
    // 0xa368b0: stur            x1, [fp, #-0x60]
    // 0xa368b4: r1 = LoadTaggedClassIdMayBeSmiInstr(r3)
    //     0xa368b4: mov             x1, #0x76
    //     0xa368b8: tbz             w3, #0, #0xa368c8
    //     0xa368bc: ldur            x1, [x3, #-1]
    //     0xa368c0: ubfx            x1, x1, #0xc, #0x14
    //     0xa368c4: lsl             x1, x1, #1
    // 0xa368c8: cmp             w1, #0xf28
    // 0xa368cc: b.ne            #0xa3693c
    // 0xa368d0: r1 = Null
    //     0xa368d0: mov             x1, NULL
    // 0xa368d4: r2 = 4
    //     0xa368d4: mov             x2, #4
    // 0xa368d8: r0 = AllocateArray()
    //     0xa368d8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa368dc: r17 = "Plugin createFFmpegSession error: "
    //     0xa368dc: add             x17, PP, #0x30, lsl #12  ; [pp+0x30028] "Plugin createFFmpegSession error: "
    //     0xa368e0: ldr             x17, [x17, #0x28]
    // 0xa368e4: StoreField: r0->field_f = r17
    //     0xa368e4: stur            w17, [x0, #0xf]
    // 0xa368e8: ldur            x1, [fp, #-0x58]
    // 0xa368ec: LoadField: r2 = r1->field_b
    //     0xa368ec: ldur            w2, [x1, #0xb]
    // 0xa368f0: DecompressPointer r2
    //     0xa368f0: add             x2, x2, HEAP, lsl #32
    // 0xa368f4: StoreField: r0->field_13 = r2
    //     0xa368f4: stur            w2, [x0, #0x13]
    // 0xa368f8: SaveReg r0
    //     0xa368f8: str             x0, [SP, #-8]!
    // 0xa368fc: r0 = _interpolate()
    //     0xa368fc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa36900: add             SP, SP, #8
    // 0xa36904: SaveReg r0
    //     0xa36904: str             x0, [SP, #-8]!
    // 0xa36908: r0 = print()
    //     0xa36908: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xa3690c: add             SP, SP, #8
    // 0xa36910: r16 = <FFmpegSession>
    //     0xa36910: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2ffb0] TypeArguments: <FFmpegSession>
    //     0xa36914: ldr             x16, [x16, #0xfb0]
    // 0xa36918: r30 = "createFFmpegSession failed."
    //     0xa36918: add             lr, PP, #0x30, lsl #12  ; [pp+0x30030] "createFFmpegSession failed."
    //     0xa3691c: ldr             lr, [lr, #0x30]
    // 0xa36920: stp             lr, x16, [SP, #-0x10]!
    // 0xa36924: ldur            x16, [fp, #-0x60]
    // 0xa36928: SaveReg r16
    //     0xa36928: str             x16, [SP, #-8]!
    // 0xa3692c: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa3692c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa36930: r0 = Future.error()
    //     0xa36930: bl              #0x4e95bc  ; [dart:async] Future::Future.error
    // 0xa36934: add             SP, SP, #0x18
    // 0xa36938: r0 = ReturnAsync()
    //     0xa36938: b               #0x501858  ; ReturnAsyncStub
    // 0xa3693c: mov             x1, x3
    // 0xa36940: mov             x0, x1
    // 0xa36944: ldur            x1, [fp, #-0x60]
    // 0xa36948: r0 = ReThrow()
    //     0xa36948: bl              #0xd67e14  ; ReThrowStub
    // 0xa3694c: brk             #0
    // 0xa36950: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa36950: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa36954: b               #0xa365d4
  }
  _ getReturnCode(/* No info */) async {
    // ** addr: 0xa376c0, size: 0x168
    // 0xa376c0: EnterFrame
    //     0xa376c0: stp             fp, lr, [SP, #-0x10]!
    //     0xa376c4: mov             fp, SP
    // 0xa376c8: AllocStack(0x58)
    //     0xa376c8: sub             SP, SP, #0x58
    // 0xa376cc: SetupParameters(AbstractSession this /* r1, fp-0x50 */)
    //     0xa376cc: stur            NULL, [fp, #-8]
    //     0xa376d0: mov             x0, #0
    //     0xa376d4: add             x1, fp, w0, sxtw #2
    //     0xa376d8: ldr             x1, [x1, #0x10]
    //     0xa376dc: stur            x1, [fp, #-0x50]
    // 0xa376e0: CheckStackOverflow
    //     0xa376e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa376e4: cmp             SP, x16
    //     0xa376e8: b.ls            #0xa37820
    // 0xa376ec: InitAsync() -> Future<ReturnCode?>
    //     0xa376ec: add             x0, PP, #0x2f, lsl #12  ; [pp+0x2ff70] TypeArguments: <ReturnCode?>
    //     0xa376f0: ldr             x0, [x0, #0xf70]
    //     0xa376f4: bl              #0x4b92e4
    // 0xa376f8: ldur            x0, [fp, #-0x50]
    // 0xa376fc: r0 = InitLateStaticField(0xc44) // [package:ffmpeg_kit_flutter_min/abstract_session.dart] AbstractSession::_platform
    //     0xa376fc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa37700: ldr             x0, [x0, #0x1888]
    //     0xa37704: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa37708: cmp             w0, w16
    //     0xa3770c: b.ne            #0xa3771c
    //     0xa37710: add             x2, PP, #0x2f, lsl #12  ; [pp+0x2ff78] Field <AbstractSession._platform@515409998>: static late (offset: 0xc44)
    //     0xa37714: ldr             x2, [x2, #0xf78]
    //     0xa37718: bl              #0xd67d44
    // 0xa3771c: mov             x1, x0
    // 0xa37720: ldur            x0, [fp, #-0x50]
    // 0xa37724: LoadField: r2 = r0->field_7
    //     0xa37724: ldur            w2, [x0, #7]
    // 0xa37728: DecompressPointer r2
    //     0xa37728: add             x2, x2, HEAP, lsl #32
    // 0xa3772c: stp             x2, x1, [SP, #-0x10]!
    // 0xa37730: r0 = abstractSessionGetReturnCode()
    //     0xa37730: bl              #0xa37828  ; [package:ffmpeg_kit_flutter_platform_interface/method_channel_ffmpeg_kit_flutter.dart] MethodChannelFFmpegKit::abstractSessionGetReturnCode
    // 0xa37734: add             SP, SP, #0x10
    // 0xa37738: r1 = Function '<anonymous closure>':.
    //     0xa37738: add             x1, PP, #0x2f, lsl #12  ; [pp+0x2ff80] AnonymousClosure: (0xa378c8), in [package:ffmpeg_kit_flutter_min/abstract_session.dart] AbstractSession::getReturnCode (0xa376c0)
    //     0xa3773c: ldr             x1, [x1, #0xf80]
    // 0xa37740: r2 = Null
    //     0xa37740: mov             x2, NULL
    // 0xa37744: stur            x0, [fp, #-0x50]
    // 0xa37748: r0 = AllocateClosure()
    //     0xa37748: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa3774c: r16 = <ReturnCode?>
    //     0xa3774c: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2ff70] TypeArguments: <ReturnCode?>
    //     0xa37750: ldr             x16, [x16, #0xf70]
    // 0xa37754: ldur            lr, [fp, #-0x50]
    // 0xa37758: stp             lr, x16, [SP, #-0x10]!
    // 0xa3775c: SaveReg r0
    //     0xa3775c: str             x0, [SP, #-8]!
    // 0xa37760: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa37760: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa37764: r0 = then()
    //     0xa37764: bl              #0xca6124  ; [dart:async] _Future::then
    // 0xa37768: add             SP, SP, #0x18
    // 0xa3776c: r0 = ReturnAsync()
    //     0xa3776c: b               #0x501858  ; ReturnAsyncStub
    // 0xa37770: sub             SP, fp, #0x58
    // 0xa37774: mov             x3, x0
    // 0xa37778: stur            x0, [fp, #-0x50]
    // 0xa3777c: mov             x0, x1
    // 0xa37780: stur            x1, [fp, #-0x58]
    // 0xa37784: r1 = LoadTaggedClassIdMayBeSmiInstr(r3)
    //     0xa37784: mov             x1, #0x76
    //     0xa37788: tbz             w3, #0, #0xa37798
    //     0xa3778c: ldur            x1, [x3, #-1]
    //     0xa37790: ubfx            x1, x1, #0xc, #0x14
    //     0xa37794: lsl             x1, x1, #1
    // 0xa37798: cmp             w1, #0xf28
    // 0xa3779c: b.ne            #0xa3780c
    // 0xa377a0: r1 = Null
    //     0xa377a0: mov             x1, NULL
    // 0xa377a4: r2 = 4
    //     0xa377a4: mov             x2, #4
    // 0xa377a8: r0 = AllocateArray()
    //     0xa377a8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa377ac: r17 = "Plugin getReturnCode error: "
    //     0xa377ac: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2ff88] "Plugin getReturnCode error: "
    //     0xa377b0: ldr             x17, [x17, #0xf88]
    // 0xa377b4: StoreField: r0->field_f = r17
    //     0xa377b4: stur            w17, [x0, #0xf]
    // 0xa377b8: ldur            x1, [fp, #-0x50]
    // 0xa377bc: LoadField: r2 = r1->field_b
    //     0xa377bc: ldur            w2, [x1, #0xb]
    // 0xa377c0: DecompressPointer r2
    //     0xa377c0: add             x2, x2, HEAP, lsl #32
    // 0xa377c4: StoreField: r0->field_13 = r2
    //     0xa377c4: stur            w2, [x0, #0x13]
    // 0xa377c8: SaveReg r0
    //     0xa377c8: str             x0, [SP, #-8]!
    // 0xa377cc: r0 = _interpolate()
    //     0xa377cc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa377d0: add             SP, SP, #8
    // 0xa377d4: SaveReg r0
    //     0xa377d4: str             x0, [SP, #-8]!
    // 0xa377d8: r0 = print()
    //     0xa377d8: bl              #0x4ff92c  ; [dart:core] ::print
    // 0xa377dc: add             SP, SP, #8
    // 0xa377e0: r16 = <ReturnCode?>
    //     0xa377e0: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2ff70] TypeArguments: <ReturnCode?>
    //     0xa377e4: ldr             x16, [x16, #0xf70]
    // 0xa377e8: r30 = "getReturnCode failed."
    //     0xa377e8: add             lr, PP, #0x2f, lsl #12  ; [pp+0x2ff90] "getReturnCode failed."
    //     0xa377ec: ldr             lr, [lr, #0xf90]
    // 0xa377f0: stp             lr, x16, [SP, #-0x10]!
    // 0xa377f4: ldur            x16, [fp, #-0x58]
    // 0xa377f8: SaveReg r16
    //     0xa377f8: str             x16, [SP, #-8]!
    // 0xa377fc: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa377fc: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa37800: r0 = Future.error()
    //     0xa37800: bl              #0x4e95bc  ; [dart:async] Future::Future.error
    // 0xa37804: add             SP, SP, #0x18
    // 0xa37808: r0 = ReturnAsync()
    //     0xa37808: b               #0x501858  ; ReturnAsyncStub
    // 0xa3780c: mov             x1, x3
    // 0xa37810: mov             x0, x1
    // 0xa37814: ldur            x1, [fp, #-0x58]
    // 0xa37818: r0 = ReThrow()
    //     0xa37818: bl              #0xd67e14  ; ReThrowStub
    // 0xa3781c: brk             #0
    // 0xa37820: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa37820: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa37824: b               #0xa376ec
  }
  [closure] ReturnCode? <anonymous closure>(dynamic, int?) {
    // ** addr: 0xa378c8, size: 0x50
    // 0xa378c8: EnterFrame
    //     0xa378c8: stp             fp, lr, [SP, #-0x10]!
    //     0xa378cc: mov             fp, SP
    // 0xa378d0: AllocStack(0x8)
    //     0xa378d0: sub             SP, SP, #8
    // 0xa378d4: ldr             x0, [fp, #0x10]
    // 0xa378d8: cmp             w0, NULL
    // 0xa378dc: b.ne            #0xa378f0
    // 0xa378e0: r0 = Null
    //     0xa378e0: mov             x0, NULL
    // 0xa378e4: LeaveFrame
    //     0xa378e4: mov             SP, fp
    //     0xa378e8: ldp             fp, lr, [SP], #0x10
    // 0xa378ec: ret
    //     0xa378ec: ret             
    // 0xa378f0: r1 = LoadInt32Instr(r0)
    //     0xa378f0: sbfx            x1, x0, #1, #0x1f
    //     0xa378f4: tbz             w0, #0, #0xa378fc
    //     0xa378f8: ldur            x1, [x0, #7]
    // 0xa378fc: stur            x1, [fp, #-8]
    // 0xa37900: r0 = ReturnCode()
    //     0xa37900: bl              #0xa37918  ; AllocateReturnCodeStub -> ReturnCode (size=0x10)
    // 0xa37904: ldur            x1, [fp, #-8]
    // 0xa37908: StoreField: r0->field_7 = r1
    //     0xa37908: stur            x1, [x0, #7]
    // 0xa3790c: LeaveFrame
    //     0xa3790c: mov             SP, fp
    //     0xa37910: ldp             fp, lr, [SP], #0x10
    // 0xa37914: ret
    //     0xa37914: ret             
  }
  static _ createFFmpegSessionFromMap(/* No info */) {
    // ** addr: 0xcb7338, size: 0x264
    // 0xcb7338: EnterFrame
    //     0xcb7338: stp             fp, lr, [SP, #-0x10]!
    //     0xcb733c: mov             fp, SP
    // 0xcb7340: AllocStack(0x18)
    //     0xcb7340: sub             SP, SP, #0x18
    // 0xcb7344: CheckStackOverflow
    //     0xcb7344: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb7348: cmp             SP, x16
    //     0xcb734c: b.ls            #0xcb7594
    // 0xcb7350: ldr             x1, [fp, #0x10]
    // 0xcb7354: r0 = LoadClassIdInstr(r1)
    //     0xcb7354: ldur            x0, [x1, #-1]
    //     0xcb7358: ubfx            x0, x0, #0xc, #0x14
    // 0xcb735c: r16 = "sessionId"
    //     0xcb735c: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2fd10] "sessionId"
    //     0xcb7360: ldr             x16, [x16, #0xd10]
    // 0xcb7364: stp             x16, x1, [SP, #-0x10]!
    // 0xcb7368: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb7368: sub             lr, x0, #0xef
    //     0xcb736c: ldr             lr, [x21, lr, lsl #3]
    //     0xcb7370: blr             lr
    // 0xcb7374: add             SP, SP, #0x10
    // 0xcb7378: mov             x3, x0
    // 0xcb737c: r2 = Null
    //     0xcb737c: mov             x2, NULL
    // 0xcb7380: r1 = Null
    //     0xcb7380: mov             x1, NULL
    // 0xcb7384: stur            x3, [fp, #-8]
    // 0xcb7388: branchIfSmi(r0, 0xcb73b0)
    //     0xcb7388: tbz             w0, #0, #0xcb73b0
    // 0xcb738c: r4 = LoadClassIdInstr(r0)
    //     0xcb738c: ldur            x4, [x0, #-1]
    //     0xcb7390: ubfx            x4, x4, #0xc, #0x14
    // 0xcb7394: sub             x4, x4, #0x3b
    // 0xcb7398: cmp             x4, #1
    // 0xcb739c: b.ls            #0xcb73b0
    // 0xcb73a0: r8 = int?
    //     0xcb73a0: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xcb73a4: r3 = Null
    //     0xcb73a4: add             x3, PP, #0x40, lsl #12  ; [pp+0x40748] Null
    //     0xcb73a8: ldr             x3, [x3, #0x748]
    // 0xcb73ac: r0 = int?()
    //     0xcb73ac: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xcb73b0: r0 = FFmpegSession()
    //     0xcb73b0: bl              #0xa369f0  ; AllocateFFmpegSessionStub -> FFmpegSession (size=0xc)
    // 0xcb73b4: mov             x2, x0
    // 0xcb73b8: ldur            x1, [fp, #-8]
    // 0xcb73bc: stur            x2, [fp, #-0x10]
    // 0xcb73c0: StoreField: r2->field_7 = r1
    //     0xcb73c0: stur            w1, [x2, #7]
    // 0xcb73c4: ldr             x3, [fp, #0x10]
    // 0xcb73c8: r0 = LoadClassIdInstr(r3)
    //     0xcb73c8: ldur            x0, [x3, #-1]
    //     0xcb73cc: ubfx            x0, x0, #0xc, #0x14
    // 0xcb73d0: r16 = "createTime"
    //     0xcb73d0: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2ffe0] "createTime"
    //     0xcb73d4: ldr             x16, [x16, #0xfe0]
    // 0xcb73d8: stp             x16, x3, [SP, #-0x10]!
    // 0xcb73dc: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb73dc: sub             lr, x0, #0xef
    //     0xcb73e0: ldr             lr, [x21, lr, lsl #3]
    //     0xcb73e4: blr             lr
    // 0xcb73e8: add             SP, SP, #0x10
    // 0xcb73ec: mov             x3, x0
    // 0xcb73f0: r2 = Null
    //     0xcb73f0: mov             x2, NULL
    // 0xcb73f4: r1 = Null
    //     0xcb73f4: mov             x1, NULL
    // 0xcb73f8: stur            x3, [fp, #-0x18]
    // 0xcb73fc: branchIfSmi(r0, 0xcb7424)
    //     0xcb73fc: tbz             w0, #0, #0xcb7424
    // 0xcb7400: r4 = LoadClassIdInstr(r0)
    //     0xcb7400: ldur            x4, [x0, #-1]
    //     0xcb7404: ubfx            x4, x4, #0xc, #0x14
    // 0xcb7408: sub             x4, x4, #0x3b
    // 0xcb740c: cmp             x4, #1
    // 0xcb7410: b.ls            #0xcb7424
    // 0xcb7414: r8 = int?
    //     0xcb7414: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xcb7418: r3 = Null
    //     0xcb7418: add             x3, PP, #0x40, lsl #12  ; [pp+0x40758] Null
    //     0xcb741c: ldr             x3, [x3, #0x758]
    // 0xcb7420: r0 = int?()
    //     0xcb7420: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xcb7424: ldur            x16, [fp, #-0x18]
    // 0xcb7428: SaveReg r16
    //     0xcb7428: str             x16, [SP, #-8]!
    // 0xcb742c: r0 = validDate()
    //     0xcb742c: bl              #0xa36958  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] FFmpegKitFactory::validDate
    // 0xcb7430: add             SP, SP, #8
    // 0xcb7434: ldr             x1, [fp, #0x10]
    // 0xcb7438: r0 = LoadClassIdInstr(r1)
    //     0xcb7438: ldur            x0, [x1, #-1]
    //     0xcb743c: ubfx            x0, x0, #0xc, #0x14
    // 0xcb7440: r16 = "startTime"
    //     0xcb7440: ldr             x16, [PP, #0x2aa8]  ; [pp+0x2aa8] "startTime"
    // 0xcb7444: stp             x16, x1, [SP, #-0x10]!
    // 0xcb7448: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb7448: sub             lr, x0, #0xef
    //     0xcb744c: ldr             lr, [x21, lr, lsl #3]
    //     0xcb7450: blr             lr
    // 0xcb7454: add             SP, SP, #0x10
    // 0xcb7458: mov             x3, x0
    // 0xcb745c: r2 = Null
    //     0xcb745c: mov             x2, NULL
    // 0xcb7460: r1 = Null
    //     0xcb7460: mov             x1, NULL
    // 0xcb7464: stur            x3, [fp, #-0x18]
    // 0xcb7468: branchIfSmi(r0, 0xcb7490)
    //     0xcb7468: tbz             w0, #0, #0xcb7490
    // 0xcb746c: r4 = LoadClassIdInstr(r0)
    //     0xcb746c: ldur            x4, [x0, #-1]
    //     0xcb7470: ubfx            x4, x4, #0xc, #0x14
    // 0xcb7474: sub             x4, x4, #0x3b
    // 0xcb7478: cmp             x4, #1
    // 0xcb747c: b.ls            #0xcb7490
    // 0xcb7480: r8 = int?
    //     0xcb7480: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xcb7484: r3 = Null
    //     0xcb7484: add             x3, PP, #0x40, lsl #12  ; [pp+0x40768] Null
    //     0xcb7488: ldr             x3, [x3, #0x768]
    // 0xcb748c: r0 = int?()
    //     0xcb748c: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xcb7490: ldur            x16, [fp, #-0x18]
    // 0xcb7494: SaveReg r16
    //     0xcb7494: str             x16, [SP, #-8]!
    // 0xcb7498: r0 = validDate()
    //     0xcb7498: bl              #0xa36958  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] FFmpegKitFactory::validDate
    // 0xcb749c: add             SP, SP, #8
    // 0xcb74a0: ldr             x1, [fp, #0x10]
    // 0xcb74a4: r0 = LoadClassIdInstr(r1)
    //     0xcb74a4: ldur            x0, [x1, #-1]
    //     0xcb74a8: ubfx            x0, x0, #0xc, #0x14
    // 0xcb74ac: r16 = "command"
    //     0xcb74ac: add             x16, PP, #0x30, lsl #12  ; [pp+0x30008] "command"
    //     0xcb74b0: ldr             x16, [x16, #8]
    // 0xcb74b4: stp             x16, x1, [SP, #-0x10]!
    // 0xcb74b8: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb74b8: sub             lr, x0, #0xef
    //     0xcb74bc: ldr             lr, [x21, lr, lsl #3]
    //     0xcb74c0: blr             lr
    // 0xcb74c4: add             SP, SP, #0x10
    // 0xcb74c8: r2 = Null
    //     0xcb74c8: mov             x2, NULL
    // 0xcb74cc: r1 = Null
    //     0xcb74cc: mov             x1, NULL
    // 0xcb74d0: r4 = 59
    //     0xcb74d0: mov             x4, #0x3b
    // 0xcb74d4: branchIfSmi(r0, 0xcb74e0)
    //     0xcb74d4: tbz             w0, #0, #0xcb74e0
    // 0xcb74d8: r4 = LoadClassIdInstr(r0)
    //     0xcb74d8: ldur            x4, [x0, #-1]
    //     0xcb74dc: ubfx            x4, x4, #0xc, #0x14
    // 0xcb74e0: sub             x4, x4, #0x5d
    // 0xcb74e4: cmp             x4, #3
    // 0xcb74e8: b.ls            #0xcb74fc
    // 0xcb74ec: r8 = String?
    //     0xcb74ec: ldr             x8, [PP, #0x2148]  ; [pp+0x2148] Type: String?
    // 0xcb74f0: r3 = Null
    //     0xcb74f0: add             x3, PP, #0x40, lsl #12  ; [pp+0x40778] Null
    //     0xcb74f4: ldr             x3, [x3, #0x778]
    // 0xcb74f8: r0 = String?()
    //     0xcb74f8: bl              #0x4b2994  ; IsType_String?_Stub
    // 0xcb74fc: ldr             x0, [fp, #0x10]
    // 0xcb7500: r1 = LoadClassIdInstr(r0)
    //     0xcb7500: ldur            x1, [x0, #-1]
    //     0xcb7504: ubfx            x1, x1, #0xc, #0x14
    // 0xcb7508: r16 = "command"
    //     0xcb7508: add             x16, PP, #0x30, lsl #12  ; [pp+0x30008] "command"
    //     0xcb750c: ldr             x16, [x16, #8]
    // 0xcb7510: stp             x16, x0, [SP, #-0x10]!
    // 0xcb7514: mov             x0, x1
    // 0xcb7518: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb7518: sub             lr, x0, #0xef
    //     0xcb751c: ldr             lr, [x21, lr, lsl #3]
    //     0xcb7520: blr             lr
    // 0xcb7524: add             SP, SP, #0x10
    // 0xcb7528: mov             x3, x0
    // 0xcb752c: r2 = Null
    //     0xcb752c: mov             x2, NULL
    // 0xcb7530: r1 = Null
    //     0xcb7530: mov             x1, NULL
    // 0xcb7534: stur            x3, [fp, #-0x18]
    // 0xcb7538: r4 = 59
    //     0xcb7538: mov             x4, #0x3b
    // 0xcb753c: branchIfSmi(r0, 0xcb7548)
    //     0xcb753c: tbz             w0, #0, #0xcb7548
    // 0xcb7540: r4 = LoadClassIdInstr(r0)
    //     0xcb7540: ldur            x4, [x0, #-1]
    //     0xcb7544: ubfx            x4, x4, #0xc, #0x14
    // 0xcb7548: sub             x4, x4, #0x5d
    // 0xcb754c: cmp             x4, #3
    // 0xcb7550: b.ls            #0xcb7564
    // 0xcb7554: r8 = String
    //     0xcb7554: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xcb7558: r3 = Null
    //     0xcb7558: add             x3, PP, #0x40, lsl #12  ; [pp+0x40788] Null
    //     0xcb755c: ldr             x3, [x3, #0x788]
    // 0xcb7560: r0 = String()
    //     0xcb7560: bl              #0xd72afc  ; IsType_String_Stub
    // 0xcb7564: ldur            x16, [fp, #-0x18]
    // 0xcb7568: SaveReg r16
    //     0xcb7568: str             x16, [SP, #-8]!
    // 0xcb756c: r0 = parseArguments()
    //     0xcb756c: bl              #0xa36acc  ; [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::parseArguments
    // 0xcb7570: add             SP, SP, #8
    // 0xcb7574: ldur            x16, [fp, #-8]
    // 0xcb7578: SaveReg r16
    //     0xcb7578: str             x16, [SP, #-8]!
    // 0xcb757c: r0 = getLogRedirectionStrategy()
    //     0xcb757c: bl              #0xcb759c  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] FFmpegKitFactory::getLogRedirectionStrategy
    // 0xcb7580: add             SP, SP, #8
    // 0xcb7584: ldur            x0, [fp, #-0x10]
    // 0xcb7588: LeaveFrame
    //     0xcb7588: mov             SP, fp
    //     0xcb758c: ldp             fp, lr, [SP], #0x10
    // 0xcb7590: ret
    //     0xcb7590: ret             
    // 0xcb7594: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb7594: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb7598: b               #0xcb7350
  }
  static _ createMediaInformationSessionFromMap(/* No info */) {
    // ** addr: 0xcb76e4, size: 0x2c4
    // 0xcb76e4: EnterFrame
    //     0xcb76e4: stp             fp, lr, [SP, #-0x10]!
    //     0xcb76e8: mov             fp, SP
    // 0xcb76ec: AllocStack(0x10)
    //     0xcb76ec: sub             SP, SP, #0x10
    // 0xcb76f0: CheckStackOverflow
    //     0xcb76f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb76f4: cmp             SP, x16
    //     0xcb76f8: b.ls            #0xcb79a0
    // 0xcb76fc: ldr             x1, [fp, #0x10]
    // 0xcb7700: r0 = LoadClassIdInstr(r1)
    //     0xcb7700: ldur            x0, [x1, #-1]
    //     0xcb7704: ubfx            x0, x0, #0xc, #0x14
    // 0xcb7708: r16 = "sessionId"
    //     0xcb7708: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2fd10] "sessionId"
    //     0xcb770c: ldr             x16, [x16, #0xd10]
    // 0xcb7710: stp             x16, x1, [SP, #-0x10]!
    // 0xcb7714: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb7714: sub             lr, x0, #0xef
    //     0xcb7718: ldr             lr, [x21, lr, lsl #3]
    //     0xcb771c: blr             lr
    // 0xcb7720: add             SP, SP, #0x10
    // 0xcb7724: mov             x3, x0
    // 0xcb7728: r2 = Null
    //     0xcb7728: mov             x2, NULL
    // 0xcb772c: r1 = Null
    //     0xcb772c: mov             x1, NULL
    // 0xcb7730: stur            x3, [fp, #-8]
    // 0xcb7734: branchIfSmi(r0, 0xcb775c)
    //     0xcb7734: tbz             w0, #0, #0xcb775c
    // 0xcb7738: r4 = LoadClassIdInstr(r0)
    //     0xcb7738: ldur            x4, [x0, #-1]
    //     0xcb773c: ubfx            x4, x4, #0xc, #0x14
    // 0xcb7740: sub             x4, x4, #0x3b
    // 0xcb7744: cmp             x4, #1
    // 0xcb7748: b.ls            #0xcb775c
    // 0xcb774c: r8 = int?
    //     0xcb774c: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xcb7750: r3 = Null
    //     0xcb7750: add             x3, PP, #0x40, lsl #12  ; [pp+0x407a8] Null
    //     0xcb7754: ldr             x3, [x3, #0x7a8]
    // 0xcb7758: r0 = int?()
    //     0xcb7758: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xcb775c: r0 = MediaInformationSession()
    //     0xcb775c: bl              #0xcb79a8  ; AllocateMediaInformationSessionStub -> MediaInformationSession (size=0xc)
    // 0xcb7760: mov             x1, x0
    // 0xcb7764: ldur            x0, [fp, #-8]
    // 0xcb7768: stur            x1, [fp, #-0x10]
    // 0xcb776c: StoreField: r1->field_7 = r0
    //     0xcb776c: stur            w0, [x1, #7]
    // 0xcb7770: ldr             x2, [fp, #0x10]
    // 0xcb7774: r0 = LoadClassIdInstr(r2)
    //     0xcb7774: ldur            x0, [x2, #-1]
    //     0xcb7778: ubfx            x0, x0, #0xc, #0x14
    // 0xcb777c: r16 = "createTime"
    //     0xcb777c: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2ffe0] "createTime"
    //     0xcb7780: ldr             x16, [x16, #0xfe0]
    // 0xcb7784: stp             x16, x2, [SP, #-0x10]!
    // 0xcb7788: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb7788: sub             lr, x0, #0xef
    //     0xcb778c: ldr             lr, [x21, lr, lsl #3]
    //     0xcb7790: blr             lr
    // 0xcb7794: add             SP, SP, #0x10
    // 0xcb7798: mov             x3, x0
    // 0xcb779c: r2 = Null
    //     0xcb779c: mov             x2, NULL
    // 0xcb77a0: r1 = Null
    //     0xcb77a0: mov             x1, NULL
    // 0xcb77a4: stur            x3, [fp, #-8]
    // 0xcb77a8: branchIfSmi(r0, 0xcb77d0)
    //     0xcb77a8: tbz             w0, #0, #0xcb77d0
    // 0xcb77ac: r4 = LoadClassIdInstr(r0)
    //     0xcb77ac: ldur            x4, [x0, #-1]
    //     0xcb77b0: ubfx            x4, x4, #0xc, #0x14
    // 0xcb77b4: sub             x4, x4, #0x3b
    // 0xcb77b8: cmp             x4, #1
    // 0xcb77bc: b.ls            #0xcb77d0
    // 0xcb77c0: r8 = int?
    //     0xcb77c0: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xcb77c4: r3 = Null
    //     0xcb77c4: add             x3, PP, #0x40, lsl #12  ; [pp+0x407b8] Null
    //     0xcb77c8: ldr             x3, [x3, #0x7b8]
    // 0xcb77cc: r0 = int?()
    //     0xcb77cc: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xcb77d0: ldur            x16, [fp, #-8]
    // 0xcb77d4: SaveReg r16
    //     0xcb77d4: str             x16, [SP, #-8]!
    // 0xcb77d8: r0 = validDate()
    //     0xcb77d8: bl              #0xa36958  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] FFmpegKitFactory::validDate
    // 0xcb77dc: add             SP, SP, #8
    // 0xcb77e0: ldr             x1, [fp, #0x10]
    // 0xcb77e4: r0 = LoadClassIdInstr(r1)
    //     0xcb77e4: ldur            x0, [x1, #-1]
    //     0xcb77e8: ubfx            x0, x0, #0xc, #0x14
    // 0xcb77ec: r16 = "startTime"
    //     0xcb77ec: ldr             x16, [PP, #0x2aa8]  ; [pp+0x2aa8] "startTime"
    // 0xcb77f0: stp             x16, x1, [SP, #-0x10]!
    // 0xcb77f4: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb77f4: sub             lr, x0, #0xef
    //     0xcb77f8: ldr             lr, [x21, lr, lsl #3]
    //     0xcb77fc: blr             lr
    // 0xcb7800: add             SP, SP, #0x10
    // 0xcb7804: mov             x3, x0
    // 0xcb7808: r2 = Null
    //     0xcb7808: mov             x2, NULL
    // 0xcb780c: r1 = Null
    //     0xcb780c: mov             x1, NULL
    // 0xcb7810: stur            x3, [fp, #-8]
    // 0xcb7814: branchIfSmi(r0, 0xcb783c)
    //     0xcb7814: tbz             w0, #0, #0xcb783c
    // 0xcb7818: r4 = LoadClassIdInstr(r0)
    //     0xcb7818: ldur            x4, [x0, #-1]
    //     0xcb781c: ubfx            x4, x4, #0xc, #0x14
    // 0xcb7820: sub             x4, x4, #0x3b
    // 0xcb7824: cmp             x4, #1
    // 0xcb7828: b.ls            #0xcb783c
    // 0xcb782c: r8 = int?
    //     0xcb782c: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xcb7830: r3 = Null
    //     0xcb7830: add             x3, PP, #0x40, lsl #12  ; [pp+0x407c8] Null
    //     0xcb7834: ldr             x3, [x3, #0x7c8]
    // 0xcb7838: r0 = int?()
    //     0xcb7838: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xcb783c: ldur            x16, [fp, #-8]
    // 0xcb7840: SaveReg r16
    //     0xcb7840: str             x16, [SP, #-8]!
    // 0xcb7844: r0 = validDate()
    //     0xcb7844: bl              #0xa36958  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] FFmpegKitFactory::validDate
    // 0xcb7848: add             SP, SP, #8
    // 0xcb784c: ldr             x1, [fp, #0x10]
    // 0xcb7850: r0 = LoadClassIdInstr(r1)
    //     0xcb7850: ldur            x0, [x1, #-1]
    //     0xcb7854: ubfx            x0, x0, #0xc, #0x14
    // 0xcb7858: r16 = "command"
    //     0xcb7858: add             x16, PP, #0x30, lsl #12  ; [pp+0x30008] "command"
    //     0xcb785c: ldr             x16, [x16, #8]
    // 0xcb7860: stp             x16, x1, [SP, #-0x10]!
    // 0xcb7864: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb7864: sub             lr, x0, #0xef
    //     0xcb7868: ldr             lr, [x21, lr, lsl #3]
    //     0xcb786c: blr             lr
    // 0xcb7870: add             SP, SP, #0x10
    // 0xcb7874: r2 = Null
    //     0xcb7874: mov             x2, NULL
    // 0xcb7878: r1 = Null
    //     0xcb7878: mov             x1, NULL
    // 0xcb787c: r4 = 59
    //     0xcb787c: mov             x4, #0x3b
    // 0xcb7880: branchIfSmi(r0, 0xcb788c)
    //     0xcb7880: tbz             w0, #0, #0xcb788c
    // 0xcb7884: r4 = LoadClassIdInstr(r0)
    //     0xcb7884: ldur            x4, [x0, #-1]
    //     0xcb7888: ubfx            x4, x4, #0xc, #0x14
    // 0xcb788c: sub             x4, x4, #0x5d
    // 0xcb7890: cmp             x4, #3
    // 0xcb7894: b.ls            #0xcb78a8
    // 0xcb7898: r8 = String?
    //     0xcb7898: ldr             x8, [PP, #0x2148]  ; [pp+0x2148] Type: String?
    // 0xcb789c: r3 = Null
    //     0xcb789c: add             x3, PP, #0x40, lsl #12  ; [pp+0x407d8] Null
    //     0xcb78a0: ldr             x3, [x3, #0x7d8]
    // 0xcb78a4: r0 = String?()
    //     0xcb78a4: bl              #0x4b2994  ; IsType_String?_Stub
    // 0xcb78a8: ldr             x1, [fp, #0x10]
    // 0xcb78ac: r0 = LoadClassIdInstr(r1)
    //     0xcb78ac: ldur            x0, [x1, #-1]
    //     0xcb78b0: ubfx            x0, x0, #0xc, #0x14
    // 0xcb78b4: r16 = "command"
    //     0xcb78b4: add             x16, PP, #0x30, lsl #12  ; [pp+0x30008] "command"
    //     0xcb78b8: ldr             x16, [x16, #8]
    // 0xcb78bc: stp             x16, x1, [SP, #-0x10]!
    // 0xcb78c0: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb78c0: sub             lr, x0, #0xef
    //     0xcb78c4: ldr             lr, [x21, lr, lsl #3]
    //     0xcb78c8: blr             lr
    // 0xcb78cc: add             SP, SP, #0x10
    // 0xcb78d0: mov             x3, x0
    // 0xcb78d4: r2 = Null
    //     0xcb78d4: mov             x2, NULL
    // 0xcb78d8: r1 = Null
    //     0xcb78d8: mov             x1, NULL
    // 0xcb78dc: stur            x3, [fp, #-8]
    // 0xcb78e0: r4 = 59
    //     0xcb78e0: mov             x4, #0x3b
    // 0xcb78e4: branchIfSmi(r0, 0xcb78f0)
    //     0xcb78e4: tbz             w0, #0, #0xcb78f0
    // 0xcb78e8: r4 = LoadClassIdInstr(r0)
    //     0xcb78e8: ldur            x4, [x0, #-1]
    //     0xcb78ec: ubfx            x4, x4, #0xc, #0x14
    // 0xcb78f0: sub             x4, x4, #0x5d
    // 0xcb78f4: cmp             x4, #3
    // 0xcb78f8: b.ls            #0xcb790c
    // 0xcb78fc: r8 = String
    //     0xcb78fc: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xcb7900: r3 = Null
    //     0xcb7900: add             x3, PP, #0x40, lsl #12  ; [pp+0x407e8] Null
    //     0xcb7904: ldr             x3, [x3, #0x7e8]
    // 0xcb7908: r0 = String()
    //     0xcb7908: bl              #0xd72afc  ; IsType_String_Stub
    // 0xcb790c: ldur            x16, [fp, #-8]
    // 0xcb7910: SaveReg r16
    //     0xcb7910: str             x16, [SP, #-8]!
    // 0xcb7914: r0 = parseArguments()
    //     0xcb7914: bl              #0xa36acc  ; [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::parseArguments
    // 0xcb7918: add             SP, SP, #8
    // 0xcb791c: ldr             x1, [fp, #0x10]
    // 0xcb7920: r0 = LoadClassIdInstr(r1)
    //     0xcb7920: ldur            x0, [x1, #-1]
    //     0xcb7924: ubfx            x0, x0, #0xc, #0x14
    // 0xcb7928: r16 = "mediaInformation"
    //     0xcb7928: add             x16, PP, #0x40, lsl #12  ; [pp+0x407f8] "mediaInformation"
    //     0xcb792c: ldr             x16, [x16, #0x7f8]
    // 0xcb7930: stp             x16, x1, [SP, #-0x10]!
    // 0xcb7934: r0 = GDT[cid_x0 + 0x579]()
    //     0xcb7934: add             lr, x0, #0x579
    //     0xcb7938: ldr             lr, [x21, lr, lsl #3]
    //     0xcb793c: blr             lr
    // 0xcb7940: add             SP, SP, #0x10
    // 0xcb7944: tbnz            w0, #4, #0xcb7990
    // 0xcb7948: ldr             x0, [fp, #0x10]
    // 0xcb794c: r1 = LoadClassIdInstr(r0)
    //     0xcb794c: ldur            x1, [x0, #-1]
    //     0xcb7950: ubfx            x1, x1, #0xc, #0x14
    // 0xcb7954: r16 = "mediaInformation"
    //     0xcb7954: add             x16, PP, #0x40, lsl #12  ; [pp+0x407f8] "mediaInformation"
    //     0xcb7958: ldr             x16, [x16, #0x7f8]
    // 0xcb795c: stp             x16, x0, [SP, #-0x10]!
    // 0xcb7960: mov             x0, x1
    // 0xcb7964: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb7964: sub             lr, x0, #0xef
    //     0xcb7968: ldr             lr, [x21, lr, lsl #3]
    //     0xcb796c: blr             lr
    // 0xcb7970: add             SP, SP, #0x10
    // 0xcb7974: r2 = Null
    //     0xcb7974: mov             x2, NULL
    // 0xcb7978: r1 = Null
    //     0xcb7978: mov             x1, NULL
    // 0xcb797c: r8 = Map?
    //     0xcb797c: add             x8, PP, #0x39, lsl #12  ; [pp+0x392b0] Type: Map?
    //     0xcb7980: ldr             x8, [x8, #0x2b0]
    // 0xcb7984: r3 = Null
    //     0xcb7984: add             x3, PP, #0x40, lsl #12  ; [pp+0x40800] Null
    //     0xcb7988: ldr             x3, [x3, #0x800]
    // 0xcb798c: r0 = Map?()
    //     0xcb798c: bl              #0x5a2f04  ; IsType_Map?_Stub
    // 0xcb7990: ldur            x0, [fp, #-0x10]
    // 0xcb7994: LeaveFrame
    //     0xcb7994: mov             SP, fp
    //     0xcb7998: ldp             fp, lr, [SP], #0x10
    // 0xcb799c: ret
    //     0xcb799c: ret             
    // 0xcb79a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb79a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb79a4: b               #0xcb76fc
  }
  static _ createFFprobeSessionFromMap(/* No info */) {
    // ** addr: 0xcb79b4, size: 0x264
    // 0xcb79b4: EnterFrame
    //     0xcb79b4: stp             fp, lr, [SP, #-0x10]!
    //     0xcb79b8: mov             fp, SP
    // 0xcb79bc: AllocStack(0x18)
    //     0xcb79bc: sub             SP, SP, #0x18
    // 0xcb79c0: CheckStackOverflow
    //     0xcb79c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb79c4: cmp             SP, x16
    //     0xcb79c8: b.ls            #0xcb7c10
    // 0xcb79cc: ldr             x1, [fp, #0x10]
    // 0xcb79d0: r0 = LoadClassIdInstr(r1)
    //     0xcb79d0: ldur            x0, [x1, #-1]
    //     0xcb79d4: ubfx            x0, x0, #0xc, #0x14
    // 0xcb79d8: r16 = "sessionId"
    //     0xcb79d8: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2fd10] "sessionId"
    //     0xcb79dc: ldr             x16, [x16, #0xd10]
    // 0xcb79e0: stp             x16, x1, [SP, #-0x10]!
    // 0xcb79e4: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb79e4: sub             lr, x0, #0xef
    //     0xcb79e8: ldr             lr, [x21, lr, lsl #3]
    //     0xcb79ec: blr             lr
    // 0xcb79f0: add             SP, SP, #0x10
    // 0xcb79f4: mov             x3, x0
    // 0xcb79f8: r2 = Null
    //     0xcb79f8: mov             x2, NULL
    // 0xcb79fc: r1 = Null
    //     0xcb79fc: mov             x1, NULL
    // 0xcb7a00: stur            x3, [fp, #-8]
    // 0xcb7a04: branchIfSmi(r0, 0xcb7a2c)
    //     0xcb7a04: tbz             w0, #0, #0xcb7a2c
    // 0xcb7a08: r4 = LoadClassIdInstr(r0)
    //     0xcb7a08: ldur            x4, [x0, #-1]
    //     0xcb7a0c: ubfx            x4, x4, #0xc, #0x14
    // 0xcb7a10: sub             x4, x4, #0x3b
    // 0xcb7a14: cmp             x4, #1
    // 0xcb7a18: b.ls            #0xcb7a2c
    // 0xcb7a1c: r8 = int?
    //     0xcb7a1c: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xcb7a20: r3 = Null
    //     0xcb7a20: add             x3, PP, #0x40, lsl #12  ; [pp+0x40810] Null
    //     0xcb7a24: ldr             x3, [x3, #0x810]
    // 0xcb7a28: r0 = int?()
    //     0xcb7a28: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xcb7a2c: r0 = FFprobeSession()
    //     0xcb7a2c: bl              #0xcb7c18  ; AllocateFFprobeSessionStub -> FFprobeSession (size=0xc)
    // 0xcb7a30: mov             x2, x0
    // 0xcb7a34: ldur            x1, [fp, #-8]
    // 0xcb7a38: stur            x2, [fp, #-0x10]
    // 0xcb7a3c: StoreField: r2->field_7 = r1
    //     0xcb7a3c: stur            w1, [x2, #7]
    // 0xcb7a40: ldr             x3, [fp, #0x10]
    // 0xcb7a44: r0 = LoadClassIdInstr(r3)
    //     0xcb7a44: ldur            x0, [x3, #-1]
    //     0xcb7a48: ubfx            x0, x0, #0xc, #0x14
    // 0xcb7a4c: r16 = "createTime"
    //     0xcb7a4c: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2ffe0] "createTime"
    //     0xcb7a50: ldr             x16, [x16, #0xfe0]
    // 0xcb7a54: stp             x16, x3, [SP, #-0x10]!
    // 0xcb7a58: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb7a58: sub             lr, x0, #0xef
    //     0xcb7a5c: ldr             lr, [x21, lr, lsl #3]
    //     0xcb7a60: blr             lr
    // 0xcb7a64: add             SP, SP, #0x10
    // 0xcb7a68: mov             x3, x0
    // 0xcb7a6c: r2 = Null
    //     0xcb7a6c: mov             x2, NULL
    // 0xcb7a70: r1 = Null
    //     0xcb7a70: mov             x1, NULL
    // 0xcb7a74: stur            x3, [fp, #-0x18]
    // 0xcb7a78: branchIfSmi(r0, 0xcb7aa0)
    //     0xcb7a78: tbz             w0, #0, #0xcb7aa0
    // 0xcb7a7c: r4 = LoadClassIdInstr(r0)
    //     0xcb7a7c: ldur            x4, [x0, #-1]
    //     0xcb7a80: ubfx            x4, x4, #0xc, #0x14
    // 0xcb7a84: sub             x4, x4, #0x3b
    // 0xcb7a88: cmp             x4, #1
    // 0xcb7a8c: b.ls            #0xcb7aa0
    // 0xcb7a90: r8 = int?
    //     0xcb7a90: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xcb7a94: r3 = Null
    //     0xcb7a94: add             x3, PP, #0x40, lsl #12  ; [pp+0x40820] Null
    //     0xcb7a98: ldr             x3, [x3, #0x820]
    // 0xcb7a9c: r0 = int?()
    //     0xcb7a9c: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xcb7aa0: ldur            x16, [fp, #-0x18]
    // 0xcb7aa4: SaveReg r16
    //     0xcb7aa4: str             x16, [SP, #-8]!
    // 0xcb7aa8: r0 = validDate()
    //     0xcb7aa8: bl              #0xa36958  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] FFmpegKitFactory::validDate
    // 0xcb7aac: add             SP, SP, #8
    // 0xcb7ab0: ldr             x1, [fp, #0x10]
    // 0xcb7ab4: r0 = LoadClassIdInstr(r1)
    //     0xcb7ab4: ldur            x0, [x1, #-1]
    //     0xcb7ab8: ubfx            x0, x0, #0xc, #0x14
    // 0xcb7abc: r16 = "startTime"
    //     0xcb7abc: ldr             x16, [PP, #0x2aa8]  ; [pp+0x2aa8] "startTime"
    // 0xcb7ac0: stp             x16, x1, [SP, #-0x10]!
    // 0xcb7ac4: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb7ac4: sub             lr, x0, #0xef
    //     0xcb7ac8: ldr             lr, [x21, lr, lsl #3]
    //     0xcb7acc: blr             lr
    // 0xcb7ad0: add             SP, SP, #0x10
    // 0xcb7ad4: mov             x3, x0
    // 0xcb7ad8: r2 = Null
    //     0xcb7ad8: mov             x2, NULL
    // 0xcb7adc: r1 = Null
    //     0xcb7adc: mov             x1, NULL
    // 0xcb7ae0: stur            x3, [fp, #-0x18]
    // 0xcb7ae4: branchIfSmi(r0, 0xcb7b0c)
    //     0xcb7ae4: tbz             w0, #0, #0xcb7b0c
    // 0xcb7ae8: r4 = LoadClassIdInstr(r0)
    //     0xcb7ae8: ldur            x4, [x0, #-1]
    //     0xcb7aec: ubfx            x4, x4, #0xc, #0x14
    // 0xcb7af0: sub             x4, x4, #0x3b
    // 0xcb7af4: cmp             x4, #1
    // 0xcb7af8: b.ls            #0xcb7b0c
    // 0xcb7afc: r8 = int?
    //     0xcb7afc: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xcb7b00: r3 = Null
    //     0xcb7b00: add             x3, PP, #0x40, lsl #12  ; [pp+0x40830] Null
    //     0xcb7b04: ldr             x3, [x3, #0x830]
    // 0xcb7b08: r0 = int?()
    //     0xcb7b08: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xcb7b0c: ldur            x16, [fp, #-0x18]
    // 0xcb7b10: SaveReg r16
    //     0xcb7b10: str             x16, [SP, #-8]!
    // 0xcb7b14: r0 = validDate()
    //     0xcb7b14: bl              #0xa36958  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] FFmpegKitFactory::validDate
    // 0xcb7b18: add             SP, SP, #8
    // 0xcb7b1c: ldr             x1, [fp, #0x10]
    // 0xcb7b20: r0 = LoadClassIdInstr(r1)
    //     0xcb7b20: ldur            x0, [x1, #-1]
    //     0xcb7b24: ubfx            x0, x0, #0xc, #0x14
    // 0xcb7b28: r16 = "command"
    //     0xcb7b28: add             x16, PP, #0x30, lsl #12  ; [pp+0x30008] "command"
    //     0xcb7b2c: ldr             x16, [x16, #8]
    // 0xcb7b30: stp             x16, x1, [SP, #-0x10]!
    // 0xcb7b34: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb7b34: sub             lr, x0, #0xef
    //     0xcb7b38: ldr             lr, [x21, lr, lsl #3]
    //     0xcb7b3c: blr             lr
    // 0xcb7b40: add             SP, SP, #0x10
    // 0xcb7b44: r2 = Null
    //     0xcb7b44: mov             x2, NULL
    // 0xcb7b48: r1 = Null
    //     0xcb7b48: mov             x1, NULL
    // 0xcb7b4c: r4 = 59
    //     0xcb7b4c: mov             x4, #0x3b
    // 0xcb7b50: branchIfSmi(r0, 0xcb7b5c)
    //     0xcb7b50: tbz             w0, #0, #0xcb7b5c
    // 0xcb7b54: r4 = LoadClassIdInstr(r0)
    //     0xcb7b54: ldur            x4, [x0, #-1]
    //     0xcb7b58: ubfx            x4, x4, #0xc, #0x14
    // 0xcb7b5c: sub             x4, x4, #0x5d
    // 0xcb7b60: cmp             x4, #3
    // 0xcb7b64: b.ls            #0xcb7b78
    // 0xcb7b68: r8 = String?
    //     0xcb7b68: ldr             x8, [PP, #0x2148]  ; [pp+0x2148] Type: String?
    // 0xcb7b6c: r3 = Null
    //     0xcb7b6c: add             x3, PP, #0x40, lsl #12  ; [pp+0x40840] Null
    //     0xcb7b70: ldr             x3, [x3, #0x840]
    // 0xcb7b74: r0 = String?()
    //     0xcb7b74: bl              #0x4b2994  ; IsType_String?_Stub
    // 0xcb7b78: ldr             x0, [fp, #0x10]
    // 0xcb7b7c: r1 = LoadClassIdInstr(r0)
    //     0xcb7b7c: ldur            x1, [x0, #-1]
    //     0xcb7b80: ubfx            x1, x1, #0xc, #0x14
    // 0xcb7b84: r16 = "command"
    //     0xcb7b84: add             x16, PP, #0x30, lsl #12  ; [pp+0x30008] "command"
    //     0xcb7b88: ldr             x16, [x16, #8]
    // 0xcb7b8c: stp             x16, x0, [SP, #-0x10]!
    // 0xcb7b90: mov             x0, x1
    // 0xcb7b94: r0 = GDT[cid_x0 + -0xef]()
    //     0xcb7b94: sub             lr, x0, #0xef
    //     0xcb7b98: ldr             lr, [x21, lr, lsl #3]
    //     0xcb7b9c: blr             lr
    // 0xcb7ba0: add             SP, SP, #0x10
    // 0xcb7ba4: mov             x3, x0
    // 0xcb7ba8: r2 = Null
    //     0xcb7ba8: mov             x2, NULL
    // 0xcb7bac: r1 = Null
    //     0xcb7bac: mov             x1, NULL
    // 0xcb7bb0: stur            x3, [fp, #-0x18]
    // 0xcb7bb4: r4 = 59
    //     0xcb7bb4: mov             x4, #0x3b
    // 0xcb7bb8: branchIfSmi(r0, 0xcb7bc4)
    //     0xcb7bb8: tbz             w0, #0, #0xcb7bc4
    // 0xcb7bbc: r4 = LoadClassIdInstr(r0)
    //     0xcb7bbc: ldur            x4, [x0, #-1]
    //     0xcb7bc0: ubfx            x4, x4, #0xc, #0x14
    // 0xcb7bc4: sub             x4, x4, #0x5d
    // 0xcb7bc8: cmp             x4, #3
    // 0xcb7bcc: b.ls            #0xcb7be0
    // 0xcb7bd0: r8 = String
    //     0xcb7bd0: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xcb7bd4: r3 = Null
    //     0xcb7bd4: add             x3, PP, #0x40, lsl #12  ; [pp+0x40850] Null
    //     0xcb7bd8: ldr             x3, [x3, #0x850]
    // 0xcb7bdc: r0 = String()
    //     0xcb7bdc: bl              #0xd72afc  ; IsType_String_Stub
    // 0xcb7be0: ldur            x16, [fp, #-0x18]
    // 0xcb7be4: SaveReg r16
    //     0xcb7be4: str             x16, [SP, #-8]!
    // 0xcb7be8: r0 = parseArguments()
    //     0xcb7be8: bl              #0xa36acc  ; [package:ffmpeg_kit_flutter_min/ffmpeg_kit_config.dart] FFmpegKitConfig::parseArguments
    // 0xcb7bec: add             SP, SP, #8
    // 0xcb7bf0: ldur            x16, [fp, #-8]
    // 0xcb7bf4: SaveReg r16
    //     0xcb7bf4: str             x16, [SP, #-8]!
    // 0xcb7bf8: r0 = getLogRedirectionStrategy()
    //     0xcb7bf8: bl              #0xcb759c  ; [package:ffmpeg_kit_flutter_min/src/ffmpeg_kit_factory.dart] FFmpegKitFactory::getLogRedirectionStrategy
    // 0xcb7bfc: add             SP, SP, #8
    // 0xcb7c00: ldur            x0, [fp, #-0x10]
    // 0xcb7c04: LeaveFrame
    //     0xcb7c04: mov             SP, fp
    //     0xcb7c08: ldp             fp, lr, [SP], #0x10
    // 0xcb7c0c: ret
    //     0xcb7c0c: ret             
    // 0xcb7c10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb7c10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb7c14: b               #0xcb79cc
  }
}

// lib: , url: package:archive/src/zlib_decoder.dart

// class id: 1048635, size: 0x8
class :: {
}

// class id: 4987, size: 0x8, field offset: 0x8
//   const constructor, 
class ZLibDecoder extends Object {

  _ decodeBytes(/* No info */) {
    // ** addr: 0xb96f8c, size: 0x40
    // 0xb96f8c: EnterFrame
    //     0xb96f8c: stp             fp, lr, [SP, #-0x10]!
    //     0xb96f90: mov             fp, SP
    // 0xb96f94: CheckStackOverflow
    //     0xb96f94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb96f98: cmp             SP, x16
    //     0xb96f9c: b.ls            #0xb96fc4
    // 0xb96fa0: r16 = Instance__ZLibDecoder
    //     0xb96fa0: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b150] Obj!_ZLibDecoder@b5c8d1
    //     0xb96fa4: ldr             x16, [x16, #0x150]
    // 0xb96fa8: ldr             lr, [fp, #0x10]
    // 0xb96fac: stp             lr, x16, [SP, #-0x10]!
    // 0xb96fb0: r0 = decodeBytes()
    //     0xb96fb0: bl              #0xb9ab60  ; [package:archive/src/zlib/_zlib_decoder_io.dart] _ZLibDecoder::decodeBytes
    // 0xb96fb4: add             SP, SP, #0x10
    // 0xb96fb8: LeaveFrame
    //     0xb96fb8: mov             SP, fp
    //     0xb96fbc: ldp             fp, lr, [SP], #0x10
    // 0xb96fc0: ret
    //     0xb96fc0: ret             
    // 0xb96fc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb96fc4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb96fc8: b               #0xb96fa0
  }
}

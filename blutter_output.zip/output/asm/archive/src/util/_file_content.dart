// lib: , url: package:archive/src/util/_file_content.dart

// class id: 1048610, size: 0x8
class :: {
}

// class id: 5005, size: 0x8, field offset: 0x8
abstract class FileContent extends Object {
}

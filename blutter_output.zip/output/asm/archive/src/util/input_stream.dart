// lib: , url: package:archive/src/util/input_stream.dart

// class id: 1048617, size: 0x8
class :: {
}

// class id: 5002, size: 0x8, field offset: 0x8
abstract class InputStreamBase extends Object {
}

// class id: 5003, size: 0x28, field offset: 0x8
class InputStream extends InputStreamBase {

  late int _length; // offset: 0x24

  _ toUint8List(/* No info */) {
    // ** addr: 0x7f57d4, size: 0x2c4
    // 0x7f57d4: EnterFrame
    //     0x7f57d4: stp             fp, lr, [SP, #-0x10]!
    //     0x7f57d8: mov             fp, SP
    // 0x7f57dc: AllocStack(0x28)
    //     0x7f57dc: sub             SP, SP, #0x28
    // 0x7f57e0: CheckStackOverflow
    //     0x7f57e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7f57e4: cmp             SP, x16
    //     0x7f57e8: b.ls            #0x7f5a84
    // 0x7f57ec: ldr             x3, [fp, #0x10]
    // 0x7f57f0: LoadField: r0 = r3->field_23
    //     0x7f57f0: ldur            w0, [x3, #0x23]
    // 0x7f57f4: DecompressPointer r0
    //     0x7f57f4: add             x0, x0, HEAP, lsl #32
    // 0x7f57f8: r16 = Sentinel
    //     0x7f57f8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7f57fc: cmp             w0, w16
    // 0x7f5800: b.eq            #0x7f5a8c
    // 0x7f5804: LoadField: r4 = r3->field_b
    //     0x7f5804: ldur            x4, [x3, #0xb]
    // 0x7f5808: stur            x4, [fp, #-0x18]
    // 0x7f580c: LoadField: r1 = r3->field_13
    //     0x7f580c: ldur            x1, [x3, #0x13]
    // 0x7f5810: sub             x2, x4, x1
    // 0x7f5814: r1 = LoadInt32Instr(r0)
    //     0x7f5814: sbfx            x1, x0, #1, #0x1f
    //     0x7f5818: tbz             w0, #0, #0x7f5820
    //     0x7f581c: ldur            x1, [x0, #7]
    // 0x7f5820: sub             x5, x1, x2
    // 0x7f5824: stur            x5, [fp, #-0x10]
    // 0x7f5828: LoadField: r6 = r3->field_7
    //     0x7f5828: ldur            w6, [x3, #7]
    // 0x7f582c: DecompressPointer r6
    //     0x7f582c: add             x6, x6, HEAP, lsl #32
    // 0x7f5830: stur            x6, [fp, #-8]
    // 0x7f5834: r0 = LoadClassIdInstr(r6)
    //     0x7f5834: ldur            x0, [x6, #-1]
    //     0x7f5838: ubfx            x0, x0, #0xc, #0x14
    // 0x7f583c: lsl             x0, x0, #1
    // 0x7f5840: r1 = LoadInt32Instr(r0)
    //     0x7f5840: sbfx            x1, x0, #1, #0x1f
    // 0x7f5844: cmp             x1, #0x75
    // 0x7f5848: b.lt            #0x7f5994
    // 0x7f584c: cmp             x1, #0x78
    // 0x7f5850: b.gt            #0x7f5984
    // 0x7f5854: mov             x0, x6
    // 0x7f5858: r2 = Null
    //     0x7f5858: mov             x2, NULL
    // 0x7f585c: r1 = Null
    //     0x7f585c: mov             x1, NULL
    // 0x7f5860: r4 = LoadClassIdInstr(r0)
    //     0x7f5860: ldur            x4, [x0, #-1]
    //     0x7f5864: ubfx            x4, x4, #0xc, #0x14
    // 0x7f5868: sub             x4, x4, #0x75
    // 0x7f586c: cmp             x4, #3
    // 0x7f5870: b.ls            #0x7f5888
    // 0x7f5874: r8 = Uint8List
    //     0x7f5874: add             x8, PP, #8, lsl #12  ; [pp+0x8760] Type: Uint8List
    //     0x7f5878: ldr             x8, [x8, #0x760]
    // 0x7f587c: r3 = Null
    //     0x7f587c: add             x3, PP, #0x34, lsl #12  ; [pp+0x34b90] Null
    //     0x7f5880: ldr             x3, [x3, #0xb90]
    // 0x7f5884: r0 = Uint8List()
    //     0x7f5884: bl              #0x4b2828  ; IsType_Uint8List_Stub
    // 0x7f5888: ldur            x0, [fp, #-0x18]
    // 0x7f588c: ldur            x1, [fp, #-0x10]
    // 0x7f5890: add             x2, x0, x1
    // 0x7f5894: ldur            x3, [fp, #-8]
    // 0x7f5898: LoadField: r4 = r3->field_13
    //     0x7f5898: ldur            w4, [x3, #0x13]
    // 0x7f589c: DecompressPointer r4
    //     0x7f589c: add             x4, x4, HEAP, lsl #32
    // 0x7f58a0: r5 = LoadInt32Instr(r4)
    //     0x7f58a0: sbfx            x5, x4, #1, #0x1f
    // 0x7f58a4: cmp             x2, x5
    // 0x7f58a8: b.le            #0x7f58b8
    // 0x7f58ac: sub             x1, x5, x0
    // 0x7f58b0: mov             x2, x1
    // 0x7f58b4: b               #0x7f58bc
    // 0x7f58b8: mov             x2, x1
    // 0x7f58bc: ldr             x1, [fp, #0x10]
    // 0x7f58c0: stur            x2, [fp, #-0x20]
    // 0x7f58c4: r0 = LoadClassIdInstr(r3)
    //     0x7f58c4: ldur            x0, [x3, #-1]
    //     0x7f58c8: ubfx            x0, x0, #0xc, #0x14
    // 0x7f58cc: SaveReg r3
    //     0x7f58cc: str             x3, [SP, #-8]!
    // 0x7f58d0: r0 = GDT[cid_x0 + -0xf7e]()
    //     0x7f58d0: sub             lr, x0, #0xf7e
    //     0x7f58d4: ldr             lr, [x21, lr, lsl #3]
    //     0x7f58d8: blr             lr
    // 0x7f58dc: add             SP, SP, #8
    // 0x7f58e0: mov             x1, x0
    // 0x7f58e4: ldur            x2, [fp, #-8]
    // 0x7f58e8: stur            x1, [fp, #-0x28]
    // 0x7f58ec: r0 = LoadClassIdInstr(r2)
    //     0x7f58ec: ldur            x0, [x2, #-1]
    //     0x7f58f0: ubfx            x0, x0, #0xc, #0x14
    // 0x7f58f4: SaveReg r2
    //     0x7f58f4: str             x2, [SP, #-8]!
    // 0x7f58f8: r0 = GDT[cid_x0 + -0xef6]()
    //     0x7f58f8: sub             lr, x0, #0xef6
    //     0x7f58fc: ldr             lr, [x21, lr, lsl #3]
    //     0x7f5900: blr             lr
    // 0x7f5904: add             SP, SP, #8
    // 0x7f5908: ldr             x3, [fp, #0x10]
    // 0x7f590c: LoadField: r1 = r3->field_b
    //     0x7f590c: ldur            x1, [x3, #0xb]
    // 0x7f5910: r2 = LoadInt32Instr(r0)
    //     0x7f5910: sbfx            x2, x0, #1, #0x1f
    // 0x7f5914: add             x3, x2, x1
    // 0x7f5918: ldur            x2, [fp, #-0x20]
    // 0x7f591c: r0 = BoxInt64Instr(r2)
    //     0x7f591c: sbfiz           x0, x2, #1, #0x1f
    //     0x7f5920: cmp             x2, x0, asr #1
    //     0x7f5924: b.eq            #0x7f5930
    //     0x7f5928: bl              #0xd69bb8
    //     0x7f592c: stur            x2, [x0, #7]
    // 0x7f5930: mov             x2, x0
    // 0x7f5934: r0 = BoxInt64Instr(r3)
    //     0x7f5934: sbfiz           x0, x3, #1, #0x1f
    //     0x7f5938: cmp             x3, x0, asr #1
    //     0x7f593c: b.eq            #0x7f5948
    //     0x7f5940: bl              #0xd69bb8
    //     0x7f5944: stur            x3, [x0, #7]
    // 0x7f5948: mov             x1, x0
    // 0x7f594c: ldur            x0, [fp, #-0x28]
    // 0x7f5950: r3 = LoadClassIdInstr(r0)
    //     0x7f5950: ldur            x3, [x0, #-1]
    //     0x7f5954: ubfx            x3, x3, #0xc, #0x14
    // 0x7f5958: stp             x1, x0, [SP, #-0x10]!
    // 0x7f595c: SaveReg r2
    //     0x7f595c: str             x2, [SP, #-8]!
    // 0x7f5960: mov             x0, x3
    // 0x7f5964: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x7f5964: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x7f5968: r0 = GDT[cid_x0 + -0xffc]()
    //     0x7f5968: sub             lr, x0, #0xffc
    //     0x7f596c: ldr             lr, [x21, lr, lsl #3]
    //     0x7f5970: blr             lr
    // 0x7f5974: add             SP, SP, #0x18
    // 0x7f5978: LeaveFrame
    //     0x7f5978: mov             SP, fp
    //     0x7f597c: ldp             fp, lr, [SP], #0x10
    // 0x7f5980: ret
    //     0x7f5980: ret             
    // 0x7f5984: mov             x2, x6
    // 0x7f5988: mov             x0, x4
    // 0x7f598c: mov             x1, x5
    // 0x7f5990: b               #0x7f59a0
    // 0x7f5994: mov             x2, x6
    // 0x7f5998: mov             x0, x4
    // 0x7f599c: mov             x1, x5
    // 0x7f59a0: add             x4, x0, x1
    // 0x7f59a4: stur            x4, [fp, #-0x20]
    // 0x7f59a8: r0 = LoadClassIdInstr(r2)
    //     0x7f59a8: ldur            x0, [x2, #-1]
    //     0x7f59ac: ubfx            x0, x0, #0xc, #0x14
    // 0x7f59b0: SaveReg r2
    //     0x7f59b0: str             x2, [SP, #-8]!
    // 0x7f59b4: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x7f59b4: mov             x17, #0xb8ea
    //     0x7f59b8: add             lr, x0, x17
    //     0x7f59bc: ldr             lr, [x21, lr, lsl #3]
    //     0x7f59c0: blr             lr
    // 0x7f59c4: add             SP, SP, #8
    // 0x7f59c8: r1 = LoadInt32Instr(r0)
    //     0x7f59c8: sbfx            x1, x0, #1, #0x1f
    // 0x7f59cc: ldur            x0, [fp, #-0x20]
    // 0x7f59d0: cmp             x0, x1
    // 0x7f59d4: b.le            #0x7f5a14
    // 0x7f59d8: ldr             x1, [fp, #0x10]
    // 0x7f59dc: LoadField: r0 = r1->field_7
    //     0x7f59dc: ldur            w0, [x1, #7]
    // 0x7f59e0: DecompressPointer r0
    //     0x7f59e0: add             x0, x0, HEAP, lsl #32
    // 0x7f59e4: r2 = LoadClassIdInstr(r0)
    //     0x7f59e4: ldur            x2, [x0, #-1]
    //     0x7f59e8: ubfx            x2, x2, #0xc, #0x14
    // 0x7f59ec: SaveReg r0
    //     0x7f59ec: str             x0, [SP, #-8]!
    // 0x7f59f0: mov             x0, x2
    // 0x7f59f4: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x7f59f4: mov             x17, #0xb8ea
    //     0x7f59f8: add             lr, x0, x17
    //     0x7f59fc: ldr             lr, [x21, lr, lsl #3]
    //     0x7f5a00: blr             lr
    // 0x7f5a04: add             SP, SP, #8
    // 0x7f5a08: r1 = LoadInt32Instr(r0)
    //     0x7f5a08: sbfx            x1, x0, #1, #0x1f
    // 0x7f5a0c: mov             x2, x1
    // 0x7f5a10: b               #0x7f5a18
    // 0x7f5a14: mov             x2, x0
    // 0x7f5a18: ldr             x0, [fp, #0x10]
    // 0x7f5a1c: LoadField: r3 = r0->field_7
    //     0x7f5a1c: ldur            w3, [x0, #7]
    // 0x7f5a20: DecompressPointer r3
    //     0x7f5a20: add             x3, x3, HEAP, lsl #32
    // 0x7f5a24: LoadField: r4 = r0->field_b
    //     0x7f5a24: ldur            x4, [x0, #0xb]
    // 0x7f5a28: r0 = BoxInt64Instr(r2)
    //     0x7f5a28: sbfiz           x0, x2, #1, #0x1f
    //     0x7f5a2c: cmp             x2, x0, asr #1
    //     0x7f5a30: b.eq            #0x7f5a3c
    //     0x7f5a34: bl              #0xd69bb8
    //     0x7f5a38: stur            x2, [x0, #7]
    // 0x7f5a3c: r1 = LoadClassIdInstr(r3)
    //     0x7f5a3c: ldur            x1, [x3, #-1]
    //     0x7f5a40: ubfx            x1, x1, #0xc, #0x14
    // 0x7f5a44: stp             x4, x3, [SP, #-0x10]!
    // 0x7f5a48: SaveReg r0
    //     0x7f5a48: str             x0, [SP, #-8]!
    // 0x7f5a4c: mov             x0, x1
    // 0x7f5a50: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x7f5a50: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x7f5a54: r0 = GDT[cid_x0 + 0x10217]()
    //     0x7f5a54: mov             x17, #0x217
    //     0x7f5a58: movk            x17, #1, lsl #16
    //     0x7f5a5c: add             lr, x0, x17
    //     0x7f5a60: ldr             lr, [x21, lr, lsl #3]
    //     0x7f5a64: blr             lr
    // 0x7f5a68: add             SP, SP, #0x18
    // 0x7f5a6c: stp             x0, NULL, [SP, #-0x10]!
    // 0x7f5a70: r0 = Uint8List.fromList()
    //     0x7f5a70: bl              #0x540140  ; [dart:typed_data] Uint8List::Uint8List.fromList
    // 0x7f5a74: add             SP, SP, #0x10
    // 0x7f5a78: LeaveFrame
    //     0x7f5a78: mov             SP, fp
    //     0x7f5a7c: ldp             fp, lr, [SP], #0x10
    // 0x7f5a80: ret
    //     0x7f5a80: ret             
    // 0x7f5a84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f5a84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f5a88: b               #0x7f57ec
    // 0x7f5a8c: r9 = _length
    //     0x7f5a8c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a20] Field <InputStream._length@54080104>: late (offset: 0x24)
    //     0x7f5a90: ldr             x9, [x9, #0xa20]
    // 0x7f5a94: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7f5a94: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  int [](InputStream, int) {
    // ** addr: 0x7f5ab0, size: 0xa0
    // 0x7f5ab0: EnterFrame
    //     0x7f5ab0: stp             fp, lr, [SP, #-0x10]!
    //     0x7f5ab4: mov             fp, SP
    // 0x7f5ab8: CheckStackOverflow
    //     0x7f5ab8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7f5abc: cmp             SP, x16
    //     0x7f5ac0: b.ls            #0x7f5b30
    // 0x7f5ac4: ldr             x0, [fp, #0x10]
    // 0x7f5ac8: r2 = Null
    //     0x7f5ac8: mov             x2, NULL
    // 0x7f5acc: r1 = Null
    //     0x7f5acc: mov             x1, NULL
    // 0x7f5ad0: branchIfSmi(r0, 0x7f5af8)
    //     0x7f5ad0: tbz             w0, #0, #0x7f5af8
    // 0x7f5ad4: r4 = LoadClassIdInstr(r0)
    //     0x7f5ad4: ldur            x4, [x0, #-1]
    //     0x7f5ad8: ubfx            x4, x4, #0xc, #0x14
    // 0x7f5adc: sub             x4, x4, #0x3b
    // 0x7f5ae0: cmp             x4, #1
    // 0x7f5ae4: b.ls            #0x7f5af8
    // 0x7f5ae8: r8 = int
    //     0x7f5ae8: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0x7f5aec: r3 = Null
    //     0x7f5aec: add             x3, PP, #0x41, lsl #12  ; [pp+0x414a0] Null
    //     0x7f5af0: ldr             x3, [x3, #0x4a0]
    // 0x7f5af4: r0 = int()
    //     0x7f5af4: bl              #0xd73714  ; IsType_int_Stub
    // 0x7f5af8: ldr             x16, [fp, #0x18]
    // 0x7f5afc: ldr             lr, [fp, #0x10]
    // 0x7f5b00: stp             lr, x16, [SP, #-0x10]!
    // 0x7f5b04: r0 = []()
    //     0x7f5b04: bl              #0x7f5b38  ; [package:archive/src/util/input_stream.dart] InputStream::[]
    // 0x7f5b08: add             SP, SP, #0x10
    // 0x7f5b0c: mov             x2, x0
    // 0x7f5b10: r0 = BoxInt64Instr(r2)
    //     0x7f5b10: sbfiz           x0, x2, #1, #0x1f
    //     0x7f5b14: cmp             x2, x0, asr #1
    //     0x7f5b18: b.eq            #0x7f5b24
    //     0x7f5b1c: bl              #0xd69bb8
    //     0x7f5b20: stur            x2, [x0, #7]
    // 0x7f5b24: LeaveFrame
    //     0x7f5b24: mov             SP, fp
    //     0x7f5b28: ldp             fp, lr, [SP], #0x10
    // 0x7f5b2c: ret
    //     0x7f5b2c: ret             
    // 0x7f5b30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f5b30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f5b34: b               #0x7f5ac4
  }
  int [](InputStream, int) {
    // ** addr: 0x7f5b38, size: 0x90
    // 0x7f5b38: EnterFrame
    //     0x7f5b38: stp             fp, lr, [SP, #-0x10]!
    //     0x7f5b3c: mov             fp, SP
    // 0x7f5b40: CheckStackOverflow
    //     0x7f5b40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7f5b44: cmp             SP, x16
    //     0x7f5b48: b.ls            #0x7f5bc0
    // 0x7f5b4c: ldr             x0, [fp, #0x18]
    // 0x7f5b50: LoadField: r2 = r0->field_7
    //     0x7f5b50: ldur            w2, [x0, #7]
    // 0x7f5b54: DecompressPointer r2
    //     0x7f5b54: add             x2, x2, HEAP, lsl #32
    // 0x7f5b58: LoadField: r1 = r0->field_b
    //     0x7f5b58: ldur            x1, [x0, #0xb]
    // 0x7f5b5c: ldr             x0, [fp, #0x10]
    // 0x7f5b60: r3 = LoadInt32Instr(r0)
    //     0x7f5b60: sbfx            x3, x0, #1, #0x1f
    //     0x7f5b64: tbz             w0, #0, #0x7f5b6c
    //     0x7f5b68: ldur            x3, [x0, #7]
    // 0x7f5b6c: add             x4, x1, x3
    // 0x7f5b70: r0 = BoxInt64Instr(r4)
    //     0x7f5b70: sbfiz           x0, x4, #1, #0x1f
    //     0x7f5b74: cmp             x4, x0, asr #1
    //     0x7f5b78: b.eq            #0x7f5b84
    //     0x7f5b7c: bl              #0xd69bb8
    //     0x7f5b80: stur            x4, [x0, #7]
    // 0x7f5b84: r1 = LoadClassIdInstr(r2)
    //     0x7f5b84: ldur            x1, [x2, #-1]
    //     0x7f5b88: ubfx            x1, x1, #0xc, #0x14
    // 0x7f5b8c: stp             x0, x2, [SP, #-0x10]!
    // 0x7f5b90: mov             x0, x1
    // 0x7f5b94: r0 = GDT[cid_x0 + -0xd83]()
    //     0x7f5b94: sub             lr, x0, #0xd83
    //     0x7f5b98: ldr             lr, [x21, lr, lsl #3]
    //     0x7f5b9c: blr             lr
    // 0x7f5ba0: add             SP, SP, #0x10
    // 0x7f5ba4: r1 = LoadInt32Instr(r0)
    //     0x7f5ba4: sbfx            x1, x0, #1, #0x1f
    //     0x7f5ba8: tbz             w0, #0, #0x7f5bb0
    //     0x7f5bac: ldur            x1, [x0, #7]
    // 0x7f5bb0: mov             x0, x1
    // 0x7f5bb4: LeaveFrame
    //     0x7f5bb4: mov             SP, fp
    //     0x7f5bb8: ldp             fp, lr, [SP], #0x10
    // 0x7f5bbc: ret
    //     0x7f5bbc: ret             
    // 0x7f5bc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f5bc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f5bc4: b               #0x7f5b4c
  }
  int dyn:get:length(InputStream) {
    // ** addr: 0x7f5be0, size: 0x80
    // 0x7f5be0: EnterFrame
    //     0x7f5be0: stp             fp, lr, [SP, #-0x10]!
    //     0x7f5be4: mov             fp, SP
    // 0x7f5be8: ldr             x2, [fp, #0x10]
    // 0x7f5bec: LoadField: r3 = r2->field_23
    //     0x7f5bec: ldur            w3, [x2, #0x23]
    // 0x7f5bf0: DecompressPointer r3
    //     0x7f5bf0: add             x3, x3, HEAP, lsl #32
    // 0x7f5bf4: r16 = Sentinel
    //     0x7f5bf4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7f5bf8: cmp             w3, w16
    // 0x7f5bfc: b.eq            #0x7f5c3c
    // 0x7f5c00: LoadField: r4 = r2->field_b
    //     0x7f5c00: ldur            x4, [x2, #0xb]
    // 0x7f5c04: LoadField: r5 = r2->field_13
    //     0x7f5c04: ldur            x5, [x2, #0x13]
    // 0x7f5c08: sub             x2, x4, x5
    // 0x7f5c0c: r4 = LoadInt32Instr(r3)
    //     0x7f5c0c: sbfx            x4, x3, #1, #0x1f
    //     0x7f5c10: tbz             w3, #0, #0x7f5c18
    //     0x7f5c14: ldur            x4, [x3, #7]
    // 0x7f5c18: sub             x3, x4, x2
    // 0x7f5c1c: r0 = BoxInt64Instr(r3)
    //     0x7f5c1c: sbfiz           x0, x3, #1, #0x1f
    //     0x7f5c20: cmp             x3, x0, asr #1
    //     0x7f5c24: b.eq            #0x7f5c30
    //     0x7f5c28: bl              #0xd69bb8
    //     0x7f5c2c: stur            x3, [x0, #7]
    // 0x7f5c30: LeaveFrame
    //     0x7f5c30: mov             SP, fp
    //     0x7f5c34: ldp             fp, lr, [SP], #0x10
    // 0x7f5c38: ret
    //     0x7f5c38: ret             
    // 0x7f5c3c: r9 = _length
    //     0x7f5c3c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a20] Field <InputStream._length@54080104>: late (offset: 0x24)
    //     0x7f5c40: ldr             x9, [x9, #0xa20]
    // 0x7f5c44: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7f5c44: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  int length(InputStream) {
    // ** addr: 0x7f5c48, size: 0x54
    // 0x7f5c48: EnterFrame
    //     0x7f5c48: stp             fp, lr, [SP, #-0x10]!
    //     0x7f5c4c: mov             fp, SP
    // 0x7f5c50: ldr             x1, [fp, #0x10]
    // 0x7f5c54: LoadField: r2 = r1->field_23
    //     0x7f5c54: ldur            w2, [x1, #0x23]
    // 0x7f5c58: DecompressPointer r2
    //     0x7f5c58: add             x2, x2, HEAP, lsl #32
    // 0x7f5c5c: r16 = Sentinel
    //     0x7f5c5c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7f5c60: cmp             w2, w16
    // 0x7f5c64: b.eq            #0x7f5c90
    // 0x7f5c68: LoadField: r3 = r1->field_b
    //     0x7f5c68: ldur            x3, [x1, #0xb]
    // 0x7f5c6c: LoadField: r4 = r1->field_13
    //     0x7f5c6c: ldur            x4, [x1, #0x13]
    // 0x7f5c70: sub             x1, x3, x4
    // 0x7f5c74: r3 = LoadInt32Instr(r2)
    //     0x7f5c74: sbfx            x3, x2, #1, #0x1f
    //     0x7f5c78: tbz             w2, #0, #0x7f5c80
    //     0x7f5c7c: ldur            x3, [x2, #7]
    // 0x7f5c80: sub             x0, x3, x1
    // 0x7f5c84: LeaveFrame
    //     0x7f5c84: mov             SP, fp
    //     0x7f5c88: ldp             fp, lr, [SP], #0x10
    // 0x7f5c8c: ret
    //     0x7f5c8c: ret             
    // 0x7f5c90: r9 = _length
    //     0x7f5c90: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a20] Field <InputStream._length@54080104>: late (offset: 0x24)
    //     0x7f5c94: ldr             x9, [x9, #0xa20]
    // 0x7f5c98: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7f5c98: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  int readByte(InputStream) {
    // ** addr: 0x817848, size: 0x84
    // 0x817848: EnterFrame
    //     0x817848: stp             fp, lr, [SP, #-0x10]!
    //     0x81784c: mov             fp, SP
    // 0x817850: CheckStackOverflow
    //     0x817850: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x817854: cmp             SP, x16
    //     0x817858: b.ls            #0x8178c4
    // 0x81785c: ldr             x0, [fp, #0x10]
    // 0x817860: LoadField: r2 = r0->field_7
    //     0x817860: ldur            w2, [x0, #7]
    // 0x817864: DecompressPointer r2
    //     0x817864: add             x2, x2, HEAP, lsl #32
    // 0x817868: LoadField: r3 = r0->field_b
    //     0x817868: ldur            x3, [x0, #0xb]
    // 0x81786c: add             x1, x3, #1
    // 0x817870: StoreField: r0->field_b = r1
    //     0x817870: stur            x1, [x0, #0xb]
    // 0x817874: r0 = BoxInt64Instr(r3)
    //     0x817874: sbfiz           x0, x3, #1, #0x1f
    //     0x817878: cmp             x3, x0, asr #1
    //     0x81787c: b.eq            #0x817888
    //     0x817880: bl              #0xd69bb8
    //     0x817884: stur            x3, [x0, #7]
    // 0x817888: r1 = LoadClassIdInstr(r2)
    //     0x817888: ldur            x1, [x2, #-1]
    //     0x81788c: ubfx            x1, x1, #0xc, #0x14
    // 0x817890: stp             x0, x2, [SP, #-0x10]!
    // 0x817894: mov             x0, x1
    // 0x817898: r0 = GDT[cid_x0 + -0xd83]()
    //     0x817898: sub             lr, x0, #0xd83
    //     0x81789c: ldr             lr, [x21, lr, lsl #3]
    //     0x8178a0: blr             lr
    // 0x8178a4: add             SP, SP, #0x10
    // 0x8178a8: r1 = LoadInt32Instr(r0)
    //     0x8178a8: sbfx            x1, x0, #1, #0x1f
    //     0x8178ac: tbz             w0, #0, #0x8178b4
    //     0x8178b0: ldur            x1, [x0, #7]
    // 0x8178b4: mov             x0, x1
    // 0x8178b8: LeaveFrame
    //     0x8178b8: mov             SP, fp
    //     0x8178bc: ldp             fp, lr, [SP], #0x10
    // 0x8178c0: ret
    //     0x8178c0: ret             
    // 0x8178c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8178c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8178c8: b               #0x81785c
  }
  int readUint64(InputStream) {
    // ** addr: 0x8178d8, size: 0x454
    // 0x8178d8: EnterFrame
    //     0x8178d8: stp             fp, lr, [SP, #-0x10]!
    //     0x8178dc: mov             fp, SP
    // 0x8178e0: AllocStack(0x38)
    //     0x8178e0: sub             SP, SP, #0x38
    // 0x8178e4: CheckStackOverflow
    //     0x8178e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8178e8: cmp             SP, x16
    //     0x8178ec: b.ls            #0x817d24
    // 0x8178f0: ldr             x2, [fp, #0x10]
    // 0x8178f4: LoadField: r3 = r2->field_7
    //     0x8178f4: ldur            w3, [x2, #7]
    // 0x8178f8: DecompressPointer r3
    //     0x8178f8: add             x3, x3, HEAP, lsl #32
    // 0x8178fc: LoadField: r4 = r2->field_b
    //     0x8178fc: ldur            x4, [x2, #0xb]
    // 0x817900: add             x0, x4, #1
    // 0x817904: StoreField: r2->field_b = r0
    //     0x817904: stur            x0, [x2, #0xb]
    // 0x817908: r0 = BoxInt64Instr(r4)
    //     0x817908: sbfiz           x0, x4, #1, #0x1f
    //     0x81790c: cmp             x4, x0, asr #1
    //     0x817910: b.eq            #0x81791c
    //     0x817914: bl              #0xd69bb8
    //     0x817918: stur            x4, [x0, #7]
    // 0x81791c: r1 = LoadClassIdInstr(r3)
    //     0x81791c: ldur            x1, [x3, #-1]
    //     0x817920: ubfx            x1, x1, #0xc, #0x14
    // 0x817924: stp             x0, x3, [SP, #-0x10]!
    // 0x817928: mov             x0, x1
    // 0x81792c: r0 = GDT[cid_x0 + -0xd83]()
    //     0x81792c: sub             lr, x0, #0xd83
    //     0x817930: ldr             lr, [x21, lr, lsl #3]
    //     0x817934: blr             lr
    // 0x817938: add             SP, SP, #0x10
    // 0x81793c: r1 = LoadInt32Instr(r0)
    //     0x81793c: sbfx            x1, x0, #1, #0x1f
    //     0x817940: tbz             w0, #0, #0x817948
    //     0x817944: ldur            x1, [x0, #7]
    // 0x817948: r2 = 255
    //     0x817948: mov             x2, #0xff
    // 0x81794c: and             x3, x1, x2
    // 0x817950: ldr             x4, [fp, #0x10]
    // 0x817954: stur            x3, [fp, #-8]
    // 0x817958: LoadField: r5 = r4->field_7
    //     0x817958: ldur            w5, [x4, #7]
    // 0x81795c: DecompressPointer r5
    //     0x81795c: add             x5, x5, HEAP, lsl #32
    // 0x817960: LoadField: r6 = r4->field_b
    //     0x817960: ldur            x6, [x4, #0xb]
    // 0x817964: add             x0, x6, #1
    // 0x817968: StoreField: r4->field_b = r0
    //     0x817968: stur            x0, [x4, #0xb]
    // 0x81796c: r0 = BoxInt64Instr(r6)
    //     0x81796c: sbfiz           x0, x6, #1, #0x1f
    //     0x817970: cmp             x6, x0, asr #1
    //     0x817974: b.eq            #0x817980
    //     0x817978: bl              #0xd69bb8
    //     0x81797c: stur            x6, [x0, #7]
    // 0x817980: r1 = LoadClassIdInstr(r5)
    //     0x817980: ldur            x1, [x5, #-1]
    //     0x817984: ubfx            x1, x1, #0xc, #0x14
    // 0x817988: stp             x0, x5, [SP, #-0x10]!
    // 0x81798c: mov             x0, x1
    // 0x817990: r0 = GDT[cid_x0 + -0xd83]()
    //     0x817990: sub             lr, x0, #0xd83
    //     0x817994: ldr             lr, [x21, lr, lsl #3]
    //     0x817998: blr             lr
    // 0x81799c: add             SP, SP, #0x10
    // 0x8179a0: r1 = LoadInt32Instr(r0)
    //     0x8179a0: sbfx            x1, x0, #1, #0x1f
    //     0x8179a4: tbz             w0, #0, #0x8179ac
    //     0x8179a8: ldur            x1, [x0, #7]
    // 0x8179ac: r2 = 255
    //     0x8179ac: mov             x2, #0xff
    // 0x8179b0: and             x3, x1, x2
    // 0x8179b4: ldr             x4, [fp, #0x10]
    // 0x8179b8: stur            x3, [fp, #-0x10]
    // 0x8179bc: LoadField: r5 = r4->field_7
    //     0x8179bc: ldur            w5, [x4, #7]
    // 0x8179c0: DecompressPointer r5
    //     0x8179c0: add             x5, x5, HEAP, lsl #32
    // 0x8179c4: LoadField: r6 = r4->field_b
    //     0x8179c4: ldur            x6, [x4, #0xb]
    // 0x8179c8: add             x0, x6, #1
    // 0x8179cc: StoreField: r4->field_b = r0
    //     0x8179cc: stur            x0, [x4, #0xb]
    // 0x8179d0: r0 = BoxInt64Instr(r6)
    //     0x8179d0: sbfiz           x0, x6, #1, #0x1f
    //     0x8179d4: cmp             x6, x0, asr #1
    //     0x8179d8: b.eq            #0x8179e4
    //     0x8179dc: bl              #0xd69bb8
    //     0x8179e0: stur            x6, [x0, #7]
    // 0x8179e4: r1 = LoadClassIdInstr(r5)
    //     0x8179e4: ldur            x1, [x5, #-1]
    //     0x8179e8: ubfx            x1, x1, #0xc, #0x14
    // 0x8179ec: stp             x0, x5, [SP, #-0x10]!
    // 0x8179f0: mov             x0, x1
    // 0x8179f4: r0 = GDT[cid_x0 + -0xd83]()
    //     0x8179f4: sub             lr, x0, #0xd83
    //     0x8179f8: ldr             lr, [x21, lr, lsl #3]
    //     0x8179fc: blr             lr
    // 0x817a00: add             SP, SP, #0x10
    // 0x817a04: r1 = LoadInt32Instr(r0)
    //     0x817a04: sbfx            x1, x0, #1, #0x1f
    //     0x817a08: tbz             w0, #0, #0x817a10
    //     0x817a0c: ldur            x1, [x0, #7]
    // 0x817a10: r2 = 255
    //     0x817a10: mov             x2, #0xff
    // 0x817a14: and             x3, x1, x2
    // 0x817a18: ldr             x4, [fp, #0x10]
    // 0x817a1c: stur            x3, [fp, #-0x18]
    // 0x817a20: LoadField: r5 = r4->field_7
    //     0x817a20: ldur            w5, [x4, #7]
    // 0x817a24: DecompressPointer r5
    //     0x817a24: add             x5, x5, HEAP, lsl #32
    // 0x817a28: LoadField: r6 = r4->field_b
    //     0x817a28: ldur            x6, [x4, #0xb]
    // 0x817a2c: add             x0, x6, #1
    // 0x817a30: StoreField: r4->field_b = r0
    //     0x817a30: stur            x0, [x4, #0xb]
    // 0x817a34: r0 = BoxInt64Instr(r6)
    //     0x817a34: sbfiz           x0, x6, #1, #0x1f
    //     0x817a38: cmp             x6, x0, asr #1
    //     0x817a3c: b.eq            #0x817a48
    //     0x817a40: bl              #0xd69bb8
    //     0x817a44: stur            x6, [x0, #7]
    // 0x817a48: r1 = LoadClassIdInstr(r5)
    //     0x817a48: ldur            x1, [x5, #-1]
    //     0x817a4c: ubfx            x1, x1, #0xc, #0x14
    // 0x817a50: stp             x0, x5, [SP, #-0x10]!
    // 0x817a54: mov             x0, x1
    // 0x817a58: r0 = GDT[cid_x0 + -0xd83]()
    //     0x817a58: sub             lr, x0, #0xd83
    //     0x817a5c: ldr             lr, [x21, lr, lsl #3]
    //     0x817a60: blr             lr
    // 0x817a64: add             SP, SP, #0x10
    // 0x817a68: r1 = LoadInt32Instr(r0)
    //     0x817a68: sbfx            x1, x0, #1, #0x1f
    //     0x817a6c: tbz             w0, #0, #0x817a74
    //     0x817a70: ldur            x1, [x0, #7]
    // 0x817a74: r2 = 255
    //     0x817a74: mov             x2, #0xff
    // 0x817a78: and             x3, x1, x2
    // 0x817a7c: ldr             x4, [fp, #0x10]
    // 0x817a80: stur            x3, [fp, #-0x20]
    // 0x817a84: LoadField: r5 = r4->field_7
    //     0x817a84: ldur            w5, [x4, #7]
    // 0x817a88: DecompressPointer r5
    //     0x817a88: add             x5, x5, HEAP, lsl #32
    // 0x817a8c: LoadField: r6 = r4->field_b
    //     0x817a8c: ldur            x6, [x4, #0xb]
    // 0x817a90: add             x0, x6, #1
    // 0x817a94: StoreField: r4->field_b = r0
    //     0x817a94: stur            x0, [x4, #0xb]
    // 0x817a98: r0 = BoxInt64Instr(r6)
    //     0x817a98: sbfiz           x0, x6, #1, #0x1f
    //     0x817a9c: cmp             x6, x0, asr #1
    //     0x817aa0: b.eq            #0x817aac
    //     0x817aa4: bl              #0xd69bb8
    //     0x817aa8: stur            x6, [x0, #7]
    // 0x817aac: r1 = LoadClassIdInstr(r5)
    //     0x817aac: ldur            x1, [x5, #-1]
    //     0x817ab0: ubfx            x1, x1, #0xc, #0x14
    // 0x817ab4: stp             x0, x5, [SP, #-0x10]!
    // 0x817ab8: mov             x0, x1
    // 0x817abc: r0 = GDT[cid_x0 + -0xd83]()
    //     0x817abc: sub             lr, x0, #0xd83
    //     0x817ac0: ldr             lr, [x21, lr, lsl #3]
    //     0x817ac4: blr             lr
    // 0x817ac8: add             SP, SP, #0x10
    // 0x817acc: r1 = LoadInt32Instr(r0)
    //     0x817acc: sbfx            x1, x0, #1, #0x1f
    //     0x817ad0: tbz             w0, #0, #0x817ad8
    //     0x817ad4: ldur            x1, [x0, #7]
    // 0x817ad8: r2 = 255
    //     0x817ad8: mov             x2, #0xff
    // 0x817adc: and             x3, x1, x2
    // 0x817ae0: ldr             x4, [fp, #0x10]
    // 0x817ae4: stur            x3, [fp, #-0x28]
    // 0x817ae8: LoadField: r5 = r4->field_7
    //     0x817ae8: ldur            w5, [x4, #7]
    // 0x817aec: DecompressPointer r5
    //     0x817aec: add             x5, x5, HEAP, lsl #32
    // 0x817af0: LoadField: r6 = r4->field_b
    //     0x817af0: ldur            x6, [x4, #0xb]
    // 0x817af4: add             x0, x6, #1
    // 0x817af8: StoreField: r4->field_b = r0
    //     0x817af8: stur            x0, [x4, #0xb]
    // 0x817afc: r0 = BoxInt64Instr(r6)
    //     0x817afc: sbfiz           x0, x6, #1, #0x1f
    //     0x817b00: cmp             x6, x0, asr #1
    //     0x817b04: b.eq            #0x817b10
    //     0x817b08: bl              #0xd69bb8
    //     0x817b0c: stur            x6, [x0, #7]
    // 0x817b10: r1 = LoadClassIdInstr(r5)
    //     0x817b10: ldur            x1, [x5, #-1]
    //     0x817b14: ubfx            x1, x1, #0xc, #0x14
    // 0x817b18: stp             x0, x5, [SP, #-0x10]!
    // 0x817b1c: mov             x0, x1
    // 0x817b20: r0 = GDT[cid_x0 + -0xd83]()
    //     0x817b20: sub             lr, x0, #0xd83
    //     0x817b24: ldr             lr, [x21, lr, lsl #3]
    //     0x817b28: blr             lr
    // 0x817b2c: add             SP, SP, #0x10
    // 0x817b30: r1 = LoadInt32Instr(r0)
    //     0x817b30: sbfx            x1, x0, #1, #0x1f
    //     0x817b34: tbz             w0, #0, #0x817b3c
    //     0x817b38: ldur            x1, [x0, #7]
    // 0x817b3c: r2 = 255
    //     0x817b3c: mov             x2, #0xff
    // 0x817b40: and             x3, x1, x2
    // 0x817b44: ldr             x4, [fp, #0x10]
    // 0x817b48: stur            x3, [fp, #-0x30]
    // 0x817b4c: LoadField: r5 = r4->field_7
    //     0x817b4c: ldur            w5, [x4, #7]
    // 0x817b50: DecompressPointer r5
    //     0x817b50: add             x5, x5, HEAP, lsl #32
    // 0x817b54: LoadField: r6 = r4->field_b
    //     0x817b54: ldur            x6, [x4, #0xb]
    // 0x817b58: add             x0, x6, #1
    // 0x817b5c: StoreField: r4->field_b = r0
    //     0x817b5c: stur            x0, [x4, #0xb]
    // 0x817b60: r0 = BoxInt64Instr(r6)
    //     0x817b60: sbfiz           x0, x6, #1, #0x1f
    //     0x817b64: cmp             x6, x0, asr #1
    //     0x817b68: b.eq            #0x817b74
    //     0x817b6c: bl              #0xd69bb8
    //     0x817b70: stur            x6, [x0, #7]
    // 0x817b74: r1 = LoadClassIdInstr(r5)
    //     0x817b74: ldur            x1, [x5, #-1]
    //     0x817b78: ubfx            x1, x1, #0xc, #0x14
    // 0x817b7c: stp             x0, x5, [SP, #-0x10]!
    // 0x817b80: mov             x0, x1
    // 0x817b84: r0 = GDT[cid_x0 + -0xd83]()
    //     0x817b84: sub             lr, x0, #0xd83
    //     0x817b88: ldr             lr, [x21, lr, lsl #3]
    //     0x817b8c: blr             lr
    // 0x817b90: add             SP, SP, #0x10
    // 0x817b94: r1 = LoadInt32Instr(r0)
    //     0x817b94: sbfx            x1, x0, #1, #0x1f
    //     0x817b98: tbz             w0, #0, #0x817ba0
    //     0x817b9c: ldur            x1, [x0, #7]
    // 0x817ba0: r2 = 255
    //     0x817ba0: mov             x2, #0xff
    // 0x817ba4: and             x3, x1, x2
    // 0x817ba8: ldr             x4, [fp, #0x10]
    // 0x817bac: stur            x3, [fp, #-0x38]
    // 0x817bb0: LoadField: r5 = r4->field_7
    //     0x817bb0: ldur            w5, [x4, #7]
    // 0x817bb4: DecompressPointer r5
    //     0x817bb4: add             x5, x5, HEAP, lsl #32
    // 0x817bb8: LoadField: r6 = r4->field_b
    //     0x817bb8: ldur            x6, [x4, #0xb]
    // 0x817bbc: add             x0, x6, #1
    // 0x817bc0: StoreField: r4->field_b = r0
    //     0x817bc0: stur            x0, [x4, #0xb]
    // 0x817bc4: r0 = BoxInt64Instr(r6)
    //     0x817bc4: sbfiz           x0, x6, #1, #0x1f
    //     0x817bc8: cmp             x6, x0, asr #1
    //     0x817bcc: b.eq            #0x817bd8
    //     0x817bd0: bl              #0xd69bb8
    //     0x817bd4: stur            x6, [x0, #7]
    // 0x817bd8: r1 = LoadClassIdInstr(r5)
    //     0x817bd8: ldur            x1, [x5, #-1]
    //     0x817bdc: ubfx            x1, x1, #0xc, #0x14
    // 0x817be0: stp             x0, x5, [SP, #-0x10]!
    // 0x817be4: mov             x0, x1
    // 0x817be8: r0 = GDT[cid_x0 + -0xd83]()
    //     0x817be8: sub             lr, x0, #0xd83
    //     0x817bec: ldr             lr, [x21, lr, lsl #3]
    //     0x817bf0: blr             lr
    // 0x817bf4: add             SP, SP, #0x10
    // 0x817bf8: r1 = LoadInt32Instr(r0)
    //     0x817bf8: sbfx            x1, x0, #1, #0x1f
    //     0x817bfc: tbz             w0, #0, #0x817c04
    //     0x817c00: ldur            x1, [x0, #7]
    // 0x817c04: r2 = 255
    //     0x817c04: mov             x2, #0xff
    // 0x817c08: and             x3, x1, x2
    // 0x817c0c: ldr             x1, [fp, #0x10]
    // 0x817c10: LoadField: r2 = r1->field_1b
    //     0x817c10: ldur            x2, [x1, #0x1b]
    // 0x817c14: lsl             x1, x2, #1
    // 0x817c18: cmp             w1, #2
    // 0x817c1c: b.ne            #0x817ca4
    // 0x817c20: ldur            x1, [fp, #-8]
    // 0x817c24: ubfx            x1, x1, #0, #0x20
    // 0x817c28: lsl             x2, x1, #0x38
    // 0x817c2c: ldur            x1, [fp, #-0x10]
    // 0x817c30: ubfx            x1, x1, #0, #0x20
    // 0x817c34: lsl             x4, x1, #0x30
    // 0x817c38: orr             x1, x2, x4
    // 0x817c3c: ldur            x2, [fp, #-0x18]
    // 0x817c40: ubfx            x2, x2, #0, #0x20
    // 0x817c44: lsl             x4, x2, #0x28
    // 0x817c48: orr             x2, x1, x4
    // 0x817c4c: ldur            x1, [fp, #-0x20]
    // 0x817c50: ubfx            x1, x1, #0, #0x20
    // 0x817c54: lsl             x4, x1, #0x20
    // 0x817c58: orr             x1, x2, x4
    // 0x817c5c: ldur            x2, [fp, #-0x28]
    // 0x817c60: ubfx            x2, x2, #0, #0x20
    // 0x817c64: lsl             x4, x2, #0x18
    // 0x817c68: orr             x2, x1, x4
    // 0x817c6c: ldur            x1, [fp, #-0x30]
    // 0x817c70: ubfx            x1, x1, #0, #0x20
    // 0x817c74: lsl             x4, x1, #0x10
    // 0x817c78: orr             x1, x2, x4
    // 0x817c7c: ldur            x2, [fp, #-0x38]
    // 0x817c80: ubfx            x2, x2, #0, #0x20
    // 0x817c84: lsl             x4, x2, #8
    // 0x817c88: orr             x2, x1, x4
    // 0x817c8c: mov             x1, x3
    // 0x817c90: ubfx            x1, x1, #0, #0x20
    // 0x817c94: orr             x0, x2, x1
    // 0x817c98: LeaveFrame
    //     0x817c98: mov             SP, fp
    //     0x817c9c: ldp             fp, lr, [SP], #0x10
    // 0x817ca0: ret
    //     0x817ca0: ret             
    // 0x817ca4: ubfx            x3, x3, #0, #0x20
    // 0x817ca8: lsl             x1, x3, #0x38
    // 0x817cac: ldur            x2, [fp, #-0x38]
    // 0x817cb0: ubfx            x2, x2, #0, #0x20
    // 0x817cb4: lsl             x3, x2, #0x30
    // 0x817cb8: orr             x2, x1, x3
    // 0x817cbc: ldur            x1, [fp, #-0x30]
    // 0x817cc0: ubfx            x1, x1, #0, #0x20
    // 0x817cc4: lsl             x3, x1, #0x28
    // 0x817cc8: orr             x1, x2, x3
    // 0x817ccc: ldur            x2, [fp, #-0x28]
    // 0x817cd0: ubfx            x2, x2, #0, #0x20
    // 0x817cd4: lsl             x3, x2, #0x20
    // 0x817cd8: orr             x2, x1, x3
    // 0x817cdc: ldur            x1, [fp, #-0x20]
    // 0x817ce0: ubfx            x1, x1, #0, #0x20
    // 0x817ce4: lsl             x3, x1, #0x18
    // 0x817ce8: orr             x1, x2, x3
    // 0x817cec: ldur            x2, [fp, #-0x18]
    // 0x817cf0: ubfx            x2, x2, #0, #0x20
    // 0x817cf4: lsl             x3, x2, #0x10
    // 0x817cf8: orr             x2, x1, x3
    // 0x817cfc: ldur            x1, [fp, #-0x10]
    // 0x817d00: ubfx            x1, x1, #0, #0x20
    // 0x817d04: lsl             x3, x1, #8
    // 0x817d08: orr             x1, x2, x3
    // 0x817d0c: ldur            x2, [fp, #-8]
    // 0x817d10: ubfx            x2, x2, #0, #0x20
    // 0x817d14: orr             x0, x1, x2
    // 0x817d18: LeaveFrame
    //     0x817d18: mov             SP, fp
    //     0x817d1c: ldp             fp, lr, [SP], #0x10
    // 0x817d20: ret
    //     0x817d20: ret             
    // 0x817d24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x817d24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x817d28: b               #0x8178f0
  }
  _ rewind(/* No info */) {
    // ** addr: 0x817d2c, size: 0x28
    // 0x817d2c: ldr             x1, [SP, #8]
    // 0x817d30: LoadField: r2 = r1->field_b
    //     0x817d30: ldur            x2, [x1, #0xb]
    // 0x817d34: ldr             x3, [SP]
    // 0x817d38: sub             x4, x2, x3
    // 0x817d3c: StoreField: r1->field_b = r4
    //     0x817d3c: stur            x4, [x1, #0xb]
    // 0x817d40: tbz             x4, #0x3f, #0x817d4c
    // 0x817d44: r2 = 0
    //     0x817d44: mov             x2, #0
    // 0x817d48: StoreField: r1->field_b = r2
    //     0x817d48: stur            x2, [x1, #0xb]
    // 0x817d4c: r0 = Null
    //     0x817d4c: mov             x0, NULL
    // 0x817d50: ret
    //     0x817d50: ret             
  }
  _ readBytes(/* No info */) {
    // ** addr: 0x817d54, size: 0xac
    // 0x817d54: EnterFrame
    //     0x817d54: stp             fp, lr, [SP, #-0x10]!
    //     0x817d58: mov             fp, SP
    // 0x817d5c: CheckStackOverflow
    //     0x817d5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x817d60: cmp             SP, x16
    //     0x817d64: b.ls            #0x817dec
    // 0x817d68: ldr             x2, [fp, #0x18]
    // 0x817d6c: LoadField: r0 = r2->field_b
    //     0x817d6c: ldur            x0, [x2, #0xb]
    // 0x817d70: LoadField: r1 = r2->field_13
    //     0x817d70: ldur            x1, [x2, #0x13]
    // 0x817d74: sub             x3, x0, x1
    // 0x817d78: r0 = BoxInt64Instr(r3)
    //     0x817d78: sbfiz           x0, x3, #1, #0x1f
    //     0x817d7c: cmp             x3, x0, asr #1
    //     0x817d80: b.eq            #0x817d8c
    //     0x817d84: bl              #0xd69bb8
    //     0x817d88: stur            x3, [x0, #7]
    // 0x817d8c: stp             x0, x2, [SP, #-0x10]!
    // 0x817d90: ldr             x0, [fp, #0x10]
    // 0x817d94: SaveReg r0
    //     0x817d94: str             x0, [SP, #-8]!
    // 0x817d98: r0 = subset()
    //     0x817d98: bl              #0x817e0c  ; [package:archive/src/util/input_stream.dart] InputStream::subset
    // 0x817d9c: add             SP, SP, #0x18
    // 0x817da0: ldr             x1, [fp, #0x18]
    // 0x817da4: LoadField: r2 = r1->field_b
    //     0x817da4: ldur            x2, [x1, #0xb]
    // 0x817da8: LoadField: r3 = r0->field_23
    //     0x817da8: ldur            w3, [x0, #0x23]
    // 0x817dac: DecompressPointer r3
    //     0x817dac: add             x3, x3, HEAP, lsl #32
    // 0x817db0: r16 = Sentinel
    //     0x817db0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x817db4: cmp             w3, w16
    // 0x817db8: b.eq            #0x817df4
    // 0x817dbc: LoadField: r4 = r0->field_b
    //     0x817dbc: ldur            x4, [x0, #0xb]
    // 0x817dc0: LoadField: r5 = r0->field_13
    //     0x817dc0: ldur            x5, [x0, #0x13]
    // 0x817dc4: sub             x6, x4, x5
    // 0x817dc8: r4 = LoadInt32Instr(r3)
    //     0x817dc8: sbfx            x4, x3, #1, #0x1f
    //     0x817dcc: tbz             w3, #0, #0x817dd4
    //     0x817dd0: ldur            x4, [x3, #7]
    // 0x817dd4: sub             x3, x4, x6
    // 0x817dd8: add             x4, x2, x3
    // 0x817ddc: StoreField: r1->field_b = r4
    //     0x817ddc: stur            x4, [x1, #0xb]
    // 0x817de0: LeaveFrame
    //     0x817de0: mov             SP, fp
    //     0x817de4: ldp             fp, lr, [SP], #0x10
    // 0x817de8: ret
    //     0x817de8: ret             
    // 0x817dec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x817dec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x817df0: b               #0x817d68
    // 0x817df4: r9 = _length
    //     0x817df4: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a20] Field <InputStream._length@54080104>: late (offset: 0x24)
    //     0x817df8: ldr             x9, [x9, #0xa20]
    // 0x817dfc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x817dfc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ subset(/* No info */) {
    // ** addr: 0x817e0c, size: 0x108
    // 0x817e0c: EnterFrame
    //     0x817e0c: stp             fp, lr, [SP, #-0x10]!
    //     0x817e10: mov             fp, SP
    // 0x817e14: AllocStack(0x28)
    //     0x817e14: sub             SP, SP, #0x28
    // 0x817e18: CheckStackOverflow
    //     0x817e18: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x817e1c: cmp             SP, x16
    //     0x817e20: b.ls            #0x817f00
    // 0x817e24: ldr             x0, [fp, #0x20]
    // 0x817e28: LoadField: r1 = r0->field_13
    //     0x817e28: ldur            x1, [x0, #0x13]
    // 0x817e2c: ldr             x2, [fp, #0x18]
    // 0x817e30: r3 = LoadInt32Instr(r2)
    //     0x817e30: sbfx            x3, x2, #1, #0x1f
    //     0x817e34: tbz             w2, #0, #0x817e3c
    //     0x817e38: ldur            x3, [x2, #7]
    // 0x817e3c: add             x2, x3, x1
    // 0x817e40: ldr             x3, [fp, #0x10]
    // 0x817e44: tbz             x3, #0x3f, #0x817e70
    // 0x817e48: LoadField: r3 = r0->field_23
    //     0x817e48: ldur            w3, [x0, #0x23]
    // 0x817e4c: DecompressPointer r3
    //     0x817e4c: add             x3, x3, HEAP, lsl #32
    // 0x817e50: r16 = Sentinel
    //     0x817e50: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x817e54: cmp             w3, w16
    // 0x817e58: b.eq            #0x817f08
    // 0x817e5c: sub             x4, x2, x1
    // 0x817e60: r1 = LoadInt32Instr(r3)
    //     0x817e60: sbfx            x1, x3, #1, #0x1f
    //     0x817e64: tbz             w3, #0, #0x817e6c
    //     0x817e68: ldur            x1, [x3, #7]
    // 0x817e6c: sub             x3, x1, x4
    // 0x817e70: LoadField: r4 = r0->field_7
    //     0x817e70: ldur            w4, [x0, #7]
    // 0x817e74: DecompressPointer r4
    //     0x817e74: add             x4, x4, HEAP, lsl #32
    // 0x817e78: stur            x4, [fp, #-0x20]
    // 0x817e7c: LoadField: r5 = r0->field_1b
    //     0x817e7c: ldur            x5, [x0, #0x1b]
    // 0x817e80: r0 = BoxInt64Instr(r2)
    //     0x817e80: sbfiz           x0, x2, #1, #0x1f
    //     0x817e84: cmp             x2, x0, asr #1
    //     0x817e88: b.eq            #0x817e94
    //     0x817e8c: bl              #0xd69bb8
    //     0x817e90: stur            x2, [x0, #7]
    // 0x817e94: mov             x2, x0
    // 0x817e98: stur            x2, [fp, #-0x18]
    // 0x817e9c: r0 = BoxInt64Instr(r3)
    //     0x817e9c: sbfiz           x0, x3, #1, #0x1f
    //     0x817ea0: cmp             x3, x0, asr #1
    //     0x817ea4: b.eq            #0x817eb0
    //     0x817ea8: bl              #0xd69bb8
    //     0x817eac: stur            x3, [x0, #7]
    // 0x817eb0: stur            x0, [fp, #-0x10]
    // 0x817eb4: lsl             x1, x5, #1
    // 0x817eb8: stur            x1, [fp, #-8]
    // 0x817ebc: r0 = InputStream()
    //     0x817ebc: bl              #0x818b18  ; AllocateInputStreamStub -> InputStream (size=0x28)
    // 0x817ec0: stur            x0, [fp, #-0x28]
    // 0x817ec4: ldur            x16, [fp, #-0x20]
    // 0x817ec8: stp             x16, x0, [SP, #-0x10]!
    // 0x817ecc: ldur            x16, [fp, #-8]
    // 0x817ed0: ldur            lr, [fp, #-0x18]
    // 0x817ed4: stp             lr, x16, [SP, #-0x10]!
    // 0x817ed8: ldur            x16, [fp, #-0x10]
    // 0x817edc: SaveReg r16
    //     0x817edc: str             x16, [SP, #-8]!
    // 0x817ee0: r4 = const [0, 0x5, 0x5, 0x2, byteOrder, 0x2, length, 0x4, start, 0x3, null]
    //     0x817ee0: add             x4, PP, #0x34, lsl #12  ; [pp+0x34ba0] List(11) [0, 0x5, 0x5, 0x2, "byteOrder", 0x2, "length", 0x4, "start", 0x3, Null]
    //     0x817ee4: ldr             x4, [x4, #0xba0]
    // 0x817ee8: r0 = InputStream()
    //     0x817ee8: bl              #0x818754  ; [package:archive/src/util/input_stream.dart] InputStream::InputStream
    // 0x817eec: add             SP, SP, #0x28
    // 0x817ef0: ldur            x0, [fp, #-0x28]
    // 0x817ef4: LeaveFrame
    //     0x817ef4: mov             SP, fp
    //     0x817ef8: ldp             fp, lr, [SP], #0x10
    // 0x817efc: ret
    //     0x817efc: ret             
    // 0x817f00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x817f00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x817f04: b               #0x817e24
    // 0x817f08: r9 = _length
    //     0x817f08: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a20] Field <InputStream._length@54080104>: late (offset: 0x24)
    //     0x817f0c: ldr             x9, [x9, #0xa20]
    // 0x817f10: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x817f10: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ readString(/* No info */) {
    // ** addr: 0x818198, size: 0x110
    // 0x818198: EnterFrame
    //     0x818198: stp             fp, lr, [SP, #-0x10]!
    //     0x81819c: mov             fp, SP
    // 0x8181a0: AllocStack(0x78)
    //     0x8181a0: sub             SP, SP, #0x78
    // 0x8181a4: SetupParameters(InputStream this /* r3 */, dynamic _ /* r4 */, {dynamic utf8 = true /* r0, fp-0x70 */})
    //     0x8181a4: mov             x0, x4
    //     0x8181a8: ldur            w1, [x0, #0x13]
    //     0x8181ac: add             x1, x1, HEAP, lsl #32
    //     0x8181b0: sub             x2, x1, #4
    //     0x8181b4: add             x3, fp, w2, sxtw #2
    //     0x8181b8: ldr             x3, [x3, #0x18]
    //     0x8181bc: add             x4, fp, w2, sxtw #2
    //     0x8181c0: ldr             x4, [x4, #0x10]
    //     0x8181c4: ldur            w2, [x0, #0x1f]
    //     0x8181c8: add             x2, x2, HEAP, lsl #32
    //     0x8181cc: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a9b8] "utf8"
    //     0x8181d0: ldr             x16, [x16, #0x9b8]
    //     0x8181d4: cmp             w2, w16
    //     0x8181d8: b.ne            #0x8181f8
    //     0x8181dc: ldur            w2, [x0, #0x23]
    //     0x8181e0: add             x2, x2, HEAP, lsl #32
    //     0x8181e4: sub             w0, w1, w2
    //     0x8181e8: add             x1, fp, w0, sxtw #2
    //     0x8181ec: ldr             x1, [x1, #8]
    //     0x8181f0: mov             x0, x1
    //     0x8181f4: b               #0x8181fc
    //     0x8181f8: add             x0, NULL, #0x20  ; true
    //     0x8181fc: stur            x0, [fp, #-0x70]
    // 0x818200: CheckStackOverflow
    //     0x818200: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x818204: cmp             SP, x16
    //     0x818208: b.ls            #0x8182a0
    // 0x81820c: stp             x4, x3, [SP, #-0x10]!
    // 0x818210: r0 = readBytes()
    //     0x818210: bl              #0x817d54  ; [package:archive/src/util/input_stream.dart] InputStream::readBytes
    // 0x818214: add             SP, SP, #0x10
    // 0x818218: SaveReg r0
    //     0x818218: str             x0, [SP, #-8]!
    // 0x81821c: r0 = toUint8List()
    //     0x81821c: bl              #0x7f57d4  ; [package:archive/src/util/input_stream.dart] InputStream::toUint8List
    // 0x818220: add             SP, SP, #8
    // 0x818224: stur            x0, [fp, #-0x78]
    // 0x818228: ldur            x1, [fp, #-0x70]
    // 0x81822c: tbnz            w1, #4, #0x81825c
    // 0x818230: r1 = <List<int>, String>
    //     0x818230: ldr             x1, [PP, #0x5080]  ; [pp+0x5080] TypeArguments: <List<int>, String>
    // 0x818234: r0 = Utf8Decoder()
    //     0x818234: bl              #0x8182a8  ; AllocateUtf8DecoderStub -> Utf8Decoder (size=0x10)
    // 0x818238: mov             x1, x0
    // 0x81823c: r0 = false
    //     0x81823c: add             x0, NULL, #0x30  ; false
    // 0x818240: StoreField: r1->field_b = r0
    //     0x818240: stur            w0, [x1, #0xb]
    // 0x818244: ldur            x16, [fp, #-0x78]
    // 0x818248: stp             x16, x1, [SP, #-0x10]!
    // 0x81824c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x81824c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x818250: r0 = convert()
    //     0x818250: bl              #0xc1ed20  ; [dart:convert] Utf8Decoder::convert
    // 0x818254: add             SP, SP, #0x10
    // 0x818258: b               #0x818270
    // 0x81825c: ldur            x16, [fp, #-0x78]
    // 0x818260: stp             xzr, x16, [SP, #-0x10]!
    // 0x818264: stp             NULL, NULL, [SP, #-0x10]!
    // 0x818268: r0 = createFromCharCodes()
    //     0x818268: bl              #0x4d2124  ; [dart:core] _StringBase::createFromCharCodes
    // 0x81826c: add             SP, SP, #0x20
    // 0x818270: LeaveFrame
    //     0x818270: mov             SP, fp
    //     0x818274: ldp             fp, lr, [SP], #0x10
    // 0x818278: ret
    //     0x818278: ret             
    // 0x81827c: sub             SP, fp, #0x78
    // 0x818280: ldur            x16, [fp, #-0x60]
    // 0x818284: stp             xzr, x16, [SP, #-0x10]!
    // 0x818288: stp             NULL, NULL, [SP, #-0x10]!
    // 0x81828c: r0 = createFromCharCodes()
    //     0x81828c: bl              #0x4d2124  ; [dart:core] _StringBase::createFromCharCodes
    // 0x818290: add             SP, SP, #0x20
    // 0x818294: LeaveFrame
    //     0x818294: mov             SP, fp
    //     0x818298: ldp             fp, lr, [SP], #0x10
    // 0x81829c: ret
    //     0x81829c: ret             
    // 0x8182a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8182a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8182a4: b               #0x81820c
  }
  int readUint16(InputStream) {
    // ** addr: 0x8182b4, size: 0x13c
    // 0x8182b4: EnterFrame
    //     0x8182b4: stp             fp, lr, [SP, #-0x10]!
    //     0x8182b8: mov             fp, SP
    // 0x8182bc: AllocStack(0x8)
    //     0x8182bc: sub             SP, SP, #8
    // 0x8182c0: CheckStackOverflow
    //     0x8182c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8182c4: cmp             SP, x16
    //     0x8182c8: b.ls            #0x8183e8
    // 0x8182cc: ldr             x2, [fp, #0x10]
    // 0x8182d0: LoadField: r3 = r2->field_7
    //     0x8182d0: ldur            w3, [x2, #7]
    // 0x8182d4: DecompressPointer r3
    //     0x8182d4: add             x3, x3, HEAP, lsl #32
    // 0x8182d8: LoadField: r4 = r2->field_b
    //     0x8182d8: ldur            x4, [x2, #0xb]
    // 0x8182dc: add             x0, x4, #1
    // 0x8182e0: StoreField: r2->field_b = r0
    //     0x8182e0: stur            x0, [x2, #0xb]
    // 0x8182e4: r0 = BoxInt64Instr(r4)
    //     0x8182e4: sbfiz           x0, x4, #1, #0x1f
    //     0x8182e8: cmp             x4, x0, asr #1
    //     0x8182ec: b.eq            #0x8182f8
    //     0x8182f0: bl              #0xd69bb8
    //     0x8182f4: stur            x4, [x0, #7]
    // 0x8182f8: r1 = LoadClassIdInstr(r3)
    //     0x8182f8: ldur            x1, [x3, #-1]
    //     0x8182fc: ubfx            x1, x1, #0xc, #0x14
    // 0x818300: stp             x0, x3, [SP, #-0x10]!
    // 0x818304: mov             x0, x1
    // 0x818308: r0 = GDT[cid_x0 + -0xd83]()
    //     0x818308: sub             lr, x0, #0xd83
    //     0x81830c: ldr             lr, [x21, lr, lsl #3]
    //     0x818310: blr             lr
    // 0x818314: add             SP, SP, #0x10
    // 0x818318: r1 = LoadInt32Instr(r0)
    //     0x818318: sbfx            x1, x0, #1, #0x1f
    //     0x81831c: tbz             w0, #0, #0x818324
    //     0x818320: ldur            x1, [x0, #7]
    // 0x818324: r2 = 255
    //     0x818324: mov             x2, #0xff
    // 0x818328: and             x3, x1, x2
    // 0x81832c: ldr             x4, [fp, #0x10]
    // 0x818330: stur            x3, [fp, #-8]
    // 0x818334: LoadField: r5 = r4->field_7
    //     0x818334: ldur            w5, [x4, #7]
    // 0x818338: DecompressPointer r5
    //     0x818338: add             x5, x5, HEAP, lsl #32
    // 0x81833c: LoadField: r6 = r4->field_b
    //     0x81833c: ldur            x6, [x4, #0xb]
    // 0x818340: add             x0, x6, #1
    // 0x818344: StoreField: r4->field_b = r0
    //     0x818344: stur            x0, [x4, #0xb]
    // 0x818348: r0 = BoxInt64Instr(r6)
    //     0x818348: sbfiz           x0, x6, #1, #0x1f
    //     0x81834c: cmp             x6, x0, asr #1
    //     0x818350: b.eq            #0x81835c
    //     0x818354: bl              #0xd69bb8
    //     0x818358: stur            x6, [x0, #7]
    // 0x81835c: r1 = LoadClassIdInstr(r5)
    //     0x81835c: ldur            x1, [x5, #-1]
    //     0x818360: ubfx            x1, x1, #0xc, #0x14
    // 0x818364: stp             x0, x5, [SP, #-0x10]!
    // 0x818368: mov             x0, x1
    // 0x81836c: r0 = GDT[cid_x0 + -0xd83]()
    //     0x81836c: sub             lr, x0, #0xd83
    //     0x818370: ldr             lr, [x21, lr, lsl #3]
    //     0x818374: blr             lr
    // 0x818378: add             SP, SP, #0x10
    // 0x81837c: r1 = LoadInt32Instr(r0)
    //     0x81837c: sbfx            x1, x0, #1, #0x1f
    //     0x818380: tbz             w0, #0, #0x818388
    //     0x818384: ldur            x1, [x0, #7]
    // 0x818388: r2 = 255
    //     0x818388: mov             x2, #0xff
    // 0x81838c: and             x3, x1, x2
    // 0x818390: ldr             x1, [fp, #0x10]
    // 0x818394: LoadField: r2 = r1->field_1b
    //     0x818394: ldur            x2, [x1, #0x1b]
    // 0x818398: lsl             x1, x2, #1
    // 0x81839c: cmp             w1, #2
    // 0x8183a0: b.ne            #0x8183c8
    // 0x8183a4: ldur            x1, [fp, #-8]
    // 0x8183a8: ubfx            x1, x1, #0, #0x20
    // 0x8183ac: lsl             x2, x1, #8
    // 0x8183b0: mov             x1, x3
    // 0x8183b4: ubfx            x1, x1, #0, #0x20
    // 0x8183b8: orr             x0, x2, x1
    // 0x8183bc: LeaveFrame
    //     0x8183bc: mov             SP, fp
    //     0x8183c0: ldp             fp, lr, [SP], #0x10
    // 0x8183c4: ret
    //     0x8183c4: ret             
    // 0x8183c8: ubfx            x3, x3, #0, #0x20
    // 0x8183cc: lsl             x1, x3, #8
    // 0x8183d0: ldur            x2, [fp, #-8]
    // 0x8183d4: ubfx            x2, x2, #0, #0x20
    // 0x8183d8: orr             x0, x1, x2
    // 0x8183dc: LeaveFrame
    //     0x8183dc: mov             SP, fp
    //     0x8183e0: ldp             fp, lr, [SP], #0x10
    // 0x8183e4: ret
    //     0x8183e4: ret             
    // 0x8183e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8183e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8183ec: b               #0x8182cc
  }
  int readUint32(InputStream) {
    // ** addr: 0x8183f0, size: 0x244
    // 0x8183f0: EnterFrame
    //     0x8183f0: stp             fp, lr, [SP, #-0x10]!
    //     0x8183f4: mov             fp, SP
    // 0x8183f8: AllocStack(0x18)
    //     0x8183f8: sub             SP, SP, #0x18
    // 0x8183fc: CheckStackOverflow
    //     0x8183fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x818400: cmp             SP, x16
    //     0x818404: b.ls            #0x81862c
    // 0x818408: ldr             x2, [fp, #0x10]
    // 0x81840c: LoadField: r3 = r2->field_7
    //     0x81840c: ldur            w3, [x2, #7]
    // 0x818410: DecompressPointer r3
    //     0x818410: add             x3, x3, HEAP, lsl #32
    // 0x818414: LoadField: r4 = r2->field_b
    //     0x818414: ldur            x4, [x2, #0xb]
    // 0x818418: add             x0, x4, #1
    // 0x81841c: StoreField: r2->field_b = r0
    //     0x81841c: stur            x0, [x2, #0xb]
    // 0x818420: r0 = BoxInt64Instr(r4)
    //     0x818420: sbfiz           x0, x4, #1, #0x1f
    //     0x818424: cmp             x4, x0, asr #1
    //     0x818428: b.eq            #0x818434
    //     0x81842c: bl              #0xd69bb8
    //     0x818430: stur            x4, [x0, #7]
    // 0x818434: r1 = LoadClassIdInstr(r3)
    //     0x818434: ldur            x1, [x3, #-1]
    //     0x818438: ubfx            x1, x1, #0xc, #0x14
    // 0x81843c: stp             x0, x3, [SP, #-0x10]!
    // 0x818440: mov             x0, x1
    // 0x818444: r0 = GDT[cid_x0 + -0xd83]()
    //     0x818444: sub             lr, x0, #0xd83
    //     0x818448: ldr             lr, [x21, lr, lsl #3]
    //     0x81844c: blr             lr
    // 0x818450: add             SP, SP, #0x10
    // 0x818454: r1 = LoadInt32Instr(r0)
    //     0x818454: sbfx            x1, x0, #1, #0x1f
    //     0x818458: tbz             w0, #0, #0x818460
    //     0x81845c: ldur            x1, [x0, #7]
    // 0x818460: r2 = 255
    //     0x818460: mov             x2, #0xff
    // 0x818464: and             x3, x1, x2
    // 0x818468: ldr             x4, [fp, #0x10]
    // 0x81846c: stur            x3, [fp, #-8]
    // 0x818470: LoadField: r5 = r4->field_7
    //     0x818470: ldur            w5, [x4, #7]
    // 0x818474: DecompressPointer r5
    //     0x818474: add             x5, x5, HEAP, lsl #32
    // 0x818478: LoadField: r6 = r4->field_b
    //     0x818478: ldur            x6, [x4, #0xb]
    // 0x81847c: add             x0, x6, #1
    // 0x818480: StoreField: r4->field_b = r0
    //     0x818480: stur            x0, [x4, #0xb]
    // 0x818484: r0 = BoxInt64Instr(r6)
    //     0x818484: sbfiz           x0, x6, #1, #0x1f
    //     0x818488: cmp             x6, x0, asr #1
    //     0x81848c: b.eq            #0x818498
    //     0x818490: bl              #0xd69bb8
    //     0x818494: stur            x6, [x0, #7]
    // 0x818498: r1 = LoadClassIdInstr(r5)
    //     0x818498: ldur            x1, [x5, #-1]
    //     0x81849c: ubfx            x1, x1, #0xc, #0x14
    // 0x8184a0: stp             x0, x5, [SP, #-0x10]!
    // 0x8184a4: mov             x0, x1
    // 0x8184a8: r0 = GDT[cid_x0 + -0xd83]()
    //     0x8184a8: sub             lr, x0, #0xd83
    //     0x8184ac: ldr             lr, [x21, lr, lsl #3]
    //     0x8184b0: blr             lr
    // 0x8184b4: add             SP, SP, #0x10
    // 0x8184b8: r1 = LoadInt32Instr(r0)
    //     0x8184b8: sbfx            x1, x0, #1, #0x1f
    //     0x8184bc: tbz             w0, #0, #0x8184c4
    //     0x8184c0: ldur            x1, [x0, #7]
    // 0x8184c4: r2 = 255
    //     0x8184c4: mov             x2, #0xff
    // 0x8184c8: and             x3, x1, x2
    // 0x8184cc: ldr             x4, [fp, #0x10]
    // 0x8184d0: stur            x3, [fp, #-0x10]
    // 0x8184d4: LoadField: r5 = r4->field_7
    //     0x8184d4: ldur            w5, [x4, #7]
    // 0x8184d8: DecompressPointer r5
    //     0x8184d8: add             x5, x5, HEAP, lsl #32
    // 0x8184dc: LoadField: r6 = r4->field_b
    //     0x8184dc: ldur            x6, [x4, #0xb]
    // 0x8184e0: add             x0, x6, #1
    // 0x8184e4: StoreField: r4->field_b = r0
    //     0x8184e4: stur            x0, [x4, #0xb]
    // 0x8184e8: r0 = BoxInt64Instr(r6)
    //     0x8184e8: sbfiz           x0, x6, #1, #0x1f
    //     0x8184ec: cmp             x6, x0, asr #1
    //     0x8184f0: b.eq            #0x8184fc
    //     0x8184f4: bl              #0xd69bb8
    //     0x8184f8: stur            x6, [x0, #7]
    // 0x8184fc: r1 = LoadClassIdInstr(r5)
    //     0x8184fc: ldur            x1, [x5, #-1]
    //     0x818500: ubfx            x1, x1, #0xc, #0x14
    // 0x818504: stp             x0, x5, [SP, #-0x10]!
    // 0x818508: mov             x0, x1
    // 0x81850c: r0 = GDT[cid_x0 + -0xd83]()
    //     0x81850c: sub             lr, x0, #0xd83
    //     0x818510: ldr             lr, [x21, lr, lsl #3]
    //     0x818514: blr             lr
    // 0x818518: add             SP, SP, #0x10
    // 0x81851c: r1 = LoadInt32Instr(r0)
    //     0x81851c: sbfx            x1, x0, #1, #0x1f
    //     0x818520: tbz             w0, #0, #0x818528
    //     0x818524: ldur            x1, [x0, #7]
    // 0x818528: r2 = 255
    //     0x818528: mov             x2, #0xff
    // 0x81852c: and             x3, x1, x2
    // 0x818530: ldr             x4, [fp, #0x10]
    // 0x818534: stur            x3, [fp, #-0x18]
    // 0x818538: LoadField: r5 = r4->field_7
    //     0x818538: ldur            w5, [x4, #7]
    // 0x81853c: DecompressPointer r5
    //     0x81853c: add             x5, x5, HEAP, lsl #32
    // 0x818540: LoadField: r6 = r4->field_b
    //     0x818540: ldur            x6, [x4, #0xb]
    // 0x818544: add             x0, x6, #1
    // 0x818548: StoreField: r4->field_b = r0
    //     0x818548: stur            x0, [x4, #0xb]
    // 0x81854c: r0 = BoxInt64Instr(r6)
    //     0x81854c: sbfiz           x0, x6, #1, #0x1f
    //     0x818550: cmp             x6, x0, asr #1
    //     0x818554: b.eq            #0x818560
    //     0x818558: bl              #0xd69bb8
    //     0x81855c: stur            x6, [x0, #7]
    // 0x818560: r1 = LoadClassIdInstr(r5)
    //     0x818560: ldur            x1, [x5, #-1]
    //     0x818564: ubfx            x1, x1, #0xc, #0x14
    // 0x818568: stp             x0, x5, [SP, #-0x10]!
    // 0x81856c: mov             x0, x1
    // 0x818570: r0 = GDT[cid_x0 + -0xd83]()
    //     0x818570: sub             lr, x0, #0xd83
    //     0x818574: ldr             lr, [x21, lr, lsl #3]
    //     0x818578: blr             lr
    // 0x81857c: add             SP, SP, #0x10
    // 0x818580: r1 = LoadInt32Instr(r0)
    //     0x818580: sbfx            x1, x0, #1, #0x1f
    //     0x818584: tbz             w0, #0, #0x81858c
    //     0x818588: ldur            x1, [x0, #7]
    // 0x81858c: r2 = 255
    //     0x81858c: mov             x2, #0xff
    // 0x818590: and             x3, x1, x2
    // 0x818594: ldr             x1, [fp, #0x10]
    // 0x818598: LoadField: r2 = r1->field_1b
    //     0x818598: ldur            x2, [x1, #0x1b]
    // 0x81859c: lsl             x1, x2, #1
    // 0x8185a0: cmp             w1, #2
    // 0x8185a4: b.ne            #0x8185ec
    // 0x8185a8: ldur            x1, [fp, #-8]
    // 0x8185ac: ubfx            x1, x1, #0, #0x20
    // 0x8185b0: lsl             x2, x1, #0x18
    // 0x8185b4: ldur            x1, [fp, #-0x10]
    // 0x8185b8: ubfx            x1, x1, #0, #0x20
    // 0x8185bc: lsl             x4, x1, #0x10
    // 0x8185c0: orr             x1, x2, x4
    // 0x8185c4: ldur            x2, [fp, #-0x18]
    // 0x8185c8: ubfx            x2, x2, #0, #0x20
    // 0x8185cc: lsl             x4, x2, #8
    // 0x8185d0: orr             x2, x1, x4
    // 0x8185d4: mov             x1, x3
    // 0x8185d8: ubfx            x1, x1, #0, #0x20
    // 0x8185dc: orr             x0, x2, x1
    // 0x8185e0: LeaveFrame
    //     0x8185e0: mov             SP, fp
    //     0x8185e4: ldp             fp, lr, [SP], #0x10
    // 0x8185e8: ret
    //     0x8185e8: ret             
    // 0x8185ec: ubfx            x3, x3, #0, #0x20
    // 0x8185f0: lsl             x1, x3, #0x18
    // 0x8185f4: ldur            x2, [fp, #-0x18]
    // 0x8185f8: ubfx            x2, x2, #0, #0x20
    // 0x8185fc: lsl             x3, x2, #0x10
    // 0x818600: orr             x2, x1, x3
    // 0x818604: ldur            x1, [fp, #-0x10]
    // 0x818608: ubfx            x1, x1, #0, #0x20
    // 0x81860c: lsl             x3, x1, #8
    // 0x818610: orr             x1, x2, x3
    // 0x818614: ldur            x2, [fp, #-8]
    // 0x818618: ubfx            x2, x2, #0, #0x20
    // 0x81861c: orr             x0, x1, x2
    // 0x818620: LeaveFrame
    //     0x818620: mov             SP, fp
    //     0x818624: ldp             fp, lr, [SP], #0x10
    // 0x818628: ret
    //     0x818628: ret             
    // 0x81862c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81862c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x818630: b               #0x818408
  }
  _ InputStream(/* No info */) {
    // ** addr: 0x818754, size: 0x3c4
    // 0x818754: EnterFrame
    //     0x818754: stp             fp, lr, [SP, #-0x10]!
    //     0x818758: mov             fp, SP
    // 0x81875c: AllocStack(0x30)
    //     0x81875c: sub             SP, SP, #0x30
    // 0x818760: SetupParameters(InputStream this /* r3, fp-0x20 */, dynamic _ /* r4, fp-0x18 */, {int byteOrder = 0 /* r5 */, dynamic length = Null /* r6, fp-0x10 */, int start = 0 /* r1, fp-0x8 */})
    //     0x818760: mov             x0, x4
    //     0x818764: ldur            w1, [x0, #0x13]
    //     0x818768: add             x1, x1, HEAP, lsl #32
    //     0x81876c: sub             x2, x1, #4
    //     0x818770: add             x3, fp, w2, sxtw #2
    //     0x818774: ldr             x3, [x3, #0x18]
    //     0x818778: stur            x3, [fp, #-0x20]
    //     0x81877c: add             x4, fp, w2, sxtw #2
    //     0x818780: ldr             x4, [x4, #0x10]
    //     0x818784: stur            x4, [fp, #-0x18]
    //     0x818788: ldur            w2, [x0, #0x1f]
    //     0x81878c: add             x2, x2, HEAP, lsl #32
    //     0x818790: add             x16, PP, #0x34, lsl #12  ; [pp+0x34bd8] "byteOrder"
    //     0x818794: ldr             x16, [x16, #0xbd8]
    //     0x818798: cmp             w2, w16
    //     0x81879c: b.ne            #0x8187c8
    //     0x8187a0: ldur            w2, [x0, #0x23]
    //     0x8187a4: add             x2, x2, HEAP, lsl #32
    //     0x8187a8: sub             w5, w1, w2
    //     0x8187ac: add             x2, fp, w5, sxtw #2
    //     0x8187b0: ldr             x2, [x2, #8]
    //     0x8187b4: sbfx            x5, x2, #1, #0x1f
    //     0x8187b8: tbz             w2, #0, #0x8187c0
    //     0x8187bc: ldur            x5, [x2, #7]
    //     0x8187c0: mov             x2, #1
    //     0x8187c4: b               #0x8187d0
    //     0x8187c8: mov             x5, #0
    //     0x8187cc: mov             x2, #0
    //     0x8187d0: lsl             x6, x2, #1
    //     0x8187d4: lsl             w7, w6, #1
    //     0x8187d8: add             w8, w7, #8
    //     0x8187dc: add             x16, x0, w8, sxtw #1
    //     0x8187e0: ldur            w9, [x16, #0xf]
    //     0x8187e4: add             x9, x9, HEAP, lsl #32
    //     0x8187e8: add             x16, PP, #0x31, lsl #12  ; [pp+0x31770] "length"
    //     0x8187ec: ldr             x16, [x16, #0x770]
    //     0x8187f0: cmp             w9, w16
    //     0x8187f4: b.ne            #0x818828
    //     0x8187f8: add             w2, w7, #0xa
    //     0x8187fc: add             x16, x0, w2, sxtw #1
    //     0x818800: ldur            w7, [x16, #0xf]
    //     0x818804: add             x7, x7, HEAP, lsl #32
    //     0x818808: sub             w2, w1, w7
    //     0x81880c: add             x7, fp, w2, sxtw #2
    //     0x818810: ldr             x7, [x7, #8]
    //     0x818814: add             w2, w6, #2
    //     0x818818: sbfx            x6, x2, #1, #0x1f
    //     0x81881c: mov             x2, x6
    //     0x818820: mov             x6, x7
    //     0x818824: b               #0x81882c
    //     0x818828: mov             x6, NULL
    //     0x81882c: stur            x6, [fp, #-0x10]
    //     0x818830: lsl             x7, x2, #1
    //     0x818834: lsl             w2, w7, #1
    //     0x818838: add             w7, w2, #8
    //     0x81883c: add             x16, x0, w7, sxtw #1
    //     0x818840: ldur            w8, [x16, #0xf]
    //     0x818844: add             x8, x8, HEAP, lsl #32
    //     0x818848: ldr             x16, [PP, #0x308]  ; [pp+0x308] "start"
    //     0x81884c: cmp             w8, w16
    //     0x818850: b.ne            #0x818884
    //     0x818854: add             w7, w2, #0xa
    //     0x818858: add             x16, x0, w7, sxtw #1
    //     0x81885c: ldur            w2, [x16, #0xf]
    //     0x818860: add             x2, x2, HEAP, lsl #32
    //     0x818864: sub             w0, w1, w2
    //     0x818868: add             x1, fp, w0, sxtw #2
    //     0x81886c: ldr             x1, [x1, #8]
    //     0x818870: sbfx            x0, x1, #1, #0x1f
    //     0x818874: tbz             w1, #0, #0x81887c
    //     0x818878: ldur            x0, [x1, #7]
    //     0x81887c: mov             x1, x0
    //     0x818880: b               #0x818888
    //     0x818884: mov             x1, #0
    //     0x818888: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x81888c: stur            x1, [fp, #-8]
    // 0x818888: r0 = Sentinel
    // 0x818890: CheckStackOverflow
    //     0x818890: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x818894: cmp             SP, x16
    //     0x818898: b.ls            #0x818b10
    // 0x81889c: StoreField: r3->field_23 = r0
    //     0x81889c: stur            w0, [x3, #0x23]
    // 0x8188a0: StoreField: r3->field_1b = r5
    //     0x8188a0: stur            x5, [x3, #0x1b]
    // 0x8188a4: StoreField: r3->field_13 = r1
    //     0x8188a4: stur            x1, [x3, #0x13]
    // 0x8188a8: r0 = LoadTaggedClassIdMayBeSmiInstr(r4)
    //     0x8188a8: mov             x0, #0x76
    //     0x8188ac: tbz             w4, #0, #0x8188bc
    //     0x8188b0: ldur            x0, [x4, #-1]
    //     0x8188b4: ubfx            x0, x0, #0xc, #0x14
    //     0x8188b8: lsl             x0, x0, #1
    // 0x8188bc: r2 = LoadInt32Instr(r0)
    //     0x8188bc: sbfx            x2, x0, #1, #0x1f
    // 0x8188c0: cmp             x2, #0x71
    // 0x8188c4: b.lt            #0x81899c
    // 0x8188c8: cmp             x2, #0xaa
    // 0x8188cc: b.gt            #0x818994
    // 0x8188d0: r0 = LoadClassIdInstr(r4)
    //     0x8188d0: ldur            x0, [x4, #-1]
    //     0x8188d4: ubfx            x0, x0, #0xc, #0x14
    // 0x8188d8: SaveReg r4
    //     0x8188d8: str             x4, [SP, #-8]!
    // 0x8188dc: r0 = GDT[cid_x0 + -0xf7e]()
    //     0x8188dc: sub             lr, x0, #0xf7e
    //     0x8188e0: ldr             lr, [x21, lr, lsl #3]
    //     0x8188e4: blr             lr
    // 0x8188e8: add             SP, SP, #8
    // 0x8188ec: mov             x2, x0
    // 0x8188f0: ldur            x1, [fp, #-0x18]
    // 0x8188f4: stur            x2, [fp, #-0x28]
    // 0x8188f8: r0 = LoadClassIdInstr(r1)
    //     0x8188f8: ldur            x0, [x1, #-1]
    //     0x8188fc: ubfx            x0, x0, #0xc, #0x14
    // 0x818900: SaveReg r1
    //     0x818900: str             x1, [SP, #-8]!
    // 0x818904: r0 = GDT[cid_x0 + -0xef6]()
    //     0x818904: sub             lr, x0, #0xef6
    //     0x818908: ldr             lr, [x21, lr, lsl #3]
    //     0x81890c: blr             lr
    // 0x818910: add             SP, SP, #8
    // 0x818914: mov             x1, x0
    // 0x818918: ldur            x3, [fp, #-0x18]
    // 0x81891c: stur            x1, [fp, #-0x30]
    // 0x818920: r0 = LoadClassIdInstr(r3)
    //     0x818920: ldur            x0, [x3, #-1]
    //     0x818924: ubfx            x0, x0, #0xc, #0x14
    // 0x818928: SaveReg r3
    //     0x818928: str             x3, [SP, #-8]!
    // 0x81892c: r0 = GDT[cid_x0 + 0x3b2f]()
    //     0x81892c: mov             x17, #0x3b2f
    //     0x818930: add             lr, x0, x17
    //     0x818934: ldr             lr, [x21, lr, lsl #3]
    //     0x818938: blr             lr
    // 0x81893c: add             SP, SP, #8
    // 0x818940: mov             x2, x0
    // 0x818944: r0 = BoxInt64Instr(r2)
    //     0x818944: sbfiz           x0, x2, #1, #0x1f
    //     0x818948: cmp             x2, x0, asr #1
    //     0x81894c: b.eq            #0x818958
    //     0x818950: bl              #0xd69bb8
    //     0x818954: stur            x2, [x0, #7]
    // 0x818958: mov             x1, x0
    // 0x81895c: ldur            x0, [fp, #-0x28]
    // 0x818960: r2 = LoadClassIdInstr(r0)
    //     0x818960: ldur            x2, [x0, #-1]
    //     0x818964: ubfx            x2, x2, #0xc, #0x14
    // 0x818968: ldur            x16, [fp, #-0x30]
    // 0x81896c: stp             x16, x0, [SP, #-0x10]!
    // 0x818970: SaveReg r1
    //     0x818970: str             x1, [SP, #-8]!
    // 0x818974: mov             x0, x2
    // 0x818978: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x818978: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x81897c: r0 = GDT[cid_x0 + -0xffc]()
    //     0x81897c: sub             lr, x0, #0xffc
    //     0x818980: ldr             lr, [x21, lr, lsl #3]
    //     0x818984: blr             lr
    // 0x818988: add             SP, SP, #0x18
    // 0x81898c: mov             x4, x0
    // 0x818990: b               #0x818a58
    // 0x818994: mov             x3, x4
    // 0x818998: b               #0x8189a0
    // 0x81899c: mov             x3, x4
    // 0x8189a0: mov             x0, x3
    // 0x8189a4: r2 = Null
    //     0x8189a4: mov             x2, NULL
    // 0x8189a8: r1 = Null
    //     0x8189a8: mov             x1, NULL
    // 0x8189ac: cmp             w0, NULL
    // 0x8189b0: b.eq            #0x818a04
    // 0x8189b4: branchIfSmi(r0, 0x818a04)
    //     0x8189b4: tbz             w0, #0, #0x818a04
    // 0x8189b8: r8 = List<int>
    //     0x8189b8: add             x8, PP, #0x34, lsl #12  ; [pp+0x34be0] Type: List<int>
    //     0x8189bc: ldr             x8, [x8, #0xbe0]
    // 0x8189c0: r3 = SubtypeTestCache
    //     0x8189c0: add             x3, PP, #0x34, lsl #12  ; [pp+0x34be8] SubtypeTestCache
    //     0x8189c4: ldr             x3, [x3, #0xbe8]
    // 0x8189c8: r24 = Subtype3TestCacheStub
    //     0x8189c8: ldr             x24, [PP, #0x10]  ; [pp+0x10] Stub: Subtype3TestCache (0x4ae294)
    // 0x8189cc: LoadField: r30 = r24->field_7
    //     0x8189cc: ldur            lr, [x24, #7]
    // 0x8189d0: blr             lr
    // 0x8189d4: cmp             w7, NULL
    // 0x8189d8: b.eq            #0x8189e4
    // 0x8189dc: tbnz            w7, #4, #0x818a04
    // 0x8189e0: b               #0x818a0c
    // 0x8189e4: r8 = List<int>
    //     0x8189e4: add             x8, PP, #0x34, lsl #12  ; [pp+0x34bf0] Type: List<int>
    //     0x8189e8: ldr             x8, [x8, #0xbf0]
    // 0x8189ec: r3 = SubtypeTestCache
    //     0x8189ec: add             x3, PP, #0x34, lsl #12  ; [pp+0x34bf8] SubtypeTestCache
    //     0x8189f0: ldr             x3, [x3, #0xbf8]
    // 0x8189f4: r24 = InstanceOfStub
    //     0x8189f4: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x8189f8: LoadField: r30 = r24->field_7
    //     0x8189f8: ldur            lr, [x24, #7]
    // 0x8189fc: blr             lr
    // 0x818a00: b               #0x818a10
    // 0x818a04: r0 = false
    //     0x818a04: add             x0, NULL, #0x30  ; false
    // 0x818a08: b               #0x818a10
    // 0x818a0c: r0 = true
    //     0x818a0c: add             x0, NULL, #0x20  ; true
    // 0x818a10: tbnz            w0, #4, #0x818a1c
    // 0x818a14: ldur            x0, [fp, #-0x18]
    // 0x818a18: b               #0x818a54
    // 0x818a1c: ldur            x0, [fp, #-0x18]
    // 0x818a20: r2 = Null
    //     0x818a20: mov             x2, NULL
    // 0x818a24: r1 = Null
    //     0x818a24: mov             x1, NULL
    // 0x818a28: r8 = Iterable
    //     0x818a28: add             x8, PP, #0x14, lsl #12  ; [pp+0x14e70] Type: Iterable
    //     0x818a2c: ldr             x8, [x8, #0xe70]
    // 0x818a30: r3 = Null
    //     0x818a30: add             x3, PP, #0x34, lsl #12  ; [pp+0x34c00] Null
    //     0x818a34: ldr             x3, [x3, #0xc00]
    // 0x818a38: r0 = Iterable()
    //     0x818a38: bl              #0x53322c  ; IsType_Iterable_Stub
    // 0x818a3c: r16 = <int>
    //     0x818a3c: ldr             x16, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0x818a40: ldur            lr, [fp, #-0x18]
    // 0x818a44: stp             lr, x16, [SP, #-0x10]!
    // 0x818a48: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x818a48: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x818a4c: r0 = List.from()
    //     0x818a4c: bl              #0x4c85f8  ; [dart:core] List::List.from
    // 0x818a50: add             SP, SP, #0x10
    // 0x818a54: mov             x4, x0
    // 0x818a58: ldur            x1, [fp, #-0x20]
    // 0x818a5c: ldur            x2, [fp, #-0x10]
    // 0x818a60: ldur            x3, [fp, #-8]
    // 0x818a64: mov             x0, x4
    // 0x818a68: StoreField: r1->field_7 = r0
    //     0x818a68: stur            w0, [x1, #7]
    //     0x818a6c: tbz             w0, #0, #0x818a88
    //     0x818a70: ldurb           w16, [x1, #-1]
    //     0x818a74: ldurb           w17, [x0, #-1]
    //     0x818a78: and             x16, x17, x16, lsr #2
    //     0x818a7c: tst             x16, HEAP, lsr #32
    //     0x818a80: b.eq            #0x818a88
    //     0x818a84: bl              #0xd6826c
    // 0x818a88: StoreField: r1->field_b = r3
    //     0x818a88: stur            x3, [x1, #0xb]
    // 0x818a8c: cmp             w2, NULL
    // 0x818a90: b.ne            #0x818abc
    // 0x818a94: r0 = LoadClassIdInstr(r4)
    //     0x818a94: ldur            x0, [x4, #-1]
    //     0x818a98: ubfx            x0, x0, #0xc, #0x14
    // 0x818a9c: SaveReg r4
    //     0x818a9c: str             x4, [SP, #-8]!
    // 0x818aa0: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x818aa0: mov             x17, #0xb8ea
    //     0x818aa4: add             lr, x0, x17
    //     0x818aa8: ldr             lr, [x21, lr, lsl #3]
    //     0x818aac: blr             lr
    // 0x818ab0: add             SP, SP, #8
    // 0x818ab4: r3 = LoadInt32Instr(r0)
    //     0x818ab4: sbfx            x3, x0, #1, #0x1f
    // 0x818ab8: b               #0x818ac8
    // 0x818abc: r3 = LoadInt32Instr(r2)
    //     0x818abc: sbfx            x3, x2, #1, #0x1f
    //     0x818ac0: tbz             w2, #0, #0x818ac8
    //     0x818ac4: ldur            x3, [x2, #7]
    // 0x818ac8: ldur            x2, [fp, #-0x20]
    // 0x818acc: r0 = BoxInt64Instr(r3)
    //     0x818acc: sbfiz           x0, x3, #1, #0x1f
    //     0x818ad0: cmp             x3, x0, asr #1
    //     0x818ad4: b.eq            #0x818ae0
    //     0x818ad8: bl              #0xd69bb8
    //     0x818adc: stur            x3, [x0, #7]
    // 0x818ae0: StoreField: r2->field_23 = r0
    //     0x818ae0: stur            w0, [x2, #0x23]
    //     0x818ae4: tbz             w0, #0, #0x818b00
    //     0x818ae8: ldurb           w16, [x2, #-1]
    //     0x818aec: ldurb           w17, [x0, #-1]
    //     0x818af0: and             x16, x17, x16, lsr #2
    //     0x818af4: tst             x16, HEAP, lsr #32
    //     0x818af8: b.eq            #0x818b00
    //     0x818afc: bl              #0xd6828c
    // 0x818b00: r0 = Null
    //     0x818b00: mov             x0, NULL
    // 0x818b04: LeaveFrame
    //     0x818b04: mov             SP, fp
    //     0x818b08: ldp             fp, lr, [SP], #0x10
    // 0x818b0c: ret
    //     0x818b0c: ret             
    // 0x818b10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x818b10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x818b14: b               #0x81889c
  }
}

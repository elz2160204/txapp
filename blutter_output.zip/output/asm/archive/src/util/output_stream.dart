// lib: , url: package:archive/src/util/output_stream.dart

// class id: 1048619, size: 0x8
class :: {
}

// class id: 5000, size: 0x8, field offset: 0x8
abstract class OutputStreamBase extends Object {
}

// class id: 5001, size: 0x1c, field offset: 0x8
class OutputStream extends OutputStreamBase {

  List<int> getBytes(OutputStream) {
    // ** addr: 0x815168, size: 0x94
    // 0x815168: EnterFrame
    //     0x815168: stp             fp, lr, [SP, #-0x10]!
    //     0x81516c: mov             fp, SP
    // 0x815170: AllocStack(0x8)
    //     0x815170: sub             SP, SP, #8
    // 0x815174: CheckStackOverflow
    //     0x815174: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x815178: cmp             SP, x16
    //     0x81517c: b.ls            #0x8151dc
    // 0x815180: ldr             x0, [fp, #0x10]
    // 0x815184: LoadField: r1 = r0->field_17
    //     0x815184: ldur            w1, [x0, #0x17]
    // 0x815188: DecompressPointer r1
    //     0x815188: add             x1, x1, HEAP, lsl #32
    // 0x81518c: stur            x1, [fp, #-8]
    // 0x815190: r0 = _ByteBuffer()
    //     0x815190: bl              #0x4b2c3c  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0x815194: mov             x2, x0
    // 0x815198: ldur            x0, [fp, #-8]
    // 0x81519c: StoreField: r2->field_7 = r0
    //     0x81519c: stur            w0, [x2, #7]
    // 0x8151a0: ldr             x0, [fp, #0x10]
    // 0x8151a4: LoadField: r3 = r0->field_7
    //     0x8151a4: ldur            x3, [x0, #7]
    // 0x8151a8: r0 = BoxInt64Instr(r3)
    //     0x8151a8: sbfiz           x0, x3, #1, #0x1f
    //     0x8151ac: cmp             x3, x0, asr #1
    //     0x8151b0: b.eq            #0x8151bc
    //     0x8151b4: bl              #0xd69bb8
    //     0x8151b8: stur            x3, [x0, #7]
    // 0x8151bc: stp             xzr, x2, [SP, #-0x10]!
    // 0x8151c0: SaveReg r0
    //     0x8151c0: str             x0, [SP, #-8]!
    // 0x8151c4: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x8151c4: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x8151c8: r0 = asUint8List()
    //     0x8151c8: bl              #0xd64518  ; [dart:typed_data] _ByteBuffer::asUint8List
    // 0x8151cc: add             SP, SP, #0x18
    // 0x8151d0: LeaveFrame
    //     0x8151d0: mov             SP, fp
    //     0x8151d4: ldp             fp, lr, [SP], #0x10
    // 0x8151d8: ret
    //     0x8151d8: ret             
    // 0x8151dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8151dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8151e0: b               #0x815180
  }
  _ writeBytes(/* No info */) {
    // ** addr: 0x815c7c, size: 0x1b0
    // 0x815c7c: EnterFrame
    //     0x815c7c: stp             fp, lr, [SP, #-0x10]!
    //     0x815c80: mov             fp, SP
    // 0x815c84: AllocStack(0x30)
    //     0x815c84: sub             SP, SP, #0x30
    // 0x815c88: SetupParameters(OutputStream this /* r2, fp-0x28 */, dynamic _ /* r3, fp-0x20 */, [dynamic _ = Null /* r0 */])
    //     0x815c88: mov             x0, x4
    //     0x815c8c: ldur            w1, [x0, #0x13]
    //     0x815c90: add             x1, x1, HEAP, lsl #32
    //     0x815c94: sub             x0, x1, #4
    //     0x815c98: add             x2, fp, w0, sxtw #2
    //     0x815c9c: ldr             x2, [x2, #0x18]
    //     0x815ca0: stur            x2, [fp, #-0x28]
    //     0x815ca4: add             x3, fp, w0, sxtw #2
    //     0x815ca8: ldr             x3, [x3, #0x10]
    //     0x815cac: stur            x3, [fp, #-0x20]
    //     0x815cb0: cmp             w0, #2
    //     0x815cb4: b.lt            #0x815cc8
    //     0x815cb8: add             x1, fp, w0, sxtw #2
    //     0x815cbc: ldr             x1, [x1, #8]
    //     0x815cc0: mov             x0, x1
    //     0x815cc4: b               #0x815ccc
    //     0x815cc8: mov             x0, NULL
    // 0x815ccc: CheckStackOverflow
    //     0x815ccc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x815cd0: cmp             SP, x16
    //     0x815cd4: b.ls            #0x815e1c
    // 0x815cd8: cmp             w0, NULL
    // 0x815cdc: b.ne            #0x815cf4
    // 0x815ce0: LoadField: r0 = r3->field_13
    //     0x815ce0: ldur            w0, [x3, #0x13]
    // 0x815ce4: DecompressPointer r0
    //     0x815ce4: add             x0, x0, HEAP, lsl #32
    // 0x815ce8: r1 = LoadInt32Instr(r0)
    //     0x815ce8: sbfx            x1, x0, #1, #0x1f
    // 0x815cec: mov             x5, x1
    // 0x815cf0: b               #0x815d04
    // 0x815cf4: r1 = LoadInt32Instr(r0)
    //     0x815cf4: sbfx            x1, x0, #1, #0x1f
    //     0x815cf8: tbz             w0, #0, #0x815d00
    //     0x815cfc: ldur            x1, [x0, #7]
    // 0x815d00: mov             x5, x1
    // 0x815d04: stur            x5, [fp, #-0x18]
    // 0x815d08: CheckStackOverflow
    //     0x815d08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x815d0c: cmp             SP, x16
    //     0x815d10: b.ls            #0x815e24
    // 0x815d14: LoadField: r4 = r2->field_7
    //     0x815d14: ldur            x4, [x2, #7]
    // 0x815d18: add             x6, x4, x5
    // 0x815d1c: LoadField: r7 = r2->field_17
    //     0x815d1c: ldur            w7, [x2, #0x17]
    // 0x815d20: DecompressPointer r7
    //     0x815d20: add             x7, x7, HEAP, lsl #32
    // 0x815d24: stur            x7, [fp, #-0x10]
    // 0x815d28: LoadField: r0 = r7->field_13
    //     0x815d28: ldur            w0, [x7, #0x13]
    // 0x815d2c: DecompressPointer r0
    //     0x815d2c: add             x0, x0, HEAP, lsl #32
    // 0x815d30: r8 = LoadInt32Instr(r0)
    //     0x815d30: sbfx            x8, x0, #1, #0x1f
    // 0x815d34: stur            x8, [fp, #-8]
    // 0x815d38: cmp             x6, x8
    // 0x815d3c: b.le            #0x815dc4
    // 0x815d40: sub             x0, x6, x8
    // 0x815d44: cmp             x0, #8, lsl #12
    // 0x815d48: b.gt            #0x815d50
    // 0x815d4c: r0 = 32768
    //     0x815d4c: mov             x0, #0x8000
    // 0x815d50: add             x1, x8, x0
    // 0x815d54: lsl             x4, x1, #1
    // 0x815d58: r0 = BoxInt64Instr(r4)
    //     0x815d58: sbfiz           x0, x4, #1, #0x1f
    //     0x815d5c: cmp             x4, x0, asr #1
    //     0x815d60: b.eq            #0x815d6c
    //     0x815d64: bl              #0xd69bb8
    //     0x815d68: stur            x4, [x0, #7]
    // 0x815d6c: mov             x4, x0
    // 0x815d70: r0 = AllocateUint8Array()
    //     0x815d70: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0x815d74: stur            x0, [fp, #-0x30]
    // 0x815d78: stp             xzr, x0, [SP, #-0x10]!
    // 0x815d7c: ldur            x1, [fp, #-8]
    // 0x815d80: ldur            x16, [fp, #-0x10]
    // 0x815d84: stp             x16, x1, [SP, #-0x10]!
    // 0x815d88: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x815d88: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x815d8c: r0 = setRange()
    //     0x815d8c: bl              #0x605c8c  ; [dart:typed_data] __Uint8List&_TypedList&_IntListMixin&_TypedIntListMixin::setRange
    // 0x815d90: add             SP, SP, #0x20
    // 0x815d94: ldur            x0, [fp, #-0x30]
    // 0x815d98: ldur            x2, [fp, #-0x28]
    // 0x815d9c: StoreField: r2->field_17 = r0
    //     0x815d9c: stur            w0, [x2, #0x17]
    //     0x815da0: ldurb           w16, [x2, #-1]
    //     0x815da4: ldurb           w17, [x0, #-1]
    //     0x815da8: and             x16, x17, x16, lsr #2
    //     0x815dac: tst             x16, HEAP, lsr #32
    //     0x815db0: b.eq            #0x815db8
    //     0x815db4: bl              #0xd6828c
    // 0x815db8: ldur            x3, [fp, #-0x20]
    // 0x815dbc: ldur            x5, [fp, #-0x18]
    // 0x815dc0: b               #0x815d08
    // 0x815dc4: mov             x3, x5
    // 0x815dc8: r0 = BoxInt64Instr(r4)
    //     0x815dc8: sbfiz           x0, x4, #1, #0x1f
    //     0x815dcc: cmp             x4, x0, asr #1
    //     0x815dd0: b.eq            #0x815ddc
    //     0x815dd4: bl              #0xd69bb8
    //     0x815dd8: stur            x4, [x0, #7]
    // 0x815ddc: ldur            x16, [fp, #-0x10]
    // 0x815de0: stp             x0, x16, [SP, #-0x10]!
    // 0x815de4: ldur            x16, [fp, #-0x20]
    // 0x815de8: stp             x16, x6, [SP, #-0x10]!
    // 0x815dec: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x815dec: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x815df0: r0 = setRange()
    //     0x815df0: bl              #0x605c8c  ; [dart:typed_data] __Uint8List&_TypedList&_IntListMixin&_TypedIntListMixin::setRange
    // 0x815df4: add             SP, SP, #0x20
    // 0x815df8: ldur            x1, [fp, #-0x28]
    // 0x815dfc: LoadField: r2 = r1->field_7
    //     0x815dfc: ldur            x2, [x1, #7]
    // 0x815e00: ldur            x3, [fp, #-0x18]
    // 0x815e04: add             x4, x2, x3
    // 0x815e08: StoreField: r1->field_7 = r4
    //     0x815e08: stur            x4, [x1, #7]
    // 0x815e0c: r0 = Null
    //     0x815e0c: mov             x0, NULL
    // 0x815e10: LeaveFrame
    //     0x815e10: mov             SP, fp
    //     0x815e14: ldp             fp, lr, [SP], #0x10
    // 0x815e18: ret
    //     0x815e18: ret             
    // 0x815e1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x815e1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x815e20: b               #0x815cd8
    // 0x815e24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x815e24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x815e28: b               #0x815d14
  }
  _ _expandBuffer(/* No info */) {
    // ** addr: 0x815e2c, size: 0x11c
    // 0x815e2c: EnterFrame
    //     0x815e2c: stp             fp, lr, [SP, #-0x10]!
    //     0x815e30: mov             fp, SP
    // 0x815e34: AllocStack(0x20)
    //     0x815e34: sub             SP, SP, #0x20
    // 0x815e38: SetupParameters(OutputStream this /* r2, fp-0x18 */, [dynamic _ = Null /* r0 */])
    //     0x815e38: mov             x0, x4
    //     0x815e3c: ldur            w1, [x0, #0x13]
    //     0x815e40: add             x1, x1, HEAP, lsl #32
    //     0x815e44: sub             x0, x1, #2
    //     0x815e48: add             x2, fp, w0, sxtw #2
    //     0x815e4c: ldr             x2, [x2, #0x10]
    //     0x815e50: stur            x2, [fp, #-0x18]
    //     0x815e54: cmp             w0, #2
    //     0x815e58: b.lt            #0x815e6c
    //     0x815e5c: add             x1, fp, w0, sxtw #2
    //     0x815e60: ldr             x1, [x1, #8]
    //     0x815e64: mov             x0, x1
    //     0x815e68: b               #0x815e70
    //     0x815e6c: mov             x0, NULL
    // 0x815e70: CheckStackOverflow
    //     0x815e70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x815e74: cmp             SP, x16
    //     0x815e78: b.ls            #0x815f40
    // 0x815e7c: cmp             w0, NULL
    // 0x815e80: b.eq            #0x815ea8
    // 0x815e84: r1 = LoadInt32Instr(r0)
    //     0x815e84: sbfx            x1, x0, #1, #0x1f
    //     0x815e88: tbz             w0, #0, #0x815e90
    //     0x815e8c: ldur            x1, [x0, #7]
    // 0x815e90: cmp             x1, #8, lsl #12
    // 0x815e94: b.le            #0x815ea0
    // 0x815e98: mov             x0, x1
    // 0x815e9c: b               #0x815eac
    // 0x815ea0: r0 = 32768
    //     0x815ea0: mov             x0, #0x8000
    // 0x815ea4: b               #0x815eac
    // 0x815ea8: r0 = 32768
    //     0x815ea8: mov             x0, #0x8000
    // 0x815eac: LoadField: r3 = r2->field_17
    //     0x815eac: ldur            w3, [x2, #0x17]
    // 0x815eb0: DecompressPointer r3
    //     0x815eb0: add             x3, x3, HEAP, lsl #32
    // 0x815eb4: stur            x3, [fp, #-0x10]
    // 0x815eb8: LoadField: r1 = r3->field_13
    //     0x815eb8: ldur            w1, [x3, #0x13]
    // 0x815ebc: DecompressPointer r1
    //     0x815ebc: add             x1, x1, HEAP, lsl #32
    // 0x815ec0: r5 = LoadInt32Instr(r1)
    //     0x815ec0: sbfx            x5, x1, #1, #0x1f
    // 0x815ec4: stur            x5, [fp, #-8]
    // 0x815ec8: add             x1, x5, x0
    // 0x815ecc: lsl             x4, x1, #1
    // 0x815ed0: r0 = BoxInt64Instr(r4)
    //     0x815ed0: sbfiz           x0, x4, #1, #0x1f
    //     0x815ed4: cmp             x4, x0, asr #1
    //     0x815ed8: b.eq            #0x815ee4
    //     0x815edc: bl              #0xd69bb8
    //     0x815ee0: stur            x4, [x0, #7]
    // 0x815ee4: mov             x4, x0
    // 0x815ee8: r0 = AllocateUint8Array()
    //     0x815ee8: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0x815eec: stur            x0, [fp, #-0x20]
    // 0x815ef0: stp             xzr, x0, [SP, #-0x10]!
    // 0x815ef4: ldur            x1, [fp, #-8]
    // 0x815ef8: ldur            x16, [fp, #-0x10]
    // 0x815efc: stp             x16, x1, [SP, #-0x10]!
    // 0x815f00: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x815f00: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x815f04: r0 = setRange()
    //     0x815f04: bl              #0x605c8c  ; [dart:typed_data] __Uint8List&_TypedList&_IntListMixin&_TypedIntListMixin::setRange
    // 0x815f08: add             SP, SP, #0x20
    // 0x815f0c: ldur            x0, [fp, #-0x20]
    // 0x815f10: ldur            x1, [fp, #-0x18]
    // 0x815f14: StoreField: r1->field_17 = r0
    //     0x815f14: stur            w0, [x1, #0x17]
    //     0x815f18: ldurb           w16, [x1, #-1]
    //     0x815f1c: ldurb           w17, [x0, #-1]
    //     0x815f20: and             x16, x17, x16, lsr #2
    //     0x815f24: tst             x16, HEAP, lsr #32
    //     0x815f28: b.eq            #0x815f30
    //     0x815f2c: bl              #0xd6826c
    // 0x815f30: r0 = Null
    //     0x815f30: mov             x0, NULL
    // 0x815f34: LeaveFrame
    //     0x815f34: mov             SP, fp
    //     0x815f38: ldp             fp, lr, [SP], #0x10
    // 0x815f3c: ret
    //     0x815f3c: ret             
    // 0x815f40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x815f40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x815f44: b               #0x815e7c
  }
  _ subset(/* No info */) {
    // ** addr: 0x815f48, size: 0x11c
    // 0x815f48: EnterFrame
    //     0x815f48: stp             fp, lr, [SP, #-0x10]!
    //     0x815f4c: mov             fp, SP
    // 0x815f50: AllocStack(0x18)
    //     0x815f50: sub             SP, SP, #0x18
    // 0x815f54: SetupParameters(OutputStream this /* r1 */, dynamic _ /* r2 */, [dynamic _ = Null /* r0 */])
    //     0x815f54: mov             x0, x4
    //     0x815f58: ldur            w1, [x0, #0x13]
    //     0x815f5c: add             x1, x1, HEAP, lsl #32
    //     0x815f60: sub             x0, x1, #4
    //     0x815f64: add             x1, fp, w0, sxtw #2
    //     0x815f68: ldr             x1, [x1, #0x18]
    //     0x815f6c: add             x2, fp, w0, sxtw #2
    //     0x815f70: ldr             x2, [x2, #0x10]
    //     0x815f74: cmp             w0, #2
    //     0x815f78: b.lt            #0x815f8c
    //     0x815f7c: add             x3, fp, w0, sxtw #2
    //     0x815f80: ldr             x3, [x3, #8]
    //     0x815f84: mov             x0, x3
    //     0x815f88: b               #0x815f90
    //     0x815f8c: mov             x0, NULL
    // 0x815f90: CheckStackOverflow
    //     0x815f90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x815f94: cmp             SP, x16
    //     0x815f98: b.ls            #0x81605c
    // 0x815f9c: tbz             x2, #0x3f, #0x815fac
    // 0x815fa0: LoadField: r3 = r1->field_7
    //     0x815fa0: ldur            x3, [x1, #7]
    // 0x815fa4: add             x4, x3, x2
    // 0x815fa8: mov             x2, x4
    // 0x815fac: stur            x2, [fp, #-0x18]
    // 0x815fb0: cmp             w0, NULL
    // 0x815fb4: b.ne            #0x815fc0
    // 0x815fb8: LoadField: r0 = r1->field_7
    //     0x815fb8: ldur            x0, [x1, #7]
    // 0x815fbc: b               #0x815fe4
    // 0x815fc0: r3 = LoadInt32Instr(r0)
    //     0x815fc0: sbfx            x3, x0, #1, #0x1f
    //     0x815fc4: tbz             w0, #0, #0x815fcc
    //     0x815fc8: ldur            x3, [x0, #7]
    // 0x815fcc: tbz             x3, #0x3f, #0x815fe0
    // 0x815fd0: LoadField: r0 = r1->field_7
    //     0x815fd0: ldur            x0, [x1, #7]
    // 0x815fd4: add             x4, x0, x3
    // 0x815fd8: mov             x0, x4
    // 0x815fdc: b               #0x815fe4
    // 0x815fe0: mov             x0, x3
    // 0x815fe4: stur            x0, [fp, #-0x10]
    // 0x815fe8: LoadField: r3 = r1->field_17
    //     0x815fe8: ldur            w3, [x1, #0x17]
    // 0x815fec: DecompressPointer r3
    //     0x815fec: add             x3, x3, HEAP, lsl #32
    // 0x815ff0: stur            x3, [fp, #-8]
    // 0x815ff4: r0 = _ByteBuffer()
    //     0x815ff4: bl              #0x4b2c3c  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0x815ff8: mov             x2, x0
    // 0x815ffc: ldur            x0, [fp, #-8]
    // 0x816000: StoreField: r2->field_7 = r0
    //     0x816000: stur            w0, [x2, #7]
    // 0x816004: ldur            x3, [fp, #-0x18]
    // 0x816008: ldur            x0, [fp, #-0x10]
    // 0x81600c: sub             x4, x0, x3
    // 0x816010: r0 = BoxInt64Instr(r3)
    //     0x816010: sbfiz           x0, x3, #1, #0x1f
    //     0x816014: cmp             x3, x0, asr #1
    //     0x816018: b.eq            #0x816024
    //     0x81601c: bl              #0xd69bb8
    //     0x816020: stur            x3, [x0, #7]
    // 0x816024: mov             x3, x0
    // 0x816028: r0 = BoxInt64Instr(r4)
    //     0x816028: sbfiz           x0, x4, #1, #0x1f
    //     0x81602c: cmp             x4, x0, asr #1
    //     0x816030: b.eq            #0x81603c
    //     0x816034: bl              #0xd69bb8
    //     0x816038: stur            x4, [x0, #7]
    // 0x81603c: stp             x3, x2, [SP, #-0x10]!
    // 0x816040: SaveReg r0
    //     0x816040: str             x0, [SP, #-8]!
    // 0x816044: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x816044: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x816048: r0 = asUint8List()
    //     0x816048: bl              #0xd64518  ; [dart:typed_data] _ByteBuffer::asUint8List
    // 0x81604c: add             SP, SP, #0x18
    // 0x816050: LeaveFrame
    //     0x816050: mov             SP, fp
    //     0x816054: ldp             fp, lr, [SP], #0x10
    // 0x816058: ret
    //     0x816058: ret             
    // 0x81605c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81605c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x816060: b               #0x815f9c
  }
  _ writeByte(/* No info */) {
    // ** addr: 0x816064, size: 0xb0
    // 0x816064: EnterFrame
    //     0x816064: stp             fp, lr, [SP, #-0x10]!
    //     0x816068: mov             fp, SP
    // 0x81606c: CheckStackOverflow
    //     0x81606c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x816070: cmp             SP, x16
    //     0x816074: b.ls            #0x816108
    // 0x816078: ldr             x0, [fp, #0x18]
    // 0x81607c: LoadField: r1 = r0->field_7
    //     0x81607c: ldur            x1, [x0, #7]
    // 0x816080: LoadField: r2 = r0->field_17
    //     0x816080: ldur            w2, [x0, #0x17]
    // 0x816084: DecompressPointer r2
    //     0x816084: add             x2, x2, HEAP, lsl #32
    // 0x816088: LoadField: r3 = r2->field_13
    //     0x816088: ldur            w3, [x2, #0x13]
    // 0x81608c: DecompressPointer r3
    //     0x81608c: add             x3, x3, HEAP, lsl #32
    // 0x816090: r2 = LoadInt32Instr(r3)
    //     0x816090: sbfx            x2, x3, #1, #0x1f
    // 0x816094: cmp             x1, x2
    // 0x816098: b.ne            #0x8160ac
    // 0x81609c: SaveReg r0
    //     0x81609c: str             x0, [SP, #-8]!
    // 0x8160a0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8160a0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8160a4: r0 = _expandBuffer()
    //     0x8160a4: bl              #0x815e2c  ; [package:archive/src/util/output_stream.dart] OutputStream::_expandBuffer
    // 0x8160a8: add             SP, SP, #8
    // 0x8160ac: ldr             x2, [fp, #0x18]
    // 0x8160b0: r3 = 255
    //     0x8160b0: mov             x3, #0xff
    // 0x8160b4: LoadField: r4 = r2->field_17
    //     0x8160b4: ldur            w4, [x2, #0x17]
    // 0x8160b8: DecompressPointer r4
    //     0x8160b8: add             x4, x4, HEAP, lsl #32
    // 0x8160bc: LoadField: r5 = r2->field_7
    //     0x8160bc: ldur            x5, [x2, #7]
    // 0x8160c0: add             x6, x5, #1
    // 0x8160c4: StoreField: r2->field_7 = r6
    //     0x8160c4: stur            x6, [x2, #7]
    // 0x8160c8: ldr             x2, [fp, #0x10]
    // 0x8160cc: ubfx            x2, x2, #0, #0x20
    // 0x8160d0: and             x6, x2, x3
    // 0x8160d4: LoadField: r2 = r4->field_13
    //     0x8160d4: ldur            w2, [x4, #0x13]
    // 0x8160d8: DecompressPointer r2
    //     0x8160d8: add             x2, x2, HEAP, lsl #32
    // 0x8160dc: r0 = LoadInt32Instr(r2)
    //     0x8160dc: sbfx            x0, x2, #1, #0x1f
    // 0x8160e0: mov             x1, x5
    // 0x8160e4: cmp             x1, x0
    // 0x8160e8: b.hs            #0x816110
    // 0x8160ec: ubfx            x6, x6, #0, #0x20
    // 0x8160f0: ArrayStore: r4[r5] = r6  ; TypeUnknown_1
    //     0x8160f0: add             x1, x4, x5
    //     0x8160f4: strb            w6, [x1, #0x17]
    // 0x8160f8: r0 = Null
    //     0x8160f8: mov             x0, NULL
    // 0x8160fc: LeaveFrame
    //     0x8160fc: mov             SP, fp
    //     0x816100: ldp             fp, lr, [SP], #0x10
    // 0x816104: ret
    //     0x816104: ret             
    // 0x816108: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x816108: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81610c: b               #0x816078
    // 0x816110: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x816110: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ writeInputStream(/* No info */) {
    // ** addr: 0x816864, size: 0x1c8
    // 0x816864: EnterFrame
    //     0x816864: stp             fp, lr, [SP, #-0x10]!
    //     0x816868: mov             fp, SP
    // 0x81686c: AllocStack(0x18)
    //     0x81686c: sub             SP, SP, #0x18
    // 0x816870: CheckStackOverflow
    //     0x816870: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x816874: cmp             SP, x16
    //     0x816878: b.ls            #0x816a10
    // 0x81687c: ldr             x3, [fp, #0x18]
    // 0x816880: ldr             x2, [fp, #0x10]
    // 0x816884: CheckStackOverflow
    //     0x816884: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x816888: cmp             SP, x16
    //     0x81688c: b.ls            #0x816a18
    // 0x816890: LoadField: r4 = r3->field_7
    //     0x816890: ldur            x4, [x3, #7]
    // 0x816894: LoadField: r0 = r2->field_23
    //     0x816894: ldur            w0, [x2, #0x23]
    // 0x816898: DecompressPointer r0
    //     0x816898: add             x0, x0, HEAP, lsl #32
    // 0x81689c: r16 = Sentinel
    //     0x81689c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8168a0: cmp             w0, w16
    // 0x8168a4: b.eq            #0x816a20
    // 0x8168a8: LoadField: r5 = r2->field_b
    //     0x8168a8: ldur            x5, [x2, #0xb]
    // 0x8168ac: LoadField: r1 = r2->field_13
    //     0x8168ac: ldur            x1, [x2, #0x13]
    // 0x8168b0: sub             x6, x5, x1
    // 0x8168b4: r1 = LoadInt32Instr(r0)
    //     0x8168b4: sbfx            x1, x0, #1, #0x1f
    //     0x8168b8: tbz             w0, #0, #0x8168c0
    //     0x8168bc: ldur            x1, [x0, #7]
    // 0x8168c0: sub             x0, x1, x6
    // 0x8168c4: add             x6, x4, x0
    // 0x8168c8: LoadField: r7 = r3->field_17
    //     0x8168c8: ldur            w7, [x3, #0x17]
    // 0x8168cc: DecompressPointer r7
    //     0x8168cc: add             x7, x7, HEAP, lsl #32
    // 0x8168d0: stur            x7, [fp, #-0x10]
    // 0x8168d4: LoadField: r0 = r7->field_13
    //     0x8168d4: ldur            w0, [x7, #0x13]
    // 0x8168d8: DecompressPointer r0
    //     0x8168d8: add             x0, x0, HEAP, lsl #32
    // 0x8168dc: r8 = LoadInt32Instr(r0)
    //     0x8168dc: sbfx            x8, x0, #1, #0x1f
    // 0x8168e0: stur            x8, [fp, #-8]
    // 0x8168e4: cmp             x6, x8
    // 0x8168e8: b.le            #0x81696c
    // 0x8168ec: sub             x0, x6, x8
    // 0x8168f0: cmp             x0, #8, lsl #12
    // 0x8168f4: b.gt            #0x8168fc
    // 0x8168f8: r0 = 32768
    //     0x8168f8: mov             x0, #0x8000
    // 0x8168fc: add             x1, x8, x0
    // 0x816900: lsl             x4, x1, #1
    // 0x816904: r0 = BoxInt64Instr(r4)
    //     0x816904: sbfiz           x0, x4, #1, #0x1f
    //     0x816908: cmp             x4, x0, asr #1
    //     0x81690c: b.eq            #0x816918
    //     0x816910: bl              #0xd69bb8
    //     0x816914: stur            x4, [x0, #7]
    // 0x816918: mov             x4, x0
    // 0x81691c: r0 = AllocateUint8Array()
    //     0x81691c: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0x816920: stur            x0, [fp, #-0x18]
    // 0x816924: stp             xzr, x0, [SP, #-0x10]!
    // 0x816928: ldur            x1, [fp, #-8]
    // 0x81692c: ldur            x16, [fp, #-0x10]
    // 0x816930: stp             x16, x1, [SP, #-0x10]!
    // 0x816934: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x816934: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x816938: r0 = setRange()
    //     0x816938: bl              #0x605c8c  ; [dart:typed_data] __Uint8List&_TypedList&_IntListMixin&_TypedIntListMixin::setRange
    // 0x81693c: add             SP, SP, #0x20
    // 0x816940: ldur            x0, [fp, #-0x18]
    // 0x816944: ldr             x2, [fp, #0x18]
    // 0x816948: StoreField: r2->field_17 = r0
    //     0x816948: stur            w0, [x2, #0x17]
    //     0x81694c: ldurb           w16, [x2, #-1]
    //     0x816950: ldurb           w17, [x0, #-1]
    //     0x816954: and             x16, x17, x16, lsr #2
    //     0x816958: tst             x16, HEAP, lsr #32
    //     0x81695c: b.eq            #0x816964
    //     0x816960: bl              #0xd6828c
    // 0x816964: mov             x3, x2
    // 0x816968: b               #0x816880
    // 0x81696c: mov             x16, x2
    // 0x816970: mov             x2, x3
    // 0x816974: mov             x3, x16
    // 0x816978: LoadField: r7 = r3->field_7
    //     0x816978: ldur            w7, [x3, #7]
    // 0x81697c: DecompressPointer r7
    //     0x81697c: add             x7, x7, HEAP, lsl #32
    // 0x816980: r0 = BoxInt64Instr(r4)
    //     0x816980: sbfiz           x0, x4, #1, #0x1f
    //     0x816984: cmp             x4, x0, asr #1
    //     0x816988: b.eq            #0x816994
    //     0x81698c: bl              #0xd69bb8
    //     0x816990: stur            x4, [x0, #7]
    // 0x816994: mov             x4, x0
    // 0x816998: r0 = BoxInt64Instr(r5)
    //     0x816998: sbfiz           x0, x5, #1, #0x1f
    //     0x81699c: cmp             x5, x0, asr #1
    //     0x8169a0: b.eq            #0x8169ac
    //     0x8169a4: bl              #0xd69bb8
    //     0x8169a8: stur            x5, [x0, #7]
    // 0x8169ac: ldur            x16, [fp, #-0x10]
    // 0x8169b0: stp             x4, x16, [SP, #-0x10]!
    // 0x8169b4: stp             x7, x6, [SP, #-0x10]!
    // 0x8169b8: SaveReg r0
    //     0x8169b8: str             x0, [SP, #-8]!
    // 0x8169bc: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0x8169bc: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0x8169c0: r0 = setRange()
    //     0x8169c0: bl              #0x605c8c  ; [dart:typed_data] __Uint8List&_TypedList&_IntListMixin&_TypedIntListMixin::setRange
    // 0x8169c4: add             SP, SP, #0x28
    // 0x8169c8: ldr             x1, [fp, #0x18]
    // 0x8169cc: LoadField: r2 = r1->field_7
    //     0x8169cc: ldur            x2, [x1, #7]
    // 0x8169d0: ldr             x3, [fp, #0x10]
    // 0x8169d4: LoadField: r4 = r3->field_23
    //     0x8169d4: ldur            w4, [x3, #0x23]
    // 0x8169d8: DecompressPointer r4
    //     0x8169d8: add             x4, x4, HEAP, lsl #32
    // 0x8169dc: LoadField: r5 = r3->field_b
    //     0x8169dc: ldur            x5, [x3, #0xb]
    // 0x8169e0: LoadField: r6 = r3->field_13
    //     0x8169e0: ldur            x6, [x3, #0x13]
    // 0x8169e4: sub             x3, x5, x6
    // 0x8169e8: r5 = LoadInt32Instr(r4)
    //     0x8169e8: sbfx            x5, x4, #1, #0x1f
    //     0x8169ec: tbz             w4, #0, #0x8169f4
    //     0x8169f0: ldur            x5, [x4, #7]
    // 0x8169f4: sub             x4, x5, x3
    // 0x8169f8: add             x3, x2, x4
    // 0x8169fc: StoreField: r1->field_7 = r3
    //     0x8169fc: stur            x3, [x1, #7]
    // 0x816a00: r0 = Null
    //     0x816a00: mov             x0, NULL
    // 0x816a04: LeaveFrame
    //     0x816a04: mov             SP, fp
    //     0x816a08: ldp             fp, lr, [SP], #0x10
    // 0x816a0c: ret
    //     0x816a0c: ret             
    // 0x816a10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x816a10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x816a14: b               #0x81687c
    // 0x816a18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x816a18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x816a1c: b               #0x816890
    // 0x816a20: r9 = _length
    //     0x816a20: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a20] Field <InputStream._length@54080104>: late (offset: 0x24)
    //     0x816a24: ldr             x9, [x9, #0xa20]
    // 0x816a28: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x816a28: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ OutputStream(/* No info */) {
    // ** addr: 0x816c50, size: 0x138
    // 0x816c50: EnterFrame
    //     0x816c50: stp             fp, lr, [SP, #-0x10]!
    //     0x816c54: mov             fp, SP
    // 0x816c58: AllocStack(0x8)
    //     0x816c58: sub             SP, SP, #8
    // 0x816c5c: SetupParameters(OutputStream this /* r3, fp-0x8 */, {int byteOrder = 0 /* r4 */, dynamic size = 65536 /* r0 */})
    //     0x816c5c: mov             x0, x4
    //     0x816c60: ldur            w1, [x0, #0x13]
    //     0x816c64: add             x1, x1, HEAP, lsl #32
    //     0x816c68: sub             x2, x1, #2
    //     0x816c6c: add             x3, fp, w2, sxtw #2
    //     0x816c70: ldr             x3, [x3, #0x10]
    //     0x816c74: stur            x3, [fp, #-8]
    //     0x816c78: ldur            w2, [x0, #0x1f]
    //     0x816c7c: add             x2, x2, HEAP, lsl #32
    //     0x816c80: add             x16, PP, #0x34, lsl #12  ; [pp+0x34bd8] "byteOrder"
    //     0x816c84: ldr             x16, [x16, #0xbd8]
    //     0x816c88: cmp             w2, w16
    //     0x816c8c: b.ne            #0x816cb8
    //     0x816c90: ldur            w2, [x0, #0x23]
    //     0x816c94: add             x2, x2, HEAP, lsl #32
    //     0x816c98: sub             w4, w1, w2
    //     0x816c9c: add             x2, fp, w4, sxtw #2
    //     0x816ca0: ldr             x2, [x2, #8]
    //     0x816ca4: sbfx            x4, x2, #1, #0x1f
    //     0x816ca8: tbz             w2, #0, #0x816cb0
    //     0x816cac: ldur            x4, [x2, #7]
    //     0x816cb0: mov             x2, #1
    //     0x816cb4: b               #0x816cc0
    //     0x816cb8: mov             x4, #0
    //     0x816cbc: mov             x2, #0
    //     0x816cc0: lsl             x5, x2, #1
    //     0x816cc4: lsl             w2, w5, #1
    //     0x816cc8: add             w5, w2, #8
    //     0x816ccc: add             x16, x0, w5, sxtw #1
    //     0x816cd0: ldur            w6, [x16, #0xf]
    //     0x816cd4: add             x6, x6, HEAP, lsl #32
    //     0x816cd8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14fc0] "size"
    //     0x816cdc: ldr             x16, [x16, #0xfc0]
    //     0x816ce0: cmp             w6, w16
    //     0x816ce4: b.ne            #0x816d0c
    //     0x816ce8: add             w5, w2, #0xa
    //     0x816cec: add             x16, x0, w5, sxtw #1
    //     0x816cf0: ldur            w2, [x16, #0xf]
    //     0x816cf4: add             x2, x2, HEAP, lsl #32
    //     0x816cf8: sub             w0, w1, w2
    //     0x816cfc: add             x1, fp, w0, sxtw #2
    //     0x816d00: ldr             x1, [x1, #8]
    //     0x816d04: mov             x0, x1
    //     0x816d08: b               #0x816d10
    //     0x816d0c: mov             x0, #0x10000
    // 0x816d10: StoreField: r3->field_f = r4
    //     0x816d10: stur            x4, [x3, #0xf]
    // 0x816d14: cmp             w0, NULL
    // 0x816d18: b.ne            #0x816d24
    // 0x816d1c: r2 = 32768
    //     0x816d1c: mov             x2, #0x8000
    // 0x816d20: b               #0x816d34
    // 0x816d24: r1 = LoadInt32Instr(r0)
    //     0x816d24: sbfx            x1, x0, #1, #0x1f
    //     0x816d28: tbz             w0, #0, #0x816d30
    //     0x816d2c: ldur            x1, [x0, #7]
    // 0x816d30: mov             x2, x1
    // 0x816d34: r0 = BoxInt64Instr(r2)
    //     0x816d34: sbfiz           x0, x2, #1, #0x1f
    //     0x816d38: cmp             x2, x0, asr #1
    //     0x816d3c: b.eq            #0x816d48
    //     0x816d40: bl              #0xd69bb8
    //     0x816d44: stur            x2, [x0, #7]
    // 0x816d48: mov             x4, x0
    // 0x816d4c: r0 = AllocateUint8Array()
    //     0x816d4c: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0x816d50: ldur            x1, [fp, #-8]
    // 0x816d54: StoreField: r1->field_17 = r0
    //     0x816d54: stur            w0, [x1, #0x17]
    //     0x816d58: ldurb           w16, [x1, #-1]
    //     0x816d5c: ldurb           w17, [x0, #-1]
    //     0x816d60: and             x16, x17, x16, lsr #2
    //     0x816d64: tst             x16, HEAP, lsr #32
    //     0x816d68: b.eq            #0x816d70
    //     0x816d6c: bl              #0xd6826c
    // 0x816d70: r2 = 0
    //     0x816d70: mov             x2, #0
    // 0x816d74: StoreField: r1->field_7 = r2
    //     0x816d74: stur            x2, [x1, #7]
    // 0x816d78: r0 = Null
    //     0x816d78: mov             x0, NULL
    // 0x816d7c: LeaveFrame
    //     0x816d7c: mov             SP, fp
    //     0x816d80: ldp             fp, lr, [SP], #0x10
    // 0x816d84: ret
    //     0x816d84: ret             
  }
  _ writeUint32(/* No info */) {
    // ** addr: 0x8cb2d4, size: 0x188
    // 0x8cb2d4: EnterFrame
    //     0x8cb2d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8cb2d8: mov             fp, SP
    // 0x8cb2dc: CheckStackOverflow
    //     0x8cb2dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cb2e0: cmp             SP, x16
    //     0x8cb2e4: b.ls            #0x8cb454
    // 0x8cb2e8: ldr             x0, [fp, #0x18]
    // 0x8cb2ec: LoadField: r1 = r0->field_f
    //     0x8cb2ec: ldur            x1, [x0, #0xf]
    // 0x8cb2f0: lsl             x2, x1, #1
    // 0x8cb2f4: cmp             w2, #2
    // 0x8cb2f8: b.ne            #0x8cb3a4
    // 0x8cb2fc: ldr             x2, [fp, #0x10]
    // 0x8cb300: r1 = 255
    //     0x8cb300: mov             x1, #0xff
    // 0x8cb304: asr             x3, x2, #0x18
    // 0x8cb308: ubfx            x3, x3, #0, #0x20
    // 0x8cb30c: and             x4, x3, x1
    // 0x8cb310: ubfx            x4, x4, #0, #0x20
    // 0x8cb314: stp             x4, x0, [SP, #-0x10]!
    // 0x8cb318: r0 = writeByte()
    //     0x8cb318: bl              #0x816064  ; [package:archive/src/util/output_stream.dart] OutputStream::writeByte
    // 0x8cb31c: add             SP, SP, #0x10
    // 0x8cb320: ldr             x0, [fp, #0x10]
    // 0x8cb324: asr             x1, x0, #0x10
    // 0x8cb328: ubfx            x1, x1, #0, #0x20
    // 0x8cb32c: r2 = 255
    //     0x8cb32c: mov             x2, #0xff
    // 0x8cb330: and             x3, x1, x2
    // 0x8cb334: ubfx            x3, x3, #0, #0x20
    // 0x8cb338: ldr             x16, [fp, #0x18]
    // 0x8cb33c: stp             x3, x16, [SP, #-0x10]!
    // 0x8cb340: r0 = writeByte()
    //     0x8cb340: bl              #0x816064  ; [package:archive/src/util/output_stream.dart] OutputStream::writeByte
    // 0x8cb344: add             SP, SP, #0x10
    // 0x8cb348: ldr             x0, [fp, #0x10]
    // 0x8cb34c: asr             x1, x0, #8
    // 0x8cb350: ubfx            x1, x1, #0, #0x20
    // 0x8cb354: r2 = 255
    //     0x8cb354: mov             x2, #0xff
    // 0x8cb358: and             x3, x1, x2
    // 0x8cb35c: ubfx            x3, x3, #0, #0x20
    // 0x8cb360: ldr             x16, [fp, #0x18]
    // 0x8cb364: stp             x3, x16, [SP, #-0x10]!
    // 0x8cb368: r0 = writeByte()
    //     0x8cb368: bl              #0x816064  ; [package:archive/src/util/output_stream.dart] OutputStream::writeByte
    // 0x8cb36c: add             SP, SP, #0x10
    // 0x8cb370: ldr             x0, [fp, #0x10]
    // 0x8cb374: ubfx            x0, x0, #0, #0x20
    // 0x8cb378: r1 = 255
    //     0x8cb378: mov             x1, #0xff
    // 0x8cb37c: and             x2, x0, x1
    // 0x8cb380: ubfx            x2, x2, #0, #0x20
    // 0x8cb384: ldr             x16, [fp, #0x18]
    // 0x8cb388: stp             x2, x16, [SP, #-0x10]!
    // 0x8cb38c: r0 = writeByte()
    //     0x8cb38c: bl              #0x816064  ; [package:archive/src/util/output_stream.dart] OutputStream::writeByte
    // 0x8cb390: add             SP, SP, #0x10
    // 0x8cb394: r0 = Null
    //     0x8cb394: mov             x0, NULL
    // 0x8cb398: LeaveFrame
    //     0x8cb398: mov             SP, fp
    //     0x8cb39c: ldp             fp, lr, [SP], #0x10
    // 0x8cb3a0: ret
    //     0x8cb3a0: ret             
    // 0x8cb3a4: ldr             x0, [fp, #0x10]
    // 0x8cb3a8: r1 = 255
    //     0x8cb3a8: mov             x1, #0xff
    // 0x8cb3ac: mov             x2, x0
    // 0x8cb3b0: ubfx            x2, x2, #0, #0x20
    // 0x8cb3b4: and             x3, x2, x1
    // 0x8cb3b8: ubfx            x3, x3, #0, #0x20
    // 0x8cb3bc: ldr             x16, [fp, #0x18]
    // 0x8cb3c0: stp             x3, x16, [SP, #-0x10]!
    // 0x8cb3c4: r0 = writeByte()
    //     0x8cb3c4: bl              #0x816064  ; [package:archive/src/util/output_stream.dart] OutputStream::writeByte
    // 0x8cb3c8: add             SP, SP, #0x10
    // 0x8cb3cc: ldr             x0, [fp, #0x10]
    // 0x8cb3d0: asr             x1, x0, #8
    // 0x8cb3d4: ubfx            x1, x1, #0, #0x20
    // 0x8cb3d8: r2 = 255
    //     0x8cb3d8: mov             x2, #0xff
    // 0x8cb3dc: and             x3, x1, x2
    // 0x8cb3e0: ubfx            x3, x3, #0, #0x20
    // 0x8cb3e4: ldr             x16, [fp, #0x18]
    // 0x8cb3e8: stp             x3, x16, [SP, #-0x10]!
    // 0x8cb3ec: r0 = writeByte()
    //     0x8cb3ec: bl              #0x816064  ; [package:archive/src/util/output_stream.dart] OutputStream::writeByte
    // 0x8cb3f0: add             SP, SP, #0x10
    // 0x8cb3f4: ldr             x0, [fp, #0x10]
    // 0x8cb3f8: asr             x1, x0, #0x10
    // 0x8cb3fc: ubfx            x1, x1, #0, #0x20
    // 0x8cb400: r2 = 255
    //     0x8cb400: mov             x2, #0xff
    // 0x8cb404: and             x3, x1, x2
    // 0x8cb408: ubfx            x3, x3, #0, #0x20
    // 0x8cb40c: ldr             x16, [fp, #0x18]
    // 0x8cb410: stp             x3, x16, [SP, #-0x10]!
    // 0x8cb414: r0 = writeByte()
    //     0x8cb414: bl              #0x816064  ; [package:archive/src/util/output_stream.dart] OutputStream::writeByte
    // 0x8cb418: add             SP, SP, #0x10
    // 0x8cb41c: ldr             x0, [fp, #0x10]
    // 0x8cb420: asr             x1, x0, #0x18
    // 0x8cb424: ubfx            x1, x1, #0, #0x20
    // 0x8cb428: r0 = 255
    //     0x8cb428: mov             x0, #0xff
    // 0x8cb42c: and             x2, x1, x0
    // 0x8cb430: ubfx            x2, x2, #0, #0x20
    // 0x8cb434: ldr             x16, [fp, #0x18]
    // 0x8cb438: stp             x2, x16, [SP, #-0x10]!
    // 0x8cb43c: r0 = writeByte()
    //     0x8cb43c: bl              #0x816064  ; [package:archive/src/util/output_stream.dart] OutputStream::writeByte
    // 0x8cb440: add             SP, SP, #0x10
    // 0x8cb444: r0 = Null
    //     0x8cb444: mov             x0, NULL
    // 0x8cb448: LeaveFrame
    //     0x8cb448: mov             SP, fp
    //     0x8cb44c: ldp             fp, lr, [SP], #0x10
    // 0x8cb450: ret
    //     0x8cb450: ret             
    // 0x8cb454: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cb454: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cb458: b               #0x8cb2e8
  }
}

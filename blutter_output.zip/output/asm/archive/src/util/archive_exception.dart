// lib: , url: package:archive/src/util/archive_exception.dart

// class id: 1048613, size: 0x8
class :: {
}

// class id: 5702, size: 0x14, field offset: 0x14
class ArchiveException extends FormatException {
}

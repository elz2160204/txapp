// lib: , url: package:archive/src/util/adler32.dart

// class id: 1048611, size: 0x8
class :: {

  static _ getAdler32(/* No info */) {
    // ** addr: 0x8d32b8, size: 0x19c
    // 0x8d32b8: EnterFrame
    //     0x8d32b8: stp             fp, lr, [SP, #-0x10]!
    //     0x8d32bc: mov             fp, SP
    // 0x8d32c0: AllocStack(0x28)
    //     0x8d32c0: sub             SP, SP, #0x28
    // 0x8d32c4: CheckStackOverflow
    //     0x8d32c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d32c8: cmp             SP, x16
    //     0x8d32cc: b.ls            #0x8d342c
    // 0x8d32d0: ldr             x2, [fp, #0x10]
    // 0x8d32d4: LoadField: r0 = r2->field_13
    //     0x8d32d4: ldur            w0, [x2, #0x13]
    // 0x8d32d8: DecompressPointer r0
    //     0x8d32d8: add             x0, x0, HEAP, lsl #32
    // 0x8d32dc: r1 = LoadInt32Instr(r0)
    //     0x8d32dc: sbfx            x1, x0, #1, #0x1f
    // 0x8d32e0: r4 = 1
    //     0x8d32e0: mov             x4, #1
    // 0x8d32e4: r3 = 0
    //     0x8d32e4: mov             x3, #0
    // 0x8d32e8: r0 = 0
    //     0x8d32e8: mov             x0, #0
    // 0x8d32ec: CheckStackOverflow
    //     0x8d32ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d32f0: cmp             SP, x16
    //     0x8d32f4: b.ls            #0x8d3434
    // 0x8d32f8: cmp             x1, #0
    // 0x8d32fc: b.le            #0x8d3418
    // 0x8d3300: cmp             x1, #0xed8
    // 0x8d3304: b.ge            #0x8d3310
    // 0x8d3308: mov             x5, x1
    // 0x8d330c: b               #0x8d3314
    // 0x8d3310: r5 = 3800
    //     0x8d3310: mov             x5, #0xed8
    // 0x8d3314: sub             x6, x1, x5
    // 0x8d3318: stur            x6, [fp, #-0x28]
    // 0x8d331c: mov             x16, x3
    // 0x8d3320: mov             x3, x4
    // 0x8d3324: mov             x4, x16
    // 0x8d3328: mov             x16, x0
    // 0x8d332c: mov             x0, x3
    // 0x8d3330: mov             x3, x16
    // 0x8d3334: mov             x16, x5
    // 0x8d3338: mov             x5, x0
    // 0x8d333c: mov             x0, x16
    // 0x8d3340: stur            x5, [fp, #-0x18]
    // 0x8d3344: stur            x4, [fp, #-0x20]
    // 0x8d3348: CheckStackOverflow
    //     0x8d3348: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d334c: cmp             SP, x16
    //     0x8d3350: b.ls            #0x8d343c
    // 0x8d3354: sub             x7, x0, #1
    // 0x8d3358: stur            x7, [fp, #-0x10]
    // 0x8d335c: tbnz            x7, #0x3f, #0x8d33d4
    // 0x8d3360: add             x8, x3, #1
    // 0x8d3364: stur            x8, [fp, #-8]
    // 0x8d3368: r0 = BoxInt64Instr(r3)
    //     0x8d3368: sbfiz           x0, x3, #1, #0x1f
    //     0x8d336c: cmp             x3, x0, asr #1
    //     0x8d3370: b.eq            #0x8d337c
    //     0x8d3374: bl              #0xd69bb8
    //     0x8d3378: stur            x3, [x0, #7]
    // 0x8d337c: r1 = LoadClassIdInstr(r2)
    //     0x8d337c: ldur            x1, [x2, #-1]
    //     0x8d3380: ubfx            x1, x1, #0xc, #0x14
    // 0x8d3384: stp             x0, x2, [SP, #-0x10]!
    // 0x8d3388: mov             x0, x1
    // 0x8d338c: r0 = GDT[cid_x0 + -0xd83]()
    //     0x8d338c: sub             lr, x0, #0xd83
    //     0x8d3390: ldr             lr, [x21, lr, lsl #3]
    //     0x8d3394: blr             lr
    // 0x8d3398: add             SP, SP, #0x10
    // 0x8d339c: r1 = LoadInt32Instr(r0)
    //     0x8d339c: sbfx            x1, x0, #1, #0x1f
    // 0x8d33a0: r2 = 255
    //     0x8d33a0: mov             x2, #0xff
    // 0x8d33a4: and             x5, x1, x2
    // 0x8d33a8: ubfx            x5, x5, #0, #0x20
    // 0x8d33ac: ldur            x1, [fp, #-0x18]
    // 0x8d33b0: add             x6, x1, x5
    // 0x8d33b4: ldur            x5, [fp, #-0x20]
    // 0x8d33b8: add             x4, x5, x6
    // 0x8d33bc: mov             x5, x6
    // 0x8d33c0: ldur            x3, [fp, #-8]
    // 0x8d33c4: ldur            x0, [fp, #-0x10]
    // 0x8d33c8: ldr             x2, [fp, #0x10]
    // 0x8d33cc: ldur            x6, [fp, #-0x28]
    // 0x8d33d0: b               #0x8d3340
    // 0x8d33d4: mov             x1, x5
    // 0x8d33d8: mov             x5, x4
    // 0x8d33dc: r6 = 65521
    //     0x8d33dc: mov             x6, #0xfff1
    // 0x8d33e0: r2 = 255
    //     0x8d33e0: mov             x2, #0xff
    // 0x8d33e4: sdiv            x7, x1, x6
    // 0x8d33e8: msub            x4, x7, x6, x1
    // 0x8d33ec: cmp             x4, xzr
    // 0x8d33f0: b.lt            #0x8d3444
    // 0x8d33f4: sdiv            x1, x5, x6
    // 0x8d33f8: msub            x7, x1, x6, x5
    // 0x8d33fc: cmp             x7, xzr
    // 0x8d3400: b.lt            #0x8d344c
    // 0x8d3404: mov             x0, x3
    // 0x8d3408: mov             x3, x7
    // 0x8d340c: ldur            x1, [fp, #-0x28]
    // 0x8d3410: ldr             x2, [fp, #0x10]
    // 0x8d3414: b               #0x8d32ec
    // 0x8d3418: lsl             x1, x3, #0x10
    // 0x8d341c: orr             x0, x1, x4
    // 0x8d3420: LeaveFrame
    //     0x8d3420: mov             SP, fp
    //     0x8d3424: ldp             fp, lr, [SP], #0x10
    // 0x8d3428: ret
    //     0x8d3428: ret             
    // 0x8d342c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d342c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d3430: b               #0x8d32d0
    // 0x8d3434: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d3434: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d3438: b               #0x8d32f8
    // 0x8d343c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d343c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d3440: b               #0x8d3354
    // 0x8d3444: add             x4, x4, x6
    // 0x8d3448: b               #0x8d33f4
    // 0x8d344c: add             x7, x7, x6
    // 0x8d3450: b               #0x8d3404
  }
}

// lib: , url: package:archive/src/zlib_encoder.dart

// class id: 1048636, size: 0x8
class :: {
}

// class id: 4986, size: 0x8, field offset: 0x8
//   const constructor, 
class ZLibEncoder extends Object {

  _ encode(/* No info */) {
    // ** addr: 0x8cb114, size: 0x1c0
    // 0x8cb114: EnterFrame
    //     0x8cb114: stp             fp, lr, [SP, #-0x10]!
    //     0x8cb118: mov             fp, SP
    // 0x8cb11c: AllocStack(0x28)
    //     0x8cb11c: sub             SP, SP, #0x28
    // 0x8cb120: SetupParameters(ZLibEncoder this /* r3, fp-0x10 */, {dynamic level = Null /* r0, fp-0x8 */})
    //     0x8cb120: mov             x0, x4
    //     0x8cb124: ldur            w1, [x0, #0x13]
    //     0x8cb128: add             x1, x1, HEAP, lsl #32
    //     0x8cb12c: sub             x2, x1, #4
    //     0x8cb130: add             x3, fp, w2, sxtw #2
    //     0x8cb134: ldr             x3, [x3, #0x10]
    //     0x8cb138: stur            x3, [fp, #-0x10]
    //     0x8cb13c: ldur            w2, [x0, #0x1f]
    //     0x8cb140: add             x2, x2, HEAP, lsl #32
    //     0x8cb144: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2fe18] "level"
    //     0x8cb148: ldr             x16, [x16, #0xe18]
    //     0x8cb14c: cmp             w2, w16
    //     0x8cb150: b.ne            #0x8cb170
    //     0x8cb154: ldur            w2, [x0, #0x23]
    //     0x8cb158: add             x2, x2, HEAP, lsl #32
    //     0x8cb15c: sub             w0, w1, w2
    //     0x8cb160: add             x1, fp, w0, sxtw #2
    //     0x8cb164: ldr             x1, [x1, #8]
    //     0x8cb168: mov             x0, x1
    //     0x8cb16c: b               #0x8cb174
    //     0x8cb170: mov             x0, NULL
    //     0x8cb174: stur            x0, [fp, #-8]
    // 0x8cb178: CheckStackOverflow
    //     0x8cb178: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cb17c: cmp             SP, x16
    //     0x8cb180: b.ls            #0x8cb2bc
    // 0x8cb184: r0 = OutputStream()
    //     0x8cb184: bl              #0x816d88  ; AllocateOutputStreamStub -> OutputStream (size=0x1c)
    // 0x8cb188: stur            x0, [fp, #-0x18]
    // 0x8cb18c: r16 = 2
    //     0x8cb18c: mov             x16, #2
    // 0x8cb190: stp             x16, x0, [SP, #-0x10]!
    // 0x8cb194: r4 = const [0, 0x2, 0x2, 0x1, byteOrder, 0x1, null]
    //     0x8cb194: add             x4, PP, #0x34, lsl #12  ; [pp+0x349f8] List(7) [0, 0x2, 0x2, 0x1, "byteOrder", 0x1, Null]
    //     0x8cb198: ldr             x4, [x4, #0x9f8]
    // 0x8cb19c: r0 = OutputStream()
    //     0x8cb19c: bl              #0x816c50  ; [package:archive/src/util/output_stream.dart] OutputStream::OutputStream
    // 0x8cb1a0: add             SP, SP, #0x10
    // 0x8cb1a4: ldur            x16, [fp, #-0x18]
    // 0x8cb1a8: SaveReg r16
    //     0x8cb1a8: str             x16, [SP, #-8]!
    // 0x8cb1ac: r0 = 120
    //     0x8cb1ac: mov             x0, #0x78
    // 0x8cb1b0: SaveReg r0
    //     0x8cb1b0: str             x0, [SP, #-8]!
    // 0x8cb1b4: r0 = writeByte()
    //     0x8cb1b4: bl              #0x816064  ; [package:archive/src/util/output_stream.dart] OutputStream::writeByte
    // 0x8cb1b8: add             SP, SP, #0x10
    // 0x8cb1bc: r1 = 0
    //     0x8cb1bc: mov             x1, #0
    // 0x8cb1c0: r0 = 31
    //     0x8cb1c0: mov             x0, #0x1f
    // 0x8cb1c4: CheckStackOverflow
    //     0x8cb1c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cb1c8: cmp             SP, x16
    //     0x8cb1cc: b.ls            #0x8cb2c4
    // 0x8cb1d0: r17 = 30720
    //     0x8cb1d0: mov             x17, #0x7800
    // 0x8cb1d4: add             x2, x1, x17
    // 0x8cb1d8: sdiv            x4, x2, x0
    // 0x8cb1dc: msub            x3, x4, x0, x2
    // 0x8cb1e0: cmp             x3, xzr
    // 0x8cb1e4: b.lt            #0x8cb2cc
    // 0x8cb1e8: cbz             x3, #0x8cb1f8
    // 0x8cb1ec: add             x2, x1, #1
    // 0x8cb1f0: mov             x1, x2
    // 0x8cb1f4: b               #0x8cb1c4
    // 0x8cb1f8: ldur            x16, [fp, #-0x18]
    // 0x8cb1fc: stp             x1, x16, [SP, #-0x10]!
    // 0x8cb200: r0 = writeByte()
    //     0x8cb200: bl              #0x816064  ; [package:archive/src/util/output_stream.dart] OutputStream::writeByte
    // 0x8cb204: add             SP, SP, #0x10
    // 0x8cb208: ldur            x16, [fp, #-0x10]
    // 0x8cb20c: SaveReg r16
    //     0x8cb20c: str             x16, [SP, #-8]!
    // 0x8cb210: r0 = getAdler32()
    //     0x8cb210: bl              #0x8d32b8  ; [package:archive/src/util/adler32.dart] ::getAdler32
    // 0x8cb214: add             SP, SP, #8
    // 0x8cb218: stur            x0, [fp, #-0x20]
    // 0x8cb21c: r0 = InputStream()
    //     0x8cb21c: bl              #0x818b18  ; AllocateInputStreamStub -> InputStream (size=0x28)
    // 0x8cb220: stur            x0, [fp, #-0x28]
    // 0x8cb224: ldur            x16, [fp, #-0x10]
    // 0x8cb228: stp             x16, x0, [SP, #-0x10]!
    // 0x8cb22c: r16 = 2
    //     0x8cb22c: mov             x16, #2
    // 0x8cb230: SaveReg r16
    //     0x8cb230: str             x16, [SP, #-8]!
    // 0x8cb234: r4 = const [0, 0x3, 0x3, 0x2, byteOrder, 0x2, null]
    //     0x8cb234: add             x4, PP, #0x34, lsl #12  ; [pp+0x34a00] List(7) [0, 0x3, 0x3, 0x2, "byteOrder", 0x2, Null]
    //     0x8cb238: ldr             x4, [x4, #0xa00]
    // 0x8cb23c: r0 = InputStream()
    //     0x8cb23c: bl              #0x818754  ; [package:archive/src/util/input_stream.dart] InputStream::InputStream
    // 0x8cb240: add             SP, SP, #0x18
    // 0x8cb244: r0 = Deflate()
    //     0x8cb244: bl              #0x8d32ac  ; AllocateDeflateStub -> Deflate (size=0xec)
    // 0x8cb248: stur            x0, [fp, #-0x10]
    // 0x8cb24c: ldur            x16, [fp, #-0x28]
    // 0x8cb250: stp             x16, x0, [SP, #-0x10]!
    // 0x8cb254: ldur            x16, [fp, #-8]
    // 0x8cb258: SaveReg r16
    //     0x8cb258: str             x16, [SP, #-8]!
    // 0x8cb25c: r0 = Deflate.buffer()
    //     0x8cb25c: bl              #0x8cb60c  ; [package:archive/src/zlib/deflate.dart] Deflate::Deflate.buffer
    // 0x8cb260: add             SP, SP, #0x18
    // 0x8cb264: ldur            x16, [fp, #-0x10]
    // 0x8cb268: SaveReg r16
    //     0x8cb268: str             x16, [SP, #-8]!
    // 0x8cb26c: r0 = getBytes()
    //     0x8cb26c: bl              #0x8cb45c  ; [package:archive/src/zlib/deflate.dart] Deflate::getBytes
    // 0x8cb270: add             SP, SP, #8
    // 0x8cb274: ldur            x16, [fp, #-0x18]
    // 0x8cb278: stp             x0, x16, [SP, #-0x10]!
    // 0x8cb27c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x8cb27c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x8cb280: r0 = writeBytes()
    //     0x8cb280: bl              #0x815c7c  ; [package:archive/src/util/output_stream.dart] OutputStream::writeBytes
    // 0x8cb284: add             SP, SP, #0x10
    // 0x8cb288: ldur            x16, [fp, #-0x18]
    // 0x8cb28c: SaveReg r16
    //     0x8cb28c: str             x16, [SP, #-8]!
    // 0x8cb290: ldur            x0, [fp, #-0x20]
    // 0x8cb294: SaveReg r0
    //     0x8cb294: str             x0, [SP, #-8]!
    // 0x8cb298: r0 = writeUint32()
    //     0x8cb298: bl              #0x8cb2d4  ; [package:archive/src/util/output_stream.dart] OutputStream::writeUint32
    // 0x8cb29c: add             SP, SP, #0x10
    // 0x8cb2a0: ldur            x16, [fp, #-0x18]
    // 0x8cb2a4: SaveReg r16
    //     0x8cb2a4: str             x16, [SP, #-8]!
    // 0x8cb2a8: r0 = getBytes()
    //     0x8cb2a8: bl              #0x815168  ; [package:archive/src/util/output_stream.dart] OutputStream::getBytes
    // 0x8cb2ac: add             SP, SP, #8
    // 0x8cb2b0: LeaveFrame
    //     0x8cb2b0: mov             SP, fp
    //     0x8cb2b4: ldp             fp, lr, [SP], #0x10
    // 0x8cb2b8: ret
    //     0x8cb2b8: ret             
    // 0x8cb2bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cb2bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cb2c0: b               #0x8cb184
    // 0x8cb2c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cb2c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cb2c8: b               #0x8cb1d0
    // 0x8cb2cc: add             x3, x3, x0
    // 0x8cb2d0: b               #0x8cb1e8
  }
}

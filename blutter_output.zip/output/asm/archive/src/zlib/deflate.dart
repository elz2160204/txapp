// lib: , url: package:archive/src/zlib/deflate.dart

// class id: 1048629, size: 0x8
class :: {
}

// class id: 4990, size: 0x28, field offset: 0x8
class _StaticTree extends Object {

  static late final _StaticTree staticLDesc; // offset: 0xa88
  static late final _StaticTree staticDDesc; // offset: 0xa8c
  static late final _StaticTree staticBlDesc; // offset: 0xa90

  static _StaticTree staticBlDesc() {
    // ** addr: 0x8d2e70, size: 0x3c
    // 0x8d2e70: EnterFrame
    //     0x8d2e70: stp             fp, lr, [SP, #-0x10]!
    //     0x8d2e74: mov             fp, SP
    // 0x8d2e78: r0 = _StaticTree()
    //     0x8d2e78: bl              #0x8d2eac  ; Allocate_StaticTreeStub -> _StaticTree (size=0x28)
    // 0x8d2e7c: r1 = const [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x2, 0x3, 0x7]
    //     0x8d2e7c: add             x1, PP, #0x34, lsl #12  ; [pp+0x34bd0] List<int>(19)
    //     0x8d2e80: ldr             x1, [x1, #0xbd0]
    // 0x8d2e84: StoreField: r0->field_b = r1
    //     0x8d2e84: stur            w1, [x0, #0xb]
    // 0x8d2e88: r1 = 0
    //     0x8d2e88: mov             x1, #0
    // 0x8d2e8c: StoreField: r0->field_f = r1
    //     0x8d2e8c: stur            x1, [x0, #0xf]
    // 0x8d2e90: r1 = 19
    //     0x8d2e90: mov             x1, #0x13
    // 0x8d2e94: StoreField: r0->field_17 = r1
    //     0x8d2e94: stur            x1, [x0, #0x17]
    // 0x8d2e98: r1 = 7
    //     0x8d2e98: mov             x1, #7
    // 0x8d2e9c: StoreField: r0->field_1f = r1
    //     0x8d2e9c: stur            x1, [x0, #0x1f]
    // 0x8d2ea0: LeaveFrame
    //     0x8d2ea0: mov             SP, fp
    //     0x8d2ea4: ldp             fp, lr, [SP], #0x10
    // 0x8d2ea8: ret
    //     0x8d2ea8: ret             
  }
  static _StaticTree staticDDesc() {
    // ** addr: 0x8d2eb8, size: 0x48
    // 0x8d2eb8: EnterFrame
    //     0x8d2eb8: stp             fp, lr, [SP, #-0x10]!
    //     0x8d2ebc: mov             fp, SP
    // 0x8d2ec0: r0 = _StaticTree()
    //     0x8d2ec0: bl              #0x8d2eac  ; Allocate_StaticTreeStub -> _StaticTree (size=0x28)
    // 0x8d2ec4: r1 = const [0, 0x5, 0x10, 0x5, 0x8, 0x5, 0x18, 0x5, 0x4, 0x5, 0x14, 0x5, 0xc, 0x5, 0x1c, 0x5, 0x2, 0x5, 0x12, 0x5, 0xa, 0x5, 0x1a, 0x5, 0x6, 0x5, 0x16, 0x5, 0xe, 0x5, 0x1e, 0x5, 0x1, 0x5, 0x11, 0x5, 0x9, 0x5, 0x19, 0x5, 0x5, 0x5, 0x15, 0x5, 0xd, 0x5, 0x1d, 0x5, 0x3, 0x5, 0x13, 0x5, 0xb, 0x5, 0x1b, 0x5, 0x7, 0x5, 0x17, 0x5]
    //     0x8d2ec4: add             x1, PP, #0x34, lsl #12  ; [pp+0x34ac0] List<int>(60)
    //     0x8d2ec8: ldr             x1, [x1, #0xac0]
    // 0x8d2ecc: StoreField: r0->field_7 = r1
    //     0x8d2ecc: stur            w1, [x0, #7]
    // 0x8d2ed0: r1 = const [0, 0, 0, 0, 0x1, 0x1, 0x2, 0x2, 0x3, 0x3, 0x4, 0x4, 0x5, 0x5, 0x6, 0x6, 0x7, 0x7, 0x8, 0x8, 0x9, 0x9, 0xa, 0xa, 0xb, 0xb, 0xc, 0xc, 0xd, 0xd]
    //     0x8d2ed0: add             x1, PP, #0x34, lsl #12  ; [pp+0x34b28] List<int>(30)
    //     0x8d2ed4: ldr             x1, [x1, #0xb28]
    // 0x8d2ed8: StoreField: r0->field_b = r1
    //     0x8d2ed8: stur            w1, [x0, #0xb]
    // 0x8d2edc: r1 = 0
    //     0x8d2edc: mov             x1, #0
    // 0x8d2ee0: StoreField: r0->field_f = r1
    //     0x8d2ee0: stur            x1, [x0, #0xf]
    // 0x8d2ee4: r1 = 30
    //     0x8d2ee4: mov             x1, #0x1e
    // 0x8d2ee8: StoreField: r0->field_17 = r1
    //     0x8d2ee8: stur            x1, [x0, #0x17]
    // 0x8d2eec: r1 = 15
    //     0x8d2eec: mov             x1, #0xf
    // 0x8d2ef0: StoreField: r0->field_1f = r1
    //     0x8d2ef0: stur            x1, [x0, #0x1f]
    // 0x8d2ef4: LeaveFrame
    //     0x8d2ef4: mov             SP, fp
    //     0x8d2ef8: ldp             fp, lr, [SP], #0x10
    // 0x8d2efc: ret
    //     0x8d2efc: ret             
  }
  static _StaticTree staticLDesc() {
    // ** addr: 0x8d2f00, size: 0x48
    // 0x8d2f00: EnterFrame
    //     0x8d2f00: stp             fp, lr, [SP, #-0x10]!
    //     0x8d2f04: mov             fp, SP
    // 0x8d2f08: r0 = _StaticTree()
    //     0x8d2f08: bl              #0x8d2eac  ; Allocate_StaticTreeStub -> _StaticTree (size=0x28)
    // 0x8d2f0c: r1 = const [0xc, 0x8, 0x8c, 0x8, 0x4c, 0x8, 0xcc, 0x8, 0x2c, 0x8, 0xac, 0x8, 0x6c, 0x8, 0xec, 0x8, 0x1c, 0x8, 0x9c, 0x8, 0x5c, 0x8, 0xdc, 0x8, 0x3c, 0x8, 0xbc, 0x8, 0x7c, 0x8, 0xfc, 0x8, 0x2, 0x8, 0x82, 0x8, 0x42, 0x8, 0xc2, 0x8, 0x22, 0x8, 0xa2, 0x8, 0x62, 0x8, 0xe2, 0x8, 0x12, 0x8, 0x92, 0x8, 0x52, 0x8, 0xd2, 0x8, 0x32, 0x8, 0xb2, 0x8, 0x72, 0x8, 0xf2, 0x8, 0xa, 0x8, 0x8a, 0x8, 0x4a, 0x8, 0xca, 0x8, 0x2a, 0x8, 0xaa, 0x8, 0x6a, 0x8, 0xea, 0x8, 0x1a, 0x8, 0x9a, 0x8, 0x5a, 0x8, 0xda, 0x8, 0x3a, 0x8, 0xba, 0x8, 0x7a, 0x8, 0xfa, 0x8, 0x6, 0x8, 0x86, 0x8, 0x46, 0x8, 0xc6, 0x8, 0x26, 0x8, 0xa6, 0x8, 0x66, 0x8, 0xe6, 0x8, 0x16, 0x8, 0x96, 0x8, 0x56, 0x8, 0xd6, 0x8, 0x36, 0x8, 0xb6, 0x8, 0x76, 0x8, 0xf6, 0x8, 0xe, 0x8, 0x8e, 0x8, 0x4e, 0x8, 0xce, 0x8, 0x2e, 0x8, 0xae, 0x8, 0x6e, 0x8, 0xee, 0x8, 0x1e, 0x8, 0x9e, 0x8, 0x5e, 0x8, 0xde, 0x8, 0x3e, 0x8, 0xbe, 0x8, 0x7e, 0x8, 0xfe, 0x8, 0x1, 0x8, 0x81, 0x8, 0x41, 0x8, 0xc1, 0x8, 0x21, 0x8, 0xa1, 0x8, 0x61, 0x8, 0xe1, 0x8, 0x11, 0x8, 0x91, 0x8, 0x51, 0x8, 0xd1, 0x8, 0x31, 0x8, 0xb1, 0x8, 0x71, 0x8, 0xf1, 0x8, 0x9, 0x8, 0x89, 0x8, 0x49, 0x8, 0xc9, 0x8, 0x29, 0x8, 0xa9, 0x8, 0x69, 0x8, 0xe9, 0x8, 0x19, 0x8, 0x99, 0x8, 0x59, 0x8, 0xd9, 0x8, 0x39, 0x8, 0xb9, 0x8, 0x79, 0x8, 0xf9, 0x8, 0x5, 0x8, 0x85, 0x8, 0x45, 0x8, 0xc5, 0x8, 0x25, 0x8, 0xa5, 0x8, 0x65, 0x8, 0xe5, 0x8, 0x15, 0x8, 0x95, 0x8, 0x55, 0x8, 0xd5, 0x8, 0x35, 0x8, 0xb5, 0x8, 0x75, 0x8, 0xf5, 0x8, 0xd, 0x8, 0x8d, 0x8, 0x4d, 0x8, 0xcd, 0x8, 0x2d, 0x8, 0xad, 0x8, 0x6d, 0x8, 0xed, 0x8, 0x1d, 0x8, 0x9d, 0x8, 0x5d, 0x8, 0xdd, 0x8, 0x3d, 0x8, 0xbd, 0x8, 0x7d, 0x8, 0xfd, 0x8, 0x13, 0x9, 0x113, 0x9, 0x93, 0x9, 0x193, 0x9, 0x53, 0x9, 0x153, 0x9, 0xd3, 0x9, 0x1d3, 0x9, 0x33, 0x9, 0x133, 0x9, 0xb3, 0x9, 0x1b3, 0x9, 0x73, 0x9, 0x173, 0x9, 0xf3, 0x9, 0x1f3, 0x9, 0xb, 0x9, 0x10b, 0x9, 0x8b, 0x9, 0x18b, 0x9, 0x4b, 0x9, 0x14b, 0x9, 0xcb, 0x9, 0x1cb, 0x9, 0x2b, 0x9, 0x12b, 0x9, 0xab, 0x9, 0x1ab, 0x9, 0x6b, 0x9, 0x16b, 0x9, 0xeb, 0x9, 0x1eb, 0x9, 0x1b, 0x9, 0x11b, 0x9, 0x9b, 0x9, 0x19b, 0x9, 0x5b, 0x9, 0x15b, 0x9, 0xdb, 0x9, 0x1db, 0x9, 0x3b, 0x9, 0x13b, 0x9, 0xbb, 0x9, 0x1bb, 0x9, 0x7b, 0x9, 0x17b, 0x9, 0xfb, 0x9, 0x1fb, 0x9, 0x7, 0x9, 0x107, 0x9, 0x87, 0x9, 0x187, 0x9, 0x47, 0x9, 0x147, 0x9, 0xc7, 0x9, 0x1c7, 0x9, 0x27, 0x9, 0x127, 0x9, 0xa7, 0x9, 0x1a7, 0x9, 0x67, 0x9, 0x167, 0x9, 0xe7, 0x9, 0x1e7, 0x9, 0x17, 0x9, 0x117, 0x9, 0x97, 0x9, 0x197, 0x9, 0x57, 0x9, 0x157, 0x9, 0xd7, 0x9, 0x1d7, 0x9, 0x37, 0x9, 0x137, 0x9, 0xb7, 0x9, 0x1b7, 0x9, 0x77, 0x9, 0x177, 0x9, 0xf7, 0x9, 0x1f7, 0x9, 0xf, 0x9, 0x10f, 0x9, 0x8f, 0x9, 0x18f, 0x9, 0x4f, 0x9, 0x14f, 0x9, 0xcf, 0x9, 0x1cf, 0x9, 0x2f, 0x9, 0x12f, 0x9, 0xaf, 0x9, 0x1af, 0x9, 0x6f, 0x9, 0x16f, 0x9, 0xef, 0x9, 0x1ef, 0x9, 0x1f, 0x9, 0x11f, 0x9, 0x9f, 0x9, 0x19f, 0x9, 0x5f, 0x9, 0x15f, 0x9, 0xdf, 0x9, 0x1df, 0x9, 0x3f, 0x9, 0x13f, 0x9, 0xbf, 0x9, 0x1bf, 0x9, 0x7f, 0x9, 0x17f, 0x9, 0xff, 0x9, 0x1ff, 0x9, 0, 0x7, 0x40, 0x7, 0x20, 0x7, 0x60, 0x7, 0x10, 0x7, 0x50, 0x7, 0x30, 0x7, 0x70, 0x7, 0x8, 0x7, 0x48, 0x7, 0x28, 0x7, 0x68, 0x7, 0x18, 0x7, 0x58, 0x7, 0x38, 0x7, 0x78, 0x7, 0x4, 0x7, 0x44, 0x7, 0x24, 0x7, 0x64, 0x7, 0x14, 0x7, 0x54, 0x7, 0x34, 0x7, 0x74, 0x7, 0x3, 0x8, 0x83, 0x8, 0x43, 0x8, 0xc3, 0x8, 0x23, 0x8, 0xa3, 0x8, 0x63, 0x8, 0xe3, 0x8]
    //     0x8d2f0c: add             x1, PP, #0x34, lsl #12  ; [pp+0x34ab8] List<int>(576)
    //     0x8d2f10: ldr             x1, [x1, #0xab8]
    // 0x8d2f14: StoreField: r0->field_7 = r1
    //     0x8d2f14: stur            w1, [x0, #7]
    // 0x8d2f18: r1 = const [0, 0, 0, 0, 0, 0, 0, 0, 0x1, 0x1, 0x1, 0x1, 0x2, 0x2, 0x2, 0x2, 0x3, 0x3, 0x3, 0x3, 0x4, 0x4, 0x4, 0x4, 0x5, 0x5, 0x5, 0x5, 0]
    //     0x8d2f18: add             x1, PP, #0x34, lsl #12  ; [pp+0x34b10] List<int>(29)
    //     0x8d2f1c: ldr             x1, [x1, #0xb10]
    // 0x8d2f20: StoreField: r0->field_b = r1
    //     0x8d2f20: stur            w1, [x0, #0xb]
    // 0x8d2f24: r1 = 257
    //     0x8d2f24: mov             x1, #0x101
    // 0x8d2f28: StoreField: r0->field_f = r1
    //     0x8d2f28: stur            x1, [x0, #0xf]
    // 0x8d2f2c: r1 = 286
    //     0x8d2f2c: mov             x1, #0x11e
    // 0x8d2f30: StoreField: r0->field_17 = r1
    //     0x8d2f30: stur            x1, [x0, #0x17]
    // 0x8d2f34: r1 = 15
    //     0x8d2f34: mov             x1, #0xf
    // 0x8d2f38: StoreField: r0->field_1f = r1
    //     0x8d2f38: stur            x1, [x0, #0x1f]
    // 0x8d2f3c: LeaveFrame
    //     0x8d2f3c: mov             SP, fp
    //     0x8d2f40: ldp             fp, lr, [SP], #0x10
    // 0x8d2f44: ret
    //     0x8d2f44: ret             
  }
}

// class id: 4991, size: 0x14, field offset: 0x8
class _HuffmanTree extends Object {

  late int maxCode; // offset: 0xc
  late Uint16List dynamicTree; // offset: 0x8
  late _StaticTree staticDesc; // offset: 0x10

  static int _dCode(int) {
    // ** addr: 0x8ced3c, size: 0xb0
    // 0x8ced3c: EnterFrame
    //     0x8ced3c: stp             fp, lr, [SP, #-0x10]!
    //     0x8ced40: mov             fp, SP
    // 0x8ced44: ldr             x2, [fp, #0x10]
    // 0x8ced48: cmp             x2, #0x100
    // 0x8ced4c: b.ge            #0x8ced88
    // 0x8ced50: r3 = const [0, 0x1, 0x2, 0x3, 0x4, 0x4, 0x5, 0x5, 0x6, 0x6, 0x6, 0x6, 0x7, 0x7, 0x7, 0x7, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0, 0, 0x10, 0x11, 0x12, 0x12, 0x13, 0x13, 0x14, 0x14, 0x14, 0x14, 0x15, 0x15, 0x15, 0x15, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d]
    //     0x8ced50: add             x3, PP, #0x34, lsl #12  ; [pp+0x34b20] List<int>(512)
    //     0x8ced54: ldr             x3, [x3, #0xb20]
    // 0x8ced58: mov             x1, x2
    // 0x8ced5c: r0 = 512
    //     0x8ced5c: mov             x0, #0x200
    // 0x8ced60: cmp             x1, x0
    // 0x8ced64: b.hs            #0x8cede4
    // 0x8ced68: ArrayLoad: r4 = r3[r2]  ; Unknown_4
    //     0x8ced68: add             x16, x3, x2, lsl #2
    //     0x8ced6c: ldur            w4, [x16, #0xf]
    // 0x8ced70: DecompressPointer r4
    //     0x8ced70: add             x4, x4, HEAP, lsl #32
    // 0x8ced74: r5 = LoadInt32Instr(r4)
    //     0x8ced74: sbfx            x5, x4, #1, #0x1f
    //     0x8ced78: tbz             w4, #0, #0x8ced80
    //     0x8ced7c: ldur            x5, [x4, #7]
    // 0x8ced80: mov             x0, x5
    // 0x8ced84: b               #0x8cedd8
    // 0x8ced88: r3 = const [0, 0x1, 0x2, 0x3, 0x4, 0x4, 0x5, 0x5, 0x6, 0x6, 0x6, 0x6, 0x7, 0x7, 0x7, 0x7, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0, 0, 0x10, 0x11, 0x12, 0x12, 0x13, 0x13, 0x14, 0x14, 0x14, 0x14, 0x15, 0x15, 0x15, 0x15, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d]
    //     0x8ced88: add             x3, PP, #0x34, lsl #12  ; [pp+0x34b20] List<int>(512)
    //     0x8ced8c: ldr             x3, [x3, #0xb20]
    // 0x8ced90: tbnz            x2, #0x3f, #0x8ceda0
    // 0x8ced94: asr             x4, x2, #7
    // 0x8ced98: mov             x2, x4
    // 0x8ced9c: b               #0x8ceda8
    // 0x8ceda0: asr             x4, x2, #7
    // 0x8ceda4: mov             x2, x4
    // 0x8ceda8: add             x4, x2, #0x100
    // 0x8cedac: mov             x1, x4
    // 0x8cedb0: r0 = 512
    //     0x8cedb0: mov             x0, #0x200
    // 0x8cedb4: cmp             x1, x0
    // 0x8cedb8: b.hs            #0x8cede8
    // 0x8cedbc: ArrayLoad: r1 = r3[r4]  ; Unknown_4
    //     0x8cedbc: add             x16, x3, x4, lsl #2
    //     0x8cedc0: ldur            w1, [x16, #0xf]
    // 0x8cedc4: DecompressPointer r1
    //     0x8cedc4: add             x1, x1, HEAP, lsl #32
    // 0x8cedc8: r2 = LoadInt32Instr(r1)
    //     0x8cedc8: sbfx            x2, x1, #1, #0x1f
    //     0x8cedcc: tbz             w1, #0, #0x8cedd4
    //     0x8cedd0: ldur            x2, [x1, #7]
    // 0x8cedd4: mov             x0, x2
    // 0x8cedd8: LeaveFrame
    //     0x8cedd8: mov             SP, fp
    //     0x8ceddc: ldp             fp, lr, [SP], #0x10
    // 0x8cede0: ret
    //     0x8cede0: ret             
    // 0x8cede4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cede4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cede8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cede8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _buildTree(/* No info */) {
    // ** addr: 0x8cf434, size: 0x9cc
    // 0x8cf434: EnterFrame
    //     0x8cf434: stp             fp, lr, [SP, #-0x10]!
    //     0x8cf438: mov             fp, SP
    // 0x8cf43c: AllocStack(0x50)
    //     0x8cf43c: sub             SP, SP, #0x50
    // 0x8cf440: r0 = 1146
    //     0x8cf440: mov             x0, #0x47a
    // 0x8cf444: CheckStackOverflow
    //     0x8cf444: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cf448: cmp             SP, x16
    //     0x8cf44c: b.ls            #0x8cfc88
    // 0x8cf450: ldr             x2, [fp, #0x18]
    // 0x8cf454: LoadField: r3 = r2->field_7
    //     0x8cf454: ldur            w3, [x2, #7]
    // 0x8cf458: DecompressPointer r3
    //     0x8cf458: add             x3, x3, HEAP, lsl #32
    // 0x8cf45c: r16 = Sentinel
    //     0x8cf45c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cf460: cmp             w3, w16
    // 0x8cf464: b.eq            #0x8cfc90
    // 0x8cf468: stur            x3, [fp, #-0x38]
    // 0x8cf46c: LoadField: r1 = r2->field_f
    //     0x8cf46c: ldur            w1, [x2, #0xf]
    // 0x8cf470: DecompressPointer r1
    //     0x8cf470: add             x1, x1, HEAP, lsl #32
    // 0x8cf474: r16 = Sentinel
    //     0x8cf474: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cf478: cmp             w1, w16
    // 0x8cf47c: b.eq            #0x8cfc9c
    // 0x8cf480: LoadField: r4 = r1->field_7
    //     0x8cf480: ldur            w4, [x1, #7]
    // 0x8cf484: DecompressPointer r4
    //     0x8cf484: add             x4, x4, HEAP, lsl #32
    // 0x8cf488: LoadField: r5 = r1->field_17
    //     0x8cf488: ldur            x5, [x1, #0x17]
    // 0x8cf48c: ldr             x6, [fp, #0x10]
    // 0x8cf490: stur            x5, [fp, #-0x30]
    // 0x8cf494: StoreField: r6->field_b7 = rZR
    //     0x8cf494: stur            wzr, [x6, #0xb7]
    // 0x8cf498: StoreField: r6->field_bb = r0
    //     0x8cf498: stur            w0, [x6, #0xbb]
    // 0x8cf49c: LoadField: r7 = r3->field_13
    //     0x8cf49c: ldur            w7, [x3, #0x13]
    // 0x8cf4a0: DecompressPointer r7
    //     0x8cf4a0: add             x7, x7, HEAP, lsl #32
    // 0x8cf4a4: stur            x7, [fp, #-0x28]
    // 0x8cf4a8: r8 = LoadInt32Instr(r7)
    //     0x8cf4a8: sbfx            x8, x7, #1, #0x1f
    // 0x8cf4ac: LoadField: r10 = r6->field_b3
    //     0x8cf4ac: ldur            w10, [x6, #0xb3]
    // 0x8cf4b0: DecompressPointer r10
    //     0x8cf4b0: add             x10, x10, HEAP, lsl #32
    // 0x8cf4b4: stur            x10, [fp, #-0x20]
    // 0x8cf4b8: LoadField: r0 = r10->field_13
    //     0x8cf4b8: ldur            w0, [x10, #0x13]
    // 0x8cf4bc: DecompressPointer r0
    //     0x8cf4bc: add             x0, x0, HEAP, lsl #32
    // 0x8cf4c0: r11 = LoadInt32Instr(r0)
    //     0x8cf4c0: sbfx            x11, x0, #1, #0x1f
    // 0x8cf4c4: LoadField: r12 = r6->field_bf
    //     0x8cf4c4: ldur            w12, [x6, #0xbf]
    // 0x8cf4c8: DecompressPointer r12
    //     0x8cf4c8: add             x12, x12, HEAP, lsl #32
    // 0x8cf4cc: stur            x12, [fp, #-0x18]
    // 0x8cf4d0: LoadField: r0 = r12->field_13
    //     0x8cf4d0: ldur            w0, [x12, #0x13]
    // 0x8cf4d4: DecompressPointer r0
    //     0x8cf4d4: add             x0, x0, HEAP, lsl #32
    // 0x8cf4d8: r13 = LoadInt32Instr(r0)
    //     0x8cf4d8: sbfx            x13, x0, #1, #0x1f
    // 0x8cf4dc: r14 = 0
    //     0x8cf4dc: mov             x14, #0
    // 0x8cf4e0: r9 = -1
    //     0x8cf4e0: mov             x9, #-1
    // 0x8cf4e4: CheckStackOverflow
    //     0x8cf4e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cf4e8: cmp             SP, x16
    //     0x8cf4ec: b.ls            #0x8cfca8
    // 0x8cf4f0: cmp             x14, x5
    // 0x8cf4f4: b.ge            #0x8cf5e0
    // 0x8cf4f8: lsl             x19, x14, #1
    // 0x8cf4fc: mov             x0, x8
    // 0x8cf500: mov             x1, x19
    // 0x8cf504: cmp             x1, x0
    // 0x8cf508: b.hs            #0x8cfcb0
    // 0x8cf50c: add             x16, x3, x19, lsl #1
    // 0x8cf510: ldurh           w0, [x16, #0x17]
    // 0x8cf514: cbz             x0, #0x8cf5b4
    // 0x8cf518: LoadField: r0 = r6->field_b7
    //     0x8cf518: ldur            w0, [x6, #0xb7]
    // 0x8cf51c: DecompressPointer r0
    //     0x8cf51c: add             x0, x0, HEAP, lsl #32
    // 0x8cf520: r16 = Sentinel
    //     0x8cf520: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cf524: cmp             w0, w16
    // 0x8cf528: b.eq            #0x8cfcb4
    // 0x8cf52c: r1 = LoadInt32Instr(r0)
    //     0x8cf52c: sbfx            x1, x0, #1, #0x1f
    //     0x8cf530: tbz             w0, #0, #0x8cf538
    //     0x8cf534: ldur            x1, [x0, #7]
    // 0x8cf538: add             x9, x1, #1
    // 0x8cf53c: r0 = BoxInt64Instr(r9)
    //     0x8cf53c: sbfiz           x0, x9, #1, #0x1f
    //     0x8cf540: cmp             x9, x0, asr #1
    //     0x8cf544: b.eq            #0x8cf550
    //     0x8cf548: bl              #0xd69bb8
    //     0x8cf54c: stur            x9, [x0, #7]
    // 0x8cf550: StoreField: r6->field_b7 = r0
    //     0x8cf550: stur            w0, [x6, #0xb7]
    //     0x8cf554: tbz             w0, #0, #0x8cf570
    //     0x8cf558: ldurb           w16, [x6, #-1]
    //     0x8cf55c: ldurb           w17, [x0, #-1]
    //     0x8cf560: and             x16, x17, x16, lsr #2
    //     0x8cf564: tst             x16, HEAP, lsr #32
    //     0x8cf568: b.eq            #0x8cf570
    //     0x8cf56c: bl              #0xd6830c
    // 0x8cf570: mov             x0, x11
    // 0x8cf574: mov             x1, x9
    // 0x8cf578: cmp             x1, x0
    // 0x8cf57c: b.hs            #0x8cfcc0
    // 0x8cf580: mov             x0, x14
    // 0x8cf584: ubfx            x0, x0, #0, #0x20
    // 0x8cf588: LoadField: r1 = r10->field_7
    //     0x8cf588: ldur            x1, [x10, #7]
    // 0x8cf58c: add             x19, x1, x9, lsl #2
    // 0x8cf590: str             w0, [x19]
    // 0x8cf594: mov             x0, x13
    // 0x8cf598: mov             x1, x14
    // 0x8cf59c: cmp             x1, x0
    // 0x8cf5a0: b.hs            #0x8cfcc4
    // 0x8cf5a4: LoadField: r0 = r12->field_7
    //     0x8cf5a4: ldur            x0, [x12, #7]
    // 0x8cf5a8: strb            wzr, [x0, x14]
    // 0x8cf5ac: mov             x9, x14
    // 0x8cf5b0: b               #0x8cf5d4
    // 0x8cf5b4: add             x20, x19, #1
    // 0x8cf5b8: mov             x0, x8
    // 0x8cf5bc: mov             x1, x20
    // 0x8cf5c0: cmp             x1, x0
    // 0x8cf5c4: b.hs            #0x8cfcc8
    // 0x8cf5c8: LoadField: r0 = r3->field_7
    //     0x8cf5c8: ldur            x0, [x3, #7]
    // 0x8cf5cc: add             x1, x0, x20, lsl #1
    // 0x8cf5d0: strh            wzr, [x1]
    // 0x8cf5d4: add             x0, x14, #1
    // 0x8cf5d8: mov             x14, x0
    // 0x8cf5dc: b               #0x8cf4e4
    // 0x8cf5e0: LoadField: r0 = r10->field_13
    //     0x8cf5e0: ldur            w0, [x10, #0x13]
    // 0x8cf5e4: DecompressPointer r0
    //     0x8cf5e4: add             x0, x0, HEAP, lsl #32
    // 0x8cf5e8: r8 = LoadInt32Instr(r0)
    //     0x8cf5e8: sbfx            x8, x0, #1, #0x1f
    // 0x8cf5ec: r11 = LoadInt32Instr(r7)
    //     0x8cf5ec: sbfx            x11, x7, #1, #0x1f
    // 0x8cf5f0: LoadField: r0 = r12->field_13
    //     0x8cf5f0: ldur            w0, [x12, #0x13]
    // 0x8cf5f4: DecompressPointer r0
    //     0x8cf5f4: add             x0, x0, HEAP, lsl #32
    // 0x8cf5f8: r13 = LoadInt32Instr(r0)
    //     0x8cf5f8: sbfx            x13, x0, #1, #0x1f
    // 0x8cf5fc: mov             x19, x9
    // 0x8cf600: r14 = 1
    //     0x8cf600: mov             x14, #1
    // 0x8cf604: stur            x19, [fp, #-0x10]
    // 0x8cf608: CheckStackOverflow
    //     0x8cf608: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cf60c: cmp             SP, x16
    //     0x8cf610: b.ls            #0x8cfccc
    // 0x8cf614: LoadField: r0 = r6->field_b7
    //     0x8cf614: ldur            w0, [x6, #0xb7]
    // 0x8cf618: DecompressPointer r0
    //     0x8cf618: add             x0, x0, HEAP, lsl #32
    // 0x8cf61c: r16 = Sentinel
    //     0x8cf61c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cf620: cmp             w0, w16
    // 0x8cf624: b.eq            #0x8cfcd4
    // 0x8cf628: r9 = LoadInt32Instr(r0)
    //     0x8cf628: sbfx            x9, x0, #1, #0x1f
    //     0x8cf62c: tbz             w0, #0, #0x8cf634
    //     0x8cf630: ldur            x9, [x0, #7]
    // 0x8cf634: cmp             x9, #2
    // 0x8cf638: b.ge            #0x8cf7e0
    // 0x8cf63c: add             x20, x9, #1
    // 0x8cf640: r0 = BoxInt64Instr(r20)
    //     0x8cf640: sbfiz           x0, x20, #1, #0x1f
    //     0x8cf644: cmp             x20, x0, asr #1
    //     0x8cf648: b.eq            #0x8cf654
    //     0x8cf64c: bl              #0xd69bb8
    //     0x8cf650: stur            x20, [x0, #7]
    // 0x8cf654: StoreField: r6->field_b7 = r0
    //     0x8cf654: stur            w0, [x6, #0xb7]
    //     0x8cf658: tbz             w0, #0, #0x8cf674
    //     0x8cf65c: ldurb           w16, [x6, #-1]
    //     0x8cf660: ldurb           w17, [x0, #-1]
    //     0x8cf664: and             x16, x17, x16, lsr #2
    //     0x8cf668: tst             x16, HEAP, lsr #32
    //     0x8cf66c: b.eq            #0x8cf674
    //     0x8cf670: bl              #0xd6830c
    // 0x8cf674: cmp             x19, #2
    // 0x8cf678: b.ge            #0x8cf68c
    // 0x8cf67c: add             x0, x19, #1
    // 0x8cf680: mov             x9, x0
    // 0x8cf684: mov             x19, x0
    // 0x8cf688: b               #0x8cf690
    // 0x8cf68c: r9 = 0
    //     0x8cf68c: mov             x9, #0
    // 0x8cf690: mov             x0, x8
    // 0x8cf694: mov             x1, x20
    // 0x8cf698: cmp             x1, x0
    // 0x8cf69c: b.hs            #0x8cfce0
    // 0x8cf6a0: mov             x0, x9
    // 0x8cf6a4: ubfx            x0, x0, #0, #0x20
    // 0x8cf6a8: LoadField: r1 = r10->field_7
    //     0x8cf6a8: ldur            x1, [x10, #7]
    // 0x8cf6ac: add             x23, x1, x20, lsl #2
    // 0x8cf6b0: str             w0, [x23]
    // 0x8cf6b4: lsl             x20, x9, #1
    // 0x8cf6b8: mov             x0, x11
    // 0x8cf6bc: mov             x1, x20
    // 0x8cf6c0: cmp             x1, x0
    // 0x8cf6c4: b.hs            #0x8cfce4
    // 0x8cf6c8: LoadField: r0 = r3->field_7
    //     0x8cf6c8: ldur            x0, [x3, #7]
    // 0x8cf6cc: add             x1, x0, x20, lsl #1
    // 0x8cf6d0: strh            w14, [x1]
    // 0x8cf6d4: mov             x0, x13
    // 0x8cf6d8: mov             x1, x9
    // 0x8cf6dc: cmp             x1, x0
    // 0x8cf6e0: b.hs            #0x8cfce8
    // 0x8cf6e4: LoadField: r0 = r12->field_7
    //     0x8cf6e4: ldur            x0, [x12, #7]
    // 0x8cf6e8: strb            wzr, [x0, x9]
    // 0x8cf6ec: LoadField: r0 = r6->field_d3
    //     0x8cf6ec: ldur            w0, [x6, #0xd3]
    // 0x8cf6f0: DecompressPointer r0
    //     0x8cf6f0: add             x0, x0, HEAP, lsl #32
    // 0x8cf6f4: r16 = Sentinel
    //     0x8cf6f4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cf6f8: cmp             w0, w16
    // 0x8cf6fc: b.eq            #0x8cfcec
    // 0x8cf700: r1 = LoadInt32Instr(r0)
    //     0x8cf700: sbfx            x1, x0, #1, #0x1f
    //     0x8cf704: tbz             w0, #0, #0x8cf70c
    //     0x8cf708: ldur            x1, [x0, #7]
    // 0x8cf70c: sub             x9, x1, #1
    // 0x8cf710: r0 = BoxInt64Instr(r9)
    //     0x8cf710: sbfiz           x0, x9, #1, #0x1f
    //     0x8cf714: cmp             x9, x0, asr #1
    //     0x8cf718: b.eq            #0x8cf724
    //     0x8cf71c: bl              #0xd69bb8
    //     0x8cf720: stur            x9, [x0, #7]
    // 0x8cf724: StoreField: r6->field_d3 = r0
    //     0x8cf724: stur            w0, [x6, #0xd3]
    //     0x8cf728: tbz             w0, #0, #0x8cf744
    //     0x8cf72c: ldurb           w16, [x6, #-1]
    //     0x8cf730: ldurb           w17, [x0, #-1]
    //     0x8cf734: and             x16, x17, x16, lsr #2
    //     0x8cf738: tst             x16, HEAP, lsr #32
    //     0x8cf73c: b.eq            #0x8cf744
    //     0x8cf740: bl              #0xd6830c
    // 0x8cf744: cmp             w4, NULL
    // 0x8cf748: b.eq            #0x8cf604
    // 0x8cf74c: LoadField: r23 = r6->field_d7
    //     0x8cf74c: ldur            w23, [x6, #0xd7]
    // 0x8cf750: DecompressPointer r23
    //     0x8cf750: add             x23, x23, HEAP, lsl #32
    // 0x8cf754: r16 = Sentinel
    //     0x8cf754: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cf758: cmp             w23, w16
    // 0x8cf75c: b.eq            #0x8cfcf8
    // 0x8cf760: add             x9, x20, #1
    // 0x8cf764: LoadField: r0 = r4->field_b
    //     0x8cf764: ldur            w0, [x4, #0xb]
    // 0x8cf768: DecompressPointer r0
    //     0x8cf768: add             x0, x0, HEAP, lsl #32
    // 0x8cf76c: r1 = LoadInt32Instr(r0)
    //     0x8cf76c: sbfx            x1, x0, #1, #0x1f
    // 0x8cf770: mov             x0, x1
    // 0x8cf774: mov             x1, x9
    // 0x8cf778: cmp             x1, x0
    // 0x8cf77c: b.hs            #0x8cfd04
    // 0x8cf780: ArrayLoad: r0 = r4[r9]  ; Unknown_4
    //     0x8cf780: add             x16, x4, x9, lsl #2
    //     0x8cf784: ldur            w0, [x16, #0xf]
    // 0x8cf788: DecompressPointer r0
    //     0x8cf788: add             x0, x0, HEAP, lsl #32
    // 0x8cf78c: r1 = LoadInt32Instr(r23)
    //     0x8cf78c: sbfx            x1, x23, #1, #0x1f
    //     0x8cf790: tbz             w23, #0, #0x8cf798
    //     0x8cf794: ldur            x1, [x23, #7]
    // 0x8cf798: r9 = LoadInt32Instr(r0)
    //     0x8cf798: sbfx            x9, x0, #1, #0x1f
    //     0x8cf79c: tbz             w0, #0, #0x8cf7a4
    //     0x8cf7a0: ldur            x9, [x0, #7]
    // 0x8cf7a4: sub             x20, x1, x9
    // 0x8cf7a8: r0 = BoxInt64Instr(r20)
    //     0x8cf7a8: sbfiz           x0, x20, #1, #0x1f
    //     0x8cf7ac: cmp             x20, x0, asr #1
    //     0x8cf7b0: b.eq            #0x8cf7bc
    //     0x8cf7b4: bl              #0xd69bb8
    //     0x8cf7b8: stur            x20, [x0, #7]
    // 0x8cf7bc: StoreField: r6->field_d7 = r0
    //     0x8cf7bc: stur            w0, [x6, #0xd7]
    //     0x8cf7c0: tbz             w0, #0, #0x8cf7dc
    //     0x8cf7c4: ldurb           w16, [x6, #-1]
    //     0x8cf7c8: ldurb           w17, [x0, #-1]
    //     0x8cf7cc: and             x16, x17, x16, lsr #2
    //     0x8cf7d0: tst             x16, HEAP, lsr #32
    //     0x8cf7d4: b.eq            #0x8cf7dc
    //     0x8cf7d8: bl              #0xd6830c
    // 0x8cf7dc: b               #0x8cf604
    // 0x8cf7e0: r4 = 2
    //     0x8cf7e0: mov             x4, #2
    // 0x8cf7e4: r0 = BoxInt64Instr(r19)
    //     0x8cf7e4: sbfiz           x0, x19, #1, #0x1f
    //     0x8cf7e8: cmp             x19, x0, asr #1
    //     0x8cf7ec: b.eq            #0x8cf7f8
    //     0x8cf7f0: bl              #0xd69bb8
    //     0x8cf7f4: stur            x19, [x0, #7]
    // 0x8cf7f8: StoreField: r2->field_b = r0
    //     0x8cf7f8: stur            w0, [x2, #0xb]
    //     0x8cf7fc: tbz             w0, #0, #0x8cf818
    //     0x8cf800: ldurb           w16, [x2, #-1]
    //     0x8cf804: ldurb           w17, [x0, #-1]
    //     0x8cf808: and             x16, x17, x16, lsr #2
    //     0x8cf80c: tst             x16, HEAP, lsr #32
    //     0x8cf810: b.eq            #0x8cf818
    //     0x8cf814: bl              #0xd6828c
    // 0x8cf818: sdiv            x0, x9, x4
    // 0x8cf81c: stur            x0, [fp, #-8]
    // 0x8cf820: CheckStackOverflow
    //     0x8cf820: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cf824: cmp             SP, x16
    //     0x8cf828: b.ls            #0x8cfd08
    // 0x8cf82c: cmp             x0, #1
    // 0x8cf830: b.lt            #0x8cf878
    // 0x8cf834: stp             x3, x6, [SP, #-0x10]!
    // 0x8cf838: SaveReg r0
    //     0x8cf838: str             x0, [SP, #-8]!
    // 0x8cf83c: r0 = _pqdownheap()
    //     0x8cf83c: bl              #0x8d0690  ; [package:archive/src/zlib/deflate.dart] Deflate::_pqdownheap
    // 0x8cf840: add             SP, SP, #0x18
    // 0x8cf844: ldur            x0, [fp, #-8]
    // 0x8cf848: sub             x1, x0, #1
    // 0x8cf84c: mov             x0, x1
    // 0x8cf850: ldr             x2, [fp, #0x18]
    // 0x8cf854: ldr             x6, [fp, #0x10]
    // 0x8cf858: ldur            x5, [fp, #-0x30]
    // 0x8cf85c: ldur            x19, [fp, #-0x10]
    // 0x8cf860: ldur            x10, [fp, #-0x20]
    // 0x8cf864: ldur            x12, [fp, #-0x18]
    // 0x8cf868: ldur            x7, [fp, #-0x28]
    // 0x8cf86c: ldur            x3, [fp, #-0x38]
    // 0x8cf870: r14 = 1
    //     0x8cf870: mov             x14, #1
    // 0x8cf874: b               #0x8cf81c
    // 0x8cf878: mov             x3, x10
    // 0x8cf87c: mov             x4, x12
    // 0x8cf880: mov             x2, x7
    // 0x8cf884: LoadField: r0 = r3->field_13
    //     0x8cf884: ldur            w0, [x3, #0x13]
    // 0x8cf888: DecompressPointer r0
    //     0x8cf888: add             x0, x0, HEAP, lsl #32
    // 0x8cf88c: r5 = LoadInt32Instr(r0)
    //     0x8cf88c: sbfx            x5, x0, #1, #0x1f
    // 0x8cf890: mov             x0, x5
    // 0x8cf894: stur            x5, [fp, #-0x50]
    // 0x8cf898: r1 = 1
    //     0x8cf898: mov             x1, #1
    // 0x8cf89c: cmp             x1, x0
    // 0x8cf8a0: b.hs            #0x8cfd10
    // 0x8cf8a4: r6 = LoadInt32Instr(r2)
    //     0x8cf8a4: sbfx            x6, x2, #1, #0x1f
    // 0x8cf8a8: stur            x6, [fp, #-0x48]
    // 0x8cf8ac: LoadField: r0 = r4->field_13
    //     0x8cf8ac: ldur            w0, [x4, #0x13]
    // 0x8cf8b0: DecompressPointer r0
    //     0x8cf8b0: add             x0, x0, HEAP, lsl #32
    // 0x8cf8b4: r2 = LoadInt32Instr(r0)
    //     0x8cf8b4: sbfx            x2, x0, #1, #0x1f
    // 0x8cf8b8: stur            x2, [fp, #-0x40]
    // 0x8cf8bc: ldur            x11, [fp, #-0x30]
    // 0x8cf8c0: ldr             x8, [fp, #0x10]
    // 0x8cf8c4: ldur            x7, [fp, #-0x38]
    // 0x8cf8c8: r10 = 1
    //     0x8cf8c8: mov             x10, #1
    // 0x8cf8cc: stur            x11, [fp, #-0x30]
    // 0x8cf8d0: CheckStackOverflow
    //     0x8cf8d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cf8d4: cmp             SP, x16
    //     0x8cf8d8: b.ls            #0x8cfd14
    // 0x8cf8dc: LoadField: r12 = r3->field_1b
    //     0x8cf8dc: ldur            w12, [x3, #0x1b]
    // 0x8cf8e0: stur            x12, [fp, #-8]
    // 0x8cf8e4: LoadField: r13 = r8->field_b7
    //     0x8cf8e4: ldur            w13, [x8, #0xb7]
    // 0x8cf8e8: DecompressPointer r13
    //     0x8cf8e8: add             x13, x13, HEAP, lsl #32
    // 0x8cf8ec: r16 = Sentinel
    //     0x8cf8ec: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cf8f0: cmp             w13, w16
    // 0x8cf8f4: b.eq            #0x8cfd1c
    // 0x8cf8f8: stur            x13, [fp, #-0x28]
    // 0x8cf8fc: r9 = LoadInt32Instr(r13)
    //     0x8cf8fc: sbfx            x9, x13, #1, #0x1f
    //     0x8cf900: tbz             w13, #0, #0x8cf908
    //     0x8cf904: ldur            x9, [x13, #7]
    // 0x8cf908: sub             x14, x9, #1
    // 0x8cf90c: r0 = BoxInt64Instr(r14)
    //     0x8cf90c: sbfiz           x0, x14, #1, #0x1f
    //     0x8cf910: cmp             x14, x0, asr #1
    //     0x8cf914: b.eq            #0x8cf920
    //     0x8cf918: bl              #0xd69bb8
    //     0x8cf91c: stur            x14, [x0, #7]
    // 0x8cf920: StoreField: r8->field_b7 = r0
    //     0x8cf920: stur            w0, [x8, #0xb7]
    //     0x8cf924: tbz             w0, #0, #0x8cf940
    //     0x8cf928: ldurb           w16, [x8, #-1]
    //     0x8cf92c: ldurb           w17, [x0, #-1]
    //     0x8cf930: and             x16, x17, x16, lsr #2
    //     0x8cf934: tst             x16, HEAP, lsr #32
    //     0x8cf938: b.eq            #0x8cf940
    //     0x8cf93c: bl              #0xd6834c
    // 0x8cf940: mov             x0, x5
    // 0x8cf944: mov             x1, x9
    // 0x8cf948: cmp             x1, x0
    // 0x8cf94c: b.hs            #0x8cfd28
    // 0x8cf950: ArrayLoad: r0 = r3[r9]  ; Unknown_4
    //     0x8cf950: add             x16, x3, x9, lsl #2
    //     0x8cf954: ldur            w0, [x16, #0x17]
    // 0x8cf958: LoadField: r1 = r3->field_7
    //     0x8cf958: ldur            x1, [x3, #7]
    // 0x8cf95c: str             w0, [x1, #4]
    // 0x8cf960: stp             x7, x8, [SP, #-0x10]!
    // 0x8cf964: SaveReg r10
    //     0x8cf964: str             x10, [SP, #-8]!
    // 0x8cf968: r0 = _pqdownheap()
    //     0x8cf968: bl              #0x8d0690  ; [package:archive/src/zlib/deflate.dart] Deflate::_pqdownheap
    // 0x8cf96c: add             SP, SP, #0x18
    // 0x8cf970: ldur            x2, [fp, #-0x20]
    // 0x8cf974: LoadField: r3 = r2->field_1b
    //     0x8cf974: ldur            w3, [x2, #0x1b]
    // 0x8cf978: ldr             x4, [fp, #0x10]
    // 0x8cf97c: LoadField: r0 = r4->field_bb
    //     0x8cf97c: ldur            w0, [x4, #0xbb]
    // 0x8cf980: DecompressPointer r0
    //     0x8cf980: add             x0, x0, HEAP, lsl #32
    // 0x8cf984: r16 = Sentinel
    //     0x8cf984: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cf988: cmp             w0, w16
    // 0x8cf98c: b.eq            #0x8cfd2c
    // 0x8cf990: r1 = LoadInt32Instr(r0)
    //     0x8cf990: sbfx            x1, x0, #1, #0x1f
    //     0x8cf994: tbz             w0, #0, #0x8cf99c
    //     0x8cf998: ldur            x1, [x0, #7]
    // 0x8cf99c: sub             x5, x1, #1
    // 0x8cf9a0: r0 = BoxInt64Instr(r5)
    //     0x8cf9a0: sbfiz           x0, x5, #1, #0x1f
    //     0x8cf9a4: cmp             x5, x0, asr #1
    //     0x8cf9a8: b.eq            #0x8cf9b4
    //     0x8cf9ac: bl              #0xd69bb8
    //     0x8cf9b0: stur            x5, [x0, #7]
    // 0x8cf9b4: StoreField: r4->field_bb = r0
    //     0x8cf9b4: stur            w0, [x4, #0xbb]
    //     0x8cf9b8: tbz             w0, #0, #0x8cf9d4
    //     0x8cf9bc: ldurb           w16, [x4, #-1]
    //     0x8cf9c0: ldurb           w17, [x0, #-1]
    //     0x8cf9c4: and             x16, x17, x16, lsr #2
    //     0x8cf9c8: tst             x16, HEAP, lsr #32
    //     0x8cf9cc: b.eq            #0x8cf9d4
    //     0x8cf9d0: bl              #0xd682cc
    // 0x8cf9d4: ldur            x0, [fp, #-0x50]
    // 0x8cf9d8: mov             x1, x5
    // 0x8cf9dc: cmp             x1, x0
    // 0x8cf9e0: b.hs            #0x8cfd38
    // 0x8cf9e4: LoadField: r0 = r2->field_7
    //     0x8cf9e4: ldur            x0, [x2, #7]
    // 0x8cf9e8: ldur            x6, [fp, #-8]
    // 0x8cf9ec: add             x1, x0, x5, lsl #2
    // 0x8cf9f0: str             w6, [x1]
    // 0x8cf9f4: sub             x7, x5, #1
    // 0x8cf9f8: r0 = BoxInt64Instr(r7)
    //     0x8cf9f8: sbfiz           x0, x7, #1, #0x1f
    //     0x8cf9fc: cmp             x7, x0, asr #1
    //     0x8cfa00: b.eq            #0x8cfa0c
    //     0x8cfa04: bl              #0xd69bb8
    //     0x8cfa08: stur            x7, [x0, #7]
    // 0x8cfa0c: StoreField: r4->field_bb = r0
    //     0x8cfa0c: stur            w0, [x4, #0xbb]
    //     0x8cfa10: tbz             w0, #0, #0x8cfa2c
    //     0x8cfa14: ldurb           w16, [x4, #-1]
    //     0x8cfa18: ldurb           w17, [x0, #-1]
    //     0x8cfa1c: and             x16, x17, x16, lsr #2
    //     0x8cfa20: tst             x16, HEAP, lsr #32
    //     0x8cfa24: b.eq            #0x8cfa2c
    //     0x8cfa28: bl              #0xd682cc
    // 0x8cfa2c: ldur            x0, [fp, #-0x50]
    // 0x8cfa30: mov             x1, x7
    // 0x8cfa34: cmp             x1, x0
    // 0x8cfa38: b.hs            #0x8cfd3c
    // 0x8cfa3c: LoadField: r0 = r2->field_7
    //     0x8cfa3c: ldur            x0, [x2, #7]
    // 0x8cfa40: add             x1, x0, x7, lsl #2
    // 0x8cfa44: str             w3, [x1]
    // 0x8cfa48: ldur            x7, [fp, #-0x30]
    // 0x8cfa4c: r5 = 1
    //     0x8cfa4c: mov             x5, #1
    // 0x8cfa50: cmp             x5, #0x3f
    // 0x8cfa54: b.hi            #0x8cfd40
    // 0x8cfa58: lsl             x8, x7, x5
    // 0x8cfa5c: ubfx            x6, x6, #0, #0x20
    // 0x8cfa60: cmp             x5, #0x3f
    // 0x8cfa64: b.hi            #0x8cfd70
    // 0x8cfa68: lsl             x9, x6, x5
    // 0x8cfa6c: ldur            x0, [fp, #-0x48]
    // 0x8cfa70: mov             x1, x9
    // 0x8cfa74: cmp             x1, x0
    // 0x8cfa78: b.hs            #0x8cfda4
    // 0x8cfa7c: ldur            x10, [fp, #-0x38]
    // 0x8cfa80: add             x16, x10, x9, lsl #1
    // 0x8cfa84: ldurh           w11, [x16, #0x17]
    // 0x8cfa88: ubfx            x3, x3, #0, #0x20
    // 0x8cfa8c: cmp             x5, #0x3f
    // 0x8cfa90: b.hi            #0x8cfda8
    // 0x8cfa94: lsl             x12, x3, x5
    // 0x8cfa98: ldur            x0, [fp, #-0x48]
    // 0x8cfa9c: mov             x1, x12
    // 0x8cfaa0: cmp             x1, x0
    // 0x8cfaa4: b.hs            #0x8cfde0
    // 0x8cfaa8: add             x16, x10, x12, lsl #1
    // 0x8cfaac: ldurh           w0, [x16, #0x17]
    // 0x8cfab0: add             x13, x11, x0
    // 0x8cfab4: ldur            x0, [fp, #-0x48]
    // 0x8cfab8: mov             x1, x8
    // 0x8cfabc: cmp             x1, x0
    // 0x8cfac0: b.hs            #0x8cfde4
    // 0x8cfac4: LoadField: r0 = r10->field_7
    //     0x8cfac4: ldur            x0, [x10, #7]
    // 0x8cfac8: add             x1, x0, x8, lsl #1
    // 0x8cfacc: strh            w13, [x1]
    // 0x8cfad0: ldur            x0, [fp, #-0x40]
    // 0x8cfad4: mov             x1, x6
    // 0x8cfad8: cmp             x1, x0
    // 0x8cfadc: b.hs            #0x8cfde8
    // 0x8cfae0: ldur            x8, [fp, #-0x18]
    // 0x8cfae4: ArrayLoad: r13 = r8[r6]  ; TypedUnsigned_1
    //     0x8cfae4: add             x16, x8, x6
    //     0x8cfae8: ldrb            w13, [x16, #0x17]
    // 0x8cfaec: ldur            x0, [fp, #-0x40]
    // 0x8cfaf0: mov             x1, x3
    // 0x8cfaf4: cmp             x1, x0
    // 0x8cfaf8: b.hs            #0x8cfdec
    // 0x8cfafc: ArrayLoad: r0 = r8[r3]  ; TypedUnsigned_1
    //     0x8cfafc: add             x16, x8, x3
    //     0x8cfb00: ldrb            w0, [x16, #0x17]
    // 0x8cfb04: cmp             x13, x0
    // 0x8cfb08: b.le            #0x8cfb10
    // 0x8cfb0c: mov             x0, x13
    // 0x8cfb10: add             x3, x0, #1
    // 0x8cfb14: ldur            x0, [fp, #-0x40]
    // 0x8cfb18: mov             x1, x7
    // 0x8cfb1c: cmp             x1, x0
    // 0x8cfb20: b.hs            #0x8cfdf0
    // 0x8cfb24: LoadField: r0 = r8->field_7
    //     0x8cfb24: ldur            x0, [x8, #7]
    // 0x8cfb28: strb            w3, [x0, x7]
    // 0x8cfb2c: add             x3, x9, #1
    // 0x8cfb30: add             x6, x12, #1
    // 0x8cfb34: ldur            x0, [fp, #-0x48]
    // 0x8cfb38: mov             x1, x6
    // 0x8cfb3c: cmp             x1, x0
    // 0x8cfb40: b.hs            #0x8cfdf4
    // 0x8cfb44: LoadField: r0 = r10->field_7
    //     0x8cfb44: ldur            x0, [x10, #7]
    // 0x8cfb48: add             x1, x0, x6, lsl #1
    // 0x8cfb4c: strh            w7, [x1]
    // 0x8cfb50: ldur            x0, [fp, #-0x48]
    // 0x8cfb54: mov             x1, x3
    // 0x8cfb58: cmp             x1, x0
    // 0x8cfb5c: b.hs            #0x8cfdf8
    // 0x8cfb60: LoadField: r0 = r10->field_7
    //     0x8cfb60: ldur            x0, [x10, #7]
    // 0x8cfb64: add             x1, x0, x3, lsl #1
    // 0x8cfb68: strh            w7, [x1]
    // 0x8cfb6c: add             x11, x7, #1
    // 0x8cfb70: stur            x11, [fp, #-8]
    // 0x8cfb74: ubfx            x7, x7, #0, #0x20
    // 0x8cfb78: LoadField: r0 = r2->field_7
    //     0x8cfb78: ldur            x0, [x2, #7]
    // 0x8cfb7c: str             w7, [x0, #4]
    // 0x8cfb80: stp             x10, x4, [SP, #-0x10]!
    // 0x8cfb84: SaveReg r5
    //     0x8cfb84: str             x5, [SP, #-8]!
    // 0x8cfb88: r0 = _pqdownheap()
    //     0x8cfb88: bl              #0x8d0690  ; [package:archive/src/zlib/deflate.dart] Deflate::_pqdownheap
    // 0x8cfb8c: add             SP, SP, #0x18
    // 0x8cfb90: ldr             x2, [fp, #0x10]
    // 0x8cfb94: LoadField: r0 = r2->field_b7
    //     0x8cfb94: ldur            w0, [x2, #0xb7]
    // 0x8cfb98: DecompressPointer r0
    //     0x8cfb98: add             x0, x0, HEAP, lsl #32
    // 0x8cfb9c: r1 = LoadInt32Instr(r0)
    //     0x8cfb9c: sbfx            x1, x0, #1, #0x1f
    //     0x8cfba0: tbz             w0, #0, #0x8cfba8
    //     0x8cfba4: ldur            x1, [x0, #7]
    // 0x8cfba8: cmp             x1, #2
    // 0x8cfbac: b.lt            #0x8cfbd0
    // 0x8cfbb0: ldur            x11, [fp, #-8]
    // 0x8cfbb4: mov             x8, x2
    // 0x8cfbb8: ldur            x3, [fp, #-0x20]
    // 0x8cfbbc: ldur            x4, [fp, #-0x18]
    // 0x8cfbc0: ldur            x5, [fp, #-0x50]
    // 0x8cfbc4: ldur            x6, [fp, #-0x48]
    // 0x8cfbc8: ldur            x2, [fp, #-0x40]
    // 0x8cfbcc: b               #0x8cf8c4
    // 0x8cfbd0: ldur            x4, [fp, #-0x10]
    // 0x8cfbd4: ldur            x3, [fp, #-0x20]
    // 0x8cfbd8: LoadField: r0 = r2->field_bb
    //     0x8cfbd8: ldur            w0, [x2, #0xbb]
    // 0x8cfbdc: DecompressPointer r0
    //     0x8cfbdc: add             x0, x0, HEAP, lsl #32
    // 0x8cfbe0: r1 = LoadInt32Instr(r0)
    //     0x8cfbe0: sbfx            x1, x0, #1, #0x1f
    //     0x8cfbe4: tbz             w0, #0, #0x8cfbec
    //     0x8cfbe8: ldur            x1, [x0, #7]
    // 0x8cfbec: sub             x5, x1, #1
    // 0x8cfbf0: r0 = BoxInt64Instr(r5)
    //     0x8cfbf0: sbfiz           x0, x5, #1, #0x1f
    //     0x8cfbf4: cmp             x5, x0, asr #1
    //     0x8cfbf8: b.eq            #0x8cfc04
    //     0x8cfbfc: bl              #0xd69bb8
    //     0x8cfc00: stur            x5, [x0, #7]
    // 0x8cfc04: StoreField: r2->field_bb = r0
    //     0x8cfc04: stur            w0, [x2, #0xbb]
    //     0x8cfc08: tbz             w0, #0, #0x8cfc24
    //     0x8cfc0c: ldurb           w16, [x2, #-1]
    //     0x8cfc10: ldurb           w17, [x0, #-1]
    //     0x8cfc14: and             x16, x17, x16, lsr #2
    //     0x8cfc18: tst             x16, HEAP, lsr #32
    //     0x8cfc1c: b.eq            #0x8cfc24
    //     0x8cfc20: bl              #0xd6828c
    // 0x8cfc24: LoadField: r6 = r3->field_1b
    //     0x8cfc24: ldur            w6, [x3, #0x1b]
    // 0x8cfc28: ldur            x0, [fp, #-0x50]
    // 0x8cfc2c: mov             x1, x5
    // 0x8cfc30: cmp             x1, x0
    // 0x8cfc34: b.hs            #0x8cfdfc
    // 0x8cfc38: LoadField: r0 = r3->field_7
    //     0x8cfc38: ldur            x0, [x3, #7]
    // 0x8cfc3c: add             x1, x0, x5, lsl #2
    // 0x8cfc40: str             w6, [x1]
    // 0x8cfc44: ldr             x16, [fp, #0x18]
    // 0x8cfc48: stp             x2, x16, [SP, #-0x10]!
    // 0x8cfc4c: r0 = _genBitlen()
    //     0x8cfc4c: bl              #0x8cffc8  ; [package:archive/src/zlib/deflate.dart] _HuffmanTree::_genBitlen
    // 0x8cfc50: add             SP, SP, #0x10
    // 0x8cfc54: ldr             x0, [fp, #0x10]
    // 0x8cfc58: LoadField: r1 = r0->field_af
    //     0x8cfc58: ldur            w1, [x0, #0xaf]
    // 0x8cfc5c: DecompressPointer r1
    //     0x8cfc5c: add             x1, x1, HEAP, lsl #32
    // 0x8cfc60: ldur            x16, [fp, #-0x38]
    // 0x8cfc64: SaveReg r16
    //     0x8cfc64: str             x16, [SP, #-8]!
    // 0x8cfc68: ldur            x0, [fp, #-0x10]
    // 0x8cfc6c: stp             x1, x0, [SP, #-0x10]!
    // 0x8cfc70: r0 = _genCodes()
    //     0x8cfc70: bl              #0x8cfe00  ; [package:archive/src/zlib/deflate.dart] _HuffmanTree::_genCodes
    // 0x8cfc74: add             SP, SP, #0x18
    // 0x8cfc78: r0 = Null
    //     0x8cfc78: mov             x0, NULL
    // 0x8cfc7c: LeaveFrame
    //     0x8cfc7c: mov             SP, fp
    //     0x8cfc80: ldp             fp, lr, [SP], #0x10
    // 0x8cfc84: ret
    //     0x8cfc84: ret             
    // 0x8cfc88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cfc88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cfc8c: b               #0x8cf450
    // 0x8cfc90: r9 = dynamicTree
    //     0x8cfc90: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b50] Field <_HuffmanTree@60040000.dynamicTree>: late (offset: 0x8)
    //     0x8cfc94: ldr             x9, [x9, #0xb50]
    // 0x8cfc98: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cfc98: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cfc9c: r9 = staticDesc
    //     0x8cfc9c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b58] Field <_HuffmanTree@60040000.staticDesc>: late (offset: 0x10)
    //     0x8cfca0: ldr             x9, [x9, #0xb58]
    // 0x8cfca4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cfca4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cfca8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cfca8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cfcac: b               #0x8cf4f0
    // 0x8cfcb0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cfcb0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cfcb4: r9 = _heapLen
    //     0x8cfcb4: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b60] Field <Deflate._heapLen@60040000>: late (offset: 0xb8)
    //     0x8cfcb8: ldr             x9, [x9, #0xb60]
    // 0x8cfcbc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cfcbc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cfcc0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cfcc0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cfcc4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cfcc4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cfcc8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cfcc8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cfccc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cfccc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cfcd0: b               #0x8cf614
    // 0x8cfcd4: r9 = _heapLen
    //     0x8cfcd4: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b60] Field <Deflate._heapLen@60040000>: late (offset: 0xb8)
    //     0x8cfcd8: ldr             x9, [x9, #0xb60]
    // 0x8cfcdc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cfcdc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cfce0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cfce0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cfce4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cfce4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cfce8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cfce8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cfcec: r9 = _optimalLen
    //     0x8cfcec: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ad0] Field <Deflate._optimalLen@60040000>: late (offset: 0xd4)
    //     0x8cfcf0: ldr             x9, [x9, #0xad0]
    // 0x8cfcf4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cfcf4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cfcf8: r9 = _staticLen
    //     0x8cfcf8: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ad8] Field <Deflate._staticLen@60040000>: late (offset: 0xd8)
    //     0x8cfcfc: ldr             x9, [x9, #0xad8]
    // 0x8cfd00: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cfd00: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cfd04: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cfd04: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cfd08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cfd08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cfd0c: b               #0x8cf82c
    // 0x8cfd10: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cfd10: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cfd14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cfd14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cfd18: b               #0x8cf8dc
    // 0x8cfd1c: r9 = _heapLen
    //     0x8cfd1c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b60] Field <Deflate._heapLen@60040000>: late (offset: 0xb8)
    //     0x8cfd20: ldr             x9, [x9, #0xb60]
    // 0x8cfd24: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cfd24: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cfd28: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cfd28: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cfd2c: r9 = _heapMax
    //     0x8cfd2c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b68] Field <Deflate._heapMax@60040000>: late (offset: 0xbc)
    //     0x8cfd30: ldr             x9, [x9, #0xb68]
    // 0x8cfd34: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cfd34: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cfd38: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cfd38: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cfd3c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cfd3c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cfd40: tbnz            x5, #0x3f, #0x8cfd4c
    // 0x8cfd44: mov             x8, xzr
    // 0x8cfd48: b               #0x8cfa5c
    // 0x8cfd4c: str             x5, [THR, #0xc0]  ; THR::
    // 0x8cfd50: stp             x6, x7, [SP, #-0x10]!
    // 0x8cfd54: stp             x4, x5, [SP, #-0x10]!
    // 0x8cfd58: stp             x2, x3, [SP, #-0x10]!
    // 0x8cfd5c: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x8cfd60: r4 = 0
    //     0x8cfd60: mov             x4, #0
    // 0x8cfd64: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8cfd68: blr             lr
    // 0x8cfd6c: brk             #0
    // 0x8cfd70: tbnz            x5, #0x3f, #0x8cfd7c
    // 0x8cfd74: mov             x9, xzr
    // 0x8cfd78: b               #0x8cfa6c
    // 0x8cfd7c: str             x5, [THR, #0xc0]  ; THR::
    // 0x8cfd80: stp             x7, x8, [SP, #-0x10]!
    // 0x8cfd84: stp             x5, x6, [SP, #-0x10]!
    // 0x8cfd88: stp             x3, x4, [SP, #-0x10]!
    // 0x8cfd8c: SaveReg r2
    //     0x8cfd8c: str             x2, [SP, #-8]!
    // 0x8cfd90: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x8cfd94: r4 = 0
    //     0x8cfd94: mov             x4, #0
    // 0x8cfd98: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8cfd9c: blr             lr
    // 0x8cfda0: brk             #0
    // 0x8cfda4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cfda4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cfda8: tbnz            x5, #0x3f, #0x8cfdb4
    // 0x8cfdac: mov             x12, xzr
    // 0x8cfdb0: b               #0x8cfa98
    // 0x8cfdb4: str             x5, [THR, #0xc0]  ; THR::
    // 0x8cfdb8: stp             x10, x11, [SP, #-0x10]!
    // 0x8cfdbc: stp             x8, x9, [SP, #-0x10]!
    // 0x8cfdc0: stp             x6, x7, [SP, #-0x10]!
    // 0x8cfdc4: stp             x4, x5, [SP, #-0x10]!
    // 0x8cfdc8: stp             x2, x3, [SP, #-0x10]!
    // 0x8cfdcc: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x8cfdd0: r4 = 0
    //     0x8cfdd0: mov             x4, #0
    // 0x8cfdd4: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8cfdd8: blr             lr
    // 0x8cfddc: brk             #0
    // 0x8cfde0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cfde0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cfde4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cfde4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cfde8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cfde8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cfdec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cfdec: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cfdf0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cfdf0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cfdf4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cfdf4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cfdf8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cfdf8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cfdfc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cfdfc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ _genCodes(/* No info */) {
    // ** addr: 0x8cfe00, size: 0x1c8
    // 0x8cfe00: EnterFrame
    //     0x8cfe00: stp             fp, lr, [SP, #-0x10]!
    //     0x8cfe04: mov             fp, SP
    // 0x8cfe08: r4 = 32
    //     0x8cfe08: mov             x4, #0x20
    // 0x8cfe0c: r0 = AllocateUint16Array()
    //     0x8cfe0c: bl              #0xd69318  ; AllocateUint16ArrayStub
    // 0x8cfe10: mov             x3, x0
    // 0x8cfe14: ldr             x2, [fp, #0x10]
    // 0x8cfe18: LoadField: r4 = r2->field_13
    //     0x8cfe18: ldur            w4, [x2, #0x13]
    // 0x8cfe1c: DecompressPointer r4
    //     0x8cfe1c: add             x4, x4, HEAP, lsl #32
    // 0x8cfe20: r5 = LoadInt32Instr(r4)
    //     0x8cfe20: sbfx            x5, x4, #1, #0x1f
    // 0x8cfe24: r6 = 0
    //     0x8cfe24: mov             x6, #0
    // 0x8cfe28: r4 = 1
    //     0x8cfe28: mov             x4, #1
    // 0x8cfe2c: CheckStackOverflow
    //     0x8cfe2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cfe30: cmp             SP, x16
    //     0x8cfe34: b.ls            #0x8cffa0
    // 0x8cfe38: cmp             x4, #0xf
    // 0x8cfe3c: b.gt            #0x8cfe7c
    // 0x8cfe40: sub             x7, x4, #1
    // 0x8cfe44: mov             x0, x5
    // 0x8cfe48: mov             x1, x7
    // 0x8cfe4c: cmp             x1, x0
    // 0x8cfe50: b.hs            #0x8cffa8
    // 0x8cfe54: add             x16, x2, x7, lsl #1
    // 0x8cfe58: ldurh           w8, [x16, #0x17]
    // 0x8cfe5c: add             x7, x6, x8
    // 0x8cfe60: lsl             x6, x7, #1
    // 0x8cfe64: LoadField: r7 = r3->field_7
    //     0x8cfe64: ldur            x7, [x3, #7]
    // 0x8cfe68: add             x8, x7, x4, lsl #1
    // 0x8cfe6c: strh            w6, [x8]
    // 0x8cfe70: add             x0, x4, #1
    // 0x8cfe74: mov             x4, x0
    // 0x8cfe78: b               #0x8cfe2c
    // 0x8cfe7c: ldr             x2, [fp, #0x20]
    // 0x8cfe80: LoadField: r4 = r2->field_13
    //     0x8cfe80: ldur            w4, [x2, #0x13]
    // 0x8cfe84: DecompressPointer r4
    //     0x8cfe84: add             x4, x4, HEAP, lsl #32
    // 0x8cfe88: r5 = LoadInt32Instr(r4)
    //     0x8cfe88: sbfx            x5, x4, #1, #0x1f
    // 0x8cfe8c: ldr             x6, [fp, #0x18]
    // 0x8cfe90: r7 = 0
    //     0x8cfe90: mov             x7, #0
    // 0x8cfe94: r4 = 1
    //     0x8cfe94: mov             x4, #1
    // 0x8cfe98: CheckStackOverflow
    //     0x8cfe98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cfe9c: cmp             SP, x16
    //     0x8cfea0: b.ls            #0x8cffac
    // 0x8cfea4: cmp             x7, x6
    // 0x8cfea8: b.gt            #0x8cff90
    // 0x8cfeac: lsl             x8, x7, #1
    // 0x8cfeb0: add             x9, x8, #1
    // 0x8cfeb4: mov             x0, x5
    // 0x8cfeb8: mov             x1, x9
    // 0x8cfebc: cmp             x1, x0
    // 0x8cfec0: b.hs            #0x8cffb4
    // 0x8cfec4: add             x16, x2, x9, lsl #1
    // 0x8cfec8: ldurh           w10, [x16, #0x17]
    // 0x8cfecc: cbz             x10, #0x8cff84
    // 0x8cfed0: mov             x1, x10
    // 0x8cfed4: r0 = 16
    //     0x8cfed4: mov             x0, #0x10
    // 0x8cfed8: cmp             x1, x0
    // 0x8cfedc: b.hs            #0x8cffb8
    // 0x8cfee0: add             x16, x3, x10, lsl #1
    // 0x8cfee4: ldurh           w9, [x16, #0x17]
    // 0x8cfee8: add             x11, x9, #1
    // 0x8cfeec: LoadField: r12 = r3->field_7
    //     0x8cfeec: ldur            x12, [x3, #7]
    // 0x8cfef0: add             x13, x12, x10, lsl #1
    // 0x8cfef4: strh            w11, [x13]
    // 0x8cfef8: mov             x11, x9
    // 0x8cfefc: r9 = 0
    //     0x8cfefc: mov             x9, #0
    // 0x8cff00: CheckStackOverflow
    //     0x8cff00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cff04: cmp             SP, x16
    //     0x8cff08: b.ls            #0x8cffbc
    // 0x8cff0c: mov             x12, x11
    // 0x8cff10: ubfx            x12, x12, #0, #0x20
    // 0x8cff14: and             x13, x12, x4
    // 0x8cff18: ubfx            x13, x13, #0, #0x20
    // 0x8cff1c: orr             x12, x9, x13
    // 0x8cff20: tbnz            x11, #0x3f, #0x8cff30
    // 0x8cff24: asr             x0, x11, #1
    // 0x8cff28: mov             x11, x0
    // 0x8cff2c: b               #0x8cff38
    // 0x8cff30: asr             x0, x11, #1
    // 0x8cff34: mov             x11, x0
    // 0x8cff38: lsl             x9, x12, #1
    // 0x8cff3c: sub             x0, x10, #1
    // 0x8cff40: cmp             x0, #0
    // 0x8cff44: b.le            #0x8cff50
    // 0x8cff48: mov             x10, x0
    // 0x8cff4c: b               #0x8cff00
    // 0x8cff50: tbnz            x9, #0x3f, #0x8cff60
    // 0x8cff54: asr             x10, x9, #1
    // 0x8cff58: mov             x9, x10
    // 0x8cff5c: b               #0x8cff68
    // 0x8cff60: asr             x10, x9, #1
    // 0x8cff64: mov             x9, x10
    // 0x8cff68: mov             x0, x5
    // 0x8cff6c: mov             x1, x8
    // 0x8cff70: cmp             x1, x0
    // 0x8cff74: b.hs            #0x8cffc4
    // 0x8cff78: LoadField: r1 = r2->field_7
    //     0x8cff78: ldur            x1, [x2, #7]
    // 0x8cff7c: add             x10, x1, x8, lsl #1
    // 0x8cff80: strh            w9, [x10]
    // 0x8cff84: add             x0, x7, #1
    // 0x8cff88: mov             x7, x0
    // 0x8cff8c: b               #0x8cfe98
    // 0x8cff90: r0 = Null
    //     0x8cff90: mov             x0, NULL
    // 0x8cff94: LeaveFrame
    //     0x8cff94: mov             SP, fp
    //     0x8cff98: ldp             fp, lr, [SP], #0x10
    // 0x8cff9c: ret
    //     0x8cff9c: ret             
    // 0x8cffa0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cffa0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cffa4: b               #0x8cfe38
    // 0x8cffa8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cffa8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cffac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cffac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cffb0: b               #0x8cfea4
    // 0x8cffb4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cffb4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cffb8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cffb8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cffbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cffbc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cffc0: b               #0x8cff0c
    // 0x8cffc4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cffc4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _genBitlen(/* No info */) {
    // ** addr: 0x8cffc8, size: 0x6c8
    // 0x8cffc8: EnterFrame
    //     0x8cffc8: stp             fp, lr, [SP, #-0x10]!
    //     0x8cffcc: mov             fp, SP
    // 0x8cffd0: AllocStack(0x10)
    //     0x8cffd0: sub             SP, SP, #0x10
    // 0x8cffd4: ldr             x2, [fp, #0x18]
    // 0x8cffd8: LoadField: r3 = r2->field_7
    //     0x8cffd8: ldur            w3, [x2, #7]
    // 0x8cffdc: DecompressPointer r3
    //     0x8cffdc: add             x3, x3, HEAP, lsl #32
    // 0x8cffe0: r16 = Sentinel
    //     0x8cffe0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cffe4: cmp             w3, w16
    // 0x8cffe8: b.eq            #0x8d05bc
    // 0x8cffec: LoadField: r4 = r2->field_f
    //     0x8cffec: ldur            w4, [x2, #0xf]
    // 0x8cfff0: DecompressPointer r4
    //     0x8cfff0: add             x4, x4, HEAP, lsl #32
    // 0x8cfff4: r16 = Sentinel
    //     0x8cfff4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cfff8: cmp             w4, w16
    // 0x8cfffc: b.eq            #0x8d05c8
    // 0x8d0000: LoadField: r5 = r4->field_7
    //     0x8d0000: ldur            w5, [x4, #7]
    // 0x8d0004: DecompressPointer r5
    //     0x8d0004: add             x5, x5, HEAP, lsl #32
    // 0x8d0008: LoadField: r6 = r4->field_b
    //     0x8d0008: ldur            w6, [x4, #0xb]
    // 0x8d000c: DecompressPointer r6
    //     0x8d000c: add             x6, x6, HEAP, lsl #32
    // 0x8d0010: LoadField: r7 = r4->field_f
    //     0x8d0010: ldur            x7, [x4, #0xf]
    // 0x8d0014: LoadField: r8 = r4->field_1f
    //     0x8d0014: ldur            x8, [x4, #0x1f]
    // 0x8d0018: ldr             x4, [fp, #0x10]
    // 0x8d001c: LoadField: r10 = r4->field_af
    //     0x8d001c: ldur            w10, [x4, #0xaf]
    // 0x8d0020: DecompressPointer r10
    //     0x8d0020: add             x10, x10, HEAP, lsl #32
    // 0x8d0024: LoadField: r11 = r10->field_13
    //     0x8d0024: ldur            w11, [x10, #0x13]
    // 0x8d0028: DecompressPointer r11
    //     0x8d0028: add             x11, x11, HEAP, lsl #32
    // 0x8d002c: r9 = LoadInt32Instr(r11)
    //     0x8d002c: sbfx            x9, x11, #1, #0x1f
    // 0x8d0030: r11 = 0
    //     0x8d0030: mov             x11, #0
    // 0x8d0034: CheckStackOverflow
    //     0x8d0034: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d0038: cmp             SP, x16
    //     0x8d003c: b.ls            #0x8d05d4
    // 0x8d0040: cmp             x11, #0xf
    // 0x8d0044: b.gt            #0x8d0070
    // 0x8d0048: mov             x0, x9
    // 0x8d004c: mov             x1, x11
    // 0x8d0050: cmp             x1, x0
    // 0x8d0054: b.hs            #0x8d05dc
    // 0x8d0058: LoadField: r12 = r10->field_7
    //     0x8d0058: ldur            x12, [x10, #7]
    // 0x8d005c: add             x13, x12, x11, lsl #1
    // 0x8d0060: strh            wzr, [x13]
    // 0x8d0064: add             x0, x11, #1
    // 0x8d0068: mov             x11, x0
    // 0x8d006c: b               #0x8d0034
    // 0x8d0070: LoadField: r11 = r4->field_b3
    //     0x8d0070: ldur            w11, [x4, #0xb3]
    // 0x8d0074: DecompressPointer r11
    //     0x8d0074: add             x11, x11, HEAP, lsl #32
    // 0x8d0078: LoadField: r12 = r4->field_bb
    //     0x8d0078: ldur            w12, [x4, #0xbb]
    // 0x8d007c: DecompressPointer r12
    //     0x8d007c: add             x12, x12, HEAP, lsl #32
    // 0x8d0080: r16 = Sentinel
    //     0x8d0080: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d0084: cmp             w12, w16
    // 0x8d0088: b.eq            #0x8d05e0
    // 0x8d008c: LoadField: r13 = r11->field_13
    //     0x8d008c: ldur            w13, [x11, #0x13]
    // 0x8d0090: DecompressPointer r13
    //     0x8d0090: add             x13, x13, HEAP, lsl #32
    // 0x8d0094: r9 = LoadInt32Instr(r12)
    //     0x8d0094: sbfx            x9, x12, #1, #0x1f
    //     0x8d0098: tbz             w12, #0, #0x8d00a0
    //     0x8d009c: ldur            x9, [x12, #7]
    // 0x8d00a0: r14 = LoadInt32Instr(r13)
    //     0x8d00a0: sbfx            x14, x13, #1, #0x1f
    // 0x8d00a4: mov             x0, x14
    // 0x8d00a8: mov             x1, x9
    // 0x8d00ac: stur            x14, [fp, #-8]
    // 0x8d00b0: cmp             x1, x0
    // 0x8d00b4: b.hs            #0x8d05ec
    // 0x8d00b8: ArrayLoad: r13 = r11[r9]  ; Unknown_4
    //     0x8d00b8: add             x16, x11, x9, lsl #2
    //     0x8d00bc: ldur            w13, [x16, #0x17]
    // 0x8d00c0: ubfx            x13, x13, #0, #0x20
    // 0x8d00c4: lsl             x12, x13, #1
    // 0x8d00c8: add             x13, x12, #1
    // 0x8d00cc: LoadField: r12 = r3->field_13
    //     0x8d00cc: ldur            w12, [x3, #0x13]
    // 0x8d00d0: DecompressPointer r12
    //     0x8d00d0: add             x12, x12, HEAP, lsl #32
    // 0x8d00d4: r19 = LoadInt32Instr(r12)
    //     0x8d00d4: sbfx            x19, x12, #1, #0x1f
    // 0x8d00d8: mov             x0, x19
    // 0x8d00dc: mov             x1, x13
    // 0x8d00e0: stur            x19, [fp, #-0x10]
    // 0x8d00e4: cmp             x1, x0
    // 0x8d00e8: b.hs            #0x8d05f0
    // 0x8d00ec: LoadField: r12 = r3->field_7
    //     0x8d00ec: ldur            x12, [x3, #7]
    // 0x8d00f0: add             x20, x12, x13, lsl #1
    // 0x8d00f4: strh            wzr, [x20]
    // 0x8d00f8: add             x12, x9, #1
    // 0x8d00fc: LoadField: r13 = r10->field_13
    //     0x8d00fc: ldur            w13, [x10, #0x13]
    // 0x8d0100: DecompressPointer r13
    //     0x8d0100: add             x13, x13, HEAP, lsl #32
    // 0x8d0104: r20 = LoadInt32Instr(r13)
    //     0x8d0104: sbfx            x20, x13, #1, #0x1f
    // 0x8d0108: LoadField: r13 = r6->field_b
    //     0x8d0108: ldur            w13, [x6, #0xb]
    // 0x8d010c: DecompressPointer r13
    //     0x8d010c: add             x13, x13, HEAP, lsl #32
    // 0x8d0110: r23 = LoadInt32Instr(r13)
    //     0x8d0110: sbfx            x23, x13, #1, #0x1f
    // 0x8d0114: mov             x13, x12
    // 0x8d0118: r12 = 0
    //     0x8d0118: mov             x12, #0
    // 0x8d011c: CheckStackOverflow
    //     0x8d011c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d0120: cmp             SP, x16
    //     0x8d0124: b.ls            #0x8d05f4
    // 0x8d0128: cmp             x13, #0x23d
    // 0x8d012c: b.ge            #0x8d036c
    // 0x8d0130: ldur            x0, [fp, #-8]
    // 0x8d0134: mov             x1, x13
    // 0x8d0138: cmp             x1, x0
    // 0x8d013c: b.hs            #0x8d05fc
    // 0x8d0140: ArrayLoad: r24 = r11[r13]  ; Unknown_4
    //     0x8d0140: add             x16, x11, x13, lsl #2
    //     0x8d0144: ldur            w24, [x16, #0x17]
    // 0x8d0148: ubfx            x24, x24, #0, #0x20
    // 0x8d014c: lsl             x25, x24, #1
    // 0x8d0150: add             x9, x25, #1
    // 0x8d0154: ldur            x0, [fp, #-0x10]
    // 0x8d0158: mov             x1, x9
    // 0x8d015c: cmp             x1, x0
    // 0x8d0160: b.hs            #0x8d0600
    // 0x8d0164: add             x16, x3, x9, lsl #1
    // 0x8d0168: ldurh           w0, [x16, #0x17]
    // 0x8d016c: lsl             x1, x0, #1
    // 0x8d0170: add             x0, x1, #1
    // 0x8d0174: mov             x1, x0
    // 0x8d0178: mov             x14, x0
    // 0x8d017c: ldur            x0, [fp, #-0x10]
    // 0x8d0180: cmp             x1, x0
    // 0x8d0184: b.hs            #0x8d0604
    // 0x8d0188: add             x16, x3, x14, lsl #1
    // 0x8d018c: ldurh           w0, [x16, #0x17]
    // 0x8d0190: add             x14, x0, #1
    // 0x8d0194: cmp             x14, x8
    // 0x8d0198: b.le            #0x8d01a8
    // 0x8d019c: add             x0, x12, #1
    // 0x8d01a0: mov             x14, x8
    // 0x8d01a4: mov             x12, x0
    // 0x8d01a8: LoadField: r0 = r3->field_7
    //     0x8d01a8: ldur            x0, [x3, #7]
    // 0x8d01ac: add             x1, x0, x9, lsl #1
    // 0x8d01b0: strh            w14, [x1]
    // 0x8d01b4: mov             x1, x9
    // 0x8d01b8: LoadField: r0 = r2->field_b
    //     0x8d01b8: ldur            w0, [x2, #0xb]
    // 0x8d01bc: DecompressPointer r0
    //     0x8d01bc: add             x0, x0, HEAP, lsl #32
    // 0x8d01c0: r16 = Sentinel
    //     0x8d01c0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d01c4: cmp             w0, w16
    // 0x8d01c8: b.eq            #0x8d0608
    // 0x8d01cc: r9 = LoadInt32Instr(r0)
    //     0x8d01cc: sbfx            x9, x0, #1, #0x1f
    //     0x8d01d0: tbz             w0, #0, #0x8d01d8
    //     0x8d01d4: ldur            x9, [x0, #7]
    // 0x8d01d8: cmp             x24, x9
    // 0x8d01dc: b.gt            #0x8d0360
    // 0x8d01e0: mov             x0, x20
    // 0x8d01e4: mov             x9, x1
    // 0x8d01e8: mov             x1, x14
    // 0x8d01ec: cmp             x1, x0
    // 0x8d01f0: b.hs            #0x8d0614
    // 0x8d01f4: add             x16, x10, x14, lsl #1
    // 0x8d01f8: ldurh           w0, [x16, #0x17]
    // 0x8d01fc: add             x1, x0, #1
    // 0x8d0200: LoadField: r0 = r10->field_7
    //     0x8d0200: ldur            x0, [x10, #7]
    // 0x8d0204: add             x19, x0, x14, lsl #1
    // 0x8d0208: strh            w1, [x19]
    // 0x8d020c: cmp             x24, x7
    // 0x8d0210: b.lt            #0x8d0244
    // 0x8d0214: sub             x19, x24, x7
    // 0x8d0218: mov             x0, x23
    // 0x8d021c: mov             x1, x19
    // 0x8d0220: cmp             x1, x0
    // 0x8d0224: b.hs            #0x8d0618
    // 0x8d0228: ArrayLoad: r24 = r6[r19]  ; Unknown_4
    //     0x8d0228: add             x16, x6, x19, lsl #2
    //     0x8d022c: ldur            w24, [x16, #0xf]
    // 0x8d0230: DecompressPointer r24
    //     0x8d0230: add             x24, x24, HEAP, lsl #32
    // 0x8d0234: r19 = LoadInt32Instr(r24)
    //     0x8d0234: sbfx            x19, x24, #1, #0x1f
    //     0x8d0238: tbz             w24, #0, #0x8d0240
    //     0x8d023c: ldur            x19, [x24, #7]
    // 0x8d0240: b               #0x8d0248
    // 0x8d0244: r19 = 0
    //     0x8d0244: mov             x19, #0
    // 0x8d0248: ldur            x0, [fp, #-0x10]
    // 0x8d024c: mov             x1, x25
    // 0x8d0250: cmp             x1, x0
    // 0x8d0254: b.hs            #0x8d061c
    // 0x8d0258: add             x16, x3, x25, lsl #1
    // 0x8d025c: ldurh           w24, [x16, #0x17]
    // 0x8d0260: mov             x25, x9
    // 0x8d0264: LoadField: r0 = r4->field_d3
    //     0x8d0264: ldur            w0, [x4, #0xd3]
    // 0x8d0268: DecompressPointer r0
    //     0x8d0268: add             x0, x0, HEAP, lsl #32
    // 0x8d026c: r16 = Sentinel
    //     0x8d026c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d0270: cmp             w0, w16
    // 0x8d0274: b.eq            #0x8d0620
    // 0x8d0278: add             x1, x14, x19
    // 0x8d027c: mul             x14, x24, x1
    // 0x8d0280: r1 = LoadInt32Instr(r0)
    //     0x8d0280: sbfx            x1, x0, #1, #0x1f
    //     0x8d0284: tbz             w0, #0, #0x8d028c
    //     0x8d0288: ldur            x1, [x0, #7]
    // 0x8d028c: add             x9, x1, x14
    // 0x8d0290: r0 = BoxInt64Instr(r9)
    //     0x8d0290: sbfiz           x0, x9, #1, #0x1f
    //     0x8d0294: cmp             x9, x0, asr #1
    //     0x8d0298: b.eq            #0x8d02a4
    //     0x8d029c: bl              #0xd69bb8
    //     0x8d02a0: stur            x9, [x0, #7]
    // 0x8d02a4: StoreField: r4->field_d3 = r0
    //     0x8d02a4: stur            w0, [x4, #0xd3]
    //     0x8d02a8: tbz             w0, #0, #0x8d02c4
    //     0x8d02ac: ldurb           w16, [x4, #-1]
    //     0x8d02b0: ldurb           w17, [x0, #-1]
    //     0x8d02b4: and             x16, x17, x16, lsr #2
    //     0x8d02b8: tst             x16, HEAP, lsr #32
    //     0x8d02bc: b.eq            #0x8d02c4
    //     0x8d02c0: bl              #0xd682cc
    // 0x8d02c4: cmp             w5, NULL
    // 0x8d02c8: b.eq            #0x8d0360
    // 0x8d02cc: LoadField: r14 = r4->field_d7
    //     0x8d02cc: ldur            w14, [x4, #0xd7]
    // 0x8d02d0: DecompressPointer r14
    //     0x8d02d0: add             x14, x14, HEAP, lsl #32
    // 0x8d02d4: r16 = Sentinel
    //     0x8d02d4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d02d8: cmp             w14, w16
    // 0x8d02dc: b.eq            #0x8d062c
    // 0x8d02e0: LoadField: r0 = r5->field_b
    //     0x8d02e0: ldur            w0, [x5, #0xb]
    // 0x8d02e4: DecompressPointer r0
    //     0x8d02e4: add             x0, x0, HEAP, lsl #32
    // 0x8d02e8: r1 = LoadInt32Instr(r0)
    //     0x8d02e8: sbfx            x1, x0, #1, #0x1f
    // 0x8d02ec: mov             x0, x1
    // 0x8d02f0: mov             x1, x25
    // 0x8d02f4: cmp             x1, x0
    // 0x8d02f8: b.hs            #0x8d0638
    // 0x8d02fc: ArrayLoad: r0 = r5[r25]  ; Unknown_4
    //     0x8d02fc: add             x16, x5, x25, lsl #2
    //     0x8d0300: ldur            w0, [x16, #0xf]
    // 0x8d0304: DecompressPointer r0
    //     0x8d0304: add             x0, x0, HEAP, lsl #32
    // 0x8d0308: r25 = LoadInt32Instr(r0)
    //     0x8d0308: sbfx            x25, x0, #1, #0x1f
    //     0x8d030c: tbz             w0, #0, #0x8d0314
    //     0x8d0310: ldur            x25, [x0, #7]
    // 0x8d0314: add             x0, x25, x19
    // 0x8d0318: mul             x19, x24, x0
    // 0x8d031c: r24 = LoadInt32Instr(r14)
    //     0x8d031c: sbfx            x24, x14, #1, #0x1f
    //     0x8d0320: tbz             w14, #0, #0x8d0328
    //     0x8d0324: ldur            x24, [x14, #7]
    // 0x8d0328: add             x14, x24, x19
    // 0x8d032c: r0 = BoxInt64Instr(r14)
    //     0x8d032c: sbfiz           x0, x14, #1, #0x1f
    //     0x8d0330: cmp             x14, x0, asr #1
    //     0x8d0334: b.eq            #0x8d0340
    //     0x8d0338: bl              #0xd69bb8
    //     0x8d033c: stur            x14, [x0, #7]
    // 0x8d0340: StoreField: r4->field_d7 = r0
    //     0x8d0340: stur            w0, [x4, #0xd7]
    //     0x8d0344: tbz             w0, #0, #0x8d0360
    //     0x8d0348: ldurb           w16, [x4, #-1]
    //     0x8d034c: ldurb           w17, [x0, #-1]
    //     0x8d0350: and             x16, x17, x16, lsr #2
    //     0x8d0354: tst             x16, HEAP, lsr #32
    //     0x8d0358: b.eq            #0x8d0360
    //     0x8d035c: bl              #0xd682cc
    // 0x8d0360: add             x0, x13, #1
    // 0x8d0364: mov             x13, x0
    // 0x8d0368: b               #0x8d011c
    // 0x8d036c: cbnz            x12, #0x8d0380
    // 0x8d0370: r0 = Null
    //     0x8d0370: mov             x0, NULL
    // 0x8d0374: LeaveFrame
    //     0x8d0374: mov             SP, fp
    //     0x8d0378: ldp             fp, lr, [SP], #0x10
    // 0x8d037c: ret
    //     0x8d037c: ret             
    // 0x8d0380: sub             x5, x8, #1
    // 0x8d0384: LoadField: r6 = r10->field_13
    //     0x8d0384: ldur            w6, [x10, #0x13]
    // 0x8d0388: DecompressPointer r6
    //     0x8d0388: add             x6, x6, HEAP, lsl #32
    // 0x8d038c: r7 = LoadInt32Instr(r6)
    //     0x8d038c: sbfx            x7, x6, #1, #0x1f
    // 0x8d0390: mov             x6, x12
    // 0x8d0394: CheckStackOverflow
    //     0x8d0394: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d0398: cmp             SP, x16
    //     0x8d039c: b.ls            #0x8d063c
    // 0x8d03a0: mov             x9, x5
    // 0x8d03a4: CheckStackOverflow
    //     0x8d03a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d03a8: cmp             SP, x16
    //     0x8d03ac: b.ls            #0x8d0644
    // 0x8d03b0: mov             x0, x7
    // 0x8d03b4: mov             x1, x9
    // 0x8d03b8: cmp             x1, x0
    // 0x8d03bc: b.hs            #0x8d064c
    // 0x8d03c0: add             x16, x10, x9, lsl #1
    // 0x8d03c4: ldurh           w12, [x16, #0x17]
    // 0x8d03c8: cbnz            x12, #0x8d03d8
    // 0x8d03cc: sub             x0, x9, #1
    // 0x8d03d0: mov             x9, x0
    // 0x8d03d4: b               #0x8d03a4
    // 0x8d03d8: sub             x14, x12, #1
    // 0x8d03dc: LoadField: r12 = r10->field_7
    //     0x8d03dc: ldur            x12, [x10, #7]
    // 0x8d03e0: add             x19, x12, x9, lsl #1
    // 0x8d03e4: strh            w14, [x19]
    // 0x8d03e8: add             x12, x9, #1
    // 0x8d03ec: mov             x0, x7
    // 0x8d03f0: mov             x1, x12
    // 0x8d03f4: cmp             x1, x0
    // 0x8d03f8: b.hs            #0x8d0650
    // 0x8d03fc: add             x16, x10, x12, lsl #1
    // 0x8d0400: ldurh           w14, [x16, #0x17]
    // 0x8d0404: add             x19, x14, #2
    // 0x8d0408: LoadField: r14 = r10->field_7
    //     0x8d0408: ldur            x14, [x10, #7]
    // 0x8d040c: add             x20, x14, x12, lsl #1
    // 0x8d0410: strh            w19, [x20]
    // 0x8d0414: mov             x0, x7
    // 0x8d0418: mov             x1, x8
    // 0x8d041c: cmp             x1, x0
    // 0x8d0420: b.hs            #0x8d0654
    // 0x8d0424: add             x16, x10, x8, lsl #1
    // 0x8d0428: ldurh           w12, [x16, #0x17]
    // 0x8d042c: sub             x14, x12, #1
    // 0x8d0430: LoadField: r12 = r10->field_7
    //     0x8d0430: ldur            x12, [x10, #7]
    // 0x8d0434: add             x19, x12, x8, lsl #1
    // 0x8d0438: strh            w14, [x19]
    // 0x8d043c: sub             x0, x6, #2
    // 0x8d0440: cmp             x0, #0
    // 0x8d0444: b.le            #0x8d0450
    // 0x8d0448: mov             x6, x0
    // 0x8d044c: b               #0x8d0394
    // 0x8d0450: mov             x6, x13
    // 0x8d0454: mov             x5, x8
    // 0x8d0458: CheckStackOverflow
    //     0x8d0458: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d045c: cmp             SP, x16
    //     0x8d0460: b.ls            #0x8d0658
    // 0x8d0464: cbz             x5, #0x8d05ac
    // 0x8d0468: mov             x0, x7
    // 0x8d046c: mov             x1, x5
    // 0x8d0470: cmp             x1, x0
    // 0x8d0474: b.hs            #0x8d0660
    // 0x8d0478: add             x16, x10, x5, lsl #1
    // 0x8d047c: ldurh           w8, [x16, #0x17]
    // 0x8d0480: mov             x0, x6
    // 0x8d0484: mov             x6, x8
    // 0x8d0488: CheckStackOverflow
    //     0x8d0488: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d048c: cmp             SP, x16
    //     0x8d0490: b.ls            #0x8d0664
    // 0x8d0494: cbz             x6, #0x8d059c
    // 0x8d0498: sub             x8, x0, #1
    // 0x8d049c: ldur            x0, [fp, #-8]
    // 0x8d04a0: mov             x1, x8
    // 0x8d04a4: cmp             x1, x0
    // 0x8d04a8: b.hs            #0x8d066c
    // 0x8d04ac: ArrayLoad: r12 = r11[r8]  ; Unknown_4
    //     0x8d04ac: add             x16, x11, x8, lsl #2
    //     0x8d04b0: ldur            w12, [x16, #0x17]
    // 0x8d04b4: LoadField: r13 = r2->field_b
    //     0x8d04b4: ldur            w13, [x2, #0xb]
    // 0x8d04b8: DecompressPointer r13
    //     0x8d04b8: add             x13, x13, HEAP, lsl #32
    // 0x8d04bc: r16 = Sentinel
    //     0x8d04bc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d04c0: cmp             w13, w16
    // 0x8d04c4: b.eq            #0x8d0670
    // 0x8d04c8: ubfx            x12, x12, #0, #0x20
    // 0x8d04cc: r14 = LoadInt32Instr(r13)
    //     0x8d04cc: sbfx            x14, x13, #1, #0x1f
    //     0x8d04d0: tbz             w13, #0, #0x8d04d8
    //     0x8d04d4: ldur            x14, [x13, #7]
    // 0x8d04d8: cmp             x12, x14
    // 0x8d04dc: b.gt            #0x8d0594
    // 0x8d04e0: lsl             x13, x12, #1
    // 0x8d04e4: add             x12, x13, #1
    // 0x8d04e8: ldur            x0, [fp, #-0x10]
    // 0x8d04ec: mov             x1, x12
    // 0x8d04f0: cmp             x1, x0
    // 0x8d04f4: b.hs            #0x8d067c
    // 0x8d04f8: add             x16, x3, x12, lsl #1
    // 0x8d04fc: ldurh           w14, [x16, #0x17]
    // 0x8d0500: cmp             x14, x5
    // 0x8d0504: b.eq            #0x8d058c
    // 0x8d0508: LoadField: r19 = r4->field_d3
    //     0x8d0508: ldur            w19, [x4, #0xd3]
    // 0x8d050c: DecompressPointer r19
    //     0x8d050c: add             x19, x19, HEAP, lsl #32
    // 0x8d0510: r16 = Sentinel
    //     0x8d0510: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d0514: cmp             w19, w16
    // 0x8d0518: b.eq            #0x8d0680
    // 0x8d051c: sub             x9, x5, x14
    // 0x8d0520: ldur            x0, [fp, #-0x10]
    // 0x8d0524: mov             x1, x13
    // 0x8d0528: cmp             x1, x0
    // 0x8d052c: b.hs            #0x8d068c
    // 0x8d0530: add             x16, x3, x13, lsl #1
    // 0x8d0534: ldurh           w14, [x16, #0x17]
    // 0x8d0538: mul             x13, x9, x14
    // 0x8d053c: r9 = LoadInt32Instr(r19)
    //     0x8d053c: sbfx            x9, x19, #1, #0x1f
    //     0x8d0540: tbz             w19, #0, #0x8d0548
    //     0x8d0544: ldur            x9, [x19, #7]
    // 0x8d0548: add             x14, x9, x13
    // 0x8d054c: r0 = BoxInt64Instr(r14)
    //     0x8d054c: sbfiz           x0, x14, #1, #0x1f
    //     0x8d0550: cmp             x14, x0, asr #1
    //     0x8d0554: b.eq            #0x8d0560
    //     0x8d0558: bl              #0xd69bb8
    //     0x8d055c: stur            x14, [x0, #7]
    // 0x8d0560: StoreField: r4->field_d3 = r0
    //     0x8d0560: stur            w0, [x4, #0xd3]
    //     0x8d0564: tbz             w0, #0, #0x8d0580
    //     0x8d0568: ldurb           w16, [x4, #-1]
    //     0x8d056c: ldurb           w17, [x0, #-1]
    //     0x8d0570: and             x16, x17, x16, lsr #2
    //     0x8d0574: tst             x16, HEAP, lsr #32
    //     0x8d0578: b.eq            #0x8d0580
    //     0x8d057c: bl              #0xd682cc
    // 0x8d0580: LoadField: r1 = r3->field_7
    //     0x8d0580: ldur            x1, [x3, #7]
    // 0x8d0584: add             x9, x1, x12, lsl #1
    // 0x8d0588: strh            w5, [x9]
    // 0x8d058c: sub             x1, x6, #1
    // 0x8d0590: mov             x6, x1
    // 0x8d0594: mov             x0, x8
    // 0x8d0598: b               #0x8d0488
    // 0x8d059c: sub             x1, x5, #1
    // 0x8d05a0: mov             x6, x0
    // 0x8d05a4: mov             x5, x1
    // 0x8d05a8: b               #0x8d0458
    // 0x8d05ac: r0 = Null
    //     0x8d05ac: mov             x0, NULL
    // 0x8d05b0: LeaveFrame
    //     0x8d05b0: mov             SP, fp
    //     0x8d05b4: ldp             fp, lr, [SP], #0x10
    // 0x8d05b8: ret
    //     0x8d05b8: ret             
    // 0x8d05bc: r9 = dynamicTree
    //     0x8d05bc: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b50] Field <_HuffmanTree@60040000.dynamicTree>: late (offset: 0x8)
    //     0x8d05c0: ldr             x9, [x9, #0xb50]
    // 0x8d05c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d05c4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d05c8: r9 = staticDesc
    //     0x8d05c8: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b58] Field <_HuffmanTree@60040000.staticDesc>: late (offset: 0x10)
    //     0x8d05cc: ldr             x9, [x9, #0xb58]
    // 0x8d05d0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d05d0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d05d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d05d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d05d8: b               #0x8d0040
    // 0x8d05dc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d05dc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d05e0: r9 = _heapMax
    //     0x8d05e0: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b68] Field <Deflate._heapMax@60040000>: late (offset: 0xbc)
    //     0x8d05e4: ldr             x9, [x9, #0xb68]
    // 0x8d05e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d05e8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d05ec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d05ec: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d05f0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d05f0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d05f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d05f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d05f8: b               #0x8d0128
    // 0x8d05fc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d05fc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d0600: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d0600: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d0604: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d0604: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d0608: r9 = maxCode
    //     0x8d0608: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ae0] Field <_HuffmanTree@60040000.maxCode>: late (offset: 0xc)
    //     0x8d060c: ldr             x9, [x9, #0xae0]
    // 0x8d0610: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d0610: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d0614: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d0614: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d0618: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d0618: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d061c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d061c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d0620: r9 = _optimalLen
    //     0x8d0620: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ad0] Field <Deflate._optimalLen@60040000>: late (offset: 0xd4)
    //     0x8d0624: ldr             x9, [x9, #0xad0]
    // 0x8d0628: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d0628: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d062c: r9 = _staticLen
    //     0x8d062c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ad8] Field <Deflate._staticLen@60040000>: late (offset: 0xd8)
    //     0x8d0630: ldr             x9, [x9, #0xad8]
    // 0x8d0634: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d0634: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d0638: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d0638: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d063c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d063c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d0640: b               #0x8d03a0
    // 0x8d0644: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d0644: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d0648: b               #0x8d03b0
    // 0x8d064c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d064c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d0650: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d0650: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d0654: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d0654: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d0658: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d0658: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d065c: b               #0x8d0464
    // 0x8d0660: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d0660: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d0664: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d0664: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d0668: b               #0x8d0494
    // 0x8d066c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d066c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d0670: r9 = maxCode
    //     0x8d0670: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ae0] Field <_HuffmanTree@60040000.maxCode>: late (offset: 0xc)
    //     0x8d0674: ldr             x9, [x9, #0xae0]
    // 0x8d0678: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d0678: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d067c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d067c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d0680: r9 = _optimalLen
    //     0x8d0680: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ad0] Field <Deflate._optimalLen@60040000>: late (offset: 0xd4)
    //     0x8d0684: ldr             x9, [x9, #0xad0]
    // 0x8d0688: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d0688: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d068c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d068c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 4992, size: 0x30, field offset: 0x8
class _DeflaterConfig extends Object {
}

// class id: 4993, size: 0xec, field offset: 0x8
class Deflate extends Object {

  late int _pending; // offset: 0x30
  late Uint8List _pendingBuffer; // offset: 0x24
  late int _pendingOut; // offset: 0x2c
  late int _lookAhead; // offset: 0x88
  static late _DeflaterConfig _config; // offset: 0xa84
  late Uint8List _window; // offset: 0x48
  late int _numValidBits; // offset: 0xe8
  late int _bitBuffer; // offset: 0xe4
  late int _matchAvailable; // offset: 0x78
  late int _strStart; // offset: 0x7c
  late int _insertHash; // offset: 0x58
  late int _hashShift; // offset: 0x68
  late int _hashMask; // offset: 0x64
  late Uint16List _head; // offset: 0x54
  late Uint16List _prev; // offset: 0x50
  late int _windowMask; // offset: 0x44
  late int _matchLength; // offset: 0x70
  late int _windowSize; // offset: 0x3c
  late int _strategy; // offset: 0x94
  late int _prevLength; // offset: 0x8c
  late int _blockStart; // offset: 0x6c
  late int _level; // offset: 0x90
  late int _optimalLen; // offset: 0xd4
  late int _staticLen; // offset: 0xd8
  late Uint16List _dynamicLengthTree; // offset: 0x98
  late Uint16List _dynamicDistTree; // offset: 0x9c
  late Uint16List _bitLengthTree; // offset: 0xa0
  late int _lastLit; // offset: 0xcc
  late int _dbuf; // offset: 0xd0
  late int _lbuf; // offset: 0xc4
  late int _heapLen; // offset: 0xb8
  late int _heapMax; // offset: 0xbc
  late int _matches; // offset: 0xdc
  late int _litBufferSize; // offset: 0xc8
  late int _actualWindowSize; // offset: 0x4c
  late int _hashSize; // offset: 0x5c
  late int _pendingBufferSize; // offset: 0x28

  _ getBytes(/* No info */) {
    // ** addr: 0x8cb45c, size: 0x50
    // 0x8cb45c: EnterFrame
    //     0x8cb45c: stp             fp, lr, [SP, #-0x10]!
    //     0x8cb460: mov             fp, SP
    // 0x8cb464: CheckStackOverflow
    //     0x8cb464: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cb468: cmp             SP, x16
    //     0x8cb46c: b.ls            #0x8cb4a4
    // 0x8cb470: ldr             x16, [fp, #0x10]
    // 0x8cb474: SaveReg r16
    //     0x8cb474: str             x16, [SP, #-8]!
    // 0x8cb478: r0 = _flushPending()
    //     0x8cb478: bl              #0x8cb4ac  ; [package:archive/src/zlib/deflate.dart] Deflate::_flushPending
    // 0x8cb47c: add             SP, SP, #8
    // 0x8cb480: ldr             x0, [fp, #0x10]
    // 0x8cb484: LoadField: r1 = r0->field_1b
    //     0x8cb484: ldur            w1, [x0, #0x1b]
    // 0x8cb488: DecompressPointer r1
    //     0x8cb488: add             x1, x1, HEAP, lsl #32
    // 0x8cb48c: SaveReg r1
    //     0x8cb48c: str             x1, [SP, #-8]!
    // 0x8cb490: r0 = getBytes()
    //     0x8cb490: bl              #0x815168  ; [package:archive/src/util/output_stream.dart] OutputStream::getBytes
    // 0x8cb494: add             SP, SP, #8
    // 0x8cb498: LeaveFrame
    //     0x8cb498: mov             SP, fp
    //     0x8cb49c: ldp             fp, lr, [SP], #0x10
    // 0x8cb4a0: ret
    //     0x8cb4a0: ret             
    // 0x8cb4a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cb4a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cb4a8: b               #0x8cb470
  }
  _ _flushPending(/* No info */) {
    // ** addr: 0x8cb4ac, size: 0x160
    // 0x8cb4ac: EnterFrame
    //     0x8cb4ac: stp             fp, lr, [SP, #-0x10]!
    //     0x8cb4b0: mov             fp, SP
    // 0x8cb4b4: AllocStack(0x8)
    //     0x8cb4b4: sub             SP, SP, #8
    // 0x8cb4b8: CheckStackOverflow
    //     0x8cb4b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cb4bc: cmp             SP, x16
    //     0x8cb4c0: b.ls            #0x8cb5e0
    // 0x8cb4c4: ldr             x0, [fp, #0x10]
    // 0x8cb4c8: LoadField: r1 = r0->field_2f
    //     0x8cb4c8: ldur            w1, [x0, #0x2f]
    // 0x8cb4cc: DecompressPointer r1
    //     0x8cb4cc: add             x1, x1, HEAP, lsl #32
    // 0x8cb4d0: r16 = Sentinel
    //     0x8cb4d0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cb4d4: cmp             w1, w16
    // 0x8cb4d8: b.eq            #0x8cb5e8
    // 0x8cb4dc: stur            x1, [fp, #-8]
    // 0x8cb4e0: LoadField: r2 = r0->field_1b
    //     0x8cb4e0: ldur            w2, [x0, #0x1b]
    // 0x8cb4e4: DecompressPointer r2
    //     0x8cb4e4: add             x2, x2, HEAP, lsl #32
    // 0x8cb4e8: LoadField: r3 = r0->field_23
    //     0x8cb4e8: ldur            w3, [x0, #0x23]
    // 0x8cb4ec: DecompressPointer r3
    //     0x8cb4ec: add             x3, x3, HEAP, lsl #32
    // 0x8cb4f0: r16 = Sentinel
    //     0x8cb4f0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cb4f4: cmp             w3, w16
    // 0x8cb4f8: b.eq            #0x8cb5f4
    // 0x8cb4fc: stp             x3, x2, [SP, #-0x10]!
    // 0x8cb500: SaveReg r1
    //     0x8cb500: str             x1, [SP, #-8]!
    // 0x8cb504: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x8cb504: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x8cb508: r0 = writeBytes()
    //     0x8cb508: bl              #0x815c7c  ; [package:archive/src/util/output_stream.dart] OutputStream::writeBytes
    // 0x8cb50c: add             SP, SP, #0x18
    // 0x8cb510: ldr             x2, [fp, #0x10]
    // 0x8cb514: LoadField: r3 = r2->field_2b
    //     0x8cb514: ldur            w3, [x2, #0x2b]
    // 0x8cb518: DecompressPointer r3
    //     0x8cb518: add             x3, x3, HEAP, lsl #32
    // 0x8cb51c: r16 = Sentinel
    //     0x8cb51c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cb520: cmp             w3, w16
    // 0x8cb524: b.eq            #0x8cb600
    // 0x8cb528: ldur            x4, [fp, #-8]
    // 0x8cb52c: r5 = LoadInt32Instr(r4)
    //     0x8cb52c: sbfx            x5, x4, #1, #0x1f
    //     0x8cb530: tbz             w4, #0, #0x8cb538
    //     0x8cb534: ldur            x5, [x4, #7]
    // 0x8cb538: r4 = LoadInt32Instr(r3)
    //     0x8cb538: sbfx            x4, x3, #1, #0x1f
    //     0x8cb53c: tbz             w3, #0, #0x8cb544
    //     0x8cb540: ldur            x4, [x3, #7]
    // 0x8cb544: add             x3, x4, x5
    // 0x8cb548: r0 = BoxInt64Instr(r3)
    //     0x8cb548: sbfiz           x0, x3, #1, #0x1f
    //     0x8cb54c: cmp             x3, x0, asr #1
    //     0x8cb550: b.eq            #0x8cb55c
    //     0x8cb554: bl              #0xd69bb8
    //     0x8cb558: stur            x3, [x0, #7]
    // 0x8cb55c: StoreField: r2->field_2b = r0
    //     0x8cb55c: stur            w0, [x2, #0x2b]
    //     0x8cb560: tbz             w0, #0, #0x8cb57c
    //     0x8cb564: ldurb           w16, [x2, #-1]
    //     0x8cb568: ldurb           w17, [x0, #-1]
    //     0x8cb56c: and             x16, x17, x16, lsr #2
    //     0x8cb570: tst             x16, HEAP, lsr #32
    //     0x8cb574: b.eq            #0x8cb57c
    //     0x8cb578: bl              #0xd6828c
    // 0x8cb57c: LoadField: r3 = r2->field_2f
    //     0x8cb57c: ldur            w3, [x2, #0x2f]
    // 0x8cb580: DecompressPointer r3
    //     0x8cb580: add             x3, x3, HEAP, lsl #32
    // 0x8cb584: r4 = LoadInt32Instr(r3)
    //     0x8cb584: sbfx            x4, x3, #1, #0x1f
    //     0x8cb588: tbz             w3, #0, #0x8cb590
    //     0x8cb58c: ldur            x4, [x3, #7]
    // 0x8cb590: sub             x3, x4, x5
    // 0x8cb594: r0 = BoxInt64Instr(r3)
    //     0x8cb594: sbfiz           x0, x3, #1, #0x1f
    //     0x8cb598: cmp             x3, x0, asr #1
    //     0x8cb59c: b.eq            #0x8cb5a8
    //     0x8cb5a0: bl              #0xd69bb8
    //     0x8cb5a4: stur            x3, [x0, #7]
    // 0x8cb5a8: StoreField: r2->field_2f = r0
    //     0x8cb5a8: stur            w0, [x2, #0x2f]
    //     0x8cb5ac: tbz             w0, #0, #0x8cb5c8
    //     0x8cb5b0: ldurb           w16, [x2, #-1]
    //     0x8cb5b4: ldurb           w17, [x0, #-1]
    //     0x8cb5b8: and             x16, x17, x16, lsr #2
    //     0x8cb5bc: tst             x16, HEAP, lsr #32
    //     0x8cb5c0: b.eq            #0x8cb5c8
    //     0x8cb5c4: bl              #0xd6828c
    // 0x8cb5c8: cbnz            x3, #0x8cb5d0
    // 0x8cb5cc: StoreField: r2->field_2b = rZR
    //     0x8cb5cc: stur            wzr, [x2, #0x2b]
    // 0x8cb5d0: r0 = Null
    //     0x8cb5d0: mov             x0, NULL
    // 0x8cb5d4: LeaveFrame
    //     0x8cb5d4: mov             SP, fp
    //     0x8cb5d8: ldp             fp, lr, [SP], #0x10
    // 0x8cb5dc: ret
    //     0x8cb5dc: ret             
    // 0x8cb5e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cb5e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cb5e4: b               #0x8cb4c4
    // 0x8cb5e8: r9 = _pending
    //     0x8cb5e8: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a08] Field <Deflate._pending@60040000>: late (offset: 0x30)
    //     0x8cb5ec: ldr             x9, [x9, #0xa08]
    // 0x8cb5f0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cb5f0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cb5f4: r9 = _pendingBuffer
    //     0x8cb5f4: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a10] Field <Deflate._pendingBuffer@60040000>: late (offset: 0x24)
    //     0x8cb5f8: ldr             x9, [x9, #0xa10]
    // 0x8cb5fc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cb5fc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cb600: r9 = _pendingOut
    //     0x8cb600: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a18] Field <Deflate._pendingOut@60040000>: late (offset: 0x2c)
    //     0x8cb604: ldr             x9, [x9, #0xa18]
    // 0x8cb608: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cb608: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ Deflate.buffer(/* No info */) {
    // ** addr: 0x8cb60c, size: 0x288
    // 0x8cb60c: EnterFrame
    //     0x8cb60c: stp             fp, lr, [SP, #-0x10]!
    //     0x8cb610: mov             fp, SP
    // 0x8cb614: AllocStack(0x8)
    //     0x8cb614: sub             SP, SP, #8
    // 0x8cb618: r2 = Sentinel
    //     0x8cb618: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cb61c: r1 = 0
    //     0x8cb61c: mov             x1, #0
    // 0x8cb620: r0 = 2
    //     0x8cb620: mov             x0, #2
    // 0x8cb624: CheckStackOverflow
    //     0x8cb624: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cb628: cmp             SP, x16
    //     0x8cb62c: b.ls            #0x8cb88c
    // 0x8cb630: ldr             x3, [fp, #0x20]
    // 0x8cb634: StoreField: r3->field_7 = r1
    //     0x8cb634: stur            x1, [x3, #7]
    // 0x8cb638: StoreField: r3->field_f = r1
    //     0x8cb638: stur            x1, [x3, #0xf]
    // 0x8cb63c: StoreField: r3->field_23 = r2
    //     0x8cb63c: stur            w2, [x3, #0x23]
    // 0x8cb640: StoreField: r3->field_27 = r2
    //     0x8cb640: stur            w2, [x3, #0x27]
    // 0x8cb644: StoreField: r3->field_2b = r2
    //     0x8cb644: stur            w2, [x3, #0x2b]
    // 0x8cb648: StoreField: r3->field_2f = r2
    //     0x8cb648: stur            w2, [x3, #0x2f]
    // 0x8cb64c: StoreField: r3->field_33 = r0
    //     0x8cb64c: stur            x0, [x3, #0x33]
    // 0x8cb650: StoreField: r3->field_3b = r2
    //     0x8cb650: stur            w2, [x3, #0x3b]
    // 0x8cb654: StoreField: r3->field_3f = r2
    //     0x8cb654: stur            w2, [x3, #0x3f]
    // 0x8cb658: StoreField: r3->field_43 = r2
    //     0x8cb658: stur            w2, [x3, #0x43]
    // 0x8cb65c: StoreField: r3->field_47 = r2
    //     0x8cb65c: stur            w2, [x3, #0x47]
    // 0x8cb660: StoreField: r3->field_4b = r2
    //     0x8cb660: stur            w2, [x3, #0x4b]
    // 0x8cb664: StoreField: r3->field_4f = r2
    //     0x8cb664: stur            w2, [x3, #0x4f]
    // 0x8cb668: StoreField: r3->field_53 = r2
    //     0x8cb668: stur            w2, [x3, #0x53]
    // 0x8cb66c: StoreField: r3->field_57 = r2
    //     0x8cb66c: stur            w2, [x3, #0x57]
    // 0x8cb670: StoreField: r3->field_5b = r2
    //     0x8cb670: stur            w2, [x3, #0x5b]
    // 0x8cb674: StoreField: r3->field_5f = r2
    //     0x8cb674: stur            w2, [x3, #0x5f]
    // 0x8cb678: StoreField: r3->field_63 = r2
    //     0x8cb678: stur            w2, [x3, #0x63]
    // 0x8cb67c: StoreField: r3->field_67 = r2
    //     0x8cb67c: stur            w2, [x3, #0x67]
    // 0x8cb680: StoreField: r3->field_6b = r2
    //     0x8cb680: stur            w2, [x3, #0x6b]
    // 0x8cb684: StoreField: r3->field_6f = r2
    //     0x8cb684: stur            w2, [x3, #0x6f]
    // 0x8cb688: StoreField: r3->field_73 = r2
    //     0x8cb688: stur            w2, [x3, #0x73]
    // 0x8cb68c: StoreField: r3->field_77 = r2
    //     0x8cb68c: stur            w2, [x3, #0x77]
    // 0x8cb690: StoreField: r3->field_7b = r2
    //     0x8cb690: stur            w2, [x3, #0x7b]
    // 0x8cb694: StoreField: r3->field_7f = r1
    //     0x8cb694: stur            x1, [x3, #0x7f]
    // 0x8cb698: StoreField: r3->field_87 = r2
    //     0x8cb698: stur            w2, [x3, #0x87]
    // 0x8cb69c: StoreField: r3->field_8b = r2
    //     0x8cb69c: stur            w2, [x3, #0x8b]
    // 0x8cb6a0: StoreField: r3->field_8f = r2
    //     0x8cb6a0: stur            w2, [x3, #0x8f]
    // 0x8cb6a4: StoreField: r3->field_93 = r2
    //     0x8cb6a4: stur            w2, [x3, #0x93]
    // 0x8cb6a8: StoreField: r3->field_97 = r2
    //     0x8cb6a8: stur            w2, [x3, #0x97]
    // 0x8cb6ac: StoreField: r3->field_9b = r2
    //     0x8cb6ac: stur            w2, [x3, #0x9b]
    // 0x8cb6b0: StoreField: r3->field_9f = r2
    //     0x8cb6b0: stur            w2, [x3, #0x9f]
    // 0x8cb6b4: StoreField: r3->field_b7 = r2
    //     0x8cb6b4: stur            w2, [x3, #0xb7]
    // 0x8cb6b8: StoreField: r3->field_bb = r2
    //     0x8cb6b8: stur            w2, [x3, #0xbb]
    // 0x8cb6bc: StoreField: r3->field_c3 = r2
    //     0x8cb6bc: stur            w2, [x3, #0xc3]
    // 0x8cb6c0: StoreField: r3->field_c7 = r2
    //     0x8cb6c0: stur            w2, [x3, #0xc7]
    // 0x8cb6c4: StoreField: r3->field_cb = r2
    //     0x8cb6c4: stur            w2, [x3, #0xcb]
    // 0x8cb6c8: StoreField: r3->field_cf = r2
    //     0x8cb6c8: stur            w2, [x3, #0xcf]
    // 0x8cb6cc: StoreField: r3->field_d3 = r2
    //     0x8cb6cc: stur            w2, [x3, #0xd3]
    // 0x8cb6d0: StoreField: r3->field_d7 = r2
    //     0x8cb6d0: stur            w2, [x3, #0xd7]
    // 0x8cb6d4: StoreField: r3->field_db = r2
    //     0x8cb6d4: stur            w2, [x3, #0xdb]
    // 0x8cb6d8: StoreField: r3->field_df = r2
    //     0x8cb6d8: stur            w2, [x3, #0xdf]
    // 0x8cb6dc: StoreField: r3->field_e3 = r2
    //     0x8cb6dc: stur            w2, [x3, #0xe3]
    // 0x8cb6e0: StoreField: r3->field_e7 = r2
    //     0x8cb6e0: stur            w2, [x3, #0xe7]
    // 0x8cb6e4: r0 = _HuffmanTree()
    //     0x8cb6e4: bl              #0x8d32a0  ; Allocate_HuffmanTreeStub -> _HuffmanTree (size=0x14)
    // 0x8cb6e8: r1 = Sentinel
    //     0x8cb6e8: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cb6ec: StoreField: r0->field_7 = r1
    //     0x8cb6ec: stur            w1, [x0, #7]
    // 0x8cb6f0: StoreField: r0->field_b = r1
    //     0x8cb6f0: stur            w1, [x0, #0xb]
    // 0x8cb6f4: StoreField: r0->field_f = r1
    //     0x8cb6f4: stur            w1, [x0, #0xf]
    // 0x8cb6f8: ldr             x2, [fp, #0x20]
    // 0x8cb6fc: StoreField: r2->field_a3 = r0
    //     0x8cb6fc: stur            w0, [x2, #0xa3]
    //     0x8cb700: ldurb           w16, [x2, #-1]
    //     0x8cb704: ldurb           w17, [x0, #-1]
    //     0x8cb708: and             x16, x17, x16, lsr #2
    //     0x8cb70c: tst             x16, HEAP, lsr #32
    //     0x8cb710: b.eq            #0x8cb718
    //     0x8cb714: bl              #0xd6828c
    // 0x8cb718: r0 = _HuffmanTree()
    //     0x8cb718: bl              #0x8d32a0  ; Allocate_HuffmanTreeStub -> _HuffmanTree (size=0x14)
    // 0x8cb71c: r1 = Sentinel
    //     0x8cb71c: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cb720: StoreField: r0->field_7 = r1
    //     0x8cb720: stur            w1, [x0, #7]
    // 0x8cb724: StoreField: r0->field_b = r1
    //     0x8cb724: stur            w1, [x0, #0xb]
    // 0x8cb728: StoreField: r0->field_f = r1
    //     0x8cb728: stur            w1, [x0, #0xf]
    // 0x8cb72c: ldr             x2, [fp, #0x20]
    // 0x8cb730: StoreField: r2->field_a7 = r0
    //     0x8cb730: stur            w0, [x2, #0xa7]
    //     0x8cb734: ldurb           w16, [x2, #-1]
    //     0x8cb738: ldurb           w17, [x0, #-1]
    //     0x8cb73c: and             x16, x17, x16, lsr #2
    //     0x8cb740: tst             x16, HEAP, lsr #32
    //     0x8cb744: b.eq            #0x8cb74c
    //     0x8cb748: bl              #0xd6828c
    // 0x8cb74c: r0 = _HuffmanTree()
    //     0x8cb74c: bl              #0x8d32a0  ; Allocate_HuffmanTreeStub -> _HuffmanTree (size=0x14)
    // 0x8cb750: mov             x1, x0
    // 0x8cb754: r0 = Sentinel
    //     0x8cb754: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cb758: StoreField: r1->field_7 = r0
    //     0x8cb758: stur            w0, [x1, #7]
    // 0x8cb75c: StoreField: r1->field_b = r0
    //     0x8cb75c: stur            w0, [x1, #0xb]
    // 0x8cb760: StoreField: r1->field_f = r0
    //     0x8cb760: stur            w0, [x1, #0xf]
    // 0x8cb764: mov             x0, x1
    // 0x8cb768: ldr             x1, [fp, #0x20]
    // 0x8cb76c: StoreField: r1->field_ab = r0
    //     0x8cb76c: stur            w0, [x1, #0xab]
    //     0x8cb770: ldurb           w16, [x1, #-1]
    //     0x8cb774: ldurb           w17, [x0, #-1]
    //     0x8cb778: and             x16, x17, x16, lsr #2
    //     0x8cb77c: tst             x16, HEAP, lsr #32
    //     0x8cb780: b.eq            #0x8cb788
    //     0x8cb784: bl              #0xd6826c
    // 0x8cb788: r4 = 32
    //     0x8cb788: mov             x4, #0x20
    // 0x8cb78c: r0 = AllocateUint16Array()
    //     0x8cb78c: bl              #0xd69318  ; AllocateUint16ArrayStub
    // 0x8cb790: ldr             x1, [fp, #0x20]
    // 0x8cb794: StoreField: r1->field_af = r0
    //     0x8cb794: stur            w0, [x1, #0xaf]
    //     0x8cb798: ldurb           w16, [x1, #-1]
    //     0x8cb79c: ldurb           w17, [x0, #-1]
    //     0x8cb7a0: and             x16, x17, x16, lsr #2
    //     0x8cb7a4: tst             x16, HEAP, lsr #32
    //     0x8cb7a8: b.eq            #0x8cb7b0
    //     0x8cb7ac: bl              #0xd6826c
    // 0x8cb7b0: r4 = 1146
    //     0x8cb7b0: mov             x4, #0x47a
    // 0x8cb7b4: r0 = AllocateUint32Array()
    //     0x8cb7b4: bl              #0xd691a0  ; AllocateUint32ArrayStub
    // 0x8cb7b8: ldr             x1, [fp, #0x20]
    // 0x8cb7bc: StoreField: r1->field_b3 = r0
    //     0x8cb7bc: stur            w0, [x1, #0xb3]
    //     0x8cb7c0: ldurb           w16, [x1, #-1]
    //     0x8cb7c4: ldurb           w17, [x0, #-1]
    //     0x8cb7c8: and             x16, x17, x16, lsr #2
    //     0x8cb7cc: tst             x16, HEAP, lsr #32
    //     0x8cb7d0: b.eq            #0x8cb7d8
    //     0x8cb7d4: bl              #0xd6826c
    // 0x8cb7d8: r4 = 1146
    //     0x8cb7d8: mov             x4, #0x47a
    // 0x8cb7dc: r0 = AllocateUint8Array()
    //     0x8cb7dc: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0x8cb7e0: ldr             x1, [fp, #0x20]
    // 0x8cb7e4: StoreField: r1->field_bf = r0
    //     0x8cb7e4: stur            w0, [x1, #0xbf]
    //     0x8cb7e8: ldurb           w16, [x1, #-1]
    //     0x8cb7ec: ldurb           w17, [x0, #-1]
    //     0x8cb7f0: and             x16, x17, x16, lsr #2
    //     0x8cb7f4: tst             x16, HEAP, lsr #32
    //     0x8cb7f8: b.eq            #0x8cb800
    //     0x8cb7fc: bl              #0xd6826c
    // 0x8cb800: ldr             x0, [fp, #0x18]
    // 0x8cb804: StoreField: r1->field_17 = r0
    //     0x8cb804: stur            w0, [x1, #0x17]
    //     0x8cb808: ldurb           w16, [x1, #-1]
    //     0x8cb80c: ldurb           w17, [x0, #-1]
    //     0x8cb810: and             x16, x17, x16, lsr #2
    //     0x8cb814: tst             x16, HEAP, lsr #32
    //     0x8cb818: b.eq            #0x8cb820
    //     0x8cb81c: bl              #0xd6826c
    // 0x8cb820: r0 = OutputStream()
    //     0x8cb820: bl              #0x816d88  ; AllocateOutputStreamStub -> OutputStream (size=0x1c)
    // 0x8cb824: stur            x0, [fp, #-8]
    // 0x8cb828: SaveReg r0
    //     0x8cb828: str             x0, [SP, #-8]!
    // 0x8cb82c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8cb82c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8cb830: r0 = OutputStream()
    //     0x8cb830: bl              #0x816c50  ; [package:archive/src/util/output_stream.dart] OutputStream::OutputStream
    // 0x8cb834: add             SP, SP, #8
    // 0x8cb838: ldur            x0, [fp, #-8]
    // 0x8cb83c: ldr             x1, [fp, #0x20]
    // 0x8cb840: StoreField: r1->field_1b = r0
    //     0x8cb840: stur            w0, [x1, #0x1b]
    //     0x8cb844: ldurb           w16, [x1, #-1]
    //     0x8cb848: ldurb           w17, [x0, #-1]
    //     0x8cb84c: and             x16, x17, x16, lsr #2
    //     0x8cb850: tst             x16, HEAP, lsr #32
    //     0x8cb854: b.eq            #0x8cb85c
    //     0x8cb858: bl              #0xd6826c
    // 0x8cb85c: ldr             x16, [fp, #0x10]
    // 0x8cb860: stp             x16, x1, [SP, #-0x10]!
    // 0x8cb864: r0 = _init()
    //     0x8cb864: bl              #0x8d28a0  ; [package:archive/src/zlib/deflate.dart] Deflate::_init
    // 0x8cb868: add             SP, SP, #0x10
    // 0x8cb86c: ldr             x16, [fp, #0x20]
    // 0x8cb870: SaveReg r16
    //     0x8cb870: str             x16, [SP, #-8]!
    // 0x8cb874: r0 = _deflate()
    //     0x8cb874: bl              #0x8cb894  ; [package:archive/src/zlib/deflate.dart] Deflate::_deflate
    // 0x8cb878: add             SP, SP, #8
    // 0x8cb87c: r0 = Null
    //     0x8cb87c: mov             x0, NULL
    // 0x8cb880: LeaveFrame
    //     0x8cb880: mov             SP, fp
    //     0x8cb884: ldp             fp, lr, [SP], #0x10
    // 0x8cb888: ret
    //     0x8cb888: ret             
    // 0x8cb88c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cb88c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cb890: b               #0x8cb630
  }
  _ _deflate(/* No info */) {
    // ** addr: 0x8cb894, size: 0x1f0
    // 0x8cb894: EnterFrame
    //     0x8cb894: stp             fp, lr, [SP, #-0x10]!
    //     0x8cb898: mov             fp, SP
    // 0x8cb89c: CheckStackOverflow
    //     0x8cb89c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cb8a0: cmp             SP, x16
    //     0x8cb8a4: b.ls            #0x8cba4c
    // 0x8cb8a8: ldr             x0, [fp, #0x10]
    // 0x8cb8ac: LoadField: r1 = r0->field_2f
    //     0x8cb8ac: ldur            w1, [x0, #0x2f]
    // 0x8cb8b0: DecompressPointer r1
    //     0x8cb8b0: add             x1, x1, HEAP, lsl #32
    // 0x8cb8b4: r16 = Sentinel
    //     0x8cb8b4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cb8b8: cmp             w1, w16
    // 0x8cb8bc: b.eq            #0x8cba54
    // 0x8cb8c0: r2 = LoadInt32Instr(r1)
    //     0x8cb8c0: sbfx            x2, x1, #1, #0x1f
    //     0x8cb8c4: tbz             w1, #0, #0x8cb8cc
    //     0x8cb8c8: ldur            x2, [x1, #7]
    // 0x8cb8cc: cbz             x2, #0x8cb8dc
    // 0x8cb8d0: SaveReg r0
    //     0x8cb8d0: str             x0, [SP, #-8]!
    // 0x8cb8d4: r0 = _flushPending()
    //     0x8cb8d4: bl              #0x8cb4ac  ; [package:archive/src/zlib/deflate.dart] Deflate::_flushPending
    // 0x8cb8d8: add             SP, SP, #8
    // 0x8cb8dc: ldr             x1, [fp, #0x10]
    // 0x8cb8e0: LoadField: r0 = r1->field_17
    //     0x8cb8e0: ldur            w0, [x1, #0x17]
    // 0x8cb8e4: DecompressPointer r0
    //     0x8cb8e4: add             x0, x0, HEAP, lsl #32
    // 0x8cb8e8: LoadField: r2 = r0->field_b
    //     0x8cb8e8: ldur            x2, [x0, #0xb]
    // 0x8cb8ec: LoadField: r3 = r0->field_13
    //     0x8cb8ec: ldur            x3, [x0, #0x13]
    // 0x8cb8f0: LoadField: r4 = r0->field_23
    //     0x8cb8f0: ldur            w4, [x0, #0x23]
    // 0x8cb8f4: DecompressPointer r4
    //     0x8cb8f4: add             x4, x4, HEAP, lsl #32
    // 0x8cb8f8: r16 = Sentinel
    //     0x8cb8f8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cb8fc: cmp             w4, w16
    // 0x8cb900: b.eq            #0x8cba60
    // 0x8cb904: r0 = LoadInt32Instr(r4)
    //     0x8cb904: sbfx            x0, x4, #1, #0x1f
    //     0x8cb908: tbz             w4, #0, #0x8cb910
    //     0x8cb90c: ldur            x0, [x4, #7]
    // 0x8cb910: add             x4, x3, x0
    // 0x8cb914: cmp             x2, x4
    // 0x8cb918: b.lt            #0x8cb950
    // 0x8cb91c: LoadField: r0 = r1->field_87
    //     0x8cb91c: ldur            w0, [x1, #0x87]
    // 0x8cb920: DecompressPointer r0
    //     0x8cb920: add             x0, x0, HEAP, lsl #32
    // 0x8cb924: r16 = Sentinel
    //     0x8cb924: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cb928: cmp             w0, w16
    // 0x8cb92c: b.eq            #0x8cba6c
    // 0x8cb930: r2 = LoadInt32Instr(r0)
    //     0x8cb930: sbfx            x2, x0, #1, #0x1f
    //     0x8cb934: tbz             w0, #0, #0x8cb93c
    //     0x8cb938: ldur            x2, [x0, #7]
    // 0x8cb93c: cbnz            x2, #0x8cb950
    // 0x8cb940: LoadField: r0 = r1->field_1f
    //     0x8cb940: ldur            w0, [x1, #0x1f]
    // 0x8cb944: DecompressPointer r0
    //     0x8cb944: add             x0, x0, HEAP, lsl #32
    // 0x8cb948: cmp             w0, #0x534
    // 0x8cb94c: b.eq            #0x8cba3c
    // 0x8cb950: r0 = LoadStaticField(0xa84)
    //     0x8cb950: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x8cb954: ldr             x0, [x0, #0x1508]
    //     0x8cb958: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cb95c: cmp             w0, w16
    // 0x8cb960: b.eq            #0x8cba78
    // 0x8cb964: LoadField: r2 = r0->field_27
    //     0x8cb964: ldur            x2, [x0, #0x27]
    // 0x8cb968: cmp             x2, #1
    // 0x8cb96c: b.gt            #0x8cb9a4
    // 0x8cb970: cmp             x2, #0
    // 0x8cb974: b.gt            #0x8cb990
    // 0x8cb978: lsl             x0, x2, #1
    // 0x8cb97c: cbnz            w0, #0x8cb9c4
    // 0x8cb980: SaveReg r1
    //     0x8cb980: str             x1, [SP, #-8]!
    // 0x8cb984: r0 = _deflateStored()
    //     0x8cb984: bl              #0x8d25e0  ; [package:archive/src/zlib/deflate.dart] Deflate::_deflateStored
    // 0x8cb988: add             SP, SP, #8
    // 0x8cb98c: b               #0x8cb9c8
    // 0x8cb990: ldr             x16, [fp, #0x10]
    // 0x8cb994: SaveReg r16
    //     0x8cb994: str             x16, [SP, #-8]!
    // 0x8cb998: r0 = _deflateFast()
    //     0x8cb998: bl              #0x8d19c8  ; [package:archive/src/zlib/deflate.dart] Deflate::_deflateFast
    // 0x8cb99c: add             SP, SP, #8
    // 0x8cb9a0: b               #0x8cb9c8
    // 0x8cb9a4: lsl             x0, x2, #1
    // 0x8cb9a8: cmp             w0, #4
    // 0x8cb9ac: b.ne            #0x8cb9c4
    // 0x8cb9b0: ldr             x16, [fp, #0x10]
    // 0x8cb9b4: SaveReg r16
    //     0x8cb9b4: str             x16, [SP, #-8]!
    // 0x8cb9b8: r0 = _deflateSlow()
    //     0x8cb9b8: bl              #0x8cc2ac  ; [package:archive/src/zlib/deflate.dart] Deflate::_deflateSlow
    // 0x8cb9bc: add             SP, SP, #8
    // 0x8cb9c0: b               #0x8cb9c8
    // 0x8cb9c4: r0 = -1
    //     0x8cb9c4: mov             x0, #-1
    // 0x8cb9c8: cmp             x0, #2
    // 0x8cb9cc: r16 = true
    //     0x8cb9cc: add             x16, NULL, #0x20  ; true
    // 0x8cb9d0: r17 = false
    //     0x8cb9d0: add             x17, NULL, #0x30  ; false
    // 0x8cb9d4: csel            x1, x16, x17, eq
    // 0x8cb9d8: tbz             w1, #4, #0x8cb9e4
    // 0x8cb9dc: cmp             x0, #3
    // 0x8cb9e0: b.ne            #0x8cb9f4
    // 0x8cb9e4: ldr             x2, [fp, #0x10]
    // 0x8cb9e8: r3 = 1332
    //     0x8cb9e8: mov             x3, #0x534
    // 0x8cb9ec: StoreField: r2->field_1f = r3
    //     0x8cb9ec: stur            w3, [x2, #0x1f]
    // 0x8cb9f0: b               #0x8cb9f8
    // 0x8cb9f4: ldr             x2, [fp, #0x10]
    // 0x8cb9f8: cbz             x0, #0x8cba00
    // 0x8cb9fc: tbnz            w1, #4, #0x8cba10
    // 0x8cba00: r0 = 0
    //     0x8cba00: mov             x0, #0
    // 0x8cba04: LeaveFrame
    //     0x8cba04: mov             SP, fp
    //     0x8cba08: ldp             fp, lr, [SP], #0x10
    // 0x8cba0c: ret
    //     0x8cba0c: ret             
    // 0x8cba10: cmp             x0, #1
    // 0x8cba14: b.ne            #0x8cba3c
    // 0x8cba18: stp             xzr, x2, [SP, #-0x10]!
    // 0x8cba1c: r16 = false
    //     0x8cba1c: add             x16, NULL, #0x30  ; false
    // 0x8cba20: stp             x16, xzr, [SP, #-0x10]!
    // 0x8cba24: r0 = _trStoredBlock()
    //     0x8cba24: bl              #0x8cba84  ; [package:archive/src/zlib/deflate.dart] Deflate::_trStoredBlock
    // 0x8cba28: add             SP, SP, #0x20
    // 0x8cba2c: ldr             x16, [fp, #0x10]
    // 0x8cba30: SaveReg r16
    //     0x8cba30: str             x16, [SP, #-8]!
    // 0x8cba34: r0 = _flushPending()
    //     0x8cba34: bl              #0x8cb4ac  ; [package:archive/src/zlib/deflate.dart] Deflate::_flushPending
    // 0x8cba38: add             SP, SP, #8
    // 0x8cba3c: r0 = 1
    //     0x8cba3c: mov             x0, #1
    // 0x8cba40: LeaveFrame
    //     0x8cba40: mov             SP, fp
    //     0x8cba44: ldp             fp, lr, [SP], #0x10
    // 0x8cba48: ret
    //     0x8cba48: ret             
    // 0x8cba4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cba4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cba50: b               #0x8cb8a8
    // 0x8cba54: r9 = _pending
    //     0x8cba54: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a08] Field <Deflate._pending@60040000>: late (offset: 0x30)
    //     0x8cba58: ldr             x9, [x9, #0xa08]
    // 0x8cba5c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cba5c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cba60: r9 = _length
    //     0x8cba60: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a20] Field <InputStream._length@54080104>: late (offset: 0x24)
    //     0x8cba64: ldr             x9, [x9, #0xa20]
    // 0x8cba68: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cba68: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cba6c: r9 = _lookAhead
    //     0x8cba6c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a28] Field <Deflate._lookAhead@60040000>: late (offset: 0x88)
    //     0x8cba70: ldr             x9, [x9, #0xa28]
    // 0x8cba74: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cba74: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cba78: r9 = _config
    //     0x8cba78: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a30] Field <Deflate._config@60040000>: static late (offset: 0xa84)
    //     0x8cba7c: ldr             x9, [x9, #0xa30]
    // 0x8cba80: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cba80: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _trStoredBlock(/* No info */) {
    // ** addr: 0x8cba84, size: 0x70
    // 0x8cba84: EnterFrame
    //     0x8cba84: stp             fp, lr, [SP, #-0x10]!
    //     0x8cba88: mov             fp, SP
    // 0x8cba8c: r0 = 3
    //     0x8cba8c: mov             x0, #3
    // 0x8cba90: CheckStackOverflow
    //     0x8cba90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cba94: cmp             SP, x16
    //     0x8cba98: b.ls            #0x8cbaec
    // 0x8cba9c: ldr             x1, [fp, #0x10]
    // 0x8cbaa0: tst             x1, #0x10
    // 0x8cbaa4: cset            x2, eq
    // 0x8cbaa8: lsl             x2, x2, #1
    // 0x8cbaac: ldr             x16, [fp, #0x28]
    // 0x8cbab0: stp             x2, x16, [SP, #-0x10]!
    // 0x8cbab4: SaveReg r0
    //     0x8cbab4: str             x0, [SP, #-8]!
    // 0x8cbab8: r0 = _sendBits()
    //     0x8cbab8: bl              #0x8cbef4  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendBits
    // 0x8cbabc: add             SP, SP, #0x18
    // 0x8cbac0: ldr             x16, [fp, #0x28]
    // 0x8cbac4: ldr             lr, [fp, #0x20]
    // 0x8cbac8: stp             lr, x16, [SP, #-0x10]!
    // 0x8cbacc: ldr             x0, [fp, #0x18]
    // 0x8cbad0: SaveReg r0
    //     0x8cbad0: str             x0, [SP, #-8]!
    // 0x8cbad4: r0 = _copyBlock()
    //     0x8cbad4: bl              #0x8cbaf4  ; [package:archive/src/zlib/deflate.dart] Deflate::_copyBlock
    // 0x8cbad8: add             SP, SP, #0x18
    // 0x8cbadc: r0 = Null
    //     0x8cbadc: mov             x0, NULL
    // 0x8cbae0: LeaveFrame
    //     0x8cbae0: mov             SP, fp
    //     0x8cbae4: ldp             fp, lr, [SP], #0x10
    // 0x8cbae8: ret
    //     0x8cbae8: ret             
    // 0x8cbaec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cbaec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cbaf0: b               #0x8cba9c
  }
  _ _copyBlock(/* No info */) {
    // ** addr: 0x8cbaf4, size: 0xcc
    // 0x8cbaf4: EnterFrame
    //     0x8cbaf4: stp             fp, lr, [SP, #-0x10]!
    //     0x8cbaf8: mov             fp, SP
    // 0x8cbafc: CheckStackOverflow
    //     0x8cbafc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cbb00: cmp             SP, x16
    //     0x8cbb04: b.ls            #0x8cbbac
    // 0x8cbb08: ldr             x16, [fp, #0x20]
    // 0x8cbb0c: SaveReg r16
    //     0x8cbb0c: str             x16, [SP, #-8]!
    // 0x8cbb10: r0 = _biWindup()
    //     0x8cbb10: bl              #0x8cbe04  ; [package:archive/src/zlib/deflate.dart] Deflate::_biWindup
    // 0x8cbb14: add             SP, SP, #8
    // 0x8cbb18: ldr             x1, [fp, #0x20]
    // 0x8cbb1c: r0 = 16
    //     0x8cbb1c: mov             x0, #0x10
    // 0x8cbb20: StoreField: r1->field_df = r0
    //     0x8cbb20: stur            w0, [x1, #0xdf]
    // 0x8cbb24: SaveReg r1
    //     0x8cbb24: str             x1, [SP, #-8]!
    // 0x8cbb28: ldr             x0, [fp, #0x10]
    // 0x8cbb2c: SaveReg r0
    //     0x8cbb2c: str             x0, [SP, #-8]!
    // 0x8cbb30: r0 = _putShort()
    //     0x8cbb30: bl              #0x8cbccc  ; [package:archive/src/zlib/deflate.dart] Deflate::_putShort
    // 0x8cbb34: add             SP, SP, #0x10
    // 0x8cbb38: ldr             x0, [fp, #0x10]
    // 0x8cbb3c: ubfx            x0, x0, #0, #0x20
    // 0x8cbb40: mvn             w1, w0
    // 0x8cbb44: r0 = 65536
    //     0x8cbb44: mov             x0, #0x10000
    // 0x8cbb48: add             w2, w1, w0
    // 0x8cbb4c: r0 = 65535
    //     0x8cbb4c: mov             x0, #0xffff
    // 0x8cbb50: and             x1, x2, x0
    // 0x8cbb54: ubfx            x1, x1, #0, #0x20
    // 0x8cbb58: ldr             x16, [fp, #0x20]
    // 0x8cbb5c: stp             x1, x16, [SP, #-0x10]!
    // 0x8cbb60: r0 = _putShort()
    //     0x8cbb60: bl              #0x8cbccc  ; [package:archive/src/zlib/deflate.dart] Deflate::_putShort
    // 0x8cbb64: add             SP, SP, #0x10
    // 0x8cbb68: ldr             x0, [fp, #0x20]
    // 0x8cbb6c: LoadField: r1 = r0->field_47
    //     0x8cbb6c: ldur            w1, [x0, #0x47]
    // 0x8cbb70: DecompressPointer r1
    //     0x8cbb70: add             x1, x1, HEAP, lsl #32
    // 0x8cbb74: r16 = Sentinel
    //     0x8cbb74: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cbb78: cmp             w1, w16
    // 0x8cbb7c: b.eq            #0x8cbbb4
    // 0x8cbb80: stp             x1, x0, [SP, #-0x10]!
    // 0x8cbb84: ldr             x16, [fp, #0x18]
    // 0x8cbb88: SaveReg r16
    //     0x8cbb88: str             x16, [SP, #-8]!
    // 0x8cbb8c: ldr             x0, [fp, #0x10]
    // 0x8cbb90: SaveReg r0
    //     0x8cbb90: str             x0, [SP, #-8]!
    // 0x8cbb94: r0 = _putBytes()
    //     0x8cbb94: bl              #0x8cbbc0  ; [package:archive/src/zlib/deflate.dart] Deflate::_putBytes
    // 0x8cbb98: add             SP, SP, #0x20
    // 0x8cbb9c: r0 = Null
    //     0x8cbb9c: mov             x0, NULL
    // 0x8cbba0: LeaveFrame
    //     0x8cbba0: mov             SP, fp
    //     0x8cbba4: ldp             fp, lr, [SP], #0x10
    // 0x8cbba8: ret
    //     0x8cbba8: ret             
    // 0x8cbbac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cbbac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cbbb0: b               #0x8cbb08
    // 0x8cbbb4: r9 = _window
    //     0x8cbbb4: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a38] Field <Deflate._window@60040000>: late (offset: 0x48)
    //     0x8cbbb8: ldr             x9, [x9, #0xa38]
    // 0x8cbbbc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cbbbc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _putBytes(/* No info */) {
    // ** addr: 0x8cbbc0, size: 0x10c
    // 0x8cbbc0: EnterFrame
    //     0x8cbbc0: stp             fp, lr, [SP, #-0x10]!
    //     0x8cbbc4: mov             fp, SP
    // 0x8cbbc8: CheckStackOverflow
    //     0x8cbbc8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cbbcc: cmp             SP, x16
    //     0x8cbbd0: b.ls            #0x8cbcac
    // 0x8cbbd4: ldr             x0, [fp, #0x10]
    // 0x8cbbd8: cbnz            x0, #0x8cbbec
    // 0x8cbbdc: r0 = Null
    //     0x8cbbdc: mov             x0, NULL
    // 0x8cbbe0: LeaveFrame
    //     0x8cbbe0: mov             SP, fp
    //     0x8cbbe4: ldp             fp, lr, [SP], #0x10
    // 0x8cbbe8: ret
    //     0x8cbbe8: ret             
    // 0x8cbbec: ldr             x1, [fp, #0x28]
    // 0x8cbbf0: LoadField: r2 = r1->field_23
    //     0x8cbbf0: ldur            w2, [x1, #0x23]
    // 0x8cbbf4: DecompressPointer r2
    //     0x8cbbf4: add             x2, x2, HEAP, lsl #32
    // 0x8cbbf8: r16 = Sentinel
    //     0x8cbbf8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cbbfc: cmp             w2, w16
    // 0x8cbc00: b.eq            #0x8cbcb4
    // 0x8cbc04: LoadField: r3 = r1->field_2f
    //     0x8cbc04: ldur            w3, [x1, #0x2f]
    // 0x8cbc08: DecompressPointer r3
    //     0x8cbc08: add             x3, x3, HEAP, lsl #32
    // 0x8cbc0c: r16 = Sentinel
    //     0x8cbc0c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cbc10: cmp             w3, w16
    // 0x8cbc14: b.eq            #0x8cbcc0
    // 0x8cbc18: r4 = LoadInt32Instr(r3)
    //     0x8cbc18: sbfx            x4, x3, #1, #0x1f
    //     0x8cbc1c: tbz             w3, #0, #0x8cbc24
    //     0x8cbc20: ldur            x4, [x3, #7]
    // 0x8cbc24: add             x5, x4, x0
    // 0x8cbc28: stp             x3, x2, [SP, #-0x10]!
    // 0x8cbc2c: ldr             x16, [fp, #0x20]
    // 0x8cbc30: stp             x16, x5, [SP, #-0x10]!
    // 0x8cbc34: ldr             x16, [fp, #0x18]
    // 0x8cbc38: SaveReg r16
    //     0x8cbc38: str             x16, [SP, #-8]!
    // 0x8cbc3c: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0x8cbc3c: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0x8cbc40: r0 = setRange()
    //     0x8cbc40: bl              #0x605c8c  ; [dart:typed_data] __Uint8List&_TypedList&_IntListMixin&_TypedIntListMixin::setRange
    // 0x8cbc44: add             SP, SP, #0x28
    // 0x8cbc48: ldr             x2, [fp, #0x28]
    // 0x8cbc4c: LoadField: r3 = r2->field_2f
    //     0x8cbc4c: ldur            w3, [x2, #0x2f]
    // 0x8cbc50: DecompressPointer r3
    //     0x8cbc50: add             x3, x3, HEAP, lsl #32
    // 0x8cbc54: r4 = LoadInt32Instr(r3)
    //     0x8cbc54: sbfx            x4, x3, #1, #0x1f
    //     0x8cbc58: tbz             w3, #0, #0x8cbc60
    //     0x8cbc5c: ldur            x4, [x3, #7]
    // 0x8cbc60: ldr             x3, [fp, #0x10]
    // 0x8cbc64: add             x5, x4, x3
    // 0x8cbc68: r0 = BoxInt64Instr(r5)
    //     0x8cbc68: sbfiz           x0, x5, #1, #0x1f
    //     0x8cbc6c: cmp             x5, x0, asr #1
    //     0x8cbc70: b.eq            #0x8cbc7c
    //     0x8cbc74: bl              #0xd69bb8
    //     0x8cbc78: stur            x5, [x0, #7]
    // 0x8cbc7c: StoreField: r2->field_2f = r0
    //     0x8cbc7c: stur            w0, [x2, #0x2f]
    //     0x8cbc80: tbz             w0, #0, #0x8cbc9c
    //     0x8cbc84: ldurb           w16, [x2, #-1]
    //     0x8cbc88: ldurb           w17, [x0, #-1]
    //     0x8cbc8c: and             x16, x17, x16, lsr #2
    //     0x8cbc90: tst             x16, HEAP, lsr #32
    //     0x8cbc94: b.eq            #0x8cbc9c
    //     0x8cbc98: bl              #0xd6828c
    // 0x8cbc9c: r0 = Null
    //     0x8cbc9c: mov             x0, NULL
    // 0x8cbca0: LeaveFrame
    //     0x8cbca0: mov             SP, fp
    //     0x8cbca4: ldp             fp, lr, [SP], #0x10
    // 0x8cbca8: ret
    //     0x8cbca8: ret             
    // 0x8cbcac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cbcac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cbcb0: b               #0x8cbbd4
    // 0x8cbcb4: r9 = _pendingBuffer
    //     0x8cbcb4: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a10] Field <Deflate._pendingBuffer@60040000>: late (offset: 0x24)
    //     0x8cbcb8: ldr             x9, [x9, #0xa10]
    // 0x8cbcbc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cbcbc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cbcc0: r9 = _pending
    //     0x8cbcc0: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a08] Field <Deflate._pending@60040000>: late (offset: 0x30)
    //     0x8cbcc4: ldr             x9, [x9, #0xa08]
    // 0x8cbcc8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cbcc8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _putShort(/* No info */) {
    // ** addr: 0x8cbccc, size: 0x70
    // 0x8cbccc: EnterFrame
    //     0x8cbccc: stp             fp, lr, [SP, #-0x10]!
    //     0x8cbcd0: mov             fp, SP
    // 0x8cbcd4: CheckStackOverflow
    //     0x8cbcd4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cbcd8: cmp             SP, x16
    //     0x8cbcdc: b.ls            #0x8cbd34
    // 0x8cbce0: ldr             x16, [fp, #0x18]
    // 0x8cbce4: SaveReg r16
    //     0x8cbce4: str             x16, [SP, #-8]!
    // 0x8cbce8: ldr             x0, [fp, #0x10]
    // 0x8cbcec: SaveReg r0
    //     0x8cbcec: str             x0, [SP, #-8]!
    // 0x8cbcf0: r0 = _putByte()
    //     0x8cbcf0: bl              #0x8cbd3c  ; [package:archive/src/zlib/deflate.dart] Deflate::_putByte
    // 0x8cbcf4: add             SP, SP, #0x10
    // 0x8cbcf8: ldr             x0, [fp, #0x10]
    // 0x8cbcfc: tbnz            x0, #0x3f, #0x8cbd0c
    // 0x8cbd00: asr             x1, x0, #8
    // 0x8cbd04: mov             x0, x1
    // 0x8cbd08: b               #0x8cbd14
    // 0x8cbd0c: asr             x1, x0, #8
    // 0x8cbd10: mov             x0, x1
    // 0x8cbd14: ldr             x16, [fp, #0x18]
    // 0x8cbd18: stp             x0, x16, [SP, #-0x10]!
    // 0x8cbd1c: r0 = _putByte()
    //     0x8cbd1c: bl              #0x8cbd3c  ; [package:archive/src/zlib/deflate.dart] Deflate::_putByte
    // 0x8cbd20: add             SP, SP, #0x10
    // 0x8cbd24: r0 = Null
    //     0x8cbd24: mov             x0, NULL
    // 0x8cbd28: LeaveFrame
    //     0x8cbd28: mov             SP, fp
    //     0x8cbd2c: ldp             fp, lr, [SP], #0x10
    // 0x8cbd30: ret
    //     0x8cbd30: ret             
    // 0x8cbd34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cbd34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cbd38: b               #0x8cbce0
  }
  _ _putByte(/* No info */) {
    // ** addr: 0x8cbd3c, size: 0xc8
    // 0x8cbd3c: EnterFrame
    //     0x8cbd3c: stp             fp, lr, [SP, #-0x10]!
    //     0x8cbd40: mov             fp, SP
    // 0x8cbd44: ldr             x2, [fp, #0x18]
    // 0x8cbd48: LoadField: r3 = r2->field_23
    //     0x8cbd48: ldur            w3, [x2, #0x23]
    // 0x8cbd4c: DecompressPointer r3
    //     0x8cbd4c: add             x3, x3, HEAP, lsl #32
    // 0x8cbd50: r16 = Sentinel
    //     0x8cbd50: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cbd54: cmp             w3, w16
    // 0x8cbd58: b.eq            #0x8cbde8
    // 0x8cbd5c: LoadField: r4 = r2->field_2f
    //     0x8cbd5c: ldur            w4, [x2, #0x2f]
    // 0x8cbd60: DecompressPointer r4
    //     0x8cbd60: add             x4, x4, HEAP, lsl #32
    // 0x8cbd64: r16 = Sentinel
    //     0x8cbd64: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cbd68: cmp             w4, w16
    // 0x8cbd6c: b.eq            #0x8cbdf4
    // 0x8cbd70: r5 = LoadInt32Instr(r4)
    //     0x8cbd70: sbfx            x5, x4, #1, #0x1f
    //     0x8cbd74: tbz             w4, #0, #0x8cbd7c
    //     0x8cbd78: ldur            x5, [x4, #7]
    // 0x8cbd7c: add             x4, x5, #1
    // 0x8cbd80: r0 = BoxInt64Instr(r4)
    //     0x8cbd80: sbfiz           x0, x4, #1, #0x1f
    //     0x8cbd84: cmp             x4, x0, asr #1
    //     0x8cbd88: b.eq            #0x8cbd94
    //     0x8cbd8c: bl              #0xd69bb8
    //     0x8cbd90: stur            x4, [x0, #7]
    // 0x8cbd94: StoreField: r2->field_2f = r0
    //     0x8cbd94: stur            w0, [x2, #0x2f]
    //     0x8cbd98: tbz             w0, #0, #0x8cbdb4
    //     0x8cbd9c: ldurb           w16, [x2, #-1]
    //     0x8cbda0: ldurb           w17, [x0, #-1]
    //     0x8cbda4: and             x16, x17, x16, lsr #2
    //     0x8cbda8: tst             x16, HEAP, lsr #32
    //     0x8cbdac: b.eq            #0x8cbdb4
    //     0x8cbdb0: bl              #0xd6828c
    // 0x8cbdb4: LoadField: r2 = r3->field_13
    //     0x8cbdb4: ldur            w2, [x3, #0x13]
    // 0x8cbdb8: DecompressPointer r2
    //     0x8cbdb8: add             x2, x2, HEAP, lsl #32
    // 0x8cbdbc: r0 = LoadInt32Instr(r2)
    //     0x8cbdbc: sbfx            x0, x2, #1, #0x1f
    // 0x8cbdc0: mov             x1, x5
    // 0x8cbdc4: cmp             x1, x0
    // 0x8cbdc8: b.hs            #0x8cbe00
    // 0x8cbdcc: LoadField: r1 = r3->field_7
    //     0x8cbdcc: ldur            x1, [x3, #7]
    // 0x8cbdd0: ldr             x2, [fp, #0x10]
    // 0x8cbdd4: strb            w2, [x1, x5]
    // 0x8cbdd8: r0 = Null
    //     0x8cbdd8: mov             x0, NULL
    // 0x8cbddc: LeaveFrame
    //     0x8cbddc: mov             SP, fp
    //     0x8cbde0: ldp             fp, lr, [SP], #0x10
    // 0x8cbde4: ret
    //     0x8cbde4: ret             
    // 0x8cbde8: r9 = _pendingBuffer
    //     0x8cbde8: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a10] Field <Deflate._pendingBuffer@60040000>: late (offset: 0x24)
    //     0x8cbdec: ldr             x9, [x9, #0xa10]
    // 0x8cbdf0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cbdf0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cbdf4: r9 = _pending
    //     0x8cbdf4: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a08] Field <Deflate._pending@60040000>: late (offset: 0x30)
    //     0x8cbdf8: ldr             x9, [x9, #0xa08]
    // 0x8cbdfc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cbdfc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cbe00: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cbe00: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _biWindup(/* No info */) {
    // ** addr: 0x8cbe04, size: 0xf0
    // 0x8cbe04: EnterFrame
    //     0x8cbe04: stp             fp, lr, [SP, #-0x10]!
    //     0x8cbe08: mov             fp, SP
    // 0x8cbe0c: CheckStackOverflow
    //     0x8cbe0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cbe10: cmp             SP, x16
    //     0x8cbe14: b.ls            #0x8cbec8
    // 0x8cbe18: ldr             x0, [fp, #0x10]
    // 0x8cbe1c: LoadField: r1 = r0->field_e7
    //     0x8cbe1c: ldur            w1, [x0, #0xe7]
    // 0x8cbe20: DecompressPointer r1
    //     0x8cbe20: add             x1, x1, HEAP, lsl #32
    // 0x8cbe24: r16 = Sentinel
    //     0x8cbe24: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cbe28: cmp             w1, w16
    // 0x8cbe2c: b.eq            #0x8cbed0
    // 0x8cbe30: r2 = LoadInt32Instr(r1)
    //     0x8cbe30: sbfx            x2, x1, #1, #0x1f
    //     0x8cbe34: tbz             w1, #0, #0x8cbe3c
    //     0x8cbe38: ldur            x2, [x1, #7]
    // 0x8cbe3c: cmp             x2, #8
    // 0x8cbe40: b.le            #0x8cbe74
    // 0x8cbe44: LoadField: r1 = r0->field_e3
    //     0x8cbe44: ldur            w1, [x0, #0xe3]
    // 0x8cbe48: DecompressPointer r1
    //     0x8cbe48: add             x1, x1, HEAP, lsl #32
    // 0x8cbe4c: r16 = Sentinel
    //     0x8cbe4c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cbe50: cmp             w1, w16
    // 0x8cbe54: b.eq            #0x8cbedc
    // 0x8cbe58: r2 = LoadInt32Instr(r1)
    //     0x8cbe58: sbfx            x2, x1, #1, #0x1f
    //     0x8cbe5c: tbz             w1, #0, #0x8cbe64
    //     0x8cbe60: ldur            x2, [x1, #7]
    // 0x8cbe64: stp             x2, x0, [SP, #-0x10]!
    // 0x8cbe68: r0 = _putShort()
    //     0x8cbe68: bl              #0x8cbccc  ; [package:archive/src/zlib/deflate.dart] Deflate::_putShort
    // 0x8cbe6c: add             SP, SP, #0x10
    // 0x8cbe70: b               #0x8cbeac
    // 0x8cbe74: cmp             x2, #0
    // 0x8cbe78: b.le            #0x8cbeac
    // 0x8cbe7c: ldr             x0, [fp, #0x10]
    // 0x8cbe80: LoadField: r1 = r0->field_e3
    //     0x8cbe80: ldur            w1, [x0, #0xe3]
    // 0x8cbe84: DecompressPointer r1
    //     0x8cbe84: add             x1, x1, HEAP, lsl #32
    // 0x8cbe88: r16 = Sentinel
    //     0x8cbe88: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cbe8c: cmp             w1, w16
    // 0x8cbe90: b.eq            #0x8cbee8
    // 0x8cbe94: r2 = LoadInt32Instr(r1)
    //     0x8cbe94: sbfx            x2, x1, #1, #0x1f
    //     0x8cbe98: tbz             w1, #0, #0x8cbea0
    //     0x8cbe9c: ldur            x2, [x1, #7]
    // 0x8cbea0: stp             x2, x0, [SP, #-0x10]!
    // 0x8cbea4: r0 = _putByte()
    //     0x8cbea4: bl              #0x8cbd3c  ; [package:archive/src/zlib/deflate.dart] Deflate::_putByte
    // 0x8cbea8: add             SP, SP, #0x10
    // 0x8cbeac: ldr             x1, [fp, #0x10]
    // 0x8cbeb0: StoreField: r1->field_e3 = rZR
    //     0x8cbeb0: stur            wzr, [x1, #0xe3]
    // 0x8cbeb4: StoreField: r1->field_e7 = rZR
    //     0x8cbeb4: stur            wzr, [x1, #0xe7]
    // 0x8cbeb8: r0 = Null
    //     0x8cbeb8: mov             x0, NULL
    // 0x8cbebc: LeaveFrame
    //     0x8cbebc: mov             SP, fp
    //     0x8cbec0: ldp             fp, lr, [SP], #0x10
    // 0x8cbec4: ret
    //     0x8cbec4: ret             
    // 0x8cbec8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cbec8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cbecc: b               #0x8cbe18
    // 0x8cbed0: r9 = _numValidBits
    //     0x8cbed0: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a40] Field <Deflate._numValidBits@60040000>: late (offset: 0xe8)
    //     0x8cbed4: ldr             x9, [x9, #0xa40]
    // 0x8cbed8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cbed8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cbedc: r9 = _bitBuffer
    //     0x8cbedc: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a48] Field <Deflate._bitBuffer@60040000>: late (offset: 0xe4)
    //     0x8cbee0: ldr             x9, [x9, #0xa48]
    // 0x8cbee4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cbee4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cbee8: r9 = _bitBuffer
    //     0x8cbee8: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a48] Field <Deflate._bitBuffer@60040000>: late (offset: 0xe4)
    //     0x8cbeec: ldr             x9, [x9, #0xa48]
    // 0x8cbef0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cbef0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _sendBits(/* No info */) {
    // ** addr: 0x8cbef4, size: 0x3b8
    // 0x8cbef4: EnterFrame
    //     0x8cbef4: stp             fp, lr, [SP, #-0x10]!
    //     0x8cbef8: mov             fp, SP
    // 0x8cbefc: AllocStack(0x8)
    //     0x8cbefc: sub             SP, SP, #8
    // 0x8cbf00: r2 = 16
    //     0x8cbf00: mov             x2, #0x10
    // 0x8cbf04: CheckStackOverflow
    //     0x8cbf04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cbf08: cmp             SP, x16
    //     0x8cbf0c: b.ls            #0x8cc1a8
    // 0x8cbf10: ldr             x3, [fp, #0x20]
    // 0x8cbf14: LoadField: r0 = r3->field_e7
    //     0x8cbf14: ldur            w0, [x3, #0xe7]
    // 0x8cbf18: DecompressPointer r0
    //     0x8cbf18: add             x0, x0, HEAP, lsl #32
    // 0x8cbf1c: r16 = Sentinel
    //     0x8cbf1c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cbf20: cmp             w0, w16
    // 0x8cbf24: b.eq            #0x8cc1b0
    // 0x8cbf28: ldr             x4, [fp, #0x10]
    // 0x8cbf2c: sub             x1, x2, x4
    // 0x8cbf30: r5 = LoadInt32Instr(r0)
    //     0x8cbf30: sbfx            x5, x0, #1, #0x1f
    //     0x8cbf34: tbz             w0, #0, #0x8cbf3c
    //     0x8cbf38: ldur            x5, [x0, #7]
    // 0x8cbf3c: cmp             x5, x1
    // 0x8cbf40: b.le            #0x8cc0d4
    // 0x8cbf44: ldr             x0, [fp, #0x18]
    // 0x8cbf48: r6 = 65535
    //     0x8cbf48: mov             x6, #0xffff
    // 0x8cbf4c: LoadField: r1 = r3->field_e3
    //     0x8cbf4c: ldur            w1, [x3, #0xe3]
    // 0x8cbf50: DecompressPointer r1
    //     0x8cbf50: add             x1, x1, HEAP, lsl #32
    // 0x8cbf54: r16 = Sentinel
    //     0x8cbf54: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cbf58: cmp             w1, w16
    // 0x8cbf5c: b.eq            #0x8cc1bc
    // 0x8cbf60: r7 = LoadInt32Instr(r0)
    //     0x8cbf60: sbfx            x7, x0, #1, #0x1f
    //     0x8cbf64: tbz             w0, #0, #0x8cbf6c
    //     0x8cbf68: ldur            x7, [x0, #7]
    // 0x8cbf6c: stur            x7, [fp, #-8]
    // 0x8cbf70: mov             x0, x7
    // 0x8cbf74: ubfx            x0, x0, #0, #0x20
    // 0x8cbf78: tbnz            x5, #0x3f, #0x8cc1c8
    // 0x8cbf7c: lsl             w8, w0, w5
    // 0x8cbf80: cmp             x5, #0x1f
    // 0x8cbf84: csel            x8, x8, xzr, le
    // 0x8cbf88: and             x0, x8, x6
    // 0x8cbf8c: r5 = LoadInt32Instr(r1)
    //     0x8cbf8c: sbfx            x5, x1, #1, #0x1f
    //     0x8cbf90: tbz             w1, #0, #0x8cbf98
    //     0x8cbf94: ldur            x5, [x1, #7]
    // 0x8cbf98: ubfx            x0, x0, #0, #0x20
    // 0x8cbf9c: orr             x8, x5, x0
    // 0x8cbfa0: r0 = BoxInt64Instr(r8)
    //     0x8cbfa0: sbfiz           x0, x8, #1, #0x1f
    //     0x8cbfa4: cmp             x8, x0, asr #1
    //     0x8cbfa8: b.eq            #0x8cbfb4
    //     0x8cbfac: bl              #0xd69bb8
    //     0x8cbfb0: stur            x8, [x0, #7]
    // 0x8cbfb4: StoreField: r3->field_e3 = r0
    //     0x8cbfb4: stur            w0, [x3, #0xe3]
    //     0x8cbfb8: tbz             w0, #0, #0x8cbfd4
    //     0x8cbfbc: ldurb           w16, [x3, #-1]
    //     0x8cbfc0: ldurb           w17, [x0, #-1]
    //     0x8cbfc4: and             x16, x17, x16, lsr #2
    //     0x8cbfc8: tst             x16, HEAP, lsr #32
    //     0x8cbfcc: b.eq            #0x8cbfd4
    //     0x8cbfd0: bl              #0xd682ac
    // 0x8cbfd4: stp             x8, x3, [SP, #-0x10]!
    // 0x8cbfd8: r0 = _putShort()
    //     0x8cbfd8: bl              #0x8cbccc  ; [package:archive/src/zlib/deflate.dart] Deflate::_putShort
    // 0x8cbfdc: add             SP, SP, #0x10
    // 0x8cbfe0: ldr             x2, [fp, #0x20]
    // 0x8cbfe4: LoadField: r3 = r2->field_e7
    //     0x8cbfe4: ldur            w3, [x2, #0xe7]
    // 0x8cbfe8: DecompressPointer r3
    //     0x8cbfe8: add             x3, x3, HEAP, lsl #32
    // 0x8cbfec: r4 = LoadInt32Instr(r3)
    //     0x8cbfec: sbfx            x4, x3, #1, #0x1f
    //     0x8cbff0: tbz             w3, #0, #0x8cbff8
    //     0x8cbff4: ldur            x4, [x3, #7]
    // 0x8cbff8: r3 = 16
    //     0x8cbff8: mov             x3, #0x10
    // 0x8cbffc: sub             x6, x3, x4
    // 0x8cc000: ldur            x3, [fp, #-8]
    // 0x8cc004: tbnz            x3, #0x3f, #0x8cc01c
    // 0x8cc008: cmp             x6, #0x3f
    // 0x8cc00c: b.hi            #0x8cc1f0
    // 0x8cc010: asr             x7, x3, x6
    // 0x8cc014: mov             x6, x7
    // 0x8cc018: b               #0x8cc05c
    // 0x8cc01c: r10 = 2
    //     0x8cc01c: mov             x10, #2
    // 0x8cc020: r7 = 65535
    //     0x8cc020: mov             x7, #0xffff
    // 0x8cc024: r8 = 65536
    //     0x8cc024: mov             x8, #0x10000
    // 0x8cc028: mov             x11, x6
    // 0x8cc02c: ubfx            x11, x11, #0, #0x20
    // 0x8cc030: mvn             w12, w11
    // 0x8cc034: add             w11, w12, w8
    // 0x8cc038: and             x8, x11, x7
    // 0x8cc03c: cmp             x6, #0x3f
    // 0x8cc040: b.hi            #0x8cc21c
    // 0x8cc044: asr             x11, x3, x6
    // 0x8cc048: ubfx            x8, x8, #0, #0x20
    // 0x8cc04c: cmp             x8, #0x3f
    // 0x8cc050: b.hi            #0x8cc24c
    // 0x8cc054: lsl             x3, x10, x8
    // 0x8cc058: add             x6, x11, x3
    // 0x8cc05c: ldr             x3, [fp, #0x10]
    // 0x8cc060: r0 = BoxInt64Instr(r6)
    //     0x8cc060: sbfiz           x0, x6, #1, #0x1f
    //     0x8cc064: cmp             x6, x0, asr #1
    //     0x8cc068: b.eq            #0x8cc074
    //     0x8cc06c: bl              #0xd69bb8
    //     0x8cc070: stur            x6, [x0, #7]
    // 0x8cc074: StoreField: r2->field_e3 = r0
    //     0x8cc074: stur            w0, [x2, #0xe3]
    //     0x8cc078: tbz             w0, #0, #0x8cc094
    //     0x8cc07c: ldurb           w16, [x2, #-1]
    //     0x8cc080: ldurb           w17, [x0, #-1]
    //     0x8cc084: and             x16, x17, x16, lsr #2
    //     0x8cc088: tst             x16, HEAP, lsr #32
    //     0x8cc08c: b.eq            #0x8cc094
    //     0x8cc090: bl              #0xd6828c
    // 0x8cc094: sub             x6, x3, #0x10
    // 0x8cc098: add             x8, x4, x6
    // 0x8cc09c: r0 = BoxInt64Instr(r8)
    //     0x8cc09c: sbfiz           x0, x8, #1, #0x1f
    //     0x8cc0a0: cmp             x8, x0, asr #1
    //     0x8cc0a4: b.eq            #0x8cc0b0
    //     0x8cc0a8: bl              #0xd69bb8
    //     0x8cc0ac: stur            x8, [x0, #7]
    // 0x8cc0b0: StoreField: r2->field_e7 = r0
    //     0x8cc0b0: stur            w0, [x2, #0xe7]
    //     0x8cc0b4: tbz             w0, #0, #0x8cc0d0
    //     0x8cc0b8: ldurb           w16, [x2, #-1]
    //     0x8cc0bc: ldurb           w17, [x0, #-1]
    //     0x8cc0c0: and             x16, x17, x16, lsr #2
    //     0x8cc0c4: tst             x16, HEAP, lsr #32
    //     0x8cc0c8: b.eq            #0x8cc0d0
    //     0x8cc0cc: bl              #0xd6828c
    // 0x8cc0d0: b               #0x8cc198
    // 0x8cc0d4: mov             x2, x3
    // 0x8cc0d8: ldr             x0, [fp, #0x18]
    // 0x8cc0dc: mov             x3, x4
    // 0x8cc0e0: r7 = 65535
    //     0x8cc0e0: mov             x7, #0xffff
    // 0x8cc0e4: LoadField: r4 = r2->field_e3
    //     0x8cc0e4: ldur            w4, [x2, #0xe3]
    // 0x8cc0e8: DecompressPointer r4
    //     0x8cc0e8: add             x4, x4, HEAP, lsl #32
    // 0x8cc0ec: r16 = Sentinel
    //     0x8cc0ec: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cc0f0: cmp             w4, w16
    // 0x8cc0f4: b.eq            #0x8cc27c
    // 0x8cc0f8: r6 = LoadInt32Instr(r0)
    //     0x8cc0f8: sbfx            x6, x0, #1, #0x1f
    //     0x8cc0fc: tbz             w0, #0, #0x8cc104
    //     0x8cc100: ldur            x6, [x0, #7]
    // 0x8cc104: tbnz            x5, #0x3f, #0x8cc288
    // 0x8cc108: lsl             w8, w6, w5
    // 0x8cc10c: cmp             x5, #0x1f
    // 0x8cc110: csel            x8, x8, xzr, le
    // 0x8cc114: and             x6, x8, x7
    // 0x8cc118: r7 = LoadInt32Instr(r4)
    //     0x8cc118: sbfx            x7, x4, #1, #0x1f
    //     0x8cc11c: tbz             w4, #0, #0x8cc124
    //     0x8cc120: ldur            x7, [x4, #7]
    // 0x8cc124: ubfx            x6, x6, #0, #0x20
    // 0x8cc128: orr             x4, x7, x6
    // 0x8cc12c: r0 = BoxInt64Instr(r4)
    //     0x8cc12c: sbfiz           x0, x4, #1, #0x1f
    //     0x8cc130: cmp             x4, x0, asr #1
    //     0x8cc134: b.eq            #0x8cc140
    //     0x8cc138: bl              #0xd69bb8
    //     0x8cc13c: stur            x4, [x0, #7]
    // 0x8cc140: StoreField: r2->field_e3 = r0
    //     0x8cc140: stur            w0, [x2, #0xe3]
    //     0x8cc144: tbz             w0, #0, #0x8cc160
    //     0x8cc148: ldurb           w16, [x2, #-1]
    //     0x8cc14c: ldurb           w17, [x0, #-1]
    //     0x8cc150: and             x16, x17, x16, lsr #2
    //     0x8cc154: tst             x16, HEAP, lsr #32
    //     0x8cc158: b.eq            #0x8cc160
    //     0x8cc15c: bl              #0xd6828c
    // 0x8cc160: add             x4, x5, x3
    // 0x8cc164: r0 = BoxInt64Instr(r4)
    //     0x8cc164: sbfiz           x0, x4, #1, #0x1f
    //     0x8cc168: cmp             x4, x0, asr #1
    //     0x8cc16c: b.eq            #0x8cc178
    //     0x8cc170: bl              #0xd69bb8
    //     0x8cc174: stur            x4, [x0, #7]
    // 0x8cc178: StoreField: r2->field_e7 = r0
    //     0x8cc178: stur            w0, [x2, #0xe7]
    //     0x8cc17c: tbz             w0, #0, #0x8cc198
    //     0x8cc180: ldurb           w16, [x2, #-1]
    //     0x8cc184: ldurb           w17, [x0, #-1]
    //     0x8cc188: and             x16, x17, x16, lsr #2
    //     0x8cc18c: tst             x16, HEAP, lsr #32
    //     0x8cc190: b.eq            #0x8cc198
    //     0x8cc194: bl              #0xd6828c
    // 0x8cc198: r0 = Null
    //     0x8cc198: mov             x0, NULL
    // 0x8cc19c: LeaveFrame
    //     0x8cc19c: mov             SP, fp
    //     0x8cc1a0: ldp             fp, lr, [SP], #0x10
    // 0x8cc1a4: ret
    //     0x8cc1a4: ret             
    // 0x8cc1a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cc1a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cc1ac: b               #0x8cbf10
    // 0x8cc1b0: r9 = _numValidBits
    //     0x8cc1b0: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a40] Field <Deflate._numValidBits@60040000>: late (offset: 0xe8)
    //     0x8cc1b4: ldr             x9, [x9, #0xa40]
    // 0x8cc1b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cc1b8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cc1bc: r9 = _bitBuffer
    //     0x8cc1bc: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a48] Field <Deflate._bitBuffer@60040000>: late (offset: 0xe4)
    //     0x8cc1c0: ldr             x9, [x9, #0xa48]
    // 0x8cc1c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cc1c4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cc1c8: str             x5, [THR, #0xc0]  ; THR::
    // 0x8cc1cc: stp             x6, x7, [SP, #-0x10]!
    // 0x8cc1d0: stp             x4, x5, [SP, #-0x10]!
    // 0x8cc1d4: stp             x2, x3, [SP, #-0x10]!
    // 0x8cc1d8: stp             x0, x1, [SP, #-0x10]!
    // 0x8cc1dc: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x8cc1e0: r4 = 0
    //     0x8cc1e0: mov             x4, #0
    // 0x8cc1e4: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8cc1e8: blr             lr
    // 0x8cc1ec: brk             #0
    // 0x8cc1f0: tbnz            x6, #0x3f, #0x8cc1fc
    // 0x8cc1f4: asr             x7, x3, #0x3f
    // 0x8cc1f8: b               #0x8cc014
    // 0x8cc1fc: str             x6, [THR, #0xc0]  ; THR::
    // 0x8cc200: stp             x4, x6, [SP, #-0x10]!
    // 0x8cc204: stp             x2, x3, [SP, #-0x10]!
    // 0x8cc208: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x8cc20c: r4 = 0
    //     0x8cc20c: mov             x4, #0
    // 0x8cc210: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8cc214: blr             lr
    // 0x8cc218: brk             #0
    // 0x8cc21c: tbnz            x6, #0x3f, #0x8cc228
    // 0x8cc220: asr             x11, x3, #0x3f
    // 0x8cc224: b               #0x8cc048
    // 0x8cc228: str             x6, [THR, #0xc0]  ; THR::
    // 0x8cc22c: stp             x8, x10, [SP, #-0x10]!
    // 0x8cc230: stp             x4, x6, [SP, #-0x10]!
    // 0x8cc234: stp             x2, x3, [SP, #-0x10]!
    // 0x8cc238: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x8cc23c: r4 = 0
    //     0x8cc23c: mov             x4, #0
    // 0x8cc240: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8cc244: blr             lr
    // 0x8cc248: brk             #0
    // 0x8cc24c: tbnz            x8, #0x3f, #0x8cc258
    // 0x8cc250: mov             x3, xzr
    // 0x8cc254: b               #0x8cc058
    // 0x8cc258: str             x8, [THR, #0xc0]  ; THR::
    // 0x8cc25c: stp             x10, x11, [SP, #-0x10]!
    // 0x8cc260: stp             x4, x8, [SP, #-0x10]!
    // 0x8cc264: SaveReg r2
    //     0x8cc264: str             x2, [SP, #-8]!
    // 0x8cc268: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x8cc26c: r4 = 0
    //     0x8cc26c: mov             x4, #0
    // 0x8cc270: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8cc274: blr             lr
    // 0x8cc278: brk             #0
    // 0x8cc27c: r9 = _bitBuffer
    //     0x8cc27c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a48] Field <Deflate._bitBuffer@60040000>: late (offset: 0xe4)
    //     0x8cc280: ldr             x9, [x9, #0xa48]
    // 0x8cc284: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cc284: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cc288: str             x5, [THR, #0xc0]  ; THR::
    // 0x8cc28c: stp             x6, x7, [SP, #-0x10]!
    // 0x8cc290: stp             x4, x5, [SP, #-0x10]!
    // 0x8cc294: stp             x2, x3, [SP, #-0x10]!
    // 0x8cc298: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x8cc29c: r4 = 0
    //     0x8cc29c: mov             x4, #0
    // 0x8cc2a0: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8cc2a4: blr             lr
    // 0x8cc2a8: brk             #0
  }
  _ _deflateSlow(/* No info */) {
    // ** addr: 0x8cc2ac, size: 0xd60
    // 0x8cc2ac: EnterFrame
    //     0x8cc2ac: stp             fp, lr, [SP, #-0x10]!
    //     0x8cc2b0: mov             fp, SP
    // 0x8cc2b4: AllocStack(0x18)
    //     0x8cc2b4: sub             SP, SP, #0x18
    // 0x8cc2b8: CheckStackOverflow
    //     0x8cc2b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cc2bc: cmp             SP, x16
    //     0x8cc2c0: b.ls            #0x8cce10
    // 0x8cc2c4: ldr             x0, [fp, #0x10]
    // 0x8cc2c8: r1 = 0
    //     0x8cc2c8: mov             x1, #0
    // 0x8cc2cc: stur            x1, [fp, #-8]
    // 0x8cc2d0: CheckStackOverflow
    //     0x8cc2d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cc2d4: cmp             SP, x16
    //     0x8cc2d8: b.ls            #0x8cce18
    // 0x8cc2dc: LoadField: r2 = r0->field_87
    //     0x8cc2dc: ldur            w2, [x0, #0x87]
    // 0x8cc2e0: DecompressPointer r2
    //     0x8cc2e0: add             x2, x2, HEAP, lsl #32
    // 0x8cc2e4: r16 = Sentinel
    //     0x8cc2e4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cc2e8: cmp             w2, w16
    // 0x8cc2ec: b.eq            #0x8cce20
    // 0x8cc2f0: r3 = LoadInt32Instr(r2)
    //     0x8cc2f0: sbfx            x3, x2, #1, #0x1f
    //     0x8cc2f4: tbz             w2, #0, #0x8cc2fc
    //     0x8cc2f8: ldur            x3, [x2, #7]
    // 0x8cc2fc: cmp             x3, #0x106
    // 0x8cc300: b.ge            #0x8cc40c
    // 0x8cc304: SaveReg r0
    //     0x8cc304: str             x0, [SP, #-8]!
    // 0x8cc308: r0 = _fillWindow()
    //     0x8cc308: bl              #0x8d1120  ; [package:archive/src/zlib/deflate.dart] Deflate::_fillWindow
    // 0x8cc30c: add             SP, SP, #8
    // 0x8cc310: ldr             x2, [fp, #0x10]
    // 0x8cc314: LoadField: r0 = r2->field_87
    //     0x8cc314: ldur            w0, [x2, #0x87]
    // 0x8cc318: DecompressPointer r0
    //     0x8cc318: add             x0, x0, HEAP, lsl #32
    // 0x8cc31c: r1 = LoadInt32Instr(r0)
    //     0x8cc31c: sbfx            x1, x0, #1, #0x1f
    //     0x8cc320: tbz             w0, #0, #0x8cc328
    //     0x8cc324: ldur            x1, [x0, #7]
    // 0x8cc328: cbnz            x1, #0x8cc3f0
    // 0x8cc32c: LoadField: r0 = r2->field_77
    //     0x8cc32c: ldur            w0, [x2, #0x77]
    // 0x8cc330: DecompressPointer r0
    //     0x8cc330: add             x0, x0, HEAP, lsl #32
    // 0x8cc334: r16 = Sentinel
    //     0x8cc334: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cc338: cmp             w0, w16
    // 0x8cc33c: b.eq            #0x8cce2c
    // 0x8cc340: cbz             w0, #0x8cc3cc
    // 0x8cc344: r3 = 255
    //     0x8cc344: mov             x3, #0xff
    // 0x8cc348: LoadField: r4 = r2->field_47
    //     0x8cc348: ldur            w4, [x2, #0x47]
    // 0x8cc34c: DecompressPointer r4
    //     0x8cc34c: add             x4, x4, HEAP, lsl #32
    // 0x8cc350: r16 = Sentinel
    //     0x8cc350: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cc354: cmp             w4, w16
    // 0x8cc358: b.eq            #0x8cce38
    // 0x8cc35c: LoadField: r0 = r2->field_7b
    //     0x8cc35c: ldur            w0, [x2, #0x7b]
    // 0x8cc360: DecompressPointer r0
    //     0x8cc360: add             x0, x0, HEAP, lsl #32
    // 0x8cc364: r16 = Sentinel
    //     0x8cc364: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cc368: cmp             w0, w16
    // 0x8cc36c: b.eq            #0x8cce44
    // 0x8cc370: r1 = LoadInt32Instr(r0)
    //     0x8cc370: sbfx            x1, x0, #1, #0x1f
    //     0x8cc374: tbz             w0, #0, #0x8cc37c
    //     0x8cc378: ldur            x1, [x0, #7]
    // 0x8cc37c: sub             x5, x1, #1
    // 0x8cc380: LoadField: r0 = r4->field_13
    //     0x8cc380: ldur            w0, [x4, #0x13]
    // 0x8cc384: DecompressPointer r0
    //     0x8cc384: add             x0, x0, HEAP, lsl #32
    // 0x8cc388: r1 = LoadInt32Instr(r0)
    //     0x8cc388: sbfx            x1, x0, #1, #0x1f
    // 0x8cc38c: mov             x0, x1
    // 0x8cc390: mov             x1, x5
    // 0x8cc394: cmp             x1, x0
    // 0x8cc398: b.hs            #0x8cce50
    // 0x8cc39c: ArrayLoad: r0 = r4[r5]  ; TypedUnsigned_1
    //     0x8cc39c: add             x16, x4, x5
    //     0x8cc3a0: ldrb            w0, [x16, #0x17]
    // 0x8cc3a4: ubfx            x0, x0, #0, #0x20
    // 0x8cc3a8: and             x1, x0, x3
    // 0x8cc3ac: ubfx            x1, x1, #0, #0x20
    // 0x8cc3b0: stp             xzr, x2, [SP, #-0x10]!
    // 0x8cc3b4: SaveReg r1
    //     0x8cc3b4: str             x1, [SP, #-8]!
    // 0x8cc3b8: r0 = _trTally()
    //     0x8cc3b8: bl              #0x8d0b30  ; [package:archive/src/zlib/deflate.dart] Deflate::_trTally
    // 0x8cc3bc: add             SP, SP, #0x18
    // 0x8cc3c0: ldr             x4, [fp, #0x10]
    // 0x8cc3c4: StoreField: r4->field_77 = rZR
    //     0x8cc3c4: stur            wzr, [x4, #0x77]
    // 0x8cc3c8: b               #0x8cc3d0
    // 0x8cc3cc: mov             x4, x2
    // 0x8cc3d0: r16 = true
    //     0x8cc3d0: add             x16, NULL, #0x20  ; true
    // 0x8cc3d4: stp             x16, x4, [SP, #-0x10]!
    // 0x8cc3d8: r0 = _flushBlockOnly()
    //     0x8cc3d8: bl              #0x8cd6d8  ; [package:archive/src/zlib/deflate.dart] Deflate::_flushBlockOnly
    // 0x8cc3dc: add             SP, SP, #0x10
    // 0x8cc3e0: r0 = 3
    //     0x8cc3e0: mov             x0, #3
    // 0x8cc3e4: LeaveFrame
    //     0x8cc3e4: mov             SP, fp
    //     0x8cc3e8: ldp             fp, lr, [SP], #0x10
    // 0x8cc3ec: ret
    //     0x8cc3ec: ret             
    // 0x8cc3f0: mov             x4, x2
    // 0x8cc3f4: r3 = 255
    //     0x8cc3f4: mov             x3, #0xff
    // 0x8cc3f8: r1 = LoadInt32Instr(r0)
    //     0x8cc3f8: sbfx            x1, x0, #1, #0x1f
    //     0x8cc3fc: tbz             w0, #0, #0x8cc404
    //     0x8cc400: ldur            x1, [x0, #7]
    // 0x8cc404: mov             x0, x1
    // 0x8cc408: b               #0x8cc420
    // 0x8cc40c: mov             x4, x0
    // 0x8cc410: r3 = 255
    //     0x8cc410: mov             x3, #0xff
    // 0x8cc414: r0 = LoadInt32Instr(r2)
    //     0x8cc414: sbfx            x0, x2, #1, #0x1f
    //     0x8cc418: tbz             w2, #0, #0x8cc420
    //     0x8cc41c: ldur            x0, [x2, #7]
    // 0x8cc420: cmp             x0, #3
    // 0x8cc424: b.lt            #0x8cc5f8
    // 0x8cc428: r2 = 65535
    //     0x8cc428: mov             x2, #0xffff
    // 0x8cc42c: LoadField: r0 = r4->field_57
    //     0x8cc42c: ldur            w0, [x4, #0x57]
    // 0x8cc430: DecompressPointer r0
    //     0x8cc430: add             x0, x0, HEAP, lsl #32
    // 0x8cc434: r16 = Sentinel
    //     0x8cc434: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cc438: cmp             w0, w16
    // 0x8cc43c: b.eq            #0x8cce54
    // 0x8cc440: LoadField: r1 = r4->field_67
    //     0x8cc440: ldur            w1, [x4, #0x67]
    // 0x8cc444: DecompressPointer r1
    //     0x8cc444: add             x1, x1, HEAP, lsl #32
    // 0x8cc448: r16 = Sentinel
    //     0x8cc448: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cc44c: cmp             w1, w16
    // 0x8cc450: b.eq            #0x8cce60
    // 0x8cc454: r5 = LoadInt32Instr(r0)
    //     0x8cc454: sbfx            x5, x0, #1, #0x1f
    //     0x8cc458: tbz             w0, #0, #0x8cc460
    //     0x8cc45c: ldur            x5, [x0, #7]
    // 0x8cc460: r0 = LoadInt32Instr(r1)
    //     0x8cc460: sbfx            x0, x1, #1, #0x1f
    //     0x8cc464: tbz             w1, #0, #0x8cc46c
    //     0x8cc468: ldur            x0, [x1, #7]
    // 0x8cc46c: cmp             x0, #0x3f
    // 0x8cc470: b.hi            #0x8cce6c
    // 0x8cc474: lsl             x6, x5, x0
    // 0x8cc478: LoadField: r5 = r4->field_47
    //     0x8cc478: ldur            w5, [x4, #0x47]
    // 0x8cc47c: DecompressPointer r5
    //     0x8cc47c: add             x5, x5, HEAP, lsl #32
    // 0x8cc480: r16 = Sentinel
    //     0x8cc480: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cc484: cmp             w5, w16
    // 0x8cc488: b.eq            #0x8cce9c
    // 0x8cc48c: LoadField: r0 = r4->field_7b
    //     0x8cc48c: ldur            w0, [x4, #0x7b]
    // 0x8cc490: DecompressPointer r0
    //     0x8cc490: add             x0, x0, HEAP, lsl #32
    // 0x8cc494: r16 = Sentinel
    //     0x8cc494: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cc498: cmp             w0, w16
    // 0x8cc49c: b.eq            #0x8ccea8
    // 0x8cc4a0: r7 = LoadInt32Instr(r0)
    //     0x8cc4a0: sbfx            x7, x0, #1, #0x1f
    //     0x8cc4a4: tbz             w0, #0, #0x8cc4ac
    //     0x8cc4a8: ldur            x7, [x0, #7]
    // 0x8cc4ac: add             x8, x7, #2
    // 0x8cc4b0: LoadField: r0 = r5->field_13
    //     0x8cc4b0: ldur            w0, [x5, #0x13]
    // 0x8cc4b4: DecompressPointer r0
    //     0x8cc4b4: add             x0, x0, HEAP, lsl #32
    // 0x8cc4b8: r1 = LoadInt32Instr(r0)
    //     0x8cc4b8: sbfx            x1, x0, #1, #0x1f
    // 0x8cc4bc: mov             x0, x1
    // 0x8cc4c0: mov             x1, x8
    // 0x8cc4c4: cmp             x1, x0
    // 0x8cc4c8: b.hs            #0x8cceb4
    // 0x8cc4cc: ArrayLoad: r0 = r5[r8]  ; TypedUnsigned_1
    //     0x8cc4cc: add             x16, x5, x8
    //     0x8cc4d0: ldrb            w0, [x16, #0x17]
    // 0x8cc4d4: ubfx            x0, x0, #0, #0x20
    // 0x8cc4d8: and             x1, x0, x3
    // 0x8cc4dc: ubfx            x1, x1, #0, #0x20
    // 0x8cc4e0: eor             x0, x6, x1
    // 0x8cc4e4: LoadField: r1 = r4->field_63
    //     0x8cc4e4: ldur            w1, [x4, #0x63]
    // 0x8cc4e8: DecompressPointer r1
    //     0x8cc4e8: add             x1, x1, HEAP, lsl #32
    // 0x8cc4ec: r16 = Sentinel
    //     0x8cc4ec: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cc4f0: cmp             w1, w16
    // 0x8cc4f4: b.eq            #0x8cceb8
    // 0x8cc4f8: r5 = LoadInt32Instr(r1)
    //     0x8cc4f8: sbfx            x5, x1, #1, #0x1f
    //     0x8cc4fc: tbz             w1, #0, #0x8cc504
    //     0x8cc500: ldur            x5, [x1, #7]
    // 0x8cc504: and             x6, x0, x5
    // 0x8cc508: r0 = BoxInt64Instr(r6)
    //     0x8cc508: sbfiz           x0, x6, #1, #0x1f
    //     0x8cc50c: cmp             x6, x0, asr #1
    //     0x8cc510: b.eq            #0x8cc51c
    //     0x8cc514: bl              #0xd69bb8
    //     0x8cc518: stur            x6, [x0, #7]
    // 0x8cc51c: StoreField: r4->field_57 = r0
    //     0x8cc51c: stur            w0, [x4, #0x57]
    //     0x8cc520: tbz             w0, #0, #0x8cc53c
    //     0x8cc524: ldurb           w16, [x4, #-1]
    //     0x8cc528: ldurb           w17, [x0, #-1]
    //     0x8cc52c: and             x16, x17, x16, lsr #2
    //     0x8cc530: tst             x16, HEAP, lsr #32
    //     0x8cc534: b.eq            #0x8cc53c
    //     0x8cc538: bl              #0xd682cc
    // 0x8cc53c: LoadField: r5 = r4->field_53
    //     0x8cc53c: ldur            w5, [x4, #0x53]
    // 0x8cc540: DecompressPointer r5
    //     0x8cc540: add             x5, x5, HEAP, lsl #32
    // 0x8cc544: r16 = Sentinel
    //     0x8cc544: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cc548: cmp             w5, w16
    // 0x8cc54c: b.eq            #0x8ccec4
    // 0x8cc550: LoadField: r0 = r5->field_13
    //     0x8cc550: ldur            w0, [x5, #0x13]
    // 0x8cc554: DecompressPointer r0
    //     0x8cc554: add             x0, x0, HEAP, lsl #32
    // 0x8cc558: r1 = LoadInt32Instr(r0)
    //     0x8cc558: sbfx            x1, x0, #1, #0x1f
    // 0x8cc55c: mov             x0, x1
    // 0x8cc560: mov             x1, x6
    // 0x8cc564: cmp             x1, x0
    // 0x8cc568: b.hs            #0x8cced0
    // 0x8cc56c: add             x16, x5, x6, lsl #1
    // 0x8cc570: ldurh           w8, [x16, #0x17]
    // 0x8cc574: mov             x0, x8
    // 0x8cc578: ubfx            x0, x0, #0, #0x20
    // 0x8cc57c: and             x10, x0, x2
    // 0x8cc580: LoadField: r11 = r4->field_4f
    //     0x8cc580: ldur            w11, [x4, #0x4f]
    // 0x8cc584: DecompressPointer r11
    //     0x8cc584: add             x11, x11, HEAP, lsl #32
    // 0x8cc588: r16 = Sentinel
    //     0x8cc588: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cc58c: cmp             w11, w16
    // 0x8cc590: b.eq            #0x8cced4
    // 0x8cc594: LoadField: r0 = r4->field_43
    //     0x8cc594: ldur            w0, [x4, #0x43]
    // 0x8cc598: DecompressPointer r0
    //     0x8cc598: add             x0, x0, HEAP, lsl #32
    // 0x8cc59c: r16 = Sentinel
    //     0x8cc59c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cc5a0: cmp             w0, w16
    // 0x8cc5a4: b.eq            #0x8ccee0
    // 0x8cc5a8: r1 = LoadInt32Instr(r0)
    //     0x8cc5a8: sbfx            x1, x0, #1, #0x1f
    //     0x8cc5ac: tbz             w0, #0, #0x8cc5b4
    //     0x8cc5b0: ldur            x1, [x0, #7]
    // 0x8cc5b4: and             x9, x7, x1
    // 0x8cc5b8: LoadField: r0 = r11->field_13
    //     0x8cc5b8: ldur            w0, [x11, #0x13]
    // 0x8cc5bc: DecompressPointer r0
    //     0x8cc5bc: add             x0, x0, HEAP, lsl #32
    // 0x8cc5c0: r1 = LoadInt32Instr(r0)
    //     0x8cc5c0: sbfx            x1, x0, #1, #0x1f
    // 0x8cc5c4: mov             x0, x1
    // 0x8cc5c8: mov             x1, x9
    // 0x8cc5cc: cmp             x1, x0
    // 0x8cc5d0: b.hs            #0x8cceec
    // 0x8cc5d4: LoadField: r0 = r11->field_7
    //     0x8cc5d4: ldur            x0, [x11, #7]
    // 0x8cc5d8: add             x1, x0, x9, lsl #1
    // 0x8cc5dc: strh            w8, [x1]
    // 0x8cc5e0: LoadField: r0 = r5->field_7
    //     0x8cc5e0: ldur            x0, [x5, #7]
    // 0x8cc5e4: add             x1, x0, x6, lsl #1
    // 0x8cc5e8: strh            w7, [x1]
    // 0x8cc5ec: ubfx            x10, x10, #0, #0x20
    // 0x8cc5f0: mov             x6, x10
    // 0x8cc5f4: b               #0x8cc600
    // 0x8cc5f8: r2 = 65535
    //     0x8cc5f8: mov             x2, #0xffff
    // 0x8cc5fc: ldur            x6, [fp, #-8]
    // 0x8cc600: r5 = 4
    //     0x8cc600: mov             x5, #4
    // 0x8cc604: stur            x6, [fp, #-8]
    // 0x8cc608: LoadField: r7 = r4->field_6f
    //     0x8cc608: ldur            w7, [x4, #0x6f]
    // 0x8cc60c: DecompressPointer r7
    //     0x8cc60c: add             x7, x7, HEAP, lsl #32
    // 0x8cc610: r16 = Sentinel
    //     0x8cc610: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cc614: cmp             w7, w16
    // 0x8cc618: b.eq            #0x8ccef0
    // 0x8cc61c: mov             x0, x7
    // 0x8cc620: StoreField: r4->field_8b = r0
    //     0x8cc620: stur            w0, [x4, #0x8b]
    //     0x8cc624: tbz             w0, #0, #0x8cc640
    //     0x8cc628: ldurb           w16, [x4, #-1]
    //     0x8cc62c: ldurb           w17, [x0, #-1]
    //     0x8cc630: and             x16, x17, x16, lsr #2
    //     0x8cc634: tst             x16, HEAP, lsr #32
    //     0x8cc638: b.eq            #0x8cc640
    //     0x8cc63c: bl              #0xd682cc
    // 0x8cc640: LoadField: r8 = r4->field_7f
    //     0x8cc640: ldur            x8, [x4, #0x7f]
    // 0x8cc644: r0 = BoxInt64Instr(r8)
    //     0x8cc644: sbfiz           x0, x8, #1, #0x1f
    //     0x8cc648: cmp             x8, x0, asr #1
    //     0x8cc64c: b.eq            #0x8cc658
    //     0x8cc650: bl              #0xd69bb8
    //     0x8cc654: stur            x8, [x0, #7]
    // 0x8cc658: StoreField: r4->field_73 = r0
    //     0x8cc658: stur            w0, [x4, #0x73]
    //     0x8cc65c: tbz             w0, #0, #0x8cc678
    //     0x8cc660: ldurb           w16, [x4, #-1]
    //     0x8cc664: ldurb           w17, [x0, #-1]
    //     0x8cc668: and             x16, x17, x16, lsr #2
    //     0x8cc66c: tst             x16, HEAP, lsr #32
    //     0x8cc670: b.eq            #0x8cc678
    //     0x8cc674: bl              #0xd682cc
    // 0x8cc678: StoreField: r4->field_6f = r5
    //     0x8cc678: stur            w5, [x4, #0x6f]
    // 0x8cc67c: cbz             x6, #0x8cc7e0
    // 0x8cc680: r0 = LoadStaticField(0xa84)
    //     0x8cc680: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x8cc684: ldr             x0, [x0, #0x1508]
    //     0x8cc688: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cc68c: cmp             w0, w16
    // 0x8cc690: b.eq            #0x8ccefc
    // 0x8cc694: LoadField: r1 = r0->field_f
    //     0x8cc694: ldur            x1, [x0, #0xf]
    // 0x8cc698: r0 = LoadInt32Instr(r7)
    //     0x8cc698: sbfx            x0, x7, #1, #0x1f
    //     0x8cc69c: tbz             w7, #0, #0x8cc6a4
    //     0x8cc6a0: ldur            x0, [x7, #7]
    // 0x8cc6a4: cmp             x0, x1
    // 0x8cc6a8: b.ge            #0x8cc7d4
    // 0x8cc6ac: LoadField: r0 = r4->field_7b
    //     0x8cc6ac: ldur            w0, [x4, #0x7b]
    // 0x8cc6b0: DecompressPointer r0
    //     0x8cc6b0: add             x0, x0, HEAP, lsl #32
    // 0x8cc6b4: r16 = Sentinel
    //     0x8cc6b4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cc6b8: cmp             w0, w16
    // 0x8cc6bc: b.eq            #0x8ccf08
    // 0x8cc6c0: r1 = LoadInt32Instr(r0)
    //     0x8cc6c0: sbfx            x1, x0, #1, #0x1f
    //     0x8cc6c4: tbz             w0, #0, #0x8cc6cc
    //     0x8cc6c8: ldur            x1, [x0, #7]
    // 0x8cc6cc: mov             x0, x6
    // 0x8cc6d0: ubfx            x0, x0, #0, #0x20
    // 0x8cc6d4: sub             w7, w1, w0
    // 0x8cc6d8: and             x0, x7, x2
    // 0x8cc6dc: LoadField: r1 = r4->field_3b
    //     0x8cc6dc: ldur            w1, [x4, #0x3b]
    // 0x8cc6e0: DecompressPointer r1
    //     0x8cc6e0: add             x1, x1, HEAP, lsl #32
    // 0x8cc6e4: r16 = Sentinel
    //     0x8cc6e4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cc6e8: cmp             w1, w16
    // 0x8cc6ec: b.eq            #0x8ccf14
    // 0x8cc6f0: r7 = LoadInt32Instr(r1)
    //     0x8cc6f0: sbfx            x7, x1, #1, #0x1f
    //     0x8cc6f4: tbz             w1, #0, #0x8cc6fc
    //     0x8cc6f8: ldur            x7, [x1, #7]
    // 0x8cc6fc: sub             x1, x7, #0x106
    // 0x8cc700: ubfx            x0, x0, #0, #0x20
    // 0x8cc704: cmp             x0, x1
    // 0x8cc708: b.gt            #0x8cc7c8
    // 0x8cc70c: LoadField: r0 = r4->field_93
    //     0x8cc70c: ldur            w0, [x4, #0x93]
    // 0x8cc710: DecompressPointer r0
    //     0x8cc710: add             x0, x0, HEAP, lsl #32
    // 0x8cc714: r16 = Sentinel
    //     0x8cc714: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cc718: cmp             w0, w16
    // 0x8cc71c: b.eq            #0x8ccf20
    // 0x8cc720: stp             x6, x4, [SP, #-0x10]!
    // 0x8cc724: r0 = _longestMatch()
    //     0x8cc724: bl              #0x8cd00c  ; [package:archive/src/zlib/deflate.dart] Deflate::_longestMatch
    // 0x8cc728: add             SP, SP, #0x10
    // 0x8cc72c: mov             x2, x0
    // 0x8cc730: r0 = BoxInt64Instr(r2)
    //     0x8cc730: sbfiz           x0, x2, #1, #0x1f
    //     0x8cc734: cmp             x2, x0, asr #1
    //     0x8cc738: b.eq            #0x8cc744
    //     0x8cc73c: bl              #0xd69bb8
    //     0x8cc740: stur            x2, [x0, #7]
    // 0x8cc744: ldr             x3, [fp, #0x10]
    // 0x8cc748: StoreField: r3->field_6f = r0
    //     0x8cc748: stur            w0, [x3, #0x6f]
    //     0x8cc74c: tbz             w0, #0, #0x8cc768
    //     0x8cc750: ldurb           w16, [x3, #-1]
    //     0x8cc754: ldurb           w17, [x0, #-1]
    //     0x8cc758: and             x16, x17, x16, lsr #2
    //     0x8cc75c: tst             x16, HEAP, lsr #32
    //     0x8cc760: b.eq            #0x8cc768
    //     0x8cc764: bl              #0xd682ac
    // 0x8cc768: cmp             x2, #5
    // 0x8cc76c: b.gt            #0x8cc7bc
    // 0x8cc770: cmp             x2, #3
    // 0x8cc774: b.ne            #0x8cc7b4
    // 0x8cc778: LoadField: r0 = r3->field_7b
    //     0x8cc778: ldur            w0, [x3, #0x7b]
    // 0x8cc77c: DecompressPointer r0
    //     0x8cc77c: add             x0, x0, HEAP, lsl #32
    // 0x8cc780: LoadField: r1 = r3->field_7f
    //     0x8cc780: ldur            x1, [x3, #0x7f]
    // 0x8cc784: r4 = LoadInt32Instr(r0)
    //     0x8cc784: sbfx            x4, x0, #1, #0x1f
    //     0x8cc788: tbz             w0, #0, #0x8cc790
    //     0x8cc78c: ldur            x4, [x0, #7]
    // 0x8cc790: sub             x0, x4, x1
    // 0x8cc794: cmp             x0, #1, lsl #12
    // 0x8cc798: b.le            #0x8cc7ac
    // 0x8cc79c: r4 = 4
    //     0x8cc79c: mov             x4, #4
    // 0x8cc7a0: StoreField: r3->field_6f = r4
    //     0x8cc7a0: stur            w4, [x3, #0x6f]
    // 0x8cc7a4: r0 = 2
    //     0x8cc7a4: mov             x0, #2
    // 0x8cc7a8: b               #0x8cc7ec
    // 0x8cc7ac: r4 = 4
    //     0x8cc7ac: mov             x4, #4
    // 0x8cc7b0: b               #0x8cc7c0
    // 0x8cc7b4: r4 = 4
    //     0x8cc7b4: mov             x4, #4
    // 0x8cc7b8: b               #0x8cc7c0
    // 0x8cc7bc: r4 = 4
    //     0x8cc7bc: mov             x4, #4
    // 0x8cc7c0: mov             x0, x2
    // 0x8cc7c4: b               #0x8cc7ec
    // 0x8cc7c8: mov             x3, x4
    // 0x8cc7cc: mov             x4, x5
    // 0x8cc7d0: b               #0x8cc7e8
    // 0x8cc7d4: mov             x3, x4
    // 0x8cc7d8: mov             x4, x5
    // 0x8cc7dc: b               #0x8cc7e8
    // 0x8cc7e0: mov             x3, x4
    // 0x8cc7e4: mov             x4, x5
    // 0x8cc7e8: r0 = 2
    //     0x8cc7e8: mov             x0, #2
    // 0x8cc7ec: LoadField: r1 = r3->field_8b
    //     0x8cc7ec: ldur            w1, [x3, #0x8b]
    // 0x8cc7f0: DecompressPointer r1
    //     0x8cc7f0: add             x1, x1, HEAP, lsl #32
    // 0x8cc7f4: r2 = LoadInt32Instr(r1)
    //     0x8cc7f4: sbfx            x2, x1, #1, #0x1f
    //     0x8cc7f8: tbz             w1, #0, #0x8cc800
    //     0x8cc7fc: ldur            x2, [x1, #7]
    // 0x8cc800: cmp             x2, #3
    // 0x8cc804: b.lt            #0x8ccc04
    // 0x8cc808: cmp             x0, x2
    // 0x8cc80c: b.gt            #0x8ccc04
    // 0x8cc810: LoadField: r0 = r3->field_7b
    //     0x8cc810: ldur            w0, [x3, #0x7b]
    // 0x8cc814: DecompressPointer r0
    //     0x8cc814: add             x0, x0, HEAP, lsl #32
    // 0x8cc818: r16 = Sentinel
    //     0x8cc818: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cc81c: cmp             w0, w16
    // 0x8cc820: b.eq            #0x8ccf2c
    // 0x8cc824: LoadField: r1 = r3->field_87
    //     0x8cc824: ldur            w1, [x3, #0x87]
    // 0x8cc828: DecompressPointer r1
    //     0x8cc828: add             x1, x1, HEAP, lsl #32
    // 0x8cc82c: r5 = LoadInt32Instr(r0)
    //     0x8cc82c: sbfx            x5, x0, #1, #0x1f
    //     0x8cc830: tbz             w0, #0, #0x8cc838
    //     0x8cc834: ldur            x5, [x0, #7]
    // 0x8cc838: r0 = LoadInt32Instr(r1)
    //     0x8cc838: sbfx            x0, x1, #1, #0x1f
    //     0x8cc83c: tbz             w1, #0, #0x8cc844
    //     0x8cc840: ldur            x0, [x1, #7]
    // 0x8cc844: add             x1, x5, x0
    // 0x8cc848: sub             x6, x1, #3
    // 0x8cc84c: stur            x6, [fp, #-0x10]
    // 0x8cc850: sub             x0, x5, #1
    // 0x8cc854: LoadField: r1 = r3->field_73
    //     0x8cc854: ldur            w1, [x3, #0x73]
    // 0x8cc858: DecompressPointer r1
    //     0x8cc858: add             x1, x1, HEAP, lsl #32
    // 0x8cc85c: r5 = LoadInt32Instr(r1)
    //     0x8cc85c: sbfx            x5, x1, #1, #0x1f
    //     0x8cc860: tbz             w1, #0, #0x8cc868
    //     0x8cc864: ldur            x5, [x1, #7]
    // 0x8cc868: sub             x7, x0, x5
    // 0x8cc86c: sub             x5, x2, #3
    // 0x8cc870: r0 = BoxInt64Instr(r7)
    //     0x8cc870: sbfiz           x0, x7, #1, #0x1f
    //     0x8cc874: cmp             x7, x0, asr #1
    //     0x8cc878: b.eq            #0x8cc884
    //     0x8cc87c: bl              #0xd69bb8
    //     0x8cc880: stur            x7, [x0, #7]
    // 0x8cc884: stp             x0, x3, [SP, #-0x10]!
    // 0x8cc888: SaveReg r5
    //     0x8cc888: str             x5, [SP, #-8]!
    // 0x8cc88c: r0 = _trTally()
    //     0x8cc88c: bl              #0x8d0b30  ; [package:archive/src/zlib/deflate.dart] Deflate::_trTally
    // 0x8cc890: add             SP, SP, #0x18
    // 0x8cc894: mov             x3, x0
    // 0x8cc898: ldr             x2, [fp, #0x10]
    // 0x8cc89c: LoadField: r0 = r2->field_87
    //     0x8cc89c: ldur            w0, [x2, #0x87]
    // 0x8cc8a0: DecompressPointer r0
    //     0x8cc8a0: add             x0, x0, HEAP, lsl #32
    // 0x8cc8a4: LoadField: r1 = r2->field_8b
    //     0x8cc8a4: ldur            w1, [x2, #0x8b]
    // 0x8cc8a8: DecompressPointer r1
    //     0x8cc8a8: add             x1, x1, HEAP, lsl #32
    // 0x8cc8ac: r4 = LoadInt32Instr(r1)
    //     0x8cc8ac: sbfx            x4, x1, #1, #0x1f
    //     0x8cc8b0: tbz             w1, #0, #0x8cc8b8
    //     0x8cc8b4: ldur            x4, [x1, #7]
    // 0x8cc8b8: sub             x1, x4, #1
    // 0x8cc8bc: r5 = LoadInt32Instr(r0)
    //     0x8cc8bc: sbfx            x5, x0, #1, #0x1f
    //     0x8cc8c0: tbz             w0, #0, #0x8cc8c8
    //     0x8cc8c4: ldur            x5, [x0, #7]
    // 0x8cc8c8: sub             x6, x5, x1
    // 0x8cc8cc: r0 = BoxInt64Instr(r6)
    //     0x8cc8cc: sbfiz           x0, x6, #1, #0x1f
    //     0x8cc8d0: cmp             x6, x0, asr #1
    //     0x8cc8d4: b.eq            #0x8cc8e0
    //     0x8cc8d8: bl              #0xd69bb8
    //     0x8cc8dc: stur            x6, [x0, #7]
    // 0x8cc8e0: StoreField: r2->field_87 = r0
    //     0x8cc8e0: stur            w0, [x2, #0x87]
    //     0x8cc8e4: tbz             w0, #0, #0x8cc900
    //     0x8cc8e8: ldurb           w16, [x2, #-1]
    //     0x8cc8ec: ldurb           w17, [x0, #-1]
    //     0x8cc8f0: and             x16, x17, x16, lsr #2
    //     0x8cc8f4: tst             x16, HEAP, lsr #32
    //     0x8cc8f8: b.eq            #0x8cc900
    //     0x8cc8fc: bl              #0xd6828c
    // 0x8cc900: sub             x5, x4, #2
    // 0x8cc904: r0 = BoxInt64Instr(r5)
    //     0x8cc904: sbfiz           x0, x5, #1, #0x1f
    //     0x8cc908: cmp             x5, x0, asr #1
    //     0x8cc90c: b.eq            #0x8cc918
    //     0x8cc910: bl              #0xd69bb8
    //     0x8cc914: stur            x5, [x0, #7]
    // 0x8cc918: StoreField: r2->field_8b = r0
    //     0x8cc918: stur            w0, [x2, #0x8b]
    //     0x8cc91c: tbz             w0, #0, #0x8cc938
    //     0x8cc920: ldurb           w16, [x2, #-1]
    //     0x8cc924: ldurb           w17, [x0, #-1]
    //     0x8cc928: and             x16, x17, x16, lsr #2
    //     0x8cc92c: tst             x16, HEAP, lsr #32
    //     0x8cc930: b.eq            #0x8cc938
    //     0x8cc934: bl              #0xd6828c
    // 0x8cc938: ldur            x8, [fp, #-8]
    // 0x8cc93c: mov             x7, x5
    // 0x8cc940: ldur            x4, [fp, #-0x10]
    // 0x8cc944: r5 = 255
    //     0x8cc944: mov             x5, #0xff
    // 0x8cc948: r6 = 65535
    //     0x8cc948: mov             x6, #0xffff
    // 0x8cc94c: CheckStackOverflow
    //     0x8cc94c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cc950: cmp             SP, x16
    //     0x8cc954: b.ls            #0x8ccf38
    // 0x8cc958: LoadField: r0 = r2->field_7b
    //     0x8cc958: ldur            w0, [x2, #0x7b]
    // 0x8cc95c: DecompressPointer r0
    //     0x8cc95c: add             x0, x0, HEAP, lsl #32
    // 0x8cc960: r1 = LoadInt32Instr(r0)
    //     0x8cc960: sbfx            x1, x0, #1, #0x1f
    //     0x8cc964: tbz             w0, #0, #0x8cc96c
    //     0x8cc968: ldur            x1, [x0, #7]
    // 0x8cc96c: add             x10, x1, #1
    // 0x8cc970: r0 = BoxInt64Instr(r10)
    //     0x8cc970: sbfiz           x0, x10, #1, #0x1f
    //     0x8cc974: cmp             x10, x0, asr #1
    //     0x8cc978: b.eq            #0x8cc984
    //     0x8cc97c: bl              #0xd69bb8
    //     0x8cc980: stur            x10, [x0, #7]
    // 0x8cc984: StoreField: r2->field_7b = r0
    //     0x8cc984: stur            w0, [x2, #0x7b]
    //     0x8cc988: tbz             w0, #0, #0x8cc9a4
    //     0x8cc98c: ldurb           w16, [x2, #-1]
    //     0x8cc990: ldurb           w17, [x0, #-1]
    //     0x8cc994: and             x16, x17, x16, lsr #2
    //     0x8cc998: tst             x16, HEAP, lsr #32
    //     0x8cc99c: b.eq            #0x8cc9a4
    //     0x8cc9a0: bl              #0xd6828c
    // 0x8cc9a4: cmp             x10, x4
    // 0x8cc9a8: b.gt            #0x8ccb54
    // 0x8cc9ac: LoadField: r0 = r2->field_57
    //     0x8cc9ac: ldur            w0, [x2, #0x57]
    // 0x8cc9b0: DecompressPointer r0
    //     0x8cc9b0: add             x0, x0, HEAP, lsl #32
    // 0x8cc9b4: r16 = Sentinel
    //     0x8cc9b4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cc9b8: cmp             w0, w16
    // 0x8cc9bc: b.eq            #0x8ccf40
    // 0x8cc9c0: LoadField: r1 = r2->field_67
    //     0x8cc9c0: ldur            w1, [x2, #0x67]
    // 0x8cc9c4: DecompressPointer r1
    //     0x8cc9c4: add             x1, x1, HEAP, lsl #32
    // 0x8cc9c8: r16 = Sentinel
    //     0x8cc9c8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cc9cc: cmp             w1, w16
    // 0x8cc9d0: b.eq            #0x8ccf4c
    // 0x8cc9d4: r8 = LoadInt32Instr(r0)
    //     0x8cc9d4: sbfx            x8, x0, #1, #0x1f
    //     0x8cc9d8: tbz             w0, #0, #0x8cc9e0
    //     0x8cc9dc: ldur            x8, [x0, #7]
    // 0x8cc9e0: r0 = LoadInt32Instr(r1)
    //     0x8cc9e0: sbfx            x0, x1, #1, #0x1f
    //     0x8cc9e4: tbz             w1, #0, #0x8cc9ec
    //     0x8cc9e8: ldur            x0, [x1, #7]
    // 0x8cc9ec: cmp             x0, #0x3f
    // 0x8cc9f0: b.hi            #0x8ccf58
    // 0x8cc9f4: lsl             x11, x8, x0
    // 0x8cc9f8: LoadField: r8 = r2->field_47
    //     0x8cc9f8: ldur            w8, [x2, #0x47]
    // 0x8cc9fc: DecompressPointer r8
    //     0x8cc9fc: add             x8, x8, HEAP, lsl #32
    // 0x8cca00: r16 = Sentinel
    //     0x8cca00: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cca04: cmp             w8, w16
    // 0x8cca08: b.eq            #0x8ccf90
    // 0x8cca0c: add             x9, x10, #2
    // 0x8cca10: LoadField: r0 = r8->field_13
    //     0x8cca10: ldur            w0, [x8, #0x13]
    // 0x8cca14: DecompressPointer r0
    //     0x8cca14: add             x0, x0, HEAP, lsl #32
    // 0x8cca18: r1 = LoadInt32Instr(r0)
    //     0x8cca18: sbfx            x1, x0, #1, #0x1f
    // 0x8cca1c: mov             x0, x1
    // 0x8cca20: mov             x1, x9
    // 0x8cca24: cmp             x1, x0
    // 0x8cca28: b.hs            #0x8ccf9c
    // 0x8cca2c: ArrayLoad: r0 = r8[r9]  ; TypedUnsigned_1
    //     0x8cca2c: add             x16, x8, x9
    //     0x8cca30: ldrb            w0, [x16, #0x17]
    // 0x8cca34: ubfx            x0, x0, #0, #0x20
    // 0x8cca38: and             x1, x0, x5
    // 0x8cca3c: ubfx            x1, x1, #0, #0x20
    // 0x8cca40: eor             x0, x11, x1
    // 0x8cca44: LoadField: r1 = r2->field_63
    //     0x8cca44: ldur            w1, [x2, #0x63]
    // 0x8cca48: DecompressPointer r1
    //     0x8cca48: add             x1, x1, HEAP, lsl #32
    // 0x8cca4c: r16 = Sentinel
    //     0x8cca4c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cca50: cmp             w1, w16
    // 0x8cca54: b.eq            #0x8ccfa0
    // 0x8cca58: r8 = LoadInt32Instr(r1)
    //     0x8cca58: sbfx            x8, x1, #1, #0x1f
    //     0x8cca5c: tbz             w1, #0, #0x8cca64
    //     0x8cca60: ldur            x8, [x1, #7]
    // 0x8cca64: and             x11, x0, x8
    // 0x8cca68: r0 = BoxInt64Instr(r11)
    //     0x8cca68: sbfiz           x0, x11, #1, #0x1f
    //     0x8cca6c: cmp             x11, x0, asr #1
    //     0x8cca70: b.eq            #0x8cca7c
    //     0x8cca74: bl              #0xd69bb8
    //     0x8cca78: stur            x11, [x0, #7]
    // 0x8cca7c: StoreField: r2->field_57 = r0
    //     0x8cca7c: stur            w0, [x2, #0x57]
    //     0x8cca80: tbz             w0, #0, #0x8cca9c
    //     0x8cca84: ldurb           w16, [x2, #-1]
    //     0x8cca88: ldurb           w17, [x0, #-1]
    //     0x8cca8c: and             x16, x17, x16, lsr #2
    //     0x8cca90: tst             x16, HEAP, lsr #32
    //     0x8cca94: b.eq            #0x8cca9c
    //     0x8cca98: bl              #0xd6828c
    // 0x8cca9c: LoadField: r8 = r2->field_53
    //     0x8cca9c: ldur            w8, [x2, #0x53]
    // 0x8ccaa0: DecompressPointer r8
    //     0x8ccaa0: add             x8, x8, HEAP, lsl #32
    // 0x8ccaa4: r16 = Sentinel
    //     0x8ccaa4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8ccaa8: cmp             w8, w16
    // 0x8ccaac: b.eq            #0x8ccfac
    // 0x8ccab0: LoadField: r0 = r8->field_13
    //     0x8ccab0: ldur            w0, [x8, #0x13]
    // 0x8ccab4: DecompressPointer r0
    //     0x8ccab4: add             x0, x0, HEAP, lsl #32
    // 0x8ccab8: r1 = LoadInt32Instr(r0)
    //     0x8ccab8: sbfx            x1, x0, #1, #0x1f
    // 0x8ccabc: mov             x0, x1
    // 0x8ccac0: mov             x1, x11
    // 0x8ccac4: cmp             x1, x0
    // 0x8ccac8: b.hs            #0x8ccfb8
    // 0x8ccacc: add             x16, x8, x11, lsl #1
    // 0x8ccad0: ldurh           w12, [x16, #0x17]
    // 0x8ccad4: mov             x0, x12
    // 0x8ccad8: ubfx            x0, x0, #0, #0x20
    // 0x8ccadc: and             x13, x0, x6
    // 0x8ccae0: LoadField: r14 = r2->field_4f
    //     0x8ccae0: ldur            w14, [x2, #0x4f]
    // 0x8ccae4: DecompressPointer r14
    //     0x8ccae4: add             x14, x14, HEAP, lsl #32
    // 0x8ccae8: r16 = Sentinel
    //     0x8ccae8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8ccaec: cmp             w14, w16
    // 0x8ccaf0: b.eq            #0x8ccfbc
    // 0x8ccaf4: LoadField: r0 = r2->field_43
    //     0x8ccaf4: ldur            w0, [x2, #0x43]
    // 0x8ccaf8: DecompressPointer r0
    //     0x8ccaf8: add             x0, x0, HEAP, lsl #32
    // 0x8ccafc: r16 = Sentinel
    //     0x8ccafc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8ccb00: cmp             w0, w16
    // 0x8ccb04: b.eq            #0x8ccfc8
    // 0x8ccb08: r1 = LoadInt32Instr(r0)
    //     0x8ccb08: sbfx            x1, x0, #1, #0x1f
    //     0x8ccb0c: tbz             w0, #0, #0x8ccb14
    //     0x8ccb10: ldur            x1, [x0, #7]
    // 0x8ccb14: and             x9, x10, x1
    // 0x8ccb18: LoadField: r0 = r14->field_13
    //     0x8ccb18: ldur            w0, [x14, #0x13]
    // 0x8ccb1c: DecompressPointer r0
    //     0x8ccb1c: add             x0, x0, HEAP, lsl #32
    // 0x8ccb20: r1 = LoadInt32Instr(r0)
    //     0x8ccb20: sbfx            x1, x0, #1, #0x1f
    // 0x8ccb24: mov             x0, x1
    // 0x8ccb28: mov             x1, x9
    // 0x8ccb2c: cmp             x1, x0
    // 0x8ccb30: b.hs            #0x8ccfd4
    // 0x8ccb34: LoadField: r0 = r14->field_7
    //     0x8ccb34: ldur            x0, [x14, #7]
    // 0x8ccb38: add             x1, x0, x9, lsl #1
    // 0x8ccb3c: strh            w12, [x1]
    // 0x8ccb40: LoadField: r0 = r8->field_7
    //     0x8ccb40: ldur            x0, [x8, #7]
    // 0x8ccb44: add             x1, x0, x11, lsl #1
    // 0x8ccb48: strh            w10, [x1]
    // 0x8ccb4c: ubfx            x13, x13, #0, #0x20
    // 0x8ccb50: mov             x8, x13
    // 0x8ccb54: stur            x8, [fp, #-0x18]
    // 0x8ccb58: sub             x9, x7, #1
    // 0x8ccb5c: r0 = BoxInt64Instr(r9)
    //     0x8ccb5c: sbfiz           x0, x9, #1, #0x1f
    //     0x8ccb60: cmp             x9, x0, asr #1
    //     0x8ccb64: b.eq            #0x8ccb70
    //     0x8ccb68: bl              #0xd69bb8
    //     0x8ccb6c: stur            x9, [x0, #7]
    // 0x8ccb70: StoreField: r2->field_8b = r0
    //     0x8ccb70: stur            w0, [x2, #0x8b]
    //     0x8ccb74: tbz             w0, #0, #0x8ccb90
    //     0x8ccb78: ldurb           w16, [x2, #-1]
    //     0x8ccb7c: ldurb           w17, [x0, #-1]
    //     0x8ccb80: and             x16, x17, x16, lsr #2
    //     0x8ccb84: tst             x16, HEAP, lsr #32
    //     0x8ccb88: b.eq            #0x8ccb90
    //     0x8ccb8c: bl              #0xd6828c
    // 0x8ccb90: cbz             x9, #0x8ccb9c
    // 0x8ccb94: mov             x7, x9
    // 0x8ccb98: b               #0x8cc94c
    // 0x8ccb9c: r4 = 4
    //     0x8ccb9c: mov             x4, #4
    // 0x8ccba0: StoreField: r2->field_77 = rZR
    //     0x8ccba0: stur            wzr, [x2, #0x77]
    // 0x8ccba4: StoreField: r2->field_6f = r4
    //     0x8ccba4: stur            w4, [x2, #0x6f]
    // 0x8ccba8: add             x7, x10, #1
    // 0x8ccbac: r0 = BoxInt64Instr(r7)
    //     0x8ccbac: sbfiz           x0, x7, #1, #0x1f
    //     0x8ccbb0: cmp             x7, x0, asr #1
    //     0x8ccbb4: b.eq            #0x8ccbc0
    //     0x8ccbb8: bl              #0xd69bb8
    //     0x8ccbbc: stur            x7, [x0, #7]
    // 0x8ccbc0: StoreField: r2->field_7b = r0
    //     0x8ccbc0: stur            w0, [x2, #0x7b]
    //     0x8ccbc4: tbz             w0, #0, #0x8ccbe0
    //     0x8ccbc8: ldurb           w16, [x2, #-1]
    //     0x8ccbcc: ldurb           w17, [x0, #-1]
    //     0x8ccbd0: and             x16, x17, x16, lsr #2
    //     0x8ccbd4: tst             x16, HEAP, lsr #32
    //     0x8ccbd8: b.eq            #0x8ccbe0
    //     0x8ccbdc: bl              #0xd6828c
    // 0x8ccbe0: tbnz            w3, #4, #0x8ccbf4
    // 0x8ccbe4: r16 = false
    //     0x8ccbe4: add             x16, NULL, #0x30  ; false
    // 0x8ccbe8: stp             x16, x2, [SP, #-0x10]!
    // 0x8ccbec: r0 = _flushBlockOnly()
    //     0x8ccbec: bl              #0x8cd6d8  ; [package:archive/src/zlib/deflate.dart] Deflate::_flushBlockOnly
    // 0x8ccbf0: add             SP, SP, #0x10
    // 0x8ccbf4: ldur            x1, [fp, #-0x18]
    // 0x8ccbf8: ldr             x2, [fp, #0x10]
    // 0x8ccbfc: r3 = 2
    //     0x8ccbfc: mov             x3, #2
    // 0x8ccc00: b               #0x8cce08
    // 0x8ccc04: ldr             x2, [fp, #0x10]
    // 0x8ccc08: LoadField: r0 = r2->field_77
    //     0x8ccc08: ldur            w0, [x2, #0x77]
    // 0x8ccc0c: DecompressPointer r0
    //     0x8ccc0c: add             x0, x0, HEAP, lsl #32
    // 0x8ccc10: r16 = Sentinel
    //     0x8ccc10: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8ccc14: cmp             w0, w16
    // 0x8ccc18: b.eq            #0x8ccfd8
    // 0x8ccc1c: cbz             w0, #0x8ccd58
    // 0x8ccc20: r3 = 255
    //     0x8ccc20: mov             x3, #0xff
    // 0x8ccc24: LoadField: r4 = r2->field_47
    //     0x8ccc24: ldur            w4, [x2, #0x47]
    // 0x8ccc28: DecompressPointer r4
    //     0x8ccc28: add             x4, x4, HEAP, lsl #32
    // 0x8ccc2c: r16 = Sentinel
    //     0x8ccc2c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8ccc30: cmp             w4, w16
    // 0x8ccc34: b.eq            #0x8ccfe4
    // 0x8ccc38: LoadField: r0 = r2->field_7b
    //     0x8ccc38: ldur            w0, [x2, #0x7b]
    // 0x8ccc3c: DecompressPointer r0
    //     0x8ccc3c: add             x0, x0, HEAP, lsl #32
    // 0x8ccc40: r16 = Sentinel
    //     0x8ccc40: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8ccc44: cmp             w0, w16
    // 0x8ccc48: b.eq            #0x8ccff0
    // 0x8ccc4c: r1 = LoadInt32Instr(r0)
    //     0x8ccc4c: sbfx            x1, x0, #1, #0x1f
    //     0x8ccc50: tbz             w0, #0, #0x8ccc58
    //     0x8ccc54: ldur            x1, [x0, #7]
    // 0x8ccc58: sub             x5, x1, #1
    // 0x8ccc5c: LoadField: r0 = r4->field_13
    //     0x8ccc5c: ldur            w0, [x4, #0x13]
    // 0x8ccc60: DecompressPointer r0
    //     0x8ccc60: add             x0, x0, HEAP, lsl #32
    // 0x8ccc64: r1 = LoadInt32Instr(r0)
    //     0x8ccc64: sbfx            x1, x0, #1, #0x1f
    // 0x8ccc68: mov             x0, x1
    // 0x8ccc6c: mov             x1, x5
    // 0x8ccc70: cmp             x1, x0
    // 0x8ccc74: b.hs            #0x8ccffc
    // 0x8ccc78: ArrayLoad: r0 = r4[r5]  ; TypedUnsigned_1
    //     0x8ccc78: add             x16, x4, x5
    //     0x8ccc7c: ldrb            w0, [x16, #0x17]
    // 0x8ccc80: ubfx            x0, x0, #0, #0x20
    // 0x8ccc84: and             x1, x0, x3
    // 0x8ccc88: ubfx            x1, x1, #0, #0x20
    // 0x8ccc8c: stp             xzr, x2, [SP, #-0x10]!
    // 0x8ccc90: SaveReg r1
    //     0x8ccc90: str             x1, [SP, #-8]!
    // 0x8ccc94: r0 = _trTally()
    //     0x8ccc94: bl              #0x8d0b30  ; [package:archive/src/zlib/deflate.dart] Deflate::_trTally
    // 0x8ccc98: add             SP, SP, #0x18
    // 0x8ccc9c: tbnz            w0, #4, #0x8cccb4
    // 0x8ccca0: ldr             x16, [fp, #0x10]
    // 0x8ccca4: r30 = false
    //     0x8ccca4: add             lr, NULL, #0x30  ; false
    // 0x8ccca8: stp             lr, x16, [SP, #-0x10]!
    // 0x8cccac: r0 = _flushBlockOnly()
    //     0x8cccac: bl              #0x8cd6d8  ; [package:archive/src/zlib/deflate.dart] Deflate::_flushBlockOnly
    // 0x8cccb0: add             SP, SP, #0x10
    // 0x8cccb4: ldr             x2, [fp, #0x10]
    // 0x8cccb8: LoadField: r3 = r2->field_7b
    //     0x8cccb8: ldur            w3, [x2, #0x7b]
    // 0x8cccbc: DecompressPointer r3
    //     0x8cccbc: add             x3, x3, HEAP, lsl #32
    // 0x8cccc0: r4 = LoadInt32Instr(r3)
    //     0x8cccc0: sbfx            x4, x3, #1, #0x1f
    //     0x8cccc4: tbz             w3, #0, #0x8ccccc
    //     0x8cccc8: ldur            x4, [x3, #7]
    // 0x8ccccc: add             x3, x4, #1
    // 0x8cccd0: r0 = BoxInt64Instr(r3)
    //     0x8cccd0: sbfiz           x0, x3, #1, #0x1f
    //     0x8cccd4: cmp             x3, x0, asr #1
    //     0x8cccd8: b.eq            #0x8ccce4
    //     0x8cccdc: bl              #0xd69bb8
    //     0x8ccce0: stur            x3, [x0, #7]
    // 0x8ccce4: StoreField: r2->field_7b = r0
    //     0x8ccce4: stur            w0, [x2, #0x7b]
    //     0x8ccce8: tbz             w0, #0, #0x8ccd04
    //     0x8cccec: ldurb           w16, [x2, #-1]
    //     0x8cccf0: ldurb           w17, [x0, #-1]
    //     0x8cccf4: and             x16, x17, x16, lsr #2
    //     0x8cccf8: tst             x16, HEAP, lsr #32
    //     0x8cccfc: b.eq            #0x8ccd04
    //     0x8ccd00: bl              #0xd6828c
    // 0x8ccd04: LoadField: r3 = r2->field_87
    //     0x8ccd04: ldur            w3, [x2, #0x87]
    // 0x8ccd08: DecompressPointer r3
    //     0x8ccd08: add             x3, x3, HEAP, lsl #32
    // 0x8ccd0c: r4 = LoadInt32Instr(r3)
    //     0x8ccd0c: sbfx            x4, x3, #1, #0x1f
    //     0x8ccd10: tbz             w3, #0, #0x8ccd18
    //     0x8ccd14: ldur            x4, [x3, #7]
    // 0x8ccd18: sub             x3, x4, #1
    // 0x8ccd1c: r0 = BoxInt64Instr(r3)
    //     0x8ccd1c: sbfiz           x0, x3, #1, #0x1f
    //     0x8ccd20: cmp             x3, x0, asr #1
    //     0x8ccd24: b.eq            #0x8ccd30
    //     0x8ccd28: bl              #0xd69bb8
    //     0x8ccd2c: stur            x3, [x0, #7]
    // 0x8ccd30: StoreField: r2->field_87 = r0
    //     0x8ccd30: stur            w0, [x2, #0x87]
    //     0x8ccd34: tbz             w0, #0, #0x8ccd50
    //     0x8ccd38: ldurb           w16, [x2, #-1]
    //     0x8ccd3c: ldurb           w17, [x0, #-1]
    //     0x8ccd40: and             x16, x17, x16, lsr #2
    //     0x8ccd44: tst             x16, HEAP, lsr #32
    //     0x8ccd48: b.eq            #0x8ccd50
    //     0x8ccd4c: bl              #0xd6828c
    // 0x8ccd50: r3 = 2
    //     0x8ccd50: mov             x3, #2
    // 0x8ccd54: b               #0x8cce04
    // 0x8ccd58: r3 = 2
    //     0x8ccd58: mov             x3, #2
    // 0x8ccd5c: StoreField: r2->field_77 = r3
    //     0x8ccd5c: stur            w3, [x2, #0x77]
    // 0x8ccd60: LoadField: r4 = r2->field_7b
    //     0x8ccd60: ldur            w4, [x2, #0x7b]
    // 0x8ccd64: DecompressPointer r4
    //     0x8ccd64: add             x4, x4, HEAP, lsl #32
    // 0x8ccd68: r16 = Sentinel
    //     0x8ccd68: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8ccd6c: cmp             w4, w16
    // 0x8ccd70: b.eq            #0x8cd000
    // 0x8ccd74: r5 = LoadInt32Instr(r4)
    //     0x8ccd74: sbfx            x5, x4, #1, #0x1f
    //     0x8ccd78: tbz             w4, #0, #0x8ccd80
    //     0x8ccd7c: ldur            x5, [x4, #7]
    // 0x8ccd80: add             x4, x5, #1
    // 0x8ccd84: r0 = BoxInt64Instr(r4)
    //     0x8ccd84: sbfiz           x0, x4, #1, #0x1f
    //     0x8ccd88: cmp             x4, x0, asr #1
    //     0x8ccd8c: b.eq            #0x8ccd98
    //     0x8ccd90: bl              #0xd69bb8
    //     0x8ccd94: stur            x4, [x0, #7]
    // 0x8ccd98: StoreField: r2->field_7b = r0
    //     0x8ccd98: stur            w0, [x2, #0x7b]
    //     0x8ccd9c: tbz             w0, #0, #0x8ccdb8
    //     0x8ccda0: ldurb           w16, [x2, #-1]
    //     0x8ccda4: ldurb           w17, [x0, #-1]
    //     0x8ccda8: and             x16, x17, x16, lsr #2
    //     0x8ccdac: tst             x16, HEAP, lsr #32
    //     0x8ccdb0: b.eq            #0x8ccdb8
    //     0x8ccdb4: bl              #0xd6828c
    // 0x8ccdb8: LoadField: r4 = r2->field_87
    //     0x8ccdb8: ldur            w4, [x2, #0x87]
    // 0x8ccdbc: DecompressPointer r4
    //     0x8ccdbc: add             x4, x4, HEAP, lsl #32
    // 0x8ccdc0: r5 = LoadInt32Instr(r4)
    //     0x8ccdc0: sbfx            x5, x4, #1, #0x1f
    //     0x8ccdc4: tbz             w4, #0, #0x8ccdcc
    //     0x8ccdc8: ldur            x5, [x4, #7]
    // 0x8ccdcc: sub             x4, x5, #1
    // 0x8ccdd0: r0 = BoxInt64Instr(r4)
    //     0x8ccdd0: sbfiz           x0, x4, #1, #0x1f
    //     0x8ccdd4: cmp             x4, x0, asr #1
    //     0x8ccdd8: b.eq            #0x8ccde4
    //     0x8ccddc: bl              #0xd69bb8
    //     0x8ccde0: stur            x4, [x0, #7]
    // 0x8ccde4: StoreField: r2->field_87 = r0
    //     0x8ccde4: stur            w0, [x2, #0x87]
    //     0x8ccde8: tbz             w0, #0, #0x8cce04
    //     0x8ccdec: ldurb           w16, [x2, #-1]
    //     0x8ccdf0: ldurb           w17, [x0, #-1]
    //     0x8ccdf4: and             x16, x17, x16, lsr #2
    //     0x8ccdf8: tst             x16, HEAP, lsr #32
    //     0x8ccdfc: b.eq            #0x8cce04
    //     0x8cce00: bl              #0xd6828c
    // 0x8cce04: ldur            x1, [fp, #-8]
    // 0x8cce08: mov             x0, x2
    // 0x8cce0c: b               #0x8cc2cc
    // 0x8cce10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cce10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cce14: b               #0x8cc2c4
    // 0x8cce18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cce18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cce1c: b               #0x8cc2dc
    // 0x8cce20: r9 = _lookAhead
    //     0x8cce20: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a28] Field <Deflate._lookAhead@60040000>: late (offset: 0x88)
    //     0x8cce24: ldr             x9, [x9, #0xa28]
    // 0x8cce28: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cce28: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cce2c: r9 = _matchAvailable
    //     0x8cce2c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a50] Field <Deflate._matchAvailable@60040000>: late (offset: 0x78)
    //     0x8cce30: ldr             x9, [x9, #0xa50]
    // 0x8cce34: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cce34: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cce38: r9 = _window
    //     0x8cce38: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a38] Field <Deflate._window@60040000>: late (offset: 0x48)
    //     0x8cce3c: ldr             x9, [x9, #0xa38]
    // 0x8cce40: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cce40: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cce44: r9 = _strStart
    //     0x8cce44: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a58] Field <Deflate._strStart@60040000>: late (offset: 0x7c)
    //     0x8cce48: ldr             x9, [x9, #0xa58]
    // 0x8cce4c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cce4c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cce50: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cce50: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cce54: r9 = _insertHash
    //     0x8cce54: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a60] Field <Deflate._insertHash@60040000>: late (offset: 0x58)
    //     0x8cce58: ldr             x9, [x9, #0xa60]
    // 0x8cce5c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cce5c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cce60: r9 = _hashShift
    //     0x8cce60: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a68] Field <Deflate._hashShift@60040000>: late (offset: 0x68)
    //     0x8cce64: ldr             x9, [x9, #0xa68]
    // 0x8cce68: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cce68: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cce6c: tbnz            x0, #0x3f, #0x8cce78
    // 0x8cce70: mov             x6, xzr
    // 0x8cce74: b               #0x8cc478
    // 0x8cce78: str             x0, [THR, #0xc0]  ; THR::
    // 0x8cce7c: stp             x4, x5, [SP, #-0x10]!
    // 0x8cce80: stp             x2, x3, [SP, #-0x10]!
    // 0x8cce84: SaveReg r0
    //     0x8cce84: str             x0, [SP, #-8]!
    // 0x8cce88: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x8cce8c: r4 = 0
    //     0x8cce8c: mov             x4, #0
    // 0x8cce90: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8cce94: blr             lr
    // 0x8cce98: brk             #0
    // 0x8cce9c: r9 = _window
    //     0x8cce9c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a38] Field <Deflate._window@60040000>: late (offset: 0x48)
    //     0x8ccea0: ldr             x9, [x9, #0xa38]
    // 0x8ccea4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccea4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ccea8: r9 = _strStart
    //     0x8ccea8: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a58] Field <Deflate._strStart@60040000>: late (offset: 0x7c)
    //     0x8cceac: ldr             x9, [x9, #0xa58]
    // 0x8cceb0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cceb0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cceb4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cceb4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cceb8: r9 = _hashMask
    //     0x8cceb8: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a70] Field <Deflate._hashMask@60040000>: late (offset: 0x64)
    //     0x8ccebc: ldr             x9, [x9, #0xa70]
    // 0x8ccec0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccec0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ccec4: r9 = _head
    //     0x8ccec4: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a78] Field <Deflate._head@60040000>: late (offset: 0x54)
    //     0x8ccec8: ldr             x9, [x9, #0xa78]
    // 0x8ccecc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccecc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cced0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cced0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cced4: r9 = _prev
    //     0x8cced4: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a80] Field <Deflate._prev@60040000>: late (offset: 0x50)
    //     0x8cced8: ldr             x9, [x9, #0xa80]
    // 0x8ccedc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccedc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ccee0: r9 = _windowMask
    //     0x8ccee0: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a88] Field <Deflate._windowMask@60040000>: late (offset: 0x44)
    //     0x8ccee4: ldr             x9, [x9, #0xa88]
    // 0x8ccee8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccee8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cceec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cceec: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ccef0: r9 = _matchLength
    //     0x8ccef0: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a90] Field <Deflate._matchLength@60040000>: late (offset: 0x70)
    //     0x8ccef4: ldr             x9, [x9, #0xa90]
    // 0x8ccef8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccef8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ccefc: r9 = _config
    //     0x8ccefc: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a30] Field <Deflate._config@60040000>: static late (offset: 0xa84)
    //     0x8ccf00: ldr             x9, [x9, #0xa30]
    // 0x8ccf04: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccf04: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ccf08: r9 = _strStart
    //     0x8ccf08: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a58] Field <Deflate._strStart@60040000>: late (offset: 0x7c)
    //     0x8ccf0c: ldr             x9, [x9, #0xa58]
    // 0x8ccf10: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccf10: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ccf14: r9 = _windowSize
    //     0x8ccf14: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a98] Field <Deflate._windowSize@60040000>: late (offset: 0x3c)
    //     0x8ccf18: ldr             x9, [x9, #0xa98]
    // 0x8ccf1c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccf1c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ccf20: r9 = _strategy
    //     0x8ccf20: add             x9, PP, #0x34, lsl #12  ; [pp+0x34aa0] Field <Deflate._strategy@60040000>: late (offset: 0x94)
    //     0x8ccf24: ldr             x9, [x9, #0xaa0]
    // 0x8ccf28: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccf28: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ccf2c: r9 = _strStart
    //     0x8ccf2c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a58] Field <Deflate._strStart@60040000>: late (offset: 0x7c)
    //     0x8ccf30: ldr             x9, [x9, #0xa58]
    // 0x8ccf34: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccf34: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ccf38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ccf38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ccf3c: b               #0x8cc958
    // 0x8ccf40: r9 = _insertHash
    //     0x8ccf40: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a60] Field <Deflate._insertHash@60040000>: late (offset: 0x58)
    //     0x8ccf44: ldr             x9, [x9, #0xa60]
    // 0x8ccf48: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccf48: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ccf4c: r9 = _hashShift
    //     0x8ccf4c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a68] Field <Deflate._hashShift@60040000>: late (offset: 0x68)
    //     0x8ccf50: ldr             x9, [x9, #0xa68]
    // 0x8ccf54: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccf54: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ccf58: tbnz            x0, #0x3f, #0x8ccf64
    // 0x8ccf5c: mov             x11, xzr
    // 0x8ccf60: b               #0x8cc9f8
    // 0x8ccf64: str             x0, [THR, #0xc0]  ; THR::
    // 0x8ccf68: stp             x8, x10, [SP, #-0x10]!
    // 0x8ccf6c: stp             x6, x7, [SP, #-0x10]!
    // 0x8ccf70: stp             x4, x5, [SP, #-0x10]!
    // 0x8ccf74: stp             x2, x3, [SP, #-0x10]!
    // 0x8ccf78: SaveReg r0
    //     0x8ccf78: str             x0, [SP, #-8]!
    // 0x8ccf7c: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x8ccf80: r4 = 0
    //     0x8ccf80: mov             x4, #0
    // 0x8ccf84: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8ccf88: blr             lr
    // 0x8ccf8c: brk             #0
    // 0x8ccf90: r9 = _window
    //     0x8ccf90: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a38] Field <Deflate._window@60040000>: late (offset: 0x48)
    //     0x8ccf94: ldr             x9, [x9, #0xa38]
    // 0x8ccf98: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccf98: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ccf9c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ccf9c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ccfa0: r9 = _hashMask
    //     0x8ccfa0: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a70] Field <Deflate._hashMask@60040000>: late (offset: 0x64)
    //     0x8ccfa4: ldr             x9, [x9, #0xa70]
    // 0x8ccfa8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccfa8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ccfac: r9 = _head
    //     0x8ccfac: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a78] Field <Deflate._head@60040000>: late (offset: 0x54)
    //     0x8ccfb0: ldr             x9, [x9, #0xa78]
    // 0x8ccfb4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccfb4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ccfb8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ccfb8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ccfbc: r9 = _prev
    //     0x8ccfbc: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a80] Field <Deflate._prev@60040000>: late (offset: 0x50)
    //     0x8ccfc0: ldr             x9, [x9, #0xa80]
    // 0x8ccfc4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccfc4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ccfc8: r9 = _windowMask
    //     0x8ccfc8: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a88] Field <Deflate._windowMask@60040000>: late (offset: 0x44)
    //     0x8ccfcc: ldr             x9, [x9, #0xa88]
    // 0x8ccfd0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccfd0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ccfd4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ccfd4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ccfd8: r9 = _matchAvailable
    //     0x8ccfd8: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a50] Field <Deflate._matchAvailable@60040000>: late (offset: 0x78)
    //     0x8ccfdc: ldr             x9, [x9, #0xa50]
    // 0x8ccfe0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccfe0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ccfe4: r9 = _window
    //     0x8ccfe4: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a38] Field <Deflate._window@60040000>: late (offset: 0x48)
    //     0x8ccfe8: ldr             x9, [x9, #0xa38]
    // 0x8ccfec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccfec: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ccff0: r9 = _strStart
    //     0x8ccff0: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a58] Field <Deflate._strStart@60040000>: late (offset: 0x7c)
    //     0x8ccff4: ldr             x9, [x9, #0xa58]
    // 0x8ccff8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccff8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ccffc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ccffc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd000: r9 = _strStart
    //     0x8cd000: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a58] Field <Deflate._strStart@60040000>: late (offset: 0x7c)
    //     0x8cd004: ldr             x9, [x9, #0xa58]
    // 0x8cd008: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cd008: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _longestMatch(/* No info */) {
    // ** addr: 0x8cd00c, size: 0x6cc
    // 0x8cd00c: EnterFrame
    //     0x8cd00c: stp             fp, lr, [SP, #-0x10]!
    //     0x8cd010: mov             fp, SP
    // 0x8cd014: AllocStack(0x8)
    //     0x8cd014: sub             SP, SP, #8
    // 0x8cd018: r0 = LoadStaticField(0xa84)
    //     0x8cd018: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x8cd01c: ldr             x0, [x0, #0x1508]
    //     0x8cd020: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cd024: cmp             w0, w16
    // 0x8cd028: b.eq            #0x8cd5f0
    // 0x8cd02c: mov             x2, x0
    // 0x8cd030: LoadField: r3 = r2->field_1f
    //     0x8cd030: ldur            x3, [x2, #0x1f]
    // 0x8cd034: ldr             x4, [fp, #0x18]
    // 0x8cd038: LoadField: r5 = r4->field_7b
    //     0x8cd038: ldur            w5, [x4, #0x7b]
    // 0x8cd03c: DecompressPointer r5
    //     0x8cd03c: add             x5, x5, HEAP, lsl #32
    // 0x8cd040: r16 = Sentinel
    //     0x8cd040: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cd044: cmp             w5, w16
    // 0x8cd048: b.eq            #0x8cd5fc
    // 0x8cd04c: LoadField: r6 = r4->field_8b
    //     0x8cd04c: ldur            w6, [x4, #0x8b]
    // 0x8cd050: DecompressPointer r6
    //     0x8cd050: add             x6, x6, HEAP, lsl #32
    // 0x8cd054: r16 = Sentinel
    //     0x8cd054: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cd058: cmp             w6, w16
    // 0x8cd05c: b.eq            #0x8cd608
    // 0x8cd060: LoadField: r7 = r4->field_3b
    //     0x8cd060: ldur            w7, [x4, #0x3b]
    // 0x8cd064: DecompressPointer r7
    //     0x8cd064: add             x7, x7, HEAP, lsl #32
    // 0x8cd068: r16 = Sentinel
    //     0x8cd068: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cd06c: cmp             w7, w16
    // 0x8cd070: b.eq            #0x8cd614
    // 0x8cd074: r8 = LoadInt32Instr(r7)
    //     0x8cd074: sbfx            x8, x7, #1, #0x1f
    //     0x8cd078: tbz             w7, #0, #0x8cd080
    //     0x8cd07c: ldur            x8, [x7, #7]
    // 0x8cd080: sub             x7, x8, #0x106
    // 0x8cd084: r8 = LoadInt32Instr(r5)
    //     0x8cd084: sbfx            x8, x5, #1, #0x1f
    //     0x8cd088: tbz             w5, #0, #0x8cd090
    //     0x8cd08c: ldur            x8, [x5, #7]
    // 0x8cd090: cmp             x8, x7
    // 0x8cd094: b.le            #0x8cd0a0
    // 0x8cd098: sub             x5, x8, x7
    // 0x8cd09c: b               #0x8cd0a4
    // 0x8cd0a0: r5 = 0
    //     0x8cd0a0: mov             x5, #0
    // 0x8cd0a4: LoadField: r7 = r2->field_17
    //     0x8cd0a4: ldur            x7, [x2, #0x17]
    // 0x8cd0a8: LoadField: r10 = r4->field_43
    //     0x8cd0a8: ldur            w10, [x4, #0x43]
    // 0x8cd0ac: DecompressPointer r10
    //     0x8cd0ac: add             x10, x10, HEAP, lsl #32
    // 0x8cd0b0: r16 = Sentinel
    //     0x8cd0b0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cd0b4: cmp             w10, w16
    // 0x8cd0b8: b.eq            #0x8cd620
    // 0x8cd0bc: add             x11, x8, #0x102
    // 0x8cd0c0: LoadField: r12 = r4->field_47
    //     0x8cd0c0: ldur            w12, [x4, #0x47]
    // 0x8cd0c4: DecompressPointer r12
    //     0x8cd0c4: add             x12, x12, HEAP, lsl #32
    // 0x8cd0c8: r16 = Sentinel
    //     0x8cd0c8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cd0cc: cmp             w12, w16
    // 0x8cd0d0: b.eq            #0x8cd62c
    // 0x8cd0d4: r13 = LoadInt32Instr(r6)
    //     0x8cd0d4: sbfx            x13, x6, #1, #0x1f
    //     0x8cd0d8: tbz             w6, #0, #0x8cd0e0
    //     0x8cd0dc: ldur            x13, [x6, #7]
    // 0x8cd0e0: add             x6, x8, x13
    // 0x8cd0e4: sub             x9, x6, #1
    // 0x8cd0e8: LoadField: r14 = r12->field_13
    //     0x8cd0e8: ldur            w14, [x12, #0x13]
    // 0x8cd0ec: DecompressPointer r14
    //     0x8cd0ec: add             x14, x14, HEAP, lsl #32
    // 0x8cd0f0: r19 = LoadInt32Instr(r14)
    //     0x8cd0f0: sbfx            x19, x14, #1, #0x1f
    // 0x8cd0f4: mov             x0, x19
    // 0x8cd0f8: mov             x1, x9
    // 0x8cd0fc: stur            x19, [fp, #-8]
    // 0x8cd100: cmp             x1, x0
    // 0x8cd104: b.hs            #0x8cd638
    // 0x8cd108: ArrayLoad: r14 = r12[r9]  ; TypedUnsigned_1
    //     0x8cd108: add             x16, x12, x9
    //     0x8cd10c: ldrb            w14, [x16, #0x17]
    // 0x8cd110: mov             x0, x19
    // 0x8cd114: mov             x1, x6
    // 0x8cd118: cmp             x1, x0
    // 0x8cd11c: b.hs            #0x8cd63c
    // 0x8cd120: ArrayLoad: r20 = r12[r6]  ; TypedUnsigned_1
    //     0x8cd120: add             x16, x12, x6
    //     0x8cd124: ldrb            w20, [x16, #0x17]
    // 0x8cd128: LoadField: r6 = r2->field_7
    //     0x8cd128: ldur            x6, [x2, #7]
    // 0x8cd12c: cmp             x13, x6
    // 0x8cd130: b.lt            #0x8cd13c
    // 0x8cd134: asr             x2, x3, #2
    // 0x8cd138: b               #0x8cd140
    // 0x8cd13c: mov             x2, x3
    // 0x8cd140: LoadField: r3 = r4->field_87
    //     0x8cd140: ldur            w3, [x4, #0x87]
    // 0x8cd144: DecompressPointer r3
    //     0x8cd144: add             x3, x3, HEAP, lsl #32
    // 0x8cd148: r16 = Sentinel
    //     0x8cd148: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cd14c: cmp             w3, w16
    // 0x8cd150: b.eq            #0x8cd640
    // 0x8cd154: r6 = LoadInt32Instr(r3)
    //     0x8cd154: sbfx            x6, x3, #1, #0x1f
    //     0x8cd158: tbz             w3, #0, #0x8cd160
    //     0x8cd15c: ldur            x6, [x3, #7]
    // 0x8cd160: cmp             x7, x6
    // 0x8cd164: b.gt            #0x8cd16c
    // 0x8cd168: mov             x6, x7
    // 0x8cd16c: ldr             x3, [fp, #0x10]
    // 0x8cd170: sub             x7, x11, #0x102
    // 0x8cd174: r23 = LoadInt32Instr(r10)
    //     0x8cd174: sbfx            x23, x10, #1, #0x1f
    //     0x8cd178: tbz             w10, #0, #0x8cd180
    //     0x8cd17c: ldur            x23, [x10, #7]
    // 0x8cd180: mov             x9, x8
    // 0x8cd184: mov             x8, x20
    // 0x8cd188: mov             x20, x3
    // 0x8cd18c: mov             x10, x14
    // 0x8cd190: mov             x14, x2
    // 0x8cd194: r3 = 258
    //     0x8cd194: mov             x3, #0x102
    // 0x8cd198: r2 = 65535
    //     0x8cd198: mov             x2, #0xffff
    // 0x8cd19c: CheckStackOverflow
    //     0x8cd19c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cd1a0: cmp             SP, x16
    //     0x8cd1a4: b.ls            #0x8cd64c
    // 0x8cd1a8: add             x24, x20, x13
    // 0x8cd1ac: ldur            x0, [fp, #-8]
    // 0x8cd1b0: mov             x1, x24
    // 0x8cd1b4: cmp             x1, x0
    // 0x8cd1b8: b.hs            #0x8cd654
    // 0x8cd1bc: ArrayLoad: r25 = r12[r24]  ; TypedUnsigned_1
    //     0x8cd1bc: add             x16, x12, x24
    //     0x8cd1c0: ldrb            w25, [x16, #0x17]
    // 0x8cd1c4: cmp             x25, x8
    // 0x8cd1c8: b.ne            #0x8cd268
    // 0x8cd1cc: sub             x25, x24, #1
    // 0x8cd1d0: ldur            x0, [fp, #-8]
    // 0x8cd1d4: mov             x1, x25
    // 0x8cd1d8: cmp             x1, x0
    // 0x8cd1dc: b.hs            #0x8cd658
    // 0x8cd1e0: ArrayLoad: r24 = r12[r25]  ; TypedUnsigned_1
    //     0x8cd1e0: add             x16, x12, x25
    //     0x8cd1e4: ldrb            w24, [x16, #0x17]
    // 0x8cd1e8: cmp             x24, x10
    // 0x8cd1ec: b.ne            #0x8cd268
    // 0x8cd1f0: ldur            x0, [fp, #-8]
    // 0x8cd1f4: mov             x1, x20
    // 0x8cd1f8: cmp             x1, x0
    // 0x8cd1fc: b.hs            #0x8cd65c
    // 0x8cd200: ArrayLoad: r24 = r12[r20]  ; TypedUnsigned_1
    //     0x8cd200: add             x16, x12, x20
    //     0x8cd204: ldrb            w24, [x16, #0x17]
    // 0x8cd208: ldur            x0, [fp, #-8]
    // 0x8cd20c: mov             x1, x9
    // 0x8cd210: cmp             x1, x0
    // 0x8cd214: b.hs            #0x8cd660
    // 0x8cd218: ArrayLoad: r25 = r12[r9]  ; TypedUnsigned_1
    //     0x8cd218: add             x16, x12, x9
    //     0x8cd21c: ldrb            w25, [x16, #0x17]
    // 0x8cd220: cmp             x24, x25
    // 0x8cd224: b.ne            #0x8cd268
    // 0x8cd228: add             x24, x20, #1
    // 0x8cd22c: ldur            x0, [fp, #-8]
    // 0x8cd230: mov             x1, x24
    // 0x8cd234: cmp             x1, x0
    // 0x8cd238: b.hs            #0x8cd664
    // 0x8cd23c: ArrayLoad: r25 = r12[r24]  ; TypedUnsigned_1
    //     0x8cd23c: add             x16, x12, x24
    //     0x8cd240: ldrb            w25, [x16, #0x17]
    // 0x8cd244: add             x1, x9, #1
    // 0x8cd248: ldur            x0, [fp, #-8]
    // 0x8cd24c: mov             x19, x1
    // 0x8cd250: cmp             x1, x0
    // 0x8cd254: b.hs            #0x8cd668
    // 0x8cd258: ArrayLoad: r0 = r12[r19]  ; TypedUnsigned_1
    //     0x8cd258: add             x16, x12, x19
    //     0x8cd25c: ldrb            w0, [x16, #0x17]
    // 0x8cd260: cmp             x25, x0
    // 0x8cd264: b.eq            #0x8cd270
    // 0x8cd268: mov             x19, x9
    // 0x8cd26c: b               #0x8cd53c
    // 0x8cd270: add             x19, x9, #2
    // 0x8cd274: add             x25, x24, #1
    // 0x8cd278: mov             x24, x19
    // 0x8cd27c: mov             x19, x25
    // 0x8cd280: CheckStackOverflow
    //     0x8cd280: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cd284: cmp             SP, x16
    //     0x8cd288: b.ls            #0x8cd66c
    // 0x8cd28c: add             x9, x24, #1
    // 0x8cd290: ldur            x0, [fp, #-8]
    // 0x8cd294: mov             x1, x9
    // 0x8cd298: cmp             x1, x0
    // 0x8cd29c: b.hs            #0x8cd674
    // 0x8cd2a0: ArrayLoad: r24 = r12[r9]  ; TypedUnsigned_1
    //     0x8cd2a0: add             x16, x12, x9
    //     0x8cd2a4: ldrb            w24, [x16, #0x17]
    // 0x8cd2a8: add             x25, x19, #1
    // 0x8cd2ac: ldur            x0, [fp, #-8]
    // 0x8cd2b0: mov             x1, x25
    // 0x8cd2b4: cmp             x1, x0
    // 0x8cd2b8: b.hs            #0x8cd678
    // 0x8cd2bc: ArrayLoad: r19 = r12[r25]  ; TypedUnsigned_1
    //     0x8cd2bc: add             x16, x12, x25
    //     0x8cd2c0: ldrb            w19, [x16, #0x17]
    // 0x8cd2c4: cmp             x24, x19
    // 0x8cd2c8: b.ne            #0x8cd4cc
    // 0x8cd2cc: add             x19, x9, #1
    // 0x8cd2d0: ldur            x0, [fp, #-8]
    // 0x8cd2d4: mov             x1, x19
    // 0x8cd2d8: cmp             x1, x0
    // 0x8cd2dc: b.hs            #0x8cd67c
    // 0x8cd2e0: ArrayLoad: r24 = r12[r19]  ; TypedUnsigned_1
    //     0x8cd2e0: add             x16, x12, x19
    //     0x8cd2e4: ldrb            w24, [x16, #0x17]
    // 0x8cd2e8: add             x9, x25, #1
    // 0x8cd2ec: ldur            x0, [fp, #-8]
    // 0x8cd2f0: mov             x1, x9
    // 0x8cd2f4: cmp             x1, x0
    // 0x8cd2f8: b.hs            #0x8cd680
    // 0x8cd2fc: ArrayLoad: r25 = r12[r9]  ; TypedUnsigned_1
    //     0x8cd2fc: add             x16, x12, x9
    //     0x8cd300: ldrb            w25, [x16, #0x17]
    // 0x8cd304: cmp             x24, x25
    // 0x8cd308: b.ne            #0x8cd4d0
    // 0x8cd30c: add             x24, x19, #1
    // 0x8cd310: ldur            x0, [fp, #-8]
    // 0x8cd314: mov             x1, x24
    // 0x8cd318: cmp             x1, x0
    // 0x8cd31c: b.hs            #0x8cd684
    // 0x8cd320: ArrayLoad: r25 = r12[r24]  ; TypedUnsigned_1
    //     0x8cd320: add             x16, x12, x24
    //     0x8cd324: ldrb            w25, [x16, #0x17]
    // 0x8cd328: add             x19, x9, #1
    // 0x8cd32c: ldur            x0, [fp, #-8]
    // 0x8cd330: mov             x1, x19
    // 0x8cd334: cmp             x1, x0
    // 0x8cd338: b.hs            #0x8cd688
    // 0x8cd33c: ArrayLoad: r0 = r12[r19]  ; TypedUnsigned_1
    //     0x8cd33c: add             x16, x12, x19
    //     0x8cd340: ldrb            w0, [x16, #0x17]
    // 0x8cd344: cmp             x25, x0
    // 0x8cd348: b.ne            #0x8cd4c4
    // 0x8cd34c: add             x9, x24, #1
    // 0x8cd350: ldur            x0, [fp, #-8]
    // 0x8cd354: mov             x1, x9
    // 0x8cd358: cmp             x1, x0
    // 0x8cd35c: b.hs            #0x8cd68c
    // 0x8cd360: ArrayLoad: r25 = r12[r9]  ; TypedUnsigned_1
    //     0x8cd360: add             x16, x12, x9
    //     0x8cd364: ldrb            w25, [x16, #0x17]
    // 0x8cd368: add             x24, x19, #1
    // 0x8cd36c: ldur            x0, [fp, #-8]
    // 0x8cd370: mov             x1, x24
    // 0x8cd374: cmp             x1, x0
    // 0x8cd378: b.hs            #0x8cd690
    // 0x8cd37c: ArrayLoad: r0 = r12[r24]  ; TypedUnsigned_1
    //     0x8cd37c: add             x16, x12, x24
    //     0x8cd380: ldrb            w0, [x16, #0x17]
    // 0x8cd384: cmp             x25, x0
    // 0x8cd388: b.ne            #0x8cd4bc
    // 0x8cd38c: add             x19, x9, #1
    // 0x8cd390: ldur            x0, [fp, #-8]
    // 0x8cd394: mov             x1, x19
    // 0x8cd398: cmp             x1, x0
    // 0x8cd39c: b.hs            #0x8cd694
    // 0x8cd3a0: ArrayLoad: r25 = r12[r19]  ; TypedUnsigned_1
    //     0x8cd3a0: add             x16, x12, x19
    //     0x8cd3a4: ldrb            w25, [x16, #0x17]
    // 0x8cd3a8: add             x9, x24, #1
    // 0x8cd3ac: ldur            x0, [fp, #-8]
    // 0x8cd3b0: mov             x1, x9
    // 0x8cd3b4: cmp             x1, x0
    // 0x8cd3b8: b.hs            #0x8cd698
    // 0x8cd3bc: ArrayLoad: r0 = r12[r9]  ; TypedUnsigned_1
    //     0x8cd3bc: add             x16, x12, x9
    //     0x8cd3c0: ldrb            w0, [x16, #0x17]
    // 0x8cd3c4: cmp             x25, x0
    // 0x8cd3c8: b.ne            #0x8cd4d0
    // 0x8cd3cc: add             x24, x19, #1
    // 0x8cd3d0: ldur            x0, [fp, #-8]
    // 0x8cd3d4: mov             x1, x24
    // 0x8cd3d8: cmp             x1, x0
    // 0x8cd3dc: b.hs            #0x8cd69c
    // 0x8cd3e0: ArrayLoad: r25 = r12[r24]  ; TypedUnsigned_1
    //     0x8cd3e0: add             x16, x12, x24
    //     0x8cd3e4: ldrb            w25, [x16, #0x17]
    // 0x8cd3e8: add             x19, x9, #1
    // 0x8cd3ec: ldur            x0, [fp, #-8]
    // 0x8cd3f0: mov             x1, x19
    // 0x8cd3f4: cmp             x1, x0
    // 0x8cd3f8: b.hs            #0x8cd6a0
    // 0x8cd3fc: ArrayLoad: r0 = r12[r19]  ; TypedUnsigned_1
    //     0x8cd3fc: add             x16, x12, x19
    //     0x8cd400: ldrb            w0, [x16, #0x17]
    // 0x8cd404: cmp             x25, x0
    // 0x8cd408: b.ne            #0x8cd4b4
    // 0x8cd40c: add             x9, x24, #1
    // 0x8cd410: ldur            x0, [fp, #-8]
    // 0x8cd414: mov             x1, x9
    // 0x8cd418: cmp             x1, x0
    // 0x8cd41c: b.hs            #0x8cd6a4
    // 0x8cd420: ArrayLoad: r25 = r12[r9]  ; TypedUnsigned_1
    //     0x8cd420: add             x16, x12, x9
    //     0x8cd424: ldrb            w25, [x16, #0x17]
    // 0x8cd428: add             x24, x19, #1
    // 0x8cd42c: ldur            x0, [fp, #-8]
    // 0x8cd430: mov             x1, x24
    // 0x8cd434: cmp             x1, x0
    // 0x8cd438: b.hs            #0x8cd6a8
    // 0x8cd43c: ArrayLoad: r0 = r12[r24]  ; TypedUnsigned_1
    //     0x8cd43c: add             x16, x12, x24
    //     0x8cd440: ldrb            w0, [x16, #0x17]
    // 0x8cd444: cmp             x25, x0
    // 0x8cd448: b.ne            #0x8cd4ac
    // 0x8cd44c: add             x25, x9, #1
    // 0x8cd450: ldur            x0, [fp, #-8]
    // 0x8cd454: mov             x1, x25
    // 0x8cd458: cmp             x1, x0
    // 0x8cd45c: b.hs            #0x8cd6ac
    // 0x8cd460: ArrayLoad: r9 = r12[r25]  ; TypedUnsigned_1
    //     0x8cd460: add             x16, x12, x25
    //     0x8cd464: ldrb            w9, [x16, #0x17]
    // 0x8cd468: add             x19, x24, #1
    // 0x8cd46c: ldur            x0, [fp, #-8]
    // 0x8cd470: mov             x1, x19
    // 0x8cd474: cmp             x1, x0
    // 0x8cd478: b.hs            #0x8cd6b0
    // 0x8cd47c: ArrayLoad: r0 = r12[r19]  ; TypedUnsigned_1
    //     0x8cd47c: add             x16, x12, x19
    //     0x8cd480: ldrb            w0, [x16, #0x17]
    // 0x8cd484: cmp             x9, x0
    // 0x8cd488: b.ne            #0x8cd4a4
    // 0x8cd48c: cmp             x25, x11
    // 0x8cd490: b.ge            #0x8cd49c
    // 0x8cd494: mov             x24, x25
    // 0x8cd498: b               #0x8cd280
    // 0x8cd49c: mov             x19, x25
    // 0x8cd4a0: b               #0x8cd4d0
    // 0x8cd4a4: mov             x19, x25
    // 0x8cd4a8: b               #0x8cd4d0
    // 0x8cd4ac: mov             x19, x9
    // 0x8cd4b0: b               #0x8cd4d0
    // 0x8cd4b4: mov             x19, x24
    // 0x8cd4b8: b               #0x8cd4d0
    // 0x8cd4bc: mov             x19, x9
    // 0x8cd4c0: b               #0x8cd4d0
    // 0x8cd4c4: mov             x19, x24
    // 0x8cd4c8: b               #0x8cd4d0
    // 0x8cd4cc: mov             x19, x9
    // 0x8cd4d0: sub             x24, x11, x19
    // 0x8cd4d4: sub             x19, x3, x24
    // 0x8cd4d8: cmp             x19, x13
    // 0x8cd4dc: b.le            #0x8cd538
    // 0x8cd4e0: StoreField: r4->field_7f = r20
    //     0x8cd4e0: stur            x20, [x4, #0x7f]
    // 0x8cd4e4: cmp             x19, x6
    // 0x8cd4e8: b.lt            #0x8cd4f4
    // 0x8cd4ec: mov             x0, x19
    // 0x8cd4f0: b               #0x8cd5ac
    // 0x8cd4f4: add             x8, x7, x19
    // 0x8cd4f8: sub             x9, x8, #1
    // 0x8cd4fc: ldur            x0, [fp, #-8]
    // 0x8cd500: mov             x1, x9
    // 0x8cd504: cmp             x1, x0
    // 0x8cd508: b.hs            #0x8cd6b4
    // 0x8cd50c: ArrayLoad: r24 = r12[r9]  ; TypedUnsigned_1
    //     0x8cd50c: add             x16, x12, x9
    //     0x8cd510: ldrb            w24, [x16, #0x17]
    // 0x8cd514: ldur            x0, [fp, #-8]
    // 0x8cd518: mov             x1, x8
    // 0x8cd51c: cmp             x1, x0
    // 0x8cd520: b.hs            #0x8cd6b8
    // 0x8cd524: ArrayLoad: r25 = r12[r8]  ; TypedUnsigned_1
    //     0x8cd524: add             x16, x12, x8
    //     0x8cd528: ldrb            w25, [x16, #0x17]
    // 0x8cd52c: mov             x13, x19
    // 0x8cd530: mov             x10, x24
    // 0x8cd534: mov             x8, x25
    // 0x8cd538: mov             x19, x7
    // 0x8cd53c: LoadField: r24 = r4->field_4f
    //     0x8cd53c: ldur            w24, [x4, #0x4f]
    // 0x8cd540: DecompressPointer r24
    //     0x8cd540: add             x24, x24, HEAP, lsl #32
    // 0x8cd544: r16 = Sentinel
    //     0x8cd544: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cd548: cmp             w24, w16
    // 0x8cd54c: b.eq            #0x8cd6bc
    // 0x8cd550: and             x9, x20, x23
    // 0x8cd554: LoadField: r20 = r24->field_13
    //     0x8cd554: ldur            w20, [x24, #0x13]
    // 0x8cd558: DecompressPointer r20
    //     0x8cd558: add             x20, x20, HEAP, lsl #32
    // 0x8cd55c: r0 = LoadInt32Instr(r20)
    //     0x8cd55c: sbfx            x0, x20, #1, #0x1f
    // 0x8cd560: mov             x1, x9
    // 0x8cd564: cmp             x1, x0
    // 0x8cd568: b.hs            #0x8cd6c8
    // 0x8cd56c: add             x16, x24, x9, lsl #1
    // 0x8cd570: ldurh           w1, [x16, #0x17]
    // 0x8cd574: ubfx            x1, x1, #0, #0x20
    // 0x8cd578: and             x0, x1, x2
    // 0x8cd57c: mov             x1, x0
    // 0x8cd580: ubfx            x1, x1, #0, #0x20
    // 0x8cd584: cmp             x1, x5
    // 0x8cd588: b.le            #0x8cd5a8
    // 0x8cd58c: sub             x1, x14, #1
    // 0x8cd590: cbz             x1, #0x8cd5a8
    // 0x8cd594: ubfx            x0, x0, #0, #0x20
    // 0x8cd598: mov             x20, x0
    // 0x8cd59c: mov             x14, x1
    // 0x8cd5a0: mov             x9, x19
    // 0x8cd5a4: b               #0x8cd19c
    // 0x8cd5a8: mov             x0, x13
    // 0x8cd5ac: LoadField: r1 = r4->field_87
    //     0x8cd5ac: ldur            w1, [x4, #0x87]
    // 0x8cd5b0: DecompressPointer r1
    //     0x8cd5b0: add             x1, x1, HEAP, lsl #32
    // 0x8cd5b4: r16 = Sentinel
    //     0x8cd5b4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cd5b8: cmp             w1, w16
    // 0x8cd5bc: b.eq            #0x8cd6cc
    // 0x8cd5c0: r2 = LoadInt32Instr(r1)
    //     0x8cd5c0: sbfx            x2, x1, #1, #0x1f
    //     0x8cd5c4: tbz             w1, #0, #0x8cd5cc
    //     0x8cd5c8: ldur            x2, [x1, #7]
    // 0x8cd5cc: cmp             x0, x2
    // 0x8cd5d0: b.gt            #0x8cd5e0
    // 0x8cd5d4: LeaveFrame
    //     0x8cd5d4: mov             SP, fp
    //     0x8cd5d8: ldp             fp, lr, [SP], #0x10
    // 0x8cd5dc: ret
    //     0x8cd5dc: ret             
    // 0x8cd5e0: mov             x0, x2
    // 0x8cd5e4: LeaveFrame
    //     0x8cd5e4: mov             SP, fp
    //     0x8cd5e8: ldp             fp, lr, [SP], #0x10
    // 0x8cd5ec: ret
    //     0x8cd5ec: ret             
    // 0x8cd5f0: r9 = _config
    //     0x8cd5f0: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a30] Field <Deflate._config@60040000>: static late (offset: 0xa84)
    //     0x8cd5f4: ldr             x9, [x9, #0xa30]
    // 0x8cd5f8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cd5f8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cd5fc: r9 = _strStart
    //     0x8cd5fc: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a58] Field <Deflate._strStart@60040000>: late (offset: 0x7c)
    //     0x8cd600: ldr             x9, [x9, #0xa58]
    // 0x8cd604: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cd604: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cd608: r9 = _prevLength
    //     0x8cd608: add             x9, PP, #0x34, lsl #12  ; [pp+0x34aa8] Field <Deflate._prevLength@60040000>: late (offset: 0x8c)
    //     0x8cd60c: ldr             x9, [x9, #0xaa8]
    // 0x8cd610: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cd610: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cd614: r9 = _windowSize
    //     0x8cd614: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a98] Field <Deflate._windowSize@60040000>: late (offset: 0x3c)
    //     0x8cd618: ldr             x9, [x9, #0xa98]
    // 0x8cd61c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cd61c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cd620: r9 = _windowMask
    //     0x8cd620: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a88] Field <Deflate._windowMask@60040000>: late (offset: 0x44)
    //     0x8cd624: ldr             x9, [x9, #0xa88]
    // 0x8cd628: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cd628: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cd62c: r9 = _window
    //     0x8cd62c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a38] Field <Deflate._window@60040000>: late (offset: 0x48)
    //     0x8cd630: ldr             x9, [x9, #0xa38]
    // 0x8cd634: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cd634: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cd638: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd638: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd63c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd63c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd640: r9 = _lookAhead
    //     0x8cd640: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a28] Field <Deflate._lookAhead@60040000>: late (offset: 0x88)
    //     0x8cd644: ldr             x9, [x9, #0xa28]
    // 0x8cd648: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cd648: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cd64c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cd64c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cd650: b               #0x8cd1a8
    // 0x8cd654: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd654: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd658: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd658: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd65c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd65c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd660: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd660: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd664: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd664: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd668: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd668: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd66c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cd66c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cd670: b               #0x8cd28c
    // 0x8cd674: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd674: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd678: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd678: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd67c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd67c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd680: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd680: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd684: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd684: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd688: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd688: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd68c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd68c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd690: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd690: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd694: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd694: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd698: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd698: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd69c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd69c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd6a0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd6a0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd6a4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd6a4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd6a8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd6a8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd6ac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd6ac: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd6b0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd6b0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd6b4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd6b4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd6b8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd6b8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd6bc: r9 = _prev
    //     0x8cd6bc: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a80] Field <Deflate._prev@60040000>: late (offset: 0x50)
    //     0x8cd6c0: ldr             x9, [x9, #0xa80]
    // 0x8cd6c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cd6c4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cd6c8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cd6c8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cd6cc: r9 = _lookAhead
    //     0x8cd6cc: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a28] Field <Deflate._lookAhead@60040000>: late (offset: 0x88)
    //     0x8cd6d0: ldr             x9, [x9, #0xa28]
    // 0x8cd6d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cd6d4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _flushBlockOnly(/* No info */) {
    // ** addr: 0x8cd6d8, size: 0xfc
    // 0x8cd6d8: EnterFrame
    //     0x8cd6d8: stp             fp, lr, [SP, #-0x10]!
    //     0x8cd6dc: mov             fp, SP
    // 0x8cd6e0: CheckStackOverflow
    //     0x8cd6e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cd6e4: cmp             SP, x16
    //     0x8cd6e8: b.ls            #0x8cd7b4
    // 0x8cd6ec: ldr             x2, [fp, #0x18]
    // 0x8cd6f0: LoadField: r0 = r2->field_6b
    //     0x8cd6f0: ldur            w0, [x2, #0x6b]
    // 0x8cd6f4: DecompressPointer r0
    //     0x8cd6f4: add             x0, x0, HEAP, lsl #32
    // 0x8cd6f8: r16 = Sentinel
    //     0x8cd6f8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cd6fc: cmp             w0, w16
    // 0x8cd700: b.eq            #0x8cd7bc
    // 0x8cd704: r1 = LoadInt32Instr(r0)
    //     0x8cd704: sbfx            x1, x0, #1, #0x1f
    //     0x8cd708: tbz             w0, #0, #0x8cd710
    //     0x8cd70c: ldur            x1, [x0, #7]
    // 0x8cd710: tbnz            x1, #0x3f, #0x8cd71c
    // 0x8cd714: mov             x3, x1
    // 0x8cd718: b               #0x8cd720
    // 0x8cd71c: r3 = -1
    //     0x8cd71c: mov             x3, #-1
    // 0x8cd720: LoadField: r0 = r2->field_7b
    //     0x8cd720: ldur            w0, [x2, #0x7b]
    // 0x8cd724: DecompressPointer r0
    //     0x8cd724: add             x0, x0, HEAP, lsl #32
    // 0x8cd728: r16 = Sentinel
    //     0x8cd728: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cd72c: cmp             w0, w16
    // 0x8cd730: b.eq            #0x8cd7c8
    // 0x8cd734: r4 = LoadInt32Instr(r0)
    //     0x8cd734: sbfx            x4, x0, #1, #0x1f
    //     0x8cd738: tbz             w0, #0, #0x8cd740
    //     0x8cd73c: ldur            x4, [x0, #7]
    // 0x8cd740: sub             x5, x4, x1
    // 0x8cd744: r0 = BoxInt64Instr(r3)
    //     0x8cd744: sbfiz           x0, x3, #1, #0x1f
    //     0x8cd748: cmp             x3, x0, asr #1
    //     0x8cd74c: b.eq            #0x8cd758
    //     0x8cd750: bl              #0xd69bb8
    //     0x8cd754: stur            x3, [x0, #7]
    // 0x8cd758: stp             x0, x2, [SP, #-0x10]!
    // 0x8cd75c: ldr             x16, [fp, #0x10]
    // 0x8cd760: stp             x16, x5, [SP, #-0x10]!
    // 0x8cd764: r0 = _trFlushBlock()
    //     0x8cd764: bl              #0x8cd7d4  ; [package:archive/src/zlib/deflate.dart] Deflate::_trFlushBlock
    // 0x8cd768: add             SP, SP, #0x20
    // 0x8cd76c: ldr             x1, [fp, #0x18]
    // 0x8cd770: LoadField: r0 = r1->field_7b
    //     0x8cd770: ldur            w0, [x1, #0x7b]
    // 0x8cd774: DecompressPointer r0
    //     0x8cd774: add             x0, x0, HEAP, lsl #32
    // 0x8cd778: StoreField: r1->field_6b = r0
    //     0x8cd778: stur            w0, [x1, #0x6b]
    //     0x8cd77c: tbz             w0, #0, #0x8cd798
    //     0x8cd780: ldurb           w16, [x1, #-1]
    //     0x8cd784: ldurb           w17, [x0, #-1]
    //     0x8cd788: and             x16, x17, x16, lsr #2
    //     0x8cd78c: tst             x16, HEAP, lsr #32
    //     0x8cd790: b.eq            #0x8cd798
    //     0x8cd794: bl              #0xd6826c
    // 0x8cd798: SaveReg r1
    //     0x8cd798: str             x1, [SP, #-8]!
    // 0x8cd79c: r0 = _flushPending()
    //     0x8cd79c: bl              #0x8cb4ac  ; [package:archive/src/zlib/deflate.dart] Deflate::_flushPending
    // 0x8cd7a0: add             SP, SP, #8
    // 0x8cd7a4: r0 = Null
    //     0x8cd7a4: mov             x0, NULL
    // 0x8cd7a8: LeaveFrame
    //     0x8cd7a8: mov             SP, fp
    //     0x8cd7ac: ldp             fp, lr, [SP], #0x10
    // 0x8cd7b0: ret
    //     0x8cd7b0: ret             
    // 0x8cd7b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cd7b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cd7b8: b               #0x8cd6ec
    // 0x8cd7bc: r9 = _blockStart
    //     0x8cd7bc: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ab0] Field <Deflate._blockStart@60040000>: late (offset: 0x6c)
    //     0x8cd7c0: ldr             x9, [x9, #0xab0]
    // 0x8cd7c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cd7c4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cd7c8: r9 = _strStart
    //     0x8cd7c8: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a58] Field <Deflate._strStart@60040000>: late (offset: 0x7c)
    //     0x8cd7cc: ldr             x9, [x9, #0xa58]
    // 0x8cd7d0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cd7d0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _trFlushBlock(/* No info */) {
    // ** addr: 0x8cd7d4, size: 0x394
    // 0x8cd7d4: EnterFrame
    //     0x8cd7d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8cd7d8: mov             fp, SP
    // 0x8cd7dc: AllocStack(0x8)
    //     0x8cd7dc: sub             SP, SP, #8
    // 0x8cd7e0: CheckStackOverflow
    //     0x8cd7e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cd7e4: cmp             SP, x16
    //     0x8cd7e8: b.ls            #0x8cdb0c
    // 0x8cd7ec: ldr             x0, [fp, #0x28]
    // 0x8cd7f0: LoadField: r1 = r0->field_8f
    //     0x8cd7f0: ldur            w1, [x0, #0x8f]
    // 0x8cd7f4: DecompressPointer r1
    //     0x8cd7f4: add             x1, x1, HEAP, lsl #32
    // 0x8cd7f8: r16 = Sentinel
    //     0x8cd7f8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cd7fc: cmp             w1, w16
    // 0x8cd800: b.eq            #0x8cdb14
    // 0x8cd804: r2 = LoadInt32Instr(r1)
    //     0x8cd804: sbfx            x2, x1, #1, #0x1f
    //     0x8cd808: tbz             w1, #0, #0x8cd810
    //     0x8cd80c: ldur            x2, [x1, #7]
    // 0x8cd810: cmp             x2, #0
    // 0x8cd814: b.le            #0x8cd908
    // 0x8cd818: LoadField: r1 = r0->field_33
    //     0x8cd818: ldur            x1, [x0, #0x33]
    // 0x8cd81c: lsl             x2, x1, #1
    // 0x8cd820: cmp             w2, #4
    // 0x8cd824: b.ne            #0x8cd834
    // 0x8cd828: SaveReg r0
    //     0x8cd828: str             x0, [SP, #-8]!
    // 0x8cd82c: r0 = setDataType()
    //     0x8cd82c: bl              #0x8d0964  ; [package:archive/src/zlib/deflate.dart] Deflate::setDataType
    // 0x8cd830: add             SP, SP, #8
    // 0x8cd834: ldr             x0, [fp, #0x28]
    // 0x8cd838: LoadField: r1 = r0->field_a3
    //     0x8cd838: ldur            w1, [x0, #0xa3]
    // 0x8cd83c: DecompressPointer r1
    //     0x8cd83c: add             x1, x1, HEAP, lsl #32
    // 0x8cd840: stp             x0, x1, [SP, #-0x10]!
    // 0x8cd844: r0 = _buildTree()
    //     0x8cd844: bl              #0x8cf434  ; [package:archive/src/zlib/deflate.dart] _HuffmanTree::_buildTree
    // 0x8cd848: add             SP, SP, #0x10
    // 0x8cd84c: ldr             x0, [fp, #0x28]
    // 0x8cd850: LoadField: r1 = r0->field_a7
    //     0x8cd850: ldur            w1, [x0, #0xa7]
    // 0x8cd854: DecompressPointer r1
    //     0x8cd854: add             x1, x1, HEAP, lsl #32
    // 0x8cd858: stp             x0, x1, [SP, #-0x10]!
    // 0x8cd85c: r0 = _buildTree()
    //     0x8cd85c: bl              #0x8cf434  ; [package:archive/src/zlib/deflate.dart] _HuffmanTree::_buildTree
    // 0x8cd860: add             SP, SP, #0x10
    // 0x8cd864: ldr             x16, [fp, #0x28]
    // 0x8cd868: SaveReg r16
    //     0x8cd868: str             x16, [SP, #-8]!
    // 0x8cd86c: r0 = _buildBitLengthTree()
    //     0x8cd86c: bl              #0x8cedec  ; [package:archive/src/zlib/deflate.dart] Deflate::_buildBitLengthTree
    // 0x8cd870: add             SP, SP, #8
    // 0x8cd874: mov             x1, x0
    // 0x8cd878: ldr             x0, [fp, #0x28]
    // 0x8cd87c: LoadField: r2 = r0->field_d3
    //     0x8cd87c: ldur            w2, [x0, #0xd3]
    // 0x8cd880: DecompressPointer r2
    //     0x8cd880: add             x2, x2, HEAP, lsl #32
    // 0x8cd884: r16 = Sentinel
    //     0x8cd884: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cd888: cmp             w2, w16
    // 0x8cd88c: b.eq            #0x8cdb20
    // 0x8cd890: r3 = LoadInt32Instr(r2)
    //     0x8cd890: sbfx            x3, x2, #1, #0x1f
    //     0x8cd894: tbz             w2, #0, #0x8cd89c
    //     0x8cd898: ldur            x3, [x2, #7]
    // 0x8cd89c: add             x2, x3, #3
    // 0x8cd8a0: add             x3, x2, #7
    // 0x8cd8a4: tbnz            x3, #0x3f, #0x8cd8b0
    // 0x8cd8a8: asr             x2, x3, #3
    // 0x8cd8ac: b               #0x8cd8b4
    // 0x8cd8b0: asr             x2, x3, #3
    // 0x8cd8b4: LoadField: r3 = r0->field_d7
    //     0x8cd8b4: ldur            w3, [x0, #0xd7]
    // 0x8cd8b8: DecompressPointer r3
    //     0x8cd8b8: add             x3, x3, HEAP, lsl #32
    // 0x8cd8bc: r16 = Sentinel
    //     0x8cd8bc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cd8c0: cmp             w3, w16
    // 0x8cd8c4: b.eq            #0x8cdb2c
    // 0x8cd8c8: r4 = LoadInt32Instr(r3)
    //     0x8cd8c8: sbfx            x4, x3, #1, #0x1f
    //     0x8cd8cc: tbz             w3, #0, #0x8cd8d4
    //     0x8cd8d0: ldur            x4, [x3, #7]
    // 0x8cd8d4: add             x3, x4, #3
    // 0x8cd8d8: add             x4, x3, #7
    // 0x8cd8dc: tbnz            x4, #0x3f, #0x8cd8e8
    // 0x8cd8e0: asr             x3, x4, #3
    // 0x8cd8e4: b               #0x8cd8ec
    // 0x8cd8e8: asr             x3, x4, #3
    // 0x8cd8ec: cmp             x3, x2
    // 0x8cd8f0: b.gt            #0x8cd8f8
    // 0x8cd8f4: mov             x2, x3
    // 0x8cd8f8: mov             x4, x2
    // 0x8cd8fc: mov             x2, x1
    // 0x8cd900: ldr             x1, [fp, #0x18]
    // 0x8cd904: b               #0x8cd91c
    // 0x8cd908: ldr             x1, [fp, #0x18]
    // 0x8cd90c: add             x2, x1, #5
    // 0x8cd910: mov             x4, x2
    // 0x8cd914: mov             x3, x2
    // 0x8cd918: r2 = 0
    //     0x8cd918: mov             x2, #0
    // 0x8cd91c: stur            x2, [fp, #-8]
    // 0x8cd920: add             x5, x1, #4
    // 0x8cd924: cmp             x5, x4
    // 0x8cd928: b.gt            #0x8cd95c
    // 0x8cd92c: ldr             x5, [fp, #0x20]
    // 0x8cd930: r6 = LoadInt32Instr(r5)
    //     0x8cd930: sbfx            x6, x5, #1, #0x1f
    //     0x8cd934: tbz             w5, #0, #0x8cd93c
    //     0x8cd938: ldur            x6, [x5, #7]
    // 0x8cd93c: cmn             x6, #1
    // 0x8cd940: b.eq            #0x8cd95c
    // 0x8cd944: stp             x5, x0, [SP, #-0x10]!
    // 0x8cd948: ldr             x16, [fp, #0x10]
    // 0x8cd94c: stp             x16, x1, [SP, #-0x10]!
    // 0x8cd950: r0 = _trStoredBlock()
    //     0x8cd950: bl              #0x8cba84  ; [package:archive/src/zlib/deflate.dart] Deflate::_trStoredBlock
    // 0x8cd954: add             SP, SP, #0x20
    // 0x8cd958: b               #0x8cdad0
    // 0x8cd95c: cmp             x3, x4
    // 0x8cd960: b.ne            #0x8cd9c0
    // 0x8cd964: ldr             x1, [fp, #0x10]
    // 0x8cd968: r0 = 3
    //     0x8cd968: mov             x0, #3
    // 0x8cd96c: tst             x1, #0x10
    // 0x8cd970: cset            x2, eq
    // 0x8cd974: lsl             x2, x2, #1
    // 0x8cd978: r3 = LoadInt32Instr(r2)
    //     0x8cd978: sbfx            x3, x2, #1, #0x1f
    // 0x8cd97c: add             x2, x3, #2
    // 0x8cd980: lsl             x3, x2, #1
    // 0x8cd984: ldr             x16, [fp, #0x28]
    // 0x8cd988: stp             x3, x16, [SP, #-0x10]!
    // 0x8cd98c: SaveReg r0
    //     0x8cd98c: str             x0, [SP, #-8]!
    // 0x8cd990: r0 = _sendBits()
    //     0x8cd990: bl              #0x8cbef4  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendBits
    // 0x8cd994: add             SP, SP, #0x18
    // 0x8cd998: ldr             x16, [fp, #0x28]
    // 0x8cd99c: r30 = const [0xc, 0x8, 0x8c, 0x8, 0x4c, 0x8, 0xcc, 0x8, 0x2c, 0x8, 0xac, 0x8, 0x6c, 0x8, 0xec, 0x8, 0x1c, 0x8, 0x9c, 0x8, 0x5c, 0x8, 0xdc, 0x8, 0x3c, 0x8, 0xbc, 0x8, 0x7c, 0x8, 0xfc, 0x8, 0x2, 0x8, 0x82, 0x8, 0x42, 0x8, 0xc2, 0x8, 0x22, 0x8, 0xa2, 0x8, 0x62, 0x8, 0xe2, 0x8, 0x12, 0x8, 0x92, 0x8, 0x52, 0x8, 0xd2, 0x8, 0x32, 0x8, 0xb2, 0x8, 0x72, 0x8, 0xf2, 0x8, 0xa, 0x8, 0x8a, 0x8, 0x4a, 0x8, 0xca, 0x8, 0x2a, 0x8, 0xaa, 0x8, 0x6a, 0x8, 0xea, 0x8, 0x1a, 0x8, 0x9a, 0x8, 0x5a, 0x8, 0xda, 0x8, 0x3a, 0x8, 0xba, 0x8, 0x7a, 0x8, 0xfa, 0x8, 0x6, 0x8, 0x86, 0x8, 0x46, 0x8, 0xc6, 0x8, 0x26, 0x8, 0xa6, 0x8, 0x66, 0x8, 0xe6, 0x8, 0x16, 0x8, 0x96, 0x8, 0x56, 0x8, 0xd6, 0x8, 0x36, 0x8, 0xb6, 0x8, 0x76, 0x8, 0xf6, 0x8, 0xe, 0x8, 0x8e, 0x8, 0x4e, 0x8, 0xce, 0x8, 0x2e, 0x8, 0xae, 0x8, 0x6e, 0x8, 0xee, 0x8, 0x1e, 0x8, 0x9e, 0x8, 0x5e, 0x8, 0xde, 0x8, 0x3e, 0x8, 0xbe, 0x8, 0x7e, 0x8, 0xfe, 0x8, 0x1, 0x8, 0x81, 0x8, 0x41, 0x8, 0xc1, 0x8, 0x21, 0x8, 0xa1, 0x8, 0x61, 0x8, 0xe1, 0x8, 0x11, 0x8, 0x91, 0x8, 0x51, 0x8, 0xd1, 0x8, 0x31, 0x8, 0xb1, 0x8, 0x71, 0x8, 0xf1, 0x8, 0x9, 0x8, 0x89, 0x8, 0x49, 0x8, 0xc9, 0x8, 0x29, 0x8, 0xa9, 0x8, 0x69, 0x8, 0xe9, 0x8, 0x19, 0x8, 0x99, 0x8, 0x59, 0x8, 0xd9, 0x8, 0x39, 0x8, 0xb9, 0x8, 0x79, 0x8, 0xf9, 0x8, 0x5, 0x8, 0x85, 0x8, 0x45, 0x8, 0xc5, 0x8, 0x25, 0x8, 0xa5, 0x8, 0x65, 0x8, 0xe5, 0x8, 0x15, 0x8, 0x95, 0x8, 0x55, 0x8, 0xd5, 0x8, 0x35, 0x8, 0xb5, 0x8, 0x75, 0x8, 0xf5, 0x8, 0xd, 0x8, 0x8d, 0x8, 0x4d, 0x8, 0xcd, 0x8, 0x2d, 0x8, 0xad, 0x8, 0x6d, 0x8, 0xed, 0x8, 0x1d, 0x8, 0x9d, 0x8, 0x5d, 0x8, 0xdd, 0x8, 0x3d, 0x8, 0xbd, 0x8, 0x7d, 0x8, 0xfd, 0x8, 0x13, 0x9, 0x113, 0x9, 0x93, 0x9, 0x193, 0x9, 0x53, 0x9, 0x153, 0x9, 0xd3, 0x9, 0x1d3, 0x9, 0x33, 0x9, 0x133, 0x9, 0xb3, 0x9, 0x1b3, 0x9, 0x73, 0x9, 0x173, 0x9, 0xf3, 0x9, 0x1f3, 0x9, 0xb, 0x9, 0x10b, 0x9, 0x8b, 0x9, 0x18b, 0x9, 0x4b, 0x9, 0x14b, 0x9, 0xcb, 0x9, 0x1cb, 0x9, 0x2b, 0x9, 0x12b, 0x9, 0xab, 0x9, 0x1ab, 0x9, 0x6b, 0x9, 0x16b, 0x9, 0xeb, 0x9, 0x1eb, 0x9, 0x1b, 0x9, 0x11b, 0x9, 0x9b, 0x9, 0x19b, 0x9, 0x5b, 0x9, 0x15b, 0x9, 0xdb, 0x9, 0x1db, 0x9, 0x3b, 0x9, 0x13b, 0x9, 0xbb, 0x9, 0x1bb, 0x9, 0x7b, 0x9, 0x17b, 0x9, 0xfb, 0x9, 0x1fb, 0x9, 0x7, 0x9, 0x107, 0x9, 0x87, 0x9, 0x187, 0x9, 0x47, 0x9, 0x147, 0x9, 0xc7, 0x9, 0x1c7, 0x9, 0x27, 0x9, 0x127, 0x9, 0xa7, 0x9, 0x1a7, 0x9, 0x67, 0x9, 0x167, 0x9, 0xe7, 0x9, 0x1e7, 0x9, 0x17, 0x9, 0x117, 0x9, 0x97, 0x9, 0x197, 0x9, 0x57, 0x9, 0x157, 0x9, 0xd7, 0x9, 0x1d7, 0x9, 0x37, 0x9, 0x137, 0x9, 0xb7, 0x9, 0x1b7, 0x9, 0x77, 0x9, 0x177, 0x9, 0xf7, 0x9, 0x1f7, 0x9, 0xf, 0x9, 0x10f, 0x9, 0x8f, 0x9, 0x18f, 0x9, 0x4f, 0x9, 0x14f, 0x9, 0xcf, 0x9, 0x1cf, 0x9, 0x2f, 0x9, 0x12f, 0x9, 0xaf, 0x9, 0x1af, 0x9, 0x6f, 0x9, 0x16f, 0x9, 0xef, 0x9, 0x1ef, 0x9, 0x1f, 0x9, 0x11f, 0x9, 0x9f, 0x9, 0x19f, 0x9, 0x5f, 0x9, 0x15f, 0x9, 0xdf, 0x9, 0x1df, 0x9, 0x3f, 0x9, 0x13f, 0x9, 0xbf, 0x9, 0x1bf, 0x9, 0x7f, 0x9, 0x17f, 0x9, 0xff, 0x9, 0x1ff, 0x9, 0, 0x7, 0x40, 0x7, 0x20, 0x7, 0x60, 0x7, 0x10, 0x7, 0x50, 0x7, 0x30, 0x7, 0x70, 0x7, 0x8, 0x7, 0x48, 0x7, 0x28, 0x7, 0x68, 0x7, 0x18, 0x7, 0x58, 0x7, 0x38, 0x7, 0x78, 0x7, 0x4, 0x7, 0x44, 0x7, 0x24, 0x7, 0x64, 0x7, 0x14, 0x7, 0x54, 0x7, 0x34, 0x7, 0x74, 0x7, 0x3, 0x8, 0x83, 0x8, 0x43, 0x8, 0xc3, 0x8, 0x23, 0x8, 0xa3, 0x8, 0x63, 0x8, 0xe3, 0x8]
    //     0x8cd99c: add             lr, PP, #0x34, lsl #12  ; [pp+0x34ab8] List<int>(576)
    //     0x8cd9a0: ldr             lr, [lr, #0xab8]
    // 0x8cd9a4: stp             lr, x16, [SP, #-0x10]!
    // 0x8cd9a8: r16 = const [0, 0x5, 0x10, 0x5, 0x8, 0x5, 0x18, 0x5, 0x4, 0x5, 0x14, 0x5, 0xc, 0x5, 0x1c, 0x5, 0x2, 0x5, 0x12, 0x5, 0xa, 0x5, 0x1a, 0x5, 0x6, 0x5, 0x16, 0x5, 0xe, 0x5, 0x1e, 0x5, 0x1, 0x5, 0x11, 0x5, 0x9, 0x5, 0x19, 0x5, 0x5, 0x5, 0x15, 0x5, 0xd, 0x5, 0x1d, 0x5, 0x3, 0x5, 0x13, 0x5, 0xb, 0x5, 0x1b, 0x5, 0x7, 0x5, 0x17, 0x5]
    //     0x8cd9a8: add             x16, PP, #0x34, lsl #12  ; [pp+0x34ac0] List<int>(60)
    //     0x8cd9ac: ldr             x16, [x16, #0xac0]
    // 0x8cd9b0: SaveReg r16
    //     0x8cd9b0: str             x16, [SP, #-8]!
    // 0x8cd9b4: r0 = _compressBlock()
    //     0x8cd9b4: bl              #0x8ce6bc  ; [package:archive/src/zlib/deflate.dart] Deflate::_compressBlock
    // 0x8cd9b8: add             SP, SP, #0x18
    // 0x8cd9bc: b               #0x8cdad0
    // 0x8cd9c0: ldr             x3, [fp, #0x28]
    // 0x8cd9c4: ldr             x1, [fp, #0x10]
    // 0x8cd9c8: r0 = 3
    //     0x8cd9c8: mov             x0, #3
    // 0x8cd9cc: tst             x1, #0x10
    // 0x8cd9d0: cset            x4, eq
    // 0x8cd9d4: lsl             x4, x4, #1
    // 0x8cd9d8: r5 = LoadInt32Instr(r4)
    //     0x8cd9d8: sbfx            x5, x4, #1, #0x1f
    // 0x8cd9dc: add             x4, x5, #4
    // 0x8cd9e0: lsl             x5, x4, #1
    // 0x8cd9e4: stp             x5, x3, [SP, #-0x10]!
    // 0x8cd9e8: SaveReg r0
    //     0x8cd9e8: str             x0, [SP, #-8]!
    // 0x8cd9ec: r0 = _sendBits()
    //     0x8cd9ec: bl              #0x8cbef4  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendBits
    // 0x8cd9f0: add             SP, SP, #0x18
    // 0x8cd9f4: ldr             x2, [fp, #0x28]
    // 0x8cd9f8: LoadField: r0 = r2->field_a3
    //     0x8cd9f8: ldur            w0, [x2, #0xa3]
    // 0x8cd9fc: DecompressPointer r0
    //     0x8cd9fc: add             x0, x0, HEAP, lsl #32
    // 0x8cda00: LoadField: r1 = r0->field_b
    //     0x8cda00: ldur            w1, [x0, #0xb]
    // 0x8cda04: DecompressPointer r1
    //     0x8cda04: add             x1, x1, HEAP, lsl #32
    // 0x8cda08: r16 = Sentinel
    //     0x8cda08: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cda0c: cmp             w1, w16
    // 0x8cda10: b.eq            #0x8cdb38
    // 0x8cda14: r0 = LoadInt32Instr(r1)
    //     0x8cda14: sbfx            x0, x1, #1, #0x1f
    //     0x8cda18: tbz             w1, #0, #0x8cda20
    //     0x8cda1c: ldur            x0, [x1, #7]
    // 0x8cda20: add             x3, x0, #1
    // 0x8cda24: LoadField: r0 = r2->field_a7
    //     0x8cda24: ldur            w0, [x2, #0xa7]
    // 0x8cda28: DecompressPointer r0
    //     0x8cda28: add             x0, x0, HEAP, lsl #32
    // 0x8cda2c: LoadField: r1 = r0->field_b
    //     0x8cda2c: ldur            w1, [x0, #0xb]
    // 0x8cda30: DecompressPointer r1
    //     0x8cda30: add             x1, x1, HEAP, lsl #32
    // 0x8cda34: r16 = Sentinel
    //     0x8cda34: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cda38: cmp             w1, w16
    // 0x8cda3c: b.eq            #0x8cdb44
    // 0x8cda40: r0 = LoadInt32Instr(r1)
    //     0x8cda40: sbfx            x0, x1, #1, #0x1f
    //     0x8cda44: tbz             w1, #0, #0x8cda4c
    //     0x8cda48: ldur            x0, [x1, #7]
    // 0x8cda4c: add             x4, x0, #1
    // 0x8cda50: ldur            x0, [fp, #-8]
    // 0x8cda54: add             x5, x0, #1
    // 0x8cda58: r0 = BoxInt64Instr(r3)
    //     0x8cda58: sbfiz           x0, x3, #1, #0x1f
    //     0x8cda5c: cmp             x3, x0, asr #1
    //     0x8cda60: b.eq            #0x8cda6c
    //     0x8cda64: bl              #0xd69bb8
    //     0x8cda68: stur            x3, [x0, #7]
    // 0x8cda6c: mov             x3, x0
    // 0x8cda70: r0 = BoxInt64Instr(r4)
    //     0x8cda70: sbfiz           x0, x4, #1, #0x1f
    //     0x8cda74: cmp             x4, x0, asr #1
    //     0x8cda78: b.eq            #0x8cda84
    //     0x8cda7c: bl              #0xd69bb8
    //     0x8cda80: stur            x4, [x0, #7]
    // 0x8cda84: stp             x3, x2, [SP, #-0x10]!
    // 0x8cda88: stp             x5, x0, [SP, #-0x10]!
    // 0x8cda8c: r0 = _sendAllTrees()
    //     0x8cda8c: bl              #0x8cdd48  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendAllTrees
    // 0x8cda90: add             SP, SP, #0x20
    // 0x8cda94: ldr             x0, [fp, #0x28]
    // 0x8cda98: LoadField: r1 = r0->field_97
    //     0x8cda98: ldur            w1, [x0, #0x97]
    // 0x8cda9c: DecompressPointer r1
    //     0x8cda9c: add             x1, x1, HEAP, lsl #32
    // 0x8cdaa0: r16 = Sentinel
    //     0x8cdaa0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cdaa4: cmp             w1, w16
    // 0x8cdaa8: b.eq            #0x8cdb50
    // 0x8cdaac: LoadField: r2 = r0->field_9b
    //     0x8cdaac: ldur            w2, [x0, #0x9b]
    // 0x8cdab0: DecompressPointer r2
    //     0x8cdab0: add             x2, x2, HEAP, lsl #32
    // 0x8cdab4: r16 = Sentinel
    //     0x8cdab4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cdab8: cmp             w2, w16
    // 0x8cdabc: b.eq            #0x8cdb5c
    // 0x8cdac0: stp             x1, x0, [SP, #-0x10]!
    // 0x8cdac4: SaveReg r2
    //     0x8cdac4: str             x2, [SP, #-8]!
    // 0x8cdac8: r0 = _compressBlock()
    //     0x8cdac8: bl              #0x8ce6bc  ; [package:archive/src/zlib/deflate.dart] Deflate::_compressBlock
    // 0x8cdacc: add             SP, SP, #0x18
    // 0x8cdad0: ldr             x0, [fp, #0x10]
    // 0x8cdad4: ldr             x16, [fp, #0x28]
    // 0x8cdad8: SaveReg r16
    //     0x8cdad8: str             x16, [SP, #-8]!
    // 0x8cdadc: r0 = _initBlock()
    //     0x8cdadc: bl              #0x8cdb68  ; [package:archive/src/zlib/deflate.dart] Deflate::_initBlock
    // 0x8cdae0: add             SP, SP, #8
    // 0x8cdae4: ldr             x0, [fp, #0x10]
    // 0x8cdae8: tbnz            w0, #4, #0x8cdafc
    // 0x8cdaec: ldr             x16, [fp, #0x28]
    // 0x8cdaf0: SaveReg r16
    //     0x8cdaf0: str             x16, [SP, #-8]!
    // 0x8cdaf4: r0 = _biWindup()
    //     0x8cdaf4: bl              #0x8cbe04  ; [package:archive/src/zlib/deflate.dart] Deflate::_biWindup
    // 0x8cdaf8: add             SP, SP, #8
    // 0x8cdafc: r0 = Null
    //     0x8cdafc: mov             x0, NULL
    // 0x8cdb00: LeaveFrame
    //     0x8cdb00: mov             SP, fp
    //     0x8cdb04: ldp             fp, lr, [SP], #0x10
    // 0x8cdb08: ret
    //     0x8cdb08: ret             
    // 0x8cdb0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cdb0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cdb10: b               #0x8cd7ec
    // 0x8cdb14: r9 = _level
    //     0x8cdb14: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ac8] Field <Deflate._level@60040000>: late (offset: 0x90)
    //     0x8cdb18: ldr             x9, [x9, #0xac8]
    // 0x8cdb1c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cdb1c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cdb20: r9 = _optimalLen
    //     0x8cdb20: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ad0] Field <Deflate._optimalLen@60040000>: late (offset: 0xd4)
    //     0x8cdb24: ldr             x9, [x9, #0xad0]
    // 0x8cdb28: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cdb28: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cdb2c: r9 = _staticLen
    //     0x8cdb2c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ad8] Field <Deflate._staticLen@60040000>: late (offset: 0xd8)
    //     0x8cdb30: ldr             x9, [x9, #0xad8]
    // 0x8cdb34: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cdb34: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cdb38: r9 = maxCode
    //     0x8cdb38: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ae0] Field <_HuffmanTree@60040000.maxCode>: late (offset: 0xc)
    //     0x8cdb3c: ldr             x9, [x9, #0xae0]
    // 0x8cdb40: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cdb40: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cdb44: r9 = maxCode
    //     0x8cdb44: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ae0] Field <_HuffmanTree@60040000.maxCode>: late (offset: 0xc)
    //     0x8cdb48: ldr             x9, [x9, #0xae0]
    // 0x8cdb4c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cdb4c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cdb50: r9 = _dynamicLengthTree
    //     0x8cdb50: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ae8] Field <Deflate._dynamicLengthTree@60040000>: late (offset: 0x98)
    //     0x8cdb54: ldr             x9, [x9, #0xae8]
    // 0x8cdb58: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cdb58: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cdb5c: r9 = _dynamicDistTree
    //     0x8cdb5c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34af0] Field <Deflate._dynamicDistTree@60040000>: late (offset: 0x9c)
    //     0x8cdb60: ldr             x9, [x9, #0xaf0]
    // 0x8cdb64: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cdb64: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _initBlock(/* No info */) {
    // ** addr: 0x8cdb68, size: 0x1e0
    // 0x8cdb68: EnterFrame
    //     0x8cdb68: stp             fp, lr, [SP, #-0x10]!
    //     0x8cdb6c: mov             fp, SP
    // 0x8cdb70: ldr             x2, [fp, #0x10]
    // 0x8cdb74: LoadField: r3 = r2->field_97
    //     0x8cdb74: ldur            w3, [x2, #0x97]
    // 0x8cdb78: DecompressPointer r3
    //     0x8cdb78: add             x3, x3, HEAP, lsl #32
    // 0x8cdb7c: r16 = Sentinel
    //     0x8cdb7c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cdb80: cmp             w3, w16
    // 0x8cdb84: b.eq            #0x8cdcf0
    // 0x8cdb88: LoadField: r4 = r3->field_13
    //     0x8cdb88: ldur            w4, [x3, #0x13]
    // 0x8cdb8c: DecompressPointer r4
    //     0x8cdb8c: add             x4, x4, HEAP, lsl #32
    // 0x8cdb90: r5 = LoadInt32Instr(r4)
    //     0x8cdb90: sbfx            x5, x4, #1, #0x1f
    // 0x8cdb94: r4 = 0
    //     0x8cdb94: mov             x4, #0
    // 0x8cdb98: CheckStackOverflow
    //     0x8cdb98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cdb9c: cmp             SP, x16
    //     0x8cdba0: b.ls            #0x8cdcfc
    // 0x8cdba4: cmp             x4, #0x11e
    // 0x8cdba8: b.ge            #0x8cdbd4
    // 0x8cdbac: lsl             x6, x4, #1
    // 0x8cdbb0: mov             x0, x5
    // 0x8cdbb4: mov             x1, x6
    // 0x8cdbb8: cmp             x1, x0
    // 0x8cdbbc: b.hs            #0x8cdd04
    // 0x8cdbc0: ArrayStore: r3[r6] = rZR  ; TypeUnknown_2
    //     0x8cdbc0: add             x7, x3, x6, lsl #1
    //     0x8cdbc4: sturh           wzr, [x7, #0x17]
    // 0x8cdbc8: add             x0, x4, #1
    // 0x8cdbcc: mov             x4, x0
    // 0x8cdbd0: b               #0x8cdb98
    // 0x8cdbd4: LoadField: r3 = r2->field_9b
    //     0x8cdbd4: ldur            w3, [x2, #0x9b]
    // 0x8cdbd8: DecompressPointer r3
    //     0x8cdbd8: add             x3, x3, HEAP, lsl #32
    // 0x8cdbdc: r16 = Sentinel
    //     0x8cdbdc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cdbe0: cmp             w3, w16
    // 0x8cdbe4: b.eq            #0x8cdd08
    // 0x8cdbe8: LoadField: r4 = r3->field_13
    //     0x8cdbe8: ldur            w4, [x3, #0x13]
    // 0x8cdbec: DecompressPointer r4
    //     0x8cdbec: add             x4, x4, HEAP, lsl #32
    // 0x8cdbf0: r5 = LoadInt32Instr(r4)
    //     0x8cdbf0: sbfx            x5, x4, #1, #0x1f
    // 0x8cdbf4: r4 = 0
    //     0x8cdbf4: mov             x4, #0
    // 0x8cdbf8: CheckStackOverflow
    //     0x8cdbf8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cdbfc: cmp             SP, x16
    //     0x8cdc00: b.ls            #0x8cdd14
    // 0x8cdc04: cmp             x4, #0x1e
    // 0x8cdc08: b.ge            #0x8cdc34
    // 0x8cdc0c: lsl             x6, x4, #1
    // 0x8cdc10: mov             x0, x5
    // 0x8cdc14: mov             x1, x6
    // 0x8cdc18: cmp             x1, x0
    // 0x8cdc1c: b.hs            #0x8cdd1c
    // 0x8cdc20: ArrayStore: r3[r6] = rZR  ; TypeUnknown_2
    //     0x8cdc20: add             x7, x3, x6, lsl #1
    //     0x8cdc24: sturh           wzr, [x7, #0x17]
    // 0x8cdc28: add             x0, x4, #1
    // 0x8cdc2c: mov             x4, x0
    // 0x8cdc30: b               #0x8cdbf8
    // 0x8cdc34: LoadField: r3 = r2->field_9f
    //     0x8cdc34: ldur            w3, [x2, #0x9f]
    // 0x8cdc38: DecompressPointer r3
    //     0x8cdc38: add             x3, x3, HEAP, lsl #32
    // 0x8cdc3c: r16 = Sentinel
    //     0x8cdc3c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cdc40: cmp             w3, w16
    // 0x8cdc44: b.eq            #0x8cdd20
    // 0x8cdc48: LoadField: r4 = r3->field_13
    //     0x8cdc48: ldur            w4, [x3, #0x13]
    // 0x8cdc4c: DecompressPointer r4
    //     0x8cdc4c: add             x4, x4, HEAP, lsl #32
    // 0x8cdc50: r5 = LoadInt32Instr(r4)
    //     0x8cdc50: sbfx            x5, x4, #1, #0x1f
    // 0x8cdc54: r4 = 0
    //     0x8cdc54: mov             x4, #0
    // 0x8cdc58: CheckStackOverflow
    //     0x8cdc58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cdc5c: cmp             SP, x16
    //     0x8cdc60: b.ls            #0x8cdd2c
    // 0x8cdc64: cmp             x4, #0x13
    // 0x8cdc68: b.ge            #0x8cdc94
    // 0x8cdc6c: lsl             x6, x4, #1
    // 0x8cdc70: mov             x0, x5
    // 0x8cdc74: mov             x1, x6
    // 0x8cdc78: cmp             x1, x0
    // 0x8cdc7c: b.hs            #0x8cdd34
    // 0x8cdc80: ArrayStore: r3[r6] = rZR  ; TypeUnknown_2
    //     0x8cdc80: add             x7, x3, x6, lsl #1
    //     0x8cdc84: sturh           wzr, [x7, #0x17]
    // 0x8cdc88: add             x0, x4, #1
    // 0x8cdc8c: mov             x4, x0
    // 0x8cdc90: b               #0x8cdc58
    // 0x8cdc94: r4 = 1
    //     0x8cdc94: mov             x4, #1
    // 0x8cdc98: r3 = 512
    //     0x8cdc98: mov             x3, #0x200
    // 0x8cdc9c: LoadField: r5 = r2->field_97
    //     0x8cdc9c: ldur            w5, [x2, #0x97]
    // 0x8cdca0: DecompressPointer r5
    //     0x8cdca0: add             x5, x5, HEAP, lsl #32
    // 0x8cdca4: r16 = Sentinel
    //     0x8cdca4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cdca8: cmp             w5, w16
    // 0x8cdcac: b.eq            #0x8cdd38
    // 0x8cdcb0: LoadField: r6 = r5->field_13
    //     0x8cdcb0: ldur            w6, [x5, #0x13]
    // 0x8cdcb4: DecompressPointer r6
    //     0x8cdcb4: add             x6, x6, HEAP, lsl #32
    // 0x8cdcb8: r0 = LoadInt32Instr(r6)
    //     0x8cdcb8: sbfx            x0, x6, #1, #0x1f
    // 0x8cdcbc: mov             x1, x3
    // 0x8cdcc0: cmp             x1, x0
    // 0x8cdcc4: b.hs            #0x8cdd44
    // 0x8cdcc8: ArrayStore: r5[r3] = r4  ; TypeUnknown_2
    //     0x8cdcc8: add             x1, x5, x3, lsl #1
    //     0x8cdccc: sturh           w4, [x1, #0x17]
    // 0x8cdcd0: StoreField: r2->field_d7 = rZR
    //     0x8cdcd0: stur            wzr, [x2, #0xd7]
    // 0x8cdcd4: StoreField: r2->field_d3 = rZR
    //     0x8cdcd4: stur            wzr, [x2, #0xd3]
    // 0x8cdcd8: StoreField: r2->field_db = rZR
    //     0x8cdcd8: stur            wzr, [x2, #0xdb]
    // 0x8cdcdc: StoreField: r2->field_cb = rZR
    //     0x8cdcdc: stur            wzr, [x2, #0xcb]
    // 0x8cdce0: r0 = Null
    //     0x8cdce0: mov             x0, NULL
    // 0x8cdce4: LeaveFrame
    //     0x8cdce4: mov             SP, fp
    //     0x8cdce8: ldp             fp, lr, [SP], #0x10
    // 0x8cdcec: ret
    //     0x8cdcec: ret             
    // 0x8cdcf0: r9 = _dynamicLengthTree
    //     0x8cdcf0: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ae8] Field <Deflate._dynamicLengthTree@60040000>: late (offset: 0x98)
    //     0x8cdcf4: ldr             x9, [x9, #0xae8]
    // 0x8cdcf8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cdcf8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cdcfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cdcfc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cdd00: b               #0x8cdba4
    // 0x8cdd04: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cdd04: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cdd08: r9 = _dynamicDistTree
    //     0x8cdd08: add             x9, PP, #0x34, lsl #12  ; [pp+0x34af0] Field <Deflate._dynamicDistTree@60040000>: late (offset: 0x9c)
    //     0x8cdd0c: ldr             x9, [x9, #0xaf0]
    // 0x8cdd10: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cdd10: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cdd14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cdd14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cdd18: b               #0x8cdc04
    // 0x8cdd1c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cdd1c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cdd20: r9 = _bitLengthTree
    //     0x8cdd20: add             x9, PP, #0x34, lsl #12  ; [pp+0x34af8] Field <Deflate._bitLengthTree@60040000>: late (offset: 0xa0)
    //     0x8cdd24: ldr             x9, [x9, #0xaf8]
    // 0x8cdd28: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cdd28: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cdd2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cdd2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cdd30: b               #0x8cdc64
    // 0x8cdd34: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cdd34: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cdd38: r9 = _dynamicLengthTree
    //     0x8cdd38: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ae8] Field <Deflate._dynamicLengthTree@60040000>: late (offset: 0x98)
    //     0x8cdd3c: ldr             x9, [x9, #0xae8]
    // 0x8cdd40: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cdd40: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cdd44: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cdd44: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _sendAllTrees(/* No info */) {
    // ** addr: 0x8cdd48, size: 0x238
    // 0x8cdd48: EnterFrame
    //     0x8cdd48: stp             fp, lr, [SP, #-0x10]!
    //     0x8cdd4c: mov             fp, SP
    // 0x8cdd50: AllocStack(0x18)
    //     0x8cdd50: sub             SP, SP, #0x18
    // 0x8cdd54: r2 = 5
    //     0x8cdd54: mov             x2, #5
    // 0x8cdd58: CheckStackOverflow
    //     0x8cdd58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cdd5c: cmp             SP, x16
    //     0x8cdd60: b.ls            #0x8cdf44
    // 0x8cdd64: ldr             x0, [fp, #0x20]
    // 0x8cdd68: r3 = LoadInt32Instr(r0)
    //     0x8cdd68: sbfx            x3, x0, #1, #0x1f
    //     0x8cdd6c: tbz             w0, #0, #0x8cdd74
    //     0x8cdd70: ldur            x3, [x0, #7]
    // 0x8cdd74: stur            x3, [fp, #-8]
    // 0x8cdd78: sub             x4, x3, #0x101
    // 0x8cdd7c: r0 = BoxInt64Instr(r4)
    //     0x8cdd7c: sbfiz           x0, x4, #1, #0x1f
    //     0x8cdd80: cmp             x4, x0, asr #1
    //     0x8cdd84: b.eq            #0x8cdd90
    //     0x8cdd88: bl              #0xd69bb8
    //     0x8cdd8c: stur            x4, [x0, #7]
    // 0x8cdd90: ldr             x16, [fp, #0x28]
    // 0x8cdd94: stp             x0, x16, [SP, #-0x10]!
    // 0x8cdd98: SaveReg r2
    //     0x8cdd98: str             x2, [SP, #-8]!
    // 0x8cdd9c: r0 = _sendBits()
    //     0x8cdd9c: bl              #0x8cbef4  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendBits
    // 0x8cdda0: add             SP, SP, #0x18
    // 0x8cdda4: ldr             x0, [fp, #0x18]
    // 0x8cdda8: r1 = LoadInt32Instr(r0)
    //     0x8cdda8: sbfx            x1, x0, #1, #0x1f
    //     0x8cddac: tbz             w0, #0, #0x8cddb4
    //     0x8cddb0: ldur            x1, [x0, #7]
    // 0x8cddb4: sub             x2, x1, #1
    // 0x8cddb8: stur            x2, [fp, #-0x10]
    // 0x8cddbc: r0 = BoxInt64Instr(r2)
    //     0x8cddbc: sbfiz           x0, x2, #1, #0x1f
    //     0x8cddc0: cmp             x2, x0, asr #1
    //     0x8cddc4: b.eq            #0x8cddd0
    //     0x8cddc8: bl              #0xd69bb8
    //     0x8cddcc: stur            x2, [x0, #7]
    // 0x8cddd0: ldr             x16, [fp, #0x28]
    // 0x8cddd4: stp             x0, x16, [SP, #-0x10]!
    // 0x8cddd8: r0 = 5
    //     0x8cddd8: mov             x0, #5
    // 0x8cdddc: SaveReg r0
    //     0x8cdddc: str             x0, [SP, #-8]!
    // 0x8cdde0: r0 = _sendBits()
    //     0x8cdde0: bl              #0x8cbef4  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendBits
    // 0x8cdde4: add             SP, SP, #0x18
    // 0x8cdde8: ldr             x2, [fp, #0x10]
    // 0x8cddec: sub             x3, x2, #4
    // 0x8cddf0: r0 = BoxInt64Instr(r3)
    //     0x8cddf0: sbfiz           x0, x3, #1, #0x1f
    //     0x8cddf4: cmp             x3, x0, asr #1
    //     0x8cddf8: b.eq            #0x8cde04
    //     0x8cddfc: bl              #0xd69bb8
    //     0x8cde00: stur            x3, [x0, #7]
    // 0x8cde04: ldr             x16, [fp, #0x28]
    // 0x8cde08: stp             x0, x16, [SP, #-0x10]!
    // 0x8cde0c: r0 = 4
    //     0x8cde0c: mov             x0, #4
    // 0x8cde10: SaveReg r0
    //     0x8cde10: str             x0, [SP, #-8]!
    // 0x8cde14: r0 = _sendBits()
    //     0x8cde14: bl              #0x8cbef4  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendBits
    // 0x8cde18: add             SP, SP, #0x18
    // 0x8cde1c: r6 = 0
    //     0x8cde1c: mov             x6, #0
    // 0x8cde20: ldr             x5, [fp, #0x28]
    // 0x8cde24: ldr             x2, [fp, #0x10]
    // 0x8cde28: r4 = const [0x10, 0x11, 0x12, 0, 0x8, 0x7, 0x9, 0x6, 0xa, 0x5, 0xb, 0x4, 0xc, 0x3, 0xd, 0x2, 0xe, 0x1, 0xf]
    //     0x8cde28: add             x4, PP, #0x34, lsl #12  ; [pp+0x34b00] List<int>(19)
    //     0x8cde2c: ldr             x4, [x4, #0xb00]
    // 0x8cde30: r3 = 3
    //     0x8cde30: mov             x3, #3
    // 0x8cde34: stur            x6, [fp, #-0x18]
    // 0x8cde38: CheckStackOverflow
    //     0x8cde38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cde3c: cmp             SP, x16
    //     0x8cde40: b.ls            #0x8cdf4c
    // 0x8cde44: cmp             x6, x2
    // 0x8cde48: b.ge            #0x8cded4
    // 0x8cde4c: LoadField: r7 = r5->field_9f
    //     0x8cde4c: ldur            w7, [x5, #0x9f]
    // 0x8cde50: DecompressPointer r7
    //     0x8cde50: add             x7, x7, HEAP, lsl #32
    // 0x8cde54: r16 = Sentinel
    //     0x8cde54: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cde58: cmp             w7, w16
    // 0x8cde5c: b.eq            #0x8cdf54
    // 0x8cde60: mov             x1, x6
    // 0x8cde64: r0 = 19
    //     0x8cde64: mov             x0, #0x13
    // 0x8cde68: cmp             x1, x0
    // 0x8cde6c: b.hs            #0x8cdf60
    // 0x8cde70: ArrayLoad: r0 = r4[r6]  ; Unknown_4
    //     0x8cde70: add             x16, x4, x6, lsl #2
    //     0x8cde74: ldur            w0, [x16, #0xf]
    // 0x8cde78: DecompressPointer r0
    //     0x8cde78: add             x0, x0, HEAP, lsl #32
    // 0x8cde7c: r1 = LoadInt32Instr(r0)
    //     0x8cde7c: sbfx            x1, x0, #1, #0x1f
    //     0x8cde80: tbz             w0, #0, #0x8cde88
    //     0x8cde84: ldur            x1, [x0, #7]
    // 0x8cde88: lsl             x0, x1, #1
    // 0x8cde8c: add             x8, x0, #1
    // 0x8cde90: LoadField: r0 = r7->field_13
    //     0x8cde90: ldur            w0, [x7, #0x13]
    // 0x8cde94: DecompressPointer r0
    //     0x8cde94: add             x0, x0, HEAP, lsl #32
    // 0x8cde98: r1 = LoadInt32Instr(r0)
    //     0x8cde98: sbfx            x1, x0, #1, #0x1f
    // 0x8cde9c: mov             x0, x1
    // 0x8cdea0: mov             x1, x8
    // 0x8cdea4: cmp             x1, x0
    // 0x8cdea8: b.hs            #0x8cdf64
    // 0x8cdeac: add             x16, x7, x8, lsl #1
    // 0x8cdeb0: ldurh           w0, [x16, #0x17]
    // 0x8cdeb4: lsl             x1, x0, #1
    // 0x8cdeb8: stp             x1, x5, [SP, #-0x10]!
    // 0x8cdebc: SaveReg r3
    //     0x8cdebc: str             x3, [SP, #-8]!
    // 0x8cdec0: r0 = _sendBits()
    //     0x8cdec0: bl              #0x8cbef4  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendBits
    // 0x8cdec4: add             SP, SP, #0x18
    // 0x8cdec8: ldur            x0, [fp, #-0x18]
    // 0x8cdecc: add             x6, x0, #1
    // 0x8cded0: b               #0x8cde20
    // 0x8cded4: mov             x0, x5
    // 0x8cded8: ldur            x1, [fp, #-0x10]
    // 0x8cdedc: ldur            x2, [fp, #-8]
    // 0x8cdee0: LoadField: r3 = r0->field_97
    //     0x8cdee0: ldur            w3, [x0, #0x97]
    // 0x8cdee4: DecompressPointer r3
    //     0x8cdee4: add             x3, x3, HEAP, lsl #32
    // 0x8cdee8: r16 = Sentinel
    //     0x8cdee8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cdeec: cmp             w3, w16
    // 0x8cdef0: b.eq            #0x8cdf68
    // 0x8cdef4: sub             x4, x2, #1
    // 0x8cdef8: stp             x3, x0, [SP, #-0x10]!
    // 0x8cdefc: SaveReg r4
    //     0x8cdefc: str             x4, [SP, #-8]!
    // 0x8cdf00: r0 = _sendTree()
    //     0x8cdf00: bl              #0x8cdf80  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendTree
    // 0x8cdf04: add             SP, SP, #0x18
    // 0x8cdf08: ldr             x0, [fp, #0x28]
    // 0x8cdf0c: LoadField: r1 = r0->field_9b
    //     0x8cdf0c: ldur            w1, [x0, #0x9b]
    // 0x8cdf10: DecompressPointer r1
    //     0x8cdf10: add             x1, x1, HEAP, lsl #32
    // 0x8cdf14: r16 = Sentinel
    //     0x8cdf14: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cdf18: cmp             w1, w16
    // 0x8cdf1c: b.eq            #0x8cdf74
    // 0x8cdf20: stp             x1, x0, [SP, #-0x10]!
    // 0x8cdf24: ldur            x0, [fp, #-0x10]
    // 0x8cdf28: SaveReg r0
    //     0x8cdf28: str             x0, [SP, #-8]!
    // 0x8cdf2c: r0 = _sendTree()
    //     0x8cdf2c: bl              #0x8cdf80  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendTree
    // 0x8cdf30: add             SP, SP, #0x18
    // 0x8cdf34: r0 = Null
    //     0x8cdf34: mov             x0, NULL
    // 0x8cdf38: LeaveFrame
    //     0x8cdf38: mov             SP, fp
    //     0x8cdf3c: ldp             fp, lr, [SP], #0x10
    // 0x8cdf40: ret
    //     0x8cdf40: ret             
    // 0x8cdf44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cdf44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cdf48: b               #0x8cdd64
    // 0x8cdf4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cdf4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cdf50: b               #0x8cde44
    // 0x8cdf54: r9 = _bitLengthTree
    //     0x8cdf54: add             x9, PP, #0x34, lsl #12  ; [pp+0x34af8] Field <Deflate._bitLengthTree@60040000>: late (offset: 0xa0)
    //     0x8cdf58: ldr             x9, [x9, #0xaf8]
    // 0x8cdf5c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cdf5c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cdf60: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cdf60: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cdf64: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cdf64: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cdf68: r9 = _dynamicLengthTree
    //     0x8cdf68: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ae8] Field <Deflate._dynamicLengthTree@60040000>: late (offset: 0x98)
    //     0x8cdf6c: ldr             x9, [x9, #0xae8]
    // 0x8cdf70: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cdf70: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cdf74: r9 = _dynamicDistTree
    //     0x8cdf74: add             x9, PP, #0x34, lsl #12  ; [pp+0x34af0] Field <Deflate._dynamicDistTree@60040000>: late (offset: 0x9c)
    //     0x8cdf78: ldr             x9, [x9, #0xaf0]
    // 0x8cdf7c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cdf7c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _sendTree(/* No info */) {
    // ** addr: 0x8cdf80, size: 0x638
    // 0x8cdf80: EnterFrame
    //     0x8cdf80: stp             fp, lr, [SP, #-0x10]!
    //     0x8cdf84: mov             fp, SP
    // 0x8cdf88: AllocStack(0x38)
    //     0x8cdf88: sub             SP, SP, #0x38
    // 0x8cdf8c: CheckStackOverflow
    //     0x8cdf8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cdf90: cmp             SP, x16
    //     0x8cdf94: b.ls            #0x8ce490
    // 0x8cdf98: ldr             x2, [fp, #0x18]
    // 0x8cdf9c: LoadField: r0 = r2->field_13
    //     0x8cdf9c: ldur            w0, [x2, #0x13]
    // 0x8cdfa0: DecompressPointer r0
    //     0x8cdfa0: add             x0, x0, HEAP, lsl #32
    // 0x8cdfa4: r3 = LoadInt32Instr(r0)
    //     0x8cdfa4: sbfx            x3, x0, #1, #0x1f
    // 0x8cdfa8: mov             x0, x3
    // 0x8cdfac: stur            x3, [fp, #-0x30]
    // 0x8cdfb0: r1 = 1
    //     0x8cdfb0: mov             x1, #1
    // 0x8cdfb4: cmp             x1, x0
    // 0x8cdfb8: b.hs            #0x8ce498
    // 0x8cdfbc: ldurh           w0, [x2, #0x19]
    // 0x8cdfc0: cbnz            x0, #0x8cdfd0
    // 0x8cdfc4: r4 = 138
    //     0x8cdfc4: mov             x4, #0x8a
    // 0x8cdfc8: r1 = 3
    //     0x8cdfc8: mov             x1, #3
    // 0x8cdfcc: b               #0x8cdfd8
    // 0x8cdfd0: r4 = 7
    //     0x8cdfd0: mov             x4, #7
    // 0x8cdfd4: r1 = 4
    //     0x8cdfd4: mov             x1, #4
    // 0x8cdfd8: mov             x11, x0
    // 0x8cdfdc: mov             x9, x4
    // 0x8cdfe0: mov             x8, x1
    // 0x8cdfe4: r0 = 0
    //     0x8cdfe4: mov             x0, #0
    // 0x8cdfe8: r12 = -1
    //     0x8cdfe8: mov             x12, #-1
    // 0x8cdfec: r10 = 0
    //     0x8cdfec: mov             x10, #0
    // 0x8cdff0: ldr             x7, [fp, #0x20]
    // 0x8cdff4: ldr             x6, [fp, #0x10]
    // 0x8cdff8: r5 = 1
    //     0x8cdff8: mov             x5, #1
    // 0x8cdffc: r4 = 65535
    //     0x8cdffc: mov             x4, #0xffff
    // 0x8ce000: stur            x11, [fp, #-0x28]
    // 0x8ce004: CheckStackOverflow
    //     0x8ce004: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8ce008: cmp             SP, x16
    //     0x8ce00c: b.ls            #0x8ce49c
    // 0x8ce010: cmp             x0, x6
    // 0x8ce014: b.gt            #0x8ce480
    // 0x8ce018: add             x13, x0, #1
    // 0x8ce01c: stur            x13, [fp, #-0x20]
    // 0x8ce020: cmp             x5, #0x3f
    // 0x8ce024: b.hi            #0x8ce4a4
    // 0x8ce028: lsl             x0, x13, x5
    // 0x8ce02c: add             x14, x0, #1
    // 0x8ce030: mov             x0, x3
    // 0x8ce034: mov             x1, x14
    // 0x8ce038: cmp             x1, x0
    // 0x8ce03c: b.hs            #0x8ce4e0
    // 0x8ce040: add             x16, x2, x14, lsl #1
    // 0x8ce044: ldurh           w19, [x16, #0x17]
    // 0x8ce048: stur            x19, [fp, #-0x18]
    // 0x8ce04c: add             x14, x10, #1
    // 0x8ce050: stur            x14, [fp, #-0x38]
    // 0x8ce054: cmp             x14, x9
    // 0x8ce058: b.ge            #0x8ce070
    // 0x8ce05c: cmp             x11, x19
    // 0x8ce060: b.ne            #0x8ce070
    // 0x8ce064: mov             x10, x14
    // 0x8ce068: mov             x11, x19
    // 0x8ce06c: b               #0x8ce470
    // 0x8ce070: cmp             x14, x8
    // 0x8ce074: b.ge            #0x8ce150
    // 0x8ce078: cmp             x5, #0x3f
    // 0x8ce07c: b.hi            #0x8ce4e4
    // 0x8ce080: lsl             x8, x11, x5
    // 0x8ce084: stur            x8, [fp, #-0x10]
    // 0x8ce088: mov             x10, x14
    // 0x8ce08c: stur            x10, [fp, #-8]
    // 0x8ce090: CheckStackOverflow
    //     0x8ce090: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8ce094: cmp             SP, x16
    //     0x8ce098: b.ls            #0x8ce51c
    // 0x8ce09c: LoadField: r12 = r7->field_9f
    //     0x8ce09c: ldur            w12, [x7, #0x9f]
    // 0x8ce0a0: DecompressPointer r12
    //     0x8ce0a0: add             x12, x12, HEAP, lsl #32
    // 0x8ce0a4: r16 = Sentinel
    //     0x8ce0a4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8ce0a8: cmp             w12, w16
    // 0x8ce0ac: b.eq            #0x8ce524
    // 0x8ce0b0: LoadField: r0 = r12->field_13
    //     0x8ce0b0: ldur            w0, [x12, #0x13]
    // 0x8ce0b4: DecompressPointer r0
    //     0x8ce0b4: add             x0, x0, HEAP, lsl #32
    // 0x8ce0b8: r9 = LoadInt32Instr(r0)
    //     0x8ce0b8: sbfx            x9, x0, #1, #0x1f
    // 0x8ce0bc: mov             x0, x9
    // 0x8ce0c0: mov             x1, x8
    // 0x8ce0c4: cmp             x1, x0
    // 0x8ce0c8: b.hs            #0x8ce530
    // 0x8ce0cc: add             x16, x12, x8, lsl #1
    // 0x8ce0d0: ldurh           w0, [x16, #0x17]
    // 0x8ce0d4: ubfx            x0, x0, #0, #0x20
    // 0x8ce0d8: and             x14, x0, x4
    // 0x8ce0dc: add             x20, x8, #1
    // 0x8ce0e0: mov             x0, x9
    // 0x8ce0e4: mov             x1, x20
    // 0x8ce0e8: cmp             x1, x0
    // 0x8ce0ec: b.hs            #0x8ce534
    // 0x8ce0f0: add             x16, x12, x20, lsl #1
    // 0x8ce0f4: ldurh           w0, [x16, #0x17]
    // 0x8ce0f8: ubfx            x0, x0, #0, #0x20
    // 0x8ce0fc: and             x1, x0, x4
    // 0x8ce100: lsl             w0, w14, #1
    // 0x8ce104: ubfx            x1, x1, #0, #0x20
    // 0x8ce108: stp             x0, x7, [SP, #-0x10]!
    // 0x8ce10c: SaveReg r1
    //     0x8ce10c: str             x1, [SP, #-8]!
    // 0x8ce110: r0 = _sendBits()
    //     0x8ce110: bl              #0x8cbef4  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendBits
    // 0x8ce114: add             SP, SP, #0x18
    // 0x8ce118: ldur            x0, [fp, #-8]
    // 0x8ce11c: sub             x10, x0, #1
    // 0x8ce120: cbz             x10, #0x8ce428
    // 0x8ce124: ldr             x7, [fp, #0x20]
    // 0x8ce128: ldr             x2, [fp, #0x18]
    // 0x8ce12c: ldr             x6, [fp, #0x10]
    // 0x8ce130: ldur            x11, [fp, #-0x28]
    // 0x8ce134: ldur            x13, [fp, #-0x20]
    // 0x8ce138: ldur            x3, [fp, #-0x30]
    // 0x8ce13c: ldur            x19, [fp, #-0x18]
    // 0x8ce140: ldur            x8, [fp, #-0x10]
    // 0x8ce144: r5 = 1
    //     0x8ce144: mov             x5, #1
    // 0x8ce148: r4 = 65535
    //     0x8ce148: mov             x4, #0xffff
    // 0x8ce14c: b               #0x8ce08c
    // 0x8ce150: mov             x2, x11
    // 0x8ce154: cbz             x2, #0x8ce2c0
    // 0x8ce158: cmp             x2, x12
    // 0x8ce15c: b.eq            #0x8ce204
    // 0x8ce160: ldr             x5, [fp, #0x20]
    // 0x8ce164: r4 = 1
    //     0x8ce164: mov             x4, #1
    // 0x8ce168: r3 = 65535
    //     0x8ce168: mov             x3, #0xffff
    // 0x8ce16c: LoadField: r6 = r5->field_9f
    //     0x8ce16c: ldur            w6, [x5, #0x9f]
    // 0x8ce170: DecompressPointer r6
    //     0x8ce170: add             x6, x6, HEAP, lsl #32
    // 0x8ce174: r16 = Sentinel
    //     0x8ce174: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8ce178: cmp             w6, w16
    // 0x8ce17c: b.eq            #0x8ce538
    // 0x8ce180: cmp             x4, #0x3f
    // 0x8ce184: b.hi            #0x8ce544
    // 0x8ce188: lsl             x7, x2, x4
    // 0x8ce18c: LoadField: r0 = r6->field_13
    //     0x8ce18c: ldur            w0, [x6, #0x13]
    // 0x8ce190: DecompressPointer r0
    //     0x8ce190: add             x0, x0, HEAP, lsl #32
    // 0x8ce194: r8 = LoadInt32Instr(r0)
    //     0x8ce194: sbfx            x8, x0, #1, #0x1f
    // 0x8ce198: mov             x0, x8
    // 0x8ce19c: mov             x1, x7
    // 0x8ce1a0: cmp             x1, x0
    // 0x8ce1a4: b.hs            #0x8ce574
    // 0x8ce1a8: add             x16, x6, x7, lsl #1
    // 0x8ce1ac: ldurh           w0, [x16, #0x17]
    // 0x8ce1b0: ubfx            x0, x0, #0, #0x20
    // 0x8ce1b4: and             x9, x0, x3
    // 0x8ce1b8: add             x10, x7, #1
    // 0x8ce1bc: mov             x0, x8
    // 0x8ce1c0: mov             x1, x10
    // 0x8ce1c4: cmp             x1, x0
    // 0x8ce1c8: b.hs            #0x8ce578
    // 0x8ce1cc: add             x16, x6, x10, lsl #1
    // 0x8ce1d0: ldurh           w0, [x16, #0x17]
    // 0x8ce1d4: ubfx            x0, x0, #0, #0x20
    // 0x8ce1d8: and             x1, x0, x3
    // 0x8ce1dc: lsl             w0, w9, #1
    // 0x8ce1e0: ubfx            x1, x1, #0, #0x20
    // 0x8ce1e4: stp             x0, x5, [SP, #-0x10]!
    // 0x8ce1e8: SaveReg r1
    //     0x8ce1e8: str             x1, [SP, #-8]!
    // 0x8ce1ec: r0 = _sendBits()
    //     0x8ce1ec: bl              #0x8cbef4  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendBits
    // 0x8ce1f0: add             SP, SP, #0x18
    // 0x8ce1f4: ldur            x2, [fp, #-0x38]
    // 0x8ce1f8: sub             x1, x2, #1
    // 0x8ce1fc: mov             x4, x1
    // 0x8ce200: b               #0x8ce20c
    // 0x8ce204: mov             x2, x14
    // 0x8ce208: mov             x4, x2
    // 0x8ce20c: ldr             x3, [fp, #0x20]
    // 0x8ce210: r2 = 65535
    //     0x8ce210: mov             x2, #0xffff
    // 0x8ce214: stur            x4, [fp, #-8]
    // 0x8ce218: LoadField: r5 = r3->field_9f
    //     0x8ce218: ldur            w5, [x3, #0x9f]
    // 0x8ce21c: DecompressPointer r5
    //     0x8ce21c: add             x5, x5, HEAP, lsl #32
    // 0x8ce220: r16 = Sentinel
    //     0x8ce220: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8ce224: cmp             w5, w16
    // 0x8ce228: b.eq            #0x8ce57c
    // 0x8ce22c: LoadField: r0 = r5->field_13
    //     0x8ce22c: ldur            w0, [x5, #0x13]
    // 0x8ce230: DecompressPointer r0
    //     0x8ce230: add             x0, x0, HEAP, lsl #32
    // 0x8ce234: r6 = LoadInt32Instr(r0)
    //     0x8ce234: sbfx            x6, x0, #1, #0x1f
    // 0x8ce238: mov             x0, x6
    // 0x8ce23c: r1 = 32
    //     0x8ce23c: mov             x1, #0x20
    // 0x8ce240: cmp             x1, x0
    // 0x8ce244: b.hs            #0x8ce588
    // 0x8ce248: ldurh           w0, [x5, #0x57]
    // 0x8ce24c: ubfx            x0, x0, #0, #0x20
    // 0x8ce250: and             x7, x0, x2
    // 0x8ce254: mov             x0, x6
    // 0x8ce258: r1 = 33
    //     0x8ce258: mov             x1, #0x21
    // 0x8ce25c: cmp             x1, x0
    // 0x8ce260: b.hs            #0x8ce58c
    // 0x8ce264: ldurh           w0, [x5, #0x59]
    // 0x8ce268: ubfx            x0, x0, #0, #0x20
    // 0x8ce26c: and             x1, x0, x2
    // 0x8ce270: lsl             w0, w7, #1
    // 0x8ce274: ubfx            x1, x1, #0, #0x20
    // 0x8ce278: stp             x0, x3, [SP, #-0x10]!
    // 0x8ce27c: SaveReg r1
    //     0x8ce27c: str             x1, [SP, #-8]!
    // 0x8ce280: r0 = _sendBits()
    //     0x8ce280: bl              #0x8cbef4  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendBits
    // 0x8ce284: add             SP, SP, #0x18
    // 0x8ce288: ldur            x0, [fp, #-8]
    // 0x8ce28c: sub             x2, x0, #3
    // 0x8ce290: r0 = BoxInt64Instr(r2)
    //     0x8ce290: sbfiz           x0, x2, #1, #0x1f
    //     0x8ce294: cmp             x2, x0, asr #1
    //     0x8ce298: b.eq            #0x8ce2a4
    //     0x8ce29c: bl              #0xd69bb8
    //     0x8ce2a0: stur            x2, [x0, #7]
    // 0x8ce2a4: ldr             x16, [fp, #0x20]
    // 0x8ce2a8: stp             x0, x16, [SP, #-0x10]!
    // 0x8ce2ac: r0 = 2
    //     0x8ce2ac: mov             x0, #2
    // 0x8ce2b0: SaveReg r0
    //     0x8ce2b0: str             x0, [SP, #-8]!
    // 0x8ce2b4: r0 = _sendBits()
    //     0x8ce2b4: bl              #0x8cbef4  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendBits
    // 0x8ce2b8: add             SP, SP, #0x18
    // 0x8ce2bc: b               #0x8ce428
    // 0x8ce2c0: mov             x2, x14
    // 0x8ce2c4: cmp             x2, #0xa
    // 0x8ce2c8: b.gt            #0x8ce37c
    // 0x8ce2cc: ldr             x4, [fp, #0x20]
    // 0x8ce2d0: r3 = 65535
    //     0x8ce2d0: mov             x3, #0xffff
    // 0x8ce2d4: LoadField: r5 = r4->field_9f
    //     0x8ce2d4: ldur            w5, [x4, #0x9f]
    // 0x8ce2d8: DecompressPointer r5
    //     0x8ce2d8: add             x5, x5, HEAP, lsl #32
    // 0x8ce2dc: r16 = Sentinel
    //     0x8ce2dc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8ce2e0: cmp             w5, w16
    // 0x8ce2e4: b.eq            #0x8ce590
    // 0x8ce2e8: LoadField: r0 = r5->field_13
    //     0x8ce2e8: ldur            w0, [x5, #0x13]
    // 0x8ce2ec: DecompressPointer r0
    //     0x8ce2ec: add             x0, x0, HEAP, lsl #32
    // 0x8ce2f0: r6 = LoadInt32Instr(r0)
    //     0x8ce2f0: sbfx            x6, x0, #1, #0x1f
    // 0x8ce2f4: mov             x0, x6
    // 0x8ce2f8: r1 = 34
    //     0x8ce2f8: mov             x1, #0x22
    // 0x8ce2fc: cmp             x1, x0
    // 0x8ce300: b.hs            #0x8ce59c
    // 0x8ce304: ldurh           w0, [x5, #0x5b]
    // 0x8ce308: ubfx            x0, x0, #0, #0x20
    // 0x8ce30c: and             x7, x0, x3
    // 0x8ce310: mov             x0, x6
    // 0x8ce314: r1 = 35
    //     0x8ce314: mov             x1, #0x23
    // 0x8ce318: cmp             x1, x0
    // 0x8ce31c: b.hs            #0x8ce5a0
    // 0x8ce320: ldurh           w0, [x5, #0x5d]
    // 0x8ce324: ubfx            x0, x0, #0, #0x20
    // 0x8ce328: and             x1, x0, x3
    // 0x8ce32c: lsl             w0, w7, #1
    // 0x8ce330: ubfx            x1, x1, #0, #0x20
    // 0x8ce334: stp             x0, x4, [SP, #-0x10]!
    // 0x8ce338: SaveReg r1
    //     0x8ce338: str             x1, [SP, #-8]!
    // 0x8ce33c: r0 = _sendBits()
    //     0x8ce33c: bl              #0x8cbef4  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendBits
    // 0x8ce340: add             SP, SP, #0x18
    // 0x8ce344: ldur            x2, [fp, #-0x38]
    // 0x8ce348: sub             x3, x2, #3
    // 0x8ce34c: r0 = BoxInt64Instr(r3)
    //     0x8ce34c: sbfiz           x0, x3, #1, #0x1f
    //     0x8ce350: cmp             x3, x0, asr #1
    //     0x8ce354: b.eq            #0x8ce360
    //     0x8ce358: bl              #0xd69bb8
    //     0x8ce35c: stur            x3, [x0, #7]
    // 0x8ce360: ldr             x16, [fp, #0x20]
    // 0x8ce364: stp             x0, x16, [SP, #-0x10]!
    // 0x8ce368: r0 = 3
    //     0x8ce368: mov             x0, #3
    // 0x8ce36c: SaveReg r0
    //     0x8ce36c: str             x0, [SP, #-8]!
    // 0x8ce370: r0 = _sendBits()
    //     0x8ce370: bl              #0x8cbef4  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendBits
    // 0x8ce374: add             SP, SP, #0x18
    // 0x8ce378: b               #0x8ce428
    // 0x8ce37c: ldr             x4, [fp, #0x20]
    // 0x8ce380: r3 = 65535
    //     0x8ce380: mov             x3, #0xffff
    // 0x8ce384: LoadField: r5 = r4->field_9f
    //     0x8ce384: ldur            w5, [x4, #0x9f]
    // 0x8ce388: DecompressPointer r5
    //     0x8ce388: add             x5, x5, HEAP, lsl #32
    // 0x8ce38c: r16 = Sentinel
    //     0x8ce38c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8ce390: cmp             w5, w16
    // 0x8ce394: b.eq            #0x8ce5a4
    // 0x8ce398: LoadField: r0 = r5->field_13
    //     0x8ce398: ldur            w0, [x5, #0x13]
    // 0x8ce39c: DecompressPointer r0
    //     0x8ce39c: add             x0, x0, HEAP, lsl #32
    // 0x8ce3a0: r6 = LoadInt32Instr(r0)
    //     0x8ce3a0: sbfx            x6, x0, #1, #0x1f
    // 0x8ce3a4: mov             x0, x6
    // 0x8ce3a8: r1 = 36
    //     0x8ce3a8: mov             x1, #0x24
    // 0x8ce3ac: cmp             x1, x0
    // 0x8ce3b0: b.hs            #0x8ce5b0
    // 0x8ce3b4: ldurh           w0, [x5, #0x5f]
    // 0x8ce3b8: ubfx            x0, x0, #0, #0x20
    // 0x8ce3bc: and             x7, x0, x3
    // 0x8ce3c0: mov             x0, x6
    // 0x8ce3c4: r1 = 37
    //     0x8ce3c4: mov             x1, #0x25
    // 0x8ce3c8: cmp             x1, x0
    // 0x8ce3cc: b.hs            #0x8ce5b4
    // 0x8ce3d0: ldurh           w0, [x5, #0x61]
    // 0x8ce3d4: ubfx            x0, x0, #0, #0x20
    // 0x8ce3d8: and             x1, x0, x3
    // 0x8ce3dc: lsl             w0, w7, #1
    // 0x8ce3e0: ubfx            x1, x1, #0, #0x20
    // 0x8ce3e4: stp             x0, x4, [SP, #-0x10]!
    // 0x8ce3e8: SaveReg r1
    //     0x8ce3e8: str             x1, [SP, #-8]!
    // 0x8ce3ec: r0 = _sendBits()
    //     0x8ce3ec: bl              #0x8cbef4  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendBits
    // 0x8ce3f0: add             SP, SP, #0x18
    // 0x8ce3f4: ldur            x1, [fp, #-0x38]
    // 0x8ce3f8: sub             x2, x1, #0xb
    // 0x8ce3fc: r0 = BoxInt64Instr(r2)
    //     0x8ce3fc: sbfiz           x0, x2, #1, #0x1f
    //     0x8ce400: cmp             x2, x0, asr #1
    //     0x8ce404: b.eq            #0x8ce410
    //     0x8ce408: bl              #0xd69bb8
    //     0x8ce40c: stur            x2, [x0, #7]
    // 0x8ce410: ldr             x16, [fp, #0x20]
    // 0x8ce414: stp             x0, x16, [SP, #-0x10]!
    // 0x8ce418: r0 = 7
    //     0x8ce418: mov             x0, #7
    // 0x8ce41c: SaveReg r0
    //     0x8ce41c: str             x0, [SP, #-8]!
    // 0x8ce420: r0 = _sendBits()
    //     0x8ce420: bl              #0x8cbef4  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendBits
    // 0x8ce424: add             SP, SP, #0x18
    // 0x8ce428: ldur            x11, [fp, #-0x18]
    // 0x8ce42c: cbnz            x11, #0x8ce440
    // 0x8ce430: ldur            x1, [fp, #-0x28]
    // 0x8ce434: r3 = 138
    //     0x8ce434: mov             x3, #0x8a
    // 0x8ce438: r2 = 3
    //     0x8ce438: mov             x2, #3
    // 0x8ce43c: b               #0x8ce460
    // 0x8ce440: ldur            x1, [fp, #-0x28]
    // 0x8ce444: cmp             x1, x11
    // 0x8ce448: b.ne            #0x8ce458
    // 0x8ce44c: r3 = 6
    //     0x8ce44c: mov             x3, #6
    // 0x8ce450: r2 = 3
    //     0x8ce450: mov             x2, #3
    // 0x8ce454: b               #0x8ce460
    // 0x8ce458: r3 = 7
    //     0x8ce458: mov             x3, #7
    // 0x8ce45c: r2 = 4
    //     0x8ce45c: mov             x2, #4
    // 0x8ce460: mov             x12, x1
    // 0x8ce464: mov             x9, x3
    // 0x8ce468: mov             x8, x2
    // 0x8ce46c: r10 = 0
    //     0x8ce46c: mov             x10, #0
    // 0x8ce470: ldur            x0, [fp, #-0x20]
    // 0x8ce474: ldr             x2, [fp, #0x18]
    // 0x8ce478: ldur            x3, [fp, #-0x30]
    // 0x8ce47c: b               #0x8cdff0
    // 0x8ce480: r0 = Null
    //     0x8ce480: mov             x0, NULL
    // 0x8ce484: LeaveFrame
    //     0x8ce484: mov             SP, fp
    //     0x8ce488: ldp             fp, lr, [SP], #0x10
    // 0x8ce48c: ret
    //     0x8ce48c: ret             
    // 0x8ce490: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ce490: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ce494: b               #0x8cdf98
    // 0x8ce498: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ce498: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ce49c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ce49c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ce4a0: b               #0x8ce010
    // 0x8ce4a4: tbnz            x5, #0x3f, #0x8ce4b0
    // 0x8ce4a8: mov             x0, xzr
    // 0x8ce4ac: b               #0x8ce02c
    // 0x8ce4b0: str             x5, [THR, #0xc0]  ; THR::
    // 0x8ce4b4: stp             x12, x13, [SP, #-0x10]!
    // 0x8ce4b8: stp             x10, x11, [SP, #-0x10]!
    // 0x8ce4bc: stp             x8, x9, [SP, #-0x10]!
    // 0x8ce4c0: stp             x6, x7, [SP, #-0x10]!
    // 0x8ce4c4: stp             x4, x5, [SP, #-0x10]!
    // 0x8ce4c8: stp             x2, x3, [SP, #-0x10]!
    // 0x8ce4cc: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x8ce4d0: r4 = 0
    //     0x8ce4d0: mov             x4, #0
    // 0x8ce4d4: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8ce4d8: blr             lr
    // 0x8ce4dc: brk             #0
    // 0x8ce4e0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ce4e0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ce4e4: tbnz            x5, #0x3f, #0x8ce4f0
    // 0x8ce4e8: mov             x8, xzr
    // 0x8ce4ec: b               #0x8ce084
    // 0x8ce4f0: str             x5, [THR, #0xc0]  ; THR::
    // 0x8ce4f4: stp             x14, x19, [SP, #-0x10]!
    // 0x8ce4f8: stp             x11, x13, [SP, #-0x10]!
    // 0x8ce4fc: stp             x6, x7, [SP, #-0x10]!
    // 0x8ce500: stp             x4, x5, [SP, #-0x10]!
    // 0x8ce504: stp             x2, x3, [SP, #-0x10]!
    // 0x8ce508: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x8ce50c: r4 = 0
    //     0x8ce50c: mov             x4, #0
    // 0x8ce510: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8ce514: blr             lr
    // 0x8ce518: brk             #0
    // 0x8ce51c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ce51c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ce520: b               #0x8ce09c
    // 0x8ce524: r9 = _bitLengthTree
    //     0x8ce524: add             x9, PP, #0x34, lsl #12  ; [pp+0x34af8] Field <Deflate._bitLengthTree@60040000>: late (offset: 0xa0)
    //     0x8ce528: ldr             x9, [x9, #0xaf8]
    // 0x8ce52c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ce52c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ce530: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ce530: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ce534: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ce534: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ce538: r9 = _bitLengthTree
    //     0x8ce538: add             x9, PP, #0x34, lsl #12  ; [pp+0x34af8] Field <Deflate._bitLengthTree@60040000>: late (offset: 0xa0)
    //     0x8ce53c: ldr             x9, [x9, #0xaf8]
    // 0x8ce540: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ce540: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ce544: tbnz            x4, #0x3f, #0x8ce550
    // 0x8ce548: mov             x7, xzr
    // 0x8ce54c: b               #0x8ce18c
    // 0x8ce550: str             x4, [THR, #0xc0]  ; THR::
    // 0x8ce554: stp             x6, x14, [SP, #-0x10]!
    // 0x8ce558: stp             x4, x5, [SP, #-0x10]!
    // 0x8ce55c: stp             x2, x3, [SP, #-0x10]!
    // 0x8ce560: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x8ce564: r4 = 0
    //     0x8ce564: mov             x4, #0
    // 0x8ce568: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8ce56c: blr             lr
    // 0x8ce570: brk             #0
    // 0x8ce574: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ce574: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ce578: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ce578: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ce57c: r9 = _bitLengthTree
    //     0x8ce57c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34af8] Field <Deflate._bitLengthTree@60040000>: late (offset: 0xa0)
    //     0x8ce580: ldr             x9, [x9, #0xaf8]
    // 0x8ce584: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ce584: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ce588: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ce588: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ce58c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ce58c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ce590: r9 = _bitLengthTree
    //     0x8ce590: add             x9, PP, #0x34, lsl #12  ; [pp+0x34af8] Field <Deflate._bitLengthTree@60040000>: late (offset: 0xa0)
    //     0x8ce594: ldr             x9, [x9, #0xaf8]
    // 0x8ce598: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ce598: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ce59c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ce59c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ce5a0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ce5a0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ce5a4: r9 = _bitLengthTree
    //     0x8ce5a4: add             x9, PP, #0x34, lsl #12  ; [pp+0x34af8] Field <Deflate._bitLengthTree@60040000>: late (offset: 0xa0)
    //     0x8ce5a8: ldr             x9, [x9, #0xaf8]
    // 0x8ce5ac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ce5ac: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ce5b0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ce5b0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ce5b4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ce5b4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _sendCode(/* No info */) {
    // ** addr: 0x8ce5b8, size: 0x104
    // 0x8ce5b8: EnterFrame
    //     0x8ce5b8: stp             fp, lr, [SP, #-0x10]!
    //     0x8ce5bc: mov             fp, SP
    // 0x8ce5c0: AllocStack(0x10)
    //     0x8ce5c0: sub             SP, SP, #0x10
    // 0x8ce5c4: CheckStackOverflow
    //     0x8ce5c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8ce5c8: cmp             SP, x16
    //     0x8ce5cc: b.ls            #0x8ce6b4
    // 0x8ce5d0: ldr             x0, [fp, #0x18]
    // 0x8ce5d4: lsl             x2, x0, #1
    // 0x8ce5d8: stur            x2, [fp, #-8]
    // 0x8ce5dc: r0 = BoxInt64Instr(r2)
    //     0x8ce5dc: sbfiz           x0, x2, #1, #0x1f
    //     0x8ce5e0: cmp             x2, x0, asr #1
    //     0x8ce5e4: b.eq            #0x8ce5f0
    //     0x8ce5e8: bl              #0xd69bb8
    //     0x8ce5ec: stur            x2, [x0, #7]
    // 0x8ce5f0: ldr             x1, [fp, #0x10]
    // 0x8ce5f4: r3 = LoadClassIdInstr(r1)
    //     0x8ce5f4: ldur            x3, [x1, #-1]
    //     0x8ce5f8: ubfx            x3, x3, #0xc, #0x14
    // 0x8ce5fc: stp             x0, x1, [SP, #-0x10]!
    // 0x8ce600: mov             x0, x3
    // 0x8ce604: r0 = GDT[cid_x0 + -0xd83]()
    //     0x8ce604: sub             lr, x0, #0xd83
    //     0x8ce608: ldr             lr, [x21, lr, lsl #3]
    //     0x8ce60c: blr             lr
    // 0x8ce610: add             SP, SP, #0x10
    // 0x8ce614: r1 = LoadInt32Instr(r0)
    //     0x8ce614: sbfx            x1, x0, #1, #0x1f
    //     0x8ce618: tbz             w0, #0, #0x8ce620
    //     0x8ce61c: ldur            x1, [x0, #7]
    // 0x8ce620: r2 = 65535
    //     0x8ce620: mov             x2, #0xffff
    // 0x8ce624: and             x3, x1, x2
    // 0x8ce628: ldur            x0, [fp, #-8]
    // 0x8ce62c: stur            x3, [fp, #-0x10]
    // 0x8ce630: add             x4, x0, #1
    // 0x8ce634: r0 = BoxInt64Instr(r4)
    //     0x8ce634: sbfiz           x0, x4, #1, #0x1f
    //     0x8ce638: cmp             x4, x0, asr #1
    //     0x8ce63c: b.eq            #0x8ce648
    //     0x8ce640: bl              #0xd69bb8
    //     0x8ce644: stur            x4, [x0, #7]
    // 0x8ce648: mov             x1, x0
    // 0x8ce64c: ldr             x0, [fp, #0x10]
    // 0x8ce650: r4 = LoadClassIdInstr(r0)
    //     0x8ce650: ldur            x4, [x0, #-1]
    //     0x8ce654: ubfx            x4, x4, #0xc, #0x14
    // 0x8ce658: stp             x1, x0, [SP, #-0x10]!
    // 0x8ce65c: mov             x0, x4
    // 0x8ce660: r0 = GDT[cid_x0 + -0xd83]()
    //     0x8ce660: sub             lr, x0, #0xd83
    //     0x8ce664: ldr             lr, [x21, lr, lsl #3]
    //     0x8ce668: blr             lr
    // 0x8ce66c: add             SP, SP, #0x10
    // 0x8ce670: r1 = LoadInt32Instr(r0)
    //     0x8ce670: sbfx            x1, x0, #1, #0x1f
    //     0x8ce674: tbz             w0, #0, #0x8ce67c
    //     0x8ce678: ldur            x1, [x0, #7]
    // 0x8ce67c: r0 = 65535
    //     0x8ce67c: mov             x0, #0xffff
    // 0x8ce680: and             x2, x1, x0
    // 0x8ce684: ldur            x0, [fp, #-0x10]
    // 0x8ce688: lsl             w1, w0, #1
    // 0x8ce68c: ubfx            x2, x2, #0, #0x20
    // 0x8ce690: ldr             x16, [fp, #0x20]
    // 0x8ce694: stp             x1, x16, [SP, #-0x10]!
    // 0x8ce698: SaveReg r2
    //     0x8ce698: str             x2, [SP, #-8]!
    // 0x8ce69c: r0 = _sendBits()
    //     0x8ce69c: bl              #0x8cbef4  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendBits
    // 0x8ce6a0: add             SP, SP, #0x18
    // 0x8ce6a4: r0 = Null
    //     0x8ce6a4: mov             x0, NULL
    // 0x8ce6a8: LeaveFrame
    //     0x8ce6a8: mov             SP, fp
    //     0x8ce6ac: ldp             fp, lr, [SP], #0x10
    // 0x8ce6b0: ret
    //     0x8ce6b0: ret             
    // 0x8ce6b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ce6b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ce6b8: b               #0x8ce5d0
  }
  _ _compressBlock(/* No info */) {
    // ** addr: 0x8ce6bc, size: 0x680
    // 0x8ce6bc: EnterFrame
    //     0x8ce6bc: stp             fp, lr, [SP, #-0x10]!
    //     0x8ce6c0: mov             fp, SP
    // 0x8ce6c4: AllocStack(0x30)
    //     0x8ce6c4: sub             SP, SP, #0x30
    // 0x8ce6c8: CheckStackOverflow
    //     0x8ce6c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8ce6cc: cmp             SP, x16
    //     0x8ce6d0: b.ls            #0x8cece0
    // 0x8ce6d4: ldr             x2, [fp, #0x20]
    // 0x8ce6d8: LoadField: r0 = r2->field_cb
    //     0x8ce6d8: ldur            w0, [x2, #0xcb]
    // 0x8ce6dc: DecompressPointer r0
    //     0x8ce6dc: add             x0, x0, HEAP, lsl #32
    // 0x8ce6e0: r16 = Sentinel
    //     0x8ce6e0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8ce6e4: cmp             w0, w16
    // 0x8ce6e8: b.eq            #0x8cece8
    // 0x8ce6ec: r1 = LoadInt32Instr(r0)
    //     0x8ce6ec: sbfx            x1, x0, #1, #0x1f
    //     0x8ce6f0: tbz             w0, #0, #0x8ce6f8
    //     0x8ce6f4: ldur            x1, [x0, #7]
    // 0x8ce6f8: cbz             x1, #0x8cec68
    // 0x8ce6fc: r7 = 0
    //     0x8ce6fc: mov             x7, #0
    // 0x8ce700: ldr             x6, [fp, #0x18]
    // 0x8ce704: ldr             x5, [fp, #0x10]
    // 0x8ce708: r4 = 65280
    //     0x8ce708: mov             x4, #0xff00
    // 0x8ce70c: r3 = 255
    //     0x8ce70c: mov             x3, #0xff
    // 0x8ce710: CheckStackOverflow
    //     0x8ce710: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8ce714: cmp             SP, x16
    //     0x8ce718: b.ls            #0x8cecf4
    // 0x8ce71c: LoadField: r8 = r2->field_23
    //     0x8ce71c: ldur            w8, [x2, #0x23]
    // 0x8ce720: DecompressPointer r8
    //     0x8ce720: add             x8, x8, HEAP, lsl #32
    // 0x8ce724: r16 = Sentinel
    //     0x8ce724: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8ce728: cmp             w8, w16
    // 0x8ce72c: b.eq            #0x8cecfc
    // 0x8ce730: LoadField: r0 = r2->field_cf
    //     0x8ce730: ldur            w0, [x2, #0xcf]
    // 0x8ce734: DecompressPointer r0
    //     0x8ce734: add             x0, x0, HEAP, lsl #32
    // 0x8ce738: r16 = Sentinel
    //     0x8ce738: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8ce73c: cmp             w0, w16
    // 0x8ce740: b.eq            #0x8ced08
    // 0x8ce744: lsl             x1, x7, #1
    // 0x8ce748: r9 = LoadInt32Instr(r0)
    //     0x8ce748: sbfx            x9, x0, #1, #0x1f
    //     0x8ce74c: tbz             w0, #0, #0x8ce754
    //     0x8ce750: ldur            x9, [x0, #7]
    // 0x8ce754: add             x10, x9, x1
    // 0x8ce758: LoadField: r0 = r8->field_13
    //     0x8ce758: ldur            w0, [x8, #0x13]
    // 0x8ce75c: DecompressPointer r0
    //     0x8ce75c: add             x0, x0, HEAP, lsl #32
    // 0x8ce760: r11 = LoadInt32Instr(r0)
    //     0x8ce760: sbfx            x11, x0, #1, #0x1f
    // 0x8ce764: mov             x0, x11
    // 0x8ce768: mov             x1, x10
    // 0x8ce76c: cmp             x1, x0
    // 0x8ce770: b.hs            #0x8ced14
    // 0x8ce774: ArrayLoad: r0 = r8[r10]  ; TypedUnsigned_1
    //     0x8ce774: add             x16, x8, x10
    //     0x8ce778: ldrb            w0, [x16, #0x17]
    // 0x8ce77c: ubfx            x0, x0, #0, #0x20
    // 0x8ce780: lsl             w1, w0, #8
    // 0x8ce784: and             x9, x1, x4
    // 0x8ce788: add             x12, x10, #1
    // 0x8ce78c: mov             x0, x11
    // 0x8ce790: mov             x1, x12
    // 0x8ce794: cmp             x1, x0
    // 0x8ce798: b.hs            #0x8ced18
    // 0x8ce79c: ArrayLoad: r0 = r8[r12]  ; TypedUnsigned_1
    //     0x8ce79c: add             x16, x8, x12
    //     0x8ce7a0: ldrb            w0, [x16, #0x17]
    // 0x8ce7a4: ubfx            x0, x0, #0, #0x20
    // 0x8ce7a8: and             x1, x0, x3
    // 0x8ce7ac: ubfx            x9, x9, #0, #0x20
    // 0x8ce7b0: ubfx            x1, x1, #0, #0x20
    // 0x8ce7b4: orr             x10, x9, x1
    // 0x8ce7b8: stur            x10, [fp, #-0x28]
    // 0x8ce7bc: LoadField: r0 = r2->field_c3
    //     0x8ce7bc: ldur            w0, [x2, #0xc3]
    // 0x8ce7c0: DecompressPointer r0
    //     0x8ce7c0: add             x0, x0, HEAP, lsl #32
    // 0x8ce7c4: r16 = Sentinel
    //     0x8ce7c4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8ce7c8: cmp             w0, w16
    // 0x8ce7cc: b.eq            #0x8ced1c
    // 0x8ce7d0: r1 = LoadInt32Instr(r0)
    //     0x8ce7d0: sbfx            x1, x0, #1, #0x1f
    //     0x8ce7d4: tbz             w0, #0, #0x8ce7dc
    //     0x8ce7d8: ldur            x1, [x0, #7]
    // 0x8ce7dc: add             x9, x1, x7
    // 0x8ce7e0: mov             x0, x11
    // 0x8ce7e4: mov             x1, x9
    // 0x8ce7e8: cmp             x1, x0
    // 0x8ce7ec: b.hs            #0x8ced28
    // 0x8ce7f0: ArrayLoad: r0 = r8[r9]  ; TypedUnsigned_1
    //     0x8ce7f0: add             x16, x8, x9
    //     0x8ce7f4: ldrb            w0, [x16, #0x17]
    // 0x8ce7f8: ubfx            x0, x0, #0, #0x20
    // 0x8ce7fc: and             x8, x0, x3
    // 0x8ce800: stur            x8, [fp, #-0x20]
    // 0x8ce804: add             x1, x7, #1
    // 0x8ce808: stur            x1, [fp, #-0x10]
    // 0x8ce80c: cbnz            x10, #0x8ce8c4
    // 0x8ce810: mov             x0, x8
    // 0x8ce814: ubfx            x0, x0, #0, #0x20
    // 0x8ce818: lsl             x7, x0, #1
    // 0x8ce81c: stur            x7, [fp, #-8]
    // 0x8ce820: lsl             x0, x7, #1
    // 0x8ce824: r8 = LoadClassIdInstr(r6)
    //     0x8ce824: ldur            x8, [x6, #-1]
    //     0x8ce828: ubfx            x8, x8, #0xc, #0x14
    // 0x8ce82c: stp             x0, x6, [SP, #-0x10]!
    // 0x8ce830: mov             x0, x8
    // 0x8ce834: r0 = GDT[cid_x0 + -0xd83]()
    //     0x8ce834: sub             lr, x0, #0xd83
    //     0x8ce838: ldr             lr, [x21, lr, lsl #3]
    //     0x8ce83c: blr             lr
    // 0x8ce840: add             SP, SP, #0x10
    // 0x8ce844: r1 = LoadInt32Instr(r0)
    //     0x8ce844: sbfx            x1, x0, #1, #0x1f
    //     0x8ce848: tbz             w0, #0, #0x8ce850
    //     0x8ce84c: ldur            x1, [x0, #7]
    // 0x8ce850: r2 = 65535
    //     0x8ce850: mov             x2, #0xffff
    // 0x8ce854: and             x3, x1, x2
    // 0x8ce858: ldur            x0, [fp, #-8]
    // 0x8ce85c: stur            x3, [fp, #-0x18]
    // 0x8ce860: add             x1, x0, #1
    // 0x8ce864: lsl             x0, x1, #1
    // 0x8ce868: ldr             x1, [fp, #0x18]
    // 0x8ce86c: r4 = LoadClassIdInstr(r1)
    //     0x8ce86c: ldur            x4, [x1, #-1]
    //     0x8ce870: ubfx            x4, x4, #0xc, #0x14
    // 0x8ce874: stp             x0, x1, [SP, #-0x10]!
    // 0x8ce878: mov             x0, x4
    // 0x8ce87c: r0 = GDT[cid_x0 + -0xd83]()
    //     0x8ce87c: sub             lr, x0, #0xd83
    //     0x8ce880: ldr             lr, [x21, lr, lsl #3]
    //     0x8ce884: blr             lr
    // 0x8ce888: add             SP, SP, #0x10
    // 0x8ce88c: r1 = LoadInt32Instr(r0)
    //     0x8ce88c: sbfx            x1, x0, #1, #0x1f
    //     0x8ce890: tbz             w0, #0, #0x8ce898
    //     0x8ce894: ldur            x1, [x0, #7]
    // 0x8ce898: r0 = 65535
    //     0x8ce898: mov             x0, #0xffff
    // 0x8ce89c: and             x2, x1, x0
    // 0x8ce8a0: ldur            x1, [fp, #-0x18]
    // 0x8ce8a4: lsl             w3, w1, #1
    // 0x8ce8a8: ubfx            x2, x2, #0, #0x20
    // 0x8ce8ac: ldr             x16, [fp, #0x20]
    // 0x8ce8b0: stp             x3, x16, [SP, #-0x10]!
    // 0x8ce8b4: SaveReg r2
    //     0x8ce8b4: str             x2, [SP, #-8]!
    // 0x8ce8b8: r0 = _sendBits()
    //     0x8ce8b8: bl              #0x8cbef4  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendBits
    // 0x8ce8bc: add             SP, SP, #0x18
    // 0x8ce8c0: b               #0x8cec3c
    // 0x8ce8c4: mov             x2, x6
    // 0x8ce8c8: r3 = const [0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x8, 0x9, 0x9, 0xa, 0xa, 0xb, 0xb, 0xc, 0xc, 0xc, 0xc, 0xd, 0xd, 0xd, 0xd, 0xe, 0xe, 0xe, 0xe, 0xf, 0xf, 0xf, 0xf, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x12, 0x12, 0x12, 0x12, 0x12, 0x12, 0x12, 0x12, 0x13, 0x13, 0x13, 0x13, 0x13, 0x13, 0x13, 0x13, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1c]
    //     0x8ce8c8: add             x3, PP, #0x34, lsl #12  ; [pp+0x34b08] List<int>(256)
    //     0x8ce8cc: ldr             x3, [x3, #0xb08]
    // 0x8ce8d0: mov             x0, x8
    // 0x8ce8d4: ubfx            x0, x0, #0, #0x20
    // 0x8ce8d8: ArrayLoad: r1 = r3[r0]  ; Unknown_4
    //     0x8ce8d8: add             x16, x3, x0, lsl #2
    //     0x8ce8dc: ldur            w1, [x16, #0xf]
    // 0x8ce8e0: DecompressPointer r1
    //     0x8ce8e0: add             x1, x1, HEAP, lsl #32
    // 0x8ce8e4: r4 = LoadInt32Instr(r1)
    //     0x8ce8e4: sbfx            x4, x1, #1, #0x1f
    //     0x8ce8e8: tbz             w1, #0, #0x8ce8f0
    //     0x8ce8ec: ldur            x4, [x1, #7]
    // 0x8ce8f0: stur            x4, [fp, #-0x18]
    // 0x8ce8f4: add             x0, x4, #0x100
    // 0x8ce8f8: add             x1, x0, #1
    // 0x8ce8fc: lsl             x5, x1, #1
    // 0x8ce900: stur            x5, [fp, #-8]
    // 0x8ce904: r0 = BoxInt64Instr(r5)
    //     0x8ce904: sbfiz           x0, x5, #1, #0x1f
    //     0x8ce908: cmp             x5, x0, asr #1
    //     0x8ce90c: b.eq            #0x8ce918
    //     0x8ce910: bl              #0xd69bb8
    //     0x8ce914: stur            x5, [x0, #7]
    // 0x8ce918: r1 = LoadClassIdInstr(r2)
    //     0x8ce918: ldur            x1, [x2, #-1]
    //     0x8ce91c: ubfx            x1, x1, #0xc, #0x14
    // 0x8ce920: stp             x0, x2, [SP, #-0x10]!
    // 0x8ce924: mov             x0, x1
    // 0x8ce928: r0 = GDT[cid_x0 + -0xd83]()
    //     0x8ce928: sub             lr, x0, #0xd83
    //     0x8ce92c: ldr             lr, [x21, lr, lsl #3]
    //     0x8ce930: blr             lr
    // 0x8ce934: add             SP, SP, #0x10
    // 0x8ce938: r1 = LoadInt32Instr(r0)
    //     0x8ce938: sbfx            x1, x0, #1, #0x1f
    //     0x8ce93c: tbz             w0, #0, #0x8ce944
    //     0x8ce940: ldur            x1, [x0, #7]
    // 0x8ce944: r2 = 65535
    //     0x8ce944: mov             x2, #0xffff
    // 0x8ce948: and             x3, x1, x2
    // 0x8ce94c: ldur            x0, [fp, #-8]
    // 0x8ce950: stur            x3, [fp, #-0x30]
    // 0x8ce954: add             x4, x0, #1
    // 0x8ce958: r0 = BoxInt64Instr(r4)
    //     0x8ce958: sbfiz           x0, x4, #1, #0x1f
    //     0x8ce95c: cmp             x4, x0, asr #1
    //     0x8ce960: b.eq            #0x8ce96c
    //     0x8ce964: bl              #0xd69bb8
    //     0x8ce968: stur            x4, [x0, #7]
    // 0x8ce96c: ldr             x1, [fp, #0x18]
    // 0x8ce970: r4 = LoadClassIdInstr(r1)
    //     0x8ce970: ldur            x4, [x1, #-1]
    //     0x8ce974: ubfx            x4, x4, #0xc, #0x14
    // 0x8ce978: stp             x0, x1, [SP, #-0x10]!
    // 0x8ce97c: mov             x0, x4
    // 0x8ce980: r0 = GDT[cid_x0 + -0xd83]()
    //     0x8ce980: sub             lr, x0, #0xd83
    //     0x8ce984: ldr             lr, [x21, lr, lsl #3]
    //     0x8ce988: blr             lr
    // 0x8ce98c: add             SP, SP, #0x10
    // 0x8ce990: r1 = LoadInt32Instr(r0)
    //     0x8ce990: sbfx            x1, x0, #1, #0x1f
    //     0x8ce994: tbz             w0, #0, #0x8ce99c
    //     0x8ce998: ldur            x1, [x0, #7]
    // 0x8ce99c: r0 = 65535
    //     0x8ce99c: mov             x0, #0xffff
    // 0x8ce9a0: and             x2, x1, x0
    // 0x8ce9a4: ldur            x1, [fp, #-0x30]
    // 0x8ce9a8: lsl             w3, w1, #1
    // 0x8ce9ac: ubfx            x2, x2, #0, #0x20
    // 0x8ce9b0: ldr             x16, [fp, #0x20]
    // 0x8ce9b4: stp             x3, x16, [SP, #-0x10]!
    // 0x8ce9b8: SaveReg r2
    //     0x8ce9b8: str             x2, [SP, #-8]!
    // 0x8ce9bc: r0 = _sendBits()
    //     0x8ce9bc: bl              #0x8cbef4  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendBits
    // 0x8ce9c0: add             SP, SP, #0x18
    // 0x8ce9c4: ldur            x1, [fp, #-0x18]
    // 0x8ce9c8: r0 = 29
    //     0x8ce9c8: mov             x0, #0x1d
    // 0x8ce9cc: cmp             x1, x0
    // 0x8ce9d0: b.hs            #0x8ced2c
    // 0x8ce9d4: ldur            x0, [fp, #-0x18]
    // 0x8ce9d8: r2 = const [0, 0, 0, 0, 0, 0, 0, 0, 0x1, 0x1, 0x1, 0x1, 0x2, 0x2, 0x2, 0x2, 0x3, 0x3, 0x3, 0x3, 0x4, 0x4, 0x4, 0x4, 0x5, 0x5, 0x5, 0x5, 0]
    //     0x8ce9d8: add             x2, PP, #0x34, lsl #12  ; [pp+0x34b10] List<int>(29)
    //     0x8ce9dc: ldr             x2, [x2, #0xb10]
    // 0x8ce9e0: ArrayLoad: r1 = r2[r0]  ; Unknown_4
    //     0x8ce9e0: add             x16, x2, x0, lsl #2
    //     0x8ce9e4: ldur            w1, [x16, #0xf]
    // 0x8ce9e8: DecompressPointer r1
    //     0x8ce9e8: add             x1, x1, HEAP, lsl #32
    // 0x8ce9ec: cbz             w1, #0x8cea50
    // 0x8ce9f0: r3 = const [0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0xa, 0xc, 0xe, 0x10, 0x14, 0x18, 0x1c, 0x20, 0x28, 0x30, 0x38, 0x40, 0x50, 0x60, 0x70, 0x80, 0xa0, 0xc0, 0xe0, 0]
    //     0x8ce9f0: add             x3, PP, #0x34, lsl #12  ; [pp+0x34b18] List<int>(29)
    //     0x8ce9f4: ldr             x3, [x3, #0xb18]
    // 0x8ce9f8: ArrayLoad: r4 = r3[r0]  ; Unknown_4
    //     0x8ce9f8: add             x16, x3, x0, lsl #2
    //     0x8ce9fc: ldur            w4, [x16, #0xf]
    // 0x8cea00: DecompressPointer r4
    //     0x8cea00: add             x4, x4, HEAP, lsl #32
    // 0x8cea04: r0 = LoadInt32Instr(r4)
    //     0x8cea04: sbfx            x0, x4, #1, #0x1f
    //     0x8cea08: tbz             w4, #0, #0x8cea10
    //     0x8cea0c: ldur            x0, [x4, #7]
    // 0x8cea10: ldur            x4, [fp, #-0x20]
    // 0x8cea14: ubfx            x4, x4, #0, #0x20
    // 0x8cea18: sub             x5, x4, x0
    // 0x8cea1c: r4 = LoadInt32Instr(r1)
    //     0x8cea1c: sbfx            x4, x1, #1, #0x1f
    //     0x8cea20: tbz             w1, #0, #0x8cea28
    //     0x8cea24: ldur            x4, [x1, #7]
    // 0x8cea28: r0 = BoxInt64Instr(r5)
    //     0x8cea28: sbfiz           x0, x5, #1, #0x1f
    //     0x8cea2c: cmp             x5, x0, asr #1
    //     0x8cea30: b.eq            #0x8cea3c
    //     0x8cea34: bl              #0xd69bb8
    //     0x8cea38: stur            x5, [x0, #7]
    // 0x8cea3c: ldr             x16, [fp, #0x20]
    // 0x8cea40: stp             x0, x16, [SP, #-0x10]!
    // 0x8cea44: SaveReg r4
    //     0x8cea44: str             x4, [SP, #-8]!
    // 0x8cea48: r0 = _sendBits()
    //     0x8cea48: bl              #0x8cbef4  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendBits
    // 0x8cea4c: add             SP, SP, #0x18
    // 0x8cea50: ldur            x0, [fp, #-0x28]
    // 0x8cea54: sub             x2, x0, #1
    // 0x8cea58: stur            x2, [fp, #-0x20]
    // 0x8cea5c: cmp             x2, #0x100
    // 0x8cea60: b.ge            #0x8cea9c
    // 0x8cea64: r3 = const [0, 0x1, 0x2, 0x3, 0x4, 0x4, 0x5, 0x5, 0x6, 0x6, 0x6, 0x6, 0x7, 0x7, 0x7, 0x7, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0, 0, 0x10, 0x11, 0x12, 0x12, 0x13, 0x13, 0x14, 0x14, 0x14, 0x14, 0x15, 0x15, 0x15, 0x15, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d]
    //     0x8cea64: add             x3, PP, #0x34, lsl #12  ; [pp+0x34b20] List<int>(512)
    //     0x8cea68: ldr             x3, [x3, #0xb20]
    // 0x8cea6c: mov             x1, x2
    // 0x8cea70: r0 = 512
    //     0x8cea70: mov             x0, #0x200
    // 0x8cea74: cmp             x1, x0
    // 0x8cea78: b.hs            #0x8ced30
    // 0x8cea7c: ArrayLoad: r0 = r3[r2]  ; Unknown_4
    //     0x8cea7c: add             x16, x3, x2, lsl #2
    //     0x8cea80: ldur            w0, [x16, #0xf]
    // 0x8cea84: DecompressPointer r0
    //     0x8cea84: add             x0, x0, HEAP, lsl #32
    // 0x8cea88: r1 = LoadInt32Instr(r0)
    //     0x8cea88: sbfx            x1, x0, #1, #0x1f
    //     0x8cea8c: tbz             w0, #0, #0x8cea94
    //     0x8cea90: ldur            x1, [x0, #7]
    // 0x8cea94: mov             x5, x1
    // 0x8cea98: b               #0x8ceae4
    // 0x8cea9c: r3 = const [0, 0x1, 0x2, 0x3, 0x4, 0x4, 0x5, 0x5, 0x6, 0x6, 0x6, 0x6, 0x7, 0x7, 0x7, 0x7, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xb, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xc, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xd, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xe, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0, 0, 0x10, 0x11, 0x12, 0x12, 0x13, 0x13, 0x14, 0x14, 0x14, 0x14, 0x15, 0x15, 0x15, 0x15, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1c, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d, 0x1d]
    //     0x8cea9c: add             x3, PP, #0x34, lsl #12  ; [pp+0x34b20] List<int>(512)
    //     0x8ceaa0: ldr             x3, [x3, #0xb20]
    // 0x8ceaa4: tbnz            x2, #0x3f, #0x8ceab0
    // 0x8ceaa8: asr             x0, x2, #7
    // 0x8ceaac: b               #0x8ceab4
    // 0x8ceab0: asr             x0, x2, #7
    // 0x8ceab4: add             x4, x0, #0x100
    // 0x8ceab8: mov             x1, x4
    // 0x8ceabc: r0 = 512
    //     0x8ceabc: mov             x0, #0x200
    // 0x8ceac0: cmp             x1, x0
    // 0x8ceac4: b.hs            #0x8ced34
    // 0x8ceac8: ArrayLoad: r0 = r3[r4]  ; Unknown_4
    //     0x8ceac8: add             x16, x3, x4, lsl #2
    //     0x8ceacc: ldur            w0, [x16, #0xf]
    // 0x8cead0: DecompressPointer r0
    //     0x8cead0: add             x0, x0, HEAP, lsl #32
    // 0x8cead4: r1 = LoadInt32Instr(r0)
    //     0x8cead4: sbfx            x1, x0, #1, #0x1f
    //     0x8cead8: tbz             w0, #0, #0x8ceae0
    //     0x8ceadc: ldur            x1, [x0, #7]
    // 0x8ceae0: mov             x5, x1
    // 0x8ceae4: ldr             x4, [fp, #0x10]
    // 0x8ceae8: stur            x5, [fp, #-0x18]
    // 0x8ceaec: lsl             x6, x5, #1
    // 0x8ceaf0: stur            x6, [fp, #-8]
    // 0x8ceaf4: r0 = BoxInt64Instr(r6)
    //     0x8ceaf4: sbfiz           x0, x6, #1, #0x1f
    //     0x8ceaf8: cmp             x6, x0, asr #1
    //     0x8ceafc: b.eq            #0x8ceb08
    //     0x8ceb00: bl              #0xd69bb8
    //     0x8ceb04: stur            x6, [x0, #7]
    // 0x8ceb08: r1 = LoadClassIdInstr(r4)
    //     0x8ceb08: ldur            x1, [x4, #-1]
    //     0x8ceb0c: ubfx            x1, x1, #0xc, #0x14
    // 0x8ceb10: stp             x0, x4, [SP, #-0x10]!
    // 0x8ceb14: mov             x0, x1
    // 0x8ceb18: r0 = GDT[cid_x0 + -0xd83]()
    //     0x8ceb18: sub             lr, x0, #0xd83
    //     0x8ceb1c: ldr             lr, [x21, lr, lsl #3]
    //     0x8ceb20: blr             lr
    // 0x8ceb24: add             SP, SP, #0x10
    // 0x8ceb28: r1 = LoadInt32Instr(r0)
    //     0x8ceb28: sbfx            x1, x0, #1, #0x1f
    //     0x8ceb2c: tbz             w0, #0, #0x8ceb34
    //     0x8ceb30: ldur            x1, [x0, #7]
    // 0x8ceb34: r2 = 65535
    //     0x8ceb34: mov             x2, #0xffff
    // 0x8ceb38: and             x3, x1, x2
    // 0x8ceb3c: ldur            x0, [fp, #-8]
    // 0x8ceb40: stur            x3, [fp, #-0x28]
    // 0x8ceb44: add             x4, x0, #1
    // 0x8ceb48: r0 = BoxInt64Instr(r4)
    //     0x8ceb48: sbfiz           x0, x4, #1, #0x1f
    //     0x8ceb4c: cmp             x4, x0, asr #1
    //     0x8ceb50: b.eq            #0x8ceb5c
    //     0x8ceb54: bl              #0xd69bb8
    //     0x8ceb58: stur            x4, [x0, #7]
    // 0x8ceb5c: ldr             x1, [fp, #0x10]
    // 0x8ceb60: r4 = LoadClassIdInstr(r1)
    //     0x8ceb60: ldur            x4, [x1, #-1]
    //     0x8ceb64: ubfx            x4, x4, #0xc, #0x14
    // 0x8ceb68: stp             x0, x1, [SP, #-0x10]!
    // 0x8ceb6c: mov             x0, x4
    // 0x8ceb70: r0 = GDT[cid_x0 + -0xd83]()
    //     0x8ceb70: sub             lr, x0, #0xd83
    //     0x8ceb74: ldr             lr, [x21, lr, lsl #3]
    //     0x8ceb78: blr             lr
    // 0x8ceb7c: add             SP, SP, #0x10
    // 0x8ceb80: r1 = LoadInt32Instr(r0)
    //     0x8ceb80: sbfx            x1, x0, #1, #0x1f
    //     0x8ceb84: tbz             w0, #0, #0x8ceb8c
    //     0x8ceb88: ldur            x1, [x0, #7]
    // 0x8ceb8c: r0 = 65535
    //     0x8ceb8c: mov             x0, #0xffff
    // 0x8ceb90: and             x2, x1, x0
    // 0x8ceb94: ldur            x1, [fp, #-0x28]
    // 0x8ceb98: lsl             w3, w1, #1
    // 0x8ceb9c: ubfx            x2, x2, #0, #0x20
    // 0x8ceba0: ldr             x16, [fp, #0x20]
    // 0x8ceba4: stp             x3, x16, [SP, #-0x10]!
    // 0x8ceba8: SaveReg r2
    //     0x8ceba8: str             x2, [SP, #-8]!
    // 0x8cebac: r0 = _sendBits()
    //     0x8cebac: bl              #0x8cbef4  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendBits
    // 0x8cebb0: add             SP, SP, #0x18
    // 0x8cebb4: ldur            x1, [fp, #-0x18]
    // 0x8cebb8: r0 = 30
    //     0x8cebb8: mov             x0, #0x1e
    // 0x8cebbc: cmp             x1, x0
    // 0x8cebc0: b.hs            #0x8ced38
    // 0x8cebc4: ldur            x0, [fp, #-0x18]
    // 0x8cebc8: r2 = const [0, 0, 0, 0, 0x1, 0x1, 0x2, 0x2, 0x3, 0x3, 0x4, 0x4, 0x5, 0x5, 0x6, 0x6, 0x7, 0x7, 0x8, 0x8, 0x9, 0x9, 0xa, 0xa, 0xb, 0xb, 0xc, 0xc, 0xd, 0xd]
    //     0x8cebc8: add             x2, PP, #0x34, lsl #12  ; [pp+0x34b28] List<int>(30)
    //     0x8cebcc: ldr             x2, [x2, #0xb28]
    // 0x8cebd0: ArrayLoad: r1 = r2[r0]  ; Unknown_4
    //     0x8cebd0: add             x16, x2, x0, lsl #2
    //     0x8cebd4: ldur            w1, [x16, #0xf]
    // 0x8cebd8: DecompressPointer r1
    //     0x8cebd8: add             x1, x1, HEAP, lsl #32
    // 0x8cebdc: cbz             w1, #0x8cec3c
    // 0x8cebe0: ldur            x3, [fp, #-0x20]
    // 0x8cebe4: r4 = const [0, 0x1, 0x2, 0x3, 0x4, 0x6, 0x8, 0xc, 0x10, 0x18, 0x20, 0x30, 0x40, 0x60, 0x80, 0xc0, 0x100, 0x180, 0x200, 0x300, 0x400, 0x600, 0x800, 0xc00, 0x1000, 0x1800, 0x2000, 0x3000, 0x4000, 0x6000]
    //     0x8cebe4: add             x4, PP, #0x34, lsl #12  ; [pp+0x34b30] List<int>(30)
    //     0x8cebe8: ldr             x4, [x4, #0xb30]
    // 0x8cebec: ArrayLoad: r5 = r4[r0]  ; Unknown_4
    //     0x8cebec: add             x16, x4, x0, lsl #2
    //     0x8cebf0: ldur            w5, [x16, #0xf]
    // 0x8cebf4: DecompressPointer r5
    //     0x8cebf4: add             x5, x5, HEAP, lsl #32
    // 0x8cebf8: r0 = LoadInt32Instr(r5)
    //     0x8cebf8: sbfx            x0, x5, #1, #0x1f
    //     0x8cebfc: tbz             w5, #0, #0x8cec04
    //     0x8cec00: ldur            x0, [x5, #7]
    // 0x8cec04: sub             x5, x3, x0
    // 0x8cec08: r3 = LoadInt32Instr(r1)
    //     0x8cec08: sbfx            x3, x1, #1, #0x1f
    //     0x8cec0c: tbz             w1, #0, #0x8cec14
    //     0x8cec10: ldur            x3, [x1, #7]
    // 0x8cec14: r0 = BoxInt64Instr(r5)
    //     0x8cec14: sbfiz           x0, x5, #1, #0x1f
    //     0x8cec18: cmp             x5, x0, asr #1
    //     0x8cec1c: b.eq            #0x8cec28
    //     0x8cec20: bl              #0xd69bb8
    //     0x8cec24: stur            x5, [x0, #7]
    // 0x8cec28: ldr             x16, [fp, #0x20]
    // 0x8cec2c: stp             x0, x16, [SP, #-0x10]!
    // 0x8cec30: SaveReg r3
    //     0x8cec30: str             x3, [SP, #-8]!
    // 0x8cec34: r0 = _sendBits()
    //     0x8cec34: bl              #0x8cbef4  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendBits
    // 0x8cec38: add             SP, SP, #0x18
    // 0x8cec3c: ldr             x0, [fp, #0x20]
    // 0x8cec40: ldur            x7, [fp, #-0x10]
    // 0x8cec44: LoadField: r1 = r0->field_cb
    //     0x8cec44: ldur            w1, [x0, #0xcb]
    // 0x8cec48: DecompressPointer r1
    //     0x8cec48: add             x1, x1, HEAP, lsl #32
    // 0x8cec4c: r2 = LoadInt32Instr(r1)
    //     0x8cec4c: sbfx            x2, x1, #1, #0x1f
    //     0x8cec50: tbz             w1, #0, #0x8cec58
    //     0x8cec54: ldur            x2, [x1, #7]
    // 0x8cec58: cmp             x7, x2
    // 0x8cec5c: b.ge            #0x8cec6c
    // 0x8cec60: mov             x2, x0
    // 0x8cec64: b               #0x8ce700
    // 0x8cec68: mov             x0, x2
    // 0x8cec6c: ldr             x1, [fp, #0x18]
    // 0x8cec70: r2 = 256
    //     0x8cec70: mov             x2, #0x100
    // 0x8cec74: stp             x2, x0, [SP, #-0x10]!
    // 0x8cec78: SaveReg r1
    //     0x8cec78: str             x1, [SP, #-8]!
    // 0x8cec7c: r0 = _sendCode()
    //     0x8cec7c: bl              #0x8ce5b8  ; [package:archive/src/zlib/deflate.dart] Deflate::_sendCode
    // 0x8cec80: add             SP, SP, #0x18
    // 0x8cec84: ldr             x0, [fp, #0x18]
    // 0x8cec88: r1 = LoadClassIdInstr(r0)
    //     0x8cec88: ldur            x1, [x0, #-1]
    //     0x8cec8c: ubfx            x1, x1, #0xc, #0x14
    // 0x8cec90: r16 = 1026
    //     0x8cec90: mov             x16, #0x402
    // 0x8cec94: stp             x16, x0, [SP, #-0x10]!
    // 0x8cec98: mov             x0, x1
    // 0x8cec9c: r0 = GDT[cid_x0 + -0xd83]()
    //     0x8cec9c: sub             lr, x0, #0xd83
    //     0x8ceca0: ldr             lr, [x21, lr, lsl #3]
    //     0x8ceca4: blr             lr
    // 0x8ceca8: add             SP, SP, #0x10
    // 0x8cecac: ldr             x1, [fp, #0x20]
    // 0x8cecb0: StoreField: r1->field_df = r0
    //     0x8cecb0: stur            w0, [x1, #0xdf]
    //     0x8cecb4: tbz             w0, #0, #0x8cecd0
    //     0x8cecb8: ldurb           w16, [x1, #-1]
    //     0x8cecbc: ldurb           w17, [x0, #-1]
    //     0x8cecc0: and             x16, x17, x16, lsr #2
    //     0x8cecc4: tst             x16, HEAP, lsr #32
    //     0x8cecc8: b.eq            #0x8cecd0
    //     0x8ceccc: bl              #0xd6826c
    // 0x8cecd0: r0 = Null
    //     0x8cecd0: mov             x0, NULL
    // 0x8cecd4: LeaveFrame
    //     0x8cecd4: mov             SP, fp
    //     0x8cecd8: ldp             fp, lr, [SP], #0x10
    // 0x8cecdc: ret
    //     0x8cecdc: ret             
    // 0x8cece0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cece0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cece4: b               #0x8ce6d4
    // 0x8cece8: r9 = _lastLit
    //     0x8cece8: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b38] Field <Deflate._lastLit@60040000>: late (offset: 0xcc)
    //     0x8cecec: ldr             x9, [x9, #0xb38]
    // 0x8cecf0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cecf0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cecf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cecf4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cecf8: b               #0x8ce71c
    // 0x8cecfc: r9 = _pendingBuffer
    //     0x8cecfc: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a10] Field <Deflate._pendingBuffer@60040000>: late (offset: 0x24)
    //     0x8ced00: ldr             x9, [x9, #0xa10]
    // 0x8ced04: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ced04: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ced08: r9 = _dbuf
    //     0x8ced08: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b40] Field <Deflate._dbuf@60040000>: late (offset: 0xd0)
    //     0x8ced0c: ldr             x9, [x9, #0xb40]
    // 0x8ced10: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ced10: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ced14: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ced14: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ced18: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ced18: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ced1c: r9 = _lbuf
    //     0x8ced1c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b48] Field <Deflate._lbuf@60040000>: late (offset: 0xc4)
    //     0x8ced20: ldr             x9, [x9, #0xb48]
    // 0x8ced24: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ced24: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ced28: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ced28: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ced2c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ced2c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ced30: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ced30: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ced34: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ced34: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ced38: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ced38: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _buildBitLengthTree(/* No info */) {
    // ** addr: 0x8cedec, size: 0x234
    // 0x8cedec: EnterFrame
    //     0x8cedec: stp             fp, lr, [SP, #-0x10]!
    //     0x8cedf0: mov             fp, SP
    // 0x8cedf4: CheckStackOverflow
    //     0x8cedf4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cedf8: cmp             SP, x16
    //     0x8cedfc: b.ls            #0x8cefc4
    // 0x8cee00: ldr             x0, [fp, #0x10]
    // 0x8cee04: LoadField: r1 = r0->field_97
    //     0x8cee04: ldur            w1, [x0, #0x97]
    // 0x8cee08: DecompressPointer r1
    //     0x8cee08: add             x1, x1, HEAP, lsl #32
    // 0x8cee0c: r16 = Sentinel
    //     0x8cee0c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cee10: cmp             w1, w16
    // 0x8cee14: b.eq            #0x8cefcc
    // 0x8cee18: LoadField: r2 = r0->field_a3
    //     0x8cee18: ldur            w2, [x0, #0xa3]
    // 0x8cee1c: DecompressPointer r2
    //     0x8cee1c: add             x2, x2, HEAP, lsl #32
    // 0x8cee20: LoadField: r3 = r2->field_b
    //     0x8cee20: ldur            w3, [x2, #0xb]
    // 0x8cee24: DecompressPointer r3
    //     0x8cee24: add             x3, x3, HEAP, lsl #32
    // 0x8cee28: r16 = Sentinel
    //     0x8cee28: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cee2c: cmp             w3, w16
    // 0x8cee30: b.eq            #0x8cefd8
    // 0x8cee34: r2 = LoadInt32Instr(r3)
    //     0x8cee34: sbfx            x2, x3, #1, #0x1f
    //     0x8cee38: tbz             w3, #0, #0x8cee40
    //     0x8cee3c: ldur            x2, [x3, #7]
    // 0x8cee40: stp             x1, x0, [SP, #-0x10]!
    // 0x8cee44: SaveReg r2
    //     0x8cee44: str             x2, [SP, #-8]!
    // 0x8cee48: r0 = _scanTree()
    //     0x8cee48: bl              #0x8cf020  ; [package:archive/src/zlib/deflate.dart] Deflate::_scanTree
    // 0x8cee4c: add             SP, SP, #0x18
    // 0x8cee50: ldr             x0, [fp, #0x10]
    // 0x8cee54: LoadField: r1 = r0->field_9b
    //     0x8cee54: ldur            w1, [x0, #0x9b]
    // 0x8cee58: DecompressPointer r1
    //     0x8cee58: add             x1, x1, HEAP, lsl #32
    // 0x8cee5c: r16 = Sentinel
    //     0x8cee5c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cee60: cmp             w1, w16
    // 0x8cee64: b.eq            #0x8cefe4
    // 0x8cee68: LoadField: r2 = r0->field_a7
    //     0x8cee68: ldur            w2, [x0, #0xa7]
    // 0x8cee6c: DecompressPointer r2
    //     0x8cee6c: add             x2, x2, HEAP, lsl #32
    // 0x8cee70: LoadField: r3 = r2->field_b
    //     0x8cee70: ldur            w3, [x2, #0xb]
    // 0x8cee74: DecompressPointer r3
    //     0x8cee74: add             x3, x3, HEAP, lsl #32
    // 0x8cee78: r16 = Sentinel
    //     0x8cee78: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cee7c: cmp             w3, w16
    // 0x8cee80: b.eq            #0x8ceff0
    // 0x8cee84: r2 = LoadInt32Instr(r3)
    //     0x8cee84: sbfx            x2, x3, #1, #0x1f
    //     0x8cee88: tbz             w3, #0, #0x8cee90
    //     0x8cee8c: ldur            x2, [x3, #7]
    // 0x8cee90: stp             x1, x0, [SP, #-0x10]!
    // 0x8cee94: SaveReg r2
    //     0x8cee94: str             x2, [SP, #-8]!
    // 0x8cee98: r0 = _scanTree()
    //     0x8cee98: bl              #0x8cf020  ; [package:archive/src/zlib/deflate.dart] Deflate::_scanTree
    // 0x8cee9c: add             SP, SP, #0x18
    // 0x8ceea0: ldr             x0, [fp, #0x10]
    // 0x8ceea4: LoadField: r1 = r0->field_ab
    //     0x8ceea4: ldur            w1, [x0, #0xab]
    // 0x8ceea8: DecompressPointer r1
    //     0x8ceea8: add             x1, x1, HEAP, lsl #32
    // 0x8ceeac: stp             x0, x1, [SP, #-0x10]!
    // 0x8ceeb0: r0 = _buildTree()
    //     0x8ceeb0: bl              #0x8cf434  ; [package:archive/src/zlib/deflate.dart] _HuffmanTree::_buildTree
    // 0x8ceeb4: add             SP, SP, #0x10
    // 0x8ceeb8: ldr             x2, [fp, #0x10]
    // 0x8ceebc: LoadField: r3 = r2->field_9f
    //     0x8ceebc: ldur            w3, [x2, #0x9f]
    // 0x8ceec0: DecompressPointer r3
    //     0x8ceec0: add             x3, x3, HEAP, lsl #32
    // 0x8ceec4: r16 = Sentinel
    //     0x8ceec4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8ceec8: cmp             w3, w16
    // 0x8ceecc: b.eq            #0x8ceffc
    // 0x8ceed0: LoadField: r4 = r3->field_13
    //     0x8ceed0: ldur            w4, [x3, #0x13]
    // 0x8ceed4: DecompressPointer r4
    //     0x8ceed4: add             x4, x4, HEAP, lsl #32
    // 0x8ceed8: r5 = LoadInt32Instr(r4)
    //     0x8ceed8: sbfx            x5, x4, #1, #0x1f
    // 0x8ceedc: r6 = 18
    //     0x8ceedc: mov             x6, #0x12
    // 0x8ceee0: r4 = const [0x10, 0x11, 0x12, 0, 0x8, 0x7, 0x9, 0x6, 0xa, 0x5, 0xb, 0x4, 0xc, 0x3, 0xd, 0x2, 0xe, 0x1, 0xf]
    //     0x8ceee0: add             x4, PP, #0x34, lsl #12  ; [pp+0x34b00] List<int>(19)
    //     0x8ceee4: ldr             x4, [x4, #0xb00]
    // 0x8ceee8: CheckStackOverflow
    //     0x8ceee8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8ceeec: cmp             SP, x16
    //     0x8ceef0: b.ls            #0x8cf008
    // 0x8ceef4: cmp             x6, #3
    // 0x8ceef8: b.lt            #0x8cef44
    // 0x8ceefc: ArrayLoad: r7 = r4[r6]  ; Unknown_4
    //     0x8ceefc: add             x16, x4, x6, lsl #2
    //     0x8cef00: ldur            w7, [x16, #0xf]
    // 0x8cef04: DecompressPointer r7
    //     0x8cef04: add             x7, x7, HEAP, lsl #32
    // 0x8cef08: r8 = LoadInt32Instr(r7)
    //     0x8cef08: sbfx            x8, x7, #1, #0x1f
    //     0x8cef0c: tbz             w7, #0, #0x8cef14
    //     0x8cef10: ldur            x8, [x7, #7]
    // 0x8cef14: lsl             x7, x8, #1
    // 0x8cef18: add             x8, x7, #1
    // 0x8cef1c: mov             x0, x5
    // 0x8cef20: mov             x1, x8
    // 0x8cef24: cmp             x1, x0
    // 0x8cef28: b.hs            #0x8cf010
    // 0x8cef2c: add             x16, x3, x8, lsl #1
    // 0x8cef30: ldurh           w7, [x16, #0x17]
    // 0x8cef34: cbnz            x7, #0x8cef44
    // 0x8cef38: sub             x0, x6, #1
    // 0x8cef3c: mov             x6, x0
    // 0x8cef40: b               #0x8ceee8
    // 0x8cef44: LoadField: r3 = r2->field_d3
    //     0x8cef44: ldur            w3, [x2, #0xd3]
    // 0x8cef48: DecompressPointer r3
    //     0x8cef48: add             x3, x3, HEAP, lsl #32
    // 0x8cef4c: r16 = Sentinel
    //     0x8cef4c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cef50: cmp             w3, w16
    // 0x8cef54: b.eq            #0x8cf014
    // 0x8cef58: add             x4, x6, #1
    // 0x8cef5c: r16 = 3
    //     0x8cef5c: mov             x16, #3
    // 0x8cef60: mul             x5, x4, x16
    // 0x8cef64: add             x4, x5, #5
    // 0x8cef68: add             x5, x4, #5
    // 0x8cef6c: add             x4, x5, #4
    // 0x8cef70: r5 = LoadInt32Instr(r3)
    //     0x8cef70: sbfx            x5, x3, #1, #0x1f
    //     0x8cef74: tbz             w3, #0, #0x8cef7c
    //     0x8cef78: ldur            x5, [x3, #7]
    // 0x8cef7c: add             x3, x5, x4
    // 0x8cef80: r0 = BoxInt64Instr(r3)
    //     0x8cef80: sbfiz           x0, x3, #1, #0x1f
    //     0x8cef84: cmp             x3, x0, asr #1
    //     0x8cef88: b.eq            #0x8cef94
    //     0x8cef8c: bl              #0xd69bb8
    //     0x8cef90: stur            x3, [x0, #7]
    // 0x8cef94: StoreField: r2->field_d3 = r0
    //     0x8cef94: stur            w0, [x2, #0xd3]
    //     0x8cef98: tbz             w0, #0, #0x8cefb4
    //     0x8cef9c: ldurb           w16, [x2, #-1]
    //     0x8cefa0: ldurb           w17, [x0, #-1]
    //     0x8cefa4: and             x16, x17, x16, lsr #2
    //     0x8cefa8: tst             x16, HEAP, lsr #32
    //     0x8cefac: b.eq            #0x8cefb4
    //     0x8cefb0: bl              #0xd6828c
    // 0x8cefb4: mov             x0, x6
    // 0x8cefb8: LeaveFrame
    //     0x8cefb8: mov             SP, fp
    //     0x8cefbc: ldp             fp, lr, [SP], #0x10
    // 0x8cefc0: ret
    //     0x8cefc0: ret             
    // 0x8cefc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cefc4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cefc8: b               #0x8cee00
    // 0x8cefcc: r9 = _dynamicLengthTree
    //     0x8cefcc: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ae8] Field <Deflate._dynamicLengthTree@60040000>: late (offset: 0x98)
    //     0x8cefd0: ldr             x9, [x9, #0xae8]
    // 0x8cefd4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cefd4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cefd8: r9 = maxCode
    //     0x8cefd8: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ae0] Field <_HuffmanTree@60040000.maxCode>: late (offset: 0xc)
    //     0x8cefdc: ldr             x9, [x9, #0xae0]
    // 0x8cefe0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cefe0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cefe4: r9 = _dynamicDistTree
    //     0x8cefe4: add             x9, PP, #0x34, lsl #12  ; [pp+0x34af0] Field <Deflate._dynamicDistTree@60040000>: late (offset: 0x9c)
    //     0x8cefe8: ldr             x9, [x9, #0xaf0]
    // 0x8cefec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cefec: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ceff0: r9 = maxCode
    //     0x8ceff0: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ae0] Field <_HuffmanTree@60040000.maxCode>: late (offset: 0xc)
    //     0x8ceff4: ldr             x9, [x9, #0xae0]
    // 0x8ceff8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ceff8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8ceffc: r9 = _bitLengthTree
    //     0x8ceffc: add             x9, PP, #0x34, lsl #12  ; [pp+0x34af8] Field <Deflate._bitLengthTree@60040000>: late (offset: 0xa0)
    //     0x8cf000: ldr             x9, [x9, #0xaf8]
    // 0x8cf004: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cf004: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cf008: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cf008: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cf00c: b               #0x8ceef4
    // 0x8cf010: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cf010: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cf014: r9 = _optimalLen
    //     0x8cf014: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ad0] Field <Deflate._optimalLen@60040000>: late (offset: 0xd4)
    //     0x8cf018: ldr             x9, [x9, #0xad0]
    // 0x8cf01c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cf01c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _scanTree(/* No info */) {
    // ** addr: 0x8cf020, size: 0x414
    // 0x8cf020: EnterFrame
    //     0x8cf020: stp             fp, lr, [SP, #-0x10]!
    //     0x8cf024: mov             fp, SP
    // 0x8cf028: ldr             x2, [fp, #0x18]
    // 0x8cf02c: LoadField: r3 = r2->field_13
    //     0x8cf02c: ldur            w3, [x2, #0x13]
    // 0x8cf030: DecompressPointer r3
    //     0x8cf030: add             x3, x3, HEAP, lsl #32
    // 0x8cf034: r4 = LoadInt32Instr(r3)
    //     0x8cf034: sbfx            x4, x3, #1, #0x1f
    // 0x8cf038: mov             x0, x4
    // 0x8cf03c: r1 = 1
    //     0x8cf03c: mov             x1, #1
    // 0x8cf040: cmp             x1, x0
    // 0x8cf044: b.hs            #0x8cf2ec
    // 0x8cf048: ldurh           w3, [x2, #0x19]
    // 0x8cf04c: cbnz            x3, #0x8cf05c
    // 0x8cf050: r10 = 138
    //     0x8cf050: mov             x10, #0x8a
    // 0x8cf054: r8 = 3
    //     0x8cf054: mov             x8, #3
    // 0x8cf058: b               #0x8cf064
    // 0x8cf05c: r10 = 7
    //     0x8cf05c: mov             x10, #7
    // 0x8cf060: r8 = 4
    //     0x8cf060: mov             x8, #4
    // 0x8cf064: ldr             x7, [fp, #0x10]
    // 0x8cf068: r6 = 1
    //     0x8cf068: mov             x6, #1
    // 0x8cf06c: r5 = 65535
    //     0x8cf06c: mov             x5, #0xffff
    // 0x8cf070: add             x11, x7, #1
    // 0x8cf074: cmp             x6, #0x3f
    // 0x8cf078: b.hi            #0x8cf2f0
    // 0x8cf07c: lsl             x12, x11, x6
    // 0x8cf080: add             x9, x12, #1
    // 0x8cf084: mov             x0, x4
    // 0x8cf088: mov             x1, x9
    // 0x8cf08c: cmp             x1, x0
    // 0x8cf090: b.hs            #0x8cf328
    // 0x8cf094: LoadField: r11 = r2->field_7
    //     0x8cf094: ldur            x11, [x2, #7]
    // 0x8cf098: add             x12, x11, x9, lsl #1
    // 0x8cf09c: strh            w5, [x12]
    // 0x8cf0a0: mov             x11, x3
    // 0x8cf0a4: mov             x5, x8
    // 0x8cf0a8: mov             x8, x10
    // 0x8cf0ac: ldr             x3, [fp, #0x20]
    // 0x8cf0b0: r13 = 0
    //     0x8cf0b0: mov             x13, #0
    // 0x8cf0b4: r12 = -1
    //     0x8cf0b4: mov             x12, #-1
    // 0x8cf0b8: r10 = 0
    //     0x8cf0b8: mov             x10, #0
    // 0x8cf0bc: CheckStackOverflow
    //     0x8cf0bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8cf0c0: cmp             SP, x16
    //     0x8cf0c4: b.ls            #0x8cf32c
    // 0x8cf0c8: cmp             x13, x7
    // 0x8cf0cc: b.gt            #0x8cf2dc
    // 0x8cf0d0: add             x14, x13, #1
    // 0x8cf0d4: cmp             x6, #0x3f
    // 0x8cf0d8: b.hi            #0x8cf334
    // 0x8cf0dc: lsl             x13, x14, x6
    // 0x8cf0e0: add             x9, x13, #1
    // 0x8cf0e4: mov             x0, x4
    // 0x8cf0e8: mov             x1, x9
    // 0x8cf0ec: cmp             x1, x0
    // 0x8cf0f0: b.hs            #0x8cf370
    // 0x8cf0f4: add             x16, x2, x9, lsl #1
    // 0x8cf0f8: ldurh           w19, [x16, #0x17]
    // 0x8cf0fc: add             x20, x10, #1
    // 0x8cf100: cmp             x20, x8
    // 0x8cf104: b.ge            #0x8cf118
    // 0x8cf108: cmp             x11, x19
    // 0x8cf10c: b.ne            #0x8cf118
    // 0x8cf110: mov             x10, x20
    // 0x8cf114: b               #0x8cf2d0
    // 0x8cf118: cmp             x20, x5
    // 0x8cf11c: b.ge            #0x8cf174
    // 0x8cf120: LoadField: r5 = r3->field_9f
    //     0x8cf120: ldur            w5, [x3, #0x9f]
    // 0x8cf124: DecompressPointer r5
    //     0x8cf124: add             x5, x5, HEAP, lsl #32
    // 0x8cf128: r16 = Sentinel
    //     0x8cf128: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cf12c: cmp             w5, w16
    // 0x8cf130: b.eq            #0x8cf374
    // 0x8cf134: cmp             x6, #0x3f
    // 0x8cf138: b.hi            #0x8cf380
    // 0x8cf13c: lsl             x8, x11, x6
    // 0x8cf140: LoadField: r10 = r5->field_13
    //     0x8cf140: ldur            w10, [x5, #0x13]
    // 0x8cf144: DecompressPointer r10
    //     0x8cf144: add             x10, x10, HEAP, lsl #32
    // 0x8cf148: r0 = LoadInt32Instr(r10)
    //     0x8cf148: sbfx            x0, x10, #1, #0x1f
    // 0x8cf14c: mov             x1, x8
    // 0x8cf150: cmp             x1, x0
    // 0x8cf154: b.hs            #0x8cf3b8
    // 0x8cf158: add             x16, x5, x8, lsl #1
    // 0x8cf15c: ldurh           w10, [x16, #0x17]
    // 0x8cf160: add             x13, x10, x20
    // 0x8cf164: LoadField: r10 = r5->field_7
    //     0x8cf164: ldur            x10, [x5, #7]
    // 0x8cf168: add             x5, x10, x8, lsl #1
    // 0x8cf16c: strh            w13, [x5]
    // 0x8cf170: b               #0x8cf294
    // 0x8cf174: cbz             x11, #0x8cf210
    // 0x8cf178: cmp             x11, x12
    // 0x8cf17c: b.eq            #0x8cf1d0
    // 0x8cf180: LoadField: r5 = r3->field_9f
    //     0x8cf180: ldur            w5, [x3, #0x9f]
    // 0x8cf184: DecompressPointer r5
    //     0x8cf184: add             x5, x5, HEAP, lsl #32
    // 0x8cf188: r16 = Sentinel
    //     0x8cf188: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cf18c: cmp             w5, w16
    // 0x8cf190: b.eq            #0x8cf3bc
    // 0x8cf194: cmp             x6, #0x3f
    // 0x8cf198: b.hi            #0x8cf3c8
    // 0x8cf19c: lsl             x8, x11, x6
    // 0x8cf1a0: LoadField: r10 = r5->field_13
    //     0x8cf1a0: ldur            w10, [x5, #0x13]
    // 0x8cf1a4: DecompressPointer r10
    //     0x8cf1a4: add             x10, x10, HEAP, lsl #32
    // 0x8cf1a8: r0 = LoadInt32Instr(r10)
    //     0x8cf1a8: sbfx            x0, x10, #1, #0x1f
    // 0x8cf1ac: mov             x1, x8
    // 0x8cf1b0: cmp             x1, x0
    // 0x8cf1b4: b.hs            #0x8cf400
    // 0x8cf1b8: add             x16, x5, x8, lsl #1
    // 0x8cf1bc: ldurh           w10, [x16, #0x17]
    // 0x8cf1c0: add             x12, x10, #1
    // 0x8cf1c4: LoadField: r10 = r5->field_7
    //     0x8cf1c4: ldur            x10, [x5, #7]
    // 0x8cf1c8: add             x5, x10, x8, lsl #1
    // 0x8cf1cc: strh            w12, [x5]
    // 0x8cf1d0: LoadField: r5 = r3->field_9f
    //     0x8cf1d0: ldur            w5, [x3, #0x9f]
    // 0x8cf1d4: DecompressPointer r5
    //     0x8cf1d4: add             x5, x5, HEAP, lsl #32
    // 0x8cf1d8: r16 = Sentinel
    //     0x8cf1d8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cf1dc: cmp             w5, w16
    // 0x8cf1e0: b.eq            #0x8cf404
    // 0x8cf1e4: LoadField: r8 = r5->field_13
    //     0x8cf1e4: ldur            w8, [x5, #0x13]
    // 0x8cf1e8: DecompressPointer r8
    //     0x8cf1e8: add             x8, x8, HEAP, lsl #32
    // 0x8cf1ec: r0 = LoadInt32Instr(r8)
    //     0x8cf1ec: sbfx            x0, x8, #1, #0x1f
    // 0x8cf1f0: r1 = 32
    //     0x8cf1f0: mov             x1, #0x20
    // 0x8cf1f4: cmp             x1, x0
    // 0x8cf1f8: b.hs            #0x8cf410
    // 0x8cf1fc: ldurh           w8, [x5, #0x57]
    // 0x8cf200: add             x10, x8, #1
    // 0x8cf204: LoadField: r8 = r5->field_7
    //     0x8cf204: ldur            x8, [x5, #7]
    // 0x8cf208: strh            w10, [x8, #0x40]
    // 0x8cf20c: b               #0x8cf294
    // 0x8cf210: cmp             x20, #0xa
    // 0x8cf214: b.gt            #0x8cf258
    // 0x8cf218: LoadField: r5 = r3->field_9f
    //     0x8cf218: ldur            w5, [x3, #0x9f]
    // 0x8cf21c: DecompressPointer r5
    //     0x8cf21c: add             x5, x5, HEAP, lsl #32
    // 0x8cf220: r16 = Sentinel
    //     0x8cf220: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cf224: cmp             w5, w16
    // 0x8cf228: b.eq            #0x8cf414
    // 0x8cf22c: LoadField: r8 = r5->field_13
    //     0x8cf22c: ldur            w8, [x5, #0x13]
    // 0x8cf230: DecompressPointer r8
    //     0x8cf230: add             x8, x8, HEAP, lsl #32
    // 0x8cf234: r0 = LoadInt32Instr(r8)
    //     0x8cf234: sbfx            x0, x8, #1, #0x1f
    // 0x8cf238: r1 = 34
    //     0x8cf238: mov             x1, #0x22
    // 0x8cf23c: cmp             x1, x0
    // 0x8cf240: b.hs            #0x8cf420
    // 0x8cf244: ldurh           w8, [x5, #0x5b]
    // 0x8cf248: add             x10, x8, #1
    // 0x8cf24c: LoadField: r8 = r5->field_7
    //     0x8cf24c: ldur            x8, [x5, #7]
    // 0x8cf250: strh            w10, [x8, #0x44]
    // 0x8cf254: b               #0x8cf294
    // 0x8cf258: LoadField: r5 = r3->field_9f
    //     0x8cf258: ldur            w5, [x3, #0x9f]
    // 0x8cf25c: DecompressPointer r5
    //     0x8cf25c: add             x5, x5, HEAP, lsl #32
    // 0x8cf260: r16 = Sentinel
    //     0x8cf260: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8cf264: cmp             w5, w16
    // 0x8cf268: b.eq            #0x8cf424
    // 0x8cf26c: LoadField: r8 = r5->field_13
    //     0x8cf26c: ldur            w8, [x5, #0x13]
    // 0x8cf270: DecompressPointer r8
    //     0x8cf270: add             x8, x8, HEAP, lsl #32
    // 0x8cf274: r0 = LoadInt32Instr(r8)
    //     0x8cf274: sbfx            x0, x8, #1, #0x1f
    // 0x8cf278: r1 = 36
    //     0x8cf278: mov             x1, #0x24
    // 0x8cf27c: cmp             x1, x0
    // 0x8cf280: b.hs            #0x8cf430
    // 0x8cf284: ldurh           w1, [x5, #0x5f]
    // 0x8cf288: add             x8, x1, #1
    // 0x8cf28c: LoadField: r1 = r5->field_7
    //     0x8cf28c: ldur            x1, [x5, #7]
    // 0x8cf290: strh            w8, [x1, #0x48]
    // 0x8cf294: cbnz            x19, #0x8cf2a4
    // 0x8cf298: r0 = 138
    //     0x8cf298: mov             x0, #0x8a
    // 0x8cf29c: r1 = 3
    //     0x8cf29c: mov             x1, #3
    // 0x8cf2a0: b               #0x8cf2c0
    // 0x8cf2a4: cmp             x11, x19
    // 0x8cf2a8: b.ne            #0x8cf2b8
    // 0x8cf2ac: r0 = 6
    //     0x8cf2ac: mov             x0, #6
    // 0x8cf2b0: r1 = 3
    //     0x8cf2b0: mov             x1, #3
    // 0x8cf2b4: b               #0x8cf2c0
    // 0x8cf2b8: r0 = 7
    //     0x8cf2b8: mov             x0, #7
    // 0x8cf2bc: r1 = 4
    //     0x8cf2bc: mov             x1, #4
    // 0x8cf2c0: mov             x12, x11
    // 0x8cf2c4: mov             x8, x0
    // 0x8cf2c8: mov             x5, x1
    // 0x8cf2cc: r10 = 0
    //     0x8cf2cc: mov             x10, #0
    // 0x8cf2d0: mov             x13, x14
    // 0x8cf2d4: mov             x11, x19
    // 0x8cf2d8: b               #0x8cf0bc
    // 0x8cf2dc: r0 = Null
    //     0x8cf2dc: mov             x0, NULL
    // 0x8cf2e0: LeaveFrame
    //     0x8cf2e0: mov             SP, fp
    //     0x8cf2e4: ldp             fp, lr, [SP], #0x10
    // 0x8cf2e8: ret
    //     0x8cf2e8: ret             
    // 0x8cf2ec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cf2ec: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cf2f0: tbnz            x6, #0x3f, #0x8cf2fc
    // 0x8cf2f4: mov             x12, xzr
    // 0x8cf2f8: b               #0x8cf080
    // 0x8cf2fc: str             x6, [THR, #0xc0]  ; THR::
    // 0x8cf300: stp             x10, x11, [SP, #-0x10]!
    // 0x8cf304: stp             x7, x8, [SP, #-0x10]!
    // 0x8cf308: stp             x5, x6, [SP, #-0x10]!
    // 0x8cf30c: stp             x3, x4, [SP, #-0x10]!
    // 0x8cf310: SaveReg r2
    //     0x8cf310: str             x2, [SP, #-8]!
    // 0x8cf314: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x8cf318: r4 = 0
    //     0x8cf318: mov             x4, #0
    // 0x8cf31c: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8cf320: blr             lr
    // 0x8cf324: brk             #0
    // 0x8cf328: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cf328: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cf32c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cf32c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cf330: b               #0x8cf0c8
    // 0x8cf334: tbnz            x6, #0x3f, #0x8cf340
    // 0x8cf338: mov             x13, xzr
    // 0x8cf33c: b               #0x8cf0e0
    // 0x8cf340: str             x6, [THR, #0xc0]  ; THR::
    // 0x8cf344: stp             x12, x14, [SP, #-0x10]!
    // 0x8cf348: stp             x10, x11, [SP, #-0x10]!
    // 0x8cf34c: stp             x7, x8, [SP, #-0x10]!
    // 0x8cf350: stp             x5, x6, [SP, #-0x10]!
    // 0x8cf354: stp             x3, x4, [SP, #-0x10]!
    // 0x8cf358: SaveReg r2
    //     0x8cf358: str             x2, [SP, #-8]!
    // 0x8cf35c: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x8cf360: r4 = 0
    //     0x8cf360: mov             x4, #0
    // 0x8cf364: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8cf368: blr             lr
    // 0x8cf36c: brk             #0
    // 0x8cf370: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cf370: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cf374: r9 = _bitLengthTree
    //     0x8cf374: add             x9, PP, #0x34, lsl #12  ; [pp+0x34af8] Field <Deflate._bitLengthTree@60040000>: late (offset: 0xa0)
    //     0x8cf378: ldr             x9, [x9, #0xaf8]
    // 0x8cf37c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cf37c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cf380: tbnz            x6, #0x3f, #0x8cf38c
    // 0x8cf384: mov             x8, xzr
    // 0x8cf388: b               #0x8cf140
    // 0x8cf38c: str             x6, [THR, #0xc0]  ; THR::
    // 0x8cf390: stp             x19, x20, [SP, #-0x10]!
    // 0x8cf394: stp             x11, x14, [SP, #-0x10]!
    // 0x8cf398: stp             x6, x7, [SP, #-0x10]!
    // 0x8cf39c: stp             x4, x5, [SP, #-0x10]!
    // 0x8cf3a0: stp             x2, x3, [SP, #-0x10]!
    // 0x8cf3a4: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x8cf3a8: r4 = 0
    //     0x8cf3a8: mov             x4, #0
    // 0x8cf3ac: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8cf3b0: blr             lr
    // 0x8cf3b4: brk             #0
    // 0x8cf3b8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cf3b8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cf3bc: r9 = _bitLengthTree
    //     0x8cf3bc: add             x9, PP, #0x34, lsl #12  ; [pp+0x34af8] Field <Deflate._bitLengthTree@60040000>: late (offset: 0xa0)
    //     0x8cf3c0: ldr             x9, [x9, #0xaf8]
    // 0x8cf3c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cf3c4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cf3c8: tbnz            x6, #0x3f, #0x8cf3d4
    // 0x8cf3cc: mov             x8, xzr
    // 0x8cf3d0: b               #0x8cf1a0
    // 0x8cf3d4: str             x6, [THR, #0xc0]  ; THR::
    // 0x8cf3d8: stp             x14, x19, [SP, #-0x10]!
    // 0x8cf3dc: stp             x7, x11, [SP, #-0x10]!
    // 0x8cf3e0: stp             x5, x6, [SP, #-0x10]!
    // 0x8cf3e4: stp             x3, x4, [SP, #-0x10]!
    // 0x8cf3e8: SaveReg r2
    //     0x8cf3e8: str             x2, [SP, #-8]!
    // 0x8cf3ec: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x8cf3f0: r4 = 0
    //     0x8cf3f0: mov             x4, #0
    // 0x8cf3f4: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8cf3f8: blr             lr
    // 0x8cf3fc: brk             #0
    // 0x8cf400: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cf400: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cf404: r9 = _bitLengthTree
    //     0x8cf404: add             x9, PP, #0x34, lsl #12  ; [pp+0x34af8] Field <Deflate._bitLengthTree@60040000>: late (offset: 0xa0)
    //     0x8cf408: ldr             x9, [x9, #0xaf8]
    // 0x8cf40c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cf40c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cf410: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cf410: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cf414: r9 = _bitLengthTree
    //     0x8cf414: add             x9, PP, #0x34, lsl #12  ; [pp+0x34af8] Field <Deflate._bitLengthTree@60040000>: late (offset: 0xa0)
    //     0x8cf418: ldr             x9, [x9, #0xaf8]
    // 0x8cf41c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cf41c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cf420: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cf420: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cf424: r9 = _bitLengthTree
    //     0x8cf424: add             x9, PP, #0x34, lsl #12  ; [pp+0x34af8] Field <Deflate._bitLengthTree@60040000>: late (offset: 0xa0)
    //     0x8cf428: ldr             x9, [x9, #0xaf8]
    // 0x8cf42c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cf42c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8cf430: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cf430: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _pqdownheap(/* No info */) {
    // ** addr: 0x8d0690, size: 0x2d4
    // 0x8d0690: EnterFrame
    //     0x8d0690: stp             fp, lr, [SP, #-0x10]!
    //     0x8d0694: mov             fp, SP
    // 0x8d0698: AllocStack(0x10)
    //     0x8d0698: sub             SP, SP, #0x10
    // 0x8d069c: ldr             x2, [fp, #0x20]
    // 0x8d06a0: LoadField: r3 = r2->field_b3
    //     0x8d06a0: ldur            w3, [x2, #0xb3]
    // 0x8d06a4: DecompressPointer r3
    //     0x8d06a4: add             x3, x3, HEAP, lsl #32
    // 0x8d06a8: LoadField: r4 = r3->field_13
    //     0x8d06a8: ldur            w4, [x3, #0x13]
    // 0x8d06ac: DecompressPointer r4
    //     0x8d06ac: add             x4, x4, HEAP, lsl #32
    // 0x8d06b0: r5 = LoadInt32Instr(r4)
    //     0x8d06b0: sbfx            x5, x4, #1, #0x1f
    // 0x8d06b4: mov             x0, x5
    // 0x8d06b8: ldr             x1, [fp, #0x10]
    // 0x8d06bc: stur            x5, [fp, #-0x10]
    // 0x8d06c0: cmp             x1, x0
    // 0x8d06c4: b.hs            #0x8d0918
    // 0x8d06c8: ldr             x4, [fp, #0x10]
    // 0x8d06cc: ArrayLoad: r6 = r3[r4]  ; Unknown_4
    //     0x8d06cc: add             x16, x3, x4, lsl #2
    //     0x8d06d0: ldur            w6, [x16, #0x17]
    // 0x8d06d4: stur            x6, [fp, #-8]
    // 0x8d06d8: lsl             x7, x4, #1
    // 0x8d06dc: LoadField: r8 = r2->field_b7
    //     0x8d06dc: ldur            w8, [x2, #0xb7]
    // 0x8d06e0: DecompressPointer r8
    //     0x8d06e0: add             x8, x8, HEAP, lsl #32
    // 0x8d06e4: r16 = Sentinel
    //     0x8d06e4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d06e8: cmp             w8, w16
    // 0x8d06ec: b.eq            #0x8d091c
    // 0x8d06f0: r9 = LoadInt32Instr(r8)
    //     0x8d06f0: sbfx            x9, x8, #1, #0x1f
    //     0x8d06f4: tbz             w8, #0, #0x8d06fc
    //     0x8d06f8: ldur            x9, [x8, #7]
    // 0x8d06fc: LoadField: r8 = r2->field_bf
    //     0x8d06fc: ldur            w8, [x2, #0xbf]
    // 0x8d0700: DecompressPointer r8
    //     0x8d0700: add             x8, x8, HEAP, lsl #32
    // 0x8d0704: mov             x10, x6
    // 0x8d0708: ubfx            x10, x10, #0, #0x20
    // 0x8d070c: lsl             x11, x10, #1
    // 0x8d0710: ldr             x12, [fp, #0x18]
    // 0x8d0714: LoadField: r13 = r12->field_13
    //     0x8d0714: ldur            w13, [x12, #0x13]
    // 0x8d0718: DecompressPointer r13
    //     0x8d0718: add             x13, x13, HEAP, lsl #32
    // 0x8d071c: r14 = LoadInt32Instr(r13)
    //     0x8d071c: sbfx            x14, x13, #1, #0x1f
    // 0x8d0720: LoadField: r19 = r8->field_13
    //     0x8d0720: ldur            w19, [x8, #0x13]
    // 0x8d0724: DecompressPointer r19
    //     0x8d0724: add             x19, x19, HEAP, lsl #32
    // 0x8d0728: r20 = LoadInt32Instr(r19)
    //     0x8d0728: sbfx            x20, x19, #1, #0x1f
    // 0x8d072c: r23 = LoadInt32Instr(r13)
    //     0x8d072c: sbfx            x23, x13, #1, #0x1f
    // 0x8d0730: r13 = LoadInt32Instr(r19)
    //     0x8d0730: sbfx            x13, x19, #1, #0x1f
    // 0x8d0734: mov             x16, x7
    // 0x8d0738: mov             x7, x4
    // 0x8d073c: mov             x4, x16
    // 0x8d0740: CheckStackOverflow
    //     0x8d0740: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d0744: cmp             SP, x16
    //     0x8d0748: b.ls            #0x8d0928
    // 0x8d074c: cmp             x4, x9
    // 0x8d0750: b.gt            #0x8d08ec
    // 0x8d0754: cmp             x4, x9
    // 0x8d0758: b.ge            #0x8d0824
    // 0x8d075c: add             x19, x4, #1
    // 0x8d0760: ldur            x0, [fp, #-0x10]
    // 0x8d0764: mov             x1, x19
    // 0x8d0768: cmp             x1, x0
    // 0x8d076c: b.hs            #0x8d0930
    // 0x8d0770: ArrayLoad: r24 = r3[r19]  ; Unknown_4
    //     0x8d0770: add             x16, x3, x19, lsl #2
    //     0x8d0774: ldur            w24, [x16, #0x17]
    // 0x8d0778: ldur            x0, [fp, #-0x10]
    // 0x8d077c: mov             x1, x4
    // 0x8d0780: cmp             x1, x0
    // 0x8d0784: b.hs            #0x8d0934
    // 0x8d0788: ArrayLoad: r25 = r3[r4]  ; Unknown_4
    //     0x8d0788: add             x16, x3, x4, lsl #2
    //     0x8d078c: ldur            w25, [x16, #0x17]
    // 0x8d0790: ubfx            x24, x24, #0, #0x20
    // 0x8d0794: lsl             x1, x24, #1
    // 0x8d0798: mov             x0, x23
    // 0x8d079c: mov             x6, x1
    // 0x8d07a0: cmp             x1, x0
    // 0x8d07a4: b.hs            #0x8d0938
    // 0x8d07a8: add             x16, x12, x6, lsl #1
    // 0x8d07ac: ldurh           w0, [x16, #0x17]
    // 0x8d07b0: ubfx            x25, x25, #0, #0x20
    // 0x8d07b4: lsl             x6, x25, #1
    // 0x8d07b8: mov             x5, x0
    // 0x8d07bc: mov             x0, x23
    // 0x8d07c0: mov             x1, x6
    // 0x8d07c4: cmp             x1, x0
    // 0x8d07c8: b.hs            #0x8d093c
    // 0x8d07cc: add             x16, x12, x6, lsl #1
    // 0x8d07d0: ldurh           w0, [x16, #0x17]
    // 0x8d07d4: cmp             x5, x0
    // 0x8d07d8: b.lt            #0x8d081c
    // 0x8d07dc: cmp             x5, x0
    // 0x8d07e0: b.ne            #0x8d0824
    // 0x8d07e4: mov             x0, x13
    // 0x8d07e8: mov             x1, x24
    // 0x8d07ec: cmp             x1, x0
    // 0x8d07f0: b.hs            #0x8d0940
    // 0x8d07f4: ArrayLoad: r5 = r8[r24]  ; TypedUnsigned_1
    //     0x8d07f4: add             x16, x8, x24
    //     0x8d07f8: ldrb            w5, [x16, #0x17]
    // 0x8d07fc: mov             x0, x13
    // 0x8d0800: mov             x1, x25
    // 0x8d0804: cmp             x1, x0
    // 0x8d0808: b.hs            #0x8d0944
    // 0x8d080c: ArrayLoad: r6 = r8[r25]  ; TypedUnsigned_1
    //     0x8d080c: add             x16, x8, x25
    //     0x8d0810: ldrb            w6, [x16, #0x17]
    // 0x8d0814: cmp             x5, x6
    // 0x8d0818: b.gt            #0x8d0824
    // 0x8d081c: mov             x5, x19
    // 0x8d0820: b               #0x8d0828
    // 0x8d0824: mov             x5, x4
    // 0x8d0828: ldur            x0, [fp, #-0x10]
    // 0x8d082c: mov             x1, x5
    // 0x8d0830: cmp             x1, x0
    // 0x8d0834: b.hs            #0x8d0948
    // 0x8d0838: ArrayLoad: r4 = r3[r5]  ; Unknown_4
    //     0x8d0838: add             x16, x3, x5, lsl #2
    //     0x8d083c: ldur            w4, [x16, #0x17]
    // 0x8d0840: mov             x0, x14
    // 0x8d0844: mov             x1, x11
    // 0x8d0848: cmp             x1, x0
    // 0x8d084c: b.hs            #0x8d094c
    // 0x8d0850: add             x16, x12, x11, lsl #1
    // 0x8d0854: ldurh           w6, [x16, #0x17]
    // 0x8d0858: mov             x19, x4
    // 0x8d085c: ubfx            x19, x19, #0, #0x20
    // 0x8d0860: lsl             x24, x19, #1
    // 0x8d0864: mov             x0, x14
    // 0x8d0868: mov             x1, x24
    // 0x8d086c: cmp             x1, x0
    // 0x8d0870: b.hs            #0x8d0950
    // 0x8d0874: add             x16, x12, x24, lsl #1
    // 0x8d0878: ldurh           w25, [x16, #0x17]
    // 0x8d087c: cmp             x6, x25
    // 0x8d0880: b.lt            #0x8d08ec
    // 0x8d0884: cmp             x6, x25
    // 0x8d0888: b.ne            #0x8d08c4
    // 0x8d088c: mov             x0, x20
    // 0x8d0890: mov             x1, x10
    // 0x8d0894: cmp             x1, x0
    // 0x8d0898: b.hs            #0x8d0954
    // 0x8d089c: ArrayLoad: r6 = r8[r10]  ; TypedUnsigned_1
    //     0x8d089c: add             x16, x8, x10
    //     0x8d08a0: ldrb            w6, [x16, #0x17]
    // 0x8d08a4: mov             x0, x20
    // 0x8d08a8: mov             x1, x19
    // 0x8d08ac: cmp             x1, x0
    // 0x8d08b0: b.hs            #0x8d0958
    // 0x8d08b4: ArrayLoad: r24 = r8[r19]  ; TypedUnsigned_1
    //     0x8d08b4: add             x16, x8, x19
    //     0x8d08b8: ldrb            w24, [x16, #0x17]
    // 0x8d08bc: cmp             x6, x24
    // 0x8d08c0: b.le            #0x8d08ec
    // 0x8d08c4: ldur            x0, [fp, #-0x10]
    // 0x8d08c8: mov             x1, x7
    // 0x8d08cc: cmp             x1, x0
    // 0x8d08d0: b.hs            #0x8d095c
    // 0x8d08d4: ArrayStore: r3[r7] = r4  ; Unknown_4
    //     0x8d08d4: add             x6, x3, x7, lsl #2
    //     0x8d08d8: stur            w4, [x6, #0x17]
    // 0x8d08dc: lsl             x4, x5, #1
    // 0x8d08e0: mov             x7, x5
    // 0x8d08e4: ldur            x6, [fp, #-8]
    // 0x8d08e8: b               #0x8d0740
    // 0x8d08ec: ldur            x2, [fp, #-8]
    // 0x8d08f0: ldur            x0, [fp, #-0x10]
    // 0x8d08f4: mov             x1, x7
    // 0x8d08f8: cmp             x1, x0
    // 0x8d08fc: b.hs            #0x8d0960
    // 0x8d0900: ArrayStore: r3[r7] = r2  ; Unknown_4
    //     0x8d0900: add             x1, x3, x7, lsl #2
    //     0x8d0904: stur            w2, [x1, #0x17]
    // 0x8d0908: r0 = Null
    //     0x8d0908: mov             x0, NULL
    // 0x8d090c: LeaveFrame
    //     0x8d090c: mov             SP, fp
    //     0x8d0910: ldp             fp, lr, [SP], #0x10
    // 0x8d0914: ret
    //     0x8d0914: ret             
    // 0x8d0918: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d0918: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d091c: r9 = _heapLen
    //     0x8d091c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b60] Field <Deflate._heapLen@60040000>: late (offset: 0xb8)
    //     0x8d0920: ldr             x9, [x9, #0xb60]
    // 0x8d0924: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d0924: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d0928: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d0928: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d092c: b               #0x8d074c
    // 0x8d0930: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d0930: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d0934: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d0934: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d0938: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d0938: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d093c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d093c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d0940: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d0940: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d0944: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d0944: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d0948: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d0948: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d094c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d094c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d0950: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d0950: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d0954: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d0954: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d0958: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d0958: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d095c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d095c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d0960: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d0960: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ setDataType(/* No info */) {
    // ** addr: 0x8d0964, size: 0x1cc
    // 0x8d0964: EnterFrame
    //     0x8d0964: stp             fp, lr, [SP, #-0x10]!
    //     0x8d0968: mov             fp, SP
    // 0x8d096c: ldr             x2, [fp, #0x10]
    // 0x8d0970: LoadField: r3 = r2->field_97
    //     0x8d0970: ldur            w3, [x2, #0x97]
    // 0x8d0974: DecompressPointer r3
    //     0x8d0974: add             x3, x3, HEAP, lsl #32
    // 0x8d0978: r16 = Sentinel
    //     0x8d0978: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d097c: cmp             w3, w16
    // 0x8d0980: b.eq            #0x8d0ae8
    // 0x8d0984: LoadField: r4 = r3->field_13
    //     0x8d0984: ldur            w4, [x3, #0x13]
    // 0x8d0988: DecompressPointer r4
    //     0x8d0988: add             x4, x4, HEAP, lsl #32
    // 0x8d098c: r5 = LoadInt32Instr(r4)
    //     0x8d098c: sbfx            x5, x4, #1, #0x1f
    // 0x8d0990: r6 = 0
    //     0x8d0990: mov             x6, #0
    // 0x8d0994: r4 = 0
    //     0x8d0994: mov             x4, #0
    // 0x8d0998: CheckStackOverflow
    //     0x8d0998: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d099c: cmp             SP, x16
    //     0x8d09a0: b.ls            #0x8d0af4
    // 0x8d09a4: cmp             x6, #7
    // 0x8d09a8: b.ge            #0x8d09dc
    // 0x8d09ac: lsl             x7, x6, #1
    // 0x8d09b0: mov             x0, x5
    // 0x8d09b4: mov             x1, x7
    // 0x8d09b8: cmp             x1, x0
    // 0x8d09bc: b.hs            #0x8d0afc
    // 0x8d09c0: add             x16, x3, x7, lsl #1
    // 0x8d09c4: ldurh           w8, [x16, #0x17]
    // 0x8d09c8: add             x0, x4, x8
    // 0x8d09cc: add             x1, x6, #1
    // 0x8d09d0: mov             x6, x1
    // 0x8d09d4: mov             x4, x0
    // 0x8d09d8: b               #0x8d0998
    // 0x8d09dc: mov             x5, x6
    // 0x8d09e0: r3 = 0
    //     0x8d09e0: mov             x3, #0
    // 0x8d09e4: CheckStackOverflow
    //     0x8d09e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d09e8: cmp             SP, x16
    //     0x8d09ec: b.ls            #0x8d0b00
    // 0x8d09f0: cmp             x5, #0x80
    // 0x8d09f4: b.ge            #0x8d0a44
    // 0x8d09f8: LoadField: r6 = r2->field_97
    //     0x8d09f8: ldur            w6, [x2, #0x97]
    // 0x8d09fc: DecompressPointer r6
    //     0x8d09fc: add             x6, x6, HEAP, lsl #32
    // 0x8d0a00: r16 = Sentinel
    //     0x8d0a00: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d0a04: cmp             w6, w16
    // 0x8d0a08: b.eq            #0x8d0b08
    // 0x8d0a0c: lsl             x7, x5, #1
    // 0x8d0a10: LoadField: r8 = r6->field_13
    //     0x8d0a10: ldur            w8, [x6, #0x13]
    // 0x8d0a14: DecompressPointer r8
    //     0x8d0a14: add             x8, x8, HEAP, lsl #32
    // 0x8d0a18: r0 = LoadInt32Instr(r8)
    //     0x8d0a18: sbfx            x0, x8, #1, #0x1f
    // 0x8d0a1c: mov             x1, x7
    // 0x8d0a20: cmp             x1, x0
    // 0x8d0a24: b.hs            #0x8d0b14
    // 0x8d0a28: add             x16, x6, x7, lsl #1
    // 0x8d0a2c: ldurh           w8, [x16, #0x17]
    // 0x8d0a30: add             x0, x3, x8
    // 0x8d0a34: add             x1, x5, #1
    // 0x8d0a38: mov             x5, x1
    // 0x8d0a3c: mov             x3, x0
    // 0x8d0a40: b               #0x8d09e4
    // 0x8d0a44: CheckStackOverflow
    //     0x8d0a44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d0a48: cmp             SP, x16
    //     0x8d0a4c: b.ls            #0x8d0b18
    // 0x8d0a50: cmp             x5, #0x100
    // 0x8d0a54: b.ge            #0x8d0aa4
    // 0x8d0a58: LoadField: r6 = r2->field_97
    //     0x8d0a58: ldur            w6, [x2, #0x97]
    // 0x8d0a5c: DecompressPointer r6
    //     0x8d0a5c: add             x6, x6, HEAP, lsl #32
    // 0x8d0a60: r16 = Sentinel
    //     0x8d0a60: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d0a64: cmp             w6, w16
    // 0x8d0a68: b.eq            #0x8d0b20
    // 0x8d0a6c: lsl             x7, x5, #1
    // 0x8d0a70: LoadField: r8 = r6->field_13
    //     0x8d0a70: ldur            w8, [x6, #0x13]
    // 0x8d0a74: DecompressPointer r8
    //     0x8d0a74: add             x8, x8, HEAP, lsl #32
    // 0x8d0a78: r0 = LoadInt32Instr(r8)
    //     0x8d0a78: sbfx            x0, x8, #1, #0x1f
    // 0x8d0a7c: mov             x1, x7
    // 0x8d0a80: cmp             x1, x0
    // 0x8d0a84: b.hs            #0x8d0b2c
    // 0x8d0a88: add             x16, x6, x7, lsl #1
    // 0x8d0a8c: ldurh           w1, [x16, #0x17]
    // 0x8d0a90: add             x0, x4, x1
    // 0x8d0a94: add             x1, x5, #1
    // 0x8d0a98: mov             x5, x1
    // 0x8d0a9c: mov             x4, x0
    // 0x8d0aa0: b               #0x8d0a44
    // 0x8d0aa4: tbnz            x3, #0x3f, #0x8d0ab0
    // 0x8d0aa8: asr             x1, x3, #2
    // 0x8d0aac: b               #0x8d0ab4
    // 0x8d0ab0: asr             x1, x3, #2
    // 0x8d0ab4: cmp             x4, x1
    // 0x8d0ab8: r16 = true
    //     0x8d0ab8: add             x16, NULL, #0x20  ; true
    // 0x8d0abc: r17 = false
    //     0x8d0abc: add             x17, NULL, #0x30  ; false
    // 0x8d0ac0: csel            x3, x16, x17, gt
    // 0x8d0ac4: tst             x3, #0x10
    // 0x8d0ac8: cset            x1, ne
    // 0x8d0acc: lsl             x1, x1, #1
    // 0x8d0ad0: r3 = LoadInt32Instr(r1)
    //     0x8d0ad0: sbfx            x3, x1, #1, #0x1f
    // 0x8d0ad4: StoreField: r2->field_33 = r3
    //     0x8d0ad4: stur            x3, [x2, #0x33]
    // 0x8d0ad8: r0 = Null
    //     0x8d0ad8: mov             x0, NULL
    // 0x8d0adc: LeaveFrame
    //     0x8d0adc: mov             SP, fp
    //     0x8d0ae0: ldp             fp, lr, [SP], #0x10
    // 0x8d0ae4: ret
    //     0x8d0ae4: ret             
    // 0x8d0ae8: r9 = _dynamicLengthTree
    //     0x8d0ae8: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ae8] Field <Deflate._dynamicLengthTree@60040000>: late (offset: 0x98)
    //     0x8d0aec: ldr             x9, [x9, #0xae8]
    // 0x8d0af0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d0af0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d0af4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d0af4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d0af8: b               #0x8d09a4
    // 0x8d0afc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d0afc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d0b00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d0b00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d0b04: b               #0x8d09f0
    // 0x8d0b08: r9 = _dynamicLengthTree
    //     0x8d0b08: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ae8] Field <Deflate._dynamicLengthTree@60040000>: late (offset: 0x98)
    //     0x8d0b0c: ldr             x9, [x9, #0xae8]
    // 0x8d0b10: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d0b10: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d0b14: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d0b14: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d0b18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d0b18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d0b1c: b               #0x8d0a50
    // 0x8d0b20: r9 = _dynamicLengthTree
    //     0x8d0b20: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ae8] Field <Deflate._dynamicLengthTree@60040000>: late (offset: 0x98)
    //     0x8d0b24: ldr             x9, [x9, #0xae8]
    // 0x8d0b28: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d0b28: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d0b2c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d0b2c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _trTally(/* No info */) {
    // ** addr: 0x8d0b30, size: 0x5f0
    // 0x8d0b30: EnterFrame
    //     0x8d0b30: stp             fp, lr, [SP, #-0x10]!
    //     0x8d0b34: mov             fp, SP
    // 0x8d0b38: AllocStack(0x8)
    //     0x8d0b38: sub             SP, SP, #8
    // 0x8d0b3c: CheckStackOverflow
    //     0x8d0b3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d0b40: cmp             SP, x16
    //     0x8d0b44: b.ls            #0x8d103c
    // 0x8d0b48: ldr             x2, [fp, #0x20]
    // 0x8d0b4c: LoadField: r3 = r2->field_23
    //     0x8d0b4c: ldur            w3, [x2, #0x23]
    // 0x8d0b50: DecompressPointer r3
    //     0x8d0b50: add             x3, x3, HEAP, lsl #32
    // 0x8d0b54: r16 = Sentinel
    //     0x8d0b54: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d0b58: cmp             w3, w16
    // 0x8d0b5c: b.eq            #0x8d1044
    // 0x8d0b60: LoadField: r0 = r2->field_cf
    //     0x8d0b60: ldur            w0, [x2, #0xcf]
    // 0x8d0b64: DecompressPointer r0
    //     0x8d0b64: add             x0, x0, HEAP, lsl #32
    // 0x8d0b68: r16 = Sentinel
    //     0x8d0b68: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d0b6c: cmp             w0, w16
    // 0x8d0b70: b.eq            #0x8d1050
    // 0x8d0b74: LoadField: r1 = r2->field_cb
    //     0x8d0b74: ldur            w1, [x2, #0xcb]
    // 0x8d0b78: DecompressPointer r1
    //     0x8d0b78: add             x1, x1, HEAP, lsl #32
    // 0x8d0b7c: r16 = Sentinel
    //     0x8d0b7c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d0b80: cmp             w1, w16
    // 0x8d0b84: b.eq            #0x8d105c
    // 0x8d0b88: r4 = LoadInt32Instr(r1)
    //     0x8d0b88: sbfx            x4, x1, #1, #0x1f
    //     0x8d0b8c: tbz             w1, #0, #0x8d0b94
    //     0x8d0b90: ldur            x4, [x1, #7]
    // 0x8d0b94: lsl             x1, x4, #1
    // 0x8d0b98: r5 = LoadInt32Instr(r0)
    //     0x8d0b98: sbfx            x5, x0, #1, #0x1f
    //     0x8d0b9c: tbz             w0, #0, #0x8d0ba4
    //     0x8d0ba0: ldur            x5, [x0, #7]
    // 0x8d0ba4: add             x6, x5, x1
    // 0x8d0ba8: ldr             x0, [fp, #0x18]
    // 0x8d0bac: r5 = LoadInt32Instr(r0)
    //     0x8d0bac: sbfx            x5, x0, #1, #0x1f
    //     0x8d0bb0: tbz             w0, #0, #0x8d0bb8
    //     0x8d0bb4: ldur            x5, [x0, #7]
    // 0x8d0bb8: tbnz            x5, #0x3f, #0x8d0bc8
    // 0x8d0bbc: asr             x0, x5, #8
    // 0x8d0bc0: mov             x8, x0
    // 0x8d0bc4: b               #0x8d0bd0
    // 0x8d0bc8: asr             x0, x5, #8
    // 0x8d0bcc: mov             x8, x0
    // 0x8d0bd0: ldr             x7, [fp, #0x10]
    // 0x8d0bd4: LoadField: r0 = r3->field_13
    //     0x8d0bd4: ldur            w0, [x3, #0x13]
    // 0x8d0bd8: DecompressPointer r0
    //     0x8d0bd8: add             x0, x0, HEAP, lsl #32
    // 0x8d0bdc: r10 = LoadInt32Instr(r0)
    //     0x8d0bdc: sbfx            x10, x0, #1, #0x1f
    // 0x8d0be0: mov             x0, x10
    // 0x8d0be4: mov             x1, x6
    // 0x8d0be8: cmp             x1, x0
    // 0x8d0bec: b.hs            #0x8d1068
    // 0x8d0bf0: LoadField: r0 = r3->field_7
    //     0x8d0bf0: ldur            x0, [x3, #7]
    // 0x8d0bf4: strb            w8, [x0, x6]
    // 0x8d0bf8: add             x8, x6, #1
    // 0x8d0bfc: mov             x0, x10
    // 0x8d0c00: mov             x1, x8
    // 0x8d0c04: cmp             x1, x0
    // 0x8d0c08: b.hs            #0x8d106c
    // 0x8d0c0c: LoadField: r0 = r3->field_7
    //     0x8d0c0c: ldur            x0, [x3, #7]
    // 0x8d0c10: strb            w5, [x0, x8]
    // 0x8d0c14: LoadField: r0 = r2->field_c3
    //     0x8d0c14: ldur            w0, [x2, #0xc3]
    // 0x8d0c18: DecompressPointer r0
    //     0x8d0c18: add             x0, x0, HEAP, lsl #32
    // 0x8d0c1c: r16 = Sentinel
    //     0x8d0c1c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d0c20: cmp             w0, w16
    // 0x8d0c24: b.eq            #0x8d1070
    // 0x8d0c28: r1 = LoadInt32Instr(r0)
    //     0x8d0c28: sbfx            x1, x0, #1, #0x1f
    //     0x8d0c2c: tbz             w0, #0, #0x8d0c34
    //     0x8d0c30: ldur            x1, [x0, #7]
    // 0x8d0c34: add             x6, x1, x4
    // 0x8d0c38: mov             x0, x10
    // 0x8d0c3c: mov             x1, x6
    // 0x8d0c40: cmp             x1, x0
    // 0x8d0c44: b.hs            #0x8d107c
    // 0x8d0c48: LoadField: r0 = r3->field_7
    //     0x8d0c48: ldur            x0, [x3, #7]
    // 0x8d0c4c: strb            w7, [x0, x6]
    // 0x8d0c50: add             x3, x4, #1
    // 0x8d0c54: r0 = BoxInt64Instr(r3)
    //     0x8d0c54: sbfiz           x0, x3, #1, #0x1f
    //     0x8d0c58: cmp             x3, x0, asr #1
    //     0x8d0c5c: b.eq            #0x8d0c68
    //     0x8d0c60: bl              #0xd69bb8
    //     0x8d0c64: stur            x3, [x0, #7]
    // 0x8d0c68: StoreField: r2->field_cb = r0
    //     0x8d0c68: stur            w0, [x2, #0xcb]
    //     0x8d0c6c: tbz             w0, #0, #0x8d0c88
    //     0x8d0c70: ldurb           w16, [x2, #-1]
    //     0x8d0c74: ldurb           w17, [x0, #-1]
    //     0x8d0c78: and             x16, x17, x16, lsr #2
    //     0x8d0c7c: tst             x16, HEAP, lsr #32
    //     0x8d0c80: b.eq            #0x8d0c88
    //     0x8d0c84: bl              #0xd6828c
    // 0x8d0c88: cbnz            x5, #0x8d0cdc
    // 0x8d0c8c: LoadField: r3 = r2->field_97
    //     0x8d0c8c: ldur            w3, [x2, #0x97]
    // 0x8d0c90: DecompressPointer r3
    //     0x8d0c90: add             x3, x3, HEAP, lsl #32
    // 0x8d0c94: r16 = Sentinel
    //     0x8d0c94: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d0c98: cmp             w3, w16
    // 0x8d0c9c: b.eq            #0x8d1080
    // 0x8d0ca0: lsl             x4, x7, #1
    // 0x8d0ca4: LoadField: r0 = r3->field_13
    //     0x8d0ca4: ldur            w0, [x3, #0x13]
    // 0x8d0ca8: DecompressPointer r0
    //     0x8d0ca8: add             x0, x0, HEAP, lsl #32
    // 0x8d0cac: r1 = LoadInt32Instr(r0)
    //     0x8d0cac: sbfx            x1, x0, #1, #0x1f
    // 0x8d0cb0: mov             x0, x1
    // 0x8d0cb4: mov             x1, x4
    // 0x8d0cb8: cmp             x1, x0
    // 0x8d0cbc: b.hs            #0x8d108c
    // 0x8d0cc0: add             x16, x3, x4, lsl #1
    // 0x8d0cc4: ldurh           w0, [x16, #0x17]
    // 0x8d0cc8: add             x1, x0, #1
    // 0x8d0ccc: LoadField: r0 = r3->field_7
    //     0x8d0ccc: ldur            x0, [x3, #7]
    // 0x8d0cd0: add             x3, x0, x4, lsl #1
    // 0x8d0cd4: strh            w1, [x3]
    // 0x8d0cd8: b               #0x8d0e1c
    // 0x8d0cdc: r3 = const [0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x8, 0x9, 0x9, 0xa, 0xa, 0xb, 0xb, 0xc, 0xc, 0xc, 0xc, 0xd, 0xd, 0xd, 0xd, 0xe, 0xe, 0xe, 0xe, 0xf, 0xf, 0xf, 0xf, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x12, 0x12, 0x12, 0x12, 0x12, 0x12, 0x12, 0x12, 0x13, 0x13, 0x13, 0x13, 0x13, 0x13, 0x13, 0x13, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1c]
    //     0x8d0cdc: add             x3, PP, #0x34, lsl #12  ; [pp+0x34b08] List<int>(256)
    //     0x8d0ce0: ldr             x3, [x3, #0xb08]
    // 0x8d0ce4: LoadField: r0 = r2->field_db
    //     0x8d0ce4: ldur            w0, [x2, #0xdb]
    // 0x8d0ce8: DecompressPointer r0
    //     0x8d0ce8: add             x0, x0, HEAP, lsl #32
    // 0x8d0cec: r16 = Sentinel
    //     0x8d0cec: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d0cf0: cmp             w0, w16
    // 0x8d0cf4: b.eq            #0x8d1090
    // 0x8d0cf8: r1 = LoadInt32Instr(r0)
    //     0x8d0cf8: sbfx            x1, x0, #1, #0x1f
    //     0x8d0cfc: tbz             w0, #0, #0x8d0d04
    //     0x8d0d00: ldur            x1, [x0, #7]
    // 0x8d0d04: add             x4, x1, #1
    // 0x8d0d08: r0 = BoxInt64Instr(r4)
    //     0x8d0d08: sbfiz           x0, x4, #1, #0x1f
    //     0x8d0d0c: cmp             x4, x0, asr #1
    //     0x8d0d10: b.eq            #0x8d0d1c
    //     0x8d0d14: bl              #0xd69bb8
    //     0x8d0d18: stur            x4, [x0, #7]
    // 0x8d0d1c: StoreField: r2->field_db = r0
    //     0x8d0d1c: stur            w0, [x2, #0xdb]
    //     0x8d0d20: tbz             w0, #0, #0x8d0d3c
    //     0x8d0d24: ldurb           w16, [x2, #-1]
    //     0x8d0d28: ldurb           w17, [x0, #-1]
    //     0x8d0d2c: and             x16, x17, x16, lsr #2
    //     0x8d0d30: tst             x16, HEAP, lsr #32
    //     0x8d0d34: b.eq            #0x8d0d3c
    //     0x8d0d38: bl              #0xd6828c
    // 0x8d0d3c: sub             x4, x5, #1
    // 0x8d0d40: LoadField: r5 = r2->field_97
    //     0x8d0d40: ldur            w5, [x2, #0x97]
    // 0x8d0d44: DecompressPointer r5
    //     0x8d0d44: add             x5, x5, HEAP, lsl #32
    // 0x8d0d48: r16 = Sentinel
    //     0x8d0d48: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d0d4c: cmp             w5, w16
    // 0x8d0d50: b.eq            #0x8d109c
    // 0x8d0d54: mov             x1, x7
    // 0x8d0d58: r0 = 256
    //     0x8d0d58: mov             x0, #0x100
    // 0x8d0d5c: cmp             x1, x0
    // 0x8d0d60: b.hs            #0x8d10a8
    // 0x8d0d64: ArrayLoad: r0 = r3[r7]  ; Unknown_4
    //     0x8d0d64: add             x16, x3, x7, lsl #2
    //     0x8d0d68: ldur            w0, [x16, #0xf]
    // 0x8d0d6c: DecompressPointer r0
    //     0x8d0d6c: add             x0, x0, HEAP, lsl #32
    // 0x8d0d70: r1 = LoadInt32Instr(r0)
    //     0x8d0d70: sbfx            x1, x0, #1, #0x1f
    //     0x8d0d74: tbz             w0, #0, #0x8d0d7c
    //     0x8d0d78: ldur            x1, [x0, #7]
    // 0x8d0d7c: add             x0, x1, #0x100
    // 0x8d0d80: add             x1, x0, #1
    // 0x8d0d84: lsl             x3, x1, #1
    // 0x8d0d88: LoadField: r0 = r5->field_13
    //     0x8d0d88: ldur            w0, [x5, #0x13]
    // 0x8d0d8c: DecompressPointer r0
    //     0x8d0d8c: add             x0, x0, HEAP, lsl #32
    // 0x8d0d90: r1 = LoadInt32Instr(r0)
    //     0x8d0d90: sbfx            x1, x0, #1, #0x1f
    // 0x8d0d94: mov             x0, x1
    // 0x8d0d98: mov             x1, x3
    // 0x8d0d9c: cmp             x1, x0
    // 0x8d0da0: b.hs            #0x8d10ac
    // 0x8d0da4: add             x16, x5, x3, lsl #1
    // 0x8d0da8: ldurh           w0, [x16, #0x17]
    // 0x8d0dac: add             x1, x0, #1
    // 0x8d0db0: LoadField: r0 = r5->field_7
    //     0x8d0db0: ldur            x0, [x5, #7]
    // 0x8d0db4: add             x5, x0, x3, lsl #1
    // 0x8d0db8: strh            w1, [x5]
    // 0x8d0dbc: LoadField: r0 = r2->field_9b
    //     0x8d0dbc: ldur            w0, [x2, #0x9b]
    // 0x8d0dc0: DecompressPointer r0
    //     0x8d0dc0: add             x0, x0, HEAP, lsl #32
    // 0x8d0dc4: r16 = Sentinel
    //     0x8d0dc4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d0dc8: cmp             w0, w16
    // 0x8d0dcc: b.eq            #0x8d10b0
    // 0x8d0dd0: stur            x0, [fp, #-8]
    // 0x8d0dd4: SaveReg r4
    //     0x8d0dd4: str             x4, [SP, #-8]!
    // 0x8d0dd8: r0 = _dCode()
    //     0x8d0dd8: bl              #0x8ced3c  ; [package:archive/src/zlib/deflate.dart] _HuffmanTree::_dCode
    // 0x8d0ddc: add             SP, SP, #8
    // 0x8d0de0: lsl             x2, x0, #1
    // 0x8d0de4: ldur            x3, [fp, #-8]
    // 0x8d0de8: LoadField: r4 = r3->field_13
    //     0x8d0de8: ldur            w4, [x3, #0x13]
    // 0x8d0dec: DecompressPointer r4
    //     0x8d0dec: add             x4, x4, HEAP, lsl #32
    // 0x8d0df0: r0 = LoadInt32Instr(r4)
    //     0x8d0df0: sbfx            x0, x4, #1, #0x1f
    // 0x8d0df4: mov             x1, x2
    // 0x8d0df8: cmp             x1, x0
    // 0x8d0dfc: b.hs            #0x8d10bc
    // 0x8d0e00: add             x16, x3, x2, lsl #1
    // 0x8d0e04: ldurh           w4, [x16, #0x17]
    // 0x8d0e08: add             x5, x4, #1
    // 0x8d0e0c: LoadField: r4 = r3->field_7
    //     0x8d0e0c: ldur            x4, [x3, #7]
    // 0x8d0e10: add             x3, x4, x2, lsl #1
    // 0x8d0e14: strh            w5, [x3]
    // 0x8d0e18: ldr             x2, [fp, #0x20]
    // 0x8d0e1c: r3 = 8191
    //     0x8d0e1c: mov             x3, #0x1fff
    // 0x8d0e20: LoadField: r4 = r2->field_cb
    //     0x8d0e20: ldur            w4, [x2, #0xcb]
    // 0x8d0e24: DecompressPointer r4
    //     0x8d0e24: add             x4, x4, HEAP, lsl #32
    // 0x8d0e28: r5 = LoadInt32Instr(r4)
    //     0x8d0e28: sbfx            x5, x4, #1, #0x1f
    //     0x8d0e2c: tbz             w4, #0, #0x8d0e34
    //     0x8d0e30: ldur            x5, [x4, #7]
    // 0x8d0e34: mov             x6, x5
    // 0x8d0e38: ubfx            x6, x6, #0, #0x20
    // 0x8d0e3c: and             x7, x6, x3
    // 0x8d0e40: ubfx            x7, x7, #0, #0x20
    // 0x8d0e44: cbnz            x7, #0x8d0ff0
    // 0x8d0e48: LoadField: r3 = r2->field_8f
    //     0x8d0e48: ldur            w3, [x2, #0x8f]
    // 0x8d0e4c: DecompressPointer r3
    //     0x8d0e4c: add             x3, x3, HEAP, lsl #32
    // 0x8d0e50: r16 = Sentinel
    //     0x8d0e50: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d0e54: cmp             w3, w16
    // 0x8d0e58: b.eq            #0x8d10c0
    // 0x8d0e5c: r6 = LoadInt32Instr(r3)
    //     0x8d0e5c: sbfx            x6, x3, #1, #0x1f
    //     0x8d0e60: tbz             w3, #0, #0x8d0e68
    //     0x8d0e64: ldur            x6, [x3, #7]
    // 0x8d0e68: cmp             x6, #2
    // 0x8d0e6c: b.le            #0x8d0ff0
    // 0x8d0e70: lsl             x3, x5, #3
    // 0x8d0e74: LoadField: r5 = r2->field_7b
    //     0x8d0e74: ldur            w5, [x2, #0x7b]
    // 0x8d0e78: DecompressPointer r5
    //     0x8d0e78: add             x5, x5, HEAP, lsl #32
    // 0x8d0e7c: r16 = Sentinel
    //     0x8d0e7c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d0e80: cmp             w5, w16
    // 0x8d0e84: b.eq            #0x8d10cc
    // 0x8d0e88: LoadField: r6 = r2->field_6b
    //     0x8d0e88: ldur            w6, [x2, #0x6b]
    // 0x8d0e8c: DecompressPointer r6
    //     0x8d0e8c: add             x6, x6, HEAP, lsl #32
    // 0x8d0e90: r16 = Sentinel
    //     0x8d0e90: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d0e94: cmp             w6, w16
    // 0x8d0e98: b.eq            #0x8d10d8
    // 0x8d0e9c: r7 = LoadInt32Instr(r5)
    //     0x8d0e9c: sbfx            x7, x5, #1, #0x1f
    //     0x8d0ea0: tbz             w5, #0, #0x8d0ea8
    //     0x8d0ea4: ldur            x7, [x5, #7]
    // 0x8d0ea8: r5 = LoadInt32Instr(r6)
    //     0x8d0ea8: sbfx            x5, x6, #1, #0x1f
    //     0x8d0eac: tbz             w6, #0, #0x8d0eb4
    //     0x8d0eb0: ldur            x5, [x6, #7]
    // 0x8d0eb4: sub             x6, x7, x5
    // 0x8d0eb8: LoadField: r5 = r2->field_9b
    //     0x8d0eb8: ldur            w5, [x2, #0x9b]
    // 0x8d0ebc: DecompressPointer r5
    //     0x8d0ebc: add             x5, x5, HEAP, lsl #32
    // 0x8d0ec0: r16 = Sentinel
    //     0x8d0ec0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d0ec4: cmp             w5, w16
    // 0x8d0ec8: b.eq            #0x8d10e4
    // 0x8d0ecc: LoadField: r7 = r5->field_13
    //     0x8d0ecc: ldur            w7, [x5, #0x13]
    // 0x8d0ed0: DecompressPointer r7
    //     0x8d0ed0: add             x7, x7, HEAP, lsl #32
    // 0x8d0ed4: r4 = LoadInt32Instr(r7)
    //     0x8d0ed4: sbfx            x4, x7, #1, #0x1f
    // 0x8d0ed8: mov             x8, x3
    // 0x8d0edc: r7 = 0
    //     0x8d0edc: mov             x7, #0
    // 0x8d0ee0: r3 = const [0, 0, 0, 0, 0x1, 0x1, 0x2, 0x2, 0x3, 0x3, 0x4, 0x4, 0x5, 0x5, 0x6, 0x6, 0x7, 0x7, 0x8, 0x8, 0x9, 0x9, 0xa, 0xa, 0xb, 0xb, 0xc, 0xc, 0xd, 0xd]
    //     0x8d0ee0: add             x3, PP, #0x34, lsl #12  ; [pp+0x34b28] List<int>(30)
    //     0x8d0ee4: ldr             x3, [x3, #0xb28]
    // 0x8d0ee8: CheckStackOverflow
    //     0x8d0ee8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d0eec: cmp             SP, x16
    //     0x8d0ef0: b.ls            #0x8d10f0
    // 0x8d0ef4: cmp             x7, #0x1e
    // 0x8d0ef8: b.ge            #0x8d0f4c
    // 0x8d0efc: lsl             x9, x7, #1
    // 0x8d0f00: mov             x0, x4
    // 0x8d0f04: mov             x1, x9
    // 0x8d0f08: cmp             x1, x0
    // 0x8d0f0c: b.hs            #0x8d10f8
    // 0x8d0f10: add             x16, x5, x9, lsl #1
    // 0x8d0f14: ldurh           w1, [x16, #0x17]
    // 0x8d0f18: ArrayLoad: r10 = r3[r7]  ; Unknown_4
    //     0x8d0f18: add             x16, x3, x7, lsl #2
    //     0x8d0f1c: ldur            w10, [x16, #0xf]
    // 0x8d0f20: DecompressPointer r10
    //     0x8d0f20: add             x10, x10, HEAP, lsl #32
    // 0x8d0f24: r11 = LoadInt32Instr(r10)
    //     0x8d0f24: sbfx            x11, x10, #1, #0x1f
    //     0x8d0f28: tbz             w10, #0, #0x8d0f30
    //     0x8d0f2c: ldur            x11, [x10, #7]
    // 0x8d0f30: add             x10, x11, #5
    // 0x8d0f34: mul             x11, x1, x10
    // 0x8d0f38: add             x0, x8, x11
    // 0x8d0f3c: add             x1, x7, #1
    // 0x8d0f40: mov             x8, x0
    // 0x8d0f44: mov             x7, x1
    // 0x8d0f48: b               #0x8d0ee8
    // 0x8d0f4c: tbnz            x8, #0x3f, #0x8d0f58
    // 0x8d0f50: asr             x1, x8, #3
    // 0x8d0f54: b               #0x8d0f5c
    // 0x8d0f58: asr             x1, x8, #3
    // 0x8d0f5c: d0 = 2.000000
    //     0x8d0f5c: fmov            d0, #2.00000000
    // 0x8d0f60: LoadField: r3 = r2->field_db
    //     0x8d0f60: ldur            w3, [x2, #0xdb]
    // 0x8d0f64: DecompressPointer r3
    //     0x8d0f64: add             x3, x3, HEAP, lsl #32
    // 0x8d0f68: r16 = Sentinel
    //     0x8d0f68: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d0f6c: cmp             w3, w16
    // 0x8d0f70: b.eq            #0x8d10fc
    // 0x8d0f74: LoadField: r5 = r2->field_cb
    //     0x8d0f74: ldur            w5, [x2, #0xcb]
    // 0x8d0f78: DecompressPointer r5
    //     0x8d0f78: add             x5, x5, HEAP, lsl #32
    // 0x8d0f7c: r16 = Sentinel
    //     0x8d0f7c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d0f80: cmp             w5, w16
    // 0x8d0f84: b.eq            #0x8d1108
    // 0x8d0f88: r7 = LoadInt32Instr(r5)
    //     0x8d0f88: sbfx            x7, x5, #1, #0x1f
    //     0x8d0f8c: tbz             w5, #0, #0x8d0f94
    //     0x8d0f90: ldur            x7, [x5, #7]
    // 0x8d0f94: scvtf           d1, x7
    // 0x8d0f98: fdiv            d2, d1, d0
    // 0x8d0f9c: r7 = LoadInt32Instr(r3)
    //     0x8d0f9c: sbfx            x7, x3, #1, #0x1f
    //     0x8d0fa0: tbz             w3, #0, #0x8d0fa8
    //     0x8d0fa4: ldur            x7, [x3, #7]
    // 0x8d0fa8: scvtf           d1, x7
    // 0x8d0fac: fcmp            d1, d2
    // 0x8d0fb0: b.vs            #0x8d0fe0
    // 0x8d0fb4: b.ge            #0x8d0fe0
    // 0x8d0fb8: scvtf           d1, x6
    // 0x8d0fbc: fdiv            d2, d1, d0
    // 0x8d0fc0: scvtf           d0, x1
    // 0x8d0fc4: fcmp            d0, d2
    // 0x8d0fc8: b.vs            #0x8d0fe0
    // 0x8d0fcc: b.ge            #0x8d0fe0
    // 0x8d0fd0: r0 = true
    //     0x8d0fd0: add             x0, NULL, #0x20  ; true
    // 0x8d0fd4: LeaveFrame
    //     0x8d0fd4: mov             SP, fp
    //     0x8d0fd8: ldp             fp, lr, [SP], #0x10
    // 0x8d0fdc: ret
    //     0x8d0fdc: ret             
    // 0x8d0fe0: r1 = LoadInt32Instr(r5)
    //     0x8d0fe0: sbfx            x1, x5, #1, #0x1f
    //     0x8d0fe4: tbz             w5, #0, #0x8d0fec
    //     0x8d0fe8: ldur            x1, [x5, #7]
    // 0x8d0fec: b               #0x8d0ffc
    // 0x8d0ff0: r1 = LoadInt32Instr(r4)
    //     0x8d0ff0: sbfx            x1, x4, #1, #0x1f
    //     0x8d0ff4: tbz             w4, #0, #0x8d0ffc
    //     0x8d0ff8: ldur            x1, [x4, #7]
    // 0x8d0ffc: LoadField: r3 = r2->field_c7
    //     0x8d0ffc: ldur            w3, [x2, #0xc7]
    // 0x8d1000: DecompressPointer r3
    //     0x8d1000: add             x3, x3, HEAP, lsl #32
    // 0x8d1004: r16 = Sentinel
    //     0x8d1004: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1008: cmp             w3, w16
    // 0x8d100c: b.eq            #0x8d1114
    // 0x8d1010: r2 = LoadInt32Instr(r3)
    //     0x8d1010: sbfx            x2, x3, #1, #0x1f
    //     0x8d1014: tbz             w3, #0, #0x8d101c
    //     0x8d1018: ldur            x2, [x3, #7]
    // 0x8d101c: sub             x3, x2, #1
    // 0x8d1020: cmp             x1, x3
    // 0x8d1024: r16 = true
    //     0x8d1024: add             x16, NULL, #0x20  ; true
    // 0x8d1028: r17 = false
    //     0x8d1028: add             x17, NULL, #0x30  ; false
    // 0x8d102c: csel            x0, x16, x17, eq
    // 0x8d1030: LeaveFrame
    //     0x8d1030: mov             SP, fp
    //     0x8d1034: ldp             fp, lr, [SP], #0x10
    // 0x8d1038: ret
    //     0x8d1038: ret             
    // 0x8d103c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d103c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d1040: b               #0x8d0b48
    // 0x8d1044: r9 = _pendingBuffer
    //     0x8d1044: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a10] Field <Deflate._pendingBuffer@60040000>: late (offset: 0x24)
    //     0x8d1048: ldr             x9, [x9, #0xa10]
    // 0x8d104c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d104c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d1050: r9 = _dbuf
    //     0x8d1050: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b40] Field <Deflate._dbuf@60040000>: late (offset: 0xd0)
    //     0x8d1054: ldr             x9, [x9, #0xb40]
    // 0x8d1058: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d1058: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d105c: r9 = _lastLit
    //     0x8d105c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b38] Field <Deflate._lastLit@60040000>: late (offset: 0xcc)
    //     0x8d1060: ldr             x9, [x9, #0xb38]
    // 0x8d1064: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d1064: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d1068: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d1068: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d106c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d106c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d1070: r9 = _lbuf
    //     0x8d1070: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b48] Field <Deflate._lbuf@60040000>: late (offset: 0xc4)
    //     0x8d1074: ldr             x9, [x9, #0xb48]
    // 0x8d1078: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d1078: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d107c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d107c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d1080: r9 = _dynamicLengthTree
    //     0x8d1080: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ae8] Field <Deflate._dynamicLengthTree@60040000>: late (offset: 0x98)
    //     0x8d1084: ldr             x9, [x9, #0xae8]
    // 0x8d1088: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d1088: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d108c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d108c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d1090: r9 = _matches
    //     0x8d1090: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b70] Field <Deflate._matches@60040000>: late (offset: 0xdc)
    //     0x8d1094: ldr             x9, [x9, #0xb70]
    // 0x8d1098: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d1098: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d109c: r9 = _dynamicLengthTree
    //     0x8d109c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ae8] Field <Deflate._dynamicLengthTree@60040000>: late (offset: 0x98)
    //     0x8d10a0: ldr             x9, [x9, #0xae8]
    // 0x8d10a4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d10a4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d10a8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d10a8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d10ac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d10ac: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d10b0: r9 = _dynamicDistTree
    //     0x8d10b0: add             x9, PP, #0x34, lsl #12  ; [pp+0x34af0] Field <Deflate._dynamicDistTree@60040000>: late (offset: 0x9c)
    //     0x8d10b4: ldr             x9, [x9, #0xaf0]
    // 0x8d10b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d10b8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d10bc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d10bc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d10c0: r9 = _level
    //     0x8d10c0: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ac8] Field <Deflate._level@60040000>: late (offset: 0x90)
    //     0x8d10c4: ldr             x9, [x9, #0xac8]
    // 0x8d10c8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d10c8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d10cc: r9 = _strStart
    //     0x8d10cc: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a58] Field <Deflate._strStart@60040000>: late (offset: 0x7c)
    //     0x8d10d0: ldr             x9, [x9, #0xa58]
    // 0x8d10d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d10d4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d10d8: r9 = _blockStart
    //     0x8d10d8: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ab0] Field <Deflate._blockStart@60040000>: late (offset: 0x6c)
    //     0x8d10dc: ldr             x9, [x9, #0xab0]
    // 0x8d10e0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d10e0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d10e4: r9 = _dynamicDistTree
    //     0x8d10e4: add             x9, PP, #0x34, lsl #12  ; [pp+0x34af0] Field <Deflate._dynamicDistTree@60040000>: late (offset: 0x9c)
    //     0x8d10e8: ldr             x9, [x9, #0xaf0]
    // 0x8d10ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d10ec: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d10f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d10f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d10f4: b               #0x8d0ef4
    // 0x8d10f8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d10f8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d10fc: r9 = _matches
    //     0x8d10fc: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b70] Field <Deflate._matches@60040000>: late (offset: 0xdc)
    //     0x8d1100: ldr             x9, [x9, #0xb70]
    // 0x8d1104: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x8d1104: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x8d1108: r9 = _lastLit
    //     0x8d1108: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b38] Field <Deflate._lastLit@60040000>: late (offset: 0xcc)
    //     0x8d110c: ldr             x9, [x9, #0xb38]
    // 0x8d1110: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x8d1110: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x8d1114: r9 = _litBufferSize
    //     0x8d1114: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b78] Field <Deflate._litBufferSize@60040000>: late (offset: 0xc8)
    //     0x8d1118: ldr             x9, [x9, #0xb78]
    // 0x8d111c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d111c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _fillWindow(/* No info */) {
    // ** addr: 0x8d1120, size: 0x72c
    // 0x8d1120: EnterFrame
    //     0x8d1120: stp             fp, lr, [SP, #-0x10]!
    //     0x8d1124: mov             fp, SP
    // 0x8d1128: AllocStack(0x8)
    //     0x8d1128: sub             SP, SP, #8
    // 0x8d112c: CheckStackOverflow
    //     0x8d112c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d1130: cmp             SP, x16
    //     0x8d1134: b.ls            #0x8d171c
    // 0x8d1138: ldr             x0, [fp, #0x10]
    // 0x8d113c: CheckStackOverflow
    //     0x8d113c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d1140: cmp             SP, x16
    //     0x8d1144: b.ls            #0x8d1724
    // 0x8d1148: LoadField: r1 = r0->field_4b
    //     0x8d1148: ldur            w1, [x0, #0x4b]
    // 0x8d114c: DecompressPointer r1
    //     0x8d114c: add             x1, x1, HEAP, lsl #32
    // 0x8d1150: r16 = Sentinel
    //     0x8d1150: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1154: cmp             w1, w16
    // 0x8d1158: b.eq            #0x8d172c
    // 0x8d115c: LoadField: r2 = r0->field_87
    //     0x8d115c: ldur            w2, [x0, #0x87]
    // 0x8d1160: DecompressPointer r2
    //     0x8d1160: add             x2, x2, HEAP, lsl #32
    // 0x8d1164: r16 = Sentinel
    //     0x8d1164: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1168: cmp             w2, w16
    // 0x8d116c: b.eq            #0x8d1738
    // 0x8d1170: r3 = LoadInt32Instr(r1)
    //     0x8d1170: sbfx            x3, x1, #1, #0x1f
    //     0x8d1174: tbz             w1, #0, #0x8d117c
    //     0x8d1178: ldur            x3, [x1, #7]
    // 0x8d117c: r1 = LoadInt32Instr(r2)
    //     0x8d117c: sbfx            x1, x2, #1, #0x1f
    //     0x8d1180: tbz             w2, #0, #0x8d1188
    //     0x8d1184: ldur            x1, [x2, #7]
    // 0x8d1188: sub             x2, x3, x1
    // 0x8d118c: LoadField: r3 = r0->field_7b
    //     0x8d118c: ldur            w3, [x0, #0x7b]
    // 0x8d1190: DecompressPointer r3
    //     0x8d1190: add             x3, x3, HEAP, lsl #32
    // 0x8d1194: r16 = Sentinel
    //     0x8d1194: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1198: cmp             w3, w16
    // 0x8d119c: b.eq            #0x8d1744
    // 0x8d11a0: r4 = LoadInt32Instr(r3)
    //     0x8d11a0: sbfx            x4, x3, #1, #0x1f
    //     0x8d11a4: tbz             w3, #0, #0x8d11ac
    //     0x8d11a8: ldur            x4, [x3, #7]
    // 0x8d11ac: sub             x3, x2, x4
    // 0x8d11b0: stur            x3, [fp, #-8]
    // 0x8d11b4: cbnz            x3, #0x8d11f0
    // 0x8d11b8: cbnz            x4, #0x8d11f0
    // 0x8d11bc: cbnz            x1, #0x8d11f0
    // 0x8d11c0: LoadField: r1 = r0->field_3b
    //     0x8d11c0: ldur            w1, [x0, #0x3b]
    // 0x8d11c4: DecompressPointer r1
    //     0x8d11c4: add             x1, x1, HEAP, lsl #32
    // 0x8d11c8: r16 = Sentinel
    //     0x8d11c8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d11cc: cmp             w1, w16
    // 0x8d11d0: b.eq            #0x8d1750
    // 0x8d11d4: r2 = LoadInt32Instr(r1)
    //     0x8d11d4: sbfx            x2, x1, #1, #0x1f
    //     0x8d11d8: tbz             w1, #0, #0x8d11e0
    //     0x8d11dc: ldur            x2, [x1, #7]
    // 0x8d11e0: mov             x3, x2
    // 0x8d11e4: mov             x2, x0
    // 0x8d11e8: r6 = 65535
    //     0x8d11e8: mov             x6, #0xffff
    // 0x8d11ec: b               #0x8d1490
    // 0x8d11f0: LoadField: r1 = r0->field_3b
    //     0x8d11f0: ldur            w1, [x0, #0x3b]
    // 0x8d11f4: DecompressPointer r1
    //     0x8d11f4: add             x1, x1, HEAP, lsl #32
    // 0x8d11f8: r16 = Sentinel
    //     0x8d11f8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d11fc: cmp             w1, w16
    // 0x8d1200: b.eq            #0x8d175c
    // 0x8d1204: r2 = LoadInt32Instr(r1)
    //     0x8d1204: sbfx            x2, x1, #1, #0x1f
    //     0x8d1208: tbz             w1, #0, #0x8d1210
    //     0x8d120c: ldur            x2, [x1, #7]
    // 0x8d1210: add             x5, x2, x2
    // 0x8d1214: sub             x6, x5, #0x106
    // 0x8d1218: cmp             x4, x6
    // 0x8d121c: b.lt            #0x8d1480
    // 0x8d1220: LoadField: r4 = r0->field_47
    //     0x8d1220: ldur            w4, [x0, #0x47]
    // 0x8d1224: DecompressPointer r4
    //     0x8d1224: add             x4, x4, HEAP, lsl #32
    // 0x8d1228: r16 = Sentinel
    //     0x8d1228: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d122c: cmp             w4, w16
    // 0x8d1230: b.eq            #0x8d1768
    // 0x8d1234: stp             xzr, x4, [SP, #-0x10]!
    // 0x8d1238: stp             x4, x2, [SP, #-0x10]!
    // 0x8d123c: SaveReg r1
    //     0x8d123c: str             x1, [SP, #-8]!
    // 0x8d1240: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0x8d1240: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0x8d1244: r0 = setRange()
    //     0x8d1244: bl              #0x605c8c  ; [dart:typed_data] __Uint8List&_TypedList&_IntListMixin&_TypedIntListMixin::setRange
    // 0x8d1248: add             SP, SP, #0x28
    // 0x8d124c: ldr             x2, [fp, #0x10]
    // 0x8d1250: LoadField: r0 = r2->field_7f
    //     0x8d1250: ldur            x0, [x2, #0x7f]
    // 0x8d1254: LoadField: r1 = r2->field_3b
    //     0x8d1254: ldur            w1, [x2, #0x3b]
    // 0x8d1258: DecompressPointer r1
    //     0x8d1258: add             x1, x1, HEAP, lsl #32
    // 0x8d125c: r3 = LoadInt32Instr(r1)
    //     0x8d125c: sbfx            x3, x1, #1, #0x1f
    //     0x8d1260: tbz             w1, #0, #0x8d1268
    //     0x8d1264: ldur            x3, [x1, #7]
    // 0x8d1268: sub             x1, x0, x3
    // 0x8d126c: StoreField: r2->field_7f = r1
    //     0x8d126c: stur            x1, [x2, #0x7f]
    // 0x8d1270: LoadField: r0 = r2->field_7b
    //     0x8d1270: ldur            w0, [x2, #0x7b]
    // 0x8d1274: DecompressPointer r0
    //     0x8d1274: add             x0, x0, HEAP, lsl #32
    // 0x8d1278: r1 = LoadInt32Instr(r0)
    //     0x8d1278: sbfx            x1, x0, #1, #0x1f
    //     0x8d127c: tbz             w0, #0, #0x8d1284
    //     0x8d1280: ldur            x1, [x0, #7]
    // 0x8d1284: sub             x4, x1, x3
    // 0x8d1288: r0 = BoxInt64Instr(r4)
    //     0x8d1288: sbfiz           x0, x4, #1, #0x1f
    //     0x8d128c: cmp             x4, x0, asr #1
    //     0x8d1290: b.eq            #0x8d129c
    //     0x8d1294: bl              #0xd69bb8
    //     0x8d1298: stur            x4, [x0, #7]
    // 0x8d129c: StoreField: r2->field_7b = r0
    //     0x8d129c: stur            w0, [x2, #0x7b]
    //     0x8d12a0: tbz             w0, #0, #0x8d12bc
    //     0x8d12a4: ldurb           w16, [x2, #-1]
    //     0x8d12a8: ldurb           w17, [x0, #-1]
    //     0x8d12ac: and             x16, x17, x16, lsr #2
    //     0x8d12b0: tst             x16, HEAP, lsr #32
    //     0x8d12b4: b.eq            #0x8d12bc
    //     0x8d12b8: bl              #0xd6828c
    // 0x8d12bc: LoadField: r0 = r2->field_6b
    //     0x8d12bc: ldur            w0, [x2, #0x6b]
    // 0x8d12c0: DecompressPointer r0
    //     0x8d12c0: add             x0, x0, HEAP, lsl #32
    // 0x8d12c4: r16 = Sentinel
    //     0x8d12c4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d12c8: cmp             w0, w16
    // 0x8d12cc: b.eq            #0x8d1774
    // 0x8d12d0: r1 = LoadInt32Instr(r0)
    //     0x8d12d0: sbfx            x1, x0, #1, #0x1f
    //     0x8d12d4: tbz             w0, #0, #0x8d12dc
    //     0x8d12d8: ldur            x1, [x0, #7]
    // 0x8d12dc: sub             x4, x1, x3
    // 0x8d12e0: r0 = BoxInt64Instr(r4)
    //     0x8d12e0: sbfiz           x0, x4, #1, #0x1f
    //     0x8d12e4: cmp             x4, x0, asr #1
    //     0x8d12e8: b.eq            #0x8d12f4
    //     0x8d12ec: bl              #0xd69bb8
    //     0x8d12f0: stur            x4, [x0, #7]
    // 0x8d12f4: StoreField: r2->field_6b = r0
    //     0x8d12f4: stur            w0, [x2, #0x6b]
    //     0x8d12f8: tbz             w0, #0, #0x8d1314
    //     0x8d12fc: ldurb           w16, [x2, #-1]
    //     0x8d1300: ldurb           w17, [x0, #-1]
    //     0x8d1304: and             x16, x17, x16, lsr #2
    //     0x8d1308: tst             x16, HEAP, lsr #32
    //     0x8d130c: b.eq            #0x8d1314
    //     0x8d1310: bl              #0xd6828c
    // 0x8d1314: LoadField: r0 = r2->field_5b
    //     0x8d1314: ldur            w0, [x2, #0x5b]
    // 0x8d1318: DecompressPointer r0
    //     0x8d1318: add             x0, x0, HEAP, lsl #32
    // 0x8d131c: r16 = Sentinel
    //     0x8d131c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1320: cmp             w0, w16
    // 0x8d1324: b.eq            #0x8d1780
    // 0x8d1328: r1 = LoadInt32Instr(r0)
    //     0x8d1328: sbfx            x1, x0, #1, #0x1f
    //     0x8d132c: tbz             w0, #0, #0x8d1334
    //     0x8d1330: ldur            x1, [x0, #7]
    // 0x8d1334: LoadField: r4 = r2->field_53
    //     0x8d1334: ldur            w4, [x2, #0x53]
    // 0x8d1338: DecompressPointer r4
    //     0x8d1338: add             x4, x4, HEAP, lsl #32
    // 0x8d133c: r16 = Sentinel
    //     0x8d133c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1340: cmp             w4, w16
    // 0x8d1344: b.eq            #0x8d178c
    // 0x8d1348: LoadField: r0 = r4->field_13
    //     0x8d1348: ldur            w0, [x4, #0x13]
    // 0x8d134c: DecompressPointer r0
    //     0x8d134c: add             x0, x0, HEAP, lsl #32
    // 0x8d1350: r5 = LoadInt32Instr(r0)
    //     0x8d1350: sbfx            x5, x0, #1, #0x1f
    // 0x8d1354: mov             x7, x1
    // 0x8d1358: mov             x0, x1
    // 0x8d135c: r6 = 65535
    //     0x8d135c: mov             x6, #0xffff
    // 0x8d1360: CheckStackOverflow
    //     0x8d1360: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d1364: cmp             SP, x16
    //     0x8d1368: b.ls            #0x8d1798
    // 0x8d136c: sub             x8, x0, #1
    // 0x8d1370: mov             x0, x5
    // 0x8d1374: mov             x1, x8
    // 0x8d1378: cmp             x1, x0
    // 0x8d137c: b.hs            #0x8d17a0
    // 0x8d1380: add             x16, x4, x8, lsl #1
    // 0x8d1384: ldurh           w0, [x16, #0x17]
    // 0x8d1388: ubfx            x0, x0, #0, #0x20
    // 0x8d138c: and             x1, x0, x6
    // 0x8d1390: mov             x0, x1
    // 0x8d1394: ubfx            x0, x0, #0, #0x20
    // 0x8d1398: cmp             x0, x3
    // 0x8d139c: b.lt            #0x8d13b0
    // 0x8d13a0: ubfx            x1, x1, #0, #0x20
    // 0x8d13a4: sub             x9, x1, x3
    // 0x8d13a8: mov             x0, x9
    // 0x8d13ac: b               #0x8d13b4
    // 0x8d13b0: r0 = 0
    //     0x8d13b0: mov             x0, #0
    // 0x8d13b4: LoadField: r1 = r4->field_7
    //     0x8d13b4: ldur            x1, [x4, #7]
    // 0x8d13b8: add             x9, x1, x8, lsl #1
    // 0x8d13bc: strh            w0, [x9]
    // 0x8d13c0: sub             x1, x7, #1
    // 0x8d13c4: cbz             x1, #0x8d13d4
    // 0x8d13c8: mov             x7, x1
    // 0x8d13cc: mov             x0, x8
    // 0x8d13d0: b               #0x8d1360
    // 0x8d13d4: LoadField: r4 = r2->field_4f
    //     0x8d13d4: ldur            w4, [x2, #0x4f]
    // 0x8d13d8: DecompressPointer r4
    //     0x8d13d8: add             x4, x4, HEAP, lsl #32
    // 0x8d13dc: r16 = Sentinel
    //     0x8d13dc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d13e0: cmp             w4, w16
    // 0x8d13e4: b.eq            #0x8d17a4
    // 0x8d13e8: LoadField: r0 = r4->field_13
    //     0x8d13e8: ldur            w0, [x4, #0x13]
    // 0x8d13ec: DecompressPointer r0
    //     0x8d13ec: add             x0, x0, HEAP, lsl #32
    // 0x8d13f0: r5 = LoadInt32Instr(r0)
    //     0x8d13f0: sbfx            x5, x0, #1, #0x1f
    // 0x8d13f4: mov             x7, x3
    // 0x8d13f8: mov             x0, x3
    // 0x8d13fc: CheckStackOverflow
    //     0x8d13fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d1400: cmp             SP, x16
    //     0x8d1404: b.ls            #0x8d17b0
    // 0x8d1408: sub             x8, x0, #1
    // 0x8d140c: mov             x0, x5
    // 0x8d1410: mov             x1, x8
    // 0x8d1414: cmp             x1, x0
    // 0x8d1418: b.hs            #0x8d17b8
    // 0x8d141c: add             x16, x4, x8, lsl #1
    // 0x8d1420: ldurh           w0, [x16, #0x17]
    // 0x8d1424: ubfx            x0, x0, #0, #0x20
    // 0x8d1428: and             x1, x0, x6
    // 0x8d142c: mov             x0, x1
    // 0x8d1430: ubfx            x0, x0, #0, #0x20
    // 0x8d1434: cmp             x0, x3
    // 0x8d1438: b.lt            #0x8d144c
    // 0x8d143c: ubfx            x1, x1, #0, #0x20
    // 0x8d1440: sub             x9, x1, x3
    // 0x8d1444: mov             x0, x9
    // 0x8d1448: b               #0x8d1450
    // 0x8d144c: r0 = 0
    //     0x8d144c: mov             x0, #0
    // 0x8d1450: LoadField: r1 = r4->field_7
    //     0x8d1450: ldur            x1, [x4, #7]
    // 0x8d1454: add             x9, x1, x8, lsl #1
    // 0x8d1458: strh            w0, [x9]
    // 0x8d145c: sub             x1, x7, #1
    // 0x8d1460: cbz             x1, #0x8d1470
    // 0x8d1464: mov             x7, x1
    // 0x8d1468: mov             x0, x8
    // 0x8d146c: b               #0x8d13fc
    // 0x8d1470: ldur            x0, [fp, #-8]
    // 0x8d1474: add             x1, x0, x3
    // 0x8d1478: mov             x0, x1
    // 0x8d147c: b               #0x8d148c
    // 0x8d1480: mov             x2, x0
    // 0x8d1484: mov             x0, x3
    // 0x8d1488: r6 = 65535
    //     0x8d1488: mov             x6, #0xffff
    // 0x8d148c: mov             x3, x0
    // 0x8d1490: LoadField: r0 = r2->field_17
    //     0x8d1490: ldur            w0, [x2, #0x17]
    // 0x8d1494: DecompressPointer r0
    //     0x8d1494: add             x0, x0, HEAP, lsl #32
    // 0x8d1498: LoadField: r1 = r0->field_b
    //     0x8d1498: ldur            x1, [x0, #0xb]
    // 0x8d149c: LoadField: r4 = r0->field_13
    //     0x8d149c: ldur            x4, [x0, #0x13]
    // 0x8d14a0: LoadField: r5 = r0->field_23
    //     0x8d14a0: ldur            w5, [x0, #0x23]
    // 0x8d14a4: DecompressPointer r5
    //     0x8d14a4: add             x5, x5, HEAP, lsl #32
    // 0x8d14a8: r16 = Sentinel
    //     0x8d14a8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d14ac: cmp             w5, w16
    // 0x8d14b0: b.eq            #0x8d17bc
    // 0x8d14b4: r0 = LoadInt32Instr(r5)
    //     0x8d14b4: sbfx            x0, x5, #1, #0x1f
    //     0x8d14b8: tbz             w5, #0, #0x8d14c0
    //     0x8d14bc: ldur            x0, [x5, #7]
    // 0x8d14c0: add             x5, x4, x0
    // 0x8d14c4: cmp             x1, x5
    // 0x8d14c8: b.lt            #0x8d14dc
    // 0x8d14cc: r0 = Null
    //     0x8d14cc: mov             x0, NULL
    // 0x8d14d0: LeaveFrame
    //     0x8d14d0: mov             SP, fp
    //     0x8d14d4: ldp             fp, lr, [SP], #0x10
    // 0x8d14d8: ret
    //     0x8d14d8: ret             
    // 0x8d14dc: LoadField: r4 = r2->field_47
    //     0x8d14dc: ldur            w4, [x2, #0x47]
    // 0x8d14e0: DecompressPointer r4
    //     0x8d14e0: add             x4, x4, HEAP, lsl #32
    // 0x8d14e4: r16 = Sentinel
    //     0x8d14e4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d14e8: cmp             w4, w16
    // 0x8d14ec: b.eq            #0x8d17c8
    // 0x8d14f0: LoadField: r0 = r2->field_7b
    //     0x8d14f0: ldur            w0, [x2, #0x7b]
    // 0x8d14f4: DecompressPointer r0
    //     0x8d14f4: add             x0, x0, HEAP, lsl #32
    // 0x8d14f8: r16 = Sentinel
    //     0x8d14f8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d14fc: cmp             w0, w16
    // 0x8d1500: b.eq            #0x8d17d4
    // 0x8d1504: LoadField: r1 = r2->field_87
    //     0x8d1504: ldur            w1, [x2, #0x87]
    // 0x8d1508: DecompressPointer r1
    //     0x8d1508: add             x1, x1, HEAP, lsl #32
    // 0x8d150c: r16 = Sentinel
    //     0x8d150c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1510: cmp             w1, w16
    // 0x8d1514: b.eq            #0x8d17e0
    // 0x8d1518: r5 = LoadInt32Instr(r0)
    //     0x8d1518: sbfx            x5, x0, #1, #0x1f
    //     0x8d151c: tbz             w0, #0, #0x8d1524
    //     0x8d1520: ldur            x5, [x0, #7]
    // 0x8d1524: r0 = LoadInt32Instr(r1)
    //     0x8d1524: sbfx            x0, x1, #1, #0x1f
    //     0x8d1528: tbz             w1, #0, #0x8d1530
    //     0x8d152c: ldur            x0, [x1, #7]
    // 0x8d1530: add             x7, x5, x0
    // 0x8d1534: r0 = BoxInt64Instr(r7)
    //     0x8d1534: sbfiz           x0, x7, #1, #0x1f
    //     0x8d1538: cmp             x7, x0, asr #1
    //     0x8d153c: b.eq            #0x8d1548
    //     0x8d1540: bl              #0xd69bb8
    //     0x8d1544: stur            x7, [x0, #7]
    // 0x8d1548: stp             x4, x2, [SP, #-0x10]!
    // 0x8d154c: stp             x3, x0, [SP, #-0x10]!
    // 0x8d1550: r0 = _readBuf()
    //     0x8d1550: bl              #0x8d184c  ; [package:archive/src/zlib/deflate.dart] Deflate::_readBuf
    // 0x8d1554: add             SP, SP, #0x20
    // 0x8d1558: ldr             x2, [fp, #0x10]
    // 0x8d155c: LoadField: r3 = r2->field_87
    //     0x8d155c: ldur            w3, [x2, #0x87]
    // 0x8d1560: DecompressPointer r3
    //     0x8d1560: add             x3, x3, HEAP, lsl #32
    // 0x8d1564: r4 = LoadInt32Instr(r3)
    //     0x8d1564: sbfx            x4, x3, #1, #0x1f
    //     0x8d1568: tbz             w3, #0, #0x8d1570
    //     0x8d156c: ldur            x4, [x3, #7]
    // 0x8d1570: add             x3, x4, x0
    // 0x8d1574: r0 = BoxInt64Instr(r3)
    //     0x8d1574: sbfiz           x0, x3, #1, #0x1f
    //     0x8d1578: cmp             x3, x0, asr #1
    //     0x8d157c: b.eq            #0x8d1588
    //     0x8d1580: bl              #0xd69bb8
    //     0x8d1584: stur            x3, [x0, #7]
    // 0x8d1588: StoreField: r2->field_87 = r0
    //     0x8d1588: stur            w0, [x2, #0x87]
    //     0x8d158c: tbz             w0, #0, #0x8d15a8
    //     0x8d1590: ldurb           w16, [x2, #-1]
    //     0x8d1594: ldurb           w17, [x0, #-1]
    //     0x8d1598: and             x16, x17, x16, lsr #2
    //     0x8d159c: tst             x16, HEAP, lsr #32
    //     0x8d15a0: b.eq            #0x8d15a8
    //     0x8d15a4: bl              #0xd6828c
    // 0x8d15a8: cmp             x3, #3
    // 0x8d15ac: b.lt            #0x8d16bc
    // 0x8d15b0: r4 = 255
    //     0x8d15b0: mov             x4, #0xff
    // 0x8d15b4: LoadField: r5 = r2->field_47
    //     0x8d15b4: ldur            w5, [x2, #0x47]
    // 0x8d15b8: DecompressPointer r5
    //     0x8d15b8: add             x5, x5, HEAP, lsl #32
    // 0x8d15bc: LoadField: r6 = r2->field_7b
    //     0x8d15bc: ldur            w6, [x2, #0x7b]
    // 0x8d15c0: DecompressPointer r6
    //     0x8d15c0: add             x6, x6, HEAP, lsl #32
    // 0x8d15c4: LoadField: r7 = r5->field_13
    //     0x8d15c4: ldur            w7, [x5, #0x13]
    // 0x8d15c8: DecompressPointer r7
    //     0x8d15c8: add             x7, x7, HEAP, lsl #32
    // 0x8d15cc: r8 = LoadInt32Instr(r6)
    //     0x8d15cc: sbfx            x8, x6, #1, #0x1f
    //     0x8d15d0: tbz             w6, #0, #0x8d15d8
    //     0x8d15d4: ldur            x8, [x6, #7]
    // 0x8d15d8: r6 = LoadInt32Instr(r7)
    //     0x8d15d8: sbfx            x6, x7, #1, #0x1f
    // 0x8d15dc: mov             x0, x6
    // 0x8d15e0: mov             x1, x8
    // 0x8d15e4: cmp             x1, x0
    // 0x8d15e8: b.hs            #0x8d17ec
    // 0x8d15ec: ArrayLoad: r7 = r5[r8]  ; TypedUnsigned_1
    //     0x8d15ec: add             x16, x5, x8
    //     0x8d15f0: ldrb            w7, [x16, #0x17]
    // 0x8d15f4: ubfx            x7, x7, #0, #0x20
    // 0x8d15f8: and             x10, x7, x4
    // 0x8d15fc: lsl             w7, w10, #1
    // 0x8d1600: StoreField: r2->field_57 = r7
    //     0x8d1600: stur            w7, [x2, #0x57]
    // 0x8d1604: LoadField: r7 = r2->field_67
    //     0x8d1604: ldur            w7, [x2, #0x67]
    // 0x8d1608: DecompressPointer r7
    //     0x8d1608: add             x7, x7, HEAP, lsl #32
    // 0x8d160c: r16 = Sentinel
    //     0x8d160c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1610: cmp             w7, w16
    // 0x8d1614: b.eq            #0x8d17f0
    // 0x8d1618: r11 = LoadInt32Instr(r7)
    //     0x8d1618: sbfx            x11, x7, #1, #0x1f
    //     0x8d161c: tbz             w7, #0, #0x8d1624
    //     0x8d1620: ldur            x11, [x7, #7]
    // 0x8d1624: ubfx            x10, x10, #0, #0x20
    // 0x8d1628: cmp             x11, #0x3f
    // 0x8d162c: b.hi            #0x8d17fc
    // 0x8d1630: lsl             x7, x10, x11
    // 0x8d1634: add             x9, x8, #1
    // 0x8d1638: mov             x0, x6
    // 0x8d163c: mov             x1, x9
    // 0x8d1640: cmp             x1, x0
    // 0x8d1644: b.hs            #0x8d1830
    // 0x8d1648: ArrayLoad: r6 = r5[r9]  ; TypedUnsigned_1
    //     0x8d1648: add             x16, x5, x9
    //     0x8d164c: ldrb            w6, [x16, #0x17]
    // 0x8d1650: ubfx            x6, x6, #0, #0x20
    // 0x8d1654: and             x5, x6, x4
    // 0x8d1658: ubfx            x5, x5, #0, #0x20
    // 0x8d165c: eor             x6, x7, x5
    // 0x8d1660: LoadField: r5 = r2->field_63
    //     0x8d1660: ldur            w5, [x2, #0x63]
    // 0x8d1664: DecompressPointer r5
    //     0x8d1664: add             x5, x5, HEAP, lsl #32
    // 0x8d1668: r16 = Sentinel
    //     0x8d1668: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d166c: cmp             w5, w16
    // 0x8d1670: b.eq            #0x8d1834
    // 0x8d1674: r7 = LoadInt32Instr(r5)
    //     0x8d1674: sbfx            x7, x5, #1, #0x1f
    //     0x8d1678: tbz             w5, #0, #0x8d1680
    //     0x8d167c: ldur            x7, [x5, #7]
    // 0x8d1680: and             x5, x6, x7
    // 0x8d1684: r0 = BoxInt64Instr(r5)
    //     0x8d1684: sbfiz           x0, x5, #1, #0x1f
    //     0x8d1688: cmp             x5, x0, asr #1
    //     0x8d168c: b.eq            #0x8d1698
    //     0x8d1690: bl              #0xd69bb8
    //     0x8d1694: stur            x5, [x0, #7]
    // 0x8d1698: StoreField: r2->field_57 = r0
    //     0x8d1698: stur            w0, [x2, #0x57]
    //     0x8d169c: tbz             w0, #0, #0x8d16b8
    //     0x8d16a0: ldurb           w16, [x2, #-1]
    //     0x8d16a4: ldurb           w17, [x0, #-1]
    //     0x8d16a8: and             x16, x17, x16, lsr #2
    //     0x8d16ac: tst             x16, HEAP, lsr #32
    //     0x8d16b0: b.eq            #0x8d16b8
    //     0x8d16b4: bl              #0xd6828c
    // 0x8d16b8: b               #0x8d16c0
    // 0x8d16bc: r4 = 255
    //     0x8d16bc: mov             x4, #0xff
    // 0x8d16c0: cmp             x3, #0x106
    // 0x8d16c4: b.ge            #0x8d170c
    // 0x8d16c8: LoadField: r1 = r2->field_17
    //     0x8d16c8: ldur            w1, [x2, #0x17]
    // 0x8d16cc: DecompressPointer r1
    //     0x8d16cc: add             x1, x1, HEAP, lsl #32
    // 0x8d16d0: LoadField: r3 = r1->field_b
    //     0x8d16d0: ldur            x3, [x1, #0xb]
    // 0x8d16d4: LoadField: r5 = r1->field_13
    //     0x8d16d4: ldur            x5, [x1, #0x13]
    // 0x8d16d8: LoadField: r6 = r1->field_23
    //     0x8d16d8: ldur            w6, [x1, #0x23]
    // 0x8d16dc: DecompressPointer r6
    //     0x8d16dc: add             x6, x6, HEAP, lsl #32
    // 0x8d16e0: r16 = Sentinel
    //     0x8d16e0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d16e4: cmp             w6, w16
    // 0x8d16e8: b.eq            #0x8d1840
    // 0x8d16ec: r1 = LoadInt32Instr(r6)
    //     0x8d16ec: sbfx            x1, x6, #1, #0x1f
    //     0x8d16f0: tbz             w6, #0, #0x8d16f8
    //     0x8d16f4: ldur            x1, [x6, #7]
    // 0x8d16f8: add             x6, x5, x1
    // 0x8d16fc: cmp             x3, x6
    // 0x8d1700: b.ge            #0x8d170c
    // 0x8d1704: mov             x0, x2
    // 0x8d1708: b               #0x8d113c
    // 0x8d170c: r0 = Null
    //     0x8d170c: mov             x0, NULL
    // 0x8d1710: LeaveFrame
    //     0x8d1710: mov             SP, fp
    //     0x8d1714: ldp             fp, lr, [SP], #0x10
    // 0x8d1718: ret
    //     0x8d1718: ret             
    // 0x8d171c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d171c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d1720: b               #0x8d1138
    // 0x8d1724: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d1724: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d1728: b               #0x8d1148
    // 0x8d172c: r9 = _actualWindowSize
    //     0x8d172c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b80] Field <Deflate._actualWindowSize@60040000>: late (offset: 0x4c)
    //     0x8d1730: ldr             x9, [x9, #0xb80]
    // 0x8d1734: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d1734: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d1738: r9 = _lookAhead
    //     0x8d1738: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a28] Field <Deflate._lookAhead@60040000>: late (offset: 0x88)
    //     0x8d173c: ldr             x9, [x9, #0xa28]
    // 0x8d1740: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d1740: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d1744: r9 = _strStart
    //     0x8d1744: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a58] Field <Deflate._strStart@60040000>: late (offset: 0x7c)
    //     0x8d1748: ldr             x9, [x9, #0xa58]
    // 0x8d174c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d174c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d1750: r9 = _windowSize
    //     0x8d1750: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a98] Field <Deflate._windowSize@60040000>: late (offset: 0x3c)
    //     0x8d1754: ldr             x9, [x9, #0xa98]
    // 0x8d1758: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d1758: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d175c: r9 = _windowSize
    //     0x8d175c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a98] Field <Deflate._windowSize@60040000>: late (offset: 0x3c)
    //     0x8d1760: ldr             x9, [x9, #0xa98]
    // 0x8d1764: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d1764: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d1768: r9 = _window
    //     0x8d1768: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a38] Field <Deflate._window@60040000>: late (offset: 0x48)
    //     0x8d176c: ldr             x9, [x9, #0xa38]
    // 0x8d1770: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d1770: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d1774: r9 = _blockStart
    //     0x8d1774: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ab0] Field <Deflate._blockStart@60040000>: late (offset: 0x6c)
    //     0x8d1778: ldr             x9, [x9, #0xab0]
    // 0x8d177c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d177c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d1780: r9 = _hashSize
    //     0x8d1780: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b88] Field <Deflate._hashSize@60040000>: late (offset: 0x5c)
    //     0x8d1784: ldr             x9, [x9, #0xb88]
    // 0x8d1788: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d1788: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d178c: r9 = _head
    //     0x8d178c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a78] Field <Deflate._head@60040000>: late (offset: 0x54)
    //     0x8d1790: ldr             x9, [x9, #0xa78]
    // 0x8d1794: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d1794: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d1798: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d1798: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d179c: b               #0x8d136c
    // 0x8d17a0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d17a0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d17a4: r9 = _prev
    //     0x8d17a4: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a80] Field <Deflate._prev@60040000>: late (offset: 0x50)
    //     0x8d17a8: ldr             x9, [x9, #0xa80]
    // 0x8d17ac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d17ac: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d17b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d17b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d17b4: b               #0x8d1408
    // 0x8d17b8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d17b8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d17bc: r9 = _length
    //     0x8d17bc: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a20] Field <InputStream._length@54080104>: late (offset: 0x24)
    //     0x8d17c0: ldr             x9, [x9, #0xa20]
    // 0x8d17c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d17c4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d17c8: r9 = _window
    //     0x8d17c8: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a38] Field <Deflate._window@60040000>: late (offset: 0x48)
    //     0x8d17cc: ldr             x9, [x9, #0xa38]
    // 0x8d17d0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d17d0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d17d4: r9 = _strStart
    //     0x8d17d4: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a58] Field <Deflate._strStart@60040000>: late (offset: 0x7c)
    //     0x8d17d8: ldr             x9, [x9, #0xa58]
    // 0x8d17dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d17dc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d17e0: r9 = _lookAhead
    //     0x8d17e0: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a28] Field <Deflate._lookAhead@60040000>: late (offset: 0x88)
    //     0x8d17e4: ldr             x9, [x9, #0xa28]
    // 0x8d17e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d17e8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d17ec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d17ec: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d17f0: r9 = _hashShift
    //     0x8d17f0: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a68] Field <Deflate._hashShift@60040000>: late (offset: 0x68)
    //     0x8d17f4: ldr             x9, [x9, #0xa68]
    // 0x8d17f8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d17f8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d17fc: tbnz            x11, #0x3f, #0x8d1808
    // 0x8d1800: mov             x7, xzr
    // 0x8d1804: b               #0x8d1634
    // 0x8d1808: str             x11, [THR, #0xc0]  ; THR::
    // 0x8d180c: stp             x10, x11, [SP, #-0x10]!
    // 0x8d1810: stp             x6, x8, [SP, #-0x10]!
    // 0x8d1814: stp             x4, x5, [SP, #-0x10]!
    // 0x8d1818: stp             x2, x3, [SP, #-0x10]!
    // 0x8d181c: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x8d1820: r4 = 0
    //     0x8d1820: mov             x4, #0
    // 0x8d1824: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8d1828: blr             lr
    // 0x8d182c: brk             #0
    // 0x8d1830: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d1830: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d1834: r9 = _hashMask
    //     0x8d1834: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a70] Field <Deflate._hashMask@60040000>: late (offset: 0x64)
    //     0x8d1838: ldr             x9, [x9, #0xa70]
    // 0x8d183c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d183c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d1840: r9 = _length
    //     0x8d1840: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a20] Field <InputStream._length@54080104>: late (offset: 0x24)
    //     0x8d1844: ldr             x9, [x9, #0xa20]
    // 0x8d1848: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d1848: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _readBuf(/* No info */) {
    // ** addr: 0x8d184c, size: 0x17c
    // 0x8d184c: EnterFrame
    //     0x8d184c: stp             fp, lr, [SP, #-0x10]!
    //     0x8d1850: mov             fp, SP
    // 0x8d1854: AllocStack(0x10)
    //     0x8d1854: sub             SP, SP, #0x10
    // 0x8d1858: CheckStackOverflow
    //     0x8d1858: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d185c: cmp             SP, x16
    //     0x8d1860: b.ls            #0x8d19b4
    // 0x8d1864: ldr             x0, [fp, #0x10]
    // 0x8d1868: cbz             x0, #0x8d18ac
    // 0x8d186c: ldr             x1, [fp, #0x28]
    // 0x8d1870: LoadField: r2 = r1->field_17
    //     0x8d1870: ldur            w2, [x1, #0x17]
    // 0x8d1874: DecompressPointer r2
    //     0x8d1874: add             x2, x2, HEAP, lsl #32
    // 0x8d1878: LoadField: r3 = r2->field_b
    //     0x8d1878: ldur            x3, [x2, #0xb]
    // 0x8d187c: LoadField: r4 = r2->field_13
    //     0x8d187c: ldur            x4, [x2, #0x13]
    // 0x8d1880: LoadField: r5 = r2->field_23
    //     0x8d1880: ldur            w5, [x2, #0x23]
    // 0x8d1884: DecompressPointer r5
    //     0x8d1884: add             x5, x5, HEAP, lsl #32
    // 0x8d1888: r16 = Sentinel
    //     0x8d1888: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d188c: cmp             w5, w16
    // 0x8d1890: b.eq            #0x8d19bc
    // 0x8d1894: r6 = LoadInt32Instr(r5)
    //     0x8d1894: sbfx            x6, x5, #1, #0x1f
    //     0x8d1898: tbz             w5, #0, #0x8d18a0
    //     0x8d189c: ldur            x6, [x5, #7]
    // 0x8d18a0: add             x5, x4, x6
    // 0x8d18a4: cmp             x3, x5
    // 0x8d18a8: b.lt            #0x8d18bc
    // 0x8d18ac: r0 = 0
    //     0x8d18ac: mov             x0, #0
    // 0x8d18b0: LeaveFrame
    //     0x8d18b0: mov             SP, fp
    //     0x8d18b4: ldp             fp, lr, [SP], #0x10
    // 0x8d18b8: ret
    //     0x8d18b8: ret             
    // 0x8d18bc: stp             x0, x2, [SP, #-0x10]!
    // 0x8d18c0: r0 = readBytes()
    //     0x8d18c0: bl              #0x817d54  ; [package:archive/src/util/input_stream.dart] InputStream::readBytes
    // 0x8d18c4: add             SP, SP, #0x10
    // 0x8d18c8: stur            x0, [fp, #-8]
    // 0x8d18cc: SaveReg r0
    //     0x8d18cc: str             x0, [SP, #-8]!
    // 0x8d18d0: r0 = length()
    //     0x8d18d0: bl              #0x7f5c48  ; [package:archive/src/util/input_stream.dart] InputStream::length
    // 0x8d18d4: add             SP, SP, #8
    // 0x8d18d8: stur            x0, [fp, #-0x10]
    // 0x8d18dc: cbnz            x0, #0x8d18f0
    // 0x8d18e0: r0 = 0
    //     0x8d18e0: mov             x0, #0
    // 0x8d18e4: LeaveFrame
    //     0x8d18e4: mov             SP, fp
    //     0x8d18e8: ldp             fp, lr, [SP], #0x10
    // 0x8d18ec: ret
    //     0x8d18ec: ret             
    // 0x8d18f0: ldur            x16, [fp, #-8]
    // 0x8d18f4: SaveReg r16
    //     0x8d18f4: str             x16, [SP, #-8]!
    // 0x8d18f8: r0 = toUint8List()
    //     0x8d18f8: bl              #0x7f57d4  ; [package:archive/src/util/input_stream.dart] InputStream::toUint8List
    // 0x8d18fc: add             SP, SP, #8
    // 0x8d1900: stur            x0, [fp, #-8]
    // 0x8d1904: LoadField: r1 = r0->field_13
    //     0x8d1904: ldur            w1, [x0, #0x13]
    // 0x8d1908: DecompressPointer r1
    //     0x8d1908: add             x1, x1, HEAP, lsl #32
    // 0x8d190c: r2 = LoadInt32Instr(r1)
    //     0x8d190c: sbfx            x2, x1, #1, #0x1f
    // 0x8d1910: ldur            x1, [fp, #-0x10]
    // 0x8d1914: cmp             x1, x2
    // 0x8d1918: b.le            #0x8d1924
    // 0x8d191c: mov             x3, x2
    // 0x8d1920: b               #0x8d1928
    // 0x8d1924: mov             x3, x1
    // 0x8d1928: ldr             x1, [fp, #0x28]
    // 0x8d192c: ldr             x2, [fp, #0x18]
    // 0x8d1930: stur            x3, [fp, #-0x10]
    // 0x8d1934: r4 = LoadInt32Instr(r2)
    //     0x8d1934: sbfx            x4, x2, #1, #0x1f
    //     0x8d1938: tbz             w2, #0, #0x8d1940
    //     0x8d193c: ldur            x4, [x2, #7]
    // 0x8d1940: add             x5, x4, x3
    // 0x8d1944: ldr             x16, [fp, #0x20]
    // 0x8d1948: stp             x2, x16, [SP, #-0x10]!
    // 0x8d194c: stp             x0, x5, [SP, #-0x10]!
    // 0x8d1950: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x8d1950: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x8d1954: r0 = setRange()
    //     0x8d1954: bl              #0x605c8c  ; [dart:typed_data] __Uint8List&_TypedList&_IntListMixin&_TypedIntListMixin::setRange
    // 0x8d1958: add             SP, SP, #0x20
    // 0x8d195c: ldr             x2, [fp, #0x28]
    // 0x8d1960: LoadField: r0 = r2->field_f
    //     0x8d1960: ldur            x0, [x2, #0xf]
    // 0x8d1964: ldur            x3, [fp, #-0x10]
    // 0x8d1968: add             x1, x0, x3
    // 0x8d196c: StoreField: r2->field_f = r1
    //     0x8d196c: stur            x1, [x2, #0xf]
    // 0x8d1970: LoadField: r4 = r2->field_7
    //     0x8d1970: ldur            x4, [x2, #7]
    // 0x8d1974: r0 = BoxInt64Instr(r4)
    //     0x8d1974: sbfiz           x0, x4, #1, #0x1f
    //     0x8d1978: cmp             x4, x0, asr #1
    //     0x8d197c: b.eq            #0x8d1988
    //     0x8d1980: bl              #0xd69bb8
    //     0x8d1984: stur            x4, [x0, #7]
    // 0x8d1988: ldur            x16, [fp, #-8]
    // 0x8d198c: stp             x0, x16, [SP, #-0x10]!
    // 0x8d1990: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x8d1990: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x8d1994: r0 = getCrc32()
    //     0x8d1994: bl              #0x8c7f8c  ; [package:archive/src/util/crc32.dart] ::getCrc32
    // 0x8d1998: add             SP, SP, #0x10
    // 0x8d199c: ldr             x1, [fp, #0x28]
    // 0x8d19a0: StoreField: r1->field_7 = r0
    //     0x8d19a0: stur            x0, [x1, #7]
    // 0x8d19a4: ldur            x0, [fp, #-0x10]
    // 0x8d19a8: LeaveFrame
    //     0x8d19a8: mov             SP, fp
    //     0x8d19ac: ldp             fp, lr, [SP], #0x10
    // 0x8d19b0: ret
    //     0x8d19b0: ret             
    // 0x8d19b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d19b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d19b8: b               #0x8d1864
    // 0x8d19bc: r9 = _length
    //     0x8d19bc: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a20] Field <InputStream._length@54080104>: late (offset: 0x24)
    //     0x8d19c0: ldr             x9, [x9, #0xa20]
    // 0x8d19c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d19c4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _deflateFast(/* No info */) {
    // ** addr: 0x8d19c8, size: 0xc18
    // 0x8d19c8: EnterFrame
    //     0x8d19c8: stp             fp, lr, [SP, #-0x10]!
    //     0x8d19cc: mov             fp, SP
    // 0x8d19d0: AllocStack(0x8)
    //     0x8d19d0: sub             SP, SP, #8
    // 0x8d19d4: CheckStackOverflow
    //     0x8d19d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d19d8: cmp             SP, x16
    //     0x8d19dc: b.ls            #0x8d23c4
    // 0x8d19e0: r1 = 0
    //     0x8d19e0: mov             x1, #0
    // 0x8d19e4: ldr             x0, [fp, #0x10]
    // 0x8d19e8: stur            x1, [fp, #-8]
    // 0x8d19ec: CheckStackOverflow
    //     0x8d19ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d19f0: cmp             SP, x16
    //     0x8d19f4: b.ls            #0x8d23cc
    // 0x8d19f8: LoadField: r2 = r0->field_87
    //     0x8d19f8: ldur            w2, [x0, #0x87]
    // 0x8d19fc: DecompressPointer r2
    //     0x8d19fc: add             x2, x2, HEAP, lsl #32
    // 0x8d1a00: r16 = Sentinel
    //     0x8d1a00: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1a04: cmp             w2, w16
    // 0x8d1a08: b.eq            #0x8d23d4
    // 0x8d1a0c: r3 = LoadInt32Instr(r2)
    //     0x8d1a0c: sbfx            x3, x2, #1, #0x1f
    //     0x8d1a10: tbz             w2, #0, #0x8d1a18
    //     0x8d1a14: ldur            x3, [x2, #7]
    // 0x8d1a18: cmp             x3, #0x106
    // 0x8d1a1c: b.ge            #0x8d1a7c
    // 0x8d1a20: SaveReg r0
    //     0x8d1a20: str             x0, [SP, #-8]!
    // 0x8d1a24: r0 = _fillWindow()
    //     0x8d1a24: bl              #0x8d1120  ; [package:archive/src/zlib/deflate.dart] Deflate::_fillWindow
    // 0x8d1a28: add             SP, SP, #8
    // 0x8d1a2c: ldr             x3, [fp, #0x10]
    // 0x8d1a30: LoadField: r0 = r3->field_87
    //     0x8d1a30: ldur            w0, [x3, #0x87]
    // 0x8d1a34: DecompressPointer r0
    //     0x8d1a34: add             x0, x0, HEAP, lsl #32
    // 0x8d1a38: r1 = LoadInt32Instr(r0)
    //     0x8d1a38: sbfx            x1, x0, #1, #0x1f
    //     0x8d1a3c: tbz             w0, #0, #0x8d1a44
    //     0x8d1a40: ldur            x1, [x0, #7]
    // 0x8d1a44: cbnz            x1, #0x8d1a68
    // 0x8d1a48: r16 = true
    //     0x8d1a48: add             x16, NULL, #0x20  ; true
    // 0x8d1a4c: stp             x16, x3, [SP, #-0x10]!
    // 0x8d1a50: r0 = _flushBlockOnly()
    //     0x8d1a50: bl              #0x8cd6d8  ; [package:archive/src/zlib/deflate.dart] Deflate::_flushBlockOnly
    // 0x8d1a54: add             SP, SP, #0x10
    // 0x8d1a58: r0 = 3
    //     0x8d1a58: mov             x0, #3
    // 0x8d1a5c: LeaveFrame
    //     0x8d1a5c: mov             SP, fp
    //     0x8d1a60: ldp             fp, lr, [SP], #0x10
    // 0x8d1a64: ret
    //     0x8d1a64: ret             
    // 0x8d1a68: r1 = LoadInt32Instr(r0)
    //     0x8d1a68: sbfx            x1, x0, #1, #0x1f
    //     0x8d1a6c: tbz             w0, #0, #0x8d1a74
    //     0x8d1a70: ldur            x1, [x0, #7]
    // 0x8d1a74: mov             x0, x1
    // 0x8d1a78: b               #0x8d1a8c
    // 0x8d1a7c: mov             x3, x0
    // 0x8d1a80: r0 = LoadInt32Instr(r2)
    //     0x8d1a80: sbfx            x0, x2, #1, #0x1f
    //     0x8d1a84: tbz             w2, #0, #0x8d1a8c
    //     0x8d1a88: ldur            x0, [x2, #7]
    // 0x8d1a8c: cmp             x0, #3
    // 0x8d1a90: b.lt            #0x8d1c68
    // 0x8d1a94: r4 = 255
    //     0x8d1a94: mov             x4, #0xff
    // 0x8d1a98: r2 = 65535
    //     0x8d1a98: mov             x2, #0xffff
    // 0x8d1a9c: LoadField: r0 = r3->field_57
    //     0x8d1a9c: ldur            w0, [x3, #0x57]
    // 0x8d1aa0: DecompressPointer r0
    //     0x8d1aa0: add             x0, x0, HEAP, lsl #32
    // 0x8d1aa4: r16 = Sentinel
    //     0x8d1aa4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1aa8: cmp             w0, w16
    // 0x8d1aac: b.eq            #0x8d23e0
    // 0x8d1ab0: LoadField: r1 = r3->field_67
    //     0x8d1ab0: ldur            w1, [x3, #0x67]
    // 0x8d1ab4: DecompressPointer r1
    //     0x8d1ab4: add             x1, x1, HEAP, lsl #32
    // 0x8d1ab8: r16 = Sentinel
    //     0x8d1ab8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1abc: cmp             w1, w16
    // 0x8d1ac0: b.eq            #0x8d23ec
    // 0x8d1ac4: r5 = LoadInt32Instr(r0)
    //     0x8d1ac4: sbfx            x5, x0, #1, #0x1f
    //     0x8d1ac8: tbz             w0, #0, #0x8d1ad0
    //     0x8d1acc: ldur            x5, [x0, #7]
    // 0x8d1ad0: r0 = LoadInt32Instr(r1)
    //     0x8d1ad0: sbfx            x0, x1, #1, #0x1f
    //     0x8d1ad4: tbz             w1, #0, #0x8d1adc
    //     0x8d1ad8: ldur            x0, [x1, #7]
    // 0x8d1adc: cmp             x0, #0x3f
    // 0x8d1ae0: b.hi            #0x8d23f8
    // 0x8d1ae4: lsl             x6, x5, x0
    // 0x8d1ae8: LoadField: r5 = r3->field_47
    //     0x8d1ae8: ldur            w5, [x3, #0x47]
    // 0x8d1aec: DecompressPointer r5
    //     0x8d1aec: add             x5, x5, HEAP, lsl #32
    // 0x8d1af0: r16 = Sentinel
    //     0x8d1af0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1af4: cmp             w5, w16
    // 0x8d1af8: b.eq            #0x8d2428
    // 0x8d1afc: LoadField: r0 = r3->field_7b
    //     0x8d1afc: ldur            w0, [x3, #0x7b]
    // 0x8d1b00: DecompressPointer r0
    //     0x8d1b00: add             x0, x0, HEAP, lsl #32
    // 0x8d1b04: r16 = Sentinel
    //     0x8d1b04: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1b08: cmp             w0, w16
    // 0x8d1b0c: b.eq            #0x8d2434
    // 0x8d1b10: r7 = LoadInt32Instr(r0)
    //     0x8d1b10: sbfx            x7, x0, #1, #0x1f
    //     0x8d1b14: tbz             w0, #0, #0x8d1b1c
    //     0x8d1b18: ldur            x7, [x0, #7]
    // 0x8d1b1c: add             x8, x7, #2
    // 0x8d1b20: LoadField: r0 = r5->field_13
    //     0x8d1b20: ldur            w0, [x5, #0x13]
    // 0x8d1b24: DecompressPointer r0
    //     0x8d1b24: add             x0, x0, HEAP, lsl #32
    // 0x8d1b28: r1 = LoadInt32Instr(r0)
    //     0x8d1b28: sbfx            x1, x0, #1, #0x1f
    // 0x8d1b2c: mov             x0, x1
    // 0x8d1b30: mov             x1, x8
    // 0x8d1b34: cmp             x1, x0
    // 0x8d1b38: b.hs            #0x8d2440
    // 0x8d1b3c: ArrayLoad: r0 = r5[r8]  ; TypedUnsigned_1
    //     0x8d1b3c: add             x16, x5, x8
    //     0x8d1b40: ldrb            w0, [x16, #0x17]
    // 0x8d1b44: ubfx            x0, x0, #0, #0x20
    // 0x8d1b48: and             x1, x0, x4
    // 0x8d1b4c: ubfx            x1, x1, #0, #0x20
    // 0x8d1b50: eor             x0, x6, x1
    // 0x8d1b54: LoadField: r1 = r3->field_63
    //     0x8d1b54: ldur            w1, [x3, #0x63]
    // 0x8d1b58: DecompressPointer r1
    //     0x8d1b58: add             x1, x1, HEAP, lsl #32
    // 0x8d1b5c: r16 = Sentinel
    //     0x8d1b5c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1b60: cmp             w1, w16
    // 0x8d1b64: b.eq            #0x8d2444
    // 0x8d1b68: r5 = LoadInt32Instr(r1)
    //     0x8d1b68: sbfx            x5, x1, #1, #0x1f
    //     0x8d1b6c: tbz             w1, #0, #0x8d1b74
    //     0x8d1b70: ldur            x5, [x1, #7]
    // 0x8d1b74: and             x6, x0, x5
    // 0x8d1b78: r0 = BoxInt64Instr(r6)
    //     0x8d1b78: sbfiz           x0, x6, #1, #0x1f
    //     0x8d1b7c: cmp             x6, x0, asr #1
    //     0x8d1b80: b.eq            #0x8d1b8c
    //     0x8d1b84: bl              #0xd69bb8
    //     0x8d1b88: stur            x6, [x0, #7]
    // 0x8d1b8c: StoreField: r3->field_57 = r0
    //     0x8d1b8c: stur            w0, [x3, #0x57]
    //     0x8d1b90: tbz             w0, #0, #0x8d1bac
    //     0x8d1b94: ldurb           w16, [x3, #-1]
    //     0x8d1b98: ldurb           w17, [x0, #-1]
    //     0x8d1b9c: and             x16, x17, x16, lsr #2
    //     0x8d1ba0: tst             x16, HEAP, lsr #32
    //     0x8d1ba4: b.eq            #0x8d1bac
    //     0x8d1ba8: bl              #0xd682ac
    // 0x8d1bac: LoadField: r5 = r3->field_53
    //     0x8d1bac: ldur            w5, [x3, #0x53]
    // 0x8d1bb0: DecompressPointer r5
    //     0x8d1bb0: add             x5, x5, HEAP, lsl #32
    // 0x8d1bb4: r16 = Sentinel
    //     0x8d1bb4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1bb8: cmp             w5, w16
    // 0x8d1bbc: b.eq            #0x8d2450
    // 0x8d1bc0: LoadField: r0 = r5->field_13
    //     0x8d1bc0: ldur            w0, [x5, #0x13]
    // 0x8d1bc4: DecompressPointer r0
    //     0x8d1bc4: add             x0, x0, HEAP, lsl #32
    // 0x8d1bc8: r1 = LoadInt32Instr(r0)
    //     0x8d1bc8: sbfx            x1, x0, #1, #0x1f
    // 0x8d1bcc: mov             x0, x1
    // 0x8d1bd0: mov             x1, x6
    // 0x8d1bd4: cmp             x1, x0
    // 0x8d1bd8: b.hs            #0x8d245c
    // 0x8d1bdc: add             x16, x5, x6, lsl #1
    // 0x8d1be0: ldurh           w8, [x16, #0x17]
    // 0x8d1be4: mov             x0, x8
    // 0x8d1be8: ubfx            x0, x0, #0, #0x20
    // 0x8d1bec: and             x10, x0, x2
    // 0x8d1bf0: LoadField: r11 = r3->field_4f
    //     0x8d1bf0: ldur            w11, [x3, #0x4f]
    // 0x8d1bf4: DecompressPointer r11
    //     0x8d1bf4: add             x11, x11, HEAP, lsl #32
    // 0x8d1bf8: r16 = Sentinel
    //     0x8d1bf8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1bfc: cmp             w11, w16
    // 0x8d1c00: b.eq            #0x8d2460
    // 0x8d1c04: LoadField: r0 = r3->field_43
    //     0x8d1c04: ldur            w0, [x3, #0x43]
    // 0x8d1c08: DecompressPointer r0
    //     0x8d1c08: add             x0, x0, HEAP, lsl #32
    // 0x8d1c0c: r16 = Sentinel
    //     0x8d1c0c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1c10: cmp             w0, w16
    // 0x8d1c14: b.eq            #0x8d246c
    // 0x8d1c18: r1 = LoadInt32Instr(r0)
    //     0x8d1c18: sbfx            x1, x0, #1, #0x1f
    //     0x8d1c1c: tbz             w0, #0, #0x8d1c24
    //     0x8d1c20: ldur            x1, [x0, #7]
    // 0x8d1c24: and             x9, x7, x1
    // 0x8d1c28: LoadField: r0 = r11->field_13
    //     0x8d1c28: ldur            w0, [x11, #0x13]
    // 0x8d1c2c: DecompressPointer r0
    //     0x8d1c2c: add             x0, x0, HEAP, lsl #32
    // 0x8d1c30: r1 = LoadInt32Instr(r0)
    //     0x8d1c30: sbfx            x1, x0, #1, #0x1f
    // 0x8d1c34: mov             x0, x1
    // 0x8d1c38: mov             x1, x9
    // 0x8d1c3c: cmp             x1, x0
    // 0x8d1c40: b.hs            #0x8d2478
    // 0x8d1c44: LoadField: r0 = r11->field_7
    //     0x8d1c44: ldur            x0, [x11, #7]
    // 0x8d1c48: add             x1, x0, x9, lsl #1
    // 0x8d1c4c: strh            w8, [x1]
    // 0x8d1c50: LoadField: r0 = r5->field_7
    //     0x8d1c50: ldur            x0, [x5, #7]
    // 0x8d1c54: add             x1, x0, x6, lsl #1
    // 0x8d1c58: strh            w7, [x1]
    // 0x8d1c5c: ubfx            x10, x10, #0, #0x20
    // 0x8d1c60: mov             x0, x10
    // 0x8d1c64: b               #0x8d1c74
    // 0x8d1c68: r4 = 255
    //     0x8d1c68: mov             x4, #0xff
    // 0x8d1c6c: r2 = 65535
    //     0x8d1c6c: mov             x2, #0xffff
    // 0x8d1c70: ldur            x0, [fp, #-8]
    // 0x8d1c74: stur            x0, [fp, #-8]
    // 0x8d1c78: cbz             x0, #0x8d1d44
    // 0x8d1c7c: LoadField: r1 = r3->field_7b
    //     0x8d1c7c: ldur            w1, [x3, #0x7b]
    // 0x8d1c80: DecompressPointer r1
    //     0x8d1c80: add             x1, x1, HEAP, lsl #32
    // 0x8d1c84: r16 = Sentinel
    //     0x8d1c84: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1c88: cmp             w1, w16
    // 0x8d1c8c: b.eq            #0x8d247c
    // 0x8d1c90: r5 = LoadInt32Instr(r1)
    //     0x8d1c90: sbfx            x5, x1, #1, #0x1f
    //     0x8d1c94: tbz             w1, #0, #0x8d1c9c
    //     0x8d1c98: ldur            x5, [x1, #7]
    // 0x8d1c9c: mov             x1, x0
    // 0x8d1ca0: ubfx            x1, x1, #0, #0x20
    // 0x8d1ca4: sub             w6, w5, w1
    // 0x8d1ca8: and             x1, x6, x2
    // 0x8d1cac: LoadField: r5 = r3->field_3b
    //     0x8d1cac: ldur            w5, [x3, #0x3b]
    // 0x8d1cb0: DecompressPointer r5
    //     0x8d1cb0: add             x5, x5, HEAP, lsl #32
    // 0x8d1cb4: r16 = Sentinel
    //     0x8d1cb4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1cb8: cmp             w5, w16
    // 0x8d1cbc: b.eq            #0x8d2488
    // 0x8d1cc0: r6 = LoadInt32Instr(r5)
    //     0x8d1cc0: sbfx            x6, x5, #1, #0x1f
    //     0x8d1cc4: tbz             w5, #0, #0x8d1ccc
    //     0x8d1cc8: ldur            x6, [x5, #7]
    // 0x8d1ccc: sub             x5, x6, #0x106
    // 0x8d1cd0: ubfx            x1, x1, #0, #0x20
    // 0x8d1cd4: cmp             x1, x5
    // 0x8d1cd8: b.gt            #0x8d1d3c
    // 0x8d1cdc: LoadField: r1 = r3->field_93
    //     0x8d1cdc: ldur            w1, [x3, #0x93]
    // 0x8d1ce0: DecompressPointer r1
    //     0x8d1ce0: add             x1, x1, HEAP, lsl #32
    // 0x8d1ce4: r16 = Sentinel
    //     0x8d1ce4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1ce8: cmp             w1, w16
    // 0x8d1cec: b.eq            #0x8d2494
    // 0x8d1cf0: stp             x0, x3, [SP, #-0x10]!
    // 0x8d1cf4: r0 = _longestMatch()
    //     0x8d1cf4: bl              #0x8cd00c  ; [package:archive/src/zlib/deflate.dart] Deflate::_longestMatch
    // 0x8d1cf8: add             SP, SP, #0x10
    // 0x8d1cfc: mov             x2, x0
    // 0x8d1d00: r0 = BoxInt64Instr(r2)
    //     0x8d1d00: sbfiz           x0, x2, #1, #0x1f
    //     0x8d1d04: cmp             x2, x0, asr #1
    //     0x8d1d08: b.eq            #0x8d1d14
    //     0x8d1d0c: bl              #0xd69bb8
    //     0x8d1d10: stur            x2, [x0, #7]
    // 0x8d1d14: ldr             x2, [fp, #0x10]
    // 0x8d1d18: StoreField: r2->field_6f = r0
    //     0x8d1d18: stur            w0, [x2, #0x6f]
    //     0x8d1d1c: tbz             w0, #0, #0x8d1d38
    //     0x8d1d20: ldurb           w16, [x2, #-1]
    //     0x8d1d24: ldurb           w17, [x0, #-1]
    //     0x8d1d28: and             x16, x17, x16, lsr #2
    //     0x8d1d2c: tst             x16, HEAP, lsr #32
    //     0x8d1d30: b.eq            #0x8d1d38
    //     0x8d1d34: bl              #0xd6828c
    // 0x8d1d38: b               #0x8d1d48
    // 0x8d1d3c: mov             x2, x3
    // 0x8d1d40: b               #0x8d1d48
    // 0x8d1d44: mov             x2, x3
    // 0x8d1d48: LoadField: r0 = r2->field_6f
    //     0x8d1d48: ldur            w0, [x2, #0x6f]
    // 0x8d1d4c: DecompressPointer r0
    //     0x8d1d4c: add             x0, x0, HEAP, lsl #32
    // 0x8d1d50: r16 = Sentinel
    //     0x8d1d50: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1d54: cmp             w0, w16
    // 0x8d1d58: b.eq            #0x8d24a0
    // 0x8d1d5c: r1 = LoadInt32Instr(r0)
    //     0x8d1d5c: sbfx            x1, x0, #1, #0x1f
    //     0x8d1d60: tbz             w0, #0, #0x8d1d68
    //     0x8d1d64: ldur            x1, [x0, #7]
    // 0x8d1d68: cmp             x1, #3
    // 0x8d1d6c: b.lt            #0x8d2284
    // 0x8d1d70: LoadField: r0 = r2->field_7b
    //     0x8d1d70: ldur            w0, [x2, #0x7b]
    // 0x8d1d74: DecompressPointer r0
    //     0x8d1d74: add             x0, x0, HEAP, lsl #32
    // 0x8d1d78: r16 = Sentinel
    //     0x8d1d78: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1d7c: cmp             w0, w16
    // 0x8d1d80: b.eq            #0x8d24ac
    // 0x8d1d84: LoadField: r3 = r2->field_7f
    //     0x8d1d84: ldur            x3, [x2, #0x7f]
    // 0x8d1d88: r4 = LoadInt32Instr(r0)
    //     0x8d1d88: sbfx            x4, x0, #1, #0x1f
    //     0x8d1d8c: tbz             w0, #0, #0x8d1d94
    //     0x8d1d90: ldur            x4, [x0, #7]
    // 0x8d1d94: sub             x5, x4, x3
    // 0x8d1d98: sub             x3, x1, #3
    // 0x8d1d9c: r0 = BoxInt64Instr(r5)
    //     0x8d1d9c: sbfiz           x0, x5, #1, #0x1f
    //     0x8d1da0: cmp             x5, x0, asr #1
    //     0x8d1da4: b.eq            #0x8d1db0
    //     0x8d1da8: bl              #0xd69bb8
    //     0x8d1dac: stur            x5, [x0, #7]
    // 0x8d1db0: stp             x0, x2, [SP, #-0x10]!
    // 0x8d1db4: SaveReg r3
    //     0x8d1db4: str             x3, [SP, #-8]!
    // 0x8d1db8: r0 = _trTally()
    //     0x8d1db8: bl              #0x8d0b30  ; [package:archive/src/zlib/deflate.dart] Deflate::_trTally
    // 0x8d1dbc: add             SP, SP, #0x18
    // 0x8d1dc0: mov             x3, x0
    // 0x8d1dc4: ldr             x2, [fp, #0x10]
    // 0x8d1dc8: LoadField: r0 = r2->field_87
    //     0x8d1dc8: ldur            w0, [x2, #0x87]
    // 0x8d1dcc: DecompressPointer r0
    //     0x8d1dcc: add             x0, x0, HEAP, lsl #32
    // 0x8d1dd0: LoadField: r1 = r2->field_6f
    //     0x8d1dd0: ldur            w1, [x2, #0x6f]
    // 0x8d1dd4: DecompressPointer r1
    //     0x8d1dd4: add             x1, x1, HEAP, lsl #32
    // 0x8d1dd8: r4 = LoadInt32Instr(r0)
    //     0x8d1dd8: sbfx            x4, x0, #1, #0x1f
    //     0x8d1ddc: tbz             w0, #0, #0x8d1de4
    //     0x8d1de0: ldur            x4, [x0, #7]
    // 0x8d1de4: r5 = LoadInt32Instr(r1)
    //     0x8d1de4: sbfx            x5, x1, #1, #0x1f
    //     0x8d1de8: tbz             w1, #0, #0x8d1df0
    //     0x8d1dec: ldur            x5, [x1, #7]
    // 0x8d1df0: sub             x6, x4, x5
    // 0x8d1df4: r0 = BoxInt64Instr(r6)
    //     0x8d1df4: sbfiz           x0, x6, #1, #0x1f
    //     0x8d1df8: cmp             x6, x0, asr #1
    //     0x8d1dfc: b.eq            #0x8d1e08
    //     0x8d1e00: bl              #0xd69bb8
    //     0x8d1e04: stur            x6, [x0, #7]
    // 0x8d1e08: StoreField: r2->field_87 = r0
    //     0x8d1e08: stur            w0, [x2, #0x87]
    //     0x8d1e0c: tbz             w0, #0, #0x8d1e28
    //     0x8d1e10: ldurb           w16, [x2, #-1]
    //     0x8d1e14: ldurb           w17, [x0, #-1]
    //     0x8d1e18: and             x16, x17, x16, lsr #2
    //     0x8d1e1c: tst             x16, HEAP, lsr #32
    //     0x8d1e20: b.eq            #0x8d1e28
    //     0x8d1e24: bl              #0xd6828c
    // 0x8d1e28: r0 = LoadStaticField(0xa84)
    //     0x8d1e28: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x8d1e2c: ldr             x0, [x0, #0x1508]
    //     0x8d1e30: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1e34: cmp             w0, w16
    // 0x8d1e38: b.eq            #0x8d24b8
    // 0x8d1e3c: LoadField: r1 = r0->field_f
    //     0x8d1e3c: ldur            x1, [x0, #0xf]
    // 0x8d1e40: cmp             x5, x1
    // 0x8d1e44: b.gt            #0x8d2120
    // 0x8d1e48: cmp             x6, #3
    // 0x8d1e4c: b.lt            #0x8d2114
    // 0x8d1e50: sub             x4, x5, #1
    // 0x8d1e54: r0 = BoxInt64Instr(r4)
    //     0x8d1e54: sbfiz           x0, x4, #1, #0x1f
    //     0x8d1e58: cmp             x4, x0, asr #1
    //     0x8d1e5c: b.eq            #0x8d1e68
    //     0x8d1e60: bl              #0xd69bb8
    //     0x8d1e64: stur            x4, [x0, #7]
    // 0x8d1e68: StoreField: r2->field_6f = r0
    //     0x8d1e68: stur            w0, [x2, #0x6f]
    //     0x8d1e6c: tbz             w0, #0, #0x8d1e88
    //     0x8d1e70: ldurb           w16, [x2, #-1]
    //     0x8d1e74: ldurb           w17, [x0, #-1]
    //     0x8d1e78: and             x16, x17, x16, lsr #2
    //     0x8d1e7c: tst             x16, HEAP, lsr #32
    //     0x8d1e80: b.eq            #0x8d1e88
    //     0x8d1e84: bl              #0xd6828c
    // 0x8d1e88: mov             x5, x4
    // 0x8d1e8c: r6 = 255
    //     0x8d1e8c: mov             x6, #0xff
    // 0x8d1e90: r4 = 65535
    //     0x8d1e90: mov             x4, #0xffff
    // 0x8d1e94: CheckStackOverflow
    //     0x8d1e94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d1e98: cmp             SP, x16
    //     0x8d1e9c: b.ls            #0x8d24c4
    // 0x8d1ea0: LoadField: r0 = r2->field_7b
    //     0x8d1ea0: ldur            w0, [x2, #0x7b]
    // 0x8d1ea4: DecompressPointer r0
    //     0x8d1ea4: add             x0, x0, HEAP, lsl #32
    // 0x8d1ea8: r1 = LoadInt32Instr(r0)
    //     0x8d1ea8: sbfx            x1, x0, #1, #0x1f
    //     0x8d1eac: tbz             w0, #0, #0x8d1eb4
    //     0x8d1eb0: ldur            x1, [x0, #7]
    // 0x8d1eb4: add             x7, x1, #1
    // 0x8d1eb8: r0 = BoxInt64Instr(r7)
    //     0x8d1eb8: sbfiz           x0, x7, #1, #0x1f
    //     0x8d1ebc: cmp             x7, x0, asr #1
    //     0x8d1ec0: b.eq            #0x8d1ecc
    //     0x8d1ec4: bl              #0xd69bb8
    //     0x8d1ec8: stur            x7, [x0, #7]
    // 0x8d1ecc: StoreField: r2->field_7b = r0
    //     0x8d1ecc: stur            w0, [x2, #0x7b]
    //     0x8d1ed0: tbz             w0, #0, #0x8d1eec
    //     0x8d1ed4: ldurb           w16, [x2, #-1]
    //     0x8d1ed8: ldurb           w17, [x0, #-1]
    //     0x8d1edc: and             x16, x17, x16, lsr #2
    //     0x8d1ee0: tst             x16, HEAP, lsr #32
    //     0x8d1ee4: b.eq            #0x8d1eec
    //     0x8d1ee8: bl              #0xd6828c
    // 0x8d1eec: LoadField: r0 = r2->field_57
    //     0x8d1eec: ldur            w0, [x2, #0x57]
    // 0x8d1ef0: DecompressPointer r0
    //     0x8d1ef0: add             x0, x0, HEAP, lsl #32
    // 0x8d1ef4: r16 = Sentinel
    //     0x8d1ef4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1ef8: cmp             w0, w16
    // 0x8d1efc: b.eq            #0x8d24cc
    // 0x8d1f00: LoadField: r1 = r2->field_67
    //     0x8d1f00: ldur            w1, [x2, #0x67]
    // 0x8d1f04: DecompressPointer r1
    //     0x8d1f04: add             x1, x1, HEAP, lsl #32
    // 0x8d1f08: r16 = Sentinel
    //     0x8d1f08: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1f0c: cmp             w1, w16
    // 0x8d1f10: b.eq            #0x8d24d8
    // 0x8d1f14: r8 = LoadInt32Instr(r0)
    //     0x8d1f14: sbfx            x8, x0, #1, #0x1f
    //     0x8d1f18: tbz             w0, #0, #0x8d1f20
    //     0x8d1f1c: ldur            x8, [x0, #7]
    // 0x8d1f20: r0 = LoadInt32Instr(r1)
    //     0x8d1f20: sbfx            x0, x1, #1, #0x1f
    //     0x8d1f24: tbz             w1, #0, #0x8d1f2c
    //     0x8d1f28: ldur            x0, [x1, #7]
    // 0x8d1f2c: cmp             x0, #0x3f
    // 0x8d1f30: b.hi            #0x8d24e4
    // 0x8d1f34: lsl             x10, x8, x0
    // 0x8d1f38: LoadField: r8 = r2->field_47
    //     0x8d1f38: ldur            w8, [x2, #0x47]
    // 0x8d1f3c: DecompressPointer r8
    //     0x8d1f3c: add             x8, x8, HEAP, lsl #32
    // 0x8d1f40: r16 = Sentinel
    //     0x8d1f40: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1f44: cmp             w8, w16
    // 0x8d1f48: b.eq            #0x8d2518
    // 0x8d1f4c: add             x9, x7, #2
    // 0x8d1f50: LoadField: r0 = r8->field_13
    //     0x8d1f50: ldur            w0, [x8, #0x13]
    // 0x8d1f54: DecompressPointer r0
    //     0x8d1f54: add             x0, x0, HEAP, lsl #32
    // 0x8d1f58: r1 = LoadInt32Instr(r0)
    //     0x8d1f58: sbfx            x1, x0, #1, #0x1f
    // 0x8d1f5c: mov             x0, x1
    // 0x8d1f60: mov             x1, x9
    // 0x8d1f64: cmp             x1, x0
    // 0x8d1f68: b.hs            #0x8d2524
    // 0x8d1f6c: ArrayLoad: r0 = r8[r9]  ; TypedUnsigned_1
    //     0x8d1f6c: add             x16, x8, x9
    //     0x8d1f70: ldrb            w0, [x16, #0x17]
    // 0x8d1f74: ubfx            x0, x0, #0, #0x20
    // 0x8d1f78: and             x1, x0, x6
    // 0x8d1f7c: ubfx            x1, x1, #0, #0x20
    // 0x8d1f80: eor             x0, x10, x1
    // 0x8d1f84: LoadField: r1 = r2->field_63
    //     0x8d1f84: ldur            w1, [x2, #0x63]
    // 0x8d1f88: DecompressPointer r1
    //     0x8d1f88: add             x1, x1, HEAP, lsl #32
    // 0x8d1f8c: r16 = Sentinel
    //     0x8d1f8c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1f90: cmp             w1, w16
    // 0x8d1f94: b.eq            #0x8d2528
    // 0x8d1f98: r8 = LoadInt32Instr(r1)
    //     0x8d1f98: sbfx            x8, x1, #1, #0x1f
    //     0x8d1f9c: tbz             w1, #0, #0x8d1fa4
    //     0x8d1fa0: ldur            x8, [x1, #7]
    // 0x8d1fa4: and             x10, x0, x8
    // 0x8d1fa8: r0 = BoxInt64Instr(r10)
    //     0x8d1fa8: sbfiz           x0, x10, #1, #0x1f
    //     0x8d1fac: cmp             x10, x0, asr #1
    //     0x8d1fb0: b.eq            #0x8d1fbc
    //     0x8d1fb4: bl              #0xd69bb8
    //     0x8d1fb8: stur            x10, [x0, #7]
    // 0x8d1fbc: StoreField: r2->field_57 = r0
    //     0x8d1fbc: stur            w0, [x2, #0x57]
    //     0x8d1fc0: tbz             w0, #0, #0x8d1fdc
    //     0x8d1fc4: ldurb           w16, [x2, #-1]
    //     0x8d1fc8: ldurb           w17, [x0, #-1]
    //     0x8d1fcc: and             x16, x17, x16, lsr #2
    //     0x8d1fd0: tst             x16, HEAP, lsr #32
    //     0x8d1fd4: b.eq            #0x8d1fdc
    //     0x8d1fd8: bl              #0xd6828c
    // 0x8d1fdc: LoadField: r8 = r2->field_53
    //     0x8d1fdc: ldur            w8, [x2, #0x53]
    // 0x8d1fe0: DecompressPointer r8
    //     0x8d1fe0: add             x8, x8, HEAP, lsl #32
    // 0x8d1fe4: r16 = Sentinel
    //     0x8d1fe4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d1fe8: cmp             w8, w16
    // 0x8d1fec: b.eq            #0x8d2534
    // 0x8d1ff0: LoadField: r0 = r8->field_13
    //     0x8d1ff0: ldur            w0, [x8, #0x13]
    // 0x8d1ff4: DecompressPointer r0
    //     0x8d1ff4: add             x0, x0, HEAP, lsl #32
    // 0x8d1ff8: r1 = LoadInt32Instr(r0)
    //     0x8d1ff8: sbfx            x1, x0, #1, #0x1f
    // 0x8d1ffc: mov             x0, x1
    // 0x8d2000: mov             x1, x10
    // 0x8d2004: cmp             x1, x0
    // 0x8d2008: b.hs            #0x8d2540
    // 0x8d200c: add             x16, x8, x10, lsl #1
    // 0x8d2010: ldurh           w11, [x16, #0x17]
    // 0x8d2014: mov             x0, x11
    // 0x8d2018: ubfx            x0, x0, #0, #0x20
    // 0x8d201c: and             x12, x0, x4
    // 0x8d2020: LoadField: r13 = r2->field_4f
    //     0x8d2020: ldur            w13, [x2, #0x4f]
    // 0x8d2024: DecompressPointer r13
    //     0x8d2024: add             x13, x13, HEAP, lsl #32
    // 0x8d2028: r16 = Sentinel
    //     0x8d2028: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d202c: cmp             w13, w16
    // 0x8d2030: b.eq            #0x8d2544
    // 0x8d2034: LoadField: r0 = r2->field_43
    //     0x8d2034: ldur            w0, [x2, #0x43]
    // 0x8d2038: DecompressPointer r0
    //     0x8d2038: add             x0, x0, HEAP, lsl #32
    // 0x8d203c: r16 = Sentinel
    //     0x8d203c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d2040: cmp             w0, w16
    // 0x8d2044: b.eq            #0x8d2550
    // 0x8d2048: r1 = LoadInt32Instr(r0)
    //     0x8d2048: sbfx            x1, x0, #1, #0x1f
    //     0x8d204c: tbz             w0, #0, #0x8d2054
    //     0x8d2050: ldur            x1, [x0, #7]
    // 0x8d2054: and             x9, x7, x1
    // 0x8d2058: LoadField: r0 = r13->field_13
    //     0x8d2058: ldur            w0, [x13, #0x13]
    // 0x8d205c: DecompressPointer r0
    //     0x8d205c: add             x0, x0, HEAP, lsl #32
    // 0x8d2060: r1 = LoadInt32Instr(r0)
    //     0x8d2060: sbfx            x1, x0, #1, #0x1f
    // 0x8d2064: mov             x0, x1
    // 0x8d2068: mov             x1, x9
    // 0x8d206c: cmp             x1, x0
    // 0x8d2070: b.hs            #0x8d255c
    // 0x8d2074: LoadField: r0 = r13->field_7
    //     0x8d2074: ldur            x0, [x13, #7]
    // 0x8d2078: add             x1, x0, x9, lsl #1
    // 0x8d207c: strh            w11, [x1]
    // 0x8d2080: LoadField: r0 = r8->field_7
    //     0x8d2080: ldur            x0, [x8, #7]
    // 0x8d2084: add             x1, x0, x10, lsl #1
    // 0x8d2088: strh            w7, [x1]
    // 0x8d208c: sub             x8, x5, #1
    // 0x8d2090: r0 = BoxInt64Instr(r8)
    //     0x8d2090: sbfiz           x0, x8, #1, #0x1f
    //     0x8d2094: cmp             x8, x0, asr #1
    //     0x8d2098: b.eq            #0x8d20a4
    //     0x8d209c: bl              #0xd69bb8
    //     0x8d20a0: stur            x8, [x0, #7]
    // 0x8d20a4: StoreField: r2->field_6f = r0
    //     0x8d20a4: stur            w0, [x2, #0x6f]
    //     0x8d20a8: tbz             w0, #0, #0x8d20c4
    //     0x8d20ac: ldurb           w16, [x2, #-1]
    //     0x8d20b0: ldurb           w17, [x0, #-1]
    //     0x8d20b4: and             x16, x17, x16, lsr #2
    //     0x8d20b8: tst             x16, HEAP, lsr #32
    //     0x8d20bc: b.eq            #0x8d20c4
    //     0x8d20c0: bl              #0xd6828c
    // 0x8d20c4: cbz             x8, #0x8d20d0
    // 0x8d20c8: mov             x5, x8
    // 0x8d20cc: b               #0x8d1e94
    // 0x8d20d0: add             x5, x7, #1
    // 0x8d20d4: r0 = BoxInt64Instr(r5)
    //     0x8d20d4: sbfiz           x0, x5, #1, #0x1f
    //     0x8d20d8: cmp             x5, x0, asr #1
    //     0x8d20dc: b.eq            #0x8d20e8
    //     0x8d20e0: bl              #0xd69bb8
    //     0x8d20e4: stur            x5, [x0, #7]
    // 0x8d20e8: StoreField: r2->field_7b = r0
    //     0x8d20e8: stur            w0, [x2, #0x7b]
    //     0x8d20ec: tbz             w0, #0, #0x8d2108
    //     0x8d20f0: ldurb           w16, [x2, #-1]
    //     0x8d20f4: ldurb           w17, [x0, #-1]
    //     0x8d20f8: and             x16, x17, x16, lsr #2
    //     0x8d20fc: tst             x16, HEAP, lsr #32
    //     0x8d2100: b.eq            #0x8d2108
    //     0x8d2104: bl              #0xd6828c
    // 0x8d2108: ubfx            x12, x12, #0, #0x20
    // 0x8d210c: mov             x0, x12
    // 0x8d2110: b               #0x8d2278
    // 0x8d2114: r6 = 255
    //     0x8d2114: mov             x6, #0xff
    // 0x8d2118: r4 = 65535
    //     0x8d2118: mov             x4, #0xffff
    // 0x8d211c: b               #0x8d2128
    // 0x8d2120: r6 = 255
    //     0x8d2120: mov             x6, #0xff
    // 0x8d2124: r4 = 65535
    //     0x8d2124: mov             x4, #0xffff
    // 0x8d2128: LoadField: r0 = r2->field_7b
    //     0x8d2128: ldur            w0, [x2, #0x7b]
    // 0x8d212c: DecompressPointer r0
    //     0x8d212c: add             x0, x0, HEAP, lsl #32
    // 0x8d2130: r1 = LoadInt32Instr(r0)
    //     0x8d2130: sbfx            x1, x0, #1, #0x1f
    //     0x8d2134: tbz             w0, #0, #0x8d213c
    //     0x8d2138: ldur            x1, [x0, #7]
    // 0x8d213c: add             x7, x1, x5
    // 0x8d2140: r0 = BoxInt64Instr(r7)
    //     0x8d2140: sbfiz           x0, x7, #1, #0x1f
    //     0x8d2144: cmp             x7, x0, asr #1
    //     0x8d2148: b.eq            #0x8d2154
    //     0x8d214c: bl              #0xd69bb8
    //     0x8d2150: stur            x7, [x0, #7]
    // 0x8d2154: StoreField: r2->field_7b = r0
    //     0x8d2154: stur            w0, [x2, #0x7b]
    //     0x8d2158: tbz             w0, #0, #0x8d2174
    //     0x8d215c: ldurb           w16, [x2, #-1]
    //     0x8d2160: ldurb           w17, [x0, #-1]
    //     0x8d2164: and             x16, x17, x16, lsr #2
    //     0x8d2168: tst             x16, HEAP, lsr #32
    //     0x8d216c: b.eq            #0x8d2174
    //     0x8d2170: bl              #0xd6828c
    // 0x8d2174: StoreField: r2->field_6f = rZR
    //     0x8d2174: stur            wzr, [x2, #0x6f]
    // 0x8d2178: LoadField: r5 = r2->field_47
    //     0x8d2178: ldur            w5, [x2, #0x47]
    // 0x8d217c: DecompressPointer r5
    //     0x8d217c: add             x5, x5, HEAP, lsl #32
    // 0x8d2180: r16 = Sentinel
    //     0x8d2180: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d2184: cmp             w5, w16
    // 0x8d2188: b.eq            #0x8d2560
    // 0x8d218c: LoadField: r0 = r5->field_13
    //     0x8d218c: ldur            w0, [x5, #0x13]
    // 0x8d2190: DecompressPointer r0
    //     0x8d2190: add             x0, x0, HEAP, lsl #32
    // 0x8d2194: r8 = LoadInt32Instr(r0)
    //     0x8d2194: sbfx            x8, x0, #1, #0x1f
    // 0x8d2198: mov             x0, x8
    // 0x8d219c: mov             x1, x7
    // 0x8d21a0: cmp             x1, x0
    // 0x8d21a4: b.hs            #0x8d256c
    // 0x8d21a8: ArrayLoad: r0 = r5[r7]  ; TypedUnsigned_1
    //     0x8d21a8: add             x16, x5, x7
    //     0x8d21ac: ldrb            w0, [x16, #0x17]
    // 0x8d21b0: ubfx            x0, x0, #0, #0x20
    // 0x8d21b4: and             x1, x0, x6
    // 0x8d21b8: lsl             w0, w1, #1
    // 0x8d21bc: StoreField: r2->field_57 = r0
    //     0x8d21bc: stur            w0, [x2, #0x57]
    // 0x8d21c0: LoadField: r0 = r2->field_67
    //     0x8d21c0: ldur            w0, [x2, #0x67]
    // 0x8d21c4: DecompressPointer r0
    //     0x8d21c4: add             x0, x0, HEAP, lsl #32
    // 0x8d21c8: r16 = Sentinel
    //     0x8d21c8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d21cc: cmp             w0, w16
    // 0x8d21d0: b.eq            #0x8d2570
    // 0x8d21d4: r9 = LoadInt32Instr(r0)
    //     0x8d21d4: sbfx            x9, x0, #1, #0x1f
    //     0x8d21d8: tbz             w0, #0, #0x8d21e0
    //     0x8d21dc: ldur            x9, [x0, #7]
    // 0x8d21e0: ubfx            x1, x1, #0, #0x20
    // 0x8d21e4: cmp             x9, #0x3f
    // 0x8d21e8: b.hi            #0x8d257c
    // 0x8d21ec: lsl             x10, x1, x9
    // 0x8d21f0: add             x9, x7, #1
    // 0x8d21f4: mov             x0, x8
    // 0x8d21f8: mov             x1, x9
    // 0x8d21fc: cmp             x1, x0
    // 0x8d2200: b.hs            #0x8d25b4
    // 0x8d2204: ArrayLoad: r0 = r5[r9]  ; TypedUnsigned_1
    //     0x8d2204: add             x16, x5, x9
    //     0x8d2208: ldrb            w0, [x16, #0x17]
    // 0x8d220c: ubfx            x0, x0, #0, #0x20
    // 0x8d2210: and             x1, x0, x6
    // 0x8d2214: ubfx            x1, x1, #0, #0x20
    // 0x8d2218: eor             x0, x10, x1
    // 0x8d221c: LoadField: r1 = r2->field_63
    //     0x8d221c: ldur            w1, [x2, #0x63]
    // 0x8d2220: DecompressPointer r1
    //     0x8d2220: add             x1, x1, HEAP, lsl #32
    // 0x8d2224: r16 = Sentinel
    //     0x8d2224: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d2228: cmp             w1, w16
    // 0x8d222c: b.eq            #0x8d25b8
    // 0x8d2230: r5 = LoadInt32Instr(r1)
    //     0x8d2230: sbfx            x5, x1, #1, #0x1f
    //     0x8d2234: tbz             w1, #0, #0x8d223c
    //     0x8d2238: ldur            x5, [x1, #7]
    // 0x8d223c: and             x7, x0, x5
    // 0x8d2240: r0 = BoxInt64Instr(r7)
    //     0x8d2240: sbfiz           x0, x7, #1, #0x1f
    //     0x8d2244: cmp             x7, x0, asr #1
    //     0x8d2248: b.eq            #0x8d2254
    //     0x8d224c: bl              #0xd69bb8
    //     0x8d2250: stur            x7, [x0, #7]
    // 0x8d2254: StoreField: r2->field_57 = r0
    //     0x8d2254: stur            w0, [x2, #0x57]
    //     0x8d2258: tbz             w0, #0, #0x8d2274
    //     0x8d225c: ldurb           w16, [x2, #-1]
    //     0x8d2260: ldurb           w17, [x0, #-1]
    //     0x8d2264: and             x16, x17, x16, lsr #2
    //     0x8d2268: tst             x16, HEAP, lsr #32
    //     0x8d226c: b.eq            #0x8d2274
    //     0x8d2270: bl              #0xd6828c
    // 0x8d2274: ldur            x0, [fp, #-8]
    // 0x8d2278: mov             x1, x0
    // 0x8d227c: mov             x0, x3
    // 0x8d2280: b               #0x8d23a4
    // 0x8d2284: r6 = 255
    //     0x8d2284: mov             x6, #0xff
    // 0x8d2288: r4 = 65535
    //     0x8d2288: mov             x4, #0xffff
    // 0x8d228c: LoadField: r3 = r2->field_47
    //     0x8d228c: ldur            w3, [x2, #0x47]
    // 0x8d2290: DecompressPointer r3
    //     0x8d2290: add             x3, x3, HEAP, lsl #32
    // 0x8d2294: r16 = Sentinel
    //     0x8d2294: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d2298: cmp             w3, w16
    // 0x8d229c: b.eq            #0x8d25c4
    // 0x8d22a0: LoadField: r0 = r2->field_7b
    //     0x8d22a0: ldur            w0, [x2, #0x7b]
    // 0x8d22a4: DecompressPointer r0
    //     0x8d22a4: add             x0, x0, HEAP, lsl #32
    // 0x8d22a8: r16 = Sentinel
    //     0x8d22a8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d22ac: cmp             w0, w16
    // 0x8d22b0: b.eq            #0x8d25d0
    // 0x8d22b4: LoadField: r1 = r3->field_13
    //     0x8d22b4: ldur            w1, [x3, #0x13]
    // 0x8d22b8: DecompressPointer r1
    //     0x8d22b8: add             x1, x1, HEAP, lsl #32
    // 0x8d22bc: r5 = LoadInt32Instr(r0)
    //     0x8d22bc: sbfx            x5, x0, #1, #0x1f
    //     0x8d22c0: tbz             w0, #0, #0x8d22c8
    //     0x8d22c4: ldur            x5, [x0, #7]
    // 0x8d22c8: r0 = LoadInt32Instr(r1)
    //     0x8d22c8: sbfx            x0, x1, #1, #0x1f
    // 0x8d22cc: mov             x1, x5
    // 0x8d22d0: cmp             x1, x0
    // 0x8d22d4: b.hs            #0x8d25dc
    // 0x8d22d8: ArrayLoad: r0 = r3[r5]  ; TypedUnsigned_1
    //     0x8d22d8: add             x16, x3, x5
    //     0x8d22dc: ldrb            w0, [x16, #0x17]
    // 0x8d22e0: ubfx            x0, x0, #0, #0x20
    // 0x8d22e4: and             x1, x0, x6
    // 0x8d22e8: ubfx            x1, x1, #0, #0x20
    // 0x8d22ec: stp             xzr, x2, [SP, #-0x10]!
    // 0x8d22f0: SaveReg r1
    //     0x8d22f0: str             x1, [SP, #-8]!
    // 0x8d22f4: r0 = _trTally()
    //     0x8d22f4: bl              #0x8d0b30  ; [package:archive/src/zlib/deflate.dart] Deflate::_trTally
    // 0x8d22f8: add             SP, SP, #0x18
    // 0x8d22fc: mov             x3, x0
    // 0x8d2300: ldr             x2, [fp, #0x10]
    // 0x8d2304: LoadField: r0 = r2->field_87
    //     0x8d2304: ldur            w0, [x2, #0x87]
    // 0x8d2308: DecompressPointer r0
    //     0x8d2308: add             x0, x0, HEAP, lsl #32
    // 0x8d230c: r1 = LoadInt32Instr(r0)
    //     0x8d230c: sbfx            x1, x0, #1, #0x1f
    //     0x8d2310: tbz             w0, #0, #0x8d2318
    //     0x8d2314: ldur            x1, [x0, #7]
    // 0x8d2318: sub             x4, x1, #1
    // 0x8d231c: r0 = BoxInt64Instr(r4)
    //     0x8d231c: sbfiz           x0, x4, #1, #0x1f
    //     0x8d2320: cmp             x4, x0, asr #1
    //     0x8d2324: b.eq            #0x8d2330
    //     0x8d2328: bl              #0xd69bb8
    //     0x8d232c: stur            x4, [x0, #7]
    // 0x8d2330: StoreField: r2->field_87 = r0
    //     0x8d2330: stur            w0, [x2, #0x87]
    //     0x8d2334: tbz             w0, #0, #0x8d2350
    //     0x8d2338: ldurb           w16, [x2, #-1]
    //     0x8d233c: ldurb           w17, [x0, #-1]
    //     0x8d2340: and             x16, x17, x16, lsr #2
    //     0x8d2344: tst             x16, HEAP, lsr #32
    //     0x8d2348: b.eq            #0x8d2350
    //     0x8d234c: bl              #0xd6828c
    // 0x8d2350: LoadField: r0 = r2->field_7b
    //     0x8d2350: ldur            w0, [x2, #0x7b]
    // 0x8d2354: DecompressPointer r0
    //     0x8d2354: add             x0, x0, HEAP, lsl #32
    // 0x8d2358: r1 = LoadInt32Instr(r0)
    //     0x8d2358: sbfx            x1, x0, #1, #0x1f
    //     0x8d235c: tbz             w0, #0, #0x8d2364
    //     0x8d2360: ldur            x1, [x0, #7]
    // 0x8d2364: add             x4, x1, #1
    // 0x8d2368: r0 = BoxInt64Instr(r4)
    //     0x8d2368: sbfiz           x0, x4, #1, #0x1f
    //     0x8d236c: cmp             x4, x0, asr #1
    //     0x8d2370: b.eq            #0x8d237c
    //     0x8d2374: bl              #0xd69bb8
    //     0x8d2378: stur            x4, [x0, #7]
    // 0x8d237c: StoreField: r2->field_7b = r0
    //     0x8d237c: stur            w0, [x2, #0x7b]
    //     0x8d2380: tbz             w0, #0, #0x8d239c
    //     0x8d2384: ldurb           w16, [x2, #-1]
    //     0x8d2388: ldurb           w17, [x0, #-1]
    //     0x8d238c: and             x16, x17, x16, lsr #2
    //     0x8d2390: tst             x16, HEAP, lsr #32
    //     0x8d2394: b.eq            #0x8d239c
    //     0x8d2398: bl              #0xd6828c
    // 0x8d239c: ldur            x1, [fp, #-8]
    // 0x8d23a0: mov             x0, x3
    // 0x8d23a4: stur            x1, [fp, #-8]
    // 0x8d23a8: tbnz            w0, #4, #0x8d23bc
    // 0x8d23ac: r16 = false
    //     0x8d23ac: add             x16, NULL, #0x30  ; false
    // 0x8d23b0: stp             x16, x2, [SP, #-0x10]!
    // 0x8d23b4: r0 = _flushBlockOnly()
    //     0x8d23b4: bl              #0x8cd6d8  ; [package:archive/src/zlib/deflate.dart] Deflate::_flushBlockOnly
    // 0x8d23b8: add             SP, SP, #0x10
    // 0x8d23bc: ldur            x1, [fp, #-8]
    // 0x8d23c0: b               #0x8d19e4
    // 0x8d23c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d23c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d23c8: b               #0x8d19e0
    // 0x8d23cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d23cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d23d0: b               #0x8d19f8
    // 0x8d23d4: r9 = _lookAhead
    //     0x8d23d4: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a28] Field <Deflate._lookAhead@60040000>: late (offset: 0x88)
    //     0x8d23d8: ldr             x9, [x9, #0xa28]
    // 0x8d23dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d23dc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d23e0: r9 = _insertHash
    //     0x8d23e0: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a60] Field <Deflate._insertHash@60040000>: late (offset: 0x58)
    //     0x8d23e4: ldr             x9, [x9, #0xa60]
    // 0x8d23e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d23e8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d23ec: r9 = _hashShift
    //     0x8d23ec: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a68] Field <Deflate._hashShift@60040000>: late (offset: 0x68)
    //     0x8d23f0: ldr             x9, [x9, #0xa68]
    // 0x8d23f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d23f4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d23f8: tbnz            x0, #0x3f, #0x8d2404
    // 0x8d23fc: mov             x6, xzr
    // 0x8d2400: b               #0x8d1ae8
    // 0x8d2404: str             x0, [THR, #0xc0]  ; THR::
    // 0x8d2408: stp             x4, x5, [SP, #-0x10]!
    // 0x8d240c: stp             x2, x3, [SP, #-0x10]!
    // 0x8d2410: SaveReg r0
    //     0x8d2410: str             x0, [SP, #-8]!
    // 0x8d2414: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x8d2418: r4 = 0
    //     0x8d2418: mov             x4, #0
    // 0x8d241c: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8d2420: blr             lr
    // 0x8d2424: brk             #0
    // 0x8d2428: r9 = _window
    //     0x8d2428: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a38] Field <Deflate._window@60040000>: late (offset: 0x48)
    //     0x8d242c: ldr             x9, [x9, #0xa38]
    // 0x8d2430: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d2430: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d2434: r9 = _strStart
    //     0x8d2434: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a58] Field <Deflate._strStart@60040000>: late (offset: 0x7c)
    //     0x8d2438: ldr             x9, [x9, #0xa58]
    // 0x8d243c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d243c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d2440: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d2440: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d2444: r9 = _hashMask
    //     0x8d2444: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a70] Field <Deflate._hashMask@60040000>: late (offset: 0x64)
    //     0x8d2448: ldr             x9, [x9, #0xa70]
    // 0x8d244c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d244c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d2450: r9 = _head
    //     0x8d2450: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a78] Field <Deflate._head@60040000>: late (offset: 0x54)
    //     0x8d2454: ldr             x9, [x9, #0xa78]
    // 0x8d2458: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d2458: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d245c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d245c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d2460: r9 = _prev
    //     0x8d2460: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a80] Field <Deflate._prev@60040000>: late (offset: 0x50)
    //     0x8d2464: ldr             x9, [x9, #0xa80]
    // 0x8d2468: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d2468: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d246c: r9 = _windowMask
    //     0x8d246c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a88] Field <Deflate._windowMask@60040000>: late (offset: 0x44)
    //     0x8d2470: ldr             x9, [x9, #0xa88]
    // 0x8d2474: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d2474: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d2478: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d2478: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d247c: r9 = _strStart
    //     0x8d247c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a58] Field <Deflate._strStart@60040000>: late (offset: 0x7c)
    //     0x8d2480: ldr             x9, [x9, #0xa58]
    // 0x8d2484: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d2484: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d2488: r9 = _windowSize
    //     0x8d2488: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a98] Field <Deflate._windowSize@60040000>: late (offset: 0x3c)
    //     0x8d248c: ldr             x9, [x9, #0xa98]
    // 0x8d2490: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d2490: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d2494: r9 = _strategy
    //     0x8d2494: add             x9, PP, #0x34, lsl #12  ; [pp+0x34aa0] Field <Deflate._strategy@60040000>: late (offset: 0x94)
    //     0x8d2498: ldr             x9, [x9, #0xaa0]
    // 0x8d249c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d249c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d24a0: r9 = _matchLength
    //     0x8d24a0: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a90] Field <Deflate._matchLength@60040000>: late (offset: 0x70)
    //     0x8d24a4: ldr             x9, [x9, #0xa90]
    // 0x8d24a8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d24a8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d24ac: r9 = _strStart
    //     0x8d24ac: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a58] Field <Deflate._strStart@60040000>: late (offset: 0x7c)
    //     0x8d24b0: ldr             x9, [x9, #0xa58]
    // 0x8d24b4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d24b4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d24b8: r9 = _config
    //     0x8d24b8: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a30] Field <Deflate._config@60040000>: static late (offset: 0xa84)
    //     0x8d24bc: ldr             x9, [x9, #0xa30]
    // 0x8d24c0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d24c0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d24c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d24c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d24c8: b               #0x8d1ea0
    // 0x8d24cc: r9 = _insertHash
    //     0x8d24cc: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a60] Field <Deflate._insertHash@60040000>: late (offset: 0x58)
    //     0x8d24d0: ldr             x9, [x9, #0xa60]
    // 0x8d24d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d24d4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d24d8: r9 = _hashShift
    //     0x8d24d8: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a68] Field <Deflate._hashShift@60040000>: late (offset: 0x68)
    //     0x8d24dc: ldr             x9, [x9, #0xa68]
    // 0x8d24e0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d24e0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d24e4: tbnz            x0, #0x3f, #0x8d24f0
    // 0x8d24e8: mov             x10, xzr
    // 0x8d24ec: b               #0x8d1f38
    // 0x8d24f0: str             x0, [THR, #0xc0]  ; THR::
    // 0x8d24f4: stp             x7, x8, [SP, #-0x10]!
    // 0x8d24f8: stp             x5, x6, [SP, #-0x10]!
    // 0x8d24fc: stp             x3, x4, [SP, #-0x10]!
    // 0x8d2500: stp             x0, x2, [SP, #-0x10]!
    // 0x8d2504: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x8d2508: r4 = 0
    //     0x8d2508: mov             x4, #0
    // 0x8d250c: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8d2510: blr             lr
    // 0x8d2514: brk             #0
    // 0x8d2518: r9 = _window
    //     0x8d2518: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a38] Field <Deflate._window@60040000>: late (offset: 0x48)
    //     0x8d251c: ldr             x9, [x9, #0xa38]
    // 0x8d2520: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d2520: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d2524: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d2524: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d2528: r9 = _hashMask
    //     0x8d2528: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a70] Field <Deflate._hashMask@60040000>: late (offset: 0x64)
    //     0x8d252c: ldr             x9, [x9, #0xa70]
    // 0x8d2530: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d2530: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d2534: r9 = _head
    //     0x8d2534: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a78] Field <Deflate._head@60040000>: late (offset: 0x54)
    //     0x8d2538: ldr             x9, [x9, #0xa78]
    // 0x8d253c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d253c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d2540: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d2540: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d2544: r9 = _prev
    //     0x8d2544: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a80] Field <Deflate._prev@60040000>: late (offset: 0x50)
    //     0x8d2548: ldr             x9, [x9, #0xa80]
    // 0x8d254c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d254c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d2550: r9 = _windowMask
    //     0x8d2550: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a88] Field <Deflate._windowMask@60040000>: late (offset: 0x44)
    //     0x8d2554: ldr             x9, [x9, #0xa88]
    // 0x8d2558: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d2558: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d255c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d255c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d2560: r9 = _window
    //     0x8d2560: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a38] Field <Deflate._window@60040000>: late (offset: 0x48)
    //     0x8d2564: ldr             x9, [x9, #0xa38]
    // 0x8d2568: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d2568: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d256c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d256c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d2570: r9 = _hashShift
    //     0x8d2570: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a68] Field <Deflate._hashShift@60040000>: late (offset: 0x68)
    //     0x8d2574: ldr             x9, [x9, #0xa68]
    // 0x8d2578: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d2578: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d257c: tbnz            x9, #0x3f, #0x8d2588
    // 0x8d2580: mov             x10, xzr
    // 0x8d2584: b               #0x8d21f0
    // 0x8d2588: str             x9, [THR, #0xc0]  ; THR::
    // 0x8d258c: stp             x8, x9, [SP, #-0x10]!
    // 0x8d2590: stp             x6, x7, [SP, #-0x10]!
    // 0x8d2594: stp             x4, x5, [SP, #-0x10]!
    // 0x8d2598: stp             x2, x3, [SP, #-0x10]!
    // 0x8d259c: SaveReg r1
    //     0x8d259c: str             x1, [SP, #-8]!
    // 0x8d25a0: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x8d25a4: r4 = 0
    //     0x8d25a4: mov             x4, #0
    // 0x8d25a8: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8d25ac: blr             lr
    // 0x8d25b0: brk             #0
    // 0x8d25b4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d25b4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d25b8: r9 = _hashMask
    //     0x8d25b8: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a70] Field <Deflate._hashMask@60040000>: late (offset: 0x64)
    //     0x8d25bc: ldr             x9, [x9, #0xa70]
    // 0x8d25c0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d25c0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d25c4: r9 = _window
    //     0x8d25c4: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a38] Field <Deflate._window@60040000>: late (offset: 0x48)
    //     0x8d25c8: ldr             x9, [x9, #0xa38]
    // 0x8d25cc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d25cc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d25d0: r9 = _strStart
    //     0x8d25d0: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a58] Field <Deflate._strStart@60040000>: late (offset: 0x7c)
    //     0x8d25d4: ldr             x9, [x9, #0xa58]
    // 0x8d25d8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d25d8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d25dc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d25dc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _deflateStored(/* No info */) {
    // ** addr: 0x8d25e0, size: 0x2c0
    // 0x8d25e0: EnterFrame
    //     0x8d25e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8d25e4: mov             fp, SP
    // 0x8d25e8: AllocStack(0x8)
    //     0x8d25e8: sub             SP, SP, #8
    // 0x8d25ec: CheckStackOverflow
    //     0x8d25ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d25f0: cmp             SP, x16
    //     0x8d25f4: b.ls            #0x8d2854
    // 0x8d25f8: ldr             x0, [fp, #0x10]
    // 0x8d25fc: LoadField: r1 = r0->field_27
    //     0x8d25fc: ldur            w1, [x0, #0x27]
    // 0x8d2600: DecompressPointer r1
    //     0x8d2600: add             x1, x1, HEAP, lsl #32
    // 0x8d2604: r16 = Sentinel
    //     0x8d2604: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d2608: cmp             w1, w16
    // 0x8d260c: b.eq            #0x8d285c
    // 0x8d2610: r2 = LoadInt32Instr(r1)
    //     0x8d2610: sbfx            x2, x1, #1, #0x1f
    //     0x8d2614: tbz             w1, #0, #0x8d261c
    //     0x8d2618: ldur            x2, [x1, #7]
    // 0x8d261c: sub             x1, x2, #5
    // 0x8d2620: r17 = 65535
    //     0x8d2620: mov             x17, #0xffff
    // 0x8d2624: cmp             x1, x17
    // 0x8d2628: b.lt            #0x8d2630
    // 0x8d262c: r1 = 65535
    //     0x8d262c: mov             x1, #0xffff
    // 0x8d2630: stur            x1, [fp, #-8]
    // 0x8d2634: CheckStackOverflow
    //     0x8d2634: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d2638: cmp             SP, x16
    //     0x8d263c: b.ls            #0x8d2868
    // 0x8d2640: LoadField: r2 = r0->field_87
    //     0x8d2640: ldur            w2, [x0, #0x87]
    // 0x8d2644: DecompressPointer r2
    //     0x8d2644: add             x2, x2, HEAP, lsl #32
    // 0x8d2648: r16 = Sentinel
    //     0x8d2648: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d264c: cmp             w2, w16
    // 0x8d2650: b.eq            #0x8d2870
    // 0x8d2654: r3 = LoadInt32Instr(r2)
    //     0x8d2654: sbfx            x3, x2, #1, #0x1f
    //     0x8d2658: tbz             w2, #0, #0x8d2660
    //     0x8d265c: ldur            x3, [x2, #7]
    // 0x8d2660: cmp             x3, #1
    // 0x8d2664: b.gt            #0x8d26c4
    // 0x8d2668: SaveReg r0
    //     0x8d2668: str             x0, [SP, #-8]!
    // 0x8d266c: r0 = _fillWindow()
    //     0x8d266c: bl              #0x8d1120  ; [package:archive/src/zlib/deflate.dart] Deflate::_fillWindow
    // 0x8d2670: add             SP, SP, #8
    // 0x8d2674: ldr             x3, [fp, #0x10]
    // 0x8d2678: LoadField: r0 = r3->field_87
    //     0x8d2678: ldur            w0, [x3, #0x87]
    // 0x8d267c: DecompressPointer r0
    //     0x8d267c: add             x0, x0, HEAP, lsl #32
    // 0x8d2680: r1 = LoadInt32Instr(r0)
    //     0x8d2680: sbfx            x1, x0, #1, #0x1f
    //     0x8d2684: tbz             w0, #0, #0x8d268c
    //     0x8d2688: ldur            x1, [x0, #7]
    // 0x8d268c: cbnz            x1, #0x8d26b0
    // 0x8d2690: r16 = true
    //     0x8d2690: add             x16, NULL, #0x20  ; true
    // 0x8d2694: stp             x16, x3, [SP, #-0x10]!
    // 0x8d2698: r0 = _flushBlockOnly()
    //     0x8d2698: bl              #0x8cd6d8  ; [package:archive/src/zlib/deflate.dart] Deflate::_flushBlockOnly
    // 0x8d269c: add             SP, SP, #0x10
    // 0x8d26a0: r0 = 3
    //     0x8d26a0: mov             x0, #3
    // 0x8d26a4: LeaveFrame
    //     0x8d26a4: mov             SP, fp
    //     0x8d26a8: ldp             fp, lr, [SP], #0x10
    // 0x8d26ac: ret
    //     0x8d26ac: ret             
    // 0x8d26b0: r1 = LoadInt32Instr(r0)
    //     0x8d26b0: sbfx            x1, x0, #1, #0x1f
    //     0x8d26b4: tbz             w0, #0, #0x8d26bc
    //     0x8d26b8: ldur            x1, [x0, #7]
    // 0x8d26bc: mov             x0, x1
    // 0x8d26c0: b               #0x8d26d4
    // 0x8d26c4: mov             x3, x0
    // 0x8d26c8: r0 = LoadInt32Instr(r2)
    //     0x8d26c8: sbfx            x0, x2, #1, #0x1f
    //     0x8d26cc: tbz             w2, #0, #0x8d26d4
    //     0x8d26d0: ldur            x0, [x2, #7]
    // 0x8d26d4: ldur            x2, [fp, #-8]
    // 0x8d26d8: LoadField: r1 = r3->field_7b
    //     0x8d26d8: ldur            w1, [x3, #0x7b]
    // 0x8d26dc: DecompressPointer r1
    //     0x8d26dc: add             x1, x1, HEAP, lsl #32
    // 0x8d26e0: r16 = Sentinel
    //     0x8d26e0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d26e4: cmp             w1, w16
    // 0x8d26e8: b.eq            #0x8d287c
    // 0x8d26ec: r4 = LoadInt32Instr(r1)
    //     0x8d26ec: sbfx            x4, x1, #1, #0x1f
    //     0x8d26f0: tbz             w1, #0, #0x8d26f8
    //     0x8d26f4: ldur            x4, [x1, #7]
    // 0x8d26f8: add             x5, x4, x0
    // 0x8d26fc: r0 = BoxInt64Instr(r5)
    //     0x8d26fc: sbfiz           x0, x5, #1, #0x1f
    //     0x8d2700: cmp             x5, x0, asr #1
    //     0x8d2704: b.eq            #0x8d2710
    //     0x8d2708: bl              #0xd69bb8
    //     0x8d270c: stur            x5, [x0, #7]
    // 0x8d2710: StoreField: r3->field_7b = r0
    //     0x8d2710: stur            w0, [x3, #0x7b]
    //     0x8d2714: tbz             w0, #0, #0x8d2730
    //     0x8d2718: ldurb           w16, [x3, #-1]
    //     0x8d271c: ldurb           w17, [x0, #-1]
    //     0x8d2720: and             x16, x17, x16, lsr #2
    //     0x8d2724: tst             x16, HEAP, lsr #32
    //     0x8d2728: b.eq            #0x8d2730
    //     0x8d272c: bl              #0xd682ac
    // 0x8d2730: StoreField: r3->field_87 = rZR
    //     0x8d2730: stur            wzr, [x3, #0x87]
    // 0x8d2734: LoadField: r0 = r3->field_6b
    //     0x8d2734: ldur            w0, [x3, #0x6b]
    // 0x8d2738: DecompressPointer r0
    //     0x8d2738: add             x0, x0, HEAP, lsl #32
    // 0x8d273c: r16 = Sentinel
    //     0x8d273c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d2740: cmp             w0, w16
    // 0x8d2744: b.eq            #0x8d2888
    // 0x8d2748: r1 = LoadInt32Instr(r0)
    //     0x8d2748: sbfx            x1, x0, #1, #0x1f
    //     0x8d274c: tbz             w0, #0, #0x8d2754
    //     0x8d2750: ldur            x1, [x0, #7]
    // 0x8d2754: add             x4, x1, x2
    // 0x8d2758: cmp             x5, x4
    // 0x8d275c: b.lt            #0x8d27dc
    // 0x8d2760: sub             x6, x5, x4
    // 0x8d2764: r0 = BoxInt64Instr(r6)
    //     0x8d2764: sbfiz           x0, x6, #1, #0x1f
    //     0x8d2768: cmp             x6, x0, asr #1
    //     0x8d276c: b.eq            #0x8d2778
    //     0x8d2770: bl              #0xd69bb8
    //     0x8d2774: stur            x6, [x0, #7]
    // 0x8d2778: StoreField: r3->field_87 = r0
    //     0x8d2778: stur            w0, [x3, #0x87]
    //     0x8d277c: tbz             w0, #0, #0x8d2798
    //     0x8d2780: ldurb           w16, [x3, #-1]
    //     0x8d2784: ldurb           w17, [x0, #-1]
    //     0x8d2788: and             x16, x17, x16, lsr #2
    //     0x8d278c: tst             x16, HEAP, lsr #32
    //     0x8d2790: b.eq            #0x8d2798
    //     0x8d2794: bl              #0xd682ac
    // 0x8d2798: r0 = BoxInt64Instr(r4)
    //     0x8d2798: sbfiz           x0, x4, #1, #0x1f
    //     0x8d279c: cmp             x4, x0, asr #1
    //     0x8d27a0: b.eq            #0x8d27ac
    //     0x8d27a4: bl              #0xd69bb8
    //     0x8d27a8: stur            x4, [x0, #7]
    // 0x8d27ac: StoreField: r3->field_7b = r0
    //     0x8d27ac: stur            w0, [x3, #0x7b]
    //     0x8d27b0: tbz             w0, #0, #0x8d27cc
    //     0x8d27b4: ldurb           w16, [x3, #-1]
    //     0x8d27b8: ldurb           w17, [x0, #-1]
    //     0x8d27bc: and             x16, x17, x16, lsr #2
    //     0x8d27c0: tst             x16, HEAP, lsr #32
    //     0x8d27c4: b.eq            #0x8d27cc
    //     0x8d27c8: bl              #0xd682ac
    // 0x8d27cc: r16 = false
    //     0x8d27cc: add             x16, NULL, #0x30  ; false
    // 0x8d27d0: stp             x16, x3, [SP, #-0x10]!
    // 0x8d27d4: r0 = _flushBlockOnly()
    //     0x8d27d4: bl              #0x8cd6d8  ; [package:archive/src/zlib/deflate.dart] Deflate::_flushBlockOnly
    // 0x8d27d8: add             SP, SP, #0x10
    // 0x8d27dc: ldr             x0, [fp, #0x10]
    // 0x8d27e0: LoadField: r1 = r0->field_7b
    //     0x8d27e0: ldur            w1, [x0, #0x7b]
    // 0x8d27e4: DecompressPointer r1
    //     0x8d27e4: add             x1, x1, HEAP, lsl #32
    // 0x8d27e8: LoadField: r2 = r0->field_6b
    //     0x8d27e8: ldur            w2, [x0, #0x6b]
    // 0x8d27ec: DecompressPointer r2
    //     0x8d27ec: add             x2, x2, HEAP, lsl #32
    // 0x8d27f0: r3 = LoadInt32Instr(r1)
    //     0x8d27f0: sbfx            x3, x1, #1, #0x1f
    //     0x8d27f4: tbz             w1, #0, #0x8d27fc
    //     0x8d27f8: ldur            x3, [x1, #7]
    // 0x8d27fc: r1 = LoadInt32Instr(r2)
    //     0x8d27fc: sbfx            x1, x2, #1, #0x1f
    //     0x8d2800: tbz             w2, #0, #0x8d2808
    //     0x8d2804: ldur            x1, [x2, #7]
    // 0x8d2808: sub             x2, x3, x1
    // 0x8d280c: LoadField: r1 = r0->field_3b
    //     0x8d280c: ldur            w1, [x0, #0x3b]
    // 0x8d2810: DecompressPointer r1
    //     0x8d2810: add             x1, x1, HEAP, lsl #32
    // 0x8d2814: r16 = Sentinel
    //     0x8d2814: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d2818: cmp             w1, w16
    // 0x8d281c: b.eq            #0x8d2894
    // 0x8d2820: r3 = LoadInt32Instr(r1)
    //     0x8d2820: sbfx            x3, x1, #1, #0x1f
    //     0x8d2824: tbz             w1, #0, #0x8d282c
    //     0x8d2828: ldur            x3, [x1, #7]
    // 0x8d282c: sub             x1, x3, #0x106
    // 0x8d2830: cmp             x2, x1
    // 0x8d2834: b.lt            #0x8d2848
    // 0x8d2838: r16 = false
    //     0x8d2838: add             x16, NULL, #0x30  ; false
    // 0x8d283c: stp             x16, x0, [SP, #-0x10]!
    // 0x8d2840: r0 = _flushBlockOnly()
    //     0x8d2840: bl              #0x8cd6d8  ; [package:archive/src/zlib/deflate.dart] Deflate::_flushBlockOnly
    // 0x8d2844: add             SP, SP, #0x10
    // 0x8d2848: ldr             x0, [fp, #0x10]
    // 0x8d284c: ldur            x1, [fp, #-8]
    // 0x8d2850: b               #0x8d2634
    // 0x8d2854: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d2854: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d2858: b               #0x8d25f8
    // 0x8d285c: r9 = _pendingBufferSize
    //     0x8d285c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ba8] Field <Deflate._pendingBufferSize@60040000>: late (offset: 0x28)
    //     0x8d2860: ldr             x9, [x9, #0xba8]
    // 0x8d2864: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d2864: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d2868: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d2868: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d286c: b               #0x8d2640
    // 0x8d2870: r9 = _lookAhead
    //     0x8d2870: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a28] Field <Deflate._lookAhead@60040000>: late (offset: 0x88)
    //     0x8d2874: ldr             x9, [x9, #0xa28]
    // 0x8d2878: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d2878: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d287c: r9 = _strStart
    //     0x8d287c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a58] Field <Deflate._strStart@60040000>: late (offset: 0x7c)
    //     0x8d2880: ldr             x9, [x9, #0xa58]
    // 0x8d2884: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d2884: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d2888: r9 = _blockStart
    //     0x8d2888: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ab0] Field <Deflate._blockStart@60040000>: late (offset: 0x6c)
    //     0x8d288c: ldr             x9, [x9, #0xab0]
    // 0x8d2890: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d2890: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d2894: r9 = _windowSize
    //     0x8d2894: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a98] Field <Deflate._windowSize@60040000>: late (offset: 0x3c)
    //     0x8d2898: ldr             x9, [x9, #0xa98]
    // 0x8d289c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d289c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _init(/* No info */) {
    // ** addr: 0x8d28a0, size: 0x27c
    // 0x8d28a0: EnterFrame
    //     0x8d28a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8d28a4: mov             fp, SP
    // 0x8d28a8: AllocStack(0x8)
    //     0x8d28a8: sub             SP, SP, #8
    // 0x8d28ac: CheckStackOverflow
    //     0x8d28ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d28b0: cmp             SP, x16
    //     0x8d28b4: b.ls            #0x8d2b14
    // 0x8d28b8: ldr             x0, [fp, #0x10]
    // 0x8d28bc: cmp             w0, NULL
    // 0x8d28c0: b.eq            #0x8d28cc
    // 0x8d28c4: cmn             w0, #2
    // 0x8d28c8: b.ne            #0x8d28d4
    // 0x8d28cc: r0 = 6
    //     0x8d28cc: mov             x0, #6
    // 0x8d28d0: b               #0x8d28e4
    // 0x8d28d4: r1 = LoadInt32Instr(r0)
    //     0x8d28d4: sbfx            x1, x0, #1, #0x1f
    //     0x8d28d8: tbz             w0, #0, #0x8d28e0
    //     0x8d28dc: ldur            x1, [x0, #7]
    // 0x8d28e0: mov             x0, x1
    // 0x8d28e4: stur            x0, [fp, #-8]
    // 0x8d28e8: tbnz            x0, #0x3f, #0x8d2af4
    // 0x8d28ec: cmp             x0, #9
    // 0x8d28f0: b.gt            #0x8d2af4
    // 0x8d28f4: ldr             x1, [fp, #0x18]
    // 0x8d28f8: stp             x0, x1, [SP, #-0x10]!
    // 0x8d28fc: r0 = _getConfig()
    //     0x8d28fc: bl              #0x8d2f48  ; [package:archive/src/zlib/deflate.dart] Deflate::_getConfig
    // 0x8d2900: add             SP, SP, #0x10
    // 0x8d2904: StoreStaticField(0xa84, r0)
    //     0x8d2904: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0x8d2908: str             x0, [x1, #0x1508]
    // 0x8d290c: r4 = 2292
    //     0x8d290c: mov             x4, #0x8f4
    // 0x8d2910: r0 = AllocateUint16Array()
    //     0x8d2910: bl              #0xd69318  ; AllocateUint16ArrayStub
    // 0x8d2914: ldr             x1, [fp, #0x18]
    // 0x8d2918: StoreField: r1->field_97 = r0
    //     0x8d2918: stur            w0, [x1, #0x97]
    //     0x8d291c: ldurb           w16, [x1, #-1]
    //     0x8d2920: ldurb           w17, [x0, #-1]
    //     0x8d2924: and             x16, x17, x16, lsr #2
    //     0x8d2928: tst             x16, HEAP, lsr #32
    //     0x8d292c: b.eq            #0x8d2934
    //     0x8d2930: bl              #0xd6826c
    // 0x8d2934: r4 = 244
    //     0x8d2934: mov             x4, #0xf4
    // 0x8d2938: r0 = AllocateUint16Array()
    //     0x8d2938: bl              #0xd69318  ; AllocateUint16ArrayStub
    // 0x8d293c: ldr             x1, [fp, #0x18]
    // 0x8d2940: StoreField: r1->field_9b = r0
    //     0x8d2940: stur            w0, [x1, #0x9b]
    //     0x8d2944: ldurb           w16, [x1, #-1]
    //     0x8d2948: ldurb           w17, [x0, #-1]
    //     0x8d294c: and             x16, x17, x16, lsr #2
    //     0x8d2950: tst             x16, HEAP, lsr #32
    //     0x8d2954: b.eq            #0x8d295c
    //     0x8d2958: bl              #0xd6826c
    // 0x8d295c: r4 = 156
    //     0x8d295c: mov             x4, #0x9c
    // 0x8d2960: r0 = AllocateUint16Array()
    //     0x8d2960: bl              #0xd69318  ; AllocateUint16ArrayStub
    // 0x8d2964: ldr             x1, [fp, #0x18]
    // 0x8d2968: StoreField: r1->field_9f = r0
    //     0x8d2968: stur            w0, [x1, #0x9f]
    //     0x8d296c: ldurb           w16, [x1, #-1]
    //     0x8d2970: ldurb           w17, [x0, #-1]
    //     0x8d2974: and             x16, x17, x16, lsr #2
    //     0x8d2978: tst             x16, HEAP, lsr #32
    //     0x8d297c: b.eq            #0x8d2984
    //     0x8d2980: bl              #0xd6826c
    // 0x8d2984: r0 = 30
    //     0x8d2984: mov             x0, #0x1e
    // 0x8d2988: StoreField: r1->field_3f = r0
    //     0x8d2988: stur            w0, [x1, #0x3f]
    // 0x8d298c: r2 = 65536
    //     0x8d298c: mov             x2, #0x10000
    // 0x8d2990: StoreField: r1->field_3b = r2
    //     0x8d2990: stur            w2, [x1, #0x3b]
    // 0x8d2994: r3 = 65534
    //     0x8d2994: mov             x3, #0xfffe
    // 0x8d2998: StoreField: r1->field_43 = r3
    //     0x8d2998: stur            w3, [x1, #0x43]
    // 0x8d299c: StoreField: r1->field_5f = r0
    //     0x8d299c: stur            w0, [x1, #0x5f]
    // 0x8d29a0: StoreField: r1->field_5b = r2
    //     0x8d29a0: stur            w2, [x1, #0x5b]
    // 0x8d29a4: StoreField: r1->field_63 = r3
    //     0x8d29a4: stur            w3, [x1, #0x63]
    // 0x8d29a8: r0 = 10
    //     0x8d29a8: mov             x0, #0xa
    // 0x8d29ac: StoreField: r1->field_67 = r0
    //     0x8d29ac: stur            w0, [x1, #0x67]
    // 0x8d29b0: r4 = 131072
    //     0x8d29b0: mov             x4, #0x20000
    // 0x8d29b4: r0 = AllocateUint8Array()
    //     0x8d29b4: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0x8d29b8: ldr             x1, [fp, #0x18]
    // 0x8d29bc: StoreField: r1->field_47 = r0
    //     0x8d29bc: stur            w0, [x1, #0x47]
    //     0x8d29c0: ldurb           w16, [x1, #-1]
    //     0x8d29c4: ldurb           w17, [x0, #-1]
    //     0x8d29c8: and             x16, x17, x16, lsr #2
    //     0x8d29cc: tst             x16, HEAP, lsr #32
    //     0x8d29d0: b.eq            #0x8d29d8
    //     0x8d29d4: bl              #0xd6826c
    // 0x8d29d8: r4 = 65536
    //     0x8d29d8: mov             x4, #0x10000
    // 0x8d29dc: r0 = AllocateUint16Array()
    //     0x8d29dc: bl              #0xd69318  ; AllocateUint16ArrayStub
    // 0x8d29e0: ldr             x1, [fp, #0x18]
    // 0x8d29e4: StoreField: r1->field_4f = r0
    //     0x8d29e4: stur            w0, [x1, #0x4f]
    //     0x8d29e8: ldurb           w16, [x1, #-1]
    //     0x8d29ec: ldurb           w17, [x0, #-1]
    //     0x8d29f0: and             x16, x17, x16, lsr #2
    //     0x8d29f4: tst             x16, HEAP, lsr #32
    //     0x8d29f8: b.eq            #0x8d2a00
    //     0x8d29fc: bl              #0xd6826c
    // 0x8d2a00: r4 = 65536
    //     0x8d2a00: mov             x4, #0x10000
    // 0x8d2a04: r0 = AllocateUint16Array()
    //     0x8d2a04: bl              #0xd69318  ; AllocateUint16ArrayStub
    // 0x8d2a08: ldr             x1, [fp, #0x18]
    // 0x8d2a0c: StoreField: r1->field_53 = r0
    //     0x8d2a0c: stur            w0, [x1, #0x53]
    //     0x8d2a10: ldurb           w16, [x1, #-1]
    //     0x8d2a14: ldurb           w17, [x0, #-1]
    //     0x8d2a18: and             x16, x17, x16, lsr #2
    //     0x8d2a1c: tst             x16, HEAP, lsr #32
    //     0x8d2a20: b.eq            #0x8d2a28
    //     0x8d2a24: bl              #0xd6826c
    // 0x8d2a28: r0 = 32768
    //     0x8d2a28: mov             x0, #0x8000
    // 0x8d2a2c: StoreField: r1->field_c7 = r0
    //     0x8d2a2c: stur            w0, [x1, #0xc7]
    // 0x8d2a30: r4 = 131072
    //     0x8d2a30: mov             x4, #0x20000
    // 0x8d2a34: r0 = AllocateUint8Array()
    //     0x8d2a34: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0x8d2a38: ldr             x2, [fp, #0x18]
    // 0x8d2a3c: StoreField: r2->field_23 = r0
    //     0x8d2a3c: stur            w0, [x2, #0x23]
    //     0x8d2a40: ldurb           w16, [x2, #-1]
    //     0x8d2a44: ldurb           w17, [x0, #-1]
    //     0x8d2a48: and             x16, x17, x16, lsr #2
    //     0x8d2a4c: tst             x16, HEAP, lsr #32
    //     0x8d2a50: b.eq            #0x8d2a58
    //     0x8d2a54: bl              #0xd6828c
    // 0x8d2a58: r0 = 131072
    //     0x8d2a58: mov             x0, #0x20000
    // 0x8d2a5c: StoreField: r2->field_27 = r0
    //     0x8d2a5c: stur            w0, [x2, #0x27]
    // 0x8d2a60: r0 = 32768
    //     0x8d2a60: mov             x0, #0x8000
    // 0x8d2a64: StoreField: r2->field_cf = r0
    //     0x8d2a64: stur            w0, [x2, #0xcf]
    // 0x8d2a68: r0 = 98304
    //     0x8d2a68: mov             x0, #0x8000
    //     0x8d2a6c: movk            x0, #1, lsl #16
    // 0x8d2a70: StoreField: r2->field_c3 = r0
    //     0x8d2a70: stur            w0, [x2, #0xc3]
    // 0x8d2a74: ldur            x3, [fp, #-8]
    // 0x8d2a78: r0 = BoxInt64Instr(r3)
    //     0x8d2a78: sbfiz           x0, x3, #1, #0x1f
    //     0x8d2a7c: cmp             x3, x0, asr #1
    //     0x8d2a80: b.eq            #0x8d2a8c
    //     0x8d2a84: bl              #0xd69bb8
    //     0x8d2a88: stur            x3, [x0, #7]
    // 0x8d2a8c: StoreField: r2->field_8f = r0
    //     0x8d2a8c: stur            w0, [x2, #0x8f]
    //     0x8d2a90: tbz             w0, #0, #0x8d2aac
    //     0x8d2a94: ldurb           w16, [x2, #-1]
    //     0x8d2a98: ldurb           w17, [x0, #-1]
    //     0x8d2a9c: and             x16, x17, x16, lsr #2
    //     0x8d2aa0: tst             x16, HEAP, lsr #32
    //     0x8d2aa4: b.eq            #0x8d2aac
    //     0x8d2aa8: bl              #0xd6828c
    // 0x8d2aac: StoreField: r2->field_93 = rZR
    //     0x8d2aac: stur            wzr, [x2, #0x93]
    // 0x8d2ab0: StoreField: r2->field_2f = rZR
    //     0x8d2ab0: stur            wzr, [x2, #0x2f]
    // 0x8d2ab4: StoreField: r2->field_2b = rZR
    //     0x8d2ab4: stur            wzr, [x2, #0x2b]
    // 0x8d2ab8: r0 = 226
    //     0x8d2ab8: mov             x0, #0xe2
    // 0x8d2abc: StoreField: r2->field_1f = r0
    //     0x8d2abc: stur            w0, [x2, #0x1f]
    // 0x8d2ac0: r0 = 0
    //     0x8d2ac0: mov             x0, #0
    // 0x8d2ac4: StoreField: r2->field_7 = r0
    //     0x8d2ac4: stur            x0, [x2, #7]
    // 0x8d2ac8: SaveReg r2
    //     0x8d2ac8: str             x2, [SP, #-8]!
    // 0x8d2acc: r0 = _trInit()
    //     0x8d2acc: bl              #0x8d2c7c  ; [package:archive/src/zlib/deflate.dart] Deflate::_trInit
    // 0x8d2ad0: add             SP, SP, #8
    // 0x8d2ad4: ldr             x16, [fp, #0x18]
    // 0x8d2ad8: SaveReg r16
    //     0x8d2ad8: str             x16, [SP, #-8]!
    // 0x8d2adc: r0 = _lmInit()
    //     0x8d2adc: bl              #0x8d2b1c  ; [package:archive/src/zlib/deflate.dart] Deflate::_lmInit
    // 0x8d2ae0: add             SP, SP, #8
    // 0x8d2ae4: r0 = Null
    //     0x8d2ae4: mov             x0, NULL
    // 0x8d2ae8: LeaveFrame
    //     0x8d2ae8: mov             SP, fp
    //     0x8d2aec: ldp             fp, lr, [SP], #0x10
    // 0x8d2af0: ret
    //     0x8d2af0: ret             
    // 0x8d2af4: r0 = ArchiveException()
    //     0x8d2af4: bl              #0x817830  ; AllocateArchiveExceptionStub -> ArchiveException (size=0x14)
    // 0x8d2af8: mov             x1, x0
    // 0x8d2afc: r0 = "Invalid Deflate parameter"
    //     0x8d2afc: add             x0, PP, #0x34, lsl #12  ; [pp+0x34bb0] "Invalid Deflate parameter"
    //     0x8d2b00: ldr             x0, [x0, #0xbb0]
    // 0x8d2b04: StoreField: r1->field_7 = r0
    //     0x8d2b04: stur            w0, [x1, #7]
    // 0x8d2b08: mov             x0, x1
    // 0x8d2b0c: r0 = Throw()
    //     0x8d2b0c: bl              #0xd67e38  ; ThrowStub
    // 0x8d2b10: brk             #0
    // 0x8d2b14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d2b14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d2b18: b               #0x8d28b8
  }
  _ _lmInit(/* No info */) {
    // ** addr: 0x8d2b1c, size: 0x160
    // 0x8d2b1c: EnterFrame
    //     0x8d2b1c: stp             fp, lr, [SP, #-0x10]!
    //     0x8d2b20: mov             fp, SP
    // 0x8d2b24: ldr             x2, [fp, #0x10]
    // 0x8d2b28: LoadField: r3 = r2->field_3b
    //     0x8d2b28: ldur            w3, [x2, #0x3b]
    // 0x8d2b2c: DecompressPointer r3
    //     0x8d2b2c: add             x3, x3, HEAP, lsl #32
    // 0x8d2b30: r16 = Sentinel
    //     0x8d2b30: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d2b34: cmp             w3, w16
    // 0x8d2b38: b.eq            #0x8d2c48
    // 0x8d2b3c: r4 = LoadInt32Instr(r3)
    //     0x8d2b3c: sbfx            x4, x3, #1, #0x1f
    //     0x8d2b40: tbz             w3, #0, #0x8d2b48
    //     0x8d2b44: ldur            x4, [x3, #7]
    // 0x8d2b48: lsl             x3, x4, #1
    // 0x8d2b4c: r0 = BoxInt64Instr(r3)
    //     0x8d2b4c: sbfiz           x0, x3, #1, #0x1f
    //     0x8d2b50: cmp             x3, x0, asr #1
    //     0x8d2b54: b.eq            #0x8d2b60
    //     0x8d2b58: bl              #0xd69bb8
    //     0x8d2b5c: stur            x3, [x0, #7]
    // 0x8d2b60: StoreField: r2->field_4b = r0
    //     0x8d2b60: stur            w0, [x2, #0x4b]
    //     0x8d2b64: tbz             w0, #0, #0x8d2b80
    //     0x8d2b68: ldurb           w16, [x2, #-1]
    //     0x8d2b6c: ldurb           w17, [x0, #-1]
    //     0x8d2b70: and             x16, x17, x16, lsr #2
    //     0x8d2b74: tst             x16, HEAP, lsr #32
    //     0x8d2b78: b.eq            #0x8d2b80
    //     0x8d2b7c: bl              #0xd6828c
    // 0x8d2b80: LoadField: r3 = r2->field_53
    //     0x8d2b80: ldur            w3, [x2, #0x53]
    // 0x8d2b84: DecompressPointer r3
    //     0x8d2b84: add             x3, x3, HEAP, lsl #32
    // 0x8d2b88: r16 = Sentinel
    //     0x8d2b88: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d2b8c: cmp             w3, w16
    // 0x8d2b90: b.eq            #0x8d2c54
    // 0x8d2b94: LoadField: r4 = r2->field_5b
    //     0x8d2b94: ldur            w4, [x2, #0x5b]
    // 0x8d2b98: DecompressPointer r4
    //     0x8d2b98: add             x4, x4, HEAP, lsl #32
    // 0x8d2b9c: r16 = Sentinel
    //     0x8d2b9c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d2ba0: cmp             w4, w16
    // 0x8d2ba4: b.eq            #0x8d2c60
    // 0x8d2ba8: r5 = LoadInt32Instr(r4)
    //     0x8d2ba8: sbfx            x5, x4, #1, #0x1f
    //     0x8d2bac: tbz             w4, #0, #0x8d2bb4
    //     0x8d2bb0: ldur            x5, [x4, #7]
    // 0x8d2bb4: sub             x4, x5, #1
    // 0x8d2bb8: LoadField: r5 = r3->field_13
    //     0x8d2bb8: ldur            w5, [x3, #0x13]
    // 0x8d2bbc: DecompressPointer r5
    //     0x8d2bbc: add             x5, x5, HEAP, lsl #32
    // 0x8d2bc0: r6 = LoadInt32Instr(r5)
    //     0x8d2bc0: sbfx            x6, x5, #1, #0x1f
    // 0x8d2bc4: mov             x0, x6
    // 0x8d2bc8: mov             x1, x4
    // 0x8d2bcc: cmp             x1, x0
    // 0x8d2bd0: b.hs            #0x8d2c6c
    // 0x8d2bd4: ArrayStore: r3[r4] = rZR  ; TypeUnknown_2
    //     0x8d2bd4: add             x5, x3, x4, lsl #1
    //     0x8d2bd8: sturh           wzr, [x5, #0x17]
    // 0x8d2bdc: r5 = 0
    //     0x8d2bdc: mov             x5, #0
    // 0x8d2be0: CheckStackOverflow
    //     0x8d2be0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d2be4: cmp             SP, x16
    //     0x8d2be8: b.ls            #0x8d2c70
    // 0x8d2bec: cmp             x5, x4
    // 0x8d2bf0: b.ge            #0x8d2c18
    // 0x8d2bf4: mov             x0, x6
    // 0x8d2bf8: mov             x1, x5
    // 0x8d2bfc: cmp             x1, x0
    // 0x8d2c00: b.hs            #0x8d2c78
    // 0x8d2c04: ArrayStore: r3[r5] = rZR  ; TypeUnknown_2
    //     0x8d2c04: add             x1, x3, x5, lsl #1
    //     0x8d2c08: sturh           wzr, [x1, #0x17]
    // 0x8d2c0c: add             x0, x5, #1
    // 0x8d2c10: mov             x5, x0
    // 0x8d2c14: b               #0x8d2be0
    // 0x8d2c18: r1 = 4
    //     0x8d2c18: mov             x1, #4
    // 0x8d2c1c: StoreField: r2->field_7b = rZR
    //     0x8d2c1c: stur            wzr, [x2, #0x7b]
    // 0x8d2c20: StoreField: r2->field_6b = rZR
    //     0x8d2c20: stur            wzr, [x2, #0x6b]
    // 0x8d2c24: StoreField: r2->field_87 = rZR
    //     0x8d2c24: stur            wzr, [x2, #0x87]
    // 0x8d2c28: StoreField: r2->field_8b = r1
    //     0x8d2c28: stur            w1, [x2, #0x8b]
    // 0x8d2c2c: StoreField: r2->field_6f = r1
    //     0x8d2c2c: stur            w1, [x2, #0x6f]
    // 0x8d2c30: StoreField: r2->field_77 = rZR
    //     0x8d2c30: stur            wzr, [x2, #0x77]
    // 0x8d2c34: StoreField: r2->field_57 = rZR
    //     0x8d2c34: stur            wzr, [x2, #0x57]
    // 0x8d2c38: r0 = Null
    //     0x8d2c38: mov             x0, NULL
    // 0x8d2c3c: LeaveFrame
    //     0x8d2c3c: mov             SP, fp
    //     0x8d2c40: ldp             fp, lr, [SP], #0x10
    // 0x8d2c44: ret
    //     0x8d2c44: ret             
    // 0x8d2c48: r9 = _windowSize
    //     0x8d2c48: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a98] Field <Deflate._windowSize@60040000>: late (offset: 0x3c)
    //     0x8d2c4c: ldr             x9, [x9, #0xa98]
    // 0x8d2c50: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d2c50: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d2c54: r9 = _head
    //     0x8d2c54: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a78] Field <Deflate._head@60040000>: late (offset: 0x54)
    //     0x8d2c58: ldr             x9, [x9, #0xa78]
    // 0x8d2c5c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d2c5c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d2c60: r9 = _hashSize
    //     0x8d2c60: add             x9, PP, #0x34, lsl #12  ; [pp+0x34b88] Field <Deflate._hashSize@60040000>: late (offset: 0x5c)
    //     0x8d2c64: ldr             x9, [x9, #0xb88]
    // 0x8d2c68: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d2c68: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d2c6c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d2c6c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d2c70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d2c70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d2c74: b               #0x8d2bec
    // 0x8d2c78: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d2c78: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _trInit(/* No info */) {
    // ** addr: 0x8d2c7c, size: 0x1f4
    // 0x8d2c7c: EnterFrame
    //     0x8d2c7c: stp             fp, lr, [SP, #-0x10]!
    //     0x8d2c80: mov             fp, SP
    // 0x8d2c84: AllocStack(0x8)
    //     0x8d2c84: sub             SP, SP, #8
    // 0x8d2c88: CheckStackOverflow
    //     0x8d2c88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8d2c8c: cmp             SP, x16
    //     0x8d2c90: b.ls            #0x8d2e44
    // 0x8d2c94: ldr             x1, [fp, #0x10]
    // 0x8d2c98: LoadField: r2 = r1->field_a3
    //     0x8d2c98: ldur            w2, [x1, #0xa3]
    // 0x8d2c9c: DecompressPointer r2
    //     0x8d2c9c: add             x2, x2, HEAP, lsl #32
    // 0x8d2ca0: stur            x2, [fp, #-8]
    // 0x8d2ca4: LoadField: r0 = r1->field_97
    //     0x8d2ca4: ldur            w0, [x1, #0x97]
    // 0x8d2ca8: DecompressPointer r0
    //     0x8d2ca8: add             x0, x0, HEAP, lsl #32
    // 0x8d2cac: r16 = Sentinel
    //     0x8d2cac: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d2cb0: cmp             w0, w16
    // 0x8d2cb4: b.eq            #0x8d2e4c
    // 0x8d2cb8: StoreField: r2->field_7 = r0
    //     0x8d2cb8: stur            w0, [x2, #7]
    //     0x8d2cbc: ldurb           w16, [x2, #-1]
    //     0x8d2cc0: ldurb           w17, [x0, #-1]
    //     0x8d2cc4: and             x16, x17, x16, lsr #2
    //     0x8d2cc8: tst             x16, HEAP, lsr #32
    //     0x8d2ccc: b.eq            #0x8d2cd4
    //     0x8d2cd0: bl              #0xd6828c
    // 0x8d2cd4: r0 = InitLateStaticField(0xa88) // [package:archive/src/zlib/deflate.dart] _StaticTree::staticLDesc
    //     0x8d2cd4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x8d2cd8: ldr             x0, [x0, #0x1510]
    //     0x8d2cdc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x8d2ce0: cmp             w0, w16
    //     0x8d2ce4: b.ne            #0x8d2cf4
    //     0x8d2ce8: add             x2, PP, #0x34, lsl #12  ; [pp+0x34bb8] Field <_StaticTree@60040000.staticLDesc>: static late final (offset: 0xa88)
    //     0x8d2cec: ldr             x2, [x2, #0xbb8]
    //     0x8d2cf0: bl              #0xd67cdc
    // 0x8d2cf4: ldur            x1, [fp, #-8]
    // 0x8d2cf8: StoreField: r1->field_f = r0
    //     0x8d2cf8: stur            w0, [x1, #0xf]
    //     0x8d2cfc: ldurb           w16, [x1, #-1]
    //     0x8d2d00: ldurb           w17, [x0, #-1]
    //     0x8d2d04: and             x16, x17, x16, lsr #2
    //     0x8d2d08: tst             x16, HEAP, lsr #32
    //     0x8d2d0c: b.eq            #0x8d2d14
    //     0x8d2d10: bl              #0xd6826c
    // 0x8d2d14: ldr             x1, [fp, #0x10]
    // 0x8d2d18: LoadField: r2 = r1->field_a7
    //     0x8d2d18: ldur            w2, [x1, #0xa7]
    // 0x8d2d1c: DecompressPointer r2
    //     0x8d2d1c: add             x2, x2, HEAP, lsl #32
    // 0x8d2d20: stur            x2, [fp, #-8]
    // 0x8d2d24: LoadField: r0 = r1->field_9b
    //     0x8d2d24: ldur            w0, [x1, #0x9b]
    // 0x8d2d28: DecompressPointer r0
    //     0x8d2d28: add             x0, x0, HEAP, lsl #32
    // 0x8d2d2c: r16 = Sentinel
    //     0x8d2d2c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d2d30: cmp             w0, w16
    // 0x8d2d34: b.eq            #0x8d2e58
    // 0x8d2d38: StoreField: r2->field_7 = r0
    //     0x8d2d38: stur            w0, [x2, #7]
    //     0x8d2d3c: ldurb           w16, [x2, #-1]
    //     0x8d2d40: ldurb           w17, [x0, #-1]
    //     0x8d2d44: and             x16, x17, x16, lsr #2
    //     0x8d2d48: tst             x16, HEAP, lsr #32
    //     0x8d2d4c: b.eq            #0x8d2d54
    //     0x8d2d50: bl              #0xd6828c
    // 0x8d2d54: r0 = InitLateStaticField(0xa8c) // [package:archive/src/zlib/deflate.dart] _StaticTree::staticDDesc
    //     0x8d2d54: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x8d2d58: ldr             x0, [x0, #0x1518]
    //     0x8d2d5c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x8d2d60: cmp             w0, w16
    //     0x8d2d64: b.ne            #0x8d2d74
    //     0x8d2d68: add             x2, PP, #0x34, lsl #12  ; [pp+0x34bc0] Field <_StaticTree@60040000.staticDDesc>: static late final (offset: 0xa8c)
    //     0x8d2d6c: ldr             x2, [x2, #0xbc0]
    //     0x8d2d70: bl              #0xd67cdc
    // 0x8d2d74: ldur            x1, [fp, #-8]
    // 0x8d2d78: StoreField: r1->field_f = r0
    //     0x8d2d78: stur            w0, [x1, #0xf]
    //     0x8d2d7c: ldurb           w16, [x1, #-1]
    //     0x8d2d80: ldurb           w17, [x0, #-1]
    //     0x8d2d84: and             x16, x17, x16, lsr #2
    //     0x8d2d88: tst             x16, HEAP, lsr #32
    //     0x8d2d8c: b.eq            #0x8d2d94
    //     0x8d2d90: bl              #0xd6826c
    // 0x8d2d94: ldr             x1, [fp, #0x10]
    // 0x8d2d98: LoadField: r2 = r1->field_ab
    //     0x8d2d98: ldur            w2, [x1, #0xab]
    // 0x8d2d9c: DecompressPointer r2
    //     0x8d2d9c: add             x2, x2, HEAP, lsl #32
    // 0x8d2da0: stur            x2, [fp, #-8]
    // 0x8d2da4: LoadField: r0 = r1->field_9f
    //     0x8d2da4: ldur            w0, [x1, #0x9f]
    // 0x8d2da8: DecompressPointer r0
    //     0x8d2da8: add             x0, x0, HEAP, lsl #32
    // 0x8d2dac: r16 = Sentinel
    //     0x8d2dac: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8d2db0: cmp             w0, w16
    // 0x8d2db4: b.eq            #0x8d2e64
    // 0x8d2db8: StoreField: r2->field_7 = r0
    //     0x8d2db8: stur            w0, [x2, #7]
    //     0x8d2dbc: ldurb           w16, [x2, #-1]
    //     0x8d2dc0: ldurb           w17, [x0, #-1]
    //     0x8d2dc4: and             x16, x17, x16, lsr #2
    //     0x8d2dc8: tst             x16, HEAP, lsr #32
    //     0x8d2dcc: b.eq            #0x8d2dd4
    //     0x8d2dd0: bl              #0xd6828c
    // 0x8d2dd4: r0 = InitLateStaticField(0xa90) // [package:archive/src/zlib/deflate.dart] _StaticTree::staticBlDesc
    //     0x8d2dd4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x8d2dd8: ldr             x0, [x0, #0x1520]
    //     0x8d2ddc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x8d2de0: cmp             w0, w16
    //     0x8d2de4: b.ne            #0x8d2df4
    //     0x8d2de8: add             x2, PP, #0x34, lsl #12  ; [pp+0x34bc8] Field <_StaticTree@60040000.staticBlDesc>: static late final (offset: 0xa90)
    //     0x8d2dec: ldr             x2, [x2, #0xbc8]
    //     0x8d2df0: bl              #0xd67cdc
    // 0x8d2df4: ldur            x1, [fp, #-8]
    // 0x8d2df8: StoreField: r1->field_f = r0
    //     0x8d2df8: stur            w0, [x1, #0xf]
    //     0x8d2dfc: ldurb           w16, [x1, #-1]
    //     0x8d2e00: ldurb           w17, [x0, #-1]
    //     0x8d2e04: and             x16, x17, x16, lsr #2
    //     0x8d2e08: tst             x16, HEAP, lsr #32
    //     0x8d2e0c: b.eq            #0x8d2e14
    //     0x8d2e10: bl              #0xd6826c
    // 0x8d2e14: ldr             x0, [fp, #0x10]
    // 0x8d2e18: StoreField: r0->field_e3 = rZR
    //     0x8d2e18: stur            wzr, [x0, #0xe3]
    // 0x8d2e1c: StoreField: r0->field_e7 = rZR
    //     0x8d2e1c: stur            wzr, [x0, #0xe7]
    // 0x8d2e20: r1 = 16
    //     0x8d2e20: mov             x1, #0x10
    // 0x8d2e24: StoreField: r0->field_df = r1
    //     0x8d2e24: stur            w1, [x0, #0xdf]
    // 0x8d2e28: SaveReg r0
    //     0x8d2e28: str             x0, [SP, #-8]!
    // 0x8d2e2c: r0 = _initBlock()
    //     0x8d2e2c: bl              #0x8cdb68  ; [package:archive/src/zlib/deflate.dart] Deflate::_initBlock
    // 0x8d2e30: add             SP, SP, #8
    // 0x8d2e34: r0 = Null
    //     0x8d2e34: mov             x0, NULL
    // 0x8d2e38: LeaveFrame
    //     0x8d2e38: mov             SP, fp
    //     0x8d2e3c: ldp             fp, lr, [SP], #0x10
    // 0x8d2e40: ret
    //     0x8d2e40: ret             
    // 0x8d2e44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d2e44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d2e48: b               #0x8d2c94
    // 0x8d2e4c: r9 = _dynamicLengthTree
    //     0x8d2e4c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34ae8] Field <Deflate._dynamicLengthTree@60040000>: late (offset: 0x98)
    //     0x8d2e50: ldr             x9, [x9, #0xae8]
    // 0x8d2e54: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d2e54: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d2e58: r9 = _dynamicDistTree
    //     0x8d2e58: add             x9, PP, #0x34, lsl #12  ; [pp+0x34af0] Field <Deflate._dynamicDistTree@60040000>: late (offset: 0x9c)
    //     0x8d2e5c: ldr             x9, [x9, #0xaf0]
    // 0x8d2e60: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d2e60: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8d2e64: r9 = _bitLengthTree
    //     0x8d2e64: add             x9, PP, #0x34, lsl #12  ; [pp+0x34af8] Field <Deflate._bitLengthTree@60040000>: late (offset: 0xa0)
    //     0x8d2e68: ldr             x9, [x9, #0xaf8]
    // 0x8d2e6c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8d2e6c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _getConfig(/* No info */) {
    // ** addr: 0x8d2f48, size: 0x34c
    // 0x8d2f48: EnterFrame
    //     0x8d2f48: stp             fp, lr, [SP, #-0x10]!
    //     0x8d2f4c: mov             fp, SP
    // 0x8d2f50: ldr             x2, [fp, #0x10]
    // 0x8d2f54: r0 = BoxInt64Instr(r2)
    //     0x8d2f54: sbfiz           x0, x2, #1, #0x1f
    //     0x8d2f58: cmp             x2, x0, asr #1
    //     0x8d2f5c: b.eq            #0x8d2f68
    //     0x8d2f60: bl              #0xd69bb8
    //     0x8d2f64: stur            x2, [x0, #7]
    // 0x8d2f68: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x8d2f68: mov             x1, #0x76
    //     0x8d2f6c: tbz             w0, #0, #0x8d2f7c
    //     0x8d2f70: ldur            x1, [x0, #-1]
    //     0x8d2f74: ubfx            x1, x1, #0xc, #0x14
    //     0x8d2f78: lsl             x1, x1, #1
    // 0x8d2f7c: cmp             w1, #0x76
    // 0x8d2f80: b.ne            #0x8d3274
    // 0x8d2f84: cmp             x2, #4
    // 0x8d2f88: b.gt            #0x8d30e4
    // 0x8d2f8c: cmp             x2, #2
    // 0x8d2f90: b.gt            #0x8d305c
    // 0x8d2f94: cmp             x2, #1
    // 0x8d2f98: b.gt            #0x8d3010
    // 0x8d2f9c: cmp             x2, #0
    // 0x8d2fa0: b.gt            #0x8d2fd8
    // 0x8d2fa4: cbnz            w0, #0x8d3274
    // 0x8d2fa8: r0 = _DeflaterConfig()
    //     0x8d2fa8: bl              #0x8d3294  ; Allocate_DeflaterConfigStub -> _DeflaterConfig (size=0x30)
    // 0x8d2fac: mov             x1, x0
    // 0x8d2fb0: r0 = 0
    //     0x8d2fb0: mov             x0, #0
    // 0x8d2fb4: StoreField: r1->field_7 = r0
    //     0x8d2fb4: stur            x0, [x1, #7]
    // 0x8d2fb8: StoreField: r1->field_f = r0
    //     0x8d2fb8: stur            x0, [x1, #0xf]
    // 0x8d2fbc: StoreField: r1->field_17 = r0
    //     0x8d2fbc: stur            x0, [x1, #0x17]
    // 0x8d2fc0: StoreField: r1->field_1f = r0
    //     0x8d2fc0: stur            x0, [x1, #0x1f]
    // 0x8d2fc4: StoreField: r1->field_27 = r0
    //     0x8d2fc4: stur            x0, [x1, #0x27]
    // 0x8d2fc8: mov             x0, x1
    // 0x8d2fcc: LeaveFrame
    //     0x8d2fcc: mov             SP, fp
    //     0x8d2fd0: ldp             fp, lr, [SP], #0x10
    // 0x8d2fd4: ret
    //     0x8d2fd4: ret             
    // 0x8d2fd8: r0 = _DeflaterConfig()
    //     0x8d2fd8: bl              #0x8d3294  ; Allocate_DeflaterConfigStub -> _DeflaterConfig (size=0x30)
    // 0x8d2fdc: mov             x1, x0
    // 0x8d2fe0: r0 = 4
    //     0x8d2fe0: mov             x0, #4
    // 0x8d2fe4: StoreField: r1->field_7 = r0
    //     0x8d2fe4: stur            x0, [x1, #7]
    // 0x8d2fe8: StoreField: r1->field_f = r0
    //     0x8d2fe8: stur            x0, [x1, #0xf]
    // 0x8d2fec: r2 = 8
    //     0x8d2fec: mov             x2, #8
    // 0x8d2ff0: StoreField: r1->field_17 = r2
    //     0x8d2ff0: stur            x2, [x1, #0x17]
    // 0x8d2ff4: StoreField: r1->field_1f = r0
    //     0x8d2ff4: stur            x0, [x1, #0x1f]
    // 0x8d2ff8: r3 = 1
    //     0x8d2ff8: mov             x3, #1
    // 0x8d2ffc: StoreField: r1->field_27 = r3
    //     0x8d2ffc: stur            x3, [x1, #0x27]
    // 0x8d3000: mov             x0, x1
    // 0x8d3004: LeaveFrame
    //     0x8d3004: mov             SP, fp
    //     0x8d3008: ldp             fp, lr, [SP], #0x10
    // 0x8d300c: ret
    //     0x8d300c: ret             
    // 0x8d3010: r0 = 4
    //     0x8d3010: mov             x0, #4
    // 0x8d3014: r3 = 1
    //     0x8d3014: mov             x3, #1
    // 0x8d3018: r2 = 8
    //     0x8d3018: mov             x2, #8
    // 0x8d301c: r0 = _DeflaterConfig()
    //     0x8d301c: bl              #0x8d3294  ; Allocate_DeflaterConfigStub -> _DeflaterConfig (size=0x30)
    // 0x8d3020: mov             x1, x0
    // 0x8d3024: r0 = 4
    //     0x8d3024: mov             x0, #4
    // 0x8d3028: StoreField: r1->field_7 = r0
    //     0x8d3028: stur            x0, [x1, #7]
    // 0x8d302c: r0 = 5
    //     0x8d302c: mov             x0, #5
    // 0x8d3030: StoreField: r1->field_f = r0
    //     0x8d3030: stur            x0, [x1, #0xf]
    // 0x8d3034: r3 = 16
    //     0x8d3034: mov             x3, #0x10
    // 0x8d3038: StoreField: r1->field_17 = r3
    //     0x8d3038: stur            x3, [x1, #0x17]
    // 0x8d303c: r3 = 8
    //     0x8d303c: mov             x3, #8
    // 0x8d3040: StoreField: r1->field_1f = r3
    //     0x8d3040: stur            x3, [x1, #0x1f]
    // 0x8d3044: r4 = 1
    //     0x8d3044: mov             x4, #1
    // 0x8d3048: StoreField: r1->field_27 = r4
    //     0x8d3048: stur            x4, [x1, #0x27]
    // 0x8d304c: mov             x0, x1
    // 0x8d3050: LeaveFrame
    //     0x8d3050: mov             SP, fp
    //     0x8d3054: ldp             fp, lr, [SP], #0x10
    // 0x8d3058: ret
    //     0x8d3058: ret             
    // 0x8d305c: r0 = 4
    //     0x8d305c: mov             x0, #4
    // 0x8d3060: r4 = 1
    //     0x8d3060: mov             x4, #1
    // 0x8d3064: r3 = 16
    //     0x8d3064: mov             x3, #0x10
    // 0x8d3068: cmp             x2, #3
    // 0x8d306c: b.gt            #0x8d30ac
    // 0x8d3070: r0 = _DeflaterConfig()
    //     0x8d3070: bl              #0x8d3294  ; Allocate_DeflaterConfigStub -> _DeflaterConfig (size=0x30)
    // 0x8d3074: mov             x1, x0
    // 0x8d3078: r0 = 4
    //     0x8d3078: mov             x0, #4
    // 0x8d307c: StoreField: r1->field_7 = r0
    //     0x8d307c: stur            x0, [x1, #7]
    // 0x8d3080: r0 = 6
    //     0x8d3080: mov             x0, #6
    // 0x8d3084: StoreField: r1->field_f = r0
    //     0x8d3084: stur            x0, [x1, #0xf]
    // 0x8d3088: r4 = 32
    //     0x8d3088: mov             x4, #0x20
    // 0x8d308c: StoreField: r1->field_17 = r4
    //     0x8d308c: stur            x4, [x1, #0x17]
    // 0x8d3090: StoreField: r1->field_1f = r4
    //     0x8d3090: stur            x4, [x1, #0x1f]
    // 0x8d3094: r0 = 1
    //     0x8d3094: mov             x0, #1
    // 0x8d3098: StoreField: r1->field_27 = r0
    //     0x8d3098: stur            x0, [x1, #0x27]
    // 0x8d309c: mov             x0, x1
    // 0x8d30a0: LeaveFrame
    //     0x8d30a0: mov             SP, fp
    //     0x8d30a4: ldp             fp, lr, [SP], #0x10
    // 0x8d30a8: ret
    //     0x8d30a8: ret             
    // 0x8d30ac: r0 = _DeflaterConfig()
    //     0x8d30ac: bl              #0x8d3294  ; Allocate_DeflaterConfigStub -> _DeflaterConfig (size=0x30)
    // 0x8d30b0: mov             x1, x0
    // 0x8d30b4: r0 = 4
    //     0x8d30b4: mov             x0, #4
    // 0x8d30b8: StoreField: r1->field_7 = r0
    //     0x8d30b8: stur            x0, [x1, #7]
    // 0x8d30bc: StoreField: r1->field_f = r0
    //     0x8d30bc: stur            x0, [x1, #0xf]
    // 0x8d30c0: r5 = 16
    //     0x8d30c0: mov             x5, #0x10
    // 0x8d30c4: StoreField: r1->field_17 = r5
    //     0x8d30c4: stur            x5, [x1, #0x17]
    // 0x8d30c8: StoreField: r1->field_1f = r5
    //     0x8d30c8: stur            x5, [x1, #0x1f]
    // 0x8d30cc: r6 = 2
    //     0x8d30cc: mov             x6, #2
    // 0x8d30d0: StoreField: r1->field_27 = r6
    //     0x8d30d0: stur            x6, [x1, #0x27]
    // 0x8d30d4: mov             x0, x1
    // 0x8d30d8: LeaveFrame
    //     0x8d30d8: mov             SP, fp
    //     0x8d30dc: ldp             fp, lr, [SP], #0x10
    // 0x8d30e0: ret
    //     0x8d30e0: ret             
    // 0x8d30e4: r6 = 2
    //     0x8d30e4: mov             x6, #2
    // 0x8d30e8: r3 = 8
    //     0x8d30e8: mov             x3, #8
    // 0x8d30ec: r5 = 16
    //     0x8d30ec: mov             x5, #0x10
    // 0x8d30f0: r4 = 32
    //     0x8d30f0: mov             x4, #0x20
    // 0x8d30f4: cmp             x2, #7
    // 0x8d30f8: b.gt            #0x8d31d8
    // 0x8d30fc: cmp             x2, #6
    // 0x8d3100: b.gt            #0x8d3188
    // 0x8d3104: cmp             x2, #5
    // 0x8d3108: b.gt            #0x8d3148
    // 0x8d310c: r0 = _DeflaterConfig()
    //     0x8d310c: bl              #0x8d3294  ; Allocate_DeflaterConfigStub -> _DeflaterConfig (size=0x30)
    // 0x8d3110: mov             x1, x0
    // 0x8d3114: r0 = 8
    //     0x8d3114: mov             x0, #8
    // 0x8d3118: StoreField: r1->field_7 = r0
    //     0x8d3118: stur            x0, [x1, #7]
    // 0x8d311c: r2 = 16
    //     0x8d311c: mov             x2, #0x10
    // 0x8d3120: StoreField: r1->field_f = r2
    //     0x8d3120: stur            x2, [x1, #0xf]
    // 0x8d3124: r0 = 32
    //     0x8d3124: mov             x0, #0x20
    // 0x8d3128: StoreField: r1->field_17 = r0
    //     0x8d3128: stur            x0, [x1, #0x17]
    // 0x8d312c: StoreField: r1->field_1f = r0
    //     0x8d312c: stur            x0, [x1, #0x1f]
    // 0x8d3130: r3 = 2
    //     0x8d3130: mov             x3, #2
    // 0x8d3134: StoreField: r1->field_27 = r3
    //     0x8d3134: stur            x3, [x1, #0x27]
    // 0x8d3138: mov             x0, x1
    // 0x8d313c: LeaveFrame
    //     0x8d313c: mov             SP, fp
    //     0x8d3140: ldp             fp, lr, [SP], #0x10
    // 0x8d3144: ret
    //     0x8d3144: ret             
    // 0x8d3148: mov             x0, x3
    // 0x8d314c: mov             x3, x6
    // 0x8d3150: mov             x2, x5
    // 0x8d3154: r0 = _DeflaterConfig()
    //     0x8d3154: bl              #0x8d3294  ; Allocate_DeflaterConfigStub -> _DeflaterConfig (size=0x30)
    // 0x8d3158: r1 = 8
    //     0x8d3158: mov             x1, #8
    // 0x8d315c: StoreField: r0->field_7 = r1
    //     0x8d315c: stur            x1, [x0, #7]
    // 0x8d3160: r1 = 16
    //     0x8d3160: mov             x1, #0x10
    // 0x8d3164: StoreField: r0->field_f = r1
    //     0x8d3164: stur            x1, [x0, #0xf]
    // 0x8d3168: r2 = 128
    //     0x8d3168: mov             x2, #0x80
    // 0x8d316c: StoreField: r0->field_17 = r2
    //     0x8d316c: stur            x2, [x0, #0x17]
    // 0x8d3170: StoreField: r0->field_1f = r2
    //     0x8d3170: stur            x2, [x0, #0x1f]
    // 0x8d3174: r3 = 2
    //     0x8d3174: mov             x3, #2
    // 0x8d3178: StoreField: r0->field_27 = r3
    //     0x8d3178: stur            x3, [x0, #0x27]
    // 0x8d317c: LeaveFrame
    //     0x8d317c: mov             SP, fp
    //     0x8d3180: ldp             fp, lr, [SP], #0x10
    // 0x8d3184: ret
    //     0x8d3184: ret             
    // 0x8d3188: mov             x1, x3
    // 0x8d318c: mov             x3, x6
    // 0x8d3190: mov             x0, x4
    // 0x8d3194: r2 = 128
    //     0x8d3194: mov             x2, #0x80
    // 0x8d3198: r0 = _DeflaterConfig()
    //     0x8d3198: bl              #0x8d3294  ; Allocate_DeflaterConfigStub -> _DeflaterConfig (size=0x30)
    // 0x8d319c: mov             x1, x0
    // 0x8d31a0: r0 = 8
    //     0x8d31a0: mov             x0, #8
    // 0x8d31a4: StoreField: r1->field_7 = r0
    //     0x8d31a4: stur            x0, [x1, #7]
    // 0x8d31a8: r3 = 32
    //     0x8d31a8: mov             x3, #0x20
    // 0x8d31ac: StoreField: r1->field_f = r3
    //     0x8d31ac: stur            x3, [x1, #0xf]
    // 0x8d31b0: r4 = 128
    //     0x8d31b0: mov             x4, #0x80
    // 0x8d31b4: StoreField: r1->field_17 = r4
    //     0x8d31b4: stur            x4, [x1, #0x17]
    // 0x8d31b8: r0 = 256
    //     0x8d31b8: mov             x0, #0x100
    // 0x8d31bc: StoreField: r1->field_1f = r0
    //     0x8d31bc: stur            x0, [x1, #0x1f]
    // 0x8d31c0: r5 = 2
    //     0x8d31c0: mov             x5, #2
    // 0x8d31c4: StoreField: r1->field_27 = r5
    //     0x8d31c4: stur            x5, [x1, #0x27]
    // 0x8d31c8: mov             x0, x1
    // 0x8d31cc: LeaveFrame
    //     0x8d31cc: mov             SP, fp
    //     0x8d31d0: ldp             fp, lr, [SP], #0x10
    // 0x8d31d4: ret
    //     0x8d31d4: ret             
    // 0x8d31d8: mov             x5, x6
    // 0x8d31dc: mov             x3, x4
    // 0x8d31e0: r4 = 128
    //     0x8d31e0: mov             x4, #0x80
    // 0x8d31e4: cmp             x2, #8
    // 0x8d31e8: b.gt            #0x8d3224
    // 0x8d31ec: r0 = _DeflaterConfig()
    //     0x8d31ec: bl              #0x8d3294  ; Allocate_DeflaterConfigStub -> _DeflaterConfig (size=0x30)
    // 0x8d31f0: r1 = 32
    //     0x8d31f0: mov             x1, #0x20
    // 0x8d31f4: StoreField: r0->field_7 = r1
    //     0x8d31f4: stur            x1, [x0, #7]
    // 0x8d31f8: r1 = 128
    //     0x8d31f8: mov             x1, #0x80
    // 0x8d31fc: StoreField: r0->field_f = r1
    //     0x8d31fc: stur            x1, [x0, #0xf]
    // 0x8d3200: r2 = 258
    //     0x8d3200: mov             x2, #0x102
    // 0x8d3204: StoreField: r0->field_17 = r2
    //     0x8d3204: stur            x2, [x0, #0x17]
    // 0x8d3208: r1 = 1024
    //     0x8d3208: mov             x1, #0x400
    // 0x8d320c: StoreField: r0->field_1f = r1
    //     0x8d320c: stur            x1, [x0, #0x1f]
    // 0x8d3210: r3 = 2
    //     0x8d3210: mov             x3, #2
    // 0x8d3214: StoreField: r0->field_27 = r3
    //     0x8d3214: stur            x3, [x0, #0x27]
    // 0x8d3218: LeaveFrame
    //     0x8d3218: mov             SP, fp
    //     0x8d321c: ldp             fp, lr, [SP], #0x10
    // 0x8d3220: ret
    //     0x8d3220: ret             
    // 0x8d3224: mov             x1, x3
    // 0x8d3228: mov             x3, x5
    // 0x8d322c: r2 = 258
    //     0x8d322c: mov             x2, #0x102
    // 0x8d3230: cmp             w0, #0x12
    // 0x8d3234: b.ne            #0x8d3274
    // 0x8d3238: r0 = _DeflaterConfig()
    //     0x8d3238: bl              #0x8d3294  ; Allocate_DeflaterConfigStub -> _DeflaterConfig (size=0x30)
    // 0x8d323c: mov             x1, x0
    // 0x8d3240: r0 = 32
    //     0x8d3240: mov             x0, #0x20
    // 0x8d3244: StoreField: r1->field_7 = r0
    //     0x8d3244: stur            x0, [x1, #7]
    // 0x8d3248: r0 = 258
    //     0x8d3248: mov             x0, #0x102
    // 0x8d324c: StoreField: r1->field_f = r0
    //     0x8d324c: stur            x0, [x1, #0xf]
    // 0x8d3250: StoreField: r1->field_17 = r0
    //     0x8d3250: stur            x0, [x1, #0x17]
    // 0x8d3254: r0 = 4096
    //     0x8d3254: mov             x0, #0x1000
    // 0x8d3258: StoreField: r1->field_1f = r0
    //     0x8d3258: stur            x0, [x1, #0x1f]
    // 0x8d325c: r0 = 2
    //     0x8d325c: mov             x0, #2
    // 0x8d3260: StoreField: r1->field_27 = r0
    //     0x8d3260: stur            x0, [x1, #0x27]
    // 0x8d3264: mov             x0, x1
    // 0x8d3268: LeaveFrame
    //     0x8d3268: mov             SP, fp
    //     0x8d326c: ldp             fp, lr, [SP], #0x10
    // 0x8d3270: ret
    //     0x8d3270: ret             
    // 0x8d3274: r0 = ArchiveException()
    //     0x8d3274: bl              #0x817830  ; AllocateArchiveExceptionStub -> ArchiveException (size=0x14)
    // 0x8d3278: mov             x1, x0
    // 0x8d327c: r0 = "Invalid Deflate parameter"
    //     0x8d327c: add             x0, PP, #0x34, lsl #12  ; [pp+0x34bb0] "Invalid Deflate parameter"
    //     0x8d3280: ldr             x0, [x0, #0xbb0]
    // 0x8d3284: StoreField: r1->field_7 = r0
    //     0x8d3284: stur            w0, [x1, #7]
    // 0x8d3288: mov             x0, x1
    // 0x8d328c: r0 = Throw()
    //     0x8d328c: bl              #0xd67e38  ; ThrowStub
    // 0x8d3290: brk             #0
  }
}

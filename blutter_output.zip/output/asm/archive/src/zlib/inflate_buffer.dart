// lib: , url: package:archive/src/zlib/inflate_buffer.dart

// class id: 1048632, size: 0x8
class :: {
}

// lib: , url: package:archive/src/zlib/_inflate_buffer_io.dart

// class id: 1048627, size: 0x8
class :: {

  static _ inflateBuffer_(/* No info */) {
    // ** addr: 0x7f5774, size: 0x54
    // 0x7f5774: EnterFrame
    //     0x7f5774: stp             fp, lr, [SP, #-0x10]!
    //     0x7f5778: mov             fp, SP
    // 0x7f577c: CheckStackOverflow
    //     0x7f577c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7f5780: cmp             SP, x16
    //     0x7f5784: b.ls            #0x7f57c0
    // 0x7f5788: r1 = <List<int>, List<int>>
    //     0x7f5788: ldr             x1, [PP, #0x5058]  ; [pp+0x5058] TypeArguments: <List<int>, List<int>>
    // 0x7f578c: r0 = ZLibDecoder()
    //     0x7f578c: bl              #0x7f57c8  ; AllocateZLibDecoderStub -> ZLibDecoder (size=0x1c)
    // 0x7f5790: mov             x1, x0
    // 0x7f5794: r0 = 15
    //     0x7f5794: mov             x0, #0xf
    // 0x7f5798: StoreField: r1->field_b = r0
    //     0x7f5798: stur            x0, [x1, #0xb]
    // 0x7f579c: r0 = true
    //     0x7f579c: add             x0, NULL, #0x20  ; true
    // 0x7f57a0: StoreField: r1->field_17 = r0
    //     0x7f57a0: stur            w0, [x1, #0x17]
    // 0x7f57a4: ldr             x16, [fp, #0x10]
    // 0x7f57a8: stp             x16, x1, [SP, #-0x10]!
    // 0x7f57ac: r0 = convert()
    //     0x7f57ac: bl              #0xc2030c  ; [dart:io] ZLibDecoder::convert
    // 0x7f57b0: add             SP, SP, #0x10
    // 0x7f57b4: LeaveFrame
    //     0x7f57b4: mov             SP, fp
    //     0x7f57b8: ldp             fp, lr, [SP], #0x10
    // 0x7f57bc: ret
    //     0x7f57bc: ret             
    // 0x7f57c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f57c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f57c4: b               #0x7f5788
  }
}

// lib: , url: package:archive/src/zlib/huffman_table.dart

// class id: 1048630, size: 0x8
class :: {
}

// class id: 4989, size: 0x1c, field offset: 0x8
class HuffmanTable extends Object {

  late Uint32List table; // offset: 0x8

  _ HuffmanTable(/* No info */) {
    // ** addr: 0x816d94, size: 0x464
    // 0x816d94: EnterFrame
    //     0x816d94: stp             fp, lr, [SP, #-0x10]!
    //     0x816d98: mov             fp, SP
    // 0x816d9c: AllocStack(0x38)
    //     0x816d9c: sub             SP, SP, #0x38
    // 0x816da0: r2 = Sentinel
    //     0x816da0: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x816da4: r1 = 0
    //     0x816da4: mov             x1, #0
    // 0x816da8: r0 = 2147483647
    //     0x816da8: mov             x0, #0x7fffffff
    // 0x816dac: CheckStackOverflow
    //     0x816dac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x816db0: cmp             SP, x16
    //     0x816db4: b.ls            #0x81718c
    // 0x816db8: ldr             x3, [fp, #0x18]
    // 0x816dbc: StoreField: r3->field_7 = r2
    //     0x816dbc: stur            w2, [x3, #7]
    // 0x816dc0: StoreField: r3->field_b = r1
    //     0x816dc0: stur            x1, [x3, #0xb]
    // 0x816dc4: StoreField: r3->field_13 = r0
    //     0x816dc4: stur            x0, [x3, #0x13]
    // 0x816dc8: ldr             x1, [fp, #0x10]
    // 0x816dcc: r0 = LoadClassIdInstr(r1)
    //     0x816dcc: ldur            x0, [x1, #-1]
    //     0x816dd0: ubfx            x0, x0, #0xc, #0x14
    // 0x816dd4: SaveReg r1
    //     0x816dd4: str             x1, [SP, #-8]!
    // 0x816dd8: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x816dd8: mov             x17, #0xb8ea
    //     0x816ddc: add             lr, x0, x17
    //     0x816de0: ldr             lr, [x21, lr, lsl #3]
    //     0x816de4: blr             lr
    // 0x816de8: add             SP, SP, #8
    // 0x816dec: r2 = LoadInt32Instr(r0)
    //     0x816dec: sbfx            x2, x0, #1, #0x1f
    // 0x816df0: stur            x2, [fp, #-0x18]
    // 0x816df4: ldr             x3, [fp, #0x18]
    // 0x816df8: r5 = 0
    //     0x816df8: mov             x5, #0
    // 0x816dfc: ldr             x4, [fp, #0x10]
    // 0x816e00: stur            x5, [fp, #-0x10]
    // 0x816e04: CheckStackOverflow
    //     0x816e04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x816e08: cmp             SP, x16
    //     0x816e0c: b.ls            #0x817194
    // 0x816e10: cmp             x5, x2
    // 0x816e14: b.ge            #0x816f40
    // 0x816e18: r0 = BoxInt64Instr(r5)
    //     0x816e18: sbfiz           x0, x5, #1, #0x1f
    //     0x816e1c: cmp             x5, x0, asr #1
    //     0x816e20: b.eq            #0x816e2c
    //     0x816e24: bl              #0xd69bb8
    //     0x816e28: stur            x5, [x0, #7]
    // 0x816e2c: mov             x1, x0
    // 0x816e30: stur            x1, [fp, #-8]
    // 0x816e34: r0 = LoadClassIdInstr(r4)
    //     0x816e34: ldur            x0, [x4, #-1]
    //     0x816e38: ubfx            x0, x0, #0xc, #0x14
    // 0x816e3c: stp             x1, x4, [SP, #-0x10]!
    // 0x816e40: r0 = GDT[cid_x0 + -0xd83]()
    //     0x816e40: sub             lr, x0, #0xd83
    //     0x816e44: ldr             lr, [x21, lr, lsl #3]
    //     0x816e48: blr             lr
    // 0x816e4c: add             SP, SP, #0x10
    // 0x816e50: ldr             x1, [fp, #0x18]
    // 0x816e54: LoadField: r2 = r1->field_b
    //     0x816e54: ldur            x2, [x1, #0xb]
    // 0x816e58: r3 = LoadInt32Instr(r0)
    //     0x816e58: sbfx            x3, x0, #1, #0x1f
    //     0x816e5c: tbz             w0, #0, #0x816e64
    //     0x816e60: ldur            x3, [x0, #7]
    // 0x816e64: cmp             x3, x2
    // 0x816e68: b.le            #0x816ea8
    // 0x816e6c: ldr             x2, [fp, #0x10]
    // 0x816e70: r0 = LoadClassIdInstr(r2)
    //     0x816e70: ldur            x0, [x2, #-1]
    //     0x816e74: ubfx            x0, x0, #0xc, #0x14
    // 0x816e78: ldur            x16, [fp, #-8]
    // 0x816e7c: stp             x16, x2, [SP, #-0x10]!
    // 0x816e80: r0 = GDT[cid_x0 + -0xd83]()
    //     0x816e80: sub             lr, x0, #0xd83
    //     0x816e84: ldr             lr, [x21, lr, lsl #3]
    //     0x816e88: blr             lr
    // 0x816e8c: add             SP, SP, #0x10
    // 0x816e90: r1 = LoadInt32Instr(r0)
    //     0x816e90: sbfx            x1, x0, #1, #0x1f
    //     0x816e94: tbz             w0, #0, #0x816e9c
    //     0x816e98: ldur            x1, [x0, #7]
    // 0x816e9c: ldr             x2, [fp, #0x18]
    // 0x816ea0: StoreField: r2->field_b = r1
    //     0x816ea0: stur            x1, [x2, #0xb]
    // 0x816ea4: b               #0x816eac
    // 0x816ea8: mov             x2, x1
    // 0x816eac: ldr             x1, [fp, #0x10]
    // 0x816eb0: r0 = LoadClassIdInstr(r1)
    //     0x816eb0: ldur            x0, [x1, #-1]
    //     0x816eb4: ubfx            x0, x0, #0xc, #0x14
    // 0x816eb8: ldur            x16, [fp, #-8]
    // 0x816ebc: stp             x16, x1, [SP, #-0x10]!
    // 0x816ec0: r0 = GDT[cid_x0 + -0xd83]()
    //     0x816ec0: sub             lr, x0, #0xd83
    //     0x816ec4: ldr             lr, [x21, lr, lsl #3]
    //     0x816ec8: blr             lr
    // 0x816ecc: add             SP, SP, #0x10
    // 0x816ed0: ldr             x1, [fp, #0x18]
    // 0x816ed4: LoadField: r2 = r1->field_13
    //     0x816ed4: ldur            x2, [x1, #0x13]
    // 0x816ed8: r3 = LoadInt32Instr(r0)
    //     0x816ed8: sbfx            x3, x0, #1, #0x1f
    //     0x816edc: tbz             w0, #0, #0x816ee4
    //     0x816ee0: ldur            x3, [x0, #7]
    // 0x816ee4: cmp             x3, x2
    // 0x816ee8: b.ge            #0x816f28
    // 0x816eec: ldr             x2, [fp, #0x10]
    // 0x816ef0: r0 = LoadClassIdInstr(r2)
    //     0x816ef0: ldur            x0, [x2, #-1]
    //     0x816ef4: ubfx            x0, x0, #0xc, #0x14
    // 0x816ef8: ldur            x16, [fp, #-8]
    // 0x816efc: stp             x16, x2, [SP, #-0x10]!
    // 0x816f00: r0 = GDT[cid_x0 + -0xd83]()
    //     0x816f00: sub             lr, x0, #0xd83
    //     0x816f04: ldr             lr, [x21, lr, lsl #3]
    //     0x816f08: blr             lr
    // 0x816f0c: add             SP, SP, #0x10
    // 0x816f10: r1 = LoadInt32Instr(r0)
    //     0x816f10: sbfx            x1, x0, #1, #0x1f
    //     0x816f14: tbz             w0, #0, #0x816f1c
    //     0x816f18: ldur            x1, [x0, #7]
    // 0x816f1c: ldr             x2, [fp, #0x18]
    // 0x816f20: StoreField: r2->field_13 = r1
    //     0x816f20: stur            x1, [x2, #0x13]
    // 0x816f24: b               #0x816f2c
    // 0x816f28: mov             x2, x1
    // 0x816f2c: ldur            x0, [fp, #-0x10]
    // 0x816f30: add             x5, x0, #1
    // 0x816f34: mov             x3, x2
    // 0x816f38: ldur            x2, [fp, #-0x18]
    // 0x816f3c: b               #0x816dfc
    // 0x816f40: mov             x2, x3
    // 0x816f44: r0 = 1
    //     0x816f44: mov             x0, #1
    // 0x816f48: LoadField: r1 = r2->field_b
    //     0x816f48: ldur            x1, [x2, #0xb]
    // 0x816f4c: cmp             x1, #0x3f
    // 0x816f50: b.hi            #0x81719c
    // 0x816f54: lsl             x3, x0, x1
    // 0x816f58: stur            x3, [fp, #-0x10]
    // 0x816f5c: r0 = BoxInt64Instr(r3)
    //     0x816f5c: sbfiz           x0, x3, #1, #0x1f
    //     0x816f60: cmp             x3, x0, asr #1
    //     0x816f64: b.eq            #0x816f70
    //     0x816f68: bl              #0xd69bb8
    //     0x816f6c: stur            x3, [x0, #7]
    // 0x816f70: mov             x4, x0
    // 0x816f74: r0 = AllocateUint32Array()
    //     0x816f74: bl              #0xd691a0  ; AllocateUint32ArrayStub
    // 0x816f78: ldr             x2, [fp, #0x18]
    // 0x816f7c: StoreField: r2->field_7 = r0
    //     0x816f7c: stur            w0, [x2, #7]
    //     0x816f80: ldurb           w16, [x2, #-1]
    //     0x816f84: ldurb           w17, [x0, #-1]
    //     0x816f88: and             x16, x17, x16, lsr #2
    //     0x816f8c: tst             x16, HEAP, lsr #32
    //     0x816f90: b.eq            #0x816f98
    //     0x816f94: bl              #0xd6828c
    // 0x816f98: ldur            x3, [fp, #-0x10]
    // 0x816f9c: r7 = 1
    //     0x816f9c: mov             x7, #1
    // 0x816fa0: r0 = 0
    //     0x816fa0: mov             x0, #0
    // 0x816fa4: r6 = 2
    //     0x816fa4: mov             x6, #2
    // 0x816fa8: ldr             x4, [fp, #0x10]
    // 0x816fac: ldur            x5, [fp, #-0x18]
    // 0x816fb0: stur            x7, [fp, #-0x30]
    // 0x816fb4: stur            x6, [fp, #-0x38]
    // 0x816fb8: CheckStackOverflow
    //     0x816fb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x816fbc: cmp             SP, x16
    //     0x816fc0: b.ls            #0x8171c8
    // 0x816fc4: LoadField: r1 = r2->field_b
    //     0x816fc4: ldur            x1, [x2, #0xb]
    // 0x816fc8: cmp             x7, x1
    // 0x816fcc: b.gt            #0x81717c
    // 0x816fd0: mov             x9, x0
    // 0x816fd4: r8 = 0
    //     0x816fd4: mov             x8, #0
    // 0x816fd8: stur            x9, [fp, #-0x20]
    // 0x816fdc: stur            x8, [fp, #-0x28]
    // 0x816fe0: CheckStackOverflow
    //     0x816fe0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x816fe4: cmp             SP, x16
    //     0x816fe8: b.ls            #0x8171d0
    // 0x816fec: cmp             x8, x5
    // 0x816ff0: b.ge            #0x81714c
    // 0x816ff4: r0 = BoxInt64Instr(r8)
    //     0x816ff4: sbfiz           x0, x8, #1, #0x1f
    //     0x816ff8: cmp             x8, x0, asr #1
    //     0x816ffc: b.eq            #0x817008
    //     0x817000: bl              #0xd69bb8
    //     0x817004: stur            x8, [x0, #7]
    // 0x817008: r1 = LoadClassIdInstr(r4)
    //     0x817008: ldur            x1, [x4, #-1]
    //     0x81700c: ubfx            x1, x1, #0xc, #0x14
    // 0x817010: stp             x0, x4, [SP, #-0x10]!
    // 0x817014: mov             x0, x1
    // 0x817018: r0 = GDT[cid_x0 + -0xd83]()
    //     0x817018: sub             lr, x0, #0xd83
    //     0x81701c: ldr             lr, [x21, lr, lsl #3]
    //     0x817020: blr             lr
    // 0x817024: add             SP, SP, #0x10
    // 0x817028: r2 = LoadInt32Instr(r0)
    //     0x817028: sbfx            x2, x0, #1, #0x1f
    //     0x81702c: tbz             w0, #0, #0x817034
    //     0x817030: ldur            x2, [x0, #7]
    // 0x817034: ldur            x3, [fp, #-0x30]
    // 0x817038: cmp             x2, x3
    // 0x81703c: b.ne            #0x817114
    // 0x817040: ldur            x5, [fp, #-0x20]
    // 0x817044: r6 = 0
    //     0x817044: mov             x6, #0
    // 0x817048: r4 = 0
    //     0x817048: mov             x4, #0
    // 0x81704c: r2 = 1
    //     0x81704c: mov             x2, #1
    // 0x817050: CheckStackOverflow
    //     0x817050: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x817054: cmp             SP, x16
    //     0x817058: b.ls            #0x8171d8
    // 0x81705c: cmp             x4, x3
    // 0x817060: b.ge            #0x817090
    // 0x817064: lsl             x7, x6, #1
    // 0x817068: mov             x8, x5
    // 0x81706c: ubfx            x8, x8, #0, #0x20
    // 0x817070: and             x10, x8, x2
    // 0x817074: ubfx            x10, x10, #0, #0x20
    // 0x817078: orr             x6, x7, x10
    // 0x81707c: asr             x0, x5, #1
    // 0x817080: add             x1, x4, #1
    // 0x817084: mov             x5, x0
    // 0x817088: mov             x4, x1
    // 0x81708c: b               #0x817050
    // 0x817090: mov             x8, x6
    // 0x817094: ldr             x4, [fp, #0x18]
    // 0x817098: ldur            x5, [fp, #-0x10]
    // 0x81709c: ldur            x6, [fp, #-0x38]
    // 0x8170a0: ldur            x7, [fp, #-0x28]
    // 0x8170a4: CheckStackOverflow
    //     0x8170a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8170a8: cmp             SP, x16
    //     0x8170ac: b.ls            #0x8171e0
    // 0x8170b0: cmp             x8, x5
    // 0x8170b4: b.ge            #0x817104
    // 0x8170b8: LoadField: r10 = r4->field_7
    //     0x8170b8: ldur            w10, [x4, #7]
    // 0x8170bc: DecompressPointer r10
    //     0x8170bc: add             x10, x10, HEAP, lsl #32
    // 0x8170c0: r16 = Sentinel
    //     0x8170c0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8170c4: cmp             w10, w16
    // 0x8170c8: b.eq            #0x8171e8
    // 0x8170cc: lsl             x9, x3, #0x10
    // 0x8170d0: orr             x11, x9, x7
    // 0x8170d4: LoadField: r9 = r10->field_13
    //     0x8170d4: ldur            w9, [x10, #0x13]
    // 0x8170d8: DecompressPointer r9
    //     0x8170d8: add             x9, x9, HEAP, lsl #32
    // 0x8170dc: r0 = LoadInt32Instr(r9)
    //     0x8170dc: sbfx            x0, x9, #1, #0x1f
    // 0x8170e0: mov             x1, x8
    // 0x8170e4: cmp             x1, x0
    // 0x8170e8: b.hs            #0x8171f4
    // 0x8170ec: ubfx            x11, x11, #0, #0x20
    // 0x8170f0: ArrayStore: r10[r8] = r11  ; Unknown_4
    //     0x8170f0: add             x1, x10, x8, lsl #2
    //     0x8170f4: stur            w11, [x1, #0x17]
    // 0x8170f8: add             x0, x8, x6
    // 0x8170fc: mov             x8, x0
    // 0x817100: b               #0x8170a4
    // 0x817104: ldur            x1, [fp, #-0x20]
    // 0x817108: add             x0, x1, #1
    // 0x81710c: mov             x9, x0
    // 0x817110: b               #0x817130
    // 0x817114: ldr             x4, [fp, #0x18]
    // 0x817118: ldur            x5, [fp, #-0x10]
    // 0x81711c: ldur            x6, [fp, #-0x38]
    // 0x817120: ldur            x1, [fp, #-0x20]
    // 0x817124: ldur            x7, [fp, #-0x28]
    // 0x817128: r2 = 1
    //     0x817128: mov             x2, #1
    // 0x81712c: mov             x9, x1
    // 0x817130: add             x8, x7, #1
    // 0x817134: mov             x2, x4
    // 0x817138: ldr             x4, [fp, #0x10]
    // 0x81713c: mov             x7, x3
    // 0x817140: mov             x3, x5
    // 0x817144: ldur            x5, [fp, #-0x18]
    // 0x817148: b               #0x816fd8
    // 0x81714c: mov             x4, x2
    // 0x817150: mov             x5, x3
    // 0x817154: mov             x3, x7
    // 0x817158: mov             x1, x9
    // 0x81715c: r2 = 1
    //     0x81715c: mov             x2, #1
    // 0x817160: add             x7, x3, #1
    // 0x817164: lsl             x0, x1, #1
    // 0x817168: lsl             x1, x6, #1
    // 0x81716c: mov             x6, x1
    // 0x817170: mov             x2, x4
    // 0x817174: mov             x3, x5
    // 0x817178: b               #0x816fa8
    // 0x81717c: r0 = Null
    //     0x81717c: mov             x0, NULL
    // 0x817180: LeaveFrame
    //     0x817180: mov             SP, fp
    //     0x817184: ldp             fp, lr, [SP], #0x10
    // 0x817188: ret
    //     0x817188: ret             
    // 0x81718c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81718c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x817190: b               #0x816db8
    // 0x817194: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x817194: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x817198: b               #0x816e10
    // 0x81719c: tbnz            x1, #0x3f, #0x8171a8
    // 0x8171a0: mov             x3, xzr
    // 0x8171a4: b               #0x816f58
    // 0x8171a8: str             x1, [THR, #0xc0]  ; THR::
    // 0x8171ac: stp             x1, x2, [SP, #-0x10]!
    // 0x8171b0: SaveReg r0
    //     0x8171b0: str             x0, [SP, #-8]!
    // 0x8171b4: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x8171b8: r4 = 0
    //     0x8171b8: mov             x4, #0
    // 0x8171bc: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8171c0: blr             lr
    // 0x8171c4: brk             #0
    // 0x8171c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8171c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8171cc: b               #0x816fc4
    // 0x8171d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8171d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8171d4: b               #0x816fec
    // 0x8171d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8171d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8171dc: b               #0x81705c
    // 0x8171e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8171e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8171e4: b               #0x8170b0
    // 0x8171e8: r9 = table
    //     0x8171e8: add             x9, PP, #0x3b, lsl #12  ; [pp+0x3b188] Field <HuffmanTable.table>: late (offset: 0x8)
    //     0x8171ec: ldr             x9, [x9, #0x188]
    // 0x8171f0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8171f0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8171f4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8171f4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

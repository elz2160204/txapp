// lib: , url: package:archive/src/zlib/zlib_decoder_base.dart

// class id: 1048633, size: 0x8
class :: {
}

// class id: 4994, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class ZLibDecoderBase extends Object {
}

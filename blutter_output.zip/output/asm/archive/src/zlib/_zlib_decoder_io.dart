// lib: , url: package:archive/src/zlib/_zlib_decoder_io.dart

// class id: 1048628, size: 0x8
class :: {
}

// class id: 4995, size: 0x8, field offset: 0x8
//   const constructor, 
class _ZLibDecoder extends ZLibDecoderBase {

  _ decodeBytes(/* No info */) {
    // ** addr: 0xb9ab60, size: 0x88
    // 0xb9ab60: EnterFrame
    //     0xb9ab60: stp             fp, lr, [SP, #-0x10]!
    //     0xb9ab64: mov             fp, SP
    // 0xb9ab68: AllocStack(0x8)
    //     0xb9ab68: sub             SP, SP, #8
    // 0xb9ab6c: CheckStackOverflow
    //     0xb9ab6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb9ab70: cmp             SP, x16
    //     0xb9ab74: b.ls            #0xb9abe0
    // 0xb9ab78: r1 = <List<int>, List<int>>
    //     0xb9ab78: ldr             x1, [PP, #0x5058]  ; [pp+0x5058] TypeArguments: <List<int>, List<int>>
    // 0xb9ab7c: r0 = ZLibCodec()
    //     0xb9ab7c: bl              #0xb9ac8c  ; AllocateZLibCodecStub -> ZLibCodec (size=0x34)
    // 0xb9ab80: mov             x1, x0
    // 0xb9ab84: r0 = 6
    //     0xb9ab84: mov             x0, #6
    // 0xb9ab88: stur            x1, [fp, #-8]
    // 0xb9ab8c: StoreField: r1->field_b = r0
    //     0xb9ab8c: stur            x0, [x1, #0xb]
    // 0xb9ab90: r0 = 15
    //     0xb9ab90: mov             x0, #0xf
    // 0xb9ab94: StoreField: r1->field_23 = r0
    //     0xb9ab94: stur            x0, [x1, #0x23]
    // 0xb9ab98: r0 = 8
    //     0xb9ab98: mov             x0, #8
    // 0xb9ab9c: StoreField: r1->field_13 = r0
    //     0xb9ab9c: stur            x0, [x1, #0x13]
    // 0xb9aba0: r0 = 0
    //     0xb9aba0: mov             x0, #0
    // 0xb9aba4: StoreField: r1->field_1b = r0
    //     0xb9aba4: stur            x0, [x1, #0x1b]
    // 0xb9aba8: r0 = false
    //     0xb9aba8: add             x0, NULL, #0x30  ; false
    // 0xb9abac: StoreField: r1->field_2b = r0
    //     0xb9abac: stur            w0, [x1, #0x2b]
    // 0xb9abb0: r0 = _validateZLibStrategy()
    //     0xb9abb0: bl              #0xb9abe8  ; [dart:io] ::_validateZLibStrategy
    // 0xb9abb4: ldur            x16, [fp, #-8]
    // 0xb9abb8: SaveReg r16
    //     0xb9abb8: str             x16, [SP, #-8]!
    // 0xb9abbc: r0 = decoder()
    //     0xb9abbc: bl              #0xbfdc88  ; [dart:io] GZipCodec::decoder
    // 0xb9abc0: add             SP, SP, #8
    // 0xb9abc4: ldr             x16, [fp, #0x10]
    // 0xb9abc8: stp             x16, x0, [SP, #-0x10]!
    // 0xb9abcc: r0 = convert()
    //     0xb9abcc: bl              #0xc2030c  ; [dart:io] ZLibDecoder::convert
    // 0xb9abd0: add             SP, SP, #0x10
    // 0xb9abd4: LeaveFrame
    //     0xb9abd4: mov             SP, fp
    //     0xb9abd8: ldp             fp, lr, [SP], #0x10
    // 0xb9abdc: ret
    //     0xb9abdc: ret             
    // 0xb9abe0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9abe0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9abe4: b               #0xb9ab78
  }
}

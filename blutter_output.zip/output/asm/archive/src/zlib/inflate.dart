// lib: , url: package:archive/src/zlib/inflate.dart

// class id: 1048631, size: 0x8
class :: {
}

// class id: 4988, size: 0x2c, field offset: 0x8
class Inflate extends Object {

  late InputStreamBase input; // offset: 0x8

  _ getBytes(/* No info */) {
    // ** addr: 0x815110, size: 0x40
    // 0x815110: EnterFrame
    //     0x815110: stp             fp, lr, [SP, #-0x10]!
    //     0x815114: mov             fp, SP
    // 0x815118: CheckStackOverflow
    //     0x815118: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81511c: cmp             SP, x16
    //     0x815120: b.ls            #0x815148
    // 0x815124: ldr             x0, [fp, #0x10]
    // 0x815128: LoadField: r1 = r0->field_f
    //     0x815128: ldur            w1, [x0, #0xf]
    // 0x81512c: DecompressPointer r1
    //     0x81512c: add             x1, x1, HEAP, lsl #32
    // 0x815130: SaveReg r1
    //     0x815130: str             x1, [SP, #-8]!
    // 0x815134: r0 = getBytes()
    //     0x815134: bl              #0x815168  ; [package:archive/src/util/output_stream.dart] OutputStream::getBytes
    // 0x815138: add             SP, SP, #8
    // 0x81513c: LeaveFrame
    //     0x81513c: mov             SP, fp
    //     0x815140: ldp             fp, lr, [SP], #0x10
    // 0x815144: ret
    //     0x815144: ret             
    // 0x815148: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x815148: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81514c: b               #0x815124
  }
  _ Inflate.buffer(/* No info */) {
    // ** addr: 0x8151e4, size: 0x140
    // 0x8151e4: EnterFrame
    //     0x8151e4: stp             fp, lr, [SP, #-0x10]!
    //     0x8151e8: mov             fp, SP
    // 0x8151ec: AllocStack(0x8)
    //     0x8151ec: sub             SP, SP, #8
    // 0x8151f0: r1 = false
    //     0x8151f0: add             x1, NULL, #0x30  ; false
    // 0x8151f4: r0 = 0
    //     0x8151f4: mov             x0, #0
    // 0x8151f8: CheckStackOverflow
    //     0x8151f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8151fc: cmp             SP, x16
    //     0x815200: b.ls            #0x81531c
    // 0x815204: ldr             x2, [fp, #0x20]
    // 0x815208: StoreField: r2->field_b = r1
    //     0x815208: stur            w1, [x2, #0xb]
    // 0x81520c: StoreField: r2->field_13 = r0
    //     0x81520c: stur            x0, [x2, #0x13]
    // 0x815210: StoreField: r2->field_1b = r0
    //     0x815210: stur            x0, [x2, #0x1b]
    // 0x815214: r0 = HuffmanTable()
    //     0x815214: bl              #0x8171f8  ; AllocateHuffmanTableStub -> HuffmanTable (size=0x1c)
    // 0x815218: stur            x0, [fp, #-8]
    // 0x81521c: r16 = const [0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8]
    //     0x81521c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b158] List<int>(288)
    //     0x815220: ldr             x16, [x16, #0x158]
    // 0x815224: stp             x16, x0, [SP, #-0x10]!
    // 0x815228: r0 = HuffmanTable()
    //     0x815228: bl              #0x816d94  ; [package:archive/src/zlib/huffman_table.dart] HuffmanTable::HuffmanTable
    // 0x81522c: add             SP, SP, #0x10
    // 0x815230: ldur            x0, [fp, #-8]
    // 0x815234: ldr             x1, [fp, #0x20]
    // 0x815238: StoreField: r1->field_23 = r0
    //     0x815238: stur            w0, [x1, #0x23]
    //     0x81523c: ldurb           w16, [x1, #-1]
    //     0x815240: ldurb           w17, [x0, #-1]
    //     0x815244: and             x16, x17, x16, lsr #2
    //     0x815248: tst             x16, HEAP, lsr #32
    //     0x81524c: b.eq            #0x815254
    //     0x815250: bl              #0xd6826c
    // 0x815254: r0 = HuffmanTable()
    //     0x815254: bl              #0x8171f8  ; AllocateHuffmanTableStub -> HuffmanTable (size=0x1c)
    // 0x815258: stur            x0, [fp, #-8]
    // 0x81525c: r16 = const [0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5]
    //     0x81525c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b160] List<int>(30)
    //     0x815260: ldr             x16, [x16, #0x160]
    // 0x815264: stp             x16, x0, [SP, #-0x10]!
    // 0x815268: r0 = HuffmanTable()
    //     0x815268: bl              #0x816d94  ; [package:archive/src/zlib/huffman_table.dart] HuffmanTable::HuffmanTable
    // 0x81526c: add             SP, SP, #0x10
    // 0x815270: ldur            x0, [fp, #-8]
    // 0x815274: ldr             x1, [fp, #0x20]
    // 0x815278: StoreField: r1->field_27 = r0
    //     0x815278: stur            w0, [x1, #0x27]
    //     0x81527c: ldurb           w16, [x1, #-1]
    //     0x815280: ldurb           w17, [x0, #-1]
    //     0x815284: and             x16, x17, x16, lsr #2
    //     0x815288: tst             x16, HEAP, lsr #32
    //     0x81528c: b.eq            #0x815294
    //     0x815290: bl              #0xd6826c
    // 0x815294: ldr             x0, [fp, #0x18]
    // 0x815298: StoreField: r1->field_7 = r0
    //     0x815298: stur            w0, [x1, #7]
    //     0x81529c: ldurb           w16, [x1, #-1]
    //     0x8152a0: ldurb           w17, [x0, #-1]
    //     0x8152a4: and             x16, x17, x16, lsr #2
    //     0x8152a8: tst             x16, HEAP, lsr #32
    //     0x8152ac: b.eq            #0x8152b4
    //     0x8152b0: bl              #0xd6826c
    // 0x8152b4: r0 = OutputStream()
    //     0x8152b4: bl              #0x816d88  ; AllocateOutputStreamStub -> OutputStream (size=0x1c)
    // 0x8152b8: stur            x0, [fp, #-8]
    // 0x8152bc: ldr             x16, [fp, #0x10]
    // 0x8152c0: stp             x16, x0, [SP, #-0x10]!
    // 0x8152c4: r4 = const [0, 0x2, 0x2, 0x1, size, 0x1, null]
    //     0x8152c4: add             x4, PP, #0x27, lsl #12  ; [pp+0x27e20] List(7) [0, 0x2, 0x2, 0x1, "size", 0x1, Null]
    //     0x8152c8: ldr             x4, [x4, #0xe20]
    // 0x8152cc: r0 = OutputStream()
    //     0x8152cc: bl              #0x816c50  ; [package:archive/src/util/output_stream.dart] OutputStream::OutputStream
    // 0x8152d0: add             SP, SP, #0x10
    // 0x8152d4: ldur            x0, [fp, #-8]
    // 0x8152d8: ldr             x1, [fp, #0x20]
    // 0x8152dc: StoreField: r1->field_f = r0
    //     0x8152dc: stur            w0, [x1, #0xf]
    //     0x8152e0: ldurb           w16, [x1, #-1]
    //     0x8152e4: ldurb           w17, [x0, #-1]
    //     0x8152e8: and             x16, x17, x16, lsr #2
    //     0x8152ec: tst             x16, HEAP, lsr #32
    //     0x8152f0: b.eq            #0x8152f8
    //     0x8152f4: bl              #0xd6826c
    // 0x8152f8: r0 = true
    //     0x8152f8: add             x0, NULL, #0x20  ; true
    // 0x8152fc: StoreField: r1->field_b = r0
    //     0x8152fc: stur            w0, [x1, #0xb]
    // 0x815300: SaveReg r1
    //     0x815300: str             x1, [SP, #-8]!
    // 0x815304: r0 = _inflate()
    //     0x815304: bl              #0x815324  ; [package:archive/src/zlib/inflate.dart] Inflate::_inflate
    // 0x815308: add             SP, SP, #8
    // 0x81530c: r0 = Null
    //     0x81530c: mov             x0, NULL
    // 0x815310: LeaveFrame
    //     0x815310: mov             SP, fp
    //     0x815314: ldp             fp, lr, [SP], #0x10
    // 0x815318: ret
    //     0x815318: ret             
    // 0x81531c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81531c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x815320: b               #0x815204
  }
  _ _inflate(/* No info */) {
    // ** addr: 0x815324, size: 0xe4
    // 0x815324: EnterFrame
    //     0x815324: stp             fp, lr, [SP, #-0x10]!
    //     0x815328: mov             fp, SP
    // 0x81532c: r0 = 0
    //     0x81532c: mov             x0, #0
    // 0x815330: CheckStackOverflow
    //     0x815330: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x815334: cmp             SP, x16
    //     0x815338: b.ls            #0x8153e0
    // 0x81533c: ldr             x1, [fp, #0x10]
    // 0x815340: StoreField: r1->field_13 = r0
    //     0x815340: stur            x0, [x1, #0x13]
    // 0x815344: StoreField: r1->field_1b = r0
    //     0x815344: stur            x0, [x1, #0x1b]
    // 0x815348: LoadField: r0 = r1->field_b
    //     0x815348: ldur            w0, [x1, #0xb]
    // 0x81534c: DecompressPointer r0
    //     0x81534c: add             x0, x0, HEAP, lsl #32
    // 0x815350: tbz             w0, #4, #0x815364
    // 0x815354: r0 = Null
    //     0x815354: mov             x0, NULL
    // 0x815358: LeaveFrame
    //     0x815358: mov             SP, fp
    //     0x81535c: ldp             fp, lr, [SP], #0x10
    // 0x815360: ret
    //     0x815360: ret             
    // 0x815364: CheckStackOverflow
    //     0x815364: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x815368: cmp             SP, x16
    //     0x81536c: b.ls            #0x8153e8
    // 0x815370: LoadField: r0 = r1->field_7
    //     0x815370: ldur            w0, [x1, #7]
    // 0x815374: DecompressPointer r0
    //     0x815374: add             x0, x0, HEAP, lsl #32
    // 0x815378: r16 = Sentinel
    //     0x815378: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x81537c: cmp             w0, w16
    // 0x815380: b.eq            #0x8153f0
    // 0x815384: LoadField: r2 = r0->field_b
    //     0x815384: ldur            x2, [x0, #0xb]
    // 0x815388: LoadField: r3 = r0->field_13
    //     0x815388: ldur            x3, [x0, #0x13]
    // 0x81538c: LoadField: r4 = r0->field_23
    //     0x81538c: ldur            w4, [x0, #0x23]
    // 0x815390: DecompressPointer r4
    //     0x815390: add             x4, x4, HEAP, lsl #32
    // 0x815394: r16 = Sentinel
    //     0x815394: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x815398: cmp             w4, w16
    // 0x81539c: b.eq            #0x8153fc
    // 0x8153a0: r0 = LoadInt32Instr(r4)
    //     0x8153a0: sbfx            x0, x4, #1, #0x1f
    //     0x8153a4: tbz             w4, #0, #0x8153ac
    //     0x8153a8: ldur            x0, [x4, #7]
    // 0x8153ac: add             x4, x3, x0
    // 0x8153b0: cmp             x2, x4
    // 0x8153b4: b.ge            #0x8153d0
    // 0x8153b8: SaveReg r1
    //     0x8153b8: str             x1, [SP, #-8]!
    // 0x8153bc: r0 = _parseBlock()
    //     0x8153bc: bl              #0x815408  ; [package:archive/src/zlib/inflate.dart] Inflate::_parseBlock
    // 0x8153c0: add             SP, SP, #8
    // 0x8153c4: tbnz            w0, #4, #0x8153d0
    // 0x8153c8: ldr             x1, [fp, #0x10]
    // 0x8153cc: b               #0x815364
    // 0x8153d0: r0 = Null
    //     0x8153d0: mov             x0, NULL
    // 0x8153d4: LeaveFrame
    //     0x8153d4: mov             SP, fp
    //     0x8153d8: ldp             fp, lr, [SP], #0x10
    // 0x8153dc: ret
    //     0x8153dc: ret             
    // 0x8153e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8153e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8153e4: b               #0x81533c
    // 0x8153e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8153e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8153ec: b               #0x815370
    // 0x8153f0: r9 = input
    //     0x8153f0: add             x9, PP, #0x3b, lsl #12  ; [pp+0x3b168] Field <Inflate.input>: late (offset: 0x8)
    //     0x8153f4: ldr             x9, [x9, #0x168]
    // 0x8153f8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8153f8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8153fc: r9 = _length
    //     0x8153fc: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a20] Field <InputStream._length@54080104>: late (offset: 0x24)
    //     0x815400: ldr             x9, [x9, #0xa20]
    // 0x815404: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x815404: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _parseBlock(/* No info */) {
    // ** addr: 0x815408, size: 0x1b4
    // 0x815408: EnterFrame
    //     0x815408: stp             fp, lr, [SP, #-0x10]!
    //     0x81540c: mov             fp, SP
    // 0x815410: AllocStack(0x8)
    //     0x815410: sub             SP, SP, #8
    // 0x815414: CheckStackOverflow
    //     0x815414: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x815418: cmp             SP, x16
    //     0x81541c: b.ls            #0x81559c
    // 0x815420: ldr             x0, [fp, #0x10]
    // 0x815424: LoadField: r1 = r0->field_7
    //     0x815424: ldur            w1, [x0, #7]
    // 0x815428: DecompressPointer r1
    //     0x815428: add             x1, x1, HEAP, lsl #32
    // 0x81542c: r16 = Sentinel
    //     0x81542c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x815430: cmp             w1, w16
    // 0x815434: b.eq            #0x8155a4
    // 0x815438: LoadField: r2 = r1->field_b
    //     0x815438: ldur            x2, [x1, #0xb]
    // 0x81543c: LoadField: r3 = r1->field_13
    //     0x81543c: ldur            x3, [x1, #0x13]
    // 0x815440: LoadField: r4 = r1->field_23
    //     0x815440: ldur            w4, [x1, #0x23]
    // 0x815444: DecompressPointer r4
    //     0x815444: add             x4, x4, HEAP, lsl #32
    // 0x815448: r16 = Sentinel
    //     0x815448: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x81544c: cmp             w4, w16
    // 0x815450: b.eq            #0x8155b0
    // 0x815454: r1 = LoadInt32Instr(r4)
    //     0x815454: sbfx            x1, x4, #1, #0x1f
    //     0x815458: tbz             w4, #0, #0x815460
    //     0x81545c: ldur            x1, [x4, #7]
    // 0x815460: add             x4, x3, x1
    // 0x815464: cmp             x2, x4
    // 0x815468: b.lt            #0x81547c
    // 0x81546c: r0 = false
    //     0x81546c: add             x0, NULL, #0x30  ; false
    // 0x815470: LeaveFrame
    //     0x815470: mov             SP, fp
    //     0x815474: ldp             fp, lr, [SP], #0x10
    // 0x815478: ret
    //     0x815478: ret             
    // 0x81547c: r1 = 3
    //     0x81547c: mov             x1, #3
    // 0x815480: stp             x1, x0, [SP, #-0x10]!
    // 0x815484: r0 = _readBits()
    //     0x815484: bl              #0x816a2c  ; [package:archive/src/zlib/inflate.dart] Inflate::_readBits
    // 0x815488: add             SP, SP, #0x10
    // 0x81548c: mov             x1, x0
    // 0x815490: ubfx            x1, x1, #0, #0x20
    // 0x815494: r2 = 1
    //     0x815494: mov             x2, #1
    // 0x815498: and             x3, x1, x2
    // 0x81549c: ubfx            x3, x3, #0, #0x20
    // 0x8154a0: cbz             x3, #0x8154ac
    // 0x8154a4: r2 = false
    //     0x8154a4: add             x2, NULL, #0x30  ; false
    // 0x8154a8: b               #0x8154b0
    // 0x8154ac: r2 = true
    //     0x8154ac: add             x2, NULL, #0x20  ; true
    // 0x8154b0: stur            x2, [fp, #-8]
    // 0x8154b4: asr             x3, x0, #1
    // 0x8154b8: r0 = BoxInt64Instr(r3)
    //     0x8154b8: sbfiz           x0, x3, #1, #0x1f
    //     0x8154bc: cmp             x3, x0, asr #1
    //     0x8154c0: b.eq            #0x8154cc
    //     0x8154c4: bl              #0xd69bb8
    //     0x8154c8: stur            x3, [x0, #7]
    // 0x8154cc: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x8154cc: mov             x1, #0x76
    //     0x8154d0: tbz             w0, #0, #0x8154e0
    //     0x8154d4: ldur            x1, [x0, #-1]
    //     0x8154d8: ubfx            x1, x1, #0xc, #0x14
    //     0x8154dc: lsl             x1, x1, #1
    // 0x8154e0: cmp             w1, #0x76
    // 0x8154e4: b.ne            #0x81558c
    // 0x8154e8: cmp             x3, #1
    // 0x8154ec: b.gt            #0x81554c
    // 0x8154f0: cmp             x3, #0
    // 0x8154f4: b.gt            #0x815524
    // 0x8154f8: cbnz            w0, #0x81558c
    // 0x8154fc: ldr             x16, [fp, #0x10]
    // 0x815500: SaveReg r16
    //     0x815500: str             x16, [SP, #-8]!
    // 0x815504: r0 = _parseUncompressedBlock()
    //     0x815504: bl              #0x816734  ; [package:archive/src/zlib/inflate.dart] Inflate::_parseUncompressedBlock
    // 0x815508: add             SP, SP, #8
    // 0x81550c: cmn             x0, #1
    // 0x815510: b.ne            #0x81557c
    // 0x815514: r0 = false
    //     0x815514: add             x0, NULL, #0x30  ; false
    // 0x815518: LeaveFrame
    //     0x815518: mov             SP, fp
    //     0x81551c: ldp             fp, lr, [SP], #0x10
    // 0x815520: ret
    //     0x815520: ret             
    // 0x815524: ldr             x16, [fp, #0x10]
    // 0x815528: SaveReg r16
    //     0x815528: str             x16, [SP, #-8]!
    // 0x81552c: r0 = _parseFixedHuffmanBlock()
    //     0x81552c: bl              #0x8166e8  ; [package:archive/src/zlib/inflate.dart] Inflate::_parseFixedHuffmanBlock
    // 0x815530: add             SP, SP, #8
    // 0x815534: cmn             x0, #1
    // 0x815538: b.ne            #0x81557c
    // 0x81553c: r0 = false
    //     0x81553c: add             x0, NULL, #0x30  ; false
    // 0x815540: LeaveFrame
    //     0x815540: mov             SP, fp
    //     0x815544: ldp             fp, lr, [SP], #0x10
    // 0x815548: ret
    //     0x815548: ret             
    // 0x81554c: cmp             w0, #4
    // 0x815550: b.ne            #0x81558c
    // 0x815554: ldr             x16, [fp, #0x10]
    // 0x815558: SaveReg r16
    //     0x815558: str             x16, [SP, #-8]!
    // 0x81555c: r0 = _parseDynamicHuffmanBlock()
    //     0x81555c: bl              #0x8155bc  ; [package:archive/src/zlib/inflate.dart] Inflate::_parseDynamicHuffmanBlock
    // 0x815560: add             SP, SP, #8
    // 0x815564: cmn             x0, #1
    // 0x815568: b.ne            #0x81557c
    // 0x81556c: r0 = false
    //     0x81556c: add             x0, NULL, #0x30  ; false
    // 0x815570: LeaveFrame
    //     0x815570: mov             SP, fp
    //     0x815574: ldp             fp, lr, [SP], #0x10
    // 0x815578: ret
    //     0x815578: ret             
    // 0x81557c: ldur            x0, [fp, #-8]
    // 0x815580: LeaveFrame
    //     0x815580: mov             SP, fp
    //     0x815584: ldp             fp, lr, [SP], #0x10
    // 0x815588: ret
    //     0x815588: ret             
    // 0x81558c: r0 = false
    //     0x81558c: add             x0, NULL, #0x30  ; false
    // 0x815590: LeaveFrame
    //     0x815590: mov             SP, fp
    //     0x815594: ldp             fp, lr, [SP], #0x10
    // 0x815598: ret
    //     0x815598: ret             
    // 0x81559c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81559c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8155a0: b               #0x815420
    // 0x8155a4: r9 = input
    //     0x8155a4: add             x9, PP, #0x3b, lsl #12  ; [pp+0x3b168] Field <Inflate.input>: late (offset: 0x8)
    //     0x8155a8: ldr             x9, [x9, #0x168]
    // 0x8155ac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8155ac: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8155b0: r9 = _length
    //     0x8155b0: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a20] Field <InputStream._length@54080104>: late (offset: 0x24)
    //     0x8155b4: ldr             x9, [x9, #0xa20]
    // 0x8155b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8155b8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _parseDynamicHuffmanBlock(/* No info */) {
    // ** addr: 0x8155bc, size: 0x340
    // 0x8155bc: EnterFrame
    //     0x8155bc: stp             fp, lr, [SP, #-0x10]!
    //     0x8155c0: mov             fp, SP
    // 0x8155c4: AllocStack(0x40)
    //     0x8155c4: sub             SP, SP, #0x40
    // 0x8155c8: r0 = 5
    //     0x8155c8: mov             x0, #5
    // 0x8155cc: CheckStackOverflow
    //     0x8155cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8155d0: cmp             SP, x16
    //     0x8155d4: b.ls            #0x8158e4
    // 0x8155d8: ldr             x16, [fp, #0x10]
    // 0x8155dc: stp             x0, x16, [SP, #-0x10]!
    // 0x8155e0: r0 = _readBits()
    //     0x8155e0: bl              #0x816a2c  ; [package:archive/src/zlib/inflate.dart] Inflate::_readBits
    // 0x8155e4: add             SP, SP, #0x10
    // 0x8155e8: cmn             x0, #1
    // 0x8155ec: b.ne            #0x815600
    // 0x8155f0: r0 = -1
    //     0x8155f0: mov             x0, #-1
    // 0x8155f4: LeaveFrame
    //     0x8155f4: mov             SP, fp
    //     0x8155f8: ldp             fp, lr, [SP], #0x10
    // 0x8155fc: ret
    //     0x8155fc: ret             
    // 0x815600: add             x1, x0, #0x101
    // 0x815604: stur            x1, [fp, #-8]
    // 0x815608: cmp             x1, #0x120
    // 0x81560c: b.le            #0x815620
    // 0x815610: r0 = -1
    //     0x815610: mov             x0, #-1
    // 0x815614: LeaveFrame
    //     0x815614: mov             SP, fp
    //     0x815618: ldp             fp, lr, [SP], #0x10
    // 0x81561c: ret
    //     0x81561c: ret             
    // 0x815620: r0 = 5
    //     0x815620: mov             x0, #5
    // 0x815624: ldr             x16, [fp, #0x10]
    // 0x815628: stp             x0, x16, [SP, #-0x10]!
    // 0x81562c: r0 = _readBits()
    //     0x81562c: bl              #0x816a2c  ; [package:archive/src/zlib/inflate.dart] Inflate::_readBits
    // 0x815630: add             SP, SP, #0x10
    // 0x815634: cmn             x0, #1
    // 0x815638: b.ne            #0x81564c
    // 0x81563c: r0 = -1
    //     0x81563c: mov             x0, #-1
    // 0x815640: LeaveFrame
    //     0x815640: mov             SP, fp
    //     0x815644: ldp             fp, lr, [SP], #0x10
    // 0x815648: ret
    //     0x815648: ret             
    // 0x81564c: add             x1, x0, #1
    // 0x815650: stur            x1, [fp, #-0x10]
    // 0x815654: cmp             x1, #0x20
    // 0x815658: b.le            #0x81566c
    // 0x81565c: r0 = -1
    //     0x81565c: mov             x0, #-1
    // 0x815660: LeaveFrame
    //     0x815660: mov             SP, fp
    //     0x815664: ldp             fp, lr, [SP], #0x10
    // 0x815668: ret
    //     0x815668: ret             
    // 0x81566c: r0 = 4
    //     0x81566c: mov             x0, #4
    // 0x815670: ldr             x16, [fp, #0x10]
    // 0x815674: stp             x0, x16, [SP, #-0x10]!
    // 0x815678: r0 = _readBits()
    //     0x815678: bl              #0x816a2c  ; [package:archive/src/zlib/inflate.dart] Inflate::_readBits
    // 0x81567c: add             SP, SP, #0x10
    // 0x815680: cmn             x0, #1
    // 0x815684: b.ne            #0x815698
    // 0x815688: r0 = -1
    //     0x815688: mov             x0, #-1
    // 0x81568c: LeaveFrame
    //     0x81568c: mov             SP, fp
    //     0x815690: ldp             fp, lr, [SP], #0x10
    // 0x815694: ret
    //     0x815694: ret             
    // 0x815698: add             x1, x0, #4
    // 0x81569c: stur            x1, [fp, #-0x18]
    // 0x8156a0: cmp             x1, #0x13
    // 0x8156a4: b.le            #0x8156b8
    // 0x8156a8: r0 = -1
    //     0x8156a8: mov             x0, #-1
    // 0x8156ac: LeaveFrame
    //     0x8156ac: mov             SP, fp
    //     0x8156b0: ldp             fp, lr, [SP], #0x10
    // 0x8156b4: ret
    //     0x8156b4: ret             
    // 0x8156b8: r4 = 38
    //     0x8156b8: mov             x4, #0x26
    // 0x8156bc: r0 = AllocateUint8Array()
    //     0x8156bc: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0x8156c0: stur            x0, [fp, #-0x28]
    // 0x8156c4: r3 = 0
    //     0x8156c4: mov             x3, #0
    // 0x8156c8: ldur            x1, [fp, #-0x18]
    // 0x8156cc: r2 = 3
    //     0x8156cc: mov             x2, #3
    // 0x8156d0: stur            x3, [fp, #-0x20]
    // 0x8156d4: CheckStackOverflow
    //     0x8156d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8156d8: cmp             SP, x16
    //     0x8156dc: b.ls            #0x8158ec
    // 0x8156e0: cmp             x3, x1
    // 0x8156e4: b.ge            #0x815774
    // 0x8156e8: ldr             x16, [fp, #0x10]
    // 0x8156ec: stp             x2, x16, [SP, #-0x10]!
    // 0x8156f0: r0 = _readBits()
    //     0x8156f0: bl              #0x816a2c  ; [package:archive/src/zlib/inflate.dart] Inflate::_readBits
    // 0x8156f4: add             SP, SP, #0x10
    // 0x8156f8: mov             x2, x0
    // 0x8156fc: cmn             x2, #1
    // 0x815700: b.ne            #0x815714
    // 0x815704: r0 = -1
    //     0x815704: mov             x0, #-1
    // 0x815708: LeaveFrame
    //     0x815708: mov             SP, fp
    //     0x81570c: ldp             fp, lr, [SP], #0x10
    // 0x815710: ret
    //     0x815710: ret             
    // 0x815714: ldur            x3, [fp, #-0x20]
    // 0x815718: ldur            x4, [fp, #-0x28]
    // 0x81571c: r5 = const [0x10, 0x11, 0x12, 0, 0x8, 0x7, 0x9, 0x6, 0xa, 0x5, 0xb, 0x4, 0xc, 0x3, 0xd, 0x2, 0xe, 0x1, 0xf]
    //     0x81571c: add             x5, PP, #0x34, lsl #12  ; [pp+0x34b00] List<int>(19)
    //     0x815720: ldr             x5, [x5, #0xb00]
    // 0x815724: mov             x1, x3
    // 0x815728: r0 = 19
    //     0x815728: mov             x0, #0x13
    // 0x81572c: cmp             x1, x0
    // 0x815730: b.hs            #0x8158f4
    // 0x815734: ArrayLoad: r0 = r5[r3]  ; Unknown_4
    //     0x815734: add             x16, x5, x3, lsl #2
    //     0x815738: ldur            w0, [x16, #0xf]
    // 0x81573c: DecompressPointer r0
    //     0x81573c: add             x0, x0, HEAP, lsl #32
    // 0x815740: r6 = LoadInt32Instr(r0)
    //     0x815740: sbfx            x6, x0, #1, #0x1f
    //     0x815744: tbz             w0, #0, #0x81574c
    //     0x815748: ldur            x6, [x0, #7]
    // 0x81574c: mov             x1, x6
    // 0x815750: r0 = 19
    //     0x815750: mov             x0, #0x13
    // 0x815754: cmp             x1, x0
    // 0x815758: b.hs            #0x8158f8
    // 0x81575c: LoadField: r0 = r4->field_7
    //     0x81575c: ldur            x0, [x4, #7]
    // 0x815760: strb            w2, [x0, x6]
    // 0x815764: add             x0, x3, #1
    // 0x815768: mov             x3, x0
    // 0x81576c: mov             x0, x4
    // 0x815770: b               #0x8156c8
    // 0x815774: ldur            x1, [fp, #-8]
    // 0x815778: mov             x4, x0
    // 0x81577c: ldur            x0, [fp, #-0x10]
    // 0x815780: r0 = HuffmanTable()
    //     0x815780: bl              #0x8171f8  ; AllocateHuffmanTableStub -> HuffmanTable (size=0x1c)
    // 0x815784: stur            x0, [fp, #-0x30]
    // 0x815788: ldur            x16, [fp, #-0x28]
    // 0x81578c: stp             x16, x0, [SP, #-0x10]!
    // 0x815790: r0 = HuffmanTable()
    //     0x815790: bl              #0x816d94  ; [package:archive/src/zlib/huffman_table.dart] HuffmanTable::HuffmanTable
    // 0x815794: add             SP, SP, #0x10
    // 0x815798: ldur            x3, [fp, #-8]
    // 0x81579c: ldur            x2, [fp, #-0x10]
    // 0x8157a0: add             x5, x3, x2
    // 0x8157a4: stur            x5, [fp, #-0x18]
    // 0x8157a8: r0 = BoxInt64Instr(r5)
    //     0x8157a8: sbfiz           x0, x5, #1, #0x1f
    //     0x8157ac: cmp             x5, x0, asr #1
    //     0x8157b0: b.eq            #0x8157bc
    //     0x8157b4: bl              #0xd69bb8
    //     0x8157b8: stur            x5, [x0, #7]
    // 0x8157bc: mov             x4, x0
    // 0x8157c0: r0 = AllocateUint8Array()
    //     0x8157c0: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0x8157c4: stur            x0, [fp, #-0x28]
    // 0x8157c8: r0 = _ByteBuffer()
    //     0x8157c8: bl              #0x4b2c3c  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0x8157cc: mov             x3, x0
    // 0x8157d0: ldur            x2, [fp, #-0x28]
    // 0x8157d4: StoreField: r3->field_7 = r2
    //     0x8157d4: stur            w2, [x3, #7]
    // 0x8157d8: ldur            x4, [fp, #-8]
    // 0x8157dc: r0 = BoxInt64Instr(r4)
    //     0x8157dc: sbfiz           x0, x4, #1, #0x1f
    //     0x8157e0: cmp             x4, x0, asr #1
    //     0x8157e4: b.eq            #0x8157f0
    //     0x8157e8: bl              #0xd69bb8
    //     0x8157ec: stur            x4, [x0, #7]
    // 0x8157f0: stur            x0, [fp, #-0x38]
    // 0x8157f4: stp             xzr, x3, [SP, #-0x10]!
    // 0x8157f8: SaveReg r0
    //     0x8157f8: str             x0, [SP, #-8]!
    // 0x8157fc: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x8157fc: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x815800: r0 = asUint8List()
    //     0x815800: bl              #0xd64518  ; [dart:typed_data] _ByteBuffer::asUint8List
    // 0x815804: add             SP, SP, #0x18
    // 0x815808: stur            x0, [fp, #-0x40]
    // 0x81580c: r0 = _ByteBuffer()
    //     0x81580c: bl              #0x4b2c3c  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0x815810: mov             x3, x0
    // 0x815814: ldur            x2, [fp, #-0x28]
    // 0x815818: StoreField: r3->field_7 = r2
    //     0x815818: stur            w2, [x3, #7]
    // 0x81581c: ldur            x4, [fp, #-0x10]
    // 0x815820: r0 = BoxInt64Instr(r4)
    //     0x815820: sbfiz           x0, x4, #1, #0x1f
    //     0x815824: cmp             x4, x0, asr #1
    //     0x815828: b.eq            #0x815834
    //     0x81582c: bl              #0xd69bb8
    //     0x815830: stur            x4, [x0, #7]
    // 0x815834: ldur            x16, [fp, #-0x38]
    // 0x815838: stp             x16, x3, [SP, #-0x10]!
    // 0x81583c: SaveReg r0
    //     0x81583c: str             x0, [SP, #-8]!
    // 0x815840: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x815840: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x815844: r0 = asUint8List()
    //     0x815844: bl              #0xd64518  ; [dart:typed_data] _ByteBuffer::asUint8List
    // 0x815848: add             SP, SP, #0x18
    // 0x81584c: stur            x0, [fp, #-0x38]
    // 0x815850: ldr             x16, [fp, #0x10]
    // 0x815854: SaveReg r16
    //     0x815854: str             x16, [SP, #-8]!
    // 0x815858: ldur            x1, [fp, #-0x18]
    // 0x81585c: ldur            x16, [fp, #-0x30]
    // 0x815860: stp             x16, x1, [SP, #-0x10]!
    // 0x815864: ldur            x16, [fp, #-0x28]
    // 0x815868: SaveReg r16
    //     0x815868: str             x16, [SP, #-8]!
    // 0x81586c: r0 = _decode()
    //     0x81586c: bl              #0x8163a8  ; [package:archive/src/zlib/inflate.dart] Inflate::_decode
    // 0x815870: add             SP, SP, #0x20
    // 0x815874: cmn             x0, #1
    // 0x815878: b.ne            #0x81588c
    // 0x81587c: r0 = -1
    //     0x81587c: mov             x0, #-1
    // 0x815880: LeaveFrame
    //     0x815880: mov             SP, fp
    //     0x815884: ldp             fp, lr, [SP], #0x10
    // 0x815888: ret
    //     0x815888: ret             
    // 0x81588c: r0 = HuffmanTable()
    //     0x81588c: bl              #0x8171f8  ; AllocateHuffmanTableStub -> HuffmanTable (size=0x1c)
    // 0x815890: stur            x0, [fp, #-0x28]
    // 0x815894: ldur            x16, [fp, #-0x40]
    // 0x815898: stp             x16, x0, [SP, #-0x10]!
    // 0x81589c: r0 = HuffmanTable()
    //     0x81589c: bl              #0x816d94  ; [package:archive/src/zlib/huffman_table.dart] HuffmanTable::HuffmanTable
    // 0x8158a0: add             SP, SP, #0x10
    // 0x8158a4: r0 = HuffmanTable()
    //     0x8158a4: bl              #0x8171f8  ; AllocateHuffmanTableStub -> HuffmanTable (size=0x1c)
    // 0x8158a8: stur            x0, [fp, #-0x30]
    // 0x8158ac: ldur            x16, [fp, #-0x38]
    // 0x8158b0: stp             x16, x0, [SP, #-0x10]!
    // 0x8158b4: r0 = HuffmanTable()
    //     0x8158b4: bl              #0x816d94  ; [package:archive/src/zlib/huffman_table.dart] HuffmanTable::HuffmanTable
    // 0x8158b8: add             SP, SP, #0x10
    // 0x8158bc: ldr             x16, [fp, #0x10]
    // 0x8158c0: ldur            lr, [fp, #-0x28]
    // 0x8158c4: stp             lr, x16, [SP, #-0x10]!
    // 0x8158c8: ldur            x16, [fp, #-0x30]
    // 0x8158cc: SaveReg r16
    //     0x8158cc: str             x16, [SP, #-8]!
    // 0x8158d0: r0 = _decodeHuffman()
    //     0x8158d0: bl              #0x8158fc  ; [package:archive/src/zlib/inflate.dart] Inflate::_decodeHuffman
    // 0x8158d4: add             SP, SP, #0x18
    // 0x8158d8: LeaveFrame
    //     0x8158d8: mov             SP, fp
    //     0x8158dc: ldp             fp, lr, [SP], #0x10
    // 0x8158e0: ret
    //     0x8158e0: ret             
    // 0x8158e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8158e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8158e8: b               #0x8155d8
    // 0x8158ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8158ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8158f0: b               #0x8156e0
    // 0x8158f4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8158f4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8158f8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8158f8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _decodeHuffman(/* No info */) {
    // ** addr: 0x8158fc, size: 0x380
    // 0x8158fc: EnterFrame
    //     0x8158fc: stp             fp, lr, [SP, #-0x10]!
    //     0x815900: mov             fp, SP
    // 0x815904: AllocStack(0x20)
    //     0x815904: sub             SP, SP, #0x20
    // 0x815908: CheckStackOverflow
    //     0x815908: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81590c: cmp             SP, x16
    //     0x815910: b.ls            #0x815c44
    // 0x815914: CheckStackOverflow
    //     0x815914: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x815918: cmp             SP, x16
    //     0x81591c: b.ls            #0x815c4c
    // 0x815920: ldr             x16, [fp, #0x20]
    // 0x815924: ldr             lr, [fp, #0x18]
    // 0x815928: stp             lr, x16, [SP, #-0x10]!
    // 0x81592c: r0 = _readCodeByTable()
    //     0x81592c: bl              #0x816114  ; [package:archive/src/zlib/inflate.dart] Inflate::_readCodeByTable
    // 0x815930: add             SP, SP, #0x10
    // 0x815934: tbnz            x0, #0x3f, #0x815940
    // 0x815938: cmp             x0, #0x11d
    // 0x81593c: b.le            #0x815950
    // 0x815940: r0 = -1
    //     0x815940: mov             x0, #-1
    // 0x815944: LeaveFrame
    //     0x815944: mov             SP, fp
    //     0x815948: ldp             fp, lr, [SP], #0x10
    // 0x81594c: ret
    //     0x81594c: ret             
    // 0x815950: cmp             x0, #0x100
    // 0x815954: b.ne            #0x8159bc
    // 0x815958: ldr             x2, [fp, #0x20]
    // 0x81595c: r1 = 0
    //     0x81595c: mov             x1, #0
    // 0x815960: CheckStackOverflow
    //     0x815960: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x815964: cmp             SP, x16
    //     0x815968: b.ls            #0x815c54
    // 0x81596c: LoadField: r0 = r2->field_1b
    //     0x81596c: ldur            x0, [x2, #0x1b]
    // 0x815970: cmp             x0, #8
    // 0x815974: b.lt            #0x8159ac
    // 0x815978: sub             x3, x0, #8
    // 0x81597c: StoreField: r2->field_1b = r3
    //     0x81597c: stur            x3, [x2, #0x1b]
    // 0x815980: LoadField: r0 = r2->field_7
    //     0x815980: ldur            w0, [x2, #7]
    // 0x815984: DecompressPointer r0
    //     0x815984: add             x0, x0, HEAP, lsl #32
    // 0x815988: r16 = Sentinel
    //     0x815988: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x81598c: cmp             w0, w16
    // 0x815990: b.eq            #0x815c5c
    // 0x815994: LoadField: r3 = r0->field_b
    //     0x815994: ldur            x3, [x0, #0xb]
    // 0x815998: sub             x4, x3, #1
    // 0x81599c: StoreField: r0->field_b = r4
    //     0x81599c: stur            x4, [x0, #0xb]
    // 0x8159a0: tbz             x4, #0x3f, #0x815960
    // 0x8159a4: StoreField: r0->field_b = r1
    //     0x8159a4: stur            x1, [x0, #0xb]
    // 0x8159a8: b               #0x815960
    // 0x8159ac: mov             x0, x1
    // 0x8159b0: LeaveFrame
    //     0x8159b0: mov             SP, fp
    //     0x8159b4: ldp             fp, lr, [SP], #0x10
    // 0x8159b8: ret
    //     0x8159b8: ret             
    // 0x8159bc: ldr             x2, [fp, #0x20]
    // 0x8159c0: r1 = 0
    //     0x8159c0: mov             x1, #0
    // 0x8159c4: cmp             x0, #0x100
    // 0x8159c8: b.ge            #0x8159f4
    // 0x8159cc: r3 = 255
    //     0x8159cc: mov             x3, #0xff
    // 0x8159d0: LoadField: r4 = r2->field_f
    //     0x8159d0: ldur            w4, [x2, #0xf]
    // 0x8159d4: DecompressPointer r4
    //     0x8159d4: add             x4, x4, HEAP, lsl #32
    // 0x8159d8: ubfx            x0, x0, #0, #0x20
    // 0x8159dc: and             x5, x0, x3
    // 0x8159e0: ubfx            x5, x5, #0, #0x20
    // 0x8159e4: stp             x5, x4, [SP, #-0x10]!
    // 0x8159e8: r0 = writeByte()
    //     0x8159e8: bl              #0x816064  ; [package:archive/src/util/output_stream.dart] OutputStream::writeByte
    // 0x8159ec: add             SP, SP, #0x10
    // 0x8159f0: b               #0x815914
    // 0x8159f4: r3 = const [0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0xa, 0xb, 0xd, 0xf, 0x11, 0x13, 0x17, 0x1b, 0x1f, 0x23, 0x2b, 0x33, 0x3b, 0x43, 0x53, 0x63, 0x73, 0x83, 0xa3, 0xc3, 0xe3, 0x102]
    //     0x8159f4: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b170] List<int>(29)
    //     0x8159f8: ldr             x3, [x3, #0x170]
    // 0x8159fc: r2 = const [0, 0, 0, 0, 0, 0, 0, 0, 0x1, 0x1, 0x1, 0x1, 0x2, 0x2, 0x2, 0x2, 0x3, 0x3, 0x3, 0x3, 0x4, 0x4, 0x4, 0x4, 0x5, 0x5, 0x5, 0x5, 0, 0, 0]
    //     0x8159fc: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b178] List<int>(31)
    //     0x815a00: ldr             x2, [x2, #0x178]
    // 0x815a04: sub             x4, x0, #0x101
    // 0x815a08: mov             x1, x4
    // 0x815a0c: r0 = 29
    //     0x815a0c: mov             x0, #0x1d
    // 0x815a10: cmp             x1, x0
    // 0x815a14: b.hs            #0x815c68
    // 0x815a18: ArrayLoad: r5 = r3[r4]  ; Unknown_4
    //     0x815a18: add             x16, x3, x4, lsl #2
    //     0x815a1c: ldur            w5, [x16, #0xf]
    // 0x815a20: DecompressPointer r5
    //     0x815a20: add             x5, x5, HEAP, lsl #32
    // 0x815a24: mov             x1, x4
    // 0x815a28: stur            x5, [fp, #-8]
    // 0x815a2c: r0 = 31
    //     0x815a2c: mov             x0, #0x1f
    // 0x815a30: cmp             x1, x0
    // 0x815a34: b.hs            #0x815c6c
    // 0x815a38: ArrayLoad: r0 = r2[r4]  ; Unknown_4
    //     0x815a38: add             x16, x2, x4, lsl #2
    //     0x815a3c: ldur            w0, [x16, #0xf]
    // 0x815a40: DecompressPointer r0
    //     0x815a40: add             x0, x0, HEAP, lsl #32
    // 0x815a44: r1 = LoadInt32Instr(r0)
    //     0x815a44: sbfx            x1, x0, #1, #0x1f
    //     0x815a48: tbz             w0, #0, #0x815a50
    //     0x815a4c: ldur            x1, [x0, #7]
    // 0x815a50: ldr             x16, [fp, #0x20]
    // 0x815a54: stp             x1, x16, [SP, #-0x10]!
    // 0x815a58: r0 = _readBits()
    //     0x815a58: bl              #0x816a2c  ; [package:archive/src/zlib/inflate.dart] Inflate::_readBits
    // 0x815a5c: add             SP, SP, #0x10
    // 0x815a60: mov             x1, x0
    // 0x815a64: ldur            x0, [fp, #-8]
    // 0x815a68: r2 = LoadInt32Instr(r0)
    //     0x815a68: sbfx            x2, x0, #1, #0x1f
    //     0x815a6c: tbz             w0, #0, #0x815a74
    //     0x815a70: ldur            x2, [x0, #7]
    // 0x815a74: add             x0, x2, x1
    // 0x815a78: stur            x0, [fp, #-0x10]
    // 0x815a7c: ldr             x16, [fp, #0x20]
    // 0x815a80: ldr             lr, [fp, #0x10]
    // 0x815a84: stp             lr, x16, [SP, #-0x10]!
    // 0x815a88: r0 = _readCodeByTable()
    //     0x815a88: bl              #0x816114  ; [package:archive/src/zlib/inflate.dart] Inflate::_readCodeByTable
    // 0x815a8c: add             SP, SP, #0x10
    // 0x815a90: mov             x2, x0
    // 0x815a94: tbnz            x2, #0x3f, #0x815aa0
    // 0x815a98: cmp             x2, #0x1d
    // 0x815a9c: b.le            #0x815ab0
    // 0x815aa0: r0 = -1
    //     0x815aa0: mov             x0, #-1
    // 0x815aa4: LeaveFrame
    //     0x815aa4: mov             SP, fp
    //     0x815aa8: ldp             fp, lr, [SP], #0x10
    // 0x815aac: ret
    //     0x815aac: ret             
    // 0x815ab0: r4 = const [0x1, 0x2, 0x3, 0x4, 0x5, 0x7, 0x9, 0xd, 0x11, 0x19, 0x21, 0x31, 0x41, 0x61, 0x81, 0xc1, 0x101, 0x181, 0x201, 0x301, 0x401, 0x601, 0x801, 0xc01, 0x1001, 0x1801, 0x2001, 0x3001, 0x4001, 0x6001]
    //     0x815ab0: add             x4, PP, #0x3b, lsl #12  ; [pp+0x3b180] List<int>(30)
    //     0x815ab4: ldr             x4, [x4, #0x180]
    // 0x815ab8: r3 = const [0, 0, 0, 0, 0x1, 0x1, 0x2, 0x2, 0x3, 0x3, 0x4, 0x4, 0x5, 0x5, 0x6, 0x6, 0x7, 0x7, 0x8, 0x8, 0x9, 0x9, 0xa, 0xa, 0xb, 0xb, 0xc, 0xc, 0xd, 0xd]
    //     0x815ab8: add             x3, PP, #0x34, lsl #12  ; [pp+0x34b28] List<int>(30)
    //     0x815abc: ldr             x3, [x3, #0xb28]
    // 0x815ac0: mov             x1, x2
    // 0x815ac4: r0 = 30
    //     0x815ac4: mov             x0, #0x1e
    // 0x815ac8: cmp             x1, x0
    // 0x815acc: b.hs            #0x815c70
    // 0x815ad0: ArrayLoad: r0 = r4[r2]  ; Unknown_4
    //     0x815ad0: add             x16, x4, x2, lsl #2
    //     0x815ad4: ldur            w0, [x16, #0xf]
    // 0x815ad8: DecompressPointer r0
    //     0x815ad8: add             x0, x0, HEAP, lsl #32
    // 0x815adc: stur            x0, [fp, #-8]
    // 0x815ae0: ArrayLoad: r1 = r3[r2]  ; Unknown_4
    //     0x815ae0: add             x16, x3, x2, lsl #2
    //     0x815ae4: ldur            w1, [x16, #0xf]
    // 0x815ae8: DecompressPointer r1
    //     0x815ae8: add             x1, x1, HEAP, lsl #32
    // 0x815aec: r2 = LoadInt32Instr(r1)
    //     0x815aec: sbfx            x2, x1, #1, #0x1f
    //     0x815af0: tbz             w1, #0, #0x815af8
    //     0x815af4: ldur            x2, [x1, #7]
    // 0x815af8: ldr             x16, [fp, #0x20]
    // 0x815afc: stp             x2, x16, [SP, #-0x10]!
    // 0x815b00: r0 = _readBits()
    //     0x815b00: bl              #0x816a2c  ; [package:archive/src/zlib/inflate.dart] Inflate::_readBits
    // 0x815b04: add             SP, SP, #0x10
    // 0x815b08: mov             x1, x0
    // 0x815b0c: ldur            x0, [fp, #-8]
    // 0x815b10: r2 = LoadInt32Instr(r0)
    //     0x815b10: sbfx            x2, x0, #1, #0x1f
    //     0x815b14: tbz             w0, #0, #0x815b1c
    //     0x815b18: ldur            x2, [x0, #7]
    // 0x815b1c: add             x0, x2, x1
    // 0x815b20: stur            x0, [fp, #-0x20]
    // 0x815b24: neg             x1, x0
    // 0x815b28: stur            x1, [fp, #-0x18]
    // 0x815b2c: ldur            x3, [fp, #-0x10]
    // 0x815b30: ldr             x2, [fp, #0x20]
    // 0x815b34: stur            x3, [fp, #-0x10]
    // 0x815b38: CheckStackOverflow
    //     0x815b38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x815b3c: cmp             SP, x16
    //     0x815b40: b.ls            #0x815c74
    // 0x815b44: cmp             x3, x0
    // 0x815b48: b.le            #0x815b98
    // 0x815b4c: LoadField: r4 = r2->field_f
    //     0x815b4c: ldur            w4, [x2, #0xf]
    // 0x815b50: DecompressPointer r4
    //     0x815b50: add             x4, x4, HEAP, lsl #32
    // 0x815b54: stur            x4, [fp, #-8]
    // 0x815b58: stp             x1, x4, [SP, #-0x10]!
    // 0x815b5c: SaveReg rNULL
    //     0x815b5c: str             NULL, [SP, #-8]!
    // 0x815b60: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x815b60: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x815b64: r0 = subset()
    //     0x815b64: bl              #0x815f48  ; [package:archive/src/util/output_stream.dart] OutputStream::subset
    // 0x815b68: add             SP, SP, #0x18
    // 0x815b6c: ldur            x16, [fp, #-8]
    // 0x815b70: stp             x0, x16, [SP, #-0x10]!
    // 0x815b74: SaveReg rNULL
    //     0x815b74: str             NULL, [SP, #-8]!
    // 0x815b78: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x815b78: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x815b7c: r0 = writeBytes()
    //     0x815b7c: bl              #0x815c7c  ; [package:archive/src/util/output_stream.dart] OutputStream::writeBytes
    // 0x815b80: add             SP, SP, #0x18
    // 0x815b84: ldur            x0, [fp, #-0x20]
    // 0x815b88: ldur            x1, [fp, #-0x10]
    // 0x815b8c: sub             x3, x1, x0
    // 0x815b90: ldur            x1, [fp, #-0x18]
    // 0x815b94: b               #0x815b30
    // 0x815b98: mov             x1, x3
    // 0x815b9c: cmp             x1, x0
    // 0x815ba0: b.ne            #0x815be8
    // 0x815ba4: ldr             x1, [fp, #0x20]
    // 0x815ba8: LoadField: r2 = r1->field_f
    //     0x815ba8: ldur            w2, [x1, #0xf]
    // 0x815bac: DecompressPointer r2
    //     0x815bac: add             x2, x2, HEAP, lsl #32
    // 0x815bb0: stur            x2, [fp, #-8]
    // 0x815bb4: neg             x3, x0
    // 0x815bb8: stp             x3, x2, [SP, #-0x10]!
    // 0x815bbc: SaveReg rNULL
    //     0x815bbc: str             NULL, [SP, #-8]!
    // 0x815bc0: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x815bc0: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x815bc4: r0 = subset()
    //     0x815bc4: bl              #0x815f48  ; [package:archive/src/util/output_stream.dart] OutputStream::subset
    // 0x815bc8: add             SP, SP, #0x18
    // 0x815bcc: ldur            x16, [fp, #-8]
    // 0x815bd0: stp             x0, x16, [SP, #-0x10]!
    // 0x815bd4: SaveReg rNULL
    //     0x815bd4: str             NULL, [SP, #-8]!
    // 0x815bd8: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x815bd8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x815bdc: r0 = writeBytes()
    //     0x815bdc: bl              #0x815c7c  ; [package:archive/src/util/output_stream.dart] OutputStream::writeBytes
    // 0x815be0: add             SP, SP, #0x18
    // 0x815be4: b               #0x815914
    // 0x815be8: ldr             x2, [fp, #0x20]
    // 0x815bec: LoadField: r3 = r2->field_f
    //     0x815bec: ldur            w3, [x2, #0xf]
    // 0x815bf0: DecompressPointer r3
    //     0x815bf0: add             x3, x3, HEAP, lsl #32
    // 0x815bf4: stur            x3, [fp, #-8]
    // 0x815bf8: neg             x4, x0
    // 0x815bfc: sub             x5, x1, x0
    // 0x815c00: r0 = BoxInt64Instr(r5)
    //     0x815c00: sbfiz           x0, x5, #1, #0x1f
    //     0x815c04: cmp             x5, x0, asr #1
    //     0x815c08: b.eq            #0x815c14
    //     0x815c0c: bl              #0xd69bb8
    //     0x815c10: stur            x5, [x0, #7]
    // 0x815c14: stp             x4, x3, [SP, #-0x10]!
    // 0x815c18: SaveReg r0
    //     0x815c18: str             x0, [SP, #-8]!
    // 0x815c1c: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x815c1c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x815c20: r0 = subset()
    //     0x815c20: bl              #0x815f48  ; [package:archive/src/util/output_stream.dart] OutputStream::subset
    // 0x815c24: add             SP, SP, #0x18
    // 0x815c28: ldur            x16, [fp, #-8]
    // 0x815c2c: stp             x0, x16, [SP, #-0x10]!
    // 0x815c30: SaveReg rNULL
    //     0x815c30: str             NULL, [SP, #-8]!
    // 0x815c34: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x815c34: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x815c38: r0 = writeBytes()
    //     0x815c38: bl              #0x815c7c  ; [package:archive/src/util/output_stream.dart] OutputStream::writeBytes
    // 0x815c3c: add             SP, SP, #0x18
    // 0x815c40: b               #0x815914
    // 0x815c44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x815c44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x815c48: b               #0x815914
    // 0x815c4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x815c4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x815c50: b               #0x815920
    // 0x815c54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x815c54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x815c58: b               #0x81596c
    // 0x815c5c: r9 = input
    //     0x815c5c: add             x9, PP, #0x3b, lsl #12  ; [pp+0x3b168] Field <Inflate.input>: late (offset: 0x8)
    //     0x815c60: ldr             x9, [x9, #0x168]
    // 0x815c64: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x815c64: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x815c68: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x815c68: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x815c6c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x815c6c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x815c70: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x815c70: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x815c74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x815c74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x815c78: b               #0x815b44
  }
  _ _readCodeByTable(/* No info */) {
    // ** addr: 0x816114, size: 0x294
    // 0x816114: EnterFrame
    //     0x816114: stp             fp, lr, [SP, #-0x10]!
    //     0x816118: mov             fp, SP
    // 0x81611c: AllocStack(0x10)
    //     0x81611c: sub             SP, SP, #0x10
    // 0x816120: CheckStackOverflow
    //     0x816120: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x816124: cmp             SP, x16
    //     0x816128: b.ls            #0x8162e0
    // 0x81612c: ldr             x0, [fp, #0x10]
    // 0x816130: LoadField: r2 = r0->field_7
    //     0x816130: ldur            w2, [x0, #7]
    // 0x816134: DecompressPointer r2
    //     0x816134: add             x2, x2, HEAP, lsl #32
    // 0x816138: r16 = Sentinel
    //     0x816138: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x81613c: cmp             w2, w16
    // 0x816140: b.eq            #0x8162e8
    // 0x816144: stur            x2, [fp, #-0x10]
    // 0x816148: LoadField: r3 = r0->field_b
    //     0x816148: ldur            x3, [x0, #0xb]
    // 0x81614c: stur            x3, [fp, #-8]
    // 0x816150: ldr             x4, [fp, #0x18]
    // 0x816154: CheckStackOverflow
    //     0x816154: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x816158: cmp             SP, x16
    //     0x81615c: b.ls            #0x8162f4
    // 0x816160: LoadField: r5 = r4->field_1b
    //     0x816160: ldur            x5, [x4, #0x1b]
    // 0x816164: cmp             x5, x3
    // 0x816168: b.ge            #0x81624c
    // 0x81616c: LoadField: r0 = r4->field_7
    //     0x81616c: ldur            w0, [x4, #7]
    // 0x816170: DecompressPointer r0
    //     0x816170: add             x0, x0, HEAP, lsl #32
    // 0x816174: r16 = Sentinel
    //     0x816174: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x816178: cmp             w0, w16
    // 0x81617c: b.eq            #0x8162fc
    // 0x816180: LoadField: r5 = r0->field_b
    //     0x816180: ldur            x5, [x0, #0xb]
    // 0x816184: LoadField: r1 = r0->field_13
    //     0x816184: ldur            x1, [x0, #0x13]
    // 0x816188: LoadField: r6 = r0->field_23
    //     0x816188: ldur            w6, [x0, #0x23]
    // 0x81618c: DecompressPointer r6
    //     0x81618c: add             x6, x6, HEAP, lsl #32
    // 0x816190: r16 = Sentinel
    //     0x816190: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x816194: cmp             w6, w16
    // 0x816198: b.eq            #0x816308
    // 0x81619c: r7 = LoadInt32Instr(r6)
    //     0x81619c: sbfx            x7, x6, #1, #0x1f
    //     0x8161a0: tbz             w6, #0, #0x8161a8
    //     0x8161a4: ldur            x7, [x6, #7]
    // 0x8161a8: add             x6, x1, x7
    // 0x8161ac: cmp             x5, x6
    // 0x8161b0: b.lt            #0x8161c4
    // 0x8161b4: r0 = -1
    //     0x8161b4: mov             x0, #-1
    // 0x8161b8: LeaveFrame
    //     0x8161b8: mov             SP, fp
    //     0x8161bc: ldp             fp, lr, [SP], #0x10
    // 0x8161c0: ret
    //     0x8161c0: ret             
    // 0x8161c4: LoadField: r6 = r0->field_7
    //     0x8161c4: ldur            w6, [x0, #7]
    // 0x8161c8: DecompressPointer r6
    //     0x8161c8: add             x6, x6, HEAP, lsl #32
    // 0x8161cc: add             x1, x5, #1
    // 0x8161d0: StoreField: r0->field_b = r1
    //     0x8161d0: stur            x1, [x0, #0xb]
    // 0x8161d4: r0 = BoxInt64Instr(r5)
    //     0x8161d4: sbfiz           x0, x5, #1, #0x1f
    //     0x8161d8: cmp             x5, x0, asr #1
    //     0x8161dc: b.eq            #0x8161e8
    //     0x8161e0: bl              #0xd69bb8
    //     0x8161e4: stur            x5, [x0, #7]
    // 0x8161e8: r1 = LoadClassIdInstr(r6)
    //     0x8161e8: ldur            x1, [x6, #-1]
    //     0x8161ec: ubfx            x1, x1, #0xc, #0x14
    // 0x8161f0: stp             x0, x6, [SP, #-0x10]!
    // 0x8161f4: mov             x0, x1
    // 0x8161f8: r0 = GDT[cid_x0 + -0xd83]()
    //     0x8161f8: sub             lr, x0, #0xd83
    //     0x8161fc: ldr             lr, [x21, lr, lsl #3]
    //     0x816200: blr             lr
    // 0x816204: add             SP, SP, #0x10
    // 0x816208: ldr             x2, [fp, #0x18]
    // 0x81620c: LoadField: r3 = r2->field_13
    //     0x81620c: ldur            x3, [x2, #0x13]
    // 0x816210: LoadField: r4 = r2->field_1b
    //     0x816210: ldur            x4, [x2, #0x1b]
    // 0x816214: r6 = LoadInt32Instr(r0)
    //     0x816214: sbfx            x6, x0, #1, #0x1f
    //     0x816218: tbz             w0, #0, #0x816220
    //     0x81621c: ldur            x6, [x0, #7]
    // 0x816220: cmp             x4, #0x3f
    // 0x816224: b.hi            #0x816314
    // 0x816228: lsl             x7, x6, x4
    // 0x81622c: orr             x6, x3, x7
    // 0x816230: StoreField: r2->field_13 = r6
    //     0x816230: stur            x6, [x2, #0x13]
    // 0x816234: add             x3, x4, #8
    // 0x816238: StoreField: r2->field_1b = r3
    //     0x816238: stur            x3, [x2, #0x1b]
    // 0x81623c: mov             x4, x2
    // 0x816240: ldur            x3, [fp, #-8]
    // 0x816244: ldur            x2, [fp, #-0x10]
    // 0x816248: b               #0x816154
    // 0x81624c: mov             x16, x3
    // 0x816250: mov             x3, x4
    // 0x816254: mov             x4, x16
    // 0x816258: mov             x16, x2
    // 0x81625c: mov             x2, x3
    // 0x816260: mov             x3, x16
    // 0x816264: r7 = 1
    //     0x816264: mov             x7, #1
    // 0x816268: r6 = 65535
    //     0x816268: mov             x6, #0xffff
    // 0x81626c: LoadField: r8 = r2->field_13
    //     0x81626c: ldur            x8, [x2, #0x13]
    // 0x816270: cmp             x4, #0x3f
    // 0x816274: b.hi            #0x816340
    // 0x816278: lsl             x9, x7, x4
    // 0x81627c: sub             x4, x9, #1
    // 0x816280: and             x7, x8, x4
    // 0x816284: LoadField: r4 = r3->field_13
    //     0x816284: ldur            w4, [x3, #0x13]
    // 0x816288: DecompressPointer r4
    //     0x816288: add             x4, x4, HEAP, lsl #32
    // 0x81628c: r0 = LoadInt32Instr(r4)
    //     0x81628c: sbfx            x0, x4, #1, #0x1f
    // 0x816290: mov             x1, x7
    // 0x816294: cmp             x1, x0
    // 0x816298: b.hs            #0x816374
    // 0x81629c: ArrayLoad: r1 = r3[r7]  ; Unknown_4
    //     0x81629c: add             x16, x3, x7, lsl #2
    //     0x8162a0: ldur            w1, [x16, #0x17]
    // 0x8162a4: mov             x3, x1
    // 0x8162a8: ubfx            x3, x3, #0, #0x20
    // 0x8162ac: asr             x4, x3, #0x10
    // 0x8162b0: cmp             x4, #0x3f
    // 0x8162b4: b.hi            #0x816378
    // 0x8162b8: asr             x3, x8, x4
    // 0x8162bc: StoreField: r2->field_13 = r3
    //     0x8162bc: stur            x3, [x2, #0x13]
    // 0x8162c0: sub             x3, x5, x4
    // 0x8162c4: StoreField: r2->field_1b = r3
    //     0x8162c4: stur            x3, [x2, #0x1b]
    // 0x8162c8: and             x2, x1, x6
    // 0x8162cc: ubfx            x2, x2, #0, #0x20
    // 0x8162d0: mov             x0, x2
    // 0x8162d4: LeaveFrame
    //     0x8162d4: mov             SP, fp
    //     0x8162d8: ldp             fp, lr, [SP], #0x10
    // 0x8162dc: ret
    //     0x8162dc: ret             
    // 0x8162e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8162e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8162e4: b               #0x81612c
    // 0x8162e8: r9 = table
    //     0x8162e8: add             x9, PP, #0x3b, lsl #12  ; [pp+0x3b188] Field <HuffmanTable.table>: late (offset: 0x8)
    //     0x8162ec: ldr             x9, [x9, #0x188]
    // 0x8162f0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8162f0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8162f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8162f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8162f8: b               #0x816160
    // 0x8162fc: r9 = input
    //     0x8162fc: add             x9, PP, #0x3b, lsl #12  ; [pp+0x3b168] Field <Inflate.input>: late (offset: 0x8)
    //     0x816300: ldr             x9, [x9, #0x168]
    // 0x816304: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x816304: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x816308: r9 = _length
    //     0x816308: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a20] Field <InputStream._length@54080104>: late (offset: 0x24)
    //     0x81630c: ldr             x9, [x9, #0xa20]
    // 0x816310: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x816310: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x816314: tbnz            x4, #0x3f, #0x816320
    // 0x816318: mov             x7, xzr
    // 0x81631c: b               #0x81622c
    // 0x816320: str             x4, [THR, #0xc0]  ; THR::
    // 0x816324: stp             x4, x6, [SP, #-0x10]!
    // 0x816328: stp             x2, x3, [SP, #-0x10]!
    // 0x81632c: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x816330: r4 = 0
    //     0x816330: mov             x4, #0
    // 0x816334: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x816338: blr             lr
    // 0x81633c: brk             #0
    // 0x816340: tbnz            x4, #0x3f, #0x81634c
    // 0x816344: mov             x9, xzr
    // 0x816348: b               #0x81627c
    // 0x81634c: str             x4, [THR, #0xc0]  ; THR::
    // 0x816350: stp             x7, x8, [SP, #-0x10]!
    // 0x816354: stp             x5, x6, [SP, #-0x10]!
    // 0x816358: stp             x3, x4, [SP, #-0x10]!
    // 0x81635c: SaveReg r2
    //     0x81635c: str             x2, [SP, #-8]!
    // 0x816360: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x816364: r4 = 0
    //     0x816364: mov             x4, #0
    // 0x816368: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x81636c: blr             lr
    // 0x816370: brk             #0
    // 0x816374: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x816374: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x816378: tbnz            x4, #0x3f, #0x816384
    // 0x81637c: asr             x3, x8, #0x3f
    // 0x816380: b               #0x8162bc
    // 0x816384: str             x4, [THR, #0xc0]  ; THR::
    // 0x816388: stp             x6, x8, [SP, #-0x10]!
    // 0x81638c: stp             x4, x5, [SP, #-0x10]!
    // 0x816390: stp             x1, x2, [SP, #-0x10]!
    // 0x816394: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x816398: r4 = 0
    //     0x816398: mov             x4, #0
    // 0x81639c: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x8163a0: blr             lr
    // 0x8163a4: brk             #0
  }
  _ _decode(/* No info */) {
    // ** addr: 0x8163a8, size: 0x340
    // 0x8163a8: EnterFrame
    //     0x8163a8: stp             fp, lr, [SP, #-0x10]!
    //     0x8163ac: mov             fp, SP
    // 0x8163b0: AllocStack(0x30)
    //     0x8163b0: sub             SP, SP, #0x30
    // 0x8163b4: CheckStackOverflow
    //     0x8163b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8163b8: cmp             SP, x16
    //     0x8163bc: b.ls            #0x8166b0
    // 0x8163c0: ldr             x0, [fp, #0x10]
    // 0x8163c4: LoadField: r1 = r0->field_13
    //     0x8163c4: ldur            w1, [x0, #0x13]
    // 0x8163c8: DecompressPointer r1
    //     0x8163c8: add             x1, x1, HEAP, lsl #32
    // 0x8163cc: r2 = LoadInt32Instr(r1)
    //     0x8163cc: sbfx            x2, x1, #1, #0x1f
    // 0x8163d0: stur            x2, [fp, #-0x30]
    // 0x8163d4: r3 = LoadInt32Instr(r1)
    //     0x8163d4: sbfx            x3, x1, #1, #0x1f
    // 0x8163d8: stur            x3, [fp, #-0x28]
    // 0x8163dc: r4 = LoadInt32Instr(r1)
    //     0x8163dc: sbfx            x4, x1, #1, #0x1f
    // 0x8163e0: stur            x4, [fp, #-0x20]
    // 0x8163e4: r5 = LoadInt32Instr(r1)
    //     0x8163e4: sbfx            x5, x1, #1, #0x1f
    // 0x8163e8: stur            x5, [fp, #-0x18]
    // 0x8163ec: r7 = 0
    //     0x8163ec: mov             x7, #0
    // 0x8163f0: r6 = 0
    //     0x8163f0: mov             x6, #0
    // 0x8163f4: ldr             x1, [fp, #0x20]
    // 0x8163f8: stur            x7, [fp, #-8]
    // 0x8163fc: stur            x6, [fp, #-0x10]
    // 0x816400: CheckStackOverflow
    //     0x816400: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x816404: cmp             SP, x16
    //     0x816408: b.ls            #0x8166b8
    // 0x81640c: cmp             x6, x1
    // 0x816410: b.ge            #0x8166a0
    // 0x816414: ldr             x16, [fp, #0x28]
    // 0x816418: ldr             lr, [fp, #0x18]
    // 0x81641c: stp             lr, x16, [SP, #-0x10]!
    // 0x816420: r0 = _readCodeByTable()
    //     0x816420: bl              #0x816114  ; [package:archive/src/zlib/inflate.dart] Inflate::_readCodeByTable
    // 0x816424: add             SP, SP, #0x10
    // 0x816428: mov             x2, x0
    // 0x81642c: cmn             x2, #1
    // 0x816430: b.ne            #0x816444
    // 0x816434: r0 = -1
    //     0x816434: mov             x0, #-1
    // 0x816438: LeaveFrame
    //     0x816438: mov             SP, fp
    //     0x81643c: ldp             fp, lr, [SP], #0x10
    // 0x816440: ret
    //     0x816440: ret             
    // 0x816444: r0 = BoxInt64Instr(r2)
    //     0x816444: sbfiz           x0, x2, #1, #0x1f
    //     0x816448: cmp             x2, x0, asr #1
    //     0x81644c: b.eq            #0x816458
    //     0x816450: bl              #0xd69bb8
    //     0x816454: stur            x2, [x0, #7]
    // 0x816458: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x816458: mov             x1, #0x76
    //     0x81645c: tbz             w0, #0, #0x81646c
    //     0x816460: ldur            x1, [x0, #-1]
    //     0x816464: ubfx            x1, x1, #0xc, #0x14
    //     0x816468: lsl             x1, x1, #1
    // 0x81646c: cmp             w1, #0x76
    // 0x816470: b.ne            #0x816640
    // 0x816474: cmp             x2, #0x11
    // 0x816478: b.gt            #0x8165ac
    // 0x81647c: cmp             x2, #0x10
    // 0x816480: b.gt            #0x816520
    // 0x816484: cmp             w0, #0x20
    // 0x816488: b.ne            #0x816518
    // 0x81648c: r0 = 2
    //     0x81648c: mov             x0, #2
    // 0x816490: ldr             x16, [fp, #0x28]
    // 0x816494: stp             x0, x16, [SP, #-0x10]!
    // 0x816498: r0 = _readBits()
    //     0x816498: bl              #0x816a2c  ; [package:archive/src/zlib/inflate.dart] Inflate::_readBits
    // 0x81649c: add             SP, SP, #0x10
    // 0x8164a0: cmn             x0, #1
    // 0x8164a4: b.ne            #0x8164b8
    // 0x8164a8: r0 = -1
    //     0x8164a8: mov             x0, #-1
    // 0x8164ac: LeaveFrame
    //     0x8164ac: mov             SP, fp
    //     0x8164b0: ldp             fp, lr, [SP], #0x10
    // 0x8164b4: ret
    //     0x8164b4: ret             
    // 0x8164b8: add             x1, x0, #3
    // 0x8164bc: ldur            x4, [fp, #-0x10]
    // 0x8164c0: mov             x0, x1
    // 0x8164c4: ldr             x3, [fp, #0x10]
    // 0x8164c8: ldur            x2, [fp, #-8]
    // 0x8164cc: CheckStackOverflow
    //     0x8164cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8164d0: cmp             SP, x16
    //     0x8164d4: b.ls            #0x8166c0
    // 0x8164d8: sub             x5, x0, #1
    // 0x8164dc: cmp             x0, #0
    // 0x8164e0: b.le            #0x81650c
    // 0x8164e4: add             x6, x4, #1
    // 0x8164e8: ldur            x0, [fp, #-0x18]
    // 0x8164ec: mov             x1, x4
    // 0x8164f0: cmp             x1, x0
    // 0x8164f4: b.hs            #0x8166c8
    // 0x8164f8: LoadField: r0 = r3->field_7
    //     0x8164f8: ldur            x0, [x3, #7]
    // 0x8164fc: strb            w2, [x0, x4]
    // 0x816500: mov             x4, x6
    // 0x816504: mov             x0, x5
    // 0x816508: b               #0x8164cc
    // 0x81650c: mov             x7, x2
    // 0x816510: mov             x6, x4
    // 0x816514: b               #0x816688
    // 0x816518: ldr             x3, [fp, #0x10]
    // 0x81651c: b               #0x816644
    // 0x816520: ldr             x3, [fp, #0x10]
    // 0x816524: r0 = 3
    //     0x816524: mov             x0, #3
    // 0x816528: ldr             x16, [fp, #0x28]
    // 0x81652c: stp             x0, x16, [SP, #-0x10]!
    // 0x816530: r0 = _readBits()
    //     0x816530: bl              #0x816a2c  ; [package:archive/src/zlib/inflate.dart] Inflate::_readBits
    // 0x816534: add             SP, SP, #0x10
    // 0x816538: cmn             x0, #1
    // 0x81653c: b.ne            #0x816550
    // 0x816540: r0 = -1
    //     0x816540: mov             x0, #-1
    // 0x816544: LeaveFrame
    //     0x816544: mov             SP, fp
    //     0x816548: ldp             fp, lr, [SP], #0x10
    // 0x81654c: ret
    //     0x81654c: ret             
    // 0x816550: add             x1, x0, #3
    // 0x816554: ldur            x2, [fp, #-0x10]
    // 0x816558: mov             x0, x1
    // 0x81655c: ldr             x3, [fp, #0x10]
    // 0x816560: CheckStackOverflow
    //     0x816560: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x816564: cmp             SP, x16
    //     0x816568: b.ls            #0x8166cc
    // 0x81656c: sub             x4, x0, #1
    // 0x816570: cmp             x0, #0
    // 0x816574: b.le            #0x8165a0
    // 0x816578: add             x5, x2, #1
    // 0x81657c: ldur            x0, [fp, #-0x20]
    // 0x816580: mov             x1, x2
    // 0x816584: cmp             x1, x0
    // 0x816588: b.hs            #0x8166d4
    // 0x81658c: LoadField: r0 = r3->field_7
    //     0x81658c: ldur            x0, [x3, #7]
    // 0x816590: strb            wzr, [x0, x2]
    // 0x816594: mov             x2, x5
    // 0x816598: mov             x0, x4
    // 0x81659c: b               #0x816560
    // 0x8165a0: mov             x6, x2
    // 0x8165a4: r7 = 0
    //     0x8165a4: mov             x7, #0
    // 0x8165a8: b               #0x816688
    // 0x8165ac: ldr             x3, [fp, #0x10]
    // 0x8165b0: cmp             w0, #0x24
    // 0x8165b4: b.ne            #0x816644
    // 0x8165b8: r0 = 7
    //     0x8165b8: mov             x0, #7
    // 0x8165bc: ldr             x16, [fp, #0x28]
    // 0x8165c0: stp             x0, x16, [SP, #-0x10]!
    // 0x8165c4: r0 = _readBits()
    //     0x8165c4: bl              #0x816a2c  ; [package:archive/src/zlib/inflate.dart] Inflate::_readBits
    // 0x8165c8: add             SP, SP, #0x10
    // 0x8165cc: cmn             x0, #1
    // 0x8165d0: b.ne            #0x8165e4
    // 0x8165d4: r0 = -1
    //     0x8165d4: mov             x0, #-1
    // 0x8165d8: LeaveFrame
    //     0x8165d8: mov             SP, fp
    //     0x8165dc: ldp             fp, lr, [SP], #0x10
    // 0x8165e0: ret
    //     0x8165e0: ret             
    // 0x8165e4: add             x3, x0, #0xb
    // 0x8165e8: ldur            x2, [fp, #-0x10]
    // 0x8165ec: mov             x4, x3
    // 0x8165f0: ldr             x3, [fp, #0x10]
    // 0x8165f4: CheckStackOverflow
    //     0x8165f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8165f8: cmp             SP, x16
    //     0x8165fc: b.ls            #0x8166d8
    // 0x816600: sub             x5, x4, #1
    // 0x816604: cmp             x4, #0
    // 0x816608: b.le            #0x816634
    // 0x81660c: add             x6, x2, #1
    // 0x816610: ldur            x0, [fp, #-0x28]
    // 0x816614: mov             x1, x2
    // 0x816618: cmp             x1, x0
    // 0x81661c: b.hs            #0x8166e0
    // 0x816620: LoadField: r4 = r3->field_7
    //     0x816620: ldur            x4, [x3, #7]
    // 0x816624: strb            wzr, [x4, x2]
    // 0x816628: mov             x2, x6
    // 0x81662c: mov             x4, x5
    // 0x816630: b               #0x8165f4
    // 0x816634: mov             x6, x2
    // 0x816638: r7 = 0
    //     0x816638: mov             x7, #0
    // 0x81663c: b               #0x816688
    // 0x816640: ldr             x3, [fp, #0x10]
    // 0x816644: tbnz            x2, #0x3f, #0x816650
    // 0x816648: cmp             x2, #0xf
    // 0x81664c: b.le            #0x816660
    // 0x816650: r0 = -1
    //     0x816650: mov             x0, #-1
    // 0x816654: LeaveFrame
    //     0x816654: mov             SP, fp
    //     0x816658: ldp             fp, lr, [SP], #0x10
    // 0x81665c: ret
    //     0x81665c: ret             
    // 0x816660: ldur            x4, [fp, #-0x10]
    // 0x816664: add             x5, x4, #1
    // 0x816668: ldur            x0, [fp, #-0x30]
    // 0x81666c: mov             x1, x4
    // 0x816670: cmp             x1, x0
    // 0x816674: b.hs            #0x8166e4
    // 0x816678: LoadField: r1 = r3->field_7
    //     0x816678: ldur            x1, [x3, #7]
    // 0x81667c: strb            w2, [x1, x4]
    // 0x816680: mov             x7, x2
    // 0x816684: mov             x6, x5
    // 0x816688: mov             x0, x3
    // 0x81668c: ldur            x5, [fp, #-0x18]
    // 0x816690: ldur            x4, [fp, #-0x20]
    // 0x816694: ldur            x3, [fp, #-0x28]
    // 0x816698: ldur            x2, [fp, #-0x30]
    // 0x81669c: b               #0x8163f4
    // 0x8166a0: r0 = 0
    //     0x8166a0: mov             x0, #0
    // 0x8166a4: LeaveFrame
    //     0x8166a4: mov             SP, fp
    //     0x8166a8: ldp             fp, lr, [SP], #0x10
    // 0x8166ac: ret
    //     0x8166ac: ret             
    // 0x8166b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8166b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8166b4: b               #0x8163c0
    // 0x8166b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8166b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8166bc: b               #0x81640c
    // 0x8166c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8166c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8166c4: b               #0x8164d8
    // 0x8166c8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8166c8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8166cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8166cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8166d0: b               #0x81656c
    // 0x8166d4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8166d4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8166d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8166d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8166dc: b               #0x816600
    // 0x8166e0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8166e0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8166e4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8166e4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _parseFixedHuffmanBlock(/* No info */) {
    // ** addr: 0x8166e8, size: 0x4c
    // 0x8166e8: EnterFrame
    //     0x8166e8: stp             fp, lr, [SP, #-0x10]!
    //     0x8166ec: mov             fp, SP
    // 0x8166f0: CheckStackOverflow
    //     0x8166f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8166f4: cmp             SP, x16
    //     0x8166f8: b.ls            #0x81672c
    // 0x8166fc: ldr             x0, [fp, #0x10]
    // 0x816700: LoadField: r1 = r0->field_23
    //     0x816700: ldur            w1, [x0, #0x23]
    // 0x816704: DecompressPointer r1
    //     0x816704: add             x1, x1, HEAP, lsl #32
    // 0x816708: LoadField: r2 = r0->field_27
    //     0x816708: ldur            w2, [x0, #0x27]
    // 0x81670c: DecompressPointer r2
    //     0x81670c: add             x2, x2, HEAP, lsl #32
    // 0x816710: stp             x1, x0, [SP, #-0x10]!
    // 0x816714: SaveReg r2
    //     0x816714: str             x2, [SP, #-8]!
    // 0x816718: r0 = _decodeHuffman()
    //     0x816718: bl              #0x8158fc  ; [package:archive/src/zlib/inflate.dart] Inflate::_decodeHuffman
    // 0x81671c: add             SP, SP, #0x18
    // 0x816720: LeaveFrame
    //     0x816720: mov             SP, fp
    //     0x816724: ldp             fp, lr, [SP], #0x10
    // 0x816728: ret
    //     0x816728: ret             
    // 0x81672c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81672c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x816730: b               #0x8166fc
  }
  _ _parseUncompressedBlock(/* No info */) {
    // ** addr: 0x816734, size: 0x130
    // 0x816734: EnterFrame
    //     0x816734: stp             fp, lr, [SP, #-0x10]!
    //     0x816738: mov             fp, SP
    // 0x81673c: AllocStack(0x10)
    //     0x81673c: sub             SP, SP, #0x10
    // 0x816740: r1 = 0
    //     0x816740: mov             x1, #0
    // 0x816744: r0 = 16
    //     0x816744: mov             x0, #0x10
    // 0x816748: CheckStackOverflow
    //     0x816748: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81674c: cmp             SP, x16
    //     0x816750: b.ls            #0x816844
    // 0x816754: ldr             x2, [fp, #0x10]
    // 0x816758: StoreField: r2->field_13 = r1
    //     0x816758: stur            x1, [x2, #0x13]
    // 0x81675c: StoreField: r2->field_1b = r1
    //     0x81675c: stur            x1, [x2, #0x1b]
    // 0x816760: stp             x0, x2, [SP, #-0x10]!
    // 0x816764: r0 = _readBits()
    //     0x816764: bl              #0x816a2c  ; [package:archive/src/zlib/inflate.dart] Inflate::_readBits
    // 0x816768: add             SP, SP, #0x10
    // 0x81676c: stur            x0, [fp, #-8]
    // 0x816770: ldr             x16, [fp, #0x10]
    // 0x816774: SaveReg r16
    //     0x816774: str             x16, [SP, #-8]!
    // 0x816778: r1 = 16
    //     0x816778: mov             x1, #0x10
    // 0x81677c: SaveReg r1
    //     0x81677c: str             x1, [SP, #-8]!
    // 0x816780: r0 = _readBits()
    //     0x816780: bl              #0x816a2c  ; [package:archive/src/zlib/inflate.dart] Inflate::_readBits
    // 0x816784: add             SP, SP, #0x10
    // 0x816788: eor             x1, x0, #0xffff
    // 0x81678c: ldur            x0, [fp, #-8]
    // 0x816790: cbz             x0, #0x8167ac
    // 0x816794: cmp             x0, x1
    // 0x816798: b.eq            #0x8167ac
    // 0x81679c: r0 = -1
    //     0x81679c: mov             x0, #-1
    // 0x8167a0: LeaveFrame
    //     0x8167a0: mov             SP, fp
    //     0x8167a4: ldp             fp, lr, [SP], #0x10
    // 0x8167a8: ret
    //     0x8167a8: ret             
    // 0x8167ac: ldr             x1, [fp, #0x10]
    // 0x8167b0: LoadField: r2 = r1->field_7
    //     0x8167b0: ldur            w2, [x1, #7]
    // 0x8167b4: DecompressPointer r2
    //     0x8167b4: add             x2, x2, HEAP, lsl #32
    // 0x8167b8: r16 = Sentinel
    //     0x8167b8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8167bc: cmp             w2, w16
    // 0x8167c0: b.eq            #0x81684c
    // 0x8167c4: LoadField: r3 = r2->field_23
    //     0x8167c4: ldur            w3, [x2, #0x23]
    // 0x8167c8: DecompressPointer r3
    //     0x8167c8: add             x3, x3, HEAP, lsl #32
    // 0x8167cc: r16 = Sentinel
    //     0x8167cc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8167d0: cmp             w3, w16
    // 0x8167d4: b.eq            #0x816858
    // 0x8167d8: LoadField: r4 = r2->field_b
    //     0x8167d8: ldur            x4, [x2, #0xb]
    // 0x8167dc: LoadField: r5 = r2->field_13
    //     0x8167dc: ldur            x5, [x2, #0x13]
    // 0x8167e0: sub             x6, x4, x5
    // 0x8167e4: r4 = LoadInt32Instr(r3)
    //     0x8167e4: sbfx            x4, x3, #1, #0x1f
    //     0x8167e8: tbz             w3, #0, #0x8167f0
    //     0x8167ec: ldur            x4, [x3, #7]
    // 0x8167f0: sub             x3, x4, x6
    // 0x8167f4: cmp             x0, x3
    // 0x8167f8: b.le            #0x81680c
    // 0x8167fc: r0 = -1
    //     0x8167fc: mov             x0, #-1
    // 0x816800: LeaveFrame
    //     0x816800: mov             SP, fp
    //     0x816804: ldp             fp, lr, [SP], #0x10
    // 0x816808: ret
    //     0x816808: ret             
    // 0x81680c: LoadField: r3 = r1->field_f
    //     0x81680c: ldur            w3, [x1, #0xf]
    // 0x816810: DecompressPointer r3
    //     0x816810: add             x3, x3, HEAP, lsl #32
    // 0x816814: stur            x3, [fp, #-0x10]
    // 0x816818: stp             x0, x2, [SP, #-0x10]!
    // 0x81681c: r0 = readBytes()
    //     0x81681c: bl              #0x817d54  ; [package:archive/src/util/input_stream.dart] InputStream::readBytes
    // 0x816820: add             SP, SP, #0x10
    // 0x816824: ldur            x16, [fp, #-0x10]
    // 0x816828: stp             x0, x16, [SP, #-0x10]!
    // 0x81682c: r0 = writeInputStream()
    //     0x81682c: bl              #0x816864  ; [package:archive/src/util/output_stream.dart] OutputStream::writeInputStream
    // 0x816830: add             SP, SP, #0x10
    // 0x816834: r0 = 0
    //     0x816834: mov             x0, #0
    // 0x816838: LeaveFrame
    //     0x816838: mov             SP, fp
    //     0x81683c: ldp             fp, lr, [SP], #0x10
    // 0x816840: ret
    //     0x816840: ret             
    // 0x816844: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x816844: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x816848: b               #0x816754
    // 0x81684c: r9 = input
    //     0x81684c: add             x9, PP, #0x3b, lsl #12  ; [pp+0x3b168] Field <Inflate.input>: late (offset: 0x8)
    //     0x816850: ldr             x9, [x9, #0x168]
    // 0x816854: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x816854: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x816858: r9 = _length
    //     0x816858: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a20] Field <InputStream._length@54080104>: late (offset: 0x24)
    //     0x81685c: ldr             x9, [x9, #0xa20]
    // 0x816860: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x816860: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _readBits(/* No info */) {
    // ** addr: 0x816a2c, size: 0x224
    // 0x816a2c: EnterFrame
    //     0x816a2c: stp             fp, lr, [SP, #-0x10]!
    //     0x816a30: mov             fp, SP
    // 0x816a34: CheckStackOverflow
    //     0x816a34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x816a38: cmp             SP, x16
    //     0x816a3c: b.ls            #0x816b9c
    // 0x816a40: ldr             x2, [fp, #0x10]
    // 0x816a44: lsl             x0, x2, #1
    // 0x816a48: cbnz            w0, #0x816a5c
    // 0x816a4c: r0 = 0
    //     0x816a4c: mov             x0, #0
    // 0x816a50: LeaveFrame
    //     0x816a50: mov             SP, fp
    //     0x816a54: ldp             fp, lr, [SP], #0x10
    // 0x816a58: ret
    //     0x816a58: ret             
    // 0x816a5c: ldr             x3, [fp, #0x18]
    // 0x816a60: CheckStackOverflow
    //     0x816a60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x816a64: cmp             SP, x16
    //     0x816a68: b.ls            #0x816ba4
    // 0x816a6c: LoadField: r0 = r3->field_1b
    //     0x816a6c: ldur            x0, [x3, #0x1b]
    // 0x816a70: cmp             x0, x2
    // 0x816a74: b.ge            #0x816b54
    // 0x816a78: LoadField: r0 = r3->field_7
    //     0x816a78: ldur            w0, [x3, #7]
    // 0x816a7c: DecompressPointer r0
    //     0x816a7c: add             x0, x0, HEAP, lsl #32
    // 0x816a80: r16 = Sentinel
    //     0x816a80: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x816a84: cmp             w0, w16
    // 0x816a88: b.eq            #0x816bac
    // 0x816a8c: LoadField: r4 = r0->field_b
    //     0x816a8c: ldur            x4, [x0, #0xb]
    // 0x816a90: LoadField: r1 = r0->field_13
    //     0x816a90: ldur            x1, [x0, #0x13]
    // 0x816a94: LoadField: r5 = r0->field_23
    //     0x816a94: ldur            w5, [x0, #0x23]
    // 0x816a98: DecompressPointer r5
    //     0x816a98: add             x5, x5, HEAP, lsl #32
    // 0x816a9c: r16 = Sentinel
    //     0x816a9c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x816aa0: cmp             w5, w16
    // 0x816aa4: b.eq            #0x816bb8
    // 0x816aa8: r6 = LoadInt32Instr(r5)
    //     0x816aa8: sbfx            x6, x5, #1, #0x1f
    //     0x816aac: tbz             w5, #0, #0x816ab4
    //     0x816ab0: ldur            x6, [x5, #7]
    // 0x816ab4: add             x5, x1, x6
    // 0x816ab8: cmp             x4, x5
    // 0x816abc: b.lt            #0x816ad0
    // 0x816ac0: r0 = -1
    //     0x816ac0: mov             x0, #-1
    // 0x816ac4: LeaveFrame
    //     0x816ac4: mov             SP, fp
    //     0x816ac8: ldp             fp, lr, [SP], #0x10
    // 0x816acc: ret
    //     0x816acc: ret             
    // 0x816ad0: LoadField: r5 = r0->field_7
    //     0x816ad0: ldur            w5, [x0, #7]
    // 0x816ad4: DecompressPointer r5
    //     0x816ad4: add             x5, x5, HEAP, lsl #32
    // 0x816ad8: add             x1, x4, #1
    // 0x816adc: StoreField: r0->field_b = r1
    //     0x816adc: stur            x1, [x0, #0xb]
    // 0x816ae0: r0 = BoxInt64Instr(r4)
    //     0x816ae0: sbfiz           x0, x4, #1, #0x1f
    //     0x816ae4: cmp             x4, x0, asr #1
    //     0x816ae8: b.eq            #0x816af4
    //     0x816aec: bl              #0xd69bb8
    //     0x816af0: stur            x4, [x0, #7]
    // 0x816af4: r1 = LoadClassIdInstr(r5)
    //     0x816af4: ldur            x1, [x5, #-1]
    //     0x816af8: ubfx            x1, x1, #0xc, #0x14
    // 0x816afc: stp             x0, x5, [SP, #-0x10]!
    // 0x816b00: mov             x0, x1
    // 0x816b04: r0 = GDT[cid_x0 + -0xd83]()
    //     0x816b04: sub             lr, x0, #0xd83
    //     0x816b08: ldr             lr, [x21, lr, lsl #3]
    //     0x816b0c: blr             lr
    // 0x816b10: add             SP, SP, #0x10
    // 0x816b14: ldr             x1, [fp, #0x18]
    // 0x816b18: LoadField: r2 = r1->field_13
    //     0x816b18: ldur            x2, [x1, #0x13]
    // 0x816b1c: LoadField: r3 = r1->field_1b
    //     0x816b1c: ldur            x3, [x1, #0x1b]
    // 0x816b20: r4 = LoadInt32Instr(r0)
    //     0x816b20: sbfx            x4, x0, #1, #0x1f
    //     0x816b24: tbz             w0, #0, #0x816b2c
    //     0x816b28: ldur            x4, [x0, #7]
    // 0x816b2c: cmp             x3, #0x3f
    // 0x816b30: b.hi            #0x816bc4
    // 0x816b34: lsl             x5, x4, x3
    // 0x816b38: orr             x4, x2, x5
    // 0x816b3c: StoreField: r1->field_13 = r4
    //     0x816b3c: stur            x4, [x1, #0x13]
    // 0x816b40: add             x2, x3, #8
    // 0x816b44: StoreField: r1->field_1b = r2
    //     0x816b44: stur            x2, [x1, #0x1b]
    // 0x816b48: mov             x3, x1
    // 0x816b4c: ldr             x2, [fp, #0x10]
    // 0x816b50: b               #0x816a60
    // 0x816b54: mov             x1, x3
    // 0x816b58: r3 = 1
    //     0x816b58: mov             x3, #1
    // 0x816b5c: LoadField: r4 = r1->field_13
    //     0x816b5c: ldur            x4, [x1, #0x13]
    // 0x816b60: cmp             x2, #0x3f
    // 0x816b64: b.hi            #0x816bf0
    // 0x816b68: lsl             x5, x3, x2
    // 0x816b6c: sub             x3, x5, #1
    // 0x816b70: and             x5, x4, x3
    // 0x816b74: cmp             x2, #0x3f
    // 0x816b78: b.hi            #0x816c20
    // 0x816b7c: asr             x3, x4, x2
    // 0x816b80: StoreField: r1->field_13 = r3
    //     0x816b80: stur            x3, [x1, #0x13]
    // 0x816b84: sub             x3, x0, x2
    // 0x816b88: StoreField: r1->field_1b = r3
    //     0x816b88: stur            x3, [x1, #0x1b]
    // 0x816b8c: mov             x0, x5
    // 0x816b90: LeaveFrame
    //     0x816b90: mov             SP, fp
    //     0x816b94: ldp             fp, lr, [SP], #0x10
    // 0x816b98: ret
    //     0x816b98: ret             
    // 0x816b9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x816b9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x816ba0: b               #0x816a40
    // 0x816ba4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x816ba4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x816ba8: b               #0x816a6c
    // 0x816bac: r9 = input
    //     0x816bac: add             x9, PP, #0x3b, lsl #12  ; [pp+0x3b168] Field <Inflate.input>: late (offset: 0x8)
    //     0x816bb0: ldr             x9, [x9, #0x168]
    // 0x816bb4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x816bb4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x816bb8: r9 = _length
    //     0x816bb8: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a20] Field <InputStream._length@54080104>: late (offset: 0x24)
    //     0x816bbc: ldr             x9, [x9, #0xa20]
    // 0x816bc0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x816bc0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x816bc4: tbnz            x3, #0x3f, #0x816bd0
    // 0x816bc8: mov             x5, xzr
    // 0x816bcc: b               #0x816b38
    // 0x816bd0: str             x3, [THR, #0xc0]  ; THR::
    // 0x816bd4: stp             x3, x4, [SP, #-0x10]!
    // 0x816bd8: stp             x1, x2, [SP, #-0x10]!
    // 0x816bdc: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x816be0: r4 = 0
    //     0x816be0: mov             x4, #0
    // 0x816be4: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x816be8: blr             lr
    // 0x816bec: brk             #0
    // 0x816bf0: tbnz            x2, #0x3f, #0x816bfc
    // 0x816bf4: mov             x5, xzr
    // 0x816bf8: b               #0x816b6c
    // 0x816bfc: str             x2, [THR, #0xc0]  ; THR::
    // 0x816c00: stp             x3, x4, [SP, #-0x10]!
    // 0x816c04: stp             x1, x2, [SP, #-0x10]!
    // 0x816c08: SaveReg r0
    //     0x816c08: str             x0, [SP, #-8]!
    // 0x816c0c: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x816c10: r4 = 0
    //     0x816c10: mov             x4, #0
    // 0x816c14: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x816c18: blr             lr
    // 0x816c1c: brk             #0
    // 0x816c20: tbnz            x2, #0x3f, #0x816c2c
    // 0x816c24: asr             x3, x4, #0x3f
    // 0x816c28: b               #0x816b80
    // 0x816c2c: str             x2, [THR, #0xc0]  ; THR::
    // 0x816c30: stp             x4, x5, [SP, #-0x10]!
    // 0x816c34: stp             x1, x2, [SP, #-0x10]!
    // 0x816c38: SaveReg r0
    //     0x816c38: str             x0, [SP, #-8]!
    // 0x816c3c: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0x816c40: r4 = 0
    //     0x816c40: mov             x4, #0
    // 0x816c44: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x816c48: blr             lr
    // 0x816c4c: brk             #0
  }
  _ Inflate(/* No info */) {
    // ** addr: 0xba5a24, size: 0x15c
    // 0xba5a24: EnterFrame
    //     0xba5a24: stp             fp, lr, [SP, #-0x10]!
    //     0xba5a28: mov             fp, SP
    // 0xba5a2c: AllocStack(0x8)
    //     0xba5a2c: sub             SP, SP, #8
    // 0xba5a30: r1 = false
    //     0xba5a30: add             x1, NULL, #0x30  ; false
    // 0xba5a34: r0 = 0
    //     0xba5a34: mov             x0, #0
    // 0xba5a38: CheckStackOverflow
    //     0xba5a38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xba5a3c: cmp             SP, x16
    //     0xba5a40: b.ls            #0xba5b78
    // 0xba5a44: ldr             x2, [fp, #0x18]
    // 0xba5a48: StoreField: r2->field_b = r1
    //     0xba5a48: stur            w1, [x2, #0xb]
    // 0xba5a4c: StoreField: r2->field_13 = r0
    //     0xba5a4c: stur            x0, [x2, #0x13]
    // 0xba5a50: StoreField: r2->field_1b = r0
    //     0xba5a50: stur            x0, [x2, #0x1b]
    // 0xba5a54: r0 = HuffmanTable()
    //     0xba5a54: bl              #0x8171f8  ; AllocateHuffmanTableStub -> HuffmanTable (size=0x1c)
    // 0xba5a58: stur            x0, [fp, #-8]
    // 0xba5a5c: r16 = const [0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x9, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8]
    //     0xba5a5c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b158] List<int>(288)
    //     0xba5a60: ldr             x16, [x16, #0x158]
    // 0xba5a64: stp             x16, x0, [SP, #-0x10]!
    // 0xba5a68: r0 = HuffmanTable()
    //     0xba5a68: bl              #0x816d94  ; [package:archive/src/zlib/huffman_table.dart] HuffmanTable::HuffmanTable
    // 0xba5a6c: add             SP, SP, #0x10
    // 0xba5a70: ldur            x0, [fp, #-8]
    // 0xba5a74: ldr             x1, [fp, #0x18]
    // 0xba5a78: StoreField: r1->field_23 = r0
    //     0xba5a78: stur            w0, [x1, #0x23]
    //     0xba5a7c: ldurb           w16, [x1, #-1]
    //     0xba5a80: ldurb           w17, [x0, #-1]
    //     0xba5a84: and             x16, x17, x16, lsr #2
    //     0xba5a88: tst             x16, HEAP, lsr #32
    //     0xba5a8c: b.eq            #0xba5a94
    //     0xba5a90: bl              #0xd6826c
    // 0xba5a94: r0 = HuffmanTable()
    //     0xba5a94: bl              #0x8171f8  ; AllocateHuffmanTableStub -> HuffmanTable (size=0x1c)
    // 0xba5a98: stur            x0, [fp, #-8]
    // 0xba5a9c: r16 = const [0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5]
    //     0xba5a9c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b160] List<int>(30)
    //     0xba5aa0: ldr             x16, [x16, #0x160]
    // 0xba5aa4: stp             x16, x0, [SP, #-0x10]!
    // 0xba5aa8: r0 = HuffmanTable()
    //     0xba5aa8: bl              #0x816d94  ; [package:archive/src/zlib/huffman_table.dart] HuffmanTable::HuffmanTable
    // 0xba5aac: add             SP, SP, #0x10
    // 0xba5ab0: ldur            x0, [fp, #-8]
    // 0xba5ab4: ldr             x1, [fp, #0x18]
    // 0xba5ab8: StoreField: r1->field_27 = r0
    //     0xba5ab8: stur            w0, [x1, #0x27]
    //     0xba5abc: ldurb           w16, [x1, #-1]
    //     0xba5ac0: ldurb           w17, [x0, #-1]
    //     0xba5ac4: and             x16, x17, x16, lsr #2
    //     0xba5ac8: tst             x16, HEAP, lsr #32
    //     0xba5acc: b.eq            #0xba5ad4
    //     0xba5ad0: bl              #0xd6826c
    // 0xba5ad4: r0 = InputStream()
    //     0xba5ad4: bl              #0x818b18  ; AllocateInputStreamStub -> InputStream (size=0x28)
    // 0xba5ad8: stur            x0, [fp, #-8]
    // 0xba5adc: ldr             x16, [fp, #0x10]
    // 0xba5ae0: stp             x16, x0, [SP, #-0x10]!
    // 0xba5ae4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xba5ae4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xba5ae8: r0 = InputStream()
    //     0xba5ae8: bl              #0x818754  ; [package:archive/src/util/input_stream.dart] InputStream::InputStream
    // 0xba5aec: add             SP, SP, #0x10
    // 0xba5af0: ldur            x0, [fp, #-8]
    // 0xba5af4: ldr             x1, [fp, #0x18]
    // 0xba5af8: StoreField: r1->field_7 = r0
    //     0xba5af8: stur            w0, [x1, #7]
    //     0xba5afc: ldurb           w16, [x1, #-1]
    //     0xba5b00: ldurb           w17, [x0, #-1]
    //     0xba5b04: and             x16, x17, x16, lsr #2
    //     0xba5b08: tst             x16, HEAP, lsr #32
    //     0xba5b0c: b.eq            #0xba5b14
    //     0xba5b10: bl              #0xd6826c
    // 0xba5b14: r0 = OutputStream()
    //     0xba5b14: bl              #0x816d88  ; AllocateOutputStreamStub -> OutputStream (size=0x1c)
    // 0xba5b18: stur            x0, [fp, #-8]
    // 0xba5b1c: stp             NULL, x0, [SP, #-0x10]!
    // 0xba5b20: r4 = const [0, 0x2, 0x2, 0x1, size, 0x1, null]
    //     0xba5b20: add             x4, PP, #0x27, lsl #12  ; [pp+0x27e20] List(7) [0, 0x2, 0x2, 0x1, "size", 0x1, Null]
    //     0xba5b24: ldr             x4, [x4, #0xe20]
    // 0xba5b28: r0 = OutputStream()
    //     0xba5b28: bl              #0x816c50  ; [package:archive/src/util/output_stream.dart] OutputStream::OutputStream
    // 0xba5b2c: add             SP, SP, #0x10
    // 0xba5b30: ldur            x0, [fp, #-8]
    // 0xba5b34: ldr             x1, [fp, #0x18]
    // 0xba5b38: StoreField: r1->field_f = r0
    //     0xba5b38: stur            w0, [x1, #0xf]
    //     0xba5b3c: ldurb           w16, [x1, #-1]
    //     0xba5b40: ldurb           w17, [x0, #-1]
    //     0xba5b44: and             x16, x17, x16, lsr #2
    //     0xba5b48: tst             x16, HEAP, lsr #32
    //     0xba5b4c: b.eq            #0xba5b54
    //     0xba5b50: bl              #0xd6826c
    // 0xba5b54: r0 = true
    //     0xba5b54: add             x0, NULL, #0x20  ; true
    // 0xba5b58: StoreField: r1->field_b = r0
    //     0xba5b58: stur            w0, [x1, #0xb]
    // 0xba5b5c: SaveReg r1
    //     0xba5b5c: str             x1, [SP, #-8]!
    // 0xba5b60: r0 = _inflate()
    //     0xba5b60: bl              #0x815324  ; [package:archive/src/zlib/inflate.dart] Inflate::_inflate
    // 0xba5b64: add             SP, SP, #8
    // 0xba5b68: r0 = Null
    //     0xba5b68: mov             x0, NULL
    // 0xba5b6c: LeaveFrame
    //     0xba5b6c: mov             SP, fp
    //     0xba5b70: ldp             fp, lr, [SP], #0x10
    // 0xba5b74: ret
    //     0xba5b74: ret             
    // 0xba5b78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba5b78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba5b7c: b               #0xba5a44
  }
}

// lib: , url: package:archive/src/zip_decoder.dart

// class id: 1048625, size: 0x8
class :: {
}

// class id: 4996, size: 0xc, field offset: 0x8
class ZipDecoder extends Object {

  _ decodeBytes(/* No info */) {
    // ** addr: 0x813690, size: 0x5c
    // 0x813690: EnterFrame
    //     0x813690: stp             fp, lr, [SP, #-0x10]!
    //     0x813694: mov             fp, SP
    // 0x813698: AllocStack(0x8)
    //     0x813698: sub             SP, SP, #8
    // 0x81369c: CheckStackOverflow
    //     0x81369c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8136a0: cmp             SP, x16
    //     0x8136a4: b.ls            #0x8136e4
    // 0x8136a8: r0 = InputStream()
    //     0x8136a8: bl              #0x818b18  ; AllocateInputStreamStub -> InputStream (size=0x28)
    // 0x8136ac: stur            x0, [fp, #-8]
    // 0x8136b0: ldr             x16, [fp, #0x10]
    // 0x8136b4: stp             x16, x0, [SP, #-0x10]!
    // 0x8136b8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x8136b8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x8136bc: r0 = InputStream()
    //     0x8136bc: bl              #0x818754  ; [package:archive/src/util/input_stream.dart] InputStream::InputStream
    // 0x8136c0: add             SP, SP, #0x10
    // 0x8136c4: ldr             x16, [fp, #0x18]
    // 0x8136c8: ldur            lr, [fp, #-8]
    // 0x8136cc: stp             lr, x16, [SP, #-0x10]!
    // 0x8136d0: r0 = decodeBuffer()
    //     0x8136d0: bl              #0x8136ec  ; [package:archive/src/zip_decoder.dart] ZipDecoder::decodeBuffer
    // 0x8136d4: add             SP, SP, #0x10
    // 0x8136d8: LeaveFrame
    //     0x8136d8: mov             SP, fp
    //     0x8136dc: ldp             fp, lr, [SP], #0x10
    // 0x8136e0: ret
    //     0x8136e0: ret             
    // 0x8136e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8136e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8136e8: b               #0x8136a8
  }
  _ decodeBuffer(/* No info */) {
    // ** addr: 0x8136ec, size: 0x458
    // 0x8136ec: EnterFrame
    //     0x8136ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8136f0: mov             fp, SP
    // 0x8136f4: AllocStack(0x60)
    //     0x8136f4: sub             SP, SP, #0x60
    // 0x8136f8: CheckStackOverflow
    //     0x8136f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8136fc: cmp             SP, x16
    //     0x813700: b.ls            #0x813b28
    // 0x813704: r0 = ZipDirectory()
    //     0x813704: bl              #0x818748  ; AllocateZipDirectoryStub -> ZipDirectory (size=0x1c)
    // 0x813708: stur            x0, [fp, #-8]
    // 0x81370c: ldr             x16, [fp, #0x10]
    // 0x813710: stp             x16, x0, [SP, #-0x10]!
    // 0x813714: r0 = ZipDirectory.read()
    //     0x813714: bl              #0x813e74  ; [package:archive/src/zip/zip_directory.dart] ZipDirectory::ZipDirectory.read
    // 0x813718: add             SP, SP, #0x10
    // 0x81371c: ldur            x0, [fp, #-8]
    // 0x813720: ldr             x2, [fp, #0x18]
    // 0x813724: StoreField: r2->field_7 = r0
    //     0x813724: stur            w0, [x2, #7]
    //     0x813728: ldurb           w16, [x2, #-1]
    //     0x81372c: ldurb           w17, [x0, #-1]
    //     0x813730: and             x16, x17, x16, lsr #2
    //     0x813734: tst             x16, HEAP, lsr #32
    //     0x813738: b.eq            #0x813740
    //     0x81373c: bl              #0xd6828c
    // 0x813740: r1 = <ArchiveFile>
    //     0x813740: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a968] TypeArguments: <ArchiveFile>
    //     0x813744: ldr             x1, [x1, #0x968]
    // 0x813748: r0 = Archive()
    //     0x813748: bl              #0x813e68  ; AllocateArchiveStub -> Archive (size=0x14)
    // 0x81374c: stur            x0, [fp, #-8]
    // 0x813750: SaveReg r0
    //     0x813750: str             x0, [SP, #-8]!
    // 0x813754: r0 = Archive()
    //     0x813754: bl              #0x813dd0  ; [package:archive/src/archive.dart] Archive::Archive
    // 0x813758: add             SP, SP, #8
    // 0x81375c: ldr             x0, [fp, #0x18]
    // 0x813760: LoadField: r1 = r0->field_7
    //     0x813760: ldur            w1, [x0, #7]
    // 0x813764: DecompressPointer r1
    //     0x813764: add             x1, x1, HEAP, lsl #32
    // 0x813768: LoadField: r2 = r1->field_17
    //     0x813768: ldur            w2, [x1, #0x17]
    // 0x81376c: DecompressPointer r2
    //     0x81376c: add             x2, x2, HEAP, lsl #32
    // 0x813770: stur            x2, [fp, #-0x28]
    // 0x813774: LoadField: r1 = r2->field_7
    //     0x813774: ldur            w1, [x2, #7]
    // 0x813778: DecompressPointer r1
    //     0x813778: add             x1, x1, HEAP, lsl #32
    // 0x81377c: stur            x1, [fp, #-0x20]
    // 0x813780: LoadField: r0 = r2->field_b
    //     0x813780: ldur            w0, [x2, #0xb]
    // 0x813784: DecompressPointer r0
    //     0x813784: add             x0, x0, HEAP, lsl #32
    // 0x813788: r3 = LoadInt32Instr(r0)
    //     0x813788: sbfx            x3, x0, #1, #0x1f
    // 0x81378c: stur            x3, [fp, #-0x18]
    // 0x813790: r4 = 0
    //     0x813790: mov             x4, #0
    // 0x813794: stur            x4, [fp, #-0x10]
    // 0x813798: CheckStackOverflow
    //     0x813798: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81379c: cmp             SP, x16
    //     0x8137a0: b.ls            #0x813b30
    // 0x8137a4: r0 = LoadClassIdInstr(r2)
    //     0x8137a4: ldur            x0, [x2, #-1]
    //     0x8137a8: ubfx            x0, x0, #0xc, #0x14
    // 0x8137ac: SaveReg r2
    //     0x8137ac: str             x2, [SP, #-8]!
    // 0x8137b0: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x8137b0: mov             x17, #0xb8ea
    //     0x8137b4: add             lr, x0, x17
    //     0x8137b8: ldr             lr, [x21, lr, lsl #3]
    //     0x8137bc: blr             lr
    // 0x8137c0: add             SP, SP, #8
    // 0x8137c4: r1 = LoadInt32Instr(r0)
    //     0x8137c4: sbfx            x1, x0, #1, #0x1f
    //     0x8137c8: tbz             w0, #0, #0x8137d0
    //     0x8137cc: ldur            x1, [x0, #7]
    // 0x8137d0: ldur            x2, [fp, #-0x18]
    // 0x8137d4: cmp             x2, x1
    // 0x8137d8: b.ne            #0x813b10
    // 0x8137dc: ldur            x3, [fp, #-0x28]
    // 0x8137e0: ldur            x4, [fp, #-0x10]
    // 0x8137e4: cmp             x4, x1
    // 0x8137e8: b.lt            #0x8137fc
    // 0x8137ec: ldur            x0, [fp, #-8]
    // 0x8137f0: LeaveFrame
    //     0x8137f0: mov             SP, fp
    //     0x8137f4: ldp             fp, lr, [SP], #0x10
    // 0x8137f8: ret
    //     0x8137f8: ret             
    // 0x8137fc: r0 = BoxInt64Instr(r4)
    //     0x8137fc: sbfiz           x0, x4, #1, #0x1f
    //     0x813800: cmp             x4, x0, asr #1
    //     0x813804: b.eq            #0x813810
    //     0x813808: bl              #0xd69bb8
    //     0x81380c: stur            x4, [x0, #7]
    // 0x813810: r1 = LoadClassIdInstr(r3)
    //     0x813810: ldur            x1, [x3, #-1]
    //     0x813814: ubfx            x1, x1, #0xc, #0x14
    // 0x813818: stp             x0, x3, [SP, #-0x10]!
    // 0x81381c: mov             x0, x1
    // 0x813820: r0 = GDT[cid_x0 + 0xd175]()
    //     0x813820: mov             x17, #0xd175
    //     0x813824: add             lr, x0, x17
    //     0x813828: ldr             lr, [x21, lr, lsl #3]
    //     0x81382c: blr             lr
    // 0x813830: add             SP, SP, #0x10
    // 0x813834: mov             x3, x0
    // 0x813838: ldur            x0, [fp, #-0x10]
    // 0x81383c: stur            x3, [fp, #-0x38]
    // 0x813840: add             x4, x0, #1
    // 0x813844: stur            x4, [fp, #-0x30]
    // 0x813848: cmp             w3, NULL
    // 0x81384c: b.ne            #0x813880
    // 0x813850: mov             x0, x3
    // 0x813854: ldur            x2, [fp, #-0x20]
    // 0x813858: r1 = Null
    //     0x813858: mov             x1, NULL
    // 0x81385c: cmp             w2, NULL
    // 0x813860: b.eq            #0x813880
    // 0x813864: LoadField: r4 = r2->field_17
    //     0x813864: ldur            w4, [x2, #0x17]
    // 0x813868: DecompressPointer r4
    //     0x813868: add             x4, x4, HEAP, lsl #32
    // 0x81386c: r8 = X0
    //     0x81386c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x813870: LoadField: r9 = r4->field_7
    //     0x813870: ldur            x9, [x4, #7]
    // 0x813874: r3 = Null
    //     0x813874: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a970] Null
    //     0x813878: ldr             x3, [x3, #0x970]
    // 0x81387c: blr             x9
    // 0x813880: ldur            x0, [fp, #-0x38]
    // 0x813884: LoadField: r1 = r0->field_27
    //     0x813884: ldur            w1, [x0, #0x27]
    // 0x813888: DecompressPointer r1
    //     0x813888: add             x1, x1, HEAP, lsl #32
    // 0x81388c: stur            x1, [fp, #-0x58]
    // 0x813890: cmp             w1, NULL
    // 0x813894: b.eq            #0x813b38
    // 0x813898: LoadField: r2 = r0->field_1b
    //     0x813898: ldur            w2, [x0, #0x1b]
    // 0x81389c: DecompressPointer r2
    //     0x81389c: add             x2, x2, HEAP, lsl #32
    // 0x8138a0: stur            x2, [fp, #-0x50]
    // 0x8138a4: cmp             w2, NULL
    // 0x8138a8: b.eq            #0x813b3c
    // 0x8138ac: LoadField: r3 = r1->field_17
    //     0x8138ac: ldur            x3, [x1, #0x17]
    // 0x8138b0: stur            x3, [fp, #-0x10]
    // 0x8138b4: LoadField: r4 = r1->field_37
    //     0x8138b4: ldur            w4, [x1, #0x37]
    // 0x8138b8: DecompressPointer r4
    //     0x8138b8: add             x4, x4, HEAP, lsl #32
    // 0x8138bc: stur            x4, [fp, #-0x48]
    // 0x8138c0: LoadField: r5 = r1->field_33
    //     0x8138c0: ldur            w5, [x1, #0x33]
    // 0x8138c4: DecompressPointer r5
    //     0x8138c4: add             x5, x5, HEAP, lsl #32
    // 0x8138c8: stur            x5, [fp, #-0x40]
    // 0x8138cc: cmp             w5, NULL
    // 0x8138d0: b.eq            #0x813b40
    // 0x8138d4: r0 = ArchiveFile()
    //     0x8138d4: bl              #0x813dc4  ; AllocateArchiveFileStub -> ArchiveFile (size=0x2c)
    // 0x8138d8: mov             x1, x0
    // 0x8138dc: r0 = 420
    //     0x8138dc: mov             x0, #0x1a4
    // 0x8138e0: stur            x1, [fp, #-0x60]
    // 0x8138e4: StoreField: r1->field_13 = r0
    //     0x8138e4: stur            x0, [x1, #0x13]
    // 0x8138e8: r0 = _getCurrentMicros()
    //     0x8138e8: bl              #0x589be8  ; [dart:core] DateTime::_getCurrentMicros
    // 0x8138ec: r1 = LoadInt32Instr(r0)
    //     0x8138ec: sbfx            x1, x0, #1, #0x1f
    //     0x8138f0: tbz             w0, #0, #0x8138f8
    //     0x8138f4: ldur            x1, [x0, #7]
    // 0x8138f8: r2 = 1000
    //     0x8138f8: mov             x2, #0x3e8
    // 0x8138fc: sdiv            x0, x1, x2
    // 0x813900: sdiv            x1, x0, x2
    // 0x813904: ldur            x0, [fp, #-0x48]
    // 0x813908: ldur            x1, [fp, #-0x60]
    // 0x81390c: StoreField: r1->field_7 = r0
    //     0x81390c: stur            w0, [x1, #7]
    //     0x813910: ldurb           w16, [x1, #-1]
    //     0x813914: ldurb           w17, [x0, #-1]
    //     0x813918: and             x16, x17, x16, lsr #2
    //     0x81391c: tst             x16, HEAP, lsr #32
    //     0x813920: b.eq            #0x813928
    //     0x813924: bl              #0xd6826c
    // 0x813928: ldur            x0, [fp, #-0x40]
    // 0x81392c: r3 = LoadInt32Instr(r0)
    //     0x81392c: sbfx            x3, x0, #1, #0x1f
    //     0x813930: tbz             w0, #0, #0x813938
    //     0x813934: ldur            x3, [x0, #7]
    // 0x813938: StoreField: r1->field_b = r3
    //     0x813938: stur            x3, [x1, #0xb]
    // 0x81393c: ldur            x0, [fp, #-0x10]
    // 0x813940: StoreField: r1->field_1b = r0
    //     0x813940: stur            x0, [x1, #0x1b]
    // 0x813944: ldur            x16, [fp, #-0x48]
    // 0x813948: r30 = "\\"
    //     0x813948: ldr             lr, [PP, #0x1230]  ; [pp+0x1230] "\\"
    // 0x81394c: stp             lr, x16, [SP, #-0x10]!
    // 0x813950: r16 = "/"
    //     0x813950: ldr             x16, [PP, #0x768]  ; [pp+0x768] "/"
    // 0x813954: SaveReg r16
    //     0x813954: str             x16, [SP, #-8]!
    // 0x813958: r0 = replaceAll()
    //     0x813958: bl              #0x4bca70  ; [dart:core] _StringBase::replaceAll
    // 0x81395c: add             SP, SP, #0x18
    // 0x813960: mov             x2, x0
    // 0x813964: ldur            x1, [fp, #-0x60]
    // 0x813968: StoreField: r1->field_7 = r0
    //     0x813968: stur            w0, [x1, #7]
    //     0x81396c: ldurb           w16, [x1, #-1]
    //     0x813970: ldurb           w17, [x0, #-1]
    //     0x813974: and             x16, x17, x16, lsr #2
    //     0x813978: tst             x16, HEAP, lsr #32
    //     0x81397c: b.eq            #0x813984
    //     0x813980: bl              #0xd6826c
    // 0x813984: ldur            x0, [fp, #-0x58]
    // 0x813988: StoreField: r1->field_27 = r0
    //     0x813988: stur            w0, [x1, #0x27]
    //     0x81398c: ldurb           w16, [x1, #-1]
    //     0x813990: ldurb           w17, [x0, #-1]
    //     0x813994: and             x16, x17, x16, lsr #2
    //     0x813998: tst             x16, HEAP, lsr #32
    //     0x81399c: b.eq            #0x8139a4
    //     0x8139a0: bl              #0xd6826c
    // 0x8139a4: ldur            x0, [fp, #-0x50]
    // 0x8139a8: r3 = LoadInt32Instr(r0)
    //     0x8139a8: sbfx            x3, x0, #1, #0x1f
    //     0x8139ac: tbz             w0, #0, #0x8139b4
    //     0x8139b0: ldur            x3, [x0, #7]
    // 0x8139b4: asr             x0, x3, #0x10
    // 0x8139b8: StoreField: r1->field_13 = r0
    //     0x8139b8: stur            x0, [x1, #0x13]
    // 0x8139bc: ldur            x3, [fp, #-0x38]
    // 0x8139c0: LoadField: r4 = r3->field_7
    //     0x8139c0: ldur            x4, [x3, #7]
    // 0x8139c4: asr             x3, x4, #8
    // 0x8139c8: cmp             x3, #3
    // 0x8139cc: b.ne            #0x813ac0
    // 0x8139d0: r2 = 61440
    //     0x8139d0: mov             x2, #0xf000
    // 0x8139d4: ubfx            x0, x0, #0, #0x20
    // 0x8139d8: and             x3, x0, x2
    // 0x8139dc: lsl             w0, w3, #1
    // 0x8139e0: ubfx            x3, x3, #0, #0x20
    // 0x8139e4: cmp             x3, #8, lsl #12
    // 0x8139e8: b.gt            #0x813a08
    // 0x8139ec: cmp             x3, #0
    // 0x8139f0: b.gt            #0x8139fc
    // 0x8139f4: cbnz            w0, #0x813ae8
    // 0x8139f8: b               #0x813ae8
    // 0x8139fc: cmp             x3, #8, lsl #12
    // 0x813a00: b.lt            #0x813ae8
    // 0x813a04: b               #0x813ae8
    // 0x813a08: cmp             x3, #0xa, lsl #12
    // 0x813a0c: b.lt            #0x813ae8
    // 0x813a10: cmp             w0, #0x14, lsl #12
    // 0x813a14: b.ne            #0x813ae8
    // 0x813a18: ldur            x16, [fp, #-0x58]
    // 0x813a1c: SaveReg r16
    //     0x813a1c: str             x16, [SP, #-8]!
    // 0x813a20: r4 = 0
    //     0x813a20: mov             x4, #0
    // 0x813a24: ldr             x0, [SP]
    // 0x813a28: r16 = UnlinkedCall_0x4aeefc
    //     0x813a28: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a980] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x813a2c: add             x16, x16, #0x980
    // 0x813a30: ldp             x5, lr, [x16]
    // 0x813a34: blr             lr
    // 0x813a38: add             SP, SP, #8
    // 0x813a3c: mov             x2, x0
    // 0x813a40: ldur            x1, [fp, #-0x60]
    // 0x813a44: StoreField: r1->field_27 = r0
    //     0x813a44: stur            w0, [x1, #0x27]
    //     0x813a48: tbz             w0, #0, #0x813a64
    //     0x813a4c: ldurb           w16, [x1, #-1]
    //     0x813a50: ldurb           w17, [x0, #-1]
    //     0x813a54: and             x16, x17, x16, lsr #2
    //     0x813a58: tst             x16, HEAP, lsr #32
    //     0x813a5c: b.eq            #0x813a64
    //     0x813a60: bl              #0xd6826c
    // 0x813a64: cmp             w2, NULL
    // 0x813a68: b.ne            #0x813a78
    // 0x813a6c: SaveReg r1
    //     0x813a6c: str             x1, [SP, #-8]!
    // 0x813a70: r0 = decompress()
    //     0x813a70: bl              #0x7f56a0  ; [package:archive/src/archive_file.dart] ArchiveFile::decompress
    // 0x813a74: add             SP, SP, #8
    // 0x813a78: ldur            x3, [fp, #-0x60]
    // 0x813a7c: LoadField: r4 = r3->field_27
    //     0x813a7c: ldur            w4, [x3, #0x27]
    // 0x813a80: DecompressPointer r4
    //     0x813a80: add             x4, x4, HEAP, lsl #32
    // 0x813a84: mov             x0, x4
    // 0x813a88: stur            x4, [fp, #-0x38]
    // 0x813a8c: r2 = Null
    //     0x813a8c: mov             x2, NULL
    // 0x813a90: r1 = Null
    //     0x813a90: mov             x1, NULL
    // 0x813a94: r8 = List<int>
    //     0x813a94: ldr             x8, [PP, #0xa60]  ; [pp+0xa60] Type: List<int>
    // 0x813a98: r3 = Null
    //     0x813a98: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a990] Null
    //     0x813a9c: ldr             x3, [x3, #0x990]
    // 0x813aa0: r0 = List<int>()
    //     0x813aa0: bl              #0x4b2744  ; IsType_List<int>_Stub
    // 0x813aa4: r16 = Instance_Utf8Decoder
    //     0x813aa4: ldr             x16, [PP, #0xa48]  ; [pp+0xa48] Obj!Utf8Decoder<List<int>, String>@b5f7a1
    // 0x813aa8: ldur            lr, [fp, #-0x38]
    // 0x813aac: stp             lr, x16, [SP, #-0x10]!
    // 0x813ab0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x813ab0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x813ab4: r0 = convert()
    //     0x813ab4: bl              #0xc1ed20  ; [dart:convert] Utf8Decoder::convert
    // 0x813ab8: add             SP, SP, #0x10
    // 0x813abc: b               #0x813ae8
    // 0x813ac0: LoadField: r0 = r2->field_7
    //     0x813ac0: ldur            w0, [x2, #7]
    // 0x813ac4: DecompressPointer r0
    //     0x813ac4: add             x0, x0, HEAP, lsl #32
    // 0x813ac8: r1 = LoadInt32Instr(r0)
    //     0x813ac8: sbfx            x1, x0, #1, #0x1f
    // 0x813acc: sub             x0, x1, #1
    // 0x813ad0: lsl             x1, x0, #1
    // 0x813ad4: stp             x1, x2, [SP, #-0x10]!
    // 0x813ad8: r16 = "/"
    //     0x813ad8: ldr             x16, [PP, #0x768]  ; [pp+0x768] "/"
    // 0x813adc: SaveReg r16
    //     0x813adc: str             x16, [SP, #-8]!
    // 0x813ae0: r0 = _substringMatches()
    //     0x813ae0: bl              #0x4e15f8  ; [dart:core] _StringBase::_substringMatches
    // 0x813ae4: add             SP, SP, #0x18
    // 0x813ae8: ldur            x16, [fp, #-8]
    // 0x813aec: ldur            lr, [fp, #-0x60]
    // 0x813af0: stp             lr, x16, [SP, #-0x10]!
    // 0x813af4: r0 = addFile()
    //     0x813af4: bl              #0x813b44  ; [package:archive/src/archive.dart] Archive::addFile
    // 0x813af8: add             SP, SP, #0x10
    // 0x813afc: ldur            x4, [fp, #-0x30]
    // 0x813b00: ldur            x2, [fp, #-0x28]
    // 0x813b04: ldur            x1, [fp, #-0x20]
    // 0x813b08: ldur            x3, [fp, #-0x18]
    // 0x813b0c: b               #0x813794
    // 0x813b10: ldur            x0, [fp, #-0x28]
    // 0x813b14: r0 = ConcurrentModificationError()
    //     0x813b14: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x813b18: ldur            x3, [fp, #-0x28]
    // 0x813b1c: StoreField: r0->field_b = r3
    //     0x813b1c: stur            w3, [x0, #0xb]
    // 0x813b20: r0 = Throw()
    //     0x813b20: bl              #0xd67e38  ; ThrowStub
    // 0x813b24: brk             #0
    // 0x813b28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x813b28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x813b2c: b               #0x813704
    // 0x813b30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x813b30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x813b34: b               #0x8137a4
    // 0x813b38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x813b38: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x813b3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x813b3c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x813b40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x813b40: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// lib: , url: package:archive/src/zip/zip_directory.dart

// class id: 1048622, size: 0x8
class :: {
}

// class id: 4999, size: 0x1c, field offset: 0x8
class ZipDirectory extends Object {

  _ ZipDirectory.read(/* No info */) {
    // ** addr: 0x813e74, size: 0x34c
    // 0x813e74: EnterFrame
    //     0x813e74: stp             fp, lr, [SP, #-0x10]!
    //     0x813e78: mov             fp, SP
    // 0x813e7c: AllocStack(0x20)
    //     0x813e7c: sub             SP, SP, #0x20
    // 0x813e80: r1 = Sentinel
    //     0x813e80: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x813e84: r0 = -1
    //     0x813e84: mov             x0, #-1
    // 0x813e88: CheckStackOverflow
    //     0x813e88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x813e8c: cmp             SP, x16
    //     0x813e90: b.ls            #0x8141a0
    // 0x813e94: ldr             x2, [fp, #0x18]
    // 0x813e98: StoreField: r2->field_f = r1
    //     0x813e98: stur            w1, [x2, #0xf]
    // 0x813e9c: StoreField: r2->field_13 = r1
    //     0x813e9c: stur            w1, [x2, #0x13]
    // 0x813ea0: StoreField: r2->field_7 = r0
    //     0x813ea0: stur            x0, [x2, #7]
    // 0x813ea4: r16 = <ZipFileHeader>
    //     0x813ea4: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a9a0] TypeArguments: <ZipFileHeader>
    //     0x813ea8: ldr             x16, [x16, #0x9a0]
    // 0x813eac: stp             xzr, x16, [SP, #-0x10]!
    // 0x813eb0: r0 = _GrowableList()
    //     0x813eb0: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x813eb4: add             SP, SP, #0x10
    // 0x813eb8: ldr             x1, [fp, #0x18]
    // 0x813ebc: StoreField: r1->field_17 = r0
    //     0x813ebc: stur            w0, [x1, #0x17]
    //     0x813ec0: ldurb           w16, [x1, #-1]
    //     0x813ec4: ldurb           w17, [x0, #-1]
    //     0x813ec8: and             x16, x17, x16, lsr #2
    //     0x813ecc: tst             x16, HEAP, lsr #32
    //     0x813ed0: b.eq            #0x813ed8
    //     0x813ed4: bl              #0xd6826c
    // 0x813ed8: ldr             x16, [fp, #0x10]
    // 0x813edc: stp             x16, x1, [SP, #-0x10]!
    // 0x813ee0: r0 = _findSignature()
    //     0x813ee0: bl              #0x818634  ; [package:archive/src/zip/zip_directory.dart] ZipDirectory::_findSignature
    // 0x813ee4: add             SP, SP, #0x10
    // 0x813ee8: mov             x1, x0
    // 0x813eec: ldr             x0, [fp, #0x18]
    // 0x813ef0: StoreField: r0->field_7 = r1
    //     0x813ef0: stur            x1, [x0, #7]
    // 0x813ef4: ldr             x2, [fp, #0x10]
    // 0x813ef8: LoadField: r3 = r2->field_13
    //     0x813ef8: ldur            x3, [x2, #0x13]
    // 0x813efc: add             x4, x3, x1
    // 0x813f00: StoreField: r2->field_b = r4
    //     0x813f00: stur            x4, [x2, #0xb]
    // 0x813f04: SaveReg r2
    //     0x813f04: str             x2, [SP, #-8]!
    // 0x813f08: r0 = readUint32()
    //     0x813f08: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x813f0c: add             SP, SP, #8
    // 0x813f10: ldr             x16, [fp, #0x10]
    // 0x813f14: SaveReg r16
    //     0x813f14: str             x16, [SP, #-8]!
    // 0x813f18: r0 = readUint16()
    //     0x813f18: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x813f1c: add             SP, SP, #8
    // 0x813f20: ldr             x16, [fp, #0x10]
    // 0x813f24: SaveReg r16
    //     0x813f24: str             x16, [SP, #-8]!
    // 0x813f28: r0 = readUint16()
    //     0x813f28: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x813f2c: add             SP, SP, #8
    // 0x813f30: ldr             x16, [fp, #0x10]
    // 0x813f34: SaveReg r16
    //     0x813f34: str             x16, [SP, #-8]!
    // 0x813f38: r0 = readUint16()
    //     0x813f38: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x813f3c: add             SP, SP, #8
    // 0x813f40: ldr             x16, [fp, #0x10]
    // 0x813f44: SaveReg r16
    //     0x813f44: str             x16, [SP, #-8]!
    // 0x813f48: r0 = readUint16()
    //     0x813f48: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x813f4c: add             SP, SP, #8
    // 0x813f50: ldr             x16, [fp, #0x10]
    // 0x813f54: SaveReg r16
    //     0x813f54: str             x16, [SP, #-8]!
    // 0x813f58: r0 = readUint32()
    //     0x813f58: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x813f5c: add             SP, SP, #8
    // 0x813f60: mov             x2, x0
    // 0x813f64: r0 = BoxInt64Instr(r2)
    //     0x813f64: sbfiz           x0, x2, #1, #0x1f
    //     0x813f68: cmp             x2, x0, asr #1
    //     0x813f6c: b.eq            #0x813f78
    //     0x813f70: bl              #0xd69bb8
    //     0x813f74: stur            x2, [x0, #7]
    // 0x813f78: ldr             x1, [fp, #0x18]
    // 0x813f7c: StoreField: r1->field_f = r0
    //     0x813f7c: stur            w0, [x1, #0xf]
    //     0x813f80: tbz             w0, #0, #0x813f9c
    //     0x813f84: ldurb           w16, [x1, #-1]
    //     0x813f88: ldurb           w17, [x0, #-1]
    //     0x813f8c: and             x16, x17, x16, lsr #2
    //     0x813f90: tst             x16, HEAP, lsr #32
    //     0x813f94: b.eq            #0x813f9c
    //     0x813f98: bl              #0xd6826c
    // 0x813f9c: ldr             x16, [fp, #0x10]
    // 0x813fa0: SaveReg r16
    //     0x813fa0: str             x16, [SP, #-8]!
    // 0x813fa4: r0 = readUint32()
    //     0x813fa4: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x813fa8: add             SP, SP, #8
    // 0x813fac: mov             x2, x0
    // 0x813fb0: r0 = BoxInt64Instr(r2)
    //     0x813fb0: sbfiz           x0, x2, #1, #0x1f
    //     0x813fb4: cmp             x2, x0, asr #1
    //     0x813fb8: b.eq            #0x813fc4
    //     0x813fbc: bl              #0xd69bb8
    //     0x813fc0: stur            x2, [x0, #7]
    // 0x813fc4: ldr             x1, [fp, #0x18]
    // 0x813fc8: StoreField: r1->field_13 = r0
    //     0x813fc8: stur            w0, [x1, #0x13]
    //     0x813fcc: tbz             w0, #0, #0x813fe8
    //     0x813fd0: ldurb           w16, [x1, #-1]
    //     0x813fd4: ldurb           w17, [x0, #-1]
    //     0x813fd8: and             x16, x17, x16, lsr #2
    //     0x813fdc: tst             x16, HEAP, lsr #32
    //     0x813fe0: b.eq            #0x813fe8
    //     0x813fe4: bl              #0xd6826c
    // 0x813fe8: ldr             x16, [fp, #0x10]
    // 0x813fec: SaveReg r16
    //     0x813fec: str             x16, [SP, #-8]!
    // 0x813ff0: r0 = readUint16()
    //     0x813ff0: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x813ff4: add             SP, SP, #8
    // 0x813ff8: cmp             x0, #0
    // 0x813ffc: b.le            #0x814020
    // 0x814000: ldr             x16, [fp, #0x10]
    // 0x814004: stp             x0, x16, [SP, #-0x10]!
    // 0x814008: r16 = false
    //     0x814008: add             x16, NULL, #0x30  ; false
    // 0x81400c: SaveReg r16
    //     0x81400c: str             x16, [SP, #-8]!
    // 0x814010: r4 = const [0, 0x3, 0x3, 0x2, utf8, 0x2, null]
    //     0x814010: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3a9a8] List(7) [0, 0x3, 0x3, 0x2, "utf8", 0x2, Null]
    //     0x814014: ldr             x4, [x4, #0x9a8]
    // 0x814018: r0 = readString()
    //     0x814018: bl              #0x818198  ; [package:archive/src/util/input_stream.dart] InputStream::readString
    // 0x81401c: add             SP, SP, #0x18
    // 0x814020: ldr             x0, [fp, #0x18]
    // 0x814024: ldr             x16, [fp, #0x10]
    // 0x814028: stp             x16, x0, [SP, #-0x10]!
    // 0x81402c: r0 = _readZip64Data()
    //     0x81402c: bl              #0x817f14  ; [package:archive/src/zip/zip_directory.dart] ZipDirectory::_readZip64Data
    // 0x814030: add             SP, SP, #0x10
    // 0x814034: ldr             x0, [fp, #0x18]
    // 0x814038: LoadField: r1 = r0->field_13
    //     0x814038: ldur            w1, [x0, #0x13]
    // 0x81403c: DecompressPointer r1
    //     0x81403c: add             x1, x1, HEAP, lsl #32
    // 0x814040: LoadField: r2 = r0->field_f
    //     0x814040: ldur            w2, [x0, #0xf]
    // 0x814044: DecompressPointer r2
    //     0x814044: add             x2, x2, HEAP, lsl #32
    // 0x814048: r3 = LoadInt32Instr(r2)
    //     0x814048: sbfx            x3, x2, #1, #0x1f
    //     0x81404c: tbz             w2, #0, #0x814054
    //     0x814050: ldur            x3, [x2, #7]
    // 0x814054: ldr             x16, [fp, #0x10]
    // 0x814058: stp             x1, x16, [SP, #-0x10]!
    // 0x81405c: SaveReg r3
    //     0x81405c: str             x3, [SP, #-8]!
    // 0x814060: r0 = subset()
    //     0x814060: bl              #0x817e0c  ; [package:archive/src/util/input_stream.dart] InputStream::subset
    // 0x814064: add             SP, SP, #0x18
    // 0x814068: stur            x0, [fp, #-8]
    // 0x81406c: ldr             x1, [fp, #0x18]
    // 0x814070: CheckStackOverflow
    //     0x814070: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x814074: cmp             SP, x16
    //     0x814078: b.ls            #0x8141a8
    // 0x81407c: LoadField: r2 = r0->field_b
    //     0x81407c: ldur            x2, [x0, #0xb]
    // 0x814080: LoadField: r3 = r0->field_13
    //     0x814080: ldur            x3, [x0, #0x13]
    // 0x814084: LoadField: r4 = r0->field_23
    //     0x814084: ldur            w4, [x0, #0x23]
    // 0x814088: DecompressPointer r4
    //     0x814088: add             x4, x4, HEAP, lsl #32
    // 0x81408c: r16 = Sentinel
    //     0x81408c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x814090: cmp             w4, w16
    // 0x814094: b.eq            #0x8141b0
    // 0x814098: r5 = LoadInt32Instr(r4)
    //     0x814098: sbfx            x5, x4, #1, #0x1f
    //     0x81409c: tbz             w4, #0, #0x8140a4
    //     0x8140a0: ldur            x5, [x4, #7]
    // 0x8140a4: add             x4, x3, x5
    // 0x8140a8: cmp             x2, x4
    // 0x8140ac: b.ge            #0x814190
    // 0x8140b0: SaveReg r0
    //     0x8140b0: str             x0, [SP, #-8]!
    // 0x8140b4: r0 = readUint32()
    //     0x8140b4: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x8140b8: add             SP, SP, #8
    // 0x8140bc: r17 = 33639248
    //     0x8140bc: mov             x17, #0x4b50
    //     0x8140c0: movk            x17, #0x201, lsl #16
    // 0x8140c4: cmp             x0, x17
    // 0x8140c8: b.ne            #0x814190
    // 0x8140cc: ldr             x0, [fp, #0x18]
    // 0x8140d0: LoadField: r1 = r0->field_17
    //     0x8140d0: ldur            w1, [x0, #0x17]
    // 0x8140d4: DecompressPointer r1
    //     0x8140d4: add             x1, x1, HEAP, lsl #32
    // 0x8140d8: stur            x1, [fp, #-0x10]
    // 0x8140dc: r0 = ZipFileHeader()
    //     0x8140dc: bl              #0x817e00  ; AllocateZipFileHeaderStub -> ZipFileHeader (size=0x2c)
    // 0x8140e0: stur            x0, [fp, #-0x18]
    // 0x8140e4: ldur            x16, [fp, #-8]
    // 0x8140e8: stp             x16, x0, [SP, #-0x10]!
    // 0x8140ec: ldr             x16, [fp, #0x10]
    // 0x8140f0: SaveReg r16
    //     0x8140f0: str             x16, [SP, #-8]!
    // 0x8140f4: r0 = ZipFileHeader()
    //     0x8140f4: bl              #0x8141c0  ; [package:archive/src/zip/zip_file_header.dart] ZipFileHeader::ZipFileHeader
    // 0x8140f8: add             SP, SP, #0x18
    // 0x8140fc: ldur            x0, [fp, #-0x10]
    // 0x814100: LoadField: r1 = r0->field_b
    //     0x814100: ldur            w1, [x0, #0xb]
    // 0x814104: DecompressPointer r1
    //     0x814104: add             x1, x1, HEAP, lsl #32
    // 0x814108: stur            x1, [fp, #-0x20]
    // 0x81410c: LoadField: r2 = r0->field_f
    //     0x81410c: ldur            w2, [x0, #0xf]
    // 0x814110: DecompressPointer r2
    //     0x814110: add             x2, x2, HEAP, lsl #32
    // 0x814114: LoadField: r3 = r2->field_b
    //     0x814114: ldur            w3, [x2, #0xb]
    // 0x814118: DecompressPointer r3
    //     0x814118: add             x3, x3, HEAP, lsl #32
    // 0x81411c: cmp             w1, w3
    // 0x814120: b.ne            #0x814130
    // 0x814124: SaveReg r0
    //     0x814124: str             x0, [SP, #-8]!
    // 0x814128: r0 = _growToNextCapacity()
    //     0x814128: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x81412c: add             SP, SP, #8
    // 0x814130: ldur            x2, [fp, #-0x10]
    // 0x814134: ldur            x3, [fp, #-0x20]
    // 0x814138: r4 = LoadInt32Instr(r3)
    //     0x814138: sbfx            x4, x3, #1, #0x1f
    // 0x81413c: add             x0, x4, #1
    // 0x814140: lsl             x3, x0, #1
    // 0x814144: StoreField: r2->field_b = r3
    //     0x814144: stur            w3, [x2, #0xb]
    // 0x814148: mov             x1, x4
    // 0x81414c: cmp             x1, x0
    // 0x814150: b.hs            #0x8141bc
    // 0x814154: LoadField: r1 = r2->field_f
    //     0x814154: ldur            w1, [x2, #0xf]
    // 0x814158: DecompressPointer r1
    //     0x814158: add             x1, x1, HEAP, lsl #32
    // 0x81415c: ldur            x0, [fp, #-0x18]
    // 0x814160: ArrayStore: r1[r4] = r0  ; List_4
    //     0x814160: add             x25, x1, x4, lsl #2
    //     0x814164: add             x25, x25, #0xf
    //     0x814168: str             w0, [x25]
    //     0x81416c: tbz             w0, #0, #0x814188
    //     0x814170: ldurb           w16, [x1, #-1]
    //     0x814174: ldurb           w17, [x0, #-1]
    //     0x814178: and             x16, x17, x16, lsr #2
    //     0x81417c: tst             x16, HEAP, lsr #32
    //     0x814180: b.eq            #0x814188
    //     0x814184: bl              #0xd67e5c
    // 0x814188: ldur            x0, [fp, #-8]
    // 0x81418c: b               #0x81406c
    // 0x814190: r0 = Null
    //     0x814190: mov             x0, NULL
    // 0x814194: LeaveFrame
    //     0x814194: mov             SP, fp
    //     0x814198: ldp             fp, lr, [SP], #0x10
    // 0x81419c: ret
    //     0x81419c: ret             
    // 0x8141a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8141a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8141a4: b               #0x813e94
    // 0x8141a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8141a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8141ac: b               #0x81407c
    // 0x8141b0: r9 = _length
    //     0x8141b0: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a20] Field <InputStream._length@54080104>: late (offset: 0x24)
    //     0x8141b4: ldr             x9, [x9, #0xa20]
    // 0x8141b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8141b8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8141bc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8141bc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _readZip64Data(/* No info */) {
    // ** addr: 0x817f14, size: 0x284
    // 0x817f14: EnterFrame
    //     0x817f14: stp             fp, lr, [SP, #-0x10]!
    //     0x817f18: mov             fp, SP
    // 0x817f1c: AllocStack(0x18)
    //     0x817f1c: sub             SP, SP, #0x18
    // 0x817f20: CheckStackOverflow
    //     0x817f20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x817f24: cmp             SP, x16
    //     0x817f28: b.ls            #0x818190
    // 0x817f2c: ldr             x2, [fp, #0x10]
    // 0x817f30: LoadField: r0 = r2->field_b
    //     0x817f30: ldur            x0, [x2, #0xb]
    // 0x817f34: LoadField: r1 = r2->field_13
    //     0x817f34: ldur            x1, [x2, #0x13]
    // 0x817f38: sub             x3, x0, x1
    // 0x817f3c: ldr             x4, [fp, #0x18]
    // 0x817f40: stur            x3, [fp, #-8]
    // 0x817f44: LoadField: r0 = r4->field_7
    //     0x817f44: ldur            x0, [x4, #7]
    // 0x817f48: sub             x5, x0, #0x14
    // 0x817f4c: tbz             x5, #0x3f, #0x817f60
    // 0x817f50: r0 = Null
    //     0x817f50: mov             x0, NULL
    // 0x817f54: LeaveFrame
    //     0x817f54: mov             SP, fp
    //     0x817f58: ldp             fp, lr, [SP], #0x10
    // 0x817f5c: ret
    //     0x817f5c: ret             
    // 0x817f60: r6 = 20
    //     0x817f60: mov             x6, #0x14
    // 0x817f64: r0 = BoxInt64Instr(r5)
    //     0x817f64: sbfiz           x0, x5, #1, #0x1f
    //     0x817f68: cmp             x5, x0, asr #1
    //     0x817f6c: b.eq            #0x817f78
    //     0x817f70: bl              #0xd69bb8
    //     0x817f74: stur            x5, [x0, #7]
    // 0x817f78: stp             x0, x2, [SP, #-0x10]!
    // 0x817f7c: SaveReg r6
    //     0x817f7c: str             x6, [SP, #-8]!
    // 0x817f80: r0 = subset()
    //     0x817f80: bl              #0x817e0c  ; [package:archive/src/util/input_stream.dart] InputStream::subset
    // 0x817f84: add             SP, SP, #0x18
    // 0x817f88: stur            x0, [fp, #-0x10]
    // 0x817f8c: SaveReg r0
    //     0x817f8c: str             x0, [SP, #-8]!
    // 0x817f90: r0 = readUint32()
    //     0x817f90: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x817f94: add             SP, SP, #8
    // 0x817f98: r17 = 117853008
    //     0x817f98: mov             x17, #0x4b50
    //     0x817f9c: movk            x17, #0x706, lsl #16
    // 0x817fa0: cmp             x0, x17
    // 0x817fa4: b.eq            #0x817fcc
    // 0x817fa8: ldr             x0, [fp, #0x10]
    // 0x817fac: ldur            x1, [fp, #-8]
    // 0x817fb0: LoadField: r2 = r0->field_13
    //     0x817fb0: ldur            x2, [x0, #0x13]
    // 0x817fb4: add             x3, x2, x1
    // 0x817fb8: StoreField: r0->field_b = r3
    //     0x817fb8: stur            x3, [x0, #0xb]
    // 0x817fbc: r0 = Null
    //     0x817fbc: mov             x0, NULL
    // 0x817fc0: LeaveFrame
    //     0x817fc0: mov             SP, fp
    //     0x817fc4: ldp             fp, lr, [SP], #0x10
    // 0x817fc8: ret
    //     0x817fc8: ret             
    // 0x817fcc: ldr             x0, [fp, #0x10]
    // 0x817fd0: ldur            x1, [fp, #-8]
    // 0x817fd4: ldur            x16, [fp, #-0x10]
    // 0x817fd8: SaveReg r16
    //     0x817fd8: str             x16, [SP, #-8]!
    // 0x817fdc: r0 = readUint32()
    //     0x817fdc: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x817fe0: add             SP, SP, #8
    // 0x817fe4: ldur            x16, [fp, #-0x10]
    // 0x817fe8: SaveReg r16
    //     0x817fe8: str             x16, [SP, #-8]!
    // 0x817fec: r0 = readUint64()
    //     0x817fec: bl              #0x8178d8  ; [package:archive/src/util/input_stream.dart] InputStream::readUint64
    // 0x817ff0: add             SP, SP, #8
    // 0x817ff4: stur            x0, [fp, #-0x18]
    // 0x817ff8: ldur            x16, [fp, #-0x10]
    // 0x817ffc: SaveReg r16
    //     0x817ffc: str             x16, [SP, #-8]!
    // 0x818000: r0 = readUint32()
    //     0x818000: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x818004: add             SP, SP, #8
    // 0x818008: ldr             x0, [fp, #0x10]
    // 0x81800c: LoadField: r1 = r0->field_13
    //     0x81800c: ldur            x1, [x0, #0x13]
    // 0x818010: ldur            x2, [fp, #-0x18]
    // 0x818014: add             x3, x1, x2
    // 0x818018: StoreField: r0->field_b = r3
    //     0x818018: stur            x3, [x0, #0xb]
    // 0x81801c: SaveReg r0
    //     0x81801c: str             x0, [SP, #-8]!
    // 0x818020: r0 = readUint32()
    //     0x818020: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x818024: add             SP, SP, #8
    // 0x818028: r17 = 101075792
    //     0x818028: mov             x17, #0x4b50
    //     0x81802c: movk            x17, #0x606, lsl #16
    // 0x818030: cmp             x0, x17
    // 0x818034: b.eq            #0x81805c
    // 0x818038: ldr             x0, [fp, #0x10]
    // 0x81803c: ldur            x1, [fp, #-8]
    // 0x818040: LoadField: r2 = r0->field_13
    //     0x818040: ldur            x2, [x0, #0x13]
    // 0x818044: add             x3, x2, x1
    // 0x818048: StoreField: r0->field_b = r3
    //     0x818048: stur            x3, [x0, #0xb]
    // 0x81804c: r0 = Null
    //     0x81804c: mov             x0, NULL
    // 0x818050: LeaveFrame
    //     0x818050: mov             SP, fp
    //     0x818054: ldp             fp, lr, [SP], #0x10
    // 0x818058: ret
    //     0x818058: ret             
    // 0x81805c: ldr             x2, [fp, #0x18]
    // 0x818060: ldr             x0, [fp, #0x10]
    // 0x818064: ldur            x1, [fp, #-8]
    // 0x818068: SaveReg r0
    //     0x818068: str             x0, [SP, #-8]!
    // 0x81806c: r0 = readUint64()
    //     0x81806c: bl              #0x8178d8  ; [package:archive/src/util/input_stream.dart] InputStream::readUint64
    // 0x818070: add             SP, SP, #8
    // 0x818074: ldr             x16, [fp, #0x10]
    // 0x818078: SaveReg r16
    //     0x818078: str             x16, [SP, #-8]!
    // 0x81807c: r0 = readUint16()
    //     0x81807c: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x818080: add             SP, SP, #8
    // 0x818084: ldr             x16, [fp, #0x10]
    // 0x818088: SaveReg r16
    //     0x818088: str             x16, [SP, #-8]!
    // 0x81808c: r0 = readUint16()
    //     0x81808c: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x818090: add             SP, SP, #8
    // 0x818094: ldr             x16, [fp, #0x10]
    // 0x818098: SaveReg r16
    //     0x818098: str             x16, [SP, #-8]!
    // 0x81809c: r0 = readUint32()
    //     0x81809c: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x8180a0: add             SP, SP, #8
    // 0x8180a4: ldr             x16, [fp, #0x10]
    // 0x8180a8: SaveReg r16
    //     0x8180a8: str             x16, [SP, #-8]!
    // 0x8180ac: r0 = readUint32()
    //     0x8180ac: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x8180b0: add             SP, SP, #8
    // 0x8180b4: ldr             x16, [fp, #0x10]
    // 0x8180b8: SaveReg r16
    //     0x8180b8: str             x16, [SP, #-8]!
    // 0x8180bc: r0 = readUint64()
    //     0x8180bc: bl              #0x8178d8  ; [package:archive/src/util/input_stream.dart] InputStream::readUint64
    // 0x8180c0: add             SP, SP, #8
    // 0x8180c4: ldr             x16, [fp, #0x10]
    // 0x8180c8: SaveReg r16
    //     0x8180c8: str             x16, [SP, #-8]!
    // 0x8180cc: r0 = readUint64()
    //     0x8180cc: bl              #0x8178d8  ; [package:archive/src/util/input_stream.dart] InputStream::readUint64
    // 0x8180d0: add             SP, SP, #8
    // 0x8180d4: ldr             x16, [fp, #0x10]
    // 0x8180d8: SaveReg r16
    //     0x8180d8: str             x16, [SP, #-8]!
    // 0x8180dc: r0 = readUint64()
    //     0x8180dc: bl              #0x8178d8  ; [package:archive/src/util/input_stream.dart] InputStream::readUint64
    // 0x8180e0: add             SP, SP, #8
    // 0x8180e4: stur            x0, [fp, #-0x18]
    // 0x8180e8: ldr             x16, [fp, #0x10]
    // 0x8180ec: SaveReg r16
    //     0x8180ec: str             x16, [SP, #-8]!
    // 0x8180f0: r0 = readUint64()
    //     0x8180f0: bl              #0x8178d8  ; [package:archive/src/util/input_stream.dart] InputStream::readUint64
    // 0x8180f4: add             SP, SP, #8
    // 0x8180f8: mov             x3, x0
    // 0x8180fc: ldur            x2, [fp, #-0x18]
    // 0x818100: r0 = BoxInt64Instr(r2)
    //     0x818100: sbfiz           x0, x2, #1, #0x1f
    //     0x818104: cmp             x2, x0, asr #1
    //     0x818108: b.eq            #0x818114
    //     0x81810c: bl              #0xd69bb8
    //     0x818110: stur            x2, [x0, #7]
    // 0x818114: ldr             x2, [fp, #0x18]
    // 0x818118: StoreField: r2->field_f = r0
    //     0x818118: stur            w0, [x2, #0xf]
    //     0x81811c: tbz             w0, #0, #0x818138
    //     0x818120: ldurb           w16, [x2, #-1]
    //     0x818124: ldurb           w17, [x0, #-1]
    //     0x818128: and             x16, x17, x16, lsr #2
    //     0x81812c: tst             x16, HEAP, lsr #32
    //     0x818130: b.eq            #0x818138
    //     0x818134: bl              #0xd6828c
    // 0x818138: r0 = BoxInt64Instr(r3)
    //     0x818138: sbfiz           x0, x3, #1, #0x1f
    //     0x81813c: cmp             x3, x0, asr #1
    //     0x818140: b.eq            #0x81814c
    //     0x818144: bl              #0xd69bb8
    //     0x818148: stur            x3, [x0, #7]
    // 0x81814c: StoreField: r2->field_13 = r0
    //     0x81814c: stur            w0, [x2, #0x13]
    //     0x818150: tbz             w0, #0, #0x81816c
    //     0x818154: ldurb           w16, [x2, #-1]
    //     0x818158: ldurb           w17, [x0, #-1]
    //     0x81815c: and             x16, x17, x16, lsr #2
    //     0x818160: tst             x16, HEAP, lsr #32
    //     0x818164: b.eq            #0x81816c
    //     0x818168: bl              #0xd6828c
    // 0x81816c: ldr             x1, [fp, #0x10]
    // 0x818170: LoadField: r2 = r1->field_13
    //     0x818170: ldur            x2, [x1, #0x13]
    // 0x818174: ldur            x3, [fp, #-8]
    // 0x818178: add             x4, x2, x3
    // 0x81817c: StoreField: r1->field_b = r4
    //     0x81817c: stur            x4, [x1, #0xb]
    // 0x818180: r0 = Null
    //     0x818180: mov             x0, NULL
    // 0x818184: LeaveFrame
    //     0x818184: mov             SP, fp
    //     0x818188: ldp             fp, lr, [SP], #0x10
    // 0x81818c: ret
    //     0x81818c: ret             
    // 0x818190: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x818190: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x818194: b               #0x817f2c
  }
  _ _findSignature(/* No info */) {
    // ** addr: 0x818634, size: 0x114
    // 0x818634: EnterFrame
    //     0x818634: stp             fp, lr, [SP, #-0x10]!
    //     0x818638: mov             fp, SP
    // 0x81863c: AllocStack(0x10)
    //     0x81863c: sub             SP, SP, #0x10
    // 0x818640: CheckStackOverflow
    //     0x818640: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x818644: cmp             SP, x16
    //     0x818648: b.ls            #0x81872c
    // 0x81864c: ldr             x0, [fp, #0x10]
    // 0x818650: LoadField: r1 = r0->field_b
    //     0x818650: ldur            x1, [x0, #0xb]
    // 0x818654: LoadField: r2 = r0->field_13
    //     0x818654: ldur            x2, [x0, #0x13]
    // 0x818658: sub             x3, x1, x2
    // 0x81865c: stur            x3, [fp, #-0x10]
    // 0x818660: LoadField: r1 = r0->field_23
    //     0x818660: ldur            w1, [x0, #0x23]
    // 0x818664: DecompressPointer r1
    //     0x818664: add             x1, x1, HEAP, lsl #32
    // 0x818668: r16 = Sentinel
    //     0x818668: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x81866c: cmp             w1, w16
    // 0x818670: b.eq            #0x818734
    // 0x818674: r2 = LoadInt32Instr(r1)
    //     0x818674: sbfx            x2, x1, #1, #0x1f
    //     0x818678: tbz             w1, #0, #0x818680
    //     0x81867c: ldur            x2, [x1, #7]
    // 0x818680: sub             x1, x2, x3
    // 0x818684: sub             x2, x1, #5
    // 0x818688: mov             x1, x2
    // 0x81868c: stur            x1, [fp, #-8]
    // 0x818690: CheckStackOverflow
    //     0x818690: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x818694: cmp             SP, x16
    //     0x818698: b.ls            #0x818740
    // 0x81869c: tbnz            x1, #0x3f, #0x81870c
    // 0x8186a0: LoadField: r2 = r0->field_13
    //     0x8186a0: ldur            x2, [x0, #0x13]
    // 0x8186a4: add             x4, x2, x1
    // 0x8186a8: StoreField: r0->field_b = r4
    //     0x8186a8: stur            x4, [x0, #0xb]
    // 0x8186ac: SaveReg r0
    //     0x8186ac: str             x0, [SP, #-8]!
    // 0x8186b0: r0 = readUint32()
    //     0x8186b0: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x8186b4: add             SP, SP, #8
    // 0x8186b8: r17 = 101010256
    //     0x8186b8: mov             x17, #0x4b50
    //     0x8186bc: movk            x17, #0x605, lsl #16
    // 0x8186c0: cmp             x0, x17
    // 0x8186c4: b.ne            #0x8186ec
    // 0x8186c8: ldr             x0, [fp, #0x10]
    // 0x8186cc: ldur            x1, [fp, #-0x10]
    // 0x8186d0: LoadField: r2 = r0->field_13
    //     0x8186d0: ldur            x2, [x0, #0x13]
    // 0x8186d4: add             x3, x2, x1
    // 0x8186d8: StoreField: r0->field_b = r3
    //     0x8186d8: stur            x3, [x0, #0xb]
    // 0x8186dc: ldur            x0, [fp, #-8]
    // 0x8186e0: LeaveFrame
    //     0x8186e0: mov             SP, fp
    //     0x8186e4: ldp             fp, lr, [SP], #0x10
    // 0x8186e8: ret
    //     0x8186e8: ret             
    // 0x8186ec: ldr             x0, [fp, #0x10]
    // 0x8186f0: ldur            x2, [fp, #-8]
    // 0x8186f4: ldur            x1, [fp, #-0x10]
    // 0x8186f8: sub             x3, x2, #1
    // 0x8186fc: mov             x16, x1
    // 0x818700: mov             x1, x3
    // 0x818704: mov             x3, x16
    // 0x818708: b               #0x81868c
    // 0x81870c: r0 = ArchiveException()
    //     0x81870c: bl              #0x817830  ; AllocateArchiveExceptionStub -> ArchiveException (size=0x14)
    // 0x818710: mov             x1, x0
    // 0x818714: r0 = "Could not find End of Central Directory Record"
    //     0x818714: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a9c0] "Could not find End of Central Directory Record"
    //     0x818718: ldr             x0, [x0, #0x9c0]
    // 0x81871c: StoreField: r1->field_7 = r0
    //     0x81871c: stur            w0, [x1, #7]
    // 0x818720: mov             x0, x1
    // 0x818724: r0 = Throw()
    //     0x818724: bl              #0xd67e38  ; ThrowStub
    // 0x818728: brk             #0
    // 0x81872c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81872c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x818730: b               #0x81864c
    // 0x818734: r9 = _length
    //     0x818734: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a20] Field <InputStream._length@54080104>: late (offset: 0x24)
    //     0x818738: ldr             x9, [x9, #0xa20]
    // 0x81873c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x81873c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x818740: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x818740: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x818744: b               #0x81869c
  }
}

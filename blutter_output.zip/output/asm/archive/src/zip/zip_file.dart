// lib: , url: package:archive/src/zip/zip_file.dart

// class id: 1048623, size: 0x8
class :: {
}

// class id: 4998, size: 0x18, field offset: 0x8
class AesHeader extends Object {
}

// class id: 5006, size: 0x60, field offset: 0x8
class ZipFile extends FileContent {

  late InputStreamBase _rawContent; // offset: 0x44

  List<int> content(ZipFile) {
    // ** addr: 0x814e94, size: 0x294
    // 0x814e94: EnterFrame
    //     0x814e94: stp             fp, lr, [SP, #-0x10]!
    //     0x814e98: mov             fp, SP
    // 0x814e9c: AllocStack(0x18)
    //     0x814e9c: sub             SP, SP, #0x18
    // 0x814ea0: CheckStackOverflow
    //     0x814ea0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x814ea4: cmp             SP, x16
    //     0x814ea8: b.ls            #0x8150d8
    // 0x814eac: ldr             x0, [fp, #0x10]
    // 0x814eb0: LoadField: r1 = r0->field_47
    //     0x814eb0: ldur            w1, [x0, #0x47]
    // 0x814eb4: DecompressPointer r1
    //     0x814eb4: add             x1, x1, HEAP, lsl #32
    // 0x814eb8: cmp             w1, NULL
    // 0x814ebc: b.ne            #0x8150c8
    // 0x814ec0: LoadField: r1 = r0->field_4b
    //     0x814ec0: ldur            x1, [x0, #0x4b]
    // 0x814ec4: lsl             x2, x1, #1
    // 0x814ec8: cbz             w2, #0x814fe0
    // 0x814ecc: LoadField: r1 = r0->field_43
    //     0x814ecc: ldur            w1, [x0, #0x43]
    // 0x814ed0: DecompressPointer r1
    //     0x814ed0: add             x1, x1, HEAP, lsl #32
    // 0x814ed4: r16 = Sentinel
    //     0x814ed4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x814ed8: cmp             w1, w16
    // 0x814edc: b.eq            #0x8150e0
    // 0x814ee0: LoadField: r3 = r1->field_23
    //     0x814ee0: ldur            w3, [x1, #0x23]
    // 0x814ee4: DecompressPointer r3
    //     0x814ee4: add             x3, x3, HEAP, lsl #32
    // 0x814ee8: r16 = Sentinel
    //     0x814ee8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x814eec: cmp             w3, w16
    // 0x814ef0: b.eq            #0x8150ec
    // 0x814ef4: LoadField: r4 = r1->field_b
    //     0x814ef4: ldur            x4, [x1, #0xb]
    // 0x814ef8: LoadField: r5 = r1->field_13
    //     0x814ef8: ldur            x5, [x1, #0x13]
    // 0x814efc: sub             x6, x4, x5
    // 0x814f00: r4 = LoadInt32Instr(r3)
    //     0x814f00: sbfx            x4, x3, #1, #0x1f
    //     0x814f04: tbz             w3, #0, #0x814f0c
    //     0x814f08: ldur            x4, [x3, #7]
    // 0x814f0c: sub             x3, x4, x6
    // 0x814f10: cmp             x3, #0
    // 0x814f14: b.gt            #0x814f54
    // 0x814f18: SaveReg r1
    //     0x814f18: str             x1, [SP, #-8]!
    // 0x814f1c: r0 = toUint8List()
    //     0x814f1c: bl              #0x7f57d4  ; [package:archive/src/util/input_stream.dart] InputStream::toUint8List
    // 0x814f20: add             SP, SP, #8
    // 0x814f24: ldr             x3, [fp, #0x10]
    // 0x814f28: StoreField: r3->field_47 = r0
    //     0x814f28: stur            w0, [x3, #0x47]
    //     0x814f2c: ldurb           w16, [x3, #-1]
    //     0x814f30: ldurb           w17, [x0, #-1]
    //     0x814f34: and             x16, x17, x16, lsr #2
    //     0x814f38: tst             x16, HEAP, lsr #32
    //     0x814f3c: b.eq            #0x814f44
    //     0x814f40: bl              #0xd682ac
    // 0x814f44: r0 = 0
    //     0x814f44: mov             x0, #0
    // 0x814f48: StoreField: r3->field_4b = r0
    //     0x814f48: stur            x0, [x3, #0x4b]
    // 0x814f4c: mov             x1, x3
    // 0x814f50: b               #0x814fe8
    // 0x814f54: mov             x3, x0
    // 0x814f58: r0 = 0
    //     0x814f58: mov             x0, #0
    // 0x814f5c: cmp             w2, #2
    // 0x814f60: b.ne            #0x814f98
    // 0x814f64: SaveReg r3
    //     0x814f64: str             x3, [SP, #-8]!
    // 0x814f68: r0 = _decodeZipCrypto()
    //     0x814f68: bl              #0x81735c  ; [package:archive/src/zip/zip_file.dart] ZipFile::_decodeZipCrypto
    // 0x814f6c: add             SP, SP, #8
    // 0x814f70: ldr             x3, [fp, #0x10]
    // 0x814f74: StoreField: r3->field_43 = r0
    //     0x814f74: stur            w0, [x3, #0x43]
    //     0x814f78: ldurb           w16, [x3, #-1]
    //     0x814f7c: ldurb           w17, [x0, #-1]
    //     0x814f80: and             x16, x17, x16, lsr #2
    //     0x814f84: tst             x16, HEAP, lsr #32
    //     0x814f88: b.eq            #0x814f90
    //     0x814f8c: bl              #0xd682ac
    // 0x814f90: mov             x1, x3
    // 0x814f94: b               #0x814fd4
    // 0x814f98: cmp             w2, #4
    // 0x814f9c: b.ne            #0x814fd0
    // 0x814fa0: stp             x1, x3, [SP, #-0x10]!
    // 0x814fa4: r0 = _decodeAes()
    //     0x814fa4: bl              #0x817210  ; [package:archive/src/zip/zip_file.dart] ZipFile::_decodeAes
    // 0x814fa8: add             SP, SP, #0x10
    // 0x814fac: ldr             x1, [fp, #0x10]
    // 0x814fb0: StoreField: r1->field_43 = r0
    //     0x814fb0: stur            w0, [x1, #0x43]
    //     0x814fb4: ldurb           w16, [x1, #-1]
    //     0x814fb8: ldurb           w17, [x0, #-1]
    //     0x814fbc: and             x16, x17, x16, lsr #2
    //     0x814fc0: tst             x16, HEAP, lsr #32
    //     0x814fc4: b.eq            #0x814fcc
    //     0x814fc8: bl              #0xd6826c
    // 0x814fcc: b               #0x814fd4
    // 0x814fd0: mov             x1, x3
    // 0x814fd4: r0 = 0
    //     0x814fd4: mov             x0, #0
    // 0x814fd8: StoreField: r1->field_4b = r0
    //     0x814fd8: stur            x0, [x1, #0x4b]
    // 0x814fdc: b               #0x814fe8
    // 0x814fe0: mov             x1, x0
    // 0x814fe4: r0 = 0
    //     0x814fe4: mov             x0, #0
    // 0x814fe8: LoadField: r2 = r1->field_17
    //     0x814fe8: ldur            x2, [x1, #0x17]
    // 0x814fec: cmp             x2, #8
    // 0x814ff0: b.ne            #0x815078
    // 0x814ff4: LoadField: r2 = r1->field_43
    //     0x814ff4: ldur            w2, [x1, #0x43]
    // 0x814ff8: DecompressPointer r2
    //     0x814ff8: add             x2, x2, HEAP, lsl #32
    // 0x814ffc: r16 = Sentinel
    //     0x814ffc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x815000: cmp             w2, w16
    // 0x815004: b.eq            #0x8150f8
    // 0x815008: stur            x2, [fp, #-0x10]
    // 0x81500c: LoadField: r3 = r1->field_33
    //     0x81500c: ldur            w3, [x1, #0x33]
    // 0x815010: DecompressPointer r3
    //     0x815010: add             x3, x3, HEAP, lsl #32
    // 0x815014: stur            x3, [fp, #-8]
    // 0x815018: r0 = Inflate()
    //     0x815018: bl              #0x817204  ; AllocateInflateStub -> Inflate (size=0x2c)
    // 0x81501c: stur            x0, [fp, #-0x18]
    // 0x815020: ldur            x16, [fp, #-0x10]
    // 0x815024: stp             x16, x0, [SP, #-0x10]!
    // 0x815028: ldur            x16, [fp, #-8]
    // 0x81502c: SaveReg r16
    //     0x81502c: str             x16, [SP, #-8]!
    // 0x815030: r0 = Inflate.buffer()
    //     0x815030: bl              #0x8151e4  ; [package:archive/src/zlib/inflate.dart] Inflate::Inflate.buffer
    // 0x815034: add             SP, SP, #0x18
    // 0x815038: ldur            x16, [fp, #-0x18]
    // 0x81503c: SaveReg r16
    //     0x81503c: str             x16, [SP, #-8]!
    // 0x815040: r0 = getBytes()
    //     0x815040: bl              #0x815110  ; [package:archive/src/zlib/inflate.dart] Inflate::getBytes
    // 0x815044: add             SP, SP, #8
    // 0x815048: mov             x2, x0
    // 0x81504c: ldr             x1, [fp, #0x10]
    // 0x815050: StoreField: r1->field_47 = r0
    //     0x815050: stur            w0, [x1, #0x47]
    //     0x815054: ldurb           w16, [x1, #-1]
    //     0x815058: ldurb           w17, [x0, #-1]
    //     0x81505c: and             x16, x17, x16, lsr #2
    //     0x815060: tst             x16, HEAP, lsr #32
    //     0x815064: b.eq            #0x81506c
    //     0x815068: bl              #0xd6826c
    // 0x81506c: r0 = 0
    //     0x81506c: mov             x0, #0
    // 0x815070: StoreField: r1->field_17 = r0
    //     0x815070: stur            x0, [x1, #0x17]
    // 0x815074: b               #0x8150c0
    // 0x815078: LoadField: r0 = r1->field_43
    //     0x815078: ldur            w0, [x1, #0x43]
    // 0x81507c: DecompressPointer r0
    //     0x81507c: add             x0, x0, HEAP, lsl #32
    // 0x815080: r16 = Sentinel
    //     0x815080: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x815084: cmp             w0, w16
    // 0x815088: b.eq            #0x815104
    // 0x81508c: SaveReg r0
    //     0x81508c: str             x0, [SP, #-8]!
    // 0x815090: r0 = toUint8List()
    //     0x815090: bl              #0x7f57d4  ; [package:archive/src/util/input_stream.dart] InputStream::toUint8List
    // 0x815094: add             SP, SP, #8
    // 0x815098: mov             x1, x0
    // 0x81509c: ldr             x2, [fp, #0x10]
    // 0x8150a0: StoreField: r2->field_47 = r0
    //     0x8150a0: stur            w0, [x2, #0x47]
    //     0x8150a4: ldurb           w16, [x2, #-1]
    //     0x8150a8: ldurb           w17, [x0, #-1]
    //     0x8150ac: and             x16, x17, x16, lsr #2
    //     0x8150b0: tst             x16, HEAP, lsr #32
    //     0x8150b4: b.eq            #0x8150bc
    //     0x8150b8: bl              #0xd6828c
    // 0x8150bc: mov             x2, x1
    // 0x8150c0: mov             x0, x2
    // 0x8150c4: b               #0x8150cc
    // 0x8150c8: mov             x0, x1
    // 0x8150cc: LeaveFrame
    //     0x8150cc: mov             SP, fp
    //     0x8150d0: ldp             fp, lr, [SP], #0x10
    // 0x8150d4: ret
    //     0x8150d4: ret             
    // 0x8150d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8150d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8150dc: b               #0x814eac
    // 0x8150e0: r9 = _rawContent
    //     0x8150e0: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4cc10] Field <ZipFile._rawContent@59286345>: late (offset: 0x44)
    //     0x8150e4: ldr             x9, [x9, #0xc10]
    // 0x8150e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8150e8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8150ec: r9 = _length
    //     0x8150ec: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a20] Field <InputStream._length@54080104>: late (offset: 0x24)
    //     0x8150f0: ldr             x9, [x9, #0xa20]
    // 0x8150f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8150f4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8150f8: r9 = _rawContent
    //     0x8150f8: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4cc10] Field <ZipFile._rawContent@59286345>: late (offset: 0x44)
    //     0x8150fc: ldr             x9, [x9, #0xc10]
    // 0x815100: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x815100: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x815104: r9 = _rawContent
    //     0x815104: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4cc10] Field <ZipFile._rawContent@59286345>: late (offset: 0x44)
    //     0x815108: ldr             x9, [x9, #0xc10]
    // 0x81510c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x81510c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ ZipFile(/* No info */) {
    // ** addr: 0x814878, size: 0x604
    // 0x814878: EnterFrame
    //     0x814878: stp             fp, lr, [SP, #-0x10]!
    //     0x81487c: mov             fp, SP
    // 0x814880: AllocStack(0x20)
    //     0x814880: sub             SP, SP, #0x20
    // 0x814884: r3 = ""
    //     0x814884: ldr             x3, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x814888: r2 = Sentinel
    //     0x814888: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x81488c: r1 = 67324752
    //     0x81488c: mov             x1, #0x4b50
    //     0x814890: movk            x1, #0x403, lsl #16
    // 0x814894: r0 = 0
    //     0x814894: mov             x0, #0
    // 0x814898: CheckStackOverflow
    //     0x814898: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81489c: cmp             SP, x16
    //     0x8148a0: b.ls            #0x814e70
    // 0x8148a4: ldr             x4, [fp, #0x20]
    // 0x8148a8: StoreField: r4->field_7 = r1
    //     0x8148a8: stur            x1, [x4, #7]
    // 0x8148ac: StoreField: r4->field_f = r0
    //     0x8148ac: stur            x0, [x4, #0xf]
    // 0x8148b0: StoreField: r4->field_17 = r0
    //     0x8148b0: stur            x0, [x4, #0x17]
    // 0x8148b4: StoreField: r4->field_1f = r0
    //     0x8148b4: stur            x0, [x4, #0x1f]
    // 0x8148b8: StoreField: r4->field_27 = r0
    //     0x8148b8: stur            x0, [x4, #0x27]
    // 0x8148bc: StoreField: r4->field_37 = r3
    //     0x8148bc: stur            w3, [x4, #0x37]
    // 0x8148c0: StoreField: r4->field_43 = r2
    //     0x8148c0: stur            w2, [x4, #0x43]
    // 0x8148c4: StoreField: r4->field_4b = r0
    //     0x8148c4: stur            x0, [x4, #0x4b]
    // 0x8148c8: r16 = <int>
    //     0x8148c8: ldr             x16, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0x8148cc: stp             xzr, x16, [SP, #-0x10]!
    // 0x8148d0: r0 = _GrowableList()
    //     0x8148d0: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x8148d4: add             SP, SP, #0x10
    // 0x8148d8: ldr             x3, [fp, #0x20]
    // 0x8148dc: StoreField: r3->field_3b = r0
    //     0x8148dc: stur            w0, [x3, #0x3b]
    //     0x8148e0: ldurb           w16, [x3, #-1]
    //     0x8148e4: ldurb           w17, [x0, #-1]
    //     0x8148e8: and             x16, x17, x16, lsr #2
    //     0x8148ec: tst             x16, HEAP, lsr #32
    //     0x8148f0: b.eq            #0x8148f8
    //     0x8148f4: bl              #0xd682ac
    // 0x8148f8: r1 = Null
    //     0x8148f8: mov             x1, NULL
    // 0x8148fc: r2 = 6
    //     0x8148fc: mov             x2, #6
    // 0x814900: r0 = AllocateArray()
    //     0x814900: bl              #0xd6987c  ; AllocateArrayStub
    // 0x814904: stur            x0, [fp, #-8]
    // 0x814908: StoreField: r0->field_f = rZR
    //     0x814908: stur            wzr, [x0, #0xf]
    // 0x81490c: StoreField: r0->field_13 = rZR
    //     0x81490c: stur            wzr, [x0, #0x13]
    // 0x814910: StoreField: r0->field_17 = rZR
    //     0x814910: stur            wzr, [x0, #0x17]
    // 0x814914: r1 = <int>
    //     0x814914: ldr             x1, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0x814918: r0 = AllocateGrowableArray()
    //     0x814918: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x81491c: mov             x1, x0
    // 0x814920: ldur            x0, [fp, #-8]
    // 0x814924: StoreField: r1->field_f = r0
    //     0x814924: stur            w0, [x1, #0xf]
    // 0x814928: r0 = 6
    //     0x814928: mov             x0, #6
    // 0x81492c: StoreField: r1->field_b = r0
    //     0x81492c: stur            w0, [x1, #0xb]
    // 0x814930: mov             x0, x1
    // 0x814934: ldr             x1, [fp, #0x20]
    // 0x814938: StoreField: r1->field_5b = r0
    //     0x814938: stur            w0, [x1, #0x5b]
    //     0x81493c: ldurb           w16, [x1, #-1]
    //     0x814940: ldurb           w17, [x0, #-1]
    //     0x814944: and             x16, x17, x16, lsr #2
    //     0x814948: tst             x16, HEAP, lsr #32
    //     0x81494c: b.eq            #0x814954
    //     0x814950: bl              #0xd6826c
    // 0x814954: ldr             x0, [fp, #0x10]
    // 0x814958: StoreField: r1->field_3f = r0
    //     0x814958: stur            w0, [x1, #0x3f]
    //     0x81495c: ldurb           w16, [x1, #-1]
    //     0x814960: ldurb           w17, [x0, #-1]
    //     0x814964: and             x16, x17, x16, lsr #2
    //     0x814968: tst             x16, HEAP, lsr #32
    //     0x81496c: b.eq            #0x814974
    //     0x814970: bl              #0xd6826c
    // 0x814974: ldr             x16, [fp, #0x18]
    // 0x814978: SaveReg r16
    //     0x814978: str             x16, [SP, #-8]!
    // 0x81497c: r0 = readUint32()
    //     0x81497c: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x814980: add             SP, SP, #8
    // 0x814984: mov             x1, x0
    // 0x814988: ldr             x0, [fp, #0x20]
    // 0x81498c: StoreField: r0->field_7 = r1
    //     0x81498c: stur            x1, [x0, #7]
    // 0x814990: r17 = 67324752
    //     0x814990: mov             x17, #0x4b50
    //     0x814994: movk            x17, #0x403, lsl #16
    // 0x814998: cmp             x1, x17
    // 0x81499c: b.ne            #0x814e50
    // 0x8149a0: ldr             x16, [fp, #0x18]
    // 0x8149a4: SaveReg r16
    //     0x8149a4: str             x16, [SP, #-8]!
    // 0x8149a8: r0 = readUint16()
    //     0x8149a8: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x8149ac: add             SP, SP, #8
    // 0x8149b0: ldr             x16, [fp, #0x18]
    // 0x8149b4: SaveReg r16
    //     0x8149b4: str             x16, [SP, #-8]!
    // 0x8149b8: r0 = readUint16()
    //     0x8149b8: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x8149bc: add             SP, SP, #8
    // 0x8149c0: mov             x1, x0
    // 0x8149c4: ldr             x0, [fp, #0x20]
    // 0x8149c8: StoreField: r0->field_f = r1
    //     0x8149c8: stur            x1, [x0, #0xf]
    // 0x8149cc: ldr             x16, [fp, #0x18]
    // 0x8149d0: SaveReg r16
    //     0x8149d0: str             x16, [SP, #-8]!
    // 0x8149d4: r0 = readUint16()
    //     0x8149d4: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x8149d8: add             SP, SP, #8
    // 0x8149dc: mov             x1, x0
    // 0x8149e0: ldr             x0, [fp, #0x20]
    // 0x8149e4: StoreField: r0->field_17 = r1
    //     0x8149e4: stur            x1, [x0, #0x17]
    // 0x8149e8: ldr             x16, [fp, #0x18]
    // 0x8149ec: SaveReg r16
    //     0x8149ec: str             x16, [SP, #-8]!
    // 0x8149f0: r0 = readUint16()
    //     0x8149f0: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x8149f4: add             SP, SP, #8
    // 0x8149f8: mov             x1, x0
    // 0x8149fc: ldr             x0, [fp, #0x20]
    // 0x814a00: StoreField: r0->field_1f = r1
    //     0x814a00: stur            x1, [x0, #0x1f]
    // 0x814a04: ldr             x16, [fp, #0x18]
    // 0x814a08: SaveReg r16
    //     0x814a08: str             x16, [SP, #-8]!
    // 0x814a0c: r0 = readUint16()
    //     0x814a0c: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x814a10: add             SP, SP, #8
    // 0x814a14: mov             x1, x0
    // 0x814a18: ldr             x0, [fp, #0x20]
    // 0x814a1c: StoreField: r0->field_27 = r1
    //     0x814a1c: stur            x1, [x0, #0x27]
    // 0x814a20: ldr             x16, [fp, #0x18]
    // 0x814a24: SaveReg r16
    //     0x814a24: str             x16, [SP, #-8]!
    // 0x814a28: r0 = readUint32()
    //     0x814a28: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x814a2c: add             SP, SP, #8
    // 0x814a30: mov             x2, x0
    // 0x814a34: r0 = BoxInt64Instr(r2)
    //     0x814a34: sbfiz           x0, x2, #1, #0x1f
    //     0x814a38: cmp             x2, x0, asr #1
    //     0x814a3c: b.eq            #0x814a48
    //     0x814a40: bl              #0xd69bb8
    //     0x814a44: stur            x2, [x0, #7]
    // 0x814a48: ldr             x1, [fp, #0x20]
    // 0x814a4c: StoreField: r1->field_2f = r0
    //     0x814a4c: stur            w0, [x1, #0x2f]
    //     0x814a50: tbz             w0, #0, #0x814a6c
    //     0x814a54: ldurb           w16, [x1, #-1]
    //     0x814a58: ldurb           w17, [x0, #-1]
    //     0x814a5c: and             x16, x17, x16, lsr #2
    //     0x814a60: tst             x16, HEAP, lsr #32
    //     0x814a64: b.eq            #0x814a6c
    //     0x814a68: bl              #0xd6826c
    // 0x814a6c: ldr             x16, [fp, #0x18]
    // 0x814a70: SaveReg r16
    //     0x814a70: str             x16, [SP, #-8]!
    // 0x814a74: r0 = readUint32()
    //     0x814a74: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x814a78: add             SP, SP, #8
    // 0x814a7c: ldr             x16, [fp, #0x18]
    // 0x814a80: SaveReg r16
    //     0x814a80: str             x16, [SP, #-8]!
    // 0x814a84: r0 = readUint32()
    //     0x814a84: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x814a88: add             SP, SP, #8
    // 0x814a8c: mov             x2, x0
    // 0x814a90: r0 = BoxInt64Instr(r2)
    //     0x814a90: sbfiz           x0, x2, #1, #0x1f
    //     0x814a94: cmp             x2, x0, asr #1
    //     0x814a98: b.eq            #0x814aa4
    //     0x814a9c: bl              #0xd69bb8
    //     0x814aa0: stur            x2, [x0, #7]
    // 0x814aa4: ldr             x1, [fp, #0x20]
    // 0x814aa8: StoreField: r1->field_33 = r0
    //     0x814aa8: stur            w0, [x1, #0x33]
    //     0x814aac: tbz             w0, #0, #0x814ac8
    //     0x814ab0: ldurb           w16, [x1, #-1]
    //     0x814ab4: ldurb           w17, [x0, #-1]
    //     0x814ab8: and             x16, x17, x16, lsr #2
    //     0x814abc: tst             x16, HEAP, lsr #32
    //     0x814ac0: b.eq            #0x814ac8
    //     0x814ac4: bl              #0xd6826c
    // 0x814ac8: ldr             x16, [fp, #0x18]
    // 0x814acc: SaveReg r16
    //     0x814acc: str             x16, [SP, #-8]!
    // 0x814ad0: r0 = readUint16()
    //     0x814ad0: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x814ad4: add             SP, SP, #8
    // 0x814ad8: stur            x0, [fp, #-0x10]
    // 0x814adc: ldr             x16, [fp, #0x18]
    // 0x814ae0: SaveReg r16
    //     0x814ae0: str             x16, [SP, #-8]!
    // 0x814ae4: r0 = readUint16()
    //     0x814ae4: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x814ae8: add             SP, SP, #8
    // 0x814aec: stur            x0, [fp, #-0x18]
    // 0x814af0: ldr             x16, [fp, #0x18]
    // 0x814af4: SaveReg r16
    //     0x814af4: str             x16, [SP, #-8]!
    // 0x814af8: ldur            x1, [fp, #-0x10]
    // 0x814afc: SaveReg r1
    //     0x814afc: str             x1, [SP, #-8]!
    // 0x814b00: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x814b00: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x814b04: r0 = readString()
    //     0x814b04: bl              #0x818198  ; [package:archive/src/util/input_stream.dart] InputStream::readString
    // 0x814b08: add             SP, SP, #0x10
    // 0x814b0c: ldr             x1, [fp, #0x20]
    // 0x814b10: StoreField: r1->field_37 = r0
    //     0x814b10: stur            w0, [x1, #0x37]
    //     0x814b14: ldurb           w16, [x1, #-1]
    //     0x814b18: ldurb           w17, [x0, #-1]
    //     0x814b1c: and             x16, x17, x16, lsr #2
    //     0x814b20: tst             x16, HEAP, lsr #32
    //     0x814b24: b.eq            #0x814b2c
    //     0x814b28: bl              #0xd6826c
    // 0x814b2c: ldr             x16, [fp, #0x18]
    // 0x814b30: SaveReg r16
    //     0x814b30: str             x16, [SP, #-8]!
    // 0x814b34: ldur            x0, [fp, #-0x18]
    // 0x814b38: SaveReg r0
    //     0x814b38: str             x0, [SP, #-8]!
    // 0x814b3c: r0 = readBytes()
    //     0x814b3c: bl              #0x817d54  ; [package:archive/src/util/input_stream.dart] InputStream::readBytes
    // 0x814b40: add             SP, SP, #0x10
    // 0x814b44: SaveReg r0
    //     0x814b44: str             x0, [SP, #-8]!
    // 0x814b48: r0 = toUint8List()
    //     0x814b48: bl              #0x7f57d4  ; [package:archive/src/util/input_stream.dart] InputStream::toUint8List
    // 0x814b4c: add             SP, SP, #8
    // 0x814b50: ldr             x1, [fp, #0x20]
    // 0x814b54: StoreField: r1->field_3b = r0
    //     0x814b54: stur            w0, [x1, #0x3b]
    //     0x814b58: ldurb           w16, [x1, #-1]
    //     0x814b5c: ldurb           w17, [x0, #-1]
    //     0x814b60: and             x16, x17, x16, lsr #2
    //     0x814b64: tst             x16, HEAP, lsr #32
    //     0x814b68: b.eq            #0x814b70
    //     0x814b6c: bl              #0xd6826c
    // 0x814b70: LoadField: r0 = r1->field_f
    //     0x814b70: ldur            x0, [x1, #0xf]
    // 0x814b74: ubfx            x0, x0, #0, #0x20
    // 0x814b78: r2 = 1
    //     0x814b78: mov             x2, #1
    // 0x814b7c: and             x3, x0, x2
    // 0x814b80: ubfx            x3, x3, #0, #0x20
    // 0x814b84: cbz             x3, #0x814b90
    // 0x814b88: r0 = false
    //     0x814b88: add             x0, NULL, #0x30  ; false
    // 0x814b8c: b               #0x814b94
    // 0x814b90: r0 = true
    //     0x814b90: add             x0, NULL, #0x20  ; true
    // 0x814b94: tst             x0, #0x10
    // 0x814b98: cset            x2, ne
    // 0x814b9c: lsl             x2, x2, #1
    // 0x814ba0: r0 = LoadInt32Instr(r2)
    //     0x814ba0: sbfx            x0, x2, #1, #0x1f
    // 0x814ba4: StoreField: r1->field_4b = r0
    //     0x814ba4: stur            x0, [x1, #0x4b]
    // 0x814ba8: StoreField: r1->field_57 = rNULL
    //     0x814ba8: stur            NULL, [x1, #0x57]
    // 0x814bac: LoadField: r0 = r1->field_3f
    //     0x814bac: ldur            w0, [x1, #0x3f]
    // 0x814bb0: DecompressPointer r0
    //     0x814bb0: add             x0, x0, HEAP, lsl #32
    // 0x814bb4: LoadField: r2 = r0->field_f
    //     0x814bb4: ldur            w2, [x0, #0xf]
    // 0x814bb8: DecompressPointer r2
    //     0x814bb8: add             x2, x2, HEAP, lsl #32
    // 0x814bbc: cmp             w2, NULL
    // 0x814bc0: b.eq            #0x814e78
    // 0x814bc4: r0 = LoadInt32Instr(r2)
    //     0x814bc4: sbfx            x0, x2, #1, #0x1f
    //     0x814bc8: tbz             w2, #0, #0x814bd0
    //     0x814bcc: ldur            x0, [x2, #7]
    // 0x814bd0: ldr             x16, [fp, #0x18]
    // 0x814bd4: stp             x0, x16, [SP, #-0x10]!
    // 0x814bd8: r0 = readBytes()
    //     0x814bd8: bl              #0x817d54  ; [package:archive/src/util/input_stream.dart] InputStream::readBytes
    // 0x814bdc: add             SP, SP, #0x10
    // 0x814be0: ldr             x1, [fp, #0x20]
    // 0x814be4: StoreField: r1->field_43 = r0
    //     0x814be4: stur            w0, [x1, #0x43]
    //     0x814be8: ldurb           w16, [x1, #-1]
    //     0x814bec: ldurb           w17, [x0, #-1]
    //     0x814bf0: and             x16, x17, x16, lsr #2
    //     0x814bf4: tst             x16, HEAP, lsr #32
    //     0x814bf8: b.eq            #0x814c00
    //     0x814bfc: bl              #0xd6826c
    // 0x814c00: LoadField: r0 = r1->field_4b
    //     0x814c00: ldur            x0, [x1, #0x4b]
    // 0x814c04: lsl             x2, x0, #1
    // 0x814c08: cbz             w2, #0x814d1c
    // 0x814c0c: ldur            x0, [fp, #-0x18]
    // 0x814c10: cmp             x0, #2
    // 0x814c14: b.le            #0x814d1c
    // 0x814c18: LoadField: r0 = r1->field_3b
    //     0x814c18: ldur            w0, [x1, #0x3b]
    // 0x814c1c: DecompressPointer r0
    //     0x814c1c: add             x0, x0, HEAP, lsl #32
    // 0x814c20: stur            x0, [fp, #-8]
    // 0x814c24: r0 = InputStream()
    //     0x814c24: bl              #0x818b18  ; AllocateInputStreamStub -> InputStream (size=0x28)
    // 0x814c28: stur            x0, [fp, #-0x20]
    // 0x814c2c: ldur            x16, [fp, #-8]
    // 0x814c30: stp             x16, x0, [SP, #-0x10]!
    // 0x814c34: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x814c34: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x814c38: r0 = InputStream()
    //     0x814c38: bl              #0x818754  ; [package:archive/src/util/input_stream.dart] InputStream::InputStream
    // 0x814c3c: add             SP, SP, #0x10
    // 0x814c40: ldur            x16, [fp, #-0x20]
    // 0x814c44: SaveReg r16
    //     0x814c44: str             x16, [SP, #-8]!
    // 0x814c48: r0 = readUint16()
    //     0x814c48: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x814c4c: add             SP, SP, #8
    // 0x814c50: r17 = 39169
    //     0x814c50: mov             x17, #0x9901
    // 0x814c54: cmp             x0, x17
    // 0x814c58: b.ne            #0x814d18
    // 0x814c5c: ldr             x0, [fp, #0x20]
    // 0x814c60: ldur            x16, [fp, #-0x20]
    // 0x814c64: SaveReg r16
    //     0x814c64: str             x16, [SP, #-8]!
    // 0x814c68: r0 = readUint16()
    //     0x814c68: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x814c6c: add             SP, SP, #8
    // 0x814c70: ldur            x16, [fp, #-0x20]
    // 0x814c74: SaveReg r16
    //     0x814c74: str             x16, [SP, #-8]!
    // 0x814c78: r0 = readUint16()
    //     0x814c78: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x814c7c: add             SP, SP, #8
    // 0x814c80: ldur            x16, [fp, #-0x20]
    // 0x814c84: SaveReg r16
    //     0x814c84: str             x16, [SP, #-8]!
    // 0x814c88: r0 = 2
    //     0x814c88: mov             x0, #2
    // 0x814c8c: SaveReg r0
    //     0x814c8c: str             x0, [SP, #-8]!
    // 0x814c90: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x814c90: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x814c94: r0 = readString()
    //     0x814c94: bl              #0x818198  ; [package:archive/src/util/input_stream.dart] InputStream::readString
    // 0x814c98: add             SP, SP, #0x10
    // 0x814c9c: ldur            x16, [fp, #-0x20]
    // 0x814ca0: SaveReg r16
    //     0x814ca0: str             x16, [SP, #-8]!
    // 0x814ca4: r0 = readByte()
    //     0x814ca4: bl              #0x817848  ; [package:archive/src/util/input_stream.dart] InputStream::readByte
    // 0x814ca8: add             SP, SP, #8
    // 0x814cac: stur            x0, [fp, #-0x10]
    // 0x814cb0: ldur            x16, [fp, #-0x20]
    // 0x814cb4: SaveReg r16
    //     0x814cb4: str             x16, [SP, #-8]!
    // 0x814cb8: r0 = readUint16()
    //     0x814cb8: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x814cbc: add             SP, SP, #8
    // 0x814cc0: mov             x2, x0
    // 0x814cc4: ldr             x1, [fp, #0x20]
    // 0x814cc8: r0 = 2
    //     0x814cc8: mov             x0, #2
    // 0x814ccc: stur            x2, [fp, #-0x18]
    // 0x814cd0: StoreField: r1->field_4b = r0
    //     0x814cd0: stur            x0, [x1, #0x4b]
    // 0x814cd4: r0 = AesHeader()
    //     0x814cd4: bl              #0x81783c  ; AllocateAesHeaderStub -> AesHeader (size=0x18)
    // 0x814cd8: mov             x1, x0
    // 0x814cdc: ldur            x0, [fp, #-0x10]
    // 0x814ce0: StoreField: r1->field_7 = r0
    //     0x814ce0: stur            x0, [x1, #7]
    // 0x814ce4: ldur            x2, [fp, #-0x18]
    // 0x814ce8: StoreField: r1->field_f = r2
    //     0x814ce8: stur            x2, [x1, #0xf]
    // 0x814cec: mov             x0, x1
    // 0x814cf0: ldr             x1, [fp, #0x20]
    // 0x814cf4: StoreField: r1->field_53 = r0
    //     0x814cf4: stur            w0, [x1, #0x53]
    //     0x814cf8: ldurb           w16, [x1, #-1]
    //     0x814cfc: ldurb           w17, [x0, #-1]
    //     0x814d00: and             x16, x17, x16, lsr #2
    //     0x814d04: tst             x16, HEAP, lsr #32
    //     0x814d08: b.eq            #0x814d10
    //     0x814d0c: bl              #0xd6826c
    // 0x814d10: StoreField: r1->field_17 = r2
    //     0x814d10: stur            x2, [x1, #0x17]
    // 0x814d14: b               #0x814d1c
    // 0x814d18: ldr             x1, [fp, #0x20]
    // 0x814d1c: r0 = 8
    //     0x814d1c: mov             x0, #8
    // 0x814d20: LoadField: r2 = r1->field_f
    //     0x814d20: ldur            x2, [x1, #0xf]
    // 0x814d24: ubfx            x2, x2, #0, #0x20
    // 0x814d28: and             x3, x2, x0
    // 0x814d2c: ubfx            x3, x3, #0, #0x20
    // 0x814d30: cbz             x3, #0x814e40
    // 0x814d34: ldr             x16, [fp, #0x18]
    // 0x814d38: SaveReg r16
    //     0x814d38: str             x16, [SP, #-8]!
    // 0x814d3c: r0 = readUint32()
    //     0x814d3c: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x814d40: add             SP, SP, #8
    // 0x814d44: mov             x2, x0
    // 0x814d48: r17 = 134695760
    //     0x814d48: mov             x17, #0x4b50
    //     0x814d4c: movk            x17, #0x807, lsl #16
    // 0x814d50: cmp             x2, x17
    // 0x814d54: b.ne            #0x814dac
    // 0x814d58: ldr             x0, [fp, #0x20]
    // 0x814d5c: ldr             x16, [fp, #0x18]
    // 0x814d60: SaveReg r16
    //     0x814d60: str             x16, [SP, #-8]!
    // 0x814d64: r0 = readUint32()
    //     0x814d64: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x814d68: add             SP, SP, #8
    // 0x814d6c: mov             x2, x0
    // 0x814d70: r0 = BoxInt64Instr(r2)
    //     0x814d70: sbfiz           x0, x2, #1, #0x1f
    //     0x814d74: cmp             x2, x0, asr #1
    //     0x814d78: b.eq            #0x814d84
    //     0x814d7c: bl              #0xd69bb8
    //     0x814d80: stur            x2, [x0, #7]
    // 0x814d84: ldr             x3, [fp, #0x20]
    // 0x814d88: StoreField: r3->field_2f = r0
    //     0x814d88: stur            w0, [x3, #0x2f]
    //     0x814d8c: tbz             w0, #0, #0x814da8
    //     0x814d90: ldurb           w16, [x3, #-1]
    //     0x814d94: ldurb           w17, [x0, #-1]
    //     0x814d98: and             x16, x17, x16, lsr #2
    //     0x814d9c: tst             x16, HEAP, lsr #32
    //     0x814da0: b.eq            #0x814da8
    //     0x814da4: bl              #0xd682ac
    // 0x814da8: b               #0x814de4
    // 0x814dac: ldr             x3, [fp, #0x20]
    // 0x814db0: r0 = BoxInt64Instr(r2)
    //     0x814db0: sbfiz           x0, x2, #1, #0x1f
    //     0x814db4: cmp             x2, x0, asr #1
    //     0x814db8: b.eq            #0x814dc4
    //     0x814dbc: bl              #0xd69bb8
    //     0x814dc0: stur            x2, [x0, #7]
    // 0x814dc4: StoreField: r3->field_2f = r0
    //     0x814dc4: stur            w0, [x3, #0x2f]
    //     0x814dc8: tbz             w0, #0, #0x814de4
    //     0x814dcc: ldurb           w16, [x3, #-1]
    //     0x814dd0: ldurb           w17, [x0, #-1]
    //     0x814dd4: and             x16, x17, x16, lsr #2
    //     0x814dd8: tst             x16, HEAP, lsr #32
    //     0x814ddc: b.eq            #0x814de4
    //     0x814de0: bl              #0xd682ac
    // 0x814de4: ldr             x16, [fp, #0x18]
    // 0x814de8: SaveReg r16
    //     0x814de8: str             x16, [SP, #-8]!
    // 0x814dec: r0 = readUint32()
    //     0x814dec: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x814df0: add             SP, SP, #8
    // 0x814df4: ldr             x16, [fp, #0x18]
    // 0x814df8: SaveReg r16
    //     0x814df8: str             x16, [SP, #-8]!
    // 0x814dfc: r0 = readUint32()
    //     0x814dfc: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x814e00: add             SP, SP, #8
    // 0x814e04: mov             x2, x0
    // 0x814e08: r0 = BoxInt64Instr(r2)
    //     0x814e08: sbfiz           x0, x2, #1, #0x1f
    //     0x814e0c: cmp             x2, x0, asr #1
    //     0x814e10: b.eq            #0x814e1c
    //     0x814e14: bl              #0xd69bb8
    //     0x814e18: stur            x2, [x0, #7]
    // 0x814e1c: ldr             x1, [fp, #0x20]
    // 0x814e20: StoreField: r1->field_33 = r0
    //     0x814e20: stur            w0, [x1, #0x33]
    //     0x814e24: tbz             w0, #0, #0x814e40
    //     0x814e28: ldurb           w16, [x1, #-1]
    //     0x814e2c: ldurb           w17, [x0, #-1]
    //     0x814e30: and             x16, x17, x16, lsr #2
    //     0x814e34: tst             x16, HEAP, lsr #32
    //     0x814e38: b.eq            #0x814e40
    //     0x814e3c: bl              #0xd6826c
    // 0x814e40: r0 = Null
    //     0x814e40: mov             x0, NULL
    // 0x814e44: LeaveFrame
    //     0x814e44: mov             SP, fp
    //     0x814e48: ldp             fp, lr, [SP], #0x10
    // 0x814e4c: ret
    //     0x814e4c: ret             
    // 0x814e50: r0 = ArchiveException()
    //     0x814e50: bl              #0x817830  ; AllocateArchiveExceptionStub -> ArchiveException (size=0x14)
    // 0x814e54: mov             x1, x0
    // 0x814e58: r0 = "Invalid Zip Signature"
    //     0x814e58: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a9b0] "Invalid Zip Signature"
    //     0x814e5c: ldr             x0, [x0, #0x9b0]
    // 0x814e60: StoreField: r1->field_7 = r0
    //     0x814e60: stur            w0, [x1, #7]
    // 0x814e64: mov             x0, x1
    // 0x814e68: r0 = Throw()
    //     0x814e68: bl              #0xd67e38  ; ThrowStub
    // 0x814e6c: brk             #0
    // 0x814e70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x814e70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x814e74: b               #0x8148a4
    // 0x814e78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x814e78: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _decodeAes(/* No info */) {
    // ** addr: 0x817210, size: 0x14c
    // 0x817210: EnterFrame
    //     0x817210: stp             fp, lr, [SP, #-0x10]!
    //     0x817214: mov             fp, SP
    // 0x817218: CheckStackOverflow
    //     0x817218: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81721c: cmp             SP, x16
    //     0x817220: b.ls            #0x817340
    // 0x817224: ldr             x0, [fp, #0x18]
    // 0x817228: LoadField: r1 = r0->field_53
    //     0x817228: ldur            w1, [x0, #0x53]
    // 0x81722c: DecompressPointer r1
    //     0x81722c: add             x1, x1, HEAP, lsl #32
    // 0x817230: cmp             w1, NULL
    // 0x817234: b.eq            #0x817348
    // 0x817238: LoadField: r0 = r1->field_7
    //     0x817238: ldur            x0, [x1, #7]
    // 0x81723c: cmp             x0, #1
    // 0x817240: b.eq            #0x817250
    // 0x817244: cmp             x0, #1
    // 0x817248: b.ne            #0x817298
    // 0x81724c: b               #0x817274
    // 0x817250: r0 = 8
    //     0x817250: mov             x0, #8
    // 0x817254: ldr             x16, [fp, #0x10]
    // 0x817258: stp             x0, x16, [SP, #-0x10]!
    // 0x81725c: r0 = readBytes()
    //     0x81725c: bl              #0x817d54  ; [package:archive/src/util/input_stream.dart] InputStream::readBytes
    // 0x817260: add             SP, SP, #0x10
    // 0x817264: SaveReg r0
    //     0x817264: str             x0, [SP, #-8]!
    // 0x817268: r0 = toUint8List()
    //     0x817268: bl              #0x7f57d4  ; [package:archive/src/util/input_stream.dart] InputStream::toUint8List
    // 0x81726c: add             SP, SP, #8
    // 0x817270: b               #0x8172b8
    // 0x817274: r0 = 12
    //     0x817274: mov             x0, #0xc
    // 0x817278: ldr             x16, [fp, #0x10]
    // 0x81727c: stp             x0, x16, [SP, #-0x10]!
    // 0x817280: r0 = readBytes()
    //     0x817280: bl              #0x817d54  ; [package:archive/src/util/input_stream.dart] InputStream::readBytes
    // 0x817284: add             SP, SP, #0x10
    // 0x817288: SaveReg r0
    //     0x817288: str             x0, [SP, #-8]!
    // 0x81728c: r0 = toUint8List()
    //     0x81728c: bl              #0x7f57d4  ; [package:archive/src/util/input_stream.dart] InputStream::toUint8List
    // 0x817290: add             SP, SP, #8
    // 0x817294: b               #0x8172b8
    // 0x817298: r0 = 16
    //     0x817298: mov             x0, #0x10
    // 0x81729c: ldr             x16, [fp, #0x10]
    // 0x8172a0: stp             x0, x16, [SP, #-0x10]!
    // 0x8172a4: r0 = readBytes()
    //     0x8172a4: bl              #0x817d54  ; [package:archive/src/util/input_stream.dart] InputStream::readBytes
    // 0x8172a8: add             SP, SP, #0x10
    // 0x8172ac: SaveReg r0
    //     0x8172ac: str             x0, [SP, #-8]!
    // 0x8172b0: r0 = toUint8List()
    //     0x8172b0: bl              #0x7f57d4  ; [package:archive/src/util/input_stream.dart] InputStream::toUint8List
    // 0x8172b4: add             SP, SP, #8
    // 0x8172b8: ldr             x1, [fp, #0x10]
    // 0x8172bc: r0 = 2
    //     0x8172bc: mov             x0, #2
    // 0x8172c0: stp             x0, x1, [SP, #-0x10]!
    // 0x8172c4: r0 = readBytes()
    //     0x8172c4: bl              #0x817d54  ; [package:archive/src/util/input_stream.dart] InputStream::readBytes
    // 0x8172c8: add             SP, SP, #0x10
    // 0x8172cc: SaveReg r0
    //     0x8172cc: str             x0, [SP, #-8]!
    // 0x8172d0: r0 = toUint8List()
    //     0x8172d0: bl              #0x7f57d4  ; [package:archive/src/util/input_stream.dart] InputStream::toUint8List
    // 0x8172d4: add             SP, SP, #8
    // 0x8172d8: ldr             x0, [fp, #0x10]
    // 0x8172dc: LoadField: r1 = r0->field_23
    //     0x8172dc: ldur            w1, [x0, #0x23]
    // 0x8172e0: DecompressPointer r1
    //     0x8172e0: add             x1, x1, HEAP, lsl #32
    // 0x8172e4: r16 = Sentinel
    //     0x8172e4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8172e8: cmp             w1, w16
    // 0x8172ec: b.eq            #0x81734c
    // 0x8172f0: LoadField: r2 = r0->field_b
    //     0x8172f0: ldur            x2, [x0, #0xb]
    // 0x8172f4: LoadField: r3 = r0->field_13
    //     0x8172f4: ldur            x3, [x0, #0x13]
    // 0x8172f8: sub             x4, x2, x3
    // 0x8172fc: r2 = LoadInt32Instr(r1)
    //     0x8172fc: sbfx            x2, x1, #1, #0x1f
    //     0x817300: tbz             w1, #0, #0x817308
    //     0x817304: ldur            x2, [x1, #7]
    // 0x817308: sub             x1, x2, x4
    // 0x81730c: sub             x2, x1, #0xa
    // 0x817310: stp             x2, x0, [SP, #-0x10]!
    // 0x817314: r0 = readBytes()
    //     0x817314: bl              #0x817d54  ; [package:archive/src/util/input_stream.dart] InputStream::readBytes
    // 0x817318: add             SP, SP, #0x10
    // 0x81731c: SaveReg r0
    //     0x81731c: str             x0, [SP, #-8]!
    // 0x817320: r0 = toUint8List()
    //     0x817320: bl              #0x7f57d4  ; [package:archive/src/util/input_stream.dart] InputStream::toUint8List
    // 0x817324: add             SP, SP, #8
    // 0x817328: r0 = Null
    //     0x817328: mov             x0, NULL
    // 0x81732c: cmp             w0, NULL
    // 0x817330: b.eq            #0x817358
    // 0x817334: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x817334: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x817338: r0 = Throw()
    //     0x817338: bl              #0xd67e38  ; ThrowStub
    // 0x81733c: brk             #0
    // 0x817340: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x817340: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x817344: b               #0x817224
    // 0x817348: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x817348: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x81734c: r9 = _length
    //     0x81734c: add             x9, PP, #0x34, lsl #12  ; [pp+0x34a20] Field <InputStream._length@54080104>: late (offset: 0x24)
    //     0x817350: ldr             x9, [x9, #0xa20]
    // 0x817354: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x817354: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x817358: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x817358: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _decodeZipCrypto(/* No info */) {
    // ** addr: 0x81735c, size: 0x2cc
    // 0x81735c: EnterFrame
    //     0x81735c: stp             fp, lr, [SP, #-0x10]!
    //     0x817360: mov             fp, SP
    // 0x817364: AllocStack(0x28)
    //     0x817364: sub             SP, SP, #0x28
    // 0x817368: CheckStackOverflow
    //     0x817368: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81736c: cmp             SP, x16
    //     0x817370: b.ls            #0x8175d8
    // 0x817374: ldr             x2, [fp, #0x10]
    // 0x817378: LoadField: r3 = r2->field_5b
    //     0x817378: ldur            w3, [x2, #0x5b]
    // 0x81737c: DecompressPointer r3
    //     0x81737c: add             x3, x3, HEAP, lsl #32
    // 0x817380: stur            x3, [fp, #-0x10]
    // 0x817384: r4 = 0
    //     0x817384: mov             x4, #0
    // 0x817388: stur            x4, [fp, #-8]
    // 0x81738c: CheckStackOverflow
    //     0x81738c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x817390: cmp             SP, x16
    //     0x817394: b.ls            #0x8175e0
    // 0x817398: cmp             x4, #0xc
    // 0x81739c: b.ge            #0x81749c
    // 0x8173a0: LoadField: r0 = r2->field_43
    //     0x8173a0: ldur            w0, [x2, #0x43]
    // 0x8173a4: DecompressPointer r0
    //     0x8173a4: add             x0, x0, HEAP, lsl #32
    // 0x8173a8: r16 = Sentinel
    //     0x8173a8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8173ac: cmp             w0, w16
    // 0x8173b0: b.eq            #0x8175e8
    // 0x8173b4: LoadField: r5 = r0->field_7
    //     0x8173b4: ldur            w5, [x0, #7]
    // 0x8173b8: DecompressPointer r5
    //     0x8173b8: add             x5, x5, HEAP, lsl #32
    // 0x8173bc: LoadField: r6 = r0->field_b
    //     0x8173bc: ldur            x6, [x0, #0xb]
    // 0x8173c0: add             x1, x6, #1
    // 0x8173c4: StoreField: r0->field_b = r1
    //     0x8173c4: stur            x1, [x0, #0xb]
    // 0x8173c8: r0 = BoxInt64Instr(r6)
    //     0x8173c8: sbfiz           x0, x6, #1, #0x1f
    //     0x8173cc: cmp             x6, x0, asr #1
    //     0x8173d0: b.eq            #0x8173dc
    //     0x8173d4: bl              #0xd69bb8
    //     0x8173d8: stur            x6, [x0, #7]
    // 0x8173dc: r1 = LoadClassIdInstr(r5)
    //     0x8173dc: ldur            x1, [x5, #-1]
    //     0x8173e0: ubfx            x1, x1, #0xc, #0x14
    // 0x8173e4: stp             x0, x5, [SP, #-0x10]!
    // 0x8173e8: mov             x0, x1
    // 0x8173ec: r0 = GDT[cid_x0 + -0xd83]()
    //     0x8173ec: sub             lr, x0, #0xd83
    //     0x8173f0: ldr             lr, [x21, lr, lsl #3]
    //     0x8173f4: blr             lr
    // 0x8173f8: add             SP, SP, #0x10
    // 0x8173fc: mov             x3, x0
    // 0x817400: ldur            x2, [fp, #-0x10]
    // 0x817404: LoadField: r0 = r2->field_b
    //     0x817404: ldur            w0, [x2, #0xb]
    // 0x817408: DecompressPointer r0
    //     0x817408: add             x0, x0, HEAP, lsl #32
    // 0x81740c: r1 = LoadInt32Instr(r0)
    //     0x81740c: sbfx            x1, x0, #1, #0x1f
    // 0x817410: mov             x0, x1
    // 0x817414: r1 = 2
    //     0x817414: mov             x1, #2
    // 0x817418: cmp             x1, x0
    // 0x81741c: b.hs            #0x8175f4
    // 0x817420: LoadField: r0 = r2->field_f
    //     0x817420: ldur            w0, [x2, #0xf]
    // 0x817424: DecompressPointer r0
    //     0x817424: add             x0, x0, HEAP, lsl #32
    // 0x817428: LoadField: r1 = r0->field_17
    //     0x817428: ldur            w1, [x0, #0x17]
    // 0x81742c: DecompressPointer r1
    //     0x81742c: add             x1, x1, HEAP, lsl #32
    // 0x817430: r0 = LoadInt32Instr(r1)
    //     0x817430: sbfx            x0, x1, #1, #0x1f
    //     0x817434: tbz             w1, #0, #0x81743c
    //     0x817438: ldur            x0, [x1, #7]
    // 0x81743c: r1 = 65535
    //     0x81743c: mov             x1, #0xffff
    // 0x817440: and             x4, x0, x1
    // 0x817444: ubfx            x4, x4, #0, #0x20
    // 0x817448: orr             x0, x4, #2
    // 0x81744c: eor             x4, x0, #1
    // 0x817450: mul             x5, x0, x4
    // 0x817454: asr             x0, x5, #8
    // 0x817458: ubfx            x0, x0, #0, #0x20
    // 0x81745c: r4 = 255
    //     0x81745c: mov             x4, #0xff
    // 0x817460: and             x5, x0, x4
    // 0x817464: r0 = LoadInt32Instr(r3)
    //     0x817464: sbfx            x0, x3, #1, #0x1f
    //     0x817468: tbz             w3, #0, #0x817470
    //     0x81746c: ldur            x0, [x3, #7]
    // 0x817470: ubfx            x5, x5, #0, #0x20
    // 0x817474: eor             x3, x0, x5
    // 0x817478: ldr             x16, [fp, #0x10]
    // 0x81747c: stp             x3, x16, [SP, #-0x10]!
    // 0x817480: r0 = _updateKeys()
    //     0x817480: bl              #0x817628  ; [package:archive/src/zip/zip_file.dart] ZipFile::_updateKeys
    // 0x817484: add             SP, SP, #0x10
    // 0x817488: ldur            x0, [fp, #-8]
    // 0x81748c: add             x4, x0, #1
    // 0x817490: ldr             x2, [fp, #0x10]
    // 0x817494: ldur            x3, [fp, #-0x10]
    // 0x817498: b               #0x817388
    // 0x81749c: mov             x0, x2
    // 0x8174a0: LoadField: r1 = r0->field_43
    //     0x8174a0: ldur            w1, [x0, #0x43]
    // 0x8174a4: DecompressPointer r1
    //     0x8174a4: add             x1, x1, HEAP, lsl #32
    // 0x8174a8: r16 = Sentinel
    //     0x8174a8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8174ac: cmp             w1, w16
    // 0x8174b0: b.eq            #0x8175f8
    // 0x8174b4: SaveReg r1
    //     0x8174b4: str             x1, [SP, #-8]!
    // 0x8174b8: r0 = toUint8List()
    //     0x8174b8: bl              #0x7f57d4  ; [package:archive/src/util/input_stream.dart] InputStream::toUint8List
    // 0x8174bc: add             SP, SP, #8
    // 0x8174c0: mov             x2, x0
    // 0x8174c4: stur            x2, [fp, #-0x28]
    // 0x8174c8: LoadField: r0 = r2->field_13
    //     0x8174c8: ldur            w0, [x2, #0x13]
    // 0x8174cc: DecompressPointer r0
    //     0x8174cc: add             x0, x0, HEAP, lsl #32
    // 0x8174d0: r3 = LoadInt32Instr(r0)
    //     0x8174d0: sbfx            x3, x0, #1, #0x1f
    // 0x8174d4: stur            x3, [fp, #-0x20]
    // 0x8174d8: r7 = 0
    //     0x8174d8: mov             x7, #0
    // 0x8174dc: ldur            x4, [fp, #-0x10]
    // 0x8174e0: r5 = 65535
    //     0x8174e0: mov             x5, #0xffff
    // 0x8174e4: r6 = 255
    //     0x8174e4: mov             x6, #0xff
    // 0x8174e8: stur            x7, [fp, #-0x18]
    // 0x8174ec: CheckStackOverflow
    //     0x8174ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8174f0: cmp             SP, x16
    //     0x8174f4: b.ls            #0x817604
    // 0x8174f8: cmp             x7, x3
    // 0x8174fc: b.ge            #0x8175a8
    // 0x817500: LoadField: r0 = r2->field_7
    //     0x817500: ldur            x0, [x2, #7]
    // 0x817504: ldrb            w8, [x0, x7]
    // 0x817508: LoadField: r0 = r4->field_b
    //     0x817508: ldur            w0, [x4, #0xb]
    // 0x81750c: DecompressPointer r0
    //     0x81750c: add             x0, x0, HEAP, lsl #32
    // 0x817510: r1 = LoadInt32Instr(r0)
    //     0x817510: sbfx            x1, x0, #1, #0x1f
    // 0x817514: mov             x0, x1
    // 0x817518: r1 = 2
    //     0x817518: mov             x1, #2
    // 0x81751c: cmp             x1, x0
    // 0x817520: b.hs            #0x81760c
    // 0x817524: LoadField: r0 = r4->field_f
    //     0x817524: ldur            w0, [x4, #0xf]
    // 0x817528: DecompressPointer r0
    //     0x817528: add             x0, x0, HEAP, lsl #32
    // 0x81752c: LoadField: r1 = r0->field_17
    //     0x81752c: ldur            w1, [x0, #0x17]
    // 0x817530: DecompressPointer r1
    //     0x817530: add             x1, x1, HEAP, lsl #32
    // 0x817534: r0 = LoadInt32Instr(r1)
    //     0x817534: sbfx            x0, x1, #1, #0x1f
    //     0x817538: tbz             w1, #0, #0x817540
    //     0x81753c: ldur            x0, [x1, #7]
    // 0x817540: and             x1, x0, x5
    // 0x817544: ubfx            x1, x1, #0, #0x20
    // 0x817548: orr             x0, x1, #2
    // 0x81754c: eor             x1, x0, #1
    // 0x817550: mul             x9, x0, x1
    // 0x817554: asr             x0, x9, #8
    // 0x817558: ubfx            x0, x0, #0, #0x20
    // 0x81755c: and             x1, x0, x6
    // 0x817560: ubfx            x1, x1, #0, #0x20
    // 0x817564: eor             x0, x8, x1
    // 0x817568: stur            x0, [fp, #-8]
    // 0x81756c: ldr             x16, [fp, #0x10]
    // 0x817570: stp             x0, x16, [SP, #-0x10]!
    // 0x817574: r0 = _updateKeys()
    //     0x817574: bl              #0x817628  ; [package:archive/src/zip/zip_file.dart] ZipFile::_updateKeys
    // 0x817578: add             SP, SP, #0x10
    // 0x81757c: ldur            x0, [fp, #-0x28]
    // 0x817580: ldurb           w16, [x0, #-1]
    // 0x817584: tbnz            w16, #6, #0x817610
    // 0x817588: LoadField: r1 = r0->field_7
    //     0x817588: ldur            x1, [x0, #7]
    // 0x81758c: ldur            x2, [fp, #-0x18]
    // 0x817590: ldur            x3, [fp, #-8]
    // 0x817594: strb            w3, [x1, x2]
    // 0x817598: add             x7, x2, #1
    // 0x81759c: mov             x2, x0
    // 0x8175a0: ldur            x3, [fp, #-0x20]
    // 0x8175a4: b               #0x8174dc
    // 0x8175a8: mov             x0, x2
    // 0x8175ac: r0 = InputStream()
    //     0x8175ac: bl              #0x818b18  ; AllocateInputStreamStub -> InputStream (size=0x28)
    // 0x8175b0: stur            x0, [fp, #-0x10]
    // 0x8175b4: ldur            x16, [fp, #-0x28]
    // 0x8175b8: stp             x16, x0, [SP, #-0x10]!
    // 0x8175bc: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x8175bc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x8175c0: r0 = InputStream()
    //     0x8175c0: bl              #0x818754  ; [package:archive/src/util/input_stream.dart] InputStream::InputStream
    // 0x8175c4: add             SP, SP, #0x10
    // 0x8175c8: ldur            x0, [fp, #-0x10]
    // 0x8175cc: LeaveFrame
    //     0x8175cc: mov             SP, fp
    //     0x8175d0: ldp             fp, lr, [SP], #0x10
    // 0x8175d4: ret
    //     0x8175d4: ret             
    // 0x8175d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8175d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8175dc: b               #0x817374
    // 0x8175e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8175e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8175e4: b               #0x817398
    // 0x8175e8: r9 = _rawContent
    //     0x8175e8: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4cc10] Field <ZipFile._rawContent@59286345>: late (offset: 0x44)
    //     0x8175ec: ldr             x9, [x9, #0xc10]
    // 0x8175f0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8175f0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8175f4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8175f4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8175f8: r9 = _rawContent
    //     0x8175f8: add             x9, PP, #0x4c, lsl #12  ; [pp+0x4cc10] Field <ZipFile._rawContent@59286345>: late (offset: 0x44)
    //     0x8175fc: ldr             x9, [x9, #0xc10]
    // 0x817600: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x817600: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x817604: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x817604: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x817608: b               #0x8174f8
    // 0x81760c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x81760c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x817610: SaveReg r0
    //     0x817610: str             x0, [SP, #-8]!
    // 0x817614: ldr             x5, [THR, #0x468]  ; THR::WriteError
    // 0x817618: r4 = 0
    //     0x817618: mov             x4, #0
    // 0x81761c: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x817620: blr             lr
    // 0x817624: brk             #0
  }
  _ _updateKeys(/* No info */) {
    // ** addr: 0x817628, size: 0x208
    // 0x817628: EnterFrame
    //     0x817628: stp             fp, lr, [SP, #-0x10]!
    //     0x81762c: mov             fp, SP
    // 0x817630: r3 = const [0, 1996959894, 3993919788, 2567524794, 0x76dc419, 1886057615, 3915621685, 2657392035, 0xedb8832, 2044508324, 3772115230, 2547177864, 0x9b64c2b, 2125561021, 3887607047, 2428444049, 0x1db71064, 1789927666, 4089016648, 2227061214, 0x1adad47d, 1843258603, 4107580753, 2211677639, 0x136c9856, 1684777152, 4251122042, 2321926636, 0x14015c4f, 1661365465, 4195302755, 2366115317, 0x3b6e20c8, 1281953886, 3579855332, 2724688242, 0x3c03e4d1, 1258607687, 3524101629, 2768942443, 0x35b5a8fa, 1119000684, 3686517206, 2898065728, 0x32d86ce3, 1172266101, 3705015759, 2882616665, 0x26d930ac, 1373503546, 3369554304, 3218104598, 0x21b4f4b5, 1454621731, 3485111705, 3099436303, 0x2802b89e, 1594198024, 3322730930, 2970347812, 0x2f6f7c87, 1483230225, 3244367275, 3060149565, 1994146192, 0x1db7106, 2563907772, 4023717930, 1907459465, 0x6b6b51f, 2680153253, 3904427059, 2013776290, 0xf00f934, 2517215374, 3775830040, 2137656763, 0x86d3d2d, 2439277719, 3865271297, 1802195444, 0x1c6c6162, 2238001368, 4066508878, 1812370925, 0x1b01a57b, 2181625025, 4111451223, 1706088902, 0x12b7e950, 2344532202, 4240017532, 1658658271, 0x15da2d49, 2362670323, 4224994405, 1303535960, 0x3ab551ce, 2747007092, 3569037538, 1256170817, 0x3dd895d7, 2765210733, 3554079995, 1131014506, 0x346ed9fc, 2909243462, 3663771856, 1141124467, 0x33031de5, 2852801631, 3708648649, 1342533948, 0x270241aa, 3188396048, 3373015174, 1466479909, 0x206f85b3, 3110523913, 3462522015, 1591671054, 0x29d9c998, 2966460450, 3352799412, 1504918807, 0x2eb40d81, 3082640443, 3233442989, 3988292384, 2596254646, 0x3b6e20c, 1957810842, 3939845945, 2647816111, 0x4db2615, 1943803523, 3814918930, 2489596804, 0xd6d6a3e, 2053790376, 3826175755, 2466906013, 0xa00ae27, 2097651377, 4027552580, 2265490386, 0x1e01f268, 1762050814, 4150417245, 2154129355, 0x196c3671, 1852507879, 4275313526, 2312317920, 0x10da7a5a, 1742555852, 4189708143, 2394877945, 0x17b7be43, 1622183637, 3604390888, 2714866558, 0x38d8c2c4, 1340076626, 3518719985, 2797360999, 0x3fb506dd, 1219638859, 3624741850, 2936675148, 0x36034af6, 1090812512, 3747672003, 2825379669, 0x316e8eef, 1181335161, 3412177804, 3160834842, 0x256fd2a0, 1382605366, 3423369109, 3138078467, 0x220216b9, 1426400815, 3317316542, 2998733608, 0x2bb45a92, 1555261956, 3268935591, 3050360625, 0x2cd99e8b, 1541320221, 2607071920, 3965973030, 1969922972, 0x26d930a, 2617837225, 3943577151, 1913087877, 0x5005713, 2512341634, 3803740692, 2075208622, 0xcb61b38, 2463272603, 3855990285, 2094854071, 0xbdbdf21, 2262029012, 4057260610, 1759359992, 0x1fda836e, 2176718541, 4139329115, 1873836001, 0x18b74777, 2282248934, 4279200368, 1711684554, 0x11010b5c, 2405801727, 4167216745, 1634467795, 0x166ccf45, 2685067896, 3608007406, 1308918612, 0x3903b3c2, 2808555105, 3495958263, 1231636301, 0x3e6e77db, 2932959818, 3654703836, 1088359270, 0x37d83bf0, 2847714899, 3736837829, 1202900863, 0x30b5ffe9, 3183342108, 3401237130, 1404277552, 0x24b4a3a6, 3134207493, 3453421203, 1423857449, 0x23d967bf, 3009837614, 3294710456, 1567103746, 0x2a6f2b94, 3020668471, 3272380065, 1510334235, 0x2d02ef8d]
    //     0x817630: add             x3, PP, #0x34, lsl #12  ; [pp+0x349a0] List<int>(256)
    //     0x817634: ldr             x3, [x3, #0x9a0]
    // 0x817638: r2 = 255
    //     0x817638: mov             x2, #0xff
    // 0x81763c: ldr             x4, [fp, #0x18]
    // 0x817640: LoadField: r5 = r4->field_5b
    //     0x817640: ldur            w5, [x4, #0x5b]
    // 0x817644: DecompressPointer r5
    //     0x817644: add             x5, x5, HEAP, lsl #32
    // 0x817648: LoadField: r4 = r5->field_b
    //     0x817648: ldur            w4, [x5, #0xb]
    // 0x81764c: DecompressPointer r4
    //     0x81764c: add             x4, x4, HEAP, lsl #32
    // 0x817650: r6 = LoadInt32Instr(r4)
    //     0x817650: sbfx            x6, x4, #1, #0x1f
    // 0x817654: mov             x0, x6
    // 0x817658: r1 = 0
    //     0x817658: mov             x1, #0
    // 0x81765c: cmp             x1, x0
    // 0x817660: b.hs            #0x817824
    // 0x817664: LoadField: r4 = r5->field_f
    //     0x817664: ldur            w4, [x5, #0xf]
    // 0x817668: DecompressPointer r4
    //     0x817668: add             x4, x4, HEAP, lsl #32
    // 0x81766c: LoadField: r5 = r4->field_f
    //     0x81766c: ldur            w5, [x4, #0xf]
    // 0x817670: DecompressPointer r5
    //     0x817670: add             x5, x5, HEAP, lsl #32
    // 0x817674: r7 = LoadInt32Instr(r5)
    //     0x817674: sbfx            x7, x5, #1, #0x1f
    //     0x817678: tbz             w5, #0, #0x817680
    //     0x81767c: ldur            x7, [x5, #7]
    // 0x817680: ldr             x5, [fp, #0x10]
    // 0x817684: ubfx            x5, x5, #0, #0x20
    // 0x817688: mov             x8, x7
    // 0x81768c: ubfx            x8, x8, #0, #0x20
    // 0x817690: eor             x9, x8, x5
    // 0x817694: and             x5, x9, x2
    // 0x817698: ubfx            x5, x5, #0, #0x20
    // 0x81769c: ArrayLoad: r8 = r3[r5]  ; Unknown_4
    //     0x81769c: add             x16, x3, x5, lsl #2
    //     0x8176a0: ldur            w8, [x16, #0xf]
    // 0x8176a4: DecompressPointer r8
    //     0x8176a4: add             x8, x8, HEAP, lsl #32
    // 0x8176a8: asr             x5, x7, #8
    // 0x8176ac: r7 = LoadInt32Instr(r8)
    //     0x8176ac: sbfx            x7, x8, #1, #0x1f
    //     0x8176b0: tbz             w8, #0, #0x8176b8
    //     0x8176b4: ldur            x7, [x8, #7]
    // 0x8176b8: eor             x8, x7, x5
    // 0x8176bc: r0 = BoxInt64Instr(r8)
    //     0x8176bc: sbfiz           x0, x8, #1, #0x1f
    //     0x8176c0: cmp             x8, x0, asr #1
    //     0x8176c4: b.eq            #0x8176d0
    //     0x8176c8: bl              #0xd69bb8
    //     0x8176cc: stur            x8, [x0, #7]
    // 0x8176d0: mov             x1, x4
    // 0x8176d4: ArrayStore: r1[0] = r0  ; List_4
    //     0x8176d4: add             x25, x1, #0xf
    //     0x8176d8: str             w0, [x25]
    //     0x8176dc: tbz             w0, #0, #0x8176f8
    //     0x8176e0: ldurb           w16, [x1, #-1]
    //     0x8176e4: ldurb           w17, [x0, #-1]
    //     0x8176e8: and             x16, x17, x16, lsr #2
    //     0x8176ec: tst             x16, HEAP, lsr #32
    //     0x8176f0: b.eq            #0x8176f8
    //     0x8176f4: bl              #0xd67e5c
    // 0x8176f8: mov             x0, x6
    // 0x8176fc: r1 = 1
    //     0x8176fc: mov             x1, #1
    // 0x817700: cmp             x1, x0
    // 0x817704: b.hs            #0x817828
    // 0x817708: LoadField: r5 = r4->field_13
    //     0x817708: ldur            w5, [x4, #0x13]
    // 0x81770c: DecompressPointer r5
    //     0x81770c: add             x5, x5, HEAP, lsl #32
    // 0x817710: ubfx            x8, x8, #0, #0x20
    // 0x817714: and             x7, x8, x2
    // 0x817718: r8 = LoadInt32Instr(r5)
    //     0x817718: sbfx            x8, x5, #1, #0x1f
    //     0x81771c: tbz             w5, #0, #0x817724
    //     0x817720: ldur            x8, [x5, #7]
    // 0x817724: ubfx            x7, x7, #0, #0x20
    // 0x817728: add             x5, x8, x7
    // 0x81772c: r16 = 134775813
    //     0x81772c: mov             x16, #0x8405
    //     0x817730: movk            x16, #0x808, lsl #16
    // 0x817734: mul             x7, x5, x16
    // 0x817738: add             x5, x7, #1
    // 0x81773c: r0 = BoxInt64Instr(r5)
    //     0x81773c: sbfiz           x0, x5, #1, #0x1f
    //     0x817740: cmp             x5, x0, asr #1
    //     0x817744: b.eq            #0x817750
    //     0x817748: bl              #0xd69bb8
    //     0x81774c: stur            x5, [x0, #7]
    // 0x817750: mov             x1, x4
    // 0x817754: ArrayStore: r1[1] = r0  ; List_4
    //     0x817754: add             x25, x1, #0x13
    //     0x817758: str             w0, [x25]
    //     0x81775c: tbz             w0, #0, #0x817778
    //     0x817760: ldurb           w16, [x1, #-1]
    //     0x817764: ldurb           w17, [x0, #-1]
    //     0x817768: and             x16, x17, x16, lsr #2
    //     0x81776c: tst             x16, HEAP, lsr #32
    //     0x817770: b.eq            #0x817778
    //     0x817774: bl              #0xd67e5c
    // 0x817778: mov             x0, x6
    // 0x81777c: r1 = 2
    //     0x81777c: mov             x1, #2
    // 0x817780: cmp             x1, x0
    // 0x817784: b.hs            #0x81782c
    // 0x817788: LoadField: r6 = r4->field_17
    //     0x817788: ldur            w6, [x4, #0x17]
    // 0x81778c: DecompressPointer r6
    //     0x81778c: add             x6, x6, HEAP, lsl #32
    // 0x817790: asr             x7, x5, #0x18
    // 0x817794: r5 = LoadInt32Instr(r6)
    //     0x817794: sbfx            x5, x6, #1, #0x1f
    //     0x817798: tbz             w6, #0, #0x8177a0
    //     0x81779c: ldur            x5, [x6, #7]
    // 0x8177a0: ubfx            x7, x7, #0, #0x20
    // 0x8177a4: mov             x6, x5
    // 0x8177a8: ubfx            x6, x6, #0, #0x20
    // 0x8177ac: eor             x8, x6, x7
    // 0x8177b0: and             x6, x8, x2
    // 0x8177b4: ubfx            x6, x6, #0, #0x20
    // 0x8177b8: ArrayLoad: r2 = r3[r6]  ; Unknown_4
    //     0x8177b8: add             x16, x3, x6, lsl #2
    //     0x8177bc: ldur            w2, [x16, #0xf]
    // 0x8177c0: DecompressPointer r2
    //     0x8177c0: add             x2, x2, HEAP, lsl #32
    // 0x8177c4: asr             x3, x5, #8
    // 0x8177c8: r5 = LoadInt32Instr(r2)
    //     0x8177c8: sbfx            x5, x2, #1, #0x1f
    //     0x8177cc: tbz             w2, #0, #0x8177d4
    //     0x8177d0: ldur            x5, [x2, #7]
    // 0x8177d4: eor             x2, x5, x3
    // 0x8177d8: r0 = BoxInt64Instr(r2)
    //     0x8177d8: sbfiz           x0, x2, #1, #0x1f
    //     0x8177dc: cmp             x2, x0, asr #1
    //     0x8177e0: b.eq            #0x8177ec
    //     0x8177e4: bl              #0xd69bb8
    //     0x8177e8: stur            x2, [x0, #7]
    // 0x8177ec: mov             x1, x4
    // 0x8177f0: ArrayStore: r1[2] = r0  ; List_4
    //     0x8177f0: add             x25, x1, #0x17
    //     0x8177f4: str             w0, [x25]
    //     0x8177f8: tbz             w0, #0, #0x817814
    //     0x8177fc: ldurb           w16, [x1, #-1]
    //     0x817800: ldurb           w17, [x0, #-1]
    //     0x817804: and             x16, x17, x16, lsr #2
    //     0x817808: tst             x16, HEAP, lsr #32
    //     0x81780c: b.eq            #0x817814
    //     0x817810: bl              #0xd67e5c
    // 0x817814: r0 = Null
    //     0x817814: mov             x0, NULL
    // 0x817818: LeaveFrame
    //     0x817818: mov             SP, fp
    //     0x81781c: ldp             fp, lr, [SP], #0x10
    // 0x817820: ret
    //     0x817820: ret             
    // 0x817824: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x817824: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x817828: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x817828: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x81782c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x81782c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

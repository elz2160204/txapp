// lib: , url: package:archive/src/zip/zip_file_header.dart

// class id: 1048624, size: 0x8
class :: {
}

// class id: 4997, size: 0x2c, field offset: 0x8
class ZipFileHeader extends Object {

  _ ZipFileHeader(/* No info */) {
    // ** addr: 0x8141c0, size: 0x694
    // 0x8141c0: EnterFrame
    //     0x8141c0: stp             fp, lr, [SP, #-0x10]!
    //     0x8141c4: mov             fp, SP
    // 0x8141c8: AllocStack(0x20)
    //     0x8141c8: sub             SP, SP, #0x20
    // 0x8141cc: r1 = ""
    //     0x8141cc: ldr             x1, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x8141d0: r0 = 0
    //     0x8141d0: mov             x0, #0
    // 0x8141d4: CheckStackOverflow
    //     0x8141d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8141d8: cmp             SP, x16
    //     0x8141dc: b.ls            #0x814848
    // 0x8141e0: ldr             x2, [fp, #0x20]
    // 0x8141e4: StoreField: r2->field_7 = r0
    //     0x8141e4: stur            x0, [x2, #7]
    // 0x8141e8: StoreField: r2->field_23 = r1
    //     0x8141e8: stur            w1, [x2, #0x23]
    // 0x8141ec: r16 = <int>
    //     0x8141ec: ldr             x16, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0x8141f0: stp             xzr, x16, [SP, #-0x10]!
    // 0x8141f4: r0 = _GrowableList()
    //     0x8141f4: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x8141f8: add             SP, SP, #0x10
    // 0x8141fc: ldr             x16, [fp, #0x18]
    // 0x814200: SaveReg r16
    //     0x814200: str             x16, [SP, #-8]!
    // 0x814204: r0 = readUint16()
    //     0x814204: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x814208: add             SP, SP, #8
    // 0x81420c: mov             x1, x0
    // 0x814210: ldr             x0, [fp, #0x20]
    // 0x814214: StoreField: r0->field_7 = r1
    //     0x814214: stur            x1, [x0, #7]
    // 0x814218: ldr             x16, [fp, #0x18]
    // 0x81421c: SaveReg r16
    //     0x81421c: str             x16, [SP, #-8]!
    // 0x814220: r0 = readUint16()
    //     0x814220: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x814224: add             SP, SP, #8
    // 0x814228: ldr             x16, [fp, #0x18]
    // 0x81422c: SaveReg r16
    //     0x81422c: str             x16, [SP, #-8]!
    // 0x814230: r0 = readUint16()
    //     0x814230: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x814234: add             SP, SP, #8
    // 0x814238: ldr             x16, [fp, #0x18]
    // 0x81423c: SaveReg r16
    //     0x81423c: str             x16, [SP, #-8]!
    // 0x814240: r0 = readUint16()
    //     0x814240: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x814244: add             SP, SP, #8
    // 0x814248: ldr             x16, [fp, #0x18]
    // 0x81424c: SaveReg r16
    //     0x81424c: str             x16, [SP, #-8]!
    // 0x814250: r0 = readUint16()
    //     0x814250: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x814254: add             SP, SP, #8
    // 0x814258: ldr             x16, [fp, #0x18]
    // 0x81425c: SaveReg r16
    //     0x81425c: str             x16, [SP, #-8]!
    // 0x814260: r0 = readUint16()
    //     0x814260: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x814264: add             SP, SP, #8
    // 0x814268: ldr             x16, [fp, #0x18]
    // 0x81426c: SaveReg r16
    //     0x81426c: str             x16, [SP, #-8]!
    // 0x814270: r0 = readUint32()
    //     0x814270: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x814274: add             SP, SP, #8
    // 0x814278: ldr             x16, [fp, #0x18]
    // 0x81427c: SaveReg r16
    //     0x81427c: str             x16, [SP, #-8]!
    // 0x814280: r0 = readUint32()
    //     0x814280: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x814284: add             SP, SP, #8
    // 0x814288: mov             x2, x0
    // 0x81428c: r0 = BoxInt64Instr(r2)
    //     0x81428c: sbfiz           x0, x2, #1, #0x1f
    //     0x814290: cmp             x2, x0, asr #1
    //     0x814294: b.eq            #0x8142a0
    //     0x814298: bl              #0xd69bb8
    //     0x81429c: stur            x2, [x0, #7]
    // 0x8142a0: ldr             x1, [fp, #0x20]
    // 0x8142a4: StoreField: r1->field_f = r0
    //     0x8142a4: stur            w0, [x1, #0xf]
    //     0x8142a8: tbz             w0, #0, #0x8142c4
    //     0x8142ac: ldurb           w16, [x1, #-1]
    //     0x8142b0: ldurb           w17, [x0, #-1]
    //     0x8142b4: and             x16, x17, x16, lsr #2
    //     0x8142b8: tst             x16, HEAP, lsr #32
    //     0x8142bc: b.eq            #0x8142c4
    //     0x8142c0: bl              #0xd6826c
    // 0x8142c4: ldr             x16, [fp, #0x18]
    // 0x8142c8: SaveReg r16
    //     0x8142c8: str             x16, [SP, #-8]!
    // 0x8142cc: r0 = readUint32()
    //     0x8142cc: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x8142d0: add             SP, SP, #8
    // 0x8142d4: mov             x2, x0
    // 0x8142d8: r0 = BoxInt64Instr(r2)
    //     0x8142d8: sbfiz           x0, x2, #1, #0x1f
    //     0x8142dc: cmp             x2, x0, asr #1
    //     0x8142e0: b.eq            #0x8142ec
    //     0x8142e4: bl              #0xd69bb8
    //     0x8142e8: stur            x2, [x0, #7]
    // 0x8142ec: ldr             x1, [fp, #0x20]
    // 0x8142f0: StoreField: r1->field_13 = r0
    //     0x8142f0: stur            w0, [x1, #0x13]
    //     0x8142f4: tbz             w0, #0, #0x814310
    //     0x8142f8: ldurb           w16, [x1, #-1]
    //     0x8142fc: ldurb           w17, [x0, #-1]
    //     0x814300: and             x16, x17, x16, lsr #2
    //     0x814304: tst             x16, HEAP, lsr #32
    //     0x814308: b.eq            #0x814310
    //     0x81430c: bl              #0xd6826c
    // 0x814310: ldr             x16, [fp, #0x18]
    // 0x814314: SaveReg r16
    //     0x814314: str             x16, [SP, #-8]!
    // 0x814318: r0 = readUint16()
    //     0x814318: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x81431c: add             SP, SP, #8
    // 0x814320: stur            x0, [fp, #-8]
    // 0x814324: ldr             x16, [fp, #0x18]
    // 0x814328: SaveReg r16
    //     0x814328: str             x16, [SP, #-8]!
    // 0x81432c: r0 = readUint16()
    //     0x81432c: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x814330: add             SP, SP, #8
    // 0x814334: stur            x0, [fp, #-0x10]
    // 0x814338: ldr             x16, [fp, #0x18]
    // 0x81433c: SaveReg r16
    //     0x81433c: str             x16, [SP, #-8]!
    // 0x814340: r0 = readUint16()
    //     0x814340: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x814344: add             SP, SP, #8
    // 0x814348: stur            x0, [fp, #-0x18]
    // 0x81434c: ldr             x16, [fp, #0x18]
    // 0x814350: SaveReg r16
    //     0x814350: str             x16, [SP, #-8]!
    // 0x814354: r0 = readUint16()
    //     0x814354: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x814358: add             SP, SP, #8
    // 0x81435c: mov             x2, x0
    // 0x814360: r0 = BoxInt64Instr(r2)
    //     0x814360: sbfiz           x0, x2, #1, #0x1f
    //     0x814364: cmp             x2, x0, asr #1
    //     0x814368: b.eq            #0x814374
    //     0x81436c: bl              #0xd69bb8
    //     0x814370: stur            x2, [x0, #7]
    // 0x814374: ldr             x1, [fp, #0x20]
    // 0x814378: StoreField: r1->field_17 = r0
    //     0x814378: stur            w0, [x1, #0x17]
    //     0x81437c: tbz             w0, #0, #0x814398
    //     0x814380: ldurb           w16, [x1, #-1]
    //     0x814384: ldurb           w17, [x0, #-1]
    //     0x814388: and             x16, x17, x16, lsr #2
    //     0x81438c: tst             x16, HEAP, lsr #32
    //     0x814390: b.eq            #0x814398
    //     0x814394: bl              #0xd6826c
    // 0x814398: ldr             x16, [fp, #0x18]
    // 0x81439c: SaveReg r16
    //     0x81439c: str             x16, [SP, #-8]!
    // 0x8143a0: r0 = readUint16()
    //     0x8143a0: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x8143a4: add             SP, SP, #8
    // 0x8143a8: ldr             x16, [fp, #0x18]
    // 0x8143ac: SaveReg r16
    //     0x8143ac: str             x16, [SP, #-8]!
    // 0x8143b0: r0 = readUint32()
    //     0x8143b0: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x8143b4: add             SP, SP, #8
    // 0x8143b8: mov             x2, x0
    // 0x8143bc: r0 = BoxInt64Instr(r2)
    //     0x8143bc: sbfiz           x0, x2, #1, #0x1f
    //     0x8143c0: cmp             x2, x0, asr #1
    //     0x8143c4: b.eq            #0x8143d0
    //     0x8143c8: bl              #0xd69bb8
    //     0x8143cc: stur            x2, [x0, #7]
    // 0x8143d0: ldr             x1, [fp, #0x20]
    // 0x8143d4: StoreField: r1->field_1b = r0
    //     0x8143d4: stur            w0, [x1, #0x1b]
    //     0x8143d8: tbz             w0, #0, #0x8143f4
    //     0x8143dc: ldurb           w16, [x1, #-1]
    //     0x8143e0: ldurb           w17, [x0, #-1]
    //     0x8143e4: and             x16, x17, x16, lsr #2
    //     0x8143e8: tst             x16, HEAP, lsr #32
    //     0x8143ec: b.eq            #0x8143f4
    //     0x8143f0: bl              #0xd6826c
    // 0x8143f4: ldr             x16, [fp, #0x18]
    // 0x8143f8: SaveReg r16
    //     0x8143f8: str             x16, [SP, #-8]!
    // 0x8143fc: r0 = readUint32()
    //     0x8143fc: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x814400: add             SP, SP, #8
    // 0x814404: mov             x2, x0
    // 0x814408: r0 = BoxInt64Instr(r2)
    //     0x814408: sbfiz           x0, x2, #1, #0x1f
    //     0x81440c: cmp             x2, x0, asr #1
    //     0x814410: b.eq            #0x81441c
    //     0x814414: bl              #0xd69bb8
    //     0x814418: stur            x2, [x0, #7]
    // 0x81441c: ldr             x1, [fp, #0x20]
    // 0x814420: StoreField: r1->field_1f = r0
    //     0x814420: stur            w0, [x1, #0x1f]
    //     0x814424: tbz             w0, #0, #0x814440
    //     0x814428: ldurb           w16, [x1, #-1]
    //     0x81442c: ldurb           w17, [x0, #-1]
    //     0x814430: and             x16, x17, x16, lsr #2
    //     0x814434: tst             x16, HEAP, lsr #32
    //     0x814438: b.eq            #0x814440
    //     0x81443c: bl              #0xd6826c
    // 0x814440: ldur            x0, [fp, #-8]
    // 0x814444: cmp             x0, #0
    // 0x814448: b.le            #0x814480
    // 0x81444c: ldr             x16, [fp, #0x18]
    // 0x814450: stp             x0, x16, [SP, #-0x10]!
    // 0x814454: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x814454: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x814458: r0 = readString()
    //     0x814458: bl              #0x818198  ; [package:archive/src/util/input_stream.dart] InputStream::readString
    // 0x81445c: add             SP, SP, #0x10
    // 0x814460: ldr             x1, [fp, #0x20]
    // 0x814464: StoreField: r1->field_23 = r0
    //     0x814464: stur            w0, [x1, #0x23]
    //     0x814468: ldurb           w16, [x1, #-1]
    //     0x81446c: ldurb           w17, [x0, #-1]
    //     0x814470: and             x16, x17, x16, lsr #2
    //     0x814474: tst             x16, HEAP, lsr #32
    //     0x814478: b.eq            #0x814480
    //     0x81447c: bl              #0xd6826c
    // 0x814480: ldur            x0, [fp, #-0x10]
    // 0x814484: cmp             x0, #0
    // 0x814488: b.le            #0x8147a4
    // 0x81448c: ldr             x16, [fp, #0x18]
    // 0x814490: stp             x0, x16, [SP, #-0x10]!
    // 0x814494: r0 = readBytes()
    //     0x814494: bl              #0x817d54  ; [package:archive/src/util/input_stream.dart] InputStream::readBytes
    // 0x814498: add             SP, SP, #0x10
    // 0x81449c: stur            x0, [fp, #-0x20]
    // 0x8144a0: SaveReg r0
    //     0x8144a0: str             x0, [SP, #-8]!
    // 0x8144a4: r0 = toUint8List()
    //     0x8144a4: bl              #0x7f57d4  ; [package:archive/src/util/input_stream.dart] InputStream::toUint8List
    // 0x8144a8: add             SP, SP, #8
    // 0x8144ac: ldur            x16, [fp, #-0x20]
    // 0x8144b0: SaveReg r16
    //     0x8144b0: str             x16, [SP, #-8]!
    // 0x8144b4: ldur            x0, [fp, #-0x10]
    // 0x8144b8: SaveReg r0
    //     0x8144b8: str             x0, [SP, #-8]!
    // 0x8144bc: r0 = rewind()
    //     0x8144bc: bl              #0x817d2c  ; [package:archive/src/util/input_stream.dart] InputStream::rewind
    // 0x8144c0: add             SP, SP, #0x10
    // 0x8144c4: ldur            x16, [fp, #-0x20]
    // 0x8144c8: SaveReg r16
    //     0x8144c8: str             x16, [SP, #-8]!
    // 0x8144cc: r0 = readUint16()
    //     0x8144cc: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x8144d0: add             SP, SP, #8
    // 0x8144d4: stur            x0, [fp, #-8]
    // 0x8144d8: ldur            x16, [fp, #-0x20]
    // 0x8144dc: SaveReg r16
    //     0x8144dc: str             x16, [SP, #-8]!
    // 0x8144e0: r0 = readUint16()
    //     0x8144e0: bl              #0x8182b4  ; [package:archive/src/util/input_stream.dart] InputStream::readUint16
    // 0x8144e4: add             SP, SP, #8
    // 0x8144e8: mov             x1, x0
    // 0x8144ec: ldur            x0, [fp, #-8]
    // 0x8144f0: stur            x1, [fp, #-0x10]
    // 0x8144f4: cmp             x0, #1
    // 0x8144f8: b.ne            #0x8147a0
    // 0x8144fc: cmp             x1, #8
    // 0x814500: b.lt            #0x8145c4
    // 0x814504: ldr             x0, [fp, #0x20]
    // 0x814508: r2 = 4294967295
    //     0x814508: add             x2, PP, #0x12, lsl #12  ; [pp+0x120e0] 0xffffffff
    //     0x81450c: ldr             x2, [x2, #0xe0]
    // 0x814510: LoadField: r3 = r0->field_13
    //     0x814510: ldur            w3, [x0, #0x13]
    // 0x814514: DecompressPointer r3
    //     0x814514: add             x3, x3, HEAP, lsl #32
    // 0x814518: cmp             w3, w2
    // 0x81451c: b.eq            #0x814558
    // 0x814520: and             w16, w3, w2
    // 0x814524: branchIfSmi(r16, 0x8145b4)
    //     0x814524: tbz             w16, #0, #0x8145b4
    // 0x814528: r16 = LoadClassIdInstr(r3)
    //     0x814528: ldur            x16, [x3, #-1]
    //     0x81452c: ubfx            x16, x16, #0xc, #0x14
    // 0x814530: cmp             x16, #0x3c
    // 0x814534: b.ne            #0x8145b4
    // 0x814538: r16 = LoadClassIdInstr(r2)
    //     0x814538: ldur            x16, [x2, #-1]
    //     0x81453c: ubfx            x16, x16, #0xc, #0x14
    // 0x814540: cmp             x16, #0x3c
    // 0x814544: b.ne            #0x8145b4
    // 0x814548: LoadField: r16 = r3->field_7
    //     0x814548: ldur            x16, [x3, #7]
    // 0x81454c: LoadField: r17 = r2->field_7
    //     0x81454c: ldur            x17, [x2, #7]
    // 0x814550: cmp             x16, x17
    // 0x814554: b.ne            #0x8145b4
    // 0x814558: ldur            x16, [fp, #-0x20]
    // 0x81455c: SaveReg r16
    //     0x81455c: str             x16, [SP, #-8]!
    // 0x814560: r0 = readUint64()
    //     0x814560: bl              #0x8178d8  ; [package:archive/src/util/input_stream.dart] InputStream::readUint64
    // 0x814564: add             SP, SP, #8
    // 0x814568: mov             x2, x0
    // 0x81456c: r0 = BoxInt64Instr(r2)
    //     0x81456c: sbfiz           x0, x2, #1, #0x1f
    //     0x814570: cmp             x2, x0, asr #1
    //     0x814574: b.eq            #0x814580
    //     0x814578: bl              #0xd69bb8
    //     0x81457c: stur            x2, [x0, #7]
    // 0x814580: ldr             x1, [fp, #0x20]
    // 0x814584: StoreField: r1->field_13 = r0
    //     0x814584: stur            w0, [x1, #0x13]
    //     0x814588: tbz             w0, #0, #0x8145a4
    //     0x81458c: ldurb           w16, [x1, #-1]
    //     0x814590: ldurb           w17, [x0, #-1]
    //     0x814594: and             x16, x17, x16, lsr #2
    //     0x814598: tst             x16, HEAP, lsr #32
    //     0x81459c: b.eq            #0x8145a4
    //     0x8145a0: bl              #0xd6826c
    // 0x8145a4: ldur            x0, [fp, #-0x10]
    // 0x8145a8: sub             x2, x0, #8
    // 0x8145ac: mov             x0, x2
    // 0x8145b0: b               #0x8145cc
    // 0x8145b4: mov             x16, x1
    // 0x8145b8: mov             x1, x0
    // 0x8145bc: mov             x0, x16
    // 0x8145c0: b               #0x8145cc
    // 0x8145c4: mov             x0, x1
    // 0x8145c8: ldr             x1, [fp, #0x20]
    // 0x8145cc: stur            x0, [fp, #-8]
    // 0x8145d0: cmp             x0, #8
    // 0x8145d4: b.lt            #0x814680
    // 0x8145d8: r2 = 4294967295
    //     0x8145d8: add             x2, PP, #0x12, lsl #12  ; [pp+0x120e0] 0xffffffff
    //     0x8145dc: ldr             x2, [x2, #0xe0]
    // 0x8145e0: LoadField: r3 = r1->field_f
    //     0x8145e0: ldur            w3, [x1, #0xf]
    // 0x8145e4: DecompressPointer r3
    //     0x8145e4: add             x3, x3, HEAP, lsl #32
    // 0x8145e8: cmp             w3, w2
    // 0x8145ec: b.eq            #0x814628
    // 0x8145f0: and             w16, w3, w2
    // 0x8145f4: branchIfSmi(r16, 0x814680)
    //     0x8145f4: tbz             w16, #0, #0x814680
    // 0x8145f8: r16 = LoadClassIdInstr(r3)
    //     0x8145f8: ldur            x16, [x3, #-1]
    //     0x8145fc: ubfx            x16, x16, #0xc, #0x14
    // 0x814600: cmp             x16, #0x3c
    // 0x814604: b.ne            #0x814680
    // 0x814608: r16 = LoadClassIdInstr(r2)
    //     0x814608: ldur            x16, [x2, #-1]
    //     0x81460c: ubfx            x16, x16, #0xc, #0x14
    // 0x814610: cmp             x16, #0x3c
    // 0x814614: b.ne            #0x814680
    // 0x814618: LoadField: r16 = r3->field_7
    //     0x814618: ldur            x16, [x3, #7]
    // 0x81461c: LoadField: r17 = r2->field_7
    //     0x81461c: ldur            x17, [x2, #7]
    // 0x814620: cmp             x16, x17
    // 0x814624: b.ne            #0x814680
    // 0x814628: ldur            x16, [fp, #-0x20]
    // 0x81462c: SaveReg r16
    //     0x81462c: str             x16, [SP, #-8]!
    // 0x814630: r0 = readUint64()
    //     0x814630: bl              #0x8178d8  ; [package:archive/src/util/input_stream.dart] InputStream::readUint64
    // 0x814634: add             SP, SP, #8
    // 0x814638: mov             x2, x0
    // 0x81463c: r0 = BoxInt64Instr(r2)
    //     0x81463c: sbfiz           x0, x2, #1, #0x1f
    //     0x814640: cmp             x2, x0, asr #1
    //     0x814644: b.eq            #0x814650
    //     0x814648: bl              #0xd69bb8
    //     0x81464c: stur            x2, [x0, #7]
    // 0x814650: ldr             x1, [fp, #0x20]
    // 0x814654: StoreField: r1->field_f = r0
    //     0x814654: stur            w0, [x1, #0xf]
    //     0x814658: tbz             w0, #0, #0x814674
    //     0x81465c: ldurb           w16, [x1, #-1]
    //     0x814660: ldurb           w17, [x0, #-1]
    //     0x814664: and             x16, x17, x16, lsr #2
    //     0x814668: tst             x16, HEAP, lsr #32
    //     0x81466c: b.eq            #0x814674
    //     0x814670: bl              #0xd6826c
    // 0x814674: ldur            x0, [fp, #-8]
    // 0x814678: sub             x2, x0, #8
    // 0x81467c: mov             x0, x2
    // 0x814680: stur            x0, [fp, #-8]
    // 0x814684: cmp             x0, #8
    // 0x814688: b.lt            #0x814734
    // 0x81468c: r2 = 4294967295
    //     0x81468c: add             x2, PP, #0x12, lsl #12  ; [pp+0x120e0] 0xffffffff
    //     0x814690: ldr             x2, [x2, #0xe0]
    // 0x814694: LoadField: r3 = r1->field_1f
    //     0x814694: ldur            w3, [x1, #0x1f]
    // 0x814698: DecompressPointer r3
    //     0x814698: add             x3, x3, HEAP, lsl #32
    // 0x81469c: cmp             w3, w2
    // 0x8146a0: b.eq            #0x8146dc
    // 0x8146a4: and             w16, w3, w2
    // 0x8146a8: branchIfSmi(r16, 0x814734)
    //     0x8146a8: tbz             w16, #0, #0x814734
    // 0x8146ac: r16 = LoadClassIdInstr(r3)
    //     0x8146ac: ldur            x16, [x3, #-1]
    //     0x8146b0: ubfx            x16, x16, #0xc, #0x14
    // 0x8146b4: cmp             x16, #0x3c
    // 0x8146b8: b.ne            #0x814734
    // 0x8146bc: r16 = LoadClassIdInstr(r2)
    //     0x8146bc: ldur            x16, [x2, #-1]
    //     0x8146c0: ubfx            x16, x16, #0xc, #0x14
    // 0x8146c4: cmp             x16, #0x3c
    // 0x8146c8: b.ne            #0x814734
    // 0x8146cc: LoadField: r16 = r3->field_7
    //     0x8146cc: ldur            x16, [x3, #7]
    // 0x8146d0: LoadField: r17 = r2->field_7
    //     0x8146d0: ldur            x17, [x2, #7]
    // 0x8146d4: cmp             x16, x17
    // 0x8146d8: b.ne            #0x814734
    // 0x8146dc: ldur            x16, [fp, #-0x20]
    // 0x8146e0: SaveReg r16
    //     0x8146e0: str             x16, [SP, #-8]!
    // 0x8146e4: r0 = readUint64()
    //     0x8146e4: bl              #0x8178d8  ; [package:archive/src/util/input_stream.dart] InputStream::readUint64
    // 0x8146e8: add             SP, SP, #8
    // 0x8146ec: mov             x2, x0
    // 0x8146f0: r0 = BoxInt64Instr(r2)
    //     0x8146f0: sbfiz           x0, x2, #1, #0x1f
    //     0x8146f4: cmp             x2, x0, asr #1
    //     0x8146f8: b.eq            #0x814704
    //     0x8146fc: bl              #0xd69bb8
    //     0x814700: stur            x2, [x0, #7]
    // 0x814704: ldr             x1, [fp, #0x20]
    // 0x814708: StoreField: r1->field_1f = r0
    //     0x814708: stur            w0, [x1, #0x1f]
    //     0x81470c: tbz             w0, #0, #0x814728
    //     0x814710: ldurb           w16, [x1, #-1]
    //     0x814714: ldurb           w17, [x0, #-1]
    //     0x814718: and             x16, x17, x16, lsr #2
    //     0x81471c: tst             x16, HEAP, lsr #32
    //     0x814720: b.eq            #0x814728
    //     0x814724: bl              #0xd6826c
    // 0x814728: ldur            x0, [fp, #-8]
    // 0x81472c: sub             x2, x0, #8
    // 0x814730: mov             x0, x2
    // 0x814734: cmp             x0, #4
    // 0x814738: b.lt            #0x8147a4
    // 0x81473c: LoadField: r0 = r1->field_17
    //     0x81473c: ldur            w0, [x1, #0x17]
    // 0x814740: DecompressPointer r0
    //     0x814740: add             x0, x0, HEAP, lsl #32
    // 0x814744: r17 = 131070
    //     0x814744: mov             x17, #0x1fffe
    // 0x814748: cmp             w0, w17
    // 0x81474c: b.ne            #0x8147a4
    // 0x814750: ldur            x16, [fp, #-0x20]
    // 0x814754: SaveReg r16
    //     0x814754: str             x16, [SP, #-8]!
    // 0x814758: r0 = readUint32()
    //     0x814758: bl              #0x8183f0  ; [package:archive/src/util/input_stream.dart] InputStream::readUint32
    // 0x81475c: add             SP, SP, #8
    // 0x814760: mov             x2, x0
    // 0x814764: r0 = BoxInt64Instr(r2)
    //     0x814764: sbfiz           x0, x2, #1, #0x1f
    //     0x814768: cmp             x2, x0, asr #1
    //     0x81476c: b.eq            #0x814778
    //     0x814770: bl              #0xd69bb8
    //     0x814774: stur            x2, [x0, #7]
    // 0x814778: ldr             x1, [fp, #0x20]
    // 0x81477c: StoreField: r1->field_17 = r0
    //     0x81477c: stur            w0, [x1, #0x17]
    //     0x814780: tbz             w0, #0, #0x81479c
    //     0x814784: ldurb           w16, [x1, #-1]
    //     0x814788: ldurb           w17, [x0, #-1]
    //     0x81478c: and             x16, x17, x16, lsr #2
    //     0x814790: tst             x16, HEAP, lsr #32
    //     0x814794: b.eq            #0x81479c
    //     0x814798: bl              #0xd6826c
    // 0x81479c: b               #0x8147a4
    // 0x8147a0: ldr             x1, [fp, #0x20]
    // 0x8147a4: ldur            x0, [fp, #-0x18]
    // 0x8147a8: cmp             x0, #0
    // 0x8147ac: b.le            #0x8147c4
    // 0x8147b0: ldr             x16, [fp, #0x18]
    // 0x8147b4: stp             x0, x16, [SP, #-0x10]!
    // 0x8147b8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x8147b8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x8147bc: r0 = readString()
    //     0x8147bc: bl              #0x818198  ; [package:archive/src/util/input_stream.dart] InputStream::readString
    // 0x8147c0: add             SP, SP, #0x10
    // 0x8147c4: ldr             x0, [fp, #0x20]
    // 0x8147c8: ldr             x1, [fp, #0x10]
    // 0x8147cc: LoadField: r2 = r0->field_1f
    //     0x8147cc: ldur            w2, [x0, #0x1f]
    // 0x8147d0: DecompressPointer r2
    //     0x8147d0: add             x2, x2, HEAP, lsl #32
    // 0x8147d4: cmp             w2, NULL
    // 0x8147d8: b.eq            #0x814850
    // 0x8147dc: LoadField: r3 = r1->field_13
    //     0x8147dc: ldur            x3, [x1, #0x13]
    // 0x8147e0: r4 = LoadInt32Instr(r2)
    //     0x8147e0: sbfx            x4, x2, #1, #0x1f
    //     0x8147e4: tbz             w2, #0, #0x8147ec
    //     0x8147e8: ldur            x4, [x2, #7]
    // 0x8147ec: add             x2, x3, x4
    // 0x8147f0: StoreField: r1->field_b = r2
    //     0x8147f0: stur            x2, [x1, #0xb]
    // 0x8147f4: r0 = ZipFile()
    //     0x8147f4: bl              #0x8178cc  ; AllocateZipFileStub -> ZipFile (size=0x60)
    // 0x8147f8: stur            x0, [fp, #-0x20]
    // 0x8147fc: ldr             x16, [fp, #0x10]
    // 0x814800: stp             x16, x0, [SP, #-0x10]!
    // 0x814804: ldr             x16, [fp, #0x20]
    // 0x814808: SaveReg r16
    //     0x814808: str             x16, [SP, #-8]!
    // 0x81480c: r0 = ZipFile()
    //     0x81480c: bl              #0x814878  ; [package:archive/src/zip/zip_file.dart] ZipFile::ZipFile
    // 0x814810: add             SP, SP, #0x18
    // 0x814814: ldur            x0, [fp, #-0x20]
    // 0x814818: ldr             x1, [fp, #0x20]
    // 0x81481c: StoreField: r1->field_27 = r0
    //     0x81481c: stur            w0, [x1, #0x27]
    //     0x814820: ldurb           w16, [x1, #-1]
    //     0x814824: ldurb           w17, [x0, #-1]
    //     0x814828: and             x16, x17, x16, lsr #2
    //     0x81482c: tst             x16, HEAP, lsr #32
    //     0x814830: b.eq            #0x814838
    //     0x814834: bl              #0xd6826c
    // 0x814838: r0 = Null
    //     0x814838: mov             x0, NULL
    // 0x81483c: LeaveFrame
    //     0x81483c: mov             SP, fp
    //     0x814840: ldp             fp, lr, [SP], #0x10
    // 0x814844: ret
    //     0x814844: ret             
    // 0x814848: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x814848: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81484c: b               #0x8141e0
    // 0x814850: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x814850: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// lib: , url: package:archive/src/archive_file.dart

// class id: 1048596, size: 0x8
class :: {
}

// class id: 5007, size: 0x2c, field offset: 0x8
class ArchiveFile extends Object {

  _ decompress(/* No info */) {
    // ** addr: 0x7f56a0, size: 0xd4
    // 0x7f56a0: EnterFrame
    //     0x7f56a0: stp             fp, lr, [SP, #-0x10]!
    //     0x7f56a4: mov             fp, SP
    // 0x7f56a8: CheckStackOverflow
    //     0x7f56a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7f56ac: cmp             SP, x16
    //     0x7f56b0: b.ls            #0x7f576c
    // 0x7f56b4: ldr             x0, [fp, #0x10]
    // 0x7f56b8: LoadField: r1 = r0->field_27
    //     0x7f56b8: ldur            w1, [x0, #0x27]
    // 0x7f56bc: DecompressPointer r1
    //     0x7f56bc: add             x1, x1, HEAP, lsl #32
    // 0x7f56c0: cmp             w1, NULL
    // 0x7f56c4: b.ne            #0x7f575c
    // 0x7f56c8: LoadField: r1 = r0->field_23
    //     0x7f56c8: ldur            w1, [x0, #0x23]
    // 0x7f56cc: DecompressPointer r1
    //     0x7f56cc: add             x1, x1, HEAP, lsl #32
    // 0x7f56d0: cmp             w1, NULL
    // 0x7f56d4: b.eq            #0x7f575c
    // 0x7f56d8: LoadField: r2 = r0->field_1b
    //     0x7f56d8: ldur            x2, [x0, #0x1b]
    // 0x7f56dc: cmp             x2, #8
    // 0x7f56e0: b.ne            #0x7f5724
    // 0x7f56e4: SaveReg r1
    //     0x7f56e4: str             x1, [SP, #-8]!
    // 0x7f56e8: r0 = toUint8List()
    //     0x7f56e8: bl              #0x7f57d4  ; [package:archive/src/util/input_stream.dart] InputStream::toUint8List
    // 0x7f56ec: add             SP, SP, #8
    // 0x7f56f0: SaveReg r0
    //     0x7f56f0: str             x0, [SP, #-8]!
    // 0x7f56f4: r0 = inflateBuffer_()
    //     0x7f56f4: bl              #0x7f5774  ; [package:archive/src/zlib/_inflate_buffer_io.dart] ::inflateBuffer_
    // 0x7f56f8: add             SP, SP, #8
    // 0x7f56fc: ldr             x2, [fp, #0x10]
    // 0x7f5700: StoreField: r2->field_27 = r0
    //     0x7f5700: stur            w0, [x2, #0x27]
    //     0x7f5704: ldurb           w16, [x2, #-1]
    //     0x7f5708: ldurb           w17, [x0, #-1]
    //     0x7f570c: and             x16, x17, x16, lsr #2
    //     0x7f5710: tst             x16, HEAP, lsr #32
    //     0x7f5714: b.eq            #0x7f571c
    //     0x7f5718: bl              #0xd6828c
    // 0x7f571c: mov             x1, x2
    // 0x7f5720: b               #0x7f5754
    // 0x7f5724: mov             x2, x0
    // 0x7f5728: SaveReg r1
    //     0x7f5728: str             x1, [SP, #-8]!
    // 0x7f572c: r0 = toUint8List()
    //     0x7f572c: bl              #0x7f57d4  ; [package:archive/src/util/input_stream.dart] InputStream::toUint8List
    // 0x7f5730: add             SP, SP, #8
    // 0x7f5734: ldr             x1, [fp, #0x10]
    // 0x7f5738: StoreField: r1->field_27 = r0
    //     0x7f5738: stur            w0, [x1, #0x27]
    //     0x7f573c: ldurb           w16, [x1, #-1]
    //     0x7f5740: ldurb           w17, [x0, #-1]
    //     0x7f5744: and             x16, x17, x16, lsr #2
    //     0x7f5748: tst             x16, HEAP, lsr #32
    //     0x7f574c: b.eq            #0x7f5754
    //     0x7f5750: bl              #0xd6826c
    // 0x7f5754: r2 = 0
    //     0x7f5754: mov             x2, #0
    // 0x7f5758: StoreField: r1->field_1b = r2
    //     0x7f5758: stur            x2, [x1, #0x1b]
    // 0x7f575c: r0 = Null
    //     0x7f575c: mov             x0, NULL
    // 0x7f5760: LeaveFrame
    //     0x7f5760: mov             SP, fp
    //     0x7f5764: ldp             fp, lr, [SP], #0x10
    // 0x7f5768: ret
    //     0x7f5768: ret             
    // 0x7f576c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f576c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f5770: b               #0x7f56b4
  }
  get _ content(/* No info */) {
    // ** addr: 0x8135c4, size: 0xcc
    // 0x8135c4: EnterFrame
    //     0x8135c4: stp             fp, lr, [SP, #-0x10]!
    //     0x8135c8: mov             fp, SP
    // 0x8135cc: CheckStackOverflow
    //     0x8135cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8135d0: cmp             SP, x16
    //     0x8135d4: b.ls            #0x813688
    // 0x8135d8: ldr             x0, [fp, #0x10]
    // 0x8135dc: LoadField: r1 = r0->field_27
    //     0x8135dc: ldur            w1, [x0, #0x27]
    // 0x8135e0: DecompressPointer r1
    //     0x8135e0: add             x1, x1, HEAP, lsl #32
    // 0x8135e4: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0x8135e4: mov             x2, #0x76
    //     0x8135e8: tbz             w1, #0, #0x8135f8
    //     0x8135ec: ldur            x2, [x1, #-1]
    //     0x8135f0: ubfx            x2, x2, #0xc, #0x14
    //     0x8135f4: lsl             x2, x2, #1
    // 0x8135f8: r17 = 10012
    //     0x8135f8: mov             x17, #0x271c
    // 0x8135fc: cmp             w2, w17
    // 0x813600: b.ne            #0x813654
    // 0x813604: SaveReg r1
    //     0x813604: str             x1, [SP, #-8]!
    // 0x813608: r4 = 0
    //     0x813608: mov             x4, #0
    // 0x81360c: ldr             x0, [SP]
    // 0x813610: r16 = UnlinkedCall_0x4aeefc
    //     0x813610: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a958] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x813614: add             x16, x16, #0x958
    // 0x813618: ldp             x5, lr, [x16]
    // 0x81361c: blr             lr
    // 0x813620: add             SP, SP, #8
    // 0x813624: mov             x1, x0
    // 0x813628: ldr             x2, [fp, #0x10]
    // 0x81362c: StoreField: r2->field_27 = r0
    //     0x81362c: stur            w0, [x2, #0x27]
    //     0x813630: tbz             w0, #0, #0x81364c
    //     0x813634: ldurb           w16, [x2, #-1]
    //     0x813638: ldurb           w17, [x0, #-1]
    //     0x81363c: and             x16, x17, x16, lsr #2
    //     0x813640: tst             x16, HEAP, lsr #32
    //     0x813644: b.eq            #0x81364c
    //     0x813648: bl              #0xd6828c
    // 0x81364c: mov             x0, x1
    // 0x813650: b               #0x81365c
    // 0x813654: mov             x2, x0
    // 0x813658: mov             x0, x1
    // 0x81365c: cmp             w0, NULL
    // 0x813660: b.ne            #0x813670
    // 0x813664: SaveReg r2
    //     0x813664: str             x2, [SP, #-8]!
    // 0x813668: r0 = decompress()
    //     0x813668: bl              #0x7f56a0  ; [package:archive/src/archive_file.dart] ArchiveFile::decompress
    // 0x81366c: add             SP, SP, #8
    // 0x813670: ldr             x1, [fp, #0x10]
    // 0x813674: LoadField: r0 = r1->field_27
    //     0x813674: ldur            w0, [x1, #0x27]
    // 0x813678: DecompressPointer r0
    //     0x813678: add             x0, x0, HEAP, lsl #32
    // 0x81367c: LeaveFrame
    //     0x81367c: mov             SP, fp
    //     0x813680: ldp             fp, lr, [SP], #0x10
    // 0x813684: ret
    //     0x813684: ret             
    // 0x813688: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x813688: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81368c: b               #0x8135d8
  }
}

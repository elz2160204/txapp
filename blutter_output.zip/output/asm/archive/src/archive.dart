// lib: , url: package:archive/src/archive.dart

// class id: 1048595, size: 0x8
class :: {
}

// class id: 6116, size: 0x14, field offset: 0xc
class Archive extends IterableBase<ArchiveFile> {

  int length(Archive) {
    // ** addr: 0x7174d0, size: 0x30
    // 0x7174d0: ldr             x1, [SP]
    // 0x7174d4: LoadField: r2 = r1->field_b
    //     0x7174d4: ldur            w2, [x1, #0xb]
    // 0x7174d8: DecompressPointer r2
    //     0x7174d8: add             x2, x2, HEAP, lsl #32
    // 0x7174dc: LoadField: r0 = r2->field_b
    //     0x7174dc: ldur            w0, [x2, #0xb]
    // 0x7174e0: DecompressPointer r0
    //     0x7174e0: add             x0, x0, HEAP, lsl #32
    // 0x7174e4: ret
    //     0x7174e4: ret             
  }
  bool isEmpty(Archive) {
    // ** addr: 0x6bc248, size: 0x40
    // 0x6bc248: ldr             x1, [SP]
    // 0x6bc24c: LoadField: r2 = r1->field_b
    //     0x6bc24c: ldur            w2, [x1, #0xb]
    // 0x6bc250: DecompressPointer r2
    //     0x6bc250: add             x2, x2, HEAP, lsl #32
    // 0x6bc254: LoadField: r1 = r2->field_b
    //     0x6bc254: ldur            w1, [x2, #0xb]
    // 0x6bc258: DecompressPointer r1
    //     0x6bc258: add             x1, x1, HEAP, lsl #32
    // 0x6bc25c: cbz             w1, #0x6bc268
    // 0x6bc260: r0 = false
    //     0x6bc260: add             x0, NULL, #0x30  ; false
    // 0x6bc264: b               #0x6bc26c
    // 0x6bc268: r0 = true
    //     0x6bc268: add             x0, NULL, #0x20  ; true
    // 0x6bc26c: ret
    //     0x6bc26c: ret             
  }
  bool isNotEmpty(Archive) {
    // ** addr: 0x6bc968, size: 0x40
    // 0x6bc968: ldr             x1, [SP]
    // 0x6bc96c: LoadField: r2 = r1->field_b
    //     0x6bc96c: ldur            w2, [x1, #0xb]
    // 0x6bc970: DecompressPointer r2
    //     0x6bc970: add             x2, x2, HEAP, lsl #32
    // 0x6bc974: LoadField: r1 = r2->field_b
    //     0x6bc974: ldur            w1, [x2, #0xb]
    // 0x6bc978: DecompressPointer r1
    //     0x6bc978: add             x1, x1, HEAP, lsl #32
    // 0x6bc97c: cbnz            w1, #0x6bc988
    // 0x6bc980: r0 = false
    //     0x6bc980: add             x0, NULL, #0x30  ; false
    // 0x6bc984: b               #0x6bc98c
    // 0x6bc988: r0 = true
    //     0x6bc988: add             x0, NULL, #0x20  ; true
    // 0x6bc98c: ret
    //     0x6bc98c: ret             
  }
  _ addFile(/* No info */) {
    // ** addr: 0x813b44, size: 0x1d4
    // 0x813b44: EnterFrame
    //     0x813b44: stp             fp, lr, [SP, #-0x10]!
    //     0x813b48: mov             fp, SP
    // 0x813b4c: AllocStack(0x18)
    //     0x813b4c: sub             SP, SP, #0x18
    // 0x813b50: CheckStackOverflow
    //     0x813b50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x813b54: cmp             SP, x16
    //     0x813b58: b.ls            #0x813d08
    // 0x813b5c: ldr             x0, [fp, #0x18]
    // 0x813b60: LoadField: r1 = r0->field_f
    //     0x813b60: ldur            w1, [x0, #0xf]
    // 0x813b64: DecompressPointer r1
    //     0x813b64: add             x1, x1, HEAP, lsl #32
    // 0x813b68: ldr             x2, [fp, #0x10]
    // 0x813b6c: stur            x1, [fp, #-8]
    // 0x813b70: LoadField: r3 = r2->field_7
    //     0x813b70: ldur            w3, [x2, #7]
    // 0x813b74: DecompressPointer r3
    //     0x813b74: add             x3, x3, HEAP, lsl #32
    // 0x813b78: stp             x3, x1, [SP, #-0x10]!
    // 0x813b7c: r0 = _getValueOrData()
    //     0x813b7c: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x813b80: add             SP, SP, #0x10
    // 0x813b84: mov             x1, x0
    // 0x813b88: ldur            x0, [fp, #-8]
    // 0x813b8c: LoadField: r2 = r0->field_f
    //     0x813b8c: ldur            w2, [x0, #0xf]
    // 0x813b90: DecompressPointer r2
    //     0x813b90: add             x2, x2, HEAP, lsl #32
    // 0x813b94: cmp             w2, w1
    // 0x813b98: b.ne            #0x813ba0
    // 0x813b9c: r1 = Null
    //     0x813b9c: mov             x1, NULL
    // 0x813ba0: cmp             w1, NULL
    // 0x813ba4: b.eq            #0x813c20
    // 0x813ba8: ldr             x2, [fp, #0x18]
    // 0x813bac: LoadField: r3 = r2->field_b
    //     0x813bac: ldur            w3, [x2, #0xb]
    // 0x813bb0: DecompressPointer r3
    //     0x813bb0: add             x3, x3, HEAP, lsl #32
    // 0x813bb4: LoadField: r0 = r3->field_b
    //     0x813bb4: ldur            w0, [x3, #0xb]
    // 0x813bb8: DecompressPointer r0
    //     0x813bb8: add             x0, x0, HEAP, lsl #32
    // 0x813bbc: r2 = LoadInt32Instr(r1)
    //     0x813bbc: sbfx            x2, x1, #1, #0x1f
    //     0x813bc0: tbz             w1, #0, #0x813bc8
    //     0x813bc4: ldur            x2, [x1, #7]
    // 0x813bc8: r1 = LoadInt32Instr(r0)
    //     0x813bc8: sbfx            x1, x0, #1, #0x1f
    // 0x813bcc: mov             x0, x1
    // 0x813bd0: mov             x1, x2
    // 0x813bd4: cmp             x1, x0
    // 0x813bd8: b.hs            #0x813d10
    // 0x813bdc: LoadField: r1 = r3->field_f
    //     0x813bdc: ldur            w1, [x3, #0xf]
    // 0x813be0: DecompressPointer r1
    //     0x813be0: add             x1, x1, HEAP, lsl #32
    // 0x813be4: ldr             x0, [fp, #0x10]
    // 0x813be8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x813be8: add             x25, x1, x2, lsl #2
    //     0x813bec: add             x25, x25, #0xf
    //     0x813bf0: str             w0, [x25]
    //     0x813bf4: tbz             w0, #0, #0x813c10
    //     0x813bf8: ldurb           w16, [x1, #-1]
    //     0x813bfc: ldurb           w17, [x0, #-1]
    //     0x813c00: and             x16, x17, x16, lsr #2
    //     0x813c04: tst             x16, HEAP, lsr #32
    //     0x813c08: b.eq            #0x813c10
    //     0x813c0c: bl              #0xd67e5c
    // 0x813c10: r0 = Null
    //     0x813c10: mov             x0, NULL
    // 0x813c14: LeaveFrame
    //     0x813c14: mov             SP, fp
    //     0x813c18: ldp             fp, lr, [SP], #0x10
    // 0x813c1c: ret
    //     0x813c1c: ret             
    // 0x813c20: ldr             x2, [fp, #0x18]
    // 0x813c24: LoadField: r1 = r2->field_b
    //     0x813c24: ldur            w1, [x2, #0xb]
    // 0x813c28: DecompressPointer r1
    //     0x813c28: add             x1, x1, HEAP, lsl #32
    // 0x813c2c: stur            x1, [fp, #-0x18]
    // 0x813c30: LoadField: r3 = r1->field_b
    //     0x813c30: ldur            w3, [x1, #0xb]
    // 0x813c34: DecompressPointer r3
    //     0x813c34: add             x3, x3, HEAP, lsl #32
    // 0x813c38: stur            x3, [fp, #-0x10]
    // 0x813c3c: LoadField: r4 = r1->field_f
    //     0x813c3c: ldur            w4, [x1, #0xf]
    // 0x813c40: DecompressPointer r4
    //     0x813c40: add             x4, x4, HEAP, lsl #32
    // 0x813c44: LoadField: r5 = r4->field_b
    //     0x813c44: ldur            w5, [x4, #0xb]
    // 0x813c48: DecompressPointer r5
    //     0x813c48: add             x5, x5, HEAP, lsl #32
    // 0x813c4c: cmp             w3, w5
    // 0x813c50: b.ne            #0x813c60
    // 0x813c54: SaveReg r1
    //     0x813c54: str             x1, [SP, #-8]!
    // 0x813c58: r0 = _growToNextCapacity()
    //     0x813c58: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x813c5c: add             SP, SP, #8
    // 0x813c60: ldr             x2, [fp, #0x18]
    // 0x813c64: ldr             x4, [fp, #0x10]
    // 0x813c68: ldur            x3, [fp, #-0x18]
    // 0x813c6c: ldur            x0, [fp, #-0x10]
    // 0x813c70: r5 = LoadInt32Instr(r0)
    //     0x813c70: sbfx            x5, x0, #1, #0x1f
    // 0x813c74: add             x0, x5, #1
    // 0x813c78: lsl             x1, x0, #1
    // 0x813c7c: StoreField: r3->field_b = r1
    //     0x813c7c: stur            w1, [x3, #0xb]
    // 0x813c80: mov             x1, x5
    // 0x813c84: cmp             x1, x0
    // 0x813c88: b.hs            #0x813d14
    // 0x813c8c: LoadField: r1 = r3->field_f
    //     0x813c8c: ldur            w1, [x3, #0xf]
    // 0x813c90: DecompressPointer r1
    //     0x813c90: add             x1, x1, HEAP, lsl #32
    // 0x813c94: mov             x0, x4
    // 0x813c98: ArrayStore: r1[r5] = r0  ; List_4
    //     0x813c98: add             x25, x1, x5, lsl #2
    //     0x813c9c: add             x25, x25, #0xf
    //     0x813ca0: str             w0, [x25]
    //     0x813ca4: tbz             w0, #0, #0x813cc0
    //     0x813ca8: ldurb           w16, [x1, #-1]
    //     0x813cac: ldurb           w17, [x0, #-1]
    //     0x813cb0: and             x16, x17, x16, lsr #2
    //     0x813cb4: tst             x16, HEAP, lsr #32
    //     0x813cb8: b.eq            #0x813cc0
    //     0x813cbc: bl              #0xd67e5c
    // 0x813cc0: LoadField: r0 = r4->field_7
    //     0x813cc0: ldur            w0, [x4, #7]
    // 0x813cc4: DecompressPointer r0
    //     0x813cc4: add             x0, x0, HEAP, lsl #32
    // 0x813cc8: LoadField: r1 = r2->field_b
    //     0x813cc8: ldur            w1, [x2, #0xb]
    // 0x813ccc: DecompressPointer r1
    //     0x813ccc: add             x1, x1, HEAP, lsl #32
    // 0x813cd0: LoadField: r2 = r1->field_b
    //     0x813cd0: ldur            w2, [x1, #0xb]
    // 0x813cd4: DecompressPointer r2
    //     0x813cd4: add             x2, x2, HEAP, lsl #32
    // 0x813cd8: r1 = LoadInt32Instr(r2)
    //     0x813cd8: sbfx            x1, x2, #1, #0x1f
    // 0x813cdc: sub             x2, x1, #1
    // 0x813ce0: lsl             x1, x2, #1
    // 0x813ce4: ldur            x16, [fp, #-8]
    // 0x813ce8: stp             x0, x16, [SP, #-0x10]!
    // 0x813cec: SaveReg r1
    //     0x813cec: str             x1, [SP, #-8]!
    // 0x813cf0: r0 = []=()
    //     0x813cf0: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x813cf4: add             SP, SP, #0x18
    // 0x813cf8: r0 = Null
    //     0x813cf8: mov             x0, NULL
    // 0x813cfc: LeaveFrame
    //     0x813cfc: mov             SP, fp
    //     0x813d00: ldp             fp, lr, [SP], #0x10
    // 0x813d04: ret
    //     0x813d04: ret             
    // 0x813d08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x813d08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x813d0c: b               #0x813b5c
    // 0x813d10: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x813d10: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x813d14: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x813d14: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  ArchiveFile [](Archive, int) {
    // ** addr: 0x813d30, size: 0xac
    // 0x813d30: EnterFrame
    //     0x813d30: stp             fp, lr, [SP, #-0x10]!
    //     0x813d34: mov             fp, SP
    // 0x813d38: ldr             x0, [fp, #0x10]
    // 0x813d3c: r2 = Null
    //     0x813d3c: mov             x2, NULL
    // 0x813d40: r1 = Null
    //     0x813d40: mov             x1, NULL
    // 0x813d44: branchIfSmi(r0, 0x813d6c)
    //     0x813d44: tbz             w0, #0, #0x813d6c
    // 0x813d48: r4 = LoadClassIdInstr(r0)
    //     0x813d48: ldur            x4, [x0, #-1]
    //     0x813d4c: ubfx            x4, x4, #0xc, #0x14
    // 0x813d50: sub             x4, x4, #0x3b
    // 0x813d54: cmp             x4, #1
    // 0x813d58: b.ls            #0x813d6c
    // 0x813d5c: r8 = int
    //     0x813d5c: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0x813d60: r3 = Null
    //     0x813d60: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4cc00] Null
    //     0x813d64: ldr             x3, [x3, #0xc00]
    // 0x813d68: r0 = int()
    //     0x813d68: bl              #0xd73714  ; IsType_int_Stub
    // 0x813d6c: ldr             x2, [fp, #0x18]
    // 0x813d70: LoadField: r3 = r2->field_b
    //     0x813d70: ldur            w3, [x2, #0xb]
    // 0x813d74: DecompressPointer r3
    //     0x813d74: add             x3, x3, HEAP, lsl #32
    // 0x813d78: LoadField: r2 = r3->field_b
    //     0x813d78: ldur            w2, [x3, #0xb]
    // 0x813d7c: DecompressPointer r2
    //     0x813d7c: add             x2, x2, HEAP, lsl #32
    // 0x813d80: ldr             x4, [fp, #0x10]
    // 0x813d84: r5 = LoadInt32Instr(r4)
    //     0x813d84: sbfx            x5, x4, #1, #0x1f
    //     0x813d88: tbz             w4, #0, #0x813d90
    //     0x813d8c: ldur            x5, [x4, #7]
    // 0x813d90: r0 = LoadInt32Instr(r2)
    //     0x813d90: sbfx            x0, x2, #1, #0x1f
    // 0x813d94: mov             x1, x5
    // 0x813d98: cmp             x1, x0
    // 0x813d9c: b.hs            #0x813dc0
    // 0x813da0: LoadField: r1 = r3->field_f
    //     0x813da0: ldur            w1, [x3, #0xf]
    // 0x813da4: DecompressPointer r1
    //     0x813da4: add             x1, x1, HEAP, lsl #32
    // 0x813da8: ArrayLoad: r0 = r1[r5]  ; Unknown_4
    //     0x813da8: add             x16, x1, x5, lsl #2
    //     0x813dac: ldur            w0, [x16, #0xf]
    // 0x813db0: DecompressPointer r0
    //     0x813db0: add             x0, x0, HEAP, lsl #32
    // 0x813db4: LeaveFrame
    //     0x813db4: mov             SP, fp
    //     0x813db8: ldp             fp, lr, [SP], #0x10
    // 0x813dbc: ret
    //     0x813dbc: ret             
    // 0x813dc0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x813dc0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ Archive(/* No info */) {
    // ** addr: 0x813dd0, size: 0x98
    // 0x813dd0: EnterFrame
    //     0x813dd0: stp             fp, lr, [SP, #-0x10]!
    //     0x813dd4: mov             fp, SP
    // 0x813dd8: CheckStackOverflow
    //     0x813dd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x813ddc: cmp             SP, x16
    //     0x813de0: b.ls            #0x813e60
    // 0x813de4: r16 = <ArchiveFile>
    //     0x813de4: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a968] TypeArguments: <ArchiveFile>
    //     0x813de8: ldr             x16, [x16, #0x968]
    // 0x813dec: stp             xzr, x16, [SP, #-0x10]!
    // 0x813df0: r0 = _GrowableList()
    //     0x813df0: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x813df4: add             SP, SP, #0x10
    // 0x813df8: ldr             x1, [fp, #0x10]
    // 0x813dfc: StoreField: r1->field_b = r0
    //     0x813dfc: stur            w0, [x1, #0xb]
    //     0x813e00: ldurb           w16, [x1, #-1]
    //     0x813e04: ldurb           w17, [x0, #-1]
    //     0x813e08: and             x16, x17, x16, lsr #2
    //     0x813e0c: tst             x16, HEAP, lsr #32
    //     0x813e10: b.eq            #0x813e18
    //     0x813e14: bl              #0xd6826c
    // 0x813e18: r16 = <String, int>
    //     0x813e18: ldr             x16, [PP, #0x7b0]  ; [pp+0x7b0] TypeArguments: <String, int>
    // 0x813e1c: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x813e20: stp             lr, x16, [SP, #-0x10]!
    // 0x813e24: r0 = Map._fromLiteral()
    //     0x813e24: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x813e28: add             SP, SP, #0x10
    // 0x813e2c: ldr             x1, [fp, #0x10]
    // 0x813e30: StoreField: r1->field_f = r0
    //     0x813e30: stur            w0, [x1, #0xf]
    //     0x813e34: tbz             w0, #0, #0x813e50
    //     0x813e38: ldurb           w16, [x1, #-1]
    //     0x813e3c: ldurb           w17, [x0, #-1]
    //     0x813e40: and             x16, x17, x16, lsr #2
    //     0x813e44: tst             x16, HEAP, lsr #32
    //     0x813e48: b.eq            #0x813e50
    //     0x813e4c: bl              #0xd6826c
    // 0x813e50: r0 = Null
    //     0x813e50: mov             x0, NULL
    // 0x813e54: LeaveFrame
    //     0x813e54: mov             SP, fp
    //     0x813e58: ldp             fp, lr, [SP], #0x10
    // 0x813e5c: ret
    //     0x813e5c: ret             
    // 0x813e60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x813e60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x813e64: b               #0x813de4
  }
}

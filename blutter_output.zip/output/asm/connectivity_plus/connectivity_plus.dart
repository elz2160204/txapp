// lib: , url: package:connectivity_plus/connectivity_plus.dart

// class id: 1048786, size: 0x8
class :: {
}

// class id: 4763, size: 0x8, field offset: 0x8
class Connectivity extends Object {

  get _ onConnectivityChanged(/* No info */) {
    // ** addr: 0x9fc488, size: 0x1ec
    // 0x9fc488: EnterFrame
    //     0x9fc488: stp             fp, lr, [SP, #-0x10]!
    //     0x9fc48c: mov             fp, SP
    // 0x9fc490: AllocStack(0x18)
    //     0x9fc490: sub             SP, SP, #0x18
    // 0x9fc494: CheckStackOverflow
    //     0x9fc494: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fc498: cmp             SP, x16
    //     0x9fc49c: b.ls            #0x9fc668
    // 0x9fc4a0: r0 = InitLateStaticField(0xb10) // [package:connectivity_plus_platform_interface/connectivity_plus_platform_interface.dart] ConnectivityPlatform::_instance
    //     0x9fc4a0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9fc4a4: ldr             x0, [x0, #0x1620]
    //     0x9fc4a8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9fc4ac: cmp             w0, w16
    //     0x9fc4b0: b.ne            #0x9fc4c0
    //     0x9fc4b4: add             x2, PP, #0x21, lsl #12  ; [pp+0x21010] Field <ConnectivityPlatform._instance@257483631>: static late (offset: 0xb10)
    //     0x9fc4b8: ldr             x2, [x2, #0x10]
    //     0x9fc4bc: bl              #0xd67d44
    // 0x9fc4c0: stur            x0, [fp, #-8]
    // 0x9fc4c4: r1 = LoadClassIdInstr(r0)
    //     0x9fc4c4: ldur            x1, [x0, #-1]
    //     0x9fc4c8: ubfx            x1, x1, #0xc, #0x14
    // 0x9fc4cc: lsl             x1, x1, #1
    // 0x9fc4d0: r17 = 9908
    //     0x9fc4d0: mov             x17, #0x26b4
    // 0x9fc4d4: cmp             w1, w17
    // 0x9fc4d8: b.ne            #0x9fc584
    // 0x9fc4dc: LoadField: r1 = r0->field_b
    //     0x9fc4dc: ldur            w1, [x0, #0xb]
    // 0x9fc4e0: DecompressPointer r1
    //     0x9fc4e0: add             x1, x1, HEAP, lsl #32
    // 0x9fc4e4: cmp             w1, NULL
    // 0x9fc4e8: b.ne            #0x9fc57c
    // 0x9fc4ec: r16 = Instance_EventChannel
    //     0x9fc4ec: ldr             x16, [PP, #0x358]  ; [pp+0x358] Obj!EventChannel@b34a51
    // 0x9fc4f0: SaveReg r16
    //     0x9fc4f0: str             x16, [SP, #-8]!
    // 0x9fc4f4: r0 = receiveBroadcastStream()
    //     0x9fc4f4: bl              #0x5a24c0  ; [package:flutter/src/services/platform_channel.dart] EventChannel::receiveBroadcastStream
    // 0x9fc4f8: add             SP, SP, #8
    // 0x9fc4fc: r1 = Function '<anonymous closure>':.
    //     0x9fc4fc: add             x1, PP, #0x21, lsl #12  ; [pp+0x21018] Function: [dart:core] ::_objectToString (0x5993e8)
    //     0x9fc500: ldr             x1, [x1, #0x18]
    // 0x9fc504: r2 = Null
    //     0x9fc504: mov             x2, NULL
    // 0x9fc508: stur            x0, [fp, #-0x10]
    // 0x9fc50c: r0 = AllocateClosure()
    //     0x9fc50c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9fc510: r16 = <String>
    //     0x9fc510: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x9fc514: ldur            lr, [fp, #-0x10]
    // 0x9fc518: stp             lr, x16, [SP, #-0x10]!
    // 0x9fc51c: SaveReg r0
    //     0x9fc51c: str             x0, [SP, #-8]!
    // 0x9fc520: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9fc520: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9fc524: r0 = map()
    //     0x9fc524: bl              #0x5b31c8  ; [dart:async] Stream::map
    // 0x9fc528: add             SP, SP, #0x18
    // 0x9fc52c: r16 = <ConnectivityResult>
    //     0x9fc52c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21020] TypeArguments: <ConnectivityResult>
    //     0x9fc530: ldr             x16, [x16, #0x20]
    // 0x9fc534: stp             x0, x16, [SP, #-0x10]!
    // 0x9fc538: r16 = Closure: (String) => ConnectivityResult from Function 'parseConnectivityResult': static.
    //     0x9fc538: add             x16, PP, #0x21, lsl #12  ; [pp+0x21028] Closure: (String) => ConnectivityResult from Function 'parseConnectivityResult': static. (0x7fe6e220fa74)
    //     0x9fc53c: ldr             x16, [x16, #0x28]
    // 0x9fc540: SaveReg r16
    //     0x9fc540: str             x16, [SP, #-8]!
    // 0x9fc544: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9fc544: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9fc548: r0 = map()
    //     0x9fc548: bl              #0x5b31c8  ; [dart:async] Stream::map
    // 0x9fc54c: add             SP, SP, #0x18
    // 0x9fc550: mov             x2, x0
    // 0x9fc554: ldur            x1, [fp, #-8]
    // 0x9fc558: StoreField: r1->field_b = r0
    //     0x9fc558: stur            w0, [x1, #0xb]
    //     0x9fc55c: ldurb           w16, [x1, #-1]
    //     0x9fc560: ldurb           w17, [x0, #-1]
    //     0x9fc564: and             x16, x17, x16, lsr #2
    //     0x9fc568: tst             x16, HEAP, lsr #32
    //     0x9fc56c: b.eq            #0x9fc574
    //     0x9fc570: bl              #0xd6826c
    // 0x9fc574: mov             x0, x2
    // 0x9fc578: b               #0x9fc65c
    // 0x9fc57c: mov             x0, x1
    // 0x9fc580: b               #0x9fc65c
    // 0x9fc584: mov             x1, x0
    // 0x9fc588: LoadField: r0 = r1->field_b
    //     0x9fc588: ldur            w0, [x1, #0xb]
    // 0x9fc58c: DecompressPointer r0
    //     0x9fc58c: add             x0, x0, HEAP, lsl #32
    // 0x9fc590: cmp             w0, NULL
    // 0x9fc594: b.ne            #0x9fc63c
    // 0x9fc598: r1 = 1
    //     0x9fc598: mov             x1, #1
    // 0x9fc59c: r0 = AllocateContext()
    //     0x9fc59c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9fc5a0: mov             x1, x0
    // 0x9fc5a4: ldur            x0, [fp, #-8]
    // 0x9fc5a8: stur            x1, [fp, #-0x10]
    // 0x9fc5ac: StoreField: r1->field_f = r0
    //     0x9fc5ac: stur            w0, [x1, #0xf]
    // 0x9fc5b0: r1 = 1
    //     0x9fc5b0: mov             x1, #1
    // 0x9fc5b4: r0 = AllocateContext()
    //     0x9fc5b4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9fc5b8: mov             x3, x0
    // 0x9fc5bc: ldur            x0, [fp, #-8]
    // 0x9fc5c0: stur            x3, [fp, #-0x18]
    // 0x9fc5c4: StoreField: r3->field_f = r0
    //     0x9fc5c4: stur            w0, [x3, #0xf]
    // 0x9fc5c8: ldur            x2, [fp, #-0x10]
    // 0x9fc5cc: r1 = Function '_startListenConnectivity@258502950':.
    //     0x9fc5cc: add             x1, PP, #0x21, lsl #12  ; [pp+0x21030] AnonymousClosure: (0x9fc8f0), in [package:connectivity_plus/src/connectivity_plus_linux.dart] ConnectivityPlusLinuxPlugin::_startListenConnectivity (0x9fc938)
    //     0x9fc5d0: ldr             x1, [x1, #0x30]
    // 0x9fc5d4: r0 = AllocateClosure()
    //     0x9fc5d4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9fc5d8: ldur            x2, [fp, #-0x18]
    // 0x9fc5dc: r1 = Function '_stopListenConnectivity@258502950':.
    //     0x9fc5dc: add             x1, PP, #0x21, lsl #12  ; [pp+0x21038] AnonymousClosure: (0x9fc674), in [package:connectivity_plus/src/connectivity_plus_linux.dart] ConnectivityPlusLinuxPlugin::_stopListenConnectivity (0x9fc6bc)
    //     0x9fc5e0: ldr             x1, [x1, #0x38]
    // 0x9fc5e4: stur            x0, [fp, #-0x10]
    // 0x9fc5e8: r0 = AllocateClosure()
    //     0x9fc5e8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9fc5ec: r16 = <ConnectivityResult>
    //     0x9fc5ec: add             x16, PP, #0x21, lsl #12  ; [pp+0x21020] TypeArguments: <ConnectivityResult>
    //     0x9fc5f0: ldr             x16, [x16, #0x20]
    // 0x9fc5f4: ldur            lr, [fp, #-0x10]
    // 0x9fc5f8: stp             lr, x16, [SP, #-0x10]!
    // 0x9fc5fc: SaveReg r0
    //     0x9fc5fc: str             x0, [SP, #-8]!
    // 0x9fc600: r4 = const [0, 0x3, 0x3, 0x1, onCancel, 0x2, onListen, 0x1, null]
    //     0x9fc600: add             x4, PP, #0x21, lsl #12  ; [pp+0x21040] List(9) [0, 0x3, 0x3, 0x1, "onCancel", 0x2, "onListen", 0x1, Null]
    //     0x9fc604: ldr             x4, [x4, #0x40]
    // 0x9fc608: r0 = StreamController.broadcast()
    //     0x9fc608: bl              #0x5a25d4  ; [dart:async] StreamController::StreamController.broadcast
    // 0x9fc60c: add             SP, SP, #0x18
    // 0x9fc610: mov             x2, x0
    // 0x9fc614: ldur            x1, [fp, #-8]
    // 0x9fc618: StoreField: r1->field_b = r0
    //     0x9fc618: stur            w0, [x1, #0xb]
    //     0x9fc61c: tbz             w0, #0, #0x9fc638
    //     0x9fc620: ldurb           w16, [x1, #-1]
    //     0x9fc624: ldurb           w17, [x0, #-1]
    //     0x9fc628: and             x16, x17, x16, lsr #2
    //     0x9fc62c: tst             x16, HEAP, lsr #32
    //     0x9fc630: b.eq            #0x9fc638
    //     0x9fc634: bl              #0xd6826c
    // 0x9fc638: mov             x0, x2
    // 0x9fc63c: stur            x0, [fp, #-8]
    // 0x9fc640: cmp             w0, NULL
    // 0x9fc644: b.eq            #0x9fc670
    // 0x9fc648: LoadField: r1 = r0->field_7
    //     0x9fc648: ldur            w1, [x0, #7]
    // 0x9fc64c: DecompressPointer r1
    //     0x9fc64c: add             x1, x1, HEAP, lsl #32
    // 0x9fc650: r0 = _BroadcastStream()
    //     0x9fc650: bl              #0x5a25c8  ; Allocate_BroadcastStreamStub -> _BroadcastStream<X0> (size=0x14)
    // 0x9fc654: ldur            x1, [fp, #-8]
    // 0x9fc658: StoreField: r0->field_f = r1
    //     0x9fc658: stur            w1, [x0, #0xf]
    // 0x9fc65c: LeaveFrame
    //     0x9fc65c: mov             SP, fp
    //     0x9fc660: ldp             fp, lr, [SP], #0x10
    // 0x9fc664: ret
    //     0x9fc664: ret             
    // 0x9fc668: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fc668: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fc66c: b               #0x9fc4a0
    // 0x9fc670: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9fc670: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  factory _ Connectivity(/* No info */) {
    // ** addr: 0xa0fca0, size: 0x30
    // 0xa0fca0: EnterFrame
    //     0xa0fca0: stp             fp, lr, [SP, #-0x10]!
    //     0xa0fca4: mov             fp, SP
    // 0xa0fca8: r0 = LoadStaticField(0xa78)
    //     0xa0fca8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa0fcac: ldr             x0, [x0, #0x14f0]
    // 0xa0fcb0: cmp             w0, NULL
    // 0xa0fcb4: b.ne            #0xa0fcc4
    // 0xa0fcb8: r0 = Connectivity()
    //     0xa0fcb8: bl              #0xa0fcd0  ; AllocateConnectivityStub -> Connectivity (size=0x8)
    // 0xa0fcbc: StoreStaticField(0xa78, r0)
    //     0xa0fcbc: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0xa0fcc0: str             x0, [x1, #0x14f0]
    // 0xa0fcc4: LeaveFrame
    //     0xa0fcc4: mov             SP, fp
    //     0xa0fcc8: ldp             fp, lr, [SP], #0x10
    // 0xa0fccc: ret
    //     0xa0fccc: ret             
  }
}

// lib: , url: package:connectivity_plus/src/connectivity_plus_linux.dart

// class id: 1048787, size: 0x8
class :: {
}

// class id: 4955, size: 0x14, field offset: 0x8
class ConnectivityPlusLinuxPlugin extends ConnectivityPlatform {

  [closure] Future<void> _stopListenConnectivity(dynamic) {
    // ** addr: 0x9fc674, size: 0x48
    // 0x9fc674: EnterFrame
    //     0x9fc674: stp             fp, lr, [SP, #-0x10]!
    //     0x9fc678: mov             fp, SP
    // 0x9fc67c: ldr             x0, [fp, #0x10]
    // 0x9fc680: LoadField: r1 = r0->field_17
    //     0x9fc680: ldur            w1, [x0, #0x17]
    // 0x9fc684: DecompressPointer r1
    //     0x9fc684: add             x1, x1, HEAP, lsl #32
    // 0x9fc688: CheckStackOverflow
    //     0x9fc688: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fc68c: cmp             SP, x16
    //     0x9fc690: b.ls            #0x9fc6b4
    // 0x9fc694: LoadField: r0 = r1->field_f
    //     0x9fc694: ldur            w0, [x1, #0xf]
    // 0x9fc698: DecompressPointer r0
    //     0x9fc698: add             x0, x0, HEAP, lsl #32
    // 0x9fc69c: SaveReg r0
    //     0x9fc69c: str             x0, [SP, #-8]!
    // 0x9fc6a0: r0 = _stopListenConnectivity()
    //     0x9fc6a0: bl              #0x9fc6bc  ; [package:connectivity_plus/src/connectivity_plus_linux.dart] ConnectivityPlusLinuxPlugin::_stopListenConnectivity
    // 0x9fc6a4: add             SP, SP, #8
    // 0x9fc6a8: LeaveFrame
    //     0x9fc6a8: mov             SP, fp
    //     0x9fc6ac: ldp             fp, lr, [SP], #0x10
    // 0x9fc6b0: ret
    //     0x9fc6b0: ret             
    // 0x9fc6b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fc6b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fc6b8: b               #0x9fc694
  }
  _ _stopListenConnectivity(/* No info */) async {
    // ** addr: 0x9fc6bc, size: 0x8c
    // 0x9fc6bc: EnterFrame
    //     0x9fc6bc: stp             fp, lr, [SP, #-0x10]!
    //     0x9fc6c0: mov             fp, SP
    // 0x9fc6c4: AllocStack(0x18)
    //     0x9fc6c4: sub             SP, SP, #0x18
    // 0x9fc6c8: SetupParameters(ConnectivityPlusLinuxPlugin this /* r1, fp-0x10 */)
    //     0x9fc6c8: stur            NULL, [fp, #-8]
    //     0x9fc6cc: mov             x0, #0
    //     0x9fc6d0: add             x1, fp, w0, sxtw #2
    //     0x9fc6d4: ldr             x1, [x1, #0x10]
    //     0x9fc6d8: stur            x1, [fp, #-0x10]
    // 0x9fc6dc: CheckStackOverflow
    //     0x9fc6dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fc6e0: cmp             SP, x16
    //     0x9fc6e4: b.ls            #0x9fc740
    // 0x9fc6e8: InitAsync() -> Future<void?>
    //     0x9fc6e8: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x9fc6ec: bl              #0x4b92e4
    // 0x9fc6f0: ldur            x0, [fp, #-0x10]
    // 0x9fc6f4: LoadField: r1 = r0->field_7
    //     0x9fc6f4: ldur            w1, [x0, #7]
    // 0x9fc6f8: DecompressPointer r1
    //     0x9fc6f8: add             x1, x1, HEAP, lsl #32
    // 0x9fc6fc: cmp             w1, NULL
    // 0x9fc700: b.ne            #0x9fc710
    // 0x9fc704: mov             x1, x0
    // 0x9fc708: r2 = Null
    //     0x9fc708: mov             x2, NULL
    // 0x9fc70c: b               #0x9fc724
    // 0x9fc710: SaveReg r1
    //     0x9fc710: str             x1, [SP, #-8]!
    // 0x9fc714: r0 = close()
    //     0x9fc714: bl              #0x9fc748  ; [package:nm/src/network_manager_client.dart] NetworkManagerClient::close
    // 0x9fc718: add             SP, SP, #8
    // 0x9fc71c: mov             x2, x0
    // 0x9fc720: ldur            x1, [fp, #-0x10]
    // 0x9fc724: mov             x0, x2
    // 0x9fc728: stur            x2, [fp, #-0x18]
    // 0x9fc72c: r0 = Await()
    //     0x9fc72c: bl              #0x4b8e6c  ; AwaitStub
    // 0x9fc730: ldur            x1, [fp, #-0x10]
    // 0x9fc734: StoreField: r1->field_7 = rNULL
    //     0x9fc734: stur            NULL, [x1, #7]
    // 0x9fc738: r0 = Null
    //     0x9fc738: mov             x0, NULL
    // 0x9fc73c: r0 = ReturnAsyncNotFuture()
    //     0x9fc73c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x9fc740: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fc740: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fc744: b               #0x9fc6e8
  }
  [closure] Future<void> _startListenConnectivity(dynamic) {
    // ** addr: 0x9fc8f0, size: 0x48
    // 0x9fc8f0: EnterFrame
    //     0x9fc8f0: stp             fp, lr, [SP, #-0x10]!
    //     0x9fc8f4: mov             fp, SP
    // 0x9fc8f8: ldr             x0, [fp, #0x10]
    // 0x9fc8fc: LoadField: r1 = r0->field_17
    //     0x9fc8fc: ldur            w1, [x0, #0x17]
    // 0x9fc900: DecompressPointer r1
    //     0x9fc900: add             x1, x1, HEAP, lsl #32
    // 0x9fc904: CheckStackOverflow
    //     0x9fc904: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fc908: cmp             SP, x16
    //     0x9fc90c: b.ls            #0x9fc930
    // 0x9fc910: LoadField: r0 = r1->field_f
    //     0x9fc910: ldur            w0, [x1, #0xf]
    // 0x9fc914: DecompressPointer r0
    //     0x9fc914: add             x0, x0, HEAP, lsl #32
    // 0x9fc918: SaveReg r0
    //     0x9fc918: str             x0, [SP, #-8]!
    // 0x9fc91c: r0 = _startListenConnectivity()
    //     0x9fc91c: bl              #0x9fc938  ; [package:connectivity_plus/src/connectivity_plus_linux.dart] ConnectivityPlusLinuxPlugin::_startListenConnectivity
    // 0x9fc920: add             SP, SP, #8
    // 0x9fc924: LeaveFrame
    //     0x9fc924: mov             SP, fp
    //     0x9fc928: ldp             fp, lr, [SP], #0x10
    // 0x9fc92c: ret
    //     0x9fc92c: ret             
    // 0x9fc930: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fc930: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fc934: b               #0x9fc910
  }
  _ _startListenConnectivity(/* No info */) async {
    // ** addr: 0x9fc938, size: 0x164
    // 0x9fc938: EnterFrame
    //     0x9fc938: stp             fp, lr, [SP, #-0x10]!
    //     0x9fc93c: mov             fp, SP
    // 0x9fc940: AllocStack(0x20)
    //     0x9fc940: sub             SP, SP, #0x20
    // 0x9fc944: SetupParameters(ConnectivityPlusLinuxPlugin this /* r1, fp-0x10 */)
    //     0x9fc944: stur            NULL, [fp, #-8]
    //     0x9fc948: mov             x0, #0
    //     0x9fc94c: add             x1, fp, w0, sxtw #2
    //     0x9fc950: ldr             x1, [x1, #0x10]
    //     0x9fc954: stur            x1, [fp, #-0x10]
    // 0x9fc958: CheckStackOverflow
    //     0x9fc958: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fc95c: cmp             SP, x16
    //     0x9fc960: b.ls            #0x9fca88
    // 0x9fc964: r1 = 1
    //     0x9fc964: mov             x1, #1
    // 0x9fc968: r0 = AllocateContext()
    //     0x9fc968: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9fc96c: mov             x2, x0
    // 0x9fc970: ldur            x1, [fp, #-0x10]
    // 0x9fc974: stur            x2, [fp, #-0x18]
    // 0x9fc978: StoreField: r2->field_f = r1
    //     0x9fc978: stur            w1, [x2, #0xf]
    // 0x9fc97c: InitAsync() -> Future<void?>
    //     0x9fc97c: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x9fc980: bl              #0x4b92e4
    // 0x9fc984: ldur            x1, [fp, #-0x10]
    // 0x9fc988: LoadField: r0 = r1->field_7
    //     0x9fc988: ldur            w0, [x1, #7]
    // 0x9fc98c: DecompressPointer r0
    //     0x9fc98c: add             x0, x0, HEAP, lsl #32
    // 0x9fc990: cmp             w0, NULL
    // 0x9fc994: b.ne            #0x9fc9e0
    // 0x9fc998: LoadField: r0 = r1->field_f
    //     0x9fc998: ldur            w0, [x1, #0xf]
    // 0x9fc99c: DecompressPointer r0
    //     0x9fc99c: add             x0, x0, HEAP, lsl #32
    // 0x9fc9a0: SaveReg r0
    //     0x9fc9a0: str             x0, [SP, #-8]!
    // 0x9fc9a4: ClosureCall
    //     0x9fc9a4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x9fc9a8: ldur            x2, [x0, #0x1f]
    //     0x9fc9ac: blr             x2
    // 0x9fc9b0: add             SP, SP, #8
    // 0x9fc9b4: mov             x2, x0
    // 0x9fc9b8: ldur            x1, [fp, #-0x10]
    // 0x9fc9bc: StoreField: r1->field_7 = r0
    //     0x9fc9bc: stur            w0, [x1, #7]
    //     0x9fc9c0: tbz             w0, #0, #0x9fc9dc
    //     0x9fc9c4: ldurb           w16, [x1, #-1]
    //     0x9fc9c8: ldurb           w17, [x0, #-1]
    //     0x9fc9cc: and             x16, x17, x16, lsr #2
    //     0x9fc9d0: tst             x16, HEAP, lsr #32
    //     0x9fc9d4: b.eq            #0x9fc9dc
    //     0x9fc9d8: bl              #0xd6826c
    // 0x9fc9dc: mov             x0, x2
    // 0x9fc9e0: cmp             w0, NULL
    // 0x9fc9e4: b.eq            #0x9fca90
    // 0x9fc9e8: SaveReg r0
    //     0x9fc9e8: str             x0, [SP, #-8]!
    // 0x9fc9ec: r0 = connect()
    //     0x9fc9ec: bl              #0x9fe078  ; [package:nm/src/network_manager_client.dart] NetworkManagerClient::connect
    // 0x9fc9f0: add             SP, SP, #8
    // 0x9fc9f4: mov             x1, x0
    // 0x9fc9f8: stur            x1, [fp, #-0x20]
    // 0x9fc9fc: r0 = Await()
    //     0x9fc9fc: bl              #0x4b8e6c  ; AwaitStub
    // 0x9fca00: ldur            x0, [fp, #-0x10]
    // 0x9fca04: LoadField: r1 = r0->field_7
    //     0x9fca04: ldur            w1, [x0, #7]
    // 0x9fca08: DecompressPointer r1
    //     0x9fca08: add             x1, x1, HEAP, lsl #32
    // 0x9fca0c: cmp             w1, NULL
    // 0x9fca10: b.eq            #0x9fca94
    // 0x9fca14: stp             x1, x0, [SP, #-0x10]!
    // 0x9fca18: r0 = _addConnectivity()
    //     0x9fca18: bl              #0x9fce7c  ; [package:connectivity_plus/src/connectivity_plus_linux.dart] ConnectivityPlusLinuxPlugin::_addConnectivity
    // 0x9fca1c: add             SP, SP, #0x10
    // 0x9fca20: ldur            x0, [fp, #-0x10]
    // 0x9fca24: LoadField: r1 = r0->field_7
    //     0x9fca24: ldur            w1, [x0, #7]
    // 0x9fca28: DecompressPointer r1
    //     0x9fca28: add             x1, x1, HEAP, lsl #32
    // 0x9fca2c: cmp             w1, NULL
    // 0x9fca30: b.eq            #0x9fca98
    // 0x9fca34: SaveReg r1
    //     0x9fca34: str             x1, [SP, #-8]!
    // 0x9fca38: r0 = propertiesChanged()
    //     0x9fca38: bl              #0x9fca9c  ; [package:nm/src/network_manager_client.dart] NetworkManagerClient::propertiesChanged
    // 0x9fca3c: add             SP, SP, #8
    // 0x9fca40: ldur            x2, [fp, #-0x18]
    // 0x9fca44: r1 = Function '<anonymous closure>':.
    //     0x9fca44: add             x1, PP, #0x21, lsl #12  ; [pp+0x21048] AnonymousClosure: (0xa0f9d4), in [package:connectivity_plus/src/connectivity_plus_linux.dart] ConnectivityPlusLinuxPlugin::_startListenConnectivity (0x9fc938)
    //     0x9fca48: ldr             x1, [x1, #0x48]
    // 0x9fca4c: stur            x0, [fp, #-0x10]
    // 0x9fca50: r0 = AllocateClosure()
    //     0x9fca50: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9fca54: mov             x1, x0
    // 0x9fca58: ldur            x0, [fp, #-0x10]
    // 0x9fca5c: r2 = LoadClassIdInstr(r0)
    //     0x9fca5c: ldur            x2, [x0, #-1]
    //     0x9fca60: ubfx            x2, x2, #0xc, #0x14
    // 0x9fca64: stp             x1, x0, [SP, #-0x10]!
    // 0x9fca68: mov             x0, x2
    // 0x9fca6c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x9fca6c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x9fca70: r0 = GDT[cid_x0 + 0x28a]()
    //     0x9fca70: add             lr, x0, #0x28a
    //     0x9fca74: ldr             lr, [x21, lr, lsl #3]
    //     0x9fca78: blr             lr
    // 0x9fca7c: add             SP, SP, #0x10
    // 0x9fca80: r0 = Null
    //     0x9fca80: mov             x0, NULL
    // 0x9fca84: r0 = ReturnAsyncNotFuture()
    //     0x9fca84: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x9fca88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fca88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fca8c: b               #0x9fc964
    // 0x9fca90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9fca90: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9fca94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9fca94: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9fca98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9fca98: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _addConnectivity(/* No info */) {
    // ** addr: 0x9fce7c, size: 0x6c
    // 0x9fce7c: EnterFrame
    //     0x9fce7c: stp             fp, lr, [SP, #-0x10]!
    //     0x9fce80: mov             fp, SP
    // 0x9fce84: AllocStack(0x8)
    //     0x9fce84: sub             SP, SP, #8
    // 0x9fce88: CheckStackOverflow
    //     0x9fce88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fce8c: cmp             SP, x16
    //     0x9fce90: b.ls            #0x9fcedc
    // 0x9fce94: ldr             x0, [fp, #0x18]
    // 0x9fce98: LoadField: r1 = r0->field_b
    //     0x9fce98: ldur            w1, [x0, #0xb]
    // 0x9fce9c: DecompressPointer r1
    //     0x9fce9c: add             x1, x1, HEAP, lsl #32
    // 0x9fcea0: stur            x1, [fp, #-8]
    // 0x9fcea4: cmp             w1, NULL
    // 0x9fcea8: b.eq            #0x9fcee4
    // 0x9fceac: ldr             x16, [fp, #0x10]
    // 0x9fceb0: stp             x16, x0, [SP, #-0x10]!
    // 0x9fceb4: r0 = _getConnectivity()
    //     0x9fceb4: bl              #0x9fcee8  ; [package:connectivity_plus/src/connectivity_plus_linux.dart] ConnectivityPlusLinuxPlugin::_getConnectivity
    // 0x9fceb8: add             SP, SP, #0x10
    // 0x9fcebc: ldur            x16, [fp, #-8]
    // 0x9fcec0: stp             x0, x16, [SP, #-0x10]!
    // 0x9fcec4: r0 = add()
    //     0x9fcec4: bl              #0xc13698  ; [dart:async] _BroadcastStreamController::add
    // 0x9fcec8: add             SP, SP, #0x10
    // 0x9fcecc: r0 = Null
    //     0x9fcecc: mov             x0, NULL
    // 0x9fced0: LeaveFrame
    //     0x9fced0: mov             SP, fp
    //     0x9fced4: ldp             fp, lr, [SP], #0x10
    // 0x9fced8: ret
    //     0x9fced8: ret             
    // 0x9fcedc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fcedc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fcee0: b               #0x9fce94
    // 0x9fcee4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9fcee4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getConnectivity(/* No info */) {
    // ** addr: 0x9fcee8, size: 0x1b4
    // 0x9fcee8: EnterFrame
    //     0x9fcee8: stp             fp, lr, [SP, #-0x10]!
    //     0x9fceec: mov             fp, SP
    // 0x9fcef0: CheckStackOverflow
    //     0x9fcef0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9fcef4: cmp             SP, x16
    //     0x9fcef8: b.ls            #0x9fd094
    // 0x9fcefc: ldr             x16, [fp, #0x10]
    // 0x9fcf00: SaveReg r16
    //     0x9fcf00: str             x16, [SP, #-8]!
    // 0x9fcf04: r0 = connectivity()
    //     0x9fcf04: bl              #0x9fde34  ; [package:nm/src/network_manager_client.dart] NetworkManagerClient::connectivity
    // 0x9fcf08: add             SP, SP, #8
    // 0x9fcf0c: r16 = Instance_NetworkManagerConnectivityState
    //     0x9fcf0c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21060] Obj!NetworkManagerConnectivityState@b61811
    //     0x9fcf10: ldr             x16, [x16, #0x60]
    // 0x9fcf14: cmp             w0, w16
    // 0x9fcf18: b.eq            #0x9fcf30
    // 0x9fcf1c: r0 = Instance_ConnectivityResult
    //     0x9fcf1c: add             x0, PP, #0x21, lsl #12  ; [pp+0x21068] Obj!ConnectivityResult@b66991
    //     0x9fcf20: ldr             x0, [x0, #0x68]
    // 0x9fcf24: LeaveFrame
    //     0x9fcf24: mov             SP, fp
    //     0x9fcf28: ldp             fp, lr, [SP], #0x10
    // 0x9fcf2c: ret
    //     0x9fcf2c: ret             
    // 0x9fcf30: ldr             x16, [fp, #0x10]
    // 0x9fcf34: SaveReg r16
    //     0x9fcf34: str             x16, [SP, #-8]!
    // 0x9fcf38: r0 = primaryConnectionType()
    //     0x9fcf38: bl              #0x9fd09c  ; [package:nm/src/network_manager_client.dart] NetworkManagerClient::primaryConnectionType
    // 0x9fcf3c: add             SP, SP, #8
    // 0x9fcf40: r1 = LoadClassIdInstr(r0)
    //     0x9fcf40: ldur            x1, [x0, #-1]
    //     0x9fcf44: ubfx            x1, x1, #0xc, #0x14
    // 0x9fcf48: r16 = "wireless"
    //     0x9fcf48: add             x16, PP, #0x21, lsl #12  ; [pp+0x21070] "wireless"
    //     0x9fcf4c: ldr             x16, [x16, #0x70]
    // 0x9fcf50: stp             x16, x0, [SP, #-0x10]!
    // 0x9fcf54: mov             x0, x1
    // 0x9fcf58: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x9fcf58: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x9fcf5c: r0 = GDT[cid_x0 + -0xffc]()
    //     0x9fcf5c: sub             lr, x0, #0xffc
    //     0x9fcf60: ldr             lr, [x21, lr, lsl #3]
    //     0x9fcf64: blr             lr
    // 0x9fcf68: add             SP, SP, #0x10
    // 0x9fcf6c: tbnz            w0, #4, #0x9fcf84
    // 0x9fcf70: r0 = Instance_ConnectivityResult
    //     0x9fcf70: add             x0, PP, #0x21, lsl #12  ; [pp+0x21078] Obj!ConnectivityResult@b66971
    //     0x9fcf74: ldr             x0, [x0, #0x78]
    // 0x9fcf78: LeaveFrame
    //     0x9fcf78: mov             SP, fp
    //     0x9fcf7c: ldp             fp, lr, [SP], #0x10
    // 0x9fcf80: ret
    //     0x9fcf80: ret             
    // 0x9fcf84: ldr             x16, [fp, #0x10]
    // 0x9fcf88: SaveReg r16
    //     0x9fcf88: str             x16, [SP, #-8]!
    // 0x9fcf8c: r0 = primaryConnectionType()
    //     0x9fcf8c: bl              #0x9fd09c  ; [package:nm/src/network_manager_client.dart] NetworkManagerClient::primaryConnectionType
    // 0x9fcf90: add             SP, SP, #8
    // 0x9fcf94: r1 = LoadClassIdInstr(r0)
    //     0x9fcf94: ldur            x1, [x0, #-1]
    //     0x9fcf98: ubfx            x1, x1, #0xc, #0x14
    // 0x9fcf9c: r16 = "ethernet"
    //     0x9fcf9c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21080] "ethernet"
    //     0x9fcfa0: ldr             x16, [x16, #0x80]
    // 0x9fcfa4: stp             x16, x0, [SP, #-0x10]!
    // 0x9fcfa8: mov             x0, x1
    // 0x9fcfac: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x9fcfac: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x9fcfb0: r0 = GDT[cid_x0 + -0xffc]()
    //     0x9fcfb0: sub             lr, x0, #0xffc
    //     0x9fcfb4: ldr             lr, [x21, lr, lsl #3]
    //     0x9fcfb8: blr             lr
    // 0x9fcfbc: add             SP, SP, #0x10
    // 0x9fcfc0: tbnz            w0, #4, #0x9fcfd8
    // 0x9fcfc4: r0 = Instance_ConnectivityResult
    //     0x9fcfc4: add             x0, PP, #0x21, lsl #12  ; [pp+0x21088] Obj!ConnectivityResult@b66951
    //     0x9fcfc8: ldr             x0, [x0, #0x88]
    // 0x9fcfcc: LeaveFrame
    //     0x9fcfcc: mov             SP, fp
    //     0x9fcfd0: ldp             fp, lr, [SP], #0x10
    // 0x9fcfd4: ret
    //     0x9fcfd4: ret             
    // 0x9fcfd8: ldr             x16, [fp, #0x10]
    // 0x9fcfdc: SaveReg r16
    //     0x9fcfdc: str             x16, [SP, #-8]!
    // 0x9fcfe0: r0 = primaryConnectionType()
    //     0x9fcfe0: bl              #0x9fd09c  ; [package:nm/src/network_manager_client.dart] NetworkManagerClient::primaryConnectionType
    // 0x9fcfe4: add             SP, SP, #8
    // 0x9fcfe8: r1 = LoadClassIdInstr(r0)
    //     0x9fcfe8: ldur            x1, [x0, #-1]
    //     0x9fcfec: ubfx            x1, x1, #0xc, #0x14
    // 0x9fcff0: r16 = "vpn"
    //     0x9fcff0: add             x16, PP, #0x21, lsl #12  ; [pp+0x21090] "vpn"
    //     0x9fcff4: ldr             x16, [x16, #0x90]
    // 0x9fcff8: stp             x16, x0, [SP, #-0x10]!
    // 0x9fcffc: mov             x0, x1
    // 0x9fd000: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x9fd000: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x9fd004: r0 = GDT[cid_x0 + -0xffc]()
    //     0x9fd004: sub             lr, x0, #0xffc
    //     0x9fd008: ldr             lr, [x21, lr, lsl #3]
    //     0x9fd00c: blr             lr
    // 0x9fd010: add             SP, SP, #0x10
    // 0x9fd014: tbnz            w0, #4, #0x9fd02c
    // 0x9fd018: r0 = Instance_ConnectivityResult
    //     0x9fd018: add             x0, PP, #0x21, lsl #12  ; [pp+0x21098] Obj!ConnectivityResult@b66931
    //     0x9fd01c: ldr             x0, [x0, #0x98]
    // 0x9fd020: LeaveFrame
    //     0x9fd020: mov             SP, fp
    //     0x9fd024: ldp             fp, lr, [SP], #0x10
    // 0x9fd028: ret
    //     0x9fd028: ret             
    // 0x9fd02c: ldr             x16, [fp, #0x10]
    // 0x9fd030: SaveReg r16
    //     0x9fd030: str             x16, [SP, #-8]!
    // 0x9fd034: r0 = primaryConnectionType()
    //     0x9fd034: bl              #0x9fd09c  ; [package:nm/src/network_manager_client.dart] NetworkManagerClient::primaryConnectionType
    // 0x9fd038: add             SP, SP, #8
    // 0x9fd03c: r1 = LoadClassIdInstr(r0)
    //     0x9fd03c: ldur            x1, [x0, #-1]
    //     0x9fd040: ubfx            x1, x1, #0xc, #0x14
    // 0x9fd044: r16 = "bluetooth"
    //     0x9fd044: add             x16, PP, #0x21, lsl #12  ; [pp+0x210a0] "bluetooth"
    //     0x9fd048: ldr             x16, [x16, #0xa0]
    // 0x9fd04c: stp             x16, x0, [SP, #-0x10]!
    // 0x9fd050: mov             x0, x1
    // 0x9fd054: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x9fd054: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x9fd058: r0 = GDT[cid_x0 + -0xffc]()
    //     0x9fd058: sub             lr, x0, #0xffc
    //     0x9fd05c: ldr             lr, [x21, lr, lsl #3]
    //     0x9fd060: blr             lr
    // 0x9fd064: add             SP, SP, #0x10
    // 0x9fd068: tbnz            w0, #4, #0x9fd080
    // 0x9fd06c: r0 = Instance_ConnectivityResult
    //     0x9fd06c: add             x0, PP, #0x21, lsl #12  ; [pp+0x210a8] Obj!ConnectivityResult@b66911
    //     0x9fd070: ldr             x0, [x0, #0xa8]
    // 0x9fd074: LeaveFrame
    //     0x9fd074: mov             SP, fp
    //     0x9fd078: ldp             fp, lr, [SP], #0x10
    // 0x9fd07c: ret
    //     0x9fd07c: ret             
    // 0x9fd080: r0 = Instance_ConnectivityResult
    //     0x9fd080: add             x0, PP, #0x21, lsl #12  ; [pp+0x210b0] Obj!ConnectivityResult@b668f1
    //     0x9fd084: ldr             x0, [x0, #0xb0]
    // 0x9fd088: LeaveFrame
    //     0x9fd088: mov             SP, fp
    //     0x9fd08c: ldp             fp, lr, [SP], #0x10
    // 0x9fd090: ret
    //     0x9fd090: ret             
    // 0x9fd094: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fd094: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fd098: b               #0x9fcefc
  }
  [closure] void <anonymous closure>(dynamic, List<String>) {
    // ** addr: 0xa0f9d4, size: 0xa0
    // 0xa0f9d4: EnterFrame
    //     0xa0f9d4: stp             fp, lr, [SP, #-0x10]!
    //     0xa0f9d8: mov             fp, SP
    // 0xa0f9dc: AllocStack(0x8)
    //     0xa0f9dc: sub             SP, SP, #8
    // 0xa0f9e0: SetupParameters()
    //     0xa0f9e0: ldr             x0, [fp, #0x18]
    //     0xa0f9e4: ldur            w1, [x0, #0x17]
    //     0xa0f9e8: add             x1, x1, HEAP, lsl #32
    //     0xa0f9ec: stur            x1, [fp, #-8]
    // 0xa0f9f0: CheckStackOverflow
    //     0xa0f9f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa0f9f4: cmp             SP, x16
    //     0xa0f9f8: b.ls            #0xa0fa68
    // 0xa0f9fc: ldr             x0, [fp, #0x10]
    // 0xa0fa00: r2 = LoadClassIdInstr(r0)
    //     0xa0fa00: ldur            x2, [x0, #-1]
    //     0xa0fa04: ubfx            x2, x2, #0xc, #0x14
    // 0xa0fa08: r16 = "Connectivity"
    //     0xa0fa08: add             x16, PP, #0x21, lsl #12  ; [pp+0x21050] "Connectivity"
    //     0xa0fa0c: ldr             x16, [x16, #0x50]
    // 0xa0fa10: stp             x16, x0, [SP, #-0x10]!
    // 0xa0fa14: mov             x0, x2
    // 0xa0fa18: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xa0fa18: mov             x17, #0xc98a
    //     0xa0fa1c: add             lr, x0, x17
    //     0xa0fa20: ldr             lr, [x21, lr, lsl #3]
    //     0xa0fa24: blr             lr
    // 0xa0fa28: add             SP, SP, #0x10
    // 0xa0fa2c: tbnz            w0, #4, #0xa0fa58
    // 0xa0fa30: ldur            x0, [fp, #-8]
    // 0xa0fa34: LoadField: r1 = r0->field_f
    //     0xa0fa34: ldur            w1, [x0, #0xf]
    // 0xa0fa38: DecompressPointer r1
    //     0xa0fa38: add             x1, x1, HEAP, lsl #32
    // 0xa0fa3c: LoadField: r0 = r1->field_7
    //     0xa0fa3c: ldur            w0, [x1, #7]
    // 0xa0fa40: DecompressPointer r0
    //     0xa0fa40: add             x0, x0, HEAP, lsl #32
    // 0xa0fa44: cmp             w0, NULL
    // 0xa0fa48: b.eq            #0xa0fa70
    // 0xa0fa4c: stp             x0, x1, [SP, #-0x10]!
    // 0xa0fa50: r0 = _addConnectivity()
    //     0xa0fa50: bl              #0x9fce7c  ; [package:connectivity_plus/src/connectivity_plus_linux.dart] ConnectivityPlusLinuxPlugin::_addConnectivity
    // 0xa0fa54: add             SP, SP, #0x10
    // 0xa0fa58: r0 = Null
    //     0xa0fa58: mov             x0, NULL
    // 0xa0fa5c: LeaveFrame
    //     0xa0fa5c: mov             SP, fp
    //     0xa0fa60: ldp             fp, lr, [SP], #0x10
    // 0xa0fa64: ret
    //     0xa0fa64: ret             
    // 0xa0fa68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0fa68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0fa6c: b               #0xa0f9fc
    // 0xa0fa70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa0fa70: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static void registerWith() {
    // ** addr: 0xd6e218, size: 0x54
    // 0xd6e218: EnterFrame
    //     0xd6e218: stp             fp, lr, [SP, #-0x10]!
    //     0xd6e21c: mov             fp, SP
    // 0xd6e220: AllocStack(0x8)
    //     0xd6e220: sub             SP, SP, #8
    // 0xd6e224: CheckStackOverflow
    //     0xd6e224: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd6e228: cmp             SP, x16
    //     0xd6e22c: b.ls            #0xd6e264
    // 0xd6e230: r0 = ConnectivityPlusLinuxPlugin()
    //     0xd6e230: bl              #0xd6f9d0  ; AllocateConnectivityPlusLinuxPluginStub -> ConnectivityPlusLinuxPlugin (size=0x14)
    // 0xd6e234: stur            x0, [fp, #-8]
    // 0xd6e238: SaveReg r0
    //     0xd6e238: str             x0, [SP, #-8]!
    // 0xd6e23c: r0 = ConnectivityPlusLinuxPlugin()
    //     0xd6e23c: bl              #0xd6e2d0  ; [package:connectivity_plus/src/connectivity_plus_linux.dart] ConnectivityPlusLinuxPlugin::ConnectivityPlusLinuxPlugin
    // 0xd6e240: add             SP, SP, #8
    // 0xd6e244: ldur            x16, [fp, #-8]
    // 0xd6e248: SaveReg r16
    //     0xd6e248: str             x16, [SP, #-8]!
    // 0xd6e24c: r0 = instance=()
    //     0xd6e24c: bl              #0xd6e26c  ; [package:connectivity_plus_platform_interface/connectivity_plus_platform_interface.dart] ConnectivityPlatform::instance=
    // 0xd6e250: add             SP, SP, #8
    // 0xd6e254: r0 = Null
    //     0xd6e254: mov             x0, NULL
    // 0xd6e258: LeaveFrame
    //     0xd6e258: mov             SP, fp
    //     0xd6e25c: ldp             fp, lr, [SP], #0x10
    // 0xd6e260: ret
    //     0xd6e260: ret             
    // 0xd6e264: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd6e264: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd6e268: b               #0xd6e230
  }
  _ ConnectivityPlusLinuxPlugin(/* No info */) {
    // ** addr: 0xd6e2d0, size: 0xb0
    // 0xd6e2d0: EnterFrame
    //     0xd6e2d0: stp             fp, lr, [SP, #-0x10]!
    //     0xd6e2d4: mov             fp, SP
    // 0xd6e2d8: AllocStack(0x8)
    //     0xd6e2d8: sub             SP, SP, #8
    // 0xd6e2dc: CheckStackOverflow
    //     0xd6e2dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd6e2e0: cmp             SP, x16
    //     0xd6e2e4: b.ls            #0xd6e378
    // 0xd6e2e8: r1 = Function '<anonymous closure>':.
    //     0xd6e2e8: ldr             x1, [PP, #0x360]  ; [pp+0x360] AnonymousClosure: (0xd6e380), in [package:connectivity_plus/src/connectivity_plus_linux.dart] ConnectivityPlusLinuxPlugin::ConnectivityPlusLinuxPlugin (0xd6e2d0)
    // 0xd6e2ec: r2 = Null
    //     0xd6e2ec: mov             x2, NULL
    // 0xd6e2f0: r0 = AllocateClosure()
    //     0xd6e2f0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xd6e2f4: ldr             x1, [fp, #0x10]
    // 0xd6e2f8: StoreField: r1->field_f = r0
    //     0xd6e2f8: stur            w0, [x1, #0xf]
    //     0xd6e2fc: ldurb           w16, [x1, #-1]
    //     0xd6e300: ldurb           w17, [x0, #-1]
    //     0xd6e304: and             x16, x17, x16, lsr #2
    //     0xd6e308: tst             x16, HEAP, lsr #32
    //     0xd6e30c: b.eq            #0xd6e314
    //     0xd6e310: bl              #0xd6826c
    // 0xd6e314: r0 = InitLateStaticField(0xb0c) // [package:connectivity_plus_platform_interface/connectivity_plus_platform_interface.dart] ConnectivityPlatform::_token
    //     0xd6e314: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd6e318: ldr             x0, [x0, #0x1618]
    //     0xd6e31c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd6e320: cmp             w0, w16
    //     0xd6e324: b.ne            #0xd6e330
    //     0xd6e328: ldr             x2, [PP, #0x350]  ; [pp+0x350] Field <ConnectivityPlatform._token@257483631>: static late final (offset: 0xb0c)
    //     0xd6e32c: bl              #0xd67cdc
    // 0xd6e330: stur            x0, [fp, #-8]
    // 0xd6e334: r0 = InitLateStaticField(0xa64) // [package:plugin_platform_interface/plugin_platform_interface.dart] PlatformInterface::_instanceTokens
    //     0xd6e334: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd6e338: ldr             x0, [x0, #0x14c8]
    //     0xd6e33c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd6e340: cmp             w0, w16
    //     0xd6e344: b.ne            #0xd6e350
    //     0xd6e348: ldr             x2, [PP, #0x170]  ; [pp+0x170] Field <PlatformInterface._instanceTokens@187304592>: static late final (offset: 0xa64)
    //     0xd6e34c: bl              #0xd67cdc
    // 0xd6e350: ldr             x16, [fp, #0x10]
    // 0xd6e354: stp             x16, x0, [SP, #-0x10]!
    // 0xd6e358: ldur            x16, [fp, #-8]
    // 0xd6e35c: SaveReg r16
    //     0xd6e35c: str             x16, [SP, #-8]!
    // 0xd6e360: r0 = []=()
    //     0xd6e360: bl              #0x4b97f8  ; [dart:core] Expando::[]=
    // 0xd6e364: add             SP, SP, #0x18
    // 0xd6e368: r0 = Null
    //     0xd6e368: mov             x0, NULL
    // 0xd6e36c: LeaveFrame
    //     0xd6e36c: mov             SP, fp
    //     0xd6e370: ldp             fp, lr, [SP], #0x10
    // 0xd6e374: ret
    //     0xd6e374: ret             
    // 0xd6e378: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd6e378: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd6e37c: b               #0xd6e2e8
  }
  [closure] NetworkManagerClient <anonymous closure>(dynamic) {
    // ** addr: 0xd6e380, size: 0x44
    // 0xd6e380: EnterFrame
    //     0xd6e380: stp             fp, lr, [SP, #-0x10]!
    //     0xd6e384: mov             fp, SP
    // 0xd6e388: AllocStack(0x8)
    //     0xd6e388: sub             SP, SP, #8
    // 0xd6e38c: CheckStackOverflow
    //     0xd6e38c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd6e390: cmp             SP, x16
    //     0xd6e394: b.ls            #0xd6e3bc
    // 0xd6e398: r0 = NetworkManagerClient()
    //     0xd6e398: bl              #0xd6f9c4  ; AllocateNetworkManagerClientStub -> NetworkManagerClient (size=0x2c)
    // 0xd6e39c: stur            x0, [fp, #-8]
    // 0xd6e3a0: SaveReg r0
    //     0xd6e3a0: str             x0, [SP, #-8]!
    // 0xd6e3a4: r0 = NetworkManagerClient()
    //     0xd6e3a4: bl              #0xd6e3c4  ; [package:nm/src/network_manager_client.dart] NetworkManagerClient::NetworkManagerClient
    // 0xd6e3a8: add             SP, SP, #8
    // 0xd6e3ac: ldur            x0, [fp, #-8]
    // 0xd6e3b0: LeaveFrame
    //     0xd6e3b0: mov             SP, fp
    //     0xd6e3b4: ldp             fp, lr, [SP], #0x10
    // 0xd6e3b8: ret
    //     0xd6e3b8: ret             
    // 0xd6e3bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd6e3bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd6e3c0: b               #0xd6e398
  }
}

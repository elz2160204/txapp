// lib: , url: package:flutter/src/rendering/shifted_box.dart

// class id: 1049419, size: 0x8
class :: {
}

// class id: 2241, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class SingleChildLayoutDelegate extends Object {

  _ getSize(/* No info */) {
    // ** addr: 0xbd78ac, size: 0x70
    // 0xbd78ac: EnterFrame
    //     0xbd78ac: stp             fp, lr, [SP, #-0x10]!
    //     0xbd78b0: mov             fp, SP
    // 0xbd78b4: AllocStack(0x10)
    //     0xbd78b4: sub             SP, SP, #0x10
    // 0xbd78b8: CheckStackOverflow
    //     0xbd78b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd78bc: cmp             SP, x16
    //     0xbd78c0: b.ls            #0xbd7914
    // 0xbd78c4: ldr             x16, [fp, #0x10]
    // 0xbd78c8: SaveReg r16
    //     0xbd78c8: str             x16, [SP, #-8]!
    // 0xbd78cc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xbd78cc: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xbd78d0: r0 = constrainWidth()
    //     0xbd78d0: bl              #0x62bc8c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xbd78d4: add             SP, SP, #8
    // 0xbd78d8: stur            d0, [fp, #-8]
    // 0xbd78dc: ldr             x16, [fp, #0x10]
    // 0xbd78e0: SaveReg r16
    //     0xbd78e0: str             x16, [SP, #-8]!
    // 0xbd78e4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xbd78e4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xbd78e8: r0 = constrainHeight()
    //     0xbd78e8: bl              #0x62bc00  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xbd78ec: add             SP, SP, #8
    // 0xbd78f0: stur            d0, [fp, #-0x10]
    // 0xbd78f4: r0 = Size()
    //     0xbd78f4: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbd78f8: ldur            d0, [fp, #-8]
    // 0xbd78fc: StoreField: r0->field_7 = d0
    //     0xbd78fc: stur            d0, [x0, #7]
    // 0xbd7900: ldur            d0, [fp, #-0x10]
    // 0xbd7904: StoreField: r0->field_f = d0
    //     0xbd7904: stur            d0, [x0, #0xf]
    // 0xbd7908: LeaveFrame
    //     0xbd7908: mov             SP, fp
    //     0xbd790c: ldp             fp, lr, [SP], #0x10
    // 0xbd7910: ret
    //     0xbd7910: ret             
    // 0xbd7914: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd7914: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd7918: b               #0xbd78c4
  }
}

// class id: 2453, size: 0x64, field offset: 0x60
//   transformed mixin,
abstract class _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin extends RenderBox
     with RenderObjectWithChildMixin<X0 bound RenderObject> {

  _ visitChildren(/* No info */) {
    // ** addr: 0x6bf90c, size: 0x5c
    // 0x6bf90c: EnterFrame
    //     0x6bf90c: stp             fp, lr, [SP, #-0x10]!
    //     0x6bf910: mov             fp, SP
    // 0x6bf914: CheckStackOverflow
    //     0x6bf914: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bf918: cmp             SP, x16
    //     0x6bf91c: b.ls            #0x6bf960
    // 0x6bf920: ldr             x0, [fp, #0x18]
    // 0x6bf924: LoadField: r1 = r0->field_5f
    //     0x6bf924: ldur            w1, [x0, #0x5f]
    // 0x6bf928: DecompressPointer r1
    //     0x6bf928: add             x1, x1, HEAP, lsl #32
    // 0x6bf92c: cmp             w1, NULL
    // 0x6bf930: b.eq            #0x6bf950
    // 0x6bf934: ldr             x16, [fp, #0x10]
    // 0x6bf938: stp             x1, x16, [SP, #-0x10]!
    // 0x6bf93c: ldr             x0, [fp, #0x10]
    // 0x6bf940: ClosureCall
    //     0x6bf940: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6bf944: ldur            x2, [x0, #0x1f]
    //     0x6bf948: blr             x2
    // 0x6bf94c: add             SP, SP, #0x10
    // 0x6bf950: r0 = Null
    //     0x6bf950: mov             x0, NULL
    // 0x6bf954: LeaveFrame
    //     0x6bf954: mov             SP, fp
    //     0x6bf958: ldp             fp, lr, [SP], #0x10
    // 0x6bf95c: ret
    //     0x6bf95c: ret             
    // 0x6bf960: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bf960: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bf964: b               #0x6bf920
  }
  set _ child=(/* No info */) {
    // ** addr: 0x6e7da0, size: 0xc0
    // 0x6e7da0: EnterFrame
    //     0x6e7da0: stp             fp, lr, [SP, #-0x10]!
    //     0x6e7da4: mov             fp, SP
    // 0x6e7da8: CheckStackOverflow
    //     0x6e7da8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e7dac: cmp             SP, x16
    //     0x6e7db0: b.ls            #0x6e7e58
    // 0x6e7db4: ldr             x0, [fp, #0x10]
    // 0x6e7db8: r2 = Null
    //     0x6e7db8: mov             x2, NULL
    // 0x6e7dbc: r1 = Null
    //     0x6e7dbc: mov             x1, NULL
    // 0x6e7dc0: r4 = 59
    //     0x6e7dc0: mov             x4, #0x3b
    // 0x6e7dc4: branchIfSmi(r0, 0x6e7dd0)
    //     0x6e7dc4: tbz             w0, #0, #0x6e7dd0
    // 0x6e7dc8: r4 = LoadClassIdInstr(r0)
    //     0x6e7dc8: ldur            x4, [x0, #-1]
    //     0x6e7dcc: ubfx            x4, x4, #0xc, #0x14
    // 0x6e7dd0: sub             x4, x4, #0x965
    // 0x6e7dd4: cmp             x4, #0x8b
    // 0x6e7dd8: b.ls            #0x6e7dec
    // 0x6e7ddc: r8 = RenderBox?
    //     0x6e7ddc: ldr             x8, [PP, #0x4de8]  ; [pp+0x4de8] Type: RenderBox?
    // 0x6e7de0: r3 = Null
    //     0x6e7de0: add             x3, PP, #0xf, lsl #12  ; [pp+0xf208] Null
    //     0x6e7de4: ldr             x3, [x3, #0x208]
    // 0x6e7de8: r0 = RenderBox?()
    //     0x6e7de8: bl              #0x5ad534  ; IsType_RenderBox?_Stub
    // 0x6e7dec: ldr             x0, [fp, #0x18]
    // 0x6e7df0: LoadField: r1 = r0->field_5f
    //     0x6e7df0: ldur            w1, [x0, #0x5f]
    // 0x6e7df4: DecompressPointer r1
    //     0x6e7df4: add             x1, x1, HEAP, lsl #32
    // 0x6e7df8: cmp             w1, NULL
    // 0x6e7dfc: b.eq            #0x6e7e0c
    // 0x6e7e00: stp             x1, x0, [SP, #-0x10]!
    // 0x6e7e04: r0 = dropChild()
    //     0x6e7e04: bl              #0x5e5aec  ; [package:flutter/src/rendering/object.dart] RenderObject::dropChild
    // 0x6e7e08: add             SP, SP, #0x10
    // 0x6e7e0c: ldr             x1, [fp, #0x18]
    // 0x6e7e10: ldr             x2, [fp, #0x10]
    // 0x6e7e14: mov             x0, x2
    // 0x6e7e18: StoreField: r1->field_5f = r0
    //     0x6e7e18: stur            w0, [x1, #0x5f]
    //     0x6e7e1c: ldurb           w16, [x1, #-1]
    //     0x6e7e20: ldurb           w17, [x0, #-1]
    //     0x6e7e24: and             x16, x17, x16, lsr #2
    //     0x6e7e28: tst             x16, HEAP, lsr #32
    //     0x6e7e2c: b.eq            #0x6e7e34
    //     0x6e7e30: bl              #0xd6826c
    // 0x6e7e34: cmp             w2, NULL
    // 0x6e7e38: b.eq            #0x6e7e48
    // 0x6e7e3c: stp             x2, x1, [SP, #-0x10]!
    // 0x6e7e40: r0 = adoptChild()
    //     0x6e7e40: bl              #0x5e61d4  ; [package:flutter/src/rendering/object.dart] RenderObject::adoptChild
    // 0x6e7e44: add             SP, SP, #0x10
    // 0x6e7e48: r0 = Null
    //     0x6e7e48: mov             x0, NULL
    // 0x6e7e4c: LeaveFrame
    //     0x6e7e4c: mov             SP, fp
    //     0x6e7e50: ldp             fp, lr, [SP], #0x10
    // 0x6e7e54: ret
    //     0x6e7e54: ret             
    // 0x6e7e58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e7e58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e7e5c: b               #0x6e7db4
  }
  _ redepthChildren(/* No info */) {
    // ** addr: 0x792bf8, size: 0x4c
    // 0x792bf8: EnterFrame
    //     0x792bf8: stp             fp, lr, [SP, #-0x10]!
    //     0x792bfc: mov             fp, SP
    // 0x792c00: CheckStackOverflow
    //     0x792c00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x792c04: cmp             SP, x16
    //     0x792c08: b.ls            #0x792c3c
    // 0x792c0c: ldr             x0, [fp, #0x10]
    // 0x792c10: LoadField: r1 = r0->field_5f
    //     0x792c10: ldur            w1, [x0, #0x5f]
    // 0x792c14: DecompressPointer r1
    //     0x792c14: add             x1, x1, HEAP, lsl #32
    // 0x792c18: cmp             w1, NULL
    // 0x792c1c: b.eq            #0x792c2c
    // 0x792c20: stp             x1, x0, [SP, #-0x10]!
    // 0x792c24: r0 = redepthChild()
    //     0x792c24: bl              #0x5e631c  ; [package:flutter/src/foundation/node.dart] AbstractNode::redepthChild
    // 0x792c28: add             SP, SP, #0x10
    // 0x792c2c: r0 = Null
    //     0x792c2c: mov             x0, NULL
    // 0x792c30: LeaveFrame
    //     0x792c30: mov             SP, fp
    //     0x792c34: ldp             fp, lr, [SP], #0x10
    // 0x792c38: ret
    //     0x792c38: ret             
    // 0x792c3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x792c3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x792c40: b               #0x792c0c
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bd674, size: 0xac
    // 0x9bd674: EnterFrame
    //     0x9bd674: stp             fp, lr, [SP, #-0x10]!
    //     0x9bd678: mov             fp, SP
    // 0x9bd67c: CheckStackOverflow
    //     0x9bd67c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bd680: cmp             SP, x16
    //     0x9bd684: b.ls            #0x9bd718
    // 0x9bd688: ldr             x0, [fp, #0x10]
    // 0x9bd68c: r2 = Null
    //     0x9bd68c: mov             x2, NULL
    // 0x9bd690: r1 = Null
    //     0x9bd690: mov             x1, NULL
    // 0x9bd694: r4 = 59
    //     0x9bd694: mov             x4, #0x3b
    // 0x9bd698: branchIfSmi(r0, 0x9bd6a4)
    //     0x9bd698: tbz             w0, #0, #0x9bd6a4
    // 0x9bd69c: r4 = LoadClassIdInstr(r0)
    //     0x9bd69c: ldur            x4, [x0, #-1]
    //     0x9bd6a0: ubfx            x4, x4, #0xc, #0x14
    // 0x9bd6a4: cmp             x4, #0x7e6
    // 0x9bd6a8: b.eq            #0x9bd6bc
    // 0x9bd6ac: r8 = PipelineOwner
    //     0x9bd6ac: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9bd6b0: r3 = Null
    //     0x9bd6b0: add             x3, PP, #0x15, lsl #12  ; [pp+0x151e8] Null
    //     0x9bd6b4: ldr             x3, [x3, #0x1e8]
    // 0x9bd6b8: r0 = DefaultTypeTest()
    //     0x9bd6b8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bd6bc: ldr             x16, [fp, #0x18]
    // 0x9bd6c0: ldr             lr, [fp, #0x10]
    // 0x9bd6c4: stp             lr, x16, [SP, #-0x10]!
    // 0x9bd6c8: r0 = attach()
    //     0x9bd6c8: bl              #0x9bf794  ; [package:flutter/src/rendering/object.dart] RenderObject::attach
    // 0x9bd6cc: add             SP, SP, #0x10
    // 0x9bd6d0: ldr             x0, [fp, #0x18]
    // 0x9bd6d4: LoadField: r1 = r0->field_5f
    //     0x9bd6d4: ldur            w1, [x0, #0x5f]
    // 0x9bd6d8: DecompressPointer r1
    //     0x9bd6d8: add             x1, x1, HEAP, lsl #32
    // 0x9bd6dc: cmp             w1, NULL
    // 0x9bd6e0: b.eq            #0x9bd708
    // 0x9bd6e4: r0 = LoadClassIdInstr(r1)
    //     0x9bd6e4: ldur            x0, [x1, #-1]
    //     0x9bd6e8: ubfx            x0, x0, #0xc, #0x14
    // 0x9bd6ec: ldr             x16, [fp, #0x10]
    // 0x9bd6f0: stp             x16, x1, [SP, #-0x10]!
    // 0x9bd6f4: r0 = GDT[cid_x0 + 0xaf1f]()
    //     0x9bd6f4: mov             x17, #0xaf1f
    //     0x9bd6f8: add             lr, x0, x17
    //     0x9bd6fc: ldr             lr, [x21, lr, lsl #3]
    //     0x9bd700: blr             lr
    // 0x9bd704: add             SP, SP, #0x10
    // 0x9bd708: r0 = Null
    //     0x9bd708: mov             x0, NULL
    // 0x9bd70c: LeaveFrame
    //     0x9bd70c: mov             SP, fp
    //     0x9bd710: ldp             fp, lr, [SP], #0x10
    // 0x9bd714: ret
    //     0x9bd714: ret             
    // 0x9bd718: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bd718: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bd71c: b               #0x9bd688
  }
  _ detach(/* No info */) {
    // ** addr: 0xa693e0, size: 0x70
    // 0xa693e0: EnterFrame
    //     0xa693e0: stp             fp, lr, [SP, #-0x10]!
    //     0xa693e4: mov             fp, SP
    // 0xa693e8: CheckStackOverflow
    //     0xa693e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa693ec: cmp             SP, x16
    //     0xa693f0: b.ls            #0xa69448
    // 0xa693f4: ldr             x16, [fp, #0x10]
    // 0xa693f8: SaveReg r16
    //     0xa693f8: str             x16, [SP, #-8]!
    // 0xa693fc: r0 = detach()
    //     0xa693fc: bl              #0xa6ade0  ; [package:flutter/src/foundation/node.dart] AbstractNode::detach
    // 0xa69400: add             SP, SP, #8
    // 0xa69404: ldr             x0, [fp, #0x10]
    // 0xa69408: LoadField: r1 = r0->field_5f
    //     0xa69408: ldur            w1, [x0, #0x5f]
    // 0xa6940c: DecompressPointer r1
    //     0xa6940c: add             x1, x1, HEAP, lsl #32
    // 0xa69410: cmp             w1, NULL
    // 0xa69414: b.eq            #0xa69438
    // 0xa69418: r0 = LoadClassIdInstr(r1)
    //     0xa69418: ldur            x0, [x1, #-1]
    //     0xa6941c: ubfx            x0, x0, #0xc, #0x14
    // 0xa69420: SaveReg r1
    //     0xa69420: str             x1, [SP, #-8]!
    // 0xa69424: r0 = GDT[cid_x0 + 0xa3cc]()
    //     0xa69424: mov             x17, #0xa3cc
    //     0xa69428: add             lr, x0, x17
    //     0xa6942c: ldr             lr, [x21, lr, lsl #3]
    //     0xa69430: blr             lr
    // 0xa69434: add             SP, SP, #8
    // 0xa69438: r0 = Null
    //     0xa69438: mov             x0, NULL
    // 0xa6943c: LeaveFrame
    //     0xa6943c: mov             SP, fp
    //     0xa69440: ldp             fp, lr, [SP], #0x10
    // 0xa69444: ret
    //     0xa69444: ret             
    // 0xa69448: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa69448: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6944c: b               #0xa693f4
  }
}

// class id: 2458, size: 0x64, field offset: 0x64
abstract class RenderShiftedBox extends _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin {

  [closure] bool <anonymous closure>(dynamic, BoxHitTestResult, Offset) {
    // ** addr: 0x624650, size: 0x6c
    // 0x624650: EnterFrame
    //     0x624650: stp             fp, lr, [SP, #-0x10]!
    //     0x624654: mov             fp, SP
    // 0x624658: ldr             x0, [fp, #0x20]
    // 0x62465c: LoadField: r1 = r0->field_17
    //     0x62465c: ldur            w1, [x0, #0x17]
    // 0x624660: DecompressPointer r1
    //     0x624660: add             x1, x1, HEAP, lsl #32
    // 0x624664: CheckStackOverflow
    //     0x624664: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x624668: cmp             SP, x16
    //     0x62466c: b.ls            #0x6246b4
    // 0x624670: LoadField: r0 = r1->field_f
    //     0x624670: ldur            w0, [x1, #0xf]
    // 0x624674: DecompressPointer r0
    //     0x624674: add             x0, x0, HEAP, lsl #32
    // 0x624678: r1 = LoadClassIdInstr(r0)
    //     0x624678: ldur            x1, [x0, #-1]
    //     0x62467c: ubfx            x1, x1, #0xc, #0x14
    // 0x624680: ldr             x16, [fp, #0x18]
    // 0x624684: stp             x16, x0, [SP, #-0x10]!
    // 0x624688: ldr             x16, [fp, #0x10]
    // 0x62468c: SaveReg r16
    //     0x62468c: str             x16, [SP, #-8]!
    // 0x624690: mov             x0, x1
    // 0x624694: r0 = GDT[cid_x0 + 0xefa2]()
    //     0x624694: mov             x17, #0xefa2
    //     0x624698: add             lr, x0, x17
    //     0x62469c: ldr             lr, [x21, lr, lsl #3]
    //     0x6246a0: blr             lr
    // 0x6246a4: add             SP, SP, #0x18
    // 0x6246a8: LeaveFrame
    //     0x6246a8: mov             SP, fp
    //     0x6246ac: ldp             fp, lr, [SP], #0x10
    // 0x6246b0: ret
    //     0x6246b0: ret             
    // 0x6246b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6246b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6246b8: b               #0x624670
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x6275b4, size: 0xf4
    // 0x6275b4: EnterFrame
    //     0x6275b4: stp             fp, lr, [SP, #-0x10]!
    //     0x6275b8: mov             fp, SP
    // 0x6275bc: AllocStack(0x18)
    //     0x6275bc: sub             SP, SP, #0x18
    // 0x6275c0: CheckStackOverflow
    //     0x6275c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6275c4: cmp             SP, x16
    //     0x6275c8: b.ls            #0x62769c
    // 0x6275cc: ldr             x0, [fp, #0x20]
    // 0x6275d0: LoadField: r1 = r0->field_5f
    //     0x6275d0: ldur            w1, [x0, #0x5f]
    // 0x6275d4: DecompressPointer r1
    //     0x6275d4: add             x1, x1, HEAP, lsl #32
    // 0x6275d8: stur            x1, [fp, #-8]
    // 0x6275dc: r1 = 1
    //     0x6275dc: mov             x1, #1
    // 0x6275e0: r0 = AllocateContext()
    //     0x6275e0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6275e4: mov             x3, x0
    // 0x6275e8: ldur            x0, [fp, #-8]
    // 0x6275ec: stur            x3, [fp, #-0x18]
    // 0x6275f0: StoreField: r3->field_f = r0
    //     0x6275f0: stur            w0, [x3, #0xf]
    // 0x6275f4: cmp             w0, NULL
    // 0x6275f8: b.eq            #0x62768c
    // 0x6275fc: LoadField: r4 = r0->field_17
    //     0x6275fc: ldur            w4, [x0, #0x17]
    // 0x627600: DecompressPointer r4
    //     0x627600: add             x4, x4, HEAP, lsl #32
    // 0x627604: stur            x4, [fp, #-0x10]
    // 0x627608: cmp             w4, NULL
    // 0x62760c: b.eq            #0x6276a4
    // 0x627610: mov             x0, x4
    // 0x627614: r2 = Null
    //     0x627614: mov             x2, NULL
    // 0x627618: r1 = Null
    //     0x627618: mov             x1, NULL
    // 0x62761c: r4 = LoadClassIdInstr(r0)
    //     0x62761c: ldur            x4, [x0, #-1]
    //     0x627620: ubfx            x4, x4, #0xc, #0x14
    // 0x627624: sub             x4, x4, #0x7ff
    // 0x627628: cmp             x4, #0xb
    // 0x62762c: b.ls            #0x627644
    // 0x627630: r8 = BoxParentData
    //     0x627630: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x627634: ldr             x8, [x8, #0x1b0]
    // 0x627638: r3 = Null
    //     0x627638: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1cea0] Null
    //     0x62763c: ldr             x3, [x3, #0xea0]
    // 0x627640: r0 = DefaultTypeTest()
    //     0x627640: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x627644: ldur            x0, [fp, #-0x10]
    // 0x627648: LoadField: r3 = r0->field_7
    //     0x627648: ldur            w3, [x0, #7]
    // 0x62764c: DecompressPointer r3
    //     0x62764c: add             x3, x3, HEAP, lsl #32
    // 0x627650: ldur            x2, [fp, #-0x18]
    // 0x627654: stur            x3, [fp, #-8]
    // 0x627658: r1 = Function '<anonymous closure>':.
    //     0x627658: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1ceb0] AnonymousClosure: (0x624650), in [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::hitTestChildren (0x6275b4)
    //     0x62765c: ldr             x1, [x1, #0xeb0]
    // 0x627660: r0 = AllocateClosure()
    //     0x627660: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x627664: ldr             x16, [fp, #0x18]
    // 0x627668: stp             x0, x16, [SP, #-0x10]!
    // 0x62766c: ldur            x16, [fp, #-8]
    // 0x627670: ldr             lr, [fp, #0x10]
    // 0x627674: stp             lr, x16, [SP, #-0x10]!
    // 0x627678: r0 = addWithPaintOffset()
    //     0x627678: bl              #0x622820  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithPaintOffset
    // 0x62767c: add             SP, SP, #0x20
    // 0x627680: LeaveFrame
    //     0x627680: mov             SP, fp
    //     0x627684: ldp             fp, lr, [SP], #0x10
    // 0x627688: ret
    //     0x627688: ret             
    // 0x62768c: r0 = false
    //     0x62768c: add             x0, NULL, #0x30  ; false
    // 0x627690: LeaveFrame
    //     0x627690: mov             SP, fp
    //     0x627694: ldp             fp, lr, [SP], #0x10
    // 0x627698: ret
    //     0x627698: ret             
    // 0x62769c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62769c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6276a0: b               #0x6275cc
    // 0x6276a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6276a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x62f000, size: 0x18
    // 0x62f000: r4 = 0
    //     0x62f000: mov             x4, #0
    // 0x62f004: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x62f004: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b1f0] AnonymousClosure: (0x62f018), in [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::computeMaxIntrinsicHeight (0x62f064)
    //     0x62f008: ldr             x1, [x17, #0x1f0]
    // 0x62f00c: r24 = BuildNonGenericMethodExtractorStub
    //     0x62f00c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x62f010: LoadField: r0 = r24->field_17
    //     0x62f010: ldur            x0, [x24, #0x17]
    // 0x62f014: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x62f018, size: 0x4c
    // 0x62f018: EnterFrame
    //     0x62f018: stp             fp, lr, [SP, #-0x10]!
    //     0x62f01c: mov             fp, SP
    // 0x62f020: ldr             x0, [fp, #0x18]
    // 0x62f024: LoadField: r1 = r0->field_17
    //     0x62f024: ldur            w1, [x0, #0x17]
    // 0x62f028: DecompressPointer r1
    //     0x62f028: add             x1, x1, HEAP, lsl #32
    // 0x62f02c: CheckStackOverflow
    //     0x62f02c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62f030: cmp             SP, x16
    //     0x62f034: b.ls            #0x62f05c
    // 0x62f038: LoadField: r0 = r1->field_f
    //     0x62f038: ldur            w0, [x1, #0xf]
    // 0x62f03c: DecompressPointer r0
    //     0x62f03c: add             x0, x0, HEAP, lsl #32
    // 0x62f040: ldr             x16, [fp, #0x10]
    // 0x62f044: stp             x16, x0, [SP, #-0x10]!
    // 0x62f048: r0 = computeMaxIntrinsicHeight()
    //     0x62f048: bl              #0x62f064  ; [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::computeMaxIntrinsicHeight
    // 0x62f04c: add             SP, SP, #0x10
    // 0x62f050: LeaveFrame
    //     0x62f050: mov             SP, fp
    //     0x62f054: ldp             fp, lr, [SP], #0x10
    // 0x62f058: ret
    //     0x62f058: ret             
    // 0x62f05c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62f05c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62f060: b               #0x62f038
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0x62f064, size: 0xe4
    // 0x62f064: EnterFrame
    //     0x62f064: stp             fp, lr, [SP, #-0x10]!
    //     0x62f068: mov             fp, SP
    // 0x62f06c: CheckStackOverflow
    //     0x62f06c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62f070: cmp             SP, x16
    //     0x62f074: b.ls            #0x62f11c
    // 0x62f078: ldr             x0, [fp, #0x18]
    // 0x62f07c: LoadField: r1 = r0->field_5f
    //     0x62f07c: ldur            w1, [x0, #0x5f]
    // 0x62f080: DecompressPointer r1
    //     0x62f080: add             x1, x1, HEAP, lsl #32
    // 0x62f084: cmp             w1, NULL
    // 0x62f088: b.ne            #0x62f094
    // 0x62f08c: r1 = Null
    //     0x62f08c: mov             x1, NULL
    // 0x62f090: b               #0x62f0d4
    // 0x62f094: ldr             x0, [fp, #0x10]
    // 0x62f098: LoadField: d0 = r0->field_7
    //     0x62f098: ldur            d0, [x0, #7]
    // 0x62f09c: SaveReg r1
    //     0x62f09c: str             x1, [SP, #-8]!
    // 0x62f0a0: SaveReg d0
    //     0x62f0a0: str             d0, [SP, #-8]!
    // 0x62f0a4: r0 = getMaxIntrinsicHeight()
    //     0x62f0a4: bl              #0x62cb24  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0x62f0a8: add             SP, SP, #0x10
    // 0x62f0ac: r1 = inline_Allocate_Double()
    //     0x62f0ac: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x62f0b0: add             x1, x1, #0x10
    //     0x62f0b4: cmp             x2, x1
    //     0x62f0b8: b.ls            #0x62f124
    //     0x62f0bc: str             x1, [THR, #0x60]  ; THR::top
    //     0x62f0c0: sub             x1, x1, #0xf
    //     0x62f0c4: mov             x2, #0xd108
    //     0x62f0c8: movk            x2, #3, lsl #16
    //     0x62f0cc: stur            x2, [x1, #-1]
    // 0x62f0d0: StoreField: r1->field_7 = d0
    //     0x62f0d0: stur            d0, [x1, #7]
    // 0x62f0d4: cmp             w1, NULL
    // 0x62f0d8: b.ne            #0x62f0e4
    // 0x62f0dc: d0 = 0.000000
    //     0x62f0dc: eor             v0.16b, v0.16b, v0.16b
    // 0x62f0e0: b               #0x62f0e8
    // 0x62f0e4: LoadField: d0 = r1->field_7
    //     0x62f0e4: ldur            d0, [x1, #7]
    // 0x62f0e8: r0 = inline_Allocate_Double()
    //     0x62f0e8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62f0ec: add             x0, x0, #0x10
    //     0x62f0f0: cmp             x1, x0
    //     0x62f0f4: b.ls            #0x62f138
    //     0x62f0f8: str             x0, [THR, #0x60]  ; THR::top
    //     0x62f0fc: sub             x0, x0, #0xf
    //     0x62f100: mov             x1, #0xd108
    //     0x62f104: movk            x1, #3, lsl #16
    //     0x62f108: stur            x1, [x0, #-1]
    // 0x62f10c: StoreField: r0->field_7 = d0
    //     0x62f10c: stur            d0, [x0, #7]
    // 0x62f110: LeaveFrame
    //     0x62f110: mov             SP, fp
    //     0x62f114: ldp             fp, lr, [SP], #0x10
    // 0x62f118: ret
    //     0x62f118: ret             
    // 0x62f11c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62f11c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62f120: b               #0x62f078
    // 0x62f124: SaveReg d0
    //     0x62f124: str             q0, [SP, #-0x10]!
    // 0x62f128: r0 = AllocateDouble()
    //     0x62f128: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62f12c: mov             x1, x0
    // 0x62f130: RestoreReg d0
    //     0x62f130: ldr             q0, [SP], #0x10
    // 0x62f134: b               #0x62f0d0
    // 0x62f138: SaveReg d0
    //     0x62f138: str             q0, [SP, #-0x10]!
    // 0x62f13c: r0 = AllocateDouble()
    //     0x62f13c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62f140: RestoreReg d0
    //     0x62f140: ldr             q0, [SP], #0x10
    // 0x62f144: b               #0x62f10c
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x635a18, size: 0x18
    // 0x635a18: r4 = 0
    //     0x635a18: mov             x4, #0
    // 0x635a1c: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x635a1c: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fbf8] AnonymousClosure: (0x635a30), in [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::computeMaxIntrinsicWidth (0x635a7c)
    //     0x635a20: ldr             x1, [x17, #0xbf8]
    // 0x635a24: r24 = BuildNonGenericMethodExtractorStub
    //     0x635a24: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x635a28: LoadField: r0 = r24->field_17
    //     0x635a28: ldur            x0, [x24, #0x17]
    // 0x635a2c: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x635a30, size: 0x4c
    // 0x635a30: EnterFrame
    //     0x635a30: stp             fp, lr, [SP, #-0x10]!
    //     0x635a34: mov             fp, SP
    // 0x635a38: ldr             x0, [fp, #0x18]
    // 0x635a3c: LoadField: r1 = r0->field_17
    //     0x635a3c: ldur            w1, [x0, #0x17]
    // 0x635a40: DecompressPointer r1
    //     0x635a40: add             x1, x1, HEAP, lsl #32
    // 0x635a44: CheckStackOverflow
    //     0x635a44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x635a48: cmp             SP, x16
    //     0x635a4c: b.ls            #0x635a74
    // 0x635a50: LoadField: r0 = r1->field_f
    //     0x635a50: ldur            w0, [x1, #0xf]
    // 0x635a54: DecompressPointer r0
    //     0x635a54: add             x0, x0, HEAP, lsl #32
    // 0x635a58: ldr             x16, [fp, #0x10]
    // 0x635a5c: stp             x16, x0, [SP, #-0x10]!
    // 0x635a60: r0 = computeMaxIntrinsicWidth()
    //     0x635a60: bl              #0x635a7c  ; [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::computeMaxIntrinsicWidth
    // 0x635a64: add             SP, SP, #0x10
    // 0x635a68: LeaveFrame
    //     0x635a68: mov             SP, fp
    //     0x635a6c: ldp             fp, lr, [SP], #0x10
    // 0x635a70: ret
    //     0x635a70: ret             
    // 0x635a74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x635a74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x635a78: b               #0x635a50
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0x635a7c, size: 0xe4
    // 0x635a7c: EnterFrame
    //     0x635a7c: stp             fp, lr, [SP, #-0x10]!
    //     0x635a80: mov             fp, SP
    // 0x635a84: CheckStackOverflow
    //     0x635a84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x635a88: cmp             SP, x16
    //     0x635a8c: b.ls            #0x635b34
    // 0x635a90: ldr             x0, [fp, #0x18]
    // 0x635a94: LoadField: r1 = r0->field_5f
    //     0x635a94: ldur            w1, [x0, #0x5f]
    // 0x635a98: DecompressPointer r1
    //     0x635a98: add             x1, x1, HEAP, lsl #32
    // 0x635a9c: cmp             w1, NULL
    // 0x635aa0: b.ne            #0x635aac
    // 0x635aa4: r1 = Null
    //     0x635aa4: mov             x1, NULL
    // 0x635aa8: b               #0x635aec
    // 0x635aac: ldr             x0, [fp, #0x10]
    // 0x635ab0: LoadField: d0 = r0->field_7
    //     0x635ab0: ldur            d0, [x0, #7]
    // 0x635ab4: SaveReg r1
    //     0x635ab4: str             x1, [SP, #-8]!
    // 0x635ab8: SaveReg d0
    //     0x635ab8: str             d0, [SP, #-8]!
    // 0x635abc: r0 = getMaxIntrinsicWidth()
    //     0x635abc: bl              #0x62cb94  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0x635ac0: add             SP, SP, #0x10
    // 0x635ac4: r1 = inline_Allocate_Double()
    //     0x635ac4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x635ac8: add             x1, x1, #0x10
    //     0x635acc: cmp             x2, x1
    //     0x635ad0: b.ls            #0x635b3c
    //     0x635ad4: str             x1, [THR, #0x60]  ; THR::top
    //     0x635ad8: sub             x1, x1, #0xf
    //     0x635adc: mov             x2, #0xd108
    //     0x635ae0: movk            x2, #3, lsl #16
    //     0x635ae4: stur            x2, [x1, #-1]
    // 0x635ae8: StoreField: r1->field_7 = d0
    //     0x635ae8: stur            d0, [x1, #7]
    // 0x635aec: cmp             w1, NULL
    // 0x635af0: b.ne            #0x635afc
    // 0x635af4: d0 = 0.000000
    //     0x635af4: eor             v0.16b, v0.16b, v0.16b
    // 0x635af8: b               #0x635b00
    // 0x635afc: LoadField: d0 = r1->field_7
    //     0x635afc: ldur            d0, [x1, #7]
    // 0x635b00: r0 = inline_Allocate_Double()
    //     0x635b00: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x635b04: add             x0, x0, #0x10
    //     0x635b08: cmp             x1, x0
    //     0x635b0c: b.ls            #0x635b50
    //     0x635b10: str             x0, [THR, #0x60]  ; THR::top
    //     0x635b14: sub             x0, x0, #0xf
    //     0x635b18: mov             x1, #0xd108
    //     0x635b1c: movk            x1, #3, lsl #16
    //     0x635b20: stur            x1, [x0, #-1]
    // 0x635b24: StoreField: r0->field_7 = d0
    //     0x635b24: stur            d0, [x0, #7]
    // 0x635b28: LeaveFrame
    //     0x635b28: mov             SP, fp
    //     0x635b2c: ldp             fp, lr, [SP], #0x10
    // 0x635b30: ret
    //     0x635b30: ret             
    // 0x635b34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x635b34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x635b38: b               #0x635a90
    // 0x635b3c: SaveReg d0
    //     0x635b3c: str             q0, [SP, #-0x10]!
    // 0x635b40: r0 = AllocateDouble()
    //     0x635b40: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x635b44: mov             x1, x0
    // 0x635b48: RestoreReg d0
    //     0x635b48: ldr             q0, [SP], #0x10
    // 0x635b4c: b               #0x635ae8
    // 0x635b50: SaveReg d0
    //     0x635b50: str             q0, [SP, #-0x10]!
    // 0x635b54: r0 = AllocateDouble()
    //     0x635b54: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x635b58: RestoreReg d0
    //     0x635b58: ldr             q0, [SP], #0x10
    // 0x635b5c: b               #0x635b24
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x638c64, size: 0x18
    // 0x638c64: r4 = 0
    //     0x638c64: mov             x4, #0
    // 0x638c68: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x638c68: add             x17, PP, #0x52, lsl #12  ; [pp+0x52e78] AnonymousClosure: (0x638c7c), in [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::computeMinIntrinsicHeight (0x638cc8)
    //     0x638c6c: ldr             x1, [x17, #0xe78]
    // 0x638c70: r24 = BuildNonGenericMethodExtractorStub
    //     0x638c70: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x638c74: LoadField: r0 = r24->field_17
    //     0x638c74: ldur            x0, [x24, #0x17]
    // 0x638c78: br              x0
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x638c7c, size: 0x4c
    // 0x638c7c: EnterFrame
    //     0x638c7c: stp             fp, lr, [SP, #-0x10]!
    //     0x638c80: mov             fp, SP
    // 0x638c84: ldr             x0, [fp, #0x18]
    // 0x638c88: LoadField: r1 = r0->field_17
    //     0x638c88: ldur            w1, [x0, #0x17]
    // 0x638c8c: DecompressPointer r1
    //     0x638c8c: add             x1, x1, HEAP, lsl #32
    // 0x638c90: CheckStackOverflow
    //     0x638c90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x638c94: cmp             SP, x16
    //     0x638c98: b.ls            #0x638cc0
    // 0x638c9c: LoadField: r0 = r1->field_f
    //     0x638c9c: ldur            w0, [x1, #0xf]
    // 0x638ca0: DecompressPointer r0
    //     0x638ca0: add             x0, x0, HEAP, lsl #32
    // 0x638ca4: ldr             x16, [fp, #0x10]
    // 0x638ca8: stp             x16, x0, [SP, #-0x10]!
    // 0x638cac: r0 = computeMinIntrinsicHeight()
    //     0x638cac: bl              #0x638cc8  ; [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::computeMinIntrinsicHeight
    // 0x638cb0: add             SP, SP, #0x10
    // 0x638cb4: LeaveFrame
    //     0x638cb4: mov             SP, fp
    //     0x638cb8: ldp             fp, lr, [SP], #0x10
    // 0x638cbc: ret
    //     0x638cbc: ret             
    // 0x638cc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x638cc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x638cc4: b               #0x638c9c
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0x638cc8, size: 0xe4
    // 0x638cc8: EnterFrame
    //     0x638cc8: stp             fp, lr, [SP, #-0x10]!
    //     0x638ccc: mov             fp, SP
    // 0x638cd0: CheckStackOverflow
    //     0x638cd0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x638cd4: cmp             SP, x16
    //     0x638cd8: b.ls            #0x638d80
    // 0x638cdc: ldr             x0, [fp, #0x18]
    // 0x638ce0: LoadField: r1 = r0->field_5f
    //     0x638ce0: ldur            w1, [x0, #0x5f]
    // 0x638ce4: DecompressPointer r1
    //     0x638ce4: add             x1, x1, HEAP, lsl #32
    // 0x638ce8: cmp             w1, NULL
    // 0x638cec: b.ne            #0x638cf8
    // 0x638cf0: r1 = Null
    //     0x638cf0: mov             x1, NULL
    // 0x638cf4: b               #0x638d38
    // 0x638cf8: ldr             x0, [fp, #0x10]
    // 0x638cfc: LoadField: d0 = r0->field_7
    //     0x638cfc: ldur            d0, [x0, #7]
    // 0x638d00: SaveReg r1
    //     0x638d00: str             x1, [SP, #-8]!
    // 0x638d04: SaveReg d0
    //     0x638d04: str             d0, [SP, #-8]!
    // 0x638d08: r0 = getMinIntrinsicHeight()
    //     0x638d08: bl              #0x630a58  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0x638d0c: add             SP, SP, #0x10
    // 0x638d10: r1 = inline_Allocate_Double()
    //     0x638d10: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x638d14: add             x1, x1, #0x10
    //     0x638d18: cmp             x2, x1
    //     0x638d1c: b.ls            #0x638d88
    //     0x638d20: str             x1, [THR, #0x60]  ; THR::top
    //     0x638d24: sub             x1, x1, #0xf
    //     0x638d28: mov             x2, #0xd108
    //     0x638d2c: movk            x2, #3, lsl #16
    //     0x638d30: stur            x2, [x1, #-1]
    // 0x638d34: StoreField: r1->field_7 = d0
    //     0x638d34: stur            d0, [x1, #7]
    // 0x638d38: cmp             w1, NULL
    // 0x638d3c: b.ne            #0x638d48
    // 0x638d40: d0 = 0.000000
    //     0x638d40: eor             v0.16b, v0.16b, v0.16b
    // 0x638d44: b               #0x638d4c
    // 0x638d48: LoadField: d0 = r1->field_7
    //     0x638d48: ldur            d0, [x1, #7]
    // 0x638d4c: r0 = inline_Allocate_Double()
    //     0x638d4c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x638d50: add             x0, x0, #0x10
    //     0x638d54: cmp             x1, x0
    //     0x638d58: b.ls            #0x638d9c
    //     0x638d5c: str             x0, [THR, #0x60]  ; THR::top
    //     0x638d60: sub             x0, x0, #0xf
    //     0x638d64: mov             x1, #0xd108
    //     0x638d68: movk            x1, #3, lsl #16
    //     0x638d6c: stur            x1, [x0, #-1]
    // 0x638d70: StoreField: r0->field_7 = d0
    //     0x638d70: stur            d0, [x0, #7]
    // 0x638d74: LeaveFrame
    //     0x638d74: mov             SP, fp
    //     0x638d78: ldp             fp, lr, [SP], #0x10
    // 0x638d7c: ret
    //     0x638d7c: ret             
    // 0x638d80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x638d80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x638d84: b               #0x638cdc
    // 0x638d88: SaveReg d0
    //     0x638d88: str             q0, [SP, #-0x10]!
    // 0x638d8c: r0 = AllocateDouble()
    //     0x638d8c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x638d90: mov             x1, x0
    // 0x638d94: RestoreReg d0
    //     0x638d94: ldr             q0, [SP], #0x10
    // 0x638d98: b               #0x638d34
    // 0x638d9c: SaveReg d0
    //     0x638d9c: str             q0, [SP, #-0x10]!
    // 0x638da0: r0 = AllocateDouble()
    //     0x638da0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x638da4: RestoreReg d0
    //     0x638da4: ldr             q0, [SP], #0x10
    // 0x638da8: b               #0x638d70
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63b8a0, size: 0x18
    // 0x63b8a0: r4 = 0
    //     0x63b8a0: mov             x4, #0
    // 0x63b8a4: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63b8a4: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fce8] AnonymousClosure: (0x63b8b8), in [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::computeMinIntrinsicWidth (0x63b904)
    //     0x63b8a8: ldr             x1, [x17, #0xce8]
    // 0x63b8ac: r24 = BuildNonGenericMethodExtractorStub
    //     0x63b8ac: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63b8b0: LoadField: r0 = r24->field_17
    //     0x63b8b0: ldur            x0, [x24, #0x17]
    // 0x63b8b4: br              x0
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63b8b8, size: 0x4c
    // 0x63b8b8: EnterFrame
    //     0x63b8b8: stp             fp, lr, [SP, #-0x10]!
    //     0x63b8bc: mov             fp, SP
    // 0x63b8c0: ldr             x0, [fp, #0x18]
    // 0x63b8c4: LoadField: r1 = r0->field_17
    //     0x63b8c4: ldur            w1, [x0, #0x17]
    // 0x63b8c8: DecompressPointer r1
    //     0x63b8c8: add             x1, x1, HEAP, lsl #32
    // 0x63b8cc: CheckStackOverflow
    //     0x63b8cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63b8d0: cmp             SP, x16
    //     0x63b8d4: b.ls            #0x63b8fc
    // 0x63b8d8: LoadField: r0 = r1->field_f
    //     0x63b8d8: ldur            w0, [x1, #0xf]
    // 0x63b8dc: DecompressPointer r0
    //     0x63b8dc: add             x0, x0, HEAP, lsl #32
    // 0x63b8e0: ldr             x16, [fp, #0x10]
    // 0x63b8e4: stp             x16, x0, [SP, #-0x10]!
    // 0x63b8e8: r0 = computeMinIntrinsicWidth()
    //     0x63b8e8: bl              #0x63b904  ; [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::computeMinIntrinsicWidth
    // 0x63b8ec: add             SP, SP, #0x10
    // 0x63b8f0: LeaveFrame
    //     0x63b8f0: mov             SP, fp
    //     0x63b8f4: ldp             fp, lr, [SP], #0x10
    // 0x63b8f8: ret
    //     0x63b8f8: ret             
    // 0x63b8fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63b8fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63b900: b               #0x63b8d8
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0x63b904, size: 0xe4
    // 0x63b904: EnterFrame
    //     0x63b904: stp             fp, lr, [SP, #-0x10]!
    //     0x63b908: mov             fp, SP
    // 0x63b90c: CheckStackOverflow
    //     0x63b90c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63b910: cmp             SP, x16
    //     0x63b914: b.ls            #0x63b9bc
    // 0x63b918: ldr             x0, [fp, #0x18]
    // 0x63b91c: LoadField: r1 = r0->field_5f
    //     0x63b91c: ldur            w1, [x0, #0x5f]
    // 0x63b920: DecompressPointer r1
    //     0x63b920: add             x1, x1, HEAP, lsl #32
    // 0x63b924: cmp             w1, NULL
    // 0x63b928: b.ne            #0x63b934
    // 0x63b92c: r1 = Null
    //     0x63b92c: mov             x1, NULL
    // 0x63b930: b               #0x63b974
    // 0x63b934: ldr             x0, [fp, #0x10]
    // 0x63b938: LoadField: d0 = r0->field_7
    //     0x63b938: ldur            d0, [x0, #7]
    // 0x63b93c: SaveReg r1
    //     0x63b93c: str             x1, [SP, #-8]!
    // 0x63b940: SaveReg d0
    //     0x63b940: str             d0, [SP, #-8]!
    // 0x63b944: r0 = getMinIntrinsicWidth()
    //     0x63b944: bl              #0x630b18  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicWidth
    // 0x63b948: add             SP, SP, #0x10
    // 0x63b94c: r1 = inline_Allocate_Double()
    //     0x63b94c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x63b950: add             x1, x1, #0x10
    //     0x63b954: cmp             x2, x1
    //     0x63b958: b.ls            #0x63b9c4
    //     0x63b95c: str             x1, [THR, #0x60]  ; THR::top
    //     0x63b960: sub             x1, x1, #0xf
    //     0x63b964: mov             x2, #0xd108
    //     0x63b968: movk            x2, #3, lsl #16
    //     0x63b96c: stur            x2, [x1, #-1]
    // 0x63b970: StoreField: r1->field_7 = d0
    //     0x63b970: stur            d0, [x1, #7]
    // 0x63b974: cmp             w1, NULL
    // 0x63b978: b.ne            #0x63b984
    // 0x63b97c: d0 = 0.000000
    //     0x63b97c: eor             v0.16b, v0.16b, v0.16b
    // 0x63b980: b               #0x63b988
    // 0x63b984: LoadField: d0 = r1->field_7
    //     0x63b984: ldur            d0, [x1, #7]
    // 0x63b988: r0 = inline_Allocate_Double()
    //     0x63b988: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63b98c: add             x0, x0, #0x10
    //     0x63b990: cmp             x1, x0
    //     0x63b994: b.ls            #0x63b9d8
    //     0x63b998: str             x0, [THR, #0x60]  ; THR::top
    //     0x63b99c: sub             x0, x0, #0xf
    //     0x63b9a0: mov             x1, #0xd108
    //     0x63b9a4: movk            x1, #3, lsl #16
    //     0x63b9a8: stur            x1, [x0, #-1]
    // 0x63b9ac: StoreField: r0->field_7 = d0
    //     0x63b9ac: stur            d0, [x0, #7]
    // 0x63b9b0: LeaveFrame
    //     0x63b9b0: mov             SP, fp
    //     0x63b9b4: ldp             fp, lr, [SP], #0x10
    // 0x63b9b8: ret
    //     0x63b9b8: ret             
    // 0x63b9bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63b9bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63b9c0: b               #0x63b918
    // 0x63b9c4: SaveReg d0
    //     0x63b9c4: str             q0, [SP, #-0x10]!
    // 0x63b9c8: r0 = AllocateDouble()
    //     0x63b9c8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63b9cc: mov             x1, x0
    // 0x63b9d0: RestoreReg d0
    //     0x63b9d0: ldr             q0, [SP], #0x10
    // 0x63b9d4: b               #0x63b970
    // 0x63b9d8: SaveReg d0
    //     0x63b9d8: str             q0, [SP, #-0x10]!
    // 0x63b9dc: r0 = AllocateDouble()
    //     0x63b9dc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63b9e0: RestoreReg d0
    //     0x63b9e0: ldr             q0, [SP], #0x10
    // 0x63b9e4: b               #0x63b9ac
  }
  _ computeDistanceToActualBaseline(/* No info */) {
    // ** addr: 0x63e118, size: 0x11c
    // 0x63e118: EnterFrame
    //     0x63e118: stp             fp, lr, [SP, #-0x10]!
    //     0x63e11c: mov             fp, SP
    // 0x63e120: AllocStack(0x18)
    //     0x63e120: sub             SP, SP, #0x18
    // 0x63e124: CheckStackOverflow
    //     0x63e124: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63e128: cmp             SP, x16
    //     0x63e12c: b.ls            #0x63e214
    // 0x63e130: ldr             x0, [fp, #0x18]
    // 0x63e134: LoadField: r1 = r0->field_5f
    //     0x63e134: ldur            w1, [x0, #0x5f]
    // 0x63e138: DecompressPointer r1
    //     0x63e138: add             x1, x1, HEAP, lsl #32
    // 0x63e13c: stur            x1, [fp, #-8]
    // 0x63e140: cmp             w1, NULL
    // 0x63e144: b.eq            #0x63e204
    // 0x63e148: ldr             x16, [fp, #0x10]
    // 0x63e14c: stp             x16, x1, [SP, #-0x10]!
    // 0x63e150: r0 = getDistanceToActualBaseline()
    //     0x63e150: bl              #0x63d634  ; [package:flutter/src/rendering/box.dart] RenderBox::getDistanceToActualBaseline
    // 0x63e154: add             SP, SP, #0x10
    // 0x63e158: mov             x3, x0
    // 0x63e15c: ldur            x0, [fp, #-8]
    // 0x63e160: stur            x3, [fp, #-0x18]
    // 0x63e164: LoadField: r4 = r0->field_17
    //     0x63e164: ldur            w4, [x0, #0x17]
    // 0x63e168: DecompressPointer r4
    //     0x63e168: add             x4, x4, HEAP, lsl #32
    // 0x63e16c: stur            x4, [fp, #-0x10]
    // 0x63e170: cmp             w4, NULL
    // 0x63e174: b.eq            #0x63e21c
    // 0x63e178: mov             x0, x4
    // 0x63e17c: r2 = Null
    //     0x63e17c: mov             x2, NULL
    // 0x63e180: r1 = Null
    //     0x63e180: mov             x1, NULL
    // 0x63e184: r4 = LoadClassIdInstr(r0)
    //     0x63e184: ldur            x4, [x0, #-1]
    //     0x63e188: ubfx            x4, x4, #0xc, #0x14
    // 0x63e18c: sub             x4, x4, #0x7ff
    // 0x63e190: cmp             x4, #0xb
    // 0x63e194: b.ls            #0x63e1ac
    // 0x63e198: r8 = BoxParentData
    //     0x63e198: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x63e19c: ldr             x8, [x8, #0x1b0]
    // 0x63e1a0: r3 = Null
    //     0x63e1a0: add             x3, PP, #0x21, lsl #12  ; [pp+0x21a88] Null
    //     0x63e1a4: ldr             x3, [x3, #0xa88]
    // 0x63e1a8: r0 = DefaultTypeTest()
    //     0x63e1a8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x63e1ac: ldur            x1, [fp, #-0x18]
    // 0x63e1b0: cmp             w1, NULL
    // 0x63e1b4: b.eq            #0x63e1fc
    // 0x63e1b8: ldur            x2, [fp, #-0x10]
    // 0x63e1bc: LoadField: r3 = r2->field_7
    //     0x63e1bc: ldur            w3, [x2, #7]
    // 0x63e1c0: DecompressPointer r3
    //     0x63e1c0: add             x3, x3, HEAP, lsl #32
    // 0x63e1c4: LoadField: d0 = r3->field_f
    //     0x63e1c4: ldur            d0, [x3, #0xf]
    // 0x63e1c8: LoadField: d1 = r1->field_7
    //     0x63e1c8: ldur            d1, [x1, #7]
    // 0x63e1cc: fadd            d2, d1, d0
    // 0x63e1d0: r2 = inline_Allocate_Double()
    //     0x63e1d0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x63e1d4: add             x2, x2, #0x10
    //     0x63e1d8: cmp             x3, x2
    //     0x63e1dc: b.ls            #0x63e220
    //     0x63e1e0: str             x2, [THR, #0x60]  ; THR::top
    //     0x63e1e4: sub             x2, x2, #0xf
    //     0x63e1e8: mov             x3, #0xd108
    //     0x63e1ec: movk            x3, #3, lsl #16
    //     0x63e1f0: stur            x3, [x2, #-1]
    // 0x63e1f4: StoreField: r2->field_7 = d2
    //     0x63e1f4: stur            d2, [x2, #7]
    // 0x63e1f8: mov             x1, x2
    // 0x63e1fc: mov             x0, x1
    // 0x63e200: b               #0x63e208
    // 0x63e204: r0 = Null
    //     0x63e204: mov             x0, NULL
    // 0x63e208: LeaveFrame
    //     0x63e208: mov             SP, fp
    //     0x63e20c: ldp             fp, lr, [SP], #0x10
    // 0x63e210: ret
    //     0x63e210: ret             
    // 0x63e214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63e214: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63e218: b               #0x63e130
    // 0x63e21c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63e21c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x63e220: SaveReg d2
    //     0x63e220: str             q2, [SP, #-0x10]!
    // 0x63e224: r0 = AllocateDouble()
    //     0x63e224: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63e228: mov             x2, x0
    // 0x63e22c: RestoreReg d2
    //     0x63e22c: ldr             q2, [SP], #0x10
    // 0x63e230: b               #0x63e1f4
  }
  [closure] void paint(dynamic, PaintingContext, Offset) {
    // ** addr: 0x669984, size: 0x54
    // 0x669984: EnterFrame
    //     0x669984: stp             fp, lr, [SP, #-0x10]!
    //     0x669988: mov             fp, SP
    // 0x66998c: ldr             x0, [fp, #0x20]
    // 0x669990: LoadField: r1 = r0->field_17
    //     0x669990: ldur            w1, [x0, #0x17]
    // 0x669994: DecompressPointer r1
    //     0x669994: add             x1, x1, HEAP, lsl #32
    // 0x669998: CheckStackOverflow
    //     0x669998: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66999c: cmp             SP, x16
    //     0x6699a0: b.ls            #0x6699d0
    // 0x6699a4: LoadField: r0 = r1->field_f
    //     0x6699a4: ldur            w0, [x1, #0xf]
    // 0x6699a8: DecompressPointer r0
    //     0x6699a8: add             x0, x0, HEAP, lsl #32
    // 0x6699ac: ldr             x16, [fp, #0x18]
    // 0x6699b0: stp             x16, x0, [SP, #-0x10]!
    // 0x6699b4: ldr             x16, [fp, #0x10]
    // 0x6699b8: SaveReg r16
    //     0x6699b8: str             x16, [SP, #-8]!
    // 0x6699bc: r0 = paint()
    //     0x6699bc: bl              #0x669b50  ; [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::paint
    // 0x6699c0: add             SP, SP, #0x18
    // 0x6699c4: LeaveFrame
    //     0x6699c4: mov             SP, fp
    //     0x6699c8: ldp             fp, lr, [SP], #0x10
    // 0x6699cc: ret
    //     0x6699cc: ret             
    // 0x6699d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6699d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6699d4: b               #0x6699a4
  }
  _ paint(/* No info */) {
    // ** addr: 0x669b50, size: 0xc8
    // 0x669b50: EnterFrame
    //     0x669b50: stp             fp, lr, [SP, #-0x10]!
    //     0x669b54: mov             fp, SP
    // 0x669b58: AllocStack(0x10)
    //     0x669b58: sub             SP, SP, #0x10
    // 0x669b5c: CheckStackOverflow
    //     0x669b5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x669b60: cmp             SP, x16
    //     0x669b64: b.ls            #0x669c0c
    // 0x669b68: ldr             x0, [fp, #0x20]
    // 0x669b6c: LoadField: r3 = r0->field_5f
    //     0x669b6c: ldur            w3, [x0, #0x5f]
    // 0x669b70: DecompressPointer r3
    //     0x669b70: add             x3, x3, HEAP, lsl #32
    // 0x669b74: stur            x3, [fp, #-0x10]
    // 0x669b78: cmp             w3, NULL
    // 0x669b7c: b.eq            #0x669bfc
    // 0x669b80: LoadField: r4 = r3->field_17
    //     0x669b80: ldur            w4, [x3, #0x17]
    // 0x669b84: DecompressPointer r4
    //     0x669b84: add             x4, x4, HEAP, lsl #32
    // 0x669b88: stur            x4, [fp, #-8]
    // 0x669b8c: cmp             w4, NULL
    // 0x669b90: b.eq            #0x669c14
    // 0x669b94: mov             x0, x4
    // 0x669b98: r2 = Null
    //     0x669b98: mov             x2, NULL
    // 0x669b9c: r1 = Null
    //     0x669b9c: mov             x1, NULL
    // 0x669ba0: r4 = LoadClassIdInstr(r0)
    //     0x669ba0: ldur            x4, [x0, #-1]
    //     0x669ba4: ubfx            x4, x4, #0xc, #0x14
    // 0x669ba8: sub             x4, x4, #0x7ff
    // 0x669bac: cmp             x4, #0xb
    // 0x669bb0: b.ls            #0x669bc8
    // 0x669bb4: r8 = BoxParentData
    //     0x669bb4: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x669bb8: ldr             x8, [x8, #0x1b0]
    // 0x669bbc: r3 = Null
    //     0x669bbc: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1cec0] Null
    //     0x669bc0: ldr             x3, [x3, #0xec0]
    // 0x669bc4: r0 = DefaultTypeTest()
    //     0x669bc4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x669bc8: ldur            x0, [fp, #-8]
    // 0x669bcc: LoadField: r1 = r0->field_7
    //     0x669bcc: ldur            w1, [x0, #7]
    // 0x669bd0: DecompressPointer r1
    //     0x669bd0: add             x1, x1, HEAP, lsl #32
    // 0x669bd4: ldr             x16, [fp, #0x10]
    // 0x669bd8: stp             x16, x1, [SP, #-0x10]!
    // 0x669bdc: r0 = +()
    //     0x669bdc: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x669be0: add             SP, SP, #0x10
    // 0x669be4: ldr             x16, [fp, #0x18]
    // 0x669be8: ldur            lr, [fp, #-0x10]
    // 0x669bec: stp             lr, x16, [SP, #-0x10]!
    // 0x669bf0: SaveReg r0
    //     0x669bf0: str             x0, [SP, #-8]!
    // 0x669bf4: r0 = paintChild()
    //     0x669bf4: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x669bf8: add             SP, SP, #0x18
    // 0x669bfc: r0 = Null
    //     0x669bfc: mov             x0, NULL
    // 0x669c00: LeaveFrame
    //     0x669c00: mov             SP, fp
    //     0x669c04: ldp             fp, lr, [SP], #0x10
    // 0x669c08: ret
    //     0x669c08: ret             
    // 0x669c0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x669c0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x669c10: b               #0x669b68
    // 0x669c14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x669c14: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2459, size: 0x68, field offset: 0x64
class RenderCustomSingleChildLayoutBox extends RenderShiftedBox {

  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x62f7f4, size: 0x18
    // 0x62f7f4: r4 = 0
    //     0x62f7f4: mov             x4, #0
    // 0x62f7f8: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x62f7f8: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b1d0] AnonymousClosure: (0x62f80c), in [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::computeMinIntrinsicHeight (0x62f858)
    //     0x62f7fc: ldr             x1, [x17, #0x1d0]
    // 0x62f800: r24 = BuildNonGenericMethodExtractorStub
    //     0x62f800: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x62f804: LoadField: r0 = r24->field_17
    //     0x62f804: ldur            x0, [x24, #0x17]
    // 0x62f808: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x62f80c, size: 0x4c
    // 0x62f80c: EnterFrame
    //     0x62f80c: stp             fp, lr, [SP, #-0x10]!
    //     0x62f810: mov             fp, SP
    // 0x62f814: ldr             x0, [fp, #0x18]
    // 0x62f818: LoadField: r1 = r0->field_17
    //     0x62f818: ldur            w1, [x0, #0x17]
    // 0x62f81c: DecompressPointer r1
    //     0x62f81c: add             x1, x1, HEAP, lsl #32
    // 0x62f820: CheckStackOverflow
    //     0x62f820: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62f824: cmp             SP, x16
    //     0x62f828: b.ls            #0x62f850
    // 0x62f82c: LoadField: r0 = r1->field_f
    //     0x62f82c: ldur            w0, [x1, #0xf]
    // 0x62f830: DecompressPointer r0
    //     0x62f830: add             x0, x0, HEAP, lsl #32
    // 0x62f834: ldr             x16, [fp, #0x10]
    // 0x62f838: stp             x16, x0, [SP, #-0x10]!
    // 0x62f83c: r0 = computeMinIntrinsicHeight()
    //     0x62f83c: bl              #0x62f858  ; [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::computeMinIntrinsicHeight
    // 0x62f840: add             SP, SP, #0x10
    // 0x62f844: LeaveFrame
    //     0x62f844: mov             SP, fp
    //     0x62f848: ldp             fp, lr, [SP], #0x10
    // 0x62f84c: ret
    //     0x62f84c: ret             
    // 0x62f850: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62f850: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62f854: b               #0x62f82c
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0x62f858, size: 0x128
    // 0x62f858: EnterFrame
    //     0x62f858: stp             fp, lr, [SP, #-0x10]!
    //     0x62f85c: mov             fp, SP
    // 0x62f860: AllocStack(0x18)
    //     0x62f860: sub             SP, SP, #0x18
    // 0x62f864: d0 = inf
    //     0x62f864: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62f868: CheckStackOverflow
    //     0x62f868: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62f86c: cmp             SP, x16
    //     0x62f870: b.ls            #0x62f968
    // 0x62f874: ldr             x0, [fp, #0x10]
    // 0x62f878: LoadField: d1 = r0->field_7
    //     0x62f878: ldur            d1, [x0, #7]
    // 0x62f87c: stur            d1, [fp, #-0x18]
    // 0x62f880: fcmp            d1, d0
    // 0x62f884: b.vs            #0x62f88c
    // 0x62f888: b.eq            #0x62f894
    // 0x62f88c: r0 = false
    //     0x62f88c: add             x0, NULL, #0x30  ; false
    // 0x62f890: b               #0x62f898
    // 0x62f894: r0 = true
    //     0x62f894: add             x0, NULL, #0x20  ; true
    // 0x62f898: stur            x0, [fp, #-8]
    // 0x62f89c: tbz             w0, #4, #0x62f8a8
    // 0x62f8a0: mov             v2.16b, v1.16b
    // 0x62f8a4: b               #0x62f8ac
    // 0x62f8a8: d2 = 0.000000
    //     0x62f8a8: eor             v2.16b, v2.16b, v2.16b
    // 0x62f8ac: stur            d2, [fp, #-0x10]
    // 0x62f8b0: r0 = BoxConstraints()
    //     0x62f8b0: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x62f8b4: ldur            d0, [fp, #-0x10]
    // 0x62f8b8: StoreField: r0->field_7 = d0
    //     0x62f8b8: stur            d0, [x0, #7]
    // 0x62f8bc: ldur            x1, [fp, #-8]
    // 0x62f8c0: tbz             w1, #4, #0x62f8cc
    // 0x62f8c4: ldur            d1, [fp, #-0x18]
    // 0x62f8c8: b               #0x62f8d0
    // 0x62f8cc: d1 = inf
    //     0x62f8cc: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62f8d0: d0 = inf
    //     0x62f8d0: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62f8d4: StoreField: r0->field_f = d1
    //     0x62f8d4: stur            d1, [x0, #0xf]
    // 0x62f8d8: fcmp            d0, d0
    // 0x62f8dc: b.eq            #0x62f8e8
    // 0x62f8e0: d1 = inf
    //     0x62f8e0: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62f8e4: b               #0x62f8ec
    // 0x62f8e8: d1 = 0.000000
    //     0x62f8e8: eor             v1.16b, v1.16b, v1.16b
    // 0x62f8ec: StoreField: r0->field_17 = d1
    //     0x62f8ec: stur            d1, [x0, #0x17]
    // 0x62f8f0: StoreField: r0->field_1f = d0
    //     0x62f8f0: stur            d0, [x0, #0x1f]
    // 0x62f8f4: ldr             x16, [fp, #0x18]
    // 0x62f8f8: stp             x0, x16, [SP, #-0x10]!
    // 0x62f8fc: r0 = _getSize()
    //     0x62f8fc: bl              #0x62f9cc  ; [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::_getSize
    // 0x62f900: add             SP, SP, #0x10
    // 0x62f904: LoadField: d0 = r0->field_f
    //     0x62f904: ldur            d0, [x0, #0xf]
    // 0x62f908: mov             x1, v0.d[0]
    // 0x62f90c: and             x1, x1, #0x7fffffffffffffff
    // 0x62f910: r17 = 9218868437227405312
    //     0x62f910: mov             x17, #0x7ff0000000000000
    // 0x62f914: cmp             x1, x17
    // 0x62f918: b.eq            #0x62f958
    // 0x62f91c: fcmp            d0, d0
    // 0x62f920: b.vs            #0x62f958
    // 0x62f924: r0 = inline_Allocate_Double()
    //     0x62f924: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62f928: add             x0, x0, #0x10
    //     0x62f92c: cmp             x1, x0
    //     0x62f930: b.ls            #0x62f970
    //     0x62f934: str             x0, [THR, #0x60]  ; THR::top
    //     0x62f938: sub             x0, x0, #0xf
    //     0x62f93c: mov             x1, #0xd108
    //     0x62f940: movk            x1, #3, lsl #16
    //     0x62f944: stur            x1, [x0, #-1]
    // 0x62f948: StoreField: r0->field_7 = d0
    //     0x62f948: stur            d0, [x0, #7]
    // 0x62f94c: LeaveFrame
    //     0x62f94c: mov             SP, fp
    //     0x62f950: ldp             fp, lr, [SP], #0x10
    // 0x62f954: ret
    //     0x62f954: ret             
    // 0x62f958: r0 = 0.000000
    //     0x62f958: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x62f95c: LeaveFrame
    //     0x62f95c: mov             SP, fp
    //     0x62f960: ldp             fp, lr, [SP], #0x10
    // 0x62f964: ret
    //     0x62f964: ret             
    // 0x62f968: r0 = StackOverflowSharedWithFPURegs()
    //     0x62f968: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x62f96c: b               #0x62f874
    // 0x62f970: SaveReg d0
    //     0x62f970: str             q0, [SP, #-0x10]!
    // 0x62f974: r0 = AllocateDouble()
    //     0x62f974: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62f978: RestoreReg d0
    //     0x62f978: ldr             q0, [SP], #0x10
    // 0x62f97c: b               #0x62f948
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x62f980, size: 0x4c
    // 0x62f980: EnterFrame
    //     0x62f980: stp             fp, lr, [SP, #-0x10]!
    //     0x62f984: mov             fp, SP
    // 0x62f988: ldr             x0, [fp, #0x18]
    // 0x62f98c: LoadField: r1 = r0->field_17
    //     0x62f98c: ldur            w1, [x0, #0x17]
    // 0x62f990: DecompressPointer r1
    //     0x62f990: add             x1, x1, HEAP, lsl #32
    // 0x62f994: CheckStackOverflow
    //     0x62f994: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62f998: cmp             SP, x16
    //     0x62f99c: b.ls            #0x62f9c4
    // 0x62f9a0: LoadField: r0 = r1->field_f
    //     0x62f9a0: ldur            w0, [x1, #0xf]
    // 0x62f9a4: DecompressPointer r0
    //     0x62f9a4: add             x0, x0, HEAP, lsl #32
    // 0x62f9a8: ldr             x16, [fp, #0x10]
    // 0x62f9ac: stp             x16, x0, [SP, #-0x10]!
    // 0x62f9b0: r0 = computeMinIntrinsicHeight()
    //     0x62f9b0: bl              #0x62f858  ; [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::computeMinIntrinsicHeight
    // 0x62f9b4: add             SP, SP, #0x10
    // 0x62f9b8: LeaveFrame
    //     0x62f9b8: mov             SP, fp
    //     0x62f9bc: ldp             fp, lr, [SP], #0x10
    // 0x62f9c0: ret
    //     0x62f9c0: ret             
    // 0x62f9c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62f9c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62f9c8: b               #0x62f9a0
  }
  _ _getSize(/* No info */) {
    // ** addr: 0x62f9cc, size: 0x68
    // 0x62f9cc: EnterFrame
    //     0x62f9cc: stp             fp, lr, [SP, #-0x10]!
    //     0x62f9d0: mov             fp, SP
    // 0x62f9d4: CheckStackOverflow
    //     0x62f9d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62f9d8: cmp             SP, x16
    //     0x62f9dc: b.ls            #0x62fa2c
    // 0x62f9e0: ldr             x0, [fp, #0x18]
    // 0x62f9e4: LoadField: r1 = r0->field_63
    //     0x62f9e4: ldur            w1, [x0, #0x63]
    // 0x62f9e8: DecompressPointer r1
    //     0x62f9e8: add             x1, x1, HEAP, lsl #32
    // 0x62f9ec: r0 = LoadClassIdInstr(r1)
    //     0x62f9ec: ldur            x0, [x1, #-1]
    //     0x62f9f0: ubfx            x0, x0, #0xc, #0x14
    // 0x62f9f4: ldr             x16, [fp, #0x10]
    // 0x62f9f8: stp             x16, x1, [SP, #-0x10]!
    // 0x62f9fc: r0 = GDT[cid_x0 + 0x19df]()
    //     0x62f9fc: mov             x17, #0x19df
    //     0x62fa00: add             lr, x0, x17
    //     0x62fa04: ldr             lr, [x21, lr, lsl #3]
    //     0x62fa08: blr             lr
    // 0x62fa0c: add             SP, SP, #0x10
    // 0x62fa10: ldr             x16, [fp, #0x10]
    // 0x62fa14: stp             x0, x16, [SP, #-0x10]!
    // 0x62fa18: r0 = constrain()
    //     0x62fa18: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x62fa1c: add             SP, SP, #0x10
    // 0x62fa20: LeaveFrame
    //     0x62fa20: mov             SP, fp
    //     0x62fa24: ldp             fp, lr, [SP], #0x10
    // 0x62fa28: ret
    //     0x62fa28: ret             
    // 0x62fa2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62fa2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62fa30: b               #0x62f9e0
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x636154, size: 0x18
    // 0x636154: r4 = 0
    //     0x636154: mov             x4, #0
    // 0x636158: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x636158: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fba8] AnonymousClosure: (0x63616c), in [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::computeMinIntrinsicWidth (0x6361b8)
    //     0x63615c: ldr             x1, [x17, #0xba8]
    // 0x636160: r24 = BuildNonGenericMethodExtractorStub
    //     0x636160: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x636164: LoadField: r0 = r24->field_17
    //     0x636164: ldur            x0, [x24, #0x17]
    // 0x636168: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63616c, size: 0x4c
    // 0x63616c: EnterFrame
    //     0x63616c: stp             fp, lr, [SP, #-0x10]!
    //     0x636170: mov             fp, SP
    // 0x636174: ldr             x0, [fp, #0x18]
    // 0x636178: LoadField: r1 = r0->field_17
    //     0x636178: ldur            w1, [x0, #0x17]
    // 0x63617c: DecompressPointer r1
    //     0x63617c: add             x1, x1, HEAP, lsl #32
    // 0x636180: CheckStackOverflow
    //     0x636180: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x636184: cmp             SP, x16
    //     0x636188: b.ls            #0x6361b0
    // 0x63618c: LoadField: r0 = r1->field_f
    //     0x63618c: ldur            w0, [x1, #0xf]
    // 0x636190: DecompressPointer r0
    //     0x636190: add             x0, x0, HEAP, lsl #32
    // 0x636194: ldr             x16, [fp, #0x10]
    // 0x636198: stp             x16, x0, [SP, #-0x10]!
    // 0x63619c: r0 = computeMinIntrinsicWidth()
    //     0x63619c: bl              #0x6361b8  ; [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::computeMinIntrinsicWidth
    // 0x6361a0: add             SP, SP, #0x10
    // 0x6361a4: LeaveFrame
    //     0x6361a4: mov             SP, fp
    //     0x6361a8: ldp             fp, lr, [SP], #0x10
    // 0x6361ac: ret
    //     0x6361ac: ret             
    // 0x6361b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6361b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6361b4: b               #0x63618c
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0x6361b8, size: 0x120
    // 0x6361b8: EnterFrame
    //     0x6361b8: stp             fp, lr, [SP, #-0x10]!
    //     0x6361bc: mov             fp, SP
    // 0x6361c0: AllocStack(0x8)
    //     0x6361c0: sub             SP, SP, #8
    // 0x6361c4: d0 = inf
    //     0x6361c4: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x6361c8: CheckStackOverflow
    //     0x6361c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6361cc: cmp             SP, x16
    //     0x6361d0: b.ls            #0x6362c0
    // 0x6361d4: fcmp            d0, d0
    // 0x6361d8: b.eq            #0x6361e4
    // 0x6361dc: d1 = inf
    //     0x6361dc: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x6361e0: b               #0x6361e8
    // 0x6361e4: d1 = 0.000000
    //     0x6361e4: eor             v1.16b, v1.16b, v1.16b
    // 0x6361e8: ldr             x0, [fp, #0x10]
    // 0x6361ec: stur            d1, [fp, #-8]
    // 0x6361f0: r0 = BoxConstraints()
    //     0x6361f0: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x6361f4: ldur            d0, [fp, #-8]
    // 0x6361f8: StoreField: r0->field_7 = d0
    //     0x6361f8: stur            d0, [x0, #7]
    // 0x6361fc: d0 = inf
    //     0x6361fc: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x636200: StoreField: r0->field_f = d0
    //     0x636200: stur            d0, [x0, #0xf]
    // 0x636204: ldr             x1, [fp, #0x10]
    // 0x636208: LoadField: d1 = r1->field_7
    //     0x636208: ldur            d1, [x1, #7]
    // 0x63620c: fcmp            d1, d0
    // 0x636210: b.vs            #0x636218
    // 0x636214: b.eq            #0x636220
    // 0x636218: r1 = false
    //     0x636218: add             x1, NULL, #0x30  ; false
    // 0x63621c: b               #0x636224
    // 0x636220: r1 = true
    //     0x636220: add             x1, NULL, #0x20  ; true
    // 0x636224: tbz             w1, #4, #0x636230
    // 0x636228: mov             v0.16b, v1.16b
    // 0x63622c: b               #0x636234
    // 0x636230: d0 = 0.000000
    //     0x636230: eor             v0.16b, v0.16b, v0.16b
    // 0x636234: StoreField: r0->field_17 = d0
    //     0x636234: stur            d0, [x0, #0x17]
    // 0x636238: tbz             w1, #4, #0x636244
    // 0x63623c: mov             v0.16b, v1.16b
    // 0x636240: b               #0x636248
    // 0x636244: d0 = inf
    //     0x636244: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x636248: StoreField: r0->field_1f = d0
    //     0x636248: stur            d0, [x0, #0x1f]
    // 0x63624c: ldr             x16, [fp, #0x18]
    // 0x636250: stp             x0, x16, [SP, #-0x10]!
    // 0x636254: r0 = _getSize()
    //     0x636254: bl              #0x62f9cc  ; [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::_getSize
    // 0x636258: add             SP, SP, #0x10
    // 0x63625c: LoadField: d0 = r0->field_7
    //     0x63625c: ldur            d0, [x0, #7]
    // 0x636260: mov             x1, v0.d[0]
    // 0x636264: and             x1, x1, #0x7fffffffffffffff
    // 0x636268: r17 = 9218868437227405312
    //     0x636268: mov             x17, #0x7ff0000000000000
    // 0x63626c: cmp             x1, x17
    // 0x636270: b.eq            #0x6362b0
    // 0x636274: fcmp            d0, d0
    // 0x636278: b.vs            #0x6362b0
    // 0x63627c: r0 = inline_Allocate_Double()
    //     0x63627c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x636280: add             x0, x0, #0x10
    //     0x636284: cmp             x1, x0
    //     0x636288: b.ls            #0x6362c8
    //     0x63628c: str             x0, [THR, #0x60]  ; THR::top
    //     0x636290: sub             x0, x0, #0xf
    //     0x636294: mov             x1, #0xd108
    //     0x636298: movk            x1, #3, lsl #16
    //     0x63629c: stur            x1, [x0, #-1]
    // 0x6362a0: StoreField: r0->field_7 = d0
    //     0x6362a0: stur            d0, [x0, #7]
    // 0x6362a4: LeaveFrame
    //     0x6362a4: mov             SP, fp
    //     0x6362a8: ldp             fp, lr, [SP], #0x10
    // 0x6362ac: ret
    //     0x6362ac: ret             
    // 0x6362b0: r0 = 0.000000
    //     0x6362b0: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x6362b4: LeaveFrame
    //     0x6362b4: mov             SP, fp
    //     0x6362b8: ldp             fp, lr, [SP], #0x10
    // 0x6362bc: ret
    //     0x6362bc: ret             
    // 0x6362c0: r0 = StackOverflowSharedWithFPURegs()
    //     0x6362c0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x6362c4: b               #0x6361d4
    // 0x6362c8: SaveReg d0
    //     0x6362c8: str             q0, [SP, #-0x10]!
    // 0x6362cc: r0 = AllocateDouble()
    //     0x6362cc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6362d0: RestoreReg d0
    //     0x6362d0: ldr             q0, [SP], #0x10
    // 0x6362d4: b               #0x6362a0
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x6362d8, size: 0x4c
    // 0x6362d8: EnterFrame
    //     0x6362d8: stp             fp, lr, [SP, #-0x10]!
    //     0x6362dc: mov             fp, SP
    // 0x6362e0: ldr             x0, [fp, #0x18]
    // 0x6362e4: LoadField: r1 = r0->field_17
    //     0x6362e4: ldur            w1, [x0, #0x17]
    // 0x6362e8: DecompressPointer r1
    //     0x6362e8: add             x1, x1, HEAP, lsl #32
    // 0x6362ec: CheckStackOverflow
    //     0x6362ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6362f0: cmp             SP, x16
    //     0x6362f4: b.ls            #0x63631c
    // 0x6362f8: LoadField: r0 = r1->field_f
    //     0x6362f8: ldur            w0, [x1, #0xf]
    // 0x6362fc: DecompressPointer r0
    //     0x6362fc: add             x0, x0, HEAP, lsl #32
    // 0x636300: ldr             x16, [fp, #0x10]
    // 0x636304: stp             x16, x0, [SP, #-0x10]!
    // 0x636308: r0 = computeMinIntrinsicWidth()
    //     0x636308: bl              #0x6361b8  ; [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::computeMinIntrinsicWidth
    // 0x63630c: add             SP, SP, #0x10
    // 0x636310: LeaveFrame
    //     0x636310: mov             SP, fp
    //     0x636314: ldp             fp, lr, [SP], #0x10
    // 0x636318: ret
    //     0x636318: ret             
    // 0x63631c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63631c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x636320: b               #0x6362f8
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x6393a0, size: 0x18
    // 0x6393a0: r4 = 0
    //     0x6393a0: mov             x4, #0
    // 0x6393a4: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x6393a4: add             x17, PP, #0x52, lsl #12  ; [pp+0x52e68] AnonymousClosure: (0x62f980), in [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::computeMinIntrinsicHeight (0x62f858)
    //     0x6393a8: ldr             x1, [x17, #0xe68]
    // 0x6393ac: r24 = BuildNonGenericMethodExtractorStub
    //     0x6393ac: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x6393b0: LoadField: r0 = r24->field_17
    //     0x6393b0: ldur            x0, [x24, #0x17]
    // 0x6393b4: br              x0
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63bfdc, size: 0x18
    // 0x63bfdc: r4 = 0
    //     0x63bfdc: mov             x4, #0
    // 0x63bfe0: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63bfe0: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fcd8] AnonymousClosure: (0x6362d8), in [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::computeMinIntrinsicWidth (0x6361b8)
    //     0x63bfe4: ldr             x1, [x17, #0xcd8]
    // 0x63bfe8: r24 = BuildNonGenericMethodExtractorStub
    //     0x63bfe8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63bfec: LoadField: r0 = r24->field_17
    //     0x63bfec: ldur            x0, [x24, #0x17]
    // 0x63bff0: br              x0
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x6931e4, size: 0x358
    // 0x6931e4: EnterFrame
    //     0x6931e4: stp             fp, lr, [SP, #-0x10]!
    //     0x6931e8: mov             fp, SP
    // 0x6931ec: AllocStack(0x38)
    //     0x6931ec: sub             SP, SP, #0x38
    // 0x6931f0: CheckStackOverflow
    //     0x6931f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6931f4: cmp             SP, x16
    //     0x6931f8: b.ls            #0x693520
    // 0x6931fc: ldr             x3, [fp, #0x10]
    // 0x693200: LoadField: r4 = r3->field_27
    //     0x693200: ldur            w4, [x3, #0x27]
    // 0x693204: DecompressPointer r4
    //     0x693204: add             x4, x4, HEAP, lsl #32
    // 0x693208: stur            x4, [fp, #-8]
    // 0x69320c: cmp             w4, NULL
    // 0x693210: b.eq            #0x6934e8
    // 0x693214: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x693214: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x693218: ldr             x5, [x5, #0x1e8]
    // 0x69321c: mov             x0, x4
    // 0x693220: r2 = Null
    //     0x693220: mov             x2, NULL
    // 0x693224: r1 = Null
    //     0x693224: mov             x1, NULL
    // 0x693228: r4 = LoadClassIdInstr(r0)
    //     0x693228: ldur            x4, [x0, #-1]
    //     0x69322c: ubfx            x4, x4, #0xc, #0x14
    // 0x693230: sub             x4, x4, #0x80d
    // 0x693234: cmp             x4, #1
    // 0x693238: b.ls            #0x693250
    // 0x69323c: r8 = BoxConstraints
    //     0x69323c: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x693240: ldr             x8, [x8, #0x1d0]
    // 0x693244: r3 = Null
    //     0x693244: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3fbb0] Null
    //     0x693248: ldr             x3, [x3, #0xbb0]
    // 0x69324c: r0 = BoxConstraints()
    //     0x69324c: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x693250: ldr             x16, [fp, #0x10]
    // 0x693254: ldur            lr, [fp, #-8]
    // 0x693258: stp             lr, x16, [SP, #-0x10]!
    // 0x69325c: r0 = _getSize()
    //     0x69325c: bl              #0x62f9cc  ; [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::_getSize
    // 0x693260: add             SP, SP, #0x10
    // 0x693264: ldr             x3, [fp, #0x10]
    // 0x693268: StoreField: r3->field_57 = r0
    //     0x693268: stur            w0, [x3, #0x57]
    //     0x69326c: ldurb           w16, [x3, #-1]
    //     0x693270: ldurb           w17, [x0, #-1]
    //     0x693274: and             x16, x17, x16, lsr #2
    //     0x693278: tst             x16, HEAP, lsr #32
    //     0x69327c: b.eq            #0x693284
    //     0x693280: bl              #0xd682ac
    // 0x693284: LoadField: r0 = r3->field_5f
    //     0x693284: ldur            w0, [x3, #0x5f]
    // 0x693288: DecompressPointer r0
    //     0x693288: add             x0, x0, HEAP, lsl #32
    // 0x69328c: cmp             w0, NULL
    // 0x693290: b.eq            #0x6934d8
    // 0x693294: LoadField: r4 = r3->field_63
    //     0x693294: ldur            w4, [x3, #0x63]
    // 0x693298: DecompressPointer r4
    //     0x693298: add             x4, x4, HEAP, lsl #32
    // 0x69329c: stur            x4, [fp, #-0x10]
    // 0x6932a0: LoadField: r5 = r3->field_27
    //     0x6932a0: ldur            w5, [x3, #0x27]
    // 0x6932a4: DecompressPointer r5
    //     0x6932a4: add             x5, x5, HEAP, lsl #32
    // 0x6932a8: stur            x5, [fp, #-8]
    // 0x6932ac: cmp             w5, NULL
    // 0x6932b0: b.eq            #0x693500
    // 0x6932b4: mov             x0, x5
    // 0x6932b8: r2 = Null
    //     0x6932b8: mov             x2, NULL
    // 0x6932bc: r1 = Null
    //     0x6932bc: mov             x1, NULL
    // 0x6932c0: r4 = LoadClassIdInstr(r0)
    //     0x6932c0: ldur            x4, [x0, #-1]
    //     0x6932c4: ubfx            x4, x4, #0xc, #0x14
    // 0x6932c8: sub             x4, x4, #0x80d
    // 0x6932cc: cmp             x4, #1
    // 0x6932d0: b.ls            #0x6932e8
    // 0x6932d4: r8 = BoxConstraints
    //     0x6932d4: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x6932d8: ldr             x8, [x8, #0x1d0]
    // 0x6932dc: r3 = Null
    //     0x6932dc: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3fbc0] Null
    //     0x6932e0: ldr             x3, [x3, #0xbc0]
    // 0x6932e4: r0 = BoxConstraints()
    //     0x6932e4: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x6932e8: ldur            x0, [fp, #-0x10]
    // 0x6932ec: r1 = LoadClassIdInstr(r0)
    //     0x6932ec: ldur            x1, [x0, #-1]
    //     0x6932f0: ubfx            x1, x1, #0xc, #0x14
    // 0x6932f4: ldur            x16, [fp, #-8]
    // 0x6932f8: stp             x16, x0, [SP, #-0x10]!
    // 0x6932fc: mov             x0, x1
    // 0x693300: r0 = GDT[cid_x0 + 0x1985]()
    //     0x693300: mov             x17, #0x1985
    //     0x693304: add             lr, x0, x17
    //     0x693308: ldr             lr, [x21, lr, lsl #3]
    //     0x69330c: blr             lr
    // 0x693310: add             SP, SP, #0x10
    // 0x693314: mov             x2, x0
    // 0x693318: ldr             x1, [fp, #0x10]
    // 0x69331c: stur            x2, [fp, #-8]
    // 0x693320: LoadField: r0 = r1->field_5f
    //     0x693320: ldur            w0, [x1, #0x5f]
    // 0x693324: DecompressPointer r0
    //     0x693324: add             x0, x0, HEAP, lsl #32
    // 0x693328: cmp             w0, NULL
    // 0x69332c: b.eq            #0x693528
    // 0x693330: LoadField: d0 = r2->field_7
    //     0x693330: ldur            d0, [x2, #7]
    // 0x693334: stur            d0, [fp, #-0x38]
    // 0x693338: LoadField: d1 = r2->field_f
    //     0x693338: ldur            d1, [x2, #0xf]
    // 0x69333c: stur            d1, [fp, #-0x30]
    // 0x693340: fcmp            d0, d1
    // 0x693344: b.vs            #0x693370
    // 0x693348: b.lt            #0x693370
    // 0x69334c: LoadField: d2 = r2->field_17
    //     0x69334c: ldur            d2, [x2, #0x17]
    // 0x693350: LoadField: d3 = r2->field_1f
    //     0x693350: ldur            d3, [x2, #0x1f]
    // 0x693354: fcmp            d2, d3
    // 0x693358: b.vs            #0x693360
    // 0x69335c: b.ge            #0x693368
    // 0x693360: r3 = false
    //     0x693360: add             x3, NULL, #0x30  ; false
    // 0x693364: b               #0x69336c
    // 0x693368: r3 = true
    //     0x693368: add             x3, NULL, #0x20  ; true
    // 0x69336c: b               #0x693374
    // 0x693370: r3 = false
    //     0x693370: add             x3, NULL, #0x30  ; false
    // 0x693374: eor             x4, x3, #0x10
    // 0x693378: r3 = LoadClassIdInstr(r0)
    //     0x693378: ldur            x3, [x0, #-1]
    //     0x69337c: ubfx            x3, x3, #0xc, #0x14
    // 0x693380: stp             x2, x0, [SP, #-0x10]!
    // 0x693384: SaveReg r4
    //     0x693384: str             x4, [SP, #-8]!
    // 0x693388: mov             x0, x3
    // 0x69338c: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x69338c: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x693390: ldr             x4, [x4, #0x1c8]
    // 0x693394: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x693394: mov             x17, #0xcdfb
    //     0x693398: add             lr, x0, x17
    //     0x69339c: ldr             lr, [x21, lr, lsl #3]
    //     0x6933a0: blr             lr
    // 0x6933a4: add             SP, SP, #0x18
    // 0x6933a8: ldr             x3, [fp, #0x10]
    // 0x6933ac: LoadField: r4 = r3->field_5f
    //     0x6933ac: ldur            w4, [x3, #0x5f]
    // 0x6933b0: DecompressPointer r4
    //     0x6933b0: add             x4, x4, HEAP, lsl #32
    // 0x6933b4: stur            x4, [fp, #-0x18]
    // 0x6933b8: cmp             w4, NULL
    // 0x6933bc: b.eq            #0x69352c
    // 0x6933c0: LoadField: r5 = r4->field_17
    //     0x6933c0: ldur            w5, [x4, #0x17]
    // 0x6933c4: DecompressPointer r5
    //     0x6933c4: add             x5, x5, HEAP, lsl #32
    // 0x6933c8: stur            x5, [fp, #-0x10]
    // 0x6933cc: cmp             w5, NULL
    // 0x6933d0: b.eq            #0x693530
    // 0x6933d4: mov             x0, x5
    // 0x6933d8: r2 = Null
    //     0x6933d8: mov             x2, NULL
    // 0x6933dc: r1 = Null
    //     0x6933dc: mov             x1, NULL
    // 0x6933e0: r4 = LoadClassIdInstr(r0)
    //     0x6933e0: ldur            x4, [x0, #-1]
    //     0x6933e4: ubfx            x4, x4, #0xc, #0x14
    // 0x6933e8: sub             x4, x4, #0x7ff
    // 0x6933ec: cmp             x4, #0xb
    // 0x6933f0: b.ls            #0x693408
    // 0x6933f4: r8 = BoxParentData
    //     0x6933f4: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x6933f8: ldr             x8, [x8, #0x1b0]
    // 0x6933fc: r3 = Null
    //     0x6933fc: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3fbd0] Null
    //     0x693400: ldr             x3, [x3, #0xbd0]
    // 0x693404: r0 = DefaultTypeTest()
    //     0x693404: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x693408: ldr             x0, [fp, #0x10]
    // 0x69340c: LoadField: r1 = r0->field_63
    //     0x69340c: ldur            w1, [x0, #0x63]
    // 0x693410: DecompressPointer r1
    //     0x693410: add             x1, x1, HEAP, lsl #32
    // 0x693414: stur            x1, [fp, #-0x28]
    // 0x693418: LoadField: r2 = r0->field_57
    //     0x693418: ldur            w2, [x0, #0x57]
    // 0x69341c: DecompressPointer r2
    //     0x69341c: add             x2, x2, HEAP, lsl #32
    // 0x693420: stur            x2, [fp, #-0x20]
    // 0x693424: cmp             w2, NULL
    // 0x693428: b.eq            #0x693534
    // 0x69342c: ldur            d0, [fp, #-0x38]
    // 0x693430: ldur            d1, [fp, #-0x30]
    // 0x693434: fcmp            d0, d1
    // 0x693438: b.vs            #0x69346c
    // 0x69343c: b.lt            #0x69346c
    // 0x693440: ldur            x0, [fp, #-8]
    // 0x693444: LoadField: d0 = r0->field_17
    //     0x693444: ldur            d0, [x0, #0x17]
    // 0x693448: LoadField: d1 = r0->field_1f
    //     0x693448: ldur            d1, [x0, #0x1f]
    // 0x69344c: fcmp            d0, d1
    // 0x693450: b.vs            #0x69346c
    // 0x693454: b.lt            #0x69346c
    // 0x693458: SaveReg r0
    //     0x693458: str             x0, [SP, #-8]!
    // 0x69345c: r0 = smallest()
    //     0x69345c: bl              #0x62bd18  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0x693460: add             SP, SP, #8
    // 0x693464: mov             x2, x0
    // 0x693468: b               #0x693484
    // 0x69346c: ldur            x0, [fp, #-0x18]
    // 0x693470: LoadField: r1 = r0->field_57
    //     0x693470: ldur            w1, [x0, #0x57]
    // 0x693474: DecompressPointer r1
    //     0x693474: add             x1, x1, HEAP, lsl #32
    // 0x693478: cmp             w1, NULL
    // 0x69347c: b.eq            #0x693538
    // 0x693480: mov             x2, x1
    // 0x693484: ldur            x1, [fp, #-0x10]
    // 0x693488: ldur            x0, [fp, #-0x28]
    // 0x69348c: r3 = LoadClassIdInstr(r0)
    //     0x69348c: ldur            x3, [x0, #-1]
    //     0x693490: ubfx            x3, x3, #0xc, #0x14
    // 0x693494: ldur            x16, [fp, #-0x20]
    // 0x693498: stp             x16, x0, [SP, #-0x10]!
    // 0x69349c: SaveReg r2
    //     0x69349c: str             x2, [SP, #-8]!
    // 0x6934a0: mov             x0, x3
    // 0x6934a4: r0 = GDT[cid_x0 + 0x22a4]()
    //     0x6934a4: mov             x17, #0x22a4
    //     0x6934a8: add             lr, x0, x17
    //     0x6934ac: ldr             lr, [x21, lr, lsl #3]
    //     0x6934b0: blr             lr
    // 0x6934b4: add             SP, SP, #0x18
    // 0x6934b8: ldur            x1, [fp, #-0x10]
    // 0x6934bc: StoreField: r1->field_7 = r0
    //     0x6934bc: stur            w0, [x1, #7]
    //     0x6934c0: ldurb           w16, [x1, #-1]
    //     0x6934c4: ldurb           w17, [x0, #-1]
    //     0x6934c8: and             x16, x17, x16, lsr #2
    //     0x6934cc: tst             x16, HEAP, lsr #32
    //     0x6934d0: b.eq            #0x6934d8
    //     0x6934d4: bl              #0xd6826c
    // 0x6934d8: r0 = Null
    //     0x6934d8: mov             x0, NULL
    // 0x6934dc: LeaveFrame
    //     0x6934dc: mov             SP, fp
    //     0x6934e0: ldp             fp, lr, [SP], #0x10
    // 0x6934e4: ret
    //     0x6934e4: ret             
    // 0x6934e8: r0 = StateError()
    //     0x6934e8: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6934ec: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6934ec: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6934f0: ldr             x5, [x5, #0x1e8]
    // 0x6934f4: StoreField: r0->field_b = r5
    //     0x6934f4: stur            w5, [x0, #0xb]
    // 0x6934f8: r0 = Throw()
    //     0x6934f8: bl              #0xd67e38  ; ThrowStub
    // 0x6934fc: brk             #0
    // 0x693500: r0 = StateError()
    //     0x693500: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x693504: mov             x1, x0
    // 0x693508: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x693508: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x69350c: ldr             x0, [x0, #0x1e8]
    // 0x693510: StoreField: r1->field_b = r0
    //     0x693510: stur            w0, [x1, #0xb]
    // 0x693514: mov             x0, x1
    // 0x693518: r0 = Throw()
    //     0x693518: bl              #0xd67e38  ; ThrowStub
    // 0x69351c: brk             #0
    // 0x693520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x693520: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x693524: b               #0x6931fc
    // 0x693528: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x693528: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69352c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69352c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x693530: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x693530: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x693534: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x693534: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x693538: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x693538: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ delegate=(/* No info */) {
    // ** addr: 0x6c581c, size: 0xcc
    // 0x6c581c: EnterFrame
    //     0x6c581c: stp             fp, lr, [SP, #-0x10]!
    //     0x6c5820: mov             fp, SP
    // 0x6c5824: AllocStack(0x8)
    //     0x6c5824: sub             SP, SP, #8
    // 0x6c5828: CheckStackOverflow
    //     0x6c5828: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c582c: cmp             SP, x16
    //     0x6c5830: b.ls            #0x6c58e0
    // 0x6c5834: ldr             x0, [fp, #0x18]
    // 0x6c5838: LoadField: r1 = r0->field_63
    //     0x6c5838: ldur            w1, [x0, #0x63]
    // 0x6c583c: DecompressPointer r1
    //     0x6c583c: add             x1, x1, HEAP, lsl #32
    // 0x6c5840: ldr             x2, [fp, #0x10]
    // 0x6c5844: stur            x1, [fp, #-8]
    // 0x6c5848: cmp             w1, w2
    // 0x6c584c: b.ne            #0x6c5860
    // 0x6c5850: r0 = Null
    //     0x6c5850: mov             x0, NULL
    // 0x6c5854: LeaveFrame
    //     0x6c5854: mov             SP, fp
    //     0x6c5858: ldp             fp, lr, [SP], #0x10
    // 0x6c585c: ret
    //     0x6c585c: ret             
    // 0x6c5860: stp             x1, x2, [SP, #-0x10]!
    // 0x6c5864: r0 = _haveSameRuntimeType()
    //     0x6c5864: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0x6c5868: add             SP, SP, #0x10
    // 0x6c586c: tbnz            w0, #4, #0x6c589c
    // 0x6c5870: ldr             x1, [fp, #0x10]
    // 0x6c5874: r0 = LoadClassIdInstr(r1)
    //     0x6c5874: ldur            x0, [x1, #-1]
    //     0x6c5878: ubfx            x0, x0, #0xc, #0x14
    // 0x6c587c: ldur            x16, [fp, #-8]
    // 0x6c5880: stp             x16, x1, [SP, #-0x10]!
    // 0x6c5884: r0 = GDT[cid_x0 + 0x2541]()
    //     0x6c5884: mov             x17, #0x2541
    //     0x6c5888: add             lr, x0, x17
    //     0x6c588c: ldr             lr, [x21, lr, lsl #3]
    //     0x6c5890: blr             lr
    // 0x6c5894: add             SP, SP, #0x10
    // 0x6c5898: tbnz            w0, #4, #0x6c58ac
    // 0x6c589c: ldr             x16, [fp, #0x18]
    // 0x6c58a0: SaveReg r16
    //     0x6c58a0: str             x16, [SP, #-8]!
    // 0x6c58a4: r0 = markNeedsLayout()
    //     0x6c58a4: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c58a8: add             SP, SP, #8
    // 0x6c58ac: ldr             x1, [fp, #0x18]
    // 0x6c58b0: ldr             x0, [fp, #0x10]
    // 0x6c58b4: StoreField: r1->field_63 = r0
    //     0x6c58b4: stur            w0, [x1, #0x63]
    //     0x6c58b8: ldurb           w16, [x1, #-1]
    //     0x6c58bc: ldurb           w17, [x0, #-1]
    //     0x6c58c0: and             x16, x17, x16, lsr #2
    //     0x6c58c4: tst             x16, HEAP, lsr #32
    //     0x6c58c8: b.eq            #0x6c58d0
    //     0x6c58cc: bl              #0xd6826c
    // 0x6c58d0: r0 = Null
    //     0x6c58d0: mov             x0, NULL
    // 0x6c58d4: LeaveFrame
    //     0x6c58d4: mov             SP, fp
    //     0x6c58d8: ldp             fp, lr, [SP], #0x10
    // 0x6c58dc: ret
    //     0x6c58dc: ret             
    // 0x6c58e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c58e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c58e4: b               #0x6c5834
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bd600, size: 0x74
    // 0x9bd600: EnterFrame
    //     0x9bd600: stp             fp, lr, [SP, #-0x10]!
    //     0x9bd604: mov             fp, SP
    // 0x9bd608: CheckStackOverflow
    //     0x9bd608: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bd60c: cmp             SP, x16
    //     0x9bd610: b.ls            #0x9bd66c
    // 0x9bd614: ldr             x0, [fp, #0x10]
    // 0x9bd618: r2 = Null
    //     0x9bd618: mov             x2, NULL
    // 0x9bd61c: r1 = Null
    //     0x9bd61c: mov             x1, NULL
    // 0x9bd620: r4 = 59
    //     0x9bd620: mov             x4, #0x3b
    // 0x9bd624: branchIfSmi(r0, 0x9bd630)
    //     0x9bd624: tbz             w0, #0, #0x9bd630
    // 0x9bd628: r4 = LoadClassIdInstr(r0)
    //     0x9bd628: ldur            x4, [x0, #-1]
    //     0x9bd62c: ubfx            x4, x4, #0xc, #0x14
    // 0x9bd630: cmp             x4, #0x7e6
    // 0x9bd634: b.eq            #0x9bd648
    // 0x9bd638: r8 = PipelineOwner
    //     0x9bd638: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9bd63c: r3 = Null
    //     0x9bd63c: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3fbe0] Null
    //     0x9bd640: ldr             x3, [x3, #0xbe0]
    // 0x9bd644: r0 = DefaultTypeTest()
    //     0x9bd644: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bd648: ldr             x16, [fp, #0x18]
    // 0x9bd64c: ldr             lr, [fp, #0x10]
    // 0x9bd650: stp             lr, x16, [SP, #-0x10]!
    // 0x9bd654: r0 = attach()
    //     0x9bd654: bl              #0x9bd674  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::attach
    // 0x9bd658: add             SP, SP, #0x10
    // 0x9bd65c: r0 = Null
    //     0x9bd65c: mov             x0, NULL
    // 0x9bd660: LeaveFrame
    //     0x9bd660: mov             SP, fp
    //     0x9bd664: ldp             fp, lr, [SP], #0x10
    // 0x9bd668: ret
    //     0x9bd668: ret             
    // 0x9bd66c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bd66c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bd670: b               #0x9bd614
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5e54c, size: 0x3c
    // 0xa5e54c: EnterFrame
    //     0xa5e54c: stp             fp, lr, [SP, #-0x10]!
    //     0xa5e550: mov             fp, SP
    // 0xa5e554: CheckStackOverflow
    //     0xa5e554: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5e558: cmp             SP, x16
    //     0xa5e55c: b.ls            #0xa5e580
    // 0xa5e560: ldr             x16, [fp, #0x18]
    // 0xa5e564: ldr             lr, [fp, #0x10]
    // 0xa5e568: stp             lr, x16, [SP, #-0x10]!
    // 0xa5e56c: r0 = _getSize()
    //     0xa5e56c: bl              #0x62f9cc  ; [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::_getSize
    // 0xa5e570: add             SP, SP, #0x10
    // 0xa5e574: LeaveFrame
    //     0xa5e574: mov             SP, fp
    //     0xa5e578: ldp             fp, lr, [SP], #0x10
    // 0xa5e57c: ret
    //     0xa5e57c: ret             
    // 0xa5e580: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5e580: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5e584: b               #0xa5e560
  }
  _ detach(/* No info */) {
    // ** addr: 0xa693a4, size: 0x3c
    // 0xa693a4: EnterFrame
    //     0xa693a4: stp             fp, lr, [SP, #-0x10]!
    //     0xa693a8: mov             fp, SP
    // 0xa693ac: CheckStackOverflow
    //     0xa693ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa693b0: cmp             SP, x16
    //     0xa693b4: b.ls            #0xa693d8
    // 0xa693b8: ldr             x16, [fp, #0x10]
    // 0xa693bc: SaveReg r16
    //     0xa693bc: str             x16, [SP, #-8]!
    // 0xa693c0: r0 = detach()
    //     0xa693c0: bl              #0xa693e0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::detach
    // 0xa693c4: add             SP, SP, #8
    // 0xa693c8: r0 = Null
    //     0xa693c8: mov             x0, NULL
    // 0xa693cc: LeaveFrame
    //     0xa693cc: mov             SP, fp
    //     0xa693d0: ldp             fp, lr, [SP], #0x10
    // 0xa693d4: ret
    //     0xa693d4: ret             
    // 0xa693d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa693d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa693dc: b               #0xa693b8
  }
}

// class id: 2460, size: 0x70, field offset: 0x64
class RenderPadding extends RenderShiftedBox {

  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x62f558, size: 0x18
    // 0x62f558: r4 = 0
    //     0x62f558: mov             x4, #0
    // 0x62f55c: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x62f55c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b1d8] AnonymousClosure: (0x62f570), in [package:flutter/src/rendering/shifted_box.dart] RenderPadding::computeMaxIntrinsicHeight (0x62f5bc)
    //     0x62f560: ldr             x1, [x17, #0x1d8]
    // 0x62f564: r24 = BuildNonGenericMethodExtractorStub
    //     0x62f564: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x62f568: LoadField: r0 = r24->field_17
    //     0x62f568: ldur            x0, [x24, #0x17]
    // 0x62f56c: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x62f570, size: 0x4c
    // 0x62f570: EnterFrame
    //     0x62f570: stp             fp, lr, [SP, #-0x10]!
    //     0x62f574: mov             fp, SP
    // 0x62f578: ldr             x0, [fp, #0x18]
    // 0x62f57c: LoadField: r1 = r0->field_17
    //     0x62f57c: ldur            w1, [x0, #0x17]
    // 0x62f580: DecompressPointer r1
    //     0x62f580: add             x1, x1, HEAP, lsl #32
    // 0x62f584: CheckStackOverflow
    //     0x62f584: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62f588: cmp             SP, x16
    //     0x62f58c: b.ls            #0x62f5b4
    // 0x62f590: LoadField: r0 = r1->field_f
    //     0x62f590: ldur            w0, [x1, #0xf]
    // 0x62f594: DecompressPointer r0
    //     0x62f594: add             x0, x0, HEAP, lsl #32
    // 0x62f598: ldr             x16, [fp, #0x10]
    // 0x62f59c: stp             x16, x0, [SP, #-0x10]!
    // 0x62f5a0: r0 = computeMaxIntrinsicHeight()
    //     0x62f5a0: bl              #0x62f5bc  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::computeMaxIntrinsicHeight
    // 0x62f5a4: add             SP, SP, #0x10
    // 0x62f5a8: LeaveFrame
    //     0x62f5a8: mov             SP, fp
    //     0x62f5ac: ldp             fp, lr, [SP], #0x10
    // 0x62f5b0: ret
    //     0x62f5b0: ret             
    // 0x62f5b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62f5b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62f5b8: b               #0x62f590
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0x62f5bc, size: 0x180
    // 0x62f5bc: EnterFrame
    //     0x62f5bc: stp             fp, lr, [SP, #-0x10]!
    //     0x62f5c0: mov             fp, SP
    // 0x62f5c4: AllocStack(0x8)
    //     0x62f5c4: sub             SP, SP, #8
    // 0x62f5c8: CheckStackOverflow
    //     0x62f5c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62f5cc: cmp             SP, x16
    //     0x62f5d0: b.ls            #0x62f710
    // 0x62f5d4: ldr             x16, [fp, #0x18]
    // 0x62f5d8: SaveReg r16
    //     0x62f5d8: str             x16, [SP, #-8]!
    // 0x62f5dc: r0 = _resolve()
    //     0x62f5dc: bl              #0x62f73c  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::_resolve
    // 0x62f5e0: add             SP, SP, #8
    // 0x62f5e4: ldr             x0, [fp, #0x18]
    // 0x62f5e8: LoadField: r1 = r0->field_63
    //     0x62f5e8: ldur            w1, [x0, #0x63]
    // 0x62f5ec: DecompressPointer r1
    //     0x62f5ec: add             x1, x1, HEAP, lsl #32
    // 0x62f5f0: cmp             w1, NULL
    // 0x62f5f4: b.eq            #0x62f718
    // 0x62f5f8: LoadField: d0 = r1->field_7
    //     0x62f5f8: ldur            d0, [x1, #7]
    // 0x62f5fc: LoadField: d1 = r1->field_17
    //     0x62f5fc: ldur            d1, [x1, #0x17]
    // 0x62f600: fadd            d2, d0, d1
    // 0x62f604: LoadField: d0 = r1->field_f
    //     0x62f604: ldur            d0, [x1, #0xf]
    // 0x62f608: LoadField: d1 = r1->field_1f
    //     0x62f608: ldur            d1, [x1, #0x1f]
    // 0x62f60c: fadd            d3, d0, d1
    // 0x62f610: stur            d3, [fp, #-8]
    // 0x62f614: LoadField: r1 = r0->field_5f
    //     0x62f614: ldur            w1, [x0, #0x5f]
    // 0x62f618: DecompressPointer r1
    //     0x62f618: add             x1, x1, HEAP, lsl #32
    // 0x62f61c: cmp             w1, NULL
    // 0x62f620: b.eq            #0x62f6d8
    // 0x62f624: ldr             x0, [fp, #0x10]
    // 0x62f628: d0 = 0.000000
    //     0x62f628: eor             v0.16b, v0.16b, v0.16b
    // 0x62f62c: LoadField: d1 = r0->field_7
    //     0x62f62c: ldur            d1, [x0, #7]
    // 0x62f630: fsub            d4, d1, d2
    // 0x62f634: fcmp            d0, d4
    // 0x62f638: b.vs            #0x62f648
    // 0x62f63c: b.le            #0x62f648
    // 0x62f640: d0 = 0.000000
    //     0x62f640: eor             v0.16b, v0.16b, v0.16b
    // 0x62f644: b               #0x62f688
    // 0x62f648: fcmp            d0, d4
    // 0x62f64c: b.vs            #0x62f65c
    // 0x62f650: b.ge            #0x62f65c
    // 0x62f654: mov             v0.16b, v4.16b
    // 0x62f658: b               #0x62f688
    // 0x62f65c: fcmp            d0, d0
    // 0x62f660: b.vs            #0x62f674
    // 0x62f664: b.ne            #0x62f674
    // 0x62f668: fadd            d1, d0, d4
    // 0x62f66c: mov             v0.16b, v1.16b
    // 0x62f670: b               #0x62f688
    // 0x62f674: fcmp            d4, d4
    // 0x62f678: b.vc            #0x62f684
    // 0x62f67c: mov             v0.16b, v4.16b
    // 0x62f680: b               #0x62f688
    // 0x62f684: d0 = 0.000000
    //     0x62f684: eor             v0.16b, v0.16b, v0.16b
    // 0x62f688: SaveReg r1
    //     0x62f688: str             x1, [SP, #-8]!
    // 0x62f68c: SaveReg d0
    //     0x62f68c: str             d0, [SP, #-8]!
    // 0x62f690: r0 = getMaxIntrinsicHeight()
    //     0x62f690: bl              #0x62cb24  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0x62f694: add             SP, SP, #0x10
    // 0x62f698: mov             v1.16b, v0.16b
    // 0x62f69c: ldur            d0, [fp, #-8]
    // 0x62f6a0: fadd            d2, d1, d0
    // 0x62f6a4: r0 = inline_Allocate_Double()
    //     0x62f6a4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62f6a8: add             x0, x0, #0x10
    //     0x62f6ac: cmp             x1, x0
    //     0x62f6b0: b.ls            #0x62f71c
    //     0x62f6b4: str             x0, [THR, #0x60]  ; THR::top
    //     0x62f6b8: sub             x0, x0, #0xf
    //     0x62f6bc: mov             x1, #0xd108
    //     0x62f6c0: movk            x1, #3, lsl #16
    //     0x62f6c4: stur            x1, [x0, #-1]
    // 0x62f6c8: StoreField: r0->field_7 = d2
    //     0x62f6c8: stur            d2, [x0, #7]
    // 0x62f6cc: LeaveFrame
    //     0x62f6cc: mov             SP, fp
    //     0x62f6d0: ldp             fp, lr, [SP], #0x10
    // 0x62f6d4: ret
    //     0x62f6d4: ret             
    // 0x62f6d8: mov             v0.16b, v3.16b
    // 0x62f6dc: r0 = inline_Allocate_Double()
    //     0x62f6dc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62f6e0: add             x0, x0, #0x10
    //     0x62f6e4: cmp             x1, x0
    //     0x62f6e8: b.ls            #0x62f72c
    //     0x62f6ec: str             x0, [THR, #0x60]  ; THR::top
    //     0x62f6f0: sub             x0, x0, #0xf
    //     0x62f6f4: mov             x1, #0xd108
    //     0x62f6f8: movk            x1, #3, lsl #16
    //     0x62f6fc: stur            x1, [x0, #-1]
    // 0x62f700: StoreField: r0->field_7 = d0
    //     0x62f700: stur            d0, [x0, #7]
    // 0x62f704: LeaveFrame
    //     0x62f704: mov             SP, fp
    //     0x62f708: ldp             fp, lr, [SP], #0x10
    // 0x62f70c: ret
    //     0x62f70c: ret             
    // 0x62f710: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62f710: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62f714: b               #0x62f5d4
    // 0x62f718: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x62f718: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x62f71c: SaveReg d2
    //     0x62f71c: str             q2, [SP, #-0x10]!
    // 0x62f720: r0 = AllocateDouble()
    //     0x62f720: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62f724: RestoreReg d2
    //     0x62f724: ldr             q2, [SP], #0x10
    // 0x62f728: b               #0x62f6c8
    // 0x62f72c: SaveReg d0
    //     0x62f72c: str             q0, [SP, #-0x10]!
    // 0x62f730: r0 = AllocateDouble()
    //     0x62f730: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62f734: RestoreReg d0
    //     0x62f734: ldr             q0, [SP], #0x10
    // 0x62f738: b               #0x62f700
  }
  _ _resolve(/* No info */) {
    // ** addr: 0x62f73c, size: 0xb8
    // 0x62f73c: EnterFrame
    //     0x62f73c: stp             fp, lr, [SP, #-0x10]!
    //     0x62f740: mov             fp, SP
    // 0x62f744: CheckStackOverflow
    //     0x62f744: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62f748: cmp             SP, x16
    //     0x62f74c: b.ls            #0x62f7ec
    // 0x62f750: ldr             x1, [fp, #0x10]
    // 0x62f754: LoadField: r0 = r1->field_63
    //     0x62f754: ldur            w0, [x1, #0x63]
    // 0x62f758: DecompressPointer r0
    //     0x62f758: add             x0, x0, HEAP, lsl #32
    // 0x62f75c: cmp             w0, NULL
    // 0x62f760: b.eq            #0x62f774
    // 0x62f764: r0 = Null
    //     0x62f764: mov             x0, NULL
    // 0x62f768: LeaveFrame
    //     0x62f768: mov             SP, fp
    //     0x62f76c: ldp             fp, lr, [SP], #0x10
    // 0x62f770: ret
    //     0x62f770: ret             
    // 0x62f774: LoadField: r0 = r1->field_67
    //     0x62f774: ldur            w0, [x1, #0x67]
    // 0x62f778: DecompressPointer r0
    //     0x62f778: add             x0, x0, HEAP, lsl #32
    // 0x62f77c: LoadField: r2 = r1->field_6b
    //     0x62f77c: ldur            w2, [x1, #0x6b]
    // 0x62f780: DecompressPointer r2
    //     0x62f780: add             x2, x2, HEAP, lsl #32
    // 0x62f784: r3 = LoadClassIdInstr(r0)
    //     0x62f784: ldur            x3, [x0, #-1]
    //     0x62f788: ubfx            x3, x3, #0xc, #0x14
    // 0x62f78c: lsl             x3, x3, #1
    // 0x62f790: r17 = 4206
    //     0x62f790: mov             x17, #0x106e
    // 0x62f794: cmp             w3, w17
    // 0x62f798: b.eq            #0x62f7c0
    // 0x62f79c: r3 = LoadClassIdInstr(r0)
    //     0x62f79c: ldur            x3, [x0, #-1]
    //     0x62f7a0: ubfx            x3, x3, #0xc, #0x14
    // 0x62f7a4: stp             x2, x0, [SP, #-0x10]!
    // 0x62f7a8: mov             x0, x3
    // 0x62f7ac: r0 = GDT[cid_x0 + -0xfdb]()
    //     0x62f7ac: sub             lr, x0, #0xfdb
    //     0x62f7b0: ldr             lr, [x21, lr, lsl #3]
    //     0x62f7b4: blr             lr
    // 0x62f7b8: add             SP, SP, #0x10
    // 0x62f7bc: ldr             x1, [fp, #0x10]
    // 0x62f7c0: StoreField: r1->field_63 = r0
    //     0x62f7c0: stur            w0, [x1, #0x63]
    //     0x62f7c4: ldurb           w16, [x1, #-1]
    //     0x62f7c8: ldurb           w17, [x0, #-1]
    //     0x62f7cc: and             x16, x17, x16, lsr #2
    //     0x62f7d0: tst             x16, HEAP, lsr #32
    //     0x62f7d4: b.eq            #0x62f7dc
    //     0x62f7d8: bl              #0xd6826c
    // 0x62f7dc: r0 = Null
    //     0x62f7dc: mov             x0, NULL
    // 0x62f7e0: LeaveFrame
    //     0x62f7e0: mov             SP, fp
    //     0x62f7e4: ldp             fp, lr, [SP], #0x10
    // 0x62f7e8: ret
    //     0x62f7e8: ret             
    // 0x62f7ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62f7ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62f7f0: b               #0x62f750
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x635f70, size: 0x18
    // 0x635f70: r4 = 0
    //     0x635f70: mov             x4, #0
    // 0x635f74: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x635f74: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fbf0] AnonymousClosure: (0x635f88), in [package:flutter/src/rendering/shifted_box.dart] RenderPadding::computeMaxIntrinsicWidth (0x635fd4)
    //     0x635f78: ldr             x1, [x17, #0xbf0]
    // 0x635f7c: r24 = BuildNonGenericMethodExtractorStub
    //     0x635f7c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x635f80: LoadField: r0 = r24->field_17
    //     0x635f80: ldur            x0, [x24, #0x17]
    // 0x635f84: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x635f88, size: 0x4c
    // 0x635f88: EnterFrame
    //     0x635f88: stp             fp, lr, [SP, #-0x10]!
    //     0x635f8c: mov             fp, SP
    // 0x635f90: ldr             x0, [fp, #0x18]
    // 0x635f94: LoadField: r1 = r0->field_17
    //     0x635f94: ldur            w1, [x0, #0x17]
    // 0x635f98: DecompressPointer r1
    //     0x635f98: add             x1, x1, HEAP, lsl #32
    // 0x635f9c: CheckStackOverflow
    //     0x635f9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x635fa0: cmp             SP, x16
    //     0x635fa4: b.ls            #0x635fcc
    // 0x635fa8: LoadField: r0 = r1->field_f
    //     0x635fa8: ldur            w0, [x1, #0xf]
    // 0x635fac: DecompressPointer r0
    //     0x635fac: add             x0, x0, HEAP, lsl #32
    // 0x635fb0: ldr             x16, [fp, #0x10]
    // 0x635fb4: stp             x16, x0, [SP, #-0x10]!
    // 0x635fb8: r0 = computeMaxIntrinsicWidth()
    //     0x635fb8: bl              #0x635fd4  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::computeMaxIntrinsicWidth
    // 0x635fbc: add             SP, SP, #0x10
    // 0x635fc0: LeaveFrame
    //     0x635fc0: mov             SP, fp
    //     0x635fc4: ldp             fp, lr, [SP], #0x10
    // 0x635fc8: ret
    //     0x635fc8: ret             
    // 0x635fcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x635fcc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x635fd0: b               #0x635fa8
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0x635fd4, size: 0x180
    // 0x635fd4: EnterFrame
    //     0x635fd4: stp             fp, lr, [SP, #-0x10]!
    //     0x635fd8: mov             fp, SP
    // 0x635fdc: AllocStack(0x8)
    //     0x635fdc: sub             SP, SP, #8
    // 0x635fe0: CheckStackOverflow
    //     0x635fe0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x635fe4: cmp             SP, x16
    //     0x635fe8: b.ls            #0x636128
    // 0x635fec: ldr             x16, [fp, #0x18]
    // 0x635ff0: SaveReg r16
    //     0x635ff0: str             x16, [SP, #-8]!
    // 0x635ff4: r0 = _resolve()
    //     0x635ff4: bl              #0x62f73c  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::_resolve
    // 0x635ff8: add             SP, SP, #8
    // 0x635ffc: ldr             x0, [fp, #0x18]
    // 0x636000: LoadField: r1 = r0->field_63
    //     0x636000: ldur            w1, [x0, #0x63]
    // 0x636004: DecompressPointer r1
    //     0x636004: add             x1, x1, HEAP, lsl #32
    // 0x636008: cmp             w1, NULL
    // 0x63600c: b.eq            #0x636130
    // 0x636010: LoadField: d0 = r1->field_7
    //     0x636010: ldur            d0, [x1, #7]
    // 0x636014: LoadField: d1 = r1->field_17
    //     0x636014: ldur            d1, [x1, #0x17]
    // 0x636018: fadd            d2, d0, d1
    // 0x63601c: stur            d2, [fp, #-8]
    // 0x636020: LoadField: d0 = r1->field_f
    //     0x636020: ldur            d0, [x1, #0xf]
    // 0x636024: LoadField: d1 = r1->field_1f
    //     0x636024: ldur            d1, [x1, #0x1f]
    // 0x636028: fadd            d3, d0, d1
    // 0x63602c: LoadField: r1 = r0->field_5f
    //     0x63602c: ldur            w1, [x0, #0x5f]
    // 0x636030: DecompressPointer r1
    //     0x636030: add             x1, x1, HEAP, lsl #32
    // 0x636034: cmp             w1, NULL
    // 0x636038: b.eq            #0x6360f0
    // 0x63603c: ldr             x0, [fp, #0x10]
    // 0x636040: d0 = 0.000000
    //     0x636040: eor             v0.16b, v0.16b, v0.16b
    // 0x636044: LoadField: d1 = r0->field_7
    //     0x636044: ldur            d1, [x0, #7]
    // 0x636048: fsub            d4, d1, d3
    // 0x63604c: fcmp            d0, d4
    // 0x636050: b.vs            #0x636060
    // 0x636054: b.le            #0x636060
    // 0x636058: d0 = 0.000000
    //     0x636058: eor             v0.16b, v0.16b, v0.16b
    // 0x63605c: b               #0x6360a0
    // 0x636060: fcmp            d0, d4
    // 0x636064: b.vs            #0x636074
    // 0x636068: b.ge            #0x636074
    // 0x63606c: mov             v0.16b, v4.16b
    // 0x636070: b               #0x6360a0
    // 0x636074: fcmp            d0, d0
    // 0x636078: b.vs            #0x63608c
    // 0x63607c: b.ne            #0x63608c
    // 0x636080: fadd            d1, d0, d4
    // 0x636084: mov             v0.16b, v1.16b
    // 0x636088: b               #0x6360a0
    // 0x63608c: fcmp            d4, d4
    // 0x636090: b.vc            #0x63609c
    // 0x636094: mov             v0.16b, v4.16b
    // 0x636098: b               #0x6360a0
    // 0x63609c: d0 = 0.000000
    //     0x63609c: eor             v0.16b, v0.16b, v0.16b
    // 0x6360a0: SaveReg r1
    //     0x6360a0: str             x1, [SP, #-8]!
    // 0x6360a4: SaveReg d0
    //     0x6360a4: str             d0, [SP, #-8]!
    // 0x6360a8: r0 = getMaxIntrinsicWidth()
    //     0x6360a8: bl              #0x62cb94  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0x6360ac: add             SP, SP, #0x10
    // 0x6360b0: mov             v1.16b, v0.16b
    // 0x6360b4: ldur            d0, [fp, #-8]
    // 0x6360b8: fadd            d2, d1, d0
    // 0x6360bc: r0 = inline_Allocate_Double()
    //     0x6360bc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6360c0: add             x0, x0, #0x10
    //     0x6360c4: cmp             x1, x0
    //     0x6360c8: b.ls            #0x636134
    //     0x6360cc: str             x0, [THR, #0x60]  ; THR::top
    //     0x6360d0: sub             x0, x0, #0xf
    //     0x6360d4: mov             x1, #0xd108
    //     0x6360d8: movk            x1, #3, lsl #16
    //     0x6360dc: stur            x1, [x0, #-1]
    // 0x6360e0: StoreField: r0->field_7 = d2
    //     0x6360e0: stur            d2, [x0, #7]
    // 0x6360e4: LeaveFrame
    //     0x6360e4: mov             SP, fp
    //     0x6360e8: ldp             fp, lr, [SP], #0x10
    // 0x6360ec: ret
    //     0x6360ec: ret             
    // 0x6360f0: mov             v0.16b, v2.16b
    // 0x6360f4: r0 = inline_Allocate_Double()
    //     0x6360f4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6360f8: add             x0, x0, #0x10
    //     0x6360fc: cmp             x1, x0
    //     0x636100: b.ls            #0x636144
    //     0x636104: str             x0, [THR, #0x60]  ; THR::top
    //     0x636108: sub             x0, x0, #0xf
    //     0x63610c: mov             x1, #0xd108
    //     0x636110: movk            x1, #3, lsl #16
    //     0x636114: stur            x1, [x0, #-1]
    // 0x636118: StoreField: r0->field_7 = d0
    //     0x636118: stur            d0, [x0, #7]
    // 0x63611c: LeaveFrame
    //     0x63611c: mov             SP, fp
    //     0x636120: ldp             fp, lr, [SP], #0x10
    // 0x636124: ret
    //     0x636124: ret             
    // 0x636128: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x636128: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63612c: b               #0x635fec
    // 0x636130: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x636130: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x636134: SaveReg d2
    //     0x636134: str             q2, [SP, #-0x10]!
    // 0x636138: r0 = AllocateDouble()
    //     0x636138: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63613c: RestoreReg d2
    //     0x63613c: ldr             q2, [SP], #0x10
    // 0x636140: b               #0x6360e0
    // 0x636144: SaveReg d0
    //     0x636144: str             q0, [SP, #-0x10]!
    // 0x636148: r0 = AllocateDouble()
    //     0x636148: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63614c: RestoreReg d0
    //     0x63614c: ldr             q0, [SP], #0x10
    // 0x636150: b               #0x636118
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x6391bc, size: 0x18
    // 0x6391bc: r4 = 0
    //     0x6391bc: mov             x4, #0
    // 0x6391c0: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x6391c0: add             x17, PP, #0x52, lsl #12  ; [pp+0x52e70] AnonymousClosure: (0x6391d4), in [package:flutter/src/rendering/shifted_box.dart] RenderPadding::computeMinIntrinsicHeight (0x639220)
    //     0x6391c4: ldr             x1, [x17, #0xe70]
    // 0x6391c8: r24 = BuildNonGenericMethodExtractorStub
    //     0x6391c8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x6391cc: LoadField: r0 = r24->field_17
    //     0x6391cc: ldur            x0, [x24, #0x17]
    // 0x6391d0: br              x0
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x6391d4, size: 0x4c
    // 0x6391d4: EnterFrame
    //     0x6391d4: stp             fp, lr, [SP, #-0x10]!
    //     0x6391d8: mov             fp, SP
    // 0x6391dc: ldr             x0, [fp, #0x18]
    // 0x6391e0: LoadField: r1 = r0->field_17
    //     0x6391e0: ldur            w1, [x0, #0x17]
    // 0x6391e4: DecompressPointer r1
    //     0x6391e4: add             x1, x1, HEAP, lsl #32
    // 0x6391e8: CheckStackOverflow
    //     0x6391e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6391ec: cmp             SP, x16
    //     0x6391f0: b.ls            #0x639218
    // 0x6391f4: LoadField: r0 = r1->field_f
    //     0x6391f4: ldur            w0, [x1, #0xf]
    // 0x6391f8: DecompressPointer r0
    //     0x6391f8: add             x0, x0, HEAP, lsl #32
    // 0x6391fc: ldr             x16, [fp, #0x10]
    // 0x639200: stp             x16, x0, [SP, #-0x10]!
    // 0x639204: r0 = computeMinIntrinsicHeight()
    //     0x639204: bl              #0x639220  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::computeMinIntrinsicHeight
    // 0x639208: add             SP, SP, #0x10
    // 0x63920c: LeaveFrame
    //     0x63920c: mov             SP, fp
    //     0x639210: ldp             fp, lr, [SP], #0x10
    // 0x639214: ret
    //     0x639214: ret             
    // 0x639218: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x639218: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63921c: b               #0x6391f4
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0x639220, size: 0x180
    // 0x639220: EnterFrame
    //     0x639220: stp             fp, lr, [SP, #-0x10]!
    //     0x639224: mov             fp, SP
    // 0x639228: AllocStack(0x8)
    //     0x639228: sub             SP, SP, #8
    // 0x63922c: CheckStackOverflow
    //     0x63922c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x639230: cmp             SP, x16
    //     0x639234: b.ls            #0x639374
    // 0x639238: ldr             x16, [fp, #0x18]
    // 0x63923c: SaveReg r16
    //     0x63923c: str             x16, [SP, #-8]!
    // 0x639240: r0 = _resolve()
    //     0x639240: bl              #0x62f73c  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::_resolve
    // 0x639244: add             SP, SP, #8
    // 0x639248: ldr             x0, [fp, #0x18]
    // 0x63924c: LoadField: r1 = r0->field_63
    //     0x63924c: ldur            w1, [x0, #0x63]
    // 0x639250: DecompressPointer r1
    //     0x639250: add             x1, x1, HEAP, lsl #32
    // 0x639254: cmp             w1, NULL
    // 0x639258: b.eq            #0x63937c
    // 0x63925c: LoadField: d0 = r1->field_7
    //     0x63925c: ldur            d0, [x1, #7]
    // 0x639260: LoadField: d1 = r1->field_17
    //     0x639260: ldur            d1, [x1, #0x17]
    // 0x639264: fadd            d2, d0, d1
    // 0x639268: LoadField: d0 = r1->field_f
    //     0x639268: ldur            d0, [x1, #0xf]
    // 0x63926c: LoadField: d1 = r1->field_1f
    //     0x63926c: ldur            d1, [x1, #0x1f]
    // 0x639270: fadd            d3, d0, d1
    // 0x639274: stur            d3, [fp, #-8]
    // 0x639278: LoadField: r1 = r0->field_5f
    //     0x639278: ldur            w1, [x0, #0x5f]
    // 0x63927c: DecompressPointer r1
    //     0x63927c: add             x1, x1, HEAP, lsl #32
    // 0x639280: cmp             w1, NULL
    // 0x639284: b.eq            #0x63933c
    // 0x639288: ldr             x0, [fp, #0x10]
    // 0x63928c: d0 = 0.000000
    //     0x63928c: eor             v0.16b, v0.16b, v0.16b
    // 0x639290: LoadField: d1 = r0->field_7
    //     0x639290: ldur            d1, [x0, #7]
    // 0x639294: fsub            d4, d1, d2
    // 0x639298: fcmp            d0, d4
    // 0x63929c: b.vs            #0x6392ac
    // 0x6392a0: b.le            #0x6392ac
    // 0x6392a4: d0 = 0.000000
    //     0x6392a4: eor             v0.16b, v0.16b, v0.16b
    // 0x6392a8: b               #0x6392ec
    // 0x6392ac: fcmp            d0, d4
    // 0x6392b0: b.vs            #0x6392c0
    // 0x6392b4: b.ge            #0x6392c0
    // 0x6392b8: mov             v0.16b, v4.16b
    // 0x6392bc: b               #0x6392ec
    // 0x6392c0: fcmp            d0, d0
    // 0x6392c4: b.vs            #0x6392d8
    // 0x6392c8: b.ne            #0x6392d8
    // 0x6392cc: fadd            d1, d0, d4
    // 0x6392d0: mov             v0.16b, v1.16b
    // 0x6392d4: b               #0x6392ec
    // 0x6392d8: fcmp            d4, d4
    // 0x6392dc: b.vc            #0x6392e8
    // 0x6392e0: mov             v0.16b, v4.16b
    // 0x6392e4: b               #0x6392ec
    // 0x6392e8: d0 = 0.000000
    //     0x6392e8: eor             v0.16b, v0.16b, v0.16b
    // 0x6392ec: SaveReg r1
    //     0x6392ec: str             x1, [SP, #-8]!
    // 0x6392f0: SaveReg d0
    //     0x6392f0: str             d0, [SP, #-8]!
    // 0x6392f4: r0 = getMinIntrinsicHeight()
    //     0x6392f4: bl              #0x630a58  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0x6392f8: add             SP, SP, #0x10
    // 0x6392fc: mov             v1.16b, v0.16b
    // 0x639300: ldur            d0, [fp, #-8]
    // 0x639304: fadd            d2, d1, d0
    // 0x639308: r0 = inline_Allocate_Double()
    //     0x639308: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63930c: add             x0, x0, #0x10
    //     0x639310: cmp             x1, x0
    //     0x639314: b.ls            #0x639380
    //     0x639318: str             x0, [THR, #0x60]  ; THR::top
    //     0x63931c: sub             x0, x0, #0xf
    //     0x639320: mov             x1, #0xd108
    //     0x639324: movk            x1, #3, lsl #16
    //     0x639328: stur            x1, [x0, #-1]
    // 0x63932c: StoreField: r0->field_7 = d2
    //     0x63932c: stur            d2, [x0, #7]
    // 0x639330: LeaveFrame
    //     0x639330: mov             SP, fp
    //     0x639334: ldp             fp, lr, [SP], #0x10
    // 0x639338: ret
    //     0x639338: ret             
    // 0x63933c: mov             v0.16b, v3.16b
    // 0x639340: r0 = inline_Allocate_Double()
    //     0x639340: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x639344: add             x0, x0, #0x10
    //     0x639348: cmp             x1, x0
    //     0x63934c: b.ls            #0x639390
    //     0x639350: str             x0, [THR, #0x60]  ; THR::top
    //     0x639354: sub             x0, x0, #0xf
    //     0x639358: mov             x1, #0xd108
    //     0x63935c: movk            x1, #3, lsl #16
    //     0x639360: stur            x1, [x0, #-1]
    // 0x639364: StoreField: r0->field_7 = d0
    //     0x639364: stur            d0, [x0, #7]
    // 0x639368: LeaveFrame
    //     0x639368: mov             SP, fp
    //     0x63936c: ldp             fp, lr, [SP], #0x10
    // 0x639370: ret
    //     0x639370: ret             
    // 0x639374: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x639374: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x639378: b               #0x639238
    // 0x63937c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63937c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x639380: SaveReg d2
    //     0x639380: str             q2, [SP, #-0x10]!
    // 0x639384: r0 = AllocateDouble()
    //     0x639384: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x639388: RestoreReg d2
    //     0x639388: ldr             q2, [SP], #0x10
    // 0x63938c: b               #0x63932c
    // 0x639390: SaveReg d0
    //     0x639390: str             q0, [SP, #-0x10]!
    // 0x639394: r0 = AllocateDouble()
    //     0x639394: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x639398: RestoreReg d0
    //     0x639398: ldr             q0, [SP], #0x10
    // 0x63939c: b               #0x639364
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63bdf8, size: 0x18
    // 0x63bdf8: r4 = 0
    //     0x63bdf8: mov             x4, #0
    // 0x63bdfc: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63bdfc: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fce0] AnonymousClosure: (0x63be10), in [package:flutter/src/rendering/shifted_box.dart] RenderPadding::computeMinIntrinsicWidth (0x63be5c)
    //     0x63be00: ldr             x1, [x17, #0xce0]
    // 0x63be04: r24 = BuildNonGenericMethodExtractorStub
    //     0x63be04: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63be08: LoadField: r0 = r24->field_17
    //     0x63be08: ldur            x0, [x24, #0x17]
    // 0x63be0c: br              x0
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63be10, size: 0x4c
    // 0x63be10: EnterFrame
    //     0x63be10: stp             fp, lr, [SP, #-0x10]!
    //     0x63be14: mov             fp, SP
    // 0x63be18: ldr             x0, [fp, #0x18]
    // 0x63be1c: LoadField: r1 = r0->field_17
    //     0x63be1c: ldur            w1, [x0, #0x17]
    // 0x63be20: DecompressPointer r1
    //     0x63be20: add             x1, x1, HEAP, lsl #32
    // 0x63be24: CheckStackOverflow
    //     0x63be24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63be28: cmp             SP, x16
    //     0x63be2c: b.ls            #0x63be54
    // 0x63be30: LoadField: r0 = r1->field_f
    //     0x63be30: ldur            w0, [x1, #0xf]
    // 0x63be34: DecompressPointer r0
    //     0x63be34: add             x0, x0, HEAP, lsl #32
    // 0x63be38: ldr             x16, [fp, #0x10]
    // 0x63be3c: stp             x16, x0, [SP, #-0x10]!
    // 0x63be40: r0 = computeMinIntrinsicWidth()
    //     0x63be40: bl              #0x63be5c  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::computeMinIntrinsicWidth
    // 0x63be44: add             SP, SP, #0x10
    // 0x63be48: LeaveFrame
    //     0x63be48: mov             SP, fp
    //     0x63be4c: ldp             fp, lr, [SP], #0x10
    // 0x63be50: ret
    //     0x63be50: ret             
    // 0x63be54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63be54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63be58: b               #0x63be30
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0x63be5c, size: 0x180
    // 0x63be5c: EnterFrame
    //     0x63be5c: stp             fp, lr, [SP, #-0x10]!
    //     0x63be60: mov             fp, SP
    // 0x63be64: AllocStack(0x8)
    //     0x63be64: sub             SP, SP, #8
    // 0x63be68: CheckStackOverflow
    //     0x63be68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63be6c: cmp             SP, x16
    //     0x63be70: b.ls            #0x63bfb0
    // 0x63be74: ldr             x16, [fp, #0x18]
    // 0x63be78: SaveReg r16
    //     0x63be78: str             x16, [SP, #-8]!
    // 0x63be7c: r0 = _resolve()
    //     0x63be7c: bl              #0x62f73c  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::_resolve
    // 0x63be80: add             SP, SP, #8
    // 0x63be84: ldr             x0, [fp, #0x18]
    // 0x63be88: LoadField: r1 = r0->field_63
    //     0x63be88: ldur            w1, [x0, #0x63]
    // 0x63be8c: DecompressPointer r1
    //     0x63be8c: add             x1, x1, HEAP, lsl #32
    // 0x63be90: cmp             w1, NULL
    // 0x63be94: b.eq            #0x63bfb8
    // 0x63be98: LoadField: d0 = r1->field_7
    //     0x63be98: ldur            d0, [x1, #7]
    // 0x63be9c: LoadField: d1 = r1->field_17
    //     0x63be9c: ldur            d1, [x1, #0x17]
    // 0x63bea0: fadd            d2, d0, d1
    // 0x63bea4: stur            d2, [fp, #-8]
    // 0x63bea8: LoadField: d0 = r1->field_f
    //     0x63bea8: ldur            d0, [x1, #0xf]
    // 0x63beac: LoadField: d1 = r1->field_1f
    //     0x63beac: ldur            d1, [x1, #0x1f]
    // 0x63beb0: fadd            d3, d0, d1
    // 0x63beb4: LoadField: r1 = r0->field_5f
    //     0x63beb4: ldur            w1, [x0, #0x5f]
    // 0x63beb8: DecompressPointer r1
    //     0x63beb8: add             x1, x1, HEAP, lsl #32
    // 0x63bebc: cmp             w1, NULL
    // 0x63bec0: b.eq            #0x63bf78
    // 0x63bec4: ldr             x0, [fp, #0x10]
    // 0x63bec8: d0 = 0.000000
    //     0x63bec8: eor             v0.16b, v0.16b, v0.16b
    // 0x63becc: LoadField: d1 = r0->field_7
    //     0x63becc: ldur            d1, [x0, #7]
    // 0x63bed0: fsub            d4, d1, d3
    // 0x63bed4: fcmp            d0, d4
    // 0x63bed8: b.vs            #0x63bee8
    // 0x63bedc: b.le            #0x63bee8
    // 0x63bee0: d0 = 0.000000
    //     0x63bee0: eor             v0.16b, v0.16b, v0.16b
    // 0x63bee4: b               #0x63bf28
    // 0x63bee8: fcmp            d0, d4
    // 0x63beec: b.vs            #0x63befc
    // 0x63bef0: b.ge            #0x63befc
    // 0x63bef4: mov             v0.16b, v4.16b
    // 0x63bef8: b               #0x63bf28
    // 0x63befc: fcmp            d0, d0
    // 0x63bf00: b.vs            #0x63bf14
    // 0x63bf04: b.ne            #0x63bf14
    // 0x63bf08: fadd            d1, d0, d4
    // 0x63bf0c: mov             v0.16b, v1.16b
    // 0x63bf10: b               #0x63bf28
    // 0x63bf14: fcmp            d4, d4
    // 0x63bf18: b.vc            #0x63bf24
    // 0x63bf1c: mov             v0.16b, v4.16b
    // 0x63bf20: b               #0x63bf28
    // 0x63bf24: d0 = 0.000000
    //     0x63bf24: eor             v0.16b, v0.16b, v0.16b
    // 0x63bf28: SaveReg r1
    //     0x63bf28: str             x1, [SP, #-8]!
    // 0x63bf2c: SaveReg d0
    //     0x63bf2c: str             d0, [SP, #-8]!
    // 0x63bf30: r0 = getMinIntrinsicWidth()
    //     0x63bf30: bl              #0x630b18  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicWidth
    // 0x63bf34: add             SP, SP, #0x10
    // 0x63bf38: mov             v1.16b, v0.16b
    // 0x63bf3c: ldur            d0, [fp, #-8]
    // 0x63bf40: fadd            d2, d1, d0
    // 0x63bf44: r0 = inline_Allocate_Double()
    //     0x63bf44: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63bf48: add             x0, x0, #0x10
    //     0x63bf4c: cmp             x1, x0
    //     0x63bf50: b.ls            #0x63bfbc
    //     0x63bf54: str             x0, [THR, #0x60]  ; THR::top
    //     0x63bf58: sub             x0, x0, #0xf
    //     0x63bf5c: mov             x1, #0xd108
    //     0x63bf60: movk            x1, #3, lsl #16
    //     0x63bf64: stur            x1, [x0, #-1]
    // 0x63bf68: StoreField: r0->field_7 = d2
    //     0x63bf68: stur            d2, [x0, #7]
    // 0x63bf6c: LeaveFrame
    //     0x63bf6c: mov             SP, fp
    //     0x63bf70: ldp             fp, lr, [SP], #0x10
    // 0x63bf74: ret
    //     0x63bf74: ret             
    // 0x63bf78: mov             v0.16b, v2.16b
    // 0x63bf7c: r0 = inline_Allocate_Double()
    //     0x63bf7c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63bf80: add             x0, x0, #0x10
    //     0x63bf84: cmp             x1, x0
    //     0x63bf88: b.ls            #0x63bfcc
    //     0x63bf8c: str             x0, [THR, #0x60]  ; THR::top
    //     0x63bf90: sub             x0, x0, #0xf
    //     0x63bf94: mov             x1, #0xd108
    //     0x63bf98: movk            x1, #3, lsl #16
    //     0x63bf9c: stur            x1, [x0, #-1]
    // 0x63bfa0: StoreField: r0->field_7 = d0
    //     0x63bfa0: stur            d0, [x0, #7]
    // 0x63bfa4: LeaveFrame
    //     0x63bfa4: mov             SP, fp
    //     0x63bfa8: ldp             fp, lr, [SP], #0x10
    // 0x63bfac: ret
    //     0x63bfac: ret             
    // 0x63bfb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63bfb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63bfb4: b               #0x63be74
    // 0x63bfb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63bfb8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x63bfbc: SaveReg d2
    //     0x63bfbc: str             q2, [SP, #-0x10]!
    // 0x63bfc0: r0 = AllocateDouble()
    //     0x63bfc0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63bfc4: RestoreReg d2
    //     0x63bfc4: ldr             q2, [SP], #0x10
    // 0x63bfc8: b               #0x63bf68
    // 0x63bfcc: SaveReg d0
    //     0x63bfcc: str             q0, [SP, #-0x10]!
    // 0x63bfd0: r0 = AllocateDouble()
    //     0x63bfd0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63bfd4: RestoreReg d0
    //     0x63bfd4: ldr             q0, [SP], #0x10
    // 0x63bfd8: b               #0x63bfa0
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x692cc0, size: 0x30c
    // 0x692cc0: EnterFrame
    //     0x692cc0: stp             fp, lr, [SP, #-0x10]!
    //     0x692cc4: mov             fp, SP
    // 0x692cc8: AllocStack(0x30)
    //     0x692cc8: sub             SP, SP, #0x30
    // 0x692ccc: CheckStackOverflow
    //     0x692ccc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x692cd0: cmp             SP, x16
    //     0x692cd4: b.ls            #0x692fa8
    // 0x692cd8: ldr             x3, [fp, #0x10]
    // 0x692cdc: LoadField: r4 = r3->field_27
    //     0x692cdc: ldur            w4, [x3, #0x27]
    // 0x692ce0: DecompressPointer r4
    //     0x692ce0: add             x4, x4, HEAP, lsl #32
    // 0x692ce4: stur            x4, [fp, #-8]
    // 0x692ce8: cmp             w4, NULL
    // 0x692cec: b.eq            #0x692f88
    // 0x692cf0: mov             x0, x4
    // 0x692cf4: r2 = Null
    //     0x692cf4: mov             x2, NULL
    // 0x692cf8: r1 = Null
    //     0x692cf8: mov             x1, NULL
    // 0x692cfc: r4 = LoadClassIdInstr(r0)
    //     0x692cfc: ldur            x4, [x0, #-1]
    //     0x692d00: ubfx            x4, x4, #0xc, #0x14
    // 0x692d04: sub             x4, x4, #0x80d
    // 0x692d08: cmp             x4, #1
    // 0x692d0c: b.ls            #0x692d24
    // 0x692d10: r8 = BoxConstraints
    //     0x692d10: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x692d14: ldr             x8, [x8, #0x1d0]
    // 0x692d18: r3 = Null
    //     0x692d18: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1ce80] Null
    //     0x692d1c: ldr             x3, [x3, #0xe80]
    // 0x692d20: r0 = BoxConstraints()
    //     0x692d20: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x692d24: ldr             x16, [fp, #0x10]
    // 0x692d28: SaveReg r16
    //     0x692d28: str             x16, [SP, #-8]!
    // 0x692d2c: r0 = _resolve()
    //     0x692d2c: bl              #0x62f73c  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::_resolve
    // 0x692d30: add             SP, SP, #8
    // 0x692d34: ldr             x0, [fp, #0x10]
    // 0x692d38: LoadField: r1 = r0->field_5f
    //     0x692d38: ldur            w1, [x0, #0x5f]
    // 0x692d3c: DecompressPointer r1
    //     0x692d3c: add             x1, x1, HEAP, lsl #32
    // 0x692d40: cmp             w1, NULL
    // 0x692d44: b.ne            #0x692dcc
    // 0x692d48: LoadField: r1 = r0->field_63
    //     0x692d48: ldur            w1, [x0, #0x63]
    // 0x692d4c: DecompressPointer r1
    //     0x692d4c: add             x1, x1, HEAP, lsl #32
    // 0x692d50: cmp             w1, NULL
    // 0x692d54: b.eq            #0x692fb0
    // 0x692d58: LoadField: d0 = r1->field_7
    //     0x692d58: ldur            d0, [x1, #7]
    // 0x692d5c: LoadField: d1 = r1->field_17
    //     0x692d5c: ldur            d1, [x1, #0x17]
    // 0x692d60: fadd            d2, d0, d1
    // 0x692d64: stur            d2, [fp, #-0x30]
    // 0x692d68: LoadField: d0 = r1->field_f
    //     0x692d68: ldur            d0, [x1, #0xf]
    // 0x692d6c: LoadField: d1 = r1->field_1f
    //     0x692d6c: ldur            d1, [x1, #0x1f]
    // 0x692d70: fadd            d3, d0, d1
    // 0x692d74: stur            d3, [fp, #-0x28]
    // 0x692d78: r0 = Size()
    //     0x692d78: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x692d7c: ldur            d0, [fp, #-0x30]
    // 0x692d80: StoreField: r0->field_7 = d0
    //     0x692d80: stur            d0, [x0, #7]
    // 0x692d84: ldur            d0, [fp, #-0x28]
    // 0x692d88: StoreField: r0->field_f = d0
    //     0x692d88: stur            d0, [x0, #0xf]
    // 0x692d8c: ldur            x16, [fp, #-8]
    // 0x692d90: stp             x0, x16, [SP, #-0x10]!
    // 0x692d94: r0 = constrain()
    //     0x692d94: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x692d98: add             SP, SP, #0x10
    // 0x692d9c: ldr             x1, [fp, #0x10]
    // 0x692da0: StoreField: r1->field_57 = r0
    //     0x692da0: stur            w0, [x1, #0x57]
    //     0x692da4: ldurb           w16, [x1, #-1]
    //     0x692da8: ldurb           w17, [x0, #-1]
    //     0x692dac: and             x16, x17, x16, lsr #2
    //     0x692db0: tst             x16, HEAP, lsr #32
    //     0x692db4: b.eq            #0x692dbc
    //     0x692db8: bl              #0xd6826c
    // 0x692dbc: r0 = Null
    //     0x692dbc: mov             x0, NULL
    // 0x692dc0: LeaveFrame
    //     0x692dc0: mov             SP, fp
    //     0x692dc4: ldp             fp, lr, [SP], #0x10
    // 0x692dc8: ret
    //     0x692dc8: ret             
    // 0x692dcc: mov             x1, x0
    // 0x692dd0: LoadField: r0 = r1->field_63
    //     0x692dd0: ldur            w0, [x1, #0x63]
    // 0x692dd4: DecompressPointer r0
    //     0x692dd4: add             x0, x0, HEAP, lsl #32
    // 0x692dd8: cmp             w0, NULL
    // 0x692ddc: b.eq            #0x692fb4
    // 0x692de0: ldur            x16, [fp, #-8]
    // 0x692de4: stp             x0, x16, [SP, #-0x10]!
    // 0x692de8: r0 = deflate()
    //     0x692de8: bl              #0x692fcc  ; [package:flutter/src/rendering/box.dart] BoxConstraints::deflate
    // 0x692dec: add             SP, SP, #0x10
    // 0x692df0: ldr             x1, [fp, #0x10]
    // 0x692df4: LoadField: r2 = r1->field_5f
    //     0x692df4: ldur            w2, [x1, #0x5f]
    // 0x692df8: DecompressPointer r2
    //     0x692df8: add             x2, x2, HEAP, lsl #32
    // 0x692dfc: cmp             w2, NULL
    // 0x692e00: b.eq            #0x692fb8
    // 0x692e04: r3 = LoadClassIdInstr(r2)
    //     0x692e04: ldur            x3, [x2, #-1]
    //     0x692e08: ubfx            x3, x3, #0xc, #0x14
    // 0x692e0c: stp             x0, x2, [SP, #-0x10]!
    // 0x692e10: r16 = true
    //     0x692e10: add             x16, NULL, #0x20  ; true
    // 0x692e14: SaveReg r16
    //     0x692e14: str             x16, [SP, #-8]!
    // 0x692e18: mov             x0, x3
    // 0x692e1c: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x692e1c: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x692e20: ldr             x4, [x4, #0x1c8]
    // 0x692e24: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x692e24: mov             x17, #0xcdfb
    //     0x692e28: add             lr, x0, x17
    //     0x692e2c: ldr             lr, [x21, lr, lsl #3]
    //     0x692e30: blr             lr
    // 0x692e34: add             SP, SP, #0x18
    // 0x692e38: ldr             x3, [fp, #0x10]
    // 0x692e3c: LoadField: r4 = r3->field_5f
    //     0x692e3c: ldur            w4, [x3, #0x5f]
    // 0x692e40: DecompressPointer r4
    //     0x692e40: add             x4, x4, HEAP, lsl #32
    // 0x692e44: stur            x4, [fp, #-0x18]
    // 0x692e48: cmp             w4, NULL
    // 0x692e4c: b.eq            #0x692fbc
    // 0x692e50: LoadField: r5 = r4->field_17
    //     0x692e50: ldur            w5, [x4, #0x17]
    // 0x692e54: DecompressPointer r5
    //     0x692e54: add             x5, x5, HEAP, lsl #32
    // 0x692e58: stur            x5, [fp, #-0x10]
    // 0x692e5c: cmp             w5, NULL
    // 0x692e60: b.eq            #0x692fc0
    // 0x692e64: mov             x0, x5
    // 0x692e68: r2 = Null
    //     0x692e68: mov             x2, NULL
    // 0x692e6c: r1 = Null
    //     0x692e6c: mov             x1, NULL
    // 0x692e70: r4 = LoadClassIdInstr(r0)
    //     0x692e70: ldur            x4, [x0, #-1]
    //     0x692e74: ubfx            x4, x4, #0xc, #0x14
    // 0x692e78: sub             x4, x4, #0x7ff
    // 0x692e7c: cmp             x4, #0xb
    // 0x692e80: b.ls            #0x692e98
    // 0x692e84: r8 = BoxParentData
    //     0x692e84: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x692e88: ldr             x8, [x8, #0x1b0]
    // 0x692e8c: r3 = Null
    //     0x692e8c: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1ce90] Null
    //     0x692e90: ldr             x3, [x3, #0xe90]
    // 0x692e94: r0 = DefaultTypeTest()
    //     0x692e94: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x692e98: ldr             x0, [fp, #0x10]
    // 0x692e9c: LoadField: r1 = r0->field_63
    //     0x692e9c: ldur            w1, [x0, #0x63]
    // 0x692ea0: DecompressPointer r1
    //     0x692ea0: add             x1, x1, HEAP, lsl #32
    // 0x692ea4: stur            x1, [fp, #-0x20]
    // 0x692ea8: cmp             w1, NULL
    // 0x692eac: b.eq            #0x692fc4
    // 0x692eb0: LoadField: d0 = r1->field_7
    //     0x692eb0: ldur            d0, [x1, #7]
    // 0x692eb4: stur            d0, [fp, #-0x30]
    // 0x692eb8: LoadField: d1 = r1->field_f
    //     0x692eb8: ldur            d1, [x1, #0xf]
    // 0x692ebc: stur            d1, [fp, #-0x28]
    // 0x692ec0: r0 = Offset()
    //     0x692ec0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x692ec4: ldur            d0, [fp, #-0x30]
    // 0x692ec8: StoreField: r0->field_7 = d0
    //     0x692ec8: stur            d0, [x0, #7]
    // 0x692ecc: ldur            d1, [fp, #-0x28]
    // 0x692ed0: StoreField: r0->field_f = d1
    //     0x692ed0: stur            d1, [x0, #0xf]
    // 0x692ed4: ldur            x1, [fp, #-0x10]
    // 0x692ed8: StoreField: r1->field_7 = r0
    //     0x692ed8: stur            w0, [x1, #7]
    //     0x692edc: ldurb           w16, [x1, #-1]
    //     0x692ee0: ldurb           w17, [x0, #-1]
    //     0x692ee4: and             x16, x17, x16, lsr #2
    //     0x692ee8: tst             x16, HEAP, lsr #32
    //     0x692eec: b.eq            #0x692ef4
    //     0x692ef0: bl              #0xd6826c
    // 0x692ef4: ldur            x0, [fp, #-0x18]
    // 0x692ef8: LoadField: r1 = r0->field_57
    //     0x692ef8: ldur            w1, [x0, #0x57]
    // 0x692efc: DecompressPointer r1
    //     0x692efc: add             x1, x1, HEAP, lsl #32
    // 0x692f00: cmp             w1, NULL
    // 0x692f04: b.eq            #0x692fc8
    // 0x692f08: LoadField: d2 = r1->field_7
    //     0x692f08: ldur            d2, [x1, #7]
    // 0x692f0c: fadd            d3, d0, d2
    // 0x692f10: ldur            x0, [fp, #-0x20]
    // 0x692f14: LoadField: d0 = r0->field_17
    //     0x692f14: ldur            d0, [x0, #0x17]
    // 0x692f18: fadd            d2, d3, d0
    // 0x692f1c: stur            d2, [fp, #-0x30]
    // 0x692f20: LoadField: d0 = r1->field_f
    //     0x692f20: ldur            d0, [x1, #0xf]
    // 0x692f24: fadd            d3, d1, d0
    // 0x692f28: LoadField: d0 = r0->field_1f
    //     0x692f28: ldur            d0, [x0, #0x1f]
    // 0x692f2c: fadd            d1, d3, d0
    // 0x692f30: stur            d1, [fp, #-0x28]
    // 0x692f34: r0 = Size()
    //     0x692f34: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x692f38: ldur            d0, [fp, #-0x30]
    // 0x692f3c: StoreField: r0->field_7 = d0
    //     0x692f3c: stur            d0, [x0, #7]
    // 0x692f40: ldur            d0, [fp, #-0x28]
    // 0x692f44: StoreField: r0->field_f = d0
    //     0x692f44: stur            d0, [x0, #0xf]
    // 0x692f48: ldur            x16, [fp, #-8]
    // 0x692f4c: stp             x0, x16, [SP, #-0x10]!
    // 0x692f50: r0 = constrain()
    //     0x692f50: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x692f54: add             SP, SP, #0x10
    // 0x692f58: ldr             x1, [fp, #0x10]
    // 0x692f5c: StoreField: r1->field_57 = r0
    //     0x692f5c: stur            w0, [x1, #0x57]
    //     0x692f60: ldurb           w16, [x1, #-1]
    //     0x692f64: ldurb           w17, [x0, #-1]
    //     0x692f68: and             x16, x17, x16, lsr #2
    //     0x692f6c: tst             x16, HEAP, lsr #32
    //     0x692f70: b.eq            #0x692f78
    //     0x692f74: bl              #0xd6826c
    // 0x692f78: r0 = Null
    //     0x692f78: mov             x0, NULL
    // 0x692f7c: LeaveFrame
    //     0x692f7c: mov             SP, fp
    //     0x692f80: ldp             fp, lr, [SP], #0x10
    // 0x692f84: ret
    //     0x692f84: ret             
    // 0x692f88: r0 = StateError()
    //     0x692f88: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x692f8c: mov             x1, x0
    // 0x692f90: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x692f90: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x692f94: ldr             x0, [x0, #0x1e8]
    // 0x692f98: StoreField: r1->field_b = r0
    //     0x692f98: stur            w0, [x1, #0xb]
    // 0x692f9c: mov             x0, x1
    // 0x692fa0: r0 = Throw()
    //     0x692fa0: bl              #0xd67e38  ; ThrowStub
    // 0x692fa4: brk             #0
    // 0x692fa8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x692fa8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x692fac: b               #0x692cd8
    // 0x692fb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x692fb0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x692fb4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x692fb4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x692fb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x692fb8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x692fbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x692fbc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x692fc0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x692fc0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x692fc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x692fc4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x692fc8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x692fc8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0x6c5478, size: 0x80
    // 0x6c5478: EnterFrame
    //     0x6c5478: stp             fp, lr, [SP, #-0x10]!
    //     0x6c547c: mov             fp, SP
    // 0x6c5480: CheckStackOverflow
    //     0x6c5480: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c5484: cmp             SP, x16
    //     0x6c5488: b.ls            #0x6c54f0
    // 0x6c548c: ldr             x1, [fp, #0x18]
    // 0x6c5490: LoadField: r0 = r1->field_6b
    //     0x6c5490: ldur            w0, [x1, #0x6b]
    // 0x6c5494: DecompressPointer r0
    //     0x6c5494: add             x0, x0, HEAP, lsl #32
    // 0x6c5498: ldr             x2, [fp, #0x10]
    // 0x6c549c: cmp             w0, w2
    // 0x6c54a0: b.ne            #0x6c54b4
    // 0x6c54a4: r0 = Null
    //     0x6c54a4: mov             x0, NULL
    // 0x6c54a8: LeaveFrame
    //     0x6c54a8: mov             SP, fp
    //     0x6c54ac: ldp             fp, lr, [SP], #0x10
    // 0x6c54b0: ret
    //     0x6c54b0: ret             
    // 0x6c54b4: mov             x0, x2
    // 0x6c54b8: StoreField: r1->field_6b = r0
    //     0x6c54b8: stur            w0, [x1, #0x6b]
    //     0x6c54bc: ldurb           w16, [x1, #-1]
    //     0x6c54c0: ldurb           w17, [x0, #-1]
    //     0x6c54c4: and             x16, x17, x16, lsr #2
    //     0x6c54c8: tst             x16, HEAP, lsr #32
    //     0x6c54cc: b.eq            #0x6c54d4
    //     0x6c54d0: bl              #0xd6826c
    // 0x6c54d4: SaveReg r1
    //     0x6c54d4: str             x1, [SP, #-8]!
    // 0x6c54d8: r0 = _markNeedResolution()
    //     0x6c54d8: bl              #0x6c25fc  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::_markNeedResolution
    // 0x6c54dc: add             SP, SP, #8
    // 0x6c54e0: r0 = Null
    //     0x6c54e0: mov             x0, NULL
    // 0x6c54e4: LeaveFrame
    //     0x6c54e4: mov             SP, fp
    //     0x6c54e8: ldp             fp, lr, [SP], #0x10
    // 0x6c54ec: ret
    //     0x6c54ec: ret             
    // 0x6c54f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c54f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c54f4: b               #0x6c548c
  }
  set _ padding=(/* No info */) {
    // ** addr: 0x6c54f8, size: 0x8c
    // 0x6c54f8: EnterFrame
    //     0x6c54f8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c54fc: mov             fp, SP
    // 0x6c5500: CheckStackOverflow
    //     0x6c5500: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c5504: cmp             SP, x16
    //     0x6c5508: b.ls            #0x6c557c
    // 0x6c550c: ldr             x0, [fp, #0x18]
    // 0x6c5510: LoadField: r1 = r0->field_67
    //     0x6c5510: ldur            w1, [x0, #0x67]
    // 0x6c5514: DecompressPointer r1
    //     0x6c5514: add             x1, x1, HEAP, lsl #32
    // 0x6c5518: ldr             x16, [fp, #0x10]
    // 0x6c551c: stp             x16, x1, [SP, #-0x10]!
    // 0x6c5520: r0 = ==()
    //     0x6c5520: bl              #0xc9d2f4  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::==
    // 0x6c5524: add             SP, SP, #0x10
    // 0x6c5528: tbnz            w0, #4, #0x6c553c
    // 0x6c552c: r0 = Null
    //     0x6c552c: mov             x0, NULL
    // 0x6c5530: LeaveFrame
    //     0x6c5530: mov             SP, fp
    //     0x6c5534: ldp             fp, lr, [SP], #0x10
    // 0x6c5538: ret
    //     0x6c5538: ret             
    // 0x6c553c: ldr             x1, [fp, #0x18]
    // 0x6c5540: ldr             x0, [fp, #0x10]
    // 0x6c5544: StoreField: r1->field_67 = r0
    //     0x6c5544: stur            w0, [x1, #0x67]
    //     0x6c5548: ldurb           w16, [x1, #-1]
    //     0x6c554c: ldurb           w17, [x0, #-1]
    //     0x6c5550: and             x16, x17, x16, lsr #2
    //     0x6c5554: tst             x16, HEAP, lsr #32
    //     0x6c5558: b.eq            #0x6c5560
    //     0x6c555c: bl              #0xd6826c
    // 0x6c5560: SaveReg r1
    //     0x6c5560: str             x1, [SP, #-8]!
    // 0x6c5564: r0 = _markNeedResolution()
    //     0x6c5564: bl              #0x6c25fc  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::_markNeedResolution
    // 0x6c5568: add             SP, SP, #8
    // 0x6c556c: r0 = Null
    //     0x6c556c: mov             x0, NULL
    // 0x6c5570: LeaveFrame
    //     0x6c5570: mov             SP, fp
    //     0x6c5574: ldp             fp, lr, [SP], #0x10
    // 0x6c5578: ret
    //     0x6c5578: ret             
    // 0x6c557c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c557c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c5580: b               #0x6c550c
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5e3dc, size: 0x170
    // 0xa5e3dc: EnterFrame
    //     0xa5e3dc: stp             fp, lr, [SP, #-0x10]!
    //     0xa5e3e0: mov             fp, SP
    // 0xa5e3e4: AllocStack(0x10)
    //     0xa5e3e4: sub             SP, SP, #0x10
    // 0xa5e3e8: CheckStackOverflow
    //     0xa5e3e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5e3ec: cmp             SP, x16
    //     0xa5e3f0: b.ls            #0xa5e534
    // 0xa5e3f4: ldr             x16, [fp, #0x18]
    // 0xa5e3f8: SaveReg r16
    //     0xa5e3f8: str             x16, [SP, #-8]!
    // 0xa5e3fc: r0 = _resolve()
    //     0xa5e3fc: bl              #0x62f73c  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::_resolve
    // 0xa5e400: add             SP, SP, #8
    // 0xa5e404: ldr             x0, [fp, #0x18]
    // 0xa5e408: LoadField: r1 = r0->field_5f
    //     0xa5e408: ldur            w1, [x0, #0x5f]
    // 0xa5e40c: DecompressPointer r1
    //     0xa5e40c: add             x1, x1, HEAP, lsl #32
    // 0xa5e410: cmp             w1, NULL
    // 0xa5e414: b.ne            #0xa5e478
    // 0xa5e418: LoadField: r1 = r0->field_63
    //     0xa5e418: ldur            w1, [x0, #0x63]
    // 0xa5e41c: DecompressPointer r1
    //     0xa5e41c: add             x1, x1, HEAP, lsl #32
    // 0xa5e420: cmp             w1, NULL
    // 0xa5e424: b.eq            #0xa5e53c
    // 0xa5e428: LoadField: d0 = r1->field_7
    //     0xa5e428: ldur            d0, [x1, #7]
    // 0xa5e42c: LoadField: d1 = r1->field_17
    //     0xa5e42c: ldur            d1, [x1, #0x17]
    // 0xa5e430: fadd            d2, d0, d1
    // 0xa5e434: stur            d2, [fp, #-0x10]
    // 0xa5e438: LoadField: d0 = r1->field_f
    //     0xa5e438: ldur            d0, [x1, #0xf]
    // 0xa5e43c: LoadField: d1 = r1->field_1f
    //     0xa5e43c: ldur            d1, [x1, #0x1f]
    // 0xa5e440: fadd            d3, d0, d1
    // 0xa5e444: stur            d3, [fp, #-8]
    // 0xa5e448: r0 = Size()
    //     0xa5e448: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xa5e44c: ldur            d0, [fp, #-0x10]
    // 0xa5e450: StoreField: r0->field_7 = d0
    //     0xa5e450: stur            d0, [x0, #7]
    // 0xa5e454: ldur            d0, [fp, #-8]
    // 0xa5e458: StoreField: r0->field_f = d0
    //     0xa5e458: stur            d0, [x0, #0xf]
    // 0xa5e45c: ldr             x16, [fp, #0x10]
    // 0xa5e460: stp             x0, x16, [SP, #-0x10]!
    // 0xa5e464: r0 = constrain()
    //     0xa5e464: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xa5e468: add             SP, SP, #0x10
    // 0xa5e46c: LeaveFrame
    //     0xa5e46c: mov             SP, fp
    //     0xa5e470: ldp             fp, lr, [SP], #0x10
    // 0xa5e474: ret
    //     0xa5e474: ret             
    // 0xa5e478: LoadField: r1 = r0->field_63
    //     0xa5e478: ldur            w1, [x0, #0x63]
    // 0xa5e47c: DecompressPointer r1
    //     0xa5e47c: add             x1, x1, HEAP, lsl #32
    // 0xa5e480: cmp             w1, NULL
    // 0xa5e484: b.eq            #0xa5e540
    // 0xa5e488: ldr             x16, [fp, #0x10]
    // 0xa5e48c: stp             x1, x16, [SP, #-0x10]!
    // 0xa5e490: r0 = deflate()
    //     0xa5e490: bl              #0x692fcc  ; [package:flutter/src/rendering/box.dart] BoxConstraints::deflate
    // 0xa5e494: add             SP, SP, #0x10
    // 0xa5e498: mov             x1, x0
    // 0xa5e49c: ldr             x0, [fp, #0x18]
    // 0xa5e4a0: LoadField: r2 = r0->field_5f
    //     0xa5e4a0: ldur            w2, [x0, #0x5f]
    // 0xa5e4a4: DecompressPointer r2
    //     0xa5e4a4: add             x2, x2, HEAP, lsl #32
    // 0xa5e4a8: cmp             w2, NULL
    // 0xa5e4ac: b.eq            #0xa5e544
    // 0xa5e4b0: stp             x1, x2, [SP, #-0x10]!
    // 0xa5e4b4: r0 = getDryLayout()
    //     0xa5e4b4: bl              #0x62d394  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xa5e4b8: add             SP, SP, #0x10
    // 0xa5e4bc: mov             x1, x0
    // 0xa5e4c0: ldr             x0, [fp, #0x18]
    // 0xa5e4c4: LoadField: r2 = r0->field_63
    //     0xa5e4c4: ldur            w2, [x0, #0x63]
    // 0xa5e4c8: DecompressPointer r2
    //     0xa5e4c8: add             x2, x2, HEAP, lsl #32
    // 0xa5e4cc: cmp             w2, NULL
    // 0xa5e4d0: b.eq            #0xa5e548
    // 0xa5e4d4: LoadField: d0 = r2->field_7
    //     0xa5e4d4: ldur            d0, [x2, #7]
    // 0xa5e4d8: LoadField: d1 = r1->field_7
    //     0xa5e4d8: ldur            d1, [x1, #7]
    // 0xa5e4dc: fadd            d2, d0, d1
    // 0xa5e4e0: LoadField: d0 = r2->field_17
    //     0xa5e4e0: ldur            d0, [x2, #0x17]
    // 0xa5e4e4: fadd            d1, d2, d0
    // 0xa5e4e8: stur            d1, [fp, #-0x10]
    // 0xa5e4ec: LoadField: d0 = r2->field_f
    //     0xa5e4ec: ldur            d0, [x2, #0xf]
    // 0xa5e4f0: LoadField: d2 = r1->field_f
    //     0xa5e4f0: ldur            d2, [x1, #0xf]
    // 0xa5e4f4: fadd            d3, d0, d2
    // 0xa5e4f8: LoadField: d0 = r2->field_1f
    //     0xa5e4f8: ldur            d0, [x2, #0x1f]
    // 0xa5e4fc: fadd            d2, d3, d0
    // 0xa5e500: stur            d2, [fp, #-8]
    // 0xa5e504: r0 = Size()
    //     0xa5e504: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xa5e508: ldur            d0, [fp, #-0x10]
    // 0xa5e50c: StoreField: r0->field_7 = d0
    //     0xa5e50c: stur            d0, [x0, #7]
    // 0xa5e510: ldur            d0, [fp, #-8]
    // 0xa5e514: StoreField: r0->field_f = d0
    //     0xa5e514: stur            d0, [x0, #0xf]
    // 0xa5e518: ldr             x16, [fp, #0x10]
    // 0xa5e51c: stp             x0, x16, [SP, #-0x10]!
    // 0xa5e520: r0 = constrain()
    //     0xa5e520: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xa5e524: add             SP, SP, #0x10
    // 0xa5e528: LeaveFrame
    //     0xa5e528: mov             SP, fp
    //     0xa5e52c: ldp             fp, lr, [SP], #0x10
    // 0xa5e530: ret
    //     0xa5e530: ret             
    // 0xa5e534: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5e534: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5e538: b               #0xa5e3f4
    // 0xa5e53c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa5e53c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa5e540: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa5e540: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa5e544: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa5e544: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa5e548: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa5e548: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2463, size: 0x70, field offset: 0x64
abstract class RenderAligningShiftedBox extends RenderShiftedBox {

  _ alignChild(/* No info */) {
    // ** addr: 0x69064c, size: 0x12c
    // 0x69064c: EnterFrame
    //     0x69064c: stp             fp, lr, [SP, #-0x10]!
    //     0x690650: mov             fp, SP
    // 0x690654: AllocStack(0x18)
    //     0x690654: sub             SP, SP, #0x18
    // 0x690658: CheckStackOverflow
    //     0x690658: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x69065c: cmp             SP, x16
    //     0x690660: b.ls            #0x69075c
    // 0x690664: ldr             x16, [fp, #0x10]
    // 0x690668: SaveReg r16
    //     0x690668: str             x16, [SP, #-8]!
    // 0x69066c: r0 = _resolve()
    //     0x69066c: bl              #0x690778  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::_resolve
    // 0x690670: add             SP, SP, #8
    // 0x690674: ldr             x3, [fp, #0x10]
    // 0x690678: LoadField: r4 = r3->field_5f
    //     0x690678: ldur            w4, [x3, #0x5f]
    // 0x69067c: DecompressPointer r4
    //     0x69067c: add             x4, x4, HEAP, lsl #32
    // 0x690680: stur            x4, [fp, #-0x10]
    // 0x690684: cmp             w4, NULL
    // 0x690688: b.eq            #0x690764
    // 0x69068c: LoadField: r5 = r4->field_17
    //     0x69068c: ldur            w5, [x4, #0x17]
    // 0x690690: DecompressPointer r5
    //     0x690690: add             x5, x5, HEAP, lsl #32
    // 0x690694: stur            x5, [fp, #-8]
    // 0x690698: cmp             w5, NULL
    // 0x69069c: b.eq            #0x690768
    // 0x6906a0: mov             x0, x5
    // 0x6906a4: r2 = Null
    //     0x6906a4: mov             x2, NULL
    // 0x6906a8: r1 = Null
    //     0x6906a8: mov             x1, NULL
    // 0x6906ac: r4 = LoadClassIdInstr(r0)
    //     0x6906ac: ldur            x4, [x0, #-1]
    //     0x6906b0: ubfx            x4, x4, #0xc, #0x14
    // 0x6906b4: sub             x4, x4, #0x7ff
    // 0x6906b8: cmp             x4, #0xb
    // 0x6906bc: b.ls            #0x6906d4
    // 0x6906c0: r8 = BoxParentData
    //     0x6906c0: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x6906c4: ldr             x8, [x8, #0x1b0]
    // 0x6906c8: r3 = Null
    //     0x6906c8: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1ce70] Null
    //     0x6906cc: ldr             x3, [x3, #0xe70]
    // 0x6906d0: r0 = DefaultTypeTest()
    //     0x6906d0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6906d4: ldr             x0, [fp, #0x10]
    // 0x6906d8: LoadField: r1 = r0->field_63
    //     0x6906d8: ldur            w1, [x0, #0x63]
    // 0x6906dc: DecompressPointer r1
    //     0x6906dc: add             x1, x1, HEAP, lsl #32
    // 0x6906e0: stur            x1, [fp, #-0x18]
    // 0x6906e4: cmp             w1, NULL
    // 0x6906e8: b.eq            #0x69076c
    // 0x6906ec: LoadField: r2 = r0->field_57
    //     0x6906ec: ldur            w2, [x0, #0x57]
    // 0x6906f0: DecompressPointer r2
    //     0x6906f0: add             x2, x2, HEAP, lsl #32
    // 0x6906f4: cmp             w2, NULL
    // 0x6906f8: b.eq            #0x690770
    // 0x6906fc: ldur            x0, [fp, #-0x10]
    // 0x690700: LoadField: r3 = r0->field_57
    //     0x690700: ldur            w3, [x0, #0x57]
    // 0x690704: DecompressPointer r3
    //     0x690704: add             x3, x3, HEAP, lsl #32
    // 0x690708: cmp             w3, NULL
    // 0x69070c: b.eq            #0x690774
    // 0x690710: stp             x3, x2, [SP, #-0x10]!
    // 0x690714: r0 = -()
    //     0x690714: bl              #0x50e344  ; [dart:ui] Size::-
    // 0x690718: add             SP, SP, #0x10
    // 0x69071c: ldur            x16, [fp, #-0x18]
    // 0x690720: stp             x0, x16, [SP, #-0x10]!
    // 0x690724: r0 = alongOffset()
    //     0x690724: bl              #0x626350  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0x690728: add             SP, SP, #0x10
    // 0x69072c: ldur            x1, [fp, #-8]
    // 0x690730: StoreField: r1->field_7 = r0
    //     0x690730: stur            w0, [x1, #7]
    //     0x690734: ldurb           w16, [x1, #-1]
    //     0x690738: ldurb           w17, [x0, #-1]
    //     0x69073c: and             x16, x17, x16, lsr #2
    //     0x690740: tst             x16, HEAP, lsr #32
    //     0x690744: b.eq            #0x69074c
    //     0x690748: bl              #0xd6826c
    // 0x69074c: r0 = Null
    //     0x69074c: mov             x0, NULL
    // 0x690750: LeaveFrame
    //     0x690750: mov             SP, fp
    //     0x690754: ldp             fp, lr, [SP], #0x10
    // 0x690758: ret
    //     0x690758: ret             
    // 0x69075c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69075c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x690760: b               #0x690664
    // 0x690764: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x690764: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x690768: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x690768: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69076c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69076c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x690770: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x690770: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x690774: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x690774: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _resolve(/* No info */) {
    // ** addr: 0x690778, size: 0x19c
    // 0x690778: EnterFrame
    //     0x690778: stp             fp, lr, [SP, #-0x10]!
    //     0x69077c: mov             fp, SP
    // 0x690780: AllocStack(0x10)
    //     0x690780: sub             SP, SP, #0x10
    // 0x690784: ldr             x0, [fp, #0x10]
    // 0x690788: LoadField: r1 = r0->field_63
    //     0x690788: ldur            w1, [x0, #0x63]
    // 0x69078c: DecompressPointer r1
    //     0x69078c: add             x1, x1, HEAP, lsl #32
    // 0x690790: cmp             w1, NULL
    // 0x690794: b.eq            #0x6907a8
    // 0x690798: r0 = Null
    //     0x690798: mov             x0, NULL
    // 0x69079c: LeaveFrame
    //     0x69079c: mov             SP, fp
    //     0x6907a0: ldp             fp, lr, [SP], #0x10
    // 0x6907a4: ret
    //     0x6907a4: ret             
    // 0x6907a8: LoadField: r1 = r0->field_67
    //     0x6907a8: ldur            w1, [x0, #0x67]
    // 0x6907ac: DecompressPointer r1
    //     0x6907ac: add             x1, x1, HEAP, lsl #32
    // 0x6907b0: LoadField: r2 = r0->field_6b
    //     0x6907b0: ldur            w2, [x0, #0x6b]
    // 0x6907b4: DecompressPointer r2
    //     0x6907b4: add             x2, x2, HEAP, lsl #32
    // 0x6907b8: r3 = LoadClassIdInstr(r1)
    //     0x6907b8: ldur            x3, [x1, #-1]
    //     0x6907bc: ubfx            x3, x3, #0xc, #0x14
    // 0x6907c0: lsl             x3, x3, #1
    // 0x6907c4: r17 = 4240
    //     0x6907c4: mov             x17, #0x1090
    // 0x6907c8: cmp             w3, w17
    // 0x6907cc: b.gt            #0x6907ec
    // 0x6907d0: r17 = 4238
    //     0x6907d0: mov             x17, #0x108e
    // 0x6907d4: cmp             w3, w17
    // 0x6907d8: b.lt            #0x6907ec
    // 0x6907dc: mov             x16, x0
    // 0x6907e0: mov             x0, x1
    // 0x6907e4: mov             x1, x16
    // 0x6907e8: b               #0x6908e0
    // 0x6907ec: r17 = 4234
    //     0x6907ec: mov             x17, #0x108a
    // 0x6907f0: cmp             w3, w17
    // 0x6907f4: b.ne            #0x690874
    // 0x6907f8: cmp             w2, NULL
    // 0x6907fc: b.eq            #0x69090c
    // 0x690800: LoadField: r3 = r2->field_7
    //     0x690800: ldur            x3, [x2, #7]
    // 0x690804: cmp             x3, #0
    // 0x690808: b.gt            #0x690840
    // 0x69080c: LoadField: d0 = r1->field_7
    //     0x69080c: ldur            d0, [x1, #7]
    // 0x690810: LoadField: d1 = r1->field_f
    //     0x690810: ldur            d1, [x1, #0xf]
    // 0x690814: fsub            d2, d0, d1
    // 0x690818: stur            d2, [fp, #-0x10]
    // 0x69081c: LoadField: d0 = r1->field_17
    //     0x69081c: ldur            d0, [x1, #0x17]
    // 0x690820: stur            d0, [fp, #-8]
    // 0x690824: r0 = Alignment()
    //     0x690824: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x690828: ldur            d0, [fp, #-0x10]
    // 0x69082c: StoreField: r0->field_7 = d0
    //     0x69082c: stur            d0, [x0, #7]
    // 0x690830: ldur            d0, [fp, #-8]
    // 0x690834: StoreField: r0->field_f = d0
    //     0x690834: stur            d0, [x0, #0xf]
    // 0x690838: ldr             x1, [fp, #0x10]
    // 0x69083c: b               #0x6908e0
    // 0x690840: LoadField: d0 = r1->field_7
    //     0x690840: ldur            d0, [x1, #7]
    // 0x690844: LoadField: d1 = r1->field_f
    //     0x690844: ldur            d1, [x1, #0xf]
    // 0x690848: fadd            d2, d0, d1
    // 0x69084c: stur            d2, [fp, #-0x10]
    // 0x690850: LoadField: d0 = r1->field_17
    //     0x690850: ldur            d0, [x1, #0x17]
    // 0x690854: stur            d0, [fp, #-8]
    // 0x690858: r0 = Alignment()
    //     0x690858: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x69085c: ldur            d0, [fp, #-0x10]
    // 0x690860: StoreField: r0->field_7 = d0
    //     0x690860: stur            d0, [x0, #7]
    // 0x690864: ldur            d0, [fp, #-8]
    // 0x690868: StoreField: r0->field_f = d0
    //     0x690868: stur            d0, [x0, #0xf]
    // 0x69086c: ldr             x1, [fp, #0x10]
    // 0x690870: b               #0x6908e0
    // 0x690874: cmp             w2, NULL
    // 0x690878: b.eq            #0x690910
    // 0x69087c: LoadField: r0 = r2->field_7
    //     0x69087c: ldur            x0, [x2, #7]
    // 0x690880: cmp             x0, #0
    // 0x690884: b.gt            #0x6908b8
    // 0x690888: LoadField: d0 = r1->field_7
    //     0x690888: ldur            d0, [x1, #7]
    // 0x69088c: fneg            d1, d0
    // 0x690890: stur            d1, [fp, #-0x10]
    // 0x690894: LoadField: d0 = r1->field_f
    //     0x690894: ldur            d0, [x1, #0xf]
    // 0x690898: stur            d0, [fp, #-8]
    // 0x69089c: r0 = Alignment()
    //     0x69089c: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x6908a0: ldur            d0, [fp, #-0x10]
    // 0x6908a4: StoreField: r0->field_7 = d0
    //     0x6908a4: stur            d0, [x0, #7]
    // 0x6908a8: ldur            d0, [fp, #-8]
    // 0x6908ac: StoreField: r0->field_f = d0
    //     0x6908ac: stur            d0, [x0, #0xf]
    // 0x6908b0: ldr             x1, [fp, #0x10]
    // 0x6908b4: b               #0x6908e0
    // 0x6908b8: LoadField: d0 = r1->field_7
    //     0x6908b8: ldur            d0, [x1, #7]
    // 0x6908bc: stur            d0, [fp, #-0x10]
    // 0x6908c0: LoadField: d1 = r1->field_f
    //     0x6908c0: ldur            d1, [x1, #0xf]
    // 0x6908c4: stur            d1, [fp, #-8]
    // 0x6908c8: r0 = Alignment()
    //     0x6908c8: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x6908cc: ldur            d0, [fp, #-0x10]
    // 0x6908d0: StoreField: r0->field_7 = d0
    //     0x6908d0: stur            d0, [x0, #7]
    // 0x6908d4: ldur            d0, [fp, #-8]
    // 0x6908d8: StoreField: r0->field_f = d0
    //     0x6908d8: stur            d0, [x0, #0xf]
    // 0x6908dc: ldr             x1, [fp, #0x10]
    // 0x6908e0: StoreField: r1->field_63 = r0
    //     0x6908e0: stur            w0, [x1, #0x63]
    //     0x6908e4: ldurb           w16, [x1, #-1]
    //     0x6908e8: ldurb           w17, [x0, #-1]
    //     0x6908ec: and             x16, x17, x16, lsr #2
    //     0x6908f0: tst             x16, HEAP, lsr #32
    //     0x6908f4: b.eq            #0x6908fc
    //     0x6908f8: bl              #0xd6826c
    // 0x6908fc: r0 = Null
    //     0x6908fc: mov             x0, NULL
    // 0x690900: LeaveFrame
    //     0x690900: mov             SP, fp
    //     0x690904: ldp             fp, lr, [SP], #0x10
    // 0x690908: ret
    //     0x690908: ret             
    // 0x69090c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69090c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x690910: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x690910: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0x6c257c, size: 0x80
    // 0x6c257c: EnterFrame
    //     0x6c257c: stp             fp, lr, [SP, #-0x10]!
    //     0x6c2580: mov             fp, SP
    // 0x6c2584: CheckStackOverflow
    //     0x6c2584: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c2588: cmp             SP, x16
    //     0x6c258c: b.ls            #0x6c25f4
    // 0x6c2590: ldr             x1, [fp, #0x18]
    // 0x6c2594: LoadField: r0 = r1->field_6b
    //     0x6c2594: ldur            w0, [x1, #0x6b]
    // 0x6c2598: DecompressPointer r0
    //     0x6c2598: add             x0, x0, HEAP, lsl #32
    // 0x6c259c: ldr             x2, [fp, #0x10]
    // 0x6c25a0: cmp             w0, w2
    // 0x6c25a4: b.ne            #0x6c25b8
    // 0x6c25a8: r0 = Null
    //     0x6c25a8: mov             x0, NULL
    // 0x6c25ac: LeaveFrame
    //     0x6c25ac: mov             SP, fp
    //     0x6c25b0: ldp             fp, lr, [SP], #0x10
    // 0x6c25b4: ret
    //     0x6c25b4: ret             
    // 0x6c25b8: mov             x0, x2
    // 0x6c25bc: StoreField: r1->field_6b = r0
    //     0x6c25bc: stur            w0, [x1, #0x6b]
    //     0x6c25c0: ldurb           w16, [x1, #-1]
    //     0x6c25c4: ldurb           w17, [x0, #-1]
    //     0x6c25c8: and             x16, x17, x16, lsr #2
    //     0x6c25cc: tst             x16, HEAP, lsr #32
    //     0x6c25d0: b.eq            #0x6c25d8
    //     0x6c25d4: bl              #0xd6826c
    // 0x6c25d8: SaveReg r1
    //     0x6c25d8: str             x1, [SP, #-8]!
    // 0x6c25dc: r0 = _markNeedResolution()
    //     0x6c25dc: bl              #0x6c25fc  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::_markNeedResolution
    // 0x6c25e0: add             SP, SP, #8
    // 0x6c25e4: r0 = Null
    //     0x6c25e4: mov             x0, NULL
    // 0x6c25e8: LeaveFrame
    //     0x6c25e8: mov             SP, fp
    //     0x6c25ec: ldp             fp, lr, [SP], #0x10
    // 0x6c25f0: ret
    //     0x6c25f0: ret             
    // 0x6c25f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c25f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c25f8: b               #0x6c2590
  }
  _ _markNeedResolution(/* No info */) {
    // ** addr: 0x6c25fc, size: 0x40
    // 0x6c25fc: EnterFrame
    //     0x6c25fc: stp             fp, lr, [SP, #-0x10]!
    //     0x6c2600: mov             fp, SP
    // 0x6c2604: CheckStackOverflow
    //     0x6c2604: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c2608: cmp             SP, x16
    //     0x6c260c: b.ls            #0x6c2634
    // 0x6c2610: ldr             x0, [fp, #0x10]
    // 0x6c2614: StoreField: r0->field_63 = rNULL
    //     0x6c2614: stur            NULL, [x0, #0x63]
    // 0x6c2618: SaveReg r0
    //     0x6c2618: str             x0, [SP, #-8]!
    // 0x6c261c: r0 = markNeedsLayout()
    //     0x6c261c: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c2620: add             SP, SP, #8
    // 0x6c2624: r0 = Null
    //     0x6c2624: mov             x0, NULL
    // 0x6c2628: LeaveFrame
    //     0x6c2628: mov             SP, fp
    //     0x6c262c: ldp             fp, lr, [SP], #0x10
    // 0x6c2630: ret
    //     0x6c2630: ret             
    // 0x6c2634: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c2634: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c2638: b               #0x6c2610
  }
  set _ alignment=(/* No info */) {
    // ** addr: 0x6c33b8, size: 0x8c
    // 0x6c33b8: EnterFrame
    //     0x6c33b8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c33bc: mov             fp, SP
    // 0x6c33c0: CheckStackOverflow
    //     0x6c33c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c33c4: cmp             SP, x16
    //     0x6c33c8: b.ls            #0x6c343c
    // 0x6c33cc: ldr             x0, [fp, #0x18]
    // 0x6c33d0: LoadField: r1 = r0->field_67
    //     0x6c33d0: ldur            w1, [x0, #0x67]
    // 0x6c33d4: DecompressPointer r1
    //     0x6c33d4: add             x1, x1, HEAP, lsl #32
    // 0x6c33d8: ldr             x16, [fp, #0x10]
    // 0x6c33dc: stp             x16, x1, [SP, #-0x10]!
    // 0x6c33e0: r0 = ==()
    //     0x6c33e0: bl              #0xc9c720  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::==
    // 0x6c33e4: add             SP, SP, #0x10
    // 0x6c33e8: tbnz            w0, #4, #0x6c33fc
    // 0x6c33ec: r0 = Null
    //     0x6c33ec: mov             x0, NULL
    // 0x6c33f0: LeaveFrame
    //     0x6c33f0: mov             SP, fp
    //     0x6c33f4: ldp             fp, lr, [SP], #0x10
    // 0x6c33f8: ret
    //     0x6c33f8: ret             
    // 0x6c33fc: ldr             x1, [fp, #0x18]
    // 0x6c3400: ldr             x0, [fp, #0x10]
    // 0x6c3404: StoreField: r1->field_67 = r0
    //     0x6c3404: stur            w0, [x1, #0x67]
    //     0x6c3408: ldurb           w16, [x1, #-1]
    //     0x6c340c: ldurb           w17, [x0, #-1]
    //     0x6c3410: and             x16, x17, x16, lsr #2
    //     0x6c3414: tst             x16, HEAP, lsr #32
    //     0x6c3418: b.eq            #0x6c3420
    //     0x6c341c: bl              #0xd6826c
    // 0x6c3420: SaveReg r1
    //     0x6c3420: str             x1, [SP, #-8]!
    // 0x6c3424: r0 = _markNeedResolution()
    //     0x6c3424: bl              #0x6c25fc  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::_markNeedResolution
    // 0x6c3428: add             SP, SP, #8
    // 0x6c342c: r0 = Null
    //     0x6c342c: mov             x0, NULL
    // 0x6c3430: LeaveFrame
    //     0x6c3430: mov             SP, fp
    //     0x6c3434: ldp             fp, lr, [SP], #0x10
    // 0x6c3438: ret
    //     0x6c3438: ret             
    // 0x6c343c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c343c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c3440: b               #0x6c33cc
  }
}

// class id: 2464, size: 0x7c, field offset: 0x70
class RenderFractionallySizedOverflowBox extends RenderAligningShiftedBox {

  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x62f268, size: 0x18
    // 0x62f268: r4 = 0
    //     0x62f268: mov             x4, #0
    // 0x62f26c: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x62f26c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b1c8] AnonymousClosure: (0x62f280), in [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::computeMaxIntrinsicHeight (0x62f2cc)
    //     0x62f270: ldr             x1, [x17, #0x1c8]
    // 0x62f274: r24 = BuildNonGenericMethodExtractorStub
    //     0x62f274: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x62f278: LoadField: r0 = r24->field_17
    //     0x62f278: ldur            x0, [x24, #0x17]
    // 0x62f27c: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x62f280, size: 0x4c
    // 0x62f280: EnterFrame
    //     0x62f280: stp             fp, lr, [SP, #-0x10]!
    //     0x62f284: mov             fp, SP
    // 0x62f288: ldr             x0, [fp, #0x18]
    // 0x62f28c: LoadField: r1 = r0->field_17
    //     0x62f28c: ldur            w1, [x0, #0x17]
    // 0x62f290: DecompressPointer r1
    //     0x62f290: add             x1, x1, HEAP, lsl #32
    // 0x62f294: CheckStackOverflow
    //     0x62f294: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62f298: cmp             SP, x16
    //     0x62f29c: b.ls            #0x62f2c4
    // 0x62f2a0: LoadField: r0 = r1->field_f
    //     0x62f2a0: ldur            w0, [x1, #0xf]
    // 0x62f2a4: DecompressPointer r0
    //     0x62f2a4: add             x0, x0, HEAP, lsl #32
    // 0x62f2a8: ldr             x16, [fp, #0x10]
    // 0x62f2ac: stp             x16, x0, [SP, #-0x10]!
    // 0x62f2b0: r0 = computeMaxIntrinsicHeight()
    //     0x62f2b0: bl              #0x62f2cc  ; [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::computeMaxIntrinsicHeight
    // 0x62f2b4: add             SP, SP, #0x10
    // 0x62f2b8: LeaveFrame
    //     0x62f2b8: mov             SP, fp
    //     0x62f2bc: ldp             fp, lr, [SP], #0x10
    // 0x62f2c0: ret
    //     0x62f2c0: ret             
    // 0x62f2c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62f2c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62f2c8: b               #0x62f2a0
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0x62f2cc, size: 0xd0
    // 0x62f2cc: EnterFrame
    //     0x62f2cc: stp             fp, lr, [SP, #-0x10]!
    //     0x62f2d0: mov             fp, SP
    // 0x62f2d4: CheckStackOverflow
    //     0x62f2d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62f2d8: cmp             SP, x16
    //     0x62f2dc: b.ls            #0x62f384
    // 0x62f2e0: ldr             x0, [fp, #0x18]
    // 0x62f2e4: LoadField: r1 = r0->field_5f
    //     0x62f2e4: ldur            w1, [x0, #0x5f]
    // 0x62f2e8: DecompressPointer r1
    //     0x62f2e8: add             x1, x1, HEAP, lsl #32
    // 0x62f2ec: cmp             w1, NULL
    // 0x62f2f0: b.ne            #0x62f30c
    // 0x62f2f4: ldr             x16, [fp, #0x10]
    // 0x62f2f8: stp             x16, x0, [SP, #-0x10]!
    // 0x62f2fc: r0 = computeMaxIntrinsicHeight()
    //     0x62f2fc: bl              #0x62f064  ; [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::computeMaxIntrinsicHeight
    // 0x62f300: add             SP, SP, #0x10
    // 0x62f304: LoadField: d0 = r0->field_7
    //     0x62f304: ldur            d0, [x0, #7]
    // 0x62f308: b               #0x62f32c
    // 0x62f30c: ldr             x2, [fp, #0x10]
    // 0x62f310: LoadField: d0 = r0->field_6f
    //     0x62f310: ldur            d0, [x0, #0x6f]
    // 0x62f314: LoadField: d1 = r2->field_7
    //     0x62f314: ldur            d1, [x2, #7]
    // 0x62f318: fmul            d2, d1, d0
    // 0x62f31c: SaveReg r1
    //     0x62f31c: str             x1, [SP, #-8]!
    // 0x62f320: SaveReg d2
    //     0x62f320: str             d2, [SP, #-8]!
    // 0x62f324: r0 = getMaxIntrinsicHeight()
    //     0x62f324: bl              #0x62cb24  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0x62f328: add             SP, SP, #0x10
    // 0x62f32c: ldr             x1, [fp, #0x18]
    // 0x62f330: LoadField: r2 = r1->field_77
    //     0x62f330: ldur            w2, [x1, #0x77]
    // 0x62f334: DecompressPointer r2
    //     0x62f334: add             x2, x2, HEAP, lsl #32
    // 0x62f338: cmp             w2, NULL
    // 0x62f33c: b.ne            #0x62f348
    // 0x62f340: d1 = 1.000000
    //     0x62f340: fmov            d1, #1.00000000
    // 0x62f344: b               #0x62f34c
    // 0x62f348: LoadField: d1 = r2->field_7
    //     0x62f348: ldur            d1, [x2, #7]
    // 0x62f34c: fdiv            d2, d0, d1
    // 0x62f350: r0 = inline_Allocate_Double()
    //     0x62f350: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62f354: add             x0, x0, #0x10
    //     0x62f358: cmp             x1, x0
    //     0x62f35c: b.ls            #0x62f38c
    //     0x62f360: str             x0, [THR, #0x60]  ; THR::top
    //     0x62f364: sub             x0, x0, #0xf
    //     0x62f368: mov             x1, #0xd108
    //     0x62f36c: movk            x1, #3, lsl #16
    //     0x62f370: stur            x1, [x0, #-1]
    // 0x62f374: StoreField: r0->field_7 = d2
    //     0x62f374: stur            d2, [x0, #7]
    // 0x62f378: LeaveFrame
    //     0x62f378: mov             SP, fp
    //     0x62f37c: ldp             fp, lr, [SP], #0x10
    // 0x62f380: ret
    //     0x62f380: ret             
    // 0x62f384: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62f384: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62f388: b               #0x62f2e0
    // 0x62f38c: SaveReg d2
    //     0x62f38c: str             q2, [SP, #-0x10]!
    // 0x62f390: r0 = AllocateDouble()
    //     0x62f390: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62f394: RestoreReg d2
    //     0x62f394: ldr             q2, [SP], #0x10
    // 0x62f398: b               #0x62f374
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x635c80, size: 0x18
    // 0x635c80: r4 = 0
    //     0x635c80: mov             x4, #0
    // 0x635c84: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x635c84: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fba0] AnonymousClosure: (0x635c98), in [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::computeMaxIntrinsicWidth (0x635ce4)
    //     0x635c88: ldr             x1, [x17, #0xba0]
    // 0x635c8c: r24 = BuildNonGenericMethodExtractorStub
    //     0x635c8c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x635c90: LoadField: r0 = r24->field_17
    //     0x635c90: ldur            x0, [x24, #0x17]
    // 0x635c94: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x635c98, size: 0x4c
    // 0x635c98: EnterFrame
    //     0x635c98: stp             fp, lr, [SP, #-0x10]!
    //     0x635c9c: mov             fp, SP
    // 0x635ca0: ldr             x0, [fp, #0x18]
    // 0x635ca4: LoadField: r1 = r0->field_17
    //     0x635ca4: ldur            w1, [x0, #0x17]
    // 0x635ca8: DecompressPointer r1
    //     0x635ca8: add             x1, x1, HEAP, lsl #32
    // 0x635cac: CheckStackOverflow
    //     0x635cac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x635cb0: cmp             SP, x16
    //     0x635cb4: b.ls            #0x635cdc
    // 0x635cb8: LoadField: r0 = r1->field_f
    //     0x635cb8: ldur            w0, [x1, #0xf]
    // 0x635cbc: DecompressPointer r0
    //     0x635cbc: add             x0, x0, HEAP, lsl #32
    // 0x635cc0: ldr             x16, [fp, #0x10]
    // 0x635cc4: stp             x16, x0, [SP, #-0x10]!
    // 0x635cc8: r0 = computeMaxIntrinsicWidth()
    //     0x635cc8: bl              #0x635ce4  ; [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::computeMaxIntrinsicWidth
    // 0x635ccc: add             SP, SP, #0x10
    // 0x635cd0: LeaveFrame
    //     0x635cd0: mov             SP, fp
    //     0x635cd4: ldp             fp, lr, [SP], #0x10
    // 0x635cd8: ret
    //     0x635cd8: ret             
    // 0x635cdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x635cdc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x635ce0: b               #0x635cb8
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0x635ce4, size: 0xd0
    // 0x635ce4: EnterFrame
    //     0x635ce4: stp             fp, lr, [SP, #-0x10]!
    //     0x635ce8: mov             fp, SP
    // 0x635cec: CheckStackOverflow
    //     0x635cec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x635cf0: cmp             SP, x16
    //     0x635cf4: b.ls            #0x635d9c
    // 0x635cf8: ldr             x0, [fp, #0x18]
    // 0x635cfc: LoadField: r1 = r0->field_5f
    //     0x635cfc: ldur            w1, [x0, #0x5f]
    // 0x635d00: DecompressPointer r1
    //     0x635d00: add             x1, x1, HEAP, lsl #32
    // 0x635d04: cmp             w1, NULL
    // 0x635d08: b.ne            #0x635d24
    // 0x635d0c: ldr             x16, [fp, #0x10]
    // 0x635d10: stp             x16, x0, [SP, #-0x10]!
    // 0x635d14: r0 = computeMaxIntrinsicWidth()
    //     0x635d14: bl              #0x635a7c  ; [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::computeMaxIntrinsicWidth
    // 0x635d18: add             SP, SP, #0x10
    // 0x635d1c: LoadField: d0 = r0->field_7
    //     0x635d1c: ldur            d0, [x0, #7]
    // 0x635d20: b               #0x635d5c
    // 0x635d24: LoadField: r2 = r0->field_77
    //     0x635d24: ldur            w2, [x0, #0x77]
    // 0x635d28: DecompressPointer r2
    //     0x635d28: add             x2, x2, HEAP, lsl #32
    // 0x635d2c: cmp             w2, NULL
    // 0x635d30: b.ne            #0x635d3c
    // 0x635d34: d0 = 1.000000
    //     0x635d34: fmov            d0, #1.00000000
    // 0x635d38: b               #0x635d40
    // 0x635d3c: LoadField: d0 = r2->field_7
    //     0x635d3c: ldur            d0, [x2, #7]
    // 0x635d40: ldr             x2, [fp, #0x10]
    // 0x635d44: LoadField: d1 = r2->field_7
    //     0x635d44: ldur            d1, [x2, #7]
    // 0x635d48: fmul            d2, d1, d0
    // 0x635d4c: SaveReg r1
    //     0x635d4c: str             x1, [SP, #-8]!
    // 0x635d50: SaveReg d2
    //     0x635d50: str             d2, [SP, #-8]!
    // 0x635d54: r0 = getMaxIntrinsicWidth()
    //     0x635d54: bl              #0x62cb94  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0x635d58: add             SP, SP, #0x10
    // 0x635d5c: ldr             x1, [fp, #0x18]
    // 0x635d60: LoadField: d1 = r1->field_6f
    //     0x635d60: ldur            d1, [x1, #0x6f]
    // 0x635d64: fdiv            d2, d0, d1
    // 0x635d68: r0 = inline_Allocate_Double()
    //     0x635d68: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x635d6c: add             x0, x0, #0x10
    //     0x635d70: cmp             x1, x0
    //     0x635d74: b.ls            #0x635da4
    //     0x635d78: str             x0, [THR, #0x60]  ; THR::top
    //     0x635d7c: sub             x0, x0, #0xf
    //     0x635d80: mov             x1, #0xd108
    //     0x635d84: movk            x1, #3, lsl #16
    //     0x635d88: stur            x1, [x0, #-1]
    // 0x635d8c: StoreField: r0->field_7 = d2
    //     0x635d8c: stur            d2, [x0, #7]
    // 0x635d90: LeaveFrame
    //     0x635d90: mov             SP, fp
    //     0x635d94: ldp             fp, lr, [SP], #0x10
    // 0x635d98: ret
    //     0x635d98: ret             
    // 0x635d9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x635d9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x635da0: b               #0x635cf8
    // 0x635da4: SaveReg d2
    //     0x635da4: str             q2, [SP, #-0x10]!
    // 0x635da8: r0 = AllocateDouble()
    //     0x635da8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x635dac: RestoreReg d2
    //     0x635dac: ldr             q2, [SP], #0x10
    // 0x635db0: b               #0x635d8c
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x638ecc, size: 0x18
    // 0x638ecc: r4 = 0
    //     0x638ecc: mov             x4, #0
    // 0x638ed0: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x638ed0: add             x17, PP, #0x52, lsl #12  ; [pp+0x52e60] AnonymousClosure: (0x638ee4), in [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::computeMinIntrinsicHeight (0x638f30)
    //     0x638ed4: ldr             x1, [x17, #0xe60]
    // 0x638ed8: r24 = BuildNonGenericMethodExtractorStub
    //     0x638ed8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x638edc: LoadField: r0 = r24->field_17
    //     0x638edc: ldur            x0, [x24, #0x17]
    // 0x638ee0: br              x0
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x638ee4, size: 0x4c
    // 0x638ee4: EnterFrame
    //     0x638ee4: stp             fp, lr, [SP, #-0x10]!
    //     0x638ee8: mov             fp, SP
    // 0x638eec: ldr             x0, [fp, #0x18]
    // 0x638ef0: LoadField: r1 = r0->field_17
    //     0x638ef0: ldur            w1, [x0, #0x17]
    // 0x638ef4: DecompressPointer r1
    //     0x638ef4: add             x1, x1, HEAP, lsl #32
    // 0x638ef8: CheckStackOverflow
    //     0x638ef8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x638efc: cmp             SP, x16
    //     0x638f00: b.ls            #0x638f28
    // 0x638f04: LoadField: r0 = r1->field_f
    //     0x638f04: ldur            w0, [x1, #0xf]
    // 0x638f08: DecompressPointer r0
    //     0x638f08: add             x0, x0, HEAP, lsl #32
    // 0x638f0c: ldr             x16, [fp, #0x10]
    // 0x638f10: stp             x16, x0, [SP, #-0x10]!
    // 0x638f14: r0 = computeMinIntrinsicHeight()
    //     0x638f14: bl              #0x638f30  ; [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::computeMinIntrinsicHeight
    // 0x638f18: add             SP, SP, #0x10
    // 0x638f1c: LeaveFrame
    //     0x638f1c: mov             SP, fp
    //     0x638f20: ldp             fp, lr, [SP], #0x10
    // 0x638f24: ret
    //     0x638f24: ret             
    // 0x638f28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x638f28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x638f2c: b               #0x638f04
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0x638f30, size: 0xd0
    // 0x638f30: EnterFrame
    //     0x638f30: stp             fp, lr, [SP, #-0x10]!
    //     0x638f34: mov             fp, SP
    // 0x638f38: CheckStackOverflow
    //     0x638f38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x638f3c: cmp             SP, x16
    //     0x638f40: b.ls            #0x638fe8
    // 0x638f44: ldr             x0, [fp, #0x18]
    // 0x638f48: LoadField: r1 = r0->field_5f
    //     0x638f48: ldur            w1, [x0, #0x5f]
    // 0x638f4c: DecompressPointer r1
    //     0x638f4c: add             x1, x1, HEAP, lsl #32
    // 0x638f50: cmp             w1, NULL
    // 0x638f54: b.ne            #0x638f70
    // 0x638f58: ldr             x16, [fp, #0x10]
    // 0x638f5c: stp             x16, x0, [SP, #-0x10]!
    // 0x638f60: r0 = computeMinIntrinsicHeight()
    //     0x638f60: bl              #0x638cc8  ; [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::computeMinIntrinsicHeight
    // 0x638f64: add             SP, SP, #0x10
    // 0x638f68: LoadField: d0 = r0->field_7
    //     0x638f68: ldur            d0, [x0, #7]
    // 0x638f6c: b               #0x638f90
    // 0x638f70: ldr             x2, [fp, #0x10]
    // 0x638f74: LoadField: d0 = r0->field_6f
    //     0x638f74: ldur            d0, [x0, #0x6f]
    // 0x638f78: LoadField: d1 = r2->field_7
    //     0x638f78: ldur            d1, [x2, #7]
    // 0x638f7c: fmul            d2, d1, d0
    // 0x638f80: SaveReg r1
    //     0x638f80: str             x1, [SP, #-8]!
    // 0x638f84: SaveReg d2
    //     0x638f84: str             d2, [SP, #-8]!
    // 0x638f88: r0 = getMinIntrinsicHeight()
    //     0x638f88: bl              #0x630a58  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0x638f8c: add             SP, SP, #0x10
    // 0x638f90: ldr             x1, [fp, #0x18]
    // 0x638f94: LoadField: r2 = r1->field_77
    //     0x638f94: ldur            w2, [x1, #0x77]
    // 0x638f98: DecompressPointer r2
    //     0x638f98: add             x2, x2, HEAP, lsl #32
    // 0x638f9c: cmp             w2, NULL
    // 0x638fa0: b.ne            #0x638fac
    // 0x638fa4: d1 = 1.000000
    //     0x638fa4: fmov            d1, #1.00000000
    // 0x638fa8: b               #0x638fb0
    // 0x638fac: LoadField: d1 = r2->field_7
    //     0x638fac: ldur            d1, [x2, #7]
    // 0x638fb0: fdiv            d2, d0, d1
    // 0x638fb4: r0 = inline_Allocate_Double()
    //     0x638fb4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x638fb8: add             x0, x0, #0x10
    //     0x638fbc: cmp             x1, x0
    //     0x638fc0: b.ls            #0x638ff0
    //     0x638fc4: str             x0, [THR, #0x60]  ; THR::top
    //     0x638fc8: sub             x0, x0, #0xf
    //     0x638fcc: mov             x1, #0xd108
    //     0x638fd0: movk            x1, #3, lsl #16
    //     0x638fd4: stur            x1, [x0, #-1]
    // 0x638fd8: StoreField: r0->field_7 = d2
    //     0x638fd8: stur            d2, [x0, #7]
    // 0x638fdc: LeaveFrame
    //     0x638fdc: mov             SP, fp
    //     0x638fe0: ldp             fp, lr, [SP], #0x10
    // 0x638fe4: ret
    //     0x638fe4: ret             
    // 0x638fe8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x638fe8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x638fec: b               #0x638f44
    // 0x638ff0: SaveReg d2
    //     0x638ff0: str             q2, [SP, #-0x10]!
    // 0x638ff4: r0 = AllocateDouble()
    //     0x638ff4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x638ff8: RestoreReg d2
    //     0x638ff8: ldr             q2, [SP], #0x10
    // 0x638ffc: b               #0x638fd8
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63bb08, size: 0x18
    // 0x63bb08: r4 = 0
    //     0x63bb08: mov             x4, #0
    // 0x63bb0c: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63bb0c: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fcd0] AnonymousClosure: (0x63bb20), in [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::computeMinIntrinsicWidth (0x63bb6c)
    //     0x63bb10: ldr             x1, [x17, #0xcd0]
    // 0x63bb14: r24 = BuildNonGenericMethodExtractorStub
    //     0x63bb14: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63bb18: LoadField: r0 = r24->field_17
    //     0x63bb18: ldur            x0, [x24, #0x17]
    // 0x63bb1c: br              x0
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63bb20, size: 0x4c
    // 0x63bb20: EnterFrame
    //     0x63bb20: stp             fp, lr, [SP, #-0x10]!
    //     0x63bb24: mov             fp, SP
    // 0x63bb28: ldr             x0, [fp, #0x18]
    // 0x63bb2c: LoadField: r1 = r0->field_17
    //     0x63bb2c: ldur            w1, [x0, #0x17]
    // 0x63bb30: DecompressPointer r1
    //     0x63bb30: add             x1, x1, HEAP, lsl #32
    // 0x63bb34: CheckStackOverflow
    //     0x63bb34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63bb38: cmp             SP, x16
    //     0x63bb3c: b.ls            #0x63bb64
    // 0x63bb40: LoadField: r0 = r1->field_f
    //     0x63bb40: ldur            w0, [x1, #0xf]
    // 0x63bb44: DecompressPointer r0
    //     0x63bb44: add             x0, x0, HEAP, lsl #32
    // 0x63bb48: ldr             x16, [fp, #0x10]
    // 0x63bb4c: stp             x16, x0, [SP, #-0x10]!
    // 0x63bb50: r0 = computeMinIntrinsicWidth()
    //     0x63bb50: bl              #0x63bb6c  ; [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::computeMinIntrinsicWidth
    // 0x63bb54: add             SP, SP, #0x10
    // 0x63bb58: LeaveFrame
    //     0x63bb58: mov             SP, fp
    //     0x63bb5c: ldp             fp, lr, [SP], #0x10
    // 0x63bb60: ret
    //     0x63bb60: ret             
    // 0x63bb64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63bb64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63bb68: b               #0x63bb40
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0x63bb6c, size: 0xd0
    // 0x63bb6c: EnterFrame
    //     0x63bb6c: stp             fp, lr, [SP, #-0x10]!
    //     0x63bb70: mov             fp, SP
    // 0x63bb74: CheckStackOverflow
    //     0x63bb74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63bb78: cmp             SP, x16
    //     0x63bb7c: b.ls            #0x63bc24
    // 0x63bb80: ldr             x0, [fp, #0x18]
    // 0x63bb84: LoadField: r1 = r0->field_5f
    //     0x63bb84: ldur            w1, [x0, #0x5f]
    // 0x63bb88: DecompressPointer r1
    //     0x63bb88: add             x1, x1, HEAP, lsl #32
    // 0x63bb8c: cmp             w1, NULL
    // 0x63bb90: b.ne            #0x63bbac
    // 0x63bb94: ldr             x16, [fp, #0x10]
    // 0x63bb98: stp             x16, x0, [SP, #-0x10]!
    // 0x63bb9c: r0 = computeMinIntrinsicWidth()
    //     0x63bb9c: bl              #0x63b904  ; [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::computeMinIntrinsicWidth
    // 0x63bba0: add             SP, SP, #0x10
    // 0x63bba4: LoadField: d0 = r0->field_7
    //     0x63bba4: ldur            d0, [x0, #7]
    // 0x63bba8: b               #0x63bbe4
    // 0x63bbac: LoadField: r2 = r0->field_77
    //     0x63bbac: ldur            w2, [x0, #0x77]
    // 0x63bbb0: DecompressPointer r2
    //     0x63bbb0: add             x2, x2, HEAP, lsl #32
    // 0x63bbb4: cmp             w2, NULL
    // 0x63bbb8: b.ne            #0x63bbc4
    // 0x63bbbc: d0 = 1.000000
    //     0x63bbbc: fmov            d0, #1.00000000
    // 0x63bbc0: b               #0x63bbc8
    // 0x63bbc4: LoadField: d0 = r2->field_7
    //     0x63bbc4: ldur            d0, [x2, #7]
    // 0x63bbc8: ldr             x2, [fp, #0x10]
    // 0x63bbcc: LoadField: d1 = r2->field_7
    //     0x63bbcc: ldur            d1, [x2, #7]
    // 0x63bbd0: fmul            d2, d1, d0
    // 0x63bbd4: SaveReg r1
    //     0x63bbd4: str             x1, [SP, #-8]!
    // 0x63bbd8: SaveReg d2
    //     0x63bbd8: str             d2, [SP, #-8]!
    // 0x63bbdc: r0 = getMinIntrinsicWidth()
    //     0x63bbdc: bl              #0x630b18  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicWidth
    // 0x63bbe0: add             SP, SP, #0x10
    // 0x63bbe4: ldr             x1, [fp, #0x18]
    // 0x63bbe8: LoadField: d1 = r1->field_6f
    //     0x63bbe8: ldur            d1, [x1, #0x6f]
    // 0x63bbec: fdiv            d2, d0, d1
    // 0x63bbf0: r0 = inline_Allocate_Double()
    //     0x63bbf0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63bbf4: add             x0, x0, #0x10
    //     0x63bbf8: cmp             x1, x0
    //     0x63bbfc: b.ls            #0x63bc2c
    //     0x63bc00: str             x0, [THR, #0x60]  ; THR::top
    //     0x63bc04: sub             x0, x0, #0xf
    //     0x63bc08: mov             x1, #0xd108
    //     0x63bc0c: movk            x1, #3, lsl #16
    //     0x63bc10: stur            x1, [x0, #-1]
    // 0x63bc14: StoreField: r0->field_7 = d2
    //     0x63bc14: stur            d2, [x0, #7]
    // 0x63bc18: LeaveFrame
    //     0x63bc18: mov             SP, fp
    //     0x63bc1c: ldp             fp, lr, [SP], #0x10
    // 0x63bc20: ret
    //     0x63bc20: ret             
    // 0x63bc24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63bc24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63bc28: b               #0x63bb80
    // 0x63bc2c: SaveReg d2
    //     0x63bc2c: str             q2, [SP, #-0x10]!
    // 0x63bc30: r0 = AllocateDouble()
    //     0x63bc30: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63bc34: RestoreReg d2
    //     0x63bc34: ldr             q2, [SP], #0x10
    // 0x63bc38: b               #0x63bc14
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x692500, size: 0x29c
    // 0x692500: EnterFrame
    //     0x692500: stp             fp, lr, [SP, #-0x10]!
    //     0x692504: mov             fp, SP
    // 0x692508: AllocStack(0x10)
    //     0x692508: sub             SP, SP, #0x10
    // 0x69250c: CheckStackOverflow
    //     0x69250c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x692510: cmp             SP, x16
    //     0x692514: b.ls            #0x69278c
    // 0x692518: ldr             x3, [fp, #0x10]
    // 0x69251c: LoadField: r4 = r3->field_5f
    //     0x69251c: ldur            w4, [x3, #0x5f]
    // 0x692520: DecompressPointer r4
    //     0x692520: add             x4, x4, HEAP, lsl #32
    // 0x692524: stur            x4, [fp, #-0x10]
    // 0x692528: cmp             w4, NULL
    // 0x69252c: b.eq            #0x692680
    // 0x692530: LoadField: r5 = r3->field_27
    //     0x692530: ldur            w5, [x3, #0x27]
    // 0x692534: DecompressPointer r5
    //     0x692534: add             x5, x5, HEAP, lsl #32
    // 0x692538: stur            x5, [fp, #-8]
    // 0x69253c: cmp             w5, NULL
    // 0x692540: b.eq            #0x692734
    // 0x692544: r6 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x692544: add             x6, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x692548: ldr             x6, [x6, #0x1e8]
    // 0x69254c: mov             x0, x5
    // 0x692550: r2 = Null
    //     0x692550: mov             x2, NULL
    // 0x692554: r1 = Null
    //     0x692554: mov             x1, NULL
    // 0x692558: r4 = LoadClassIdInstr(r0)
    //     0x692558: ldur            x4, [x0, #-1]
    //     0x69255c: ubfx            x4, x4, #0xc, #0x14
    // 0x692560: sub             x4, x4, #0x80d
    // 0x692564: cmp             x4, #1
    // 0x692568: b.ls            #0x692580
    // 0x69256c: r8 = BoxConstraints
    //     0x69256c: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x692570: ldr             x8, [x8, #0x1d0]
    // 0x692574: r3 = Null
    //     0x692574: add             x3, PP, #0x37, lsl #12  ; [pp+0x37008] Null
    //     0x692578: ldr             x3, [x3, #8]
    // 0x69257c: r0 = BoxConstraints()
    //     0x69257c: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x692580: ldr             x16, [fp, #0x10]
    // 0x692584: ldur            lr, [fp, #-8]
    // 0x692588: stp             lr, x16, [SP, #-0x10]!
    // 0x69258c: r0 = _getInnerConstraints()
    //     0x69258c: bl              #0x69279c  ; [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::_getInnerConstraints
    // 0x692590: add             SP, SP, #0x10
    // 0x692594: mov             x1, x0
    // 0x692598: ldur            x0, [fp, #-0x10]
    // 0x69259c: r2 = LoadClassIdInstr(r0)
    //     0x69259c: ldur            x2, [x0, #-1]
    //     0x6925a0: ubfx            x2, x2, #0xc, #0x14
    // 0x6925a4: stp             x1, x0, [SP, #-0x10]!
    // 0x6925a8: r16 = true
    //     0x6925a8: add             x16, NULL, #0x20  ; true
    // 0x6925ac: SaveReg r16
    //     0x6925ac: str             x16, [SP, #-8]!
    // 0x6925b0: mov             x0, x2
    // 0x6925b4: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x6925b4: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x6925b8: ldr             x4, [x4, #0x1c8]
    // 0x6925bc: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x6925bc: mov             x17, #0xcdfb
    //     0x6925c0: add             lr, x0, x17
    //     0x6925c4: ldr             lr, [x21, lr, lsl #3]
    //     0x6925c8: blr             lr
    // 0x6925cc: add             SP, SP, #0x18
    // 0x6925d0: ldr             x3, [fp, #0x10]
    // 0x6925d4: LoadField: r4 = r3->field_27
    //     0x6925d4: ldur            w4, [x3, #0x27]
    // 0x6925d8: DecompressPointer r4
    //     0x6925d8: add             x4, x4, HEAP, lsl #32
    // 0x6925dc: stur            x4, [fp, #-8]
    // 0x6925e0: cmp             w4, NULL
    // 0x6925e4: b.eq            #0x69274c
    // 0x6925e8: mov             x0, x4
    // 0x6925ec: r2 = Null
    //     0x6925ec: mov             x2, NULL
    // 0x6925f0: r1 = Null
    //     0x6925f0: mov             x1, NULL
    // 0x6925f4: r4 = LoadClassIdInstr(r0)
    //     0x6925f4: ldur            x4, [x0, #-1]
    //     0x6925f8: ubfx            x4, x4, #0xc, #0x14
    // 0x6925fc: sub             x4, x4, #0x80d
    // 0x692600: cmp             x4, #1
    // 0x692604: b.ls            #0x69261c
    // 0x692608: r8 = BoxConstraints
    //     0x692608: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x69260c: ldr             x8, [x8, #0x1d0]
    // 0x692610: r3 = Null
    //     0x692610: add             x3, PP, #0x37, lsl #12  ; [pp+0x37018] Null
    //     0x692614: ldr             x3, [x3, #0x18]
    // 0x692618: r0 = BoxConstraints()
    //     0x692618: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x69261c: ldr             x0, [fp, #0x10]
    // 0x692620: LoadField: r1 = r0->field_5f
    //     0x692620: ldur            w1, [x0, #0x5f]
    // 0x692624: DecompressPointer r1
    //     0x692624: add             x1, x1, HEAP, lsl #32
    // 0x692628: cmp             w1, NULL
    // 0x69262c: b.eq            #0x692794
    // 0x692630: LoadField: r2 = r1->field_57
    //     0x692630: ldur            w2, [x1, #0x57]
    // 0x692634: DecompressPointer r2
    //     0x692634: add             x2, x2, HEAP, lsl #32
    // 0x692638: cmp             w2, NULL
    // 0x69263c: b.eq            #0x692798
    // 0x692640: ldur            x16, [fp, #-8]
    // 0x692644: stp             x2, x16, [SP, #-0x10]!
    // 0x692648: r0 = constrain()
    //     0x692648: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x69264c: add             SP, SP, #0x10
    // 0x692650: ldr             x3, [fp, #0x10]
    // 0x692654: StoreField: r3->field_57 = r0
    //     0x692654: stur            w0, [x3, #0x57]
    //     0x692658: ldurb           w16, [x3, #-1]
    //     0x69265c: ldurb           w17, [x0, #-1]
    //     0x692660: and             x16, x17, x16, lsr #2
    //     0x692664: tst             x16, HEAP, lsr #32
    //     0x692668: b.eq            #0x692670
    //     0x69266c: bl              #0xd682ac
    // 0x692670: SaveReg r3
    //     0x692670: str             x3, [SP, #-8]!
    // 0x692674: r0 = alignChild()
    //     0x692674: bl              #0x69064c  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::alignChild
    // 0x692678: add             SP, SP, #8
    // 0x69267c: b               #0x692724
    // 0x692680: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x692680: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x692684: ldr             x0, [x0, #0x1e8]
    // 0x692688: LoadField: r4 = r3->field_27
    //     0x692688: ldur            w4, [x3, #0x27]
    // 0x69268c: DecompressPointer r4
    //     0x69268c: add             x4, x4, HEAP, lsl #32
    // 0x692690: stur            x4, [fp, #-8]
    // 0x692694: cmp             w4, NULL
    // 0x692698: b.eq            #0x69276c
    // 0x69269c: mov             x0, x4
    // 0x6926a0: r2 = Null
    //     0x6926a0: mov             x2, NULL
    // 0x6926a4: r1 = Null
    //     0x6926a4: mov             x1, NULL
    // 0x6926a8: r4 = LoadClassIdInstr(r0)
    //     0x6926a8: ldur            x4, [x0, #-1]
    //     0x6926ac: ubfx            x4, x4, #0xc, #0x14
    // 0x6926b0: sub             x4, x4, #0x80d
    // 0x6926b4: cmp             x4, #1
    // 0x6926b8: b.ls            #0x6926d0
    // 0x6926bc: r8 = BoxConstraints
    //     0x6926bc: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x6926c0: ldr             x8, [x8, #0x1d0]
    // 0x6926c4: r3 = Null
    //     0x6926c4: add             x3, PP, #0x37, lsl #12  ; [pp+0x37028] Null
    //     0x6926c8: ldr             x3, [x3, #0x28]
    // 0x6926cc: r0 = BoxConstraints()
    //     0x6926cc: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x6926d0: ldr             x16, [fp, #0x10]
    // 0x6926d4: ldur            lr, [fp, #-8]
    // 0x6926d8: stp             lr, x16, [SP, #-0x10]!
    // 0x6926dc: r0 = _getInnerConstraints()
    //     0x6926dc: bl              #0x69279c  ; [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::_getInnerConstraints
    // 0x6926e0: add             SP, SP, #0x10
    // 0x6926e4: r16 = Instance_Size
    //     0x6926e4: ldr             x16, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0x6926e8: stp             x16, x0, [SP, #-0x10]!
    // 0x6926ec: r0 = constrain()
    //     0x6926ec: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x6926f0: add             SP, SP, #0x10
    // 0x6926f4: ldur            x16, [fp, #-8]
    // 0x6926f8: stp             x0, x16, [SP, #-0x10]!
    // 0x6926fc: r0 = constrain()
    //     0x6926fc: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x692700: add             SP, SP, #0x10
    // 0x692704: ldr             x1, [fp, #0x10]
    // 0x692708: StoreField: r1->field_57 = r0
    //     0x692708: stur            w0, [x1, #0x57]
    //     0x69270c: ldurb           w16, [x1, #-1]
    //     0x692710: ldurb           w17, [x0, #-1]
    //     0x692714: and             x16, x17, x16, lsr #2
    //     0x692718: tst             x16, HEAP, lsr #32
    //     0x69271c: b.eq            #0x692724
    //     0x692720: bl              #0xd6826c
    // 0x692724: r0 = Null
    //     0x692724: mov             x0, NULL
    // 0x692728: LeaveFrame
    //     0x692728: mov             SP, fp
    //     0x69272c: ldp             fp, lr, [SP], #0x10
    // 0x692730: ret
    //     0x692730: ret             
    // 0x692734: r0 = StateError()
    //     0x692734: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x692738: r6 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x692738: add             x6, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x69273c: ldr             x6, [x6, #0x1e8]
    // 0x692740: StoreField: r0->field_b = r6
    //     0x692740: stur            w6, [x0, #0xb]
    // 0x692744: r0 = Throw()
    //     0x692744: bl              #0xd67e38  ; ThrowStub
    // 0x692748: brk             #0
    // 0x69274c: r0 = StateError()
    //     0x69274c: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x692750: mov             x1, x0
    // 0x692754: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x692754: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x692758: ldr             x0, [x0, #0x1e8]
    // 0x69275c: StoreField: r1->field_b = r0
    //     0x69275c: stur            w0, [x1, #0xb]
    // 0x692760: mov             x0, x1
    // 0x692764: r0 = Throw()
    //     0x692764: bl              #0xd67e38  ; ThrowStub
    // 0x692768: brk             #0
    // 0x69276c: r0 = StateError()
    //     0x69276c: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x692770: mov             x1, x0
    // 0x692774: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x692774: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x692778: ldr             x0, [x0, #0x1e8]
    // 0x69277c: StoreField: r1->field_b = r0
    //     0x69277c: stur            w0, [x1, #0xb]
    // 0x692780: mov             x0, x1
    // 0x692784: r0 = Throw()
    //     0x692784: bl              #0xd67e38  ; ThrowStub
    // 0x692788: brk             #0
    // 0x69278c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69278c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x692790: b               #0x692518
    // 0x692794: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x692794: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x692798: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x692798: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getInnerConstraints(/* No info */) {
    // ** addr: 0x69279c, size: 0x90
    // 0x69279c: EnterFrame
    //     0x69279c: stp             fp, lr, [SP, #-0x10]!
    //     0x6927a0: mov             fp, SP
    // 0x6927a4: AllocStack(0x18)
    //     0x6927a4: sub             SP, SP, #0x18
    // 0x6927a8: ldr             x0, [fp, #0x10]
    // 0x6927ac: LoadField: d0 = r0->field_f
    //     0x6927ac: ldur            d0, [x0, #0xf]
    // 0x6927b0: ldr             x1, [fp, #0x18]
    // 0x6927b4: LoadField: d1 = r1->field_6f
    //     0x6927b4: ldur            d1, [x1, #0x6f]
    // 0x6927b8: fmul            d2, d0, d1
    // 0x6927bc: stur            d2, [fp, #-0x18]
    // 0x6927c0: LoadField: d0 = r0->field_17
    //     0x6927c0: ldur            d0, [x0, #0x17]
    // 0x6927c4: LoadField: d1 = r0->field_1f
    //     0x6927c4: ldur            d1, [x0, #0x1f]
    // 0x6927c8: LoadField: r0 = r1->field_77
    //     0x6927c8: ldur            w0, [x1, #0x77]
    // 0x6927cc: DecompressPointer r0
    //     0x6927cc: add             x0, x0, HEAP, lsl #32
    // 0x6927d0: cmp             w0, NULL
    // 0x6927d4: b.eq            #0x6927ec
    // 0x6927d8: LoadField: d0 = r0->field_7
    //     0x6927d8: ldur            d0, [x0, #7]
    // 0x6927dc: fmul            d3, d1, d0
    // 0x6927e0: mov             v1.16b, v3.16b
    // 0x6927e4: mov             v0.16b, v3.16b
    // 0x6927e8: b               #0x6927f8
    // 0x6927ec: mov             v31.16b, v1.16b
    // 0x6927f0: mov             v1.16b, v0.16b
    // 0x6927f4: mov             v0.16b, v31.16b
    // 0x6927f8: stur            d1, [fp, #-8]
    // 0x6927fc: stur            d0, [fp, #-0x10]
    // 0x692800: r0 = BoxConstraints()
    //     0x692800: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x692804: ldur            d0, [fp, #-0x18]
    // 0x692808: StoreField: r0->field_7 = d0
    //     0x692808: stur            d0, [x0, #7]
    // 0x69280c: StoreField: r0->field_f = d0
    //     0x69280c: stur            d0, [x0, #0xf]
    // 0x692810: ldur            d0, [fp, #-8]
    // 0x692814: StoreField: r0->field_17 = d0
    //     0x692814: stur            d0, [x0, #0x17]
    // 0x692818: ldur            d0, [fp, #-0x10]
    // 0x69281c: StoreField: r0->field_1f = d0
    //     0x69281c: stur            d0, [x0, #0x1f]
    // 0x692820: LeaveFrame
    //     0x692820: mov             SP, fp
    //     0x692824: ldp             fp, lr, [SP], #0x10
    // 0x692828: ret
    //     0x692828: ret             
  }
  set _ heightFactor=(/* No info */) {
    // ** addr: 0x6c5f48, size: 0xa0
    // 0x6c5f48: EnterFrame
    //     0x6c5f48: stp             fp, lr, [SP, #-0x10]!
    //     0x6c5f4c: mov             fp, SP
    // 0x6c5f50: CheckStackOverflow
    //     0x6c5f50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c5f54: cmp             SP, x16
    //     0x6c5f58: b.ls            #0x6c5fe0
    // 0x6c5f5c: ldr             x1, [fp, #0x18]
    // 0x6c5f60: LoadField: r0 = r1->field_77
    //     0x6c5f60: ldur            w0, [x1, #0x77]
    // 0x6c5f64: DecompressPointer r0
    //     0x6c5f64: add             x0, x0, HEAP, lsl #32
    // 0x6c5f68: r2 = LoadClassIdInstr(r0)
    //     0x6c5f68: ldur            x2, [x0, #-1]
    //     0x6c5f6c: ubfx            x2, x2, #0xc, #0x14
    // 0x6c5f70: ldr             x16, [fp, #0x10]
    // 0x6c5f74: stp             x16, x0, [SP, #-0x10]!
    // 0x6c5f78: mov             x0, x2
    // 0x6c5f7c: mov             lr, x0
    // 0x6c5f80: ldr             lr, [x21, lr, lsl #3]
    // 0x6c5f84: blr             lr
    // 0x6c5f88: add             SP, SP, #0x10
    // 0x6c5f8c: tbnz            w0, #4, #0x6c5fa0
    // 0x6c5f90: r0 = Null
    //     0x6c5f90: mov             x0, NULL
    // 0x6c5f94: LeaveFrame
    //     0x6c5f94: mov             SP, fp
    //     0x6c5f98: ldp             fp, lr, [SP], #0x10
    // 0x6c5f9c: ret
    //     0x6c5f9c: ret             
    // 0x6c5fa0: ldr             x1, [fp, #0x18]
    // 0x6c5fa4: ldr             x0, [fp, #0x10]
    // 0x6c5fa8: StoreField: r1->field_77 = r0
    //     0x6c5fa8: stur            w0, [x1, #0x77]
    //     0x6c5fac: ldurb           w16, [x1, #-1]
    //     0x6c5fb0: ldurb           w17, [x0, #-1]
    //     0x6c5fb4: and             x16, x17, x16, lsr #2
    //     0x6c5fb8: tst             x16, HEAP, lsr #32
    //     0x6c5fbc: b.eq            #0x6c5fc4
    //     0x6c5fc0: bl              #0xd6826c
    // 0x6c5fc4: SaveReg r1
    //     0x6c5fc4: str             x1, [SP, #-8]!
    // 0x6c5fc8: r0 = markNeedsLayout()
    //     0x6c5fc8: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c5fcc: add             SP, SP, #8
    // 0x6c5fd0: r0 = Null
    //     0x6c5fd0: mov             x0, NULL
    // 0x6c5fd4: LeaveFrame
    //     0x6c5fd4: mov             SP, fp
    //     0x6c5fd8: ldp             fp, lr, [SP], #0x10
    // 0x6c5fdc: ret
    //     0x6c5fdc: ret             
    // 0x6c5fe0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c5fe0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c5fe4: b               #0x6c5f5c
  }
  set _ widthFactor=(/* No info */) {
    // ** addr: 0x6c5fe8, size: 0x64
    // 0x6c5fe8: EnterFrame
    //     0x6c5fe8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c5fec: mov             fp, SP
    // 0x6c5ff0: CheckStackOverflow
    //     0x6c5ff0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c5ff4: cmp             SP, x16
    //     0x6c5ff8: b.ls            #0x6c6044
    // 0x6c5ffc: ldr             x0, [fp, #0x18]
    // 0x6c6000: LoadField: d0 = r0->field_6f
    //     0x6c6000: ldur            d0, [x0, #0x6f]
    // 0x6c6004: ldr             d1, [fp, #0x10]
    // 0x6c6008: fcmp            d0, d1
    // 0x6c600c: b.vs            #0x6c6024
    // 0x6c6010: b.ne            #0x6c6024
    // 0x6c6014: r0 = Null
    //     0x6c6014: mov             x0, NULL
    // 0x6c6018: LeaveFrame
    //     0x6c6018: mov             SP, fp
    //     0x6c601c: ldp             fp, lr, [SP], #0x10
    // 0x6c6020: ret
    //     0x6c6020: ret             
    // 0x6c6024: StoreField: r0->field_6f = d1
    //     0x6c6024: stur            d1, [x0, #0x6f]
    // 0x6c6028: SaveReg r0
    //     0x6c6028: str             x0, [SP, #-8]!
    // 0x6c602c: r0 = markNeedsLayout()
    //     0x6c602c: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c6030: add             SP, SP, #8
    // 0x6c6034: r0 = Null
    //     0x6c6034: mov             x0, NULL
    // 0x6c6038: LeaveFrame
    //     0x6c6038: mov             SP, fp
    //     0x6c603c: ldp             fp, lr, [SP], #0x10
    // 0x6c6040: ret
    //     0x6c6040: ret             
    // 0x6c6044: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6044: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c6048: b               #0x6c5ffc
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5e29c, size: 0xb0
    // 0xa5e29c: EnterFrame
    //     0xa5e29c: stp             fp, lr, [SP, #-0x10]!
    //     0xa5e2a0: mov             fp, SP
    // 0xa5e2a4: AllocStack(0x8)
    //     0xa5e2a4: sub             SP, SP, #8
    // 0xa5e2a8: CheckStackOverflow
    //     0xa5e2a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5e2ac: cmp             SP, x16
    //     0xa5e2b0: b.ls            #0xa5e344
    // 0xa5e2b4: ldr             x0, [fp, #0x18]
    // 0xa5e2b8: LoadField: r1 = r0->field_5f
    //     0xa5e2b8: ldur            w1, [x0, #0x5f]
    // 0xa5e2bc: DecompressPointer r1
    //     0xa5e2bc: add             x1, x1, HEAP, lsl #32
    // 0xa5e2c0: stur            x1, [fp, #-8]
    // 0xa5e2c4: cmp             w1, NULL
    // 0xa5e2c8: b.eq            #0xa5e308
    // 0xa5e2cc: ldr             x16, [fp, #0x10]
    // 0xa5e2d0: stp             x16, x0, [SP, #-0x10]!
    // 0xa5e2d4: r0 = _getInnerConstraints()
    //     0xa5e2d4: bl              #0x69279c  ; [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::_getInnerConstraints
    // 0xa5e2d8: add             SP, SP, #0x10
    // 0xa5e2dc: ldur            x16, [fp, #-8]
    // 0xa5e2e0: stp             x0, x16, [SP, #-0x10]!
    // 0xa5e2e4: r0 = getDryLayout()
    //     0xa5e2e4: bl              #0x62d394  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xa5e2e8: add             SP, SP, #0x10
    // 0xa5e2ec: ldr             x16, [fp, #0x10]
    // 0xa5e2f0: stp             x0, x16, [SP, #-0x10]!
    // 0xa5e2f4: r0 = constrain()
    //     0xa5e2f4: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xa5e2f8: add             SP, SP, #0x10
    // 0xa5e2fc: LeaveFrame
    //     0xa5e2fc: mov             SP, fp
    //     0xa5e300: ldp             fp, lr, [SP], #0x10
    // 0xa5e304: ret
    //     0xa5e304: ret             
    // 0xa5e308: ldr             x16, [fp, #0x10]
    // 0xa5e30c: stp             x16, x0, [SP, #-0x10]!
    // 0xa5e310: r0 = _getInnerConstraints()
    //     0xa5e310: bl              #0x69279c  ; [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::_getInnerConstraints
    // 0xa5e314: add             SP, SP, #0x10
    // 0xa5e318: r16 = Instance_Size
    //     0xa5e318: ldr             x16, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0xa5e31c: stp             x16, x0, [SP, #-0x10]!
    // 0xa5e320: r0 = constrain()
    //     0xa5e320: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xa5e324: add             SP, SP, #0x10
    // 0xa5e328: ldr             x16, [fp, #0x10]
    // 0xa5e32c: stp             x0, x16, [SP, #-0x10]!
    // 0xa5e330: r0 = constrain()
    //     0xa5e330: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xa5e334: add             SP, SP, #0x10
    // 0xa5e338: LeaveFrame
    //     0xa5e338: mov             SP, fp
    //     0xa5e33c: ldp             fp, lr, [SP], #0x10
    // 0xa5e340: ret
    //     0xa5e340: ret             
    // 0xa5e344: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5e344: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5e348: b               #0xa5e2b4
  }
}

// class id: 2465, size: 0x74, field offset: 0x70
//   transformed mixin,
abstract class _RenderConstraintsTransformBox&RenderAligningShiftedBox&DebugOverflowIndicatorMixin extends RenderAligningShiftedBox
     with DebugOverflowIndicatorMixin {

  _ reassemble(/* No info */) {
    // ** addr: 0x641874, size: 0x3c
    // 0x641874: EnterFrame
    //     0x641874: stp             fp, lr, [SP, #-0x10]!
    //     0x641878: mov             fp, SP
    // 0x64187c: CheckStackOverflow
    //     0x64187c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x641880: cmp             SP, x16
    //     0x641884: b.ls            #0x6418a8
    // 0x641888: ldr             x16, [fp, #0x10]
    // 0x64188c: SaveReg r16
    //     0x64188c: str             x16, [SP, #-8]!
    // 0x641890: r0 = reassemble()
    //     0x641890: bl              #0x6418b0  ; [package:flutter/src/rendering/object.dart] RenderObject::reassemble
    // 0x641894: add             SP, SP, #8
    // 0x641898: r0 = Null
    //     0x641898: mov             x0, NULL
    // 0x64189c: LeaveFrame
    //     0x64189c: mov             SP, fp
    //     0x6418a0: ldp             fp, lr, [SP], #0x10
    // 0x6418a4: ret
    //     0x6418a4: ret             
    // 0x6418a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6418a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6418ac: b               #0x641888
  }
  _ dispose(/* No info */) {
    // ** addr: 0x652e54, size: 0x140
    // 0x652e54: EnterFrame
    //     0x652e54: stp             fp, lr, [SP, #-0x10]!
    //     0x652e58: mov             fp, SP
    // 0x652e5c: AllocStack(0x28)
    //     0x652e5c: sub             SP, SP, #0x28
    // 0x652e60: CheckStackOverflow
    //     0x652e60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x652e64: cmp             SP, x16
    //     0x652e68: b.ls            #0x652f84
    // 0x652e6c: ldr             x3, [fp, #0x10]
    // 0x652e70: LoadField: r4 = r3->field_6f
    //     0x652e70: ldur            w4, [x3, #0x6f]
    // 0x652e74: DecompressPointer r4
    //     0x652e74: add             x4, x4, HEAP, lsl #32
    // 0x652e78: stur            x4, [fp, #-0x28]
    // 0x652e7c: LoadField: r5 = r4->field_7
    //     0x652e7c: ldur            w5, [x4, #7]
    // 0x652e80: DecompressPointer r5
    //     0x652e80: add             x5, x5, HEAP, lsl #32
    // 0x652e84: stur            x5, [fp, #-0x20]
    // 0x652e88: LoadField: r0 = r4->field_b
    //     0x652e88: ldur            w0, [x4, #0xb]
    // 0x652e8c: DecompressPointer r0
    //     0x652e8c: add             x0, x0, HEAP, lsl #32
    // 0x652e90: r6 = LoadInt32Instr(r0)
    //     0x652e90: sbfx            x6, x0, #1, #0x1f
    // 0x652e94: stur            x6, [fp, #-0x18]
    // 0x652e98: r0 = 0
    //     0x652e98: mov             x0, #0
    // 0x652e9c: CheckStackOverflow
    //     0x652e9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x652ea0: cmp             SP, x16
    //     0x652ea4: b.ls            #0x652f8c
    // 0x652ea8: cmp             x0, x6
    // 0x652eac: b.lt            #0x652ecc
    // 0x652eb0: SaveReg r3
    //     0x652eb0: str             x3, [SP, #-8]!
    // 0x652eb4: r0 = dispose()
    //     0x652eb4: bl              #0x65378c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0x652eb8: add             SP, SP, #8
    // 0x652ebc: r0 = Null
    //     0x652ebc: mov             x0, NULL
    // 0x652ec0: LeaveFrame
    //     0x652ec0: mov             SP, fp
    //     0x652ec4: ldp             fp, lr, [SP], #0x10
    // 0x652ec8: ret
    //     0x652ec8: ret             
    // 0x652ecc: ArrayLoad: r7 = r4[r0]  ; Unknown_4
    //     0x652ecc: add             x16, x4, x0, lsl #2
    //     0x652ed0: ldur            w7, [x16, #0xf]
    // 0x652ed4: DecompressPointer r7
    //     0x652ed4: add             x7, x7, HEAP, lsl #32
    // 0x652ed8: stur            x7, [fp, #-0x10]
    // 0x652edc: add             x8, x0, #1
    // 0x652ee0: stur            x8, [fp, #-8]
    // 0x652ee4: cmp             w7, NULL
    // 0x652ee8: b.ne            #0x652f1c
    // 0x652eec: mov             x0, x7
    // 0x652ef0: mov             x2, x5
    // 0x652ef4: r1 = Null
    //     0x652ef4: mov             x1, NULL
    // 0x652ef8: cmp             w2, NULL
    // 0x652efc: b.eq            #0x652f1c
    // 0x652f00: LoadField: r4 = r2->field_17
    //     0x652f00: ldur            w4, [x2, #0x17]
    // 0x652f04: DecompressPointer r4
    //     0x652f04: add             x4, x4, HEAP, lsl #32
    // 0x652f08: r8 = X0
    //     0x652f08: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x652f0c: LoadField: r9 = r4->field_7
    //     0x652f0c: ldur            x9, [x4, #7]
    // 0x652f10: r3 = Null
    //     0x652f10: add             x3, PP, #0x55, lsl #12  ; [pp+0x55678] Null
    //     0x652f14: ldr             x3, [x3, #0x678]
    // 0x652f18: blr             x9
    // 0x652f1c: ldur            x0, [fp, #-0x10]
    // 0x652f20: LoadField: r1 = r0->field_4b
    //     0x652f20: ldur            w1, [x0, #0x4b]
    // 0x652f24: DecompressPointer r1
    //     0x652f24: add             x1, x1, HEAP, lsl #32
    // 0x652f28: cmp             w1, NULL
    // 0x652f2c: b.eq            #0x652f40
    // 0x652f30: SaveReg r1
    //     0x652f30: str             x1, [SP, #-8]!
    // 0x652f34: r0 = _dispose()
    //     0x652f34: bl              #0x62d5b4  ; [dart:ui] Paragraph::_dispose
    // 0x652f38: add             SP, SP, #8
    // 0x652f3c: ldur            x0, [fp, #-0x10]
    // 0x652f40: StoreField: r0->field_4b = rNULL
    //     0x652f40: stur            NULL, [x0, #0x4b]
    // 0x652f44: LoadField: r1 = r0->field_7
    //     0x652f44: ldur            w1, [x0, #7]
    // 0x652f48: DecompressPointer r1
    //     0x652f48: add             x1, x1, HEAP, lsl #32
    // 0x652f4c: cmp             w1, NULL
    // 0x652f50: b.eq            #0x652f64
    // 0x652f54: SaveReg r1
    //     0x652f54: str             x1, [SP, #-8]!
    // 0x652f58: r0 = _dispose()
    //     0x652f58: bl              #0x62d5b4  ; [dart:ui] Paragraph::_dispose
    // 0x652f5c: add             SP, SP, #8
    // 0x652f60: ldur            x0, [fp, #-0x10]
    // 0x652f64: StoreField: r0->field_7 = rNULL
    //     0x652f64: stur            NULL, [x0, #7]
    // 0x652f68: StoreField: r0->field_f = rNULL
    //     0x652f68: stur            NULL, [x0, #0xf]
    // 0x652f6c: ldur            x0, [fp, #-8]
    // 0x652f70: ldr             x3, [fp, #0x10]
    // 0x652f74: ldur            x4, [fp, #-0x28]
    // 0x652f78: ldur            x5, [fp, #-0x20]
    // 0x652f7c: ldur            x6, [fp, #-0x18]
    // 0x652f80: b               #0x652e9c
    // 0x652f84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x652f84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x652f88: b               #0x652e6c
    // 0x652f8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x652f8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x652f90: b               #0x652ea8
  }
  _ _RenderConstraintsTransformBox&RenderAligningShiftedBox&DebugOverflowIndicatorMixin(/* No info */) {
    // ** addr: 0x6ebdf0, size: 0x124
    // 0x6ebdf0: EnterFrame
    //     0x6ebdf0: stp             fp, lr, [SP, #-0x10]!
    //     0x6ebdf4: mov             fp, SP
    // 0x6ebdf8: AllocStack(0x8)
    //     0x6ebdf8: sub             SP, SP, #8
    // 0x6ebdfc: CheckStackOverflow
    //     0x6ebdfc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ebe00: cmp             SP, x16
    //     0x6ebe04: b.ls            #0x6ebf04
    // 0x6ebe08: r0 = TextPainter()
    //     0x6ebe08: bl              #0x68dbc4  ; AllocateTextPainterStub -> TextPainter (size=0x68)
    // 0x6ebe0c: mov             x3, x0
    // 0x6ebe10: r0 = true
    //     0x6ebe10: add             x0, NULL, #0x20  ; true
    // 0x6ebe14: stur            x3, [fp, #-8]
    // 0x6ebe18: StoreField: r3->field_b = r0
    //     0x6ebe18: stur            w0, [x3, #0xb]
    // 0x6ebe1c: r0 = Sentinel
    //     0x6ebe1c: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6ebe20: StoreField: r3->field_57 = r0
    //     0x6ebe20: stur            w0, [x3, #0x57]
    // 0x6ebe24: r0 = Instance_TextAlign
    //     0x6ebe24: add             x0, PP, #0x14, lsl #12  ; [pp+0x14fe8] Obj!TextAlign@b66f71
    //     0x6ebe28: ldr             x0, [x0, #0xfe8]
    // 0x6ebe2c: StoreField: r3->field_17 = r0
    //     0x6ebe2c: stur            w0, [x3, #0x17]
    // 0x6ebe30: r0 = Instance_TextDirection
    //     0x6ebe30: ldr             x0, [PP, #0x4808]  ; [pp+0x4808] Obj!TextDirection@b66e31
    // 0x6ebe34: StoreField: r3->field_1b = r0
    //     0x6ebe34: stur            w0, [x3, #0x1b]
    // 0x6ebe38: d0 = 1.000000
    //     0x6ebe38: fmov            d0, #1.00000000
    // 0x6ebe3c: StoreField: r3->field_1f = d0
    //     0x6ebe3c: stur            d0, [x3, #0x1f]
    // 0x6ebe40: r0 = Instance_TextWidthBasis
    //     0x6ebe40: add             x0, PP, #0x15, lsl #12  ; [pp+0x15148] Obj!TextWidthBasis@b64d31
    //     0x6ebe44: ldr             x0, [x0, #0x148]
    // 0x6ebe48: StoreField: r3->field_37 = r0
    //     0x6ebe48: stur            w0, [x3, #0x37]
    // 0x6ebe4c: r1 = <TextPainter>
    //     0x6ebe4c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15390] TypeArguments: <TextPainter>
    //     0x6ebe50: ldr             x1, [x1, #0x390]
    // 0x6ebe54: r2 = 8
    //     0x6ebe54: mov             x2, #8
    // 0x6ebe58: r0 = AllocateArray()
    //     0x6ebe58: bl              #0xd6987c  ; AllocateArrayStub
    // 0x6ebe5c: ldur            x1, [fp, #-8]
    // 0x6ebe60: r2 = 0
    //     0x6ebe60: mov             x2, #0
    // 0x6ebe64: CheckStackOverflow
    //     0x6ebe64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ebe68: cmp             SP, x16
    //     0x6ebe6c: b.ls            #0x6ebf0c
    // 0x6ebe70: cmp             x2, #4
    // 0x6ebe74: b.ge            #0x6ebe8c
    // 0x6ebe78: ArrayStore: r0[r2] = r1  ; Unknown_4
    //     0x6ebe78: add             x3, x0, x2, lsl #2
    //     0x6ebe7c: stur            w1, [x3, #0xf]
    // 0x6ebe80: add             x3, x2, #1
    // 0x6ebe84: mov             x2, x3
    // 0x6ebe88: b               #0x6ebe64
    // 0x6ebe8c: ldr             x2, [fp, #0x18]
    // 0x6ebe90: r1 = Instance_Alignment
    //     0x6ebe90: add             x1, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x6ebe94: ldr             x1, [x1, #0xc70]
    // 0x6ebe98: StoreField: r2->field_6f = r0
    //     0x6ebe98: stur            w0, [x2, #0x6f]
    //     0x6ebe9c: ldurb           w16, [x2, #-1]
    //     0x6ebea0: ldurb           w17, [x0, #-1]
    //     0x6ebea4: and             x16, x17, x16, lsr #2
    //     0x6ebea8: tst             x16, HEAP, lsr #32
    //     0x6ebeac: b.eq            #0x6ebeb4
    //     0x6ebeb0: bl              #0xd6828c
    // 0x6ebeb4: StoreField: r2->field_67 = r1
    //     0x6ebeb4: stur            w1, [x2, #0x67]
    // 0x6ebeb8: ldr             x0, [fp, #0x10]
    // 0x6ebebc: StoreField: r2->field_6b = r0
    //     0x6ebebc: stur            w0, [x2, #0x6b]
    //     0x6ebec0: ldurb           w16, [x2, #-1]
    //     0x6ebec4: ldurb           w17, [x0, #-1]
    //     0x6ebec8: and             x16, x17, x16, lsr #2
    //     0x6ebecc: tst             x16, HEAP, lsr #32
    //     0x6ebed0: b.eq            #0x6ebed8
    //     0x6ebed4: bl              #0xd6828c
    // 0x6ebed8: SaveReg r2
    //     0x6ebed8: str             x2, [SP, #-8]!
    // 0x6ebedc: r0 = RenderObject()
    //     0x6ebedc: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6ebee0: add             SP, SP, #8
    // 0x6ebee4: ldr             x16, [fp, #0x18]
    // 0x6ebee8: stp             NULL, x16, [SP, #-0x10]!
    // 0x6ebeec: r0 = child=()
    //     0x6ebeec: bl              #0x6e7da0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::child=
    // 0x6ebef0: add             SP, SP, #0x10
    // 0x6ebef4: r0 = Null
    //     0x6ebef4: mov             x0, NULL
    // 0x6ebef8: LeaveFrame
    //     0x6ebef8: mov             SP, fp
    //     0x6ebefc: ldp             fp, lr, [SP], #0x10
    // 0x6ebf00: ret
    //     0x6ebf00: ret             
    // 0x6ebf04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ebf04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ebf08: b               #0x6ebe08
    // 0x6ebf0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ebf0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ebf10: b               #0x6ebe70
  }
}

// class id: 2466, size: 0x90, field offset: 0x74
class RenderConstraintsTransformBox extends _RenderConstraintsTransformBox&RenderAligningShiftedBox&DebugOverflowIndicatorMixin {

  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x62f148, size: 0x18
    // 0x62f148: r4 = 0
    //     0x62f148: mov             x4, #0
    // 0x62f14c: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x62f14c: add             x17, PP, #0x55, lsl #12  ; [pp+0x55640] AnonymousClosure: (0x62f160), in [package:flutter/src/rendering/shifted_box.dart] RenderConstraintsTransformBox::computeMaxIntrinsicHeight (0x62f1ac)
    //     0x62f150: ldr             x1, [x17, #0x640]
    // 0x62f154: r24 = BuildNonGenericMethodExtractorStub
    //     0x62f154: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x62f158: LoadField: r0 = r24->field_17
    //     0x62f158: ldur            x0, [x24, #0x17]
    // 0x62f15c: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x62f160, size: 0x4c
    // 0x62f160: EnterFrame
    //     0x62f160: stp             fp, lr, [SP, #-0x10]!
    //     0x62f164: mov             fp, SP
    // 0x62f168: ldr             x0, [fp, #0x18]
    // 0x62f16c: LoadField: r1 = r0->field_17
    //     0x62f16c: ldur            w1, [x0, #0x17]
    // 0x62f170: DecompressPointer r1
    //     0x62f170: add             x1, x1, HEAP, lsl #32
    // 0x62f174: CheckStackOverflow
    //     0x62f174: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62f178: cmp             SP, x16
    //     0x62f17c: b.ls            #0x62f1a4
    // 0x62f180: LoadField: r0 = r1->field_f
    //     0x62f180: ldur            w0, [x1, #0xf]
    // 0x62f184: DecompressPointer r0
    //     0x62f184: add             x0, x0, HEAP, lsl #32
    // 0x62f188: ldr             x16, [fp, #0x10]
    // 0x62f18c: stp             x16, x0, [SP, #-0x10]!
    // 0x62f190: r0 = computeMaxIntrinsicHeight()
    //     0x62f190: bl              #0x62f1ac  ; [package:flutter/src/rendering/shifted_box.dart] RenderConstraintsTransformBox::computeMaxIntrinsicHeight
    // 0x62f194: add             SP, SP, #0x10
    // 0x62f198: LeaveFrame
    //     0x62f198: mov             SP, fp
    //     0x62f19c: ldp             fp, lr, [SP], #0x10
    // 0x62f1a0: ret
    //     0x62f1a0: ret             
    // 0x62f1a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62f1a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62f1a8: b               #0x62f180
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0x62f1ac, size: 0xbc
    // 0x62f1ac: EnterFrame
    //     0x62f1ac: stp             fp, lr, [SP, #-0x10]!
    //     0x62f1b0: mov             fp, SP
    // 0x62f1b4: CheckStackOverflow
    //     0x62f1b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62f1b8: cmp             SP, x16
    //     0x62f1bc: b.ls            #0x62f250
    // 0x62f1c0: r0 = BoxConstraints()
    //     0x62f1c0: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x62f1c4: d0 = 0.000000
    //     0x62f1c4: eor             v0.16b, v0.16b, v0.16b
    // 0x62f1c8: StoreField: r0->field_7 = d0
    //     0x62f1c8: stur            d0, [x0, #7]
    // 0x62f1cc: ldr             x1, [fp, #0x10]
    // 0x62f1d0: LoadField: d1 = r1->field_7
    //     0x62f1d0: ldur            d1, [x1, #7]
    // 0x62f1d4: StoreField: r0->field_f = d1
    //     0x62f1d4: stur            d1, [x0, #0xf]
    // 0x62f1d8: StoreField: r0->field_17 = d0
    //     0x62f1d8: stur            d0, [x0, #0x17]
    // 0x62f1dc: d0 = inf
    //     0x62f1dc: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62f1e0: StoreField: r0->field_1f = d0
    //     0x62f1e0: stur            d0, [x0, #0x1f]
    // 0x62f1e4: ldr             x1, [fp, #0x18]
    // 0x62f1e8: LoadField: r2 = r1->field_73
    //     0x62f1e8: ldur            w2, [x1, #0x73]
    // 0x62f1ec: DecompressPointer r2
    //     0x62f1ec: add             x2, x2, HEAP, lsl #32
    // 0x62f1f0: stp             x0, x2, [SP, #-0x10]!
    // 0x62f1f4: mov             x0, x2
    // 0x62f1f8: ClosureCall
    //     0x62f1f8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x62f1fc: ldur            x2, [x0, #0x1f]
    //     0x62f200: blr             x2
    // 0x62f204: add             SP, SP, #0x10
    // 0x62f208: LoadField: d0 = r0->field_f
    //     0x62f208: ldur            d0, [x0, #0xf]
    // 0x62f20c: r0 = inline_Allocate_Double()
    //     0x62f20c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62f210: add             x0, x0, #0x10
    //     0x62f214: cmp             x1, x0
    //     0x62f218: b.ls            #0x62f258
    //     0x62f21c: str             x0, [THR, #0x60]  ; THR::top
    //     0x62f220: sub             x0, x0, #0xf
    //     0x62f224: mov             x1, #0xd108
    //     0x62f228: movk            x1, #3, lsl #16
    //     0x62f22c: stur            x1, [x0, #-1]
    // 0x62f230: StoreField: r0->field_7 = d0
    //     0x62f230: stur            d0, [x0, #7]
    // 0x62f234: ldr             x16, [fp, #0x18]
    // 0x62f238: stp             x0, x16, [SP, #-0x10]!
    // 0x62f23c: r0 = computeMaxIntrinsicHeight()
    //     0x62f23c: bl              #0x62f064  ; [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::computeMaxIntrinsicHeight
    // 0x62f240: add             SP, SP, #0x10
    // 0x62f244: LeaveFrame
    //     0x62f244: mov             SP, fp
    //     0x62f248: ldp             fp, lr, [SP], #0x10
    // 0x62f24c: ret
    //     0x62f24c: ret             
    // 0x62f250: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62f250: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62f254: b               #0x62f1c0
    // 0x62f258: SaveReg d0
    //     0x62f258: str             q0, [SP, #-0x10]!
    // 0x62f25c: r0 = AllocateDouble()
    //     0x62f25c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62f260: RestoreReg d0
    //     0x62f260: ldr             q0, [SP], #0x10
    // 0x62f264: b               #0x62f230
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x635b60, size: 0x18
    // 0x635b60: r4 = 0
    //     0x635b60: mov             x4, #0
    // 0x635b64: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x635b64: add             x17, PP, #0x55, lsl #12  ; [pp+0x55630] AnonymousClosure: (0x635b78), in [package:flutter/src/rendering/shifted_box.dart] RenderConstraintsTransformBox::computeMaxIntrinsicWidth (0x635bc4)
    //     0x635b68: ldr             x1, [x17, #0x630]
    // 0x635b6c: r24 = BuildNonGenericMethodExtractorStub
    //     0x635b6c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x635b70: LoadField: r0 = r24->field_17
    //     0x635b70: ldur            x0, [x24, #0x17]
    // 0x635b74: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x635b78, size: 0x4c
    // 0x635b78: EnterFrame
    //     0x635b78: stp             fp, lr, [SP, #-0x10]!
    //     0x635b7c: mov             fp, SP
    // 0x635b80: ldr             x0, [fp, #0x18]
    // 0x635b84: LoadField: r1 = r0->field_17
    //     0x635b84: ldur            w1, [x0, #0x17]
    // 0x635b88: DecompressPointer r1
    //     0x635b88: add             x1, x1, HEAP, lsl #32
    // 0x635b8c: CheckStackOverflow
    //     0x635b8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x635b90: cmp             SP, x16
    //     0x635b94: b.ls            #0x635bbc
    // 0x635b98: LoadField: r0 = r1->field_f
    //     0x635b98: ldur            w0, [x1, #0xf]
    // 0x635b9c: DecompressPointer r0
    //     0x635b9c: add             x0, x0, HEAP, lsl #32
    // 0x635ba0: ldr             x16, [fp, #0x10]
    // 0x635ba4: stp             x16, x0, [SP, #-0x10]!
    // 0x635ba8: r0 = computeMaxIntrinsicWidth()
    //     0x635ba8: bl              #0x635bc4  ; [package:flutter/src/rendering/shifted_box.dart] RenderConstraintsTransformBox::computeMaxIntrinsicWidth
    // 0x635bac: add             SP, SP, #0x10
    // 0x635bb0: LeaveFrame
    //     0x635bb0: mov             SP, fp
    //     0x635bb4: ldp             fp, lr, [SP], #0x10
    // 0x635bb8: ret
    //     0x635bb8: ret             
    // 0x635bbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x635bbc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x635bc0: b               #0x635b98
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0x635bc4, size: 0xbc
    // 0x635bc4: EnterFrame
    //     0x635bc4: stp             fp, lr, [SP, #-0x10]!
    //     0x635bc8: mov             fp, SP
    // 0x635bcc: CheckStackOverflow
    //     0x635bcc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x635bd0: cmp             SP, x16
    //     0x635bd4: b.ls            #0x635c68
    // 0x635bd8: r0 = BoxConstraints()
    //     0x635bd8: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x635bdc: d0 = 0.000000
    //     0x635bdc: eor             v0.16b, v0.16b, v0.16b
    // 0x635be0: StoreField: r0->field_7 = d0
    //     0x635be0: stur            d0, [x0, #7]
    // 0x635be4: d1 = inf
    //     0x635be4: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x635be8: StoreField: r0->field_f = d1
    //     0x635be8: stur            d1, [x0, #0xf]
    // 0x635bec: StoreField: r0->field_17 = d0
    //     0x635bec: stur            d0, [x0, #0x17]
    // 0x635bf0: ldr             x1, [fp, #0x10]
    // 0x635bf4: LoadField: d0 = r1->field_7
    //     0x635bf4: ldur            d0, [x1, #7]
    // 0x635bf8: StoreField: r0->field_1f = d0
    //     0x635bf8: stur            d0, [x0, #0x1f]
    // 0x635bfc: ldr             x1, [fp, #0x18]
    // 0x635c00: LoadField: r2 = r1->field_73
    //     0x635c00: ldur            w2, [x1, #0x73]
    // 0x635c04: DecompressPointer r2
    //     0x635c04: add             x2, x2, HEAP, lsl #32
    // 0x635c08: stp             x0, x2, [SP, #-0x10]!
    // 0x635c0c: mov             x0, x2
    // 0x635c10: ClosureCall
    //     0x635c10: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x635c14: ldur            x2, [x0, #0x1f]
    //     0x635c18: blr             x2
    // 0x635c1c: add             SP, SP, #0x10
    // 0x635c20: LoadField: d0 = r0->field_1f
    //     0x635c20: ldur            d0, [x0, #0x1f]
    // 0x635c24: r0 = inline_Allocate_Double()
    //     0x635c24: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x635c28: add             x0, x0, #0x10
    //     0x635c2c: cmp             x1, x0
    //     0x635c30: b.ls            #0x635c70
    //     0x635c34: str             x0, [THR, #0x60]  ; THR::top
    //     0x635c38: sub             x0, x0, #0xf
    //     0x635c3c: mov             x1, #0xd108
    //     0x635c40: movk            x1, #3, lsl #16
    //     0x635c44: stur            x1, [x0, #-1]
    // 0x635c48: StoreField: r0->field_7 = d0
    //     0x635c48: stur            d0, [x0, #7]
    // 0x635c4c: ldr             x16, [fp, #0x18]
    // 0x635c50: stp             x0, x16, [SP, #-0x10]!
    // 0x635c54: r0 = computeMaxIntrinsicWidth()
    //     0x635c54: bl              #0x635a7c  ; [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::computeMaxIntrinsicWidth
    // 0x635c58: add             SP, SP, #0x10
    // 0x635c5c: LeaveFrame
    //     0x635c5c: mov             SP, fp
    //     0x635c60: ldp             fp, lr, [SP], #0x10
    // 0x635c64: ret
    //     0x635c64: ret             
    // 0x635c68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x635c68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x635c6c: b               #0x635bd8
    // 0x635c70: SaveReg d0
    //     0x635c70: str             q0, [SP, #-0x10]!
    // 0x635c74: r0 = AllocateDouble()
    //     0x635c74: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x635c78: RestoreReg d0
    //     0x635c78: ldr             q0, [SP], #0x10
    // 0x635c7c: b               #0x635c48
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x638dac, size: 0x18
    // 0x638dac: r4 = 0
    //     0x638dac: mov             x4, #0
    // 0x638db0: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x638db0: add             x17, PP, #0x55, lsl #12  ; [pp+0x55648] AnonymousClosure: (0x638dc4), in [package:flutter/src/rendering/shifted_box.dart] RenderConstraintsTransformBox::computeMinIntrinsicHeight (0x638e10)
    //     0x638db4: ldr             x1, [x17, #0x648]
    // 0x638db8: r24 = BuildNonGenericMethodExtractorStub
    //     0x638db8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x638dbc: LoadField: r0 = r24->field_17
    //     0x638dbc: ldur            x0, [x24, #0x17]
    // 0x638dc0: br              x0
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x638dc4, size: 0x4c
    // 0x638dc4: EnterFrame
    //     0x638dc4: stp             fp, lr, [SP, #-0x10]!
    //     0x638dc8: mov             fp, SP
    // 0x638dcc: ldr             x0, [fp, #0x18]
    // 0x638dd0: LoadField: r1 = r0->field_17
    //     0x638dd0: ldur            w1, [x0, #0x17]
    // 0x638dd4: DecompressPointer r1
    //     0x638dd4: add             x1, x1, HEAP, lsl #32
    // 0x638dd8: CheckStackOverflow
    //     0x638dd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x638ddc: cmp             SP, x16
    //     0x638de0: b.ls            #0x638e08
    // 0x638de4: LoadField: r0 = r1->field_f
    //     0x638de4: ldur            w0, [x1, #0xf]
    // 0x638de8: DecompressPointer r0
    //     0x638de8: add             x0, x0, HEAP, lsl #32
    // 0x638dec: ldr             x16, [fp, #0x10]
    // 0x638df0: stp             x16, x0, [SP, #-0x10]!
    // 0x638df4: r0 = computeMinIntrinsicHeight()
    //     0x638df4: bl              #0x638e10  ; [package:flutter/src/rendering/shifted_box.dart] RenderConstraintsTransformBox::computeMinIntrinsicHeight
    // 0x638df8: add             SP, SP, #0x10
    // 0x638dfc: LeaveFrame
    //     0x638dfc: mov             SP, fp
    //     0x638e00: ldp             fp, lr, [SP], #0x10
    // 0x638e04: ret
    //     0x638e04: ret             
    // 0x638e08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x638e08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x638e0c: b               #0x638de4
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0x638e10, size: 0xbc
    // 0x638e10: EnterFrame
    //     0x638e10: stp             fp, lr, [SP, #-0x10]!
    //     0x638e14: mov             fp, SP
    // 0x638e18: CheckStackOverflow
    //     0x638e18: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x638e1c: cmp             SP, x16
    //     0x638e20: b.ls            #0x638eb4
    // 0x638e24: r0 = BoxConstraints()
    //     0x638e24: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x638e28: d0 = 0.000000
    //     0x638e28: eor             v0.16b, v0.16b, v0.16b
    // 0x638e2c: StoreField: r0->field_7 = d0
    //     0x638e2c: stur            d0, [x0, #7]
    // 0x638e30: ldr             x1, [fp, #0x10]
    // 0x638e34: LoadField: d1 = r1->field_7
    //     0x638e34: ldur            d1, [x1, #7]
    // 0x638e38: StoreField: r0->field_f = d1
    //     0x638e38: stur            d1, [x0, #0xf]
    // 0x638e3c: StoreField: r0->field_17 = d0
    //     0x638e3c: stur            d0, [x0, #0x17]
    // 0x638e40: d0 = inf
    //     0x638e40: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x638e44: StoreField: r0->field_1f = d0
    //     0x638e44: stur            d0, [x0, #0x1f]
    // 0x638e48: ldr             x1, [fp, #0x18]
    // 0x638e4c: LoadField: r2 = r1->field_73
    //     0x638e4c: ldur            w2, [x1, #0x73]
    // 0x638e50: DecompressPointer r2
    //     0x638e50: add             x2, x2, HEAP, lsl #32
    // 0x638e54: stp             x0, x2, [SP, #-0x10]!
    // 0x638e58: mov             x0, x2
    // 0x638e5c: ClosureCall
    //     0x638e5c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x638e60: ldur            x2, [x0, #0x1f]
    //     0x638e64: blr             x2
    // 0x638e68: add             SP, SP, #0x10
    // 0x638e6c: LoadField: d0 = r0->field_f
    //     0x638e6c: ldur            d0, [x0, #0xf]
    // 0x638e70: r0 = inline_Allocate_Double()
    //     0x638e70: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x638e74: add             x0, x0, #0x10
    //     0x638e78: cmp             x1, x0
    //     0x638e7c: b.ls            #0x638ebc
    //     0x638e80: str             x0, [THR, #0x60]  ; THR::top
    //     0x638e84: sub             x0, x0, #0xf
    //     0x638e88: mov             x1, #0xd108
    //     0x638e8c: movk            x1, #3, lsl #16
    //     0x638e90: stur            x1, [x0, #-1]
    // 0x638e94: StoreField: r0->field_7 = d0
    //     0x638e94: stur            d0, [x0, #7]
    // 0x638e98: ldr             x16, [fp, #0x18]
    // 0x638e9c: stp             x0, x16, [SP, #-0x10]!
    // 0x638ea0: r0 = computeMinIntrinsicHeight()
    //     0x638ea0: bl              #0x638cc8  ; [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::computeMinIntrinsicHeight
    // 0x638ea4: add             SP, SP, #0x10
    // 0x638ea8: LeaveFrame
    //     0x638ea8: mov             SP, fp
    //     0x638eac: ldp             fp, lr, [SP], #0x10
    // 0x638eb0: ret
    //     0x638eb0: ret             
    // 0x638eb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x638eb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x638eb8: b               #0x638e24
    // 0x638ebc: SaveReg d0
    //     0x638ebc: str             q0, [SP, #-0x10]!
    // 0x638ec0: r0 = AllocateDouble()
    //     0x638ec0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x638ec4: RestoreReg d0
    //     0x638ec4: ldr             q0, [SP], #0x10
    // 0x638ec8: b               #0x638e94
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63b9e8, size: 0x18
    // 0x63b9e8: r4 = 0
    //     0x63b9e8: mov             x4, #0
    // 0x63b9ec: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63b9ec: add             x17, PP, #0x55, lsl #12  ; [pp+0x55638] AnonymousClosure: (0x63ba00), in [package:flutter/src/rendering/shifted_box.dart] RenderConstraintsTransformBox::computeMinIntrinsicWidth (0x63ba4c)
    //     0x63b9f0: ldr             x1, [x17, #0x638]
    // 0x63b9f4: r24 = BuildNonGenericMethodExtractorStub
    //     0x63b9f4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63b9f8: LoadField: r0 = r24->field_17
    //     0x63b9f8: ldur            x0, [x24, #0x17]
    // 0x63b9fc: br              x0
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63ba00, size: 0x4c
    // 0x63ba00: EnterFrame
    //     0x63ba00: stp             fp, lr, [SP, #-0x10]!
    //     0x63ba04: mov             fp, SP
    // 0x63ba08: ldr             x0, [fp, #0x18]
    // 0x63ba0c: LoadField: r1 = r0->field_17
    //     0x63ba0c: ldur            w1, [x0, #0x17]
    // 0x63ba10: DecompressPointer r1
    //     0x63ba10: add             x1, x1, HEAP, lsl #32
    // 0x63ba14: CheckStackOverflow
    //     0x63ba14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63ba18: cmp             SP, x16
    //     0x63ba1c: b.ls            #0x63ba44
    // 0x63ba20: LoadField: r0 = r1->field_f
    //     0x63ba20: ldur            w0, [x1, #0xf]
    // 0x63ba24: DecompressPointer r0
    //     0x63ba24: add             x0, x0, HEAP, lsl #32
    // 0x63ba28: ldr             x16, [fp, #0x10]
    // 0x63ba2c: stp             x16, x0, [SP, #-0x10]!
    // 0x63ba30: r0 = computeMinIntrinsicWidth()
    //     0x63ba30: bl              #0x63ba4c  ; [package:flutter/src/rendering/shifted_box.dart] RenderConstraintsTransformBox::computeMinIntrinsicWidth
    // 0x63ba34: add             SP, SP, #0x10
    // 0x63ba38: LeaveFrame
    //     0x63ba38: mov             SP, fp
    //     0x63ba3c: ldp             fp, lr, [SP], #0x10
    // 0x63ba40: ret
    //     0x63ba40: ret             
    // 0x63ba44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63ba44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63ba48: b               #0x63ba20
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0x63ba4c, size: 0xbc
    // 0x63ba4c: EnterFrame
    //     0x63ba4c: stp             fp, lr, [SP, #-0x10]!
    //     0x63ba50: mov             fp, SP
    // 0x63ba54: CheckStackOverflow
    //     0x63ba54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63ba58: cmp             SP, x16
    //     0x63ba5c: b.ls            #0x63baf0
    // 0x63ba60: r0 = BoxConstraints()
    //     0x63ba60: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x63ba64: d0 = 0.000000
    //     0x63ba64: eor             v0.16b, v0.16b, v0.16b
    // 0x63ba68: StoreField: r0->field_7 = d0
    //     0x63ba68: stur            d0, [x0, #7]
    // 0x63ba6c: d1 = inf
    //     0x63ba6c: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x63ba70: StoreField: r0->field_f = d1
    //     0x63ba70: stur            d1, [x0, #0xf]
    // 0x63ba74: StoreField: r0->field_17 = d0
    //     0x63ba74: stur            d0, [x0, #0x17]
    // 0x63ba78: ldr             x1, [fp, #0x10]
    // 0x63ba7c: LoadField: d0 = r1->field_7
    //     0x63ba7c: ldur            d0, [x1, #7]
    // 0x63ba80: StoreField: r0->field_1f = d0
    //     0x63ba80: stur            d0, [x0, #0x1f]
    // 0x63ba84: ldr             x1, [fp, #0x18]
    // 0x63ba88: LoadField: r2 = r1->field_73
    //     0x63ba88: ldur            w2, [x1, #0x73]
    // 0x63ba8c: DecompressPointer r2
    //     0x63ba8c: add             x2, x2, HEAP, lsl #32
    // 0x63ba90: stp             x0, x2, [SP, #-0x10]!
    // 0x63ba94: mov             x0, x2
    // 0x63ba98: ClosureCall
    //     0x63ba98: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x63ba9c: ldur            x2, [x0, #0x1f]
    //     0x63baa0: blr             x2
    // 0x63baa4: add             SP, SP, #0x10
    // 0x63baa8: LoadField: d0 = r0->field_1f
    //     0x63baa8: ldur            d0, [x0, #0x1f]
    // 0x63baac: r0 = inline_Allocate_Double()
    //     0x63baac: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63bab0: add             x0, x0, #0x10
    //     0x63bab4: cmp             x1, x0
    //     0x63bab8: b.ls            #0x63baf8
    //     0x63babc: str             x0, [THR, #0x60]  ; THR::top
    //     0x63bac0: sub             x0, x0, #0xf
    //     0x63bac4: mov             x1, #0xd108
    //     0x63bac8: movk            x1, #3, lsl #16
    //     0x63bacc: stur            x1, [x0, #-1]
    // 0x63bad0: StoreField: r0->field_7 = d0
    //     0x63bad0: stur            d0, [x0, #7]
    // 0x63bad4: ldr             x16, [fp, #0x18]
    // 0x63bad8: stp             x0, x16, [SP, #-0x10]!
    // 0x63badc: r0 = computeMinIntrinsicWidth()
    //     0x63badc: bl              #0x63b904  ; [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::computeMinIntrinsicWidth
    // 0x63bae0: add             SP, SP, #0x10
    // 0x63bae4: LeaveFrame
    //     0x63bae4: mov             SP, fp
    //     0x63bae8: ldp             fp, lr, [SP], #0x10
    // 0x63baec: ret
    //     0x63baec: ret             
    // 0x63baf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63baf0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63baf4: b               #0x63ba60
    // 0x63baf8: SaveReg d0
    //     0x63baf8: str             q0, [SP, #-0x10]!
    // 0x63bafc: r0 = AllocateDouble()
    //     0x63bafc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63bb00: RestoreReg d0
    //     0x63bb00: ldr             q0, [SP], #0x10
    // 0x63bb04: b               #0x63bad0
  }
  _ dispose(/* No info */) {
    // ** addr: 0x652e00, size: 0x54
    // 0x652e00: EnterFrame
    //     0x652e00: stp             fp, lr, [SP, #-0x10]!
    //     0x652e04: mov             fp, SP
    // 0x652e08: CheckStackOverflow
    //     0x652e08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x652e0c: cmp             SP, x16
    //     0x652e10: b.ls            #0x652e4c
    // 0x652e14: ldr             x0, [fp, #0x10]
    // 0x652e18: LoadField: r1 = r0->field_8b
    //     0x652e18: ldur            w1, [x0, #0x8b]
    // 0x652e1c: DecompressPointer r1
    //     0x652e1c: add             x1, x1, HEAP, lsl #32
    // 0x652e20: stp             NULL, x1, [SP, #-0x10]!
    // 0x652e24: r0 = layer=()
    //     0x652e24: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x652e28: add             SP, SP, #0x10
    // 0x652e2c: ldr             x16, [fp, #0x10]
    // 0x652e30: SaveReg r16
    //     0x652e30: str             x16, [SP, #-8]!
    // 0x652e34: r0 = dispose()
    //     0x652e34: bl              #0x652e54  ; [package:flutter/src/rendering/shifted_box.dart] _RenderConstraintsTransformBox&RenderAligningShiftedBox&DebugOverflowIndicatorMixin::dispose
    // 0x652e38: add             SP, SP, #8
    // 0x652e3c: r0 = Null
    //     0x652e3c: mov             x0, NULL
    // 0x652e40: LeaveFrame
    //     0x652e40: mov             SP, fp
    //     0x652e44: ldp             fp, lr, [SP], #0x10
    // 0x652e48: ret
    //     0x652e48: ret             
    // 0x652e4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x652e4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x652e50: b               #0x652e14
  }
  _ paint(/* No info */) {
    // ** addr: 0x6699d8, size: 0x178
    // 0x6699d8: EnterFrame
    //     0x6699d8: stp             fp, lr, [SP, #-0x10]!
    //     0x6699dc: mov             fp, SP
    // 0x6699e0: AllocStack(0x20)
    //     0x6699e0: sub             SP, SP, #0x20
    // 0x6699e4: CheckStackOverflow
    //     0x6699e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6699e8: cmp             SP, x16
    //     0x6699ec: b.ls            #0x669b3c
    // 0x6699f0: ldr             x0, [fp, #0x20]
    // 0x6699f4: LoadField: r1 = r0->field_5f
    //     0x6699f4: ldur            w1, [x0, #0x5f]
    // 0x6699f8: DecompressPointer r1
    //     0x6699f8: add             x1, x1, HEAP, lsl #32
    // 0x6699fc: cmp             w1, NULL
    // 0x669a00: b.eq            #0x669a38
    // 0x669a04: d0 = 0.000000
    //     0x669a04: eor             v0.16b, v0.16b, v0.16b
    // 0x669a08: LoadField: r1 = r0->field_57
    //     0x669a08: ldur            w1, [x0, #0x57]
    // 0x669a0c: DecompressPointer r1
    //     0x669a0c: add             x1, x1, HEAP, lsl #32
    // 0x669a10: cmp             w1, NULL
    // 0x669a14: b.eq            #0x669b44
    // 0x669a18: LoadField: d1 = r1->field_7
    //     0x669a18: ldur            d1, [x1, #7]
    // 0x669a1c: fcmp            d1, d0
    // 0x669a20: b.vs            #0x669a28
    // 0x669a24: b.le            #0x669a38
    // 0x669a28: LoadField: d1 = r1->field_f
    //     0x669a28: ldur            d1, [x1, #0xf]
    // 0x669a2c: fcmp            d1, d0
    // 0x669a30: b.vs            #0x669a48
    // 0x669a34: b.gt            #0x669a48
    // 0x669a38: r0 = Null
    //     0x669a38: mov             x0, NULL
    // 0x669a3c: LeaveFrame
    //     0x669a3c: mov             SP, fp
    //     0x669a40: ldp             fp, lr, [SP], #0x10
    // 0x669a44: ret
    //     0x669a44: ret             
    // 0x669a48: LoadField: r2 = r0->field_83
    //     0x669a48: ldur            w2, [x0, #0x83]
    // 0x669a4c: DecompressPointer r2
    //     0x669a4c: add             x2, x2, HEAP, lsl #32
    // 0x669a50: tbz             w2, #4, #0x669a7c
    // 0x669a54: ldr             x16, [fp, #0x18]
    // 0x669a58: stp             x16, x0, [SP, #-0x10]!
    // 0x669a5c: ldr             x16, [fp, #0x10]
    // 0x669a60: SaveReg r16
    //     0x669a60: str             x16, [SP, #-8]!
    // 0x669a64: r0 = paint()
    //     0x669a64: bl              #0x669b50  ; [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::paint
    // 0x669a68: add             SP, SP, #0x18
    // 0x669a6c: r0 = Null
    //     0x669a6c: mov             x0, NULL
    // 0x669a70: LeaveFrame
    //     0x669a70: mov             SP, fp
    //     0x669a74: ldp             fp, lr, [SP], #0x10
    // 0x669a78: ret
    //     0x669a78: ret             
    // 0x669a7c: LoadField: r2 = r0->field_8b
    //     0x669a7c: ldur            w2, [x0, #0x8b]
    // 0x669a80: DecompressPointer r2
    //     0x669a80: add             x2, x2, HEAP, lsl #32
    // 0x669a84: stur            x2, [fp, #-0x10]
    // 0x669a88: LoadField: r3 = r0->field_37
    //     0x669a88: ldur            w3, [x0, #0x37]
    // 0x669a8c: DecompressPointer r3
    //     0x669a8c: add             x3, x3, HEAP, lsl #32
    // 0x669a90: r16 = Sentinel
    //     0x669a90: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x669a94: cmp             w3, w16
    // 0x669a98: b.eq            #0x669b48
    // 0x669a9c: stur            x3, [fp, #-8]
    // 0x669aa0: r16 = Instance_Offset
    //     0x669aa0: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x669aa4: stp             x1, x16, [SP, #-0x10]!
    // 0x669aa8: r0 = &()
    //     0x669aa8: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x669aac: add             SP, SP, #0x10
    // 0x669ab0: stur            x0, [fp, #-0x18]
    // 0x669ab4: r1 = 1
    //     0x669ab4: mov             x1, #1
    // 0x669ab8: r0 = AllocateContext()
    //     0x669ab8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x669abc: mov             x1, x0
    // 0x669ac0: ldr             x0, [fp, #0x20]
    // 0x669ac4: StoreField: r1->field_f = r0
    //     0x669ac4: stur            w0, [x1, #0xf]
    // 0x669ac8: ldur            x0, [fp, #-0x10]
    // 0x669acc: LoadField: r3 = r0->field_b
    //     0x669acc: ldur            w3, [x0, #0xb]
    // 0x669ad0: DecompressPointer r3
    //     0x669ad0: add             x3, x3, HEAP, lsl #32
    // 0x669ad4: mov             x2, x1
    // 0x669ad8: stur            x3, [fp, #-0x20]
    // 0x669adc: r1 = Function 'paint':.
    //     0x669adc: add             x1, PP, #0x55, lsl #12  ; [pp+0x55650] AnonymousClosure: (0x669984), in [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::paint (0x669b50)
    //     0x669ae0: ldr             x1, [x1, #0x650]
    // 0x669ae4: r0 = AllocateClosure()
    //     0x669ae4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x669ae8: ldr             x16, [fp, #0x18]
    // 0x669aec: ldur            lr, [fp, #-8]
    // 0x669af0: stp             lr, x16, [SP, #-0x10]!
    // 0x669af4: ldr             x16, [fp, #0x10]
    // 0x669af8: ldur            lr, [fp, #-0x18]
    // 0x669afc: stp             lr, x16, [SP, #-0x10]!
    // 0x669b00: r16 = Instance_Clip
    //     0x669b00: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x669b04: ldr             x16, [x16, #0xb38]
    // 0x669b08: stp             x16, x0, [SP, #-0x10]!
    // 0x669b0c: ldur            x16, [fp, #-0x20]
    // 0x669b10: SaveReg r16
    //     0x669b10: str             x16, [SP, #-8]!
    // 0x669b14: r0 = pushClipRect()
    //     0x669b14: bl              #0x65b240  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRect
    // 0x669b18: add             SP, SP, #0x38
    // 0x669b1c: ldur            x16, [fp, #-0x10]
    // 0x669b20: stp             x0, x16, [SP, #-0x10]!
    // 0x669b24: r0 = layer=()
    //     0x669b24: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x669b28: add             SP, SP, #0x10
    // 0x669b2c: r0 = Null
    //     0x669b2c: mov             x0, NULL
    // 0x669b30: LeaveFrame
    //     0x669b30: mov             SP, fp
    //     0x669b34: ldp             fp, lr, [SP], #0x10
    // 0x669b38: ret
    //     0x669b38: ret             
    // 0x669b3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x669b3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x669b40: b               #0x6699f0
    // 0x669b44: r0 = NullCastErrorSharedWithFPURegs()
    //     0x669b44: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x669b48: r9 = _needsCompositing
    //     0x669b48: ldr             x9, [PP, #0x4b28]  ; [pp+0x4b28] Field <RenderObject._needsCompositing@904266271>: late (offset: 0x38)
    // 0x669b4c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x669b4c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x69213c, size: 0x334
    // 0x69213c: EnterFrame
    //     0x69213c: stp             fp, lr, [SP, #-0x10]!
    //     0x692140: mov             fp, SP
    // 0x692144: AllocStack(0x18)
    //     0x692144: sub             SP, SP, #0x18
    // 0x692148: CheckStackOverflow
    //     0x692148: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x69214c: cmp             SP, x16
    //     0x692150: b.ls            #0x692458
    // 0x692154: ldr             x3, [fp, #0x10]
    // 0x692158: LoadField: r4 = r3->field_27
    //     0x692158: ldur            w4, [x3, #0x27]
    // 0x69215c: DecompressPointer r4
    //     0x69215c: add             x4, x4, HEAP, lsl #32
    // 0x692160: stur            x4, [fp, #-8]
    // 0x692164: cmp             w4, NULL
    // 0x692168: b.eq            #0x692438
    // 0x69216c: mov             x0, x4
    // 0x692170: r2 = Null
    //     0x692170: mov             x2, NULL
    // 0x692174: r1 = Null
    //     0x692174: mov             x1, NULL
    // 0x692178: r4 = LoadClassIdInstr(r0)
    //     0x692178: ldur            x4, [x0, #-1]
    //     0x69217c: ubfx            x4, x4, #0xc, #0x14
    // 0x692180: sub             x4, x4, #0x80d
    // 0x692184: cmp             x4, #1
    // 0x692188: b.ls            #0x6921a0
    // 0x69218c: r8 = BoxConstraints
    //     0x69218c: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x692190: ldr             x8, [x8, #0x1d0]
    // 0x692194: r3 = Null
    //     0x692194: add             x3, PP, #0x55, lsl #12  ; [pp+0x55658] Null
    //     0x692198: ldr             x3, [x3, #0x658]
    // 0x69219c: r0 = BoxConstraints()
    //     0x69219c: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x6921a0: ldr             x1, [fp, #0x10]
    // 0x6921a4: LoadField: r2 = r1->field_5f
    //     0x6921a4: ldur            w2, [x1, #0x5f]
    // 0x6921a8: DecompressPointer r2
    //     0x6921a8: add             x2, x2, HEAP, lsl #32
    // 0x6921ac: stur            x2, [fp, #-0x10]
    // 0x6921b0: cmp             w2, NULL
    // 0x6921b4: b.eq            #0x69236c
    // 0x6921b8: LoadField: r0 = r1->field_73
    //     0x6921b8: ldur            w0, [x1, #0x73]
    // 0x6921bc: DecompressPointer r0
    //     0x6921bc: add             x0, x0, HEAP, lsl #32
    // 0x6921c0: ldur            x16, [fp, #-8]
    // 0x6921c4: stp             x16, x0, [SP, #-0x10]!
    // 0x6921c8: ClosureCall
    //     0x6921c8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6921cc: ldur            x2, [x0, #0x1f]
    //     0x6921d0: blr             x2
    // 0x6921d4: add             SP, SP, #0x10
    // 0x6921d8: mov             x2, x0
    // 0x6921dc: ldr             x1, [fp, #0x10]
    // 0x6921e0: StoreField: r1->field_87 = r0
    //     0x6921e0: stur            w0, [x1, #0x87]
    //     0x6921e4: tbz             w0, #0, #0x692200
    //     0x6921e8: ldurb           w16, [x1, #-1]
    //     0x6921ec: ldurb           w17, [x0, #-1]
    //     0x6921f0: and             x16, x17, x16, lsr #2
    //     0x6921f4: tst             x16, HEAP, lsr #32
    //     0x6921f8: b.eq            #0x692200
    //     0x6921fc: bl              #0xd6826c
    // 0x692200: ldur            x3, [fp, #-0x10]
    // 0x692204: r0 = LoadClassIdInstr(r3)
    //     0x692204: ldur            x0, [x3, #-1]
    //     0x692208: ubfx            x0, x0, #0xc, #0x14
    // 0x69220c: stp             x2, x3, [SP, #-0x10]!
    // 0x692210: r16 = true
    //     0x692210: add             x16, NULL, #0x20  ; true
    // 0x692214: SaveReg r16
    //     0x692214: str             x16, [SP, #-8]!
    // 0x692218: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x692218: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x69221c: ldr             x4, [x4, #0x1c8]
    // 0x692220: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x692220: mov             x17, #0xcdfb
    //     0x692224: add             lr, x0, x17
    //     0x692228: ldr             lr, [x21, lr, lsl #3]
    //     0x69222c: blr             lr
    // 0x692230: add             SP, SP, #0x18
    // 0x692234: ldur            x0, [fp, #-0x10]
    // 0x692238: LoadField: r1 = r0->field_57
    //     0x692238: ldur            w1, [x0, #0x57]
    // 0x69223c: DecompressPointer r1
    //     0x69223c: add             x1, x1, HEAP, lsl #32
    // 0x692240: cmp             w1, NULL
    // 0x692244: b.eq            #0x692460
    // 0x692248: ldur            x16, [fp, #-8]
    // 0x69224c: stp             x1, x16, [SP, #-0x10]!
    // 0x692250: r0 = constrain()
    //     0x692250: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x692254: add             SP, SP, #0x10
    // 0x692258: ldr             x1, [fp, #0x10]
    // 0x69225c: StoreField: r1->field_57 = r0
    //     0x69225c: stur            w0, [x1, #0x57]
    //     0x692260: ldurb           w16, [x1, #-1]
    //     0x692264: ldurb           w17, [x0, #-1]
    //     0x692268: and             x16, x17, x16, lsr #2
    //     0x69226c: tst             x16, HEAP, lsr #32
    //     0x692270: b.eq            #0x692278
    //     0x692274: bl              #0xd6826c
    // 0x692278: SaveReg r1
    //     0x692278: str             x1, [SP, #-8]!
    // 0x69227c: r0 = alignChild()
    //     0x69227c: bl              #0x69064c  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::alignChild
    // 0x692280: add             SP, SP, #8
    // 0x692284: ldur            x3, [fp, #-0x10]
    // 0x692288: LoadField: r4 = r3->field_17
    //     0x692288: ldur            w4, [x3, #0x17]
    // 0x69228c: DecompressPointer r4
    //     0x69228c: add             x4, x4, HEAP, lsl #32
    // 0x692290: stur            x4, [fp, #-0x18]
    // 0x692294: cmp             w4, NULL
    // 0x692298: b.eq            #0x692464
    // 0x69229c: mov             x0, x4
    // 0x6922a0: r2 = Null
    //     0x6922a0: mov             x2, NULL
    // 0x6922a4: r1 = Null
    //     0x6922a4: mov             x1, NULL
    // 0x6922a8: r4 = LoadClassIdInstr(r0)
    //     0x6922a8: ldur            x4, [x0, #-1]
    //     0x6922ac: ubfx            x4, x4, #0xc, #0x14
    // 0x6922b0: sub             x4, x4, #0x7ff
    // 0x6922b4: cmp             x4, #0xb
    // 0x6922b8: b.ls            #0x6922d0
    // 0x6922bc: r8 = BoxParentData
    //     0x6922bc: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x6922c0: ldr             x8, [x8, #0x1b0]
    // 0x6922c4: r3 = Null
    //     0x6922c4: add             x3, PP, #0x55, lsl #12  ; [pp+0x55668] Null
    //     0x6922c8: ldr             x3, [x3, #0x668]
    // 0x6922cc: r0 = DefaultTypeTest()
    //     0x6922cc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6922d0: ldr             x0, [fp, #0x10]
    // 0x6922d4: LoadField: r1 = r0->field_57
    //     0x6922d4: ldur            w1, [x0, #0x57]
    // 0x6922d8: DecompressPointer r1
    //     0x6922d8: add             x1, x1, HEAP, lsl #32
    // 0x6922dc: cmp             w1, NULL
    // 0x6922e0: b.eq            #0x692468
    // 0x6922e4: r16 = Instance_Offset
    //     0x6922e4: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x6922e8: stp             x1, x16, [SP, #-0x10]!
    // 0x6922ec: r0 = &()
    //     0x6922ec: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x6922f0: add             SP, SP, #0x10
    // 0x6922f4: ldr             x1, [fp, #0x10]
    // 0x6922f8: StoreField: r1->field_7b = r0
    //     0x6922f8: stur            w0, [x1, #0x7b]
    //     0x6922fc: ldurb           w16, [x1, #-1]
    //     0x692300: ldurb           w17, [x0, #-1]
    //     0x692304: and             x16, x17, x16, lsr #2
    //     0x692308: tst             x16, HEAP, lsr #32
    //     0x69230c: b.eq            #0x692314
    //     0x692310: bl              #0xd6826c
    // 0x692314: ldur            x0, [fp, #-0x18]
    // 0x692318: LoadField: r2 = r0->field_7
    //     0x692318: ldur            w2, [x0, #7]
    // 0x69231c: DecompressPointer r2
    //     0x69231c: add             x2, x2, HEAP, lsl #32
    // 0x692320: ldur            x0, [fp, #-0x10]
    // 0x692324: LoadField: r3 = r0->field_57
    //     0x692324: ldur            w3, [x0, #0x57]
    // 0x692328: DecompressPointer r3
    //     0x692328: add             x3, x3, HEAP, lsl #32
    // 0x69232c: cmp             w3, NULL
    // 0x692330: b.eq            #0x69246c
    // 0x692334: stp             x3, x2, [SP, #-0x10]!
    // 0x692338: r0 = &()
    //     0x692338: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x69233c: add             SP, SP, #0x10
    // 0x692340: mov             x2, x0
    // 0x692344: ldr             x1, [fp, #0x10]
    // 0x692348: StoreField: r1->field_7f = r0
    //     0x692348: stur            w0, [x1, #0x7f]
    //     0x69234c: ldurb           w16, [x1, #-1]
    //     0x692350: ldurb           w17, [x0, #-1]
    //     0x692354: and             x16, x17, x16, lsr #2
    //     0x692358: tst             x16, HEAP, lsr #32
    //     0x69235c: b.eq            #0x692364
    //     0x692360: bl              #0xd6826c
    // 0x692364: mov             x0, x2
    // 0x692368: b               #0x6923ac
    // 0x69236c: ldur            x16, [fp, #-8]
    // 0x692370: SaveReg r16
    //     0x692370: str             x16, [SP, #-8]!
    // 0x692374: r0 = smallest()
    //     0x692374: bl              #0x62bd18  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0x692378: add             SP, SP, #8
    // 0x69237c: ldr             x1, [fp, #0x10]
    // 0x692380: StoreField: r1->field_57 = r0
    //     0x692380: stur            w0, [x1, #0x57]
    //     0x692384: ldurb           w16, [x1, #-1]
    //     0x692388: ldurb           w17, [x0, #-1]
    //     0x69238c: and             x16, x17, x16, lsr #2
    //     0x692390: tst             x16, HEAP, lsr #32
    //     0x692394: b.eq            #0x69239c
    //     0x692398: bl              #0xd6826c
    // 0x69239c: r0 = Instance_Rect
    //     0x69239c: ldr             x0, [PP, #0x5e48]  ; [pp+0x5e48] Obj!Rect@b5ebc1
    // 0x6923a0: StoreField: r1->field_7b = r0
    //     0x6923a0: stur            w0, [x1, #0x7b]
    // 0x6923a4: StoreField: r1->field_7f = r0
    //     0x6923a4: stur            w0, [x1, #0x7f]
    // 0x6923a8: r0 = Instance_Rect
    //     0x6923a8: ldr             x0, [PP, #0x5e48]  ; [pp+0x5e48] Obj!Rect@b5ebc1
    // 0x6923ac: LoadField: r2 = r1->field_7b
    //     0x6923ac: ldur            w2, [x1, #0x7b]
    // 0x6923b0: DecompressPointer r2
    //     0x6923b0: add             x2, x2, HEAP, lsl #32
    // 0x6923b4: stp             x2, NULL, [SP, #-0x10]!
    // 0x6923b8: SaveReg r0
    //     0x6923b8: str             x0, [SP, #-8]!
    // 0x6923bc: r0 = RelativeRect.fromRect()
    //     0x6923bc: bl              #0x692470  ; [package:flutter/src/rendering/stack.dart] RelativeRect::RelativeRect.fromRect
    // 0x6923c0: add             SP, SP, #0x18
    // 0x6923c4: LoadField: d0 = r0->field_7
    //     0x6923c4: ldur            d0, [x0, #7]
    // 0x6923c8: d1 = 0.000000
    //     0x6923c8: eor             v1.16b, v1.16b, v1.16b
    // 0x6923cc: fcmp            d0, d1
    // 0x6923d0: b.vs            #0x6923d8
    // 0x6923d4: b.gt            #0x6923f8
    // 0x6923d8: LoadField: d0 = r0->field_f
    //     0x6923d8: ldur            d0, [x0, #0xf]
    // 0x6923dc: fcmp            d0, d1
    // 0x6923e0: b.vs            #0x6923e8
    // 0x6923e4: b.gt            #0x6923f8
    // 0x6923e8: LoadField: d0 = r0->field_17
    //     0x6923e8: ldur            d0, [x0, #0x17]
    // 0x6923ec: fcmp            d0, d1
    // 0x6923f0: b.vs            #0x692400
    // 0x6923f4: b.le            #0x692400
    // 0x6923f8: r2 = true
    //     0x6923f8: add             x2, NULL, #0x20  ; true
    // 0x6923fc: b               #0x692420
    // 0x692400: LoadField: d0 = r0->field_1f
    //     0x692400: ldur            d0, [x0, #0x1f]
    // 0x692404: fcmp            d0, d1
    // 0x692408: b.vs            #0x692410
    // 0x69240c: b.gt            #0x692418
    // 0x692410: r1 = false
    //     0x692410: add             x1, NULL, #0x30  ; false
    // 0x692414: b               #0x69241c
    // 0x692418: r1 = true
    //     0x692418: add             x1, NULL, #0x20  ; true
    // 0x69241c: mov             x2, x1
    // 0x692420: ldr             x1, [fp, #0x10]
    // 0x692424: StoreField: r1->field_83 = r2
    //     0x692424: stur            w2, [x1, #0x83]
    // 0x692428: r0 = Null
    //     0x692428: mov             x0, NULL
    // 0x69242c: LeaveFrame
    //     0x69242c: mov             SP, fp
    //     0x692430: ldp             fp, lr, [SP], #0x10
    // 0x692434: ret
    //     0x692434: ret             
    // 0x692438: r0 = StateError()
    //     0x692438: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x69243c: mov             x1, x0
    // 0x692440: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x692440: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x692444: ldr             x0, [x0, #0x1e8]
    // 0x692448: StoreField: r1->field_b = r0
    //     0x692448: stur            w0, [x1, #0xb]
    // 0x69244c: mov             x0, x1
    // 0x692450: r0 = Throw()
    //     0x692450: bl              #0xd67e38  ; ThrowStub
    // 0x692454: brk             #0
    // 0x692458: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x692458: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69245c: b               #0x692154
    // 0x692460: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x692460: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x692464: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x692464: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x692468: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x692468: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69246c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69246c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ constraintsTransform=(/* No info */) {
    // ** addr: 0x6c5cd0, size: 0x174
    // 0x6c5cd0: EnterFrame
    //     0x6c5cd0: stp             fp, lr, [SP, #-0x10]!
    //     0x6c5cd4: mov             fp, SP
    // 0x6c5cd8: AllocStack(0x10)
    //     0x6c5cd8: sub             SP, SP, #0x10
    // 0x6c5cdc: CheckStackOverflow
    //     0x6c5cdc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c5ce0: cmp             SP, x16
    //     0x6c5ce4: b.ls            #0x6c5e3c
    // 0x6c5ce8: ldr             x1, [fp, #0x18]
    // 0x6c5cec: LoadField: r0 = r1->field_73
    //     0x6c5cec: ldur            w0, [x1, #0x73]
    // 0x6c5cf0: DecompressPointer r0
    //     0x6c5cf0: add             x0, x0, HEAP, lsl #32
    // 0x6c5cf4: r2 = LoadClassIdInstr(r0)
    //     0x6c5cf4: ldur            x2, [x0, #-1]
    //     0x6c5cf8: ubfx            x2, x2, #0xc, #0x14
    // 0x6c5cfc: ldr             x16, [fp, #0x10]
    // 0x6c5d00: stp             x16, x0, [SP, #-0x10]!
    // 0x6c5d04: mov             x0, x2
    // 0x6c5d08: mov             lr, x0
    // 0x6c5d0c: ldr             lr, [x21, lr, lsl #3]
    // 0x6c5d10: blr             lr
    // 0x6c5d14: add             SP, SP, #0x10
    // 0x6c5d18: tbnz            w0, #4, #0x6c5d2c
    // 0x6c5d1c: r0 = Null
    //     0x6c5d1c: mov             x0, NULL
    // 0x6c5d20: LeaveFrame
    //     0x6c5d20: mov             SP, fp
    //     0x6c5d24: ldp             fp, lr, [SP], #0x10
    // 0x6c5d28: ret
    //     0x6c5d28: ret             
    // 0x6c5d2c: ldr             x3, [fp, #0x18]
    // 0x6c5d30: ldr             x0, [fp, #0x10]
    // 0x6c5d34: StoreField: r3->field_73 = r0
    //     0x6c5d34: stur            w0, [x3, #0x73]
    //     0x6c5d38: ldurb           w16, [x3, #-1]
    //     0x6c5d3c: ldurb           w17, [x0, #-1]
    //     0x6c5d40: and             x16, x17, x16, lsr #2
    //     0x6c5d44: tst             x16, HEAP, lsr #32
    //     0x6c5d48: b.eq            #0x6c5d50
    //     0x6c5d4c: bl              #0xd682ac
    // 0x6c5d50: LoadField: r4 = r3->field_87
    //     0x6c5d50: ldur            w4, [x3, #0x87]
    // 0x6c5d54: DecompressPointer r4
    //     0x6c5d54: add             x4, x4, HEAP, lsl #32
    // 0x6c5d58: stur            x4, [fp, #-0x10]
    // 0x6c5d5c: cmp             w4, NULL
    // 0x6c5d60: b.eq            #0x6c5dfc
    // 0x6c5d64: LoadField: r5 = r3->field_27
    //     0x6c5d64: ldur            w5, [x3, #0x27]
    // 0x6c5d68: DecompressPointer r5
    //     0x6c5d68: add             x5, x5, HEAP, lsl #32
    // 0x6c5d6c: stur            x5, [fp, #-8]
    // 0x6c5d70: cmp             w5, NULL
    // 0x6c5d74: b.eq            #0x6c5e1c
    // 0x6c5d78: mov             x0, x5
    // 0x6c5d7c: r2 = Null
    //     0x6c5d7c: mov             x2, NULL
    // 0x6c5d80: r1 = Null
    //     0x6c5d80: mov             x1, NULL
    // 0x6c5d84: r4 = LoadClassIdInstr(r0)
    //     0x6c5d84: ldur            x4, [x0, #-1]
    //     0x6c5d88: ubfx            x4, x4, #0xc, #0x14
    // 0x6c5d8c: sub             x4, x4, #0x80d
    // 0x6c5d90: cmp             x4, #1
    // 0x6c5d94: b.ls            #0x6c5dac
    // 0x6c5d98: r8 = BoxConstraints
    //     0x6c5d98: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x6c5d9c: ldr             x8, [x8, #0x1d0]
    // 0x6c5da0: r3 = Null
    //     0x6c5da0: add             x3, PP, #0x53, lsl #12  ; [pp+0x53690] Null
    //     0x6c5da4: ldr             x3, [x3, #0x690]
    // 0x6c5da8: r0 = BoxConstraints()
    //     0x6c5da8: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x6c5dac: ldr             x16, [fp, #0x10]
    // 0x6c5db0: ldur            lr, [fp, #-8]
    // 0x6c5db4: stp             lr, x16, [SP, #-0x10]!
    // 0x6c5db8: ldr             x0, [fp, #0x10]
    // 0x6c5dbc: ClosureCall
    //     0x6c5dbc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6c5dc0: ldur            x2, [x0, #0x1f]
    //     0x6c5dc4: blr             x2
    // 0x6c5dc8: add             SP, SP, #0x10
    // 0x6c5dcc: mov             x1, x0
    // 0x6c5dd0: ldur            x0, [fp, #-0x10]
    // 0x6c5dd4: r2 = LoadClassIdInstr(r0)
    //     0x6c5dd4: ldur            x2, [x0, #-1]
    //     0x6c5dd8: ubfx            x2, x2, #0xc, #0x14
    // 0x6c5ddc: stp             x1, x0, [SP, #-0x10]!
    // 0x6c5de0: mov             x0, x2
    // 0x6c5de4: mov             lr, x0
    // 0x6c5de8: ldr             lr, [x21, lr, lsl #3]
    // 0x6c5dec: blr             lr
    // 0x6c5df0: add             SP, SP, #0x10
    // 0x6c5df4: eor             x1, x0, #0x10
    // 0x6c5df8: tbnz            w1, #4, #0x6c5e0c
    // 0x6c5dfc: ldr             x16, [fp, #0x18]
    // 0x6c5e00: SaveReg r16
    //     0x6c5e00: str             x16, [SP, #-8]!
    // 0x6c5e04: r0 = markNeedsLayout()
    //     0x6c5e04: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c5e08: add             SP, SP, #8
    // 0x6c5e0c: r0 = Null
    //     0x6c5e0c: mov             x0, NULL
    // 0x6c5e10: LeaveFrame
    //     0x6c5e10: mov             SP, fp
    //     0x6c5e14: ldp             fp, lr, [SP], #0x10
    // 0x6c5e18: ret
    //     0x6c5e18: ret             
    // 0x6c5e1c: r0 = StateError()
    //     0x6c5e1c: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6c5e20: mov             x1, x0
    // 0x6c5e24: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6c5e24: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6c5e28: ldr             x0, [x0, #0x1e8]
    // 0x6c5e2c: StoreField: r1->field_b = r0
    //     0x6c5e2c: stur            w0, [x1, #0xb]
    // 0x6c5e30: mov             x0, x1
    // 0x6c5e34: r0 = Throw()
    //     0x6c5e34: bl              #0xd67e38  ; ThrowStub
    // 0x6c5e38: brk             #0
    // 0x6c5e3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c5e3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c5e40: b               #0x6c5ce8
  }
  _ RenderConstraintsTransformBox(/* No info */) {
    // ** addr: 0x6ebd44, size: 0xac
    // 0x6ebd44: EnterFrame
    //     0x6ebd44: stp             fp, lr, [SP, #-0x10]!
    //     0x6ebd48: mov             fp, SP
    // 0x6ebd4c: r1 = Instance_Rect
    //     0x6ebd4c: ldr             x1, [PP, #0x5e48]  ; [pp+0x5e48] Obj!Rect@b5ebc1
    // 0x6ebd50: r0 = false
    //     0x6ebd50: add             x0, NULL, #0x30  ; false
    // 0x6ebd54: CheckStackOverflow
    //     0x6ebd54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ebd58: cmp             SP, x16
    //     0x6ebd5c: b.ls            #0x6ebde8
    // 0x6ebd60: ldr             x2, [fp, #0x20]
    // 0x6ebd64: StoreField: r2->field_7b = r1
    //     0x6ebd64: stur            w1, [x2, #0x7b]
    // 0x6ebd68: StoreField: r2->field_7f = r1
    //     0x6ebd68: stur            w1, [x2, #0x7f]
    // 0x6ebd6c: StoreField: r2->field_83 = r0
    //     0x6ebd6c: stur            w0, [x2, #0x83]
    // 0x6ebd70: r1 = <ClipRectLayer>
    //     0x6ebd70: add             x1, PP, #0x15, lsl #12  ; [pp+0x15388] TypeArguments: <ClipRectLayer>
    //     0x6ebd74: ldr             x1, [x1, #0x388]
    // 0x6ebd78: r0 = LayerHandle()
    //     0x6ebd78: bl              #0x5bbf28  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x6ebd7c: ldr             x1, [fp, #0x20]
    // 0x6ebd80: StoreField: r1->field_8b = r0
    //     0x6ebd80: stur            w0, [x1, #0x8b]
    //     0x6ebd84: ldurb           w16, [x1, #-1]
    //     0x6ebd88: ldurb           w17, [x0, #-1]
    //     0x6ebd8c: and             x16, x17, x16, lsr #2
    //     0x6ebd90: tst             x16, HEAP, lsr #32
    //     0x6ebd94: b.eq            #0x6ebd9c
    //     0x6ebd98: bl              #0xd6826c
    // 0x6ebd9c: ldr             x0, [fp, #0x18]
    // 0x6ebda0: StoreField: r1->field_73 = r0
    //     0x6ebda0: stur            w0, [x1, #0x73]
    //     0x6ebda4: ldurb           w16, [x1, #-1]
    //     0x6ebda8: ldurb           w17, [x0, #-1]
    //     0x6ebdac: and             x16, x17, x16, lsr #2
    //     0x6ebdb0: tst             x16, HEAP, lsr #32
    //     0x6ebdb4: b.eq            #0x6ebdbc
    //     0x6ebdb8: bl              #0xd6826c
    // 0x6ebdbc: r0 = Instance_Clip
    //     0x6ebdbc: add             x0, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x6ebdc0: ldr             x0, [x0, #0xb38]
    // 0x6ebdc4: StoreField: r1->field_77 = r0
    //     0x6ebdc4: stur            w0, [x1, #0x77]
    // 0x6ebdc8: ldr             x16, [fp, #0x10]
    // 0x6ebdcc: stp             x16, x1, [SP, #-0x10]!
    // 0x6ebdd0: r0 = _RenderConstraintsTransformBox&RenderAligningShiftedBox&DebugOverflowIndicatorMixin()
    //     0x6ebdd0: bl              #0x6ebdf0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderConstraintsTransformBox&RenderAligningShiftedBox&DebugOverflowIndicatorMixin::_RenderConstraintsTransformBox&RenderAligningShiftedBox&DebugOverflowIndicatorMixin
    // 0x6ebdd4: add             SP, SP, #0x10
    // 0x6ebdd8: r0 = Null
    //     0x6ebdd8: mov             x0, NULL
    // 0x6ebddc: LeaveFrame
    //     0x6ebddc: mov             SP, fp
    //     0x6ebde0: ldp             fp, lr, [SP], #0x10
    // 0x6ebde4: ret
    //     0x6ebde4: ret             
    // 0x6ebde8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ebde8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ebdec: b               #0x6ebd60
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5e1f0, size: 0xac
    // 0xa5e1f0: EnterFrame
    //     0xa5e1f0: stp             fp, lr, [SP, #-0x10]!
    //     0xa5e1f4: mov             fp, SP
    // 0xa5e1f8: AllocStack(0x8)
    //     0xa5e1f8: sub             SP, SP, #8
    // 0xa5e1fc: CheckStackOverflow
    //     0xa5e1fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5e200: cmp             SP, x16
    //     0xa5e204: b.ls            #0xa5e294
    // 0xa5e208: ldr             x0, [fp, #0x18]
    // 0xa5e20c: LoadField: r1 = r0->field_5f
    //     0xa5e20c: ldur            w1, [x0, #0x5f]
    // 0xa5e210: DecompressPointer r1
    //     0xa5e210: add             x1, x1, HEAP, lsl #32
    // 0xa5e214: stur            x1, [fp, #-8]
    // 0xa5e218: cmp             w1, NULL
    // 0xa5e21c: b.ne            #0xa5e228
    // 0xa5e220: r0 = Null
    //     0xa5e220: mov             x0, NULL
    // 0xa5e224: b               #0xa5e25c
    // 0xa5e228: LoadField: r2 = r0->field_73
    //     0xa5e228: ldur            w2, [x0, #0x73]
    // 0xa5e22c: DecompressPointer r2
    //     0xa5e22c: add             x2, x2, HEAP, lsl #32
    // 0xa5e230: ldr             x16, [fp, #0x10]
    // 0xa5e234: stp             x16, x2, [SP, #-0x10]!
    // 0xa5e238: mov             x0, x2
    // 0xa5e23c: ClosureCall
    //     0xa5e23c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xa5e240: ldur            x2, [x0, #0x1f]
    //     0xa5e244: blr             x2
    // 0xa5e248: add             SP, SP, #0x10
    // 0xa5e24c: ldur            x16, [fp, #-8]
    // 0xa5e250: stp             x0, x16, [SP, #-0x10]!
    // 0xa5e254: r0 = getDryLayout()
    //     0xa5e254: bl              #0x62d394  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xa5e258: add             SP, SP, #0x10
    // 0xa5e25c: cmp             w0, NULL
    // 0xa5e260: b.ne            #0xa5e278
    // 0xa5e264: ldr             x16, [fp, #0x10]
    // 0xa5e268: SaveReg r16
    //     0xa5e268: str             x16, [SP, #-8]!
    // 0xa5e26c: r0 = smallest()
    //     0xa5e26c: bl              #0x62bd18  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xa5e270: add             SP, SP, #8
    // 0xa5e274: b               #0xa5e288
    // 0xa5e278: ldr             x16, [fp, #0x10]
    // 0xa5e27c: stp             x0, x16, [SP, #-0x10]!
    // 0xa5e280: r0 = constrain()
    //     0xa5e280: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xa5e284: add             SP, SP, #0x10
    // 0xa5e288: LeaveFrame
    //     0xa5e288: mov             SP, fp
    //     0xa5e28c: ldp             fp, lr, [SP], #0x10
    // 0xa5e290: ret
    //     0xa5e290: ret             
    // 0xa5e294: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5e294: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5e298: b               #0xa5e208
  }
}

// class id: 2467, size: 0x84, field offset: 0x70
class RenderConstrainedOverflowBox extends RenderAligningShiftedBox {

  _ performLayout(/* No info */) {
    // ** addr: 0x691fd0, size: 0x110
    // 0x691fd0: EnterFrame
    //     0x691fd0: stp             fp, lr, [SP, #-0x10]!
    //     0x691fd4: mov             fp, SP
    // 0x691fd8: AllocStack(0x10)
    //     0x691fd8: sub             SP, SP, #0x10
    // 0x691fdc: CheckStackOverflow
    //     0x691fdc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x691fe0: cmp             SP, x16
    //     0x691fe4: b.ls            #0x6920d8
    // 0x691fe8: ldr             x3, [fp, #0x10]
    // 0x691fec: LoadField: r4 = r3->field_5f
    //     0x691fec: ldur            w4, [x3, #0x5f]
    // 0x691ff0: DecompressPointer r4
    //     0x691ff0: add             x4, x4, HEAP, lsl #32
    // 0x691ff4: stur            x4, [fp, #-0x10]
    // 0x691ff8: cmp             w4, NULL
    // 0x691ffc: b.eq            #0x6920a8
    // 0x692000: LoadField: r5 = r3->field_27
    //     0x692000: ldur            w5, [x3, #0x27]
    // 0x692004: DecompressPointer r5
    //     0x692004: add             x5, x5, HEAP, lsl #32
    // 0x692008: stur            x5, [fp, #-8]
    // 0x69200c: cmp             w5, NULL
    // 0x692010: b.eq            #0x6920b8
    // 0x692014: mov             x0, x5
    // 0x692018: r2 = Null
    //     0x692018: mov             x2, NULL
    // 0x69201c: r1 = Null
    //     0x69201c: mov             x1, NULL
    // 0x692020: r4 = LoadClassIdInstr(r0)
    //     0x692020: ldur            x4, [x0, #-1]
    //     0x692024: ubfx            x4, x4, #0xc, #0x14
    // 0x692028: sub             x4, x4, #0x80d
    // 0x69202c: cmp             x4, #1
    // 0x692030: b.ls            #0x692048
    // 0x692034: r8 = BoxConstraints
    //     0x692034: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x692038: ldr             x8, [x8, #0x1d0]
    // 0x69203c: r3 = Null
    //     0x69203c: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b1e0] Null
    //     0x692040: ldr             x3, [x3, #0x1e0]
    // 0x692044: r0 = BoxConstraints()
    //     0x692044: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x692048: ldr             x16, [fp, #0x10]
    // 0x69204c: ldur            lr, [fp, #-8]
    // 0x692050: stp             lr, x16, [SP, #-0x10]!
    // 0x692054: r0 = _getInnerConstraints()
    //     0x692054: bl              #0x6920e0  ; [package:flutter/src/rendering/shifted_box.dart] RenderConstrainedOverflowBox::_getInnerConstraints
    // 0x692058: add             SP, SP, #0x10
    // 0x69205c: mov             x1, x0
    // 0x692060: ldur            x0, [fp, #-0x10]
    // 0x692064: r2 = LoadClassIdInstr(r0)
    //     0x692064: ldur            x2, [x0, #-1]
    //     0x692068: ubfx            x2, x2, #0xc, #0x14
    // 0x69206c: stp             x1, x0, [SP, #-0x10]!
    // 0x692070: r16 = true
    //     0x692070: add             x16, NULL, #0x20  ; true
    // 0x692074: SaveReg r16
    //     0x692074: str             x16, [SP, #-8]!
    // 0x692078: mov             x0, x2
    // 0x69207c: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x69207c: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x692080: ldr             x4, [x4, #0x1c8]
    // 0x692084: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x692084: mov             x17, #0xcdfb
    //     0x692088: add             lr, x0, x17
    //     0x69208c: ldr             lr, [x21, lr, lsl #3]
    //     0x692090: blr             lr
    // 0x692094: add             SP, SP, #0x18
    // 0x692098: ldr             x16, [fp, #0x10]
    // 0x69209c: SaveReg r16
    //     0x69209c: str             x16, [SP, #-8]!
    // 0x6920a0: r0 = alignChild()
    //     0x6920a0: bl              #0x69064c  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::alignChild
    // 0x6920a4: add             SP, SP, #8
    // 0x6920a8: r0 = Null
    //     0x6920a8: mov             x0, NULL
    // 0x6920ac: LeaveFrame
    //     0x6920ac: mov             SP, fp
    //     0x6920b0: ldp             fp, lr, [SP], #0x10
    // 0x6920b4: ret
    //     0x6920b4: ret             
    // 0x6920b8: r0 = StateError()
    //     0x6920b8: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6920bc: mov             x1, x0
    // 0x6920c0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6920c0: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6920c4: ldr             x0, [x0, #0x1e8]
    // 0x6920c8: StoreField: r1->field_b = r0
    //     0x6920c8: stur            w0, [x1, #0xb]
    // 0x6920cc: mov             x0, x1
    // 0x6920d0: r0 = Throw()
    //     0x6920d0: bl              #0xd67e38  ; ThrowStub
    // 0x6920d4: brk             #0
    // 0x6920d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6920d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6920dc: b               #0x691fe8
  }
  _ _getInnerConstraints(/* No info */) {
    // ** addr: 0x6920e0, size: 0x5c
    // 0x6920e0: EnterFrame
    //     0x6920e0: stp             fp, lr, [SP, #-0x10]!
    //     0x6920e4: mov             fp, SP
    // 0x6920e8: AllocStack(0x18)
    //     0x6920e8: sub             SP, SP, #0x18
    // 0x6920ec: ldr             x0, [fp, #0x10]
    // 0x6920f0: LoadField: d0 = r0->field_7
    //     0x6920f0: ldur            d0, [x0, #7]
    // 0x6920f4: stur            d0, [fp, #-0x18]
    // 0x6920f8: LoadField: d1 = r0->field_17
    //     0x6920f8: ldur            d1, [x0, #0x17]
    // 0x6920fc: stur            d1, [fp, #-0x10]
    // 0x692100: LoadField: d2 = r0->field_1f
    //     0x692100: ldur            d2, [x0, #0x1f]
    // 0x692104: stur            d2, [fp, #-8]
    // 0x692108: r0 = BoxConstraints()
    //     0x692108: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x69210c: ldur            d0, [fp, #-0x18]
    // 0x692110: StoreField: r0->field_7 = d0
    //     0x692110: stur            d0, [x0, #7]
    // 0x692114: d0 = 80.000000
    //     0x692114: add             x17, PP, #0x25, lsl #12  ; [pp+0x25a40] IMM: double(80) from 0x4054000000000000
    //     0x692118: ldr             d0, [x17, #0xa40]
    // 0x69211c: StoreField: r0->field_f = d0
    //     0x69211c: stur            d0, [x0, #0xf]
    // 0x692120: ldur            d0, [fp, #-0x10]
    // 0x692124: StoreField: r0->field_17 = d0
    //     0x692124: stur            d0, [x0, #0x17]
    // 0x692128: ldur            d0, [fp, #-8]
    // 0x69212c: StoreField: r0->field_1f = d0
    //     0x69212c: stur            d0, [x0, #0x1f]
    // 0x692130: LeaveFrame
    //     0x692130: mov             SP, fp
    //     0x692134: ldp             fp, lr, [SP], #0x10
    // 0x692138: ret
    //     0x692138: ret             
  }
  set _ maxWidth=(/* No info */) {
    // ** addr: 0x6c62a4, size: 0x64
    // 0x6c62a4: EnterFrame
    //     0x6c62a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6c62a8: mov             fp, SP
    // 0x6c62ac: d0 = 80.000000
    //     0x6c62ac: add             x17, PP, #0x25, lsl #12  ; [pp+0x25a40] IMM: double(80) from 0x4054000000000000
    //     0x6c62b0: ldr             d0, [x17, #0xa40]
    // 0x6c62b4: CheckStackOverflow
    //     0x6c62b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c62b8: cmp             SP, x16
    //     0x6c62bc: b.ls            #0x6c6300
    // 0x6c62c0: fcmp            d0, d0
    // 0x6c62c4: b.vs            #0x6c62dc
    // 0x6c62c8: b.ne            #0x6c62dc
    // 0x6c62cc: r0 = Null
    //     0x6c62cc: mov             x0, NULL
    // 0x6c62d0: LeaveFrame
    //     0x6c62d0: mov             SP, fp
    //     0x6c62d4: ldp             fp, lr, [SP], #0x10
    // 0x6c62d8: ret
    //     0x6c62d8: ret             
    // 0x6c62dc: ldr             x0, [fp, #0x18]
    // 0x6c62e0: StoreField: r0->field_73 = d0
    //     0x6c62e0: stur            d0, [x0, #0x73]
    // 0x6c62e4: SaveReg r0
    //     0x6c62e4: str             x0, [SP, #-8]!
    // 0x6c62e8: r0 = markNeedsLayout()
    //     0x6c62e8: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c62ec: add             SP, SP, #8
    // 0x6c62f0: r0 = Null
    //     0x6c62f0: mov             x0, NULL
    // 0x6c62f4: LeaveFrame
    //     0x6c62f4: mov             SP, fp
    //     0x6c62f8: ldp             fp, lr, [SP], #0x10
    // 0x6c62fc: ret
    //     0x6c62fc: ret             
    // 0x6c6300: r0 = StackOverflowSharedWithFPURegs()
    //     0x6c6300: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x6c6304: b               #0x6c62c0
  }
  _ RenderConstrainedOverflowBox(/* No info */) {
    // ** addr: 0x6ec0a0, size: 0x84
    // 0x6ec0a0: EnterFrame
    //     0x6ec0a0: stp             fp, lr, [SP, #-0x10]!
    //     0x6ec0a4: mov             fp, SP
    // 0x6ec0a8: r0 = Instance_Alignment
    //     0x6ec0a8: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x6ec0ac: ldr             x0, [x0, #0xc70]
    // 0x6ec0b0: d0 = 80.000000
    //     0x6ec0b0: add             x17, PP, #0x25, lsl #12  ; [pp+0x25a40] IMM: double(80) from 0x4054000000000000
    //     0x6ec0b4: ldr             d0, [x17, #0xa40]
    // 0x6ec0b8: CheckStackOverflow
    //     0x6ec0b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ec0bc: cmp             SP, x16
    //     0x6ec0c0: b.ls            #0x6ec11c
    // 0x6ec0c4: ldr             x1, [fp, #0x18]
    // 0x6ec0c8: StoreField: r1->field_73 = d0
    //     0x6ec0c8: stur            d0, [x1, #0x73]
    // 0x6ec0cc: StoreField: r1->field_67 = r0
    //     0x6ec0cc: stur            w0, [x1, #0x67]
    // 0x6ec0d0: ldr             x0, [fp, #0x10]
    // 0x6ec0d4: StoreField: r1->field_6b = r0
    //     0x6ec0d4: stur            w0, [x1, #0x6b]
    //     0x6ec0d8: ldurb           w16, [x1, #-1]
    //     0x6ec0dc: ldurb           w17, [x0, #-1]
    //     0x6ec0e0: and             x16, x17, x16, lsr #2
    //     0x6ec0e4: tst             x16, HEAP, lsr #32
    //     0x6ec0e8: b.eq            #0x6ec0f0
    //     0x6ec0ec: bl              #0xd6826c
    // 0x6ec0f0: SaveReg r1
    //     0x6ec0f0: str             x1, [SP, #-8]!
    // 0x6ec0f4: r0 = RenderObject()
    //     0x6ec0f4: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6ec0f8: add             SP, SP, #8
    // 0x6ec0fc: ldr             x16, [fp, #0x18]
    // 0x6ec100: stp             NULL, x16, [SP, #-0x10]!
    // 0x6ec104: r0 = child=()
    //     0x6ec104: bl              #0x6e7da0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::child=
    // 0x6ec108: add             SP, SP, #0x10
    // 0x6ec10c: r0 = Null
    //     0x6ec10c: mov             x0, NULL
    // 0x6ec110: LeaveFrame
    //     0x6ec110: mov             SP, fp
    //     0x6ec114: ldp             fp, lr, [SP], #0x10
    // 0x6ec118: ret
    //     0x6ec118: ret             
    // 0x6ec11c: r0 = StackOverflowSharedWithFPURegs()
    //     0x6ec11c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x6ec120: b               #0x6ec0c4
  }
}

// class id: 2468, size: 0x78, field offset: 0x70
class RenderPositionedBox extends RenderAligningShiftedBox {

  _ performLayout(/* No info */) {
    // ** addr: 0x691cb4, size: 0x31c
    // 0x691cb4: EnterFrame
    //     0x691cb4: stp             fp, lr, [SP, #-0x10]!
    //     0x691cb8: mov             fp, SP
    // 0x691cbc: AllocStack(0x30)
    //     0x691cbc: sub             SP, SP, #0x30
    // 0x691cc0: CheckStackOverflow
    //     0x691cc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x691cc4: cmp             SP, x16
    //     0x691cc8: b.ls            #0x691fb8
    // 0x691ccc: ldr             x3, [fp, #0x10]
    // 0x691cd0: LoadField: r4 = r3->field_27
    //     0x691cd0: ldur            w4, [x3, #0x27]
    // 0x691cd4: DecompressPointer r4
    //     0x691cd4: add             x4, x4, HEAP, lsl #32
    // 0x691cd8: stur            x4, [fp, #-8]
    // 0x691cdc: cmp             w4, NULL
    // 0x691ce0: b.eq            #0x691f98
    // 0x691ce4: mov             x0, x4
    // 0x691ce8: r2 = Null
    //     0x691ce8: mov             x2, NULL
    // 0x691cec: r1 = Null
    //     0x691cec: mov             x1, NULL
    // 0x691cf0: r4 = LoadClassIdInstr(r0)
    //     0x691cf0: ldur            x4, [x0, #-1]
    //     0x691cf4: ubfx            x4, x4, #0xc, #0x14
    // 0x691cf8: sub             x4, x4, #0x80d
    // 0x691cfc: cmp             x4, #1
    // 0x691d00: b.ls            #0x691d18
    // 0x691d04: r8 = BoxConstraints
    //     0x691d04: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x691d08: ldr             x8, [x8, #0x1d0]
    // 0x691d0c: r3 = Null
    //     0x691d0c: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1ce60] Null
    //     0x691d10: ldr             x3, [x3, #0xe60]
    // 0x691d14: r0 = BoxConstraints()
    //     0x691d14: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x691d18: ldr             x0, [fp, #0x10]
    // 0x691d1c: LoadField: r1 = r0->field_6f
    //     0x691d1c: ldur            w1, [x0, #0x6f]
    // 0x691d20: DecompressPointer r1
    //     0x691d20: add             x1, x1, HEAP, lsl #32
    // 0x691d24: cmp             w1, NULL
    // 0x691d28: b.eq            #0x691d3c
    // 0x691d2c: ldur            x1, [fp, #-8]
    // 0x691d30: r2 = true
    //     0x691d30: add             x2, NULL, #0x20  ; true
    // 0x691d34: d0 = inf
    //     0x691d34: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x691d38: b               #0x691d60
    // 0x691d3c: ldur            x1, [fp, #-8]
    // 0x691d40: d0 = inf
    //     0x691d40: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x691d44: LoadField: d1 = r1->field_f
    //     0x691d44: ldur            d1, [x1, #0xf]
    // 0x691d48: fcmp            d1, d0
    // 0x691d4c: b.vs            #0x691d54
    // 0x691d50: b.eq            #0x691d5c
    // 0x691d54: r2 = false
    //     0x691d54: add             x2, NULL, #0x30  ; false
    // 0x691d58: b               #0x691d60
    // 0x691d5c: r2 = true
    //     0x691d5c: add             x2, NULL, #0x20  ; true
    // 0x691d60: stur            x2, [fp, #-0x20]
    // 0x691d64: LoadField: r3 = r0->field_73
    //     0x691d64: ldur            w3, [x0, #0x73]
    // 0x691d68: DecompressPointer r3
    //     0x691d68: add             x3, x3, HEAP, lsl #32
    // 0x691d6c: cmp             w3, NULL
    // 0x691d70: b.eq            #0x691d7c
    // 0x691d74: r3 = true
    //     0x691d74: add             x3, NULL, #0x20  ; true
    // 0x691d78: b               #0x691d98
    // 0x691d7c: LoadField: d1 = r1->field_1f
    //     0x691d7c: ldur            d1, [x1, #0x1f]
    // 0x691d80: fcmp            d1, d0
    // 0x691d84: b.vs            #0x691d8c
    // 0x691d88: b.eq            #0x691d94
    // 0x691d8c: r3 = false
    //     0x691d8c: add             x3, NULL, #0x30  ; false
    // 0x691d90: b               #0x691d98
    // 0x691d94: r3 = true
    //     0x691d94: add             x3, NULL, #0x20  ; true
    // 0x691d98: stur            x3, [fp, #-0x18]
    // 0x691d9c: LoadField: r4 = r0->field_5f
    //     0x691d9c: ldur            w4, [x0, #0x5f]
    // 0x691da0: DecompressPointer r4
    //     0x691da0: add             x4, x4, HEAP, lsl #32
    // 0x691da4: stur            x4, [fp, #-0x10]
    // 0x691da8: cmp             w4, NULL
    // 0x691dac: b.eq            #0x691f0c
    // 0x691db0: SaveReg r1
    //     0x691db0: str             x1, [SP, #-8]!
    // 0x691db4: r0 = loosen()
    //     0x691db4: bl              #0x68f088  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0x691db8: add             SP, SP, #8
    // 0x691dbc: mov             x1, x0
    // 0x691dc0: ldur            x0, [fp, #-0x10]
    // 0x691dc4: r2 = LoadClassIdInstr(r0)
    //     0x691dc4: ldur            x2, [x0, #-1]
    //     0x691dc8: ubfx            x2, x2, #0xc, #0x14
    // 0x691dcc: stp             x1, x0, [SP, #-0x10]!
    // 0x691dd0: r16 = true
    //     0x691dd0: add             x16, NULL, #0x20  ; true
    // 0x691dd4: SaveReg r16
    //     0x691dd4: str             x16, [SP, #-8]!
    // 0x691dd8: mov             x0, x2
    // 0x691ddc: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x691ddc: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x691de0: ldr             x4, [x4, #0x1c8]
    // 0x691de4: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x691de4: mov             x17, #0xcdfb
    //     0x691de8: add             lr, x0, x17
    //     0x691dec: ldr             lr, [x21, lr, lsl #3]
    //     0x691df0: blr             lr
    // 0x691df4: add             SP, SP, #0x18
    // 0x691df8: ldur            x0, [fp, #-0x20]
    // 0x691dfc: tbnz            w0, #4, #0x691e50
    // 0x691e00: ldr             x0, [fp, #0x10]
    // 0x691e04: LoadField: r1 = r0->field_5f
    //     0x691e04: ldur            w1, [x0, #0x5f]
    // 0x691e08: DecompressPointer r1
    //     0x691e08: add             x1, x1, HEAP, lsl #32
    // 0x691e0c: cmp             w1, NULL
    // 0x691e10: b.eq            #0x691fc0
    // 0x691e14: LoadField: r2 = r1->field_57
    //     0x691e14: ldur            w2, [x1, #0x57]
    // 0x691e18: DecompressPointer r2
    //     0x691e18: add             x2, x2, HEAP, lsl #32
    // 0x691e1c: cmp             w2, NULL
    // 0x691e20: b.eq            #0x691fc4
    // 0x691e24: LoadField: d0 = r2->field_7
    //     0x691e24: ldur            d0, [x2, #7]
    // 0x691e28: LoadField: r1 = r0->field_6f
    //     0x691e28: ldur            w1, [x0, #0x6f]
    // 0x691e2c: DecompressPointer r1
    //     0x691e2c: add             x1, x1, HEAP, lsl #32
    // 0x691e30: cmp             w1, NULL
    // 0x691e34: b.ne            #0x691e40
    // 0x691e38: d1 = 1.000000
    //     0x691e38: fmov            d1, #1.00000000
    // 0x691e3c: b               #0x691e44
    // 0x691e40: LoadField: d1 = r1->field_7
    //     0x691e40: ldur            d1, [x1, #7]
    // 0x691e44: fmul            d2, d0, d1
    // 0x691e48: mov             v0.16b, v2.16b
    // 0x691e4c: b               #0x691e58
    // 0x691e50: ldr             x0, [fp, #0x10]
    // 0x691e54: d0 = inf
    //     0x691e54: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x691e58: ldur            x1, [fp, #-0x18]
    // 0x691e5c: stur            d0, [fp, #-0x30]
    // 0x691e60: tbnz            w1, #4, #0x691eb0
    // 0x691e64: LoadField: r1 = r0->field_5f
    //     0x691e64: ldur            w1, [x0, #0x5f]
    // 0x691e68: DecompressPointer r1
    //     0x691e68: add             x1, x1, HEAP, lsl #32
    // 0x691e6c: cmp             w1, NULL
    // 0x691e70: b.eq            #0x691fc8
    // 0x691e74: LoadField: r2 = r1->field_57
    //     0x691e74: ldur            w2, [x1, #0x57]
    // 0x691e78: DecompressPointer r2
    //     0x691e78: add             x2, x2, HEAP, lsl #32
    // 0x691e7c: cmp             w2, NULL
    // 0x691e80: b.eq            #0x691fcc
    // 0x691e84: LoadField: d1 = r2->field_f
    //     0x691e84: ldur            d1, [x2, #0xf]
    // 0x691e88: LoadField: r1 = r0->field_73
    //     0x691e88: ldur            w1, [x0, #0x73]
    // 0x691e8c: DecompressPointer r1
    //     0x691e8c: add             x1, x1, HEAP, lsl #32
    // 0x691e90: cmp             w1, NULL
    // 0x691e94: b.ne            #0x691ea0
    // 0x691e98: d2 = 1.000000
    //     0x691e98: fmov            d2, #1.00000000
    // 0x691e9c: b               #0x691ea4
    // 0x691ea0: LoadField: d2 = r1->field_7
    //     0x691ea0: ldur            d2, [x1, #7]
    // 0x691ea4: fmul            d3, d1, d2
    // 0x691ea8: mov             v1.16b, v3.16b
    // 0x691eac: b               #0x691eb4
    // 0x691eb0: d1 = inf
    //     0x691eb0: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x691eb4: stur            d1, [fp, #-0x28]
    // 0x691eb8: r0 = Size()
    //     0x691eb8: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x691ebc: ldur            d0, [fp, #-0x30]
    // 0x691ec0: StoreField: r0->field_7 = d0
    //     0x691ec0: stur            d0, [x0, #7]
    // 0x691ec4: ldur            d0, [fp, #-0x28]
    // 0x691ec8: StoreField: r0->field_f = d0
    //     0x691ec8: stur            d0, [x0, #0xf]
    // 0x691ecc: ldur            x16, [fp, #-8]
    // 0x691ed0: stp             x0, x16, [SP, #-0x10]!
    // 0x691ed4: r0 = constrain()
    //     0x691ed4: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x691ed8: add             SP, SP, #0x10
    // 0x691edc: ldr             x2, [fp, #0x10]
    // 0x691ee0: StoreField: r2->field_57 = r0
    //     0x691ee0: stur            w0, [x2, #0x57]
    //     0x691ee4: ldurb           w16, [x2, #-1]
    //     0x691ee8: ldurb           w17, [x0, #-1]
    //     0x691eec: and             x16, x17, x16, lsr #2
    //     0x691ef0: tst             x16, HEAP, lsr #32
    //     0x691ef4: b.eq            #0x691efc
    //     0x691ef8: bl              #0xd6828c
    // 0x691efc: SaveReg r2
    //     0x691efc: str             x2, [SP, #-8]!
    // 0x691f00: r0 = alignChild()
    //     0x691f00: bl              #0x69064c  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::alignChild
    // 0x691f04: add             SP, SP, #8
    // 0x691f08: b               #0x691f88
    // 0x691f0c: mov             x16, x2
    // 0x691f10: mov             x2, x0
    // 0x691f14: mov             x0, x16
    // 0x691f18: mov             x1, x3
    // 0x691f1c: tbnz            w0, #4, #0x691f28
    // 0x691f20: d0 = 0.000000
    //     0x691f20: eor             v0.16b, v0.16b, v0.16b
    // 0x691f24: b               #0x691f2c
    // 0x691f28: d0 = inf
    //     0x691f28: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x691f2c: stur            d0, [fp, #-0x30]
    // 0x691f30: tbnz            w1, #4, #0x691f3c
    // 0x691f34: d1 = 0.000000
    //     0x691f34: eor             v1.16b, v1.16b, v1.16b
    // 0x691f38: b               #0x691f40
    // 0x691f3c: d1 = inf
    //     0x691f3c: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x691f40: stur            d1, [fp, #-0x28]
    // 0x691f44: r0 = Size()
    //     0x691f44: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x691f48: ldur            d0, [fp, #-0x30]
    // 0x691f4c: StoreField: r0->field_7 = d0
    //     0x691f4c: stur            d0, [x0, #7]
    // 0x691f50: ldur            d0, [fp, #-0x28]
    // 0x691f54: StoreField: r0->field_f = d0
    //     0x691f54: stur            d0, [x0, #0xf]
    // 0x691f58: ldur            x16, [fp, #-8]
    // 0x691f5c: stp             x0, x16, [SP, #-0x10]!
    // 0x691f60: r0 = constrain()
    //     0x691f60: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x691f64: add             SP, SP, #0x10
    // 0x691f68: ldr             x1, [fp, #0x10]
    // 0x691f6c: StoreField: r1->field_57 = r0
    //     0x691f6c: stur            w0, [x1, #0x57]
    //     0x691f70: ldurb           w16, [x1, #-1]
    //     0x691f74: ldurb           w17, [x0, #-1]
    //     0x691f78: and             x16, x17, x16, lsr #2
    //     0x691f7c: tst             x16, HEAP, lsr #32
    //     0x691f80: b.eq            #0x691f88
    //     0x691f84: bl              #0xd6826c
    // 0x691f88: r0 = Null
    //     0x691f88: mov             x0, NULL
    // 0x691f8c: LeaveFrame
    //     0x691f8c: mov             SP, fp
    //     0x691f90: ldp             fp, lr, [SP], #0x10
    // 0x691f94: ret
    //     0x691f94: ret             
    // 0x691f98: r0 = StateError()
    //     0x691f98: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x691f9c: mov             x1, x0
    // 0x691fa0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x691fa0: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x691fa4: ldr             x0, [x0, #0x1e8]
    // 0x691fa8: StoreField: r1->field_b = r0
    //     0x691fa8: stur            w0, [x1, #0xb]
    // 0x691fac: mov             x0, x1
    // 0x691fb0: r0 = Throw()
    //     0x691fb0: bl              #0xd67e38  ; ThrowStub
    // 0x691fb4: brk             #0
    // 0x691fb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x691fb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x691fbc: b               #0x691ccc
    // 0x691fc0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x691fc0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x691fc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x691fc4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x691fc8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x691fc8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x691fcc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x691fcc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  set _ heightFactor=(/* No info */) {
    // ** addr: 0x6c565c, size: 0xa0
    // 0x6c565c: EnterFrame
    //     0x6c565c: stp             fp, lr, [SP, #-0x10]!
    //     0x6c5660: mov             fp, SP
    // 0x6c5664: CheckStackOverflow
    //     0x6c5664: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c5668: cmp             SP, x16
    //     0x6c566c: b.ls            #0x6c56f4
    // 0x6c5670: ldr             x1, [fp, #0x18]
    // 0x6c5674: LoadField: r0 = r1->field_73
    //     0x6c5674: ldur            w0, [x1, #0x73]
    // 0x6c5678: DecompressPointer r0
    //     0x6c5678: add             x0, x0, HEAP, lsl #32
    // 0x6c567c: r2 = LoadClassIdInstr(r0)
    //     0x6c567c: ldur            x2, [x0, #-1]
    //     0x6c5680: ubfx            x2, x2, #0xc, #0x14
    // 0x6c5684: ldr             x16, [fp, #0x10]
    // 0x6c5688: stp             x16, x0, [SP, #-0x10]!
    // 0x6c568c: mov             x0, x2
    // 0x6c5690: mov             lr, x0
    // 0x6c5694: ldr             lr, [x21, lr, lsl #3]
    // 0x6c5698: blr             lr
    // 0x6c569c: add             SP, SP, #0x10
    // 0x6c56a0: tbnz            w0, #4, #0x6c56b4
    // 0x6c56a4: r0 = Null
    //     0x6c56a4: mov             x0, NULL
    // 0x6c56a8: LeaveFrame
    //     0x6c56a8: mov             SP, fp
    //     0x6c56ac: ldp             fp, lr, [SP], #0x10
    // 0x6c56b0: ret
    //     0x6c56b0: ret             
    // 0x6c56b4: ldr             x1, [fp, #0x18]
    // 0x6c56b8: ldr             x0, [fp, #0x10]
    // 0x6c56bc: StoreField: r1->field_73 = r0
    //     0x6c56bc: stur            w0, [x1, #0x73]
    //     0x6c56c0: ldurb           w16, [x1, #-1]
    //     0x6c56c4: ldurb           w17, [x0, #-1]
    //     0x6c56c8: and             x16, x17, x16, lsr #2
    //     0x6c56cc: tst             x16, HEAP, lsr #32
    //     0x6c56d0: b.eq            #0x6c56d8
    //     0x6c56d4: bl              #0xd6826c
    // 0x6c56d8: SaveReg r1
    //     0x6c56d8: str             x1, [SP, #-8]!
    // 0x6c56dc: r0 = markNeedsLayout()
    //     0x6c56dc: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c56e0: add             SP, SP, #8
    // 0x6c56e4: r0 = Null
    //     0x6c56e4: mov             x0, NULL
    // 0x6c56e8: LeaveFrame
    //     0x6c56e8: mov             SP, fp
    //     0x6c56ec: ldp             fp, lr, [SP], #0x10
    // 0x6c56f0: ret
    //     0x6c56f0: ret             
    // 0x6c56f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c56f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c56f8: b               #0x6c5670
  }
  set _ widthFactor=(/* No info */) {
    // ** addr: 0x6c56fc, size: 0xa0
    // 0x6c56fc: EnterFrame
    //     0x6c56fc: stp             fp, lr, [SP, #-0x10]!
    //     0x6c5700: mov             fp, SP
    // 0x6c5704: CheckStackOverflow
    //     0x6c5704: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c5708: cmp             SP, x16
    //     0x6c570c: b.ls            #0x6c5794
    // 0x6c5710: ldr             x1, [fp, #0x18]
    // 0x6c5714: LoadField: r0 = r1->field_6f
    //     0x6c5714: ldur            w0, [x1, #0x6f]
    // 0x6c5718: DecompressPointer r0
    //     0x6c5718: add             x0, x0, HEAP, lsl #32
    // 0x6c571c: r2 = LoadClassIdInstr(r0)
    //     0x6c571c: ldur            x2, [x0, #-1]
    //     0x6c5720: ubfx            x2, x2, #0xc, #0x14
    // 0x6c5724: ldr             x16, [fp, #0x10]
    // 0x6c5728: stp             x16, x0, [SP, #-0x10]!
    // 0x6c572c: mov             x0, x2
    // 0x6c5730: mov             lr, x0
    // 0x6c5734: ldr             lr, [x21, lr, lsl #3]
    // 0x6c5738: blr             lr
    // 0x6c573c: add             SP, SP, #0x10
    // 0x6c5740: tbnz            w0, #4, #0x6c5754
    // 0x6c5744: r0 = Null
    //     0x6c5744: mov             x0, NULL
    // 0x6c5748: LeaveFrame
    //     0x6c5748: mov             SP, fp
    //     0x6c574c: ldp             fp, lr, [SP], #0x10
    // 0x6c5750: ret
    //     0x6c5750: ret             
    // 0x6c5754: ldr             x1, [fp, #0x18]
    // 0x6c5758: ldr             x0, [fp, #0x10]
    // 0x6c575c: StoreField: r1->field_6f = r0
    //     0x6c575c: stur            w0, [x1, #0x6f]
    //     0x6c5760: ldurb           w16, [x1, #-1]
    //     0x6c5764: ldurb           w17, [x0, #-1]
    //     0x6c5768: and             x16, x17, x16, lsr #2
    //     0x6c576c: tst             x16, HEAP, lsr #32
    //     0x6c5770: b.eq            #0x6c5778
    //     0x6c5774: bl              #0xd6826c
    // 0x6c5778: SaveReg r1
    //     0x6c5778: str             x1, [SP, #-8]!
    // 0x6c577c: r0 = markNeedsLayout()
    //     0x6c577c: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c5780: add             SP, SP, #8
    // 0x6c5784: r0 = Null
    //     0x6c5784: mov             x0, NULL
    // 0x6c5788: LeaveFrame
    //     0x6c5788: mov             SP, fp
    //     0x6c578c: ldp             fp, lr, [SP], #0x10
    // 0x6c5790: ret
    //     0x6c5790: ret             
    // 0x6c5794: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c5794: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c5798: b               #0x6c5710
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5e008, size: 0x1e8
    // 0xa5e008: EnterFrame
    //     0xa5e008: stp             fp, lr, [SP, #-0x10]!
    //     0xa5e00c: mov             fp, SP
    // 0xa5e010: AllocStack(0x28)
    //     0xa5e010: sub             SP, SP, #0x28
    // 0xa5e014: CheckStackOverflow
    //     0xa5e014: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5e018: cmp             SP, x16
    //     0xa5e01c: b.ls            #0xa5e1e8
    // 0xa5e020: ldr             x0, [fp, #0x18]
    // 0xa5e024: LoadField: r1 = r0->field_6f
    //     0xa5e024: ldur            w1, [x0, #0x6f]
    // 0xa5e028: DecompressPointer r1
    //     0xa5e028: add             x1, x1, HEAP, lsl #32
    // 0xa5e02c: cmp             w1, NULL
    // 0xa5e030: b.eq            #0xa5e044
    // 0xa5e034: ldr             x1, [fp, #0x10]
    // 0xa5e038: r2 = true
    //     0xa5e038: add             x2, NULL, #0x20  ; true
    // 0xa5e03c: d0 = inf
    //     0xa5e03c: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xa5e040: b               #0xa5e068
    // 0xa5e044: ldr             x1, [fp, #0x10]
    // 0xa5e048: d0 = inf
    //     0xa5e048: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xa5e04c: LoadField: d1 = r1->field_f
    //     0xa5e04c: ldur            d1, [x1, #0xf]
    // 0xa5e050: fcmp            d1, d0
    // 0xa5e054: b.vs            #0xa5e05c
    // 0xa5e058: b.eq            #0xa5e064
    // 0xa5e05c: r2 = false
    //     0xa5e05c: add             x2, NULL, #0x30  ; false
    // 0xa5e060: b               #0xa5e068
    // 0xa5e064: r2 = true
    //     0xa5e064: add             x2, NULL, #0x20  ; true
    // 0xa5e068: stur            x2, [fp, #-0x18]
    // 0xa5e06c: LoadField: r3 = r0->field_73
    //     0xa5e06c: ldur            w3, [x0, #0x73]
    // 0xa5e070: DecompressPointer r3
    //     0xa5e070: add             x3, x3, HEAP, lsl #32
    // 0xa5e074: cmp             w3, NULL
    // 0xa5e078: b.eq            #0xa5e084
    // 0xa5e07c: r3 = true
    //     0xa5e07c: add             x3, NULL, #0x20  ; true
    // 0xa5e080: b               #0xa5e0a0
    // 0xa5e084: LoadField: d1 = r1->field_1f
    //     0xa5e084: ldur            d1, [x1, #0x1f]
    // 0xa5e088: fcmp            d1, d0
    // 0xa5e08c: b.vs            #0xa5e094
    // 0xa5e090: b.eq            #0xa5e09c
    // 0xa5e094: r3 = false
    //     0xa5e094: add             x3, NULL, #0x30  ; false
    // 0xa5e098: b               #0xa5e0a0
    // 0xa5e09c: r3 = true
    //     0xa5e09c: add             x3, NULL, #0x20  ; true
    // 0xa5e0a0: stur            x3, [fp, #-0x10]
    // 0xa5e0a4: LoadField: r4 = r0->field_5f
    //     0xa5e0a4: ldur            w4, [x0, #0x5f]
    // 0xa5e0a8: DecompressPointer r4
    //     0xa5e0a8: add             x4, x4, HEAP, lsl #32
    // 0xa5e0ac: stur            x4, [fp, #-8]
    // 0xa5e0b0: cmp             w4, NULL
    // 0xa5e0b4: b.eq            #0xa5e188
    // 0xa5e0b8: SaveReg r1
    //     0xa5e0b8: str             x1, [SP, #-8]!
    // 0xa5e0bc: r0 = loosen()
    //     0xa5e0bc: bl              #0x68f088  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0xa5e0c0: add             SP, SP, #8
    // 0xa5e0c4: ldur            x16, [fp, #-8]
    // 0xa5e0c8: stp             x0, x16, [SP, #-0x10]!
    // 0xa5e0cc: r0 = getDryLayout()
    //     0xa5e0cc: bl              #0x62d394  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xa5e0d0: add             SP, SP, #0x10
    // 0xa5e0d4: mov             x1, x0
    // 0xa5e0d8: ldur            x0, [fp, #-0x18]
    // 0xa5e0dc: tbnz            w0, #4, #0xa5e110
    // 0xa5e0e0: ldr             x0, [fp, #0x18]
    // 0xa5e0e4: LoadField: d0 = r1->field_7
    //     0xa5e0e4: ldur            d0, [x1, #7]
    // 0xa5e0e8: LoadField: r2 = r0->field_6f
    //     0xa5e0e8: ldur            w2, [x0, #0x6f]
    // 0xa5e0ec: DecompressPointer r2
    //     0xa5e0ec: add             x2, x2, HEAP, lsl #32
    // 0xa5e0f0: cmp             w2, NULL
    // 0xa5e0f4: b.ne            #0xa5e100
    // 0xa5e0f8: d1 = 1.000000
    //     0xa5e0f8: fmov            d1, #1.00000000
    // 0xa5e0fc: b               #0xa5e104
    // 0xa5e100: LoadField: d1 = r2->field_7
    //     0xa5e100: ldur            d1, [x2, #7]
    // 0xa5e104: fmul            d2, d0, d1
    // 0xa5e108: mov             v0.16b, v2.16b
    // 0xa5e10c: b               #0xa5e118
    // 0xa5e110: ldr             x0, [fp, #0x18]
    // 0xa5e114: d0 = inf
    //     0xa5e114: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xa5e118: ldur            x2, [fp, #-0x10]
    // 0xa5e11c: stur            d0, [fp, #-0x28]
    // 0xa5e120: tbnz            w2, #4, #0xa5e150
    // 0xa5e124: LoadField: d1 = r1->field_f
    //     0xa5e124: ldur            d1, [x1, #0xf]
    // 0xa5e128: LoadField: r1 = r0->field_73
    //     0xa5e128: ldur            w1, [x0, #0x73]
    // 0xa5e12c: DecompressPointer r1
    //     0xa5e12c: add             x1, x1, HEAP, lsl #32
    // 0xa5e130: cmp             w1, NULL
    // 0xa5e134: b.ne            #0xa5e140
    // 0xa5e138: d2 = 1.000000
    //     0xa5e138: fmov            d2, #1.00000000
    // 0xa5e13c: b               #0xa5e144
    // 0xa5e140: LoadField: d2 = r1->field_7
    //     0xa5e140: ldur            d2, [x1, #7]
    // 0xa5e144: fmul            d3, d1, d2
    // 0xa5e148: mov             v1.16b, v3.16b
    // 0xa5e14c: b               #0xa5e154
    // 0xa5e150: d1 = inf
    //     0xa5e150: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xa5e154: stur            d1, [fp, #-0x20]
    // 0xa5e158: r0 = Size()
    //     0xa5e158: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xa5e15c: ldur            d0, [fp, #-0x28]
    // 0xa5e160: StoreField: r0->field_7 = d0
    //     0xa5e160: stur            d0, [x0, #7]
    // 0xa5e164: ldur            d0, [fp, #-0x20]
    // 0xa5e168: StoreField: r0->field_f = d0
    //     0xa5e168: stur            d0, [x0, #0xf]
    // 0xa5e16c: ldr             x16, [fp, #0x10]
    // 0xa5e170: stp             x0, x16, [SP, #-0x10]!
    // 0xa5e174: r0 = constrain()
    //     0xa5e174: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xa5e178: add             SP, SP, #0x10
    // 0xa5e17c: LeaveFrame
    //     0xa5e17c: mov             SP, fp
    //     0xa5e180: ldp             fp, lr, [SP], #0x10
    // 0xa5e184: ret
    //     0xa5e184: ret             
    // 0xa5e188: mov             x0, x2
    // 0xa5e18c: mov             x2, x3
    // 0xa5e190: tbnz            w0, #4, #0xa5e19c
    // 0xa5e194: d0 = 0.000000
    //     0xa5e194: eor             v0.16b, v0.16b, v0.16b
    // 0xa5e198: b               #0xa5e1a0
    // 0xa5e19c: d0 = inf
    //     0xa5e19c: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xa5e1a0: stur            d0, [fp, #-0x28]
    // 0xa5e1a4: tbnz            w2, #4, #0xa5e1b0
    // 0xa5e1a8: d1 = 0.000000
    //     0xa5e1a8: eor             v1.16b, v1.16b, v1.16b
    // 0xa5e1ac: b               #0xa5e1b4
    // 0xa5e1b0: d1 = inf
    //     0xa5e1b0: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xa5e1b4: stur            d1, [fp, #-0x20]
    // 0xa5e1b8: r0 = Size()
    //     0xa5e1b8: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xa5e1bc: ldur            d0, [fp, #-0x28]
    // 0xa5e1c0: StoreField: r0->field_7 = d0
    //     0xa5e1c0: stur            d0, [x0, #7]
    // 0xa5e1c4: ldur            d0, [fp, #-0x20]
    // 0xa5e1c8: StoreField: r0->field_f = d0
    //     0xa5e1c8: stur            d0, [x0, #0xf]
    // 0xa5e1cc: ldr             x16, [fp, #0x10]
    // 0xa5e1d0: stp             x0, x16, [SP, #-0x10]!
    // 0xa5e1d4: r0 = constrain()
    //     0xa5e1d4: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xa5e1d8: add             SP, SP, #0x10
    // 0xa5e1dc: LeaveFrame
    //     0xa5e1dc: mov             SP, fp
    //     0xa5e1e0: ldp             fp, lr, [SP], #0x10
    // 0xa5e1e4: ret
    //     0xa5e1e4: ret             
    // 0xa5e1e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5e1e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5e1ec: b               #0xa5e020
  }
}

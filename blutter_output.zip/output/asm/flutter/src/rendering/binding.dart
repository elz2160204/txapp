// lib: , url: package:flutter/src/rendering/binding.dart

// class id: 1049394, size: 0x8
class :: {
}

// class id: 2063, size: 0x8, field offset: 0x8
abstract class _RendererBinding&BindingBase&ServicesBinding&SchedulerBinding&GestureBinding&SemanticsBinding&HitTestable extends Object
    implements _RendererBinding&BindingBase&ServicesBinding&SchedulerBinding&GestureBinding&SemanticsBinding, HitTestable {
}

// class id: 2064, size: 0x8, field offset: 0x8
abstract class RendererBinding extends _RendererBinding&BindingBase&ServicesBinding&SchedulerBinding&GestureBinding&SemanticsBinding&HitTestable {

  get _ instance(/* No info */) {
    // ** addr: 0x7d0b38, size: 0x28
    // 0x7d0b38: EnterFrame
    //     0x7d0b38: stp             fp, lr, [SP, #-0x10]!
    //     0x7d0b3c: mov             fp, SP
    // 0x7d0b40: r0 = LoadStaticField(0xea4)
    //     0x7d0b40: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7d0b44: ldr             x0, [x0, #0x1d48]
    // 0x7d0b48: cmp             w0, NULL
    // 0x7d0b4c: b.eq            #0x7d0b5c
    // 0x7d0b50: LeaveFrame
    //     0x7d0b50: mov             SP, fp
    //     0x7d0b54: ldp             fp, lr, [SP], #0x10
    // 0x7d0b58: ret
    //     0x7d0b58: ret             
    // 0x7d0b5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7d0b5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2066, size: 0x8, field offset: 0x8
abstract class _RendererBinding&BindingBase&ServicesBinding&SchedulerBinding&GestureBinding&SemanticsBinding extends Object
    implements _WidgetsBinding&BindingBase&ServicesBinding&SchedulerBinding&GestureBinding, SemanticsBinding {
}

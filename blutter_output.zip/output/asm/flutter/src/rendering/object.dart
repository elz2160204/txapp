// lib: , url: package:flutter/src/rendering/object.dart

// class id: 1049410, size: 0x8
class :: {
}

// class id: 2016, size: 0x1c, field offset: 0x8
class _SemanticsGeometry extends Object {

  late Rect _rect; // offset: 0x14
  late Matrix4 _transform; // offset: 0x10
  static late final Matrix4 _temporaryTransformHolder; // offset: 0xec0

  get _ dropFromTree(/* No info */) {
    // ** addr: 0xd02ab0, size: 0xa0
    // 0xd02ab0: EnterFrame
    //     0xd02ab0: stp             fp, lr, [SP, #-0x10]!
    //     0xd02ab4: mov             fp, SP
    // 0xd02ab8: CheckStackOverflow
    //     0xd02ab8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd02abc: cmp             SP, x16
    //     0xd02ac0: b.ls            #0xd02b38
    // 0xd02ac4: ldr             x0, [fp, #0x10]
    // 0xd02ac8: LoadField: r1 = r0->field_13
    //     0xd02ac8: ldur            w1, [x0, #0x13]
    // 0xd02acc: DecompressPointer r1
    //     0xd02acc: add             x1, x1, HEAP, lsl #32
    // 0xd02ad0: r16 = Sentinel
    //     0xd02ad0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xd02ad4: cmp             w1, w16
    // 0xd02ad8: b.eq            #0xd02b40
    // 0xd02adc: LoadField: d0 = r1->field_7
    //     0xd02adc: ldur            d0, [x1, #7]
    // 0xd02ae0: LoadField: d1 = r1->field_17
    //     0xd02ae0: ldur            d1, [x1, #0x17]
    // 0xd02ae4: fcmp            d0, d1
    // 0xd02ae8: b.vs            #0xd02af0
    // 0xd02aec: b.ge            #0xd02b04
    // 0xd02af0: LoadField: d0 = r1->field_f
    //     0xd02af0: ldur            d0, [x1, #0xf]
    // 0xd02af4: LoadField: d1 = r1->field_1f
    //     0xd02af4: ldur            d1, [x1, #0x1f]
    // 0xd02af8: fcmp            d0, d1
    // 0xd02afc: b.vs            #0xd02b0c
    // 0xd02b00: b.lt            #0xd02b0c
    // 0xd02b04: r0 = true
    //     0xd02b04: add             x0, NULL, #0x20  ; true
    // 0xd02b08: b               #0xd02b2c
    // 0xd02b0c: LoadField: r1 = r0->field_f
    //     0xd02b0c: ldur            w1, [x0, #0xf]
    // 0xd02b10: DecompressPointer r1
    //     0xd02b10: add             x1, x1, HEAP, lsl #32
    // 0xd02b14: r16 = Sentinel
    //     0xd02b14: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xd02b18: cmp             w1, w16
    // 0xd02b1c: b.eq            #0xd02b48
    // 0xd02b20: SaveReg r1
    //     0xd02b20: str             x1, [SP, #-8]!
    // 0xd02b24: r0 = isZero()
    //     0xd02b24: bl              #0xd02b50  ; [package:vector_math/vector_math_64.dart] Matrix4::isZero
    // 0xd02b28: add             SP, SP, #8
    // 0xd02b2c: LeaveFrame
    //     0xd02b2c: mov             SP, fp
    //     0xd02b30: ldp             fp, lr, [SP], #0x10
    // 0xd02b34: ret
    //     0xd02b34: ret             
    // 0xd02b38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02b38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02b3c: b               #0xd02ac4
    // 0xd02b40: r9 = _rect
    //     0xd02b40: ldr             x9, [PP, #0x7320]  ; [pp+0x7320] Field <_SemanticsGeometry@904266271._rect@904266271>: late (offset: 0x14)
    // 0xd02b44: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd02b44: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd02b48: r9 = _transform
    //     0xd02b48: ldr             x9, [PP, #0x7328]  ; [pp+0x7328] Field <_SemanticsGeometry@904266271._transform@904266271>: late (offset: 0x10)
    // 0xd02b4c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd02b4c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _SemanticsGeometry(/* No info */) {
    // ** addr: 0xd02dd8, size: 0x60
    // 0xd02dd8: EnterFrame
    //     0xd02dd8: stp             fp, lr, [SP, #-0x10]!
    //     0xd02ddc: mov             fp, SP
    // 0xd02de0: r1 = Sentinel
    //     0xd02de0: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xd02de4: r0 = false
    //     0xd02de4: add             x0, NULL, #0x30  ; false
    // 0xd02de8: CheckStackOverflow
    //     0xd02de8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd02dec: cmp             SP, x16
    //     0xd02df0: b.ls            #0xd02e30
    // 0xd02df4: ldr             x2, [fp, #0x28]
    // 0xd02df8: StoreField: r2->field_f = r1
    //     0xd02df8: stur            w1, [x2, #0xf]
    // 0xd02dfc: StoreField: r2->field_13 = r1
    //     0xd02dfc: stur            w1, [x2, #0x13]
    // 0xd02e00: StoreField: r2->field_17 = r0
    //     0xd02e00: stur            w0, [x2, #0x17]
    // 0xd02e04: ldr             x16, [fp, #0x10]
    // 0xd02e08: stp             x16, x2, [SP, #-0x10]!
    // 0xd02e0c: ldr             x16, [fp, #0x18]
    // 0xd02e10: ldr             lr, [fp, #0x20]
    // 0xd02e14: stp             lr, x16, [SP, #-0x10]!
    // 0xd02e18: r0 = _computeValues()
    //     0xd02e18: bl              #0xd02e38  ; [package:flutter/src/rendering/object.dart] _SemanticsGeometry::_computeValues
    // 0xd02e1c: add             SP, SP, #0x20
    // 0xd02e20: r0 = Null
    //     0xd02e20: mov             x0, NULL
    // 0xd02e24: LeaveFrame
    //     0xd02e24: mov             SP, fp
    //     0xd02e28: ldp             fp, lr, [SP], #0x10
    // 0xd02e2c: ret
    //     0xd02e2c: ret             
    // 0xd02e30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02e30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02e34: b               #0xd02df4
  }
  _ _computeValues(/* No info */) {
    // ** addr: 0xd02e38, size: 0x744
    // 0xd02e38: EnterFrame
    //     0xd02e38: stp             fp, lr, [SP, #-0x10]!
    //     0xd02e3c: mov             fp, SP
    // 0xd02e40: AllocStack(0x20)
    //     0xd02e40: sub             SP, SP, #0x20
    // 0xd02e44: CheckStackOverflow
    //     0xd02e44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd02e48: cmp             SP, x16
    //     0xd02e4c: b.ls            #0xd03524
    // 0xd02e50: r0 = Matrix4()
    //     0xd02e50: bl              #0x50ace8  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0xd02e54: r4 = 32
    //     0xd02e54: mov             x4, #0x20
    // 0xd02e58: stur            x0, [fp, #-8]
    // 0xd02e5c: r0 = AllocateFloat64Array()
    //     0xd02e5c: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0xd02e60: mov             x1, x0
    // 0xd02e64: ldur            x0, [fp, #-8]
    // 0xd02e68: StoreField: r0->field_7 = r1
    //     0xd02e68: stur            w1, [x0, #7]
    // 0xd02e6c: SaveReg r0
    //     0xd02e6c: str             x0, [SP, #-8]!
    // 0xd02e70: r0 = setIdentity()
    //     0xd02e70: bl              #0x50f090  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0xd02e74: add             SP, SP, #8
    // 0xd02e78: ldur            x0, [fp, #-8]
    // 0xd02e7c: ldr             x2, [fp, #0x28]
    // 0xd02e80: StoreField: r2->field_f = r0
    //     0xd02e80: stur            w0, [x2, #0xf]
    //     0xd02e84: ldurb           w16, [x2, #-1]
    //     0xd02e88: ldurb           w17, [x0, #-1]
    //     0xd02e8c: and             x16, x17, x16, lsr #2
    //     0xd02e90: tst             x16, HEAP, lsr #32
    //     0xd02e94: b.eq            #0xd02e9c
    //     0xd02e98: bl              #0xd6828c
    // 0xd02e9c: ldr             x0, [fp, #0x20]
    // 0xd02ea0: StoreField: r2->field_b = r0
    //     0xd02ea0: stur            w0, [x2, #0xb]
    //     0xd02ea4: ldurb           w16, [x2, #-1]
    //     0xd02ea8: ldurb           w17, [x0, #-1]
    //     0xd02eac: and             x16, x17, x16, lsr #2
    //     0xd02eb0: tst             x16, HEAP, lsr #32
    //     0xd02eb4: b.eq            #0xd02ebc
    //     0xd02eb8: bl              #0xd6828c
    // 0xd02ebc: ldr             x0, [fp, #0x18]
    // 0xd02ec0: StoreField: r2->field_7 = r0
    //     0xd02ec0: stur            w0, [x2, #7]
    //     0xd02ec4: ldurb           w16, [x2, #-1]
    //     0xd02ec8: ldurb           w17, [x0, #-1]
    //     0xd02ecc: and             x16, x17, x16, lsr #2
    //     0xd02ed0: tst             x16, HEAP, lsr #32
    //     0xd02ed4: b.eq            #0xd02edc
    //     0xd02ed8: bl              #0xd6828c
    // 0xd02edc: ldr             x3, [fp, #0x10]
    // 0xd02ee0: LoadField: r0 = r3->field_b
    //     0xd02ee0: ldur            w0, [x3, #0xb]
    // 0xd02ee4: DecompressPointer r0
    //     0xd02ee4: add             x0, x0, HEAP, lsl #32
    // 0xd02ee8: r1 = LoadInt32Instr(r0)
    //     0xd02ee8: sbfx            x1, x0, #1, #0x1f
    // 0xd02eec: sub             x0, x1, #1
    // 0xd02ef0: mov             x4, x0
    // 0xd02ef4: CheckStackOverflow
    //     0xd02ef4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd02ef8: cmp             SP, x16
    //     0xd02efc: b.ls            #0xd0352c
    // 0xd02f00: cmp             x4, #0
    // 0xd02f04: b.le            #0xd0339c
    // 0xd02f08: LoadField: r0 = r3->field_b
    //     0xd02f08: ldur            w0, [x3, #0xb]
    // 0xd02f0c: DecompressPointer r0
    //     0xd02f0c: add             x0, x0, HEAP, lsl #32
    // 0xd02f10: r5 = LoadInt32Instr(r0)
    //     0xd02f10: sbfx            x5, x0, #1, #0x1f
    // 0xd02f14: mov             x0, x5
    // 0xd02f18: mov             x1, x4
    // 0xd02f1c: cmp             x1, x0
    // 0xd02f20: b.hs            #0xd03534
    // 0xd02f24: LoadField: r6 = r3->field_f
    //     0xd02f24: ldur            w6, [x3, #0xf]
    // 0xd02f28: DecompressPointer r6
    //     0xd02f28: add             x6, x6, HEAP, lsl #32
    // 0xd02f2c: ArrayLoad: r7 = r6[r4]  ; Unknown_4
    //     0xd02f2c: add             x16, x6, x4, lsl #2
    //     0xd02f30: ldur            w7, [x16, #0xf]
    // 0xd02f34: DecompressPointer r7
    //     0xd02f34: add             x7, x7, HEAP, lsl #32
    // 0xd02f38: stur            x7, [fp, #-0x18]
    // 0xd02f3c: sub             x8, x4, #1
    // 0xd02f40: mov             x0, x5
    // 0xd02f44: mov             x1, x8
    // 0xd02f48: stur            x8, [fp, #-0x10]
    // 0xd02f4c: cmp             x1, x0
    // 0xd02f50: b.hs            #0xd03538
    // 0xd02f54: ArrayLoad: r1 = r6[r8]  ; Unknown_4
    //     0xd02f54: add             x16, x6, x8, lsl #2
    //     0xd02f58: ldur            w1, [x16, #0xf]
    // 0xd02f5c: DecompressPointer r1
    //     0xd02f5c: add             x1, x1, HEAP, lsl #32
    // 0xd02f60: stur            x1, [fp, #-8]
    // 0xd02f64: r0 = LoadClassIdInstr(r7)
    //     0xd02f64: ldur            x0, [x7, #-1]
    //     0xd02f68: ubfx            x0, x0, #0xc, #0x14
    // 0xd02f6c: stp             x1, x7, [SP, #-0x10]!
    // 0xd02f70: r0 = GDT[cid_x0 + 0xebed]()
    //     0xd02f70: mov             x17, #0xebed
    //     0xd02f74: add             lr, x0, x17
    //     0xd02f78: ldr             lr, [x21, lr, lsl #3]
    //     0xd02f7c: blr             lr
    // 0xd02f80: add             SP, SP, #0x10
    // 0xd02f84: cmp             w0, NULL
    // 0xd02f88: b.eq            #0xd03030
    // 0xd02f8c: ldr             x1, [fp, #0x28]
    // 0xd02f90: ldur            x2, [fp, #-0x18]
    // 0xd02f94: StoreField: r1->field_b = r0
    //     0xd02f94: stur            w0, [x1, #0xb]
    //     0xd02f98: ldurb           w16, [x1, #-1]
    //     0xd02f9c: ldurb           w17, [x0, #-1]
    //     0xd02fa0: and             x16, x17, x16, lsr #2
    //     0xd02fa4: tst             x16, HEAP, lsr #32
    //     0xd02fa8: b.eq            #0xd02fb0
    //     0xd02fac: bl              #0xd6826c
    // 0xd02fb0: LoadField: r3 = r1->field_7
    //     0xd02fb0: ldur            w3, [x1, #7]
    // 0xd02fb4: DecompressPointer r3
    //     0xd02fb4: add             x3, x3, HEAP, lsl #32
    // 0xd02fb8: stur            x3, [fp, #-0x20]
    // 0xd02fbc: r0 = LoadClassIdInstr(r2)
    //     0xd02fbc: ldur            x0, [x2, #-1]
    //     0xd02fc0: ubfx            x0, x0, #0xc, #0x14
    // 0xd02fc4: ldur            x16, [fp, #-8]
    // 0xd02fc8: stp             x16, x2, [SP, #-0x10]!
    // 0xd02fcc: r0 = GDT[cid_x0 + 0xe5f5]()
    //     0xd02fcc: mov             x17, #0xe5f5
    //     0xd02fd0: add             lr, x0, x17
    //     0xd02fd4: ldr             lr, [x21, lr, lsl #3]
    //     0xd02fd8: blr             lr
    // 0xd02fdc: add             SP, SP, #0x10
    // 0xd02fe0: mov             x1, x0
    // 0xd02fe4: ldur            x0, [fp, #-0x20]
    // 0xd02fe8: cmp             w0, NULL
    // 0xd02fec: b.ne            #0xd02ff8
    // 0xd02ff0: mov             x0, x1
    // 0xd02ff4: b               #0xd0300c
    // 0xd02ff8: cmp             w1, NULL
    // 0xd02ffc: b.eq            #0xd0300c
    // 0xd03000: stp             x1, x0, [SP, #-0x10]!
    // 0xd03004: r0 = intersect()
    //     0xd03004: bl              #0x642ca8  ; [dart:ui] Rect::intersect
    // 0xd03008: add             SP, SP, #0x10
    // 0xd0300c: ldr             x1, [fp, #0x28]
    // 0xd03010: StoreField: r1->field_7 = r0
    //     0xd03010: stur            w0, [x1, #7]
    //     0xd03014: ldurb           w16, [x1, #-1]
    //     0xd03018: ldurb           w17, [x0, #-1]
    //     0xd0301c: and             x16, x17, x16, lsr #2
    //     0xd03020: tst             x16, HEAP, lsr #32
    //     0xd03024: b.eq            #0xd0302c
    //     0xd03028: bl              #0xd6826c
    // 0xd0302c: b               #0xd030b4
    // 0xd03030: ldr             x1, [fp, #0x28]
    // 0xd03034: ldur            x2, [fp, #-0x18]
    // 0xd03038: LoadField: r3 = r1->field_b
    //     0xd03038: ldur            w3, [x1, #0xb]
    // 0xd0303c: DecompressPointer r3
    //     0xd0303c: add             x3, x3, HEAP, lsl #32
    // 0xd03040: stur            x3, [fp, #-0x20]
    // 0xd03044: r0 = LoadClassIdInstr(r2)
    //     0xd03044: ldur            x0, [x2, #-1]
    //     0xd03048: ubfx            x0, x0, #0xc, #0x14
    // 0xd0304c: ldur            x16, [fp, #-8]
    // 0xd03050: stp             x16, x2, [SP, #-0x10]!
    // 0xd03054: r0 = GDT[cid_x0 + 0xe5f5]()
    //     0xd03054: mov             x17, #0xe5f5
    //     0xd03058: add             lr, x0, x17
    //     0xd0305c: ldr             lr, [x21, lr, lsl #3]
    //     0xd03060: blr             lr
    // 0xd03064: add             SP, SP, #0x10
    // 0xd03068: mov             x1, x0
    // 0xd0306c: ldur            x0, [fp, #-0x20]
    // 0xd03070: cmp             w0, NULL
    // 0xd03074: b.ne            #0xd03080
    // 0xd03078: mov             x0, x1
    // 0xd0307c: b               #0xd03094
    // 0xd03080: cmp             w1, NULL
    // 0xd03084: b.eq            #0xd03094
    // 0xd03088: stp             x1, x0, [SP, #-0x10]!
    // 0xd0308c: r0 = intersect()
    //     0xd0308c: bl              #0x642ca8  ; [dart:ui] Rect::intersect
    // 0xd03090: add             SP, SP, #0x10
    // 0xd03094: ldr             x1, [fp, #0x28]
    // 0xd03098: StoreField: r1->field_b = r0
    //     0xd03098: stur            w0, [x1, #0xb]
    //     0xd0309c: ldurb           w16, [x1, #-1]
    //     0xd030a0: ldurb           w17, [x0, #-1]
    //     0xd030a4: and             x16, x17, x16, lsr #2
    //     0xd030a8: tst             x16, HEAP, lsr #32
    //     0xd030ac: b.eq            #0xd030b4
    //     0xd030b0: bl              #0xd6826c
    // 0xd030b4: r0 = InitLateStaticField(0xec0) // [package:flutter/src/rendering/object.dart] _SemanticsGeometry::_temporaryTransformHolder
    //     0xd030b4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd030b8: ldr             x0, [x0, #0x1d80]
    //     0xd030bc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd030c0: cmp             w0, w16
    //     0xd030c4: b.ne            #0xd030d0
    //     0xd030c8: ldr             x2, [PP, #0x7340]  ; [pp+0x7340] Field <_SemanticsGeometry@904266271._temporaryTransformHolder@904266271>: static late final (offset: 0xec0)
    //     0xd030cc: bl              #0xd67cdc
    // 0xd030d0: mov             x2, x0
    // 0xd030d4: stur            x2, [fp, #-0x20]
    // 0xd030d8: LoadField: r3 = r2->field_7
    //     0xd030d8: ldur            w3, [x2, #7]
    // 0xd030dc: DecompressPointer r3
    //     0xd030dc: add             x3, x3, HEAP, lsl #32
    // 0xd030e0: LoadField: r0 = r3->field_13
    //     0xd030e0: ldur            w0, [x3, #0x13]
    // 0xd030e4: DecompressPointer r0
    //     0xd030e4: add             x0, x0, HEAP, lsl #32
    // 0xd030e8: r4 = LoadInt32Instr(r0)
    //     0xd030e8: sbfx            x4, x0, #1, #0x1f
    // 0xd030ec: mov             x0, x4
    // 0xd030f0: r1 = 0
    //     0xd030f0: mov             x1, #0
    // 0xd030f4: cmp             x1, x0
    // 0xd030f8: b.hs            #0xd0353c
    // 0xd030fc: d0 = 1.000000
    //     0xd030fc: fmov            d0, #1.00000000
    // 0xd03100: StoreField: r3->field_17 = d0
    //     0xd03100: stur            d0, [x3, #0x17]
    // 0xd03104: mov             x0, x4
    // 0xd03108: r1 = 1
    //     0xd03108: mov             x1, #1
    // 0xd0310c: cmp             x1, x0
    // 0xd03110: b.hs            #0xd03540
    // 0xd03114: StoreField: r3->field_1f = rZR
    //     0xd03114: stur            xzr, [x3, #0x1f]
    // 0xd03118: mov             x0, x4
    // 0xd0311c: r1 = 2
    //     0xd0311c: mov             x1, #2
    // 0xd03120: cmp             x1, x0
    // 0xd03124: b.hs            #0xd03544
    // 0xd03128: StoreField: r3->field_27 = rZR
    //     0xd03128: stur            xzr, [x3, #0x27]
    // 0xd0312c: mov             x0, x4
    // 0xd03130: r1 = 3
    //     0xd03130: mov             x1, #3
    // 0xd03134: cmp             x1, x0
    // 0xd03138: b.hs            #0xd03548
    // 0xd0313c: StoreField: r3->field_2f = rZR
    //     0xd0313c: stur            xzr, [x3, #0x2f]
    // 0xd03140: mov             x0, x4
    // 0xd03144: r1 = 4
    //     0xd03144: mov             x1, #4
    // 0xd03148: cmp             x1, x0
    // 0xd0314c: b.hs            #0xd0354c
    // 0xd03150: StoreField: r3->field_37 = rZR
    //     0xd03150: stur            xzr, [x3, #0x37]
    // 0xd03154: mov             x0, x4
    // 0xd03158: r1 = 5
    //     0xd03158: mov             x1, #5
    // 0xd0315c: cmp             x1, x0
    // 0xd03160: b.hs            #0xd03550
    // 0xd03164: StoreField: r3->field_3f = d0
    //     0xd03164: stur            d0, [x3, #0x3f]
    // 0xd03168: mov             x0, x4
    // 0xd0316c: r1 = 6
    //     0xd0316c: mov             x1, #6
    // 0xd03170: cmp             x1, x0
    // 0xd03174: b.hs            #0xd03554
    // 0xd03178: StoreField: r3->field_47 = rZR
    //     0xd03178: stur            xzr, [x3, #0x47]
    // 0xd0317c: mov             x0, x4
    // 0xd03180: r1 = 7
    //     0xd03180: mov             x1, #7
    // 0xd03184: cmp             x1, x0
    // 0xd03188: b.hs            #0xd03558
    // 0xd0318c: StoreField: r3->field_4f = rZR
    //     0xd0318c: stur            xzr, [x3, #0x4f]
    // 0xd03190: mov             x0, x4
    // 0xd03194: r1 = 8
    //     0xd03194: mov             x1, #8
    // 0xd03198: cmp             x1, x0
    // 0xd0319c: b.hs            #0xd0355c
    // 0xd031a0: StoreField: r3->field_57 = rZR
    //     0xd031a0: stur            xzr, [x3, #0x57]
    // 0xd031a4: mov             x0, x4
    // 0xd031a8: r1 = 9
    //     0xd031a8: mov             x1, #9
    // 0xd031ac: cmp             x1, x0
    // 0xd031b0: b.hs            #0xd03560
    // 0xd031b4: StoreField: r3->field_5f = rZR
    //     0xd031b4: stur            xzr, [x3, #0x5f]
    // 0xd031b8: mov             x0, x4
    // 0xd031bc: r1 = 10
    //     0xd031bc: mov             x1, #0xa
    // 0xd031c0: cmp             x1, x0
    // 0xd031c4: b.hs            #0xd03564
    // 0xd031c8: StoreField: r3->field_67 = d0
    //     0xd031c8: stur            d0, [x3, #0x67]
    // 0xd031cc: mov             x0, x4
    // 0xd031d0: r1 = 11
    //     0xd031d0: mov             x1, #0xb
    // 0xd031d4: cmp             x1, x0
    // 0xd031d8: b.hs            #0xd03568
    // 0xd031dc: StoreField: r3->field_6f = rZR
    //     0xd031dc: stur            xzr, [x3, #0x6f]
    // 0xd031e0: mov             x0, x4
    // 0xd031e4: r1 = 12
    //     0xd031e4: mov             x1, #0xc
    // 0xd031e8: cmp             x1, x0
    // 0xd031ec: b.hs            #0xd0356c
    // 0xd031f0: StoreField: r3->field_77 = rZR
    //     0xd031f0: stur            xzr, [x3, #0x77]
    // 0xd031f4: mov             x0, x4
    // 0xd031f8: r1 = 13
    //     0xd031f8: mov             x1, #0xd
    // 0xd031fc: cmp             x1, x0
    // 0xd03200: b.hs            #0xd03570
    // 0xd03204: StoreField: r3->field_7f = rZR
    //     0xd03204: stur            xzr, [x3, #0x7f]
    // 0xd03208: mov             x0, x4
    // 0xd0320c: r1 = 14
    //     0xd0320c: mov             x1, #0xe
    // 0xd03210: cmp             x1, x0
    // 0xd03214: b.hs            #0xd03574
    // 0xd03218: StoreField: r3->field_87 = rZR
    //     0xd03218: stur            xzr, [x3, #0x87]
    // 0xd0321c: mov             x0, x4
    // 0xd03220: r1 = 15
    //     0xd03220: mov             x1, #0xf
    // 0xd03224: cmp             x1, x0
    // 0xd03228: b.hs            #0xd03578
    // 0xd0322c: StoreField: r3->field_8f = d0
    //     0xd0322c: stur            d0, [x3, #0x8f]
    // 0xd03230: ldr             x0, [fp, #0x28]
    // 0xd03234: LoadField: r1 = r0->field_f
    //     0xd03234: ldur            w1, [x0, #0xf]
    // 0xd03238: DecompressPointer r1
    //     0xd03238: add             x1, x1, HEAP, lsl #32
    // 0xd0323c: ldur            x16, [fp, #-0x18]
    // 0xd03240: ldur            lr, [fp, #-8]
    // 0xd03244: stp             lr, x16, [SP, #-0x10]!
    // 0xd03248: stp             x2, x1, [SP, #-0x10]!
    // 0xd0324c: r0 = _applyIntermediatePaintTransforms()
    //     0xd0324c: bl              #0xd0357c  ; [package:flutter/src/rendering/object.dart] _SemanticsGeometry::_applyIntermediatePaintTransforms
    // 0xd03250: add             SP, SP, #0x20
    // 0xd03254: ldr             x0, [fp, #0x28]
    // 0xd03258: LoadField: r1 = r0->field_b
    //     0xd03258: ldur            w1, [x0, #0xb]
    // 0xd0325c: DecompressPointer r1
    //     0xd0325c: add             x1, x1, HEAP, lsl #32
    // 0xd03260: stur            x1, [fp, #-8]
    // 0xd03264: cmp             w1, NULL
    // 0xd03268: b.ne            #0xd03278
    // 0xd0326c: mov             x1, x0
    // 0xd03270: r0 = Null
    //     0xd03270: mov             x0, NULL
    // 0xd03274: b               #0xd032d8
    // 0xd03278: LoadField: d0 = r1->field_7
    //     0xd03278: ldur            d0, [x1, #7]
    // 0xd0327c: LoadField: d1 = r1->field_17
    //     0xd0327c: ldur            d1, [x1, #0x17]
    // 0xd03280: fcmp            d0, d1
    // 0xd03284: b.vs            #0xd0328c
    // 0xd03288: b.ge            #0xd032b4
    // 0xd0328c: LoadField: d0 = r1->field_f
    //     0xd0328c: ldur            d0, [x1, #0xf]
    // 0xd03290: LoadField: d1 = r1->field_1f
    //     0xd03290: ldur            d1, [x1, #0x1f]
    // 0xd03294: fcmp            d0, d1
    // 0xd03298: b.vs            #0xd032a0
    // 0xd0329c: b.ge            #0xd032b4
    // 0xd032a0: ldur            x16, [fp, #-0x20]
    // 0xd032a4: SaveReg r16
    //     0xd032a4: str             x16, [SP, #-8]!
    // 0xd032a8: r0 = isZero()
    //     0xd032a8: bl              #0xd02b50  ; [package:vector_math/vector_math_64.dart] Matrix4::isZero
    // 0xd032ac: add             SP, SP, #8
    // 0xd032b0: tbnz            w0, #4, #0xd032c0
    // 0xd032b4: ldr             x1, [fp, #0x28]
    // 0xd032b8: r0 = Instance_Rect
    //     0xd032b8: ldr             x0, [PP, #0x5e48]  ; [pp+0x5e48] Obj!Rect@b5ebc1
    // 0xd032bc: b               #0xd032d8
    // 0xd032c0: ldur            x16, [fp, #-0x20]
    // 0xd032c4: ldur            lr, [fp, #-8]
    // 0xd032c8: stp             lr, x16, [SP, #-0x10]!
    // 0xd032cc: r0 = inverseTransformRect()
    //     0xd032cc: bl              #0x65d3dc  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::inverseTransformRect
    // 0xd032d0: add             SP, SP, #0x10
    // 0xd032d4: ldr             x1, [fp, #0x28]
    // 0xd032d8: StoreField: r1->field_b = r0
    //     0xd032d8: stur            w0, [x1, #0xb]
    //     0xd032dc: ldurb           w16, [x1, #-1]
    //     0xd032e0: ldurb           w17, [x0, #-1]
    //     0xd032e4: and             x16, x17, x16, lsr #2
    //     0xd032e8: tst             x16, HEAP, lsr #32
    //     0xd032ec: b.eq            #0xd032f4
    //     0xd032f0: bl              #0xd6826c
    // 0xd032f4: LoadField: r0 = r1->field_7
    //     0xd032f4: ldur            w0, [x1, #7]
    // 0xd032f8: DecompressPointer r0
    //     0xd032f8: add             x0, x0, HEAP, lsl #32
    // 0xd032fc: stur            x0, [fp, #-8]
    // 0xd03300: cmp             w0, NULL
    // 0xd03304: b.ne            #0xd03310
    // 0xd03308: r0 = Null
    //     0xd03308: mov             x0, NULL
    // 0xd0330c: b               #0xd03370
    // 0xd03310: LoadField: d0 = r0->field_7
    //     0xd03310: ldur            d0, [x0, #7]
    // 0xd03314: LoadField: d1 = r0->field_17
    //     0xd03314: ldur            d1, [x0, #0x17]
    // 0xd03318: fcmp            d0, d1
    // 0xd0331c: b.vs            #0xd03324
    // 0xd03320: b.ge            #0xd0334c
    // 0xd03324: LoadField: d0 = r0->field_f
    //     0xd03324: ldur            d0, [x0, #0xf]
    // 0xd03328: LoadField: d1 = r0->field_1f
    //     0xd03328: ldur            d1, [x0, #0x1f]
    // 0xd0332c: fcmp            d0, d1
    // 0xd03330: b.vs            #0xd03338
    // 0xd03334: b.ge            #0xd0334c
    // 0xd03338: ldur            x16, [fp, #-0x20]
    // 0xd0333c: SaveReg r16
    //     0xd0333c: str             x16, [SP, #-8]!
    // 0xd03340: r0 = isZero()
    //     0xd03340: bl              #0xd02b50  ; [package:vector_math/vector_math_64.dart] Matrix4::isZero
    // 0xd03344: add             SP, SP, #8
    // 0xd03348: tbnz            w0, #4, #0xd03358
    // 0xd0334c: ldr             x1, [fp, #0x28]
    // 0xd03350: r0 = Instance_Rect
    //     0xd03350: ldr             x0, [PP, #0x5e48]  ; [pp+0x5e48] Obj!Rect@b5ebc1
    // 0xd03354: b               #0xd03370
    // 0xd03358: ldur            x16, [fp, #-0x20]
    // 0xd0335c: ldur            lr, [fp, #-8]
    // 0xd03360: stp             lr, x16, [SP, #-0x10]!
    // 0xd03364: r0 = inverseTransformRect()
    //     0xd03364: bl              #0x65d3dc  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::inverseTransformRect
    // 0xd03368: add             SP, SP, #0x10
    // 0xd0336c: ldr             x1, [fp, #0x28]
    // 0xd03370: StoreField: r1->field_7 = r0
    //     0xd03370: stur            w0, [x1, #7]
    //     0xd03374: ldurb           w16, [x1, #-1]
    //     0xd03378: ldurb           w17, [x0, #-1]
    //     0xd0337c: and             x16, x17, x16, lsr #2
    //     0xd03380: tst             x16, HEAP, lsr #32
    //     0xd03384: b.eq            #0xd0338c
    //     0xd03388: bl              #0xd6826c
    // 0xd0338c: ldur            x4, [fp, #-0x10]
    // 0xd03390: mov             x2, x1
    // 0xd03394: ldr             x3, [fp, #0x10]
    // 0xd03398: b               #0xd02ef4
    // 0xd0339c: mov             x1, x2
    // 0xd033a0: ldr             x16, [fp, #0x10]
    // 0xd033a4: SaveReg r16
    //     0xd033a4: str             x16, [SP, #-8]!
    // 0xd033a8: r0 = first()
    //     0xd033a8: bl              #0x7192e8  ; [dart:core] _GrowableList::first
    // 0xd033ac: add             SP, SP, #8
    // 0xd033b0: ldr             x1, [fp, #0x28]
    // 0xd033b4: LoadField: r2 = r1->field_b
    //     0xd033b4: ldur            w2, [x1, #0xb]
    // 0xd033b8: DecompressPointer r2
    //     0xd033b8: add             x2, x2, HEAP, lsl #32
    // 0xd033bc: stur            x2, [fp, #-8]
    // 0xd033c0: cmp             w2, NULL
    // 0xd033c4: b.ne            #0xd033f4
    // 0xd033c8: r2 = LoadClassIdInstr(r0)
    //     0xd033c8: ldur            x2, [x0, #-1]
    //     0xd033cc: ubfx            x2, x2, #0xc, #0x14
    // 0xd033d0: SaveReg r0
    //     0xd033d0: str             x0, [SP, #-8]!
    // 0xd033d4: mov             x0, x2
    // 0xd033d8: r0 = GDT[cid_x0 + 0xd953]()
    //     0xd033d8: mov             x17, #0xd953
    //     0xd033dc: add             lr, x0, x17
    //     0xd033e0: ldr             lr, [x21, lr, lsl #3]
    //     0xd033e4: blr             lr
    // 0xd033e8: add             SP, SP, #8
    // 0xd033ec: mov             x2, x0
    // 0xd033f0: b               #0xd0342c
    // 0xd033f4: r1 = LoadClassIdInstr(r0)
    //     0xd033f4: ldur            x1, [x0, #-1]
    //     0xd033f8: ubfx            x1, x1, #0xc, #0x14
    // 0xd033fc: SaveReg r0
    //     0xd033fc: str             x0, [SP, #-8]!
    // 0xd03400: mov             x0, x1
    // 0xd03404: r0 = GDT[cid_x0 + 0xd953]()
    //     0xd03404: mov             x17, #0xd953
    //     0xd03408: add             lr, x0, x17
    //     0xd0340c: ldr             lr, [x21, lr, lsl #3]
    //     0xd03410: blr             lr
    // 0xd03414: add             SP, SP, #8
    // 0xd03418: ldur            x16, [fp, #-8]
    // 0xd0341c: stp             x0, x16, [SP, #-0x10]!
    // 0xd03420: r0 = intersect()
    //     0xd03420: bl              #0x642ca8  ; [dart:ui] Rect::intersect
    // 0xd03424: add             SP, SP, #0x10
    // 0xd03428: mov             x2, x0
    // 0xd0342c: ldr             x1, [fp, #0x28]
    // 0xd03430: mov             x0, x2
    // 0xd03434: StoreField: r1->field_13 = r0
    //     0xd03434: stur            w0, [x1, #0x13]
    //     0xd03438: ldurb           w16, [x1, #-1]
    //     0xd0343c: ldurb           w17, [x0, #-1]
    //     0xd03440: and             x16, x17, x16, lsr #2
    //     0xd03444: tst             x16, HEAP, lsr #32
    //     0xd03448: b.eq            #0xd03450
    //     0xd0344c: bl              #0xd6826c
    // 0xd03450: LoadField: r0 = r1->field_7
    //     0xd03450: ldur            w0, [x1, #7]
    // 0xd03454: DecompressPointer r0
    //     0xd03454: add             x0, x0, HEAP, lsl #32
    // 0xd03458: cmp             w0, NULL
    // 0xd0345c: b.eq            #0xd03514
    // 0xd03460: stp             x2, x0, [SP, #-0x10]!
    // 0xd03464: r0 = intersect()
    //     0xd03464: bl              #0x642ca8  ; [dart:ui] Rect::intersect
    // 0xd03468: add             SP, SP, #0x10
    // 0xd0346c: LoadField: d0 = r0->field_7
    //     0xd0346c: ldur            d0, [x0, #7]
    // 0xd03470: LoadField: d1 = r0->field_17
    //     0xd03470: ldur            d1, [x0, #0x17]
    // 0xd03474: fcmp            d0, d1
    // 0xd03478: b.vs            #0xd03480
    // 0xd0347c: b.ge            #0xd03494
    // 0xd03480: LoadField: d0 = r0->field_f
    //     0xd03480: ldur            d0, [x0, #0xf]
    // 0xd03484: LoadField: d1 = r0->field_1f
    //     0xd03484: ldur            d1, [x0, #0x1f]
    // 0xd03488: fcmp            d0, d1
    // 0xd0348c: b.vs            #0xd034e8
    // 0xd03490: b.lt            #0xd034e8
    // 0xd03494: ldr             x1, [fp, #0x28]
    // 0xd03498: LoadField: r2 = r1->field_13
    //     0xd03498: ldur            w2, [x1, #0x13]
    // 0xd0349c: DecompressPointer r2
    //     0xd0349c: add             x2, x2, HEAP, lsl #32
    // 0xd034a0: LoadField: d0 = r2->field_7
    //     0xd034a0: ldur            d0, [x2, #7]
    // 0xd034a4: LoadField: d1 = r2->field_17
    //     0xd034a4: ldur            d1, [x2, #0x17]
    // 0xd034a8: fcmp            d0, d1
    // 0xd034ac: b.vs            #0xd034bc
    // 0xd034b0: b.lt            #0xd034bc
    // 0xd034b4: r2 = true
    //     0xd034b4: add             x2, NULL, #0x20  ; true
    // 0xd034b8: b               #0xd034dc
    // 0xd034bc: LoadField: d0 = r2->field_f
    //     0xd034bc: ldur            d0, [x2, #0xf]
    // 0xd034c0: LoadField: d1 = r2->field_1f
    //     0xd034c0: ldur            d1, [x2, #0x1f]
    // 0xd034c4: fcmp            d0, d1
    // 0xd034c8: b.vs            #0xd034d0
    // 0xd034cc: b.ge            #0xd034d8
    // 0xd034d0: r2 = false
    //     0xd034d0: add             x2, NULL, #0x30  ; false
    // 0xd034d4: b               #0xd034dc
    // 0xd034d8: r2 = true
    //     0xd034d8: add             x2, NULL, #0x20  ; true
    // 0xd034dc: eor             x3, x2, #0x10
    // 0xd034e0: mov             x2, x3
    // 0xd034e4: b               #0xd034f0
    // 0xd034e8: ldr             x1, [fp, #0x28]
    // 0xd034ec: r2 = false
    //     0xd034ec: add             x2, NULL, #0x30  ; false
    // 0xd034f0: StoreField: r1->field_17 = r2
    //     0xd034f0: stur            w2, [x1, #0x17]
    // 0xd034f4: tbz             w2, #4, #0xd03514
    // 0xd034f8: StoreField: r1->field_13 = r0
    //     0xd034f8: stur            w0, [x1, #0x13]
    //     0xd034fc: ldurb           w16, [x1, #-1]
    //     0xd03500: ldurb           w17, [x0, #-1]
    //     0xd03504: and             x16, x17, x16, lsr #2
    //     0xd03508: tst             x16, HEAP, lsr #32
    //     0xd0350c: b.eq            #0xd03514
    //     0xd03510: bl              #0xd6826c
    // 0xd03514: r0 = Null
    //     0xd03514: mov             x0, NULL
    // 0xd03518: LeaveFrame
    //     0xd03518: mov             SP, fp
    //     0xd0351c: ldp             fp, lr, [SP], #0x10
    // 0xd03520: ret
    //     0xd03520: ret             
    // 0xd03524: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03524: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03528: b               #0xd02e50
    // 0xd0352c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0352c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03530: b               #0xd02f00
    // 0xd03534: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd03534: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd03538: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd03538: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd0353c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd0353c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd03540: r0 = RangeErrorSharedWithFPURegs()
    //     0xd03540: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd03544: r0 = RangeErrorSharedWithFPURegs()
    //     0xd03544: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd03548: r0 = RangeErrorSharedWithFPURegs()
    //     0xd03548: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd0354c: r0 = RangeErrorSharedWithFPURegs()
    //     0xd0354c: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd03550: r0 = RangeErrorSharedWithFPURegs()
    //     0xd03550: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd03554: r0 = RangeErrorSharedWithFPURegs()
    //     0xd03554: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd03558: r0 = RangeErrorSharedWithFPURegs()
    //     0xd03558: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd0355c: r0 = RangeErrorSharedWithFPURegs()
    //     0xd0355c: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd03560: r0 = RangeErrorSharedWithFPURegs()
    //     0xd03560: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd03564: r0 = RangeErrorSharedWithFPURegs()
    //     0xd03564: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd03568: r0 = RangeErrorSharedWithFPURegs()
    //     0xd03568: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd0356c: r0 = RangeErrorSharedWithFPURegs()
    //     0xd0356c: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd03570: r0 = RangeErrorSharedWithFPURegs()
    //     0xd03570: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd03574: r0 = RangeErrorSharedWithFPURegs()
    //     0xd03574: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd03578: r0 = RangeErrorSharedWithFPURegs()
    //     0xd03578: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
  }
  static _ _applyIntermediatePaintTransforms(/* No info */) {
    // ** addr: 0xd0357c, size: 0x228
    // 0xd0357c: EnterFrame
    //     0xd0357c: stp             fp, lr, [SP, #-0x10]!
    //     0xd03580: mov             fp, SP
    // 0xd03584: AllocStack(0x18)
    //     0xd03584: sub             SP, SP, #0x18
    // 0xd03588: CheckStackOverflow
    //     0xd03588: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd0358c: cmp             SP, x16
    //     0xd03590: b.ls            #0xd03788
    // 0xd03594: ldr             x1, [fp, #0x20]
    // 0xd03598: r0 = LoadClassIdInstr(r1)
    //     0xd03598: ldur            x0, [x1, #-1]
    //     0xd0359c: ubfx            x0, x0, #0xc, #0x14
    // 0xd035a0: SaveReg r1
    //     0xd035a0: str             x1, [SP, #-8]!
    // 0xd035a4: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0xd035a4: mov             x17, #0xa2f1
    //     0xd035a8: add             lr, x0, x17
    //     0xd035ac: ldr             lr, [x21, lr, lsl #3]
    //     0xd035b0: blr             lr
    // 0xd035b4: add             SP, SP, #8
    // 0xd035b8: mov             x3, x0
    // 0xd035bc: stur            x3, [fp, #-8]
    // 0xd035c0: cmp             w3, NULL
    // 0xd035c4: b.eq            #0xd03790
    // 0xd035c8: mov             x0, x3
    // 0xd035cc: r2 = Null
    //     0xd035cc: mov             x2, NULL
    // 0xd035d0: r1 = Null
    //     0xd035d0: mov             x1, NULL
    // 0xd035d4: r4 = LoadClassIdInstr(r0)
    //     0xd035d4: ldur            x4, [x0, #-1]
    //     0xd035d8: ubfx            x4, x4, #0xc, #0x14
    // 0xd035dc: sub             x4, x4, #0x961
    // 0xd035e0: cmp             x4, #0xbe
    // 0xd035e4: b.ls            #0xd035f4
    // 0xd035e8: r8 = RenderObject
    //     0xd035e8: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0xd035ec: r3 = Null
    //     0xd035ec: ldr             x3, [PP, #0x7350]  ; [pp+0x7350] Null
    // 0xd035f0: r0 = RenderObject()
    //     0xd035f0: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0xd035f4: ldr             x3, [fp, #0x20]
    // 0xd035f8: ldur            x2, [fp, #-8]
    // 0xd035fc: ldr             x1, [fp, #0x28]
    // 0xd03600: stur            x3, [fp, #-8]
    // 0xd03604: stur            x2, [fp, #-0x10]
    // 0xd03608: CheckStackOverflow
    //     0xd03608: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd0360c: cmp             SP, x16
    //     0xd03610: b.ls            #0xd03794
    // 0xd03614: cmp             w2, w1
    // 0xd03618: b.eq            #0xd03714
    // 0xd0361c: r0 = LoadClassIdInstr(r2)
    //     0xd0361c: ldur            x0, [x2, #-1]
    //     0xd03620: ubfx            x0, x0, #0xc, #0x14
    // 0xd03624: stp             x3, x2, [SP, #-0x10]!
    // 0xd03628: ldr             x16, [fp, #0x18]
    // 0xd0362c: SaveReg r16
    //     0xd0362c: str             x16, [SP, #-8]!
    // 0xd03630: r0 = GDT[cid_x0 + 0xd590]()
    //     0xd03630: mov             x17, #0xd590
    //     0xd03634: add             lr, x0, x17
    //     0xd03638: ldr             lr, [x21, lr, lsl #3]
    //     0xd0363c: blr             lr
    // 0xd03640: add             SP, SP, #0x18
    // 0xd03644: ldur            x0, [fp, #-0x10]
    // 0xd03648: r1 = LoadClassIdInstr(r0)
    //     0xd03648: ldur            x1, [x0, #-1]
    //     0xd0364c: ubfx            x1, x1, #0xc, #0x14
    // 0xd03650: SaveReg r0
    //     0xd03650: str             x0, [SP, #-8]!
    // 0xd03654: mov             x0, x1
    // 0xd03658: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0xd03658: mov             x17, #0xa2f1
    //     0xd0365c: add             lr, x0, x17
    //     0xd03660: ldr             lr, [x21, lr, lsl #3]
    //     0xd03664: blr             lr
    // 0xd03668: add             SP, SP, #8
    // 0xd0366c: mov             x3, x0
    // 0xd03670: stur            x3, [fp, #-0x10]
    // 0xd03674: cmp             w3, NULL
    // 0xd03678: b.eq            #0xd0379c
    // 0xd0367c: mov             x0, x3
    // 0xd03680: r2 = Null
    //     0xd03680: mov             x2, NULL
    // 0xd03684: r1 = Null
    //     0xd03684: mov             x1, NULL
    // 0xd03688: r4 = LoadClassIdInstr(r0)
    //     0xd03688: ldur            x4, [x0, #-1]
    //     0xd0368c: ubfx            x4, x4, #0xc, #0x14
    // 0xd03690: sub             x4, x4, #0x961
    // 0xd03694: cmp             x4, #0xbe
    // 0xd03698: b.ls            #0xd036a8
    // 0xd0369c: r8 = RenderObject
    //     0xd0369c: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0xd036a0: r3 = Null
    //     0xd036a0: ldr             x3, [PP, #0x7360]  ; [pp+0x7360] Null
    // 0xd036a4: r0 = RenderObject()
    //     0xd036a4: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0xd036a8: ldur            x1, [fp, #-8]
    // 0xd036ac: r0 = LoadClassIdInstr(r1)
    //     0xd036ac: ldur            x0, [x1, #-1]
    //     0xd036b0: ubfx            x0, x0, #0xc, #0x14
    // 0xd036b4: SaveReg r1
    //     0xd036b4: str             x1, [SP, #-8]!
    // 0xd036b8: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0xd036b8: mov             x17, #0xa2f1
    //     0xd036bc: add             lr, x0, x17
    //     0xd036c0: ldr             lr, [x21, lr, lsl #3]
    //     0xd036c4: blr             lr
    // 0xd036c8: add             SP, SP, #8
    // 0xd036cc: mov             x3, x0
    // 0xd036d0: stur            x3, [fp, #-0x18]
    // 0xd036d4: cmp             w3, NULL
    // 0xd036d8: b.eq            #0xd037a0
    // 0xd036dc: mov             x0, x3
    // 0xd036e0: r2 = Null
    //     0xd036e0: mov             x2, NULL
    // 0xd036e4: r1 = Null
    //     0xd036e4: mov             x1, NULL
    // 0xd036e8: r4 = LoadClassIdInstr(r0)
    //     0xd036e8: ldur            x4, [x0, #-1]
    //     0xd036ec: ubfx            x4, x4, #0xc, #0x14
    // 0xd036f0: sub             x4, x4, #0x961
    // 0xd036f4: cmp             x4, #0xbe
    // 0xd036f8: b.ls            #0xd03708
    // 0xd036fc: r8 = RenderObject
    //     0xd036fc: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0xd03700: r3 = Null
    //     0xd03700: ldr             x3, [PP, #0x7370]  ; [pp+0x7370] Null
    // 0xd03704: r0 = RenderObject()
    //     0xd03704: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0xd03708: ldur            x3, [fp, #-0x18]
    // 0xd0370c: ldur            x2, [fp, #-0x10]
    // 0xd03710: b               #0xd035fc
    // 0xd03714: mov             x2, x1
    // 0xd03718: mov             x1, x3
    // 0xd0371c: r0 = LoadClassIdInstr(r2)
    //     0xd0371c: ldur            x0, [x2, #-1]
    //     0xd03720: ubfx            x0, x0, #0xc, #0x14
    // 0xd03724: stp             x1, x2, [SP, #-0x10]!
    // 0xd03728: ldr             x16, [fp, #0x18]
    // 0xd0372c: SaveReg r16
    //     0xd0372c: str             x16, [SP, #-8]!
    // 0xd03730: r0 = GDT[cid_x0 + 0xd590]()
    //     0xd03730: mov             x17, #0xd590
    //     0xd03734: add             lr, x0, x17
    //     0xd03738: ldr             lr, [x21, lr, lsl #3]
    //     0xd0373c: blr             lr
    // 0xd03740: add             SP, SP, #0x18
    // 0xd03744: ldr             x0, [fp, #0x28]
    // 0xd03748: r1 = LoadClassIdInstr(r0)
    //     0xd03748: ldur            x1, [x0, #-1]
    //     0xd0374c: ubfx            x1, x1, #0xc, #0x14
    // 0xd03750: ldur            x16, [fp, #-8]
    // 0xd03754: stp             x16, x0, [SP, #-0x10]!
    // 0xd03758: ldr             x16, [fp, #0x10]
    // 0xd0375c: SaveReg r16
    //     0xd0375c: str             x16, [SP, #-8]!
    // 0xd03760: mov             x0, x1
    // 0xd03764: r0 = GDT[cid_x0 + 0xd590]()
    //     0xd03764: mov             x17, #0xd590
    //     0xd03768: add             lr, x0, x17
    //     0xd0376c: ldr             lr, [x21, lr, lsl #3]
    //     0xd03770: blr             lr
    // 0xd03774: add             SP, SP, #0x18
    // 0xd03778: r0 = Null
    //     0xd03778: mov             x0, NULL
    // 0xd0377c: LeaveFrame
    //     0xd0377c: mov             SP, fp
    //     0xd03780: ldp             fp, lr, [SP], #0x10
    // 0xd03784: ret
    //     0xd03784: ret             
    // 0xd03788: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03788: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0378c: b               #0xd03594
    // 0xd03790: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd03790: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd03794: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03794: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03798: b               #0xd03614
    // 0xd0379c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0379c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd037a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd037a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static Matrix4 _temporaryTransformHolder() {
    // ** addr: 0xd037a4, size: 0x34
    // 0xd037a4: EnterFrame
    //     0xd037a4: stp             fp, lr, [SP, #-0x10]!
    //     0xd037a8: mov             fp, SP
    // 0xd037ac: AllocStack(0x8)
    //     0xd037ac: sub             SP, SP, #8
    // 0xd037b0: r0 = Matrix4()
    //     0xd037b0: bl              #0x50ace8  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0xd037b4: r4 = 32
    //     0xd037b4: mov             x4, #0x20
    // 0xd037b8: stur            x0, [fp, #-8]
    // 0xd037bc: r0 = AllocateFloat64Array()
    //     0xd037bc: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0xd037c0: mov             x1, x0
    // 0xd037c4: ldur            x0, [fp, #-8]
    // 0xd037c8: StoreField: r0->field_7 = r1
    //     0xd037c8: stur            w1, [x0, #7]
    // 0xd037cc: LeaveFrame
    //     0xd037cc: mov             SP, fp
    //     0xd037d0: ldp             fp, lr, [SP], #0x10
    // 0xd037d4: ret
    //     0xd037d4: ret             
  }
}

// class id: 2017, size: 0xc, field offset: 0x8
abstract class _SemanticsFragment extends Object {
}

// class id: 2018, size: 0x14, field offset: 0xc
abstract class _InterestingSemanticsFragment extends _SemanticsFragment {
}

// class id: 2019, size: 0x28, field offset: 0x14
class _SwitchableSemanticsFragment extends _InterestingSemanticsFragment {

  _ _SwitchableSemanticsFragment(/* No info */) {
    // ** addr: 0x5dc700, size: 0xf4
    // 0x5dc700: EnterFrame
    //     0x5dc700: stp             fp, lr, [SP, #-0x10]!
    //     0x5dc704: mov             fp, SP
    // 0x5dc708: AllocStack(0x8)
    //     0x5dc708: sub             SP, SP, #8
    // 0x5dc70c: r0 = false
    //     0x5dc70c: add             x0, NULL, #0x30  ; false
    // 0x5dc710: CheckStackOverflow
    //     0x5dc710: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5dc714: cmp             SP, x16
    //     0x5dc718: b.ls            #0x5dc7ec
    // 0x5dc71c: ldr             x1, [fp, #0x30]
    // 0x5dc720: StoreField: r1->field_1b = r0
    //     0x5dc720: stur            w0, [x1, #0x1b]
    // 0x5dc724: StoreField: r1->field_23 = r0
    //     0x5dc724: stur            w0, [x1, #0x23]
    // 0x5dc728: r16 = <_InterestingSemanticsFragment>
    //     0x5dc728: ldr             x16, [PP, #0x4958]  ; [pp+0x4958] TypeArguments: <_InterestingSemanticsFragment>
    // 0x5dc72c: stp             xzr, x16, [SP, #-0x10]!
    // 0x5dc730: r0 = _GrowableList()
    //     0x5dc730: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x5dc734: add             SP, SP, #0x10
    // 0x5dc738: ldr             x3, [fp, #0x30]
    // 0x5dc73c: StoreField: r3->field_1f = r0
    //     0x5dc73c: stur            w0, [x3, #0x1f]
    //     0x5dc740: ldurb           w16, [x3, #-1]
    //     0x5dc744: ldurb           w17, [x0, #-1]
    //     0x5dc748: and             x16, x17, x16, lsr #2
    //     0x5dc74c: tst             x16, HEAP, lsr #32
    //     0x5dc750: b.eq            #0x5dc758
    //     0x5dc754: bl              #0xd682ac
    // 0x5dc758: ldr             x0, [fp, #0x18]
    // 0x5dc75c: StoreField: r3->field_13 = r0
    //     0x5dc75c: stur            w0, [x3, #0x13]
    // 0x5dc760: ldr             x0, [fp, #0x28]
    // 0x5dc764: StoreField: r3->field_17 = r0
    //     0x5dc764: stur            w0, [x3, #0x17]
    //     0x5dc768: ldurb           w16, [x3, #-1]
    //     0x5dc76c: ldurb           w17, [x0, #-1]
    //     0x5dc770: and             x16, x17, x16, lsr #2
    //     0x5dc774: tst             x16, HEAP, lsr #32
    //     0x5dc778: b.eq            #0x5dc780
    //     0x5dc77c: bl              #0xd682ac
    // 0x5dc780: r1 = Null
    //     0x5dc780: mov             x1, NULL
    // 0x5dc784: r2 = 2
    //     0x5dc784: mov             x2, #2
    // 0x5dc788: r0 = AllocateArray()
    //     0x5dc788: bl              #0xd6987c  ; AllocateArrayStub
    // 0x5dc78c: mov             x2, x0
    // 0x5dc790: ldr             x0, [fp, #0x10]
    // 0x5dc794: stur            x2, [fp, #-8]
    // 0x5dc798: StoreField: r2->field_f = r0
    //     0x5dc798: stur            w0, [x2, #0xf]
    // 0x5dc79c: r1 = <RenderObject>
    //     0x5dc79c: ldr             x1, [PP, #0x4988]  ; [pp+0x4988] TypeArguments: <RenderObject>
    // 0x5dc7a0: r0 = AllocateGrowableArray()
    //     0x5dc7a0: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x5dc7a4: ldur            x1, [fp, #-8]
    // 0x5dc7a8: StoreField: r0->field_f = r1
    //     0x5dc7a8: stur            w1, [x0, #0xf]
    // 0x5dc7ac: r1 = 2
    //     0x5dc7ac: mov             x1, #2
    // 0x5dc7b0: StoreField: r0->field_b = r1
    //     0x5dc7b0: stur            w1, [x0, #0xb]
    // 0x5dc7b4: ldr             x1, [fp, #0x30]
    // 0x5dc7b8: StoreField: r1->field_b = r0
    //     0x5dc7b8: stur            w0, [x1, #0xb]
    //     0x5dc7bc: ldurb           w16, [x1, #-1]
    //     0x5dc7c0: ldurb           w17, [x0, #-1]
    //     0x5dc7c4: and             x16, x17, x16, lsr #2
    //     0x5dc7c8: tst             x16, HEAP, lsr #32
    //     0x5dc7cc: b.eq            #0x5dc7d4
    //     0x5dc7d0: bl              #0xd6826c
    // 0x5dc7d4: ldr             x2, [fp, #0x20]
    // 0x5dc7d8: StoreField: r1->field_7 = r2
    //     0x5dc7d8: stur            w2, [x1, #7]
    // 0x5dc7dc: r0 = Null
    //     0x5dc7dc: mov             x0, NULL
    // 0x5dc7e0: LeaveFrame
    //     0x5dc7e0: mov             SP, fp
    //     0x5dc7e4: ldp             fp, lr, [SP], #0x10
    // 0x5dc7e8: ret
    //     0x5dc7e8: ret             
    // 0x5dc7ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5dc7ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5dc7f0: b               #0x5dc71c
  }
  _ addAll(/* No info */) {
    // ** addr: 0xd00974, size: 0x2d4
    // 0xd00974: EnterFrame
    //     0xd00974: stp             fp, lr, [SP, #-0x10]!
    //     0xd00978: mov             fp, SP
    // 0xd0097c: AllocStack(0x38)
    //     0xd0097c: sub             SP, SP, #0x38
    // 0xd00980: CheckStackOverflow
    //     0xd00980: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd00984: cmp             SP, x16
    //     0xd00988: b.ls            #0xd00c30
    // 0xd0098c: ldr             x1, [fp, #0x10]
    // 0xd00990: LoadField: r2 = r1->field_7
    //     0xd00990: ldur            w2, [x1, #7]
    // 0xd00994: DecompressPointer r2
    //     0xd00994: add             x2, x2, HEAP, lsl #32
    // 0xd00998: stur            x2, [fp, #-0x20]
    // 0xd0099c: LoadField: r0 = r1->field_b
    //     0xd0099c: ldur            w0, [x1, #0xb]
    // 0xd009a0: DecompressPointer r0
    //     0xd009a0: add             x0, x0, HEAP, lsl #32
    // 0xd009a4: r3 = LoadInt32Instr(r0)
    //     0xd009a4: sbfx            x3, x0, #1, #0x1f
    // 0xd009a8: ldr             x4, [fp, #0x18]
    // 0xd009ac: stur            x3, [fp, #-0x18]
    // 0xd009b0: LoadField: r5 = r4->field_1f
    //     0xd009b0: ldur            w5, [x4, #0x1f]
    // 0xd009b4: DecompressPointer r5
    //     0xd009b4: add             x5, x5, HEAP, lsl #32
    // 0xd009b8: stur            x5, [fp, #-0x10]
    // 0xd009bc: r6 = 0
    //     0xd009bc: mov             x6, #0
    // 0xd009c0: stur            x6, [fp, #-8]
    // 0xd009c4: CheckStackOverflow
    //     0xd009c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd009c8: cmp             SP, x16
    //     0xd009cc: b.ls            #0xd00c38
    // 0xd009d0: r0 = LoadClassIdInstr(r1)
    //     0xd009d0: ldur            x0, [x1, #-1]
    //     0xd009d4: ubfx            x0, x0, #0xc, #0x14
    // 0xd009d8: SaveReg r1
    //     0xd009d8: str             x1, [SP, #-8]!
    // 0xd009dc: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xd009dc: mov             x17, #0xb8ea
    //     0xd009e0: add             lr, x0, x17
    //     0xd009e4: ldr             lr, [x21, lr, lsl #3]
    //     0xd009e8: blr             lr
    // 0xd009ec: add             SP, SP, #8
    // 0xd009f0: r1 = LoadInt32Instr(r0)
    //     0xd009f0: sbfx            x1, x0, #1, #0x1f
    //     0xd009f4: tbz             w0, #0, #0xd009fc
    //     0xd009f8: ldur            x1, [x0, #7]
    // 0xd009fc: ldur            x2, [fp, #-0x18]
    // 0xd00a00: cmp             x2, x1
    // 0xd00a04: b.ne            #0xd00c18
    // 0xd00a08: ldr             x3, [fp, #0x10]
    // 0xd00a0c: ldur            x4, [fp, #-8]
    // 0xd00a10: cmp             x4, x1
    // 0xd00a14: b.lt            #0xd00a28
    // 0xd00a18: r0 = Null
    //     0xd00a18: mov             x0, NULL
    // 0xd00a1c: LeaveFrame
    //     0xd00a1c: mov             SP, fp
    //     0xd00a20: ldp             fp, lr, [SP], #0x10
    // 0xd00a24: ret
    //     0xd00a24: ret             
    // 0xd00a28: r0 = BoxInt64Instr(r4)
    //     0xd00a28: sbfiz           x0, x4, #1, #0x1f
    //     0xd00a2c: cmp             x4, x0, asr #1
    //     0xd00a30: b.eq            #0xd00a3c
    //     0xd00a34: bl              #0xd69bb8
    //     0xd00a38: stur            x4, [x0, #7]
    // 0xd00a3c: r1 = LoadClassIdInstr(r3)
    //     0xd00a3c: ldur            x1, [x3, #-1]
    //     0xd00a40: ubfx            x1, x1, #0xc, #0x14
    // 0xd00a44: stp             x0, x3, [SP, #-0x10]!
    // 0xd00a48: mov             x0, x1
    // 0xd00a4c: r0 = GDT[cid_x0 + 0xd175]()
    //     0xd00a4c: mov             x17, #0xd175
    //     0xd00a50: add             lr, x0, x17
    //     0xd00a54: ldr             lr, [x21, lr, lsl #3]
    //     0xd00a58: blr             lr
    // 0xd00a5c: add             SP, SP, #0x10
    // 0xd00a60: mov             x3, x0
    // 0xd00a64: ldur            x0, [fp, #-8]
    // 0xd00a68: stur            x3, [fp, #-0x30]
    // 0xd00a6c: add             x6, x0, #1
    // 0xd00a70: stur            x6, [fp, #-0x28]
    // 0xd00a74: cmp             w3, NULL
    // 0xd00a78: b.ne            #0xd00aa8
    // 0xd00a7c: mov             x0, x3
    // 0xd00a80: ldur            x2, [fp, #-0x20]
    // 0xd00a84: r1 = Null
    //     0xd00a84: mov             x1, NULL
    // 0xd00a88: cmp             w2, NULL
    // 0xd00a8c: b.eq            #0xd00aa8
    // 0xd00a90: LoadField: r4 = r2->field_17
    //     0xd00a90: ldur            w4, [x2, #0x17]
    // 0xd00a94: DecompressPointer r4
    //     0xd00a94: add             x4, x4, HEAP, lsl #32
    // 0xd00a98: r8 = X0
    //     0xd00a98: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xd00a9c: LoadField: r9 = r4->field_7
    //     0xd00a9c: ldur            x9, [x4, #7]
    // 0xd00aa0: r3 = Null
    //     0xd00aa0: ldr             x3, [PP, #0x72e8]  ; [pp+0x72e8] Null
    // 0xd00aa4: blr             x9
    // 0xd00aa8: ldur            x0, [fp, #-0x10]
    // 0xd00aac: LoadField: r1 = r0->field_b
    //     0xd00aac: ldur            w1, [x0, #0xb]
    // 0xd00ab0: DecompressPointer r1
    //     0xd00ab0: add             x1, x1, HEAP, lsl #32
    // 0xd00ab4: stur            x1, [fp, #-0x38]
    // 0xd00ab8: LoadField: r2 = r0->field_f
    //     0xd00ab8: ldur            w2, [x0, #0xf]
    // 0xd00abc: DecompressPointer r2
    //     0xd00abc: add             x2, x2, HEAP, lsl #32
    // 0xd00ac0: LoadField: r3 = r2->field_b
    //     0xd00ac0: ldur            w3, [x2, #0xb]
    // 0xd00ac4: DecompressPointer r3
    //     0xd00ac4: add             x3, x3, HEAP, lsl #32
    // 0xd00ac8: cmp             w1, w3
    // 0xd00acc: b.ne            #0xd00adc
    // 0xd00ad0: SaveReg r0
    //     0xd00ad0: str             x0, [SP, #-8]!
    // 0xd00ad4: r0 = _growToNextCapacity()
    //     0xd00ad4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd00ad8: add             SP, SP, #8
    // 0xd00adc: ldur            x2, [fp, #-0x10]
    // 0xd00ae0: ldur            x3, [fp, #-0x30]
    // 0xd00ae4: ldur            x0, [fp, #-0x38]
    // 0xd00ae8: r4 = LoadInt32Instr(r0)
    //     0xd00ae8: sbfx            x4, x0, #1, #0x1f
    // 0xd00aec: add             x0, x4, #1
    // 0xd00af0: lsl             x1, x0, #1
    // 0xd00af4: StoreField: r2->field_b = r1
    //     0xd00af4: stur            w1, [x2, #0xb]
    // 0xd00af8: mov             x1, x4
    // 0xd00afc: cmp             x1, x0
    // 0xd00b00: b.hs            #0xd00c40
    // 0xd00b04: LoadField: r1 = r2->field_f
    //     0xd00b04: ldur            w1, [x2, #0xf]
    // 0xd00b08: DecompressPointer r1
    //     0xd00b08: add             x1, x1, HEAP, lsl #32
    // 0xd00b0c: mov             x0, x3
    // 0xd00b10: ArrayStore: r1[r4] = r0  ; List_4
    //     0xd00b10: add             x25, x1, x4, lsl #2
    //     0xd00b14: add             x25, x25, #0xf
    //     0xd00b18: str             w0, [x25]
    //     0xd00b1c: tbz             w0, #0, #0xd00b38
    //     0xd00b20: ldurb           w16, [x1, #-1]
    //     0xd00b24: ldurb           w17, [x0, #-1]
    //     0xd00b28: and             x16, x17, x16, lsr #2
    //     0xd00b2c: tst             x16, HEAP, lsr #32
    //     0xd00b30: b.eq            #0xd00b38
    //     0xd00b34: bl              #0xd67e5c
    // 0xd00b38: r0 = LoadClassIdInstr(r3)
    //     0xd00b38: ldur            x0, [x3, #-1]
    //     0xd00b3c: ubfx            x0, x0, #0xc, #0x14
    // 0xd00b40: SaveReg r3
    //     0xd00b40: str             x3, [SP, #-8]!
    // 0xd00b44: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd00b44: sub             lr, x0, #1, lsl #12
    //     0xd00b48: ldr             lr, [x21, lr, lsl #3]
    //     0xd00b4c: blr             lr
    // 0xd00b50: add             SP, SP, #8
    // 0xd00b54: cmp             w0, NULL
    // 0xd00b58: b.eq            #0xd00bfc
    // 0xd00b5c: ldr             x0, [fp, #0x18]
    // 0xd00b60: LoadField: r1 = r0->field_1b
    //     0xd00b60: ldur            w1, [x0, #0x1b]
    // 0xd00b64: DecompressPointer r1
    //     0xd00b64: add             x1, x1, HEAP, lsl #32
    // 0xd00b68: tbz             w1, #4, #0xd00bac
    // 0xd00b6c: LoadField: r1 = r0->field_17
    //     0xd00b6c: ldur            w1, [x0, #0x17]
    // 0xd00b70: DecompressPointer r1
    //     0xd00b70: add             x1, x1, HEAP, lsl #32
    // 0xd00b74: SaveReg r1
    //     0xd00b74: str             x1, [SP, #-8]!
    // 0xd00b78: r0 = copy()
    //     0xd00b78: bl              #0xd01320  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::copy
    // 0xd00b7c: add             SP, SP, #8
    // 0xd00b80: ldr             x1, [fp, #0x18]
    // 0xd00b84: StoreField: r1->field_17 = r0
    //     0xd00b84: stur            w0, [x1, #0x17]
    //     0xd00b88: ldurb           w16, [x1, #-1]
    //     0xd00b8c: ldurb           w17, [x0, #-1]
    //     0xd00b90: and             x16, x17, x16, lsr #2
    //     0xd00b94: tst             x16, HEAP, lsr #32
    //     0xd00b98: b.eq            #0xd00ba0
    //     0xd00b9c: bl              #0xd6826c
    // 0xd00ba0: r2 = true
    //     0xd00ba0: add             x2, NULL, #0x20  ; true
    // 0xd00ba4: StoreField: r1->field_1b = r2
    //     0xd00ba4: stur            w2, [x1, #0x1b]
    // 0xd00ba8: b               #0xd00bb4
    // 0xd00bac: mov             x1, x0
    // 0xd00bb0: r2 = true
    //     0xd00bb0: add             x2, NULL, #0x20  ; true
    // 0xd00bb4: ldur            x0, [fp, #-0x30]
    // 0xd00bb8: LoadField: r3 = r1->field_17
    //     0xd00bb8: ldur            w3, [x1, #0x17]
    // 0xd00bbc: DecompressPointer r3
    //     0xd00bbc: add             x3, x3, HEAP, lsl #32
    // 0xd00bc0: stur            x3, [fp, #-0x38]
    // 0xd00bc4: r4 = LoadClassIdInstr(r0)
    //     0xd00bc4: ldur            x4, [x0, #-1]
    //     0xd00bc8: ubfx            x4, x4, #0xc, #0x14
    // 0xd00bcc: SaveReg r0
    //     0xd00bcc: str             x0, [SP, #-8]!
    // 0xd00bd0: mov             x0, x4
    // 0xd00bd4: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd00bd4: sub             lr, x0, #1, lsl #12
    //     0xd00bd8: ldr             lr, [x21, lr, lsl #3]
    //     0xd00bdc: blr             lr
    // 0xd00be0: add             SP, SP, #8
    // 0xd00be4: cmp             w0, NULL
    // 0xd00be8: b.eq            #0xd00c44
    // 0xd00bec: ldur            x16, [fp, #-0x38]
    // 0xd00bf0: stp             x0, x16, [SP, #-0x10]!
    // 0xd00bf4: r0 = absorb()
    //     0xd00bf4: bl              #0xd00cc0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::absorb
    // 0xd00bf8: add             SP, SP, #0x10
    // 0xd00bfc: ldur            x6, [fp, #-0x28]
    // 0xd00c00: ldr             x4, [fp, #0x18]
    // 0xd00c04: ldr             x1, [fp, #0x10]
    // 0xd00c08: ldur            x5, [fp, #-0x10]
    // 0xd00c0c: ldur            x2, [fp, #-0x20]
    // 0xd00c10: ldur            x3, [fp, #-0x18]
    // 0xd00c14: b               #0xd009c0
    // 0xd00c18: ldr             x0, [fp, #0x10]
    // 0xd00c1c: r0 = ConcurrentModificationError()
    //     0xd00c1c: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xd00c20: ldr             x3, [fp, #0x10]
    // 0xd00c24: StoreField: r0->field_b = r3
    //     0xd00c24: stur            w3, [x0, #0xb]
    // 0xd00c28: r0 = Throw()
    //     0xd00c28: bl              #0xd67e38  ; ThrowStub
    // 0xd00c2c: brk             #0
    // 0xd00c30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd00c30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd00c34: b               #0xd0098c
    // 0xd00c38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd00c38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd00c3c: b               #0xd009d0
    // 0xd00c40: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd00c40: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd00c44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd00c44: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _ensureConfigIsWritable(/* No info */) {
    // ** addr: 0xd00c48, size: 0x78
    // 0xd00c48: EnterFrame
    //     0xd00c48: stp             fp, lr, [SP, #-0x10]!
    //     0xd00c4c: mov             fp, SP
    // 0xd00c50: CheckStackOverflow
    //     0xd00c50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd00c54: cmp             SP, x16
    //     0xd00c58: b.ls            #0xd00cb8
    // 0xd00c5c: ldr             x0, [fp, #0x10]
    // 0xd00c60: LoadField: r1 = r0->field_1b
    //     0xd00c60: ldur            w1, [x0, #0x1b]
    // 0xd00c64: DecompressPointer r1
    //     0xd00c64: add             x1, x1, HEAP, lsl #32
    // 0xd00c68: tbz             w1, #4, #0xd00ca8
    // 0xd00c6c: LoadField: r1 = r0->field_17
    //     0xd00c6c: ldur            w1, [x0, #0x17]
    // 0xd00c70: DecompressPointer r1
    //     0xd00c70: add             x1, x1, HEAP, lsl #32
    // 0xd00c74: SaveReg r1
    //     0xd00c74: str             x1, [SP, #-8]!
    // 0xd00c78: r0 = copy()
    //     0xd00c78: bl              #0xd01320  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::copy
    // 0xd00c7c: add             SP, SP, #8
    // 0xd00c80: ldr             x1, [fp, #0x10]
    // 0xd00c84: StoreField: r1->field_17 = r0
    //     0xd00c84: stur            w0, [x1, #0x17]
    //     0xd00c88: ldurb           w16, [x1, #-1]
    //     0xd00c8c: ldurb           w17, [x0, #-1]
    //     0xd00c90: and             x16, x17, x16, lsr #2
    //     0xd00c94: tst             x16, HEAP, lsr #32
    //     0xd00c98: b.eq            #0xd00ca0
    //     0xd00c9c: bl              #0xd6826c
    // 0xd00ca0: r2 = true
    //     0xd00ca0: add             x2, NULL, #0x20  ; true
    // 0xd00ca4: StoreField: r1->field_1b = r2
    //     0xd00ca4: stur            w2, [x1, #0x1b]
    // 0xd00ca8: r0 = Null
    //     0xd00ca8: mov             x0, NULL
    // 0xd00cac: LeaveFrame
    //     0xd00cac: mov             SP, fp
    //     0xd00cb0: ldp             fp, lr, [SP], #0x10
    // 0xd00cb4: ret
    //     0xd00cb4: ret             
    // 0xd00cb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd00cb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd00cbc: b               #0xd00c5c
  }
  _ markAsExplicit(/* No info */) {
    // ** addr: 0xd016d4, size: 0x14
    // 0xd016d4: r1 = true
    //     0xd016d4: add             x1, NULL, #0x20  ; true
    // 0xd016d8: ldr             x2, [SP]
    // 0xd016dc: StoreField: r2->field_23 = r1
    //     0xd016dc: stur            w1, [x2, #0x23]
    // 0xd016e0: r0 = Null
    //     0xd016e0: mov             x0, NULL
    // 0xd016e4: ret
    //     0xd016e4: ret             
  }
  _ compileChildren(/* No info */) {
    // ** addr: 0xd01d04, size: 0x878
    // 0xd01d04: EnterFrame
    //     0xd01d04: stp             fp, lr, [SP, #-0x10]!
    //     0xd01d08: mov             fp, SP
    // 0xd01d0c: AllocStack(0x50)
    //     0xd01d0c: sub             SP, SP, #0x50
    // 0xd01d10: CheckStackOverflow
    //     0xd01d10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd01d14: cmp             SP, x16
    //     0xd01d18: b.ls            #0xd02534
    // 0xd01d1c: ldr             x0, [fp, #0x30]
    // 0xd01d20: LoadField: r1 = r0->field_23
    //     0xd01d20: ldur            w1, [x0, #0x23]
    // 0xd01d24: DecompressPointer r1
    //     0xd01d24: add             x1, x1, HEAP, lsl #32
    // 0xd01d28: tbz             w1, #4, #0xd01f38
    // 0xd01d2c: LoadField: r1 = r0->field_b
    //     0xd01d2c: ldur            w1, [x0, #0xb]
    // 0xd01d30: DecompressPointer r1
    //     0xd01d30: add             x1, x1, HEAP, lsl #32
    // 0xd01d34: stur            x1, [fp, #-8]
    // 0xd01d38: SaveReg r1
    //     0xd01d38: str             x1, [SP, #-8]!
    // 0xd01d3c: r0 = first()
    //     0xd01d3c: bl              #0x7192e8  ; [dart:core] _GrowableList::first
    // 0xd01d40: add             SP, SP, #8
    // 0xd01d44: StoreField: r0->field_4b = rNULL
    //     0xd01d44: stur            NULL, [x0, #0x4b]
    // 0xd01d48: ldr             x1, [fp, #0x30]
    // 0xd01d4c: LoadField: r2 = r1->field_1f
    //     0xd01d4c: ldur            w2, [x1, #0x1f]
    // 0xd01d50: DecompressPointer r2
    //     0xd01d50: add             x2, x2, HEAP, lsl #32
    // 0xd01d54: stur            x2, [fp, #-0x30]
    // 0xd01d58: LoadField: r3 = r2->field_7
    //     0xd01d58: ldur            w3, [x2, #7]
    // 0xd01d5c: DecompressPointer r3
    //     0xd01d5c: add             x3, x3, HEAP, lsl #32
    // 0xd01d60: stur            x3, [fp, #-0x28]
    // 0xd01d64: LoadField: r0 = r2->field_b
    //     0xd01d64: ldur            w0, [x2, #0xb]
    // 0xd01d68: DecompressPointer r0
    //     0xd01d68: add             x0, x0, HEAP, lsl #32
    // 0xd01d6c: r4 = LoadInt32Instr(r0)
    //     0xd01d6c: sbfx            x4, x0, #1, #0x1f
    // 0xd01d70: ldur            x5, [fp, #-8]
    // 0xd01d74: stur            x4, [fp, #-0x20]
    // 0xd01d78: LoadField: r6 = r5->field_7
    //     0xd01d78: ldur            w6, [x5, #7]
    // 0xd01d7c: DecompressPointer r6
    //     0xd01d7c: add             x6, x6, HEAP, lsl #32
    // 0xd01d80: stur            x6, [fp, #-0x18]
    // 0xd01d84: r7 = 0
    //     0xd01d84: mov             x7, #0
    // 0xd01d88: ldr             d0, [fp, #0x28]
    // 0xd01d8c: stur            x7, [fp, #-0x10]
    // 0xd01d90: CheckStackOverflow
    //     0xd01d90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd01d94: cmp             SP, x16
    //     0xd01d98: b.ls            #0xd0253c
    // 0xd01d9c: r0 = LoadClassIdInstr(r2)
    //     0xd01d9c: ldur            x0, [x2, #-1]
    //     0xd01da0: ubfx            x0, x0, #0xc, #0x14
    // 0xd01da4: SaveReg r2
    //     0xd01da4: str             x2, [SP, #-8]!
    // 0xd01da8: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xd01da8: mov             x17, #0xb8ea
    //     0xd01dac: add             lr, x0, x17
    //     0xd01db0: ldr             lr, [x21, lr, lsl #3]
    //     0xd01db4: blr             lr
    // 0xd01db8: add             SP, SP, #8
    // 0xd01dbc: r1 = LoadInt32Instr(r0)
    //     0xd01dbc: sbfx            x1, x0, #1, #0x1f
    //     0xd01dc0: tbz             w0, #0, #0xd01dc8
    //     0xd01dc4: ldur            x1, [x0, #7]
    // 0xd01dc8: ldur            x2, [fp, #-0x20]
    // 0xd01dcc: cmp             x2, x1
    // 0xd01dd0: b.ne            #0xd02504
    // 0xd01dd4: ldur            x3, [fp, #-0x30]
    // 0xd01dd8: ldur            x4, [fp, #-0x10]
    // 0xd01ddc: cmp             x4, x1
    // 0xd01de0: b.lt            #0xd01df4
    // 0xd01de4: r0 = Null
    //     0xd01de4: mov             x0, NULL
    // 0xd01de8: LeaveFrame
    //     0xd01de8: mov             SP, fp
    //     0xd01dec: ldp             fp, lr, [SP], #0x10
    // 0xd01df0: ret
    //     0xd01df0: ret             
    // 0xd01df4: r0 = BoxInt64Instr(r4)
    //     0xd01df4: sbfiz           x0, x4, #1, #0x1f
    //     0xd01df8: cmp             x4, x0, asr #1
    //     0xd01dfc: b.eq            #0xd01e08
    //     0xd01e00: bl              #0xd69bb8
    //     0xd01e04: stur            x4, [x0, #7]
    // 0xd01e08: r1 = LoadClassIdInstr(r3)
    //     0xd01e08: ldur            x1, [x3, #-1]
    //     0xd01e0c: ubfx            x1, x1, #0xc, #0x14
    // 0xd01e10: stp             x0, x3, [SP, #-0x10]!
    // 0xd01e14: mov             x0, x1
    // 0xd01e18: r0 = GDT[cid_x0 + 0xd175]()
    //     0xd01e18: mov             x17, #0xd175
    //     0xd01e1c: add             lr, x0, x17
    //     0xd01e20: ldr             lr, [x21, lr, lsl #3]
    //     0xd01e24: blr             lr
    // 0xd01e28: add             SP, SP, #0x10
    // 0xd01e2c: mov             x3, x0
    // 0xd01e30: ldur            x0, [fp, #-0x10]
    // 0xd01e34: stur            x3, [fp, #-0x40]
    // 0xd01e38: add             x7, x0, #1
    // 0xd01e3c: stur            x7, [fp, #-0x38]
    // 0xd01e40: cmp             w3, NULL
    // 0xd01e44: b.ne            #0xd01e74
    // 0xd01e48: mov             x0, x3
    // 0xd01e4c: ldur            x2, [fp, #-0x28]
    // 0xd01e50: r1 = Null
    //     0xd01e50: mov             x1, NULL
    // 0xd01e54: cmp             w2, NULL
    // 0xd01e58: b.eq            #0xd01e74
    // 0xd01e5c: LoadField: r4 = r2->field_17
    //     0xd01e5c: ldur            w4, [x2, #0x17]
    // 0xd01e60: DecompressPointer r4
    //     0xd01e60: add             x4, x4, HEAP, lsl #32
    // 0xd01e64: r8 = X0
    //     0xd01e64: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xd01e68: LoadField: r9 = r4->field_7
    //     0xd01e68: ldur            x9, [x4, #7]
    // 0xd01e6c: r3 = Null
    //     0xd01e6c: ldr             x3, [PP, #0x72f8]  ; [pp+0x72f8] Null
    // 0xd01e70: blr             x9
    // 0xd01e74: ldr             x2, [fp, #0x30]
    // 0xd01e78: ldr             d0, [fp, #0x28]
    // 0xd01e7c: ldur            x0, [fp, #-0x40]
    // 0xd01e80: LoadField: r3 = r0->field_b
    //     0xd01e80: ldur            w3, [x0, #0xb]
    // 0xd01e84: DecompressPointer r3
    //     0xd01e84: add             x3, x3, HEAP, lsl #32
    // 0xd01e88: ldur            x1, [fp, #-0x18]
    // 0xd01e8c: stur            x3, [fp, #-0x48]
    // 0xd01e90: r0 = SubListIterable()
    //     0xd01e90: bl              #0x4c2748  ; AllocateSubListIterableStub -> SubListIterable<X0> (size=0x1c)
    // 0xd01e94: stur            x0, [fp, #-0x50]
    // 0xd01e98: ldur            x16, [fp, #-8]
    // 0xd01e9c: stp             x16, x0, [SP, #-0x10]!
    // 0xd01ea0: r1 = 1
    //     0xd01ea0: mov             x1, #1
    // 0xd01ea4: stp             NULL, x1, [SP, #-0x10]!
    // 0xd01ea8: r0 = SubListIterable()
    //     0xd01ea8: bl              #0x4c25b4  ; [dart:_internal] SubListIterable::SubListIterable
    // 0xd01eac: add             SP, SP, #0x20
    // 0xd01eb0: ldur            x16, [fp, #-0x48]
    // 0xd01eb4: ldur            lr, [fp, #-0x50]
    // 0xd01eb8: stp             lr, x16, [SP, #-0x10]!
    // 0xd01ebc: r0 = addAll()
    //     0xd01ebc: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0xd01ec0: add             SP, SP, #0x10
    // 0xd01ec4: ldr             x1, [fp, #0x30]
    // 0xd01ec8: LoadField: r0 = r1->field_17
    //     0xd01ec8: ldur            w0, [x1, #0x17]
    // 0xd01ecc: DecompressPointer r0
    //     0xd01ecc: add             x0, x0, HEAP, lsl #32
    // 0xd01ed0: LoadField: d0 = r0->field_63
    //     0xd01ed0: ldur            d0, [x0, #0x63]
    // 0xd01ed4: ldr             d1, [fp, #0x28]
    // 0xd01ed8: fadd            d2, d1, d0
    // 0xd01edc: ldur            x0, [fp, #-0x40]
    // 0xd01ee0: r2 = LoadClassIdInstr(r0)
    //     0xd01ee0: ldur            x2, [x0, #-1]
    //     0xd01ee4: ubfx            x2, x2, #0xc, #0x14
    // 0xd01ee8: SaveReg r0
    //     0xd01ee8: str             x0, [SP, #-8]!
    // 0xd01eec: SaveReg d2
    //     0xd01eec: str             d2, [SP, #-8]!
    // 0xd01ef0: ldr             x16, [fp, #0x20]
    // 0xd01ef4: ldr             lr, [fp, #0x18]
    // 0xd01ef8: stp             lr, x16, [SP, #-0x10]!
    // 0xd01efc: ldr             x16, [fp, #0x10]
    // 0xd01f00: SaveReg r16
    //     0xd01f00: str             x16, [SP, #-8]!
    // 0xd01f04: mov             x0, x2
    // 0xd01f08: r0 = GDT[cid_x0 + -0xffe]()
    //     0xd01f08: sub             lr, x0, #0xffe
    //     0xd01f0c: ldr             lr, [x21, lr, lsl #3]
    //     0xd01f10: blr             lr
    // 0xd01f14: add             SP, SP, #0x28
    // 0xd01f18: ldur            x7, [fp, #-0x38]
    // 0xd01f1c: ldr             x1, [fp, #0x30]
    // 0xd01f20: ldur            x2, [fp, #-0x30]
    // 0xd01f24: ldur            x6, [fp, #-0x18]
    // 0xd01f28: ldur            x5, [fp, #-8]
    // 0xd01f2c: ldur            x3, [fp, #-0x28]
    // 0xd01f30: ldur            x4, [fp, #-0x20]
    // 0xd01f34: b               #0xd01d88
    // 0xd01f38: LoadField: r1 = r0->field_b
    //     0xd01f38: ldur            w1, [x0, #0xb]
    // 0xd01f3c: DecompressPointer r1
    //     0xd01f3c: add             x1, x1, HEAP, lsl #32
    // 0xd01f40: stur            x1, [fp, #-8]
    // 0xd01f44: LoadField: r2 = r1->field_b
    //     0xd01f44: ldur            w2, [x1, #0xb]
    // 0xd01f48: DecompressPointer r2
    //     0xd01f48: add             x2, x2, HEAP, lsl #32
    // 0xd01f4c: r3 = LoadInt32Instr(r2)
    //     0xd01f4c: sbfx            x3, x2, #1, #0x1f
    // 0xd01f50: cmp             x3, #1
    // 0xd01f54: b.le            #0xd01f84
    // 0xd01f58: r0 = _SemanticsGeometry()
    //     0xd01f58: bl              #0xd037d8  ; Allocate_SemanticsGeometryStub -> _SemanticsGeometry (size=0x1c)
    // 0xd01f5c: stur            x0, [fp, #-0x18]
    // 0xd01f60: ldur            x16, [fp, #-8]
    // 0xd01f64: stp             x16, x0, [SP, #-0x10]!
    // 0xd01f68: ldr             x16, [fp, #0x20]
    // 0xd01f6c: ldr             lr, [fp, #0x18]
    // 0xd01f70: stp             lr, x16, [SP, #-0x10]!
    // 0xd01f74: r0 = _SemanticsGeometry()
    //     0xd01f74: bl              #0xd02dd8  ; [package:flutter/src/rendering/object.dart] _SemanticsGeometry::_SemanticsGeometry
    // 0xd01f78: add             SP, SP, #0x20
    // 0xd01f7c: ldur            x1, [fp, #-0x18]
    // 0xd01f80: b               #0xd01f88
    // 0xd01f84: r1 = Null
    //     0xd01f84: mov             x1, NULL
    // 0xd01f88: ldr             x0, [fp, #0x30]
    // 0xd01f8c: stur            x1, [fp, #-0x28]
    // 0xd01f90: LoadField: r2 = r0->field_13
    //     0xd01f90: ldur            w2, [x0, #0x13]
    // 0xd01f94: DecompressPointer r2
    //     0xd01f94: add             x2, x2, HEAP, lsl #32
    // 0xd01f98: stur            x2, [fp, #-0x18]
    // 0xd01f9c: tbz             w2, #4, #0xd01fd8
    // 0xd01fa0: cmp             w1, NULL
    // 0xd01fa4: b.ne            #0xd01fb0
    // 0xd01fa8: r0 = Null
    //     0xd01fa8: mov             x0, NULL
    // 0xd01fac: b               #0xd01fbc
    // 0xd01fb0: SaveReg r1
    //     0xd01fb0: str             x1, [SP, #-8]!
    // 0xd01fb4: r0 = dropFromTree()
    //     0xd01fb4: bl              #0xd02ab0  ; [package:flutter/src/rendering/object.dart] _SemanticsGeometry::dropFromTree
    // 0xd01fb8: add             SP, SP, #8
    // 0xd01fbc: cmp             w0, NULL
    // 0xd01fc0: b.eq            #0xd01fd8
    // 0xd01fc4: tbnz            w0, #4, #0xd01fd8
    // 0xd01fc8: r0 = Null
    //     0xd01fc8: mov             x0, NULL
    // 0xd01fcc: LeaveFrame
    //     0xd01fcc: mov             SP, fp
    //     0xd01fd0: ldp             fp, lr, [SP], #0x10
    // 0xd01fd4: ret
    //     0xd01fd4: ret             
    // 0xd01fd8: ldur            x16, [fp, #-8]
    // 0xd01fdc: SaveReg r16
    //     0xd01fdc: str             x16, [SP, #-8]!
    // 0xd01fe0: r0 = first()
    //     0xd01fe0: bl              #0x7192e8  ; [dart:core] _GrowableList::first
    // 0xd01fe4: add             SP, SP, #8
    // 0xd01fe8: stur            x0, [fp, #-0x30]
    // 0xd01fec: LoadField: r1 = r0->field_4b
    //     0xd01fec: ldur            w1, [x0, #0x4b]
    // 0xd01ff0: DecompressPointer r1
    //     0xd01ff0: add             x1, x1, HEAP, lsl #32
    // 0xd01ff4: cmp             w1, NULL
    // 0xd01ff8: b.ne            #0xd02074
    // 0xd01ffc: ldur            x16, [fp, #-8]
    // 0xd02000: SaveReg r16
    //     0xd02000: str             x16, [SP, #-8]!
    // 0xd02004: r0 = first()
    //     0xd02004: bl              #0x7192e8  ; [dart:core] _GrowableList::first
    // 0xd02008: add             SP, SP, #8
    // 0xd0200c: r1 = LoadClassIdInstr(r0)
    //     0xd0200c: ldur            x1, [x0, #-1]
    //     0xd02010: ubfx            x1, x1, #0xc, #0x14
    // 0xd02014: SaveReg r0
    //     0xd02014: str             x0, [SP, #-8]!
    // 0xd02018: mov             x0, x1
    // 0xd0201c: r0 = GDT[cid_x0 + 0xdc01]()
    //     0xd0201c: mov             x17, #0xdc01
    //     0xd02020: add             lr, x0, x17
    //     0xd02024: ldr             lr, [x21, lr, lsl #3]
    //     0xd02028: blr             lr
    // 0xd0202c: add             SP, SP, #8
    // 0xd02030: stur            x0, [fp, #-0x40]
    // 0xd02034: r0 = SemanticsNode()
    //     0xd02034: bl              #0x646784  ; AllocateSemanticsNodeStub -> SemanticsNode (size=0xc8)
    // 0xd02038: stur            x0, [fp, #-0x48]
    // 0xd0203c: ldur            x16, [fp, #-0x40]
    // 0xd02040: stp             x16, x0, [SP, #-0x10]!
    // 0xd02044: r4 = const [0, 0x2, 0x2, 0x1, showOnScreen, 0x1, null]
    //     0xd02044: ldr             x4, [PP, #0x7308]  ; [pp+0x7308] List(7) [0, 0x2, 0x2, 0x1, "showOnScreen", 0x1, Null]
    // 0xd02048: r0 = SemanticsNode()
    //     0xd02048: bl              #0x64642c  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::SemanticsNode
    // 0xd0204c: add             SP, SP, #0x10
    // 0xd02050: ldur            x0, [fp, #-0x48]
    // 0xd02054: ldur            x1, [fp, #-0x30]
    // 0xd02058: StoreField: r1->field_4b = r0
    //     0xd02058: stur            w0, [x1, #0x4b]
    //     0xd0205c: ldurb           w16, [x1, #-1]
    //     0xd02060: ldurb           w17, [x0, #-1]
    //     0xd02064: and             x16, x17, x16, lsr #2
    //     0xd02068: tst             x16, HEAP, lsr #32
    //     0xd0206c: b.eq            #0xd02074
    //     0xd02070: bl              #0xd6826c
    // 0xd02074: ldr             x0, [fp, #0x30]
    // 0xd02078: ldr             d0, [fp, #0x28]
    // 0xd0207c: ldur            x16, [fp, #-8]
    // 0xd02080: SaveReg r16
    //     0xd02080: str             x16, [SP, #-8]!
    // 0xd02084: r0 = first()
    //     0xd02084: bl              #0x7192e8  ; [dart:core] _GrowableList::first
    // 0xd02088: add             SP, SP, #8
    // 0xd0208c: LoadField: r1 = r0->field_4b
    //     0xd0208c: ldur            w1, [x0, #0x4b]
    // 0xd02090: DecompressPointer r1
    //     0xd02090: add             x1, x1, HEAP, lsl #32
    // 0xd02094: stur            x1, [fp, #-0x30]
    // 0xd02098: cmp             w1, NULL
    // 0xd0209c: b.eq            #0xd02544
    // 0xd020a0: ldur            x16, [fp, #-0x18]
    // 0xd020a4: stp             x16, x1, [SP, #-0x10]!
    // 0xd020a8: r0 = isMergedIntoParent=()
    //     0xd020a8: bl              #0x64a078  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::isMergedIntoParent=
    // 0xd020ac: add             SP, SP, #0x10
    // 0xd020b0: ldr             x1, [fp, #0x30]
    // 0xd020b4: LoadField: r0 = r1->field_f
    //     0xd020b4: ldur            w0, [x1, #0xf]
    // 0xd020b8: DecompressPointer r0
    //     0xd020b8: add             x0, x0, HEAP, lsl #32
    // 0xd020bc: ldur            x2, [fp, #-0x30]
    // 0xd020c0: StoreField: r2->field_63 = r0
    //     0xd020c0: stur            w0, [x2, #0x63]
    //     0xd020c4: ldurb           w16, [x2, #-1]
    //     0xd020c8: ldurb           w17, [x0, #-1]
    //     0xd020cc: and             x16, x17, x16, lsr #2
    //     0xd020d0: tst             x16, HEAP, lsr #32
    //     0xd020d4: b.eq            #0xd020dc
    //     0xd020d8: bl              #0xd6828c
    // 0xd020dc: ldr             d0, [fp, #0x28]
    // 0xd020e0: r0 = inline_Allocate_Double()
    //     0xd020e0: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xd020e4: add             x0, x0, #0x10
    //     0xd020e8: cmp             x3, x0
    //     0xd020ec: b.ls            #0xd02548
    //     0xd020f0: str             x0, [THR, #0x60]  ; THR::top
    //     0xd020f4: sub             x0, x0, #0xf
    //     0xd020f8: mov             x3, #0xd108
    //     0xd020fc: movk            x3, #3, lsl #16
    //     0xd02100: stur            x3, [x0, #-1]
    // 0xd02104: StoreField: r0->field_7 = d0
    //     0xd02104: stur            d0, [x0, #7]
    // 0xd02108: StoreField: r2->field_37 = r0
    //     0xd02108: stur            w0, [x2, #0x37]
    //     0xd0210c: ldurb           w16, [x2, #-1]
    //     0xd02110: ldurb           w17, [x0, #-1]
    //     0xd02114: and             x16, x17, x16, lsr #2
    //     0xd02118: tst             x16, HEAP, lsr #32
    //     0xd0211c: b.eq            #0xd02124
    //     0xd02120: bl              #0xd6828c
    // 0xd02124: d1 = 0.000000
    //     0xd02124: eor             v1.16b, v1.16b, v1.16b
    // 0xd02128: fcmp            d0, d1
    // 0xd0212c: b.eq            #0xd02164
    // 0xd02130: SaveReg r1
    //     0xd02130: str             x1, [SP, #-8]!
    // 0xd02134: r0 = _ensureConfigIsWritable()
    //     0xd02134: bl              #0xd00c48  ; [package:flutter/src/rendering/object.dart] _SwitchableSemanticsFragment::_ensureConfigIsWritable
    // 0xd02138: add             SP, SP, #8
    // 0xd0213c: ldr             x0, [fp, #0x30]
    // 0xd02140: LoadField: r1 = r0->field_17
    //     0xd02140: ldur            w1, [x0, #0x17]
    // 0xd02144: DecompressPointer r1
    //     0xd02144: add             x1, x1, HEAP, lsl #32
    // 0xd02148: LoadField: d0 = r1->field_63
    //     0xd02148: ldur            d0, [x1, #0x63]
    // 0xd0214c: ldr             d1, [fp, #0x28]
    // 0xd02150: fadd            d2, d0, d1
    // 0xd02154: SaveReg r1
    //     0xd02154: str             x1, [SP, #-8]!
    // 0xd02158: SaveReg d2
    //     0xd02158: str             d2, [SP, #-8]!
    // 0xd0215c: r0 = elevation=()
    //     0xd0215c: bl              #0xd02a7c  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::elevation=
    // 0xd02160: add             SP, SP, #0x10
    // 0xd02164: ldur            x0, [fp, #-0x28]
    // 0xd02168: cmp             w0, NULL
    // 0xd0216c: b.eq            #0xd02250
    // 0xd02170: ldur            x2, [fp, #-0x18]
    // 0xd02174: ldur            x1, [fp, #-0x30]
    // 0xd02178: LoadField: r3 = r0->field_13
    //     0xd02178: ldur            w3, [x0, #0x13]
    // 0xd0217c: DecompressPointer r3
    //     0xd0217c: add             x3, x3, HEAP, lsl #32
    // 0xd02180: r16 = Sentinel
    //     0xd02180: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xd02184: cmp             w3, w16
    // 0xd02188: b.eq            #0xd02560
    // 0xd0218c: stp             x3, x1, [SP, #-0x10]!
    // 0xd02190: r0 = rect=()
    //     0xd02190: bl              #0x6468c4  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::rect=
    // 0xd02194: add             SP, SP, #0x10
    // 0xd02198: ldur            x0, [fp, #-0x28]
    // 0xd0219c: LoadField: r1 = r0->field_f
    //     0xd0219c: ldur            w1, [x0, #0xf]
    // 0xd021a0: DecompressPointer r1
    //     0xd021a0: add             x1, x1, HEAP, lsl #32
    // 0xd021a4: r16 = Sentinel
    //     0xd021a4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xd021a8: cmp             w1, w16
    // 0xd021ac: b.eq            #0xd02568
    // 0xd021b0: ldur            x16, [fp, #-0x30]
    // 0xd021b4: stp             x1, x16, [SP, #-0x10]!
    // 0xd021b8: r0 = transform=()
    //     0xd021b8: bl              #0xd0257c  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::transform=
    // 0xd021bc: add             SP, SP, #0x10
    // 0xd021c0: ldur            x1, [fp, #-0x28]
    // 0xd021c4: LoadField: r0 = r1->field_b
    //     0xd021c4: ldur            w0, [x1, #0xb]
    // 0xd021c8: DecompressPointer r0
    //     0xd021c8: add             x0, x0, HEAP, lsl #32
    // 0xd021cc: ldur            x2, [fp, #-0x30]
    // 0xd021d0: StoreField: r2->field_2f = r0
    //     0xd021d0: stur            w0, [x2, #0x2f]
    //     0xd021d4: ldurb           w16, [x2, #-1]
    //     0xd021d8: ldurb           w17, [x0, #-1]
    //     0xd021dc: and             x16, x17, x16, lsr #2
    //     0xd021e0: tst             x16, HEAP, lsr #32
    //     0xd021e4: b.eq            #0xd021ec
    //     0xd021e8: bl              #0xd6828c
    // 0xd021ec: LoadField: r0 = r1->field_7
    //     0xd021ec: ldur            w0, [x1, #7]
    // 0xd021f0: DecompressPointer r0
    //     0xd021f0: add             x0, x0, HEAP, lsl #32
    // 0xd021f4: StoreField: r2->field_33 = r0
    //     0xd021f4: stur            w0, [x2, #0x33]
    //     0xd021f8: ldurb           w16, [x2, #-1]
    //     0xd021fc: ldurb           w17, [x0, #-1]
    //     0xd02200: and             x16, x17, x16, lsr #2
    //     0xd02204: tst             x16, HEAP, lsr #32
    //     0xd02208: b.eq            #0xd02210
    //     0xd0220c: bl              #0xd6828c
    // 0xd02210: ldur            x0, [fp, #-0x18]
    // 0xd02214: tbz             w0, #4, #0xd02250
    // 0xd02218: LoadField: r0 = r1->field_17
    //     0xd02218: ldur            w0, [x1, #0x17]
    // 0xd0221c: DecompressPointer r0
    //     0xd0221c: add             x0, x0, HEAP, lsl #32
    // 0xd02220: tbnz            w0, #4, #0xd02250
    // 0xd02224: ldr             x0, [fp, #0x30]
    // 0xd02228: SaveReg r0
    //     0xd02228: str             x0, [SP, #-8]!
    // 0xd0222c: r0 = _ensureConfigIsWritable()
    //     0xd0222c: bl              #0xd00c48  ; [package:flutter/src/rendering/object.dart] _SwitchableSemanticsFragment::_ensureConfigIsWritable
    // 0xd02230: add             SP, SP, #8
    // 0xd02234: ldr             x0, [fp, #0x30]
    // 0xd02238: LoadField: r1 = r0->field_17
    //     0xd02238: ldur            w1, [x0, #0x17]
    // 0xd0223c: DecompressPointer r1
    //     0xd0223c: add             x1, x1, HEAP, lsl #32
    // 0xd02240: r16 = true
    //     0xd02240: add             x16, NULL, #0x20  ; true
    // 0xd02244: stp             x16, x1, [SP, #-0x10]!
    // 0xd02248: r0 = isHidden=()
    //     0xd02248: bl              #0x6492c0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isHidden=
    // 0xd0224c: add             SP, SP, #0x10
    // 0xd02250: ldr             x0, [fp, #0x30]
    // 0xd02254: r16 = <SemanticsNode>
    //     0xd02254: ldr             x16, [PP, #0x45e0]  ; [pp+0x45e0] TypeArguments: <SemanticsNode>
    // 0xd02258: stp             xzr, x16, [SP, #-0x10]!
    // 0xd0225c: r0 = _GrowableList()
    //     0xd0225c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xd02260: add             SP, SP, #0x10
    // 0xd02264: mov             x2, x0
    // 0xd02268: ldr             x1, [fp, #0x30]
    // 0xd0226c: stur            x2, [fp, #-0x40]
    // 0xd02270: LoadField: r3 = r1->field_1f
    //     0xd02270: ldur            w3, [x1, #0x1f]
    // 0xd02274: DecompressPointer r3
    //     0xd02274: add             x3, x3, HEAP, lsl #32
    // 0xd02278: stur            x3, [fp, #-0x28]
    // 0xd0227c: LoadField: r4 = r3->field_7
    //     0xd0227c: ldur            w4, [x3, #7]
    // 0xd02280: DecompressPointer r4
    //     0xd02280: add             x4, x4, HEAP, lsl #32
    // 0xd02284: stur            x4, [fp, #-0x18]
    // 0xd02288: LoadField: r0 = r3->field_b
    //     0xd02288: ldur            w0, [x3, #0xb]
    // 0xd0228c: DecompressPointer r0
    //     0xd0228c: add             x0, x0, HEAP, lsl #32
    // 0xd02290: r5 = LoadInt32Instr(r0)
    //     0xd02290: sbfx            x5, x0, #1, #0x1f
    // 0xd02294: stur            x5, [fp, #-0x20]
    // 0xd02298: r8 = 0
    //     0xd02298: mov             x8, #0
    // 0xd0229c: ldr             x7, [fp, #0x10]
    // 0xd022a0: ldur            x6, [fp, #-0x30]
    // 0xd022a4: stur            x8, [fp, #-0x10]
    // 0xd022a8: CheckStackOverflow
    //     0xd022a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd022ac: cmp             SP, x16
    //     0xd022b0: b.ls            #0xd02570
    // 0xd022b4: r0 = LoadClassIdInstr(r3)
    //     0xd022b4: ldur            x0, [x3, #-1]
    //     0xd022b8: ubfx            x0, x0, #0xc, #0x14
    // 0xd022bc: SaveReg r3
    //     0xd022bc: str             x3, [SP, #-8]!
    // 0xd022c0: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xd022c0: mov             x17, #0xb8ea
    //     0xd022c4: add             lr, x0, x17
    //     0xd022c8: ldr             lr, [x21, lr, lsl #3]
    //     0xd022cc: blr             lr
    // 0xd022d0: add             SP, SP, #8
    // 0xd022d4: r1 = LoadInt32Instr(r0)
    //     0xd022d4: sbfx            x1, x0, #1, #0x1f
    //     0xd022d8: tbz             w0, #0, #0xd022e0
    //     0xd022dc: ldur            x1, [x0, #7]
    // 0xd022e0: ldur            x2, [fp, #-0x20]
    // 0xd022e4: cmp             x2, x1
    // 0xd022e8: b.ne            #0xd0251c
    // 0xd022ec: ldur            x3, [fp, #-0x28]
    // 0xd022f0: ldur            x4, [fp, #-0x10]
    // 0xd022f4: cmp             x4, x1
    // 0xd022f8: b.lt            #0xd0241c
    // 0xd022fc: ldr             x0, [fp, #0x30]
    // 0xd02300: LoadField: r1 = r0->field_17
    //     0xd02300: ldur            w1, [x0, #0x17]
    // 0xd02304: DecompressPointer r1
    //     0xd02304: add             x1, x1, HEAP, lsl #32
    // 0xd02308: LoadField: r2 = r1->field_7
    //     0xd02308: ldur            w2, [x1, #7]
    // 0xd0230c: DecompressPointer r2
    //     0xd0230c: add             x2, x2, HEAP, lsl #32
    // 0xd02310: tbnz            w2, #4, #0xd02364
    // 0xd02314: ldur            x16, [fp, #-8]
    // 0xd02318: SaveReg r16
    //     0xd02318: str             x16, [SP, #-8]!
    // 0xd0231c: r0 = first()
    //     0xd0231c: bl              #0x7192e8  ; [dart:core] _GrowableList::first
    // 0xd02320: add             SP, SP, #8
    // 0xd02324: ldr             x5, [fp, #0x30]
    // 0xd02328: LoadField: r1 = r5->field_17
    //     0xd02328: ldur            w1, [x5, #0x17]
    // 0xd0232c: DecompressPointer r1
    //     0xd0232c: add             x1, x1, HEAP, lsl #32
    // 0xd02330: r2 = LoadClassIdInstr(r0)
    //     0xd02330: ldur            x2, [x0, #-1]
    //     0xd02334: ubfx            x2, x2, #0xc, #0x14
    // 0xd02338: ldur            x16, [fp, #-0x30]
    // 0xd0233c: stp             x16, x0, [SP, #-0x10]!
    // 0xd02340: ldur            x16, [fp, #-0x40]
    // 0xd02344: stp             x16, x1, [SP, #-0x10]!
    // 0xd02348: mov             x0, x2
    // 0xd0234c: r0 = GDT[cid_x0 + 0xe9b0]()
    //     0xd0234c: mov             x17, #0xe9b0
    //     0xd02350: add             lr, x0, x17
    //     0xd02354: ldr             lr, [x21, lr, lsl #3]
    //     0xd02358: blr             lr
    // 0xd0235c: add             SP, SP, #0x20
    // 0xd02360: b               #0xd02380
    // 0xd02364: ldur            x16, [fp, #-0x30]
    // 0xd02368: stp             x1, x16, [SP, #-0x10]!
    // 0xd0236c: ldur            x16, [fp, #-0x40]
    // 0xd02370: SaveReg r16
    //     0xd02370: str             x16, [SP, #-8]!
    // 0xd02374: r4 = const [0, 0x3, 0x3, 0x2, childrenInInversePaintOrder, 0x2, null]
    //     0xd02374: ldr             x4, [PP, #0x7218]  ; [pp+0x7218] List(7) [0, 0x3, 0x3, 0x2, "childrenInInversePaintOrder", 0x2, Null]
    // 0xd02378: r0 = updateWith()
    //     0xd02378: bl              #0x6469d8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::updateWith
    // 0xd0237c: add             SP, SP, #0x18
    // 0xd02380: ldr             x0, [fp, #0x10]
    // 0xd02384: LoadField: r1 = r0->field_b
    //     0xd02384: ldur            w1, [x0, #0xb]
    // 0xd02388: DecompressPointer r1
    //     0xd02388: add             x1, x1, HEAP, lsl #32
    // 0xd0238c: stur            x1, [fp, #-0x48]
    // 0xd02390: LoadField: r2 = r0->field_f
    //     0xd02390: ldur            w2, [x0, #0xf]
    // 0xd02394: DecompressPointer r2
    //     0xd02394: add             x2, x2, HEAP, lsl #32
    // 0xd02398: LoadField: r3 = r2->field_b
    //     0xd02398: ldur            w3, [x2, #0xb]
    // 0xd0239c: DecompressPointer r3
    //     0xd0239c: add             x3, x3, HEAP, lsl #32
    // 0xd023a0: cmp             w1, w3
    // 0xd023a4: b.ne            #0xd023b4
    // 0xd023a8: SaveReg r0
    //     0xd023a8: str             x0, [SP, #-8]!
    // 0xd023ac: r0 = _growToNextCapacity()
    //     0xd023ac: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd023b0: add             SP, SP, #8
    // 0xd023b4: ldr             x6, [fp, #0x10]
    // 0xd023b8: ldur            x0, [fp, #-0x48]
    // 0xd023bc: r2 = LoadInt32Instr(r0)
    //     0xd023bc: sbfx            x2, x0, #1, #0x1f
    // 0xd023c0: add             x0, x2, #1
    // 0xd023c4: lsl             x1, x0, #1
    // 0xd023c8: StoreField: r6->field_b = r1
    //     0xd023c8: stur            w1, [x6, #0xb]
    // 0xd023cc: mov             x1, x2
    // 0xd023d0: cmp             x1, x0
    // 0xd023d4: b.hs            #0xd02578
    // 0xd023d8: LoadField: r1 = r6->field_f
    //     0xd023d8: ldur            w1, [x6, #0xf]
    // 0xd023dc: DecompressPointer r1
    //     0xd023dc: add             x1, x1, HEAP, lsl #32
    // 0xd023e0: ldur            x0, [fp, #-0x30]
    // 0xd023e4: ArrayStore: r1[r2] = r0  ; List_4
    //     0xd023e4: add             x25, x1, x2, lsl #2
    //     0xd023e8: add             x25, x25, #0xf
    //     0xd023ec: str             w0, [x25]
    //     0xd023f0: tbz             w0, #0, #0xd0240c
    //     0xd023f4: ldurb           w16, [x1, #-1]
    //     0xd023f8: ldurb           w17, [x0, #-1]
    //     0xd023fc: and             x16, x17, x16, lsr #2
    //     0xd02400: tst             x16, HEAP, lsr #32
    //     0xd02404: b.eq            #0xd0240c
    //     0xd02408: bl              #0xd67e5c
    // 0xd0240c: r0 = Null
    //     0xd0240c: mov             x0, NULL
    // 0xd02410: LeaveFrame
    //     0xd02410: mov             SP, fp
    //     0xd02414: ldp             fp, lr, [SP], #0x10
    // 0xd02418: ret
    //     0xd02418: ret             
    // 0xd0241c: ldr             x5, [fp, #0x30]
    // 0xd02420: ldr             x6, [fp, #0x10]
    // 0xd02424: r0 = BoxInt64Instr(r4)
    //     0xd02424: sbfiz           x0, x4, #1, #0x1f
    //     0xd02428: cmp             x4, x0, asr #1
    //     0xd0242c: b.eq            #0xd02438
    //     0xd02430: bl              #0xd69bb8
    //     0xd02434: stur            x4, [x0, #7]
    // 0xd02438: r1 = LoadClassIdInstr(r3)
    //     0xd02438: ldur            x1, [x3, #-1]
    //     0xd0243c: ubfx            x1, x1, #0xc, #0x14
    // 0xd02440: stp             x0, x3, [SP, #-0x10]!
    // 0xd02444: mov             x0, x1
    // 0xd02448: r0 = GDT[cid_x0 + 0xd175]()
    //     0xd02448: mov             x17, #0xd175
    //     0xd0244c: add             lr, x0, x17
    //     0xd02450: ldr             lr, [x21, lr, lsl #3]
    //     0xd02454: blr             lr
    // 0xd02458: add             SP, SP, #0x10
    // 0xd0245c: mov             x3, x0
    // 0xd02460: ldur            x0, [fp, #-0x10]
    // 0xd02464: stur            x3, [fp, #-0x48]
    // 0xd02468: add             x8, x0, #1
    // 0xd0246c: stur            x8, [fp, #-0x38]
    // 0xd02470: cmp             w3, NULL
    // 0xd02474: b.ne            #0xd024a4
    // 0xd02478: mov             x0, x3
    // 0xd0247c: ldur            x2, [fp, #-0x18]
    // 0xd02480: r1 = Null
    //     0xd02480: mov             x1, NULL
    // 0xd02484: cmp             w2, NULL
    // 0xd02488: b.eq            #0xd024a4
    // 0xd0248c: LoadField: r4 = r2->field_17
    //     0xd0248c: ldur            w4, [x2, #0x17]
    // 0xd02490: DecompressPointer r4
    //     0xd02490: add             x4, x4, HEAP, lsl #32
    // 0xd02494: r8 = X0
    //     0xd02494: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xd02498: LoadField: r9 = r4->field_7
    //     0xd02498: ldur            x9, [x4, #7]
    // 0xd0249c: r3 = Null
    //     0xd0249c: ldr             x3, [PP, #0x7310]  ; [pp+0x7310] Null
    // 0xd024a0: blr             x9
    // 0xd024a4: ldur            x1, [fp, #-0x30]
    // 0xd024a8: ldur            x0, [fp, #-0x48]
    // 0xd024ac: LoadField: r2 = r1->field_2f
    //     0xd024ac: ldur            w2, [x1, #0x2f]
    // 0xd024b0: DecompressPointer r2
    //     0xd024b0: add             x2, x2, HEAP, lsl #32
    // 0xd024b4: LoadField: r3 = r1->field_33
    //     0xd024b4: ldur            w3, [x1, #0x33]
    // 0xd024b8: DecompressPointer r3
    //     0xd024b8: add             x3, x3, HEAP, lsl #32
    // 0xd024bc: r4 = LoadClassIdInstr(r0)
    //     0xd024bc: ldur            x4, [x0, #-1]
    //     0xd024c0: ubfx            x4, x4, #0xc, #0x14
    // 0xd024c4: stp             xzr, x0, [SP, #-0x10]!
    // 0xd024c8: stp             x2, x3, [SP, #-0x10]!
    // 0xd024cc: ldur            x16, [fp, #-0x40]
    // 0xd024d0: SaveReg r16
    //     0xd024d0: str             x16, [SP, #-8]!
    // 0xd024d4: mov             x0, x4
    // 0xd024d8: r0 = GDT[cid_x0 + -0xffe]()
    //     0xd024d8: sub             lr, x0, #0xffe
    //     0xd024dc: ldr             lr, [x21, lr, lsl #3]
    //     0xd024e0: blr             lr
    // 0xd024e4: add             SP, SP, #0x28
    // 0xd024e8: ldur            x8, [fp, #-0x38]
    // 0xd024ec: ldr             x1, [fp, #0x30]
    // 0xd024f0: ldur            x2, [fp, #-0x40]
    // 0xd024f4: ldur            x3, [fp, #-0x28]
    // 0xd024f8: ldur            x4, [fp, #-0x18]
    // 0xd024fc: ldur            x5, [fp, #-0x20]
    // 0xd02500: b               #0xd0229c
    // 0xd02504: ldur            x0, [fp, #-0x30]
    // 0xd02508: r0 = ConcurrentModificationError()
    //     0xd02508: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xd0250c: ldur            x3, [fp, #-0x30]
    // 0xd02510: StoreField: r0->field_b = r3
    //     0xd02510: stur            w3, [x0, #0xb]
    // 0xd02514: r0 = Throw()
    //     0xd02514: bl              #0xd67e38  ; ThrowStub
    // 0xd02518: brk             #0
    // 0xd0251c: ldur            x0, [fp, #-0x28]
    // 0xd02520: r0 = ConcurrentModificationError()
    //     0xd02520: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xd02524: ldur            x3, [fp, #-0x28]
    // 0xd02528: StoreField: r0->field_b = r3
    //     0xd02528: stur            w3, [x0, #0xb]
    // 0xd0252c: r0 = Throw()
    //     0xd0252c: bl              #0xd67e38  ; ThrowStub
    // 0xd02530: brk             #0
    // 0xd02534: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02534: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02538: b               #0xd01d1c
    // 0xd0253c: r0 = StackOverflowSharedWithFPURegs()
    //     0xd0253c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xd02540: b               #0xd01d9c
    // 0xd02544: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd02544: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd02548: SaveReg d0
    //     0xd02548: str             q0, [SP, #-0x10]!
    // 0xd0254c: stp             x1, x2, [SP, #-0x10]!
    // 0xd02550: r0 = AllocateDouble()
    //     0xd02550: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xd02554: ldp             x1, x2, [SP], #0x10
    // 0xd02558: RestoreReg d0
    //     0xd02558: ldr             q0, [SP], #0x10
    // 0xd0255c: b               #0xd02104
    // 0xd02560: r9 = _rect
    //     0xd02560: ldr             x9, [PP, #0x7320]  ; [pp+0x7320] Field <_SemanticsGeometry@904266271._rect@904266271>: late (offset: 0x14)
    // 0xd02564: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd02564: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd02568: r9 = _transform
    //     0xd02568: ldr             x9, [PP, #0x7328]  ; [pp+0x7328] Field <_SemanticsGeometry@904266271._transform@904266271>: late (offset: 0x10)
    // 0xd0256c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd0256c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd02570: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd02570: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd02574: b               #0xd022b4
    // 0xd02578: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd02578: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  get _ config(/* No info */) {
    // ** addr: 0xd037e4, size: 0x28
    // 0xd037e4: ldr             x1, [SP]
    // 0xd037e8: LoadField: r2 = r1->field_23
    //     0xd037e8: ldur            w2, [x1, #0x23]
    // 0xd037ec: DecompressPointer r2
    //     0xd037ec: add             x2, x2, HEAP, lsl #32
    // 0xd037f0: tbnz            w2, #4, #0xd037fc
    // 0xd037f4: r0 = Null
    //     0xd037f4: mov             x0, NULL
    // 0xd037f8: b               #0xd03808
    // 0xd037fc: LoadField: r2 = r1->field_17
    //     0xd037fc: ldur            w2, [x1, #0x17]
    // 0xd03800: DecompressPointer r2
    //     0xd03800: add             x2, x2, HEAP, lsl #32
    // 0xd03804: mov             x0, x2
    // 0xd03808: ret
    //     0xd03808: ret             
  }
}

// class id: 2020, size: 0x18, field offset: 0x14
class _RootSemanticsFragment extends _InterestingSemanticsFragment {

  _ _RootSemanticsFragment(/* No info */) {
    // ** addr: 0x5dc638, size: 0xbc
    // 0x5dc638: EnterFrame
    //     0x5dc638: stp             fp, lr, [SP, #-0x10]!
    //     0x5dc63c: mov             fp, SP
    // 0x5dc640: AllocStack(0x8)
    //     0x5dc640: sub             SP, SP, #8
    // 0x5dc644: CheckStackOverflow
    //     0x5dc644: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5dc648: cmp             SP, x16
    //     0x5dc64c: b.ls            #0x5dc6ec
    // 0x5dc650: r16 = <_InterestingSemanticsFragment>
    //     0x5dc650: ldr             x16, [PP, #0x4958]  ; [pp+0x4958] TypeArguments: <_InterestingSemanticsFragment>
    // 0x5dc654: stp             xzr, x16, [SP, #-0x10]!
    // 0x5dc658: r0 = _GrowableList()
    //     0x5dc658: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x5dc65c: add             SP, SP, #0x10
    // 0x5dc660: ldr             x3, [fp, #0x20]
    // 0x5dc664: StoreField: r3->field_13 = r0
    //     0x5dc664: stur            w0, [x3, #0x13]
    //     0x5dc668: ldurb           w16, [x3, #-1]
    //     0x5dc66c: ldurb           w17, [x0, #-1]
    //     0x5dc670: and             x16, x17, x16, lsr #2
    //     0x5dc674: tst             x16, HEAP, lsr #32
    //     0x5dc678: b.eq            #0x5dc680
    //     0x5dc67c: bl              #0xd682ac
    // 0x5dc680: r1 = Null
    //     0x5dc680: mov             x1, NULL
    // 0x5dc684: r2 = 2
    //     0x5dc684: mov             x2, #2
    // 0x5dc688: r0 = AllocateArray()
    //     0x5dc688: bl              #0xd6987c  ; AllocateArrayStub
    // 0x5dc68c: mov             x2, x0
    // 0x5dc690: ldr             x0, [fp, #0x10]
    // 0x5dc694: stur            x2, [fp, #-8]
    // 0x5dc698: StoreField: r2->field_f = r0
    //     0x5dc698: stur            w0, [x2, #0xf]
    // 0x5dc69c: r1 = <RenderObject>
    //     0x5dc69c: ldr             x1, [PP, #0x4988]  ; [pp+0x4988] TypeArguments: <RenderObject>
    // 0x5dc6a0: r0 = AllocateGrowableArray()
    //     0x5dc6a0: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x5dc6a4: ldur            x1, [fp, #-8]
    // 0x5dc6a8: StoreField: r0->field_f = r1
    //     0x5dc6a8: stur            w1, [x0, #0xf]
    // 0x5dc6ac: r1 = 2
    //     0x5dc6ac: mov             x1, #2
    // 0x5dc6b0: StoreField: r0->field_b = r1
    //     0x5dc6b0: stur            w1, [x0, #0xb]
    // 0x5dc6b4: ldr             x1, [fp, #0x20]
    // 0x5dc6b8: StoreField: r1->field_b = r0
    //     0x5dc6b8: stur            w0, [x1, #0xb]
    //     0x5dc6bc: ldurb           w16, [x1, #-1]
    //     0x5dc6c0: ldurb           w17, [x0, #-1]
    //     0x5dc6c4: and             x16, x17, x16, lsr #2
    //     0x5dc6c8: tst             x16, HEAP, lsr #32
    //     0x5dc6cc: b.eq            #0x5dc6d4
    //     0x5dc6d0: bl              #0xd6826c
    // 0x5dc6d4: ldr             x2, [fp, #0x18]
    // 0x5dc6d8: StoreField: r1->field_7 = r2
    //     0x5dc6d8: stur            w2, [x1, #7]
    // 0x5dc6dc: r0 = Null
    //     0x5dc6dc: mov             x0, NULL
    // 0x5dc6e0: LeaveFrame
    //     0x5dc6e0: mov             SP, fp
    //     0x5dc6e4: ldp             fp, lr, [SP], #0x10
    // 0x5dc6e8: ret
    //     0x5dc6e8: ret             
    // 0x5dc6ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5dc6ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5dc6f0: b               #0x5dc650
  }
  _ addAll(/* No info */) {
    // ** addr: 0xd0092c, size: 0x48
    // 0xd0092c: EnterFrame
    //     0xd0092c: stp             fp, lr, [SP, #-0x10]!
    //     0xd00930: mov             fp, SP
    // 0xd00934: CheckStackOverflow
    //     0xd00934: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd00938: cmp             SP, x16
    //     0xd0093c: b.ls            #0xd0096c
    // 0xd00940: ldr             x0, [fp, #0x18]
    // 0xd00944: LoadField: r1 = r0->field_13
    //     0xd00944: ldur            w1, [x0, #0x13]
    // 0xd00948: DecompressPointer r1
    //     0xd00948: add             x1, x1, HEAP, lsl #32
    // 0xd0094c: ldr             x16, [fp, #0x10]
    // 0xd00950: stp             x16, x1, [SP, #-0x10]!
    // 0xd00954: r0 = addAll()
    //     0xd00954: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0xd00958: add             SP, SP, #0x10
    // 0xd0095c: r0 = Null
    //     0xd0095c: mov             x0, NULL
    // 0xd00960: LeaveFrame
    //     0xd00960: mov             SP, fp
    //     0xd00964: ldp             fp, lr, [SP], #0x10
    // 0xd00968: ret
    //     0xd00968: ret             
    // 0xd0096c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0096c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd00970: b               #0xd00940
  }
  _ compileChildren(/* No info */) {
    // ** addr: 0xd016e8, size: 0x404
    // 0xd016e8: EnterFrame
    //     0xd016e8: stp             fp, lr, [SP, #-0x10]!
    //     0xd016ec: mov             fp, SP
    // 0xd016f0: AllocStack(0x40)
    //     0xd016f0: sub             SP, SP, #0x40
    // 0xd016f4: CheckStackOverflow
    //     0xd016f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd016f8: cmp             SP, x16
    //     0xd016fc: b.ls            #0xd01acc
    // 0xd01700: ldr             x0, [fp, #0x30]
    // 0xd01704: LoadField: r1 = r0->field_b
    //     0xd01704: ldur            w1, [x0, #0xb]
    // 0xd01708: DecompressPointer r1
    //     0xd01708: add             x1, x1, HEAP, lsl #32
    // 0xd0170c: stur            x1, [fp, #-8]
    // 0xd01710: SaveReg r1
    //     0xd01710: str             x1, [SP, #-8]!
    // 0xd01714: r0 = first()
    //     0xd01714: bl              #0x7192e8  ; [dart:core] _GrowableList::first
    // 0xd01718: add             SP, SP, #8
    // 0xd0171c: stur            x0, [fp, #-0x10]
    // 0xd01720: LoadField: r1 = r0->field_4b
    //     0xd01720: ldur            w1, [x0, #0x4b]
    // 0xd01724: DecompressPointer r1
    //     0xd01724: add             x1, x1, HEAP, lsl #32
    // 0xd01728: cmp             w1, NULL
    // 0xd0172c: b.ne            #0xd01818
    // 0xd01730: ldur            x16, [fp, #-8]
    // 0xd01734: SaveReg r16
    //     0xd01734: str             x16, [SP, #-8]!
    // 0xd01738: r0 = first()
    //     0xd01738: bl              #0x7192e8  ; [dart:core] _GrowableList::first
    // 0xd0173c: add             SP, SP, #8
    // 0xd01740: r1 = LoadClassIdInstr(r0)
    //     0xd01740: ldur            x1, [x0, #-1]
    //     0xd01744: ubfx            x1, x1, #0xc, #0x14
    // 0xd01748: SaveReg r0
    //     0xd01748: str             x0, [SP, #-8]!
    // 0xd0174c: mov             x0, x1
    // 0xd01750: r0 = GDT[cid_x0 + 0xdc01]()
    //     0xd01750: mov             x17, #0xdc01
    //     0xd01754: add             lr, x0, x17
    //     0xd01758: ldr             lr, [x21, lr, lsl #3]
    //     0xd0175c: blr             lr
    // 0xd01760: add             SP, SP, #8
    // 0xd01764: stur            x0, [fp, #-0x18]
    // 0xd01768: ldur            x16, [fp, #-8]
    // 0xd0176c: SaveReg r16
    //     0xd0176c: str             x16, [SP, #-8]!
    // 0xd01770: r0 = first()
    //     0xd01770: bl              #0x7192e8  ; [dart:core] _GrowableList::first
    // 0xd01774: add             SP, SP, #8
    // 0xd01778: LoadField: r3 = r0->field_f
    //     0xd01778: ldur            w3, [x0, #0xf]
    // 0xd0177c: DecompressPointer r3
    //     0xd0177c: add             x3, x3, HEAP, lsl #32
    // 0xd01780: mov             x0, x3
    // 0xd01784: stur            x3, [fp, #-0x20]
    // 0xd01788: r2 = Null
    //     0xd01788: mov             x2, NULL
    // 0xd0178c: r1 = Null
    //     0xd0178c: mov             x1, NULL
    // 0xd01790: r4 = 59
    //     0xd01790: mov             x4, #0x3b
    // 0xd01794: branchIfSmi(r0, 0xd017a0)
    //     0xd01794: tbz             w0, #0, #0xd017a0
    // 0xd01798: r4 = LoadClassIdInstr(r0)
    //     0xd01798: ldur            x4, [x0, #-1]
    //     0xd0179c: ubfx            x4, x4, #0xc, #0x14
    // 0xd017a0: cmp             x4, #0x7e6
    // 0xd017a4: b.eq            #0xd017b4
    // 0xd017a8: r8 = PipelineOwner?
    //     0xd017a8: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0xd017ac: r3 = Null
    //     0xd017ac: ldr             x3, [PP, #0x7208]  ; [pp+0x7208] Null
    // 0xd017b0: r0 = DefaultNullableTypeTest()
    //     0xd017b0: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xd017b4: ldur            x0, [fp, #-0x20]
    // 0xd017b8: cmp             w0, NULL
    // 0xd017bc: b.eq            #0xd01ad4
    // 0xd017c0: LoadField: r1 = r0->field_2b
    //     0xd017c0: ldur            w1, [x0, #0x2b]
    // 0xd017c4: DecompressPointer r1
    //     0xd017c4: add             x1, x1, HEAP, lsl #32
    // 0xd017c8: stur            x1, [fp, #-0x28]
    // 0xd017cc: cmp             w1, NULL
    // 0xd017d0: b.eq            #0xd01ad8
    // 0xd017d4: r0 = SemanticsNode()
    //     0xd017d4: bl              #0x646784  ; AllocateSemanticsNodeStub -> SemanticsNode (size=0xc8)
    // 0xd017d8: stur            x0, [fp, #-0x20]
    // 0xd017dc: ldur            x16, [fp, #-0x28]
    // 0xd017e0: stp             x16, x0, [SP, #-0x10]!
    // 0xd017e4: ldur            x16, [fp, #-0x18]
    // 0xd017e8: SaveReg r16
    //     0xd017e8: str             x16, [SP, #-8]!
    // 0xd017ec: r0 = SemanticsNode.root()
    //     0xd017ec: bl              #0xd01aec  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::SemanticsNode.root
    // 0xd017f0: add             SP, SP, #0x18
    // 0xd017f4: ldur            x0, [fp, #-0x20]
    // 0xd017f8: ldur            x1, [fp, #-0x10]
    // 0xd017fc: StoreField: r1->field_4b = r0
    //     0xd017fc: stur            w0, [x1, #0x4b]
    //     0xd01800: ldurb           w16, [x1, #-1]
    //     0xd01804: ldurb           w17, [x0, #-1]
    //     0xd01808: and             x16, x17, x16, lsr #2
    //     0xd0180c: tst             x16, HEAP, lsr #32
    //     0xd01810: b.eq            #0xd01818
    //     0xd01814: bl              #0xd6826c
    // 0xd01818: ldr             x0, [fp, #0x30]
    // 0xd0181c: SaveReg r0
    //     0xd0181c: str             x0, [SP, #-8]!
    // 0xd01820: r0 = first()
    //     0xd01820: bl              #0x6bf0fc  ; [package:collection/src/wrappers.dart] _DelegatingIterableBase::first
    // 0xd01824: add             SP, SP, #8
    // 0xd01828: LoadField: r1 = r0->field_4b
    //     0xd01828: ldur            w1, [x0, #0x4b]
    // 0xd0182c: DecompressPointer r1
    //     0xd0182c: add             x1, x1, HEAP, lsl #32
    // 0xd01830: stur            x1, [fp, #-0x10]
    // 0xd01834: cmp             w1, NULL
    // 0xd01838: b.eq            #0xd01adc
    // 0xd0183c: ldur            x16, [fp, #-8]
    // 0xd01840: SaveReg r16
    //     0xd01840: str             x16, [SP, #-8]!
    // 0xd01844: r0 = first()
    //     0xd01844: bl              #0x7192e8  ; [dart:core] _GrowableList::first
    // 0xd01848: add             SP, SP, #8
    // 0xd0184c: r1 = LoadClassIdInstr(r0)
    //     0xd0184c: ldur            x1, [x0, #-1]
    //     0xd01850: ubfx            x1, x1, #0xc, #0x14
    // 0xd01854: SaveReg r0
    //     0xd01854: str             x0, [SP, #-8]!
    // 0xd01858: mov             x0, x1
    // 0xd0185c: r0 = GDT[cid_x0 + 0xd953]()
    //     0xd0185c: mov             x17, #0xd953
    //     0xd01860: add             lr, x0, x17
    //     0xd01864: ldr             lr, [x21, lr, lsl #3]
    //     0xd01868: blr             lr
    // 0xd0186c: add             SP, SP, #8
    // 0xd01870: ldur            x16, [fp, #-0x10]
    // 0xd01874: stp             x0, x16, [SP, #-0x10]!
    // 0xd01878: r0 = rect=()
    //     0xd01878: bl              #0x6468c4  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::rect=
    // 0xd0187c: add             SP, SP, #0x10
    // 0xd01880: r16 = <SemanticsNode>
    //     0xd01880: ldr             x16, [PP, #0x45e0]  ; [pp+0x45e0] TypeArguments: <SemanticsNode>
    // 0xd01884: stp             xzr, x16, [SP, #-0x10]!
    // 0xd01888: r0 = _GrowableList()
    //     0xd01888: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xd0188c: add             SP, SP, #0x10
    // 0xd01890: mov             x1, x0
    // 0xd01894: ldr             x0, [fp, #0x30]
    // 0xd01898: stur            x1, [fp, #-0x20]
    // 0xd0189c: LoadField: r2 = r0->field_13
    //     0xd0189c: ldur            w2, [x0, #0x13]
    // 0xd018a0: DecompressPointer r2
    //     0xd018a0: add             x2, x2, HEAP, lsl #32
    // 0xd018a4: stur            x2, [fp, #-0x18]
    // 0xd018a8: LoadField: r3 = r2->field_7
    //     0xd018a8: ldur            w3, [x2, #7]
    // 0xd018ac: DecompressPointer r3
    //     0xd018ac: add             x3, x3, HEAP, lsl #32
    // 0xd018b0: stur            x3, [fp, #-8]
    // 0xd018b4: LoadField: r0 = r2->field_b
    //     0xd018b4: ldur            w0, [x2, #0xb]
    // 0xd018b8: DecompressPointer r0
    //     0xd018b8: add             x0, x0, HEAP, lsl #32
    // 0xd018bc: r4 = LoadInt32Instr(r0)
    //     0xd018bc: sbfx            x4, x0, #1, #0x1f
    // 0xd018c0: stur            x4, [fp, #-0x38]
    // 0xd018c4: r6 = 0
    //     0xd018c4: mov             x6, #0
    // 0xd018c8: ldr             x5, [fp, #0x10]
    // 0xd018cc: stur            x6, [fp, #-0x30]
    // 0xd018d0: CheckStackOverflow
    //     0xd018d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd018d4: cmp             SP, x16
    //     0xd018d8: b.ls            #0xd01ae0
    // 0xd018dc: r0 = LoadClassIdInstr(r2)
    //     0xd018dc: ldur            x0, [x2, #-1]
    //     0xd018e0: ubfx            x0, x0, #0xc, #0x14
    // 0xd018e4: SaveReg r2
    //     0xd018e4: str             x2, [SP, #-8]!
    // 0xd018e8: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xd018e8: mov             x17, #0xb8ea
    //     0xd018ec: add             lr, x0, x17
    //     0xd018f0: ldr             lr, [x21, lr, lsl #3]
    //     0xd018f4: blr             lr
    // 0xd018f8: add             SP, SP, #8
    // 0xd018fc: r1 = LoadInt32Instr(r0)
    //     0xd018fc: sbfx            x1, x0, #1, #0x1f
    //     0xd01900: tbz             w0, #0, #0xd01908
    //     0xd01904: ldur            x1, [x0, #7]
    // 0xd01908: ldur            x2, [fp, #-0x38]
    // 0xd0190c: cmp             x2, x1
    // 0xd01910: b.ne            #0xd01ab4
    // 0xd01914: ldur            x3, [fp, #-0x18]
    // 0xd01918: ldur            x4, [fp, #-0x30]
    // 0xd0191c: cmp             x4, x1
    // 0xd01920: b.lt            #0xd019e0
    // 0xd01924: ldr             x0, [fp, #0x10]
    // 0xd01928: ldur            x16, [fp, #-0x10]
    // 0xd0192c: stp             NULL, x16, [SP, #-0x10]!
    // 0xd01930: ldur            x16, [fp, #-0x20]
    // 0xd01934: SaveReg r16
    //     0xd01934: str             x16, [SP, #-8]!
    // 0xd01938: r4 = const [0, 0x3, 0x3, 0x2, childrenInInversePaintOrder, 0x2, null]
    //     0xd01938: ldr             x4, [PP, #0x7218]  ; [pp+0x7218] List(7) [0, 0x3, 0x3, 0x2, "childrenInInversePaintOrder", 0x2, Null]
    // 0xd0193c: r0 = updateWith()
    //     0xd0193c: bl              #0x6469d8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::updateWith
    // 0xd01940: add             SP, SP, #0x18
    // 0xd01944: ldr             x0, [fp, #0x10]
    // 0xd01948: LoadField: r1 = r0->field_b
    //     0xd01948: ldur            w1, [x0, #0xb]
    // 0xd0194c: DecompressPointer r1
    //     0xd0194c: add             x1, x1, HEAP, lsl #32
    // 0xd01950: stur            x1, [fp, #-0x28]
    // 0xd01954: LoadField: r2 = r0->field_f
    //     0xd01954: ldur            w2, [x0, #0xf]
    // 0xd01958: DecompressPointer r2
    //     0xd01958: add             x2, x2, HEAP, lsl #32
    // 0xd0195c: LoadField: r3 = r2->field_b
    //     0xd0195c: ldur            w3, [x2, #0xb]
    // 0xd01960: DecompressPointer r3
    //     0xd01960: add             x3, x3, HEAP, lsl #32
    // 0xd01964: cmp             w1, w3
    // 0xd01968: b.ne            #0xd01978
    // 0xd0196c: SaveReg r0
    //     0xd0196c: str             x0, [SP, #-8]!
    // 0xd01970: r0 = _growToNextCapacity()
    //     0xd01970: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd01974: add             SP, SP, #8
    // 0xd01978: ldr             x5, [fp, #0x10]
    // 0xd0197c: ldur            x0, [fp, #-0x28]
    // 0xd01980: r2 = LoadInt32Instr(r0)
    //     0xd01980: sbfx            x2, x0, #1, #0x1f
    // 0xd01984: add             x0, x2, #1
    // 0xd01988: lsl             x1, x0, #1
    // 0xd0198c: StoreField: r5->field_b = r1
    //     0xd0198c: stur            w1, [x5, #0xb]
    // 0xd01990: mov             x1, x2
    // 0xd01994: cmp             x1, x0
    // 0xd01998: b.hs            #0xd01ae8
    // 0xd0199c: LoadField: r1 = r5->field_f
    //     0xd0199c: ldur            w1, [x5, #0xf]
    // 0xd019a0: DecompressPointer r1
    //     0xd019a0: add             x1, x1, HEAP, lsl #32
    // 0xd019a4: ldur            x0, [fp, #-0x10]
    // 0xd019a8: ArrayStore: r1[r2] = r0  ; List_4
    //     0xd019a8: add             x25, x1, x2, lsl #2
    //     0xd019ac: add             x25, x25, #0xf
    //     0xd019b0: str             w0, [x25]
    //     0xd019b4: tbz             w0, #0, #0xd019d0
    //     0xd019b8: ldurb           w16, [x1, #-1]
    //     0xd019bc: ldurb           w17, [x0, #-1]
    //     0xd019c0: and             x16, x17, x16, lsr #2
    //     0xd019c4: tst             x16, HEAP, lsr #32
    //     0xd019c8: b.eq            #0xd019d0
    //     0xd019cc: bl              #0xd67e5c
    // 0xd019d0: r0 = Null
    //     0xd019d0: mov             x0, NULL
    // 0xd019d4: LeaveFrame
    //     0xd019d4: mov             SP, fp
    //     0xd019d8: ldp             fp, lr, [SP], #0x10
    // 0xd019dc: ret
    //     0xd019dc: ret             
    // 0xd019e0: ldr             x5, [fp, #0x10]
    // 0xd019e4: r0 = BoxInt64Instr(r4)
    //     0xd019e4: sbfiz           x0, x4, #1, #0x1f
    //     0xd019e8: cmp             x4, x0, asr #1
    //     0xd019ec: b.eq            #0xd019f8
    //     0xd019f0: bl              #0xd69bb8
    //     0xd019f4: stur            x4, [x0, #7]
    // 0xd019f8: r1 = LoadClassIdInstr(r3)
    //     0xd019f8: ldur            x1, [x3, #-1]
    //     0xd019fc: ubfx            x1, x1, #0xc, #0x14
    // 0xd01a00: stp             x0, x3, [SP, #-0x10]!
    // 0xd01a04: mov             x0, x1
    // 0xd01a08: r0 = GDT[cid_x0 + 0xd175]()
    //     0xd01a08: mov             x17, #0xd175
    //     0xd01a0c: add             lr, x0, x17
    //     0xd01a10: ldr             lr, [x21, lr, lsl #3]
    //     0xd01a14: blr             lr
    // 0xd01a18: add             SP, SP, #0x10
    // 0xd01a1c: mov             x3, x0
    // 0xd01a20: ldur            x0, [fp, #-0x30]
    // 0xd01a24: stur            x3, [fp, #-0x28]
    // 0xd01a28: add             x6, x0, #1
    // 0xd01a2c: stur            x6, [fp, #-0x40]
    // 0xd01a30: cmp             w3, NULL
    // 0xd01a34: b.ne            #0xd01a64
    // 0xd01a38: mov             x0, x3
    // 0xd01a3c: ldur            x2, [fp, #-8]
    // 0xd01a40: r1 = Null
    //     0xd01a40: mov             x1, NULL
    // 0xd01a44: cmp             w2, NULL
    // 0xd01a48: b.eq            #0xd01a64
    // 0xd01a4c: LoadField: r4 = r2->field_17
    //     0xd01a4c: ldur            w4, [x2, #0x17]
    // 0xd01a50: DecompressPointer r4
    //     0xd01a50: add             x4, x4, HEAP, lsl #32
    // 0xd01a54: r8 = X0
    //     0xd01a54: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xd01a58: LoadField: r9 = r4->field_7
    //     0xd01a58: ldur            x9, [x4, #7]
    // 0xd01a5c: r3 = Null
    //     0xd01a5c: ldr             x3, [PP, #0x7220]  ; [pp+0x7220] Null
    // 0xd01a60: blr             x9
    // 0xd01a64: ldur            x0, [fp, #-0x28]
    // 0xd01a68: r1 = LoadClassIdInstr(r0)
    //     0xd01a68: ldur            x1, [x0, #-1]
    //     0xd01a6c: ubfx            x1, x1, #0xc, #0x14
    // 0xd01a70: stp             xzr, x0, [SP, #-0x10]!
    // 0xd01a74: ldr             x16, [fp, #0x20]
    // 0xd01a78: ldr             lr, [fp, #0x18]
    // 0xd01a7c: stp             lr, x16, [SP, #-0x10]!
    // 0xd01a80: ldur            x16, [fp, #-0x20]
    // 0xd01a84: SaveReg r16
    //     0xd01a84: str             x16, [SP, #-8]!
    // 0xd01a88: mov             x0, x1
    // 0xd01a8c: r0 = GDT[cid_x0 + -0xffe]()
    //     0xd01a8c: sub             lr, x0, #0xffe
    //     0xd01a90: ldr             lr, [x21, lr, lsl #3]
    //     0xd01a94: blr             lr
    // 0xd01a98: add             SP, SP, #0x28
    // 0xd01a9c: ldur            x6, [fp, #-0x40]
    // 0xd01aa0: ldur            x1, [fp, #-0x20]
    // 0xd01aa4: ldur            x2, [fp, #-0x18]
    // 0xd01aa8: ldur            x3, [fp, #-8]
    // 0xd01aac: ldur            x4, [fp, #-0x38]
    // 0xd01ab0: b               #0xd018c8
    // 0xd01ab4: ldur            x0, [fp, #-0x18]
    // 0xd01ab8: r0 = ConcurrentModificationError()
    //     0xd01ab8: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xd01abc: ldur            x3, [fp, #-0x18]
    // 0xd01ac0: StoreField: r0->field_b = r3
    //     0xd01ac0: stur            w3, [x0, #0xb]
    // 0xd01ac4: r0 = Throw()
    //     0xd01ac4: bl              #0xd67e38  ; ThrowStub
    // 0xd01ac8: brk             #0
    // 0xd01acc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd01acc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01ad0: b               #0xd01700
    // 0xd01ad4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd01ad4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd01ad8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd01ad8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd01adc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd01adc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd01ae0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd01ae0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01ae4: b               #0xd018dc
    // 0xd01ae8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd01ae8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 2021, size: 0x10, field offset: 0xc
class _ContainerSemanticsFragment extends _SemanticsFragment {

  _ addAll(/* No info */) {
    // ** addr: 0xd008e4, size: 0x48
    // 0xd008e4: EnterFrame
    //     0xd008e4: stp             fp, lr, [SP, #-0x10]!
    //     0xd008e8: mov             fp, SP
    // 0xd008ec: CheckStackOverflow
    //     0xd008ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd008f0: cmp             SP, x16
    //     0xd008f4: b.ls            #0xd00924
    // 0xd008f8: ldr             x0, [fp, #0x18]
    // 0xd008fc: LoadField: r1 = r0->field_b
    //     0xd008fc: ldur            w1, [x0, #0xb]
    // 0xd00900: DecompressPointer r1
    //     0xd00900: add             x1, x1, HEAP, lsl #32
    // 0xd00904: ldr             x16, [fp, #0x10]
    // 0xd00908: stp             x16, x1, [SP, #-0x10]!
    // 0xd0090c: r0 = addAll()
    //     0xd0090c: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0xd00910: add             SP, SP, #0x10
    // 0xd00914: r0 = Null
    //     0xd00914: mov             x0, NULL
    // 0xd00918: LeaveFrame
    //     0xd00918: mov             SP, fp
    //     0xd0091c: ldp             fp, lr, [SP], #0x10
    // 0xd00920: ret
    //     0xd00920: ret             
    // 0xd00924: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd00924: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd00928: b               #0xd008f8
  }
}

// class id: 2022, size: 0x3c, field offset: 0x8
class PipelineOwner extends Object {

  _ requestVisualUpdate(/* No info */) {
    // ** addr: 0x50fd88, size: 0x58
    // 0x50fd88: EnterFrame
    //     0x50fd88: stp             fp, lr, [SP, #-0x10]!
    //     0x50fd8c: mov             fp, SP
    // 0x50fd90: CheckStackOverflow
    //     0x50fd90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50fd94: cmp             SP, x16
    //     0x50fd98: b.ls            #0x50fdd8
    // 0x50fd9c: ldr             x0, [fp, #0x10]
    // 0x50fda0: LoadField: r1 = r0->field_7
    //     0x50fda0: ldur            w1, [x0, #7]
    // 0x50fda4: DecompressPointer r1
    //     0x50fda4: add             x1, x1, HEAP, lsl #32
    // 0x50fda8: cmp             w1, NULL
    // 0x50fdac: b.eq            #0x50fdc8
    // 0x50fdb0: SaveReg r1
    //     0x50fdb0: str             x1, [SP, #-8]!
    // 0x50fdb4: mov             x0, x1
    // 0x50fdb8: ClosureCall
    //     0x50fdb8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x50fdbc: ldur            x2, [x0, #0x1f]
    //     0x50fdc0: blr             x2
    // 0x50fdc4: add             SP, SP, #8
    // 0x50fdc8: r0 = Null
    //     0x50fdc8: mov             x0, NULL
    // 0x50fdcc: LeaveFrame
    //     0x50fdcc: mov             SP, fp
    //     0x50fdd0: ldp             fp, lr, [SP], #0x10
    // 0x50fdd4: ret
    //     0x50fdd4: ret             
    // 0x50fdd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50fdd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50fddc: b               #0x50fd9c
  }
  _ _didDisposeSemanticsHandle(/* No info */) {
    // ** addr: 0x5bb5b4, size: 0x90
    // 0x5bb5b4: EnterFrame
    //     0x5bb5b4: stp             fp, lr, [SP, #-0x10]!
    //     0x5bb5b8: mov             fp, SP
    // 0x5bb5bc: CheckStackOverflow
    //     0x5bb5bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5bb5c0: cmp             SP, x16
    //     0x5bb5c4: b.ls            #0x5bb638
    // 0x5bb5c8: ldr             x0, [fp, #0x10]
    // 0x5bb5cc: LoadField: r1 = r0->field_2f
    //     0x5bb5cc: ldur            x1, [x0, #0x2f]
    // 0x5bb5d0: sub             x2, x1, #1
    // 0x5bb5d4: StoreField: r0->field_2f = r2
    //     0x5bb5d4: stur            x2, [x0, #0x2f]
    // 0x5bb5d8: cbnz            x2, #0x5bb628
    // 0x5bb5dc: LoadField: r1 = r0->field_2b
    //     0x5bb5dc: ldur            w1, [x0, #0x2b]
    // 0x5bb5e0: DecompressPointer r1
    //     0x5bb5e0: add             x1, x1, HEAP, lsl #32
    // 0x5bb5e4: cmp             w1, NULL
    // 0x5bb5e8: b.eq            #0x5bb640
    // 0x5bb5ec: SaveReg r1
    //     0x5bb5ec: str             x1, [SP, #-8]!
    // 0x5bb5f0: r0 = dispose()
    //     0x5bb5f0: bl              #0x9c2864  ; [package:flutter/src/semantics/semantics.dart] SemanticsOwner::dispose
    // 0x5bb5f4: add             SP, SP, #8
    // 0x5bb5f8: ldr             x0, [fp, #0x10]
    // 0x5bb5fc: StoreField: r0->field_2b = rNULL
    //     0x5bb5fc: stur            NULL, [x0, #0x2b]
    // 0x5bb600: LoadField: r1 = r0->field_13
    //     0x5bb600: ldur            w1, [x0, #0x13]
    // 0x5bb604: DecompressPointer r1
    //     0x5bb604: add             x1, x1, HEAP, lsl #32
    // 0x5bb608: cmp             w1, NULL
    // 0x5bb60c: b.eq            #0x5bb628
    // 0x5bb610: SaveReg r1
    //     0x5bb610: str             x1, [SP, #-8]!
    // 0x5bb614: mov             x0, x1
    // 0x5bb618: ClosureCall
    //     0x5bb618: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x5bb61c: ldur            x2, [x0, #0x1f]
    //     0x5bb620: blr             x2
    // 0x5bb624: add             SP, SP, #8
    // 0x5bb628: r0 = Null
    //     0x5bb628: mov             x0, NULL
    // 0x5bb62c: LeaveFrame
    //     0x5bb62c: mov             SP, fp
    //     0x5bb630: ldp             fp, lr, [SP], #0x10
    // 0x5bb634: ret
    //     0x5bb634: ret             
    // 0x5bb638: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5bb638: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5bb63c: b               #0x5bb5c8
    // 0x5bb640: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5bb640: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ ensureSemantics(/* No info */) {
    // ** addr: 0x5bb644, size: 0x130
    // 0x5bb644: EnterFrame
    //     0x5bb644: stp             fp, lr, [SP, #-0x10]!
    //     0x5bb648: mov             fp, SP
    // 0x5bb64c: AllocStack(0x20)
    //     0x5bb64c: sub             SP, SP, #0x20
    // 0x5bb650: SetupParameters(PipelineOwner this /* r3, fp-0x18 */, {dynamic listener = Null /* r0, fp-0x10 */})
    //     0x5bb650: mov             x0, x4
    //     0x5bb654: ldur            w1, [x0, #0x13]
    //     0x5bb658: add             x1, x1, HEAP, lsl #32
    //     0x5bb65c: sub             x2, x1, #2
    //     0x5bb660: add             x3, fp, w2, sxtw #2
    //     0x5bb664: ldr             x3, [x3, #0x10]
    //     0x5bb668: stur            x3, [fp, #-0x18]
    //     0x5bb66c: ldur            w2, [x0, #0x1f]
    //     0x5bb670: add             x2, x2, HEAP, lsl #32
    //     0x5bb674: ldr             x16, [PP, #0x4d60]  ; [pp+0x4d60] "listener"
    //     0x5bb678: cmp             w2, w16
    //     0x5bb67c: b.ne            #0x5bb69c
    //     0x5bb680: ldur            w2, [x0, #0x23]
    //     0x5bb684: add             x2, x2, HEAP, lsl #32
    //     0x5bb688: sub             w0, w1, w2
    //     0x5bb68c: add             x1, fp, w0, sxtw #2
    //     0x5bb690: ldr             x1, [x1, #8]
    //     0x5bb694: mov             x0, x1
    //     0x5bb698: b               #0x5bb6a0
    //     0x5bb69c: mov             x0, NULL
    //     0x5bb6a0: stur            x0, [fp, #-0x10]
    // 0x5bb6a4: CheckStackOverflow
    //     0x5bb6a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5bb6a8: cmp             SP, x16
    //     0x5bb6ac: b.ls            #0x5bb768
    // 0x5bb6b0: LoadField: r1 = r3->field_2f
    //     0x5bb6b0: ldur            x1, [x3, #0x2f]
    // 0x5bb6b4: add             x2, x1, #1
    // 0x5bb6b8: StoreField: r3->field_2f = r2
    //     0x5bb6b8: stur            x2, [x3, #0x2f]
    // 0x5bb6bc: cmp             x2, #1
    // 0x5bb6c0: b.ne            #0x5bb738
    // 0x5bb6c4: LoadField: r1 = r3->field_f
    //     0x5bb6c4: ldur            w1, [x3, #0xf]
    // 0x5bb6c8: DecompressPointer r1
    //     0x5bb6c8: add             x1, x1, HEAP, lsl #32
    // 0x5bb6cc: stur            x1, [fp, #-8]
    // 0x5bb6d0: cmp             w1, NULL
    // 0x5bb6d4: b.eq            #0x5bb770
    // 0x5bb6d8: r0 = SemanticsOwner()
    //     0x5bb6d8: bl              #0x5bb9f0  ; AllocateSemanticsOwnerStub -> SemanticsOwner (size=0x34)
    // 0x5bb6dc: stur            x0, [fp, #-0x20]
    // 0x5bb6e0: ldur            x16, [fp, #-8]
    // 0x5bb6e4: stp             x16, x0, [SP, #-0x10]!
    // 0x5bb6e8: r0 = SemanticsOwner()
    //     0x5bb6e8: bl              #0x5bb820  ; [package:flutter/src/semantics/semantics.dart] SemanticsOwner::SemanticsOwner
    // 0x5bb6ec: add             SP, SP, #0x10
    // 0x5bb6f0: ldur            x0, [fp, #-0x20]
    // 0x5bb6f4: ldur            x1, [fp, #-0x18]
    // 0x5bb6f8: StoreField: r1->field_2b = r0
    //     0x5bb6f8: stur            w0, [x1, #0x2b]
    //     0x5bb6fc: ldurb           w16, [x1, #-1]
    //     0x5bb700: ldurb           w17, [x0, #-1]
    //     0x5bb704: and             x16, x17, x16, lsr #2
    //     0x5bb708: tst             x16, HEAP, lsr #32
    //     0x5bb70c: b.eq            #0x5bb714
    //     0x5bb710: bl              #0xd6826c
    // 0x5bb714: LoadField: r0 = r1->field_b
    //     0x5bb714: ldur            w0, [x1, #0xb]
    // 0x5bb718: DecompressPointer r0
    //     0x5bb718: add             x0, x0, HEAP, lsl #32
    // 0x5bb71c: cmp             w0, NULL
    // 0x5bb720: b.eq            #0x5bb738
    // 0x5bb724: SaveReg r0
    //     0x5bb724: str             x0, [SP, #-8]!
    // 0x5bb728: ClosureCall
    //     0x5bb728: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x5bb72c: ldur            x2, [x0, #0x1f]
    //     0x5bb730: blr             x2
    // 0x5bb734: add             SP, SP, #8
    // 0x5bb738: r0 = SemanticsHandle()
    //     0x5bb738: bl              #0x5bb814  ; AllocateSemanticsHandleStub -> SemanticsHandle (size=0x10)
    // 0x5bb73c: stur            x0, [fp, #-8]
    // 0x5bb740: ldur            x16, [fp, #-0x18]
    // 0x5bb744: stp             x16, x0, [SP, #-0x10]!
    // 0x5bb748: ldur            x16, [fp, #-0x10]
    // 0x5bb74c: SaveReg r16
    //     0x5bb74c: str             x16, [SP, #-8]!
    // 0x5bb750: r0 = SemanticsHandle._()
    //     0x5bb750: bl              #0x5bb774  ; [package:flutter/src/rendering/object.dart] SemanticsHandle::SemanticsHandle._
    // 0x5bb754: add             SP, SP, #0x18
    // 0x5bb758: ldur            x0, [fp, #-8]
    // 0x5bb75c: LeaveFrame
    //     0x5bb75c: mov             SP, fp
    //     0x5bb760: ldp             fp, lr, [SP], #0x10
    // 0x5bb764: ret
    //     0x5bb764: ret             
    // 0x5bb768: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5bb768: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5bb76c: b               #0x5bb6b0
    // 0x5bb770: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5bb770: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ rootNode=(/* No info */) {
    // ** addr: 0x5bc1b8, size: 0xa4
    // 0x5bc1b8: EnterFrame
    //     0x5bc1b8: stp             fp, lr, [SP, #-0x10]!
    //     0x5bc1bc: mov             fp, SP
    // 0x5bc1c0: CheckStackOverflow
    //     0x5bc1c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5bc1c4: cmp             SP, x16
    //     0x5bc1c8: b.ls            #0x5bc254
    // 0x5bc1cc: ldr             x0, [fp, #0x18]
    // 0x5bc1d0: LoadField: r1 = r0->field_17
    //     0x5bc1d0: ldur            w1, [x0, #0x17]
    // 0x5bc1d4: DecompressPointer r1
    //     0x5bc1d4: add             x1, x1, HEAP, lsl #32
    // 0x5bc1d8: ldr             x2, [fp, #0x10]
    // 0x5bc1dc: cmp             w1, w2
    // 0x5bc1e0: b.ne            #0x5bc1f4
    // 0x5bc1e4: r0 = Null
    //     0x5bc1e4: mov             x0, NULL
    // 0x5bc1e8: LeaveFrame
    //     0x5bc1e8: mov             SP, fp
    //     0x5bc1ec: ldp             fp, lr, [SP], #0x10
    // 0x5bc1f0: ret
    //     0x5bc1f0: ret             
    // 0x5bc1f4: cmp             w1, NULL
    // 0x5bc1f8: b.ne            #0x5bc204
    // 0x5bc1fc: mov             x1, x0
    // 0x5bc200: b               #0x5bc214
    // 0x5bc204: SaveReg r1
    //     0x5bc204: str             x1, [SP, #-8]!
    // 0x5bc208: r0 = detach()
    //     0x5bc208: bl              #0xa6ad70  ; [package:flutter/src/rendering/view.dart] _RenderView&RenderObject&RenderObjectWithChildMixin::detach
    // 0x5bc20c: add             SP, SP, #8
    // 0x5bc210: ldr             x1, [fp, #0x18]
    // 0x5bc214: ldr             x0, [fp, #0x10]
    // 0x5bc218: StoreField: r1->field_17 = r0
    //     0x5bc218: stur            w0, [x1, #0x17]
    //     0x5bc21c: ldurb           w16, [x1, #-1]
    //     0x5bc220: ldurb           w17, [x0, #-1]
    //     0x5bc224: and             x16, x17, x16, lsr #2
    //     0x5bc228: tst             x16, HEAP, lsr #32
    //     0x5bc22c: b.eq            #0x5bc234
    //     0x5bc230: bl              #0xd6826c
    // 0x5bc234: ldr             x16, [fp, #0x10]
    // 0x5bc238: stp             x1, x16, [SP, #-0x10]!
    // 0x5bc23c: r0 = attach()
    //     0x5bc23c: bl              #0x9bf90c  ; [package:flutter/src/rendering/view.dart] _RenderView&RenderObject&RenderObjectWithChildMixin::attach
    // 0x5bc240: add             SP, SP, #0x10
    // 0x5bc244: r0 = Null
    //     0x5bc244: mov             x0, NULL
    // 0x5bc248: LeaveFrame
    //     0x5bc248: mov             SP, fp
    //     0x5bc24c: ldp             fp, lr, [SP], #0x10
    // 0x5bc250: ret
    //     0x5bc250: ret             
    // 0x5bc254: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5bc254: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5bc258: b               #0x5bc1cc
  }
  _ PipelineOwner(/* No info */) {
    // ** addr: 0x5bc890, size: 0x1e0
    // 0x5bc890: EnterFrame
    //     0x5bc890: stp             fp, lr, [SP, #-0x10]!
    //     0x5bc894: mov             fp, SP
    // 0x5bc898: AllocStack(0x10)
    //     0x5bc898: sub             SP, SP, #0x10
    // 0x5bc89c: r1 = false
    //     0x5bc89c: add             x1, NULL, #0x30  ; false
    // 0x5bc8a0: r0 = 0
    //     0x5bc8a0: mov             x0, #0
    // 0x5bc8a4: CheckStackOverflow
    //     0x5bc8a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5bc8a8: cmp             SP, x16
    //     0x5bc8ac: b.ls            #0x5bca68
    // 0x5bc8b0: ldr             x2, [fp, #0x30]
    // 0x5bc8b4: StoreField: r2->field_1b = r1
    //     0x5bc8b4: stur            w1, [x2, #0x1b]
    // 0x5bc8b8: StoreField: r2->field_2f = r0
    //     0x5bc8b8: stur            x0, [x2, #0x2f]
    // 0x5bc8bc: r16 = <RenderObject>
    //     0x5bc8bc: ldr             x16, [PP, #0x4988]  ; [pp+0x4988] TypeArguments: <RenderObject>
    // 0x5bc8c0: stp             xzr, x16, [SP, #-0x10]!
    // 0x5bc8c4: r0 = _GrowableList()
    //     0x5bc8c4: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x5bc8c8: add             SP, SP, #0x10
    // 0x5bc8cc: ldr             x1, [fp, #0x30]
    // 0x5bc8d0: StoreField: r1->field_1f = r0
    //     0x5bc8d0: stur            w0, [x1, #0x1f]
    //     0x5bc8d4: ldurb           w16, [x1, #-1]
    //     0x5bc8d8: ldurb           w17, [x0, #-1]
    //     0x5bc8dc: and             x16, x17, x16, lsr #2
    //     0x5bc8e0: tst             x16, HEAP, lsr #32
    //     0x5bc8e4: b.eq            #0x5bc8ec
    //     0x5bc8e8: bl              #0xd6826c
    // 0x5bc8ec: r16 = <RenderObject>
    //     0x5bc8ec: ldr             x16, [PP, #0x4988]  ; [pp+0x4988] TypeArguments: <RenderObject>
    // 0x5bc8f0: stp             xzr, x16, [SP, #-0x10]!
    // 0x5bc8f4: r0 = _GrowableList()
    //     0x5bc8f4: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x5bc8f8: add             SP, SP, #0x10
    // 0x5bc8fc: ldr             x1, [fp, #0x30]
    // 0x5bc900: StoreField: r1->field_23 = r0
    //     0x5bc900: stur            w0, [x1, #0x23]
    //     0x5bc904: ldurb           w16, [x1, #-1]
    //     0x5bc908: ldurb           w17, [x0, #-1]
    //     0x5bc90c: and             x16, x17, x16, lsr #2
    //     0x5bc910: tst             x16, HEAP, lsr #32
    //     0x5bc914: b.eq            #0x5bc91c
    //     0x5bc918: bl              #0xd6826c
    // 0x5bc91c: r16 = <RenderObject>
    //     0x5bc91c: ldr             x16, [PP, #0x4988]  ; [pp+0x4988] TypeArguments: <RenderObject>
    // 0x5bc920: stp             xzr, x16, [SP, #-0x10]!
    // 0x5bc924: r0 = _GrowableList()
    //     0x5bc924: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x5bc928: add             SP, SP, #0x10
    // 0x5bc92c: ldr             x1, [fp, #0x30]
    // 0x5bc930: StoreField: r1->field_27 = r0
    //     0x5bc930: stur            w0, [x1, #0x27]
    //     0x5bc934: ldurb           w16, [x1, #-1]
    //     0x5bc938: ldurb           w17, [x0, #-1]
    //     0x5bc93c: and             x16, x17, x16, lsr #2
    //     0x5bc940: tst             x16, HEAP, lsr #32
    //     0x5bc944: b.eq            #0x5bc94c
    //     0x5bc948: bl              #0xd6826c
    // 0x5bc94c: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x5bc94c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5bc950: ldr             x0, [x0, #0x598]
    //     0x5bc954: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5bc958: cmp             w0, w16
    //     0x5bc95c: b.ne            #0x5bc968
    //     0x5bc960: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x5bc964: bl              #0xd67cdc
    // 0x5bc968: r1 = <RenderObject>
    //     0x5bc968: ldr             x1, [PP, #0x4988]  ; [pp+0x4988] TypeArguments: <RenderObject>
    // 0x5bc96c: stur            x0, [fp, #-8]
    // 0x5bc970: r0 = _Set()
    //     0x5bc970: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x5bc974: mov             x1, x0
    // 0x5bc978: ldur            x0, [fp, #-8]
    // 0x5bc97c: stur            x1, [fp, #-0x10]
    // 0x5bc980: StoreField: r1->field_1b = r0
    //     0x5bc980: stur            w0, [x1, #0x1b]
    // 0x5bc984: StoreField: r1->field_b = rZR
    //     0x5bc984: stur            wzr, [x1, #0xb]
    // 0x5bc988: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x5bc988: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5bc98c: ldr             x0, [x0, #0x5a0]
    //     0x5bc990: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5bc994: cmp             w0, w16
    //     0x5bc998: b.ne            #0x5bc9a4
    //     0x5bc99c: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x5bc9a0: bl              #0xd67cdc
    // 0x5bc9a4: mov             x1, x0
    // 0x5bc9a8: ldur            x0, [fp, #-0x10]
    // 0x5bc9ac: StoreField: r0->field_f = r1
    //     0x5bc9ac: stur            w1, [x0, #0xf]
    // 0x5bc9b0: StoreField: r0->field_13 = rZR
    //     0x5bc9b0: stur            wzr, [x0, #0x13]
    // 0x5bc9b4: StoreField: r0->field_17 = rZR
    //     0x5bc9b4: stur            wzr, [x0, #0x17]
    // 0x5bc9b8: ldr             x1, [fp, #0x30]
    // 0x5bc9bc: StoreField: r1->field_37 = r0
    //     0x5bc9bc: stur            w0, [x1, #0x37]
    //     0x5bc9c0: ldurb           w16, [x1, #-1]
    //     0x5bc9c4: ldurb           w17, [x0, #-1]
    //     0x5bc9c8: and             x16, x17, x16, lsr #2
    //     0x5bc9cc: tst             x16, HEAP, lsr #32
    //     0x5bc9d0: b.eq            #0x5bc9d8
    //     0x5bc9d4: bl              #0xd6826c
    // 0x5bc9d8: ldr             x0, [fp, #0x28]
    // 0x5bc9dc: StoreField: r1->field_7 = r0
    //     0x5bc9dc: stur            w0, [x1, #7]
    //     0x5bc9e0: ldurb           w16, [x1, #-1]
    //     0x5bc9e4: ldurb           w17, [x0, #-1]
    //     0x5bc9e8: and             x16, x17, x16, lsr #2
    //     0x5bc9ec: tst             x16, HEAP, lsr #32
    //     0x5bc9f0: b.eq            #0x5bc9f8
    //     0x5bc9f4: bl              #0xd6826c
    // 0x5bc9f8: ldr             x0, [fp, #0x20]
    // 0x5bc9fc: StoreField: r1->field_b = r0
    //     0x5bc9fc: stur            w0, [x1, #0xb]
    //     0x5bca00: ldurb           w16, [x1, #-1]
    //     0x5bca04: ldurb           w17, [x0, #-1]
    //     0x5bca08: and             x16, x17, x16, lsr #2
    //     0x5bca0c: tst             x16, HEAP, lsr #32
    //     0x5bca10: b.eq            #0x5bca18
    //     0x5bca14: bl              #0xd6826c
    // 0x5bca18: ldr             x0, [fp, #0x10]
    // 0x5bca1c: StoreField: r1->field_f = r0
    //     0x5bca1c: stur            w0, [x1, #0xf]
    //     0x5bca20: ldurb           w16, [x1, #-1]
    //     0x5bca24: ldurb           w17, [x0, #-1]
    //     0x5bca28: and             x16, x17, x16, lsr #2
    //     0x5bca2c: tst             x16, HEAP, lsr #32
    //     0x5bca30: b.eq            #0x5bca38
    //     0x5bca34: bl              #0xd6826c
    // 0x5bca38: ldr             x0, [fp, #0x18]
    // 0x5bca3c: StoreField: r1->field_13 = r0
    //     0x5bca3c: stur            w0, [x1, #0x13]
    //     0x5bca40: ldurb           w16, [x1, #-1]
    //     0x5bca44: ldurb           w17, [x0, #-1]
    //     0x5bca48: and             x16, x17, x16, lsr #2
    //     0x5bca4c: tst             x16, HEAP, lsr #32
    //     0x5bca50: b.eq            #0x5bca58
    //     0x5bca54: bl              #0xd6826c
    // 0x5bca58: r0 = Null
    //     0x5bca58: mov             x0, NULL
    // 0x5bca5c: LeaveFrame
    //     0x5bca5c: mov             SP, fp
    //     0x5bca60: ldp             fp, lr, [SP], #0x10
    // 0x5bca64: ret
    //     0x5bca64: ret             
    // 0x5bca68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5bca68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5bca6c: b               #0x5bc8b0
  }
  _ flushSemantics(/* No info */) {
    // ** addr: 0x5ce698, size: 0x1cc
    // 0x5ce698: EnterFrame
    //     0x5ce698: stp             fp, lr, [SP, #-0x10]!
    //     0x5ce69c: mov             fp, SP
    // 0x5ce6a0: AllocStack(0x18)
    //     0x5ce6a0: sub             SP, SP, #0x18
    // 0x5ce6a4: CheckStackOverflow
    //     0x5ce6a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5ce6a8: cmp             SP, x16
    //     0x5ce6ac: b.ls            #0x5ce850
    // 0x5ce6b0: ldr             x0, [fp, #0x10]
    // 0x5ce6b4: LoadField: r1 = r0->field_2b
    //     0x5ce6b4: ldur            w1, [x0, #0x2b]
    // 0x5ce6b8: DecompressPointer r1
    //     0x5ce6b8: add             x1, x1, HEAP, lsl #32
    // 0x5ce6bc: cmp             w1, NULL
    // 0x5ce6c0: b.ne            #0x5ce6d4
    // 0x5ce6c4: r0 = Null
    //     0x5ce6c4: mov             x0, NULL
    // 0x5ce6c8: LeaveFrame
    //     0x5ce6c8: mov             SP, fp
    //     0x5ce6cc: ldp             fp, lr, [SP], #0x10
    // 0x5ce6d0: ret
    //     0x5ce6d0: ret             
    // 0x5ce6d4: LoadField: r1 = r0->field_37
    //     0x5ce6d4: ldur            w1, [x0, #0x37]
    // 0x5ce6d8: DecompressPointer r1
    //     0x5ce6d8: add             x1, x1, HEAP, lsl #32
    // 0x5ce6dc: stur            x1, [fp, #-8]
    // 0x5ce6e0: SaveReg r1
    //     0x5ce6e0: str             x1, [SP, #-8]!
    // 0x5ce6e4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x5ce6e4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x5ce6e8: r0 = toList()
    //     0x5ce6e8: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0x5ce6ec: add             SP, SP, #8
    // 0x5ce6f0: r1 = Function '<anonymous closure>':.
    //     0x5ce6f0: ldr             x1, [PP, #0x45b8]  ; [pp+0x45b8] AnonymousClosure: (0x5dbf44), in [package:flutter/src/rendering/object.dart] PipelineOwner::flushSemantics (0x5ce698)
    // 0x5ce6f4: r2 = Null
    //     0x5ce6f4: mov             x2, NULL
    // 0x5ce6f8: stur            x0, [fp, #-0x10]
    // 0x5ce6fc: r0 = AllocateClosure()
    //     0x5ce6fc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5ce700: ldur            x16, [fp, #-0x10]
    // 0x5ce704: stp             x0, x16, [SP, #-0x10]!
    // 0x5ce708: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x5ce708: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x5ce70c: r0 = sort()
    //     0x5ce70c: bl              #0x5edd6c  ; [dart:collection] _ListBase&Object&ListMixin::sort
    // 0x5ce710: add             SP, SP, #0x10
    // 0x5ce714: ldur            x16, [fp, #-8]
    // 0x5ce718: SaveReg r16
    //     0x5ce718: str             x16, [SP, #-8]!
    // 0x5ce71c: r0 = clear()
    //     0x5ce71c: bl              #0x536e88  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::clear
    // 0x5ce720: add             SP, SP, #8
    // 0x5ce724: ldur            x0, [fp, #-0x10]
    // 0x5ce728: r1 = LoadClassIdInstr(r0)
    //     0x5ce728: ldur            x1, [x0, #-1]
    //     0x5ce72c: ubfx            x1, x1, #0xc, #0x14
    // 0x5ce730: SaveReg r0
    //     0x5ce730: str             x0, [SP, #-8]!
    // 0x5ce734: mov             x0, x1
    // 0x5ce738: r0 = GDT[cid_x0 + 0xb940]()
    //     0x5ce738: mov             x17, #0xb940
    //     0x5ce73c: add             lr, x0, x17
    //     0x5ce740: ldr             lr, [x21, lr, lsl #3]
    //     0x5ce744: blr             lr
    // 0x5ce748: add             SP, SP, #8
    // 0x5ce74c: mov             x1, x0
    // 0x5ce750: stur            x1, [fp, #-8]
    // 0x5ce754: ldr             x2, [fp, #0x10]
    // 0x5ce758: CheckStackOverflow
    //     0x5ce758: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5ce75c: cmp             SP, x16
    //     0x5ce760: b.ls            #0x5ce858
    // 0x5ce764: r0 = LoadClassIdInstr(r1)
    //     0x5ce764: ldur            x0, [x1, #-1]
    //     0x5ce768: ubfx            x0, x0, #0xc, #0x14
    // 0x5ce76c: SaveReg r1
    //     0x5ce76c: str             x1, [SP, #-8]!
    // 0x5ce770: r0 = GDT[cid_x0 + 0x541]()
    //     0x5ce770: add             lr, x0, #0x541
    //     0x5ce774: ldr             lr, [x21, lr, lsl #3]
    //     0x5ce778: blr             lr
    // 0x5ce77c: add             SP, SP, #8
    // 0x5ce780: tbnz            w0, #4, #0x5ce820
    // 0x5ce784: ldur            x1, [fp, #-8]
    // 0x5ce788: r0 = LoadClassIdInstr(r1)
    //     0x5ce788: ldur            x0, [x1, #-1]
    //     0x5ce78c: ubfx            x0, x0, #0xc, #0x14
    // 0x5ce790: SaveReg r1
    //     0x5ce790: str             x1, [SP, #-8]!
    // 0x5ce794: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x5ce794: add             lr, x0, #0x5ca
    //     0x5ce798: ldr             lr, [x21, lr, lsl #3]
    //     0x5ce79c: blr             lr
    // 0x5ce7a0: add             SP, SP, #8
    // 0x5ce7a4: mov             x3, x0
    // 0x5ce7a8: stur            x3, [fp, #-0x18]
    // 0x5ce7ac: LoadField: r0 = r3->field_47
    //     0x5ce7ac: ldur            w0, [x3, #0x47]
    // 0x5ce7b0: DecompressPointer r0
    //     0x5ce7b0: add             x0, x0, HEAP, lsl #32
    // 0x5ce7b4: tbnz            w0, #4, #0x5ce818
    // 0x5ce7b8: ldr             x4, [fp, #0x10]
    // 0x5ce7bc: LoadField: r5 = r3->field_f
    //     0x5ce7bc: ldur            w5, [x3, #0xf]
    // 0x5ce7c0: DecompressPointer r5
    //     0x5ce7c0: add             x5, x5, HEAP, lsl #32
    // 0x5ce7c4: mov             x0, x5
    // 0x5ce7c8: stur            x5, [fp, #-0x10]
    // 0x5ce7cc: r2 = Null
    //     0x5ce7cc: mov             x2, NULL
    // 0x5ce7d0: r1 = Null
    //     0x5ce7d0: mov             x1, NULL
    // 0x5ce7d4: r4 = 59
    //     0x5ce7d4: mov             x4, #0x3b
    // 0x5ce7d8: branchIfSmi(r0, 0x5ce7e4)
    //     0x5ce7d8: tbz             w0, #0, #0x5ce7e4
    // 0x5ce7dc: r4 = LoadClassIdInstr(r0)
    //     0x5ce7dc: ldur            x4, [x0, #-1]
    //     0x5ce7e0: ubfx            x4, x4, #0xc, #0x14
    // 0x5ce7e4: cmp             x4, #0x7e6
    // 0x5ce7e8: b.eq            #0x5ce7f8
    // 0x5ce7ec: r8 = PipelineOwner?
    //     0x5ce7ec: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x5ce7f0: r3 = Null
    //     0x5ce7f0: ldr             x3, [PP, #0x45d0]  ; [pp+0x45d0] Null
    // 0x5ce7f4: r0 = DefaultNullableTypeTest()
    //     0x5ce7f4: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x5ce7f8: ldr             x0, [fp, #0x10]
    // 0x5ce7fc: ldur            x1, [fp, #-0x10]
    // 0x5ce800: cmp             w1, w0
    // 0x5ce804: b.ne            #0x5ce818
    // 0x5ce808: ldur            x16, [fp, #-0x18]
    // 0x5ce80c: SaveReg r16
    //     0x5ce80c: str             x16, [SP, #-8]!
    // 0x5ce810: r0 = _updateSemantics()
    //     0x5ce810: bl              #0x5dc008  ; [package:flutter/src/rendering/object.dart] RenderObject::_updateSemantics
    // 0x5ce814: add             SP, SP, #8
    // 0x5ce818: ldur            x1, [fp, #-8]
    // 0x5ce81c: b               #0x5ce754
    // 0x5ce820: ldr             x0, [fp, #0x10]
    // 0x5ce824: LoadField: r1 = r0->field_2b
    //     0x5ce824: ldur            w1, [x0, #0x2b]
    // 0x5ce828: DecompressPointer r1
    //     0x5ce828: add             x1, x1, HEAP, lsl #32
    // 0x5ce82c: cmp             w1, NULL
    // 0x5ce830: b.eq            #0x5ce860
    // 0x5ce834: SaveReg r1
    //     0x5ce834: str             x1, [SP, #-8]!
    // 0x5ce838: r0 = sendSemanticsUpdate()
    //     0x5ce838: bl              #0x5ce864  ; [package:flutter/src/semantics/semantics.dart] SemanticsOwner::sendSemanticsUpdate
    // 0x5ce83c: add             SP, SP, #8
    // 0x5ce840: r0 = Null
    //     0x5ce840: mov             x0, NULL
    // 0x5ce844: LeaveFrame
    //     0x5ce844: mov             SP, fp
    //     0x5ce848: ldp             fp, lr, [SP], #0x10
    // 0x5ce84c: ret
    //     0x5ce84c: ret             
    // 0x5ce850: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5ce850: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5ce854: b               #0x5ce6b0
    // 0x5ce858: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5ce858: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5ce85c: b               #0x5ce764
    // 0x5ce860: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5ce860: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] int <anonymous closure>(dynamic, RenderObject, RenderObject) {
    // ** addr: 0x5dbf44, size: 0x3c
    // 0x5dbf44: EnterFrame
    //     0x5dbf44: stp             fp, lr, [SP, #-0x10]!
    //     0x5dbf48: mov             fp, SP
    // 0x5dbf4c: ldr             x2, [fp, #0x18]
    // 0x5dbf50: LoadField: r3 = r2->field_7
    //     0x5dbf50: ldur            x3, [x2, #7]
    // 0x5dbf54: ldr             x2, [fp, #0x10]
    // 0x5dbf58: LoadField: r4 = r2->field_7
    //     0x5dbf58: ldur            x4, [x2, #7]
    // 0x5dbf5c: sub             x2, x3, x4
    // 0x5dbf60: r0 = BoxInt64Instr(r2)
    //     0x5dbf60: sbfiz           x0, x2, #1, #0x1f
    //     0x5dbf64: cmp             x2, x0, asr #1
    //     0x5dbf68: b.eq            #0x5dbf74
    //     0x5dbf6c: bl              #0xd69bb8
    //     0x5dbf70: stur            x2, [x0, #7]
    // 0x5dbf74: LeaveFrame
    //     0x5dbf74: mov             SP, fp
    //     0x5dbf78: ldp             fp, lr, [SP], #0x10
    // 0x5dbf7c: ret
    //     0x5dbf7c: ret             
  }
  _ flushPaint(/* No info */) {
    // ** addr: 0x5de360, size: 0x300
    // 0x5de360: EnterFrame
    //     0x5de360: stp             fp, lr, [SP, #-0x10]!
    //     0x5de364: mov             fp, SP
    // 0x5de368: AllocStack(0x40)
    //     0x5de368: sub             SP, SP, #0x40
    // 0x5de36c: CheckStackOverflow
    //     0x5de36c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5de370: cmp             SP, x16
    //     0x5de374: b.ls            #0x5de64c
    // 0x5de378: ldr             x0, [fp, #0x10]
    // 0x5de37c: LoadField: r1 = r0->field_27
    //     0x5de37c: ldur            w1, [x0, #0x27]
    // 0x5de380: DecompressPointer r1
    //     0x5de380: add             x1, x1, HEAP, lsl #32
    // 0x5de384: stur            x1, [fp, #-8]
    // 0x5de388: r16 = <RenderObject>
    //     0x5de388: ldr             x16, [PP, #0x4988]  ; [pp+0x4988] TypeArguments: <RenderObject>
    // 0x5de38c: stp             xzr, x16, [SP, #-0x10]!
    // 0x5de390: r0 = _GrowableList()
    //     0x5de390: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x5de394: add             SP, SP, #0x10
    // 0x5de398: ldr             x3, [fp, #0x10]
    // 0x5de39c: StoreField: r3->field_27 = r0
    //     0x5de39c: stur            w0, [x3, #0x27]
    //     0x5de3a0: ldurb           w16, [x3, #-1]
    //     0x5de3a4: ldurb           w17, [x0, #-1]
    //     0x5de3a8: and             x16, x17, x16, lsr #2
    //     0x5de3ac: tst             x16, HEAP, lsr #32
    //     0x5de3b0: b.eq            #0x5de3b8
    //     0x5de3b4: bl              #0xd682ac
    // 0x5de3b8: r1 = Function '<anonymous closure>':.
    //     0x5de3b8: ldr             x1, [PP, #0x4a00]  ; [pp+0x4a00] AnonymousClosure: (0x5df6dc), in [package:flutter/src/rendering/object.dart] PipelineOwner::flushPaint (0x5de360)
    // 0x5de3bc: r2 = Null
    //     0x5de3bc: mov             x2, NULL
    // 0x5de3c0: r0 = AllocateClosure()
    //     0x5de3c0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5de3c4: ldur            x16, [fp, #-8]
    // 0x5de3c8: stp             x0, x16, [SP, #-0x10]!
    // 0x5de3cc: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x5de3cc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x5de3d0: r0 = sort()
    //     0x5de3d0: bl              #0x5edd6c  ; [dart:collection] _ListBase&Object&ListMixin::sort
    // 0x5de3d4: add             SP, SP, #0x10
    // 0x5de3d8: ldur            x1, [fp, #-8]
    // 0x5de3dc: LoadField: r2 = r1->field_7
    //     0x5de3dc: ldur            w2, [x1, #7]
    // 0x5de3e0: DecompressPointer r2
    //     0x5de3e0: add             x2, x2, HEAP, lsl #32
    // 0x5de3e4: stur            x2, [fp, #-0x20]
    // 0x5de3e8: LoadField: r0 = r1->field_b
    //     0x5de3e8: ldur            w0, [x1, #0xb]
    // 0x5de3ec: DecompressPointer r0
    //     0x5de3ec: add             x0, x0, HEAP, lsl #32
    // 0x5de3f0: r3 = LoadInt32Instr(r0)
    //     0x5de3f0: sbfx            x3, x0, #1, #0x1f
    // 0x5de3f4: stur            x3, [fp, #-0x18]
    // 0x5de3f8: r5 = 0
    //     0x5de3f8: mov             x5, #0
    // 0x5de3fc: ldr             x4, [fp, #0x10]
    // 0x5de400: stur            x5, [fp, #-0x10]
    // 0x5de404: CheckStackOverflow
    //     0x5de404: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5de408: cmp             SP, x16
    //     0x5de40c: b.ls            #0x5de654
    // 0x5de410: r0 = LoadClassIdInstr(r1)
    //     0x5de410: ldur            x0, [x1, #-1]
    //     0x5de414: ubfx            x0, x0, #0xc, #0x14
    // 0x5de418: SaveReg r1
    //     0x5de418: str             x1, [SP, #-8]!
    // 0x5de41c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x5de41c: mov             x17, #0xb8ea
    //     0x5de420: add             lr, x0, x17
    //     0x5de424: ldr             lr, [x21, lr, lsl #3]
    //     0x5de428: blr             lr
    // 0x5de42c: add             SP, SP, #8
    // 0x5de430: r1 = LoadInt32Instr(r0)
    //     0x5de430: sbfx            x1, x0, #1, #0x1f
    //     0x5de434: tbz             w0, #0, #0x5de43c
    //     0x5de438: ldur            x1, [x0, #7]
    // 0x5de43c: ldur            x2, [fp, #-0x18]
    // 0x5de440: cmp             x2, x1
    // 0x5de444: b.ne            #0x5de634
    // 0x5de448: ldur            x3, [fp, #-8]
    // 0x5de44c: ldur            x4, [fp, #-0x10]
    // 0x5de450: cmp             x4, x1
    // 0x5de454: b.lt            #0x5de468
    // 0x5de458: r0 = Null
    //     0x5de458: mov             x0, NULL
    // 0x5de45c: LeaveFrame
    //     0x5de45c: mov             SP, fp
    //     0x5de460: ldp             fp, lr, [SP], #0x10
    // 0x5de464: ret
    //     0x5de464: ret             
    // 0x5de468: r0 = BoxInt64Instr(r4)
    //     0x5de468: sbfiz           x0, x4, #1, #0x1f
    //     0x5de46c: cmp             x4, x0, asr #1
    //     0x5de470: b.eq            #0x5de47c
    //     0x5de474: bl              #0xd69bb8
    //     0x5de478: stur            x4, [x0, #7]
    // 0x5de47c: r1 = LoadClassIdInstr(r3)
    //     0x5de47c: ldur            x1, [x3, #-1]
    //     0x5de480: ubfx            x1, x1, #0xc, #0x14
    // 0x5de484: stp             x0, x3, [SP, #-0x10]!
    // 0x5de488: mov             x0, x1
    // 0x5de48c: r0 = GDT[cid_x0 + 0xd175]()
    //     0x5de48c: mov             x17, #0xd175
    //     0x5de490: add             lr, x0, x17
    //     0x5de494: ldr             lr, [x21, lr, lsl #3]
    //     0x5de498: blr             lr
    // 0x5de49c: add             SP, SP, #0x10
    // 0x5de4a0: mov             x3, x0
    // 0x5de4a4: ldur            x0, [fp, #-0x10]
    // 0x5de4a8: stur            x3, [fp, #-0x30]
    // 0x5de4ac: add             x5, x0, #1
    // 0x5de4b0: stur            x5, [fp, #-0x28]
    // 0x5de4b4: cmp             w3, NULL
    // 0x5de4b8: b.ne            #0x5de4e8
    // 0x5de4bc: mov             x0, x3
    // 0x5de4c0: ldur            x2, [fp, #-0x20]
    // 0x5de4c4: r1 = Null
    //     0x5de4c4: mov             x1, NULL
    // 0x5de4c8: cmp             w2, NULL
    // 0x5de4cc: b.eq            #0x5de4e8
    // 0x5de4d0: LoadField: r4 = r2->field_17
    //     0x5de4d0: ldur            w4, [x2, #0x17]
    // 0x5de4d4: DecompressPointer r4
    //     0x5de4d4: add             x4, x4, HEAP, lsl #32
    // 0x5de4d8: r8 = X0
    //     0x5de4d8: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5de4dc: LoadField: r9 = r4->field_7
    //     0x5de4dc: ldur            x9, [x4, #7]
    // 0x5de4e0: r3 = Null
    //     0x5de4e0: ldr             x3, [PP, #0x4a08]  ; [pp+0x4a08] Null
    // 0x5de4e4: blr             x9
    // 0x5de4e8: ldur            x3, [fp, #-0x30]
    // 0x5de4ec: LoadField: r4 = r3->field_3b
    //     0x5de4ec: ldur            w4, [x3, #0x3b]
    // 0x5de4f0: DecompressPointer r4
    //     0x5de4f0: add             x4, x4, HEAP, lsl #32
    // 0x5de4f4: stur            x4, [fp, #-0x40]
    // 0x5de4f8: tbz             w4, #4, #0x5de508
    // 0x5de4fc: LoadField: r0 = r3->field_3f
    //     0x5de4fc: ldur            w0, [x3, #0x3f]
    // 0x5de500: DecompressPointer r0
    //     0x5de500: add             x0, x0, HEAP, lsl #32
    // 0x5de504: tbnz            w0, #4, #0x5de620
    // 0x5de508: ldr             x5, [fp, #0x10]
    // 0x5de50c: LoadField: r6 = r3->field_f
    //     0x5de50c: ldur            w6, [x3, #0xf]
    // 0x5de510: DecompressPointer r6
    //     0x5de510: add             x6, x6, HEAP, lsl #32
    // 0x5de514: mov             x0, x6
    // 0x5de518: stur            x6, [fp, #-0x38]
    // 0x5de51c: r2 = Null
    //     0x5de51c: mov             x2, NULL
    // 0x5de520: r1 = Null
    //     0x5de520: mov             x1, NULL
    // 0x5de524: r4 = 59
    //     0x5de524: mov             x4, #0x3b
    // 0x5de528: branchIfSmi(r0, 0x5de534)
    //     0x5de528: tbz             w0, #0, #0x5de534
    // 0x5de52c: r4 = LoadClassIdInstr(r0)
    //     0x5de52c: ldur            x4, [x0, #-1]
    //     0x5de530: ubfx            x4, x4, #0xc, #0x14
    // 0x5de534: cmp             x4, #0x7e6
    // 0x5de538: b.eq            #0x5de548
    // 0x5de53c: r8 = PipelineOwner?
    //     0x5de53c: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x5de540: r3 = Null
    //     0x5de540: ldr             x3, [PP, #0x4a18]  ; [pp+0x4a18] Null
    // 0x5de544: r0 = DefaultNullableTypeTest()
    //     0x5de544: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x5de548: ldr             x0, [fp, #0x10]
    // 0x5de54c: ldur            x1, [fp, #-0x38]
    // 0x5de550: cmp             w1, w0
    // 0x5de554: b.ne            #0x5de620
    // 0x5de558: ldur            x3, [fp, #-0x30]
    // 0x5de55c: LoadField: r1 = r3->field_2f
    //     0x5de55c: ldur            w1, [x3, #0x2f]
    // 0x5de560: DecompressPointer r1
    //     0x5de560: add             x1, x1, HEAP, lsl #32
    // 0x5de564: LoadField: r4 = r1->field_b
    //     0x5de564: ldur            w4, [x1, #0xb]
    // 0x5de568: DecompressPointer r4
    //     0x5de568: add             x4, x4, HEAP, lsl #32
    // 0x5de56c: stur            x4, [fp, #-0x38]
    // 0x5de570: cmp             w4, NULL
    // 0x5de574: b.eq            #0x5de65c
    // 0x5de578: LoadField: r1 = r4->field_f
    //     0x5de578: ldur            w1, [x4, #0xf]
    // 0x5de57c: DecompressPointer r1
    //     0x5de57c: add             x1, x1, HEAP, lsl #32
    // 0x5de580: cmp             w1, NULL
    // 0x5de584: b.eq            #0x5de60c
    // 0x5de588: ldur            x1, [fp, #-0x40]
    // 0x5de58c: tbnz            w1, #4, #0x5de5a8
    // 0x5de590: SaveReg r3
    //     0x5de590: str             x3, [SP, #-8]!
    // 0x5de594: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x5de594: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x5de598: r0 = _repaintCompositedChild()
    //     0x5de598: bl              #0x5de838  ; [package:flutter/src/rendering/object.dart] PaintingContext::_repaintCompositedChild
    // 0x5de59c: add             SP, SP, #8
    // 0x5de5a0: r1 = false
    //     0x5de5a0: add             x1, NULL, #0x30  ; false
    // 0x5de5a4: b               #0x5de620
    // 0x5de5a8: mov             x0, x4
    // 0x5de5ac: r2 = Null
    //     0x5de5ac: mov             x2, NULL
    // 0x5de5b0: r1 = Null
    //     0x5de5b0: mov             x1, NULL
    // 0x5de5b4: r4 = LoadClassIdInstr(r0)
    //     0x5de5b4: ldur            x4, [x0, #-1]
    //     0x5de5b8: ubfx            x4, x4, #0xc, #0x14
    // 0x5de5bc: sub             x4, x4, #0x956
    // 0x5de5c0: cmp             x4, #3
    // 0x5de5c4: b.ls            #0x5de5d4
    // 0x5de5c8: r8 = OffsetLayer
    //     0x5de5c8: ldr             x8, [PP, #0x4a28]  ; [pp+0x4a28] Type: OffsetLayer
    // 0x5de5cc: r3 = Null
    //     0x5de5cc: ldr             x3, [PP, #0x4a30]  ; [pp+0x4a30] Null
    // 0x5de5d0: r0 = DefaultTypeTest()
    //     0x5de5d0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5de5d4: ldur            x1, [fp, #-0x30]
    // 0x5de5d8: r0 = LoadClassIdInstr(r1)
    //     0x5de5d8: ldur            x0, [x1, #-1]
    //     0x5de5dc: ubfx            x0, x0, #0xc, #0x14
    // 0x5de5e0: ldur            x16, [fp, #-0x38]
    // 0x5de5e4: stp             x16, x1, [SP, #-0x10]!
    // 0x5de5e8: r0 = GDT[cid_x0 + 0xe17b]()
    //     0x5de5e8: mov             x17, #0xe17b
    //     0x5de5ec: add             lr, x0, x17
    //     0x5de5f0: ldr             lr, [x21, lr, lsl #3]
    //     0x5de5f4: blr             lr
    // 0x5de5f8: add             SP, SP, #0x10
    // 0x5de5fc: ldur            x0, [fp, #-0x30]
    // 0x5de600: r1 = false
    //     0x5de600: add             x1, NULL, #0x30  ; false
    // 0x5de604: StoreField: r0->field_3f = r1
    //     0x5de604: stur            w1, [x0, #0x3f]
    // 0x5de608: b               #0x5de620
    // 0x5de60c: mov             x0, x3
    // 0x5de610: r1 = false
    //     0x5de610: add             x1, NULL, #0x30  ; false
    // 0x5de614: SaveReg r0
    //     0x5de614: str             x0, [SP, #-8]!
    // 0x5de618: r0 = _skippedPaintingOnLayer()
    //     0x5de618: bl              #0x5de714  ; [package:flutter/src/rendering/object.dart] RenderObject::_skippedPaintingOnLayer
    // 0x5de61c: add             SP, SP, #8
    // 0x5de620: ldur            x5, [fp, #-0x28]
    // 0x5de624: ldur            x1, [fp, #-8]
    // 0x5de628: ldur            x2, [fp, #-0x20]
    // 0x5de62c: ldur            x3, [fp, #-0x18]
    // 0x5de630: b               #0x5de3fc
    // 0x5de634: ldur            x0, [fp, #-8]
    // 0x5de638: r0 = ConcurrentModificationError()
    //     0x5de638: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x5de63c: ldur            x3, [fp, #-8]
    // 0x5de640: StoreField: r0->field_b = r3
    //     0x5de640: stur            w3, [x0, #0xb]
    // 0x5de644: r0 = Throw()
    //     0x5de644: bl              #0xd67e38  ; ThrowStub
    // 0x5de648: brk             #0
    // 0x5de64c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5de64c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5de650: b               #0x5de378
    // 0x5de654: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5de654: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5de658: b               #0x5de410
    // 0x5de65c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5de65c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] int <anonymous closure>(dynamic, RenderObject, RenderObject) {
    // ** addr: 0x5df6dc, size: 0x3c
    // 0x5df6dc: EnterFrame
    //     0x5df6dc: stp             fp, lr, [SP, #-0x10]!
    //     0x5df6e0: mov             fp, SP
    // 0x5df6e4: ldr             x2, [fp, #0x10]
    // 0x5df6e8: LoadField: r3 = r2->field_7
    //     0x5df6e8: ldur            x3, [x2, #7]
    // 0x5df6ec: ldr             x2, [fp, #0x18]
    // 0x5df6f0: LoadField: r4 = r2->field_7
    //     0x5df6f0: ldur            x4, [x2, #7]
    // 0x5df6f4: sub             x2, x3, x4
    // 0x5df6f8: r0 = BoxInt64Instr(r2)
    //     0x5df6f8: sbfiz           x0, x2, #1, #0x1f
    //     0x5df6fc: cmp             x2, x0, asr #1
    //     0x5df700: b.eq            #0x5df70c
    //     0x5df704: bl              #0xd69bb8
    //     0x5df708: stur            x2, [x0, #7]
    // 0x5df70c: LeaveFrame
    //     0x5df70c: mov             SP, fp
    //     0x5df710: ldp             fp, lr, [SP], #0x10
    // 0x5df714: ret
    //     0x5df714: ret             
  }
  _ flushCompositingBits(/* No info */) {
    // ** addr: 0x5df718, size: 0x210
    // 0x5df718: EnterFrame
    //     0x5df718: stp             fp, lr, [SP, #-0x10]!
    //     0x5df71c: mov             fp, SP
    // 0x5df720: AllocStack(0x38)
    //     0x5df720: sub             SP, SP, #0x38
    // 0x5df724: CheckStackOverflow
    //     0x5df724: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5df728: cmp             SP, x16
    //     0x5df72c: b.ls            #0x5df918
    // 0x5df730: ldr             x0, [fp, #0x10]
    // 0x5df734: LoadField: r3 = r0->field_23
    //     0x5df734: ldur            w3, [x0, #0x23]
    // 0x5df738: DecompressPointer r3
    //     0x5df738: add             x3, x3, HEAP, lsl #32
    // 0x5df73c: stur            x3, [fp, #-8]
    // 0x5df740: r1 = Function '<anonymous closure>':.
    //     0x5df740: ldr             x1, [PP, #0x4ae8]  ; [pp+0x4ae8] AnonymousClosure: (0x5dbf44), in [package:flutter/src/rendering/object.dart] PipelineOwner::flushSemantics (0x5ce698)
    // 0x5df744: r2 = Null
    //     0x5df744: mov             x2, NULL
    // 0x5df748: r0 = AllocateClosure()
    //     0x5df748: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5df74c: ldur            x16, [fp, #-8]
    // 0x5df750: stp             x0, x16, [SP, #-0x10]!
    // 0x5df754: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x5df754: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x5df758: r0 = sort()
    //     0x5df758: bl              #0x5edd6c  ; [dart:collection] _ListBase&Object&ListMixin::sort
    // 0x5df75c: add             SP, SP, #0x10
    // 0x5df760: ldur            x1, [fp, #-8]
    // 0x5df764: LoadField: r2 = r1->field_7
    //     0x5df764: ldur            w2, [x1, #7]
    // 0x5df768: DecompressPointer r2
    //     0x5df768: add             x2, x2, HEAP, lsl #32
    // 0x5df76c: stur            x2, [fp, #-0x20]
    // 0x5df770: LoadField: r0 = r1->field_b
    //     0x5df770: ldur            w0, [x1, #0xb]
    // 0x5df774: DecompressPointer r0
    //     0x5df774: add             x0, x0, HEAP, lsl #32
    // 0x5df778: r3 = LoadInt32Instr(r0)
    //     0x5df778: sbfx            x3, x0, #1, #0x1f
    // 0x5df77c: stur            x3, [fp, #-0x18]
    // 0x5df780: r5 = 0
    //     0x5df780: mov             x5, #0
    // 0x5df784: ldr             x4, [fp, #0x10]
    // 0x5df788: stur            x5, [fp, #-0x10]
    // 0x5df78c: CheckStackOverflow
    //     0x5df78c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5df790: cmp             SP, x16
    //     0x5df794: b.ls            #0x5df920
    // 0x5df798: r0 = LoadClassIdInstr(r1)
    //     0x5df798: ldur            x0, [x1, #-1]
    //     0x5df79c: ubfx            x0, x0, #0xc, #0x14
    // 0x5df7a0: SaveReg r1
    //     0x5df7a0: str             x1, [SP, #-8]!
    // 0x5df7a4: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x5df7a4: mov             x17, #0xb8ea
    //     0x5df7a8: add             lr, x0, x17
    //     0x5df7ac: ldr             lr, [x21, lr, lsl #3]
    //     0x5df7b0: blr             lr
    // 0x5df7b4: add             SP, SP, #8
    // 0x5df7b8: r1 = LoadInt32Instr(r0)
    //     0x5df7b8: sbfx            x1, x0, #1, #0x1f
    //     0x5df7bc: tbz             w0, #0, #0x5df7c4
    //     0x5df7c0: ldur            x1, [x0, #7]
    // 0x5df7c4: ldur            x2, [fp, #-0x18]
    // 0x5df7c8: cmp             x2, x1
    // 0x5df7cc: b.ne            #0x5df900
    // 0x5df7d0: ldur            x3, [fp, #-8]
    // 0x5df7d4: ldur            x4, [fp, #-0x10]
    // 0x5df7d8: cmp             x4, x1
    // 0x5df7dc: b.lt            #0x5df7fc
    // 0x5df7e0: SaveReg r3
    //     0x5df7e0: str             x3, [SP, #-8]!
    // 0x5df7e4: r0 = clear()
    //     0x5df7e4: bl              #0xd281bc  ; [dart:core] _GrowableList::clear
    // 0x5df7e8: add             SP, SP, #8
    // 0x5df7ec: r0 = Null
    //     0x5df7ec: mov             x0, NULL
    // 0x5df7f0: LeaveFrame
    //     0x5df7f0: mov             SP, fp
    //     0x5df7f4: ldp             fp, lr, [SP], #0x10
    // 0x5df7f8: ret
    //     0x5df7f8: ret             
    // 0x5df7fc: r0 = BoxInt64Instr(r4)
    //     0x5df7fc: sbfiz           x0, x4, #1, #0x1f
    //     0x5df800: cmp             x4, x0, asr #1
    //     0x5df804: b.eq            #0x5df810
    //     0x5df808: bl              #0xd69bb8
    //     0x5df80c: stur            x4, [x0, #7]
    // 0x5df810: r1 = LoadClassIdInstr(r3)
    //     0x5df810: ldur            x1, [x3, #-1]
    //     0x5df814: ubfx            x1, x1, #0xc, #0x14
    // 0x5df818: stp             x0, x3, [SP, #-0x10]!
    // 0x5df81c: mov             x0, x1
    // 0x5df820: r0 = GDT[cid_x0 + 0xd175]()
    //     0x5df820: mov             x17, #0xd175
    //     0x5df824: add             lr, x0, x17
    //     0x5df828: ldr             lr, [x21, lr, lsl #3]
    //     0x5df82c: blr             lr
    // 0x5df830: add             SP, SP, #0x10
    // 0x5df834: mov             x3, x0
    // 0x5df838: ldur            x0, [fp, #-0x10]
    // 0x5df83c: stur            x3, [fp, #-0x30]
    // 0x5df840: add             x5, x0, #1
    // 0x5df844: stur            x5, [fp, #-0x28]
    // 0x5df848: cmp             w3, NULL
    // 0x5df84c: b.ne            #0x5df87c
    // 0x5df850: mov             x0, x3
    // 0x5df854: ldur            x2, [fp, #-0x20]
    // 0x5df858: r1 = Null
    //     0x5df858: mov             x1, NULL
    // 0x5df85c: cmp             w2, NULL
    // 0x5df860: b.eq            #0x5df87c
    // 0x5df864: LoadField: r4 = r2->field_17
    //     0x5df864: ldur            w4, [x2, #0x17]
    // 0x5df868: DecompressPointer r4
    //     0x5df868: add             x4, x4, HEAP, lsl #32
    // 0x5df86c: r8 = X0
    //     0x5df86c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5df870: LoadField: r9 = r4->field_7
    //     0x5df870: ldur            x9, [x4, #7]
    // 0x5df874: r3 = Null
    //     0x5df874: ldr             x3, [PP, #0x4af0]  ; [pp+0x4af0] Null
    // 0x5df878: blr             x9
    // 0x5df87c: ldur            x3, [fp, #-0x30]
    // 0x5df880: LoadField: r0 = r3->field_33
    //     0x5df880: ldur            w0, [x3, #0x33]
    // 0x5df884: DecompressPointer r0
    //     0x5df884: add             x0, x0, HEAP, lsl #32
    // 0x5df888: tbnz            w0, #4, #0x5df8ec
    // 0x5df88c: ldr             x4, [fp, #0x10]
    // 0x5df890: LoadField: r5 = r3->field_f
    //     0x5df890: ldur            w5, [x3, #0xf]
    // 0x5df894: DecompressPointer r5
    //     0x5df894: add             x5, x5, HEAP, lsl #32
    // 0x5df898: mov             x0, x5
    // 0x5df89c: stur            x5, [fp, #-0x38]
    // 0x5df8a0: r2 = Null
    //     0x5df8a0: mov             x2, NULL
    // 0x5df8a4: r1 = Null
    //     0x5df8a4: mov             x1, NULL
    // 0x5df8a8: r4 = 59
    //     0x5df8a8: mov             x4, #0x3b
    // 0x5df8ac: branchIfSmi(r0, 0x5df8b8)
    //     0x5df8ac: tbz             w0, #0, #0x5df8b8
    // 0x5df8b0: r4 = LoadClassIdInstr(r0)
    //     0x5df8b0: ldur            x4, [x0, #-1]
    //     0x5df8b4: ubfx            x4, x4, #0xc, #0x14
    // 0x5df8b8: cmp             x4, #0x7e6
    // 0x5df8bc: b.eq            #0x5df8cc
    // 0x5df8c0: r8 = PipelineOwner?
    //     0x5df8c0: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x5df8c4: r3 = Null
    //     0x5df8c4: ldr             x3, [PP, #0x4b00]  ; [pp+0x4b00] Null
    // 0x5df8c8: r0 = DefaultNullableTypeTest()
    //     0x5df8c8: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x5df8cc: ldr             x0, [fp, #0x10]
    // 0x5df8d0: ldur            x1, [fp, #-0x38]
    // 0x5df8d4: cmp             w1, w0
    // 0x5df8d8: b.ne            #0x5df8ec
    // 0x5df8dc: ldur            x16, [fp, #-0x30]
    // 0x5df8e0: SaveReg r16
    //     0x5df8e0: str             x16, [SP, #-8]!
    // 0x5df8e4: r0 = _updateCompositingBits()
    //     0x5df8e4: bl              #0x5df928  ; [package:flutter/src/rendering/object.dart] RenderObject::_updateCompositingBits
    // 0x5df8e8: add             SP, SP, #8
    // 0x5df8ec: ldur            x5, [fp, #-0x28]
    // 0x5df8f0: ldur            x1, [fp, #-8]
    // 0x5df8f4: ldur            x2, [fp, #-0x20]
    // 0x5df8f8: ldur            x3, [fp, #-0x18]
    // 0x5df8fc: b               #0x5df784
    // 0x5df900: ldur            x0, [fp, #-8]
    // 0x5df904: r0 = ConcurrentModificationError()
    //     0x5df904: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x5df908: ldur            x3, [fp, #-8]
    // 0x5df90c: StoreField: r0->field_b = r3
    //     0x5df90c: stur            w3, [x0, #0xb]
    // 0x5df910: r0 = Throw()
    //     0x5df910: bl              #0xd67e38  ; ThrowStub
    // 0x5df914: brk             #0
    // 0x5df918: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5df918: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5df91c: b               #0x5df730
    // 0x5df920: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5df920: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5df924: b               #0x5df798
  }
  _ flushLayout(/* No info */) {
    // ** addr: 0x5dfc10, size: 0x2b8
    // 0x5dfc10: EnterFrame
    //     0x5dfc10: stp             fp, lr, [SP, #-0x10]!
    //     0x5dfc14: mov             fp, SP
    // 0x5dfc18: AllocStack(0x88)
    //     0x5dfc18: sub             SP, SP, #0x88
    // 0x5dfc1c: CheckStackOverflow
    //     0x5dfc1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5dfc20: cmp             SP, x16
    //     0x5dfc24: b.ls            #0x5dfeac
    // 0x5dfc28: ldr             x0, [fp, #0x10]
    // 0x5dfc2c: stur            x0, [fp, #-0x58]
    // 0x5dfc30: CheckStackOverflow
    //     0x5dfc30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5dfc34: cmp             SP, x16
    //     0x5dfc38: b.ls            #0x5dfeb4
    // 0x5dfc3c: LoadField: r1 = r0->field_1f
    //     0x5dfc3c: ldur            w1, [x0, #0x1f]
    // 0x5dfc40: DecompressPointer r1
    //     0x5dfc40: add             x1, x1, HEAP, lsl #32
    // 0x5dfc44: stur            x1, [fp, #-0x50]
    // 0x5dfc48: LoadField: r2 = r1->field_b
    //     0x5dfc48: ldur            w2, [x1, #0xb]
    // 0x5dfc4c: DecompressPointer r2
    //     0x5dfc4c: add             x2, x2, HEAP, lsl #32
    // 0x5dfc50: cbz             w2, #0x5dfe78
    // 0x5dfc54: r0 = InitLateStaticField(0x0) // [dart:core] _GrowableList<X0>::_emptyList
    //     0x5dfc54: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5dfc58: ldr             x0, [x0]
    //     0x5dfc5c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5dfc60: cmp             w0, w16
    //     0x5dfc64: b.ne            #0x5dfc70
    //     0x5dfc68: ldr             x2, [PP, #0x7c8]  ; [pp+0x7c8] Field <_GrowableList@0150898._emptyList@0150898>: static late final (offset: 0x0)
    //     0x5dfc6c: bl              #0xd67cdc
    // 0x5dfc70: r1 = <RenderObject>
    //     0x5dfc70: ldr             x1, [PP, #0x4988]  ; [pp+0x4988] TypeArguments: <RenderObject>
    // 0x5dfc74: stur            x0, [fp, #-0x60]
    // 0x5dfc78: r0 = AllocateGrowableArray()
    //     0x5dfc78: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x5dfc7c: mov             x1, x0
    // 0x5dfc80: ldur            x0, [fp, #-0x60]
    // 0x5dfc84: StoreField: r1->field_f = r0
    //     0x5dfc84: stur            w0, [x1, #0xf]
    // 0x5dfc88: StoreField: r1->field_b = rZR
    //     0x5dfc88: stur            wzr, [x1, #0xb]
    // 0x5dfc8c: mov             x0, x1
    // 0x5dfc90: ldur            x3, [fp, #-0x58]
    // 0x5dfc94: StoreField: r3->field_1f = r0
    //     0x5dfc94: stur            w0, [x3, #0x1f]
    //     0x5dfc98: ldurb           w16, [x3, #-1]
    //     0x5dfc9c: ldurb           w17, [x0, #-1]
    //     0x5dfca0: and             x16, x17, x16, lsr #2
    //     0x5dfca4: tst             x16, HEAP, lsr #32
    //     0x5dfca8: b.eq            #0x5dfcb0
    //     0x5dfcac: bl              #0xd682ac
    // 0x5dfcb0: r1 = Function '<anonymous closure>':.
    //     0x5dfcb0: ldr             x1, [PP, #0x4b38]  ; [pp+0x4b38] AnonymousClosure: (0x5dbf44), in [package:flutter/src/rendering/object.dart] PipelineOwner::flushSemantics (0x5ce698)
    // 0x5dfcb4: r2 = Null
    //     0x5dfcb4: mov             x2, NULL
    // 0x5dfcb8: r0 = AllocateClosure()
    //     0x5dfcb8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5dfcbc: mov             x1, x0
    // 0x5dfcc0: ldur            x0, [fp, #-0x50]
    // 0x5dfcc4: stur            x1, [fp, #-0x68]
    // 0x5dfcc8: LoadField: r2 = r0->field_7
    //     0x5dfcc8: ldur            w2, [x0, #7]
    // 0x5dfccc: DecompressPointer r2
    //     0x5dfccc: add             x2, x2, HEAP, lsl #32
    // 0x5dfcd0: stur            x2, [fp, #-0x60]
    // 0x5dfcd4: stp             x0, x2, [SP, #-0x10]!
    // 0x5dfcd8: SaveReg r1
    //     0x5dfcd8: str             x1, [SP, #-8]!
    // 0x5dfcdc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5dfcdc: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5dfce0: r0 = sort()
    //     0x5dfce0: bl              #0x4c8938  ; [dart:_internal] Sort::sort
    // 0x5dfce4: add             SP, SP, #0x18
    // 0x5dfce8: ldur            x5, [fp, #-0x58]
    // 0x5dfcec: ldur            x3, [fp, #-0x50]
    // 0x5dfcf0: r4 = 0
    //     0x5dfcf0: mov             x4, #0
    // 0x5dfcf4: r2 = false
    //     0x5dfcf4: add             x2, NULL, #0x30  ; false
    // 0x5dfcf8: stur            x5, [fp, #-0x70]
    // 0x5dfcfc: stur            x4, [fp, #-0x78]
    // 0x5dfd00: stur            x3, [fp, #-0x80]
    // 0x5dfd04: CheckStackOverflow
    //     0x5dfd04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5dfd08: cmp             SP, x16
    //     0x5dfd0c: b.ls            #0x5dfebc
    // 0x5dfd10: LoadField: r6 = r3->field_b
    //     0x5dfd10: ldur            w6, [x3, #0xb]
    // 0x5dfd14: DecompressPointer r6
    //     0x5dfd14: add             x6, x6, HEAP, lsl #32
    // 0x5dfd18: stur            x6, [fp, #-0x68]
    // 0x5dfd1c: r7 = LoadInt32Instr(r6)
    //     0x5dfd1c: sbfx            x7, x6, #1, #0x1f
    // 0x5dfd20: cmp             x4, x7
    // 0x5dfd24: b.ge            #0x5dfe68
    // 0x5dfd28: LoadField: r0 = r5->field_1b
    //     0x5dfd28: ldur            w0, [x5, #0x1b]
    // 0x5dfd2c: DecompressPointer r0
    //     0x5dfd2c: add             x0, x0, HEAP, lsl #32
    // 0x5dfd30: tbnz            w0, #4, #0x5dfdb8
    // 0x5dfd34: StoreField: r5->field_1b = r2
    //     0x5dfd34: stur            w2, [x5, #0x1b]
    // 0x5dfd38: LoadField: r8 = r5->field_1f
    //     0x5dfd38: ldur            w8, [x5, #0x1f]
    // 0x5dfd3c: DecompressPointer r8
    //     0x5dfd3c: add             x8, x8, HEAP, lsl #32
    // 0x5dfd40: stur            x8, [fp, #-0x50]
    // 0x5dfd44: LoadField: r0 = r8->field_b
    //     0x5dfd44: ldur            w0, [x8, #0xb]
    // 0x5dfd48: DecompressPointer r0
    //     0x5dfd48: add             x0, x0, HEAP, lsl #32
    // 0x5dfd4c: cbz             w0, #0x5dfdb8
    // 0x5dfd50: r0 = BoxInt64Instr(r4)
    //     0x5dfd50: sbfiz           x0, x4, #1, #0x1f
    //     0x5dfd54: cmp             x4, x0, asr #1
    //     0x5dfd58: b.eq            #0x5dfd64
    //     0x5dfd5c: bl              #0xd69bb8
    //     0x5dfd60: stur            x4, [x0, #7]
    // 0x5dfd64: stp             x6, x0, [SP, #-0x10]!
    // 0x5dfd68: SaveReg r7
    //     0x5dfd68: str             x7, [SP, #-8]!
    // 0x5dfd6c: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x5dfd6c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x5dfd70: r0 = checkValidRange()
    //     0x5dfd70: bl              #0x4c2754  ; [dart:core] RangeError::checkValidRange
    // 0x5dfd74: add             SP, SP, #0x18
    // 0x5dfd78: ldur            x1, [fp, #-0x60]
    // 0x5dfd7c: r0 = SubListIterable()
    //     0x5dfd7c: bl              #0x4c2748  ; AllocateSubListIterableStub -> SubListIterable<X0> (size=0x1c)
    // 0x5dfd80: stur            x0, [fp, #-0x88]
    // 0x5dfd84: ldur            x16, [fp, #-0x80]
    // 0x5dfd88: stp             x16, x0, [SP, #-0x10]!
    // 0x5dfd8c: ldur            x1, [fp, #-0x78]
    // 0x5dfd90: ldur            x16, [fp, #-0x68]
    // 0x5dfd94: stp             x16, x1, [SP, #-0x10]!
    // 0x5dfd98: r0 = SubListIterable()
    //     0x5dfd98: bl              #0x4c25b4  ; [dart:_internal] SubListIterable::SubListIterable
    // 0x5dfd9c: add             SP, SP, #0x20
    // 0x5dfda0: ldur            x16, [fp, #-0x50]
    // 0x5dfda4: ldur            lr, [fp, #-0x88]
    // 0x5dfda8: stp             lr, x16, [SP, #-0x10]!
    // 0x5dfdac: r0 = addAll()
    //     0x5dfdac: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0x5dfdb0: add             SP, SP, #0x10
    // 0x5dfdb4: b               #0x5dfe68
    // 0x5dfdb8: ldur            x4, [fp, #-0x80]
    // 0x5dfdbc: ldur            x3, [fp, #-0x78]
    // 0x5dfdc0: mov             x0, x7
    // 0x5dfdc4: mov             x1, x3
    // 0x5dfdc8: cmp             x1, x0
    // 0x5dfdcc: b.hs            #0x5dfec4
    // 0x5dfdd0: LoadField: r0 = r4->field_f
    //     0x5dfdd0: ldur            w0, [x4, #0xf]
    // 0x5dfdd4: DecompressPointer r0
    //     0x5dfdd4: add             x0, x0, HEAP, lsl #32
    // 0x5dfdd8: ArrayLoad: r5 = r0[r3]  ; Unknown_4
    //     0x5dfdd8: add             x16, x0, x3, lsl #2
    //     0x5dfddc: ldur            w5, [x16, #0xf]
    // 0x5dfde0: DecompressPointer r5
    //     0x5dfde0: add             x5, x5, HEAP, lsl #32
    // 0x5dfde4: stur            x5, [fp, #-0x68]
    // 0x5dfde8: LoadField: r0 = r5->field_1b
    //     0x5dfde8: ldur            w0, [x5, #0x1b]
    // 0x5dfdec: DecompressPointer r0
    //     0x5dfdec: add             x0, x0, HEAP, lsl #32
    // 0x5dfdf0: tbnz            w0, #4, #0x5dfe54
    // 0x5dfdf4: ldur            x6, [fp, #-0x70]
    // 0x5dfdf8: LoadField: r7 = r5->field_f
    //     0x5dfdf8: ldur            w7, [x5, #0xf]
    // 0x5dfdfc: DecompressPointer r7
    //     0x5dfdfc: add             x7, x7, HEAP, lsl #32
    // 0x5dfe00: mov             x0, x7
    // 0x5dfe04: stur            x7, [fp, #-0x50]
    // 0x5dfe08: r2 = Null
    //     0x5dfe08: mov             x2, NULL
    // 0x5dfe0c: r1 = Null
    //     0x5dfe0c: mov             x1, NULL
    // 0x5dfe10: r4 = 59
    //     0x5dfe10: mov             x4, #0x3b
    // 0x5dfe14: branchIfSmi(r0, 0x5dfe20)
    //     0x5dfe14: tbz             w0, #0, #0x5dfe20
    // 0x5dfe18: r4 = LoadClassIdInstr(r0)
    //     0x5dfe18: ldur            x4, [x0, #-1]
    //     0x5dfe1c: ubfx            x4, x4, #0xc, #0x14
    // 0x5dfe20: cmp             x4, #0x7e6
    // 0x5dfe24: b.eq            #0x5dfe34
    // 0x5dfe28: r8 = PipelineOwner?
    //     0x5dfe28: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x5dfe2c: r3 = Null
    //     0x5dfe2c: ldr             x3, [PP, #0x4b40]  ; [pp+0x4b40] Null
    // 0x5dfe30: r0 = DefaultNullableTypeTest()
    //     0x5dfe30: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x5dfe34: ldur            x5, [fp, #-0x70]
    // 0x5dfe38: ldur            x0, [fp, #-0x50]
    // 0x5dfe3c: cmp             w0, w5
    // 0x5dfe40: b.ne            #0x5dfe54
    // 0x5dfe44: ldur            x16, [fp, #-0x68]
    // 0x5dfe48: SaveReg r16
    //     0x5dfe48: str             x16, [SP, #-8]!
    // 0x5dfe4c: r0 = _layoutWithoutResize()
    //     0x5dfe4c: bl              #0x5dfec8  ; [package:flutter/src/rendering/object.dart] RenderObject::_layoutWithoutResize
    // 0x5dfe50: add             SP, SP, #8
    // 0x5dfe54: ldur            x0, [fp, #-0x78]
    // 0x5dfe58: add             x4, x0, #1
    // 0x5dfe5c: ldur            x5, [fp, #-0x70]
    // 0x5dfe60: ldur            x3, [fp, #-0x80]
    // 0x5dfe64: b               #0x5dfcf4
    // 0x5dfe68: ldur            x0, [fp, #-0x70]
    // 0x5dfe6c: r2 = false
    //     0x5dfe6c: add             x2, NULL, #0x30  ; false
    // 0x5dfe70: StoreField: r0->field_1b = r2
    //     0x5dfe70: stur            w2, [x0, #0x1b]
    // 0x5dfe74: b               #0x5dfc2c
    // 0x5dfe78: r2 = false
    //     0x5dfe78: add             x2, NULL, #0x30  ; false
    // 0x5dfe7c: ldur            x0, [fp, #-0x58]
    // 0x5dfe80: StoreField: r0->field_1b = r2
    //     0x5dfe80: stur            w2, [x0, #0x1b]
    // 0x5dfe84: r0 = Null
    //     0x5dfe84: mov             x0, NULL
    // 0x5dfe88: LeaveFrame
    //     0x5dfe88: mov             SP, fp
    //     0x5dfe8c: ldp             fp, lr, [SP], #0x10
    // 0x5dfe90: ret
    //     0x5dfe90: ret             
    // 0x5dfe94: r2 = false
    //     0x5dfe94: add             x2, NULL, #0x30  ; false
    // 0x5dfe98: sub             SP, fp, #0x88
    // 0x5dfe9c: ldr             x3, [fp, #0x10]
    // 0x5dfea0: StoreField: r3->field_1b = r2
    //     0x5dfea0: stur            w2, [x3, #0x1b]
    // 0x5dfea4: r0 = ReThrow()
    //     0x5dfea4: bl              #0xd67e14  ; ReThrowStub
    // 0x5dfea8: brk             #0
    // 0x5dfeac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5dfeac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5dfeb0: b               #0x5dfc28
    // 0x5dfeb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5dfeb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5dfeb8: b               #0x5dfc3c
    // 0x5dfebc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5dfebc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5dfec0: b               #0x5dfd10
    // 0x5dfec4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5dfec4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _enableMutationsToDirtySubtrees(/* No info */) {
    // ** addr: 0x6783a4, size: 0x70
    // 0x6783a4: EnterFrame
    //     0x6783a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6783a8: mov             fp, SP
    // 0x6783ac: AllocStack(0x30)
    //     0x6783ac: sub             SP, SP, #0x30
    // 0x6783b0: CheckStackOverflow
    //     0x6783b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6783b4: cmp             SP, x16
    //     0x6783b8: b.ls            #0x67840c
    // 0x6783bc: ldr             x16, [fp, #0x10]
    // 0x6783c0: SaveReg r16
    //     0x6783c0: str             x16, [SP, #-8]!
    // 0x6783c4: ldr             x0, [fp, #0x10]
    // 0x6783c8: ClosureCall
    //     0x6783c8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x6783cc: ldur            x2, [x0, #0x1f]
    //     0x6783d0: blr             x2
    // 0x6783d4: add             SP, SP, #8
    // 0x6783d8: ldr             x0, [fp, #0x18]
    // 0x6783dc: r2 = true
    //     0x6783dc: add             x2, NULL, #0x20  ; true
    // 0x6783e0: StoreField: r0->field_1b = r2
    //     0x6783e0: stur            w2, [x0, #0x1b]
    // 0x6783e4: r0 = Null
    //     0x6783e4: mov             x0, NULL
    // 0x6783e8: LeaveFrame
    //     0x6783e8: mov             SP, fp
    //     0x6783ec: ldp             fp, lr, [SP], #0x10
    // 0x6783f0: ret
    //     0x6783f0: ret             
    // 0x6783f4: r2 = true
    //     0x6783f4: add             x2, NULL, #0x20  ; true
    // 0x6783f8: sub             SP, fp, #0x30
    // 0x6783fc: ldr             x3, [fp, #0x18]
    // 0x678400: StoreField: r3->field_1b = r2
    //     0x678400: stur            w2, [x3, #0x1b]
    // 0x678404: r0 = ReThrow()
    //     0x678404: bl              #0xd67e14  ; ReThrowStub
    // 0x678408: brk             #0
    // 0x67840c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x67840c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x678410: b               #0x6783bc
  }
}

// class id: 2023, size: 0x10, field offset: 0x8
class SemanticsHandle extends Object {

  _ dispose(/* No info */) {
    // ** addr: 0x5bb534, size: 0x80
    // 0x5bb534: EnterFrame
    //     0x5bb534: stp             fp, lr, [SP, #-0x10]!
    //     0x5bb538: mov             fp, SP
    // 0x5bb53c: CheckStackOverflow
    //     0x5bb53c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5bb540: cmp             SP, x16
    //     0x5bb544: b.ls            #0x5bb5a8
    // 0x5bb548: ldr             x0, [fp, #0x10]
    // 0x5bb54c: LoadField: r1 = r0->field_b
    //     0x5bb54c: ldur            w1, [x0, #0xb]
    // 0x5bb550: DecompressPointer r1
    //     0x5bb550: add             x1, x1, HEAP, lsl #32
    // 0x5bb554: cmp             w1, NULL
    // 0x5bb558: b.eq            #0x5bb580
    // 0x5bb55c: LoadField: r2 = r0->field_7
    //     0x5bb55c: ldur            w2, [x0, #7]
    // 0x5bb560: DecompressPointer r2
    //     0x5bb560: add             x2, x2, HEAP, lsl #32
    // 0x5bb564: LoadField: r3 = r2->field_2b
    //     0x5bb564: ldur            w3, [x2, #0x2b]
    // 0x5bb568: DecompressPointer r3
    //     0x5bb568: add             x3, x3, HEAP, lsl #32
    // 0x5bb56c: cmp             w3, NULL
    // 0x5bb570: b.eq            #0x5bb5b0
    // 0x5bb574: stp             x1, x3, [SP, #-0x10]!
    // 0x5bb578: r0 = removeListener()
    //     0x5bb578: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x5bb57c: add             SP, SP, #0x10
    // 0x5bb580: ldr             x0, [fp, #0x10]
    // 0x5bb584: LoadField: r1 = r0->field_7
    //     0x5bb584: ldur            w1, [x0, #7]
    // 0x5bb588: DecompressPointer r1
    //     0x5bb588: add             x1, x1, HEAP, lsl #32
    // 0x5bb58c: SaveReg r1
    //     0x5bb58c: str             x1, [SP, #-8]!
    // 0x5bb590: r0 = _didDisposeSemanticsHandle()
    //     0x5bb590: bl              #0x5bb5b4  ; [package:flutter/src/rendering/object.dart] PipelineOwner::_didDisposeSemanticsHandle
    // 0x5bb594: add             SP, SP, #8
    // 0x5bb598: r0 = Null
    //     0x5bb598: mov             x0, NULL
    // 0x5bb59c: LeaveFrame
    //     0x5bb59c: mov             SP, fp
    //     0x5bb5a0: ldp             fp, lr, [SP], #0x10
    // 0x5bb5a4: ret
    //     0x5bb5a4: ret             
    // 0x5bb5a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5bb5a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5bb5ac: b               #0x5bb548
    // 0x5bb5b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5bb5b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ SemanticsHandle._(/* No info */) {
    // ** addr: 0x5bb774, size: 0xa0
    // 0x5bb774: EnterFrame
    //     0x5bb774: stp             fp, lr, [SP, #-0x10]!
    //     0x5bb778: mov             fp, SP
    // 0x5bb77c: CheckStackOverflow
    //     0x5bb77c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5bb780: cmp             SP, x16
    //     0x5bb784: b.ls            #0x5bb808
    // 0x5bb788: ldr             x0, [fp, #0x10]
    // 0x5bb78c: ldr             x1, [fp, #0x20]
    // 0x5bb790: StoreField: r1->field_b = r0
    //     0x5bb790: stur            w0, [x1, #0xb]
    //     0x5bb794: ldurb           w16, [x1, #-1]
    //     0x5bb798: ldurb           w17, [x0, #-1]
    //     0x5bb79c: and             x16, x17, x16, lsr #2
    //     0x5bb7a0: tst             x16, HEAP, lsr #32
    //     0x5bb7a4: b.eq            #0x5bb7ac
    //     0x5bb7a8: bl              #0xd6826c
    // 0x5bb7ac: ldr             x0, [fp, #0x18]
    // 0x5bb7b0: StoreField: r1->field_7 = r0
    //     0x5bb7b0: stur            w0, [x1, #7]
    //     0x5bb7b4: ldurb           w16, [x1, #-1]
    //     0x5bb7b8: ldurb           w17, [x0, #-1]
    //     0x5bb7bc: and             x16, x17, x16, lsr #2
    //     0x5bb7c0: tst             x16, HEAP, lsr #32
    //     0x5bb7c4: b.eq            #0x5bb7cc
    //     0x5bb7c8: bl              #0xd6826c
    // 0x5bb7cc: ldr             x0, [fp, #0x10]
    // 0x5bb7d0: cmp             w0, NULL
    // 0x5bb7d4: b.eq            #0x5bb7f8
    // 0x5bb7d8: ldr             x1, [fp, #0x18]
    // 0x5bb7dc: LoadField: r2 = r1->field_2b
    //     0x5bb7dc: ldur            w2, [x1, #0x2b]
    // 0x5bb7e0: DecompressPointer r2
    //     0x5bb7e0: add             x2, x2, HEAP, lsl #32
    // 0x5bb7e4: cmp             w2, NULL
    // 0x5bb7e8: b.eq            #0x5bb810
    // 0x5bb7ec: stp             x0, x2, [SP, #-0x10]!
    // 0x5bb7f0: r0 = addListener()
    //     0x5bb7f0: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x5bb7f4: add             SP, SP, #0x10
    // 0x5bb7f8: r0 = Null
    //     0x5bb7f8: mov             x0, NULL
    // 0x5bb7fc: LeaveFrame
    //     0x5bb7fc: mov             SP, fp
    //     0x5bb800: ldp             fp, lr, [SP], #0x10
    // 0x5bb804: ret
    //     0x5bb804: ret             
    // 0x5bb808: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5bb808: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5bb80c: b               #0x5bb788
    // 0x5bb810: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5bb810: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2034, size: 0x8, field offset: 0x8
class ParentData extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xae54ec, size: 0xc
    // 0xae54ec: r0 = "<none>"
    //     0xae54ec: add             x0, PP, #8, lsl #12  ; [pp+0x8a60] "<none>"
    //     0xae54f0: ldr             x0, [x0, #0xa60]
    // 0xae54f4: ret
    //     0xae54f4: ret             
  }
}

// class id: 2046, size: 0xc, field offset: 0x8
abstract class ContainerParentDataMixin<X0 bound RenderObject> extends ParentData {
}

// class id: 2059, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class Constraints extends Object {
}

// class id: 2108, size: 0x1c, field offset: 0x8
class PaintingContext extends ClipContext {

  static _ updateLayerProperties(/* No info */) {
    // ** addr: 0x5de660, size: 0xb4
    // 0x5de660: EnterFrame
    //     0x5de660: stp             fp, lr, [SP, #-0x10]!
    //     0x5de664: mov             fp, SP
    // 0x5de668: AllocStack(0x8)
    //     0x5de668: sub             SP, SP, #8
    // 0x5de66c: CheckStackOverflow
    //     0x5de66c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5de670: cmp             SP, x16
    //     0x5de674: b.ls            #0x5de708
    // 0x5de678: ldr             x3, [fp, #0x10]
    // 0x5de67c: LoadField: r0 = r3->field_2f
    //     0x5de67c: ldur            w0, [x3, #0x2f]
    // 0x5de680: DecompressPointer r0
    //     0x5de680: add             x0, x0, HEAP, lsl #32
    // 0x5de684: LoadField: r4 = r0->field_b
    //     0x5de684: ldur            w4, [x0, #0xb]
    // 0x5de688: DecompressPointer r4
    //     0x5de688: add             x4, x4, HEAP, lsl #32
    // 0x5de68c: stur            x4, [fp, #-8]
    // 0x5de690: cmp             w4, NULL
    // 0x5de694: b.eq            #0x5de710
    // 0x5de698: mov             x0, x4
    // 0x5de69c: r2 = Null
    //     0x5de69c: mov             x2, NULL
    // 0x5de6a0: r1 = Null
    //     0x5de6a0: mov             x1, NULL
    // 0x5de6a4: r4 = LoadClassIdInstr(r0)
    //     0x5de6a4: ldur            x4, [x0, #-1]
    //     0x5de6a8: ubfx            x4, x4, #0xc, #0x14
    // 0x5de6ac: sub             x4, x4, #0x956
    // 0x5de6b0: cmp             x4, #3
    // 0x5de6b4: b.ls            #0x5de6c4
    // 0x5de6b8: r8 = OffsetLayer
    //     0x5de6b8: ldr             x8, [PP, #0x4a28]  ; [pp+0x4a28] Type: OffsetLayer
    // 0x5de6bc: r3 = Null
    //     0x5de6bc: ldr             x3, [PP, #0x71b0]  ; [pp+0x71b0] Null
    // 0x5de6c0: r0 = DefaultTypeTest()
    //     0x5de6c0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5de6c4: ldr             x1, [fp, #0x10]
    // 0x5de6c8: r0 = LoadClassIdInstr(r1)
    //     0x5de6c8: ldur            x0, [x1, #-1]
    //     0x5de6cc: ubfx            x0, x0, #0xc, #0x14
    // 0x5de6d0: ldur            x16, [fp, #-8]
    // 0x5de6d4: stp             x16, x1, [SP, #-0x10]!
    // 0x5de6d8: r0 = GDT[cid_x0 + 0xe17b]()
    //     0x5de6d8: mov             x17, #0xe17b
    //     0x5de6dc: add             lr, x0, x17
    //     0x5de6e0: ldr             lr, [x21, lr, lsl #3]
    //     0x5de6e4: blr             lr
    // 0x5de6e8: add             SP, SP, #0x10
    // 0x5de6ec: ldr             x1, [fp, #0x10]
    // 0x5de6f0: r2 = false
    //     0x5de6f0: add             x2, NULL, #0x30  ; false
    // 0x5de6f4: StoreField: r1->field_3f = r2
    //     0x5de6f4: stur            w2, [x1, #0x3f]
    // 0x5de6f8: r0 = Null
    //     0x5de6f8: mov             x0, NULL
    // 0x5de6fc: LeaveFrame
    //     0x5de6fc: mov             SP, fp
    //     0x5de700: ldp             fp, lr, [SP], #0x10
    // 0x5de704: ret
    //     0x5de704: ret             
    // 0x5de708: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5de708: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5de70c: b               #0x5de678
    // 0x5de710: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5de710: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ _repaintCompositedChild(/* No info */) {
    // ** addr: 0x5de838, size: 0x190
    // 0x5de838: EnterFrame
    //     0x5de838: stp             fp, lr, [SP, #-0x10]!
    //     0x5de83c: mov             fp, SP
    // 0x5de840: AllocStack(0x20)
    //     0x5de840: sub             SP, SP, #0x20
    // 0x5de844: SetupParameters(dynamic _ /* r3, fp-0x18 */)
    //     0x5de844: mov             x0, x4
    //     0x5de848: ldur            w1, [x0, #0x13]
    //     0x5de84c: add             x1, x1, HEAP, lsl #32
    //     0x5de850: sub             x0, x1, #2
    //     0x5de854: add             x3, fp, w0, sxtw #2
    //     0x5de858: ldr             x3, [x3, #0x10]
    //     0x5de85c: stur            x3, [fp, #-0x18]
    // 0x5de860: CheckStackOverflow
    //     0x5de860: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5de864: cmp             SP, x16
    //     0x5de868: b.ls            #0x5de9c0
    // 0x5de86c: LoadField: r4 = r3->field_2f
    //     0x5de86c: ldur            w4, [x3, #0x2f]
    // 0x5de870: DecompressPointer r4
    //     0x5de870: add             x4, x4, HEAP, lsl #32
    // 0x5de874: stur            x4, [fp, #-0x10]
    // 0x5de878: LoadField: r5 = r4->field_b
    //     0x5de878: ldur            w5, [x4, #0xb]
    // 0x5de87c: DecompressPointer r5
    //     0x5de87c: add             x5, x5, HEAP, lsl #32
    // 0x5de880: mov             x0, x5
    // 0x5de884: stur            x5, [fp, #-8]
    // 0x5de888: r2 = Null
    //     0x5de888: mov             x2, NULL
    // 0x5de88c: r1 = Null
    //     0x5de88c: mov             x1, NULL
    // 0x5de890: r4 = LoadClassIdInstr(r0)
    //     0x5de890: ldur            x4, [x0, #-1]
    //     0x5de894: ubfx            x4, x4, #0xc, #0x14
    // 0x5de898: sub             x4, x4, #0x956
    // 0x5de89c: cmp             x4, #3
    // 0x5de8a0: b.ls            #0x5de8b0
    // 0x5de8a4: r8 = OffsetLayer?
    //     0x5de8a4: ldr             x8, [PP, #0x4a40]  ; [pp+0x4a40] Type: OffsetLayer?
    // 0x5de8a8: r3 = Null
    //     0x5de8a8: ldr             x3, [PP, #0x4a48]  ; [pp+0x4a48] Null
    // 0x5de8ac: r0 = DefaultNullableTypeTest()
    //     0x5de8ac: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x5de8b0: ldur            x0, [fp, #-8]
    // 0x5de8b4: cmp             w0, NULL
    // 0x5de8b8: b.ne            #0x5de8fc
    // 0x5de8bc: ldur            x1, [fp, #-0x18]
    // 0x5de8c0: r0 = LoadClassIdInstr(r1)
    //     0x5de8c0: ldur            x0, [x1, #-1]
    //     0x5de8c4: ubfx            x0, x0, #0xc, #0x14
    // 0x5de8c8: stp             NULL, x1, [SP, #-0x10]!
    // 0x5de8cc: r0 = GDT[cid_x0 + 0xe17b]()
    //     0x5de8cc: mov             x17, #0xe17b
    //     0x5de8d0: add             lr, x0, x17
    //     0x5de8d4: ldr             lr, [x21, lr, lsl #3]
    //     0x5de8d8: blr             lr
    // 0x5de8dc: add             SP, SP, #0x10
    // 0x5de8e0: stur            x0, [fp, #-0x20]
    // 0x5de8e4: ldur            x16, [fp, #-0x10]
    // 0x5de8e8: stp             x0, x16, [SP, #-0x10]!
    // 0x5de8ec: r0 = layer=()
    //     0x5de8ec: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x5de8f0: add             SP, SP, #0x10
    // 0x5de8f4: ldur            x2, [fp, #-0x20]
    // 0x5de8f8: b               #0x5de938
    // 0x5de8fc: ldur            x1, [fp, #-0x18]
    // 0x5de900: SaveReg r0
    //     0x5de900: str             x0, [SP, #-8]!
    // 0x5de904: r0 = removeAllChildren()
    //     0x5de904: bl              #0x5df3f8  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::removeAllChildren
    // 0x5de908: add             SP, SP, #8
    // 0x5de90c: ldur            x1, [fp, #-0x18]
    // 0x5de910: r0 = LoadClassIdInstr(r1)
    //     0x5de910: ldur            x0, [x1, #-1]
    //     0x5de914: ubfx            x0, x0, #0xc, #0x14
    // 0x5de918: ldur            x16, [fp, #-8]
    // 0x5de91c: stp             x16, x1, [SP, #-0x10]!
    // 0x5de920: r0 = GDT[cid_x0 + 0xe17b]()
    //     0x5de920: mov             x17, #0xe17b
    //     0x5de924: add             lr, x0, x17
    //     0x5de928: ldr             lr, [x21, lr, lsl #3]
    //     0x5de92c: blr             lr
    // 0x5de930: add             SP, SP, #0x10
    // 0x5de934: ldur            x2, [fp, #-8]
    // 0x5de938: ldur            x1, [fp, #-0x18]
    // 0x5de93c: r0 = false
    //     0x5de93c: add             x0, NULL, #0x30  ; false
    // 0x5de940: stur            x2, [fp, #-8]
    // 0x5de944: StoreField: r1->field_3f = r0
    //     0x5de944: stur            w0, [x1, #0x3f]
    // 0x5de948: r0 = LoadClassIdInstr(r1)
    //     0x5de948: ldur            x0, [x1, #-1]
    //     0x5de94c: ubfx            x0, x0, #0xc, #0x14
    // 0x5de950: SaveReg r1
    //     0x5de950: str             x1, [SP, #-8]!
    // 0x5de954: r0 = GDT[cid_x0 + 0xd215]()
    //     0x5de954: mov             x17, #0xd215
    //     0x5de958: add             lr, x0, x17
    //     0x5de95c: ldr             lr, [x21, lr, lsl #3]
    //     0x5de960: blr             lr
    // 0x5de964: add             SP, SP, #8
    // 0x5de968: stur            x0, [fp, #-0x10]
    // 0x5de96c: r0 = PaintingContext()
    //     0x5de96c: bl              #0x5df3ec  ; AllocatePaintingContextStub -> PaintingContext (size=0x1c)
    // 0x5de970: mov             x1, x0
    // 0x5de974: ldur            x0, [fp, #-8]
    // 0x5de978: stur            x1, [fp, #-0x20]
    // 0x5de97c: StoreField: r1->field_7 = r0
    //     0x5de97c: stur            w0, [x1, #7]
    // 0x5de980: ldur            x0, [fp, #-0x10]
    // 0x5de984: StoreField: r1->field_b = r0
    //     0x5de984: stur            w0, [x1, #0xb]
    // 0x5de988: ldur            x16, [fp, #-0x18]
    // 0x5de98c: stp             x1, x16, [SP, #-0x10]!
    // 0x5de990: r16 = Instance_Offset
    //     0x5de990: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x5de994: SaveReg r16
    //     0x5de994: str             x16, [SP, #-8]!
    // 0x5de998: r0 = _paintWithContext()
    //     0x5de998: bl              #0x5df060  ; [package:flutter/src/rendering/object.dart] RenderObject::_paintWithContext
    // 0x5de99c: add             SP, SP, #0x18
    // 0x5de9a0: ldur            x16, [fp, #-0x20]
    // 0x5de9a4: SaveReg r16
    //     0x5de9a4: str             x16, [SP, #-8]!
    // 0x5de9a8: r0 = stopRecordingIfNeeded()
    //     0x5de9a8: bl              #0x5de9c8  ; [package:flutter/src/rendering/object.dart] PaintingContext::stopRecordingIfNeeded
    // 0x5de9ac: add             SP, SP, #8
    // 0x5de9b0: r0 = Null
    //     0x5de9b0: mov             x0, NULL
    // 0x5de9b4: LeaveFrame
    //     0x5de9b4: mov             SP, fp
    //     0x5de9b8: ldp             fp, lr, [SP], #0x10
    // 0x5de9bc: ret
    //     0x5de9bc: ret             
    // 0x5de9c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5de9c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5de9c4: b               #0x5de86c
  }
  _ stopRecordingIfNeeded(/* No info */) {
    // ** addr: 0x5de9c8, size: 0xac
    // 0x5de9c8: EnterFrame
    //     0x5de9c8: stp             fp, lr, [SP, #-0x10]!
    //     0x5de9cc: mov             fp, SP
    // 0x5de9d0: AllocStack(0x8)
    //     0x5de9d0: sub             SP, SP, #8
    // 0x5de9d4: CheckStackOverflow
    //     0x5de9d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5de9d8: cmp             SP, x16
    //     0x5de9dc: b.ls            #0x5dea64
    // 0x5de9e0: ldr             x0, [fp, #0x10]
    // 0x5de9e4: LoadField: r1 = r0->field_17
    //     0x5de9e4: ldur            w1, [x0, #0x17]
    // 0x5de9e8: DecompressPointer r1
    //     0x5de9e8: add             x1, x1, HEAP, lsl #32
    // 0x5de9ec: cmp             w1, NULL
    // 0x5de9f0: b.ne            #0x5dea04
    // 0x5de9f4: r0 = Null
    //     0x5de9f4: mov             x0, NULL
    // 0x5de9f8: LeaveFrame
    //     0x5de9f8: mov             SP, fp
    //     0x5de9fc: ldp             fp, lr, [SP], #0x10
    // 0x5dea00: ret
    //     0x5dea00: ret             
    // 0x5dea04: LoadField: r1 = r0->field_f
    //     0x5dea04: ldur            w1, [x0, #0xf]
    // 0x5dea08: DecompressPointer r1
    //     0x5dea08: add             x1, x1, HEAP, lsl #32
    // 0x5dea0c: stur            x1, [fp, #-8]
    // 0x5dea10: cmp             w1, NULL
    // 0x5dea14: b.eq            #0x5dea6c
    // 0x5dea18: LoadField: r2 = r0->field_13
    //     0x5dea18: ldur            w2, [x0, #0x13]
    // 0x5dea1c: DecompressPointer r2
    //     0x5dea1c: add             x2, x2, HEAP, lsl #32
    // 0x5dea20: cmp             w2, NULL
    // 0x5dea24: b.eq            #0x5dea70
    // 0x5dea28: SaveReg r2
    //     0x5dea28: str             x2, [SP, #-8]!
    // 0x5dea2c: r0 = endRecording()
    //     0x5dea2c: bl              #0x5dec9c  ; [dart:ui] PictureRecorder::endRecording
    // 0x5dea30: add             SP, SP, #8
    // 0x5dea34: ldur            x16, [fp, #-8]
    // 0x5dea38: stp             x0, x16, [SP, #-0x10]!
    // 0x5dea3c: r0 = picture=()
    //     0x5dea3c: bl              #0x5dea74  ; [package:flutter/src/rendering/layer.dart] PictureLayer::picture=
    // 0x5dea40: add             SP, SP, #0x10
    // 0x5dea44: ldr             x1, [fp, #0x10]
    // 0x5dea48: StoreField: r1->field_f = rNULL
    //     0x5dea48: stur            NULL, [x1, #0xf]
    // 0x5dea4c: StoreField: r1->field_13 = rNULL
    //     0x5dea4c: stur            NULL, [x1, #0x13]
    // 0x5dea50: StoreField: r1->field_17 = rNULL
    //     0x5dea50: stur            NULL, [x1, #0x17]
    // 0x5dea54: r0 = Null
    //     0x5dea54: mov             x0, NULL
    // 0x5dea58: LeaveFrame
    //     0x5dea58: mov             SP, fp
    //     0x5dea5c: ldp             fp, lr, [SP], #0x10
    // 0x5dea60: ret
    //     0x5dea60: ret             
    // 0x5dea64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5dea64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5dea68: b               #0x5de9e0
    // 0x5dea6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5dea6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5dea70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5dea70: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paintChild(/* No info */) {
    // ** addr: 0x653fdc, size: 0xf8
    // 0x653fdc: EnterFrame
    //     0x653fdc: stp             fp, lr, [SP, #-0x10]!
    //     0x653fe0: mov             fp, SP
    // 0x653fe4: CheckStackOverflow
    //     0x653fe4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x653fe8: cmp             SP, x16
    //     0x653fec: b.ls            #0x6540c4
    // 0x653ff0: ldr             x1, [fp, #0x18]
    // 0x653ff4: r0 = LoadClassIdInstr(r1)
    //     0x653ff4: ldur            x0, [x1, #-1]
    //     0x653ff8: ubfx            x0, x0, #0xc, #0x14
    // 0x653ffc: SaveReg r1
    //     0x653ffc: str             x1, [SP, #-8]!
    // 0x654000: r0 = GDT[cid_x0 + 0xd14d]()
    //     0x654000: mov             x17, #0xd14d
    //     0x654004: add             lr, x0, x17
    //     0x654008: ldr             lr, [x21, lr, lsl #3]
    //     0x65400c: blr             lr
    // 0x654010: add             SP, SP, #8
    // 0x654014: tbnz            w0, #4, #0x654048
    // 0x654018: ldr             x16, [fp, #0x20]
    // 0x65401c: SaveReg r16
    //     0x65401c: str             x16, [SP, #-8]!
    // 0x654020: r0 = stopRecordingIfNeeded()
    //     0x654020: bl              #0x5de9c8  ; [package:flutter/src/rendering/object.dart] PaintingContext::stopRecordingIfNeeded
    // 0x654024: add             SP, SP, #8
    // 0x654028: ldr             x16, [fp, #0x20]
    // 0x65402c: ldr             lr, [fp, #0x18]
    // 0x654030: stp             lr, x16, [SP, #-0x10]!
    // 0x654034: ldr             x16, [fp, #0x10]
    // 0x654038: SaveReg r16
    //     0x654038: str             x16, [SP, #-8]!
    // 0x65403c: r0 = _compositeChild()
    //     0x65403c: bl              #0x6540d4  ; [package:flutter/src/rendering/object.dart] PaintingContext::_compositeChild
    // 0x654040: add             SP, SP, #0x18
    // 0x654044: b               #0x6540b4
    // 0x654048: ldr             x0, [fp, #0x18]
    // 0x65404c: LoadField: r1 = r0->field_2b
    //     0x65404c: ldur            w1, [x0, #0x2b]
    // 0x654050: DecompressPointer r1
    //     0x654050: add             x1, x1, HEAP, lsl #32
    // 0x654054: r16 = Sentinel
    //     0x654054: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x654058: cmp             w1, w16
    // 0x65405c: b.eq            #0x6540cc
    // 0x654060: tbnz            w1, #4, #0x654098
    // 0x654064: LoadField: r1 = r0->field_2f
    //     0x654064: ldur            w1, [x0, #0x2f]
    // 0x654068: DecompressPointer r1
    //     0x654068: add             x1, x1, HEAP, lsl #32
    // 0x65406c: stp             NULL, x1, [SP, #-0x10]!
    // 0x654070: r0 = layer=()
    //     0x654070: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x654074: add             SP, SP, #0x10
    // 0x654078: ldr             x16, [fp, #0x18]
    // 0x65407c: ldr             lr, [fp, #0x20]
    // 0x654080: stp             lr, x16, [SP, #-0x10]!
    // 0x654084: ldr             x16, [fp, #0x10]
    // 0x654088: SaveReg r16
    //     0x654088: str             x16, [SP, #-8]!
    // 0x65408c: r0 = _paintWithContext()
    //     0x65408c: bl              #0x5df060  ; [package:flutter/src/rendering/object.dart] RenderObject::_paintWithContext
    // 0x654090: add             SP, SP, #0x18
    // 0x654094: b               #0x6540b4
    // 0x654098: ldr             x16, [fp, #0x18]
    // 0x65409c: ldr             lr, [fp, #0x20]
    // 0x6540a0: stp             lr, x16, [SP, #-0x10]!
    // 0x6540a4: ldr             x16, [fp, #0x10]
    // 0x6540a8: SaveReg r16
    //     0x6540a8: str             x16, [SP, #-8]!
    // 0x6540ac: r0 = _paintWithContext()
    //     0x6540ac: bl              #0x5df060  ; [package:flutter/src/rendering/object.dart] RenderObject::_paintWithContext
    // 0x6540b0: add             SP, SP, #0x18
    // 0x6540b4: r0 = Null
    //     0x6540b4: mov             x0, NULL
    // 0x6540b8: LeaveFrame
    //     0x6540b8: mov             SP, fp
    //     0x6540bc: ldp             fp, lr, [SP], #0x10
    // 0x6540c0: ret
    //     0x6540c0: ret             
    // 0x6540c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6540c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6540c8: b               #0x653ff0
    // 0x6540cc: r9 = _wasRepaintBoundary
    //     0x6540cc: ldr             x9, [PP, #0x4b30]  ; [pp+0x4b30] Field <RenderObject._wasRepaintBoundary@904266271>: late (offset: 0x2c)
    // 0x6540d0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6540d0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _compositeChild(/* No info */) {
    // ** addr: 0x6540d4, size: 0x104
    // 0x6540d4: EnterFrame
    //     0x6540d4: stp             fp, lr, [SP, #-0x10]!
    //     0x6540d8: mov             fp, SP
    // 0x6540dc: AllocStack(0x8)
    //     0x6540dc: sub             SP, SP, #8
    // 0x6540e0: CheckStackOverflow
    //     0x6540e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6540e4: cmp             SP, x16
    //     0x6540e8: b.ls            #0x6541c4
    // 0x6540ec: ldr             x0, [fp, #0x18]
    // 0x6540f0: LoadField: r1 = r0->field_3b
    //     0x6540f0: ldur            w1, [x0, #0x3b]
    // 0x6540f4: DecompressPointer r1
    //     0x6540f4: add             x1, x1, HEAP, lsl #32
    // 0x6540f8: tbz             w1, #4, #0x654114
    // 0x6540fc: LoadField: r1 = r0->field_2b
    //     0x6540fc: ldur            w1, [x0, #0x2b]
    // 0x654100: DecompressPointer r1
    //     0x654100: add             x1, x1, HEAP, lsl #32
    // 0x654104: r16 = Sentinel
    //     0x654104: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x654108: cmp             w1, w16
    // 0x65410c: b.eq            #0x6541cc
    // 0x654110: tbz             w1, #4, #0x654128
    // 0x654114: SaveReg r0
    //     0x654114: str             x0, [SP, #-8]!
    // 0x654118: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x654118: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x65411c: r0 = _repaintCompositedChild()
    //     0x65411c: bl              #0x5de838  ; [package:flutter/src/rendering/object.dart] PaintingContext::_repaintCompositedChild
    // 0x654120: add             SP, SP, #8
    // 0x654124: b               #0x654140
    // 0x654128: LoadField: r1 = r0->field_3f
    //     0x654128: ldur            w1, [x0, #0x3f]
    // 0x65412c: DecompressPointer r1
    //     0x65412c: add             x1, x1, HEAP, lsl #32
    // 0x654130: tbnz            w1, #4, #0x654140
    // 0x654134: SaveReg r0
    //     0x654134: str             x0, [SP, #-8]!
    // 0x654138: r0 = updateLayerProperties()
    //     0x654138: bl              #0x5de660  ; [package:flutter/src/rendering/object.dart] PaintingContext::updateLayerProperties
    // 0x65413c: add             SP, SP, #8
    // 0x654140: ldr             x0, [fp, #0x18]
    // 0x654144: LoadField: r1 = r0->field_2f
    //     0x654144: ldur            w1, [x0, #0x2f]
    // 0x654148: DecompressPointer r1
    //     0x654148: add             x1, x1, HEAP, lsl #32
    // 0x65414c: LoadField: r3 = r1->field_b
    //     0x65414c: ldur            w3, [x1, #0xb]
    // 0x654150: DecompressPointer r3
    //     0x654150: add             x3, x3, HEAP, lsl #32
    // 0x654154: stur            x3, [fp, #-8]
    // 0x654158: cmp             w3, NULL
    // 0x65415c: b.eq            #0x6541d4
    // 0x654160: mov             x0, x3
    // 0x654164: r2 = Null
    //     0x654164: mov             x2, NULL
    // 0x654168: r1 = Null
    //     0x654168: mov             x1, NULL
    // 0x65416c: r4 = LoadClassIdInstr(r0)
    //     0x65416c: ldur            x4, [x0, #-1]
    //     0x654170: ubfx            x4, x4, #0xc, #0x14
    // 0x654174: sub             x4, x4, #0x956
    // 0x654178: cmp             x4, #3
    // 0x65417c: b.ls            #0x65418c
    // 0x654180: r8 = OffsetLayer
    //     0x654180: ldr             x8, [PP, #0x4a28]  ; [pp+0x4a28] Type: OffsetLayer
    // 0x654184: r3 = Null
    //     0x654184: ldr             x3, [PP, #0x7190]  ; [pp+0x7190] Null
    // 0x654188: r0 = DefaultTypeTest()
    //     0x654188: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x65418c: ldur            x16, [fp, #-8]
    // 0x654190: ldr             lr, [fp, #0x10]
    // 0x654194: stp             lr, x16, [SP, #-0x10]!
    // 0x654198: r0 = offset=()
    //     0x654198: bl              #0x65455c  ; [package:flutter/src/rendering/layer.dart] OffsetLayer::offset=
    // 0x65419c: add             SP, SP, #0x10
    // 0x6541a0: ldr             x16, [fp, #0x20]
    // 0x6541a4: ldur            lr, [fp, #-8]
    // 0x6541a8: stp             lr, x16, [SP, #-0x10]!
    // 0x6541ac: r0 = appendLayer()
    //     0x6541ac: bl              #0x6541d8  ; [package:flutter/src/rendering/object.dart] PaintingContext::appendLayer
    // 0x6541b0: add             SP, SP, #0x10
    // 0x6541b4: r0 = Null
    //     0x6541b4: mov             x0, NULL
    // 0x6541b8: LeaveFrame
    //     0x6541b8: mov             SP, fp
    //     0x6541bc: ldp             fp, lr, [SP], #0x10
    // 0x6541c0: ret
    //     0x6541c0: ret             
    // 0x6541c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6541c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6541c8: b               #0x6540ec
    // 0x6541cc: r9 = _wasRepaintBoundary
    //     0x6541cc: ldr             x9, [PP, #0x4b30]  ; [pp+0x4b30] Field <RenderObject._wasRepaintBoundary@904266271>: late (offset: 0x2c)
    // 0x6541d0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6541d0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6541d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6541d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ appendLayer(/* No info */) {
    // ** addr: 0x6541d8, size: 0x58
    // 0x6541d8: EnterFrame
    //     0x6541d8: stp             fp, lr, [SP, #-0x10]!
    //     0x6541dc: mov             fp, SP
    // 0x6541e0: CheckStackOverflow
    //     0x6541e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6541e4: cmp             SP, x16
    //     0x6541e8: b.ls            #0x654228
    // 0x6541ec: ldr             x16, [fp, #0x10]
    // 0x6541f0: SaveReg r16
    //     0x6541f0: str             x16, [SP, #-8]!
    // 0x6541f4: r0 = remove()
    //     0x6541f4: bl              #0x6543c0  ; [package:flutter/src/rendering/layer.dart] Layer::remove
    // 0x6541f8: add             SP, SP, #8
    // 0x6541fc: ldr             x0, [fp, #0x18]
    // 0x654200: LoadField: r1 = r0->field_7
    //     0x654200: ldur            w1, [x0, #7]
    // 0x654204: DecompressPointer r1
    //     0x654204: add             x1, x1, HEAP, lsl #32
    // 0x654208: ldr             x16, [fp, #0x10]
    // 0x65420c: stp             x16, x1, [SP, #-0x10]!
    // 0x654210: r0 = append()
    //     0x654210: bl              #0x654230  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::append
    // 0x654214: add             SP, SP, #0x10
    // 0x654218: r0 = Null
    //     0x654218: mov             x0, NULL
    // 0x65421c: LeaveFrame
    //     0x65421c: mov             SP, fp
    //     0x654220: ldp             fp, lr, [SP], #0x10
    // 0x654224: ret
    //     0x654224: ret             
    // 0x654228: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x654228: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65422c: b               #0x6541ec
  }
  get _ canvas(/* No info */) {
    // ** addr: 0x65aee4, size: 0x60
    // 0x65aee4: EnterFrame
    //     0x65aee4: stp             fp, lr, [SP, #-0x10]!
    //     0x65aee8: mov             fp, SP
    // 0x65aeec: CheckStackOverflow
    //     0x65aeec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65aef0: cmp             SP, x16
    //     0x65aef4: b.ls            #0x65af38
    // 0x65aef8: ldr             x0, [fp, #0x10]
    // 0x65aefc: LoadField: r1 = r0->field_17
    //     0x65aefc: ldur            w1, [x0, #0x17]
    // 0x65af00: DecompressPointer r1
    //     0x65af00: add             x1, x1, HEAP, lsl #32
    // 0x65af04: cmp             w1, NULL
    // 0x65af08: b.ne            #0x65af18
    // 0x65af0c: SaveReg r0
    //     0x65af0c: str             x0, [SP, #-8]!
    // 0x65af10: r0 = _startRecording()
    //     0x65af10: bl              #0x65af44  ; [package:flutter/src/rendering/object.dart] PaintingContext::_startRecording
    // 0x65af14: add             SP, SP, #8
    // 0x65af18: ldr             x1, [fp, #0x10]
    // 0x65af1c: LoadField: r0 = r1->field_17
    //     0x65af1c: ldur            w0, [x1, #0x17]
    // 0x65af20: DecompressPointer r0
    //     0x65af20: add             x0, x0, HEAP, lsl #32
    // 0x65af24: cmp             w0, NULL
    // 0x65af28: b.eq            #0x65af40
    // 0x65af2c: LeaveFrame
    //     0x65af2c: mov             SP, fp
    //     0x65af30: ldp             fp, lr, [SP], #0x10
    // 0x65af34: ret
    //     0x65af34: ret             
    // 0x65af38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65af38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65af3c: b               #0x65aef8
    // 0x65af40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65af40: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _startRecording(/* No info */) {
    // ** addr: 0x65af44, size: 0x118
    // 0x65af44: EnterFrame
    //     0x65af44: stp             fp, lr, [SP, #-0x10]!
    //     0x65af48: mov             fp, SP
    // 0x65af4c: AllocStack(0x10)
    //     0x65af4c: sub             SP, SP, #0x10
    // 0x65af50: CheckStackOverflow
    //     0x65af50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65af54: cmp             SP, x16
    //     0x65af58: b.ls            #0x65b050
    // 0x65af5c: r0 = PictureLayer()
    //     0x65af5c: bl              #0x65b074  ; AllocatePictureLayerStub -> PictureLayer (size=0x4c)
    // 0x65af60: mov             x1, x0
    // 0x65af64: r0 = false
    //     0x65af64: add             x0, NULL, #0x30  ; false
    // 0x65af68: stur            x1, [fp, #-8]
    // 0x65af6c: StoreField: r1->field_43 = r0
    //     0x65af6c: stur            w0, [x1, #0x43]
    // 0x65af70: StoreField: r1->field_47 = r0
    //     0x65af70: stur            w0, [x1, #0x47]
    // 0x65af74: SaveReg r1
    //     0x65af74: str             x1, [SP, #-8]!
    // 0x65af78: r0 = Layer()
    //     0x65af78: bl              #0x5bbe7c  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0x65af7c: add             SP, SP, #8
    // 0x65af80: ldur            x0, [fp, #-8]
    // 0x65af84: ldr             x1, [fp, #0x10]
    // 0x65af88: StoreField: r1->field_f = r0
    //     0x65af88: stur            w0, [x1, #0xf]
    //     0x65af8c: ldurb           w16, [x1, #-1]
    //     0x65af90: ldurb           w17, [x0, #-1]
    //     0x65af94: and             x16, x17, x16, lsr #2
    //     0x65af98: tst             x16, HEAP, lsr #32
    //     0x65af9c: b.eq            #0x65afa4
    //     0x65afa0: bl              #0xd6826c
    // 0x65afa4: r0 = PictureRecorder()
    //     0x65afa4: bl              #0x65b068  ; AllocatePictureRecorderStub -> PictureRecorder (size=0x10)
    // 0x65afa8: stur            x0, [fp, #-8]
    // 0x65afac: SaveReg r0
    //     0x65afac: str             x0, [SP, #-8]!
    // 0x65afb0: r0 = _constructor()
    //     0x65afb0: bl              #0x4f7474  ; [dart:ui] PictureRecorder::_constructor
    // 0x65afb4: add             SP, SP, #8
    // 0x65afb8: ldur            x0, [fp, #-8]
    // 0x65afbc: ldr             x1, [fp, #0x10]
    // 0x65afc0: StoreField: r1->field_13 = r0
    //     0x65afc0: stur            w0, [x1, #0x13]
    //     0x65afc4: ldurb           w16, [x1, #-1]
    //     0x65afc8: ldurb           w17, [x0, #-1]
    //     0x65afcc: and             x16, x17, x16, lsr #2
    //     0x65afd0: tst             x16, HEAP, lsr #32
    //     0x65afd4: b.eq            #0x65afdc
    //     0x65afd8: bl              #0xd6826c
    // 0x65afdc: r0 = Canvas()
    //     0x65afdc: bl              #0x65b05c  ; AllocateCanvasStub -> Canvas (size=0x10)
    // 0x65afe0: stur            x0, [fp, #-0x10]
    // 0x65afe4: ldur            x16, [fp, #-8]
    // 0x65afe8: stp             x16, x0, [SP, #-0x10]!
    // 0x65afec: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x65afec: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x65aff0: r0 = Canvas()
    //     0x65aff0: bl              #0x4f5a94  ; [dart:ui] Canvas::Canvas
    // 0x65aff4: add             SP, SP, #0x10
    // 0x65aff8: ldur            x0, [fp, #-0x10]
    // 0x65affc: ldr             x1, [fp, #0x10]
    // 0x65b000: StoreField: r1->field_17 = r0
    //     0x65b000: stur            w0, [x1, #0x17]
    //     0x65b004: ldurb           w16, [x1, #-1]
    //     0x65b008: ldurb           w17, [x0, #-1]
    //     0x65b00c: and             x16, x17, x16, lsr #2
    //     0x65b010: tst             x16, HEAP, lsr #32
    //     0x65b014: b.eq            #0x65b01c
    //     0x65b018: bl              #0xd6826c
    // 0x65b01c: LoadField: r0 = r1->field_7
    //     0x65b01c: ldur            w0, [x1, #7]
    // 0x65b020: DecompressPointer r0
    //     0x65b020: add             x0, x0, HEAP, lsl #32
    // 0x65b024: LoadField: r2 = r1->field_f
    //     0x65b024: ldur            w2, [x1, #0xf]
    // 0x65b028: DecompressPointer r2
    //     0x65b028: add             x2, x2, HEAP, lsl #32
    // 0x65b02c: cmp             w2, NULL
    // 0x65b030: b.eq            #0x65b058
    // 0x65b034: stp             x2, x0, [SP, #-0x10]!
    // 0x65b038: r0 = append()
    //     0x65b038: bl              #0x654230  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::append
    // 0x65b03c: add             SP, SP, #0x10
    // 0x65b040: r0 = Null
    //     0x65b040: mov             x0, NULL
    // 0x65b044: LeaveFrame
    //     0x65b044: mov             SP, fp
    //     0x65b048: ldp             fp, lr, [SP], #0x10
    // 0x65b04c: ret
    //     0x65b04c: ret             
    // 0x65b050: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65b050: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65b054: b               #0x65af5c
    // 0x65b058: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65b058: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ pushClipRect(/* No info */) {
    // ** addr: 0x65b240, size: 0x19c
    // 0x65b240: EnterFrame
    //     0x65b240: stp             fp, lr, [SP, #-0x10]!
    //     0x65b244: mov             fp, SP
    // 0x65b248: AllocStack(0x18)
    //     0x65b248: sub             SP, SP, #0x18
    // 0x65b24c: CheckStackOverflow
    //     0x65b24c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65b250: cmp             SP, x16
    //     0x65b254: b.ls            #0x65b3d4
    // 0x65b258: r1 = 3
    //     0x65b258: mov             x1, #3
    // 0x65b25c: r0 = AllocateContext()
    //     0x65b25c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x65b260: mov             x1, x0
    // 0x65b264: ldr             x0, [fp, #0x40]
    // 0x65b268: stur            x1, [fp, #-8]
    // 0x65b26c: StoreField: r1->field_f = r0
    //     0x65b26c: stur            w0, [x1, #0xf]
    // 0x65b270: ldr             x2, [fp, #0x30]
    // 0x65b274: StoreField: r1->field_13 = r2
    //     0x65b274: stur            w2, [x1, #0x13]
    // 0x65b278: ldr             x3, [fp, #0x20]
    // 0x65b27c: StoreField: r1->field_17 = r3
    //     0x65b27c: stur            w3, [x1, #0x17]
    // 0x65b280: ldr             x4, [fp, #0x18]
    // 0x65b284: r16 = Instance_Clip
    //     0x65b284: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x65b288: ldr             x16, [x16, #0xb38]
    // 0x65b28c: cmp             w4, w16
    // 0x65b290: b.ne            #0x65b2c0
    // 0x65b294: stp             x0, x3, [SP, #-0x10]!
    // 0x65b298: SaveReg r2
    //     0x65b298: str             x2, [SP, #-8]!
    // 0x65b29c: mov             x0, x3
    // 0x65b2a0: ClosureCall
    //     0x65b2a0: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x65b2a4: ldur            x2, [x0, #0x1f]
    //     0x65b2a8: blr             x2
    // 0x65b2ac: add             SP, SP, #0x18
    // 0x65b2b0: r0 = Null
    //     0x65b2b0: mov             x0, NULL
    // 0x65b2b4: LeaveFrame
    //     0x65b2b4: mov             SP, fp
    //     0x65b2b8: ldp             fp, lr, [SP], #0x10
    // 0x65b2bc: ret
    //     0x65b2bc: ret             
    // 0x65b2c0: ldr             x3, [fp, #0x38]
    // 0x65b2c4: ldr             x16, [fp, #0x28]
    // 0x65b2c8: stp             x2, x16, [SP, #-0x10]!
    // 0x65b2cc: r0 = shift()
    //     0x65b2cc: bl              #0x51a0bc  ; [dart:ui] Rect::shift
    // 0x65b2d0: add             SP, SP, #0x10
    // 0x65b2d4: mov             x1, x0
    // 0x65b2d8: ldr             x0, [fp, #0x38]
    // 0x65b2dc: stur            x1, [fp, #-0x10]
    // 0x65b2e0: tbnz            w0, #4, #0x65b390
    // 0x65b2e4: ldr             x0, [fp, #0x10]
    // 0x65b2e8: cmp             w0, NULL
    // 0x65b2ec: b.ne            #0x65b318
    // 0x65b2f0: r0 = ClipRectLayer()
    //     0x65b2f0: bl              #0x65bec8  ; AllocateClipRectLayerStub -> ClipRectLayer (size=0x50)
    // 0x65b2f4: mov             x1, x0
    // 0x65b2f8: r0 = Instance_Clip
    //     0x65b2f8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x65b2fc: ldr             x0, [x0, #0x678]
    // 0x65b300: stur            x1, [fp, #-0x18]
    // 0x65b304: StoreField: r1->field_4b = r0
    //     0x65b304: stur            w0, [x1, #0x4b]
    // 0x65b308: SaveReg r1
    //     0x65b308: str             x1, [SP, #-8]!
    // 0x65b30c: r0 = Layer()
    //     0x65b30c: bl              #0x5bbe7c  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0x65b310: add             SP, SP, #8
    // 0x65b314: ldur            x0, [fp, #-0x18]
    // 0x65b318: ldur            x2, [fp, #-8]
    // 0x65b31c: stur            x0, [fp, #-0x18]
    // 0x65b320: ldur            x16, [fp, #-0x10]
    // 0x65b324: stp             x16, x0, [SP, #-0x10]!
    // 0x65b328: r0 = clipRect=()
    //     0x65b328: bl              #0x65bdc0  ; [package:flutter/src/rendering/layer.dart] ClipRectLayer::clipRect=
    // 0x65b32c: add             SP, SP, #0x10
    // 0x65b330: ldur            x16, [fp, #-0x18]
    // 0x65b334: ldr             lr, [fp, #0x18]
    // 0x65b338: stp             lr, x16, [SP, #-0x10]!
    // 0x65b33c: r0 = clipBehavior=()
    //     0x65b33c: bl              #0x65bd50  ; [package:flutter/src/rendering/layer.dart] ClipPathLayer::clipBehavior=
    // 0x65b340: add             SP, SP, #0x10
    // 0x65b344: ldur            x2, [fp, #-8]
    // 0x65b348: LoadField: r0 = r2->field_17
    //     0x65b348: ldur            w0, [x2, #0x17]
    // 0x65b34c: DecompressPointer r0
    //     0x65b34c: add             x0, x0, HEAP, lsl #32
    // 0x65b350: LoadField: r1 = r2->field_13
    //     0x65b350: ldur            w1, [x2, #0x13]
    // 0x65b354: DecompressPointer r1
    //     0x65b354: add             x1, x1, HEAP, lsl #32
    // 0x65b358: ldr             x16, [fp, #0x40]
    // 0x65b35c: ldur            lr, [fp, #-0x18]
    // 0x65b360: stp             lr, x16, [SP, #-0x10]!
    // 0x65b364: stp             x1, x0, [SP, #-0x10]!
    // 0x65b368: ldur            x16, [fp, #-0x10]
    // 0x65b36c: SaveReg r16
    //     0x65b36c: str             x16, [SP, #-8]!
    // 0x65b370: r4 = const [0, 0x5, 0x5, 0x4, childPaintBounds, 0x4, null]
    //     0x65b370: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1cf00] List(7) [0, 0x5, 0x5, 0x4, "childPaintBounds", 0x4, Null]
    //     0x65b374: ldr             x4, [x4, #0xf00]
    // 0x65b378: r0 = pushLayer()
    //     0x65b378: bl              #0x65bbc8  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0x65b37c: add             SP, SP, #0x28
    // 0x65b380: ldur            x0, [fp, #-0x18]
    // 0x65b384: LeaveFrame
    //     0x65b384: mov             SP, fp
    //     0x65b388: ldp             fp, lr, [SP], #0x10
    // 0x65b38c: ret
    //     0x65b38c: ret             
    // 0x65b390: ldur            x2, [fp, #-8]
    // 0x65b394: r1 = Function '<anonymous closure>':.
    //     0x65b394: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d1f0] AnonymousClosure: (0x65bed4), in [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRect (0x65b240)
    //     0x65b398: ldr             x1, [x1, #0x1f0]
    // 0x65b39c: r0 = AllocateClosure()
    //     0x65b39c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x65b3a0: ldr             x16, [fp, #0x40]
    // 0x65b3a4: ldur            lr, [fp, #-0x10]
    // 0x65b3a8: stp             lr, x16, [SP, #-0x10]!
    // 0x65b3ac: ldr             x16, [fp, #0x18]
    // 0x65b3b0: ldur            lr, [fp, #-0x10]
    // 0x65b3b4: stp             lr, x16, [SP, #-0x10]!
    // 0x65b3b8: SaveReg r0
    //     0x65b3b8: str             x0, [SP, #-8]!
    // 0x65b3bc: r0 = clipRectAndPaint()
    //     0x65b3bc: bl              #0x65b3dc  ; [package:flutter/src/painting/clip.dart] ClipContext::clipRectAndPaint
    // 0x65b3c0: add             SP, SP, #0x28
    // 0x65b3c4: r0 = Null
    //     0x65b3c4: mov             x0, NULL
    // 0x65b3c8: LeaveFrame
    //     0x65b3c8: mov             SP, fp
    //     0x65b3cc: ldp             fp, lr, [SP], #0x10
    // 0x65b3d0: ret
    //     0x65b3d0: ret             
    // 0x65b3d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65b3d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65b3d8: b               #0x65b258
  }
  _ pushLayer(/* No info */) {
    // ** addr: 0x65bbc8, size: 0x160
    // 0x65bbc8: EnterFrame
    //     0x65bbc8: stp             fp, lr, [SP, #-0x10]!
    //     0x65bbcc: mov             fp, SP
    // 0x65bbd0: AllocStack(0x28)
    //     0x65bbd0: sub             SP, SP, #0x28
    // 0x65bbd4: SetupParameters(PaintingContext this /* r3, fp-0x28 */, dynamic _ /* r4, fp-0x20 */, dynamic _ /* r5, fp-0x18 */, dynamic _ /* r6, fp-0x10 */, {dynamic childPaintBounds = Null /* r0, fp-0x8 */})
    //     0x65bbd4: mov             x0, x4
    //     0x65bbd8: ldur            w1, [x0, #0x13]
    //     0x65bbdc: add             x1, x1, HEAP, lsl #32
    //     0x65bbe0: sub             x2, x1, #8
    //     0x65bbe4: add             x3, fp, w2, sxtw #2
    //     0x65bbe8: ldr             x3, [x3, #0x28]
    //     0x65bbec: stur            x3, [fp, #-0x28]
    //     0x65bbf0: add             x4, fp, w2, sxtw #2
    //     0x65bbf4: ldr             x4, [x4, #0x20]
    //     0x65bbf8: stur            x4, [fp, #-0x20]
    //     0x65bbfc: add             x5, fp, w2, sxtw #2
    //     0x65bc00: ldr             x5, [x5, #0x18]
    //     0x65bc04: stur            x5, [fp, #-0x18]
    //     0x65bc08: add             x6, fp, w2, sxtw #2
    //     0x65bc0c: ldr             x6, [x6, #0x10]
    //     0x65bc10: stur            x6, [fp, #-0x10]
    //     0x65bc14: ldur            w2, [x0, #0x1f]
    //     0x65bc18: add             x2, x2, HEAP, lsl #32
    //     0x65bc1c: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cf50] "childPaintBounds"
    //     0x65bc20: ldr             x16, [x16, #0xf50]
    //     0x65bc24: cmp             w2, w16
    //     0x65bc28: b.ne            #0x65bc48
    //     0x65bc2c: ldur            w2, [x0, #0x23]
    //     0x65bc30: add             x2, x2, HEAP, lsl #32
    //     0x65bc34: sub             w0, w1, w2
    //     0x65bc38: add             x1, fp, w0, sxtw #2
    //     0x65bc3c: ldr             x1, [x1, #8]
    //     0x65bc40: mov             x0, x1
    //     0x65bc44: b               #0x65bc4c
    //     0x65bc48: mov             x0, NULL
    //     0x65bc4c: stur            x0, [fp, #-8]
    // 0x65bc50: CheckStackOverflow
    //     0x65bc50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65bc54: cmp             SP, x16
    //     0x65bc58: b.ls            #0x65bd20
    // 0x65bc5c: LoadField: r1 = r4->field_3f
    //     0x65bc5c: ldur            w1, [x4, #0x3f]
    // 0x65bc60: DecompressPointer r1
    //     0x65bc60: add             x1, x1, HEAP, lsl #32
    // 0x65bc64: cmp             w1, NULL
    // 0x65bc68: b.eq            #0x65bc78
    // 0x65bc6c: SaveReg r4
    //     0x65bc6c: str             x4, [SP, #-8]!
    // 0x65bc70: r0 = removeAllChildren()
    //     0x65bc70: bl              #0x5df3f8  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::removeAllChildren
    // 0x65bc74: add             SP, SP, #8
    // 0x65bc78: ldur            x0, [fp, #-8]
    // 0x65bc7c: ldur            x16, [fp, #-0x28]
    // 0x65bc80: SaveReg r16
    //     0x65bc80: str             x16, [SP, #-8]!
    // 0x65bc84: r0 = stopRecordingIfNeeded()
    //     0x65bc84: bl              #0x5de9c8  ; [package:flutter/src/rendering/object.dart] PaintingContext::stopRecordingIfNeeded
    // 0x65bc88: add             SP, SP, #8
    // 0x65bc8c: ldur            x16, [fp, #-0x28]
    // 0x65bc90: ldur            lr, [fp, #-0x20]
    // 0x65bc94: stp             lr, x16, [SP, #-0x10]!
    // 0x65bc98: r0 = appendLayer()
    //     0x65bc98: bl              #0x6541d8  ; [package:flutter/src/rendering/object.dart] PaintingContext::appendLayer
    // 0x65bc9c: add             SP, SP, #0x10
    // 0x65bca0: ldur            x0, [fp, #-8]
    // 0x65bca4: cmp             w0, NULL
    // 0x65bca8: b.ne            #0x65bcbc
    // 0x65bcac: ldur            x1, [fp, #-0x28]
    // 0x65bcb0: LoadField: r0 = r1->field_b
    //     0x65bcb0: ldur            w0, [x1, #0xb]
    // 0x65bcb4: DecompressPointer r0
    //     0x65bcb4: add             x0, x0, HEAP, lsl #32
    // 0x65bcb8: b               #0x65bcc0
    // 0x65bcbc: ldur            x1, [fp, #-0x28]
    // 0x65bcc0: ldur            x16, [fp, #-0x20]
    // 0x65bcc4: stp             x16, x1, [SP, #-0x10]!
    // 0x65bcc8: SaveReg r0
    //     0x65bcc8: str             x0, [SP, #-8]!
    // 0x65bccc: r0 = createChildContext()
    //     0x65bccc: bl              #0x65bd28  ; [package:flutter/src/rendering/object.dart] PaintingContext::createChildContext
    // 0x65bcd0: add             SP, SP, #0x18
    // 0x65bcd4: mov             x1, x0
    // 0x65bcd8: stur            x1, [fp, #-8]
    // 0x65bcdc: ldur            x16, [fp, #-0x18]
    // 0x65bce0: stp             x1, x16, [SP, #-0x10]!
    // 0x65bce4: ldur            x16, [fp, #-0x10]
    // 0x65bce8: SaveReg r16
    //     0x65bce8: str             x16, [SP, #-8]!
    // 0x65bcec: ldur            x0, [fp, #-0x18]
    // 0x65bcf0: ClosureCall
    //     0x65bcf0: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x65bcf4: ldur            x2, [x0, #0x1f]
    //     0x65bcf8: blr             x2
    // 0x65bcfc: add             SP, SP, #0x18
    // 0x65bd00: ldur            x16, [fp, #-8]
    // 0x65bd04: SaveReg r16
    //     0x65bd04: str             x16, [SP, #-8]!
    // 0x65bd08: r0 = stopRecordingIfNeeded()
    //     0x65bd08: bl              #0x5de9c8  ; [package:flutter/src/rendering/object.dart] PaintingContext::stopRecordingIfNeeded
    // 0x65bd0c: add             SP, SP, #8
    // 0x65bd10: r0 = Null
    //     0x65bd10: mov             x0, NULL
    // 0x65bd14: LeaveFrame
    //     0x65bd14: mov             SP, fp
    //     0x65bd18: ldp             fp, lr, [SP], #0x10
    // 0x65bd1c: ret
    //     0x65bd1c: ret             
    // 0x65bd20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65bd20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65bd24: b               #0x65bc5c
  }
  _ createChildContext(/* No info */) {
    // ** addr: 0x65bd28, size: 0x28
    // 0x65bd28: EnterFrame
    //     0x65bd28: stp             fp, lr, [SP, #-0x10]!
    //     0x65bd2c: mov             fp, SP
    // 0x65bd30: r0 = PaintingContext()
    //     0x65bd30: bl              #0x5df3ec  ; AllocatePaintingContextStub -> PaintingContext (size=0x1c)
    // 0x65bd34: ldr             x1, [fp, #0x18]
    // 0x65bd38: StoreField: r0->field_7 = r1
    //     0x65bd38: stur            w1, [x0, #7]
    // 0x65bd3c: ldr             x1, [fp, #0x10]
    // 0x65bd40: StoreField: r0->field_b = r1
    //     0x65bd40: stur            w1, [x0, #0xb]
    // 0x65bd44: LeaveFrame
    //     0x65bd44: mov             SP, fp
    //     0x65bd48: ldp             fp, lr, [SP], #0x10
    // 0x65bd4c: ret
    //     0x65bd4c: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x65bed4, size: 0x70
    // 0x65bed4: EnterFrame
    //     0x65bed4: stp             fp, lr, [SP, #-0x10]!
    //     0x65bed8: mov             fp, SP
    // 0x65bedc: ldr             x0, [fp, #0x10]
    // 0x65bee0: LoadField: r1 = r0->field_17
    //     0x65bee0: ldur            w1, [x0, #0x17]
    // 0x65bee4: DecompressPointer r1
    //     0x65bee4: add             x1, x1, HEAP, lsl #32
    // 0x65bee8: CheckStackOverflow
    //     0x65bee8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65beec: cmp             SP, x16
    //     0x65bef0: b.ls            #0x65bf38
    // 0x65bef4: LoadField: r0 = r1->field_17
    //     0x65bef4: ldur            w0, [x1, #0x17]
    // 0x65bef8: DecompressPointer r0
    //     0x65bef8: add             x0, x0, HEAP, lsl #32
    // 0x65befc: LoadField: r2 = r1->field_f
    //     0x65befc: ldur            w2, [x1, #0xf]
    // 0x65bf00: DecompressPointer r2
    //     0x65bf00: add             x2, x2, HEAP, lsl #32
    // 0x65bf04: LoadField: r3 = r1->field_13
    //     0x65bf04: ldur            w3, [x1, #0x13]
    // 0x65bf08: DecompressPointer r3
    //     0x65bf08: add             x3, x3, HEAP, lsl #32
    // 0x65bf0c: cmp             w0, NULL
    // 0x65bf10: b.eq            #0x65bf40
    // 0x65bf14: stp             x2, x0, [SP, #-0x10]!
    // 0x65bf18: SaveReg r3
    //     0x65bf18: str             x3, [SP, #-8]!
    // 0x65bf1c: ClosureCall
    //     0x65bf1c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x65bf20: ldur            x2, [x0, #0x1f]
    //     0x65bf24: blr             x2
    // 0x65bf28: add             SP, SP, #0x18
    // 0x65bf2c: LeaveFrame
    //     0x65bf2c: mov             SP, fp
    //     0x65bf30: ldp             fp, lr, [SP], #0x10
    // 0x65bf34: ret
    //     0x65bf34: ret             
    // 0x65bf38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65bf38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65bf3c: b               #0x65bef4
    // 0x65bf40: r0 = NullErrorSharedWithoutFPURegs()
    //     0x65bf40: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ pushTransform(/* No info */) {
    // ** addr: 0x65d108, size: 0x2d4
    // 0x65d108: EnterFrame
    //     0x65d108: stp             fp, lr, [SP, #-0x10]!
    //     0x65d10c: mov             fp, SP
    // 0x65d110: AllocStack(0x48)
    //     0x65d110: sub             SP, SP, #0x48
    // 0x65d114: SetupParameters(PaintingContext this /* r3, fp-0x30 */, dynamic _ /* r4, fp-0x28 */, dynamic _ /* r5, fp-0x20 */, dynamic _ /* r6, fp-0x18 */, dynamic _ /* r7, fp-0x10 */, {dynamic oldLayer = Null /* r0, fp-0x8 */})
    //     0x65d114: mov             x0, x4
    //     0x65d118: ldur            w1, [x0, #0x13]
    //     0x65d11c: add             x1, x1, HEAP, lsl #32
    //     0x65d120: sub             x2, x1, #0xa
    //     0x65d124: add             x3, fp, w2, sxtw #2
    //     0x65d128: ldr             x3, [x3, #0x30]
    //     0x65d12c: stur            x3, [fp, #-0x30]
    //     0x65d130: add             x4, fp, w2, sxtw #2
    //     0x65d134: ldr             x4, [x4, #0x28]
    //     0x65d138: stur            x4, [fp, #-0x28]
    //     0x65d13c: add             x5, fp, w2, sxtw #2
    //     0x65d140: ldr             x5, [x5, #0x20]
    //     0x65d144: stur            x5, [fp, #-0x20]
    //     0x65d148: add             x6, fp, w2, sxtw #2
    //     0x65d14c: ldr             x6, [x6, #0x18]
    //     0x65d150: stur            x6, [fp, #-0x18]
    //     0x65d154: add             x7, fp, w2, sxtw #2
    //     0x65d158: ldr             x7, [x7, #0x10]
    //     0x65d15c: stur            x7, [fp, #-0x10]
    //     0x65d160: ldur            w2, [x0, #0x1f]
    //     0x65d164: add             x2, x2, HEAP, lsl #32
    //     0x65d168: ldr             x16, [PP, #0x7470]  ; [pp+0x7470] "oldLayer"
    //     0x65d16c: cmp             w2, w16
    //     0x65d170: b.ne            #0x65d190
    //     0x65d174: ldur            w2, [x0, #0x23]
    //     0x65d178: add             x2, x2, HEAP, lsl #32
    //     0x65d17c: sub             w0, w1, w2
    //     0x65d180: add             x1, fp, w0, sxtw #2
    //     0x65d184: ldr             x1, [x1, #8]
    //     0x65d188: mov             x0, x1
    //     0x65d18c: b               #0x65d194
    //     0x65d190: mov             x0, NULL
    //     0x65d194: stur            x0, [fp, #-8]
    // 0x65d198: CheckStackOverflow
    //     0x65d198: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65d19c: cmp             SP, x16
    //     0x65d1a0: b.ls            #0x65d398
    // 0x65d1a4: LoadField: d0 = r5->field_7
    //     0x65d1a4: ldur            d0, [x5, #7]
    // 0x65d1a8: stur            d0, [fp, #-0x48]
    // 0x65d1ac: LoadField: d1 = r5->field_f
    //     0x65d1ac: ldur            d1, [x5, #0xf]
    // 0x65d1b0: stur            d1, [fp, #-0x40]
    // 0x65d1b4: r1 = inline_Allocate_Double()
    //     0x65d1b4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x65d1b8: add             x1, x1, #0x10
    //     0x65d1bc: cmp             x2, x1
    //     0x65d1c0: b.ls            #0x65d3a0
    //     0x65d1c4: str             x1, [THR, #0x60]  ; THR::top
    //     0x65d1c8: sub             x1, x1, #0xf
    //     0x65d1cc: mov             x2, #0xd108
    //     0x65d1d0: movk            x2, #3, lsl #16
    //     0x65d1d4: stur            x2, [x1, #-1]
    // 0x65d1d8: StoreField: r1->field_7 = d0
    //     0x65d1d8: stur            d0, [x1, #7]
    // 0x65d1dc: stp             x1, NULL, [SP, #-0x10]!
    // 0x65d1e0: SaveReg d1
    //     0x65d1e0: str             d1, [SP, #-8]!
    // 0x65d1e4: r0 = Matrix4.translationValues()
    //     0x65d1e4: bl              #0x6245d8  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.translationValues
    // 0x65d1e8: add             SP, SP, #0x18
    // 0x65d1ec: stur            x0, [fp, #-0x38]
    // 0x65d1f0: ldur            x16, [fp, #-0x18]
    // 0x65d1f4: stp             x16, x0, [SP, #-0x10]!
    // 0x65d1f8: r0 = multiply()
    //     0x65d1f8: bl              #0x625d1c  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0x65d1fc: add             SP, SP, #0x10
    // 0x65d200: ldur            d0, [fp, #-0x48]
    // 0x65d204: fneg            d1, d0
    // 0x65d208: ldur            d0, [fp, #-0x40]
    // 0x65d20c: fneg            d2, d0
    // 0x65d210: r0 = inline_Allocate_Double()
    //     0x65d210: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x65d214: add             x0, x0, #0x10
    //     0x65d218: cmp             x1, x0
    //     0x65d21c: b.ls            #0x65d3cc
    //     0x65d220: str             x0, [THR, #0x60]  ; THR::top
    //     0x65d224: sub             x0, x0, #0xf
    //     0x65d228: mov             x1, #0xd108
    //     0x65d22c: movk            x1, #3, lsl #16
    //     0x65d230: stur            x1, [x0, #-1]
    // 0x65d234: StoreField: r0->field_7 = d1
    //     0x65d234: stur            d1, [x0, #7]
    // 0x65d238: ldur            x16, [fp, #-0x38]
    // 0x65d23c: stp             x0, x16, [SP, #-0x10]!
    // 0x65d240: SaveReg d2
    //     0x65d240: str             d2, [SP, #-8]!
    // 0x65d244: r0 = translate()
    //     0x65d244: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0x65d248: add             SP, SP, #0x18
    // 0x65d24c: ldur            x0, [fp, #-0x28]
    // 0x65d250: tbnz            w0, #4, #0x65d304
    // 0x65d254: ldur            x0, [fp, #-8]
    // 0x65d258: cmp             w0, NULL
    // 0x65d25c: b.ne            #0x65d290
    // 0x65d260: r0 = TransformLayer()
    //     0x65d260: bl              #0x5bbf34  ; AllocateTransformLayerStub -> TransformLayer (size=0x5c)
    // 0x65d264: mov             x1, x0
    // 0x65d268: r0 = true
    //     0x65d268: add             x0, NULL, #0x20  ; true
    // 0x65d26c: stur            x1, [fp, #-0x18]
    // 0x65d270: StoreField: r1->field_57 = r0
    //     0x65d270: stur            w0, [x1, #0x57]
    // 0x65d274: r0 = Instance_Offset
    //     0x65d274: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x65d278: StoreField: r1->field_47 = r0
    //     0x65d278: stur            w0, [x1, #0x47]
    // 0x65d27c: SaveReg r1
    //     0x65d27c: str             x1, [SP, #-8]!
    // 0x65d280: r0 = Layer()
    //     0x65d280: bl              #0x5bbe7c  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0x65d284: add             SP, SP, #8
    // 0x65d288: ldur            x1, [fp, #-0x18]
    // 0x65d28c: b               #0x65d294
    // 0x65d290: mov             x1, x0
    // 0x65d294: ldur            x0, [fp, #-0x30]
    // 0x65d298: stur            x1, [fp, #-8]
    // 0x65d29c: ldur            x16, [fp, #-0x38]
    // 0x65d2a0: stp             x16, x1, [SP, #-0x10]!
    // 0x65d2a4: r0 = transform=()
    //     0x65d2a4: bl              #0x65d728  ; [package:flutter/src/rendering/layer.dart] TransformLayer::transform=
    // 0x65d2a8: add             SP, SP, #0x10
    // 0x65d2ac: ldur            x0, [fp, #-0x30]
    // 0x65d2b0: LoadField: r1 = r0->field_b
    //     0x65d2b0: ldur            w1, [x0, #0xb]
    // 0x65d2b4: DecompressPointer r1
    //     0x65d2b4: add             x1, x1, HEAP, lsl #32
    // 0x65d2b8: ldur            x16, [fp, #-0x38]
    // 0x65d2bc: stp             x1, x16, [SP, #-0x10]!
    // 0x65d2c0: r0 = inverseTransformRect()
    //     0x65d2c0: bl              #0x65d3dc  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::inverseTransformRect
    // 0x65d2c4: add             SP, SP, #0x10
    // 0x65d2c8: ldur            x16, [fp, #-0x30]
    // 0x65d2cc: ldur            lr, [fp, #-8]
    // 0x65d2d0: stp             lr, x16, [SP, #-0x10]!
    // 0x65d2d4: ldur            x16, [fp, #-0x10]
    // 0x65d2d8: ldur            lr, [fp, #-0x20]
    // 0x65d2dc: stp             lr, x16, [SP, #-0x10]!
    // 0x65d2e0: SaveReg r0
    //     0x65d2e0: str             x0, [SP, #-8]!
    // 0x65d2e4: r4 = const [0, 0x5, 0x5, 0x4, childPaintBounds, 0x4, null]
    //     0x65d2e4: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1cf00] List(7) [0, 0x5, 0x5, 0x4, "childPaintBounds", 0x4, Null]
    //     0x65d2e8: ldr             x4, [x4, #0xf00]
    // 0x65d2ec: r0 = pushLayer()
    //     0x65d2ec: bl              #0x65bbc8  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0x65d2f0: add             SP, SP, #0x28
    // 0x65d2f4: ldur            x0, [fp, #-8]
    // 0x65d2f8: LeaveFrame
    //     0x65d2f8: mov             SP, fp
    //     0x65d2fc: ldp             fp, lr, [SP], #0x10
    // 0x65d300: ret
    //     0x65d300: ret             
    // 0x65d304: ldur            x0, [fp, #-0x38]
    // 0x65d308: ldur            x16, [fp, #-0x30]
    // 0x65d30c: SaveReg r16
    //     0x65d30c: str             x16, [SP, #-8]!
    // 0x65d310: r0 = canvas()
    //     0x65d310: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x65d314: add             SP, SP, #8
    // 0x65d318: stur            x0, [fp, #-8]
    // 0x65d31c: SaveReg r0
    //     0x65d31c: str             x0, [SP, #-8]!
    // 0x65d320: r0 = save()
    //     0x65d320: bl              #0x6595b0  ; [dart:ui] Canvas::save
    // 0x65d324: add             SP, SP, #8
    // 0x65d328: ldur            x0, [fp, #-0x38]
    // 0x65d32c: LoadField: r1 = r0->field_7
    //     0x65d32c: ldur            w1, [x0, #7]
    // 0x65d330: DecompressPointer r1
    //     0x65d330: add             x1, x1, HEAP, lsl #32
    // 0x65d334: ldur            x16, [fp, #-8]
    // 0x65d338: stp             x1, x16, [SP, #-0x10]!
    // 0x65d33c: r0 = transform()
    //     0x65d33c: bl              #0x656f48  ; [dart:ui] Canvas::transform
    // 0x65d340: add             SP, SP, #0x10
    // 0x65d344: ldur            x16, [fp, #-0x10]
    // 0x65d348: ldur            lr, [fp, #-0x30]
    // 0x65d34c: stp             lr, x16, [SP, #-0x10]!
    // 0x65d350: ldur            x16, [fp, #-0x20]
    // 0x65d354: SaveReg r16
    //     0x65d354: str             x16, [SP, #-8]!
    // 0x65d358: ldur            x0, [fp, #-0x10]
    // 0x65d35c: ClosureCall
    //     0x65d35c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x65d360: ldur            x2, [x0, #0x1f]
    //     0x65d364: blr             x2
    // 0x65d368: add             SP, SP, #0x18
    // 0x65d36c: ldur            x16, [fp, #-0x30]
    // 0x65d370: SaveReg r16
    //     0x65d370: str             x16, [SP, #-8]!
    // 0x65d374: r0 = canvas()
    //     0x65d374: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x65d378: add             SP, SP, #8
    // 0x65d37c: SaveReg r0
    //     0x65d37c: str             x0, [SP, #-8]!
    // 0x65d380: r0 = restore()
    //     0x65d380: bl              #0x65586c  ; [dart:ui] Canvas::restore
    // 0x65d384: add             SP, SP, #8
    // 0x65d388: r0 = Null
    //     0x65d388: mov             x0, NULL
    // 0x65d38c: LeaveFrame
    //     0x65d38c: mov             SP, fp
    //     0x65d390: ldp             fp, lr, [SP], #0x10
    // 0x65d394: ret
    //     0x65d394: ret             
    // 0x65d398: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65d398: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65d39c: b               #0x65d1a4
    // 0x65d3a0: stp             q0, q1, [SP, #-0x20]!
    // 0x65d3a4: stp             x6, x7, [SP, #-0x10]!
    // 0x65d3a8: stp             x4, x5, [SP, #-0x10]!
    // 0x65d3ac: stp             x0, x3, [SP, #-0x10]!
    // 0x65d3b0: r0 = AllocateDouble()
    //     0x65d3b0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65d3b4: mov             x1, x0
    // 0x65d3b8: ldp             x0, x3, [SP], #0x10
    // 0x65d3bc: ldp             x4, x5, [SP], #0x10
    // 0x65d3c0: ldp             x6, x7, [SP], #0x10
    // 0x65d3c4: ldp             q0, q1, [SP], #0x20
    // 0x65d3c8: b               #0x65d1d8
    // 0x65d3cc: stp             q1, q2, [SP, #-0x20]!
    // 0x65d3d0: r0 = AllocateDouble()
    //     0x65d3d0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65d3d4: ldp             q1, q2, [SP], #0x20
    // 0x65d3d8: b               #0x65d234
  }
  _ pushOpacity(/* No info */) {
    // ** addr: 0x66116c, size: 0xc8
    // 0x66116c: EnterFrame
    //     0x66116c: stp             fp, lr, [SP, #-0x10]!
    //     0x661170: mov             fp, SP
    // 0x661174: AllocStack(0x8)
    //     0x661174: sub             SP, SP, #8
    // 0x661178: CheckStackOverflow
    //     0x661178: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66117c: cmp             SP, x16
    //     0x661180: b.ls            #0x66122c
    // 0x661184: ldr             x0, [fp, #0x10]
    // 0x661188: cmp             w0, NULL
    // 0x66118c: b.ne            #0x6611b8
    // 0x661190: r0 = OpacityLayer()
    //     0x661190: bl              #0x661624  ; AllocateOpacityLayerStub -> OpacityLayer (size=0x50)
    // 0x661194: mov             x1, x0
    // 0x661198: r0 = Instance_Offset
    //     0x661198: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x66119c: stur            x1, [fp, #-8]
    // 0x6611a0: StoreField: r1->field_47 = r0
    //     0x6611a0: stur            w0, [x1, #0x47]
    // 0x6611a4: SaveReg r1
    //     0x6611a4: str             x1, [SP, #-8]!
    // 0x6611a8: r0 = Layer()
    //     0x6611a8: bl              #0x5bbe7c  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0x6611ac: add             SP, SP, #8
    // 0x6611b0: ldur            x3, [fp, #-8]
    // 0x6611b4: b               #0x6611bc
    // 0x6611b8: mov             x3, x0
    // 0x6611bc: ldr             x2, [fp, #0x20]
    // 0x6611c0: stur            x3, [fp, #-8]
    // 0x6611c4: r0 = BoxInt64Instr(r2)
    //     0x6611c4: sbfiz           x0, x2, #1, #0x1f
    //     0x6611c8: cmp             x2, x0, asr #1
    //     0x6611cc: b.eq            #0x6611d8
    //     0x6611d0: bl              #0xd69bb8
    //     0x6611d4: stur            x2, [x0, #7]
    // 0x6611d8: stp             x0, x3, [SP, #-0x10]!
    // 0x6611dc: r0 = alpha=()
    //     0x6611dc: bl              #0x661234  ; [package:flutter/src/rendering/layer.dart] OpacityLayer::alpha=
    // 0x6611e0: add             SP, SP, #0x10
    // 0x6611e4: ldur            x16, [fp, #-8]
    // 0x6611e8: ldr             lr, [fp, #0x28]
    // 0x6611ec: stp             lr, x16, [SP, #-0x10]!
    // 0x6611f0: r0 = offset=()
    //     0x6611f0: bl              #0x65455c  ; [package:flutter/src/rendering/layer.dart] OffsetLayer::offset=
    // 0x6611f4: add             SP, SP, #0x10
    // 0x6611f8: ldr             x16, [fp, #0x30]
    // 0x6611fc: ldur            lr, [fp, #-8]
    // 0x661200: stp             lr, x16, [SP, #-0x10]!
    // 0x661204: ldr             x16, [fp, #0x18]
    // 0x661208: r30 = Instance_Offset
    //     0x661208: ldr             lr, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x66120c: stp             lr, x16, [SP, #-0x10]!
    // 0x661210: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x661210: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x661214: r0 = pushLayer()
    //     0x661214: bl              #0x65bbc8  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0x661218: add             SP, SP, #0x20
    // 0x66121c: ldur            x0, [fp, #-8]
    // 0x661220: LeaveFrame
    //     0x661220: mov             SP, fp
    //     0x661224: ldp             fp, lr, [SP], #0x10
    // 0x661228: ret
    //     0x661228: ret             
    // 0x66122c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66122c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x661230: b               #0x661184
  }
  _ pushClipRRect(/* No info */) {
    // ** addr: 0x661d8c, size: 0x1bc
    // 0x661d8c: EnterFrame
    //     0x661d8c: stp             fp, lr, [SP, #-0x10]!
    //     0x661d90: mov             fp, SP
    // 0x661d94: AllocStack(0x20)
    //     0x661d94: sub             SP, SP, #0x20
    // 0x661d98: CheckStackOverflow
    //     0x661d98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x661d9c: cmp             SP, x16
    //     0x661da0: b.ls            #0x661f40
    // 0x661da4: r1 = 3
    //     0x661da4: mov             x1, #3
    // 0x661da8: r0 = AllocateContext()
    //     0x661da8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x661dac: mov             x1, x0
    // 0x661db0: ldr             x0, [fp, #0x48]
    // 0x661db4: stur            x1, [fp, #-8]
    // 0x661db8: StoreField: r1->field_f = r0
    //     0x661db8: stur            w0, [x1, #0xf]
    // 0x661dbc: ldr             x2, [fp, #0x38]
    // 0x661dc0: StoreField: r1->field_13 = r2
    //     0x661dc0: stur            w2, [x1, #0x13]
    // 0x661dc4: ldr             x3, [fp, #0x20]
    // 0x661dc8: StoreField: r1->field_17 = r3
    //     0x661dc8: stur            w3, [x1, #0x17]
    // 0x661dcc: ldr             x4, [fp, #0x18]
    // 0x661dd0: r16 = Instance_Clip
    //     0x661dd0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x661dd4: ldr             x16, [x16, #0xb38]
    // 0x661dd8: cmp             w4, w16
    // 0x661ddc: b.ne            #0x661e0c
    // 0x661de0: stp             x0, x3, [SP, #-0x10]!
    // 0x661de4: SaveReg r2
    //     0x661de4: str             x2, [SP, #-8]!
    // 0x661de8: mov             x0, x3
    // 0x661dec: ClosureCall
    //     0x661dec: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x661df0: ldur            x2, [x0, #0x1f]
    //     0x661df4: blr             x2
    // 0x661df8: add             SP, SP, #0x18
    // 0x661dfc: r0 = Null
    //     0x661dfc: mov             x0, NULL
    // 0x661e00: LeaveFrame
    //     0x661e00: mov             SP, fp
    //     0x661e04: ldp             fp, lr, [SP], #0x10
    // 0x661e08: ret
    //     0x661e08: ret             
    // 0x661e0c: ldr             x3, [fp, #0x40]
    // 0x661e10: ldr             x16, [fp, #0x30]
    // 0x661e14: stp             x2, x16, [SP, #-0x10]!
    // 0x661e18: r0 = shift()
    //     0x661e18: bl              #0x51a0bc  ; [dart:ui] Rect::shift
    // 0x661e1c: add             SP, SP, #0x10
    // 0x661e20: ldur            x2, [fp, #-8]
    // 0x661e24: stur            x0, [fp, #-0x10]
    // 0x661e28: LoadField: r1 = r2->field_13
    //     0x661e28: ldur            w1, [x2, #0x13]
    // 0x661e2c: DecompressPointer r1
    //     0x661e2c: add             x1, x1, HEAP, lsl #32
    // 0x661e30: ldr             x16, [fp, #0x28]
    // 0x661e34: stp             x1, x16, [SP, #-0x10]!
    // 0x661e38: r0 = shift()
    //     0x661e38: bl              #0x65fe90  ; [dart:ui] RRect::shift
    // 0x661e3c: add             SP, SP, #0x10
    // 0x661e40: mov             x1, x0
    // 0x661e44: ldr             x0, [fp, #0x40]
    // 0x661e48: stur            x1, [fp, #-0x18]
    // 0x661e4c: tbnz            w0, #4, #0x661efc
    // 0x661e50: ldr             x0, [fp, #0x10]
    // 0x661e54: cmp             w0, NULL
    // 0x661e58: b.ne            #0x661e84
    // 0x661e5c: r0 = ClipRRectLayer()
    //     0x661e5c: bl              #0x6624cc  ; AllocateClipRRectLayerStub -> ClipRRectLayer (size=0x50)
    // 0x661e60: mov             x1, x0
    // 0x661e64: r0 = Instance_Clip
    //     0x661e64: add             x0, PP, #0x21, lsl #12  ; [pp+0x21ad0] Obj!Clip@b676b1
    //     0x661e68: ldr             x0, [x0, #0xad0]
    // 0x661e6c: stur            x1, [fp, #-0x20]
    // 0x661e70: StoreField: r1->field_4b = r0
    //     0x661e70: stur            w0, [x1, #0x4b]
    // 0x661e74: SaveReg r1
    //     0x661e74: str             x1, [SP, #-8]!
    // 0x661e78: r0 = Layer()
    //     0x661e78: bl              #0x5bbe7c  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0x661e7c: add             SP, SP, #8
    // 0x661e80: ldur            x0, [fp, #-0x20]
    // 0x661e84: ldur            x2, [fp, #-8]
    // 0x661e88: stur            x0, [fp, #-0x20]
    // 0x661e8c: ldur            x16, [fp, #-0x18]
    // 0x661e90: stp             x16, x0, [SP, #-0x10]!
    // 0x661e94: r0 = clipRRect=()
    //     0x661e94: bl              #0x662450  ; [package:flutter/src/rendering/layer.dart] ClipRRectLayer::clipRRect=
    // 0x661e98: add             SP, SP, #0x10
    // 0x661e9c: ldur            x16, [fp, #-0x20]
    // 0x661ea0: ldr             lr, [fp, #0x18]
    // 0x661ea4: stp             lr, x16, [SP, #-0x10]!
    // 0x661ea8: r0 = clipBehavior=()
    //     0x661ea8: bl              #0x65bd50  ; [package:flutter/src/rendering/layer.dart] ClipPathLayer::clipBehavior=
    // 0x661eac: add             SP, SP, #0x10
    // 0x661eb0: ldur            x2, [fp, #-8]
    // 0x661eb4: LoadField: r0 = r2->field_17
    //     0x661eb4: ldur            w0, [x2, #0x17]
    // 0x661eb8: DecompressPointer r0
    //     0x661eb8: add             x0, x0, HEAP, lsl #32
    // 0x661ebc: LoadField: r1 = r2->field_13
    //     0x661ebc: ldur            w1, [x2, #0x13]
    // 0x661ec0: DecompressPointer r1
    //     0x661ec0: add             x1, x1, HEAP, lsl #32
    // 0x661ec4: ldr             x16, [fp, #0x48]
    // 0x661ec8: ldur            lr, [fp, #-0x20]
    // 0x661ecc: stp             lr, x16, [SP, #-0x10]!
    // 0x661ed0: stp             x1, x0, [SP, #-0x10]!
    // 0x661ed4: ldur            x16, [fp, #-0x10]
    // 0x661ed8: SaveReg r16
    //     0x661ed8: str             x16, [SP, #-8]!
    // 0x661edc: r4 = const [0, 0x5, 0x5, 0x4, childPaintBounds, 0x4, null]
    //     0x661edc: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1cf00] List(7) [0, 0x5, 0x5, 0x4, "childPaintBounds", 0x4, Null]
    //     0x661ee0: ldr             x4, [x4, #0xf00]
    // 0x661ee4: r0 = pushLayer()
    //     0x661ee4: bl              #0x65bbc8  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0x661ee8: add             SP, SP, #0x28
    // 0x661eec: ldur            x0, [fp, #-0x20]
    // 0x661ef0: LeaveFrame
    //     0x661ef0: mov             SP, fp
    //     0x661ef4: ldp             fp, lr, [SP], #0x10
    // 0x661ef8: ret
    //     0x661ef8: ret             
    // 0x661efc: ldur            x2, [fp, #-8]
    // 0x661f00: r1 = Function '<anonymous closure>':.
    //     0x661f00: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2d6a8] AnonymousClosure: (0x65bed4), in [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRect (0x65b240)
    //     0x661f04: ldr             x1, [x1, #0x6a8]
    // 0x661f08: r0 = AllocateClosure()
    //     0x661f08: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x661f0c: ldr             x16, [fp, #0x48]
    // 0x661f10: ldur            lr, [fp, #-0x18]
    // 0x661f14: stp             lr, x16, [SP, #-0x10]!
    // 0x661f18: ldr             x16, [fp, #0x18]
    // 0x661f1c: ldur            lr, [fp, #-0x10]
    // 0x661f20: stp             lr, x16, [SP, #-0x10]!
    // 0x661f24: SaveReg r0
    //     0x661f24: str             x0, [SP, #-8]!
    // 0x661f28: r0 = clipRRectAndPaint()
    //     0x661f28: bl              #0x661f48  ; [package:flutter/src/painting/clip.dart] ClipContext::clipRRectAndPaint
    // 0x661f2c: add             SP, SP, #0x28
    // 0x661f30: r0 = Null
    //     0x661f30: mov             x0, NULL
    // 0x661f34: LeaveFrame
    //     0x661f34: mov             SP, fp
    //     0x661f38: ldp             fp, lr, [SP], #0x10
    // 0x661f3c: ret
    //     0x661f3c: ret             
    // 0x661f40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x661f40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x661f44: b               #0x661da4
  }
  _ pushClipPath(/* No info */) {
    // ** addr: 0x6626a0, size: 0x260
    // 0x6626a0: EnterFrame
    //     0x6626a0: stp             fp, lr, [SP, #-0x10]!
    //     0x6626a4: mov             fp, SP
    // 0x6626a8: AllocStack(0x48)
    //     0x6626a8: sub             SP, SP, #0x48
    // 0x6626ac: SetupParameters(PaintingContext this /* r3, fp-0x40 */, dynamic _ /* r4, fp-0x38 */, dynamic _ /* r5, fp-0x30 */, dynamic _ /* r6, fp-0x28 */, dynamic _ /* r7, fp-0x20 */, dynamic _ /* r8, fp-0x18 */, dynamic _ /* r9, fp-0x10 */, {dynamic clipBehavior = Instance_Clip /* r0, fp-0x8 */})
    //     0x6626ac: mov             x0, x4
    //     0x6626b0: ldur            w1, [x0, #0x13]
    //     0x6626b4: add             x1, x1, HEAP, lsl #32
    //     0x6626b8: sub             x2, x1, #0xe
    //     0x6626bc: add             x3, fp, w2, sxtw #2
    //     0x6626c0: ldr             x3, [x3, #0x40]
    //     0x6626c4: stur            x3, [fp, #-0x40]
    //     0x6626c8: add             x4, fp, w2, sxtw #2
    //     0x6626cc: ldr             x4, [x4, #0x38]
    //     0x6626d0: stur            x4, [fp, #-0x38]
    //     0x6626d4: add             x5, fp, w2, sxtw #2
    //     0x6626d8: ldr             x5, [x5, #0x30]
    //     0x6626dc: stur            x5, [fp, #-0x30]
    //     0x6626e0: add             x6, fp, w2, sxtw #2
    //     0x6626e4: ldr             x6, [x6, #0x28]
    //     0x6626e8: stur            x6, [fp, #-0x28]
    //     0x6626ec: add             x7, fp, w2, sxtw #2
    //     0x6626f0: ldr             x7, [x7, #0x20]
    //     0x6626f4: stur            x7, [fp, #-0x20]
    //     0x6626f8: add             x8, fp, w2, sxtw #2
    //     0x6626fc: ldr             x8, [x8, #0x18]
    //     0x662700: stur            x8, [fp, #-0x18]
    //     0x662704: add             x9, fp, w2, sxtw #2
    //     0x662708: ldr             x9, [x9, #0x10]
    //     0x66270c: stur            x9, [fp, #-0x10]
    //     0x662710: ldur            w2, [x0, #0x1f]
    //     0x662714: add             x2, x2, HEAP, lsl #32
    //     0x662718: add             x16, PP, #0x21, lsl #12  ; [pp+0x21ac8] "clipBehavior"
    //     0x66271c: ldr             x16, [x16, #0xac8]
    //     0x662720: cmp             w2, w16
    //     0x662724: b.ne            #0x662744
    //     0x662728: ldur            w2, [x0, #0x23]
    //     0x66272c: add             x2, x2, HEAP, lsl #32
    //     0x662730: sub             w0, w1, w2
    //     0x662734: add             x1, fp, w0, sxtw #2
    //     0x662738: ldr             x1, [x1, #8]
    //     0x66273c: mov             x0, x1
    //     0x662740: b               #0x66274c
    //     0x662744: add             x0, PP, #0x21, lsl #12  ; [pp+0x21ad0] Obj!Clip@b676b1
    //     0x662748: ldr             x0, [x0, #0xad0]
    //     0x66274c: stur            x0, [fp, #-8]
    // 0x662750: CheckStackOverflow
    //     0x662750: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x662754: cmp             SP, x16
    //     0x662758: b.ls            #0x6628f8
    // 0x66275c: r1 = 3
    //     0x66275c: mov             x1, #3
    // 0x662760: r0 = AllocateContext()
    //     0x662760: bl              #0xd68aa4  ; AllocateContextStub
    // 0x662764: mov             x1, x0
    // 0x662768: ldur            x0, [fp, #-0x40]
    // 0x66276c: stur            x1, [fp, #-0x48]
    // 0x662770: StoreField: r1->field_f = r0
    //     0x662770: stur            w0, [x1, #0xf]
    // 0x662774: ldur            x2, [fp, #-0x30]
    // 0x662778: StoreField: r1->field_13 = r2
    //     0x662778: stur            w2, [x1, #0x13]
    // 0x66277c: ldur            x3, [fp, #-0x18]
    // 0x662780: StoreField: r1->field_17 = r3
    //     0x662780: stur            w3, [x1, #0x17]
    // 0x662784: ldur            x4, [fp, #-8]
    // 0x662788: r16 = Instance_Clip
    //     0x662788: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x66278c: ldr             x16, [x16, #0xb38]
    // 0x662790: cmp             w4, w16
    // 0x662794: b.ne            #0x6627c4
    // 0x662798: stp             x0, x3, [SP, #-0x10]!
    // 0x66279c: SaveReg r2
    //     0x66279c: str             x2, [SP, #-8]!
    // 0x6627a0: mov             x0, x3
    // 0x6627a4: ClosureCall
    //     0x6627a4: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x6627a8: ldur            x2, [x0, #0x1f]
    //     0x6627ac: blr             x2
    // 0x6627b0: add             SP, SP, #0x18
    // 0x6627b4: r0 = Null
    //     0x6627b4: mov             x0, NULL
    // 0x6627b8: LeaveFrame
    //     0x6627b8: mov             SP, fp
    //     0x6627bc: ldp             fp, lr, [SP], #0x10
    // 0x6627c0: ret
    //     0x6627c0: ret             
    // 0x6627c4: ldur            x3, [fp, #-0x38]
    // 0x6627c8: ldur            x16, [fp, #-0x28]
    // 0x6627cc: stp             x2, x16, [SP, #-0x10]!
    // 0x6627d0: r0 = shift()
    //     0x6627d0: bl              #0x51a0bc  ; [dart:ui] Rect::shift
    // 0x6627d4: add             SP, SP, #0x10
    // 0x6627d8: ldur            x2, [fp, #-0x48]
    // 0x6627dc: stur            x0, [fp, #-0x18]
    // 0x6627e0: LoadField: r1 = r2->field_13
    //     0x6627e0: ldur            w1, [x2, #0x13]
    // 0x6627e4: DecompressPointer r1
    //     0x6627e4: add             x1, x1, HEAP, lsl #32
    // 0x6627e8: ldur            x16, [fp, #-0x20]
    // 0x6627ec: stp             x1, x16, [SP, #-0x10]!
    // 0x6627f0: r0 = shift()
    //     0x6627f0: bl              #0x662dc8  ; [dart:ui] Path::shift
    // 0x6627f4: add             SP, SP, #0x10
    // 0x6627f8: mov             x1, x0
    // 0x6627fc: ldur            x0, [fp, #-0x38]
    // 0x662800: stur            x1, [fp, #-0x20]
    // 0x662804: tbnz            w0, #4, #0x6628b4
    // 0x662808: ldur            x0, [fp, #-0x10]
    // 0x66280c: cmp             w0, NULL
    // 0x662810: b.ne            #0x66283c
    // 0x662814: r0 = ClipPathLayer()
    //     0x662814: bl              #0x662dbc  ; AllocateClipPathLayerStub -> ClipPathLayer (size=0x50)
    // 0x662818: mov             x1, x0
    // 0x66281c: r0 = Instance_Clip
    //     0x66281c: add             x0, PP, #0x21, lsl #12  ; [pp+0x21ad0] Obj!Clip@b676b1
    //     0x662820: ldr             x0, [x0, #0xad0]
    // 0x662824: stur            x1, [fp, #-0x28]
    // 0x662828: StoreField: r1->field_4b = r0
    //     0x662828: stur            w0, [x1, #0x4b]
    // 0x66282c: SaveReg r1
    //     0x66282c: str             x1, [SP, #-8]!
    // 0x662830: r0 = Layer()
    //     0x662830: bl              #0x5bbe7c  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0x662834: add             SP, SP, #8
    // 0x662838: ldur            x0, [fp, #-0x28]
    // 0x66283c: ldur            x2, [fp, #-0x48]
    // 0x662840: stur            x0, [fp, #-0x10]
    // 0x662844: ldur            x16, [fp, #-0x20]
    // 0x662848: stp             x16, x0, [SP, #-0x10]!
    // 0x66284c: r0 = clipPath=()
    //     0x66284c: bl              #0x662d4c  ; [package:flutter/src/rendering/layer.dart] ClipPathLayer::clipPath=
    // 0x662850: add             SP, SP, #0x10
    // 0x662854: ldur            x16, [fp, #-0x10]
    // 0x662858: ldur            lr, [fp, #-8]
    // 0x66285c: stp             lr, x16, [SP, #-0x10]!
    // 0x662860: r0 = clipBehavior=()
    //     0x662860: bl              #0x65bd50  ; [package:flutter/src/rendering/layer.dart] ClipPathLayer::clipBehavior=
    // 0x662864: add             SP, SP, #0x10
    // 0x662868: ldur            x2, [fp, #-0x48]
    // 0x66286c: LoadField: r0 = r2->field_17
    //     0x66286c: ldur            w0, [x2, #0x17]
    // 0x662870: DecompressPointer r0
    //     0x662870: add             x0, x0, HEAP, lsl #32
    // 0x662874: LoadField: r1 = r2->field_13
    //     0x662874: ldur            w1, [x2, #0x13]
    // 0x662878: DecompressPointer r1
    //     0x662878: add             x1, x1, HEAP, lsl #32
    // 0x66287c: ldur            x16, [fp, #-0x40]
    // 0x662880: ldur            lr, [fp, #-0x10]
    // 0x662884: stp             lr, x16, [SP, #-0x10]!
    // 0x662888: stp             x1, x0, [SP, #-0x10]!
    // 0x66288c: ldur            x16, [fp, #-0x18]
    // 0x662890: SaveReg r16
    //     0x662890: str             x16, [SP, #-8]!
    // 0x662894: r4 = const [0, 0x5, 0x5, 0x4, childPaintBounds, 0x4, null]
    //     0x662894: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1cf00] List(7) [0, 0x5, 0x5, 0x4, "childPaintBounds", 0x4, Null]
    //     0x662898: ldr             x4, [x4, #0xf00]
    // 0x66289c: r0 = pushLayer()
    //     0x66289c: bl              #0x65bbc8  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0x6628a0: add             SP, SP, #0x28
    // 0x6628a4: ldur            x0, [fp, #-0x10]
    // 0x6628a8: LeaveFrame
    //     0x6628a8: mov             SP, fp
    //     0x6628ac: ldp             fp, lr, [SP], #0x10
    // 0x6628b0: ret
    //     0x6628b0: ret             
    // 0x6628b4: ldur            x2, [fp, #-0x48]
    // 0x6628b8: r1 = Function '<anonymous closure>':.
    //     0x6628b8: add             x1, PP, #0x21, lsl #12  ; [pp+0x21ad8] AnonymousClosure: (0x65bed4), in [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRect (0x65b240)
    //     0x6628bc: ldr             x1, [x1, #0xad8]
    // 0x6628c0: r0 = AllocateClosure()
    //     0x6628c0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6628c4: ldur            x16, [fp, #-0x40]
    // 0x6628c8: ldur            lr, [fp, #-0x20]
    // 0x6628cc: stp             lr, x16, [SP, #-0x10]!
    // 0x6628d0: ldur            x16, [fp, #-8]
    // 0x6628d4: ldur            lr, [fp, #-0x18]
    // 0x6628d8: stp             lr, x16, [SP, #-0x10]!
    // 0x6628dc: SaveReg r0
    //     0x6628dc: str             x0, [SP, #-8]!
    // 0x6628e0: r0 = clipPathAndPaint()
    //     0x6628e0: bl              #0x662900  ; [package:flutter/src/painting/clip.dart] ClipContext::clipPathAndPaint
    // 0x6628e4: add             SP, SP, #0x28
    // 0x6628e8: r0 = Null
    //     0x6628e8: mov             x0, NULL
    // 0x6628ec: LeaveFrame
    //     0x6628ec: mov             SP, fp
    //     0x6628f0: ldp             fp, lr, [SP], #0x10
    // 0x6628f4: ret
    //     0x6628f4: ret             
    // 0x6628f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6628f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6628fc: b               #0x66275c
  }
  _ setIsComplexHint(/* No info */) {
    // ** addr: 0x6654e4, size: 0x50
    // 0x6654e4: EnterFrame
    //     0x6654e4: stp             fp, lr, [SP, #-0x10]!
    //     0x6654e8: mov             fp, SP
    // 0x6654ec: CheckStackOverflow
    //     0x6654ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6654f0: cmp             SP, x16
    //     0x6654f4: b.ls            #0x66552c
    // 0x6654f8: ldr             x0, [fp, #0x10]
    // 0x6654fc: LoadField: r1 = r0->field_f
    //     0x6654fc: ldur            w1, [x0, #0xf]
    // 0x665500: DecompressPointer r1
    //     0x665500: add             x1, x1, HEAP, lsl #32
    // 0x665504: cmp             w1, NULL
    // 0x665508: b.eq            #0x66551c
    // 0x66550c: r16 = true
    //     0x66550c: add             x16, NULL, #0x20  ; true
    // 0x665510: stp             x16, x1, [SP, #-0x10]!
    // 0x665514: r0 = isComplexHint=()
    //     0x665514: bl              #0x665534  ; [package:flutter/src/rendering/layer.dart] PictureLayer::isComplexHint=
    // 0x665518: add             SP, SP, #0x10
    // 0x66551c: r0 = Null
    //     0x66551c: mov             x0, NULL
    // 0x665520: LeaveFrame
    //     0x665520: mov             SP, fp
    //     0x665524: ldp             fp, lr, [SP], #0x10
    // 0x665528: ret
    //     0x665528: ret             
    // 0x66552c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66552c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x665530: b               #0x6654f8
  }
  _ addLayer(/* No info */) {
    // ** addr: 0x66eec4, size: 0x50
    // 0x66eec4: EnterFrame
    //     0x66eec4: stp             fp, lr, [SP, #-0x10]!
    //     0x66eec8: mov             fp, SP
    // 0x66eecc: CheckStackOverflow
    //     0x66eecc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66eed0: cmp             SP, x16
    //     0x66eed4: b.ls            #0x66ef0c
    // 0x66eed8: ldr             x16, [fp, #0x18]
    // 0x66eedc: SaveReg r16
    //     0x66eedc: str             x16, [SP, #-8]!
    // 0x66eee0: r0 = stopRecordingIfNeeded()
    //     0x66eee0: bl              #0x5de9c8  ; [package:flutter/src/rendering/object.dart] PaintingContext::stopRecordingIfNeeded
    // 0x66eee4: add             SP, SP, #8
    // 0x66eee8: ldr             x16, [fp, #0x18]
    // 0x66eeec: ldr             lr, [fp, #0x10]
    // 0x66eef0: stp             lr, x16, [SP, #-0x10]!
    // 0x66eef4: r0 = appendLayer()
    //     0x66eef4: bl              #0x6541d8  ; [package:flutter/src/rendering/object.dart] PaintingContext::appendLayer
    // 0x66eef8: add             SP, SP, #0x10
    // 0x66eefc: r0 = Null
    //     0x66eefc: mov             x0, NULL
    // 0x66ef00: LeaveFrame
    //     0x66ef00: mov             SP, fp
    //     0x66ef04: ldp             fp, lr, [SP], #0x10
    // 0x66ef08: ret
    //     0x66ef08: ret             
    // 0x66ef0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66ef0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66ef10: b               #0x66eed8
  }
  _ toString(/* No info */) {
    // ** addr: 0xae0994, size: 0xec
    // 0xae0994: EnterFrame
    //     0xae0994: stp             fp, lr, [SP, #-0x10]!
    //     0xae0998: mov             fp, SP
    // 0xae099c: AllocStack(0x8)
    //     0xae099c: sub             SP, SP, #8
    // 0xae09a0: CheckStackOverflow
    //     0xae09a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae09a4: cmp             SP, x16
    //     0xae09a8: b.ls            #0xae0a78
    // 0xae09ac: r1 = Null
    //     0xae09ac: mov             x1, NULL
    // 0xae09b0: r2 = 16
    //     0xae09b0: mov             x2, #0x10
    // 0xae09b4: r0 = AllocateArray()
    //     0xae09b4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae09b8: stur            x0, [fp, #-8]
    // 0xae09bc: r17 = "PaintingContext"
    //     0xae09bc: ldr             x17, [PP, #0x7380]  ; [pp+0x7380] "PaintingContext"
    // 0xae09c0: StoreField: r0->field_f = r17
    //     0xae09c0: stur            w17, [x0, #0xf]
    // 0xae09c4: r17 = "#"
    //     0xae09c4: ldr             x17, [PP, #0x11c8]  ; [pp+0x11c8] "#"
    // 0xae09c8: StoreField: r0->field_13 = r17
    //     0xae09c8: stur            w17, [x0, #0x13]
    // 0xae09cc: ldr             x16, [fp, #0x10]
    // 0xae09d0: SaveReg r16
    //     0xae09d0: str             x16, [SP, #-8]!
    // 0xae09d4: r0 = _getHash()
    //     0xae09d4: bl              #0x5c2424  ; [dart:core] ::_getHash
    // 0xae09d8: add             SP, SP, #8
    // 0xae09dc: ldur            x2, [fp, #-8]
    // 0xae09e0: StoreField: r2->field_17 = r0
    //     0xae09e0: stur            w0, [x2, #0x17]
    // 0xae09e4: r17 = "(layer: "
    //     0xae09e4: ldr             x17, [PP, #0x7388]  ; [pp+0x7388] "(layer: "
    // 0xae09e8: StoreField: r2->field_1b = r17
    //     0xae09e8: stur            w17, [x2, #0x1b]
    // 0xae09ec: ldr             x3, [fp, #0x10]
    // 0xae09f0: LoadField: r0 = r3->field_7
    //     0xae09f0: ldur            w0, [x3, #7]
    // 0xae09f4: DecompressPointer r0
    //     0xae09f4: add             x0, x0, HEAP, lsl #32
    // 0xae09f8: mov             x1, x2
    // 0xae09fc: ArrayStore: r1[4] = r0  ; List_4
    //     0xae09fc: add             x25, x1, #0x1f
    //     0xae0a00: str             w0, [x25]
    //     0xae0a04: tbz             w0, #0, #0xae0a20
    //     0xae0a08: ldurb           w16, [x1, #-1]
    //     0xae0a0c: ldurb           w17, [x0, #-1]
    //     0xae0a10: and             x16, x17, x16, lsr #2
    //     0xae0a14: tst             x16, HEAP, lsr #32
    //     0xae0a18: b.eq            #0xae0a20
    //     0xae0a1c: bl              #0xd67e5c
    // 0xae0a20: r17 = ", canvas bounds: "
    //     0xae0a20: ldr             x17, [PP, #0x7390]  ; [pp+0x7390] ", canvas bounds: "
    // 0xae0a24: StoreField: r2->field_23 = r17
    //     0xae0a24: stur            w17, [x2, #0x23]
    // 0xae0a28: LoadField: r0 = r3->field_b
    //     0xae0a28: ldur            w0, [x3, #0xb]
    // 0xae0a2c: DecompressPointer r0
    //     0xae0a2c: add             x0, x0, HEAP, lsl #32
    // 0xae0a30: mov             x1, x2
    // 0xae0a34: ArrayStore: r1[6] = r0  ; List_4
    //     0xae0a34: add             x25, x1, #0x27
    //     0xae0a38: str             w0, [x25]
    //     0xae0a3c: tbz             w0, #0, #0xae0a58
    //     0xae0a40: ldurb           w16, [x1, #-1]
    //     0xae0a44: ldurb           w17, [x0, #-1]
    //     0xae0a48: and             x16, x17, x16, lsr #2
    //     0xae0a4c: tst             x16, HEAP, lsr #32
    //     0xae0a50: b.eq            #0xae0a58
    //     0xae0a54: bl              #0xd67e5c
    // 0xae0a58: r17 = ")"
    //     0xae0a58: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae0a5c: StoreField: r2->field_2b = r17
    //     0xae0a5c: stur            w17, [x2, #0x2b]
    // 0xae0a60: SaveReg r2
    //     0xae0a60: str             x2, [SP, #-8]!
    // 0xae0a64: r0 = _interpolate()
    //     0xae0a64: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae0a68: add             SP, SP, #8
    // 0xae0a6c: LeaveFrame
    //     0xae0a6c: mov             SP, fp
    //     0xae0a70: ldp             fp, lr, [SP], #0x10
    // 0xae0a74: ret
    //     0xae0a74: ret             
    // 0xae0a78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae0a78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae0a7c: b               #0xae09ac
  }
}

// class id: 2378, size: 0x18, field offset: 0x18
//   transformed mixin,
abstract class _RenderObject&AbstractNode&DiagnosticableTreeMixin extends AbstractNode
     with DiagnosticableTreeMixin {

  _ toString(/* No info */) {
    // ** addr: 0xad8e00, size: 0x6c
    // 0xad8e00: EnterFrame
    //     0xad8e00: stp             fp, lr, [SP, #-0x10]!
    //     0xad8e04: mov             fp, SP
    // 0xad8e08: mov             x0, x4
    // 0xad8e0c: LoadField: r1 = r0->field_13
    //     0xad8e0c: ldur            w1, [x0, #0x13]
    // 0xad8e10: DecompressPointer r1
    //     0xad8e10: add             x1, x1, HEAP, lsl #32
    // 0xad8e14: sub             x0, x1, #2
    // 0xad8e18: add             x1, fp, w0, sxtw #2
    // 0xad8e1c: ldr             x1, [x1, #0x10]
    // 0xad8e20: CheckStackOverflow
    //     0xad8e20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad8e24: cmp             SP, x16
    //     0xad8e28: b.ls            #0xad8e64
    // 0xad8e2c: r0 = LoadClassIdInstr(r1)
    //     0xad8e2c: ldur            x0, [x1, #-1]
    //     0xad8e30: ubfx            x0, x0, #0xc, #0x14
    // 0xad8e34: SaveReg r1
    //     0xad8e34: str             x1, [SP, #-8]!
    // 0xad8e38: r0 = GDT[cid_x0 + 0xbc47]()
    //     0xad8e38: mov             x17, #0xbc47
    //     0xad8e3c: add             lr, x0, x17
    //     0xad8e40: ldr             lr, [x21, lr, lsl #3]
    //     0xad8e44: blr             lr
    // 0xad8e48: add             SP, SP, #8
    // 0xad8e4c: SaveReg r0
    //     0xad8e4c: str             x0, [SP, #-8]!
    // 0xad8e50: r0 = toString()
    //     0xad8e50: bl              #0xaf6f6c  ; [dart:core] Object::toString
    // 0xad8e54: add             SP, SP, #8
    // 0xad8e58: LeaveFrame
    //     0xad8e58: mov             SP, fp
    //     0xad8e5c: ldp             fp, lr, [SP], #0x10
    // 0xad8e60: ret
    //     0xad8e60: ret             
    // 0xad8e64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad8e64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad8e68: b               #0xad8e2c
  }
}

// class id: 2398, size: 0x50, field offset: 0x18
abstract class RenderObject extends _RenderObject&AbstractNode&DiagnosticableTreeMixin
    implements HitTestTarget {

  late bool _needsCompositing; // offset: 0x38
  late bool _wasRepaintBoundary; // offset: 0x2c

  _ markNeedsSemanticsUpdate(/* No info */) {
    // ** addr: 0x50f8f4, size: 0x44c
    // 0x50f8f4: EnterFrame
    //     0x50f8f4: stp             fp, lr, [SP, #-0x10]!
    //     0x50f8f8: mov             fp, SP
    // 0x50f8fc: AllocStack(0x18)
    //     0x50f8fc: sub             SP, SP, #0x18
    // 0x50f900: CheckStackOverflow
    //     0x50f900: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50f904: cmp             SP, x16
    //     0x50f908: b.ls            #0x50fd20
    // 0x50f90c: ldr             x3, [fp, #0x10]
    // 0x50f910: LoadField: r4 = r3->field_f
    //     0x50f910: ldur            w4, [x3, #0xf]
    // 0x50f914: DecompressPointer r4
    //     0x50f914: add             x4, x4, HEAP, lsl #32
    // 0x50f918: stur            x4, [fp, #-8]
    // 0x50f91c: cmp             w4, NULL
    // 0x50f920: b.ne            #0x50f92c
    // 0x50f924: mov             x0, x3
    // 0x50f928: b               #0x50f974
    // 0x50f92c: mov             x0, x4
    // 0x50f930: r2 = Null
    //     0x50f930: mov             x2, NULL
    // 0x50f934: r1 = Null
    //     0x50f934: mov             x1, NULL
    // 0x50f938: r4 = 59
    //     0x50f938: mov             x4, #0x3b
    // 0x50f93c: branchIfSmi(r0, 0x50f948)
    //     0x50f93c: tbz             w0, #0, #0x50f948
    // 0x50f940: r4 = LoadClassIdInstr(r0)
    //     0x50f940: ldur            x4, [x0, #-1]
    //     0x50f944: ubfx            x4, x4, #0xc, #0x14
    // 0x50f948: cmp             x4, #0x7e6
    // 0x50f94c: b.eq            #0x50f95c
    // 0x50f950: r8 = PipelineOwner?
    //     0x50f950: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x50f954: r3 = Null
    //     0x50f954: ldr             x3, [PP, #0x4b58]  ; [pp+0x4b58] Null
    // 0x50f958: r0 = DefaultNullableTypeTest()
    //     0x50f958: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x50f95c: ldur            x0, [fp, #-8]
    // 0x50f960: LoadField: r1 = r0->field_2b
    //     0x50f960: ldur            w1, [x0, #0x2b]
    // 0x50f964: DecompressPointer r1
    //     0x50f964: add             x1, x1, HEAP, lsl #32
    // 0x50f968: cmp             w1, NULL
    // 0x50f96c: b.ne            #0x50f988
    // 0x50f970: ldr             x0, [fp, #0x10]
    // 0x50f974: StoreField: r0->field_43 = rNULL
    //     0x50f974: stur            NULL, [x0, #0x43]
    // 0x50f978: r0 = Null
    //     0x50f978: mov             x0, NULL
    // 0x50f97c: LeaveFrame
    //     0x50f97c: mov             SP, fp
    //     0x50f980: ldp             fp, lr, [SP], #0x10
    // 0x50f984: ret
    //     0x50f984: ret             
    // 0x50f988: ldr             x0, [fp, #0x10]
    // 0x50f98c: LoadField: r1 = r0->field_4b
    //     0x50f98c: ldur            w1, [x0, #0x4b]
    // 0x50f990: DecompressPointer r1
    //     0x50f990: add             x1, x1, HEAP, lsl #32
    // 0x50f994: cmp             w1, NULL
    // 0x50f998: b.eq            #0x50f9d0
    // 0x50f99c: LoadField: r1 = r0->field_43
    //     0x50f99c: ldur            w1, [x0, #0x43]
    // 0x50f9a0: DecompressPointer r1
    //     0x50f9a0: add             x1, x1, HEAP, lsl #32
    // 0x50f9a4: cmp             w1, NULL
    // 0x50f9a8: b.ne            #0x50f9b4
    // 0x50f9ac: r1 = Null
    //     0x50f9ac: mov             x1, NULL
    // 0x50f9b0: b               #0x50f9c0
    // 0x50f9b4: LoadField: r2 = r1->field_7
    //     0x50f9b4: ldur            w2, [x1, #7]
    // 0x50f9b8: DecompressPointer r2
    //     0x50f9b8: add             x2, x2, HEAP, lsl #32
    // 0x50f9bc: mov             x1, x2
    // 0x50f9c0: cmp             w1, NULL
    // 0x50f9c4: b.ne            #0x50f9d4
    // 0x50f9c8: r1 = false
    //     0x50f9c8: add             x1, NULL, #0x30  ; false
    // 0x50f9cc: b               #0x50f9d4
    // 0x50f9d0: r1 = false
    //     0x50f9d0: add             x1, NULL, #0x30  ; false
    // 0x50f9d4: stur            x1, [fp, #-8]
    // 0x50f9d8: StoreField: r0->field_43 = rNULL
    //     0x50f9d8: stur            NULL, [x0, #0x43]
    // 0x50f9dc: SaveReg r0
    //     0x50f9dc: str             x0, [SP, #-8]!
    // 0x50f9e0: r0 = _semanticsConfiguration()
    //     0x50f9e0: bl              #0x5102cc  ; [package:flutter/src/rendering/object.dart] RenderObject::_semanticsConfiguration
    // 0x50f9e4: add             SP, SP, #8
    // 0x50f9e8: LoadField: r1 = r0->field_7
    //     0x50f9e8: ldur            w1, [x0, #7]
    // 0x50f9ec: DecompressPointer r1
    //     0x50f9ec: add             x1, x1, HEAP, lsl #32
    // 0x50f9f0: tbnz            w1, #4, #0x50f9fc
    // 0x50f9f4: ldur            x0, [fp, #-8]
    // 0x50f9f8: b               #0x50fa00
    // 0x50f9fc: r0 = false
    //     0x50f9fc: add             x0, NULL, #0x30  ; false
    // 0x50fa00: ldr             x2, [fp, #0x10]
    // 0x50fa04: ldr             x1, [fp, #0x10]
    // 0x50fa08: stur            x2, [fp, #-8]
    // 0x50fa0c: CheckStackOverflow
    //     0x50fa0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50fa10: cmp             SP, x16
    //     0x50fa14: b.ls            #0x50fd28
    // 0x50fa18: tbz             w0, #4, #0x50fbac
    // 0x50fa1c: r0 = LoadClassIdInstr(r2)
    //     0x50fa1c: ldur            x0, [x2, #-1]
    //     0x50fa20: ubfx            x0, x0, #0xc, #0x14
    // 0x50fa24: SaveReg r2
    //     0x50fa24: str             x2, [SP, #-8]!
    // 0x50fa28: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0x50fa28: mov             x17, #0xa2f1
    //     0x50fa2c: add             lr, x0, x17
    //     0x50fa30: ldr             lr, [x21, lr, lsl #3]
    //     0x50fa34: blr             lr
    // 0x50fa38: add             SP, SP, #8
    // 0x50fa3c: r1 = LoadClassIdInstr(r0)
    //     0x50fa3c: ldur            x1, [x0, #-1]
    //     0x50fa40: ubfx            x1, x1, #0xc, #0x14
    // 0x50fa44: lsl             x1, x1, #1
    // 0x50fa48: r0 = LoadInt32Instr(r1)
    //     0x50fa48: sbfx            x0, x1, #1, #0x1f
    // 0x50fa4c: cmp             x0, #0x961
    // 0x50fa50: b.lt            #0x50fba4
    // 0x50fa54: cmp             x0, #0xa1f
    // 0x50fa58: b.gt            #0x50fb9c
    // 0x50fa5c: ldr             x1, [fp, #0x10]
    // 0x50fa60: ldur            x3, [fp, #-8]
    // 0x50fa64: cmp             w3, w1
    // 0x50fa68: b.eq            #0x50fa80
    // 0x50fa6c: LoadField: r0 = r3->field_47
    //     0x50fa6c: ldur            w0, [x3, #0x47]
    // 0x50fa70: DecompressPointer r0
    //     0x50fa70: add             x0, x0, HEAP, lsl #32
    // 0x50fa74: tbnz            w0, #4, #0x50fa80
    // 0x50fa78: mov             x4, x1
    // 0x50fa7c: b               #0x50fbb4
    // 0x50fa80: r2 = true
    //     0x50fa80: add             x2, NULL, #0x20  ; true
    // 0x50fa84: StoreField: r3->field_47 = r2
    //     0x50fa84: stur            w2, [x3, #0x47]
    // 0x50fa88: r0 = LoadClassIdInstr(r3)
    //     0x50fa88: ldur            x0, [x3, #-1]
    //     0x50fa8c: ubfx            x0, x0, #0xc, #0x14
    // 0x50fa90: SaveReg r3
    //     0x50fa90: str             x3, [SP, #-8]!
    // 0x50fa94: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0x50fa94: mov             x17, #0xa2f1
    //     0x50fa98: add             lr, x0, x17
    //     0x50fa9c: ldr             lr, [x21, lr, lsl #3]
    //     0x50faa0: blr             lr
    // 0x50faa4: add             SP, SP, #8
    // 0x50faa8: mov             x3, x0
    // 0x50faac: stur            x3, [fp, #-0x10]
    // 0x50fab0: cmp             w3, NULL
    // 0x50fab4: b.eq            #0x50fd30
    // 0x50fab8: mov             x0, x3
    // 0x50fabc: r2 = Null
    //     0x50fabc: mov             x2, NULL
    // 0x50fac0: r1 = Null
    //     0x50fac0: mov             x1, NULL
    // 0x50fac4: r4 = LoadClassIdInstr(r0)
    //     0x50fac4: ldur            x4, [x0, #-1]
    //     0x50fac8: ubfx            x4, x4, #0xc, #0x14
    // 0x50facc: sub             x4, x4, #0x961
    // 0x50fad0: cmp             x4, #0xbe
    // 0x50fad4: b.ls            #0x50fae4
    // 0x50fad8: r8 = RenderObject
    //     0x50fad8: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x50fadc: r3 = Null
    //     0x50fadc: ldr             x3, [PP, #0x4b70]  ; [pp+0x4b70] Null
    // 0x50fae0: r0 = RenderObject()
    //     0x50fae0: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x50fae4: ldur            x2, [fp, #-0x10]
    // 0x50fae8: LoadField: r0 = r2->field_43
    //     0x50fae8: ldur            w0, [x2, #0x43]
    // 0x50faec: DecompressPointer r0
    //     0x50faec: add             x0, x0, HEAP, lsl #32
    // 0x50faf0: cmp             w0, NULL
    // 0x50faf4: b.ne            #0x50fb54
    // 0x50faf8: r0 = SemanticsConfiguration()
    //     0x50faf8: bl              #0x5102c0  ; AllocateSemanticsConfigurationStub -> SemanticsConfiguration (size=0x94)
    // 0x50fafc: stur            x0, [fp, #-0x18]
    // 0x50fb00: SaveReg r0
    //     0x50fb00: str             x0, [SP, #-8]!
    // 0x50fb04: r0 = SemanticsConfiguration()
    //     0x50fb04: bl              #0x50fde0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::SemanticsConfiguration
    // 0x50fb08: add             SP, SP, #8
    // 0x50fb0c: ldur            x0, [fp, #-0x18]
    // 0x50fb10: ldur            x2, [fp, #-0x10]
    // 0x50fb14: StoreField: r2->field_43 = r0
    //     0x50fb14: stur            w0, [x2, #0x43]
    //     0x50fb18: ldurb           w16, [x2, #-1]
    //     0x50fb1c: ldurb           w17, [x0, #-1]
    //     0x50fb20: and             x16, x17, x16, lsr #2
    //     0x50fb24: tst             x16, HEAP, lsr #32
    //     0x50fb28: b.eq            #0x50fb30
    //     0x50fb2c: bl              #0xd6828c
    // 0x50fb30: r0 = LoadClassIdInstr(r2)
    //     0x50fb30: ldur            x0, [x2, #-1]
    //     0x50fb34: ubfx            x0, x0, #0xc, #0x14
    // 0x50fb38: ldur            x16, [fp, #-0x18]
    // 0x50fb3c: stp             x16, x2, [SP, #-0x10]!
    // 0x50fb40: r0 = GDT[cid_x0 + 0xe832]()
    //     0x50fb40: mov             x17, #0xe832
    //     0x50fb44: add             lr, x0, x17
    //     0x50fb48: ldr             lr, [x21, lr, lsl #3]
    //     0x50fb4c: blr             lr
    // 0x50fb50: add             SP, SP, #0x10
    // 0x50fb54: ldur            x2, [fp, #-0x10]
    // 0x50fb58: LoadField: r0 = r2->field_43
    //     0x50fb58: ldur            w0, [x2, #0x43]
    // 0x50fb5c: DecompressPointer r0
    //     0x50fb5c: add             x0, x0, HEAP, lsl #32
    // 0x50fb60: cmp             w0, NULL
    // 0x50fb64: b.eq            #0x50fd34
    // 0x50fb68: LoadField: r1 = r0->field_7
    //     0x50fb68: ldur            w1, [x0, #7]
    // 0x50fb6c: DecompressPointer r1
    //     0x50fb6c: add             x1, x1, HEAP, lsl #32
    // 0x50fb70: tbnz            w1, #4, #0x50fb94
    // 0x50fb74: LoadField: r0 = r2->field_4b
    //     0x50fb74: ldur            w0, [x2, #0x4b]
    // 0x50fb78: DecompressPointer r0
    //     0x50fb78: add             x0, x0, HEAP, lsl #32
    // 0x50fb7c: cmp             w0, NULL
    // 0x50fb80: b.ne            #0x50fb94
    // 0x50fb84: r0 = Null
    //     0x50fb84: mov             x0, NULL
    // 0x50fb88: LeaveFrame
    //     0x50fb88: mov             SP, fp
    //     0x50fb8c: ldp             fp, lr, [SP], #0x10
    // 0x50fb90: ret
    //     0x50fb90: ret             
    // 0x50fb94: mov             x0, x1
    // 0x50fb98: b               #0x50fa04
    // 0x50fb9c: ldur            x3, [fp, #-8]
    // 0x50fba0: b               #0x50fbb0
    // 0x50fba4: ldur            x3, [fp, #-8]
    // 0x50fba8: b               #0x50fbb0
    // 0x50fbac: mov             x3, x2
    // 0x50fbb0: ldr             x4, [fp, #0x10]
    // 0x50fbb4: cmp             w3, w4
    // 0x50fbb8: b.eq            #0x50fc38
    // 0x50fbbc: LoadField: r0 = r4->field_4b
    //     0x50fbbc: ldur            w0, [x4, #0x4b]
    // 0x50fbc0: DecompressPointer r0
    //     0x50fbc0: add             x0, x0, HEAP, lsl #32
    // 0x50fbc4: cmp             w0, NULL
    // 0x50fbc8: b.eq            #0x50fc38
    // 0x50fbcc: LoadField: r0 = r4->field_47
    //     0x50fbcc: ldur            w0, [x4, #0x47]
    // 0x50fbd0: DecompressPointer r0
    //     0x50fbd0: add             x0, x0, HEAP, lsl #32
    // 0x50fbd4: tbnz            w0, #4, #0x50fc38
    // 0x50fbd8: LoadField: r5 = r4->field_f
    //     0x50fbd8: ldur            w5, [x4, #0xf]
    // 0x50fbdc: DecompressPointer r5
    //     0x50fbdc: add             x5, x5, HEAP, lsl #32
    // 0x50fbe0: mov             x0, x5
    // 0x50fbe4: stur            x5, [fp, #-0x10]
    // 0x50fbe8: r2 = Null
    //     0x50fbe8: mov             x2, NULL
    // 0x50fbec: r1 = Null
    //     0x50fbec: mov             x1, NULL
    // 0x50fbf0: r4 = 59
    //     0x50fbf0: mov             x4, #0x3b
    // 0x50fbf4: branchIfSmi(r0, 0x50fc00)
    //     0x50fbf4: tbz             w0, #0, #0x50fc00
    // 0x50fbf8: r4 = LoadClassIdInstr(r0)
    //     0x50fbf8: ldur            x4, [x0, #-1]
    //     0x50fbfc: ubfx            x4, x4, #0xc, #0x14
    // 0x50fc00: cmp             x4, #0x7e6
    // 0x50fc04: b.eq            #0x50fc14
    // 0x50fc08: r8 = PipelineOwner?
    //     0x50fc08: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x50fc0c: r3 = Null
    //     0x50fc0c: ldr             x3, [PP, #0x4b80]  ; [pp+0x4b80] Null
    // 0x50fc10: r0 = DefaultNullableTypeTest()
    //     0x50fc10: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x50fc14: ldur            x0, [fp, #-0x10]
    // 0x50fc18: cmp             w0, NULL
    // 0x50fc1c: b.eq            #0x50fd38
    // 0x50fc20: LoadField: r1 = r0->field_37
    //     0x50fc20: ldur            w1, [x0, #0x37]
    // 0x50fc24: DecompressPointer r1
    //     0x50fc24: add             x1, x1, HEAP, lsl #32
    // 0x50fc28: ldr             x16, [fp, #0x10]
    // 0x50fc2c: stp             x16, x1, [SP, #-0x10]!
    // 0x50fc30: r0 = remove()
    //     0x50fc30: bl              #0xcbad38  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0x50fc34: add             SP, SP, #0x10
    // 0x50fc38: ldur            x3, [fp, #-8]
    // 0x50fc3c: LoadField: r0 = r3->field_47
    //     0x50fc3c: ldur            w0, [x3, #0x47]
    // 0x50fc40: DecompressPointer r0
    //     0x50fc40: add             x0, x0, HEAP, lsl #32
    // 0x50fc44: tbz             w0, #4, #0x50fd10
    // 0x50fc48: ldr             x4, [fp, #0x10]
    // 0x50fc4c: r0 = true
    //     0x50fc4c: add             x0, NULL, #0x20  ; true
    // 0x50fc50: StoreField: r3->field_47 = r0
    //     0x50fc50: stur            w0, [x3, #0x47]
    // 0x50fc54: LoadField: r5 = r4->field_f
    //     0x50fc54: ldur            w5, [x4, #0xf]
    // 0x50fc58: DecompressPointer r5
    //     0x50fc58: add             x5, x5, HEAP, lsl #32
    // 0x50fc5c: mov             x0, x5
    // 0x50fc60: stur            x5, [fp, #-0x10]
    // 0x50fc64: r2 = Null
    //     0x50fc64: mov             x2, NULL
    // 0x50fc68: r1 = Null
    //     0x50fc68: mov             x1, NULL
    // 0x50fc6c: r4 = 59
    //     0x50fc6c: mov             x4, #0x3b
    // 0x50fc70: branchIfSmi(r0, 0x50fc7c)
    //     0x50fc70: tbz             w0, #0, #0x50fc7c
    // 0x50fc74: r4 = LoadClassIdInstr(r0)
    //     0x50fc74: ldur            x4, [x0, #-1]
    //     0x50fc78: ubfx            x4, x4, #0xc, #0x14
    // 0x50fc7c: cmp             x4, #0x7e6
    // 0x50fc80: b.eq            #0x50fc90
    // 0x50fc84: r8 = PipelineOwner?
    //     0x50fc84: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x50fc88: r3 = Null
    //     0x50fc88: ldr             x3, [PP, #0x4b90]  ; [pp+0x4b90] Null
    // 0x50fc8c: r0 = DefaultNullableTypeTest()
    //     0x50fc8c: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x50fc90: ldur            x0, [fp, #-0x10]
    // 0x50fc94: cmp             w0, NULL
    // 0x50fc98: b.eq            #0x50fd10
    // 0x50fc9c: ldr             x1, [fp, #0x10]
    // 0x50fca0: LoadField: r2 = r0->field_37
    //     0x50fca0: ldur            w2, [x0, #0x37]
    // 0x50fca4: DecompressPointer r2
    //     0x50fca4: add             x2, x2, HEAP, lsl #32
    // 0x50fca8: ldur            x16, [fp, #-8]
    // 0x50fcac: stp             x16, x2, [SP, #-0x10]!
    // 0x50fcb0: r0 = add()
    //     0x50fcb0: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x50fcb4: add             SP, SP, #0x10
    // 0x50fcb8: ldr             x0, [fp, #0x10]
    // 0x50fcbc: LoadField: r3 = r0->field_f
    //     0x50fcbc: ldur            w3, [x0, #0xf]
    // 0x50fcc0: DecompressPointer r3
    //     0x50fcc0: add             x3, x3, HEAP, lsl #32
    // 0x50fcc4: mov             x0, x3
    // 0x50fcc8: stur            x3, [fp, #-8]
    // 0x50fccc: r2 = Null
    //     0x50fccc: mov             x2, NULL
    // 0x50fcd0: r1 = Null
    //     0x50fcd0: mov             x1, NULL
    // 0x50fcd4: r4 = 59
    //     0x50fcd4: mov             x4, #0x3b
    // 0x50fcd8: branchIfSmi(r0, 0x50fce4)
    //     0x50fcd8: tbz             w0, #0, #0x50fce4
    // 0x50fcdc: r4 = LoadClassIdInstr(r0)
    //     0x50fcdc: ldur            x4, [x0, #-1]
    //     0x50fce0: ubfx            x4, x4, #0xc, #0x14
    // 0x50fce4: cmp             x4, #0x7e6
    // 0x50fce8: b.eq            #0x50fcf8
    // 0x50fcec: r8 = PipelineOwner?
    //     0x50fcec: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x50fcf0: r3 = Null
    //     0x50fcf0: ldr             x3, [PP, #0x4ba0]  ; [pp+0x4ba0] Null
    // 0x50fcf4: r0 = DefaultNullableTypeTest()
    //     0x50fcf4: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x50fcf8: ldur            x0, [fp, #-8]
    // 0x50fcfc: cmp             w0, NULL
    // 0x50fd00: b.eq            #0x50fd3c
    // 0x50fd04: SaveReg r0
    //     0x50fd04: str             x0, [SP, #-8]!
    // 0x50fd08: r0 = requestVisualUpdate()
    //     0x50fd08: bl              #0x50fd88  ; [package:flutter/src/rendering/object.dart] PipelineOwner::requestVisualUpdate
    // 0x50fd0c: add             SP, SP, #8
    // 0x50fd10: r0 = Null
    //     0x50fd10: mov             x0, NULL
    // 0x50fd14: LeaveFrame
    //     0x50fd14: mov             SP, fp
    //     0x50fd18: ldp             fp, lr, [SP], #0x10
    // 0x50fd1c: ret
    //     0x50fd1c: ret             
    // 0x50fd20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50fd20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50fd24: b               #0x50f90c
    // 0x50fd28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50fd28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50fd2c: b               #0x50fa18
    // 0x50fd30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x50fd30: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x50fd34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x50fd34: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x50fd38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x50fd38: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x50fd3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x50fd3c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void markNeedsSemanticsUpdate(dynamic) {
    // ** addr: 0x50fd40, size: 0x48
    // 0x50fd40: EnterFrame
    //     0x50fd40: stp             fp, lr, [SP, #-0x10]!
    //     0x50fd44: mov             fp, SP
    // 0x50fd48: ldr             x0, [fp, #0x10]
    // 0x50fd4c: LoadField: r1 = r0->field_17
    //     0x50fd4c: ldur            w1, [x0, #0x17]
    // 0x50fd50: DecompressPointer r1
    //     0x50fd50: add             x1, x1, HEAP, lsl #32
    // 0x50fd54: CheckStackOverflow
    //     0x50fd54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50fd58: cmp             SP, x16
    //     0x50fd5c: b.ls            #0x50fd80
    // 0x50fd60: LoadField: r0 = r1->field_f
    //     0x50fd60: ldur            w0, [x1, #0xf]
    // 0x50fd64: DecompressPointer r0
    //     0x50fd64: add             x0, x0, HEAP, lsl #32
    // 0x50fd68: SaveReg r0
    //     0x50fd68: str             x0, [SP, #-8]!
    // 0x50fd6c: r0 = markNeedsSemanticsUpdate()
    //     0x50fd6c: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x50fd70: add             SP, SP, #8
    // 0x50fd74: LeaveFrame
    //     0x50fd74: mov             SP, fp
    //     0x50fd78: ldp             fp, lr, [SP], #0x10
    // 0x50fd7c: ret
    //     0x50fd7c: ret             
    // 0x50fd80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50fd80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50fd84: b               #0x50fd60
  }
  get _ _semanticsConfiguration(/* No info */) {
    // ** addr: 0x5102cc, size: 0xb4
    // 0x5102cc: EnterFrame
    //     0x5102cc: stp             fp, lr, [SP, #-0x10]!
    //     0x5102d0: mov             fp, SP
    // 0x5102d4: AllocStack(0x8)
    //     0x5102d4: sub             SP, SP, #8
    // 0x5102d8: CheckStackOverflow
    //     0x5102d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5102dc: cmp             SP, x16
    //     0x5102e0: b.ls            #0x510374
    // 0x5102e4: ldr             x0, [fp, #0x10]
    // 0x5102e8: LoadField: r1 = r0->field_43
    //     0x5102e8: ldur            w1, [x0, #0x43]
    // 0x5102ec: DecompressPointer r1
    //     0x5102ec: add             x1, x1, HEAP, lsl #32
    // 0x5102f0: cmp             w1, NULL
    // 0x5102f4: b.ne            #0x510354
    // 0x5102f8: r0 = SemanticsConfiguration()
    //     0x5102f8: bl              #0x5102c0  ; AllocateSemanticsConfigurationStub -> SemanticsConfiguration (size=0x94)
    // 0x5102fc: stur            x0, [fp, #-8]
    // 0x510300: SaveReg r0
    //     0x510300: str             x0, [SP, #-8]!
    // 0x510304: r0 = SemanticsConfiguration()
    //     0x510304: bl              #0x50fde0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::SemanticsConfiguration
    // 0x510308: add             SP, SP, #8
    // 0x51030c: ldur            x0, [fp, #-8]
    // 0x510310: ldr             x1, [fp, #0x10]
    // 0x510314: StoreField: r1->field_43 = r0
    //     0x510314: stur            w0, [x1, #0x43]
    //     0x510318: ldurb           w16, [x1, #-1]
    //     0x51031c: ldurb           w17, [x0, #-1]
    //     0x510320: and             x16, x17, x16, lsr #2
    //     0x510324: tst             x16, HEAP, lsr #32
    //     0x510328: b.eq            #0x510330
    //     0x51032c: bl              #0xd6826c
    // 0x510330: r0 = LoadClassIdInstr(r1)
    //     0x510330: ldur            x0, [x1, #-1]
    //     0x510334: ubfx            x0, x0, #0xc, #0x14
    // 0x510338: ldur            x16, [fp, #-8]
    // 0x51033c: stp             x16, x1, [SP, #-0x10]!
    // 0x510340: r0 = GDT[cid_x0 + 0xe832]()
    //     0x510340: mov             x17, #0xe832
    //     0x510344: add             lr, x0, x17
    //     0x510348: ldr             lr, [x21, lr, lsl #3]
    //     0x51034c: blr             lr
    // 0x510350: add             SP, SP, #0x10
    // 0x510354: ldr             x1, [fp, #0x10]
    // 0x510358: LoadField: r0 = r1->field_43
    //     0x510358: ldur            w0, [x1, #0x43]
    // 0x51035c: DecompressPointer r0
    //     0x51035c: add             x0, x0, HEAP, lsl #32
    // 0x510360: cmp             w0, NULL
    // 0x510364: b.eq            #0x51037c
    // 0x510368: LeaveFrame
    //     0x510368: mov             SP, fp
    //     0x51036c: ldp             fp, lr, [SP], #0x10
    // 0x510370: ret
    //     0x510370: ret             
    // 0x510374: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x510374: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x510378: b               #0x5102e4
    // 0x51037c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x51037c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ markParentNeedsLayout(/* No info */) {
    // ** addr: 0x5ae148, size: 0xd4
    // 0x5ae148: EnterFrame
    //     0x5ae148: stp             fp, lr, [SP, #-0x10]!
    //     0x5ae14c: mov             fp, SP
    // 0x5ae150: AllocStack(0x8)
    //     0x5ae150: sub             SP, SP, #8
    // 0x5ae154: r0 = true
    //     0x5ae154: add             x0, NULL, #0x20  ; true
    // 0x5ae158: CheckStackOverflow
    //     0x5ae158: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5ae15c: cmp             SP, x16
    //     0x5ae160: b.ls            #0x5ae210
    // 0x5ae164: ldr             x1, [fp, #0x10]
    // 0x5ae168: StoreField: r1->field_1b = r0
    //     0x5ae168: stur            w0, [x1, #0x1b]
    // 0x5ae16c: r0 = LoadClassIdInstr(r1)
    //     0x5ae16c: ldur            x0, [x1, #-1]
    //     0x5ae170: ubfx            x0, x0, #0xc, #0x14
    // 0x5ae174: SaveReg r1
    //     0x5ae174: str             x1, [SP, #-8]!
    // 0x5ae178: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0x5ae178: mov             x17, #0xa2f1
    //     0x5ae17c: add             lr, x0, x17
    //     0x5ae180: ldr             lr, [x21, lr, lsl #3]
    //     0x5ae184: blr             lr
    // 0x5ae188: add             SP, SP, #8
    // 0x5ae18c: mov             x3, x0
    // 0x5ae190: stur            x3, [fp, #-8]
    // 0x5ae194: cmp             w3, NULL
    // 0x5ae198: b.eq            #0x5ae218
    // 0x5ae19c: mov             x0, x3
    // 0x5ae1a0: r2 = Null
    //     0x5ae1a0: mov             x2, NULL
    // 0x5ae1a4: r1 = Null
    //     0x5ae1a4: mov             x1, NULL
    // 0x5ae1a8: r4 = LoadClassIdInstr(r0)
    //     0x5ae1a8: ldur            x4, [x0, #-1]
    //     0x5ae1ac: ubfx            x4, x4, #0xc, #0x14
    // 0x5ae1b0: sub             x4, x4, #0x961
    // 0x5ae1b4: cmp             x4, #0xbe
    // 0x5ae1b8: b.ls            #0x5ae1c8
    // 0x5ae1bc: r8 = RenderObject
    //     0x5ae1bc: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x5ae1c0: r3 = Null
    //     0x5ae1c0: ldr             x3, [PP, #0x4c50]  ; [pp+0x4c50] Null
    // 0x5ae1c4: r0 = RenderObject()
    //     0x5ae1c4: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x5ae1c8: ldr             x0, [fp, #0x10]
    // 0x5ae1cc: LoadField: r1 = r0->field_23
    //     0x5ae1cc: ldur            w1, [x0, #0x23]
    // 0x5ae1d0: DecompressPointer r1
    //     0x5ae1d0: add             x1, x1, HEAP, lsl #32
    // 0x5ae1d4: tbz             w1, #4, #0x5ae200
    // 0x5ae1d8: ldur            x0, [fp, #-8]
    // 0x5ae1dc: r1 = LoadClassIdInstr(r0)
    //     0x5ae1dc: ldur            x1, [x0, #-1]
    //     0x5ae1e0: ubfx            x1, x1, #0xc, #0x14
    // 0x5ae1e4: SaveReg r0
    //     0x5ae1e4: str             x0, [SP, #-8]!
    // 0x5ae1e8: mov             x0, x1
    // 0x5ae1ec: r0 = GDT[cid_x0 + 0xcfc6]()
    //     0x5ae1ec: mov             x17, #0xcfc6
    //     0x5ae1f0: add             lr, x0, x17
    //     0x5ae1f4: ldr             lr, [x21, lr, lsl #3]
    //     0x5ae1f8: blr             lr
    // 0x5ae1fc: add             SP, SP, #8
    // 0x5ae200: r0 = Null
    //     0x5ae200: mov             x0, NULL
    // 0x5ae204: LeaveFrame
    //     0x5ae204: mov             SP, fp
    //     0x5ae208: ldp             fp, lr, [SP], #0x10
    // 0x5ae20c: ret
    //     0x5ae20c: ret             
    // 0x5ae210: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5ae210: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5ae214: b               #0x5ae164
    // 0x5ae218: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5ae218: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ scheduleInitialPaint(/* No info */) {
    // ** addr: 0x5bbb48, size: 0x134
    // 0x5bbb48: EnterFrame
    //     0x5bbb48: stp             fp, lr, [SP, #-0x10]!
    //     0x5bbb4c: mov             fp, SP
    // 0x5bbb50: AllocStack(0x10)
    //     0x5bbb50: sub             SP, SP, #0x10
    // 0x5bbb54: CheckStackOverflow
    //     0x5bbb54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5bbb58: cmp             SP, x16
    //     0x5bbb5c: b.ls            #0x5bbc6c
    // 0x5bbb60: ldr             x0, [fp, #0x18]
    // 0x5bbb64: LoadField: r1 = r0->field_2f
    //     0x5bbb64: ldur            w1, [x0, #0x2f]
    // 0x5bbb68: DecompressPointer r1
    //     0x5bbb68: add             x1, x1, HEAP, lsl #32
    // 0x5bbb6c: ldr             x16, [fp, #0x10]
    // 0x5bbb70: stp             x16, x1, [SP, #-0x10]!
    // 0x5bbb74: r0 = layer=()
    //     0x5bbb74: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x5bbb78: add             SP, SP, #0x10
    // 0x5bbb7c: ldr             x3, [fp, #0x18]
    // 0x5bbb80: LoadField: r4 = r3->field_f
    //     0x5bbb80: ldur            w4, [x3, #0xf]
    // 0x5bbb84: DecompressPointer r4
    //     0x5bbb84: add             x4, x4, HEAP, lsl #32
    // 0x5bbb88: mov             x0, x4
    // 0x5bbb8c: stur            x4, [fp, #-8]
    // 0x5bbb90: r2 = Null
    //     0x5bbb90: mov             x2, NULL
    // 0x5bbb94: r1 = Null
    //     0x5bbb94: mov             x1, NULL
    // 0x5bbb98: r4 = 59
    //     0x5bbb98: mov             x4, #0x3b
    // 0x5bbb9c: branchIfSmi(r0, 0x5bbba8)
    //     0x5bbb9c: tbz             w0, #0, #0x5bbba8
    // 0x5bbba0: r4 = LoadClassIdInstr(r0)
    //     0x5bbba0: ldur            x4, [x0, #-1]
    //     0x5bbba4: ubfx            x4, x4, #0xc, #0x14
    // 0x5bbba8: cmp             x4, #0x7e6
    // 0x5bbbac: b.eq            #0x5bbbbc
    // 0x5bbbb0: r8 = PipelineOwner?
    //     0x5bbbb0: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x5bbbb4: r3 = Null
    //     0x5bbbb4: ldr             x3, [PP, #0x4d88]  ; [pp+0x4d88] Null
    // 0x5bbbb8: r0 = DefaultNullableTypeTest()
    //     0x5bbbb8: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x5bbbbc: ldur            x0, [fp, #-8]
    // 0x5bbbc0: cmp             w0, NULL
    // 0x5bbbc4: b.eq            #0x5bbc74
    // 0x5bbbc8: LoadField: r1 = r0->field_27
    //     0x5bbbc8: ldur            w1, [x0, #0x27]
    // 0x5bbbcc: DecompressPointer r1
    //     0x5bbbcc: add             x1, x1, HEAP, lsl #32
    // 0x5bbbd0: stur            x1, [fp, #-0x10]
    // 0x5bbbd4: LoadField: r0 = r1->field_b
    //     0x5bbbd4: ldur            w0, [x1, #0xb]
    // 0x5bbbd8: DecompressPointer r0
    //     0x5bbbd8: add             x0, x0, HEAP, lsl #32
    // 0x5bbbdc: stur            x0, [fp, #-8]
    // 0x5bbbe0: LoadField: r2 = r1->field_f
    //     0x5bbbe0: ldur            w2, [x1, #0xf]
    // 0x5bbbe4: DecompressPointer r2
    //     0x5bbbe4: add             x2, x2, HEAP, lsl #32
    // 0x5bbbe8: LoadField: r3 = r2->field_b
    //     0x5bbbe8: ldur            w3, [x2, #0xb]
    // 0x5bbbec: DecompressPointer r3
    //     0x5bbbec: add             x3, x3, HEAP, lsl #32
    // 0x5bbbf0: cmp             w0, w3
    // 0x5bbbf4: b.ne            #0x5bbc04
    // 0x5bbbf8: SaveReg r1
    //     0x5bbbf8: str             x1, [SP, #-8]!
    // 0x5bbbfc: r0 = _growToNextCapacity()
    //     0x5bbbfc: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x5bbc00: add             SP, SP, #8
    // 0x5bbc04: ldur            x2, [fp, #-0x10]
    // 0x5bbc08: ldur            x3, [fp, #-8]
    // 0x5bbc0c: r4 = LoadInt32Instr(r3)
    //     0x5bbc0c: sbfx            x4, x3, #1, #0x1f
    // 0x5bbc10: add             x0, x4, #1
    // 0x5bbc14: lsl             x3, x0, #1
    // 0x5bbc18: StoreField: r2->field_b = r3
    //     0x5bbc18: stur            w3, [x2, #0xb]
    // 0x5bbc1c: mov             x1, x4
    // 0x5bbc20: cmp             x1, x0
    // 0x5bbc24: b.hs            #0x5bbc78
    // 0x5bbc28: LoadField: r1 = r2->field_f
    //     0x5bbc28: ldur            w1, [x2, #0xf]
    // 0x5bbc2c: DecompressPointer r1
    //     0x5bbc2c: add             x1, x1, HEAP, lsl #32
    // 0x5bbc30: ldr             x0, [fp, #0x18]
    // 0x5bbc34: ArrayStore: r1[r4] = r0  ; List_4
    //     0x5bbc34: add             x25, x1, x4, lsl #2
    //     0x5bbc38: add             x25, x25, #0xf
    //     0x5bbc3c: str             w0, [x25]
    //     0x5bbc40: tbz             w0, #0, #0x5bbc5c
    //     0x5bbc44: ldurb           w16, [x1, #-1]
    //     0x5bbc48: ldurb           w17, [x0, #-1]
    //     0x5bbc4c: and             x16, x17, x16, lsr #2
    //     0x5bbc50: tst             x16, HEAP, lsr #32
    //     0x5bbc54: b.eq            #0x5bbc5c
    //     0x5bbc58: bl              #0xd67e5c
    // 0x5bbc5c: r0 = Null
    //     0x5bbc5c: mov             x0, NULL
    // 0x5bbc60: LeaveFrame
    //     0x5bbc60: mov             SP, fp
    //     0x5bbc64: ldp             fp, lr, [SP], #0x10
    // 0x5bbc68: ret
    //     0x5bbc68: ret             
    // 0x5bbc6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5bbc6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5bbc70: b               #0x5bbb60
    // 0x5bbc74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5bbc74: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5bbc78: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5bbc78: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ scheduleInitialLayout(/* No info */) {
    // ** addr: 0x5bc040, size: 0x11c
    // 0x5bc040: EnterFrame
    //     0x5bc040: stp             fp, lr, [SP, #-0x10]!
    //     0x5bc044: mov             fp, SP
    // 0x5bc048: AllocStack(0x10)
    //     0x5bc048: sub             SP, SP, #0x10
    // 0x5bc04c: CheckStackOverflow
    //     0x5bc04c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5bc050: cmp             SP, x16
    //     0x5bc054: b.ls            #0x5bc14c
    // 0x5bc058: ldr             x3, [fp, #0x10]
    // 0x5bc05c: StoreField: r3->field_1f = r3
    //     0x5bc05c: stur            w3, [x3, #0x1f]
    // 0x5bc060: LoadField: r4 = r3->field_f
    //     0x5bc060: ldur            w4, [x3, #0xf]
    // 0x5bc064: DecompressPointer r4
    //     0x5bc064: add             x4, x4, HEAP, lsl #32
    // 0x5bc068: mov             x0, x4
    // 0x5bc06c: stur            x4, [fp, #-8]
    // 0x5bc070: r2 = Null
    //     0x5bc070: mov             x2, NULL
    // 0x5bc074: r1 = Null
    //     0x5bc074: mov             x1, NULL
    // 0x5bc078: r4 = 59
    //     0x5bc078: mov             x4, #0x3b
    // 0x5bc07c: branchIfSmi(r0, 0x5bc088)
    //     0x5bc07c: tbz             w0, #0, #0x5bc088
    // 0x5bc080: r4 = LoadClassIdInstr(r0)
    //     0x5bc080: ldur            x4, [x0, #-1]
    //     0x5bc084: ubfx            x4, x4, #0xc, #0x14
    // 0x5bc088: cmp             x4, #0x7e6
    // 0x5bc08c: b.eq            #0x5bc09c
    // 0x5bc090: r8 = PipelineOwner?
    //     0x5bc090: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x5bc094: r3 = Null
    //     0x5bc094: ldr             x3, [PP, #0x4d98]  ; [pp+0x4d98] Null
    // 0x5bc098: r0 = DefaultNullableTypeTest()
    //     0x5bc098: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x5bc09c: ldur            x0, [fp, #-8]
    // 0x5bc0a0: cmp             w0, NULL
    // 0x5bc0a4: b.eq            #0x5bc154
    // 0x5bc0a8: LoadField: r1 = r0->field_1f
    //     0x5bc0a8: ldur            w1, [x0, #0x1f]
    // 0x5bc0ac: DecompressPointer r1
    //     0x5bc0ac: add             x1, x1, HEAP, lsl #32
    // 0x5bc0b0: stur            x1, [fp, #-0x10]
    // 0x5bc0b4: LoadField: r0 = r1->field_b
    //     0x5bc0b4: ldur            w0, [x1, #0xb]
    // 0x5bc0b8: DecompressPointer r0
    //     0x5bc0b8: add             x0, x0, HEAP, lsl #32
    // 0x5bc0bc: stur            x0, [fp, #-8]
    // 0x5bc0c0: LoadField: r2 = r1->field_f
    //     0x5bc0c0: ldur            w2, [x1, #0xf]
    // 0x5bc0c4: DecompressPointer r2
    //     0x5bc0c4: add             x2, x2, HEAP, lsl #32
    // 0x5bc0c8: LoadField: r3 = r2->field_b
    //     0x5bc0c8: ldur            w3, [x2, #0xb]
    // 0x5bc0cc: DecompressPointer r3
    //     0x5bc0cc: add             x3, x3, HEAP, lsl #32
    // 0x5bc0d0: cmp             w0, w3
    // 0x5bc0d4: b.ne            #0x5bc0e4
    // 0x5bc0d8: SaveReg r1
    //     0x5bc0d8: str             x1, [SP, #-8]!
    // 0x5bc0dc: r0 = _growToNextCapacity()
    //     0x5bc0dc: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x5bc0e0: add             SP, SP, #8
    // 0x5bc0e4: ldur            x2, [fp, #-0x10]
    // 0x5bc0e8: ldur            x3, [fp, #-8]
    // 0x5bc0ec: r4 = LoadInt32Instr(r3)
    //     0x5bc0ec: sbfx            x4, x3, #1, #0x1f
    // 0x5bc0f0: add             x0, x4, #1
    // 0x5bc0f4: lsl             x3, x0, #1
    // 0x5bc0f8: StoreField: r2->field_b = r3
    //     0x5bc0f8: stur            w3, [x2, #0xb]
    // 0x5bc0fc: mov             x1, x4
    // 0x5bc100: cmp             x1, x0
    // 0x5bc104: b.hs            #0x5bc158
    // 0x5bc108: LoadField: r1 = r2->field_f
    //     0x5bc108: ldur            w1, [x2, #0xf]
    // 0x5bc10c: DecompressPointer r1
    //     0x5bc10c: add             x1, x1, HEAP, lsl #32
    // 0x5bc110: ldr             x0, [fp, #0x10]
    // 0x5bc114: ArrayStore: r1[r4] = r0  ; List_4
    //     0x5bc114: add             x25, x1, x4, lsl #2
    //     0x5bc118: add             x25, x25, #0xf
    //     0x5bc11c: str             w0, [x25]
    //     0x5bc120: tbz             w0, #0, #0x5bc13c
    //     0x5bc124: ldurb           w16, [x1, #-1]
    //     0x5bc128: ldurb           w17, [x0, #-1]
    //     0x5bc12c: and             x16, x17, x16, lsr #2
    //     0x5bc130: tst             x16, HEAP, lsr #32
    //     0x5bc134: b.eq            #0x5bc13c
    //     0x5bc138: bl              #0xd67e5c
    // 0x5bc13c: r0 = Null
    //     0x5bc13c: mov             x0, NULL
    // 0x5bc140: LeaveFrame
    //     0x5bc140: mov             SP, fp
    //     0x5bc144: ldp             fp, lr, [SP], #0x10
    // 0x5bc148: ret
    //     0x5bc148: ret             
    // 0x5bc14c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5bc14c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5bc150: b               #0x5bc058
    // 0x5bc154: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5bc154: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5bc158: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5bc158: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ RenderObject(/* No info */) {
    // ** addr: 0x5bc2f8, size: 0x10c
    // 0x5bc2f8: EnterFrame
    //     0x5bc2f8: stp             fp, lr, [SP, #-0x10]!
    //     0x5bc2fc: mov             fp, SP
    // 0x5bc300: r2 = true
    //     0x5bc300: add             x2, NULL, #0x20  ; true
    // 0x5bc304: r1 = false
    //     0x5bc304: add             x1, NULL, #0x30  ; false
    // 0x5bc308: r0 = Sentinel
    //     0x5bc308: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5bc30c: CheckStackOverflow
    //     0x5bc30c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5bc310: cmp             SP, x16
    //     0x5bc314: b.ls            #0x5bc3fc
    // 0x5bc318: ldr             x3, [fp, #0x10]
    // 0x5bc31c: StoreField: r3->field_1b = r2
    //     0x5bc31c: stur            w2, [x3, #0x1b]
    // 0x5bc320: StoreField: r3->field_23 = r1
    //     0x5bc320: stur            w1, [x3, #0x23]
    // 0x5bc324: StoreField: r3->field_2b = r0
    //     0x5bc324: stur            w0, [x3, #0x2b]
    // 0x5bc328: StoreField: r3->field_33 = r1
    //     0x5bc328: stur            w1, [x3, #0x33]
    // 0x5bc32c: StoreField: r3->field_37 = r0
    //     0x5bc32c: stur            w0, [x3, #0x37]
    // 0x5bc330: StoreField: r3->field_3b = r2
    //     0x5bc330: stur            w2, [x3, #0x3b]
    // 0x5bc334: StoreField: r3->field_3f = r1
    //     0x5bc334: stur            w1, [x3, #0x3f]
    // 0x5bc338: StoreField: r3->field_47 = r2
    //     0x5bc338: stur            w2, [x3, #0x47]
    // 0x5bc33c: r1 = <ContainerLayer>
    //     0x5bc33c: ldr             x1, [PP, #0x4e18]  ; [pp+0x4e18] TypeArguments: <ContainerLayer>
    // 0x5bc340: r0 = LayerHandle()
    //     0x5bc340: bl              #0x5bbf28  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x5bc344: ldr             x1, [fp, #0x10]
    // 0x5bc348: StoreField: r1->field_2f = r0
    //     0x5bc348: stur            w0, [x1, #0x2f]
    //     0x5bc34c: ldurb           w16, [x1, #-1]
    //     0x5bc350: ldurb           w17, [x0, #-1]
    //     0x5bc354: and             x16, x17, x16, lsr #2
    //     0x5bc358: tst             x16, HEAP, lsr #32
    //     0x5bc35c: b.eq            #0x5bc364
    //     0x5bc360: bl              #0xd6826c
    // 0x5bc364: r0 = 0
    //     0x5bc364: mov             x0, #0
    // 0x5bc368: StoreField: r1->field_7 = r0
    //     0x5bc368: stur            x0, [x1, #7]
    // 0x5bc36c: r0 = LoadClassIdInstr(r1)
    //     0x5bc36c: ldur            x0, [x1, #-1]
    //     0x5bc370: ubfx            x0, x0, #0xc, #0x14
    // 0x5bc374: SaveReg r1
    //     0x5bc374: str             x1, [SP, #-8]!
    // 0x5bc378: r0 = GDT[cid_x0 + 0xd14d]()
    //     0x5bc378: mov             x17, #0xd14d
    //     0x5bc37c: add             lr, x0, x17
    //     0x5bc380: ldr             lr, [x21, lr, lsl #3]
    //     0x5bc384: blr             lr
    // 0x5bc388: add             SP, SP, #8
    // 0x5bc38c: tbnz            w0, #4, #0x5bc398
    // 0x5bc390: r0 = true
    //     0x5bc390: add             x0, NULL, #0x20  ; true
    // 0x5bc394: b               #0x5bc3bc
    // 0x5bc398: ldr             x1, [fp, #0x10]
    // 0x5bc39c: r0 = LoadClassIdInstr(r1)
    //     0x5bc39c: ldur            x0, [x1, #-1]
    //     0x5bc3a0: ubfx            x0, x0, #0xc, #0x14
    // 0x5bc3a4: SaveReg r1
    //     0x5bc3a4: str             x1, [SP, #-8]!
    // 0x5bc3a8: r0 = GDT[cid_x0 + 0xe536]()
    //     0x5bc3a8: mov             x17, #0xe536
    //     0x5bc3ac: add             lr, x0, x17
    //     0x5bc3b0: ldr             lr, [x21, lr, lsl #3]
    //     0x5bc3b4: blr             lr
    // 0x5bc3b8: add             SP, SP, #8
    // 0x5bc3bc: ldr             x1, [fp, #0x10]
    // 0x5bc3c0: StoreField: r1->field_37 = r0
    //     0x5bc3c0: stur            w0, [x1, #0x37]
    // 0x5bc3c4: r0 = LoadClassIdInstr(r1)
    //     0x5bc3c4: ldur            x0, [x1, #-1]
    //     0x5bc3c8: ubfx            x0, x0, #0xc, #0x14
    // 0x5bc3cc: SaveReg r1
    //     0x5bc3cc: str             x1, [SP, #-8]!
    // 0x5bc3d0: r0 = GDT[cid_x0 + 0xd14d]()
    //     0x5bc3d0: mov             x17, #0xd14d
    //     0x5bc3d4: add             lr, x0, x17
    //     0x5bc3d8: ldr             lr, [x21, lr, lsl #3]
    //     0x5bc3dc: blr             lr
    // 0x5bc3e0: add             SP, SP, #8
    // 0x5bc3e4: ldr             x1, [fp, #0x10]
    // 0x5bc3e8: StoreField: r1->field_2b = r0
    //     0x5bc3e8: stur            w0, [x1, #0x2b]
    // 0x5bc3ec: r0 = Null
    //     0x5bc3ec: mov             x0, NULL
    // 0x5bc3f0: LeaveFrame
    //     0x5bc3f0: mov             SP, fp
    //     0x5bc3f4: ldp             fp, lr, [SP], #0x10
    // 0x5bc3f8: ret
    //     0x5bc3f8: ret             
    // 0x5bc3fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5bc3fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5bc400: b               #0x5bc318
  }
  _ _updateSemantics(/* No info */) {
    // ** addr: 0x5dc008, size: 0x1e8
    // 0x5dc008: EnterFrame
    //     0x5dc008: stp             fp, lr, [SP, #-0x10]!
    //     0x5dc00c: mov             fp, SP
    // 0x5dc010: AllocStack(0x10)
    //     0x5dc010: sub             SP, SP, #0x10
    // 0x5dc014: CheckStackOverflow
    //     0x5dc014: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5dc018: cmp             SP, x16
    //     0x5dc01c: b.ls            #0x5dc1e8
    // 0x5dc020: ldr             x3, [fp, #0x10]
    // 0x5dc024: LoadField: r0 = r3->field_1b
    //     0x5dc024: ldur            w0, [x3, #0x1b]
    // 0x5dc028: DecompressPointer r0
    //     0x5dc028: add             x0, x0, HEAP, lsl #32
    // 0x5dc02c: tbnz            w0, #4, #0x5dc040
    // 0x5dc030: r0 = Null
    //     0x5dc030: mov             x0, NULL
    // 0x5dc034: LeaveFrame
    //     0x5dc034: mov             SP, fp
    //     0x5dc038: ldp             fp, lr, [SP], #0x10
    // 0x5dc03c: ret
    //     0x5dc03c: ret             
    // 0x5dc040: LoadField: r0 = r3->field_4b
    //     0x5dc040: ldur            w0, [x3, #0x4b]
    // 0x5dc044: DecompressPointer r0
    //     0x5dc044: add             x0, x0, HEAP, lsl #32
    // 0x5dc048: cmp             w0, NULL
    // 0x5dc04c: b.ne            #0x5dc058
    // 0x5dc050: r0 = Null
    //     0x5dc050: mov             x0, NULL
    // 0x5dc054: b               #0x5dc0c0
    // 0x5dc058: LoadField: r4 = r0->field_13
    //     0x5dc058: ldur            w4, [x0, #0x13]
    // 0x5dc05c: DecompressPointer r4
    //     0x5dc05c: add             x4, x4, HEAP, lsl #32
    // 0x5dc060: mov             x0, x4
    // 0x5dc064: stur            x4, [fp, #-8]
    // 0x5dc068: r2 = Null
    //     0x5dc068: mov             x2, NULL
    // 0x5dc06c: r1 = Null
    //     0x5dc06c: mov             x1, NULL
    // 0x5dc070: r4 = LoadClassIdInstr(r0)
    //     0x5dc070: ldur            x4, [x0, #-1]
    //     0x5dc074: ubfx            x4, x4, #0xc, #0x14
    // 0x5dc078: cmp             x4, #0x94b
    // 0x5dc07c: b.eq            #0x5dc08c
    // 0x5dc080: r8 = SemanticsNode?
    //     0x5dc080: ldr             x8, [PP, #0x45f8]  ; [pp+0x45f8] Type: SemanticsNode?
    // 0x5dc084: r3 = Null
    //     0x5dc084: ldr             x3, [PP, #0x4930]  ; [pp+0x4930] Null
    // 0x5dc088: r0 = SemanticsNode?()
    //     0x5dc088: bl              #0x5dbf80  ; IsType_SemanticsNode?_Stub
    // 0x5dc08c: ldur            x0, [fp, #-8]
    // 0x5dc090: cmp             w0, NULL
    // 0x5dc094: b.ne            #0x5dc0a0
    // 0x5dc098: r0 = Null
    //     0x5dc098: mov             x0, NULL
    // 0x5dc09c: b               #0x5dc0c0
    // 0x5dc0a0: LoadField: r1 = r0->field_43
    //     0x5dc0a0: ldur            w1, [x0, #0x43]
    // 0x5dc0a4: DecompressPointer r1
    //     0x5dc0a4: add             x1, x1, HEAP, lsl #32
    // 0x5dc0a8: tbnz            w1, #4, #0x5dc0b4
    // 0x5dc0ac: r0 = true
    //     0x5dc0ac: add             x0, NULL, #0x20  ; true
    // 0x5dc0b0: b               #0x5dc0c0
    // 0x5dc0b4: LoadField: r1 = r0->field_3f
    //     0x5dc0b4: ldur            w1, [x0, #0x3f]
    // 0x5dc0b8: DecompressPointer r1
    //     0x5dc0b8: add             x1, x1, HEAP, lsl #32
    // 0x5dc0bc: mov             x0, x1
    // 0x5dc0c0: cmp             w0, NULL
    // 0x5dc0c4: b.ne            #0x5dc0d0
    // 0x5dc0c8: r1 = false
    //     0x5dc0c8: add             x1, NULL, #0x30  ; false
    // 0x5dc0cc: b               #0x5dc0d4
    // 0x5dc0d0: mov             x1, x0
    // 0x5dc0d4: ldr             x0, [fp, #0x10]
    // 0x5dc0d8: stp             x1, x0, [SP, #-0x10]!
    // 0x5dc0dc: r0 = _getSemanticsForParent()
    //     0x5dc0dc: bl              #0x5dc1f0  ; [package:flutter/src/rendering/object.dart] RenderObject::_getSemanticsForParent
    // 0x5dc0e0: add             SP, SP, #0x10
    // 0x5dc0e4: mov             x3, x0
    // 0x5dc0e8: r2 = Null
    //     0x5dc0e8: mov             x2, NULL
    // 0x5dc0ec: r1 = Null
    //     0x5dc0ec: mov             x1, NULL
    // 0x5dc0f0: stur            x3, [fp, #-8]
    // 0x5dc0f4: r4 = LoadClassIdInstr(r0)
    //     0x5dc0f4: ldur            x4, [x0, #-1]
    //     0x5dc0f8: ubfx            x4, x4, #0xc, #0x14
    // 0x5dc0fc: sub             x4, x4, #0x7e3
    // 0x5dc100: cmp             x4, #1
    // 0x5dc104: b.ls            #0x5dc114
    // 0x5dc108: r8 = _InterestingSemanticsFragment
    //     0x5dc108: ldr             x8, [PP, #0x4940]  ; [pp+0x4940] Type: _InterestingSemanticsFragment
    // 0x5dc10c: r3 = Null
    //     0x5dc10c: ldr             x3, [PP, #0x4948]  ; [pp+0x4948] Null
    // 0x5dc110: r0 = _InterestingSemanticsFragment()
    //     0x5dc110: bl              #0x5dd0bc  ; IsType__InterestingSemanticsFragment_Stub
    // 0x5dc114: r16 = <SemanticsNode>
    //     0x5dc114: ldr             x16, [PP, #0x45e0]  ; [pp+0x45e0] TypeArguments: <SemanticsNode>
    // 0x5dc118: stp             xzr, x16, [SP, #-0x10]!
    // 0x5dc11c: r0 = _GrowableList()
    //     0x5dc11c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x5dc120: add             SP, SP, #0x10
    // 0x5dc124: mov             x1, x0
    // 0x5dc128: ldr             x0, [fp, #0x10]
    // 0x5dc12c: stur            x1, [fp, #-0x10]
    // 0x5dc130: LoadField: r2 = r0->field_4b
    //     0x5dc130: ldur            w2, [x0, #0x4b]
    // 0x5dc134: DecompressPointer r2
    //     0x5dc134: add             x2, x2, HEAP, lsl #32
    // 0x5dc138: cmp             w2, NULL
    // 0x5dc13c: b.ne            #0x5dc148
    // 0x5dc140: r0 = Null
    //     0x5dc140: mov             x0, NULL
    // 0x5dc144: b               #0x5dc150
    // 0x5dc148: LoadField: r0 = r2->field_2f
    //     0x5dc148: ldur            w0, [x2, #0x2f]
    // 0x5dc14c: DecompressPointer r0
    //     0x5dc14c: add             x0, x0, HEAP, lsl #32
    // 0x5dc150: cmp             w2, NULL
    // 0x5dc154: b.ne            #0x5dc160
    // 0x5dc158: r3 = Null
    //     0x5dc158: mov             x3, NULL
    // 0x5dc15c: b               #0x5dc168
    // 0x5dc160: LoadField: r3 = r2->field_33
    //     0x5dc160: ldur            w3, [x2, #0x33]
    // 0x5dc164: DecompressPointer r3
    //     0x5dc164: add             x3, x3, HEAP, lsl #32
    // 0x5dc168: cmp             w2, NULL
    // 0x5dc16c: b.ne            #0x5dc178
    // 0x5dc170: r2 = Null
    //     0x5dc170: mov             x2, NULL
    // 0x5dc174: b               #0x5dc184
    // 0x5dc178: LoadField: r4 = r2->field_37
    //     0x5dc178: ldur            w4, [x2, #0x37]
    // 0x5dc17c: DecompressPointer r4
    //     0x5dc17c: add             x4, x4, HEAP, lsl #32
    // 0x5dc180: mov             x2, x4
    // 0x5dc184: cmp             w2, NULL
    // 0x5dc188: b.ne            #0x5dc194
    // 0x5dc18c: d0 = 0.000000
    //     0x5dc18c: eor             v0.16b, v0.16b, v0.16b
    // 0x5dc190: b               #0x5dc198
    // 0x5dc194: LoadField: d0 = r2->field_7
    //     0x5dc194: ldur            d0, [x2, #7]
    // 0x5dc198: ldur            x2, [fp, #-8]
    // 0x5dc19c: r4 = LoadClassIdInstr(r2)
    //     0x5dc19c: ldur            x4, [x2, #-1]
    //     0x5dc1a0: ubfx            x4, x4, #0xc, #0x14
    // 0x5dc1a4: SaveReg r2
    //     0x5dc1a4: str             x2, [SP, #-8]!
    // 0x5dc1a8: SaveReg d0
    //     0x5dc1a8: str             d0, [SP, #-8]!
    // 0x5dc1ac: stp             x0, x3, [SP, #-0x10]!
    // 0x5dc1b0: SaveReg r1
    //     0x5dc1b0: str             x1, [SP, #-8]!
    // 0x5dc1b4: mov             x0, x4
    // 0x5dc1b8: r0 = GDT[cid_x0 + -0xffe]()
    //     0x5dc1b8: sub             lr, x0, #0xffe
    //     0x5dc1bc: ldr             lr, [x21, lr, lsl #3]
    //     0x5dc1c0: blr             lr
    // 0x5dc1c4: add             SP, SP, #0x28
    // 0x5dc1c8: ldur            x16, [fp, #-0x10]
    // 0x5dc1cc: SaveReg r16
    //     0x5dc1cc: str             x16, [SP, #-8]!
    // 0x5dc1d0: r0 = single()
    //     0x5dc1d0: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x5dc1d4: add             SP, SP, #8
    // 0x5dc1d8: r0 = Null
    //     0x5dc1d8: mov             x0, NULL
    // 0x5dc1dc: LeaveFrame
    //     0x5dc1dc: mov             SP, fp
    //     0x5dc1e0: ldp             fp, lr, [SP], #0x10
    // 0x5dc1e4: ret
    //     0x5dc1e4: ret             
    // 0x5dc1e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5dc1e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5dc1ec: b               #0x5dc020
  }
  _ _getSemanticsForParent(/* No info */) {
    // ** addr: 0x5dc1f0, size: 0x448
    // 0x5dc1f0: EnterFrame
    //     0x5dc1f0: stp             fp, lr, [SP, #-0x10]!
    //     0x5dc1f4: mov             fp, SP
    // 0x5dc1f8: AllocStack(0x38)
    //     0x5dc1f8: sub             SP, SP, #0x38
    // 0x5dc1fc: CheckStackOverflow
    //     0x5dc1fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5dc200: cmp             SP, x16
    //     0x5dc204: b.ls            #0x5dc628
    // 0x5dc208: r1 = 7
    //     0x5dc208: mov             x1, #7
    // 0x5dc20c: r0 = AllocateContext()
    //     0x5dc20c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x5dc210: mov             x1, x0
    // 0x5dc214: ldr             x0, [fp, #0x18]
    // 0x5dc218: stur            x1, [fp, #-8]
    // 0x5dc21c: StoreField: r1->field_f = r0
    //     0x5dc21c: stur            w0, [x1, #0xf]
    // 0x5dc220: SaveReg r0
    //     0x5dc220: str             x0, [SP, #-8]!
    // 0x5dc224: r0 = _semanticsConfiguration()
    //     0x5dc224: bl              #0x5102cc  ; [package:flutter/src/rendering/object.dart] RenderObject::_semanticsConfiguration
    // 0x5dc228: add             SP, SP, #8
    // 0x5dc22c: mov             x1, x0
    // 0x5dc230: ldur            x2, [fp, #-8]
    // 0x5dc234: stur            x1, [fp, #-0x18]
    // 0x5dc238: StoreField: r2->field_13 = r0
    //     0x5dc238: stur            w0, [x2, #0x13]
    //     0x5dc23c: ldurb           w16, [x2, #-1]
    //     0x5dc240: ldurb           w17, [x0, #-1]
    //     0x5dc244: and             x16, x17, x16, lsr #2
    //     0x5dc248: tst             x16, HEAP, lsr #32
    //     0x5dc24c: b.eq            #0x5dc254
    //     0x5dc250: bl              #0xd6828c
    // 0x5dc254: LoadField: r0 = r1->field_f
    //     0x5dc254: ldur            w0, [x1, #0xf]
    // 0x5dc258: DecompressPointer r0
    //     0x5dc258: add             x0, x0, HEAP, lsl #32
    // 0x5dc25c: StoreField: r2->field_17 = r0
    //     0x5dc25c: stur            w0, [x2, #0x17]
    // 0x5dc260: LoadField: r0 = r1->field_13
    //     0x5dc260: ldur            w0, [x1, #0x13]
    // 0x5dc264: DecompressPointer r0
    //     0x5dc264: add             x0, x0, HEAP, lsl #32
    // 0x5dc268: tbz             w0, #4, #0x5dc27c
    // 0x5dc26c: LoadField: r0 = r1->field_7
    //     0x5dc26c: ldur            w0, [x1, #7]
    // 0x5dc270: DecompressPointer r0
    //     0x5dc270: add             x0, x0, HEAP, lsl #32
    // 0x5dc274: eor             x3, x0, #0x10
    // 0x5dc278: b               #0x5dc280
    // 0x5dc27c: r3 = false
    //     0x5dc27c: add             x3, NULL, #0x30  ; false
    // 0x5dc280: ldr             x0, [fp, #0x10]
    // 0x5dc284: stur            x3, [fp, #-0x10]
    // 0x5dc288: StoreField: r2->field_1b = r3
    //     0x5dc288: stur            w3, [x2, #0x1b]
    // 0x5dc28c: r16 = <_InterestingSemanticsFragment>
    //     0x5dc28c: ldr             x16, [PP, #0x4958]  ; [pp+0x4958] TypeArguments: <_InterestingSemanticsFragment>
    // 0x5dc290: stp             xzr, x16, [SP, #-0x10]!
    // 0x5dc294: r0 = _GrowableList()
    //     0x5dc294: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x5dc298: add             SP, SP, #0x10
    // 0x5dc29c: mov             x1, x0
    // 0x5dc2a0: ldur            x2, [fp, #-8]
    // 0x5dc2a4: stur            x1, [fp, #-0x20]
    // 0x5dc2a8: StoreField: r2->field_1f = r0
    //     0x5dc2a8: stur            w0, [x2, #0x1f]
    //     0x5dc2ac: ldurb           w16, [x2, #-1]
    //     0x5dc2b0: ldurb           w17, [x0, #-1]
    //     0x5dc2b4: and             x16, x17, x16, lsr #2
    //     0x5dc2b8: tst             x16, HEAP, lsr #32
    //     0x5dc2bc: b.eq            #0x5dc2c4
    //     0x5dc2c0: bl              #0xd6828c
    // 0x5dc2c4: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x5dc2c4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5dc2c8: ldr             x0, [x0, #0x598]
    //     0x5dc2cc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5dc2d0: cmp             w0, w16
    //     0x5dc2d4: b.ne            #0x5dc2e0
    //     0x5dc2d8: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x5dc2dc: bl              #0xd67cdc
    // 0x5dc2e0: r1 = <_InterestingSemanticsFragment>
    //     0x5dc2e0: ldr             x1, [PP, #0x4958]  ; [pp+0x4958] TypeArguments: <_InterestingSemanticsFragment>
    // 0x5dc2e4: stur            x0, [fp, #-0x28]
    // 0x5dc2e8: r0 = _Set()
    //     0x5dc2e8: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x5dc2ec: mov             x1, x0
    // 0x5dc2f0: ldur            x0, [fp, #-0x28]
    // 0x5dc2f4: stur            x1, [fp, #-0x30]
    // 0x5dc2f8: StoreField: r1->field_1b = r0
    //     0x5dc2f8: stur            w0, [x1, #0x1b]
    // 0x5dc2fc: StoreField: r1->field_b = rZR
    //     0x5dc2fc: stur            wzr, [x1, #0xb]
    // 0x5dc300: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x5dc300: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5dc304: ldr             x0, [x0, #0x5a0]
    //     0x5dc308: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5dc30c: cmp             w0, w16
    //     0x5dc310: b.ne            #0x5dc31c
    //     0x5dc314: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x5dc318: bl              #0xd67cdc
    // 0x5dc31c: ldur            x3, [fp, #-0x30]
    // 0x5dc320: StoreField: r3->field_f = r0
    //     0x5dc320: stur            w0, [x3, #0xf]
    // 0x5dc324: StoreField: r3->field_13 = rZR
    //     0x5dc324: stur            wzr, [x3, #0x13]
    // 0x5dc328: StoreField: r3->field_17 = rZR
    //     0x5dc328: stur            wzr, [x3, #0x17]
    // 0x5dc32c: mov             x0, x3
    // 0x5dc330: ldur            x4, [fp, #-8]
    // 0x5dc334: StoreField: r4->field_23 = r0
    //     0x5dc334: stur            w0, [x4, #0x23]
    //     0x5dc338: ldurb           w16, [x4, #-1]
    //     0x5dc33c: ldurb           w17, [x0, #-1]
    //     0x5dc340: and             x16, x17, x16, lsr #2
    //     0x5dc344: tst             x16, HEAP, lsr #32
    //     0x5dc348: b.eq            #0x5dc350
    //     0x5dc34c: bl              #0xd682cc
    // 0x5dc350: ldr             x0, [fp, #0x10]
    // 0x5dc354: tbnz            w0, #4, #0x5dc364
    // 0x5dc358: ldur            x5, [fp, #-0x18]
    // 0x5dc35c: r1 = true
    //     0x5dc35c: add             x1, NULL, #0x20  ; true
    // 0x5dc360: b               #0x5dc370
    // 0x5dc364: ldur            x5, [fp, #-0x18]
    // 0x5dc368: LoadField: r1 = r5->field_3f
    //     0x5dc368: ldur            w1, [x5, #0x3f]
    // 0x5dc36c: DecompressPointer r1
    //     0x5dc36c: add             x1, x1, HEAP, lsl #32
    // 0x5dc370: ldr             x6, [fp, #0x18]
    // 0x5dc374: StoreField: r4->field_27 = r1
    //     0x5dc374: stur            w1, [x4, #0x27]
    // 0x5dc378: mov             x2, x4
    // 0x5dc37c: r1 = Function '<anonymous closure>':.
    //     0x5dc37c: ldr             x1, [PP, #0x4960]  ; [pp+0x4960] AnonymousClosure: (0x5dc80c), in [package:flutter/src/rendering/object.dart] RenderObject::_getSemanticsForParent (0x5dc1f0)
    // 0x5dc380: r0 = AllocateClosure()
    //     0x5dc380: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5dc384: ldr             x1, [fp, #0x18]
    // 0x5dc388: r2 = LoadClassIdInstr(r1)
    //     0x5dc388: ldur            x2, [x1, #-1]
    //     0x5dc38c: ubfx            x2, x2, #0xc, #0x14
    // 0x5dc390: stp             x0, x1, [SP, #-0x10]!
    // 0x5dc394: mov             x0, x2
    // 0x5dc398: r0 = GDT[cid_x0 + 0xe3b8]()
    //     0x5dc398: mov             x17, #0xe3b8
    //     0x5dc39c: add             lr, x0, x17
    //     0x5dc3a0: ldr             lr, [x21, lr, lsl #3]
    //     0x5dc3a4: blr             lr
    // 0x5dc3a8: add             SP, SP, #0x10
    // 0x5dc3ac: ldur            x16, [fp, #-0x30]
    // 0x5dc3b0: SaveReg r16
    //     0x5dc3b0: str             x16, [SP, #-8]!
    // 0x5dc3b4: r0 = iterator()
    //     0x5dc3b4: bl              #0x9bb174  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x5dc3b8: add             SP, SP, #8
    // 0x5dc3bc: stur            x0, [fp, #-0x30]
    // 0x5dc3c0: LoadField: r2 = r0->field_7
    //     0x5dc3c0: ldur            w2, [x0, #7]
    // 0x5dc3c4: DecompressPointer r2
    //     0x5dc3c4: add             x2, x2, HEAP, lsl #32
    // 0x5dc3c8: stur            x2, [fp, #-0x28]
    // 0x5dc3cc: CheckStackOverflow
    //     0x5dc3cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5dc3d0: cmp             SP, x16
    //     0x5dc3d4: b.ls            #0x5dc630
    // 0x5dc3d8: SaveReg r0
    //     0x5dc3d8: str             x0, [SP, #-8]!
    // 0x5dc3dc: r0 = moveNext()
    //     0x5dc3dc: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x5dc3e0: add             SP, SP, #8
    // 0x5dc3e4: tbnz            w0, #4, #0x5dc45c
    // 0x5dc3e8: ldur            x3, [fp, #-0x30]
    // 0x5dc3ec: LoadField: r4 = r3->field_33
    //     0x5dc3ec: ldur            w4, [x3, #0x33]
    // 0x5dc3f0: DecompressPointer r4
    //     0x5dc3f0: add             x4, x4, HEAP, lsl #32
    // 0x5dc3f4: stur            x4, [fp, #-0x38]
    // 0x5dc3f8: cmp             w4, NULL
    // 0x5dc3fc: b.ne            #0x5dc42c
    // 0x5dc400: mov             x0, x4
    // 0x5dc404: ldur            x2, [fp, #-0x28]
    // 0x5dc408: r1 = Null
    //     0x5dc408: mov             x1, NULL
    // 0x5dc40c: cmp             w2, NULL
    // 0x5dc410: b.eq            #0x5dc42c
    // 0x5dc414: LoadField: r4 = r2->field_17
    //     0x5dc414: ldur            w4, [x2, #0x17]
    // 0x5dc418: DecompressPointer r4
    //     0x5dc418: add             x4, x4, HEAP, lsl #32
    // 0x5dc41c: r8 = X0
    //     0x5dc41c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5dc420: LoadField: r9 = r4->field_7
    //     0x5dc420: ldur            x9, [x4, #7]
    // 0x5dc424: r3 = Null
    //     0x5dc424: ldr             x3, [PP, #0x4968]  ; [pp+0x4968] Null
    // 0x5dc428: blr             x9
    // 0x5dc42c: ldur            x0, [fp, #-0x38]
    // 0x5dc430: r1 = LoadClassIdInstr(r0)
    //     0x5dc430: ldur            x1, [x0, #-1]
    //     0x5dc434: ubfx            x1, x1, #0xc, #0x14
    // 0x5dc438: SaveReg r0
    //     0x5dc438: str             x0, [SP, #-8]!
    // 0x5dc43c: mov             x0, x1
    // 0x5dc440: r0 = GDT[cid_x0 + -0xffc]()
    //     0x5dc440: sub             lr, x0, #0xffc
    //     0x5dc444: ldr             lr, [x21, lr, lsl #3]
    //     0x5dc448: blr             lr
    // 0x5dc44c: add             SP, SP, #8
    // 0x5dc450: ldur            x0, [fp, #-0x30]
    // 0x5dc454: ldur            x2, [fp, #-0x28]
    // 0x5dc458: b               #0x5dc3cc
    // 0x5dc45c: ldr             x1, [fp, #0x18]
    // 0x5dc460: r0 = false
    //     0x5dc460: add             x0, NULL, #0x30  ; false
    // 0x5dc464: StoreField: r1->field_47 = r0
    //     0x5dc464: stur            w0, [x1, #0x47]
    // 0x5dc468: r0 = LoadClassIdInstr(r1)
    //     0x5dc468: ldur            x0, [x1, #-1]
    //     0x5dc46c: ubfx            x0, x0, #0xc, #0x14
    // 0x5dc470: SaveReg r1
    //     0x5dc470: str             x1, [SP, #-8]!
    // 0x5dc474: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0x5dc474: mov             x17, #0xa2f1
    //     0x5dc478: add             lr, x0, x17
    //     0x5dc47c: ldr             lr, [x21, lr, lsl #3]
    //     0x5dc480: blr             lr
    // 0x5dc484: add             SP, SP, #8
    // 0x5dc488: r1 = LoadClassIdInstr(r0)
    //     0x5dc488: ldur            x1, [x0, #-1]
    //     0x5dc48c: ubfx            x1, x1, #0xc, #0x14
    // 0x5dc490: lsl             x1, x1, #1
    // 0x5dc494: r0 = LoadInt32Instr(r1)
    //     0x5dc494: sbfx            x0, x1, #1, #0x1f
    // 0x5dc498: cmp             x0, #0x961
    // 0x5dc49c: b.lt            #0x5dc564
    // 0x5dc4a0: cmp             x0, #0xa1f
    // 0x5dc4a4: b.le            #0x5dc4b0
    // 0x5dc4a8: ldur            x0, [fp, #-8]
    // 0x5dc4ac: b               #0x5dc568
    // 0x5dc4b0: ldur            x0, [fp, #-0x10]
    // 0x5dc4b4: tbnz            w0, #4, #0x5dc4fc
    // 0x5dc4b8: ldur            x0, [fp, #-8]
    // 0x5dc4bc: LoadField: r1 = r0->field_17
    //     0x5dc4bc: ldur            w1, [x0, #0x17]
    // 0x5dc4c0: DecompressPointer r1
    //     0x5dc4c0: add             x1, x1, HEAP, lsl #32
    // 0x5dc4c4: stur            x1, [fp, #-0x10]
    // 0x5dc4c8: r16 = <_InterestingSemanticsFragment>
    //     0x5dc4c8: ldr             x16, [PP, #0x4958]  ; [pp+0x4958] TypeArguments: <_InterestingSemanticsFragment>
    // 0x5dc4cc: stp             xzr, x16, [SP, #-0x10]!
    // 0x5dc4d0: r0 = _GrowableList()
    //     0x5dc4d0: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x5dc4d4: add             SP, SP, #0x10
    // 0x5dc4d8: stur            x0, [fp, #-0x28]
    // 0x5dc4dc: r0 = _ContainerSemanticsFragment()
    //     0x5dc4dc: bl              #0x5dc800  ; Allocate_ContainerSemanticsFragmentStub -> _ContainerSemanticsFragment (size=0x10)
    // 0x5dc4e0: mov             x1, x0
    // 0x5dc4e4: ldur            x0, [fp, #-0x28]
    // 0x5dc4e8: StoreField: r1->field_b = r0
    //     0x5dc4e8: stur            w0, [x1, #0xb]
    // 0x5dc4ec: ldur            x0, [fp, #-0x10]
    // 0x5dc4f0: StoreField: r1->field_7 = r0
    //     0x5dc4f0: stur            w0, [x1, #7]
    // 0x5dc4f4: mov             x0, x1
    // 0x5dc4f8: b               #0x5dc598
    // 0x5dc4fc: ldur            x0, [fp, #-8]
    // 0x5dc500: ldur            x1, [fp, #-0x18]
    // 0x5dc504: LoadField: r2 = r0->field_17
    //     0x5dc504: ldur            w2, [x0, #0x17]
    // 0x5dc508: DecompressPointer r2
    //     0x5dc508: add             x2, x2, HEAP, lsl #32
    // 0x5dc50c: stur            x2, [fp, #-0x10]
    // 0x5dc510: r0 = _SwitchableSemanticsFragment()
    //     0x5dc510: bl              #0x5dc7f4  ; Allocate_SwitchableSemanticsFragmentStub -> _SwitchableSemanticsFragment (size=0x28)
    // 0x5dc514: stur            x0, [fp, #-0x28]
    // 0x5dc518: ldur            x16, [fp, #-0x18]
    // 0x5dc51c: stp             x16, x0, [SP, #-0x10]!
    // 0x5dc520: ldur            x16, [fp, #-0x10]
    // 0x5dc524: ldr             lr, [fp, #0x10]
    // 0x5dc528: stp             lr, x16, [SP, #-0x10]!
    // 0x5dc52c: ldr             x16, [fp, #0x18]
    // 0x5dc530: SaveReg r16
    //     0x5dc530: str             x16, [SP, #-8]!
    // 0x5dc534: r0 = _SwitchableSemanticsFragment()
    //     0x5dc534: bl              #0x5dc700  ; [package:flutter/src/rendering/object.dart] _SwitchableSemanticsFragment::_SwitchableSemanticsFragment
    // 0x5dc538: add             SP, SP, #0x28
    // 0x5dc53c: ldur            x0, [fp, #-0x18]
    // 0x5dc540: LoadField: r1 = r0->field_7
    //     0x5dc540: ldur            w1, [x0, #7]
    // 0x5dc544: DecompressPointer r1
    //     0x5dc544: add             x1, x1, HEAP, lsl #32
    // 0x5dc548: tbnz            w1, #4, #0x5dc55c
    // 0x5dc54c: ldur            x16, [fp, #-0x28]
    // 0x5dc550: SaveReg r16
    //     0x5dc550: str             x16, [SP, #-8]!
    // 0x5dc554: r0 = markAsExplicit()
    //     0x5dc554: bl              #0xd016d4  ; [package:flutter/src/rendering/object.dart] _SwitchableSemanticsFragment::markAsExplicit
    // 0x5dc558: add             SP, SP, #8
    // 0x5dc55c: ldur            x0, [fp, #-0x28]
    // 0x5dc560: b               #0x5dc598
    // 0x5dc564: ldur            x0, [fp, #-8]
    // 0x5dc568: LoadField: r1 = r0->field_17
    //     0x5dc568: ldur            w1, [x0, #0x17]
    // 0x5dc56c: DecompressPointer r1
    //     0x5dc56c: add             x1, x1, HEAP, lsl #32
    // 0x5dc570: stur            x1, [fp, #-0x10]
    // 0x5dc574: r0 = _RootSemanticsFragment()
    //     0x5dc574: bl              #0x5dc6f4  ; Allocate_RootSemanticsFragmentStub -> _RootSemanticsFragment (size=0x18)
    // 0x5dc578: stur            x0, [fp, #-8]
    // 0x5dc57c: ldur            x16, [fp, #-0x10]
    // 0x5dc580: stp             x16, x0, [SP, #-0x10]!
    // 0x5dc584: ldr             x16, [fp, #0x18]
    // 0x5dc588: SaveReg r16
    //     0x5dc588: str             x16, [SP, #-8]!
    // 0x5dc58c: r0 = _RootSemanticsFragment()
    //     0x5dc58c: bl              #0x5dc638  ; [package:flutter/src/rendering/object.dart] _RootSemanticsFragment::_RootSemanticsFragment
    // 0x5dc590: add             SP, SP, #0x18
    // 0x5dc594: ldur            x0, [fp, #-8]
    // 0x5dc598: stur            x0, [fp, #-8]
    // 0x5dc59c: r1 = LoadClassIdInstr(r0)
    //     0x5dc59c: ldur            x1, [x0, #-1]
    //     0x5dc5a0: ubfx            x1, x1, #0xc, #0x14
    // 0x5dc5a4: lsl             x1, x1, #1
    // 0x5dc5a8: cmp             w1, #0xfc8
    // 0x5dc5ac: b.ne            #0x5dc5cc
    // 0x5dc5b0: LoadField: r1 = r0->field_13
    //     0x5dc5b0: ldur            w1, [x0, #0x13]
    // 0x5dc5b4: DecompressPointer r1
    //     0x5dc5b4: add             x1, x1, HEAP, lsl #32
    // 0x5dc5b8: ldur            x16, [fp, #-0x20]
    // 0x5dc5bc: stp             x16, x1, [SP, #-0x10]!
    // 0x5dc5c0: r0 = addAll()
    //     0x5dc5c0: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0x5dc5c4: add             SP, SP, #0x10
    // 0x5dc5c8: b               #0x5dc618
    // 0x5dc5cc: cmp             w1, #0xfca
    // 0x5dc5d0: b.ne            #0x5dc5f4
    // 0x5dc5d4: ldur            x0, [fp, #-8]
    // 0x5dc5d8: LoadField: r1 = r0->field_b
    //     0x5dc5d8: ldur            w1, [x0, #0xb]
    // 0x5dc5dc: DecompressPointer r1
    //     0x5dc5dc: add             x1, x1, HEAP, lsl #32
    // 0x5dc5e0: ldur            x16, [fp, #-0x20]
    // 0x5dc5e4: stp             x16, x1, [SP, #-0x10]!
    // 0x5dc5e8: r0 = addAll()
    //     0x5dc5e8: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0x5dc5ec: add             SP, SP, #0x10
    // 0x5dc5f0: b               #0x5dc618
    // 0x5dc5f4: ldur            x1, [fp, #-8]
    // 0x5dc5f8: r0 = LoadClassIdInstr(r1)
    //     0x5dc5f8: ldur            x0, [x1, #-1]
    //     0x5dc5fc: ubfx            x0, x0, #0xc, #0x14
    // 0x5dc600: ldur            x16, [fp, #-0x20]
    // 0x5dc604: stp             x16, x1, [SP, #-0x10]!
    // 0x5dc608: r0 = GDT[cid_x0 + -0xffa]()
    //     0x5dc608: sub             lr, x0, #0xffa
    //     0x5dc60c: ldr             lr, [x21, lr, lsl #3]
    //     0x5dc610: blr             lr
    // 0x5dc614: add             SP, SP, #0x10
    // 0x5dc618: ldur            x0, [fp, #-8]
    // 0x5dc61c: LeaveFrame
    //     0x5dc61c: mov             SP, fp
    //     0x5dc620: ldp             fp, lr, [SP], #0x10
    // 0x5dc624: ret
    //     0x5dc624: ret             
    // 0x5dc628: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5dc628: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5dc62c: b               #0x5dc208
    // 0x5dc630: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5dc630: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5dc634: b               #0x5dc3d8
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0x5dc80c, size: 0x790
    // 0x5dc80c: EnterFrame
    //     0x5dc80c: stp             fp, lr, [SP, #-0x10]!
    //     0x5dc810: mov             fp, SP
    // 0x5dc814: AllocStack(0x78)
    //     0x5dc814: sub             SP, SP, #0x78
    // 0x5dc818: SetupParameters()
    //     0x5dc818: ldr             x0, [fp, #0x18]
    //     0x5dc81c: ldur            w1, [x0, #0x17]
    //     0x5dc820: add             x1, x1, HEAP, lsl #32
    //     0x5dc824: stur            x1, [fp, #-8]
    // 0x5dc828: CheckStackOverflow
    //     0x5dc828: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5dc82c: cmp             SP, x16
    //     0x5dc830: b.ls            #0x5dcf74
    // 0x5dc834: LoadField: r0 = r1->field_27
    //     0x5dc834: ldur            w0, [x1, #0x27]
    // 0x5dc838: DecompressPointer r0
    //     0x5dc838: add             x0, x0, HEAP, lsl #32
    // 0x5dc83c: ldr             x16, [fp, #0x10]
    // 0x5dc840: stp             x0, x16, [SP, #-0x10]!
    // 0x5dc844: r0 = _getSemanticsForParent()
    //     0x5dc844: bl              #0x5dc1f0  ; [package:flutter/src/rendering/object.dart] RenderObject::_getSemanticsForParent
    // 0x5dc848: add             SP, SP, #0x10
    // 0x5dc84c: stur            x0, [fp, #-0x10]
    // 0x5dc850: LoadField: r1 = r0->field_7
    //     0x5dc850: ldur            w1, [x0, #7]
    // 0x5dc854: DecompressPointer r1
    //     0x5dc854: add             x1, x1, HEAP, lsl #32
    // 0x5dc858: tbnz            w1, #4, #0x5dc8b0
    // 0x5dc85c: ldur            x1, [fp, #-8]
    // 0x5dc860: LoadField: r2 = r1->field_1f
    //     0x5dc860: ldur            w2, [x1, #0x1f]
    // 0x5dc864: DecompressPointer r2
    //     0x5dc864: add             x2, x2, HEAP, lsl #32
    // 0x5dc868: SaveReg r2
    //     0x5dc868: str             x2, [SP, #-8]!
    // 0x5dc86c: r0 = clear()
    //     0x5dc86c: bl              #0xd281bc  ; [dart:core] _GrowableList::clear
    // 0x5dc870: add             SP, SP, #8
    // 0x5dc874: ldur            x0, [fp, #-8]
    // 0x5dc878: LoadField: r1 = r0->field_23
    //     0x5dc878: ldur            w1, [x0, #0x23]
    // 0x5dc87c: DecompressPointer r1
    //     0x5dc87c: add             x1, x1, HEAP, lsl #32
    // 0x5dc880: SaveReg r1
    //     0x5dc880: str             x1, [SP, #-8]!
    // 0x5dc884: r0 = clear()
    //     0x5dc884: bl              #0x536e88  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::clear
    // 0x5dc888: add             SP, SP, #8
    // 0x5dc88c: ldur            x0, [fp, #-8]
    // 0x5dc890: LoadField: r1 = r0->field_13
    //     0x5dc890: ldur            w1, [x0, #0x13]
    // 0x5dc894: DecompressPointer r1
    //     0x5dc894: add             x1, x1, HEAP, lsl #32
    // 0x5dc898: LoadField: r2 = r1->field_7
    //     0x5dc898: ldur            w2, [x1, #7]
    // 0x5dc89c: DecompressPointer r2
    //     0x5dc89c: add             x2, x2, HEAP, lsl #32
    // 0x5dc8a0: tbz             w2, #4, #0x5dc8b4
    // 0x5dc8a4: r1 = true
    //     0x5dc8a4: add             x1, NULL, #0x20  ; true
    // 0x5dc8a8: StoreField: r0->field_17 = r1
    //     0x5dc8a8: stur            w1, [x0, #0x17]
    // 0x5dc8ac: b               #0x5dc8b4
    // 0x5dc8b0: ldur            x0, [fp, #-8]
    // 0x5dc8b4: ldur            x3, [fp, #-0x10]
    // 0x5dc8b8: r1 = LoadClassIdInstr(r3)
    //     0x5dc8b8: ldur            x1, [x3, #-1]
    //     0x5dc8bc: ubfx            x1, x1, #0xc, #0x14
    // 0x5dc8c0: lsl             x1, x1, #1
    // 0x5dc8c4: cmp             w1, #0xfc8
    // 0x5dc8c8: b.gt            #0x5dc920
    // 0x5dc8cc: cmp             w1, #0xfc6
    // 0x5dc8d0: b.lt            #0x5dc918
    // 0x5dc8d4: r4 = 2
    //     0x5dc8d4: mov             x4, #2
    // 0x5dc8d8: mov             x2, x4
    // 0x5dc8dc: r1 = Null
    //     0x5dc8dc: mov             x1, NULL
    // 0x5dc8e0: r0 = AllocateArray()
    //     0x5dc8e0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x5dc8e4: mov             x2, x0
    // 0x5dc8e8: ldur            x0, [fp, #-0x10]
    // 0x5dc8ec: stur            x2, [fp, #-0x18]
    // 0x5dc8f0: StoreField: r2->field_f = r0
    //     0x5dc8f0: stur            w0, [x2, #0xf]
    // 0x5dc8f4: r1 = <_InterestingSemanticsFragment>
    //     0x5dc8f4: ldr             x1, [PP, #0x4958]  ; [pp+0x4958] TypeArguments: <_InterestingSemanticsFragment>
    // 0x5dc8f8: r0 = AllocateGrowableArray()
    //     0x5dc8f8: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x5dc8fc: mov             x1, x0
    // 0x5dc900: ldur            x0, [fp, #-0x18]
    // 0x5dc904: StoreField: r1->field_f = r0
    //     0x5dc904: stur            w0, [x1, #0xf]
    // 0x5dc908: r0 = 2
    //     0x5dc908: mov             x0, #2
    // 0x5dc90c: StoreField: r1->field_b = r0
    //     0x5dc90c: stur            w0, [x1, #0xb]
    // 0x5dc910: mov             x2, x1
    // 0x5dc914: b               #0x5dc930
    // 0x5dc918: mov             x0, x3
    // 0x5dc91c: b               #0x5dc924
    // 0x5dc920: mov             x0, x3
    // 0x5dc924: LoadField: r1 = r0->field_b
    //     0x5dc924: ldur            w1, [x0, #0xb]
    // 0x5dc928: DecompressPointer r1
    //     0x5dc928: add             x1, x1, HEAP, lsl #32
    // 0x5dc92c: mov             x2, x1
    // 0x5dc930: ldur            x1, [fp, #-8]
    // 0x5dc934: stur            x2, [fp, #-0x48]
    // 0x5dc938: LoadField: r3 = r2->field_7
    //     0x5dc938: ldur            w3, [x2, #7]
    // 0x5dc93c: DecompressPointer r3
    //     0x5dc93c: add             x3, x3, HEAP, lsl #32
    // 0x5dc940: stur            x3, [fp, #-0x40]
    // 0x5dc944: LoadField: r0 = r2->field_b
    //     0x5dc944: ldur            w0, [x2, #0xb]
    // 0x5dc948: DecompressPointer r0
    //     0x5dc948: add             x0, x0, HEAP, lsl #32
    // 0x5dc94c: r4 = LoadInt32Instr(r0)
    //     0x5dc94c: sbfx            x4, x0, #1, #0x1f
    // 0x5dc950: stur            x4, [fp, #-0x38]
    // 0x5dc954: LoadField: r5 = r1->field_1f
    //     0x5dc954: ldur            w5, [x1, #0x1f]
    // 0x5dc958: DecompressPointer r5
    //     0x5dc958: add             x5, x5, HEAP, lsl #32
    // 0x5dc95c: stur            x5, [fp, #-0x30]
    // 0x5dc960: LoadField: r6 = r1->field_13
    //     0x5dc960: ldur            w6, [x1, #0x13]
    // 0x5dc964: DecompressPointer r6
    //     0x5dc964: add             x6, x6, HEAP, lsl #32
    // 0x5dc968: stur            x6, [fp, #-0x28]
    // 0x5dc96c: LoadField: r7 = r1->field_1b
    //     0x5dc96c: ldur            w7, [x1, #0x1b]
    // 0x5dc970: DecompressPointer r7
    //     0x5dc970: add             x7, x7, HEAP, lsl #32
    // 0x5dc974: stur            x7, [fp, #-0x18]
    // 0x5dc978: LoadField: r8 = r1->field_23
    //     0x5dc978: ldur            w8, [x1, #0x23]
    // 0x5dc97c: DecompressPointer r8
    //     0x5dc97c: add             x8, x8, HEAP, lsl #32
    // 0x5dc980: stur            x8, [fp, #-0x10]
    // 0x5dc984: r9 = 0
    //     0x5dc984: mov             x9, #0
    // 0x5dc988: stur            x9, [fp, #-0x20]
    // 0x5dc98c: CheckStackOverflow
    //     0x5dc98c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5dc990: cmp             SP, x16
    //     0x5dc994: b.ls            #0x5dcf7c
    // 0x5dc998: r0 = LoadClassIdInstr(r2)
    //     0x5dc998: ldur            x0, [x2, #-1]
    //     0x5dc99c: ubfx            x0, x0, #0xc, #0x14
    // 0x5dc9a0: SaveReg r2
    //     0x5dc9a0: str             x2, [SP, #-8]!
    // 0x5dc9a4: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x5dc9a4: mov             x17, #0xb8ea
    //     0x5dc9a8: add             lr, x0, x17
    //     0x5dc9ac: ldr             lr, [x21, lr, lsl #3]
    //     0x5dc9b0: blr             lr
    // 0x5dc9b4: add             SP, SP, #8
    // 0x5dc9b8: r1 = LoadInt32Instr(r0)
    //     0x5dc9b8: sbfx            x1, x0, #1, #0x1f
    //     0x5dc9bc: tbz             w0, #0, #0x5dc9c4
    //     0x5dc9c0: ldur            x1, [x0, #7]
    // 0x5dc9c4: ldur            x2, [fp, #-0x38]
    // 0x5dc9c8: cmp             x2, x1
    // 0x5dc9cc: b.ne            #0x5dcf5c
    // 0x5dc9d0: ldur            x3, [fp, #-0x48]
    // 0x5dc9d4: ldur            x4, [fp, #-0x20]
    // 0x5dc9d8: cmp             x4, x1
    // 0x5dc9dc: b.lt            #0x5dc9f0
    // 0x5dc9e0: r0 = Null
    //     0x5dc9e0: mov             x0, NULL
    // 0x5dc9e4: LeaveFrame
    //     0x5dc9e4: mov             SP, fp
    //     0x5dc9e8: ldp             fp, lr, [SP], #0x10
    // 0x5dc9ec: ret
    //     0x5dc9ec: ret             
    // 0x5dc9f0: r0 = BoxInt64Instr(r4)
    //     0x5dc9f0: sbfiz           x0, x4, #1, #0x1f
    //     0x5dc9f4: cmp             x4, x0, asr #1
    //     0x5dc9f8: b.eq            #0x5dca04
    //     0x5dc9fc: bl              #0xd69bb8
    //     0x5dca00: stur            x4, [x0, #7]
    // 0x5dca04: r1 = LoadClassIdInstr(r3)
    //     0x5dca04: ldur            x1, [x3, #-1]
    //     0x5dca08: ubfx            x1, x1, #0xc, #0x14
    // 0x5dca0c: stp             x0, x3, [SP, #-0x10]!
    // 0x5dca10: mov             x0, x1
    // 0x5dca14: r0 = GDT[cid_x0 + 0xd175]()
    //     0x5dca14: mov             x17, #0xd175
    //     0x5dca18: add             lr, x0, x17
    //     0x5dca1c: ldr             lr, [x21, lr, lsl #3]
    //     0x5dca20: blr             lr
    // 0x5dca24: add             SP, SP, #0x10
    // 0x5dca28: mov             x3, x0
    // 0x5dca2c: ldur            x0, [fp, #-0x20]
    // 0x5dca30: stur            x3, [fp, #-0x58]
    // 0x5dca34: add             x9, x0, #1
    // 0x5dca38: stur            x9, [fp, #-0x50]
    // 0x5dca3c: cmp             w3, NULL
    // 0x5dca40: b.ne            #0x5dca70
    // 0x5dca44: mov             x0, x3
    // 0x5dca48: ldur            x2, [fp, #-0x40]
    // 0x5dca4c: r1 = Null
    //     0x5dca4c: mov             x1, NULL
    // 0x5dca50: cmp             w2, NULL
    // 0x5dca54: b.eq            #0x5dca70
    // 0x5dca58: LoadField: r4 = r2->field_17
    //     0x5dca58: ldur            w4, [x2, #0x17]
    // 0x5dca5c: DecompressPointer r4
    //     0x5dca5c: add             x4, x4, HEAP, lsl #32
    // 0x5dca60: r8 = X0
    //     0x5dca60: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5dca64: LoadField: r9 = r4->field_7
    //     0x5dca64: ldur            x9, [x4, #7]
    // 0x5dca68: r3 = Null
    //     0x5dca68: ldr             x3, [PP, #0x4978]  ; [pp+0x4978] Null
    // 0x5dca6c: blr             x9
    // 0x5dca70: ldur            x0, [fp, #-0x30]
    // 0x5dca74: LoadField: r1 = r0->field_b
    //     0x5dca74: ldur            w1, [x0, #0xb]
    // 0x5dca78: DecompressPointer r1
    //     0x5dca78: add             x1, x1, HEAP, lsl #32
    // 0x5dca7c: stur            x1, [fp, #-0x60]
    // 0x5dca80: LoadField: r2 = r0->field_f
    //     0x5dca80: ldur            w2, [x0, #0xf]
    // 0x5dca84: DecompressPointer r2
    //     0x5dca84: add             x2, x2, HEAP, lsl #32
    // 0x5dca88: LoadField: r3 = r2->field_b
    //     0x5dca88: ldur            w3, [x2, #0xb]
    // 0x5dca8c: DecompressPointer r3
    //     0x5dca8c: add             x3, x3, HEAP, lsl #32
    // 0x5dca90: cmp             w1, w3
    // 0x5dca94: b.ne            #0x5dcaa4
    // 0x5dca98: SaveReg r0
    //     0x5dca98: str             x0, [SP, #-8]!
    // 0x5dca9c: r0 = _growToNextCapacity()
    //     0x5dca9c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x5dcaa0: add             SP, SP, #8
    // 0x5dcaa4: ldur            x4, [fp, #-8]
    // 0x5dcaa8: ldur            x2, [fp, #-0x30]
    // 0x5dcaac: ldur            x3, [fp, #-0x58]
    // 0x5dcab0: ldur            x0, [fp, #-0x60]
    // 0x5dcab4: r5 = LoadInt32Instr(r0)
    //     0x5dcab4: sbfx            x5, x0, #1, #0x1f
    // 0x5dcab8: add             x0, x5, #1
    // 0x5dcabc: lsl             x1, x0, #1
    // 0x5dcac0: StoreField: r2->field_b = r1
    //     0x5dcac0: stur            w1, [x2, #0xb]
    // 0x5dcac4: mov             x1, x5
    // 0x5dcac8: cmp             x1, x0
    // 0x5dcacc: b.hs            #0x5dcf84
    // 0x5dcad0: LoadField: r1 = r2->field_f
    //     0x5dcad0: ldur            w1, [x2, #0xf]
    // 0x5dcad4: DecompressPointer r1
    //     0x5dcad4: add             x1, x1, HEAP, lsl #32
    // 0x5dcad8: mov             x0, x3
    // 0x5dcadc: ArrayStore: r1[r5] = r0  ; List_4
    //     0x5dcadc: add             x25, x1, x5, lsl #2
    //     0x5dcae0: add             x25, x25, #0xf
    //     0x5dcae4: str             w0, [x25]
    //     0x5dcae8: tbz             w0, #0, #0x5dcb04
    //     0x5dcaec: ldurb           w16, [x1, #-1]
    //     0x5dcaf0: ldurb           w17, [x0, #-1]
    //     0x5dcaf4: and             x16, x17, x16, lsr #2
    //     0x5dcaf8: tst             x16, HEAP, lsr #32
    //     0x5dcafc: b.eq            #0x5dcb04
    //     0x5dcb00: bl              #0xd67e5c
    // 0x5dcb04: LoadField: r0 = r4->field_f
    //     0x5dcb04: ldur            w0, [x4, #0xf]
    // 0x5dcb08: DecompressPointer r0
    //     0x5dcb08: add             x0, x0, HEAP, lsl #32
    // 0x5dcb0c: stur            x0, [fp, #-0x70]
    // 0x5dcb10: LoadField: r1 = r3->field_b
    //     0x5dcb10: ldur            w1, [x3, #0xb]
    // 0x5dcb14: DecompressPointer r1
    //     0x5dcb14: add             x1, x1, HEAP, lsl #32
    // 0x5dcb18: stur            x1, [fp, #-0x68]
    // 0x5dcb1c: LoadField: r5 = r1->field_b
    //     0x5dcb1c: ldur            w5, [x1, #0xb]
    // 0x5dcb20: DecompressPointer r5
    //     0x5dcb20: add             x5, x5, HEAP, lsl #32
    // 0x5dcb24: stur            x5, [fp, #-0x60]
    // 0x5dcb28: LoadField: r6 = r1->field_f
    //     0x5dcb28: ldur            w6, [x1, #0xf]
    // 0x5dcb2c: DecompressPointer r6
    //     0x5dcb2c: add             x6, x6, HEAP, lsl #32
    // 0x5dcb30: LoadField: r7 = r6->field_b
    //     0x5dcb30: ldur            w7, [x6, #0xb]
    // 0x5dcb34: DecompressPointer r7
    //     0x5dcb34: add             x7, x7, HEAP, lsl #32
    // 0x5dcb38: cmp             w5, w7
    // 0x5dcb3c: b.ne            #0x5dcb4c
    // 0x5dcb40: SaveReg r1
    //     0x5dcb40: str             x1, [SP, #-8]!
    // 0x5dcb44: r0 = _growToNextCapacity()
    //     0x5dcb44: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x5dcb48: add             SP, SP, #8
    // 0x5dcb4c: ldur            x3, [fp, #-0x28]
    // 0x5dcb50: ldur            x2, [fp, #-0x68]
    // 0x5dcb54: ldur            x0, [fp, #-0x60]
    // 0x5dcb58: r4 = LoadInt32Instr(r0)
    //     0x5dcb58: sbfx            x4, x0, #1, #0x1f
    // 0x5dcb5c: add             x0, x4, #1
    // 0x5dcb60: lsl             x1, x0, #1
    // 0x5dcb64: StoreField: r2->field_b = r1
    //     0x5dcb64: stur            w1, [x2, #0xb]
    // 0x5dcb68: mov             x1, x4
    // 0x5dcb6c: cmp             x1, x0
    // 0x5dcb70: b.hs            #0x5dcf88
    // 0x5dcb74: LoadField: r1 = r2->field_f
    //     0x5dcb74: ldur            w1, [x2, #0xf]
    // 0x5dcb78: DecompressPointer r1
    //     0x5dcb78: add             x1, x1, HEAP, lsl #32
    // 0x5dcb7c: ldur            x0, [fp, #-0x70]
    // 0x5dcb80: ArrayStore: r1[r4] = r0  ; List_4
    //     0x5dcb80: add             x25, x1, x4, lsl #2
    //     0x5dcb84: add             x25, x25, #0xf
    //     0x5dcb88: str             w0, [x25]
    //     0x5dcb8c: tbz             w0, #0, #0x5dcba8
    //     0x5dcb90: ldurb           w16, [x1, #-1]
    //     0x5dcb94: ldurb           w17, [x0, #-1]
    //     0x5dcb98: and             x16, x17, x16, lsr #2
    //     0x5dcb9c: tst             x16, HEAP, lsr #32
    //     0x5dcba0: b.eq            #0x5dcba8
    //     0x5dcba4: bl              #0xd67e5c
    // 0x5dcba8: LoadField: r0 = r3->field_87
    //     0x5dcba8: ldur            w0, [x3, #0x87]
    // 0x5dcbac: DecompressPointer r0
    //     0x5dcbac: add             x0, x0, HEAP, lsl #32
    // 0x5dcbb0: stur            x0, [fp, #-0x60]
    // 0x5dcbb4: cmp             w0, NULL
    // 0x5dcbb8: b.eq            #0x5dcbdc
    // 0x5dcbbc: LoadField: r1 = r0->field_13
    //     0x5dcbbc: ldur            w1, [x0, #0x13]
    // 0x5dcbc0: DecompressPointer r1
    //     0x5dcbc0: add             x1, x1, HEAP, lsl #32
    // 0x5dcbc4: LoadField: r2 = r0->field_17
    //     0x5dcbc4: ldur            w2, [x0, #0x17]
    // 0x5dcbc8: DecompressPointer r2
    //     0x5dcbc8: add             x2, x2, HEAP, lsl #32
    // 0x5dcbcc: r4 = LoadInt32Instr(r1)
    //     0x5dcbcc: sbfx            x4, x1, #1, #0x1f
    // 0x5dcbd0: r1 = LoadInt32Instr(r2)
    //     0x5dcbd0: sbfx            x1, x2, #1, #0x1f
    // 0x5dcbd4: sub             x2, x4, x1
    // 0x5dcbd8: cbnz            x2, #0x5dcbe4
    // 0x5dcbdc: mov             x1, x3
    // 0x5dcbe0: b               #0x5dccd8
    // 0x5dcbe4: ldur            x2, [fp, #-0x58]
    // 0x5dcbe8: LoadField: r1 = r2->field_f
    //     0x5dcbe8: ldur            w1, [x2, #0xf]
    // 0x5dcbec: DecompressPointer r1
    //     0x5dcbec: add             x1, x1, HEAP, lsl #32
    // 0x5dcbf0: cmp             w1, NULL
    // 0x5dcbf4: b.ne            #0x5dccc0
    // 0x5dcbf8: r1 = <SemanticsTag>
    //     0x5dcbf8: ldr             x1, [PP, #0x4830]  ; [pp+0x4830] TypeArguments: <SemanticsTag>
    // 0x5dcbfc: r0 = _Set()
    //     0x5dcbfc: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x5dcc00: stur            x0, [fp, #-0x68]
    // 0x5dcc04: SaveReg r0
    //     0x5dcc04: str             x0, [SP, #-8]!
    // 0x5dcc08: r0 = Shader._()
    //     0x5dcc08: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x5dcc0c: add             SP, SP, #8
    // 0x5dcc10: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x5dcc10: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5dcc14: ldr             x0, [x0, #0x598]
    //     0x5dcc18: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5dcc1c: cmp             w0, w16
    //     0x5dcc20: b.ne            #0x5dcc2c
    //     0x5dcc24: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x5dcc28: bl              #0xd67cdc
    // 0x5dcc2c: ldur            x1, [fp, #-0x68]
    // 0x5dcc30: StoreField: r1->field_1b = r0
    //     0x5dcc30: stur            w0, [x1, #0x1b]
    //     0x5dcc34: ldurb           w16, [x1, #-1]
    //     0x5dcc38: ldurb           w17, [x0, #-1]
    //     0x5dcc3c: and             x16, x17, x16, lsr #2
    //     0x5dcc40: tst             x16, HEAP, lsr #32
    //     0x5dcc44: b.eq            #0x5dcc4c
    //     0x5dcc48: bl              #0xd6826c
    // 0x5dcc4c: StoreField: r1->field_b = rZR
    //     0x5dcc4c: stur            wzr, [x1, #0xb]
    // 0x5dcc50: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x5dcc50: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5dcc54: ldr             x0, [x0, #0x5a0]
    //     0x5dcc58: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5dcc5c: cmp             w0, w16
    //     0x5dcc60: b.ne            #0x5dcc6c
    //     0x5dcc64: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x5dcc68: bl              #0xd67cdc
    // 0x5dcc6c: ldur            x1, [fp, #-0x68]
    // 0x5dcc70: StoreField: r1->field_f = r0
    //     0x5dcc70: stur            w0, [x1, #0xf]
    //     0x5dcc74: ldurb           w16, [x1, #-1]
    //     0x5dcc78: ldurb           w17, [x0, #-1]
    //     0x5dcc7c: and             x16, x17, x16, lsr #2
    //     0x5dcc80: tst             x16, HEAP, lsr #32
    //     0x5dcc84: b.eq            #0x5dcc8c
    //     0x5dcc88: bl              #0xd6826c
    // 0x5dcc8c: StoreField: r1->field_13 = rZR
    //     0x5dcc8c: stur            wzr, [x1, #0x13]
    // 0x5dcc90: StoreField: r1->field_17 = rZR
    //     0x5dcc90: stur            wzr, [x1, #0x17]
    // 0x5dcc94: mov             x0, x1
    // 0x5dcc98: ldur            x2, [fp, #-0x58]
    // 0x5dcc9c: StoreField: r2->field_f = r0
    //     0x5dcc9c: stur            w0, [x2, #0xf]
    //     0x5dcca0: ldurb           w16, [x2, #-1]
    //     0x5dcca4: ldurb           w17, [x0, #-1]
    //     0x5dcca8: and             x16, x17, x16, lsr #2
    //     0x5dccac: tst             x16, HEAP, lsr #32
    //     0x5dccb0: b.eq            #0x5dccb8
    //     0x5dccb4: bl              #0xd6828c
    // 0x5dccb8: mov             x0, x1
    // 0x5dccbc: b               #0x5dccc4
    // 0x5dccc0: mov             x0, x1
    // 0x5dccc4: ldur            x16, [fp, #-0x60]
    // 0x5dccc8: stp             x16, x0, [SP, #-0x10]!
    // 0x5dcccc: r0 = addAll()
    //     0x5dcccc: bl              #0xc79cec  ; [dart:collection] _Set::addAll
    // 0x5dccd0: add             SP, SP, #0x10
    // 0x5dccd4: ldur            x1, [fp, #-0x28]
    // 0x5dccd8: LoadField: r0 = r1->field_b
    //     0x5dccd8: ldur            w0, [x1, #0xb]
    // 0x5dccdc: DecompressPointer r0
    //     0x5dccdc: add             x0, x0, HEAP, lsl #32
    // 0x5dcce0: tbz             w0, #4, #0x5dcf10
    // 0x5dcce4: ldur            x2, [fp, #-8]
    // 0x5dcce8: LoadField: r0 = r2->field_f
    //     0x5dcce8: ldur            w0, [x2, #0xf]
    // 0x5dccec: DecompressPointer r0
    //     0x5dccec: add             x0, x0, HEAP, lsl #32
    // 0x5dccf0: r3 = LoadClassIdInstr(r0)
    //     0x5dccf0: ldur            x3, [x0, #-1]
    //     0x5dccf4: ubfx            x3, x3, #0xc, #0x14
    // 0x5dccf8: SaveReg r0
    //     0x5dccf8: str             x0, [SP, #-8]!
    // 0x5dccfc: mov             x0, x3
    // 0x5dcd00: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0x5dcd00: mov             x17, #0xa2f1
    //     0x5dcd04: add             lr, x0, x17
    //     0x5dcd08: ldr             lr, [x21, lr, lsl #3]
    //     0x5dcd0c: blr             lr
    // 0x5dcd10: add             SP, SP, #8
    // 0x5dcd14: r1 = LoadClassIdInstr(r0)
    //     0x5dcd14: ldur            x1, [x0, #-1]
    //     0x5dcd18: ubfx            x1, x1, #0xc, #0x14
    // 0x5dcd1c: lsl             x1, x1, #1
    // 0x5dcd20: r0 = LoadInt32Instr(r1)
    //     0x5dcd20: sbfx            x0, x1, #1, #0x1f
    // 0x5dcd24: cmp             x0, #0x961
    // 0x5dcd28: b.lt            #0x5dcf10
    // 0x5dcd2c: cmp             x0, #0xa1f
    // 0x5dcd30: b.gt            #0x5dcf10
    // 0x5dcd34: ldur            x1, [fp, #-0x58]
    // 0x5dcd38: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0x5dcd38: mov             x0, #0x76
    //     0x5dcd3c: tbz             w1, #0, #0x5dcd4c
    //     0x5dcd40: ldur            x0, [x1, #-1]
    //     0x5dcd44: ubfx            x0, x0, #0xc, #0x14
    //     0x5dcd48: lsl             x0, x0, #1
    // 0x5dcd4c: cmp             w0, #0xfc6
    // 0x5dcd50: b.ne            #0x5dcf34
    // 0x5dcd54: LoadField: r0 = r1->field_23
    //     0x5dcd54: ldur            w0, [x1, #0x23]
    // 0x5dcd58: DecompressPointer r0
    //     0x5dcd58: add             x0, x0, HEAP, lsl #32
    // 0x5dcd5c: tbz             w0, #4, #0x5dcf34
    // 0x5dcd60: ldur            x2, [fp, #-0x18]
    // 0x5dcd64: mov             x0, x2
    // 0x5dcd68: tbnz            w0, #5, #0x5dcd70
    // 0x5dcd6c: r0 = AssertBoolean()
    //     0x5dcd6c: bl              #0xd67df0  ; AssertBooleanStub
    // 0x5dcd70: ldur            x1, [fp, #-0x18]
    // 0x5dcd74: tbz             w1, #4, #0x5dcf34
    // 0x5dcd78: ldur            x2, [fp, #-0x58]
    // 0x5dcd7c: r0 = LoadClassIdInstr(r2)
    //     0x5dcd7c: ldur            x0, [x2, #-1]
    //     0x5dcd80: ubfx            x0, x0, #0xc, #0x14
    // 0x5dcd84: SaveReg r2
    //     0x5dcd84: str             x2, [SP, #-8]!
    // 0x5dcd88: r0 = GDT[cid_x0 + -0x1000]()
    //     0x5dcd88: sub             lr, x0, #1, lsl #12
    //     0x5dcd8c: ldr             lr, [x21, lr, lsl #3]
    //     0x5dcd90: blr             lr
    // 0x5dcd94: add             SP, SP, #8
    // 0x5dcd98: ldur            x16, [fp, #-0x28]
    // 0x5dcd9c: stp             x0, x16, [SP, #-0x10]!
    // 0x5dcda0: r0 = isCompatibleWith()
    //     0x5dcda0: bl              #0x5dcf9c  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isCompatibleWith
    // 0x5dcda4: add             SP, SP, #0x10
    // 0x5dcda8: tbz             w0, #4, #0x5dcdd8
    // 0x5dcdac: ldur            x16, [fp, #-0x10]
    // 0x5dcdb0: ldur            lr, [fp, #-0x58]
    // 0x5dcdb4: stp             lr, x16, [SP, #-0x10]!
    // 0x5dcdb8: r0 = hash()
    //     0x5dcdb8: bl              #0xc0483c  ; [package:collection/src/equality.dart] DefaultEquality::hash
    // 0x5dcdbc: add             SP, SP, #0x10
    // 0x5dcdc0: ldur            x16, [fp, #-0x10]
    // 0x5dcdc4: ldur            lr, [fp, #-0x58]
    // 0x5dcdc8: stp             lr, x16, [SP, #-0x10]!
    // 0x5dcdcc: SaveReg r0
    //     0x5dcdcc: str             x0, [SP, #-8]!
    // 0x5dcdd0: r0 = _add()
    //     0x5dcdd0: bl              #0x5c1840  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_add
    // 0x5dcdd4: add             SP, SP, #0x18
    // 0x5dcdd8: ldur            x2, [fp, #-0x30]
    // 0x5dcddc: LoadField: r0 = r2->field_b
    //     0x5dcddc: ldur            w0, [x2, #0xb]
    // 0x5dcde0: DecompressPointer r0
    //     0x5dcde0: add             x0, x0, HEAP, lsl #32
    // 0x5dcde4: r1 = LoadInt32Instr(r0)
    //     0x5dcde4: sbfx            x1, x0, #1, #0x1f
    // 0x5dcde8: sub             x3, x1, #1
    // 0x5dcdec: stur            x3, [fp, #-0x78]
    // 0x5dcdf0: r5 = 0
    //     0x5dcdf0: mov             x5, #0
    // 0x5dcdf4: ldur            x4, [fp, #-0x58]
    // 0x5dcdf8: stur            x5, [fp, #-0x20]
    // 0x5dcdfc: CheckStackOverflow
    //     0x5dcdfc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5dce00: cmp             SP, x16
    //     0x5dce04: b.ls            #0x5dcf8c
    // 0x5dce08: cmp             x5, x3
    // 0x5dce0c: b.ge            #0x5dcf34
    // 0x5dce10: LoadField: r0 = r2->field_b
    //     0x5dce10: ldur            w0, [x2, #0xb]
    // 0x5dce14: DecompressPointer r0
    //     0x5dce14: add             x0, x0, HEAP, lsl #32
    // 0x5dce18: r1 = LoadInt32Instr(r0)
    //     0x5dce18: sbfx            x1, x0, #1, #0x1f
    // 0x5dce1c: mov             x0, x1
    // 0x5dce20: mov             x1, x5
    // 0x5dce24: cmp             x1, x0
    // 0x5dce28: b.hs            #0x5dcf94
    // 0x5dce2c: LoadField: r0 = r2->field_f
    //     0x5dce2c: ldur            w0, [x2, #0xf]
    // 0x5dce30: DecompressPointer r0
    //     0x5dce30: add             x0, x0, HEAP, lsl #32
    // 0x5dce34: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x5dce34: add             x16, x0, x5, lsl #2
    //     0x5dce38: ldur            w1, [x16, #0xf]
    // 0x5dce3c: DecompressPointer r1
    //     0x5dce3c: add             x1, x1, HEAP, lsl #32
    // 0x5dce40: stur            x1, [fp, #-0x60]
    // 0x5dce44: r0 = LoadClassIdInstr(r4)
    //     0x5dce44: ldur            x0, [x4, #-1]
    //     0x5dce48: ubfx            x0, x0, #0xc, #0x14
    // 0x5dce4c: SaveReg r4
    //     0x5dce4c: str             x4, [SP, #-8]!
    // 0x5dce50: r0 = GDT[cid_x0 + -0x1000]()
    //     0x5dce50: sub             lr, x0, #1, lsl #12
    //     0x5dce54: ldr             lr, [x21, lr, lsl #3]
    //     0x5dce58: blr             lr
    // 0x5dce5c: add             SP, SP, #8
    // 0x5dce60: mov             x1, x0
    // 0x5dce64: stur            x1, [fp, #-0x68]
    // 0x5dce68: cmp             w1, NULL
    // 0x5dce6c: b.eq            #0x5dcf98
    // 0x5dce70: ldur            x2, [fp, #-0x60]
    // 0x5dce74: r0 = LoadClassIdInstr(r2)
    //     0x5dce74: ldur            x0, [x2, #-1]
    //     0x5dce78: ubfx            x0, x0, #0xc, #0x14
    // 0x5dce7c: SaveReg r2
    //     0x5dce7c: str             x2, [SP, #-8]!
    // 0x5dce80: r0 = GDT[cid_x0 + -0x1000]()
    //     0x5dce80: sub             lr, x0, #1, lsl #12
    //     0x5dce84: ldr             lr, [x21, lr, lsl #3]
    //     0x5dce88: blr             lr
    // 0x5dce8c: add             SP, SP, #8
    // 0x5dce90: ldur            x16, [fp, #-0x68]
    // 0x5dce94: stp             x0, x16, [SP, #-0x10]!
    // 0x5dce98: r0 = isCompatibleWith()
    //     0x5dce98: bl              #0x5dcf9c  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isCompatibleWith
    // 0x5dce9c: add             SP, SP, #0x10
    // 0x5dcea0: tbz             w0, #4, #0x5dcefc
    // 0x5dcea4: ldur            x16, [fp, #-0x10]
    // 0x5dcea8: ldur            lr, [fp, #-0x58]
    // 0x5dceac: stp             lr, x16, [SP, #-0x10]!
    // 0x5dceb0: r0 = hash()
    //     0x5dceb0: bl              #0xc0483c  ; [package:collection/src/equality.dart] DefaultEquality::hash
    // 0x5dceb4: add             SP, SP, #0x10
    // 0x5dceb8: ldur            x16, [fp, #-0x10]
    // 0x5dcebc: ldur            lr, [fp, #-0x58]
    // 0x5dcec0: stp             lr, x16, [SP, #-0x10]!
    // 0x5dcec4: SaveReg r0
    //     0x5dcec4: str             x0, [SP, #-8]!
    // 0x5dcec8: r0 = _add()
    //     0x5dcec8: bl              #0x5c1840  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_add
    // 0x5dcecc: add             SP, SP, #0x18
    // 0x5dced0: ldur            x16, [fp, #-0x10]
    // 0x5dced4: ldur            lr, [fp, #-0x60]
    // 0x5dced8: stp             lr, x16, [SP, #-0x10]!
    // 0x5dcedc: r0 = hash()
    //     0x5dcedc: bl              #0xc0483c  ; [package:collection/src/equality.dart] DefaultEquality::hash
    // 0x5dcee0: add             SP, SP, #0x10
    // 0x5dcee4: ldur            x16, [fp, #-0x10]
    // 0x5dcee8: ldur            lr, [fp, #-0x60]
    // 0x5dceec: stp             lr, x16, [SP, #-0x10]!
    // 0x5dcef0: SaveReg r0
    //     0x5dcef0: str             x0, [SP, #-8]!
    // 0x5dcef4: r0 = _add()
    //     0x5dcef4: bl              #0x5c1840  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_add
    // 0x5dcef8: add             SP, SP, #0x18
    // 0x5dcefc: ldur            x0, [fp, #-0x20]
    // 0x5dcf00: add             x5, x0, #1
    // 0x5dcf04: ldur            x2, [fp, #-0x30]
    // 0x5dcf08: ldur            x3, [fp, #-0x78]
    // 0x5dcf0c: b               #0x5dcdf4
    // 0x5dcf10: ldur            x0, [fp, #-0x58]
    // 0x5dcf14: r1 = LoadClassIdInstr(r0)
    //     0x5dcf14: ldur            x1, [x0, #-1]
    //     0x5dcf18: ubfx            x1, x1, #0xc, #0x14
    // 0x5dcf1c: SaveReg r0
    //     0x5dcf1c: str             x0, [SP, #-8]!
    // 0x5dcf20: mov             x0, x1
    // 0x5dcf24: r0 = GDT[cid_x0 + -0xffc]()
    //     0x5dcf24: sub             lr, x0, #0xffc
    //     0x5dcf28: ldr             lr, [x21, lr, lsl #3]
    //     0x5dcf2c: blr             lr
    // 0x5dcf30: add             SP, SP, #8
    // 0x5dcf34: ldur            x9, [fp, #-0x50]
    // 0x5dcf38: ldur            x1, [fp, #-8]
    // 0x5dcf3c: ldur            x5, [fp, #-0x30]
    // 0x5dcf40: ldur            x6, [fp, #-0x28]
    // 0x5dcf44: ldur            x7, [fp, #-0x18]
    // 0x5dcf48: ldur            x8, [fp, #-0x10]
    // 0x5dcf4c: ldur            x2, [fp, #-0x48]
    // 0x5dcf50: ldur            x3, [fp, #-0x40]
    // 0x5dcf54: ldur            x4, [fp, #-0x38]
    // 0x5dcf58: b               #0x5dc988
    // 0x5dcf5c: ldur            x0, [fp, #-0x48]
    // 0x5dcf60: r0 = ConcurrentModificationError()
    //     0x5dcf60: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x5dcf64: ldur            x3, [fp, #-0x48]
    // 0x5dcf68: StoreField: r0->field_b = r3
    //     0x5dcf68: stur            w3, [x0, #0xb]
    // 0x5dcf6c: r0 = Throw()
    //     0x5dcf6c: bl              #0xd67e38  ; ThrowStub
    // 0x5dcf70: brk             #0
    // 0x5dcf74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5dcf74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5dcf78: b               #0x5dc834
    // 0x5dcf7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5dcf7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5dcf80: b               #0x5dc998
    // 0x5dcf84: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5dcf84: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x5dcf88: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5dcf88: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x5dcf8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5dcf8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5dcf90: b               #0x5dce08
    // 0x5dcf94: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5dcf94: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x5dcf98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5dcf98: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ layer(/* No info */) {
    // ** addr: 0x5de33c, size: 0x18
    // 0x5de33c: ldr             x1, [SP]
    // 0x5de340: LoadField: r2 = r1->field_2f
    //     0x5de340: ldur            w2, [x1, #0x2f]
    // 0x5de344: DecompressPointer r2
    //     0x5de344: add             x2, x2, HEAP, lsl #32
    // 0x5de348: LoadField: r0 = r2->field_b
    //     0x5de348: ldur            w0, [x2, #0xb]
    // 0x5de34c: DecompressPointer r0
    //     0x5de34c: add             x0, x0, HEAP, lsl #32
    // 0x5de350: ret
    //     0x5de350: ret             
  }
  _ _skippedPaintingOnLayer(/* No info */) {
    // ** addr: 0x5de714, size: 0x124
    // 0x5de714: EnterFrame
    //     0x5de714: stp             fp, lr, [SP, #-0x10]!
    //     0x5de718: mov             fp, SP
    // 0x5de71c: AllocStack(0x8)
    //     0x5de71c: sub             SP, SP, #8
    // 0x5de720: CheckStackOverflow
    //     0x5de720: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5de724: cmp             SP, x16
    //     0x5de728: b.ls            #0x5de828
    // 0x5de72c: ldr             x0, [fp, #0x10]
    // 0x5de730: r1 = LoadClassIdInstr(r0)
    //     0x5de730: ldur            x1, [x0, #-1]
    //     0x5de734: ubfx            x1, x1, #0xc, #0x14
    // 0x5de738: SaveReg r0
    //     0x5de738: str             x0, [SP, #-8]!
    // 0x5de73c: mov             x0, x1
    // 0x5de740: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0x5de740: mov             x17, #0xa2f1
    //     0x5de744: add             lr, x0, x17
    //     0x5de748: ldr             lr, [x21, lr, lsl #3]
    //     0x5de74c: blr             lr
    // 0x5de750: add             SP, SP, #8
    // 0x5de754: mov             x1, x0
    // 0x5de758: stur            x1, [fp, #-8]
    // 0x5de75c: CheckStackOverflow
    //     0x5de75c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5de760: cmp             SP, x16
    //     0x5de764: b.ls            #0x5de830
    // 0x5de768: r0 = LoadClassIdInstr(r1)
    //     0x5de768: ldur            x0, [x1, #-1]
    //     0x5de76c: ubfx            x0, x0, #0xc, #0x14
    // 0x5de770: lsl             x0, x0, #1
    // 0x5de774: r2 = LoadInt32Instr(r0)
    //     0x5de774: sbfx            x2, x0, #1, #0x1f
    // 0x5de778: cmp             x2, #0x961
    // 0x5de77c: b.lt            #0x5de818
    // 0x5de780: cmp             x2, #0xa1f
    // 0x5de784: b.gt            #0x5de818
    // 0x5de788: r0 = LoadClassIdInstr(r1)
    //     0x5de788: ldur            x0, [x1, #-1]
    //     0x5de78c: ubfx            x0, x0, #0xc, #0x14
    // 0x5de790: SaveReg r1
    //     0x5de790: str             x1, [SP, #-8]!
    // 0x5de794: r0 = GDT[cid_x0 + 0xd14d]()
    //     0x5de794: mov             x17, #0xd14d
    //     0x5de798: add             lr, x0, x17
    //     0x5de79c: ldr             lr, [x21, lr, lsl #3]
    //     0x5de7a0: blr             lr
    // 0x5de7a4: add             SP, SP, #8
    // 0x5de7a8: tbnz            w0, #4, #0x5de7e4
    // 0x5de7ac: ldur            x0, [fp, #-8]
    // 0x5de7b0: LoadField: r1 = r0->field_2f
    //     0x5de7b0: ldur            w1, [x0, #0x2f]
    // 0x5de7b4: DecompressPointer r1
    //     0x5de7b4: add             x1, x1, HEAP, lsl #32
    // 0x5de7b8: LoadField: r2 = r1->field_b
    //     0x5de7b8: ldur            w2, [x1, #0xb]
    // 0x5de7bc: DecompressPointer r2
    //     0x5de7bc: add             x2, x2, HEAP, lsl #32
    // 0x5de7c0: cmp             w2, NULL
    // 0x5de7c4: b.eq            #0x5de818
    // 0x5de7c8: LoadField: r1 = r2->field_f
    //     0x5de7c8: ldur            w1, [x2, #0xf]
    // 0x5de7cc: DecompressPointer r1
    //     0x5de7cc: add             x1, x1, HEAP, lsl #32
    // 0x5de7d0: cmp             w1, NULL
    // 0x5de7d4: b.ne            #0x5de818
    // 0x5de7d8: r1 = true
    //     0x5de7d8: add             x1, NULL, #0x20  ; true
    // 0x5de7dc: StoreField: r0->field_3b = r1
    //     0x5de7dc: stur            w1, [x0, #0x3b]
    // 0x5de7e0: b               #0x5de7ec
    // 0x5de7e4: ldur            x0, [fp, #-8]
    // 0x5de7e8: r1 = true
    //     0x5de7e8: add             x1, NULL, #0x20  ; true
    // 0x5de7ec: r2 = LoadClassIdInstr(r0)
    //     0x5de7ec: ldur            x2, [x0, #-1]
    //     0x5de7f0: ubfx            x2, x2, #0xc, #0x14
    // 0x5de7f4: SaveReg r0
    //     0x5de7f4: str             x0, [SP, #-8]!
    // 0x5de7f8: mov             x0, x2
    // 0x5de7fc: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0x5de7fc: mov             x17, #0xa2f1
    //     0x5de800: add             lr, x0, x17
    //     0x5de804: ldr             lr, [x21, lr, lsl #3]
    //     0x5de808: blr             lr
    // 0x5de80c: add             SP, SP, #8
    // 0x5de810: mov             x1, x0
    // 0x5de814: b               #0x5de758
    // 0x5de818: r0 = Null
    //     0x5de818: mov             x0, NULL
    // 0x5de81c: LeaveFrame
    //     0x5de81c: mov             SP, fp
    //     0x5de820: ldp             fp, lr, [SP], #0x10
    // 0x5de824: ret
    //     0x5de824: ret             
    // 0x5de828: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5de828: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5de82c: b               #0x5de72c
    // 0x5de830: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5de830: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5de834: b               #0x5de768
  }
  _ _paintWithContext(/* No info */) {
    // ** addr: 0x5df060, size: 0xdc
    // 0x5df060: EnterFrame
    //     0x5df060: stp             fp, lr, [SP, #-0x10]!
    //     0x5df064: mov             fp, SP
    // 0x5df068: AllocStack(0x40)
    //     0x5df068: sub             SP, SP, #0x40
    // 0x5df06c: CheckStackOverflow
    //     0x5df06c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5df070: cmp             SP, x16
    //     0x5df074: b.ls            #0x5df134
    // 0x5df078: ldr             x1, [fp, #0x20]
    // 0x5df07c: LoadField: r0 = r1->field_1b
    //     0x5df07c: ldur            w0, [x1, #0x1b]
    // 0x5df080: DecompressPointer r0
    //     0x5df080: add             x0, x0, HEAP, lsl #32
    // 0x5df084: tbnz            w0, #4, #0x5df098
    // 0x5df088: r0 = Null
    //     0x5df088: mov             x0, NULL
    // 0x5df08c: LeaveFrame
    //     0x5df08c: mov             SP, fp
    //     0x5df090: ldp             fp, lr, [SP], #0x10
    // 0x5df094: ret
    //     0x5df094: ret             
    // 0x5df098: r0 = false
    //     0x5df098: add             x0, NULL, #0x30  ; false
    // 0x5df09c: StoreField: r1->field_3b = r0
    //     0x5df09c: stur            w0, [x1, #0x3b]
    // 0x5df0a0: StoreField: r1->field_3f = r0
    //     0x5df0a0: stur            w0, [x1, #0x3f]
    // 0x5df0a4: r0 = LoadClassIdInstr(r1)
    //     0x5df0a4: ldur            x0, [x1, #-1]
    //     0x5df0a8: ubfx            x0, x0, #0xc, #0x14
    // 0x5df0ac: SaveReg r1
    //     0x5df0ac: str             x1, [SP, #-8]!
    // 0x5df0b0: r0 = GDT[cid_x0 + 0xd14d]()
    //     0x5df0b0: mov             x17, #0xd14d
    //     0x5df0b4: add             lr, x0, x17
    //     0x5df0b8: ldr             lr, [x21, lr, lsl #3]
    //     0x5df0bc: blr             lr
    // 0x5df0c0: add             SP, SP, #8
    // 0x5df0c4: ldr             x1, [fp, #0x20]
    // 0x5df0c8: StoreField: r1->field_2b = r0
    //     0x5df0c8: stur            w0, [x1, #0x2b]
    // 0x5df0cc: r0 = LoadClassIdInstr(r1)
    //     0x5df0cc: ldur            x0, [x1, #-1]
    //     0x5df0d0: ubfx            x0, x0, #0xc, #0x14
    // 0x5df0d4: ldr             x16, [fp, #0x18]
    // 0x5df0d8: stp             x16, x1, [SP, #-0x10]!
    // 0x5df0dc: ldr             x16, [fp, #0x10]
    // 0x5df0e0: SaveReg r16
    //     0x5df0e0: str             x16, [SP, #-8]!
    // 0x5df0e4: r0 = GDT[cid_x0 + 0xe6b4]()
    //     0x5df0e4: mov             x17, #0xe6b4
    //     0x5df0e8: add             lr, x0, x17
    //     0x5df0ec: ldr             lr, [x21, lr, lsl #3]
    //     0x5df0f0: blr             lr
    // 0x5df0f4: add             SP, SP, #0x18
    // 0x5df0f8: b               #0x5df124
    // 0x5df0fc: sub             SP, fp, #0x40
    // 0x5df100: mov             x16, x1
    // 0x5df104: mov             x1, x0
    // 0x5df108: mov             x0, x16
    // 0x5df10c: ldr             x16, [fp, #0x20]
    // 0x5df110: r30 = "paint"
    //     0x5df110: ldr             lr, [PP, #0x4a90]  ; [pp+0x4a90] "paint"
    // 0x5df114: stp             lr, x16, [SP, #-0x10]!
    // 0x5df118: stp             x0, x1, [SP, #-0x10]!
    // 0x5df11c: r0 = _reportException()
    //     0x5df11c: bl              #0x5df13c  ; [package:flutter/src/rendering/object.dart] RenderObject::_reportException
    // 0x5df120: add             SP, SP, #0x20
    // 0x5df124: r0 = Null
    //     0x5df124: mov             x0, NULL
    // 0x5df128: LeaveFrame
    //     0x5df128: mov             SP, fp
    //     0x5df12c: ldp             fp, lr, [SP], #0x10
    // 0x5df130: ret
    //     0x5df130: ret             
    // 0x5df134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5df134: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5df138: b               #0x5df078
  }
  _ _reportException(/* No info */) {
    // ** addr: 0x5df13c, size: 0xf8
    // 0x5df13c: EnterFrame
    //     0x5df13c: stp             fp, lr, [SP, #-0x10]!
    //     0x5df140: mov             fp, SP
    // 0x5df144: AllocStack(0x18)
    //     0x5df144: sub             SP, SP, #0x18
    // 0x5df148: CheckStackOverflow
    //     0x5df148: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5df14c: cmp             SP, x16
    //     0x5df150: b.ls            #0x5df22c
    // 0x5df154: r1 = 1
    //     0x5df154: mov             x1, #1
    // 0x5df158: r0 = AllocateContext()
    //     0x5df158: bl              #0xd68aa4  ; AllocateContextStub
    // 0x5df15c: mov             x3, x0
    // 0x5df160: ldr             x0, [fp, #0x28]
    // 0x5df164: stur            x3, [fp, #-8]
    // 0x5df168: StoreField: r3->field_f = r0
    //     0x5df168: stur            w0, [x3, #0xf]
    // 0x5df16c: r1 = Null
    //     0x5df16c: mov             x1, NULL
    // 0x5df170: r2 = 6
    //     0x5df170: mov             x2, #6
    // 0x5df174: r0 = AllocateArray()
    //     0x5df174: bl              #0xd6987c  ; AllocateArrayStub
    // 0x5df178: r17 = "during "
    //     0x5df178: ldr             x17, [PP, #0x4a98]  ; [pp+0x4a98] "during "
    // 0x5df17c: StoreField: r0->field_f = r17
    //     0x5df17c: stur            w17, [x0, #0xf]
    // 0x5df180: ldr             x1, [fp, #0x20]
    // 0x5df184: StoreField: r0->field_13 = r1
    //     0x5df184: stur            w1, [x0, #0x13]
    // 0x5df188: r17 = "()"
    //     0x5df188: ldr             x17, [PP, #0x4aa0]  ; [pp+0x4aa0] "()"
    // 0x5df18c: StoreField: r0->field_17 = r17
    //     0x5df18c: stur            w17, [x0, #0x17]
    // 0x5df190: SaveReg r0
    //     0x5df190: str             x0, [SP, #-8]!
    // 0x5df194: r0 = _interpolate()
    //     0x5df194: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x5df198: add             SP, SP, #8
    // 0x5df19c: r1 = <List<Object>>
    //     0x5df19c: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0x5df1a0: stur            x0, [fp, #-0x10]
    // 0x5df1a4: r0 = ErrorDescription()
    //     0x5df1a4: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0x5df1a8: stur            x0, [fp, #-0x18]
    // 0x5df1ac: ldur            x16, [fp, #-0x10]
    // 0x5df1b0: stp             x16, x0, [SP, #-0x10]!
    // 0x5df1b4: r16 = Instance_DiagnosticLevel
    //     0x5df1b4: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0x5df1b8: SaveReg r16
    //     0x5df1b8: str             x16, [SP, #-8]!
    // 0x5df1bc: r0 = _ErrorDiagnostic()
    //     0x5df1bc: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x5df1c0: add             SP, SP, #0x18
    // 0x5df1c4: r0 = FlutterErrorDetails()
    //     0x5df1c4: bl              #0x500dc0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x24)
    // 0x5df1c8: mov             x3, x0
    // 0x5df1cc: ldr             x0, [fp, #0x18]
    // 0x5df1d0: stur            x3, [fp, #-0x10]
    // 0x5df1d4: StoreField: r3->field_7 = r0
    //     0x5df1d4: stur            w0, [x3, #7]
    // 0x5df1d8: ldr             x0, [fp, #0x10]
    // 0x5df1dc: StoreField: r3->field_b = r0
    //     0x5df1dc: stur            w0, [x3, #0xb]
    // 0x5df1e0: r0 = "rendering library"
    //     0x5df1e0: ldr             x0, [PP, #0x4aa8]  ; [pp+0x4aa8] "rendering library"
    // 0x5df1e4: StoreField: r3->field_f = r0
    //     0x5df1e4: stur            w0, [x3, #0xf]
    // 0x5df1e8: ldur            x0, [fp, #-0x18]
    // 0x5df1ec: StoreField: r3->field_13 = r0
    //     0x5df1ec: stur            w0, [x3, #0x13]
    // 0x5df1f0: ldur            x2, [fp, #-8]
    // 0x5df1f4: r1 = Function '<anonymous closure>':.
    //     0x5df1f4: ldr             x1, [PP, #0x4ab0]  ; [pp+0x4ab0] AnonymousClosure: (0x5df234), in [package:flutter/src/rendering/object.dart] RenderObject::_reportException (0x5df13c)
    // 0x5df1f8: r0 = AllocateClosure()
    //     0x5df1f8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5df1fc: mov             x1, x0
    // 0x5df200: ldur            x0, [fp, #-0x10]
    // 0x5df204: StoreField: r0->field_1b = r1
    //     0x5df204: stur            w1, [x0, #0x1b]
    // 0x5df208: r1 = false
    //     0x5df208: add             x1, NULL, #0x30  ; false
    // 0x5df20c: StoreField: r0->field_1f = r1
    //     0x5df20c: stur            w1, [x0, #0x1f]
    // 0x5df210: SaveReg r0
    //     0x5df210: str             x0, [SP, #-8]!
    // 0x5df214: r0 = reportError()
    //     0x5df214: bl              #0x4fc16c  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x5df218: add             SP, SP, #8
    // 0x5df21c: r0 = Null
    //     0x5df21c: mov             x0, NULL
    // 0x5df220: LeaveFrame
    //     0x5df220: mov             SP, fp
    //     0x5df224: ldp             fp, lr, [SP], #0x10
    // 0x5df228: ret
    //     0x5df228: ret             
    // 0x5df22c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5df22c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5df230: b               #0x5df154
  }
  [closure] List<DiagnosticsNode> <anonymous closure>(dynamic) {
    // ** addr: 0x5df234, size: 0x1b8
    // 0x5df234: EnterFrame
    //     0x5df234: stp             fp, lr, [SP, #-0x10]!
    //     0x5df238: mov             fp, SP
    // 0x5df23c: AllocStack(0x20)
    //     0x5df23c: sub             SP, SP, #0x20
    // 0x5df240: SetupParameters()
    //     0x5df240: ldr             x0, [fp, #0x10]
    //     0x5df244: ldur            w1, [x0, #0x17]
    //     0x5df248: add             x1, x1, HEAP, lsl #32
    //     0x5df24c: stur            x1, [fp, #-8]
    // 0x5df250: CheckStackOverflow
    //     0x5df250: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5df254: cmp             SP, x16
    //     0x5df258: b.ls            #0x5df3dc
    // 0x5df25c: r16 = <DiagnosticsNode>
    //     0x5df25c: ldr             x16, [PP, #0x3930]  ; [pp+0x3930] TypeArguments: <DiagnosticsNode>
    // 0x5df260: stp             xzr, x16, [SP, #-0x10]!
    // 0x5df264: r0 = _GrowableList()
    //     0x5df264: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x5df268: add             SP, SP, #0x10
    // 0x5df26c: mov             x1, x0
    // 0x5df270: ldur            x0, [fp, #-8]
    // 0x5df274: stur            x1, [fp, #-0x10]
    // 0x5df278: LoadField: r2 = r0->field_f
    //     0x5df278: ldur            w2, [x0, #0xf]
    // 0x5df27c: DecompressPointer r2
    //     0x5df27c: add             x2, x2, HEAP, lsl #32
    // 0x5df280: SaveReg r2
    //     0x5df280: str             x2, [SP, #-8]!
    // 0x5df284: r0 = toDiagnosticsNode()
    //     0x5df284: bl              #0x794ec0  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin::toDiagnosticsNode
    // 0x5df288: add             SP, SP, #8
    // 0x5df28c: mov             x1, x0
    // 0x5df290: ldur            x0, [fp, #-0x10]
    // 0x5df294: stur            x1, [fp, #-0x20]
    // 0x5df298: LoadField: r2 = r0->field_b
    //     0x5df298: ldur            w2, [x0, #0xb]
    // 0x5df29c: DecompressPointer r2
    //     0x5df29c: add             x2, x2, HEAP, lsl #32
    // 0x5df2a0: stur            x2, [fp, #-0x18]
    // 0x5df2a4: LoadField: r3 = r0->field_f
    //     0x5df2a4: ldur            w3, [x0, #0xf]
    // 0x5df2a8: DecompressPointer r3
    //     0x5df2a8: add             x3, x3, HEAP, lsl #32
    // 0x5df2ac: LoadField: r4 = r3->field_b
    //     0x5df2ac: ldur            w4, [x3, #0xb]
    // 0x5df2b0: DecompressPointer r4
    //     0x5df2b0: add             x4, x4, HEAP, lsl #32
    // 0x5df2b4: cmp             w2, w4
    // 0x5df2b8: b.ne            #0x5df2c8
    // 0x5df2bc: SaveReg r0
    //     0x5df2bc: str             x0, [SP, #-8]!
    // 0x5df2c0: r0 = _growToNextCapacity()
    //     0x5df2c0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x5df2c4: add             SP, SP, #8
    // 0x5df2c8: ldur            x3, [fp, #-8]
    // 0x5df2cc: ldur            x2, [fp, #-0x10]
    // 0x5df2d0: ldur            x0, [fp, #-0x18]
    // 0x5df2d4: r4 = LoadInt32Instr(r0)
    //     0x5df2d4: sbfx            x4, x0, #1, #0x1f
    // 0x5df2d8: add             x0, x4, #1
    // 0x5df2dc: lsl             x1, x0, #1
    // 0x5df2e0: StoreField: r2->field_b = r1
    //     0x5df2e0: stur            w1, [x2, #0xb]
    // 0x5df2e4: mov             x1, x4
    // 0x5df2e8: cmp             x1, x0
    // 0x5df2ec: b.hs            #0x5df3e4
    // 0x5df2f0: LoadField: r1 = r2->field_f
    //     0x5df2f0: ldur            w1, [x2, #0xf]
    // 0x5df2f4: DecompressPointer r1
    //     0x5df2f4: add             x1, x1, HEAP, lsl #32
    // 0x5df2f8: ldur            x0, [fp, #-0x20]
    // 0x5df2fc: ArrayStore: r1[r4] = r0  ; List_4
    //     0x5df2fc: add             x25, x1, x4, lsl #2
    //     0x5df300: add             x25, x25, #0xf
    //     0x5df304: str             w0, [x25]
    //     0x5df308: tbz             w0, #0, #0x5df324
    //     0x5df30c: ldurb           w16, [x1, #-1]
    //     0x5df310: ldurb           w17, [x0, #-1]
    //     0x5df314: and             x16, x17, x16, lsr #2
    //     0x5df318: tst             x16, HEAP, lsr #32
    //     0x5df31c: b.eq            #0x5df324
    //     0x5df320: bl              #0xd67e5c
    // 0x5df324: LoadField: r0 = r3->field_f
    //     0x5df324: ldur            w0, [x3, #0xf]
    // 0x5df328: DecompressPointer r0
    //     0x5df328: add             x0, x0, HEAP, lsl #32
    // 0x5df32c: SaveReg r0
    //     0x5df32c: str             x0, [SP, #-8]!
    // 0x5df330: r0 = toDiagnosticsNode()
    //     0x5df330: bl              #0x794ec0  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin::toDiagnosticsNode
    // 0x5df334: add             SP, SP, #8
    // 0x5df338: mov             x1, x0
    // 0x5df33c: ldur            x0, [fp, #-0x10]
    // 0x5df340: stur            x1, [fp, #-0x18]
    // 0x5df344: LoadField: r2 = r0->field_b
    //     0x5df344: ldur            w2, [x0, #0xb]
    // 0x5df348: DecompressPointer r2
    //     0x5df348: add             x2, x2, HEAP, lsl #32
    // 0x5df34c: stur            x2, [fp, #-8]
    // 0x5df350: LoadField: r3 = r0->field_f
    //     0x5df350: ldur            w3, [x0, #0xf]
    // 0x5df354: DecompressPointer r3
    //     0x5df354: add             x3, x3, HEAP, lsl #32
    // 0x5df358: LoadField: r4 = r3->field_b
    //     0x5df358: ldur            w4, [x3, #0xb]
    // 0x5df35c: DecompressPointer r4
    //     0x5df35c: add             x4, x4, HEAP, lsl #32
    // 0x5df360: cmp             w2, w4
    // 0x5df364: b.ne            #0x5df374
    // 0x5df368: SaveReg r0
    //     0x5df368: str             x0, [SP, #-8]!
    // 0x5df36c: r0 = _growToNextCapacity()
    //     0x5df36c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x5df370: add             SP, SP, #8
    // 0x5df374: ldur            x2, [fp, #-0x10]
    // 0x5df378: ldur            x3, [fp, #-8]
    // 0x5df37c: r4 = LoadInt32Instr(r3)
    //     0x5df37c: sbfx            x4, x3, #1, #0x1f
    // 0x5df380: add             x0, x4, #1
    // 0x5df384: lsl             x3, x0, #1
    // 0x5df388: StoreField: r2->field_b = r3
    //     0x5df388: stur            w3, [x2, #0xb]
    // 0x5df38c: mov             x1, x4
    // 0x5df390: cmp             x1, x0
    // 0x5df394: b.hs            #0x5df3e8
    // 0x5df398: LoadField: r1 = r2->field_f
    //     0x5df398: ldur            w1, [x2, #0xf]
    // 0x5df39c: DecompressPointer r1
    //     0x5df39c: add             x1, x1, HEAP, lsl #32
    // 0x5df3a0: ldur            x0, [fp, #-0x18]
    // 0x5df3a4: ArrayStore: r1[r4] = r0  ; List_4
    //     0x5df3a4: add             x25, x1, x4, lsl #2
    //     0x5df3a8: add             x25, x25, #0xf
    //     0x5df3ac: str             w0, [x25]
    //     0x5df3b0: tbz             w0, #0, #0x5df3cc
    //     0x5df3b4: ldurb           w16, [x1, #-1]
    //     0x5df3b8: ldurb           w17, [x0, #-1]
    //     0x5df3bc: and             x16, x17, x16, lsr #2
    //     0x5df3c0: tst             x16, HEAP, lsr #32
    //     0x5df3c4: b.eq            #0x5df3cc
    //     0x5df3c8: bl              #0xd67e5c
    // 0x5df3cc: mov             x0, x2
    // 0x5df3d0: LeaveFrame
    //     0x5df3d0: mov             SP, fp
    //     0x5df3d4: ldp             fp, lr, [SP], #0x10
    // 0x5df3d8: ret
    //     0x5df3d8: ret             
    // 0x5df3dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5df3dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5df3e0: b               #0x5df25c
    // 0x5df3e4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5df3e4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x5df3e8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5df3e8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _updateCompositingBits(/* No info */) {
    // ** addr: 0x5df928, size: 0x260
    // 0x5df928: EnterFrame
    //     0x5df928: stp             fp, lr, [SP, #-0x10]!
    //     0x5df92c: mov             fp, SP
    // 0x5df930: AllocStack(0x10)
    //     0x5df930: sub             SP, SP, #0x10
    // 0x5df934: CheckStackOverflow
    //     0x5df934: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5df938: cmp             SP, x16
    //     0x5df93c: b.ls            #0x5dfb70
    // 0x5df940: r1 = 1
    //     0x5df940: mov             x1, #1
    // 0x5df944: r0 = AllocateContext()
    //     0x5df944: bl              #0xd68aa4  ; AllocateContextStub
    // 0x5df948: mov             x1, x0
    // 0x5df94c: ldr             x0, [fp, #0x10]
    // 0x5df950: StoreField: r1->field_f = r0
    //     0x5df950: stur            w0, [x1, #0xf]
    // 0x5df954: LoadField: r2 = r0->field_33
    //     0x5df954: ldur            w2, [x0, #0x33]
    // 0x5df958: DecompressPointer r2
    //     0x5df958: add             x2, x2, HEAP, lsl #32
    // 0x5df95c: tbz             w2, #4, #0x5df970
    // 0x5df960: r0 = Null
    //     0x5df960: mov             x0, NULL
    // 0x5df964: LeaveFrame
    //     0x5df964: mov             SP, fp
    //     0x5df968: ldp             fp, lr, [SP], #0x10
    // 0x5df96c: ret
    //     0x5df96c: ret             
    // 0x5df970: r3 = false
    //     0x5df970: add             x3, NULL, #0x30  ; false
    // 0x5df974: LoadField: r4 = r0->field_37
    //     0x5df974: ldur            w4, [x0, #0x37]
    // 0x5df978: DecompressPointer r4
    //     0x5df978: add             x4, x4, HEAP, lsl #32
    // 0x5df97c: r16 = Sentinel
    //     0x5df97c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5df980: cmp             w4, w16
    // 0x5df984: b.eq            #0x5dfb78
    // 0x5df988: stur            x4, [fp, #-8]
    // 0x5df98c: StoreField: r0->field_37 = r3
    //     0x5df98c: stur            w3, [x0, #0x37]
    // 0x5df990: mov             x2, x1
    // 0x5df994: r1 = Function '<anonymous closure>':.
    //     0x5df994: ldr             x1, [PP, #0x4b10]  ; [pp+0x4b10] AnonymousClosure: (0x5dfb88), in [package:flutter/src/rendering/object.dart] RenderObject::_updateCompositingBits (0x5df928)
    // 0x5df998: r0 = AllocateClosure()
    //     0x5df998: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5df99c: ldr             x1, [fp, #0x10]
    // 0x5df9a0: r2 = LoadClassIdInstr(r1)
    //     0x5df9a0: ldur            x2, [x1, #-1]
    //     0x5df9a4: ubfx            x2, x2, #0xc, #0x14
    // 0x5df9a8: stp             x0, x1, [SP, #-0x10]!
    // 0x5df9ac: mov             x0, x2
    // 0x5df9b0: r0 = GDT[cid_x0 + 0xd2d5]()
    //     0x5df9b0: mov             x17, #0xd2d5
    //     0x5df9b4: add             lr, x0, x17
    //     0x5df9b8: ldr             lr, [x21, lr, lsl #3]
    //     0x5df9bc: blr             lr
    // 0x5df9c0: add             SP, SP, #0x10
    // 0x5df9c4: ldr             x1, [fp, #0x10]
    // 0x5df9c8: r0 = LoadClassIdInstr(r1)
    //     0x5df9c8: ldur            x0, [x1, #-1]
    //     0x5df9cc: ubfx            x0, x0, #0xc, #0x14
    // 0x5df9d0: SaveReg r1
    //     0x5df9d0: str             x1, [SP, #-8]!
    // 0x5df9d4: r0 = GDT[cid_x0 + 0xd14d]()
    //     0x5df9d4: mov             x17, #0xd14d
    //     0x5df9d8: add             lr, x0, x17
    //     0x5df9dc: ldr             lr, [x21, lr, lsl #3]
    //     0x5df9e0: blr             lr
    // 0x5df9e4: add             SP, SP, #8
    // 0x5df9e8: tbz             w0, #4, #0x5dfa14
    // 0x5df9ec: ldr             x1, [fp, #0x10]
    // 0x5df9f0: r0 = LoadClassIdInstr(r1)
    //     0x5df9f0: ldur            x0, [x1, #-1]
    //     0x5df9f4: ubfx            x0, x0, #0xc, #0x14
    // 0x5df9f8: SaveReg r1
    //     0x5df9f8: str             x1, [SP, #-8]!
    // 0x5df9fc: r0 = GDT[cid_x0 + 0xe536]()
    //     0x5df9fc: mov             x17, #0xe536
    //     0x5dfa00: add             lr, x0, x17
    //     0x5dfa04: ldr             lr, [x21, lr, lsl #3]
    //     0x5dfa08: blr             lr
    // 0x5dfa0c: add             SP, SP, #8
    // 0x5dfa10: tbnz            w0, #4, #0x5dfa24
    // 0x5dfa14: ldr             x1, [fp, #0x10]
    // 0x5dfa18: r0 = true
    //     0x5dfa18: add             x0, NULL, #0x20  ; true
    // 0x5dfa1c: StoreField: r1->field_37 = r0
    //     0x5dfa1c: stur            w0, [x1, #0x37]
    // 0x5dfa20: b               #0x5dfa28
    // 0x5dfa24: ldr             x1, [fp, #0x10]
    // 0x5dfa28: r0 = LoadClassIdInstr(r1)
    //     0x5dfa28: ldur            x0, [x1, #-1]
    //     0x5dfa2c: ubfx            x0, x0, #0xc, #0x14
    // 0x5dfa30: SaveReg r1
    //     0x5dfa30: str             x1, [SP, #-8]!
    // 0x5dfa34: r0 = GDT[cid_x0 + 0xd14d]()
    //     0x5dfa34: mov             x17, #0xd14d
    //     0x5dfa38: add             lr, x0, x17
    //     0x5dfa3c: ldr             lr, [x21, lr, lsl #3]
    //     0x5dfa40: blr             lr
    // 0x5dfa44: add             SP, SP, #8
    // 0x5dfa48: tbz             w0, #4, #0x5dfb14
    // 0x5dfa4c: ldr             x3, [fp, #0x10]
    // 0x5dfa50: LoadField: r0 = r3->field_2b
    //     0x5dfa50: ldur            w0, [x3, #0x2b]
    // 0x5dfa54: DecompressPointer r0
    //     0x5dfa54: add             x0, x0, HEAP, lsl #32
    // 0x5dfa58: r16 = Sentinel
    //     0x5dfa58: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5dfa5c: cmp             w0, w16
    // 0x5dfa60: b.eq            #0x5dfb80
    // 0x5dfa64: tbnz            w0, #4, #0x5dfb08
    // 0x5dfa68: r4 = false
    //     0x5dfa68: add             x4, NULL, #0x30  ; false
    // 0x5dfa6c: StoreField: r3->field_3b = r4
    //     0x5dfa6c: stur            w4, [x3, #0x3b]
    // 0x5dfa70: StoreField: r3->field_3f = r4
    //     0x5dfa70: stur            w4, [x3, #0x3f]
    // 0x5dfa74: LoadField: r5 = r3->field_f
    //     0x5dfa74: ldur            w5, [x3, #0xf]
    // 0x5dfa78: DecompressPointer r5
    //     0x5dfa78: add             x5, x5, HEAP, lsl #32
    // 0x5dfa7c: mov             x0, x5
    // 0x5dfa80: stur            x5, [fp, #-0x10]
    // 0x5dfa84: r2 = Null
    //     0x5dfa84: mov             x2, NULL
    // 0x5dfa88: r1 = Null
    //     0x5dfa88: mov             x1, NULL
    // 0x5dfa8c: r4 = 59
    //     0x5dfa8c: mov             x4, #0x3b
    // 0x5dfa90: branchIfSmi(r0, 0x5dfa9c)
    //     0x5dfa90: tbz             w0, #0, #0x5dfa9c
    // 0x5dfa94: r4 = LoadClassIdInstr(r0)
    //     0x5dfa94: ldur            x4, [x0, #-1]
    //     0x5dfa98: ubfx            x4, x4, #0xc, #0x14
    // 0x5dfa9c: cmp             x4, #0x7e6
    // 0x5dfaa0: b.eq            #0x5dfab0
    // 0x5dfaa4: r8 = PipelineOwner?
    //     0x5dfaa4: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x5dfaa8: r3 = Null
    //     0x5dfaa8: ldr             x3, [PP, #0x4b18]  ; [pp+0x4b18] Null
    // 0x5dfaac: r0 = DefaultNullableTypeTest()
    //     0x5dfaac: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x5dfab0: ldur            x0, [fp, #-0x10]
    // 0x5dfab4: cmp             w0, NULL
    // 0x5dfab8: b.eq            #0x5dfad4
    // 0x5dfabc: LoadField: r1 = r0->field_27
    //     0x5dfabc: ldur            w1, [x0, #0x27]
    // 0x5dfac0: DecompressPointer r1
    //     0x5dfac0: add             x1, x1, HEAP, lsl #32
    // 0x5dfac4: ldr             x16, [fp, #0x10]
    // 0x5dfac8: stp             x16, x1, [SP, #-0x10]!
    // 0x5dfacc: r0 = remove()
    //     0x5dfacc: bl              #0x5f0814  ; [dart:core] _GrowableList::remove
    // 0x5dfad0: add             SP, SP, #0x10
    // 0x5dfad4: ldr             x0, [fp, #0x10]
    // 0x5dfad8: r1 = false
    //     0x5dfad8: add             x1, NULL, #0x30  ; false
    // 0x5dfadc: StoreField: r0->field_33 = r1
    //     0x5dfadc: stur            w1, [x0, #0x33]
    // 0x5dfae0: r1 = LoadClassIdInstr(r0)
    //     0x5dfae0: ldur            x1, [x0, #-1]
    //     0x5dfae4: ubfx            x1, x1, #0xc, #0x14
    // 0x5dfae8: SaveReg r0
    //     0x5dfae8: str             x0, [SP, #-8]!
    // 0x5dfaec: mov             x0, x1
    // 0x5dfaf0: r0 = GDT[cid_x0 + 0xd3b6]()
    //     0x5dfaf0: mov             x17, #0xd3b6
    //     0x5dfaf4: add             lr, x0, x17
    //     0x5dfaf8: ldr             lr, [x21, lr, lsl #3]
    //     0x5dfafc: blr             lr
    // 0x5dfb00: add             SP, SP, #8
    // 0x5dfb04: b               #0x5dfb60
    // 0x5dfb08: mov             x0, x3
    // 0x5dfb0c: r1 = false
    //     0x5dfb0c: add             x1, NULL, #0x30  ; false
    // 0x5dfb10: b               #0x5dfb1c
    // 0x5dfb14: ldr             x0, [fp, #0x10]
    // 0x5dfb18: r1 = false
    //     0x5dfb18: add             x1, NULL, #0x30  ; false
    // 0x5dfb1c: ldur            x2, [fp, #-8]
    // 0x5dfb20: LoadField: r3 = r0->field_37
    //     0x5dfb20: ldur            w3, [x0, #0x37]
    // 0x5dfb24: DecompressPointer r3
    //     0x5dfb24: add             x3, x3, HEAP, lsl #32
    // 0x5dfb28: cmp             w2, w3
    // 0x5dfb2c: b.eq            #0x5dfb5c
    // 0x5dfb30: StoreField: r0->field_33 = r1
    //     0x5dfb30: stur            w1, [x0, #0x33]
    // 0x5dfb34: r1 = LoadClassIdInstr(r0)
    //     0x5dfb34: ldur            x1, [x0, #-1]
    //     0x5dfb38: ubfx            x1, x1, #0xc, #0x14
    // 0x5dfb3c: SaveReg r0
    //     0x5dfb3c: str             x0, [SP, #-8]!
    // 0x5dfb40: mov             x0, x1
    // 0x5dfb44: r0 = GDT[cid_x0 + 0xd3b6]()
    //     0x5dfb44: mov             x17, #0xd3b6
    //     0x5dfb48: add             lr, x0, x17
    //     0x5dfb4c: ldr             lr, [x21, lr, lsl #3]
    //     0x5dfb50: blr             lr
    // 0x5dfb54: add             SP, SP, #8
    // 0x5dfb58: b               #0x5dfb60
    // 0x5dfb5c: StoreField: r0->field_33 = r1
    //     0x5dfb5c: stur            w1, [x0, #0x33]
    // 0x5dfb60: r0 = Null
    //     0x5dfb60: mov             x0, NULL
    // 0x5dfb64: LeaveFrame
    //     0x5dfb64: mov             SP, fp
    //     0x5dfb68: ldp             fp, lr, [SP], #0x10
    // 0x5dfb6c: ret
    //     0x5dfb6c: ret             
    // 0x5dfb70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5dfb70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5dfb74: b               #0x5df940
    // 0x5dfb78: r9 = _needsCompositing
    //     0x5dfb78: ldr             x9, [PP, #0x4b28]  ; [pp+0x4b28] Field <RenderObject._needsCompositing@904266271>: late (offset: 0x38)
    // 0x5dfb7c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x5dfb7c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x5dfb80: r9 = _wasRepaintBoundary
    //     0x5dfb80: ldr             x9, [PP, #0x4b30]  ; [pp+0x4b30] Field <RenderObject._wasRepaintBoundary@904266271>: late (offset: 0x2c)
    // 0x5dfb84: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x5dfb84: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0x5dfb88, size: 0x88
    // 0x5dfb88: EnterFrame
    //     0x5dfb88: stp             fp, lr, [SP, #-0x10]!
    //     0x5dfb8c: mov             fp, SP
    // 0x5dfb90: AllocStack(0x8)
    //     0x5dfb90: sub             SP, SP, #8
    // 0x5dfb94: SetupParameters()
    //     0x5dfb94: ldr             x0, [fp, #0x18]
    //     0x5dfb98: ldur            w1, [x0, #0x17]
    //     0x5dfb9c: add             x1, x1, HEAP, lsl #32
    //     0x5dfba0: stur            x1, [fp, #-8]
    // 0x5dfba4: CheckStackOverflow
    //     0x5dfba4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5dfba8: cmp             SP, x16
    //     0x5dfbac: b.ls            #0x5dfc00
    // 0x5dfbb0: ldr             x16, [fp, #0x10]
    // 0x5dfbb4: SaveReg r16
    //     0x5dfbb4: str             x16, [SP, #-8]!
    // 0x5dfbb8: r0 = _updateCompositingBits()
    //     0x5dfbb8: bl              #0x5df928  ; [package:flutter/src/rendering/object.dart] RenderObject::_updateCompositingBits
    // 0x5dfbbc: add             SP, SP, #8
    // 0x5dfbc0: ldr             x1, [fp, #0x10]
    // 0x5dfbc4: LoadField: r2 = r1->field_37
    //     0x5dfbc4: ldur            w2, [x1, #0x37]
    // 0x5dfbc8: DecompressPointer r2
    //     0x5dfbc8: add             x2, x2, HEAP, lsl #32
    // 0x5dfbcc: r16 = Sentinel
    //     0x5dfbcc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5dfbd0: cmp             w2, w16
    // 0x5dfbd4: b.eq            #0x5dfc08
    // 0x5dfbd8: tbnz            w2, #4, #0x5dfbf0
    // 0x5dfbdc: ldur            x1, [fp, #-8]
    // 0x5dfbe0: r2 = true
    //     0x5dfbe0: add             x2, NULL, #0x20  ; true
    // 0x5dfbe4: LoadField: r3 = r1->field_f
    //     0x5dfbe4: ldur            w3, [x1, #0xf]
    // 0x5dfbe8: DecompressPointer r3
    //     0x5dfbe8: add             x3, x3, HEAP, lsl #32
    // 0x5dfbec: StoreField: r3->field_37 = r2
    //     0x5dfbec: stur            w2, [x3, #0x37]
    // 0x5dfbf0: r0 = Null
    //     0x5dfbf0: mov             x0, NULL
    // 0x5dfbf4: LeaveFrame
    //     0x5dfbf4: mov             SP, fp
    //     0x5dfbf8: ldp             fp, lr, [SP], #0x10
    // 0x5dfbfc: ret
    //     0x5dfbfc: ret             
    // 0x5dfc00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5dfc00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5dfc04: b               #0x5dfbb0
    // 0x5dfc08: r9 = _needsCompositing
    //     0x5dfc08: ldr             x9, [PP, #0x4b28]  ; [pp+0x4b28] Field <RenderObject._needsCompositing@904266271>: late (offset: 0x38)
    // 0x5dfc0c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x5dfc0c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _layoutWithoutResize(/* No info */) {
    // ** addr: 0x5dfec8, size: 0xc4
    // 0x5dfec8: EnterFrame
    //     0x5dfec8: stp             fp, lr, [SP, #-0x10]!
    //     0x5dfecc: mov             fp, SP
    // 0x5dfed0: AllocStack(0x40)
    //     0x5dfed0: sub             SP, SP, #0x40
    // 0x5dfed4: CheckStackOverflow
    //     0x5dfed4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5dfed8: cmp             SP, x16
    //     0x5dfedc: b.ls            #0x5dff84
    // 0x5dfee0: ldr             x1, [fp, #0x10]
    // 0x5dfee4: r0 = LoadClassIdInstr(r1)
    //     0x5dfee4: ldur            x0, [x1, #-1]
    //     0x5dfee8: ubfx            x0, x0, #0xc, #0x14
    // 0x5dfeec: SaveReg r1
    //     0x5dfeec: str             x1, [SP, #-8]!
    // 0x5dfef0: r0 = GDT[cid_x0 + 0xe2f9]()
    //     0x5dfef0: mov             x17, #0xe2f9
    //     0x5dfef4: add             lr, x0, x17
    //     0x5dfef8: ldr             lr, [x21, lr, lsl #3]
    //     0x5dfefc: blr             lr
    // 0x5dff00: add             SP, SP, #8
    // 0x5dff04: ldr             x16, [fp, #0x10]
    // 0x5dff08: SaveReg r16
    //     0x5dff08: str             x16, [SP, #-8]!
    // 0x5dff0c: r0 = markNeedsSemanticsUpdate()
    //     0x5dff0c: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x5dff10: add             SP, SP, #8
    // 0x5dff14: ldr             x1, [fp, #0x10]
    // 0x5dff18: b               #0x5dff4c
    // 0x5dff1c: sub             SP, fp, #0x40
    // 0x5dff20: mov             x16, x1
    // 0x5dff24: mov             x1, x0
    // 0x5dff28: mov             x0, x16
    // 0x5dff2c: ldr             x16, [fp, #0x10]
    // 0x5dff30: r30 = "performLayout"
    //     0x5dff30: ldr             lr, [PP, #0x4b50]  ; [pp+0x4b50] "performLayout"
    // 0x5dff34: stp             lr, x16, [SP, #-0x10]!
    // 0x5dff38: stp             x0, x1, [SP, #-0x10]!
    // 0x5dff3c: r0 = _reportException()
    //     0x5dff3c: bl              #0x5df13c  ; [package:flutter/src/rendering/object.dart] RenderObject::_reportException
    // 0x5dff40: add             SP, SP, #0x20
    // 0x5dff44: ldr             x0, [fp, #0x10]
    // 0x5dff48: mov             x1, x0
    // 0x5dff4c: r0 = false
    //     0x5dff4c: add             x0, NULL, #0x30  ; false
    // 0x5dff50: StoreField: r1->field_1b = r0
    //     0x5dff50: stur            w0, [x1, #0x1b]
    // 0x5dff54: r0 = LoadClassIdInstr(r1)
    //     0x5dff54: ldur            x0, [x1, #-1]
    //     0x5dff58: ubfx            x0, x0, #0xc, #0x14
    // 0x5dff5c: SaveReg r1
    //     0x5dff5c: str             x1, [SP, #-8]!
    // 0x5dff60: r0 = GDT[cid_x0 + 0xd3b6]()
    //     0x5dff60: mov             x17, #0xd3b6
    //     0x5dff64: add             lr, x0, x17
    //     0x5dff68: ldr             lr, [x21, lr, lsl #3]
    //     0x5dff6c: blr             lr
    // 0x5dff70: add             SP, SP, #8
    // 0x5dff74: r0 = Null
    //     0x5dff74: mov             x0, NULL
    // 0x5dff78: LeaveFrame
    //     0x5dff78: mov             SP, fp
    //     0x5dff7c: ldp             fp, lr, [SP], #0x10
    // 0x5dff80: ret
    //     0x5dff80: ret             
    // 0x5dff84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5dff84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5dff88: b               #0x5dfee0
  }
  _ replaceRootLayer(/* No info */) {
    // ** addr: 0x5e1c24, size: 0x9c
    // 0x5e1c24: EnterFrame
    //     0x5e1c24: stp             fp, lr, [SP, #-0x10]!
    //     0x5e1c28: mov             fp, SP
    // 0x5e1c2c: AllocStack(0x8)
    //     0x5e1c2c: sub             SP, SP, #8
    // 0x5e1c30: CheckStackOverflow
    //     0x5e1c30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e1c34: cmp             SP, x16
    //     0x5e1c38: b.ls            #0x5e1cb4
    // 0x5e1c3c: ldr             x1, [fp, #0x18]
    // 0x5e1c40: LoadField: r2 = r1->field_2f
    //     0x5e1c40: ldur            w2, [x1, #0x2f]
    // 0x5e1c44: DecompressPointer r2
    //     0x5e1c44: add             x2, x2, HEAP, lsl #32
    // 0x5e1c48: stur            x2, [fp, #-8]
    // 0x5e1c4c: LoadField: r0 = r2->field_b
    //     0x5e1c4c: ldur            w0, [x2, #0xb]
    // 0x5e1c50: DecompressPointer r0
    //     0x5e1c50: add             x0, x0, HEAP, lsl #32
    // 0x5e1c54: cmp             w0, NULL
    // 0x5e1c58: b.eq            #0x5e1cbc
    // 0x5e1c5c: r3 = LoadClassIdInstr(r0)
    //     0x5e1c5c: ldur            x3, [x0, #-1]
    //     0x5e1c60: ubfx            x3, x3, #0xc, #0x14
    // 0x5e1c64: SaveReg r0
    //     0x5e1c64: str             x0, [SP, #-8]!
    // 0x5e1c68: mov             x0, x3
    // 0x5e1c6c: r0 = GDT[cid_x0 + 0xa3cc]()
    //     0x5e1c6c: mov             x17, #0xa3cc
    //     0x5e1c70: add             lr, x0, x17
    //     0x5e1c74: ldr             lr, [x21, lr, lsl #3]
    //     0x5e1c78: blr             lr
    // 0x5e1c7c: add             SP, SP, #8
    // 0x5e1c80: ldur            x16, [fp, #-8]
    // 0x5e1c84: ldr             lr, [fp, #0x10]
    // 0x5e1c88: stp             lr, x16, [SP, #-0x10]!
    // 0x5e1c8c: r0 = layer=()
    //     0x5e1c8c: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x5e1c90: add             SP, SP, #0x10
    // 0x5e1c94: ldr             x16, [fp, #0x18]
    // 0x5e1c98: SaveReg r16
    //     0x5e1c98: str             x16, [SP, #-8]!
    // 0x5e1c9c: r0 = markNeedsPaint()
    //     0x5e1c9c: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x5e1ca0: add             SP, SP, #8
    // 0x5e1ca4: r0 = Null
    //     0x5e1ca4: mov             x0, NULL
    // 0x5e1ca8: LeaveFrame
    //     0x5e1ca8: mov             SP, fp
    //     0x5e1cac: ldp             fp, lr, [SP], #0x10
    // 0x5e1cb0: ret
    //     0x5e1cb0: ret             
    // 0x5e1cb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e1cb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e1cb8: b               #0x5e1c3c
    // 0x5e1cbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5e1cbc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ scheduleInitialSemantics(/* No info */) {
    // ** addr: 0x5e2080, size: 0xf4
    // 0x5e2080: EnterFrame
    //     0x5e2080: stp             fp, lr, [SP, #-0x10]!
    //     0x5e2084: mov             fp, SP
    // 0x5e2088: AllocStack(0x8)
    //     0x5e2088: sub             SP, SP, #8
    // 0x5e208c: CheckStackOverflow
    //     0x5e208c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e2090: cmp             SP, x16
    //     0x5e2094: b.ls            #0x5e2164
    // 0x5e2098: ldr             x3, [fp, #0x10]
    // 0x5e209c: LoadField: r4 = r3->field_f
    //     0x5e209c: ldur            w4, [x3, #0xf]
    // 0x5e20a0: DecompressPointer r4
    //     0x5e20a0: add             x4, x4, HEAP, lsl #32
    // 0x5e20a4: mov             x0, x4
    // 0x5e20a8: stur            x4, [fp, #-8]
    // 0x5e20ac: r2 = Null
    //     0x5e20ac: mov             x2, NULL
    // 0x5e20b0: r1 = Null
    //     0x5e20b0: mov             x1, NULL
    // 0x5e20b4: r4 = 59
    //     0x5e20b4: mov             x4, #0x3b
    // 0x5e20b8: branchIfSmi(r0, 0x5e20c4)
    //     0x5e20b8: tbz             w0, #0, #0x5e20c4
    // 0x5e20bc: r4 = LoadClassIdInstr(r0)
    //     0x5e20bc: ldur            x4, [x0, #-1]
    //     0x5e20c0: ubfx            x4, x4, #0xc, #0x14
    // 0x5e20c4: cmp             x4, #0x7e6
    // 0x5e20c8: b.eq            #0x5e20d8
    // 0x5e20cc: r8 = PipelineOwner?
    //     0x5e20cc: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x5e20d0: r3 = Null
    //     0x5e20d0: ldr             x3, [PP, #0x4ce0]  ; [pp+0x4ce0] Null
    // 0x5e20d4: r0 = DefaultNullableTypeTest()
    //     0x5e20d4: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x5e20d8: ldur            x0, [fp, #-8]
    // 0x5e20dc: cmp             w0, NULL
    // 0x5e20e0: b.eq            #0x5e216c
    // 0x5e20e4: LoadField: r1 = r0->field_37
    //     0x5e20e4: ldur            w1, [x0, #0x37]
    // 0x5e20e8: DecompressPointer r1
    //     0x5e20e8: add             x1, x1, HEAP, lsl #32
    // 0x5e20ec: ldr             x16, [fp, #0x10]
    // 0x5e20f0: stp             x16, x1, [SP, #-0x10]!
    // 0x5e20f4: r0 = add()
    //     0x5e20f4: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x5e20f8: add             SP, SP, #0x10
    // 0x5e20fc: ldr             x0, [fp, #0x10]
    // 0x5e2100: LoadField: r3 = r0->field_f
    //     0x5e2100: ldur            w3, [x0, #0xf]
    // 0x5e2104: DecompressPointer r3
    //     0x5e2104: add             x3, x3, HEAP, lsl #32
    // 0x5e2108: mov             x0, x3
    // 0x5e210c: stur            x3, [fp, #-8]
    // 0x5e2110: r2 = Null
    //     0x5e2110: mov             x2, NULL
    // 0x5e2114: r1 = Null
    //     0x5e2114: mov             x1, NULL
    // 0x5e2118: r4 = 59
    //     0x5e2118: mov             x4, #0x3b
    // 0x5e211c: branchIfSmi(r0, 0x5e2128)
    //     0x5e211c: tbz             w0, #0, #0x5e2128
    // 0x5e2120: r4 = LoadClassIdInstr(r0)
    //     0x5e2120: ldur            x4, [x0, #-1]
    //     0x5e2124: ubfx            x4, x4, #0xc, #0x14
    // 0x5e2128: cmp             x4, #0x7e6
    // 0x5e212c: b.eq            #0x5e213c
    // 0x5e2130: r8 = PipelineOwner?
    //     0x5e2130: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x5e2134: r3 = Null
    //     0x5e2134: ldr             x3, [PP, #0x4cf0]  ; [pp+0x4cf0] Null
    // 0x5e2138: r0 = DefaultNullableTypeTest()
    //     0x5e2138: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x5e213c: ldur            x0, [fp, #-8]
    // 0x5e2140: cmp             w0, NULL
    // 0x5e2144: b.eq            #0x5e2170
    // 0x5e2148: SaveReg r0
    //     0x5e2148: str             x0, [SP, #-8]!
    // 0x5e214c: r0 = requestVisualUpdate()
    //     0x5e214c: bl              #0x50fd88  ; [package:flutter/src/rendering/object.dart] PipelineOwner::requestVisualUpdate
    // 0x5e2150: add             SP, SP, #8
    // 0x5e2154: r0 = Null
    //     0x5e2154: mov             x0, NULL
    // 0x5e2158: LeaveFrame
    //     0x5e2158: mov             SP, fp
    //     0x5e215c: ldp             fp, lr, [SP], #0x10
    // 0x5e2160: ret
    //     0x5e2160: ret             
    // 0x5e2164: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e2164: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e2168: b               #0x5e2098
    // 0x5e216c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5e216c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5e2170: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5e2170: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dropChild(/* No info */) {
    // ** addr: 0x5e5aec, size: 0x108
    // 0x5e5aec: EnterFrame
    //     0x5e5aec: stp             fp, lr, [SP, #-0x10]!
    //     0x5e5af0: mov             fp, SP
    // 0x5e5af4: CheckStackOverflow
    //     0x5e5af4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e5af8: cmp             SP, x16
    //     0x5e5afc: b.ls            #0x5e5be8
    // 0x5e5b00: ldr             x0, [fp, #0x10]
    // 0x5e5b04: r2 = Null
    //     0x5e5b04: mov             x2, NULL
    // 0x5e5b08: r1 = Null
    //     0x5e5b08: mov             x1, NULL
    // 0x5e5b0c: r4 = 59
    //     0x5e5b0c: mov             x4, #0x3b
    // 0x5e5b10: branchIfSmi(r0, 0x5e5b1c)
    //     0x5e5b10: tbz             w0, #0, #0x5e5b1c
    // 0x5e5b14: r4 = LoadClassIdInstr(r0)
    //     0x5e5b14: ldur            x4, [x0, #-1]
    //     0x5e5b18: ubfx            x4, x4, #0xc, #0x14
    // 0x5e5b1c: sub             x4, x4, #0x961
    // 0x5e5b20: cmp             x4, #0xbe
    // 0x5e5b24: b.ls            #0x5e5b34
    // 0x5e5b28: r8 = RenderObject
    //     0x5e5b28: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x5e5b2c: r3 = Null
    //     0x5e5b2c: ldr             x3, [PP, #0x4e00]  ; [pp+0x4e00] Null
    // 0x5e5b30: r0 = RenderObject()
    //     0x5e5b30: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x5e5b34: ldr             x16, [fp, #0x10]
    // 0x5e5b38: SaveReg r16
    //     0x5e5b38: str             x16, [SP, #-8]!
    // 0x5e5b3c: r0 = _cleanRelayoutBoundary()
    //     0x5e5b3c: bl              #0x5e5ed0  ; [package:flutter/src/rendering/object.dart] RenderObject::_cleanRelayoutBoundary
    // 0x5e5b40: add             SP, SP, #8
    // 0x5e5b44: ldr             x1, [fp, #0x10]
    // 0x5e5b48: LoadField: r0 = r1->field_17
    //     0x5e5b48: ldur            w0, [x1, #0x17]
    // 0x5e5b4c: DecompressPointer r0
    //     0x5e5b4c: add             x0, x0, HEAP, lsl #32
    // 0x5e5b50: cmp             w0, NULL
    // 0x5e5b54: b.eq            #0x5e5bf0
    // 0x5e5b58: r2 = LoadClassIdInstr(r0)
    //     0x5e5b58: ldur            x2, [x0, #-1]
    //     0x5e5b5c: ubfx            x2, x2, #0xc, #0x14
    // 0x5e5b60: SaveReg r0
    //     0x5e5b60: str             x0, [SP, #-8]!
    // 0x5e5b64: mov             x0, x2
    // 0x5e5b68: r0 = GDT[cid_x0 + 0x1c36]()
    //     0x5e5b68: mov             x17, #0x1c36
    //     0x5e5b6c: add             lr, x0, x17
    //     0x5e5b70: ldr             lr, [x21, lr, lsl #3]
    //     0x5e5b74: blr             lr
    // 0x5e5b78: add             SP, SP, #8
    // 0x5e5b7c: ldr             x0, [fp, #0x10]
    // 0x5e5b80: StoreField: r0->field_17 = rNULL
    //     0x5e5b80: stur            NULL, [x0, #0x17]
    // 0x5e5b84: ldr             x16, [fp, #0x18]
    // 0x5e5b88: stp             x0, x16, [SP, #-0x10]!
    // 0x5e5b8c: r0 = dropChild()
    //     0x5e5b8c: bl              #0x5df5b4  ; [package:flutter/src/foundation/node.dart] AbstractNode::dropChild
    // 0x5e5b90: add             SP, SP, #0x10
    // 0x5e5b94: ldr             x1, [fp, #0x18]
    // 0x5e5b98: r0 = LoadClassIdInstr(r1)
    //     0x5e5b98: ldur            x0, [x1, #-1]
    //     0x5e5b9c: ubfx            x0, x0, #0xc, #0x14
    // 0x5e5ba0: SaveReg r1
    //     0x5e5ba0: str             x1, [SP, #-8]!
    // 0x5e5ba4: r0 = GDT[cid_x0 + 0xcfc6]()
    //     0x5e5ba4: mov             x17, #0xcfc6
    //     0x5e5ba8: add             lr, x0, x17
    //     0x5e5bac: ldr             lr, [x21, lr, lsl #3]
    //     0x5e5bb0: blr             lr
    // 0x5e5bb4: add             SP, SP, #8
    // 0x5e5bb8: ldr             x16, [fp, #0x18]
    // 0x5e5bbc: SaveReg r16
    //     0x5e5bbc: str             x16, [SP, #-8]!
    // 0x5e5bc0: r0 = markNeedsCompositingBitsUpdate()
    //     0x5e5bc0: bl              #0x5e5c40  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsCompositingBitsUpdate
    // 0x5e5bc4: add             SP, SP, #8
    // 0x5e5bc8: ldr             x16, [fp, #0x18]
    // 0x5e5bcc: SaveReg r16
    //     0x5e5bcc: str             x16, [SP, #-8]!
    // 0x5e5bd0: r0 = markNeedsSemanticsUpdate()
    //     0x5e5bd0: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x5e5bd4: add             SP, SP, #8
    // 0x5e5bd8: r0 = Null
    //     0x5e5bd8: mov             x0, NULL
    // 0x5e5bdc: LeaveFrame
    //     0x5e5bdc: mov             SP, fp
    //     0x5e5be0: ldp             fp, lr, [SP], #0x10
    // 0x5e5be4: ret
    //     0x5e5be4: ret             
    // 0x5e5be8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e5be8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e5bec: b               #0x5e5b00
    // 0x5e5bf0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5e5bf0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void dropChild(dynamic, Object?) {
    // ** addr: 0x5e5bf4, size: 0x4c
    // 0x5e5bf4: EnterFrame
    //     0x5e5bf4: stp             fp, lr, [SP, #-0x10]!
    //     0x5e5bf8: mov             fp, SP
    // 0x5e5bfc: ldr             x0, [fp, #0x18]
    // 0x5e5c00: LoadField: r1 = r0->field_17
    //     0x5e5c00: ldur            w1, [x0, #0x17]
    // 0x5e5c04: DecompressPointer r1
    //     0x5e5c04: add             x1, x1, HEAP, lsl #32
    // 0x5e5c08: CheckStackOverflow
    //     0x5e5c08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e5c0c: cmp             SP, x16
    //     0x5e5c10: b.ls            #0x5e5c38
    // 0x5e5c14: LoadField: r0 = r1->field_f
    //     0x5e5c14: ldur            w0, [x1, #0xf]
    // 0x5e5c18: DecompressPointer r0
    //     0x5e5c18: add             x0, x0, HEAP, lsl #32
    // 0x5e5c1c: ldr             x16, [fp, #0x10]
    // 0x5e5c20: stp             x16, x0, [SP, #-0x10]!
    // 0x5e5c24: r0 = dropChild()
    //     0x5e5c24: bl              #0x5e5aec  ; [package:flutter/src/rendering/object.dart] RenderObject::dropChild
    // 0x5e5c28: add             SP, SP, #0x10
    // 0x5e5c2c: LeaveFrame
    //     0x5e5c2c: mov             SP, fp
    //     0x5e5c30: ldp             fp, lr, [SP], #0x10
    // 0x5e5c34: ret
    //     0x5e5c34: ret             
    // 0x5e5c38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e5c38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e5c3c: b               #0x5e5c14
  }
  _ markNeedsCompositingBitsUpdate(/* No info */) {
    // ** addr: 0x5e5c40, size: 0x290
    // 0x5e5c40: EnterFrame
    //     0x5e5c40: stp             fp, lr, [SP, #-0x10]!
    //     0x5e5c44: mov             fp, SP
    // 0x5e5c48: AllocStack(0x10)
    //     0x5e5c48: sub             SP, SP, #0x10
    // 0x5e5c4c: CheckStackOverflow
    //     0x5e5c4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e5c50: cmp             SP, x16
    //     0x5e5c54: b.ls            #0x5e5eb8
    // 0x5e5c58: ldr             x1, [fp, #0x10]
    // 0x5e5c5c: LoadField: r0 = r1->field_33
    //     0x5e5c5c: ldur            w0, [x1, #0x33]
    // 0x5e5c60: DecompressPointer r0
    //     0x5e5c60: add             x0, x0, HEAP, lsl #32
    // 0x5e5c64: tbnz            w0, #4, #0x5e5c78
    // 0x5e5c68: r0 = Null
    //     0x5e5c68: mov             x0, NULL
    // 0x5e5c6c: LeaveFrame
    //     0x5e5c6c: mov             SP, fp
    //     0x5e5c70: ldp             fp, lr, [SP], #0x10
    // 0x5e5c74: ret
    //     0x5e5c74: ret             
    // 0x5e5c78: r0 = true
    //     0x5e5c78: add             x0, NULL, #0x20  ; true
    // 0x5e5c7c: StoreField: r1->field_33 = r0
    //     0x5e5c7c: stur            w0, [x1, #0x33]
    // 0x5e5c80: r0 = LoadClassIdInstr(r1)
    //     0x5e5c80: ldur            x0, [x1, #-1]
    //     0x5e5c84: ubfx            x0, x0, #0xc, #0x14
    // 0x5e5c88: SaveReg r1
    //     0x5e5c88: str             x1, [SP, #-8]!
    // 0x5e5c8c: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0x5e5c8c: mov             x17, #0xa2f1
    //     0x5e5c90: add             lr, x0, x17
    //     0x5e5c94: ldr             lr, [x21, lr, lsl #3]
    //     0x5e5c98: blr             lr
    // 0x5e5c9c: add             SP, SP, #8
    // 0x5e5ca0: r1 = LoadClassIdInstr(r0)
    //     0x5e5ca0: ldur            x1, [x0, #-1]
    //     0x5e5ca4: ubfx            x1, x1, #0xc, #0x14
    // 0x5e5ca8: lsl             x1, x1, #1
    // 0x5e5cac: r0 = LoadInt32Instr(r1)
    //     0x5e5cac: sbfx            x0, x1, #1, #0x1f
    // 0x5e5cb0: cmp             x0, #0x961
    // 0x5e5cb4: b.lt            #0x5e5dc8
    // 0x5e5cb8: cmp             x0, #0xa1f
    // 0x5e5cbc: b.gt            #0x5e5dc8
    // 0x5e5cc0: ldr             x1, [fp, #0x10]
    // 0x5e5cc4: r0 = LoadClassIdInstr(r1)
    //     0x5e5cc4: ldur            x0, [x1, #-1]
    //     0x5e5cc8: ubfx            x0, x0, #0xc, #0x14
    // 0x5e5ccc: SaveReg r1
    //     0x5e5ccc: str             x1, [SP, #-8]!
    // 0x5e5cd0: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0x5e5cd0: mov             x17, #0xa2f1
    //     0x5e5cd4: add             lr, x0, x17
    //     0x5e5cd8: ldr             lr, [x21, lr, lsl #3]
    //     0x5e5cdc: blr             lr
    // 0x5e5ce0: add             SP, SP, #8
    // 0x5e5ce4: mov             x3, x0
    // 0x5e5ce8: stur            x3, [fp, #-8]
    // 0x5e5cec: cmp             w3, NULL
    // 0x5e5cf0: b.eq            #0x5e5ec0
    // 0x5e5cf4: mov             x0, x3
    // 0x5e5cf8: r2 = Null
    //     0x5e5cf8: mov             x2, NULL
    // 0x5e5cfc: r1 = Null
    //     0x5e5cfc: mov             x1, NULL
    // 0x5e5d00: r4 = LoadClassIdInstr(r0)
    //     0x5e5d00: ldur            x4, [x0, #-1]
    //     0x5e5d04: ubfx            x4, x4, #0xc, #0x14
    // 0x5e5d08: sub             x4, x4, #0x961
    // 0x5e5d0c: cmp             x4, #0xbe
    // 0x5e5d10: b.ls            #0x5e5d20
    // 0x5e5d14: r8 = RenderObject
    //     0x5e5d14: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x5e5d18: r3 = Null
    //     0x5e5d18: ldr             x3, [PP, #0x4dc0]  ; [pp+0x4dc0] Null
    // 0x5e5d1c: r0 = RenderObject()
    //     0x5e5d1c: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x5e5d20: ldur            x1, [fp, #-8]
    // 0x5e5d24: LoadField: r0 = r1->field_33
    //     0x5e5d24: ldur            w0, [x1, #0x33]
    // 0x5e5d28: DecompressPointer r0
    //     0x5e5d28: add             x0, x0, HEAP, lsl #32
    // 0x5e5d2c: tbnz            w0, #4, #0x5e5d40
    // 0x5e5d30: r0 = Null
    //     0x5e5d30: mov             x0, NULL
    // 0x5e5d34: LeaveFrame
    //     0x5e5d34: mov             SP, fp
    //     0x5e5d38: ldp             fp, lr, [SP], #0x10
    // 0x5e5d3c: ret
    //     0x5e5d3c: ret             
    // 0x5e5d40: ldr             x2, [fp, #0x10]
    // 0x5e5d44: LoadField: r0 = r2->field_2b
    //     0x5e5d44: ldur            w0, [x2, #0x2b]
    // 0x5e5d48: DecompressPointer r0
    //     0x5e5d48: add             x0, x0, HEAP, lsl #32
    // 0x5e5d4c: r16 = Sentinel
    //     0x5e5d4c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5e5d50: cmp             w0, w16
    // 0x5e5d54: b.eq            #0x5e5ec4
    // 0x5e5d58: tbnz            w0, #4, #0x5e5d84
    // 0x5e5d5c: r0 = LoadClassIdInstr(r2)
    //     0x5e5d5c: ldur            x0, [x2, #-1]
    //     0x5e5d60: ubfx            x0, x0, #0xc, #0x14
    // 0x5e5d64: SaveReg r2
    //     0x5e5d64: str             x2, [SP, #-8]!
    // 0x5e5d68: r0 = GDT[cid_x0 + 0xd14d]()
    //     0x5e5d68: mov             x17, #0xd14d
    //     0x5e5d6c: add             lr, x0, x17
    //     0x5e5d70: ldr             lr, [x21, lr, lsl #3]
    //     0x5e5d74: blr             lr
    // 0x5e5d78: add             SP, SP, #8
    // 0x5e5d7c: tbz             w0, #4, #0x5e5dc8
    // 0x5e5d80: ldur            x1, [fp, #-8]
    // 0x5e5d84: r0 = LoadClassIdInstr(r1)
    //     0x5e5d84: ldur            x0, [x1, #-1]
    //     0x5e5d88: ubfx            x0, x0, #0xc, #0x14
    // 0x5e5d8c: SaveReg r1
    //     0x5e5d8c: str             x1, [SP, #-8]!
    // 0x5e5d90: r0 = GDT[cid_x0 + 0xd14d]()
    //     0x5e5d90: mov             x17, #0xd14d
    //     0x5e5d94: add             lr, x0, x17
    //     0x5e5d98: ldr             lr, [x21, lr, lsl #3]
    //     0x5e5d9c: blr             lr
    // 0x5e5da0: add             SP, SP, #8
    // 0x5e5da4: tbz             w0, #4, #0x5e5dc8
    // 0x5e5da8: ldur            x16, [fp, #-8]
    // 0x5e5dac: SaveReg r16
    //     0x5e5dac: str             x16, [SP, #-8]!
    // 0x5e5db0: r0 = markNeedsCompositingBitsUpdate()
    //     0x5e5db0: bl              #0x5e5c40  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsCompositingBitsUpdate
    // 0x5e5db4: add             SP, SP, #8
    // 0x5e5db8: r0 = Null
    //     0x5e5db8: mov             x0, NULL
    // 0x5e5dbc: LeaveFrame
    //     0x5e5dbc: mov             SP, fp
    //     0x5e5dc0: ldp             fp, lr, [SP], #0x10
    // 0x5e5dc4: ret
    //     0x5e5dc4: ret             
    // 0x5e5dc8: ldr             x3, [fp, #0x10]
    // 0x5e5dcc: LoadField: r4 = r3->field_f
    //     0x5e5dcc: ldur            w4, [x3, #0xf]
    // 0x5e5dd0: DecompressPointer r4
    //     0x5e5dd0: add             x4, x4, HEAP, lsl #32
    // 0x5e5dd4: mov             x0, x4
    // 0x5e5dd8: stur            x4, [fp, #-8]
    // 0x5e5ddc: r2 = Null
    //     0x5e5ddc: mov             x2, NULL
    // 0x5e5de0: r1 = Null
    //     0x5e5de0: mov             x1, NULL
    // 0x5e5de4: r4 = 59
    //     0x5e5de4: mov             x4, #0x3b
    // 0x5e5de8: branchIfSmi(r0, 0x5e5df4)
    //     0x5e5de8: tbz             w0, #0, #0x5e5df4
    // 0x5e5dec: r4 = LoadClassIdInstr(r0)
    //     0x5e5dec: ldur            x4, [x0, #-1]
    //     0x5e5df0: ubfx            x4, x4, #0xc, #0x14
    // 0x5e5df4: cmp             x4, #0x7e6
    // 0x5e5df8: b.eq            #0x5e5e08
    // 0x5e5dfc: r8 = PipelineOwner?
    //     0x5e5dfc: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x5e5e00: r3 = Null
    //     0x5e5e00: ldr             x3, [PP, #0x4dd0]  ; [pp+0x4dd0] Null
    // 0x5e5e04: r0 = DefaultNullableTypeTest()
    //     0x5e5e04: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x5e5e08: ldur            x0, [fp, #-8]
    // 0x5e5e0c: cmp             w0, NULL
    // 0x5e5e10: b.eq            #0x5e5ea8
    // 0x5e5e14: LoadField: r1 = r0->field_23
    //     0x5e5e14: ldur            w1, [x0, #0x23]
    // 0x5e5e18: DecompressPointer r1
    //     0x5e5e18: add             x1, x1, HEAP, lsl #32
    // 0x5e5e1c: stur            x1, [fp, #-0x10]
    // 0x5e5e20: LoadField: r0 = r1->field_b
    //     0x5e5e20: ldur            w0, [x1, #0xb]
    // 0x5e5e24: DecompressPointer r0
    //     0x5e5e24: add             x0, x0, HEAP, lsl #32
    // 0x5e5e28: stur            x0, [fp, #-8]
    // 0x5e5e2c: LoadField: r2 = r1->field_f
    //     0x5e5e2c: ldur            w2, [x1, #0xf]
    // 0x5e5e30: DecompressPointer r2
    //     0x5e5e30: add             x2, x2, HEAP, lsl #32
    // 0x5e5e34: LoadField: r3 = r2->field_b
    //     0x5e5e34: ldur            w3, [x2, #0xb]
    // 0x5e5e38: DecompressPointer r3
    //     0x5e5e38: add             x3, x3, HEAP, lsl #32
    // 0x5e5e3c: cmp             w0, w3
    // 0x5e5e40: b.ne            #0x5e5e50
    // 0x5e5e44: SaveReg r1
    //     0x5e5e44: str             x1, [SP, #-8]!
    // 0x5e5e48: r0 = _growToNextCapacity()
    //     0x5e5e48: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x5e5e4c: add             SP, SP, #8
    // 0x5e5e50: ldur            x2, [fp, #-0x10]
    // 0x5e5e54: ldur            x3, [fp, #-8]
    // 0x5e5e58: r4 = LoadInt32Instr(r3)
    //     0x5e5e58: sbfx            x4, x3, #1, #0x1f
    // 0x5e5e5c: add             x0, x4, #1
    // 0x5e5e60: lsl             x3, x0, #1
    // 0x5e5e64: StoreField: r2->field_b = r3
    //     0x5e5e64: stur            w3, [x2, #0xb]
    // 0x5e5e68: mov             x1, x4
    // 0x5e5e6c: cmp             x1, x0
    // 0x5e5e70: b.hs            #0x5e5ecc
    // 0x5e5e74: LoadField: r1 = r2->field_f
    //     0x5e5e74: ldur            w1, [x2, #0xf]
    // 0x5e5e78: DecompressPointer r1
    //     0x5e5e78: add             x1, x1, HEAP, lsl #32
    // 0x5e5e7c: ldr             x0, [fp, #0x10]
    // 0x5e5e80: ArrayStore: r1[r4] = r0  ; List_4
    //     0x5e5e80: add             x25, x1, x4, lsl #2
    //     0x5e5e84: add             x25, x25, #0xf
    //     0x5e5e88: str             w0, [x25]
    //     0x5e5e8c: tbz             w0, #0, #0x5e5ea8
    //     0x5e5e90: ldurb           w16, [x1, #-1]
    //     0x5e5e94: ldurb           w17, [x0, #-1]
    //     0x5e5e98: and             x16, x17, x16, lsr #2
    //     0x5e5e9c: tst             x16, HEAP, lsr #32
    //     0x5e5ea0: b.eq            #0x5e5ea8
    //     0x5e5ea4: bl              #0xd67e5c
    // 0x5e5ea8: r0 = Null
    //     0x5e5ea8: mov             x0, NULL
    // 0x5e5eac: LeaveFrame
    //     0x5e5eac: mov             SP, fp
    //     0x5e5eb0: ldp             fp, lr, [SP], #0x10
    // 0x5e5eb4: ret
    //     0x5e5eb4: ret             
    // 0x5e5eb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e5eb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e5ebc: b               #0x5e5c58
    // 0x5e5ec0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5e5ec0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5e5ec4: r9 = _wasRepaintBoundary
    //     0x5e5ec4: ldr             x9, [PP, #0x4b30]  ; [pp+0x4b30] Field <RenderObject._wasRepaintBoundary@904266271>: late (offset: 0x2c)
    // 0x5e5ec8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x5e5ec8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x5e5ecc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5e5ecc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _cleanRelayoutBoundary(/* No info */) {
    // ** addr: 0x5e5ed0, size: 0x8c
    // 0x5e5ed0: EnterFrame
    //     0x5e5ed0: stp             fp, lr, [SP, #-0x10]!
    //     0x5e5ed4: mov             fp, SP
    // 0x5e5ed8: CheckStackOverflow
    //     0x5e5ed8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e5edc: cmp             SP, x16
    //     0x5e5ee0: b.ls            #0x5e5f54
    // 0x5e5ee4: ldr             x1, [fp, #0x10]
    // 0x5e5ee8: LoadField: r0 = r1->field_1f
    //     0x5e5ee8: ldur            w0, [x1, #0x1f]
    // 0x5e5eec: DecompressPointer r0
    //     0x5e5eec: add             x0, x0, HEAP, lsl #32
    // 0x5e5ef0: r2 = LoadClassIdInstr(r0)
    //     0x5e5ef0: ldur            x2, [x0, #-1]
    //     0x5e5ef4: ubfx            x2, x2, #0xc, #0x14
    // 0x5e5ef8: stp             x1, x0, [SP, #-0x10]!
    // 0x5e5efc: mov             x0, x2
    // 0x5e5f00: mov             lr, x0
    // 0x5e5f04: ldr             lr, [x21, lr, lsl #3]
    // 0x5e5f08: blr             lr
    // 0x5e5f0c: add             SP, SP, #0x10
    // 0x5e5f10: tbz             w0, #4, #0x5e5f44
    // 0x5e5f14: ldr             x0, [fp, #0x10]
    // 0x5e5f18: StoreField: r0->field_1f = rNULL
    //     0x5e5f18: stur            NULL, [x0, #0x1f]
    // 0x5e5f1c: r1 = LoadClassIdInstr(r0)
    //     0x5e5f1c: ldur            x1, [x0, #-1]
    //     0x5e5f20: ubfx            x1, x1, #0xc, #0x14
    // 0x5e5f24: r16 = Closure: (RenderObject) => void from Function '_cleanChildRelayoutBoundary@904266271': static.
    //     0x5e5f24: ldr             x16, [PP, #0x4e10]  ; [pp+0x4e10] Closure: (RenderObject) => void from Function '_cleanChildRelayoutBoundary@904266271': static. (0x7fe6e1de5f5c)
    // 0x5e5f28: stp             x16, x0, [SP, #-0x10]!
    // 0x5e5f2c: mov             x0, x1
    // 0x5e5f30: r0 = GDT[cid_x0 + 0xd2d5]()
    //     0x5e5f30: mov             x17, #0xd2d5
    //     0x5e5f34: add             lr, x0, x17
    //     0x5e5f38: ldr             lr, [x21, lr, lsl #3]
    //     0x5e5f3c: blr             lr
    // 0x5e5f40: add             SP, SP, #0x10
    // 0x5e5f44: r0 = Null
    //     0x5e5f44: mov             x0, NULL
    // 0x5e5f48: LeaveFrame
    //     0x5e5f48: mov             SP, fp
    //     0x5e5f4c: ldp             fp, lr, [SP], #0x10
    // 0x5e5f50: ret
    //     0x5e5f50: ret             
    // 0x5e5f54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e5f54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e5f58: b               #0x5e5ee4
  }
  [closure] static void _cleanChildRelayoutBoundary(dynamic, RenderObject) {
    // ** addr: 0x5e5f5c, size: 0x3c
    // 0x5e5f5c: EnterFrame
    //     0x5e5f5c: stp             fp, lr, [SP, #-0x10]!
    //     0x5e5f60: mov             fp, SP
    // 0x5e5f64: CheckStackOverflow
    //     0x5e5f64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e5f68: cmp             SP, x16
    //     0x5e5f6c: b.ls            #0x5e5f90
    // 0x5e5f70: ldr             x16, [fp, #0x10]
    // 0x5e5f74: SaveReg r16
    //     0x5e5f74: str             x16, [SP, #-8]!
    // 0x5e5f78: r0 = _cleanRelayoutBoundary()
    //     0x5e5f78: bl              #0x5e5ed0  ; [package:flutter/src/rendering/object.dart] RenderObject::_cleanRelayoutBoundary
    // 0x5e5f7c: add             SP, SP, #8
    // 0x5e5f80: r0 = Null
    //     0x5e5f80: mov             x0, NULL
    // 0x5e5f84: LeaveFrame
    //     0x5e5f84: mov             SP, fp
    //     0x5e5f88: ldp             fp, lr, [SP], #0x10
    // 0x5e5f8c: ret
    //     0x5e5f8c: ret             
    // 0x5e5f90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e5f90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e5f94: b               #0x5e5f70
  }
  _ adoptChild(/* No info */) {
    // ** addr: 0x5e61d4, size: 0xac
    // 0x5e61d4: EnterFrame
    //     0x5e61d4: stp             fp, lr, [SP, #-0x10]!
    //     0x5e61d8: mov             fp, SP
    // 0x5e61dc: CheckStackOverflow
    //     0x5e61dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e61e0: cmp             SP, x16
    //     0x5e61e4: b.ls            #0x5e6278
    // 0x5e61e8: ldr             x1, [fp, #0x18]
    // 0x5e61ec: r0 = LoadClassIdInstr(r1)
    //     0x5e61ec: ldur            x0, [x1, #-1]
    //     0x5e61f0: ubfx            x0, x0, #0xc, #0x14
    // 0x5e61f4: ldr             x16, [fp, #0x10]
    // 0x5e61f8: stp             x16, x1, [SP, #-0x10]!
    // 0x5e61fc: r0 = GDT[cid_x0 + 0xe8f1]()
    //     0x5e61fc: mov             x17, #0xe8f1
    //     0x5e6200: add             lr, x0, x17
    //     0x5e6204: ldr             lr, [x21, lr, lsl #3]
    //     0x5e6208: blr             lr
    // 0x5e620c: add             SP, SP, #0x10
    // 0x5e6210: ldr             x1, [fp, #0x18]
    // 0x5e6214: r0 = LoadClassIdInstr(r1)
    //     0x5e6214: ldur            x0, [x1, #-1]
    //     0x5e6218: ubfx            x0, x0, #0xc, #0x14
    // 0x5e621c: SaveReg r1
    //     0x5e621c: str             x1, [SP, #-8]!
    // 0x5e6220: r0 = GDT[cid_x0 + 0xcfc6]()
    //     0x5e6220: mov             x17, #0xcfc6
    //     0x5e6224: add             lr, x0, x17
    //     0x5e6228: ldr             lr, [x21, lr, lsl #3]
    //     0x5e622c: blr             lr
    // 0x5e6230: add             SP, SP, #8
    // 0x5e6234: ldr             x16, [fp, #0x18]
    // 0x5e6238: SaveReg r16
    //     0x5e6238: str             x16, [SP, #-8]!
    // 0x5e623c: r0 = markNeedsCompositingBitsUpdate()
    //     0x5e623c: bl              #0x5e5c40  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsCompositingBitsUpdate
    // 0x5e6240: add             SP, SP, #8
    // 0x5e6244: ldr             x16, [fp, #0x18]
    // 0x5e6248: SaveReg r16
    //     0x5e6248: str             x16, [SP, #-8]!
    // 0x5e624c: r0 = markNeedsSemanticsUpdate()
    //     0x5e624c: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x5e6250: add             SP, SP, #8
    // 0x5e6254: ldr             x16, [fp, #0x18]
    // 0x5e6258: ldr             lr, [fp, #0x10]
    // 0x5e625c: stp             lr, x16, [SP, #-0x10]!
    // 0x5e6260: r0 = adoptChild()
    //     0x5e6260: bl              #0x5e6280  ; [package:flutter/src/foundation/node.dart] AbstractNode::adoptChild
    // 0x5e6264: add             SP, SP, #0x10
    // 0x5e6268: r0 = Null
    //     0x5e6268: mov             x0, NULL
    // 0x5e626c: LeaveFrame
    //     0x5e626c: mov             SP, fp
    //     0x5e6270: ldp             fp, lr, [SP], #0x10
    // 0x5e6274: ret
    //     0x5e6274: ret             
    // 0x5e6278: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e6278: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e627c: b               #0x5e61e8
  }
  _ reassemble(/* No info */) {
    // ** addr: 0x6418b0, size: 0xd0
    // 0x6418b0: EnterFrame
    //     0x6418b0: stp             fp, lr, [SP, #-0x10]!
    //     0x6418b4: mov             fp, SP
    // 0x6418b8: CheckStackOverflow
    //     0x6418b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6418bc: cmp             SP, x16
    //     0x6418c0: b.ls            #0x641978
    // 0x6418c4: ldr             x1, [fp, #0x10]
    // 0x6418c8: r0 = LoadClassIdInstr(r1)
    //     0x6418c8: ldur            x0, [x1, #-1]
    //     0x6418cc: ubfx            x0, x0, #0xc, #0x14
    // 0x6418d0: SaveReg r1
    //     0x6418d0: str             x1, [SP, #-8]!
    // 0x6418d4: r0 = GDT[cid_x0 + 0xcfc6]()
    //     0x6418d4: mov             x17, #0xcfc6
    //     0x6418d8: add             lr, x0, x17
    //     0x6418dc: ldr             lr, [x21, lr, lsl #3]
    //     0x6418e0: blr             lr
    // 0x6418e4: add             SP, SP, #8
    // 0x6418e8: ldr             x16, [fp, #0x10]
    // 0x6418ec: SaveReg r16
    //     0x6418ec: str             x16, [SP, #-8]!
    // 0x6418f0: r0 = markNeedsCompositingBitsUpdate()
    //     0x6418f0: bl              #0x5e5c40  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsCompositingBitsUpdate
    // 0x6418f4: add             SP, SP, #8
    // 0x6418f8: ldr             x1, [fp, #0x10]
    // 0x6418fc: r0 = LoadClassIdInstr(r1)
    //     0x6418fc: ldur            x0, [x1, #-1]
    //     0x641900: ubfx            x0, x0, #0xc, #0x14
    // 0x641904: SaveReg r1
    //     0x641904: str             x1, [SP, #-8]!
    // 0x641908: r0 = GDT[cid_x0 + 0xd3b6]()
    //     0x641908: mov             x17, #0xd3b6
    //     0x64190c: add             lr, x0, x17
    //     0x641910: ldr             lr, [x21, lr, lsl #3]
    //     0x641914: blr             lr
    // 0x641918: add             SP, SP, #8
    // 0x64191c: ldr             x16, [fp, #0x10]
    // 0x641920: SaveReg r16
    //     0x641920: str             x16, [SP, #-8]!
    // 0x641924: r0 = markNeedsSemanticsUpdate()
    //     0x641924: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x641928: add             SP, SP, #8
    // 0x64192c: r1 = Function '<anonymous closure>':.
    //     0x64192c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd840] AnonymousClosure: (0x641980), in [package:flutter/src/rendering/object.dart] RenderObject::reassemble (0x6418b0)
    //     0x641930: ldr             x1, [x1, #0x840]
    // 0x641934: r2 = Null
    //     0x641934: mov             x2, NULL
    // 0x641938: r0 = AllocateClosure()
    //     0x641938: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x64193c: mov             x1, x0
    // 0x641940: ldr             x0, [fp, #0x10]
    // 0x641944: r2 = LoadClassIdInstr(r0)
    //     0x641944: ldur            x2, [x0, #-1]
    //     0x641948: ubfx            x2, x2, #0xc, #0x14
    // 0x64194c: stp             x1, x0, [SP, #-0x10]!
    // 0x641950: mov             x0, x2
    // 0x641954: r0 = GDT[cid_x0 + 0xd2d5]()
    //     0x641954: mov             x17, #0xd2d5
    //     0x641958: add             lr, x0, x17
    //     0x64195c: ldr             lr, [x21, lr, lsl #3]
    //     0x641960: blr             lr
    // 0x641964: add             SP, SP, #0x10
    // 0x641968: r0 = Null
    //     0x641968: mov             x0, NULL
    // 0x64196c: LeaveFrame
    //     0x64196c: mov             SP, fp
    //     0x641970: ldp             fp, lr, [SP], #0x10
    // 0x641974: ret
    //     0x641974: ret             
    // 0x641978: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x641978: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64197c: b               #0x6418c4
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0x641980, size: 0x54
    // 0x641980: EnterFrame
    //     0x641980: stp             fp, lr, [SP, #-0x10]!
    //     0x641984: mov             fp, SP
    // 0x641988: CheckStackOverflow
    //     0x641988: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64198c: cmp             SP, x16
    //     0x641990: b.ls            #0x6419cc
    // 0x641994: ldr             x0, [fp, #0x10]
    // 0x641998: r1 = LoadClassIdInstr(r0)
    //     0x641998: ldur            x1, [x0, #-1]
    //     0x64199c: ubfx            x1, x1, #0xc, #0x14
    // 0x6419a0: SaveReg r0
    //     0x6419a0: str             x0, [SP, #-8]!
    // 0x6419a4: mov             x0, x1
    // 0x6419a8: r0 = GDT[cid_x0 + 0xed6b]()
    //     0x6419a8: mov             x17, #0xed6b
    //     0x6419ac: add             lr, x0, x17
    //     0x6419b0: ldr             lr, [x21, lr, lsl #3]
    //     0x6419b4: blr             lr
    // 0x6419b8: add             SP, SP, #8
    // 0x6419bc: r0 = Null
    //     0x6419bc: mov             x0, NULL
    // 0x6419c0: LeaveFrame
    //     0x6419c0: mov             SP, fp
    //     0x6419c4: ldp             fp, lr, [SP], #0x10
    // 0x6419c8: ret
    //     0x6419c8: ret             
    // 0x6419cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6419cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6419d0: b               #0x641994
  }
  get _ constraints(/* No info */) {
    // ** addr: 0x641ad0, size: 0x4c
    // 0x641ad0: EnterFrame
    //     0x641ad0: stp             fp, lr, [SP, #-0x10]!
    //     0x641ad4: mov             fp, SP
    // 0x641ad8: ldr             x0, [fp, #0x10]
    // 0x641adc: LoadField: r1 = r0->field_27
    //     0x641adc: ldur            w1, [x0, #0x27]
    // 0x641ae0: DecompressPointer r1
    //     0x641ae0: add             x1, x1, HEAP, lsl #32
    // 0x641ae4: cmp             w1, NULL
    // 0x641ae8: b.eq            #0x641afc
    // 0x641aec: mov             x0, x1
    // 0x641af0: LeaveFrame
    //     0x641af0: mov             SP, fp
    //     0x641af4: ldp             fp, lr, [SP], #0x10
    // 0x641af8: ret
    //     0x641af8: ret             
    // 0x641afc: r0 = StateError()
    //     0x641afc: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x641b00: mov             x1, x0
    // 0x641b04: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x641b04: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x641b08: ldr             x0, [x0, #0x1e8]
    // 0x641b0c: StoreField: r1->field_b = r0
    //     0x641b0c: stur            w0, [x1, #0xb]
    // 0x641b10: mov             x0, x1
    // 0x641b14: r0 = Throw()
    //     0x641b14: bl              #0xd67e38  ; ThrowStub
    // 0x641b18: brk             #0
  }
  _ getTransformTo(/* No info */) {
    // ** addr: 0x643bcc, size: 0x398
    // 0x643bcc: EnterFrame
    //     0x643bcc: stp             fp, lr, [SP, #-0x10]!
    //     0x643bd0: mov             fp, SP
    // 0x643bd4: AllocStack(0x28)
    //     0x643bd4: sub             SP, SP, #0x28
    // 0x643bd8: CheckStackOverflow
    //     0x643bd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x643bdc: cmp             SP, x16
    //     0x643be0: b.ls            #0x643f30
    // 0x643be4: ldr             x3, [fp, #0x10]
    // 0x643be8: cmp             w3, NULL
    // 0x643bec: b.ne            #0x643c60
    // 0x643bf0: ldr             x4, [fp, #0x18]
    // 0x643bf4: LoadField: r5 = r4->field_f
    //     0x643bf4: ldur            w5, [x4, #0xf]
    // 0x643bf8: DecompressPointer r5
    //     0x643bf8: add             x5, x5, HEAP, lsl #32
    // 0x643bfc: mov             x0, x5
    // 0x643c00: stur            x5, [fp, #-8]
    // 0x643c04: r2 = Null
    //     0x643c04: mov             x2, NULL
    // 0x643c08: r1 = Null
    //     0x643c08: mov             x1, NULL
    // 0x643c0c: r4 = 59
    //     0x643c0c: mov             x4, #0x3b
    // 0x643c10: branchIfSmi(r0, 0x643c1c)
    //     0x643c10: tbz             w0, #0, #0x643c1c
    // 0x643c14: r4 = LoadClassIdInstr(r0)
    //     0x643c14: ldur            x4, [x0, #-1]
    //     0x643c18: ubfx            x4, x4, #0xc, #0x14
    // 0x643c1c: cmp             x4, #0x7e6
    // 0x643c20: b.eq            #0x643c34
    // 0x643c24: r8 = PipelineOwner?
    //     0x643c24: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x643c28: r3 = Null
    //     0x643c28: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1ca30] Null
    //     0x643c2c: ldr             x3, [x3, #0xa30]
    // 0x643c30: r0 = DefaultNullableTypeTest()
    //     0x643c30: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x643c34: ldur            x0, [fp, #-8]
    // 0x643c38: cmp             w0, NULL
    // 0x643c3c: b.eq            #0x643f38
    // 0x643c40: LoadField: r1 = r0->field_17
    //     0x643c40: ldur            w1, [x0, #0x17]
    // 0x643c44: DecompressPointer r1
    //     0x643c44: add             x1, x1, HEAP, lsl #32
    // 0x643c48: cmp             w1, NULL
    // 0x643c4c: b.eq            #0x643c58
    // 0x643c50: mov             x0, x1
    // 0x643c54: b               #0x643c64
    // 0x643c58: ldr             x0, [fp, #0x10]
    // 0x643c5c: b               #0x643c64
    // 0x643c60: ldr             x0, [fp, #0x10]
    // 0x643c64: stur            x0, [fp, #-8]
    // 0x643c68: r16 = <RenderObject>
    //     0x643c68: ldr             x16, [PP, #0x4988]  ; [pp+0x4988] TypeArguments: <RenderObject>
    // 0x643c6c: stp             xzr, x16, [SP, #-0x10]!
    // 0x643c70: r0 = _GrowableList()
    //     0x643c70: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x643c74: add             SP, SP, #0x10
    // 0x643c78: stur            x0, [fp, #-0x20]
    // 0x643c7c: ldr             x2, [fp, #0x18]
    // 0x643c80: ldur            x1, [fp, #-8]
    // 0x643c84: stur            x2, [fp, #-0x18]
    // 0x643c88: CheckStackOverflow
    //     0x643c88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x643c8c: cmp             SP, x16
    //     0x643c90: b.ls            #0x643f3c
    // 0x643c94: cmp             w2, w1
    // 0x643c98: b.eq            #0x643d94
    // 0x643c9c: LoadField: r3 = r0->field_b
    //     0x643c9c: ldur            w3, [x0, #0xb]
    // 0x643ca0: DecompressPointer r3
    //     0x643ca0: add             x3, x3, HEAP, lsl #32
    // 0x643ca4: stur            x3, [fp, #-0x10]
    // 0x643ca8: LoadField: r4 = r0->field_f
    //     0x643ca8: ldur            w4, [x0, #0xf]
    // 0x643cac: DecompressPointer r4
    //     0x643cac: add             x4, x4, HEAP, lsl #32
    // 0x643cb0: LoadField: r5 = r4->field_b
    //     0x643cb0: ldur            w5, [x4, #0xb]
    // 0x643cb4: DecompressPointer r5
    //     0x643cb4: add             x5, x5, HEAP, lsl #32
    // 0x643cb8: cmp             w3, w5
    // 0x643cbc: b.ne            #0x643ccc
    // 0x643cc0: SaveReg r0
    //     0x643cc0: str             x0, [SP, #-8]!
    // 0x643cc4: r0 = _growToNextCapacity()
    //     0x643cc4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x643cc8: add             SP, SP, #8
    // 0x643ccc: ldur            x2, [fp, #-0x20]
    // 0x643cd0: ldur            x3, [fp, #-0x18]
    // 0x643cd4: ldur            x0, [fp, #-0x10]
    // 0x643cd8: r4 = LoadInt32Instr(r0)
    //     0x643cd8: sbfx            x4, x0, #1, #0x1f
    // 0x643cdc: add             x0, x4, #1
    // 0x643ce0: lsl             x1, x0, #1
    // 0x643ce4: StoreField: r2->field_b = r1
    //     0x643ce4: stur            w1, [x2, #0xb]
    // 0x643ce8: mov             x1, x4
    // 0x643cec: cmp             x1, x0
    // 0x643cf0: b.hs            #0x643f44
    // 0x643cf4: LoadField: r1 = r2->field_f
    //     0x643cf4: ldur            w1, [x2, #0xf]
    // 0x643cf8: DecompressPointer r1
    //     0x643cf8: add             x1, x1, HEAP, lsl #32
    // 0x643cfc: mov             x0, x3
    // 0x643d00: ArrayStore: r1[r4] = r0  ; List_4
    //     0x643d00: add             x25, x1, x4, lsl #2
    //     0x643d04: add             x25, x25, #0xf
    //     0x643d08: str             w0, [x25]
    //     0x643d0c: tbz             w0, #0, #0x643d28
    //     0x643d10: ldurb           w16, [x1, #-1]
    //     0x643d14: ldurb           w17, [x0, #-1]
    //     0x643d18: and             x16, x17, x16, lsr #2
    //     0x643d1c: tst             x16, HEAP, lsr #32
    //     0x643d20: b.eq            #0x643d28
    //     0x643d24: bl              #0xd67e5c
    // 0x643d28: r0 = LoadClassIdInstr(r3)
    //     0x643d28: ldur            x0, [x3, #-1]
    //     0x643d2c: ubfx            x0, x0, #0xc, #0x14
    // 0x643d30: SaveReg r3
    //     0x643d30: str             x3, [SP, #-8]!
    // 0x643d34: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0x643d34: mov             x17, #0xa2f1
    //     0x643d38: add             lr, x0, x17
    //     0x643d3c: ldr             lr, [x21, lr, lsl #3]
    //     0x643d40: blr             lr
    // 0x643d44: add             SP, SP, #8
    // 0x643d48: mov             x3, x0
    // 0x643d4c: stur            x3, [fp, #-0x10]
    // 0x643d50: cmp             w3, NULL
    // 0x643d54: b.eq            #0x643f48
    // 0x643d58: mov             x0, x3
    // 0x643d5c: r2 = Null
    //     0x643d5c: mov             x2, NULL
    // 0x643d60: r1 = Null
    //     0x643d60: mov             x1, NULL
    // 0x643d64: r4 = LoadClassIdInstr(r0)
    //     0x643d64: ldur            x4, [x0, #-1]
    //     0x643d68: ubfx            x4, x4, #0xc, #0x14
    // 0x643d6c: sub             x4, x4, #0x961
    // 0x643d70: cmp             x4, #0xbe
    // 0x643d74: b.ls            #0x643d88
    // 0x643d78: r8 = RenderObject
    //     0x643d78: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x643d7c: r3 = Null
    //     0x643d7c: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1ca40] Null
    //     0x643d80: ldr             x3, [x3, #0xa40]
    // 0x643d84: r0 = RenderObject()
    //     0x643d84: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x643d88: ldur            x2, [fp, #-0x10]
    // 0x643d8c: ldur            x0, [fp, #-0x20]
    // 0x643d90: b               #0x643c80
    // 0x643d94: ldr             x0, [fp, #0x10]
    // 0x643d98: cmp             w0, NULL
    // 0x643d9c: b.eq            #0x643e3c
    // 0x643da0: ldur            x1, [fp, #-8]
    // 0x643da4: ldur            x0, [fp, #-0x20]
    // 0x643da8: cmp             w1, NULL
    // 0x643dac: b.eq            #0x643f4c
    // 0x643db0: LoadField: r2 = r0->field_b
    //     0x643db0: ldur            w2, [x0, #0xb]
    // 0x643db4: DecompressPointer r2
    //     0x643db4: add             x2, x2, HEAP, lsl #32
    // 0x643db8: stur            x2, [fp, #-0x10]
    // 0x643dbc: LoadField: r3 = r0->field_f
    //     0x643dbc: ldur            w3, [x0, #0xf]
    // 0x643dc0: DecompressPointer r3
    //     0x643dc0: add             x3, x3, HEAP, lsl #32
    // 0x643dc4: LoadField: r4 = r3->field_b
    //     0x643dc4: ldur            w4, [x3, #0xb]
    // 0x643dc8: DecompressPointer r4
    //     0x643dc8: add             x4, x4, HEAP, lsl #32
    // 0x643dcc: cmp             w2, w4
    // 0x643dd0: b.ne            #0x643de0
    // 0x643dd4: SaveReg r0
    //     0x643dd4: str             x0, [SP, #-8]!
    // 0x643dd8: r0 = _growToNextCapacity()
    //     0x643dd8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x643ddc: add             SP, SP, #8
    // 0x643de0: ldur            x2, [fp, #-0x20]
    // 0x643de4: ldur            x0, [fp, #-0x10]
    // 0x643de8: r3 = LoadInt32Instr(r0)
    //     0x643de8: sbfx            x3, x0, #1, #0x1f
    // 0x643dec: add             x0, x3, #1
    // 0x643df0: lsl             x1, x0, #1
    // 0x643df4: StoreField: r2->field_b = r1
    //     0x643df4: stur            w1, [x2, #0xb]
    // 0x643df8: mov             x1, x3
    // 0x643dfc: cmp             x1, x0
    // 0x643e00: b.hs            #0x643f50
    // 0x643e04: LoadField: r1 = r2->field_f
    //     0x643e04: ldur            w1, [x2, #0xf]
    // 0x643e08: DecompressPointer r1
    //     0x643e08: add             x1, x1, HEAP, lsl #32
    // 0x643e0c: ldur            x0, [fp, #-8]
    // 0x643e10: ArrayStore: r1[r3] = r0  ; List_4
    //     0x643e10: add             x25, x1, x3, lsl #2
    //     0x643e14: add             x25, x25, #0xf
    //     0x643e18: str             w0, [x25]
    //     0x643e1c: tbz             w0, #0, #0x643e38
    //     0x643e20: ldurb           w16, [x1, #-1]
    //     0x643e24: ldurb           w17, [x0, #-1]
    //     0x643e28: and             x16, x17, x16, lsr #2
    //     0x643e2c: tst             x16, HEAP, lsr #32
    //     0x643e30: b.eq            #0x643e38
    //     0x643e34: bl              #0xd67e5c
    // 0x643e38: b               #0x643e40
    // 0x643e3c: ldur            x2, [fp, #-0x20]
    // 0x643e40: r0 = Matrix4()
    //     0x643e40: bl              #0x50ace8  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x643e44: r4 = 32
    //     0x643e44: mov             x4, #0x20
    // 0x643e48: stur            x0, [fp, #-8]
    // 0x643e4c: r0 = AllocateFloat64Array()
    //     0x643e4c: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0x643e50: mov             x1, x0
    // 0x643e54: ldur            x0, [fp, #-8]
    // 0x643e58: StoreField: r0->field_7 = r1
    //     0x643e58: stur            w1, [x0, #7]
    // 0x643e5c: SaveReg r0
    //     0x643e5c: str             x0, [SP, #-8]!
    // 0x643e60: r0 = setIdentity()
    //     0x643e60: bl              #0x50f090  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0x643e64: add             SP, SP, #8
    // 0x643e68: ldur            x2, [fp, #-0x20]
    // 0x643e6c: LoadField: r0 = r2->field_b
    //     0x643e6c: ldur            w0, [x2, #0xb]
    // 0x643e70: DecompressPointer r0
    //     0x643e70: add             x0, x0, HEAP, lsl #32
    // 0x643e74: r1 = LoadInt32Instr(r0)
    //     0x643e74: sbfx            x1, x0, #1, #0x1f
    // 0x643e78: sub             x0, x1, #1
    // 0x643e7c: mov             x3, x0
    // 0x643e80: CheckStackOverflow
    //     0x643e80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x643e84: cmp             SP, x16
    //     0x643e88: b.ls            #0x643f54
    // 0x643e8c: cmp             x3, #0
    // 0x643e90: b.le            #0x643f20
    // 0x643e94: LoadField: r0 = r2->field_b
    //     0x643e94: ldur            w0, [x2, #0xb]
    // 0x643e98: DecompressPointer r0
    //     0x643e98: add             x0, x0, HEAP, lsl #32
    // 0x643e9c: r4 = LoadInt32Instr(r0)
    //     0x643e9c: sbfx            x4, x0, #1, #0x1f
    // 0x643ea0: mov             x0, x4
    // 0x643ea4: mov             x1, x3
    // 0x643ea8: cmp             x1, x0
    // 0x643eac: b.hs            #0x643f5c
    // 0x643eb0: LoadField: r5 = r2->field_f
    //     0x643eb0: ldur            w5, [x2, #0xf]
    // 0x643eb4: DecompressPointer r5
    //     0x643eb4: add             x5, x5, HEAP, lsl #32
    // 0x643eb8: ArrayLoad: r6 = r5[r3]  ; Unknown_4
    //     0x643eb8: add             x16, x5, x3, lsl #2
    //     0x643ebc: ldur            w6, [x16, #0xf]
    // 0x643ec0: DecompressPointer r6
    //     0x643ec0: add             x6, x6, HEAP, lsl #32
    // 0x643ec4: sub             x7, x3, #1
    // 0x643ec8: mov             x0, x4
    // 0x643ecc: mov             x1, x7
    // 0x643ed0: stur            x7, [fp, #-0x28]
    // 0x643ed4: cmp             x1, x0
    // 0x643ed8: b.hs            #0x643f60
    // 0x643edc: ArrayLoad: r0 = r5[r7]  ; Unknown_4
    //     0x643edc: add             x16, x5, x7, lsl #2
    //     0x643ee0: ldur            w0, [x16, #0xf]
    // 0x643ee4: DecompressPointer r0
    //     0x643ee4: add             x0, x0, HEAP, lsl #32
    // 0x643ee8: r1 = LoadClassIdInstr(r6)
    //     0x643ee8: ldur            x1, [x6, #-1]
    //     0x643eec: ubfx            x1, x1, #0xc, #0x14
    // 0x643ef0: stp             x0, x6, [SP, #-0x10]!
    // 0x643ef4: ldur            x16, [fp, #-8]
    // 0x643ef8: SaveReg r16
    //     0x643ef8: str             x16, [SP, #-8]!
    // 0x643efc: mov             x0, x1
    // 0x643f00: r0 = GDT[cid_x0 + 0xd590]()
    //     0x643f00: mov             x17, #0xd590
    //     0x643f04: add             lr, x0, x17
    //     0x643f08: ldr             lr, [x21, lr, lsl #3]
    //     0x643f0c: blr             lr
    // 0x643f10: add             SP, SP, #0x18
    // 0x643f14: ldur            x3, [fp, #-0x28]
    // 0x643f18: ldur            x2, [fp, #-0x20]
    // 0x643f1c: b               #0x643e80
    // 0x643f20: ldur            x0, [fp, #-8]
    // 0x643f24: LeaveFrame
    //     0x643f24: mov             SP, fp
    //     0x643f28: ldp             fp, lr, [SP], #0x10
    // 0x643f2c: ret
    //     0x643f2c: ret             
    // 0x643f30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x643f30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x643f34: b               #0x643be4
    // 0x643f38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x643f38: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x643f3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x643f3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x643f40: b               #0x643c94
    // 0x643f44: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x643f44: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x643f48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x643f48: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x643f4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x643f4c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x643f50: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x643f50: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x643f54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x643f54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x643f58: b               #0x643e8c
    // 0x643f5c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x643f5c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x643f60: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x643f60: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ showOnScreen(/* No info */) {
    // ** addr: 0x644c40, size: 0x2ac
    // 0x644c40: EnterFrame
    //     0x644c40: stp             fp, lr, [SP, #-0x10]!
    //     0x644c44: mov             fp, SP
    // 0x644c48: AllocStack(0x30)
    //     0x644c48: sub             SP, SP, #0x30
    // 0x644c4c: SetupParameters(RenderObject this /* r3, fp-0x28 */, {dynamic curve = Instance_Cubic /* r4, fp-0x20 */, dynamic descendant = Null /* r5, fp-0x18 */, dynamic duration = Instance_Duration /* r6, fp-0x10 */, dynamic rect = Null /* r1, fp-0x8 */})
    //     0x644c4c: mov             x0, x4
    //     0x644c50: ldur            w1, [x0, #0x13]
    //     0x644c54: add             x1, x1, HEAP, lsl #32
    //     0x644c58: sub             x2, x1, #2
    //     0x644c5c: add             x3, fp, w2, sxtw #2
    //     0x644c60: ldr             x3, [x3, #0x10]
    //     0x644c64: stur            x3, [fp, #-0x28]
    //     0x644c68: ldur            w2, [x0, #0x1f]
    //     0x644c6c: add             x2, x2, HEAP, lsl #32
    //     0x644c70: add             x16, PP, #0xa, lsl #12  ; [pp+0xafc0] "curve"
    //     0x644c74: ldr             x16, [x16, #0xfc0]
    //     0x644c78: cmp             w2, w16
    //     0x644c7c: b.ne            #0x644ca0
    //     0x644c80: ldur            w2, [x0, #0x23]
    //     0x644c84: add             x2, x2, HEAP, lsl #32
    //     0x644c88: sub             w4, w1, w2
    //     0x644c8c: add             x2, fp, w4, sxtw #2
    //     0x644c90: ldr             x2, [x2, #8]
    //     0x644c94: mov             x4, x2
    //     0x644c98: mov             x2, #1
    //     0x644c9c: b               #0x644cac
    //     0x644ca0: add             x4, PP, #0xa, lsl #12  ; [pp+0xafc8] Obj!Cubic<double>@b4f341
    //     0x644ca4: ldr             x4, [x4, #0xfc8]
    //     0x644ca8: mov             x2, #0
    //     0x644cac: stur            x4, [fp, #-0x20]
    //     0x644cb0: lsl             x5, x2, #1
    //     0x644cb4: lsl             w6, w5, #1
    //     0x644cb8: add             w7, w6, #8
    //     0x644cbc: add             x16, x0, w7, sxtw #1
    //     0x644cc0: ldur            w8, [x16, #0xf]
    //     0x644cc4: add             x8, x8, HEAP, lsl #32
    //     0x644cc8: add             x16, PP, #0xa, lsl #12  ; [pp+0xafd0] "descendant"
    //     0x644ccc: ldr             x16, [x16, #0xfd0]
    //     0x644cd0: cmp             w8, w16
    //     0x644cd4: b.ne            #0x644d08
    //     0x644cd8: add             w2, w6, #0xa
    //     0x644cdc: add             x16, x0, w2, sxtw #1
    //     0x644ce0: ldur            w6, [x16, #0xf]
    //     0x644ce4: add             x6, x6, HEAP, lsl #32
    //     0x644ce8: sub             w2, w1, w6
    //     0x644cec: add             x6, fp, w2, sxtw #2
    //     0x644cf0: ldr             x6, [x6, #8]
    //     0x644cf4: add             w2, w5, #2
    //     0x644cf8: sbfx            x5, x2, #1, #0x1f
    //     0x644cfc: mov             x2, x5
    //     0x644d00: mov             x5, x6
    //     0x644d04: b               #0x644d0c
    //     0x644d08: mov             x5, NULL
    //     0x644d0c: stur            x5, [fp, #-0x18]
    //     0x644d10: lsl             x6, x2, #1
    //     0x644d14: lsl             w7, w6, #1
    //     0x644d18: add             w8, w7, #8
    //     0x644d1c: add             x16, x0, w8, sxtw #1
    //     0x644d20: ldur            w9, [x16, #0xf]
    //     0x644d24: add             x9, x9, HEAP, lsl #32
    //     0x644d28: add             x16, PP, #0xa, lsl #12  ; [pp+0xafd8] "duration"
    //     0x644d2c: ldr             x16, [x16, #0xfd8]
    //     0x644d30: cmp             w9, w16
    //     0x644d34: b.ne            #0x644d68
    //     0x644d38: add             w2, w7, #0xa
    //     0x644d3c: add             x16, x0, w2, sxtw #1
    //     0x644d40: ldur            w7, [x16, #0xf]
    //     0x644d44: add             x7, x7, HEAP, lsl #32
    //     0x644d48: sub             w2, w1, w7
    //     0x644d4c: add             x7, fp, w2, sxtw #2
    //     0x644d50: ldr             x7, [x7, #8]
    //     0x644d54: add             w2, w6, #2
    //     0x644d58: sbfx            x6, x2, #1, #0x1f
    //     0x644d5c: mov             x2, x6
    //     0x644d60: mov             x6, x7
    //     0x644d64: b               #0x644d6c
    //     0x644d68: ldr             x6, [PP, #0x33e0]  ; [pp+0x33e0] Obj!Duration@b67a11
    //     0x644d6c: stur            x6, [fp, #-0x10]
    //     0x644d70: lsl             x7, x2, #1
    //     0x644d74: lsl             w2, w7, #1
    //     0x644d78: add             w7, w2, #8
    //     0x644d7c: add             x16, x0, w7, sxtw #1
    //     0x644d80: ldur            w8, [x16, #0xf]
    //     0x644d84: add             x8, x8, HEAP, lsl #32
    //     0x644d88: add             x16, PP, #0xa, lsl #12  ; [pp+0xafe0] "rect"
    //     0x644d8c: ldr             x16, [x16, #0xfe0]
    //     0x644d90: cmp             w8, w16
    //     0x644d94: b.ne            #0x644db8
    //     0x644d98: add             w7, w2, #0xa
    //     0x644d9c: add             x16, x0, w7, sxtw #1
    //     0x644da0: ldur            w2, [x16, #0xf]
    //     0x644da4: add             x2, x2, HEAP, lsl #32
    //     0x644da8: sub             w0, w1, w2
    //     0x644dac: add             x1, fp, w0, sxtw #2
    //     0x644db0: ldr             x1, [x1, #8]
    //     0x644db4: b               #0x644dbc
    //     0x644db8: mov             x1, NULL
    //     0x644dbc: stur            x1, [fp, #-8]
    // 0x644dc0: CheckStackOverflow
    //     0x644dc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x644dc4: cmp             SP, x16
    //     0x644dc8: b.ls            #0x644ee0
    // 0x644dcc: r0 = LoadClassIdInstr(r3)
    //     0x644dcc: ldur            x0, [x3, #-1]
    //     0x644dd0: ubfx            x0, x0, #0xc, #0x14
    // 0x644dd4: SaveReg r3
    //     0x644dd4: str             x3, [SP, #-8]!
    // 0x644dd8: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0x644dd8: mov             x17, #0xa2f1
    //     0x644ddc: add             lr, x0, x17
    //     0x644de0: ldr             lr, [x21, lr, lsl #3]
    //     0x644de4: blr             lr
    // 0x644de8: add             SP, SP, #8
    // 0x644dec: r1 = LoadClassIdInstr(r0)
    //     0x644dec: ldur            x1, [x0, #-1]
    //     0x644df0: ubfx            x1, x1, #0xc, #0x14
    // 0x644df4: lsl             x1, x1, #1
    // 0x644df8: r0 = LoadInt32Instr(r1)
    //     0x644df8: sbfx            x0, x1, #1, #0x1f
    // 0x644dfc: cmp             x0, #0x961
    // 0x644e00: b.lt            #0x644ed0
    // 0x644e04: cmp             x0, #0xa1f
    // 0x644e08: b.gt            #0x644ed0
    // 0x644e0c: ldur            x1, [fp, #-0x28]
    // 0x644e10: ldur            x2, [fp, #-0x18]
    // 0x644e14: r0 = LoadClassIdInstr(r1)
    //     0x644e14: ldur            x0, [x1, #-1]
    //     0x644e18: ubfx            x0, x0, #0xc, #0x14
    // 0x644e1c: SaveReg r1
    //     0x644e1c: str             x1, [SP, #-8]!
    // 0x644e20: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0x644e20: mov             x17, #0xa2f1
    //     0x644e24: add             lr, x0, x17
    //     0x644e28: ldr             lr, [x21, lr, lsl #3]
    //     0x644e2c: blr             lr
    // 0x644e30: add             SP, SP, #8
    // 0x644e34: mov             x3, x0
    // 0x644e38: stur            x3, [fp, #-0x30]
    // 0x644e3c: cmp             w3, NULL
    // 0x644e40: b.eq            #0x644ee8
    // 0x644e44: mov             x0, x3
    // 0x644e48: r2 = Null
    //     0x644e48: mov             x2, NULL
    // 0x644e4c: r1 = Null
    //     0x644e4c: mov             x1, NULL
    // 0x644e50: r4 = LoadClassIdInstr(r0)
    //     0x644e50: ldur            x4, [x0, #-1]
    //     0x644e54: ubfx            x4, x4, #0xc, #0x14
    // 0x644e58: sub             x4, x4, #0x961
    // 0x644e5c: cmp             x4, #0xbe
    // 0x644e60: b.ls            #0x644e74
    // 0x644e64: r8 = RenderObject
    //     0x644e64: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x644e68: r3 = Null
    //     0x644e68: add             x3, PP, #0xa, lsl #12  ; [pp+0xaff0] Null
    //     0x644e6c: ldr             x3, [x3, #0xff0]
    // 0x644e70: r0 = RenderObject()
    //     0x644e70: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x644e74: ldur            x0, [fp, #-0x18]
    // 0x644e78: cmp             w0, NULL
    // 0x644e7c: b.ne            #0x644e88
    // 0x644e80: ldur            x1, [fp, #-0x28]
    // 0x644e84: b               #0x644e8c
    // 0x644e88: mov             x1, x0
    // 0x644e8c: ldur            x0, [fp, #-0x30]
    // 0x644e90: r2 = LoadClassIdInstr(r0)
    //     0x644e90: ldur            x2, [x0, #-1]
    //     0x644e94: ubfx            x2, x2, #0xc, #0x14
    // 0x644e98: stp             x1, x0, [SP, #-0x10]!
    // 0x644e9c: ldur            x16, [fp, #-8]
    // 0x644ea0: ldur            lr, [fp, #-0x10]
    // 0x644ea4: stp             lr, x16, [SP, #-0x10]!
    // 0x644ea8: ldur            x16, [fp, #-0x20]
    // 0x644eac: SaveReg r16
    //     0x644eac: str             x16, [SP, #-8]!
    // 0x644eb0: mov             x0, x2
    // 0x644eb4: r4 = const [0, 0x5, 0x5, 0x1, curve, 0x4, descendant, 0x1, duration, 0x3, rect, 0x2, null]
    //     0x644eb4: add             x4, PP, #0xa, lsl #12  ; [pp+0xafe8] List(13) [0, 0x5, 0x5, 0x1, "curve", 0x4, "descendant", 0x1, "duration", 0x3, "rect", 0x2, Null]
    //     0x644eb8: ldr             x4, [x4, #0xfe8]
    // 0x644ebc: r0 = GDT[cid_x0 + 0xeb2e]()
    //     0x644ebc: mov             x17, #0xeb2e
    //     0x644ec0: add             lr, x0, x17
    //     0x644ec4: ldr             lr, [x21, lr, lsl #3]
    //     0x644ec8: blr             lr
    // 0x644ecc: add             SP, SP, #0x28
    // 0x644ed0: r0 = Null
    //     0x644ed0: mov             x0, NULL
    // 0x644ed4: LeaveFrame
    //     0x644ed4: mov             SP, fp
    //     0x644ed8: ldp             fp, lr, [SP], #0x10
    // 0x644edc: ret
    //     0x644edc: ret             
    // 0x644ee0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x644ee0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x644ee4: b               #0x644dcc
    // 0x644ee8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x644ee8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void showOnScreen(dynamic, {RenderObject? descendant, Rect? rect, Duration duration, Curve curve}) {
    // ** addr: 0x644eec, size: 0x1b8
    // 0x644eec: EnterFrame
    //     0x644eec: stp             fp, lr, [SP, #-0x10]!
    //     0x644ef0: mov             fp, SP
    // 0x644ef4: mov             x0, x4
    // 0x644ef8: LoadField: r1 = r0->field_13
    //     0x644ef8: ldur            w1, [x0, #0x13]
    // 0x644efc: DecompressPointer r1
    //     0x644efc: add             x1, x1, HEAP, lsl #32
    // 0x644f00: sub             x2, x1, #2
    // 0x644f04: add             x3, fp, w2, sxtw #2
    // 0x644f08: ldr             x3, [x3, #0x10]
    // 0x644f0c: LoadField: r2 = r0->field_1f
    //     0x644f0c: ldur            w2, [x0, #0x1f]
    // 0x644f10: DecompressPointer r2
    //     0x644f10: add             x2, x2, HEAP, lsl #32
    // 0x644f14: r16 = "curve"
    //     0x644f14: add             x16, PP, #0xa, lsl #12  ; [pp+0xafc0] "curve"
    //     0x644f18: ldr             x16, [x16, #0xfc0]
    // 0x644f1c: cmp             w2, w16
    // 0x644f20: b.ne            #0x644f44
    // 0x644f24: LoadField: r2 = r0->field_23
    //     0x644f24: ldur            w2, [x0, #0x23]
    // 0x644f28: DecompressPointer r2
    //     0x644f28: add             x2, x2, HEAP, lsl #32
    // 0x644f2c: sub             w4, w1, w2
    // 0x644f30: add             x2, fp, w4, sxtw #2
    // 0x644f34: ldr             x2, [x2, #8]
    // 0x644f38: mov             x4, x2
    // 0x644f3c: r2 = 1
    //     0x644f3c: mov             x2, #1
    // 0x644f40: b               #0x644f50
    // 0x644f44: r4 = Instance_Cubic
    //     0x644f44: add             x4, PP, #0xa, lsl #12  ; [pp+0xafc8] Obj!Cubic<double>@b4f341
    //     0x644f48: ldr             x4, [x4, #0xfc8]
    // 0x644f4c: r2 = 0
    //     0x644f4c: mov             x2, #0
    // 0x644f50: lsl             x5, x2, #1
    // 0x644f54: lsl             w6, w5, #1
    // 0x644f58: add             w7, w6, #8
    // 0x644f5c: ArrayLoad: r8 = r0[r7]  ; Unknown_4
    //     0x644f5c: add             x16, x0, w7, sxtw #1
    //     0x644f60: ldur            w8, [x16, #0xf]
    // 0x644f64: DecompressPointer r8
    //     0x644f64: add             x8, x8, HEAP, lsl #32
    // 0x644f68: r16 = "descendant"
    //     0x644f68: add             x16, PP, #0xa, lsl #12  ; [pp+0xafd0] "descendant"
    //     0x644f6c: ldr             x16, [x16, #0xfd0]
    // 0x644f70: cmp             w8, w16
    // 0x644f74: b.ne            #0x644fa8
    // 0x644f78: add             w2, w6, #0xa
    // 0x644f7c: ArrayLoad: r6 = r0[r2]  ; Unknown_4
    //     0x644f7c: add             x16, x0, w2, sxtw #1
    //     0x644f80: ldur            w6, [x16, #0xf]
    // 0x644f84: DecompressPointer r6
    //     0x644f84: add             x6, x6, HEAP, lsl #32
    // 0x644f88: sub             w2, w1, w6
    // 0x644f8c: add             x6, fp, w2, sxtw #2
    // 0x644f90: ldr             x6, [x6, #8]
    // 0x644f94: add             w2, w5, #2
    // 0x644f98: r5 = LoadInt32Instr(r2)
    //     0x644f98: sbfx            x5, x2, #1, #0x1f
    // 0x644f9c: mov             x2, x5
    // 0x644fa0: mov             x5, x6
    // 0x644fa4: b               #0x644fac
    // 0x644fa8: r5 = Null
    //     0x644fa8: mov             x5, NULL
    // 0x644fac: lsl             x6, x2, #1
    // 0x644fb0: lsl             w7, w6, #1
    // 0x644fb4: add             w8, w7, #8
    // 0x644fb8: ArrayLoad: r9 = r0[r8]  ; Unknown_4
    //     0x644fb8: add             x16, x0, w8, sxtw #1
    //     0x644fbc: ldur            w9, [x16, #0xf]
    // 0x644fc0: DecompressPointer r9
    //     0x644fc0: add             x9, x9, HEAP, lsl #32
    // 0x644fc4: r16 = "duration"
    //     0x644fc4: add             x16, PP, #0xa, lsl #12  ; [pp+0xafd8] "duration"
    //     0x644fc8: ldr             x16, [x16, #0xfd8]
    // 0x644fcc: cmp             w9, w16
    // 0x644fd0: b.ne            #0x645004
    // 0x644fd4: add             w2, w7, #0xa
    // 0x644fd8: ArrayLoad: r7 = r0[r2]  ; Unknown_4
    //     0x644fd8: add             x16, x0, w2, sxtw #1
    //     0x644fdc: ldur            w7, [x16, #0xf]
    // 0x644fe0: DecompressPointer r7
    //     0x644fe0: add             x7, x7, HEAP, lsl #32
    // 0x644fe4: sub             w2, w1, w7
    // 0x644fe8: add             x7, fp, w2, sxtw #2
    // 0x644fec: ldr             x7, [x7, #8]
    // 0x644ff0: add             w2, w6, #2
    // 0x644ff4: r6 = LoadInt32Instr(r2)
    //     0x644ff4: sbfx            x6, x2, #1, #0x1f
    // 0x644ff8: mov             x2, x6
    // 0x644ffc: mov             x6, x7
    // 0x645000: b               #0x645008
    // 0x645004: r6 = Instance_Duration
    //     0x645004: ldr             x6, [PP, #0x33e0]  ; [pp+0x33e0] Obj!Duration@b67a11
    // 0x645008: lsl             x7, x2, #1
    // 0x64500c: lsl             w2, w7, #1
    // 0x645010: add             w7, w2, #8
    // 0x645014: ArrayLoad: r8 = r0[r7]  ; Unknown_4
    //     0x645014: add             x16, x0, w7, sxtw #1
    //     0x645018: ldur            w8, [x16, #0xf]
    // 0x64501c: DecompressPointer r8
    //     0x64501c: add             x8, x8, HEAP, lsl #32
    // 0x645020: r16 = "rect"
    //     0x645020: add             x16, PP, #0xa, lsl #12  ; [pp+0xafe0] "rect"
    //     0x645024: ldr             x16, [x16, #0xfe0]
    // 0x645028: cmp             w8, w16
    // 0x64502c: b.ne            #0x645054
    // 0x645030: add             w7, w2, #0xa
    // 0x645034: ArrayLoad: r2 = r0[r7]  ; Unknown_4
    //     0x645034: add             x16, x0, w7, sxtw #1
    //     0x645038: ldur            w2, [x16, #0xf]
    // 0x64503c: DecompressPointer r2
    //     0x64503c: add             x2, x2, HEAP, lsl #32
    // 0x645040: sub             w0, w1, w2
    // 0x645044: add             x1, fp, w0, sxtw #2
    // 0x645048: ldr             x1, [x1, #8]
    // 0x64504c: mov             x0, x1
    // 0x645050: b               #0x645058
    // 0x645054: r0 = Null
    //     0x645054: mov             x0, NULL
    // 0x645058: LoadField: r1 = r3->field_17
    //     0x645058: ldur            w1, [x3, #0x17]
    // 0x64505c: DecompressPointer r1
    //     0x64505c: add             x1, x1, HEAP, lsl #32
    // 0x645060: CheckStackOverflow
    //     0x645060: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x645064: cmp             SP, x16
    //     0x645068: b.ls            #0x64509c
    // 0x64506c: LoadField: r2 = r1->field_f
    //     0x64506c: ldur            w2, [x1, #0xf]
    // 0x645070: DecompressPointer r2
    //     0x645070: add             x2, x2, HEAP, lsl #32
    // 0x645074: stp             x5, x2, [SP, #-0x10]!
    // 0x645078: stp             x6, x0, [SP, #-0x10]!
    // 0x64507c: SaveReg r4
    //     0x64507c: str             x4, [SP, #-8]!
    // 0x645080: r4 = const [0, 0x5, 0x5, 0x1, curve, 0x4, descendant, 0x1, duration, 0x3, rect, 0x2, null]
    //     0x645080: add             x4, PP, #0xa, lsl #12  ; [pp+0xafe8] List(13) [0, 0x5, 0x5, 0x1, "curve", 0x4, "descendant", 0x1, "duration", 0x3, "rect", 0x2, Null]
    //     0x645084: ldr             x4, [x4, #0xfe8]
    // 0x645088: r0 = showOnScreen()
    //     0x645088: bl              #0x644c40  ; [package:flutter/src/rendering/object.dart] RenderObject::showOnScreen
    // 0x64508c: add             SP, SP, #0x28
    // 0x645090: LeaveFrame
    //     0x645090: mov             SP, fp
    //     0x645094: ldp             fp, lr, [SP], #0x10
    // 0x645098: ret
    //     0x645098: ret             
    // 0x64509c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64509c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6450a0: b               #0x64506c
  }
  _ clearSemantics(/* No info */) {
    // ** addr: 0x645174, size: 0x74
    // 0x645174: EnterFrame
    //     0x645174: stp             fp, lr, [SP, #-0x10]!
    //     0x645178: mov             fp, SP
    // 0x64517c: r0 = true
    //     0x64517c: add             x0, NULL, #0x20  ; true
    // 0x645180: CheckStackOverflow
    //     0x645180: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x645184: cmp             SP, x16
    //     0x645188: b.ls            #0x6451e0
    // 0x64518c: ldr             x3, [fp, #0x10]
    // 0x645190: StoreField: r3->field_47 = r0
    //     0x645190: stur            w0, [x3, #0x47]
    // 0x645194: StoreField: r3->field_4b = rNULL
    //     0x645194: stur            NULL, [x3, #0x4b]
    // 0x645198: r1 = Function '<anonymous closure>':.
    //     0x645198: ldr             x1, [PP, #0x4cc0]  ; [pp+0x4cc0] AnonymousClosure: (0x6451e8), in [package:flutter/src/rendering/object.dart] RenderObject::clearSemantics (0x645174)
    // 0x64519c: r2 = Null
    //     0x64519c: mov             x2, NULL
    // 0x6451a0: r0 = AllocateClosure()
    //     0x6451a0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6451a4: mov             x1, x0
    // 0x6451a8: ldr             x0, [fp, #0x10]
    // 0x6451ac: r2 = LoadClassIdInstr(r0)
    //     0x6451ac: ldur            x2, [x0, #-1]
    //     0x6451b0: ubfx            x2, x2, #0xc, #0x14
    // 0x6451b4: stp             x1, x0, [SP, #-0x10]!
    // 0x6451b8: mov             x0, x2
    // 0x6451bc: r0 = GDT[cid_x0 + 0xd2d5]()
    //     0x6451bc: mov             x17, #0xd2d5
    //     0x6451c0: add             lr, x0, x17
    //     0x6451c4: ldr             lr, [x21, lr, lsl #3]
    //     0x6451c8: blr             lr
    // 0x6451cc: add             SP, SP, #0x10
    // 0x6451d0: r0 = Null
    //     0x6451d0: mov             x0, NULL
    // 0x6451d4: LeaveFrame
    //     0x6451d4: mov             SP, fp
    //     0x6451d8: ldp             fp, lr, [SP], #0x10
    // 0x6451dc: ret
    //     0x6451dc: ret             
    // 0x6451e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6451e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6451e4: b               #0x64518c
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0x6451e8, size: 0x54
    // 0x6451e8: EnterFrame
    //     0x6451e8: stp             fp, lr, [SP, #-0x10]!
    //     0x6451ec: mov             fp, SP
    // 0x6451f0: CheckStackOverflow
    //     0x6451f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6451f4: cmp             SP, x16
    //     0x6451f8: b.ls            #0x645234
    // 0x6451fc: ldr             x0, [fp, #0x10]
    // 0x645200: r1 = LoadClassIdInstr(r0)
    //     0x645200: ldur            x1, [x0, #-1]
    //     0x645204: ubfx            x1, x1, #0xc, #0x14
    // 0x645208: SaveReg r0
    //     0x645208: str             x0, [SP, #-8]!
    // 0x64520c: mov             x0, x1
    // 0x645210: r0 = GDT[cid_x0 + 0xea6f]()
    //     0x645210: mov             x17, #0xea6f
    //     0x645214: add             lr, x0, x17
    //     0x645218: ldr             lr, [x21, lr, lsl #3]
    //     0x64521c: blr             lr
    // 0x645220: add             SP, SP, #8
    // 0x645224: r0 = Null
    //     0x645224: mov             x0, NULL
    // 0x645228: LeaveFrame
    //     0x645228: mov             SP, fp
    //     0x64522c: ldp             fp, lr, [SP], #0x10
    // 0x645230: ret
    //     0x645230: ret             
    // 0x645234: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x645234: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x645238: b               #0x6451fc
  }
  _ assembleSemanticsNode(/* No info */) {
    // ** addr: 0x64b60c, size: 0x4c
    // 0x64b60c: EnterFrame
    //     0x64b60c: stp             fp, lr, [SP, #-0x10]!
    //     0x64b610: mov             fp, SP
    // 0x64b614: CheckStackOverflow
    //     0x64b614: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64b618: cmp             SP, x16
    //     0x64b61c: b.ls            #0x64b650
    // 0x64b620: ldr             x16, [fp, #0x20]
    // 0x64b624: ldr             lr, [fp, #0x18]
    // 0x64b628: stp             lr, x16, [SP, #-0x10]!
    // 0x64b62c: ldr             x16, [fp, #0x10]
    // 0x64b630: SaveReg r16
    //     0x64b630: str             x16, [SP, #-8]!
    // 0x64b634: r4 = const [0, 0x3, 0x3, 0x2, childrenInInversePaintOrder, 0x2, null]
    //     0x64b634: ldr             x4, [PP, #0x7218]  ; [pp+0x7218] List(7) [0, 0x3, 0x3, 0x2, "childrenInInversePaintOrder", 0x2, Null]
    // 0x64b638: r0 = updateWith()
    //     0x64b638: bl              #0x6469d8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::updateWith
    // 0x64b63c: add             SP, SP, #0x18
    // 0x64b640: r0 = Null
    //     0x64b640: mov             x0, NULL
    // 0x64b644: LeaveFrame
    //     0x64b644: mov             SP, fp
    //     0x64b648: ldp             fp, lr, [SP], #0x10
    // 0x64b64c: ret
    //     0x64b64c: ret             
    // 0x64b650: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64b650: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64b654: b               #0x64b620
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0x64bdd0, size: 0x68
    // 0x64bdd0: EnterFrame
    //     0x64bdd0: stp             fp, lr, [SP, #-0x10]!
    //     0x64bdd4: mov             fp, SP
    // 0x64bdd8: ldr             x0, [fp, #0x10]
    // 0x64bddc: LoadField: r1 = r0->field_17
    //     0x64bddc: ldur            w1, [x0, #0x17]
    // 0x64bde0: DecompressPointer r1
    //     0x64bde0: add             x1, x1, HEAP, lsl #32
    // 0x64bde4: r2 = LoadClassIdInstr(r1)
    //     0x64bde4: ldur            x2, [x1, #-1]
    //     0x64bde8: ubfx            x2, x2, #0xc, #0x14
    // 0x64bdec: lsl             x2, x2, #1
    // 0x64bdf0: r1 = LoadInt32Instr(r2)
    //     0x64bdf0: sbfx            x1, x2, #1, #0x1f
    // 0x64bdf4: cmp             x1, #0x7f2
    // 0x64bdf8: b.lt            #0x64be04
    // 0x64bdfc: cmp             x1, #0x80a
    // 0x64be00: b.le            #0x64be28
    // 0x64be04: r0 = ParentData()
    //     0x64be04: bl              #0x64be38  ; AllocateParentDataStub -> ParentData (size=0x8)
    // 0x64be08: ldr             x1, [fp, #0x10]
    // 0x64be0c: StoreField: r1->field_17 = r0
    //     0x64be0c: stur            w0, [x1, #0x17]
    //     0x64be10: ldurb           w16, [x1, #-1]
    //     0x64be14: ldurb           w17, [x0, #-1]
    //     0x64be18: and             x16, x17, x16, lsr #2
    //     0x64be1c: tst             x16, HEAP, lsr #32
    //     0x64be20: b.eq            #0x64be28
    //     0x64be24: bl              #0xd6826c
    // 0x64be28: r0 = Null
    //     0x64be28: mov             x0, NULL
    // 0x64be2c: LeaveFrame
    //     0x64be2c: mov             SP, fp
    //     0x64be30: ldp             fp, lr, [SP], #0x10
    // 0x64be34: ret
    //     0x64be34: ret             
  }
  [closure] void markNeedsPaint(dynamic) {
    // ** addr: 0x652ca8, size: 0x48
    // 0x652ca8: EnterFrame
    //     0x652ca8: stp             fp, lr, [SP, #-0x10]!
    //     0x652cac: mov             fp, SP
    // 0x652cb0: ldr             x0, [fp, #0x10]
    // 0x652cb4: LoadField: r1 = r0->field_17
    //     0x652cb4: ldur            w1, [x0, #0x17]
    // 0x652cb8: DecompressPointer r1
    //     0x652cb8: add             x1, x1, HEAP, lsl #32
    // 0x652cbc: CheckStackOverflow
    //     0x652cbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x652cc0: cmp             SP, x16
    //     0x652cc4: b.ls            #0x652ce8
    // 0x652cc8: LoadField: r0 = r1->field_f
    //     0x652cc8: ldur            w0, [x1, #0xf]
    // 0x652ccc: DecompressPointer r0
    //     0x652ccc: add             x0, x0, HEAP, lsl #32
    // 0x652cd0: SaveReg r0
    //     0x652cd0: str             x0, [SP, #-8]!
    // 0x652cd4: r0 = markNeedsPaint()
    //     0x652cd4: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x652cd8: add             SP, SP, #8
    // 0x652cdc: LeaveFrame
    //     0x652cdc: mov             SP, fp
    //     0x652ce0: ldp             fp, lr, [SP], #0x10
    // 0x652ce4: ret
    //     0x652ce4: ret             
    // 0x652ce8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x652ce8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x652cec: b               #0x652cc8
  }
  _ dispose(/* No info */) {
    // ** addr: 0x65378c, size: 0x44
    // 0x65378c: EnterFrame
    //     0x65378c: stp             fp, lr, [SP, #-0x10]!
    //     0x653790: mov             fp, SP
    // 0x653794: CheckStackOverflow
    //     0x653794: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x653798: cmp             SP, x16
    //     0x65379c: b.ls            #0x6537c8
    // 0x6537a0: ldr             x0, [fp, #0x10]
    // 0x6537a4: LoadField: r1 = r0->field_2f
    //     0x6537a4: ldur            w1, [x0, #0x2f]
    // 0x6537a8: DecompressPointer r1
    //     0x6537a8: add             x1, x1, HEAP, lsl #32
    // 0x6537ac: stp             NULL, x1, [SP, #-0x10]!
    // 0x6537b0: r0 = layer=()
    //     0x6537b0: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x6537b4: add             SP, SP, #0x10
    // 0x6537b8: r0 = Null
    //     0x6537b8: mov             x0, NULL
    // 0x6537bc: LeaveFrame
    //     0x6537bc: mov             SP, fp
    //     0x6537c0: ldp             fp, lr, [SP], #0x10
    // 0x6537c4: ret
    //     0x6537c4: ret             
    // 0x6537c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6537c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6537cc: b               #0x6537a0
  }
  set _ layer=(/* No info */) {
    // ** addr: 0x661124, size: 0x48
    // 0x661124: EnterFrame
    //     0x661124: stp             fp, lr, [SP, #-0x10]!
    //     0x661128: mov             fp, SP
    // 0x66112c: CheckStackOverflow
    //     0x66112c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x661130: cmp             SP, x16
    //     0x661134: b.ls            #0x661164
    // 0x661138: ldr             x0, [fp, #0x18]
    // 0x66113c: LoadField: r1 = r0->field_2f
    //     0x66113c: ldur            w1, [x0, #0x2f]
    // 0x661140: DecompressPointer r1
    //     0x661140: add             x1, x1, HEAP, lsl #32
    // 0x661144: ldr             x16, [fp, #0x10]
    // 0x661148: stp             x16, x1, [SP, #-0x10]!
    // 0x66114c: r0 = layer=()
    //     0x66114c: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x661150: add             SP, SP, #0x10
    // 0x661154: r0 = Null
    //     0x661154: mov             x0, NULL
    // 0x661158: LeaveFrame
    //     0x661158: mov             SP, fp
    //     0x66115c: ldp             fp, lr, [SP], #0x10
    // 0x661160: ret
    //     0x661160: ret             
    // 0x661164: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x661164: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x661168: b               #0x661138
  }
  _ visitChildrenForSemantics(/* No info */) {
    // ** addr: 0x676a28, size: 0x58
    // 0x676a28: EnterFrame
    //     0x676a28: stp             fp, lr, [SP, #-0x10]!
    //     0x676a2c: mov             fp, SP
    // 0x676a30: CheckStackOverflow
    //     0x676a30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x676a34: cmp             SP, x16
    //     0x676a38: b.ls            #0x676a78
    // 0x676a3c: ldr             x0, [fp, #0x18]
    // 0x676a40: r1 = LoadClassIdInstr(r0)
    //     0x676a40: ldur            x1, [x0, #-1]
    //     0x676a44: ubfx            x1, x1, #0xc, #0x14
    // 0x676a48: ldr             x16, [fp, #0x10]
    // 0x676a4c: stp             x16, x0, [SP, #-0x10]!
    // 0x676a50: mov             x0, x1
    // 0x676a54: r0 = GDT[cid_x0 + 0xd2d5]()
    //     0x676a54: mov             x17, #0xd2d5
    //     0x676a58: add             lr, x0, x17
    //     0x676a5c: ldr             lr, [x21, lr, lsl #3]
    //     0x676a60: blr             lr
    // 0x676a64: add             SP, SP, #0x10
    // 0x676a68: r0 = Null
    //     0x676a68: mov             x0, NULL
    // 0x676a6c: LeaveFrame
    //     0x676a6c: mov             SP, fp
    //     0x676a70: ldp             fp, lr, [SP], #0x10
    // 0x676a74: ret
    //     0x676a74: ret             
    // 0x676a78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x676a78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x676a7c: b               #0x676a3c
  }
  _ invokeLayoutCallback(/* No info */) {
    // ** addr: 0x678254, size: 0x150
    // 0x678254: EnterFrame
    //     0x678254: stp             fp, lr, [SP, #-0x10]!
    //     0x678258: mov             fp, SP
    // 0x67825c: AllocStack(0x50)
    //     0x67825c: sub             SP, SP, #0x50
    // 0x678260: SetupParameters()
    //     0x678260: mov             x0, x4
    //     0x678264: ldur            w1, [x0, #0xf]
    //     0x678268: add             x1, x1, HEAP, lsl #32
    //     0x67826c: stur            x1, [fp, #-0x48]
    //     0x678270: cbnz            w1, #0x67827c
    //     0x678274: mov             x3, NULL
    //     0x678278: b               #0x678290
    //     0x67827c: ldur            w2, [x0, #0x17]
    //     0x678280: add             x2, x2, HEAP, lsl #32
    //     0x678284: add             x0, fp, w2, sxtw #2
    //     0x678288: ldr             x0, [x0, #0x10]
    //     0x67828c: mov             x3, x0
    //     0x678290: ldr             x2, [fp, #0x18]
    //     0x678294: ldr             x0, [fp, #0x10]
    //     0x678298: stur            x3, [fp, #-0x40]
    // 0x67829c: CheckStackOverflow
    //     0x67829c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6782a0: cmp             SP, x16
    //     0x6782a4: b.ls            #0x678398
    // 0x6782a8: r1 = 2
    //     0x6782a8: mov             x1, #2
    // 0x6782ac: r0 = AllocateContext()
    //     0x6782ac: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6782b0: mov             x4, x0
    // 0x6782b4: ldr             x3, [fp, #0x18]
    // 0x6782b8: stur            x4, [fp, #-0x50]
    // 0x6782bc: StoreField: r4->field_f = r3
    //     0x6782bc: stur            w3, [x4, #0xf]
    // 0x6782c0: ldr             x0, [fp, #0x10]
    // 0x6782c4: StoreField: r4->field_13 = r0
    //     0x6782c4: stur            w0, [x4, #0x13]
    // 0x6782c8: ldur            x0, [fp, #-0x48]
    // 0x6782cc: cbnz            w0, #0x6782dc
    // 0x6782d0: r5 = <Constraints>
    //     0x6782d0: add             x5, PP, #0x43, lsl #12  ; [pp+0x434b8] TypeArguments: <Constraints>
    //     0x6782d4: ldr             x5, [x5, #0x4b8]
    // 0x6782d8: b               #0x6782e0
    // 0x6782dc: ldur            x5, [fp, #-0x40]
    // 0x6782e0: r0 = true
    //     0x6782e0: add             x0, NULL, #0x20  ; true
    // 0x6782e4: stur            x5, [fp, #-0x48]
    // 0x6782e8: StoreField: r3->field_23 = r0
    //     0x6782e8: stur            w0, [x3, #0x23]
    // 0x6782ec: LoadField: r6 = r3->field_f
    //     0x6782ec: ldur            w6, [x3, #0xf]
    // 0x6782f0: DecompressPointer r6
    //     0x6782f0: add             x6, x6, HEAP, lsl #32
    // 0x6782f4: mov             x0, x6
    // 0x6782f8: stur            x6, [fp, #-0x40]
    // 0x6782fc: r2 = Null
    //     0x6782fc: mov             x2, NULL
    // 0x678300: r1 = Null
    //     0x678300: mov             x1, NULL
    // 0x678304: r4 = 59
    //     0x678304: mov             x4, #0x3b
    // 0x678308: branchIfSmi(r0, 0x678314)
    //     0x678308: tbz             w0, #0, #0x678314
    // 0x67830c: r4 = LoadClassIdInstr(r0)
    //     0x67830c: ldur            x4, [x0, #-1]
    //     0x678310: ubfx            x4, x4, #0xc, #0x14
    // 0x678314: cmp             x4, #0x7e6
    // 0x678318: b.eq            #0x67832c
    // 0x67831c: r8 = PipelineOwner?
    //     0x67831c: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x678320: r3 = Null
    //     0x678320: add             x3, PP, #0x43, lsl #12  ; [pp+0x434c0] Null
    //     0x678324: ldr             x3, [x3, #0x4c0]
    // 0x678328: r0 = DefaultNullableTypeTest()
    //     0x678328: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x67832c: ldur            x0, [fp, #-0x40]
    // 0x678330: cmp             w0, NULL
    // 0x678334: b.eq            #0x6783a0
    // 0x678338: ldur            x2, [fp, #-0x50]
    // 0x67833c: r1 = Function '<anonymous closure>':.
    //     0x67833c: add             x1, PP, #0x43, lsl #12  ; [pp+0x434d0] AnonymousClosure: (0x678414), in [package:flutter/src/rendering/object.dart] RenderObject::invokeLayoutCallback (0x678254)
    //     0x678340: ldr             x1, [x1, #0x4d0]
    // 0x678344: r0 = AllocateClosure()
    //     0x678344: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x678348: mov             x1, x0
    // 0x67834c: ldur            x0, [fp, #-0x48]
    // 0x678350: StoreField: r1->field_b = r0
    //     0x678350: stur            w0, [x1, #0xb]
    // 0x678354: ldur            x16, [fp, #-0x40]
    // 0x678358: stp             x1, x16, [SP, #-0x10]!
    // 0x67835c: r0 = _enableMutationsToDirtySubtrees()
    //     0x67835c: bl              #0x6783a4  ; [package:flutter/src/rendering/object.dart] PipelineOwner::_enableMutationsToDirtySubtrees
    // 0x678360: add             SP, SP, #0x10
    // 0x678364: ldr             x0, [fp, #0x18]
    // 0x678368: r2 = false
    //     0x678368: add             x2, NULL, #0x30  ; false
    // 0x67836c: StoreField: r0->field_23 = r2
    //     0x67836c: stur            w2, [x0, #0x23]
    // 0x678370: r0 = Null
    //     0x678370: mov             x0, NULL
    // 0x678374: LeaveFrame
    //     0x678374: mov             SP, fp
    //     0x678378: ldp             fp, lr, [SP], #0x10
    // 0x67837c: ret
    //     0x67837c: ret             
    // 0x678380: r2 = false
    //     0x678380: add             x2, NULL, #0x30  ; false
    // 0x678384: sub             SP, fp, #0x50
    // 0x678388: ldr             x3, [fp, #0x18]
    // 0x67838c: StoreField: r3->field_23 = r2
    //     0x67838c: stur            w2, [x3, #0x23]
    // 0x678390: r0 = ReThrow()
    //     0x678390: bl              #0xd67e14  ; ReThrowStub
    // 0x678394: brk             #0
    // 0x678398: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x678398: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x67839c: b               #0x6782a8
    // 0x6783a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6783a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x678414, size: 0xe0
    // 0x678414: EnterFrame
    //     0x678414: stp             fp, lr, [SP, #-0x10]!
    //     0x678418: mov             fp, SP
    // 0x67841c: AllocStack(0x10)
    //     0x67841c: sub             SP, SP, #0x10
    // 0x678420: SetupParameters()
    //     0x678420: ldr             x0, [fp, #0x10]
    //     0x678424: ldur            w1, [x0, #0x17]
    //     0x678428: add             x1, x1, HEAP, lsl #32
    // 0x67842c: CheckStackOverflow
    //     0x67842c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x678430: cmp             SP, x16
    //     0x678434: b.ls            #0x6784e8
    // 0x678438: LoadField: r2 = r0->field_b
    //     0x678438: ldur            w2, [x0, #0xb]
    // 0x67843c: DecompressPointer r2
    //     0x67843c: add             x2, x2, HEAP, lsl #32
    // 0x678440: stur            x2, [fp, #-0x10]
    // 0x678444: LoadField: r3 = r1->field_13
    //     0x678444: ldur            w3, [x1, #0x13]
    // 0x678448: DecompressPointer r3
    //     0x678448: add             x3, x3, HEAP, lsl #32
    // 0x67844c: stur            x3, [fp, #-8]
    // 0x678450: LoadField: r0 = r1->field_f
    //     0x678450: ldur            w0, [x1, #0xf]
    // 0x678454: DecompressPointer r0
    //     0x678454: add             x0, x0, HEAP, lsl #32
    // 0x678458: r1 = LoadClassIdInstr(r0)
    //     0x678458: ldur            x1, [x0, #-1]
    //     0x67845c: ubfx            x1, x1, #0xc, #0x14
    // 0x678460: SaveReg r0
    //     0x678460: str             x0, [SP, #-8]!
    // 0x678464: mov             x0, x1
    // 0x678468: r0 = GDT[cid_x0 + 0xecac]()
    //     0x678468: mov             x17, #0xecac
    //     0x67846c: add             lr, x0, x17
    //     0x678470: ldr             lr, [x21, lr, lsl #3]
    //     0x678474: blr             lr
    // 0x678478: add             SP, SP, #8
    // 0x67847c: ldur            x1, [fp, #-0x10]
    // 0x678480: mov             x3, x0
    // 0x678484: r2 = Null
    //     0x678484: mov             x2, NULL
    // 0x678488: stur            x3, [fp, #-0x10]
    // 0x67848c: cmp             w1, NULL
    // 0x678490: b.eq            #0x6784b4
    // 0x678494: LoadField: r4 = r1->field_17
    //     0x678494: ldur            w4, [x1, #0x17]
    // 0x678498: DecompressPointer r4
    //     0x678498: add             x4, x4, HEAP, lsl #32
    // 0x67849c: r8 = Y0 bound Constraints
    //     0x67849c: add             x8, PP, #0x43, lsl #12  ; [pp+0x434d8] TypeParameter: Y0 bound Constraints
    //     0x6784a0: ldr             x8, [x8, #0x4d8]
    // 0x6784a4: LoadField: r9 = r4->field_7
    //     0x6784a4: ldur            x9, [x4, #7]
    // 0x6784a8: r3 = Null
    //     0x6784a8: add             x3, PP, #0x43, lsl #12  ; [pp+0x434e0] Null
    //     0x6784ac: ldr             x3, [x3, #0x4e0]
    // 0x6784b0: blr             x9
    // 0x6784b4: ldur            x0, [fp, #-8]
    // 0x6784b8: cmp             w0, NULL
    // 0x6784bc: b.eq            #0x6784f0
    // 0x6784c0: ldur            x16, [fp, #-0x10]
    // 0x6784c4: stp             x16, x0, [SP, #-0x10]!
    // 0x6784c8: ClosureCall
    //     0x6784c8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6784cc: ldur            x2, [x0, #0x1f]
    //     0x6784d0: blr             x2
    // 0x6784d4: add             SP, SP, #0x10
    // 0x6784d8: r0 = Null
    //     0x6784d8: mov             x0, NULL
    // 0x6784dc: LeaveFrame
    //     0x6784dc: mov             SP, fp
    //     0x6784e0: ldp             fp, lr, [SP], #0x10
    // 0x6784e4: ret
    //     0x6784e4: ret             
    // 0x6784e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6784e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6784ec: b               #0x678438
    // 0x6784f0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x6784f0: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ updateCompositedLayer(/* No info */) {
    // ** addr: 0x6a4730, size: 0x90
    // 0x6a4730: EnterFrame
    //     0x6a4730: stp             fp, lr, [SP, #-0x10]!
    //     0x6a4734: mov             fp, SP
    // 0x6a4738: AllocStack(0x8)
    //     0x6a4738: sub             SP, SP, #8
    // 0x6a473c: CheckStackOverflow
    //     0x6a473c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6a4740: cmp             SP, x16
    //     0x6a4744: b.ls            #0x6a47b8
    // 0x6a4748: ldr             x0, [fp, #0x10]
    // 0x6a474c: r2 = Null
    //     0x6a474c: mov             x2, NULL
    // 0x6a4750: r1 = Null
    //     0x6a4750: mov             x1, NULL
    // 0x6a4754: r4 = 59
    //     0x6a4754: mov             x4, #0x3b
    // 0x6a4758: branchIfSmi(r0, 0x6a4764)
    //     0x6a4758: tbz             w0, #0, #0x6a4764
    // 0x6a475c: r4 = LoadClassIdInstr(r0)
    //     0x6a475c: ldur            x4, [x0, #-1]
    //     0x6a4760: ubfx            x4, x4, #0xc, #0x14
    // 0x6a4764: sub             x4, x4, #0x956
    // 0x6a4768: cmp             x4, #3
    // 0x6a476c: b.ls            #0x6a477c
    // 0x6a4770: r8 = OffsetLayer?
    //     0x6a4770: ldr             x8, [PP, #0x4a40]  ; [pp+0x4a40] Type: OffsetLayer?
    // 0x6a4774: r3 = Null
    //     0x6a4774: ldr             x3, [PP, #0x72d8]  ; [pp+0x72d8] Null
    // 0x6a4778: r0 = DefaultNullableTypeTest()
    //     0x6a4778: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x6a477c: ldr             x0, [fp, #0x10]
    // 0x6a4780: cmp             w0, NULL
    // 0x6a4784: b.ne            #0x6a47ac
    // 0x6a4788: r0 = OffsetLayer()
    //     0x6a4788: bl              #0x6683f8  ; AllocateOffsetLayerStub -> OffsetLayer (size=0x4c)
    // 0x6a478c: mov             x1, x0
    // 0x6a4790: r0 = Instance_Offset
    //     0x6a4790: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x6a4794: stur            x1, [fp, #-8]
    // 0x6a4798: StoreField: r1->field_47 = r0
    //     0x6a4798: stur            w0, [x1, #0x47]
    // 0x6a479c: SaveReg r1
    //     0x6a479c: str             x1, [SP, #-8]!
    // 0x6a47a0: r0 = Layer()
    //     0x6a47a0: bl              #0x5bbe7c  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0x6a47a4: add             SP, SP, #8
    // 0x6a47a8: ldur            x0, [fp, #-8]
    // 0x6a47ac: LeaveFrame
    //     0x6a47ac: mov             SP, fp
    //     0x6a47b0: ldp             fp, lr, [SP], #0x10
    // 0x6a47b4: ret
    //     0x6a47b4: ret             
    // 0x6a47b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a47b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a47bc: b               #0x6a4748
  }
  dynamic showOnScreen(dynamic) {
    // ** addr: 0x6abc3c, size: 0x18
    // 0x6abc3c: r4 = 0
    //     0x6abc3c: mov             x4, #0
    // 0x6abc40: r1 = Function 'showOnScreen':.
    //     0x6abc40: add             x17, PP, #0xa, lsl #12  ; [pp+0xafb8] AnonymousClosure: (0x644eec), in [package:flutter/src/rendering/object.dart] RenderObject::showOnScreen (0x644c40)
    //     0x6abc44: ldr             x1, [x17, #0xfb8]
    // 0x6abc48: r24 = BuildNonGenericMethodExtractorStub
    //     0x6abc48: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x6abc4c: LoadField: r0 = r24->field_17
    //     0x6abc4c: ldur            x0, [x24, #0x17]
    // 0x6abc50: br              x0
  }
  _ markNeedsPaint(/* No info */) {
    // ** addr: 0x6bf200, size: 0x318
    // 0x6bf200: EnterFrame
    //     0x6bf200: stp             fp, lr, [SP, #-0x10]!
    //     0x6bf204: mov             fp, SP
    // 0x6bf208: AllocStack(0x10)
    //     0x6bf208: sub             SP, SP, #0x10
    // 0x6bf20c: CheckStackOverflow
    //     0x6bf20c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bf210: cmp             SP, x16
    //     0x6bf214: b.ls            #0x6bf4fc
    // 0x6bf218: ldr             x1, [fp, #0x10]
    // 0x6bf21c: LoadField: r0 = r1->field_3b
    //     0x6bf21c: ldur            w0, [x1, #0x3b]
    // 0x6bf220: DecompressPointer r0
    //     0x6bf220: add             x0, x0, HEAP, lsl #32
    // 0x6bf224: tbnz            w0, #4, #0x6bf238
    // 0x6bf228: r0 = Null
    //     0x6bf228: mov             x0, NULL
    // 0x6bf22c: LeaveFrame
    //     0x6bf22c: mov             SP, fp
    //     0x6bf230: ldp             fp, lr, [SP], #0x10
    // 0x6bf234: ret
    //     0x6bf234: ret             
    // 0x6bf238: r0 = true
    //     0x6bf238: add             x0, NULL, #0x20  ; true
    // 0x6bf23c: StoreField: r1->field_3b = r0
    //     0x6bf23c: stur            w0, [x1, #0x3b]
    // 0x6bf240: r0 = LoadClassIdInstr(r1)
    //     0x6bf240: ldur            x0, [x1, #-1]
    //     0x6bf244: ubfx            x0, x0, #0xc, #0x14
    // 0x6bf248: SaveReg r1
    //     0x6bf248: str             x1, [SP, #-8]!
    // 0x6bf24c: r0 = GDT[cid_x0 + 0xd14d]()
    //     0x6bf24c: mov             x17, #0xd14d
    //     0x6bf250: add             lr, x0, x17
    //     0x6bf254: ldr             lr, [x21, lr, lsl #3]
    //     0x6bf258: blr             lr
    // 0x6bf25c: add             SP, SP, #8
    // 0x6bf260: tbnz            w0, #4, #0x6bf3b8
    // 0x6bf264: ldr             x3, [fp, #0x10]
    // 0x6bf268: LoadField: r0 = r3->field_2b
    //     0x6bf268: ldur            w0, [x3, #0x2b]
    // 0x6bf26c: DecompressPointer r0
    //     0x6bf26c: add             x0, x0, HEAP, lsl #32
    // 0x6bf270: r16 = Sentinel
    //     0x6bf270: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6bf274: cmp             w0, w16
    // 0x6bf278: b.eq            #0x6bf504
    // 0x6bf27c: tbnz            w0, #4, #0x6bf3bc
    // 0x6bf280: LoadField: r4 = r3->field_f
    //     0x6bf280: ldur            w4, [x3, #0xf]
    // 0x6bf284: DecompressPointer r4
    //     0x6bf284: add             x4, x4, HEAP, lsl #32
    // 0x6bf288: mov             x0, x4
    // 0x6bf28c: stur            x4, [fp, #-8]
    // 0x6bf290: r2 = Null
    //     0x6bf290: mov             x2, NULL
    // 0x6bf294: r1 = Null
    //     0x6bf294: mov             x1, NULL
    // 0x6bf298: r4 = 59
    //     0x6bf298: mov             x4, #0x3b
    // 0x6bf29c: branchIfSmi(r0, 0x6bf2a8)
    //     0x6bf29c: tbz             w0, #0, #0x6bf2a8
    // 0x6bf2a0: r4 = LoadClassIdInstr(r0)
    //     0x6bf2a0: ldur            x4, [x0, #-1]
    //     0x6bf2a4: ubfx            x4, x4, #0xc, #0x14
    // 0x6bf2a8: cmp             x4, #0x7e6
    // 0x6bf2ac: b.eq            #0x6bf2bc
    // 0x6bf2b0: r8 = PipelineOwner?
    //     0x6bf2b0: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x6bf2b4: r3 = Null
    //     0x6bf2b4: ldr             x3, [PP, #0x4c60]  ; [pp+0x4c60] Null
    // 0x6bf2b8: r0 = DefaultNullableTypeTest()
    //     0x6bf2b8: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x6bf2bc: ldur            x0, [fp, #-8]
    // 0x6bf2c0: cmp             w0, NULL
    // 0x6bf2c4: b.eq            #0x6bf4ec
    // 0x6bf2c8: LoadField: r1 = r0->field_27
    //     0x6bf2c8: ldur            w1, [x0, #0x27]
    // 0x6bf2cc: DecompressPointer r1
    //     0x6bf2cc: add             x1, x1, HEAP, lsl #32
    // 0x6bf2d0: stur            x1, [fp, #-0x10]
    // 0x6bf2d4: LoadField: r0 = r1->field_b
    //     0x6bf2d4: ldur            w0, [x1, #0xb]
    // 0x6bf2d8: DecompressPointer r0
    //     0x6bf2d8: add             x0, x0, HEAP, lsl #32
    // 0x6bf2dc: stur            x0, [fp, #-8]
    // 0x6bf2e0: LoadField: r2 = r1->field_f
    //     0x6bf2e0: ldur            w2, [x1, #0xf]
    // 0x6bf2e4: DecompressPointer r2
    //     0x6bf2e4: add             x2, x2, HEAP, lsl #32
    // 0x6bf2e8: LoadField: r3 = r2->field_b
    //     0x6bf2e8: ldur            w3, [x2, #0xb]
    // 0x6bf2ec: DecompressPointer r3
    //     0x6bf2ec: add             x3, x3, HEAP, lsl #32
    // 0x6bf2f0: cmp             w0, w3
    // 0x6bf2f4: b.ne            #0x6bf304
    // 0x6bf2f8: SaveReg r1
    //     0x6bf2f8: str             x1, [SP, #-8]!
    // 0x6bf2fc: r0 = _growToNextCapacity()
    //     0x6bf2fc: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6bf300: add             SP, SP, #8
    // 0x6bf304: ldr             x3, [fp, #0x10]
    // 0x6bf308: ldur            x2, [fp, #-0x10]
    // 0x6bf30c: ldur            x0, [fp, #-8]
    // 0x6bf310: r4 = LoadInt32Instr(r0)
    //     0x6bf310: sbfx            x4, x0, #1, #0x1f
    // 0x6bf314: add             x0, x4, #1
    // 0x6bf318: lsl             x1, x0, #1
    // 0x6bf31c: StoreField: r2->field_b = r1
    //     0x6bf31c: stur            w1, [x2, #0xb]
    // 0x6bf320: mov             x1, x4
    // 0x6bf324: cmp             x1, x0
    // 0x6bf328: b.hs            #0x6bf50c
    // 0x6bf32c: LoadField: r1 = r2->field_f
    //     0x6bf32c: ldur            w1, [x2, #0xf]
    // 0x6bf330: DecompressPointer r1
    //     0x6bf330: add             x1, x1, HEAP, lsl #32
    // 0x6bf334: mov             x0, x3
    // 0x6bf338: ArrayStore: r1[r4] = r0  ; List_4
    //     0x6bf338: add             x25, x1, x4, lsl #2
    //     0x6bf33c: add             x25, x25, #0xf
    //     0x6bf340: str             w0, [x25]
    //     0x6bf344: tbz             w0, #0, #0x6bf360
    //     0x6bf348: ldurb           w16, [x1, #-1]
    //     0x6bf34c: ldurb           w17, [x0, #-1]
    //     0x6bf350: and             x16, x17, x16, lsr #2
    //     0x6bf354: tst             x16, HEAP, lsr #32
    //     0x6bf358: b.eq            #0x6bf360
    //     0x6bf35c: bl              #0xd67e5c
    // 0x6bf360: LoadField: r4 = r3->field_f
    //     0x6bf360: ldur            w4, [x3, #0xf]
    // 0x6bf364: DecompressPointer r4
    //     0x6bf364: add             x4, x4, HEAP, lsl #32
    // 0x6bf368: mov             x0, x4
    // 0x6bf36c: stur            x4, [fp, #-8]
    // 0x6bf370: r2 = Null
    //     0x6bf370: mov             x2, NULL
    // 0x6bf374: r1 = Null
    //     0x6bf374: mov             x1, NULL
    // 0x6bf378: r4 = 59
    //     0x6bf378: mov             x4, #0x3b
    // 0x6bf37c: branchIfSmi(r0, 0x6bf388)
    //     0x6bf37c: tbz             w0, #0, #0x6bf388
    // 0x6bf380: r4 = LoadClassIdInstr(r0)
    //     0x6bf380: ldur            x4, [x0, #-1]
    //     0x6bf384: ubfx            x4, x4, #0xc, #0x14
    // 0x6bf388: cmp             x4, #0x7e6
    // 0x6bf38c: b.eq            #0x6bf39c
    // 0x6bf390: r8 = PipelineOwner?
    //     0x6bf390: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x6bf394: r3 = Null
    //     0x6bf394: ldr             x3, [PP, #0x4c70]  ; [pp+0x4c70] Null
    // 0x6bf398: r0 = DefaultNullableTypeTest()
    //     0x6bf398: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x6bf39c: ldur            x0, [fp, #-8]
    // 0x6bf3a0: cmp             w0, NULL
    // 0x6bf3a4: b.eq            #0x6bf510
    // 0x6bf3a8: SaveReg r0
    //     0x6bf3a8: str             x0, [SP, #-8]!
    // 0x6bf3ac: r0 = requestVisualUpdate()
    //     0x6bf3ac: bl              #0x50fd88  ; [package:flutter/src/rendering/object.dart] PipelineOwner::requestVisualUpdate
    // 0x6bf3b0: add             SP, SP, #8
    // 0x6bf3b4: b               #0x6bf4ec
    // 0x6bf3b8: ldr             x3, [fp, #0x10]
    // 0x6bf3bc: r0 = LoadClassIdInstr(r3)
    //     0x6bf3bc: ldur            x0, [x3, #-1]
    //     0x6bf3c0: ubfx            x0, x0, #0xc, #0x14
    // 0x6bf3c4: SaveReg r3
    //     0x6bf3c4: str             x3, [SP, #-8]!
    // 0x6bf3c8: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0x6bf3c8: mov             x17, #0xa2f1
    //     0x6bf3cc: add             lr, x0, x17
    //     0x6bf3d0: ldr             lr, [x21, lr, lsl #3]
    //     0x6bf3d4: blr             lr
    // 0x6bf3d8: add             SP, SP, #8
    // 0x6bf3dc: r1 = LoadClassIdInstr(r0)
    //     0x6bf3dc: ldur            x1, [x0, #-1]
    //     0x6bf3e0: ubfx            x1, x1, #0xc, #0x14
    // 0x6bf3e4: lsl             x1, x1, #1
    // 0x6bf3e8: r0 = LoadInt32Instr(r1)
    //     0x6bf3e8: sbfx            x0, x1, #1, #0x1f
    // 0x6bf3ec: cmp             x0, #0x961
    // 0x6bf3f0: b.lt            #0x6bf494
    // 0x6bf3f4: cmp             x0, #0xa1f
    // 0x6bf3f8: b.gt            #0x6bf48c
    // 0x6bf3fc: ldr             x0, [fp, #0x10]
    // 0x6bf400: r1 = LoadClassIdInstr(r0)
    //     0x6bf400: ldur            x1, [x0, #-1]
    //     0x6bf404: ubfx            x1, x1, #0xc, #0x14
    // 0x6bf408: SaveReg r0
    //     0x6bf408: str             x0, [SP, #-8]!
    // 0x6bf40c: mov             x0, x1
    // 0x6bf410: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0x6bf410: mov             x17, #0xa2f1
    //     0x6bf414: add             lr, x0, x17
    //     0x6bf418: ldr             lr, [x21, lr, lsl #3]
    //     0x6bf41c: blr             lr
    // 0x6bf420: add             SP, SP, #8
    // 0x6bf424: mov             x3, x0
    // 0x6bf428: stur            x3, [fp, #-8]
    // 0x6bf42c: cmp             w3, NULL
    // 0x6bf430: b.eq            #0x6bf514
    // 0x6bf434: mov             x0, x3
    // 0x6bf438: r2 = Null
    //     0x6bf438: mov             x2, NULL
    // 0x6bf43c: r1 = Null
    //     0x6bf43c: mov             x1, NULL
    // 0x6bf440: r4 = LoadClassIdInstr(r0)
    //     0x6bf440: ldur            x4, [x0, #-1]
    //     0x6bf444: ubfx            x4, x4, #0xc, #0x14
    // 0x6bf448: sub             x4, x4, #0x961
    // 0x6bf44c: cmp             x4, #0xbe
    // 0x6bf450: b.ls            #0x6bf460
    // 0x6bf454: r8 = RenderObject
    //     0x6bf454: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x6bf458: r3 = Null
    //     0x6bf458: ldr             x3, [PP, #0x4c80]  ; [pp+0x4c80] Null
    // 0x6bf45c: r0 = RenderObject()
    //     0x6bf45c: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x6bf460: ldur            x0, [fp, #-8]
    // 0x6bf464: r1 = LoadClassIdInstr(r0)
    //     0x6bf464: ldur            x1, [x0, #-1]
    //     0x6bf468: ubfx            x1, x1, #0xc, #0x14
    // 0x6bf46c: SaveReg r0
    //     0x6bf46c: str             x0, [SP, #-8]!
    // 0x6bf470: mov             x0, x1
    // 0x6bf474: r0 = GDT[cid_x0 + 0xd3b6]()
    //     0x6bf474: mov             x17, #0xd3b6
    //     0x6bf478: add             lr, x0, x17
    //     0x6bf47c: ldr             lr, [x21, lr, lsl #3]
    //     0x6bf480: blr             lr
    // 0x6bf484: add             SP, SP, #8
    // 0x6bf488: b               #0x6bf4ec
    // 0x6bf48c: ldr             x0, [fp, #0x10]
    // 0x6bf490: b               #0x6bf498
    // 0x6bf494: ldr             x0, [fp, #0x10]
    // 0x6bf498: LoadField: r3 = r0->field_f
    //     0x6bf498: ldur            w3, [x0, #0xf]
    // 0x6bf49c: DecompressPointer r3
    //     0x6bf49c: add             x3, x3, HEAP, lsl #32
    // 0x6bf4a0: mov             x0, x3
    // 0x6bf4a4: stur            x3, [fp, #-8]
    // 0x6bf4a8: r2 = Null
    //     0x6bf4a8: mov             x2, NULL
    // 0x6bf4ac: r1 = Null
    //     0x6bf4ac: mov             x1, NULL
    // 0x6bf4b0: r4 = 59
    //     0x6bf4b0: mov             x4, #0x3b
    // 0x6bf4b4: branchIfSmi(r0, 0x6bf4c0)
    //     0x6bf4b4: tbz             w0, #0, #0x6bf4c0
    // 0x6bf4b8: r4 = LoadClassIdInstr(r0)
    //     0x6bf4b8: ldur            x4, [x0, #-1]
    //     0x6bf4bc: ubfx            x4, x4, #0xc, #0x14
    // 0x6bf4c0: cmp             x4, #0x7e6
    // 0x6bf4c4: b.eq            #0x6bf4d4
    // 0x6bf4c8: r8 = PipelineOwner?
    //     0x6bf4c8: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x6bf4cc: r3 = Null
    //     0x6bf4cc: ldr             x3, [PP, #0x4c90]  ; [pp+0x4c90] Null
    // 0x6bf4d0: r0 = DefaultNullableTypeTest()
    //     0x6bf4d0: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x6bf4d4: ldur            x0, [fp, #-8]
    // 0x6bf4d8: cmp             w0, NULL
    // 0x6bf4dc: b.eq            #0x6bf4ec
    // 0x6bf4e0: SaveReg r0
    //     0x6bf4e0: str             x0, [SP, #-8]!
    // 0x6bf4e4: r0 = requestVisualUpdate()
    //     0x6bf4e4: bl              #0x50fd88  ; [package:flutter/src/rendering/object.dart] PipelineOwner::requestVisualUpdate
    // 0x6bf4e8: add             SP, SP, #8
    // 0x6bf4ec: r0 = Null
    //     0x6bf4ec: mov             x0, NULL
    // 0x6bf4f0: LeaveFrame
    //     0x6bf4f0: mov             SP, fp
    //     0x6bf4f4: ldp             fp, lr, [SP], #0x10
    // 0x6bf4f8: ret
    //     0x6bf4f8: ret             
    // 0x6bf4fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bf4fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bf500: b               #0x6bf218
    // 0x6bf504: r9 = _wasRepaintBoundary
    //     0x6bf504: ldr             x9, [PP, #0x4b30]  ; [pp+0x4b30] Field <RenderObject._wasRepaintBoundary@904266271>: late (offset: 0x2c)
    // 0x6bf508: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6bf508: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6bf50c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6bf50c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6bf510: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6bf510: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6bf514: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6bf514: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ markNeedsLayout(/* No info */) {
    // ** addr: 0x6c0ee8, size: 0x238
    // 0x6c0ee8: EnterFrame
    //     0x6c0ee8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c0eec: mov             fp, SP
    // 0x6c0ef0: AllocStack(0x10)
    //     0x6c0ef0: sub             SP, SP, #0x10
    // 0x6c0ef4: CheckStackOverflow
    //     0x6c0ef4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c0ef8: cmp             SP, x16
    //     0x6c0efc: b.ls            #0x6c1110
    // 0x6c0f00: ldr             x1, [fp, #0x10]
    // 0x6c0f04: LoadField: r0 = r1->field_1b
    //     0x6c0f04: ldur            w0, [x1, #0x1b]
    // 0x6c0f08: DecompressPointer r0
    //     0x6c0f08: add             x0, x0, HEAP, lsl #32
    // 0x6c0f0c: tbnz            w0, #4, #0x6c0f20
    // 0x6c0f10: r0 = Null
    //     0x6c0f10: mov             x0, NULL
    // 0x6c0f14: LeaveFrame
    //     0x6c0f14: mov             SP, fp
    //     0x6c0f18: ldp             fp, lr, [SP], #0x10
    // 0x6c0f1c: ret
    //     0x6c0f1c: ret             
    // 0x6c0f20: LoadField: r0 = r1->field_1f
    //     0x6c0f20: ldur            w0, [x1, #0x1f]
    // 0x6c0f24: DecompressPointer r0
    //     0x6c0f24: add             x0, x0, HEAP, lsl #32
    // 0x6c0f28: cmp             w0, NULL
    // 0x6c0f2c: b.ne            #0x6c0f80
    // 0x6c0f30: r2 = true
    //     0x6c0f30: add             x2, NULL, #0x20  ; true
    // 0x6c0f34: StoreField: r1->field_1b = r2
    //     0x6c0f34: stur            w2, [x1, #0x1b]
    // 0x6c0f38: r0 = LoadClassIdInstr(r1)
    //     0x6c0f38: ldur            x0, [x1, #-1]
    //     0x6c0f3c: ubfx            x0, x0, #0xc, #0x14
    // 0x6c0f40: SaveReg r1
    //     0x6c0f40: str             x1, [SP, #-8]!
    // 0x6c0f44: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0x6c0f44: mov             x17, #0xa2f1
    //     0x6c0f48: add             lr, x0, x17
    //     0x6c0f4c: ldr             lr, [x21, lr, lsl #3]
    //     0x6c0f50: blr             lr
    // 0x6c0f54: add             SP, SP, #8
    // 0x6c0f58: cmp             w0, NULL
    // 0x6c0f5c: b.eq            #0x6c0f70
    // 0x6c0f60: ldr             x16, [fp, #0x10]
    // 0x6c0f64: SaveReg r16
    //     0x6c0f64: str             x16, [SP, #-8]!
    // 0x6c0f68: r0 = markParentNeedsLayout()
    //     0x6c0f68: bl              #0x5ae148  ; [package:flutter/src/rendering/object.dart] RenderObject::markParentNeedsLayout
    // 0x6c0f6c: add             SP, SP, #8
    // 0x6c0f70: r0 = Null
    //     0x6c0f70: mov             x0, NULL
    // 0x6c0f74: LeaveFrame
    //     0x6c0f74: mov             SP, fp
    //     0x6c0f78: ldp             fp, lr, [SP], #0x10
    // 0x6c0f7c: ret
    //     0x6c0f7c: ret             
    // 0x6c0f80: r2 = true
    //     0x6c0f80: add             x2, NULL, #0x20  ; true
    // 0x6c0f84: r1 = LoadClassIdInstr(r0)
    //     0x6c0f84: ldur            x1, [x0, #-1]
    //     0x6c0f88: ubfx            x1, x1, #0xc, #0x14
    // 0x6c0f8c: ldr             x16, [fp, #0x10]
    // 0x6c0f90: stp             x16, x0, [SP, #-0x10]!
    // 0x6c0f94: mov             x0, x1
    // 0x6c0f98: mov             lr, x0
    // 0x6c0f9c: ldr             lr, [x21, lr, lsl #3]
    // 0x6c0fa0: blr             lr
    // 0x6c0fa4: add             SP, SP, #0x10
    // 0x6c0fa8: tbz             w0, #4, #0x6c0fc0
    // 0x6c0fac: ldr             x16, [fp, #0x10]
    // 0x6c0fb0: SaveReg r16
    //     0x6c0fb0: str             x16, [SP, #-8]!
    // 0x6c0fb4: r0 = markParentNeedsLayout()
    //     0x6c0fb4: bl              #0x5ae148  ; [package:flutter/src/rendering/object.dart] RenderObject::markParentNeedsLayout
    // 0x6c0fb8: add             SP, SP, #8
    // 0x6c0fbc: b               #0x6c1100
    // 0x6c0fc0: ldr             x3, [fp, #0x10]
    // 0x6c0fc4: r0 = true
    //     0x6c0fc4: add             x0, NULL, #0x20  ; true
    // 0x6c0fc8: StoreField: r3->field_1b = r0
    //     0x6c0fc8: stur            w0, [x3, #0x1b]
    // 0x6c0fcc: LoadField: r4 = r3->field_f
    //     0x6c0fcc: ldur            w4, [x3, #0xf]
    // 0x6c0fd0: DecompressPointer r4
    //     0x6c0fd0: add             x4, x4, HEAP, lsl #32
    // 0x6c0fd4: mov             x0, x4
    // 0x6c0fd8: stur            x4, [fp, #-8]
    // 0x6c0fdc: r2 = Null
    //     0x6c0fdc: mov             x2, NULL
    // 0x6c0fe0: r1 = Null
    //     0x6c0fe0: mov             x1, NULL
    // 0x6c0fe4: r4 = 59
    //     0x6c0fe4: mov             x4, #0x3b
    // 0x6c0fe8: branchIfSmi(r0, 0x6c0ff4)
    //     0x6c0fe8: tbz             w0, #0, #0x6c0ff4
    // 0x6c0fec: r4 = LoadClassIdInstr(r0)
    //     0x6c0fec: ldur            x4, [x0, #-1]
    //     0x6c0ff0: ubfx            x4, x4, #0xc, #0x14
    // 0x6c0ff4: cmp             x4, #0x7e6
    // 0x6c0ff8: b.eq            #0x6c1008
    // 0x6c0ffc: r8 = PipelineOwner?
    //     0x6c0ffc: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x6c1000: r3 = Null
    //     0x6c1000: ldr             x3, [PP, #0x4c30]  ; [pp+0x4c30] Null
    // 0x6c1004: r0 = DefaultNullableTypeTest()
    //     0x6c1004: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x6c1008: ldur            x0, [fp, #-8]
    // 0x6c100c: cmp             w0, NULL
    // 0x6c1010: b.eq            #0x6c1100
    // 0x6c1014: LoadField: r1 = r0->field_1f
    //     0x6c1014: ldur            w1, [x0, #0x1f]
    // 0x6c1018: DecompressPointer r1
    //     0x6c1018: add             x1, x1, HEAP, lsl #32
    // 0x6c101c: stur            x1, [fp, #-0x10]
    // 0x6c1020: LoadField: r0 = r1->field_b
    //     0x6c1020: ldur            w0, [x1, #0xb]
    // 0x6c1024: DecompressPointer r0
    //     0x6c1024: add             x0, x0, HEAP, lsl #32
    // 0x6c1028: stur            x0, [fp, #-8]
    // 0x6c102c: LoadField: r2 = r1->field_f
    //     0x6c102c: ldur            w2, [x1, #0xf]
    // 0x6c1030: DecompressPointer r2
    //     0x6c1030: add             x2, x2, HEAP, lsl #32
    // 0x6c1034: LoadField: r3 = r2->field_b
    //     0x6c1034: ldur            w3, [x2, #0xb]
    // 0x6c1038: DecompressPointer r3
    //     0x6c1038: add             x3, x3, HEAP, lsl #32
    // 0x6c103c: cmp             w0, w3
    // 0x6c1040: b.ne            #0x6c1050
    // 0x6c1044: SaveReg r1
    //     0x6c1044: str             x1, [SP, #-8]!
    // 0x6c1048: r0 = _growToNextCapacity()
    //     0x6c1048: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6c104c: add             SP, SP, #8
    // 0x6c1050: ldr             x3, [fp, #0x10]
    // 0x6c1054: ldur            x2, [fp, #-0x10]
    // 0x6c1058: ldur            x0, [fp, #-8]
    // 0x6c105c: r4 = LoadInt32Instr(r0)
    //     0x6c105c: sbfx            x4, x0, #1, #0x1f
    // 0x6c1060: add             x0, x4, #1
    // 0x6c1064: lsl             x1, x0, #1
    // 0x6c1068: StoreField: r2->field_b = r1
    //     0x6c1068: stur            w1, [x2, #0xb]
    // 0x6c106c: mov             x1, x4
    // 0x6c1070: cmp             x1, x0
    // 0x6c1074: b.hs            #0x6c1118
    // 0x6c1078: LoadField: r1 = r2->field_f
    //     0x6c1078: ldur            w1, [x2, #0xf]
    // 0x6c107c: DecompressPointer r1
    //     0x6c107c: add             x1, x1, HEAP, lsl #32
    // 0x6c1080: mov             x0, x3
    // 0x6c1084: ArrayStore: r1[r4] = r0  ; List_4
    //     0x6c1084: add             x25, x1, x4, lsl #2
    //     0x6c1088: add             x25, x25, #0xf
    //     0x6c108c: str             w0, [x25]
    //     0x6c1090: tbz             w0, #0, #0x6c10ac
    //     0x6c1094: ldurb           w16, [x1, #-1]
    //     0x6c1098: ldurb           w17, [x0, #-1]
    //     0x6c109c: and             x16, x17, x16, lsr #2
    //     0x6c10a0: tst             x16, HEAP, lsr #32
    //     0x6c10a4: b.eq            #0x6c10ac
    //     0x6c10a8: bl              #0xd67e5c
    // 0x6c10ac: LoadField: r4 = r3->field_f
    //     0x6c10ac: ldur            w4, [x3, #0xf]
    // 0x6c10b0: DecompressPointer r4
    //     0x6c10b0: add             x4, x4, HEAP, lsl #32
    // 0x6c10b4: mov             x0, x4
    // 0x6c10b8: stur            x4, [fp, #-8]
    // 0x6c10bc: r2 = Null
    //     0x6c10bc: mov             x2, NULL
    // 0x6c10c0: r1 = Null
    //     0x6c10c0: mov             x1, NULL
    // 0x6c10c4: r4 = 59
    //     0x6c10c4: mov             x4, #0x3b
    // 0x6c10c8: branchIfSmi(r0, 0x6c10d4)
    //     0x6c10c8: tbz             w0, #0, #0x6c10d4
    // 0x6c10cc: r4 = LoadClassIdInstr(r0)
    //     0x6c10cc: ldur            x4, [x0, #-1]
    //     0x6c10d0: ubfx            x4, x4, #0xc, #0x14
    // 0x6c10d4: cmp             x4, #0x7e6
    // 0x6c10d8: b.eq            #0x6c10e8
    // 0x6c10dc: r8 = PipelineOwner?
    //     0x6c10dc: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x6c10e0: r3 = Null
    //     0x6c10e0: ldr             x3, [PP, #0x4c40]  ; [pp+0x4c40] Null
    // 0x6c10e4: r0 = DefaultNullableTypeTest()
    //     0x6c10e4: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x6c10e8: ldur            x0, [fp, #-8]
    // 0x6c10ec: cmp             w0, NULL
    // 0x6c10f0: b.eq            #0x6c111c
    // 0x6c10f4: SaveReg r0
    //     0x6c10f4: str             x0, [SP, #-8]!
    // 0x6c10f8: r0 = requestVisualUpdate()
    //     0x6c10f8: bl              #0x50fd88  ; [package:flutter/src/rendering/object.dart] PipelineOwner::requestVisualUpdate
    // 0x6c10fc: add             SP, SP, #8
    // 0x6c1100: r0 = Null
    //     0x6c1100: mov             x0, NULL
    // 0x6c1104: LeaveFrame
    //     0x6c1104: mov             SP, fp
    //     0x6c1108: ldp             fp, lr, [SP], #0x10
    // 0x6c110c: ret
    //     0x6c110c: ret             
    // 0x6c1110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c1110: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c1114: b               #0x6c0f00
    // 0x6c1118: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6c1118: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6c111c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6c111c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ markNeedsLayoutForSizedByParentChange(/* No info */) {
    // ** addr: 0x6c63ec, size: 0x4c
    // 0x6c63ec: EnterFrame
    //     0x6c63ec: stp             fp, lr, [SP, #-0x10]!
    //     0x6c63f0: mov             fp, SP
    // 0x6c63f4: CheckStackOverflow
    //     0x6c63f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c63f8: cmp             SP, x16
    //     0x6c63fc: b.ls            #0x6c6430
    // 0x6c6400: ldr             x16, [fp, #0x10]
    // 0x6c6404: SaveReg r16
    //     0x6c6404: str             x16, [SP, #-8]!
    // 0x6c6408: r0 = markNeedsLayout()
    //     0x6c6408: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c640c: add             SP, SP, #8
    // 0x6c6410: ldr             x16, [fp, #0x10]
    // 0x6c6414: SaveReg r16
    //     0x6c6414: str             x16, [SP, #-8]!
    // 0x6c6418: r0 = markParentNeedsLayout()
    //     0x6c6418: bl              #0x5ae148  ; [package:flutter/src/rendering/object.dart] RenderObject::markParentNeedsLayout
    // 0x6c641c: add             SP, SP, #8
    // 0x6c6420: r0 = Null
    //     0x6c6420: mov             x0, NULL
    // 0x6c6424: LeaveFrame
    //     0x6c6424: mov             SP, fp
    //     0x6c6428: ldp             fp, lr, [SP], #0x10
    // 0x6c642c: ret
    //     0x6c642c: ret             
    // 0x6c6430: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6430: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c6434: b               #0x6c6400
  }
  _ markNeedsCompositedLayerUpdate(/* No info */) {
    // ** addr: 0x6c9228, size: 0x1f0
    // 0x6c9228: EnterFrame
    //     0x6c9228: stp             fp, lr, [SP, #-0x10]!
    //     0x6c922c: mov             fp, SP
    // 0x6c9230: AllocStack(0x10)
    //     0x6c9230: sub             SP, SP, #0x10
    // 0x6c9234: CheckStackOverflow
    //     0x6c9234: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c9238: cmp             SP, x16
    //     0x6c923c: b.ls            #0x6c9400
    // 0x6c9240: ldr             x0, [fp, #0x10]
    // 0x6c9244: LoadField: r1 = r0->field_3f
    //     0x6c9244: ldur            w1, [x0, #0x3f]
    // 0x6c9248: DecompressPointer r1
    //     0x6c9248: add             x1, x1, HEAP, lsl #32
    // 0x6c924c: tbz             w1, #4, #0x6c925c
    // 0x6c9250: LoadField: r1 = r0->field_3b
    //     0x6c9250: ldur            w1, [x0, #0x3b]
    // 0x6c9254: DecompressPointer r1
    //     0x6c9254: add             x1, x1, HEAP, lsl #32
    // 0x6c9258: tbnz            w1, #4, #0x6c926c
    // 0x6c925c: r0 = Null
    //     0x6c925c: mov             x0, NULL
    // 0x6c9260: LeaveFrame
    //     0x6c9260: mov             SP, fp
    //     0x6c9264: ldp             fp, lr, [SP], #0x10
    // 0x6c9268: ret
    //     0x6c9268: ret             
    // 0x6c926c: r1 = true
    //     0x6c926c: add             x1, NULL, #0x20  ; true
    // 0x6c9270: StoreField: r0->field_3f = r1
    //     0x6c9270: stur            w1, [x0, #0x3f]
    // 0x6c9274: SaveReg r0
    //     0x6c9274: str             x0, [SP, #-8]!
    // 0x6c9278: r0 = isRepaintBoundary()
    //     0x6c9278: bl              #0x6c0be8  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin&RenderAnimatedOpacityMixin::isRepaintBoundary
    // 0x6c927c: add             SP, SP, #8
    // 0x6c9280: tbnz            w0, #4, #0x6c93e0
    // 0x6c9284: ldr             x3, [fp, #0x10]
    // 0x6c9288: LoadField: r0 = r3->field_2b
    //     0x6c9288: ldur            w0, [x3, #0x2b]
    // 0x6c928c: DecompressPointer r0
    //     0x6c928c: add             x0, x0, HEAP, lsl #32
    // 0x6c9290: r16 = Sentinel
    //     0x6c9290: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6c9294: cmp             w0, w16
    // 0x6c9298: b.eq            #0x6c9408
    // 0x6c929c: tbnz            w0, #4, #0x6c93e4
    // 0x6c92a0: LoadField: r4 = r3->field_f
    //     0x6c92a0: ldur            w4, [x3, #0xf]
    // 0x6c92a4: DecompressPointer r4
    //     0x6c92a4: add             x4, x4, HEAP, lsl #32
    // 0x6c92a8: mov             x0, x4
    // 0x6c92ac: stur            x4, [fp, #-8]
    // 0x6c92b0: r2 = Null
    //     0x6c92b0: mov             x2, NULL
    // 0x6c92b4: r1 = Null
    //     0x6c92b4: mov             x1, NULL
    // 0x6c92b8: r4 = 59
    //     0x6c92b8: mov             x4, #0x3b
    // 0x6c92bc: branchIfSmi(r0, 0x6c92c8)
    //     0x6c92bc: tbz             w0, #0, #0x6c92c8
    // 0x6c92c0: r4 = LoadClassIdInstr(r0)
    //     0x6c92c0: ldur            x4, [x0, #-1]
    //     0x6c92c4: ubfx            x4, x4, #0xc, #0x14
    // 0x6c92c8: cmp             x4, #0x7e6
    // 0x6c92cc: b.eq            #0x6c92e0
    // 0x6c92d0: r8 = PipelineOwner?
    //     0x6c92d0: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x6c92d4: r3 = Null
    //     0x6c92d4: add             x3, PP, #0x22, lsl #12  ; [pp+0x22920] Null
    //     0x6c92d8: ldr             x3, [x3, #0x920]
    // 0x6c92dc: r0 = DefaultNullableTypeTest()
    //     0x6c92dc: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x6c92e0: ldur            x0, [fp, #-8]
    // 0x6c92e4: cmp             w0, NULL
    // 0x6c92e8: b.eq            #0x6c93f0
    // 0x6c92ec: LoadField: r1 = r0->field_27
    //     0x6c92ec: ldur            w1, [x0, #0x27]
    // 0x6c92f0: DecompressPointer r1
    //     0x6c92f0: add             x1, x1, HEAP, lsl #32
    // 0x6c92f4: stur            x1, [fp, #-0x10]
    // 0x6c92f8: LoadField: r0 = r1->field_b
    //     0x6c92f8: ldur            w0, [x1, #0xb]
    // 0x6c92fc: DecompressPointer r0
    //     0x6c92fc: add             x0, x0, HEAP, lsl #32
    // 0x6c9300: stur            x0, [fp, #-8]
    // 0x6c9304: LoadField: r2 = r1->field_f
    //     0x6c9304: ldur            w2, [x1, #0xf]
    // 0x6c9308: DecompressPointer r2
    //     0x6c9308: add             x2, x2, HEAP, lsl #32
    // 0x6c930c: LoadField: r3 = r2->field_b
    //     0x6c930c: ldur            w3, [x2, #0xb]
    // 0x6c9310: DecompressPointer r3
    //     0x6c9310: add             x3, x3, HEAP, lsl #32
    // 0x6c9314: cmp             w0, w3
    // 0x6c9318: b.ne            #0x6c9328
    // 0x6c931c: SaveReg r1
    //     0x6c931c: str             x1, [SP, #-8]!
    // 0x6c9320: r0 = _growToNextCapacity()
    //     0x6c9320: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6c9324: add             SP, SP, #8
    // 0x6c9328: ldr             x3, [fp, #0x10]
    // 0x6c932c: ldur            x2, [fp, #-0x10]
    // 0x6c9330: ldur            x0, [fp, #-8]
    // 0x6c9334: r4 = LoadInt32Instr(r0)
    //     0x6c9334: sbfx            x4, x0, #1, #0x1f
    // 0x6c9338: add             x0, x4, #1
    // 0x6c933c: lsl             x1, x0, #1
    // 0x6c9340: StoreField: r2->field_b = r1
    //     0x6c9340: stur            w1, [x2, #0xb]
    // 0x6c9344: mov             x1, x4
    // 0x6c9348: cmp             x1, x0
    // 0x6c934c: b.hs            #0x6c9410
    // 0x6c9350: LoadField: r1 = r2->field_f
    //     0x6c9350: ldur            w1, [x2, #0xf]
    // 0x6c9354: DecompressPointer r1
    //     0x6c9354: add             x1, x1, HEAP, lsl #32
    // 0x6c9358: mov             x0, x3
    // 0x6c935c: ArrayStore: r1[r4] = r0  ; List_4
    //     0x6c935c: add             x25, x1, x4, lsl #2
    //     0x6c9360: add             x25, x25, #0xf
    //     0x6c9364: str             w0, [x25]
    //     0x6c9368: tbz             w0, #0, #0x6c9384
    //     0x6c936c: ldurb           w16, [x1, #-1]
    //     0x6c9370: ldurb           w17, [x0, #-1]
    //     0x6c9374: and             x16, x17, x16, lsr #2
    //     0x6c9378: tst             x16, HEAP, lsr #32
    //     0x6c937c: b.eq            #0x6c9384
    //     0x6c9380: bl              #0xd67e5c
    // 0x6c9384: LoadField: r4 = r3->field_f
    //     0x6c9384: ldur            w4, [x3, #0xf]
    // 0x6c9388: DecompressPointer r4
    //     0x6c9388: add             x4, x4, HEAP, lsl #32
    // 0x6c938c: mov             x0, x4
    // 0x6c9390: stur            x4, [fp, #-8]
    // 0x6c9394: r2 = Null
    //     0x6c9394: mov             x2, NULL
    // 0x6c9398: r1 = Null
    //     0x6c9398: mov             x1, NULL
    // 0x6c939c: r4 = 59
    //     0x6c939c: mov             x4, #0x3b
    // 0x6c93a0: branchIfSmi(r0, 0x6c93ac)
    //     0x6c93a0: tbz             w0, #0, #0x6c93ac
    // 0x6c93a4: r4 = LoadClassIdInstr(r0)
    //     0x6c93a4: ldur            x4, [x0, #-1]
    //     0x6c93a8: ubfx            x4, x4, #0xc, #0x14
    // 0x6c93ac: cmp             x4, #0x7e6
    // 0x6c93b0: b.eq            #0x6c93c4
    // 0x6c93b4: r8 = PipelineOwner?
    //     0x6c93b4: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x6c93b8: r3 = Null
    //     0x6c93b8: add             x3, PP, #0x22, lsl #12  ; [pp+0x22930] Null
    //     0x6c93bc: ldr             x3, [x3, #0x930]
    // 0x6c93c0: r0 = DefaultNullableTypeTest()
    //     0x6c93c0: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x6c93c4: ldur            x0, [fp, #-8]
    // 0x6c93c8: cmp             w0, NULL
    // 0x6c93cc: b.eq            #0x6c9414
    // 0x6c93d0: SaveReg r0
    //     0x6c93d0: str             x0, [SP, #-8]!
    // 0x6c93d4: r0 = requestVisualUpdate()
    //     0x6c93d4: bl              #0x50fd88  ; [package:flutter/src/rendering/object.dart] PipelineOwner::requestVisualUpdate
    // 0x6c93d8: add             SP, SP, #8
    // 0x6c93dc: b               #0x6c93f0
    // 0x6c93e0: ldr             x3, [fp, #0x10]
    // 0x6c93e4: SaveReg r3
    //     0x6c93e4: str             x3, [SP, #-8]!
    // 0x6c93e8: r0 = markNeedsPaint()
    //     0x6c93e8: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c93ec: add             SP, SP, #8
    // 0x6c93f0: r0 = Null
    //     0x6c93f0: mov             x0, NULL
    // 0x6c93f4: LeaveFrame
    //     0x6c93f4: mov             SP, fp
    //     0x6c93f8: ldp             fp, lr, [SP], #0x10
    // 0x6c93fc: ret
    //     0x6c93fc: ret             
    // 0x6c9400: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c9400: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c9404: b               #0x6c9240
    // 0x6c9408: r9 = _wasRepaintBoundary
    //     0x6c9408: ldr             x9, [PP, #0x4b30]  ; [pp+0x4b30] Field <RenderObject._wasRepaintBoundary@904266271>: late (offset: 0x2c)
    // 0x6c940c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6c940c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6c9410: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6c9410: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6c9414: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6c9414: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ layout(/* No info */) {
    // ** addr: 0x6e6ea0, size: 0x540
    // 0x6e6ea0: EnterFrame
    //     0x6e6ea0: stp             fp, lr, [SP, #-0x10]!
    //     0x6e6ea4: mov             fp, SP
    // 0x6e6ea8: AllocStack(0x98)
    //     0x6e6ea8: sub             SP, SP, #0x98
    // 0x6e6eac: SetupParameters(RenderObject this /* r3, fp-0x88 */, dynamic _ /* r4, fp-0x80 */, {dynamic parentUsesSize = false /* r0 */})
    //     0x6e6eac: mov             x0, x4
    //     0x6e6eb0: ldur            w1, [x0, #0x13]
    //     0x6e6eb4: add             x1, x1, HEAP, lsl #32
    //     0x6e6eb8: sub             x2, x1, #4
    //     0x6e6ebc: add             x3, fp, w2, sxtw #2
    //     0x6e6ec0: ldr             x3, [x3, #0x18]
    //     0x6e6ec4: stur            x3, [fp, #-0x88]
    //     0x6e6ec8: add             x4, fp, w2, sxtw #2
    //     0x6e6ecc: ldr             x4, [x4, #0x10]
    //     0x6e6ed0: stur            x4, [fp, #-0x80]
    //     0x6e6ed4: ldur            w2, [x0, #0x1f]
    //     0x6e6ed8: add             x2, x2, HEAP, lsl #32
    //     0x6e6edc: add             x16, PP, #0xb, lsl #12  ; [pp+0xb000] "parentUsesSize"
    //     0x6e6ee0: ldr             x16, [x16]
    //     0x6e6ee4: cmp             w2, w16
    //     0x6e6ee8: b.ne            #0x6e6f08
    //     0x6e6eec: ldur            w2, [x0, #0x23]
    //     0x6e6ef0: add             x2, x2, HEAP, lsl #32
    //     0x6e6ef4: sub             w0, w1, w2
    //     0x6e6ef8: add             x1, fp, w0, sxtw #2
    //     0x6e6efc: ldr             x1, [x1, #8]
    //     0x6e6f00: mov             x0, x1
    //     0x6e6f04: b               #0x6e6f0c
    //     0x6e6f08: add             x0, NULL, #0x30  ; false
    // 0x6e6f0c: CheckStackOverflow
    //     0x6e6f0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e6f10: cmp             SP, x16
    //     0x6e6f14: b.ls            #0x6e73d0
    // 0x6e6f18: tbz             w0, #4, #0x6e6f24
    // 0x6e6f1c: mov             x1, x4
    // 0x6e6f20: b               #0x6e6fa0
    // 0x6e6f24: r0 = LoadClassIdInstr(r3)
    //     0x6e6f24: ldur            x0, [x3, #-1]
    //     0x6e6f28: ubfx            x0, x0, #0xc, #0x14
    // 0x6e6f2c: SaveReg r3
    //     0x6e6f2c: str             x3, [SP, #-8]!
    // 0x6e6f30: r0 = GDT[cid_x0 + 0xe477]()
    //     0x6e6f30: mov             x17, #0xe477
    //     0x6e6f34: add             lr, x0, x17
    //     0x6e6f38: ldr             lr, [x21, lr, lsl #3]
    //     0x6e6f3c: blr             lr
    // 0x6e6f40: add             SP, SP, #8
    // 0x6e6f44: tbnz            w0, #4, #0x6e6f50
    // 0x6e6f48: ldur            x1, [fp, #-0x80]
    // 0x6e6f4c: b               #0x6e6fa0
    // 0x6e6f50: ldur            x1, [fp, #-0x80]
    // 0x6e6f54: r0 = LoadClassIdInstr(r1)
    //     0x6e6f54: ldur            x0, [x1, #-1]
    //     0x6e6f58: ubfx            x0, x0, #0xc, #0x14
    // 0x6e6f5c: lsl             x0, x0, #1
    // 0x6e6f60: r17 = 4124
    //     0x6e6f60: mov             x17, #0x101c
    // 0x6e6f64: cmp             w0, w17
    // 0x6e6f68: b.gt            #0x6e6fa8
    // 0x6e6f6c: r17 = 4122
    //     0x6e6f6c: mov             x17, #0x101a
    // 0x6e6f70: cmp             w0, w17
    // 0x6e6f74: b.lt            #0x6e6fa8
    // 0x6e6f78: LoadField: d0 = r1->field_7
    //     0x6e6f78: ldur            d0, [x1, #7]
    // 0x6e6f7c: LoadField: d1 = r1->field_f
    //     0x6e6f7c: ldur            d1, [x1, #0xf]
    // 0x6e6f80: fcmp            d0, d1
    // 0x6e6f84: b.vs            #0x6e6fa8
    // 0x6e6f88: b.lt            #0x6e6fa8
    // 0x6e6f8c: LoadField: d0 = r1->field_17
    //     0x6e6f8c: ldur            d0, [x1, #0x17]
    // 0x6e6f90: LoadField: d1 = r1->field_1f
    //     0x6e6f90: ldur            d1, [x1, #0x1f]
    // 0x6e6f94: fcmp            d0, d1
    // 0x6e6f98: b.vs            #0x6e6fa8
    // 0x6e6f9c: b.lt            #0x6e6fa8
    // 0x6e6fa0: r0 = true
    //     0x6e6fa0: add             x0, NULL, #0x20  ; true
    // 0x6e6fa4: b               #0x6e7008
    // 0x6e6fa8: ldur            x2, [fp, #-0x88]
    // 0x6e6fac: r0 = LoadClassIdInstr(r2)
    //     0x6e6fac: ldur            x0, [x2, #-1]
    //     0x6e6fb0: ubfx            x0, x0, #0xc, #0x14
    // 0x6e6fb4: SaveReg r2
    //     0x6e6fb4: str             x2, [SP, #-8]!
    // 0x6e6fb8: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0x6e6fb8: mov             x17, #0xa2f1
    //     0x6e6fbc: add             lr, x0, x17
    //     0x6e6fc0: ldr             lr, [x21, lr, lsl #3]
    //     0x6e6fc4: blr             lr
    // 0x6e6fc8: add             SP, SP, #8
    // 0x6e6fcc: r1 = LoadClassIdInstr(r0)
    //     0x6e6fcc: ldur            x1, [x0, #-1]
    //     0x6e6fd0: ubfx            x1, x1, #0xc, #0x14
    // 0x6e6fd4: lsl             x1, x1, #1
    // 0x6e6fd8: r0 = LoadInt32Instr(r1)
    //     0x6e6fd8: sbfx            x0, x1, #1, #0x1f
    // 0x6e6fdc: cmp             x0, #0x961
    // 0x6e6fe0: b.lt            #0x6e6ffc
    // 0x6e6fe4: cmp             x0, #0xa1f
    // 0x6e6fe8: r16 = true
    //     0x6e6fe8: add             x16, NULL, #0x20  ; true
    // 0x6e6fec: r17 = false
    //     0x6e6fec: add             x17, NULL, #0x30  ; false
    // 0x6e6ff0: csel            x1, x16, x17, le
    // 0x6e6ff4: mov             x0, x1
    // 0x6e6ff8: b               #0x6e7000
    // 0x6e6ffc: r0 = false
    //     0x6e6ffc: add             x0, NULL, #0x30  ; false
    // 0x6e7000: eor             x1, x0, #0x10
    // 0x6e7004: mov             x0, x1
    // 0x6e7008: tbnz            w0, #4, #0x6e7014
    // 0x6e700c: ldur            x1, [fp, #-0x88]
    // 0x6e7010: b               #0x6e708c
    // 0x6e7014: ldur            x1, [fp, #-0x88]
    // 0x6e7018: r0 = LoadClassIdInstr(r1)
    //     0x6e7018: ldur            x0, [x1, #-1]
    //     0x6e701c: ubfx            x0, x0, #0xc, #0x14
    // 0x6e7020: SaveReg r1
    //     0x6e7020: str             x1, [SP, #-8]!
    // 0x6e7024: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0x6e7024: mov             x17, #0xa2f1
    //     0x6e7028: add             lr, x0, x17
    //     0x6e702c: ldr             lr, [x21, lr, lsl #3]
    //     0x6e7030: blr             lr
    // 0x6e7034: add             SP, SP, #8
    // 0x6e7038: mov             x3, x0
    // 0x6e703c: stur            x3, [fp, #-0x90]
    // 0x6e7040: cmp             w3, NULL
    // 0x6e7044: b.eq            #0x6e73d8
    // 0x6e7048: mov             x0, x3
    // 0x6e704c: r2 = Null
    //     0x6e704c: mov             x2, NULL
    // 0x6e7050: r1 = Null
    //     0x6e7050: mov             x1, NULL
    // 0x6e7054: r4 = LoadClassIdInstr(r0)
    //     0x6e7054: ldur            x4, [x0, #-1]
    //     0x6e7058: ubfx            x4, x4, #0xc, #0x14
    // 0x6e705c: sub             x4, x4, #0x961
    // 0x6e7060: cmp             x4, #0xbe
    // 0x6e7064: b.ls            #0x6e7078
    // 0x6e7068: r8 = RenderObject
    //     0x6e7068: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x6e706c: r3 = Null
    //     0x6e706c: add             x3, PP, #0xb, lsl #12  ; [pp+0xb008] Null
    //     0x6e7070: ldr             x3, [x3, #8]
    // 0x6e7074: r0 = RenderObject()
    //     0x6e7074: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x6e7078: ldur            x0, [fp, #-0x90]
    // 0x6e707c: LoadField: r1 = r0->field_1f
    //     0x6e707c: ldur            w1, [x0, #0x1f]
    // 0x6e7080: DecompressPointer r1
    //     0x6e7080: add             x1, x1, HEAP, lsl #32
    // 0x6e7084: cmp             w1, NULL
    // 0x6e7088: b.eq            #0x6e73dc
    // 0x6e708c: ldur            x0, [fp, #-0x88]
    // 0x6e7090: stur            x1, [fp, #-0x98]
    // 0x6e7094: LoadField: r2 = r0->field_1b
    //     0x6e7094: ldur            w2, [x0, #0x1b]
    // 0x6e7098: DecompressPointer r2
    //     0x6e7098: add             x2, x2, HEAP, lsl #32
    // 0x6e709c: tbz             w2, #4, #0x6e7214
    // 0x6e70a0: ldur            x2, [fp, #-0x80]
    // 0x6e70a4: LoadField: r3 = r0->field_27
    //     0x6e70a4: ldur            w3, [x0, #0x27]
    // 0x6e70a8: DecompressPointer r3
    //     0x6e70a8: add             x3, x3, HEAP, lsl #32
    // 0x6e70ac: stur            x3, [fp, #-0x90]
    // 0x6e70b0: r4 = LoadClassIdInstr(r2)
    //     0x6e70b0: ldur            x4, [x2, #-1]
    //     0x6e70b4: ubfx            x4, x4, #0xc, #0x14
    // 0x6e70b8: lsl             x4, x4, #1
    // 0x6e70bc: r17 = 4124
    //     0x6e70bc: mov             x17, #0x101c
    // 0x6e70c0: cmp             w4, w17
    // 0x6e70c4: b.ne            #0x6e7168
    // 0x6e70c8: cmp             w3, NULL
    // 0x6e70cc: b.ne            #0x6e70dc
    // 0x6e70d0: mov             x2, x1
    // 0x6e70d4: mov             x1, x0
    // 0x6e70d8: b               #0x6e721c
    // 0x6e70dc: stp             x3, x2, [SP, #-0x10]!
    // 0x6e70e0: r0 = ==()
    //     0x6e70e0: bl              #0xc9e8ac  ; [package:flutter/src/rendering/box.dart] BoxConstraints::==
    // 0x6e70e4: add             SP, SP, #0x10
    // 0x6e70e8: tbz             w0, #4, #0x6e70f8
    // 0x6e70ec: ldur            x1, [fp, #-0x88]
    // 0x6e70f0: ldur            x2, [fp, #-0x98]
    // 0x6e70f4: b               #0x6e721c
    // 0x6e70f8: ldur            x0, [fp, #-0x90]
    // 0x6e70fc: r1 = LoadClassIdInstr(r0)
    //     0x6e70fc: ldur            x1, [x0, #-1]
    //     0x6e7100: ubfx            x1, x1, #0xc, #0x14
    // 0x6e7104: lsl             x1, x1, #1
    // 0x6e7108: r17 = 4124
    //     0x6e7108: mov             x17, #0x101c
    // 0x6e710c: cmp             w1, w17
    // 0x6e7110: b.ne            #0x6e7158
    // 0x6e7114: ldur            x1, [fp, #-0x80]
    // 0x6e7118: LoadField: d0 = r0->field_37
    //     0x6e7118: ldur            d0, [x0, #0x37]
    // 0x6e711c: LoadField: d1 = r1->field_37
    //     0x6e711c: ldur            d1, [x1, #0x37]
    // 0x6e7120: fcmp            d0, d1
    // 0x6e7124: b.vs            #0x6e715c
    // 0x6e7128: b.ne            #0x6e715c
    // 0x6e712c: LoadField: d0 = r0->field_27
    //     0x6e712c: ldur            d0, [x0, #0x27]
    // 0x6e7130: LoadField: d1 = r1->field_27
    //     0x6e7130: ldur            d1, [x1, #0x27]
    // 0x6e7134: fcmp            d0, d1
    // 0x6e7138: b.vs            #0x6e715c
    // 0x6e713c: b.ne            #0x6e715c
    // 0x6e7140: LoadField: d0 = r0->field_2f
    //     0x6e7140: ldur            d0, [x0, #0x2f]
    // 0x6e7144: LoadField: d1 = r1->field_2f
    //     0x6e7144: ldur            d1, [x1, #0x2f]
    // 0x6e7148: fcmp            d0, d1
    // 0x6e714c: b.vs            #0x6e715c
    // 0x6e7150: b.ne            #0x6e715c
    // 0x6e7154: b               #0x6e7194
    // 0x6e7158: ldur            x1, [fp, #-0x80]
    // 0x6e715c: ldur            x1, [fp, #-0x88]
    // 0x6e7160: ldur            x2, [fp, #-0x98]
    // 0x6e7164: b               #0x6e721c
    // 0x6e7168: mov             x1, x2
    // 0x6e716c: mov             x0, x3
    // 0x6e7170: r2 = LoadClassIdInstr(r1)
    //     0x6e7170: ldur            x2, [x1, #-1]
    //     0x6e7174: ubfx            x2, x2, #0xc, #0x14
    // 0x6e7178: stp             x0, x1, [SP, #-0x10]!
    // 0x6e717c: mov             x0, x2
    // 0x6e7180: mov             lr, x0
    // 0x6e7184: ldr             lr, [x21, lr, lsl #3]
    // 0x6e7188: blr             lr
    // 0x6e718c: add             SP, SP, #0x10
    // 0x6e7190: tbnz            w0, #4, #0x6e7208
    // 0x6e7194: ldur            x1, [fp, #-0x88]
    // 0x6e7198: ldur            x2, [fp, #-0x98]
    // 0x6e719c: LoadField: r0 = r1->field_1f
    //     0x6e719c: ldur            w0, [x1, #0x1f]
    // 0x6e71a0: DecompressPointer r0
    //     0x6e71a0: add             x0, x0, HEAP, lsl #32
    // 0x6e71a4: cmp             w2, w0
    // 0x6e71a8: b.eq            #0x6e71f8
    // 0x6e71ac: mov             x0, x2
    // 0x6e71b0: StoreField: r1->field_1f = r0
    //     0x6e71b0: stur            w0, [x1, #0x1f]
    //     0x6e71b4: tbz             w0, #0, #0x6e71d0
    //     0x6e71b8: ldurb           w16, [x1, #-1]
    //     0x6e71bc: ldurb           w17, [x0, #-1]
    //     0x6e71c0: and             x16, x17, x16, lsr #2
    //     0x6e71c4: tst             x16, HEAP, lsr #32
    //     0x6e71c8: b.eq            #0x6e71d0
    //     0x6e71cc: bl              #0xd6826c
    // 0x6e71d0: r0 = LoadClassIdInstr(r1)
    //     0x6e71d0: ldur            x0, [x1, #-1]
    //     0x6e71d4: ubfx            x0, x0, #0xc, #0x14
    // 0x6e71d8: r16 = Closure: (RenderObject) => void from Function '_propagateRelayoutBoundaryToChild@904266271': static.
    //     0x6e71d8: add             x16, PP, #0xb, lsl #12  ; [pp+0xb018] Closure: (RenderObject) => void from Function '_propagateRelayoutBoundaryToChild@904266271': static. (0x7fe6e1ee73e0)
    //     0x6e71dc: ldr             x16, [x16, #0x18]
    // 0x6e71e0: stp             x16, x1, [SP, #-0x10]!
    // 0x6e71e4: r0 = GDT[cid_x0 + 0xd2d5]()
    //     0x6e71e4: mov             x17, #0xd2d5
    //     0x6e71e8: add             lr, x0, x17
    //     0x6e71ec: ldr             lr, [x21, lr, lsl #3]
    //     0x6e71f0: blr             lr
    // 0x6e71f4: add             SP, SP, #0x10
    // 0x6e71f8: r0 = Null
    //     0x6e71f8: mov             x0, NULL
    // 0x6e71fc: LeaveFrame
    //     0x6e71fc: mov             SP, fp
    //     0x6e7200: ldp             fp, lr, [SP], #0x10
    // 0x6e7204: ret
    //     0x6e7204: ret             
    // 0x6e7208: ldur            x1, [fp, #-0x88]
    // 0x6e720c: ldur            x2, [fp, #-0x98]
    // 0x6e7210: b               #0x6e721c
    // 0x6e7214: mov             x2, x1
    // 0x6e7218: mov             x1, x0
    // 0x6e721c: ldur            x0, [fp, #-0x80]
    // 0x6e7220: StoreField: r1->field_27 = r0
    //     0x6e7220: stur            w0, [x1, #0x27]
    //     0x6e7224: ldurb           w16, [x1, #-1]
    //     0x6e7228: ldurb           w17, [x0, #-1]
    //     0x6e722c: and             x16, x17, x16, lsr #2
    //     0x6e7230: tst             x16, HEAP, lsr #32
    //     0x6e7234: b.eq            #0x6e723c
    //     0x6e7238: bl              #0xd6826c
    // 0x6e723c: LoadField: r0 = r1->field_1f
    //     0x6e723c: ldur            w0, [x1, #0x1f]
    // 0x6e7240: DecompressPointer r0
    //     0x6e7240: add             x0, x0, HEAP, lsl #32
    // 0x6e7244: cmp             w0, NULL
    // 0x6e7248: b.eq            #0x6e7278
    // 0x6e724c: cmp             w2, w0
    // 0x6e7250: b.eq            #0x6e7278
    // 0x6e7254: r0 = LoadClassIdInstr(r1)
    //     0x6e7254: ldur            x0, [x1, #-1]
    //     0x6e7258: ubfx            x0, x0, #0xc, #0x14
    // 0x6e725c: r16 = Closure: (RenderObject) => void from Function '_cleanChildRelayoutBoundary@904266271': static.
    //     0x6e725c: ldr             x16, [PP, #0x4e10]  ; [pp+0x4e10] Closure: (RenderObject) => void from Function '_cleanChildRelayoutBoundary@904266271': static. (0x7fe6e1de5f5c)
    // 0x6e7260: stp             x16, x1, [SP, #-0x10]!
    // 0x6e7264: r0 = GDT[cid_x0 + 0xd2d5]()
    //     0x6e7264: mov             x17, #0xd2d5
    //     0x6e7268: add             lr, x0, x17
    //     0x6e726c: ldr             lr, [x21, lr, lsl #3]
    //     0x6e7270: blr             lr
    // 0x6e7274: add             SP, SP, #0x10
    // 0x6e7278: ldur            x1, [fp, #-0x88]
    // 0x6e727c: ldur            x0, [fp, #-0x98]
    // 0x6e7280: StoreField: r1->field_1f = r0
    //     0x6e7280: stur            w0, [x1, #0x1f]
    //     0x6e7284: tbz             w0, #0, #0x6e72a0
    //     0x6e7288: ldurb           w16, [x1, #-1]
    //     0x6e728c: ldurb           w17, [x0, #-1]
    //     0x6e7290: and             x16, x17, x16, lsr #2
    //     0x6e7294: tst             x16, HEAP, lsr #32
    //     0x6e7298: b.eq            #0x6e72a0
    //     0x6e729c: bl              #0xd6826c
    // 0x6e72a0: r0 = LoadClassIdInstr(r1)
    //     0x6e72a0: ldur            x0, [x1, #-1]
    //     0x6e72a4: ubfx            x0, x0, #0xc, #0x14
    // 0x6e72a8: SaveReg r1
    //     0x6e72a8: str             x1, [SP, #-8]!
    // 0x6e72ac: r0 = GDT[cid_x0 + 0xe477]()
    //     0x6e72ac: mov             x17, #0xe477
    //     0x6e72b0: add             lr, x0, x17
    //     0x6e72b4: ldr             lr, [x21, lr, lsl #3]
    //     0x6e72b8: blr             lr
    // 0x6e72bc: add             SP, SP, #8
    // 0x6e72c0: tbnz            w0, #4, #0x6e72f0
    // 0x6e72c4: ldur            x1, [fp, #-0x88]
    // 0x6e72c8: r0 = LoadClassIdInstr(r1)
    //     0x6e72c8: ldur            x0, [x1, #-1]
    //     0x6e72cc: ubfx            x0, x0, #0xc, #0x14
    // 0x6e72d0: SaveReg r1
    //     0x6e72d0: str             x1, [SP, #-8]!
    // 0x6e72d4: r0 = GDT[cid_x0 + 0xeee5]()
    //     0x6e72d4: mov             x17, #0xeee5
    //     0x6e72d8: add             lr, x0, x17
    //     0x6e72dc: ldr             lr, [x21, lr, lsl #3]
    //     0x6e72e0: blr             lr
    // 0x6e72e4: add             SP, SP, #8
    // 0x6e72e8: ldur            x0, [fp, #-0x88]
    // 0x6e72ec: b               #0x6e7328
    // 0x6e72f0: ldur            x1, [fp, #-0x88]
    // 0x6e72f4: b               #0x6e732c
    // 0x6e72f8: sub             SP, fp, #0x98
    // 0x6e72fc: mov             x16, x1
    // 0x6e7300: mov             x1, x0
    // 0x6e7304: mov             x0, x16
    // 0x6e7308: ldur            x16, [fp, #-8]
    // 0x6e730c: r30 = "performResize"
    //     0x6e730c: add             lr, PP, #0xb, lsl #12  ; [pp+0xb020] "performResize"
    //     0x6e7310: ldr             lr, [lr, #0x20]
    // 0x6e7314: stp             lr, x16, [SP, #-0x10]!
    // 0x6e7318: stp             x0, x1, [SP, #-0x10]!
    // 0x6e731c: r0 = _reportException()
    //     0x6e731c: bl              #0x5df13c  ; [package:flutter/src/rendering/object.dart] RenderObject::_reportException
    // 0x6e7320: add             SP, SP, #0x20
    // 0x6e7324: ldur            x0, [fp, #-8]
    // 0x6e7328: mov             x1, x0
    // 0x6e732c: stur            x1, [fp, #-0x80]
    // 0x6e7330: r0 = LoadClassIdInstr(r1)
    //     0x6e7330: ldur            x0, [x1, #-1]
    //     0x6e7334: ubfx            x0, x0, #0xc, #0x14
    // 0x6e7338: SaveReg r1
    //     0x6e7338: str             x1, [SP, #-8]!
    // 0x6e733c: r0 = GDT[cid_x0 + 0xe2f9]()
    //     0x6e733c: mov             x17, #0xe2f9
    //     0x6e7340: add             lr, x0, x17
    //     0x6e7344: ldr             lr, [x21, lr, lsl #3]
    //     0x6e7348: blr             lr
    // 0x6e734c: add             SP, SP, #8
    // 0x6e7350: ldur            x16, [fp, #-0x80]
    // 0x6e7354: SaveReg r16
    //     0x6e7354: str             x16, [SP, #-8]!
    // 0x6e7358: r0 = markNeedsSemanticsUpdate()
    //     0x6e7358: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6e735c: add             SP, SP, #8
    // 0x6e7360: ldur            x1, [fp, #-0x80]
    // 0x6e7364: b               #0x6e7398
    // 0x6e7368: sub             SP, fp, #0x98
    // 0x6e736c: mov             x16, x1
    // 0x6e7370: mov             x1, x0
    // 0x6e7374: mov             x0, x16
    // 0x6e7378: ldur            x16, [fp, #-8]
    // 0x6e737c: r30 = "performLayout"
    //     0x6e737c: ldr             lr, [PP, #0x4b50]  ; [pp+0x4b50] "performLayout"
    // 0x6e7380: stp             lr, x16, [SP, #-0x10]!
    // 0x6e7384: stp             x0, x1, [SP, #-0x10]!
    // 0x6e7388: r0 = _reportException()
    //     0x6e7388: bl              #0x5df13c  ; [package:flutter/src/rendering/object.dart] RenderObject::_reportException
    // 0x6e738c: add             SP, SP, #0x20
    // 0x6e7390: ldur            x0, [fp, #-8]
    // 0x6e7394: mov             x1, x0
    // 0x6e7398: r0 = false
    //     0x6e7398: add             x0, NULL, #0x30  ; false
    // 0x6e739c: StoreField: r1->field_1b = r0
    //     0x6e739c: stur            w0, [x1, #0x1b]
    // 0x6e73a0: r0 = LoadClassIdInstr(r1)
    //     0x6e73a0: ldur            x0, [x1, #-1]
    //     0x6e73a4: ubfx            x0, x0, #0xc, #0x14
    // 0x6e73a8: SaveReg r1
    //     0x6e73a8: str             x1, [SP, #-8]!
    // 0x6e73ac: r0 = GDT[cid_x0 + 0xd3b6]()
    //     0x6e73ac: mov             x17, #0xd3b6
    //     0x6e73b0: add             lr, x0, x17
    //     0x6e73b4: ldr             lr, [x21, lr, lsl #3]
    //     0x6e73b8: blr             lr
    // 0x6e73bc: add             SP, SP, #8
    // 0x6e73c0: r0 = Null
    //     0x6e73c0: mov             x0, NULL
    // 0x6e73c4: LeaveFrame
    //     0x6e73c4: mov             SP, fp
    //     0x6e73c8: ldp             fp, lr, [SP], #0x10
    // 0x6e73cc: ret
    //     0x6e73cc: ret             
    // 0x6e73d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e73d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e73d4: b               #0x6e6f18
    // 0x6e73d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6e73d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6e73dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6e73dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] static void _propagateRelayoutBoundaryToChild(dynamic, RenderObject) {
    // ** addr: 0x6e73e0, size: 0x3c
    // 0x6e73e0: EnterFrame
    //     0x6e73e0: stp             fp, lr, [SP, #-0x10]!
    //     0x6e73e4: mov             fp, SP
    // 0x6e73e8: CheckStackOverflow
    //     0x6e73e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e73ec: cmp             SP, x16
    //     0x6e73f0: b.ls            #0x6e7414
    // 0x6e73f4: ldr             x16, [fp, #0x10]
    // 0x6e73f8: SaveReg r16
    //     0x6e73f8: str             x16, [SP, #-8]!
    // 0x6e73fc: r0 = _propagateRelayoutBoundary()
    //     0x6e73fc: bl              #0x6e741c  ; [package:flutter/src/rendering/object.dart] RenderObject::_propagateRelayoutBoundary
    // 0x6e7400: add             SP, SP, #8
    // 0x6e7404: r0 = Null
    //     0x6e7404: mov             x0, NULL
    // 0x6e7408: LeaveFrame
    //     0x6e7408: mov             SP, fp
    //     0x6e740c: ldp             fp, lr, [SP], #0x10
    // 0x6e7410: ret
    //     0x6e7410: ret             
    // 0x6e7414: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e7414: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e7418: b               #0x6e73f4
  }
  _ _propagateRelayoutBoundary(/* No info */) {
    // ** addr: 0x6e741c, size: 0x16c
    // 0x6e741c: EnterFrame
    //     0x6e741c: stp             fp, lr, [SP, #-0x10]!
    //     0x6e7420: mov             fp, SP
    // 0x6e7424: AllocStack(0x8)
    //     0x6e7424: sub             SP, SP, #8
    // 0x6e7428: CheckStackOverflow
    //     0x6e7428: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e742c: cmp             SP, x16
    //     0x6e7430: b.ls            #0x6e7580
    // 0x6e7434: ldr             x1, [fp, #0x10]
    // 0x6e7438: LoadField: r0 = r1->field_1f
    //     0x6e7438: ldur            w0, [x1, #0x1f]
    // 0x6e743c: DecompressPointer r0
    //     0x6e743c: add             x0, x0, HEAP, lsl #32
    // 0x6e7440: r2 = LoadClassIdInstr(r0)
    //     0x6e7440: ldur            x2, [x0, #-1]
    //     0x6e7444: ubfx            x2, x2, #0xc, #0x14
    // 0x6e7448: stp             x1, x0, [SP, #-0x10]!
    // 0x6e744c: mov             x0, x2
    // 0x6e7450: mov             lr, x0
    // 0x6e7454: ldr             lr, [x21, lr, lsl #3]
    // 0x6e7458: blr             lr
    // 0x6e745c: add             SP, SP, #0x10
    // 0x6e7460: tbnz            w0, #4, #0x6e7474
    // 0x6e7464: r0 = Null
    //     0x6e7464: mov             x0, NULL
    // 0x6e7468: LeaveFrame
    //     0x6e7468: mov             SP, fp
    //     0x6e746c: ldp             fp, lr, [SP], #0x10
    // 0x6e7470: ret
    //     0x6e7470: ret             
    // 0x6e7474: ldr             x1, [fp, #0x10]
    // 0x6e7478: r0 = LoadClassIdInstr(r1)
    //     0x6e7478: ldur            x0, [x1, #-1]
    //     0x6e747c: ubfx            x0, x0, #0xc, #0x14
    // 0x6e7480: SaveReg r1
    //     0x6e7480: str             x1, [SP, #-8]!
    // 0x6e7484: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0x6e7484: mov             x17, #0xa2f1
    //     0x6e7488: add             lr, x0, x17
    //     0x6e748c: ldr             lr, [x21, lr, lsl #3]
    //     0x6e7490: blr             lr
    // 0x6e7494: add             SP, SP, #8
    // 0x6e7498: mov             x3, x0
    // 0x6e749c: r2 = Null
    //     0x6e749c: mov             x2, NULL
    // 0x6e74a0: r1 = Null
    //     0x6e74a0: mov             x1, NULL
    // 0x6e74a4: stur            x3, [fp, #-8]
    // 0x6e74a8: r4 = LoadClassIdInstr(r0)
    //     0x6e74a8: ldur            x4, [x0, #-1]
    //     0x6e74ac: ubfx            x4, x4, #0xc, #0x14
    // 0x6e74b0: sub             x4, x4, #0x961
    // 0x6e74b4: cmp             x4, #0xbe
    // 0x6e74b8: b.ls            #0x6e74d0
    // 0x6e74bc: r8 = RenderObject?
    //     0x6e74bc: add             x8, PP, #0xb, lsl #12  ; [pp+0xb028] Type: RenderObject?
    //     0x6e74c0: ldr             x8, [x8, #0x28]
    // 0x6e74c4: r3 = Null
    //     0x6e74c4: add             x3, PP, #0xb, lsl #12  ; [pp+0xb030] Null
    //     0x6e74c8: ldr             x3, [x3, #0x30]
    // 0x6e74cc: r0 = DefaultNullableTypeTest()
    //     0x6e74cc: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x6e74d0: ldur            x0, [fp, #-8]
    // 0x6e74d4: cmp             w0, NULL
    // 0x6e74d8: b.ne            #0x6e74e4
    // 0x6e74dc: r2 = Null
    //     0x6e74dc: mov             x2, NULL
    // 0x6e74e0: b               #0x6e74f0
    // 0x6e74e4: LoadField: r1 = r0->field_1f
    //     0x6e74e4: ldur            w1, [x0, #0x1f]
    // 0x6e74e8: DecompressPointer r1
    //     0x6e74e8: add             x1, x1, HEAP, lsl #32
    // 0x6e74ec: mov             x2, x1
    // 0x6e74f0: ldr             x1, [fp, #0x10]
    // 0x6e74f4: stur            x2, [fp, #-8]
    // 0x6e74f8: LoadField: r0 = r1->field_1f
    //     0x6e74f8: ldur            w0, [x1, #0x1f]
    // 0x6e74fc: DecompressPointer r0
    //     0x6e74fc: add             x0, x0, HEAP, lsl #32
    // 0x6e7500: r3 = LoadClassIdInstr(r2)
    //     0x6e7500: ldur            x3, [x2, #-1]
    //     0x6e7504: ubfx            x3, x3, #0xc, #0x14
    // 0x6e7508: stp             x0, x2, [SP, #-0x10]!
    // 0x6e750c: mov             x0, x3
    // 0x6e7510: mov             lr, x0
    // 0x6e7514: ldr             lr, [x21, lr, lsl #3]
    // 0x6e7518: blr             lr
    // 0x6e751c: add             SP, SP, #0x10
    // 0x6e7520: tbz             w0, #4, #0x6e7570
    // 0x6e7524: ldr             x1, [fp, #0x10]
    // 0x6e7528: ldur            x0, [fp, #-8]
    // 0x6e752c: StoreField: r1->field_1f = r0
    //     0x6e752c: stur            w0, [x1, #0x1f]
    //     0x6e7530: ldurb           w16, [x1, #-1]
    //     0x6e7534: ldurb           w17, [x0, #-1]
    //     0x6e7538: and             x16, x17, x16, lsr #2
    //     0x6e753c: tst             x16, HEAP, lsr #32
    //     0x6e7540: b.eq            #0x6e7548
    //     0x6e7544: bl              #0xd6826c
    // 0x6e7548: r0 = LoadClassIdInstr(r1)
    //     0x6e7548: ldur            x0, [x1, #-1]
    //     0x6e754c: ubfx            x0, x0, #0xc, #0x14
    // 0x6e7550: r16 = Closure: (RenderObject) => void from Function '_propagateRelayoutBoundaryToChild@904266271': static.
    //     0x6e7550: add             x16, PP, #0xb, lsl #12  ; [pp+0xb018] Closure: (RenderObject) => void from Function '_propagateRelayoutBoundaryToChild@904266271': static. (0x7fe6e1ee73e0)
    //     0x6e7554: ldr             x16, [x16, #0x18]
    // 0x6e7558: stp             x16, x1, [SP, #-0x10]!
    // 0x6e755c: r0 = GDT[cid_x0 + 0xd2d5]()
    //     0x6e755c: mov             x17, #0xd2d5
    //     0x6e7560: add             lr, x0, x17
    //     0x6e7564: ldr             lr, [x21, lr, lsl #3]
    //     0x6e7568: blr             lr
    // 0x6e756c: add             SP, SP, #0x10
    // 0x6e7570: r0 = Null
    //     0x6e7570: mov             x0, NULL
    // 0x6e7574: LeaveFrame
    //     0x6e7574: mov             SP, fp
    //     0x6e7578: ldp             fp, lr, [SP], #0x10
    // 0x6e757c: ret
    //     0x6e757c: ret             
    // 0x6e7580: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e7580: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e7584: b               #0x6e7434
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0x717214, size: 0x30
    // 0x717214: EnterFrame
    //     0x717214: stp             fp, lr, [SP, #-0x10]!
    //     0x717218: mov             fp, SP
    // 0x71721c: ldr             x0, [fp, #0x10]
    // 0x717220: r2 = Null
    //     0x717220: mov             x2, NULL
    // 0x717224: r1 = Null
    //     0x717224: mov             x1, NULL
    // 0x717228: r8 = HitTestEntry<HitTestTarget>
    //     0x717228: ldr             x8, [PP, #0x72c0]  ; [pp+0x72c0] Type: HitTestEntry<HitTestTarget>
    // 0x71722c: r3 = Null
    //     0x71722c: ldr             x3, [PP, #0x72c8]  ; [pp+0x72c8] Null
    // 0x717230: r0 = HitTestEntry<HitTestTarget>()
    //     0x717230: bl              #0x50f268  ; IsType_HitTestEntry<HitTestTarget>_Stub
    // 0x717234: r0 = Null
    //     0x717234: mov             x0, NULL
    // 0x717238: LeaveFrame
    //     0x717238: mov             SP, fp
    //     0x71723c: ldp             fp, lr, [SP], #0x10
    // 0x717240: ret
    //     0x717240: ret             
  }
  dynamic dropChild(dynamic) {
    // ** addr: 0x792650, size: 0x18
    // 0x792650: r4 = 0
    //     0x792650: mov             x4, #0
    // 0x792654: r1 = Function 'dropChild':.
    //     0x792654: add             x17, PP, #0x57, lsl #12  ; [pp+0x575f0] AnonymousClosure: (0x5e5bf4), in [package:flutter/src/rendering/object.dart] RenderObject::dropChild (0x5e5aec)
    //     0x792658: ldr             x1, [x17, #0x5f0]
    // 0x79265c: r24 = BuildNonGenericMethodExtractorStub
    //     0x79265c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x792660: LoadField: r0 = r24->field_17
    //     0x792660: ldur            x0, [x24, #0x17]
    // 0x792664: br              x0
  }
  _ sendSemanticsEvent(/* No info */) {
    // ** addr: 0x83c044, size: 0x130
    // 0x83c044: EnterFrame
    //     0x83c044: stp             fp, lr, [SP, #-0x10]!
    //     0x83c048: mov             fp, SP
    // 0x83c04c: AllocStack(0x8)
    //     0x83c04c: sub             SP, SP, #8
    // 0x83c050: CheckStackOverflow
    //     0x83c050: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83c054: cmp             SP, x16
    //     0x83c058: b.ls            #0x83c168
    // 0x83c05c: ldr             x3, [fp, #0x18]
    // 0x83c060: LoadField: r4 = r3->field_f
    //     0x83c060: ldur            w4, [x3, #0xf]
    // 0x83c064: DecompressPointer r4
    //     0x83c064: add             x4, x4, HEAP, lsl #32
    // 0x83c068: mov             x0, x4
    // 0x83c06c: stur            x4, [fp, #-8]
    // 0x83c070: r2 = Null
    //     0x83c070: mov             x2, NULL
    // 0x83c074: r1 = Null
    //     0x83c074: mov             x1, NULL
    // 0x83c078: r4 = 59
    //     0x83c078: mov             x4, #0x3b
    // 0x83c07c: branchIfSmi(r0, 0x83c088)
    //     0x83c07c: tbz             w0, #0, #0x83c088
    // 0x83c080: r4 = LoadClassIdInstr(r0)
    //     0x83c080: ldur            x4, [x0, #-1]
    //     0x83c084: ubfx            x4, x4, #0xc, #0x14
    // 0x83c088: cmp             x4, #0x7e6
    // 0x83c08c: b.eq            #0x83c0a0
    // 0x83c090: r8 = PipelineOwner?
    //     0x83c090: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x83c094: r3 = Null
    //     0x83c094: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2de90] Null
    //     0x83c098: ldr             x3, [x3, #0xe90]
    // 0x83c09c: r0 = DefaultNullableTypeTest()
    //     0x83c09c: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x83c0a0: ldur            x0, [fp, #-8]
    // 0x83c0a4: cmp             w0, NULL
    // 0x83c0a8: b.eq            #0x83c170
    // 0x83c0ac: LoadField: r1 = r0->field_2b
    //     0x83c0ac: ldur            w1, [x0, #0x2b]
    // 0x83c0b0: DecompressPointer r1
    //     0x83c0b0: add             x1, x1, HEAP, lsl #32
    // 0x83c0b4: cmp             w1, NULL
    // 0x83c0b8: b.ne            #0x83c0cc
    // 0x83c0bc: r0 = Null
    //     0x83c0bc: mov             x0, NULL
    // 0x83c0c0: LeaveFrame
    //     0x83c0c0: mov             SP, fp
    //     0x83c0c4: ldp             fp, lr, [SP], #0x10
    // 0x83c0c8: ret
    //     0x83c0c8: ret             
    // 0x83c0cc: ldr             x0, [fp, #0x18]
    // 0x83c0d0: LoadField: r1 = r0->field_4b
    //     0x83c0d0: ldur            w1, [x0, #0x4b]
    // 0x83c0d4: DecompressPointer r1
    //     0x83c0d4: add             x1, x1, HEAP, lsl #32
    // 0x83c0d8: cmp             w1, NULL
    // 0x83c0dc: b.eq            #0x83c100
    // 0x83c0e0: LoadField: r2 = r1->field_3f
    //     0x83c0e0: ldur            w2, [x1, #0x3f]
    // 0x83c0e4: DecompressPointer r2
    //     0x83c0e4: add             x2, x2, HEAP, lsl #32
    // 0x83c0e8: tbz             w2, #4, #0x83c100
    // 0x83c0ec: ldr             x16, [fp, #0x10]
    // 0x83c0f0: stp             x16, x1, [SP, #-0x10]!
    // 0x83c0f4: r0 = sendEvent()
    //     0x83c0f4: bl              #0x83c174  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::sendEvent
    // 0x83c0f8: add             SP, SP, #0x10
    // 0x83c0fc: b               #0x83c158
    // 0x83c100: LoadField: r3 = r0->field_13
    //     0x83c100: ldur            w3, [x0, #0x13]
    // 0x83c104: DecompressPointer r3
    //     0x83c104: add             x3, x3, HEAP, lsl #32
    // 0x83c108: stur            x3, [fp, #-8]
    // 0x83c10c: cmp             w3, NULL
    // 0x83c110: b.eq            #0x83c158
    // 0x83c114: mov             x0, x3
    // 0x83c118: r2 = Null
    //     0x83c118: mov             x2, NULL
    // 0x83c11c: r1 = Null
    //     0x83c11c: mov             x1, NULL
    // 0x83c120: r4 = LoadClassIdInstr(r0)
    //     0x83c120: ldur            x4, [x0, #-1]
    //     0x83c124: ubfx            x4, x4, #0xc, #0x14
    // 0x83c128: sub             x4, x4, #0x961
    // 0x83c12c: cmp             x4, #0xbe
    // 0x83c130: b.ls            #0x83c144
    // 0x83c134: r8 = RenderObject
    //     0x83c134: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x83c138: r3 = Null
    //     0x83c138: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2dea0] Null
    //     0x83c13c: ldr             x3, [x3, #0xea0]
    // 0x83c140: r0 = RenderObject()
    //     0x83c140: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x83c144: ldur            x16, [fp, #-8]
    // 0x83c148: ldr             lr, [fp, #0x10]
    // 0x83c14c: stp             lr, x16, [SP, #-0x10]!
    // 0x83c150: r0 = sendSemanticsEvent()
    //     0x83c150: bl              #0x83c044  ; [package:flutter/src/rendering/object.dart] RenderObject::sendSemanticsEvent
    // 0x83c154: add             SP, SP, #0x10
    // 0x83c158: r0 = Null
    //     0x83c158: mov             x0, NULL
    // 0x83c15c: LeaveFrame
    //     0x83c15c: mov             SP, fp
    //     0x83c160: ldp             fp, lr, [SP], #0x10
    // 0x83c164: ret
    //     0x83c164: ret             
    // 0x83c168: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83c168: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83c16c: b               #0x83c05c
    // 0x83c170: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83c170: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bf794, size: 0x178
    // 0x9bf794: EnterFrame
    //     0x9bf794: stp             fp, lr, [SP, #-0x10]!
    //     0x9bf798: mov             fp, SP
    // 0x9bf79c: CheckStackOverflow
    //     0x9bf79c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bf7a0: cmp             SP, x16
    //     0x9bf7a4: b.ls            #0x9bf904
    // 0x9bf7a8: ldr             x0, [fp, #0x10]
    // 0x9bf7ac: r2 = Null
    //     0x9bf7ac: mov             x2, NULL
    // 0x9bf7b0: r1 = Null
    //     0x9bf7b0: mov             x1, NULL
    // 0x9bf7b4: r4 = 59
    //     0x9bf7b4: mov             x4, #0x3b
    // 0x9bf7b8: branchIfSmi(r0, 0x9bf7c4)
    //     0x9bf7b8: tbz             w0, #0, #0x9bf7c4
    // 0x9bf7bc: r4 = LoadClassIdInstr(r0)
    //     0x9bf7bc: ldur            x4, [x0, #-1]
    //     0x9bf7c0: ubfx            x4, x4, #0xc, #0x14
    // 0x9bf7c4: cmp             x4, #0x7e6
    // 0x9bf7c8: b.eq            #0x9bf7d8
    // 0x9bf7cc: r8 = PipelineOwner
    //     0x9bf7cc: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9bf7d0: r3 = Null
    //     0x9bf7d0: ldr             x3, [PP, #0x4db0]  ; [pp+0x4db0] Null
    // 0x9bf7d4: r0 = DefaultTypeTest()
    //     0x9bf7d4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bf7d8: ldr             x0, [fp, #0x10]
    // 0x9bf7dc: ldr             x1, [fp, #0x18]
    // 0x9bf7e0: StoreField: r1->field_f = r0
    //     0x9bf7e0: stur            w0, [x1, #0xf]
    //     0x9bf7e4: ldurb           w16, [x1, #-1]
    //     0x9bf7e8: ldurb           w17, [x0, #-1]
    //     0x9bf7ec: and             x16, x17, x16, lsr #2
    //     0x9bf7f0: tst             x16, HEAP, lsr #32
    //     0x9bf7f4: b.eq            #0x9bf7fc
    //     0x9bf7f8: bl              #0xd6826c
    // 0x9bf7fc: LoadField: r0 = r1->field_1b
    //     0x9bf7fc: ldur            w0, [x1, #0x1b]
    // 0x9bf800: DecompressPointer r0
    //     0x9bf800: add             x0, x0, HEAP, lsl #32
    // 0x9bf804: tbnz            w0, #4, #0x9bf840
    // 0x9bf808: LoadField: r0 = r1->field_1f
    //     0x9bf808: ldur            w0, [x1, #0x1f]
    // 0x9bf80c: DecompressPointer r0
    //     0x9bf80c: add             x0, x0, HEAP, lsl #32
    // 0x9bf810: cmp             w0, NULL
    // 0x9bf814: b.eq            #0x9bf840
    // 0x9bf818: r2 = false
    //     0x9bf818: add             x2, NULL, #0x30  ; false
    // 0x9bf81c: StoreField: r1->field_1b = r2
    //     0x9bf81c: stur            w2, [x1, #0x1b]
    // 0x9bf820: r0 = LoadClassIdInstr(r1)
    //     0x9bf820: ldur            x0, [x1, #-1]
    //     0x9bf824: ubfx            x0, x0, #0xc, #0x14
    // 0x9bf828: SaveReg r1
    //     0x9bf828: str             x1, [SP, #-8]!
    // 0x9bf82c: r0 = GDT[cid_x0 + 0xcfc6]()
    //     0x9bf82c: mov             x17, #0xcfc6
    //     0x9bf830: add             lr, x0, x17
    //     0x9bf834: ldr             lr, [x21, lr, lsl #3]
    //     0x9bf838: blr             lr
    // 0x9bf83c: add             SP, SP, #8
    // 0x9bf840: ldr             x0, [fp, #0x18]
    // 0x9bf844: LoadField: r1 = r0->field_33
    //     0x9bf844: ldur            w1, [x0, #0x33]
    // 0x9bf848: DecompressPointer r1
    //     0x9bf848: add             x1, x1, HEAP, lsl #32
    // 0x9bf84c: tbnz            w1, #4, #0x9bf864
    // 0x9bf850: r1 = false
    //     0x9bf850: add             x1, NULL, #0x30  ; false
    // 0x9bf854: StoreField: r0->field_33 = r1
    //     0x9bf854: stur            w1, [x0, #0x33]
    // 0x9bf858: SaveReg r0
    //     0x9bf858: str             x0, [SP, #-8]!
    // 0x9bf85c: r0 = markNeedsCompositingBitsUpdate()
    //     0x9bf85c: bl              #0x5e5c40  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsCompositingBitsUpdate
    // 0x9bf860: add             SP, SP, #8
    // 0x9bf864: ldr             x1, [fp, #0x18]
    // 0x9bf868: LoadField: r0 = r1->field_3b
    //     0x9bf868: ldur            w0, [x1, #0x3b]
    // 0x9bf86c: DecompressPointer r0
    //     0x9bf86c: add             x0, x0, HEAP, lsl #32
    // 0x9bf870: tbnz            w0, #4, #0x9bf8b4
    // 0x9bf874: LoadField: r0 = r1->field_2f
    //     0x9bf874: ldur            w0, [x1, #0x2f]
    // 0x9bf878: DecompressPointer r0
    //     0x9bf878: add             x0, x0, HEAP, lsl #32
    // 0x9bf87c: LoadField: r2 = r0->field_b
    //     0x9bf87c: ldur            w2, [x0, #0xb]
    // 0x9bf880: DecompressPointer r2
    //     0x9bf880: add             x2, x2, HEAP, lsl #32
    // 0x9bf884: cmp             w2, NULL
    // 0x9bf888: b.eq            #0x9bf8b4
    // 0x9bf88c: r2 = false
    //     0x9bf88c: add             x2, NULL, #0x30  ; false
    // 0x9bf890: StoreField: r1->field_3b = r2
    //     0x9bf890: stur            w2, [x1, #0x3b]
    // 0x9bf894: r0 = LoadClassIdInstr(r1)
    //     0x9bf894: ldur            x0, [x1, #-1]
    //     0x9bf898: ubfx            x0, x0, #0xc, #0x14
    // 0x9bf89c: SaveReg r1
    //     0x9bf89c: str             x1, [SP, #-8]!
    // 0x9bf8a0: r0 = GDT[cid_x0 + 0xd3b6]()
    //     0x9bf8a0: mov             x17, #0xd3b6
    //     0x9bf8a4: add             lr, x0, x17
    //     0x9bf8a8: ldr             lr, [x21, lr, lsl #3]
    //     0x9bf8ac: blr             lr
    // 0x9bf8b0: add             SP, SP, #8
    // 0x9bf8b4: ldr             x0, [fp, #0x18]
    // 0x9bf8b8: LoadField: r1 = r0->field_47
    //     0x9bf8b8: ldur            w1, [x0, #0x47]
    // 0x9bf8bc: DecompressPointer r1
    //     0x9bf8bc: add             x1, x1, HEAP, lsl #32
    // 0x9bf8c0: tbnz            w1, #4, #0x9bf8f4
    // 0x9bf8c4: SaveReg r0
    //     0x9bf8c4: str             x0, [SP, #-8]!
    // 0x9bf8c8: r0 = _semanticsConfiguration()
    //     0x9bf8c8: bl              #0x5102cc  ; [package:flutter/src/rendering/object.dart] RenderObject::_semanticsConfiguration
    // 0x9bf8cc: add             SP, SP, #8
    // 0x9bf8d0: LoadField: r1 = r0->field_7
    //     0x9bf8d0: ldur            w1, [x0, #7]
    // 0x9bf8d4: DecompressPointer r1
    //     0x9bf8d4: add             x1, x1, HEAP, lsl #32
    // 0x9bf8d8: tbnz            w1, #4, #0x9bf8f4
    // 0x9bf8dc: ldr             x0, [fp, #0x18]
    // 0x9bf8e0: r1 = false
    //     0x9bf8e0: add             x1, NULL, #0x30  ; false
    // 0x9bf8e4: StoreField: r0->field_47 = r1
    //     0x9bf8e4: stur            w1, [x0, #0x47]
    // 0x9bf8e8: SaveReg r0
    //     0x9bf8e8: str             x0, [SP, #-8]!
    // 0x9bf8ec: r0 = markNeedsSemanticsUpdate()
    //     0x9bf8ec: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x9bf8f0: add             SP, SP, #8
    // 0x9bf8f4: r0 = Null
    //     0x9bf8f4: mov             x0, NULL
    // 0x9bf8f8: LeaveFrame
    //     0x9bf8f8: mov             SP, fp
    //     0x9bf8fc: ldp             fp, lr, [SP], #0x10
    // 0x9bf900: ret
    //     0x9bf900: ret             
    // 0x9bf904: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bf904: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bf908: b               #0x9bf7a8
  }
  _ toString(/* No info */) {
    // ** addr: 0xad8da0, size: 0x60
    // 0xad8da0: EnterFrame
    //     0xad8da0: stp             fp, lr, [SP, #-0x10]!
    //     0xad8da4: mov             fp, SP
    // 0xad8da8: mov             x0, x4
    // 0xad8dac: LoadField: r1 = r0->field_13
    //     0xad8dac: ldur            w1, [x0, #0x13]
    // 0xad8db0: DecompressPointer r1
    //     0xad8db0: add             x1, x1, HEAP, lsl #32
    // 0xad8db4: sub             x0, x1, #2
    // 0xad8db8: add             x1, fp, w0, sxtw #2
    // 0xad8dbc: ldr             x1, [x1, #0x10]
    // 0xad8dc0: CheckStackOverflow
    //     0xad8dc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad8dc4: cmp             SP, x16
    //     0xad8dc8: b.ls            #0xad8df8
    // 0xad8dcc: r0 = LoadClassIdInstr(r1)
    //     0xad8dcc: ldur            x0, [x1, #-1]
    //     0xad8dd0: ubfx            x0, x0, #0xc, #0x14
    // 0xad8dd4: SaveReg r1
    //     0xad8dd4: str             x1, [SP, #-8]!
    // 0xad8dd8: r0 = GDT[cid_x0 + 0x9892]()
    //     0xad8dd8: mov             x17, #0x9892
    //     0xad8ddc: add             lr, x0, x17
    //     0xad8de0: ldr             lr, [x21, lr, lsl #3]
    //     0xad8de4: blr             lr
    // 0xad8de8: add             SP, SP, #8
    // 0xad8dec: LeaveFrame
    //     0xad8dec: mov             SP, fp
    //     0xad8df0: ldp             fp, lr, [SP], #0x10
    // 0xad8df4: ret
    //     0xad8df4: ret             
    // 0xad8df8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad8df8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad8dfc: b               #0xad8dcc
  }
}

// class id: 2402, size: 0x50, field offset: 0x50
abstract class RelayoutWhenSystemFontsChangeMixin extends RenderObject {
}

// class id: 2545, size: 0x54, field offset: 0x50
abstract class RenderObjectWithChildMixin<X0 bound RenderObject> extends RenderObject {
}

// class id: 2548, size: 0x54, field offset: 0x50
abstract class ContainerRenderObjectMixin<X0 bound RenderObject, X1 bound ContainerParentDataMixin<X0 bound RenderObject>> extends RenderObject {
}

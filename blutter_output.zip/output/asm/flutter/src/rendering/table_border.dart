// lib: , url: package:flutter/src/rendering/table_border.dart

// class id: 1049430, size: 0x8
class :: {
}

// class id: 1984, size: 0x24, field offset: 0x8
//   const constructor, 
class TableBorder extends Object {

  BorderSide field_8;
  BorderSide field_c;
  BorderSide field_10;
  BorderSide field_14;
  BorderSide field_18;
  BorderSide field_1c;
  BorderRadius field_20;

  _ paint(/* No info */) {
    // ** addr: 0x66fff0, size: 0x1fc
    // 0x66fff0: EnterFrame
    //     0x66fff0: stp             fp, lr, [SP, #-0x10]!
    //     0x66fff4: mov             fp, SP
    // 0x66fff8: AllocStack(0x18)
    //     0x66fff8: sub             SP, SP, #0x18
    // 0x66fffc: CheckStackOverflow
    //     0x66fffc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x670000: cmp             SP, x16
    //     0x670004: b.ls            #0x6701e4
    // 0x670008: ldr             x1, [fp, #0x18]
    // 0x67000c: r0 = LoadClassIdInstr(r1)
    //     0x67000c: ldur            x0, [x1, #-1]
    //     0x670010: ubfx            x0, x0, #0xc, #0x14
    // 0x670014: SaveReg r1
    //     0x670014: str             x1, [SP, #-8]!
    // 0x670018: r0 = GDT[cid_x0 + 0xcc6c]()
    //     0x670018: mov             x17, #0xcc6c
    //     0x67001c: add             lr, x0, x17
    //     0x670020: ldr             lr, [x21, lr, lsl #3]
    //     0x670024: blr             lr
    // 0x670028: add             SP, SP, #8
    // 0x67002c: tbz             w0, #4, #0x670058
    // 0x670030: ldr             x1, [fp, #0x10]
    // 0x670034: r0 = LoadClassIdInstr(r1)
    //     0x670034: ldur            x0, [x1, #-1]
    //     0x670038: ubfx            x0, x0, #0xc, #0x14
    // 0x67003c: SaveReg r1
    //     0x67003c: str             x1, [SP, #-8]!
    // 0x670040: r0 = GDT[cid_x0 + 0xcc6c]()
    //     0x670040: mov             x17, #0xcc6c
    //     0x670044: add             lr, x0, x17
    //     0x670048: ldr             lr, [x21, lr, lsl #3]
    //     0x67004c: blr             lr
    // 0x670050: add             SP, SP, #8
    // 0x670054: tbnz            w0, #4, #0x6700d0
    // 0x670058: ldr             x1, [fp, #0x18]
    // 0x67005c: ldr             x0, [fp, #0x10]
    // 0x670060: r16 = 112
    //     0x670060: mov             x16, #0x70
    // 0x670064: stp             x16, NULL, [SP, #-0x10]!
    // 0x670068: r0 = ByteData()
    //     0x670068: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x67006c: add             SP, SP, #0x10
    // 0x670070: r0 = Path()
    //     0x670070: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0x670074: SaveReg r0
    //     0x670074: str             x0, [SP, #-8]!
    // 0x670078: r0 = _constructor()
    //     0x670078: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0x67007c: add             SP, SP, #8
    // 0x670080: ldr             x0, [fp, #0x18]
    // 0x670084: r1 = LoadClassIdInstr(r0)
    //     0x670084: ldur            x1, [x0, #-1]
    //     0x670088: ubfx            x1, x1, #0xc, #0x14
    // 0x67008c: SaveReg r0
    //     0x67008c: str             x0, [SP, #-8]!
    // 0x670090: mov             x0, x1
    // 0x670094: r0 = GDT[cid_x0 + 0xcc6c]()
    //     0x670094: mov             x17, #0xcc6c
    //     0x670098: add             lr, x0, x17
    //     0x67009c: ldr             lr, [x21, lr, lsl #3]
    //     0x6700a0: blr             lr
    // 0x6700a4: add             SP, SP, #8
    // 0x6700a8: ldr             x0, [fp, #0x10]
    // 0x6700ac: r1 = LoadClassIdInstr(r0)
    //     0x6700ac: ldur            x1, [x0, #-1]
    //     0x6700b0: ubfx            x1, x1, #0xc, #0x14
    // 0x6700b4: SaveReg r0
    //     0x6700b4: str             x0, [SP, #-8]!
    // 0x6700b8: mov             x0, x1
    // 0x6700bc: r0 = GDT[cid_x0 + 0xcc6c]()
    //     0x6700bc: mov             x17, #0xcc6c
    //     0x6700c0: add             lr, x0, x17
    //     0x6700c4: ldr             lr, [x21, lr, lsl #3]
    //     0x6700c8: blr             lr
    // 0x6700cc: add             SP, SP, #8
    // 0x6700d0: ldr             x16, [fp, #0x30]
    // 0x6700d4: SaveReg r16
    //     0x6700d4: str             x16, [SP, #-8]!
    // 0x6700d8: r0 = isUniform()
    //     0x6700d8: bl              #0x6715d0  ; [package:flutter/src/rendering/table_border.dart] TableBorder::isUniform
    // 0x6700dc: add             SP, SP, #8
    // 0x6700e0: tbnz            w0, #4, #0x670104
    // 0x6700e4: r16 = Instance_BorderRadius
    //     0x6700e4: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c0] Obj!BorderRadius@b37471
    //     0x6700e8: ldr             x16, [x16, #0x2c0]
    // 0x6700ec: r30 = Instance_BorderRadius
    //     0x6700ec: add             lr, PP, #0x15, lsl #12  ; [pp+0x152c0] Obj!BorderRadius@b37471
    //     0x6700f0: ldr             lr, [lr, #0x2c0]
    // 0x6700f4: stp             lr, x16, [SP, #-0x10]!
    // 0x6700f8: r0 = ==()
    //     0x6700f8: bl              #0xc9c94c  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0x6700fc: add             SP, SP, #0x10
    // 0x670100: tbnz            w0, #4, #0x670144
    // 0x670104: ldr             x16, [fp, #0x28]
    // 0x670108: ldr             lr, [fp, #0x20]
    // 0x67010c: stp             lr, x16, [SP, #-0x10]!
    // 0x670110: r16 = Instance_BorderSide
    //     0x670110: add             x16, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0x670114: ldr             x16, [x16, #0x2f0]
    // 0x670118: r30 = Instance_BorderSide
    //     0x670118: add             lr, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0x67011c: ldr             lr, [lr, #0x2f0]
    // 0x670120: stp             lr, x16, [SP, #-0x10]!
    // 0x670124: r16 = Instance_BorderSide
    //     0x670124: add             x16, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0x670128: ldr             x16, [x16, #0x2f0]
    // 0x67012c: r30 = Instance_BorderSide
    //     0x67012c: add             lr, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0x670130: ldr             lr, [lr, #0x2f0]
    // 0x670134: stp             lr, x16, [SP, #-0x10]!
    // 0x670138: r0 = paintBorder()
    //     0x670138: bl              #0x6709c0  ; [package:flutter/src/painting/borders.dart] ::paintBorder
    // 0x67013c: add             SP, SP, #0x30
    // 0x670140: b               #0x6701d4
    // 0x670144: r16 = Instance_BorderRadius
    //     0x670144: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c0] Obj!BorderRadius@b37471
    //     0x670148: ldr             x16, [x16, #0x2c0]
    // 0x67014c: ldr             lr, [fp, #0x20]
    // 0x670150: stp             lr, x16, [SP, #-0x10]!
    // 0x670154: r0 = toRRect()
    //     0x670154: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x670158: add             SP, SP, #0x10
    // 0x67015c: mov             x1, x0
    // 0x670160: r0 = Instance_BorderSide
    //     0x670160: add             x0, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0x670164: ldr             x0, [x0, #0x2f0]
    // 0x670168: stur            x1, [fp, #-8]
    // 0x67016c: LoadField: d0 = r0->field_b
    //     0x67016c: ldur            d0, [x0, #0xb]
    // 0x670170: SaveReg r1
    //     0x670170: str             x1, [SP, #-8]!
    // 0x670174: SaveReg d0
    //     0x670174: str             d0, [SP, #-8]!
    // 0x670178: r0 = deflate()
    //     0x670178: bl              #0x6705bc  ; [dart:ui] RRect::deflate
    // 0x67017c: add             SP, SP, #0x10
    // 0x670180: stur            x0, [fp, #-0x10]
    // 0x670184: r16 = 112
    //     0x670184: mov             x16, #0x70
    // 0x670188: stp             x16, NULL, [SP, #-0x10]!
    // 0x67018c: r0 = ByteData()
    //     0x67018c: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x670190: add             SP, SP, #0x10
    // 0x670194: stur            x0, [fp, #-0x18]
    // 0x670198: r0 = Paint()
    //     0x670198: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x67019c: mov             x1, x0
    // 0x6701a0: ldur            x0, [fp, #-0x18]
    // 0x6701a4: StoreField: r1->field_7 = r0
    //     0x6701a4: stur            w0, [x1, #7]
    // 0x6701a8: LoadField: r2 = r0->field_17
    //     0x6701a8: ldur            w2, [x0, #0x17]
    // 0x6701ac: DecompressPointer r2
    //     0x6701ac: add             x2, x2, HEAP, lsl #32
    // 0x6701b0: LoadField: r0 = r2->field_7
    //     0x6701b0: ldur            x0, [x2, #7]
    // 0x6701b4: str             wzr, [x0, #4]
    // 0x6701b8: ldr             x16, [fp, #0x28]
    // 0x6701bc: ldur            lr, [fp, #-8]
    // 0x6701c0: stp             lr, x16, [SP, #-0x10]!
    // 0x6701c4: ldur            x16, [fp, #-0x10]
    // 0x6701c8: stp             x1, x16, [SP, #-0x10]!
    // 0x6701cc: r0 = drawDRRect()
    //     0x6701cc: bl              #0x6701ec  ; [dart:ui] Canvas::drawDRRect
    // 0x6701d0: add             SP, SP, #0x20
    // 0x6701d4: r0 = Null
    //     0x6701d4: mov             x0, NULL
    // 0x6701d8: LeaveFrame
    //     0x6701d8: mov             SP, fp
    //     0x6701dc: ldp             fp, lr, [SP], #0x10
    // 0x6701e0: ret
    //     0x6701e0: ret             
    // 0x6701e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6701e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6701e8: b               #0x670008
  }
  get _ isUniform(/* No info */) {
    // ** addr: 0x6715d0, size: 0x44
    // 0x6715d0: r1 = Instance_BorderSide
    //     0x6715d0: add             x1, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0x6715d4: ldr             x1, [x1, #0x2f0]
    // 0x6715d8: LoadField: d0 = r1->field_b
    //     0x6715d8: ldur            d0, [x1, #0xb]
    // 0x6715dc: fcmp            d0, d0
    // 0x6715e0: b.ne            #0x671604
    // 0x6715e4: fcmp            d0, d0
    // 0x6715e8: b.ne            #0x671604
    // 0x6715ec: fcmp            d0, d0
    // 0x6715f0: b.ne            #0x671604
    // 0x6715f4: fcmp            d0, d0
    // 0x6715f8: b.ne            #0x671604
    // 0x6715fc: fcmp            d0, d0
    // 0x671600: b.eq            #0x67160c
    // 0x671604: r0 = false
    //     0x671604: add             x0, NULL, #0x30  ; false
    // 0x671608: ret
    //     0x671608: ret             
    // 0x67160c: r0 = true
    //     0x67160c: add             x0, NULL, #0x20  ; true
    // 0x671610: ret
    //     0x671610: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0xae5fe4, size: 0xdc
    // 0xae5fe4: EnterFrame
    //     0xae5fe4: stp             fp, lr, [SP, #-0x10]!
    //     0xae5fe8: mov             fp, SP
    // 0xae5fec: CheckStackOverflow
    //     0xae5fec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae5ff0: cmp             SP, x16
    //     0xae5ff4: b.ls            #0xae60b8
    // 0xae5ff8: r1 = Null
    //     0xae5ff8: mov             x1, NULL
    // 0xae5ffc: r2 = 30
    //     0xae5ffc: mov             x2, #0x1e
    // 0xae6000: r0 = AllocateArray()
    //     0xae6000: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae6004: r17 = "TableBorder("
    //     0xae6004: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fa40] "TableBorder("
    //     0xae6008: ldr             x17, [x17, #0xa40]
    // 0xae600c: StoreField: r0->field_f = r17
    //     0xae600c: stur            w17, [x0, #0xf]
    // 0xae6010: ldr             x1, [fp, #0x10]
    // 0xae6014: LoadField: r2 = r1->field_7
    //     0xae6014: ldur            w2, [x1, #7]
    // 0xae6018: DecompressPointer r2
    //     0xae6018: add             x2, x2, HEAP, lsl #32
    // 0xae601c: StoreField: r0->field_13 = r2
    //     0xae601c: stur            w2, [x0, #0x13]
    // 0xae6020: r17 = ", "
    //     0xae6020: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae6024: StoreField: r0->field_17 = r17
    //     0xae6024: stur            w17, [x0, #0x17]
    // 0xae6028: LoadField: r2 = r1->field_b
    //     0xae6028: ldur            w2, [x1, #0xb]
    // 0xae602c: DecompressPointer r2
    //     0xae602c: add             x2, x2, HEAP, lsl #32
    // 0xae6030: StoreField: r0->field_1b = r2
    //     0xae6030: stur            w2, [x0, #0x1b]
    // 0xae6034: r17 = ", "
    //     0xae6034: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae6038: StoreField: r0->field_1f = r17
    //     0xae6038: stur            w17, [x0, #0x1f]
    // 0xae603c: LoadField: r2 = r1->field_f
    //     0xae603c: ldur            w2, [x1, #0xf]
    // 0xae6040: DecompressPointer r2
    //     0xae6040: add             x2, x2, HEAP, lsl #32
    // 0xae6044: StoreField: r0->field_23 = r2
    //     0xae6044: stur            w2, [x0, #0x23]
    // 0xae6048: r17 = ", "
    //     0xae6048: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae604c: StoreField: r0->field_27 = r17
    //     0xae604c: stur            w17, [x0, #0x27]
    // 0xae6050: LoadField: r2 = r1->field_13
    //     0xae6050: ldur            w2, [x1, #0x13]
    // 0xae6054: DecompressPointer r2
    //     0xae6054: add             x2, x2, HEAP, lsl #32
    // 0xae6058: StoreField: r0->field_2b = r2
    //     0xae6058: stur            w2, [x0, #0x2b]
    // 0xae605c: r17 = ", "
    //     0xae605c: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae6060: StoreField: r0->field_2f = r17
    //     0xae6060: stur            w17, [x0, #0x2f]
    // 0xae6064: LoadField: r2 = r1->field_17
    //     0xae6064: ldur            w2, [x1, #0x17]
    // 0xae6068: DecompressPointer r2
    //     0xae6068: add             x2, x2, HEAP, lsl #32
    // 0xae606c: StoreField: r0->field_33 = r2
    //     0xae606c: stur            w2, [x0, #0x33]
    // 0xae6070: r17 = ", "
    //     0xae6070: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae6074: StoreField: r0->field_37 = r17
    //     0xae6074: stur            w17, [x0, #0x37]
    // 0xae6078: LoadField: r2 = r1->field_1b
    //     0xae6078: ldur            w2, [x1, #0x1b]
    // 0xae607c: DecompressPointer r2
    //     0xae607c: add             x2, x2, HEAP, lsl #32
    // 0xae6080: StoreField: r0->field_3b = r2
    //     0xae6080: stur            w2, [x0, #0x3b]
    // 0xae6084: r17 = ", "
    //     0xae6084: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae6088: StoreField: r0->field_3f = r17
    //     0xae6088: stur            w17, [x0, #0x3f]
    // 0xae608c: LoadField: r2 = r1->field_1f
    //     0xae608c: ldur            w2, [x1, #0x1f]
    // 0xae6090: DecompressPointer r2
    //     0xae6090: add             x2, x2, HEAP, lsl #32
    // 0xae6094: StoreField: r0->field_43 = r2
    //     0xae6094: stur            w2, [x0, #0x43]
    // 0xae6098: r17 = ")"
    //     0xae6098: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae609c: StoreField: r0->field_47 = r17
    //     0xae609c: stur            w17, [x0, #0x47]
    // 0xae60a0: SaveReg r0
    //     0xae60a0: str             x0, [SP, #-8]!
    // 0xae60a4: r0 = _interpolate()
    //     0xae60a4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae60a8: add             SP, SP, #8
    // 0xae60ac: LeaveFrame
    //     0xae60ac: mov             SP, fp
    //     0xae60b0: ldp             fp, lr, [SP], #0x10
    // 0xae60b4: ret
    //     0xae60b4: ret             
    // 0xae60b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae60b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae60bc: b               #0xae5ff8
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb0f6ac, size: 0x94
    // 0xb0f6ac: EnterFrame
    //     0xb0f6ac: stp             fp, lr, [SP, #-0x10]!
    //     0xb0f6b0: mov             fp, SP
    // 0xb0f6b4: CheckStackOverflow
    //     0xb0f6b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0f6b8: cmp             SP, x16
    //     0xb0f6bc: b.ls            #0xb0f738
    // 0xb0f6c0: r16 = Instance_BorderSide
    //     0xb0f6c0: add             x16, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xb0f6c4: ldr             x16, [x16, #0x2f0]
    // 0xb0f6c8: r30 = Instance_BorderSide
    //     0xb0f6c8: add             lr, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xb0f6cc: ldr             lr, [lr, #0x2f0]
    // 0xb0f6d0: stp             lr, x16, [SP, #-0x10]!
    // 0xb0f6d4: r16 = Instance_BorderSide
    //     0xb0f6d4: add             x16, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xb0f6d8: ldr             x16, [x16, #0x2f0]
    // 0xb0f6dc: r30 = Instance_BorderSide
    //     0xb0f6dc: add             lr, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xb0f6e0: ldr             lr, [lr, #0x2f0]
    // 0xb0f6e4: stp             lr, x16, [SP, #-0x10]!
    // 0xb0f6e8: r16 = Instance_BorderSide
    //     0xb0f6e8: add             x16, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xb0f6ec: ldr             x16, [x16, #0x2f0]
    // 0xb0f6f0: r30 = Instance_BorderSide
    //     0xb0f6f0: add             lr, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xb0f6f4: ldr             lr, [lr, #0x2f0]
    // 0xb0f6f8: stp             lr, x16, [SP, #-0x10]!
    // 0xb0f6fc: r16 = Instance_BorderRadius
    //     0xb0f6fc: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c0] Obj!BorderRadius@b37471
    //     0xb0f700: ldr             x16, [x16, #0x2c0]
    // 0xb0f704: SaveReg r16
    //     0xb0f704: str             x16, [SP, #-8]!
    // 0xb0f708: r4 = const [0, 0x7, 0x7, 0x7, null]
    //     0xb0f708: ldr             x4, [PP, #0x2450]  ; [pp+0x2450] List(5) [0, 0x7, 0x7, 0x7, Null]
    // 0xb0f70c: r0 = hash()
    //     0xb0f70c: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0f710: add             SP, SP, #0x38
    // 0xb0f714: mov             x2, x0
    // 0xb0f718: r0 = BoxInt64Instr(r2)
    //     0xb0f718: sbfiz           x0, x2, #1, #0x1f
    //     0xb0f71c: cmp             x2, x0, asr #1
    //     0xb0f720: b.eq            #0xb0f72c
    //     0xb0f724: bl              #0xd69bb8
    //     0xb0f728: stur            x2, [x0, #7]
    // 0xb0f72c: LeaveFrame
    //     0xb0f72c: mov             SP, fp
    //     0xb0f730: ldp             fp, lr, [SP], #0x10
    // 0xb0f734: ret
    //     0xb0f734: ret             
    // 0xb0f738: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0f738: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0f73c: b               #0xb0f6c0
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9f584, size: 0x1c8
    // 0xc9f584: EnterFrame
    //     0xc9f584: stp             fp, lr, [SP, #-0x10]!
    //     0xc9f588: mov             fp, SP
    // 0xc9f58c: CheckStackOverflow
    //     0xc9f58c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc9f590: cmp             SP, x16
    //     0xc9f594: b.ls            #0xc9f744
    // 0xc9f598: ldr             x1, [fp, #0x10]
    // 0xc9f59c: cmp             w1, NULL
    // 0xc9f5a0: b.ne            #0xc9f5b4
    // 0xc9f5a4: r0 = false
    //     0xc9f5a4: add             x0, NULL, #0x30  ; false
    // 0xc9f5a8: LeaveFrame
    //     0xc9f5a8: mov             SP, fp
    //     0xc9f5ac: ldp             fp, lr, [SP], #0x10
    // 0xc9f5b0: ret
    //     0xc9f5b0: ret             
    // 0xc9f5b4: ldr             x0, [fp, #0x18]
    // 0xc9f5b8: cmp             w0, w1
    // 0xc9f5bc: b.ne            #0xc9f5d0
    // 0xc9f5c0: r0 = true
    //     0xc9f5c0: add             x0, NULL, #0x20  ; true
    // 0xc9f5c4: LeaveFrame
    //     0xc9f5c4: mov             SP, fp
    //     0xc9f5c8: ldp             fp, lr, [SP], #0x10
    // 0xc9f5cc: ret
    //     0xc9f5cc: ret             
    // 0xc9f5d0: r0 = 59
    //     0xc9f5d0: mov             x0, #0x3b
    // 0xc9f5d4: branchIfSmi(r1, 0xc9f5e0)
    //     0xc9f5d4: tbz             w1, #0, #0xc9f5e0
    // 0xc9f5d8: r0 = LoadClassIdInstr(r1)
    //     0xc9f5d8: ldur            x0, [x1, #-1]
    //     0xc9f5dc: ubfx            x0, x0, #0xc, #0x14
    // 0xc9f5e0: SaveReg r1
    //     0xc9f5e0: str             x1, [SP, #-8]!
    // 0xc9f5e4: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc9f5e4: mov             x17, #0x57c5
    //     0xc9f5e8: add             lr, x0, x17
    //     0xc9f5ec: ldr             lr, [x21, lr, lsl #3]
    //     0xc9f5f0: blr             lr
    // 0xc9f5f4: add             SP, SP, #8
    // 0xc9f5f8: r1 = LoadClassIdInstr(r0)
    //     0xc9f5f8: ldur            x1, [x0, #-1]
    //     0xc9f5fc: ubfx            x1, x1, #0xc, #0x14
    // 0xc9f600: r16 = TableBorder
    //     0xc9f600: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4fa48] Type: TableBorder
    //     0xc9f604: ldr             x16, [x16, #0xa48]
    // 0xc9f608: stp             x16, x0, [SP, #-0x10]!
    // 0xc9f60c: mov             x0, x1
    // 0xc9f610: mov             lr, x0
    // 0xc9f614: ldr             lr, [x21, lr, lsl #3]
    // 0xc9f618: blr             lr
    // 0xc9f61c: add             SP, SP, #0x10
    // 0xc9f620: tbz             w0, #4, #0xc9f634
    // 0xc9f624: r0 = false
    //     0xc9f624: add             x0, NULL, #0x30  ; false
    // 0xc9f628: LeaveFrame
    //     0xc9f628: mov             SP, fp
    //     0xc9f62c: ldp             fp, lr, [SP], #0x10
    // 0xc9f630: ret
    //     0xc9f630: ret             
    // 0xc9f634: ldr             x0, [fp, #0x10]
    // 0xc9f638: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc9f638: mov             x1, #0x76
    //     0xc9f63c: tbz             w0, #0, #0xc9f64c
    //     0xc9f640: ldur            x1, [x0, #-1]
    //     0xc9f644: ubfx            x1, x1, #0xc, #0x14
    //     0xc9f648: lsl             x1, x1, #1
    // 0xc9f64c: cmp             w1, #0xf80
    // 0xc9f650: b.ne            #0xc9f734
    // 0xc9f654: r16 = Instance_BorderSide
    //     0xc9f654: add             x16, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xc9f658: ldr             x16, [x16, #0x2f0]
    // 0xc9f65c: r30 = Instance_BorderSide
    //     0xc9f65c: add             lr, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xc9f660: ldr             lr, [lr, #0x2f0]
    // 0xc9f664: stp             lr, x16, [SP, #-0x10]!
    // 0xc9f668: r0 = ==()
    //     0xc9f668: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xc9f66c: add             SP, SP, #0x10
    // 0xc9f670: tbnz            w0, #4, #0xc9f734
    // 0xc9f674: r16 = Instance_BorderSide
    //     0xc9f674: add             x16, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xc9f678: ldr             x16, [x16, #0x2f0]
    // 0xc9f67c: r30 = Instance_BorderSide
    //     0xc9f67c: add             lr, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xc9f680: ldr             lr, [lr, #0x2f0]
    // 0xc9f684: stp             lr, x16, [SP, #-0x10]!
    // 0xc9f688: r0 = ==()
    //     0xc9f688: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xc9f68c: add             SP, SP, #0x10
    // 0xc9f690: tbnz            w0, #4, #0xc9f734
    // 0xc9f694: r16 = Instance_BorderSide
    //     0xc9f694: add             x16, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xc9f698: ldr             x16, [x16, #0x2f0]
    // 0xc9f69c: r30 = Instance_BorderSide
    //     0xc9f69c: add             lr, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xc9f6a0: ldr             lr, [lr, #0x2f0]
    // 0xc9f6a4: stp             lr, x16, [SP, #-0x10]!
    // 0xc9f6a8: r0 = ==()
    //     0xc9f6a8: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xc9f6ac: add             SP, SP, #0x10
    // 0xc9f6b0: tbnz            w0, #4, #0xc9f734
    // 0xc9f6b4: r16 = Instance_BorderSide
    //     0xc9f6b4: add             x16, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xc9f6b8: ldr             x16, [x16, #0x2f0]
    // 0xc9f6bc: r30 = Instance_BorderSide
    //     0xc9f6bc: add             lr, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xc9f6c0: ldr             lr, [lr, #0x2f0]
    // 0xc9f6c4: stp             lr, x16, [SP, #-0x10]!
    // 0xc9f6c8: r0 = ==()
    //     0xc9f6c8: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xc9f6cc: add             SP, SP, #0x10
    // 0xc9f6d0: tbnz            w0, #4, #0xc9f734
    // 0xc9f6d4: r16 = Instance_BorderSide
    //     0xc9f6d4: add             x16, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xc9f6d8: ldr             x16, [x16, #0x2f0]
    // 0xc9f6dc: r30 = Instance_BorderSide
    //     0xc9f6dc: add             lr, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xc9f6e0: ldr             lr, [lr, #0x2f0]
    // 0xc9f6e4: stp             lr, x16, [SP, #-0x10]!
    // 0xc9f6e8: r0 = ==()
    //     0xc9f6e8: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xc9f6ec: add             SP, SP, #0x10
    // 0xc9f6f0: tbnz            w0, #4, #0xc9f734
    // 0xc9f6f4: r16 = Instance_BorderSide
    //     0xc9f6f4: add             x16, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xc9f6f8: ldr             x16, [x16, #0x2f0]
    // 0xc9f6fc: r30 = Instance_BorderSide
    //     0xc9f6fc: add             lr, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xc9f700: ldr             lr, [lr, #0x2f0]
    // 0xc9f704: stp             lr, x16, [SP, #-0x10]!
    // 0xc9f708: r0 = ==()
    //     0xc9f708: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xc9f70c: add             SP, SP, #0x10
    // 0xc9f710: tbnz            w0, #4, #0xc9f734
    // 0xc9f714: r16 = Instance_BorderRadius
    //     0xc9f714: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c0] Obj!BorderRadius@b37471
    //     0xc9f718: ldr             x16, [x16, #0x2c0]
    // 0xc9f71c: r30 = Instance_BorderRadius
    //     0xc9f71c: add             lr, PP, #0x15, lsl #12  ; [pp+0x152c0] Obj!BorderRadius@b37471
    //     0xc9f720: ldr             lr, [lr, #0x2c0]
    // 0xc9f724: stp             lr, x16, [SP, #-0x10]!
    // 0xc9f728: r0 = ==()
    //     0xc9f728: bl              #0xc9c94c  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0xc9f72c: add             SP, SP, #0x10
    // 0xc9f730: b               #0xc9f738
    // 0xc9f734: r0 = false
    //     0xc9f734: add             x0, NULL, #0x30  ; false
    // 0xc9f738: LeaveFrame
    //     0xc9f738: mov             SP, fp
    //     0xc9f73c: ldp             fp, lr, [SP], #0x10
    // 0xc9f740: ret
    //     0xc9f740: ret             
    // 0xc9f744: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc9f744: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc9f748: b               #0xc9f598
  }
}

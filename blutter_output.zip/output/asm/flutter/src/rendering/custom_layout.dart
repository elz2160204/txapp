// lib: , url: package:flutter/src/rendering/custom_layout.dart

// class id: 1049396, size: 0x8
class :: {
}

// class id: 2058, size: 0x1c, field offset: 0x18
class MultiChildLayoutParentData extends ContainerBoxParentData<RenderBox> {

  _ toString(/* No info */) {
    // ** addr: 0xae451c, size: 0x80
    // 0xae451c: EnterFrame
    //     0xae451c: stp             fp, lr, [SP, #-0x10]!
    //     0xae4520: mov             fp, SP
    // 0xae4524: AllocStack(0x8)
    //     0xae4524: sub             SP, SP, #8
    // 0xae4528: CheckStackOverflow
    //     0xae4528: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae452c: cmp             SP, x16
    //     0xae4530: b.ls            #0xae4594
    // 0xae4534: ldr             x16, [fp, #0x10]
    // 0xae4538: SaveReg r16
    //     0xae4538: str             x16, [SP, #-8]!
    // 0xae453c: r0 = toString()
    //     0xae453c: bl              #0xae516c  ; [package:flutter/src/rendering/box.dart] BoxParentData::toString
    // 0xae4540: add             SP, SP, #8
    // 0xae4544: r1 = Null
    //     0xae4544: mov             x1, NULL
    // 0xae4548: r2 = 6
    //     0xae4548: mov             x2, #6
    // 0xae454c: stur            x0, [fp, #-8]
    // 0xae4550: r0 = AllocateArray()
    //     0xae4550: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae4554: mov             x1, x0
    // 0xae4558: ldur            x0, [fp, #-8]
    // 0xae455c: StoreField: r1->field_f = r0
    //     0xae455c: stur            w0, [x1, #0xf]
    // 0xae4560: r17 = "; id="
    //     0xae4560: add             x17, PP, #0x37, lsl #12  ; [pp+0x37138] "; id="
    //     0xae4564: ldr             x17, [x17, #0x138]
    // 0xae4568: StoreField: r1->field_13 = r17
    //     0xae4568: stur            w17, [x1, #0x13]
    // 0xae456c: ldr             x0, [fp, #0x10]
    // 0xae4570: LoadField: r2 = r0->field_17
    //     0xae4570: ldur            w2, [x0, #0x17]
    // 0xae4574: DecompressPointer r2
    //     0xae4574: add             x2, x2, HEAP, lsl #32
    // 0xae4578: StoreField: r1->field_17 = r2
    //     0xae4578: stur            w2, [x1, #0x17]
    // 0xae457c: SaveReg r1
    //     0xae457c: str             x1, [SP, #-8]!
    // 0xae4580: r0 = _interpolate()
    //     0xae4580: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae4584: add             SP, SP, #8
    // 0xae4588: LeaveFrame
    //     0xae4588: mov             SP, fp
    //     0xae458c: ldp             fp, lr, [SP], #0x10
    // 0xae4590: ret
    //     0xae4590: ret             
    // 0xae4594: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae4594: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae4598: b               #0xae4534
  }
}

// class id: 2150, size: 0x10, field offset: 0x8
abstract class MultiChildLayoutDelegate extends Object {

  _ _callPerformLayout(/* No info */) {
    // ** addr: 0x68e724, size: 0x1e8
    // 0x68e724: EnterFrame
    //     0x68e724: stp             fp, lr, [SP, #-0x10]!
    //     0x68e728: mov             fp, SP
    // 0x68e72c: AllocStack(0x78)
    //     0x68e72c: sub             SP, SP, #0x78
    // 0x68e730: CheckStackOverflow
    //     0x68e730: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68e734: cmp             SP, x16
    //     0x68e738: b.ls            #0x68e8f0
    // 0x68e73c: ldr             x0, [fp, #0x20]
    // 0x68e740: LoadField: r1 = r0->field_b
    //     0x68e740: ldur            w1, [x0, #0xb]
    // 0x68e744: DecompressPointer r1
    //     0x68e744: add             x1, x1, HEAP, lsl #32
    // 0x68e748: stur            x1, [fp, #-0x50]
    // 0x68e74c: ldr             x2, [fp, #0x10]
    // 0x68e750: r16 = <Object, RenderBox>
    //     0x68e750: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2d740] TypeArguments: <Object, RenderBox>
    //     0x68e754: ldr             x16, [x16, #0x740]
    // 0x68e758: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x68e75c: stp             lr, x16, [SP, #-0x10]!
    // 0x68e760: r0 = Map._fromLiteral()
    //     0x68e760: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x68e764: add             SP, SP, #0x10
    // 0x68e768: ldr             x3, [fp, #0x20]
    // 0x68e76c: StoreField: r3->field_b = r0
    //     0x68e76c: stur            w0, [x3, #0xb]
    //     0x68e770: tbz             w0, #0, #0x68e78c
    //     0x68e774: ldurb           w16, [x3, #-1]
    //     0x68e778: ldurb           w17, [x0, #-1]
    //     0x68e77c: and             x16, x17, x16, lsr #2
    //     0x68e780: tst             x16, HEAP, lsr #32
    //     0x68e784: b.eq            #0x68e78c
    //     0x68e788: bl              #0xd682ac
    // 0x68e78c: ldr             x4, [fp, #0x10]
    // 0x68e790: stur            x4, [fp, #-0x60]
    // 0x68e794: CheckStackOverflow
    //     0x68e794: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68e798: cmp             SP, x16
    //     0x68e79c: b.ls            #0x68e8f8
    // 0x68e7a0: cmp             w4, NULL
    // 0x68e7a4: b.eq            #0x68e85c
    // 0x68e7a8: LoadField: r5 = r4->field_17
    //     0x68e7a8: ldur            w5, [x4, #0x17]
    // 0x68e7ac: DecompressPointer r5
    //     0x68e7ac: add             x5, x5, HEAP, lsl #32
    // 0x68e7b0: stur            x5, [fp, #-0x58]
    // 0x68e7b4: cmp             w5, NULL
    // 0x68e7b8: b.eq            #0x68e900
    // 0x68e7bc: mov             x0, x5
    // 0x68e7c0: r2 = Null
    //     0x68e7c0: mov             x2, NULL
    // 0x68e7c4: r1 = Null
    //     0x68e7c4: mov             x1, NULL
    // 0x68e7c8: r4 = LoadClassIdInstr(r0)
    //     0x68e7c8: ldur            x4, [x0, #-1]
    //     0x68e7cc: ubfx            x4, x4, #0xc, #0x14
    // 0x68e7d0: cmp             x4, #0x80a
    // 0x68e7d4: b.eq            #0x68e7ec
    // 0x68e7d8: r8 = MultiChildLayoutParentData<RenderBox>
    //     0x68e7d8: add             x8, PP, #0x29, lsl #12  ; [pp+0x29170] Type: MultiChildLayoutParentData<RenderBox>
    //     0x68e7dc: ldr             x8, [x8, #0x170]
    // 0x68e7e0: r3 = Null
    //     0x68e7e0: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2d748] Null
    //     0x68e7e4: ldr             x3, [x3, #0x748]
    // 0x68e7e8: r0 = DefaultTypeTest()
    //     0x68e7e8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x68e7ec: ldr             x0, [fp, #0x20]
    // 0x68e7f0: LoadField: r1 = r0->field_b
    //     0x68e7f0: ldur            w1, [x0, #0xb]
    // 0x68e7f4: DecompressPointer r1
    //     0x68e7f4: add             x1, x1, HEAP, lsl #32
    // 0x68e7f8: stur            x1, [fp, #-0x70]
    // 0x68e7fc: cmp             w1, NULL
    // 0x68e800: b.eq            #0x68e904
    // 0x68e804: ldur            x2, [fp, #-0x58]
    // 0x68e808: LoadField: r3 = r2->field_17
    //     0x68e808: ldur            w3, [x2, #0x17]
    // 0x68e80c: DecompressPointer r3
    //     0x68e80c: add             x3, x3, HEAP, lsl #32
    // 0x68e810: stur            x3, [fp, #-0x68]
    // 0x68e814: cmp             w3, NULL
    // 0x68e818: b.eq            #0x68e908
    // 0x68e81c: stp             x3, x1, [SP, #-0x10]!
    // 0x68e820: r0 = hash()
    //     0x68e820: bl              #0xc0483c  ; [package:collection/src/equality.dart] DefaultEquality::hash
    // 0x68e824: add             SP, SP, #0x10
    // 0x68e828: stur            x0, [fp, #-0x78]
    // 0x68e82c: ldur            x16, [fp, #-0x70]
    // 0x68e830: ldur            lr, [fp, #-0x68]
    // 0x68e834: stp             lr, x16, [SP, #-0x10]!
    // 0x68e838: ldur            x16, [fp, #-0x60]
    // 0x68e83c: stp             x0, x16, [SP, #-0x10]!
    // 0x68e840: r0 = _set()
    //     0x68e840: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x68e844: add             SP, SP, #0x20
    // 0x68e848: ldur            x0, [fp, #-0x58]
    // 0x68e84c: LoadField: r4 = r0->field_13
    //     0x68e84c: ldur            w4, [x0, #0x13]
    // 0x68e850: DecompressPointer r4
    //     0x68e850: add             x4, x4, HEAP, lsl #32
    // 0x68e854: ldr             x3, [fp, #0x20]
    // 0x68e858: b               #0x68e790
    // 0x68e85c: mov             x1, x3
    // 0x68e860: r0 = LoadClassIdInstr(r1)
    //     0x68e860: ldur            x0, [x1, #-1]
    //     0x68e864: ubfx            x0, x0, #0xc, #0x14
    // 0x68e868: ldr             x16, [fp, #0x18]
    // 0x68e86c: stp             x16, x1, [SP, #-0x10]!
    // 0x68e870: r0 = GDT[cid_x0 + -0xf02]()
    //     0x68e870: sub             lr, x0, #0xf02
    //     0x68e874: ldr             lr, [x21, lr, lsl #3]
    //     0x68e878: blr             lr
    // 0x68e87c: add             SP, SP, #0x10
    // 0x68e880: ldr             x1, [fp, #0x20]
    // 0x68e884: ldur            x0, [fp, #-0x50]
    // 0x68e888: StoreField: r1->field_b = r0
    //     0x68e888: stur            w0, [x1, #0xb]
    //     0x68e88c: ldurb           w16, [x1, #-1]
    //     0x68e890: ldurb           w17, [x0, #-1]
    //     0x68e894: and             x16, x17, x16, lsr #2
    //     0x68e898: tst             x16, HEAP, lsr #32
    //     0x68e89c: b.eq            #0x68e8a4
    //     0x68e8a0: bl              #0xd6826c
    // 0x68e8a4: r0 = Null
    //     0x68e8a4: mov             x0, NULL
    // 0x68e8a8: LeaveFrame
    //     0x68e8a8: mov             SP, fp
    //     0x68e8ac: ldp             fp, lr, [SP], #0x10
    // 0x68e8b0: ret
    //     0x68e8b0: ret             
    // 0x68e8b4: sub             SP, fp, #0x78
    // 0x68e8b8: mov             x2, x0
    // 0x68e8bc: ldur            x0, [fp, #-0x30]
    // 0x68e8c0: ldr             x3, [fp, #0x20]
    // 0x68e8c4: StoreField: r3->field_b = r0
    //     0x68e8c4: stur            w0, [x3, #0xb]
    //     0x68e8c8: tbz             w0, #0, #0x68e8e4
    //     0x68e8cc: ldurb           w16, [x3, #-1]
    //     0x68e8d0: ldurb           w17, [x0, #-1]
    //     0x68e8d4: and             x16, x17, x16, lsr #2
    //     0x68e8d8: tst             x16, HEAP, lsr #32
    //     0x68e8dc: b.eq            #0x68e8e4
    //     0x68e8e0: bl              #0xd682ac
    // 0x68e8e4: mov             x0, x2
    // 0x68e8e8: r0 = ReThrow()
    //     0x68e8e8: bl              #0xd67e14  ; ReThrowStub
    // 0x68e8ec: brk             #0
    // 0x68e8f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68e8f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68e8f4: b               #0x68e73c
    // 0x68e8f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68e8f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68e8fc: b               #0x68e7a0
    // 0x68e900: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68e900: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68e904: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68e904: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68e908: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68e908: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ toString(/* No info */) {
    // ** addr: 0xade3c4, size: 0xc
    // 0xade3c4: r0 = "MultiChildLayoutDelegate"
    //     0xade3c4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28608] "MultiChildLayoutDelegate"
    //     0xade3c8: ldr             x0, [x0, #0x608]
    // 0xade3cc: ret
    //     0xade3cc: ret             
  }
  _ positionChild(/* No info */) {
    // ** addr: 0xcf4058, size: 0xf8
    // 0xcf4058: EnterFrame
    //     0xcf4058: stp             fp, lr, [SP, #-0x10]!
    //     0xcf405c: mov             fp, SP
    // 0xcf4060: AllocStack(0x8)
    //     0xcf4060: sub             SP, SP, #8
    // 0xcf4064: CheckStackOverflow
    //     0xcf4064: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf4068: cmp             SP, x16
    //     0xcf406c: b.ls            #0xcf413c
    // 0xcf4070: ldr             x0, [fp, #0x20]
    // 0xcf4074: LoadField: r1 = r0->field_b
    //     0xcf4074: ldur            w1, [x0, #0xb]
    // 0xcf4078: DecompressPointer r1
    //     0xcf4078: add             x1, x1, HEAP, lsl #32
    // 0xcf407c: stur            x1, [fp, #-8]
    // 0xcf4080: cmp             w1, NULL
    // 0xcf4084: b.eq            #0xcf4144
    // 0xcf4088: ldr             x16, [fp, #0x18]
    // 0xcf408c: stp             x16, x1, [SP, #-0x10]!
    // 0xcf4090: r0 = _getValueOrData()
    //     0xcf4090: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xcf4094: add             SP, SP, #0x10
    // 0xcf4098: mov             x1, x0
    // 0xcf409c: ldur            x0, [fp, #-8]
    // 0xcf40a0: LoadField: r2 = r0->field_f
    //     0xcf40a0: ldur            w2, [x0, #0xf]
    // 0xcf40a4: DecompressPointer r2
    //     0xcf40a4: add             x2, x2, HEAP, lsl #32
    // 0xcf40a8: cmp             w2, w1
    // 0xcf40ac: b.ne            #0xcf40b8
    // 0xcf40b0: r0 = Null
    //     0xcf40b0: mov             x0, NULL
    // 0xcf40b4: b               #0xcf40bc
    // 0xcf40b8: mov             x0, x1
    // 0xcf40bc: cmp             w0, NULL
    // 0xcf40c0: b.eq            #0xcf4148
    // 0xcf40c4: LoadField: r3 = r0->field_17
    //     0xcf40c4: ldur            w3, [x0, #0x17]
    // 0xcf40c8: DecompressPointer r3
    //     0xcf40c8: add             x3, x3, HEAP, lsl #32
    // 0xcf40cc: stur            x3, [fp, #-8]
    // 0xcf40d0: cmp             w3, NULL
    // 0xcf40d4: b.eq            #0xcf414c
    // 0xcf40d8: mov             x0, x3
    // 0xcf40dc: r2 = Null
    //     0xcf40dc: mov             x2, NULL
    // 0xcf40e0: r1 = Null
    //     0xcf40e0: mov             x1, NULL
    // 0xcf40e4: r4 = LoadClassIdInstr(r0)
    //     0xcf40e4: ldur            x4, [x0, #-1]
    //     0xcf40e8: ubfx            x4, x4, #0xc, #0x14
    // 0xcf40ec: cmp             x4, #0x80a
    // 0xcf40f0: b.eq            #0xcf4108
    // 0xcf40f4: r8 = MultiChildLayoutParentData<RenderBox>
    //     0xcf40f4: add             x8, PP, #0x29, lsl #12  ; [pp+0x29170] Type: MultiChildLayoutParentData<RenderBox>
    //     0xcf40f8: ldr             x8, [x8, #0x170]
    // 0xcf40fc: r3 = Null
    //     0xcf40fc: add             x3, PP, #0x37, lsl #12  ; [pp+0x37780] Null
    //     0xcf4100: ldr             x3, [x3, #0x780]
    // 0xcf4104: r0 = DefaultTypeTest()
    //     0xcf4104: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xcf4108: ldr             x0, [fp, #0x10]
    // 0xcf410c: ldur            x1, [fp, #-8]
    // 0xcf4110: StoreField: r1->field_7 = r0
    //     0xcf4110: stur            w0, [x1, #7]
    //     0xcf4114: ldurb           w16, [x1, #-1]
    //     0xcf4118: ldurb           w17, [x0, #-1]
    //     0xcf411c: and             x16, x17, x16, lsr #2
    //     0xcf4120: tst             x16, HEAP, lsr #32
    //     0xcf4124: b.eq            #0xcf412c
    //     0xcf4128: bl              #0xd6826c
    // 0xcf412c: r0 = Null
    //     0xcf412c: mov             x0, NULL
    // 0xcf4130: LeaveFrame
    //     0xcf4130: mov             SP, fp
    //     0xcf4134: ldp             fp, lr, [SP], #0x10
    // 0xcf4138: ret
    //     0xcf4138: ret             
    // 0xcf413c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf413c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf4140: b               #0xcf4070
    // 0xcf4144: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcf4144: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcf4148: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcf4148: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcf414c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcf414c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ layoutChild(/* No info */) {
    // ** addr: 0xcf4150, size: 0xd0
    // 0xcf4150: EnterFrame
    //     0xcf4150: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4154: mov             fp, SP
    // 0xcf4158: AllocStack(0x8)
    //     0xcf4158: sub             SP, SP, #8
    // 0xcf415c: CheckStackOverflow
    //     0xcf415c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf4160: cmp             SP, x16
    //     0xcf4164: b.ls            #0xcf420c
    // 0xcf4168: ldr             x0, [fp, #0x20]
    // 0xcf416c: LoadField: r1 = r0->field_b
    //     0xcf416c: ldur            w1, [x0, #0xb]
    // 0xcf4170: DecompressPointer r1
    //     0xcf4170: add             x1, x1, HEAP, lsl #32
    // 0xcf4174: stur            x1, [fp, #-8]
    // 0xcf4178: cmp             w1, NULL
    // 0xcf417c: b.eq            #0xcf4214
    // 0xcf4180: ldr             x16, [fp, #0x18]
    // 0xcf4184: stp             x16, x1, [SP, #-0x10]!
    // 0xcf4188: r0 = _getValueOrData()
    //     0xcf4188: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xcf418c: add             SP, SP, #0x10
    // 0xcf4190: mov             x1, x0
    // 0xcf4194: ldur            x0, [fp, #-8]
    // 0xcf4198: LoadField: r2 = r0->field_f
    //     0xcf4198: ldur            w2, [x0, #0xf]
    // 0xcf419c: DecompressPointer r2
    //     0xcf419c: add             x2, x2, HEAP, lsl #32
    // 0xcf41a0: cmp             w2, w1
    // 0xcf41a4: b.ne            #0xcf41ac
    // 0xcf41a8: r1 = Null
    //     0xcf41a8: mov             x1, NULL
    // 0xcf41ac: stur            x1, [fp, #-8]
    // 0xcf41b0: cmp             w1, NULL
    // 0xcf41b4: b.eq            #0xcf4218
    // 0xcf41b8: r0 = LoadClassIdInstr(r1)
    //     0xcf41b8: ldur            x0, [x1, #-1]
    //     0xcf41bc: ubfx            x0, x0, #0xc, #0x14
    // 0xcf41c0: ldr             x16, [fp, #0x10]
    // 0xcf41c4: stp             x16, x1, [SP, #-0x10]!
    // 0xcf41c8: r16 = true
    //     0xcf41c8: add             x16, NULL, #0x20  ; true
    // 0xcf41cc: SaveReg r16
    //     0xcf41cc: str             x16, [SP, #-8]!
    // 0xcf41d0: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0xcf41d0: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0xcf41d4: ldr             x4, [x4, #0x1c8]
    // 0xcf41d8: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0xcf41d8: mov             x17, #0xcdfb
    //     0xcf41dc: add             lr, x0, x17
    //     0xcf41e0: ldr             lr, [x21, lr, lsl #3]
    //     0xcf41e4: blr             lr
    // 0xcf41e8: add             SP, SP, #0x18
    // 0xcf41ec: ldur            x1, [fp, #-8]
    // 0xcf41f0: LoadField: r0 = r1->field_57
    //     0xcf41f0: ldur            w0, [x1, #0x57]
    // 0xcf41f4: DecompressPointer r0
    //     0xcf41f4: add             x0, x0, HEAP, lsl #32
    // 0xcf41f8: cmp             w0, NULL
    // 0xcf41fc: b.eq            #0xcf421c
    // 0xcf4200: LeaveFrame
    //     0xcf4200: mov             SP, fp
    //     0xcf4204: ldp             fp, lr, [SP], #0x10
    // 0xcf4208: ret
    //     0xcf4208: ret             
    // 0xcf420c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf420c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf4210: b               #0xcf4168
    // 0xcf4214: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcf4214: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcf4218: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcf4218: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcf421c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcf421c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ hasChild(/* No info */) {
    // ** addr: 0xcf4220, size: 0x88
    // 0xcf4220: EnterFrame
    //     0xcf4220: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4224: mov             fp, SP
    // 0xcf4228: AllocStack(0x8)
    //     0xcf4228: sub             SP, SP, #8
    // 0xcf422c: CheckStackOverflow
    //     0xcf422c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf4230: cmp             SP, x16
    //     0xcf4234: b.ls            #0xcf429c
    // 0xcf4238: ldr             x0, [fp, #0x18]
    // 0xcf423c: LoadField: r1 = r0->field_b
    //     0xcf423c: ldur            w1, [x0, #0xb]
    // 0xcf4240: DecompressPointer r1
    //     0xcf4240: add             x1, x1, HEAP, lsl #32
    // 0xcf4244: stur            x1, [fp, #-8]
    // 0xcf4248: cmp             w1, NULL
    // 0xcf424c: b.eq            #0xcf42a4
    // 0xcf4250: ldr             x16, [fp, #0x10]
    // 0xcf4254: stp             x16, x1, [SP, #-0x10]!
    // 0xcf4258: r0 = _getValueOrData()
    //     0xcf4258: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xcf425c: add             SP, SP, #0x10
    // 0xcf4260: ldur            x1, [fp, #-8]
    // 0xcf4264: LoadField: r2 = r1->field_f
    //     0xcf4264: ldur            w2, [x1, #0xf]
    // 0xcf4268: DecompressPointer r2
    //     0xcf4268: add             x2, x2, HEAP, lsl #32
    // 0xcf426c: cmp             w2, w0
    // 0xcf4270: b.ne            #0xcf427c
    // 0xcf4274: r1 = Null
    //     0xcf4274: mov             x1, NULL
    // 0xcf4278: b               #0xcf4280
    // 0xcf427c: mov             x1, x0
    // 0xcf4280: cmp             w1, NULL
    // 0xcf4284: r16 = true
    //     0xcf4284: add             x16, NULL, #0x20  ; true
    // 0xcf4288: r17 = false
    //     0xcf4288: add             x17, NULL, #0x30  ; false
    // 0xcf428c: csel            x0, x16, x17, ne
    // 0xcf4290: LeaveFrame
    //     0xcf4290: mov             SP, fp
    //     0xcf4294: ldp             fp, lr, [SP], #0x10
    // 0xcf4298: ret
    //     0xcf4298: ret             
    // 0xcf429c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf429c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf42a0: b               #0xcf4238
    // 0xcf42a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcf42a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2529, size: 0x74, field offset: 0x70
class RenderCustomMultiChildLayoutBox extends __RenderCupertinoDialogActions&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin {

  _ hitTestChildren(/* No info */) {
    // ** addr: 0x625184, size: 0x44
    // 0x625184: EnterFrame
    //     0x625184: stp             fp, lr, [SP, #-0x10]!
    //     0x625188: mov             fp, SP
    // 0x62518c: CheckStackOverflow
    //     0x62518c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x625190: cmp             SP, x16
    //     0x625194: b.ls            #0x6251c0
    // 0x625198: ldr             x16, [fp, #0x20]
    // 0x62519c: ldr             lr, [fp, #0x18]
    // 0x6251a0: stp             lr, x16, [SP, #-0x10]!
    // 0x6251a4: ldr             x16, [fp, #0x10]
    // 0x6251a8: SaveReg r16
    //     0x6251a8: str             x16, [SP, #-8]!
    // 0x6251ac: r0 = defaultHitTestChildren()
    //     0x6251ac: bl              #0x6251c8  ; [package:flutter/src/cupertino/dialog.dart] __RenderCupertinoDialogActions&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultHitTestChildren
    // 0x6251b0: add             SP, SP, #0x18
    // 0x6251b4: LeaveFrame
    //     0x6251b4: mov             SP, fp
    //     0x6251b8: ldp             fp, lr, [SP], #0x10
    // 0x6251bc: ret
    //     0x6251bc: ret             
    // 0x6251c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6251c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6251c4: b               #0x625198
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x62e250, size: 0x18
    // 0x62e250: r4 = 0
    //     0x62e250: mov             x4, #0
    // 0x62e254: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x62e254: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b390] AnonymousClosure: (0x62e268), in [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::computeMinIntrinsicHeight (0x62e2b4)
    //     0x62e258: ldr             x1, [x17, #0x390]
    // 0x62e25c: r24 = BuildNonGenericMethodExtractorStub
    //     0x62e25c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x62e260: LoadField: r0 = r24->field_17
    //     0x62e260: ldur            x0, [x24, #0x17]
    // 0x62e264: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x62e268, size: 0x4c
    // 0x62e268: EnterFrame
    //     0x62e268: stp             fp, lr, [SP, #-0x10]!
    //     0x62e26c: mov             fp, SP
    // 0x62e270: ldr             x0, [fp, #0x18]
    // 0x62e274: LoadField: r1 = r0->field_17
    //     0x62e274: ldur            w1, [x0, #0x17]
    // 0x62e278: DecompressPointer r1
    //     0x62e278: add             x1, x1, HEAP, lsl #32
    // 0x62e27c: CheckStackOverflow
    //     0x62e27c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62e280: cmp             SP, x16
    //     0x62e284: b.ls            #0x62e2ac
    // 0x62e288: LoadField: r0 = r1->field_f
    //     0x62e288: ldur            w0, [x1, #0xf]
    // 0x62e28c: DecompressPointer r0
    //     0x62e28c: add             x0, x0, HEAP, lsl #32
    // 0x62e290: ldr             x16, [fp, #0x10]
    // 0x62e294: stp             x16, x0, [SP, #-0x10]!
    // 0x62e298: r0 = computeMinIntrinsicHeight()
    //     0x62e298: bl              #0x62e2b4  ; [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::computeMinIntrinsicHeight
    // 0x62e29c: add             SP, SP, #0x10
    // 0x62e2a0: LeaveFrame
    //     0x62e2a0: mov             SP, fp
    //     0x62e2a4: ldp             fp, lr, [SP], #0x10
    // 0x62e2a8: ret
    //     0x62e2a8: ret             
    // 0x62e2ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62e2ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62e2b0: b               #0x62e288
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0x62e2b4, size: 0x128
    // 0x62e2b4: EnterFrame
    //     0x62e2b4: stp             fp, lr, [SP, #-0x10]!
    //     0x62e2b8: mov             fp, SP
    // 0x62e2bc: AllocStack(0x18)
    //     0x62e2bc: sub             SP, SP, #0x18
    // 0x62e2c0: d0 = inf
    //     0x62e2c0: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62e2c4: CheckStackOverflow
    //     0x62e2c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62e2c8: cmp             SP, x16
    //     0x62e2cc: b.ls            #0x62e3c4
    // 0x62e2d0: ldr             x0, [fp, #0x10]
    // 0x62e2d4: LoadField: d1 = r0->field_7
    //     0x62e2d4: ldur            d1, [x0, #7]
    // 0x62e2d8: stur            d1, [fp, #-0x18]
    // 0x62e2dc: fcmp            d1, d0
    // 0x62e2e0: b.vs            #0x62e2e8
    // 0x62e2e4: b.eq            #0x62e2f0
    // 0x62e2e8: r0 = false
    //     0x62e2e8: add             x0, NULL, #0x30  ; false
    // 0x62e2ec: b               #0x62e2f4
    // 0x62e2f0: r0 = true
    //     0x62e2f0: add             x0, NULL, #0x20  ; true
    // 0x62e2f4: stur            x0, [fp, #-8]
    // 0x62e2f8: tbz             w0, #4, #0x62e304
    // 0x62e2fc: mov             v2.16b, v1.16b
    // 0x62e300: b               #0x62e308
    // 0x62e304: d2 = 0.000000
    //     0x62e304: eor             v2.16b, v2.16b, v2.16b
    // 0x62e308: stur            d2, [fp, #-0x10]
    // 0x62e30c: r0 = BoxConstraints()
    //     0x62e30c: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x62e310: ldur            d0, [fp, #-0x10]
    // 0x62e314: StoreField: r0->field_7 = d0
    //     0x62e314: stur            d0, [x0, #7]
    // 0x62e318: ldur            x1, [fp, #-8]
    // 0x62e31c: tbz             w1, #4, #0x62e328
    // 0x62e320: ldur            d1, [fp, #-0x18]
    // 0x62e324: b               #0x62e32c
    // 0x62e328: d1 = inf
    //     0x62e328: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62e32c: d0 = inf
    //     0x62e32c: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62e330: StoreField: r0->field_f = d1
    //     0x62e330: stur            d1, [x0, #0xf]
    // 0x62e334: fcmp            d0, d0
    // 0x62e338: b.eq            #0x62e344
    // 0x62e33c: d1 = inf
    //     0x62e33c: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62e340: b               #0x62e348
    // 0x62e344: d1 = 0.000000
    //     0x62e344: eor             v1.16b, v1.16b, v1.16b
    // 0x62e348: StoreField: r0->field_17 = d1
    //     0x62e348: stur            d1, [x0, #0x17]
    // 0x62e34c: StoreField: r0->field_1f = d0
    //     0x62e34c: stur            d0, [x0, #0x1f]
    // 0x62e350: ldr             x16, [fp, #0x18]
    // 0x62e354: stp             x0, x16, [SP, #-0x10]!
    // 0x62e358: r0 = _getSize()
    //     0x62e358: bl              #0x62e428  ; [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::_getSize
    // 0x62e35c: add             SP, SP, #0x10
    // 0x62e360: LoadField: d0 = r0->field_f
    //     0x62e360: ldur            d0, [x0, #0xf]
    // 0x62e364: mov             x1, v0.d[0]
    // 0x62e368: and             x1, x1, #0x7fffffffffffffff
    // 0x62e36c: r17 = 9218868437227405312
    //     0x62e36c: mov             x17, #0x7ff0000000000000
    // 0x62e370: cmp             x1, x17
    // 0x62e374: b.eq            #0x62e3b4
    // 0x62e378: fcmp            d0, d0
    // 0x62e37c: b.vs            #0x62e3b4
    // 0x62e380: r0 = inline_Allocate_Double()
    //     0x62e380: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62e384: add             x0, x0, #0x10
    //     0x62e388: cmp             x1, x0
    //     0x62e38c: b.ls            #0x62e3cc
    //     0x62e390: str             x0, [THR, #0x60]  ; THR::top
    //     0x62e394: sub             x0, x0, #0xf
    //     0x62e398: mov             x1, #0xd108
    //     0x62e39c: movk            x1, #3, lsl #16
    //     0x62e3a0: stur            x1, [x0, #-1]
    // 0x62e3a4: StoreField: r0->field_7 = d0
    //     0x62e3a4: stur            d0, [x0, #7]
    // 0x62e3a8: LeaveFrame
    //     0x62e3a8: mov             SP, fp
    //     0x62e3ac: ldp             fp, lr, [SP], #0x10
    // 0x62e3b0: ret
    //     0x62e3b0: ret             
    // 0x62e3b4: r0 = 0.000000
    //     0x62e3b4: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x62e3b8: LeaveFrame
    //     0x62e3b8: mov             SP, fp
    //     0x62e3bc: ldp             fp, lr, [SP], #0x10
    // 0x62e3c0: ret
    //     0x62e3c0: ret             
    // 0x62e3c4: r0 = StackOverflowSharedWithFPURegs()
    //     0x62e3c4: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x62e3c8: b               #0x62e2d0
    // 0x62e3cc: SaveReg d0
    //     0x62e3cc: str             q0, [SP, #-0x10]!
    // 0x62e3d0: r0 = AllocateDouble()
    //     0x62e3d0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62e3d4: RestoreReg d0
    //     0x62e3d4: ldr             q0, [SP], #0x10
    // 0x62e3d8: b               #0x62e3a4
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x62e3dc, size: 0x4c
    // 0x62e3dc: EnterFrame
    //     0x62e3dc: stp             fp, lr, [SP, #-0x10]!
    //     0x62e3e0: mov             fp, SP
    // 0x62e3e4: ldr             x0, [fp, #0x18]
    // 0x62e3e8: LoadField: r1 = r0->field_17
    //     0x62e3e8: ldur            w1, [x0, #0x17]
    // 0x62e3ec: DecompressPointer r1
    //     0x62e3ec: add             x1, x1, HEAP, lsl #32
    // 0x62e3f0: CheckStackOverflow
    //     0x62e3f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62e3f4: cmp             SP, x16
    //     0x62e3f8: b.ls            #0x62e420
    // 0x62e3fc: LoadField: r0 = r1->field_f
    //     0x62e3fc: ldur            w0, [x1, #0xf]
    // 0x62e400: DecompressPointer r0
    //     0x62e400: add             x0, x0, HEAP, lsl #32
    // 0x62e404: ldr             x16, [fp, #0x10]
    // 0x62e408: stp             x16, x0, [SP, #-0x10]!
    // 0x62e40c: r0 = computeMinIntrinsicHeight()
    //     0x62e40c: bl              #0x62e2b4  ; [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::computeMinIntrinsicHeight
    // 0x62e410: add             SP, SP, #0x10
    // 0x62e414: LeaveFrame
    //     0x62e414: mov             SP, fp
    //     0x62e418: ldp             fp, lr, [SP], #0x10
    // 0x62e41c: ret
    //     0x62e41c: ret             
    // 0x62e420: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62e420: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62e424: b               #0x62e3fc
  }
  _ _getSize(/* No info */) {
    // ** addr: 0x62e428, size: 0x80
    // 0x62e428: EnterFrame
    //     0x62e428: stp             fp, lr, [SP, #-0x10]!
    //     0x62e42c: mov             fp, SP
    // 0x62e430: AllocStack(0x10)
    //     0x62e430: sub             SP, SP, #0x10
    // 0x62e434: CheckStackOverflow
    //     0x62e434: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62e438: cmp             SP, x16
    //     0x62e43c: b.ls            #0x62e4a0
    // 0x62e440: ldr             x16, [fp, #0x10]
    // 0x62e444: SaveReg r16
    //     0x62e444: str             x16, [SP, #-8]!
    // 0x62e448: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x62e448: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x62e44c: r0 = constrainWidth()
    //     0x62e44c: bl              #0x62bc8c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0x62e450: add             SP, SP, #8
    // 0x62e454: stur            d0, [fp, #-8]
    // 0x62e458: ldr             x16, [fp, #0x10]
    // 0x62e45c: SaveReg r16
    //     0x62e45c: str             x16, [SP, #-8]!
    // 0x62e460: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x62e460: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x62e464: r0 = constrainHeight()
    //     0x62e464: bl              #0x62bc00  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0x62e468: add             SP, SP, #8
    // 0x62e46c: stur            d0, [fp, #-0x10]
    // 0x62e470: r0 = Size()
    //     0x62e470: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x62e474: ldur            d0, [fp, #-8]
    // 0x62e478: StoreField: r0->field_7 = d0
    //     0x62e478: stur            d0, [x0, #7]
    // 0x62e47c: ldur            d0, [fp, #-0x10]
    // 0x62e480: StoreField: r0->field_f = d0
    //     0x62e480: stur            d0, [x0, #0xf]
    // 0x62e484: ldr             x16, [fp, #0x10]
    // 0x62e488: stp             x0, x16, [SP, #-0x10]!
    // 0x62e48c: r0 = constrain()
    //     0x62e48c: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x62e490: add             SP, SP, #0x10
    // 0x62e494: LeaveFrame
    //     0x62e494: mov             SP, fp
    //     0x62e498: ldp             fp, lr, [SP], #0x10
    // 0x62e49c: ret
    //     0x62e49c: ret             
    // 0x62e4a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62e4a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62e4a4: b               #0x62e440
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x6351d8, size: 0x18
    // 0x6351d8: r4 = 0
    //     0x6351d8: mov             x4, #0
    // 0x6351dc: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x6351dc: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fd48] AnonymousClosure: (0x6351f0), in [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::computeMinIntrinsicWidth (0x63523c)
    //     0x6351e0: ldr             x1, [x17, #0xd48]
    // 0x6351e4: r24 = BuildNonGenericMethodExtractorStub
    //     0x6351e4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x6351e8: LoadField: r0 = r24->field_17
    //     0x6351e8: ldur            x0, [x24, #0x17]
    // 0x6351ec: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x6351f0, size: 0x4c
    // 0x6351f0: EnterFrame
    //     0x6351f0: stp             fp, lr, [SP, #-0x10]!
    //     0x6351f4: mov             fp, SP
    // 0x6351f8: ldr             x0, [fp, #0x18]
    // 0x6351fc: LoadField: r1 = r0->field_17
    //     0x6351fc: ldur            w1, [x0, #0x17]
    // 0x635200: DecompressPointer r1
    //     0x635200: add             x1, x1, HEAP, lsl #32
    // 0x635204: CheckStackOverflow
    //     0x635204: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x635208: cmp             SP, x16
    //     0x63520c: b.ls            #0x635234
    // 0x635210: LoadField: r0 = r1->field_f
    //     0x635210: ldur            w0, [x1, #0xf]
    // 0x635214: DecompressPointer r0
    //     0x635214: add             x0, x0, HEAP, lsl #32
    // 0x635218: ldr             x16, [fp, #0x10]
    // 0x63521c: stp             x16, x0, [SP, #-0x10]!
    // 0x635220: r0 = computeMinIntrinsicWidth()
    //     0x635220: bl              #0x63523c  ; [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::computeMinIntrinsicWidth
    // 0x635224: add             SP, SP, #0x10
    // 0x635228: LeaveFrame
    //     0x635228: mov             SP, fp
    //     0x63522c: ldp             fp, lr, [SP], #0x10
    // 0x635230: ret
    //     0x635230: ret             
    // 0x635234: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x635234: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x635238: b               #0x635210
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0x63523c, size: 0x120
    // 0x63523c: EnterFrame
    //     0x63523c: stp             fp, lr, [SP, #-0x10]!
    //     0x635240: mov             fp, SP
    // 0x635244: AllocStack(0x8)
    //     0x635244: sub             SP, SP, #8
    // 0x635248: d0 = inf
    //     0x635248: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x63524c: CheckStackOverflow
    //     0x63524c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x635250: cmp             SP, x16
    //     0x635254: b.ls            #0x635344
    // 0x635258: fcmp            d0, d0
    // 0x63525c: b.eq            #0x635268
    // 0x635260: d1 = inf
    //     0x635260: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x635264: b               #0x63526c
    // 0x635268: d1 = 0.000000
    //     0x635268: eor             v1.16b, v1.16b, v1.16b
    // 0x63526c: ldr             x0, [fp, #0x10]
    // 0x635270: stur            d1, [fp, #-8]
    // 0x635274: r0 = BoxConstraints()
    //     0x635274: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x635278: ldur            d0, [fp, #-8]
    // 0x63527c: StoreField: r0->field_7 = d0
    //     0x63527c: stur            d0, [x0, #7]
    // 0x635280: d0 = inf
    //     0x635280: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x635284: StoreField: r0->field_f = d0
    //     0x635284: stur            d0, [x0, #0xf]
    // 0x635288: ldr             x1, [fp, #0x10]
    // 0x63528c: LoadField: d1 = r1->field_7
    //     0x63528c: ldur            d1, [x1, #7]
    // 0x635290: fcmp            d1, d0
    // 0x635294: b.vs            #0x63529c
    // 0x635298: b.eq            #0x6352a4
    // 0x63529c: r1 = false
    //     0x63529c: add             x1, NULL, #0x30  ; false
    // 0x6352a0: b               #0x6352a8
    // 0x6352a4: r1 = true
    //     0x6352a4: add             x1, NULL, #0x20  ; true
    // 0x6352a8: tbz             w1, #4, #0x6352b4
    // 0x6352ac: mov             v0.16b, v1.16b
    // 0x6352b0: b               #0x6352b8
    // 0x6352b4: d0 = 0.000000
    //     0x6352b4: eor             v0.16b, v0.16b, v0.16b
    // 0x6352b8: StoreField: r0->field_17 = d0
    //     0x6352b8: stur            d0, [x0, #0x17]
    // 0x6352bc: tbz             w1, #4, #0x6352c8
    // 0x6352c0: mov             v0.16b, v1.16b
    // 0x6352c4: b               #0x6352cc
    // 0x6352c8: d0 = inf
    //     0x6352c8: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x6352cc: StoreField: r0->field_1f = d0
    //     0x6352cc: stur            d0, [x0, #0x1f]
    // 0x6352d0: ldr             x16, [fp, #0x18]
    // 0x6352d4: stp             x0, x16, [SP, #-0x10]!
    // 0x6352d8: r0 = _getSize()
    //     0x6352d8: bl              #0x62e428  ; [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::_getSize
    // 0x6352dc: add             SP, SP, #0x10
    // 0x6352e0: LoadField: d0 = r0->field_7
    //     0x6352e0: ldur            d0, [x0, #7]
    // 0x6352e4: mov             x1, v0.d[0]
    // 0x6352e8: and             x1, x1, #0x7fffffffffffffff
    // 0x6352ec: r17 = 9218868437227405312
    //     0x6352ec: mov             x17, #0x7ff0000000000000
    // 0x6352f0: cmp             x1, x17
    // 0x6352f4: b.eq            #0x635334
    // 0x6352f8: fcmp            d0, d0
    // 0x6352fc: b.vs            #0x635334
    // 0x635300: r0 = inline_Allocate_Double()
    //     0x635300: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x635304: add             x0, x0, #0x10
    //     0x635308: cmp             x1, x0
    //     0x63530c: b.ls            #0x63534c
    //     0x635310: str             x0, [THR, #0x60]  ; THR::top
    //     0x635314: sub             x0, x0, #0xf
    //     0x635318: mov             x1, #0xd108
    //     0x63531c: movk            x1, #3, lsl #16
    //     0x635320: stur            x1, [x0, #-1]
    // 0x635324: StoreField: r0->field_7 = d0
    //     0x635324: stur            d0, [x0, #7]
    // 0x635328: LeaveFrame
    //     0x635328: mov             SP, fp
    //     0x63532c: ldp             fp, lr, [SP], #0x10
    // 0x635330: ret
    //     0x635330: ret             
    // 0x635334: r0 = 0.000000
    //     0x635334: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x635338: LeaveFrame
    //     0x635338: mov             SP, fp
    //     0x63533c: ldp             fp, lr, [SP], #0x10
    // 0x635340: ret
    //     0x635340: ret             
    // 0x635344: r0 = StackOverflowSharedWithFPURegs()
    //     0x635344: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x635348: b               #0x635258
    // 0x63534c: SaveReg d0
    //     0x63534c: str             q0, [SP, #-0x10]!
    // 0x635350: r0 = AllocateDouble()
    //     0x635350: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x635354: RestoreReg d0
    //     0x635354: ldr             q0, [SP], #0x10
    // 0x635358: b               #0x635324
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63535c, size: 0x4c
    // 0x63535c: EnterFrame
    //     0x63535c: stp             fp, lr, [SP, #-0x10]!
    //     0x635360: mov             fp, SP
    // 0x635364: ldr             x0, [fp, #0x18]
    // 0x635368: LoadField: r1 = r0->field_17
    //     0x635368: ldur            w1, [x0, #0x17]
    // 0x63536c: DecompressPointer r1
    //     0x63536c: add             x1, x1, HEAP, lsl #32
    // 0x635370: CheckStackOverflow
    //     0x635370: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x635374: cmp             SP, x16
    //     0x635378: b.ls            #0x6353a0
    // 0x63537c: LoadField: r0 = r1->field_f
    //     0x63537c: ldur            w0, [x1, #0xf]
    // 0x635380: DecompressPointer r0
    //     0x635380: add             x0, x0, HEAP, lsl #32
    // 0x635384: ldr             x16, [fp, #0x10]
    // 0x635388: stp             x16, x0, [SP, #-0x10]!
    // 0x63538c: r0 = computeMinIntrinsicWidth()
    //     0x63538c: bl              #0x63523c  ; [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::computeMinIntrinsicWidth
    // 0x635390: add             SP, SP, #0x10
    // 0x635394: LeaveFrame
    //     0x635394: mov             SP, fp
    //     0x635398: ldp             fp, lr, [SP], #0x10
    // 0x63539c: ret
    //     0x63539c: ret             
    // 0x6353a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6353a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6353a4: b               #0x63537c
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x638488, size: 0x18
    // 0x638488: r4 = 0
    //     0x638488: mov             x4, #0
    // 0x63848c: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x63848c: add             x17, PP, #0x52, lsl #12  ; [pp+0x52f48] AnonymousClosure: (0x62e3dc), in [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::computeMinIntrinsicHeight (0x62e2b4)
    //     0x638490: ldr             x1, [x17, #0xf48]
    // 0x638494: r24 = BuildNonGenericMethodExtractorStub
    //     0x638494: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x638498: LoadField: r0 = r24->field_17
    //     0x638498: ldur            x0, [x24, #0x17]
    // 0x63849c: br              x0
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63b1b4, size: 0x18
    // 0x63b1b4: r4 = 0
    //     0x63b1b4: mov             x4, #0
    // 0x63b1b8: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63b1b8: add             x17, PP, #0x50, lsl #12  ; [pp+0x50390] AnonymousClosure: (0x63535c), in [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::computeMinIntrinsicWidth (0x63523c)
    //     0x63b1bc: ldr             x1, [x17, #0x390]
    // 0x63b1c0: r24 = BuildNonGenericMethodExtractorStub
    //     0x63b1c0: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63b1c4: LoadField: r0 = r24->field_17
    //     0x63b1c4: ldur            x0, [x24, #0x17]
    // 0x63b1c8: br              x0
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0x64b8b4, size: 0x6c
    // 0x64b8b4: EnterFrame
    //     0x64b8b4: stp             fp, lr, [SP, #-0x10]!
    //     0x64b8b8: mov             fp, SP
    // 0x64b8bc: ldr             x0, [fp, #0x10]
    // 0x64b8c0: LoadField: r1 = r0->field_17
    //     0x64b8c0: ldur            w1, [x0, #0x17]
    // 0x64b8c4: DecompressPointer r1
    //     0x64b8c4: add             x1, x1, HEAP, lsl #32
    // 0x64b8c8: r2 = LoadClassIdInstr(r1)
    //     0x64b8c8: ldur            x2, [x1, #-1]
    //     0x64b8cc: ubfx            x2, x2, #0xc, #0x14
    // 0x64b8d0: lsl             x2, x2, #1
    // 0x64b8d4: r17 = 4116
    //     0x64b8d4: mov             x17, #0x1014
    // 0x64b8d8: cmp             w2, w17
    // 0x64b8dc: b.eq            #0x64b910
    // 0x64b8e0: r1 = <RenderBox>
    //     0x64b8e0: ldr             x1, [PP, #0x3b20]  ; [pp+0x3b20] TypeArguments: <RenderBox>
    // 0x64b8e4: r0 = MultiChildLayoutParentData()
    //     0x64b8e4: bl              #0x64b920  ; AllocateMultiChildLayoutParentDataStub -> MultiChildLayoutParentData (size=0x1c)
    // 0x64b8e8: r1 = Instance_Offset
    //     0x64b8e8: ldr             x1, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x64b8ec: StoreField: r0->field_7 = r1
    //     0x64b8ec: stur            w1, [x0, #7]
    // 0x64b8f0: ldr             x1, [fp, #0x10]
    // 0x64b8f4: StoreField: r1->field_17 = r0
    //     0x64b8f4: stur            w0, [x1, #0x17]
    //     0x64b8f8: ldurb           w16, [x1, #-1]
    //     0x64b8fc: ldurb           w17, [x0, #-1]
    //     0x64b900: and             x16, x17, x16, lsr #2
    //     0x64b904: tst             x16, HEAP, lsr #32
    //     0x64b908: b.eq            #0x64b910
    //     0x64b90c: bl              #0xd6826c
    // 0x64b910: r0 = Null
    //     0x64b910: mov             x0, NULL
    // 0x64b914: LeaveFrame
    //     0x64b914: mov             SP, fp
    //     0x64b918: ldp             fp, lr, [SP], #0x10
    // 0x64b91c: ret
    //     0x64b91c: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0x65eddc, size: 0x48
    // 0x65eddc: EnterFrame
    //     0x65eddc: stp             fp, lr, [SP, #-0x10]!
    //     0x65ede0: mov             fp, SP
    // 0x65ede4: CheckStackOverflow
    //     0x65ede4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65ede8: cmp             SP, x16
    //     0x65edec: b.ls            #0x65ee1c
    // 0x65edf0: ldr             x16, [fp, #0x20]
    // 0x65edf4: ldr             lr, [fp, #0x18]
    // 0x65edf8: stp             lr, x16, [SP, #-0x10]!
    // 0x65edfc: ldr             x16, [fp, #0x10]
    // 0x65ee00: SaveReg r16
    //     0x65ee00: str             x16, [SP, #-8]!
    // 0x65ee04: r0 = defaultPaint()
    //     0x65ee04: bl              #0x65ee24  ; [package:flutter/src/cupertino/dialog.dart] __RenderCupertinoDialogActions&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultPaint
    // 0x65ee08: add             SP, SP, #0x18
    // 0x65ee0c: r0 = Null
    //     0x65ee0c: mov             x0, NULL
    // 0x65ee10: LeaveFrame
    //     0x65ee10: mov             SP, fp
    //     0x65ee14: ldp             fp, lr, [SP], #0x10
    // 0x65ee18: ret
    //     0x65ee18: ret             
    // 0x65ee1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65ee1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65ee20: b               #0x65edf0
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x68e630, size: 0xf4
    // 0x68e630: EnterFrame
    //     0x68e630: stp             fp, lr, [SP, #-0x10]!
    //     0x68e634: mov             fp, SP
    // 0x68e638: AllocStack(0x8)
    //     0x68e638: sub             SP, SP, #8
    // 0x68e63c: CheckStackOverflow
    //     0x68e63c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68e640: cmp             SP, x16
    //     0x68e644: b.ls            #0x68e71c
    // 0x68e648: ldr             x3, [fp, #0x10]
    // 0x68e64c: LoadField: r4 = r3->field_27
    //     0x68e64c: ldur            w4, [x3, #0x27]
    // 0x68e650: DecompressPointer r4
    //     0x68e650: add             x4, x4, HEAP, lsl #32
    // 0x68e654: stur            x4, [fp, #-8]
    // 0x68e658: cmp             w4, NULL
    // 0x68e65c: b.eq            #0x68e6fc
    // 0x68e660: mov             x0, x4
    // 0x68e664: r2 = Null
    //     0x68e664: mov             x2, NULL
    // 0x68e668: r1 = Null
    //     0x68e668: mov             x1, NULL
    // 0x68e66c: r4 = LoadClassIdInstr(r0)
    //     0x68e66c: ldur            x4, [x0, #-1]
    //     0x68e670: ubfx            x4, x4, #0xc, #0x14
    // 0x68e674: sub             x4, x4, #0x80d
    // 0x68e678: cmp             x4, #1
    // 0x68e67c: b.ls            #0x68e694
    // 0x68e680: r8 = BoxConstraints
    //     0x68e680: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x68e684: ldr             x8, [x8, #0x1d0]
    // 0x68e688: r3 = Null
    //     0x68e688: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2d730] Null
    //     0x68e68c: ldr             x3, [x3, #0x730]
    // 0x68e690: r0 = BoxConstraints()
    //     0x68e690: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x68e694: ldr             x16, [fp, #0x10]
    // 0x68e698: ldur            lr, [fp, #-8]
    // 0x68e69c: stp             lr, x16, [SP, #-0x10]!
    // 0x68e6a0: r0 = _getSize()
    //     0x68e6a0: bl              #0x62e428  ; [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::_getSize
    // 0x68e6a4: add             SP, SP, #0x10
    // 0x68e6a8: mov             x2, x0
    // 0x68e6ac: ldr             x1, [fp, #0x10]
    // 0x68e6b0: StoreField: r1->field_57 = r0
    //     0x68e6b0: stur            w0, [x1, #0x57]
    //     0x68e6b4: ldurb           w16, [x1, #-1]
    //     0x68e6b8: ldurb           w17, [x0, #-1]
    //     0x68e6bc: and             x16, x17, x16, lsr #2
    //     0x68e6c0: tst             x16, HEAP, lsr #32
    //     0x68e6c4: b.eq            #0x68e6cc
    //     0x68e6c8: bl              #0xd6826c
    // 0x68e6cc: LoadField: r0 = r1->field_6f
    //     0x68e6cc: ldur            w0, [x1, #0x6f]
    // 0x68e6d0: DecompressPointer r0
    //     0x68e6d0: add             x0, x0, HEAP, lsl #32
    // 0x68e6d4: LoadField: r3 = r1->field_67
    //     0x68e6d4: ldur            w3, [x1, #0x67]
    // 0x68e6d8: DecompressPointer r3
    //     0x68e6d8: add             x3, x3, HEAP, lsl #32
    // 0x68e6dc: stp             x2, x0, [SP, #-0x10]!
    // 0x68e6e0: SaveReg r3
    //     0x68e6e0: str             x3, [SP, #-8]!
    // 0x68e6e4: r0 = _callPerformLayout()
    //     0x68e6e4: bl              #0x68e724  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::_callPerformLayout
    // 0x68e6e8: add             SP, SP, #0x18
    // 0x68e6ec: r0 = Null
    //     0x68e6ec: mov             x0, NULL
    // 0x68e6f0: LeaveFrame
    //     0x68e6f0: mov             SP, fp
    //     0x68e6f4: ldp             fp, lr, [SP], #0x10
    // 0x68e6f8: ret
    //     0x68e6f8: ret             
    // 0x68e6fc: r0 = StateError()
    //     0x68e6fc: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68e700: mov             x1, x0
    // 0x68e704: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68e704: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68e708: ldr             x0, [x0, #0x1e8]
    // 0x68e70c: StoreField: r1->field_b = r0
    //     0x68e70c: stur            w0, [x1, #0xb]
    // 0x68e710: mov             x0, x1
    // 0x68e714: r0 = Throw()
    //     0x68e714: bl              #0xd67e38  ; ThrowStub
    // 0x68e718: brk             #0
    // 0x68e71c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68e71c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68e720: b               #0x68e648
  }
  set _ delegate=(/* No info */) {
    // ** addr: 0x6e0420, size: 0x174
    // 0x6e0420: EnterFrame
    //     0x6e0420: stp             fp, lr, [SP, #-0x10]!
    //     0x6e0424: mov             fp, SP
    // 0x6e0428: AllocStack(0x8)
    //     0x6e0428: sub             SP, SP, #8
    // 0x6e042c: CheckStackOverflow
    //     0x6e042c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e0430: cmp             SP, x16
    //     0x6e0434: b.ls            #0x6e058c
    // 0x6e0438: ldr             x0, [fp, #0x18]
    // 0x6e043c: LoadField: r1 = r0->field_6f
    //     0x6e043c: ldur            w1, [x0, #0x6f]
    // 0x6e0440: DecompressPointer r1
    //     0x6e0440: add             x1, x1, HEAP, lsl #32
    // 0x6e0444: ldr             x2, [fp, #0x10]
    // 0x6e0448: stur            x1, [fp, #-8]
    // 0x6e044c: cmp             w1, w2
    // 0x6e0450: b.ne            #0x6e0464
    // 0x6e0454: r0 = Null
    //     0x6e0454: mov             x0, NULL
    // 0x6e0458: LeaveFrame
    //     0x6e0458: mov             SP, fp
    //     0x6e045c: ldp             fp, lr, [SP], #0x10
    // 0x6e0460: ret
    //     0x6e0460: ret             
    // 0x6e0464: stp             x1, x2, [SP, #-0x10]!
    // 0x6e0468: r0 = _haveSameRuntimeType()
    //     0x6e0468: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0x6e046c: add             SP, SP, #0x10
    // 0x6e0470: tbnz            w0, #4, #0x6e0548
    // 0x6e0474: ldr             x3, [fp, #0x10]
    // 0x6e0478: r0 = LoadClassIdInstr(r3)
    //     0x6e0478: ldur            x0, [x3, #-1]
    //     0x6e047c: ubfx            x0, x0, #0xc, #0x14
    // 0x6e0480: lsl             x0, x0, #1
    // 0x6e0484: r17 = 4302
    //     0x6e0484: mov             x17, #0x10ce
    // 0x6e0488: cmp             w0, w17
    // 0x6e048c: b.eq            #0x6e0558
    // 0x6e0490: r17 = 4304
    //     0x6e0490: mov             x17, #0x10d0
    // 0x6e0494: cmp             w0, w17
    // 0x6e0498: b.ne            #0x6e051c
    // 0x6e049c: ldur            x4, [fp, #-8]
    // 0x6e04a0: mov             x0, x4
    // 0x6e04a4: r2 = Null
    //     0x6e04a4: mov             x2, NULL
    // 0x6e04a8: r1 = Null
    //     0x6e04a8: mov             x1, NULL
    // 0x6e04ac: r4 = LoadClassIdInstr(r0)
    //     0x6e04ac: ldur            x4, [x0, #-1]
    //     0x6e04b0: ubfx            x4, x4, #0xc, #0x14
    // 0x6e04b4: cmp             x4, #0x868
    // 0x6e04b8: b.eq            #0x6e04d0
    // 0x6e04bc: r8 = _ToolbarLayout
    //     0x6e04bc: add             x8, PP, #0x29, lsl #12  ; [pp+0x29158] Type: _ToolbarLayout
    //     0x6e04c0: ldr             x8, [x8, #0x158]
    // 0x6e04c4: r3 = Null
    //     0x6e04c4: add             x3, PP, #0x29, lsl #12  ; [pp+0x29160] Null
    //     0x6e04c8: ldr             x3, [x3, #0x160]
    // 0x6e04cc: r0 = DefaultTypeTest()
    //     0x6e04cc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6e04d0: ldur            x0, [fp, #-8]
    // 0x6e04d4: LoadField: r1 = r0->field_f
    //     0x6e04d4: ldur            w1, [x0, #0xf]
    // 0x6e04d8: DecompressPointer r1
    //     0x6e04d8: add             x1, x1, HEAP, lsl #32
    // 0x6e04dc: ldr             x2, [fp, #0x10]
    // 0x6e04e0: LoadField: r3 = r2->field_f
    //     0x6e04e0: ldur            w3, [x2, #0xf]
    // 0x6e04e4: DecompressPointer r3
    //     0x6e04e4: add             x3, x3, HEAP, lsl #32
    // 0x6e04e8: cmp             w1, w3
    // 0x6e04ec: b.ne            #0x6e0548
    // 0x6e04f0: LoadField: d0 = r0->field_13
    //     0x6e04f0: ldur            d0, [x0, #0x13]
    // 0x6e04f4: LoadField: d1 = r2->field_13
    //     0x6e04f4: ldur            d1, [x2, #0x13]
    // 0x6e04f8: fcmp            d0, d1
    // 0x6e04fc: b.ne            #0x6e0548
    // 0x6e0500: LoadField: r1 = r0->field_1b
    //     0x6e0500: ldur            w1, [x0, #0x1b]
    // 0x6e0504: DecompressPointer r1
    //     0x6e0504: add             x1, x1, HEAP, lsl #32
    // 0x6e0508: LoadField: r0 = r2->field_1b
    //     0x6e0508: ldur            w0, [x2, #0x1b]
    // 0x6e050c: DecompressPointer r0
    //     0x6e050c: add             x0, x0, HEAP, lsl #32
    // 0x6e0510: cmp             w1, w0
    // 0x6e0514: b.eq            #0x6e0558
    // 0x6e0518: b               #0x6e0548
    // 0x6e051c: mov             x2, x3
    // 0x6e0520: ldur            x0, [fp, #-8]
    // 0x6e0524: r1 = LoadClassIdInstr(r2)
    //     0x6e0524: ldur            x1, [x2, #-1]
    //     0x6e0528: ubfx            x1, x1, #0xc, #0x14
    // 0x6e052c: stp             x0, x2, [SP, #-0x10]!
    // 0x6e0530: mov             x0, x1
    // 0x6e0534: r0 = GDT[cid_x0 + -0xef6]()
    //     0x6e0534: sub             lr, x0, #0xef6
    //     0x6e0538: ldr             lr, [x21, lr, lsl #3]
    //     0x6e053c: blr             lr
    // 0x6e0540: add             SP, SP, #0x10
    // 0x6e0544: tbnz            w0, #4, #0x6e0558
    // 0x6e0548: ldr             x16, [fp, #0x18]
    // 0x6e054c: SaveReg r16
    //     0x6e054c: str             x16, [SP, #-8]!
    // 0x6e0550: r0 = markNeedsLayout()
    //     0x6e0550: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6e0554: add             SP, SP, #8
    // 0x6e0558: ldr             x1, [fp, #0x18]
    // 0x6e055c: ldr             x0, [fp, #0x10]
    // 0x6e0560: StoreField: r1->field_6f = r0
    //     0x6e0560: stur            w0, [x1, #0x6f]
    //     0x6e0564: ldurb           w16, [x1, #-1]
    //     0x6e0568: ldurb           w17, [x0, #-1]
    //     0x6e056c: and             x16, x17, x16, lsr #2
    //     0x6e0570: tst             x16, HEAP, lsr #32
    //     0x6e0574: b.eq            #0x6e057c
    //     0x6e0578: bl              #0xd6826c
    // 0x6e057c: r0 = Null
    //     0x6e057c: mov             x0, NULL
    // 0x6e0580: LeaveFrame
    //     0x6e0580: mov             SP, fp
    //     0x6e0584: ldp             fp, lr, [SP], #0x10
    // 0x6e0588: ret
    //     0x6e0588: ret             
    // 0x6e058c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e058c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e0590: b               #0x6e0438
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bcfbc, size: 0x74
    // 0x9bcfbc: EnterFrame
    //     0x9bcfbc: stp             fp, lr, [SP, #-0x10]!
    //     0x9bcfc0: mov             fp, SP
    // 0x9bcfc4: CheckStackOverflow
    //     0x9bcfc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bcfc8: cmp             SP, x16
    //     0x9bcfcc: b.ls            #0x9bd028
    // 0x9bcfd0: ldr             x0, [fp, #0x10]
    // 0x9bcfd4: r2 = Null
    //     0x9bcfd4: mov             x2, NULL
    // 0x9bcfd8: r1 = Null
    //     0x9bcfd8: mov             x1, NULL
    // 0x9bcfdc: r4 = 59
    //     0x9bcfdc: mov             x4, #0x3b
    // 0x9bcfe0: branchIfSmi(r0, 0x9bcfec)
    //     0x9bcfe0: tbz             w0, #0, #0x9bcfec
    // 0x9bcfe4: r4 = LoadClassIdInstr(r0)
    //     0x9bcfe4: ldur            x4, [x0, #-1]
    //     0x9bcfe8: ubfx            x4, x4, #0xc, #0x14
    // 0x9bcfec: cmp             x4, #0x7e6
    // 0x9bcff0: b.eq            #0x9bd004
    // 0x9bcff4: r8 = PipelineOwner
    //     0x9bcff4: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9bcff8: r3 = Null
    //     0x9bcff8: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2d758] Null
    //     0x9bcffc: ldr             x3, [x3, #0x758]
    // 0x9bd000: r0 = DefaultTypeTest()
    //     0x9bd000: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bd004: ldr             x16, [fp, #0x18]
    // 0x9bd008: ldr             lr, [fp, #0x10]
    // 0x9bd00c: stp             lr, x16, [SP, #-0x10]!
    // 0x9bd010: r0 = attach()
    //     0x9bd010: bl              #0x9bd030  ; [package:flutter/src/cupertino/dialog.dart] __RenderCupertinoDialogActions&RenderBox&ContainerRenderObjectMixin::attach
    // 0x9bd014: add             SP, SP, #0x10
    // 0x9bd018: r0 = Null
    //     0x9bd018: mov             x0, NULL
    // 0x9bd01c: LeaveFrame
    //     0x9bd01c: mov             SP, fp
    //     0x9bd020: ldp             fp, lr, [SP], #0x10
    // 0x9bd024: ret
    //     0x9bd024: ret             
    // 0x9bd028: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bd028: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bd02c: b               #0x9bcfd0
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5d608, size: 0x3c
    // 0xa5d608: EnterFrame
    //     0xa5d608: stp             fp, lr, [SP, #-0x10]!
    //     0xa5d60c: mov             fp, SP
    // 0xa5d610: CheckStackOverflow
    //     0xa5d610: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5d614: cmp             SP, x16
    //     0xa5d618: b.ls            #0xa5d63c
    // 0xa5d61c: ldr             x16, [fp, #0x18]
    // 0xa5d620: ldr             lr, [fp, #0x10]
    // 0xa5d624: stp             lr, x16, [SP, #-0x10]!
    // 0xa5d628: r0 = _getSize()
    //     0xa5d628: bl              #0x62e428  ; [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::_getSize
    // 0xa5d62c: add             SP, SP, #0x10
    // 0xa5d630: LeaveFrame
    //     0xa5d630: mov             SP, fp
    //     0xa5d634: ldp             fp, lr, [SP], #0x10
    // 0xa5d638: ret
    //     0xa5d638: ret             
    // 0xa5d63c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5d63c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5d640: b               #0xa5d61c
  }
  _ detach(/* No info */) {
    // ** addr: 0xa68de8, size: 0x3c
    // 0xa68de8: EnterFrame
    //     0xa68de8: stp             fp, lr, [SP, #-0x10]!
    //     0xa68dec: mov             fp, SP
    // 0xa68df0: CheckStackOverflow
    //     0xa68df0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa68df4: cmp             SP, x16
    //     0xa68df8: b.ls            #0xa68e1c
    // 0xa68dfc: ldr             x16, [fp, #0x10]
    // 0xa68e00: SaveReg r16
    //     0xa68e00: str             x16, [SP, #-8]!
    // 0xa68e04: r0 = detach()
    //     0xa68e04: bl              #0xa68e24  ; [package:flutter/src/cupertino/dialog.dart] __RenderCupertinoDialogActions&RenderBox&ContainerRenderObjectMixin::detach
    // 0xa68e08: add             SP, SP, #8
    // 0xa68e0c: r0 = Null
    //     0xa68e0c: mov             x0, NULL
    // 0xa68e10: LeaveFrame
    //     0xa68e10: mov             SP, fp
    //     0xa68e14: ldp             fp, lr, [SP], #0x10
    // 0xa68e18: ret
    //     0xa68e18: ret             
    // 0xa68e1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa68e1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa68e20: b               #0xa68dfc
  }
}

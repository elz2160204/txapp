// lib: , url: package:flutter/src/rendering/paragraph.dart

// class id: 1049411, size: 0x8
class :: {
}

// class id: 2011, size: 0x8, field offset: 0x8
//   const constructor, transformed mixin,
abstract class __SelectableFragment&Object&Selectable extends Object
     with Selectable {
}

// class id: 2012, size: 0x24, field offset: 0x8
//   transformed mixin,
abstract class __SelectableFragment&Object&Selectable&ChangeNotifier extends __SelectableFragment&Object&Selectable
     with ChangeNotifier {

  _ addListener(/* No info */) {
    // ** addr: 0x7174e8, size: 0x23c
    // 0x7174e8: EnterFrame
    //     0x7174e8: stp             fp, lr, [SP, #-0x10]!
    //     0x7174ec: mov             fp, SP
    // 0x7174f0: AllocStack(0x38)
    //     0x7174f0: sub             SP, SP, #0x38
    // 0x7174f4: ldr             x0, [fp, #0x18]
    // 0x7174f8: LoadField: r3 = r0->field_7
    //     0x7174f8: ldur            x3, [x0, #7]
    // 0x7174fc: stur            x3, [fp, #-8]
    // 0x717500: LoadField: r4 = r0->field_f
    //     0x717500: ldur            w4, [x0, #0xf]
    // 0x717504: DecompressPointer r4
    //     0x717504: add             x4, x4, HEAP, lsl #32
    // 0x717508: stur            x4, [fp, #-0x20]
    // 0x71750c: LoadField: r1 = r4->field_b
    //     0x71750c: ldur            w1, [x4, #0xb]
    // 0x717510: DecompressPointer r1
    //     0x717510: add             x1, x1, HEAP, lsl #32
    // 0x717514: r5 = LoadInt32Instr(r1)
    //     0x717514: sbfx            x5, x1, #1, #0x1f
    // 0x717518: stur            x5, [fp, #-0x18]
    // 0x71751c: cmp             x3, x5
    // 0x717520: b.ne            #0x717664
    // 0x717524: cbnz            x3, #0x717564
    // 0x717528: r1 = <((dynamic this) => void?)?>
    //     0x717528: ldr             x1, [PP, #0x3a28]  ; [pp+0x3a28] TypeArguments: <((dynamic this) => void?)?>
    // 0x71752c: r2 = 2
    //     0x71752c: mov             x2, #2
    // 0x717530: r0 = AllocateArray()
    //     0x717530: bl              #0xd6987c  ; AllocateArrayStub
    // 0x717534: mov             x1, x0
    // 0x717538: ldr             x3, [fp, #0x18]
    // 0x71753c: StoreField: r3->field_f = r0
    //     0x71753c: stur            w0, [x3, #0xf]
    //     0x717540: ldurb           w16, [x3, #-1]
    //     0x717544: ldurb           w17, [x0, #-1]
    //     0x717548: and             x16, x17, x16, lsr #2
    //     0x71754c: tst             x16, HEAP, lsr #32
    //     0x717550: b.eq            #0x717558
    //     0x717554: bl              #0xd682ac
    // 0x717558: mov             x0, x1
    // 0x71755c: mov             x1, x3
    // 0x717560: b               #0x71765c
    // 0x717564: mov             x3, x0
    // 0x717568: lsl             x0, x5, #1
    // 0x71756c: stur            x0, [fp, #-0x10]
    // 0x717570: lsl             x2, x0, #1
    // 0x717574: r1 = <((dynamic this) => void?)?>
    //     0x717574: ldr             x1, [PP, #0x3a28]  ; [pp+0x3a28] TypeArguments: <((dynamic this) => void?)?>
    // 0x717578: r0 = AllocateArray()
    //     0x717578: bl              #0xd6987c  ; AllocateArrayStub
    // 0x71757c: mov             x3, x0
    // 0x717580: stur            x3, [fp, #-0x38]
    // 0x717584: r6 = 0
    //     0x717584: mov             x6, #0
    // 0x717588: ldur            x5, [fp, #-8]
    // 0x71758c: ldur            x4, [fp, #-0x20]
    // 0x717590: stur            x6, [fp, #-0x30]
    // 0x717594: CheckStackOverflow
    //     0x717594: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x717598: cmp             SP, x16
    //     0x71759c: b.ls            #0x717710
    // 0x7175a0: cmp             x6, x5
    // 0x7175a4: b.ge            #0x717634
    // 0x7175a8: ldur            x0, [fp, #-0x18]
    // 0x7175ac: mov             x1, x6
    // 0x7175b0: cmp             x1, x0
    // 0x7175b4: b.hs            #0x717718
    // 0x7175b8: ArrayLoad: r7 = r4[r6]  ; Unknown_4
    //     0x7175b8: add             x16, x4, x6, lsl #2
    //     0x7175bc: ldur            w7, [x16, #0xf]
    // 0x7175c0: DecompressPointer r7
    //     0x7175c0: add             x7, x7, HEAP, lsl #32
    // 0x7175c4: mov             x0, x7
    // 0x7175c8: stur            x7, [fp, #-0x28]
    // 0x7175cc: r2 = Null
    //     0x7175cc: mov             x2, NULL
    // 0x7175d0: r1 = Null
    //     0x7175d0: mov             x1, NULL
    // 0x7175d4: r8 = ((dynamic this) => void?)?
    //     0x7175d4: ldr             x8, [PP, #0x3a30]  ; [pp+0x3a30] FunctionType: ((dynamic this) => void?)?
    // 0x7175d8: r3 = Null
    //     0x7175d8: add             x3, PP, #0x22, lsl #12  ; [pp+0x22260] Null
    //     0x7175dc: ldr             x3, [x3, #0x260]
    // 0x7175e0: r0 = DefaultNullableTypeTest()
    //     0x7175e0: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x7175e4: ldur            x0, [fp, #-0x10]
    // 0x7175e8: ldur            x1, [fp, #-0x30]
    // 0x7175ec: cmp             x1, x0
    // 0x7175f0: b.hs            #0x71771c
    // 0x7175f4: ldur            x1, [fp, #-0x38]
    // 0x7175f8: ldur            x0, [fp, #-0x28]
    // 0x7175fc: ldur            x2, [fp, #-0x30]
    // 0x717600: ArrayStore: r1[r2] = r0  ; List_4
    //     0x717600: add             x25, x1, x2, lsl #2
    //     0x717604: add             x25, x25, #0xf
    //     0x717608: str             w0, [x25]
    //     0x71760c: tbz             w0, #0, #0x717628
    //     0x717610: ldurb           w16, [x1, #-1]
    //     0x717614: ldurb           w17, [x0, #-1]
    //     0x717618: and             x16, x17, x16, lsr #2
    //     0x71761c: tst             x16, HEAP, lsr #32
    //     0x717620: b.eq            #0x717628
    //     0x717624: bl              #0xd67e5c
    // 0x717628: add             x6, x2, #1
    // 0x71762c: ldur            x3, [fp, #-0x38]
    // 0x717630: b               #0x717588
    // 0x717634: ldr             x1, [fp, #0x18]
    // 0x717638: ldur            x0, [fp, #-0x38]
    // 0x71763c: StoreField: r1->field_f = r0
    //     0x71763c: stur            w0, [x1, #0xf]
    //     0x717640: ldurb           w16, [x1, #-1]
    //     0x717644: ldurb           w17, [x0, #-1]
    //     0x717648: and             x16, x17, x16, lsr #2
    //     0x71764c: tst             x16, HEAP, lsr #32
    //     0x717650: b.eq            #0x717658
    //     0x717654: bl              #0xd6826c
    // 0x717658: ldur            x0, [fp, #-0x38]
    // 0x71765c: mov             x4, x0
    // 0x717660: b               #0x71766c
    // 0x717664: mov             x1, x0
    // 0x717668: ldur            x4, [fp, #-0x20]
    // 0x71766c: ldur            x3, [fp, #-8]
    // 0x717670: stur            x4, [fp, #-0x20]
    // 0x717674: add             x0, x3, #1
    // 0x717678: StoreField: r1->field_7 = r0
    //     0x717678: stur            x0, [x1, #7]
    // 0x71767c: LoadField: r2 = r4->field_7
    //     0x71767c: ldur            w2, [x4, #7]
    // 0x717680: DecompressPointer r2
    //     0x717680: add             x2, x2, HEAP, lsl #32
    // 0x717684: ldr             x0, [fp, #0x10]
    // 0x717688: r1 = Null
    //     0x717688: mov             x1, NULL
    // 0x71768c: cmp             w2, NULL
    // 0x717690: b.eq            #0x7176b0
    // 0x717694: LoadField: r4 = r2->field_17
    //     0x717694: ldur            w4, [x2, #0x17]
    // 0x717698: DecompressPointer r4
    //     0x717698: add             x4, x4, HEAP, lsl #32
    // 0x71769c: r8 = X0
    //     0x71769c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x7176a0: LoadField: r9 = r4->field_7
    //     0x7176a0: ldur            x9, [x4, #7]
    // 0x7176a4: r3 = Null
    //     0x7176a4: add             x3, PP, #0x22, lsl #12  ; [pp+0x22270] Null
    //     0x7176a8: ldr             x3, [x3, #0x270]
    // 0x7176ac: blr             x9
    // 0x7176b0: ldur            x2, [fp, #-0x20]
    // 0x7176b4: LoadField: r3 = r2->field_b
    //     0x7176b4: ldur            w3, [x2, #0xb]
    // 0x7176b8: DecompressPointer r3
    //     0x7176b8: add             x3, x3, HEAP, lsl #32
    // 0x7176bc: r0 = LoadInt32Instr(r3)
    //     0x7176bc: sbfx            x0, x3, #1, #0x1f
    // 0x7176c0: ldur            x1, [fp, #-8]
    // 0x7176c4: cmp             x1, x0
    // 0x7176c8: b.hs            #0x717720
    // 0x7176cc: mov             x1, x2
    // 0x7176d0: ldr             x0, [fp, #0x10]
    // 0x7176d4: ldur            x2, [fp, #-8]
    // 0x7176d8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x7176d8: add             x25, x1, x2, lsl #2
    //     0x7176dc: add             x25, x25, #0xf
    //     0x7176e0: str             w0, [x25]
    //     0x7176e4: tbz             w0, #0, #0x717700
    //     0x7176e8: ldurb           w16, [x1, #-1]
    //     0x7176ec: ldurb           w17, [x0, #-1]
    //     0x7176f0: and             x16, x17, x16, lsr #2
    //     0x7176f4: tst             x16, HEAP, lsr #32
    //     0x7176f8: b.eq            #0x717700
    //     0x7176fc: bl              #0xd67e5c
    // 0x717700: r0 = Null
    //     0x717700: mov             x0, NULL
    // 0x717704: LeaveFrame
    //     0x717704: mov             SP, fp
    //     0x717708: ldp             fp, lr, [SP], #0x10
    // 0x71770c: ret
    //     0x71770c: ret             
    // 0x717710: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x717710: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x717714: b               #0x7175a0
    // 0x717718: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x717718: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x71771c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x71771c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x717720: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x717720: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ removeListener(/* No info */) {
    // ** addr: 0x71b418, size: 0x184
    // 0x71b418: EnterFrame
    //     0x71b418: stp             fp, lr, [SP, #-0x10]!
    //     0x71b41c: mov             fp, SP
    // 0x71b420: AllocStack(0x10)
    //     0x71b420: sub             SP, SP, #0x10
    // 0x71b424: CheckStackOverflow
    //     0x71b424: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x71b428: cmp             SP, x16
    //     0x71b42c: b.ls            #0x71b584
    // 0x71b430: ldr             x2, [fp, #0x18]
    // 0x71b434: r3 = 0
    //     0x71b434: mov             x3, #0
    // 0x71b438: stur            x3, [fp, #-8]
    // 0x71b43c: CheckStackOverflow
    //     0x71b43c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x71b440: cmp             SP, x16
    //     0x71b444: b.ls            #0x71b58c
    // 0x71b448: LoadField: r0 = r2->field_7
    //     0x71b448: ldur            x0, [x2, #7]
    // 0x71b44c: cmp             x3, x0
    // 0x71b450: b.ge            #0x71b574
    // 0x71b454: LoadField: r4 = r2->field_f
    //     0x71b454: ldur            w4, [x2, #0xf]
    // 0x71b458: DecompressPointer r4
    //     0x71b458: add             x4, x4, HEAP, lsl #32
    // 0x71b45c: LoadField: r0 = r4->field_b
    //     0x71b45c: ldur            w0, [x4, #0xb]
    // 0x71b460: DecompressPointer r0
    //     0x71b460: add             x0, x0, HEAP, lsl #32
    // 0x71b464: r1 = LoadInt32Instr(r0)
    //     0x71b464: sbfx            x1, x0, #1, #0x1f
    // 0x71b468: mov             x0, x1
    // 0x71b46c: mov             x1, x3
    // 0x71b470: cmp             x1, x0
    // 0x71b474: b.hs            #0x71b594
    // 0x71b478: ArrayLoad: r0 = r4[r3]  ; Unknown_4
    //     0x71b478: add             x16, x4, x3, lsl #2
    //     0x71b47c: ldur            w0, [x16, #0xf]
    // 0x71b480: DecompressPointer r0
    //     0x71b480: add             x0, x0, HEAP, lsl #32
    // 0x71b484: r1 = 59
    //     0x71b484: mov             x1, #0x3b
    // 0x71b488: branchIfSmi(r0, 0x71b494)
    //     0x71b488: tbz             w0, #0, #0x71b494
    // 0x71b48c: r1 = LoadClassIdInstr(r0)
    //     0x71b48c: ldur            x1, [x0, #-1]
    //     0x71b490: ubfx            x1, x1, #0xc, #0x14
    // 0x71b494: ldr             x16, [fp, #0x10]
    // 0x71b498: stp             x16, x0, [SP, #-0x10]!
    // 0x71b49c: mov             x0, x1
    // 0x71b4a0: mov             lr, x0
    // 0x71b4a4: ldr             lr, [x21, lr, lsl #3]
    // 0x71b4a8: blr             lr
    // 0x71b4ac: add             SP, SP, #0x10
    // 0x71b4b0: tbnz            w0, #4, #0x71b560
    // 0x71b4b4: ldr             x3, [fp, #0x18]
    // 0x71b4b8: LoadField: r0 = r3->field_13
    //     0x71b4b8: ldur            x0, [x3, #0x13]
    // 0x71b4bc: cmp             x0, #0
    // 0x71b4c0: b.le            #0x71b548
    // 0x71b4c4: ldur            x4, [fp, #-8]
    // 0x71b4c8: LoadField: r5 = r3->field_f
    //     0x71b4c8: ldur            w5, [x3, #0xf]
    // 0x71b4cc: DecompressPointer r5
    //     0x71b4cc: add             x5, x5, HEAP, lsl #32
    // 0x71b4d0: stur            x5, [fp, #-0x10]
    // 0x71b4d4: LoadField: r2 = r5->field_7
    //     0x71b4d4: ldur            w2, [x5, #7]
    // 0x71b4d8: DecompressPointer r2
    //     0x71b4d8: add             x2, x2, HEAP, lsl #32
    // 0x71b4dc: r0 = Null
    //     0x71b4dc: mov             x0, NULL
    // 0x71b4e0: r1 = Null
    //     0x71b4e0: mov             x1, NULL
    // 0x71b4e4: cmp             w2, NULL
    // 0x71b4e8: b.eq            #0x71b508
    // 0x71b4ec: LoadField: r4 = r2->field_17
    //     0x71b4ec: ldur            w4, [x2, #0x17]
    // 0x71b4f0: DecompressPointer r4
    //     0x71b4f0: add             x4, x4, HEAP, lsl #32
    // 0x71b4f4: r8 = X0
    //     0x71b4f4: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x71b4f8: LoadField: r9 = r4->field_7
    //     0x71b4f8: ldur            x9, [x4, #7]
    // 0x71b4fc: r3 = Null
    //     0x71b4fc: add             x3, PP, #0x22, lsl #12  ; [pp+0x22210] Null
    //     0x71b500: ldr             x3, [x3, #0x210]
    // 0x71b504: blr             x9
    // 0x71b508: ldur            x2, [fp, #-0x10]
    // 0x71b50c: LoadField: r0 = r2->field_b
    //     0x71b50c: ldur            w0, [x2, #0xb]
    // 0x71b510: DecompressPointer r0
    //     0x71b510: add             x0, x0, HEAP, lsl #32
    // 0x71b514: r1 = LoadInt32Instr(r0)
    //     0x71b514: sbfx            x1, x0, #1, #0x1f
    // 0x71b518: mov             x0, x1
    // 0x71b51c: ldur            x1, [fp, #-8]
    // 0x71b520: cmp             x1, x0
    // 0x71b524: b.hs            #0x71b598
    // 0x71b528: ldur            x0, [fp, #-8]
    // 0x71b52c: ArrayStore: r2[r0] = rNULL  ; Unknown_4
    //     0x71b52c: add             x1, x2, x0, lsl #2
    //     0x71b530: stur            NULL, [x1, #0xf]
    // 0x71b534: ldr             x1, [fp, #0x18]
    // 0x71b538: LoadField: r0 = r1->field_1b
    //     0x71b538: ldur            x0, [x1, #0x1b]
    // 0x71b53c: add             x2, x0, #1
    // 0x71b540: StoreField: r1->field_1b = r2
    //     0x71b540: stur            x2, [x1, #0x1b]
    // 0x71b544: b               #0x71b574
    // 0x71b548: mov             x1, x3
    // 0x71b54c: ldur            x0, [fp, #-8]
    // 0x71b550: stp             x0, x1, [SP, #-0x10]!
    // 0x71b554: r0 = _removeAt()
    //     0x71b554: bl              #0x71b59c  ; [package:flutter/src/rendering/paragraph.dart] __SelectableFragment&Object&Selectable&ChangeNotifier::_removeAt
    // 0x71b558: add             SP, SP, #0x10
    // 0x71b55c: b               #0x71b574
    // 0x71b560: ldr             x1, [fp, #0x18]
    // 0x71b564: ldur            x0, [fp, #-8]
    // 0x71b568: add             x3, x0, #1
    // 0x71b56c: mov             x2, x1
    // 0x71b570: b               #0x71b438
    // 0x71b574: r0 = Null
    //     0x71b574: mov             x0, NULL
    // 0x71b578: LeaveFrame
    //     0x71b578: mov             SP, fp
    //     0x71b57c: ldp             fp, lr, [SP], #0x10
    // 0x71b580: ret
    //     0x71b580: ret             
    // 0x71b584: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71b584: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71b588: b               #0x71b430
    // 0x71b58c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71b58c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71b590: b               #0x71b448
    // 0x71b594: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x71b594: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x71b598: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x71b598: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _removeAt(/* No info */) {
    // ** addr: 0x71b59c, size: 0x370
    // 0x71b59c: EnterFrame
    //     0x71b59c: stp             fp, lr, [SP, #-0x10]!
    //     0x71b5a0: mov             fp, SP
    // 0x71b5a4: AllocStack(0x38)
    //     0x71b5a4: sub             SP, SP, #0x38
    // 0x71b5a8: ldr             x3, [fp, #0x18]
    // 0x71b5ac: LoadField: r0 = r3->field_7
    //     0x71b5ac: ldur            x0, [x3, #7]
    // 0x71b5b0: sub             x4, x0, #1
    // 0x71b5b4: stur            x4, [fp, #-0x18]
    // 0x71b5b8: StoreField: r3->field_7 = r4
    //     0x71b5b8: stur            x4, [x3, #7]
    // 0x71b5bc: lsl             x0, x4, #1
    // 0x71b5c0: LoadField: r5 = r3->field_f
    //     0x71b5c0: ldur            w5, [x3, #0xf]
    // 0x71b5c4: DecompressPointer r5
    //     0x71b5c4: add             x5, x5, HEAP, lsl #32
    // 0x71b5c8: stur            x5, [fp, #-0x10]
    // 0x71b5cc: LoadField: r1 = r5->field_b
    //     0x71b5cc: ldur            w1, [x5, #0xb]
    // 0x71b5d0: DecompressPointer r1
    //     0x71b5d0: add             x1, x1, HEAP, lsl #32
    // 0x71b5d4: r6 = LoadInt32Instr(r1)
    //     0x71b5d4: sbfx            x6, x1, #1, #0x1f
    // 0x71b5d8: stur            x6, [fp, #-8]
    // 0x71b5dc: cmp             x0, x6
    // 0x71b5e0: b.gt            #0x71b798
    // 0x71b5e4: r0 = BoxInt64Instr(r4)
    //     0x71b5e4: sbfiz           x0, x4, #1, #0x1f
    //     0x71b5e8: cmp             x4, x0, asr #1
    //     0x71b5ec: b.eq            #0x71b5f8
    //     0x71b5f0: bl              #0xd69bb8
    //     0x71b5f4: stur            x4, [x0, #7]
    // 0x71b5f8: mov             x2, x0
    // 0x71b5fc: r1 = <((dynamic this) => void?)?>
    //     0x71b5fc: ldr             x1, [PP, #0x3a28]  ; [pp+0x3a28] TypeArguments: <((dynamic this) => void?)?>
    // 0x71b600: r0 = AllocateArray()
    //     0x71b600: bl              #0xd6987c  ; AllocateArrayStub
    // 0x71b604: mov             x3, x0
    // 0x71b608: stur            x3, [fp, #-0x30]
    // 0x71b60c: r6 = 0
    //     0x71b60c: mov             x6, #0
    // 0x71b610: ldr             x5, [fp, #0x10]
    // 0x71b614: ldur            x4, [fp, #-0x10]
    // 0x71b618: stur            x6, [fp, #-0x28]
    // 0x71b61c: CheckStackOverflow
    //     0x71b61c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x71b620: cmp             SP, x16
    //     0x71b624: b.ls            #0x71b8d8
    // 0x71b628: cmp             x6, x5
    // 0x71b62c: b.ge            #0x71b6bc
    // 0x71b630: ldur            x0, [fp, #-8]
    // 0x71b634: mov             x1, x6
    // 0x71b638: cmp             x1, x0
    // 0x71b63c: b.hs            #0x71b8e0
    // 0x71b640: ArrayLoad: r7 = r4[r6]  ; Unknown_4
    //     0x71b640: add             x16, x4, x6, lsl #2
    //     0x71b644: ldur            w7, [x16, #0xf]
    // 0x71b648: DecompressPointer r7
    //     0x71b648: add             x7, x7, HEAP, lsl #32
    // 0x71b64c: mov             x0, x7
    // 0x71b650: stur            x7, [fp, #-0x20]
    // 0x71b654: r2 = Null
    //     0x71b654: mov             x2, NULL
    // 0x71b658: r1 = Null
    //     0x71b658: mov             x1, NULL
    // 0x71b65c: r8 = ((dynamic this) => void?)?
    //     0x71b65c: ldr             x8, [PP, #0x3a30]  ; [pp+0x3a30] FunctionType: ((dynamic this) => void?)?
    // 0x71b660: r3 = Null
    //     0x71b660: add             x3, PP, #0x22, lsl #12  ; [pp+0x22220] Null
    //     0x71b664: ldr             x3, [x3, #0x220]
    // 0x71b668: r0 = DefaultNullableTypeTest()
    //     0x71b668: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x71b66c: ldur            x0, [fp, #-0x18]
    // 0x71b670: ldur            x1, [fp, #-0x28]
    // 0x71b674: cmp             x1, x0
    // 0x71b678: b.hs            #0x71b8e4
    // 0x71b67c: ldur            x1, [fp, #-0x30]
    // 0x71b680: ldur            x0, [fp, #-0x20]
    // 0x71b684: ldur            x2, [fp, #-0x28]
    // 0x71b688: ArrayStore: r1[r2] = r0  ; List_4
    //     0x71b688: add             x25, x1, x2, lsl #2
    //     0x71b68c: add             x25, x25, #0xf
    //     0x71b690: str             w0, [x25]
    //     0x71b694: tbz             w0, #0, #0x71b6b0
    //     0x71b698: ldurb           w16, [x1, #-1]
    //     0x71b69c: ldurb           w17, [x0, #-1]
    //     0x71b6a0: and             x16, x17, x16, lsr #2
    //     0x71b6a4: tst             x16, HEAP, lsr #32
    //     0x71b6a8: b.eq            #0x71b6b0
    //     0x71b6ac: bl              #0xd67e5c
    // 0x71b6b0: add             x6, x2, #1
    // 0x71b6b4: ldur            x3, [fp, #-0x30]
    // 0x71b6b8: b               #0x71b610
    // 0x71b6bc: ldr             x5, [fp, #0x10]
    // 0x71b6c0: ldur            x4, [fp, #-0x18]
    // 0x71b6c4: ldur            x3, [fp, #-0x10]
    // 0x71b6c8: stur            x5, [fp, #-0x38]
    // 0x71b6cc: CheckStackOverflow
    //     0x71b6cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x71b6d0: cmp             SP, x16
    //     0x71b6d4: b.ls            #0x71b8e8
    // 0x71b6d8: cmp             x5, x4
    // 0x71b6dc: b.ge            #0x71b770
    // 0x71b6e0: add             x6, x5, #1
    // 0x71b6e4: ldur            x0, [fp, #-8]
    // 0x71b6e8: mov             x1, x6
    // 0x71b6ec: stur            x6, [fp, #-0x28]
    // 0x71b6f0: cmp             x1, x0
    // 0x71b6f4: b.hs            #0x71b8f0
    // 0x71b6f8: ArrayLoad: r7 = r3[r6]  ; Unknown_4
    //     0x71b6f8: add             x16, x3, x6, lsl #2
    //     0x71b6fc: ldur            w7, [x16, #0xf]
    // 0x71b700: DecompressPointer r7
    //     0x71b700: add             x7, x7, HEAP, lsl #32
    // 0x71b704: mov             x0, x7
    // 0x71b708: stur            x7, [fp, #-0x20]
    // 0x71b70c: r2 = Null
    //     0x71b70c: mov             x2, NULL
    // 0x71b710: r1 = Null
    //     0x71b710: mov             x1, NULL
    // 0x71b714: r8 = ((dynamic this) => void?)?
    //     0x71b714: ldr             x8, [PP, #0x3a30]  ; [pp+0x3a30] FunctionType: ((dynamic this) => void?)?
    // 0x71b718: r3 = Null
    //     0x71b718: add             x3, PP, #0x22, lsl #12  ; [pp+0x22230] Null
    //     0x71b71c: ldr             x3, [x3, #0x230]
    // 0x71b720: r0 = DefaultNullableTypeTest()
    //     0x71b720: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x71b724: ldur            x0, [fp, #-0x18]
    // 0x71b728: ldur            x1, [fp, #-0x38]
    // 0x71b72c: cmp             x1, x0
    // 0x71b730: b.hs            #0x71b8f4
    // 0x71b734: ldur            x1, [fp, #-0x30]
    // 0x71b738: ldur            x0, [fp, #-0x20]
    // 0x71b73c: ldur            x2, [fp, #-0x38]
    // 0x71b740: ArrayStore: r1[r2] = r0  ; List_4
    //     0x71b740: add             x25, x1, x2, lsl #2
    //     0x71b744: add             x25, x25, #0xf
    //     0x71b748: str             w0, [x25]
    //     0x71b74c: tbz             w0, #0, #0x71b768
    //     0x71b750: ldurb           w16, [x1, #-1]
    //     0x71b754: ldurb           w17, [x0, #-1]
    //     0x71b758: and             x16, x17, x16, lsr #2
    //     0x71b75c: tst             x16, HEAP, lsr #32
    //     0x71b760: b.eq            #0x71b768
    //     0x71b764: bl              #0xd67e5c
    // 0x71b768: ldur            x5, [fp, #-0x28]
    // 0x71b76c: b               #0x71b6c0
    // 0x71b770: ldr             x1, [fp, #0x18]
    // 0x71b774: ldur            x0, [fp, #-0x30]
    // 0x71b778: StoreField: r1->field_f = r0
    //     0x71b778: stur            w0, [x1, #0xf]
    //     0x71b77c: ldurb           w16, [x1, #-1]
    //     0x71b780: ldurb           w17, [x0, #-1]
    //     0x71b784: and             x16, x17, x16, lsr #2
    //     0x71b788: tst             x16, HEAP, lsr #32
    //     0x71b78c: b.eq            #0x71b794
    //     0x71b790: bl              #0xd6826c
    // 0x71b794: b               #0x71b8c8
    // 0x71b798: mov             x3, x5
    // 0x71b79c: LoadField: r4 = r3->field_7
    //     0x71b79c: ldur            w4, [x3, #7]
    // 0x71b7a0: DecompressPointer r4
    //     0x71b7a0: add             x4, x4, HEAP, lsl #32
    // 0x71b7a4: stur            x4, [fp, #-0x30]
    // 0x71b7a8: ldr             x6, [fp, #0x10]
    // 0x71b7ac: ldur            x5, [fp, #-0x18]
    // 0x71b7b0: stur            x6, [fp, #-0x38]
    // 0x71b7b4: CheckStackOverflow
    //     0x71b7b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x71b7b8: cmp             SP, x16
    //     0x71b7bc: b.ls            #0x71b8f8
    // 0x71b7c0: cmp             x6, x5
    // 0x71b7c4: b.ge            #0x71b874
    // 0x71b7c8: add             x7, x6, #1
    // 0x71b7cc: ldur            x0, [fp, #-8]
    // 0x71b7d0: mov             x1, x7
    // 0x71b7d4: stur            x7, [fp, #-0x28]
    // 0x71b7d8: cmp             x1, x0
    // 0x71b7dc: b.hs            #0x71b900
    // 0x71b7e0: ArrayLoad: r8 = r3[r7]  ; Unknown_4
    //     0x71b7e0: add             x16, x3, x7, lsl #2
    //     0x71b7e4: ldur            w8, [x16, #0xf]
    // 0x71b7e8: DecompressPointer r8
    //     0x71b7e8: add             x8, x8, HEAP, lsl #32
    // 0x71b7ec: mov             x0, x8
    // 0x71b7f0: mov             x2, x4
    // 0x71b7f4: stur            x8, [fp, #-0x20]
    // 0x71b7f8: r1 = Null
    //     0x71b7f8: mov             x1, NULL
    // 0x71b7fc: cmp             w2, NULL
    // 0x71b800: b.eq            #0x71b820
    // 0x71b804: LoadField: r4 = r2->field_17
    //     0x71b804: ldur            w4, [x2, #0x17]
    // 0x71b808: DecompressPointer r4
    //     0x71b808: add             x4, x4, HEAP, lsl #32
    // 0x71b80c: r8 = X0
    //     0x71b80c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x71b810: LoadField: r9 = r4->field_7
    //     0x71b810: ldur            x9, [x4, #7]
    // 0x71b814: r3 = Null
    //     0x71b814: add             x3, PP, #0x22, lsl #12  ; [pp+0x22240] Null
    //     0x71b818: ldr             x3, [x3, #0x240]
    // 0x71b81c: blr             x9
    // 0x71b820: ldur            x0, [fp, #-8]
    // 0x71b824: ldur            x1, [fp, #-0x38]
    // 0x71b828: cmp             x1, x0
    // 0x71b82c: b.hs            #0x71b904
    // 0x71b830: ldur            x1, [fp, #-0x10]
    // 0x71b834: ldur            x0, [fp, #-0x20]
    // 0x71b838: ldur            x2, [fp, #-0x38]
    // 0x71b83c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x71b83c: add             x25, x1, x2, lsl #2
    //     0x71b840: add             x25, x25, #0xf
    //     0x71b844: str             w0, [x25]
    //     0x71b848: tbz             w0, #0, #0x71b864
    //     0x71b84c: ldurb           w16, [x1, #-1]
    //     0x71b850: ldurb           w17, [x0, #-1]
    //     0x71b854: and             x16, x17, x16, lsr #2
    //     0x71b858: tst             x16, HEAP, lsr #32
    //     0x71b85c: b.eq            #0x71b864
    //     0x71b860: bl              #0xd67e5c
    // 0x71b864: ldur            x6, [fp, #-0x28]
    // 0x71b868: ldur            x3, [fp, #-0x10]
    // 0x71b86c: ldur            x4, [fp, #-0x30]
    // 0x71b870: b               #0x71b7ac
    // 0x71b874: mov             x4, x5
    // 0x71b878: ldur            x2, [fp, #-0x30]
    // 0x71b87c: r0 = Null
    //     0x71b87c: mov             x0, NULL
    // 0x71b880: r1 = Null
    //     0x71b880: mov             x1, NULL
    // 0x71b884: cmp             w2, NULL
    // 0x71b888: b.eq            #0x71b8a8
    // 0x71b88c: LoadField: r4 = r2->field_17
    //     0x71b88c: ldur            w4, [x2, #0x17]
    // 0x71b890: DecompressPointer r4
    //     0x71b890: add             x4, x4, HEAP, lsl #32
    // 0x71b894: r8 = X0
    //     0x71b894: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x71b898: LoadField: r9 = r4->field_7
    //     0x71b898: ldur            x9, [x4, #7]
    // 0x71b89c: r3 = Null
    //     0x71b89c: add             x3, PP, #0x22, lsl #12  ; [pp+0x22250] Null
    //     0x71b8a0: ldr             x3, [x3, #0x250]
    // 0x71b8a4: blr             x9
    // 0x71b8a8: ldur            x0, [fp, #-8]
    // 0x71b8ac: ldur            x1, [fp, #-0x18]
    // 0x71b8b0: cmp             x1, x0
    // 0x71b8b4: b.hs            #0x71b908
    // 0x71b8b8: ldur            x2, [fp, #-0x18]
    // 0x71b8bc: ldur            x1, [fp, #-0x10]
    // 0x71b8c0: ArrayStore: r1[r2] = rNULL  ; Unknown_4
    //     0x71b8c0: add             x3, x1, x2, lsl #2
    //     0x71b8c4: stur            NULL, [x3, #0xf]
    // 0x71b8c8: r0 = Null
    //     0x71b8c8: mov             x0, NULL
    // 0x71b8cc: LeaveFrame
    //     0x71b8cc: mov             SP, fp
    //     0x71b8d0: ldp             fp, lr, [SP], #0x10
    // 0x71b8d4: ret
    //     0x71b8d4: ret             
    // 0x71b8d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71b8d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71b8dc: b               #0x71b628
    // 0x71b8e0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x71b8e0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x71b8e4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x71b8e4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x71b8e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71b8e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71b8ec: b               #0x71b6d8
    // 0x71b8f0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x71b8f0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x71b8f4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x71b8f4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x71b8f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71b8f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71b8fc: b               #0x71b7c0
    // 0x71b900: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x71b900: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x71b904: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x71b904: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x71b908: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x71b908: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa64d9c, size: 0x18
    // 0xa64d9c: r4 = 0
    //     0xa64d9c: mov             x4, #0
    // 0xa64da0: r1 = Function 'dispose':.
    //     0xa64da0: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4bbb8] AnonymousClosure: (0xa64db4), in [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::dispose (0xa6b240)
    //     0xa64da4: ldr             x1, [x17, #0xbb8]
    // 0xa64da8: r24 = BuildNonGenericMethodExtractorStub
    //     0xa64da8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa64dac: LoadField: r0 = r24->field_17
    //     0xa64dac: ldur            x0, [x24, #0x17]
    // 0xa64db0: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa64db4, size: 0x48
    // 0xa64db4: EnterFrame
    //     0xa64db4: stp             fp, lr, [SP, #-0x10]!
    //     0xa64db8: mov             fp, SP
    // 0xa64dbc: ldr             x0, [fp, #0x10]
    // 0xa64dc0: LoadField: r1 = r0->field_17
    //     0xa64dc0: ldur            w1, [x0, #0x17]
    // 0xa64dc4: DecompressPointer r1
    //     0xa64dc4: add             x1, x1, HEAP, lsl #32
    // 0xa64dc8: CheckStackOverflow
    //     0xa64dc8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa64dcc: cmp             SP, x16
    //     0xa64dd0: b.ls            #0xa64df4
    // 0xa64dd4: LoadField: r0 = r1->field_f
    //     0xa64dd4: ldur            w0, [x1, #0xf]
    // 0xa64dd8: DecompressPointer r0
    //     0xa64dd8: add             x0, x0, HEAP, lsl #32
    // 0xa64ddc: SaveReg r0
    //     0xa64ddc: str             x0, [SP, #-8]!
    // 0xa64de0: r0 = dispose()
    //     0xa64de0: bl              #0xa6b240  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::dispose
    // 0xa64de4: add             SP, SP, #8
    // 0xa64de8: LeaveFrame
    //     0xa64de8: mov             SP, fp
    //     0xa64dec: ldp             fp, lr, [SP], #0x10
    // 0xa64df0: ret
    //     0xa64df0: ret             
    // 0xa64df4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa64df4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa64df8: b               #0xa64dd4
  }
}

// class id: 2013, size: 0x44, field offset: 0x24
class _SelectableFragment extends __SelectableFragment&Object&Selectable&ChangeNotifier
    implements TextLayoutMetrics {

  late SelectionGeometry _selectionGeometry; // offset: 0x3c

  _ didChangeParagraphLayout(/* No info */) {
    // ** addr: 0x6c0dd0, size: 0x10
    // 0x6c0dd0: ldr             x1, [SP]
    // 0x6c0dd4: StoreField: r1->field_3f = rNULL
    //     0x6c0dd4: stur            NULL, [x1, #0x3f]
    // 0x6c0dd8: r0 = Null
    //     0x6c0dd8: mov             x0, NULL
    // 0x6c0ddc: ret
    //     0x6c0ddc: ret             
  }
  get _ value(/* No info */) {
    // ** addr: 0xc69b44, size: 0x40
    // 0xc69b44: EnterFrame
    //     0xc69b44: stp             fp, lr, [SP, #-0x10]!
    //     0xc69b48: mov             fp, SP
    // 0xc69b4c: ldr             x1, [fp, #0x10]
    // 0xc69b50: LoadField: r2 = r1->field_3b
    //     0xc69b50: ldur            w2, [x1, #0x3b]
    // 0xc69b54: DecompressPointer r2
    //     0xc69b54: add             x2, x2, HEAP, lsl #32
    // 0xc69b58: r16 = Sentinel
    //     0xc69b58: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc69b5c: cmp             w2, w16
    // 0xc69b60: b.eq            #0xc69b78
    // 0xc69b64: r0 = Instance_SelectionGeometry
    //     0xc69b64: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d408] Obj!SelectionGeometry@b352f1
    //     0xc69b68: ldr             x0, [x0, #0x408]
    // 0xc69b6c: LeaveFrame
    //     0xc69b6c: mov             SP, fp
    //     0xc69b70: ldp             fp, lr, [SP], #0x10
    // 0xc69b74: ret
    //     0xc69b74: ret             
    // 0xc69b78: r9 = _selectionGeometry
    //     0xc69b78: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d3f0] Field <_SelectableFragment@507149678._selectionGeometry@507149678>: late (offset: 0x3c)
    //     0xc69b7c: ldr             x9, [x9, #0x3f0]
    // 0xc69b80: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc69b80: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ getTransformTo(/* No info */) {
    // ** addr: 0xd0380c, size: 0x74
    // 0xd0380c: EnterFrame
    //     0xd0380c: stp             fp, lr, [SP, #-0x10]!
    //     0xd03810: mov             fp, SP
    // 0xd03814: AllocStack(0x8)
    //     0xd03814: sub             SP, SP, #8
    // 0xd03818: CheckStackOverflow
    //     0xd03818: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd0381c: cmp             SP, x16
    //     0xd03820: b.ls            #0xd03878
    // 0xd03824: ldr             x16, [fp, #0x18]
    // 0xd03828: SaveReg r16
    //     0xd03828: str             x16, [SP, #-8]!
    // 0xd0382c: r0 = getTransformToParagraph()
    //     0xd0382c: bl              #0xd03880  ; [package:flutter/src/rendering/paragraph.dart] _SelectableFragment::getTransformToParagraph
    // 0xd03830: add             SP, SP, #8
    // 0xd03834: mov             x1, x0
    // 0xd03838: ldr             x0, [fp, #0x18]
    // 0xd0383c: stur            x1, [fp, #-8]
    // 0xd03840: LoadField: r2 = r0->field_27
    //     0xd03840: ldur            w2, [x0, #0x27]
    // 0xd03844: DecompressPointer r2
    //     0xd03844: add             x2, x2, HEAP, lsl #32
    // 0xd03848: ldr             x16, [fp, #0x10]
    // 0xd0384c: stp             x16, x2, [SP, #-0x10]!
    // 0xd03850: r0 = getTransformTo()
    //     0xd03850: bl              #0x643bcc  ; [package:flutter/src/rendering/object.dart] RenderObject::getTransformTo
    // 0xd03854: add             SP, SP, #0x10
    // 0xd03858: ldur            x16, [fp, #-8]
    // 0xd0385c: stp             x0, x16, [SP, #-0x10]!
    // 0xd03860: r0 = multiply()
    //     0xd03860: bl              #0x625d1c  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0xd03864: add             SP, SP, #0x10
    // 0xd03868: ldur            x0, [fp, #-8]
    // 0xd0386c: LeaveFrame
    //     0xd0386c: mov             SP, fp
    //     0xd03870: ldp             fp, lr, [SP], #0x10
    // 0xd03874: ret
    //     0xd03874: ret             
    // 0xd03878: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03878: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0387c: b               #0xd03824
  }
  _ getTransformToParagraph(/* No info */) {
    // ** addr: 0xd03880, size: 0xa4
    // 0xd03880: EnterFrame
    //     0xd03880: stp             fp, lr, [SP, #-0x10]!
    //     0xd03884: mov             fp, SP
    // 0xd03888: AllocStack(0x8)
    //     0xd03888: sub             SP, SP, #8
    // 0xd0388c: CheckStackOverflow
    //     0xd0388c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd03890: cmp             SP, x16
    //     0xd03894: b.ls            #0xd0390c
    // 0xd03898: ldr             x16, [fp, #0x10]
    // 0xd0389c: SaveReg r16
    //     0xd0389c: str             x16, [SP, #-8]!
    // 0xd038a0: r0 = _rect()
    //     0xd038a0: bl              #0xd03924  ; [package:flutter/src/rendering/paragraph.dart] _SelectableFragment::_rect
    // 0xd038a4: add             SP, SP, #8
    // 0xd038a8: LoadField: d0 = r0->field_7
    //     0xd038a8: ldur            d0, [x0, #7]
    // 0xd038ac: stur            d0, [fp, #-8]
    // 0xd038b0: ldr             x16, [fp, #0x10]
    // 0xd038b4: SaveReg r16
    //     0xd038b4: str             x16, [SP, #-8]!
    // 0xd038b8: r0 = _rect()
    //     0xd038b8: bl              #0xd03924  ; [package:flutter/src/rendering/paragraph.dart] _SelectableFragment::_rect
    // 0xd038bc: add             SP, SP, #8
    // 0xd038c0: LoadField: d0 = r0->field_f
    //     0xd038c0: ldur            d0, [x0, #0xf]
    // 0xd038c4: ldur            d1, [fp, #-8]
    // 0xd038c8: r0 = inline_Allocate_Double()
    //     0xd038c8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd038cc: add             x0, x0, #0x10
    //     0xd038d0: cmp             x1, x0
    //     0xd038d4: b.ls            #0xd03914
    //     0xd038d8: str             x0, [THR, #0x60]  ; THR::top
    //     0xd038dc: sub             x0, x0, #0xf
    //     0xd038e0: mov             x1, #0xd108
    //     0xd038e4: movk            x1, #3, lsl #16
    //     0xd038e8: stur            x1, [x0, #-1]
    // 0xd038ec: StoreField: r0->field_7 = d1
    //     0xd038ec: stur            d1, [x0, #7]
    // 0xd038f0: stp             x0, NULL, [SP, #-0x10]!
    // 0xd038f4: SaveReg d0
    //     0xd038f4: str             d0, [SP, #-8]!
    // 0xd038f8: r0 = Matrix4.translationValues()
    //     0xd038f8: bl              #0x6245d8  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.translationValues
    // 0xd038fc: add             SP, SP, #0x18
    // 0xd03900: LeaveFrame
    //     0xd03900: mov             SP, fp
    //     0xd03904: ldp             fp, lr, [SP], #0x10
    // 0xd03908: ret
    //     0xd03908: ret             
    // 0xd0390c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0390c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03910: b               #0xd03898
    // 0xd03914: stp             q0, q1, [SP, #-0x20]!
    // 0xd03918: r0 = AllocateDouble()
    //     0xd03918: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xd0391c: ldp             q0, q1, [SP], #0x20
    // 0xd03920: b               #0xd038ec
  }
  get _ _rect(/* No info */) {
    // ** addr: 0xd03924, size: 0x2ac
    // 0xd03924: EnterFrame
    //     0xd03924: stp             fp, lr, [SP, #-0x10]!
    //     0xd03928: mov             fp, SP
    // 0xd0392c: AllocStack(0x48)
    //     0xd0392c: sub             SP, SP, #0x48
    // 0xd03930: CheckStackOverflow
    //     0xd03930: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd03934: cmp             SP, x16
    //     0xd03938: b.ls            #0xd03bbc
    // 0xd0393c: ldr             x0, [fp, #0x10]
    // 0xd03940: LoadField: r1 = r0->field_3f
    //     0xd03940: ldur            w1, [x0, #0x3f]
    // 0xd03944: DecompressPointer r1
    //     0xd03944: add             x1, x1, HEAP, lsl #32
    // 0xd03948: cmp             w1, NULL
    // 0xd0394c: b.ne            #0xd03bac
    // 0xd03950: LoadField: r1 = r0->field_27
    //     0xd03950: ldur            w1, [x0, #0x27]
    // 0xd03954: DecompressPointer r1
    //     0xd03954: add             x1, x1, HEAP, lsl #32
    // 0xd03958: stur            x1, [fp, #-0x18]
    // 0xd0395c: LoadField: r2 = r0->field_23
    //     0xd0395c: ldur            w2, [x0, #0x23]
    // 0xd03960: DecompressPointer r2
    //     0xd03960: add             x2, x2, HEAP, lsl #32
    // 0xd03964: LoadField: r3 = r2->field_7
    //     0xd03964: ldur            x3, [x2, #7]
    // 0xd03968: stur            x3, [fp, #-0x10]
    // 0xd0396c: LoadField: r4 = r2->field_f
    //     0xd0396c: ldur            x4, [x2, #0xf]
    // 0xd03970: stur            x4, [fp, #-8]
    // 0xd03974: r0 = TextSelection()
    //     0xd03974: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xd03978: mov             x1, x0
    // 0xd0397c: ldur            x0, [fp, #-0x10]
    // 0xd03980: StoreField: r1->field_17 = r0
    //     0xd03980: stur            x0, [x1, #0x17]
    // 0xd03984: ldur            x2, [fp, #-8]
    // 0xd03988: StoreField: r1->field_1f = r2
    //     0xd03988: stur            x2, [x1, #0x1f]
    // 0xd0398c: r3 = Instance_TextAffinity
    //     0xd0398c: ldr             x3, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0xd03990: StoreField: r1->field_27 = r3
    //     0xd03990: stur            w3, [x1, #0x27]
    // 0xd03994: r4 = false
    //     0xd03994: add             x4, NULL, #0x30  ; false
    // 0xd03998: StoreField: r1->field_2b = r4
    //     0xd03998: stur            w4, [x1, #0x2b]
    // 0xd0399c: cmp             x0, x2
    // 0xd039a0: b.ge            #0xd039ac
    // 0xd039a4: mov             x4, x0
    // 0xd039a8: b               #0xd039b0
    // 0xd039ac: mov             x4, x2
    // 0xd039b0: cmp             x0, x2
    // 0xd039b4: b.lt            #0xd039bc
    // 0xd039b8: mov             x2, x0
    // 0xd039bc: StoreField: r1->field_7 = r4
    //     0xd039bc: stur            x4, [x1, #7]
    // 0xd039c0: StoreField: r1->field_f = r2
    //     0xd039c0: stur            x2, [x1, #0xf]
    // 0xd039c4: ldur            x16, [fp, #-0x18]
    // 0xd039c8: stp             x1, x16, [SP, #-0x10]!
    // 0xd039cc: r0 = getBoxesForSelection()
    //     0xd039cc: bl              #0x649308  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::getBoxesForSelection
    // 0xd039d0: add             SP, SP, #0x10
    // 0xd039d4: stur            x0, [fp, #-0x20]
    // 0xd039d8: LoadField: r1 = r0->field_b
    //     0xd039d8: ldur            w1, [x0, #0xb]
    // 0xd039dc: DecompressPointer r1
    //     0xd039dc: add             x1, x1, HEAP, lsl #32
    // 0xd039e0: cbz             w1, #0xd03ae8
    // 0xd039e4: SaveReg r0
    //     0xd039e4: str             x0, [SP, #-8]!
    // 0xd039e8: r0 = first()
    //     0xd039e8: bl              #0x7192e8  ; [dart:core] _GrowableList::first
    // 0xd039ec: add             SP, SP, #8
    // 0xd039f0: SaveReg r0
    //     0xd039f0: str             x0, [SP, #-8]!
    // 0xd039f4: r0 = toRect()
    //     0xd039f4: bl              #0x52231c  ; [dart:ui] TextBox::toRect
    // 0xd039f8: add             SP, SP, #8
    // 0xd039fc: mov             x4, x0
    // 0xd03a00: r3 = 1
    //     0xd03a00: mov             x3, #1
    // 0xd03a04: ldur            x2, [fp, #-0x20]
    // 0xd03a08: stur            x4, [fp, #-0x28]
    // 0xd03a0c: stur            x3, [fp, #-8]
    // 0xd03a10: CheckStackOverflow
    //     0xd03a10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd03a14: cmp             SP, x16
    //     0xd03a18: b.ls            #0xd03bc4
    // 0xd03a1c: LoadField: r0 = r2->field_b
    //     0xd03a1c: ldur            w0, [x2, #0xb]
    // 0xd03a20: DecompressPointer r0
    //     0xd03a20: add             x0, x0, HEAP, lsl #32
    // 0xd03a24: r1 = LoadInt32Instr(r0)
    //     0xd03a24: sbfx            x1, x0, #1, #0x1f
    // 0xd03a28: cmp             x3, x1
    // 0xd03a2c: b.ge            #0xd03abc
    // 0xd03a30: mov             x0, x1
    // 0xd03a34: mov             x1, x3
    // 0xd03a38: cmp             x1, x0
    // 0xd03a3c: b.hs            #0xd03bcc
    // 0xd03a40: LoadField: r0 = r2->field_f
    //     0xd03a40: ldur            w0, [x2, #0xf]
    // 0xd03a44: DecompressPointer r0
    //     0xd03a44: add             x0, x0, HEAP, lsl #32
    // 0xd03a48: ArrayLoad: r1 = r0[r3]  ; Unknown_4
    //     0xd03a48: add             x16, x0, x3, lsl #2
    //     0xd03a4c: ldur            w1, [x16, #0xf]
    // 0xd03a50: DecompressPointer r1
    //     0xd03a50: add             x1, x1, HEAP, lsl #32
    // 0xd03a54: LoadField: d0 = r1->field_7
    //     0xd03a54: ldur            d0, [x1, #7]
    // 0xd03a58: stur            d0, [fp, #-0x48]
    // 0xd03a5c: LoadField: d1 = r1->field_f
    //     0xd03a5c: ldur            d1, [x1, #0xf]
    // 0xd03a60: stur            d1, [fp, #-0x40]
    // 0xd03a64: LoadField: d2 = r1->field_17
    //     0xd03a64: ldur            d2, [x1, #0x17]
    // 0xd03a68: stur            d2, [fp, #-0x38]
    // 0xd03a6c: LoadField: d3 = r1->field_1f
    //     0xd03a6c: ldur            d3, [x1, #0x1f]
    // 0xd03a70: stur            d3, [fp, #-0x30]
    // 0xd03a74: r0 = Rect()
    //     0xd03a74: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0xd03a78: ldur            d0, [fp, #-0x48]
    // 0xd03a7c: StoreField: r0->field_7 = d0
    //     0xd03a7c: stur            d0, [x0, #7]
    // 0xd03a80: ldur            d0, [fp, #-0x40]
    // 0xd03a84: StoreField: r0->field_f = d0
    //     0xd03a84: stur            d0, [x0, #0xf]
    // 0xd03a88: ldur            d0, [fp, #-0x38]
    // 0xd03a8c: StoreField: r0->field_17 = d0
    //     0xd03a8c: stur            d0, [x0, #0x17]
    // 0xd03a90: ldur            d0, [fp, #-0x30]
    // 0xd03a94: StoreField: r0->field_1f = d0
    //     0xd03a94: stur            d0, [x0, #0x1f]
    // 0xd03a98: ldur            x16, [fp, #-0x28]
    // 0xd03a9c: stp             x0, x16, [SP, #-0x10]!
    // 0xd03aa0: r0 = expandToInclude()
    //     0xd03aa0: bl              #0x5251a0  ; [dart:ui] Rect::expandToInclude
    // 0xd03aa4: add             SP, SP, #0x10
    // 0xd03aa8: mov             x1, x0
    // 0xd03aac: ldur            x0, [fp, #-8]
    // 0xd03ab0: add             x3, x0, #1
    // 0xd03ab4: mov             x4, x1
    // 0xd03ab8: b               #0xd03a04
    // 0xd03abc: ldr             x1, [fp, #0x10]
    // 0xd03ac0: ldur            x0, [fp, #-0x28]
    // 0xd03ac4: StoreField: r1->field_3f = r0
    //     0xd03ac4: stur            w0, [x1, #0x3f]
    //     0xd03ac8: ldurb           w16, [x1, #-1]
    //     0xd03acc: ldurb           w17, [x0, #-1]
    //     0xd03ad0: and             x16, x17, x16, lsr #2
    //     0xd03ad4: tst             x16, HEAP, lsr #32
    //     0xd03ad8: b.eq            #0xd03ae0
    //     0xd03adc: bl              #0xd6826c
    // 0xd03ae0: ldur            x2, [fp, #-0x28]
    // 0xd03ae4: b               #0xd03ba4
    // 0xd03ae8: ldr             x1, [fp, #0x10]
    // 0xd03aec: ldur            x2, [fp, #-0x18]
    // 0xd03af0: ldur            x0, [fp, #-0x10]
    // 0xd03af4: r0 = TextPosition()
    //     0xd03af4: bl              #0x5223f0  ; AllocateTextPositionStub -> TextPosition (size=0x14)
    // 0xd03af8: mov             x1, x0
    // 0xd03afc: ldur            x0, [fp, #-0x10]
    // 0xd03b00: StoreField: r1->field_7 = r0
    //     0xd03b00: stur            x0, [x1, #7]
    // 0xd03b04: r0 = Instance_TextAffinity
    //     0xd03b04: ldr             x0, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0xd03b08: StoreField: r1->field_f = r0
    //     0xd03b08: stur            w0, [x1, #0xf]
    // 0xd03b0c: ldur            x16, [fp, #-0x18]
    // 0xd03b10: stp             x1, x16, [SP, #-0x10]!
    // 0xd03b14: r0 = _getOffsetForPosition()
    //     0xd03b14: bl              #0xd03bd0  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_getOffsetForPosition
    // 0xd03b18: add             SP, SP, #0x10
    // 0xd03b1c: mov             x1, x0
    // 0xd03b20: ldur            x0, [fp, #-0x18]
    // 0xd03b24: stur            x1, [fp, #-0x20]
    // 0xd03b28: LoadField: r2 = r0->field_6f
    //     0xd03b28: ldur            w2, [x0, #0x6f]
    // 0xd03b2c: DecompressPointer r2
    //     0xd03b2c: add             x2, x2, HEAP, lsl #32
    // 0xd03b30: SaveReg r2
    //     0xd03b30: str             x2, [SP, #-8]!
    // 0xd03b34: r0 = preferredLineHeight()
    //     0xd03b34: bl              #0x51a438  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0xd03b38: add             SP, SP, #8
    // 0xd03b3c: fneg            d1, d0
    // 0xd03b40: ldur            x16, [fp, #-0x20]
    // 0xd03b44: r30 = 0.000000
    //     0xd03b44: ldr             lr, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xd03b48: stp             lr, x16, [SP, #-0x10]!
    // 0xd03b4c: SaveReg d1
    //     0xd03b4c: str             d1, [SP, #-8]!
    // 0xd03b50: r0 = translate()
    //     0xd03b50: bl              #0x65ad6c  ; [dart:ui] Offset::translate
    // 0xd03b54: add             SP, SP, #0x18
    // 0xd03b58: stur            x0, [fp, #-0x18]
    // 0xd03b5c: r0 = Rect()
    //     0xd03b5c: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0xd03b60: stur            x0, [fp, #-0x28]
    // 0xd03b64: ldur            x16, [fp, #-0x20]
    // 0xd03b68: stp             x16, x0, [SP, #-0x10]!
    // 0xd03b6c: ldur            x16, [fp, #-0x18]
    // 0xd03b70: SaveReg r16
    //     0xd03b70: str             x16, [SP, #-8]!
    // 0xd03b74: r0 = Rect.fromPoints()
    //     0xd03b74: bl              #0x656aa4  ; [dart:ui] Rect::Rect.fromPoints
    // 0xd03b78: add             SP, SP, #0x18
    // 0xd03b7c: ldur            x0, [fp, #-0x28]
    // 0xd03b80: ldr             x2, [fp, #0x10]
    // 0xd03b84: StoreField: r2->field_3f = r0
    //     0xd03b84: stur            w0, [x2, #0x3f]
    //     0xd03b88: ldurb           w16, [x2, #-1]
    //     0xd03b8c: ldurb           w17, [x0, #-1]
    //     0xd03b90: and             x16, x17, x16, lsr #2
    //     0xd03b94: tst             x16, HEAP, lsr #32
    //     0xd03b98: b.eq            #0xd03ba0
    //     0xd03b9c: bl              #0xd6828c
    // 0xd03ba0: ldur            x2, [fp, #-0x28]
    // 0xd03ba4: mov             x0, x2
    // 0xd03ba8: b               #0xd03bb0
    // 0xd03bac: mov             x0, x1
    // 0xd03bb0: LeaveFrame
    //     0xd03bb0: mov             SP, fp
    //     0xd03bb4: ldp             fp, lr, [SP], #0x10
    // 0xd03bb8: ret
    //     0xd03bb8: ret             
    // 0xd03bbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03bbc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03bc0: b               #0xd0393c
    // 0xd03bc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03bc4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03bc8: b               #0xd03a1c
    // 0xd03bcc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd03bcc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ pushHandleLayers(/* No info */) {
    // ** addr: 0xd03e04, size: 0x2c
    // 0xd03e04: ldr             x1, [SP, #0x10]
    // 0xd03e08: LoadField: r2 = r1->field_27
    //     0xd03e08: ldur            w2, [x1, #0x27]
    // 0xd03e0c: DecompressPointer r2
    //     0xd03e0c: add             x2, x2, HEAP, lsl #32
    // 0xd03e10: LoadField: r1 = r2->field_f
    //     0xd03e10: ldur            w1, [x2, #0xf]
    // 0xd03e14: DecompressPointer r1
    //     0xd03e14: add             x1, x1, HEAP, lsl #32
    // 0xd03e18: cmp             w1, NULL
    // 0xd03e1c: b.ne            #0xd03e28
    // 0xd03e20: r0 = Null
    //     0xd03e20: mov             x0, NULL
    // 0xd03e24: ret
    //     0xd03e24: ret             
    // 0xd03e28: r0 = Null
    //     0xd03e28: mov             x0, NULL
    // 0xd03e2c: ret
    //     0xd03e2c: ret             
  }
  get _ size(/* No info */) {
    // ** addr: 0xd03e30, size: 0x44
    // 0xd03e30: EnterFrame
    //     0xd03e30: stp             fp, lr, [SP, #-0x10]!
    //     0xd03e34: mov             fp, SP
    // 0xd03e38: CheckStackOverflow
    //     0xd03e38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd03e3c: cmp             SP, x16
    //     0xd03e40: b.ls            #0xd03e6c
    // 0xd03e44: ldr             x16, [fp, #0x10]
    // 0xd03e48: SaveReg r16
    //     0xd03e48: str             x16, [SP, #-8]!
    // 0xd03e4c: r0 = _rect()
    //     0xd03e4c: bl              #0xd03924  ; [package:flutter/src/rendering/paragraph.dart] _SelectableFragment::_rect
    // 0xd03e50: add             SP, SP, #8
    // 0xd03e54: SaveReg r0
    //     0xd03e54: str             x0, [SP, #-8]!
    // 0xd03e58: r0 = size()
    //     0xd03e58: bl              #0x5bc584  ; [dart:ui] Rect::size
    // 0xd03e5c: add             SP, SP, #8
    // 0xd03e60: LeaveFrame
    //     0xd03e60: mov             SP, fp
    //     0xd03e64: ldp             fp, lr, [SP], #0x10
    // 0xd03e68: ret
    //     0xd03e68: ret             
    // 0xd03e6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03e6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03e70: b               #0xd03e44
  }
}

// class id: 2015, size: 0x14, field offset: 0xc
//   const constructor, 
class PlaceholderSpanIndexSemanticsTag extends SemanticsTag {

  get _ hashCode(/* No info */) {
    // ** addr: 0xb0f168, size: 0x74
    // 0xb0f168: EnterFrame
    //     0xb0f168: stp             fp, lr, [SP, #-0x10]!
    //     0xb0f16c: mov             fp, SP
    // 0xb0f170: CheckStackOverflow
    //     0xb0f170: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0f174: cmp             SP, x16
    //     0xb0f178: b.ls            #0xb0f1d4
    // 0xb0f17c: ldr             x0, [fp, #0x10]
    // 0xb0f180: LoadField: r2 = r0->field_b
    //     0xb0f180: ldur            x2, [x0, #0xb]
    // 0xb0f184: r0 = BoxInt64Instr(r2)
    //     0xb0f184: sbfiz           x0, x2, #1, #0x1f
    //     0xb0f188: cmp             x2, x0, asr #1
    //     0xb0f18c: b.eq            #0xb0f198
    //     0xb0f190: bl              #0xd69bb8
    //     0xb0f194: stur            x2, [x0, #7]
    // 0xb0f198: r16 = PlaceholderSpanIndexSemanticsTag
    //     0xb0f198: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d1d8] Type: PlaceholderSpanIndexSemanticsTag
    //     0xb0f19c: ldr             x16, [x16, #0x1d8]
    // 0xb0f1a0: stp             x0, x16, [SP, #-0x10]!
    // 0xb0f1a4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xb0f1a4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xb0f1a8: r0 = hash()
    //     0xb0f1a8: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0f1ac: add             SP, SP, #0x10
    // 0xb0f1b0: mov             x2, x0
    // 0xb0f1b4: r0 = BoxInt64Instr(r2)
    //     0xb0f1b4: sbfiz           x0, x2, #1, #0x1f
    //     0xb0f1b8: cmp             x2, x0, asr #1
    //     0xb0f1bc: b.eq            #0xb0f1c8
    //     0xb0f1c0: bl              #0xd69bb8
    //     0xb0f1c4: stur            x2, [x0, #7]
    // 0xb0f1c8: LeaveFrame
    //     0xb0f1c8: mov             SP, fp
    //     0xb0f1cc: ldp             fp, lr, [SP], #0x10
    // 0xb0f1d0: ret
    //     0xb0f1d0: ret             
    // 0xb0f1d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0f1d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0f1d8: b               #0xb0f17c
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9f190, size: 0x5c
    // 0xc9f190: ldr             x1, [SP]
    // 0xc9f194: cmp             w1, NULL
    // 0xc9f198: b.ne            #0xc9f1a4
    // 0xc9f19c: r0 = false
    //     0xc9f19c: add             x0, NULL, #0x30  ; false
    // 0xc9f1a0: ret
    //     0xc9f1a0: ret             
    // 0xc9f1a4: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc9f1a4: mov             x2, #0x76
    //     0xc9f1a8: tbz             w1, #0, #0xc9f1b8
    //     0xc9f1ac: ldur            x2, [x1, #-1]
    //     0xc9f1b0: ubfx            x2, x2, #0xc, #0x14
    //     0xc9f1b4: lsl             x2, x2, #1
    // 0xc9f1b8: cmp             w2, #0xfbe
    // 0xc9f1bc: b.ne            #0xc9f1e4
    // 0xc9f1c0: ldr             x2, [SP, #8]
    // 0xc9f1c4: LoadField: r3 = r1->field_b
    //     0xc9f1c4: ldur            x3, [x1, #0xb]
    // 0xc9f1c8: LoadField: r1 = r2->field_b
    //     0xc9f1c8: ldur            x1, [x2, #0xb]
    // 0xc9f1cc: cmp             x3, x1
    // 0xc9f1d0: r16 = true
    //     0xc9f1d0: add             x16, NULL, #0x20  ; true
    // 0xc9f1d4: r17 = false
    //     0xc9f1d4: add             x17, NULL, #0x30  ; false
    // 0xc9f1d8: csel            x2, x16, x17, eq
    // 0xc9f1dc: mov             x0, x2
    // 0xc9f1e0: b               #0xc9f1e8
    // 0xc9f1e4: r0 = false
    //     0xc9f1e4: add             x0, NULL, #0x30  ; false
    // 0xc9f1e8: ret
    //     0xc9f1e8: ret             
  }
}

// class id: 2056, size: 0x1c, field offset: 0x18
class TextParentData extends ContainerBoxParentData<RenderBox> {

  _ toString(/* No info */) {
    // ** addr: 0xae4634, size: 0x244
    // 0xae4634: EnterFrame
    //     0xae4634: stp             fp, lr, [SP, #-0x10]!
    //     0xae4638: mov             fp, SP
    // 0xae463c: AllocStack(0x18)
    //     0xae463c: sub             SP, SP, #0x18
    // 0xae4640: CheckStackOverflow
    //     0xae4640: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae4644: cmp             SP, x16
    //     0xae4648: b.ls            #0xae4868
    // 0xae464c: r1 = Null
    //     0xae464c: mov             x1, NULL
    // 0xae4650: r2 = 4
    //     0xae4650: mov             x2, #4
    // 0xae4654: r0 = AllocateArray()
    //     0xae4654: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae4658: r17 = "offset="
    //     0xae4658: add             x17, PP, #0xc, lsl #12  ; [pp+0xc7c0] "offset="
    //     0xae465c: ldr             x17, [x17, #0x7c0]
    // 0xae4660: StoreField: r0->field_f = r17
    //     0xae4660: stur            w17, [x0, #0xf]
    // 0xae4664: ldr             x1, [fp, #0x10]
    // 0xae4668: LoadField: r2 = r1->field_7
    //     0xae4668: ldur            w2, [x1, #7]
    // 0xae466c: DecompressPointer r2
    //     0xae466c: add             x2, x2, HEAP, lsl #32
    // 0xae4670: StoreField: r0->field_13 = r2
    //     0xae4670: stur            w2, [x0, #0x13]
    // 0xae4674: SaveReg r0
    //     0xae4674: str             x0, [SP, #-8]!
    // 0xae4678: r0 = _interpolate()
    //     0xae4678: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae467c: add             SP, SP, #8
    // 0xae4680: r1 = Null
    //     0xae4680: mov             x1, NULL
    // 0xae4684: r2 = 2
    //     0xae4684: mov             x2, #2
    // 0xae4688: stur            x0, [fp, #-8]
    // 0xae468c: r0 = AllocateArray()
    //     0xae468c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae4690: mov             x2, x0
    // 0xae4694: ldur            x0, [fp, #-8]
    // 0xae4698: stur            x2, [fp, #-0x10]
    // 0xae469c: StoreField: r2->field_f = r0
    //     0xae469c: stur            w0, [x2, #0xf]
    // 0xae46a0: r1 = <String>
    //     0xae46a0: ldr             x1, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xae46a4: r0 = AllocateGrowableArray()
    //     0xae46a4: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xae46a8: mov             x3, x0
    // 0xae46ac: ldur            x0, [fp, #-0x10]
    // 0xae46b0: stur            x3, [fp, #-0x18]
    // 0xae46b4: StoreField: r3->field_f = r0
    //     0xae46b4: stur            w0, [x3, #0xf]
    // 0xae46b8: r0 = 2
    //     0xae46b8: mov             x0, #2
    // 0xae46bc: StoreField: r3->field_b = r0
    //     0xae46bc: stur            w0, [x3, #0xb]
    // 0xae46c0: ldr             x0, [fp, #0x10]
    // 0xae46c4: LoadField: r4 = r0->field_17
    //     0xae46c4: ldur            w4, [x0, #0x17]
    // 0xae46c8: DecompressPointer r4
    //     0xae46c8: add             x4, x4, HEAP, lsl #32
    // 0xae46cc: stur            x4, [fp, #-8]
    // 0xae46d0: cmp             w4, NULL
    // 0xae46d4: b.eq            #0xae479c
    // 0xae46d8: r1 = Null
    //     0xae46d8: mov             x1, NULL
    // 0xae46dc: r2 = 4
    //     0xae46dc: mov             x2, #4
    // 0xae46e0: r0 = AllocateArray()
    //     0xae46e0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae46e4: r17 = "scale="
    //     0xae46e4: add             x17, PP, #0x29, lsl #12  ; [pp+0x290b0] "scale="
    //     0xae46e8: ldr             x17, [x17, #0xb0]
    // 0xae46ec: StoreField: r0->field_f = r17
    //     0xae46ec: stur            w17, [x0, #0xf]
    // 0xae46f0: ldur            x1, [fp, #-8]
    // 0xae46f4: StoreField: r0->field_13 = r1
    //     0xae46f4: stur            w1, [x0, #0x13]
    // 0xae46f8: SaveReg r0
    //     0xae46f8: str             x0, [SP, #-8]!
    // 0xae46fc: r0 = _interpolate()
    //     0xae46fc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae4700: add             SP, SP, #8
    // 0xae4704: mov             x1, x0
    // 0xae4708: ldur            x0, [fp, #-0x18]
    // 0xae470c: stur            x1, [fp, #-0x10]
    // 0xae4710: LoadField: r2 = r0->field_b
    //     0xae4710: ldur            w2, [x0, #0xb]
    // 0xae4714: DecompressPointer r2
    //     0xae4714: add             x2, x2, HEAP, lsl #32
    // 0xae4718: stur            x2, [fp, #-8]
    // 0xae471c: LoadField: r3 = r0->field_f
    //     0xae471c: ldur            w3, [x0, #0xf]
    // 0xae4720: DecompressPointer r3
    //     0xae4720: add             x3, x3, HEAP, lsl #32
    // 0xae4724: LoadField: r4 = r3->field_b
    //     0xae4724: ldur            w4, [x3, #0xb]
    // 0xae4728: DecompressPointer r4
    //     0xae4728: add             x4, x4, HEAP, lsl #32
    // 0xae472c: cmp             w2, w4
    // 0xae4730: b.ne            #0xae4740
    // 0xae4734: SaveReg r0
    //     0xae4734: str             x0, [SP, #-8]!
    // 0xae4738: r0 = _growToNextCapacity()
    //     0xae4738: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae473c: add             SP, SP, #8
    // 0xae4740: ldur            x0, [fp, #-8]
    // 0xae4744: ldur            x2, [fp, #-0x18]
    // 0xae4748: r3 = LoadInt32Instr(r0)
    //     0xae4748: sbfx            x3, x0, #1, #0x1f
    // 0xae474c: add             x0, x3, #1
    // 0xae4750: lsl             x1, x0, #1
    // 0xae4754: StoreField: r2->field_b = r1
    //     0xae4754: stur            w1, [x2, #0xb]
    // 0xae4758: mov             x1, x3
    // 0xae475c: cmp             x1, x0
    // 0xae4760: b.hs            #0xae4870
    // 0xae4764: LoadField: r1 = r2->field_f
    //     0xae4764: ldur            w1, [x2, #0xf]
    // 0xae4768: DecompressPointer r1
    //     0xae4768: add             x1, x1, HEAP, lsl #32
    // 0xae476c: ldur            x0, [fp, #-0x10]
    // 0xae4770: ArrayStore: r1[r3] = r0  ; List_4
    //     0xae4770: add             x25, x1, x3, lsl #2
    //     0xae4774: add             x25, x25, #0xf
    //     0xae4778: str             w0, [x25]
    //     0xae477c: tbz             w0, #0, #0xae4798
    //     0xae4780: ldurb           w16, [x1, #-1]
    //     0xae4784: ldurb           w17, [x0, #-1]
    //     0xae4788: and             x16, x17, x16, lsr #2
    //     0xae478c: tst             x16, HEAP, lsr #32
    //     0xae4790: b.eq            #0xae4798
    //     0xae4794: bl              #0xd67e5c
    // 0xae4798: b               #0xae47a0
    // 0xae479c: mov             x2, x3
    // 0xae47a0: ldr             x16, [fp, #0x10]
    // 0xae47a4: SaveReg r16
    //     0xae47a4: str             x16, [SP, #-8]!
    // 0xae47a8: r0 = toString()
    //     0xae47a8: bl              #0xae516c  ; [package:flutter/src/rendering/box.dart] BoxParentData::toString
    // 0xae47ac: add             SP, SP, #8
    // 0xae47b0: mov             x1, x0
    // 0xae47b4: ldur            x0, [fp, #-0x18]
    // 0xae47b8: stur            x1, [fp, #-0x10]
    // 0xae47bc: LoadField: r2 = r0->field_b
    //     0xae47bc: ldur            w2, [x0, #0xb]
    // 0xae47c0: DecompressPointer r2
    //     0xae47c0: add             x2, x2, HEAP, lsl #32
    // 0xae47c4: stur            x2, [fp, #-8]
    // 0xae47c8: LoadField: r3 = r0->field_f
    //     0xae47c8: ldur            w3, [x0, #0xf]
    // 0xae47cc: DecompressPointer r3
    //     0xae47cc: add             x3, x3, HEAP, lsl #32
    // 0xae47d0: LoadField: r4 = r3->field_b
    //     0xae47d0: ldur            w4, [x3, #0xb]
    // 0xae47d4: DecompressPointer r4
    //     0xae47d4: add             x4, x4, HEAP, lsl #32
    // 0xae47d8: cmp             w2, w4
    // 0xae47dc: b.ne            #0xae47ec
    // 0xae47e0: SaveReg r0
    //     0xae47e0: str             x0, [SP, #-8]!
    // 0xae47e4: r0 = _growToNextCapacity()
    //     0xae47e4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae47e8: add             SP, SP, #8
    // 0xae47ec: ldur            x0, [fp, #-8]
    // 0xae47f0: ldur            x2, [fp, #-0x18]
    // 0xae47f4: r3 = LoadInt32Instr(r0)
    //     0xae47f4: sbfx            x3, x0, #1, #0x1f
    // 0xae47f8: add             x0, x3, #1
    // 0xae47fc: lsl             x1, x0, #1
    // 0xae4800: StoreField: r2->field_b = r1
    //     0xae4800: stur            w1, [x2, #0xb]
    // 0xae4804: mov             x1, x3
    // 0xae4808: cmp             x1, x0
    // 0xae480c: b.hs            #0xae4874
    // 0xae4810: LoadField: r1 = r2->field_f
    //     0xae4810: ldur            w1, [x2, #0xf]
    // 0xae4814: DecompressPointer r1
    //     0xae4814: add             x1, x1, HEAP, lsl #32
    // 0xae4818: ldur            x0, [fp, #-0x10]
    // 0xae481c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xae481c: add             x25, x1, x3, lsl #2
    //     0xae4820: add             x25, x25, #0xf
    //     0xae4824: str             w0, [x25]
    //     0xae4828: tbz             w0, #0, #0xae4844
    //     0xae482c: ldurb           w16, [x1, #-1]
    //     0xae4830: ldurb           w17, [x0, #-1]
    //     0xae4834: and             x16, x17, x16, lsr #2
    //     0xae4838: tst             x16, HEAP, lsr #32
    //     0xae483c: b.eq            #0xae4844
    //     0xae4840: bl              #0xd67e5c
    // 0xae4844: r16 = "; "
    //     0xae4844: add             x16, PP, #0x1b, lsl #12  ; [pp+0x1bca8] "; "
    //     0xae4848: ldr             x16, [x16, #0xca8]
    // 0xae484c: stp             x16, x2, [SP, #-0x10]!
    // 0xae4850: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xae4850: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xae4854: r0 = join()
    //     0xae4854: bl              #0x6fddb0  ; [dart:core] _GrowableList::join
    // 0xae4858: add             SP, SP, #0x10
    // 0xae485c: LeaveFrame
    //     0xae485c: mov             SP, fp
    //     0xae4860: ldp             fp, lr, [SP], #0x10
    // 0xae4864: ret
    //     0xae4864: ret             
    // 0xae4868: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae4868: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae486c: b               #0xae464c
    // 0xae4870: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae4870: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xae4874: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae4874: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 2531, size: 0x70, field offset: 0x60
//   transformed mixin,
abstract class _RenderParagraph&RenderBox&ContainerRenderObjectMixin extends RenderBox
     with ContainerRenderObjectMixin<X0 bound RenderObject, X1 bound ContainerParentDataMixin<X0 bound RenderObject>> {

  _ move(/* No info */) {
    // ** addr: 0x5adef8, size: 0x208
    // 0x5adef8: EnterFrame
    //     0x5adef8: stp             fp, lr, [SP, #-0x10]!
    //     0x5adefc: mov             fp, SP
    // 0x5adf00: AllocStack(0x8)
    //     0x5adf00: sub             SP, SP, #8
    // 0x5adf04: CheckStackOverflow
    //     0x5adf04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5adf08: cmp             SP, x16
    //     0x5adf0c: b.ls            #0x5ae0f4
    // 0x5adf10: ldr             x0, [fp, #0x18]
    // 0x5adf14: r2 = Null
    //     0x5adf14: mov             x2, NULL
    // 0x5adf18: r1 = Null
    //     0x5adf18: mov             x1, NULL
    // 0x5adf1c: r4 = 59
    //     0x5adf1c: mov             x4, #0x3b
    // 0x5adf20: branchIfSmi(r0, 0x5adf2c)
    //     0x5adf20: tbz             w0, #0, #0x5adf2c
    // 0x5adf24: r4 = LoadClassIdInstr(r0)
    //     0x5adf24: ldur            x4, [x0, #-1]
    //     0x5adf28: ubfx            x4, x4, #0xc, #0x14
    // 0x5adf2c: sub             x4, x4, #0x965
    // 0x5adf30: cmp             x4, #0x8b
    // 0x5adf34: b.ls            #0x5adf4c
    // 0x5adf38: r8 = RenderBox
    //     0x5adf38: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x5adf3c: ldr             x8, [x8, #0xfa0]
    // 0x5adf40: r3 = Null
    //     0x5adf40: add             x3, PP, #0x22, lsl #12  ; [pp+0x22520] Null
    //     0x5adf44: ldr             x3, [x3, #0x520]
    // 0x5adf48: r0 = RenderBox()
    //     0x5adf48: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x5adf4c: ldr             x0, [fp, #0x10]
    // 0x5adf50: r2 = Null
    //     0x5adf50: mov             x2, NULL
    // 0x5adf54: r1 = Null
    //     0x5adf54: mov             x1, NULL
    // 0x5adf58: r4 = 59
    //     0x5adf58: mov             x4, #0x3b
    // 0x5adf5c: branchIfSmi(r0, 0x5adf68)
    //     0x5adf5c: tbz             w0, #0, #0x5adf68
    // 0x5adf60: r4 = LoadClassIdInstr(r0)
    //     0x5adf60: ldur            x4, [x0, #-1]
    //     0x5adf64: ubfx            x4, x4, #0xc, #0x14
    // 0x5adf68: sub             x4, x4, #0x965
    // 0x5adf6c: cmp             x4, #0x8b
    // 0x5adf70: b.ls            #0x5adf84
    // 0x5adf74: r8 = RenderBox?
    //     0x5adf74: ldr             x8, [PP, #0x4de8]  ; [pp+0x4de8] Type: RenderBox?
    // 0x5adf78: r3 = Null
    //     0x5adf78: add             x3, PP, #0x22, lsl #12  ; [pp+0x22530] Null
    //     0x5adf7c: ldr             x3, [x3, #0x530]
    // 0x5adf80: r0 = RenderBox?()
    //     0x5adf80: bl              #0x5ad534  ; IsType_RenderBox?_Stub
    // 0x5adf84: ldr             x3, [fp, #0x18]
    // 0x5adf88: LoadField: r4 = r3->field_17
    //     0x5adf88: ldur            w4, [x3, #0x17]
    // 0x5adf8c: DecompressPointer r4
    //     0x5adf8c: add             x4, x4, HEAP, lsl #32
    // 0x5adf90: stur            x4, [fp, #-8]
    // 0x5adf94: cmp             w4, NULL
    // 0x5adf98: b.eq            #0x5ae0fc
    // 0x5adf9c: mov             x0, x4
    // 0x5adfa0: r2 = Null
    //     0x5adfa0: mov             x2, NULL
    // 0x5adfa4: r1 = Null
    //     0x5adfa4: mov             x1, NULL
    // 0x5adfa8: r4 = LoadClassIdInstr(r0)
    //     0x5adfa8: ldur            x4, [x0, #-1]
    //     0x5adfac: ubfx            x4, x4, #0xc, #0x14
    // 0x5adfb0: cmp             x4, #0x808
    // 0x5adfb4: b.eq            #0x5adfcc
    // 0x5adfb8: r8 = TextParentData<RenderBox>
    //     0x5adfb8: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x5adfbc: ldr             x8, [x8, #0x298]
    // 0x5adfc0: r3 = Null
    //     0x5adfc0: add             x3, PP, #0x22, lsl #12  ; [pp+0x22540] Null
    //     0x5adfc4: ldr             x3, [x3, #0x540]
    // 0x5adfc8: r0 = DefaultTypeTest()
    //     0x5adfc8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5adfcc: ldur            x0, [fp, #-8]
    // 0x5adfd0: LoadField: r1 = r0->field_f
    //     0x5adfd0: ldur            w1, [x0, #0xf]
    // 0x5adfd4: DecompressPointer r1
    //     0x5adfd4: add             x1, x1, HEAP, lsl #32
    // 0x5adfd8: r0 = LoadClassIdInstr(r1)
    //     0x5adfd8: ldur            x0, [x1, #-1]
    //     0x5adfdc: ubfx            x0, x0, #0xc, #0x14
    // 0x5adfe0: ldr             x16, [fp, #0x10]
    // 0x5adfe4: stp             x16, x1, [SP, #-0x10]!
    // 0x5adfe8: mov             lr, x0
    // 0x5adfec: ldr             lr, [x21, lr, lsl #3]
    // 0x5adff0: blr             lr
    // 0x5adff4: add             SP, SP, #0x10
    // 0x5adff8: tbnz            w0, #4, #0x5ae00c
    // 0x5adffc: r0 = Null
    //     0x5adffc: mov             x0, NULL
    // 0x5ae000: LeaveFrame
    //     0x5ae000: mov             SP, fp
    //     0x5ae004: ldp             fp, lr, [SP], #0x10
    // 0x5ae008: ret
    //     0x5ae008: ret             
    // 0x5ae00c: ldr             x0, [fp, #0x20]
    // 0x5ae010: ldr             x16, [fp, #0x18]
    // 0x5ae014: stp             x16, x0, [SP, #-0x10]!
    // 0x5ae018: r0 = _removeFromChildList()
    //     0x5ae018: bl              #0x5ae8ac  ; [package:flutter/src/rendering/paragraph.dart] _RenderParagraph&RenderBox&ContainerRenderObjectMixin::_removeFromChildList
    // 0x5ae01c: add             SP, SP, #0x10
    // 0x5ae020: ldr             x16, [fp, #0x20]
    // 0x5ae024: ldr             lr, [fp, #0x18]
    // 0x5ae028: stp             lr, x16, [SP, #-0x10]!
    // 0x5ae02c: ldr             x16, [fp, #0x10]
    // 0x5ae030: SaveReg r16
    //     0x5ae030: str             x16, [SP, #-8]!
    // 0x5ae034: r0 = _insertIntoChildList()
    //     0x5ae034: bl              #0x5ae34c  ; [package:flutter/src/rendering/paragraph.dart] _RenderParagraph&RenderBox&ContainerRenderObjectMixin::_insertIntoChildList
    // 0x5ae038: add             SP, SP, #0x18
    // 0x5ae03c: ldr             x0, [fp, #0x20]
    // 0x5ae040: r1 = LoadClassIdInstr(r0)
    //     0x5ae040: ldur            x1, [x0, #-1]
    //     0x5ae044: ubfx            x1, x1, #0xc, #0x14
    // 0x5ae048: lsl             x1, x1, #1
    // 0x5ae04c: r17 = 5074
    //     0x5ae04c: mov             x17, #0x13d2
    // 0x5ae050: cmp             w1, w17
    // 0x5ae054: b.ne            #0x5ae0c0
    // 0x5ae058: SaveReg r0
    //     0x5ae058: str             x0, [SP, #-8]!
    // 0x5ae05c: r0 = _clearCachedData()
    //     0x5ae05c: bl              #0x5ae21c  ; [package:flutter/src/rendering/box.dart] RenderBox::_clearCachedData
    // 0x5ae060: add             SP, SP, #8
    // 0x5ae064: tbnz            w0, #4, #0x5ae0ac
    // 0x5ae068: ldr             x16, [fp, #0x20]
    // 0x5ae06c: SaveReg r16
    //     0x5ae06c: str             x16, [SP, #-8]!
    // 0x5ae070: r0 = _function()
    //     0x5ae070: bl              #0xd60f38  ; [dart:core] _Closure::_function
    // 0x5ae074: add             SP, SP, #8
    // 0x5ae078: r1 = LoadClassIdInstr(r0)
    //     0x5ae078: ldur            x1, [x0, #-1]
    //     0x5ae07c: ubfx            x1, x1, #0xc, #0x14
    // 0x5ae080: lsl             x1, x1, #1
    // 0x5ae084: r0 = LoadInt32Instr(r1)
    //     0x5ae084: sbfx            x0, x1, #1, #0x1f
    // 0x5ae088: cmp             x0, #0x961
    // 0x5ae08c: b.lt            #0x5ae0ac
    // 0x5ae090: cmp             x0, #0xa1f
    // 0x5ae094: b.gt            #0x5ae0ac
    // 0x5ae098: ldr             x16, [fp, #0x20]
    // 0x5ae09c: SaveReg r16
    //     0x5ae09c: str             x16, [SP, #-8]!
    // 0x5ae0a0: r0 = markParentNeedsLayout()
    //     0x5ae0a0: bl              #0x5ae148  ; [package:flutter/src/rendering/object.dart] RenderObject::markParentNeedsLayout
    // 0x5ae0a4: add             SP, SP, #8
    // 0x5ae0a8: b               #0x5ae0e4
    // 0x5ae0ac: ldr             x16, [fp, #0x20]
    // 0x5ae0b0: SaveReg r16
    //     0x5ae0b0: str             x16, [SP, #-8]!
    // 0x5ae0b4: r0 = markNeedsLayout()
    //     0x5ae0b4: bl              #0x6c0ee8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsLayout
    // 0x5ae0b8: add             SP, SP, #8
    // 0x5ae0bc: b               #0x5ae0e4
    // 0x5ae0c0: r1 = LoadClassIdInstr(r0)
    //     0x5ae0c0: ldur            x1, [x0, #-1]
    //     0x5ae0c4: ubfx            x1, x1, #0xc, #0x14
    // 0x5ae0c8: SaveReg r0
    //     0x5ae0c8: str             x0, [SP, #-8]!
    // 0x5ae0cc: mov             x0, x1
    // 0x5ae0d0: r0 = GDT[cid_x0 + 0xcfc6]()
    //     0x5ae0d0: mov             x17, #0xcfc6
    //     0x5ae0d4: add             lr, x0, x17
    //     0x5ae0d8: ldr             lr, [x21, lr, lsl #3]
    //     0x5ae0dc: blr             lr
    // 0x5ae0e0: add             SP, SP, #8
    // 0x5ae0e4: r0 = Null
    //     0x5ae0e4: mov             x0, NULL
    // 0x5ae0e8: LeaveFrame
    //     0x5ae0e8: mov             SP, fp
    //     0x5ae0ec: ldp             fp, lr, [SP], #0x10
    // 0x5ae0f0: ret
    //     0x5ae0f0: ret             
    // 0x5ae0f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5ae0f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5ae0f8: b               #0x5adf10
    // 0x5ae0fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5ae0fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _insertIntoChildList(/* No info */) {
    // ** addr: 0x5ae34c, size: 0x560
    // 0x5ae34c: EnterFrame
    //     0x5ae34c: stp             fp, lr, [SP, #-0x10]!
    //     0x5ae350: mov             fp, SP
    // 0x5ae354: AllocStack(0x20)
    //     0x5ae354: sub             SP, SP, #0x20
    // 0x5ae358: ldr             x3, [fp, #0x18]
    // 0x5ae35c: LoadField: r4 = r3->field_17
    //     0x5ae35c: ldur            w4, [x3, #0x17]
    // 0x5ae360: DecompressPointer r4
    //     0x5ae360: add             x4, x4, HEAP, lsl #32
    // 0x5ae364: stur            x4, [fp, #-8]
    // 0x5ae368: cmp             w4, NULL
    // 0x5ae36c: b.eq            #0x5ae89c
    // 0x5ae370: mov             x0, x4
    // 0x5ae374: r2 = Null
    //     0x5ae374: mov             x2, NULL
    // 0x5ae378: r1 = Null
    //     0x5ae378: mov             x1, NULL
    // 0x5ae37c: r4 = LoadClassIdInstr(r0)
    //     0x5ae37c: ldur            x4, [x0, #-1]
    //     0x5ae380: ubfx            x4, x4, #0xc, #0x14
    // 0x5ae384: cmp             x4, #0x808
    // 0x5ae388: b.eq            #0x5ae3a0
    // 0x5ae38c: r8 = TextParentData<RenderBox>
    //     0x5ae38c: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x5ae390: ldr             x8, [x8, #0x298]
    // 0x5ae394: r3 = Null
    //     0x5ae394: add             x3, PP, #0x22, lsl #12  ; [pp+0x22550] Null
    //     0x5ae398: ldr             x3, [x3, #0x550]
    // 0x5ae39c: r0 = DefaultTypeTest()
    //     0x5ae39c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5ae3a0: ldr             x3, [fp, #0x20]
    // 0x5ae3a4: LoadField: r0 = r3->field_5f
    //     0x5ae3a4: ldur            x0, [x3, #0x5f]
    // 0x5ae3a8: add             x1, x0, #1
    // 0x5ae3ac: StoreField: r3->field_5f = r1
    //     0x5ae3ac: stur            x1, [x3, #0x5f]
    // 0x5ae3b0: ldr             x4, [fp, #0x10]
    // 0x5ae3b4: cmp             w4, NULL
    // 0x5ae3b8: b.ne            #0x5ae540
    // 0x5ae3bc: ldur            x4, [fp, #-8]
    // 0x5ae3c0: LoadField: r5 = r3->field_67
    //     0x5ae3c0: ldur            w5, [x3, #0x67]
    // 0x5ae3c4: DecompressPointer r5
    //     0x5ae3c4: add             x5, x5, HEAP, lsl #32
    // 0x5ae3c8: stur            x5, [fp, #-0x10]
    // 0x5ae3cc: LoadField: r2 = r4->field_b
    //     0x5ae3cc: ldur            w2, [x4, #0xb]
    // 0x5ae3d0: DecompressPointer r2
    //     0x5ae3d0: add             x2, x2, HEAP, lsl #32
    // 0x5ae3d4: mov             x0, x5
    // 0x5ae3d8: r1 = Null
    //     0x5ae3d8: mov             x1, NULL
    // 0x5ae3dc: cmp             w0, NULL
    // 0x5ae3e0: b.eq            #0x5ae40c
    // 0x5ae3e4: cmp             w2, NULL
    // 0x5ae3e8: b.eq            #0x5ae40c
    // 0x5ae3ec: LoadField: r4 = r2->field_17
    //     0x5ae3ec: ldur            w4, [x2, #0x17]
    // 0x5ae3f0: DecompressPointer r4
    //     0x5ae3f0: add             x4, x4, HEAP, lsl #32
    // 0x5ae3f4: r8 = X0? bound RenderObject
    //     0x5ae3f4: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5ae3f8: ldr             x8, [x8, #0x6e8]
    // 0x5ae3fc: LoadField: r9 = r4->field_7
    //     0x5ae3fc: ldur            x9, [x4, #7]
    // 0x5ae400: r3 = Null
    //     0x5ae400: add             x3, PP, #0x22, lsl #12  ; [pp+0x22560] Null
    //     0x5ae404: ldr             x3, [x3, #0x560]
    // 0x5ae408: blr             x9
    // 0x5ae40c: ldur            x0, [fp, #-0x10]
    // 0x5ae410: ldur            x3, [fp, #-8]
    // 0x5ae414: StoreField: r3->field_13 = r0
    //     0x5ae414: stur            w0, [x3, #0x13]
    //     0x5ae418: ldurb           w16, [x3, #-1]
    //     0x5ae41c: ldurb           w17, [x0, #-1]
    //     0x5ae420: and             x16, x17, x16, lsr #2
    //     0x5ae424: tst             x16, HEAP, lsr #32
    //     0x5ae428: b.eq            #0x5ae430
    //     0x5ae42c: bl              #0xd682ac
    // 0x5ae430: ldur            x0, [fp, #-0x10]
    // 0x5ae434: cmp             w0, NULL
    // 0x5ae438: b.eq            #0x5ae4e8
    // 0x5ae43c: LoadField: r3 = r0->field_17
    //     0x5ae43c: ldur            w3, [x0, #0x17]
    // 0x5ae440: DecompressPointer r3
    //     0x5ae440: add             x3, x3, HEAP, lsl #32
    // 0x5ae444: stur            x3, [fp, #-0x18]
    // 0x5ae448: cmp             w3, NULL
    // 0x5ae44c: b.eq            #0x5ae8a0
    // 0x5ae450: mov             x0, x3
    // 0x5ae454: r2 = Null
    //     0x5ae454: mov             x2, NULL
    // 0x5ae458: r1 = Null
    //     0x5ae458: mov             x1, NULL
    // 0x5ae45c: r4 = LoadClassIdInstr(r0)
    //     0x5ae45c: ldur            x4, [x0, #-1]
    //     0x5ae460: ubfx            x4, x4, #0xc, #0x14
    // 0x5ae464: cmp             x4, #0x808
    // 0x5ae468: b.eq            #0x5ae480
    // 0x5ae46c: r8 = TextParentData<RenderBox>
    //     0x5ae46c: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x5ae470: ldr             x8, [x8, #0x298]
    // 0x5ae474: r3 = Null
    //     0x5ae474: add             x3, PP, #0x22, lsl #12  ; [pp+0x22570] Null
    //     0x5ae478: ldr             x3, [x3, #0x570]
    // 0x5ae47c: r0 = DefaultTypeTest()
    //     0x5ae47c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5ae480: ldur            x3, [fp, #-0x18]
    // 0x5ae484: LoadField: r2 = r3->field_b
    //     0x5ae484: ldur            w2, [x3, #0xb]
    // 0x5ae488: DecompressPointer r2
    //     0x5ae488: add             x2, x2, HEAP, lsl #32
    // 0x5ae48c: ldr             x0, [fp, #0x18]
    // 0x5ae490: r1 = Null
    //     0x5ae490: mov             x1, NULL
    // 0x5ae494: cmp             w0, NULL
    // 0x5ae498: b.eq            #0x5ae4c4
    // 0x5ae49c: cmp             w2, NULL
    // 0x5ae4a0: b.eq            #0x5ae4c4
    // 0x5ae4a4: LoadField: r4 = r2->field_17
    //     0x5ae4a4: ldur            w4, [x2, #0x17]
    // 0x5ae4a8: DecompressPointer r4
    //     0x5ae4a8: add             x4, x4, HEAP, lsl #32
    // 0x5ae4ac: r8 = X0? bound RenderObject
    //     0x5ae4ac: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5ae4b0: ldr             x8, [x8, #0x6e8]
    // 0x5ae4b4: LoadField: r9 = r4->field_7
    //     0x5ae4b4: ldur            x9, [x4, #7]
    // 0x5ae4b8: r3 = Null
    //     0x5ae4b8: add             x3, PP, #0x22, lsl #12  ; [pp+0x22580] Null
    //     0x5ae4bc: ldr             x3, [x3, #0x580]
    // 0x5ae4c0: blr             x9
    // 0x5ae4c4: ldr             x0, [fp, #0x18]
    // 0x5ae4c8: ldur            x1, [fp, #-0x18]
    // 0x5ae4cc: StoreField: r1->field_f = r0
    //     0x5ae4cc: stur            w0, [x1, #0xf]
    //     0x5ae4d0: ldurb           w16, [x1, #-1]
    //     0x5ae4d4: ldurb           w17, [x0, #-1]
    //     0x5ae4d8: and             x16, x17, x16, lsr #2
    //     0x5ae4dc: tst             x16, HEAP, lsr #32
    //     0x5ae4e0: b.eq            #0x5ae4e8
    //     0x5ae4e4: bl              #0xd6826c
    // 0x5ae4e8: ldr             x5, [fp, #0x20]
    // 0x5ae4ec: ldr             x0, [fp, #0x18]
    // 0x5ae4f0: StoreField: r5->field_67 = r0
    //     0x5ae4f0: stur            w0, [x5, #0x67]
    //     0x5ae4f4: ldurb           w16, [x5, #-1]
    //     0x5ae4f8: ldurb           w17, [x0, #-1]
    //     0x5ae4fc: and             x16, x17, x16, lsr #2
    //     0x5ae500: tst             x16, HEAP, lsr #32
    //     0x5ae504: b.eq            #0x5ae50c
    //     0x5ae508: bl              #0xd682ec
    // 0x5ae50c: LoadField: r0 = r5->field_6b
    //     0x5ae50c: ldur            w0, [x5, #0x6b]
    // 0x5ae510: DecompressPointer r0
    //     0x5ae510: add             x0, x0, HEAP, lsl #32
    // 0x5ae514: cmp             w0, NULL
    // 0x5ae518: b.ne            #0x5ae88c
    // 0x5ae51c: ldr             x0, [fp, #0x18]
    // 0x5ae520: StoreField: r5->field_6b = r0
    //     0x5ae520: stur            w0, [x5, #0x6b]
    //     0x5ae524: ldurb           w16, [x5, #-1]
    //     0x5ae528: ldurb           w17, [x0, #-1]
    //     0x5ae52c: and             x16, x17, x16, lsr #2
    //     0x5ae530: tst             x16, HEAP, lsr #32
    //     0x5ae534: b.eq            #0x5ae53c
    //     0x5ae538: bl              #0xd682ec
    // 0x5ae53c: b               #0x5ae88c
    // 0x5ae540: mov             x5, x3
    // 0x5ae544: ldur            x3, [fp, #-8]
    // 0x5ae548: LoadField: r6 = r4->field_17
    //     0x5ae548: ldur            w6, [x4, #0x17]
    // 0x5ae54c: DecompressPointer r6
    //     0x5ae54c: add             x6, x6, HEAP, lsl #32
    // 0x5ae550: stur            x6, [fp, #-0x10]
    // 0x5ae554: cmp             w6, NULL
    // 0x5ae558: b.eq            #0x5ae8a4
    // 0x5ae55c: mov             x0, x6
    // 0x5ae560: r2 = Null
    //     0x5ae560: mov             x2, NULL
    // 0x5ae564: r1 = Null
    //     0x5ae564: mov             x1, NULL
    // 0x5ae568: r4 = LoadClassIdInstr(r0)
    //     0x5ae568: ldur            x4, [x0, #-1]
    //     0x5ae56c: ubfx            x4, x4, #0xc, #0x14
    // 0x5ae570: cmp             x4, #0x808
    // 0x5ae574: b.eq            #0x5ae58c
    // 0x5ae578: r8 = TextParentData<RenderBox>
    //     0x5ae578: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x5ae57c: ldr             x8, [x8, #0x298]
    // 0x5ae580: r3 = Null
    //     0x5ae580: add             x3, PP, #0x22, lsl #12  ; [pp+0x22590] Null
    //     0x5ae584: ldr             x3, [x3, #0x590]
    // 0x5ae588: r0 = DefaultTypeTest()
    //     0x5ae588: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5ae58c: ldur            x3, [fp, #-0x10]
    // 0x5ae590: LoadField: r4 = r3->field_13
    //     0x5ae590: ldur            w4, [x3, #0x13]
    // 0x5ae594: DecompressPointer r4
    //     0x5ae594: add             x4, x4, HEAP, lsl #32
    // 0x5ae598: stur            x4, [fp, #-0x20]
    // 0x5ae59c: cmp             w4, NULL
    // 0x5ae5a0: b.ne            #0x5ae6a0
    // 0x5ae5a4: ldr             x5, [fp, #0x20]
    // 0x5ae5a8: ldur            x4, [fp, #-8]
    // 0x5ae5ac: LoadField: r2 = r4->field_b
    //     0x5ae5ac: ldur            w2, [x4, #0xb]
    // 0x5ae5b0: DecompressPointer r2
    //     0x5ae5b0: add             x2, x2, HEAP, lsl #32
    // 0x5ae5b4: ldr             x0, [fp, #0x10]
    // 0x5ae5b8: r1 = Null
    //     0x5ae5b8: mov             x1, NULL
    // 0x5ae5bc: cmp             w0, NULL
    // 0x5ae5c0: b.eq            #0x5ae5ec
    // 0x5ae5c4: cmp             w2, NULL
    // 0x5ae5c8: b.eq            #0x5ae5ec
    // 0x5ae5cc: LoadField: r4 = r2->field_17
    //     0x5ae5cc: ldur            w4, [x2, #0x17]
    // 0x5ae5d0: DecompressPointer r4
    //     0x5ae5d0: add             x4, x4, HEAP, lsl #32
    // 0x5ae5d4: r8 = X0? bound RenderObject
    //     0x5ae5d4: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5ae5d8: ldr             x8, [x8, #0x6e8]
    // 0x5ae5dc: LoadField: r9 = r4->field_7
    //     0x5ae5dc: ldur            x9, [x4, #7]
    // 0x5ae5e0: r3 = Null
    //     0x5ae5e0: add             x3, PP, #0x22, lsl #12  ; [pp+0x225a0] Null
    //     0x5ae5e4: ldr             x3, [x3, #0x5a0]
    // 0x5ae5e8: blr             x9
    // 0x5ae5ec: ldr             x0, [fp, #0x10]
    // 0x5ae5f0: ldur            x3, [fp, #-8]
    // 0x5ae5f4: StoreField: r3->field_f = r0
    //     0x5ae5f4: stur            w0, [x3, #0xf]
    //     0x5ae5f8: ldurb           w16, [x3, #-1]
    //     0x5ae5fc: ldurb           w17, [x0, #-1]
    //     0x5ae600: and             x16, x17, x16, lsr #2
    //     0x5ae604: tst             x16, HEAP, lsr #32
    //     0x5ae608: b.eq            #0x5ae610
    //     0x5ae60c: bl              #0xd682ac
    // 0x5ae610: ldur            x3, [fp, #-0x10]
    // 0x5ae614: LoadField: r2 = r3->field_b
    //     0x5ae614: ldur            w2, [x3, #0xb]
    // 0x5ae618: DecompressPointer r2
    //     0x5ae618: add             x2, x2, HEAP, lsl #32
    // 0x5ae61c: ldr             x0, [fp, #0x18]
    // 0x5ae620: r1 = Null
    //     0x5ae620: mov             x1, NULL
    // 0x5ae624: cmp             w0, NULL
    // 0x5ae628: b.eq            #0x5ae654
    // 0x5ae62c: cmp             w2, NULL
    // 0x5ae630: b.eq            #0x5ae654
    // 0x5ae634: LoadField: r4 = r2->field_17
    //     0x5ae634: ldur            w4, [x2, #0x17]
    // 0x5ae638: DecompressPointer r4
    //     0x5ae638: add             x4, x4, HEAP, lsl #32
    // 0x5ae63c: r8 = X0? bound RenderObject
    //     0x5ae63c: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5ae640: ldr             x8, [x8, #0x6e8]
    // 0x5ae644: LoadField: r9 = r4->field_7
    //     0x5ae644: ldur            x9, [x4, #7]
    // 0x5ae648: r3 = Null
    //     0x5ae648: add             x3, PP, #0x22, lsl #12  ; [pp+0x225b0] Null
    //     0x5ae64c: ldr             x3, [x3, #0x5b0]
    // 0x5ae650: blr             x9
    // 0x5ae654: ldr             x0, [fp, #0x18]
    // 0x5ae658: ldur            x5, [fp, #-0x10]
    // 0x5ae65c: StoreField: r5->field_13 = r0
    //     0x5ae65c: stur            w0, [x5, #0x13]
    //     0x5ae660: ldurb           w16, [x5, #-1]
    //     0x5ae664: ldurb           w17, [x0, #-1]
    //     0x5ae668: and             x16, x17, x16, lsr #2
    //     0x5ae66c: tst             x16, HEAP, lsr #32
    //     0x5ae670: b.eq            #0x5ae678
    //     0x5ae674: bl              #0xd682ec
    // 0x5ae678: ldr             x0, [fp, #0x18]
    // 0x5ae67c: ldr             x1, [fp, #0x20]
    // 0x5ae680: StoreField: r1->field_6b = r0
    //     0x5ae680: stur            w0, [x1, #0x6b]
    //     0x5ae684: ldurb           w16, [x1, #-1]
    //     0x5ae688: ldurb           w17, [x0, #-1]
    //     0x5ae68c: and             x16, x17, x16, lsr #2
    //     0x5ae690: tst             x16, HEAP, lsr #32
    //     0x5ae694: b.eq            #0x5ae69c
    //     0x5ae698: bl              #0xd6826c
    // 0x5ae69c: b               #0x5ae88c
    // 0x5ae6a0: mov             x5, x3
    // 0x5ae6a4: ldur            x3, [fp, #-8]
    // 0x5ae6a8: LoadField: r6 = r3->field_b
    //     0x5ae6a8: ldur            w6, [x3, #0xb]
    // 0x5ae6ac: DecompressPointer r6
    //     0x5ae6ac: add             x6, x6, HEAP, lsl #32
    // 0x5ae6b0: mov             x0, x4
    // 0x5ae6b4: mov             x2, x6
    // 0x5ae6b8: stur            x6, [fp, #-0x18]
    // 0x5ae6bc: r1 = Null
    //     0x5ae6bc: mov             x1, NULL
    // 0x5ae6c0: cmp             w0, NULL
    // 0x5ae6c4: b.eq            #0x5ae6f0
    // 0x5ae6c8: cmp             w2, NULL
    // 0x5ae6cc: b.eq            #0x5ae6f0
    // 0x5ae6d0: LoadField: r4 = r2->field_17
    //     0x5ae6d0: ldur            w4, [x2, #0x17]
    // 0x5ae6d4: DecompressPointer r4
    //     0x5ae6d4: add             x4, x4, HEAP, lsl #32
    // 0x5ae6d8: r8 = X0? bound RenderObject
    //     0x5ae6d8: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5ae6dc: ldr             x8, [x8, #0x6e8]
    // 0x5ae6e0: LoadField: r9 = r4->field_7
    //     0x5ae6e0: ldur            x9, [x4, #7]
    // 0x5ae6e4: r3 = Null
    //     0x5ae6e4: add             x3, PP, #0x22, lsl #12  ; [pp+0x225c0] Null
    //     0x5ae6e8: ldr             x3, [x3, #0x5c0]
    // 0x5ae6ec: blr             x9
    // 0x5ae6f0: ldur            x0, [fp, #-0x20]
    // 0x5ae6f4: ldur            x3, [fp, #-8]
    // 0x5ae6f8: StoreField: r3->field_13 = r0
    //     0x5ae6f8: stur            w0, [x3, #0x13]
    //     0x5ae6fc: ldurb           w16, [x3, #-1]
    //     0x5ae700: ldurb           w17, [x0, #-1]
    //     0x5ae704: and             x16, x17, x16, lsr #2
    //     0x5ae708: tst             x16, HEAP, lsr #32
    //     0x5ae70c: b.eq            #0x5ae714
    //     0x5ae710: bl              #0xd682ac
    // 0x5ae714: ldr             x0, [fp, #0x10]
    // 0x5ae718: ldur            x2, [fp, #-0x18]
    // 0x5ae71c: r1 = Null
    //     0x5ae71c: mov             x1, NULL
    // 0x5ae720: cmp             w0, NULL
    // 0x5ae724: b.eq            #0x5ae750
    // 0x5ae728: cmp             w2, NULL
    // 0x5ae72c: b.eq            #0x5ae750
    // 0x5ae730: LoadField: r4 = r2->field_17
    //     0x5ae730: ldur            w4, [x2, #0x17]
    // 0x5ae734: DecompressPointer r4
    //     0x5ae734: add             x4, x4, HEAP, lsl #32
    // 0x5ae738: r8 = X0? bound RenderObject
    //     0x5ae738: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5ae73c: ldr             x8, [x8, #0x6e8]
    // 0x5ae740: LoadField: r9 = r4->field_7
    //     0x5ae740: ldur            x9, [x4, #7]
    // 0x5ae744: r3 = Null
    //     0x5ae744: add             x3, PP, #0x22, lsl #12  ; [pp+0x225d0] Null
    //     0x5ae748: ldr             x3, [x3, #0x5d0]
    // 0x5ae74c: blr             x9
    // 0x5ae750: ldr             x0, [fp, #0x10]
    // 0x5ae754: ldur            x1, [fp, #-8]
    // 0x5ae758: StoreField: r1->field_f = r0
    //     0x5ae758: stur            w0, [x1, #0xf]
    //     0x5ae75c: ldurb           w16, [x1, #-1]
    //     0x5ae760: ldurb           w17, [x0, #-1]
    //     0x5ae764: and             x16, x17, x16, lsr #2
    //     0x5ae768: tst             x16, HEAP, lsr #32
    //     0x5ae76c: b.eq            #0x5ae774
    //     0x5ae770: bl              #0xd6826c
    // 0x5ae774: ldur            x0, [fp, #-0x20]
    // 0x5ae778: LoadField: r3 = r0->field_17
    //     0x5ae778: ldur            w3, [x0, #0x17]
    // 0x5ae77c: DecompressPointer r3
    //     0x5ae77c: add             x3, x3, HEAP, lsl #32
    // 0x5ae780: stur            x3, [fp, #-8]
    // 0x5ae784: cmp             w3, NULL
    // 0x5ae788: b.eq            #0x5ae8a8
    // 0x5ae78c: mov             x0, x3
    // 0x5ae790: r2 = Null
    //     0x5ae790: mov             x2, NULL
    // 0x5ae794: r1 = Null
    //     0x5ae794: mov             x1, NULL
    // 0x5ae798: r4 = LoadClassIdInstr(r0)
    //     0x5ae798: ldur            x4, [x0, #-1]
    //     0x5ae79c: ubfx            x4, x4, #0xc, #0x14
    // 0x5ae7a0: cmp             x4, #0x808
    // 0x5ae7a4: b.eq            #0x5ae7bc
    // 0x5ae7a8: r8 = TextParentData<RenderBox>
    //     0x5ae7a8: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x5ae7ac: ldr             x8, [x8, #0x298]
    // 0x5ae7b0: r3 = Null
    //     0x5ae7b0: add             x3, PP, #0x22, lsl #12  ; [pp+0x225e0] Null
    //     0x5ae7b4: ldr             x3, [x3, #0x5e0]
    // 0x5ae7b8: r0 = DefaultTypeTest()
    //     0x5ae7b8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5ae7bc: ldur            x3, [fp, #-0x10]
    // 0x5ae7c0: LoadField: r2 = r3->field_b
    //     0x5ae7c0: ldur            w2, [x3, #0xb]
    // 0x5ae7c4: DecompressPointer r2
    //     0x5ae7c4: add             x2, x2, HEAP, lsl #32
    // 0x5ae7c8: ldr             x0, [fp, #0x18]
    // 0x5ae7cc: r1 = Null
    //     0x5ae7cc: mov             x1, NULL
    // 0x5ae7d0: cmp             w0, NULL
    // 0x5ae7d4: b.eq            #0x5ae800
    // 0x5ae7d8: cmp             w2, NULL
    // 0x5ae7dc: b.eq            #0x5ae800
    // 0x5ae7e0: LoadField: r4 = r2->field_17
    //     0x5ae7e0: ldur            w4, [x2, #0x17]
    // 0x5ae7e4: DecompressPointer r4
    //     0x5ae7e4: add             x4, x4, HEAP, lsl #32
    // 0x5ae7e8: r8 = X0? bound RenderObject
    //     0x5ae7e8: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5ae7ec: ldr             x8, [x8, #0x6e8]
    // 0x5ae7f0: LoadField: r9 = r4->field_7
    //     0x5ae7f0: ldur            x9, [x4, #7]
    // 0x5ae7f4: r3 = Null
    //     0x5ae7f4: add             x3, PP, #0x22, lsl #12  ; [pp+0x225f0] Null
    //     0x5ae7f8: ldr             x3, [x3, #0x5f0]
    // 0x5ae7fc: blr             x9
    // 0x5ae800: ldr             x0, [fp, #0x18]
    // 0x5ae804: ldur            x1, [fp, #-0x10]
    // 0x5ae808: StoreField: r1->field_13 = r0
    //     0x5ae808: stur            w0, [x1, #0x13]
    //     0x5ae80c: ldurb           w16, [x1, #-1]
    //     0x5ae810: ldurb           w17, [x0, #-1]
    //     0x5ae814: and             x16, x17, x16, lsr #2
    //     0x5ae818: tst             x16, HEAP, lsr #32
    //     0x5ae81c: b.eq            #0x5ae824
    //     0x5ae820: bl              #0xd6826c
    // 0x5ae824: ldur            x3, [fp, #-8]
    // 0x5ae828: LoadField: r2 = r3->field_b
    //     0x5ae828: ldur            w2, [x3, #0xb]
    // 0x5ae82c: DecompressPointer r2
    //     0x5ae82c: add             x2, x2, HEAP, lsl #32
    // 0x5ae830: ldr             x0, [fp, #0x18]
    // 0x5ae834: r1 = Null
    //     0x5ae834: mov             x1, NULL
    // 0x5ae838: cmp             w0, NULL
    // 0x5ae83c: b.eq            #0x5ae868
    // 0x5ae840: cmp             w2, NULL
    // 0x5ae844: b.eq            #0x5ae868
    // 0x5ae848: LoadField: r4 = r2->field_17
    //     0x5ae848: ldur            w4, [x2, #0x17]
    // 0x5ae84c: DecompressPointer r4
    //     0x5ae84c: add             x4, x4, HEAP, lsl #32
    // 0x5ae850: r8 = X0? bound RenderObject
    //     0x5ae850: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5ae854: ldr             x8, [x8, #0x6e8]
    // 0x5ae858: LoadField: r9 = r4->field_7
    //     0x5ae858: ldur            x9, [x4, #7]
    // 0x5ae85c: r3 = Null
    //     0x5ae85c: add             x3, PP, #0x22, lsl #12  ; [pp+0x22600] Null
    //     0x5ae860: ldr             x3, [x3, #0x600]
    // 0x5ae864: blr             x9
    // 0x5ae868: ldr             x0, [fp, #0x18]
    // 0x5ae86c: ldur            x1, [fp, #-8]
    // 0x5ae870: StoreField: r1->field_f = r0
    //     0x5ae870: stur            w0, [x1, #0xf]
    //     0x5ae874: ldurb           w16, [x1, #-1]
    //     0x5ae878: ldurb           w17, [x0, #-1]
    //     0x5ae87c: and             x16, x17, x16, lsr #2
    //     0x5ae880: tst             x16, HEAP, lsr #32
    //     0x5ae884: b.eq            #0x5ae88c
    //     0x5ae888: bl              #0xd6826c
    // 0x5ae88c: r0 = Null
    //     0x5ae88c: mov             x0, NULL
    // 0x5ae890: LeaveFrame
    //     0x5ae890: mov             SP, fp
    //     0x5ae894: ldp             fp, lr, [SP], #0x10
    // 0x5ae898: ret
    //     0x5ae898: ret             
    // 0x5ae89c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5ae89c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5ae8a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5ae8a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5ae8a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5ae8a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5ae8a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5ae8a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _removeFromChildList(/* No info */) {
    // ** addr: 0x5ae8ac, size: 0x2c4
    // 0x5ae8ac: EnterFrame
    //     0x5ae8ac: stp             fp, lr, [SP, #-0x10]!
    //     0x5ae8b0: mov             fp, SP
    // 0x5ae8b4: AllocStack(0x20)
    //     0x5ae8b4: sub             SP, SP, #0x20
    // 0x5ae8b8: ldr             x0, [fp, #0x10]
    // 0x5ae8bc: LoadField: r3 = r0->field_17
    //     0x5ae8bc: ldur            w3, [x0, #0x17]
    // 0x5ae8c0: DecompressPointer r3
    //     0x5ae8c0: add             x3, x3, HEAP, lsl #32
    // 0x5ae8c4: stur            x3, [fp, #-8]
    // 0x5ae8c8: cmp             w3, NULL
    // 0x5ae8cc: b.eq            #0x5aeb64
    // 0x5ae8d0: mov             x0, x3
    // 0x5ae8d4: r2 = Null
    //     0x5ae8d4: mov             x2, NULL
    // 0x5ae8d8: r1 = Null
    //     0x5ae8d8: mov             x1, NULL
    // 0x5ae8dc: r4 = LoadClassIdInstr(r0)
    //     0x5ae8dc: ldur            x4, [x0, #-1]
    //     0x5ae8e0: ubfx            x4, x4, #0xc, #0x14
    // 0x5ae8e4: cmp             x4, #0x808
    // 0x5ae8e8: b.eq            #0x5ae900
    // 0x5ae8ec: r8 = TextParentData<RenderBox>
    //     0x5ae8ec: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x5ae8f0: ldr             x8, [x8, #0x298]
    // 0x5ae8f4: r3 = Null
    //     0x5ae8f4: add             x3, PP, #0x22, lsl #12  ; [pp+0x22610] Null
    //     0x5ae8f8: ldr             x3, [x3, #0x610]
    // 0x5ae8fc: r0 = DefaultTypeTest()
    //     0x5ae8fc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5ae900: ldur            x3, [fp, #-8]
    // 0x5ae904: LoadField: r4 = r3->field_f
    //     0x5ae904: ldur            w4, [x3, #0xf]
    // 0x5ae908: DecompressPointer r4
    //     0x5ae908: add             x4, x4, HEAP, lsl #32
    // 0x5ae90c: stur            x4, [fp, #-0x18]
    // 0x5ae910: cmp             w4, NULL
    // 0x5ae914: b.ne            #0x5ae944
    // 0x5ae918: ldr             x5, [fp, #0x18]
    // 0x5ae91c: LoadField: r0 = r3->field_13
    //     0x5ae91c: ldur            w0, [x3, #0x13]
    // 0x5ae920: DecompressPointer r0
    //     0x5ae920: add             x0, x0, HEAP, lsl #32
    // 0x5ae924: StoreField: r5->field_67 = r0
    //     0x5ae924: stur            w0, [x5, #0x67]
    //     0x5ae928: ldurb           w16, [x5, #-1]
    //     0x5ae92c: ldurb           w17, [x0, #-1]
    //     0x5ae930: and             x16, x17, x16, lsr #2
    //     0x5ae934: tst             x16, HEAP, lsr #32
    //     0x5ae938: b.eq            #0x5ae940
    //     0x5ae93c: bl              #0xd682ec
    // 0x5ae940: b               #0x5aea08
    // 0x5ae944: ldr             x5, [fp, #0x18]
    // 0x5ae948: LoadField: r6 = r4->field_17
    //     0x5ae948: ldur            w6, [x4, #0x17]
    // 0x5ae94c: DecompressPointer r6
    //     0x5ae94c: add             x6, x6, HEAP, lsl #32
    // 0x5ae950: stur            x6, [fp, #-0x10]
    // 0x5ae954: cmp             w6, NULL
    // 0x5ae958: b.eq            #0x5aeb68
    // 0x5ae95c: mov             x0, x6
    // 0x5ae960: r2 = Null
    //     0x5ae960: mov             x2, NULL
    // 0x5ae964: r1 = Null
    //     0x5ae964: mov             x1, NULL
    // 0x5ae968: r4 = LoadClassIdInstr(r0)
    //     0x5ae968: ldur            x4, [x0, #-1]
    //     0x5ae96c: ubfx            x4, x4, #0xc, #0x14
    // 0x5ae970: cmp             x4, #0x808
    // 0x5ae974: b.eq            #0x5ae98c
    // 0x5ae978: r8 = TextParentData<RenderBox>
    //     0x5ae978: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x5ae97c: ldr             x8, [x8, #0x298]
    // 0x5ae980: r3 = Null
    //     0x5ae980: add             x3, PP, #0x22, lsl #12  ; [pp+0x22620] Null
    //     0x5ae984: ldr             x3, [x3, #0x620]
    // 0x5ae988: r0 = DefaultTypeTest()
    //     0x5ae988: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5ae98c: ldur            x3, [fp, #-8]
    // 0x5ae990: LoadField: r4 = r3->field_13
    //     0x5ae990: ldur            w4, [x3, #0x13]
    // 0x5ae994: DecompressPointer r4
    //     0x5ae994: add             x4, x4, HEAP, lsl #32
    // 0x5ae998: ldur            x5, [fp, #-0x10]
    // 0x5ae99c: stur            x4, [fp, #-0x20]
    // 0x5ae9a0: LoadField: r2 = r5->field_b
    //     0x5ae9a0: ldur            w2, [x5, #0xb]
    // 0x5ae9a4: DecompressPointer r2
    //     0x5ae9a4: add             x2, x2, HEAP, lsl #32
    // 0x5ae9a8: mov             x0, x4
    // 0x5ae9ac: r1 = Null
    //     0x5ae9ac: mov             x1, NULL
    // 0x5ae9b0: cmp             w0, NULL
    // 0x5ae9b4: b.eq            #0x5ae9e0
    // 0x5ae9b8: cmp             w2, NULL
    // 0x5ae9bc: b.eq            #0x5ae9e0
    // 0x5ae9c0: LoadField: r4 = r2->field_17
    //     0x5ae9c0: ldur            w4, [x2, #0x17]
    // 0x5ae9c4: DecompressPointer r4
    //     0x5ae9c4: add             x4, x4, HEAP, lsl #32
    // 0x5ae9c8: r8 = X0? bound RenderObject
    //     0x5ae9c8: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5ae9cc: ldr             x8, [x8, #0x6e8]
    // 0x5ae9d0: LoadField: r9 = r4->field_7
    //     0x5ae9d0: ldur            x9, [x4, #7]
    // 0x5ae9d4: r3 = Null
    //     0x5ae9d4: add             x3, PP, #0x22, lsl #12  ; [pp+0x22630] Null
    //     0x5ae9d8: ldr             x3, [x3, #0x630]
    // 0x5ae9dc: blr             x9
    // 0x5ae9e0: ldur            x0, [fp, #-0x20]
    // 0x5ae9e4: ldur            x1, [fp, #-0x10]
    // 0x5ae9e8: StoreField: r1->field_13 = r0
    //     0x5ae9e8: stur            w0, [x1, #0x13]
    //     0x5ae9ec: ldurb           w16, [x1, #-1]
    //     0x5ae9f0: ldurb           w17, [x0, #-1]
    //     0x5ae9f4: and             x16, x17, x16, lsr #2
    //     0x5ae9f8: tst             x16, HEAP, lsr #32
    //     0x5ae9fc: b.eq            #0x5aea04
    //     0x5aea00: bl              #0xd6826c
    // 0x5aea04: ldur            x3, [fp, #-8]
    // 0x5aea08: LoadField: r0 = r3->field_13
    //     0x5aea08: ldur            w0, [x3, #0x13]
    // 0x5aea0c: DecompressPointer r0
    //     0x5aea0c: add             x0, x0, HEAP, lsl #32
    // 0x5aea10: cmp             w0, NULL
    // 0x5aea14: b.ne            #0x5aea40
    // 0x5aea18: ldr             x4, [fp, #0x18]
    // 0x5aea1c: ldur            x0, [fp, #-0x18]
    // 0x5aea20: StoreField: r4->field_6b = r0
    //     0x5aea20: stur            w0, [x4, #0x6b]
    //     0x5aea24: ldurb           w16, [x4, #-1]
    //     0x5aea28: ldurb           w17, [x0, #-1]
    //     0x5aea2c: and             x16, x17, x16, lsr #2
    //     0x5aea30: tst             x16, HEAP, lsr #32
    //     0x5aea34: b.eq            #0x5aea3c
    //     0x5aea38: bl              #0xd682cc
    // 0x5aea3c: b               #0x5aeaf8
    // 0x5aea40: ldr             x4, [fp, #0x18]
    // 0x5aea44: LoadField: r5 = r0->field_17
    //     0x5aea44: ldur            w5, [x0, #0x17]
    // 0x5aea48: DecompressPointer r5
    //     0x5aea48: add             x5, x5, HEAP, lsl #32
    // 0x5aea4c: stur            x5, [fp, #-0x10]
    // 0x5aea50: cmp             w5, NULL
    // 0x5aea54: b.eq            #0x5aeb6c
    // 0x5aea58: mov             x0, x5
    // 0x5aea5c: r2 = Null
    //     0x5aea5c: mov             x2, NULL
    // 0x5aea60: r1 = Null
    //     0x5aea60: mov             x1, NULL
    // 0x5aea64: r4 = LoadClassIdInstr(r0)
    //     0x5aea64: ldur            x4, [x0, #-1]
    //     0x5aea68: ubfx            x4, x4, #0xc, #0x14
    // 0x5aea6c: cmp             x4, #0x808
    // 0x5aea70: b.eq            #0x5aea88
    // 0x5aea74: r8 = TextParentData<RenderBox>
    //     0x5aea74: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x5aea78: ldr             x8, [x8, #0x298]
    // 0x5aea7c: r3 = Null
    //     0x5aea7c: add             x3, PP, #0x22, lsl #12  ; [pp+0x22640] Null
    //     0x5aea80: ldr             x3, [x3, #0x640]
    // 0x5aea84: r0 = DefaultTypeTest()
    //     0x5aea84: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5aea88: ldur            x3, [fp, #-0x10]
    // 0x5aea8c: LoadField: r2 = r3->field_b
    //     0x5aea8c: ldur            w2, [x3, #0xb]
    // 0x5aea90: DecompressPointer r2
    //     0x5aea90: add             x2, x2, HEAP, lsl #32
    // 0x5aea94: ldur            x0, [fp, #-0x18]
    // 0x5aea98: r1 = Null
    //     0x5aea98: mov             x1, NULL
    // 0x5aea9c: cmp             w0, NULL
    // 0x5aeaa0: b.eq            #0x5aeacc
    // 0x5aeaa4: cmp             w2, NULL
    // 0x5aeaa8: b.eq            #0x5aeacc
    // 0x5aeaac: LoadField: r4 = r2->field_17
    //     0x5aeaac: ldur            w4, [x2, #0x17]
    // 0x5aeab0: DecompressPointer r4
    //     0x5aeab0: add             x4, x4, HEAP, lsl #32
    // 0x5aeab4: r8 = X0? bound RenderObject
    //     0x5aeab4: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5aeab8: ldr             x8, [x8, #0x6e8]
    // 0x5aeabc: LoadField: r9 = r4->field_7
    //     0x5aeabc: ldur            x9, [x4, #7]
    // 0x5aeac0: r3 = Null
    //     0x5aeac0: add             x3, PP, #0x22, lsl #12  ; [pp+0x22650] Null
    //     0x5aeac4: ldr             x3, [x3, #0x650]
    // 0x5aeac8: blr             x9
    // 0x5aeacc: ldur            x0, [fp, #-0x18]
    // 0x5aead0: ldur            x1, [fp, #-0x10]
    // 0x5aead4: StoreField: r1->field_f = r0
    //     0x5aead4: stur            w0, [x1, #0xf]
    //     0x5aead8: ldurb           w16, [x1, #-1]
    //     0x5aeadc: ldurb           w17, [x0, #-1]
    //     0x5aeae0: and             x16, x17, x16, lsr #2
    //     0x5aeae4: tst             x16, HEAP, lsr #32
    //     0x5aeae8: b.eq            #0x5aeaf0
    //     0x5aeaec: bl              #0xd6826c
    // 0x5aeaf0: ldr             x4, [fp, #0x18]
    // 0x5aeaf4: ldur            x3, [fp, #-8]
    // 0x5aeaf8: LoadField: r2 = r3->field_b
    //     0x5aeaf8: ldur            w2, [x3, #0xb]
    // 0x5aeafc: DecompressPointer r2
    //     0x5aeafc: add             x2, x2, HEAP, lsl #32
    // 0x5aeb00: r0 = Null
    //     0x5aeb00: mov             x0, NULL
    // 0x5aeb04: r1 = Null
    //     0x5aeb04: mov             x1, NULL
    // 0x5aeb08: cmp             w0, NULL
    // 0x5aeb0c: b.eq            #0x5aeb38
    // 0x5aeb10: cmp             w2, NULL
    // 0x5aeb14: b.eq            #0x5aeb38
    // 0x5aeb18: LoadField: r4 = r2->field_17
    //     0x5aeb18: ldur            w4, [x2, #0x17]
    // 0x5aeb1c: DecompressPointer r4
    //     0x5aeb1c: add             x4, x4, HEAP, lsl #32
    // 0x5aeb20: r8 = X0? bound RenderObject
    //     0x5aeb20: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5aeb24: ldr             x8, [x8, #0x6e8]
    // 0x5aeb28: LoadField: r9 = r4->field_7
    //     0x5aeb28: ldur            x9, [x4, #7]
    // 0x5aeb2c: r3 = Null
    //     0x5aeb2c: add             x3, PP, #0x22, lsl #12  ; [pp+0x22660] Null
    //     0x5aeb30: ldr             x3, [x3, #0x660]
    // 0x5aeb34: blr             x9
    // 0x5aeb38: ldur            x1, [fp, #-8]
    // 0x5aeb3c: StoreField: r1->field_f = rNULL
    //     0x5aeb3c: stur            NULL, [x1, #0xf]
    // 0x5aeb40: StoreField: r1->field_13 = rNULL
    //     0x5aeb40: stur            NULL, [x1, #0x13]
    // 0x5aeb44: ldr             x1, [fp, #0x18]
    // 0x5aeb48: LoadField: r2 = r1->field_5f
    //     0x5aeb48: ldur            x2, [x1, #0x5f]
    // 0x5aeb4c: sub             x3, x2, #1
    // 0x5aeb50: StoreField: r1->field_5f = r3
    //     0x5aeb50: stur            x3, [x1, #0x5f]
    // 0x5aeb54: r0 = Null
    //     0x5aeb54: mov             x0, NULL
    // 0x5aeb58: LeaveFrame
    //     0x5aeb58: mov             SP, fp
    //     0x5aeb5c: ldp             fp, lr, [SP], #0x10
    // 0x5aeb60: ret
    //     0x5aeb60: ret             
    // 0x5aeb64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5aeb64: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5aeb68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5aeb68: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5aeb6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5aeb6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ remove(/* No info */) {
    // ** addr: 0x5e9360, size: 0x90
    // 0x5e9360: EnterFrame
    //     0x5e9360: stp             fp, lr, [SP, #-0x10]!
    //     0x5e9364: mov             fp, SP
    // 0x5e9368: CheckStackOverflow
    //     0x5e9368: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e936c: cmp             SP, x16
    //     0x5e9370: b.ls            #0x5e93e8
    // 0x5e9374: ldr             x0, [fp, #0x10]
    // 0x5e9378: r2 = Null
    //     0x5e9378: mov             x2, NULL
    // 0x5e937c: r1 = Null
    //     0x5e937c: mov             x1, NULL
    // 0x5e9380: r4 = 59
    //     0x5e9380: mov             x4, #0x3b
    // 0x5e9384: branchIfSmi(r0, 0x5e9390)
    //     0x5e9384: tbz             w0, #0, #0x5e9390
    // 0x5e9388: r4 = LoadClassIdInstr(r0)
    //     0x5e9388: ldur            x4, [x0, #-1]
    //     0x5e938c: ubfx            x4, x4, #0xc, #0x14
    // 0x5e9390: sub             x4, x4, #0x965
    // 0x5e9394: cmp             x4, #0x8b
    // 0x5e9398: b.ls            #0x5e93b0
    // 0x5e939c: r8 = RenderBox
    //     0x5e939c: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x5e93a0: ldr             x8, [x8, #0xfa0]
    // 0x5e93a4: r3 = Null
    //     0x5e93a4: add             x3, PP, #0x22, lsl #12  ; [pp+0x22670] Null
    //     0x5e93a8: ldr             x3, [x3, #0x670]
    // 0x5e93ac: r0 = RenderBox()
    //     0x5e93ac: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x5e93b0: ldr             x16, [fp, #0x18]
    // 0x5e93b4: ldr             lr, [fp, #0x10]
    // 0x5e93b8: stp             lr, x16, [SP, #-0x10]!
    // 0x5e93bc: r0 = _removeFromChildList()
    //     0x5e93bc: bl              #0x5ae8ac  ; [package:flutter/src/rendering/paragraph.dart] _RenderParagraph&RenderBox&ContainerRenderObjectMixin::_removeFromChildList
    // 0x5e93c0: add             SP, SP, #0x10
    // 0x5e93c4: ldr             x16, [fp, #0x18]
    // 0x5e93c8: ldr             lr, [fp, #0x10]
    // 0x5e93cc: stp             lr, x16, [SP, #-0x10]!
    // 0x5e93d0: r0 = dropChild()
    //     0x5e93d0: bl              #0x5e5aec  ; [package:flutter/src/rendering/object.dart] RenderObject::dropChild
    // 0x5e93d4: add             SP, SP, #0x10
    // 0x5e93d8: r0 = Null
    //     0x5e93d8: mov             x0, NULL
    // 0x5e93dc: LeaveFrame
    //     0x5e93dc: mov             SP, fp
    //     0x5e93e0: ldp             fp, lr, [SP], #0x10
    // 0x5e93e4: ret
    //     0x5e93e4: ret             
    // 0x5e93e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e93e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e93ec: b               #0x5e9374
  }
  _ insert(/* No info */) {
    // ** addr: 0x5e9550, size: 0xd0
    // 0x5e9550: EnterFrame
    //     0x5e9550: stp             fp, lr, [SP, #-0x10]!
    //     0x5e9554: mov             fp, SP
    // 0x5e9558: CheckStackOverflow
    //     0x5e9558: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e955c: cmp             SP, x16
    //     0x5e9560: b.ls            #0x5e9618
    // 0x5e9564: ldr             x0, [fp, #0x18]
    // 0x5e9568: r2 = Null
    //     0x5e9568: mov             x2, NULL
    // 0x5e956c: r1 = Null
    //     0x5e956c: mov             x1, NULL
    // 0x5e9570: r4 = 59
    //     0x5e9570: mov             x4, #0x3b
    // 0x5e9574: branchIfSmi(r0, 0x5e9580)
    //     0x5e9574: tbz             w0, #0, #0x5e9580
    // 0x5e9578: r4 = LoadClassIdInstr(r0)
    //     0x5e9578: ldur            x4, [x0, #-1]
    //     0x5e957c: ubfx            x4, x4, #0xc, #0x14
    // 0x5e9580: sub             x4, x4, #0x965
    // 0x5e9584: cmp             x4, #0x8b
    // 0x5e9588: b.ls            #0x5e95a0
    // 0x5e958c: r8 = RenderBox
    //     0x5e958c: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x5e9590: ldr             x8, [x8, #0xfa0]
    // 0x5e9594: r3 = Null
    //     0x5e9594: add             x3, PP, #0x22, lsl #12  ; [pp+0x22680] Null
    //     0x5e9598: ldr             x3, [x3, #0x680]
    // 0x5e959c: r0 = RenderBox()
    //     0x5e959c: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x5e95a0: ldr             x0, [fp, #0x10]
    // 0x5e95a4: r2 = Null
    //     0x5e95a4: mov             x2, NULL
    // 0x5e95a8: r1 = Null
    //     0x5e95a8: mov             x1, NULL
    // 0x5e95ac: r4 = 59
    //     0x5e95ac: mov             x4, #0x3b
    // 0x5e95b0: branchIfSmi(r0, 0x5e95bc)
    //     0x5e95b0: tbz             w0, #0, #0x5e95bc
    // 0x5e95b4: r4 = LoadClassIdInstr(r0)
    //     0x5e95b4: ldur            x4, [x0, #-1]
    //     0x5e95b8: ubfx            x4, x4, #0xc, #0x14
    // 0x5e95bc: sub             x4, x4, #0x965
    // 0x5e95c0: cmp             x4, #0x8b
    // 0x5e95c4: b.ls            #0x5e95d8
    // 0x5e95c8: r8 = RenderBox?
    //     0x5e95c8: ldr             x8, [PP, #0x4de8]  ; [pp+0x4de8] Type: RenderBox?
    // 0x5e95cc: r3 = Null
    //     0x5e95cc: add             x3, PP, #0x22, lsl #12  ; [pp+0x22690] Null
    //     0x5e95d0: ldr             x3, [x3, #0x690]
    // 0x5e95d4: r0 = RenderBox?()
    //     0x5e95d4: bl              #0x5ad534  ; IsType_RenderBox?_Stub
    // 0x5e95d8: ldr             x16, [fp, #0x20]
    // 0x5e95dc: ldr             lr, [fp, #0x18]
    // 0x5e95e0: stp             lr, x16, [SP, #-0x10]!
    // 0x5e95e4: r0 = adoptChild()
    //     0x5e95e4: bl              #0x5e61d4  ; [package:flutter/src/rendering/object.dart] RenderObject::adoptChild
    // 0x5e95e8: add             SP, SP, #0x10
    // 0x5e95ec: ldr             x16, [fp, #0x20]
    // 0x5e95f0: ldr             lr, [fp, #0x18]
    // 0x5e95f4: stp             lr, x16, [SP, #-0x10]!
    // 0x5e95f8: ldr             x16, [fp, #0x10]
    // 0x5e95fc: SaveReg r16
    //     0x5e95fc: str             x16, [SP, #-8]!
    // 0x5e9600: r0 = _insertIntoChildList()
    //     0x5e9600: bl              #0x5ae34c  ; [package:flutter/src/rendering/paragraph.dart] _RenderParagraph&RenderBox&ContainerRenderObjectMixin::_insertIntoChildList
    // 0x5e9604: add             SP, SP, #0x18
    // 0x5e9608: r0 = Null
    //     0x5e9608: mov             x0, NULL
    // 0x5e960c: LeaveFrame
    //     0x5e960c: mov             SP, fp
    //     0x5e9610: ldp             fp, lr, [SP], #0x10
    // 0x5e9614: ret
    //     0x5e9614: ret             
    // 0x5e9618: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e9618: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e961c: b               #0x5e9564
  }
  get _ firstChild(/* No info */) {
    // ** addr: 0x6250fc, size: 0x10
    // 0x6250fc: ldr             x1, [SP]
    // 0x625100: LoadField: r0 = r1->field_67
    //     0x625100: ldur            w0, [x1, #0x67]
    // 0x625104: DecompressPointer r0
    //     0x625104: add             x0, x0, HEAP, lsl #32
    // 0x625108: ret
    //     0x625108: ret             
  }
  _ visitChildren(/* No info */) {
    // ** addr: 0x6bf75c, size: 0xd8
    // 0x6bf75c: EnterFrame
    //     0x6bf75c: stp             fp, lr, [SP, #-0x10]!
    //     0x6bf760: mov             fp, SP
    // 0x6bf764: AllocStack(0x10)
    //     0x6bf764: sub             SP, SP, #0x10
    // 0x6bf768: CheckStackOverflow
    //     0x6bf768: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bf76c: cmp             SP, x16
    //     0x6bf770: b.ls            #0x6bf820
    // 0x6bf774: ldr             x0, [fp, #0x18]
    // 0x6bf778: LoadField: r1 = r0->field_67
    //     0x6bf778: ldur            w1, [x0, #0x67]
    // 0x6bf77c: DecompressPointer r1
    //     0x6bf77c: add             x1, x1, HEAP, lsl #32
    // 0x6bf780: stur            x1, [fp, #-8]
    // 0x6bf784: CheckStackOverflow
    //     0x6bf784: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bf788: cmp             SP, x16
    //     0x6bf78c: b.ls            #0x6bf828
    // 0x6bf790: cmp             w1, NULL
    // 0x6bf794: b.eq            #0x6bf810
    // 0x6bf798: ldr             x16, [fp, #0x10]
    // 0x6bf79c: stp             x1, x16, [SP, #-0x10]!
    // 0x6bf7a0: ldr             x0, [fp, #0x10]
    // 0x6bf7a4: ClosureCall
    //     0x6bf7a4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6bf7a8: ldur            x2, [x0, #0x1f]
    //     0x6bf7ac: blr             x2
    // 0x6bf7b0: add             SP, SP, #0x10
    // 0x6bf7b4: ldur            x0, [fp, #-8]
    // 0x6bf7b8: LoadField: r3 = r0->field_17
    //     0x6bf7b8: ldur            w3, [x0, #0x17]
    // 0x6bf7bc: DecompressPointer r3
    //     0x6bf7bc: add             x3, x3, HEAP, lsl #32
    // 0x6bf7c0: stur            x3, [fp, #-0x10]
    // 0x6bf7c4: cmp             w3, NULL
    // 0x6bf7c8: b.eq            #0x6bf830
    // 0x6bf7cc: mov             x0, x3
    // 0x6bf7d0: r2 = Null
    //     0x6bf7d0: mov             x2, NULL
    // 0x6bf7d4: r1 = Null
    //     0x6bf7d4: mov             x1, NULL
    // 0x6bf7d8: r4 = LoadClassIdInstr(r0)
    //     0x6bf7d8: ldur            x4, [x0, #-1]
    //     0x6bf7dc: ubfx            x4, x4, #0xc, #0x14
    // 0x6bf7e0: cmp             x4, #0x808
    // 0x6bf7e4: b.eq            #0x6bf7fc
    // 0x6bf7e8: r8 = TextParentData<RenderBox>
    //     0x6bf7e8: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x6bf7ec: ldr             x8, [x8, #0x298]
    // 0x6bf7f0: r3 = Null
    //     0x6bf7f0: add             x3, PP, #0x22, lsl #12  ; [pp+0x22500] Null
    //     0x6bf7f4: ldr             x3, [x3, #0x500]
    // 0x6bf7f8: r0 = DefaultTypeTest()
    //     0x6bf7f8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6bf7fc: ldur            x1, [fp, #-0x10]
    // 0x6bf800: LoadField: r0 = r1->field_13
    //     0x6bf800: ldur            w0, [x1, #0x13]
    // 0x6bf804: DecompressPointer r0
    //     0x6bf804: add             x0, x0, HEAP, lsl #32
    // 0x6bf808: mov             x1, x0
    // 0x6bf80c: b               #0x6bf780
    // 0x6bf810: r0 = Null
    //     0x6bf810: mov             x0, NULL
    // 0x6bf814: LeaveFrame
    //     0x6bf814: mov             SP, fp
    //     0x6bf818: ldp             fp, lr, [SP], #0x10
    // 0x6bf81c: ret
    //     0x6bf81c: ret             
    // 0x6bf820: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bf820: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bf824: b               #0x6bf774
    // 0x6bf828: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bf828: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bf82c: b               #0x6bf790
    // 0x6bf830: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6bf830: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ redepthChildren(/* No info */) {
    // ** addr: 0x792a08, size: 0xf8
    // 0x792a08: EnterFrame
    //     0x792a08: stp             fp, lr, [SP, #-0x10]!
    //     0x792a0c: mov             fp, SP
    // 0x792a10: AllocStack(0x10)
    //     0x792a10: sub             SP, SP, #0x10
    // 0x792a14: CheckStackOverflow
    //     0x792a14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x792a18: cmp             SP, x16
    //     0x792a1c: b.ls            #0x792aec
    // 0x792a20: ldr             x1, [fp, #0x10]
    // 0x792a24: LoadField: r0 = r1->field_67
    //     0x792a24: ldur            w0, [x1, #0x67]
    // 0x792a28: DecompressPointer r0
    //     0x792a28: add             x0, x0, HEAP, lsl #32
    // 0x792a2c: mov             x2, x0
    // 0x792a30: stur            x2, [fp, #-8]
    // 0x792a34: CheckStackOverflow
    //     0x792a34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x792a38: cmp             SP, x16
    //     0x792a3c: b.ls            #0x792af4
    // 0x792a40: cmp             w2, NULL
    // 0x792a44: b.eq            #0x792adc
    // 0x792a48: LoadField: r0 = r2->field_7
    //     0x792a48: ldur            x0, [x2, #7]
    // 0x792a4c: LoadField: r3 = r1->field_7
    //     0x792a4c: ldur            x3, [x1, #7]
    // 0x792a50: cmp             x0, x3
    // 0x792a54: b.gt            #0x792a80
    // 0x792a58: add             x0, x3, #1
    // 0x792a5c: StoreField: r2->field_7 = r0
    //     0x792a5c: stur            x0, [x2, #7]
    // 0x792a60: r0 = LoadClassIdInstr(r2)
    //     0x792a60: ldur            x0, [x2, #-1]
    //     0x792a64: ubfx            x0, x0, #0xc, #0x14
    // 0x792a68: SaveReg r2
    //     0x792a68: str             x2, [SP, #-8]!
    // 0x792a6c: r0 = GDT[cid_x0 + 0xbdf1]()
    //     0x792a6c: mov             x17, #0xbdf1
    //     0x792a70: add             lr, x0, x17
    //     0x792a74: ldr             lr, [x21, lr, lsl #3]
    //     0x792a78: blr             lr
    // 0x792a7c: add             SP, SP, #8
    // 0x792a80: ldur            x0, [fp, #-8]
    // 0x792a84: LoadField: r3 = r0->field_17
    //     0x792a84: ldur            w3, [x0, #0x17]
    // 0x792a88: DecompressPointer r3
    //     0x792a88: add             x3, x3, HEAP, lsl #32
    // 0x792a8c: stur            x3, [fp, #-0x10]
    // 0x792a90: cmp             w3, NULL
    // 0x792a94: b.eq            #0x792afc
    // 0x792a98: mov             x0, x3
    // 0x792a9c: r2 = Null
    //     0x792a9c: mov             x2, NULL
    // 0x792aa0: r1 = Null
    //     0x792aa0: mov             x1, NULL
    // 0x792aa4: r4 = LoadClassIdInstr(r0)
    //     0x792aa4: ldur            x4, [x0, #-1]
    //     0x792aa8: ubfx            x4, x4, #0xc, #0x14
    // 0x792aac: cmp             x4, #0x808
    // 0x792ab0: b.eq            #0x792ac8
    // 0x792ab4: r8 = TextParentData<RenderBox>
    //     0x792ab4: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x792ab8: ldr             x8, [x8, #0x298]
    // 0x792abc: r3 = Null
    //     0x792abc: add             x3, PP, #0x22, lsl #12  ; [pp+0x22510] Null
    //     0x792ac0: ldr             x3, [x3, #0x510]
    // 0x792ac4: r0 = DefaultTypeTest()
    //     0x792ac4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x792ac8: ldur            x1, [fp, #-0x10]
    // 0x792acc: LoadField: r2 = r1->field_13
    //     0x792acc: ldur            w2, [x1, #0x13]
    // 0x792ad0: DecompressPointer r2
    //     0x792ad0: add             x2, x2, HEAP, lsl #32
    // 0x792ad4: ldr             x1, [fp, #0x10]
    // 0x792ad8: b               #0x792a30
    // 0x792adc: r0 = Null
    //     0x792adc: mov             x0, NULL
    // 0x792ae0: LeaveFrame
    //     0x792ae0: mov             SP, fp
    //     0x792ae4: ldp             fp, lr, [SP], #0x10
    // 0x792ae8: ret
    //     0x792ae8: ret             
    // 0x792aec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x792aec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x792af0: b               #0x792a20
    // 0x792af4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x792af4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x792af8: b               #0x792a40
    // 0x792afc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x792afc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bcac4, size: 0xf4
    // 0x9bcac4: EnterFrame
    //     0x9bcac4: stp             fp, lr, [SP, #-0x10]!
    //     0x9bcac8: mov             fp, SP
    // 0x9bcacc: AllocStack(0x10)
    //     0x9bcacc: sub             SP, SP, #0x10
    // 0x9bcad0: CheckStackOverflow
    //     0x9bcad0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bcad4: cmp             SP, x16
    //     0x9bcad8: b.ls            #0x9bcba4
    // 0x9bcadc: ldr             x16, [fp, #0x18]
    // 0x9bcae0: ldr             lr, [fp, #0x10]
    // 0x9bcae4: stp             lr, x16, [SP, #-0x10]!
    // 0x9bcae8: r0 = attach()
    //     0x9bcae8: bl              #0x9bf794  ; [package:flutter/src/rendering/object.dart] RenderObject::attach
    // 0x9bcaec: add             SP, SP, #0x10
    // 0x9bcaf0: ldr             x0, [fp, #0x18]
    // 0x9bcaf4: LoadField: r1 = r0->field_67
    //     0x9bcaf4: ldur            w1, [x0, #0x67]
    // 0x9bcaf8: DecompressPointer r1
    //     0x9bcaf8: add             x1, x1, HEAP, lsl #32
    // 0x9bcafc: stur            x1, [fp, #-8]
    // 0x9bcb00: CheckStackOverflow
    //     0x9bcb00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bcb04: cmp             SP, x16
    //     0x9bcb08: b.ls            #0x9bcbac
    // 0x9bcb0c: cmp             w1, NULL
    // 0x9bcb10: b.eq            #0x9bcb94
    // 0x9bcb14: r0 = LoadClassIdInstr(r1)
    //     0x9bcb14: ldur            x0, [x1, #-1]
    //     0x9bcb18: ubfx            x0, x0, #0xc, #0x14
    // 0x9bcb1c: ldr             x16, [fp, #0x10]
    // 0x9bcb20: stp             x16, x1, [SP, #-0x10]!
    // 0x9bcb24: r0 = GDT[cid_x0 + 0xaf1f]()
    //     0x9bcb24: mov             x17, #0xaf1f
    //     0x9bcb28: add             lr, x0, x17
    //     0x9bcb2c: ldr             lr, [x21, lr, lsl #3]
    //     0x9bcb30: blr             lr
    // 0x9bcb34: add             SP, SP, #0x10
    // 0x9bcb38: ldur            x0, [fp, #-8]
    // 0x9bcb3c: LoadField: r3 = r0->field_17
    //     0x9bcb3c: ldur            w3, [x0, #0x17]
    // 0x9bcb40: DecompressPointer r3
    //     0x9bcb40: add             x3, x3, HEAP, lsl #32
    // 0x9bcb44: stur            x3, [fp, #-0x10]
    // 0x9bcb48: cmp             w3, NULL
    // 0x9bcb4c: b.eq            #0x9bcbb4
    // 0x9bcb50: mov             x0, x3
    // 0x9bcb54: r2 = Null
    //     0x9bcb54: mov             x2, NULL
    // 0x9bcb58: r1 = Null
    //     0x9bcb58: mov             x1, NULL
    // 0x9bcb5c: r4 = LoadClassIdInstr(r0)
    //     0x9bcb5c: ldur            x4, [x0, #-1]
    //     0x9bcb60: ubfx            x4, x4, #0xc, #0x14
    // 0x9bcb64: cmp             x4, #0x808
    // 0x9bcb68: b.eq            #0x9bcb80
    // 0x9bcb6c: r8 = TextParentData<RenderBox>
    //     0x9bcb6c: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x9bcb70: ldr             x8, [x8, #0x298]
    // 0x9bcb74: r3 = Null
    //     0x9bcb74: add             x3, PP, #0x22, lsl #12  ; [pp+0x226b0] Null
    //     0x9bcb78: ldr             x3, [x3, #0x6b0]
    // 0x9bcb7c: r0 = DefaultTypeTest()
    //     0x9bcb7c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bcb80: ldur            x1, [fp, #-0x10]
    // 0x9bcb84: LoadField: r0 = r1->field_13
    //     0x9bcb84: ldur            w0, [x1, #0x13]
    // 0x9bcb88: DecompressPointer r0
    //     0x9bcb88: add             x0, x0, HEAP, lsl #32
    // 0x9bcb8c: mov             x1, x0
    // 0x9bcb90: b               #0x9bcafc
    // 0x9bcb94: r0 = Null
    //     0x9bcb94: mov             x0, NULL
    // 0x9bcb98: LeaveFrame
    //     0x9bcb98: mov             SP, fp
    //     0x9bcb9c: ldp             fp, lr, [SP], #0x10
    // 0x9bcba0: ret
    //     0x9bcba0: ret             
    // 0x9bcba4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bcba4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bcba8: b               #0x9bcadc
    // 0x9bcbac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bcbac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bcbb0: b               #0x9bcb0c
    // 0x9bcbb4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9bcbb4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ detach(/* No info */) {
    // ** addr: 0xa68c78, size: 0xec
    // 0xa68c78: EnterFrame
    //     0xa68c78: stp             fp, lr, [SP, #-0x10]!
    //     0xa68c7c: mov             fp, SP
    // 0xa68c80: AllocStack(0x10)
    //     0xa68c80: sub             SP, SP, #0x10
    // 0xa68c84: CheckStackOverflow
    //     0xa68c84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa68c88: cmp             SP, x16
    //     0xa68c8c: b.ls            #0xa68d50
    // 0xa68c90: ldr             x16, [fp, #0x10]
    // 0xa68c94: SaveReg r16
    //     0xa68c94: str             x16, [SP, #-8]!
    // 0xa68c98: r0 = detach()
    //     0xa68c98: bl              #0xa6ade0  ; [package:flutter/src/foundation/node.dart] AbstractNode::detach
    // 0xa68c9c: add             SP, SP, #8
    // 0xa68ca0: ldr             x0, [fp, #0x10]
    // 0xa68ca4: LoadField: r1 = r0->field_67
    //     0xa68ca4: ldur            w1, [x0, #0x67]
    // 0xa68ca8: DecompressPointer r1
    //     0xa68ca8: add             x1, x1, HEAP, lsl #32
    // 0xa68cac: stur            x1, [fp, #-8]
    // 0xa68cb0: CheckStackOverflow
    //     0xa68cb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa68cb4: cmp             SP, x16
    //     0xa68cb8: b.ls            #0xa68d58
    // 0xa68cbc: cmp             w1, NULL
    // 0xa68cc0: b.eq            #0xa68d40
    // 0xa68cc4: r0 = LoadClassIdInstr(r1)
    //     0xa68cc4: ldur            x0, [x1, #-1]
    //     0xa68cc8: ubfx            x0, x0, #0xc, #0x14
    // 0xa68ccc: SaveReg r1
    //     0xa68ccc: str             x1, [SP, #-8]!
    // 0xa68cd0: r0 = GDT[cid_x0 + 0xa3cc]()
    //     0xa68cd0: mov             x17, #0xa3cc
    //     0xa68cd4: add             lr, x0, x17
    //     0xa68cd8: ldr             lr, [x21, lr, lsl #3]
    //     0xa68cdc: blr             lr
    // 0xa68ce0: add             SP, SP, #8
    // 0xa68ce4: ldur            x0, [fp, #-8]
    // 0xa68ce8: LoadField: r3 = r0->field_17
    //     0xa68ce8: ldur            w3, [x0, #0x17]
    // 0xa68cec: DecompressPointer r3
    //     0xa68cec: add             x3, x3, HEAP, lsl #32
    // 0xa68cf0: stur            x3, [fp, #-0x10]
    // 0xa68cf4: cmp             w3, NULL
    // 0xa68cf8: b.eq            #0xa68d60
    // 0xa68cfc: mov             x0, x3
    // 0xa68d00: r2 = Null
    //     0xa68d00: mov             x2, NULL
    // 0xa68d04: r1 = Null
    //     0xa68d04: mov             x1, NULL
    // 0xa68d08: r4 = LoadClassIdInstr(r0)
    //     0xa68d08: ldur            x4, [x0, #-1]
    //     0xa68d0c: ubfx            x4, x4, #0xc, #0x14
    // 0xa68d10: cmp             x4, #0x808
    // 0xa68d14: b.eq            #0xa68d2c
    // 0xa68d18: r8 = TextParentData<RenderBox>
    //     0xa68d18: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0xa68d1c: ldr             x8, [x8, #0x298]
    // 0xa68d20: r3 = Null
    //     0xa68d20: add             x3, PP, #0x22, lsl #12  ; [pp+0x226a0] Null
    //     0xa68d24: ldr             x3, [x3, #0x6a0]
    // 0xa68d28: r0 = DefaultTypeTest()
    //     0xa68d28: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa68d2c: ldur            x1, [fp, #-0x10]
    // 0xa68d30: LoadField: r0 = r1->field_13
    //     0xa68d30: ldur            w0, [x1, #0x13]
    // 0xa68d34: DecompressPointer r0
    //     0xa68d34: add             x0, x0, HEAP, lsl #32
    // 0xa68d38: mov             x1, x0
    // 0xa68d3c: b               #0xa68cac
    // 0xa68d40: r0 = Null
    //     0xa68d40: mov             x0, NULL
    // 0xa68d44: LeaveFrame
    //     0xa68d44: mov             SP, fp
    //     0xa68d48: ldp             fp, lr, [SP], #0x10
    // 0xa68d4c: ret
    //     0xa68d4c: ret             
    // 0xa68d50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa68d50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa68d54: b               #0xa68c90
    // 0xa68d58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa68d58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa68d5c: b               #0xa68cbc
    // 0xa68d60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa68d60: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2532, size: 0x70, field offset: 0x70
//   transformed mixin,
abstract class _RenderParagraph&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin extends _RenderParagraph&RenderBox&ContainerRenderObjectMixin
     with RenderBoxContainerDefaultsMixin<X0 bound RenderBox, X1 bound ContainerBoxParentData<X0 bound RenderBox>> {
}

// class id: 2533, size: 0x70, field offset: 0x70
//   transformed mixin,
abstract class _RenderParagraph&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin&RelayoutWhenSystemFontsChangeMixin extends _RenderParagraph&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin
     with RelayoutWhenSystemFontsChangeMixin {

  _ attach(/* No info */) {
    // ** addr: 0x9bc98c, size: 0x110
    // 0x9bc98c: EnterFrame
    //     0x9bc98c: stp             fp, lr, [SP, #-0x10]!
    //     0x9bc990: mov             fp, SP
    // 0x9bc994: AllocStack(0x8)
    //     0x9bc994: sub             SP, SP, #8
    // 0x9bc998: CheckStackOverflow
    //     0x9bc998: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bc99c: cmp             SP, x16
    //     0x9bc9a0: b.ls            #0x9bca90
    // 0x9bc9a4: ldr             x0, [fp, #0x10]
    // 0x9bc9a8: r2 = Null
    //     0x9bc9a8: mov             x2, NULL
    // 0x9bc9ac: r1 = Null
    //     0x9bc9ac: mov             x1, NULL
    // 0x9bc9b0: r4 = 59
    //     0x9bc9b0: mov             x4, #0x3b
    // 0x9bc9b4: branchIfSmi(r0, 0x9bc9c0)
    //     0x9bc9b4: tbz             w0, #0, #0x9bc9c0
    // 0x9bc9b8: r4 = LoadClassIdInstr(r0)
    //     0x9bc9b8: ldur            x4, [x0, #-1]
    //     0x9bc9bc: ubfx            x4, x4, #0xc, #0x14
    // 0x9bc9c0: cmp             x4, #0x7e6
    // 0x9bc9c4: b.eq            #0x9bc9d8
    // 0x9bc9c8: r8 = PipelineOwner
    //     0x9bc9c8: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9bc9cc: r3 = Null
    //     0x9bc9cc: add             x3, PP, #0x22, lsl #12  ; [pp+0x226d8] Null
    //     0x9bc9d0: ldr             x3, [x3, #0x6d8]
    // 0x9bc9d4: r0 = DefaultTypeTest()
    //     0x9bc9d4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bc9d8: ldr             x16, [fp, #0x18]
    // 0x9bc9dc: ldr             lr, [fp, #0x10]
    // 0x9bc9e0: stp             lr, x16, [SP, #-0x10]!
    // 0x9bc9e4: r0 = attach()
    //     0x9bc9e4: bl              #0x9bcac4  ; [package:flutter/src/rendering/paragraph.dart] _RenderParagraph&RenderBox&ContainerRenderObjectMixin::attach
    // 0x9bc9e8: add             SP, SP, #0x10
    // 0x9bc9ec: r0 = LoadStaticField(0xe6c)
    //     0x9bc9ec: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9bc9f0: ldr             x0, [x0, #0x1cd8]
    // 0x9bc9f4: cmp             w0, NULL
    // 0x9bc9f8: b.eq            #0x9bca98
    // 0x9bc9fc: LoadField: r1 = r0->field_ab
    //     0x9bc9fc: ldur            w1, [x0, #0xab]
    // 0x9bca00: DecompressPointer r1
    //     0x9bca00: add             x1, x1, HEAP, lsl #32
    // 0x9bca04: ldr             x0, [fp, #0x18]
    // 0x9bca08: stur            x1, [fp, #-8]
    // 0x9bca0c: r2 = LoadClassIdInstr(r0)
    //     0x9bca0c: ldur            x2, [x0, #-1]
    //     0x9bca10: ubfx            x2, x2, #0xc, #0x14
    // 0x9bca14: lsl             x2, x2, #1
    // 0x9bca18: r17 = 5068
    //     0x9bca18: mov             x17, #0x13cc
    // 0x9bca1c: cmp             w2, w17
    // 0x9bca20: b.ne            #0x9bca4c
    // 0x9bca24: r1 = 1
    //     0x9bca24: mov             x1, #1
    // 0x9bca28: r0 = AllocateContext()
    //     0x9bca28: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9bca2c: mov             x1, x0
    // 0x9bca30: ldr             x0, [fp, #0x18]
    // 0x9bca34: StoreField: r1->field_f = r0
    //     0x9bca34: stur            w0, [x1, #0xf]
    // 0x9bca38: mov             x2, x1
    // 0x9bca3c: r1 = Function 'systemFontsDidChange':.
    //     0x9bca3c: add             x1, PP, #0x22, lsl #12  ; [pp+0x226c0] AnonymousClosure: (0x9bcd34), in [package:flutter/src/rendering/paragraph.dart] RenderParagraph::systemFontsDidChange (0x9bcd7c)
    //     0x9bca40: ldr             x1, [x1, #0x6c0]
    // 0x9bca44: r0 = AllocateClosure()
    //     0x9bca44: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9bca48: b               #0x9bca70
    // 0x9bca4c: r1 = 1
    //     0x9bca4c: mov             x1, #1
    // 0x9bca50: r0 = AllocateContext()
    //     0x9bca50: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9bca54: mov             x1, x0
    // 0x9bca58: ldr             x0, [fp, #0x18]
    // 0x9bca5c: StoreField: r1->field_f = r0
    //     0x9bca5c: stur            w0, [x1, #0xf]
    // 0x9bca60: mov             x2, x1
    // 0x9bca64: r1 = Function 'systemFontsDidChange':.
    //     0x9bca64: add             x1, PP, #0x22, lsl #12  ; [pp+0x226c8] AnonymousClosure: (0x9bcbb8), in [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::systemFontsDidChange (0x9bcc00)
    //     0x9bca68: ldr             x1, [x1, #0x6c8]
    // 0x9bca6c: r0 = AllocateClosure()
    //     0x9bca6c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9bca70: ldur            x16, [fp, #-8]
    // 0x9bca74: stp             x0, x16, [SP, #-0x10]!
    // 0x9bca78: r0 = addListener()
    //     0x9bca78: bl              #0x6e9740  ; [package:flutter/src/painting/binding.dart] _SystemFontsNotifier::addListener
    // 0x9bca7c: add             SP, SP, #0x10
    // 0x9bca80: r0 = Null
    //     0x9bca80: mov             x0, NULL
    // 0x9bca84: LeaveFrame
    //     0x9bca84: mov             SP, fp
    //     0x9bca88: ldp             fp, lr, [SP], #0x10
    // 0x9bca8c: ret
    //     0x9bca8c: ret             
    // 0x9bca90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bca90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bca94: b               #0x9bc9a4
    // 0x9bca98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9bca98: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ systemFontsDidChange(/* No info */) {
    // ** addr: 0x9bcc60, size: 0xd4
    // 0x9bcc60: EnterFrame
    //     0x9bcc60: stp             fp, lr, [SP, #-0x10]!
    //     0x9bcc64: mov             fp, SP
    // 0x9bcc68: CheckStackOverflow
    //     0x9bcc68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bcc6c: cmp             SP, x16
    //     0x9bcc70: b.ls            #0x9bcd2c
    // 0x9bcc74: ldr             x0, [fp, #0x10]
    // 0x9bcc78: r1 = LoadClassIdInstr(r0)
    //     0x9bcc78: ldur            x1, [x0, #-1]
    //     0x9bcc7c: ubfx            x1, x1, #0xc, #0x14
    // 0x9bcc80: lsl             x1, x1, #1
    // 0x9bcc84: r17 = 5074
    //     0x9bcc84: mov             x17, #0x13d2
    // 0x9bcc88: cmp             w1, w17
    // 0x9bcc8c: b.ne            #0x9bccf8
    // 0x9bcc90: SaveReg r0
    //     0x9bcc90: str             x0, [SP, #-8]!
    // 0x9bcc94: r0 = _clearCachedData()
    //     0x9bcc94: bl              #0x5ae21c  ; [package:flutter/src/rendering/box.dart] RenderBox::_clearCachedData
    // 0x9bcc98: add             SP, SP, #8
    // 0x9bcc9c: tbnz            w0, #4, #0x9bcce4
    // 0x9bcca0: ldr             x16, [fp, #0x10]
    // 0x9bcca4: SaveReg r16
    //     0x9bcca4: str             x16, [SP, #-8]!
    // 0x9bcca8: r0 = _function()
    //     0x9bcca8: bl              #0xd60f38  ; [dart:core] _Closure::_function
    // 0x9bccac: add             SP, SP, #8
    // 0x9bccb0: r1 = LoadClassIdInstr(r0)
    //     0x9bccb0: ldur            x1, [x0, #-1]
    //     0x9bccb4: ubfx            x1, x1, #0xc, #0x14
    // 0x9bccb8: lsl             x1, x1, #1
    // 0x9bccbc: r0 = LoadInt32Instr(r1)
    //     0x9bccbc: sbfx            x0, x1, #1, #0x1f
    // 0x9bccc0: cmp             x0, #0x961
    // 0x9bccc4: b.lt            #0x9bcce4
    // 0x9bccc8: cmp             x0, #0xa1f
    // 0x9bcccc: b.gt            #0x9bcce4
    // 0x9bccd0: ldr             x16, [fp, #0x10]
    // 0x9bccd4: SaveReg r16
    //     0x9bccd4: str             x16, [SP, #-8]!
    // 0x9bccd8: r0 = markParentNeedsLayout()
    //     0x9bccd8: bl              #0x5ae148  ; [package:flutter/src/rendering/object.dart] RenderObject::markParentNeedsLayout
    // 0x9bccdc: add             SP, SP, #8
    // 0x9bcce0: b               #0x9bcd1c
    // 0x9bcce4: ldr             x16, [fp, #0x10]
    // 0x9bcce8: SaveReg r16
    //     0x9bcce8: str             x16, [SP, #-8]!
    // 0x9bccec: r0 = markNeedsLayout()
    //     0x9bccec: bl              #0x6c0ee8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsLayout
    // 0x9bccf0: add             SP, SP, #8
    // 0x9bccf4: b               #0x9bcd1c
    // 0x9bccf8: r1 = LoadClassIdInstr(r0)
    //     0x9bccf8: ldur            x1, [x0, #-1]
    //     0x9bccfc: ubfx            x1, x1, #0xc, #0x14
    // 0x9bcd00: SaveReg r0
    //     0x9bcd00: str             x0, [SP, #-8]!
    // 0x9bcd04: mov             x0, x1
    // 0x9bcd08: r0 = GDT[cid_x0 + 0xcfc6]()
    //     0x9bcd08: mov             x17, #0xcfc6
    //     0x9bcd0c: add             lr, x0, x17
    //     0x9bcd10: ldr             lr, [x21, lr, lsl #3]
    //     0x9bcd14: blr             lr
    // 0x9bcd18: add             SP, SP, #8
    // 0x9bcd1c: r0 = Null
    //     0x9bcd1c: mov             x0, NULL
    // 0x9bcd20: LeaveFrame
    //     0x9bcd20: mov             SP, fp
    //     0x9bcd24: ldp             fp, lr, [SP], #0x10
    // 0x9bcd28: ret
    //     0x9bcd28: ret             
    // 0x9bcd2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bcd2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bcd30: b               #0x9bcc74
  }
  _ detach(/* No info */) {
    // ** addr: 0xa68bb0, size: 0xc8
    // 0xa68bb0: EnterFrame
    //     0xa68bb0: stp             fp, lr, [SP, #-0x10]!
    //     0xa68bb4: mov             fp, SP
    // 0xa68bb8: AllocStack(0x8)
    //     0xa68bb8: sub             SP, SP, #8
    // 0xa68bbc: CheckStackOverflow
    //     0xa68bbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa68bc0: cmp             SP, x16
    //     0xa68bc4: b.ls            #0xa68c70
    // 0xa68bc8: r0 = instance()
    //     0xa68bc8: bl              #0x9bca9c  ; [package:flutter/src/painting/binding.dart] PaintingBinding::instance
    // 0xa68bcc: LoadField: r1 = r0->field_ab
    //     0xa68bcc: ldur            w1, [x0, #0xab]
    // 0xa68bd0: DecompressPointer r1
    //     0xa68bd0: add             x1, x1, HEAP, lsl #32
    // 0xa68bd4: ldr             x0, [fp, #0x10]
    // 0xa68bd8: stur            x1, [fp, #-8]
    // 0xa68bdc: r2 = LoadClassIdInstr(r0)
    //     0xa68bdc: ldur            x2, [x0, #-1]
    //     0xa68be0: ubfx            x2, x2, #0xc, #0x14
    // 0xa68be4: lsl             x2, x2, #1
    // 0xa68be8: r17 = 5068
    //     0xa68be8: mov             x17, #0x13cc
    // 0xa68bec: cmp             w2, w17
    // 0xa68bf0: b.ne            #0xa68c1c
    // 0xa68bf4: r1 = 1
    //     0xa68bf4: mov             x1, #1
    // 0xa68bf8: r0 = AllocateContext()
    //     0xa68bf8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa68bfc: mov             x1, x0
    // 0xa68c00: ldr             x0, [fp, #0x10]
    // 0xa68c04: StoreField: r1->field_f = r0
    //     0xa68c04: stur            w0, [x1, #0xf]
    // 0xa68c08: mov             x2, x1
    // 0xa68c0c: r1 = Function 'systemFontsDidChange':.
    //     0xa68c0c: add             x1, PP, #0x22, lsl #12  ; [pp+0x226c0] AnonymousClosure: (0x9bcd34), in [package:flutter/src/rendering/paragraph.dart] RenderParagraph::systemFontsDidChange (0x9bcd7c)
    //     0xa68c10: ldr             x1, [x1, #0x6c0]
    // 0xa68c14: r0 = AllocateClosure()
    //     0xa68c14: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa68c18: b               #0xa68c40
    // 0xa68c1c: r1 = 1
    //     0xa68c1c: mov             x1, #1
    // 0xa68c20: r0 = AllocateContext()
    //     0xa68c20: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa68c24: mov             x1, x0
    // 0xa68c28: ldr             x0, [fp, #0x10]
    // 0xa68c2c: StoreField: r1->field_f = r0
    //     0xa68c2c: stur            w0, [x1, #0xf]
    // 0xa68c30: mov             x2, x1
    // 0xa68c34: r1 = Function 'systemFontsDidChange':.
    //     0xa68c34: add             x1, PP, #0x22, lsl #12  ; [pp+0x226c8] AnonymousClosure: (0x9bcbb8), in [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::systemFontsDidChange (0x9bcc00)
    //     0xa68c38: ldr             x1, [x1, #0x6c8]
    // 0xa68c3c: r0 = AllocateClosure()
    //     0xa68c3c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa68c40: ldur            x16, [fp, #-8]
    // 0xa68c44: stp             x0, x16, [SP, #-0x10]!
    // 0xa68c48: r0 = removeListener()
    //     0xa68c48: bl              #0x6f63c0  ; [package:flutter/src/painting/binding.dart] _SystemFontsNotifier::removeListener
    // 0xa68c4c: add             SP, SP, #0x10
    // 0xa68c50: ldr             x16, [fp, #0x10]
    // 0xa68c54: SaveReg r16
    //     0xa68c54: str             x16, [SP, #-8]!
    // 0xa68c58: r0 = detach()
    //     0xa68c58: bl              #0xa68c78  ; [package:flutter/src/rendering/paragraph.dart] _RenderParagraph&RenderBox&ContainerRenderObjectMixin::detach
    // 0xa68c5c: add             SP, SP, #8
    // 0xa68c60: r0 = Null
    //     0xa68c60: mov             x0, NULL
    // 0xa68c64: LeaveFrame
    //     0xa68c64: mov             SP, fp
    //     0xa68c68: ldp             fp, lr, [SP], #0x10
    // 0xa68c6c: ret
    //     0xa68c6c: ret             
    // 0xa68c70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa68c70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa68c74: b               #0xa68bc8
  }
}

// class id: 2534, size: 0xac, field offset: 0x70
class RenderParagraph extends _RenderParagraph&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin&RelayoutWhenSystemFontsChangeMixin {

  static late final String _placeholderCharacter; // offset: 0xc28
  late List<PlaceholderSpan> _placeholderSpans; // offset: 0x84

  _ hitTestChildren(/* No info */) {
    // ** addr: 0x624d20, size: 0x3dc
    // 0x624d20: EnterFrame
    //     0x624d20: stp             fp, lr, [SP, #-0x10]!
    //     0x624d24: mov             fp, SP
    // 0x624d28: AllocStack(0x48)
    //     0x624d28: sub             SP, SP, #0x48
    // 0x624d2c: CheckStackOverflow
    //     0x624d2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x624d30: cmp             SP, x16
    //     0x624d34: b.ls            #0x6250dc
    // 0x624d38: ldr             x0, [fp, #0x20]
    // 0x624d3c: LoadField: r1 = r0->field_6f
    //     0x624d3c: ldur            w1, [x0, #0x6f]
    // 0x624d40: DecompressPointer r1
    //     0x624d40: add             x1, x1, HEAP, lsl #32
    // 0x624d44: stur            x1, [fp, #-8]
    // 0x624d48: ldr             x16, [fp, #0x10]
    // 0x624d4c: stp             x16, x1, [SP, #-0x10]!
    // 0x624d50: r0 = getPositionForOffset()
    //     0x624d50: bl              #0x6246bc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getPositionForOffset
    // 0x624d54: add             SP, SP, #0x10
    // 0x624d58: mov             x1, x0
    // 0x624d5c: ldur            x0, [fp, #-8]
    // 0x624d60: stur            x1, [fp, #-0x18]
    // 0x624d64: LoadField: r2 = r0->field_f
    //     0x624d64: ldur            w2, [x0, #0xf]
    // 0x624d68: DecompressPointer r2
    //     0x624d68: add             x2, x2, HEAP, lsl #32
    // 0x624d6c: stur            x2, [fp, #-0x10]
    // 0x624d70: cmp             w2, NULL
    // 0x624d74: b.eq            #0x6250e4
    // 0x624d78: r3 = LoadClassIdInstr(r2)
    //     0x624d78: ldur            x3, [x2, #-1]
    //     0x624d7c: ubfx            x3, x3, #0xc, #0x14
    // 0x624d80: lsl             x3, x3, #1
    // 0x624d84: r17 = 6958
    //     0x624d84: mov             x17, #0x1b2e
    // 0x624d88: cmp             w3, w17
    // 0x624d8c: b.gt            #0x624da4
    // 0x624d90: r17 = 6954
    //     0x624d90: mov             x17, #0x1b2a
    // 0x624d94: cmp             w3, w17
    // 0x624d98: b.lt            #0x624da4
    // 0x624d9c: r3 = Null
    //     0x624d9c: mov             x3, NULL
    // 0x624da0: b               #0x624e04
    // 0x624da4: r1 = 3
    //     0x624da4: mov             x1, #3
    // 0x624da8: r0 = AllocateContext()
    //     0x624da8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x624dac: mov             x1, x0
    // 0x624db0: ldur            x0, [fp, #-0x18]
    // 0x624db4: stur            x1, [fp, #-0x20]
    // 0x624db8: StoreField: r1->field_f = r0
    //     0x624db8: stur            w0, [x1, #0xf]
    // 0x624dbc: r0 = Accumulator()
    //     0x624dbc: bl              #0x522218  ; AllocateAccumulatorStub -> Accumulator (size=0x10)
    // 0x624dc0: mov             x1, x0
    // 0x624dc4: r0 = 0
    //     0x624dc4: mov             x0, #0
    // 0x624dc8: StoreField: r1->field_7 = r0
    //     0x624dc8: stur            x0, [x1, #7]
    // 0x624dcc: ldur            x0, [fp, #-0x20]
    // 0x624dd0: StoreField: r0->field_13 = r1
    //     0x624dd0: stur            w1, [x0, #0x13]
    // 0x624dd4: mov             x2, x0
    // 0x624dd8: r1 = Function '<anonymous closure>':.
    //     0x624dd8: add             x1, PP, #0x22, lsl #12  ; [pp+0x22488] AnonymousClosure: (0x624c1c), of [package:flutter/src/painting/inline_span.dart] InlineSpan
    //     0x624ddc: ldr             x1, [x1, #0x488]
    // 0x624de0: r0 = AllocateClosure()
    //     0x624de0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x624de4: ldur            x16, [fp, #-0x10]
    // 0x624de8: stp             x0, x16, [SP, #-0x10]!
    // 0x624dec: r0 = visitChildren()
    //     0x624dec: bl              #0xcdf548  ; [package:flutter/src/painting/text_span.dart] TextSpan::visitChildren
    // 0x624df0: add             SP, SP, #0x10
    // 0x624df4: ldur            x0, [fp, #-0x20]
    // 0x624df8: LoadField: r1 = r0->field_17
    //     0x624df8: ldur            w1, [x0, #0x17]
    // 0x624dfc: DecompressPointer r1
    //     0x624dfc: add             x1, x1, HEAP, lsl #32
    // 0x624e00: mov             x3, x1
    // 0x624e04: stur            x3, [fp, #-0x10]
    // 0x624e08: cmp             w3, NULL
    // 0x624e0c: b.eq            #0x624e90
    // 0x624e10: mov             x0, x3
    // 0x624e14: r2 = Null
    //     0x624e14: mov             x2, NULL
    // 0x624e18: r1 = Null
    //     0x624e18: mov             x1, NULL
    // 0x624e1c: cmp             w0, NULL
    // 0x624e20: b.eq            #0x624e50
    // 0x624e24: branchIfSmi(r0, 0x624e50)
    //     0x624e24: tbz             w0, #0, #0x624e50
    // 0x624e28: r3 = LoadClassIdInstr(r0)
    //     0x624e28: ldur            x3, [x0, #-1]
    //     0x624e2c: ubfx            x3, x3, #0xc, #0x14
    // 0x624e30: sub             x3, x3, #0x961
    // 0x624e34: cmp             x3, #0xbe
    // 0x624e38: b.ls            #0x624e58
    // 0x624e3c: cmp             x3, #0xf8
    // 0x624e40: b.eq            #0x624e58
    // 0x624e44: sub             x3, x3, #0x430
    // 0x624e48: cmp             x3, #2
    // 0x624e4c: b.ls            #0x624e58
    // 0x624e50: r0 = false
    //     0x624e50: add             x0, NULL, #0x30  ; false
    // 0x624e54: b               #0x624e5c
    // 0x624e58: r0 = true
    //     0x624e58: add             x0, NULL, #0x20  ; true
    // 0x624e5c: tbnz            w0, #4, #0x624e90
    // 0x624e60: ldur            x0, [fp, #-0x10]
    // 0x624e64: r1 = <HitTestTarget>
    //     0x624e64: ldr             x1, [PP, #0x38d0]  ; [pp+0x38d0] TypeArguments: <HitTestTarget>
    // 0x624e68: r0 = HitTestEntry()
    //     0x624e68: bl              #0x50edf8  ; AllocateHitTestEntryStub -> HitTestEntry<X0 bound HitTestTarget> (size=0x14)
    // 0x624e6c: mov             x1, x0
    // 0x624e70: ldur            x0, [fp, #-0x10]
    // 0x624e74: StoreField: r1->field_b = r0
    //     0x624e74: stur            w0, [x1, #0xb]
    // 0x624e78: ldr             x16, [fp, #0x18]
    // 0x624e7c: stp             x1, x16, [SP, #-0x10]!
    // 0x624e80: r0 = add()
    //     0x624e80: bl              #0x50ea24  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::add
    // 0x624e84: add             SP, SP, #0x10
    // 0x624e88: r1 = true
    //     0x624e88: add             x1, NULL, #0x20  ; true
    // 0x624e8c: b               #0x624e94
    // 0x624e90: r1 = false
    //     0x624e90: add             x1, NULL, #0x30  ; false
    // 0x624e94: ldr             x0, [fp, #0x20]
    // 0x624e98: stur            x1, [fp, #-0x18]
    // 0x624e9c: LoadField: r2 = r0->field_67
    //     0x624e9c: ldur            w2, [x0, #0x67]
    // 0x624ea0: DecompressPointer r2
    //     0x624ea0: add             x2, x2, HEAP, lsl #32
    // 0x624ea4: stur            x2, [fp, #-0x10]
    // 0x624ea8: r1 = 1
    //     0x624ea8: mov             x1, #1
    // 0x624eac: r0 = AllocateContext()
    //     0x624eac: bl              #0xd68aa4  ; AllocateContextStub
    // 0x624eb0: mov             x3, x0
    // 0x624eb4: ldur            x0, [fp, #-0x10]
    // 0x624eb8: stur            x3, [fp, #-0x20]
    // 0x624ebc: StoreField: r3->field_f = r0
    //     0x624ebc: stur            w0, [x3, #0xf]
    // 0x624ec0: r5 = 0
    //     0x624ec0: mov             x5, #0
    // 0x624ec4: ldur            x4, [fp, #-8]
    // 0x624ec8: stur            x5, [fp, #-0x28]
    // 0x624ecc: CheckStackOverflow
    //     0x624ecc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x624ed0: cmp             SP, x16
    //     0x624ed4: b.ls            #0x6250e8
    // 0x624ed8: cmp             w0, NULL
    // 0x624edc: b.eq            #0x6250cc
    // 0x624ee0: LoadField: r1 = r4->field_3f
    //     0x624ee0: ldur            w1, [x4, #0x3f]
    // 0x624ee4: DecompressPointer r1
    //     0x624ee4: add             x1, x1, HEAP, lsl #32
    // 0x624ee8: cmp             w1, NULL
    // 0x624eec: b.eq            #0x6250f0
    // 0x624ef0: LoadField: r2 = r1->field_b
    //     0x624ef0: ldur            w2, [x1, #0xb]
    // 0x624ef4: DecompressPointer r2
    //     0x624ef4: add             x2, x2, HEAP, lsl #32
    // 0x624ef8: r1 = LoadInt32Instr(r2)
    //     0x624ef8: sbfx            x1, x2, #1, #0x1f
    // 0x624efc: cmp             x5, x1
    // 0x624f00: b.ge            #0x6250cc
    // 0x624f04: LoadField: r6 = r0->field_17
    //     0x624f04: ldur            w6, [x0, #0x17]
    // 0x624f08: DecompressPointer r6
    //     0x624f08: add             x6, x6, HEAP, lsl #32
    // 0x624f0c: stur            x6, [fp, #-0x10]
    // 0x624f10: cmp             w6, NULL
    // 0x624f14: b.eq            #0x6250f4
    // 0x624f18: mov             x0, x6
    // 0x624f1c: r2 = Null
    //     0x624f1c: mov             x2, NULL
    // 0x624f20: r1 = Null
    //     0x624f20: mov             x1, NULL
    // 0x624f24: r4 = LoadClassIdInstr(r0)
    //     0x624f24: ldur            x4, [x0, #-1]
    //     0x624f28: ubfx            x4, x4, #0xc, #0x14
    // 0x624f2c: cmp             x4, #0x808
    // 0x624f30: b.eq            #0x624f48
    // 0x624f34: r8 = TextParentData<RenderBox>
    //     0x624f34: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x624f38: ldr             x8, [x8, #0x298]
    // 0x624f3c: r3 = Null
    //     0x624f3c: add             x3, PP, #0x22, lsl #12  ; [pp+0x22490] Null
    //     0x624f40: ldr             x3, [x3, #0x490]
    // 0x624f44: r0 = DefaultTypeTest()
    //     0x624f44: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x624f48: ldur            x0, [fp, #-0x10]
    // 0x624f4c: LoadField: r1 = r0->field_7
    //     0x624f4c: ldur            w1, [x0, #7]
    // 0x624f50: DecompressPointer r1
    //     0x624f50: add             x1, x1, HEAP, lsl #32
    // 0x624f54: LoadField: d0 = r1->field_7
    //     0x624f54: ldur            d0, [x1, #7]
    // 0x624f58: stur            d0, [fp, #-0x48]
    // 0x624f5c: LoadField: d1 = r1->field_f
    //     0x624f5c: ldur            d1, [x1, #0xf]
    // 0x624f60: stur            d1, [fp, #-0x40]
    // 0x624f64: r0 = Matrix4()
    //     0x624f64: bl              #0x50ace8  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x624f68: r4 = 32
    //     0x624f68: mov             x4, #0x20
    // 0x624f6c: stur            x0, [fp, #-0x30]
    // 0x624f70: r0 = AllocateFloat64Array()
    //     0x624f70: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0x624f74: mov             x1, x0
    // 0x624f78: ldur            x0, [fp, #-0x30]
    // 0x624f7c: stur            x1, [fp, #-0x38]
    // 0x624f80: StoreField: r0->field_7 = r1
    //     0x624f80: stur            w1, [x0, #7]
    // 0x624f84: SaveReg r0
    //     0x624f84: str             x0, [SP, #-8]!
    // 0x624f88: r0 = setIdentity()
    //     0x624f88: bl              #0x50f090  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0x624f8c: add             SP, SP, #8
    // 0x624f90: ldur            x0, [fp, #-0x38]
    // 0x624f94: StoreField: r0->field_87 = rZR
    //     0x624f94: stur            xzr, [x0, #0x87]
    // 0x624f98: ldur            d0, [fp, #-0x40]
    // 0x624f9c: StoreField: r0->field_7f = d0
    //     0x624f9c: stur            d0, [x0, #0x7f]
    // 0x624fa0: ldur            d0, [fp, #-0x48]
    // 0x624fa4: StoreField: r0->field_77 = d0
    //     0x624fa4: stur            d0, [x0, #0x77]
    // 0x624fa8: ldur            x0, [fp, #-0x10]
    // 0x624fac: LoadField: r1 = r0->field_17
    //     0x624fac: ldur            w1, [x0, #0x17]
    // 0x624fb0: DecompressPointer r1
    //     0x624fb0: add             x1, x1, HEAP, lsl #32
    // 0x624fb4: ldur            x16, [fp, #-0x30]
    // 0x624fb8: stp             x1, x16, [SP, #-0x10]!
    // 0x624fbc: stp             x1, x1, [SP, #-0x10]!
    // 0x624fc0: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x624fc0: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x624fc4: r0 = scale()
    //     0x624fc4: bl              #0x50b298  ; [package:vector_math/vector_math_64.dart] Matrix4::scale
    // 0x624fc8: add             SP, SP, #0x20
    // 0x624fcc: ldur            x16, [fp, #-0x30]
    // 0x624fd0: SaveReg r16
    //     0x624fd0: str             x16, [SP, #-8]!
    // 0x624fd4: r0 = removePerspectiveTransform()
    //     0x624fd4: bl              #0x623918  ; [package:flutter/src/gestures/events.dart] PointerEvent::removePerspectiveTransform
    // 0x624fd8: add             SP, SP, #8
    // 0x624fdc: SaveReg r0
    //     0x624fdc: str             x0, [SP, #-8]!
    // 0x624fe0: r0 = tryInvert()
    //     0x624fe0: bl              #0x623294  ; [package:vector_math/vector_math_64.dart] Matrix4::tryInvert
    // 0x624fe4: add             SP, SP, #8
    // 0x624fe8: stur            x0, [fp, #-0x10]
    // 0x624fec: cmp             w0, NULL
    // 0x624ff0: b.eq            #0x625034
    // 0x624ff4: ldur            x2, [fp, #-0x20]
    // 0x624ff8: r1 = Function '<anonymous closure>':.
    //     0x624ff8: add             x1, PP, #0x22, lsl #12  ; [pp+0x224a0] AnonymousClosure: (0x62510c), in [package:flutter/src/rendering/paragraph.dart] RenderParagraph::hitTestChildren (0x624d20)
    //     0x624ffc: ldr             x1, [x1, #0x4a0]
    // 0x625000: r0 = AllocateClosure()
    //     0x625000: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x625004: ldr             x16, [fp, #0x18]
    // 0x625008: stp             x0, x16, [SP, #-0x10]!
    // 0x62500c: ldr             x16, [fp, #0x10]
    // 0x625010: ldur            lr, [fp, #-0x10]
    // 0x625014: stp             lr, x16, [SP, #-0x10]!
    // 0x625018: r0 = addWithRawTransform()
    //     0x625018: bl              #0x622f84  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithRawTransform
    // 0x62501c: add             SP, SP, #0x20
    // 0x625020: tbnz            w0, #4, #0x625034
    // 0x625024: r0 = true
    //     0x625024: add             x0, NULL, #0x20  ; true
    // 0x625028: LeaveFrame
    //     0x625028: mov             SP, fp
    //     0x62502c: ldp             fp, lr, [SP], #0x10
    // 0x625030: ret
    //     0x625030: ret             
    // 0x625034: ldur            x3, [fp, #-0x20]
    // 0x625038: ldur            x4, [fp, #-0x28]
    // 0x62503c: LoadField: r0 = r3->field_f
    //     0x62503c: ldur            w0, [x3, #0xf]
    // 0x625040: DecompressPointer r0
    //     0x625040: add             x0, x0, HEAP, lsl #32
    // 0x625044: LoadField: r5 = r0->field_17
    //     0x625044: ldur            w5, [x0, #0x17]
    // 0x625048: DecompressPointer r5
    //     0x625048: add             x5, x5, HEAP, lsl #32
    // 0x62504c: stur            x5, [fp, #-0x10]
    // 0x625050: cmp             w5, NULL
    // 0x625054: b.eq            #0x6250f8
    // 0x625058: mov             x0, x5
    // 0x62505c: r2 = Null
    //     0x62505c: mov             x2, NULL
    // 0x625060: r1 = Null
    //     0x625060: mov             x1, NULL
    // 0x625064: r4 = LoadClassIdInstr(r0)
    //     0x625064: ldur            x4, [x0, #-1]
    //     0x625068: ubfx            x4, x4, #0xc, #0x14
    // 0x62506c: cmp             x4, #0x808
    // 0x625070: b.eq            #0x625088
    // 0x625074: r8 = TextParentData<RenderBox>
    //     0x625074: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x625078: ldr             x8, [x8, #0x298]
    // 0x62507c: r3 = Null
    //     0x62507c: add             x3, PP, #0x22, lsl #12  ; [pp+0x224a8] Null
    //     0x625080: ldr             x3, [x3, #0x4a8]
    // 0x625084: r0 = DefaultTypeTest()
    //     0x625084: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x625088: ldur            x1, [fp, #-0x10]
    // 0x62508c: LoadField: r2 = r1->field_13
    //     0x62508c: ldur            w2, [x1, #0x13]
    // 0x625090: DecompressPointer r2
    //     0x625090: add             x2, x2, HEAP, lsl #32
    // 0x625094: mov             x0, x2
    // 0x625098: ldur            x1, [fp, #-0x20]
    // 0x62509c: StoreField: r1->field_f = r0
    //     0x62509c: stur            w0, [x1, #0xf]
    //     0x6250a0: ldurb           w16, [x1, #-1]
    //     0x6250a4: ldurb           w17, [x0, #-1]
    //     0x6250a8: and             x16, x17, x16, lsr #2
    //     0x6250ac: tst             x16, HEAP, lsr #32
    //     0x6250b0: b.eq            #0x6250b8
    //     0x6250b4: bl              #0xd6826c
    // 0x6250b8: ldur            x3, [fp, #-0x28]
    // 0x6250bc: add             x5, x3, #1
    // 0x6250c0: mov             x0, x2
    // 0x6250c4: mov             x3, x1
    // 0x6250c8: b               #0x624ec4
    // 0x6250cc: ldur            x0, [fp, #-0x18]
    // 0x6250d0: LeaveFrame
    //     0x6250d0: mov             SP, fp
    //     0x6250d4: ldp             fp, lr, [SP], #0x10
    // 0x6250d8: ret
    //     0x6250d8: ret             
    // 0x6250dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6250dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6250e0: b               #0x624d38
    // 0x6250e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6250e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6250e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6250e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6250ec: b               #0x624ed8
    // 0x6250f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6250f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6250f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6250f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6250f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6250f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, BoxHitTestResult, Offset) {
    // ** addr: 0x62510c, size: 0x78
    // 0x62510c: EnterFrame
    //     0x62510c: stp             fp, lr, [SP, #-0x10]!
    //     0x625110: mov             fp, SP
    // 0x625114: ldr             x0, [fp, #0x20]
    // 0x625118: LoadField: r1 = r0->field_17
    //     0x625118: ldur            w1, [x0, #0x17]
    // 0x62511c: DecompressPointer r1
    //     0x62511c: add             x1, x1, HEAP, lsl #32
    // 0x625120: CheckStackOverflow
    //     0x625120: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x625124: cmp             SP, x16
    //     0x625128: b.ls            #0x625178
    // 0x62512c: LoadField: r0 = r1->field_f
    //     0x62512c: ldur            w0, [x1, #0xf]
    // 0x625130: DecompressPointer r0
    //     0x625130: add             x0, x0, HEAP, lsl #32
    // 0x625134: cmp             w0, NULL
    // 0x625138: b.eq            #0x625180
    // 0x62513c: r1 = LoadClassIdInstr(r0)
    //     0x62513c: ldur            x1, [x0, #-1]
    //     0x625140: ubfx            x1, x1, #0xc, #0x14
    // 0x625144: ldr             x16, [fp, #0x18]
    // 0x625148: stp             x16, x0, [SP, #-0x10]!
    // 0x62514c: ldr             x16, [fp, #0x10]
    // 0x625150: SaveReg r16
    //     0x625150: str             x16, [SP, #-8]!
    // 0x625154: mov             x0, x1
    // 0x625158: r0 = GDT[cid_x0 + 0xefa2]()
    //     0x625158: mov             x17, #0xefa2
    //     0x62515c: add             lr, x0, x17
    //     0x625160: ldr             lr, [x21, lr, lsl #3]
    //     0x625164: blr             lr
    // 0x625168: add             SP, SP, #0x18
    // 0x62516c: LeaveFrame
    //     0x62516c: mov             SP, fp
    //     0x625170: ldp             fp, lr, [SP], #0x10
    // 0x625174: ret
    //     0x625174: ret             
    // 0x625178: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x625178: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62517c: b               #0x62512c
    // 0x625180: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x625180: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x62d9cc, size: 0x18
    // 0x62d9cc: r4 = 0
    //     0x62d9cc: mov             x4, #0
    // 0x62d9d0: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x62d9d0: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4bbc0] AnonymousClosure: (0x62d9e4), of [package:flutter/src/rendering/paragraph.dart] RenderParagraph
    //     0x62d9d4: ldr             x1, [x17, #0xbc0]
    // 0x62d9d8: r24 = BuildNonGenericMethodExtractorStub
    //     0x62d9d8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x62d9dc: LoadField: r0 = r24->field_17
    //     0x62d9dc: ldur            x0, [x24, #0x17]
    // 0x62d9e0: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x62d9e4, size: 0x8c
    // 0x62d9e4: EnterFrame
    //     0x62d9e4: stp             fp, lr, [SP, #-0x10]!
    //     0x62d9e8: mov             fp, SP
    // 0x62d9ec: ldr             x0, [fp, #0x18]
    // 0x62d9f0: LoadField: r1 = r0->field_17
    //     0x62d9f0: ldur            w1, [x0, #0x17]
    // 0x62d9f4: DecompressPointer r1
    //     0x62d9f4: add             x1, x1, HEAP, lsl #32
    // 0x62d9f8: CheckStackOverflow
    //     0x62d9f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62d9fc: cmp             SP, x16
    //     0x62da00: b.ls            #0x62da58
    // 0x62da04: LoadField: r0 = r1->field_f
    //     0x62da04: ldur            w0, [x1, #0xf]
    // 0x62da08: DecompressPointer r0
    //     0x62da08: add             x0, x0, HEAP, lsl #32
    // 0x62da0c: ldr             x1, [fp, #0x10]
    // 0x62da10: LoadField: d0 = r1->field_7
    //     0x62da10: ldur            d0, [x1, #7]
    // 0x62da14: SaveReg r0
    //     0x62da14: str             x0, [SP, #-8]!
    // 0x62da18: SaveReg d0
    //     0x62da18: str             d0, [SP, #-8]!
    // 0x62da1c: r0 = _computeIntrinsicHeight()
    //     0x62da1c: bl              #0x62da70  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_computeIntrinsicHeight
    // 0x62da20: add             SP, SP, #0x10
    // 0x62da24: r0 = inline_Allocate_Double()
    //     0x62da24: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62da28: add             x0, x0, #0x10
    //     0x62da2c: cmp             x1, x0
    //     0x62da30: b.ls            #0x62da60
    //     0x62da34: str             x0, [THR, #0x60]  ; THR::top
    //     0x62da38: sub             x0, x0, #0xf
    //     0x62da3c: mov             x1, #0xd108
    //     0x62da40: movk            x1, #3, lsl #16
    //     0x62da44: stur            x1, [x0, #-1]
    // 0x62da48: StoreField: r0->field_7 = d0
    //     0x62da48: stur            d0, [x0, #7]
    // 0x62da4c: LeaveFrame
    //     0x62da4c: mov             SP, fp
    //     0x62da50: ldp             fp, lr, [SP], #0x10
    // 0x62da54: ret
    //     0x62da54: ret             
    // 0x62da58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62da58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62da5c: b               #0x62da04
    // 0x62da60: SaveReg d0
    //     0x62da60: str             q0, [SP, #-0x10]!
    // 0x62da64: r0 = AllocateDouble()
    //     0x62da64: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62da68: RestoreReg d0
    //     0x62da68: ldr             q0, [SP], #0x10
    // 0x62da6c: b               #0x62da48
  }
  _ _computeIntrinsicHeight(/* No info */) {
    // ** addr: 0x62da70, size: 0x11c
    // 0x62da70: EnterFrame
    //     0x62da70: stp             fp, lr, [SP, #-0x10]!
    //     0x62da74: mov             fp, SP
    // 0x62da78: CheckStackOverflow
    //     0x62da78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62da7c: cmp             SP, x16
    //     0x62da80: b.ls            #0x62db70
    // 0x62da84: ldr             x16, [fp, #0x18]
    // 0x62da88: SaveReg r16
    //     0x62da88: str             x16, [SP, #-8]!
    // 0x62da8c: r0 = _canComputeIntrinsics()
    //     0x62da8c: bl              #0x62e0a0  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_canComputeIntrinsics
    // 0x62da90: add             SP, SP, #8
    // 0x62da94: tbz             w0, #4, #0x62daa8
    // 0x62da98: d0 = 0.000000
    //     0x62da98: eor             v0.16b, v0.16b, v0.16b
    // 0x62da9c: LeaveFrame
    //     0x62da9c: mov             SP, fp
    //     0x62daa0: ldp             fp, lr, [SP], #0x10
    // 0x62daa4: ret
    //     0x62daa4: ret             
    // 0x62daa8: ldr             x0, [fp, #0x18]
    // 0x62daac: ldr             d0, [fp, #0x10]
    // 0x62dab0: SaveReg r0
    //     0x62dab0: str             x0, [SP, #-8]!
    // 0x62dab4: SaveReg d0
    //     0x62dab4: str             d0, [SP, #-8]!
    // 0x62dab8: r0 = _computeChildrenHeightWithMinIntrinsics()
    //     0x62dab8: bl              #0x62dd44  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_computeChildrenHeightWithMinIntrinsics
    // 0x62dabc: add             SP, SP, #0x10
    // 0x62dac0: ldr             d0, [fp, #0x10]
    // 0x62dac4: r0 = inline_Allocate_Double()
    //     0x62dac4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62dac8: add             x0, x0, #0x10
    //     0x62dacc: cmp             x1, x0
    //     0x62dad0: b.ls            #0x62db78
    //     0x62dad4: str             x0, [THR, #0x60]  ; THR::top
    //     0x62dad8: sub             x0, x0, #0xf
    //     0x62dadc: mov             x1, #0xd108
    //     0x62dae0: movk            x1, #3, lsl #16
    //     0x62dae4: stur            x1, [x0, #-1]
    // 0x62dae8: StoreField: r0->field_7 = d0
    //     0x62dae8: stur            d0, [x0, #7]
    // 0x62daec: ldr             x16, [fp, #0x18]
    // 0x62daf0: stp             x0, x16, [SP, #-0x10]!
    // 0x62daf4: SaveReg r0
    //     0x62daf4: str             x0, [SP, #-8]!
    // 0x62daf8: r4 = const [0, 0x3, 0x3, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0x62daf8: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f588] List(9) [0, 0x3, 0x3, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    //     0x62dafc: ldr             x4, [x4, #0x588]
    // 0x62db00: r0 = _layoutText()
    //     0x62db00: bl              #0x62db8c  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_layoutText
    // 0x62db04: add             SP, SP, #0x18
    // 0x62db08: ldr             x0, [fp, #0x18]
    // 0x62db0c: LoadField: r1 = r0->field_6f
    //     0x62db0c: ldur            w1, [x0, #0x6f]
    // 0x62db10: DecompressPointer r1
    //     0x62db10: add             x1, x1, HEAP, lsl #32
    // 0x62db14: LoadField: r0 = r1->field_7
    //     0x62db14: ldur            w0, [x1, #7]
    // 0x62db18: DecompressPointer r0
    //     0x62db18: add             x0, x0, HEAP, lsl #32
    // 0x62db1c: cmp             w0, NULL
    // 0x62db20: b.eq            #0x62db88
    // 0x62db24: SaveReg r0
    //     0x62db24: str             x0, [SP, #-8]!
    // 0x62db28: r0 = height()
    //     0x62db28: bl              #0x51a4dc  ; [dart:ui] Paragraph::height
    // 0x62db2c: add             SP, SP, #8
    // 0x62db30: stp             fp, lr, [SP, #-0x10]!
    // 0x62db34: mov             fp, SP
    // 0x62db38: CallRuntime_LibcCeil(double) -> double
    //     0x62db38: and             SP, SP, #0xfffffffffffffff0
    //     0x62db3c: mov             sp, SP
    //     0x62db40: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x62db44: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x62db48: blr             x16
    //     0x62db4c: mov             x16, #8
    //     0x62db50: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x62db54: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x62db58: sub             sp, x16, #1, lsl #12
    //     0x62db5c: mov             SP, fp
    //     0x62db60: ldp             fp, lr, [SP], #0x10
    // 0x62db64: LeaveFrame
    //     0x62db64: mov             SP, fp
    //     0x62db68: ldp             fp, lr, [SP], #0x10
    // 0x62db6c: ret
    //     0x62db6c: ret             
    // 0x62db70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62db70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62db74: b               #0x62da84
    // 0x62db78: SaveReg d0
    //     0x62db78: str             q0, [SP, #-0x10]!
    // 0x62db7c: r0 = AllocateDouble()
    //     0x62db7c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62db80: RestoreReg d0
    //     0x62db80: ldr             q0, [SP], #0x10
    // 0x62db84: b               #0x62dae8
    // 0x62db88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x62db88: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _layoutText(/* No info */) {
    // ** addr: 0x62db8c, size: 0x1b8
    // 0x62db8c: EnterFrame
    //     0x62db8c: stp             fp, lr, [SP, #-0x10]!
    //     0x62db90: mov             fp, SP
    // 0x62db94: mov             x0, x4
    // 0x62db98: LoadField: r1 = r0->field_13
    //     0x62db98: ldur            w1, [x0, #0x13]
    // 0x62db9c: DecompressPointer r1
    //     0x62db9c: add             x1, x1, HEAP, lsl #32
    // 0x62dba0: sub             x2, x1, #2
    // 0x62dba4: add             x3, fp, w2, sxtw #2
    // 0x62dba8: ldr             x3, [x3, #0x10]
    // 0x62dbac: LoadField: r2 = r0->field_1f
    //     0x62dbac: ldur            w2, [x0, #0x1f]
    // 0x62dbb0: DecompressPointer r2
    //     0x62dbb0: add             x2, x2, HEAP, lsl #32
    // 0x62dbb4: r16 = "maxWidth"
    //     0x62dbb4: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f590] "maxWidth"
    //     0x62dbb8: ldr             x16, [x16, #0x590]
    // 0x62dbbc: cmp             w2, w16
    // 0x62dbc0: b.ne            #0x62dbe4
    // 0x62dbc4: LoadField: r2 = r0->field_23
    //     0x62dbc4: ldur            w2, [x0, #0x23]
    // 0x62dbc8: DecompressPointer r2
    //     0x62dbc8: add             x2, x2, HEAP, lsl #32
    // 0x62dbcc: sub             w4, w1, w2
    // 0x62dbd0: add             x2, fp, w4, sxtw #2
    // 0x62dbd4: ldr             x2, [x2, #8]
    // 0x62dbd8: LoadField: d0 = r2->field_7
    //     0x62dbd8: ldur            d0, [x2, #7]
    // 0x62dbdc: r2 = 1
    //     0x62dbdc: mov             x2, #1
    // 0x62dbe0: b               #0x62dbec
    // 0x62dbe4: d0 = inf
    //     0x62dbe4: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62dbe8: r2 = 0
    //     0x62dbe8: mov             x2, #0
    // 0x62dbec: lsl             x4, x2, #1
    // 0x62dbf0: lsl             w2, w4, #1
    // 0x62dbf4: add             w4, w2, #8
    // 0x62dbf8: ArrayLoad: r5 = r0[r4]  ; Unknown_4
    //     0x62dbf8: add             x16, x0, w4, sxtw #1
    //     0x62dbfc: ldur            w5, [x16, #0xf]
    // 0x62dc00: DecompressPointer r5
    //     0x62dc00: add             x5, x5, HEAP, lsl #32
    // 0x62dc04: r16 = "minWidth"
    //     0x62dc04: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f598] "minWidth"
    //     0x62dc08: ldr             x16, [x16, #0x598]
    // 0x62dc0c: cmp             w5, w16
    // 0x62dc10: b.ne            #0x62dc38
    // 0x62dc14: add             w4, w2, #0xa
    // 0x62dc18: ArrayLoad: r2 = r0[r4]  ; Unknown_4
    //     0x62dc18: add             x16, x0, w4, sxtw #1
    //     0x62dc1c: ldur            w2, [x16, #0xf]
    // 0x62dc20: DecompressPointer r2
    //     0x62dc20: add             x2, x2, HEAP, lsl #32
    // 0x62dc24: sub             w0, w1, w2
    // 0x62dc28: add             x1, fp, w0, sxtw #2
    // 0x62dc2c: ldr             x1, [x1, #8]
    // 0x62dc30: LoadField: d1 = r1->field_7
    //     0x62dc30: ldur            d1, [x1, #7]
    // 0x62dc34: b               #0x62dc3c
    // 0x62dc38: d1 = 0.000000
    //     0x62dc38: eor             v1.16b, v1.16b, v1.16b
    // 0x62dc3c: CheckStackOverflow
    //     0x62dc3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62dc40: cmp             SP, x16
    //     0x62dc44: b.ls            #0x62dd08
    // 0x62dc48: LoadField: r0 = r3->field_87
    //     0x62dc48: ldur            w0, [x3, #0x87]
    // 0x62dc4c: DecompressPointer r0
    //     0x62dc4c: add             x0, x0, HEAP, lsl #32
    // 0x62dc50: tbnz            w0, #4, #0x62dc5c
    // 0x62dc54: r0 = true
    //     0x62dc54: add             x0, NULL, #0x20  ; true
    // 0x62dc58: b               #0x62dc80
    // 0x62dc5c: LoadField: r0 = r3->field_8b
    //     0x62dc5c: ldur            w0, [x3, #0x8b]
    // 0x62dc60: DecompressPointer r0
    //     0x62dc60: add             x0, x0, HEAP, lsl #32
    // 0x62dc64: r16 = Instance_TextOverflow
    //     0x62dc64: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d428] Obj!TextOverflow@b64d51
    //     0x62dc68: ldr             x16, [x16, #0x428]
    // 0x62dc6c: cmp             w0, w16
    // 0x62dc70: r16 = true
    //     0x62dc70: add             x16, NULL, #0x20  ; true
    // 0x62dc74: r17 = false
    //     0x62dc74: add             x17, NULL, #0x30  ; false
    // 0x62dc78: csel            x1, x16, x17, eq
    // 0x62dc7c: mov             x0, x1
    // 0x62dc80: LoadField: r1 = r3->field_6f
    //     0x62dc80: ldur            w1, [x3, #0x6f]
    // 0x62dc84: DecompressPointer r1
    //     0x62dc84: add             x1, x1, HEAP, lsl #32
    // 0x62dc88: tbz             w0, #4, #0x62dc90
    // 0x62dc8c: d0 = inf
    //     0x62dc8c: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62dc90: r0 = inline_Allocate_Double()
    //     0x62dc90: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x62dc94: add             x0, x0, #0x10
    //     0x62dc98: cmp             x2, x0
    //     0x62dc9c: b.ls            #0x62dd10
    //     0x62dca0: str             x0, [THR, #0x60]  ; THR::top
    //     0x62dca4: sub             x0, x0, #0xf
    //     0x62dca8: mov             x2, #0xd108
    //     0x62dcac: movk            x2, #3, lsl #16
    //     0x62dcb0: stur            x2, [x0, #-1]
    // 0x62dcb4: StoreField: r0->field_7 = d1
    //     0x62dcb4: stur            d1, [x0, #7]
    // 0x62dcb8: r2 = inline_Allocate_Double()
    //     0x62dcb8: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x62dcbc: add             x2, x2, #0x10
    //     0x62dcc0: cmp             x3, x2
    //     0x62dcc4: b.ls            #0x62dd28
    //     0x62dcc8: str             x2, [THR, #0x60]  ; THR::top
    //     0x62dccc: sub             x2, x2, #0xf
    //     0x62dcd0: mov             x3, #0xd108
    //     0x62dcd4: movk            x3, #3, lsl #16
    //     0x62dcd8: stur            x3, [x2, #-1]
    // 0x62dcdc: StoreField: r2->field_7 = d0
    //     0x62dcdc: stur            d0, [x2, #7]
    // 0x62dce0: stp             x0, x1, [SP, #-0x10]!
    // 0x62dce4: SaveReg r2
    //     0x62dce4: str             x2, [SP, #-8]!
    // 0x62dce8: r4 = const [0, 0x3, 0x3, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0x62dce8: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f588] List(9) [0, 0x3, 0x3, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    //     0x62dcec: ldr             x4, [x4, #0x588]
    // 0x62dcf0: r0 = layout()
    //     0x62dcf0: bl              #0x52362c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::layout
    // 0x62dcf4: add             SP, SP, #0x18
    // 0x62dcf8: r0 = Null
    //     0x62dcf8: mov             x0, NULL
    // 0x62dcfc: LeaveFrame
    //     0x62dcfc: mov             SP, fp
    //     0x62dd00: ldp             fp, lr, [SP], #0x10
    // 0x62dd04: ret
    //     0x62dd04: ret             
    // 0x62dd08: r0 = StackOverflowSharedWithFPURegs()
    //     0x62dd08: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x62dd0c: b               #0x62dc48
    // 0x62dd10: stp             q0, q1, [SP, #-0x20]!
    // 0x62dd14: SaveReg r1
    //     0x62dd14: str             x1, [SP, #-8]!
    // 0x62dd18: r0 = AllocateDouble()
    //     0x62dd18: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62dd1c: RestoreReg r1
    //     0x62dd1c: ldr             x1, [SP], #8
    // 0x62dd20: ldp             q0, q1, [SP], #0x20
    // 0x62dd24: b               #0x62dcb4
    // 0x62dd28: SaveReg d0
    //     0x62dd28: str             q0, [SP, #-0x10]!
    // 0x62dd2c: stp             x0, x1, [SP, #-0x10]!
    // 0x62dd30: r0 = AllocateDouble()
    //     0x62dd30: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62dd34: mov             x2, x0
    // 0x62dd38: ldp             x0, x1, [SP], #0x10
    // 0x62dd3c: RestoreReg d0
    //     0x62dd3c: ldr             q0, [SP], #0x10
    // 0x62dd40: b               #0x62dcdc
  }
  _ _computeChildrenHeightWithMinIntrinsics(/* No info */) {
    // ** addr: 0x62dd44, size: 0x35c
    // 0x62dd44: EnterFrame
    //     0x62dd44: stp             fp, lr, [SP, #-0x10]!
    //     0x62dd48: mov             fp, SP
    // 0x62dd4c: AllocStack(0x48)
    //     0x62dd4c: sub             SP, SP, #0x48
    // 0x62dd50: CheckStackOverflow
    //     0x62dd50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62dd54: cmp             SP, x16
    //     0x62dd58: b.ls            #0x62e06c
    // 0x62dd5c: ldr             x3, [fp, #0x18]
    // 0x62dd60: LoadField: r4 = r3->field_67
    //     0x62dd60: ldur            w4, [x3, #0x67]
    // 0x62dd64: DecompressPointer r4
    //     0x62dd64: add             x4, x4, HEAP, lsl #32
    // 0x62dd68: stur            x4, [fp, #-0x10]
    // 0x62dd6c: LoadField: r5 = r3->field_5f
    //     0x62dd6c: ldur            x5, [x3, #0x5f]
    // 0x62dd70: stur            x5, [fp, #-8]
    // 0x62dd74: r0 = BoxInt64Instr(r5)
    //     0x62dd74: sbfiz           x0, x5, #1, #0x1f
    //     0x62dd78: cmp             x5, x0, asr #1
    //     0x62dd7c: b.eq            #0x62dd88
    //     0x62dd80: bl              #0xd69bb8
    //     0x62dd84: stur            x5, [x0, #7]
    // 0x62dd88: mov             x2, x0
    // 0x62dd8c: r1 = <PlaceholderDimensions>
    //     0x62dd8c: add             x1, PP, #0x22, lsl #12  ; [pp+0x22320] TypeArguments: <PlaceholderDimensions>
    //     0x62dd90: ldr             x1, [x1, #0x320]
    // 0x62dd94: r0 = AllocateArray()
    //     0x62dd94: bl              #0xd6987c  ; AllocateArrayStub
    // 0x62dd98: stur            x0, [fp, #-0x28]
    // 0x62dd9c: ldur            x1, [fp, #-8]
    // 0x62dda0: r2 = 0
    //     0x62dda0: mov             x2, #0
    // 0x62dda4: CheckStackOverflow
    //     0x62dda4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62dda8: cmp             SP, x16
    //     0x62ddac: b.ls            #0x62e074
    // 0x62ddb0: cmp             x2, x1
    // 0x62ddb4: b.ge            #0x62ddd4
    // 0x62ddb8: add             x3, x0, x2, lsl #2
    // 0x62ddbc: r17 = Instance_PlaceholderDimensions
    //     0x62ddbc: add             x17, PP, #0x22, lsl #12  ; [pp+0x22458] Obj!PlaceholderDimensions@b356b1
    //     0x62ddc0: ldr             x17, [x17, #0x458]
    // 0x62ddc4: StoreField: r3->field_f = r17
    //     0x62ddc4: stur            w17, [x3, #0xf]
    // 0x62ddc8: add             x3, x2, #1
    // 0x62ddcc: mov             x2, x3
    // 0x62ddd0: b               #0x62dda4
    // 0x62ddd4: ldr             x2, [fp, #0x18]
    // 0x62ddd8: ldr             d0, [fp, #0x10]
    // 0x62dddc: LoadField: r3 = r2->field_6f
    //     0x62dddc: ldur            w3, [x2, #0x6f]
    // 0x62dde0: DecompressPointer r3
    //     0x62dde0: add             x3, x3, HEAP, lsl #32
    // 0x62dde4: stur            x3, [fp, #-0x20]
    // 0x62dde8: LoadField: d1 = r3->field_1f
    //     0x62dde8: ldur            d1, [x3, #0x1f]
    // 0x62ddec: fdiv            d2, d0, d1
    // 0x62ddf0: stur            d2, [fp, #-0x48]
    // 0x62ddf4: ldur            x5, [fp, #-0x10]
    // 0x62ddf8: r4 = 0
    //     0x62ddf8: mov             x4, #0
    // 0x62ddfc: stur            x5, [fp, #-0x10]
    // 0x62de00: stur            x4, [fp, #-0x18]
    // 0x62de04: CheckStackOverflow
    //     0x62de04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62de08: cmp             SP, x16
    //     0x62de0c: b.ls            #0x62e07c
    // 0x62de10: cmp             w5, NULL
    // 0x62de14: b.eq            #0x62e048
    // 0x62de18: r0 = BoxConstraints()
    //     0x62de18: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x62de1c: d0 = 0.000000
    //     0x62de1c: eor             v0.16b, v0.16b, v0.16b
    // 0x62de20: stur            x0, [fp, #-0x30]
    // 0x62de24: StoreField: r0->field_7 = d0
    //     0x62de24: stur            d0, [x0, #7]
    // 0x62de28: ldur            d1, [fp, #-0x48]
    // 0x62de2c: StoreField: r0->field_f = d1
    //     0x62de2c: stur            d1, [x0, #0xf]
    // 0x62de30: StoreField: r0->field_17 = d0
    //     0x62de30: stur            d0, [x0, #0x17]
    // 0x62de34: d2 = inf
    //     0x62de34: ldr             d2, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62de38: StoreField: r0->field_1f = d2
    //     0x62de38: stur            d2, [x0, #0x1f]
    // 0x62de3c: r1 = 2
    //     0x62de3c: mov             x1, #2
    // 0x62de40: r0 = AllocateContext()
    //     0x62de40: bl              #0xd68aa4  ; AllocateContextStub
    // 0x62de44: mov             x1, x0
    // 0x62de48: ldur            x0, [fp, #-0x10]
    // 0x62de4c: stur            x1, [fp, #-0x38]
    // 0x62de50: StoreField: r1->field_f = r0
    //     0x62de50: stur            w0, [x1, #0xf]
    // 0x62de54: ldur            x2, [fp, #-0x30]
    // 0x62de58: StoreField: r1->field_13 = r2
    //     0x62de58: stur            w2, [x1, #0x13]
    // 0x62de5c: LoadField: r2 = r0->field_53
    //     0x62de5c: ldur            w2, [x0, #0x53]
    // 0x62de60: DecompressPointer r2
    //     0x62de60: add             x2, x2, HEAP, lsl #32
    // 0x62de64: cmp             w2, NULL
    // 0x62de68: b.ne            #0x62deb4
    // 0x62de6c: r16 = <BoxConstraints, Size>
    //     0x62de6c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15208] TypeArguments: <BoxConstraints, Size>
    //     0x62de70: ldr             x16, [x16, #0x208]
    // 0x62de74: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x62de78: stp             lr, x16, [SP, #-0x10]!
    // 0x62de7c: r0 = Map._fromLiteral()
    //     0x62de7c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x62de80: add             SP, SP, #0x10
    // 0x62de84: mov             x1, x0
    // 0x62de88: ldur            x3, [fp, #-0x10]
    // 0x62de8c: StoreField: r3->field_53 = r0
    //     0x62de8c: stur            w0, [x3, #0x53]
    //     0x62de90: tbz             w0, #0, #0x62deac
    //     0x62de94: ldurb           w16, [x3, #-1]
    //     0x62de98: ldurb           w17, [x0, #-1]
    //     0x62de9c: and             x16, x17, x16, lsr #2
    //     0x62dea0: tst             x16, HEAP, lsr #32
    //     0x62dea4: b.eq            #0x62deac
    //     0x62dea8: bl              #0xd682ac
    // 0x62deac: mov             x5, x1
    // 0x62deb0: b               #0x62debc
    // 0x62deb4: mov             x3, x0
    // 0x62deb8: mov             x5, x2
    // 0x62debc: ldr             x0, [fp, #0x18]
    // 0x62dec0: ldur            x4, [fp, #-0x18]
    // 0x62dec4: ldur            x2, [fp, #-0x38]
    // 0x62dec8: stur            x5, [fp, #-0x40]
    // 0x62decc: cmp             w5, NULL
    // 0x62ded0: b.eq            #0x62e084
    // 0x62ded4: LoadField: r6 = r2->field_13
    //     0x62ded4: ldur            w6, [x2, #0x13]
    // 0x62ded8: DecompressPointer r6
    //     0x62ded8: add             x6, x6, HEAP, lsl #32
    // 0x62dedc: stur            x6, [fp, #-0x30]
    // 0x62dee0: r1 = Function '<anonymous closure>':.
    //     0x62dee0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15210] AnonymousClosure: (0x62d778), in [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout (0x62d394)
    //     0x62dee4: ldr             x1, [x1, #0x210]
    // 0x62dee8: r0 = AllocateClosure()
    //     0x62dee8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x62deec: ldur            x16, [fp, #-0x40]
    // 0x62def0: ldur            lr, [fp, #-0x30]
    // 0x62def4: stp             lr, x16, [SP, #-0x10]!
    // 0x62def8: SaveReg r0
    //     0x62def8: str             x0, [SP, #-8]!
    // 0x62defc: r0 = putIfAbsent()
    //     0x62defc: bl              #0xc7a83c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0x62df00: add             SP, SP, #0x18
    // 0x62df04: mov             x3, x0
    // 0x62df08: ldr             x2, [fp, #0x18]
    // 0x62df0c: stur            x3, [fp, #-0x40]
    // 0x62df10: LoadField: r4 = r2->field_83
    //     0x62df10: ldur            w4, [x2, #0x83]
    // 0x62df14: DecompressPointer r4
    //     0x62df14: add             x4, x4, HEAP, lsl #32
    // 0x62df18: r16 = Sentinel
    //     0x62df18: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x62df1c: cmp             w4, w16
    // 0x62df20: b.eq            #0x62e088
    // 0x62df24: LoadField: r0 = r4->field_b
    //     0x62df24: ldur            w0, [x4, #0xb]
    // 0x62df28: DecompressPointer r0
    //     0x62df28: add             x0, x0, HEAP, lsl #32
    // 0x62df2c: r1 = LoadInt32Instr(r0)
    //     0x62df2c: sbfx            x1, x0, #1, #0x1f
    // 0x62df30: mov             x0, x1
    // 0x62df34: ldur            x1, [fp, #-0x18]
    // 0x62df38: cmp             x1, x0
    // 0x62df3c: b.hs            #0x62e094
    // 0x62df40: LoadField: r0 = r4->field_f
    //     0x62df40: ldur            w0, [x4, #0xf]
    // 0x62df44: DecompressPointer r0
    //     0x62df44: add             x0, x0, HEAP, lsl #32
    // 0x62df48: ldur            x1, [fp, #-0x18]
    // 0x62df4c: ArrayLoad: r4 = r0[r1]  ; Unknown_4
    //     0x62df4c: add             x16, x0, x1, lsl #2
    //     0x62df50: ldur            w4, [x16, #0xf]
    // 0x62df54: DecompressPointer r4
    //     0x62df54: add             x4, x4, HEAP, lsl #32
    // 0x62df58: LoadField: r0 = r4->field_b
    //     0x62df58: ldur            w0, [x4, #0xb]
    // 0x62df5c: DecompressPointer r0
    //     0x62df5c: add             x0, x0, HEAP, lsl #32
    // 0x62df60: stur            x0, [fp, #-0x38]
    // 0x62df64: LoadField: r5 = r4->field_f
    //     0x62df64: ldur            w5, [x4, #0xf]
    // 0x62df68: DecompressPointer r5
    //     0x62df68: add             x5, x5, HEAP, lsl #32
    // 0x62df6c: stur            x5, [fp, #-0x30]
    // 0x62df70: r0 = PlaceholderDimensions()
    //     0x62df70: bl              #0x62d738  ; AllocatePlaceholderDimensionsStub -> PlaceholderDimensions (size=0x18)
    // 0x62df74: mov             x2, x0
    // 0x62df78: ldur            x0, [fp, #-0x40]
    // 0x62df7c: StoreField: r2->field_7 = r0
    //     0x62df7c: stur            w0, [x2, #7]
    // 0x62df80: ldur            x0, [fp, #-0x38]
    // 0x62df84: StoreField: r2->field_b = r0
    //     0x62df84: stur            w0, [x2, #0xb]
    // 0x62df88: ldur            x0, [fp, #-0x30]
    // 0x62df8c: StoreField: r2->field_13 = r0
    //     0x62df8c: stur            w0, [x2, #0x13]
    // 0x62df90: ldur            x0, [fp, #-8]
    // 0x62df94: ldur            x1, [fp, #-0x18]
    // 0x62df98: cmp             x1, x0
    // 0x62df9c: b.hs            #0x62e098
    // 0x62dfa0: ldur            x1, [fp, #-0x28]
    // 0x62dfa4: mov             x0, x2
    // 0x62dfa8: ldur            x3, [fp, #-0x18]
    // 0x62dfac: ArrayStore: r1[r3] = r0  ; List_4
    //     0x62dfac: add             x25, x1, x3, lsl #2
    //     0x62dfb0: add             x25, x25, #0xf
    //     0x62dfb4: str             w0, [x25]
    //     0x62dfb8: tbz             w0, #0, #0x62dfd4
    //     0x62dfbc: ldurb           w16, [x1, #-1]
    //     0x62dfc0: ldurb           w17, [x0, #-1]
    //     0x62dfc4: and             x16, x17, x16, lsr #2
    //     0x62dfc8: tst             x16, HEAP, lsr #32
    //     0x62dfcc: b.eq            #0x62dfd4
    //     0x62dfd0: bl              #0xd67e5c
    // 0x62dfd4: ldur            x0, [fp, #-0x10]
    // 0x62dfd8: LoadField: r4 = r0->field_17
    //     0x62dfd8: ldur            w4, [x0, #0x17]
    // 0x62dfdc: DecompressPointer r4
    //     0x62dfdc: add             x4, x4, HEAP, lsl #32
    // 0x62dfe0: stur            x4, [fp, #-0x30]
    // 0x62dfe4: cmp             w4, NULL
    // 0x62dfe8: b.eq            #0x62e09c
    // 0x62dfec: mov             x0, x4
    // 0x62dff0: r2 = Null
    //     0x62dff0: mov             x2, NULL
    // 0x62dff4: r1 = Null
    //     0x62dff4: mov             x1, NULL
    // 0x62dff8: r4 = LoadClassIdInstr(r0)
    //     0x62dff8: ldur            x4, [x0, #-1]
    //     0x62dffc: ubfx            x4, x4, #0xc, #0x14
    // 0x62e000: cmp             x4, #0x808
    // 0x62e004: b.eq            #0x62e01c
    // 0x62e008: r8 = TextParentData<RenderBox>
    //     0x62e008: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x62e00c: ldr             x8, [x8, #0x298]
    // 0x62e010: r3 = Null
    //     0x62e010: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4bbc8] Null
    //     0x62e014: ldr             x3, [x3, #0xbc8]
    // 0x62e018: r0 = DefaultTypeTest()
    //     0x62e018: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x62e01c: ldur            x0, [fp, #-0x30]
    // 0x62e020: LoadField: r5 = r0->field_13
    //     0x62e020: ldur            w5, [x0, #0x13]
    // 0x62e024: DecompressPointer r5
    //     0x62e024: add             x5, x5, HEAP, lsl #32
    // 0x62e028: ldur            x0, [fp, #-0x18]
    // 0x62e02c: add             x4, x0, #1
    // 0x62e030: ldr             x2, [fp, #0x18]
    // 0x62e034: ldur            d2, [fp, #-0x48]
    // 0x62e038: ldur            x1, [fp, #-8]
    // 0x62e03c: ldur            x3, [fp, #-0x20]
    // 0x62e040: ldur            x0, [fp, #-0x28]
    // 0x62e044: b               #0x62ddfc
    // 0x62e048: ldur            x16, [fp, #-0x20]
    // 0x62e04c: ldur            lr, [fp, #-0x28]
    // 0x62e050: stp             lr, x16, [SP, #-0x10]!
    // 0x62e054: r0 = setPlaceholderDimensions()
    //     0x62e054: bl              #0x62d480  ; [package:flutter/src/painting/text_painter.dart] TextPainter::setPlaceholderDimensions
    // 0x62e058: add             SP, SP, #0x10
    // 0x62e05c: r0 = Null
    //     0x62e05c: mov             x0, NULL
    // 0x62e060: LeaveFrame
    //     0x62e060: mov             SP, fp
    //     0x62e064: ldp             fp, lr, [SP], #0x10
    // 0x62e068: ret
    //     0x62e068: ret             
    // 0x62e06c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62e06c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62e070: b               #0x62dd5c
    // 0x62e074: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62e074: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62e078: b               #0x62ddb0
    // 0x62e07c: r0 = StackOverflowSharedWithFPURegs()
    //     0x62e07c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x62e080: b               #0x62de10
    // 0x62e084: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x62e084: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x62e088: r9 = _placeholderSpans
    //     0x62e088: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d468] Field <RenderParagraph._placeholderSpans@507149678>: late (offset: 0x84)
    //     0x62e08c: ldr             x9, [x9, #0x468]
    // 0x62e090: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x62e090: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x62e094: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x62e094: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x62e098: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x62e098: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x62e09c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x62e09c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _canComputeIntrinsics(/* No info */) {
    // ** addr: 0x62e0a0, size: 0x1b0
    // 0x62e0a0: EnterFrame
    //     0x62e0a0: stp             fp, lr, [SP, #-0x10]!
    //     0x62e0a4: mov             fp, SP
    // 0x62e0a8: AllocStack(0x30)
    //     0x62e0a8: sub             SP, SP, #0x30
    // 0x62e0ac: CheckStackOverflow
    //     0x62e0ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62e0b0: cmp             SP, x16
    //     0x62e0b4: b.ls            #0x62e234
    // 0x62e0b8: ldr             x0, [fp, #0x10]
    // 0x62e0bc: LoadField: r1 = r0->field_83
    //     0x62e0bc: ldur            w1, [x0, #0x83]
    // 0x62e0c0: DecompressPointer r1
    //     0x62e0c0: add             x1, x1, HEAP, lsl #32
    // 0x62e0c4: r16 = Sentinel
    //     0x62e0c4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x62e0c8: cmp             w1, w16
    // 0x62e0cc: b.eq            #0x62e23c
    // 0x62e0d0: stur            x1, [fp, #-0x20]
    // 0x62e0d4: LoadField: r2 = r1->field_7
    //     0x62e0d4: ldur            w2, [x1, #7]
    // 0x62e0d8: DecompressPointer r2
    //     0x62e0d8: add             x2, x2, HEAP, lsl #32
    // 0x62e0dc: stur            x2, [fp, #-0x18]
    // 0x62e0e0: LoadField: r0 = r1->field_b
    //     0x62e0e0: ldur            w0, [x1, #0xb]
    // 0x62e0e4: DecompressPointer r0
    //     0x62e0e4: add             x0, x0, HEAP, lsl #32
    // 0x62e0e8: r3 = LoadInt32Instr(r0)
    //     0x62e0e8: sbfx            x3, x0, #1, #0x1f
    // 0x62e0ec: stur            x3, [fp, #-0x10]
    // 0x62e0f0: r4 = 0
    //     0x62e0f0: mov             x4, #0
    // 0x62e0f4: stur            x4, [fp, #-8]
    // 0x62e0f8: CheckStackOverflow
    //     0x62e0f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62e0fc: cmp             SP, x16
    //     0x62e100: b.ls            #0x62e248
    // 0x62e104: r0 = LoadClassIdInstr(r1)
    //     0x62e104: ldur            x0, [x1, #-1]
    //     0x62e108: ubfx            x0, x0, #0xc, #0x14
    // 0x62e10c: SaveReg r1
    //     0x62e10c: str             x1, [SP, #-8]!
    // 0x62e110: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x62e110: mov             x17, #0xb8ea
    //     0x62e114: add             lr, x0, x17
    //     0x62e118: ldr             lr, [x21, lr, lsl #3]
    //     0x62e11c: blr             lr
    // 0x62e120: add             SP, SP, #8
    // 0x62e124: r1 = LoadInt32Instr(r0)
    //     0x62e124: sbfx            x1, x0, #1, #0x1f
    //     0x62e128: tbz             w0, #0, #0x62e130
    //     0x62e12c: ldur            x1, [x0, #7]
    // 0x62e130: ldur            x2, [fp, #-0x10]
    // 0x62e134: cmp             x2, x1
    // 0x62e138: b.ne            #0x62e21c
    // 0x62e13c: ldur            x3, [fp, #-0x20]
    // 0x62e140: ldur            x4, [fp, #-8]
    // 0x62e144: cmp             x4, x1
    // 0x62e148: b.lt            #0x62e15c
    // 0x62e14c: r0 = true
    //     0x62e14c: add             x0, NULL, #0x20  ; true
    // 0x62e150: LeaveFrame
    //     0x62e150: mov             SP, fp
    //     0x62e154: ldp             fp, lr, [SP], #0x10
    // 0x62e158: ret
    //     0x62e158: ret             
    // 0x62e15c: r0 = BoxInt64Instr(r4)
    //     0x62e15c: sbfiz           x0, x4, #1, #0x1f
    //     0x62e160: cmp             x4, x0, asr #1
    //     0x62e164: b.eq            #0x62e170
    //     0x62e168: bl              #0xd69bb8
    //     0x62e16c: stur            x4, [x0, #7]
    // 0x62e170: r1 = LoadClassIdInstr(r3)
    //     0x62e170: ldur            x1, [x3, #-1]
    //     0x62e174: ubfx            x1, x1, #0xc, #0x14
    // 0x62e178: stp             x0, x3, [SP, #-0x10]!
    // 0x62e17c: mov             x0, x1
    // 0x62e180: r0 = GDT[cid_x0 + 0xd175]()
    //     0x62e180: mov             x17, #0xd175
    //     0x62e184: add             lr, x0, x17
    //     0x62e188: ldr             lr, [x21, lr, lsl #3]
    //     0x62e18c: blr             lr
    // 0x62e190: add             SP, SP, #0x10
    // 0x62e194: mov             x3, x0
    // 0x62e198: ldur            x0, [fp, #-8]
    // 0x62e19c: stur            x3, [fp, #-0x30]
    // 0x62e1a0: add             x4, x0, #1
    // 0x62e1a4: stur            x4, [fp, #-0x28]
    // 0x62e1a8: cmp             w3, NULL
    // 0x62e1ac: b.ne            #0x62e1e0
    // 0x62e1b0: mov             x0, x3
    // 0x62e1b4: ldur            x2, [fp, #-0x18]
    // 0x62e1b8: r1 = Null
    //     0x62e1b8: mov             x1, NULL
    // 0x62e1bc: cmp             w2, NULL
    // 0x62e1c0: b.eq            #0x62e1e0
    // 0x62e1c4: LoadField: r4 = r2->field_17
    //     0x62e1c4: ldur            w4, [x2, #0x17]
    // 0x62e1c8: DecompressPointer r4
    //     0x62e1c8: add             x4, x4, HEAP, lsl #32
    // 0x62e1cc: r8 = X0
    //     0x62e1cc: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x62e1d0: LoadField: r9 = r4->field_7
    //     0x62e1d0: ldur            x9, [x4, #7]
    // 0x62e1d4: r3 = Null
    //     0x62e1d4: add             x3, PP, #0x40, lsl #12  ; [pp+0x40a20] Null
    //     0x62e1d8: ldr             x3, [x3, #0xa20]
    // 0x62e1dc: blr             x9
    // 0x62e1e0: ldur            x1, [fp, #-0x30]
    // 0x62e1e4: LoadField: r2 = r1->field_b
    //     0x62e1e4: ldur            w2, [x1, #0xb]
    // 0x62e1e8: DecompressPointer r2
    //     0x62e1e8: add             x2, x2, HEAP, lsl #32
    // 0x62e1ec: LoadField: r1 = r2->field_7
    //     0x62e1ec: ldur            x1, [x2, #7]
    // 0x62e1f0: cmp             x1, #2
    // 0x62e1f4: b.gt            #0x62e208
    // 0x62e1f8: r0 = false
    //     0x62e1f8: add             x0, NULL, #0x30  ; false
    // 0x62e1fc: LeaveFrame
    //     0x62e1fc: mov             SP, fp
    //     0x62e200: ldp             fp, lr, [SP], #0x10
    // 0x62e204: ret
    //     0x62e204: ret             
    // 0x62e208: ldur            x4, [fp, #-0x28]
    // 0x62e20c: ldur            x1, [fp, #-0x20]
    // 0x62e210: ldur            x2, [fp, #-0x18]
    // 0x62e214: ldur            x3, [fp, #-0x10]
    // 0x62e218: b               #0x62e0f4
    // 0x62e21c: ldur            x0, [fp, #-0x20]
    // 0x62e220: r0 = ConcurrentModificationError()
    //     0x62e220: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x62e224: ldur            x3, [fp, #-0x20]
    // 0x62e228: StoreField: r0->field_b = r3
    //     0x62e228: stur            w3, [x0, #0xb]
    // 0x62e22c: r0 = Throw()
    //     0x62e22c: bl              #0xd67e38  ; ThrowStub
    // 0x62e230: brk             #0
    // 0x62e234: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62e234: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62e238: b               #0x62e0b8
    // 0x62e23c: r9 = _placeholderSpans
    //     0x62e23c: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d468] Field <RenderParagraph._placeholderSpans@507149678>: late (offset: 0x84)
    //     0x62e240: ldr             x9, [x9, #0x468]
    // 0x62e244: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x62e244: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x62e248: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62e248: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62e24c: b               #0x62e104
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x634dc0, size: 0x18
    // 0x634dc0: r4 = 0
    //     0x634dc0: mov             x4, #0
    // 0x634dc4: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x634dc4: add             x17, PP, #0x40, lsl #12  ; [pp+0x40a08] AnonymousClosure: (0x634dd8), in [package:flutter/src/rendering/paragraph.dart] RenderParagraph::computeMaxIntrinsicWidth (0x634e24)
    //     0x634dc8: ldr             x1, [x17, #0xa08]
    // 0x634dcc: r24 = BuildNonGenericMethodExtractorStub
    //     0x634dcc: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x634dd0: LoadField: r0 = r24->field_17
    //     0x634dd0: ldur            x0, [x24, #0x17]
    // 0x634dd4: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x634dd8, size: 0x4c
    // 0x634dd8: EnterFrame
    //     0x634dd8: stp             fp, lr, [SP, #-0x10]!
    //     0x634ddc: mov             fp, SP
    // 0x634de0: ldr             x0, [fp, #0x18]
    // 0x634de4: LoadField: r1 = r0->field_17
    //     0x634de4: ldur            w1, [x0, #0x17]
    // 0x634de8: DecompressPointer r1
    //     0x634de8: add             x1, x1, HEAP, lsl #32
    // 0x634dec: CheckStackOverflow
    //     0x634dec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x634df0: cmp             SP, x16
    //     0x634df4: b.ls            #0x634e1c
    // 0x634df8: LoadField: r0 = r1->field_f
    //     0x634df8: ldur            w0, [x1, #0xf]
    // 0x634dfc: DecompressPointer r0
    //     0x634dfc: add             x0, x0, HEAP, lsl #32
    // 0x634e00: ldr             x16, [fp, #0x10]
    // 0x634e04: stp             x16, x0, [SP, #-0x10]!
    // 0x634e08: r0 = computeMaxIntrinsicWidth()
    //     0x634e08: bl              #0x634e24  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::computeMaxIntrinsicWidth
    // 0x634e0c: add             SP, SP, #0x10
    // 0x634e10: LeaveFrame
    //     0x634e10: mov             SP, fp
    //     0x634e14: ldp             fp, lr, [SP], #0x10
    // 0x634e18: ret
    //     0x634e18: ret             
    // 0x634e1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x634e1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x634e20: b               #0x634df8
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0x634e24, size: 0x108
    // 0x634e24: EnterFrame
    //     0x634e24: stp             fp, lr, [SP, #-0x10]!
    //     0x634e28: mov             fp, SP
    // 0x634e2c: CheckStackOverflow
    //     0x634e2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x634e30: cmp             SP, x16
    //     0x634e34: b.ls            #0x634f10
    // 0x634e38: ldr             x16, [fp, #0x18]
    // 0x634e3c: SaveReg r16
    //     0x634e3c: str             x16, [SP, #-8]!
    // 0x634e40: r0 = _canComputeIntrinsics()
    //     0x634e40: bl              #0x62e0a0  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_canComputeIntrinsics
    // 0x634e44: add             SP, SP, #8
    // 0x634e48: tbz             w0, #4, #0x634e5c
    // 0x634e4c: r0 = 0.000000
    //     0x634e4c: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x634e50: LeaveFrame
    //     0x634e50: mov             SP, fp
    //     0x634e54: ldp             fp, lr, [SP], #0x10
    // 0x634e58: ret
    //     0x634e58: ret             
    // 0x634e5c: ldr             x0, [fp, #0x18]
    // 0x634e60: SaveReg r0
    //     0x634e60: str             x0, [SP, #-8]!
    // 0x634e64: r0 = _computeChildrenWidthWithMaxIntrinsics()
    //     0x634e64: bl              #0x634f2c  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_computeChildrenWidthWithMaxIntrinsics
    // 0x634e68: add             SP, SP, #8
    // 0x634e6c: ldr             x16, [fp, #0x18]
    // 0x634e70: SaveReg r16
    //     0x634e70: str             x16, [SP, #-8]!
    // 0x634e74: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x634e74: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x634e78: r0 = _layoutText()
    //     0x634e78: bl              #0x62db8c  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_layoutText
    // 0x634e7c: add             SP, SP, #8
    // 0x634e80: ldr             x0, [fp, #0x18]
    // 0x634e84: LoadField: r1 = r0->field_6f
    //     0x634e84: ldur            w1, [x0, #0x6f]
    // 0x634e88: DecompressPointer r1
    //     0x634e88: add             x1, x1, HEAP, lsl #32
    // 0x634e8c: LoadField: r0 = r1->field_7
    //     0x634e8c: ldur            w0, [x1, #7]
    // 0x634e90: DecompressPointer r0
    //     0x634e90: add             x0, x0, HEAP, lsl #32
    // 0x634e94: cmp             w0, NULL
    // 0x634e98: b.eq            #0x634f18
    // 0x634e9c: SaveReg r0
    //     0x634e9c: str             x0, [SP, #-8]!
    // 0x634ea0: r0 = maxIntrinsicWidth()
    //     0x634ea0: bl              #0x523ec4  ; [dart:ui] Paragraph::maxIntrinsicWidth
    // 0x634ea4: add             SP, SP, #8
    // 0x634ea8: stp             fp, lr, [SP, #-0x10]!
    // 0x634eac: mov             fp, SP
    // 0x634eb0: CallRuntime_LibcCeil(double) -> double
    //     0x634eb0: and             SP, SP, #0xfffffffffffffff0
    //     0x634eb4: mov             sp, SP
    //     0x634eb8: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x634ebc: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x634ec0: blr             x16
    //     0x634ec4: mov             x16, #8
    //     0x634ec8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x634ecc: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x634ed0: sub             sp, x16, #1, lsl #12
    //     0x634ed4: mov             SP, fp
    //     0x634ed8: ldp             fp, lr, [SP], #0x10
    // 0x634edc: r0 = inline_Allocate_Double()
    //     0x634edc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x634ee0: add             x0, x0, #0x10
    //     0x634ee4: cmp             x1, x0
    //     0x634ee8: b.ls            #0x634f1c
    //     0x634eec: str             x0, [THR, #0x60]  ; THR::top
    //     0x634ef0: sub             x0, x0, #0xf
    //     0x634ef4: mov             x1, #0xd108
    //     0x634ef8: movk            x1, #3, lsl #16
    //     0x634efc: stur            x1, [x0, #-1]
    // 0x634f00: StoreField: r0->field_7 = d0
    //     0x634f00: stur            d0, [x0, #7]
    // 0x634f04: LeaveFrame
    //     0x634f04: mov             SP, fp
    //     0x634f08: ldp             fp, lr, [SP], #0x10
    // 0x634f0c: ret
    //     0x634f0c: ret             
    // 0x634f10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x634f10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x634f14: b               #0x634e38
    // 0x634f18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x634f18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x634f1c: SaveReg d0
    //     0x634f1c: str             q0, [SP, #-0x10]!
    // 0x634f20: r0 = AllocateDouble()
    //     0x634f20: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x634f24: RestoreReg d0
    //     0x634f24: ldr             q0, [SP], #0x10
    // 0x634f28: b               #0x634f00
  }
  _ _computeChildrenWidthWithMaxIntrinsics(/* No info */) {
    // ** addr: 0x634f2c, size: 0x2ac
    // 0x634f2c: EnterFrame
    //     0x634f2c: stp             fp, lr, [SP, #-0x10]!
    //     0x634f30: mov             fp, SP
    // 0x634f34: AllocStack(0x40)
    //     0x634f34: sub             SP, SP, #0x40
    // 0x634f38: CheckStackOverflow
    //     0x634f38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x634f3c: cmp             SP, x16
    //     0x634f40: b.ls            #0x6351a8
    // 0x634f44: ldr             x3, [fp, #0x10]
    // 0x634f48: LoadField: r4 = r3->field_67
    //     0x634f48: ldur            w4, [x3, #0x67]
    // 0x634f4c: DecompressPointer r4
    //     0x634f4c: add             x4, x4, HEAP, lsl #32
    // 0x634f50: stur            x4, [fp, #-0x10]
    // 0x634f54: LoadField: r5 = r3->field_5f
    //     0x634f54: ldur            x5, [x3, #0x5f]
    // 0x634f58: stur            x5, [fp, #-8]
    // 0x634f5c: r0 = BoxInt64Instr(r5)
    //     0x634f5c: sbfiz           x0, x5, #1, #0x1f
    //     0x634f60: cmp             x5, x0, asr #1
    //     0x634f64: b.eq            #0x634f70
    //     0x634f68: bl              #0xd69bb8
    //     0x634f6c: stur            x5, [x0, #7]
    // 0x634f70: mov             x2, x0
    // 0x634f74: r1 = <PlaceholderDimensions>
    //     0x634f74: add             x1, PP, #0x22, lsl #12  ; [pp+0x22320] TypeArguments: <PlaceholderDimensions>
    //     0x634f78: ldr             x1, [x1, #0x320]
    // 0x634f7c: r0 = AllocateArray()
    //     0x634f7c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x634f80: mov             x1, x0
    // 0x634f84: stur            x1, [fp, #-0x20]
    // 0x634f88: ldur            x2, [fp, #-8]
    // 0x634f8c: r0 = 0
    //     0x634f8c: mov             x0, #0
    // 0x634f90: CheckStackOverflow
    //     0x634f90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x634f94: cmp             SP, x16
    //     0x634f98: b.ls            #0x6351b0
    // 0x634f9c: cmp             x0, x2
    // 0x634fa0: b.ge            #0x634fc0
    // 0x634fa4: add             x3, x1, x0, lsl #2
    // 0x634fa8: r17 = Instance_PlaceholderDimensions
    //     0x634fa8: add             x17, PP, #0x22, lsl #12  ; [pp+0x22458] Obj!PlaceholderDimensions@b356b1
    //     0x634fac: ldr             x17, [x17, #0x458]
    // 0x634fb0: StoreField: r3->field_f = r17
    //     0x634fb0: stur            w17, [x3, #0xf]
    // 0x634fb4: add             x3, x0, #1
    // 0x634fb8: mov             x0, x3
    // 0x634fbc: b               #0x634f90
    // 0x634fc0: ldur            x5, [fp, #-0x10]
    // 0x634fc4: r4 = 0
    //     0x634fc4: mov             x4, #0
    // 0x634fc8: ldr             x3, [fp, #0x10]
    // 0x634fcc: stur            x5, [fp, #-0x10]
    // 0x634fd0: stur            x4, [fp, #-0x18]
    // 0x634fd4: CheckStackOverflow
    //     0x634fd4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x634fd8: cmp             SP, x16
    //     0x634fdc: b.ls            #0x6351b8
    // 0x634fe0: cmp             w5, NULL
    // 0x634fe4: b.eq            #0x63517c
    // 0x634fe8: r0 = LoadClassIdInstr(r5)
    //     0x634fe8: ldur            x0, [x5, #-1]
    //     0x634fec: ubfx            x0, x0, #0xc, #0x14
    // 0x634ff0: SaveReg r5
    //     0x634ff0: str             x5, [SP, #-8]!
    // 0x634ff4: r0 = GDT[cid_x0 + 0xf204]()
    //     0x634ff4: mov             x17, #0xf204
    //     0x634ff8: add             lr, x0, x17
    //     0x634ffc: ldr             lr, [x21, lr, lsl #3]
    //     0x635000: blr             lr
    // 0x635004: add             SP, SP, #8
    // 0x635008: ldur            x16, [fp, #-0x10]
    // 0x63500c: r30 = Instance__IntrinsicDimension
    //     0x63500c: add             lr, PP, #0x37, lsl #12  ; [pp+0x37080] Obj!_IntrinsicDimension@b64bf1
    //     0x635010: ldr             lr, [lr, #0x80]
    // 0x635014: stp             lr, x16, [SP, #-0x10]!
    // 0x635018: d0 = inf
    //     0x635018: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x63501c: SaveReg d0
    //     0x63501c: str             d0, [SP, #-8]!
    // 0x635020: SaveReg r0
    //     0x635020: str             x0, [SP, #-8]!
    // 0x635024: r0 = _computeIntrinsicDimension()
    //     0x635024: bl              #0x62cc04  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsicDimension
    // 0x635028: add             SP, SP, #0x20
    // 0x63502c: stur            d0, [fp, #-0x40]
    // 0x635030: r0 = Size()
    //     0x635030: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x635034: mov             x2, x0
    // 0x635038: ldur            d0, [fp, #-0x40]
    // 0x63503c: stur            x2, [fp, #-0x38]
    // 0x635040: StoreField: r2->field_7 = d0
    //     0x635040: stur            d0, [x2, #7]
    // 0x635044: d0 = 0.000000
    //     0x635044: eor             v0.16b, v0.16b, v0.16b
    // 0x635048: StoreField: r2->field_f = d0
    //     0x635048: stur            d0, [x2, #0xf]
    // 0x63504c: ldr             x3, [fp, #0x10]
    // 0x635050: LoadField: r4 = r3->field_83
    //     0x635050: ldur            w4, [x3, #0x83]
    // 0x635054: DecompressPointer r4
    //     0x635054: add             x4, x4, HEAP, lsl #32
    // 0x635058: r16 = Sentinel
    //     0x635058: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x63505c: cmp             w4, w16
    // 0x635060: b.eq            #0x6351c0
    // 0x635064: LoadField: r0 = r4->field_b
    //     0x635064: ldur            w0, [x4, #0xb]
    // 0x635068: DecompressPointer r0
    //     0x635068: add             x0, x0, HEAP, lsl #32
    // 0x63506c: r1 = LoadInt32Instr(r0)
    //     0x63506c: sbfx            x1, x0, #1, #0x1f
    // 0x635070: mov             x0, x1
    // 0x635074: ldur            x1, [fp, #-0x18]
    // 0x635078: cmp             x1, x0
    // 0x63507c: b.hs            #0x6351cc
    // 0x635080: LoadField: r0 = r4->field_f
    //     0x635080: ldur            w0, [x4, #0xf]
    // 0x635084: DecompressPointer r0
    //     0x635084: add             x0, x0, HEAP, lsl #32
    // 0x635088: ldur            x1, [fp, #-0x18]
    // 0x63508c: ArrayLoad: r4 = r0[r1]  ; Unknown_4
    //     0x63508c: add             x16, x0, x1, lsl #2
    //     0x635090: ldur            w4, [x16, #0xf]
    // 0x635094: DecompressPointer r4
    //     0x635094: add             x4, x4, HEAP, lsl #32
    // 0x635098: LoadField: r0 = r4->field_b
    //     0x635098: ldur            w0, [x4, #0xb]
    // 0x63509c: DecompressPointer r0
    //     0x63509c: add             x0, x0, HEAP, lsl #32
    // 0x6350a0: stur            x0, [fp, #-0x30]
    // 0x6350a4: LoadField: r5 = r4->field_f
    //     0x6350a4: ldur            w5, [x4, #0xf]
    // 0x6350a8: DecompressPointer r5
    //     0x6350a8: add             x5, x5, HEAP, lsl #32
    // 0x6350ac: stur            x5, [fp, #-0x28]
    // 0x6350b0: r0 = PlaceholderDimensions()
    //     0x6350b0: bl              #0x62d738  ; AllocatePlaceholderDimensionsStub -> PlaceholderDimensions (size=0x18)
    // 0x6350b4: mov             x2, x0
    // 0x6350b8: ldur            x0, [fp, #-0x38]
    // 0x6350bc: StoreField: r2->field_7 = r0
    //     0x6350bc: stur            w0, [x2, #7]
    // 0x6350c0: ldur            x0, [fp, #-0x30]
    // 0x6350c4: StoreField: r2->field_b = r0
    //     0x6350c4: stur            w0, [x2, #0xb]
    // 0x6350c8: ldur            x0, [fp, #-0x28]
    // 0x6350cc: StoreField: r2->field_13 = r0
    //     0x6350cc: stur            w0, [x2, #0x13]
    // 0x6350d0: ldur            x0, [fp, #-8]
    // 0x6350d4: ldur            x1, [fp, #-0x18]
    // 0x6350d8: cmp             x1, x0
    // 0x6350dc: b.hs            #0x6351d0
    // 0x6350e0: ldur            x1, [fp, #-0x20]
    // 0x6350e4: mov             x0, x2
    // 0x6350e8: ldur            x3, [fp, #-0x18]
    // 0x6350ec: ArrayStore: r1[r3] = r0  ; List_4
    //     0x6350ec: add             x25, x1, x3, lsl #2
    //     0x6350f0: add             x25, x25, #0xf
    //     0x6350f4: str             w0, [x25]
    //     0x6350f8: tbz             w0, #0, #0x635114
    //     0x6350fc: ldurb           w16, [x1, #-1]
    //     0x635100: ldurb           w17, [x0, #-1]
    //     0x635104: and             x16, x17, x16, lsr #2
    //     0x635108: tst             x16, HEAP, lsr #32
    //     0x63510c: b.eq            #0x635114
    //     0x635110: bl              #0xd67e5c
    // 0x635114: ldur            x0, [fp, #-0x10]
    // 0x635118: LoadField: r4 = r0->field_17
    //     0x635118: ldur            w4, [x0, #0x17]
    // 0x63511c: DecompressPointer r4
    //     0x63511c: add             x4, x4, HEAP, lsl #32
    // 0x635120: stur            x4, [fp, #-0x28]
    // 0x635124: cmp             w4, NULL
    // 0x635128: b.eq            #0x6351d4
    // 0x63512c: mov             x0, x4
    // 0x635130: r2 = Null
    //     0x635130: mov             x2, NULL
    // 0x635134: r1 = Null
    //     0x635134: mov             x1, NULL
    // 0x635138: r4 = LoadClassIdInstr(r0)
    //     0x635138: ldur            x4, [x0, #-1]
    //     0x63513c: ubfx            x4, x4, #0xc, #0x14
    // 0x635140: cmp             x4, #0x808
    // 0x635144: b.eq            #0x63515c
    // 0x635148: r8 = TextParentData<RenderBox>
    //     0x635148: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x63514c: ldr             x8, [x8, #0x298]
    // 0x635150: r3 = Null
    //     0x635150: add             x3, PP, #0x40, lsl #12  ; [pp+0x40a10] Null
    //     0x635154: ldr             x3, [x3, #0xa10]
    // 0x635158: r0 = DefaultTypeTest()
    //     0x635158: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x63515c: ldur            x0, [fp, #-0x28]
    // 0x635160: LoadField: r5 = r0->field_13
    //     0x635160: ldur            w5, [x0, #0x13]
    // 0x635164: DecompressPointer r5
    //     0x635164: add             x5, x5, HEAP, lsl #32
    // 0x635168: ldur            x0, [fp, #-0x18]
    // 0x63516c: add             x4, x0, #1
    // 0x635170: ldur            x2, [fp, #-8]
    // 0x635174: ldur            x1, [fp, #-0x20]
    // 0x635178: b               #0x634fc8
    // 0x63517c: mov             x0, x3
    // 0x635180: LoadField: r1 = r0->field_6f
    //     0x635180: ldur            w1, [x0, #0x6f]
    // 0x635184: DecompressPointer r1
    //     0x635184: add             x1, x1, HEAP, lsl #32
    // 0x635188: ldur            x16, [fp, #-0x20]
    // 0x63518c: stp             x16, x1, [SP, #-0x10]!
    // 0x635190: r0 = setPlaceholderDimensions()
    //     0x635190: bl              #0x62d480  ; [package:flutter/src/painting/text_painter.dart] TextPainter::setPlaceholderDimensions
    // 0x635194: add             SP, SP, #0x10
    // 0x635198: r0 = Null
    //     0x635198: mov             x0, NULL
    // 0x63519c: LeaveFrame
    //     0x63519c: mov             SP, fp
    //     0x6351a0: ldp             fp, lr, [SP], #0x10
    // 0x6351a4: ret
    //     0x6351a4: ret             
    // 0x6351a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6351a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6351ac: b               #0x634f44
    // 0x6351b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6351b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6351b4: b               #0x634f9c
    // 0x6351b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6351b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6351bc: b               #0x634fe0
    // 0x6351c0: r9 = _placeholderSpans
    //     0x6351c0: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d468] Field <RenderParagraph._placeholderSpans@507149678>: late (offset: 0x84)
    //     0x6351c4: ldr             x9, [x9, #0x468]
    // 0x6351c8: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x6351c8: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x6351cc: r0 = RangeErrorSharedWithFPURegs()
    //     0x6351cc: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x6351d0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6351d0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6351d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6351d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x638470, size: 0x18
    // 0x638470: r4 = 0
    //     0x638470: mov             x4, #0
    // 0x638474: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x638474: add             x17, PP, #0x53, lsl #12  ; [pp+0x532f8] AnonymousClosure: (0x62d9e4), of [package:flutter/src/rendering/paragraph.dart] RenderParagraph
    //     0x638478: ldr             x1, [x17, #0x2f8]
    // 0x63847c: r24 = BuildNonGenericMethodExtractorStub
    //     0x63847c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x638480: LoadField: r0 = r24->field_17
    //     0x638480: ldur            x0, [x24, #0x17]
    // 0x638484: br              x0
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63ad9c, size: 0x18
    // 0x63ad9c: r4 = 0
    //     0x63ad9c: mov             x4, #0
    // 0x63ada0: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63ada0: add             x17, PP, #0x51, lsl #12  ; [pp+0x510a8] AnonymousClosure: (0x63adb4), in [package:flutter/src/rendering/paragraph.dart] RenderParagraph::computeMinIntrinsicWidth (0x63ae00)
    //     0x63ada4: ldr             x1, [x17, #0xa8]
    // 0x63ada8: r24 = BuildNonGenericMethodExtractorStub
    //     0x63ada8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63adac: LoadField: r0 = r24->field_17
    //     0x63adac: ldur            x0, [x24, #0x17]
    // 0x63adb0: br              x0
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63adb4, size: 0x4c
    // 0x63adb4: EnterFrame
    //     0x63adb4: stp             fp, lr, [SP, #-0x10]!
    //     0x63adb8: mov             fp, SP
    // 0x63adbc: ldr             x0, [fp, #0x18]
    // 0x63adc0: LoadField: r1 = r0->field_17
    //     0x63adc0: ldur            w1, [x0, #0x17]
    // 0x63adc4: DecompressPointer r1
    //     0x63adc4: add             x1, x1, HEAP, lsl #32
    // 0x63adc8: CheckStackOverflow
    //     0x63adc8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63adcc: cmp             SP, x16
    //     0x63add0: b.ls            #0x63adf8
    // 0x63add4: LoadField: r0 = r1->field_f
    //     0x63add4: ldur            w0, [x1, #0xf]
    // 0x63add8: DecompressPointer r0
    //     0x63add8: add             x0, x0, HEAP, lsl #32
    // 0x63addc: ldr             x16, [fp, #0x10]
    // 0x63ade0: stp             x16, x0, [SP, #-0x10]!
    // 0x63ade4: r0 = computeMinIntrinsicWidth()
    //     0x63ade4: bl              #0x63ae00  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::computeMinIntrinsicWidth
    // 0x63ade8: add             SP, SP, #0x10
    // 0x63adec: LeaveFrame
    //     0x63adec: mov             SP, fp
    //     0x63adf0: ldp             fp, lr, [SP], #0x10
    // 0x63adf4: ret
    //     0x63adf4: ret             
    // 0x63adf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63adf8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63adfc: b               #0x63add4
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0x63ae00, size: 0x108
    // 0x63ae00: EnterFrame
    //     0x63ae00: stp             fp, lr, [SP, #-0x10]!
    //     0x63ae04: mov             fp, SP
    // 0x63ae08: CheckStackOverflow
    //     0x63ae08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63ae0c: cmp             SP, x16
    //     0x63ae10: b.ls            #0x63aeec
    // 0x63ae14: ldr             x16, [fp, #0x18]
    // 0x63ae18: SaveReg r16
    //     0x63ae18: str             x16, [SP, #-8]!
    // 0x63ae1c: r0 = _canComputeIntrinsics()
    //     0x63ae1c: bl              #0x62e0a0  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_canComputeIntrinsics
    // 0x63ae20: add             SP, SP, #8
    // 0x63ae24: tbz             w0, #4, #0x63ae38
    // 0x63ae28: r0 = 0.000000
    //     0x63ae28: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x63ae2c: LeaveFrame
    //     0x63ae2c: mov             SP, fp
    //     0x63ae30: ldp             fp, lr, [SP], #0x10
    // 0x63ae34: ret
    //     0x63ae34: ret             
    // 0x63ae38: ldr             x0, [fp, #0x18]
    // 0x63ae3c: SaveReg r0
    //     0x63ae3c: str             x0, [SP, #-8]!
    // 0x63ae40: r0 = _computeChildrenWidthWithMinIntrinsics()
    //     0x63ae40: bl              #0x63af08  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_computeChildrenWidthWithMinIntrinsics
    // 0x63ae44: add             SP, SP, #8
    // 0x63ae48: ldr             x16, [fp, #0x18]
    // 0x63ae4c: SaveReg r16
    //     0x63ae4c: str             x16, [SP, #-8]!
    // 0x63ae50: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x63ae50: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x63ae54: r0 = _layoutText()
    //     0x63ae54: bl              #0x62db8c  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_layoutText
    // 0x63ae58: add             SP, SP, #8
    // 0x63ae5c: ldr             x0, [fp, #0x18]
    // 0x63ae60: LoadField: r1 = r0->field_6f
    //     0x63ae60: ldur            w1, [x0, #0x6f]
    // 0x63ae64: DecompressPointer r1
    //     0x63ae64: add             x1, x1, HEAP, lsl #32
    // 0x63ae68: LoadField: r0 = r1->field_7
    //     0x63ae68: ldur            w0, [x1, #7]
    // 0x63ae6c: DecompressPointer r0
    //     0x63ae6c: add             x0, x0, HEAP, lsl #32
    // 0x63ae70: cmp             w0, NULL
    // 0x63ae74: b.eq            #0x63aef4
    // 0x63ae78: SaveReg r0
    //     0x63ae78: str             x0, [SP, #-8]!
    // 0x63ae7c: r0 = minIntrinsicWidth()
    //     0x63ae7c: bl              #0x63a95c  ; [dart:ui] Paragraph::minIntrinsicWidth
    // 0x63ae80: add             SP, SP, #8
    // 0x63ae84: stp             fp, lr, [SP, #-0x10]!
    // 0x63ae88: mov             fp, SP
    // 0x63ae8c: CallRuntime_LibcCeil(double) -> double
    //     0x63ae8c: and             SP, SP, #0xfffffffffffffff0
    //     0x63ae90: mov             sp, SP
    //     0x63ae94: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x63ae98: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x63ae9c: blr             x16
    //     0x63aea0: mov             x16, #8
    //     0x63aea4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x63aea8: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x63aeac: sub             sp, x16, #1, lsl #12
    //     0x63aeb0: mov             SP, fp
    //     0x63aeb4: ldp             fp, lr, [SP], #0x10
    // 0x63aeb8: r0 = inline_Allocate_Double()
    //     0x63aeb8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63aebc: add             x0, x0, #0x10
    //     0x63aec0: cmp             x1, x0
    //     0x63aec4: b.ls            #0x63aef8
    //     0x63aec8: str             x0, [THR, #0x60]  ; THR::top
    //     0x63aecc: sub             x0, x0, #0xf
    //     0x63aed0: mov             x1, #0xd108
    //     0x63aed4: movk            x1, #3, lsl #16
    //     0x63aed8: stur            x1, [x0, #-1]
    // 0x63aedc: StoreField: r0->field_7 = d0
    //     0x63aedc: stur            d0, [x0, #7]
    // 0x63aee0: LeaveFrame
    //     0x63aee0: mov             SP, fp
    //     0x63aee4: ldp             fp, lr, [SP], #0x10
    // 0x63aee8: ret
    //     0x63aee8: ret             
    // 0x63aeec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63aeec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63aef0: b               #0x63ae14
    // 0x63aef4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63aef4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x63aef8: SaveReg d0
    //     0x63aef8: str             q0, [SP, #-0x10]!
    // 0x63aefc: r0 = AllocateDouble()
    //     0x63aefc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63af00: RestoreReg d0
    //     0x63af00: ldr             q0, [SP], #0x10
    // 0x63af04: b               #0x63aedc
  }
  _ _computeChildrenWidthWithMinIntrinsics(/* No info */) {
    // ** addr: 0x63af08, size: 0x2ac
    // 0x63af08: EnterFrame
    //     0x63af08: stp             fp, lr, [SP, #-0x10]!
    //     0x63af0c: mov             fp, SP
    // 0x63af10: AllocStack(0x40)
    //     0x63af10: sub             SP, SP, #0x40
    // 0x63af14: CheckStackOverflow
    //     0x63af14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63af18: cmp             SP, x16
    //     0x63af1c: b.ls            #0x63b184
    // 0x63af20: ldr             x3, [fp, #0x10]
    // 0x63af24: LoadField: r4 = r3->field_67
    //     0x63af24: ldur            w4, [x3, #0x67]
    // 0x63af28: DecompressPointer r4
    //     0x63af28: add             x4, x4, HEAP, lsl #32
    // 0x63af2c: stur            x4, [fp, #-0x10]
    // 0x63af30: LoadField: r5 = r3->field_5f
    //     0x63af30: ldur            x5, [x3, #0x5f]
    // 0x63af34: stur            x5, [fp, #-8]
    // 0x63af38: r0 = BoxInt64Instr(r5)
    //     0x63af38: sbfiz           x0, x5, #1, #0x1f
    //     0x63af3c: cmp             x5, x0, asr #1
    //     0x63af40: b.eq            #0x63af4c
    //     0x63af44: bl              #0xd69bb8
    //     0x63af48: stur            x5, [x0, #7]
    // 0x63af4c: mov             x2, x0
    // 0x63af50: r1 = <PlaceholderDimensions>
    //     0x63af50: add             x1, PP, #0x22, lsl #12  ; [pp+0x22320] TypeArguments: <PlaceholderDimensions>
    //     0x63af54: ldr             x1, [x1, #0x320]
    // 0x63af58: r0 = AllocateArray()
    //     0x63af58: bl              #0xd6987c  ; AllocateArrayStub
    // 0x63af5c: mov             x1, x0
    // 0x63af60: stur            x1, [fp, #-0x20]
    // 0x63af64: ldur            x2, [fp, #-8]
    // 0x63af68: r0 = 0
    //     0x63af68: mov             x0, #0
    // 0x63af6c: CheckStackOverflow
    //     0x63af6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63af70: cmp             SP, x16
    //     0x63af74: b.ls            #0x63b18c
    // 0x63af78: cmp             x0, x2
    // 0x63af7c: b.ge            #0x63af9c
    // 0x63af80: add             x3, x1, x0, lsl #2
    // 0x63af84: r17 = Instance_PlaceholderDimensions
    //     0x63af84: add             x17, PP, #0x22, lsl #12  ; [pp+0x22458] Obj!PlaceholderDimensions@b356b1
    //     0x63af88: ldr             x17, [x17, #0x458]
    // 0x63af8c: StoreField: r3->field_f = r17
    //     0x63af8c: stur            w17, [x3, #0xf]
    // 0x63af90: add             x3, x0, #1
    // 0x63af94: mov             x0, x3
    // 0x63af98: b               #0x63af6c
    // 0x63af9c: ldur            x5, [fp, #-0x10]
    // 0x63afa0: r4 = 0
    //     0x63afa0: mov             x4, #0
    // 0x63afa4: ldr             x3, [fp, #0x10]
    // 0x63afa8: stur            x5, [fp, #-0x10]
    // 0x63afac: stur            x4, [fp, #-0x18]
    // 0x63afb0: CheckStackOverflow
    //     0x63afb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63afb4: cmp             SP, x16
    //     0x63afb8: b.ls            #0x63b194
    // 0x63afbc: cmp             w5, NULL
    // 0x63afc0: b.eq            #0x63b158
    // 0x63afc4: r0 = LoadClassIdInstr(r5)
    //     0x63afc4: ldur            x0, [x5, #-1]
    //     0x63afc8: ubfx            x0, x0, #0xc, #0x14
    // 0x63afcc: SaveReg r5
    //     0x63afcc: str             x5, [SP, #-8]!
    // 0x63afd0: r0 = GDT[cid_x0 + 0xf0dd]()
    //     0x63afd0: mov             x17, #0xf0dd
    //     0x63afd4: add             lr, x0, x17
    //     0x63afd8: ldr             lr, [x21, lr, lsl #3]
    //     0x63afdc: blr             lr
    // 0x63afe0: add             SP, SP, #8
    // 0x63afe4: ldur            x16, [fp, #-0x10]
    // 0x63afe8: r30 = Instance__IntrinsicDimension
    //     0x63afe8: add             lr, PP, #0x49, lsl #12  ; [pp+0x49ac8] Obj!_IntrinsicDimension@b64c31
    //     0x63afec: ldr             lr, [lr, #0xac8]
    // 0x63aff0: stp             lr, x16, [SP, #-0x10]!
    // 0x63aff4: d0 = inf
    //     0x63aff4: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x63aff8: SaveReg d0
    //     0x63aff8: str             d0, [SP, #-8]!
    // 0x63affc: SaveReg r0
    //     0x63affc: str             x0, [SP, #-8]!
    // 0x63b000: r0 = _computeIntrinsicDimension()
    //     0x63b000: bl              #0x62cc04  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsicDimension
    // 0x63b004: add             SP, SP, #0x20
    // 0x63b008: stur            d0, [fp, #-0x40]
    // 0x63b00c: r0 = Size()
    //     0x63b00c: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x63b010: mov             x2, x0
    // 0x63b014: ldur            d0, [fp, #-0x40]
    // 0x63b018: stur            x2, [fp, #-0x38]
    // 0x63b01c: StoreField: r2->field_7 = d0
    //     0x63b01c: stur            d0, [x2, #7]
    // 0x63b020: d0 = 0.000000
    //     0x63b020: eor             v0.16b, v0.16b, v0.16b
    // 0x63b024: StoreField: r2->field_f = d0
    //     0x63b024: stur            d0, [x2, #0xf]
    // 0x63b028: ldr             x3, [fp, #0x10]
    // 0x63b02c: LoadField: r4 = r3->field_83
    //     0x63b02c: ldur            w4, [x3, #0x83]
    // 0x63b030: DecompressPointer r4
    //     0x63b030: add             x4, x4, HEAP, lsl #32
    // 0x63b034: r16 = Sentinel
    //     0x63b034: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x63b038: cmp             w4, w16
    // 0x63b03c: b.eq            #0x63b19c
    // 0x63b040: LoadField: r0 = r4->field_b
    //     0x63b040: ldur            w0, [x4, #0xb]
    // 0x63b044: DecompressPointer r0
    //     0x63b044: add             x0, x0, HEAP, lsl #32
    // 0x63b048: r1 = LoadInt32Instr(r0)
    //     0x63b048: sbfx            x1, x0, #1, #0x1f
    // 0x63b04c: mov             x0, x1
    // 0x63b050: ldur            x1, [fp, #-0x18]
    // 0x63b054: cmp             x1, x0
    // 0x63b058: b.hs            #0x63b1a8
    // 0x63b05c: LoadField: r0 = r4->field_f
    //     0x63b05c: ldur            w0, [x4, #0xf]
    // 0x63b060: DecompressPointer r0
    //     0x63b060: add             x0, x0, HEAP, lsl #32
    // 0x63b064: ldur            x1, [fp, #-0x18]
    // 0x63b068: ArrayLoad: r4 = r0[r1]  ; Unknown_4
    //     0x63b068: add             x16, x0, x1, lsl #2
    //     0x63b06c: ldur            w4, [x16, #0xf]
    // 0x63b070: DecompressPointer r4
    //     0x63b070: add             x4, x4, HEAP, lsl #32
    // 0x63b074: LoadField: r0 = r4->field_b
    //     0x63b074: ldur            w0, [x4, #0xb]
    // 0x63b078: DecompressPointer r0
    //     0x63b078: add             x0, x0, HEAP, lsl #32
    // 0x63b07c: stur            x0, [fp, #-0x30]
    // 0x63b080: LoadField: r5 = r4->field_f
    //     0x63b080: ldur            w5, [x4, #0xf]
    // 0x63b084: DecompressPointer r5
    //     0x63b084: add             x5, x5, HEAP, lsl #32
    // 0x63b088: stur            x5, [fp, #-0x28]
    // 0x63b08c: r0 = PlaceholderDimensions()
    //     0x63b08c: bl              #0x62d738  ; AllocatePlaceholderDimensionsStub -> PlaceholderDimensions (size=0x18)
    // 0x63b090: mov             x2, x0
    // 0x63b094: ldur            x0, [fp, #-0x38]
    // 0x63b098: StoreField: r2->field_7 = r0
    //     0x63b098: stur            w0, [x2, #7]
    // 0x63b09c: ldur            x0, [fp, #-0x30]
    // 0x63b0a0: StoreField: r2->field_b = r0
    //     0x63b0a0: stur            w0, [x2, #0xb]
    // 0x63b0a4: ldur            x0, [fp, #-0x28]
    // 0x63b0a8: StoreField: r2->field_13 = r0
    //     0x63b0a8: stur            w0, [x2, #0x13]
    // 0x63b0ac: ldur            x0, [fp, #-8]
    // 0x63b0b0: ldur            x1, [fp, #-0x18]
    // 0x63b0b4: cmp             x1, x0
    // 0x63b0b8: b.hs            #0x63b1ac
    // 0x63b0bc: ldur            x1, [fp, #-0x20]
    // 0x63b0c0: mov             x0, x2
    // 0x63b0c4: ldur            x3, [fp, #-0x18]
    // 0x63b0c8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x63b0c8: add             x25, x1, x3, lsl #2
    //     0x63b0cc: add             x25, x25, #0xf
    //     0x63b0d0: str             w0, [x25]
    //     0x63b0d4: tbz             w0, #0, #0x63b0f0
    //     0x63b0d8: ldurb           w16, [x1, #-1]
    //     0x63b0dc: ldurb           w17, [x0, #-1]
    //     0x63b0e0: and             x16, x17, x16, lsr #2
    //     0x63b0e4: tst             x16, HEAP, lsr #32
    //     0x63b0e8: b.eq            #0x63b0f0
    //     0x63b0ec: bl              #0xd67e5c
    // 0x63b0f0: ldur            x0, [fp, #-0x10]
    // 0x63b0f4: LoadField: r4 = r0->field_17
    //     0x63b0f4: ldur            w4, [x0, #0x17]
    // 0x63b0f8: DecompressPointer r4
    //     0x63b0f8: add             x4, x4, HEAP, lsl #32
    // 0x63b0fc: stur            x4, [fp, #-0x28]
    // 0x63b100: cmp             w4, NULL
    // 0x63b104: b.eq            #0x63b1b0
    // 0x63b108: mov             x0, x4
    // 0x63b10c: r2 = Null
    //     0x63b10c: mov             x2, NULL
    // 0x63b110: r1 = Null
    //     0x63b110: mov             x1, NULL
    // 0x63b114: r4 = LoadClassIdInstr(r0)
    //     0x63b114: ldur            x4, [x0, #-1]
    //     0x63b118: ubfx            x4, x4, #0xc, #0x14
    // 0x63b11c: cmp             x4, #0x808
    // 0x63b120: b.eq            #0x63b138
    // 0x63b124: r8 = TextParentData<RenderBox>
    //     0x63b124: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x63b128: ldr             x8, [x8, #0x298]
    // 0x63b12c: r3 = Null
    //     0x63b12c: add             x3, PP, #0x51, lsl #12  ; [pp+0x510b0] Null
    //     0x63b130: ldr             x3, [x3, #0xb0]
    // 0x63b134: r0 = DefaultTypeTest()
    //     0x63b134: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x63b138: ldur            x0, [fp, #-0x28]
    // 0x63b13c: LoadField: r5 = r0->field_13
    //     0x63b13c: ldur            w5, [x0, #0x13]
    // 0x63b140: DecompressPointer r5
    //     0x63b140: add             x5, x5, HEAP, lsl #32
    // 0x63b144: ldur            x0, [fp, #-0x18]
    // 0x63b148: add             x4, x0, #1
    // 0x63b14c: ldur            x2, [fp, #-8]
    // 0x63b150: ldur            x1, [fp, #-0x20]
    // 0x63b154: b               #0x63afa4
    // 0x63b158: mov             x0, x3
    // 0x63b15c: LoadField: r1 = r0->field_6f
    //     0x63b15c: ldur            w1, [x0, #0x6f]
    // 0x63b160: DecompressPointer r1
    //     0x63b160: add             x1, x1, HEAP, lsl #32
    // 0x63b164: ldur            x16, [fp, #-0x20]
    // 0x63b168: stp             x16, x1, [SP, #-0x10]!
    // 0x63b16c: r0 = setPlaceholderDimensions()
    //     0x63b16c: bl              #0x62d480  ; [package:flutter/src/painting/text_painter.dart] TextPainter::setPlaceholderDimensions
    // 0x63b170: add             SP, SP, #0x10
    // 0x63b174: r0 = Null
    //     0x63b174: mov             x0, NULL
    // 0x63b178: LeaveFrame
    //     0x63b178: mov             SP, fp
    //     0x63b17c: ldp             fp, lr, [SP], #0x10
    // 0x63b180: ret
    //     0x63b180: ret             
    // 0x63b184: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63b184: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63b188: b               #0x63af20
    // 0x63b18c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63b18c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63b190: b               #0x63af78
    // 0x63b194: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63b194: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63b198: b               #0x63afbc
    // 0x63b19c: r9 = _placeholderSpans
    //     0x63b19c: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d468] Field <RenderParagraph._placeholderSpans@507149678>: late (offset: 0x84)
    //     0x63b1a0: ldr             x9, [x9, #0x468]
    // 0x63b1a4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x63b1a4: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x63b1a8: r0 = RangeErrorSharedWithFPURegs()
    //     0x63b1a8: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x63b1ac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x63b1ac: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x63b1b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63b1b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ computeDistanceToActualBaseline(/* No info */) {
    // ** addr: 0x63de9c, size: 0xcc
    // 0x63de9c: EnterFrame
    //     0x63de9c: stp             fp, lr, [SP, #-0x10]!
    //     0x63dea0: mov             fp, SP
    // 0x63dea4: AllocStack(0x8)
    //     0x63dea4: sub             SP, SP, #8
    // 0x63dea8: CheckStackOverflow
    //     0x63dea8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63deac: cmp             SP, x16
    //     0x63deb0: b.ls            #0x63df60
    // 0x63deb4: ldr             x3, [fp, #0x18]
    // 0x63deb8: LoadField: r4 = r3->field_27
    //     0x63deb8: ldur            w4, [x3, #0x27]
    // 0x63debc: DecompressPointer r4
    //     0x63debc: add             x4, x4, HEAP, lsl #32
    // 0x63dec0: stur            x4, [fp, #-8]
    // 0x63dec4: cmp             w4, NULL
    // 0x63dec8: b.eq            #0x63df40
    // 0x63decc: mov             x0, x4
    // 0x63ded0: r2 = Null
    //     0x63ded0: mov             x2, NULL
    // 0x63ded4: r1 = Null
    //     0x63ded4: mov             x1, NULL
    // 0x63ded8: r4 = LoadClassIdInstr(r0)
    //     0x63ded8: ldur            x4, [x0, #-1]
    //     0x63dedc: ubfx            x4, x4, #0xc, #0x14
    // 0x63dee0: sub             x4, x4, #0x80d
    // 0x63dee4: cmp             x4, #1
    // 0x63dee8: b.ls            #0x63df00
    // 0x63deec: r8 = BoxConstraints
    //     0x63deec: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x63def0: ldr             x8, [x8, #0x1d0]
    // 0x63def4: r3 = Null
    //     0x63def4: add             x3, PP, #0x22, lsl #12  ; [pp+0x224b8] Null
    //     0x63def8: ldr             x3, [x3, #0x4b8]
    // 0x63defc: r0 = BoxConstraints()
    //     0x63defc: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x63df00: ldr             x16, [fp, #0x18]
    // 0x63df04: ldur            lr, [fp, #-8]
    // 0x63df08: stp             lr, x16, [SP, #-0x10]!
    // 0x63df0c: r0 = _layoutTextWithConstraints()
    //     0x63df0c: bl              #0x63df68  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_layoutTextWithConstraints
    // 0x63df10: add             SP, SP, #0x10
    // 0x63df14: ldr             x0, [fp, #0x18]
    // 0x63df18: LoadField: r1 = r0->field_6f
    //     0x63df18: ldur            w1, [x0, #0x6f]
    // 0x63df1c: DecompressPointer r1
    //     0x63df1c: add             x1, x1, HEAP, lsl #32
    // 0x63df20: r16 = Instance_TextBaseline
    //     0x63df20: add             x16, PP, #0x22, lsl #12  ; [pp+0x224c8] Obj!TextBaseline@b66f31
    //     0x63df24: ldr             x16, [x16, #0x4c8]
    // 0x63df28: stp             x16, x1, [SP, #-0x10]!
    // 0x63df2c: r0 = computeDistanceToActualBaseline()
    //     0x63df2c: bl              #0x63da90  ; [package:flutter/src/painting/text_painter.dart] TextPainter::computeDistanceToActualBaseline
    // 0x63df30: add             SP, SP, #0x10
    // 0x63df34: LeaveFrame
    //     0x63df34: mov             SP, fp
    //     0x63df38: ldp             fp, lr, [SP], #0x10
    // 0x63df3c: ret
    //     0x63df3c: ret             
    // 0x63df40: r0 = StateError()
    //     0x63df40: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x63df44: mov             x1, x0
    // 0x63df48: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x63df48: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x63df4c: ldr             x0, [x0, #0x1e8]
    // 0x63df50: StoreField: r1->field_b = r0
    //     0x63df50: stur            w0, [x1, #0xb]
    // 0x63df54: mov             x0, x1
    // 0x63df58: r0 = Throw()
    //     0x63df58: bl              #0xd67e38  ; ThrowStub
    // 0x63df5c: brk             #0
    // 0x63df60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63df60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63df64: b               #0x63deb4
  }
  _ _layoutTextWithConstraints(/* No info */) {
    // ** addr: 0x63df68, size: 0xf0
    // 0x63df68: EnterFrame
    //     0x63df68: stp             fp, lr, [SP, #-0x10]!
    //     0x63df6c: mov             fp, SP
    // 0x63df70: CheckStackOverflow
    //     0x63df70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63df74: cmp             SP, x16
    //     0x63df78: b.ls            #0x63e024
    // 0x63df7c: ldr             x0, [fp, #0x18]
    // 0x63df80: LoadField: r1 = r0->field_6f
    //     0x63df80: ldur            w1, [x0, #0x6f]
    // 0x63df84: DecompressPointer r1
    //     0x63df84: add             x1, x1, HEAP, lsl #32
    // 0x63df88: LoadField: r2 = r0->field_9f
    //     0x63df88: ldur            w2, [x0, #0x9f]
    // 0x63df8c: DecompressPointer r2
    //     0x63df8c: add             x2, x2, HEAP, lsl #32
    // 0x63df90: stp             x2, x1, [SP, #-0x10]!
    // 0x63df94: r0 = setPlaceholderDimensions()
    //     0x63df94: bl              #0x62d480  ; [package:flutter/src/painting/text_painter.dart] TextPainter::setPlaceholderDimensions
    // 0x63df98: add             SP, SP, #0x10
    // 0x63df9c: ldr             x0, [fp, #0x10]
    // 0x63dfa0: LoadField: d0 = r0->field_7
    //     0x63dfa0: ldur            d0, [x0, #7]
    // 0x63dfa4: LoadField: d1 = r0->field_f
    //     0x63dfa4: ldur            d1, [x0, #0xf]
    // 0x63dfa8: r0 = inline_Allocate_Double()
    //     0x63dfa8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63dfac: add             x0, x0, #0x10
    //     0x63dfb0: cmp             x1, x0
    //     0x63dfb4: b.ls            #0x63e02c
    //     0x63dfb8: str             x0, [THR, #0x60]  ; THR::top
    //     0x63dfbc: sub             x0, x0, #0xf
    //     0x63dfc0: mov             x1, #0xd108
    //     0x63dfc4: movk            x1, #3, lsl #16
    //     0x63dfc8: stur            x1, [x0, #-1]
    // 0x63dfcc: StoreField: r0->field_7 = d0
    //     0x63dfcc: stur            d0, [x0, #7]
    // 0x63dfd0: r1 = inline_Allocate_Double()
    //     0x63dfd0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x63dfd4: add             x1, x1, #0x10
    //     0x63dfd8: cmp             x2, x1
    //     0x63dfdc: b.ls            #0x63e03c
    //     0x63dfe0: str             x1, [THR, #0x60]  ; THR::top
    //     0x63dfe4: sub             x1, x1, #0xf
    //     0x63dfe8: mov             x2, #0xd108
    //     0x63dfec: movk            x2, #3, lsl #16
    //     0x63dff0: stur            x2, [x1, #-1]
    // 0x63dff4: StoreField: r1->field_7 = d1
    //     0x63dff4: stur            d1, [x1, #7]
    // 0x63dff8: ldr             x16, [fp, #0x18]
    // 0x63dffc: stp             x0, x16, [SP, #-0x10]!
    // 0x63e000: SaveReg r1
    //     0x63e000: str             x1, [SP, #-8]!
    // 0x63e004: r4 = const [0, 0x3, 0x3, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0x63e004: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f588] List(9) [0, 0x3, 0x3, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    //     0x63e008: ldr             x4, [x4, #0x588]
    // 0x63e00c: r0 = _layoutText()
    //     0x63e00c: bl              #0x62db8c  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_layoutText
    // 0x63e010: add             SP, SP, #0x18
    // 0x63e014: r0 = Null
    //     0x63e014: mov             x0, NULL
    // 0x63e018: LeaveFrame
    //     0x63e018: mov             SP, fp
    //     0x63e01c: ldp             fp, lr, [SP], #0x10
    // 0x63e020: ret
    //     0x63e020: ret             
    // 0x63e024: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63e024: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63e028: b               #0x63df7c
    // 0x63e02c: stp             q0, q1, [SP, #-0x20]!
    // 0x63e030: r0 = AllocateDouble()
    //     0x63e030: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63e034: ldp             q0, q1, [SP], #0x20
    // 0x63e038: b               #0x63dfcc
    // 0x63e03c: SaveReg d1
    //     0x63e03c: str             q1, [SP, #-0x10]!
    // 0x63e040: SaveReg r0
    //     0x63e040: str             x0, [SP, #-8]!
    // 0x63e044: r0 = AllocateDouble()
    //     0x63e044: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63e048: mov             x1, x0
    // 0x63e04c: RestoreReg r0
    //     0x63e04c: ldr             x0, [SP], #8
    // 0x63e050: RestoreReg d1
    //     0x63e050: ldr             q1, [SP], #0x10
    // 0x63e054: b               #0x63dff4
  }
  _ clearSemantics(/* No info */) {
    // ** addr: 0x6450a4, size: 0x44
    // 0x6450a4: EnterFrame
    //     0x6450a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6450a8: mov             fp, SP
    // 0x6450ac: CheckStackOverflow
    //     0x6450ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6450b0: cmp             SP, x16
    //     0x6450b4: b.ls            #0x6450e0
    // 0x6450b8: ldr             x16, [fp, #0x10]
    // 0x6450bc: SaveReg r16
    //     0x6450bc: str             x16, [SP, #-8]!
    // 0x6450c0: r0 = clearSemantics()
    //     0x6450c0: bl              #0x645174  ; [package:flutter/src/rendering/object.dart] RenderObject::clearSemantics
    // 0x6450c4: add             SP, SP, #8
    // 0x6450c8: ldr             x1, [fp, #0x10]
    // 0x6450cc: StoreField: r1->field_a7 = rNULL
    //     0x6450cc: stur            NULL, [x1, #0xa7]
    // 0x6450d0: r0 = Null
    //     0x6450d0: mov             x0, NULL
    // 0x6450d4: LeaveFrame
    //     0x6450d4: mov             SP, fp
    //     0x6450d8: ldp             fp, lr, [SP], #0x10
    // 0x6450dc: ret
    //     0x6450dc: ret             
    // 0x6450e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6450e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6450e4: b               #0x6450b8
  }
  _ assembleSemanticsNode(/* No info */) {
    // ** addr: 0x647e70, size: 0x1450
    // 0x647e70: EnterFrame
    //     0x647e70: stp             fp, lr, [SP, #-0x10]!
    //     0x647e74: mov             fp, SP
    // 0x647e78: AllocStack(0x100)
    //     0x647e78: sub             SP, SP, #0x100
    // 0x647e7c: CheckStackOverflow
    //     0x647e7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x647e80: cmp             SP, x16
    //     0x647e84: b.ls            #0x64923c
    // 0x647e88: r16 = <SemanticsNode>
    //     0x647e88: ldr             x16, [PP, #0x45e0]  ; [pp+0x45e0] TypeArguments: <SemanticsNode>
    // 0x647e8c: stp             xzr, x16, [SP, #-0x10]!
    // 0x647e90: r0 = _GrowableList()
    //     0x647e90: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x647e94: add             SP, SP, #0x10
    // 0x647e98: stur            x0, [fp, #-8]
    // 0x647e9c: ldr             x16, [fp, #0x28]
    // 0x647ea0: SaveReg r16
    //     0x647ea0: str             x16, [SP, #-8]!
    // 0x647ea4: r0 = textDirection()
    //     0x647ea4: bl              #0x6493dc  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::textDirection
    // 0x647ea8: add             SP, SP, #8
    // 0x647eac: stur            x0, [fp, #-0x10]
    // 0x647eb0: ldr             x16, [fp, #0x28]
    // 0x647eb4: SaveReg r16
    //     0x647eb4: str             x16, [SP, #-8]!
    // 0x647eb8: r0 = firstChild()
    //     0x647eb8: bl              #0x6250fc  ; [package:flutter/src/rendering/paragraph.dart] _RenderParagraph&RenderBox&ContainerRenderObjectMixin::firstChild
    // 0x647ebc: add             SP, SP, #8
    // 0x647ec0: stur            x0, [fp, #-0x18]
    // 0x647ec4: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x647ec4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x647ec8: ldr             x0, [x0, #0x598]
    //     0x647ecc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x647ed0: cmp             w0, w16
    //     0x647ed4: b.ne            #0x647ee0
    //     0x647ed8: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x647edc: bl              #0xd67cdc
    // 0x647ee0: r1 = <Key, SemanticsNode>
    //     0x647ee0: add             x1, PP, #0x22, lsl #12  ; [pp+0x22280] TypeArguments: <Key, SemanticsNode>
    //     0x647ee4: ldr             x1, [x1, #0x280]
    // 0x647ee8: stur            x0, [fp, #-0x20]
    // 0x647eec: r0 = _Map()
    //     0x647eec: bl              #0x4b4914  ; Allocate_MapStub -> _Map<X0, X1> (size=-0x8)
    // 0x647ef0: mov             x1, x0
    // 0x647ef4: ldur            x0, [fp, #-0x20]
    // 0x647ef8: stur            x1, [fp, #-0x28]
    // 0x647efc: StoreField: r1->field_1b = r0
    //     0x647efc: stur            w0, [x1, #0x1b]
    // 0x647f00: StoreField: r1->field_b = rZR
    //     0x647f00: stur            wzr, [x1, #0xb]
    // 0x647f04: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x647f04: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x647f08: ldr             x0, [x0, #0x5a0]
    //     0x647f0c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x647f10: cmp             w0, w16
    //     0x647f14: b.ne            #0x647f20
    //     0x647f18: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x647f1c: bl              #0xd67cdc
    // 0x647f20: mov             x1, x0
    // 0x647f24: ldur            x0, [fp, #-0x28]
    // 0x647f28: StoreField: r0->field_f = r1
    //     0x647f28: stur            w1, [x0, #0xf]
    // 0x647f2c: StoreField: r0->field_13 = rZR
    //     0x647f2c: stur            wzr, [x0, #0x13]
    // 0x647f30: StoreField: r0->field_17 = rZR
    //     0x647f30: stur            wzr, [x0, #0x17]
    // 0x647f34: ldr             x1, [fp, #0x28]
    // 0x647f38: LoadField: r2 = r1->field_77
    //     0x647f38: ldur            w2, [x1, #0x77]
    // 0x647f3c: DecompressPointer r2
    //     0x647f3c: add             x2, x2, HEAP, lsl #32
    // 0x647f40: cmp             w2, NULL
    // 0x647f44: b.ne            #0x647f88
    // 0x647f48: LoadField: r2 = r1->field_a3
    //     0x647f48: ldur            w2, [x1, #0xa3]
    // 0x647f4c: DecompressPointer r2
    //     0x647f4c: add             x2, x2, HEAP, lsl #32
    // 0x647f50: cmp             w2, NULL
    // 0x647f54: b.eq            #0x649244
    // 0x647f58: SaveReg r2
    //     0x647f58: str             x2, [SP, #-8]!
    // 0x647f5c: r0 = combineSemanticsInfo()
    //     0x647f5c: bl              #0x64778c  ; [package:flutter/src/painting/inline_span.dart] ::combineSemanticsInfo
    // 0x647f60: add             SP, SP, #8
    // 0x647f64: mov             x2, x0
    // 0x647f68: ldr             x1, [fp, #0x28]
    // 0x647f6c: StoreField: r1->field_77 = r0
    //     0x647f6c: stur            w0, [x1, #0x77]
    //     0x647f70: ldurb           w16, [x1, #-1]
    //     0x647f74: ldurb           w17, [x0, #-1]
    //     0x647f78: and             x16, x17, x16, lsr #2
    //     0x647f7c: tst             x16, HEAP, lsr #32
    //     0x647f80: b.eq            #0x647f88
    //     0x647f84: bl              #0xd6826c
    // 0x647f88: stur            x2, [fp, #-0x60]
    // 0x647f8c: LoadField: r3 = r2->field_7
    //     0x647f8c: ldur            w3, [x2, #7]
    // 0x647f90: DecompressPointer r3
    //     0x647f90: add             x3, x3, HEAP, lsl #32
    // 0x647f94: stur            x3, [fp, #-0x58]
    // 0x647f98: LoadField: r0 = r2->field_b
    //     0x647f98: ldur            w0, [x2, #0xb]
    // 0x647f9c: DecompressPointer r0
    //     0x647f9c: add             x0, x0, HEAP, lsl #32
    // 0x647fa0: r4 = LoadInt32Instr(r0)
    //     0x647fa0: sbfx            x4, x0, #1, #0x1f
    // 0x647fa4: stur            x4, [fp, #-0x50]
    // 0x647fa8: LoadField: r5 = r1->field_6f
    //     0x647fa8: ldur            w5, [x1, #0x6f]
    // 0x647fac: DecompressPointer r5
    //     0x647fac: add             x5, x5, HEAP, lsl #32
    // 0x647fb0: stur            x5, [fp, #-0x20]
    // 0x647fb4: ldur            x14, [fp, #-0x10]
    // 0x647fb8: ldur            x10, [fp, #-0x18]
    // 0x647fbc: ldur            x6, [fp, #-8]
    // 0x647fc0: d0 = 0.000000
    //     0x647fc0: eor             v0.16b, v0.16b, v0.16b
    // 0x647fc4: r13 = 0
    //     0x647fc4: mov             x13, #0
    // 0x647fc8: r12 = 0
    //     0x647fc8: mov             x12, #0
    // 0x647fcc: r11 = 0
    //     0x647fcc: mov             x11, #0
    // 0x647fd0: r9 = 0
    //     0x647fd0: mov             x9, #0
    // 0x647fd4: ldr             x8, [fp, #0x20]
    // 0x647fd8: ldr             x7, [fp, #0x10]
    // 0x647fdc: stur            x14, [fp, #-0x10]
    // 0x647fe0: stur            x13, [fp, #-0x30]
    // 0x647fe4: stur            x12, [fp, #-0x38]
    // 0x647fe8: stur            x11, [fp, #-0x40]
    // 0x647fec: stur            x10, [fp, #-0x18]
    // 0x647ff0: stur            x9, [fp, #-0x48]
    // 0x647ff4: stur            d0, [fp, #-0xd8]
    // 0x647ff8: CheckStackOverflow
    //     0x647ff8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x647ffc: cmp             SP, x16
    //     0x648000: b.ls            #0x649248
    // 0x648004: r0 = LoadClassIdInstr(r2)
    //     0x648004: ldur            x0, [x2, #-1]
    //     0x648008: ubfx            x0, x0, #0xc, #0x14
    // 0x64800c: SaveReg r2
    //     0x64800c: str             x2, [SP, #-8]!
    // 0x648010: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x648010: mov             x17, #0xb8ea
    //     0x648014: add             lr, x0, x17
    //     0x648018: ldr             lr, [x21, lr, lsl #3]
    //     0x64801c: blr             lr
    // 0x648020: add             SP, SP, #8
    // 0x648024: r1 = LoadInt32Instr(r0)
    //     0x648024: sbfx            x1, x0, #1, #0x1f
    //     0x648028: tbz             w0, #0, #0x648030
    //     0x64802c: ldur            x1, [x0, #7]
    // 0x648030: ldur            x2, [fp, #-0x50]
    // 0x648034: cmp             x2, x1
    // 0x648038: b.ne            #0x6491a0
    // 0x64803c: ldur            x4, [fp, #-0x48]
    // 0x648040: ldur            x3, [fp, #-0x60]
    // 0x648044: cmp             x4, x1
    // 0x648048: b.lt            #0x6480a0
    // 0x64804c: ldr             x5, [fp, #0x28]
    // 0x648050: ldur            x0, [fp, #-0x28]
    // 0x648054: StoreField: r5->field_a7 = r0
    //     0x648054: stur            w0, [x5, #0xa7]
    //     0x648058: ldurb           w16, [x5, #-1]
    //     0x64805c: ldurb           w17, [x0, #-1]
    //     0x648060: and             x16, x17, x16, lsr #2
    //     0x648064: tst             x16, HEAP, lsr #32
    //     0x648068: b.eq            #0x648070
    //     0x64806c: bl              #0xd682ec
    // 0x648070: ldr             x16, [fp, #0x20]
    // 0x648074: ldr             lr, [fp, #0x18]
    // 0x648078: stp             lr, x16, [SP, #-0x10]!
    // 0x64807c: ldur            x16, [fp, #-8]
    // 0x648080: SaveReg r16
    //     0x648080: str             x16, [SP, #-8]!
    // 0x648084: r4 = const [0, 0x3, 0x3, 0x2, childrenInInversePaintOrder, 0x2, null]
    //     0x648084: ldr             x4, [PP, #0x7218]  ; [pp+0x7218] List(7) [0, 0x3, 0x3, 0x2, "childrenInInversePaintOrder", 0x2, Null]
    // 0x648088: r0 = updateWith()
    //     0x648088: bl              #0x6469d8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::updateWith
    // 0x64808c: add             SP, SP, #0x18
    // 0x648090: r0 = Null
    //     0x648090: mov             x0, NULL
    // 0x648094: LeaveFrame
    //     0x648094: mov             SP, fp
    //     0x648098: ldp             fp, lr, [SP], #0x10
    // 0x64809c: ret
    //     0x64809c: ret             
    // 0x6480a0: ldr             x5, [fp, #0x28]
    // 0x6480a4: r0 = BoxInt64Instr(r4)
    //     0x6480a4: sbfiz           x0, x4, #1, #0x1f
    //     0x6480a8: cmp             x4, x0, asr #1
    //     0x6480ac: b.eq            #0x6480b8
    //     0x6480b0: bl              #0xd69bb8
    //     0x6480b4: stur            x4, [x0, #7]
    // 0x6480b8: r1 = LoadClassIdInstr(r3)
    //     0x6480b8: ldur            x1, [x3, #-1]
    //     0x6480bc: ubfx            x1, x1, #0xc, #0x14
    // 0x6480c0: stp             x0, x3, [SP, #-0x10]!
    // 0x6480c4: mov             x0, x1
    // 0x6480c8: r0 = GDT[cid_x0 + 0xd175]()
    //     0x6480c8: mov             x17, #0xd175
    //     0x6480cc: add             lr, x0, x17
    //     0x6480d0: ldr             lr, [x21, lr, lsl #3]
    //     0x6480d4: blr             lr
    // 0x6480d8: add             SP, SP, #0x10
    // 0x6480dc: mov             x3, x0
    // 0x6480e0: ldur            x0, [fp, #-0x48]
    // 0x6480e4: stur            x3, [fp, #-0x70]
    // 0x6480e8: add             x9, x0, #1
    // 0x6480ec: stur            x9, [fp, #-0x68]
    // 0x6480f0: cmp             w3, NULL
    // 0x6480f4: b.ne            #0x648128
    // 0x6480f8: mov             x0, x3
    // 0x6480fc: ldur            x2, [fp, #-0x58]
    // 0x648100: r1 = Null
    //     0x648100: mov             x1, NULL
    // 0x648104: cmp             w2, NULL
    // 0x648108: b.eq            #0x648128
    // 0x64810c: LoadField: r4 = r2->field_17
    //     0x64810c: ldur            w4, [x2, #0x17]
    // 0x648110: DecompressPointer r4
    //     0x648110: add             x4, x4, HEAP, lsl #32
    // 0x648114: r8 = X0
    //     0x648114: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x648118: LoadField: r9 = r4->field_7
    //     0x648118: ldur            x9, [x4, #7]
    // 0x64811c: r3 = Null
    //     0x64811c: add             x3, PP, #0x22, lsl #12  ; [pp+0x22288] Null
    //     0x648120: ldr             x3, [x3, #0x288]
    // 0x648124: blr             x9
    // 0x648128: ldur            x1, [fp, #-0x30]
    // 0x64812c: ldur            x0, [fp, #-0x70]
    // 0x648130: LoadField: r2 = r0->field_7
    //     0x648130: ldur            w2, [x0, #7]
    // 0x648134: DecompressPointer r2
    //     0x648134: add             x2, x2, HEAP, lsl #32
    // 0x648138: stur            x2, [fp, #-0x78]
    // 0x64813c: LoadField: r3 = r2->field_7
    //     0x64813c: ldur            w3, [x2, #7]
    // 0x648140: DecompressPointer r3
    //     0x648140: add             x3, x3, HEAP, lsl #32
    // 0x648144: r4 = LoadInt32Instr(r3)
    //     0x648144: sbfx            x4, x3, #1, #0x1f
    // 0x648148: add             x3, x1, x4
    // 0x64814c: stur            x3, [fp, #-0x48]
    // 0x648150: r0 = TextSelection()
    //     0x648150: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x648154: mov             x3, x0
    // 0x648158: ldur            x0, [fp, #-0x30]
    // 0x64815c: stur            x3, [fp, #-0x98]
    // 0x648160: StoreField: r3->field_17 = r0
    //     0x648160: stur            x0, [x3, #0x17]
    // 0x648164: ldur            x2, [fp, #-0x48]
    // 0x648168: StoreField: r3->field_1f = r2
    //     0x648168: stur            x2, [x3, #0x1f]
    // 0x64816c: r4 = Instance_TextAffinity
    //     0x64816c: ldr             x4, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x648170: StoreField: r3->field_27 = r4
    //     0x648170: stur            w4, [x3, #0x27]
    // 0x648174: r5 = false
    //     0x648174: add             x5, NULL, #0x30  ; false
    // 0x648178: StoreField: r3->field_2b = r5
    //     0x648178: stur            w5, [x3, #0x2b]
    // 0x64817c: cmp             x0, x2
    // 0x648180: r16 = true
    //     0x648180: add             x16, NULL, #0x20  ; true
    // 0x648184: r17 = false
    //     0x648184: add             x17, NULL, #0x30  ; false
    // 0x648188: csel            x1, x16, x17, lt
    // 0x64818c: tbnz            w1, #4, #0x648198
    // 0x648190: mov             x6, x0
    // 0x648194: b               #0x64819c
    // 0x648198: mov             x6, x2
    // 0x64819c: tbnz            w1, #4, #0x6481a4
    // 0x6481a0: mov             x0, x2
    // 0x6481a4: ldur            x7, [fp, #-0x70]
    // 0x6481a8: StoreField: r3->field_7 = r6
    //     0x6481a8: stur            x6, [x3, #7]
    // 0x6481ac: StoreField: r3->field_f = r0
    //     0x6481ac: stur            x0, [x3, #0xf]
    // 0x6481b0: LoadField: r0 = r7->field_13
    //     0x6481b0: ldur            w0, [x7, #0x13]
    // 0x6481b4: DecompressPointer r0
    //     0x6481b4: add             x0, x0, HEAP, lsl #32
    // 0x6481b8: tbnz            w0, #4, #0x648540
    // 0x6481bc: ldur            x3, [fp, #-0x38]
    // 0x6481c0: r0 = BoxInt64Instr(r3)
    //     0x6481c0: sbfiz           x0, x3, #1, #0x1f
    //     0x6481c4: cmp             x3, x0, asr #1
    //     0x6481c8: b.eq            #0x6481d4
    //     0x6481cc: bl              #0xd69bb8
    //     0x6481d0: stur            x3, [x0, #7]
    // 0x6481d4: mov             x6, x0
    // 0x6481d8: stur            x6, [fp, #-0x88]
    // 0x6481dc: ldur            x10, [fp, #-0x40]
    // 0x6481e0: ldur            x7, [fp, #-8]
    // 0x6481e4: ldr             x8, [fp, #0x10]
    // 0x6481e8: ldur            x9, [fp, #-0x18]
    // 0x6481ec: stur            x10, [fp, #-0x30]
    // 0x6481f0: CheckStackOverflow
    //     0x6481f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6481f4: cmp             SP, x16
    //     0x6481f8: b.ls            #0x649250
    // 0x6481fc: LoadField: r0 = r8->field_b
    //     0x6481fc: ldur            w0, [x8, #0xb]
    // 0x648200: DecompressPointer r0
    //     0x648200: add             x0, x0, HEAP, lsl #32
    // 0x648204: r1 = LoadInt32Instr(r0)
    //     0x648204: sbfx            x1, x0, #1, #0x1f
    // 0x648208: cmp             x1, x10
    // 0x64820c: b.le            #0x6484b4
    // 0x648210: mov             x0, x1
    // 0x648214: mov             x1, x10
    // 0x648218: cmp             x1, x0
    // 0x64821c: b.hs            #0x649258
    // 0x648220: LoadField: r0 = r8->field_f
    //     0x648220: ldur            w0, [x8, #0xf]
    // 0x648224: DecompressPointer r0
    //     0x648224: add             x0, x0, HEAP, lsl #32
    // 0x648228: ArrayLoad: r1 = r0[r10]  ; Unknown_4
    //     0x648228: add             x16, x0, x10, lsl #2
    //     0x64822c: ldur            w1, [x16, #0xf]
    // 0x648230: DecompressPointer r1
    //     0x648230: add             x1, x1, HEAP, lsl #32
    // 0x648234: stur            x1, [fp, #-0x80]
    // 0x648238: r0 = PlaceholderSpanIndexSemanticsTag()
    //     0x648238: bl              #0x6469cc  ; AllocatePlaceholderSpanIndexSemanticsTagStub -> PlaceholderSpanIndexSemanticsTag (size=0x14)
    // 0x64823c: mov             x3, x0
    // 0x648240: ldur            x0, [fp, #-0x38]
    // 0x648244: stur            x3, [fp, #-0x90]
    // 0x648248: StoreField: r3->field_b = r0
    //     0x648248: stur            x0, [x3, #0xb]
    // 0x64824c: r1 = Null
    //     0x64824c: mov             x1, NULL
    // 0x648250: r2 = 6
    //     0x648250: mov             x2, #6
    // 0x648254: r0 = AllocateArray()
    //     0x648254: bl              #0xd6987c  ; AllocateArrayStub
    // 0x648258: r17 = "PlaceholderSpanIndexSemanticsTag("
    //     0x648258: add             x17, PP, #0x15, lsl #12  ; [pp+0x15158] "PlaceholderSpanIndexSemanticsTag("
    //     0x64825c: ldr             x17, [x17, #0x158]
    // 0x648260: StoreField: r0->field_f = r17
    //     0x648260: stur            w17, [x0, #0xf]
    // 0x648264: ldur            x1, [fp, #-0x88]
    // 0x648268: StoreField: r0->field_13 = r1
    //     0x648268: stur            w1, [x0, #0x13]
    // 0x64826c: r17 = ")"
    //     0x64826c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0x648270: StoreField: r0->field_17 = r17
    //     0x648270: stur            w17, [x0, #0x17]
    // 0x648274: SaveReg r0
    //     0x648274: str             x0, [SP, #-8]!
    // 0x648278: r0 = _interpolate()
    //     0x648278: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x64827c: add             SP, SP, #8
    // 0x648280: ldur            x1, [fp, #-0x90]
    // 0x648284: StoreField: r1->field_7 = r0
    //     0x648284: stur            w0, [x1, #7]
    //     0x648288: ldurb           w16, [x1, #-1]
    //     0x64828c: ldurb           w17, [x0, #-1]
    //     0x648290: and             x16, x17, x16, lsr #2
    //     0x648294: tst             x16, HEAP, lsr #32
    //     0x648298: b.eq            #0x6482a0
    //     0x64829c: bl              #0xd6826c
    // 0x6482a0: ldur            x0, [fp, #-0x80]
    // 0x6482a4: LoadField: r2 = r0->field_63
    //     0x6482a4: ldur            w2, [x0, #0x63]
    // 0x6482a8: DecompressPointer r2
    //     0x6482a8: add             x2, x2, HEAP, lsl #32
    // 0x6482ac: cmp             w2, NULL
    // 0x6482b0: b.eq            #0x6484a8
    // 0x6482b4: stp             x1, x2, [SP, #-0x10]!
    // 0x6482b8: r0 = contains()
    //     0x6482b8: bl              #0x787194  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x6482bc: add             SP, SP, #0x10
    // 0x6482c0: tbnz            w0, #4, #0x64849c
    // 0x6482c4: ldr             x3, [fp, #0x10]
    // 0x6482c8: ldur            x4, [fp, #-0x18]
    // 0x6482cc: ldur            x5, [fp, #-0x30]
    // 0x6482d0: LoadField: r0 = r3->field_b
    //     0x6482d0: ldur            w0, [x3, #0xb]
    // 0x6482d4: DecompressPointer r0
    //     0x6482d4: add             x0, x0, HEAP, lsl #32
    // 0x6482d8: r1 = LoadInt32Instr(r0)
    //     0x6482d8: sbfx            x1, x0, #1, #0x1f
    // 0x6482dc: mov             x0, x1
    // 0x6482e0: mov             x1, x5
    // 0x6482e4: cmp             x1, x0
    // 0x6482e8: b.hs            #0x64925c
    // 0x6482ec: LoadField: r0 = r3->field_f
    //     0x6482ec: ldur            w0, [x3, #0xf]
    // 0x6482f0: DecompressPointer r0
    //     0x6482f0: add             x0, x0, HEAP, lsl #32
    // 0x6482f4: ArrayLoad: r6 = r0[r5]  ; Unknown_4
    //     0x6482f4: add             x16, x0, x5, lsl #2
    //     0x6482f8: ldur            w6, [x16, #0xf]
    // 0x6482fc: DecompressPointer r6
    //     0x6482fc: add             x6, x6, HEAP, lsl #32
    // 0x648300: stur            x6, [fp, #-0x90]
    // 0x648304: cmp             w4, NULL
    // 0x648308: b.eq            #0x649260
    // 0x64830c: LoadField: r7 = r4->field_17
    //     0x64830c: ldur            w7, [x4, #0x17]
    // 0x648310: DecompressPointer r7
    //     0x648310: add             x7, x7, HEAP, lsl #32
    // 0x648314: stur            x7, [fp, #-0x80]
    // 0x648318: cmp             w7, NULL
    // 0x64831c: b.eq            #0x649264
    // 0x648320: mov             x0, x7
    // 0x648324: r2 = Null
    //     0x648324: mov             x2, NULL
    // 0x648328: r1 = Null
    //     0x648328: mov             x1, NULL
    // 0x64832c: r4 = LoadClassIdInstr(r0)
    //     0x64832c: ldur            x4, [x0, #-1]
    //     0x648330: ubfx            x4, x4, #0xc, #0x14
    // 0x648334: cmp             x4, #0x808
    // 0x648338: b.eq            #0x648350
    // 0x64833c: r8 = TextParentData<RenderBox>
    //     0x64833c: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x648340: ldr             x8, [x8, #0x298]
    // 0x648344: r3 = Null
    //     0x648344: add             x3, PP, #0x22, lsl #12  ; [pp+0x222a0] Null
    //     0x648348: ldr             x3, [x3, #0x2a0]
    // 0x64834c: r0 = DefaultTypeTest()
    //     0x64834c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x648350: ldur            x0, [fp, #-0x80]
    // 0x648354: LoadField: r1 = r0->field_17
    //     0x648354: ldur            w1, [x0, #0x17]
    // 0x648358: DecompressPointer r1
    //     0x648358: add             x1, x1, HEAP, lsl #32
    // 0x64835c: cmp             w1, NULL
    // 0x648360: b.eq            #0x648474
    // 0x648364: ldur            x2, [fp, #-8]
    // 0x648368: ldur            x0, [fp, #-0x90]
    // 0x64836c: LoadField: r3 = r0->field_2b
    //     0x64836c: ldur            w3, [x0, #0x2b]
    // 0x648370: DecompressPointer r3
    //     0x648370: add             x3, x3, HEAP, lsl #32
    // 0x648374: LoadField: d0 = r3->field_7
    //     0x648374: ldur            d0, [x3, #7]
    // 0x648378: stur            d0, [fp, #-0xf8]
    // 0x64837c: LoadField: d1 = r3->field_f
    //     0x64837c: ldur            d1, [x3, #0xf]
    // 0x648380: stur            d1, [fp, #-0xf0]
    // 0x648384: LoadField: d2 = r3->field_17
    //     0x648384: ldur            d2, [x3, #0x17]
    // 0x648388: fsub            d3, d2, d0
    // 0x64838c: LoadField: d2 = r1->field_7
    //     0x64838c: ldur            d2, [x1, #7]
    // 0x648390: fmul            d4, d3, d2
    // 0x648394: LoadField: d3 = r3->field_1f
    //     0x648394: ldur            d3, [x3, #0x1f]
    // 0x648398: fsub            d5, d3, d1
    // 0x64839c: fmul            d3, d5, d2
    // 0x6483a0: fadd            d2, d0, d4
    // 0x6483a4: stur            d2, [fp, #-0xe8]
    // 0x6483a8: fadd            d4, d1, d3
    // 0x6483ac: stur            d4, [fp, #-0xe0]
    // 0x6483b0: r0 = Rect()
    //     0x6483b0: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x6483b4: ldur            d0, [fp, #-0xf8]
    // 0x6483b8: StoreField: r0->field_7 = d0
    //     0x6483b8: stur            d0, [x0, #7]
    // 0x6483bc: ldur            d0, [fp, #-0xf0]
    // 0x6483c0: StoreField: r0->field_f = d0
    //     0x6483c0: stur            d0, [x0, #0xf]
    // 0x6483c4: ldur            d0, [fp, #-0xe8]
    // 0x6483c8: StoreField: r0->field_17 = d0
    //     0x6483c8: stur            d0, [x0, #0x17]
    // 0x6483cc: ldur            d0, [fp, #-0xe0]
    // 0x6483d0: StoreField: r0->field_1f = d0
    //     0x6483d0: stur            d0, [x0, #0x1f]
    // 0x6483d4: ldur            x16, [fp, #-0x90]
    // 0x6483d8: stp             x0, x16, [SP, #-0x10]!
    // 0x6483dc: r0 = rect=()
    //     0x6483dc: bl              #0x6468c4  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::rect=
    // 0x6483e0: add             SP, SP, #0x10
    // 0x6483e4: ldur            x0, [fp, #-8]
    // 0x6483e8: LoadField: r1 = r0->field_b
    //     0x6483e8: ldur            w1, [x0, #0xb]
    // 0x6483ec: DecompressPointer r1
    //     0x6483ec: add             x1, x1, HEAP, lsl #32
    // 0x6483f0: stur            x1, [fp, #-0x80]
    // 0x6483f4: LoadField: r2 = r0->field_f
    //     0x6483f4: ldur            w2, [x0, #0xf]
    // 0x6483f8: DecompressPointer r2
    //     0x6483f8: add             x2, x2, HEAP, lsl #32
    // 0x6483fc: LoadField: r3 = r2->field_b
    //     0x6483fc: ldur            w3, [x2, #0xb]
    // 0x648400: DecompressPointer r3
    //     0x648400: add             x3, x3, HEAP, lsl #32
    // 0x648404: cmp             w1, w3
    // 0x648408: b.ne            #0x648418
    // 0x64840c: SaveReg r0
    //     0x64840c: str             x0, [SP, #-8]!
    // 0x648410: r0 = _growToNextCapacity()
    //     0x648410: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x648414: add             SP, SP, #8
    // 0x648418: ldur            x3, [fp, #-8]
    // 0x64841c: ldur            x0, [fp, #-0x80]
    // 0x648420: r2 = LoadInt32Instr(r0)
    //     0x648420: sbfx            x2, x0, #1, #0x1f
    // 0x648424: add             x0, x2, #1
    // 0x648428: lsl             x1, x0, #1
    // 0x64842c: StoreField: r3->field_b = r1
    //     0x64842c: stur            w1, [x3, #0xb]
    // 0x648430: mov             x1, x2
    // 0x648434: cmp             x1, x0
    // 0x648438: b.hs            #0x649268
    // 0x64843c: LoadField: r1 = r3->field_f
    //     0x64843c: ldur            w1, [x3, #0xf]
    // 0x648440: DecompressPointer r1
    //     0x648440: add             x1, x1, HEAP, lsl #32
    // 0x648444: ldur            x0, [fp, #-0x90]
    // 0x648448: ArrayStore: r1[r2] = r0  ; List_4
    //     0x648448: add             x25, x1, x2, lsl #2
    //     0x64844c: add             x25, x25, #0xf
    //     0x648450: str             w0, [x25]
    //     0x648454: tbz             w0, #0, #0x648470
    //     0x648458: ldurb           w16, [x1, #-1]
    //     0x64845c: ldurb           w17, [x0, #-1]
    //     0x648460: and             x16, x17, x16, lsr #2
    //     0x648464: tst             x16, HEAP, lsr #32
    //     0x648468: b.eq            #0x648470
    //     0x64846c: bl              #0xd67e5c
    // 0x648470: b               #0x648478
    // 0x648474: ldur            x3, [fp, #-8]
    // 0x648478: ldur            x4, [fp, #-0x30]
    // 0x64847c: add             x10, x4, #1
    // 0x648480: mov             x7, x3
    // 0x648484: ldur            x3, [fp, #-0x38]
    // 0x648488: ldur            x2, [fp, #-0x48]
    // 0x64848c: ldur            x6, [fp, #-0x88]
    // 0x648490: r5 = false
    //     0x648490: add             x5, NULL, #0x30  ; false
    // 0x648494: r4 = Instance_TextAffinity
    //     0x648494: ldr             x4, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x648498: b               #0x6481e4
    // 0x64849c: ldur            x3, [fp, #-8]
    // 0x6484a0: ldur            x4, [fp, #-0x30]
    // 0x6484a4: b               #0x6484bc
    // 0x6484a8: ldur            x3, [fp, #-8]
    // 0x6484ac: ldur            x4, [fp, #-0x30]
    // 0x6484b0: b               #0x6484bc
    // 0x6484b4: mov             x3, x7
    // 0x6484b8: mov             x4, x10
    // 0x6484bc: ldur            x6, [fp, #-0x38]
    // 0x6484c0: ldur            x5, [fp, #-0x18]
    // 0x6484c4: cmp             w5, NULL
    // 0x6484c8: b.eq            #0x64926c
    // 0x6484cc: LoadField: r7 = r5->field_17
    //     0x6484cc: ldur            w7, [x5, #0x17]
    // 0x6484d0: DecompressPointer r7
    //     0x6484d0: add             x7, x7, HEAP, lsl #32
    // 0x6484d4: stur            x7, [fp, #-0x80]
    // 0x6484d8: cmp             w7, NULL
    // 0x6484dc: b.eq            #0x649270
    // 0x6484e0: mov             x0, x7
    // 0x6484e4: r2 = Null
    //     0x6484e4: mov             x2, NULL
    // 0x6484e8: r1 = Null
    //     0x6484e8: mov             x1, NULL
    // 0x6484ec: r4 = LoadClassIdInstr(r0)
    //     0x6484ec: ldur            x4, [x0, #-1]
    //     0x6484f0: ubfx            x4, x4, #0xc, #0x14
    // 0x6484f4: cmp             x4, #0x808
    // 0x6484f8: b.eq            #0x648510
    // 0x6484fc: r8 = TextParentData<RenderBox>
    //     0x6484fc: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x648500: ldr             x8, [x8, #0x298]
    // 0x648504: r3 = Null
    //     0x648504: add             x3, PP, #0x22, lsl #12  ; [pp+0x222b0] Null
    //     0x648508: ldr             x3, [x3, #0x2b0]
    // 0x64850c: r0 = DefaultTypeTest()
    //     0x64850c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x648510: ldur            x0, [fp, #-0x80]
    // 0x648514: LoadField: r1 = r0->field_13
    //     0x648514: ldur            w1, [x0, #0x13]
    // 0x648518: DecompressPointer r1
    //     0x648518: add             x1, x1, HEAP, lsl #32
    // 0x64851c: ldur            x4, [fp, #-0x38]
    // 0x648520: add             x0, x4, #1
    // 0x648524: ldur            x3, [fp, #-0x10]
    // 0x648528: ldur            d0, [fp, #-0xd8]
    // 0x64852c: mov             x2, x0
    // 0x648530: mov             x0, x1
    // 0x648534: ldur            x1, [fp, #-0x30]
    // 0x648538: ldur            x7, [fp, #-8]
    // 0x64853c: b               #0x649060
    // 0x648540: ldr             x6, [fp, #0x28]
    // 0x648544: ldur            x4, [fp, #-0x38]
    // 0x648548: ldur            x5, [fp, #-0x18]
    // 0x64854c: LoadField: r8 = r6->field_27
    //     0x64854c: ldur            w8, [x6, #0x27]
    // 0x648550: DecompressPointer r8
    //     0x648550: add             x8, x8, HEAP, lsl #32
    // 0x648554: stur            x8, [fp, #-0x80]
    // 0x648558: cmp             w8, NULL
    // 0x64855c: b.eq            #0x6491b8
    // 0x648560: r9 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x648560: add             x9, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x648564: ldr             x9, [x9, #0x1e8]
    // 0x648568: mov             x0, x8
    // 0x64856c: r2 = Null
    //     0x64856c: mov             x2, NULL
    // 0x648570: r1 = Null
    //     0x648570: mov             x1, NULL
    // 0x648574: r4 = LoadClassIdInstr(r0)
    //     0x648574: ldur            x4, [x0, #-1]
    //     0x648578: ubfx            x4, x4, #0xc, #0x14
    // 0x64857c: sub             x4, x4, #0x80d
    // 0x648580: cmp             x4, #1
    // 0x648584: b.ls            #0x64859c
    // 0x648588: r8 = BoxConstraints
    //     0x648588: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x64858c: ldr             x8, [x8, #0x1d0]
    // 0x648590: r3 = Null
    //     0x648590: add             x3, PP, #0x22, lsl #12  ; [pp+0x222c0] Null
    //     0x648594: ldr             x3, [x3, #0x2c0]
    // 0x648598: r0 = BoxConstraints()
    //     0x648598: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x64859c: ldr             x16, [fp, #0x28]
    // 0x6485a0: ldur            lr, [fp, #-0x80]
    // 0x6485a4: stp             lr, x16, [SP, #-0x10]!
    // 0x6485a8: r0 = _layoutTextWithConstraints()
    //     0x6485a8: bl              #0x63df68  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_layoutTextWithConstraints
    // 0x6485ac: add             SP, SP, #0x10
    // 0x6485b0: ldur            x16, [fp, #-0x20]
    // 0x6485b4: ldur            lr, [fp, #-0x98]
    // 0x6485b8: stp             lr, x16, [SP, #-0x10]!
    // 0x6485bc: r0 = getBoxesForSelection()
    //     0x6485bc: bl              #0x51fabc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getBoxesForSelection
    // 0x6485c0: add             SP, SP, #0x10
    // 0x6485c4: mov             x2, x0
    // 0x6485c8: stur            x2, [fp, #-0x90]
    // 0x6485cc: LoadField: r0 = r2->field_b
    //     0x6485cc: ldur            w0, [x2, #0xb]
    // 0x6485d0: DecompressPointer r0
    //     0x6485d0: add             x0, x0, HEAP, lsl #32
    // 0x6485d4: cbnz            w0, #0x6485f4
    // 0x6485d8: ldur            x14, [fp, #-0x10]
    // 0x6485dc: ldur            d0, [fp, #-0xd8]
    // 0x6485e0: ldur            x12, [fp, #-0x38]
    // 0x6485e4: ldur            x11, [fp, #-0x40]
    // 0x6485e8: ldur            x10, [fp, #-0x18]
    // 0x6485ec: ldur            x7, [fp, #-8]
    // 0x6485f0: b               #0x649070
    // 0x6485f4: r1 = LoadInt32Instr(r0)
    //     0x6485f4: sbfx            x1, x0, #1, #0x1f
    // 0x6485f8: cmp             x1, #0
    // 0x6485fc: r16 = true
    //     0x6485fc: add             x16, NULL, #0x20  ; true
    // 0x648600: r17 = false
    //     0x648600: add             x17, NULL, #0x30  ; false
    // 0x648604: csel            x3, x16, x17, gt
    // 0x648608: stur            x3, [fp, #-0x88]
    // 0x64860c: tbnz            w3, #4, #0x649230
    // 0x648610: mov             x0, x1
    // 0x648614: r1 = 0
    //     0x648614: mov             x1, #0
    // 0x648618: cmp             x1, x0
    // 0x64861c: b.hs            #0x649274
    // 0x648620: LoadField: r0 = r2->field_f
    //     0x648620: ldur            w0, [x2, #0xf]
    // 0x648624: DecompressPointer r0
    //     0x648624: add             x0, x0, HEAP, lsl #32
    // 0x648628: LoadField: r1 = r0->field_f
    //     0x648628: ldur            w1, [x0, #0xf]
    // 0x64862c: DecompressPointer r1
    //     0x64862c: add             x1, x1, HEAP, lsl #32
    // 0x648630: stur            x1, [fp, #-0x80]
    // 0x648634: LoadField: d0 = r1->field_7
    //     0x648634: ldur            d0, [x1, #7]
    // 0x648638: stur            d0, [fp, #-0xf8]
    // 0x64863c: LoadField: d1 = r1->field_f
    //     0x64863c: ldur            d1, [x1, #0xf]
    // 0x648640: stur            d1, [fp, #-0xf0]
    // 0x648644: LoadField: d2 = r1->field_17
    //     0x648644: ldur            d2, [x1, #0x17]
    // 0x648648: stur            d2, [fp, #-0xe8]
    // 0x64864c: LoadField: d3 = r1->field_1f
    //     0x64864c: ldur            d3, [x1, #0x1f]
    // 0x648650: stur            d3, [fp, #-0xe0]
    // 0x648654: r0 = Rect()
    //     0x648654: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x648658: ldur            d0, [fp, #-0xf8]
    // 0x64865c: stur            x0, [fp, #-0x98]
    // 0x648660: StoreField: r0->field_7 = d0
    //     0x648660: stur            d0, [x0, #7]
    // 0x648664: ldur            d0, [fp, #-0xf0]
    // 0x648668: StoreField: r0->field_f = d0
    //     0x648668: stur            d0, [x0, #0xf]
    // 0x64866c: ldur            d0, [fp, #-0xe8]
    // 0x648670: StoreField: r0->field_17 = d0
    //     0x648670: stur            d0, [x0, #0x17]
    // 0x648674: ldur            d0, [fp, #-0xe0]
    // 0x648678: StoreField: r0->field_1f = d0
    //     0x648678: stur            d0, [x0, #0x1f]
    // 0x64867c: ldur            x1, [fp, #-0x88]
    // 0x648680: tbnz            w1, #4, #0x649224
    // 0x648684: ldur            x2, [fp, #-0x90]
    // 0x648688: ldur            x1, [fp, #-0x80]
    // 0x64868c: LoadField: r3 = r1->field_27
    //     0x64868c: ldur            w3, [x1, #0x27]
    // 0x648690: DecompressPointer r3
    //     0x648690: add             x3, x3, HEAP, lsl #32
    // 0x648694: stur            x3, [fp, #-0x88]
    // 0x648698: LoadField: r4 = r2->field_7
    //     0x648698: ldur            w4, [x2, #7]
    // 0x64869c: DecompressPointer r4
    //     0x64869c: add             x4, x4, HEAP, lsl #32
    // 0x6486a0: mov             x1, x4
    // 0x6486a4: stur            x4, [fp, #-0x80]
    // 0x6486a8: r0 = SubListIterable()
    //     0x6486a8: bl              #0x4c2748  ; AllocateSubListIterableStub -> SubListIterable<X0> (size=0x1c)
    // 0x6486ac: stur            x0, [fp, #-0xa0]
    // 0x6486b0: ldur            x16, [fp, #-0x90]
    // 0x6486b4: stp             x16, x0, [SP, #-0x10]!
    // 0x6486b8: r1 = 1
    //     0x6486b8: mov             x1, #1
    // 0x6486bc: stp             NULL, x1, [SP, #-0x10]!
    // 0x6486c0: r0 = SubListIterable()
    //     0x6486c0: bl              #0x4c25b4  ; [dart:_internal] SubListIterable::SubListIterable
    // 0x6486c4: add             SP, SP, #0x20
    // 0x6486c8: ldur            x16, [fp, #-0xa0]
    // 0x6486cc: SaveReg r16
    //     0x6486cc: str             x16, [SP, #-8]!
    // 0x6486d0: r0 = length()
    //     0x6486d0: bl              #0x6fd0f8  ; [dart:_internal] SubListIterable::length
    // 0x6486d4: add             SP, SP, #8
    // 0x6486d8: r1 = LoadInt32Instr(r0)
    //     0x6486d8: sbfx            x1, x0, #1, #0x1f
    //     0x6486dc: tbz             w0, #0, #0x6486e4
    //     0x6486e0: ldur            x1, [x0, #7]
    // 0x6486e4: stur            x1, [fp, #-0xa8]
    // 0x6486e8: ldur            x5, [fp, #-0x88]
    // 0x6486ec: ldur            x4, [fp, #-0x98]
    // 0x6486f0: r3 = 0
    //     0x6486f0: mov             x3, #0
    // 0x6486f4: ldur            x2, [fp, #-0xa0]
    // 0x6486f8: stur            x5, [fp, #-0x88]
    // 0x6486fc: stur            x4, [fp, #-0x90]
    // 0x648700: stur            x3, [fp, #-0x30]
    // 0x648704: CheckStackOverflow
    //     0x648704: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x648708: cmp             SP, x16
    //     0x64870c: b.ls            #0x649278
    // 0x648710: r0 = LoadClassIdInstr(r2)
    //     0x648710: ldur            x0, [x2, #-1]
    //     0x648714: ubfx            x0, x0, #0xc, #0x14
    // 0x648718: SaveReg r2
    //     0x648718: str             x2, [SP, #-8]!
    // 0x64871c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x64871c: mov             x17, #0xb8ea
    //     0x648720: add             lr, x0, x17
    //     0x648724: ldr             lr, [x21, lr, lsl #3]
    //     0x648728: blr             lr
    // 0x64872c: add             SP, SP, #8
    // 0x648730: r1 = LoadInt32Instr(r0)
    //     0x648730: sbfx            x1, x0, #1, #0x1f
    //     0x648734: tbz             w0, #0, #0x64873c
    //     0x648738: ldur            x1, [x0, #7]
    // 0x64873c: ldur            x2, [fp, #-0xa8]
    // 0x648740: cmp             x2, x1
    // 0x648744: b.ne            #0x6491d0
    // 0x648748: ldur            x3, [fp, #-0xa0]
    // 0x64874c: ldur            x4, [fp, #-0x30]
    // 0x648750: cmp             x4, x1
    // 0x648754: b.lt            #0x649094
    // 0x648758: ldur            x3, [fp, #-0x90]
    // 0x64875c: d0 = 0.000000
    //     0x64875c: eor             v0.16b, v0.16b, v0.16b
    // 0x648760: LoadField: d1 = r3->field_7
    //     0x648760: ldur            d1, [x3, #7]
    // 0x648764: fcmp            d0, d1
    // 0x648768: b.vs            #0x648778
    // 0x64876c: b.le            #0x648778
    // 0x648770: d2 = 0.000000
    //     0x648770: eor             v2.16b, v2.16b, v2.16b
    // 0x648774: b               #0x6487b4
    // 0x648778: fcmp            d0, d1
    // 0x64877c: b.vs            #0x64878c
    // 0x648780: b.ge            #0x64878c
    // 0x648784: mov             v2.16b, v1.16b
    // 0x648788: b               #0x6487b4
    // 0x64878c: fcmp            d0, d0
    // 0x648790: b.vs            #0x6487a0
    // 0x648794: b.ne            #0x6487a0
    // 0x648798: fadd            d2, d0, d1
    // 0x64879c: b               #0x6487b4
    // 0x6487a0: fcmp            d1, d1
    // 0x6487a4: b.vc            #0x6487b0
    // 0x6487a8: mov             v2.16b, v1.16b
    // 0x6487ac: b               #0x6487b4
    // 0x6487b0: d2 = 0.000000
    //     0x6487b0: eor             v2.16b, v2.16b, v2.16b
    // 0x6487b4: stur            d2, [fp, #-0xf8]
    // 0x6487b8: LoadField: d3 = r3->field_f
    //     0x6487b8: ldur            d3, [x3, #0xf]
    // 0x6487bc: stur            d3, [fp, #-0xf0]
    // 0x6487c0: fcmp            d0, d3
    // 0x6487c4: b.vs            #0x6487d4
    // 0x6487c8: b.le            #0x6487d4
    // 0x6487cc: d4 = 0.000000
    //     0x6487cc: eor             v4.16b, v4.16b, v4.16b
    // 0x6487d0: b               #0x648810
    // 0x6487d4: fcmp            d0, d3
    // 0x6487d8: b.vs            #0x6487e8
    // 0x6487dc: b.ge            #0x6487e8
    // 0x6487e0: mov             v4.16b, v3.16b
    // 0x6487e4: b               #0x648810
    // 0x6487e8: fcmp            d0, d0
    // 0x6487ec: b.vs            #0x6487fc
    // 0x6487f0: b.ne            #0x6487fc
    // 0x6487f4: fadd            d4, d0, d3
    // 0x6487f8: b               #0x648810
    // 0x6487fc: fcmp            d3, d3
    // 0x648800: b.vc            #0x64880c
    // 0x648804: mov             v4.16b, v3.16b
    // 0x648808: b               #0x648810
    // 0x64880c: d4 = 0.000000
    //     0x64880c: eor             v4.16b, v4.16b, v4.16b
    // 0x648810: ldr             x4, [fp, #0x28]
    // 0x648814: stur            d4, [fp, #-0xe8]
    // 0x648818: LoadField: d5 = r3->field_17
    //     0x648818: ldur            d5, [x3, #0x17]
    // 0x64881c: fsub            d6, d5, d1
    // 0x648820: stur            d6, [fp, #-0xe0]
    // 0x648824: LoadField: r5 = r4->field_27
    //     0x648824: ldur            w5, [x4, #0x27]
    // 0x648828: DecompressPointer r5
    //     0x648828: add             x5, x5, HEAP, lsl #32
    // 0x64882c: stur            x5, [fp, #-0x98]
    // 0x648830: cmp             w5, NULL
    // 0x648834: b.eq            #0x6491e8
    // 0x648838: r6 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x648838: add             x6, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x64883c: ldr             x6, [x6, #0x1e8]
    // 0x648840: mov             x0, x5
    // 0x648844: r2 = Null
    //     0x648844: mov             x2, NULL
    // 0x648848: r1 = Null
    //     0x648848: mov             x1, NULL
    // 0x64884c: r4 = LoadClassIdInstr(r0)
    //     0x64884c: ldur            x4, [x0, #-1]
    //     0x648850: ubfx            x4, x4, #0xc, #0x14
    // 0x648854: sub             x4, x4, #0x80d
    // 0x648858: cmp             x4, #1
    // 0x64885c: b.ls            #0x648874
    // 0x648860: r8 = BoxConstraints
    //     0x648860: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x648864: ldr             x8, [x8, #0x1d0]
    // 0x648868: r3 = Null
    //     0x648868: add             x3, PP, #0x22, lsl #12  ; [pp+0x222d0] Null
    //     0x64886c: ldr             x3, [x3, #0x2d0]
    // 0x648870: r0 = BoxConstraints()
    //     0x648870: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x648874: ldur            x0, [fp, #-0x98]
    // 0x648878: LoadField: d0 = r0->field_f
    //     0x648878: ldur            d0, [x0, #0xf]
    // 0x64887c: ldur            d1, [fp, #-0xe0]
    // 0x648880: stur            d0, [fp, #-0x100]
    // 0x648884: fcmp            d1, d0
    // 0x648888: b.vs            #0x648890
    // 0x64888c: b.gt            #0x648934
    // 0x648890: fcmp            d1, d0
    // 0x648894: b.vs            #0x6488a4
    // 0x648898: b.ge            #0x6488a4
    // 0x64889c: mov             v0.16b, v1.16b
    // 0x6488a0: b               #0x648934
    // 0x6488a4: d2 = 0.000000
    //     0x6488a4: eor             v2.16b, v2.16b, v2.16b
    // 0x6488a8: fcmp            d1, d2
    // 0x6488ac: b.vs            #0x6488b4
    // 0x6488b0: b.eq            #0x6488bc
    // 0x6488b4: r0 = false
    //     0x6488b4: add             x0, NULL, #0x30  ; false
    // 0x6488b8: b               #0x6488c0
    // 0x6488bc: r0 = true
    //     0x6488bc: add             x0, NULL, #0x20  ; true
    // 0x6488c0: tbnz            w0, #4, #0x6488d8
    // 0x6488c4: fadd            d3, d1, d0
    // 0x6488c8: fmul            d4, d3, d1
    // 0x6488cc: fmul            d1, d4, d0
    // 0x6488d0: mov             v0.16b, v1.16b
    // 0x6488d4: b               #0x648934
    // 0x6488d8: tbnz            w0, #4, #0x64891c
    // 0x6488dc: r0 = inline_Allocate_Double()
    //     0x6488dc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6488e0: add             x0, x0, #0x10
    //     0x6488e4: cmp             x1, x0
    //     0x6488e8: b.ls            #0x649280
    //     0x6488ec: str             x0, [THR, #0x60]  ; THR::top
    //     0x6488f0: sub             x0, x0, #0xf
    //     0x6488f4: mov             x1, #0xd108
    //     0x6488f8: movk            x1, #3, lsl #16
    //     0x6488fc: stur            x1, [x0, #-1]
    // 0x648900: StoreField: r0->field_7 = d0
    //     0x648900: stur            d0, [x0, #7]
    // 0x648904: SaveReg r0
    //     0x648904: str             x0, [SP, #-8]!
    // 0x648908: r0 = isNegative()
    //     0x648908: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x64890c: add             SP, SP, #8
    // 0x648910: tbnz            w0, #4, #0x64891c
    // 0x648914: ldur            d1, [fp, #-0x100]
    // 0x648918: b               #0x648928
    // 0x64891c: ldur            d1, [fp, #-0x100]
    // 0x648920: fcmp            d1, d1
    // 0x648924: b.vc            #0x648930
    // 0x648928: mov             v0.16b, v1.16b
    // 0x64892c: b               #0x648934
    // 0x648930: ldur            d0, [fp, #-0xe0]
    // 0x648934: ldr             x3, [fp, #0x28]
    // 0x648938: ldur            x5, [fp, #-0x90]
    // 0x64893c: ldur            d1, [fp, #-0xf0]
    // 0x648940: stur            d0, [fp, #-0x100]
    // 0x648944: LoadField: d2 = r5->field_1f
    //     0x648944: ldur            d2, [x5, #0x1f]
    // 0x648948: fsub            d3, d2, d1
    // 0x64894c: stur            d3, [fp, #-0xe0]
    // 0x648950: LoadField: r4 = r3->field_27
    //     0x648950: ldur            w4, [x3, #0x27]
    // 0x648954: DecompressPointer r4
    //     0x648954: add             x4, x4, HEAP, lsl #32
    // 0x648958: stur            x4, [fp, #-0x98]
    // 0x64895c: cmp             w4, NULL
    // 0x648960: b.eq            #0x649200
    // 0x648964: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x648964: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x648968: ldr             x5, [x5, #0x1e8]
    // 0x64896c: mov             x0, x4
    // 0x648970: r2 = Null
    //     0x648970: mov             x2, NULL
    // 0x648974: r1 = Null
    //     0x648974: mov             x1, NULL
    // 0x648978: r4 = LoadClassIdInstr(r0)
    //     0x648978: ldur            x4, [x0, #-1]
    //     0x64897c: ubfx            x4, x4, #0xc, #0x14
    // 0x648980: sub             x4, x4, #0x80d
    // 0x648984: cmp             x4, #1
    // 0x648988: b.ls            #0x6489a0
    // 0x64898c: r8 = BoxConstraints
    //     0x64898c: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x648990: ldr             x8, [x8, #0x1d0]
    // 0x648994: r3 = Null
    //     0x648994: add             x3, PP, #0x22, lsl #12  ; [pp+0x222e0] Null
    //     0x648998: ldr             x3, [x3, #0x2e0]
    // 0x64899c: r0 = BoxConstraints()
    //     0x64899c: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x6489a0: ldur            x0, [fp, #-0x98]
    // 0x6489a4: LoadField: d0 = r0->field_1f
    //     0x6489a4: ldur            d0, [x0, #0x1f]
    // 0x6489a8: ldur            d1, [fp, #-0xe0]
    // 0x6489ac: stur            d0, [fp, #-0xf0]
    // 0x6489b0: fcmp            d1, d0
    // 0x6489b4: b.vs            #0x6489c4
    // 0x6489b8: b.le            #0x6489c4
    // 0x6489bc: mov             v4.16b, v0.16b
    // 0x6489c0: b               #0x648a68
    // 0x6489c4: fcmp            d1, d0
    // 0x6489c8: b.vs            #0x6489d8
    // 0x6489cc: b.ge            #0x6489d8
    // 0x6489d0: mov             v4.16b, v1.16b
    // 0x6489d4: b               #0x648a68
    // 0x6489d8: d2 = 0.000000
    //     0x6489d8: eor             v2.16b, v2.16b, v2.16b
    // 0x6489dc: fcmp            d1, d2
    // 0x6489e0: b.vs            #0x6489e8
    // 0x6489e4: b.eq            #0x6489f0
    // 0x6489e8: r0 = false
    //     0x6489e8: add             x0, NULL, #0x30  ; false
    // 0x6489ec: b               #0x6489f4
    // 0x6489f0: r0 = true
    //     0x6489f0: add             x0, NULL, #0x20  ; true
    // 0x6489f4: tbnz            w0, #4, #0x648a0c
    // 0x6489f8: fadd            d3, d1, d0
    // 0x6489fc: fmul            d4, d3, d1
    // 0x648a00: fmul            d1, d4, d0
    // 0x648a04: mov             v4.16b, v1.16b
    // 0x648a08: b               #0x648a68
    // 0x648a0c: tbnz            w0, #4, #0x648a50
    // 0x648a10: r0 = inline_Allocate_Double()
    //     0x648a10: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x648a14: add             x0, x0, #0x10
    //     0x648a18: cmp             x1, x0
    //     0x648a1c: b.ls            #0x649298
    //     0x648a20: str             x0, [THR, #0x60]  ; THR::top
    //     0x648a24: sub             x0, x0, #0xf
    //     0x648a28: mov             x1, #0xd108
    //     0x648a2c: movk            x1, #3, lsl #16
    //     0x648a30: stur            x1, [x0, #-1]
    // 0x648a34: StoreField: r0->field_7 = d0
    //     0x648a34: stur            d0, [x0, #7]
    // 0x648a38: SaveReg r0
    //     0x648a38: str             x0, [SP, #-8]!
    // 0x648a3c: r0 = isNegative()
    //     0x648a3c: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x648a40: add             SP, SP, #8
    // 0x648a44: tbnz            w0, #4, #0x648a50
    // 0x648a48: ldur            d1, [fp, #-0xf0]
    // 0x648a4c: b               #0x648a5c
    // 0x648a50: ldur            d1, [fp, #-0xf0]
    // 0x648a54: fcmp            d1, d1
    // 0x648a58: b.vc            #0x648a64
    // 0x648a5c: mov             v4.16b, v1.16b
    // 0x648a60: b               #0x648a68
    // 0x648a64: ldur            d4, [fp, #-0xe0]
    // 0x648a68: ldur            d3, [fp, #-0xd8]
    // 0x648a6c: ldur            d1, [fp, #-0xf8]
    // 0x648a70: ldur            d2, [fp, #-0xe8]
    // 0x648a74: ldur            d0, [fp, #-0x100]
    // 0x648a78: ldur            x0, [fp, #-0x70]
    // 0x648a7c: fadd            d5, d1, d0
    // 0x648a80: stur            d5, [fp, #-0xf0]
    // 0x648a84: fadd            d6, d2, d4
    // 0x648a88: mov             v0.16b, v1.16b
    // 0x648a8c: stur            d6, [fp, #-0xe0]
    // 0x648a90: stp             fp, lr, [SP, #-0x10]!
    // 0x648a94: mov             fp, SP
    // 0x648a98: CallRuntime_LibcFloor(double) -> double
    //     0x648a98: and             SP, SP, #0xfffffffffffffff0
    //     0x648a9c: mov             sp, SP
    //     0x648aa0: ldr             x16, [THR, #0x560]  ; THR::LibcFloor
    //     0x648aa4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x648aa8: blr             x16
    //     0x648aac: mov             x16, #8
    //     0x648ab0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x648ab4: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x648ab8: sub             sp, x16, #1, lsl #12
    //     0x648abc: mov             SP, fp
    //     0x648ac0: ldp             fp, lr, [SP], #0x10
    // 0x648ac4: d1 = 4.000000
    //     0x648ac4: fmov            d1, #4.00000000
    // 0x648ac8: fsub            d2, d0, d1
    // 0x648acc: ldur            d0, [fp, #-0xe8]
    // 0x648ad0: stur            d2, [fp, #-0xf8]
    // 0x648ad4: stp             fp, lr, [SP, #-0x10]!
    // 0x648ad8: mov             fp, SP
    // 0x648adc: CallRuntime_LibcFloor(double) -> double
    //     0x648adc: and             SP, SP, #0xfffffffffffffff0
    //     0x648ae0: mov             sp, SP
    //     0x648ae4: ldr             x16, [THR, #0x560]  ; THR::LibcFloor
    //     0x648ae8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x648aec: blr             x16
    //     0x648af0: mov             x16, #8
    //     0x648af4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x648af8: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x648afc: sub             sp, x16, #1, lsl #12
    //     0x648b00: mov             SP, fp
    //     0x648b04: ldp             fp, lr, [SP], #0x10
    // 0x648b08: d1 = 4.000000
    //     0x648b08: fmov            d1, #4.00000000
    // 0x648b0c: fsub            d2, d0, d1
    // 0x648b10: ldur            d0, [fp, #-0xf0]
    // 0x648b14: stur            d2, [fp, #-0xe8]
    // 0x648b18: stp             fp, lr, [SP, #-0x10]!
    // 0x648b1c: mov             fp, SP
    // 0x648b20: CallRuntime_LibcCeil(double) -> double
    //     0x648b20: and             SP, SP, #0xfffffffffffffff0
    //     0x648b24: mov             sp, SP
    //     0x648b28: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x648b2c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x648b30: blr             x16
    //     0x648b34: mov             x16, #8
    //     0x648b38: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x648b3c: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x648b40: sub             sp, x16, #1, lsl #12
    //     0x648b44: mov             SP, fp
    //     0x648b48: ldp             fp, lr, [SP], #0x10
    // 0x648b4c: d1 = 4.000000
    //     0x648b4c: fmov            d1, #4.00000000
    // 0x648b50: fadd            d2, d0, d1
    // 0x648b54: ldur            d0, [fp, #-0xe0]
    // 0x648b58: stur            d2, [fp, #-0xf0]
    // 0x648b5c: stp             fp, lr, [SP, #-0x10]!
    // 0x648b60: mov             fp, SP
    // 0x648b64: CallRuntime_LibcCeil(double) -> double
    //     0x648b64: and             SP, SP, #0xfffffffffffffff0
    //     0x648b68: mov             sp, SP
    //     0x648b6c: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x648b70: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x648b74: blr             x16
    //     0x648b78: mov             x16, #8
    //     0x648b7c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x648b80: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x648b84: sub             sp, x16, #1, lsl #12
    //     0x648b88: mov             SP, fp
    //     0x648b8c: ldp             fp, lr, [SP], #0x10
    // 0x648b90: mov             v1.16b, v0.16b
    // 0x648b94: d0 = 4.000000
    //     0x648b94: fmov            d0, #4.00000000
    // 0x648b98: fadd            d2, d1, d0
    // 0x648b9c: stur            d2, [fp, #-0xe0]
    // 0x648ba0: r0 = Rect()
    //     0x648ba0: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x648ba4: ldur            d0, [fp, #-0xf8]
    // 0x648ba8: stur            x0, [fp, #-0x98]
    // 0x648bac: StoreField: r0->field_7 = d0
    //     0x648bac: stur            d0, [x0, #7]
    // 0x648bb0: ldur            d1, [fp, #-0xe8]
    // 0x648bb4: StoreField: r0->field_f = d1
    //     0x648bb4: stur            d1, [x0, #0xf]
    // 0x648bb8: ldur            d2, [fp, #-0xf0]
    // 0x648bbc: StoreField: r0->field_17 = d2
    //     0x648bbc: stur            d2, [x0, #0x17]
    // 0x648bc0: ldur            d3, [fp, #-0xe0]
    // 0x648bc4: StoreField: r0->field_1f = d3
    //     0x648bc4: stur            d3, [x0, #0x1f]
    // 0x648bc8: r0 = SemanticsConfiguration()
    //     0x648bc8: bl              #0x5102c0  ; AllocateSemanticsConfigurationStub -> SemanticsConfiguration (size=0x94)
    // 0x648bcc: stur            x0, [fp, #-0xb0]
    // 0x648bd0: SaveReg r0
    //     0x648bd0: str             x0, [SP, #-8]!
    // 0x648bd4: r0 = SemanticsConfiguration()
    //     0x648bd4: bl              #0x50fde0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::SemanticsConfiguration
    // 0x648bd8: add             SP, SP, #8
    // 0x648bdc: ldur            d1, [fp, #-0xd8]
    // 0x648be0: d0 = 1.000000
    //     0x648be0: fmov            d0, #1.00000000
    // 0x648be4: fadd            d2, d1, d0
    // 0x648be8: stur            d2, [fp, #-0x100]
    // 0x648bec: r0 = OrdinalSortKey()
    //     0x648bec: bl              #0x6468b8  ; AllocateOrdinalSortKeyStub -> OrdinalSortKey (size=0x14)
    // 0x648bf0: ldur            d0, [fp, #-0xd8]
    // 0x648bf4: StoreField: r0->field_b = d0
    //     0x648bf4: stur            d0, [x0, #0xb]
    // 0x648bf8: ldur            x1, [fp, #-0xb0]
    // 0x648bfc: StoreField: r1->field_23 = r0
    //     0x648bfc: stur            w0, [x1, #0x23]
    //     0x648c00: ldurb           w16, [x1, #-1]
    //     0x648c04: ldurb           w17, [x0, #-1]
    //     0x648c08: and             x16, x17, x16, lsr #2
    //     0x648c0c: tst             x16, HEAP, lsr #32
    //     0x648c10: b.eq            #0x648c18
    //     0x648c14: bl              #0xd6826c
    // 0x648c18: r2 = true
    //     0x648c18: add             x2, NULL, #0x20  ; true
    // 0x648c1c: StoreField: r1->field_13 = r2
    //     0x648c1c: stur            w2, [x1, #0x13]
    // 0x648c20: ldur            x0, [fp, #-0x10]
    // 0x648c24: StoreField: r1->field_73 = r0
    //     0x648c24: stur            w0, [x1, #0x73]
    //     0x648c28: ldurb           w16, [x1, #-1]
    //     0x648c2c: ldurb           w17, [x0, #-1]
    //     0x648c30: and             x16, x17, x16, lsr #2
    //     0x648c34: tst             x16, HEAP, lsr #32
    //     0x648c38: b.eq            #0x648c40
    //     0x648c3c: bl              #0xd6826c
    // 0x648c40: ldur            x0, [fp, #-0x70]
    // 0x648c44: LoadField: r3 = r0->field_b
    //     0x648c44: ldur            w3, [x0, #0xb]
    // 0x648c48: DecompressPointer r3
    //     0x648c48: add             x3, x3, HEAP, lsl #32
    // 0x648c4c: cmp             w3, NULL
    // 0x648c50: b.ne            #0x648c58
    // 0x648c54: ldur            x3, [fp, #-0x78]
    // 0x648c58: stur            x3, [fp, #-0xc0]
    // 0x648c5c: LoadField: r4 = r0->field_1b
    //     0x648c5c: ldur            w4, [x0, #0x1b]
    // 0x648c60: DecompressPointer r4
    //     0x648c60: add             x4, x4, HEAP, lsl #32
    // 0x648c64: stur            x4, [fp, #-0xb8]
    // 0x648c68: r0 = AttributedString()
    //     0x648c68: bl              #0x50ffbc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0x648c6c: mov             x1, x0
    // 0x648c70: ldur            x0, [fp, #-0xc0]
    // 0x648c74: StoreField: r1->field_7 = r0
    //     0x648c74: stur            w0, [x1, #7]
    // 0x648c78: ldur            x0, [fp, #-0xb8]
    // 0x648c7c: StoreField: r1->field_b = r0
    //     0x648c7c: stur            w0, [x1, #0xb]
    // 0x648c80: mov             x0, x1
    // 0x648c84: ldur            x1, [fp, #-0xb0]
    // 0x648c88: StoreField: r1->field_47 = r0
    //     0x648c88: stur            w0, [x1, #0x47]
    //     0x648c8c: ldurb           w16, [x1, #-1]
    //     0x648c90: ldurb           w17, [x0, #-1]
    //     0x648c94: and             x16, x17, x16, lsr #2
    //     0x648c98: tst             x16, HEAP, lsr #32
    //     0x648c9c: b.eq            #0x648ca4
    //     0x648ca0: bl              #0xd6826c
    // 0x648ca4: r0 = true
    //     0x648ca4: add             x0, NULL, #0x20  ; true
    // 0x648ca8: StoreField: r1->field_13 = r0
    //     0x648ca8: stur            w0, [x1, #0x13]
    // 0x648cac: ldur            x6, [fp, #-0x70]
    // 0x648cb0: LoadField: r2 = r6->field_f
    //     0x648cb0: ldur            w2, [x6, #0xf]
    // 0x648cb4: DecompressPointer r2
    //     0x648cb4: add             x2, x2, HEAP, lsl #32
    // 0x648cb8: cmp             w2, NULL
    // 0x648cbc: b.eq            #0x648d04
    // 0x648cc0: LoadField: r3 = r2->field_5b
    //     0x648cc0: ldur            w3, [x2, #0x5b]
    // 0x648cc4: DecompressPointer r3
    //     0x648cc4: add             x3, x3, HEAP, lsl #32
    // 0x648cc8: cmp             w3, NULL
    // 0x648ccc: b.eq            #0x648d04
    // 0x648cd0: r16 = Instance_SemanticsAction
    //     0x648cd0: ldr             x16, [PP, #0x4850]  ; [pp+0x4850] Obj!SemanticsAction@b5ce01
    // 0x648cd4: stp             x16, x1, [SP, #-0x10]!
    // 0x648cd8: SaveReg r3
    //     0x648cd8: str             x3, [SP, #-8]!
    // 0x648cdc: r0 = _addArgumentlessAction()
    //     0x648cdc: bl              #0x6467e0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addArgumentlessAction
    // 0x648ce0: add             SP, SP, #0x18
    // 0x648ce4: ldur            x16, [fp, #-0xb0]
    // 0x648ce8: r30 = Instance_SemanticsFlag
    //     0x648ce8: add             lr, PP, #0x22, lsl #12  ; [pp+0x222f0] Obj!SemanticsFlag@b5cb51
    //     0x648cec: ldr             lr, [lr, #0x2f0]
    // 0x648cf0: stp             lr, x16, [SP, #-0x10]!
    // 0x648cf4: r16 = true
    //     0x648cf4: add             x16, NULL, #0x20  ; true
    // 0x648cf8: SaveReg r16
    //     0x648cf8: str             x16, [SP, #-8]!
    // 0x648cfc: r0 = _setFlag()
    //     0x648cfc: bl              #0x646790  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_setFlag
    // 0x648d00: add             SP, SP, #0x18
    // 0x648d04: ldr             x0, [fp, #0x20]
    // 0x648d08: LoadField: r1 = r0->field_33
    //     0x648d08: ldur            w1, [x0, #0x33]
    // 0x648d0c: DecompressPointer r1
    //     0x648d0c: add             x1, x1, HEAP, lsl #32
    // 0x648d10: cmp             w1, NULL
    // 0x648d14: b.eq            #0x648db4
    // 0x648d18: ldur            x16, [fp, #-0x98]
    // 0x648d1c: stp             x16, x1, [SP, #-0x10]!
    // 0x648d20: r0 = intersect()
    //     0x648d20: bl              #0x642ca8  ; [dart:ui] Rect::intersect
    // 0x648d24: add             SP, SP, #0x10
    // 0x648d28: LoadField: d0 = r0->field_7
    //     0x648d28: ldur            d0, [x0, #7]
    // 0x648d2c: LoadField: d1 = r0->field_17
    //     0x648d2c: ldur            d1, [x0, #0x17]
    // 0x648d30: fcmp            d0, d1
    // 0x648d34: b.vs            #0x648d3c
    // 0x648d38: b.ge            #0x648d50
    // 0x648d3c: LoadField: d0 = r0->field_f
    //     0x648d3c: ldur            d0, [x0, #0xf]
    // 0x648d40: LoadField: d1 = r0->field_1f
    //     0x648d40: ldur            d1, [x0, #0x1f]
    // 0x648d44: fcmp            d0, d1
    // 0x648d48: b.vs            #0x648d98
    // 0x648d4c: b.lt            #0x648d98
    // 0x648d50: ldur            d0, [fp, #-0xf8]
    // 0x648d54: ldur            d1, [fp, #-0xf0]
    // 0x648d58: fcmp            d0, d1
    // 0x648d5c: b.vs            #0x648d6c
    // 0x648d60: b.lt            #0x648d6c
    // 0x648d64: r0 = true
    //     0x648d64: add             x0, NULL, #0x20  ; true
    // 0x648d68: b               #0x648d8c
    // 0x648d6c: ldur            d0, [fp, #-0xe8]
    // 0x648d70: ldur            d1, [fp, #-0xe0]
    // 0x648d74: fcmp            d0, d1
    // 0x648d78: b.vs            #0x648d80
    // 0x648d7c: b.ge            #0x648d88
    // 0x648d80: r0 = false
    //     0x648d80: add             x0, NULL, #0x30  ; false
    // 0x648d84: b               #0x648d8c
    // 0x648d88: r0 = true
    //     0x648d88: add             x0, NULL, #0x20  ; true
    // 0x648d8c: eor             x1, x0, #0x10
    // 0x648d90: mov             x0, x1
    // 0x648d94: b               #0x648d9c
    // 0x648d98: r0 = false
    //     0x648d98: add             x0, NULL, #0x30  ; false
    // 0x648d9c: ldur            x16, [fp, #-0xb0]
    // 0x648da0: r30 = Instance_SemanticsFlag
    //     0x648da0: ldr             lr, [PP, #0x7330]  ; [pp+0x7330] Obj!SemanticsFlag@b5cb61
    // 0x648da4: stp             lr, x16, [SP, #-0x10]!
    // 0x648da8: SaveReg r0
    //     0x648da8: str             x0, [SP, #-8]!
    // 0x648dac: r0 = _setFlag()
    //     0x648dac: bl              #0x646790  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_setFlag
    // 0x648db0: add             SP, SP, #0x18
    // 0x648db4: ldr             x0, [fp, #0x28]
    // 0x648db8: LoadField: r2 = r0->field_a7
    //     0x648db8: ldur            w2, [x0, #0xa7]
    // 0x648dbc: DecompressPointer r2
    //     0x648dbc: add             x2, x2, HEAP, lsl #32
    // 0x648dc0: stur            x2, [fp, #-0xc8]
    // 0x648dc4: cmp             w2, NULL
    // 0x648dc8: b.ne            #0x648dd4
    // 0x648dcc: r1 = Null
    //     0x648dcc: mov             x1, NULL
    // 0x648dd0: b               #0x648e04
    // 0x648dd4: LoadField: r1 = r2->field_13
    //     0x648dd4: ldur            w1, [x2, #0x13]
    // 0x648dd8: DecompressPointer r1
    //     0x648dd8: add             x1, x1, HEAP, lsl #32
    // 0x648ddc: r3 = LoadInt32Instr(r1)
    //     0x648ddc: sbfx            x3, x1, #1, #0x1f
    // 0x648de0: asr             x1, x3, #1
    // 0x648de4: LoadField: r3 = r2->field_17
    //     0x648de4: ldur            w3, [x2, #0x17]
    // 0x648de8: DecompressPointer r3
    //     0x648de8: add             x3, x3, HEAP, lsl #32
    // 0x648dec: r4 = LoadInt32Instr(r3)
    //     0x648dec: sbfx            x4, x3, #1, #0x1f
    // 0x648df0: sub             x3, x1, x4
    // 0x648df4: cbnz            x3, #0x648e00
    // 0x648df8: r1 = false
    //     0x648df8: add             x1, NULL, #0x30  ; false
    // 0x648dfc: b               #0x648e04
    // 0x648e00: r1 = true
    //     0x648e00: add             x1, NULL, #0x20  ; true
    // 0x648e04: cmp             w1, NULL
    // 0x648e08: b.eq            #0x648ee8
    // 0x648e0c: tbnz            w1, #4, #0x648ee4
    // 0x648e10: cmp             w2, NULL
    // 0x648e14: b.eq            #0x6492b0
    // 0x648e18: LoadField: r1 = r2->field_7
    //     0x648e18: ldur            w1, [x2, #7]
    // 0x648e1c: DecompressPointer r1
    //     0x648e1c: add             x1, x1, HEAP, lsl #32
    // 0x648e20: LoadField: r3 = r2->field_f
    //     0x648e20: ldur            w3, [x2, #0xf]
    // 0x648e24: DecompressPointer r3
    //     0x648e24: add             x3, x3, HEAP, lsl #32
    // 0x648e28: stur            x3, [fp, #-0xc0]
    // 0x648e2c: LoadField: r4 = r2->field_13
    //     0x648e2c: ldur            w4, [x2, #0x13]
    // 0x648e30: DecompressPointer r4
    //     0x648e30: add             x4, x4, HEAP, lsl #32
    // 0x648e34: stur            x4, [fp, #-0xb8]
    // 0x648e38: r0 = _CompactIterable()
    //     0x648e38: bl              #0x6493d0  ; Allocate_CompactIterableStub -> _CompactIterable<X0> (size=0x2c)
    // 0x648e3c: mov             x1, x0
    // 0x648e40: ldur            x0, [fp, #-0xc8]
    // 0x648e44: StoreField: r1->field_b = r0
    //     0x648e44: stur            w0, [x1, #0xb]
    // 0x648e48: ldur            x2, [fp, #-0xc0]
    // 0x648e4c: StoreField: r1->field_f = r2
    //     0x648e4c: stur            w2, [x1, #0xf]
    // 0x648e50: ldur            x2, [fp, #-0xb8]
    // 0x648e54: r3 = LoadInt32Instr(r2)
    //     0x648e54: sbfx            x3, x2, #1, #0x1f
    // 0x648e58: StoreField: r1->field_13 = r3
    //     0x648e58: stur            x3, [x1, #0x13]
    // 0x648e5c: r2 = -2
    //     0x648e5c: mov             x2, #-2
    // 0x648e60: StoreField: r1->field_1b = r2
    //     0x648e60: stur            x2, [x1, #0x1b]
    // 0x648e64: r3 = 2
    //     0x648e64: mov             x3, #2
    // 0x648e68: StoreField: r1->field_23 = r3
    //     0x648e68: stur            x3, [x1, #0x23]
    // 0x648e6c: SaveReg r1
    //     0x648e6c: str             x1, [SP, #-8]!
    // 0x648e70: r0 = iterator()
    //     0x648e70: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0x648e74: add             SP, SP, #8
    // 0x648e78: mov             x1, x0
    // 0x648e7c: stur            x1, [fp, #-0xb8]
    // 0x648e80: r0 = LoadClassIdInstr(r1)
    //     0x648e80: ldur            x0, [x1, #-1]
    //     0x648e84: ubfx            x0, x0, #0xc, #0x14
    // 0x648e88: SaveReg r1
    //     0x648e88: str             x1, [SP, #-8]!
    // 0x648e8c: r0 = GDT[cid_x0 + 0x541]()
    //     0x648e8c: add             lr, x0, #0x541
    //     0x648e90: ldr             lr, [x21, lr, lsl #3]
    //     0x648e94: blr             lr
    // 0x648e98: add             SP, SP, #8
    // 0x648e9c: tbnz            w0, #4, #0x649218
    // 0x648ea0: ldur            x0, [fp, #-0xb8]
    // 0x648ea4: r1 = LoadClassIdInstr(r0)
    //     0x648ea4: ldur            x1, [x0, #-1]
    //     0x648ea8: ubfx            x1, x1, #0xc, #0x14
    // 0x648eac: SaveReg r0
    //     0x648eac: str             x0, [SP, #-8]!
    // 0x648eb0: mov             x0, x1
    // 0x648eb4: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x648eb4: add             lr, x0, #0x5ca
    //     0x648eb8: ldr             lr, [x21, lr, lsl #3]
    //     0x648ebc: blr             lr
    // 0x648ec0: add             SP, SP, #8
    // 0x648ec4: ldur            x16, [fp, #-0xc8]
    // 0x648ec8: stp             x0, x16, [SP, #-0x10]!
    // 0x648ecc: r0 = remove()
    //     0x648ecc: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x648ed0: add             SP, SP, #0x10
    // 0x648ed4: cmp             w0, NULL
    // 0x648ed8: b.eq            #0x6492b4
    // 0x648edc: mov             x1, x0
    // 0x648ee0: b               #0x648f4c
    // 0x648ee4: ldr             x0, [fp, #0x28]
    // 0x648ee8: r1 = 2
    //     0x648ee8: mov             x1, #2
    // 0x648eec: r0 = AllocateContext()
    //     0x648eec: bl              #0xd68aa4  ; AllocateContextStub
    // 0x648ef0: mov             x1, x0
    // 0x648ef4: ldr             x0, [fp, #0x28]
    // 0x648ef8: stur            x1, [fp, #-0xb8]
    // 0x648efc: StoreField: r1->field_f = r0
    //     0x648efc: stur            w0, [x1, #0xf]
    // 0x648f00: r0 = UniqueKey()
    //     0x648f00: bl              #0x594010  ; AllocateUniqueKeyStub -> UniqueKey (size=0x8)
    // 0x648f04: ldur            x2, [fp, #-0xb8]
    // 0x648f08: stur            x0, [fp, #-0xc0]
    // 0x648f0c: StoreField: r2->field_13 = r0
    //     0x648f0c: stur            w0, [x2, #0x13]
    // 0x648f10: r0 = SemanticsNode()
    //     0x648f10: bl              #0x646784  ; AllocateSemanticsNodeStub -> SemanticsNode (size=0xc8)
    // 0x648f14: ldur            x2, [fp, #-0xb8]
    // 0x648f18: r1 = Function '<anonymous closure>':.
    //     0x648f18: add             x1, PP, #0x22, lsl #12  ; [pp+0x222f8] AnonymousClosure: (0x649410), of [package:flutter/src/rendering/paragraph.dart] RenderParagraph
    //     0x648f1c: ldr             x1, [x1, #0x2f8]
    // 0x648f20: stur            x0, [fp, #-0xb8]
    // 0x648f24: r0 = AllocateClosure()
    //     0x648f24: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x648f28: ldur            x16, [fp, #-0xb8]
    // 0x648f2c: ldur            lr, [fp, #-0xc0]
    // 0x648f30: stp             lr, x16, [SP, #-0x10]!
    // 0x648f34: SaveReg r0
    //     0x648f34: str             x0, [SP, #-8]!
    // 0x648f38: r4 = const [0, 0x3, 0x3, 0x1, key, 0x1, showOnScreen, 0x2, null]
    //     0x648f38: add             x4, PP, #0x22, lsl #12  ; [pp+0x22300] List(9) [0, 0x3, 0x3, 0x1, "key", 0x1, "showOnScreen", 0x2, Null]
    //     0x648f3c: ldr             x4, [x4, #0x300]
    // 0x648f40: r0 = SemanticsNode()
    //     0x648f40: bl              #0x64642c  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::SemanticsNode
    // 0x648f44: add             SP, SP, #0x18
    // 0x648f48: ldur            x1, [fp, #-0xb8]
    // 0x648f4c: ldur            x0, [fp, #-8]
    // 0x648f50: stur            x1, [fp, #-0xb8]
    // 0x648f54: ldur            x16, [fp, #-0xb0]
    // 0x648f58: stp             x16, x1, [SP, #-0x10]!
    // 0x648f5c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x648f5c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x648f60: r0 = updateWith()
    //     0x648f60: bl              #0x6469d8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::updateWith
    // 0x648f64: add             SP, SP, #0x10
    // 0x648f68: ldur            x16, [fp, #-0xb8]
    // 0x648f6c: ldur            lr, [fp, #-0x98]
    // 0x648f70: stp             lr, x16, [SP, #-0x10]!
    // 0x648f74: r0 = rect=()
    //     0x648f74: bl              #0x6468c4  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::rect=
    // 0x648f78: add             SP, SP, #0x10
    // 0x648f7c: ldur            x0, [fp, #-0xb8]
    // 0x648f80: LoadField: r1 = r0->field_17
    //     0x648f80: ldur            w1, [x0, #0x17]
    // 0x648f84: DecompressPointer r1
    //     0x648f84: add             x1, x1, HEAP, lsl #32
    // 0x648f88: stur            x1, [fp, #-0x98]
    // 0x648f8c: cmp             w1, NULL
    // 0x648f90: b.eq            #0x6492b8
    // 0x648f94: SaveReg r1
    //     0x648f94: str             x1, [SP, #-8]!
    // 0x648f98: r0 = _getHash()
    //     0x648f98: bl              #0x5c2424  ; [dart:core] ::_getHash
    // 0x648f9c: add             SP, SP, #8
    // 0x648fa0: r1 = LoadInt32Instr(r0)
    //     0x648fa0: sbfx            x1, x0, #1, #0x1f
    // 0x648fa4: ldur            x16, [fp, #-0x28]
    // 0x648fa8: ldur            lr, [fp, #-0x98]
    // 0x648fac: stp             lr, x16, [SP, #-0x10]!
    // 0x648fb0: ldur            x16, [fp, #-0xb8]
    // 0x648fb4: stp             x1, x16, [SP, #-0x10]!
    // 0x648fb8: r0 = _set()
    //     0x648fb8: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x648fbc: add             SP, SP, #0x20
    // 0x648fc0: ldur            x0, [fp, #-8]
    // 0x648fc4: LoadField: r1 = r0->field_b
    //     0x648fc4: ldur            w1, [x0, #0xb]
    // 0x648fc8: DecompressPointer r1
    //     0x648fc8: add             x1, x1, HEAP, lsl #32
    // 0x648fcc: stur            x1, [fp, #-0x98]
    // 0x648fd0: LoadField: r2 = r0->field_f
    //     0x648fd0: ldur            w2, [x0, #0xf]
    // 0x648fd4: DecompressPointer r2
    //     0x648fd4: add             x2, x2, HEAP, lsl #32
    // 0x648fd8: LoadField: r3 = r2->field_b
    //     0x648fd8: ldur            w3, [x2, #0xb]
    // 0x648fdc: DecompressPointer r3
    //     0x648fdc: add             x3, x3, HEAP, lsl #32
    // 0x648fe0: cmp             w1, w3
    // 0x648fe4: b.ne            #0x648ff4
    // 0x648fe8: SaveReg r0
    //     0x648fe8: str             x0, [SP, #-8]!
    // 0x648fec: r0 = _growToNextCapacity()
    //     0x648fec: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x648ff0: add             SP, SP, #8
    // 0x648ff4: ldur            x7, [fp, #-8]
    // 0x648ff8: ldur            x0, [fp, #-0x98]
    // 0x648ffc: r2 = LoadInt32Instr(r0)
    //     0x648ffc: sbfx            x2, x0, #1, #0x1f
    // 0x649000: add             x0, x2, #1
    // 0x649004: lsl             x1, x0, #1
    // 0x649008: StoreField: r7->field_b = r1
    //     0x649008: stur            w1, [x7, #0xb]
    // 0x64900c: mov             x1, x2
    // 0x649010: cmp             x1, x0
    // 0x649014: b.hs            #0x6492bc
    // 0x649018: LoadField: r1 = r7->field_f
    //     0x649018: ldur            w1, [x7, #0xf]
    // 0x64901c: DecompressPointer r1
    //     0x64901c: add             x1, x1, HEAP, lsl #32
    // 0x649020: ldur            x0, [fp, #-0xb8]
    // 0x649024: ArrayStore: r1[r2] = r0  ; List_4
    //     0x649024: add             x25, x1, x2, lsl #2
    //     0x649028: add             x25, x25, #0xf
    //     0x64902c: str             w0, [x25]
    //     0x649030: tbz             w0, #0, #0x64904c
    //     0x649034: ldurb           w16, [x1, #-1]
    //     0x649038: ldurb           w17, [x0, #-1]
    //     0x64903c: and             x16, x17, x16, lsr #2
    //     0x649040: tst             x16, HEAP, lsr #32
    //     0x649044: b.eq            #0x64904c
    //     0x649048: bl              #0xd67e5c
    // 0x64904c: ldur            x3, [fp, #-0x88]
    // 0x649050: ldur            d0, [fp, #-0x100]
    // 0x649054: ldur            x2, [fp, #-0x38]
    // 0x649058: ldur            x1, [fp, #-0x40]
    // 0x64905c: ldur            x0, [fp, #-0x18]
    // 0x649060: mov             x14, x3
    // 0x649064: mov             x12, x2
    // 0x649068: mov             x11, x1
    // 0x64906c: mov             x10, x0
    // 0x649070: ldur            x13, [fp, #-0x48]
    // 0x649074: ldur            x9, [fp, #-0x68]
    // 0x649078: ldr             x1, [fp, #0x28]
    // 0x64907c: mov             x6, x7
    // 0x649080: ldur            x5, [fp, #-0x20]
    // 0x649084: ldur            x3, [fp, #-0x58]
    // 0x649088: ldur            x4, [fp, #-0x50]
    // 0x64908c: ldur            x2, [fp, #-0x60]
    // 0x649090: b               #0x647fd4
    // 0x649094: ldur            x7, [fp, #-8]
    // 0x649098: ldur            d0, [fp, #-0xd8]
    // 0x64909c: ldur            x5, [fp, #-0x90]
    // 0x6490a0: ldur            x6, [fp, #-0x70]
    // 0x6490a4: r0 = BoxInt64Instr(r4)
    //     0x6490a4: sbfiz           x0, x4, #1, #0x1f
    //     0x6490a8: cmp             x4, x0, asr #1
    //     0x6490ac: b.eq            #0x6490b8
    //     0x6490b0: bl              #0xd69c6c
    //     0x6490b4: stur            x4, [x0, #7]
    // 0x6490b8: r1 = LoadClassIdInstr(r3)
    //     0x6490b8: ldur            x1, [x3, #-1]
    //     0x6490bc: ubfx            x1, x1, #0xc, #0x14
    // 0x6490c0: stp             x0, x3, [SP, #-0x10]!
    // 0x6490c4: mov             x0, x1
    // 0x6490c8: r0 = GDT[cid_x0 + 0xd175]()
    //     0x6490c8: mov             x17, #0xd175
    //     0x6490cc: add             lr, x0, x17
    //     0x6490d0: ldr             lr, [x21, lr, lsl #3]
    //     0x6490d4: blr             lr
    // 0x6490d8: add             SP, SP, #0x10
    // 0x6490dc: mov             x3, x0
    // 0x6490e0: ldur            x0, [fp, #-0x30]
    // 0x6490e4: stur            x3, [fp, #-0x88]
    // 0x6490e8: add             x4, x0, #1
    // 0x6490ec: stur            x4, [fp, #-0xd0]
    // 0x6490f0: cmp             w3, NULL
    // 0x6490f4: b.ne            #0x649128
    // 0x6490f8: mov             x0, x3
    // 0x6490fc: ldur            x2, [fp, #-0x80]
    // 0x649100: r1 = Null
    //     0x649100: mov             x1, NULL
    // 0x649104: cmp             w2, NULL
    // 0x649108: b.eq            #0x649128
    // 0x64910c: LoadField: r4 = r2->field_17
    //     0x64910c: ldur            w4, [x2, #0x17]
    // 0x649110: DecompressPointer r4
    //     0x649110: add             x4, x4, HEAP, lsl #32
    // 0x649114: r8 = X0
    //     0x649114: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x649118: LoadField: r9 = r4->field_7
    //     0x649118: ldur            x9, [x4, #7]
    // 0x64911c: r3 = Null
    //     0x64911c: add             x3, PP, #0x22, lsl #12  ; [pp+0x22308] Null
    //     0x649120: ldr             x3, [x3, #0x308]
    // 0x649124: blr             x9
    // 0x649128: ldur            x0, [fp, #-0x88]
    // 0x64912c: LoadField: d0 = r0->field_7
    //     0x64912c: ldur            d0, [x0, #7]
    // 0x649130: stur            d0, [fp, #-0xf8]
    // 0x649134: LoadField: d1 = r0->field_f
    //     0x649134: ldur            d1, [x0, #0xf]
    // 0x649138: stur            d1, [fp, #-0xf0]
    // 0x64913c: LoadField: d2 = r0->field_17
    //     0x64913c: ldur            d2, [x0, #0x17]
    // 0x649140: stur            d2, [fp, #-0xe8]
    // 0x649144: LoadField: d3 = r0->field_1f
    //     0x649144: ldur            d3, [x0, #0x1f]
    // 0x649148: stur            d3, [fp, #-0xe0]
    // 0x64914c: r0 = Rect()
    //     0x64914c: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x649150: ldur            d0, [fp, #-0xf8]
    // 0x649154: StoreField: r0->field_7 = d0
    //     0x649154: stur            d0, [x0, #7]
    // 0x649158: ldur            d0, [fp, #-0xf0]
    // 0x64915c: StoreField: r0->field_f = d0
    //     0x64915c: stur            d0, [x0, #0xf]
    // 0x649160: ldur            d0, [fp, #-0xe8]
    // 0x649164: StoreField: r0->field_17 = d0
    //     0x649164: stur            d0, [x0, #0x17]
    // 0x649168: ldur            d0, [fp, #-0xe0]
    // 0x64916c: StoreField: r0->field_1f = d0
    //     0x64916c: stur            d0, [x0, #0x1f]
    // 0x649170: ldur            x16, [fp, #-0x90]
    // 0x649174: stp             x0, x16, [SP, #-0x10]!
    // 0x649178: r0 = expandToInclude()
    //     0x649178: bl              #0x5251a0  ; [dart:ui] Rect::expandToInclude
    // 0x64917c: add             SP, SP, #0x10
    // 0x649180: mov             x1, x0
    // 0x649184: ldur            x0, [fp, #-0x88]
    // 0x649188: LoadField: r5 = r0->field_27
    //     0x649188: ldur            w5, [x0, #0x27]
    // 0x64918c: DecompressPointer r5
    //     0x64918c: add             x5, x5, HEAP, lsl #32
    // 0x649190: mov             x4, x1
    // 0x649194: ldur            x3, [fp, #-0xd0]
    // 0x649198: ldur            x1, [fp, #-0xa8]
    // 0x64919c: b               #0x6486f4
    // 0x6491a0: ldur            x0, [fp, #-0x60]
    // 0x6491a4: r0 = ConcurrentModificationError()
    //     0x6491a4: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x6491a8: ldur            x3, [fp, #-0x60]
    // 0x6491ac: StoreField: r0->field_b = r3
    //     0x6491ac: stur            w3, [x0, #0xb]
    // 0x6491b0: r0 = Throw()
    //     0x6491b0: bl              #0xd67e38  ; ThrowStub
    // 0x6491b4: brk             #0
    // 0x6491b8: r0 = StateError()
    //     0x6491b8: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6491bc: r9 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6491bc: add             x9, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6491c0: ldr             x9, [x9, #0x1e8]
    // 0x6491c4: StoreField: r0->field_b = r9
    //     0x6491c4: stur            w9, [x0, #0xb]
    // 0x6491c8: r0 = Throw()
    //     0x6491c8: bl              #0xd67e38  ; ThrowStub
    // 0x6491cc: brk             #0
    // 0x6491d0: ldur            x0, [fp, #-0xa0]
    // 0x6491d4: r0 = ConcurrentModificationError()
    //     0x6491d4: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x6491d8: ldur            x3, [fp, #-0xa0]
    // 0x6491dc: StoreField: r0->field_b = r3
    //     0x6491dc: stur            w3, [x0, #0xb]
    // 0x6491e0: r0 = Throw()
    //     0x6491e0: bl              #0xd67e38  ; ThrowStub
    // 0x6491e4: brk             #0
    // 0x6491e8: r0 = StateError()
    //     0x6491e8: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6491ec: r6 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6491ec: add             x6, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6491f0: ldr             x6, [x6, #0x1e8]
    // 0x6491f4: StoreField: r0->field_b = r6
    //     0x6491f4: stur            w6, [x0, #0xb]
    // 0x6491f8: r0 = Throw()
    //     0x6491f8: bl              #0xd67e38  ; ThrowStub
    // 0x6491fc: brk             #0
    // 0x649200: r0 = StateError()
    //     0x649200: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x649204: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x649204: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x649208: ldr             x5, [x5, #0x1e8]
    // 0x64920c: StoreField: r0->field_b = r5
    //     0x64920c: stur            w5, [x0, #0xb]
    // 0x649210: r0 = Throw()
    //     0x649210: bl              #0xd67e38  ; ThrowStub
    // 0x649214: brk             #0
    // 0x649218: r0 = noElement()
    //     0x649218: bl              #0x4c8048  ; [dart:_internal] IterableElementError::noElement
    // 0x64921c: r0 = Throw()
    //     0x64921c: bl              #0xd67e38  ; ThrowStub
    // 0x649220: brk             #0
    // 0x649224: r0 = noElement()
    //     0x649224: bl              #0x4c8048  ; [dart:_internal] IterableElementError::noElement
    // 0x649228: r0 = Throw()
    //     0x649228: bl              #0xd67e38  ; ThrowStub
    // 0x64922c: brk             #0
    // 0x649230: r0 = noElement()
    //     0x649230: bl              #0x4c8048  ; [dart:_internal] IterableElementError::noElement
    // 0x649234: r0 = Throw()
    //     0x649234: bl              #0xd67e38  ; ThrowStub
    // 0x649238: brk             #0
    // 0x64923c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64923c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x649240: b               #0x647e88
    // 0x649244: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x649244: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x649248: r0 = StackOverflowSharedWithFPURegs()
    //     0x649248: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x64924c: b               #0x648004
    // 0x649250: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x649250: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x649254: b               #0x6481fc
    // 0x649258: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x649258: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x64925c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x64925c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x649260: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x649260: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x649264: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x649264: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x649268: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x649268: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x64926c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x64926c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x649270: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x649270: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x649274: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x649274: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x649278: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x649278: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64927c: b               #0x648710
    // 0x649280: stp             q1, q2, [SP, #-0x20]!
    // 0x649284: SaveReg d0
    //     0x649284: str             q0, [SP, #-0x10]!
    // 0x649288: r0 = AllocateDouble()
    //     0x649288: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x64928c: RestoreReg d0
    //     0x64928c: ldr             q0, [SP], #0x10
    // 0x649290: ldp             q1, q2, [SP], #0x20
    // 0x649294: b               #0x648900
    // 0x649298: stp             q1, q2, [SP, #-0x20]!
    // 0x64929c: SaveReg d0
    //     0x64929c: str             q0, [SP, #-0x10]!
    // 0x6492a0: r0 = AllocateDouble()
    //     0x6492a0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6492a4: RestoreReg d0
    //     0x6492a4: ldr             q0, [SP], #0x10
    // 0x6492a8: ldp             q1, q2, [SP], #0x20
    // 0x6492ac: b               #0x648a34
    // 0x6492b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6492b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6492b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6492b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6492b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6492b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6492bc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6492bc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ getBoxesForSelection(/* No info */) {
    // ** addr: 0x649308, size: 0xc8
    // 0x649308: EnterFrame
    //     0x649308: stp             fp, lr, [SP, #-0x10]!
    //     0x64930c: mov             fp, SP
    // 0x649310: AllocStack(0x8)
    //     0x649310: sub             SP, SP, #8
    // 0x649314: CheckStackOverflow
    //     0x649314: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x649318: cmp             SP, x16
    //     0x64931c: b.ls            #0x6493c8
    // 0x649320: ldr             x3, [fp, #0x18]
    // 0x649324: LoadField: r4 = r3->field_27
    //     0x649324: ldur            w4, [x3, #0x27]
    // 0x649328: DecompressPointer r4
    //     0x649328: add             x4, x4, HEAP, lsl #32
    // 0x64932c: stur            x4, [fp, #-8]
    // 0x649330: cmp             w4, NULL
    // 0x649334: b.eq            #0x6493a8
    // 0x649338: mov             x0, x4
    // 0x64933c: r2 = Null
    //     0x64933c: mov             x2, NULL
    // 0x649340: r1 = Null
    //     0x649340: mov             x1, NULL
    // 0x649344: r4 = LoadClassIdInstr(r0)
    //     0x649344: ldur            x4, [x0, #-1]
    //     0x649348: ubfx            x4, x4, #0xc, #0x14
    // 0x64934c: sub             x4, x4, #0x80d
    // 0x649350: cmp             x4, #1
    // 0x649354: b.ls            #0x64936c
    // 0x649358: r8 = BoxConstraints
    //     0x649358: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x64935c: ldr             x8, [x8, #0x1d0]
    // 0x649360: r3 = Null
    //     0x649360: add             x3, PP, #0x55, lsl #12  ; [pp+0x55930] Null
    //     0x649364: ldr             x3, [x3, #0x930]
    // 0x649368: r0 = BoxConstraints()
    //     0x649368: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x64936c: ldr             x16, [fp, #0x18]
    // 0x649370: ldur            lr, [fp, #-8]
    // 0x649374: stp             lr, x16, [SP, #-0x10]!
    // 0x649378: r0 = _layoutTextWithConstraints()
    //     0x649378: bl              #0x63df68  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_layoutTextWithConstraints
    // 0x64937c: add             SP, SP, #0x10
    // 0x649380: ldr             x0, [fp, #0x18]
    // 0x649384: LoadField: r1 = r0->field_6f
    //     0x649384: ldur            w1, [x0, #0x6f]
    // 0x649388: DecompressPointer r1
    //     0x649388: add             x1, x1, HEAP, lsl #32
    // 0x64938c: ldr             x16, [fp, #0x10]
    // 0x649390: stp             x16, x1, [SP, #-0x10]!
    // 0x649394: r0 = getBoxesForSelection()
    //     0x649394: bl              #0x51fabc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getBoxesForSelection
    // 0x649398: add             SP, SP, #0x10
    // 0x64939c: LeaveFrame
    //     0x64939c: mov             SP, fp
    //     0x6493a0: ldp             fp, lr, [SP], #0x10
    // 0x6493a4: ret
    //     0x6493a4: ret             
    // 0x6493a8: r0 = StateError()
    //     0x6493a8: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6493ac: mov             x1, x0
    // 0x6493b0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6493b0: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6493b4: ldr             x0, [x0, #0x1e8]
    // 0x6493b8: StoreField: r1->field_b = r0
    //     0x6493b8: stur            w0, [x1, #0xb]
    // 0x6493bc: mov             x0, x1
    // 0x6493c0: r0 = Throw()
    //     0x6493c0: bl              #0xd67e38  ; ThrowStub
    // 0x6493c4: brk             #0
    // 0x6493c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6493c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6493cc: b               #0x649320
  }
  get _ textDirection(/* No info */) {
    // ** addr: 0x6493dc, size: 0x34
    // 0x6493dc: EnterFrame
    //     0x6493dc: stp             fp, lr, [SP, #-0x10]!
    //     0x6493e0: mov             fp, SP
    // 0x6493e4: ldr             x1, [fp, #0x10]
    // 0x6493e8: LoadField: r2 = r1->field_6f
    //     0x6493e8: ldur            w2, [x1, #0x6f]
    // 0x6493ec: DecompressPointer r2
    //     0x6493ec: add             x2, x2, HEAP, lsl #32
    // 0x6493f0: LoadField: r0 = r2->field_1b
    //     0x6493f0: ldur            w0, [x2, #0x1b]
    // 0x6493f4: DecompressPointer r0
    //     0x6493f4: add             x0, x0, HEAP, lsl #32
    // 0x6493f8: cmp             w0, NULL
    // 0x6493fc: b.eq            #0x64940c
    // 0x649400: LeaveFrame
    //     0x649400: mov             SP, fp
    //     0x649404: ldp             fp, lr, [SP], #0x10
    // 0x649408: ret
    //     0x649408: ret             
    // 0x64940c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x64940c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x649410, size: 0xc8
    // 0x649410: EnterFrame
    //     0x649410: stp             fp, lr, [SP, #-0x10]!
    //     0x649414: mov             fp, SP
    // 0x649418: AllocStack(0x10)
    //     0x649418: sub             SP, SP, #0x10
    // 0x64941c: SetupParameters()
    //     0x64941c: ldr             x0, [fp, #0x10]
    //     0x649420: ldur            w1, [x0, #0x17]
    //     0x649424: add             x1, x1, HEAP, lsl #32
    //     0x649428: stur            x1, [fp, #-0x10]
    // 0x64942c: CheckStackOverflow
    //     0x64942c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x649430: cmp             SP, x16
    //     0x649434: b.ls            #0x6494c8
    // 0x649438: LoadField: r0 = r1->field_f
    //     0x649438: ldur            w0, [x1, #0xf]
    // 0x64943c: DecompressPointer r0
    //     0x64943c: add             x0, x0, HEAP, lsl #32
    // 0x649440: LoadField: r2 = r0->field_a7
    //     0x649440: ldur            w2, [x0, #0xa7]
    // 0x649444: DecompressPointer r2
    //     0x649444: add             x2, x2, HEAP, lsl #32
    // 0x649448: stur            x2, [fp, #-8]
    // 0x64944c: cmp             w2, NULL
    // 0x649450: b.eq            #0x6494d0
    // 0x649454: LoadField: r0 = r1->field_13
    //     0x649454: ldur            w0, [x1, #0x13]
    // 0x649458: DecompressPointer r0
    //     0x649458: add             x0, x0, HEAP, lsl #32
    // 0x64945c: stp             x0, x2, [SP, #-0x10]!
    // 0x649460: r0 = _getValueOrData()
    //     0x649460: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x649464: add             SP, SP, #0x10
    // 0x649468: mov             x1, x0
    // 0x64946c: ldur            x0, [fp, #-8]
    // 0x649470: LoadField: r2 = r0->field_f
    //     0x649470: ldur            w2, [x0, #0xf]
    // 0x649474: DecompressPointer r2
    //     0x649474: add             x2, x2, HEAP, lsl #32
    // 0x649478: cmp             w2, w1
    // 0x64947c: b.ne            #0x649484
    // 0x649480: r1 = Null
    //     0x649480: mov             x1, NULL
    // 0x649484: ldur            x0, [fp, #-0x10]
    // 0x649488: cmp             w1, NULL
    // 0x64948c: b.eq            #0x6494d4
    // 0x649490: LoadField: r2 = r0->field_f
    //     0x649490: ldur            w2, [x0, #0xf]
    // 0x649494: DecompressPointer r2
    //     0x649494: add             x2, x2, HEAP, lsl #32
    // 0x649498: LoadField: r0 = r1->field_2b
    //     0x649498: ldur            w0, [x1, #0x2b]
    // 0x64949c: DecompressPointer r0
    //     0x64949c: add             x0, x0, HEAP, lsl #32
    // 0x6494a0: stp             x2, x2, [SP, #-0x10]!
    // 0x6494a4: SaveReg r0
    //     0x6494a4: str             x0, [SP, #-8]!
    // 0x6494a8: r4 = const [0, 0x3, 0x3, 0x1, descendant, 0x1, rect, 0x2, null]
    //     0x6494a8: add             x4, PP, #0x22, lsl #12  ; [pp+0x22318] List(9) [0, 0x3, 0x3, 0x1, "descendant", 0x1, "rect", 0x2, Null]
    //     0x6494ac: ldr             x4, [x4, #0x318]
    // 0x6494b0: r0 = showOnScreen()
    //     0x6494b0: bl              #0x644c40  ; [package:flutter/src/rendering/object.dart] RenderObject::showOnScreen
    // 0x6494b4: add             SP, SP, #0x18
    // 0x6494b8: r0 = Null
    //     0x6494b8: mov             x0, NULL
    // 0x6494bc: LeaveFrame
    //     0x6494bc: mov             SP, fp
    //     0x6494c0: ldp             fp, lr, [SP], #0x10
    // 0x6494c4: ret
    //     0x6494c4: ret             
    // 0x6494c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6494c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6494cc: b               #0x649438
    // 0x6494d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6494d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6494d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6494d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0x64d4cc, size: 0x55c
    // 0x64d4cc: EnterFrame
    //     0x64d4cc: stp             fp, lr, [SP, #-0x10]!
    //     0x64d4d0: mov             fp, SP
    // 0x64d4d4: AllocStack(0x70)
    //     0x64d4d4: sub             SP, SP, #0x70
    // 0x64d4d8: CheckStackOverflow
    //     0x64d4d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64d4dc: cmp             SP, x16
    //     0x64d4e0: b.ls            #0x64da00
    // 0x64d4e4: ldr             x16, [fp, #0x18]
    // 0x64d4e8: ldr             lr, [fp, #0x10]
    // 0x64d4ec: stp             lr, x16, [SP, #-0x10]!
    // 0x64d4f0: r0 = Shader._()
    //     0x64d4f0: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x64d4f4: add             SP, SP, #0x10
    // 0x64d4f8: ldr             x0, [fp, #0x18]
    // 0x64d4fc: LoadField: r1 = r0->field_6f
    //     0x64d4fc: ldur            w1, [x0, #0x6f]
    // 0x64d500: DecompressPointer r1
    //     0x64d500: add             x1, x1, HEAP, lsl #32
    // 0x64d504: stur            x1, [fp, #-8]
    // 0x64d508: LoadField: r2 = r1->field_f
    //     0x64d508: ldur            w2, [x1, #0xf]
    // 0x64d50c: DecompressPointer r2
    //     0x64d50c: add             x2, x2, HEAP, lsl #32
    // 0x64d510: cmp             w2, NULL
    // 0x64d514: b.eq            #0x64da08
    // 0x64d518: SaveReg r2
    //     0x64d518: str             x2, [SP, #-8]!
    // 0x64d51c: r0 = getSemanticsInformation()
    //     0x64d51c: bl              #0x64ce54  ; [package:flutter/src/painting/inline_span.dart] InlineSpan::getSemanticsInformation
    // 0x64d520: add             SP, SP, #8
    // 0x64d524: mov             x4, x0
    // 0x64d528: ldr             x3, [fp, #0x18]
    // 0x64d52c: stur            x4, [fp, #-0x10]
    // 0x64d530: StoreField: r3->field_a3 = r0
    //     0x64d530: stur            w0, [x3, #0xa3]
    //     0x64d534: ldurb           w16, [x3, #-1]
    //     0x64d538: ldurb           w17, [x0, #-1]
    //     0x64d53c: and             x16, x17, x16, lsr #2
    //     0x64d540: tst             x16, HEAP, lsr #32
    //     0x64d544: b.eq            #0x64d54c
    //     0x64d548: bl              #0xd682ac
    // 0x64d54c: r1 = Function '<anonymous closure>':.
    //     0x64d54c: add             x1, PP, #0x22, lsl #12  ; [pp+0x22350] AnonymousClosure: (0xc9fb98), in [package:flutter/src/rendering/paragraph.dart] RenderParagraph::describeSemanticsConfiguration (0x64d4cc)
    //     0x64d550: ldr             x1, [x1, #0x350]
    // 0x64d554: r2 = Null
    //     0x64d554: mov             x2, NULL
    // 0x64d558: r0 = AllocateClosure()
    //     0x64d558: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x64d55c: ldur            x16, [fp, #-0x10]
    // 0x64d560: stp             x0, x16, [SP, #-0x10]!
    // 0x64d564: r0 = any()
    //     0x64d564: bl              #0x6f72b8  ; [dart:collection] _ListBase&Object&ListMixin::any
    // 0x64d568: add             SP, SP, #0x10
    // 0x64d56c: tbnz            w0, #4, #0x64d584
    // 0x64d570: ldr             x1, [fp, #0x10]
    // 0x64d574: r0 = true
    //     0x64d574: add             x0, NULL, #0x20  ; true
    // 0x64d578: StoreField: r1->field_b = r0
    //     0x64d578: stur            w0, [x1, #0xb]
    // 0x64d57c: StoreField: r1->field_7 = r0
    //     0x64d57c: stur            w0, [x1, #7]
    // 0x64d580: b               #0x64d9d8
    // 0x64d584: ldr             x2, [fp, #0x18]
    // 0x64d588: ldr             x1, [fp, #0x10]
    // 0x64d58c: r0 = true
    //     0x64d58c: add             x0, NULL, #0x20  ; true
    // 0x64d590: LoadField: r3 = r2->field_73
    //     0x64d590: ldur            w3, [x2, #0x73]
    // 0x64d594: DecompressPointer r3
    //     0x64d594: add             x3, x3, HEAP, lsl #32
    // 0x64d598: cmp             w3, NULL
    // 0x64d59c: b.ne            #0x64d97c
    // 0x64d5a0: r0 = StringBuffer()
    //     0x64d5a0: bl              #0x4d1e30  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x64d5a4: stur            x0, [fp, #-0x10]
    // 0x64d5a8: SaveReg r0
    //     0x64d5a8: str             x0, [SP, #-8]!
    // 0x64d5ac: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x64d5ac: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x64d5b0: r0 = StringBuffer()
    //     0x64d5b0: bl              #0x4d16e0  ; [dart:core] StringBuffer::StringBuffer
    // 0x64d5b4: add             SP, SP, #8
    // 0x64d5b8: r16 = <StringAttribute>
    //     0x64d5b8: ldr             x16, [PP, #0x48a0]  ; [pp+0x48a0] TypeArguments: <StringAttribute>
    // 0x64d5bc: stp             xzr, x16, [SP, #-0x10]!
    // 0x64d5c0: r0 = _GrowableList()
    //     0x64d5c0: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x64d5c4: add             SP, SP, #0x10
    // 0x64d5c8: mov             x2, x0
    // 0x64d5cc: ldr             x1, [fp, #0x18]
    // 0x64d5d0: stur            x2, [fp, #-0x40]
    // 0x64d5d4: LoadField: r3 = r1->field_a3
    //     0x64d5d4: ldur            w3, [x1, #0xa3]
    // 0x64d5d8: DecompressPointer r3
    //     0x64d5d8: add             x3, x3, HEAP, lsl #32
    // 0x64d5dc: stur            x3, [fp, #-0x38]
    // 0x64d5e0: cmp             w3, NULL
    // 0x64d5e4: b.eq            #0x64da0c
    // 0x64d5e8: LoadField: r4 = r3->field_7
    //     0x64d5e8: ldur            w4, [x3, #7]
    // 0x64d5ec: DecompressPointer r4
    //     0x64d5ec: add             x4, x4, HEAP, lsl #32
    // 0x64d5f0: stur            x4, [fp, #-0x30]
    // 0x64d5f4: LoadField: r0 = r3->field_b
    //     0x64d5f4: ldur            w0, [x3, #0xb]
    // 0x64d5f8: DecompressPointer r0
    //     0x64d5f8: add             x0, x0, HEAP, lsl #32
    // 0x64d5fc: r5 = LoadInt32Instr(r0)
    //     0x64d5fc: sbfx            x5, x0, #1, #0x1f
    // 0x64d600: stur            x5, [fp, #-0x28]
    // 0x64d604: r7 = 0
    //     0x64d604: mov             x7, #0
    // 0x64d608: r6 = 0
    //     0x64d608: mov             x6, #0
    // 0x64d60c: stur            x7, [fp, #-0x18]
    // 0x64d610: stur            x6, [fp, #-0x20]
    // 0x64d614: CheckStackOverflow
    //     0x64d614: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64d618: cmp             SP, x16
    //     0x64d61c: b.ls            #0x64da10
    // 0x64d620: r0 = LoadClassIdInstr(r3)
    //     0x64d620: ldur            x0, [x3, #-1]
    //     0x64d624: ubfx            x0, x0, #0xc, #0x14
    // 0x64d628: SaveReg r3
    //     0x64d628: str             x3, [SP, #-8]!
    // 0x64d62c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x64d62c: mov             x17, #0xb8ea
    //     0x64d630: add             lr, x0, x17
    //     0x64d634: ldr             lr, [x21, lr, lsl #3]
    //     0x64d638: blr             lr
    // 0x64d63c: add             SP, SP, #8
    // 0x64d640: r1 = LoadInt32Instr(r0)
    //     0x64d640: sbfx            x1, x0, #1, #0x1f
    //     0x64d644: tbz             w0, #0, #0x64d64c
    //     0x64d648: ldur            x1, [x0, #7]
    // 0x64d64c: ldur            x2, [fp, #-0x28]
    // 0x64d650: cmp             x2, x1
    // 0x64d654: b.ne            #0x64d9e8
    // 0x64d658: ldur            x3, [fp, #-0x38]
    // 0x64d65c: ldur            x4, [fp, #-0x20]
    // 0x64d660: cmp             x4, x1
    // 0x64d664: b.lt            #0x64d6c8
    // 0x64d668: ldr             x0, [fp, #0x18]
    // 0x64d66c: ldur            x1, [fp, #-0x40]
    // 0x64d670: ldur            x16, [fp, #-0x10]
    // 0x64d674: SaveReg r16
    //     0x64d674: str             x16, [SP, #-8]!
    // 0x64d678: r0 = toString()
    //     0x64d678: bl              #0xaba59c  ; [dart:core] StringBuffer::toString
    // 0x64d67c: add             SP, SP, #8
    // 0x64d680: stur            x0, [fp, #-0x48]
    // 0x64d684: r0 = AttributedString()
    //     0x64d684: bl              #0x50ffbc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0x64d688: mov             x1, x0
    // 0x64d68c: ldur            x0, [fp, #-0x48]
    // 0x64d690: StoreField: r1->field_7 = r0
    //     0x64d690: stur            w0, [x1, #7]
    // 0x64d694: ldur            x5, [fp, #-0x40]
    // 0x64d698: StoreField: r1->field_b = r5
    //     0x64d698: stur            w5, [x1, #0xb]
    // 0x64d69c: mov             x0, x1
    // 0x64d6a0: ldr             x6, [fp, #0x18]
    // 0x64d6a4: StoreField: r6->field_73 = r0
    //     0x64d6a4: stur            w0, [x6, #0x73]
    //     0x64d6a8: ldurb           w16, [x6, #-1]
    //     0x64d6ac: ldurb           w17, [x0, #-1]
    //     0x64d6b0: and             x16, x17, x16, lsr #2
    //     0x64d6b4: tst             x16, HEAP, lsr #32
    //     0x64d6b8: b.eq            #0x64d6c0
    //     0x64d6bc: bl              #0xd6830c
    // 0x64d6c0: mov             x0, x1
    // 0x64d6c4: b               #0x64d980
    // 0x64d6c8: ldr             x6, [fp, #0x18]
    // 0x64d6cc: ldur            x5, [fp, #-0x40]
    // 0x64d6d0: r0 = BoxInt64Instr(r4)
    //     0x64d6d0: sbfiz           x0, x4, #1, #0x1f
    //     0x64d6d4: cmp             x4, x0, asr #1
    //     0x64d6d8: b.eq            #0x64d6e4
    //     0x64d6dc: bl              #0xd69bb8
    //     0x64d6e0: stur            x4, [x0, #7]
    // 0x64d6e4: r1 = LoadClassIdInstr(r3)
    //     0x64d6e4: ldur            x1, [x3, #-1]
    //     0x64d6e8: ubfx            x1, x1, #0xc, #0x14
    // 0x64d6ec: stp             x0, x3, [SP, #-0x10]!
    // 0x64d6f0: mov             x0, x1
    // 0x64d6f4: r0 = GDT[cid_x0 + 0xd175]()
    //     0x64d6f4: mov             x17, #0xd175
    //     0x64d6f8: add             lr, x0, x17
    //     0x64d6fc: ldr             lr, [x21, lr, lsl #3]
    //     0x64d700: blr             lr
    // 0x64d704: add             SP, SP, #0x10
    // 0x64d708: mov             x3, x0
    // 0x64d70c: ldur            x0, [fp, #-0x20]
    // 0x64d710: stur            x3, [fp, #-0x48]
    // 0x64d714: add             x6, x0, #1
    // 0x64d718: stur            x6, [fp, #-0x50]
    // 0x64d71c: cmp             w3, NULL
    // 0x64d720: b.ne            #0x64d754
    // 0x64d724: mov             x0, x3
    // 0x64d728: ldur            x2, [fp, #-0x30]
    // 0x64d72c: r1 = Null
    //     0x64d72c: mov             x1, NULL
    // 0x64d730: cmp             w2, NULL
    // 0x64d734: b.eq            #0x64d754
    // 0x64d738: LoadField: r4 = r2->field_17
    //     0x64d738: ldur            w4, [x2, #0x17]
    // 0x64d73c: DecompressPointer r4
    //     0x64d73c: add             x4, x4, HEAP, lsl #32
    // 0x64d740: r8 = X0
    //     0x64d740: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x64d744: LoadField: r9 = r4->field_7
    //     0x64d744: ldur            x9, [x4, #7]
    // 0x64d748: r3 = Null
    //     0x64d748: add             x3, PP, #0x22, lsl #12  ; [pp+0x22358] Null
    //     0x64d74c: ldr             x3, [x3, #0x358]
    // 0x64d750: blr             x9
    // 0x64d754: ldur            x0, [fp, #-0x48]
    // 0x64d758: LoadField: r1 = r0->field_b
    //     0x64d758: ldur            w1, [x0, #0xb]
    // 0x64d75c: DecompressPointer r1
    //     0x64d75c: add             x1, x1, HEAP, lsl #32
    // 0x64d760: cmp             w1, NULL
    // 0x64d764: b.ne            #0x64d770
    // 0x64d768: LoadField: r1 = r0->field_7
    //     0x64d768: ldur            w1, [x0, #7]
    // 0x64d76c: DecompressPointer r1
    //     0x64d76c: add             x1, x1, HEAP, lsl #32
    // 0x64d770: stur            x1, [fp, #-0x58]
    // 0x64d774: LoadField: r2 = r0->field_1b
    //     0x64d774: ldur            w2, [x0, #0x1b]
    // 0x64d778: DecompressPointer r2
    //     0x64d778: add             x2, x2, HEAP, lsl #32
    // 0x64d77c: r0 = LoadClassIdInstr(r2)
    //     0x64d77c: ldur            x0, [x2, #-1]
    //     0x64d780: ubfx            x0, x0, #0xc, #0x14
    // 0x64d784: SaveReg r2
    //     0x64d784: str             x2, [SP, #-8]!
    // 0x64d788: r0 = GDT[cid_x0 + 0xb940]()
    //     0x64d788: mov             x17, #0xb940
    //     0x64d78c: add             lr, x0, x17
    //     0x64d790: ldr             lr, [x21, lr, lsl #3]
    //     0x64d794: blr             lr
    // 0x64d798: add             SP, SP, #8
    // 0x64d79c: mov             x1, x0
    // 0x64d7a0: stur            x1, [fp, #-0x48]
    // 0x64d7a4: ldur            x2, [fp, #-0x40]
    // 0x64d7a8: ldur            x3, [fp, #-0x18]
    // 0x64d7ac: CheckStackOverflow
    //     0x64d7ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64d7b0: cmp             SP, x16
    //     0x64d7b4: b.ls            #0x64da18
    // 0x64d7b8: r0 = LoadClassIdInstr(r1)
    //     0x64d7b8: ldur            x0, [x1, #-1]
    //     0x64d7bc: ubfx            x0, x0, #0xc, #0x14
    // 0x64d7c0: SaveReg r1
    //     0x64d7c0: str             x1, [SP, #-8]!
    // 0x64d7c4: r0 = GDT[cid_x0 + 0x541]()
    //     0x64d7c4: add             lr, x0, #0x541
    //     0x64d7c8: ldr             lr, [x21, lr, lsl #3]
    //     0x64d7cc: blr             lr
    // 0x64d7d0: add             SP, SP, #8
    // 0x64d7d4: tbnz            w0, #4, #0x64d900
    // 0x64d7d8: ldur            x2, [fp, #-0x40]
    // 0x64d7dc: ldur            x3, [fp, #-0x18]
    // 0x64d7e0: ldur            x1, [fp, #-0x48]
    // 0x64d7e4: r0 = LoadClassIdInstr(r1)
    //     0x64d7e4: ldur            x0, [x1, #-1]
    //     0x64d7e8: ubfx            x0, x0, #0xc, #0x14
    // 0x64d7ec: SaveReg r1
    //     0x64d7ec: str             x1, [SP, #-8]!
    // 0x64d7f0: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x64d7f0: add             lr, x0, #0x5ca
    //     0x64d7f4: ldr             lr, [x21, lr, lsl #3]
    //     0x64d7f8: blr             lr
    // 0x64d7fc: add             SP, SP, #8
    // 0x64d800: stur            x0, [fp, #-0x68]
    // 0x64d804: LoadField: r1 = r0->field_b
    //     0x64d804: ldur            w1, [x0, #0xb]
    // 0x64d808: DecompressPointer r1
    //     0x64d808: add             x1, x1, HEAP, lsl #32
    // 0x64d80c: LoadField: r2 = r1->field_7
    //     0x64d80c: ldur            x2, [x1, #7]
    // 0x64d810: ldur            x3, [fp, #-0x18]
    // 0x64d814: add             x4, x3, x2
    // 0x64d818: stur            x4, [fp, #-0x60]
    // 0x64d81c: LoadField: r2 = r1->field_f
    //     0x64d81c: ldur            x2, [x1, #0xf]
    // 0x64d820: add             x1, x3, x2
    // 0x64d824: stur            x1, [fp, #-0x20]
    // 0x64d828: r0 = TextRange()
    //     0x64d828: bl              #0x51026c  ; AllocateTextRangeStub -> TextRange (size=0x18)
    // 0x64d82c: mov             x1, x0
    // 0x64d830: ldur            x0, [fp, #-0x60]
    // 0x64d834: StoreField: r1->field_7 = r0
    //     0x64d834: stur            x0, [x1, #7]
    // 0x64d838: ldur            x0, [fp, #-0x20]
    // 0x64d83c: StoreField: r1->field_f = r0
    //     0x64d83c: stur            x0, [x1, #0xf]
    // 0x64d840: ldur            x0, [fp, #-0x68]
    // 0x64d844: r2 = LoadClassIdInstr(r0)
    //     0x64d844: ldur            x2, [x0, #-1]
    //     0x64d848: ubfx            x2, x2, #0xc, #0x14
    // 0x64d84c: stp             x1, x0, [SP, #-0x10]!
    // 0x64d850: mov             x0, x2
    // 0x64d854: r0 = GDT[cid_x0 + -0xff3]()
    //     0x64d854: sub             lr, x0, #0xff3
    //     0x64d858: ldr             lr, [x21, lr, lsl #3]
    //     0x64d85c: blr             lr
    // 0x64d860: add             SP, SP, #0x10
    // 0x64d864: mov             x1, x0
    // 0x64d868: ldur            x0, [fp, #-0x40]
    // 0x64d86c: stur            x1, [fp, #-0x70]
    // 0x64d870: LoadField: r2 = r0->field_b
    //     0x64d870: ldur            w2, [x0, #0xb]
    // 0x64d874: DecompressPointer r2
    //     0x64d874: add             x2, x2, HEAP, lsl #32
    // 0x64d878: stur            x2, [fp, #-0x68]
    // 0x64d87c: LoadField: r3 = r0->field_f
    //     0x64d87c: ldur            w3, [x0, #0xf]
    // 0x64d880: DecompressPointer r3
    //     0x64d880: add             x3, x3, HEAP, lsl #32
    // 0x64d884: LoadField: r4 = r3->field_b
    //     0x64d884: ldur            w4, [x3, #0xb]
    // 0x64d888: DecompressPointer r4
    //     0x64d888: add             x4, x4, HEAP, lsl #32
    // 0x64d88c: cmp             w2, w4
    // 0x64d890: b.ne            #0x64d8a0
    // 0x64d894: SaveReg r0
    //     0x64d894: str             x0, [SP, #-8]!
    // 0x64d898: r0 = _growToNextCapacity()
    //     0x64d898: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x64d89c: add             SP, SP, #8
    // 0x64d8a0: ldur            x2, [fp, #-0x40]
    // 0x64d8a4: ldur            x0, [fp, #-0x68]
    // 0x64d8a8: r3 = LoadInt32Instr(r0)
    //     0x64d8a8: sbfx            x3, x0, #1, #0x1f
    // 0x64d8ac: add             x0, x3, #1
    // 0x64d8b0: lsl             x1, x0, #1
    // 0x64d8b4: StoreField: r2->field_b = r1
    //     0x64d8b4: stur            w1, [x2, #0xb]
    // 0x64d8b8: mov             x1, x3
    // 0x64d8bc: cmp             x1, x0
    // 0x64d8c0: b.hs            #0x64da20
    // 0x64d8c4: LoadField: r1 = r2->field_f
    //     0x64d8c4: ldur            w1, [x2, #0xf]
    // 0x64d8c8: DecompressPointer r1
    //     0x64d8c8: add             x1, x1, HEAP, lsl #32
    // 0x64d8cc: ldur            x0, [fp, #-0x70]
    // 0x64d8d0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x64d8d0: add             x25, x1, x3, lsl #2
    //     0x64d8d4: add             x25, x25, #0xf
    //     0x64d8d8: str             w0, [x25]
    //     0x64d8dc: tbz             w0, #0, #0x64d8f8
    //     0x64d8e0: ldurb           w16, [x1, #-1]
    //     0x64d8e4: ldurb           w17, [x0, #-1]
    //     0x64d8e8: and             x16, x17, x16, lsr #2
    //     0x64d8ec: tst             x16, HEAP, lsr #32
    //     0x64d8f0: b.eq            #0x64d8f8
    //     0x64d8f4: bl              #0xd67e5c
    // 0x64d8f8: ldur            x1, [fp, #-0x48]
    // 0x64d8fc: b               #0x64d7a8
    // 0x64d900: ldur            x2, [fp, #-0x40]
    // 0x64d904: ldur            x16, [fp, #-0x58]
    // 0x64d908: SaveReg r16
    //     0x64d908: str             x16, [SP, #-8]!
    // 0x64d90c: r0 = _interpolateSingle()
    //     0x64d90c: bl              #0x4bdd98  ; [dart:core] _StringBase::_interpolateSingle
    // 0x64d910: add             SP, SP, #8
    // 0x64d914: stur            x0, [fp, #-0x48]
    // 0x64d918: LoadField: r1 = r0->field_7
    //     0x64d918: ldur            w1, [x0, #7]
    // 0x64d91c: DecompressPointer r1
    //     0x64d91c: add             x1, x1, HEAP, lsl #32
    // 0x64d920: cbz             w1, #0x64d948
    // 0x64d924: ldur            x16, [fp, #-0x10]
    // 0x64d928: SaveReg r16
    //     0x64d928: str             x16, [SP, #-8]!
    // 0x64d92c: r0 = _consumeBuffer()
    //     0x64d92c: bl              #0x4d1cf0  ; [dart:core] StringBuffer::_consumeBuffer
    // 0x64d930: add             SP, SP, #8
    // 0x64d934: ldur            x16, [fp, #-0x10]
    // 0x64d938: ldur            lr, [fp, #-0x48]
    // 0x64d93c: stp             lr, x16, [SP, #-0x10]!
    // 0x64d940: r0 = _addPart()
    //     0x64d940: bl              #0x4d18b0  ; [dart:core] StringBuffer::_addPart
    // 0x64d944: add             SP, SP, #0x10
    // 0x64d948: ldur            x1, [fp, #-0x18]
    // 0x64d94c: ldur            x2, [fp, #-0x58]
    // 0x64d950: LoadField: r4 = r2->field_7
    //     0x64d950: ldur            w4, [x2, #7]
    // 0x64d954: DecompressPointer r4
    //     0x64d954: add             x4, x4, HEAP, lsl #32
    // 0x64d958: r2 = LoadInt32Instr(r4)
    //     0x64d958: sbfx            x2, x4, #1, #0x1f
    // 0x64d95c: add             x7, x1, x2
    // 0x64d960: ldur            x6, [fp, #-0x50]
    // 0x64d964: ldr             x1, [fp, #0x18]
    // 0x64d968: ldur            x2, [fp, #-0x40]
    // 0x64d96c: ldur            x3, [fp, #-0x38]
    // 0x64d970: ldur            x4, [fp, #-0x30]
    // 0x64d974: ldur            x5, [fp, #-0x28]
    // 0x64d978: b               #0x64d60c
    // 0x64d97c: mov             x0, x3
    // 0x64d980: ldr             x2, [fp, #0x10]
    // 0x64d984: ldur            x3, [fp, #-8]
    // 0x64d988: r1 = true
    //     0x64d988: add             x1, NULL, #0x20  ; true
    // 0x64d98c: StoreField: r2->field_47 = r0
    //     0x64d98c: stur            w0, [x2, #0x47]
    //     0x64d990: ldurb           w16, [x2, #-1]
    //     0x64d994: ldurb           w17, [x0, #-1]
    //     0x64d998: and             x16, x17, x16, lsr #2
    //     0x64d99c: tst             x16, HEAP, lsr #32
    //     0x64d9a0: b.eq            #0x64d9a8
    //     0x64d9a4: bl              #0xd6828c
    // 0x64d9a8: StoreField: r2->field_13 = r1
    //     0x64d9a8: stur            w1, [x2, #0x13]
    // 0x64d9ac: LoadField: r0 = r3->field_1b
    //     0x64d9ac: ldur            w0, [x3, #0x1b]
    // 0x64d9b0: DecompressPointer r0
    //     0x64d9b0: add             x0, x0, HEAP, lsl #32
    // 0x64d9b4: cmp             w0, NULL
    // 0x64d9b8: b.eq            #0x64da24
    // 0x64d9bc: StoreField: r2->field_73 = r0
    //     0x64d9bc: stur            w0, [x2, #0x73]
    //     0x64d9c0: ldurb           w16, [x2, #-1]
    //     0x64d9c4: ldurb           w17, [x0, #-1]
    //     0x64d9c8: and             x16, x17, x16, lsr #2
    //     0x64d9cc: tst             x16, HEAP, lsr #32
    //     0x64d9d0: b.eq            #0x64d9d8
    //     0x64d9d4: bl              #0xd6828c
    // 0x64d9d8: r0 = Null
    //     0x64d9d8: mov             x0, NULL
    // 0x64d9dc: LeaveFrame
    //     0x64d9dc: mov             SP, fp
    //     0x64d9e0: ldp             fp, lr, [SP], #0x10
    // 0x64d9e4: ret
    //     0x64d9e4: ret             
    // 0x64d9e8: ldur            x0, [fp, #-0x38]
    // 0x64d9ec: r0 = ConcurrentModificationError()
    //     0x64d9ec: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x64d9f0: ldur            x3, [fp, #-0x38]
    // 0x64d9f4: StoreField: r0->field_b = r3
    //     0x64d9f4: stur            w3, [x0, #0xb]
    // 0x64d9f8: r0 = Throw()
    //     0x64d9f8: bl              #0xd67e38  ; ThrowStub
    // 0x64d9fc: brk             #0
    // 0x64da00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64da00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64da04: b               #0x64d4e4
    // 0x64da08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x64da08: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x64da0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x64da0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x64da10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64da10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64da14: b               #0x64d620
    // 0x64da18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64da18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64da1c: b               #0x64d7b8
    // 0x64da20: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x64da20: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x64da24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x64da24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ text(/* No info */) {
    // ** addr: 0x64da28, size: 0x34
    // 0x64da28: EnterFrame
    //     0x64da28: stp             fp, lr, [SP, #-0x10]!
    //     0x64da2c: mov             fp, SP
    // 0x64da30: ldr             x1, [fp, #0x10]
    // 0x64da34: LoadField: r2 = r1->field_6f
    //     0x64da34: ldur            w2, [x1, #0x6f]
    // 0x64da38: DecompressPointer r2
    //     0x64da38: add             x2, x2, HEAP, lsl #32
    // 0x64da3c: LoadField: r0 = r2->field_f
    //     0x64da3c: ldur            w0, [x2, #0xf]
    // 0x64da40: DecompressPointer r0
    //     0x64da40: add             x0, x0, HEAP, lsl #32
    // 0x64da44: cmp             w0, NULL
    // 0x64da48: b.eq            #0x64da58
    // 0x64da4c: LeaveFrame
    //     0x64da4c: mov             SP, fp
    //     0x64da50: ldp             fp, lr, [SP], #0x10
    // 0x64da54: ret
    //     0x64da54: ret             
    // 0x64da58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x64da58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x6527e4, size: 0x68
    // 0x6527e4: EnterFrame
    //     0x6527e4: stp             fp, lr, [SP, #-0x10]!
    //     0x6527e8: mov             fp, SP
    // 0x6527ec: CheckStackOverflow
    //     0x6527ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6527f0: cmp             SP, x16
    //     0x6527f4: b.ls            #0x652844
    // 0x6527f8: ldr             x16, [fp, #0x10]
    // 0x6527fc: SaveReg r16
    //     0x6527fc: str             x16, [SP, #-8]!
    // 0x652800: r0 = _removeSelectionRegistrarSubscription()
    //     0x652800: bl              #0x65284c  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_removeSelectionRegistrarSubscription
    // 0x652804: add             SP, SP, #8
    // 0x652808: ldr             x0, [fp, #0x10]
    // 0x65280c: StoreField: r0->field_7b = rNULL
    //     0x65280c: stur            NULL, [x0, #0x7b]
    // 0x652810: LoadField: r1 = r0->field_6f
    //     0x652810: ldur            w1, [x0, #0x6f]
    // 0x652814: DecompressPointer r1
    //     0x652814: add             x1, x1, HEAP, lsl #32
    // 0x652818: SaveReg r1
    //     0x652818: str             x1, [SP, #-8]!
    // 0x65281c: r0 = dispose()
    //     0x65281c: bl              #0x652680  ; [package:flutter/src/painting/text_painter.dart] TextPainter::dispose
    // 0x652820: add             SP, SP, #8
    // 0x652824: ldr             x16, [fp, #0x10]
    // 0x652828: SaveReg r16
    //     0x652828: str             x16, [SP, #-8]!
    // 0x65282c: r0 = dispose()
    //     0x65282c: bl              #0x65378c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0x652830: add             SP, SP, #8
    // 0x652834: r0 = Null
    //     0x652834: mov             x0, NULL
    // 0x652838: LeaveFrame
    //     0x652838: mov             SP, fp
    //     0x65283c: ldp             fp, lr, [SP], #0x10
    // 0x652840: ret
    //     0x652840: ret             
    // 0x652844: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x652844: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x652848: b               #0x6527f8
  }
  _ _removeSelectionRegistrarSubscription(/* No info */) {
    // ** addr: 0x65284c, size: 0x160
    // 0x65284c: EnterFrame
    //     0x65284c: stp             fp, lr, [SP, #-0x10]!
    //     0x652850: mov             fp, SP
    // 0x652854: AllocStack(0x20)
    //     0x652854: sub             SP, SP, #0x20
    // 0x652858: CheckStackOverflow
    //     0x652858: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65285c: cmp             SP, x16
    //     0x652860: b.ls            #0x652994
    // 0x652864: ldr             x0, [fp, #0x10]
    // 0x652868: LoadField: r1 = r0->field_7f
    //     0x652868: ldur            w1, [x0, #0x7f]
    // 0x65286c: DecompressPointer r1
    //     0x65286c: add             x1, x1, HEAP, lsl #32
    // 0x652870: cmp             w1, NULL
    // 0x652874: b.eq            #0x65288c
    // 0x652878: LoadField: r2 = r0->field_7b
    //     0x652878: ldur            w2, [x0, #0x7b]
    // 0x65287c: DecompressPointer r2
    //     0x65287c: add             x2, x2, HEAP, lsl #32
    // 0x652880: stur            x2, [fp, #-8]
    // 0x652884: cmp             w2, NULL
    // 0x652888: b.ne            #0x65289c
    // 0x65288c: r0 = Null
    //     0x65288c: mov             x0, NULL
    // 0x652890: LeaveFrame
    //     0x652890: mov             SP, fp
    //     0x652894: ldp             fp, lr, [SP], #0x10
    // 0x652898: ret
    //     0x652898: ret             
    // 0x65289c: r0 = LoadClassIdInstr(r1)
    //     0x65289c: ldur            x0, [x1, #-1]
    //     0x6528a0: ubfx            x0, x0, #0xc, #0x14
    // 0x6528a4: SaveReg r1
    //     0x6528a4: str             x1, [SP, #-8]!
    // 0x6528a8: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x6528a8: sub             lr, x0, #0xfd9
    //     0x6528ac: ldr             lr, [x21, lr, lsl #3]
    //     0x6528b0: blr             lr
    // 0x6528b4: add             SP, SP, #8
    // 0x6528b8: mov             x3, x0
    // 0x6528bc: ldur            x2, [fp, #-8]
    // 0x6528c0: stur            x3, [fp, #-0x20]
    // 0x6528c4: LoadField: r4 = r2->field_b
    //     0x6528c4: ldur            w4, [x2, #0xb]
    // 0x6528c8: DecompressPointer r4
    //     0x6528c8: add             x4, x4, HEAP, lsl #32
    // 0x6528cc: stur            x4, [fp, #-0x18]
    // 0x6528d0: r0 = LoadInt32Instr(r4)
    //     0x6528d0: sbfx            x0, x4, #1, #0x1f
    // 0x6528d4: r5 = 0
    //     0x6528d4: mov             x5, #0
    // 0x6528d8: stur            x5, [fp, #-0x10]
    // 0x6528dc: CheckStackOverflow
    //     0x6528dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6528e0: cmp             SP, x16
    //     0x6528e4: b.ls            #0x65299c
    // 0x6528e8: cmp             x5, x0
    // 0x6528ec: b.ge            #0x652968
    // 0x6528f0: mov             x1, x5
    // 0x6528f4: cmp             x1, x0
    // 0x6528f8: b.hs            #0x6529a4
    // 0x6528fc: LoadField: r0 = r2->field_f
    //     0x6528fc: ldur            w0, [x2, #0xf]
    // 0x652900: DecompressPointer r0
    //     0x652900: add             x0, x0, HEAP, lsl #32
    // 0x652904: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x652904: add             x16, x0, x5, lsl #2
    //     0x652908: ldur            w1, [x16, #0xf]
    // 0x65290c: DecompressPointer r1
    //     0x65290c: add             x1, x1, HEAP, lsl #32
    // 0x652910: cmp             w3, NULL
    // 0x652914: b.eq            #0x6529a8
    // 0x652918: stp             x1, x3, [SP, #-0x10]!
    // 0x65291c: mov             x0, x3
    // 0x652920: ClosureCall
    //     0x652920: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x652924: ldur            x2, [x0, #0x1f]
    //     0x652928: blr             x2
    // 0x65292c: add             SP, SP, #0x10
    // 0x652930: ldur            x0, [fp, #-8]
    // 0x652934: LoadField: r1 = r0->field_b
    //     0x652934: ldur            w1, [x0, #0xb]
    // 0x652938: DecompressPointer r1
    //     0x652938: add             x1, x1, HEAP, lsl #32
    // 0x65293c: ldur            x2, [fp, #-0x18]
    // 0x652940: cmp             w1, w2
    // 0x652944: b.ne            #0x652978
    // 0x652948: ldur            x3, [fp, #-0x10]
    // 0x65294c: add             x5, x3, #1
    // 0x652950: r3 = LoadInt32Instr(r1)
    //     0x652950: sbfx            x3, x1, #1, #0x1f
    // 0x652954: mov             x4, x2
    // 0x652958: mov             x2, x0
    // 0x65295c: mov             x0, x3
    // 0x652960: ldur            x3, [fp, #-0x20]
    // 0x652964: b               #0x6528d8
    // 0x652968: r0 = Null
    //     0x652968: mov             x0, NULL
    // 0x65296c: LeaveFrame
    //     0x65296c: mov             SP, fp
    //     0x652970: ldp             fp, lr, [SP], #0x10
    // 0x652974: ret
    //     0x652974: ret             
    // 0x652978: r0 = ConcurrentModificationError()
    //     0x652978: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x65297c: mov             x1, x0
    // 0x652980: ldur            x0, [fp, #-8]
    // 0x652984: StoreField: r1->field_b = r0
    //     0x652984: stur            w0, [x1, #0xb]
    // 0x652988: mov             x0, x1
    // 0x65298c: r0 = Throw()
    //     0x65298c: bl              #0xd67e38  ; ThrowStub
    // 0x652990: brk             #0
    // 0x652994: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x652994: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x652998: b               #0x652864
    // 0x65299c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65299c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6529a0: b               #0x6528e8
    // 0x6529a4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6529a4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6529a8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x6529a8: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, PaintingContext, Offset) {
    // ** addr: 0x65d7bc, size: 0x64
    // 0x65d7bc: EnterFrame
    //     0x65d7bc: stp             fp, lr, [SP, #-0x10]!
    //     0x65d7c0: mov             fp, SP
    // 0x65d7c4: ldr             x0, [fp, #0x20]
    // 0x65d7c8: LoadField: r1 = r0->field_17
    //     0x65d7c8: ldur            w1, [x0, #0x17]
    // 0x65d7cc: DecompressPointer r1
    //     0x65d7cc: add             x1, x1, HEAP, lsl #32
    // 0x65d7d0: CheckStackOverflow
    //     0x65d7d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65d7d4: cmp             SP, x16
    //     0x65d7d8: b.ls            #0x65d814
    // 0x65d7dc: LoadField: r0 = r1->field_f
    //     0x65d7dc: ldur            w0, [x1, #0xf]
    // 0x65d7e0: DecompressPointer r0
    //     0x65d7e0: add             x0, x0, HEAP, lsl #32
    // 0x65d7e4: cmp             w0, NULL
    // 0x65d7e8: b.eq            #0x65d81c
    // 0x65d7ec: ldr             x16, [fp, #0x18]
    // 0x65d7f0: stp             x0, x16, [SP, #-0x10]!
    // 0x65d7f4: ldr             x16, [fp, #0x10]
    // 0x65d7f8: SaveReg r16
    //     0x65d7f8: str             x16, [SP, #-8]!
    // 0x65d7fc: r0 = paintChild()
    //     0x65d7fc: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x65d800: add             SP, SP, #0x18
    // 0x65d804: r0 = Null
    //     0x65d804: mov             x0, NULL
    // 0x65d808: LeaveFrame
    //     0x65d808: mov             SP, fp
    //     0x65d80c: ldp             fp, lr, [SP], #0x10
    // 0x65d810: ret
    //     0x65d810: ret             
    // 0x65d814: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65d814: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65d818: b               #0x65d7dc
    // 0x65d81c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65d81c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0x65df34, size: 0x6dc
    // 0x65df34: EnterFrame
    //     0x65df34: stp             fp, lr, [SP, #-0x10]!
    //     0x65df38: mov             fp, SP
    // 0x65df3c: AllocStack(0x68)
    //     0x65df3c: sub             SP, SP, #0x68
    // 0x65df40: CheckStackOverflow
    //     0x65df40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65df44: cmp             SP, x16
    //     0x65df48: b.ls            #0x65e5bc
    // 0x65df4c: ldr             x3, [fp, #0x20]
    // 0x65df50: LoadField: r4 = r3->field_27
    //     0x65df50: ldur            w4, [x3, #0x27]
    // 0x65df54: DecompressPointer r4
    //     0x65df54: add             x4, x4, HEAP, lsl #32
    // 0x65df58: stur            x4, [fp, #-8]
    // 0x65df5c: cmp             w4, NULL
    // 0x65df60: b.eq            #0x65e584
    // 0x65df64: mov             x0, x4
    // 0x65df68: r2 = Null
    //     0x65df68: mov             x2, NULL
    // 0x65df6c: r1 = Null
    //     0x65df6c: mov             x1, NULL
    // 0x65df70: r4 = LoadClassIdInstr(r0)
    //     0x65df70: ldur            x4, [x0, #-1]
    //     0x65df74: ubfx            x4, x4, #0xc, #0x14
    // 0x65df78: sub             x4, x4, #0x80d
    // 0x65df7c: cmp             x4, #1
    // 0x65df80: b.ls            #0x65df98
    // 0x65df84: r8 = BoxConstraints
    //     0x65df84: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x65df88: ldr             x8, [x8, #0x1d0]
    // 0x65df8c: r3 = Null
    //     0x65df8c: add             x3, PP, #0x22, lsl #12  ; [pp+0x22370] Null
    //     0x65df90: ldr             x3, [x3, #0x370]
    // 0x65df94: r0 = BoxConstraints()
    //     0x65df94: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x65df98: ldr             x16, [fp, #0x20]
    // 0x65df9c: ldur            lr, [fp, #-8]
    // 0x65dfa0: stp             lr, x16, [SP, #-0x10]!
    // 0x65dfa4: r0 = _layoutTextWithConstraints()
    //     0x65dfa4: bl              #0x63df68  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_layoutTextWithConstraints
    // 0x65dfa8: add             SP, SP, #0x10
    // 0x65dfac: ldr             x0, [fp, #0x20]
    // 0x65dfb0: LoadField: r1 = r0->field_93
    //     0x65dfb0: ldur            w1, [x0, #0x93]
    // 0x65dfb4: DecompressPointer r1
    //     0x65dfb4: add             x1, x1, HEAP, lsl #32
    // 0x65dfb8: tbnz            w1, #4, #0x65e08c
    // 0x65dfbc: LoadField: r1 = r0->field_57
    //     0x65dfbc: ldur            w1, [x0, #0x57]
    // 0x65dfc0: DecompressPointer r1
    //     0x65dfc0: add             x1, x1, HEAP, lsl #32
    // 0x65dfc4: cmp             w1, NULL
    // 0x65dfc8: b.eq            #0x65e5c4
    // 0x65dfcc: ldr             x16, [fp, #0x10]
    // 0x65dfd0: stp             x1, x16, [SP, #-0x10]!
    // 0x65dfd4: r0 = &()
    //     0x65dfd4: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x65dfd8: add             SP, SP, #0x10
    // 0x65dfdc: mov             x1, x0
    // 0x65dfe0: ldr             x0, [fp, #0x20]
    // 0x65dfe4: stur            x1, [fp, #-8]
    // 0x65dfe8: LoadField: r2 = r0->field_97
    //     0x65dfe8: ldur            w2, [x0, #0x97]
    // 0x65dfec: DecompressPointer r2
    //     0x65dfec: add             x2, x2, HEAP, lsl #32
    // 0x65dff0: cmp             w2, NULL
    // 0x65dff4: b.eq            #0x65e04c
    // 0x65dff8: ldr             x16, [fp, #0x18]
    // 0x65dffc: SaveReg r16
    //     0x65dffc: str             x16, [SP, #-8]!
    // 0x65e000: r0 = canvas()
    //     0x65e000: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x65e004: add             SP, SP, #8
    // 0x65e008: stur            x0, [fp, #-0x10]
    // 0x65e00c: r16 = 112
    //     0x65e00c: mov             x16, #0x70
    // 0x65e010: stp             x16, NULL, [SP, #-0x10]!
    // 0x65e014: r0 = ByteData()
    //     0x65e014: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x65e018: add             SP, SP, #0x10
    // 0x65e01c: stur            x0, [fp, #-0x18]
    // 0x65e020: r0 = Paint()
    //     0x65e020: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x65e024: mov             x1, x0
    // 0x65e028: ldur            x0, [fp, #-0x18]
    // 0x65e02c: StoreField: r1->field_7 = r0
    //     0x65e02c: stur            w0, [x1, #7]
    // 0x65e030: ldur            x16, [fp, #-0x10]
    // 0x65e034: ldur            lr, [fp, #-8]
    // 0x65e038: stp             lr, x16, [SP, #-0x10]!
    // 0x65e03c: SaveReg r1
    //     0x65e03c: str             x1, [SP, #-8]!
    // 0x65e040: r0 = saveLayer()
    //     0x65e040: bl              #0x65b5f0  ; [dart:ui] Canvas::saveLayer
    // 0x65e044: add             SP, SP, #0x18
    // 0x65e048: b               #0x65e068
    // 0x65e04c: ldr             x16, [fp, #0x18]
    // 0x65e050: SaveReg r16
    //     0x65e050: str             x16, [SP, #-8]!
    // 0x65e054: r0 = canvas()
    //     0x65e054: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x65e058: add             SP, SP, #8
    // 0x65e05c: SaveReg r0
    //     0x65e05c: str             x0, [SP, #-8]!
    // 0x65e060: r0 = save()
    //     0x65e060: bl              #0x6595b0  ; [dart:ui] Canvas::save
    // 0x65e064: add             SP, SP, #8
    // 0x65e068: ldr             x16, [fp, #0x18]
    // 0x65e06c: SaveReg r16
    //     0x65e06c: str             x16, [SP, #-8]!
    // 0x65e070: r0 = canvas()
    //     0x65e070: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x65e074: add             SP, SP, #8
    // 0x65e078: ldur            x16, [fp, #-8]
    // 0x65e07c: stp             x16, x0, [SP, #-0x10]!
    // 0x65e080: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x65e080: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x65e084: r0 = clipRect()
    //     0x65e084: bl              #0x6590f4  ; [dart:ui] Canvas::clipRect
    // 0x65e088: add             SP, SP, #0x10
    // 0x65e08c: ldr             x0, [fp, #0x20]
    // 0x65e090: ldr             x1, [fp, #0x10]
    // 0x65e094: LoadField: r2 = r0->field_6f
    //     0x65e094: ldur            w2, [x0, #0x6f]
    // 0x65e098: DecompressPointer r2
    //     0x65e098: add             x2, x2, HEAP, lsl #32
    // 0x65e09c: stur            x2, [fp, #-8]
    // 0x65e0a0: ldr             x16, [fp, #0x18]
    // 0x65e0a4: SaveReg r16
    //     0x65e0a4: str             x16, [SP, #-8]!
    // 0x65e0a8: r0 = canvas()
    //     0x65e0a8: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x65e0ac: add             SP, SP, #8
    // 0x65e0b0: ldur            x16, [fp, #-8]
    // 0x65e0b4: stp             x0, x16, [SP, #-0x10]!
    // 0x65e0b8: ldr             x16, [fp, #0x10]
    // 0x65e0bc: SaveReg r16
    //     0x65e0bc: str             x16, [SP, #-8]!
    // 0x65e0c0: r0 = paint()
    //     0x65e0c0: bl              #0x65d820  ; [package:flutter/src/painting/text_painter.dart] TextPainter::paint
    // 0x65e0c4: add             SP, SP, #0x18
    // 0x65e0c8: ldr             x0, [fp, #0x20]
    // 0x65e0cc: LoadField: r1 = r0->field_67
    //     0x65e0cc: ldur            w1, [x0, #0x67]
    // 0x65e0d0: DecompressPointer r1
    //     0x65e0d0: add             x1, x1, HEAP, lsl #32
    // 0x65e0d4: stur            x1, [fp, #-0x10]
    // 0x65e0d8: r1 = 1
    //     0x65e0d8: mov             x1, #1
    // 0x65e0dc: r0 = AllocateContext()
    //     0x65e0dc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x65e0e0: mov             x3, x0
    // 0x65e0e4: ldur            x0, [fp, #-0x10]
    // 0x65e0e8: stur            x3, [fp, #-0x18]
    // 0x65e0ec: StoreField: r3->field_f = r0
    //     0x65e0ec: stur            w0, [x3, #0xf]
    // 0x65e0f0: ldr             x1, [fp, #0x10]
    // 0x65e0f4: LoadField: d0 = r1->field_7
    //     0x65e0f4: ldur            d0, [x1, #7]
    // 0x65e0f8: stur            d0, [fp, #-0x58]
    // 0x65e0fc: LoadField: d1 = r1->field_f
    //     0x65e0fc: ldur            d1, [x1, #0xf]
    // 0x65e100: stur            d1, [fp, #-0x50]
    // 0x65e104: r6 = 0
    //     0x65e104: mov             x6, #0
    // 0x65e108: ldr             x4, [fp, #0x20]
    // 0x65e10c: ldur            x5, [fp, #-8]
    // 0x65e110: stur            x6, [fp, #-0x20]
    // 0x65e114: CheckStackOverflow
    //     0x65e114: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65e118: cmp             SP, x16
    //     0x65e11c: b.ls            #0x65e5c8
    // 0x65e120: cmp             w0, NULL
    // 0x65e124: b.eq            #0x65e310
    // 0x65e128: LoadField: r1 = r5->field_3f
    //     0x65e128: ldur            w1, [x5, #0x3f]
    // 0x65e12c: DecompressPointer r1
    //     0x65e12c: add             x1, x1, HEAP, lsl #32
    // 0x65e130: cmp             w1, NULL
    // 0x65e134: b.eq            #0x65e5d0
    // 0x65e138: LoadField: r2 = r1->field_b
    //     0x65e138: ldur            w2, [x1, #0xb]
    // 0x65e13c: DecompressPointer r2
    //     0x65e13c: add             x2, x2, HEAP, lsl #32
    // 0x65e140: r1 = LoadInt32Instr(r2)
    //     0x65e140: sbfx            x1, x2, #1, #0x1f
    // 0x65e144: cmp             x6, x1
    // 0x65e148: b.ge            #0x65e310
    // 0x65e14c: LoadField: r7 = r0->field_17
    //     0x65e14c: ldur            w7, [x0, #0x17]
    // 0x65e150: DecompressPointer r7
    //     0x65e150: add             x7, x7, HEAP, lsl #32
    // 0x65e154: stur            x7, [fp, #-0x10]
    // 0x65e158: cmp             w7, NULL
    // 0x65e15c: b.eq            #0x65e5d4
    // 0x65e160: mov             x0, x7
    // 0x65e164: r2 = Null
    //     0x65e164: mov             x2, NULL
    // 0x65e168: r1 = Null
    //     0x65e168: mov             x1, NULL
    // 0x65e16c: r4 = LoadClassIdInstr(r0)
    //     0x65e16c: ldur            x4, [x0, #-1]
    //     0x65e170: ubfx            x4, x4, #0xc, #0x14
    // 0x65e174: cmp             x4, #0x808
    // 0x65e178: b.eq            #0x65e190
    // 0x65e17c: r8 = TextParentData<RenderBox>
    //     0x65e17c: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x65e180: ldr             x8, [x8, #0x298]
    // 0x65e184: r3 = Null
    //     0x65e184: add             x3, PP, #0x22, lsl #12  ; [pp+0x22380] Null
    //     0x65e188: ldr             x3, [x3, #0x380]
    // 0x65e18c: r0 = DefaultTypeTest()
    //     0x65e18c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x65e190: ldur            x0, [fp, #-0x10]
    // 0x65e194: LoadField: r1 = r0->field_17
    //     0x65e194: ldur            w1, [x0, #0x17]
    // 0x65e198: DecompressPointer r1
    //     0x65e198: add             x1, x1, HEAP, lsl #32
    // 0x65e19c: stur            x1, [fp, #-0x30]
    // 0x65e1a0: cmp             w1, NULL
    // 0x65e1a4: b.eq            #0x65e5d8
    // 0x65e1a8: ldr             x2, [fp, #0x20]
    // 0x65e1ac: LoadField: r3 = r2->field_37
    //     0x65e1ac: ldur            w3, [x2, #0x37]
    // 0x65e1b0: DecompressPointer r3
    //     0x65e1b0: add             x3, x3, HEAP, lsl #32
    // 0x65e1b4: r16 = Sentinel
    //     0x65e1b4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x65e1b8: cmp             w3, w16
    // 0x65e1bc: b.eq            #0x65e5dc
    // 0x65e1c0: stur            x3, [fp, #-0x28]
    // 0x65e1c4: LoadField: r4 = r0->field_7
    //     0x65e1c4: ldur            w4, [x0, #7]
    // 0x65e1c8: DecompressPointer r4
    //     0x65e1c8: add             x4, x4, HEAP, lsl #32
    // 0x65e1cc: LoadField: d0 = r4->field_7
    //     0x65e1cc: ldur            d0, [x4, #7]
    // 0x65e1d0: ldur            d1, [fp, #-0x58]
    // 0x65e1d4: fadd            d2, d1, d0
    // 0x65e1d8: stur            d2, [fp, #-0x68]
    // 0x65e1dc: LoadField: d0 = r4->field_f
    //     0x65e1dc: ldur            d0, [x4, #0xf]
    // 0x65e1e0: ldur            d3, [fp, #-0x50]
    // 0x65e1e4: fadd            d4, d3, d0
    // 0x65e1e8: stur            d4, [fp, #-0x60]
    // 0x65e1ec: r0 = Offset()
    //     0x65e1ec: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x65e1f0: ldur            d0, [fp, #-0x68]
    // 0x65e1f4: stur            x0, [fp, #-0x10]
    // 0x65e1f8: StoreField: r0->field_7 = d0
    //     0x65e1f8: stur            d0, [x0, #7]
    // 0x65e1fc: ldur            d0, [fp, #-0x60]
    // 0x65e200: StoreField: r0->field_f = d0
    //     0x65e200: stur            d0, [x0, #0xf]
    // 0x65e204: r0 = Matrix4()
    //     0x65e204: bl              #0x50ace8  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x65e208: r4 = 32
    //     0x65e208: mov             x4, #0x20
    // 0x65e20c: stur            x0, [fp, #-0x38]
    // 0x65e210: r0 = AllocateFloat64Array()
    //     0x65e210: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0x65e214: mov             x1, x0
    // 0x65e218: ldur            x0, [fp, #-0x38]
    // 0x65e21c: StoreField: r0->field_7 = r1
    //     0x65e21c: stur            w1, [x0, #7]
    // 0x65e220: d0 = 1.000000
    //     0x65e220: fmov            d0, #1.00000000
    // 0x65e224: StoreField: r1->field_8f = d0
    //     0x65e224: stur            d0, [x1, #0x8f]
    // 0x65e228: ldur            x2, [fp, #-0x30]
    // 0x65e22c: LoadField: d1 = r2->field_7
    //     0x65e22c: ldur            d1, [x2, #7]
    // 0x65e230: StoreField: r1->field_67 = d1
    //     0x65e230: stur            d1, [x1, #0x67]
    // 0x65e234: StoreField: r1->field_3f = d1
    //     0x65e234: stur            d1, [x1, #0x3f]
    // 0x65e238: StoreField: r1->field_17 = d1
    //     0x65e238: stur            d1, [x1, #0x17]
    // 0x65e23c: ldur            x2, [fp, #-0x18]
    // 0x65e240: r1 = Function '<anonymous closure>':.
    //     0x65e240: add             x1, PP, #0x22, lsl #12  ; [pp+0x22390] AnonymousClosure: (0x65d7bc), in [package:flutter/src/rendering/paragraph.dart] RenderParagraph::paint (0x65df34)
    //     0x65e244: ldr             x1, [x1, #0x390]
    // 0x65e248: r0 = AllocateClosure()
    //     0x65e248: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x65e24c: ldr             x16, [fp, #0x18]
    // 0x65e250: ldur            lr, [fp, #-0x28]
    // 0x65e254: stp             lr, x16, [SP, #-0x10]!
    // 0x65e258: ldur            x16, [fp, #-0x10]
    // 0x65e25c: ldur            lr, [fp, #-0x38]
    // 0x65e260: stp             lr, x16, [SP, #-0x10]!
    // 0x65e264: SaveReg r0
    //     0x65e264: str             x0, [SP, #-8]!
    // 0x65e268: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0x65e268: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0x65e26c: r0 = pushTransform()
    //     0x65e26c: bl              #0x65d108  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushTransform
    // 0x65e270: add             SP, SP, #0x28
    // 0x65e274: ldur            x3, [fp, #-0x18]
    // 0x65e278: LoadField: r0 = r3->field_f
    //     0x65e278: ldur            w0, [x3, #0xf]
    // 0x65e27c: DecompressPointer r0
    //     0x65e27c: add             x0, x0, HEAP, lsl #32
    // 0x65e280: LoadField: r4 = r0->field_17
    //     0x65e280: ldur            w4, [x0, #0x17]
    // 0x65e284: DecompressPointer r4
    //     0x65e284: add             x4, x4, HEAP, lsl #32
    // 0x65e288: stur            x4, [fp, #-0x10]
    // 0x65e28c: cmp             w4, NULL
    // 0x65e290: b.eq            #0x65e5e4
    // 0x65e294: mov             x0, x4
    // 0x65e298: r2 = Null
    //     0x65e298: mov             x2, NULL
    // 0x65e29c: r1 = Null
    //     0x65e29c: mov             x1, NULL
    // 0x65e2a0: r4 = LoadClassIdInstr(r0)
    //     0x65e2a0: ldur            x4, [x0, #-1]
    //     0x65e2a4: ubfx            x4, x4, #0xc, #0x14
    // 0x65e2a8: cmp             x4, #0x808
    // 0x65e2ac: b.eq            #0x65e2c4
    // 0x65e2b0: r8 = TextParentData<RenderBox>
    //     0x65e2b0: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x65e2b4: ldr             x8, [x8, #0x298]
    // 0x65e2b8: r3 = Null
    //     0x65e2b8: add             x3, PP, #0x22, lsl #12  ; [pp+0x22398] Null
    //     0x65e2bc: ldr             x3, [x3, #0x398]
    // 0x65e2c0: r0 = DefaultTypeTest()
    //     0x65e2c0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x65e2c4: ldur            x0, [fp, #-0x10]
    // 0x65e2c8: LoadField: r1 = r0->field_13
    //     0x65e2c8: ldur            w1, [x0, #0x13]
    // 0x65e2cc: DecompressPointer r1
    //     0x65e2cc: add             x1, x1, HEAP, lsl #32
    // 0x65e2d0: mov             x0, x1
    // 0x65e2d4: ldur            x2, [fp, #-0x18]
    // 0x65e2d8: StoreField: r2->field_f = r0
    //     0x65e2d8: stur            w0, [x2, #0xf]
    //     0x65e2dc: ldurb           w16, [x2, #-1]
    //     0x65e2e0: ldurb           w17, [x0, #-1]
    //     0x65e2e4: and             x16, x17, x16, lsr #2
    //     0x65e2e8: tst             x16, HEAP, lsr #32
    //     0x65e2ec: b.eq            #0x65e2f4
    //     0x65e2f0: bl              #0xd6828c
    // 0x65e2f4: ldur            x0, [fp, #-0x20]
    // 0x65e2f8: add             x6, x0, #1
    // 0x65e2fc: mov             x0, x1
    // 0x65e300: mov             x3, x2
    // 0x65e304: ldur            d0, [fp, #-0x58]
    // 0x65e308: ldur            d1, [fp, #-0x50]
    // 0x65e30c: b               #0x65e108
    // 0x65e310: ldr             x0, [fp, #0x20]
    // 0x65e314: LoadField: r1 = r0->field_93
    //     0x65e314: ldur            w1, [x0, #0x93]
    // 0x65e318: DecompressPointer r1
    //     0x65e318: add             x1, x1, HEAP, lsl #32
    // 0x65e31c: tbnz            w1, #4, #0x65e450
    // 0x65e320: LoadField: r1 = r0->field_97
    //     0x65e320: ldur            w1, [x0, #0x97]
    // 0x65e324: DecompressPointer r1
    //     0x65e324: add             x1, x1, HEAP, lsl #32
    // 0x65e328: cmp             w1, NULL
    // 0x65e32c: b.eq            #0x65e434
    // 0x65e330: ldur            d0, [fp, #-0x58]
    // 0x65e334: ldur            d1, [fp, #-0x50]
    // 0x65e338: ldr             x16, [fp, #0x18]
    // 0x65e33c: SaveReg r16
    //     0x65e33c: str             x16, [SP, #-8]!
    // 0x65e340: r0 = canvas()
    //     0x65e340: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x65e344: add             SP, SP, #8
    // 0x65e348: ldur            d0, [fp, #-0x58]
    // 0x65e34c: r1 = inline_Allocate_Double()
    //     0x65e34c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x65e350: add             x1, x1, #0x10
    //     0x65e354: cmp             x2, x1
    //     0x65e358: b.ls            #0x65e5e8
    //     0x65e35c: str             x1, [THR, #0x60]  ; THR::top
    //     0x65e360: sub             x1, x1, #0xf
    //     0x65e364: mov             x2, #0xd108
    //     0x65e368: movk            x2, #3, lsl #16
    //     0x65e36c: stur            x2, [x1, #-1]
    // 0x65e370: StoreField: r1->field_7 = d0
    //     0x65e370: stur            d0, [x1, #7]
    // 0x65e374: stp             x1, x0, [SP, #-0x10]!
    // 0x65e378: ldur            d0, [fp, #-0x50]
    // 0x65e37c: SaveReg d0
    //     0x65e37c: str             d0, [SP, #-8]!
    // 0x65e380: r0 = translate()
    //     0x65e380: bl              #0x6566d0  ; [dart:ui] Canvas::translate
    // 0x65e384: add             SP, SP, #0x18
    // 0x65e388: r16 = 112
    //     0x65e388: mov             x16, #0x70
    // 0x65e38c: stp             x16, NULL, [SP, #-0x10]!
    // 0x65e390: r0 = ByteData()
    //     0x65e390: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x65e394: add             SP, SP, #0x10
    // 0x65e398: stur            x0, [fp, #-8]
    // 0x65e39c: r0 = Paint()
    //     0x65e39c: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x65e3a0: mov             x1, x0
    // 0x65e3a4: ldur            x0, [fp, #-8]
    // 0x65e3a8: stur            x1, [fp, #-0x10]
    // 0x65e3ac: StoreField: r1->field_7 = r0
    //     0x65e3ac: stur            w0, [x1, #7]
    // 0x65e3b0: r16 = Instance_BlendMode
    //     0x65e3b0: add             x16, PP, #0x22, lsl #12  ; [pp+0x223a8] Obj!BlendMode@b67851
    //     0x65e3b4: ldr             x16, [x16, #0x3a8]
    // 0x65e3b8: stp             x16, x1, [SP, #-0x10]!
    // 0x65e3bc: r0 = blendMode=()
    //     0x65e3bc: bl              #0x65ec3c  ; [dart:ui] Paint::blendMode=
    // 0x65e3c0: add             SP, SP, #0x10
    // 0x65e3c4: ldr             x0, [fp, #0x20]
    // 0x65e3c8: LoadField: r1 = r0->field_97
    //     0x65e3c8: ldur            w1, [x0, #0x97]
    // 0x65e3cc: DecompressPointer r1
    //     0x65e3cc: add             x1, x1, HEAP, lsl #32
    // 0x65e3d0: ldur            x16, [fp, #-0x10]
    // 0x65e3d4: stp             x1, x16, [SP, #-0x10]!
    // 0x65e3d8: r0 = shader=()
    //     0x65e3d8: bl              #0x65eb6c  ; [dart:ui] Paint::shader=
    // 0x65e3dc: add             SP, SP, #0x10
    // 0x65e3e0: ldr             x16, [fp, #0x18]
    // 0x65e3e4: SaveReg r16
    //     0x65e3e4: str             x16, [SP, #-8]!
    // 0x65e3e8: r0 = canvas()
    //     0x65e3e8: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x65e3ec: add             SP, SP, #8
    // 0x65e3f0: mov             x1, x0
    // 0x65e3f4: ldr             x0, [fp, #0x20]
    // 0x65e3f8: stur            x1, [fp, #-8]
    // 0x65e3fc: LoadField: r2 = r0->field_57
    //     0x65e3fc: ldur            w2, [x0, #0x57]
    // 0x65e400: DecompressPointer r2
    //     0x65e400: add             x2, x2, HEAP, lsl #32
    // 0x65e404: cmp             w2, NULL
    // 0x65e408: b.eq            #0x65e604
    // 0x65e40c: r16 = Instance_Offset
    //     0x65e40c: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x65e410: stp             x2, x16, [SP, #-0x10]!
    // 0x65e414: r0 = &()
    //     0x65e414: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x65e418: add             SP, SP, #0x10
    // 0x65e41c: ldur            x16, [fp, #-8]
    // 0x65e420: stp             x0, x16, [SP, #-0x10]!
    // 0x65e424: ldur            x16, [fp, #-0x10]
    // 0x65e428: SaveReg r16
    //     0x65e428: str             x16, [SP, #-8]!
    // 0x65e42c: r0 = drawRect()
    //     0x65e42c: bl              #0x65e610  ; [dart:ui] Canvas::drawRect
    // 0x65e430: add             SP, SP, #0x18
    // 0x65e434: ldr             x16, [fp, #0x18]
    // 0x65e438: SaveReg r16
    //     0x65e438: str             x16, [SP, #-8]!
    // 0x65e43c: r0 = canvas()
    //     0x65e43c: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x65e440: add             SP, SP, #8
    // 0x65e444: SaveReg r0
    //     0x65e444: str             x0, [SP, #-8]!
    // 0x65e448: r0 = restore()
    //     0x65e448: bl              #0x65586c  ; [dart:ui] Canvas::restore
    // 0x65e44c: add             SP, SP, #8
    // 0x65e450: ldr             x0, [fp, #0x20]
    // 0x65e454: LoadField: r1 = r0->field_7b
    //     0x65e454: ldur            w1, [x0, #0x7b]
    // 0x65e458: DecompressPointer r1
    //     0x65e458: add             x1, x1, HEAP, lsl #32
    // 0x65e45c: stur            x1, [fp, #-0x10]
    // 0x65e460: cmp             w1, NULL
    // 0x65e464: b.eq            #0x65e574
    // 0x65e468: LoadField: r2 = r1->field_7
    //     0x65e468: ldur            w2, [x1, #7]
    // 0x65e46c: DecompressPointer r2
    //     0x65e46c: add             x2, x2, HEAP, lsl #32
    // 0x65e470: stur            x2, [fp, #-8]
    // 0x65e474: LoadField: r0 = r1->field_b
    //     0x65e474: ldur            w0, [x1, #0xb]
    // 0x65e478: DecompressPointer r0
    //     0x65e478: add             x0, x0, HEAP, lsl #32
    // 0x65e47c: r3 = LoadInt32Instr(r0)
    //     0x65e47c: sbfx            x3, x0, #1, #0x1f
    // 0x65e480: stur            x3, [fp, #-0x40]
    // 0x65e484: r4 = 0
    //     0x65e484: mov             x4, #0
    // 0x65e488: stur            x4, [fp, #-0x20]
    // 0x65e48c: CheckStackOverflow
    //     0x65e48c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65e490: cmp             SP, x16
    //     0x65e494: b.ls            #0x65e608
    // 0x65e498: r0 = LoadClassIdInstr(r1)
    //     0x65e498: ldur            x0, [x1, #-1]
    //     0x65e49c: ubfx            x0, x0, #0xc, #0x14
    // 0x65e4a0: SaveReg r1
    //     0x65e4a0: str             x1, [SP, #-8]!
    // 0x65e4a4: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x65e4a4: mov             x17, #0xb8ea
    //     0x65e4a8: add             lr, x0, x17
    //     0x65e4ac: ldr             lr, [x21, lr, lsl #3]
    //     0x65e4b0: blr             lr
    // 0x65e4b4: add             SP, SP, #8
    // 0x65e4b8: r1 = LoadInt32Instr(r0)
    //     0x65e4b8: sbfx            x1, x0, #1, #0x1f
    //     0x65e4bc: tbz             w0, #0, #0x65e4c4
    //     0x65e4c0: ldur            x1, [x0, #7]
    // 0x65e4c4: ldur            x2, [fp, #-0x40]
    // 0x65e4c8: cmp             x2, x1
    // 0x65e4cc: b.ne            #0x65e5a4
    // 0x65e4d0: ldur            x3, [fp, #-0x10]
    // 0x65e4d4: ldur            x4, [fp, #-0x20]
    // 0x65e4d8: cmp             x4, x1
    // 0x65e4dc: b.ge            #0x65e574
    // 0x65e4e0: r0 = BoxInt64Instr(r4)
    //     0x65e4e0: sbfiz           x0, x4, #1, #0x1f
    //     0x65e4e4: cmp             x4, x0, asr #1
    //     0x65e4e8: b.eq            #0x65e4f4
    //     0x65e4ec: bl              #0xd69bb8
    //     0x65e4f0: stur            x4, [x0, #7]
    // 0x65e4f4: r1 = LoadClassIdInstr(r3)
    //     0x65e4f4: ldur            x1, [x3, #-1]
    //     0x65e4f8: ubfx            x1, x1, #0xc, #0x14
    // 0x65e4fc: stp             x0, x3, [SP, #-0x10]!
    // 0x65e500: mov             x0, x1
    // 0x65e504: r0 = GDT[cid_x0 + 0xd175]()
    //     0x65e504: mov             x17, #0xd175
    //     0x65e508: add             lr, x0, x17
    //     0x65e50c: ldr             lr, [x21, lr, lsl #3]
    //     0x65e510: blr             lr
    // 0x65e514: add             SP, SP, #0x10
    // 0x65e518: mov             x1, x0
    // 0x65e51c: ldur            x0, [fp, #-0x20]
    // 0x65e520: add             x4, x0, #1
    // 0x65e524: stur            x4, [fp, #-0x48]
    // 0x65e528: cmp             w1, NULL
    // 0x65e52c: b.ne            #0x65e560
    // 0x65e530: mov             x0, x1
    // 0x65e534: ldur            x2, [fp, #-8]
    // 0x65e538: r1 = Null
    //     0x65e538: mov             x1, NULL
    // 0x65e53c: cmp             w2, NULL
    // 0x65e540: b.eq            #0x65e560
    // 0x65e544: LoadField: r4 = r2->field_17
    //     0x65e544: ldur            w4, [x2, #0x17]
    // 0x65e548: DecompressPointer r4
    //     0x65e548: add             x4, x4, HEAP, lsl #32
    // 0x65e54c: r8 = X0
    //     0x65e54c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x65e550: LoadField: r9 = r4->field_7
    //     0x65e550: ldur            x9, [x4, #7]
    // 0x65e554: r3 = Null
    //     0x65e554: add             x3, PP, #0x22, lsl #12  ; [pp+0x223b0] Null
    //     0x65e558: ldr             x3, [x3, #0x3b0]
    // 0x65e55c: blr             x9
    // 0x65e560: ldur            x4, [fp, #-0x48]
    // 0x65e564: ldur            x1, [fp, #-0x10]
    // 0x65e568: ldur            x2, [fp, #-8]
    // 0x65e56c: ldur            x3, [fp, #-0x40]
    // 0x65e570: b               #0x65e488
    // 0x65e574: r0 = Null
    //     0x65e574: mov             x0, NULL
    // 0x65e578: LeaveFrame
    //     0x65e578: mov             SP, fp
    //     0x65e57c: ldp             fp, lr, [SP], #0x10
    // 0x65e580: ret
    //     0x65e580: ret             
    // 0x65e584: r0 = StateError()
    //     0x65e584: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x65e588: mov             x1, x0
    // 0x65e58c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x65e58c: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x65e590: ldr             x0, [x0, #0x1e8]
    // 0x65e594: StoreField: r1->field_b = r0
    //     0x65e594: stur            w0, [x1, #0xb]
    // 0x65e598: mov             x0, x1
    // 0x65e59c: r0 = Throw()
    //     0x65e59c: bl              #0xd67e38  ; ThrowStub
    // 0x65e5a0: brk             #0
    // 0x65e5a4: ldur            x0, [fp, #-0x10]
    // 0x65e5a8: r0 = ConcurrentModificationError()
    //     0x65e5a8: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x65e5ac: ldur            x3, [fp, #-0x10]
    // 0x65e5b0: StoreField: r0->field_b = r3
    //     0x65e5b0: stur            w3, [x0, #0xb]
    // 0x65e5b4: r0 = Throw()
    //     0x65e5b4: bl              #0xd67e38  ; ThrowStub
    // 0x65e5b8: brk             #0
    // 0x65e5bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65e5bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65e5c0: b               #0x65df4c
    // 0x65e5c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65e5c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x65e5c8: r0 = StackOverflowSharedWithFPURegs()
    //     0x65e5c8: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x65e5cc: b               #0x65e120
    // 0x65e5d0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x65e5d0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x65e5d4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x65e5d4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x65e5d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65e5d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x65e5dc: r9 = _needsCompositing
    //     0x65e5dc: ldr             x9, [PP, #0x4b28]  ; [pp+0x4b28] Field <RenderObject._needsCompositing@904266271>: late (offset: 0x38)
    // 0x65e5e0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x65e5e0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x65e5e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65e5e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x65e5e8: SaveReg d0
    //     0x65e5e8: str             q0, [SP, #-0x10]!
    // 0x65e5ec: SaveReg r0
    //     0x65e5ec: str             x0, [SP, #-8]!
    // 0x65e5f0: r0 = AllocateDouble()
    //     0x65e5f0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65e5f4: mov             x1, x0
    // 0x65e5f8: RestoreReg r0
    //     0x65e5f8: ldr             x0, [SP], #8
    // 0x65e5fc: RestoreReg d0
    //     0x65e5fc: ldr             q0, [SP], #0x10
    // 0x65e600: b               #0x65e370
    // 0x65e604: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65e604: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x65e608: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65e608: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65e60c: b               #0x65e498
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x68c9ac, size: 0x720
    // 0x68c9ac: EnterFrame
    //     0x68c9ac: stp             fp, lr, [SP, #-0x10]!
    //     0x68c9b0: mov             fp, SP
    // 0x68c9b4: AllocStack(0x40)
    //     0x68c9b4: sub             SP, SP, #0x40
    // 0x68c9b8: CheckStackOverflow
    //     0x68c9b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68c9bc: cmp             SP, x16
    //     0x68c9c0: b.ls            #0x68d09c
    // 0x68c9c4: ldr             x3, [fp, #0x10]
    // 0x68c9c8: LoadField: r4 = r3->field_27
    //     0x68c9c8: ldur            w4, [x3, #0x27]
    // 0x68c9cc: DecompressPointer r4
    //     0x68c9cc: add             x4, x4, HEAP, lsl #32
    // 0x68c9d0: stur            x4, [fp, #-8]
    // 0x68c9d4: cmp             w4, NULL
    // 0x68c9d8: b.eq            #0x68d07c
    // 0x68c9dc: mov             x0, x4
    // 0x68c9e0: r2 = Null
    //     0x68c9e0: mov             x2, NULL
    // 0x68c9e4: r1 = Null
    //     0x68c9e4: mov             x1, NULL
    // 0x68c9e8: r4 = LoadClassIdInstr(r0)
    //     0x68c9e8: ldur            x4, [x0, #-1]
    //     0x68c9ec: ubfx            x4, x4, #0xc, #0x14
    // 0x68c9f0: sub             x4, x4, #0x80d
    // 0x68c9f4: cmp             x4, #1
    // 0x68c9f8: b.ls            #0x68ca10
    // 0x68c9fc: r8 = BoxConstraints
    //     0x68c9fc: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x68ca00: ldr             x8, [x8, #0x1d0]
    // 0x68ca04: r3 = Null
    //     0x68ca04: add             x3, PP, #0x22, lsl #12  ; [pp+0x223d0] Null
    //     0x68ca08: ldr             x3, [x3, #0x3d0]
    // 0x68ca0c: r0 = BoxConstraints()
    //     0x68ca0c: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x68ca10: ldr             x16, [fp, #0x10]
    // 0x68ca14: ldur            lr, [fp, #-8]
    // 0x68ca18: stp             lr, x16, [SP, #-0x10]!
    // 0x68ca1c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x68ca1c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x68ca20: r0 = _layoutChildren()
    //     0x68ca20: bl              #0x68e078  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_layoutChildren
    // 0x68ca24: add             SP, SP, #0x10
    // 0x68ca28: ldr             x1, [fp, #0x10]
    // 0x68ca2c: StoreField: r1->field_9f = r0
    //     0x68ca2c: stur            w0, [x1, #0x9f]
    //     0x68ca30: ldurb           w16, [x1, #-1]
    //     0x68ca34: ldurb           w17, [x0, #-1]
    //     0x68ca38: and             x16, x17, x16, lsr #2
    //     0x68ca3c: tst             x16, HEAP, lsr #32
    //     0x68ca40: b.eq            #0x68ca48
    //     0x68ca44: bl              #0xd6826c
    // 0x68ca48: ldur            x16, [fp, #-8]
    // 0x68ca4c: stp             x16, x1, [SP, #-0x10]!
    // 0x68ca50: r0 = _layoutTextWithConstraints()
    //     0x68ca50: bl              #0x63df68  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_layoutTextWithConstraints
    // 0x68ca54: add             SP, SP, #0x10
    // 0x68ca58: ldr             x16, [fp, #0x10]
    // 0x68ca5c: SaveReg r16
    //     0x68ca5c: str             x16, [SP, #-8]!
    // 0x68ca60: r0 = _setParentData()
    //     0x68ca60: bl              #0x68dea8  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_setParentData
    // 0x68ca64: add             SP, SP, #8
    // 0x68ca68: ldr             x0, [fp, #0x10]
    // 0x68ca6c: LoadField: r1 = r0->field_6f
    //     0x68ca6c: ldur            w1, [x0, #0x6f]
    // 0x68ca70: DecompressPointer r1
    //     0x68ca70: add             x1, x1, HEAP, lsl #32
    // 0x68ca74: stur            x1, [fp, #-0x10]
    // 0x68ca78: LoadField: r2 = r1->field_7
    //     0x68ca78: ldur            w2, [x1, #7]
    // 0x68ca7c: DecompressPointer r2
    //     0x68ca7c: add             x2, x2, HEAP, lsl #32
    // 0x68ca80: cmp             w2, NULL
    // 0x68ca84: b.eq            #0x68d0a4
    // 0x68ca88: SaveReg r2
    //     0x68ca88: str             x2, [SP, #-8]!
    // 0x68ca8c: r0 = width()
    //     0x68ca8c: bl              #0x520ee4  ; [dart:ui] Paragraph::width
    // 0x68ca90: add             SP, SP, #8
    // 0x68ca94: stp             fp, lr, [SP, #-0x10]!
    // 0x68ca98: mov             fp, SP
    // 0x68ca9c: CallRuntime_LibcCeil(double) -> double
    //     0x68ca9c: and             SP, SP, #0xfffffffffffffff0
    //     0x68caa0: mov             sp, SP
    //     0x68caa4: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x68caa8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x68caac: blr             x16
    //     0x68cab0: mov             x16, #8
    //     0x68cab4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x68cab8: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x68cabc: sub             sp, x16, #1, lsl #12
    //     0x68cac0: mov             SP, fp
    //     0x68cac4: ldp             fp, lr, [SP], #0x10
    // 0x68cac8: ldur            x0, [fp, #-0x10]
    // 0x68cacc: stur            d0, [fp, #-0x38]
    // 0x68cad0: LoadField: r1 = r0->field_7
    //     0x68cad0: ldur            w1, [x0, #7]
    // 0x68cad4: DecompressPointer r1
    //     0x68cad4: add             x1, x1, HEAP, lsl #32
    // 0x68cad8: cmp             w1, NULL
    // 0x68cadc: b.eq            #0x68d0a8
    // 0x68cae0: SaveReg r1
    //     0x68cae0: str             x1, [SP, #-8]!
    // 0x68cae4: r0 = height()
    //     0x68cae4: bl              #0x51a4dc  ; [dart:ui] Paragraph::height
    // 0x68cae8: add             SP, SP, #8
    // 0x68caec: stp             fp, lr, [SP, #-0x10]!
    // 0x68caf0: mov             fp, SP
    // 0x68caf4: CallRuntime_LibcCeil(double) -> double
    //     0x68caf4: and             SP, SP, #0xfffffffffffffff0
    //     0x68caf8: mov             sp, SP
    //     0x68cafc: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x68cb00: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x68cb04: blr             x16
    //     0x68cb08: mov             x16, #8
    //     0x68cb0c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x68cb10: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x68cb14: sub             sp, x16, #1, lsl #12
    //     0x68cb18: mov             SP, fp
    //     0x68cb1c: ldp             fp, lr, [SP], #0x10
    // 0x68cb20: stur            d0, [fp, #-0x40]
    // 0x68cb24: r0 = Size()
    //     0x68cb24: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x68cb28: ldur            d0, [fp, #-0x38]
    // 0x68cb2c: stur            x0, [fp, #-0x18]
    // 0x68cb30: StoreField: r0->field_7 = d0
    //     0x68cb30: stur            d0, [x0, #7]
    // 0x68cb34: ldur            d1, [fp, #-0x40]
    // 0x68cb38: StoreField: r0->field_f = d1
    //     0x68cb38: stur            d1, [x0, #0xf]
    // 0x68cb3c: ldur            x16, [fp, #-0x10]
    // 0x68cb40: SaveReg r16
    //     0x68cb40: str             x16, [SP, #-8]!
    // 0x68cb44: r0 = didExceedMaxLines()
    //     0x68cb44: bl              #0x68dbfc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::didExceedMaxLines
    // 0x68cb48: add             SP, SP, #8
    // 0x68cb4c: stur            x0, [fp, #-0x20]
    // 0x68cb50: ldur            x16, [fp, #-8]
    // 0x68cb54: ldur            lr, [fp, #-0x18]
    // 0x68cb58: stp             lr, x16, [SP, #-0x10]!
    // 0x68cb5c: r0 = constrain()
    //     0x68cb5c: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x68cb60: add             SP, SP, #0x10
    // 0x68cb64: mov             x2, x0
    // 0x68cb68: ldr             x1, [fp, #0x10]
    // 0x68cb6c: StoreField: r1->field_57 = r0
    //     0x68cb6c: stur            w0, [x1, #0x57]
    //     0x68cb70: ldurb           w16, [x1, #-1]
    //     0x68cb74: ldurb           w17, [x0, #-1]
    //     0x68cb78: and             x16, x17, x16, lsr #2
    //     0x68cb7c: tst             x16, HEAP, lsr #32
    //     0x68cb80: b.eq            #0x68cb88
    //     0x68cb84: bl              #0xd6826c
    // 0x68cb88: LoadField: d0 = r2->field_f
    //     0x68cb88: ldur            d0, [x2, #0xf]
    // 0x68cb8c: ldur            d1, [fp, #-0x40]
    // 0x68cb90: fcmp            d0, d1
    // 0x68cb94: b.vs            #0x68cba4
    // 0x68cb98: b.ge            #0x68cba4
    // 0x68cb9c: r0 = true
    //     0x68cb9c: add             x0, NULL, #0x20  ; true
    // 0x68cba0: b               #0x68cba8
    // 0x68cba4: ldur            x0, [fp, #-0x20]
    // 0x68cba8: ldur            d0, [fp, #-0x38]
    // 0x68cbac: LoadField: d1 = r2->field_7
    //     0x68cbac: ldur            d1, [x2, #7]
    // 0x68cbb0: fcmp            d1, d0
    // 0x68cbb4: b.vs            #0x68cbbc
    // 0x68cbb8: b.lt            #0x68cbc4
    // 0x68cbbc: r2 = false
    //     0x68cbbc: add             x2, NULL, #0x30  ; false
    // 0x68cbc0: b               #0x68cbc8
    // 0x68cbc4: r2 = true
    //     0x68cbc4: add             x2, NULL, #0x20  ; true
    // 0x68cbc8: stur            x2, [fp, #-0x18]
    // 0x68cbcc: tbz             w2, #4, #0x68cbd4
    // 0x68cbd0: tbnz            w0, #4, #0x68d060
    // 0x68cbd4: LoadField: r0 = r1->field_8b
    //     0x68cbd4: ldur            w0, [x1, #0x8b]
    // 0x68cbd8: DecompressPointer r0
    //     0x68cbd8: add             x0, x0, HEAP, lsl #32
    // 0x68cbdc: LoadField: r3 = r0->field_7
    //     0x68cbdc: ldur            x3, [x0, #7]
    // 0x68cbe0: cmp             x3, #1
    // 0x68cbe4: b.gt            #0x68d038
    // 0x68cbe8: cmp             x3, #0
    // 0x68cbec: b.gt            #0x68cbf8
    // 0x68cbf0: r0 = true
    //     0x68cbf0: add             x0, NULL, #0x20  ; true
    // 0x68cbf4: b               #0x68d044
    // 0x68cbf8: ldur            x0, [fp, #-0x10]
    // 0x68cbfc: r3 = true
    //     0x68cbfc: add             x3, NULL, #0x20  ; true
    // 0x68cc00: StoreField: r1->field_93 = r3
    //     0x68cc00: stur            w3, [x1, #0x93]
    // 0x68cc04: LoadField: r4 = r0->field_f
    //     0x68cc04: ldur            w4, [x0, #0xf]
    // 0x68cc08: DecompressPointer r4
    //     0x68cc08: add             x4, x4, HEAP, lsl #32
    // 0x68cc0c: cmp             w4, NULL
    // 0x68cc10: b.eq            #0x68d0ac
    // 0x68cc14: LoadField: r5 = r4->field_7
    //     0x68cc14: ldur            w5, [x4, #7]
    // 0x68cc18: DecompressPointer r5
    //     0x68cc18: add             x5, x5, HEAP, lsl #32
    // 0x68cc1c: stur            x5, [fp, #-8]
    // 0x68cc20: r0 = TextSpan()
    //     0x68cc20: bl              #0x673780  ; AllocateTextSpanStub -> TextSpan (size=0x30)
    // 0x68cc24: mov             x1, x0
    // 0x68cc28: r0 = "…"
    //     0x68cc28: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d430] "…"
    //     0x68cc2c: ldr             x0, [x0, #0x430]
    // 0x68cc30: stur            x1, [fp, #-0x20]
    // 0x68cc34: StoreField: r1->field_b = r0
    //     0x68cc34: stur            w0, [x1, #0xb]
    // 0x68cc38: r0 = Instance__DeferringMouseCursor
    //     0x68cc38: ldr             x0, [PP, #0x39d8]  ; [pp+0x39d8] Obj!_DeferringMouseCursor@b489e1
    // 0x68cc3c: StoreField: r1->field_17 = r0
    //     0x68cc3c: stur            w0, [x1, #0x17]
    // 0x68cc40: ldur            x0, [fp, #-8]
    // 0x68cc44: StoreField: r1->field_7 = r0
    //     0x68cc44: stur            w0, [x1, #7]
    // 0x68cc48: ldur            x0, [fp, #-0x10]
    // 0x68cc4c: LoadField: r2 = r0->field_1b
    //     0x68cc4c: ldur            w2, [x0, #0x1b]
    // 0x68cc50: DecompressPointer r2
    //     0x68cc50: add             x2, x2, HEAP, lsl #32
    // 0x68cc54: stur            x2, [fp, #-8]
    // 0x68cc58: cmp             w2, NULL
    // 0x68cc5c: b.eq            #0x68d0b0
    // 0x68cc60: ldr             x16, [fp, #0x10]
    // 0x68cc64: SaveReg r16
    //     0x68cc64: str             x16, [SP, #-8]!
    // 0x68cc68: r0 = textScaleFactor()
    //     0x68cc68: bl              #0x68dbe8  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::textScaleFactor
    // 0x68cc6c: add             SP, SP, #8
    // 0x68cc70: stur            d0, [fp, #-0x38]
    // 0x68cc74: ldr             x16, [fp, #0x10]
    // 0x68cc78: SaveReg r16
    //     0x68cc78: str             x16, [SP, #-8]!
    // 0x68cc7c: r0 = locale()
    //     0x68cc7c: bl              #0x68dbd0  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::locale
    // 0x68cc80: add             SP, SP, #8
    // 0x68cc84: stur            x0, [fp, #-0x28]
    // 0x68cc88: r0 = TextPainter()
    //     0x68cc88: bl              #0x68dbc4  ; AllocateTextPainterStub -> TextPainter (size=0x68)
    // 0x68cc8c: mov             x1, x0
    // 0x68cc90: r0 = true
    //     0x68cc90: add             x0, NULL, #0x20  ; true
    // 0x68cc94: stur            x1, [fp, #-0x30]
    // 0x68cc98: StoreField: r1->field_b = r0
    //     0x68cc98: stur            w0, [x1, #0xb]
    // 0x68cc9c: r0 = Sentinel
    //     0x68cc9c: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x68cca0: StoreField: r1->field_57 = r0
    //     0x68cca0: stur            w0, [x1, #0x57]
    // 0x68cca4: ldur            x0, [fp, #-0x20]
    // 0x68cca8: StoreField: r1->field_f = r0
    //     0x68cca8: stur            w0, [x1, #0xf]
    // 0x68ccac: r0 = Instance_TextAlign
    //     0x68ccac: add             x0, PP, #0x14, lsl #12  ; [pp+0x14fe8] Obj!TextAlign@b66f71
    //     0x68ccb0: ldr             x0, [x0, #0xfe8]
    // 0x68ccb4: StoreField: r1->field_17 = r0
    //     0x68ccb4: stur            w0, [x1, #0x17]
    // 0x68ccb8: ldur            x0, [fp, #-8]
    // 0x68ccbc: StoreField: r1->field_1b = r0
    //     0x68ccbc: stur            w0, [x1, #0x1b]
    // 0x68ccc0: ldur            d0, [fp, #-0x38]
    // 0x68ccc4: StoreField: r1->field_1f = d0
    //     0x68ccc4: stur            d0, [x1, #0x1f]
    // 0x68ccc8: ldur            x0, [fp, #-0x28]
    // 0x68cccc: StoreField: r1->field_2b = r0
    //     0x68cccc: stur            w0, [x1, #0x2b]
    // 0x68ccd0: r0 = Instance_TextWidthBasis
    //     0x68ccd0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15148] Obj!TextWidthBasis@b64d31
    //     0x68ccd4: ldr             x0, [x0, #0x148]
    // 0x68ccd8: StoreField: r1->field_37 = r0
    //     0x68ccd8: stur            w0, [x1, #0x37]
    // 0x68ccdc: SaveReg r1
    //     0x68ccdc: str             x1, [SP, #-8]!
    // 0x68cce0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x68cce0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x68cce4: r0 = layout()
    //     0x68cce4: bl              #0x52362c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::layout
    // 0x68cce8: add             SP, SP, #8
    // 0x68ccec: ldur            x0, [fp, #-0x18]
    // 0x68ccf0: tbnz            w0, #4, #0x68cecc
    // 0x68ccf4: ldur            x0, [fp, #-0x10]
    // 0x68ccf8: LoadField: r1 = r0->field_1b
    //     0x68ccf8: ldur            w1, [x0, #0x1b]
    // 0x68ccfc: DecompressPointer r1
    //     0x68ccfc: add             x1, x1, HEAP, lsl #32
    // 0x68cd00: cmp             w1, NULL
    // 0x68cd04: b.eq            #0x68d0b4
    // 0x68cd08: LoadField: r0 = r1->field_7
    //     0x68cd08: ldur            x0, [x1, #7]
    // 0x68cd0c: cmp             x0, #0
    // 0x68cd10: b.gt            #0x68cd70
    // 0x68cd14: ldur            x0, [fp, #-0x30]
    // 0x68cd18: LoadField: r1 = r0->field_7
    //     0x68cd18: ldur            w1, [x0, #7]
    // 0x68cd1c: DecompressPointer r1
    //     0x68cd1c: add             x1, x1, HEAP, lsl #32
    // 0x68cd20: cmp             w1, NULL
    // 0x68cd24: b.eq            #0x68d0b8
    // 0x68cd28: SaveReg r1
    //     0x68cd28: str             x1, [SP, #-8]!
    // 0x68cd2c: r0 = width()
    //     0x68cd2c: bl              #0x520ee4  ; [dart:ui] Paragraph::width
    // 0x68cd30: add             SP, SP, #8
    // 0x68cd34: stp             fp, lr, [SP, #-0x10]!
    // 0x68cd38: mov             fp, SP
    // 0x68cd3c: CallRuntime_LibcCeil(double) -> double
    //     0x68cd3c: and             SP, SP, #0xfffffffffffffff0
    //     0x68cd40: mov             sp, SP
    //     0x68cd44: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x68cd48: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x68cd4c: blr             x16
    //     0x68cd50: mov             x16, #8
    //     0x68cd54: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x68cd58: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x68cd5c: sub             sp, x16, #1, lsl #12
    //     0x68cd60: mov             SP, fp
    //     0x68cd64: ldp             fp, lr, [SP], #0x10
    // 0x68cd68: d1 = 0.000000
    //     0x68cd68: eor             v1.16b, v1.16b, v1.16b
    // 0x68cd6c: b               #0x68cdf4
    // 0x68cd70: ldr             x1, [fp, #0x10]
    // 0x68cd74: ldur            x0, [fp, #-0x30]
    // 0x68cd78: LoadField: r2 = r1->field_57
    //     0x68cd78: ldur            w2, [x1, #0x57]
    // 0x68cd7c: DecompressPointer r2
    //     0x68cd7c: add             x2, x2, HEAP, lsl #32
    // 0x68cd80: cmp             w2, NULL
    // 0x68cd84: b.eq            #0x68d0bc
    // 0x68cd88: LoadField: d0 = r2->field_7
    //     0x68cd88: ldur            d0, [x2, #7]
    // 0x68cd8c: stur            d0, [fp, #-0x38]
    // 0x68cd90: LoadField: r2 = r0->field_7
    //     0x68cd90: ldur            w2, [x0, #7]
    // 0x68cd94: DecompressPointer r2
    //     0x68cd94: add             x2, x2, HEAP, lsl #32
    // 0x68cd98: cmp             w2, NULL
    // 0x68cd9c: b.eq            #0x68d0c0
    // 0x68cda0: SaveReg r2
    //     0x68cda0: str             x2, [SP, #-8]!
    // 0x68cda4: r0 = width()
    //     0x68cda4: bl              #0x520ee4  ; [dart:ui] Paragraph::width
    // 0x68cda8: add             SP, SP, #8
    // 0x68cdac: stp             fp, lr, [SP, #-0x10]!
    // 0x68cdb0: mov             fp, SP
    // 0x68cdb4: CallRuntime_LibcCeil(double) -> double
    //     0x68cdb4: and             SP, SP, #0xfffffffffffffff0
    //     0x68cdb8: mov             sp, SP
    //     0x68cdbc: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x68cdc0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x68cdc4: blr             x16
    //     0x68cdc8: mov             x16, #8
    //     0x68cdcc: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x68cdd0: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x68cdd4: sub             sp, x16, #1, lsl #12
    //     0x68cdd8: mov             SP, fp
    //     0x68cddc: ldp             fp, lr, [SP], #0x10
    // 0x68cde0: mov             v1.16b, v0.16b
    // 0x68cde4: ldur            d0, [fp, #-0x38]
    // 0x68cde8: fsub            d2, d0, d1
    // 0x68cdec: mov             v1.16b, v0.16b
    // 0x68cdf0: mov             v0.16b, v2.16b
    // 0x68cdf4: ldr             x0, [fp, #0x10]
    // 0x68cdf8: stur            d1, [fp, #-0x38]
    // 0x68cdfc: stur            d0, [fp, #-0x40]
    // 0x68ce00: r0 = Offset()
    //     0x68ce00: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x68ce04: ldur            d0, [fp, #-0x40]
    // 0x68ce08: stur            x0, [fp, #-8]
    // 0x68ce0c: StoreField: r0->field_7 = d0
    //     0x68ce0c: stur            d0, [x0, #7]
    // 0x68ce10: d0 = 0.000000
    //     0x68ce10: eor             v0.16b, v0.16b, v0.16b
    // 0x68ce14: StoreField: r0->field_f = d0
    //     0x68ce14: stur            d0, [x0, #0xf]
    // 0x68ce18: r0 = Offset()
    //     0x68ce18: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x68ce1c: ldur            d0, [fp, #-0x38]
    // 0x68ce20: stur            x0, [fp, #-0x10]
    // 0x68ce24: StoreField: r0->field_7 = d0
    //     0x68ce24: stur            d0, [x0, #7]
    // 0x68ce28: d0 = 0.000000
    //     0x68ce28: eor             v0.16b, v0.16b, v0.16b
    // 0x68ce2c: StoreField: r0->field_f = d0
    //     0x68ce2c: stur            d0, [x0, #0xf]
    // 0x68ce30: r1 = Null
    //     0x68ce30: mov             x1, NULL
    // 0x68ce34: r2 = 4
    //     0x68ce34: mov             x2, #4
    // 0x68ce38: r0 = AllocateArray()
    //     0x68ce38: bl              #0xd6987c  ; AllocateArrayStub
    // 0x68ce3c: stur            x0, [fp, #-0x18]
    // 0x68ce40: r17 = Instance_Color
    //     0x68ce40: add             x17, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x68ce44: ldr             x17, [x17, #0xbe8]
    // 0x68ce48: StoreField: r0->field_f = r17
    //     0x68ce48: stur            w17, [x0, #0xf]
    // 0x68ce4c: r17 = Instance_Color
    //     0x68ce4c: add             x17, PP, #0x22, lsl #12  ; [pp+0x223e0] Obj!Color@b5d191
    //     0x68ce50: ldr             x17, [x17, #0x3e0]
    // 0x68ce54: StoreField: r0->field_13 = r17
    //     0x68ce54: stur            w17, [x0, #0x13]
    // 0x68ce58: r1 = <Color>
    //     0x68ce58: add             x1, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0x68ce5c: ldr             x1, [x1, #0x3f8]
    // 0x68ce60: r0 = AllocateGrowableArray()
    //     0x68ce60: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x68ce64: mov             x1, x0
    // 0x68ce68: ldur            x0, [fp, #-0x18]
    // 0x68ce6c: stur            x1, [fp, #-0x20]
    // 0x68ce70: StoreField: r1->field_f = r0
    //     0x68ce70: stur            w0, [x1, #0xf]
    // 0x68ce74: r2 = 4
    //     0x68ce74: mov             x2, #4
    // 0x68ce78: StoreField: r1->field_b = r2
    //     0x68ce78: stur            w2, [x1, #0xb]
    // 0x68ce7c: r0 = Gradient()
    //     0x68ce7c: bl              #0x68dbb8  ; AllocateGradientStub -> Gradient (size=0xc)
    // 0x68ce80: stur            x0, [fp, #-0x18]
    // 0x68ce84: ldur            x16, [fp, #-8]
    // 0x68ce88: stp             x16, x0, [SP, #-0x10]!
    // 0x68ce8c: ldur            x16, [fp, #-0x10]
    // 0x68ce90: ldur            lr, [fp, #-0x20]
    // 0x68ce94: stp             lr, x16, [SP, #-0x10]!
    // 0x68ce98: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x68ce98: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x68ce9c: r0 = Gradient.linear()
    //     0x68ce9c: bl              #0x68d0cc  ; [dart:ui] Gradient::Gradient.linear
    // 0x68cea0: add             SP, SP, #0x20
    // 0x68cea4: ldur            x0, [fp, #-0x18]
    // 0x68cea8: ldr             x1, [fp, #0x10]
    // 0x68ceac: StoreField: r1->field_97 = r0
    //     0x68ceac: stur            w0, [x1, #0x97]
    //     0x68ceb0: ldurb           w16, [x1, #-1]
    //     0x68ceb4: ldurb           w17, [x0, #-1]
    //     0x68ceb8: and             x16, x17, x16, lsr #2
    //     0x68cebc: tst             x16, HEAP, lsr #32
    //     0x68cec0: b.eq            #0x68cec8
    //     0x68cec4: bl              #0xd6826c
    // 0x68cec8: b               #0x68d024
    // 0x68cecc: ldr             x1, [fp, #0x10]
    // 0x68ced0: ldur            x0, [fp, #-0x30]
    // 0x68ced4: r2 = 4
    //     0x68ced4: mov             x2, #4
    // 0x68ced8: d0 = 0.000000
    //     0x68ced8: eor             v0.16b, v0.16b, v0.16b
    // 0x68cedc: LoadField: r3 = r1->field_57
    //     0x68cedc: ldur            w3, [x1, #0x57]
    // 0x68cee0: DecompressPointer r3
    //     0x68cee0: add             x3, x3, HEAP, lsl #32
    // 0x68cee4: cmp             w3, NULL
    // 0x68cee8: b.eq            #0x68d0c4
    // 0x68ceec: LoadField: d1 = r3->field_f
    //     0x68ceec: ldur            d1, [x3, #0xf]
    // 0x68cef0: stur            d1, [fp, #-0x38]
    // 0x68cef4: LoadField: r3 = r0->field_7
    //     0x68cef4: ldur            w3, [x0, #7]
    // 0x68cef8: DecompressPointer r3
    //     0x68cef8: add             x3, x3, HEAP, lsl #32
    // 0x68cefc: cmp             w3, NULL
    // 0x68cf00: b.eq            #0x68d0c8
    // 0x68cf04: SaveReg r3
    //     0x68cf04: str             x3, [SP, #-8]!
    // 0x68cf08: r0 = height()
    //     0x68cf08: bl              #0x51a4dc  ; [dart:ui] Paragraph::height
    // 0x68cf0c: add             SP, SP, #8
    // 0x68cf10: stp             fp, lr, [SP, #-0x10]!
    // 0x68cf14: mov             fp, SP
    // 0x68cf18: CallRuntime_LibcCeil(double) -> double
    //     0x68cf18: and             SP, SP, #0xfffffffffffffff0
    //     0x68cf1c: mov             sp, SP
    //     0x68cf20: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x68cf24: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x68cf28: blr             x16
    //     0x68cf2c: mov             x16, #8
    //     0x68cf30: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x68cf34: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x68cf38: sub             sp, x16, #1, lsl #12
    //     0x68cf3c: mov             SP, fp
    //     0x68cf40: ldp             fp, lr, [SP], #0x10
    // 0x68cf44: mov             v1.16b, v0.16b
    // 0x68cf48: d0 = 2.000000
    //     0x68cf48: fmov            d0, #2.00000000
    // 0x68cf4c: fdiv            d2, d1, d0
    // 0x68cf50: ldur            d0, [fp, #-0x38]
    // 0x68cf54: fsub            d1, d0, d2
    // 0x68cf58: stur            d1, [fp, #-0x40]
    // 0x68cf5c: r0 = Offset()
    //     0x68cf5c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x68cf60: d0 = 0.000000
    //     0x68cf60: eor             v0.16b, v0.16b, v0.16b
    // 0x68cf64: stur            x0, [fp, #-8]
    // 0x68cf68: StoreField: r0->field_7 = d0
    //     0x68cf68: stur            d0, [x0, #7]
    // 0x68cf6c: ldur            d1, [fp, #-0x40]
    // 0x68cf70: StoreField: r0->field_f = d1
    //     0x68cf70: stur            d1, [x0, #0xf]
    // 0x68cf74: r0 = Offset()
    //     0x68cf74: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x68cf78: d0 = 0.000000
    //     0x68cf78: eor             v0.16b, v0.16b, v0.16b
    // 0x68cf7c: stur            x0, [fp, #-0x10]
    // 0x68cf80: StoreField: r0->field_7 = d0
    //     0x68cf80: stur            d0, [x0, #7]
    // 0x68cf84: ldur            d0, [fp, #-0x38]
    // 0x68cf88: StoreField: r0->field_f = d0
    //     0x68cf88: stur            d0, [x0, #0xf]
    // 0x68cf8c: r1 = Null
    //     0x68cf8c: mov             x1, NULL
    // 0x68cf90: r2 = 4
    //     0x68cf90: mov             x2, #4
    // 0x68cf94: r0 = AllocateArray()
    //     0x68cf94: bl              #0xd6987c  ; AllocateArrayStub
    // 0x68cf98: stur            x0, [fp, #-0x18]
    // 0x68cf9c: r17 = Instance_Color
    //     0x68cf9c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x68cfa0: ldr             x17, [x17, #0xbe8]
    // 0x68cfa4: StoreField: r0->field_f = r17
    //     0x68cfa4: stur            w17, [x0, #0xf]
    // 0x68cfa8: r17 = Instance_Color
    //     0x68cfa8: add             x17, PP, #0x22, lsl #12  ; [pp+0x223e0] Obj!Color@b5d191
    //     0x68cfac: ldr             x17, [x17, #0x3e0]
    // 0x68cfb0: StoreField: r0->field_13 = r17
    //     0x68cfb0: stur            w17, [x0, #0x13]
    // 0x68cfb4: r1 = <Color>
    //     0x68cfb4: add             x1, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0x68cfb8: ldr             x1, [x1, #0x3f8]
    // 0x68cfbc: r0 = AllocateGrowableArray()
    //     0x68cfbc: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x68cfc0: mov             x1, x0
    // 0x68cfc4: ldur            x0, [fp, #-0x18]
    // 0x68cfc8: stur            x1, [fp, #-0x20]
    // 0x68cfcc: StoreField: r1->field_f = r0
    //     0x68cfcc: stur            w0, [x1, #0xf]
    // 0x68cfd0: r0 = 4
    //     0x68cfd0: mov             x0, #4
    // 0x68cfd4: StoreField: r1->field_b = r0
    //     0x68cfd4: stur            w0, [x1, #0xb]
    // 0x68cfd8: r0 = Gradient()
    //     0x68cfd8: bl              #0x68dbb8  ; AllocateGradientStub -> Gradient (size=0xc)
    // 0x68cfdc: stur            x0, [fp, #-0x18]
    // 0x68cfe0: ldur            x16, [fp, #-8]
    // 0x68cfe4: stp             x16, x0, [SP, #-0x10]!
    // 0x68cfe8: ldur            x16, [fp, #-0x10]
    // 0x68cfec: ldur            lr, [fp, #-0x20]
    // 0x68cff0: stp             lr, x16, [SP, #-0x10]!
    // 0x68cff4: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x68cff4: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x68cff8: r0 = Gradient.linear()
    //     0x68cff8: bl              #0x68d0cc  ; [dart:ui] Gradient::Gradient.linear
    // 0x68cffc: add             SP, SP, #0x20
    // 0x68d000: ldur            x0, [fp, #-0x18]
    // 0x68d004: ldr             x1, [fp, #0x10]
    // 0x68d008: StoreField: r1->field_97 = r0
    //     0x68d008: stur            w0, [x1, #0x97]
    //     0x68d00c: ldurb           w16, [x1, #-1]
    //     0x68d010: ldurb           w17, [x0, #-1]
    //     0x68d014: and             x16, x17, x16, lsr #2
    //     0x68d018: tst             x16, HEAP, lsr #32
    //     0x68d01c: b.eq            #0x68d024
    //     0x68d020: bl              #0xd6826c
    // 0x68d024: ldur            x16, [fp, #-0x30]
    // 0x68d028: SaveReg r16
    //     0x68d028: str             x16, [SP, #-8]!
    // 0x68d02c: r0 = dispose()
    //     0x68d02c: bl              #0x652680  ; [package:flutter/src/painting/text_painter.dart] TextPainter::dispose
    // 0x68d030: add             SP, SP, #8
    // 0x68d034: b               #0x68d06c
    // 0x68d038: r0 = true
    //     0x68d038: add             x0, NULL, #0x20  ; true
    // 0x68d03c: cmp             x3, #2
    // 0x68d040: b.gt            #0x68d050
    // 0x68d044: StoreField: r1->field_93 = r0
    //     0x68d044: stur            w0, [x1, #0x93]
    // 0x68d048: StoreField: r1->field_97 = rNULL
    //     0x68d048: stur            NULL, [x1, #0x97]
    // 0x68d04c: b               #0x68d06c
    // 0x68d050: r2 = false
    //     0x68d050: add             x2, NULL, #0x30  ; false
    // 0x68d054: StoreField: r1->field_93 = r2
    //     0x68d054: stur            w2, [x1, #0x93]
    // 0x68d058: StoreField: r1->field_97 = rNULL
    //     0x68d058: stur            NULL, [x1, #0x97]
    // 0x68d05c: b               #0x68d06c
    // 0x68d060: r2 = false
    //     0x68d060: add             x2, NULL, #0x30  ; false
    // 0x68d064: StoreField: r1->field_93 = r2
    //     0x68d064: stur            w2, [x1, #0x93]
    // 0x68d068: StoreField: r1->field_97 = rNULL
    //     0x68d068: stur            NULL, [x1, #0x97]
    // 0x68d06c: r0 = Null
    //     0x68d06c: mov             x0, NULL
    // 0x68d070: LeaveFrame
    //     0x68d070: mov             SP, fp
    //     0x68d074: ldp             fp, lr, [SP], #0x10
    // 0x68d078: ret
    //     0x68d078: ret             
    // 0x68d07c: r0 = StateError()
    //     0x68d07c: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68d080: mov             x1, x0
    // 0x68d084: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68d084: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68d088: ldr             x0, [x0, #0x1e8]
    // 0x68d08c: StoreField: r1->field_b = r0
    //     0x68d08c: stur            w0, [x1, #0xb]
    // 0x68d090: mov             x0, x1
    // 0x68d094: r0 = Throw()
    //     0x68d094: bl              #0xd67e38  ; ThrowStub
    // 0x68d098: brk             #0
    // 0x68d09c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68d09c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68d0a0: b               #0x68c9c4
    // 0x68d0a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68d0a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68d0a8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68d0a8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x68d0ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68d0ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68d0b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68d0b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68d0b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68d0b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68d0b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68d0b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68d0bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68d0bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68d0c0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68d0c0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x68d0c4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68d0c4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x68d0c8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68d0c8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  get _ locale(/* No info */) {
    // ** addr: 0x68dbd0, size: 0x18
    // 0x68dbd0: ldr             x1, [SP]
    // 0x68dbd4: LoadField: r2 = r1->field_6f
    //     0x68dbd4: ldur            w2, [x1, #0x6f]
    // 0x68dbd8: DecompressPointer r2
    //     0x68dbd8: add             x2, x2, HEAP, lsl #32
    // 0x68dbdc: LoadField: r0 = r2->field_2b
    //     0x68dbdc: ldur            w0, [x2, #0x2b]
    // 0x68dbe0: DecompressPointer r0
    //     0x68dbe0: add             x0, x0, HEAP, lsl #32
    // 0x68dbe4: ret
    //     0x68dbe4: ret             
  }
  get _ textScaleFactor(/* No info */) {
    // ** addr: 0x68dbe8, size: 0x14
    // 0x68dbe8: ldr             x0, [SP]
    // 0x68dbec: LoadField: r1 = r0->field_6f
    //     0x68dbec: ldur            w1, [x0, #0x6f]
    // 0x68dbf0: DecompressPointer r1
    //     0x68dbf0: add             x1, x1, HEAP, lsl #32
    // 0x68dbf4: LoadField: d0 = r1->field_1f
    //     0x68dbf4: ldur            d0, [x1, #0x1f]
    // 0x68dbf8: ret
    //     0x68dbf8: ret             
  }
  _ _setParentData(/* No info */) {
    // ** addr: 0x68dea8, size: 0x1d0
    // 0x68dea8: EnterFrame
    //     0x68dea8: stp             fp, lr, [SP, #-0x10]!
    //     0x68deac: mov             fp, SP
    // 0x68deb0: AllocStack(0x38)
    //     0x68deb0: sub             SP, SP, #0x38
    // 0x68deb4: ldr             x0, [fp, #0x10]
    // 0x68deb8: LoadField: r1 = r0->field_67
    //     0x68deb8: ldur            w1, [x0, #0x67]
    // 0x68debc: DecompressPointer r1
    //     0x68debc: add             x1, x1, HEAP, lsl #32
    // 0x68dec0: LoadField: r2 = r0->field_6f
    //     0x68dec0: ldur            w2, [x0, #0x6f]
    // 0x68dec4: DecompressPointer r2
    //     0x68dec4: add             x2, x2, HEAP, lsl #32
    // 0x68dec8: LoadField: r3 = r2->field_3f
    //     0x68dec8: ldur            w3, [x2, #0x3f]
    // 0x68decc: DecompressPointer r3
    //     0x68decc: add             x3, x3, HEAP, lsl #32
    // 0x68ded0: stur            x3, [fp, #-0x28]
    // 0x68ded4: LoadField: r4 = r2->field_43
    //     0x68ded4: ldur            w4, [x2, #0x43]
    // 0x68ded8: DecompressPointer r4
    //     0x68ded8: add             x4, x4, HEAP, lsl #32
    // 0x68dedc: stur            x4, [fp, #-0x20]
    // 0x68dee0: mov             x0, x1
    // 0x68dee4: r5 = 0
    //     0x68dee4: mov             x5, #0
    // 0x68dee8: stur            x5, [fp, #-0x18]
    // 0x68deec: CheckStackOverflow
    //     0x68deec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68def0: cmp             SP, x16
    //     0x68def4: b.ls            #0x68e05c
    // 0x68def8: cmp             w0, NULL
    // 0x68defc: b.eq            #0x68e04c
    // 0x68df00: cmp             w3, NULL
    // 0x68df04: b.eq            #0x68e064
    // 0x68df08: LoadField: r6 = r3->field_b
    //     0x68df08: ldur            w6, [x3, #0xb]
    // 0x68df0c: DecompressPointer r6
    //     0x68df0c: add             x6, x6, HEAP, lsl #32
    // 0x68df10: stur            x6, [fp, #-0x10]
    // 0x68df14: r1 = LoadInt32Instr(r6)
    //     0x68df14: sbfx            x1, x6, #1, #0x1f
    // 0x68df18: cmp             x5, x1
    // 0x68df1c: b.ge            #0x68e04c
    // 0x68df20: LoadField: r7 = r0->field_17
    //     0x68df20: ldur            w7, [x0, #0x17]
    // 0x68df24: DecompressPointer r7
    //     0x68df24: add             x7, x7, HEAP, lsl #32
    // 0x68df28: stur            x7, [fp, #-8]
    // 0x68df2c: cmp             w7, NULL
    // 0x68df30: b.eq            #0x68e068
    // 0x68df34: mov             x0, x7
    // 0x68df38: r2 = Null
    //     0x68df38: mov             x2, NULL
    // 0x68df3c: r1 = Null
    //     0x68df3c: mov             x1, NULL
    // 0x68df40: r4 = LoadClassIdInstr(r0)
    //     0x68df40: ldur            x4, [x0, #-1]
    //     0x68df44: ubfx            x4, x4, #0xc, #0x14
    // 0x68df48: cmp             x4, #0x808
    // 0x68df4c: b.eq            #0x68df64
    // 0x68df50: r8 = TextParentData<RenderBox>
    //     0x68df50: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x68df54: ldr             x8, [x8, #0x298]
    // 0x68df58: r3 = Null
    //     0x68df58: add             x3, PP, #0x22, lsl #12  ; [pp+0x22440] Null
    //     0x68df5c: ldr             x3, [x3, #0x440]
    // 0x68df60: r0 = DefaultTypeTest()
    //     0x68df60: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x68df64: ldur            x0, [fp, #-0x10]
    // 0x68df68: r1 = LoadInt32Instr(r0)
    //     0x68df68: sbfx            x1, x0, #1, #0x1f
    // 0x68df6c: mov             x0, x1
    // 0x68df70: ldur            x1, [fp, #-0x18]
    // 0x68df74: cmp             x1, x0
    // 0x68df78: b.hs            #0x68e06c
    // 0x68df7c: ldur            x0, [fp, #-0x28]
    // 0x68df80: LoadField: r1 = r0->field_f
    //     0x68df80: ldur            w1, [x0, #0xf]
    // 0x68df84: DecompressPointer r1
    //     0x68df84: add             x1, x1, HEAP, lsl #32
    // 0x68df88: ldur            x2, [fp, #-0x18]
    // 0x68df8c: ArrayLoad: r3 = r1[r2]  ; Unknown_4
    //     0x68df8c: add             x16, x1, x2, lsl #2
    //     0x68df90: ldur            w3, [x16, #0xf]
    // 0x68df94: DecompressPointer r3
    //     0x68df94: add             x3, x3, HEAP, lsl #32
    // 0x68df98: LoadField: d0 = r3->field_7
    //     0x68df98: ldur            d0, [x3, #7]
    // 0x68df9c: stur            d0, [fp, #-0x38]
    // 0x68dfa0: LoadField: d1 = r3->field_f
    //     0x68dfa0: ldur            d1, [x3, #0xf]
    // 0x68dfa4: stur            d1, [fp, #-0x30]
    // 0x68dfa8: r0 = Offset()
    //     0x68dfa8: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x68dfac: ldur            d0, [fp, #-0x38]
    // 0x68dfb0: StoreField: r0->field_7 = d0
    //     0x68dfb0: stur            d0, [x0, #7]
    // 0x68dfb4: ldur            d0, [fp, #-0x30]
    // 0x68dfb8: StoreField: r0->field_f = d0
    //     0x68dfb8: stur            d0, [x0, #0xf]
    // 0x68dfbc: ldur            x2, [fp, #-8]
    // 0x68dfc0: StoreField: r2->field_7 = r0
    //     0x68dfc0: stur            w0, [x2, #7]
    //     0x68dfc4: ldurb           w16, [x2, #-1]
    //     0x68dfc8: ldurb           w17, [x0, #-1]
    //     0x68dfcc: and             x16, x17, x16, lsr #2
    //     0x68dfd0: tst             x16, HEAP, lsr #32
    //     0x68dfd4: b.eq            #0x68dfdc
    //     0x68dfd8: bl              #0xd6828c
    // 0x68dfdc: ldur            x3, [fp, #-0x20]
    // 0x68dfe0: cmp             w3, NULL
    // 0x68dfe4: b.eq            #0x68e070
    // 0x68dfe8: LoadField: r4 = r3->field_b
    //     0x68dfe8: ldur            w4, [x3, #0xb]
    // 0x68dfec: DecompressPointer r4
    //     0x68dfec: add             x4, x4, HEAP, lsl #32
    // 0x68dff0: r0 = LoadInt32Instr(r4)
    //     0x68dff0: sbfx            x0, x4, #1, #0x1f
    // 0x68dff4: ldur            x1, [fp, #-0x18]
    // 0x68dff8: cmp             x1, x0
    // 0x68dffc: b.hs            #0x68e074
    // 0x68e000: LoadField: r1 = r3->field_f
    //     0x68e000: ldur            w1, [x3, #0xf]
    // 0x68e004: DecompressPointer r1
    //     0x68e004: add             x1, x1, HEAP, lsl #32
    // 0x68e008: ldur            x4, [fp, #-0x18]
    // 0x68e00c: ArrayLoad: r0 = r1[r4]  ; Unknown_4
    //     0x68e00c: add             x16, x1, x4, lsl #2
    //     0x68e010: ldur            w0, [x16, #0xf]
    // 0x68e014: DecompressPointer r0
    //     0x68e014: add             x0, x0, HEAP, lsl #32
    // 0x68e018: StoreField: r2->field_17 = r0
    //     0x68e018: stur            w0, [x2, #0x17]
    //     0x68e01c: ldurb           w16, [x2, #-1]
    //     0x68e020: ldurb           w17, [x0, #-1]
    //     0x68e024: and             x16, x17, x16, lsr #2
    //     0x68e028: tst             x16, HEAP, lsr #32
    //     0x68e02c: b.eq            #0x68e034
    //     0x68e030: bl              #0xd6828c
    // 0x68e034: LoadField: r0 = r2->field_13
    //     0x68e034: ldur            w0, [x2, #0x13]
    // 0x68e038: DecompressPointer r0
    //     0x68e038: add             x0, x0, HEAP, lsl #32
    // 0x68e03c: add             x5, x4, #1
    // 0x68e040: mov             x4, x3
    // 0x68e044: ldur            x3, [fp, #-0x28]
    // 0x68e048: b               #0x68dee8
    // 0x68e04c: r0 = Null
    //     0x68e04c: mov             x0, NULL
    // 0x68e050: LeaveFrame
    //     0x68e050: mov             SP, fp
    //     0x68e054: ldp             fp, lr, [SP], #0x10
    // 0x68e058: ret
    //     0x68e058: ret             
    // 0x68e05c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68e05c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68e060: b               #0x68def8
    // 0x68e064: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68e064: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68e068: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68e068: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68e06c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x68e06c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x68e070: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68e070: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68e074: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x68e074: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _layoutChildren(/* No info */) {
    // ** addr: 0x68e078, size: 0x5b8
    // 0x68e078: EnterFrame
    //     0x68e078: stp             fp, lr, [SP, #-0x10]!
    //     0x68e07c: mov             fp, SP
    // 0x68e080: AllocStack(0x60)
    //     0x68e080: sub             SP, SP, #0x60
    // 0x68e084: SetupParameters(RenderParagraph this /* r3, fp-0x28 */, dynamic _ /* r4, fp-0x20 */, {dynamic dry = false /* r5, fp-0x18 */})
    //     0x68e084: mov             x0, x4
    //     0x68e088: ldur            w1, [x0, #0x13]
    //     0x68e08c: add             x1, x1, HEAP, lsl #32
    //     0x68e090: sub             x2, x1, #4
    //     0x68e094: add             x3, fp, w2, sxtw #2
    //     0x68e098: ldr             x3, [x3, #0x18]
    //     0x68e09c: stur            x3, [fp, #-0x28]
    //     0x68e0a0: add             x4, fp, w2, sxtw #2
    //     0x68e0a4: ldr             x4, [x4, #0x10]
    //     0x68e0a8: stur            x4, [fp, #-0x20]
    //     0x68e0ac: ldur            w2, [x0, #0x1f]
    //     0x68e0b0: add             x2, x2, HEAP, lsl #32
    //     0x68e0b4: add             x16, PP, #0x22, lsl #12  ; [pp+0x22450] "dry"
    //     0x68e0b8: ldr             x16, [x16, #0x450]
    //     0x68e0bc: cmp             w2, w16
    //     0x68e0c0: b.ne            #0x68e0e0
    //     0x68e0c4: ldur            w2, [x0, #0x23]
    //     0x68e0c8: add             x2, x2, HEAP, lsl #32
    //     0x68e0cc: sub             w0, w1, w2
    //     0x68e0d0: add             x1, fp, w0, sxtw #2
    //     0x68e0d4: ldr             x1, [x1, #8]
    //     0x68e0d8: mov             x5, x1
    //     0x68e0dc: b               #0x68e0e4
    //     0x68e0e0: add             x5, NULL, #0x30  ; false
    //     0x68e0e4: stur            x5, [fp, #-0x18]
    // 0x68e0e8: CheckStackOverflow
    //     0x68e0e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68e0ec: cmp             SP, x16
    //     0x68e0f0: b.ls            #0x68e5ac
    // 0x68e0f4: LoadField: r6 = r3->field_5f
    //     0x68e0f4: ldur            x6, [x3, #0x5f]
    // 0x68e0f8: stur            x6, [fp, #-0x10]
    // 0x68e0fc: cbnz            x6, #0x68e120
    // 0x68e100: r16 = <PlaceholderDimensions>
    //     0x68e100: add             x16, PP, #0x22, lsl #12  ; [pp+0x22320] TypeArguments: <PlaceholderDimensions>
    //     0x68e104: ldr             x16, [x16, #0x320]
    // 0x68e108: stp             xzr, x16, [SP, #-0x10]!
    // 0x68e10c: r0 = _GrowableList()
    //     0x68e10c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x68e110: add             SP, SP, #0x10
    // 0x68e114: LeaveFrame
    //     0x68e114: mov             SP, fp
    //     0x68e118: ldp             fp, lr, [SP], #0x10
    // 0x68e11c: ret
    //     0x68e11c: ret             
    // 0x68e120: LoadField: r7 = r3->field_67
    //     0x68e120: ldur            w7, [x3, #0x67]
    // 0x68e124: DecompressPointer r7
    //     0x68e124: add             x7, x7, HEAP, lsl #32
    // 0x68e128: stur            x7, [fp, #-8]
    // 0x68e12c: r0 = BoxInt64Instr(r6)
    //     0x68e12c: sbfiz           x0, x6, #1, #0x1f
    //     0x68e130: cmp             x6, x0, asr #1
    //     0x68e134: b.eq            #0x68e140
    //     0x68e138: bl              #0xd69bb8
    //     0x68e13c: stur            x6, [x0, #7]
    // 0x68e140: mov             x2, x0
    // 0x68e144: r1 = <PlaceholderDimensions>
    //     0x68e144: add             x1, PP, #0x22, lsl #12  ; [pp+0x22320] TypeArguments: <PlaceholderDimensions>
    //     0x68e148: ldr             x1, [x1, #0x320]
    // 0x68e14c: r0 = AllocateArray()
    //     0x68e14c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x68e150: stur            x0, [fp, #-0x30]
    // 0x68e154: ldur            x1, [fp, #-0x10]
    // 0x68e158: r2 = 0
    //     0x68e158: mov             x2, #0
    // 0x68e15c: CheckStackOverflow
    //     0x68e15c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68e160: cmp             SP, x16
    //     0x68e164: b.ls            #0x68e5b4
    // 0x68e168: cmp             x2, x1
    // 0x68e16c: b.ge            #0x68e18c
    // 0x68e170: add             x3, x0, x2, lsl #2
    // 0x68e174: r17 = Instance_PlaceholderDimensions
    //     0x68e174: add             x17, PP, #0x22, lsl #12  ; [pp+0x22458] Obj!PlaceholderDimensions@b356b1
    //     0x68e178: ldr             x17, [x17, #0x458]
    // 0x68e17c: StoreField: r3->field_f = r17
    //     0x68e17c: stur            w17, [x3, #0xf]
    // 0x68e180: add             x3, x2, #1
    // 0x68e184: mov             x2, x3
    // 0x68e188: b               #0x68e15c
    // 0x68e18c: ldur            x2, [fp, #-0x28]
    // 0x68e190: ldur            x3, [fp, #-0x20]
    // 0x68e194: LoadField: d0 = r3->field_f
    //     0x68e194: ldur            d0, [x3, #0xf]
    // 0x68e198: stur            d0, [fp, #-0x60]
    // 0x68e19c: r0 = BoxConstraints()
    //     0x68e19c: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x68e1a0: d0 = 0.000000
    //     0x68e1a0: eor             v0.16b, v0.16b, v0.16b
    // 0x68e1a4: StoreField: r0->field_7 = d0
    //     0x68e1a4: stur            d0, [x0, #7]
    // 0x68e1a8: ldur            d1, [fp, #-0x60]
    // 0x68e1ac: StoreField: r0->field_f = d1
    //     0x68e1ac: stur            d1, [x0, #0xf]
    // 0x68e1b0: StoreField: r0->field_17 = d0
    //     0x68e1b0: stur            d0, [x0, #0x17]
    // 0x68e1b4: d0 = inf
    //     0x68e1b4: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x68e1b8: StoreField: r0->field_1f = d0
    //     0x68e1b8: stur            d0, [x0, #0x1f]
    // 0x68e1bc: ldur            x1, [fp, #-0x28]
    // 0x68e1c0: LoadField: r2 = r1->field_6f
    //     0x68e1c0: ldur            w2, [x1, #0x6f]
    // 0x68e1c4: DecompressPointer r2
    //     0x68e1c4: add             x2, x2, HEAP, lsl #32
    // 0x68e1c8: LoadField: d0 = r2->field_1f
    //     0x68e1c8: ldur            d0, [x2, #0x1f]
    // 0x68e1cc: r2 = inline_Allocate_Double()
    //     0x68e1cc: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x68e1d0: add             x2, x2, #0x10
    //     0x68e1d4: cmp             x3, x2
    //     0x68e1d8: b.ls            #0x68e5bc
    //     0x68e1dc: str             x2, [THR, #0x60]  ; THR::top
    //     0x68e1e0: sub             x2, x2, #0xf
    //     0x68e1e4: mov             x3, #0xd108
    //     0x68e1e8: movk            x3, #3, lsl #16
    //     0x68e1ec: stur            x3, [x2, #-1]
    // 0x68e1f0: StoreField: r2->field_7 = d0
    //     0x68e1f0: stur            d0, [x2, #7]
    // 0x68e1f4: stp             x2, x0, [SP, #-0x10]!
    // 0x68e1f8: r0 = /()
    //     0x68e1f8: bl              #0x524234  ; [package:flutter/src/rendering/box.dart] BoxConstraints::/
    // 0x68e1fc: add             SP, SP, #0x10
    // 0x68e200: mov             x1, x0
    // 0x68e204: stur            x1, [fp, #-0x20]
    // 0x68e208: ldur            x5, [fp, #-8]
    // 0x68e20c: r4 = 0
    //     0x68e20c: mov             x4, #0
    // 0x68e210: ldur            x2, [fp, #-0x28]
    // 0x68e214: ldur            x3, [fp, #-0x18]
    // 0x68e218: stur            x5, [fp, #-8]
    // 0x68e21c: stur            x4, [fp, #-0x38]
    // 0x68e220: CheckStackOverflow
    //     0x68e220: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68e224: cmp             SP, x16
    //     0x68e228: b.ls            #0x68e5d8
    // 0x68e22c: cmp             w5, NULL
    // 0x68e230: b.eq            #0x68e59c
    // 0x68e234: tbz             w3, #4, #0x68e38c
    // 0x68e238: r0 = LoadClassIdInstr(r5)
    //     0x68e238: ldur            x0, [x5, #-1]
    //     0x68e23c: ubfx            x0, x0, #0xc, #0x14
    // 0x68e240: stp             x1, x5, [SP, #-0x10]!
    // 0x68e244: r16 = true
    //     0x68e244: add             x16, NULL, #0x20  ; true
    // 0x68e248: SaveReg r16
    //     0x68e248: str             x16, [SP, #-8]!
    // 0x68e24c: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x68e24c: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x68e250: ldr             x4, [x4, #0x1c8]
    // 0x68e254: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x68e254: mov             x17, #0xcdfb
    //     0x68e258: add             lr, x0, x17
    //     0x68e25c: ldr             lr, [x21, lr, lsl #3]
    //     0x68e260: blr             lr
    // 0x68e264: add             SP, SP, #0x18
    // 0x68e268: ldur            x2, [fp, #-8]
    // 0x68e26c: LoadField: r3 = r2->field_57
    //     0x68e26c: ldur            w3, [x2, #0x57]
    // 0x68e270: DecompressPointer r3
    //     0x68e270: add             x3, x3, HEAP, lsl #32
    // 0x68e274: stur            x3, [fp, #-0x40]
    // 0x68e278: cmp             w3, NULL
    // 0x68e27c: b.eq            #0x68e5e0
    // 0x68e280: ldur            x4, [fp, #-0x28]
    // 0x68e284: LoadField: r5 = r4->field_83
    //     0x68e284: ldur            w5, [x4, #0x83]
    // 0x68e288: DecompressPointer r5
    //     0x68e288: add             x5, x5, HEAP, lsl #32
    // 0x68e28c: r16 = Sentinel
    //     0x68e28c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x68e290: cmp             w5, w16
    // 0x68e294: b.eq            #0x68e5e4
    // 0x68e298: LoadField: r0 = r5->field_b
    //     0x68e298: ldur            w0, [x5, #0xb]
    // 0x68e29c: DecompressPointer r0
    //     0x68e29c: add             x0, x0, HEAP, lsl #32
    // 0x68e2a0: r1 = LoadInt32Instr(r0)
    //     0x68e2a0: sbfx            x1, x0, #1, #0x1f
    // 0x68e2a4: mov             x0, x1
    // 0x68e2a8: ldur            x1, [fp, #-0x38]
    // 0x68e2ac: cmp             x1, x0
    // 0x68e2b0: b.hs            #0x68e5f0
    // 0x68e2b4: LoadField: r0 = r5->field_f
    //     0x68e2b4: ldur            w0, [x5, #0xf]
    // 0x68e2b8: DecompressPointer r0
    //     0x68e2b8: add             x0, x0, HEAP, lsl #32
    // 0x68e2bc: ldur            x1, [fp, #-0x38]
    // 0x68e2c0: ArrayLoad: r5 = r0[r1]  ; Unknown_4
    //     0x68e2c0: add             x16, x0, x1, lsl #2
    //     0x68e2c4: ldur            w5, [x16, #0xf]
    // 0x68e2c8: DecompressPointer r5
    //     0x68e2c8: add             x5, x5, HEAP, lsl #32
    // 0x68e2cc: LoadField: r0 = r5->field_b
    //     0x68e2cc: ldur            w0, [x5, #0xb]
    // 0x68e2d0: DecompressPointer r0
    //     0x68e2d0: add             x0, x0, HEAP, lsl #32
    // 0x68e2d4: LoadField: r6 = r0->field_7
    //     0x68e2d4: ldur            x6, [x0, #7]
    // 0x68e2d8: cmp             x6, #2
    // 0x68e2dc: b.gt            #0x68e374
    // 0x68e2e0: cmp             x6, #1
    // 0x68e2e4: b.gt            #0x68e36c
    // 0x68e2e8: cmp             x6, #0
    // 0x68e2ec: b.gt            #0x68e364
    // 0x68e2f0: LoadField: r0 = r5->field_f
    //     0x68e2f0: ldur            w0, [x5, #0xf]
    // 0x68e2f4: DecompressPointer r0
    //     0x68e2f4: add             x0, x0, HEAP, lsl #32
    // 0x68e2f8: cmp             w0, NULL
    // 0x68e2fc: b.eq            #0x68e5f4
    // 0x68e300: stp             x0, x2, [SP, #-0x10]!
    // 0x68e304: r0 = getDistanceToActualBaseline()
    //     0x68e304: bl              #0x63d634  ; [package:flutter/src/rendering/box.dart] RenderBox::getDistanceToActualBaseline
    // 0x68e308: add             SP, SP, #0x10
    // 0x68e30c: cmp             w0, NULL
    // 0x68e310: b.ne            #0x68e330
    // 0x68e314: ldur            x1, [fp, #-8]
    // 0x68e318: LoadField: r0 = r1->field_57
    //     0x68e318: ldur            w0, [x1, #0x57]
    // 0x68e31c: DecompressPointer r0
    //     0x68e31c: add             x0, x0, HEAP, lsl #32
    // 0x68e320: cmp             w0, NULL
    // 0x68e324: b.eq            #0x68e5f8
    // 0x68e328: LoadField: d0 = r0->field_f
    //     0x68e328: ldur            d0, [x0, #0xf]
    // 0x68e32c: b               #0x68e338
    // 0x68e330: ldur            x1, [fp, #-8]
    // 0x68e334: LoadField: d0 = r0->field_7
    //     0x68e334: ldur            d0, [x0, #7]
    // 0x68e338: r0 = inline_Allocate_Double()
    //     0x68e338: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x68e33c: add             x0, x0, #0x10
    //     0x68e340: cmp             x2, x0
    //     0x68e344: b.ls            #0x68e5fc
    //     0x68e348: str             x0, [THR, #0x60]  ; THR::top
    //     0x68e34c: sub             x0, x0, #0xf
    //     0x68e350: mov             x2, #0xd108
    //     0x68e354: movk            x2, #3, lsl #16
    //     0x68e358: stur            x2, [x0, #-1]
    // 0x68e35c: StoreField: r0->field_7 = d0
    //     0x68e35c: stur            d0, [x0, #7]
    // 0x68e360: b               #0x68e37c
    // 0x68e364: mov             x1, x2
    // 0x68e368: b               #0x68e378
    // 0x68e36c: mov             x1, x2
    // 0x68e370: b               #0x68e378
    // 0x68e374: mov             x1, x2
    // 0x68e378: r0 = Null
    //     0x68e378: mov             x0, NULL
    // 0x68e37c: mov             x6, x0
    // 0x68e380: ldur            x5, [fp, #-0x40]
    // 0x68e384: mov             x2, x1
    // 0x68e388: b               #0x68e460
    // 0x68e38c: mov             x0, x1
    // 0x68e390: mov             x1, x5
    // 0x68e394: r1 = 2
    //     0x68e394: mov             x1, #2
    // 0x68e398: r0 = AllocateContext()
    //     0x68e398: bl              #0xd68aa4  ; AllocateContextStub
    // 0x68e39c: mov             x1, x0
    // 0x68e3a0: ldur            x0, [fp, #-8]
    // 0x68e3a4: stur            x1, [fp, #-0x40]
    // 0x68e3a8: StoreField: r1->field_f = r0
    //     0x68e3a8: stur            w0, [x1, #0xf]
    // 0x68e3ac: ldur            x2, [fp, #-0x20]
    // 0x68e3b0: StoreField: r1->field_13 = r2
    //     0x68e3b0: stur            w2, [x1, #0x13]
    // 0x68e3b4: LoadField: r3 = r0->field_53
    //     0x68e3b4: ldur            w3, [x0, #0x53]
    // 0x68e3b8: DecompressPointer r3
    //     0x68e3b8: add             x3, x3, HEAP, lsl #32
    // 0x68e3bc: cmp             w3, NULL
    // 0x68e3c0: b.ne            #0x68e40c
    // 0x68e3c4: r16 = <BoxConstraints, Size>
    //     0x68e3c4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15208] TypeArguments: <BoxConstraints, Size>
    //     0x68e3c8: ldr             x16, [x16, #0x208]
    // 0x68e3cc: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x68e3d0: stp             lr, x16, [SP, #-0x10]!
    // 0x68e3d4: r0 = Map._fromLiteral()
    //     0x68e3d4: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x68e3d8: add             SP, SP, #0x10
    // 0x68e3dc: mov             x1, x0
    // 0x68e3e0: ldur            x4, [fp, #-8]
    // 0x68e3e4: StoreField: r4->field_53 = r0
    //     0x68e3e4: stur            w0, [x4, #0x53]
    //     0x68e3e8: tbz             w0, #0, #0x68e404
    //     0x68e3ec: ldurb           w16, [x4, #-1]
    //     0x68e3f0: ldurb           w17, [x0, #-1]
    //     0x68e3f4: and             x16, x17, x16, lsr #2
    //     0x68e3f8: tst             x16, HEAP, lsr #32
    //     0x68e3fc: b.eq            #0x68e404
    //     0x68e400: bl              #0xd682cc
    // 0x68e404: mov             x0, x1
    // 0x68e408: b               #0x68e414
    // 0x68e40c: mov             x4, x0
    // 0x68e410: mov             x0, x3
    // 0x68e414: ldur            x2, [fp, #-0x40]
    // 0x68e418: stur            x0, [fp, #-0x50]
    // 0x68e41c: cmp             w0, NULL
    // 0x68e420: b.eq            #0x68e614
    // 0x68e424: LoadField: r3 = r2->field_13
    //     0x68e424: ldur            w3, [x2, #0x13]
    // 0x68e428: DecompressPointer r3
    //     0x68e428: add             x3, x3, HEAP, lsl #32
    // 0x68e42c: stur            x3, [fp, #-0x48]
    // 0x68e430: r1 = Function '<anonymous closure>':.
    //     0x68e430: add             x1, PP, #0x15, lsl #12  ; [pp+0x15210] AnonymousClosure: (0x62d778), in [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout (0x62d394)
    //     0x68e434: ldr             x1, [x1, #0x210]
    // 0x68e438: r0 = AllocateClosure()
    //     0x68e438: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x68e43c: ldur            x16, [fp, #-0x50]
    // 0x68e440: ldur            lr, [fp, #-0x48]
    // 0x68e444: stp             lr, x16, [SP, #-0x10]!
    // 0x68e448: SaveReg r0
    //     0x68e448: str             x0, [SP, #-8]!
    // 0x68e44c: r0 = putIfAbsent()
    //     0x68e44c: bl              #0xc7a83c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0x68e450: add             SP, SP, #0x18
    // 0x68e454: mov             x5, x0
    // 0x68e458: ldur            x2, [fp, #-8]
    // 0x68e45c: r6 = Null
    //     0x68e45c: mov             x6, NULL
    // 0x68e460: ldur            x3, [fp, #-0x28]
    // 0x68e464: ldur            x4, [fp, #-0x38]
    // 0x68e468: stur            x6, [fp, #-0x50]
    // 0x68e46c: stur            x5, [fp, #-0x58]
    // 0x68e470: LoadField: r7 = r3->field_83
    //     0x68e470: ldur            w7, [x3, #0x83]
    // 0x68e474: DecompressPointer r7
    //     0x68e474: add             x7, x7, HEAP, lsl #32
    // 0x68e478: r16 = Sentinel
    //     0x68e478: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x68e47c: cmp             w7, w16
    // 0x68e480: b.eq            #0x68e618
    // 0x68e484: LoadField: r0 = r7->field_b
    //     0x68e484: ldur            w0, [x7, #0xb]
    // 0x68e488: DecompressPointer r0
    //     0x68e488: add             x0, x0, HEAP, lsl #32
    // 0x68e48c: r1 = LoadInt32Instr(r0)
    //     0x68e48c: sbfx            x1, x0, #1, #0x1f
    // 0x68e490: mov             x0, x1
    // 0x68e494: mov             x1, x4
    // 0x68e498: cmp             x1, x0
    // 0x68e49c: b.hs            #0x68e624
    // 0x68e4a0: LoadField: r0 = r7->field_f
    //     0x68e4a0: ldur            w0, [x7, #0xf]
    // 0x68e4a4: DecompressPointer r0
    //     0x68e4a4: add             x0, x0, HEAP, lsl #32
    // 0x68e4a8: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x68e4a8: add             x16, x0, x4, lsl #2
    //     0x68e4ac: ldur            w1, [x16, #0xf]
    // 0x68e4b0: DecompressPointer r1
    //     0x68e4b0: add             x1, x1, HEAP, lsl #32
    // 0x68e4b4: LoadField: r0 = r1->field_b
    //     0x68e4b4: ldur            w0, [x1, #0xb]
    // 0x68e4b8: DecompressPointer r0
    //     0x68e4b8: add             x0, x0, HEAP, lsl #32
    // 0x68e4bc: stur            x0, [fp, #-0x48]
    // 0x68e4c0: LoadField: r7 = r1->field_f
    //     0x68e4c0: ldur            w7, [x1, #0xf]
    // 0x68e4c4: DecompressPointer r7
    //     0x68e4c4: add             x7, x7, HEAP, lsl #32
    // 0x68e4c8: stur            x7, [fp, #-0x40]
    // 0x68e4cc: r0 = PlaceholderDimensions()
    //     0x68e4cc: bl              #0x62d738  ; AllocatePlaceholderDimensionsStub -> PlaceholderDimensions (size=0x18)
    // 0x68e4d0: mov             x2, x0
    // 0x68e4d4: ldur            x0, [fp, #-0x58]
    // 0x68e4d8: StoreField: r2->field_7 = r0
    //     0x68e4d8: stur            w0, [x2, #7]
    // 0x68e4dc: ldur            x0, [fp, #-0x48]
    // 0x68e4e0: StoreField: r2->field_b = r0
    //     0x68e4e0: stur            w0, [x2, #0xb]
    // 0x68e4e4: ldur            x0, [fp, #-0x40]
    // 0x68e4e8: StoreField: r2->field_13 = r0
    //     0x68e4e8: stur            w0, [x2, #0x13]
    // 0x68e4ec: ldur            x0, [fp, #-0x50]
    // 0x68e4f0: StoreField: r2->field_f = r0
    //     0x68e4f0: stur            w0, [x2, #0xf]
    // 0x68e4f4: ldur            x0, [fp, #-0x10]
    // 0x68e4f8: ldur            x1, [fp, #-0x38]
    // 0x68e4fc: cmp             x1, x0
    // 0x68e500: b.hs            #0x68e628
    // 0x68e504: ldur            x1, [fp, #-0x30]
    // 0x68e508: mov             x0, x2
    // 0x68e50c: ldur            x3, [fp, #-0x38]
    // 0x68e510: ArrayStore: r1[r3] = r0  ; List_4
    //     0x68e510: add             x25, x1, x3, lsl #2
    //     0x68e514: add             x25, x25, #0xf
    //     0x68e518: str             w0, [x25]
    //     0x68e51c: tbz             w0, #0, #0x68e538
    //     0x68e520: ldurb           w16, [x1, #-1]
    //     0x68e524: ldurb           w17, [x0, #-1]
    //     0x68e528: and             x16, x17, x16, lsr #2
    //     0x68e52c: tst             x16, HEAP, lsr #32
    //     0x68e530: b.eq            #0x68e538
    //     0x68e534: bl              #0xd67e5c
    // 0x68e538: ldur            x0, [fp, #-8]
    // 0x68e53c: LoadField: r4 = r0->field_17
    //     0x68e53c: ldur            w4, [x0, #0x17]
    // 0x68e540: DecompressPointer r4
    //     0x68e540: add             x4, x4, HEAP, lsl #32
    // 0x68e544: stur            x4, [fp, #-0x40]
    // 0x68e548: cmp             w4, NULL
    // 0x68e54c: b.eq            #0x68e62c
    // 0x68e550: mov             x0, x4
    // 0x68e554: r2 = Null
    //     0x68e554: mov             x2, NULL
    // 0x68e558: r1 = Null
    //     0x68e558: mov             x1, NULL
    // 0x68e55c: r4 = LoadClassIdInstr(r0)
    //     0x68e55c: ldur            x4, [x0, #-1]
    //     0x68e560: ubfx            x4, x4, #0xc, #0x14
    // 0x68e564: cmp             x4, #0x808
    // 0x68e568: b.eq            #0x68e580
    // 0x68e56c: r8 = TextParentData<RenderBox>
    //     0x68e56c: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x68e570: ldr             x8, [x8, #0x298]
    // 0x68e574: r3 = Null
    //     0x68e574: add             x3, PP, #0x22, lsl #12  ; [pp+0x22460] Null
    //     0x68e578: ldr             x3, [x3, #0x460]
    // 0x68e57c: r0 = DefaultTypeTest()
    //     0x68e57c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x68e580: ldur            x1, [fp, #-0x40]
    // 0x68e584: LoadField: r5 = r1->field_13
    //     0x68e584: ldur            w5, [x1, #0x13]
    // 0x68e588: DecompressPointer r5
    //     0x68e588: add             x5, x5, HEAP, lsl #32
    // 0x68e58c: ldur            x1, [fp, #-0x38]
    // 0x68e590: add             x4, x1, #1
    // 0x68e594: ldur            x1, [fp, #-0x20]
    // 0x68e598: b               #0x68e210
    // 0x68e59c: ldur            x0, [fp, #-0x30]
    // 0x68e5a0: LeaveFrame
    //     0x68e5a0: mov             SP, fp
    //     0x68e5a4: ldp             fp, lr, [SP], #0x10
    // 0x68e5a8: ret
    //     0x68e5a8: ret             
    // 0x68e5ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68e5ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68e5b0: b               #0x68e0f4
    // 0x68e5b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68e5b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68e5b8: b               #0x68e168
    // 0x68e5bc: SaveReg d0
    //     0x68e5bc: str             q0, [SP, #-0x10]!
    // 0x68e5c0: stp             x0, x1, [SP, #-0x10]!
    // 0x68e5c4: r0 = AllocateDouble()
    //     0x68e5c4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68e5c8: mov             x2, x0
    // 0x68e5cc: ldp             x0, x1, [SP], #0x10
    // 0x68e5d0: RestoreReg d0
    //     0x68e5d0: ldr             q0, [SP], #0x10
    // 0x68e5d4: b               #0x68e1f0
    // 0x68e5d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68e5d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68e5dc: b               #0x68e22c
    // 0x68e5e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68e5e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68e5e4: r9 = _placeholderSpans
    //     0x68e5e4: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d468] Field <RenderParagraph._placeholderSpans@507149678>: late (offset: 0x84)
    //     0x68e5e8: ldr             x9, [x9, #0x468]
    // 0x68e5ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x68e5ec: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x68e5f0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x68e5f0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x68e5f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68e5f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68e5f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68e5f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68e5fc: SaveReg d0
    //     0x68e5fc: str             q0, [SP, #-0x10]!
    // 0x68e600: SaveReg r1
    //     0x68e600: str             x1, [SP, #-8]!
    // 0x68e604: r0 = AllocateDouble()
    //     0x68e604: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68e608: RestoreReg r1
    //     0x68e608: ldr             x1, [SP], #8
    // 0x68e60c: RestoreReg d0
    //     0x68e60c: ldr             q0, [SP], #0x10
    // 0x68e610: b               #0x68e35c
    // 0x68e614: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68e614: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68e618: r9 = _placeholderSpans
    //     0x68e618: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d468] Field <RenderParagraph._placeholderSpans@507149678>: late (offset: 0x84)
    //     0x68e61c: ldr             x9, [x9, #0x468]
    // 0x68e620: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x68e620: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x68e624: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x68e624: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x68e628: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x68e628: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x68e62c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68e62c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ markNeedsLayout(/* No info */) {
    // ** addr: 0x6c0c74, size: 0x114
    // 0x6c0c74: EnterFrame
    //     0x6c0c74: stp             fp, lr, [SP, #-0x10]!
    //     0x6c0c78: mov             fp, SP
    // 0x6c0c7c: AllocStack(0x18)
    //     0x6c0c7c: sub             SP, SP, #0x18
    // 0x6c0c80: CheckStackOverflow
    //     0x6c0c80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c0c84: cmp             SP, x16
    //     0x6c0c88: b.ls            #0x6c0d74
    // 0x6c0c8c: ldr             x2, [fp, #0x10]
    // 0x6c0c90: LoadField: r3 = r2->field_7b
    //     0x6c0c90: ldur            w3, [x2, #0x7b]
    // 0x6c0c94: DecompressPointer r3
    //     0x6c0c94: add             x3, x3, HEAP, lsl #32
    // 0x6c0c98: stur            x3, [fp, #-0x18]
    // 0x6c0c9c: cmp             w3, NULL
    // 0x6c0ca0: b.eq            #0x6c0d38
    // 0x6c0ca4: LoadField: r4 = r3->field_b
    //     0x6c0ca4: ldur            w4, [x3, #0xb]
    // 0x6c0ca8: DecompressPointer r4
    //     0x6c0ca8: add             x4, x4, HEAP, lsl #32
    // 0x6c0cac: stur            x4, [fp, #-0x10]
    // 0x6c0cb0: r0 = LoadInt32Instr(r4)
    //     0x6c0cb0: sbfx            x0, x4, #1, #0x1f
    // 0x6c0cb4: r5 = 0
    //     0x6c0cb4: mov             x5, #0
    // 0x6c0cb8: stur            x5, [fp, #-8]
    // 0x6c0cbc: CheckStackOverflow
    //     0x6c0cbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c0cc0: cmp             SP, x16
    //     0x6c0cc4: b.ls            #0x6c0d7c
    // 0x6c0cc8: cmp             x5, x0
    // 0x6c0ccc: b.ge            #0x6c0d38
    // 0x6c0cd0: mov             x1, x5
    // 0x6c0cd4: cmp             x1, x0
    // 0x6c0cd8: b.hs            #0x6c0d84
    // 0x6c0cdc: LoadField: r0 = r3->field_f
    //     0x6c0cdc: ldur            w0, [x3, #0xf]
    // 0x6c0ce0: DecompressPointer r0
    //     0x6c0ce0: add             x0, x0, HEAP, lsl #32
    // 0x6c0ce4: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x6c0ce4: add             x16, x0, x5, lsl #2
    //     0x6c0ce8: ldur            w1, [x16, #0xf]
    // 0x6c0cec: DecompressPointer r1
    //     0x6c0cec: add             x1, x1, HEAP, lsl #32
    // 0x6c0cf0: SaveReg r1
    //     0x6c0cf0: str             x1, [SP, #-8]!
    // 0x6c0cf4: r0 = didChangeParagraphLayout()
    //     0x6c0cf4: bl              #0x6c0dd0  ; [package:flutter/src/rendering/paragraph.dart] _SelectableFragment::didChangeParagraphLayout
    // 0x6c0cf8: add             SP, SP, #8
    // 0x6c0cfc: ldur            x0, [fp, #-0x18]
    // 0x6c0d00: LoadField: r1 = r0->field_b
    //     0x6c0d00: ldur            w1, [x0, #0xb]
    // 0x6c0d04: DecompressPointer r1
    //     0x6c0d04: add             x1, x1, HEAP, lsl #32
    // 0x6c0d08: ldur            x2, [fp, #-0x10]
    // 0x6c0d0c: cmp             w1, w2
    // 0x6c0d10: b.ne            #0x6c0d58
    // 0x6c0d14: ldur            x3, [fp, #-8]
    // 0x6c0d18: add             x5, x3, #1
    // 0x6c0d1c: r3 = LoadInt32Instr(r1)
    //     0x6c0d1c: sbfx            x3, x1, #1, #0x1f
    // 0x6c0d20: mov             x16, x0
    // 0x6c0d24: mov             x0, x3
    // 0x6c0d28: mov             x3, x16
    // 0x6c0d2c: mov             x4, x2
    // 0x6c0d30: ldr             x2, [fp, #0x10]
    // 0x6c0d34: b               #0x6c0cb8
    // 0x6c0d38: ldr             x16, [fp, #0x10]
    // 0x6c0d3c: SaveReg r16
    //     0x6c0d3c: str             x16, [SP, #-8]!
    // 0x6c0d40: r0 = markNeedsLayout()
    //     0x6c0d40: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c0d44: add             SP, SP, #8
    // 0x6c0d48: r0 = Null
    //     0x6c0d48: mov             x0, NULL
    // 0x6c0d4c: LeaveFrame
    //     0x6c0d4c: mov             SP, fp
    //     0x6c0d50: ldp             fp, lr, [SP], #0x10
    // 0x6c0d54: ret
    //     0x6c0d54: ret             
    // 0x6c0d58: r0 = ConcurrentModificationError()
    //     0x6c0d58: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x6c0d5c: mov             x1, x0
    // 0x6c0d60: ldur            x0, [fp, #-0x18]
    // 0x6c0d64: StoreField: r1->field_b = r0
    //     0x6c0d64: stur            w0, [x1, #0xb]
    // 0x6c0d68: mov             x0, x1
    // 0x6c0d6c: r0 = Throw()
    //     0x6c0d6c: bl              #0xd67e38  ; ThrowStub
    // 0x6c0d70: brk             #0
    // 0x6c0d74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c0d74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c0d78: b               #0x6c0c8c
    // 0x6c0d7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c0d7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c0d80: b               #0x6c0cc8
    // 0x6c0d84: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6c0d84: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  set _ selectionColor=(/* No info */) {
    // ** addr: 0x6e1090, size: 0xf0
    // 0x6e1090: EnterFrame
    //     0x6e1090: stp             fp, lr, [SP, #-0x10]!
    //     0x6e1094: mov             fp, SP
    // 0x6e1098: AllocStack(0x8)
    //     0x6e1098: sub             SP, SP, #8
    // 0x6e109c: CheckStackOverflow
    //     0x6e109c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e10a0: cmp             SP, x16
    //     0x6e10a4: b.ls            #0x6e1178
    // 0x6e10a8: ldr             x1, [fp, #0x18]
    // 0x6e10ac: LoadField: r0 = r1->field_8f
    //     0x6e10ac: ldur            w0, [x1, #0x8f]
    // 0x6e10b0: DecompressPointer r0
    //     0x6e10b0: add             x0, x0, HEAP, lsl #32
    // 0x6e10b4: r2 = LoadClassIdInstr(r0)
    //     0x6e10b4: ldur            x2, [x0, #-1]
    //     0x6e10b8: ubfx            x2, x2, #0xc, #0x14
    // 0x6e10bc: ldr             x16, [fp, #0x10]
    // 0x6e10c0: stp             x16, x0, [SP, #-0x10]!
    // 0x6e10c4: mov             x0, x2
    // 0x6e10c8: mov             lr, x0
    // 0x6e10cc: ldr             lr, [x21, lr, lsl #3]
    // 0x6e10d0: blr             lr
    // 0x6e10d4: add             SP, SP, #0x10
    // 0x6e10d8: tbnz            w0, #4, #0x6e10ec
    // 0x6e10dc: r0 = Null
    //     0x6e10dc: mov             x0, NULL
    // 0x6e10e0: LeaveFrame
    //     0x6e10e0: mov             SP, fp
    //     0x6e10e4: ldp             fp, lr, [SP], #0x10
    // 0x6e10e8: ret
    //     0x6e10e8: ret             
    // 0x6e10ec: ldr             x3, [fp, #0x18]
    // 0x6e10f0: ldr             x0, [fp, #0x10]
    // 0x6e10f4: StoreField: r3->field_8f = r0
    //     0x6e10f4: stur            w0, [x3, #0x8f]
    //     0x6e10f8: ldurb           w16, [x3, #-1]
    //     0x6e10fc: ldurb           w17, [x0, #-1]
    //     0x6e1100: and             x16, x17, x16, lsr #2
    //     0x6e1104: tst             x16, HEAP, lsr #32
    //     0x6e1108: b.eq            #0x6e1110
    //     0x6e110c: bl              #0xd682ac
    // 0x6e1110: LoadField: r0 = r3->field_7b
    //     0x6e1110: ldur            w0, [x3, #0x7b]
    // 0x6e1114: DecompressPointer r0
    //     0x6e1114: add             x0, x0, HEAP, lsl #32
    // 0x6e1118: stur            x0, [fp, #-8]
    // 0x6e111c: cmp             w0, NULL
    // 0x6e1120: b.ne            #0x6e112c
    // 0x6e1124: r0 = Null
    //     0x6e1124: mov             x0, NULL
    // 0x6e1128: b               #0x6e114c
    // 0x6e112c: r1 = Function '<anonymous closure>':.
    //     0x6e112c: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d3e8] AnonymousClosure: (0x6e1180), in [package:flutter/src/rendering/paragraph.dart] RenderParagraph::selectionColor= (0x6e1090)
    //     0x6e1130: ldr             x1, [x1, #0x3e8]
    // 0x6e1134: r2 = Null
    //     0x6e1134: mov             x2, NULL
    // 0x6e1138: r0 = AllocateClosure()
    //     0x6e1138: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6e113c: ldur            x16, [fp, #-8]
    // 0x6e1140: stp             x0, x16, [SP, #-0x10]!
    // 0x6e1144: r0 = any()
    //     0x6e1144: bl              #0x6f72b8  ; [dart:collection] _ListBase&Object&ListMixin::any
    // 0x6e1148: add             SP, SP, #0x10
    // 0x6e114c: cmp             w0, NULL
    // 0x6e1150: b.eq            #0x6e1168
    // 0x6e1154: tbnz            w0, #4, #0x6e1168
    // 0x6e1158: ldr             x16, [fp, #0x18]
    // 0x6e115c: SaveReg r16
    //     0x6e115c: str             x16, [SP, #-8]!
    // 0x6e1160: r0 = markNeedsPaint()
    //     0x6e1160: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6e1164: add             SP, SP, #8
    // 0x6e1168: r0 = Null
    //     0x6e1168: mov             x0, NULL
    // 0x6e116c: LeaveFrame
    //     0x6e116c: mov             SP, fp
    //     0x6e1170: ldp             fp, lr, [SP], #0x10
    // 0x6e1174: ret
    //     0x6e1174: ret             
    // 0x6e1178: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e1178: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e117c: b               #0x6e10a8
  }
  [closure] bool <anonymous closure>(dynamic, _SelectableFragment) {
    // ** addr: 0x6e1180, size: 0x3c
    // 0x6e1180: EnterFrame
    //     0x6e1180: stp             fp, lr, [SP, #-0x10]!
    //     0x6e1184: mov             fp, SP
    // 0x6e1188: ldr             x1, [fp, #0x10]
    // 0x6e118c: LoadField: r2 = r1->field_3b
    //     0x6e118c: ldur            w2, [x1, #0x3b]
    // 0x6e1190: DecompressPointer r2
    //     0x6e1190: add             x2, x2, HEAP, lsl #32
    // 0x6e1194: r16 = Sentinel
    //     0x6e1194: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6e1198: cmp             w2, w16
    // 0x6e119c: b.eq            #0x6e11b0
    // 0x6e11a0: r0 = false
    //     0x6e11a0: add             x0, NULL, #0x30  ; false
    // 0x6e11a4: LeaveFrame
    //     0x6e11a4: mov             SP, fp
    //     0x6e11a8: ldp             fp, lr, [SP], #0x10
    // 0x6e11ac: ret
    //     0x6e11ac: ret             
    // 0x6e11b0: r9 = _selectionGeometry
    //     0x6e11b0: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d3f0] Field <_SelectableFragment@507149678._selectionGeometry@507149678>: late (offset: 0x3c)
    //     0x6e11b4: ldr             x9, [x9, #0x3f0]
    // 0x6e11b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6e11b8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ registrar=(/* No info */) {
    // ** addr: 0x6e11bc, size: 0xc0
    // 0x6e11bc: EnterFrame
    //     0x6e11bc: stp             fp, lr, [SP, #-0x10]!
    //     0x6e11c0: mov             fp, SP
    // 0x6e11c4: CheckStackOverflow
    //     0x6e11c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e11c8: cmp             SP, x16
    //     0x6e11cc: b.ls            #0x6e1274
    // 0x6e11d0: ldr             x1, [fp, #0x18]
    // 0x6e11d4: LoadField: r0 = r1->field_7f
    //     0x6e11d4: ldur            w0, [x1, #0x7f]
    // 0x6e11d8: DecompressPointer r0
    //     0x6e11d8: add             x0, x0, HEAP, lsl #32
    // 0x6e11dc: ldr             x2, [fp, #0x10]
    // 0x6e11e0: r3 = LoadClassIdInstr(r2)
    //     0x6e11e0: ldur            x3, [x2, #-1]
    //     0x6e11e4: ubfx            x3, x3, #0xc, #0x14
    // 0x6e11e8: stp             x0, x2, [SP, #-0x10]!
    // 0x6e11ec: mov             x0, x3
    // 0x6e11f0: mov             lr, x0
    // 0x6e11f4: ldr             lr, [x21, lr, lsl #3]
    // 0x6e11f8: blr             lr
    // 0x6e11fc: add             SP, SP, #0x10
    // 0x6e1200: tbnz            w0, #4, #0x6e1214
    // 0x6e1204: r0 = Null
    //     0x6e1204: mov             x0, NULL
    // 0x6e1208: LeaveFrame
    //     0x6e1208: mov             SP, fp
    //     0x6e120c: ldp             fp, lr, [SP], #0x10
    // 0x6e1210: ret
    //     0x6e1210: ret             
    // 0x6e1214: ldr             x0, [fp, #0x18]
    // 0x6e1218: SaveReg r0
    //     0x6e1218: str             x0, [SP, #-8]!
    // 0x6e121c: r0 = _removeSelectionRegistrarSubscription()
    //     0x6e121c: bl              #0x65284c  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_removeSelectionRegistrarSubscription
    // 0x6e1220: add             SP, SP, #8
    // 0x6e1224: ldr             x16, [fp, #0x18]
    // 0x6e1228: SaveReg r16
    //     0x6e1228: str             x16, [SP, #-8]!
    // 0x6e122c: r0 = _disposeSelectableFragments()
    //     0x6e122c: bl              #0x6e16ec  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_disposeSelectableFragments
    // 0x6e1230: add             SP, SP, #8
    // 0x6e1234: ldr             x0, [fp, #0x10]
    // 0x6e1238: ldr             x1, [fp, #0x18]
    // 0x6e123c: StoreField: r1->field_7f = r0
    //     0x6e123c: stur            w0, [x1, #0x7f]
    //     0x6e1240: ldurb           w16, [x1, #-1]
    //     0x6e1244: ldurb           w17, [x0, #-1]
    //     0x6e1248: and             x16, x17, x16, lsr #2
    //     0x6e124c: tst             x16, HEAP, lsr #32
    //     0x6e1250: b.eq            #0x6e1258
    //     0x6e1254: bl              #0xd6826c
    // 0x6e1258: SaveReg r1
    //     0x6e1258: str             x1, [SP, #-8]!
    // 0x6e125c: r0 = _updateSelectionRegistrarSubscription()
    //     0x6e125c: bl              #0x6e127c  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_updateSelectionRegistrarSubscription
    // 0x6e1260: add             SP, SP, #8
    // 0x6e1264: r0 = Null
    //     0x6e1264: mov             x0, NULL
    // 0x6e1268: LeaveFrame
    //     0x6e1268: mov             SP, fp
    //     0x6e126c: ldp             fp, lr, [SP], #0x10
    // 0x6e1270: ret
    //     0x6e1270: ret             
    // 0x6e1274: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e1274: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e1278: b               #0x6e11d0
  }
  _ _updateSelectionRegistrarSubscription(/* No info */) {
    // ** addr: 0x6e127c, size: 0x1b0
    // 0x6e127c: EnterFrame
    //     0x6e127c: stp             fp, lr, [SP, #-0x10]!
    //     0x6e1280: mov             fp, SP
    // 0x6e1284: AllocStack(0x20)
    //     0x6e1284: sub             SP, SP, #0x20
    // 0x6e1288: CheckStackOverflow
    //     0x6e1288: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e128c: cmp             SP, x16
    //     0x6e1290: b.ls            #0x6e1410
    // 0x6e1294: ldr             x0, [fp, #0x10]
    // 0x6e1298: LoadField: r1 = r0->field_7f
    //     0x6e1298: ldur            w1, [x0, #0x7f]
    // 0x6e129c: DecompressPointer r1
    //     0x6e129c: add             x1, x1, HEAP, lsl #32
    // 0x6e12a0: cmp             w1, NULL
    // 0x6e12a4: b.ne            #0x6e12b8
    // 0x6e12a8: r0 = Null
    //     0x6e12a8: mov             x0, NULL
    // 0x6e12ac: LeaveFrame
    //     0x6e12ac: mov             SP, fp
    //     0x6e12b0: ldp             fp, lr, [SP], #0x10
    // 0x6e12b4: ret
    //     0x6e12b4: ret             
    // 0x6e12b8: LoadField: r1 = r0->field_7b
    //     0x6e12b8: ldur            w1, [x0, #0x7b]
    // 0x6e12bc: DecompressPointer r1
    //     0x6e12bc: add             x1, x1, HEAP, lsl #32
    // 0x6e12c0: cmp             w1, NULL
    // 0x6e12c4: b.ne            #0x6e12fc
    // 0x6e12c8: SaveReg r0
    //     0x6e12c8: str             x0, [SP, #-8]!
    // 0x6e12cc: r0 = _getSelectableFragments()
    //     0x6e12cc: bl              #0x6e142c  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_getSelectableFragments
    // 0x6e12d0: add             SP, SP, #8
    // 0x6e12d4: mov             x1, x0
    // 0x6e12d8: ldr             x2, [fp, #0x10]
    // 0x6e12dc: StoreField: r2->field_7b = r0
    //     0x6e12dc: stur            w0, [x2, #0x7b]
    //     0x6e12e0: ldurb           w16, [x2, #-1]
    //     0x6e12e4: ldurb           w17, [x0, #-1]
    //     0x6e12e8: and             x16, x17, x16, lsr #2
    //     0x6e12ec: tst             x16, HEAP, lsr #32
    //     0x6e12f0: b.eq            #0x6e12f8
    //     0x6e12f4: bl              #0xd6828c
    // 0x6e12f8: b               #0x6e1300
    // 0x6e12fc: mov             x2, x0
    // 0x6e1300: stur            x1, [fp, #-8]
    // 0x6e1304: LoadField: r0 = r2->field_7f
    //     0x6e1304: ldur            w0, [x2, #0x7f]
    // 0x6e1308: DecompressPointer r0
    //     0x6e1308: add             x0, x0, HEAP, lsl #32
    // 0x6e130c: cmp             w0, NULL
    // 0x6e1310: b.eq            #0x6e1418
    // 0x6e1314: r2 = LoadClassIdInstr(r0)
    //     0x6e1314: ldur            x2, [x0, #-1]
    //     0x6e1318: ubfx            x2, x2, #0xc, #0x14
    // 0x6e131c: SaveReg r0
    //     0x6e131c: str             x0, [SP, #-8]!
    // 0x6e1320: mov             x0, x2
    // 0x6e1324: r0 = GDT[cid_x0 + -0xff9]()
    //     0x6e1324: sub             lr, x0, #0xff9
    //     0x6e1328: ldr             lr, [x21, lr, lsl #3]
    //     0x6e132c: blr             lr
    // 0x6e1330: add             SP, SP, #8
    // 0x6e1334: mov             x3, x0
    // 0x6e1338: ldur            x2, [fp, #-8]
    // 0x6e133c: stur            x3, [fp, #-0x20]
    // 0x6e1340: LoadField: r4 = r2->field_b
    //     0x6e1340: ldur            w4, [x2, #0xb]
    // 0x6e1344: DecompressPointer r4
    //     0x6e1344: add             x4, x4, HEAP, lsl #32
    // 0x6e1348: stur            x4, [fp, #-0x18]
    // 0x6e134c: r0 = LoadInt32Instr(r4)
    //     0x6e134c: sbfx            x0, x4, #1, #0x1f
    // 0x6e1350: r5 = 0
    //     0x6e1350: mov             x5, #0
    // 0x6e1354: stur            x5, [fp, #-0x10]
    // 0x6e1358: CheckStackOverflow
    //     0x6e1358: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e135c: cmp             SP, x16
    //     0x6e1360: b.ls            #0x6e141c
    // 0x6e1364: cmp             x5, x0
    // 0x6e1368: b.ge            #0x6e13e4
    // 0x6e136c: mov             x1, x5
    // 0x6e1370: cmp             x1, x0
    // 0x6e1374: b.hs            #0x6e1424
    // 0x6e1378: LoadField: r0 = r2->field_f
    //     0x6e1378: ldur            w0, [x2, #0xf]
    // 0x6e137c: DecompressPointer r0
    //     0x6e137c: add             x0, x0, HEAP, lsl #32
    // 0x6e1380: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x6e1380: add             x16, x0, x5, lsl #2
    //     0x6e1384: ldur            w1, [x16, #0xf]
    // 0x6e1388: DecompressPointer r1
    //     0x6e1388: add             x1, x1, HEAP, lsl #32
    // 0x6e138c: cmp             w3, NULL
    // 0x6e1390: b.eq            #0x6e1428
    // 0x6e1394: stp             x1, x3, [SP, #-0x10]!
    // 0x6e1398: mov             x0, x3
    // 0x6e139c: ClosureCall
    //     0x6e139c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6e13a0: ldur            x2, [x0, #0x1f]
    //     0x6e13a4: blr             x2
    // 0x6e13a8: add             SP, SP, #0x10
    // 0x6e13ac: ldur            x0, [fp, #-8]
    // 0x6e13b0: LoadField: r1 = r0->field_b
    //     0x6e13b0: ldur            w1, [x0, #0xb]
    // 0x6e13b4: DecompressPointer r1
    //     0x6e13b4: add             x1, x1, HEAP, lsl #32
    // 0x6e13b8: ldur            x2, [fp, #-0x18]
    // 0x6e13bc: cmp             w1, w2
    // 0x6e13c0: b.ne            #0x6e13f4
    // 0x6e13c4: ldur            x3, [fp, #-0x10]
    // 0x6e13c8: add             x5, x3, #1
    // 0x6e13cc: r3 = LoadInt32Instr(r1)
    //     0x6e13cc: sbfx            x3, x1, #1, #0x1f
    // 0x6e13d0: mov             x4, x2
    // 0x6e13d4: mov             x2, x0
    // 0x6e13d8: mov             x0, x3
    // 0x6e13dc: ldur            x3, [fp, #-0x20]
    // 0x6e13e0: b               #0x6e1354
    // 0x6e13e4: r0 = Null
    //     0x6e13e4: mov             x0, NULL
    // 0x6e13e8: LeaveFrame
    //     0x6e13e8: mov             SP, fp
    //     0x6e13ec: ldp             fp, lr, [SP], #0x10
    // 0x6e13f0: ret
    //     0x6e13f0: ret             
    // 0x6e13f4: r0 = ConcurrentModificationError()
    //     0x6e13f4: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x6e13f8: mov             x1, x0
    // 0x6e13fc: ldur            x0, [fp, #-8]
    // 0x6e1400: StoreField: r1->field_b = r0
    //     0x6e1400: stur            w0, [x1, #0xb]
    // 0x6e1404: mov             x0, x1
    // 0x6e1408: r0 = Throw()
    //     0x6e1408: bl              #0xd67e38  ; ThrowStub
    // 0x6e140c: brk             #0
    // 0x6e1410: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e1410: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e1414: b               #0x6e1294
    // 0x6e1418: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6e1418: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6e141c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e141c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e1420: b               #0x6e1364
    // 0x6e1424: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6e1424: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6e1428: r0 = NullErrorSharedWithoutFPURegs()
    //     0x6e1428: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _getSelectableFragments(/* No info */) {
    // ** addr: 0x6e142c, size: 0x27c
    // 0x6e142c: EnterFrame
    //     0x6e142c: stp             fp, lr, [SP, #-0x10]!
    //     0x6e1430: mov             fp, SP
    // 0x6e1434: AllocStack(0x38)
    //     0x6e1434: sub             SP, SP, #0x38
    // 0x6e1438: CheckStackOverflow
    //     0x6e1438: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e143c: cmp             SP, x16
    //     0x6e1440: b.ls            #0x6e1694
    // 0x6e1444: ldr             x16, [fp, #0x10]
    // 0x6e1448: SaveReg r16
    //     0x6e1448: str             x16, [SP, #-8]!
    // 0x6e144c: r0 = text()
    //     0x6e144c: bl              #0x64da28  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::text
    // 0x6e1450: add             SP, SP, #8
    // 0x6e1454: SaveReg r0
    //     0x6e1454: str             x0, [SP, #-8]!
    // 0x6e1458: r0 = toPlainText()
    //     0x6e1458: bl              #0x521774  ; [package:flutter/src/painting/inline_span.dart] InlineSpan::toPlainText
    // 0x6e145c: add             SP, SP, #8
    // 0x6e1460: stur            x0, [fp, #-8]
    // 0x6e1464: r16 = <_SelectableFragment>
    //     0x6e1464: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d3f8] TypeArguments: <_SelectableFragment>
    //     0x6e1468: ldr             x16, [x16, #0x3f8]
    // 0x6e146c: stp             xzr, x16, [SP, #-0x10]!
    // 0x6e1470: r0 = _GrowableList()
    //     0x6e1470: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x6e1474: add             SP, SP, #0x10
    // 0x6e1478: mov             x1, x0
    // 0x6e147c: ldur            x0, [fp, #-8]
    // 0x6e1480: stur            x1, [fp, #-0x20]
    // 0x6e1484: LoadField: r2 = r0->field_7
    //     0x6e1484: ldur            w2, [x0, #7]
    // 0x6e1488: DecompressPointer r2
    //     0x6e1488: add             x2, x2, HEAP, lsl #32
    // 0x6e148c: r3 = LoadInt32Instr(r2)
    //     0x6e148c: sbfx            x3, x2, #1, #0x1f
    // 0x6e1490: stur            x3, [fp, #-0x18]
    // 0x6e1494: r4 = 0
    //     0x6e1494: mov             x4, #0
    // 0x6e1498: ldr             x2, [fp, #0x10]
    // 0x6e149c: stur            x4, [fp, #-0x10]
    // 0x6e14a0: CheckStackOverflow
    //     0x6e14a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e14a4: cmp             SP, x16
    //     0x6e14a8: b.ls            #0x6e169c
    // 0x6e14ac: cmp             x4, x3
    // 0x6e14b0: b.ge            #0x6e1680
    // 0x6e14b4: r0 = InitLateStaticField(0xc28) // [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_placeholderCharacter
    //     0x6e14b4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6e14b8: ldr             x0, [x0, #0x1850]
    //     0x6e14bc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6e14c0: cmp             w0, w16
    //     0x6e14c4: b.ne            #0x6e14d4
    //     0x6e14c8: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d400] Field <RenderParagraph._placeholderCharacter@507149678>: static late final (offset: 0xc28)
    //     0x6e14cc: ldr             x2, [x2, #0x400]
    //     0x6e14d0: bl              #0xd67cdc
    // 0x6e14d4: mov             x3, x0
    // 0x6e14d8: ldur            x2, [fp, #-0x10]
    // 0x6e14dc: r0 = BoxInt64Instr(r2)
    //     0x6e14dc: sbfiz           x0, x2, #1, #0x1f
    //     0x6e14e0: cmp             x2, x0, asr #1
    //     0x6e14e4: b.eq            #0x6e14f0
    //     0x6e14e8: bl              #0xd69bb8
    //     0x6e14ec: stur            x2, [x0, #7]
    // 0x6e14f0: ldur            x1, [fp, #-8]
    // 0x6e14f4: r4 = LoadClassIdInstr(r1)
    //     0x6e14f4: ldur            x4, [x1, #-1]
    //     0x6e14f8: ubfx            x4, x4, #0xc, #0x14
    // 0x6e14fc: stp             x3, x1, [SP, #-0x10]!
    // 0x6e1500: SaveReg r0
    //     0x6e1500: str             x0, [SP, #-8]!
    // 0x6e1504: mov             x0, x4
    // 0x6e1508: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x6e1508: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x6e150c: r0 = GDT[cid_x0 + -0xff0]()
    //     0x6e150c: sub             lr, x0, #0xff0
    //     0x6e1510: ldr             lr, [x21, lr, lsl #3]
    //     0x6e1514: blr             lr
    // 0x6e1518: add             SP, SP, #0x18
    // 0x6e151c: mov             x1, x0
    // 0x6e1520: ldur            x0, [fp, #-0x10]
    // 0x6e1524: cmp             x0, x1
    // 0x6e1528: b.eq            #0x6e1664
    // 0x6e152c: cmn             x1, #1
    // 0x6e1530: b.ne            #0x6e153c
    // 0x6e1534: ldur            x3, [fp, #-0x18]
    // 0x6e1538: b               #0x6e1540
    // 0x6e153c: mov             x3, x1
    // 0x6e1540: ldr             x2, [fp, #0x10]
    // 0x6e1544: ldur            x1, [fp, #-0x20]
    // 0x6e1548: stur            x3, [fp, #-0x28]
    // 0x6e154c: r0 = TextRange()
    //     0x6e154c: bl              #0x51026c  ; AllocateTextRangeStub -> TextRange (size=0x18)
    // 0x6e1550: mov             x1, x0
    // 0x6e1554: ldur            x0, [fp, #-0x10]
    // 0x6e1558: stur            x1, [fp, #-0x30]
    // 0x6e155c: StoreField: r1->field_7 = r0
    //     0x6e155c: stur            x0, [x1, #7]
    // 0x6e1560: ldur            x0, [fp, #-0x28]
    // 0x6e1564: StoreField: r1->field_f = r0
    //     0x6e1564: stur            x0, [x1, #0xf]
    // 0x6e1568: r0 = _SelectableFragment()
    //     0x6e1568: bl              #0x6e16a8  ; Allocate_SelectableFragmentStub -> _SelectableFragment (size=0x44)
    // 0x6e156c: mov             x1, x0
    // 0x6e1570: r0 = Sentinel
    //     0x6e1570: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6e1574: stur            x1, [fp, #-0x38]
    // 0x6e1578: StoreField: r1->field_3b = r0
    //     0x6e1578: stur            w0, [x1, #0x3b]
    // 0x6e157c: ldr             x2, [fp, #0x10]
    // 0x6e1580: StoreField: r1->field_27 = r2
    //     0x6e1580: stur            w2, [x1, #0x27]
    // 0x6e1584: ldur            x3, [fp, #-0x30]
    // 0x6e1588: StoreField: r1->field_23 = r3
    //     0x6e1588: stur            w3, [x1, #0x23]
    // 0x6e158c: r3 = 0
    //     0x6e158c: mov             x3, #0
    // 0x6e1590: StoreField: r1->field_7 = r3
    //     0x6e1590: stur            x3, [x1, #7]
    // 0x6e1594: StoreField: r1->field_13 = r3
    //     0x6e1594: stur            x3, [x1, #0x13]
    // 0x6e1598: StoreField: r1->field_1b = r3
    //     0x6e1598: stur            x3, [x1, #0x1b]
    // 0x6e159c: r0 = InitLateStaticField(0xac0) // [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_emptyListeners
    //     0x6e159c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6e15a0: ldr             x0, [x0, #0x1580]
    //     0x6e15a4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6e15a8: cmp             w0, w16
    //     0x6e15ac: b.ne            #0x6e15b8
    //     0x6e15b0: ldr             x2, [PP, #0x44a0]  ; [pp+0x44a0] Field <ChangeNotifier._emptyListeners@171329750>: static late final (offset: 0xac0)
    //     0x6e15b4: bl              #0xd67cdc
    // 0x6e15b8: mov             x1, x0
    // 0x6e15bc: ldur            x0, [fp, #-0x38]
    // 0x6e15c0: StoreField: r0->field_f = r1
    //     0x6e15c0: stur            w1, [x0, #0xf]
    // 0x6e15c4: r1 = Instance_SelectionGeometry
    //     0x6e15c4: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d408] Obj!SelectionGeometry@b352f1
    //     0x6e15c8: ldr             x1, [x1, #0x408]
    // 0x6e15cc: StoreField: r0->field_3b = r1
    //     0x6e15cc: stur            w1, [x0, #0x3b]
    // 0x6e15d0: ldur            x2, [fp, #-0x20]
    // 0x6e15d4: LoadField: r3 = r2->field_b
    //     0x6e15d4: ldur            w3, [x2, #0xb]
    // 0x6e15d8: DecompressPointer r3
    //     0x6e15d8: add             x3, x3, HEAP, lsl #32
    // 0x6e15dc: stur            x3, [fp, #-0x30]
    // 0x6e15e0: LoadField: r4 = r2->field_f
    //     0x6e15e0: ldur            w4, [x2, #0xf]
    // 0x6e15e4: DecompressPointer r4
    //     0x6e15e4: add             x4, x4, HEAP, lsl #32
    // 0x6e15e8: LoadField: r5 = r4->field_b
    //     0x6e15e8: ldur            w5, [x4, #0xb]
    // 0x6e15ec: DecompressPointer r5
    //     0x6e15ec: add             x5, x5, HEAP, lsl #32
    // 0x6e15f0: cmp             w3, w5
    // 0x6e15f4: b.ne            #0x6e1604
    // 0x6e15f8: SaveReg r2
    //     0x6e15f8: str             x2, [SP, #-8]!
    // 0x6e15fc: r0 = _growToNextCapacity()
    //     0x6e15fc: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6e1600: add             SP, SP, #8
    // 0x6e1604: ldur            x2, [fp, #-0x20]
    // 0x6e1608: ldur            x3, [fp, #-0x30]
    // 0x6e160c: r4 = LoadInt32Instr(r3)
    //     0x6e160c: sbfx            x4, x3, #1, #0x1f
    // 0x6e1610: add             x0, x4, #1
    // 0x6e1614: lsl             x3, x0, #1
    // 0x6e1618: StoreField: r2->field_b = r3
    //     0x6e1618: stur            w3, [x2, #0xb]
    // 0x6e161c: mov             x1, x4
    // 0x6e1620: cmp             x1, x0
    // 0x6e1624: b.hs            #0x6e16a4
    // 0x6e1628: LoadField: r1 = r2->field_f
    //     0x6e1628: ldur            w1, [x2, #0xf]
    // 0x6e162c: DecompressPointer r1
    //     0x6e162c: add             x1, x1, HEAP, lsl #32
    // 0x6e1630: ldur            x0, [fp, #-0x38]
    // 0x6e1634: ArrayStore: r1[r4] = r0  ; List_4
    //     0x6e1634: add             x25, x1, x4, lsl #2
    //     0x6e1638: add             x25, x25, #0xf
    //     0x6e163c: str             w0, [x25]
    //     0x6e1640: tbz             w0, #0, #0x6e165c
    //     0x6e1644: ldurb           w16, [x1, #-1]
    //     0x6e1648: ldurb           w17, [x0, #-1]
    //     0x6e164c: and             x16, x17, x16, lsr #2
    //     0x6e1650: tst             x16, HEAP, lsr #32
    //     0x6e1654: b.eq            #0x6e165c
    //     0x6e1658: bl              #0xd67e5c
    // 0x6e165c: ldur            x1, [fp, #-0x28]
    // 0x6e1660: b               #0x6e166c
    // 0x6e1664: ldur            x2, [fp, #-0x20]
    // 0x6e1668: mov             x1, x0
    // 0x6e166c: add             x4, x1, #1
    // 0x6e1670: ldur            x0, [fp, #-8]
    // 0x6e1674: mov             x1, x2
    // 0x6e1678: ldur            x3, [fp, #-0x18]
    // 0x6e167c: b               #0x6e1498
    // 0x6e1680: mov             x2, x1
    // 0x6e1684: mov             x0, x2
    // 0x6e1688: LeaveFrame
    //     0x6e1688: mov             SP, fp
    //     0x6e168c: ldp             fp, lr, [SP], #0x10
    // 0x6e1690: ret
    //     0x6e1690: ret             
    // 0x6e1694: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e1694: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e1698: b               #0x6e1444
    // 0x6e169c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e169c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e16a0: b               #0x6e14ac
    // 0x6e16a4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6e16a4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  static String _placeholderCharacter() {
    // ** addr: 0x6e16b4, size: 0x38
    // 0x6e16b4: EnterFrame
    //     0x6e16b4: stp             fp, lr, [SP, #-0x10]!
    //     0x6e16b8: mov             fp, SP
    // 0x6e16bc: r0 = 65532
    //     0x6e16bc: mov             x0, #0xfffc
    // 0x6e16c0: CheckStackOverflow
    //     0x6e16c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e16c4: cmp             SP, x16
    //     0x6e16c8: b.ls            #0x6e16e4
    // 0x6e16cc: stp             x0, NULL, [SP, #-0x10]!
    // 0x6e16d0: r0 = String.fromCharCode()
    //     0x6e16d0: bl              #0x4d316c  ; [dart:core] String::String.fromCharCode
    // 0x6e16d4: add             SP, SP, #0x10
    // 0x6e16d8: LeaveFrame
    //     0x6e16d8: mov             SP, fp
    //     0x6e16dc: ldp             fp, lr, [SP], #0x10
    // 0x6e16e0: ret
    //     0x6e16e0: ret             
    // 0x6e16e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e16e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e16e8: b               #0x6e16cc
  }
  _ _disposeSelectableFragments(/* No info */) {
    // ** addr: 0x6e16ec, size: 0x1e0
    // 0x6e16ec: EnterFrame
    //     0x6e16ec: stp             fp, lr, [SP, #-0x10]!
    //     0x6e16f0: mov             fp, SP
    // 0x6e16f4: AllocStack(0x30)
    //     0x6e16f4: sub             SP, SP, #0x30
    // 0x6e16f8: CheckStackOverflow
    //     0x6e16f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e16fc: cmp             SP, x16
    //     0x6e1700: b.ls            #0x6e18bc
    // 0x6e1704: ldr             x1, [fp, #0x10]
    // 0x6e1708: LoadField: r2 = r1->field_7b
    //     0x6e1708: ldur            w2, [x1, #0x7b]
    // 0x6e170c: DecompressPointer r2
    //     0x6e170c: add             x2, x2, HEAP, lsl #32
    // 0x6e1710: stur            x2, [fp, #-0x20]
    // 0x6e1714: cmp             w2, NULL
    // 0x6e1718: b.ne            #0x6e172c
    // 0x6e171c: r0 = Null
    //     0x6e171c: mov             x0, NULL
    // 0x6e1720: LeaveFrame
    //     0x6e1720: mov             SP, fp
    //     0x6e1724: ldp             fp, lr, [SP], #0x10
    // 0x6e1728: ret
    //     0x6e1728: ret             
    // 0x6e172c: LoadField: r3 = r2->field_7
    //     0x6e172c: ldur            w3, [x2, #7]
    // 0x6e1730: DecompressPointer r3
    //     0x6e1730: add             x3, x3, HEAP, lsl #32
    // 0x6e1734: stur            x3, [fp, #-0x18]
    // 0x6e1738: LoadField: r0 = r2->field_b
    //     0x6e1738: ldur            w0, [x2, #0xb]
    // 0x6e173c: DecompressPointer r0
    //     0x6e173c: add             x0, x0, HEAP, lsl #32
    // 0x6e1740: r4 = LoadInt32Instr(r0)
    //     0x6e1740: sbfx            x4, x0, #1, #0x1f
    // 0x6e1744: stur            x4, [fp, #-0x10]
    // 0x6e1748: r5 = 0
    //     0x6e1748: mov             x5, #0
    // 0x6e174c: stur            x5, [fp, #-8]
    // 0x6e1750: CheckStackOverflow
    //     0x6e1750: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e1754: cmp             SP, x16
    //     0x6e1758: b.ls            #0x6e18c4
    // 0x6e175c: r0 = LoadClassIdInstr(r2)
    //     0x6e175c: ldur            x0, [x2, #-1]
    //     0x6e1760: ubfx            x0, x0, #0xc, #0x14
    // 0x6e1764: SaveReg r2
    //     0x6e1764: str             x2, [SP, #-8]!
    // 0x6e1768: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x6e1768: mov             x17, #0xb8ea
    //     0x6e176c: add             lr, x0, x17
    //     0x6e1770: ldr             lr, [x21, lr, lsl #3]
    //     0x6e1774: blr             lr
    // 0x6e1778: add             SP, SP, #8
    // 0x6e177c: r1 = LoadInt32Instr(r0)
    //     0x6e177c: sbfx            x1, x0, #1, #0x1f
    //     0x6e1780: tbz             w0, #0, #0x6e1788
    //     0x6e1784: ldur            x1, [x0, #7]
    // 0x6e1788: ldur            x2, [fp, #-0x10]
    // 0x6e178c: cmp             x2, x1
    // 0x6e1790: b.ne            #0x6e18a4
    // 0x6e1794: ldur            x3, [fp, #-0x20]
    // 0x6e1798: ldur            x4, [fp, #-8]
    // 0x6e179c: cmp             x4, x1
    // 0x6e17a0: b.lt            #0x6e17bc
    // 0x6e17a4: ldr             x5, [fp, #0x10]
    // 0x6e17a8: StoreField: r5->field_7b = rNULL
    //     0x6e17a8: stur            NULL, [x5, #0x7b]
    // 0x6e17ac: r0 = Null
    //     0x6e17ac: mov             x0, NULL
    // 0x6e17b0: LeaveFrame
    //     0x6e17b0: mov             SP, fp
    //     0x6e17b4: ldp             fp, lr, [SP], #0x10
    // 0x6e17b8: ret
    //     0x6e17b8: ret             
    // 0x6e17bc: ldr             x5, [fp, #0x10]
    // 0x6e17c0: r0 = BoxInt64Instr(r4)
    //     0x6e17c0: sbfiz           x0, x4, #1, #0x1f
    //     0x6e17c4: cmp             x4, x0, asr #1
    //     0x6e17c8: b.eq            #0x6e17d4
    //     0x6e17cc: bl              #0xd69bb8
    //     0x6e17d0: stur            x4, [x0, #7]
    // 0x6e17d4: r1 = LoadClassIdInstr(r3)
    //     0x6e17d4: ldur            x1, [x3, #-1]
    //     0x6e17d8: ubfx            x1, x1, #0xc, #0x14
    // 0x6e17dc: stp             x0, x3, [SP, #-0x10]!
    // 0x6e17e0: mov             x0, x1
    // 0x6e17e4: r0 = GDT[cid_x0 + 0xd175]()
    //     0x6e17e4: mov             x17, #0xd175
    //     0x6e17e8: add             lr, x0, x17
    //     0x6e17ec: ldr             lr, [x21, lr, lsl #3]
    //     0x6e17f0: blr             lr
    // 0x6e17f4: add             SP, SP, #0x10
    // 0x6e17f8: mov             x3, x0
    // 0x6e17fc: ldur            x0, [fp, #-8]
    // 0x6e1800: stur            x3, [fp, #-0x30]
    // 0x6e1804: add             x5, x0, #1
    // 0x6e1808: stur            x5, [fp, #-0x28]
    // 0x6e180c: cmp             w3, NULL
    // 0x6e1810: b.ne            #0x6e1844
    // 0x6e1814: mov             x0, x3
    // 0x6e1818: ldur            x2, [fp, #-0x18]
    // 0x6e181c: r1 = Null
    //     0x6e181c: mov             x1, NULL
    // 0x6e1820: cmp             w2, NULL
    // 0x6e1824: b.eq            #0x6e1844
    // 0x6e1828: LoadField: r4 = r2->field_17
    //     0x6e1828: ldur            w4, [x2, #0x17]
    // 0x6e182c: DecompressPointer r4
    //     0x6e182c: add             x4, x4, HEAP, lsl #32
    // 0x6e1830: r8 = X0
    //     0x6e1830: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6e1834: LoadField: r9 = r4->field_7
    //     0x6e1834: ldur            x9, [x4, #7]
    // 0x6e1838: r3 = Null
    //     0x6e1838: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d418] Null
    //     0x6e183c: ldr             x3, [x3, #0x418]
    // 0x6e1840: blr             x9
    // 0x6e1844: ldur            x0, [fp, #-0x30]
    // 0x6e1848: r0 = InitLateStaticField(0xac0) // [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_emptyListeners
    //     0x6e1848: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6e184c: ldr             x0, [x0, #0x1580]
    //     0x6e1850: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6e1854: cmp             w0, w16
    //     0x6e1858: b.ne            #0x6e1864
    //     0x6e185c: ldr             x2, [PP, #0x44a0]  ; [pp+0x44a0] Field <ChangeNotifier._emptyListeners@171329750>: static late final (offset: 0xac0)
    //     0x6e1860: bl              #0xd67cdc
    // 0x6e1864: ldur            x1, [fp, #-0x30]
    // 0x6e1868: StoreField: r1->field_f = r0
    //     0x6e1868: stur            w0, [x1, #0xf]
    //     0x6e186c: ldurb           w16, [x1, #-1]
    //     0x6e1870: ldurb           w17, [x0, #-1]
    //     0x6e1874: and             x16, x17, x16, lsr #2
    //     0x6e1878: tst             x16, HEAP, lsr #32
    //     0x6e187c: b.eq            #0x6e1884
    //     0x6e1880: bl              #0xd6826c
    // 0x6e1884: r0 = 0
    //     0x6e1884: mov             x0, #0
    // 0x6e1888: StoreField: r1->field_7 = r0
    //     0x6e1888: stur            x0, [x1, #7]
    // 0x6e188c: ldur            x5, [fp, #-0x28]
    // 0x6e1890: ldr             x1, [fp, #0x10]
    // 0x6e1894: ldur            x2, [fp, #-0x20]
    // 0x6e1898: ldur            x3, [fp, #-0x18]
    // 0x6e189c: ldur            x4, [fp, #-0x10]
    // 0x6e18a0: b               #0x6e174c
    // 0x6e18a4: ldur            x0, [fp, #-0x20]
    // 0x6e18a8: r0 = ConcurrentModificationError()
    //     0x6e18a8: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x6e18ac: ldur            x3, [fp, #-0x20]
    // 0x6e18b0: StoreField: r0->field_b = r3
    //     0x6e18b0: stur            w3, [x0, #0xb]
    // 0x6e18b4: r0 = Throw()
    //     0x6e18b4: bl              #0xd67e38  ; ThrowStub
    // 0x6e18b8: brk             #0
    // 0x6e18bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e18bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e18c0: b               #0x6e1704
    // 0x6e18c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e18c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e18c8: b               #0x6e175c
  }
  set _ locale=(/* No info */) {
    // ** addr: 0x6e18cc, size: 0xac
    // 0x6e18cc: EnterFrame
    //     0x6e18cc: stp             fp, lr, [SP, #-0x10]!
    //     0x6e18d0: mov             fp, SP
    // 0x6e18d4: AllocStack(0x8)
    //     0x6e18d4: sub             SP, SP, #8
    // 0x6e18d8: CheckStackOverflow
    //     0x6e18d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e18dc: cmp             SP, x16
    //     0x6e18e0: b.ls            #0x6e1970
    // 0x6e18e4: ldr             x1, [fp, #0x18]
    // 0x6e18e8: LoadField: r2 = r1->field_6f
    //     0x6e18e8: ldur            w2, [x1, #0x6f]
    // 0x6e18ec: DecompressPointer r2
    //     0x6e18ec: add             x2, x2, HEAP, lsl #32
    // 0x6e18f0: stur            x2, [fp, #-8]
    // 0x6e18f4: LoadField: r0 = r2->field_2b
    //     0x6e18f4: ldur            w0, [x2, #0x2b]
    // 0x6e18f8: DecompressPointer r0
    //     0x6e18f8: add             x0, x0, HEAP, lsl #32
    // 0x6e18fc: r3 = LoadClassIdInstr(r0)
    //     0x6e18fc: ldur            x3, [x0, #-1]
    //     0x6e1900: ubfx            x3, x3, #0xc, #0x14
    // 0x6e1904: ldr             x16, [fp, #0x10]
    // 0x6e1908: stp             x16, x0, [SP, #-0x10]!
    // 0x6e190c: mov             x0, x3
    // 0x6e1910: mov             lr, x0
    // 0x6e1914: ldr             lr, [x21, lr, lsl #3]
    // 0x6e1918: blr             lr
    // 0x6e191c: add             SP, SP, #0x10
    // 0x6e1920: tbnz            w0, #4, #0x6e1934
    // 0x6e1924: r0 = Null
    //     0x6e1924: mov             x0, NULL
    // 0x6e1928: LeaveFrame
    //     0x6e1928: mov             SP, fp
    //     0x6e192c: ldp             fp, lr, [SP], #0x10
    // 0x6e1930: ret
    //     0x6e1930: ret             
    // 0x6e1934: ldr             x0, [fp, #0x18]
    // 0x6e1938: ldur            x16, [fp, #-8]
    // 0x6e193c: ldr             lr, [fp, #0x10]
    // 0x6e1940: stp             lr, x16, [SP, #-0x10]!
    // 0x6e1944: r0 = locale=()
    //     0x6e1944: bl              #0x6df43c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::locale=
    // 0x6e1948: add             SP, SP, #0x10
    // 0x6e194c: ldr             x0, [fp, #0x18]
    // 0x6e1950: StoreField: r0->field_97 = rNULL
    //     0x6e1950: stur            NULL, [x0, #0x97]
    // 0x6e1954: SaveReg r0
    //     0x6e1954: str             x0, [SP, #-8]!
    // 0x6e1958: r0 = markNeedsLayout()
    //     0x6e1958: bl              #0x6c0c74  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::markNeedsLayout
    // 0x6e195c: add             SP, SP, #8
    // 0x6e1960: r0 = Null
    //     0x6e1960: mov             x0, NULL
    // 0x6e1964: LeaveFrame
    //     0x6e1964: mov             SP, fp
    //     0x6e1968: ldp             fp, lr, [SP], #0x10
    // 0x6e196c: ret
    //     0x6e196c: ret             
    // 0x6e1970: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e1970: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e1974: b               #0x6e18e4
  }
  set _ strutStyle=(/* No info */) {
    // ** addr: 0x6e1978, size: 0xac
    // 0x6e1978: EnterFrame
    //     0x6e1978: stp             fp, lr, [SP, #-0x10]!
    //     0x6e197c: mov             fp, SP
    // 0x6e1980: AllocStack(0x8)
    //     0x6e1980: sub             SP, SP, #8
    // 0x6e1984: CheckStackOverflow
    //     0x6e1984: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e1988: cmp             SP, x16
    //     0x6e198c: b.ls            #0x6e1a1c
    // 0x6e1990: ldr             x1, [fp, #0x18]
    // 0x6e1994: LoadField: r2 = r1->field_6f
    //     0x6e1994: ldur            w2, [x1, #0x6f]
    // 0x6e1998: DecompressPointer r2
    //     0x6e1998: add             x2, x2, HEAP, lsl #32
    // 0x6e199c: stur            x2, [fp, #-8]
    // 0x6e19a0: LoadField: r0 = r2->field_33
    //     0x6e19a0: ldur            w0, [x2, #0x33]
    // 0x6e19a4: DecompressPointer r0
    //     0x6e19a4: add             x0, x0, HEAP, lsl #32
    // 0x6e19a8: r3 = LoadClassIdInstr(r0)
    //     0x6e19a8: ldur            x3, [x0, #-1]
    //     0x6e19ac: ubfx            x3, x3, #0xc, #0x14
    // 0x6e19b0: ldr             x16, [fp, #0x10]
    // 0x6e19b4: stp             x16, x0, [SP, #-0x10]!
    // 0x6e19b8: mov             x0, x3
    // 0x6e19bc: mov             lr, x0
    // 0x6e19c0: ldr             lr, [x21, lr, lsl #3]
    // 0x6e19c4: blr             lr
    // 0x6e19c8: add             SP, SP, #0x10
    // 0x6e19cc: tbnz            w0, #4, #0x6e19e0
    // 0x6e19d0: r0 = Null
    //     0x6e19d0: mov             x0, NULL
    // 0x6e19d4: LeaveFrame
    //     0x6e19d4: mov             SP, fp
    //     0x6e19d8: ldp             fp, lr, [SP], #0x10
    // 0x6e19dc: ret
    //     0x6e19dc: ret             
    // 0x6e19e0: ldr             x0, [fp, #0x18]
    // 0x6e19e4: ldur            x16, [fp, #-8]
    // 0x6e19e8: ldr             lr, [fp, #0x10]
    // 0x6e19ec: stp             lr, x16, [SP, #-0x10]!
    // 0x6e19f0: r0 = strutStyle=()
    //     0x6e19f0: bl              #0x6df878  ; [package:flutter/src/painting/text_painter.dart] TextPainter::strutStyle=
    // 0x6e19f4: add             SP, SP, #0x10
    // 0x6e19f8: ldr             x0, [fp, #0x18]
    // 0x6e19fc: StoreField: r0->field_97 = rNULL
    //     0x6e19fc: stur            NULL, [x0, #0x97]
    // 0x6e1a00: SaveReg r0
    //     0x6e1a00: str             x0, [SP, #-8]!
    // 0x6e1a04: r0 = markNeedsLayout()
    //     0x6e1a04: bl              #0x6c0c74  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::markNeedsLayout
    // 0x6e1a08: add             SP, SP, #8
    // 0x6e1a0c: r0 = Null
    //     0x6e1a0c: mov             x0, NULL
    // 0x6e1a10: LeaveFrame
    //     0x6e1a10: mov             SP, fp
    //     0x6e1a14: ldp             fp, lr, [SP], #0x10
    // 0x6e1a18: ret
    //     0x6e1a18: ret             
    // 0x6e1a1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e1a1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e1a20: b               #0x6e1990
  }
  set _ maxLines=(/* No info */) {
    // ** addr: 0x6e1a24, size: 0xb4
    // 0x6e1a24: EnterFrame
    //     0x6e1a24: stp             fp, lr, [SP, #-0x10]!
    //     0x6e1a28: mov             fp, SP
    // 0x6e1a2c: CheckStackOverflow
    //     0x6e1a2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e1a30: cmp             SP, x16
    //     0x6e1a34: b.ls            #0x6e1ad0
    // 0x6e1a38: ldr             x0, [fp, #0x18]
    // 0x6e1a3c: LoadField: r1 = r0->field_6f
    //     0x6e1a3c: ldur            w1, [x0, #0x6f]
    // 0x6e1a40: DecompressPointer r1
    //     0x6e1a40: add             x1, x1, HEAP, lsl #32
    // 0x6e1a44: LoadField: r2 = r1->field_2f
    //     0x6e1a44: ldur            w2, [x1, #0x2f]
    // 0x6e1a48: DecompressPointer r2
    //     0x6e1a48: add             x2, x2, HEAP, lsl #32
    // 0x6e1a4c: ldr             x3, [fp, #0x10]
    // 0x6e1a50: cmp             w2, w3
    // 0x6e1a54: b.eq            #0x6e1a90
    // 0x6e1a58: and             w16, w2, w3
    // 0x6e1a5c: branchIfSmi(r16, 0x6e1aa0)
    //     0x6e1a5c: tbz             w16, #0, #0x6e1aa0
    // 0x6e1a60: r16 = LoadClassIdInstr(r2)
    //     0x6e1a60: ldur            x16, [x2, #-1]
    //     0x6e1a64: ubfx            x16, x16, #0xc, #0x14
    // 0x6e1a68: cmp             x16, #0x3c
    // 0x6e1a6c: b.ne            #0x6e1aa0
    // 0x6e1a70: r16 = LoadClassIdInstr(r3)
    //     0x6e1a70: ldur            x16, [x3, #-1]
    //     0x6e1a74: ubfx            x16, x16, #0xc, #0x14
    // 0x6e1a78: cmp             x16, #0x3c
    // 0x6e1a7c: b.ne            #0x6e1aa0
    // 0x6e1a80: LoadField: r16 = r2->field_7
    //     0x6e1a80: ldur            x16, [x2, #7]
    // 0x6e1a84: LoadField: r17 = r3->field_7
    //     0x6e1a84: ldur            x17, [x3, #7]
    // 0x6e1a88: cmp             x16, x17
    // 0x6e1a8c: b.ne            #0x6e1aa0
    // 0x6e1a90: r0 = Null
    //     0x6e1a90: mov             x0, NULL
    // 0x6e1a94: LeaveFrame
    //     0x6e1a94: mov             SP, fp
    //     0x6e1a98: ldp             fp, lr, [SP], #0x10
    // 0x6e1a9c: ret
    //     0x6e1a9c: ret             
    // 0x6e1aa0: stp             x3, x1, [SP, #-0x10]!
    // 0x6e1aa4: r0 = maxLines=()
    //     0x6e1aa4: bl              #0x6e1ad8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::maxLines=
    // 0x6e1aa8: add             SP, SP, #0x10
    // 0x6e1aac: ldr             x0, [fp, #0x18]
    // 0x6e1ab0: StoreField: r0->field_97 = rNULL
    //     0x6e1ab0: stur            NULL, [x0, #0x97]
    // 0x6e1ab4: SaveReg r0
    //     0x6e1ab4: str             x0, [SP, #-8]!
    // 0x6e1ab8: r0 = markNeedsLayout()
    //     0x6e1ab8: bl              #0x6c0c74  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::markNeedsLayout
    // 0x6e1abc: add             SP, SP, #8
    // 0x6e1ac0: r0 = Null
    //     0x6e1ac0: mov             x0, NULL
    // 0x6e1ac4: LeaveFrame
    //     0x6e1ac4: mov             SP, fp
    //     0x6e1ac8: ldp             fp, lr, [SP], #0x10
    // 0x6e1acc: ret
    //     0x6e1acc: ret             
    // 0x6e1ad0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e1ad0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e1ad4: b               #0x6e1a38
  }
  set _ textScaleFactor=(/* No info */) {
    // ** addr: 0x6e1b94, size: 0x80
    // 0x6e1b94: EnterFrame
    //     0x6e1b94: stp             fp, lr, [SP, #-0x10]!
    //     0x6e1b98: mov             fp, SP
    // 0x6e1b9c: CheckStackOverflow
    //     0x6e1b9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e1ba0: cmp             SP, x16
    //     0x6e1ba4: b.ls            #0x6e1c0c
    // 0x6e1ba8: ldr             x0, [fp, #0x18]
    // 0x6e1bac: LoadField: r1 = r0->field_6f
    //     0x6e1bac: ldur            w1, [x0, #0x6f]
    // 0x6e1bb0: DecompressPointer r1
    //     0x6e1bb0: add             x1, x1, HEAP, lsl #32
    // 0x6e1bb4: LoadField: d0 = r1->field_1f
    //     0x6e1bb4: ldur            d0, [x1, #0x1f]
    // 0x6e1bb8: ldr             d1, [fp, #0x10]
    // 0x6e1bbc: fcmp            d0, d1
    // 0x6e1bc0: b.vs            #0x6e1bd8
    // 0x6e1bc4: b.ne            #0x6e1bd8
    // 0x6e1bc8: r0 = Null
    //     0x6e1bc8: mov             x0, NULL
    // 0x6e1bcc: LeaveFrame
    //     0x6e1bcc: mov             SP, fp
    //     0x6e1bd0: ldp             fp, lr, [SP], #0x10
    // 0x6e1bd4: ret
    //     0x6e1bd4: ret             
    // 0x6e1bd8: SaveReg r1
    //     0x6e1bd8: str             x1, [SP, #-8]!
    // 0x6e1bdc: SaveReg d1
    //     0x6e1bdc: str             d1, [SP, #-8]!
    // 0x6e1be0: r0 = textScaleFactor=()
    //     0x6e1be0: bl              #0x6df6f8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::textScaleFactor=
    // 0x6e1be4: add             SP, SP, #0x10
    // 0x6e1be8: ldr             x0, [fp, #0x18]
    // 0x6e1bec: StoreField: r0->field_97 = rNULL
    //     0x6e1bec: stur            NULL, [x0, #0x97]
    // 0x6e1bf0: SaveReg r0
    //     0x6e1bf0: str             x0, [SP, #-8]!
    // 0x6e1bf4: r0 = markNeedsLayout()
    //     0x6e1bf4: bl              #0x6c0c74  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::markNeedsLayout
    // 0x6e1bf8: add             SP, SP, #8
    // 0x6e1bfc: r0 = Null
    //     0x6e1bfc: mov             x0, NULL
    // 0x6e1c00: LeaveFrame
    //     0x6e1c00: mov             SP, fp
    //     0x6e1c04: ldp             fp, lr, [SP], #0x10
    // 0x6e1c08: ret
    //     0x6e1c08: ret             
    // 0x6e1c0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e1c0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e1c10: b               #0x6e1ba8
  }
  set _ overflow=(/* No info */) {
    // ** addr: 0x6e1c14, size: 0xb8
    // 0x6e1c14: EnterFrame
    //     0x6e1c14: stp             fp, lr, [SP, #-0x10]!
    //     0x6e1c18: mov             fp, SP
    // 0x6e1c1c: CheckStackOverflow
    //     0x6e1c1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e1c20: cmp             SP, x16
    //     0x6e1c24: b.ls            #0x6e1cc4
    // 0x6e1c28: ldr             x1, [fp, #0x18]
    // 0x6e1c2c: LoadField: r0 = r1->field_8b
    //     0x6e1c2c: ldur            w0, [x1, #0x8b]
    // 0x6e1c30: DecompressPointer r0
    //     0x6e1c30: add             x0, x0, HEAP, lsl #32
    // 0x6e1c34: ldr             x2, [fp, #0x10]
    // 0x6e1c38: cmp             w0, w2
    // 0x6e1c3c: b.ne            #0x6e1c50
    // 0x6e1c40: r0 = Null
    //     0x6e1c40: mov             x0, NULL
    // 0x6e1c44: LeaveFrame
    //     0x6e1c44: mov             SP, fp
    //     0x6e1c48: ldp             fp, lr, [SP], #0x10
    // 0x6e1c4c: ret
    //     0x6e1c4c: ret             
    // 0x6e1c50: mov             x0, x2
    // 0x6e1c54: StoreField: r1->field_8b = r0
    //     0x6e1c54: stur            w0, [x1, #0x8b]
    //     0x6e1c58: ldurb           w16, [x1, #-1]
    //     0x6e1c5c: ldurb           w17, [x0, #-1]
    //     0x6e1c60: and             x16, x17, x16, lsr #2
    //     0x6e1c64: tst             x16, HEAP, lsr #32
    //     0x6e1c68: b.eq            #0x6e1c70
    //     0x6e1c6c: bl              #0xd6826c
    // 0x6e1c70: LoadField: r0 = r1->field_6f
    //     0x6e1c70: ldur            w0, [x1, #0x6f]
    // 0x6e1c74: DecompressPointer r0
    //     0x6e1c74: add             x0, x0, HEAP, lsl #32
    // 0x6e1c78: r16 = Instance_TextOverflow
    //     0x6e1c78: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d428] Obj!TextOverflow@b64d51
    //     0x6e1c7c: ldr             x16, [x16, #0x428]
    // 0x6e1c80: cmp             w2, w16
    // 0x6e1c84: b.ne            #0x6e1c94
    // 0x6e1c88: r2 = "…"
    //     0x6e1c88: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d430] "…"
    //     0x6e1c8c: ldr             x2, [x2, #0x430]
    // 0x6e1c90: b               #0x6e1c98
    // 0x6e1c94: r2 = Null
    //     0x6e1c94: mov             x2, NULL
    // 0x6e1c98: stp             x2, x0, [SP, #-0x10]!
    // 0x6e1c9c: r0 = ellipsis=()
    //     0x6e1c9c: bl              #0x6e1ccc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::ellipsis=
    // 0x6e1ca0: add             SP, SP, #0x10
    // 0x6e1ca4: ldr             x16, [fp, #0x18]
    // 0x6e1ca8: SaveReg r16
    //     0x6e1ca8: str             x16, [SP, #-8]!
    // 0x6e1cac: r0 = markNeedsLayout()
    //     0x6e1cac: bl              #0x6c0c74  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::markNeedsLayout
    // 0x6e1cb0: add             SP, SP, #8
    // 0x6e1cb4: r0 = Null
    //     0x6e1cb4: mov             x0, NULL
    // 0x6e1cb8: LeaveFrame
    //     0x6e1cb8: mov             SP, fp
    //     0x6e1cbc: ldp             fp, lr, [SP], #0x10
    // 0x6e1cc0: ret
    //     0x6e1cc0: ret             
    // 0x6e1cc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e1cc4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e1cc8: b               #0x6e1c28
  }
  set _ softWrap=(/* No info */) {
    // ** addr: 0x6e1d6c, size: 0x64
    // 0x6e1d6c: EnterFrame
    //     0x6e1d6c: stp             fp, lr, [SP, #-0x10]!
    //     0x6e1d70: mov             fp, SP
    // 0x6e1d74: CheckStackOverflow
    //     0x6e1d74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e1d78: cmp             SP, x16
    //     0x6e1d7c: b.ls            #0x6e1dc8
    // 0x6e1d80: ldr             x0, [fp, #0x18]
    // 0x6e1d84: LoadField: r1 = r0->field_87
    //     0x6e1d84: ldur            w1, [x0, #0x87]
    // 0x6e1d88: DecompressPointer r1
    //     0x6e1d88: add             x1, x1, HEAP, lsl #32
    // 0x6e1d8c: ldr             x2, [fp, #0x10]
    // 0x6e1d90: cmp             w1, w2
    // 0x6e1d94: b.ne            #0x6e1da8
    // 0x6e1d98: r0 = Null
    //     0x6e1d98: mov             x0, NULL
    // 0x6e1d9c: LeaveFrame
    //     0x6e1d9c: mov             SP, fp
    //     0x6e1da0: ldp             fp, lr, [SP], #0x10
    // 0x6e1da4: ret
    //     0x6e1da4: ret             
    // 0x6e1da8: StoreField: r0->field_87 = r2
    //     0x6e1da8: stur            w2, [x0, #0x87]
    // 0x6e1dac: SaveReg r0
    //     0x6e1dac: str             x0, [SP, #-8]!
    // 0x6e1db0: r0 = markNeedsLayout()
    //     0x6e1db0: bl              #0x6c0c74  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::markNeedsLayout
    // 0x6e1db4: add             SP, SP, #8
    // 0x6e1db8: r0 = Null
    //     0x6e1db8: mov             x0, NULL
    // 0x6e1dbc: LeaveFrame
    //     0x6e1dbc: mov             SP, fp
    //     0x6e1dc0: ldp             fp, lr, [SP], #0x10
    // 0x6e1dc4: ret
    //     0x6e1dc4: ret             
    // 0x6e1dc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e1dc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e1dcc: b               #0x6e1d80
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0x6e1dd0, size: 0x78
    // 0x6e1dd0: EnterFrame
    //     0x6e1dd0: stp             fp, lr, [SP, #-0x10]!
    //     0x6e1dd4: mov             fp, SP
    // 0x6e1dd8: CheckStackOverflow
    //     0x6e1dd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e1ddc: cmp             SP, x16
    //     0x6e1de0: b.ls            #0x6e1e40
    // 0x6e1de4: ldr             x0, [fp, #0x18]
    // 0x6e1de8: LoadField: r1 = r0->field_6f
    //     0x6e1de8: ldur            w1, [x0, #0x6f]
    // 0x6e1dec: DecompressPointer r1
    //     0x6e1dec: add             x1, x1, HEAP, lsl #32
    // 0x6e1df0: LoadField: r2 = r1->field_1b
    //     0x6e1df0: ldur            w2, [x1, #0x1b]
    // 0x6e1df4: DecompressPointer r2
    //     0x6e1df4: add             x2, x2, HEAP, lsl #32
    // 0x6e1df8: ldr             x3, [fp, #0x10]
    // 0x6e1dfc: cmp             w2, w3
    // 0x6e1e00: b.ne            #0x6e1e14
    // 0x6e1e04: r0 = Null
    //     0x6e1e04: mov             x0, NULL
    // 0x6e1e08: LeaveFrame
    //     0x6e1e08: mov             SP, fp
    //     0x6e1e0c: ldp             fp, lr, [SP], #0x10
    // 0x6e1e10: ret
    //     0x6e1e10: ret             
    // 0x6e1e14: stp             x3, x1, [SP, #-0x10]!
    // 0x6e1e18: r0 = textDirection=()
    //     0x6e1e18: bl              #0x673280  ; [package:flutter/src/painting/text_painter.dart] TextPainter::textDirection=
    // 0x6e1e1c: add             SP, SP, #0x10
    // 0x6e1e20: ldr             x16, [fp, #0x18]
    // 0x6e1e24: SaveReg r16
    //     0x6e1e24: str             x16, [SP, #-8]!
    // 0x6e1e28: r0 = markNeedsLayout()
    //     0x6e1e28: bl              #0x6c0c74  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::markNeedsLayout
    // 0x6e1e2c: add             SP, SP, #8
    // 0x6e1e30: r0 = Null
    //     0x6e1e30: mov             x0, NULL
    // 0x6e1e34: LeaveFrame
    //     0x6e1e34: mov             SP, fp
    //     0x6e1e38: ldp             fp, lr, [SP], #0x10
    // 0x6e1e3c: ret
    //     0x6e1e3c: ret             
    // 0x6e1e40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e1e40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e1e44: b               #0x6e1de4
  }
  set _ textAlign=(/* No info */) {
    // ** addr: 0x6e1e48, size: 0x78
    // 0x6e1e48: EnterFrame
    //     0x6e1e48: stp             fp, lr, [SP, #-0x10]!
    //     0x6e1e4c: mov             fp, SP
    // 0x6e1e50: CheckStackOverflow
    //     0x6e1e50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e1e54: cmp             SP, x16
    //     0x6e1e58: b.ls            #0x6e1eb8
    // 0x6e1e5c: ldr             x0, [fp, #0x18]
    // 0x6e1e60: LoadField: r1 = r0->field_6f
    //     0x6e1e60: ldur            w1, [x0, #0x6f]
    // 0x6e1e64: DecompressPointer r1
    //     0x6e1e64: add             x1, x1, HEAP, lsl #32
    // 0x6e1e68: LoadField: r2 = r1->field_17
    //     0x6e1e68: ldur            w2, [x1, #0x17]
    // 0x6e1e6c: DecompressPointer r2
    //     0x6e1e6c: add             x2, x2, HEAP, lsl #32
    // 0x6e1e70: ldr             x3, [fp, #0x10]
    // 0x6e1e74: cmp             w2, w3
    // 0x6e1e78: b.ne            #0x6e1e8c
    // 0x6e1e7c: r0 = Null
    //     0x6e1e7c: mov             x0, NULL
    // 0x6e1e80: LeaveFrame
    //     0x6e1e80: mov             SP, fp
    //     0x6e1e84: ldp             fp, lr, [SP], #0x10
    // 0x6e1e88: ret
    //     0x6e1e88: ret             
    // 0x6e1e8c: stp             x3, x1, [SP, #-0x10]!
    // 0x6e1e90: r0 = textAlign=()
    //     0x6e1e90: bl              #0x6df5fc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::textAlign=
    // 0x6e1e94: add             SP, SP, #0x10
    // 0x6e1e98: ldr             x16, [fp, #0x18]
    // 0x6e1e9c: SaveReg r16
    //     0x6e1e9c: str             x16, [SP, #-8]!
    // 0x6e1ea0: r0 = markNeedsPaint()
    //     0x6e1ea0: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6e1ea4: add             SP, SP, #8
    // 0x6e1ea8: r0 = Null
    //     0x6e1ea8: mov             x0, NULL
    // 0x6e1eac: LeaveFrame
    //     0x6e1eac: mov             SP, fp
    //     0x6e1eb0: ldp             fp, lr, [SP], #0x10
    // 0x6e1eb4: ret
    //     0x6e1eb4: ret             
    // 0x6e1eb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e1eb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e1ebc: b               #0x6e1e5c
  }
  set _ text=(/* No info */) {
    // ** addr: 0x6e1ec0, size: 0x1f4
    // 0x6e1ec0: EnterFrame
    //     0x6e1ec0: stp             fp, lr, [SP, #-0x10]!
    //     0x6e1ec4: mov             fp, SP
    // 0x6e1ec8: AllocStack(0x10)
    //     0x6e1ec8: sub             SP, SP, #0x10
    // 0x6e1ecc: CheckStackOverflow
    //     0x6e1ecc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e1ed0: cmp             SP, x16
    //     0x6e1ed4: b.ls            #0x6e20a8
    // 0x6e1ed8: ldr             x0, [fp, #0x18]
    // 0x6e1edc: LoadField: r1 = r0->field_6f
    //     0x6e1edc: ldur            w1, [x0, #0x6f]
    // 0x6e1ee0: DecompressPointer r1
    //     0x6e1ee0: add             x1, x1, HEAP, lsl #32
    // 0x6e1ee4: stur            x1, [fp, #-0x10]
    // 0x6e1ee8: LoadField: r2 = r1->field_f
    //     0x6e1ee8: ldur            w2, [x1, #0xf]
    // 0x6e1eec: DecompressPointer r2
    //     0x6e1eec: add             x2, x2, HEAP, lsl #32
    // 0x6e1ef0: stur            x2, [fp, #-8]
    // 0x6e1ef4: cmp             w2, NULL
    // 0x6e1ef8: b.eq            #0x6e20b0
    // 0x6e1efc: r3 = LoadClassIdInstr(r2)
    //     0x6e1efc: ldur            x3, [x2, #-1]
    //     0x6e1f00: ubfx            x3, x3, #0xc, #0x14
    // 0x6e1f04: lsl             x3, x3, #1
    // 0x6e1f08: r17 = 6950
    //     0x6e1f08: mov             x17, #0x1b26
    // 0x6e1f0c: cmp             w3, w17
    // 0x6e1f10: b.ne            #0x6e1f7c
    // 0x6e1f14: ldr             x16, [fp, #0x10]
    // 0x6e1f18: stp             x16, x2, [SP, #-0x10]!
    // 0x6e1f1c: r0 = compareTo()
    //     0x6e1f1c: bl              #0xcdc8cc  ; [package:flutter/src/painting/text_span.dart] TextSpan::compareTo
    // 0x6e1f20: add             SP, SP, #0x10
    // 0x6e1f24: r16 = Instance_RenderComparison
    //     0x6e1f24: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d438] Obj!RenderComparison@b65051
    //     0x6e1f28: ldr             x16, [x16, #0x438]
    // 0x6e1f2c: cmp             w0, w16
    // 0x6e1f30: b.ne            #0x6e1fa4
    // 0x6e1f34: ldr             x0, [fp, #0x10]
    // 0x6e1f38: r2 = Null
    //     0x6e1f38: mov             x2, NULL
    // 0x6e1f3c: r1 = Null
    //     0x6e1f3c: mov             x1, NULL
    // 0x6e1f40: r4 = LoadClassIdInstr(r0)
    //     0x6e1f40: ldur            x4, [x0, #-1]
    //     0x6e1f44: ubfx            x4, x4, #0xc, #0x14
    // 0x6e1f48: cmp             x4, #0xd93
    // 0x6e1f4c: b.eq            #0x6e1f64
    // 0x6e1f50: r8 = SpecialInlineSpanBase
    //     0x6e1f50: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d440] Type: SpecialInlineSpanBase
    //     0x6e1f54: ldr             x8, [x8, #0x440]
    // 0x6e1f58: r3 = Null
    //     0x6e1f58: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d448] Null
    //     0x6e1f5c: ldr             x3, [x3, #0x448]
    // 0x6e1f60: r0 = DefaultTypeTest()
    //     0x6e1f60: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6e1f64: ldur            x16, [fp, #-8]
    // 0x6e1f68: ldr             lr, [fp, #0x10]
    // 0x6e1f6c: stp             lr, x16, [SP, #-0x10]!
    // 0x6e1f70: r0 = baseCompareTo()
    //     0x6e1f70: bl              #0x6736c4  ; [package:extended_text_library/src/special_text_span.dart] _SpecialTextSpan&TextSpan&SpecialInlineSpanBase::baseCompareTo
    // 0x6e1f74: add             SP, SP, #0x10
    // 0x6e1f78: b               #0x6e1fa4
    // 0x6e1f7c: mov             x0, x2
    // 0x6e1f80: r1 = LoadClassIdInstr(r0)
    //     0x6e1f80: ldur            x1, [x0, #-1]
    //     0x6e1f84: ubfx            x1, x1, #0xc, #0x14
    // 0x6e1f88: ldr             x16, [fp, #0x10]
    // 0x6e1f8c: stp             x16, x0, [SP, #-0x10]!
    // 0x6e1f90: mov             x0, x1
    // 0x6e1f94: r0 = GDT[cid_x0 + -0xf24]()
    //     0x6e1f94: sub             lr, x0, #0xf24
    //     0x6e1f98: ldr             lr, [x21, lr, lsl #3]
    //     0x6e1f9c: blr             lr
    // 0x6e1fa0: add             SP, SP, #0x10
    // 0x6e1fa4: LoadField: r1 = r0->field_7
    //     0x6e1fa4: ldur            x1, [x0, #7]
    // 0x6e1fa8: cmp             x1, #1
    // 0x6e1fac: b.gt            #0x6e1fc0
    // 0x6e1fb0: r0 = Null
    //     0x6e1fb0: mov             x0, NULL
    // 0x6e1fb4: LeaveFrame
    //     0x6e1fb4: mov             SP, fp
    //     0x6e1fb8: ldp             fp, lr, [SP], #0x10
    // 0x6e1fbc: ret
    //     0x6e1fbc: ret             
    // 0x6e1fc0: cmp             x1, #2
    // 0x6e1fc4: b.gt            #0x6e2020
    // 0x6e1fc8: ldr             x0, [fp, #0x18]
    // 0x6e1fcc: ldur            x16, [fp, #-0x10]
    // 0x6e1fd0: ldr             lr, [fp, #0x10]
    // 0x6e1fd4: stp             lr, x16, [SP, #-0x10]!
    // 0x6e1fd8: r0 = text=()
    //     0x6e1fd8: bl              #0x673330  ; [package:flutter/src/painting/text_painter.dart] TextPainter::text=
    // 0x6e1fdc: add             SP, SP, #0x10
    // 0x6e1fe0: ldr             x0, [fp, #0x18]
    // 0x6e1fe4: StoreField: r0->field_73 = rNULL
    //     0x6e1fe4: stur            NULL, [x0, #0x73]
    // 0x6e1fe8: StoreField: r0->field_77 = rNULL
    //     0x6e1fe8: stur            NULL, [x0, #0x77]
    // 0x6e1fec: ldr             x16, [fp, #0x10]
    // 0x6e1ff0: stp             x16, x0, [SP, #-0x10]!
    // 0x6e1ff4: r0 = _extractPlaceholderSpans()
    //     0x6e1ff4: bl              #0x6e20b4  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_extractPlaceholderSpans
    // 0x6e1ff8: add             SP, SP, #0x10
    // 0x6e1ffc: ldr             x16, [fp, #0x18]
    // 0x6e2000: SaveReg r16
    //     0x6e2000: str             x16, [SP, #-8]!
    // 0x6e2004: r0 = markNeedsPaint()
    //     0x6e2004: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6e2008: add             SP, SP, #8
    // 0x6e200c: ldr             x16, [fp, #0x18]
    // 0x6e2010: SaveReg r16
    //     0x6e2010: str             x16, [SP, #-8]!
    // 0x6e2014: r0 = markNeedsSemanticsUpdate()
    //     0x6e2014: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6e2018: add             SP, SP, #8
    // 0x6e201c: b               #0x6e2098
    // 0x6e2020: ldr             x0, [fp, #0x18]
    // 0x6e2024: ldur            x16, [fp, #-0x10]
    // 0x6e2028: ldr             lr, [fp, #0x10]
    // 0x6e202c: stp             lr, x16, [SP, #-0x10]!
    // 0x6e2030: r0 = text=()
    //     0x6e2030: bl              #0x673330  ; [package:flutter/src/painting/text_painter.dart] TextPainter::text=
    // 0x6e2034: add             SP, SP, #0x10
    // 0x6e2038: ldr             x0, [fp, #0x18]
    // 0x6e203c: StoreField: r0->field_97 = rNULL
    //     0x6e203c: stur            NULL, [x0, #0x97]
    // 0x6e2040: StoreField: r0->field_73 = rNULL
    //     0x6e2040: stur            NULL, [x0, #0x73]
    // 0x6e2044: StoreField: r0->field_77 = rNULL
    //     0x6e2044: stur            NULL, [x0, #0x77]
    // 0x6e2048: ldr             x16, [fp, #0x10]
    // 0x6e204c: stp             x16, x0, [SP, #-0x10]!
    // 0x6e2050: r0 = _extractPlaceholderSpans()
    //     0x6e2050: bl              #0x6e20b4  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_extractPlaceholderSpans
    // 0x6e2054: add             SP, SP, #0x10
    // 0x6e2058: ldr             x16, [fp, #0x18]
    // 0x6e205c: SaveReg r16
    //     0x6e205c: str             x16, [SP, #-8]!
    // 0x6e2060: r0 = markNeedsLayout()
    //     0x6e2060: bl              #0x6c0c74  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::markNeedsLayout
    // 0x6e2064: add             SP, SP, #8
    // 0x6e2068: ldr             x16, [fp, #0x18]
    // 0x6e206c: SaveReg r16
    //     0x6e206c: str             x16, [SP, #-8]!
    // 0x6e2070: r0 = _removeSelectionRegistrarSubscription()
    //     0x6e2070: bl              #0x65284c  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_removeSelectionRegistrarSubscription
    // 0x6e2074: add             SP, SP, #8
    // 0x6e2078: ldr             x16, [fp, #0x18]
    // 0x6e207c: SaveReg r16
    //     0x6e207c: str             x16, [SP, #-8]!
    // 0x6e2080: r0 = _disposeSelectableFragments()
    //     0x6e2080: bl              #0x6e16ec  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_disposeSelectableFragments
    // 0x6e2084: add             SP, SP, #8
    // 0x6e2088: ldr             x16, [fp, #0x18]
    // 0x6e208c: SaveReg r16
    //     0x6e208c: str             x16, [SP, #-8]!
    // 0x6e2090: r0 = _updateSelectionRegistrarSubscription()
    //     0x6e2090: bl              #0x6e127c  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_updateSelectionRegistrarSubscription
    // 0x6e2094: add             SP, SP, #8
    // 0x6e2098: r0 = Null
    //     0x6e2098: mov             x0, NULL
    // 0x6e209c: LeaveFrame
    //     0x6e209c: mov             SP, fp
    //     0x6e20a0: ldp             fp, lr, [SP], #0x10
    // 0x6e20a4: ret
    //     0x6e20a4: ret             
    // 0x6e20a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e20a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e20ac: b               #0x6e1ed8
    // 0x6e20b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6e20b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _extractPlaceholderSpans(/* No info */) {
    // ** addr: 0x6e20b4, size: 0x1bc
    // 0x6e20b4: EnterFrame
    //     0x6e20b4: stp             fp, lr, [SP, #-0x10]!
    //     0x6e20b8: mov             fp, SP
    // 0x6e20bc: AllocStack(0x18)
    //     0x6e20bc: sub             SP, SP, #0x18
    // 0x6e20c0: CheckStackOverflow
    //     0x6e20c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e20c4: cmp             SP, x16
    //     0x6e20c8: b.ls            #0x6e2258
    // 0x6e20cc: r1 = 1
    //     0x6e20cc: mov             x1, #1
    // 0x6e20d0: r0 = AllocateContext()
    //     0x6e20d0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6e20d4: mov             x1, x0
    // 0x6e20d8: ldr             x0, [fp, #0x18]
    // 0x6e20dc: stur            x1, [fp, #-8]
    // 0x6e20e0: StoreField: r1->field_f = r0
    //     0x6e20e0: stur            w0, [x1, #0xf]
    // 0x6e20e4: r16 = <PlaceholderSpan>
    //     0x6e20e4: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d458] TypeArguments: <PlaceholderSpan>
    //     0x6e20e8: ldr             x16, [x16, #0x458]
    // 0x6e20ec: stp             xzr, x16, [SP, #-0x10]!
    // 0x6e20f0: r0 = _GrowableList()
    //     0x6e20f0: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x6e20f4: add             SP, SP, #0x10
    // 0x6e20f8: ldr             x1, [fp, #0x18]
    // 0x6e20fc: StoreField: r1->field_83 = r0
    //     0x6e20fc: stur            w0, [x1, #0x83]
    //     0x6e2100: ldurb           w16, [x1, #-1]
    //     0x6e2104: ldurb           w17, [x0, #-1]
    //     0x6e2108: and             x16, x17, x16, lsr #2
    //     0x6e210c: tst             x16, HEAP, lsr #32
    //     0x6e2110: b.eq            #0x6e2118
    //     0x6e2114: bl              #0xd6826c
    // 0x6e2118: ldr             x0, [fp, #0x10]
    // 0x6e211c: r1 = LoadClassIdInstr(r0)
    //     0x6e211c: ldur            x1, [x0, #-1]
    //     0x6e2120: ubfx            x1, x1, #0xc, #0x14
    // 0x6e2124: lsl             x1, x1, #1
    // 0x6e2128: r17 = 6958
    //     0x6e2128: mov             x17, #0x1b2e
    // 0x6e212c: cmp             w1, w17
    // 0x6e2130: b.gt            #0x6e220c
    // 0x6e2134: r17 = 6954
    //     0x6e2134: mov             x17, #0x1b2a
    // 0x6e2138: cmp             w1, w17
    // 0x6e213c: b.lt            #0x6e2204
    // 0x6e2140: r2 = LoadInt32Instr(r1)
    //     0x6e2140: sbfx            x2, x1, #1, #0x1f
    // 0x6e2144: cmp             x2, #0xd95
    // 0x6e2148: b.lt            #0x6e2248
    // 0x6e214c: cmp             x2, #0xd97
    // 0x6e2150: b.gt            #0x6e2248
    // 0x6e2154: ldur            x2, [fp, #-8]
    // 0x6e2158: LoadField: r1 = r2->field_f
    //     0x6e2158: ldur            w1, [x2, #0xf]
    // 0x6e215c: DecompressPointer r1
    //     0x6e215c: add             x1, x1, HEAP, lsl #32
    // 0x6e2160: LoadField: r2 = r1->field_83
    //     0x6e2160: ldur            w2, [x1, #0x83]
    // 0x6e2164: DecompressPointer r2
    //     0x6e2164: add             x2, x2, HEAP, lsl #32
    // 0x6e2168: r16 = Sentinel
    //     0x6e2168: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6e216c: cmp             w2, w16
    // 0x6e2170: b.eq            #0x6e2260
    // 0x6e2174: stur            x2, [fp, #-0x18]
    // 0x6e2178: LoadField: r1 = r2->field_b
    //     0x6e2178: ldur            w1, [x2, #0xb]
    // 0x6e217c: DecompressPointer r1
    //     0x6e217c: add             x1, x1, HEAP, lsl #32
    // 0x6e2180: stur            x1, [fp, #-0x10]
    // 0x6e2184: LoadField: r3 = r2->field_f
    //     0x6e2184: ldur            w3, [x2, #0xf]
    // 0x6e2188: DecompressPointer r3
    //     0x6e2188: add             x3, x3, HEAP, lsl #32
    // 0x6e218c: LoadField: r4 = r3->field_b
    //     0x6e218c: ldur            w4, [x3, #0xb]
    // 0x6e2190: DecompressPointer r4
    //     0x6e2190: add             x4, x4, HEAP, lsl #32
    // 0x6e2194: cmp             w1, w4
    // 0x6e2198: b.ne            #0x6e21a8
    // 0x6e219c: SaveReg r2
    //     0x6e219c: str             x2, [SP, #-8]!
    // 0x6e21a0: r0 = _growToNextCapacity()
    //     0x6e21a0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6e21a4: add             SP, SP, #8
    // 0x6e21a8: ldur            x2, [fp, #-0x18]
    // 0x6e21ac: ldur            x0, [fp, #-0x10]
    // 0x6e21b0: r3 = LoadInt32Instr(r0)
    //     0x6e21b0: sbfx            x3, x0, #1, #0x1f
    // 0x6e21b4: add             x0, x3, #1
    // 0x6e21b8: lsl             x1, x0, #1
    // 0x6e21bc: StoreField: r2->field_b = r1
    //     0x6e21bc: stur            w1, [x2, #0xb]
    // 0x6e21c0: mov             x1, x3
    // 0x6e21c4: cmp             x1, x0
    // 0x6e21c8: b.hs            #0x6e226c
    // 0x6e21cc: LoadField: r1 = r2->field_f
    //     0x6e21cc: ldur            w1, [x2, #0xf]
    // 0x6e21d0: DecompressPointer r1
    //     0x6e21d0: add             x1, x1, HEAP, lsl #32
    // 0x6e21d4: ldr             x0, [fp, #0x10]
    // 0x6e21d8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x6e21d8: add             x25, x1, x3, lsl #2
    //     0x6e21dc: add             x25, x25, #0xf
    //     0x6e21e0: str             w0, [x25]
    //     0x6e21e4: tbz             w0, #0, #0x6e2200
    //     0x6e21e8: ldurb           w16, [x1, #-1]
    //     0x6e21ec: ldurb           w17, [x0, #-1]
    //     0x6e21f0: and             x16, x17, x16, lsr #2
    //     0x6e21f4: tst             x16, HEAP, lsr #32
    //     0x6e21f8: b.eq            #0x6e2200
    //     0x6e21fc: bl              #0xd67e5c
    // 0x6e2200: b               #0x6e2248
    // 0x6e2204: ldur            x2, [fp, #-8]
    // 0x6e2208: b               #0x6e2210
    // 0x6e220c: ldur            x2, [fp, #-8]
    // 0x6e2210: ldr             x0, [fp, #0x10]
    // 0x6e2214: r1 = Function '<anonymous closure>':.
    //     0x6e2214: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d460] AnonymousClosure: (0x6e2270), in [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_extractPlaceholderSpans (0x6e20b4)
    //     0x6e2218: ldr             x1, [x1, #0x460]
    // 0x6e221c: r0 = AllocateClosure()
    //     0x6e221c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6e2220: mov             x1, x0
    // 0x6e2224: ldr             x0, [fp, #0x10]
    // 0x6e2228: r2 = LoadClassIdInstr(r0)
    //     0x6e2228: ldur            x2, [x0, #-1]
    //     0x6e222c: ubfx            x2, x2, #0xc, #0x14
    // 0x6e2230: stp             x1, x0, [SP, #-0x10]!
    // 0x6e2234: mov             x0, x2
    // 0x6e2238: r0 = GDT[cid_x0 + -0x1000]()
    //     0x6e2238: sub             lr, x0, #1, lsl #12
    //     0x6e223c: ldr             lr, [x21, lr, lsl #3]
    //     0x6e2240: blr             lr
    // 0x6e2244: add             SP, SP, #0x10
    // 0x6e2248: r0 = Null
    //     0x6e2248: mov             x0, NULL
    // 0x6e224c: LeaveFrame
    //     0x6e224c: mov             SP, fp
    //     0x6e2250: ldp             fp, lr, [SP], #0x10
    // 0x6e2254: ret
    //     0x6e2254: ret             
    // 0x6e2258: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e2258: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e225c: b               #0x6e20cc
    // 0x6e2260: r9 = _placeholderSpans
    //     0x6e2260: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d468] Field <RenderParagraph._placeholderSpans@507149678>: late (offset: 0x84)
    //     0x6e2264: ldr             x9, [x9, #0x468]
    // 0x6e2268: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6e2268: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6e226c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6e226c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, InlineSpan) {
    // ** addr: 0x6e2270, size: 0x118
    // 0x6e2270: EnterFrame
    //     0x6e2270: stp             fp, lr, [SP, #-0x10]!
    //     0x6e2274: mov             fp, SP
    // 0x6e2278: AllocStack(0x10)
    //     0x6e2278: sub             SP, SP, #0x10
    // 0x6e227c: SetupParameters()
    //     0x6e227c: ldr             x0, [fp, #0x18]
    //     0x6e2280: ldur            w1, [x0, #0x17]
    //     0x6e2284: add             x1, x1, HEAP, lsl #32
    // 0x6e2288: CheckStackOverflow
    //     0x6e2288: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e228c: cmp             SP, x16
    //     0x6e2290: b.ls            #0x6e2370
    // 0x6e2294: ldr             x0, [fp, #0x10]
    // 0x6e2298: r2 = LoadClassIdInstr(r0)
    //     0x6e2298: ldur            x2, [x0, #-1]
    //     0x6e229c: ubfx            x2, x2, #0xc, #0x14
    // 0x6e22a0: lsl             x2, x2, #1
    // 0x6e22a4: r3 = LoadInt32Instr(r2)
    //     0x6e22a4: sbfx            x3, x2, #1, #0x1f
    // 0x6e22a8: cmp             x3, #0xd95
    // 0x6e22ac: b.lt            #0x6e2360
    // 0x6e22b0: cmp             x3, #0xd97
    // 0x6e22b4: b.gt            #0x6e2360
    // 0x6e22b8: LoadField: r2 = r1->field_f
    //     0x6e22b8: ldur            w2, [x1, #0xf]
    // 0x6e22bc: DecompressPointer r2
    //     0x6e22bc: add             x2, x2, HEAP, lsl #32
    // 0x6e22c0: LoadField: r1 = r2->field_83
    //     0x6e22c0: ldur            w1, [x2, #0x83]
    // 0x6e22c4: DecompressPointer r1
    //     0x6e22c4: add             x1, x1, HEAP, lsl #32
    // 0x6e22c8: r16 = Sentinel
    //     0x6e22c8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6e22cc: cmp             w1, w16
    // 0x6e22d0: b.eq            #0x6e2378
    // 0x6e22d4: stur            x1, [fp, #-0x10]
    // 0x6e22d8: LoadField: r2 = r1->field_b
    //     0x6e22d8: ldur            w2, [x1, #0xb]
    // 0x6e22dc: DecompressPointer r2
    //     0x6e22dc: add             x2, x2, HEAP, lsl #32
    // 0x6e22e0: stur            x2, [fp, #-8]
    // 0x6e22e4: LoadField: r3 = r1->field_f
    //     0x6e22e4: ldur            w3, [x1, #0xf]
    // 0x6e22e8: DecompressPointer r3
    //     0x6e22e8: add             x3, x3, HEAP, lsl #32
    // 0x6e22ec: LoadField: r4 = r3->field_b
    //     0x6e22ec: ldur            w4, [x3, #0xb]
    // 0x6e22f0: DecompressPointer r4
    //     0x6e22f0: add             x4, x4, HEAP, lsl #32
    // 0x6e22f4: cmp             w2, w4
    // 0x6e22f8: b.ne            #0x6e2308
    // 0x6e22fc: SaveReg r1
    //     0x6e22fc: str             x1, [SP, #-8]!
    // 0x6e2300: r0 = _growToNextCapacity()
    //     0x6e2300: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6e2304: add             SP, SP, #8
    // 0x6e2308: ldur            x2, [fp, #-0x10]
    // 0x6e230c: ldur            x3, [fp, #-8]
    // 0x6e2310: r4 = LoadInt32Instr(r3)
    //     0x6e2310: sbfx            x4, x3, #1, #0x1f
    // 0x6e2314: add             x0, x4, #1
    // 0x6e2318: lsl             x3, x0, #1
    // 0x6e231c: StoreField: r2->field_b = r3
    //     0x6e231c: stur            w3, [x2, #0xb]
    // 0x6e2320: mov             x1, x4
    // 0x6e2324: cmp             x1, x0
    // 0x6e2328: b.hs            #0x6e2384
    // 0x6e232c: LoadField: r1 = r2->field_f
    //     0x6e232c: ldur            w1, [x2, #0xf]
    // 0x6e2330: DecompressPointer r1
    //     0x6e2330: add             x1, x1, HEAP, lsl #32
    // 0x6e2334: ldr             x0, [fp, #0x10]
    // 0x6e2338: ArrayStore: r1[r4] = r0  ; List_4
    //     0x6e2338: add             x25, x1, x4, lsl #2
    //     0x6e233c: add             x25, x25, #0xf
    //     0x6e2340: str             w0, [x25]
    //     0x6e2344: tbz             w0, #0, #0x6e2360
    //     0x6e2348: ldurb           w16, [x1, #-1]
    //     0x6e234c: ldurb           w17, [x0, #-1]
    //     0x6e2350: and             x16, x17, x16, lsr #2
    //     0x6e2354: tst             x16, HEAP, lsr #32
    //     0x6e2358: b.eq            #0x6e2360
    //     0x6e235c: bl              #0xd67e5c
    // 0x6e2360: r0 = true
    //     0x6e2360: add             x0, NULL, #0x20  ; true
    // 0x6e2364: LeaveFrame
    //     0x6e2364: mov             SP, fp
    //     0x6e2368: ldp             fp, lr, [SP], #0x10
    // 0x6e236c: ret
    //     0x6e236c: ret             
    // 0x6e2370: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e2370: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e2374: b               #0x6e2294
    // 0x6e2378: r9 = _placeholderSpans
    //     0x6e2378: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d468] Field <RenderParagraph._placeholderSpans@507149678>: late (offset: 0x84)
    //     0x6e237c: ldr             x9, [x9, #0x468]
    // 0x6e2380: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6e2380: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6e2384: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6e2384: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ RenderParagraph(/* No info */) {
    // ** addr: 0x6f3e4c, size: 0x198
    // 0x6f3e4c: EnterFrame
    //     0x6f3e4c: stp             fp, lr, [SP, #-0x10]!
    //     0x6f3e50: mov             fp, SP
    // 0x6f3e54: AllocStack(0x8)
    //     0x6f3e54: sub             SP, SP, #8
    // 0x6f3e58: r1 = Sentinel
    //     0x6f3e58: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6f3e5c: r0 = false
    //     0x6f3e5c: add             x0, NULL, #0x30  ; false
    // 0x6f3e60: CheckStackOverflow
    //     0x6f3e60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f3e64: cmp             SP, x16
    //     0x6f3e68: b.ls            #0x6f3fdc
    // 0x6f3e6c: ldr             x2, [fp, #0x68]
    // 0x6f3e70: StoreField: r2->field_83 = r1
    //     0x6f3e70: stur            w1, [x2, #0x83]
    // 0x6f3e74: StoreField: r2->field_93 = r0
    //     0x6f3e74: stur            w0, [x2, #0x93]
    // 0x6f3e78: StoreField: r2->field_9b = r0
    //     0x6f3e78: stur            w0, [x2, #0x9b]
    // 0x6f3e7c: ldr             x0, [fp, #0x30]
    // 0x6f3e80: StoreField: r2->field_87 = r0
    //     0x6f3e80: stur            w0, [x2, #0x87]
    // 0x6f3e84: ldr             x0, [fp, #0x48]
    // 0x6f3e88: StoreField: r2->field_8b = r0
    //     0x6f3e88: stur            w0, [x2, #0x8b]
    //     0x6f3e8c: ldurb           w16, [x2, #-1]
    //     0x6f3e90: ldurb           w17, [x0, #-1]
    //     0x6f3e94: and             x16, x17, x16, lsr #2
    //     0x6f3e98: tst             x16, HEAP, lsr #32
    //     0x6f3e9c: b.eq            #0x6f3ea4
    //     0x6f3ea0: bl              #0xd6828c
    // 0x6f3ea4: ldr             x0, [fp, #0x38]
    // 0x6f3ea8: StoreField: r2->field_8f = r0
    //     0x6f3ea8: stur            w0, [x2, #0x8f]
    //     0x6f3eac: ldurb           w16, [x2, #-1]
    //     0x6f3eb0: ldurb           w17, [x0, #-1]
    //     0x6f3eb4: and             x16, x17, x16, lsr #2
    //     0x6f3eb8: tst             x16, HEAP, lsr #32
    //     0x6f3ebc: b.eq            #0x6f3ec4
    //     0x6f3ec0: bl              #0xd6828c
    // 0x6f3ec4: ldr             x0, [fp, #0x48]
    // 0x6f3ec8: r16 = Instance_TextOverflow
    //     0x6f3ec8: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d428] Obj!TextOverflow@b64d51
    //     0x6f3ecc: ldr             x16, [x16, #0x428]
    // 0x6f3ed0: cmp             w0, w16
    // 0x6f3ed4: b.ne            #0x6f3ee4
    // 0x6f3ed8: r8 = "…"
    //     0x6f3ed8: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d430] "…"
    //     0x6f3edc: ldr             x8, [x8, #0x430]
    // 0x6f3ee0: b               #0x6f3ee8
    // 0x6f3ee4: r8 = Null
    //     0x6f3ee4: mov             x8, NULL
    // 0x6f3ee8: ldr             x7, [fp, #0x60]
    // 0x6f3eec: ldr             x6, [fp, #0x58]
    // 0x6f3ef0: ldr             x5, [fp, #0x50]
    // 0x6f3ef4: ldr             x4, [fp, #0x28]
    // 0x6f3ef8: ldr             x3, [fp, #0x20]
    // 0x6f3efc: ldr             x0, [fp, #0x18]
    // 0x6f3f00: ldr             d0, [fp, #0x10]
    // 0x6f3f04: stur            x8, [fp, #-8]
    // 0x6f3f08: r0 = TextPainter()
    //     0x6f3f08: bl              #0x68dbc4  ; AllocateTextPainterStub -> TextPainter (size=0x68)
    // 0x6f3f0c: mov             x1, x0
    // 0x6f3f10: r0 = true
    //     0x6f3f10: add             x0, NULL, #0x20  ; true
    // 0x6f3f14: StoreField: r1->field_b = r0
    //     0x6f3f14: stur            w0, [x1, #0xb]
    // 0x6f3f18: r0 = Sentinel
    //     0x6f3f18: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6f3f1c: StoreField: r1->field_57 = r0
    //     0x6f3f1c: stur            w0, [x1, #0x57]
    // 0x6f3f20: ldr             x2, [fp, #0x60]
    // 0x6f3f24: StoreField: r1->field_f = r2
    //     0x6f3f24: stur            w2, [x1, #0xf]
    // 0x6f3f28: ldr             x0, [fp, #0x20]
    // 0x6f3f2c: StoreField: r1->field_17 = r0
    //     0x6f3f2c: stur            w0, [x1, #0x17]
    // 0x6f3f30: ldr             x0, [fp, #0x18]
    // 0x6f3f34: StoreField: r1->field_1b = r0
    //     0x6f3f34: stur            w0, [x1, #0x1b]
    // 0x6f3f38: ldr             d0, [fp, #0x10]
    // 0x6f3f3c: StoreField: r1->field_1f = d0
    //     0x6f3f3c: stur            d0, [x1, #0x1f]
    // 0x6f3f40: ldr             x0, [fp, #0x50]
    // 0x6f3f44: StoreField: r1->field_2f = r0
    //     0x6f3f44: stur            w0, [x1, #0x2f]
    // 0x6f3f48: ldur            x0, [fp, #-8]
    // 0x6f3f4c: StoreField: r1->field_27 = r0
    //     0x6f3f4c: stur            w0, [x1, #0x27]
    // 0x6f3f50: ldr             x0, [fp, #0x58]
    // 0x6f3f54: StoreField: r1->field_2b = r0
    //     0x6f3f54: stur            w0, [x1, #0x2b]
    // 0x6f3f58: ldr             x0, [fp, #0x28]
    // 0x6f3f5c: StoreField: r1->field_33 = r0
    //     0x6f3f5c: stur            w0, [x1, #0x33]
    // 0x6f3f60: r0 = Instance_TextWidthBasis
    //     0x6f3f60: add             x0, PP, #0x15, lsl #12  ; [pp+0x15148] Obj!TextWidthBasis@b64d31
    //     0x6f3f64: ldr             x0, [x0, #0x148]
    // 0x6f3f68: StoreField: r1->field_37 = r0
    //     0x6f3f68: stur            w0, [x1, #0x37]
    // 0x6f3f6c: mov             x0, x1
    // 0x6f3f70: ldr             x1, [fp, #0x68]
    // 0x6f3f74: StoreField: r1->field_6f = r0
    //     0x6f3f74: stur            w0, [x1, #0x6f]
    //     0x6f3f78: ldurb           w16, [x1, #-1]
    //     0x6f3f7c: ldurb           w17, [x0, #-1]
    //     0x6f3f80: and             x16, x17, x16, lsr #2
    //     0x6f3f84: tst             x16, HEAP, lsr #32
    //     0x6f3f88: b.eq            #0x6f3f90
    //     0x6f3f8c: bl              #0xd6826c
    // 0x6f3f90: r0 = 0
    //     0x6f3f90: mov             x0, #0
    // 0x6f3f94: StoreField: r1->field_5f = r0
    //     0x6f3f94: stur            x0, [x1, #0x5f]
    // 0x6f3f98: SaveReg r1
    //     0x6f3f98: str             x1, [SP, #-8]!
    // 0x6f3f9c: r0 = RenderObject()
    //     0x6f3f9c: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6f3fa0: add             SP, SP, #8
    // 0x6f3fa4: ldr             x16, [fp, #0x68]
    // 0x6f3fa8: ldr             lr, [fp, #0x60]
    // 0x6f3fac: stp             lr, x16, [SP, #-0x10]!
    // 0x6f3fb0: r0 = _extractPlaceholderSpans()
    //     0x6f3fb0: bl              #0x6e20b4  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_extractPlaceholderSpans
    // 0x6f3fb4: add             SP, SP, #0x10
    // 0x6f3fb8: ldr             x16, [fp, #0x68]
    // 0x6f3fbc: ldr             lr, [fp, #0x40]
    // 0x6f3fc0: stp             lr, x16, [SP, #-0x10]!
    // 0x6f3fc4: r0 = registrar=()
    //     0x6f3fc4: bl              #0x6e11bc  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::registrar=
    // 0x6f3fc8: add             SP, SP, #0x10
    // 0x6f3fcc: r0 = Null
    //     0x6f3fcc: mov             x0, NULL
    // 0x6f3fd0: LeaveFrame
    //     0x6f3fd0: mov             SP, fp
    //     0x6f3fd4: ldp             fp, lr, [SP], #0x10
    // 0x6f3fd8: ret
    //     0x6f3fd8: ret             
    // 0x6f3fdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f3fdc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f3fe0: b               #0x6f3e6c
  }
  [closure] void systemFontsDidChange(dynamic) {
    // ** addr: 0x9bcd34, size: 0x48
    // 0x9bcd34: EnterFrame
    //     0x9bcd34: stp             fp, lr, [SP, #-0x10]!
    //     0x9bcd38: mov             fp, SP
    // 0x9bcd3c: ldr             x0, [fp, #0x10]
    // 0x9bcd40: LoadField: r1 = r0->field_17
    //     0x9bcd40: ldur            w1, [x0, #0x17]
    // 0x9bcd44: DecompressPointer r1
    //     0x9bcd44: add             x1, x1, HEAP, lsl #32
    // 0x9bcd48: CheckStackOverflow
    //     0x9bcd48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bcd4c: cmp             SP, x16
    //     0x9bcd50: b.ls            #0x9bcd74
    // 0x9bcd54: LoadField: r0 = r1->field_f
    //     0x9bcd54: ldur            w0, [x1, #0xf]
    // 0x9bcd58: DecompressPointer r0
    //     0x9bcd58: add             x0, x0, HEAP, lsl #32
    // 0x9bcd5c: SaveReg r0
    //     0x9bcd5c: str             x0, [SP, #-8]!
    // 0x9bcd60: r0 = systemFontsDidChange()
    //     0x9bcd60: bl              #0x9bcd7c  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::systemFontsDidChange
    // 0x9bcd64: add             SP, SP, #8
    // 0x9bcd68: LeaveFrame
    //     0x9bcd68: mov             SP, fp
    //     0x9bcd6c: ldp             fp, lr, [SP], #0x10
    // 0x9bcd70: ret
    //     0x9bcd70: ret             
    // 0x9bcd74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bcd74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bcd78: b               #0x9bcd54
  }
  _ systemFontsDidChange(/* No info */) {
    // ** addr: 0x9bcd7c, size: 0xf8
    // 0x9bcd7c: EnterFrame
    //     0x9bcd7c: stp             fp, lr, [SP, #-0x10]!
    //     0x9bcd80: mov             fp, SP
    // 0x9bcd84: AllocStack(0x8)
    //     0x9bcd84: sub             SP, SP, #8
    // 0x9bcd88: CheckStackOverflow
    //     0x9bcd88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bcd8c: cmp             SP, x16
    //     0x9bcd90: b.ls            #0x9bce68
    // 0x9bcd94: r1 = 1
    //     0x9bcd94: mov             x1, #1
    // 0x9bcd98: r0 = AllocateContext()
    //     0x9bcd98: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9bcd9c: mov             x1, x0
    // 0x9bcda0: ldr             x0, [fp, #0x10]
    // 0x9bcda4: StoreField: r1->field_f = r0
    //     0x9bcda4: stur            w0, [x1, #0xf]
    // 0x9bcda8: r3 = LoadStaticField(0xf10)
    //     0x9bcda8: ldr             x3, [THR, #0x88]  ; THR::field_table_values
    //     0x9bcdac: ldr             x3, [x3, #0x1e20]
    // 0x9bcdb0: stur            x3, [fp, #-8]
    // 0x9bcdb4: cmp             w3, NULL
    // 0x9bcdb8: b.eq            #0x9bce70
    // 0x9bcdbc: LoadField: r2 = r3->field_63
    //     0x9bcdbc: ldur            w2, [x3, #0x63]
    // 0x9bcdc0: DecompressPointer r2
    //     0x9bcdc0: add             x2, x2, HEAP, lsl #32
    // 0x9bcdc4: LoadField: r4 = r2->field_7
    //     0x9bcdc4: ldur            x4, [x2, #7]
    // 0x9bcdc8: cmp             x4, #2
    // 0x9bcdcc: b.gt            #0x9bcde4
    // 0x9bcdd0: cmp             x4, #1
    // 0x9bcdd4: b.gt            #0x9bcdec
    // 0x9bcdd8: cmp             x4, #0
    // 0x9bcddc: b.gt            #0x9bcdec
    // 0x9bcde0: b               #0x9bce14
    // 0x9bcde4: cmp             x4, #3
    // 0x9bcde8: b.gt            #0x9bce14
    // 0x9bcdec: SaveReg r0
    //     0x9bcdec: str             x0, [SP, #-8]!
    // 0x9bcdf0: r0 = systemFontsDidChange()
    //     0x9bcdf0: bl              #0x9bcc60  ; [package:flutter/src/rendering/paragraph.dart] _RenderParagraph&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin&RelayoutWhenSystemFontsChangeMixin::systemFontsDidChange
    // 0x9bcdf4: add             SP, SP, #8
    // 0x9bcdf8: ldr             x0, [fp, #0x10]
    // 0x9bcdfc: LoadField: r1 = r0->field_6f
    //     0x9bcdfc: ldur            w1, [x0, #0x6f]
    // 0x9bce00: DecompressPointer r1
    //     0x9bce00: add             x1, x1, HEAP, lsl #32
    // 0x9bce04: SaveReg r1
    //     0x9bce04: str             x1, [SP, #-8]!
    // 0x9bce08: r0 = markNeedsLayout()
    //     0x9bce08: bl              #0x62d54c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0x9bce0c: add             SP, SP, #8
    // 0x9bce10: b               #0x9bce58
    // 0x9bce14: LoadField: r2 = r0->field_9b
    //     0x9bce14: ldur            w2, [x0, #0x9b]
    // 0x9bce18: DecompressPointer r2
    //     0x9bce18: add             x2, x2, HEAP, lsl #32
    // 0x9bce1c: tbnz            w2, #4, #0x9bce30
    // 0x9bce20: r0 = Null
    //     0x9bce20: mov             x0, NULL
    // 0x9bce24: LeaveFrame
    //     0x9bce24: mov             SP, fp
    //     0x9bce28: ldp             fp, lr, [SP], #0x10
    // 0x9bce2c: ret
    //     0x9bce2c: ret             
    // 0x9bce30: r2 = true
    //     0x9bce30: add             x2, NULL, #0x20  ; true
    // 0x9bce34: StoreField: r0->field_9b = r2
    //     0x9bce34: stur            w2, [x0, #0x9b]
    // 0x9bce38: mov             x2, x1
    // 0x9bce3c: r1 = Function '<anonymous closure>':.
    //     0x9bce3c: add             x1, PP, #0x22, lsl #12  ; [pp+0x226d0] AnonymousClosure: (0x9bce74), in [package:flutter/src/rendering/paragraph.dart] RenderParagraph::systemFontsDidChange (0x9bcd7c)
    //     0x9bce40: ldr             x1, [x1, #0x6d0]
    // 0x9bce44: r0 = AllocateClosure()
    //     0x9bce44: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9bce48: ldur            x16, [fp, #-8]
    // 0x9bce4c: stp             x0, x16, [SP, #-0x10]!
    // 0x9bce50: r0 = scheduleFrameCallback()
    //     0x9bce50: bl              #0x591c08  ; [package:flutter/src/widgets/binding.dart] _WidgetsFlutterBinding&BindingBase&GestureBinding&SchedulerBinding::scheduleFrameCallback
    // 0x9bce54: add             SP, SP, #0x10
    // 0x9bce58: r0 = Null
    //     0x9bce58: mov             x0, NULL
    // 0x9bce5c: LeaveFrame
    //     0x9bce5c: mov             SP, fp
    //     0x9bce60: ldp             fp, lr, [SP], #0x10
    // 0x9bce64: ret
    //     0x9bce64: ret             
    // 0x9bce68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bce68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bce6c: b               #0x9bcd94
    // 0x9bce70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9bce70: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Duration) {
    // ** addr: 0x9bce74, size: 0x8c
    // 0x9bce74: EnterFrame
    //     0x9bce74: stp             fp, lr, [SP, #-0x10]!
    //     0x9bce78: mov             fp, SP
    // 0x9bce7c: AllocStack(0x8)
    //     0x9bce7c: sub             SP, SP, #8
    // 0x9bce80: SetupParameters()
    //     0x9bce80: add             x0, NULL, #0x30  ; false
    //     0x9bce84: ldr             x1, [fp, #0x18]
    //     0x9bce88: ldur            w2, [x1, #0x17]
    //     0x9bce8c: add             x2, x2, HEAP, lsl #32
    //     0x9bce90: stur            x2, [fp, #-8]
    // 0x9bce80: r0 = false
    // 0x9bce94: CheckStackOverflow
    //     0x9bce94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bce98: cmp             SP, x16
    //     0x9bce9c: b.ls            #0x9bcef8
    // 0x9bcea0: LoadField: r1 = r2->field_f
    //     0x9bcea0: ldur            w1, [x2, #0xf]
    // 0x9bcea4: DecompressPointer r1
    //     0x9bcea4: add             x1, x1, HEAP, lsl #32
    // 0x9bcea8: StoreField: r1->field_9b = r0
    //     0x9bcea8: stur            w0, [x1, #0x9b]
    // 0x9bceac: LoadField: r0 = r1->field_f
    //     0x9bceac: ldur            w0, [x1, #0xf]
    // 0x9bceb0: DecompressPointer r0
    //     0x9bceb0: add             x0, x0, HEAP, lsl #32
    // 0x9bceb4: cmp             w0, NULL
    // 0x9bceb8: b.eq            #0x9bcee8
    // 0x9bcebc: SaveReg r1
    //     0x9bcebc: str             x1, [SP, #-8]!
    // 0x9bcec0: r0 = systemFontsDidChange()
    //     0x9bcec0: bl              #0x9bcc60  ; [package:flutter/src/rendering/paragraph.dart] _RenderParagraph&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin&RelayoutWhenSystemFontsChangeMixin::systemFontsDidChange
    // 0x9bcec4: add             SP, SP, #8
    // 0x9bcec8: ldur            x0, [fp, #-8]
    // 0x9bcecc: LoadField: r1 = r0->field_f
    //     0x9bcecc: ldur            w1, [x0, #0xf]
    // 0x9bced0: DecompressPointer r1
    //     0x9bced0: add             x1, x1, HEAP, lsl #32
    // 0x9bced4: LoadField: r0 = r1->field_6f
    //     0x9bced4: ldur            w0, [x1, #0x6f]
    // 0x9bced8: DecompressPointer r0
    //     0x9bced8: add             x0, x0, HEAP, lsl #32
    // 0x9bcedc: SaveReg r0
    //     0x9bcedc: str             x0, [SP, #-8]!
    // 0x9bcee0: r0 = markNeedsLayout()
    //     0x9bcee0: bl              #0x62d54c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0x9bcee4: add             SP, SP, #8
    // 0x9bcee8: r0 = Null
    //     0x9bcee8: mov             x0, NULL
    // 0x9bceec: LeaveFrame
    //     0x9bceec: mov             SP, fp
    //     0x9bcef0: ldp             fp, lr, [SP], #0x10
    // 0x9bcef4: ret
    //     0x9bcef4: ret             
    // 0x9bcef8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bcef8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bcefc: b               #0x9bcea0
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5d23c, size: 0x21c
    // 0xa5d23c: EnterFrame
    //     0xa5d23c: stp             fp, lr, [SP, #-0x10]!
    //     0xa5d240: mov             fp, SP
    // 0xa5d244: AllocStack(0x18)
    //     0xa5d244: sub             SP, SP, #0x18
    // 0xa5d248: CheckStackOverflow
    //     0xa5d248: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5d24c: cmp             SP, x16
    //     0xa5d250: b.ls            #0xa5d410
    // 0xa5d254: ldr             x16, [fp, #0x18]
    // 0xa5d258: SaveReg r16
    //     0xa5d258: str             x16, [SP, #-8]!
    // 0xa5d25c: r0 = _canComputeDryLayout()
    //     0xa5d25c: bl              #0xa5d458  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_canComputeDryLayout
    // 0xa5d260: add             SP, SP, #8
    // 0xa5d264: tbz             w0, #4, #0xa5d278
    // 0xa5d268: r0 = Instance_Size
    //     0xa5d268: ldr             x0, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0xa5d26c: LeaveFrame
    //     0xa5d26c: mov             SP, fp
    //     0xa5d270: ldp             fp, lr, [SP], #0x10
    // 0xa5d274: ret
    //     0xa5d274: ret             
    // 0xa5d278: ldr             x1, [fp, #0x18]
    // 0xa5d27c: ldr             x0, [fp, #0x10]
    // 0xa5d280: LoadField: r2 = r1->field_6f
    //     0xa5d280: ldur            w2, [x1, #0x6f]
    // 0xa5d284: DecompressPointer r2
    //     0xa5d284: add             x2, x2, HEAP, lsl #32
    // 0xa5d288: stur            x2, [fp, #-8]
    // 0xa5d28c: stp             x0, x1, [SP, #-0x10]!
    // 0xa5d290: r16 = true
    //     0xa5d290: add             x16, NULL, #0x20  ; true
    // 0xa5d294: SaveReg r16
    //     0xa5d294: str             x16, [SP, #-8]!
    // 0xa5d298: r4 = const [0, 0x3, 0x3, 0x2, dry, 0x2, null]
    //     0xa5d298: add             x4, PP, #0x22, lsl #12  ; [pp+0x22470] List(7) [0, 0x3, 0x3, 0x2, "dry", 0x2, Null]
    //     0xa5d29c: ldr             x4, [x4, #0x470]
    // 0xa5d2a0: r0 = _layoutChildren()
    //     0xa5d2a0: bl              #0x68e078  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_layoutChildren
    // 0xa5d2a4: add             SP, SP, #0x18
    // 0xa5d2a8: ldur            x16, [fp, #-8]
    // 0xa5d2ac: stp             x0, x16, [SP, #-0x10]!
    // 0xa5d2b0: r0 = setPlaceholderDimensions()
    //     0xa5d2b0: bl              #0x62d480  ; [package:flutter/src/painting/text_painter.dart] TextPainter::setPlaceholderDimensions
    // 0xa5d2b4: add             SP, SP, #0x10
    // 0xa5d2b8: ldr             x0, [fp, #0x10]
    // 0xa5d2bc: LoadField: d0 = r0->field_7
    //     0xa5d2bc: ldur            d0, [x0, #7]
    // 0xa5d2c0: LoadField: d1 = r0->field_f
    //     0xa5d2c0: ldur            d1, [x0, #0xf]
    // 0xa5d2c4: r1 = inline_Allocate_Double()
    //     0xa5d2c4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xa5d2c8: add             x1, x1, #0x10
    //     0xa5d2cc: cmp             x2, x1
    //     0xa5d2d0: b.ls            #0xa5d418
    //     0xa5d2d4: str             x1, [THR, #0x60]  ; THR::top
    //     0xa5d2d8: sub             x1, x1, #0xf
    //     0xa5d2dc: mov             x2, #0xd108
    //     0xa5d2e0: movk            x2, #3, lsl #16
    //     0xa5d2e4: stur            x2, [x1, #-1]
    // 0xa5d2e8: StoreField: r1->field_7 = d0
    //     0xa5d2e8: stur            d0, [x1, #7]
    // 0xa5d2ec: r2 = inline_Allocate_Double()
    //     0xa5d2ec: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xa5d2f0: add             x2, x2, #0x10
    //     0xa5d2f4: cmp             x3, x2
    //     0xa5d2f8: b.ls            #0xa5d434
    //     0xa5d2fc: str             x2, [THR, #0x60]  ; THR::top
    //     0xa5d300: sub             x2, x2, #0xf
    //     0xa5d304: mov             x3, #0xd108
    //     0xa5d308: movk            x3, #3, lsl #16
    //     0xa5d30c: stur            x3, [x2, #-1]
    // 0xa5d310: StoreField: r2->field_7 = d1
    //     0xa5d310: stur            d1, [x2, #7]
    // 0xa5d314: ldr             x16, [fp, #0x18]
    // 0xa5d318: stp             x1, x16, [SP, #-0x10]!
    // 0xa5d31c: SaveReg r2
    //     0xa5d31c: str             x2, [SP, #-8]!
    // 0xa5d320: r4 = const [0, 0x3, 0x3, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0xa5d320: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f588] List(9) [0, 0x3, 0x3, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    //     0xa5d324: ldr             x4, [x4, #0x588]
    // 0xa5d328: r0 = _layoutText()
    //     0xa5d328: bl              #0x62db8c  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_layoutText
    // 0xa5d32c: add             SP, SP, #0x18
    // 0xa5d330: ldur            x0, [fp, #-8]
    // 0xa5d334: LoadField: r1 = r0->field_7
    //     0xa5d334: ldur            w1, [x0, #7]
    // 0xa5d338: DecompressPointer r1
    //     0xa5d338: add             x1, x1, HEAP, lsl #32
    // 0xa5d33c: cmp             w1, NULL
    // 0xa5d340: b.eq            #0xa5d450
    // 0xa5d344: SaveReg r1
    //     0xa5d344: str             x1, [SP, #-8]!
    // 0xa5d348: r0 = width()
    //     0xa5d348: bl              #0x520ee4  ; [dart:ui] Paragraph::width
    // 0xa5d34c: add             SP, SP, #8
    // 0xa5d350: stp             fp, lr, [SP, #-0x10]!
    // 0xa5d354: mov             fp, SP
    // 0xa5d358: CallRuntime_LibcCeil(double) -> double
    //     0xa5d358: and             SP, SP, #0xfffffffffffffff0
    //     0xa5d35c: mov             sp, SP
    //     0xa5d360: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0xa5d364: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xa5d368: blr             x16
    //     0xa5d36c: mov             x16, #8
    //     0xa5d370: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xa5d374: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xa5d378: sub             sp, x16, #1, lsl #12
    //     0xa5d37c: mov             SP, fp
    //     0xa5d380: ldp             fp, lr, [SP], #0x10
    // 0xa5d384: ldur            x0, [fp, #-8]
    // 0xa5d388: stur            d0, [fp, #-0x10]
    // 0xa5d38c: LoadField: r1 = r0->field_7
    //     0xa5d38c: ldur            w1, [x0, #7]
    // 0xa5d390: DecompressPointer r1
    //     0xa5d390: add             x1, x1, HEAP, lsl #32
    // 0xa5d394: cmp             w1, NULL
    // 0xa5d398: b.eq            #0xa5d454
    // 0xa5d39c: SaveReg r1
    //     0xa5d39c: str             x1, [SP, #-8]!
    // 0xa5d3a0: r0 = height()
    //     0xa5d3a0: bl              #0x51a4dc  ; [dart:ui] Paragraph::height
    // 0xa5d3a4: add             SP, SP, #8
    // 0xa5d3a8: stp             fp, lr, [SP, #-0x10]!
    // 0xa5d3ac: mov             fp, SP
    // 0xa5d3b0: CallRuntime_LibcCeil(double) -> double
    //     0xa5d3b0: and             SP, SP, #0xfffffffffffffff0
    //     0xa5d3b4: mov             sp, SP
    //     0xa5d3b8: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0xa5d3bc: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xa5d3c0: blr             x16
    //     0xa5d3c4: mov             x16, #8
    //     0xa5d3c8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xa5d3cc: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xa5d3d0: sub             sp, x16, #1, lsl #12
    //     0xa5d3d4: mov             SP, fp
    //     0xa5d3d8: ldp             fp, lr, [SP], #0x10
    // 0xa5d3dc: stur            d0, [fp, #-0x18]
    // 0xa5d3e0: r0 = Size()
    //     0xa5d3e0: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xa5d3e4: ldur            d0, [fp, #-0x10]
    // 0xa5d3e8: StoreField: r0->field_7 = d0
    //     0xa5d3e8: stur            d0, [x0, #7]
    // 0xa5d3ec: ldur            d0, [fp, #-0x18]
    // 0xa5d3f0: StoreField: r0->field_f = d0
    //     0xa5d3f0: stur            d0, [x0, #0xf]
    // 0xa5d3f4: ldr             x16, [fp, #0x10]
    // 0xa5d3f8: stp             x0, x16, [SP, #-0x10]!
    // 0xa5d3fc: r0 = constrain()
    //     0xa5d3fc: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xa5d400: add             SP, SP, #0x10
    // 0xa5d404: LeaveFrame
    //     0xa5d404: mov             SP, fp
    //     0xa5d408: ldp             fp, lr, [SP], #0x10
    // 0xa5d40c: ret
    //     0xa5d40c: ret             
    // 0xa5d410: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5d410: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5d414: b               #0xa5d254
    // 0xa5d418: stp             q0, q1, [SP, #-0x20]!
    // 0xa5d41c: SaveReg r0
    //     0xa5d41c: str             x0, [SP, #-8]!
    // 0xa5d420: r0 = AllocateDouble()
    //     0xa5d420: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa5d424: mov             x1, x0
    // 0xa5d428: RestoreReg r0
    //     0xa5d428: ldr             x0, [SP], #8
    // 0xa5d42c: ldp             q0, q1, [SP], #0x20
    // 0xa5d430: b               #0xa5d2e8
    // 0xa5d434: SaveReg d1
    //     0xa5d434: str             q1, [SP, #-0x10]!
    // 0xa5d438: stp             x0, x1, [SP, #-0x10]!
    // 0xa5d43c: r0 = AllocateDouble()
    //     0xa5d43c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa5d440: mov             x2, x0
    // 0xa5d444: ldp             x0, x1, [SP], #0x10
    // 0xa5d448: RestoreReg d1
    //     0xa5d448: ldr             q1, [SP], #0x10
    // 0xa5d44c: b               #0xa5d310
    // 0xa5d450: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa5d450: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa5d454: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa5d454: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _canComputeDryLayout(/* No info */) {
    // ** addr: 0xa5d458, size: 0x1b0
    // 0xa5d458: EnterFrame
    //     0xa5d458: stp             fp, lr, [SP, #-0x10]!
    //     0xa5d45c: mov             fp, SP
    // 0xa5d460: AllocStack(0x30)
    //     0xa5d460: sub             SP, SP, #0x30
    // 0xa5d464: CheckStackOverflow
    //     0xa5d464: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5d468: cmp             SP, x16
    //     0xa5d46c: b.ls            #0xa5d5ec
    // 0xa5d470: ldr             x0, [fp, #0x10]
    // 0xa5d474: LoadField: r1 = r0->field_83
    //     0xa5d474: ldur            w1, [x0, #0x83]
    // 0xa5d478: DecompressPointer r1
    //     0xa5d478: add             x1, x1, HEAP, lsl #32
    // 0xa5d47c: r16 = Sentinel
    //     0xa5d47c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa5d480: cmp             w1, w16
    // 0xa5d484: b.eq            #0xa5d5f4
    // 0xa5d488: stur            x1, [fp, #-0x20]
    // 0xa5d48c: LoadField: r2 = r1->field_7
    //     0xa5d48c: ldur            w2, [x1, #7]
    // 0xa5d490: DecompressPointer r2
    //     0xa5d490: add             x2, x2, HEAP, lsl #32
    // 0xa5d494: stur            x2, [fp, #-0x18]
    // 0xa5d498: LoadField: r0 = r1->field_b
    //     0xa5d498: ldur            w0, [x1, #0xb]
    // 0xa5d49c: DecompressPointer r0
    //     0xa5d49c: add             x0, x0, HEAP, lsl #32
    // 0xa5d4a0: r3 = LoadInt32Instr(r0)
    //     0xa5d4a0: sbfx            x3, x0, #1, #0x1f
    // 0xa5d4a4: stur            x3, [fp, #-0x10]
    // 0xa5d4a8: r4 = 0
    //     0xa5d4a8: mov             x4, #0
    // 0xa5d4ac: stur            x4, [fp, #-8]
    // 0xa5d4b0: CheckStackOverflow
    //     0xa5d4b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5d4b4: cmp             SP, x16
    //     0xa5d4b8: b.ls            #0xa5d600
    // 0xa5d4bc: r0 = LoadClassIdInstr(r1)
    //     0xa5d4bc: ldur            x0, [x1, #-1]
    //     0xa5d4c0: ubfx            x0, x0, #0xc, #0x14
    // 0xa5d4c4: SaveReg r1
    //     0xa5d4c4: str             x1, [SP, #-8]!
    // 0xa5d4c8: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa5d4c8: mov             x17, #0xb8ea
    //     0xa5d4cc: add             lr, x0, x17
    //     0xa5d4d0: ldr             lr, [x21, lr, lsl #3]
    //     0xa5d4d4: blr             lr
    // 0xa5d4d8: add             SP, SP, #8
    // 0xa5d4dc: r1 = LoadInt32Instr(r0)
    //     0xa5d4dc: sbfx            x1, x0, #1, #0x1f
    //     0xa5d4e0: tbz             w0, #0, #0xa5d4e8
    //     0xa5d4e4: ldur            x1, [x0, #7]
    // 0xa5d4e8: ldur            x2, [fp, #-0x10]
    // 0xa5d4ec: cmp             x2, x1
    // 0xa5d4f0: b.ne            #0xa5d5d4
    // 0xa5d4f4: ldur            x3, [fp, #-0x20]
    // 0xa5d4f8: ldur            x4, [fp, #-8]
    // 0xa5d4fc: cmp             x4, x1
    // 0xa5d500: b.lt            #0xa5d514
    // 0xa5d504: r0 = true
    //     0xa5d504: add             x0, NULL, #0x20  ; true
    // 0xa5d508: LeaveFrame
    //     0xa5d508: mov             SP, fp
    //     0xa5d50c: ldp             fp, lr, [SP], #0x10
    // 0xa5d510: ret
    //     0xa5d510: ret             
    // 0xa5d514: r0 = BoxInt64Instr(r4)
    //     0xa5d514: sbfiz           x0, x4, #1, #0x1f
    //     0xa5d518: cmp             x4, x0, asr #1
    //     0xa5d51c: b.eq            #0xa5d528
    //     0xa5d520: bl              #0xd69bb8
    //     0xa5d524: stur            x4, [x0, #7]
    // 0xa5d528: r1 = LoadClassIdInstr(r3)
    //     0xa5d528: ldur            x1, [x3, #-1]
    //     0xa5d52c: ubfx            x1, x1, #0xc, #0x14
    // 0xa5d530: stp             x0, x3, [SP, #-0x10]!
    // 0xa5d534: mov             x0, x1
    // 0xa5d538: r0 = GDT[cid_x0 + 0xd175]()
    //     0xa5d538: mov             x17, #0xd175
    //     0xa5d53c: add             lr, x0, x17
    //     0xa5d540: ldr             lr, [x21, lr, lsl #3]
    //     0xa5d544: blr             lr
    // 0xa5d548: add             SP, SP, #0x10
    // 0xa5d54c: mov             x3, x0
    // 0xa5d550: ldur            x0, [fp, #-8]
    // 0xa5d554: stur            x3, [fp, #-0x30]
    // 0xa5d558: add             x4, x0, #1
    // 0xa5d55c: stur            x4, [fp, #-0x28]
    // 0xa5d560: cmp             w3, NULL
    // 0xa5d564: b.ne            #0xa5d598
    // 0xa5d568: mov             x0, x3
    // 0xa5d56c: ldur            x2, [fp, #-0x18]
    // 0xa5d570: r1 = Null
    //     0xa5d570: mov             x1, NULL
    // 0xa5d574: cmp             w2, NULL
    // 0xa5d578: b.eq            #0xa5d598
    // 0xa5d57c: LoadField: r4 = r2->field_17
    //     0xa5d57c: ldur            w4, [x2, #0x17]
    // 0xa5d580: DecompressPointer r4
    //     0xa5d580: add             x4, x4, HEAP, lsl #32
    // 0xa5d584: r8 = X0
    //     0xa5d584: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa5d588: LoadField: r9 = r4->field_7
    //     0xa5d588: ldur            x9, [x4, #7]
    // 0xa5d58c: r3 = Null
    //     0xa5d58c: add             x3, PP, #0x22, lsl #12  ; [pp+0x22478] Null
    //     0xa5d590: ldr             x3, [x3, #0x478]
    // 0xa5d594: blr             x9
    // 0xa5d598: ldur            x1, [fp, #-0x30]
    // 0xa5d59c: LoadField: r2 = r1->field_b
    //     0xa5d59c: ldur            w2, [x1, #0xb]
    // 0xa5d5a0: DecompressPointer r2
    //     0xa5d5a0: add             x2, x2, HEAP, lsl #32
    // 0xa5d5a4: LoadField: r1 = r2->field_7
    //     0xa5d5a4: ldur            x1, [x2, #7]
    // 0xa5d5a8: cmp             x1, #2
    // 0xa5d5ac: b.gt            #0xa5d5c0
    // 0xa5d5b0: r0 = false
    //     0xa5d5b0: add             x0, NULL, #0x30  ; false
    // 0xa5d5b4: LeaveFrame
    //     0xa5d5b4: mov             SP, fp
    //     0xa5d5b8: ldp             fp, lr, [SP], #0x10
    // 0xa5d5bc: ret
    //     0xa5d5bc: ret             
    // 0xa5d5c0: ldur            x4, [fp, #-0x28]
    // 0xa5d5c4: ldur            x1, [fp, #-0x20]
    // 0xa5d5c8: ldur            x2, [fp, #-0x18]
    // 0xa5d5cc: ldur            x3, [fp, #-0x10]
    // 0xa5d5d0: b               #0xa5d4ac
    // 0xa5d5d4: ldur            x0, [fp, #-0x20]
    // 0xa5d5d8: r0 = ConcurrentModificationError()
    //     0xa5d5d8: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xa5d5dc: ldur            x3, [fp, #-0x20]
    // 0xa5d5e0: StoreField: r0->field_b = r3
    //     0xa5d5e0: stur            w3, [x0, #0xb]
    // 0xa5d5e4: r0 = Throw()
    //     0xa5d5e4: bl              #0xd67e38  ; ThrowStub
    // 0xa5d5e8: brk             #0
    // 0xa5d5ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5d5ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5d5f0: b               #0xa5d470
    // 0xa5d5f4: r9 = _placeholderSpans
    //     0xa5d5f4: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d468] Field <RenderParagraph._placeholderSpans@507149678>: late (offset: 0x84)
    //     0xa5d5f8: ldr             x9, [x9, #0x468]
    // 0xa5d5fc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa5d5fc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa5d600: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5d600: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5d604: b               #0xa5d4bc
  }
  [closure] bool <anonymous closure>(dynamic, InlineSpanSemanticsInformation) {
    // ** addr: 0xc9fb98, size: 0x20
    // 0xc9fb98: ldr             x1, [SP]
    // 0xc9fb9c: LoadField: r2 = r1->field_f
    //     0xc9fb9c: ldur            w2, [x1, #0xf]
    // 0xc9fba0: DecompressPointer r2
    //     0xc9fba0: add             x2, x2, HEAP, lsl #32
    // 0xc9fba4: cmp             w2, NULL
    // 0xc9fba8: r16 = true
    //     0xc9fba8: add             x16, NULL, #0x20  ; true
    // 0xc9fbac: r17 = false
    //     0xc9fbac: add             x17, NULL, #0x30  ; false
    // 0xc9fbb0: csel            x0, x16, x17, ne
    // 0xc9fbb4: ret
    //     0xc9fbb4: ret             
  }
  _ _getOffsetForPosition(/* No info */) {
    // ** addr: 0xd03bd0, size: 0x94
    // 0xd03bd0: EnterFrame
    //     0xd03bd0: stp             fp, lr, [SP, #-0x10]!
    //     0xd03bd4: mov             fp, SP
    // 0xd03bd8: AllocStack(0x10)
    //     0xd03bd8: sub             SP, SP, #0x10
    // 0xd03bdc: CheckStackOverflow
    //     0xd03bdc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd03be0: cmp             SP, x16
    //     0xd03be4: b.ls            #0xd03c5c
    // 0xd03be8: ldr             x16, [fp, #0x18]
    // 0xd03bec: ldr             lr, [fp, #0x10]
    // 0xd03bf0: stp             lr, x16, [SP, #-0x10]!
    // 0xd03bf4: r0 = getOffsetForCaret()
    //     0xd03bf4: bl              #0xd03d34  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::getOffsetForCaret
    // 0xd03bf8: add             SP, SP, #0x10
    // 0xd03bfc: stur            x0, [fp, #-8]
    // 0xd03c00: ldr             x16, [fp, #0x18]
    // 0xd03c04: ldr             lr, [fp, #0x10]
    // 0xd03c08: stp             lr, x16, [SP, #-0x10]!
    // 0xd03c0c: r0 = getFullHeightForCaret()
    //     0xd03c0c: bl              #0xd03c64  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::getFullHeightForCaret
    // 0xd03c10: add             SP, SP, #0x10
    // 0xd03c14: cmp             w0, NULL
    // 0xd03c18: b.ne            #0xd03c24
    // 0xd03c1c: d0 = 0.000000
    //     0xd03c1c: eor             v0.16b, v0.16b, v0.16b
    // 0xd03c20: b               #0xd03c28
    // 0xd03c24: LoadField: d0 = r0->field_7
    //     0xd03c24: ldur            d0, [x0, #7]
    // 0xd03c28: stur            d0, [fp, #-0x10]
    // 0xd03c2c: r0 = Offset()
    //     0xd03c2c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xd03c30: d0 = 0.000000
    //     0xd03c30: eor             v0.16b, v0.16b, v0.16b
    // 0xd03c34: StoreField: r0->field_7 = d0
    //     0xd03c34: stur            d0, [x0, #7]
    // 0xd03c38: ldur            d0, [fp, #-0x10]
    // 0xd03c3c: StoreField: r0->field_f = d0
    //     0xd03c3c: stur            d0, [x0, #0xf]
    // 0xd03c40: ldur            x16, [fp, #-8]
    // 0xd03c44: stp             x0, x16, [SP, #-0x10]!
    // 0xd03c48: r0 = +()
    //     0xd03c48: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0xd03c4c: add             SP, SP, #0x10
    // 0xd03c50: LeaveFrame
    //     0xd03c50: mov             SP, fp
    //     0xd03c54: ldp             fp, lr, [SP], #0x10
    // 0xd03c58: ret
    //     0xd03c58: ret             
    // 0xd03c5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03c5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03c60: b               #0xd03be8
  }
  _ getFullHeightForCaret(/* No info */) {
    // ** addr: 0xd03c64, size: 0xd0
    // 0xd03c64: EnterFrame
    //     0xd03c64: stp             fp, lr, [SP, #-0x10]!
    //     0xd03c68: mov             fp, SP
    // 0xd03c6c: AllocStack(0x8)
    //     0xd03c6c: sub             SP, SP, #8
    // 0xd03c70: CheckStackOverflow
    //     0xd03c70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd03c74: cmp             SP, x16
    //     0xd03c78: b.ls            #0xd03d2c
    // 0xd03c7c: ldr             x3, [fp, #0x18]
    // 0xd03c80: LoadField: r4 = r3->field_27
    //     0xd03c80: ldur            w4, [x3, #0x27]
    // 0xd03c84: DecompressPointer r4
    //     0xd03c84: add             x4, x4, HEAP, lsl #32
    // 0xd03c88: stur            x4, [fp, #-8]
    // 0xd03c8c: cmp             w4, NULL
    // 0xd03c90: b.eq            #0xd03d0c
    // 0xd03c94: mov             x0, x4
    // 0xd03c98: r2 = Null
    //     0xd03c98: mov             x2, NULL
    // 0xd03c9c: r1 = Null
    //     0xd03c9c: mov             x1, NULL
    // 0xd03ca0: r4 = LoadClassIdInstr(r0)
    //     0xd03ca0: ldur            x4, [x0, #-1]
    //     0xd03ca4: ubfx            x4, x4, #0xc, #0x14
    // 0xd03ca8: sub             x4, x4, #0x80d
    // 0xd03cac: cmp             x4, #1
    // 0xd03cb0: b.ls            #0xd03cc8
    // 0xd03cb4: r8 = BoxConstraints
    //     0xd03cb4: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0xd03cb8: ldr             x8, [x8, #0x1d0]
    // 0xd03cbc: r3 = Null
    //     0xd03cbc: add             x3, PP, #0x55, lsl #12  ; [pp+0x55910] Null
    //     0xd03cc0: ldr             x3, [x3, #0x910]
    // 0xd03cc4: r0 = BoxConstraints()
    //     0xd03cc4: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0xd03cc8: ldr             x16, [fp, #0x18]
    // 0xd03ccc: ldur            lr, [fp, #-8]
    // 0xd03cd0: stp             lr, x16, [SP, #-0x10]!
    // 0xd03cd4: r0 = _layoutTextWithConstraints()
    //     0xd03cd4: bl              #0x63df68  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_layoutTextWithConstraints
    // 0xd03cd8: add             SP, SP, #0x10
    // 0xd03cdc: ldr             x0, [fp, #0x18]
    // 0xd03ce0: LoadField: r1 = r0->field_6f
    //     0xd03ce0: ldur            w1, [x0, #0x6f]
    // 0xd03ce4: DecompressPointer r1
    //     0xd03ce4: add             x1, x1, HEAP, lsl #32
    // 0xd03ce8: ldr             x16, [fp, #0x10]
    // 0xd03cec: stp             x16, x1, [SP, #-0x10]!
    // 0xd03cf0: r16 = Instance_Rect
    //     0xd03cf0: ldr             x16, [PP, #0x5e48]  ; [pp+0x5e48] Obj!Rect@b5ebc1
    // 0xd03cf4: SaveReg r16
    //     0xd03cf4: str             x16, [SP, #-8]!
    // 0xd03cf8: r0 = getFullHeightForCaret()
    //     0xd03cf8: bl              #0xc4f354  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getFullHeightForCaret
    // 0xd03cfc: add             SP, SP, #0x18
    // 0xd03d00: LeaveFrame
    //     0xd03d00: mov             SP, fp
    //     0xd03d04: ldp             fp, lr, [SP], #0x10
    // 0xd03d08: ret
    //     0xd03d08: ret             
    // 0xd03d0c: r0 = StateError()
    //     0xd03d0c: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xd03d10: mov             x1, x0
    // 0xd03d14: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xd03d14: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0xd03d18: ldr             x0, [x0, #0x1e8]
    // 0xd03d1c: StoreField: r1->field_b = r0
    //     0xd03d1c: stur            w0, [x1, #0xb]
    // 0xd03d20: mov             x0, x1
    // 0xd03d24: r0 = Throw()
    //     0xd03d24: bl              #0xd67e38  ; ThrowStub
    // 0xd03d28: brk             #0
    // 0xd03d2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03d2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03d30: b               #0xd03c7c
  }
  _ getOffsetForCaret(/* No info */) {
    // ** addr: 0xd03d34, size: 0xd0
    // 0xd03d34: EnterFrame
    //     0xd03d34: stp             fp, lr, [SP, #-0x10]!
    //     0xd03d38: mov             fp, SP
    // 0xd03d3c: AllocStack(0x8)
    //     0xd03d3c: sub             SP, SP, #8
    // 0xd03d40: CheckStackOverflow
    //     0xd03d40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd03d44: cmp             SP, x16
    //     0xd03d48: b.ls            #0xd03dfc
    // 0xd03d4c: ldr             x3, [fp, #0x18]
    // 0xd03d50: LoadField: r4 = r3->field_27
    //     0xd03d50: ldur            w4, [x3, #0x27]
    // 0xd03d54: DecompressPointer r4
    //     0xd03d54: add             x4, x4, HEAP, lsl #32
    // 0xd03d58: stur            x4, [fp, #-8]
    // 0xd03d5c: cmp             w4, NULL
    // 0xd03d60: b.eq            #0xd03ddc
    // 0xd03d64: mov             x0, x4
    // 0xd03d68: r2 = Null
    //     0xd03d68: mov             x2, NULL
    // 0xd03d6c: r1 = Null
    //     0xd03d6c: mov             x1, NULL
    // 0xd03d70: r4 = LoadClassIdInstr(r0)
    //     0xd03d70: ldur            x4, [x0, #-1]
    //     0xd03d74: ubfx            x4, x4, #0xc, #0x14
    // 0xd03d78: sub             x4, x4, #0x80d
    // 0xd03d7c: cmp             x4, #1
    // 0xd03d80: b.ls            #0xd03d98
    // 0xd03d84: r8 = BoxConstraints
    //     0xd03d84: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0xd03d88: ldr             x8, [x8, #0x1d0]
    // 0xd03d8c: r3 = Null
    //     0xd03d8c: add             x3, PP, #0x55, lsl #12  ; [pp+0x55920] Null
    //     0xd03d90: ldr             x3, [x3, #0x920]
    // 0xd03d94: r0 = BoxConstraints()
    //     0xd03d94: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0xd03d98: ldr             x16, [fp, #0x18]
    // 0xd03d9c: ldur            lr, [fp, #-8]
    // 0xd03da0: stp             lr, x16, [SP, #-0x10]!
    // 0xd03da4: r0 = _layoutTextWithConstraints()
    //     0xd03da4: bl              #0x63df68  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_layoutTextWithConstraints
    // 0xd03da8: add             SP, SP, #0x10
    // 0xd03dac: ldr             x0, [fp, #0x18]
    // 0xd03db0: LoadField: r1 = r0->field_6f
    //     0xd03db0: ldur            w1, [x0, #0x6f]
    // 0xd03db4: DecompressPointer r1
    //     0xd03db4: add             x1, x1, HEAP, lsl #32
    // 0xd03db8: ldr             x16, [fp, #0x10]
    // 0xd03dbc: stp             x16, x1, [SP, #-0x10]!
    // 0xd03dc0: r16 = Instance_Rect
    //     0xd03dc0: ldr             x16, [PP, #0x5e48]  ; [pp+0x5e48] Obj!Rect@b5ebc1
    // 0xd03dc4: SaveReg r16
    //     0xd03dc4: str             x16, [SP, #-8]!
    // 0xd03dc8: r0 = getOffsetForCaret()
    //     0xd03dc8: bl              #0x520800  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getOffsetForCaret
    // 0xd03dcc: add             SP, SP, #0x18
    // 0xd03dd0: LeaveFrame
    //     0xd03dd0: mov             SP, fp
    //     0xd03dd4: ldp             fp, lr, [SP], #0x10
    // 0xd03dd8: ret
    //     0xd03dd8: ret             
    // 0xd03ddc: r0 = StateError()
    //     0xd03ddc: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xd03de0: mov             x1, x0
    // 0xd03de4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xd03de4: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0xd03de8: ldr             x0, [x0, #0x1e8]
    // 0xd03dec: StoreField: r1->field_b = r0
    //     0xd03dec: stur            w0, [x1, #0xb]
    // 0xd03df0: mov             x0, x1
    // 0xd03df4: r0 = Throw()
    //     0xd03df4: bl              #0xd67e38  ; ThrowStub
    // 0xd03df8: brk             #0
    // 0xd03dfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03dfc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03e00: b               #0xd03d4c
  }
}

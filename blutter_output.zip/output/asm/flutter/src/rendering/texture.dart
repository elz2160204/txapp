// lib: , url: package:flutter/src/rendering/texture.dart

// class id: 1049431, size: 0x8
class :: {
}

// class id: 2422, size: 0x70, field offset: 0x60
class TextureBox extends RenderBox {

  _ paint(/* No info */) {
    // ** addr: 0x671614, size: 0xf8
    // 0x671614: EnterFrame
    //     0x671614: stp             fp, lr, [SP, #-0x10]!
    //     0x671618: mov             fp, SP
    // 0x67161c: AllocStack(0x38)
    //     0x67161c: sub             SP, SP, #0x38
    // 0x671620: CheckStackOverflow
    //     0x671620: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x671624: cmp             SP, x16
    //     0x671628: b.ls            #0x671700
    // 0x67162c: ldr             x0, [fp, #0x10]
    // 0x671630: LoadField: d0 = r0->field_7
    //     0x671630: ldur            d0, [x0, #7]
    // 0x671634: stur            d0, [fp, #-0x38]
    // 0x671638: LoadField: d1 = r0->field_f
    //     0x671638: ldur            d1, [x0, #0xf]
    // 0x67163c: ldr             x0, [fp, #0x20]
    // 0x671640: stur            d1, [fp, #-0x30]
    // 0x671644: LoadField: r1 = r0->field_57
    //     0x671644: ldur            w1, [x0, #0x57]
    // 0x671648: DecompressPointer r1
    //     0x671648: add             x1, x1, HEAP, lsl #32
    // 0x67164c: cmp             w1, NULL
    // 0x671650: b.eq            #0x671708
    // 0x671654: LoadField: d2 = r1->field_7
    //     0x671654: ldur            d2, [x1, #7]
    // 0x671658: LoadField: d3 = r1->field_f
    //     0x671658: ldur            d3, [x1, #0xf]
    // 0x67165c: fadd            d4, d0, d2
    // 0x671660: stur            d4, [fp, #-0x28]
    // 0x671664: fadd            d2, d1, d3
    // 0x671668: stur            d2, [fp, #-0x20]
    // 0x67166c: r0 = Rect()
    //     0x67166c: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x671670: ldur            d0, [fp, #-0x38]
    // 0x671674: stur            x0, [fp, #-0x10]
    // 0x671678: StoreField: r0->field_7 = d0
    //     0x671678: stur            d0, [x0, #7]
    // 0x67167c: ldur            d0, [fp, #-0x30]
    // 0x671680: StoreField: r0->field_f = d0
    //     0x671680: stur            d0, [x0, #0xf]
    // 0x671684: ldur            d0, [fp, #-0x28]
    // 0x671688: StoreField: r0->field_17 = d0
    //     0x671688: stur            d0, [x0, #0x17]
    // 0x67168c: ldur            d0, [fp, #-0x20]
    // 0x671690: StoreField: r0->field_1f = d0
    //     0x671690: stur            d0, [x0, #0x1f]
    // 0x671694: ldr             x1, [fp, #0x20]
    // 0x671698: LoadField: r2 = r1->field_5f
    //     0x671698: ldur            x2, [x1, #0x5f]
    // 0x67169c: stur            x2, [fp, #-8]
    // 0x6716a0: r0 = TextureLayer()
    //     0x6716a0: bl              #0x66ef14  ; AllocateTextureLayerStub -> TextureLayer (size=0x54)
    // 0x6716a4: mov             x1, x0
    // 0x6716a8: ldur            x0, [fp, #-0x10]
    // 0x6716ac: stur            x1, [fp, #-0x18]
    // 0x6716b0: StoreField: r1->field_3f = r0
    //     0x6716b0: stur            w0, [x1, #0x3f]
    // 0x6716b4: ldur            x0, [fp, #-8]
    // 0x6716b8: StoreField: r1->field_43 = r0
    //     0x6716b8: stur            x0, [x1, #0x43]
    // 0x6716bc: r0 = false
    //     0x6716bc: add             x0, NULL, #0x30  ; false
    // 0x6716c0: StoreField: r1->field_4b = r0
    //     0x6716c0: stur            w0, [x1, #0x4b]
    // 0x6716c4: r0 = Instance_FilterQuality
    //     0x6716c4: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c548] Obj!FilterQuality@b67811
    //     0x6716c8: ldr             x0, [x0, #0x548]
    // 0x6716cc: StoreField: r1->field_4f = r0
    //     0x6716cc: stur            w0, [x1, #0x4f]
    // 0x6716d0: SaveReg r1
    //     0x6716d0: str             x1, [SP, #-8]!
    // 0x6716d4: r0 = Layer()
    //     0x6716d4: bl              #0x5bbe7c  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0x6716d8: add             SP, SP, #8
    // 0x6716dc: ldr             x16, [fp, #0x18]
    // 0x6716e0: ldur            lr, [fp, #-0x18]
    // 0x6716e4: stp             lr, x16, [SP, #-0x10]!
    // 0x6716e8: r0 = addLayer()
    //     0x6716e8: bl              #0x66eec4  ; [package:flutter/src/rendering/object.dart] PaintingContext::addLayer
    // 0x6716ec: add             SP, SP, #0x10
    // 0x6716f0: r0 = Null
    //     0x6716f0: mov             x0, NULL
    // 0x6716f4: LeaveFrame
    //     0x6716f4: mov             SP, fp
    //     0x6716f8: ldp             fp, lr, [SP], #0x10
    // 0x6716fc: ret
    //     0x6716fc: ret             
    // 0x671700: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x671700: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x671704: b               #0x67162c
    // 0x671708: r0 = NullCastErrorSharedWithFPURegs()
    //     0x671708: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  set _ textureId=(/* No info */) {
    // ** addr: 0x6d6a08, size: 0x50
    // 0x6d6a08: EnterFrame
    //     0x6d6a08: stp             fp, lr, [SP, #-0x10]!
    //     0x6d6a0c: mov             fp, SP
    // 0x6d6a10: CheckStackOverflow
    //     0x6d6a10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d6a14: cmp             SP, x16
    //     0x6d6a18: b.ls            #0x6d6a50
    // 0x6d6a1c: ldr             x0, [fp, #0x18]
    // 0x6d6a20: LoadField: r1 = r0->field_5f
    //     0x6d6a20: ldur            x1, [x0, #0x5f]
    // 0x6d6a24: ldr             x2, [fp, #0x10]
    // 0x6d6a28: cmp             x2, x1
    // 0x6d6a2c: b.eq            #0x6d6a40
    // 0x6d6a30: StoreField: r0->field_5f = r2
    //     0x6d6a30: stur            x2, [x0, #0x5f]
    // 0x6d6a34: SaveReg r0
    //     0x6d6a34: str             x0, [SP, #-8]!
    // 0x6d6a38: r0 = markNeedsPaint()
    //     0x6d6a38: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6d6a3c: add             SP, SP, #8
    // 0x6d6a40: r0 = Null
    //     0x6d6a40: mov             x0, NULL
    // 0x6d6a44: LeaveFrame
    //     0x6d6a44: mov             SP, fp
    //     0x6d6a48: ldp             fp, lr, [SP], #0x10
    // 0x6d6a4c: ret
    //     0x6d6a4c: ret             
    // 0x6d6a50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d6a50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d6a54: b               #0x6d6a1c
  }
}

// lib: , url: package:flutter/src/rendering/proxy_box.dart

// class id: 1049414, size: 0x8
class :: {

  static late final Paint _transparentPaint; // offset: 0xed8

  static Paint _transparentPaint() {
    // ** addr: 0x6649e4, size: 0x7c
    // 0x6649e4: EnterFrame
    //     0x6649e4: stp             fp, lr, [SP, #-0x10]!
    //     0x6649e8: mov             fp, SP
    // 0x6649ec: AllocStack(0x10)
    //     0x6649ec: sub             SP, SP, #0x10
    // 0x6649f0: CheckStackOverflow
    //     0x6649f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6649f4: cmp             SP, x16
    //     0x6649f8: b.ls            #0x664a58
    // 0x6649fc: r16 = 112
    //     0x6649fc: mov             x16, #0x70
    // 0x664a00: stp             x16, NULL, [SP, #-0x10]!
    // 0x664a04: r0 = ByteData()
    //     0x664a04: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x664a08: add             SP, SP, #0x10
    // 0x664a0c: stur            x0, [fp, #-8]
    // 0x664a10: r0 = Paint()
    //     0x664a10: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x664a14: mov             x1, x0
    // 0x664a18: ldur            x0, [fp, #-8]
    // 0x664a1c: stur            x1, [fp, #-0x10]
    // 0x664a20: StoreField: r1->field_7 = r0
    //     0x664a20: stur            w0, [x1, #7]
    // 0x664a24: LoadField: r2 = r0->field_17
    //     0x664a24: ldur            w2, [x0, #0x17]
    // 0x664a28: DecompressPointer r2
    //     0x664a28: add             x2, x2, HEAP, lsl #32
    // 0x664a2c: r16 = 8
    //     0x664a2c: mov             x16, #8
    // 0x664a30: stp             x16, x2, [SP, #-0x10]!
    // 0x664a34: r16 = 4278190080
    //     0x664a34: add             x16, PP, #0x28, lsl #12  ; [pp+0x28770] 0xff000000
    //     0x664a38: ldr             x16, [x16, #0x770]
    // 0x664a3c: SaveReg r16
    //     0x664a3c: str             x16, [SP, #-8]!
    // 0x664a40: r0 = _setInt32()
    //     0x664a40: bl              #0x65ff8c  ; [dart:typed_data] _TypedList::_setInt32
    // 0x664a44: add             SP, SP, #0x18
    // 0x664a48: ldur            x0, [fp, #-0x10]
    // 0x664a4c: LeaveFrame
    //     0x664a4c: mov             SP, fp
    //     0x664a50: ldp             fp, lr, [SP], #0x10
    // 0x664a54: ret
    //     0x664a54: ret             
    // 0x664a58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x664a58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x664a5c: b               #0x6649fc
  }
}

// class id: 2007, size: 0xc, field offset: 0x8
abstract class _RenderProxyBoxMixin&RenderBox&RenderObjectWithChildMixin<X0 bound RenderBox> extends Object
    implements RenderBox, RenderObjectWithChildMixin<X0 bound RenderObject> {
}

// class id: 2008, size: 0xc, field offset: 0xc
abstract class RenderProxyBoxMixin<X0 bound RenderBox> extends _RenderProxyBoxMixin&RenderBox&RenderObjectWithChildMixin<X0 bound RenderBox> {
}

// class id: 2473, size: 0x64, field offset: 0x64
//   transformed mixin,
abstract class _RenderProxyBox&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin extends _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin
     with RenderProxyBoxMixin<X0 bound RenderBox> {

  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x62ef9c, size: 0x18
    // 0x62ef9c: r4 = 0
    //     0x62ef9c: mov             x4, #0
    // 0x62efa0: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x62efa0: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b298] AnonymousClosure: (0x62efb4), in [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMaxIntrinsicHeight (0x62e908)
    //     0x62efa4: ldr             x1, [x17, #0x298]
    // 0x62efa8: r24 = BuildNonGenericMethodExtractorStub
    //     0x62efa8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x62efac: LoadField: r0 = r24->field_17
    //     0x62efac: ldur            x0, [x24, #0x17]
    // 0x62efb0: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x62efb4, size: 0x4c
    // 0x62efb4: EnterFrame
    //     0x62efb4: stp             fp, lr, [SP, #-0x10]!
    //     0x62efb8: mov             fp, SP
    // 0x62efbc: ldr             x0, [fp, #0x18]
    // 0x62efc0: LoadField: r1 = r0->field_17
    //     0x62efc0: ldur            w1, [x0, #0x17]
    // 0x62efc4: DecompressPointer r1
    //     0x62efc4: add             x1, x1, HEAP, lsl #32
    // 0x62efc8: CheckStackOverflow
    //     0x62efc8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62efcc: cmp             SP, x16
    //     0x62efd0: b.ls            #0x62eff8
    // 0x62efd4: LoadField: r0 = r1->field_f
    //     0x62efd4: ldur            w0, [x1, #0xf]
    // 0x62efd8: DecompressPointer r0
    //     0x62efd8: add             x0, x0, HEAP, lsl #32
    // 0x62efdc: ldr             x16, [fp, #0x10]
    // 0x62efe0: stp             x16, x0, [SP, #-0x10]!
    // 0x62efe4: r0 = computeMaxIntrinsicHeight()
    //     0x62efe4: bl              #0x62e908  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMaxIntrinsicHeight
    // 0x62efe8: add             SP, SP, #0x10
    // 0x62efec: LeaveFrame
    //     0x62efec: mov             SP, fp
    //     0x62eff0: ldp             fp, lr, [SP], #0x10
    // 0x62eff4: ret
    //     0x62eff4: ret             
    // 0x62eff8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62eff8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62effc: b               #0x62efd4
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x6359b4, size: 0x18
    // 0x6359b4: r4 = 0
    //     0x6359b4: mov             x4, #0
    // 0x6359b8: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x6359b8: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fce8] AnonymousClosure: (0x6359cc), in [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMaxIntrinsicWidth (0x635544)
    //     0x6359bc: ldr             x1, [x17, #0xce8]
    // 0x6359c0: r24 = BuildNonGenericMethodExtractorStub
    //     0x6359c0: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x6359c4: LoadField: r0 = r24->field_17
    //     0x6359c4: ldur            x0, [x24, #0x17]
    // 0x6359c8: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x6359cc, size: 0x4c
    // 0x6359cc: EnterFrame
    //     0x6359cc: stp             fp, lr, [SP, #-0x10]!
    //     0x6359d0: mov             fp, SP
    // 0x6359d4: ldr             x0, [fp, #0x18]
    // 0x6359d8: LoadField: r1 = r0->field_17
    //     0x6359d8: ldur            w1, [x0, #0x17]
    // 0x6359dc: DecompressPointer r1
    //     0x6359dc: add             x1, x1, HEAP, lsl #32
    // 0x6359e0: CheckStackOverflow
    //     0x6359e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6359e4: cmp             SP, x16
    //     0x6359e8: b.ls            #0x635a10
    // 0x6359ec: LoadField: r0 = r1->field_f
    //     0x6359ec: ldur            w0, [x1, #0xf]
    // 0x6359f0: DecompressPointer r0
    //     0x6359f0: add             x0, x0, HEAP, lsl #32
    // 0x6359f4: ldr             x16, [fp, #0x10]
    // 0x6359f8: stp             x16, x0, [SP, #-0x10]!
    // 0x6359fc: r0 = computeMaxIntrinsicWidth()
    //     0x6359fc: bl              #0x635544  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMaxIntrinsicWidth
    // 0x635a00: add             SP, SP, #0x10
    // 0x635a04: LeaveFrame
    //     0x635a04: mov             SP, fp
    //     0x635a08: ldp             fp, lr, [SP], #0x10
    // 0x635a0c: ret
    //     0x635a0c: ret             
    // 0x635a10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x635a10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x635a14: b               #0x6359ec
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x638be8, size: 0x18
    // 0x638be8: r4 = 0
    //     0x638be8: mov             x4, #0
    // 0x638bec: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x638bec: add             x17, PP, #0x52, lsl #12  ; [pp+0x52eb0] AnonymousClosure: (0x638c00), in [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMinIntrinsicHeight (0x63863c)
    //     0x638bf0: ldr             x1, [x17, #0xeb0]
    // 0x638bf4: r24 = BuildNonGenericMethodExtractorStub
    //     0x638bf4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x638bf8: LoadField: r0 = r24->field_17
    //     0x638bf8: ldur            x0, [x24, #0x17]
    // 0x638bfc: br              x0
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x638c00, size: 0x4c
    // 0x638c00: EnterFrame
    //     0x638c00: stp             fp, lr, [SP, #-0x10]!
    //     0x638c04: mov             fp, SP
    // 0x638c08: ldr             x0, [fp, #0x18]
    // 0x638c0c: LoadField: r1 = r0->field_17
    //     0x638c0c: ldur            w1, [x0, #0x17]
    // 0x638c10: DecompressPointer r1
    //     0x638c10: add             x1, x1, HEAP, lsl #32
    // 0x638c14: CheckStackOverflow
    //     0x638c14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x638c18: cmp             SP, x16
    //     0x638c1c: b.ls            #0x638c44
    // 0x638c20: LoadField: r0 = r1->field_f
    //     0x638c20: ldur            w0, [x1, #0xf]
    // 0x638c24: DecompressPointer r0
    //     0x638c24: add             x0, x0, HEAP, lsl #32
    // 0x638c28: ldr             x16, [fp, #0x10]
    // 0x638c2c: stp             x16, x0, [SP, #-0x10]!
    // 0x638c30: r0 = computeMinIntrinsicHeight()
    //     0x638c30: bl              #0x63863c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMinIntrinsicHeight
    // 0x638c34: add             SP, SP, #0x10
    // 0x638c38: LeaveFrame
    //     0x638c38: mov             SP, fp
    //     0x638c3c: ldp             fp, lr, [SP], #0x10
    // 0x638c40: ret
    //     0x638c40: ret             
    // 0x638c44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x638c44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x638c48: b               #0x638c20
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63b824, size: 0x18
    // 0x63b824: r4 = 0
    //     0x63b824: mov             x4, #0
    // 0x63b828: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63b828: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fdb0] AnonymousClosure: (0x63b83c), in [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMinIntrinsicWidth (0x63b368)
    //     0x63b82c: ldr             x1, [x17, #0xdb0]
    // 0x63b830: r24 = BuildNonGenericMethodExtractorStub
    //     0x63b830: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63b834: LoadField: r0 = r24->field_17
    //     0x63b834: ldur            x0, [x24, #0x17]
    // 0x63b838: br              x0
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63b83c, size: 0x4c
    // 0x63b83c: EnterFrame
    //     0x63b83c: stp             fp, lr, [SP, #-0x10]!
    //     0x63b840: mov             fp, SP
    // 0x63b844: ldr             x0, [fp, #0x18]
    // 0x63b848: LoadField: r1 = r0->field_17
    //     0x63b848: ldur            w1, [x0, #0x17]
    // 0x63b84c: DecompressPointer r1
    //     0x63b84c: add             x1, x1, HEAP, lsl #32
    // 0x63b850: CheckStackOverflow
    //     0x63b850: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63b854: cmp             SP, x16
    //     0x63b858: b.ls            #0x63b880
    // 0x63b85c: LoadField: r0 = r1->field_f
    //     0x63b85c: ldur            w0, [x1, #0xf]
    // 0x63b860: DecompressPointer r0
    //     0x63b860: add             x0, x0, HEAP, lsl #32
    // 0x63b864: ldr             x16, [fp, #0x10]
    // 0x63b868: stp             x16, x0, [SP, #-0x10]!
    // 0x63b86c: r0 = computeMinIntrinsicWidth()
    //     0x63b86c: bl              #0x63b368  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMinIntrinsicWidth
    // 0x63b870: add             SP, SP, #0x10
    // 0x63b874: LeaveFrame
    //     0x63b874: mov             SP, fp
    //     0x63b878: ldp             fp, lr, [SP], #0x10
    // 0x63b87c: ret
    //     0x63b87c: ret             
    // 0x63b880: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63b880: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63b884: b               #0x63b85c
  }
  [closure] void paint(dynamic, PaintingContext, Offset) {
    // ** addr: 0x661630, size: 0x54
    // 0x661630: EnterFrame
    //     0x661630: stp             fp, lr, [SP, #-0x10]!
    //     0x661634: mov             fp, SP
    // 0x661638: ldr             x0, [fp, #0x20]
    // 0x66163c: LoadField: r1 = r0->field_17
    //     0x66163c: ldur            w1, [x0, #0x17]
    // 0x661640: DecompressPointer r1
    //     0x661640: add             x1, x1, HEAP, lsl #32
    // 0x661644: CheckStackOverflow
    //     0x661644: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x661648: cmp             SP, x16
    //     0x66164c: b.ls            #0x66167c
    // 0x661650: LoadField: r0 = r1->field_f
    //     0x661650: ldur            w0, [x1, #0xf]
    // 0x661654: DecompressPointer r0
    //     0x661654: add             x0, x0, HEAP, lsl #32
    // 0x661658: ldr             x16, [fp, #0x18]
    // 0x66165c: stp             x16, x0, [SP, #-0x10]!
    // 0x661660: ldr             x16, [fp, #0x10]
    // 0x661664: SaveReg r16
    //     0x661664: str             x16, [SP, #-8]!
    // 0x661668: r0 = paint()
    //     0x661668: bl              #0x669ddc  ; [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::paint
    // 0x66166c: add             SP, SP, #0x18
    // 0x661670: LeaveFrame
    //     0x661670: mov             SP, fp
    //     0x661674: ldp             fp, lr, [SP], #0x10
    // 0x661678: ret
    //     0x661678: ret             
    // 0x66167c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66167c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x661680: b               #0x661650
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x68fff8, size: 0x1f4
    // 0x68fff8: EnterFrame
    //     0x68fff8: stp             fp, lr, [SP, #-0x10]!
    //     0x68fffc: mov             fp, SP
    // 0x690000: AllocStack(0x10)
    //     0x690000: sub             SP, SP, #0x10
    // 0x690004: CheckStackOverflow
    //     0x690004: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x690008: cmp             SP, x16
    //     0x69000c: b.ls            #0x6901dc
    // 0x690010: ldr             x3, [fp, #0x10]
    // 0x690014: LoadField: r4 = r3->field_5f
    //     0x690014: ldur            w4, [x3, #0x5f]
    // 0x690018: DecompressPointer r4
    //     0x690018: add             x4, x4, HEAP, lsl #32
    // 0x69001c: stur            x4, [fp, #-0x10]
    // 0x690020: cmp             w4, NULL
    // 0x690024: b.eq            #0x6900f4
    // 0x690028: LoadField: r5 = r3->field_27
    //     0x690028: ldur            w5, [x3, #0x27]
    // 0x69002c: DecompressPointer r5
    //     0x69002c: add             x5, x5, HEAP, lsl #32
    // 0x690030: stur            x5, [fp, #-8]
    // 0x690034: cmp             w5, NULL
    // 0x690038: b.eq            #0x69019c
    // 0x69003c: mov             x0, x5
    // 0x690040: r2 = Null
    //     0x690040: mov             x2, NULL
    // 0x690044: r1 = Null
    //     0x690044: mov             x1, NULL
    // 0x690048: r4 = LoadClassIdInstr(r0)
    //     0x690048: ldur            x4, [x0, #-1]
    //     0x69004c: ubfx            x4, x4, #0xc, #0x14
    // 0x690050: sub             x4, x4, #0x80d
    // 0x690054: cmp             x4, #1
    // 0x690058: b.ls            #0x690070
    // 0x69005c: r8 = BoxConstraints
    //     0x69005c: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x690060: ldr             x8, [x8, #0x1d0]
    // 0x690064: r3 = Null
    //     0x690064: add             x3, PP, #0x15, lsl #12  ; [pp+0x15230] Null
    //     0x690068: ldr             x3, [x3, #0x230]
    // 0x69006c: r0 = BoxConstraints()
    //     0x69006c: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x690070: ldur            x0, [fp, #-0x10]
    // 0x690074: r1 = LoadClassIdInstr(r0)
    //     0x690074: ldur            x1, [x0, #-1]
    //     0x690078: ubfx            x1, x1, #0xc, #0x14
    // 0x69007c: ldur            x16, [fp, #-8]
    // 0x690080: stp             x16, x0, [SP, #-0x10]!
    // 0x690084: r16 = true
    //     0x690084: add             x16, NULL, #0x20  ; true
    // 0x690088: SaveReg r16
    //     0x690088: str             x16, [SP, #-8]!
    // 0x69008c: mov             x0, x1
    // 0x690090: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x690090: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x690094: ldr             x4, [x4, #0x1c8]
    // 0x690098: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x690098: mov             x17, #0xcdfb
    //     0x69009c: add             lr, x0, x17
    //     0x6900a0: ldr             lr, [x21, lr, lsl #3]
    //     0x6900a4: blr             lr
    // 0x6900a8: add             SP, SP, #0x18
    // 0x6900ac: ldr             x3, [fp, #0x10]
    // 0x6900b0: LoadField: r0 = r3->field_5f
    //     0x6900b0: ldur            w0, [x3, #0x5f]
    // 0x6900b4: DecompressPointer r0
    //     0x6900b4: add             x0, x0, HEAP, lsl #32
    // 0x6900b8: cmp             w0, NULL
    // 0x6900bc: b.eq            #0x6901e4
    // 0x6900c0: LoadField: r1 = r0->field_57
    //     0x6900c0: ldur            w1, [x0, #0x57]
    // 0x6900c4: DecompressPointer r1
    //     0x6900c4: add             x1, x1, HEAP, lsl #32
    // 0x6900c8: cmp             w1, NULL
    // 0x6900cc: b.eq            #0x6901e8
    // 0x6900d0: mov             x0, x1
    // 0x6900d4: StoreField: r3->field_57 = r0
    //     0x6900d4: stur            w0, [x3, #0x57]
    //     0x6900d8: ldurb           w16, [x3, #-1]
    //     0x6900dc: ldurb           w17, [x0, #-1]
    //     0x6900e0: and             x16, x17, x16, lsr #2
    //     0x6900e4: tst             x16, HEAP, lsr #32
    //     0x6900e8: b.eq            #0x6900f0
    //     0x6900ec: bl              #0xd682ac
    // 0x6900f0: b               #0x69018c
    // 0x6900f4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6900f4: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6900f8: ldr             x0, [x0, #0x1e8]
    // 0x6900fc: LoadField: r4 = r3->field_27
    //     0x6900fc: ldur            w4, [x3, #0x27]
    // 0x690100: DecompressPointer r4
    //     0x690100: add             x4, x4, HEAP, lsl #32
    // 0x690104: stur            x4, [fp, #-8]
    // 0x690108: cmp             w4, NULL
    // 0x69010c: b.eq            #0x6901bc
    // 0x690110: mov             x0, x4
    // 0x690114: r2 = Null
    //     0x690114: mov             x2, NULL
    // 0x690118: r1 = Null
    //     0x690118: mov             x1, NULL
    // 0x69011c: r4 = LoadClassIdInstr(r0)
    //     0x69011c: ldur            x4, [x0, #-1]
    //     0x690120: ubfx            x4, x4, #0xc, #0x14
    // 0x690124: sub             x4, x4, #0x80d
    // 0x690128: cmp             x4, #1
    // 0x69012c: b.ls            #0x690144
    // 0x690130: r8 = BoxConstraints
    //     0x690130: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x690134: ldr             x8, [x8, #0x1d0]
    // 0x690138: r3 = Null
    //     0x690138: add             x3, PP, #0x15, lsl #12  ; [pp+0x15240] Null
    //     0x69013c: ldr             x3, [x3, #0x240]
    // 0x690140: r0 = BoxConstraints()
    //     0x690140: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x690144: ldr             x1, [fp, #0x10]
    // 0x690148: r0 = LoadClassIdInstr(r1)
    //     0x690148: ldur            x0, [x1, #-1]
    //     0x69014c: ubfx            x0, x0, #0xc, #0x14
    // 0x690150: ldur            x16, [fp, #-8]
    // 0x690154: stp             x16, x1, [SP, #-0x10]!
    // 0x690158: r0 = GDT[cid_x0 + 0x1c05]()
    //     0x690158: mov             x17, #0x1c05
    //     0x69015c: add             lr, x0, x17
    //     0x690160: ldr             lr, [x21, lr, lsl #3]
    //     0x690164: blr             lr
    // 0x690168: add             SP, SP, #0x10
    // 0x69016c: ldr             x1, [fp, #0x10]
    // 0x690170: StoreField: r1->field_57 = r0
    //     0x690170: stur            w0, [x1, #0x57]
    //     0x690174: ldurb           w16, [x1, #-1]
    //     0x690178: ldurb           w17, [x0, #-1]
    //     0x69017c: and             x16, x17, x16, lsr #2
    //     0x690180: tst             x16, HEAP, lsr #32
    //     0x690184: b.eq            #0x69018c
    //     0x690188: bl              #0xd6826c
    // 0x69018c: r0 = Null
    //     0x69018c: mov             x0, NULL
    // 0x690190: LeaveFrame
    //     0x690190: mov             SP, fp
    //     0x690194: ldp             fp, lr, [SP], #0x10
    // 0x690198: ret
    //     0x690198: ret             
    // 0x69019c: r0 = StateError()
    //     0x69019c: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6901a0: mov             x1, x0
    // 0x6901a4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6901a4: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6901a8: ldr             x0, [x0, #0x1e8]
    // 0x6901ac: StoreField: r1->field_b = r0
    //     0x6901ac: stur            w0, [x1, #0xb]
    // 0x6901b0: mov             x0, x1
    // 0x6901b4: r0 = Throw()
    //     0x6901b4: bl              #0xd67e38  ; ThrowStub
    // 0x6901b8: brk             #0
    // 0x6901bc: r0 = StateError()
    //     0x6901bc: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6901c0: mov             x1, x0
    // 0x6901c4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6901c4: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6901c8: ldr             x0, [x0, #0x1e8]
    // 0x6901cc: StoreField: r1->field_b = r0
    //     0x6901cc: stur            w0, [x1, #0xb]
    // 0x6901d0: mov             x0, x1
    // 0x6901d4: r0 = Throw()
    //     0x6901d4: bl              #0xd67e38  ; ThrowStub
    // 0x6901d8: brk             #0
    // 0x6901dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6901dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6901e0: b               #0x690010
    // 0x6901e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6901e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6901e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6901e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5d968, size: 0x80
    // 0xa5d968: EnterFrame
    //     0xa5d968: stp             fp, lr, [SP, #-0x10]!
    //     0xa5d96c: mov             fp, SP
    // 0xa5d970: CheckStackOverflow
    //     0xa5d970: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5d974: cmp             SP, x16
    //     0xa5d978: b.ls            #0xa5d9e0
    // 0xa5d97c: ldr             x0, [fp, #0x18]
    // 0xa5d980: LoadField: r1 = r0->field_5f
    //     0xa5d980: ldur            w1, [x0, #0x5f]
    // 0xa5d984: DecompressPointer r1
    //     0xa5d984: add             x1, x1, HEAP, lsl #32
    // 0xa5d988: cmp             w1, NULL
    // 0xa5d98c: b.eq            #0xa5d9ac
    // 0xa5d990: ldr             x16, [fp, #0x10]
    // 0xa5d994: stp             x16, x1, [SP, #-0x10]!
    // 0xa5d998: r0 = getDryLayout()
    //     0xa5d998: bl              #0x62d394  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xa5d99c: add             SP, SP, #0x10
    // 0xa5d9a0: LeaveFrame
    //     0xa5d9a0: mov             SP, fp
    //     0xa5d9a4: ldp             fp, lr, [SP], #0x10
    // 0xa5d9a8: ret
    //     0xa5d9a8: ret             
    // 0xa5d9ac: r1 = LoadClassIdInstr(r0)
    //     0xa5d9ac: ldur            x1, [x0, #-1]
    //     0xa5d9b0: ubfx            x1, x1, #0xc, #0x14
    // 0xa5d9b4: ldr             x16, [fp, #0x10]
    // 0xa5d9b8: stp             x16, x0, [SP, #-0x10]!
    // 0xa5d9bc: mov             x0, x1
    // 0xa5d9c0: r0 = GDT[cid_x0 + 0x1c05]()
    //     0xa5d9c0: mov             x17, #0x1c05
    //     0xa5d9c4: add             lr, x0, x17
    //     0xa5d9c8: ldr             lr, [x21, lr, lsl #3]
    //     0xa5d9cc: blr             lr
    // 0xa5d9d0: add             SP, SP, #0x10
    // 0xa5d9d4: LeaveFrame
    //     0xa5d9d4: mov             SP, fp
    //     0xa5d9d8: ldp             fp, lr, [SP], #0x10
    // 0xa5d9dc: ret
    //     0xa5d9dc: ret             
    // 0xa5d9e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5d9e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5d9e4: b               #0xa5d97c
  }
  _ computeSizeForNoChild(/* No info */) {
    // ** addr: 0xb1b880, size: 0x38
    // 0xb1b880: EnterFrame
    //     0xb1b880: stp             fp, lr, [SP, #-0x10]!
    //     0xb1b884: mov             fp, SP
    // 0xb1b888: CheckStackOverflow
    //     0xb1b888: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1b88c: cmp             SP, x16
    //     0xb1b890: b.ls            #0xb1b8b0
    // 0xb1b894: ldr             x16, [fp, #0x10]
    // 0xb1b898: SaveReg r16
    //     0xb1b898: str             x16, [SP, #-8]!
    // 0xb1b89c: r0 = smallest()
    //     0xb1b89c: bl              #0x62bd18  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xb1b8a0: add             SP, SP, #8
    // 0xb1b8a4: LeaveFrame
    //     0xb1b8a4: mov             SP, fp
    //     0xb1b8a8: ldp             fp, lr, [SP], #0x10
    // 0xb1b8ac: ret
    //     0xb1b8ac: ret             
    // 0xb1b8b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1b8b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1b8b4: b               #0xb1b894
  }
}

// class id: 2474, size: 0x64, field offset: 0x64
abstract class RenderProxyBox extends _RenderProxyBox&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin {
}

// class id: 2480, size: 0x74, field offset: 0x64
class RenderAnnotatedRegion<X0> extends RenderProxyBox {

  _ paint(/* No info */) {
    // ** addr: 0x666724, size: 0xc8
    // 0x666724: EnterFrame
    //     0x666724: stp             fp, lr, [SP, #-0x10]!
    //     0x666728: mov             fp, SP
    // 0x66672c: AllocStack(0x18)
    //     0x66672c: sub             SP, SP, #0x18
    // 0x666730: CheckStackOverflow
    //     0x666730: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x666734: cmp             SP, x16
    //     0x666738: b.ls            #0x6667e0
    // 0x66673c: ldr             x0, [fp, #0x20]
    // 0x666740: LoadField: r2 = r0->field_67
    //     0x666740: ldur            w2, [x0, #0x67]
    // 0x666744: DecompressPointer r2
    //     0x666744: add             x2, x2, HEAP, lsl #32
    // 0x666748: stur            x2, [fp, #-0x10]
    // 0x66674c: LoadField: r3 = r0->field_57
    //     0x66674c: ldur            w3, [x0, #0x57]
    // 0x666750: DecompressPointer r3
    //     0x666750: add             x3, x3, HEAP, lsl #32
    // 0x666754: stur            x3, [fp, #-8]
    // 0x666758: cmp             w3, NULL
    // 0x66675c: b.eq            #0x6667e8
    // 0x666760: LoadField: r1 = r0->field_63
    //     0x666760: ldur            w1, [x0, #0x63]
    // 0x666764: DecompressPointer r1
    //     0x666764: add             x1, x1, HEAP, lsl #32
    // 0x666768: r0 = AnnotatedRegionLayer()
    //     0x666768: bl              #0x6669ac  ; AllocateAnnotatedRegionLayerStub -> AnnotatedRegionLayer<X0> (size=0x5c)
    // 0x66676c: stur            x0, [fp, #-0x18]
    // 0x666770: ldur            x16, [fp, #-0x10]
    // 0x666774: stp             x16, x0, [SP, #-0x10]!
    // 0x666778: ldr             x16, [fp, #0x10]
    // 0x66677c: ldur            lr, [fp, #-8]
    // 0x666780: stp             lr, x16, [SP, #-0x10]!
    // 0x666784: r0 = AnnotatedRegionLayer()
    //     0x666784: bl              #0x6668fc  ; [package:flutter/src/rendering/layer.dart] AnnotatedRegionLayer::AnnotatedRegionLayer
    // 0x666788: add             SP, SP, #0x20
    // 0x66678c: r1 = 1
    //     0x66678c: mov             x1, #1
    // 0x666790: r0 = AllocateContext()
    //     0x666790: bl              #0xd68aa4  ; AllocateContextStub
    // 0x666794: mov             x1, x0
    // 0x666798: ldr             x0, [fp, #0x20]
    // 0x66679c: StoreField: r1->field_f = r0
    //     0x66679c: stur            w0, [x1, #0xf]
    // 0x6667a0: mov             x2, x1
    // 0x6667a4: r1 = Function 'paint':.
    //     0x6667a4: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cef0] AnonymousClosure: (0x661630), in [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::paint (0x669ddc)
    //     0x6667a8: ldr             x1, [x1, #0xef0]
    // 0x6667ac: r0 = AllocateClosure()
    //     0x6667ac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6667b0: ldr             x16, [fp, #0x18]
    // 0x6667b4: ldur            lr, [fp, #-0x18]
    // 0x6667b8: stp             lr, x16, [SP, #-0x10]!
    // 0x6667bc: ldr             x16, [fp, #0x10]
    // 0x6667c0: stp             x16, x0, [SP, #-0x10]!
    // 0x6667c4: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x6667c4: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x6667c8: r0 = pushLayer()
    //     0x6667c8: bl              #0x65bbc8  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0x6667cc: add             SP, SP, #0x20
    // 0x6667d0: r0 = Null
    //     0x6667d0: mov             x0, NULL
    // 0x6667d4: LeaveFrame
    //     0x6667d4: mov             SP, fp
    //     0x6667d8: ldp             fp, lr, [SP], #0x10
    // 0x6667dc: ret
    //     0x6667dc: ret             
    // 0x6667e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6667e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6667e4: b               #0x66673c
    // 0x6667e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6667e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ value=(/* No info */) {
    // ** addr: 0x6c34cc, size: 0xc8
    // 0x6c34cc: EnterFrame
    //     0x6c34cc: stp             fp, lr, [SP, #-0x10]!
    //     0x6c34d0: mov             fp, SP
    // 0x6c34d4: CheckStackOverflow
    //     0x6c34d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c34d8: cmp             SP, x16
    //     0x6c34dc: b.ls            #0x6c358c
    // 0x6c34e0: ldr             x3, [fp, #0x18]
    // 0x6c34e4: LoadField: r2 = r3->field_63
    //     0x6c34e4: ldur            w2, [x3, #0x63]
    // 0x6c34e8: DecompressPointer r2
    //     0x6c34e8: add             x2, x2, HEAP, lsl #32
    // 0x6c34ec: ldr             x0, [fp, #0x10]
    // 0x6c34f0: r1 = Null
    //     0x6c34f0: mov             x1, NULL
    // 0x6c34f4: cmp             w2, NULL
    // 0x6c34f8: b.eq            #0x6c351c
    // 0x6c34fc: LoadField: r4 = r2->field_17
    //     0x6c34fc: ldur            w4, [x2, #0x17]
    // 0x6c3500: DecompressPointer r4
    //     0x6c3500: add             x4, x4, HEAP, lsl #32
    // 0x6c3504: r8 = X0
    //     0x6c3504: add             x8, PP, #0xe, lsl #12  ; [pp+0xe0c0] TypeParameter: X0
    //     0x6c3508: ldr             x8, [x8, #0xc0]
    // 0x6c350c: LoadField: r9 = r4->field_7
    //     0x6c350c: ldur            x9, [x4, #7]
    // 0x6c3510: r3 = Null
    //     0x6c3510: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f548] Null
    //     0x6c3514: ldr             x3, [x3, #0x548]
    // 0x6c3518: blr             x9
    // 0x6c351c: ldr             x0, [fp, #0x18]
    // 0x6c3520: LoadField: r1 = r0->field_67
    //     0x6c3520: ldur            w1, [x0, #0x67]
    // 0x6c3524: DecompressPointer r1
    //     0x6c3524: add             x1, x1, HEAP, lsl #32
    // 0x6c3528: ldr             x16, [fp, #0x10]
    // 0x6c352c: stp             x16, x1, [SP, #-0x10]!
    // 0x6c3530: r0 = ==()
    //     0x6c3530: bl              #0xca0fdc  ; [package:flutter/src/services/system_chrome.dart] SystemUiOverlayStyle::==
    // 0x6c3534: add             SP, SP, #0x10
    // 0x6c3538: tbnz            w0, #4, #0x6c354c
    // 0x6c353c: r0 = Null
    //     0x6c353c: mov             x0, NULL
    // 0x6c3540: LeaveFrame
    //     0x6c3540: mov             SP, fp
    //     0x6c3544: ldp             fp, lr, [SP], #0x10
    // 0x6c3548: ret
    //     0x6c3548: ret             
    // 0x6c354c: ldr             x1, [fp, #0x18]
    // 0x6c3550: ldr             x0, [fp, #0x10]
    // 0x6c3554: StoreField: r1->field_67 = r0
    //     0x6c3554: stur            w0, [x1, #0x67]
    //     0x6c3558: ldurb           w16, [x1, #-1]
    //     0x6c355c: ldurb           w17, [x0, #-1]
    //     0x6c3560: and             x16, x17, x16, lsr #2
    //     0x6c3564: tst             x16, HEAP, lsr #32
    //     0x6c3568: b.eq            #0x6c3570
    //     0x6c356c: bl              #0xd6826c
    // 0x6c3570: SaveReg r1
    //     0x6c3570: str             x1, [SP, #-8]!
    // 0x6c3574: r0 = markNeedsPaint()
    //     0x6c3574: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c3578: add             SP, SP, #8
    // 0x6c357c: r0 = Null
    //     0x6c357c: mov             x0, NULL
    // 0x6c3580: LeaveFrame
    //     0x6c3580: mov             SP, fp
    //     0x6c3584: ldp             fp, lr, [SP], #0x10
    // 0x6c3588: ret
    //     0x6c3588: ret             
    // 0x6c358c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c358c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c3590: b               #0x6c34e0
  }
  _ RenderAnnotatedRegion(/* No info */) {
    // ** addr: 0x6eac34, size: 0x78
    // 0x6eac34: EnterFrame
    //     0x6eac34: stp             fp, lr, [SP, #-0x10]!
    //     0x6eac38: mov             fp, SP
    // 0x6eac3c: r1 = true
    //     0x6eac3c: add             x1, NULL, #0x20  ; true
    // 0x6eac40: CheckStackOverflow
    //     0x6eac40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6eac44: cmp             SP, x16
    //     0x6eac48: b.ls            #0x6eaca4
    // 0x6eac4c: ldr             x2, [fp, #0x18]
    // 0x6eac50: StoreField: r2->field_6f = r1
    //     0x6eac50: stur            w1, [x2, #0x6f]
    // 0x6eac54: ldr             x0, [fp, #0x10]
    // 0x6eac58: StoreField: r2->field_67 = r0
    //     0x6eac58: stur            w0, [x2, #0x67]
    //     0x6eac5c: ldurb           w16, [x2, #-1]
    //     0x6eac60: ldurb           w17, [x0, #-1]
    //     0x6eac64: and             x16, x17, x16, lsr #2
    //     0x6eac68: tst             x16, HEAP, lsr #32
    //     0x6eac6c: b.eq            #0x6eac74
    //     0x6eac70: bl              #0xd6828c
    // 0x6eac74: StoreField: r2->field_6b = r1
    //     0x6eac74: stur            w1, [x2, #0x6b]
    // 0x6eac78: SaveReg r2
    //     0x6eac78: str             x2, [SP, #-8]!
    // 0x6eac7c: r0 = RenderObject()
    //     0x6eac7c: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6eac80: add             SP, SP, #8
    // 0x6eac84: ldr             x16, [fp, #0x18]
    // 0x6eac88: stp             NULL, x16, [SP, #-0x10]!
    // 0x6eac8c: r0 = child=()
    //     0x6eac8c: bl              #0x6e7da0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::child=
    // 0x6eac90: add             SP, SP, #0x10
    // 0x6eac94: r0 = Null
    //     0x6eac94: mov             x0, NULL
    // 0x6eac98: LeaveFrame
    //     0x6eac98: mov             SP, fp
    //     0x6eac9c: ldp             fp, lr, [SP], #0x10
    // 0x6eaca0: ret
    //     0x6eaca0: ret             
    // 0x6eaca4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6eaca4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6eaca8: b               #0x6eac4c
  }
}

// class id: 2481, size: 0x78, field offset: 0x64
class RenderFollowerLayer extends RenderProxyBox {

  _ hitTestChildren(/* No info */) {
    // ** addr: 0x627184, size: 0x80
    // 0x627184: EnterFrame
    //     0x627184: stp             fp, lr, [SP, #-0x10]!
    //     0x627188: mov             fp, SP
    // 0x62718c: AllocStack(0x8)
    //     0x62718c: sub             SP, SP, #8
    // 0x627190: CheckStackOverflow
    //     0x627190: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x627194: cmp             SP, x16
    //     0x627198: b.ls            #0x6271fc
    // 0x62719c: r1 = 1
    //     0x62719c: mov             x1, #1
    // 0x6271a0: r0 = AllocateContext()
    //     0x6271a0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6271a4: mov             x1, x0
    // 0x6271a8: ldr             x0, [fp, #0x20]
    // 0x6271ac: stur            x1, [fp, #-8]
    // 0x6271b0: StoreField: r1->field_f = r0
    //     0x6271b0: stur            w0, [x1, #0xf]
    // 0x6271b4: SaveReg r0
    //     0x6271b4: str             x0, [SP, #-8]!
    // 0x6271b8: r0 = getCurrentTransform()
    //     0x6271b8: bl              #0x627204  ; [package:flutter/src/rendering/proxy_box.dart] RenderFollowerLayer::getCurrentTransform
    // 0x6271bc: add             SP, SP, #8
    // 0x6271c0: ldur            x2, [fp, #-8]
    // 0x6271c4: r1 = Function '<anonymous closure>':.
    //     0x6271c4: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fce0] AnonymousClosure: (0x6263b8), in [package:flutter/src/rendering/proxy_box.dart] RenderTransform::hitTestChildren (0x625518)
    //     0x6271c8: ldr             x1, [x1, #0xce0]
    // 0x6271cc: stur            x0, [fp, #-8]
    // 0x6271d0: r0 = AllocateClosure()
    //     0x6271d0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6271d4: ldr             x16, [fp, #0x18]
    // 0x6271d8: stp             x0, x16, [SP, #-0x10]!
    // 0x6271dc: ldr             x16, [fp, #0x10]
    // 0x6271e0: ldur            lr, [fp, #-8]
    // 0x6271e4: stp             lr, x16, [SP, #-0x10]!
    // 0x6271e8: r0 = addWithPaintTransform()
    //     0x6271e8: bl              #0x622f04  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithPaintTransform
    // 0x6271ec: add             SP, SP, #0x20
    // 0x6271f0: LeaveFrame
    //     0x6271f0: mov             SP, fp
    //     0x6271f4: ldp             fp, lr, [SP], #0x10
    // 0x6271f8: ret
    //     0x6271f8: ret             
    // 0x6271fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6271fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x627200: b               #0x62719c
  }
  _ getCurrentTransform(/* No info */) {
    // ** addr: 0x627204, size: 0x8c
    // 0x627204: EnterFrame
    //     0x627204: stp             fp, lr, [SP, #-0x10]!
    //     0x627208: mov             fp, SP
    // 0x62720c: AllocStack(0x8)
    //     0x62720c: sub             SP, SP, #8
    // 0x627210: CheckStackOverflow
    //     0x627210: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x627214: cmp             SP, x16
    //     0x627218: b.ls            #0x627288
    // 0x62721c: ldr             x16, [fp, #0x10]
    // 0x627220: SaveReg r16
    //     0x627220: str             x16, [SP, #-8]!
    // 0x627224: r0 = layer()
    //     0x627224: bl              #0x627388  ; [package:flutter/src/rendering/proxy_box.dart] RenderFollowerLayer::layer
    // 0x627228: add             SP, SP, #8
    // 0x62722c: cmp             w0, NULL
    // 0x627230: b.ne            #0x62723c
    // 0x627234: r0 = Null
    //     0x627234: mov             x0, NULL
    // 0x627238: b               #0x627248
    // 0x62723c: SaveReg r0
    //     0x62723c: str             x0, [SP, #-8]!
    // 0x627240: r0 = getLastTransform()
    //     0x627240: bl              #0x627290  ; [package:flutter/src/rendering/layer.dart] FollowerLayer::getLastTransform
    // 0x627244: add             SP, SP, #8
    // 0x627248: cmp             w0, NULL
    // 0x62724c: b.ne            #0x62727c
    // 0x627250: r0 = Matrix4()
    //     0x627250: bl              #0x50ace8  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x627254: r4 = 32
    //     0x627254: mov             x4, #0x20
    // 0x627258: stur            x0, [fp, #-8]
    // 0x62725c: r0 = AllocateFloat64Array()
    //     0x62725c: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0x627260: mov             x1, x0
    // 0x627264: ldur            x0, [fp, #-8]
    // 0x627268: StoreField: r0->field_7 = r1
    //     0x627268: stur            w1, [x0, #7]
    // 0x62726c: SaveReg r0
    //     0x62726c: str             x0, [SP, #-8]!
    // 0x627270: r0 = setIdentity()
    //     0x627270: bl              #0x50f090  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0x627274: add             SP, SP, #8
    // 0x627278: ldur            x0, [fp, #-8]
    // 0x62727c: LeaveFrame
    //     0x62727c: mov             SP, fp
    //     0x627280: ldp             fp, lr, [SP], #0x10
    // 0x627284: ret
    //     0x627284: ret             
    // 0x627288: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x627288: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62728c: b               #0x62721c
  }
  get _ layer(/* No info */) {
    // ** addr: 0x627388, size: 0x64
    // 0x627388: EnterFrame
    //     0x627388: stp             fp, lr, [SP, #-0x10]!
    //     0x62738c: mov             fp, SP
    // 0x627390: AllocStack(0x8)
    //     0x627390: sub             SP, SP, #8
    // 0x627394: ldr             x0, [fp, #0x10]
    // 0x627398: LoadField: r1 = r0->field_2f
    //     0x627398: ldur            w1, [x0, #0x2f]
    // 0x62739c: DecompressPointer r1
    //     0x62739c: add             x1, x1, HEAP, lsl #32
    // 0x6273a0: LoadField: r3 = r1->field_b
    //     0x6273a0: ldur            w3, [x1, #0xb]
    // 0x6273a4: DecompressPointer r3
    //     0x6273a4: add             x3, x3, HEAP, lsl #32
    // 0x6273a8: mov             x0, x3
    // 0x6273ac: stur            x3, [fp, #-8]
    // 0x6273b0: r2 = Null
    //     0x6273b0: mov             x2, NULL
    // 0x6273b4: r1 = Null
    //     0x6273b4: mov             x1, NULL
    // 0x6273b8: r4 = LoadClassIdInstr(r0)
    //     0x6273b8: ldur            x4, [x0, #-1]
    //     0x6273bc: ubfx            x4, x4, #0xc, #0x14
    // 0x6273c0: cmp             x4, #0x950
    // 0x6273c4: b.eq            #0x6273dc
    // 0x6273c8: r8 = FollowerLayer?
    //     0x6273c8: add             x8, PP, #0x3f, lsl #12  ; [pp+0x3fca0] Type: FollowerLayer?
    //     0x6273cc: ldr             x8, [x8, #0xca0]
    // 0x6273d0: r3 = Null
    //     0x6273d0: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3fca8] Null
    //     0x6273d4: ldr             x3, [x3, #0xca8]
    // 0x6273d8: r0 = DefaultNullableTypeTest()
    //     0x6273d8: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x6273dc: ldur            x0, [fp, #-8]
    // 0x6273e0: LeaveFrame
    //     0x6273e0: mov             SP, fp
    //     0x6273e4: ldp             fp, lr, [SP], #0x10
    // 0x6273e8: ret
    //     0x6273e8: ret             
  }
  _ hitTest(/* No info */) {
    // ** addr: 0x6405d0, size: 0x78
    // 0x6405d0: EnterFrame
    //     0x6405d0: stp             fp, lr, [SP, #-0x10]!
    //     0x6405d4: mov             fp, SP
    // 0x6405d8: CheckStackOverflow
    //     0x6405d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6405dc: cmp             SP, x16
    //     0x6405e0: b.ls            #0x640640
    // 0x6405e4: ldr             x0, [fp, #0x20]
    // 0x6405e8: LoadField: r1 = r0->field_63
    //     0x6405e8: ldur            w1, [x0, #0x63]
    // 0x6405ec: DecompressPointer r1
    //     0x6405ec: add             x1, x1, HEAP, lsl #32
    // 0x6405f0: LoadField: r2 = r1->field_7
    //     0x6405f0: ldur            w2, [x1, #7]
    // 0x6405f4: DecompressPointer r2
    //     0x6405f4: add             x2, x2, HEAP, lsl #32
    // 0x6405f8: cmp             w2, NULL
    // 0x6405fc: b.ne            #0x64061c
    // 0x640600: LoadField: r1 = r0->field_67
    //     0x640600: ldur            w1, [x0, #0x67]
    // 0x640604: DecompressPointer r1
    //     0x640604: add             x1, x1, HEAP, lsl #32
    // 0x640608: tbz             w1, #4, #0x64061c
    // 0x64060c: r0 = false
    //     0x64060c: add             x0, NULL, #0x30  ; false
    // 0x640610: LeaveFrame
    //     0x640610: mov             SP, fp
    //     0x640614: ldp             fp, lr, [SP], #0x10
    // 0x640618: ret
    //     0x640618: ret             
    // 0x64061c: ldr             x16, [fp, #0x18]
    // 0x640620: stp             x16, x0, [SP, #-0x10]!
    // 0x640624: ldr             x16, [fp, #0x10]
    // 0x640628: SaveReg r16
    //     0x640628: str             x16, [SP, #-8]!
    // 0x64062c: r0 = hitTestChildren()
    //     0x64062c: bl              #0x627184  ; [package:flutter/src/rendering/proxy_box.dart] RenderFollowerLayer::hitTestChildren
    // 0x640630: add             SP, SP, #0x18
    // 0x640634: LeaveFrame
    //     0x640634: mov             SP, fp
    //     0x640638: ldp             fp, lr, [SP], #0x10
    // 0x64063c: ret
    //     0x64063c: ret             
    // 0x640640: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x640640: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x640644: b               #0x6405e4
  }
  _ paint(/* No info */) {
    // ** addr: 0x666444, size: 0x2d4
    // 0x666444: EnterFrame
    //     0x666444: stp             fp, lr, [SP, #-0x10]!
    //     0x666448: mov             fp, SP
    // 0x66644c: AllocStack(0x30)
    //     0x66644c: sub             SP, SP, #0x30
    // 0x666450: CheckStackOverflow
    //     0x666450: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x666454: cmp             SP, x16
    //     0x666458: b.ls            #0x666708
    // 0x66645c: ldr             x0, [fp, #0x20]
    // 0x666460: LoadField: r1 = r0->field_63
    //     0x666460: ldur            w1, [x0, #0x63]
    // 0x666464: DecompressPointer r1
    //     0x666464: add             x1, x1, HEAP, lsl #32
    // 0x666468: LoadField: r2 = r1->field_b
    //     0x666468: ldur            w2, [x1, #0xb]
    // 0x66646c: DecompressPointer r2
    //     0x66646c: add             x2, x2, HEAP, lsl #32
    // 0x666470: cmp             w2, NULL
    // 0x666474: b.ne            #0x66648c
    // 0x666478: LoadField: r1 = r0->field_6b
    //     0x666478: ldur            w1, [x0, #0x6b]
    // 0x66647c: DecompressPointer r1
    //     0x66647c: add             x1, x1, HEAP, lsl #32
    // 0x666480: mov             x4, x1
    // 0x666484: mov             x3, x0
    // 0x666488: b               #0x666504
    // 0x66648c: r16 = Instance_Alignment
    //     0x66648c: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2abd0] Obj!Alignment@b37ad1
    //     0x666490: ldr             x16, [x16, #0xbd0]
    // 0x666494: stp             x2, x16, [SP, #-0x10]!
    // 0x666498: r0 = alongOffset()
    //     0x666498: bl              #0x626350  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0x66649c: add             SP, SP, #0x10
    // 0x6664a0: mov             x1, x0
    // 0x6664a4: ldr             x0, [fp, #0x20]
    // 0x6664a8: stur            x1, [fp, #-8]
    // 0x6664ac: LoadField: r2 = r0->field_57
    //     0x6664ac: ldur            w2, [x0, #0x57]
    // 0x6664b0: DecompressPointer r2
    //     0x6664b0: add             x2, x2, HEAP, lsl #32
    // 0x6664b4: cmp             w2, NULL
    // 0x6664b8: b.eq            #0x666710
    // 0x6664bc: r16 = Instance_Alignment
    //     0x6664bc: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2abd0] Obj!Alignment@b37ad1
    //     0x6664c0: ldr             x16, [x16, #0xbd0]
    // 0x6664c4: stp             x2, x16, [SP, #-0x10]!
    // 0x6664c8: r0 = alongOffset()
    //     0x6664c8: bl              #0x626350  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0x6664cc: add             SP, SP, #0x10
    // 0x6664d0: ldur            x16, [fp, #-8]
    // 0x6664d4: stp             x0, x16, [SP, #-0x10]!
    // 0x6664d8: r0 = -()
    //     0x6664d8: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x6664dc: add             SP, SP, #0x10
    // 0x6664e0: mov             x1, x0
    // 0x6664e4: ldr             x0, [fp, #0x20]
    // 0x6664e8: LoadField: r2 = r0->field_6b
    //     0x6664e8: ldur            w2, [x0, #0x6b]
    // 0x6664ec: DecompressPointer r2
    //     0x6664ec: add             x2, x2, HEAP, lsl #32
    // 0x6664f0: stp             x2, x1, [SP, #-0x10]!
    // 0x6664f4: r0 = +()
    //     0x6664f4: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x6664f8: add             SP, SP, #0x10
    // 0x6664fc: mov             x4, x0
    // 0x666500: ldr             x3, [fp, #0x20]
    // 0x666504: stur            x4, [fp, #-0x18]
    // 0x666508: LoadField: r5 = r3->field_2f
    //     0x666508: ldur            w5, [x3, #0x2f]
    // 0x66650c: DecompressPointer r5
    //     0x66650c: add             x5, x5, HEAP, lsl #32
    // 0x666510: stur            x5, [fp, #-0x10]
    // 0x666514: LoadField: r6 = r5->field_b
    //     0x666514: ldur            w6, [x5, #0xb]
    // 0x666518: DecompressPointer r6
    //     0x666518: add             x6, x6, HEAP, lsl #32
    // 0x66651c: mov             x0, x6
    // 0x666520: stur            x6, [fp, #-8]
    // 0x666524: r2 = Null
    //     0x666524: mov             x2, NULL
    // 0x666528: r1 = Null
    //     0x666528: mov             x1, NULL
    // 0x66652c: r4 = LoadClassIdInstr(r0)
    //     0x66652c: ldur            x4, [x0, #-1]
    //     0x666530: ubfx            x4, x4, #0xc, #0x14
    // 0x666534: cmp             x4, #0x950
    // 0x666538: b.eq            #0x666550
    // 0x66653c: r8 = FollowerLayer?
    //     0x66653c: add             x8, PP, #0x3f, lsl #12  ; [pp+0x3fca0] Type: FollowerLayer?
    //     0x666540: ldr             x8, [x8, #0xca0]
    // 0x666544: r3 = Null
    //     0x666544: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3fcb8] Null
    //     0x666548: ldr             x3, [x3, #0xcb8]
    // 0x66654c: r0 = DefaultNullableTypeTest()
    //     0x66654c: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x666550: ldur            x1, [fp, #-8]
    // 0x666554: cmp             w1, NULL
    // 0x666558: b.ne            #0x6665dc
    // 0x66655c: ldr             x0, [fp, #0x20]
    // 0x666560: ldr             x2, [fp, #0x10]
    // 0x666564: ldur            x1, [fp, #-0x18]
    // 0x666568: LoadField: r3 = r0->field_63
    //     0x666568: ldur            w3, [x0, #0x63]
    // 0x66656c: DecompressPointer r3
    //     0x66656c: add             x3, x3, HEAP, lsl #32
    // 0x666570: stur            x3, [fp, #-0x28]
    // 0x666574: LoadField: r4 = r0->field_67
    //     0x666574: ldur            w4, [x0, #0x67]
    // 0x666578: DecompressPointer r4
    //     0x666578: add             x4, x4, HEAP, lsl #32
    // 0x66657c: stur            x4, [fp, #-0x20]
    // 0x666580: r0 = FollowerLayer()
    //     0x666580: bl              #0x666718  ; AllocateFollowerLayerStub -> FollowerLayer (size=0x68)
    // 0x666584: mov             x1, x0
    // 0x666588: r0 = true
    //     0x666588: add             x0, NULL, #0x20  ; true
    // 0x66658c: stur            x1, [fp, #-0x30]
    // 0x666590: StoreField: r1->field_63 = r0
    //     0x666590: stur            w0, [x1, #0x63]
    // 0x666594: ldur            x0, [fp, #-0x20]
    // 0x666598: StoreField: r1->field_4b = r0
    //     0x666598: stur            w0, [x1, #0x4b]
    // 0x66659c: ldr             x2, [fp, #0x10]
    // 0x6665a0: StoreField: r1->field_4f = r2
    //     0x6665a0: stur            w2, [x1, #0x4f]
    // 0x6665a4: ldur            x3, [fp, #-0x18]
    // 0x6665a8: StoreField: r1->field_53 = r3
    //     0x6665a8: stur            w3, [x1, #0x53]
    // 0x6665ac: ldur            x0, [fp, #-0x28]
    // 0x6665b0: StoreField: r1->field_47 = r0
    //     0x6665b0: stur            w0, [x1, #0x47]
    // 0x6665b4: SaveReg r1
    //     0x6665b4: str             x1, [SP, #-8]!
    // 0x6665b8: r0 = Layer()
    //     0x6665b8: bl              #0x5bbe7c  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0x6665bc: add             SP, SP, #8
    // 0x6665c0: ldur            x16, [fp, #-0x10]
    // 0x6665c4: ldur            lr, [fp, #-0x30]
    // 0x6665c8: stp             lr, x16, [SP, #-0x10]!
    // 0x6665cc: r0 = layer=()
    //     0x6665cc: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x6665d0: add             SP, SP, #0x10
    // 0x6665d4: ldr             x4, [fp, #0x20]
    // 0x6665d8: b               #0x666658
    // 0x6665dc: ldr             x4, [fp, #0x20]
    // 0x6665e0: ldr             x2, [fp, #0x10]
    // 0x6665e4: ldur            x3, [fp, #-0x18]
    // 0x6665e8: LoadField: r0 = r4->field_63
    //     0x6665e8: ldur            w0, [x4, #0x63]
    // 0x6665ec: DecompressPointer r0
    //     0x6665ec: add             x0, x0, HEAP, lsl #32
    // 0x6665f0: StoreField: r1->field_47 = r0
    //     0x6665f0: stur            w0, [x1, #0x47]
    //     0x6665f4: ldurb           w16, [x1, #-1]
    //     0x6665f8: ldurb           w17, [x0, #-1]
    //     0x6665fc: and             x16, x17, x16, lsr #2
    //     0x666600: tst             x16, HEAP, lsr #32
    //     0x666604: b.eq            #0x66660c
    //     0x666608: bl              #0xd6826c
    // 0x66660c: LoadField: r0 = r4->field_67
    //     0x66660c: ldur            w0, [x4, #0x67]
    // 0x666610: DecompressPointer r0
    //     0x666610: add             x0, x0, HEAP, lsl #32
    // 0x666614: StoreField: r1->field_4b = r0
    //     0x666614: stur            w0, [x1, #0x4b]
    // 0x666618: mov             x0, x3
    // 0x66661c: StoreField: r1->field_53 = r0
    //     0x66661c: stur            w0, [x1, #0x53]
    //     0x666620: ldurb           w16, [x1, #-1]
    //     0x666624: ldurb           w17, [x0, #-1]
    //     0x666628: and             x16, x17, x16, lsr #2
    //     0x66662c: tst             x16, HEAP, lsr #32
    //     0x666630: b.eq            #0x666638
    //     0x666634: bl              #0xd6826c
    // 0x666638: mov             x0, x2
    // 0x66663c: StoreField: r1->field_4f = r0
    //     0x66663c: stur            w0, [x1, #0x4f]
    //     0x666640: ldurb           w16, [x1, #-1]
    //     0x666644: ldurb           w17, [x0, #-1]
    //     0x666648: and             x16, x17, x16, lsr #2
    //     0x66664c: tst             x16, HEAP, lsr #32
    //     0x666650: b.eq            #0x666658
    //     0x666654: bl              #0xd6826c
    // 0x666658: ldur            x0, [fp, #-0x10]
    // 0x66665c: LoadField: r3 = r0->field_b
    //     0x66665c: ldur            w3, [x0, #0xb]
    // 0x666660: DecompressPointer r3
    //     0x666660: add             x3, x3, HEAP, lsl #32
    // 0x666664: mov             x0, x3
    // 0x666668: stur            x3, [fp, #-8]
    // 0x66666c: r2 = Null
    //     0x66666c: mov             x2, NULL
    // 0x666670: r1 = Null
    //     0x666670: mov             x1, NULL
    // 0x666674: r4 = LoadClassIdInstr(r0)
    //     0x666674: ldur            x4, [x0, #-1]
    //     0x666678: ubfx            x4, x4, #0xc, #0x14
    // 0x66667c: cmp             x4, #0x950
    // 0x666680: b.eq            #0x666698
    // 0x666684: r8 = FollowerLayer?
    //     0x666684: add             x8, PP, #0x3f, lsl #12  ; [pp+0x3fca0] Type: FollowerLayer?
    //     0x666688: ldr             x8, [x8, #0xca0]
    // 0x66668c: r3 = Null
    //     0x66668c: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3fcc8] Null
    //     0x666690: ldr             x3, [x3, #0xcc8]
    // 0x666694: r0 = DefaultNullableTypeTest()
    //     0x666694: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x666698: ldur            x0, [fp, #-8]
    // 0x66669c: cmp             w0, NULL
    // 0x6666a0: b.eq            #0x666714
    // 0x6666a4: r1 = 1
    //     0x6666a4: mov             x1, #1
    // 0x6666a8: r0 = AllocateContext()
    //     0x6666a8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6666ac: mov             x1, x0
    // 0x6666b0: ldr             x0, [fp, #0x20]
    // 0x6666b4: StoreField: r1->field_f = r0
    //     0x6666b4: stur            w0, [x1, #0xf]
    // 0x6666b8: mov             x2, x1
    // 0x6666bc: r1 = Function 'paint':.
    //     0x6666bc: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cef0] AnonymousClosure: (0x661630), in [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::paint (0x669ddc)
    //     0x6666c0: ldr             x1, [x1, #0xef0]
    // 0x6666c4: r0 = AllocateClosure()
    //     0x6666c4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6666c8: ldr             x16, [fp, #0x18]
    // 0x6666cc: ldur            lr, [fp, #-8]
    // 0x6666d0: stp             lr, x16, [SP, #-0x10]!
    // 0x6666d4: r16 = Instance_Offset
    //     0x6666d4: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x6666d8: stp             x16, x0, [SP, #-0x10]!
    // 0x6666dc: r16 = Instance_Rect
    //     0x6666dc: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3fcd8] Obj!Rect@b5ec21
    //     0x6666e0: ldr             x16, [x16, #0xcd8]
    // 0x6666e4: SaveReg r16
    //     0x6666e4: str             x16, [SP, #-8]!
    // 0x6666e8: r4 = const [0, 0x5, 0x5, 0x4, childPaintBounds, 0x4, null]
    //     0x6666e8: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1cf00] List(7) [0, 0x5, 0x5, 0x4, "childPaintBounds", 0x4, Null]
    //     0x6666ec: ldr             x4, [x4, #0xf00]
    // 0x6666f0: r0 = pushLayer()
    //     0x6666f0: bl              #0x65bbc8  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0x6666f4: add             SP, SP, #0x28
    // 0x6666f8: r0 = Null
    //     0x6666f8: mov             x0, NULL
    // 0x6666fc: LeaveFrame
    //     0x6666fc: mov             SP, fp
    //     0x666700: ldp             fp, lr, [SP], #0x10
    // 0x666704: ret
    //     0x666704: ret             
    // 0x666708: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x666708: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66670c: b               #0x66645c
    // 0x666710: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x666710: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x666714: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x666714: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0x6bc598, size: 0x88
    // 0x6bc598: EnterFrame
    //     0x6bc598: stp             fp, lr, [SP, #-0x10]!
    //     0x6bc59c: mov             fp, SP
    // 0x6bc5a0: CheckStackOverflow
    //     0x6bc5a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bc5a4: cmp             SP, x16
    //     0x6bc5a8: b.ls            #0x6bc618
    // 0x6bc5ac: ldr             x0, [fp, #0x18]
    // 0x6bc5b0: r2 = Null
    //     0x6bc5b0: mov             x2, NULL
    // 0x6bc5b4: r1 = Null
    //     0x6bc5b4: mov             x1, NULL
    // 0x6bc5b8: r4 = 59
    //     0x6bc5b8: mov             x4, #0x3b
    // 0x6bc5bc: branchIfSmi(r0, 0x6bc5c8)
    //     0x6bc5bc: tbz             w0, #0, #0x6bc5c8
    // 0x6bc5c0: r4 = LoadClassIdInstr(r0)
    //     0x6bc5c0: ldur            x4, [x0, #-1]
    //     0x6bc5c4: ubfx            x4, x4, #0xc, #0x14
    // 0x6bc5c8: sub             x4, x4, #0x965
    // 0x6bc5cc: cmp             x4, #0x8b
    // 0x6bc5d0: b.ls            #0x6bc5e8
    // 0x6bc5d4: r8 = RenderBox
    //     0x6bc5d4: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x6bc5d8: ldr             x8, [x8, #0xfa0]
    // 0x6bc5dc: r3 = Null
    //     0x6bc5dc: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3fc90] Null
    //     0x6bc5e0: ldr             x3, [x3, #0xc90]
    // 0x6bc5e4: r0 = RenderBox()
    //     0x6bc5e4: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x6bc5e8: ldr             x16, [fp, #0x20]
    // 0x6bc5ec: SaveReg r16
    //     0x6bc5ec: str             x16, [SP, #-8]!
    // 0x6bc5f0: r0 = getCurrentTransform()
    //     0x6bc5f0: bl              #0x627204  ; [package:flutter/src/rendering/proxy_box.dart] RenderFollowerLayer::getCurrentTransform
    // 0x6bc5f4: add             SP, SP, #8
    // 0x6bc5f8: ldr             x16, [fp, #0x10]
    // 0x6bc5fc: stp             x0, x16, [SP, #-0x10]!
    // 0x6bc600: r0 = multiply()
    //     0x6bc600: bl              #0x625d1c  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0x6bc604: add             SP, SP, #0x10
    // 0x6bc608: r0 = Null
    //     0x6bc608: mov             x0, NULL
    // 0x6bc60c: LeaveFrame
    //     0x6bc60c: mov             SP, fp
    //     0x6bc610: ldp             fp, lr, [SP], #0x10
    // 0x6bc614: ret
    //     0x6bc614: ret             
    // 0x6bc618: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bc618: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bc61c: b               #0x6bc5ac
  }
  set _ followerAnchor=(/* No info */) {
    // ** addr: 0x6c4bdc, size: 0x78
    // 0x6c4bdc: EnterFrame
    //     0x6c4bdc: stp             fp, lr, [SP, #-0x10]!
    //     0x6c4be0: mov             fp, SP
    // 0x6c4be4: CheckStackOverflow
    //     0x6c4be4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c4be8: cmp             SP, x16
    //     0x6c4bec: b.ls            #0x6c4c4c
    // 0x6c4bf0: r16 = Instance_Alignment
    //     0x6c4bf0: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2abd0] Obj!Alignment@b37ad1
    //     0x6c4bf4: ldr             x16, [x16, #0xbd0]
    // 0x6c4bf8: r30 = Instance_Alignment
    //     0x6c4bf8: add             lr, PP, #0x2a, lsl #12  ; [pp+0x2abd0] Obj!Alignment@b37ad1
    //     0x6c4bfc: ldr             lr, [lr, #0xbd0]
    // 0x6c4c00: stp             lr, x16, [SP, #-0x10]!
    // 0x6c4c04: r0 = ==()
    //     0x6c4c04: bl              #0xc9c720  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::==
    // 0x6c4c08: add             SP, SP, #0x10
    // 0x6c4c0c: tbnz            w0, #4, #0x6c4c20
    // 0x6c4c10: r0 = Null
    //     0x6c4c10: mov             x0, NULL
    // 0x6c4c14: LeaveFrame
    //     0x6c4c14: mov             SP, fp
    //     0x6c4c18: ldp             fp, lr, [SP], #0x10
    // 0x6c4c1c: ret
    //     0x6c4c1c: ret             
    // 0x6c4c20: ldr             x1, [fp, #0x18]
    // 0x6c4c24: r0 = Instance_Alignment
    //     0x6c4c24: add             x0, PP, #0x2a, lsl #12  ; [pp+0x2abd0] Obj!Alignment@b37ad1
    //     0x6c4c28: ldr             x0, [x0, #0xbd0]
    // 0x6c4c2c: StoreField: r1->field_73 = r0
    //     0x6c4c2c: stur            w0, [x1, #0x73]
    // 0x6c4c30: SaveReg r1
    //     0x6c4c30: str             x1, [SP, #-8]!
    // 0x6c4c34: r0 = markNeedsPaint()
    //     0x6c4c34: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c4c38: add             SP, SP, #8
    // 0x6c4c3c: r0 = Null
    //     0x6c4c3c: mov             x0, NULL
    // 0x6c4c40: LeaveFrame
    //     0x6c4c40: mov             SP, fp
    //     0x6c4c44: ldp             fp, lr, [SP], #0x10
    // 0x6c4c48: ret
    //     0x6c4c48: ret             
    // 0x6c4c4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c4c4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c4c50: b               #0x6c4bf0
  }
  set _ leaderAnchor=(/* No info */) {
    // ** addr: 0x6c4c54, size: 0x78
    // 0x6c4c54: EnterFrame
    //     0x6c4c54: stp             fp, lr, [SP, #-0x10]!
    //     0x6c4c58: mov             fp, SP
    // 0x6c4c5c: CheckStackOverflow
    //     0x6c4c5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c4c60: cmp             SP, x16
    //     0x6c4c64: b.ls            #0x6c4cc4
    // 0x6c4c68: r16 = Instance_Alignment
    //     0x6c4c68: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2abd0] Obj!Alignment@b37ad1
    //     0x6c4c6c: ldr             x16, [x16, #0xbd0]
    // 0x6c4c70: r30 = Instance_Alignment
    //     0x6c4c70: add             lr, PP, #0x2a, lsl #12  ; [pp+0x2abd0] Obj!Alignment@b37ad1
    //     0x6c4c74: ldr             lr, [lr, #0xbd0]
    // 0x6c4c78: stp             lr, x16, [SP, #-0x10]!
    // 0x6c4c7c: r0 = ==()
    //     0x6c4c7c: bl              #0xc9c720  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::==
    // 0x6c4c80: add             SP, SP, #0x10
    // 0x6c4c84: tbnz            w0, #4, #0x6c4c98
    // 0x6c4c88: r0 = Null
    //     0x6c4c88: mov             x0, NULL
    // 0x6c4c8c: LeaveFrame
    //     0x6c4c8c: mov             SP, fp
    //     0x6c4c90: ldp             fp, lr, [SP], #0x10
    // 0x6c4c94: ret
    //     0x6c4c94: ret             
    // 0x6c4c98: ldr             x1, [fp, #0x18]
    // 0x6c4c9c: r0 = Instance_Alignment
    //     0x6c4c9c: add             x0, PP, #0x2a, lsl #12  ; [pp+0x2abd0] Obj!Alignment@b37ad1
    //     0x6c4ca0: ldr             x0, [x0, #0xbd0]
    // 0x6c4ca4: StoreField: r1->field_6f = r0
    //     0x6c4ca4: stur            w0, [x1, #0x6f]
    // 0x6c4ca8: SaveReg r1
    //     0x6c4ca8: str             x1, [SP, #-8]!
    // 0x6c4cac: r0 = markNeedsPaint()
    //     0x6c4cac: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c4cb0: add             SP, SP, #8
    // 0x6c4cb4: r0 = Null
    //     0x6c4cb4: mov             x0, NULL
    // 0x6c4cb8: LeaveFrame
    //     0x6c4cb8: mov             SP, fp
    //     0x6c4cbc: ldp             fp, lr, [SP], #0x10
    // 0x6c4cc0: ret
    //     0x6c4cc0: ret             
    // 0x6c4cc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c4cc4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c4cc8: b               #0x6c4c68
  }
  set _ offset=(/* No info */) {
    // ** addr: 0x6c4ccc, size: 0x8c
    // 0x6c4ccc: EnterFrame
    //     0x6c4ccc: stp             fp, lr, [SP, #-0x10]!
    //     0x6c4cd0: mov             fp, SP
    // 0x6c4cd4: CheckStackOverflow
    //     0x6c4cd4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c4cd8: cmp             SP, x16
    //     0x6c4cdc: b.ls            #0x6c4d50
    // 0x6c4ce0: ldr             x0, [fp, #0x18]
    // 0x6c4ce4: LoadField: r1 = r0->field_6b
    //     0x6c4ce4: ldur            w1, [x0, #0x6b]
    // 0x6c4ce8: DecompressPointer r1
    //     0x6c4ce8: add             x1, x1, HEAP, lsl #32
    // 0x6c4cec: ldr             x16, [fp, #0x10]
    // 0x6c4cf0: stp             x16, x1, [SP, #-0x10]!
    // 0x6c4cf4: r0 = ==()
    //     0x6c4cf4: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0x6c4cf8: add             SP, SP, #0x10
    // 0x6c4cfc: tbnz            w0, #4, #0x6c4d10
    // 0x6c4d00: r0 = Null
    //     0x6c4d00: mov             x0, NULL
    // 0x6c4d04: LeaveFrame
    //     0x6c4d04: mov             SP, fp
    //     0x6c4d08: ldp             fp, lr, [SP], #0x10
    // 0x6c4d0c: ret
    //     0x6c4d0c: ret             
    // 0x6c4d10: ldr             x1, [fp, #0x18]
    // 0x6c4d14: ldr             x0, [fp, #0x10]
    // 0x6c4d18: StoreField: r1->field_6b = r0
    //     0x6c4d18: stur            w0, [x1, #0x6b]
    //     0x6c4d1c: ldurb           w16, [x1, #-1]
    //     0x6c4d20: ldurb           w17, [x0, #-1]
    //     0x6c4d24: and             x16, x17, x16, lsr #2
    //     0x6c4d28: tst             x16, HEAP, lsr #32
    //     0x6c4d2c: b.eq            #0x6c4d34
    //     0x6c4d30: bl              #0xd6826c
    // 0x6c4d34: SaveReg r1
    //     0x6c4d34: str             x1, [SP, #-8]!
    // 0x6c4d38: r0 = markNeedsPaint()
    //     0x6c4d38: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c4d3c: add             SP, SP, #8
    // 0x6c4d40: r0 = Null
    //     0x6c4d40: mov             x0, NULL
    // 0x6c4d44: LeaveFrame
    //     0x6c4d44: mov             SP, fp
    //     0x6c4d48: ldp             fp, lr, [SP], #0x10
    // 0x6c4d4c: ret
    //     0x6c4d4c: ret             
    // 0x6c4d50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c4d50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c4d54: b               #0x6c4ce0
  }
  set _ showWhenUnlinked=(/* No info */) {
    // ** addr: 0x6c4d58, size: 0x64
    // 0x6c4d58: EnterFrame
    //     0x6c4d58: stp             fp, lr, [SP, #-0x10]!
    //     0x6c4d5c: mov             fp, SP
    // 0x6c4d60: CheckStackOverflow
    //     0x6c4d60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c4d64: cmp             SP, x16
    //     0x6c4d68: b.ls            #0x6c4db4
    // 0x6c4d6c: ldr             x0, [fp, #0x18]
    // 0x6c4d70: LoadField: r1 = r0->field_67
    //     0x6c4d70: ldur            w1, [x0, #0x67]
    // 0x6c4d74: DecompressPointer r1
    //     0x6c4d74: add             x1, x1, HEAP, lsl #32
    // 0x6c4d78: ldr             x2, [fp, #0x10]
    // 0x6c4d7c: cmp             w1, w2
    // 0x6c4d80: b.ne            #0x6c4d94
    // 0x6c4d84: r0 = Null
    //     0x6c4d84: mov             x0, NULL
    // 0x6c4d88: LeaveFrame
    //     0x6c4d88: mov             SP, fp
    //     0x6c4d8c: ldp             fp, lr, [SP], #0x10
    // 0x6c4d90: ret
    //     0x6c4d90: ret             
    // 0x6c4d94: StoreField: r0->field_67 = r2
    //     0x6c4d94: stur            w2, [x0, #0x67]
    // 0x6c4d98: SaveReg r0
    //     0x6c4d98: str             x0, [SP, #-8]!
    // 0x6c4d9c: r0 = markNeedsPaint()
    //     0x6c4d9c: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c4da0: add             SP, SP, #8
    // 0x6c4da4: r0 = Null
    //     0x6c4da4: mov             x0, NULL
    // 0x6c4da8: LeaveFrame
    //     0x6c4da8: mov             SP, fp
    //     0x6c4dac: ldp             fp, lr, [SP], #0x10
    // 0x6c4db0: ret
    //     0x6c4db0: ret             
    // 0x6c4db4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c4db4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c4db8: b               #0x6c4d6c
  }
  set _ link=(/* No info */) {
    // ** addr: 0x6c4dbc, size: 0x80
    // 0x6c4dbc: EnterFrame
    //     0x6c4dbc: stp             fp, lr, [SP, #-0x10]!
    //     0x6c4dc0: mov             fp, SP
    // 0x6c4dc4: CheckStackOverflow
    //     0x6c4dc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c4dc8: cmp             SP, x16
    //     0x6c4dcc: b.ls            #0x6c4e34
    // 0x6c4dd0: ldr             x1, [fp, #0x18]
    // 0x6c4dd4: LoadField: r0 = r1->field_63
    //     0x6c4dd4: ldur            w0, [x1, #0x63]
    // 0x6c4dd8: DecompressPointer r0
    //     0x6c4dd8: add             x0, x0, HEAP, lsl #32
    // 0x6c4ddc: ldr             x2, [fp, #0x10]
    // 0x6c4de0: cmp             w0, w2
    // 0x6c4de4: b.ne            #0x6c4df8
    // 0x6c4de8: r0 = Null
    //     0x6c4de8: mov             x0, NULL
    // 0x6c4dec: LeaveFrame
    //     0x6c4dec: mov             SP, fp
    //     0x6c4df0: ldp             fp, lr, [SP], #0x10
    // 0x6c4df4: ret
    //     0x6c4df4: ret             
    // 0x6c4df8: mov             x0, x2
    // 0x6c4dfc: StoreField: r1->field_63 = r0
    //     0x6c4dfc: stur            w0, [x1, #0x63]
    //     0x6c4e00: ldurb           w16, [x1, #-1]
    //     0x6c4e04: ldurb           w17, [x0, #-1]
    //     0x6c4e08: and             x16, x17, x16, lsr #2
    //     0x6c4e0c: tst             x16, HEAP, lsr #32
    //     0x6c4e10: b.eq            #0x6c4e18
    //     0x6c4e14: bl              #0xd6826c
    // 0x6c4e18: SaveReg r1
    //     0x6c4e18: str             x1, [SP, #-8]!
    // 0x6c4e1c: r0 = markNeedsPaint()
    //     0x6c4e1c: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c4e20: add             SP, SP, #8
    // 0x6c4e24: r0 = Null
    //     0x6c4e24: mov             x0, NULL
    // 0x6c4e28: LeaveFrame
    //     0x6c4e28: mov             SP, fp
    //     0x6c4e2c: ldp             fp, lr, [SP], #0x10
    // 0x6c4e30: ret
    //     0x6c4e30: ret             
    // 0x6c4e34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c4e34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c4e38: b               #0x6c4dd0
  }
  _ RenderFollowerLayer(/* No info */) {
    // ** addr: 0x6eb720, size: 0xa4
    // 0x6eb720: EnterFrame
    //     0x6eb720: stp             fp, lr, [SP, #-0x10]!
    //     0x6eb724: mov             fp, SP
    // 0x6eb728: r1 = Instance_Alignment
    //     0x6eb728: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2abd0] Obj!Alignment@b37ad1
    //     0x6eb72c: ldr             x1, [x1, #0xbd0]
    // 0x6eb730: CheckStackOverflow
    //     0x6eb730: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6eb734: cmp             SP, x16
    //     0x6eb738: b.ls            #0x6eb7bc
    // 0x6eb73c: ldr             x0, [fp, #0x20]
    // 0x6eb740: ldr             x2, [fp, #0x28]
    // 0x6eb744: StoreField: r2->field_63 = r0
    //     0x6eb744: stur            w0, [x2, #0x63]
    //     0x6eb748: ldurb           w16, [x2, #-1]
    //     0x6eb74c: ldurb           w17, [x0, #-1]
    //     0x6eb750: and             x16, x17, x16, lsr #2
    //     0x6eb754: tst             x16, HEAP, lsr #32
    //     0x6eb758: b.eq            #0x6eb760
    //     0x6eb75c: bl              #0xd6828c
    // 0x6eb760: ldr             x0, [fp, #0x10]
    // 0x6eb764: StoreField: r2->field_67 = r0
    //     0x6eb764: stur            w0, [x2, #0x67]
    // 0x6eb768: ldr             x0, [fp, #0x18]
    // 0x6eb76c: StoreField: r2->field_6b = r0
    //     0x6eb76c: stur            w0, [x2, #0x6b]
    //     0x6eb770: ldurb           w16, [x2, #-1]
    //     0x6eb774: ldurb           w17, [x0, #-1]
    //     0x6eb778: and             x16, x17, x16, lsr #2
    //     0x6eb77c: tst             x16, HEAP, lsr #32
    //     0x6eb780: b.eq            #0x6eb788
    //     0x6eb784: bl              #0xd6828c
    // 0x6eb788: StoreField: r2->field_6f = r1
    //     0x6eb788: stur            w1, [x2, #0x6f]
    // 0x6eb78c: StoreField: r2->field_73 = r1
    //     0x6eb78c: stur            w1, [x2, #0x73]
    // 0x6eb790: SaveReg r2
    //     0x6eb790: str             x2, [SP, #-8]!
    // 0x6eb794: r0 = RenderObject()
    //     0x6eb794: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6eb798: add             SP, SP, #8
    // 0x6eb79c: ldr             x16, [fp, #0x28]
    // 0x6eb7a0: stp             NULL, x16, [SP, #-0x10]!
    // 0x6eb7a4: r0 = child=()
    //     0x6eb7a4: bl              #0x6e7da0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::child=
    // 0x6eb7a8: add             SP, SP, #0x10
    // 0x6eb7ac: r0 = Null
    //     0x6eb7ac: mov             x0, NULL
    // 0x6eb7b0: LeaveFrame
    //     0x6eb7b0: mov             SP, fp
    //     0x6eb7b4: ldp             fp, lr, [SP], #0x10
    // 0x6eb7b8: ret
    //     0x6eb7b8: ret             
    // 0x6eb7bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6eb7bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6eb7c0: b               #0x6eb73c
  }
  _ detach(/* No info */) {
    // ** addr: 0xa691e8, size: 0x54
    // 0xa691e8: EnterFrame
    //     0xa691e8: stp             fp, lr, [SP, #-0x10]!
    //     0xa691ec: mov             fp, SP
    // 0xa691f0: CheckStackOverflow
    //     0xa691f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa691f4: cmp             SP, x16
    //     0xa691f8: b.ls            #0xa69234
    // 0xa691fc: ldr             x0, [fp, #0x10]
    // 0xa69200: LoadField: r1 = r0->field_2f
    //     0xa69200: ldur            w1, [x0, #0x2f]
    // 0xa69204: DecompressPointer r1
    //     0xa69204: add             x1, x1, HEAP, lsl #32
    // 0xa69208: stp             NULL, x1, [SP, #-0x10]!
    // 0xa6920c: r0 = layer=()
    //     0xa6920c: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xa69210: add             SP, SP, #0x10
    // 0xa69214: ldr             x16, [fp, #0x10]
    // 0xa69218: SaveReg r16
    //     0xa69218: str             x16, [SP, #-8]!
    // 0xa6921c: r0 = detach()
    //     0xa6921c: bl              #0xa693e0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::detach
    // 0xa69220: add             SP, SP, #8
    // 0xa69224: r0 = Null
    //     0xa69224: mov             x0, NULL
    // 0xa69228: LeaveFrame
    //     0xa69228: mov             SP, fp
    //     0xa6922c: ldp             fp, lr, [SP], #0x10
    // 0xa69230: ret
    //     0xa69230: ret             
    // 0xa69234: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa69234: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa69238: b               #0xa691fc
  }
}

// class id: 2482, size: 0x6c, field offset: 0x64
class RenderLeaderLayer extends RenderProxyBox {

  _ paint(/* No info */) {
    // ** addr: 0x666164, size: 0x170
    // 0x666164: EnterFrame
    //     0x666164: stp             fp, lr, [SP, #-0x10]!
    //     0x666168: mov             fp, SP
    // 0x66616c: AllocStack(0x20)
    //     0x66616c: sub             SP, SP, #0x20
    // 0x666170: CheckStackOverflow
    //     0x666170: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x666174: cmp             SP, x16
    //     0x666178: b.ls            #0x6662c8
    // 0x66617c: ldr             x0, [fp, #0x20]
    // 0x666180: LoadField: r1 = r0->field_2f
    //     0x666180: ldur            w1, [x0, #0x2f]
    // 0x666184: DecompressPointer r1
    //     0x666184: add             x1, x1, HEAP, lsl #32
    // 0x666188: stur            x1, [fp, #-0x10]
    // 0x66618c: LoadField: r3 = r1->field_b
    //     0x66618c: ldur            w3, [x1, #0xb]
    // 0x666190: DecompressPointer r3
    //     0x666190: add             x3, x3, HEAP, lsl #32
    // 0x666194: stur            x3, [fp, #-0x20]
    // 0x666198: cmp             w3, NULL
    // 0x66619c: b.ne            #0x6661f0
    // 0x6661a0: ldr             x2, [fp, #0x10]
    // 0x6661a4: LoadField: r3 = r0->field_63
    //     0x6661a4: ldur            w3, [x0, #0x63]
    // 0x6661a8: DecompressPointer r3
    //     0x6661a8: add             x3, x3, HEAP, lsl #32
    // 0x6661ac: stur            x3, [fp, #-8]
    // 0x6661b0: r0 = LeaderLayer()
    //     0x6661b0: bl              #0x65c7b0  ; AllocateLeaderLayerStub -> LeaderLayer (size=0x50)
    // 0x6661b4: mov             x1, x0
    // 0x6661b8: ldur            x0, [fp, #-8]
    // 0x6661bc: stur            x1, [fp, #-0x18]
    // 0x6661c0: StoreField: r1->field_47 = r0
    //     0x6661c0: stur            w0, [x1, #0x47]
    // 0x6661c4: ldr             x4, [fp, #0x10]
    // 0x6661c8: StoreField: r1->field_4b = r4
    //     0x6661c8: stur            w4, [x1, #0x4b]
    // 0x6661cc: SaveReg r1
    //     0x6661cc: str             x1, [SP, #-8]!
    // 0x6661d0: r0 = Layer()
    //     0x6661d0: bl              #0x5bbe7c  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0x6661d4: add             SP, SP, #8
    // 0x6661d8: ldur            x16, [fp, #-0x10]
    // 0x6661dc: ldur            lr, [fp, #-0x18]
    // 0x6661e0: stp             lr, x16, [SP, #-0x10]!
    // 0x6661e4: r0 = layer=()
    //     0x6661e4: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x6661e8: add             SP, SP, #0x10
    // 0x6661ec: b               #0x666258
    // 0x6661f0: mov             x5, x0
    // 0x6661f4: ldr             x4, [fp, #0x10]
    // 0x6661f8: mov             x0, x3
    // 0x6661fc: r2 = Null
    //     0x6661fc: mov             x2, NULL
    // 0x666200: r1 = Null
    //     0x666200: mov             x1, NULL
    // 0x666204: r4 = LoadClassIdInstr(r0)
    //     0x666204: ldur            x4, [x0, #-1]
    //     0x666208: ubfx            x4, x4, #0xc, #0x14
    // 0x66620c: cmp             x4, #0x951
    // 0x666210: b.eq            #0x666228
    // 0x666214: r8 = LeaderLayer
    //     0x666214: add             x8, PP, #0x4f, lsl #12  ; [pp+0x4fd08] Type: LeaderLayer
    //     0x666218: ldr             x8, [x8, #0xd08]
    // 0x66621c: r3 = Null
    //     0x66621c: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fd10] Null
    //     0x666220: ldr             x3, [x3, #0xd10]
    // 0x666224: r0 = DefaultTypeTest()
    //     0x666224: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x666228: ldr             x0, [fp, #0x20]
    // 0x66622c: LoadField: r1 = r0->field_63
    //     0x66622c: ldur            w1, [x0, #0x63]
    // 0x666230: DecompressPointer r1
    //     0x666230: add             x1, x1, HEAP, lsl #32
    // 0x666234: ldur            x16, [fp, #-0x20]
    // 0x666238: stp             x1, x16, [SP, #-0x10]!
    // 0x66623c: r0 = link=()
    //     0x66623c: bl              #0x666360  ; [package:flutter/src/rendering/layer.dart] LeaderLayer::link=
    // 0x666240: add             SP, SP, #0x10
    // 0x666244: ldur            x16, [fp, #-0x20]
    // 0x666248: ldr             lr, [fp, #0x10]
    // 0x66624c: stp             lr, x16, [SP, #-0x10]!
    // 0x666250: r0 = offset=()
    //     0x666250: bl              #0x6662d4  ; [package:flutter/src/rendering/layer.dart] LeaderLayer::offset=
    // 0x666254: add             SP, SP, #0x10
    // 0x666258: ldr             x0, [fp, #0x20]
    // 0x66625c: ldur            x1, [fp, #-0x10]
    // 0x666260: LoadField: r2 = r1->field_b
    //     0x666260: ldur            w2, [x1, #0xb]
    // 0x666264: DecompressPointer r2
    //     0x666264: add             x2, x2, HEAP, lsl #32
    // 0x666268: stur            x2, [fp, #-8]
    // 0x66626c: cmp             w2, NULL
    // 0x666270: b.eq            #0x6662d0
    // 0x666274: r1 = 1
    //     0x666274: mov             x1, #1
    // 0x666278: r0 = AllocateContext()
    //     0x666278: bl              #0xd68aa4  ; AllocateContextStub
    // 0x66627c: mov             x1, x0
    // 0x666280: ldr             x0, [fp, #0x20]
    // 0x666284: StoreField: r1->field_f = r0
    //     0x666284: stur            w0, [x1, #0xf]
    // 0x666288: mov             x2, x1
    // 0x66628c: r1 = Function 'paint':.
    //     0x66628c: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cef0] AnonymousClosure: (0x661630), in [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::paint (0x669ddc)
    //     0x666290: ldr             x1, [x1, #0xef0]
    // 0x666294: r0 = AllocateClosure()
    //     0x666294: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x666298: ldr             x16, [fp, #0x18]
    // 0x66629c: ldur            lr, [fp, #-8]
    // 0x6662a0: stp             lr, x16, [SP, #-0x10]!
    // 0x6662a4: r16 = Instance_Offset
    //     0x6662a4: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x6662a8: stp             x16, x0, [SP, #-0x10]!
    // 0x6662ac: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x6662ac: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x6662b0: r0 = pushLayer()
    //     0x6662b0: bl              #0x65bbc8  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0x6662b4: add             SP, SP, #0x20
    // 0x6662b8: r0 = Null
    //     0x6662b8: mov             x0, NULL
    // 0x6662bc: LeaveFrame
    //     0x6662bc: mov             SP, fp
    //     0x6662c0: ldp             fp, lr, [SP], #0x10
    // 0x6662c4: ret
    //     0x6662c4: ret             
    // 0x6662c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6662c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6662cc: b               #0x66617c
    // 0x6662d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6662d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x68ff5c, size: 0x9c
    // 0x68ff5c: EnterFrame
    //     0x68ff5c: stp             fp, lr, [SP, #-0x10]!
    //     0x68ff60: mov             fp, SP
    // 0x68ff64: CheckStackOverflow
    //     0x68ff64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68ff68: cmp             SP, x16
    //     0x68ff6c: b.ls            #0x68ffec
    // 0x68ff70: ldr             x16, [fp, #0x10]
    // 0x68ff74: SaveReg r16
    //     0x68ff74: str             x16, [SP, #-8]!
    // 0x68ff78: r0 = performLayout()
    //     0x68ff78: bl              #0x68fff8  ; [package:flutter/src/rendering/proxy_box.dart] _RenderProxyBox&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::performLayout
    // 0x68ff7c: add             SP, SP, #8
    // 0x68ff80: ldr             x1, [fp, #0x10]
    // 0x68ff84: LoadField: r2 = r1->field_57
    //     0x68ff84: ldur            w2, [x1, #0x57]
    // 0x68ff88: DecompressPointer r2
    //     0x68ff88: add             x2, x2, HEAP, lsl #32
    // 0x68ff8c: cmp             w2, NULL
    // 0x68ff90: b.eq            #0x68fff4
    // 0x68ff94: mov             x0, x2
    // 0x68ff98: StoreField: r1->field_67 = r0
    //     0x68ff98: stur            w0, [x1, #0x67]
    //     0x68ff9c: ldurb           w16, [x1, #-1]
    //     0x68ffa0: ldurb           w17, [x0, #-1]
    //     0x68ffa4: and             x16, x17, x16, lsr #2
    //     0x68ffa8: tst             x16, HEAP, lsr #32
    //     0x68ffac: b.eq            #0x68ffb4
    //     0x68ffb0: bl              #0xd6826c
    // 0x68ffb4: LoadField: r3 = r1->field_63
    //     0x68ffb4: ldur            w3, [x1, #0x63]
    // 0x68ffb8: DecompressPointer r3
    //     0x68ffb8: add             x3, x3, HEAP, lsl #32
    // 0x68ffbc: mov             x0, x2
    // 0x68ffc0: StoreField: r3->field_b = r0
    //     0x68ffc0: stur            w0, [x3, #0xb]
    //     0x68ffc4: ldurb           w16, [x3, #-1]
    //     0x68ffc8: ldurb           w17, [x0, #-1]
    //     0x68ffcc: and             x16, x17, x16, lsr #2
    //     0x68ffd0: tst             x16, HEAP, lsr #32
    //     0x68ffd4: b.eq            #0x68ffdc
    //     0x68ffd8: bl              #0xd682ac
    // 0x68ffdc: r0 = Null
    //     0x68ffdc: mov             x0, NULL
    // 0x68ffe0: LeaveFrame
    //     0x68ffe0: mov             SP, fp
    //     0x68ffe4: ldp             fp, lr, [SP], #0x10
    // 0x68ffe8: ret
    //     0x68ffe8: ret             
    // 0x68ffec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68ffec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68fff0: b               #0x68ff70
    // 0x68fff4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68fff4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ link=(/* No info */) {
    // ** addr: 0x6c4a44, size: 0xb0
    // 0x6c4a44: EnterFrame
    //     0x6c4a44: stp             fp, lr, [SP, #-0x10]!
    //     0x6c4a48: mov             fp, SP
    // 0x6c4a4c: CheckStackOverflow
    //     0x6c4a4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c4a50: cmp             SP, x16
    //     0x6c4a54: b.ls            #0x6c4aec
    // 0x6c4a58: ldr             x1, [fp, #0x18]
    // 0x6c4a5c: LoadField: r0 = r1->field_63
    //     0x6c4a5c: ldur            w0, [x1, #0x63]
    // 0x6c4a60: DecompressPointer r0
    //     0x6c4a60: add             x0, x0, HEAP, lsl #32
    // 0x6c4a64: ldr             x2, [fp, #0x10]
    // 0x6c4a68: cmp             w0, w2
    // 0x6c4a6c: b.ne            #0x6c4a80
    // 0x6c4a70: r0 = Null
    //     0x6c4a70: mov             x0, NULL
    // 0x6c4a74: LeaveFrame
    //     0x6c4a74: mov             SP, fp
    //     0x6c4a78: ldp             fp, lr, [SP], #0x10
    // 0x6c4a7c: ret
    //     0x6c4a7c: ret             
    // 0x6c4a80: StoreField: r0->field_b = rNULL
    //     0x6c4a80: stur            NULL, [x0, #0xb]
    // 0x6c4a84: mov             x0, x2
    // 0x6c4a88: StoreField: r1->field_63 = r0
    //     0x6c4a88: stur            w0, [x1, #0x63]
    //     0x6c4a8c: ldurb           w16, [x1, #-1]
    //     0x6c4a90: ldurb           w17, [x0, #-1]
    //     0x6c4a94: and             x16, x17, x16, lsr #2
    //     0x6c4a98: tst             x16, HEAP, lsr #32
    //     0x6c4a9c: b.eq            #0x6c4aa4
    //     0x6c4aa0: bl              #0xd6826c
    // 0x6c4aa4: LoadField: r0 = r1->field_67
    //     0x6c4aa4: ldur            w0, [x1, #0x67]
    // 0x6c4aa8: DecompressPointer r0
    //     0x6c4aa8: add             x0, x0, HEAP, lsl #32
    // 0x6c4aac: cmp             w0, NULL
    // 0x6c4ab0: b.eq            #0x6c4ad0
    // 0x6c4ab4: StoreField: r2->field_b = r0
    //     0x6c4ab4: stur            w0, [x2, #0xb]
    //     0x6c4ab8: ldurb           w16, [x2, #-1]
    //     0x6c4abc: ldurb           w17, [x0, #-1]
    //     0x6c4ac0: and             x16, x17, x16, lsr #2
    //     0x6c4ac4: tst             x16, HEAP, lsr #32
    //     0x6c4ac8: b.eq            #0x6c4ad0
    //     0x6c4acc: bl              #0xd6828c
    // 0x6c4ad0: SaveReg r1
    //     0x6c4ad0: str             x1, [SP, #-8]!
    // 0x6c4ad4: r0 = markNeedsPaint()
    //     0x6c4ad4: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c4ad8: add             SP, SP, #8
    // 0x6c4adc: r0 = Null
    //     0x6c4adc: mov             x0, NULL
    // 0x6c4ae0: LeaveFrame
    //     0x6c4ae0: mov             SP, fp
    //     0x6c4ae4: ldp             fp, lr, [SP], #0x10
    // 0x6c4ae8: ret
    //     0x6c4ae8: ret             
    // 0x6c4aec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c4aec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c4af0: b               #0x6c4a58
  }
}

// class id: 2483, size: 0x6c, field offset: 0x64
class RenderIndexedSemantics extends RenderProxyBox {

  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0x6500d0, size: 0x44
    // 0x6500d0: EnterFrame
    //     0x6500d0: stp             fp, lr, [SP, #-0x10]!
    //     0x6500d4: mov             fp, SP
    // 0x6500d8: CheckStackOverflow
    //     0x6500d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6500dc: cmp             SP, x16
    //     0x6500e0: b.ls            #0x65010c
    // 0x6500e4: ldr             x0, [fp, #0x18]
    // 0x6500e8: LoadField: r1 = r0->field_63
    //     0x6500e8: ldur            x1, [x0, #0x63]
    // 0x6500ec: ldr             x16, [fp, #0x10]
    // 0x6500f0: stp             x1, x16, [SP, #-0x10]!
    // 0x6500f4: r0 = indexInParent=()
    //     0x6500f4: bl              #0x650114  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::indexInParent=
    // 0x6500f8: add             SP, SP, #0x10
    // 0x6500fc: r0 = Null
    //     0x6500fc: mov             x0, NULL
    // 0x650100: LeaveFrame
    //     0x650100: mov             SP, fp
    //     0x650104: ldp             fp, lr, [SP], #0x10
    // 0x650108: ret
    //     0x650108: ret             
    // 0x65010c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65010c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x650110: b               #0x6500e4
  }
  set _ index=(/* No info */) {
    // ** addr: 0x6c74c0, size: 0x60
    // 0x6c74c0: EnterFrame
    //     0x6c74c0: stp             fp, lr, [SP, #-0x10]!
    //     0x6c74c4: mov             fp, SP
    // 0x6c74c8: CheckStackOverflow
    //     0x6c74c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c74cc: cmp             SP, x16
    //     0x6c74d0: b.ls            #0x6c7518
    // 0x6c74d4: ldr             x0, [fp, #0x18]
    // 0x6c74d8: LoadField: r1 = r0->field_63
    //     0x6c74d8: ldur            x1, [x0, #0x63]
    // 0x6c74dc: ldr             x2, [fp, #0x10]
    // 0x6c74e0: cmp             x2, x1
    // 0x6c74e4: b.ne            #0x6c74f8
    // 0x6c74e8: r0 = Null
    //     0x6c74e8: mov             x0, NULL
    // 0x6c74ec: LeaveFrame
    //     0x6c74ec: mov             SP, fp
    //     0x6c74f0: ldp             fp, lr, [SP], #0x10
    // 0x6c74f4: ret
    //     0x6c74f4: ret             
    // 0x6c74f8: StoreField: r0->field_63 = r2
    //     0x6c74f8: stur            x2, [x0, #0x63]
    // 0x6c74fc: SaveReg r0
    //     0x6c74fc: str             x0, [SP, #-8]!
    // 0x6c7500: r0 = markNeedsSemanticsUpdate()
    //     0x6c7500: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6c7504: add             SP, SP, #8
    // 0x6c7508: r0 = Null
    //     0x6c7508: mov             x0, NULL
    // 0x6c750c: LeaveFrame
    //     0x6c750c: mov             SP, fp
    //     0x6c7510: ldp             fp, lr, [SP], #0x10
    // 0x6c7514: ret
    //     0x6c7514: ret             
    // 0x6c7518: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c7518: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c751c: b               #0x6c74d4
  }
}

// class id: 2484, size: 0x68, field offset: 0x64
class RenderExcludeSemantics extends RenderProxyBox {

  _ visitChildrenForSemantics(/* No info */) {
    // ** addr: 0x675e84, size: 0x5c
    // 0x675e84: EnterFrame
    //     0x675e84: stp             fp, lr, [SP, #-0x10]!
    //     0x675e88: mov             fp, SP
    // 0x675e8c: CheckStackOverflow
    //     0x675e8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x675e90: cmp             SP, x16
    //     0x675e94: b.ls            #0x675ed8
    // 0x675e98: ldr             x0, [fp, #0x18]
    // 0x675e9c: LoadField: r1 = r0->field_63
    //     0x675e9c: ldur            w1, [x0, #0x63]
    // 0x675ea0: DecompressPointer r1
    //     0x675ea0: add             x1, x1, HEAP, lsl #32
    // 0x675ea4: tbnz            w1, #4, #0x675eb8
    // 0x675ea8: r0 = Null
    //     0x675ea8: mov             x0, NULL
    // 0x675eac: LeaveFrame
    //     0x675eac: mov             SP, fp
    //     0x675eb0: ldp             fp, lr, [SP], #0x10
    // 0x675eb4: ret
    //     0x675eb4: ret             
    // 0x675eb8: ldr             x16, [fp, #0x10]
    // 0x675ebc: stp             x16, x0, [SP, #-0x10]!
    // 0x675ec0: r0 = visitChildren()
    //     0x675ec0: bl              #0x6bf90c  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::visitChildren
    // 0x675ec4: add             SP, SP, #0x10
    // 0x675ec8: r0 = Null
    //     0x675ec8: mov             x0, NULL
    // 0x675ecc: LeaveFrame
    //     0x675ecc: mov             SP, fp
    //     0x675ed0: ldp             fp, lr, [SP], #0x10
    // 0x675ed4: ret
    //     0x675ed4: ret             
    // 0x675ed8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x675ed8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x675edc: b               #0x675e98
  }
  set _ excluding=(/* No info */) {
    // ** addr: 0x6c73e0, size: 0x64
    // 0x6c73e0: EnterFrame
    //     0x6c73e0: stp             fp, lr, [SP, #-0x10]!
    //     0x6c73e4: mov             fp, SP
    // 0x6c73e8: CheckStackOverflow
    //     0x6c73e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c73ec: cmp             SP, x16
    //     0x6c73f0: b.ls            #0x6c743c
    // 0x6c73f4: ldr             x0, [fp, #0x18]
    // 0x6c73f8: LoadField: r1 = r0->field_63
    //     0x6c73f8: ldur            w1, [x0, #0x63]
    // 0x6c73fc: DecompressPointer r1
    //     0x6c73fc: add             x1, x1, HEAP, lsl #32
    // 0x6c7400: ldr             x2, [fp, #0x10]
    // 0x6c7404: cmp             w2, w1
    // 0x6c7408: b.ne            #0x6c741c
    // 0x6c740c: r0 = Null
    //     0x6c740c: mov             x0, NULL
    // 0x6c7410: LeaveFrame
    //     0x6c7410: mov             SP, fp
    //     0x6c7414: ldp             fp, lr, [SP], #0x10
    // 0x6c7418: ret
    //     0x6c7418: ret             
    // 0x6c741c: StoreField: r0->field_63 = r2
    //     0x6c741c: stur            w2, [x0, #0x63]
    // 0x6c7420: SaveReg r0
    //     0x6c7420: str             x0, [SP, #-8]!
    // 0x6c7424: r0 = markNeedsSemanticsUpdate()
    //     0x6c7424: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6c7428: add             SP, SP, #8
    // 0x6c742c: r0 = Null
    //     0x6c742c: mov             x0, NULL
    // 0x6c7430: LeaveFrame
    //     0x6c7430: mov             SP, fp
    //     0x6c7434: ldp             fp, lr, [SP], #0x10
    // 0x6c7438: ret
    //     0x6c7438: ret             
    // 0x6c743c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c743c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c7440: b               #0x6c73f4
  }
}

// class id: 2485, size: 0x64, field offset: 0x64
class RenderMergeSemantics extends RenderProxyBox {

  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0x650070, size: 0x48
    // 0x650070: EnterFrame
    //     0x650070: stp             fp, lr, [SP, #-0x10]!
    //     0x650074: mov             fp, SP
    // 0x650078: r0 = true
    //     0x650078: add             x0, NULL, #0x20  ; true
    // 0x65007c: CheckStackOverflow
    //     0x65007c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x650080: cmp             SP, x16
    //     0x650084: b.ls            #0x6500b0
    // 0x650088: ldr             x1, [fp, #0x10]
    // 0x65008c: StoreField: r1->field_7 = r0
    //     0x65008c: stur            w0, [x1, #7]
    // 0x650090: r16 = true
    //     0x650090: add             x16, NULL, #0x20  ; true
    // 0x650094: stp             x16, x1, [SP, #-0x10]!
    // 0x650098: r0 = isMergingSemanticsOfDescendants=()
    //     0x650098: bl              #0x6500b8  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isMergingSemanticsOfDescendants=
    // 0x65009c: add             SP, SP, #0x10
    // 0x6500a0: r0 = Null
    //     0x6500a0: mov             x0, NULL
    // 0x6500a4: LeaveFrame
    //     0x6500a4: mov             SP, fp
    //     0x6500a8: ldp             fp, lr, [SP], #0x10
    // 0x6500ac: ret
    //     0x6500ac: ret             
    // 0x6500b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6500b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6500b4: b               #0x650088
  }
}

// class id: 2486, size: 0x68, field offset: 0x64
class RenderBlockSemantics extends RenderProxyBox {

  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0x65005c, size: 0x14
    // 0x65005c: r1 = true
    //     0x65005c: add             x1, NULL, #0x20  ; true
    // 0x650060: ldr             x2, [SP]
    // 0x650064: StoreField: r2->field_f = r1
    //     0x650064: stur            w1, [x2, #0xf]
    // 0x650068: r0 = Null
    //     0x650068: mov             x0, NULL
    // 0x65006c: ret
    //     0x65006c: ret             
  }
}

// class id: 2487, size: 0x8c, field offset: 0x64
class RenderSemanticsAnnotations extends RenderProxyBox {

  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0x64ed70, size: 0x6b4
    // 0x64ed70: EnterFrame
    //     0x64ed70: stp             fp, lr, [SP, #-0x10]!
    //     0x64ed74: mov             fp, SP
    // 0x64ed78: CheckStackOverflow
    //     0x64ed78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64ed7c: cmp             SP, x16
    //     0x64ed80: b.ls            #0x64f41c
    // 0x64ed84: ldr             x0, [fp, #0x18]
    // 0x64ed88: LoadField: r1 = r0->field_67
    //     0x64ed88: ldur            w1, [x0, #0x67]
    // 0x64ed8c: DecompressPointer r1
    //     0x64ed8c: add             x1, x1, HEAP, lsl #32
    // 0x64ed90: ldr             x2, [fp, #0x10]
    // 0x64ed94: StoreField: r2->field_7 = r1
    //     0x64ed94: stur            w1, [x2, #7]
    // 0x64ed98: LoadField: r1 = r0->field_6b
    //     0x64ed98: ldur            w1, [x0, #0x6b]
    // 0x64ed9c: DecompressPointer r1
    //     0x64ed9c: add             x1, x1, HEAP, lsl #32
    // 0x64eda0: StoreField: r2->field_b = r1
    //     0x64eda0: stur            w1, [x2, #0xb]
    // 0x64eda4: LoadField: r1 = r0->field_63
    //     0x64eda4: ldur            w1, [x0, #0x63]
    // 0x64eda8: DecompressPointer r1
    //     0x64eda8: add             x1, x1, HEAP, lsl #32
    // 0x64edac: LoadField: r3 = r1->field_7
    //     0x64edac: ldur            w3, [x1, #7]
    // 0x64edb0: DecompressPointer r3
    //     0x64edb0: add             x3, x3, HEAP, lsl #32
    // 0x64edb4: cmp             w3, NULL
    // 0x64edb8: b.eq            #0x64edc8
    // 0x64edbc: stp             x3, x2, [SP, #-0x10]!
    // 0x64edc0: r0 = isEnabled=()
    //     0x64edc0: bl              #0x64fb68  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isEnabled=
    // 0x64edc4: add             SP, SP, #0x10
    // 0x64edc8: ldr             x0, [fp, #0x18]
    // 0x64edcc: LoadField: r1 = r0->field_63
    //     0x64edcc: ldur            w1, [x0, #0x63]
    // 0x64edd0: DecompressPointer r1
    //     0x64edd0: add             x1, x1, HEAP, lsl #32
    // 0x64edd4: LoadField: r2 = r1->field_b
    //     0x64edd4: ldur            w2, [x1, #0xb]
    // 0x64edd8: DecompressPointer r2
    //     0x64edd8: add             x2, x2, HEAP, lsl #32
    // 0x64eddc: cmp             w2, NULL
    // 0x64ede0: b.eq            #0x64edf4
    // 0x64ede4: ldr             x16, [fp, #0x10]
    // 0x64ede8: stp             x2, x16, [SP, #-0x10]!
    // 0x64edec: r0 = isChecked=()
    //     0x64edec: bl              #0x64faf0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isChecked=
    // 0x64edf0: add             SP, SP, #0x10
    // 0x64edf4: ldr             x0, [fp, #0x18]
    // 0x64edf8: LoadField: r1 = r0->field_63
    //     0x64edf8: ldur            w1, [x0, #0x63]
    // 0x64edfc: DecompressPointer r1
    //     0x64edfc: add             x1, x1, HEAP, lsl #32
    // 0x64ee00: LoadField: r2 = r1->field_f
    //     0x64ee00: ldur            w2, [x1, #0xf]
    // 0x64ee04: DecompressPointer r2
    //     0x64ee04: add             x2, x2, HEAP, lsl #32
    // 0x64ee08: cmp             w2, NULL
    // 0x64ee0c: b.eq            #0x64ee20
    // 0x64ee10: ldr             x16, [fp, #0x10]
    // 0x64ee14: stp             x2, x16, [SP, #-0x10]!
    // 0x64ee18: r0 = isCheckStateMixed=()
    //     0x64ee18: bl              #0x64fa78  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isCheckStateMixed=
    // 0x64ee1c: add             SP, SP, #0x10
    // 0x64ee20: ldr             x0, [fp, #0x18]
    // 0x64ee24: LoadField: r1 = r0->field_63
    //     0x64ee24: ldur            w1, [x0, #0x63]
    // 0x64ee28: DecompressPointer r1
    //     0x64ee28: add             x1, x1, HEAP, lsl #32
    // 0x64ee2c: LoadField: r2 = r1->field_17
    //     0x64ee2c: ldur            w2, [x1, #0x17]
    // 0x64ee30: DecompressPointer r2
    //     0x64ee30: add             x2, x2, HEAP, lsl #32
    // 0x64ee34: cmp             w2, NULL
    // 0x64ee38: b.eq            #0x64ee4c
    // 0x64ee3c: ldr             x16, [fp, #0x10]
    // 0x64ee40: stp             x2, x16, [SP, #-0x10]!
    // 0x64ee44: r0 = isSelected=()
    //     0x64ee44: bl              #0x64fa2c  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isSelected=
    // 0x64ee48: add             SP, SP, #0x10
    // 0x64ee4c: ldr             x0, [fp, #0x18]
    // 0x64ee50: LoadField: r1 = r0->field_63
    //     0x64ee50: ldur            w1, [x0, #0x63]
    // 0x64ee54: DecompressPointer r1
    //     0x64ee54: add             x1, x1, HEAP, lsl #32
    // 0x64ee58: LoadField: r2 = r1->field_1b
    //     0x64ee58: ldur            w2, [x1, #0x1b]
    // 0x64ee5c: DecompressPointer r2
    //     0x64ee5c: add             x2, x2, HEAP, lsl #32
    // 0x64ee60: cmp             w2, NULL
    // 0x64ee64: b.eq            #0x64ee78
    // 0x64ee68: ldr             x16, [fp, #0x10]
    // 0x64ee6c: stp             x2, x16, [SP, #-0x10]!
    // 0x64ee70: r0 = isButton=()
    //     0x64ee70: bl              #0x64f9e0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isButton=
    // 0x64ee74: add             SP, SP, #0x10
    // 0x64ee78: ldr             x0, [fp, #0x18]
    // 0x64ee7c: LoadField: r1 = r0->field_63
    //     0x64ee7c: ldur            w1, [x0, #0x63]
    // 0x64ee80: DecompressPointer r1
    //     0x64ee80: add             x1, x1, HEAP, lsl #32
    // 0x64ee84: LoadField: r2 = r1->field_2b
    //     0x64ee84: ldur            w2, [x1, #0x2b]
    // 0x64ee88: DecompressPointer r2
    //     0x64ee88: add             x2, x2, HEAP, lsl #32
    // 0x64ee8c: cmp             w2, NULL
    // 0x64ee90: b.eq            #0x64eea4
    // 0x64ee94: ldr             x16, [fp, #0x10]
    // 0x64ee98: stp             x2, x16, [SP, #-0x10]!
    // 0x64ee9c: r0 = isSlider=()
    //     0x64ee9c: bl              #0x64e014  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isSlider=
    // 0x64eea0: add             SP, SP, #0x10
    // 0x64eea4: ldr             x0, [fp, #0x18]
    // 0x64eea8: LoadField: r1 = r0->field_63
    //     0x64eea8: ldur            w1, [x0, #0x63]
    // 0x64eeac: DecompressPointer r1
    //     0x64eeac: add             x1, x1, HEAP, lsl #32
    // 0x64eeb0: LoadField: r2 = r1->field_23
    //     0x64eeb0: ldur            w2, [x1, #0x23]
    // 0x64eeb4: DecompressPointer r2
    //     0x64eeb4: add             x2, x2, HEAP, lsl #32
    // 0x64eeb8: cmp             w2, NULL
    // 0x64eebc: b.eq            #0x64eed0
    // 0x64eec0: ldr             x16, [fp, #0x10]
    // 0x64eec4: stp             x2, x16, [SP, #-0x10]!
    // 0x64eec8: r0 = isHeader=()
    //     0x64eec8: bl              #0x64f994  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isHeader=
    // 0x64eecc: add             SP, SP, #0x10
    // 0x64eed0: ldr             x0, [fp, #0x18]
    // 0x64eed4: LoadField: r1 = r0->field_63
    //     0x64eed4: ldur            w1, [x0, #0x63]
    // 0x64eed8: DecompressPointer r1
    //     0x64eed8: add             x1, x1, HEAP, lsl #32
    // 0x64eedc: LoadField: r2 = r1->field_37
    //     0x64eedc: ldur            w2, [x1, #0x37]
    // 0x64eee0: DecompressPointer r2
    //     0x64eee0: add             x2, x2, HEAP, lsl #32
    // 0x64eee4: cmp             w2, NULL
    // 0x64eee8: b.eq            #0x64eefc
    // 0x64eeec: ldr             x16, [fp, #0x10]
    // 0x64eef0: stp             x2, x16, [SP, #-0x10]!
    // 0x64eef4: r0 = isFocusable=()
    //     0x64eef4: bl              #0x64f948  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isFocusable=
    // 0x64eef8: add             SP, SP, #0x10
    // 0x64eefc: ldr             x0, [fp, #0x18]
    // 0x64ef00: LoadField: r1 = r0->field_63
    //     0x64ef00: ldur            w1, [x0, #0x63]
    // 0x64ef04: DecompressPointer r1
    //     0x64ef04: add             x1, x1, HEAP, lsl #32
    // 0x64ef08: LoadField: r2 = r1->field_3b
    //     0x64ef08: ldur            w2, [x1, #0x3b]
    // 0x64ef0c: DecompressPointer r2
    //     0x64ef0c: add             x2, x2, HEAP, lsl #32
    // 0x64ef10: cmp             w2, NULL
    // 0x64ef14: b.eq            #0x64ef28
    // 0x64ef18: ldr             x16, [fp, #0x10]
    // 0x64ef1c: stp             x2, x16, [SP, #-0x10]!
    // 0x64ef20: r0 = isFocused=()
    //     0x64ef20: bl              #0x64cbec  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isFocused=
    // 0x64ef24: add             SP, SP, #0x10
    // 0x64ef28: ldr             x0, [fp, #0x18]
    // 0x64ef2c: LoadField: r1 = r0->field_63
    //     0x64ef2c: ldur            w1, [x0, #0x63]
    // 0x64ef30: DecompressPointer r1
    //     0x64ef30: add             x1, x1, HEAP, lsl #32
    // 0x64ef34: LoadField: r2 = r1->field_43
    //     0x64ef34: ldur            w2, [x1, #0x43]
    // 0x64ef38: DecompressPointer r2
    //     0x64ef38: add             x2, x2, HEAP, lsl #32
    // 0x64ef3c: cmp             w2, NULL
    // 0x64ef40: b.eq            #0x64ef5c
    // 0x64ef44: ldr             x16, [fp, #0x10]
    // 0x64ef48: r30 = Instance_SemanticsFlag
    //     0x64ef48: ldr             lr, [PP, #0x7330]  ; [pp+0x7330] Obj!SemanticsFlag@b5cb61
    // 0x64ef4c: stp             lr, x16, [SP, #-0x10]!
    // 0x64ef50: SaveReg r2
    //     0x64ef50: str             x2, [SP, #-8]!
    // 0x64ef54: r0 = _setFlag()
    //     0x64ef54: bl              #0x646790  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_setFlag
    // 0x64ef58: add             SP, SP, #0x18
    // 0x64ef5c: ldr             x0, [fp, #0x18]
    // 0x64ef60: LoadField: r1 = r0->field_63
    //     0x64ef60: ldur            w1, [x0, #0x63]
    // 0x64ef64: DecompressPointer r1
    //     0x64ef64: add             x1, x1, HEAP, lsl #32
    // 0x64ef68: LoadField: r2 = r1->field_57
    //     0x64ef68: ldur            w2, [x1, #0x57]
    // 0x64ef6c: DecompressPointer r2
    //     0x64ef6c: add             x2, x2, HEAP, lsl #32
    // 0x64ef70: cmp             w2, NULL
    // 0x64ef74: b.eq            #0x64ef88
    // 0x64ef78: ldr             x16, [fp, #0x10]
    // 0x64ef7c: stp             x2, x16, [SP, #-0x10]!
    // 0x64ef80: r0 = isImage=()
    //     0x64ef80: bl              #0x64f8fc  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isImage=
    // 0x64ef84: add             SP, SP, #0x10
    // 0x64ef88: ldr             x0, [fp, #0x18]
    // 0x64ef8c: LoadField: r1 = r0->field_73
    //     0x64ef8c: ldur            w1, [x0, #0x73]
    // 0x64ef90: DecompressPointer r1
    //     0x64ef90: add             x1, x1, HEAP, lsl #32
    // 0x64ef94: cmp             w1, NULL
    // 0x64ef98: b.eq            #0x64efac
    // 0x64ef9c: ldr             x16, [fp, #0x10]
    // 0x64efa0: stp             x1, x16, [SP, #-0x10]!
    // 0x64efa4: r0 = attributedLabel=()
    //     0x64efa4: bl              #0x64f8c0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::attributedLabel=
    // 0x64efa8: add             SP, SP, #0x10
    // 0x64efac: ldr             x0, [fp, #0x18]
    // 0x64efb0: LoadField: r1 = r0->field_77
    //     0x64efb0: ldur            w1, [x0, #0x77]
    // 0x64efb4: DecompressPointer r1
    //     0x64efb4: add             x1, x1, HEAP, lsl #32
    // 0x64efb8: cmp             w1, NULL
    // 0x64efbc: b.eq            #0x64efd0
    // 0x64efc0: ldr             x16, [fp, #0x10]
    // 0x64efc4: stp             x1, x16, [SP, #-0x10]!
    // 0x64efc8: r0 = attributedValue=()
    //     0x64efc8: bl              #0x64f884  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::attributedValue=
    // 0x64efcc: add             SP, SP, #0x10
    // 0x64efd0: ldr             x0, [fp, #0x18]
    // 0x64efd4: LoadField: r1 = r0->field_83
    //     0x64efd4: ldur            w1, [x0, #0x83]
    // 0x64efd8: DecompressPointer r1
    //     0x64efd8: add             x1, x1, HEAP, lsl #32
    // 0x64efdc: cmp             w1, NULL
    // 0x64efe0: b.eq            #0x64eff4
    // 0x64efe4: ldr             x16, [fp, #0x10]
    // 0x64efe8: stp             x1, x16, [SP, #-0x10]!
    // 0x64efec: r0 = attributedHint=()
    //     0x64efec: bl              #0x64f848  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::attributedHint=
    // 0x64eff0: add             SP, SP, #0x10
    // 0x64eff4: ldr             x0, [fp, #0x18]
    // 0x64eff8: LoadField: r1 = r0->field_63
    //     0x64eff8: ldur            w1, [x0, #0x63]
    // 0x64effc: DecompressPointer r1
    //     0x64effc: add             x1, x1, HEAP, lsl #32
    // 0x64f000: LoadField: r2 = r1->field_8f
    //     0x64f000: ldur            w2, [x1, #0x8f]
    // 0x64f004: DecompressPointer r2
    //     0x64f004: add             x2, x2, HEAP, lsl #32
    // 0x64f008: cmp             w2, NULL
    // 0x64f00c: b.eq            #0x64f020
    // 0x64f010: ldr             x16, [fp, #0x10]
    // 0x64f014: stp             x2, x16, [SP, #-0x10]!
    // 0x64f018: r0 = tooltip=()
    //     0x64f018: bl              #0x64f80c  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::tooltip=
    // 0x64f01c: add             SP, SP, #0x10
    // 0x64f020: ldr             x0, [fp, #0x18]
    // 0x64f024: LoadField: r1 = r0->field_63
    //     0x64f024: ldur            w1, [x0, #0x63]
    // 0x64f028: DecompressPointer r1
    //     0x64f028: add             x1, x1, HEAP, lsl #32
    // 0x64f02c: LoadField: r2 = r1->field_93
    //     0x64f02c: ldur            w2, [x1, #0x93]
    // 0x64f030: DecompressPointer r2
    //     0x64f030: add             x2, x2, HEAP, lsl #32
    // 0x64f034: cmp             w2, NULL
    // 0x64f038: b.eq            #0x64f06c
    // 0x64f03c: LoadField: r1 = r2->field_7
    //     0x64f03c: ldur            w1, [x2, #7]
    // 0x64f040: DecompressPointer r1
    //     0x64f040: add             x1, x1, HEAP, lsl #32
    // 0x64f044: cmp             w1, NULL
    // 0x64f048: b.ne            #0x64f05c
    // 0x64f04c: LoadField: r1 = r2->field_b
    //     0x64f04c: ldur            w1, [x2, #0xb]
    // 0x64f050: DecompressPointer r1
    //     0x64f050: add             x1, x1, HEAP, lsl #32
    // 0x64f054: cmp             w1, NULL
    // 0x64f058: b.eq            #0x64f06c
    // 0x64f05c: ldr             x16, [fp, #0x10]
    // 0x64f060: stp             x2, x16, [SP, #-0x10]!
    // 0x64f064: r0 = hintOverrides=()
    //     0x64f064: bl              #0x64f7c0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::hintOverrides=
    // 0x64f068: add             SP, SP, #0x10
    // 0x64f06c: ldr             x0, [fp, #0x18]
    // 0x64f070: LoadField: r1 = r0->field_63
    //     0x64f070: ldur            w1, [x0, #0x63]
    // 0x64f074: DecompressPointer r1
    //     0x64f074: add             x1, x1, HEAP, lsl #32
    // 0x64f078: LoadField: r2 = r1->field_4f
    //     0x64f078: ldur            w2, [x1, #0x4f]
    // 0x64f07c: DecompressPointer r2
    //     0x64f07c: add             x2, x2, HEAP, lsl #32
    // 0x64f080: cmp             w2, NULL
    // 0x64f084: b.eq            #0x64f098
    // 0x64f088: ldr             x16, [fp, #0x10]
    // 0x64f08c: stp             x2, x16, [SP, #-0x10]!
    // 0x64f090: r0 = scopesRoute=()
    //     0x64f090: bl              #0x64f774  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::scopesRoute=
    // 0x64f094: add             SP, SP, #0x10
    // 0x64f098: ldr             x0, [fp, #0x18]
    // 0x64f09c: LoadField: r1 = r0->field_63
    //     0x64f09c: ldur            w1, [x0, #0x63]
    // 0x64f0a0: DecompressPointer r1
    //     0x64f0a0: add             x1, x1, HEAP, lsl #32
    // 0x64f0a4: LoadField: r2 = r1->field_53
    //     0x64f0a4: ldur            w2, [x1, #0x53]
    // 0x64f0a8: DecompressPointer r2
    //     0x64f0a8: add             x2, x2, HEAP, lsl #32
    // 0x64f0ac: cmp             w2, NULL
    // 0x64f0b0: b.eq            #0x64f0c4
    // 0x64f0b4: ldr             x16, [fp, #0x10]
    // 0x64f0b8: stp             x2, x16, [SP, #-0x10]!
    // 0x64f0bc: r0 = namesRoute=()
    //     0x64f0bc: bl              #0x64f728  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::namesRoute=
    // 0x64f0c0: add             SP, SP, #0x10
    // 0x64f0c4: ldr             x0, [fp, #0x18]
    // 0x64f0c8: LoadField: r1 = r0->field_63
    //     0x64f0c8: ldur            w1, [x0, #0x63]
    // 0x64f0cc: DecompressPointer r1
    //     0x64f0cc: add             x1, x1, HEAP, lsl #32
    // 0x64f0d0: LoadField: r2 = r1->field_5b
    //     0x64f0d0: ldur            w2, [x1, #0x5b]
    // 0x64f0d4: DecompressPointer r2
    //     0x64f0d4: add             x2, x2, HEAP, lsl #32
    // 0x64f0d8: cmp             w2, NULL
    // 0x64f0dc: b.eq            #0x64f0f0
    // 0x64f0e0: ldr             x16, [fp, #0x10]
    // 0x64f0e4: stp             x2, x16, [SP, #-0x10]!
    // 0x64f0e8: r0 = liveRegion=()
    //     0x64f0e8: bl              #0x64f6dc  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::liveRegion=
    // 0x64f0ec: add             SP, SP, #0x10
    // 0x64f0f0: ldr             x0, [fp, #0x18]
    // 0x64f0f4: LoadField: r1 = r0->field_63
    //     0x64f0f4: ldur            w1, [x0, #0x63]
    // 0x64f0f8: DecompressPointer r1
    //     0x64f0f8: add             x1, x1, HEAP, lsl #32
    // 0x64f0fc: LoadField: r2 = r1->field_5f
    //     0x64f0fc: ldur            w2, [x1, #0x5f]
    // 0x64f100: DecompressPointer r2
    //     0x64f100: add             x2, x2, HEAP, lsl #32
    // 0x64f104: cmp             w2, NULL
    // 0x64f108: b.eq            #0x64f11c
    // 0x64f10c: ldr             x16, [fp, #0x10]
    // 0x64f110: stp             x2, x16, [SP, #-0x10]!
    // 0x64f114: r0 = maxValueLength=()
    //     0x64f114: bl              #0x64f6a8  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::maxValueLength=
    // 0x64f118: add             SP, SP, #0x10
    // 0x64f11c: ldr             x0, [fp, #0x18]
    // 0x64f120: LoadField: r1 = r0->field_63
    //     0x64f120: ldur            w1, [x0, #0x63]
    // 0x64f124: DecompressPointer r1
    //     0x64f124: add             x1, x1, HEAP, lsl #32
    // 0x64f128: LoadField: r2 = r1->field_63
    //     0x64f128: ldur            w2, [x1, #0x63]
    // 0x64f12c: DecompressPointer r2
    //     0x64f12c: add             x2, x2, HEAP, lsl #32
    // 0x64f130: cmp             w2, NULL
    // 0x64f134: b.eq            #0x64f148
    // 0x64f138: ldr             x16, [fp, #0x10]
    // 0x64f13c: stp             x2, x16, [SP, #-0x10]!
    // 0x64f140: r0 = currentValueLength=()
    //     0x64f140: bl              #0x64f618  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::currentValueLength=
    // 0x64f144: add             SP, SP, #0x10
    // 0x64f148: ldr             x1, [fp, #0x18]
    // 0x64f14c: LoadField: r0 = r1->field_87
    //     0x64f14c: ldur            w0, [x1, #0x87]
    // 0x64f150: DecompressPointer r0
    //     0x64f150: add             x0, x0, HEAP, lsl #32
    // 0x64f154: cmp             w0, NULL
    // 0x64f158: b.eq            #0x64f188
    // 0x64f15c: ldr             x2, [fp, #0x10]
    // 0x64f160: r3 = true
    //     0x64f160: add             x3, NULL, #0x20  ; true
    // 0x64f164: StoreField: r2->field_73 = r0
    //     0x64f164: stur            w0, [x2, #0x73]
    //     0x64f168: ldurb           w16, [x2, #-1]
    //     0x64f16c: ldurb           w17, [x0, #-1]
    //     0x64f170: and             x16, x17, x16, lsr #2
    //     0x64f174: tst             x16, HEAP, lsr #32
    //     0x64f178: b.eq            #0x64f180
    //     0x64f17c: bl              #0xd6828c
    // 0x64f180: StoreField: r2->field_13 = r3
    //     0x64f180: stur            w3, [x2, #0x13]
    // 0x64f184: b               #0x64f18c
    // 0x64f188: ldr             x2, [fp, #0x10]
    // 0x64f18c: LoadField: r0 = r1->field_63
    //     0x64f18c: ldur            w0, [x1, #0x63]
    // 0x64f190: DecompressPointer r0
    //     0x64f190: add             x0, x0, HEAP, lsl #32
    // 0x64f194: LoadField: r3 = r0->field_9b
    //     0x64f194: ldur            w3, [x0, #0x9b]
    // 0x64f198: DecompressPointer r3
    //     0x64f198: add             x3, x3, HEAP, lsl #32
    // 0x64f19c: cmp             w3, NULL
    // 0x64f1a0: b.eq            #0x64f1b0
    // 0x64f1a4: stp             x3, x2, [SP, #-0x10]!
    // 0x64f1a8: r0 = sortKey=()
    //     0x64f1a8: bl              #0x64f5dc  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::sortKey=
    // 0x64f1ac: add             SP, SP, #0x10
    // 0x64f1b0: ldr             x0, [fp, #0x18]
    // 0x64f1b4: LoadField: r1 = r0->field_63
    //     0x64f1b4: ldur            w1, [x0, #0x63]
    // 0x64f1b8: DecompressPointer r1
    //     0x64f1b8: add             x1, x1, HEAP, lsl #32
    // 0x64f1bc: LoadField: r2 = r1->field_9f
    //     0x64f1bc: ldur            w2, [x1, #0x9f]
    // 0x64f1c0: DecompressPointer r2
    //     0x64f1c0: add             x2, x2, HEAP, lsl #32
    // 0x64f1c4: cmp             w2, NULL
    // 0x64f1c8: b.eq            #0x64f1dc
    // 0x64f1cc: ldr             x16, [fp, #0x10]
    // 0x64f1d0: stp             x2, x16, [SP, #-0x10]!
    // 0x64f1d4: r0 = addTagForChildren()
    //     0x64f1d4: bl              #0x64be88  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::addTagForChildren
    // 0x64f1d8: add             SP, SP, #0x10
    // 0x64f1dc: ldr             x0, [fp, #0x18]
    // 0x64f1e0: LoadField: r1 = r0->field_63
    //     0x64f1e0: ldur            w1, [x0, #0x63]
    // 0x64f1e4: DecompressPointer r1
    //     0x64f1e4: add             x1, x1, HEAP, lsl #32
    // 0x64f1e8: LoadField: r2 = r1->field_a3
    //     0x64f1e8: ldur            w2, [x1, #0xa3]
    // 0x64f1ec: DecompressPointer r2
    //     0x64f1ec: add             x2, x2, HEAP, lsl #32
    // 0x64f1f0: cmp             w2, NULL
    // 0x64f1f4: b.eq            #0x64f22c
    // 0x64f1f8: r1 = 1
    //     0x64f1f8: mov             x1, #1
    // 0x64f1fc: r0 = AllocateContext()
    //     0x64f1fc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x64f200: mov             x1, x0
    // 0x64f204: ldr             x0, [fp, #0x18]
    // 0x64f208: StoreField: r1->field_f = r0
    //     0x64f208: stur            w0, [x1, #0xf]
    // 0x64f20c: mov             x2, x1
    // 0x64f210: r1 = Function '_performTap@907160605':.
    //     0x64f210: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b70] AnonymousClosure: (0x64ffb8), in [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsAnnotations::_performTap (0x650000)
    //     0x64f214: ldr             x1, [x1, #0xb70]
    // 0x64f218: r0 = AllocateClosure()
    //     0x64f218: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x64f21c: ldr             x16, [fp, #0x10]
    // 0x64f220: stp             x0, x16, [SP, #-0x10]!
    // 0x64f224: r0 = onTap=()
    //     0x64f224: bl              #0x646384  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onTap=
    // 0x64f228: add             SP, SP, #0x10
    // 0x64f22c: ldr             x0, [fp, #0x18]
    // 0x64f230: LoadField: r1 = r0->field_63
    //     0x64f230: ldur            w1, [x0, #0x63]
    // 0x64f234: DecompressPointer r1
    //     0x64f234: add             x1, x1, HEAP, lsl #32
    // 0x64f238: LoadField: r2 = r1->field_a7
    //     0x64f238: ldur            w2, [x1, #0xa7]
    // 0x64f23c: DecompressPointer r2
    //     0x64f23c: add             x2, x2, HEAP, lsl #32
    // 0x64f240: cmp             w2, NULL
    // 0x64f244: b.eq            #0x64f27c
    // 0x64f248: r1 = 1
    //     0x64f248: mov             x1, #1
    // 0x64f24c: r0 = AllocateContext()
    //     0x64f24c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x64f250: mov             x1, x0
    // 0x64f254: ldr             x0, [fp, #0x18]
    // 0x64f258: StoreField: r1->field_f = r0
    //     0x64f258: stur            w0, [x1, #0xf]
    // 0x64f25c: mov             x2, x1
    // 0x64f260: r1 = Function '_performLongPress@907160605':.
    //     0x64f260: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b78] AnonymousClosure: (0x64ff14), in [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsAnnotations::_performLongPress (0x64ff5c)
    //     0x64f264: ldr             x1, [x1, #0xb78]
    // 0x64f268: r0 = AllocateClosure()
    //     0x64f268: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x64f26c: ldr             x16, [fp, #0x10]
    // 0x64f270: stp             x0, x16, [SP, #-0x10]!
    // 0x64f274: r0 = onLongPress=()
    //     0x64f274: bl              #0x64e5f0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onLongPress=
    // 0x64f278: add             SP, SP, #0x10
    // 0x64f27c: ldr             x0, [fp, #0x18]
    // 0x64f280: LoadField: r1 = r0->field_63
    //     0x64f280: ldur            w1, [x0, #0x63]
    // 0x64f284: DecompressPointer r1
    //     0x64f284: add             x1, x1, HEAP, lsl #32
    // 0x64f288: LoadField: r2 = r1->field_ef
    //     0x64f288: ldur            w2, [x1, #0xef]
    // 0x64f28c: DecompressPointer r2
    //     0x64f28c: add             x2, x2, HEAP, lsl #32
    // 0x64f290: cmp             w2, NULL
    // 0x64f294: b.eq            #0x64f2cc
    // 0x64f298: r1 = 1
    //     0x64f298: mov             x1, #1
    // 0x64f29c: r0 = AllocateContext()
    //     0x64f29c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x64f2a0: mov             x1, x0
    // 0x64f2a4: ldr             x0, [fp, #0x18]
    // 0x64f2a8: StoreField: r1->field_f = r0
    //     0x64f2a8: stur            w0, [x1, #0xf]
    // 0x64f2ac: mov             x2, x1
    // 0x64f2b0: r1 = Function '_performDismiss@907160605':.
    //     0x64f2b0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b80] AnonymousClosure: (0x64fe70), in [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsAnnotations::_performDismiss (0x64feb8)
    //     0x64f2b4: ldr             x1, [x1, #0xb80]
    // 0x64f2b8: r0 = AllocateClosure()
    //     0x64f2b8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x64f2bc: ldr             x16, [fp, #0x10]
    // 0x64f2c0: stp             x0, x16, [SP, #-0x10]!
    // 0x64f2c4: r0 = onDismiss=()
    //     0x64f2c4: bl              #0x64f584  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onDismiss=
    // 0x64f2c8: add             SP, SP, #0x10
    // 0x64f2cc: ldr             x0, [fp, #0x18]
    // 0x64f2d0: LoadField: r1 = r0->field_63
    //     0x64f2d0: ldur            w1, [x0, #0x63]
    // 0x64f2d4: DecompressPointer r1
    //     0x64f2d4: add             x1, x1, HEAP, lsl #32
    // 0x64f2d8: LoadField: r2 = r1->field_c3
    //     0x64f2d8: ldur            w2, [x1, #0xc3]
    // 0x64f2dc: DecompressPointer r2
    //     0x64f2dc: add             x2, x2, HEAP, lsl #32
    // 0x64f2e0: cmp             w2, NULL
    // 0x64f2e4: b.eq            #0x64f31c
    // 0x64f2e8: r1 = 1
    //     0x64f2e8: mov             x1, #1
    // 0x64f2ec: r0 = AllocateContext()
    //     0x64f2ec: bl              #0xd68aa4  ; AllocateContextStub
    // 0x64f2f0: mov             x1, x0
    // 0x64f2f4: ldr             x0, [fp, #0x18]
    // 0x64f2f8: StoreField: r1->field_f = r0
    //     0x64f2f8: stur            w0, [x1, #0xf]
    // 0x64f2fc: mov             x2, x1
    // 0x64f300: r1 = Function '_performCopy@907160605':.
    //     0x64f300: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b88] AnonymousClosure: (0x64fdcc), in [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsAnnotations::_performCopy (0x64fe14)
    //     0x64f304: ldr             x1, [x1, #0xb88]
    // 0x64f308: r0 = AllocateClosure()
    //     0x64f308: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x64f30c: ldr             x16, [fp, #0x10]
    // 0x64f310: stp             x0, x16, [SP, #-0x10]!
    // 0x64f314: r0 = onCopy=()
    //     0x64f314: bl              #0x64f52c  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onCopy=
    // 0x64f318: add             SP, SP, #0x10
    // 0x64f31c: ldr             x0, [fp, #0x18]
    // 0x64f320: LoadField: r1 = r0->field_63
    //     0x64f320: ldur            w1, [x0, #0x63]
    // 0x64f324: DecompressPointer r1
    //     0x64f324: add             x1, x1, HEAP, lsl #32
    // 0x64f328: LoadField: r2 = r1->field_c7
    //     0x64f328: ldur            w2, [x1, #0xc7]
    // 0x64f32c: DecompressPointer r2
    //     0x64f32c: add             x2, x2, HEAP, lsl #32
    // 0x64f330: cmp             w2, NULL
    // 0x64f334: b.eq            #0x64f36c
    // 0x64f338: r1 = 1
    //     0x64f338: mov             x1, #1
    // 0x64f33c: r0 = AllocateContext()
    //     0x64f33c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x64f340: mov             x1, x0
    // 0x64f344: ldr             x0, [fp, #0x18]
    // 0x64f348: StoreField: r1->field_f = r0
    //     0x64f348: stur            w0, [x1, #0xf]
    // 0x64f34c: mov             x2, x1
    // 0x64f350: r1 = Function '_performCut@907160605':.
    //     0x64f350: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b90] AnonymousClosure: (0x64fd28), in [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsAnnotations::_performCut (0x64fd70)
    //     0x64f354: ldr             x1, [x1, #0xb90]
    // 0x64f358: r0 = AllocateClosure()
    //     0x64f358: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x64f35c: ldr             x16, [fp, #0x10]
    // 0x64f360: stp             x0, x16, [SP, #-0x10]!
    // 0x64f364: r0 = onCut=()
    //     0x64f364: bl              #0x64f4d4  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onCut=
    // 0x64f368: add             SP, SP, #0x10
    // 0x64f36c: ldr             x0, [fp, #0x18]
    // 0x64f370: LoadField: r1 = r0->field_63
    //     0x64f370: ldur            w1, [x0, #0x63]
    // 0x64f374: DecompressPointer r1
    //     0x64f374: add             x1, x1, HEAP, lsl #32
    // 0x64f378: LoadField: r2 = r1->field_cb
    //     0x64f378: ldur            w2, [x1, #0xcb]
    // 0x64f37c: DecompressPointer r2
    //     0x64f37c: add             x2, x2, HEAP, lsl #32
    // 0x64f380: cmp             w2, NULL
    // 0x64f384: b.eq            #0x64f3bc
    // 0x64f388: r1 = 1
    //     0x64f388: mov             x1, #1
    // 0x64f38c: r0 = AllocateContext()
    //     0x64f38c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x64f390: mov             x1, x0
    // 0x64f394: ldr             x0, [fp, #0x18]
    // 0x64f398: StoreField: r1->field_f = r0
    //     0x64f398: stur            w0, [x1, #0xf]
    // 0x64f39c: mov             x2, x1
    // 0x64f3a0: r1 = Function '_performPaste@907160605':.
    //     0x64f3a0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b98] AnonymousClosure: (0x64fc84), in [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsAnnotations::_performPaste (0x64fccc)
    //     0x64f3a4: ldr             x1, [x1, #0xb98]
    // 0x64f3a8: r0 = AllocateClosure()
    //     0x64f3a8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x64f3ac: ldr             x16, [fp, #0x10]
    // 0x64f3b0: stp             x0, x16, [SP, #-0x10]!
    // 0x64f3b4: r0 = onPaste=()
    //     0x64f3b4: bl              #0x64f47c  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onPaste=
    // 0x64f3b8: add             SP, SP, #0x10
    // 0x64f3bc: ldr             x0, [fp, #0x18]
    // 0x64f3c0: LoadField: r1 = r0->field_63
    //     0x64f3c0: ldur            w1, [x0, #0x63]
    // 0x64f3c4: DecompressPointer r1
    //     0x64f3c4: add             x1, x1, HEAP, lsl #32
    // 0x64f3c8: LoadField: r2 = r1->field_e7
    //     0x64f3c8: ldur            w2, [x1, #0xe7]
    // 0x64f3cc: DecompressPointer r2
    //     0x64f3cc: add             x2, x2, HEAP, lsl #32
    // 0x64f3d0: cmp             w2, NULL
    // 0x64f3d4: b.eq            #0x64f40c
    // 0x64f3d8: r1 = 1
    //     0x64f3d8: mov             x1, #1
    // 0x64f3dc: r0 = AllocateContext()
    //     0x64f3dc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x64f3e0: mov             x1, x0
    // 0x64f3e4: ldr             x0, [fp, #0x18]
    // 0x64f3e8: StoreField: r1->field_f = r0
    //     0x64f3e8: stur            w0, [x1, #0xf]
    // 0x64f3ec: mov             x2, x1
    // 0x64f3f0: r1 = Function '_performDidGainAccessibilityFocus@907160605':.
    //     0x64f3f0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21ba0] AnonymousClosure: (0x64fbe0), in [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsAnnotations::_performDidGainAccessibilityFocus (0x64fc28)
    //     0x64f3f4: ldr             x1, [x1, #0xba0]
    // 0x64f3f8: r0 = AllocateClosure()
    //     0x64f3f8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x64f3fc: ldr             x16, [fp, #0x10]
    // 0x64f400: stp             x0, x16, [SP, #-0x10]!
    // 0x64f404: r0 = onDidGainAccessibilityFocus=()
    //     0x64f404: bl              #0x64f424  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onDidGainAccessibilityFocus=
    // 0x64f408: add             SP, SP, #0x10
    // 0x64f40c: r0 = Null
    //     0x64f40c: mov             x0, NULL
    // 0x64f410: LeaveFrame
    //     0x64f410: mov             SP, fp
    //     0x64f414: ldp             fp, lr, [SP], #0x10
    // 0x64f418: ret
    //     0x64f418: ret             
    // 0x64f41c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64f41c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64f420: b               #0x64ed84
  }
  [closure] void _performDidGainAccessibilityFocus(dynamic) {
    // ** addr: 0x64fbe0, size: 0x48
    // 0x64fbe0: EnterFrame
    //     0x64fbe0: stp             fp, lr, [SP, #-0x10]!
    //     0x64fbe4: mov             fp, SP
    // 0x64fbe8: ldr             x0, [fp, #0x10]
    // 0x64fbec: LoadField: r1 = r0->field_17
    //     0x64fbec: ldur            w1, [x0, #0x17]
    // 0x64fbf0: DecompressPointer r1
    //     0x64fbf0: add             x1, x1, HEAP, lsl #32
    // 0x64fbf4: CheckStackOverflow
    //     0x64fbf4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64fbf8: cmp             SP, x16
    //     0x64fbfc: b.ls            #0x64fc20
    // 0x64fc00: LoadField: r0 = r1->field_f
    //     0x64fc00: ldur            w0, [x1, #0xf]
    // 0x64fc04: DecompressPointer r0
    //     0x64fc04: add             x0, x0, HEAP, lsl #32
    // 0x64fc08: SaveReg r0
    //     0x64fc08: str             x0, [SP, #-8]!
    // 0x64fc0c: r0 = _performDidGainAccessibilityFocus()
    //     0x64fc0c: bl              #0x64fc28  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsAnnotations::_performDidGainAccessibilityFocus
    // 0x64fc10: add             SP, SP, #8
    // 0x64fc14: LeaveFrame
    //     0x64fc14: mov             SP, fp
    //     0x64fc18: ldp             fp, lr, [SP], #0x10
    // 0x64fc1c: ret
    //     0x64fc1c: ret             
    // 0x64fc20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64fc20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64fc24: b               #0x64fc00
  }
  _ _performDidGainAccessibilityFocus(/* No info */) {
    // ** addr: 0x64fc28, size: 0x5c
    // 0x64fc28: EnterFrame
    //     0x64fc28: stp             fp, lr, [SP, #-0x10]!
    //     0x64fc2c: mov             fp, SP
    // 0x64fc30: CheckStackOverflow
    //     0x64fc30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64fc34: cmp             SP, x16
    //     0x64fc38: b.ls            #0x64fc7c
    // 0x64fc3c: ldr             x0, [fp, #0x10]
    // 0x64fc40: LoadField: r1 = r0->field_63
    //     0x64fc40: ldur            w1, [x0, #0x63]
    // 0x64fc44: DecompressPointer r1
    //     0x64fc44: add             x1, x1, HEAP, lsl #32
    // 0x64fc48: LoadField: r0 = r1->field_e7
    //     0x64fc48: ldur            w0, [x1, #0xe7]
    // 0x64fc4c: DecompressPointer r0
    //     0x64fc4c: add             x0, x0, HEAP, lsl #32
    // 0x64fc50: cmp             w0, NULL
    // 0x64fc54: b.eq            #0x64fc6c
    // 0x64fc58: SaveReg r0
    //     0x64fc58: str             x0, [SP, #-8]!
    // 0x64fc5c: ClosureCall
    //     0x64fc5c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x64fc60: ldur            x2, [x0, #0x1f]
    //     0x64fc64: blr             x2
    // 0x64fc68: add             SP, SP, #8
    // 0x64fc6c: r0 = Null
    //     0x64fc6c: mov             x0, NULL
    // 0x64fc70: LeaveFrame
    //     0x64fc70: mov             SP, fp
    //     0x64fc74: ldp             fp, lr, [SP], #0x10
    // 0x64fc78: ret
    //     0x64fc78: ret             
    // 0x64fc7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64fc7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64fc80: b               #0x64fc3c
  }
  [closure] void _performPaste(dynamic) {
    // ** addr: 0x64fc84, size: 0x48
    // 0x64fc84: EnterFrame
    //     0x64fc84: stp             fp, lr, [SP, #-0x10]!
    //     0x64fc88: mov             fp, SP
    // 0x64fc8c: ldr             x0, [fp, #0x10]
    // 0x64fc90: LoadField: r1 = r0->field_17
    //     0x64fc90: ldur            w1, [x0, #0x17]
    // 0x64fc94: DecompressPointer r1
    //     0x64fc94: add             x1, x1, HEAP, lsl #32
    // 0x64fc98: CheckStackOverflow
    //     0x64fc98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64fc9c: cmp             SP, x16
    //     0x64fca0: b.ls            #0x64fcc4
    // 0x64fca4: LoadField: r0 = r1->field_f
    //     0x64fca4: ldur            w0, [x1, #0xf]
    // 0x64fca8: DecompressPointer r0
    //     0x64fca8: add             x0, x0, HEAP, lsl #32
    // 0x64fcac: SaveReg r0
    //     0x64fcac: str             x0, [SP, #-8]!
    // 0x64fcb0: r0 = _performPaste()
    //     0x64fcb0: bl              #0x64fccc  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsAnnotations::_performPaste
    // 0x64fcb4: add             SP, SP, #8
    // 0x64fcb8: LeaveFrame
    //     0x64fcb8: mov             SP, fp
    //     0x64fcbc: ldp             fp, lr, [SP], #0x10
    // 0x64fcc0: ret
    //     0x64fcc0: ret             
    // 0x64fcc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64fcc4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64fcc8: b               #0x64fca4
  }
  _ _performPaste(/* No info */) {
    // ** addr: 0x64fccc, size: 0x5c
    // 0x64fccc: EnterFrame
    //     0x64fccc: stp             fp, lr, [SP, #-0x10]!
    //     0x64fcd0: mov             fp, SP
    // 0x64fcd4: CheckStackOverflow
    //     0x64fcd4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64fcd8: cmp             SP, x16
    //     0x64fcdc: b.ls            #0x64fd20
    // 0x64fce0: ldr             x0, [fp, #0x10]
    // 0x64fce4: LoadField: r1 = r0->field_63
    //     0x64fce4: ldur            w1, [x0, #0x63]
    // 0x64fce8: DecompressPointer r1
    //     0x64fce8: add             x1, x1, HEAP, lsl #32
    // 0x64fcec: LoadField: r0 = r1->field_cb
    //     0x64fcec: ldur            w0, [x1, #0xcb]
    // 0x64fcf0: DecompressPointer r0
    //     0x64fcf0: add             x0, x0, HEAP, lsl #32
    // 0x64fcf4: cmp             w0, NULL
    // 0x64fcf8: b.eq            #0x64fd10
    // 0x64fcfc: SaveReg r0
    //     0x64fcfc: str             x0, [SP, #-8]!
    // 0x64fd00: ClosureCall
    //     0x64fd00: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x64fd04: ldur            x2, [x0, #0x1f]
    //     0x64fd08: blr             x2
    // 0x64fd0c: add             SP, SP, #8
    // 0x64fd10: r0 = Null
    //     0x64fd10: mov             x0, NULL
    // 0x64fd14: LeaveFrame
    //     0x64fd14: mov             SP, fp
    //     0x64fd18: ldp             fp, lr, [SP], #0x10
    // 0x64fd1c: ret
    //     0x64fd1c: ret             
    // 0x64fd20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64fd20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64fd24: b               #0x64fce0
  }
  [closure] void _performCut(dynamic) {
    // ** addr: 0x64fd28, size: 0x48
    // 0x64fd28: EnterFrame
    //     0x64fd28: stp             fp, lr, [SP, #-0x10]!
    //     0x64fd2c: mov             fp, SP
    // 0x64fd30: ldr             x0, [fp, #0x10]
    // 0x64fd34: LoadField: r1 = r0->field_17
    //     0x64fd34: ldur            w1, [x0, #0x17]
    // 0x64fd38: DecompressPointer r1
    //     0x64fd38: add             x1, x1, HEAP, lsl #32
    // 0x64fd3c: CheckStackOverflow
    //     0x64fd3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64fd40: cmp             SP, x16
    //     0x64fd44: b.ls            #0x64fd68
    // 0x64fd48: LoadField: r0 = r1->field_f
    //     0x64fd48: ldur            w0, [x1, #0xf]
    // 0x64fd4c: DecompressPointer r0
    //     0x64fd4c: add             x0, x0, HEAP, lsl #32
    // 0x64fd50: SaveReg r0
    //     0x64fd50: str             x0, [SP, #-8]!
    // 0x64fd54: r0 = _performCut()
    //     0x64fd54: bl              #0x64fd70  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsAnnotations::_performCut
    // 0x64fd58: add             SP, SP, #8
    // 0x64fd5c: LeaveFrame
    //     0x64fd5c: mov             SP, fp
    //     0x64fd60: ldp             fp, lr, [SP], #0x10
    // 0x64fd64: ret
    //     0x64fd64: ret             
    // 0x64fd68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64fd68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64fd6c: b               #0x64fd48
  }
  _ _performCut(/* No info */) {
    // ** addr: 0x64fd70, size: 0x5c
    // 0x64fd70: EnterFrame
    //     0x64fd70: stp             fp, lr, [SP, #-0x10]!
    //     0x64fd74: mov             fp, SP
    // 0x64fd78: CheckStackOverflow
    //     0x64fd78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64fd7c: cmp             SP, x16
    //     0x64fd80: b.ls            #0x64fdc4
    // 0x64fd84: ldr             x0, [fp, #0x10]
    // 0x64fd88: LoadField: r1 = r0->field_63
    //     0x64fd88: ldur            w1, [x0, #0x63]
    // 0x64fd8c: DecompressPointer r1
    //     0x64fd8c: add             x1, x1, HEAP, lsl #32
    // 0x64fd90: LoadField: r0 = r1->field_c7
    //     0x64fd90: ldur            w0, [x1, #0xc7]
    // 0x64fd94: DecompressPointer r0
    //     0x64fd94: add             x0, x0, HEAP, lsl #32
    // 0x64fd98: cmp             w0, NULL
    // 0x64fd9c: b.eq            #0x64fdb4
    // 0x64fda0: SaveReg r0
    //     0x64fda0: str             x0, [SP, #-8]!
    // 0x64fda4: ClosureCall
    //     0x64fda4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x64fda8: ldur            x2, [x0, #0x1f]
    //     0x64fdac: blr             x2
    // 0x64fdb0: add             SP, SP, #8
    // 0x64fdb4: r0 = Null
    //     0x64fdb4: mov             x0, NULL
    // 0x64fdb8: LeaveFrame
    //     0x64fdb8: mov             SP, fp
    //     0x64fdbc: ldp             fp, lr, [SP], #0x10
    // 0x64fdc0: ret
    //     0x64fdc0: ret             
    // 0x64fdc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64fdc4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64fdc8: b               #0x64fd84
  }
  [closure] void _performCopy(dynamic) {
    // ** addr: 0x64fdcc, size: 0x48
    // 0x64fdcc: EnterFrame
    //     0x64fdcc: stp             fp, lr, [SP, #-0x10]!
    //     0x64fdd0: mov             fp, SP
    // 0x64fdd4: ldr             x0, [fp, #0x10]
    // 0x64fdd8: LoadField: r1 = r0->field_17
    //     0x64fdd8: ldur            w1, [x0, #0x17]
    // 0x64fddc: DecompressPointer r1
    //     0x64fddc: add             x1, x1, HEAP, lsl #32
    // 0x64fde0: CheckStackOverflow
    //     0x64fde0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64fde4: cmp             SP, x16
    //     0x64fde8: b.ls            #0x64fe0c
    // 0x64fdec: LoadField: r0 = r1->field_f
    //     0x64fdec: ldur            w0, [x1, #0xf]
    // 0x64fdf0: DecompressPointer r0
    //     0x64fdf0: add             x0, x0, HEAP, lsl #32
    // 0x64fdf4: SaveReg r0
    //     0x64fdf4: str             x0, [SP, #-8]!
    // 0x64fdf8: r0 = _performCopy()
    //     0x64fdf8: bl              #0x64fe14  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsAnnotations::_performCopy
    // 0x64fdfc: add             SP, SP, #8
    // 0x64fe00: LeaveFrame
    //     0x64fe00: mov             SP, fp
    //     0x64fe04: ldp             fp, lr, [SP], #0x10
    // 0x64fe08: ret
    //     0x64fe08: ret             
    // 0x64fe0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64fe0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64fe10: b               #0x64fdec
  }
  _ _performCopy(/* No info */) {
    // ** addr: 0x64fe14, size: 0x5c
    // 0x64fe14: EnterFrame
    //     0x64fe14: stp             fp, lr, [SP, #-0x10]!
    //     0x64fe18: mov             fp, SP
    // 0x64fe1c: CheckStackOverflow
    //     0x64fe1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64fe20: cmp             SP, x16
    //     0x64fe24: b.ls            #0x64fe68
    // 0x64fe28: ldr             x0, [fp, #0x10]
    // 0x64fe2c: LoadField: r1 = r0->field_63
    //     0x64fe2c: ldur            w1, [x0, #0x63]
    // 0x64fe30: DecompressPointer r1
    //     0x64fe30: add             x1, x1, HEAP, lsl #32
    // 0x64fe34: LoadField: r0 = r1->field_c3
    //     0x64fe34: ldur            w0, [x1, #0xc3]
    // 0x64fe38: DecompressPointer r0
    //     0x64fe38: add             x0, x0, HEAP, lsl #32
    // 0x64fe3c: cmp             w0, NULL
    // 0x64fe40: b.eq            #0x64fe58
    // 0x64fe44: SaveReg r0
    //     0x64fe44: str             x0, [SP, #-8]!
    // 0x64fe48: ClosureCall
    //     0x64fe48: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x64fe4c: ldur            x2, [x0, #0x1f]
    //     0x64fe50: blr             x2
    // 0x64fe54: add             SP, SP, #8
    // 0x64fe58: r0 = Null
    //     0x64fe58: mov             x0, NULL
    // 0x64fe5c: LeaveFrame
    //     0x64fe5c: mov             SP, fp
    //     0x64fe60: ldp             fp, lr, [SP], #0x10
    // 0x64fe64: ret
    //     0x64fe64: ret             
    // 0x64fe68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64fe68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64fe6c: b               #0x64fe28
  }
  [closure] void _performDismiss(dynamic) {
    // ** addr: 0x64fe70, size: 0x48
    // 0x64fe70: EnterFrame
    //     0x64fe70: stp             fp, lr, [SP, #-0x10]!
    //     0x64fe74: mov             fp, SP
    // 0x64fe78: ldr             x0, [fp, #0x10]
    // 0x64fe7c: LoadField: r1 = r0->field_17
    //     0x64fe7c: ldur            w1, [x0, #0x17]
    // 0x64fe80: DecompressPointer r1
    //     0x64fe80: add             x1, x1, HEAP, lsl #32
    // 0x64fe84: CheckStackOverflow
    //     0x64fe84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64fe88: cmp             SP, x16
    //     0x64fe8c: b.ls            #0x64feb0
    // 0x64fe90: LoadField: r0 = r1->field_f
    //     0x64fe90: ldur            w0, [x1, #0xf]
    // 0x64fe94: DecompressPointer r0
    //     0x64fe94: add             x0, x0, HEAP, lsl #32
    // 0x64fe98: SaveReg r0
    //     0x64fe98: str             x0, [SP, #-8]!
    // 0x64fe9c: r0 = _performDismiss()
    //     0x64fe9c: bl              #0x64feb8  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsAnnotations::_performDismiss
    // 0x64fea0: add             SP, SP, #8
    // 0x64fea4: LeaveFrame
    //     0x64fea4: mov             SP, fp
    //     0x64fea8: ldp             fp, lr, [SP], #0x10
    // 0x64feac: ret
    //     0x64feac: ret             
    // 0x64feb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64feb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64feb4: b               #0x64fe90
  }
  _ _performDismiss(/* No info */) {
    // ** addr: 0x64feb8, size: 0x5c
    // 0x64feb8: EnterFrame
    //     0x64feb8: stp             fp, lr, [SP, #-0x10]!
    //     0x64febc: mov             fp, SP
    // 0x64fec0: CheckStackOverflow
    //     0x64fec0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64fec4: cmp             SP, x16
    //     0x64fec8: b.ls            #0x64ff0c
    // 0x64fecc: ldr             x0, [fp, #0x10]
    // 0x64fed0: LoadField: r1 = r0->field_63
    //     0x64fed0: ldur            w1, [x0, #0x63]
    // 0x64fed4: DecompressPointer r1
    //     0x64fed4: add             x1, x1, HEAP, lsl #32
    // 0x64fed8: LoadField: r0 = r1->field_ef
    //     0x64fed8: ldur            w0, [x1, #0xef]
    // 0x64fedc: DecompressPointer r0
    //     0x64fedc: add             x0, x0, HEAP, lsl #32
    // 0x64fee0: cmp             w0, NULL
    // 0x64fee4: b.eq            #0x64fefc
    // 0x64fee8: SaveReg r0
    //     0x64fee8: str             x0, [SP, #-8]!
    // 0x64feec: ClosureCall
    //     0x64feec: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x64fef0: ldur            x2, [x0, #0x1f]
    //     0x64fef4: blr             x2
    // 0x64fef8: add             SP, SP, #8
    // 0x64fefc: r0 = Null
    //     0x64fefc: mov             x0, NULL
    // 0x64ff00: LeaveFrame
    //     0x64ff00: mov             SP, fp
    //     0x64ff04: ldp             fp, lr, [SP], #0x10
    // 0x64ff08: ret
    //     0x64ff08: ret             
    // 0x64ff0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64ff0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64ff10: b               #0x64fecc
  }
  [closure] void _performLongPress(dynamic) {
    // ** addr: 0x64ff14, size: 0x48
    // 0x64ff14: EnterFrame
    //     0x64ff14: stp             fp, lr, [SP, #-0x10]!
    //     0x64ff18: mov             fp, SP
    // 0x64ff1c: ldr             x0, [fp, #0x10]
    // 0x64ff20: LoadField: r1 = r0->field_17
    //     0x64ff20: ldur            w1, [x0, #0x17]
    // 0x64ff24: DecompressPointer r1
    //     0x64ff24: add             x1, x1, HEAP, lsl #32
    // 0x64ff28: CheckStackOverflow
    //     0x64ff28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64ff2c: cmp             SP, x16
    //     0x64ff30: b.ls            #0x64ff54
    // 0x64ff34: LoadField: r0 = r1->field_f
    //     0x64ff34: ldur            w0, [x1, #0xf]
    // 0x64ff38: DecompressPointer r0
    //     0x64ff38: add             x0, x0, HEAP, lsl #32
    // 0x64ff3c: SaveReg r0
    //     0x64ff3c: str             x0, [SP, #-8]!
    // 0x64ff40: r0 = _performLongPress()
    //     0x64ff40: bl              #0x64ff5c  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsAnnotations::_performLongPress
    // 0x64ff44: add             SP, SP, #8
    // 0x64ff48: LeaveFrame
    //     0x64ff48: mov             SP, fp
    //     0x64ff4c: ldp             fp, lr, [SP], #0x10
    // 0x64ff50: ret
    //     0x64ff50: ret             
    // 0x64ff54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64ff54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64ff58: b               #0x64ff34
  }
  _ _performLongPress(/* No info */) {
    // ** addr: 0x64ff5c, size: 0x5c
    // 0x64ff5c: EnterFrame
    //     0x64ff5c: stp             fp, lr, [SP, #-0x10]!
    //     0x64ff60: mov             fp, SP
    // 0x64ff64: CheckStackOverflow
    //     0x64ff64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64ff68: cmp             SP, x16
    //     0x64ff6c: b.ls            #0x64ffb0
    // 0x64ff70: ldr             x0, [fp, #0x10]
    // 0x64ff74: LoadField: r1 = r0->field_63
    //     0x64ff74: ldur            w1, [x0, #0x63]
    // 0x64ff78: DecompressPointer r1
    //     0x64ff78: add             x1, x1, HEAP, lsl #32
    // 0x64ff7c: LoadField: r0 = r1->field_a7
    //     0x64ff7c: ldur            w0, [x1, #0xa7]
    // 0x64ff80: DecompressPointer r0
    //     0x64ff80: add             x0, x0, HEAP, lsl #32
    // 0x64ff84: cmp             w0, NULL
    // 0x64ff88: b.eq            #0x64ffa0
    // 0x64ff8c: SaveReg r0
    //     0x64ff8c: str             x0, [SP, #-8]!
    // 0x64ff90: ClosureCall
    //     0x64ff90: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x64ff94: ldur            x2, [x0, #0x1f]
    //     0x64ff98: blr             x2
    // 0x64ff9c: add             SP, SP, #8
    // 0x64ffa0: r0 = Null
    //     0x64ffa0: mov             x0, NULL
    // 0x64ffa4: LeaveFrame
    //     0x64ffa4: mov             SP, fp
    //     0x64ffa8: ldp             fp, lr, [SP], #0x10
    // 0x64ffac: ret
    //     0x64ffac: ret             
    // 0x64ffb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64ffb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64ffb4: b               #0x64ff70
  }
  [closure] void _performTap(dynamic) {
    // ** addr: 0x64ffb8, size: 0x48
    // 0x64ffb8: EnterFrame
    //     0x64ffb8: stp             fp, lr, [SP, #-0x10]!
    //     0x64ffbc: mov             fp, SP
    // 0x64ffc0: ldr             x0, [fp, #0x10]
    // 0x64ffc4: LoadField: r1 = r0->field_17
    //     0x64ffc4: ldur            w1, [x0, #0x17]
    // 0x64ffc8: DecompressPointer r1
    //     0x64ffc8: add             x1, x1, HEAP, lsl #32
    // 0x64ffcc: CheckStackOverflow
    //     0x64ffcc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64ffd0: cmp             SP, x16
    //     0x64ffd4: b.ls            #0x64fff8
    // 0x64ffd8: LoadField: r0 = r1->field_f
    //     0x64ffd8: ldur            w0, [x1, #0xf]
    // 0x64ffdc: DecompressPointer r0
    //     0x64ffdc: add             x0, x0, HEAP, lsl #32
    // 0x64ffe0: SaveReg r0
    //     0x64ffe0: str             x0, [SP, #-8]!
    // 0x64ffe4: r0 = _performTap()
    //     0x64ffe4: bl              #0x650000  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsAnnotations::_performTap
    // 0x64ffe8: add             SP, SP, #8
    // 0x64ffec: LeaveFrame
    //     0x64ffec: mov             SP, fp
    //     0x64fff0: ldp             fp, lr, [SP], #0x10
    // 0x64fff4: ret
    //     0x64fff4: ret             
    // 0x64fff8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64fff8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64fffc: b               #0x64ffd8
  }
  _ _performTap(/* No info */) {
    // ** addr: 0x650000, size: 0x5c
    // 0x650000: EnterFrame
    //     0x650000: stp             fp, lr, [SP, #-0x10]!
    //     0x650004: mov             fp, SP
    // 0x650008: CheckStackOverflow
    //     0x650008: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65000c: cmp             SP, x16
    //     0x650010: b.ls            #0x650054
    // 0x650014: ldr             x0, [fp, #0x10]
    // 0x650018: LoadField: r1 = r0->field_63
    //     0x650018: ldur            w1, [x0, #0x63]
    // 0x65001c: DecompressPointer r1
    //     0x65001c: add             x1, x1, HEAP, lsl #32
    // 0x650020: LoadField: r0 = r1->field_a3
    //     0x650020: ldur            w0, [x1, #0xa3]
    // 0x650024: DecompressPointer r0
    //     0x650024: add             x0, x0, HEAP, lsl #32
    // 0x650028: cmp             w0, NULL
    // 0x65002c: b.eq            #0x650044
    // 0x650030: SaveReg r0
    //     0x650030: str             x0, [SP, #-8]!
    // 0x650034: ClosureCall
    //     0x650034: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x650038: ldur            x2, [x0, #0x1f]
    //     0x65003c: blr             x2
    // 0x650040: add             SP, SP, #8
    // 0x650044: r0 = Null
    //     0x650044: mov             x0, NULL
    // 0x650048: LeaveFrame
    //     0x650048: mov             SP, fp
    //     0x65004c: ldp             fp, lr, [SP], #0x10
    // 0x650050: ret
    //     0x650050: ret             
    // 0x650054: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x650054: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x650058: b               #0x650014
  }
  _ visitChildrenForSemantics(/* No info */) {
    // ** addr: 0x675e28, size: 0x5c
    // 0x675e28: EnterFrame
    //     0x675e28: stp             fp, lr, [SP, #-0x10]!
    //     0x675e2c: mov             fp, SP
    // 0x675e30: CheckStackOverflow
    //     0x675e30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x675e34: cmp             SP, x16
    //     0x675e38: b.ls            #0x675e7c
    // 0x675e3c: ldr             x0, [fp, #0x18]
    // 0x675e40: LoadField: r1 = r0->field_6f
    //     0x675e40: ldur            w1, [x0, #0x6f]
    // 0x675e44: DecompressPointer r1
    //     0x675e44: add             x1, x1, HEAP, lsl #32
    // 0x675e48: tbnz            w1, #4, #0x675e5c
    // 0x675e4c: r0 = Null
    //     0x675e4c: mov             x0, NULL
    // 0x675e50: LeaveFrame
    //     0x675e50: mov             SP, fp
    //     0x675e54: ldp             fp, lr, [SP], #0x10
    // 0x675e58: ret
    //     0x675e58: ret             
    // 0x675e5c: ldr             x16, [fp, #0x10]
    // 0x675e60: stp             x16, x0, [SP, #-0x10]!
    // 0x675e64: r0 = visitChildren()
    //     0x675e64: bl              #0x6bf90c  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::visitChildren
    // 0x675e68: add             SP, SP, #0x10
    // 0x675e6c: r0 = Null
    //     0x675e6c: mov             x0, NULL
    // 0x675e70: LeaveFrame
    //     0x675e70: mov             SP, fp
    //     0x675e74: ldp             fp, lr, [SP], #0x10
    // 0x675e78: ret
    //     0x675e78: ret             
    // 0x675e7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x675e7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x675e80: b               #0x675e3c
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0x6c6e50, size: 0x80
    // 0x6c6e50: EnterFrame
    //     0x6c6e50: stp             fp, lr, [SP, #-0x10]!
    //     0x6c6e54: mov             fp, SP
    // 0x6c6e58: CheckStackOverflow
    //     0x6c6e58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c6e5c: cmp             SP, x16
    //     0x6c6e60: b.ls            #0x6c6ec8
    // 0x6c6e64: ldr             x1, [fp, #0x18]
    // 0x6c6e68: LoadField: r0 = r1->field_87
    //     0x6c6e68: ldur            w0, [x1, #0x87]
    // 0x6c6e6c: DecompressPointer r0
    //     0x6c6e6c: add             x0, x0, HEAP, lsl #32
    // 0x6c6e70: ldr             x2, [fp, #0x10]
    // 0x6c6e74: cmp             w0, w2
    // 0x6c6e78: b.ne            #0x6c6e8c
    // 0x6c6e7c: r0 = Null
    //     0x6c6e7c: mov             x0, NULL
    // 0x6c6e80: LeaveFrame
    //     0x6c6e80: mov             SP, fp
    //     0x6c6e84: ldp             fp, lr, [SP], #0x10
    // 0x6c6e88: ret
    //     0x6c6e88: ret             
    // 0x6c6e8c: mov             x0, x2
    // 0x6c6e90: StoreField: r1->field_87 = r0
    //     0x6c6e90: stur            w0, [x1, #0x87]
    //     0x6c6e94: ldurb           w16, [x1, #-1]
    //     0x6c6e98: ldurb           w17, [x0, #-1]
    //     0x6c6e9c: and             x16, x17, x16, lsr #2
    //     0x6c6ea0: tst             x16, HEAP, lsr #32
    //     0x6c6ea4: b.eq            #0x6c6eac
    //     0x6c6ea8: bl              #0xd6826c
    // 0x6c6eac: SaveReg r1
    //     0x6c6eac: str             x1, [SP, #-8]!
    // 0x6c6eb0: r0 = markNeedsSemanticsUpdate()
    //     0x6c6eb0: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6c6eb4: add             SP, SP, #8
    // 0x6c6eb8: r0 = Null
    //     0x6c6eb8: mov             x0, NULL
    // 0x6c6ebc: LeaveFrame
    //     0x6c6ebc: mov             SP, fp
    //     0x6c6ec0: ldp             fp, lr, [SP], #0x10
    // 0x6c6ec4: ret
    //     0x6c6ec4: ret             
    // 0x6c6ec8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6ec8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c6ecc: b               #0x6c6e64
  }
  set _ properties=(/* No info */) {
    // ** addr: 0x6c6f80, size: 0x90
    // 0x6c6f80: EnterFrame
    //     0x6c6f80: stp             fp, lr, [SP, #-0x10]!
    //     0x6c6f84: mov             fp, SP
    // 0x6c6f88: CheckStackOverflow
    //     0x6c6f88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c6f8c: cmp             SP, x16
    //     0x6c6f90: b.ls            #0x6c7008
    // 0x6c6f94: ldr             x1, [fp, #0x18]
    // 0x6c6f98: LoadField: r0 = r1->field_63
    //     0x6c6f98: ldur            w0, [x1, #0x63]
    // 0x6c6f9c: DecompressPointer r0
    //     0x6c6f9c: add             x0, x0, HEAP, lsl #32
    // 0x6c6fa0: ldr             x2, [fp, #0x10]
    // 0x6c6fa4: cmp             w0, w2
    // 0x6c6fa8: b.ne            #0x6c6fbc
    // 0x6c6fac: r0 = Null
    //     0x6c6fac: mov             x0, NULL
    // 0x6c6fb0: LeaveFrame
    //     0x6c6fb0: mov             SP, fp
    //     0x6c6fb4: ldp             fp, lr, [SP], #0x10
    // 0x6c6fb8: ret
    //     0x6c6fb8: ret             
    // 0x6c6fbc: mov             x0, x2
    // 0x6c6fc0: StoreField: r1->field_63 = r0
    //     0x6c6fc0: stur            w0, [x1, #0x63]
    //     0x6c6fc4: ldurb           w16, [x1, #-1]
    //     0x6c6fc8: ldurb           w17, [x0, #-1]
    //     0x6c6fcc: and             x16, x17, x16, lsr #2
    //     0x6c6fd0: tst             x16, HEAP, lsr #32
    //     0x6c6fd4: b.eq            #0x6c6fdc
    //     0x6c6fd8: bl              #0xd6826c
    // 0x6c6fdc: stp             x2, x1, [SP, #-0x10]!
    // 0x6c6fe0: r0 = _updateAttributedFields()
    //     0x6c6fe0: bl              #0x6c7010  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsAnnotations::_updateAttributedFields
    // 0x6c6fe4: add             SP, SP, #0x10
    // 0x6c6fe8: ldr             x16, [fp, #0x18]
    // 0x6c6fec: SaveReg r16
    //     0x6c6fec: str             x16, [SP, #-8]!
    // 0x6c6ff0: r0 = markNeedsSemanticsUpdate()
    //     0x6c6ff0: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6c6ff4: add             SP, SP, #8
    // 0x6c6ff8: r0 = Null
    //     0x6c6ff8: mov             x0, NULL
    // 0x6c6ffc: LeaveFrame
    //     0x6c6ffc: mov             SP, fp
    //     0x6c7000: ldp             fp, lr, [SP], #0x10
    // 0x6c7004: ret
    //     0x6c7004: ret             
    // 0x6c7008: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c7008: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c700c: b               #0x6c6f94
  }
  _ _updateAttributedFields(/* No info */) {
    // ** addr: 0x6c7010, size: 0xc8
    // 0x6c7010: EnterFrame
    //     0x6c7010: stp             fp, lr, [SP, #-0x10]!
    //     0x6c7014: mov             fp, SP
    // 0x6c7018: CheckStackOverflow
    //     0x6c7018: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c701c: cmp             SP, x16
    //     0x6c7020: b.ls            #0x6c70d0
    // 0x6c7024: ldr             x16, [fp, #0x18]
    // 0x6c7028: ldr             lr, [fp, #0x10]
    // 0x6c702c: stp             lr, x16, [SP, #-0x10]!
    // 0x6c7030: r0 = _effectiveAttributedLabel()
    //     0x6c7030: bl              #0x6c7170  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsAnnotations::_effectiveAttributedLabel
    // 0x6c7034: add             SP, SP, #0x10
    // 0x6c7038: ldr             x1, [fp, #0x18]
    // 0x6c703c: StoreField: r1->field_73 = r0
    //     0x6c703c: stur            w0, [x1, #0x73]
    //     0x6c7040: ldurb           w16, [x1, #-1]
    //     0x6c7044: ldurb           w17, [x0, #-1]
    //     0x6c7048: and             x16, x17, x16, lsr #2
    //     0x6c704c: tst             x16, HEAP, lsr #32
    //     0x6c7050: b.eq            #0x6c7058
    //     0x6c7054: bl              #0xd6826c
    // 0x6c7058: ldr             x16, [fp, #0x10]
    // 0x6c705c: stp             x16, x1, [SP, #-0x10]!
    // 0x6c7060: r0 = _effectiveAttributedValue()
    //     0x6c7060: bl              #0x6c7124  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsAnnotations::_effectiveAttributedValue
    // 0x6c7064: add             SP, SP, #0x10
    // 0x6c7068: ldr             x1, [fp, #0x18]
    // 0x6c706c: StoreField: r1->field_77 = r0
    //     0x6c706c: stur            w0, [x1, #0x77]
    //     0x6c7070: ldurb           w16, [x1, #-1]
    //     0x6c7074: ldurb           w17, [x0, #-1]
    //     0x6c7078: and             x16, x17, x16, lsr #2
    //     0x6c707c: tst             x16, HEAP, lsr #32
    //     0x6c7080: b.eq            #0x6c7088
    //     0x6c7084: bl              #0xd6826c
    // 0x6c7088: StoreField: r1->field_7b = rNULL
    //     0x6c7088: stur            NULL, [x1, #0x7b]
    // 0x6c708c: StoreField: r1->field_7f = rNULL
    //     0x6c708c: stur            NULL, [x1, #0x7f]
    // 0x6c7090: ldr             x16, [fp, #0x10]
    // 0x6c7094: stp             x16, x1, [SP, #-0x10]!
    // 0x6c7098: r0 = _effectiveAttributedHint()
    //     0x6c7098: bl              #0x6c70d8  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsAnnotations::_effectiveAttributedHint
    // 0x6c709c: add             SP, SP, #0x10
    // 0x6c70a0: ldr             x1, [fp, #0x18]
    // 0x6c70a4: StoreField: r1->field_83 = r0
    //     0x6c70a4: stur            w0, [x1, #0x83]
    //     0x6c70a8: ldurb           w16, [x1, #-1]
    //     0x6c70ac: ldurb           w17, [x0, #-1]
    //     0x6c70b0: and             x16, x17, x16, lsr #2
    //     0x6c70b4: tst             x16, HEAP, lsr #32
    //     0x6c70b8: b.eq            #0x6c70c0
    //     0x6c70bc: bl              #0xd6826c
    // 0x6c70c0: r0 = Null
    //     0x6c70c0: mov             x0, NULL
    // 0x6c70c4: LeaveFrame
    //     0x6c70c4: mov             SP, fp
    //     0x6c70c8: ldp             fp, lr, [SP], #0x10
    // 0x6c70cc: ret
    //     0x6c70cc: ret             
    // 0x6c70d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c70d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c70d4: b               #0x6c7024
  }
  _ _effectiveAttributedHint(/* No info */) {
    // ** addr: 0x6c70d8, size: 0x4c
    // 0x6c70d8: EnterFrame
    //     0x6c70d8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c70dc: mov             fp, SP
    // 0x6c70e0: AllocStack(0x8)
    //     0x6c70e0: sub             SP, SP, #8
    // 0x6c70e4: ldr             x0, [fp, #0x10]
    // 0x6c70e8: LoadField: r1 = r0->field_87
    //     0x6c70e8: ldur            w1, [x0, #0x87]
    // 0x6c70ec: DecompressPointer r1
    //     0x6c70ec: add             x1, x1, HEAP, lsl #32
    // 0x6c70f0: stur            x1, [fp, #-8]
    // 0x6c70f4: cmp             w1, NULL
    // 0x6c70f8: b.ne            #0x6c7104
    // 0x6c70fc: r0 = Null
    //     0x6c70fc: mov             x0, NULL
    // 0x6c7100: b               #0x6c7118
    // 0x6c7104: r0 = AttributedString()
    //     0x6c7104: bl              #0x50ffbc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0x6c7108: ldur            x1, [fp, #-8]
    // 0x6c710c: StoreField: r0->field_7 = r1
    //     0x6c710c: stur            w1, [x0, #7]
    // 0x6c7110: r1 = const []
    //     0x6c7110: ldr             x1, [PP, #0x4888]  ; [pp+0x4888] List<StringAttribute>(0)
    // 0x6c7114: StoreField: r0->field_b = r1
    //     0x6c7114: stur            w1, [x0, #0xb]
    // 0x6c7118: LeaveFrame
    //     0x6c7118: mov             SP, fp
    //     0x6c711c: ldp             fp, lr, [SP], #0x10
    // 0x6c7120: ret
    //     0x6c7120: ret             
  }
  _ _effectiveAttributedValue(/* No info */) {
    // ** addr: 0x6c7124, size: 0x4c
    // 0x6c7124: EnterFrame
    //     0x6c7124: stp             fp, lr, [SP, #-0x10]!
    //     0x6c7128: mov             fp, SP
    // 0x6c712c: AllocStack(0x8)
    //     0x6c712c: sub             SP, SP, #8
    // 0x6c7130: ldr             x0, [fp, #0x10]
    // 0x6c7134: LoadField: r1 = r0->field_6f
    //     0x6c7134: ldur            w1, [x0, #0x6f]
    // 0x6c7138: DecompressPointer r1
    //     0x6c7138: add             x1, x1, HEAP, lsl #32
    // 0x6c713c: stur            x1, [fp, #-8]
    // 0x6c7140: cmp             w1, NULL
    // 0x6c7144: b.ne            #0x6c7150
    // 0x6c7148: r0 = Null
    //     0x6c7148: mov             x0, NULL
    // 0x6c714c: b               #0x6c7164
    // 0x6c7150: r0 = AttributedString()
    //     0x6c7150: bl              #0x50ffbc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0x6c7154: ldur            x1, [fp, #-8]
    // 0x6c7158: StoreField: r0->field_7 = r1
    //     0x6c7158: stur            w1, [x0, #7]
    // 0x6c715c: r1 = const []
    //     0x6c715c: ldr             x1, [PP, #0x4888]  ; [pp+0x4888] List<StringAttribute>(0)
    // 0x6c7160: StoreField: r0->field_b = r1
    //     0x6c7160: stur            w1, [x0, #0xb]
    // 0x6c7164: LeaveFrame
    //     0x6c7164: mov             SP, fp
    //     0x6c7168: ldp             fp, lr, [SP], #0x10
    // 0x6c716c: ret
    //     0x6c716c: ret             
  }
  _ _effectiveAttributedLabel(/* No info */) {
    // ** addr: 0x6c7170, size: 0x4c
    // 0x6c7170: EnterFrame
    //     0x6c7170: stp             fp, lr, [SP, #-0x10]!
    //     0x6c7174: mov             fp, SP
    // 0x6c7178: AllocStack(0x8)
    //     0x6c7178: sub             SP, SP, #8
    // 0x6c717c: ldr             x0, [fp, #0x10]
    // 0x6c7180: LoadField: r1 = r0->field_67
    //     0x6c7180: ldur            w1, [x0, #0x67]
    // 0x6c7184: DecompressPointer r1
    //     0x6c7184: add             x1, x1, HEAP, lsl #32
    // 0x6c7188: stur            x1, [fp, #-8]
    // 0x6c718c: cmp             w1, NULL
    // 0x6c7190: b.ne            #0x6c719c
    // 0x6c7194: r0 = Null
    //     0x6c7194: mov             x0, NULL
    // 0x6c7198: b               #0x6c71b0
    // 0x6c719c: r0 = AttributedString()
    //     0x6c719c: bl              #0x50ffbc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0x6c71a0: ldur            x1, [fp, #-8]
    // 0x6c71a4: StoreField: r0->field_7 = r1
    //     0x6c71a4: stur            w1, [x0, #7]
    // 0x6c71a8: r1 = const []
    //     0x6c71a8: ldr             x1, [PP, #0x4888]  ; [pp+0x4888] List<StringAttribute>(0)
    // 0x6c71ac: StoreField: r0->field_b = r1
    //     0x6c71ac: stur            w1, [x0, #0xb]
    // 0x6c71b0: LeaveFrame
    //     0x6c71b0: mov             SP, fp
    //     0x6c71b4: ldp             fp, lr, [SP], #0x10
    // 0x6c71b8: ret
    //     0x6c71b8: ret             
  }
  set _ excludeSemantics=(/* No info */) {
    // ** addr: 0x6c71bc, size: 0x64
    // 0x6c71bc: EnterFrame
    //     0x6c71bc: stp             fp, lr, [SP, #-0x10]!
    //     0x6c71c0: mov             fp, SP
    // 0x6c71c4: CheckStackOverflow
    //     0x6c71c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c71c8: cmp             SP, x16
    //     0x6c71cc: b.ls            #0x6c7218
    // 0x6c71d0: ldr             x0, [fp, #0x18]
    // 0x6c71d4: LoadField: r1 = r0->field_6f
    //     0x6c71d4: ldur            w1, [x0, #0x6f]
    // 0x6c71d8: DecompressPointer r1
    //     0x6c71d8: add             x1, x1, HEAP, lsl #32
    // 0x6c71dc: ldr             x2, [fp, #0x10]
    // 0x6c71e0: cmp             w1, w2
    // 0x6c71e4: b.ne            #0x6c71f8
    // 0x6c71e8: r0 = Null
    //     0x6c71e8: mov             x0, NULL
    // 0x6c71ec: LeaveFrame
    //     0x6c71ec: mov             SP, fp
    //     0x6c71f0: ldp             fp, lr, [SP], #0x10
    // 0x6c71f4: ret
    //     0x6c71f4: ret             
    // 0x6c71f8: StoreField: r0->field_6f = r2
    //     0x6c71f8: stur            w2, [x0, #0x6f]
    // 0x6c71fc: SaveReg r0
    //     0x6c71fc: str             x0, [SP, #-8]!
    // 0x6c7200: r0 = markNeedsSemanticsUpdate()
    //     0x6c7200: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6c7204: add             SP, SP, #8
    // 0x6c7208: r0 = Null
    //     0x6c7208: mov             x0, NULL
    // 0x6c720c: LeaveFrame
    //     0x6c720c: mov             SP, fp
    //     0x6c7210: ldp             fp, lr, [SP], #0x10
    // 0x6c7214: ret
    //     0x6c7214: ret             
    // 0x6c7218: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c7218: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c721c: b               #0x6c71d0
  }
  set _ explicitChildNodes=(/* No info */) {
    // ** addr: 0x6c7220, size: 0x64
    // 0x6c7220: EnterFrame
    //     0x6c7220: stp             fp, lr, [SP, #-0x10]!
    //     0x6c7224: mov             fp, SP
    // 0x6c7228: CheckStackOverflow
    //     0x6c7228: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c722c: cmp             SP, x16
    //     0x6c7230: b.ls            #0x6c727c
    // 0x6c7234: ldr             x0, [fp, #0x18]
    // 0x6c7238: LoadField: r1 = r0->field_6b
    //     0x6c7238: ldur            w1, [x0, #0x6b]
    // 0x6c723c: DecompressPointer r1
    //     0x6c723c: add             x1, x1, HEAP, lsl #32
    // 0x6c7240: ldr             x2, [fp, #0x10]
    // 0x6c7244: cmp             w1, w2
    // 0x6c7248: b.ne            #0x6c725c
    // 0x6c724c: r0 = Null
    //     0x6c724c: mov             x0, NULL
    // 0x6c7250: LeaveFrame
    //     0x6c7250: mov             SP, fp
    //     0x6c7254: ldp             fp, lr, [SP], #0x10
    // 0x6c7258: ret
    //     0x6c7258: ret             
    // 0x6c725c: StoreField: r0->field_6b = r2
    //     0x6c725c: stur            w2, [x0, #0x6b]
    // 0x6c7260: SaveReg r0
    //     0x6c7260: str             x0, [SP, #-8]!
    // 0x6c7264: r0 = markNeedsSemanticsUpdate()
    //     0x6c7264: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6c7268: add             SP, SP, #8
    // 0x6c726c: r0 = Null
    //     0x6c726c: mov             x0, NULL
    // 0x6c7270: LeaveFrame
    //     0x6c7270: mov             SP, fp
    //     0x6c7274: ldp             fp, lr, [SP], #0x10
    // 0x6c7278: ret
    //     0x6c7278: ret             
    // 0x6c727c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c727c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c7280: b               #0x6c7234
  }
  set _ container=(/* No info */) {
    // ** addr: 0x6c7284, size: 0x64
    // 0x6c7284: EnterFrame
    //     0x6c7284: stp             fp, lr, [SP, #-0x10]!
    //     0x6c7288: mov             fp, SP
    // 0x6c728c: CheckStackOverflow
    //     0x6c728c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c7290: cmp             SP, x16
    //     0x6c7294: b.ls            #0x6c72e0
    // 0x6c7298: ldr             x0, [fp, #0x18]
    // 0x6c729c: LoadField: r1 = r0->field_67
    //     0x6c729c: ldur            w1, [x0, #0x67]
    // 0x6c72a0: DecompressPointer r1
    //     0x6c72a0: add             x1, x1, HEAP, lsl #32
    // 0x6c72a4: ldr             x2, [fp, #0x10]
    // 0x6c72a8: cmp             w1, w2
    // 0x6c72ac: b.ne            #0x6c72c0
    // 0x6c72b0: r0 = Null
    //     0x6c72b0: mov             x0, NULL
    // 0x6c72b4: LeaveFrame
    //     0x6c72b4: mov             SP, fp
    //     0x6c72b8: ldp             fp, lr, [SP], #0x10
    // 0x6c72bc: ret
    //     0x6c72bc: ret             
    // 0x6c72c0: StoreField: r0->field_67 = r2
    //     0x6c72c0: stur            w2, [x0, #0x67]
    // 0x6c72c4: SaveReg r0
    //     0x6c72c4: str             x0, [SP, #-8]!
    // 0x6c72c8: r0 = markNeedsSemanticsUpdate()
    //     0x6c72c8: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6c72cc: add             SP, SP, #8
    // 0x6c72d0: r0 = Null
    //     0x6c72d0: mov             x0, NULL
    // 0x6c72d4: LeaveFrame
    //     0x6c72d4: mov             SP, fp
    //     0x6c72d8: ldp             fp, lr, [SP], #0x10
    // 0x6c72dc: ret
    //     0x6c72dc: ret             
    // 0x6c72e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c72e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c72e4: b               #0x6c7298
  }
  _ RenderSemanticsAnnotations(/* No info */) {
    // ** addr: 0x6ec8f8, size: 0xbc
    // 0x6ec8f8: EnterFrame
    //     0x6ec8f8: stp             fp, lr, [SP, #-0x10]!
    //     0x6ec8fc: mov             fp, SP
    // 0x6ec900: CheckStackOverflow
    //     0x6ec900: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ec904: cmp             SP, x16
    //     0x6ec908: b.ls            #0x6ec9ac
    // 0x6ec90c: ldr             x1, [fp, #0x38]
    // 0x6ec910: ldr             x0, [fp, #0x30]
    // 0x6ec914: StoreField: r1->field_67 = r0
    //     0x6ec914: stur            w0, [x1, #0x67]
    // 0x6ec918: ldr             x0, [fp, #0x20]
    // 0x6ec91c: StoreField: r1->field_6b = r0
    //     0x6ec91c: stur            w0, [x1, #0x6b]
    // 0x6ec920: ldr             x0, [fp, #0x28]
    // 0x6ec924: StoreField: r1->field_6f = r0
    //     0x6ec924: stur            w0, [x1, #0x6f]
    // 0x6ec928: ldr             x0, [fp, #0x10]
    // 0x6ec92c: StoreField: r1->field_87 = r0
    //     0x6ec92c: stur            w0, [x1, #0x87]
    //     0x6ec930: ldurb           w16, [x1, #-1]
    //     0x6ec934: ldurb           w17, [x0, #-1]
    //     0x6ec938: and             x16, x17, x16, lsr #2
    //     0x6ec93c: tst             x16, HEAP, lsr #32
    //     0x6ec940: b.eq            #0x6ec948
    //     0x6ec944: bl              #0xd6826c
    // 0x6ec948: ldr             x0, [fp, #0x18]
    // 0x6ec94c: StoreField: r1->field_63 = r0
    //     0x6ec94c: stur            w0, [x1, #0x63]
    //     0x6ec950: ldurb           w16, [x1, #-1]
    //     0x6ec954: ldurb           w17, [x0, #-1]
    //     0x6ec958: and             x16, x17, x16, lsr #2
    //     0x6ec95c: tst             x16, HEAP, lsr #32
    //     0x6ec960: b.eq            #0x6ec968
    //     0x6ec964: bl              #0xd6826c
    // 0x6ec968: SaveReg r1
    //     0x6ec968: str             x1, [SP, #-8]!
    // 0x6ec96c: r0 = RenderObject()
    //     0x6ec96c: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6ec970: add             SP, SP, #8
    // 0x6ec974: ldr             x16, [fp, #0x38]
    // 0x6ec978: stp             NULL, x16, [SP, #-0x10]!
    // 0x6ec97c: r0 = child=()
    //     0x6ec97c: bl              #0x6e7da0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::child=
    // 0x6ec980: add             SP, SP, #0x10
    // 0x6ec984: ldr             x0, [fp, #0x38]
    // 0x6ec988: LoadField: r1 = r0->field_63
    //     0x6ec988: ldur            w1, [x0, #0x63]
    // 0x6ec98c: DecompressPointer r1
    //     0x6ec98c: add             x1, x1, HEAP, lsl #32
    // 0x6ec990: stp             x1, x0, [SP, #-0x10]!
    // 0x6ec994: r0 = _updateAttributedFields()
    //     0x6ec994: bl              #0x6c7010  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsAnnotations::_updateAttributedFields
    // 0x6ec998: add             SP, SP, #0x10
    // 0x6ec99c: r0 = Null
    //     0x6ec99c: mov             x0, NULL
    // 0x6ec9a0: LeaveFrame
    //     0x6ec9a0: mov             SP, fp
    //     0x6ec9a4: ldp             fp, lr, [SP], #0x10
    // 0x6ec9a8: ret
    //     0x6ec9a8: ret             
    // 0x6ec9ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ec9ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ec9b0: b               #0x6ec90c
  }
}

// class id: 2488, size: 0x6c, field offset: 0x64
class RenderAbsorbPointer extends RenderProxyBox {

  set _ absorbing=(/* No info */) {
    // ** addr: 0x50f890, size: 0x64
    // 0x50f890: EnterFrame
    //     0x50f890: stp             fp, lr, [SP, #-0x10]!
    //     0x50f894: mov             fp, SP
    // 0x50f898: CheckStackOverflow
    //     0x50f898: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50f89c: cmp             SP, x16
    //     0x50f8a0: b.ls            #0x50f8ec
    // 0x50f8a4: ldr             x0, [fp, #0x18]
    // 0x50f8a8: LoadField: r1 = r0->field_63
    //     0x50f8a8: ldur            w1, [x0, #0x63]
    // 0x50f8ac: DecompressPointer r1
    //     0x50f8ac: add             x1, x1, HEAP, lsl #32
    // 0x50f8b0: ldr             x2, [fp, #0x10]
    // 0x50f8b4: cmp             w1, w2
    // 0x50f8b8: b.ne            #0x50f8cc
    // 0x50f8bc: r0 = Null
    //     0x50f8bc: mov             x0, NULL
    // 0x50f8c0: LeaveFrame
    //     0x50f8c0: mov             SP, fp
    //     0x50f8c4: ldp             fp, lr, [SP], #0x10
    // 0x50f8c8: ret
    //     0x50f8c8: ret             
    // 0x50f8cc: StoreField: r0->field_63 = r2
    //     0x50f8cc: stur            w2, [x0, #0x63]
    // 0x50f8d0: SaveReg r0
    //     0x50f8d0: str             x0, [SP, #-8]!
    // 0x50f8d4: r0 = markNeedsSemanticsUpdate()
    //     0x50f8d4: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x50f8d8: add             SP, SP, #8
    // 0x50f8dc: r0 = Null
    //     0x50f8dc: mov             x0, NULL
    // 0x50f8e0: LeaveFrame
    //     0x50f8e0: mov             SP, fp
    //     0x50f8e4: ldp             fp, lr, [SP], #0x10
    // 0x50f8e8: ret
    //     0x50f8e8: ret             
    // 0x50f8ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50f8ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50f8f0: b               #0x50f8a4
  }
  _ hitTest(/* No info */) {
    // ** addr: 0x640558, size: 0x78
    // 0x640558: EnterFrame
    //     0x640558: stp             fp, lr, [SP, #-0x10]!
    //     0x64055c: mov             fp, SP
    // 0x640560: CheckStackOverflow
    //     0x640560: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x640564: cmp             SP, x16
    //     0x640568: b.ls            #0x6405c4
    // 0x64056c: ldr             x0, [fp, #0x20]
    // 0x640570: LoadField: r1 = r0->field_63
    //     0x640570: ldur            w1, [x0, #0x63]
    // 0x640574: DecompressPointer r1
    //     0x640574: add             x1, x1, HEAP, lsl #32
    // 0x640578: tbnz            w1, #4, #0x6405a0
    // 0x64057c: LoadField: r1 = r0->field_57
    //     0x64057c: ldur            w1, [x0, #0x57]
    // 0x640580: DecompressPointer r1
    //     0x640580: add             x1, x1, HEAP, lsl #32
    // 0x640584: cmp             w1, NULL
    // 0x640588: b.eq            #0x6405cc
    // 0x64058c: ldr             x16, [fp, #0x10]
    // 0x640590: stp             x16, x1, [SP, #-0x10]!
    // 0x640594: r0 = contains()
    //     0x640594: bl              #0x63f33c  ; [dart:ui] Size::contains
    // 0x640598: add             SP, SP, #0x10
    // 0x64059c: b               #0x6405b8
    // 0x6405a0: ldr             x16, [fp, #0x18]
    // 0x6405a4: stp             x16, x0, [SP, #-0x10]!
    // 0x6405a8: ldr             x16, [fp, #0x10]
    // 0x6405ac: SaveReg r16
    //     0x6405ac: str             x16, [SP, #-8]!
    // 0x6405b0: r0 = hitTest()
    //     0x6405b0: bl              #0x640b9c  ; [package:flutter/src/rendering/box.dart] RenderBox::hitTest
    // 0x6405b4: add             SP, SP, #0x18
    // 0x6405b8: LeaveFrame
    //     0x6405b8: mov             SP, fp
    //     0x6405bc: ldp             fp, lr, [SP], #0x10
    // 0x6405c0: ret
    //     0x6405c0: ret             
    // 0x6405c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6405c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6405c8: b               #0x64056c
    // 0x6405cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6405cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ visitChildrenForSemantics(/* No info */) {
    // ** addr: 0x675dc0, size: 0x68
    // 0x675dc0: EnterFrame
    //     0x675dc0: stp             fp, lr, [SP, #-0x10]!
    //     0x675dc4: mov             fp, SP
    // 0x675dc8: CheckStackOverflow
    //     0x675dc8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x675dcc: cmp             SP, x16
    //     0x675dd0: b.ls            #0x675e20
    // 0x675dd4: ldr             x0, [fp, #0x18]
    // 0x675dd8: LoadField: r1 = r0->field_5f
    //     0x675dd8: ldur            w1, [x0, #0x5f]
    // 0x675ddc: DecompressPointer r1
    //     0x675ddc: add             x1, x1, HEAP, lsl #32
    // 0x675de0: cmp             w1, NULL
    // 0x675de4: b.eq            #0x675e10
    // 0x675de8: LoadField: r2 = r0->field_63
    //     0x675de8: ldur            w2, [x0, #0x63]
    // 0x675dec: DecompressPointer r2
    //     0x675dec: add             x2, x2, HEAP, lsl #32
    // 0x675df0: tbz             w2, #4, #0x675e10
    // 0x675df4: ldr             x16, [fp, #0x10]
    // 0x675df8: stp             x1, x16, [SP, #-0x10]!
    // 0x675dfc: ldr             x0, [fp, #0x10]
    // 0x675e00: ClosureCall
    //     0x675e00: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x675e04: ldur            x2, [x0, #0x1f]
    //     0x675e08: blr             x2
    // 0x675e0c: add             SP, SP, #0x10
    // 0x675e10: r0 = Null
    //     0x675e10: mov             x0, NULL
    // 0x675e14: LeaveFrame
    //     0x675e14: mov             SP, fp
    //     0x675e18: ldp             fp, lr, [SP], #0x10
    // 0x675e1c: ret
    //     0x675e1c: ret             
    // 0x675e20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x675e20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x675e24: b               #0x675dd4
  }
}

// class id: 2489, size: 0x68, field offset: 0x64
class RenderOffstage extends RenderProxyBox {

  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x62eee0, size: 0x18
    // 0x62eee0: r4 = 0
    //     0x62eee0: mov             x4, #0
    // 0x62eee4: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x62eee4: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b258] AnonymousClosure: (0x62eef8), in [package:flutter/src/rendering/proxy_box.dart] RenderOffstage::computeMaxIntrinsicHeight (0x62ef44)
    //     0x62eee8: ldr             x1, [x17, #0x258]
    // 0x62eeec: r24 = BuildNonGenericMethodExtractorStub
    //     0x62eeec: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x62eef0: LoadField: r0 = r24->field_17
    //     0x62eef0: ldur            x0, [x24, #0x17]
    // 0x62eef4: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x62eef8, size: 0x4c
    // 0x62eef8: EnterFrame
    //     0x62eef8: stp             fp, lr, [SP, #-0x10]!
    //     0x62eefc: mov             fp, SP
    // 0x62ef00: ldr             x0, [fp, #0x18]
    // 0x62ef04: LoadField: r1 = r0->field_17
    //     0x62ef04: ldur            w1, [x0, #0x17]
    // 0x62ef08: DecompressPointer r1
    //     0x62ef08: add             x1, x1, HEAP, lsl #32
    // 0x62ef0c: CheckStackOverflow
    //     0x62ef0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62ef10: cmp             SP, x16
    //     0x62ef14: b.ls            #0x62ef3c
    // 0x62ef18: LoadField: r0 = r1->field_f
    //     0x62ef18: ldur            w0, [x1, #0xf]
    // 0x62ef1c: DecompressPointer r0
    //     0x62ef1c: add             x0, x0, HEAP, lsl #32
    // 0x62ef20: ldr             x16, [fp, #0x10]
    // 0x62ef24: stp             x16, x0, [SP, #-0x10]!
    // 0x62ef28: r0 = computeMaxIntrinsicHeight()
    //     0x62ef28: bl              #0x62ef44  ; [package:flutter/src/rendering/proxy_box.dart] RenderOffstage::computeMaxIntrinsicHeight
    // 0x62ef2c: add             SP, SP, #0x10
    // 0x62ef30: LeaveFrame
    //     0x62ef30: mov             SP, fp
    //     0x62ef34: ldp             fp, lr, [SP], #0x10
    // 0x62ef38: ret
    //     0x62ef38: ret             
    // 0x62ef3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62ef3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62ef40: b               #0x62ef18
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0x62ef44, size: 0x58
    // 0x62ef44: EnterFrame
    //     0x62ef44: stp             fp, lr, [SP, #-0x10]!
    //     0x62ef48: mov             fp, SP
    // 0x62ef4c: CheckStackOverflow
    //     0x62ef4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62ef50: cmp             SP, x16
    //     0x62ef54: b.ls            #0x62ef94
    // 0x62ef58: ldr             x0, [fp, #0x18]
    // 0x62ef5c: LoadField: r1 = r0->field_63
    //     0x62ef5c: ldur            w1, [x0, #0x63]
    // 0x62ef60: DecompressPointer r1
    //     0x62ef60: add             x1, x1, HEAP, lsl #32
    // 0x62ef64: tbnz            w1, #4, #0x62ef78
    // 0x62ef68: r0 = 0.000000
    //     0x62ef68: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x62ef6c: LeaveFrame
    //     0x62ef6c: mov             SP, fp
    //     0x62ef70: ldp             fp, lr, [SP], #0x10
    // 0x62ef74: ret
    //     0x62ef74: ret             
    // 0x62ef78: ldr             x16, [fp, #0x10]
    // 0x62ef7c: stp             x16, x0, [SP, #-0x10]!
    // 0x62ef80: r0 = computeMaxIntrinsicHeight()
    //     0x62ef80: bl              #0x62e908  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMaxIntrinsicHeight
    // 0x62ef84: add             SP, SP, #0x10
    // 0x62ef88: LeaveFrame
    //     0x62ef88: mov             SP, fp
    //     0x62ef8c: ldp             fp, lr, [SP], #0x10
    // 0x62ef90: ret
    //     0x62ef90: ret             
    // 0x62ef94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62ef94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62ef98: b               #0x62ef58
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x6358f8, size: 0x18
    // 0x6358f8: r4 = 0
    //     0x6358f8: mov             x4, #0
    // 0x6358fc: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x6358fc: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fc00] AnonymousClosure: (0x635910), in [package:flutter/src/rendering/proxy_box.dart] RenderOffstage::computeMaxIntrinsicWidth (0x63595c)
    //     0x635900: ldr             x1, [x17, #0xc00]
    // 0x635904: r24 = BuildNonGenericMethodExtractorStub
    //     0x635904: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x635908: LoadField: r0 = r24->field_17
    //     0x635908: ldur            x0, [x24, #0x17]
    // 0x63590c: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x635910, size: 0x4c
    // 0x635910: EnterFrame
    //     0x635910: stp             fp, lr, [SP, #-0x10]!
    //     0x635914: mov             fp, SP
    // 0x635918: ldr             x0, [fp, #0x18]
    // 0x63591c: LoadField: r1 = r0->field_17
    //     0x63591c: ldur            w1, [x0, #0x17]
    // 0x635920: DecompressPointer r1
    //     0x635920: add             x1, x1, HEAP, lsl #32
    // 0x635924: CheckStackOverflow
    //     0x635924: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x635928: cmp             SP, x16
    //     0x63592c: b.ls            #0x635954
    // 0x635930: LoadField: r0 = r1->field_f
    //     0x635930: ldur            w0, [x1, #0xf]
    // 0x635934: DecompressPointer r0
    //     0x635934: add             x0, x0, HEAP, lsl #32
    // 0x635938: ldr             x16, [fp, #0x10]
    // 0x63593c: stp             x16, x0, [SP, #-0x10]!
    // 0x635940: r0 = computeMaxIntrinsicWidth()
    //     0x635940: bl              #0x63595c  ; [package:flutter/src/rendering/proxy_box.dart] RenderOffstage::computeMaxIntrinsicWidth
    // 0x635944: add             SP, SP, #0x10
    // 0x635948: LeaveFrame
    //     0x635948: mov             SP, fp
    //     0x63594c: ldp             fp, lr, [SP], #0x10
    // 0x635950: ret
    //     0x635950: ret             
    // 0x635954: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x635954: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x635958: b               #0x635930
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0x63595c, size: 0x58
    // 0x63595c: EnterFrame
    //     0x63595c: stp             fp, lr, [SP, #-0x10]!
    //     0x635960: mov             fp, SP
    // 0x635964: CheckStackOverflow
    //     0x635964: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x635968: cmp             SP, x16
    //     0x63596c: b.ls            #0x6359ac
    // 0x635970: ldr             x0, [fp, #0x18]
    // 0x635974: LoadField: r1 = r0->field_63
    //     0x635974: ldur            w1, [x0, #0x63]
    // 0x635978: DecompressPointer r1
    //     0x635978: add             x1, x1, HEAP, lsl #32
    // 0x63597c: tbnz            w1, #4, #0x635990
    // 0x635980: r0 = 0.000000
    //     0x635980: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x635984: LeaveFrame
    //     0x635984: mov             SP, fp
    //     0x635988: ldp             fp, lr, [SP], #0x10
    // 0x63598c: ret
    //     0x63598c: ret             
    // 0x635990: ldr             x16, [fp, #0x10]
    // 0x635994: stp             x16, x0, [SP, #-0x10]!
    // 0x635998: r0 = computeMaxIntrinsicWidth()
    //     0x635998: bl              #0x635544  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMaxIntrinsicWidth
    // 0x63599c: add             SP, SP, #0x10
    // 0x6359a0: LeaveFrame
    //     0x6359a0: mov             SP, fp
    //     0x6359a4: ldp             fp, lr, [SP], #0x10
    // 0x6359a8: ret
    //     0x6359a8: ret             
    // 0x6359ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6359ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6359b0: b               #0x635970
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x638b2c, size: 0x18
    // 0x638b2c: r4 = 0
    //     0x638b2c: mov             x4, #0
    // 0x638b30: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x638b30: add             x17, PP, #0x52, lsl #12  ; [pp+0x52e88] AnonymousClosure: (0x638b44), in [package:flutter/src/rendering/proxy_box.dart] RenderOffstage::computeMinIntrinsicHeight (0x638b90)
    //     0x638b34: ldr             x1, [x17, #0xe88]
    // 0x638b38: r24 = BuildNonGenericMethodExtractorStub
    //     0x638b38: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x638b3c: LoadField: r0 = r24->field_17
    //     0x638b3c: ldur            x0, [x24, #0x17]
    // 0x638b40: br              x0
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x638b44, size: 0x4c
    // 0x638b44: EnterFrame
    //     0x638b44: stp             fp, lr, [SP, #-0x10]!
    //     0x638b48: mov             fp, SP
    // 0x638b4c: ldr             x0, [fp, #0x18]
    // 0x638b50: LoadField: r1 = r0->field_17
    //     0x638b50: ldur            w1, [x0, #0x17]
    // 0x638b54: DecompressPointer r1
    //     0x638b54: add             x1, x1, HEAP, lsl #32
    // 0x638b58: CheckStackOverflow
    //     0x638b58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x638b5c: cmp             SP, x16
    //     0x638b60: b.ls            #0x638b88
    // 0x638b64: LoadField: r0 = r1->field_f
    //     0x638b64: ldur            w0, [x1, #0xf]
    // 0x638b68: DecompressPointer r0
    //     0x638b68: add             x0, x0, HEAP, lsl #32
    // 0x638b6c: ldr             x16, [fp, #0x10]
    // 0x638b70: stp             x16, x0, [SP, #-0x10]!
    // 0x638b74: r0 = computeMinIntrinsicHeight()
    //     0x638b74: bl              #0x638b90  ; [package:flutter/src/rendering/proxy_box.dart] RenderOffstage::computeMinIntrinsicHeight
    // 0x638b78: add             SP, SP, #0x10
    // 0x638b7c: LeaveFrame
    //     0x638b7c: mov             SP, fp
    //     0x638b80: ldp             fp, lr, [SP], #0x10
    // 0x638b84: ret
    //     0x638b84: ret             
    // 0x638b88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x638b88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x638b8c: b               #0x638b64
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0x638b90, size: 0x58
    // 0x638b90: EnterFrame
    //     0x638b90: stp             fp, lr, [SP, #-0x10]!
    //     0x638b94: mov             fp, SP
    // 0x638b98: CheckStackOverflow
    //     0x638b98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x638b9c: cmp             SP, x16
    //     0x638ba0: b.ls            #0x638be0
    // 0x638ba4: ldr             x0, [fp, #0x18]
    // 0x638ba8: LoadField: r1 = r0->field_63
    //     0x638ba8: ldur            w1, [x0, #0x63]
    // 0x638bac: DecompressPointer r1
    //     0x638bac: add             x1, x1, HEAP, lsl #32
    // 0x638bb0: tbnz            w1, #4, #0x638bc4
    // 0x638bb4: r0 = 0.000000
    //     0x638bb4: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x638bb8: LeaveFrame
    //     0x638bb8: mov             SP, fp
    //     0x638bbc: ldp             fp, lr, [SP], #0x10
    // 0x638bc0: ret
    //     0x638bc0: ret             
    // 0x638bc4: ldr             x16, [fp, #0x10]
    // 0x638bc8: stp             x16, x0, [SP, #-0x10]!
    // 0x638bcc: r0 = computeMinIntrinsicHeight()
    //     0x638bcc: bl              #0x63863c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMinIntrinsicHeight
    // 0x638bd0: add             SP, SP, #0x10
    // 0x638bd4: LeaveFrame
    //     0x638bd4: mov             SP, fp
    //     0x638bd8: ldp             fp, lr, [SP], #0x10
    // 0x638bdc: ret
    //     0x638bdc: ret             
    // 0x638be0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x638be0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x638be4: b               #0x638ba4
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63b768, size: 0x18
    // 0x63b768: r4 = 0
    //     0x63b768: mov             x4, #0
    // 0x63b76c: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63b76c: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fd00] AnonymousClosure: (0x63b780), in [package:flutter/src/rendering/proxy_box.dart] RenderOffstage::computeMinIntrinsicWidth (0x63b7cc)
    //     0x63b770: ldr             x1, [x17, #0xd00]
    // 0x63b774: r24 = BuildNonGenericMethodExtractorStub
    //     0x63b774: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63b778: LoadField: r0 = r24->field_17
    //     0x63b778: ldur            x0, [x24, #0x17]
    // 0x63b77c: br              x0
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63b780, size: 0x4c
    // 0x63b780: EnterFrame
    //     0x63b780: stp             fp, lr, [SP, #-0x10]!
    //     0x63b784: mov             fp, SP
    // 0x63b788: ldr             x0, [fp, #0x18]
    // 0x63b78c: LoadField: r1 = r0->field_17
    //     0x63b78c: ldur            w1, [x0, #0x17]
    // 0x63b790: DecompressPointer r1
    //     0x63b790: add             x1, x1, HEAP, lsl #32
    // 0x63b794: CheckStackOverflow
    //     0x63b794: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63b798: cmp             SP, x16
    //     0x63b79c: b.ls            #0x63b7c4
    // 0x63b7a0: LoadField: r0 = r1->field_f
    //     0x63b7a0: ldur            w0, [x1, #0xf]
    // 0x63b7a4: DecompressPointer r0
    //     0x63b7a4: add             x0, x0, HEAP, lsl #32
    // 0x63b7a8: ldr             x16, [fp, #0x10]
    // 0x63b7ac: stp             x16, x0, [SP, #-0x10]!
    // 0x63b7b0: r0 = computeMinIntrinsicWidth()
    //     0x63b7b0: bl              #0x63b7cc  ; [package:flutter/src/rendering/proxy_box.dart] RenderOffstage::computeMinIntrinsicWidth
    // 0x63b7b4: add             SP, SP, #0x10
    // 0x63b7b8: LeaveFrame
    //     0x63b7b8: mov             SP, fp
    //     0x63b7bc: ldp             fp, lr, [SP], #0x10
    // 0x63b7c0: ret
    //     0x63b7c0: ret             
    // 0x63b7c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63b7c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63b7c8: b               #0x63b7a0
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0x63b7cc, size: 0x58
    // 0x63b7cc: EnterFrame
    //     0x63b7cc: stp             fp, lr, [SP, #-0x10]!
    //     0x63b7d0: mov             fp, SP
    // 0x63b7d4: CheckStackOverflow
    //     0x63b7d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63b7d8: cmp             SP, x16
    //     0x63b7dc: b.ls            #0x63b81c
    // 0x63b7e0: ldr             x0, [fp, #0x18]
    // 0x63b7e4: LoadField: r1 = r0->field_63
    //     0x63b7e4: ldur            w1, [x0, #0x63]
    // 0x63b7e8: DecompressPointer r1
    //     0x63b7e8: add             x1, x1, HEAP, lsl #32
    // 0x63b7ec: tbnz            w1, #4, #0x63b800
    // 0x63b7f0: r0 = 0.000000
    //     0x63b7f0: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x63b7f4: LeaveFrame
    //     0x63b7f4: mov             SP, fp
    //     0x63b7f8: ldp             fp, lr, [SP], #0x10
    // 0x63b7fc: ret
    //     0x63b7fc: ret             
    // 0x63b800: ldr             x16, [fp, #0x10]
    // 0x63b804: stp             x16, x0, [SP, #-0x10]!
    // 0x63b808: r0 = computeMinIntrinsicWidth()
    //     0x63b808: bl              #0x63b368  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMinIntrinsicWidth
    // 0x63b80c: add             SP, SP, #0x10
    // 0x63b810: LeaveFrame
    //     0x63b810: mov             SP, fp
    //     0x63b814: ldp             fp, lr, [SP], #0x10
    // 0x63b818: ret
    //     0x63b818: ret             
    // 0x63b81c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63b81c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63b820: b               #0x63b7e0
  }
  _ computeDistanceToActualBaseline(/* No info */) {
    // ** addr: 0x63e0c0, size: 0x58
    // 0x63e0c0: EnterFrame
    //     0x63e0c0: stp             fp, lr, [SP, #-0x10]!
    //     0x63e0c4: mov             fp, SP
    // 0x63e0c8: CheckStackOverflow
    //     0x63e0c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63e0cc: cmp             SP, x16
    //     0x63e0d0: b.ls            #0x63e110
    // 0x63e0d4: ldr             x0, [fp, #0x18]
    // 0x63e0d8: LoadField: r1 = r0->field_63
    //     0x63e0d8: ldur            w1, [x0, #0x63]
    // 0x63e0dc: DecompressPointer r1
    //     0x63e0dc: add             x1, x1, HEAP, lsl #32
    // 0x63e0e0: tbnz            w1, #4, #0x63e0f4
    // 0x63e0e4: r0 = Null
    //     0x63e0e4: mov             x0, NULL
    // 0x63e0e8: LeaveFrame
    //     0x63e0e8: mov             SP, fp
    //     0x63e0ec: ldp             fp, lr, [SP], #0x10
    // 0x63e0f0: ret
    //     0x63e0f0: ret             
    // 0x63e0f4: ldr             x16, [fp, #0x10]
    // 0x63e0f8: stp             x16, x0, [SP, #-0x10]!
    // 0x63e0fc: r0 = computeDistanceToActualBaseline()
    //     0x63e0fc: bl              #0x63e234  ; [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::computeDistanceToActualBaseline
    // 0x63e100: add             SP, SP, #0x10
    // 0x63e104: LeaveFrame
    //     0x63e104: mov             SP, fp
    //     0x63e108: ldp             fp, lr, [SP], #0x10
    // 0x63e10c: ret
    //     0x63e10c: ret             
    // 0x63e110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63e110: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63e114: b               #0x63e0d4
  }
  _ hitTest(/* No info */) {
    // ** addr: 0x640500, size: 0x58
    // 0x640500: EnterFrame
    //     0x640500: stp             fp, lr, [SP, #-0x10]!
    //     0x640504: mov             fp, SP
    // 0x640508: CheckStackOverflow
    //     0x640508: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64050c: cmp             SP, x16
    //     0x640510: b.ls            #0x640550
    // 0x640514: ldr             x0, [fp, #0x20]
    // 0x640518: LoadField: r1 = r0->field_63
    //     0x640518: ldur            w1, [x0, #0x63]
    // 0x64051c: DecompressPointer r1
    //     0x64051c: add             x1, x1, HEAP, lsl #32
    // 0x640520: tbz             w1, #4, #0x640540
    // 0x640524: ldr             x16, [fp, #0x18]
    // 0x640528: stp             x16, x0, [SP, #-0x10]!
    // 0x64052c: ldr             x16, [fp, #0x10]
    // 0x640530: SaveReg r16
    //     0x640530: str             x16, [SP, #-8]!
    // 0x640534: r0 = hitTest()
    //     0x640534: bl              #0x640b9c  ; [package:flutter/src/rendering/box.dart] RenderBox::hitTest
    // 0x640538: add             SP, SP, #0x18
    // 0x64053c: b               #0x640544
    // 0x640540: r0 = false
    //     0x640540: add             x0, NULL, #0x30  ; false
    // 0x640544: LeaveFrame
    //     0x640544: mov             SP, fp
    //     0x640548: ldp             fp, lr, [SP], #0x10
    // 0x64054c: ret
    //     0x64054c: ret             
    // 0x640550: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x640550: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x640554: b               #0x640514
  }
  _ performResize(/* No info */) {
    // ** addr: 0x640e74, size: 0x3c
    // 0x640e74: EnterFrame
    //     0x640e74: stp             fp, lr, [SP, #-0x10]!
    //     0x640e78: mov             fp, SP
    // 0x640e7c: CheckStackOverflow
    //     0x640e7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x640e80: cmp             SP, x16
    //     0x640e84: b.ls            #0x640ea8
    // 0x640e88: ldr             x16, [fp, #0x10]
    // 0x640e8c: SaveReg r16
    //     0x640e8c: str             x16, [SP, #-8]!
    // 0x640e90: r0 = performResize()
    //     0x640e90: bl              #0x641464  ; [package:flutter/src/rendering/box.dart] RenderBox::performResize
    // 0x640e94: add             SP, SP, #8
    // 0x640e98: r0 = Null
    //     0x640e98: mov             x0, NULL
    // 0x640e9c: LeaveFrame
    //     0x640e9c: mov             SP, fp
    //     0x640ea0: ldp             fp, lr, [SP], #0x10
    // 0x640ea4: ret
    //     0x640ea4: ret             
    // 0x640ea8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x640ea8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x640eac: b               #0x640e88
  }
  _ paintsChild(/* No info */) {
    // ** addr: 0x641814, size: 0x60
    // 0x641814: EnterFrame
    //     0x641814: stp             fp, lr, [SP, #-0x10]!
    //     0x641818: mov             fp, SP
    // 0x64181c: ldr             x0, [fp, #0x10]
    // 0x641820: r2 = Null
    //     0x641820: mov             x2, NULL
    // 0x641824: r1 = Null
    //     0x641824: mov             x1, NULL
    // 0x641828: r4 = 59
    //     0x641828: mov             x4, #0x3b
    // 0x64182c: branchIfSmi(r0, 0x641838)
    //     0x64182c: tbz             w0, #0, #0x641838
    // 0x641830: r4 = LoadClassIdInstr(r0)
    //     0x641830: ldur            x4, [x0, #-1]
    //     0x641834: ubfx            x4, x4, #0xc, #0x14
    // 0x641838: sub             x4, x4, #0x965
    // 0x64183c: cmp             x4, #0x8b
    // 0x641840: b.ls            #0x641858
    // 0x641844: r8 = RenderBox
    //     0x641844: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x641848: ldr             x8, [x8, #0xfa0]
    // 0x64184c: r3 = Null
    //     0x64184c: add             x3, PP, #0x28, lsl #12  ; [pp+0x28548] Null
    //     0x641850: ldr             x3, [x3, #0x548]
    // 0x641854: r0 = RenderBox()
    //     0x641854: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x641858: ldr             x1, [fp, #0x18]
    // 0x64185c: LoadField: r2 = r1->field_63
    //     0x64185c: ldur            w2, [x1, #0x63]
    // 0x641860: DecompressPointer r2
    //     0x641860: add             x2, x2, HEAP, lsl #32
    // 0x641864: eor             x0, x2, #0x10
    // 0x641868: LeaveFrame
    //     0x641868: mov             SP, fp
    //     0x64186c: ldp             fp, lr, [SP], #0x10
    // 0x641870: ret
    //     0x641870: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0x666100, size: 0x64
    // 0x666100: EnterFrame
    //     0x666100: stp             fp, lr, [SP, #-0x10]!
    //     0x666104: mov             fp, SP
    // 0x666108: CheckStackOverflow
    //     0x666108: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66610c: cmp             SP, x16
    //     0x666110: b.ls            #0x66615c
    // 0x666114: ldr             x0, [fp, #0x20]
    // 0x666118: LoadField: r1 = r0->field_63
    //     0x666118: ldur            w1, [x0, #0x63]
    // 0x66611c: DecompressPointer r1
    //     0x66611c: add             x1, x1, HEAP, lsl #32
    // 0x666120: tbnz            w1, #4, #0x666134
    // 0x666124: r0 = Null
    //     0x666124: mov             x0, NULL
    // 0x666128: LeaveFrame
    //     0x666128: mov             SP, fp
    //     0x66612c: ldp             fp, lr, [SP], #0x10
    // 0x666130: ret
    //     0x666130: ret             
    // 0x666134: ldr             x16, [fp, #0x18]
    // 0x666138: stp             x16, x0, [SP, #-0x10]!
    // 0x66613c: ldr             x16, [fp, #0x10]
    // 0x666140: SaveReg r16
    //     0x666140: str             x16, [SP, #-8]!
    // 0x666144: r0 = paint()
    //     0x666144: bl              #0x669ddc  ; [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::paint
    // 0x666148: add             SP, SP, #0x18
    // 0x66614c: r0 = Null
    //     0x66614c: mov             x0, NULL
    // 0x666150: LeaveFrame
    //     0x666150: mov             SP, fp
    //     0x666154: ldp             fp, lr, [SP], #0x10
    // 0x666158: ret
    //     0x666158: ret             
    // 0x66615c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66615c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x666160: b               #0x666114
  }
  get _ sizedByParent(/* No info */) {
    // ** addr: 0x675b24, size: 0x10
    // 0x675b24: ldr             x1, [SP]
    // 0x675b28: LoadField: r0 = r1->field_63
    //     0x675b28: ldur            w0, [x1, #0x63]
    // 0x675b2c: DecompressPointer r0
    //     0x675b2c: add             x0, x0, HEAP, lsl #32
    // 0x675b30: ret
    //     0x675b30: ret             
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x68fe60, size: 0xfc
    // 0x68fe60: EnterFrame
    //     0x68fe60: stp             fp, lr, [SP, #-0x10]!
    //     0x68fe64: mov             fp, SP
    // 0x68fe68: AllocStack(0x10)
    //     0x68fe68: sub             SP, SP, #0x10
    // 0x68fe6c: CheckStackOverflow
    //     0x68fe6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68fe70: cmp             SP, x16
    //     0x68fe74: b.ls            #0x68ff54
    // 0x68fe78: ldr             x0, [fp, #0x10]
    // 0x68fe7c: LoadField: r1 = r0->field_63
    //     0x68fe7c: ldur            w1, [x0, #0x63]
    // 0x68fe80: DecompressPointer r1
    //     0x68fe80: add             x1, x1, HEAP, lsl #32
    // 0x68fe84: tbnz            w1, #4, #0x68ff18
    // 0x68fe88: LoadField: r3 = r0->field_5f
    //     0x68fe88: ldur            w3, [x0, #0x5f]
    // 0x68fe8c: DecompressPointer r3
    //     0x68fe8c: add             x3, x3, HEAP, lsl #32
    // 0x68fe90: stur            x3, [fp, #-0x10]
    // 0x68fe94: cmp             w3, NULL
    // 0x68fe98: b.eq            #0x68ff24
    // 0x68fe9c: LoadField: r4 = r0->field_27
    //     0x68fe9c: ldur            w4, [x0, #0x27]
    // 0x68fea0: DecompressPointer r4
    //     0x68fea0: add             x4, x4, HEAP, lsl #32
    // 0x68fea4: stur            x4, [fp, #-8]
    // 0x68fea8: cmp             w4, NULL
    // 0x68feac: b.eq            #0x68ff34
    // 0x68feb0: mov             x0, x4
    // 0x68feb4: r2 = Null
    //     0x68feb4: mov             x2, NULL
    // 0x68feb8: r1 = Null
    //     0x68feb8: mov             x1, NULL
    // 0x68febc: r4 = LoadClassIdInstr(r0)
    //     0x68febc: ldur            x4, [x0, #-1]
    //     0x68fec0: ubfx            x4, x4, #0xc, #0x14
    // 0x68fec4: sub             x4, x4, #0x80d
    // 0x68fec8: cmp             x4, #1
    // 0x68fecc: b.ls            #0x68fee4
    // 0x68fed0: r8 = BoxConstraints
    //     0x68fed0: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x68fed4: ldr             x8, [x8, #0x1d0]
    // 0x68fed8: r3 = Null
    //     0x68fed8: add             x3, PP, #0x15, lsl #12  ; [pp+0x151f8] Null
    //     0x68fedc: ldr             x3, [x3, #0x1f8]
    // 0x68fee0: r0 = BoxConstraints()
    //     0x68fee0: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x68fee4: ldur            x0, [fp, #-0x10]
    // 0x68fee8: r1 = LoadClassIdInstr(r0)
    //     0x68fee8: ldur            x1, [x0, #-1]
    //     0x68feec: ubfx            x1, x1, #0xc, #0x14
    // 0x68fef0: ldur            x16, [fp, #-8]
    // 0x68fef4: stp             x16, x0, [SP, #-0x10]!
    // 0x68fef8: mov             x0, x1
    // 0x68fefc: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x68fefc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x68ff00: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x68ff00: mov             x17, #0xcdfb
    //     0x68ff04: add             lr, x0, x17
    //     0x68ff08: ldr             lr, [x21, lr, lsl #3]
    //     0x68ff0c: blr             lr
    // 0x68ff10: add             SP, SP, #0x10
    // 0x68ff14: b               #0x68ff24
    // 0x68ff18: SaveReg r0
    //     0x68ff18: str             x0, [SP, #-8]!
    // 0x68ff1c: r0 = performLayout()
    //     0x68ff1c: bl              #0x68fff8  ; [package:flutter/src/rendering/proxy_box.dart] _RenderProxyBox&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::performLayout
    // 0x68ff20: add             SP, SP, #8
    // 0x68ff24: r0 = Null
    //     0x68ff24: mov             x0, NULL
    // 0x68ff28: LeaveFrame
    //     0x68ff28: mov             SP, fp
    //     0x68ff2c: ldp             fp, lr, [SP], #0x10
    // 0x68ff30: ret
    //     0x68ff30: ret             
    // 0x68ff34: r0 = StateError()
    //     0x68ff34: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68ff38: mov             x1, x0
    // 0x68ff3c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68ff3c: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68ff40: ldr             x0, [x0, #0x1e8]
    // 0x68ff44: StoreField: r1->field_b = r0
    //     0x68ff44: stur            w0, [x1, #0xb]
    // 0x68ff48: mov             x0, x1
    // 0x68ff4c: r0 = Throw()
    //     0x68ff4c: bl              #0xd67e38  ; ThrowStub
    // 0x68ff50: brk             #0
    // 0x68ff54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68ff54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68ff58: b               #0x68fe78
  }
  set _ offstage=(/* No info */) {
    // ** addr: 0x6c6388, size: 0x64
    // 0x6c6388: EnterFrame
    //     0x6c6388: stp             fp, lr, [SP, #-0x10]!
    //     0x6c638c: mov             fp, SP
    // 0x6c6390: CheckStackOverflow
    //     0x6c6390: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c6394: cmp             SP, x16
    //     0x6c6398: b.ls            #0x6c63e4
    // 0x6c639c: ldr             x0, [fp, #0x18]
    // 0x6c63a0: LoadField: r1 = r0->field_63
    //     0x6c63a0: ldur            w1, [x0, #0x63]
    // 0x6c63a4: DecompressPointer r1
    //     0x6c63a4: add             x1, x1, HEAP, lsl #32
    // 0x6c63a8: ldr             x2, [fp, #0x10]
    // 0x6c63ac: cmp             w2, w1
    // 0x6c63b0: b.ne            #0x6c63c4
    // 0x6c63b4: r0 = Null
    //     0x6c63b4: mov             x0, NULL
    // 0x6c63b8: LeaveFrame
    //     0x6c63b8: mov             SP, fp
    //     0x6c63bc: ldp             fp, lr, [SP], #0x10
    // 0x6c63c0: ret
    //     0x6c63c0: ret             
    // 0x6c63c4: StoreField: r0->field_63 = r2
    //     0x6c63c4: stur            w2, [x0, #0x63]
    // 0x6c63c8: SaveReg r0
    //     0x6c63c8: str             x0, [SP, #-8]!
    // 0x6c63cc: r0 = markNeedsLayoutForSizedByParentChange()
    //     0x6c63cc: bl              #0x6c63ec  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsLayoutForSizedByParentChange
    // 0x6c63d0: add             SP, SP, #8
    // 0x6c63d4: r0 = Null
    //     0x6c63d4: mov             x0, NULL
    // 0x6c63d8: LeaveFrame
    //     0x6c63d8: mov             SP, fp
    //     0x6c63dc: ldp             fp, lr, [SP], #0x10
    // 0x6c63e0: ret
    //     0x6c63e0: ret             
    // 0x6c63e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c63e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c63e8: b               #0x6c639c
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5d904, size: 0x64
    // 0xa5d904: EnterFrame
    //     0xa5d904: stp             fp, lr, [SP, #-0x10]!
    //     0xa5d908: mov             fp, SP
    // 0xa5d90c: CheckStackOverflow
    //     0xa5d90c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5d910: cmp             SP, x16
    //     0xa5d914: b.ls            #0xa5d960
    // 0xa5d918: ldr             x0, [fp, #0x18]
    // 0xa5d91c: LoadField: r1 = r0->field_63
    //     0xa5d91c: ldur            w1, [x0, #0x63]
    // 0xa5d920: DecompressPointer r1
    //     0xa5d920: add             x1, x1, HEAP, lsl #32
    // 0xa5d924: tbnz            w1, #4, #0xa5d944
    // 0xa5d928: ldr             x16, [fp, #0x10]
    // 0xa5d92c: SaveReg r16
    //     0xa5d92c: str             x16, [SP, #-8]!
    // 0xa5d930: r0 = smallest()
    //     0xa5d930: bl              #0x62bd18  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xa5d934: add             SP, SP, #8
    // 0xa5d938: LeaveFrame
    //     0xa5d938: mov             SP, fp
    //     0xa5d93c: ldp             fp, lr, [SP], #0x10
    // 0xa5d940: ret
    //     0xa5d940: ret             
    // 0xa5d944: ldr             x16, [fp, #0x10]
    // 0xa5d948: stp             x16, x0, [SP, #-0x10]!
    // 0xa5d94c: r0 = computeDryLayout()
    //     0xa5d94c: bl              #0xa5d968  ; [package:flutter/src/rendering/proxy_box.dart] _RenderProxyBox&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::computeDryLayout
    // 0xa5d950: add             SP, SP, #0x10
    // 0xa5d954: LeaveFrame
    //     0xa5d954: mov             SP, fp
    //     0xa5d958: ldp             fp, lr, [SP], #0x10
    // 0xa5d95c: ret
    //     0xa5d95c: ret             
    // 0xa5d960: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5d960: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5d964: b               #0xa5d918
  }
}

// class id: 2490, size: 0x6c, field offset: 0x64
class RenderIgnorePointer extends RenderProxyBox {

  _ visitChildrenForSemantics(/* No info */) {
    // ** addr: 0x675d40, size: 0x80
    // 0x675d40: EnterFrame
    //     0x675d40: stp             fp, lr, [SP, #-0x10]!
    //     0x675d44: mov             fp, SP
    // 0x675d48: CheckStackOverflow
    //     0x675d48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x675d4c: cmp             SP, x16
    //     0x675d50: b.ls            #0x675db8
    // 0x675d54: ldr             x0, [fp, #0x18]
    // 0x675d58: LoadField: r1 = r0->field_5f
    //     0x675d58: ldur            w1, [x0, #0x5f]
    // 0x675d5c: DecompressPointer r1
    //     0x675d5c: add             x1, x1, HEAP, lsl #32
    // 0x675d60: cmp             w1, NULL
    // 0x675d64: b.eq            #0x675da8
    // 0x675d68: LoadField: r2 = r0->field_67
    //     0x675d68: ldur            w2, [x0, #0x67]
    // 0x675d6c: DecompressPointer r2
    //     0x675d6c: add             x2, x2, HEAP, lsl #32
    // 0x675d70: cmp             w2, NULL
    // 0x675d74: b.ne            #0x675d88
    // 0x675d78: LoadField: r2 = r0->field_63
    //     0x675d78: ldur            w2, [x0, #0x63]
    // 0x675d7c: DecompressPointer r2
    //     0x675d7c: add             x2, x2, HEAP, lsl #32
    // 0x675d80: tbz             w2, #4, #0x675da8
    // 0x675d84: b               #0x675d8c
    // 0x675d88: tbz             w2, #4, #0x675da8
    // 0x675d8c: ldr             x16, [fp, #0x10]
    // 0x675d90: stp             x1, x16, [SP, #-0x10]!
    // 0x675d94: ldr             x0, [fp, #0x10]
    // 0x675d98: ClosureCall
    //     0x675d98: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x675d9c: ldur            x2, [x0, #0x1f]
    //     0x675da0: blr             x2
    // 0x675da4: add             SP, SP, #0x10
    // 0x675da8: r0 = Null
    //     0x675da8: mov             x0, NULL
    // 0x675dac: LeaveFrame
    //     0x675dac: mov             SP, fp
    //     0x675db0: ldp             fp, lr, [SP], #0x10
    // 0x675db4: ret
    //     0x675db4: ret             
    // 0x675db8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x675db8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x675dbc: b               #0x675d54
  }
  set _ ignoringSemantics=(/* No info */) {
    // ** addr: 0x6c6b88, size: 0x94
    // 0x6c6b88: EnterFrame
    //     0x6c6b88: stp             fp, lr, [SP, #-0x10]!
    //     0x6c6b8c: mov             fp, SP
    // 0x6c6b90: CheckStackOverflow
    //     0x6c6b90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c6b94: cmp             SP, x16
    //     0x6c6b98: b.ls            #0x6c6c14
    // 0x6c6b9c: ldr             x0, [fp, #0x18]
    // 0x6c6ba0: LoadField: r1 = r0->field_67
    //     0x6c6ba0: ldur            w1, [x0, #0x67]
    // 0x6c6ba4: DecompressPointer r1
    //     0x6c6ba4: add             x1, x1, HEAP, lsl #32
    // 0x6c6ba8: ldr             x2, [fp, #0x10]
    // 0x6c6bac: cmp             w2, w1
    // 0x6c6bb0: b.ne            #0x6c6bc4
    // 0x6c6bb4: r0 = Null
    //     0x6c6bb4: mov             x0, NULL
    // 0x6c6bb8: LeaveFrame
    //     0x6c6bb8: mov             SP, fp
    //     0x6c6bbc: ldp             fp, lr, [SP], #0x10
    // 0x6c6bc0: ret
    //     0x6c6bc0: ret             
    // 0x6c6bc4: SaveReg r0
    //     0x6c6bc4: str             x0, [SP, #-8]!
    // 0x6c6bc8: r0 = _effectiveIgnoringSemantics()
    //     0x6c6bc8: bl              #0x6c6c1c  ; [package:flutter/src/rendering/proxy_box.dart] RenderIgnorePointer::_effectiveIgnoringSemantics
    // 0x6c6bcc: add             SP, SP, #8
    // 0x6c6bd0: mov             x2, x0
    // 0x6c6bd4: ldr             x0, [fp, #0x18]
    // 0x6c6bd8: ldr             x1, [fp, #0x10]
    // 0x6c6bdc: StoreField: r0->field_67 = r1
    //     0x6c6bdc: stur            w1, [x0, #0x67]
    // 0x6c6be0: cmp             w1, NULL
    // 0x6c6be4: b.ne            #0x6c6bf0
    // 0x6c6be8: LoadField: r1 = r0->field_63
    //     0x6c6be8: ldur            w1, [x0, #0x63]
    // 0x6c6bec: DecompressPointer r1
    //     0x6c6bec: add             x1, x1, HEAP, lsl #32
    // 0x6c6bf0: cmp             w2, w1
    // 0x6c6bf4: b.eq            #0x6c6c04
    // 0x6c6bf8: SaveReg r0
    //     0x6c6bf8: str             x0, [SP, #-8]!
    // 0x6c6bfc: r0 = markNeedsSemanticsUpdate()
    //     0x6c6bfc: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6c6c00: add             SP, SP, #8
    // 0x6c6c04: r0 = Null
    //     0x6c6c04: mov             x0, NULL
    // 0x6c6c08: LeaveFrame
    //     0x6c6c08: mov             SP, fp
    //     0x6c6c0c: ldp             fp, lr, [SP], #0x10
    // 0x6c6c10: ret
    //     0x6c6c10: ret             
    // 0x6c6c14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6c14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c6c18: b               #0x6c6b9c
  }
  get _ _effectiveIgnoringSemantics(/* No info */) {
    // ** addr: 0x6c6c1c, size: 0x2c
    // 0x6c6c1c: ldr             x1, [SP]
    // 0x6c6c20: LoadField: r2 = r1->field_67
    //     0x6c6c20: ldur            w2, [x1, #0x67]
    // 0x6c6c24: DecompressPointer r2
    //     0x6c6c24: add             x2, x2, HEAP, lsl #32
    // 0x6c6c28: cmp             w2, NULL
    // 0x6c6c2c: b.ne            #0x6c6c40
    // 0x6c6c30: LoadField: r3 = r1->field_63
    //     0x6c6c30: ldur            w3, [x1, #0x63]
    // 0x6c6c34: DecompressPointer r3
    //     0x6c6c34: add             x3, x3, HEAP, lsl #32
    // 0x6c6c38: mov             x0, x3
    // 0x6c6c3c: b               #0x6c6c44
    // 0x6c6c40: mov             x0, x2
    // 0x6c6c44: ret
    //     0x6c6c44: ret             
  }
  set _ ignoring=(/* No info */) {
    // ** addr: 0x6c6c48, size: 0x78
    // 0x6c6c48: EnterFrame
    //     0x6c6c48: stp             fp, lr, [SP, #-0x10]!
    //     0x6c6c4c: mov             fp, SP
    // 0x6c6c50: CheckStackOverflow
    //     0x6c6c50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c6c54: cmp             SP, x16
    //     0x6c6c58: b.ls            #0x6c6cb8
    // 0x6c6c5c: ldr             x0, [fp, #0x18]
    // 0x6c6c60: LoadField: r1 = r0->field_63
    //     0x6c6c60: ldur            w1, [x0, #0x63]
    // 0x6c6c64: DecompressPointer r1
    //     0x6c6c64: add             x1, x1, HEAP, lsl #32
    // 0x6c6c68: ldr             x2, [fp, #0x10]
    // 0x6c6c6c: cmp             w2, w1
    // 0x6c6c70: b.ne            #0x6c6c84
    // 0x6c6c74: r0 = Null
    //     0x6c6c74: mov             x0, NULL
    // 0x6c6c78: LeaveFrame
    //     0x6c6c78: mov             SP, fp
    //     0x6c6c7c: ldp             fp, lr, [SP], #0x10
    // 0x6c6c80: ret
    //     0x6c6c80: ret             
    // 0x6c6c84: StoreField: r0->field_63 = r2
    //     0x6c6c84: stur            w2, [x0, #0x63]
    // 0x6c6c88: LoadField: r1 = r0->field_67
    //     0x6c6c88: ldur            w1, [x0, #0x67]
    // 0x6c6c8c: DecompressPointer r1
    //     0x6c6c8c: add             x1, x1, HEAP, lsl #32
    // 0x6c6c90: cmp             w1, NULL
    // 0x6c6c94: b.eq            #0x6c6c9c
    // 0x6c6c98: tbz             w1, #4, #0x6c6ca8
    // 0x6c6c9c: SaveReg r0
    //     0x6c6c9c: str             x0, [SP, #-8]!
    // 0x6c6ca0: r0 = markNeedsSemanticsUpdate()
    //     0x6c6ca0: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6c6ca4: add             SP, SP, #8
    // 0x6c6ca8: r0 = Null
    //     0x6c6ca8: mov             x0, NULL
    // 0x6c6cac: LeaveFrame
    //     0x6c6cac: mov             SP, fp
    //     0x6c6cb0: ldp             fp, lr, [SP], #0x10
    // 0x6c6cb4: ret
    //     0x6c6cb4: ret             
    // 0x6c6cb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6cb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c6cbc: b               #0x6c6c5c
  }
}

// class id: 2491, size: 0x64, field offset: 0x64
class RenderRepaintBoundary extends RenderProxyBox {

  _ toImage(/* No info */) {
    // ** addr: 0x912a6c, size: 0xc0
    // 0x912a6c: EnterFrame
    //     0x912a6c: stp             fp, lr, [SP, #-0x10]!
    //     0x912a70: mov             fp, SP
    // 0x912a74: AllocStack(0x8)
    //     0x912a74: sub             SP, SP, #8
    // 0x912a78: CheckStackOverflow
    //     0x912a78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x912a7c: cmp             SP, x16
    //     0x912a80: b.ls            #0x912b1c
    // 0x912a84: ldr             x3, [fp, #0x18]
    // 0x912a88: LoadField: r0 = r3->field_2f
    //     0x912a88: ldur            w0, [x3, #0x2f]
    // 0x912a8c: DecompressPointer r0
    //     0x912a8c: add             x0, x0, HEAP, lsl #32
    // 0x912a90: LoadField: r4 = r0->field_b
    //     0x912a90: ldur            w4, [x0, #0xb]
    // 0x912a94: DecompressPointer r4
    //     0x912a94: add             x4, x4, HEAP, lsl #32
    // 0x912a98: stur            x4, [fp, #-8]
    // 0x912a9c: cmp             w4, NULL
    // 0x912aa0: b.eq            #0x912b24
    // 0x912aa4: mov             x0, x4
    // 0x912aa8: r2 = Null
    //     0x912aa8: mov             x2, NULL
    // 0x912aac: r1 = Null
    //     0x912aac: mov             x1, NULL
    // 0x912ab0: r4 = LoadClassIdInstr(r0)
    //     0x912ab0: ldur            x4, [x0, #-1]
    //     0x912ab4: ubfx            x4, x4, #0xc, #0x14
    // 0x912ab8: sub             x4, x4, #0x956
    // 0x912abc: cmp             x4, #3
    // 0x912ac0: b.ls            #0x912ad4
    // 0x912ac4: r8 = OffsetLayer
    //     0x912ac4: ldr             x8, [PP, #0x4a28]  ; [pp+0x4a28] Type: OffsetLayer
    // 0x912ac8: r3 = Null
    //     0x912ac8: add             x3, PP, #0x26, lsl #12  ; [pp+0x26318] Null
    //     0x912acc: ldr             x3, [x3, #0x318]
    // 0x912ad0: r0 = DefaultTypeTest()
    //     0x912ad0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x912ad4: ldr             x0, [fp, #0x18]
    // 0x912ad8: LoadField: r1 = r0->field_57
    //     0x912ad8: ldur            w1, [x0, #0x57]
    // 0x912adc: DecompressPointer r1
    //     0x912adc: add             x1, x1, HEAP, lsl #32
    // 0x912ae0: cmp             w1, NULL
    // 0x912ae4: b.eq            #0x912b28
    // 0x912ae8: r16 = Instance_Offset
    //     0x912ae8: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x912aec: stp             x1, x16, [SP, #-0x10]!
    // 0x912af0: r0 = &()
    //     0x912af0: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x912af4: add             SP, SP, #0x10
    // 0x912af8: ldur            x16, [fp, #-8]
    // 0x912afc: stp             x0, x16, [SP, #-0x10]!
    // 0x912b00: ldr             d0, [fp, #0x10]
    // 0x912b04: SaveReg d0
    //     0x912b04: str             d0, [SP, #-8]!
    // 0x912b08: r0 = toImage()
    //     0x912b08: bl              #0x912b2c  ; [package:flutter/src/rendering/layer.dart] OffsetLayer::toImage
    // 0x912b0c: add             SP, SP, #0x18
    // 0x912b10: LeaveFrame
    //     0x912b10: mov             SP, fp
    //     0x912b14: ldp             fp, lr, [SP], #0x10
    // 0x912b18: ret
    //     0x912b18: ret             
    // 0x912b1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x912b1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x912b20: b               #0x912a84
    // 0x912b24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x912b24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x912b28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x912b28: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2492, size: 0x6c, field offset: 0x64
class RenderFractionalTranslation extends RenderProxyBox {

  _ hitTestChildren(/* No info */) {
    // ** addr: 0x6270ac, size: 0xd8
    // 0x6270ac: EnterFrame
    //     0x6270ac: stp             fp, lr, [SP, #-0x10]!
    //     0x6270b0: mov             fp, SP
    // 0x6270b4: AllocStack(0x20)
    //     0x6270b4: sub             SP, SP, #0x20
    // 0x6270b8: CheckStackOverflow
    //     0x6270b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6270bc: cmp             SP, x16
    //     0x6270c0: b.ls            #0x627178
    // 0x6270c4: r1 = 1
    //     0x6270c4: mov             x1, #1
    // 0x6270c8: r0 = AllocateContext()
    //     0x6270c8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6270cc: mov             x1, x0
    // 0x6270d0: ldr             x0, [fp, #0x20]
    // 0x6270d4: stur            x1, [fp, #-8]
    // 0x6270d8: StoreField: r1->field_f = r0
    //     0x6270d8: stur            w0, [x1, #0xf]
    // 0x6270dc: LoadField: r2 = r0->field_67
    //     0x6270dc: ldur            w2, [x0, #0x67]
    // 0x6270e0: DecompressPointer r2
    //     0x6270e0: add             x2, x2, HEAP, lsl #32
    // 0x6270e4: tbnz            w2, #4, #0x627138
    // 0x6270e8: LoadField: r2 = r0->field_63
    //     0x6270e8: ldur            w2, [x0, #0x63]
    // 0x6270ec: DecompressPointer r2
    //     0x6270ec: add             x2, x2, HEAP, lsl #32
    // 0x6270f0: LoadField: d0 = r2->field_7
    //     0x6270f0: ldur            d0, [x2, #7]
    // 0x6270f4: LoadField: r3 = r0->field_57
    //     0x6270f4: ldur            w3, [x0, #0x57]
    // 0x6270f8: DecompressPointer r3
    //     0x6270f8: add             x3, x3, HEAP, lsl #32
    // 0x6270fc: cmp             w3, NULL
    // 0x627100: b.eq            #0x627180
    // 0x627104: LoadField: d1 = r3->field_7
    //     0x627104: ldur            d1, [x3, #7]
    // 0x627108: fmul            d2, d0, d1
    // 0x62710c: stur            d2, [fp, #-0x20]
    // 0x627110: LoadField: d0 = r2->field_f
    //     0x627110: ldur            d0, [x2, #0xf]
    // 0x627114: LoadField: d1 = r3->field_f
    //     0x627114: ldur            d1, [x3, #0xf]
    // 0x627118: fmul            d3, d0, d1
    // 0x62711c: stur            d3, [fp, #-0x18]
    // 0x627120: r0 = Offset()
    //     0x627120: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x627124: ldur            d0, [fp, #-0x20]
    // 0x627128: StoreField: r0->field_7 = d0
    //     0x627128: stur            d0, [x0, #7]
    // 0x62712c: ldur            d0, [fp, #-0x18]
    // 0x627130: StoreField: r0->field_f = d0
    //     0x627130: stur            d0, [x0, #0xf]
    // 0x627134: b               #0x62713c
    // 0x627138: r0 = Null
    //     0x627138: mov             x0, NULL
    // 0x62713c: ldur            x2, [fp, #-8]
    // 0x627140: stur            x0, [fp, #-0x10]
    // 0x627144: r1 = Function '<anonymous closure>':.
    //     0x627144: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fc60] AnonymousClosure: (0x6263b8), in [package:flutter/src/rendering/proxy_box.dart] RenderTransform::hitTestChildren (0x625518)
    //     0x627148: ldr             x1, [x1, #0xc60]
    // 0x62714c: r0 = AllocateClosure()
    //     0x62714c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x627150: ldr             x16, [fp, #0x18]
    // 0x627154: stp             x0, x16, [SP, #-0x10]!
    // 0x627158: ldur            x16, [fp, #-0x10]
    // 0x62715c: ldr             lr, [fp, #0x10]
    // 0x627160: stp             lr, x16, [SP, #-0x10]!
    // 0x627164: r0 = addWithPaintOffset()
    //     0x627164: bl              #0x622820  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithPaintOffset
    // 0x627168: add             SP, SP, #0x20
    // 0x62716c: LeaveFrame
    //     0x62716c: mov             SP, fp
    //     0x627170: ldp             fp, lr, [SP], #0x10
    // 0x627174: ret
    //     0x627174: ret             
    // 0x627178: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x627178: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62717c: b               #0x6270c4
    // 0x627180: r0 = NullCastErrorSharedWithFPURegs()
    //     0x627180: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ hitTest(/* No info */) {
    // ** addr: 0x6404bc, size: 0x44
    // 0x6404bc: EnterFrame
    //     0x6404bc: stp             fp, lr, [SP, #-0x10]!
    //     0x6404c0: mov             fp, SP
    // 0x6404c4: CheckStackOverflow
    //     0x6404c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6404c8: cmp             SP, x16
    //     0x6404cc: b.ls            #0x6404f8
    // 0x6404d0: ldr             x16, [fp, #0x20]
    // 0x6404d4: ldr             lr, [fp, #0x18]
    // 0x6404d8: stp             lr, x16, [SP, #-0x10]!
    // 0x6404dc: ldr             x16, [fp, #0x10]
    // 0x6404e0: SaveReg r16
    //     0x6404e0: str             x16, [SP, #-8]!
    // 0x6404e4: r0 = hitTestChildren()
    //     0x6404e4: bl              #0x6270ac  ; [package:flutter/src/rendering/proxy_box.dart] RenderFractionalTranslation::hitTestChildren
    // 0x6404e8: add             SP, SP, #0x18
    // 0x6404ec: LeaveFrame
    //     0x6404ec: mov             SP, fp
    //     0x6404f0: ldp             fp, lr, [SP], #0x10
    // 0x6404f4: ret
    //     0x6404f4: ret             
    // 0x6404f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6404f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6404fc: b               #0x6404d0
  }
  _ paint(/* No info */) {
    // ** addr: 0x666040, size: 0xc0
    // 0x666040: EnterFrame
    //     0x666040: stp             fp, lr, [SP, #-0x10]!
    //     0x666044: mov             fp, SP
    // 0x666048: AllocStack(0x10)
    //     0x666048: sub             SP, SP, #0x10
    // 0x66604c: CheckStackOverflow
    //     0x66604c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x666050: cmp             SP, x16
    //     0x666054: b.ls            #0x6660f4
    // 0x666058: ldr             x0, [fp, #0x20]
    // 0x66605c: LoadField: r1 = r0->field_5f
    //     0x66605c: ldur            w1, [x0, #0x5f]
    // 0x666060: DecompressPointer r1
    //     0x666060: add             x1, x1, HEAP, lsl #32
    // 0x666064: cmp             w1, NULL
    // 0x666068: b.eq            #0x6660e4
    // 0x66606c: ldr             x1, [fp, #0x10]
    // 0x666070: LoadField: d0 = r1->field_7
    //     0x666070: ldur            d0, [x1, #7]
    // 0x666074: LoadField: r2 = r0->field_63
    //     0x666074: ldur            w2, [x0, #0x63]
    // 0x666078: DecompressPointer r2
    //     0x666078: add             x2, x2, HEAP, lsl #32
    // 0x66607c: LoadField: d1 = r2->field_7
    //     0x66607c: ldur            d1, [x2, #7]
    // 0x666080: LoadField: r3 = r0->field_57
    //     0x666080: ldur            w3, [x0, #0x57]
    // 0x666084: DecompressPointer r3
    //     0x666084: add             x3, x3, HEAP, lsl #32
    // 0x666088: cmp             w3, NULL
    // 0x66608c: b.eq            #0x6660fc
    // 0x666090: LoadField: d2 = r3->field_7
    //     0x666090: ldur            d2, [x3, #7]
    // 0x666094: fmul            d3, d1, d2
    // 0x666098: fadd            d1, d0, d3
    // 0x66609c: stur            d1, [fp, #-0x10]
    // 0x6660a0: LoadField: d0 = r1->field_f
    //     0x6660a0: ldur            d0, [x1, #0xf]
    // 0x6660a4: LoadField: d2 = r2->field_f
    //     0x6660a4: ldur            d2, [x2, #0xf]
    // 0x6660a8: LoadField: d3 = r3->field_f
    //     0x6660a8: ldur            d3, [x3, #0xf]
    // 0x6660ac: fmul            d4, d2, d3
    // 0x6660b0: fadd            d2, d0, d4
    // 0x6660b4: stur            d2, [fp, #-8]
    // 0x6660b8: r0 = Offset()
    //     0x6660b8: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x6660bc: ldur            d0, [fp, #-0x10]
    // 0x6660c0: StoreField: r0->field_7 = d0
    //     0x6660c0: stur            d0, [x0, #7]
    // 0x6660c4: ldur            d0, [fp, #-8]
    // 0x6660c8: StoreField: r0->field_f = d0
    //     0x6660c8: stur            d0, [x0, #0xf]
    // 0x6660cc: ldr             x16, [fp, #0x20]
    // 0x6660d0: ldr             lr, [fp, #0x18]
    // 0x6660d4: stp             lr, x16, [SP, #-0x10]!
    // 0x6660d8: SaveReg r0
    //     0x6660d8: str             x0, [SP, #-8]!
    // 0x6660dc: r0 = paint()
    //     0x6660dc: bl              #0x669ddc  ; [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::paint
    // 0x6660e0: add             SP, SP, #0x18
    // 0x6660e4: r0 = Null
    //     0x6660e4: mov             x0, NULL
    // 0x6660e8: LeaveFrame
    //     0x6660e8: mov             SP, fp
    //     0x6660ec: ldp             fp, lr, [SP], #0x10
    // 0x6660f0: ret
    //     0x6660f0: ret             
    // 0x6660f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6660f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6660f8: b               #0x666058
    // 0x6660fc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6660fc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0x6bc4ac, size: 0xec
    // 0x6bc4ac: EnterFrame
    //     0x6bc4ac: stp             fp, lr, [SP, #-0x10]!
    //     0x6bc4b0: mov             fp, SP
    // 0x6bc4b4: CheckStackOverflow
    //     0x6bc4b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bc4b8: cmp             SP, x16
    //     0x6bc4bc: b.ls            #0x6bc57c
    // 0x6bc4c0: ldr             x0, [fp, #0x18]
    // 0x6bc4c4: r2 = Null
    //     0x6bc4c4: mov             x2, NULL
    // 0x6bc4c8: r1 = Null
    //     0x6bc4c8: mov             x1, NULL
    // 0x6bc4cc: r4 = 59
    //     0x6bc4cc: mov             x4, #0x3b
    // 0x6bc4d0: branchIfSmi(r0, 0x6bc4dc)
    //     0x6bc4d0: tbz             w0, #0, #0x6bc4dc
    // 0x6bc4d4: r4 = LoadClassIdInstr(r0)
    //     0x6bc4d4: ldur            x4, [x0, #-1]
    //     0x6bc4d8: ubfx            x4, x4, #0xc, #0x14
    // 0x6bc4dc: sub             x4, x4, #0x965
    // 0x6bc4e0: cmp             x4, #0x8b
    // 0x6bc4e4: b.ls            #0x6bc4fc
    // 0x6bc4e8: r8 = RenderBox
    //     0x6bc4e8: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x6bc4ec: ldr             x8, [x8, #0xfa0]
    // 0x6bc4f0: r3 = Null
    //     0x6bc4f0: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3fc50] Null
    //     0x6bc4f4: ldr             x3, [x3, #0xc50]
    // 0x6bc4f8: r0 = RenderBox()
    //     0x6bc4f8: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x6bc4fc: ldr             x0, [fp, #0x20]
    // 0x6bc500: LoadField: r1 = r0->field_63
    //     0x6bc500: ldur            w1, [x0, #0x63]
    // 0x6bc504: DecompressPointer r1
    //     0x6bc504: add             x1, x1, HEAP, lsl #32
    // 0x6bc508: LoadField: d0 = r1->field_7
    //     0x6bc508: ldur            d0, [x1, #7]
    // 0x6bc50c: LoadField: r2 = r0->field_57
    //     0x6bc50c: ldur            w2, [x0, #0x57]
    // 0x6bc510: DecompressPointer r2
    //     0x6bc510: add             x2, x2, HEAP, lsl #32
    // 0x6bc514: cmp             w2, NULL
    // 0x6bc518: b.eq            #0x6bc584
    // 0x6bc51c: LoadField: d1 = r2->field_7
    //     0x6bc51c: ldur            d1, [x2, #7]
    // 0x6bc520: fmul            d2, d0, d1
    // 0x6bc524: LoadField: d0 = r1->field_f
    //     0x6bc524: ldur            d0, [x1, #0xf]
    // 0x6bc528: LoadField: d1 = r2->field_f
    //     0x6bc528: ldur            d1, [x2, #0xf]
    // 0x6bc52c: fmul            d3, d0, d1
    // 0x6bc530: r0 = inline_Allocate_Double()
    //     0x6bc530: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6bc534: add             x0, x0, #0x10
    //     0x6bc538: cmp             x1, x0
    //     0x6bc53c: b.ls            #0x6bc588
    //     0x6bc540: str             x0, [THR, #0x60]  ; THR::top
    //     0x6bc544: sub             x0, x0, #0xf
    //     0x6bc548: mov             x1, #0xd108
    //     0x6bc54c: movk            x1, #3, lsl #16
    //     0x6bc550: stur            x1, [x0, #-1]
    // 0x6bc554: StoreField: r0->field_7 = d2
    //     0x6bc554: stur            d2, [x0, #7]
    // 0x6bc558: ldr             x16, [fp, #0x10]
    // 0x6bc55c: stp             x0, x16, [SP, #-0x10]!
    // 0x6bc560: SaveReg d3
    //     0x6bc560: str             d3, [SP, #-8]!
    // 0x6bc564: r0 = translate()
    //     0x6bc564: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0x6bc568: add             SP, SP, #0x18
    // 0x6bc56c: r0 = Null
    //     0x6bc56c: mov             x0, NULL
    // 0x6bc570: LeaveFrame
    //     0x6bc570: mov             SP, fp
    //     0x6bc574: ldp             fp, lr, [SP], #0x10
    // 0x6bc578: ret
    //     0x6bc578: ret             
    // 0x6bc57c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bc57c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bc580: b               #0x6bc4c0
    // 0x6bc584: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6bc584: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6bc588: stp             q2, q3, [SP, #-0x20]!
    // 0x6bc58c: r0 = AllocateDouble()
    //     0x6bc58c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6bc590: ldp             q2, q3, [SP], #0x20
    // 0x6bc594: b               #0x6bc554
  }
  set _ translation=(/* No info */) {
    // ** addr: 0x6c5260, size: 0x9c
    // 0x6c5260: EnterFrame
    //     0x6c5260: stp             fp, lr, [SP, #-0x10]!
    //     0x6c5264: mov             fp, SP
    // 0x6c5268: CheckStackOverflow
    //     0x6c5268: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c526c: cmp             SP, x16
    //     0x6c5270: b.ls            #0x6c52f4
    // 0x6c5274: ldr             x0, [fp, #0x18]
    // 0x6c5278: LoadField: r1 = r0->field_63
    //     0x6c5278: ldur            w1, [x0, #0x63]
    // 0x6c527c: DecompressPointer r1
    //     0x6c527c: add             x1, x1, HEAP, lsl #32
    // 0x6c5280: ldr             x16, [fp, #0x10]
    // 0x6c5284: stp             x16, x1, [SP, #-0x10]!
    // 0x6c5288: r0 = ==()
    //     0x6c5288: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0x6c528c: add             SP, SP, #0x10
    // 0x6c5290: tbnz            w0, #4, #0x6c52a4
    // 0x6c5294: r0 = Null
    //     0x6c5294: mov             x0, NULL
    // 0x6c5298: LeaveFrame
    //     0x6c5298: mov             SP, fp
    //     0x6c529c: ldp             fp, lr, [SP], #0x10
    // 0x6c52a0: ret
    //     0x6c52a0: ret             
    // 0x6c52a4: ldr             x1, [fp, #0x18]
    // 0x6c52a8: ldr             x0, [fp, #0x10]
    // 0x6c52ac: StoreField: r1->field_63 = r0
    //     0x6c52ac: stur            w0, [x1, #0x63]
    //     0x6c52b0: ldurb           w16, [x1, #-1]
    //     0x6c52b4: ldurb           w17, [x0, #-1]
    //     0x6c52b8: and             x16, x17, x16, lsr #2
    //     0x6c52bc: tst             x16, HEAP, lsr #32
    //     0x6c52c0: b.eq            #0x6c52c8
    //     0x6c52c4: bl              #0xd6826c
    // 0x6c52c8: SaveReg r1
    //     0x6c52c8: str             x1, [SP, #-8]!
    // 0x6c52cc: r0 = markNeedsPaint()
    //     0x6c52cc: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c52d0: add             SP, SP, #8
    // 0x6c52d4: ldr             x16, [fp, #0x18]
    // 0x6c52d8: SaveReg r16
    //     0x6c52d8: str             x16, [SP, #-8]!
    // 0x6c52dc: r0 = markNeedsSemanticsUpdate()
    //     0x6c52dc: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6c52e0: add             SP, SP, #8
    // 0x6c52e4: r0 = Null
    //     0x6c52e4: mov             x0, NULL
    // 0x6c52e8: LeaveFrame
    //     0x6c52e8: mov             SP, fp
    //     0x6c52ec: ldp             fp, lr, [SP], #0x10
    // 0x6c52f0: ret
    //     0x6c52f0: ret             
    // 0x6c52f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c52f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c52f8: b               #0x6c5274
  }
}

// class id: 2493, size: 0x80, field offset: 0x64
class RenderFittedBox extends RenderProxyBox {

  _ hitTestChildren(/* No info */) {
    // ** addr: 0x62640c, size: 0x140
    // 0x62640c: EnterFrame
    //     0x62640c: stp             fp, lr, [SP, #-0x10]!
    //     0x626410: mov             fp, SP
    // 0x626414: AllocStack(0x10)
    //     0x626414: sub             SP, SP, #0x10
    // 0x626418: CheckStackOverflow
    //     0x626418: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62641c: cmp             SP, x16
    //     0x626420: b.ls            #0x62653c
    // 0x626424: r1 = 1
    //     0x626424: mov             x1, #1
    // 0x626428: r0 = AllocateContext()
    //     0x626428: bl              #0xd68aa4  ; AllocateContextStub
    // 0x62642c: mov             x1, x0
    // 0x626430: ldr             x0, [fp, #0x20]
    // 0x626434: stur            x1, [fp, #-8]
    // 0x626438: StoreField: r1->field_f = r0
    //     0x626438: stur            w0, [x1, #0xf]
    // 0x62643c: LoadField: r2 = r0->field_57
    //     0x62643c: ldur            w2, [x0, #0x57]
    // 0x626440: DecompressPointer r2
    //     0x626440: add             x2, x2, HEAP, lsl #32
    // 0x626444: cmp             w2, NULL
    // 0x626448: b.eq            #0x626544
    // 0x62644c: LoadField: d0 = r2->field_7
    //     0x62644c: ldur            d0, [x2, #7]
    // 0x626450: d1 = 0.000000
    //     0x626450: eor             v1.16b, v1.16b, v1.16b
    // 0x626454: fcmp            d0, d1
    // 0x626458: b.vs            #0x626460
    // 0x62645c: b.le            #0x6264d8
    // 0x626460: LoadField: d0 = r2->field_f
    //     0x626460: ldur            d0, [x2, #0xf]
    // 0x626464: fcmp            d0, d1
    // 0x626468: b.vs            #0x626470
    // 0x62646c: b.le            #0x6264d8
    // 0x626470: LoadField: r2 = r0->field_5f
    //     0x626470: ldur            w2, [x0, #0x5f]
    // 0x626474: DecompressPointer r2
    //     0x626474: add             x2, x2, HEAP, lsl #32
    // 0x626478: cmp             w2, NULL
    // 0x62647c: b.ne            #0x626488
    // 0x626480: r2 = Null
    //     0x626480: mov             x2, NULL
    // 0x626484: b               #0x6264cc
    // 0x626488: LoadField: r3 = r2->field_57
    //     0x626488: ldur            w3, [x2, #0x57]
    // 0x62648c: DecompressPointer r3
    //     0x62648c: add             x3, x3, HEAP, lsl #32
    // 0x626490: cmp             w3, NULL
    // 0x626494: b.eq            #0x626548
    // 0x626498: LoadField: d0 = r3->field_7
    //     0x626498: ldur            d0, [x3, #7]
    // 0x62649c: fcmp            d0, d1
    // 0x6264a0: b.vs            #0x6264b0
    // 0x6264a4: b.gt            #0x6264b0
    // 0x6264a8: r2 = true
    //     0x6264a8: add             x2, NULL, #0x20  ; true
    // 0x6264ac: b               #0x6264cc
    // 0x6264b0: LoadField: d0 = r3->field_f
    //     0x6264b0: ldur            d0, [x3, #0xf]
    // 0x6264b4: fcmp            d0, d1
    // 0x6264b8: b.vs            #0x6264c0
    // 0x6264bc: b.le            #0x6264c8
    // 0x6264c0: r2 = false
    //     0x6264c0: add             x2, NULL, #0x30  ; false
    // 0x6264c4: b               #0x6264cc
    // 0x6264c8: r2 = true
    //     0x6264c8: add             x2, NULL, #0x20  ; true
    // 0x6264cc: cmp             w2, NULL
    // 0x6264d0: b.eq            #0x6264e8
    // 0x6264d4: tbnz            w2, #4, #0x6264e8
    // 0x6264d8: r0 = false
    //     0x6264d8: add             x0, NULL, #0x30  ; false
    // 0x6264dc: LeaveFrame
    //     0x6264dc: mov             SP, fp
    //     0x6264e0: ldp             fp, lr, [SP], #0x10
    // 0x6264e4: ret
    //     0x6264e4: ret             
    // 0x6264e8: SaveReg r0
    //     0x6264e8: str             x0, [SP, #-8]!
    // 0x6264ec: r0 = _updatePaintData()
    //     0x6264ec: bl              #0x62654c  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_updatePaintData
    // 0x6264f0: add             SP, SP, #8
    // 0x6264f4: ldr             x0, [fp, #0x20]
    // 0x6264f8: LoadField: r3 = r0->field_77
    //     0x6264f8: ldur            w3, [x0, #0x77]
    // 0x6264fc: DecompressPointer r3
    //     0x6264fc: add             x3, x3, HEAP, lsl #32
    // 0x626500: ldur            x2, [fp, #-8]
    // 0x626504: stur            x3, [fp, #-0x10]
    // 0x626508: r1 = Function '<anonymous closure>':.
    //     0x626508: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4fd50] AnonymousClosure: (0x6263b8), in [package:flutter/src/rendering/proxy_box.dart] RenderTransform::hitTestChildren (0x625518)
    //     0x62650c: ldr             x1, [x1, #0xd50]
    // 0x626510: r0 = AllocateClosure()
    //     0x626510: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x626514: ldr             x16, [fp, #0x18]
    // 0x626518: stp             x0, x16, [SP, #-0x10]!
    // 0x62651c: ldr             x16, [fp, #0x10]
    // 0x626520: ldur            lr, [fp, #-0x10]
    // 0x626524: stp             lr, x16, [SP, #-0x10]!
    // 0x626528: r0 = addWithPaintTransform()
    //     0x626528: bl              #0x622f04  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithPaintTransform
    // 0x62652c: add             SP, SP, #0x20
    // 0x626530: LeaveFrame
    //     0x626530: mov             SP, fp
    //     0x626534: ldp             fp, lr, [SP], #0x10
    // 0x626538: ret
    //     0x626538: ret             
    // 0x62653c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62653c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x626540: b               #0x626424
    // 0x626544: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x626544: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x626548: r0 = NullCastErrorSharedWithFPURegs()
    //     0x626548: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _updatePaintData(/* No info */) {
    // ** addr: 0x62654c, size: 0x414
    // 0x62654c: EnterFrame
    //     0x62654c: stp             fp, lr, [SP, #-0x10]!
    //     0x626550: mov             fp, SP
    // 0x626554: AllocStack(0x38)
    //     0x626554: sub             SP, SP, #0x38
    // 0x626558: CheckStackOverflow
    //     0x626558: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62655c: cmp             SP, x16
    //     0x626560: b.ls            #0x6268cc
    // 0x626564: ldr             x0, [fp, #0x10]
    // 0x626568: LoadField: r1 = r0->field_77
    //     0x626568: ldur            w1, [x0, #0x77]
    // 0x62656c: DecompressPointer r1
    //     0x62656c: add             x1, x1, HEAP, lsl #32
    // 0x626570: cmp             w1, NULL
    // 0x626574: b.eq            #0x626588
    // 0x626578: r0 = Null
    //     0x626578: mov             x0, NULL
    // 0x62657c: LeaveFrame
    //     0x62657c: mov             SP, fp
    //     0x626580: ldp             fp, lr, [SP], #0x10
    // 0x626584: ret
    //     0x626584: ret             
    // 0x626588: LoadField: r1 = r0->field_5f
    //     0x626588: ldur            w1, [x0, #0x5f]
    // 0x62658c: DecompressPointer r1
    //     0x62658c: add             x1, x1, HEAP, lsl #32
    // 0x626590: cmp             w1, NULL
    // 0x626594: b.ne            #0x6265f0
    // 0x626598: r1 = false
    //     0x626598: add             x1, NULL, #0x30  ; false
    // 0x62659c: StoreField: r0->field_73 = r1
    //     0x62659c: stur            w1, [x0, #0x73]
    // 0x6265a0: r0 = Matrix4()
    //     0x6265a0: bl              #0x50ace8  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x6265a4: r4 = 32
    //     0x6265a4: mov             x4, #0x20
    // 0x6265a8: stur            x0, [fp, #-8]
    // 0x6265ac: r0 = AllocateFloat64Array()
    //     0x6265ac: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0x6265b0: mov             x1, x0
    // 0x6265b4: ldur            x0, [fp, #-8]
    // 0x6265b8: StoreField: r0->field_7 = r1
    //     0x6265b8: stur            w1, [x0, #7]
    // 0x6265bc: SaveReg r0
    //     0x6265bc: str             x0, [SP, #-8]!
    // 0x6265c0: r0 = setIdentity()
    //     0x6265c0: bl              #0x50f090  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0x6265c4: add             SP, SP, #8
    // 0x6265c8: ldur            x0, [fp, #-8]
    // 0x6265cc: ldr             x1, [fp, #0x10]
    // 0x6265d0: StoreField: r1->field_77 = r0
    //     0x6265d0: stur            w0, [x1, #0x77]
    //     0x6265d4: ldurb           w16, [x1, #-1]
    //     0x6265d8: ldurb           w17, [x0, #-1]
    //     0x6265dc: and             x16, x17, x16, lsr #2
    //     0x6265e0: tst             x16, HEAP, lsr #32
    //     0x6265e4: b.eq            #0x6265ec
    //     0x6265e8: bl              #0xd6826c
    // 0x6265ec: b               #0x6268bc
    // 0x6265f0: mov             x1, x0
    // 0x6265f4: SaveReg r1
    //     0x6265f4: str             x1, [SP, #-8]!
    // 0x6265f8: r0 = _resolve()
    //     0x6265f8: bl              #0x626f10  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_resolve
    // 0x6265fc: add             SP, SP, #8
    // 0x626600: ldr             x0, [fp, #0x10]
    // 0x626604: LoadField: r1 = r0->field_5f
    //     0x626604: ldur            w1, [x0, #0x5f]
    // 0x626608: DecompressPointer r1
    //     0x626608: add             x1, x1, HEAP, lsl #32
    // 0x62660c: cmp             w1, NULL
    // 0x626610: b.eq            #0x6268d4
    // 0x626614: LoadField: r2 = r1->field_57
    //     0x626614: ldur            w2, [x1, #0x57]
    // 0x626618: DecompressPointer r2
    //     0x626618: add             x2, x2, HEAP, lsl #32
    // 0x62661c: stur            x2, [fp, #-8]
    // 0x626620: cmp             w2, NULL
    // 0x626624: b.eq            #0x6268d8
    // 0x626628: LoadField: r1 = r0->field_67
    //     0x626628: ldur            w1, [x0, #0x67]
    // 0x62662c: DecompressPointer r1
    //     0x62662c: add             x1, x1, HEAP, lsl #32
    // 0x626630: LoadField: r3 = r0->field_57
    //     0x626630: ldur            w3, [x0, #0x57]
    // 0x626634: DecompressPointer r3
    //     0x626634: add             x3, x3, HEAP, lsl #32
    // 0x626638: cmp             w3, NULL
    // 0x62663c: b.eq            #0x6268dc
    // 0x626640: stp             x2, x1, [SP, #-0x10]!
    // 0x626644: SaveReg r3
    //     0x626644: str             x3, [SP, #-8]!
    // 0x626648: r0 = applyBoxFit()
    //     0x626648: bl              #0x626a14  ; [package:flutter/src/painting/box_fit.dart] ::applyBoxFit
    // 0x62664c: add             SP, SP, #0x18
    // 0x626650: LoadField: r1 = r0->field_b
    //     0x626650: ldur            w1, [x0, #0xb]
    // 0x626654: DecompressPointer r1
    //     0x626654: add             x1, x1, HEAP, lsl #32
    // 0x626658: stur            x1, [fp, #-0x20]
    // 0x62665c: LoadField: d0 = r1->field_7
    //     0x62665c: ldur            d0, [x1, #7]
    // 0x626660: LoadField: r2 = r0->field_7
    //     0x626660: ldur            w2, [x0, #7]
    // 0x626664: DecompressPointer r2
    //     0x626664: add             x2, x2, HEAP, lsl #32
    // 0x626668: stur            x2, [fp, #-0x18]
    // 0x62666c: LoadField: d1 = r2->field_7
    //     0x62666c: ldur            d1, [x2, #7]
    // 0x626670: fdiv            d2, d0, d1
    // 0x626674: stur            d2, [fp, #-0x30]
    // 0x626678: LoadField: d0 = r1->field_f
    //     0x626678: ldur            d0, [x1, #0xf]
    // 0x62667c: LoadField: d1 = r2->field_f
    //     0x62667c: ldur            d1, [x2, #0xf]
    // 0x626680: fdiv            d3, d0, d1
    // 0x626684: ldr             x0, [fp, #0x10]
    // 0x626688: stur            d3, [fp, #-0x28]
    // 0x62668c: LoadField: r3 = r0->field_63
    //     0x62668c: ldur            w3, [x0, #0x63]
    // 0x626690: DecompressPointer r3
    //     0x626690: add             x3, x3, HEAP, lsl #32
    // 0x626694: stur            x3, [fp, #-0x10]
    // 0x626698: cmp             w3, NULL
    // 0x62669c: b.eq            #0x6268e0
    // 0x6266a0: r16 = Instance_Offset
    //     0x6266a0: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x6266a4: ldur            lr, [fp, #-8]
    // 0x6266a8: stp             lr, x16, [SP, #-0x10]!
    // 0x6266ac: r0 = &()
    //     0x6266ac: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x6266b0: add             SP, SP, #0x10
    // 0x6266b4: ldur            x16, [fp, #-0x10]
    // 0x6266b8: ldur            lr, [fp, #-0x18]
    // 0x6266bc: stp             lr, x16, [SP, #-0x10]!
    // 0x6266c0: SaveReg r0
    //     0x6266c0: str             x0, [SP, #-8]!
    // 0x6266c4: r0 = inscribe()
    //     0x6266c4: bl              #0x626960  ; [package:flutter/src/painting/alignment.dart] Alignment::inscribe
    // 0x6266c8: add             SP, SP, #0x18
    // 0x6266cc: mov             x1, x0
    // 0x6266d0: ldr             x0, [fp, #0x10]
    // 0x6266d4: stur            x1, [fp, #-0x18]
    // 0x6266d8: LoadField: r2 = r0->field_63
    //     0x6266d8: ldur            w2, [x0, #0x63]
    // 0x6266dc: DecompressPointer r2
    //     0x6266dc: add             x2, x2, HEAP, lsl #32
    // 0x6266e0: stur            x2, [fp, #-0x10]
    // 0x6266e4: cmp             w2, NULL
    // 0x6266e8: b.eq            #0x6268e4
    // 0x6266ec: LoadField: r3 = r0->field_57
    //     0x6266ec: ldur            w3, [x0, #0x57]
    // 0x6266f0: DecompressPointer r3
    //     0x6266f0: add             x3, x3, HEAP, lsl #32
    // 0x6266f4: cmp             w3, NULL
    // 0x6266f8: b.eq            #0x6268e8
    // 0x6266fc: r16 = Instance_Offset
    //     0x6266fc: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x626700: stp             x3, x16, [SP, #-0x10]!
    // 0x626704: r0 = &()
    //     0x626704: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x626708: add             SP, SP, #0x10
    // 0x62670c: ldur            x16, [fp, #-0x10]
    // 0x626710: ldur            lr, [fp, #-0x20]
    // 0x626714: stp             lr, x16, [SP, #-0x10]!
    // 0x626718: SaveReg r0
    //     0x626718: str             x0, [SP, #-8]!
    // 0x62671c: r0 = inscribe()
    //     0x62671c: bl              #0x626960  ; [package:flutter/src/painting/alignment.dart] Alignment::inscribe
    // 0x626720: add             SP, SP, #0x18
    // 0x626724: mov             x1, x0
    // 0x626728: ldur            x0, [fp, #-0x18]
    // 0x62672c: LoadField: d0 = r0->field_17
    //     0x62672c: ldur            d0, [x0, #0x17]
    // 0x626730: LoadField: d1 = r0->field_7
    //     0x626730: ldur            d1, [x0, #7]
    // 0x626734: stur            d1, [fp, #-0x38]
    // 0x626738: fsub            d2, d0, d1
    // 0x62673c: ldur            x2, [fp, #-8]
    // 0x626740: LoadField: d0 = r2->field_7
    //     0x626740: ldur            d0, [x2, #7]
    // 0x626744: fcmp            d2, d0
    // 0x626748: b.vs            #0x626758
    // 0x62674c: b.ge            #0x626758
    // 0x626750: r3 = true
    //     0x626750: add             x3, NULL, #0x20  ; true
    // 0x626754: b               #0x626784
    // 0x626758: LoadField: d0 = r0->field_1f
    //     0x626758: ldur            d0, [x0, #0x1f]
    // 0x62675c: LoadField: d2 = r0->field_f
    //     0x62675c: ldur            d2, [x0, #0xf]
    // 0x626760: fsub            d3, d0, d2
    // 0x626764: LoadField: d0 = r2->field_f
    //     0x626764: ldur            d0, [x2, #0xf]
    // 0x626768: fcmp            d3, d0
    // 0x62676c: b.vs            #0x626774
    // 0x626770: b.lt            #0x62677c
    // 0x626774: r2 = false
    //     0x626774: add             x2, NULL, #0x30  ; false
    // 0x626778: b               #0x626780
    // 0x62677c: r2 = true
    //     0x62677c: add             x2, NULL, #0x20  ; true
    // 0x626780: mov             x3, x2
    // 0x626784: ldr             x2, [fp, #0x10]
    // 0x626788: ldur            d0, [fp, #-0x30]
    // 0x62678c: ldur            d2, [fp, #-0x28]
    // 0x626790: StoreField: r2->field_73 = r3
    //     0x626790: stur            w3, [x2, #0x73]
    // 0x626794: LoadField: d3 = r1->field_7
    //     0x626794: ldur            d3, [x1, #7]
    // 0x626798: LoadField: d4 = r1->field_f
    //     0x626798: ldur            d4, [x1, #0xf]
    // 0x62679c: r1 = inline_Allocate_Double()
    //     0x62679c: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x6267a0: add             x1, x1, #0x10
    //     0x6267a4: cmp             x3, x1
    //     0x6267a8: b.ls            #0x6268ec
    //     0x6267ac: str             x1, [THR, #0x60]  ; THR::top
    //     0x6267b0: sub             x1, x1, #0xf
    //     0x6267b4: mov             x3, #0xd108
    //     0x6267b8: movk            x3, #3, lsl #16
    //     0x6267bc: stur            x3, [x1, #-1]
    // 0x6267c0: StoreField: r1->field_7 = d3
    //     0x6267c0: stur            d3, [x1, #7]
    // 0x6267c4: stp             x1, NULL, [SP, #-0x10]!
    // 0x6267c8: SaveReg d4
    //     0x6267c8: str             d4, [SP, #-8]!
    // 0x6267cc: r0 = Matrix4.translationValues()
    //     0x6267cc: bl              #0x6245d8  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.translationValues
    // 0x6267d0: add             SP, SP, #0x18
    // 0x6267d4: ldur            d0, [fp, #-0x30]
    // 0x6267d8: stur            x0, [fp, #-8]
    // 0x6267dc: r1 = inline_Allocate_Double()
    //     0x6267dc: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x6267e0: add             x1, x1, #0x10
    //     0x6267e4: cmp             x2, x1
    //     0x6267e8: b.ls            #0x626918
    //     0x6267ec: str             x1, [THR, #0x60]  ; THR::top
    //     0x6267f0: sub             x1, x1, #0xf
    //     0x6267f4: mov             x2, #0xd108
    //     0x6267f8: movk            x2, #3, lsl #16
    //     0x6267fc: stur            x2, [x1, #-1]
    // 0x626800: StoreField: r1->field_7 = d0
    //     0x626800: stur            d0, [x1, #7]
    // 0x626804: ldur            d0, [fp, #-0x28]
    // 0x626808: r2 = inline_Allocate_Double()
    //     0x626808: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x62680c: add             x2, x2, #0x10
    //     0x626810: cmp             x3, x2
    //     0x626814: b.ls            #0x626934
    //     0x626818: str             x2, [THR, #0x60]  ; THR::top
    //     0x62681c: sub             x2, x2, #0xf
    //     0x626820: mov             x3, #0xd108
    //     0x626824: movk            x3, #3, lsl #16
    //     0x626828: stur            x3, [x2, #-1]
    // 0x62682c: StoreField: r2->field_7 = d0
    //     0x62682c: stur            d0, [x2, #7]
    // 0x626830: stp             x1, x0, [SP, #-0x10]!
    // 0x626834: r16 = 1.000000
    //     0x626834: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x626838: stp             x16, x2, [SP, #-0x10]!
    // 0x62683c: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x62683c: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x626840: r0 = scale()
    //     0x626840: bl              #0x50b298  ; [package:vector_math/vector_math_64.dart] Matrix4::scale
    // 0x626844: add             SP, SP, #0x20
    // 0x626848: ldur            d0, [fp, #-0x38]
    // 0x62684c: fneg            d1, d0
    // 0x626850: ldur            x0, [fp, #-0x18]
    // 0x626854: LoadField: d0 = r0->field_f
    //     0x626854: ldur            d0, [x0, #0xf]
    // 0x626858: fneg            d2, d0
    // 0x62685c: r0 = inline_Allocate_Double()
    //     0x62685c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x626860: add             x0, x0, #0x10
    //     0x626864: cmp             x1, x0
    //     0x626868: b.ls            #0x626950
    //     0x62686c: str             x0, [THR, #0x60]  ; THR::top
    //     0x626870: sub             x0, x0, #0xf
    //     0x626874: mov             x1, #0xd108
    //     0x626878: movk            x1, #3, lsl #16
    //     0x62687c: stur            x1, [x0, #-1]
    // 0x626880: StoreField: r0->field_7 = d1
    //     0x626880: stur            d1, [x0, #7]
    // 0x626884: ldur            x16, [fp, #-8]
    // 0x626888: stp             x0, x16, [SP, #-0x10]!
    // 0x62688c: SaveReg d2
    //     0x62688c: str             d2, [SP, #-8]!
    // 0x626890: r0 = translate()
    //     0x626890: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0x626894: add             SP, SP, #0x18
    // 0x626898: ldur            x0, [fp, #-8]
    // 0x62689c: ldr             x1, [fp, #0x10]
    // 0x6268a0: StoreField: r1->field_77 = r0
    //     0x6268a0: stur            w0, [x1, #0x77]
    //     0x6268a4: ldurb           w16, [x1, #-1]
    //     0x6268a8: ldurb           w17, [x0, #-1]
    //     0x6268ac: and             x16, x17, x16, lsr #2
    //     0x6268b0: tst             x16, HEAP, lsr #32
    //     0x6268b4: b.eq            #0x6268bc
    //     0x6268b8: bl              #0xd6826c
    // 0x6268bc: r0 = Null
    //     0x6268bc: mov             x0, NULL
    // 0x6268c0: LeaveFrame
    //     0x6268c0: mov             SP, fp
    //     0x6268c4: ldp             fp, lr, [SP], #0x10
    // 0x6268c8: ret
    //     0x6268c8: ret             
    // 0x6268cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6268cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6268d0: b               #0x626564
    // 0x6268d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6268d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6268d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6268d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6268dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6268dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6268e0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6268e0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6268e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6268e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6268e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6268e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6268ec: stp             q3, q4, [SP, #-0x20]!
    // 0x6268f0: stp             q1, q2, [SP, #-0x20]!
    // 0x6268f4: SaveReg d0
    //     0x6268f4: str             q0, [SP, #-0x10]!
    // 0x6268f8: stp             x0, x2, [SP, #-0x10]!
    // 0x6268fc: r0 = AllocateDouble()
    //     0x6268fc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x626900: mov             x1, x0
    // 0x626904: ldp             x0, x2, [SP], #0x10
    // 0x626908: RestoreReg d0
    //     0x626908: ldr             q0, [SP], #0x10
    // 0x62690c: ldp             q1, q2, [SP], #0x20
    // 0x626910: ldp             q3, q4, [SP], #0x20
    // 0x626914: b               #0x6267c0
    // 0x626918: SaveReg d0
    //     0x626918: str             q0, [SP, #-0x10]!
    // 0x62691c: SaveReg r0
    //     0x62691c: str             x0, [SP, #-8]!
    // 0x626920: r0 = AllocateDouble()
    //     0x626920: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x626924: mov             x1, x0
    // 0x626928: RestoreReg r0
    //     0x626928: ldr             x0, [SP], #8
    // 0x62692c: RestoreReg d0
    //     0x62692c: ldr             q0, [SP], #0x10
    // 0x626930: b               #0x626800
    // 0x626934: SaveReg d0
    //     0x626934: str             q0, [SP, #-0x10]!
    // 0x626938: stp             x0, x1, [SP, #-0x10]!
    // 0x62693c: r0 = AllocateDouble()
    //     0x62693c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x626940: mov             x2, x0
    // 0x626944: ldp             x0, x1, [SP], #0x10
    // 0x626948: RestoreReg d0
    //     0x626948: ldr             q0, [SP], #0x10
    // 0x62694c: b               #0x62682c
    // 0x626950: stp             q1, q2, [SP, #-0x20]!
    // 0x626954: r0 = AllocateDouble()
    //     0x626954: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x626958: ldp             q1, q2, [SP], #0x20
    // 0x62695c: b               #0x626880
  }
  _ _resolve(/* No info */) {
    // ** addr: 0x626f10, size: 0x19c
    // 0x626f10: EnterFrame
    //     0x626f10: stp             fp, lr, [SP, #-0x10]!
    //     0x626f14: mov             fp, SP
    // 0x626f18: AllocStack(0x10)
    //     0x626f18: sub             SP, SP, #0x10
    // 0x626f1c: ldr             x0, [fp, #0x10]
    // 0x626f20: LoadField: r1 = r0->field_63
    //     0x626f20: ldur            w1, [x0, #0x63]
    // 0x626f24: DecompressPointer r1
    //     0x626f24: add             x1, x1, HEAP, lsl #32
    // 0x626f28: cmp             w1, NULL
    // 0x626f2c: b.eq            #0x626f40
    // 0x626f30: r0 = Null
    //     0x626f30: mov             x0, NULL
    // 0x626f34: LeaveFrame
    //     0x626f34: mov             SP, fp
    //     0x626f38: ldp             fp, lr, [SP], #0x10
    // 0x626f3c: ret
    //     0x626f3c: ret             
    // 0x626f40: LoadField: r1 = r0->field_6b
    //     0x626f40: ldur            w1, [x0, #0x6b]
    // 0x626f44: DecompressPointer r1
    //     0x626f44: add             x1, x1, HEAP, lsl #32
    // 0x626f48: LoadField: r2 = r0->field_6f
    //     0x626f48: ldur            w2, [x0, #0x6f]
    // 0x626f4c: DecompressPointer r2
    //     0x626f4c: add             x2, x2, HEAP, lsl #32
    // 0x626f50: r3 = LoadClassIdInstr(r1)
    //     0x626f50: ldur            x3, [x1, #-1]
    //     0x626f54: ubfx            x3, x3, #0xc, #0x14
    // 0x626f58: lsl             x3, x3, #1
    // 0x626f5c: r17 = 4240
    //     0x626f5c: mov             x17, #0x1090
    // 0x626f60: cmp             w3, w17
    // 0x626f64: b.gt            #0x626f84
    // 0x626f68: r17 = 4238
    //     0x626f68: mov             x17, #0x108e
    // 0x626f6c: cmp             w3, w17
    // 0x626f70: b.lt            #0x626f84
    // 0x626f74: mov             x16, x0
    // 0x626f78: mov             x0, x1
    // 0x626f7c: mov             x1, x16
    // 0x626f80: b               #0x627078
    // 0x626f84: r17 = 4234
    //     0x626f84: mov             x17, #0x108a
    // 0x626f88: cmp             w3, w17
    // 0x626f8c: b.ne            #0x62700c
    // 0x626f90: cmp             w2, NULL
    // 0x626f94: b.eq            #0x6270a4
    // 0x626f98: LoadField: r3 = r2->field_7
    //     0x626f98: ldur            x3, [x2, #7]
    // 0x626f9c: cmp             x3, #0
    // 0x626fa0: b.gt            #0x626fd8
    // 0x626fa4: LoadField: d0 = r1->field_7
    //     0x626fa4: ldur            d0, [x1, #7]
    // 0x626fa8: LoadField: d1 = r1->field_f
    //     0x626fa8: ldur            d1, [x1, #0xf]
    // 0x626fac: fsub            d2, d0, d1
    // 0x626fb0: stur            d2, [fp, #-0x10]
    // 0x626fb4: LoadField: d0 = r1->field_17
    //     0x626fb4: ldur            d0, [x1, #0x17]
    // 0x626fb8: stur            d0, [fp, #-8]
    // 0x626fbc: r0 = Alignment()
    //     0x626fbc: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x626fc0: ldur            d0, [fp, #-0x10]
    // 0x626fc4: StoreField: r0->field_7 = d0
    //     0x626fc4: stur            d0, [x0, #7]
    // 0x626fc8: ldur            d0, [fp, #-8]
    // 0x626fcc: StoreField: r0->field_f = d0
    //     0x626fcc: stur            d0, [x0, #0xf]
    // 0x626fd0: ldr             x1, [fp, #0x10]
    // 0x626fd4: b               #0x627078
    // 0x626fd8: LoadField: d0 = r1->field_7
    //     0x626fd8: ldur            d0, [x1, #7]
    // 0x626fdc: LoadField: d1 = r1->field_f
    //     0x626fdc: ldur            d1, [x1, #0xf]
    // 0x626fe0: fadd            d2, d0, d1
    // 0x626fe4: stur            d2, [fp, #-0x10]
    // 0x626fe8: LoadField: d0 = r1->field_17
    //     0x626fe8: ldur            d0, [x1, #0x17]
    // 0x626fec: stur            d0, [fp, #-8]
    // 0x626ff0: r0 = Alignment()
    //     0x626ff0: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x626ff4: ldur            d0, [fp, #-0x10]
    // 0x626ff8: StoreField: r0->field_7 = d0
    //     0x626ff8: stur            d0, [x0, #7]
    // 0x626ffc: ldur            d0, [fp, #-8]
    // 0x627000: StoreField: r0->field_f = d0
    //     0x627000: stur            d0, [x0, #0xf]
    // 0x627004: ldr             x1, [fp, #0x10]
    // 0x627008: b               #0x627078
    // 0x62700c: cmp             w2, NULL
    // 0x627010: b.eq            #0x6270a8
    // 0x627014: LoadField: r0 = r2->field_7
    //     0x627014: ldur            x0, [x2, #7]
    // 0x627018: cmp             x0, #0
    // 0x62701c: b.gt            #0x627050
    // 0x627020: LoadField: d0 = r1->field_7
    //     0x627020: ldur            d0, [x1, #7]
    // 0x627024: fneg            d1, d0
    // 0x627028: stur            d1, [fp, #-0x10]
    // 0x62702c: LoadField: d0 = r1->field_f
    //     0x62702c: ldur            d0, [x1, #0xf]
    // 0x627030: stur            d0, [fp, #-8]
    // 0x627034: r0 = Alignment()
    //     0x627034: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x627038: ldur            d0, [fp, #-0x10]
    // 0x62703c: StoreField: r0->field_7 = d0
    //     0x62703c: stur            d0, [x0, #7]
    // 0x627040: ldur            d0, [fp, #-8]
    // 0x627044: StoreField: r0->field_f = d0
    //     0x627044: stur            d0, [x0, #0xf]
    // 0x627048: ldr             x1, [fp, #0x10]
    // 0x62704c: b               #0x627078
    // 0x627050: LoadField: d0 = r1->field_7
    //     0x627050: ldur            d0, [x1, #7]
    // 0x627054: stur            d0, [fp, #-0x10]
    // 0x627058: LoadField: d1 = r1->field_f
    //     0x627058: ldur            d1, [x1, #0xf]
    // 0x62705c: stur            d1, [fp, #-8]
    // 0x627060: r0 = Alignment()
    //     0x627060: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x627064: ldur            d0, [fp, #-0x10]
    // 0x627068: StoreField: r0->field_7 = d0
    //     0x627068: stur            d0, [x0, #7]
    // 0x62706c: ldur            d0, [fp, #-8]
    // 0x627070: StoreField: r0->field_f = d0
    //     0x627070: stur            d0, [x0, #0xf]
    // 0x627074: ldr             x1, [fp, #0x10]
    // 0x627078: StoreField: r1->field_63 = r0
    //     0x627078: stur            w0, [x1, #0x63]
    //     0x62707c: ldurb           w16, [x1, #-1]
    //     0x627080: ldurb           w17, [x0, #-1]
    //     0x627084: and             x16, x17, x16, lsr #2
    //     0x627088: tst             x16, HEAP, lsr #32
    //     0x62708c: b.eq            #0x627094
    //     0x627090: bl              #0xd6826c
    // 0x627094: r0 = Null
    //     0x627094: mov             x0, NULL
    // 0x627098: LeaveFrame
    //     0x627098: mov             SP, fp
    //     0x62709c: ldp             fp, lr, [SP], #0x10
    // 0x6270a0: ret
    //     0x6270a0: ret             
    // 0x6270a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6270a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6270a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6270a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paintsChild(/* No info */) {
    // ** addr: 0x64171c, size: 0xf8
    // 0x64171c: EnterFrame
    //     0x64171c: stp             fp, lr, [SP, #-0x10]!
    //     0x641720: mov             fp, SP
    // 0x641724: ldr             x0, [fp, #0x10]
    // 0x641728: r2 = Null
    //     0x641728: mov             x2, NULL
    // 0x64172c: r1 = Null
    //     0x64172c: mov             x1, NULL
    // 0x641730: r4 = 59
    //     0x641730: mov             x4, #0x3b
    // 0x641734: branchIfSmi(r0, 0x641740)
    //     0x641734: tbz             w0, #0, #0x641740
    // 0x641738: r4 = LoadClassIdInstr(r0)
    //     0x641738: ldur            x4, [x0, #-1]
    //     0x64173c: ubfx            x4, x4, #0xc, #0x14
    // 0x641740: sub             x4, x4, #0x965
    // 0x641744: cmp             x4, #0x8b
    // 0x641748: b.ls            #0x641760
    // 0x64174c: r8 = RenderBox
    //     0x64174c: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x641750: ldr             x8, [x8, #0xfa0]
    // 0x641754: r3 = Null
    //     0x641754: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fd40] Null
    //     0x641758: ldr             x3, [x3, #0xd40]
    // 0x64175c: r0 = RenderBox()
    //     0x64175c: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x641760: ldr             x1, [fp, #0x18]
    // 0x641764: LoadField: r2 = r1->field_57
    //     0x641764: ldur            w2, [x1, #0x57]
    // 0x641768: DecompressPointer r2
    //     0x641768: add             x2, x2, HEAP, lsl #32
    // 0x64176c: cmp             w2, NULL
    // 0x641770: b.eq            #0x64180c
    // 0x641774: LoadField: d0 = r2->field_7
    //     0x641774: ldur            d0, [x2, #7]
    // 0x641778: d1 = 0.000000
    //     0x641778: eor             v1.16b, v1.16b, v1.16b
    // 0x64177c: fcmp            d0, d1
    // 0x641780: b.vs            #0x641788
    // 0x641784: b.le            #0x6417fc
    // 0x641788: LoadField: d0 = r2->field_f
    //     0x641788: ldur            d0, [x2, #0xf]
    // 0x64178c: fcmp            d0, d1
    // 0x641790: b.vs            #0x641798
    // 0x641794: b.le            #0x6417a0
    // 0x641798: r1 = false
    //     0x641798: add             x1, NULL, #0x30  ; false
    // 0x64179c: b               #0x6417a4
    // 0x6417a0: r1 = true
    //     0x6417a0: add             x1, NULL, #0x20  ; true
    // 0x6417a4: tbz             w1, #4, #0x6417fc
    // 0x6417a8: ldr             x1, [fp, #0x10]
    // 0x6417ac: LoadField: r2 = r1->field_57
    //     0x6417ac: ldur            w2, [x1, #0x57]
    // 0x6417b0: DecompressPointer r2
    //     0x6417b0: add             x2, x2, HEAP, lsl #32
    // 0x6417b4: cmp             w2, NULL
    // 0x6417b8: b.eq            #0x641810
    // 0x6417bc: LoadField: d0 = r2->field_7
    //     0x6417bc: ldur            d0, [x2, #7]
    // 0x6417c0: fcmp            d0, d1
    // 0x6417c4: b.vs            #0x6417d4
    // 0x6417c8: b.gt            #0x6417d4
    // 0x6417cc: r1 = true
    //     0x6417cc: add             x1, NULL, #0x20  ; true
    // 0x6417d0: b               #0x6417f0
    // 0x6417d4: LoadField: d0 = r2->field_f
    //     0x6417d4: ldur            d0, [x2, #0xf]
    // 0x6417d8: fcmp            d0, d1
    // 0x6417dc: b.vs            #0x6417e4
    // 0x6417e0: b.le            #0x6417ec
    // 0x6417e4: r1 = false
    //     0x6417e4: add             x1, NULL, #0x30  ; false
    // 0x6417e8: b               #0x6417f0
    // 0x6417ec: r1 = true
    //     0x6417ec: add             x1, NULL, #0x20  ; true
    // 0x6417f0: eor             x2, x1, #0x10
    // 0x6417f4: mov             x0, x2
    // 0x6417f8: b               #0x641800
    // 0x6417fc: r0 = false
    //     0x6417fc: add             x0, NULL, #0x30  ; false
    // 0x641800: LeaveFrame
    //     0x641800: mov             SP, fp
    //     0x641804: ldp             fp, lr, [SP], #0x10
    // 0x641808: ret
    //     0x641808: ret             
    // 0x64180c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x64180c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x641810: r0 = NullCastErrorSharedWithFPURegs()
    //     0x641810: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0x665c68, size: 0x22c
    // 0x665c68: EnterFrame
    //     0x665c68: stp             fp, lr, [SP, #-0x10]!
    //     0x665c6c: mov             fp, SP
    // 0x665c70: AllocStack(0x28)
    //     0x665c70: sub             SP, SP, #0x28
    // 0x665c74: CheckStackOverflow
    //     0x665c74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x665c78: cmp             SP, x16
    //     0x665c7c: b.ls            #0x665e74
    // 0x665c80: ldr             x0, [fp, #0x20]
    // 0x665c84: LoadField: r1 = r0->field_5f
    //     0x665c84: ldur            w1, [x0, #0x5f]
    // 0x665c88: DecompressPointer r1
    //     0x665c88: add             x1, x1, HEAP, lsl #32
    // 0x665c8c: cmp             w1, NULL
    // 0x665c90: b.eq            #0x665cf8
    // 0x665c94: d0 = 0.000000
    //     0x665c94: eor             v0.16b, v0.16b, v0.16b
    // 0x665c98: LoadField: r2 = r0->field_57
    //     0x665c98: ldur            w2, [x0, #0x57]
    // 0x665c9c: DecompressPointer r2
    //     0x665c9c: add             x2, x2, HEAP, lsl #32
    // 0x665ca0: cmp             w2, NULL
    // 0x665ca4: b.eq            #0x665e7c
    // 0x665ca8: LoadField: d1 = r2->field_7
    //     0x665ca8: ldur            d1, [x2, #7]
    // 0x665cac: fcmp            d1, d0
    // 0x665cb0: b.vs            #0x665cb8
    // 0x665cb4: b.le            #0x665cf8
    // 0x665cb8: LoadField: d1 = r2->field_f
    //     0x665cb8: ldur            d1, [x2, #0xf]
    // 0x665cbc: fcmp            d1, d0
    // 0x665cc0: b.vs            #0x665cc8
    // 0x665cc4: b.le            #0x665cf8
    // 0x665cc8: LoadField: r2 = r1->field_57
    //     0x665cc8: ldur            w2, [x1, #0x57]
    // 0x665ccc: DecompressPointer r2
    //     0x665ccc: add             x2, x2, HEAP, lsl #32
    // 0x665cd0: cmp             w2, NULL
    // 0x665cd4: b.eq            #0x665e80
    // 0x665cd8: LoadField: d1 = r2->field_7
    //     0x665cd8: ldur            d1, [x2, #7]
    // 0x665cdc: fcmp            d1, d0
    // 0x665ce0: b.vs            #0x665ce8
    // 0x665ce4: b.le            #0x665cf8
    // 0x665ce8: LoadField: d1 = r2->field_f
    //     0x665ce8: ldur            d1, [x2, #0xf]
    // 0x665cec: fcmp            d1, d0
    // 0x665cf0: b.vs            #0x665d08
    // 0x665cf4: b.gt            #0x665d08
    // 0x665cf8: r0 = Null
    //     0x665cf8: mov             x0, NULL
    // 0x665cfc: LeaveFrame
    //     0x665cfc: mov             SP, fp
    //     0x665d00: ldp             fp, lr, [SP], #0x10
    // 0x665d04: ret
    //     0x665d04: ret             
    // 0x665d08: SaveReg r0
    //     0x665d08: str             x0, [SP, #-8]!
    // 0x665d0c: r0 = _updatePaintData()
    //     0x665d0c: bl              #0x62654c  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_updatePaintData
    // 0x665d10: add             SP, SP, #8
    // 0x665d14: ldr             x0, [fp, #0x20]
    // 0x665d18: LoadField: r1 = r0->field_73
    //     0x665d18: ldur            w1, [x0, #0x73]
    // 0x665d1c: DecompressPointer r1
    //     0x665d1c: add             x1, x1, HEAP, lsl #32
    // 0x665d20: cmp             w1, NULL
    // 0x665d24: b.eq            #0x665e84
    // 0x665d28: tbnz            w1, #4, #0x665e30
    // 0x665d2c: LoadField: r1 = r0->field_7b
    //     0x665d2c: ldur            w1, [x0, #0x7b]
    // 0x665d30: DecompressPointer r1
    //     0x665d30: add             x1, x1, HEAP, lsl #32
    // 0x665d34: r16 = Instance_Clip
    //     0x665d34: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x665d38: ldr             x16, [x16, #0xb38]
    // 0x665d3c: cmp             w1, w16
    // 0x665d40: b.eq            #0x665e30
    // 0x665d44: LoadField: r1 = r0->field_37
    //     0x665d44: ldur            w1, [x0, #0x37]
    // 0x665d48: DecompressPointer r1
    //     0x665d48: add             x1, x1, HEAP, lsl #32
    // 0x665d4c: r16 = Sentinel
    //     0x665d4c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x665d50: cmp             w1, w16
    // 0x665d54: b.eq            #0x665e88
    // 0x665d58: stur            x1, [fp, #-8]
    // 0x665d5c: LoadField: r2 = r0->field_57
    //     0x665d5c: ldur            w2, [x0, #0x57]
    // 0x665d60: DecompressPointer r2
    //     0x665d60: add             x2, x2, HEAP, lsl #32
    // 0x665d64: cmp             w2, NULL
    // 0x665d68: b.eq            #0x665e90
    // 0x665d6c: r16 = Instance_Offset
    //     0x665d6c: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x665d70: stp             x2, x16, [SP, #-0x10]!
    // 0x665d74: r0 = &()
    //     0x665d74: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x665d78: add             SP, SP, #0x10
    // 0x665d7c: stur            x0, [fp, #-0x10]
    // 0x665d80: r1 = 1
    //     0x665d80: mov             x1, #1
    // 0x665d84: r0 = AllocateContext()
    //     0x665d84: bl              #0xd68aa4  ; AllocateContextStub
    // 0x665d88: mov             x1, x0
    // 0x665d8c: ldr             x0, [fp, #0x20]
    // 0x665d90: StoreField: r1->field_f = r0
    //     0x665d90: stur            w0, [x1, #0xf]
    // 0x665d94: LoadField: r3 = r0->field_2f
    //     0x665d94: ldur            w3, [x0, #0x2f]
    // 0x665d98: DecompressPointer r3
    //     0x665d98: add             x3, x3, HEAP, lsl #32
    // 0x665d9c: stur            x3, [fp, #-0x28]
    // 0x665da0: LoadField: r2 = r3->field_b
    //     0x665da0: ldur            w2, [x3, #0xb]
    // 0x665da4: DecompressPointer r2
    //     0x665da4: add             x2, x2, HEAP, lsl #32
    // 0x665da8: r4 = LoadClassIdInstr(r2)
    //     0x665da8: ldur            x4, [x2, #-1]
    //     0x665dac: ubfx            x4, x4, #0xc, #0x14
    // 0x665db0: lsl             x4, x4, #1
    // 0x665db4: r17 = 4778
    //     0x665db4: mov             x17, #0x12aa
    // 0x665db8: cmp             w4, w17
    // 0x665dbc: b.ne            #0x665dc8
    // 0x665dc0: mov             x4, x2
    // 0x665dc4: b               #0x665dcc
    // 0x665dc8: r4 = Null
    //     0x665dc8: mov             x4, NULL
    // 0x665dcc: stur            x4, [fp, #-0x20]
    // 0x665dd0: LoadField: r5 = r0->field_7b
    //     0x665dd0: ldur            w5, [x0, #0x7b]
    // 0x665dd4: DecompressPointer r5
    //     0x665dd4: add             x5, x5, HEAP, lsl #32
    // 0x665dd8: mov             x2, x1
    // 0x665ddc: stur            x5, [fp, #-0x18]
    // 0x665de0: r1 = Function '_paintChildWithTransform@907160605':.
    //     0x665de0: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4fd58] AnonymousClosure: (0x665fec), in [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_paintChildWithTransform (0x665e94)
    //     0x665de4: ldr             x1, [x1, #0xd58]
    // 0x665de8: r0 = AllocateClosure()
    //     0x665de8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x665dec: ldr             x16, [fp, #0x18]
    // 0x665df0: ldur            lr, [fp, #-8]
    // 0x665df4: stp             lr, x16, [SP, #-0x10]!
    // 0x665df8: ldr             x16, [fp, #0x10]
    // 0x665dfc: ldur            lr, [fp, #-0x10]
    // 0x665e00: stp             lr, x16, [SP, #-0x10]!
    // 0x665e04: ldur            x16, [fp, #-0x18]
    // 0x665e08: stp             x16, x0, [SP, #-0x10]!
    // 0x665e0c: ldur            x16, [fp, #-0x20]
    // 0x665e10: SaveReg r16
    //     0x665e10: str             x16, [SP, #-8]!
    // 0x665e14: r0 = pushClipRect()
    //     0x665e14: bl              #0x65b240  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRect
    // 0x665e18: add             SP, SP, #0x38
    // 0x665e1c: ldur            x16, [fp, #-0x28]
    // 0x665e20: stp             x0, x16, [SP, #-0x10]!
    // 0x665e24: r0 = layer=()
    //     0x665e24: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x665e28: add             SP, SP, #0x10
    // 0x665e2c: b               #0x665e64
    // 0x665e30: ldr             x16, [fp, #0x18]
    // 0x665e34: stp             x16, x0, [SP, #-0x10]!
    // 0x665e38: ldr             x16, [fp, #0x10]
    // 0x665e3c: SaveReg r16
    //     0x665e3c: str             x16, [SP, #-8]!
    // 0x665e40: r0 = _paintChildWithTransform()
    //     0x665e40: bl              #0x665e94  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_paintChildWithTransform
    // 0x665e44: add             SP, SP, #0x18
    // 0x665e48: mov             x1, x0
    // 0x665e4c: ldr             x0, [fp, #0x20]
    // 0x665e50: LoadField: r2 = r0->field_2f
    //     0x665e50: ldur            w2, [x0, #0x2f]
    // 0x665e54: DecompressPointer r2
    //     0x665e54: add             x2, x2, HEAP, lsl #32
    // 0x665e58: stp             x1, x2, [SP, #-0x10]!
    // 0x665e5c: r0 = layer=()
    //     0x665e5c: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x665e60: add             SP, SP, #0x10
    // 0x665e64: r0 = Null
    //     0x665e64: mov             x0, NULL
    // 0x665e68: LeaveFrame
    //     0x665e68: mov             SP, fp
    //     0x665e6c: ldp             fp, lr, [SP], #0x10
    // 0x665e70: ret
    //     0x665e70: ret             
    // 0x665e74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x665e74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x665e78: b               #0x665c80
    // 0x665e7c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x665e7c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x665e80: r0 = NullCastErrorSharedWithFPURegs()
    //     0x665e80: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x665e84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x665e84: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x665e88: r9 = _needsCompositing
    //     0x665e88: ldr             x9, [PP, #0x4b28]  ; [pp+0x4b28] Field <RenderObject._needsCompositing@904266271>: late (offset: 0x38)
    // 0x665e8c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x665e8c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x665e90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x665e90: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _paintChildWithTransform(/* No info */) {
    // ** addr: 0x665e94, size: 0x158
    // 0x665e94: EnterFrame
    //     0x665e94: stp             fp, lr, [SP, #-0x10]!
    //     0x665e98: mov             fp, SP
    // 0x665e9c: AllocStack(0x18)
    //     0x665e9c: sub             SP, SP, #0x18
    // 0x665ea0: CheckStackOverflow
    //     0x665ea0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x665ea4: cmp             SP, x16
    //     0x665ea8: b.ls            #0x665fd4
    // 0x665eac: ldr             x0, [fp, #0x20]
    // 0x665eb0: LoadField: r1 = r0->field_77
    //     0x665eb0: ldur            w1, [x0, #0x77]
    // 0x665eb4: DecompressPointer r1
    //     0x665eb4: add             x1, x1, HEAP, lsl #32
    // 0x665eb8: cmp             w1, NULL
    // 0x665ebc: b.eq            #0x665fdc
    // 0x665ec0: SaveReg r1
    //     0x665ec0: str             x1, [SP, #-8]!
    // 0x665ec4: r0 = getAsTranslation()
    //     0x665ec4: bl              #0x665a04  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::getAsTranslation
    // 0x665ec8: add             SP, SP, #8
    // 0x665ecc: cmp             w0, NULL
    // 0x665ed0: b.ne            #0x665f98
    // 0x665ed4: ldr             x0, [fp, #0x20]
    // 0x665ed8: LoadField: r1 = r0->field_37
    //     0x665ed8: ldur            w1, [x0, #0x37]
    // 0x665edc: DecompressPointer r1
    //     0x665edc: add             x1, x1, HEAP, lsl #32
    // 0x665ee0: r16 = Sentinel
    //     0x665ee0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x665ee4: cmp             w1, w16
    // 0x665ee8: b.eq            #0x665fe0
    // 0x665eec: stur            x1, [fp, #-0x10]
    // 0x665ef0: LoadField: r2 = r0->field_77
    //     0x665ef0: ldur            w2, [x0, #0x77]
    // 0x665ef4: DecompressPointer r2
    //     0x665ef4: add             x2, x2, HEAP, lsl #32
    // 0x665ef8: stur            x2, [fp, #-8]
    // 0x665efc: cmp             w2, NULL
    // 0x665f00: b.eq            #0x665fe8
    // 0x665f04: r1 = 1
    //     0x665f04: mov             x1, #1
    // 0x665f08: r0 = AllocateContext()
    //     0x665f08: bl              #0xd68aa4  ; AllocateContextStub
    // 0x665f0c: ldr             x1, [fp, #0x20]
    // 0x665f10: StoreField: r0->field_f = r1
    //     0x665f10: stur            w1, [x0, #0xf]
    // 0x665f14: LoadField: r2 = r1->field_2f
    //     0x665f14: ldur            w2, [x1, #0x2f]
    // 0x665f18: DecompressPointer r2
    //     0x665f18: add             x2, x2, HEAP, lsl #32
    // 0x665f1c: LoadField: r1 = r2->field_b
    //     0x665f1c: ldur            w1, [x2, #0xb]
    // 0x665f20: DecompressPointer r1
    //     0x665f20: add             x1, x1, HEAP, lsl #32
    // 0x665f24: r2 = LoadClassIdInstr(r1)
    //     0x665f24: ldur            x2, [x1, #-1]
    //     0x665f28: ubfx            x2, x2, #0xc, #0x14
    // 0x665f2c: lsl             x2, x2, #1
    // 0x665f30: r17 = 4784
    //     0x665f30: mov             x17, #0x12b0
    // 0x665f34: cmp             w2, w17
    // 0x665f38: b.ne            #0x665f44
    // 0x665f3c: mov             x3, x1
    // 0x665f40: b               #0x665f48
    // 0x665f44: r3 = Null
    //     0x665f44: mov             x3, NULL
    // 0x665f48: mov             x2, x0
    // 0x665f4c: stur            x3, [fp, #-0x18]
    // 0x665f50: r1 = Function 'paint':.
    //     0x665f50: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cef0] AnonymousClosure: (0x661630), in [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::paint (0x669ddc)
    //     0x665f54: ldr             x1, [x1, #0xef0]
    // 0x665f58: r0 = AllocateClosure()
    //     0x665f58: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x665f5c: ldr             x16, [fp, #0x18]
    // 0x665f60: ldur            lr, [fp, #-0x10]
    // 0x665f64: stp             lr, x16, [SP, #-0x10]!
    // 0x665f68: ldr             x16, [fp, #0x10]
    // 0x665f6c: ldur            lr, [fp, #-8]
    // 0x665f70: stp             lr, x16, [SP, #-0x10]!
    // 0x665f74: ldur            x16, [fp, #-0x18]
    // 0x665f78: stp             x16, x0, [SP, #-0x10]!
    // 0x665f7c: r4 = const [0, 0x6, 0x6, 0x5, oldLayer, 0x5, null]
    //     0x665f7c: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1cef8] List(7) [0, 0x6, 0x6, 0x5, "oldLayer", 0x5, Null]
    //     0x665f80: ldr             x4, [x4, #0xef8]
    // 0x665f84: r0 = pushTransform()
    //     0x665f84: bl              #0x65d108  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushTransform
    // 0x665f88: add             SP, SP, #0x30
    // 0x665f8c: LeaveFrame
    //     0x665f8c: mov             SP, fp
    //     0x665f90: ldp             fp, lr, [SP], #0x10
    // 0x665f94: ret
    //     0x665f94: ret             
    // 0x665f98: ldr             x1, [fp, #0x20]
    // 0x665f9c: ldr             x16, [fp, #0x10]
    // 0x665fa0: stp             x0, x16, [SP, #-0x10]!
    // 0x665fa4: r0 = +()
    //     0x665fa4: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x665fa8: add             SP, SP, #0x10
    // 0x665fac: ldr             x16, [fp, #0x20]
    // 0x665fb0: ldr             lr, [fp, #0x18]
    // 0x665fb4: stp             lr, x16, [SP, #-0x10]!
    // 0x665fb8: SaveReg r0
    //     0x665fb8: str             x0, [SP, #-8]!
    // 0x665fbc: r0 = paint()
    //     0x665fbc: bl              #0x669ddc  ; [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::paint
    // 0x665fc0: add             SP, SP, #0x18
    // 0x665fc4: r0 = Null
    //     0x665fc4: mov             x0, NULL
    // 0x665fc8: LeaveFrame
    //     0x665fc8: mov             SP, fp
    //     0x665fcc: ldp             fp, lr, [SP], #0x10
    // 0x665fd0: ret
    //     0x665fd0: ret             
    // 0x665fd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x665fd4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x665fd8: b               #0x665eac
    // 0x665fdc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x665fdc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x665fe0: r9 = _needsCompositing
    //     0x665fe0: ldr             x9, [PP, #0x4b28]  ; [pp+0x4b28] Field <RenderObject._needsCompositing@904266271>: late (offset: 0x38)
    // 0x665fe4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x665fe4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x665fe8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x665fe8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] TransformLayer? _paintChildWithTransform(dynamic, PaintingContext, Offset) {
    // ** addr: 0x665fec, size: 0x54
    // 0x665fec: EnterFrame
    //     0x665fec: stp             fp, lr, [SP, #-0x10]!
    //     0x665ff0: mov             fp, SP
    // 0x665ff4: ldr             x0, [fp, #0x20]
    // 0x665ff8: LoadField: r1 = r0->field_17
    //     0x665ff8: ldur            w1, [x0, #0x17]
    // 0x665ffc: DecompressPointer r1
    //     0x665ffc: add             x1, x1, HEAP, lsl #32
    // 0x666000: CheckStackOverflow
    //     0x666000: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x666004: cmp             SP, x16
    //     0x666008: b.ls            #0x666038
    // 0x66600c: LoadField: r0 = r1->field_f
    //     0x66600c: ldur            w0, [x1, #0xf]
    // 0x666010: DecompressPointer r0
    //     0x666010: add             x0, x0, HEAP, lsl #32
    // 0x666014: ldr             x16, [fp, #0x18]
    // 0x666018: stp             x16, x0, [SP, #-0x10]!
    // 0x66601c: ldr             x16, [fp, #0x10]
    // 0x666020: SaveReg r16
    //     0x666020: str             x16, [SP, #-8]!
    // 0x666024: r0 = _paintChildWithTransform()
    //     0x666024: bl              #0x665e94  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_paintChildWithTransform
    // 0x666028: add             SP, SP, #0x18
    // 0x66602c: LeaveFrame
    //     0x66602c: mov             SP, fp
    //     0x666030: ldp             fp, lr, [SP], #0x10
    // 0x666034: ret
    //     0x666034: ret             
    // 0x666038: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x666038: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66603c: b               #0x66600c
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x68fad0, size: 0x37c
    // 0x68fad0: EnterFrame
    //     0x68fad0: stp             fp, lr, [SP, #-0x10]!
    //     0x68fad4: mov             fp, SP
    // 0x68fad8: AllocStack(0x10)
    //     0x68fad8: sub             SP, SP, #0x10
    // 0x68fadc: CheckStackOverflow
    //     0x68fadc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68fae0: cmp             SP, x16
    //     0x68fae4: b.ls            #0x68fe34
    // 0x68fae8: ldr             x1, [fp, #0x10]
    // 0x68faec: LoadField: r0 = r1->field_5f
    //     0x68faec: ldur            w0, [x1, #0x5f]
    // 0x68faf0: DecompressPointer r0
    //     0x68faf0: add             x0, x0, HEAP, lsl #32
    // 0x68faf4: cmp             w0, NULL
    // 0x68faf8: b.eq            #0x68fd28
    // 0x68fafc: r2 = LoadClassIdInstr(r0)
    //     0x68fafc: ldur            x2, [x0, #-1]
    //     0x68fb00: ubfx            x2, x2, #0xc, #0x14
    // 0x68fb04: r16 = Instance_BoxConstraints
    //     0x68fb04: add             x16, PP, #0x21, lsl #12  ; [pp+0x21610] Obj!BoxConstraints@b35351
    //     0x68fb08: ldr             x16, [x16, #0x610]
    // 0x68fb0c: stp             x16, x0, [SP, #-0x10]!
    // 0x68fb10: r16 = true
    //     0x68fb10: add             x16, NULL, #0x20  ; true
    // 0x68fb14: SaveReg r16
    //     0x68fb14: str             x16, [SP, #-8]!
    // 0x68fb18: mov             x0, x2
    // 0x68fb1c: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x68fb1c: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x68fb20: ldr             x4, [x4, #0x1c8]
    // 0x68fb24: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x68fb24: mov             x17, #0xcdfb
    //     0x68fb28: add             lr, x0, x17
    //     0x68fb2c: ldr             lr, [x21, lr, lsl #3]
    //     0x68fb30: blr             lr
    // 0x68fb34: add             SP, SP, #0x18
    // 0x68fb38: ldr             x3, [fp, #0x10]
    // 0x68fb3c: LoadField: r0 = r3->field_67
    //     0x68fb3c: ldur            w0, [x3, #0x67]
    // 0x68fb40: DecompressPointer r0
    //     0x68fb40: add             x0, x0, HEAP, lsl #32
    // 0x68fb44: LoadField: r1 = r0->field_7
    //     0x68fb44: ldur            x1, [x0, #7]
    // 0x68fb48: cmp             x1, #3
    // 0x68fb4c: b.le            #0x68fb58
    // 0x68fb50: cmp             x1, #5
    // 0x68fb54: b.gt            #0x68fbf8
    // 0x68fb58: LoadField: r4 = r3->field_27
    //     0x68fb58: ldur            w4, [x3, #0x27]
    // 0x68fb5c: DecompressPointer r4
    //     0x68fb5c: add             x4, x4, HEAP, lsl #32
    // 0x68fb60: stur            x4, [fp, #-8]
    // 0x68fb64: cmp             w4, NULL
    // 0x68fb68: b.eq            #0x68fdbc
    // 0x68fb6c: mov             x0, x4
    // 0x68fb70: r2 = Null
    //     0x68fb70: mov             x2, NULL
    // 0x68fb74: r1 = Null
    //     0x68fb74: mov             x1, NULL
    // 0x68fb78: r4 = LoadClassIdInstr(r0)
    //     0x68fb78: ldur            x4, [x0, #-1]
    //     0x68fb7c: ubfx            x4, x4, #0xc, #0x14
    // 0x68fb80: sub             x4, x4, #0x80d
    // 0x68fb84: cmp             x4, #1
    // 0x68fb88: b.ls            #0x68fba0
    // 0x68fb8c: r8 = BoxConstraints
    //     0x68fb8c: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x68fb90: ldr             x8, [x8, #0x1d0]
    // 0x68fb94: r3 = Null
    //     0x68fb94: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fd60] Null
    //     0x68fb98: ldr             x3, [x3, #0xd60]
    // 0x68fb9c: r0 = BoxConstraints()
    //     0x68fb9c: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x68fba0: ldr             x0, [fp, #0x10]
    // 0x68fba4: LoadField: r1 = r0->field_5f
    //     0x68fba4: ldur            w1, [x0, #0x5f]
    // 0x68fba8: DecompressPointer r1
    //     0x68fba8: add             x1, x1, HEAP, lsl #32
    // 0x68fbac: cmp             w1, NULL
    // 0x68fbb0: b.eq            #0x68fe3c
    // 0x68fbb4: LoadField: r2 = r1->field_57
    //     0x68fbb4: ldur            w2, [x1, #0x57]
    // 0x68fbb8: DecompressPointer r2
    //     0x68fbb8: add             x2, x2, HEAP, lsl #32
    // 0x68fbbc: cmp             w2, NULL
    // 0x68fbc0: b.eq            #0x68fe40
    // 0x68fbc4: ldur            x16, [fp, #-8]
    // 0x68fbc8: stp             x2, x16, [SP, #-0x10]!
    // 0x68fbcc: r0 = constrainSizeAndAttemptToPreserveAspectRatio()
    //     0x68fbcc: bl              #0x62ba34  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainSizeAndAttemptToPreserveAspectRatio
    // 0x68fbd0: add             SP, SP, #0x10
    // 0x68fbd4: ldr             x3, [fp, #0x10]
    // 0x68fbd8: StoreField: r3->field_57 = r0
    //     0x68fbd8: stur            w0, [x3, #0x57]
    //     0x68fbdc: ldurb           w16, [x3, #-1]
    //     0x68fbe0: ldurb           w17, [x0, #-1]
    //     0x68fbe4: and             x16, x17, x16, lsr #2
    //     0x68fbe8: tst             x16, HEAP, lsr #32
    //     0x68fbec: b.eq            #0x68fbf4
    //     0x68fbf0: bl              #0xd682ac
    // 0x68fbf4: b               #0x68fd18
    // 0x68fbf8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68fbf8: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68fbfc: ldr             x0, [x0, #0x1e8]
    // 0x68fc00: LoadField: r4 = r3->field_27
    //     0x68fc00: ldur            w4, [x3, #0x27]
    // 0x68fc04: DecompressPointer r4
    //     0x68fc04: add             x4, x4, HEAP, lsl #32
    // 0x68fc08: stur            x4, [fp, #-8]
    // 0x68fc0c: cmp             w4, NULL
    // 0x68fc10: b.eq            #0x68fddc
    // 0x68fc14: mov             x5, x0
    // 0x68fc18: mov             x0, x4
    // 0x68fc1c: r2 = Null
    //     0x68fc1c: mov             x2, NULL
    // 0x68fc20: r1 = Null
    //     0x68fc20: mov             x1, NULL
    // 0x68fc24: r4 = LoadClassIdInstr(r0)
    //     0x68fc24: ldur            x4, [x0, #-1]
    //     0x68fc28: ubfx            x4, x4, #0xc, #0x14
    // 0x68fc2c: sub             x4, x4, #0x80d
    // 0x68fc30: cmp             x4, #1
    // 0x68fc34: b.ls            #0x68fc4c
    // 0x68fc38: r8 = BoxConstraints
    //     0x68fc38: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x68fc3c: ldr             x8, [x8, #0x1d0]
    // 0x68fc40: r3 = Null
    //     0x68fc40: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fd70] Null
    //     0x68fc44: ldr             x3, [x3, #0xd70]
    // 0x68fc48: r0 = BoxConstraints()
    //     0x68fc48: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x68fc4c: ldur            x16, [fp, #-8]
    // 0x68fc50: SaveReg r16
    //     0x68fc50: str             x16, [SP, #-8]!
    // 0x68fc54: r0 = loosen()
    //     0x68fc54: bl              #0x68f088  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0x68fc58: add             SP, SP, #8
    // 0x68fc5c: mov             x1, x0
    // 0x68fc60: ldr             x0, [fp, #0x10]
    // 0x68fc64: LoadField: r2 = r0->field_5f
    //     0x68fc64: ldur            w2, [x0, #0x5f]
    // 0x68fc68: DecompressPointer r2
    //     0x68fc68: add             x2, x2, HEAP, lsl #32
    // 0x68fc6c: cmp             w2, NULL
    // 0x68fc70: b.eq            #0x68fe44
    // 0x68fc74: LoadField: r3 = r2->field_57
    //     0x68fc74: ldur            w3, [x2, #0x57]
    // 0x68fc78: DecompressPointer r3
    //     0x68fc78: add             x3, x3, HEAP, lsl #32
    // 0x68fc7c: cmp             w3, NULL
    // 0x68fc80: b.eq            #0x68fe48
    // 0x68fc84: stp             x3, x1, [SP, #-0x10]!
    // 0x68fc88: r0 = constrainSizeAndAttemptToPreserveAspectRatio()
    //     0x68fc88: bl              #0x62ba34  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainSizeAndAttemptToPreserveAspectRatio
    // 0x68fc8c: add             SP, SP, #0x10
    // 0x68fc90: mov             x4, x0
    // 0x68fc94: ldr             x3, [fp, #0x10]
    // 0x68fc98: stur            x4, [fp, #-0x10]
    // 0x68fc9c: LoadField: r5 = r3->field_27
    //     0x68fc9c: ldur            w5, [x3, #0x27]
    // 0x68fca0: DecompressPointer r5
    //     0x68fca0: add             x5, x5, HEAP, lsl #32
    // 0x68fca4: stur            x5, [fp, #-8]
    // 0x68fca8: cmp             w5, NULL
    // 0x68fcac: b.eq            #0x68fdf4
    // 0x68fcb0: mov             x0, x5
    // 0x68fcb4: r2 = Null
    //     0x68fcb4: mov             x2, NULL
    // 0x68fcb8: r1 = Null
    //     0x68fcb8: mov             x1, NULL
    // 0x68fcbc: r4 = LoadClassIdInstr(r0)
    //     0x68fcbc: ldur            x4, [x0, #-1]
    //     0x68fcc0: ubfx            x4, x4, #0xc, #0x14
    // 0x68fcc4: sub             x4, x4, #0x80d
    // 0x68fcc8: cmp             x4, #1
    // 0x68fccc: b.ls            #0x68fce4
    // 0x68fcd0: r8 = BoxConstraints
    //     0x68fcd0: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x68fcd4: ldr             x8, [x8, #0x1d0]
    // 0x68fcd8: r3 = Null
    //     0x68fcd8: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fd80] Null
    //     0x68fcdc: ldr             x3, [x3, #0xd80]
    // 0x68fce0: r0 = BoxConstraints()
    //     0x68fce0: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x68fce4: ldur            x16, [fp, #-8]
    // 0x68fce8: ldur            lr, [fp, #-0x10]
    // 0x68fcec: stp             lr, x16, [SP, #-0x10]!
    // 0x68fcf0: r0 = constrain()
    //     0x68fcf0: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x68fcf4: add             SP, SP, #0x10
    // 0x68fcf8: ldr             x3, [fp, #0x10]
    // 0x68fcfc: StoreField: r3->field_57 = r0
    //     0x68fcfc: stur            w0, [x3, #0x57]
    //     0x68fd00: ldurb           w16, [x3, #-1]
    //     0x68fd04: ldurb           w17, [x0, #-1]
    //     0x68fd08: and             x16, x17, x16, lsr #2
    //     0x68fd0c: tst             x16, HEAP, lsr #32
    //     0x68fd10: b.eq            #0x68fd18
    //     0x68fd14: bl              #0xd682ac
    // 0x68fd18: SaveReg r3
    //     0x68fd18: str             x3, [SP, #-8]!
    // 0x68fd1c: r0 = _clearPaintData()
    //     0x68fd1c: bl              #0x68fe4c  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_clearPaintData
    // 0x68fd20: add             SP, SP, #8
    // 0x68fd24: b               #0x68fdac
    // 0x68fd28: mov             x3, x1
    // 0x68fd2c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68fd2c: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68fd30: ldr             x0, [x0, #0x1e8]
    // 0x68fd34: LoadField: r4 = r3->field_27
    //     0x68fd34: ldur            w4, [x3, #0x27]
    // 0x68fd38: DecompressPointer r4
    //     0x68fd38: add             x4, x4, HEAP, lsl #32
    // 0x68fd3c: stur            x4, [fp, #-8]
    // 0x68fd40: cmp             w4, NULL
    // 0x68fd44: b.eq            #0x68fe14
    // 0x68fd48: mov             x0, x4
    // 0x68fd4c: r2 = Null
    //     0x68fd4c: mov             x2, NULL
    // 0x68fd50: r1 = Null
    //     0x68fd50: mov             x1, NULL
    // 0x68fd54: r4 = LoadClassIdInstr(r0)
    //     0x68fd54: ldur            x4, [x0, #-1]
    //     0x68fd58: ubfx            x4, x4, #0xc, #0x14
    // 0x68fd5c: sub             x4, x4, #0x80d
    // 0x68fd60: cmp             x4, #1
    // 0x68fd64: b.ls            #0x68fd7c
    // 0x68fd68: r8 = BoxConstraints
    //     0x68fd68: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x68fd6c: ldr             x8, [x8, #0x1d0]
    // 0x68fd70: r3 = Null
    //     0x68fd70: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fd90] Null
    //     0x68fd74: ldr             x3, [x3, #0xd90]
    // 0x68fd78: r0 = BoxConstraints()
    //     0x68fd78: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x68fd7c: ldur            x16, [fp, #-8]
    // 0x68fd80: SaveReg r16
    //     0x68fd80: str             x16, [SP, #-8]!
    // 0x68fd84: r0 = smallest()
    //     0x68fd84: bl              #0x62bd18  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0x68fd88: add             SP, SP, #8
    // 0x68fd8c: ldr             x1, [fp, #0x10]
    // 0x68fd90: StoreField: r1->field_57 = r0
    //     0x68fd90: stur            w0, [x1, #0x57]
    //     0x68fd94: ldurb           w16, [x1, #-1]
    //     0x68fd98: ldurb           w17, [x0, #-1]
    //     0x68fd9c: and             x16, x17, x16, lsr #2
    //     0x68fda0: tst             x16, HEAP, lsr #32
    //     0x68fda4: b.eq            #0x68fdac
    //     0x68fda8: bl              #0xd6826c
    // 0x68fdac: r0 = Null
    //     0x68fdac: mov             x0, NULL
    // 0x68fdb0: LeaveFrame
    //     0x68fdb0: mov             SP, fp
    //     0x68fdb4: ldp             fp, lr, [SP], #0x10
    // 0x68fdb8: ret
    //     0x68fdb8: ret             
    // 0x68fdbc: r0 = StateError()
    //     0x68fdbc: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68fdc0: mov             x1, x0
    // 0x68fdc4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68fdc4: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68fdc8: ldr             x0, [x0, #0x1e8]
    // 0x68fdcc: StoreField: r1->field_b = r0
    //     0x68fdcc: stur            w0, [x1, #0xb]
    // 0x68fdd0: mov             x0, x1
    // 0x68fdd4: r0 = Throw()
    //     0x68fdd4: bl              #0xd67e38  ; ThrowStub
    // 0x68fdd8: brk             #0
    // 0x68fddc: r0 = StateError()
    //     0x68fddc: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68fde0: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68fde0: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68fde4: ldr             x5, [x5, #0x1e8]
    // 0x68fde8: StoreField: r0->field_b = r5
    //     0x68fde8: stur            w5, [x0, #0xb]
    // 0x68fdec: r0 = Throw()
    //     0x68fdec: bl              #0xd67e38  ; ThrowStub
    // 0x68fdf0: brk             #0
    // 0x68fdf4: r0 = StateError()
    //     0x68fdf4: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68fdf8: mov             x1, x0
    // 0x68fdfc: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68fdfc: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68fe00: ldr             x0, [x0, #0x1e8]
    // 0x68fe04: StoreField: r1->field_b = r0
    //     0x68fe04: stur            w0, [x1, #0xb]
    // 0x68fe08: mov             x0, x1
    // 0x68fe0c: r0 = Throw()
    //     0x68fe0c: bl              #0xd67e38  ; ThrowStub
    // 0x68fe10: brk             #0
    // 0x68fe14: r0 = StateError()
    //     0x68fe14: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68fe18: mov             x1, x0
    // 0x68fe1c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68fe1c: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68fe20: ldr             x0, [x0, #0x1e8]
    // 0x68fe24: StoreField: r1->field_b = r0
    //     0x68fe24: stur            w0, [x1, #0xb]
    // 0x68fe28: mov             x0, x1
    // 0x68fe2c: r0 = Throw()
    //     0x68fe2c: bl              #0xd67e38  ; ThrowStub
    // 0x68fe30: brk             #0
    // 0x68fe34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68fe34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68fe38: b               #0x68fae8
    // 0x68fe3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68fe3c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68fe40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68fe40: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68fe44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68fe44: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68fe48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68fe48: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _clearPaintData(/* No info */) {
    // ** addr: 0x68fe4c, size: 0x14
    // 0x68fe4c: ldr             x1, [SP]
    // 0x68fe50: StoreField: r1->field_73 = rNULL
    //     0x68fe50: stur            NULL, [x1, #0x73]
    // 0x68fe54: StoreField: r1->field_77 = rNULL
    //     0x68fe54: stur            NULL, [x1, #0x77]
    // 0x68fe58: r0 = Null
    //     0x68fe58: mov             x0, NULL
    // 0x68fe5c: ret
    //     0x68fe5c: ret             
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0x6bc3e0, size: 0xcc
    // 0x6bc3e0: EnterFrame
    //     0x6bc3e0: stp             fp, lr, [SP, #-0x10]!
    //     0x6bc3e4: mov             fp, SP
    // 0x6bc3e8: CheckStackOverflow
    //     0x6bc3e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bc3ec: cmp             SP, x16
    //     0x6bc3f0: b.ls            #0x6bc4a0
    // 0x6bc3f4: ldr             x0, [fp, #0x18]
    // 0x6bc3f8: r2 = Null
    //     0x6bc3f8: mov             x2, NULL
    // 0x6bc3fc: r1 = Null
    //     0x6bc3fc: mov             x1, NULL
    // 0x6bc400: r4 = 59
    //     0x6bc400: mov             x4, #0x3b
    // 0x6bc404: branchIfSmi(r0, 0x6bc410)
    //     0x6bc404: tbz             w0, #0, #0x6bc410
    // 0x6bc408: r4 = LoadClassIdInstr(r0)
    //     0x6bc408: ldur            x4, [x0, #-1]
    //     0x6bc40c: ubfx            x4, x4, #0xc, #0x14
    // 0x6bc410: sub             x4, x4, #0x965
    // 0x6bc414: cmp             x4, #0x8b
    // 0x6bc418: b.ls            #0x6bc430
    // 0x6bc41c: r8 = RenderBox
    //     0x6bc41c: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x6bc420: ldr             x8, [x8, #0xfa0]
    // 0x6bc424: r3 = Null
    //     0x6bc424: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fd30] Null
    //     0x6bc428: ldr             x3, [x3, #0xd30]
    // 0x6bc42c: r0 = RenderBox()
    //     0x6bc42c: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x6bc430: ldr             x16, [fp, #0x20]
    // 0x6bc434: ldr             lr, [fp, #0x18]
    // 0x6bc438: stp             lr, x16, [SP, #-0x10]!
    // 0x6bc43c: r0 = paintsChild()
    //     0x6bc43c: bl              #0x64171c  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::paintsChild
    // 0x6bc440: add             SP, SP, #0x10
    // 0x6bc444: tbz             w0, #4, #0x6bc45c
    // 0x6bc448: ldr             x16, [fp, #0x10]
    // 0x6bc44c: SaveReg r16
    //     0x6bc44c: str             x16, [SP, #-8]!
    // 0x6bc450: r0 = setZero()
    //     0x6bc450: bl              #0x6bbc24  ; [package:vector_math/vector_math_64.dart] Matrix4::setZero
    // 0x6bc454: add             SP, SP, #8
    // 0x6bc458: b               #0x6bc490
    // 0x6bc45c: ldr             x0, [fp, #0x20]
    // 0x6bc460: SaveReg r0
    //     0x6bc460: str             x0, [SP, #-8]!
    // 0x6bc464: r0 = _updatePaintData()
    //     0x6bc464: bl              #0x62654c  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_updatePaintData
    // 0x6bc468: add             SP, SP, #8
    // 0x6bc46c: ldr             x0, [fp, #0x20]
    // 0x6bc470: LoadField: r1 = r0->field_77
    //     0x6bc470: ldur            w1, [x0, #0x77]
    // 0x6bc474: DecompressPointer r1
    //     0x6bc474: add             x1, x1, HEAP, lsl #32
    // 0x6bc478: cmp             w1, NULL
    // 0x6bc47c: b.eq            #0x6bc4a8
    // 0x6bc480: ldr             x16, [fp, #0x10]
    // 0x6bc484: stp             x1, x16, [SP, #-0x10]!
    // 0x6bc488: r0 = multiply()
    //     0x6bc488: bl              #0x625d1c  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0x6bc48c: add             SP, SP, #0x10
    // 0x6bc490: r0 = Null
    //     0x6bc490: mov             x0, NULL
    // 0x6bc494: LeaveFrame
    //     0x6bc494: mov             SP, fp
    //     0x6bc498: ldp             fp, lr, [SP], #0x10
    // 0x6bc49c: ret
    //     0x6bc49c: ret             
    // 0x6bc4a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bc4a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bc4a4: b               #0x6bc3f4
    // 0x6bc4a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6bc4a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ clipBehavior=(/* No info */) {
    // ** addr: 0x6c4f14, size: 0x80
    // 0x6c4f14: EnterFrame
    //     0x6c4f14: stp             fp, lr, [SP, #-0x10]!
    //     0x6c4f18: mov             fp, SP
    // 0x6c4f1c: CheckStackOverflow
    //     0x6c4f1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c4f20: cmp             SP, x16
    //     0x6c4f24: b.ls            #0x6c4f8c
    // 0x6c4f28: ldr             x1, [fp, #0x18]
    // 0x6c4f2c: LoadField: r0 = r1->field_7b
    //     0x6c4f2c: ldur            w0, [x1, #0x7b]
    // 0x6c4f30: DecompressPointer r0
    //     0x6c4f30: add             x0, x0, HEAP, lsl #32
    // 0x6c4f34: ldr             x2, [fp, #0x10]
    // 0x6c4f38: cmp             w2, w0
    // 0x6c4f3c: b.eq            #0x6c4f7c
    // 0x6c4f40: mov             x0, x2
    // 0x6c4f44: StoreField: r1->field_7b = r0
    //     0x6c4f44: stur            w0, [x1, #0x7b]
    //     0x6c4f48: ldurb           w16, [x1, #-1]
    //     0x6c4f4c: ldurb           w17, [x0, #-1]
    //     0x6c4f50: and             x16, x17, x16, lsr #2
    //     0x6c4f54: tst             x16, HEAP, lsr #32
    //     0x6c4f58: b.eq            #0x6c4f60
    //     0x6c4f5c: bl              #0xd6826c
    // 0x6c4f60: SaveReg r1
    //     0x6c4f60: str             x1, [SP, #-8]!
    // 0x6c4f64: r0 = markNeedsPaint()
    //     0x6c4f64: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c4f68: add             SP, SP, #8
    // 0x6c4f6c: ldr             x16, [fp, #0x18]
    // 0x6c4f70: SaveReg r16
    //     0x6c4f70: str             x16, [SP, #-8]!
    // 0x6c4f74: r0 = markNeedsSemanticsUpdate()
    //     0x6c4f74: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6c4f78: add             SP, SP, #8
    // 0x6c4f7c: r0 = Null
    //     0x6c4f7c: mov             x0, NULL
    // 0x6c4f80: LeaveFrame
    //     0x6c4f80: mov             SP, fp
    //     0x6c4f84: ldp             fp, lr, [SP], #0x10
    // 0x6c4f88: ret
    //     0x6c4f88: ret             
    // 0x6c4f8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c4f8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c4f90: b               #0x6c4f28
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0x6c4f94, size: 0x90
    // 0x6c4f94: EnterFrame
    //     0x6c4f94: stp             fp, lr, [SP, #-0x10]!
    //     0x6c4f98: mov             fp, SP
    // 0x6c4f9c: CheckStackOverflow
    //     0x6c4f9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c4fa0: cmp             SP, x16
    //     0x6c4fa4: b.ls            #0x6c501c
    // 0x6c4fa8: ldr             x1, [fp, #0x18]
    // 0x6c4fac: LoadField: r0 = r1->field_6f
    //     0x6c4fac: ldur            w0, [x1, #0x6f]
    // 0x6c4fb0: DecompressPointer r0
    //     0x6c4fb0: add             x0, x0, HEAP, lsl #32
    // 0x6c4fb4: ldr             x2, [fp, #0x10]
    // 0x6c4fb8: cmp             w0, w2
    // 0x6c4fbc: b.ne            #0x6c4fd0
    // 0x6c4fc0: r0 = Null
    //     0x6c4fc0: mov             x0, NULL
    // 0x6c4fc4: LeaveFrame
    //     0x6c4fc4: mov             SP, fp
    //     0x6c4fc8: ldp             fp, lr, [SP], #0x10
    // 0x6c4fcc: ret
    //     0x6c4fcc: ret             
    // 0x6c4fd0: mov             x0, x2
    // 0x6c4fd4: StoreField: r1->field_6f = r0
    //     0x6c4fd4: stur            w0, [x1, #0x6f]
    //     0x6c4fd8: ldurb           w16, [x1, #-1]
    //     0x6c4fdc: ldurb           w17, [x0, #-1]
    //     0x6c4fe0: and             x16, x17, x16, lsr #2
    //     0x6c4fe4: tst             x16, HEAP, lsr #32
    //     0x6c4fe8: b.eq            #0x6c4ff0
    //     0x6c4fec: bl              #0xd6826c
    // 0x6c4ff0: SaveReg r1
    //     0x6c4ff0: str             x1, [SP, #-8]!
    // 0x6c4ff4: r0 = _clearPaintData()
    //     0x6c4ff4: bl              #0x68fe4c  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_clearPaintData
    // 0x6c4ff8: add             SP, SP, #8
    // 0x6c4ffc: ldr             x16, [fp, #0x18]
    // 0x6c5000: SaveReg r16
    //     0x6c5000: str             x16, [SP, #-8]!
    // 0x6c5004: r0 = _markNeedResolution()
    //     0x6c5004: bl              #0x6c5024  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_markNeedResolution
    // 0x6c5008: add             SP, SP, #8
    // 0x6c500c: r0 = Null
    //     0x6c500c: mov             x0, NULL
    // 0x6c5010: LeaveFrame
    //     0x6c5010: mov             SP, fp
    //     0x6c5014: ldp             fp, lr, [SP], #0x10
    // 0x6c5018: ret
    //     0x6c5018: ret             
    // 0x6c501c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c501c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c5020: b               #0x6c4fa8
  }
  _ _markNeedResolution(/* No info */) {
    // ** addr: 0x6c5024, size: 0x40
    // 0x6c5024: EnterFrame
    //     0x6c5024: stp             fp, lr, [SP, #-0x10]!
    //     0x6c5028: mov             fp, SP
    // 0x6c502c: CheckStackOverflow
    //     0x6c502c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c5030: cmp             SP, x16
    //     0x6c5034: b.ls            #0x6c505c
    // 0x6c5038: ldr             x0, [fp, #0x10]
    // 0x6c503c: StoreField: r0->field_63 = rNULL
    //     0x6c503c: stur            NULL, [x0, #0x63]
    // 0x6c5040: SaveReg r0
    //     0x6c5040: str             x0, [SP, #-8]!
    // 0x6c5044: r0 = markNeedsPaint()
    //     0x6c5044: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c5048: add             SP, SP, #8
    // 0x6c504c: r0 = Null
    //     0x6c504c: mov             x0, NULL
    // 0x6c5050: LeaveFrame
    //     0x6c5050: mov             SP, fp
    //     0x6c5054: ldp             fp, lr, [SP], #0x10
    // 0x6c5058: ret
    //     0x6c5058: ret             
    // 0x6c505c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c505c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c5060: b               #0x6c5038
  }
  set _ alignment=(/* No info */) {
    // ** addr: 0x6c5064, size: 0x9c
    // 0x6c5064: EnterFrame
    //     0x6c5064: stp             fp, lr, [SP, #-0x10]!
    //     0x6c5068: mov             fp, SP
    // 0x6c506c: CheckStackOverflow
    //     0x6c506c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c5070: cmp             SP, x16
    //     0x6c5074: b.ls            #0x6c50f8
    // 0x6c5078: ldr             x0, [fp, #0x18]
    // 0x6c507c: LoadField: r1 = r0->field_6b
    //     0x6c507c: ldur            w1, [x0, #0x6b]
    // 0x6c5080: DecompressPointer r1
    //     0x6c5080: add             x1, x1, HEAP, lsl #32
    // 0x6c5084: ldr             x16, [fp, #0x10]
    // 0x6c5088: stp             x16, x1, [SP, #-0x10]!
    // 0x6c508c: r0 = ==()
    //     0x6c508c: bl              #0xc9c720  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::==
    // 0x6c5090: add             SP, SP, #0x10
    // 0x6c5094: tbnz            w0, #4, #0x6c50a8
    // 0x6c5098: r0 = Null
    //     0x6c5098: mov             x0, NULL
    // 0x6c509c: LeaveFrame
    //     0x6c509c: mov             SP, fp
    //     0x6c50a0: ldp             fp, lr, [SP], #0x10
    // 0x6c50a4: ret
    //     0x6c50a4: ret             
    // 0x6c50a8: ldr             x1, [fp, #0x18]
    // 0x6c50ac: ldr             x0, [fp, #0x10]
    // 0x6c50b0: StoreField: r1->field_6b = r0
    //     0x6c50b0: stur            w0, [x1, #0x6b]
    //     0x6c50b4: ldurb           w16, [x1, #-1]
    //     0x6c50b8: ldurb           w17, [x0, #-1]
    //     0x6c50bc: and             x16, x17, x16, lsr #2
    //     0x6c50c0: tst             x16, HEAP, lsr #32
    //     0x6c50c4: b.eq            #0x6c50cc
    //     0x6c50c8: bl              #0xd6826c
    // 0x6c50cc: SaveReg r1
    //     0x6c50cc: str             x1, [SP, #-8]!
    // 0x6c50d0: r0 = _clearPaintData()
    //     0x6c50d0: bl              #0x68fe4c  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_clearPaintData
    // 0x6c50d4: add             SP, SP, #8
    // 0x6c50d8: ldr             x16, [fp, #0x18]
    // 0x6c50dc: SaveReg r16
    //     0x6c50dc: str             x16, [SP, #-8]!
    // 0x6c50e0: r0 = _markNeedResolution()
    //     0x6c50e0: bl              #0x6c5024  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_markNeedResolution
    // 0x6c50e4: add             SP, SP, #8
    // 0x6c50e8: r0 = Null
    //     0x6c50e8: mov             x0, NULL
    // 0x6c50ec: LeaveFrame
    //     0x6c50ec: mov             SP, fp
    //     0x6c50f0: ldp             fp, lr, [SP], #0x10
    // 0x6c50f4: ret
    //     0x6c50f4: ret             
    // 0x6c50f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c50f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c50fc: b               #0x6c5078
  }
  set _ fit=(/* No info */) {
    // ** addr: 0x6c5100, size: 0xcc
    // 0x6c5100: EnterFrame
    //     0x6c5100: stp             fp, lr, [SP, #-0x10]!
    //     0x6c5104: mov             fp, SP
    // 0x6c5108: CheckStackOverflow
    //     0x6c5108: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c510c: cmp             SP, x16
    //     0x6c5110: b.ls            #0x6c51c4
    // 0x6c5114: ldr             x1, [fp, #0x18]
    // 0x6c5118: LoadField: r2 = r1->field_67
    //     0x6c5118: ldur            w2, [x1, #0x67]
    // 0x6c511c: DecompressPointer r2
    //     0x6c511c: add             x2, x2, HEAP, lsl #32
    // 0x6c5120: ldr             x3, [fp, #0x10]
    // 0x6c5124: cmp             w2, w3
    // 0x6c5128: b.ne            #0x6c513c
    // 0x6c512c: r0 = Null
    //     0x6c512c: mov             x0, NULL
    // 0x6c5130: LeaveFrame
    //     0x6c5130: mov             SP, fp
    //     0x6c5134: ldp             fp, lr, [SP], #0x10
    // 0x6c5138: ret
    //     0x6c5138: ret             
    // 0x6c513c: mov             x0, x3
    // 0x6c5140: StoreField: r1->field_67 = r0
    //     0x6c5140: stur            w0, [x1, #0x67]
    //     0x6c5144: ldurb           w16, [x1, #-1]
    //     0x6c5148: ldurb           w17, [x0, #-1]
    //     0x6c514c: and             x16, x17, x16, lsr #2
    //     0x6c5150: tst             x16, HEAP, lsr #32
    //     0x6c5154: b.eq            #0x6c515c
    //     0x6c5158: bl              #0xd6826c
    // 0x6c515c: LoadField: r0 = r2->field_7
    //     0x6c515c: ldur            x0, [x2, #7]
    // 0x6c5160: cmp             x0, #3
    // 0x6c5164: b.le            #0x6c5170
    // 0x6c5168: cmp             x0, #5
    // 0x6c516c: b.gt            #0x6c51a4
    // 0x6c5170: LoadField: r0 = r3->field_7
    //     0x6c5170: ldur            x0, [x3, #7]
    // 0x6c5174: cmp             x0, #3
    // 0x6c5178: b.le            #0x6c5184
    // 0x6c517c: cmp             x0, #5
    // 0x6c5180: b.gt            #0x6c51a4
    // 0x6c5184: SaveReg r1
    //     0x6c5184: str             x1, [SP, #-8]!
    // 0x6c5188: r0 = _clearPaintData()
    //     0x6c5188: bl              #0x68fe4c  ; [package:flutter/src/rendering/proxy_box.dart] RenderFittedBox::_clearPaintData
    // 0x6c518c: add             SP, SP, #8
    // 0x6c5190: ldr             x16, [fp, #0x18]
    // 0x6c5194: SaveReg r16
    //     0x6c5194: str             x16, [SP, #-8]!
    // 0x6c5198: r0 = markNeedsPaint()
    //     0x6c5198: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c519c: add             SP, SP, #8
    // 0x6c51a0: b               #0x6c51b4
    // 0x6c51a4: ldr             x16, [fp, #0x18]
    // 0x6c51a8: SaveReg r16
    //     0x6c51a8: str             x16, [SP, #-8]!
    // 0x6c51ac: r0 = markNeedsLayout()
    //     0x6c51ac: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c51b0: add             SP, SP, #8
    // 0x6c51b4: r0 = Null
    //     0x6c51b4: mov             x0, NULL
    // 0x6c51b8: LeaveFrame
    //     0x6c51b8: mov             SP, fp
    //     0x6c51bc: ldp             fp, lr, [SP], #0x10
    // 0x6c51c0: ret
    //     0x6c51c0: ret             
    // 0x6c51c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c51c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c51c8: b               #0x6c5114
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5d820, size: 0xe4
    // 0xa5d820: EnterFrame
    //     0xa5d820: stp             fp, lr, [SP, #-0x10]!
    //     0xa5d824: mov             fp, SP
    // 0xa5d828: AllocStack(0x8)
    //     0xa5d828: sub             SP, SP, #8
    // 0xa5d82c: CheckStackOverflow
    //     0xa5d82c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5d830: cmp             SP, x16
    //     0xa5d834: b.ls            #0xa5d8fc
    // 0xa5d838: ldr             x0, [fp, #0x18]
    // 0xa5d83c: LoadField: r1 = r0->field_5f
    //     0xa5d83c: ldur            w1, [x0, #0x5f]
    // 0xa5d840: DecompressPointer r1
    //     0xa5d840: add             x1, x1, HEAP, lsl #32
    // 0xa5d844: cmp             w1, NULL
    // 0xa5d848: b.eq            #0xa5d8e0
    // 0xa5d84c: r16 = Instance_BoxConstraints
    //     0xa5d84c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21610] Obj!BoxConstraints@b35351
    //     0xa5d850: ldr             x16, [x16, #0x610]
    // 0xa5d854: stp             x16, x1, [SP, #-0x10]!
    // 0xa5d858: r0 = getDryLayout()
    //     0xa5d858: bl              #0x62d394  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xa5d85c: add             SP, SP, #0x10
    // 0xa5d860: mov             x1, x0
    // 0xa5d864: ldr             x0, [fp, #0x18]
    // 0xa5d868: stur            x1, [fp, #-8]
    // 0xa5d86c: LoadField: r2 = r0->field_67
    //     0xa5d86c: ldur            w2, [x0, #0x67]
    // 0xa5d870: DecompressPointer r2
    //     0xa5d870: add             x2, x2, HEAP, lsl #32
    // 0xa5d874: LoadField: r0 = r2->field_7
    //     0xa5d874: ldur            x0, [x2, #7]
    // 0xa5d878: cmp             x0, #3
    // 0xa5d87c: b.le            #0xa5d888
    // 0xa5d880: cmp             x0, #5
    // 0xa5d884: b.gt            #0xa5d8a4
    // 0xa5d888: ldr             x16, [fp, #0x10]
    // 0xa5d88c: stp             x1, x16, [SP, #-0x10]!
    // 0xa5d890: r0 = constrainSizeAndAttemptToPreserveAspectRatio()
    //     0xa5d890: bl              #0x62ba34  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainSizeAndAttemptToPreserveAspectRatio
    // 0xa5d894: add             SP, SP, #0x10
    // 0xa5d898: LeaveFrame
    //     0xa5d898: mov             SP, fp
    //     0xa5d89c: ldp             fp, lr, [SP], #0x10
    // 0xa5d8a0: ret
    //     0xa5d8a0: ret             
    // 0xa5d8a4: ldr             x16, [fp, #0x10]
    // 0xa5d8a8: SaveReg r16
    //     0xa5d8a8: str             x16, [SP, #-8]!
    // 0xa5d8ac: r0 = loosen()
    //     0xa5d8ac: bl              #0x68f088  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0xa5d8b0: add             SP, SP, #8
    // 0xa5d8b4: ldur            x16, [fp, #-8]
    // 0xa5d8b8: stp             x16, x0, [SP, #-0x10]!
    // 0xa5d8bc: r0 = constrainSizeAndAttemptToPreserveAspectRatio()
    //     0xa5d8bc: bl              #0x62ba34  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainSizeAndAttemptToPreserveAspectRatio
    // 0xa5d8c0: add             SP, SP, #0x10
    // 0xa5d8c4: ldr             x16, [fp, #0x10]
    // 0xa5d8c8: stp             x0, x16, [SP, #-0x10]!
    // 0xa5d8cc: r0 = constrain()
    //     0xa5d8cc: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xa5d8d0: add             SP, SP, #0x10
    // 0xa5d8d4: LeaveFrame
    //     0xa5d8d4: mov             SP, fp
    //     0xa5d8d8: ldp             fp, lr, [SP], #0x10
    // 0xa5d8dc: ret
    //     0xa5d8dc: ret             
    // 0xa5d8e0: ldr             x16, [fp, #0x10]
    // 0xa5d8e4: SaveReg r16
    //     0xa5d8e4: str             x16, [SP, #-8]!
    // 0xa5d8e8: r0 = smallest()
    //     0xa5d8e8: bl              #0x62bd18  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xa5d8ec: add             SP, SP, #8
    // 0xa5d8f0: LeaveFrame
    //     0xa5d8f0: mov             SP, fp
    //     0xa5d8f4: ldp             fp, lr, [SP], #0x10
    // 0xa5d8f8: ret
    //     0xa5d8f8: ret             
    // 0xa5d8fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5d8fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5d900: b               #0xa5d838
  }
}

// class id: 2494, size: 0x7c, field offset: 0x64
class RenderTransform extends RenderProxyBox {

  _ hitTestChildren(/* No info */) {
    // ** addr: 0x625518, size: 0x94
    // 0x625518: EnterFrame
    //     0x625518: stp             fp, lr, [SP, #-0x10]!
    //     0x62551c: mov             fp, SP
    // 0x625520: AllocStack(0x10)
    //     0x625520: sub             SP, SP, #0x10
    // 0x625524: CheckStackOverflow
    //     0x625524: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x625528: cmp             SP, x16
    //     0x62552c: b.ls            #0x6255a4
    // 0x625530: r1 = 1
    //     0x625530: mov             x1, #1
    // 0x625534: r0 = AllocateContext()
    //     0x625534: bl              #0xd68aa4  ; AllocateContextStub
    // 0x625538: mov             x1, x0
    // 0x62553c: ldr             x0, [fp, #0x20]
    // 0x625540: stur            x1, [fp, #-8]
    // 0x625544: StoreField: r1->field_f = r0
    //     0x625544: stur            w0, [x1, #0xf]
    // 0x625548: LoadField: r2 = r0->field_6f
    //     0x625548: ldur            w2, [x0, #0x6f]
    // 0x62554c: DecompressPointer r2
    //     0x62554c: add             x2, x2, HEAP, lsl #32
    // 0x625550: tbnz            w2, #4, #0x625564
    // 0x625554: SaveReg r0
    //     0x625554: str             x0, [SP, #-8]!
    // 0x625558: r0 = _effectiveTransform()
    //     0x625558: bl              #0x6255ac  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::_effectiveTransform
    // 0x62555c: add             SP, SP, #8
    // 0x625560: b               #0x625568
    // 0x625564: r0 = Null
    //     0x625564: mov             x0, NULL
    // 0x625568: ldur            x2, [fp, #-8]
    // 0x62556c: stur            x0, [fp, #-0x10]
    // 0x625570: r1 = Function '<anonymous closure>':.
    //     0x625570: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf58] AnonymousClosure: (0x6263b8), in [package:flutter/src/rendering/proxy_box.dart] RenderTransform::hitTestChildren (0x625518)
    //     0x625574: ldr             x1, [x1, #0xf58]
    // 0x625578: r0 = AllocateClosure()
    //     0x625578: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x62557c: ldr             x16, [fp, #0x18]
    // 0x625580: stp             x0, x16, [SP, #-0x10]!
    // 0x625584: ldr             x16, [fp, #0x10]
    // 0x625588: ldur            lr, [fp, #-0x10]
    // 0x62558c: stp             lr, x16, [SP, #-0x10]!
    // 0x625590: r0 = addWithPaintTransform()
    //     0x625590: bl              #0x622f04  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithPaintTransform
    // 0x625594: add             SP, SP, #0x20
    // 0x625598: LeaveFrame
    //     0x625598: mov             SP, fp
    //     0x62559c: ldp             fp, lr, [SP], #0x10
    // 0x6255a0: ret
    //     0x6255a0: ret             
    // 0x6255a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6255a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6255a8: b               #0x625530
  }
  get _ _effectiveTransform(/* No info */) {
    // ** addr: 0x6255ac, size: 0x2c4
    // 0x6255ac: EnterFrame
    //     0x6255ac: stp             fp, lr, [SP, #-0x10]!
    //     0x6255b0: mov             fp, SP
    // 0x6255b4: AllocStack(0x20)
    //     0x6255b4: sub             SP, SP, #0x20
    // 0x6255b8: CheckStackOverflow
    //     0x6255b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6255bc: cmp             SP, x16
    //     0x6255c0: b.ls            #0x625838
    // 0x6255c4: ldr             x0, [fp, #0x10]
    // 0x6255c8: LoadField: r1 = r0->field_67
    //     0x6255c8: ldur            w1, [x0, #0x67]
    // 0x6255cc: DecompressPointer r1
    //     0x6255cc: add             x1, x1, HEAP, lsl #32
    // 0x6255d0: cmp             w1, NULL
    // 0x6255d4: b.ne            #0x6255e0
    // 0x6255d8: r0 = Null
    //     0x6255d8: mov             x0, NULL
    // 0x6255dc: b               #0x6256f8
    // 0x6255e0: LoadField: r2 = r0->field_6b
    //     0x6255e0: ldur            w2, [x0, #0x6b]
    // 0x6255e4: DecompressPointer r2
    //     0x6255e4: add             x2, x2, HEAP, lsl #32
    // 0x6255e8: r3 = LoadClassIdInstr(r1)
    //     0x6255e8: ldur            x3, [x1, #-1]
    //     0x6255ec: ubfx            x3, x3, #0xc, #0x14
    // 0x6255f0: lsl             x3, x3, #1
    // 0x6255f4: r17 = 4240
    //     0x6255f4: mov             x17, #0x1090
    // 0x6255f8: cmp             w3, w17
    // 0x6255fc: b.gt            #0x625614
    // 0x625600: r17 = 4238
    //     0x625600: mov             x17, #0x108e
    // 0x625604: cmp             w3, w17
    // 0x625608: b.lt            #0x625614
    // 0x62560c: mov             x0, x1
    // 0x625610: b               #0x6256f8
    // 0x625614: r17 = 4234
    //     0x625614: mov             x17, #0x108a
    // 0x625618: cmp             w3, w17
    // 0x62561c: b.ne            #0x625694
    // 0x625620: cmp             w2, NULL
    // 0x625624: b.eq            #0x625840
    // 0x625628: LoadField: r3 = r2->field_7
    //     0x625628: ldur            x3, [x2, #7]
    // 0x62562c: cmp             x3, #0
    // 0x625630: b.gt            #0x625664
    // 0x625634: LoadField: d0 = r1->field_7
    //     0x625634: ldur            d0, [x1, #7]
    // 0x625638: LoadField: d1 = r1->field_f
    //     0x625638: ldur            d1, [x1, #0xf]
    // 0x62563c: fsub            d2, d0, d1
    // 0x625640: stur            d2, [fp, #-0x20]
    // 0x625644: LoadField: d0 = r1->field_17
    //     0x625644: ldur            d0, [x1, #0x17]
    // 0x625648: stur            d0, [fp, #-0x18]
    // 0x62564c: r0 = Alignment()
    //     0x62564c: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x625650: ldur            d0, [fp, #-0x20]
    // 0x625654: StoreField: r0->field_7 = d0
    //     0x625654: stur            d0, [x0, #7]
    // 0x625658: ldur            d0, [fp, #-0x18]
    // 0x62565c: StoreField: r0->field_f = d0
    //     0x62565c: stur            d0, [x0, #0xf]
    // 0x625660: b               #0x6256f8
    // 0x625664: LoadField: d0 = r1->field_7
    //     0x625664: ldur            d0, [x1, #7]
    // 0x625668: LoadField: d1 = r1->field_f
    //     0x625668: ldur            d1, [x1, #0xf]
    // 0x62566c: fadd            d2, d0, d1
    // 0x625670: stur            d2, [fp, #-0x20]
    // 0x625674: LoadField: d0 = r1->field_17
    //     0x625674: ldur            d0, [x1, #0x17]
    // 0x625678: stur            d0, [fp, #-0x18]
    // 0x62567c: r0 = Alignment()
    //     0x62567c: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x625680: ldur            d0, [fp, #-0x20]
    // 0x625684: StoreField: r0->field_7 = d0
    //     0x625684: stur            d0, [x0, #7]
    // 0x625688: ldur            d0, [fp, #-0x18]
    // 0x62568c: StoreField: r0->field_f = d0
    //     0x62568c: stur            d0, [x0, #0xf]
    // 0x625690: b               #0x6256f8
    // 0x625694: cmp             w2, NULL
    // 0x625698: b.eq            #0x625844
    // 0x62569c: LoadField: r0 = r2->field_7
    //     0x62569c: ldur            x0, [x2, #7]
    // 0x6256a0: cmp             x0, #0
    // 0x6256a4: b.gt            #0x6256d4
    // 0x6256a8: LoadField: d0 = r1->field_7
    //     0x6256a8: ldur            d0, [x1, #7]
    // 0x6256ac: fneg            d1, d0
    // 0x6256b0: stur            d1, [fp, #-0x20]
    // 0x6256b4: LoadField: d0 = r1->field_f
    //     0x6256b4: ldur            d0, [x1, #0xf]
    // 0x6256b8: stur            d0, [fp, #-0x18]
    // 0x6256bc: r0 = Alignment()
    //     0x6256bc: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x6256c0: ldur            d0, [fp, #-0x20]
    // 0x6256c4: StoreField: r0->field_7 = d0
    //     0x6256c4: stur            d0, [x0, #7]
    // 0x6256c8: ldur            d0, [fp, #-0x18]
    // 0x6256cc: StoreField: r0->field_f = d0
    //     0x6256cc: stur            d0, [x0, #0xf]
    // 0x6256d0: b               #0x6256f8
    // 0x6256d4: LoadField: d0 = r1->field_7
    //     0x6256d4: ldur            d0, [x1, #7]
    // 0x6256d8: stur            d0, [fp, #-0x20]
    // 0x6256dc: LoadField: d1 = r1->field_f
    //     0x6256dc: ldur            d1, [x1, #0xf]
    // 0x6256e0: stur            d1, [fp, #-0x18]
    // 0x6256e4: r0 = Alignment()
    //     0x6256e4: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x6256e8: ldur            d0, [fp, #-0x20]
    // 0x6256ec: StoreField: r0->field_7 = d0
    //     0x6256ec: stur            d0, [x0, #7]
    // 0x6256f0: ldur            d0, [fp, #-0x18]
    // 0x6256f4: StoreField: r0->field_f = d0
    //     0x6256f4: stur            d0, [x0, #0xf]
    // 0x6256f8: stur            x0, [fp, #-8]
    // 0x6256fc: cmp             w0, NULL
    // 0x625700: b.ne            #0x62571c
    // 0x625704: ldr             x1, [fp, #0x10]
    // 0x625708: LoadField: r0 = r1->field_73
    //     0x625708: ldur            w0, [x1, #0x73]
    // 0x62570c: DecompressPointer r0
    //     0x62570c: add             x0, x0, HEAP, lsl #32
    // 0x625710: LeaveFrame
    //     0x625710: mov             SP, fp
    //     0x625714: ldp             fp, lr, [SP], #0x10
    // 0x625718: ret
    //     0x625718: ret             
    // 0x62571c: ldr             x1, [fp, #0x10]
    // 0x625720: r0 = Matrix4()
    //     0x625720: bl              #0x50ace8  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x625724: r4 = 32
    //     0x625724: mov             x4, #0x20
    // 0x625728: stur            x0, [fp, #-0x10]
    // 0x62572c: r0 = AllocateFloat64Array()
    //     0x62572c: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0x625730: mov             x1, x0
    // 0x625734: ldur            x0, [fp, #-0x10]
    // 0x625738: StoreField: r0->field_7 = r1
    //     0x625738: stur            w1, [x0, #7]
    // 0x62573c: SaveReg r0
    //     0x62573c: str             x0, [SP, #-8]!
    // 0x625740: r0 = setIdentity()
    //     0x625740: bl              #0x50f090  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0x625744: add             SP, SP, #8
    // 0x625748: ldr             x0, [fp, #0x10]
    // 0x62574c: LoadField: r1 = r0->field_57
    //     0x62574c: ldur            w1, [x0, #0x57]
    // 0x625750: DecompressPointer r1
    //     0x625750: add             x1, x1, HEAP, lsl #32
    // 0x625754: cmp             w1, NULL
    // 0x625758: b.eq            #0x625848
    // 0x62575c: ldur            x16, [fp, #-8]
    // 0x625760: stp             x1, x16, [SP, #-0x10]!
    // 0x625764: r0 = alongOffset()
    //     0x625764: bl              #0x626350  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0x625768: add             SP, SP, #0x10
    // 0x62576c: LoadField: d0 = r0->field_7
    //     0x62576c: ldur            d0, [x0, #7]
    // 0x625770: stur            d0, [fp, #-0x20]
    // 0x625774: LoadField: d1 = r0->field_f
    //     0x625774: ldur            d1, [x0, #0xf]
    // 0x625778: stur            d1, [fp, #-0x18]
    // 0x62577c: r0 = inline_Allocate_Double()
    //     0x62577c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x625780: add             x0, x0, #0x10
    //     0x625784: cmp             x1, x0
    //     0x625788: b.ls            #0x62584c
    //     0x62578c: str             x0, [THR, #0x60]  ; THR::top
    //     0x625790: sub             x0, x0, #0xf
    //     0x625794: mov             x1, #0xd108
    //     0x625798: movk            x1, #3, lsl #16
    //     0x62579c: stur            x1, [x0, #-1]
    // 0x6257a0: StoreField: r0->field_7 = d0
    //     0x6257a0: stur            d0, [x0, #7]
    // 0x6257a4: ldur            x16, [fp, #-0x10]
    // 0x6257a8: stp             x0, x16, [SP, #-0x10]!
    // 0x6257ac: SaveReg d1
    //     0x6257ac: str             d1, [SP, #-8]!
    // 0x6257b0: r0 = translate()
    //     0x6257b0: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0x6257b4: add             SP, SP, #0x18
    // 0x6257b8: ldr             x0, [fp, #0x10]
    // 0x6257bc: LoadField: r1 = r0->field_73
    //     0x6257bc: ldur            w1, [x0, #0x73]
    // 0x6257c0: DecompressPointer r1
    //     0x6257c0: add             x1, x1, HEAP, lsl #32
    // 0x6257c4: cmp             w1, NULL
    // 0x6257c8: b.eq            #0x62585c
    // 0x6257cc: ldur            x16, [fp, #-0x10]
    // 0x6257d0: stp             x1, x16, [SP, #-0x10]!
    // 0x6257d4: r0 = multiply()
    //     0x6257d4: bl              #0x625d1c  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0x6257d8: add             SP, SP, #0x10
    // 0x6257dc: ldur            d0, [fp, #-0x20]
    // 0x6257e0: fneg            d1, d0
    // 0x6257e4: ldur            d0, [fp, #-0x18]
    // 0x6257e8: fneg            d2, d0
    // 0x6257ec: r0 = inline_Allocate_Double()
    //     0x6257ec: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6257f0: add             x0, x0, #0x10
    //     0x6257f4: cmp             x1, x0
    //     0x6257f8: b.ls            #0x625860
    //     0x6257fc: str             x0, [THR, #0x60]  ; THR::top
    //     0x625800: sub             x0, x0, #0xf
    //     0x625804: mov             x1, #0xd108
    //     0x625808: movk            x1, #3, lsl #16
    //     0x62580c: stur            x1, [x0, #-1]
    // 0x625810: StoreField: r0->field_7 = d1
    //     0x625810: stur            d1, [x0, #7]
    // 0x625814: ldur            x16, [fp, #-0x10]
    // 0x625818: stp             x0, x16, [SP, #-0x10]!
    // 0x62581c: SaveReg d2
    //     0x62581c: str             d2, [SP, #-8]!
    // 0x625820: r0 = translate()
    //     0x625820: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0x625824: add             SP, SP, #0x18
    // 0x625828: ldur            x0, [fp, #-0x10]
    // 0x62582c: LeaveFrame
    //     0x62582c: mov             SP, fp
    //     0x625830: ldp             fp, lr, [SP], #0x10
    // 0x625834: ret
    //     0x625834: ret             
    // 0x625838: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x625838: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62583c: b               #0x6255c4
    // 0x625840: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x625840: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x625844: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x625844: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x625848: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x625848: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x62584c: stp             q0, q1, [SP, #-0x20]!
    // 0x625850: r0 = AllocateDouble()
    //     0x625850: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x625854: ldp             q0, q1, [SP], #0x20
    // 0x625858: b               #0x6257a0
    // 0x62585c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x62585c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x625860: stp             q1, q2, [SP, #-0x20]!
    // 0x625864: r0 = AllocateDouble()
    //     0x625864: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x625868: ldp             q1, q2, [SP], #0x20
    // 0x62586c: b               #0x625810
  }
  [closure] bool <anonymous closure>(dynamic, BoxHitTestResult, Offset) {
    // ** addr: 0x6263b8, size: 0x54
    // 0x6263b8: EnterFrame
    //     0x6263b8: stp             fp, lr, [SP, #-0x10]!
    //     0x6263bc: mov             fp, SP
    // 0x6263c0: ldr             x0, [fp, #0x20]
    // 0x6263c4: LoadField: r1 = r0->field_17
    //     0x6263c4: ldur            w1, [x0, #0x17]
    // 0x6263c8: DecompressPointer r1
    //     0x6263c8: add             x1, x1, HEAP, lsl #32
    // 0x6263cc: CheckStackOverflow
    //     0x6263cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6263d0: cmp             SP, x16
    //     0x6263d4: b.ls            #0x626404
    // 0x6263d8: LoadField: r0 = r1->field_f
    //     0x6263d8: ldur            w0, [x1, #0xf]
    // 0x6263dc: DecompressPointer r0
    //     0x6263dc: add             x0, x0, HEAP, lsl #32
    // 0x6263e0: ldr             x16, [fp, #0x18]
    // 0x6263e4: stp             x16, x0, [SP, #-0x10]!
    // 0x6263e8: ldr             x16, [fp, #0x10]
    // 0x6263ec: SaveReg r16
    //     0x6263ec: str             x16, [SP, #-8]!
    // 0x6263f0: r0 = hitTestChildren()
    //     0x6263f0: bl              #0x627748  ; [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::hitTestChildren
    // 0x6263f4: add             SP, SP, #0x18
    // 0x6263f8: LeaveFrame
    //     0x6263f8: mov             SP, fp
    //     0x6263fc: ldp             fp, lr, [SP], #0x10
    // 0x626400: ret
    //     0x626400: ret             
    // 0x626404: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x626404: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x626408: b               #0x6263d8
  }
  _ hitTest(/* No info */) {
    // ** addr: 0x640478, size: 0x44
    // 0x640478: EnterFrame
    //     0x640478: stp             fp, lr, [SP, #-0x10]!
    //     0x64047c: mov             fp, SP
    // 0x640480: CheckStackOverflow
    //     0x640480: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x640484: cmp             SP, x16
    //     0x640488: b.ls            #0x6404b4
    // 0x64048c: ldr             x16, [fp, #0x20]
    // 0x640490: ldr             lr, [fp, #0x18]
    // 0x640494: stp             lr, x16, [SP, #-0x10]!
    // 0x640498: ldr             x16, [fp, #0x10]
    // 0x64049c: SaveReg r16
    //     0x64049c: str             x16, [SP, #-8]!
    // 0x6404a0: r0 = hitTestChildren()
    //     0x6404a0: bl              #0x625518  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::hitTestChildren
    // 0x6404a4: add             SP, SP, #0x18
    // 0x6404a8: LeaveFrame
    //     0x6404a8: mov             SP, fp
    //     0x6404ac: ldp             fp, lr, [SP], #0x10
    // 0x6404b0: ret
    //     0x6404b0: ret             
    // 0x6404b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6404b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6404b8: b               #0x64048c
  }
  _ paint(/* No info */) {
    // ** addr: 0x66561c, size: 0x1d4
    // 0x66561c: EnterFrame
    //     0x66561c: stp             fp, lr, [SP, #-0x10]!
    //     0x665620: mov             fp, SP
    // 0x665624: AllocStack(0x18)
    //     0x665624: sub             SP, SP, #0x18
    // 0x665628: CheckStackOverflow
    //     0x665628: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66562c: cmp             SP, x16
    //     0x665630: b.ls            #0x6657dc
    // 0x665634: ldr             x0, [fp, #0x20]
    // 0x665638: LoadField: r1 = r0->field_5f
    //     0x665638: ldur            w1, [x0, #0x5f]
    // 0x66563c: DecompressPointer r1
    //     0x66563c: add             x1, x1, HEAP, lsl #32
    // 0x665640: cmp             w1, NULL
    // 0x665644: b.eq            #0x6657cc
    // 0x665648: SaveReg r0
    //     0x665648: str             x0, [SP, #-8]!
    // 0x66564c: r0 = _effectiveTransform()
    //     0x66564c: bl              #0x6255ac  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::_effectiveTransform
    // 0x665650: add             SP, SP, #8
    // 0x665654: stur            x0, [fp, #-8]
    // 0x665658: cmp             w0, NULL
    // 0x66565c: b.eq            #0x6657e4
    // 0x665660: SaveReg r0
    //     0x665660: str             x0, [SP, #-8]!
    // 0x665664: r0 = getAsTranslation()
    //     0x665664: bl              #0x665a04  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::getAsTranslation
    // 0x665668: add             SP, SP, #8
    // 0x66566c: cmp             w0, NULL
    // 0x665670: b.ne            #0x665790
    // 0x665674: ldur            x16, [fp, #-8]
    // 0x665678: SaveReg r16
    //     0x665678: str             x16, [SP, #-8]!
    // 0x66567c: r0 = determinant()
    //     0x66567c: bl              #0x6657f0  ; [package:vector_math/vector_math_64.dart] Matrix4::determinant
    // 0x665680: add             SP, SP, #8
    // 0x665684: mov             v1.16b, v0.16b
    // 0x665688: d0 = 0.000000
    //     0x665688: eor             v0.16b, v0.16b, v0.16b
    // 0x66568c: fcmp            d1, d0
    // 0x665690: b.vs            #0x665698
    // 0x665694: b.eq            #0x665768
    // 0x665698: mov             x0, v1.d[0]
    // 0x66569c: and             x0, x0, #0x7fffffffffffffff
    // 0x6656a0: r17 = 9218868437227405312
    //     0x6656a0: mov             x17, #0x7ff0000000000000
    // 0x6656a4: cmp             x0, x17
    // 0x6656a8: b.eq            #0x665768
    // 0x6656ac: fcmp            d1, d1
    // 0x6656b0: b.vs            #0x665768
    // 0x6656b4: ldr             x0, [fp, #0x20]
    // 0x6656b8: LoadField: r1 = r0->field_37
    //     0x6656b8: ldur            w1, [x0, #0x37]
    // 0x6656bc: DecompressPointer r1
    //     0x6656bc: add             x1, x1, HEAP, lsl #32
    // 0x6656c0: r16 = Sentinel
    //     0x6656c0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6656c4: cmp             w1, w16
    // 0x6656c8: b.eq            #0x6657e8
    // 0x6656cc: stur            x1, [fp, #-0x10]
    // 0x6656d0: r1 = 1
    //     0x6656d0: mov             x1, #1
    // 0x6656d4: r0 = AllocateContext()
    //     0x6656d4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6656d8: mov             x1, x0
    // 0x6656dc: ldr             x0, [fp, #0x20]
    // 0x6656e0: StoreField: r1->field_f = r0
    //     0x6656e0: stur            w0, [x1, #0xf]
    // 0x6656e4: LoadField: r2 = r0->field_2f
    //     0x6656e4: ldur            w2, [x0, #0x2f]
    // 0x6656e8: DecompressPointer r2
    //     0x6656e8: add             x2, x2, HEAP, lsl #32
    // 0x6656ec: LoadField: r3 = r2->field_b
    //     0x6656ec: ldur            w3, [x2, #0xb]
    // 0x6656f0: DecompressPointer r3
    //     0x6656f0: add             x3, x3, HEAP, lsl #32
    // 0x6656f4: r2 = LoadClassIdInstr(r3)
    //     0x6656f4: ldur            x2, [x3, #-1]
    //     0x6656f8: ubfx            x2, x2, #0xc, #0x14
    // 0x6656fc: lsl             x2, x2, #1
    // 0x665700: r17 = 4784
    //     0x665700: mov             x17, #0x12b0
    // 0x665704: cmp             w2, w17
    // 0x665708: b.eq            #0x665710
    // 0x66570c: r3 = Null
    //     0x66570c: mov             x3, NULL
    // 0x665710: mov             x2, x1
    // 0x665714: stur            x3, [fp, #-0x18]
    // 0x665718: r1 = Function 'paint':.
    //     0x665718: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cef0] AnonymousClosure: (0x661630), in [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::paint (0x669ddc)
    //     0x66571c: ldr             x1, [x1, #0xef0]
    // 0x665720: r0 = AllocateClosure()
    //     0x665720: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x665724: ldr             x16, [fp, #0x18]
    // 0x665728: ldur            lr, [fp, #-0x10]
    // 0x66572c: stp             lr, x16, [SP, #-0x10]!
    // 0x665730: ldr             x16, [fp, #0x10]
    // 0x665734: ldur            lr, [fp, #-8]
    // 0x665738: stp             lr, x16, [SP, #-0x10]!
    // 0x66573c: ldur            x16, [fp, #-0x18]
    // 0x665740: stp             x16, x0, [SP, #-0x10]!
    // 0x665744: r4 = const [0, 0x6, 0x6, 0x5, oldLayer, 0x5, null]
    //     0x665744: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1cef8] List(7) [0, 0x6, 0x6, 0x5, "oldLayer", 0x5, Null]
    //     0x665748: ldr             x4, [x4, #0xef8]
    // 0x66574c: r0 = pushTransform()
    //     0x66574c: bl              #0x65d108  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushTransform
    // 0x665750: add             SP, SP, #0x30
    // 0x665754: ldr             x16, [fp, #0x20]
    // 0x665758: stp             x0, x16, [SP, #-0x10]!
    // 0x66575c: r0 = layer=()
    //     0x66575c: bl              #0x661124  ; [package:flutter/src/rendering/object.dart] RenderObject::layer=
    // 0x665760: add             SP, SP, #0x10
    // 0x665764: b               #0x6657cc
    // 0x665768: ldr             x1, [fp, #0x20]
    // 0x66576c: LoadField: r0 = r1->field_2f
    //     0x66576c: ldur            w0, [x1, #0x2f]
    // 0x665770: DecompressPointer r0
    //     0x665770: add             x0, x0, HEAP, lsl #32
    // 0x665774: stp             NULL, x0, [SP, #-0x10]!
    // 0x665778: r0 = layer=()
    //     0x665778: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x66577c: add             SP, SP, #0x10
    // 0x665780: r0 = Null
    //     0x665780: mov             x0, NULL
    // 0x665784: LeaveFrame
    //     0x665784: mov             SP, fp
    //     0x665788: ldp             fp, lr, [SP], #0x10
    // 0x66578c: ret
    //     0x66578c: ret             
    // 0x665790: ldr             x1, [fp, #0x20]
    // 0x665794: ldr             x16, [fp, #0x10]
    // 0x665798: stp             x0, x16, [SP, #-0x10]!
    // 0x66579c: r0 = +()
    //     0x66579c: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x6657a0: add             SP, SP, #0x10
    // 0x6657a4: ldr             x16, [fp, #0x20]
    // 0x6657a8: ldr             lr, [fp, #0x18]
    // 0x6657ac: stp             lr, x16, [SP, #-0x10]!
    // 0x6657b0: SaveReg r0
    //     0x6657b0: str             x0, [SP, #-8]!
    // 0x6657b4: r0 = paint()
    //     0x6657b4: bl              #0x669ddc  ; [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::paint
    // 0x6657b8: add             SP, SP, #0x18
    // 0x6657bc: ldr             x16, [fp, #0x20]
    // 0x6657c0: stp             NULL, x16, [SP, #-0x10]!
    // 0x6657c4: r0 = layer=()
    //     0x6657c4: bl              #0x661124  ; [package:flutter/src/rendering/object.dart] RenderObject::layer=
    // 0x6657c8: add             SP, SP, #0x10
    // 0x6657cc: r0 = Null
    //     0x6657cc: mov             x0, NULL
    // 0x6657d0: LeaveFrame
    //     0x6657d0: mov             SP, fp
    //     0x6657d4: ldp             fp, lr, [SP], #0x10
    // 0x6657d8: ret
    //     0x6657d8: ret             
    // 0x6657dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6657dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6657e0: b               #0x665634
    // 0x6657e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6657e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6657e8: r9 = _needsCompositing
    //     0x6657e8: ldr             x9, [PP, #0x4b28]  ; [pp+0x4b28] Field <RenderObject._needsCompositing@904266271>: late (offset: 0x38)
    // 0x6657ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6657ec: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0x6bc34c, size: 0x94
    // 0x6bc34c: EnterFrame
    //     0x6bc34c: stp             fp, lr, [SP, #-0x10]!
    //     0x6bc350: mov             fp, SP
    // 0x6bc354: CheckStackOverflow
    //     0x6bc354: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bc358: cmp             SP, x16
    //     0x6bc35c: b.ls            #0x6bc3d4
    // 0x6bc360: ldr             x0, [fp, #0x18]
    // 0x6bc364: r2 = Null
    //     0x6bc364: mov             x2, NULL
    // 0x6bc368: r1 = Null
    //     0x6bc368: mov             x1, NULL
    // 0x6bc36c: r4 = 59
    //     0x6bc36c: mov             x4, #0x3b
    // 0x6bc370: branchIfSmi(r0, 0x6bc37c)
    //     0x6bc370: tbz             w0, #0, #0x6bc37c
    // 0x6bc374: r4 = LoadClassIdInstr(r0)
    //     0x6bc374: ldur            x4, [x0, #-1]
    //     0x6bc378: ubfx            x4, x4, #0xc, #0x14
    // 0x6bc37c: sub             x4, x4, #0x965
    // 0x6bc380: cmp             x4, #0x8b
    // 0x6bc384: b.ls            #0x6bc39c
    // 0x6bc388: r8 = RenderBox
    //     0x6bc388: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x6bc38c: ldr             x8, [x8, #0xfa0]
    // 0x6bc390: r3 = Null
    //     0x6bc390: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1cee0] Null
    //     0x6bc394: ldr             x3, [x3, #0xee0]
    // 0x6bc398: r0 = RenderBox()
    //     0x6bc398: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x6bc39c: ldr             x16, [fp, #0x20]
    // 0x6bc3a0: SaveReg r16
    //     0x6bc3a0: str             x16, [SP, #-8]!
    // 0x6bc3a4: r0 = _effectiveTransform()
    //     0x6bc3a4: bl              #0x6255ac  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::_effectiveTransform
    // 0x6bc3a8: add             SP, SP, #8
    // 0x6bc3ac: cmp             w0, NULL
    // 0x6bc3b0: b.eq            #0x6bc3dc
    // 0x6bc3b4: ldr             x16, [fp, #0x10]
    // 0x6bc3b8: stp             x0, x16, [SP, #-0x10]!
    // 0x6bc3bc: r0 = multiply()
    //     0x6bc3bc: bl              #0x625d1c  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0x6bc3c0: add             SP, SP, #0x10
    // 0x6bc3c4: r0 = Null
    //     0x6bc3c4: mov             x0, NULL
    // 0x6bc3c8: LeaveFrame
    //     0x6bc3c8: mov             SP, fp
    //     0x6bc3cc: ldp             fp, lr, [SP], #0x10
    // 0x6bc3d0: ret
    //     0x6bc3d0: ret             
    // 0x6bc3d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bc3d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bc3d8: b               #0x6bc360
    // 0x6bc3dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6bc3dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0x6c47a0, size: 0x90
    // 0x6c47a0: EnterFrame
    //     0x6c47a0: stp             fp, lr, [SP, #-0x10]!
    //     0x6c47a4: mov             fp, SP
    // 0x6c47a8: CheckStackOverflow
    //     0x6c47a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c47ac: cmp             SP, x16
    //     0x6c47b0: b.ls            #0x6c4828
    // 0x6c47b4: ldr             x1, [fp, #0x18]
    // 0x6c47b8: LoadField: r0 = r1->field_6b
    //     0x6c47b8: ldur            w0, [x1, #0x6b]
    // 0x6c47bc: DecompressPointer r0
    //     0x6c47bc: add             x0, x0, HEAP, lsl #32
    // 0x6c47c0: ldr             x2, [fp, #0x10]
    // 0x6c47c4: cmp             w0, w2
    // 0x6c47c8: b.ne            #0x6c47dc
    // 0x6c47cc: r0 = Null
    //     0x6c47cc: mov             x0, NULL
    // 0x6c47d0: LeaveFrame
    //     0x6c47d0: mov             SP, fp
    //     0x6c47d4: ldp             fp, lr, [SP], #0x10
    // 0x6c47d8: ret
    //     0x6c47d8: ret             
    // 0x6c47dc: mov             x0, x2
    // 0x6c47e0: StoreField: r1->field_6b = r0
    //     0x6c47e0: stur            w0, [x1, #0x6b]
    //     0x6c47e4: ldurb           w16, [x1, #-1]
    //     0x6c47e8: ldurb           w17, [x0, #-1]
    //     0x6c47ec: and             x16, x17, x16, lsr #2
    //     0x6c47f0: tst             x16, HEAP, lsr #32
    //     0x6c47f4: b.eq            #0x6c47fc
    //     0x6c47f8: bl              #0xd6826c
    // 0x6c47fc: SaveReg r1
    //     0x6c47fc: str             x1, [SP, #-8]!
    // 0x6c4800: r0 = markNeedsPaint()
    //     0x6c4800: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c4804: add             SP, SP, #8
    // 0x6c4808: ldr             x16, [fp, #0x18]
    // 0x6c480c: SaveReg r16
    //     0x6c480c: str             x16, [SP, #-8]!
    // 0x6c4810: r0 = markNeedsSemanticsUpdate()
    //     0x6c4810: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6c4814: add             SP, SP, #8
    // 0x6c4818: r0 = Null
    //     0x6c4818: mov             x0, NULL
    // 0x6c481c: LeaveFrame
    //     0x6c481c: mov             SP, fp
    //     0x6c4820: ldp             fp, lr, [SP], #0x10
    // 0x6c4824: ret
    //     0x6c4824: ret             
    // 0x6c4828: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c4828: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c482c: b               #0x6c47b4
  }
  set _ alignment=(/* No info */) {
    // ** addr: 0x6c4830, size: 0xb0
    // 0x6c4830: EnterFrame
    //     0x6c4830: stp             fp, lr, [SP, #-0x10]!
    //     0x6c4834: mov             fp, SP
    // 0x6c4838: CheckStackOverflow
    //     0x6c4838: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c483c: cmp             SP, x16
    //     0x6c4840: b.ls            #0x6c48d8
    // 0x6c4844: ldr             x1, [fp, #0x18]
    // 0x6c4848: LoadField: r0 = r1->field_67
    //     0x6c4848: ldur            w0, [x1, #0x67]
    // 0x6c484c: DecompressPointer r0
    //     0x6c484c: add             x0, x0, HEAP, lsl #32
    // 0x6c4850: r2 = LoadClassIdInstr(r0)
    //     0x6c4850: ldur            x2, [x0, #-1]
    //     0x6c4854: ubfx            x2, x2, #0xc, #0x14
    // 0x6c4858: ldr             x16, [fp, #0x10]
    // 0x6c485c: stp             x16, x0, [SP, #-0x10]!
    // 0x6c4860: mov             x0, x2
    // 0x6c4864: mov             lr, x0
    // 0x6c4868: ldr             lr, [x21, lr, lsl #3]
    // 0x6c486c: blr             lr
    // 0x6c4870: add             SP, SP, #0x10
    // 0x6c4874: tbnz            w0, #4, #0x6c4888
    // 0x6c4878: r0 = Null
    //     0x6c4878: mov             x0, NULL
    // 0x6c487c: LeaveFrame
    //     0x6c487c: mov             SP, fp
    //     0x6c4880: ldp             fp, lr, [SP], #0x10
    // 0x6c4884: ret
    //     0x6c4884: ret             
    // 0x6c4888: ldr             x1, [fp, #0x18]
    // 0x6c488c: ldr             x0, [fp, #0x10]
    // 0x6c4890: StoreField: r1->field_67 = r0
    //     0x6c4890: stur            w0, [x1, #0x67]
    //     0x6c4894: ldurb           w16, [x1, #-1]
    //     0x6c4898: ldurb           w17, [x0, #-1]
    //     0x6c489c: and             x16, x17, x16, lsr #2
    //     0x6c48a0: tst             x16, HEAP, lsr #32
    //     0x6c48a4: b.eq            #0x6c48ac
    //     0x6c48a8: bl              #0xd6826c
    // 0x6c48ac: SaveReg r1
    //     0x6c48ac: str             x1, [SP, #-8]!
    // 0x6c48b0: r0 = markNeedsPaint()
    //     0x6c48b0: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c48b4: add             SP, SP, #8
    // 0x6c48b8: ldr             x16, [fp, #0x18]
    // 0x6c48bc: SaveReg r16
    //     0x6c48bc: str             x16, [SP, #-8]!
    // 0x6c48c0: r0 = markNeedsSemanticsUpdate()
    //     0x6c48c0: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6c48c4: add             SP, SP, #8
    // 0x6c48c8: r0 = Null
    //     0x6c48c8: mov             x0, NULL
    // 0x6c48cc: LeaveFrame
    //     0x6c48cc: mov             SP, fp
    //     0x6c48d0: ldp             fp, lr, [SP], #0x10
    // 0x6c48d4: ret
    //     0x6c48d4: ret             
    // 0x6c48d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c48d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c48dc: b               #0x6c4844
  }
  set _ transform=(/* No info */) {
    // ** addr: 0x6c48e0, size: 0xe4
    // 0x6c48e0: EnterFrame
    //     0x6c48e0: stp             fp, lr, [SP, #-0x10]!
    //     0x6c48e4: mov             fp, SP
    // 0x6c48e8: AllocStack(0x8)
    //     0x6c48e8: sub             SP, SP, #8
    // 0x6c48ec: CheckStackOverflow
    //     0x6c48ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c48f0: cmp             SP, x16
    //     0x6c48f4: b.ls            #0x6c49bc
    // 0x6c48f8: ldr             x1, [fp, #0x18]
    // 0x6c48fc: LoadField: r0 = r1->field_73
    //     0x6c48fc: ldur            w0, [x1, #0x73]
    // 0x6c4900: DecompressPointer r0
    //     0x6c4900: add             x0, x0, HEAP, lsl #32
    // 0x6c4904: r2 = LoadClassIdInstr(r0)
    //     0x6c4904: ldur            x2, [x0, #-1]
    //     0x6c4908: ubfx            x2, x2, #0xc, #0x14
    // 0x6c490c: ldr             x16, [fp, #0x10]
    // 0x6c4910: stp             x16, x0, [SP, #-0x10]!
    // 0x6c4914: mov             x0, x2
    // 0x6c4918: mov             lr, x0
    // 0x6c491c: ldr             lr, [x21, lr, lsl #3]
    // 0x6c4920: blr             lr
    // 0x6c4924: add             SP, SP, #0x10
    // 0x6c4928: tbnz            w0, #4, #0x6c493c
    // 0x6c492c: r0 = Null
    //     0x6c492c: mov             x0, NULL
    // 0x6c4930: LeaveFrame
    //     0x6c4930: mov             SP, fp
    //     0x6c4934: ldp             fp, lr, [SP], #0x10
    // 0x6c4938: ret
    //     0x6c4938: ret             
    // 0x6c493c: ldr             x0, [fp, #0x18]
    // 0x6c4940: r0 = Matrix4()
    //     0x6c4940: bl              #0x50ace8  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x6c4944: r4 = 32
    //     0x6c4944: mov             x4, #0x20
    // 0x6c4948: stur            x0, [fp, #-8]
    // 0x6c494c: r0 = AllocateFloat64Array()
    //     0x6c494c: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0x6c4950: mov             x1, x0
    // 0x6c4954: ldur            x0, [fp, #-8]
    // 0x6c4958: StoreField: r0->field_7 = r1
    //     0x6c4958: stur            w1, [x0, #7]
    // 0x6c495c: ldr             x16, [fp, #0x10]
    // 0x6c4960: stp             x16, x0, [SP, #-0x10]!
    // 0x6c4964: r0 = setFrom()
    //     0x6c4964: bl              #0x50aad0  ; [package:vector_math/vector_math_64.dart] Matrix4::setFrom
    // 0x6c4968: add             SP, SP, #0x10
    // 0x6c496c: ldur            x0, [fp, #-8]
    // 0x6c4970: ldr             x1, [fp, #0x18]
    // 0x6c4974: StoreField: r1->field_73 = r0
    //     0x6c4974: stur            w0, [x1, #0x73]
    //     0x6c4978: ldurb           w16, [x1, #-1]
    //     0x6c497c: ldurb           w17, [x0, #-1]
    //     0x6c4980: and             x16, x17, x16, lsr #2
    //     0x6c4984: tst             x16, HEAP, lsr #32
    //     0x6c4988: b.eq            #0x6c4990
    //     0x6c498c: bl              #0xd6826c
    // 0x6c4990: SaveReg r1
    //     0x6c4990: str             x1, [SP, #-8]!
    // 0x6c4994: r0 = markNeedsPaint()
    //     0x6c4994: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c4998: add             SP, SP, #8
    // 0x6c499c: ldr             x16, [fp, #0x18]
    // 0x6c49a0: SaveReg r16
    //     0x6c49a0: str             x16, [SP, #-8]!
    // 0x6c49a4: r0 = markNeedsSemanticsUpdate()
    //     0x6c49a4: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6c49a8: add             SP, SP, #8
    // 0x6c49ac: r0 = Null
    //     0x6c49ac: mov             x0, NULL
    // 0x6c49b0: LeaveFrame
    //     0x6c49b0: mov             SP, fp
    //     0x6c49b4: ldp             fp, lr, [SP], #0x10
    // 0x6c49b8: ret
    //     0x6c49b8: ret             
    // 0x6c49bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c49bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c49c0: b               #0x6c48f8
  }
  _ RenderTransform(/* No info */) {
    // ** addr: 0x6eb58c, size: 0x90
    // 0x6eb58c: EnterFrame
    //     0x6eb58c: stp             fp, lr, [SP, #-0x10]!
    //     0x6eb590: mov             fp, SP
    // 0x6eb594: CheckStackOverflow
    //     0x6eb594: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6eb598: cmp             SP, x16
    //     0x6eb59c: b.ls            #0x6eb614
    // 0x6eb5a0: ldr             x1, [fp, #0x30]
    // 0x6eb5a4: ldr             x0, [fp, #0x10]
    // 0x6eb5a8: StoreField: r1->field_6f = r0
    //     0x6eb5a8: stur            w0, [x1, #0x6f]
    // 0x6eb5ac: SaveReg r1
    //     0x6eb5ac: str             x1, [SP, #-8]!
    // 0x6eb5b0: r0 = RenderObject()
    //     0x6eb5b0: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6eb5b4: add             SP, SP, #8
    // 0x6eb5b8: ldr             x16, [fp, #0x30]
    // 0x6eb5bc: stp             NULL, x16, [SP, #-0x10]!
    // 0x6eb5c0: r0 = child=()
    //     0x6eb5c0: bl              #0x6e7da0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::child=
    // 0x6eb5c4: add             SP, SP, #0x10
    // 0x6eb5c8: ldr             x16, [fp, #0x30]
    // 0x6eb5cc: ldr             lr, [fp, #0x18]
    // 0x6eb5d0: stp             lr, x16, [SP, #-0x10]!
    // 0x6eb5d4: r0 = transform=()
    //     0x6eb5d4: bl              #0x6c48e0  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::transform=
    // 0x6eb5d8: add             SP, SP, #0x10
    // 0x6eb5dc: ldr             x16, [fp, #0x30]
    // 0x6eb5e0: ldr             lr, [fp, #0x28]
    // 0x6eb5e4: stp             lr, x16, [SP, #-0x10]!
    // 0x6eb5e8: r0 = alignment=()
    //     0x6eb5e8: bl              #0x6c4830  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::alignment=
    // 0x6eb5ec: add             SP, SP, #0x10
    // 0x6eb5f0: ldr             x16, [fp, #0x30]
    // 0x6eb5f4: ldr             lr, [fp, #0x20]
    // 0x6eb5f8: stp             lr, x16, [SP, #-0x10]!
    // 0x6eb5fc: r0 = textDirection=()
    //     0x6eb5fc: bl              #0x6c47a0  ; [package:flutter/src/rendering/proxy_box.dart] RenderTransform::textDirection=
    // 0x6eb600: add             SP, SP, #0x10
    // 0x6eb604: r0 = Null
    //     0x6eb604: mov             x0, NULL
    // 0x6eb608: LeaveFrame
    //     0x6eb608: mov             SP, fp
    //     0x6eb60c: ldp             fp, lr, [SP], #0x10
    // 0x6eb610: ret
    //     0x6eb610: ret             
    // 0x6eb614: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6eb614: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6eb618: b               #0x6eb5a0
  }
}

// class id: 2495, size: 0x74, field offset: 0x64
class RenderDecoratedBox extends RenderProxyBox {

  _ hitTestSelf(/* No info */) {
    // ** addr: 0x62b6a0, size: 0x84
    // 0x62b6a0: EnterFrame
    //     0x62b6a0: stp             fp, lr, [SP, #-0x10]!
    //     0x62b6a4: mov             fp, SP
    // 0x62b6a8: CheckStackOverflow
    //     0x62b6a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62b6ac: cmp             SP, x16
    //     0x62b6b0: b.ls            #0x62b718
    // 0x62b6b4: ldr             x0, [fp, #0x18]
    // 0x62b6b8: LoadField: r1 = r0->field_67
    //     0x62b6b8: ldur            w1, [x0, #0x67]
    // 0x62b6bc: DecompressPointer r1
    //     0x62b6bc: add             x1, x1, HEAP, lsl #32
    // 0x62b6c0: LoadField: r2 = r0->field_57
    //     0x62b6c0: ldur            w2, [x0, #0x57]
    // 0x62b6c4: DecompressPointer r2
    //     0x62b6c4: add             x2, x2, HEAP, lsl #32
    // 0x62b6c8: cmp             w2, NULL
    // 0x62b6cc: b.eq            #0x62b720
    // 0x62b6d0: LoadField: r3 = r0->field_6f
    //     0x62b6d0: ldur            w3, [x0, #0x6f]
    // 0x62b6d4: DecompressPointer r3
    //     0x62b6d4: add             x3, x3, HEAP, lsl #32
    // 0x62b6d8: LoadField: r0 = r3->field_13
    //     0x62b6d8: ldur            w0, [x3, #0x13]
    // 0x62b6dc: DecompressPointer r0
    //     0x62b6dc: add             x0, x0, HEAP, lsl #32
    // 0x62b6e0: r3 = LoadClassIdInstr(r1)
    //     0x62b6e0: ldur            x3, [x1, #-1]
    //     0x62b6e4: ubfx            x3, x3, #0xc, #0x14
    // 0x62b6e8: stp             x2, x1, [SP, #-0x10]!
    // 0x62b6ec: ldr             x16, [fp, #0x10]
    // 0x62b6f0: stp             x0, x16, [SP, #-0x10]!
    // 0x62b6f4: mov             x0, x3
    // 0x62b6f8: r0 = GDT[cid_x0 + 0x2380]()
    //     0x62b6f8: mov             x17, #0x2380
    //     0x62b6fc: add             lr, x0, x17
    //     0x62b700: ldr             lr, [x21, lr, lsl #3]
    //     0x62b704: blr             lr
    // 0x62b708: add             SP, SP, #0x20
    // 0x62b70c: LeaveFrame
    //     0x62b70c: mov             SP, fp
    //     0x62b710: ldp             fp, lr, [SP], #0x10
    // 0x62b714: ret
    //     0x62b714: ret             
    // 0x62b718: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62b718: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62b71c: b               #0x62b6b4
    // 0x62b720: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x62b720: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0x665268, size: 0x27c
    // 0x665268: EnterFrame
    //     0x665268: stp             fp, lr, [SP, #-0x10]!
    //     0x66526c: mov             fp, SP
    // 0x665270: AllocStack(0x10)
    //     0x665270: sub             SP, SP, #0x10
    // 0x665274: CheckStackOverflow
    //     0x665274: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x665278: cmp             SP, x16
    //     0x66527c: b.ls            #0x6654d0
    // 0x665280: ldr             x0, [fp, #0x20]
    // 0x665284: LoadField: r1 = r0->field_63
    //     0x665284: ldur            w1, [x0, #0x63]
    // 0x665288: DecompressPointer r1
    //     0x665288: add             x1, x1, HEAP, lsl #32
    // 0x66528c: cmp             w1, NULL
    // 0x665290: b.ne            #0x665310
    // 0x665294: LoadField: r1 = r0->field_67
    //     0x665294: ldur            w1, [x0, #0x67]
    // 0x665298: DecompressPointer r1
    //     0x665298: add             x1, x1, HEAP, lsl #32
    // 0x66529c: stur            x1, [fp, #-8]
    // 0x6652a0: r1 = 1
    //     0x6652a0: mov             x1, #1
    // 0x6652a4: r0 = AllocateContext()
    //     0x6652a4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6652a8: mov             x1, x0
    // 0x6652ac: ldr             x0, [fp, #0x20]
    // 0x6652b0: StoreField: r1->field_f = r0
    //     0x6652b0: stur            w0, [x1, #0xf]
    // 0x6652b4: mov             x2, x1
    // 0x6652b8: r1 = Function 'markNeedsPaint':.
    //     0x6652b8: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x6652bc: ldr             x1, [x1, #0xf60]
    // 0x6652c0: r0 = AllocateClosure()
    //     0x6652c0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6652c4: mov             x1, x0
    // 0x6652c8: ldur            x0, [fp, #-8]
    // 0x6652cc: r2 = LoadClassIdInstr(r0)
    //     0x6652cc: ldur            x2, [x0, #-1]
    //     0x6652d0: ubfx            x2, x2, #0xc, #0x14
    // 0x6652d4: stp             x1, x0, [SP, #-0x10]!
    // 0x6652d8: mov             x0, x2
    // 0x6652dc: r0 = GDT[cid_x0 + -0xc50]()
    //     0x6652dc: sub             lr, x0, #0xc50
    //     0x6652e0: ldr             lr, [x21, lr, lsl #3]
    //     0x6652e4: blr             lr
    // 0x6652e8: add             SP, SP, #0x10
    // 0x6652ec: ldr             x1, [fp, #0x20]
    // 0x6652f0: StoreField: r1->field_63 = r0
    //     0x6652f0: stur            w0, [x1, #0x63]
    //     0x6652f4: ldurb           w16, [x1, #-1]
    //     0x6652f8: ldurb           w17, [x0, #-1]
    //     0x6652fc: and             x16, x17, x16, lsr #2
    //     0x665300: tst             x16, HEAP, lsr #32
    //     0x665304: b.eq            #0x66530c
    //     0x665308: bl              #0xd6826c
    // 0x66530c: b               #0x665314
    // 0x665310: mov             x1, x0
    // 0x665314: LoadField: r0 = r1->field_6f
    //     0x665314: ldur            w0, [x1, #0x6f]
    // 0x665318: DecompressPointer r0
    //     0x665318: add             x0, x0, HEAP, lsl #32
    // 0x66531c: LoadField: r2 = r1->field_57
    //     0x66531c: ldur            w2, [x1, #0x57]
    // 0x665320: DecompressPointer r2
    //     0x665320: add             x2, x2, HEAP, lsl #32
    // 0x665324: cmp             w2, NULL
    // 0x665328: b.eq            #0x6654d8
    // 0x66532c: stp             x2, x0, [SP, #-0x10]!
    // 0x665330: r0 = copyWith()
    //     0x665330: bl              #0x665584  ; [package:flutter/src/painting/image_provider.dart] ImageConfiguration::copyWith
    // 0x665334: add             SP, SP, #0x10
    // 0x665338: mov             x1, x0
    // 0x66533c: ldr             x0, [fp, #0x20]
    // 0x665340: stur            x1, [fp, #-0x10]
    // 0x665344: LoadField: r2 = r0->field_6b
    //     0x665344: ldur            w2, [x0, #0x6b]
    // 0x665348: DecompressPointer r2
    //     0x665348: add             x2, x2, HEAP, lsl #32
    // 0x66534c: r16 = Instance_DecorationPosition
    //     0x66534c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf1b0] Obj!DecorationPosition@b648d1
    //     0x665350: ldr             x16, [x16, #0x1b0]
    // 0x665354: cmp             w2, w16
    // 0x665358: b.ne            #0x6653f4
    // 0x66535c: LoadField: r2 = r0->field_63
    //     0x66535c: ldur            w2, [x0, #0x63]
    // 0x665360: DecompressPointer r2
    //     0x665360: add             x2, x2, HEAP, lsl #32
    // 0x665364: stur            x2, [fp, #-8]
    // 0x665368: cmp             w2, NULL
    // 0x66536c: b.eq            #0x6654dc
    // 0x665370: ldr             x16, [fp, #0x18]
    // 0x665374: SaveReg r16
    //     0x665374: str             x16, [SP, #-8]!
    // 0x665378: r0 = canvas()
    //     0x665378: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x66537c: add             SP, SP, #8
    // 0x665380: mov             x1, x0
    // 0x665384: ldur            x0, [fp, #-8]
    // 0x665388: r2 = LoadClassIdInstr(r0)
    //     0x665388: ldur            x2, [x0, #-1]
    //     0x66538c: ubfx            x2, x2, #0xc, #0x14
    // 0x665390: stp             x1, x0, [SP, #-0x10]!
    // 0x665394: ldr             x16, [fp, #0x10]
    // 0x665398: ldur            lr, [fp, #-0x10]
    // 0x66539c: stp             lr, x16, [SP, #-0x10]!
    // 0x6653a0: mov             x0, x2
    // 0x6653a4: r0 = GDT[cid_x0 + -0x3e]()
    //     0x6653a4: sub             lr, x0, #0x3e
    //     0x6653a8: ldr             lr, [x21, lr, lsl #3]
    //     0x6653ac: blr             lr
    // 0x6653b0: add             SP, SP, #0x20
    // 0x6653b4: ldr             x1, [fp, #0x20]
    // 0x6653b8: LoadField: r0 = r1->field_67
    //     0x6653b8: ldur            w0, [x1, #0x67]
    // 0x6653bc: DecompressPointer r0
    //     0x6653bc: add             x0, x0, HEAP, lsl #32
    // 0x6653c0: r2 = LoadClassIdInstr(r0)
    //     0x6653c0: ldur            x2, [x0, #-1]
    //     0x6653c4: ubfx            x2, x2, #0xc, #0x14
    // 0x6653c8: SaveReg r0
    //     0x6653c8: str             x0, [SP, #-8]!
    // 0x6653cc: mov             x0, x2
    // 0x6653d0: r0 = GDT[cid_x0 + 0xf1a]()
    //     0x6653d0: add             lr, x0, #0xf1a
    //     0x6653d4: ldr             lr, [x21, lr, lsl #3]
    //     0x6653d8: blr             lr
    // 0x6653dc: add             SP, SP, #8
    // 0x6653e0: tbnz            w0, #4, #0x6653f4
    // 0x6653e4: ldr             x16, [fp, #0x18]
    // 0x6653e8: SaveReg r16
    //     0x6653e8: str             x16, [SP, #-8]!
    // 0x6653ec: r0 = setIsComplexHint()
    //     0x6653ec: bl              #0x6654e4  ; [package:flutter/src/rendering/object.dart] PaintingContext::setIsComplexHint
    // 0x6653f0: add             SP, SP, #8
    // 0x6653f4: ldr             x0, [fp, #0x20]
    // 0x6653f8: ldr             x16, [fp, #0x18]
    // 0x6653fc: stp             x16, x0, [SP, #-0x10]!
    // 0x665400: ldr             x16, [fp, #0x10]
    // 0x665404: SaveReg r16
    //     0x665404: str             x16, [SP, #-8]!
    // 0x665408: r0 = paint()
    //     0x665408: bl              #0x669ddc  ; [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::paint
    // 0x66540c: add             SP, SP, #0x18
    // 0x665410: ldr             x0, [fp, #0x20]
    // 0x665414: LoadField: r1 = r0->field_6b
    //     0x665414: ldur            w1, [x0, #0x6b]
    // 0x665418: DecompressPointer r1
    //     0x665418: add             x1, x1, HEAP, lsl #32
    // 0x66541c: r16 = Instance_DecorationPosition
    //     0x66541c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf1b8] Obj!DecorationPosition@b648b1
    //     0x665420: ldr             x16, [x16, #0x1b8]
    // 0x665424: cmp             w1, w16
    // 0x665428: b.ne            #0x6654c0
    // 0x66542c: LoadField: r1 = r0->field_63
    //     0x66542c: ldur            w1, [x0, #0x63]
    // 0x665430: DecompressPointer r1
    //     0x665430: add             x1, x1, HEAP, lsl #32
    // 0x665434: stur            x1, [fp, #-8]
    // 0x665438: cmp             w1, NULL
    // 0x66543c: b.eq            #0x6654e0
    // 0x665440: ldr             x16, [fp, #0x18]
    // 0x665444: SaveReg r16
    //     0x665444: str             x16, [SP, #-8]!
    // 0x665448: r0 = canvas()
    //     0x665448: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x66544c: add             SP, SP, #8
    // 0x665450: mov             x1, x0
    // 0x665454: ldur            x0, [fp, #-8]
    // 0x665458: r2 = LoadClassIdInstr(r0)
    //     0x665458: ldur            x2, [x0, #-1]
    //     0x66545c: ubfx            x2, x2, #0xc, #0x14
    // 0x665460: stp             x1, x0, [SP, #-0x10]!
    // 0x665464: ldr             x16, [fp, #0x10]
    // 0x665468: ldur            lr, [fp, #-0x10]
    // 0x66546c: stp             lr, x16, [SP, #-0x10]!
    // 0x665470: mov             x0, x2
    // 0x665474: r0 = GDT[cid_x0 + -0x3e]()
    //     0x665474: sub             lr, x0, #0x3e
    //     0x665478: ldr             lr, [x21, lr, lsl #3]
    //     0x66547c: blr             lr
    // 0x665480: add             SP, SP, #0x20
    // 0x665484: ldr             x0, [fp, #0x20]
    // 0x665488: LoadField: r1 = r0->field_67
    //     0x665488: ldur            w1, [x0, #0x67]
    // 0x66548c: DecompressPointer r1
    //     0x66548c: add             x1, x1, HEAP, lsl #32
    // 0x665490: r0 = LoadClassIdInstr(r1)
    //     0x665490: ldur            x0, [x1, #-1]
    //     0x665494: ubfx            x0, x0, #0xc, #0x14
    // 0x665498: SaveReg r1
    //     0x665498: str             x1, [SP, #-8]!
    // 0x66549c: r0 = GDT[cid_x0 + 0xf1a]()
    //     0x66549c: add             lr, x0, #0xf1a
    //     0x6654a0: ldr             lr, [x21, lr, lsl #3]
    //     0x6654a4: blr             lr
    // 0x6654a8: add             SP, SP, #8
    // 0x6654ac: tbnz            w0, #4, #0x6654c0
    // 0x6654b0: ldr             x16, [fp, #0x18]
    // 0x6654b4: SaveReg r16
    //     0x6654b4: str             x16, [SP, #-8]!
    // 0x6654b8: r0 = setIsComplexHint()
    //     0x6654b8: bl              #0x6654e4  ; [package:flutter/src/rendering/object.dart] PaintingContext::setIsComplexHint
    // 0x6654bc: add             SP, SP, #8
    // 0x6654c0: r0 = Null
    //     0x6654c0: mov             x0, NULL
    // 0x6654c4: LeaveFrame
    //     0x6654c4: mov             SP, fp
    //     0x6654c8: ldp             fp, lr, [SP], #0x10
    // 0x6654cc: ret
    //     0x6654cc: ret             
    // 0x6654d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6654d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6654d4: b               #0x665280
    // 0x6654d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6654d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6654dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6654dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6654e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6654e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ position=(/* No info */) {
    // ** addr: 0x6c77fc, size: 0x80
    // 0x6c77fc: EnterFrame
    //     0x6c77fc: stp             fp, lr, [SP, #-0x10]!
    //     0x6c7800: mov             fp, SP
    // 0x6c7804: CheckStackOverflow
    //     0x6c7804: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c7808: cmp             SP, x16
    //     0x6c780c: b.ls            #0x6c7874
    // 0x6c7810: ldr             x1, [fp, #0x18]
    // 0x6c7814: LoadField: r0 = r1->field_6b
    //     0x6c7814: ldur            w0, [x1, #0x6b]
    // 0x6c7818: DecompressPointer r0
    //     0x6c7818: add             x0, x0, HEAP, lsl #32
    // 0x6c781c: ldr             x2, [fp, #0x10]
    // 0x6c7820: cmp             w2, w0
    // 0x6c7824: b.ne            #0x6c7838
    // 0x6c7828: r0 = Null
    //     0x6c7828: mov             x0, NULL
    // 0x6c782c: LeaveFrame
    //     0x6c782c: mov             SP, fp
    //     0x6c7830: ldp             fp, lr, [SP], #0x10
    // 0x6c7834: ret
    //     0x6c7834: ret             
    // 0x6c7838: mov             x0, x2
    // 0x6c783c: StoreField: r1->field_6b = r0
    //     0x6c783c: stur            w0, [x1, #0x6b]
    //     0x6c7840: ldurb           w16, [x1, #-1]
    //     0x6c7844: ldurb           w17, [x0, #-1]
    //     0x6c7848: and             x16, x17, x16, lsr #2
    //     0x6c784c: tst             x16, HEAP, lsr #32
    //     0x6c7850: b.eq            #0x6c7858
    //     0x6c7854: bl              #0xd6826c
    // 0x6c7858: SaveReg r1
    //     0x6c7858: str             x1, [SP, #-8]!
    // 0x6c785c: r0 = markNeedsPaint()
    //     0x6c785c: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c7860: add             SP, SP, #8
    // 0x6c7864: r0 = Null
    //     0x6c7864: mov             x0, NULL
    // 0x6c7868: LeaveFrame
    //     0x6c7868: mov             SP, fp
    //     0x6c786c: ldp             fp, lr, [SP], #0x10
    // 0x6c7870: ret
    //     0x6c7870: ret             
    // 0x6c7874: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c7874: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c7878: b               #0x6c7810
  }
  set _ configuration=(/* No info */) {
    // ** addr: 0x6c787c, size: 0x8c
    // 0x6c787c: EnterFrame
    //     0x6c787c: stp             fp, lr, [SP, #-0x10]!
    //     0x6c7880: mov             fp, SP
    // 0x6c7884: CheckStackOverflow
    //     0x6c7884: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c7888: cmp             SP, x16
    //     0x6c788c: b.ls            #0x6c7900
    // 0x6c7890: ldr             x0, [fp, #0x18]
    // 0x6c7894: LoadField: r1 = r0->field_6f
    //     0x6c7894: ldur            w1, [x0, #0x6f]
    // 0x6c7898: DecompressPointer r1
    //     0x6c7898: add             x1, x1, HEAP, lsl #32
    // 0x6c789c: ldr             x16, [fp, #0x10]
    // 0x6c78a0: stp             x1, x16, [SP, #-0x10]!
    // 0x6c78a4: r0 = ==()
    //     0x6c78a4: bl              #0xc9d8f4  ; [package:flutter/src/painting/image_provider.dart] ImageConfiguration::==
    // 0x6c78a8: add             SP, SP, #0x10
    // 0x6c78ac: tbnz            w0, #4, #0x6c78c0
    // 0x6c78b0: r0 = Null
    //     0x6c78b0: mov             x0, NULL
    // 0x6c78b4: LeaveFrame
    //     0x6c78b4: mov             SP, fp
    //     0x6c78b8: ldp             fp, lr, [SP], #0x10
    // 0x6c78bc: ret
    //     0x6c78bc: ret             
    // 0x6c78c0: ldr             x1, [fp, #0x18]
    // 0x6c78c4: ldr             x0, [fp, #0x10]
    // 0x6c78c8: StoreField: r1->field_6f = r0
    //     0x6c78c8: stur            w0, [x1, #0x6f]
    //     0x6c78cc: ldurb           w16, [x1, #-1]
    //     0x6c78d0: ldurb           w17, [x0, #-1]
    //     0x6c78d4: and             x16, x17, x16, lsr #2
    //     0x6c78d8: tst             x16, HEAP, lsr #32
    //     0x6c78dc: b.eq            #0x6c78e4
    //     0x6c78e0: bl              #0xd6826c
    // 0x6c78e4: SaveReg r1
    //     0x6c78e4: str             x1, [SP, #-8]!
    // 0x6c78e8: r0 = markNeedsPaint()
    //     0x6c78e8: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c78ec: add             SP, SP, #8
    // 0x6c78f0: r0 = Null
    //     0x6c78f0: mov             x0, NULL
    // 0x6c78f4: LeaveFrame
    //     0x6c78f4: mov             SP, fp
    //     0x6c78f8: ldp             fp, lr, [SP], #0x10
    // 0x6c78fc: ret
    //     0x6c78fc: ret             
    // 0x6c7900: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c7900: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c7904: b               #0x6c7890
  }
  set _ decoration=(/* No info */) {
    // ** addr: 0x6c7ba8, size: 0xd8
    // 0x6c7ba8: EnterFrame
    //     0x6c7ba8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c7bac: mov             fp, SP
    // 0x6c7bb0: CheckStackOverflow
    //     0x6c7bb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c7bb4: cmp             SP, x16
    //     0x6c7bb8: b.ls            #0x6c7c78
    // 0x6c7bbc: ldr             x1, [fp, #0x18]
    // 0x6c7bc0: LoadField: r0 = r1->field_67
    //     0x6c7bc0: ldur            w0, [x1, #0x67]
    // 0x6c7bc4: DecompressPointer r0
    //     0x6c7bc4: add             x0, x0, HEAP, lsl #32
    // 0x6c7bc8: ldr             x2, [fp, #0x10]
    // 0x6c7bcc: r3 = LoadClassIdInstr(r2)
    //     0x6c7bcc: ldur            x3, [x2, #-1]
    //     0x6c7bd0: ubfx            x3, x3, #0xc, #0x14
    // 0x6c7bd4: stp             x0, x2, [SP, #-0x10]!
    // 0x6c7bd8: mov             x0, x3
    // 0x6c7bdc: mov             lr, x0
    // 0x6c7be0: ldr             lr, [x21, lr, lsl #3]
    // 0x6c7be4: blr             lr
    // 0x6c7be8: add             SP, SP, #0x10
    // 0x6c7bec: tbnz            w0, #4, #0x6c7c00
    // 0x6c7bf0: r0 = Null
    //     0x6c7bf0: mov             x0, NULL
    // 0x6c7bf4: LeaveFrame
    //     0x6c7bf4: mov             SP, fp
    //     0x6c7bf8: ldp             fp, lr, [SP], #0x10
    // 0x6c7bfc: ret
    //     0x6c7bfc: ret             
    // 0x6c7c00: ldr             x1, [fp, #0x18]
    // 0x6c7c04: LoadField: r0 = r1->field_63
    //     0x6c7c04: ldur            w0, [x1, #0x63]
    // 0x6c7c08: DecompressPointer r0
    //     0x6c7c08: add             x0, x0, HEAP, lsl #32
    // 0x6c7c0c: cmp             w0, NULL
    // 0x6c7c10: b.eq            #0x6c7c38
    // 0x6c7c14: r2 = LoadClassIdInstr(r0)
    //     0x6c7c14: ldur            x2, [x0, #-1]
    //     0x6c7c18: ubfx            x2, x2, #0xc, #0x14
    // 0x6c7c1c: SaveReg r0
    //     0x6c7c1c: str             x0, [SP, #-8]!
    // 0x6c7c20: mov             x0, x2
    // 0x6c7c24: r0 = GDT[cid_x0 + -0x3c5]()
    //     0x6c7c24: sub             lr, x0, #0x3c5
    //     0x6c7c28: ldr             lr, [x21, lr, lsl #3]
    //     0x6c7c2c: blr             lr
    // 0x6c7c30: add             SP, SP, #8
    // 0x6c7c34: ldr             x1, [fp, #0x18]
    // 0x6c7c38: StoreField: r1->field_63 = rNULL
    //     0x6c7c38: stur            NULL, [x1, #0x63]
    // 0x6c7c3c: ldr             x0, [fp, #0x10]
    // 0x6c7c40: StoreField: r1->field_67 = r0
    //     0x6c7c40: stur            w0, [x1, #0x67]
    //     0x6c7c44: ldurb           w16, [x1, #-1]
    //     0x6c7c48: ldurb           w17, [x0, #-1]
    //     0x6c7c4c: and             x16, x17, x16, lsr #2
    //     0x6c7c50: tst             x16, HEAP, lsr #32
    //     0x6c7c54: b.eq            #0x6c7c5c
    //     0x6c7c58: bl              #0xd6826c
    // 0x6c7c5c: SaveReg r1
    //     0x6c7c5c: str             x1, [SP, #-8]!
    // 0x6c7c60: r0 = markNeedsPaint()
    //     0x6c7c60: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c7c64: add             SP, SP, #8
    // 0x6c7c68: r0 = Null
    //     0x6c7c68: mov             x0, NULL
    // 0x6c7c6c: LeaveFrame
    //     0x6c7c6c: mov             SP, fp
    //     0x6c7c70: ldp             fp, lr, [SP], #0x10
    // 0x6c7c74: ret
    //     0x6c7c74: ret             
    // 0x6c7c78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c7c78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c7c7c: b               #0x6c7bbc
  }
  _ detach(/* No info */) {
    // ** addr: 0xa6915c, size: 0x8c
    // 0xa6915c: EnterFrame
    //     0xa6915c: stp             fp, lr, [SP, #-0x10]!
    //     0xa69160: mov             fp, SP
    // 0xa69164: CheckStackOverflow
    //     0xa69164: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa69168: cmp             SP, x16
    //     0xa6916c: b.ls            #0xa691e0
    // 0xa69170: ldr             x1, [fp, #0x10]
    // 0xa69174: LoadField: r0 = r1->field_63
    //     0xa69174: ldur            w0, [x1, #0x63]
    // 0xa69178: DecompressPointer r0
    //     0xa69178: add             x0, x0, HEAP, lsl #32
    // 0xa6917c: cmp             w0, NULL
    // 0xa69180: b.ne            #0xa6918c
    // 0xa69184: mov             x0, x1
    // 0xa69188: b               #0xa691b0
    // 0xa6918c: r2 = LoadClassIdInstr(r0)
    //     0xa6918c: ldur            x2, [x0, #-1]
    //     0xa69190: ubfx            x2, x2, #0xc, #0x14
    // 0xa69194: SaveReg r0
    //     0xa69194: str             x0, [SP, #-8]!
    // 0xa69198: mov             x0, x2
    // 0xa6919c: r0 = GDT[cid_x0 + -0x3c5]()
    //     0xa6919c: sub             lr, x0, #0x3c5
    //     0xa691a0: ldr             lr, [x21, lr, lsl #3]
    //     0xa691a4: blr             lr
    // 0xa691a8: add             SP, SP, #8
    // 0xa691ac: ldr             x0, [fp, #0x10]
    // 0xa691b0: StoreField: r0->field_63 = rNULL
    //     0xa691b0: stur            NULL, [x0, #0x63]
    // 0xa691b4: SaveReg r0
    //     0xa691b4: str             x0, [SP, #-8]!
    // 0xa691b8: r0 = detach()
    //     0xa691b8: bl              #0xa693e0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::detach
    // 0xa691bc: add             SP, SP, #8
    // 0xa691c0: ldr             x16, [fp, #0x10]
    // 0xa691c4: SaveReg r16
    //     0xa691c4: str             x16, [SP, #-8]!
    // 0xa691c8: r0 = markNeedsPaint()
    //     0xa691c8: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xa691cc: add             SP, SP, #8
    // 0xa691d0: r0 = Null
    //     0xa691d0: mov             x0, NULL
    // 0xa691d4: LeaveFrame
    //     0xa691d4: mov             SP, fp
    //     0xa691d8: ldp             fp, lr, [SP], #0x10
    // 0xa691dc: ret
    //     0xa691dc: ret             
    // 0xa691e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa691e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa691e4: b               #0xa69170
  }
}

// class id: 2496, size: 0x78, field offset: 0x64
abstract class _RenderCustomClip<X0> extends RenderProxyBox {

  _ _updateClip(/* No info */) {
    // ** addr: 0x63f548, size: 0xdc
    // 0x63f548: EnterFrame
    //     0x63f548: stp             fp, lr, [SP, #-0x10]!
    //     0x63f54c: mov             fp, SP
    // 0x63f550: CheckStackOverflow
    //     0x63f550: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63f554: cmp             SP, x16
    //     0x63f558: b.ls            #0x63f618
    // 0x63f55c: ldr             x1, [fp, #0x10]
    // 0x63f560: LoadField: r0 = r1->field_6b
    //     0x63f560: ldur            w0, [x1, #0x6b]
    // 0x63f564: DecompressPointer r0
    //     0x63f564: add             x0, x0, HEAP, lsl #32
    // 0x63f568: cmp             w0, NULL
    // 0x63f56c: b.ne            #0x63f608
    // 0x63f570: LoadField: r0 = r1->field_67
    //     0x63f570: ldur            w0, [x1, #0x67]
    // 0x63f574: DecompressPointer r0
    //     0x63f574: add             x0, x0, HEAP, lsl #32
    // 0x63f578: cmp             w0, NULL
    // 0x63f57c: b.ne            #0x63f588
    // 0x63f580: r0 = Null
    //     0x63f580: mov             x0, NULL
    // 0x63f584: b               #0x63f5b8
    // 0x63f588: LoadField: r2 = r1->field_57
    //     0x63f588: ldur            w2, [x1, #0x57]
    // 0x63f58c: DecompressPointer r2
    //     0x63f58c: add             x2, x2, HEAP, lsl #32
    // 0x63f590: cmp             w2, NULL
    // 0x63f594: b.eq            #0x63f620
    // 0x63f598: r3 = LoadClassIdInstr(r0)
    //     0x63f598: ldur            x3, [x0, #-1]
    //     0x63f59c: ubfx            x3, x3, #0xc, #0x14
    // 0x63f5a0: stp             x2, x0, [SP, #-0x10]!
    // 0x63f5a4: mov             x0, x3
    // 0x63f5a8: r0 = GDT[cid_x0 + 0xcc5]()
    //     0x63f5a8: add             lr, x0, #0xcc5
    //     0x63f5ac: ldr             lr, [x21, lr, lsl #3]
    //     0x63f5b0: blr             lr
    // 0x63f5b4: add             SP, SP, #0x10
    // 0x63f5b8: cmp             w0, NULL
    // 0x63f5bc: b.ne            #0x63f5e4
    // 0x63f5c0: ldr             x1, [fp, #0x10]
    // 0x63f5c4: r0 = LoadClassIdInstr(r1)
    //     0x63f5c4: ldur            x0, [x1, #-1]
    //     0x63f5c8: ubfx            x0, x0, #0xc, #0x14
    // 0x63f5cc: SaveReg r1
    //     0x63f5cc: str             x1, [SP, #-8]!
    // 0x63f5d0: r0 = GDT[cid_x0 + 0x25b0]()
    //     0x63f5d0: mov             x17, #0x25b0
    //     0x63f5d4: add             lr, x0, x17
    //     0x63f5d8: ldr             lr, [x21, lr, lsl #3]
    //     0x63f5dc: blr             lr
    // 0x63f5e0: add             SP, SP, #8
    // 0x63f5e4: ldr             x1, [fp, #0x10]
    // 0x63f5e8: StoreField: r1->field_6b = r0
    //     0x63f5e8: stur            w0, [x1, #0x6b]
    //     0x63f5ec: tbz             w0, #0, #0x63f608
    //     0x63f5f0: ldurb           w16, [x1, #-1]
    //     0x63f5f4: ldurb           w17, [x0, #-1]
    //     0x63f5f8: and             x16, x17, x16, lsr #2
    //     0x63f5fc: tst             x16, HEAP, lsr #32
    //     0x63f600: b.eq            #0x63f608
    //     0x63f604: bl              #0xd6826c
    // 0x63f608: r0 = Null
    //     0x63f608: mov             x0, NULL
    // 0x63f60c: LeaveFrame
    //     0x63f60c: mov             SP, fp
    //     0x63f610: ldp             fp, lr, [SP], #0x10
    // 0x63f614: ret
    //     0x63f614: ret             
    // 0x63f618: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63f618: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63f61c: b               #0x63f55c
    // 0x63f620: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63f620: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x652b78, size: 0x40
    // 0x652b78: EnterFrame
    //     0x652b78: stp             fp, lr, [SP, #-0x10]!
    //     0x652b7c: mov             fp, SP
    // 0x652b80: CheckStackOverflow
    //     0x652b80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x652b84: cmp             SP, x16
    //     0x652b88: b.ls            #0x652bb0
    // 0x652b8c: ldr             x0, [fp, #0x10]
    // 0x652b90: StoreField: r0->field_73 = rNULL
    //     0x652b90: stur            NULL, [x0, #0x73]
    // 0x652b94: SaveReg r0
    //     0x652b94: str             x0, [SP, #-8]!
    // 0x652b98: r0 = dispose()
    //     0x652b98: bl              #0x65378c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0x652b9c: add             SP, SP, #8
    // 0x652ba0: r0 = Null
    //     0x652ba0: mov             x0, NULL
    // 0x652ba4: LeaveFrame
    //     0x652ba4: mov             SP, fp
    //     0x652ba8: ldp             fp, lr, [SP], #0x10
    // 0x652bac: ret
    //     0x652bac: ret             
    // 0x652bb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x652bb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x652bb4: b               #0x652b8c
  }
  _ describeApproximatePaintClip(/* No info */) {
    // ** addr: 0x675570, size: 0xc4
    // 0x675570: EnterFrame
    //     0x675570: stp             fp, lr, [SP, #-0x10]!
    //     0x675574: mov             fp, SP
    // 0x675578: CheckStackOverflow
    //     0x675578: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67557c: cmp             SP, x16
    //     0x675580: b.ls            #0x675624
    // 0x675584: ldr             x0, [fp, #0x18]
    // 0x675588: LoadField: r1 = r0->field_6f
    //     0x675588: ldur            w1, [x0, #0x6f]
    // 0x67558c: DecompressPointer r1
    //     0x67558c: add             x1, x1, HEAP, lsl #32
    // 0x675590: LoadField: r2 = r1->field_7
    //     0x675590: ldur            x2, [x1, #7]
    // 0x675594: cmp             x2, #1
    // 0x675598: b.gt            #0x6755b4
    // 0x67559c: cmp             x2, #0
    // 0x6755a0: b.gt            #0x6755b4
    // 0x6755a4: r0 = Null
    //     0x6755a4: mov             x0, NULL
    // 0x6755a8: LeaveFrame
    //     0x6755a8: mov             SP, fp
    //     0x6755ac: ldp             fp, lr, [SP], #0x10
    // 0x6755b0: ret
    //     0x6755b0: ret             
    // 0x6755b4: LoadField: r1 = r0->field_67
    //     0x6755b4: ldur            w1, [x0, #0x67]
    // 0x6755b8: DecompressPointer r1
    //     0x6755b8: add             x1, x1, HEAP, lsl #32
    // 0x6755bc: cmp             w1, NULL
    // 0x6755c0: b.ne            #0x6755cc
    // 0x6755c4: r0 = Null
    //     0x6755c4: mov             x0, NULL
    // 0x6755c8: b               #0x6755ec
    // 0x6755cc: LoadField: r1 = r0->field_57
    //     0x6755cc: ldur            w1, [x0, #0x57]
    // 0x6755d0: DecompressPointer r1
    //     0x6755d0: add             x1, x1, HEAP, lsl #32
    // 0x6755d4: cmp             w1, NULL
    // 0x6755d8: b.eq            #0x67562c
    // 0x6755dc: r16 = Instance_Offset
    //     0x6755dc: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x6755e0: stp             x1, x16, [SP, #-0x10]!
    // 0x6755e4: r0 = &()
    //     0x6755e4: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x6755e8: add             SP, SP, #0x10
    // 0x6755ec: cmp             w0, NULL
    // 0x6755f0: b.ne            #0x675618
    // 0x6755f4: ldr             x0, [fp, #0x18]
    // 0x6755f8: LoadField: r1 = r0->field_57
    //     0x6755f8: ldur            w1, [x0, #0x57]
    // 0x6755fc: DecompressPointer r1
    //     0x6755fc: add             x1, x1, HEAP, lsl #32
    // 0x675600: cmp             w1, NULL
    // 0x675604: b.eq            #0x675630
    // 0x675608: r16 = Instance_Offset
    //     0x675608: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x67560c: stp             x1, x16, [SP, #-0x10]!
    // 0x675610: r0 = &()
    //     0x675610: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x675614: add             SP, SP, #0x10
    // 0x675618: LeaveFrame
    //     0x675618: mov             SP, fp
    //     0x67561c: ldp             fp, lr, [SP], #0x10
    // 0x675620: ret
    //     0x675620: ret             
    // 0x675624: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x675624: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x675628: b               #0x675584
    // 0x67562c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67562c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x675630: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x675630: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x68fa30, size: 0xa0
    // 0x68fa30: EnterFrame
    //     0x68fa30: stp             fp, lr, [SP, #-0x10]!
    //     0x68fa34: mov             fp, SP
    // 0x68fa38: AllocStack(0x8)
    //     0x68fa38: sub             SP, SP, #8
    // 0x68fa3c: CheckStackOverflow
    //     0x68fa3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68fa40: cmp             SP, x16
    //     0x68fa44: b.ls            #0x68fac4
    // 0x68fa48: ldr             x0, [fp, #0x10]
    // 0x68fa4c: LoadField: r1 = r0->field_57
    //     0x68fa4c: ldur            w1, [x0, #0x57]
    // 0x68fa50: DecompressPointer r1
    //     0x68fa50: add             x1, x1, HEAP, lsl #32
    // 0x68fa54: cmp             w1, NULL
    // 0x68fa58: b.ne            #0x68fa60
    // 0x68fa5c: r1 = Null
    //     0x68fa5c: mov             x1, NULL
    // 0x68fa60: stur            x1, [fp, #-8]
    // 0x68fa64: SaveReg r0
    //     0x68fa64: str             x0, [SP, #-8]!
    // 0x68fa68: r0 = performLayout()
    //     0x68fa68: bl              #0x68fff8  ; [package:flutter/src/rendering/proxy_box.dart] _RenderProxyBox&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::performLayout
    // 0x68fa6c: add             SP, SP, #8
    // 0x68fa70: ldr             x1, [fp, #0x10]
    // 0x68fa74: LoadField: r0 = r1->field_57
    //     0x68fa74: ldur            w0, [x1, #0x57]
    // 0x68fa78: DecompressPointer r0
    //     0x68fa78: add             x0, x0, HEAP, lsl #32
    // 0x68fa7c: cmp             w0, NULL
    // 0x68fa80: b.eq            #0x68facc
    // 0x68fa84: ldur            x2, [fp, #-8]
    // 0x68fa88: r3 = LoadClassIdInstr(r2)
    //     0x68fa88: ldur            x3, [x2, #-1]
    //     0x68fa8c: ubfx            x3, x3, #0xc, #0x14
    // 0x68fa90: stp             x0, x2, [SP, #-0x10]!
    // 0x68fa94: mov             x0, x3
    // 0x68fa98: mov             lr, x0
    // 0x68fa9c: ldr             lr, [x21, lr, lsl #3]
    // 0x68faa0: blr             lr
    // 0x68faa4: add             SP, SP, #0x10
    // 0x68faa8: tbz             w0, #4, #0x68fab4
    // 0x68faac: ldr             x1, [fp, #0x10]
    // 0x68fab0: StoreField: r1->field_6b = rNULL
    //     0x68fab0: stur            NULL, [x1, #0x6b]
    // 0x68fab4: r0 = Null
    //     0x68fab4: mov             x0, NULL
    // 0x68fab8: LeaveFrame
    //     0x68fab8: mov             SP, fp
    //     0x68fabc: ldp             fp, lr, [SP], #0x10
    // 0x68fac0: ret
    //     0x68fac0: ret             
    // 0x68fac4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68fac4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68fac8: b               #0x68fa48
    // 0x68facc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68facc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ clipper=(/* No info */) {
    // ** addr: 0x6c1578, size: 0x158
    // 0x6c1578: EnterFrame
    //     0x6c1578: stp             fp, lr, [SP, #-0x10]!
    //     0x6c157c: mov             fp, SP
    // 0x6c1580: AllocStack(0x8)
    //     0x6c1580: sub             SP, SP, #8
    // 0x6c1584: CheckStackOverflow
    //     0x6c1584: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c1588: cmp             SP, x16
    //     0x6c158c: b.ls            #0x6c16c8
    // 0x6c1590: ldr             x3, [fp, #0x18]
    // 0x6c1594: LoadField: r2 = r3->field_63
    //     0x6c1594: ldur            w2, [x3, #0x63]
    // 0x6c1598: DecompressPointer r2
    //     0x6c1598: add             x2, x2, HEAP, lsl #32
    // 0x6c159c: ldr             x0, [fp, #0x10]
    // 0x6c15a0: r1 = Null
    //     0x6c15a0: mov             x1, NULL
    // 0x6c15a4: r8 = CustomClipper<X0>?
    //     0x6c15a4: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d4c8] Type: CustomClipper<X0>?
    //     0x6c15a8: ldr             x8, [x8, #0x4c8]
    // 0x6c15ac: LoadField: r9 = r8->field_7
    //     0x6c15ac: ldur            x9, [x8, #7]
    // 0x6c15b0: r3 = Null
    //     0x6c15b0: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d4d0] Null
    //     0x6c15b4: ldr             x3, [x3, #0x4d0]
    // 0x6c15b8: blr             x9
    // 0x6c15bc: ldr             x1, [fp, #0x18]
    // 0x6c15c0: LoadField: r0 = r1->field_67
    //     0x6c15c0: ldur            w0, [x1, #0x67]
    // 0x6c15c4: DecompressPointer r0
    //     0x6c15c4: add             x0, x0, HEAP, lsl #32
    // 0x6c15c8: r2 = LoadClassIdInstr(r0)
    //     0x6c15c8: ldur            x2, [x0, #-1]
    //     0x6c15cc: ubfx            x2, x2, #0xc, #0x14
    // 0x6c15d0: ldr             x16, [fp, #0x10]
    // 0x6c15d4: stp             x16, x0, [SP, #-0x10]!
    // 0x6c15d8: mov             x0, x2
    // 0x6c15dc: mov             lr, x0
    // 0x6c15e0: ldr             lr, [x21, lr, lsl #3]
    // 0x6c15e4: blr             lr
    // 0x6c15e8: add             SP, SP, #0x10
    // 0x6c15ec: tbnz            w0, #4, #0x6c1600
    // 0x6c15f0: r0 = Null
    //     0x6c15f0: mov             x0, NULL
    // 0x6c15f4: LeaveFrame
    //     0x6c15f4: mov             SP, fp
    //     0x6c15f8: ldp             fp, lr, [SP], #0x10
    // 0x6c15fc: ret
    //     0x6c15fc: ret             
    // 0x6c1600: ldr             x1, [fp, #0x18]
    // 0x6c1604: ldr             x2, [fp, #0x10]
    // 0x6c1608: LoadField: r3 = r1->field_67
    //     0x6c1608: ldur            w3, [x1, #0x67]
    // 0x6c160c: DecompressPointer r3
    //     0x6c160c: add             x3, x3, HEAP, lsl #32
    // 0x6c1610: mov             x0, x2
    // 0x6c1614: stur            x3, [fp, #-8]
    // 0x6c1618: StoreField: r1->field_67 = r0
    //     0x6c1618: stur            w0, [x1, #0x67]
    //     0x6c161c: ldurb           w16, [x1, #-1]
    //     0x6c1620: ldurb           w17, [x0, #-1]
    //     0x6c1624: and             x16, x17, x16, lsr #2
    //     0x6c1628: tst             x16, HEAP, lsr #32
    //     0x6c162c: b.eq            #0x6c1634
    //     0x6c1630: bl              #0xd6826c
    // 0x6c1634: cmp             w2, NULL
    // 0x6c1638: b.eq            #0x6c167c
    // 0x6c163c: cmp             w3, NULL
    // 0x6c1640: b.eq            #0x6c167c
    // 0x6c1644: stp             x3, x2, [SP, #-0x10]!
    // 0x6c1648: r0 = _haveSameRuntimeType()
    //     0x6c1648: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0x6c164c: add             SP, SP, #0x10
    // 0x6c1650: tbnz            w0, #4, #0x6c167c
    // 0x6c1654: ldr             x1, [fp, #0x10]
    // 0x6c1658: r0 = LoadClassIdInstr(r1)
    //     0x6c1658: ldur            x0, [x1, #-1]
    //     0x6c165c: ubfx            x0, x0, #0xc, #0x14
    // 0x6c1660: ldur            x16, [fp, #-8]
    // 0x6c1664: stp             x16, x1, [SP, #-0x10]!
    // 0x6c1668: r0 = GDT[cid_x0 + 0xd08]()
    //     0x6c1668: add             lr, x0, #0xd08
    //     0x6c166c: ldr             lr, [x21, lr, lsl #3]
    //     0x6c1670: blr             lr
    // 0x6c1674: add             SP, SP, #0x10
    // 0x6c1678: tbnz            w0, #4, #0x6c168c
    // 0x6c167c: ldr             x16, [fp, #0x18]
    // 0x6c1680: SaveReg r16
    //     0x6c1680: str             x16, [SP, #-8]!
    // 0x6c1684: r0 = _markNeedsClip()
    //     0x6c1684: bl              #0x6c16d0  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_markNeedsClip
    // 0x6c1688: add             SP, SP, #8
    // 0x6c168c: ldr             x1, [fp, #0x18]
    // 0x6c1690: LoadField: r2 = r1->field_f
    //     0x6c1690: ldur            w2, [x1, #0xf]
    // 0x6c1694: DecompressPointer r2
    //     0x6c1694: add             x2, x2, HEAP, lsl #32
    // 0x6c1698: cmp             w2, NULL
    // 0x6c169c: b.eq            #0x6c16b8
    // 0x6c16a0: ldur            x1, [fp, #-8]
    // 0x6c16a4: cmp             w1, NULL
    // 0x6c16a8: b.eq            #0x6c16ac
    // 0x6c16ac: ldr             x1, [fp, #0x10]
    // 0x6c16b0: cmp             w1, NULL
    // 0x6c16b4: b.eq            #0x6c16b8
    // 0x6c16b8: r0 = Null
    //     0x6c16b8: mov             x0, NULL
    // 0x6c16bc: LeaveFrame
    //     0x6c16bc: mov             SP, fp
    //     0x6c16c0: ldp             fp, lr, [SP], #0x10
    // 0x6c16c4: ret
    //     0x6c16c4: ret             
    // 0x6c16c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c16c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c16cc: b               #0x6c1590
  }
  _ _markNeedsClip(/* No info */) {
    // ** addr: 0x6c16d0, size: 0x50
    // 0x6c16d0: EnterFrame
    //     0x6c16d0: stp             fp, lr, [SP, #-0x10]!
    //     0x6c16d4: mov             fp, SP
    // 0x6c16d8: CheckStackOverflow
    //     0x6c16d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c16dc: cmp             SP, x16
    //     0x6c16e0: b.ls            #0x6c1718
    // 0x6c16e4: ldr             x0, [fp, #0x10]
    // 0x6c16e8: StoreField: r0->field_6b = rNULL
    //     0x6c16e8: stur            NULL, [x0, #0x6b]
    // 0x6c16ec: SaveReg r0
    //     0x6c16ec: str             x0, [SP, #-8]!
    // 0x6c16f0: r0 = markNeedsPaint()
    //     0x6c16f0: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c16f4: add             SP, SP, #8
    // 0x6c16f8: ldr             x16, [fp, #0x10]
    // 0x6c16fc: SaveReg r16
    //     0x6c16fc: str             x16, [SP, #-8]!
    // 0x6c1700: r0 = markNeedsSemanticsUpdate()
    //     0x6c1700: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6c1704: add             SP, SP, #8
    // 0x6c1708: r0 = Null
    //     0x6c1708: mov             x0, NULL
    // 0x6c170c: LeaveFrame
    //     0x6c170c: mov             SP, fp
    //     0x6c1710: ldp             fp, lr, [SP], #0x10
    // 0x6c1714: ret
    //     0x6c1714: ret             
    // 0x6c1718: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c1718: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c171c: b               #0x6c16e4
  }
  set _ clipBehavior=(/* No info */) {
    // ** addr: 0x6c3c50, size: 0x70
    // 0x6c3c50: EnterFrame
    //     0x6c3c50: stp             fp, lr, [SP, #-0x10]!
    //     0x6c3c54: mov             fp, SP
    // 0x6c3c58: CheckStackOverflow
    //     0x6c3c58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c3c5c: cmp             SP, x16
    //     0x6c3c60: b.ls            #0x6c3cb8
    // 0x6c3c64: ldr             x1, [fp, #0x18]
    // 0x6c3c68: LoadField: r0 = r1->field_6f
    //     0x6c3c68: ldur            w0, [x1, #0x6f]
    // 0x6c3c6c: DecompressPointer r0
    //     0x6c3c6c: add             x0, x0, HEAP, lsl #32
    // 0x6c3c70: ldr             x2, [fp, #0x10]
    // 0x6c3c74: cmp             w2, w0
    // 0x6c3c78: b.eq            #0x6c3ca8
    // 0x6c3c7c: mov             x0, x2
    // 0x6c3c80: StoreField: r1->field_6f = r0
    //     0x6c3c80: stur            w0, [x1, #0x6f]
    //     0x6c3c84: ldurb           w16, [x1, #-1]
    //     0x6c3c88: ldurb           w17, [x0, #-1]
    //     0x6c3c8c: and             x16, x17, x16, lsr #2
    //     0x6c3c90: tst             x16, HEAP, lsr #32
    //     0x6c3c94: b.eq            #0x6c3c9c
    //     0x6c3c98: bl              #0xd6826c
    // 0x6c3c9c: SaveReg r1
    //     0x6c3c9c: str             x1, [SP, #-8]!
    // 0x6c3ca0: r0 = markNeedsPaint()
    //     0x6c3ca0: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c3ca4: add             SP, SP, #8
    // 0x6c3ca8: r0 = Null
    //     0x6c3ca8: mov             x0, NULL
    // 0x6c3cac: LeaveFrame
    //     0x6c3cac: mov             SP, fp
    //     0x6c3cb0: ldp             fp, lr, [SP], #0x10
    // 0x6c3cb4: ret
    //     0x6c3cb4: ret             
    // 0x6c3cb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c3cb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c3cbc: b               #0x6c3c64
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bd3e0, size: 0x88
    // 0x9bd3e0: EnterFrame
    //     0x9bd3e0: stp             fp, lr, [SP, #-0x10]!
    //     0x9bd3e4: mov             fp, SP
    // 0x9bd3e8: CheckStackOverflow
    //     0x9bd3e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bd3ec: cmp             SP, x16
    //     0x9bd3f0: b.ls            #0x9bd460
    // 0x9bd3f4: ldr             x0, [fp, #0x10]
    // 0x9bd3f8: r2 = Null
    //     0x9bd3f8: mov             x2, NULL
    // 0x9bd3fc: r1 = Null
    //     0x9bd3fc: mov             x1, NULL
    // 0x9bd400: r4 = 59
    //     0x9bd400: mov             x4, #0x3b
    // 0x9bd404: branchIfSmi(r0, 0x9bd410)
    //     0x9bd404: tbz             w0, #0, #0x9bd410
    // 0x9bd408: r4 = LoadClassIdInstr(r0)
    //     0x9bd408: ldur            x4, [x0, #-1]
    //     0x9bd40c: ubfx            x4, x4, #0xc, #0x14
    // 0x9bd410: cmp             x4, #0x7e6
    // 0x9bd414: b.eq            #0x9bd428
    // 0x9bd418: r8 = PipelineOwner
    //     0x9bd418: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9bd41c: r3 = Null
    //     0x9bd41c: add             x3, PP, #0x21, lsl #12  ; [pp+0x21b30] Null
    //     0x9bd420: ldr             x3, [x3, #0xb30]
    // 0x9bd424: r0 = DefaultTypeTest()
    //     0x9bd424: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bd428: ldr             x16, [fp, #0x18]
    // 0x9bd42c: ldr             lr, [fp, #0x10]
    // 0x9bd430: stp             lr, x16, [SP, #-0x10]!
    // 0x9bd434: r0 = attach()
    //     0x9bd434: bl              #0x9bd674  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::attach
    // 0x9bd438: add             SP, SP, #0x10
    // 0x9bd43c: ldr             x1, [fp, #0x18]
    // 0x9bd440: LoadField: r2 = r1->field_67
    //     0x9bd440: ldur            w2, [x1, #0x67]
    // 0x9bd444: DecompressPointer r2
    //     0x9bd444: add             x2, x2, HEAP, lsl #32
    // 0x9bd448: cmp             w2, NULL
    // 0x9bd44c: b.eq            #0x9bd450
    // 0x9bd450: r0 = Null
    //     0x9bd450: mov             x0, NULL
    // 0x9bd454: LeaveFrame
    //     0x9bd454: mov             SP, fp
    //     0x9bd458: ldp             fp, lr, [SP], #0x10
    // 0x9bd45c: ret
    //     0x9bd45c: ret             
    // 0x9bd460: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bd460: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bd464: b               #0x9bd3f4
  }
  _ detach(/* No info */) {
    // ** addr: 0xa69110, size: 0x4c
    // 0xa69110: EnterFrame
    //     0xa69110: stp             fp, lr, [SP, #-0x10]!
    //     0xa69114: mov             fp, SP
    // 0xa69118: CheckStackOverflow
    //     0xa69118: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6911c: cmp             SP, x16
    //     0xa69120: b.ls            #0xa69154
    // 0xa69124: ldr             x0, [fp, #0x10]
    // 0xa69128: LoadField: r1 = r0->field_67
    //     0xa69128: ldur            w1, [x0, #0x67]
    // 0xa6912c: DecompressPointer r1
    //     0xa6912c: add             x1, x1, HEAP, lsl #32
    // 0xa69130: cmp             w1, NULL
    // 0xa69134: b.eq            #0xa69138
    // 0xa69138: SaveReg r0
    //     0xa69138: str             x0, [SP, #-8]!
    // 0xa6913c: r0 = detach()
    //     0xa6913c: bl              #0xa693e0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::detach
    // 0xa69140: add             SP, SP, #8
    // 0xa69144: r0 = Null
    //     0xa69144: mov             x0, NULL
    // 0xa69148: LeaveFrame
    //     0xa69148: mov             SP, fp
    //     0xa6914c: ldp             fp, lr, [SP], #0x10
    // 0xa69150: ret
    //     0xa69150: ret             
    // 0xa69154: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa69154: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa69158: b               #0xa69124
  }
}

// class id: 2497, size: 0x88, field offset: 0x78
abstract class _RenderPhysicalModelBase<X0> extends _RenderCustomClip<X0> {

  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0x64ed40, size: 0x30
    // 0x64ed40: ldr             x1, [SP, #8]
    // 0x64ed44: LoadField: d0 = r1->field_77
    //     0x64ed44: ldur            d0, [x1, #0x77]
    // 0x64ed48: ldr             x1, [SP]
    // 0x64ed4c: LoadField: d1 = r1->field_63
    //     0x64ed4c: ldur            d1, [x1, #0x63]
    // 0x64ed50: fcmp            d0, d1
    // 0x64ed54: b.vs            #0x64ed5c
    // 0x64ed58: b.eq            #0x64ed68
    // 0x64ed5c: r2 = true
    //     0x64ed5c: add             x2, NULL, #0x20  ; true
    // 0x64ed60: StoreField: r1->field_63 = d0
    //     0x64ed60: stur            d0, [x1, #0x63]
    // 0x64ed64: StoreField: r1->field_13 = r2
    //     0x64ed64: stur            w2, [x1, #0x13]
    // 0x64ed68: r0 = Null
    //     0x64ed68: mov             x0, NULL
    // 0x64ed6c: ret
    //     0x64ed6c: ret             
  }
  set _ elevation=(/* No info */) {
    // ** addr: 0x6c4144, size: 0x64
    // 0x6c4144: EnterFrame
    //     0x6c4144: stp             fp, lr, [SP, #-0x10]!
    //     0x6c4148: mov             fp, SP
    // 0x6c414c: CheckStackOverflow
    //     0x6c414c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c4150: cmp             SP, x16
    //     0x6c4154: b.ls            #0x6c41a0
    // 0x6c4158: ldr             x0, [fp, #0x18]
    // 0x6c415c: LoadField: d0 = r0->field_77
    //     0x6c415c: ldur            d0, [x0, #0x77]
    // 0x6c4160: ldr             d1, [fp, #0x10]
    // 0x6c4164: fcmp            d0, d1
    // 0x6c4168: b.vs            #0x6c4180
    // 0x6c416c: b.ne            #0x6c4180
    // 0x6c4170: r0 = Null
    //     0x6c4170: mov             x0, NULL
    // 0x6c4174: LeaveFrame
    //     0x6c4174: mov             SP, fp
    //     0x6c4178: ldp             fp, lr, [SP], #0x10
    // 0x6c417c: ret
    //     0x6c417c: ret             
    // 0x6c4180: StoreField: r0->field_77 = d1
    //     0x6c4180: stur            d1, [x0, #0x77]
    // 0x6c4184: SaveReg r0
    //     0x6c4184: str             x0, [SP, #-8]!
    // 0x6c4188: r0 = markNeedsPaint()
    //     0x6c4188: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c418c: add             SP, SP, #8
    // 0x6c4190: r0 = Null
    //     0x6c4190: mov             x0, NULL
    // 0x6c4194: LeaveFrame
    //     0x6c4194: mov             SP, fp
    //     0x6c4198: ldp             fp, lr, [SP], #0x10
    // 0x6c419c: ret
    //     0x6c419c: ret             
    // 0x6c41a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c41a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c41a4: b               #0x6c4158
  }
  set _ shadowColor=(/* No info */) {
    // ** addr: 0x6c41a8, size: 0x1a8
    // 0x6c41a8: EnterFrame
    //     0x6c41a8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c41ac: mov             fp, SP
    // 0x6c41b0: AllocStack(0x10)
    //     0x6c41b0: sub             SP, SP, #0x10
    // 0x6c41b4: CheckStackOverflow
    //     0x6c41b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c41b8: cmp             SP, x16
    //     0x6c41bc: b.ls            #0x6c4348
    // 0x6c41c0: ldr             x0, [fp, #0x18]
    // 0x6c41c4: LoadField: r1 = r0->field_7f
    //     0x6c41c4: ldur            w1, [x0, #0x7f]
    // 0x6c41c8: DecompressPointer r1
    //     0x6c41c8: add             x1, x1, HEAP, lsl #32
    // 0x6c41cc: stur            x1, [fp, #-0x10]
    // 0x6c41d0: r2 = LoadClassIdInstr(r1)
    //     0x6c41d0: ldur            x2, [x1, #-1]
    //     0x6c41d4: ubfx            x2, x2, #0xc, #0x14
    // 0x6c41d8: lsl             x2, x2, #1
    // 0x6c41dc: stur            x2, [fp, #-8]
    // 0x6c41e0: r17 = 10114
    //     0x6c41e0: mov             x17, #0x2782
    // 0x6c41e4: cmp             w2, w17
    // 0x6c41e8: b.eq            #0x6c41f8
    // 0x6c41ec: r17 = 10118
    //     0x6c41ec: mov             x17, #0x2786
    // 0x6c41f0: cmp             w2, w17
    // 0x6c41f4: b.ne            #0x6c42cc
    // 0x6c41f8: ldr             x3, [fp, #0x10]
    // 0x6c41fc: cmp             w1, w3
    // 0x6c4200: b.eq            #0x6c42f8
    // 0x6c4204: stp             x1, x3, [SP, #-0x10]!
    // 0x6c4208: r0 = _haveSameRuntimeType()
    //     0x6c4208: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0x6c420c: add             SP, SP, #0x10
    // 0x6c4210: tbnz            w0, #4, #0x6c4308
    // 0x6c4214: ldr             x1, [fp, #0x10]
    // 0x6c4218: r0 = LoadClassIdInstr(r1)
    //     0x6c4218: ldur            x0, [x1, #-1]
    //     0x6c421c: ubfx            x0, x0, #0xc, #0x14
    // 0x6c4220: lsl             x0, x0, #1
    // 0x6c4224: r17 = 10124
    //     0x6c4224: mov             x17, #0x278c
    // 0x6c4228: cmp             w0, w17
    // 0x6c422c: b.gt            #0x6c423c
    // 0x6c4230: r17 = 10122
    //     0x6c4230: mov             x17, #0x278a
    // 0x6c4234: cmp             w0, w17
    // 0x6c4238: b.ge            #0x6c4254
    // 0x6c423c: r17 = 10114
    //     0x6c423c: mov             x17, #0x2782
    // 0x6c4240: cmp             w0, w17
    // 0x6c4244: b.eq            #0x6c4254
    // 0x6c4248: r17 = 10118
    //     0x6c4248: mov             x17, #0x2786
    // 0x6c424c: cmp             w0, w17
    // 0x6c4250: b.ne            #0x6c4260
    // 0x6c4254: LoadField: r0 = r1->field_7
    //     0x6c4254: ldur            x0, [x1, #7]
    // 0x6c4258: mov             x2, x0
    // 0x6c425c: b               #0x6c426c
    // 0x6c4260: LoadField: r0 = r1->field_f
    //     0x6c4260: ldur            w0, [x1, #0xf]
    // 0x6c4264: DecompressPointer r0
    //     0x6c4264: add             x0, x0, HEAP, lsl #32
    // 0x6c4268: LoadField: r2 = r0->field_7
    //     0x6c4268: ldur            x2, [x0, #7]
    // 0x6c426c: ldur            x0, [fp, #-8]
    // 0x6c4270: r17 = 10124
    //     0x6c4270: mov             x17, #0x278c
    // 0x6c4274: cmp             w0, w17
    // 0x6c4278: b.gt            #0x6c4288
    // 0x6c427c: r17 = 10122
    //     0x6c427c: mov             x17, #0x278a
    // 0x6c4280: cmp             w0, w17
    // 0x6c4284: b.ge            #0x6c42a0
    // 0x6c4288: r17 = 10114
    //     0x6c4288: mov             x17, #0x2782
    // 0x6c428c: cmp             w0, w17
    // 0x6c4290: b.eq            #0x6c42a0
    // 0x6c4294: r17 = 10118
    //     0x6c4294: mov             x17, #0x2786
    // 0x6c4298: cmp             w0, w17
    // 0x6c429c: b.ne            #0x6c42b0
    // 0x6c42a0: ldur            x0, [fp, #-0x10]
    // 0x6c42a4: LoadField: r3 = r0->field_7
    //     0x6c42a4: ldur            x3, [x0, #7]
    // 0x6c42a8: mov             x0, x3
    // 0x6c42ac: b               #0x6c42c0
    // 0x6c42b0: ldur            x0, [fp, #-0x10]
    // 0x6c42b4: LoadField: r3 = r0->field_f
    //     0x6c42b4: ldur            w3, [x0, #0xf]
    // 0x6c42b8: DecompressPointer r3
    //     0x6c42b8: add             x3, x3, HEAP, lsl #32
    // 0x6c42bc: LoadField: r0 = r3->field_7
    //     0x6c42bc: ldur            x0, [x3, #7]
    // 0x6c42c0: cmp             x2, x0
    // 0x6c42c4: b.ne            #0x6c4308
    // 0x6c42c8: b               #0x6c42f8
    // 0x6c42cc: mov             x0, x1
    // 0x6c42d0: ldr             x1, [fp, #0x10]
    // 0x6c42d4: r2 = LoadClassIdInstr(r0)
    //     0x6c42d4: ldur            x2, [x0, #-1]
    //     0x6c42d8: ubfx            x2, x2, #0xc, #0x14
    // 0x6c42dc: stp             x1, x0, [SP, #-0x10]!
    // 0x6c42e0: mov             x0, x2
    // 0x6c42e4: mov             lr, x0
    // 0x6c42e8: ldr             lr, [x21, lr, lsl #3]
    // 0x6c42ec: blr             lr
    // 0x6c42f0: add             SP, SP, #0x10
    // 0x6c42f4: tbnz            w0, #4, #0x6c4308
    // 0x6c42f8: r0 = Null
    //     0x6c42f8: mov             x0, NULL
    // 0x6c42fc: LeaveFrame
    //     0x6c42fc: mov             SP, fp
    //     0x6c4300: ldp             fp, lr, [SP], #0x10
    // 0x6c4304: ret
    //     0x6c4304: ret             
    // 0x6c4308: ldr             x1, [fp, #0x18]
    // 0x6c430c: ldr             x0, [fp, #0x10]
    // 0x6c4310: StoreField: r1->field_7f = r0
    //     0x6c4310: stur            w0, [x1, #0x7f]
    //     0x6c4314: ldurb           w16, [x1, #-1]
    //     0x6c4318: ldurb           w17, [x0, #-1]
    //     0x6c431c: and             x16, x17, x16, lsr #2
    //     0x6c4320: tst             x16, HEAP, lsr #32
    //     0x6c4324: b.eq            #0x6c432c
    //     0x6c4328: bl              #0xd6826c
    // 0x6c432c: SaveReg r1
    //     0x6c432c: str             x1, [SP, #-8]!
    // 0x6c4330: r0 = markNeedsPaint()
    //     0x6c4330: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c4334: add             SP, SP, #8
    // 0x6c4338: r0 = Null
    //     0x6c4338: mov             x0, NULL
    // 0x6c433c: LeaveFrame
    //     0x6c433c: mov             SP, fp
    //     0x6c4340: ldp             fp, lr, [SP], #0x10
    // 0x6c4344: ret
    //     0x6c4344: ret             
    // 0x6c4348: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c4348: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c434c: b               #0x6c41c0
  }
  set _ color=(/* No info */) {
    // ** addr: 0x6c4350, size: 0x1a8
    // 0x6c4350: EnterFrame
    //     0x6c4350: stp             fp, lr, [SP, #-0x10]!
    //     0x6c4354: mov             fp, SP
    // 0x6c4358: AllocStack(0x10)
    //     0x6c4358: sub             SP, SP, #0x10
    // 0x6c435c: CheckStackOverflow
    //     0x6c435c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c4360: cmp             SP, x16
    //     0x6c4364: b.ls            #0x6c44f0
    // 0x6c4368: ldr             x0, [fp, #0x18]
    // 0x6c436c: LoadField: r1 = r0->field_83
    //     0x6c436c: ldur            w1, [x0, #0x83]
    // 0x6c4370: DecompressPointer r1
    //     0x6c4370: add             x1, x1, HEAP, lsl #32
    // 0x6c4374: stur            x1, [fp, #-0x10]
    // 0x6c4378: r2 = LoadClassIdInstr(r1)
    //     0x6c4378: ldur            x2, [x1, #-1]
    //     0x6c437c: ubfx            x2, x2, #0xc, #0x14
    // 0x6c4380: lsl             x2, x2, #1
    // 0x6c4384: stur            x2, [fp, #-8]
    // 0x6c4388: r17 = 10114
    //     0x6c4388: mov             x17, #0x2782
    // 0x6c438c: cmp             w2, w17
    // 0x6c4390: b.eq            #0x6c43a0
    // 0x6c4394: r17 = 10118
    //     0x6c4394: mov             x17, #0x2786
    // 0x6c4398: cmp             w2, w17
    // 0x6c439c: b.ne            #0x6c4474
    // 0x6c43a0: ldr             x3, [fp, #0x10]
    // 0x6c43a4: cmp             w1, w3
    // 0x6c43a8: b.eq            #0x6c44a0
    // 0x6c43ac: stp             x1, x3, [SP, #-0x10]!
    // 0x6c43b0: r0 = _haveSameRuntimeType()
    //     0x6c43b0: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0x6c43b4: add             SP, SP, #0x10
    // 0x6c43b8: tbnz            w0, #4, #0x6c44b0
    // 0x6c43bc: ldr             x1, [fp, #0x10]
    // 0x6c43c0: r0 = LoadClassIdInstr(r1)
    //     0x6c43c0: ldur            x0, [x1, #-1]
    //     0x6c43c4: ubfx            x0, x0, #0xc, #0x14
    // 0x6c43c8: lsl             x0, x0, #1
    // 0x6c43cc: r17 = 10124
    //     0x6c43cc: mov             x17, #0x278c
    // 0x6c43d0: cmp             w0, w17
    // 0x6c43d4: b.gt            #0x6c43e4
    // 0x6c43d8: r17 = 10122
    //     0x6c43d8: mov             x17, #0x278a
    // 0x6c43dc: cmp             w0, w17
    // 0x6c43e0: b.ge            #0x6c43fc
    // 0x6c43e4: r17 = 10114
    //     0x6c43e4: mov             x17, #0x2782
    // 0x6c43e8: cmp             w0, w17
    // 0x6c43ec: b.eq            #0x6c43fc
    // 0x6c43f0: r17 = 10118
    //     0x6c43f0: mov             x17, #0x2786
    // 0x6c43f4: cmp             w0, w17
    // 0x6c43f8: b.ne            #0x6c4408
    // 0x6c43fc: LoadField: r0 = r1->field_7
    //     0x6c43fc: ldur            x0, [x1, #7]
    // 0x6c4400: mov             x2, x0
    // 0x6c4404: b               #0x6c4414
    // 0x6c4408: LoadField: r0 = r1->field_f
    //     0x6c4408: ldur            w0, [x1, #0xf]
    // 0x6c440c: DecompressPointer r0
    //     0x6c440c: add             x0, x0, HEAP, lsl #32
    // 0x6c4410: LoadField: r2 = r0->field_7
    //     0x6c4410: ldur            x2, [x0, #7]
    // 0x6c4414: ldur            x0, [fp, #-8]
    // 0x6c4418: r17 = 10124
    //     0x6c4418: mov             x17, #0x278c
    // 0x6c441c: cmp             w0, w17
    // 0x6c4420: b.gt            #0x6c4430
    // 0x6c4424: r17 = 10122
    //     0x6c4424: mov             x17, #0x278a
    // 0x6c4428: cmp             w0, w17
    // 0x6c442c: b.ge            #0x6c4448
    // 0x6c4430: r17 = 10114
    //     0x6c4430: mov             x17, #0x2782
    // 0x6c4434: cmp             w0, w17
    // 0x6c4438: b.eq            #0x6c4448
    // 0x6c443c: r17 = 10118
    //     0x6c443c: mov             x17, #0x2786
    // 0x6c4440: cmp             w0, w17
    // 0x6c4444: b.ne            #0x6c4458
    // 0x6c4448: ldur            x0, [fp, #-0x10]
    // 0x6c444c: LoadField: r3 = r0->field_7
    //     0x6c444c: ldur            x3, [x0, #7]
    // 0x6c4450: mov             x0, x3
    // 0x6c4454: b               #0x6c4468
    // 0x6c4458: ldur            x0, [fp, #-0x10]
    // 0x6c445c: LoadField: r3 = r0->field_f
    //     0x6c445c: ldur            w3, [x0, #0xf]
    // 0x6c4460: DecompressPointer r3
    //     0x6c4460: add             x3, x3, HEAP, lsl #32
    // 0x6c4464: LoadField: r0 = r3->field_7
    //     0x6c4464: ldur            x0, [x3, #7]
    // 0x6c4468: cmp             x2, x0
    // 0x6c446c: b.ne            #0x6c44b0
    // 0x6c4470: b               #0x6c44a0
    // 0x6c4474: mov             x0, x1
    // 0x6c4478: ldr             x1, [fp, #0x10]
    // 0x6c447c: r2 = LoadClassIdInstr(r0)
    //     0x6c447c: ldur            x2, [x0, #-1]
    //     0x6c4480: ubfx            x2, x2, #0xc, #0x14
    // 0x6c4484: stp             x1, x0, [SP, #-0x10]!
    // 0x6c4488: mov             x0, x2
    // 0x6c448c: mov             lr, x0
    // 0x6c4490: ldr             lr, [x21, lr, lsl #3]
    // 0x6c4494: blr             lr
    // 0x6c4498: add             SP, SP, #0x10
    // 0x6c449c: tbnz            w0, #4, #0x6c44b0
    // 0x6c44a0: r0 = Null
    //     0x6c44a0: mov             x0, NULL
    // 0x6c44a4: LeaveFrame
    //     0x6c44a4: mov             SP, fp
    //     0x6c44a8: ldp             fp, lr, [SP], #0x10
    // 0x6c44ac: ret
    //     0x6c44ac: ret             
    // 0x6c44b0: ldr             x1, [fp, #0x18]
    // 0x6c44b4: ldr             x0, [fp, #0x10]
    // 0x6c44b8: StoreField: r1->field_83 = r0
    //     0x6c44b8: stur            w0, [x1, #0x83]
    //     0x6c44bc: ldurb           w16, [x1, #-1]
    //     0x6c44c0: ldurb           w17, [x0, #-1]
    //     0x6c44c4: and             x16, x17, x16, lsr #2
    //     0x6c44c8: tst             x16, HEAP, lsr #32
    //     0x6c44cc: b.eq            #0x6c44d4
    //     0x6c44d0: bl              #0xd6826c
    // 0x6c44d4: SaveReg r1
    //     0x6c44d4: str             x1, [SP, #-8]!
    // 0x6c44d8: r0 = markNeedsPaint()
    //     0x6c44d8: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c44dc: add             SP, SP, #8
    // 0x6c44e0: r0 = Null
    //     0x6c44e0: mov             x0, NULL
    // 0x6c44e4: LeaveFrame
    //     0x6c44e4: mov             SP, fp
    //     0x6c44e8: ldp             fp, lr, [SP], #0x10
    // 0x6c44ec: ret
    //     0x6c44ec: ret             
    // 0x6c44f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c44f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c44f4: b               #0x6c4368
  }
  _ _RenderPhysicalModelBase(/* No info */) {
    // ** addr: 0x6eb2e4, size: 0x140
    // 0x6eb2e4: EnterFrame
    //     0x6eb2e4: stp             fp, lr, [SP, #-0x10]!
    //     0x6eb2e8: mov             fp, SP
    // 0x6eb2ec: AllocStack(0x8)
    //     0x6eb2ec: sub             SP, SP, #8
    // 0x6eb2f0: SetupParameters(_RenderPhysicalModelBase<X0> this /* r3, fp-0x8 */, dynamic _ /* r4 */, dynamic _ /* r5 */, dynamic _ /* d0 */, dynamic _ /* r6 */, {dynamic clipper = Null /* r1 */})
    //     0x6eb2f0: mov             x0, x4
    //     0x6eb2f4: ldur            w1, [x0, #0x13]
    //     0x6eb2f8: add             x1, x1, HEAP, lsl #32
    //     0x6eb2fc: sub             x2, x1, #0xa
    //     0x6eb300: add             x3, fp, w2, sxtw #2
    //     0x6eb304: ldr             x3, [x3, #0x30]
    //     0x6eb308: stur            x3, [fp, #-8]
    //     0x6eb30c: add             x4, fp, w2, sxtw #2
    //     0x6eb310: ldr             x4, [x4, #0x28]
    //     0x6eb314: add             x5, fp, w2, sxtw #2
    //     0x6eb318: ldr             x5, [x5, #0x20]
    //     0x6eb31c: add             x6, fp, w2, sxtw #2
    //     0x6eb320: ldr             d0, [x6, #0x18]
    //     0x6eb324: add             x6, fp, w2, sxtw #2
    //     0x6eb328: ldr             x6, [x6, #0x10]
    //     0x6eb32c: ldur            w2, [x0, #0x1f]
    //     0x6eb330: add             x2, x2, HEAP, lsl #32
    //     0x6eb334: add             x16, PP, #0x29, lsl #12  ; [pp+0x29118] "clipper"
    //     0x6eb338: ldr             x16, [x16, #0x118]
    //     0x6eb33c: cmp             w2, w16
    //     0x6eb340: b.ne            #0x6eb35c
    //     0x6eb344: ldur            w2, [x0, #0x23]
    //     0x6eb348: add             x2, x2, HEAP, lsl #32
    //     0x6eb34c: sub             w0, w1, w2
    //     0x6eb350: add             x1, fp, w0, sxtw #2
    //     0x6eb354: ldr             x1, [x1, #8]
    //     0x6eb358: b               #0x6eb360
    //     0x6eb35c: mov             x1, NULL
    // 0x6eb360: CheckStackOverflow
    //     0x6eb360: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6eb364: cmp             SP, x16
    //     0x6eb368: b.ls            #0x6eb41c
    // 0x6eb36c: StoreField: r3->field_77 = d0
    //     0x6eb36c: stur            d0, [x3, #0x77]
    // 0x6eb370: mov             x0, x5
    // 0x6eb374: StoreField: r3->field_83 = r0
    //     0x6eb374: stur            w0, [x3, #0x83]
    //     0x6eb378: ldurb           w16, [x3, #-1]
    //     0x6eb37c: ldurb           w17, [x0, #-1]
    //     0x6eb380: and             x16, x17, x16, lsr #2
    //     0x6eb384: tst             x16, HEAP, lsr #32
    //     0x6eb388: b.eq            #0x6eb390
    //     0x6eb38c: bl              #0xd682ac
    // 0x6eb390: mov             x0, x6
    // 0x6eb394: StoreField: r3->field_7f = r0
    //     0x6eb394: stur            w0, [x3, #0x7f]
    //     0x6eb398: ldurb           w16, [x3, #-1]
    //     0x6eb39c: ldurb           w17, [x0, #-1]
    //     0x6eb3a0: and             x16, x17, x16, lsr #2
    //     0x6eb3a4: tst             x16, HEAP, lsr #32
    //     0x6eb3a8: b.eq            #0x6eb3b0
    //     0x6eb3ac: bl              #0xd682ac
    // 0x6eb3b0: mov             x0, x1
    // 0x6eb3b4: StoreField: r3->field_67 = r0
    //     0x6eb3b4: stur            w0, [x3, #0x67]
    //     0x6eb3b8: ldurb           w16, [x3, #-1]
    //     0x6eb3bc: ldurb           w17, [x0, #-1]
    //     0x6eb3c0: and             x16, x17, x16, lsr #2
    //     0x6eb3c4: tst             x16, HEAP, lsr #32
    //     0x6eb3c8: b.eq            #0x6eb3d0
    //     0x6eb3cc: bl              #0xd682ac
    // 0x6eb3d0: mov             x0, x4
    // 0x6eb3d4: StoreField: r3->field_6f = r0
    //     0x6eb3d4: stur            w0, [x3, #0x6f]
    //     0x6eb3d8: ldurb           w16, [x3, #-1]
    //     0x6eb3dc: ldurb           w17, [x0, #-1]
    //     0x6eb3e0: and             x16, x17, x16, lsr #2
    //     0x6eb3e4: tst             x16, HEAP, lsr #32
    //     0x6eb3e8: b.eq            #0x6eb3f0
    //     0x6eb3ec: bl              #0xd682ac
    // 0x6eb3f0: SaveReg r3
    //     0x6eb3f0: str             x3, [SP, #-8]!
    // 0x6eb3f4: r0 = RenderObject()
    //     0x6eb3f4: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6eb3f8: add             SP, SP, #8
    // 0x6eb3fc: ldur            x16, [fp, #-8]
    // 0x6eb400: stp             NULL, x16, [SP, #-0x10]!
    // 0x6eb404: r0 = child=()
    //     0x6eb404: bl              #0x6e7da0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::child=
    // 0x6eb408: add             SP, SP, #0x10
    // 0x6eb40c: r0 = Null
    //     0x6eb40c: mov             x0, NULL
    // 0x6eb410: LeaveFrame
    //     0x6eb410: mov             SP, fp
    //     0x6eb414: ldp             fp, lr, [SP], #0x10
    // 0x6eb418: ret
    //     0x6eb418: ret             
    // 0x6eb41c: r0 = StackOverflowSharedWithFPURegs()
    //     0x6eb41c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x6eb420: b               #0x6eb36c
  }
}

// class id: 2498, size: 0x88, field offset: 0x88
class RenderPhysicalShape extends _RenderPhysicalModelBase<Path> {

  _ hitTest(/* No info */) {
    // ** addr: 0x640084, size: 0xa0
    // 0x640084: EnterFrame
    //     0x640084: stp             fp, lr, [SP, #-0x10]!
    //     0x640088: mov             fp, SP
    // 0x64008c: CheckStackOverflow
    //     0x64008c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x640090: cmp             SP, x16
    //     0x640094: b.ls            #0x640118
    // 0x640098: ldr             x0, [fp, #0x20]
    // 0x64009c: LoadField: r1 = r0->field_67
    //     0x64009c: ldur            w1, [x0, #0x67]
    // 0x6400a0: DecompressPointer r1
    //     0x6400a0: add             x1, x1, HEAP, lsl #32
    // 0x6400a4: cmp             w1, NULL
    // 0x6400a8: b.eq            #0x6400f0
    // 0x6400ac: SaveReg r0
    //     0x6400ac: str             x0, [SP, #-8]!
    // 0x6400b0: r0 = _updateClip()
    //     0x6400b0: bl              #0x63f548  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_updateClip
    // 0x6400b4: add             SP, SP, #8
    // 0x6400b8: ldr             x0, [fp, #0x20]
    // 0x6400bc: LoadField: r1 = r0->field_6b
    //     0x6400bc: ldur            w1, [x0, #0x6b]
    // 0x6400c0: DecompressPointer r1
    //     0x6400c0: add             x1, x1, HEAP, lsl #32
    // 0x6400c4: cmp             w1, NULL
    // 0x6400c8: b.eq            #0x640120
    // 0x6400cc: ldr             x16, [fp, #0x10]
    // 0x6400d0: stp             x16, x1, [SP, #-0x10]!
    // 0x6400d4: r0 = contains()
    //     0x6400d4: bl              #0x640124  ; [dart:ui] Path::contains
    // 0x6400d8: add             SP, SP, #0x10
    // 0x6400dc: tbz             w0, #4, #0x6400f0
    // 0x6400e0: r0 = false
    //     0x6400e0: add             x0, NULL, #0x30  ; false
    // 0x6400e4: LeaveFrame
    //     0x6400e4: mov             SP, fp
    //     0x6400e8: ldp             fp, lr, [SP], #0x10
    // 0x6400ec: ret
    //     0x6400ec: ret             
    // 0x6400f0: ldr             x16, [fp, #0x20]
    // 0x6400f4: ldr             lr, [fp, #0x18]
    // 0x6400f8: stp             lr, x16, [SP, #-0x10]!
    // 0x6400fc: ldr             x16, [fp, #0x10]
    // 0x640100: SaveReg r16
    //     0x640100: str             x16, [SP, #-8]!
    // 0x640104: r0 = hitTest()
    //     0x640104: bl              #0x640b9c  ; [package:flutter/src/rendering/box.dart] RenderBox::hitTest
    // 0x640108: add             SP, SP, #0x18
    // 0x64010c: LeaveFrame
    //     0x64010c: mov             SP, fp
    //     0x640110: ldp             fp, lr, [SP], #0x10
    // 0x640114: ret
    //     0x640114: ret             
    // 0x640118: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x640118: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64011c: b               #0x640098
    // 0x640120: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x640120: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, PaintingContext, Offset) {
    // ** addr: 0x66450c, size: 0x150
    // 0x66450c: EnterFrame
    //     0x66450c: stp             fp, lr, [SP, #-0x10]!
    //     0x664510: mov             fp, SP
    // 0x664514: AllocStack(0x18)
    //     0x664514: sub             SP, SP, #0x18
    // 0x664518: SetupParameters()
    //     0x664518: ldr             x0, [fp, #0x20]
    //     0x66451c: ldur            w1, [x0, #0x17]
    //     0x664520: add             x1, x1, HEAP, lsl #32
    //     0x664524: stur            x1, [fp, #-0x10]
    // 0x664528: CheckStackOverflow
    //     0x664528: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66452c: cmp             SP, x16
    //     0x664530: b.ls            #0x664654
    // 0x664534: LoadField: r2 = r1->field_13
    //     0x664534: ldur            w2, [x1, #0x13]
    // 0x664538: DecompressPointer r2
    //     0x664538: add             x2, x2, HEAP, lsl #32
    // 0x66453c: mov             x0, x2
    // 0x664540: stur            x2, [fp, #-8]
    // 0x664544: tbnz            w0, #5, #0x66454c
    // 0x664548: r0 = AssertBoolean()
    //     0x664548: bl              #0xd67df0  ; AssertBooleanStub
    // 0x66454c: ldur            x0, [fp, #-8]
    // 0x664550: tbnz            w0, #4, #0x664620
    // 0x664554: ldur            x0, [fp, #-0x10]
    // 0x664558: ldr             x16, [fp, #0x18]
    // 0x66455c: SaveReg r16
    //     0x66455c: str             x16, [SP, #-8]!
    // 0x664560: r0 = canvas()
    //     0x664560: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x664564: add             SP, SP, #8
    // 0x664568: stur            x0, [fp, #-8]
    // 0x66456c: r16 = 112
    //     0x66456c: mov             x16, #0x70
    // 0x664570: stp             x16, NULL, [SP, #-0x10]!
    // 0x664574: r0 = ByteData()
    //     0x664574: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x664578: add             SP, SP, #0x10
    // 0x66457c: stur            x0, [fp, #-0x18]
    // 0x664580: r0 = Paint()
    //     0x664580: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x664584: mov             x1, x0
    // 0x664588: ldur            x0, [fp, #-0x18]
    // 0x66458c: StoreField: r1->field_7 = r0
    //     0x66458c: stur            w0, [x1, #7]
    // 0x664590: ldur            x2, [fp, #-0x10]
    // 0x664594: LoadField: r3 = r2->field_f
    //     0x664594: ldur            w3, [x2, #0xf]
    // 0x664598: DecompressPointer r3
    //     0x664598: add             x3, x3, HEAP, lsl #32
    // 0x66459c: LoadField: r4 = r3->field_83
    //     0x66459c: ldur            w4, [x3, #0x83]
    // 0x6645a0: DecompressPointer r4
    //     0x6645a0: add             x4, x4, HEAP, lsl #32
    // 0x6645a4: r3 = LoadClassIdInstr(r4)
    //     0x6645a4: ldur            x3, [x4, #-1]
    //     0x6645a8: ubfx            x3, x3, #0xc, #0x14
    // 0x6645ac: lsl             x3, x3, #1
    // 0x6645b0: r17 = 10124
    //     0x6645b0: mov             x17, #0x278c
    // 0x6645b4: cmp             w3, w17
    // 0x6645b8: b.gt            #0x6645c8
    // 0x6645bc: r17 = 10122
    //     0x6645bc: mov             x17, #0x278a
    // 0x6645c0: cmp             w3, w17
    // 0x6645c4: b.ge            #0x6645e0
    // 0x6645c8: r17 = 10114
    //     0x6645c8: mov             x17, #0x2782
    // 0x6645cc: cmp             w3, w17
    // 0x6645d0: b.eq            #0x6645e0
    // 0x6645d4: r17 = 10118
    //     0x6645d4: mov             x17, #0x2786
    // 0x6645d8: cmp             w3, w17
    // 0x6645dc: b.ne            #0x6645e8
    // 0x6645e0: LoadField: r3 = r4->field_7
    //     0x6645e0: ldur            x3, [x4, #7]
    // 0x6645e4: b               #0x6645f8
    // 0x6645e8: LoadField: r3 = r4->field_f
    //     0x6645e8: ldur            w3, [x4, #0xf]
    // 0x6645ec: DecompressPointer r3
    //     0x6645ec: add             x3, x3, HEAP, lsl #32
    // 0x6645f0: LoadField: r4 = r3->field_7
    //     0x6645f0: ldur            x4, [x3, #7]
    // 0x6645f4: mov             x3, x4
    // 0x6645f8: eor             x4, x3, #0xff000000
    // 0x6645fc: LoadField: r3 = r0->field_17
    //     0x6645fc: ldur            w3, [x0, #0x17]
    // 0x664600: DecompressPointer r3
    //     0x664600: add             x3, x3, HEAP, lsl #32
    // 0x664604: sxtw            x4, w4
    // 0x664608: LoadField: r0 = r3->field_7
    //     0x664608: ldur            x0, [x3, #7]
    // 0x66460c: str             w4, [x0, #4]
    // 0x664610: ldur            x16, [fp, #-8]
    // 0x664614: stp             x1, x16, [SP, #-0x10]!
    // 0x664618: r0 = drawPaint()
    //     0x664618: bl              #0x66465c  ; [dart:ui] Canvas::drawPaint
    // 0x66461c: add             SP, SP, #0x10
    // 0x664620: ldur            x0, [fp, #-0x10]
    // 0x664624: LoadField: r1 = r0->field_f
    //     0x664624: ldur            w1, [x0, #0xf]
    // 0x664628: DecompressPointer r1
    //     0x664628: add             x1, x1, HEAP, lsl #32
    // 0x66462c: ldr             x16, [fp, #0x18]
    // 0x664630: stp             x16, x1, [SP, #-0x10]!
    // 0x664634: ldr             x16, [fp, #0x10]
    // 0x664638: SaveReg r16
    //     0x664638: str             x16, [SP, #-8]!
    // 0x66463c: r0 = paint()
    //     0x66463c: bl              #0x669ddc  ; [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::paint
    // 0x664640: add             SP, SP, #0x18
    // 0x664644: r0 = Null
    //     0x664644: mov             x0, NULL
    // 0x664648: LeaveFrame
    //     0x664648: mov             SP, fp
    //     0x66464c: ldp             fp, lr, [SP], #0x10
    // 0x664650: ret
    //     0x664650: ret             
    // 0x664654: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x664654: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x664658: b               #0x664534
  }
  _ paint(/* No info */) {
    // ** addr: 0x664a60, size: 0x418
    // 0x664a60: EnterFrame
    //     0x664a60: stp             fp, lr, [SP, #-0x10]!
    //     0x664a64: mov             fp, SP
    // 0x664a68: AllocStack(0x38)
    //     0x664a68: sub             SP, SP, #0x38
    // 0x664a6c: CheckStackOverflow
    //     0x664a6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x664a70: cmp             SP, x16
    //     0x664a74: b.ls            #0x664e58
    // 0x664a78: r1 = 2
    //     0x664a78: mov             x1, #2
    // 0x664a7c: r0 = AllocateContext()
    //     0x664a7c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x664a80: mov             x1, x0
    // 0x664a84: ldr             x0, [fp, #0x20]
    // 0x664a88: stur            x1, [fp, #-8]
    // 0x664a8c: StoreField: r1->field_f = r0
    //     0x664a8c: stur            w0, [x1, #0xf]
    // 0x664a90: LoadField: r2 = r0->field_5f
    //     0x664a90: ldur            w2, [x0, #0x5f]
    // 0x664a94: DecompressPointer r2
    //     0x664a94: add             x2, x2, HEAP, lsl #32
    // 0x664a98: cmp             w2, NULL
    // 0x664a9c: b.ne            #0x664ac4
    // 0x664aa0: LoadField: r1 = r0->field_2f
    //     0x664aa0: ldur            w1, [x0, #0x2f]
    // 0x664aa4: DecompressPointer r1
    //     0x664aa4: add             x1, x1, HEAP, lsl #32
    // 0x664aa8: stp             NULL, x1, [SP, #-0x10]!
    // 0x664aac: r0 = layer=()
    //     0x664aac: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x664ab0: add             SP, SP, #0x10
    // 0x664ab4: r0 = Null
    //     0x664ab4: mov             x0, NULL
    // 0x664ab8: LeaveFrame
    //     0x664ab8: mov             SP, fp
    //     0x664abc: ldp             fp, lr, [SP], #0x10
    // 0x664ac0: ret
    //     0x664ac0: ret             
    // 0x664ac4: SaveReg r0
    //     0x664ac4: str             x0, [SP, #-8]!
    // 0x664ac8: r0 = _updateClip()
    //     0x664ac8: bl              #0x63f548  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_updateClip
    // 0x664acc: add             SP, SP, #8
    // 0x664ad0: ldr             x0, [fp, #0x20]
    // 0x664ad4: LoadField: r1 = r0->field_57
    //     0x664ad4: ldur            w1, [x0, #0x57]
    // 0x664ad8: DecompressPointer r1
    //     0x664ad8: add             x1, x1, HEAP, lsl #32
    // 0x664adc: cmp             w1, NULL
    // 0x664ae0: b.eq            #0x664e60
    // 0x664ae4: ldr             x16, [fp, #0x10]
    // 0x664ae8: stp             x1, x16, [SP, #-0x10]!
    // 0x664aec: r0 = &()
    //     0x664aec: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x664af0: add             SP, SP, #0x10
    // 0x664af4: mov             x1, x0
    // 0x664af8: ldr             x0, [fp, #0x20]
    // 0x664afc: stur            x1, [fp, #-0x10]
    // 0x664b00: LoadField: r2 = r0->field_6b
    //     0x664b00: ldur            w2, [x0, #0x6b]
    // 0x664b04: DecompressPointer r2
    //     0x664b04: add             x2, x2, HEAP, lsl #32
    // 0x664b08: cmp             w2, NULL
    // 0x664b0c: b.eq            #0x664e64
    // 0x664b10: ldr             x16, [fp, #0x10]
    // 0x664b14: stp             x16, x2, [SP, #-0x10]!
    // 0x664b18: r0 = shift()
    //     0x664b18: bl              #0x662dc8  ; [dart:ui] Path::shift
    // 0x664b1c: add             SP, SP, #0x10
    // 0x664b20: stur            x0, [fp, #-0x18]
    // 0x664b24: ldr             x16, [fp, #0x18]
    // 0x664b28: SaveReg r16
    //     0x664b28: str             x16, [SP, #-8]!
    // 0x664b2c: r0 = canvas()
    //     0x664b2c: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x664b30: add             SP, SP, #8
    // 0x664b34: mov             x1, x0
    // 0x664b38: ldr             x0, [fp, #0x20]
    // 0x664b3c: stur            x1, [fp, #-0x20]
    // 0x664b40: LoadField: d0 = r0->field_77
    //     0x664b40: ldur            d0, [x0, #0x77]
    // 0x664b44: d1 = 0.000000
    //     0x664b44: eor             v1.16b, v1.16b, v1.16b
    // 0x664b48: fcmp            d0, d1
    // 0x664b4c: b.eq            #0x664c54
    // 0x664b50: d0 = 20.000000
    //     0x664b50: fmov            d0, #20.00000000
    // 0x664b54: ldur            x16, [fp, #-0x10]
    // 0x664b58: SaveReg r16
    //     0x664b58: str             x16, [SP, #-8]!
    // 0x664b5c: SaveReg d0
    //     0x664b5c: str             d0, [SP, #-8]!
    // 0x664b60: r0 = inflate()
    //     0x664b60: bl              #0x5d1480  ; [dart:ui] Rect::inflate
    // 0x664b64: add             SP, SP, #0x10
    // 0x664b68: stur            x0, [fp, #-0x10]
    // 0x664b6c: r0 = InitLateStaticField(0xed8) // [package:flutter/src/rendering/proxy_box.dart] ::_transparentPaint
    //     0x664b6c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x664b70: ldr             x0, [x0, #0x1db0]
    //     0x664b74: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x664b78: cmp             w0, w16
    //     0x664b7c: b.ne            #0x664b8c
    //     0x664b80: add             x2, PP, #0x2d, lsl #12  ; [pp+0x2d638] Field <::._transparentPaint@907160605>: static late final (offset: 0xed8)
    //     0x664b84: ldr             x2, [x2, #0x638]
    //     0x664b88: bl              #0xd67cdc
    // 0x664b8c: ldur            x16, [fp, #-0x20]
    // 0x664b90: ldur            lr, [fp, #-0x10]
    // 0x664b94: stp             lr, x16, [SP, #-0x10]!
    // 0x664b98: SaveReg r0
    //     0x664b98: str             x0, [SP, #-8]!
    // 0x664b9c: r0 = drawRect()
    //     0x664b9c: bl              #0x65e610  ; [dart:ui] Canvas::drawRect
    // 0x664ba0: add             SP, SP, #0x18
    // 0x664ba4: ldr             x0, [fp, #0x20]
    // 0x664ba8: LoadField: r1 = r0->field_7f
    //     0x664ba8: ldur            w1, [x0, #0x7f]
    // 0x664bac: DecompressPointer r1
    //     0x664bac: add             x1, x1, HEAP, lsl #32
    // 0x664bb0: LoadField: d0 = r0->field_77
    //     0x664bb0: ldur            d0, [x0, #0x77]
    // 0x664bb4: LoadField: r2 = r0->field_83
    //     0x664bb4: ldur            w2, [x0, #0x83]
    // 0x664bb8: DecompressPointer r2
    //     0x664bb8: add             x2, x2, HEAP, lsl #32
    // 0x664bbc: r3 = LoadClassIdInstr(r2)
    //     0x664bbc: ldur            x3, [x2, #-1]
    //     0x664bc0: ubfx            x3, x3, #0xc, #0x14
    // 0x664bc4: lsl             x3, x3, #1
    // 0x664bc8: r17 = 10124
    //     0x664bc8: mov             x17, #0x278c
    // 0x664bcc: cmp             w3, w17
    // 0x664bd0: b.gt            #0x664be0
    // 0x664bd4: r17 = 10122
    //     0x664bd4: mov             x17, #0x278a
    // 0x664bd8: cmp             w3, w17
    // 0x664bdc: b.ge            #0x664bf8
    // 0x664be0: r17 = 10114
    //     0x664be0: mov             x17, #0x2782
    // 0x664be4: cmp             w3, w17
    // 0x664be8: b.eq            #0x664bf8
    // 0x664bec: r17 = 10118
    //     0x664bec: mov             x17, #0x2786
    // 0x664bf0: cmp             w3, w17
    // 0x664bf4: b.ne            #0x664c00
    // 0x664bf8: LoadField: r3 = r2->field_7
    //     0x664bf8: ldur            x3, [x2, #7]
    // 0x664bfc: b               #0x664c10
    // 0x664c00: LoadField: r3 = r2->field_f
    //     0x664c00: ldur            w3, [x2, #0xf]
    // 0x664c04: DecompressPointer r3
    //     0x664c04: add             x3, x3, HEAP, lsl #32
    // 0x664c08: LoadField: r2 = r3->field_7
    //     0x664c08: ldur            x2, [x3, #7]
    // 0x664c0c: mov             x3, x2
    // 0x664c10: r2 = 4278190080
    //     0x664c10: mov             x2, #0xff000000
    // 0x664c14: ubfx            x3, x3, #0, #0x20
    // 0x664c18: and             x4, x3, x2
    // 0x664c1c: ubfx            x4, x4, #0, #0x20
    // 0x664c20: asr             x2, x4, #0x18
    // 0x664c24: cmp             x2, #0xff
    // 0x664c28: r16 = true
    //     0x664c28: add             x16, NULL, #0x20  ; true
    // 0x664c2c: r17 = false
    //     0x664c2c: add             x17, NULL, #0x30  ; false
    // 0x664c30: csel            x3, x16, x17, ne
    // 0x664c34: ldur            x16, [fp, #-0x20]
    // 0x664c38: ldur            lr, [fp, #-0x18]
    // 0x664c3c: stp             lr, x16, [SP, #-0x10]!
    // 0x664c40: SaveReg r1
    //     0x664c40: str             x1, [SP, #-8]!
    // 0x664c44: SaveReg d0
    //     0x664c44: str             d0, [SP, #-8]!
    // 0x664c48: SaveReg r3
    //     0x664c48: str             x3, [SP, #-8]!
    // 0x664c4c: r0 = drawShadow()
    //     0x664c4c: bl              #0x663d94  ; [dart:ui] Canvas::drawShadow
    // 0x664c50: add             SP, SP, #0x28
    // 0x664c54: ldr             x0, [fp, #0x20]
    // 0x664c58: ldur            x2, [fp, #-8]
    // 0x664c5c: LoadField: r1 = r0->field_6f
    //     0x664c5c: ldur            w1, [x0, #0x6f]
    // 0x664c60: DecompressPointer r1
    //     0x664c60: add             x1, x1, HEAP, lsl #32
    // 0x664c64: r16 = Instance_Clip
    //     0x664c64: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d228] Obj!Clip@b67671
    //     0x664c68: ldr             x16, [x16, #0x228]
    // 0x664c6c: cmp             w1, w16
    // 0x664c70: r16 = true
    //     0x664c70: add             x16, NULL, #0x20  ; true
    // 0x664c74: r17 = false
    //     0x664c74: add             x17, NULL, #0x30  ; false
    // 0x664c78: csel            x3, x16, x17, eq
    // 0x664c7c: StoreField: r2->field_13 = r3
    //     0x664c7c: stur            w3, [x2, #0x13]
    // 0x664c80: tbz             w3, #4, #0x664d38
    // 0x664c84: r16 = 112
    //     0x664c84: mov             x16, #0x70
    // 0x664c88: stp             x16, NULL, [SP, #-0x10]!
    // 0x664c8c: r0 = ByteData()
    //     0x664c8c: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x664c90: add             SP, SP, #0x10
    // 0x664c94: stur            x0, [fp, #-0x10]
    // 0x664c98: r0 = Paint()
    //     0x664c98: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x664c9c: mov             x1, x0
    // 0x664ca0: ldur            x0, [fp, #-0x10]
    // 0x664ca4: StoreField: r1->field_7 = r0
    //     0x664ca4: stur            w0, [x1, #7]
    // 0x664ca8: ldr             x2, [fp, #0x20]
    // 0x664cac: LoadField: r3 = r2->field_83
    //     0x664cac: ldur            w3, [x2, #0x83]
    // 0x664cb0: DecompressPointer r3
    //     0x664cb0: add             x3, x3, HEAP, lsl #32
    // 0x664cb4: r4 = LoadClassIdInstr(r3)
    //     0x664cb4: ldur            x4, [x3, #-1]
    //     0x664cb8: ubfx            x4, x4, #0xc, #0x14
    // 0x664cbc: lsl             x4, x4, #1
    // 0x664cc0: r17 = 10124
    //     0x664cc0: mov             x17, #0x278c
    // 0x664cc4: cmp             w4, w17
    // 0x664cc8: b.gt            #0x664cd8
    // 0x664ccc: r17 = 10122
    //     0x664ccc: mov             x17, #0x278a
    // 0x664cd0: cmp             w4, w17
    // 0x664cd4: b.ge            #0x664cf0
    // 0x664cd8: r17 = 10114
    //     0x664cd8: mov             x17, #0x2782
    // 0x664cdc: cmp             w4, w17
    // 0x664ce0: b.eq            #0x664cf0
    // 0x664ce4: r17 = 10118
    //     0x664ce4: mov             x17, #0x2786
    // 0x664ce8: cmp             w4, w17
    // 0x664cec: b.ne            #0x664cfc
    // 0x664cf0: LoadField: r4 = r3->field_7
    //     0x664cf0: ldur            x4, [x3, #7]
    // 0x664cf4: mov             x3, x4
    // 0x664cf8: b               #0x664d08
    // 0x664cfc: LoadField: r4 = r3->field_f
    //     0x664cfc: ldur            w4, [x3, #0xf]
    // 0x664d00: DecompressPointer r4
    //     0x664d00: add             x4, x4, HEAP, lsl #32
    // 0x664d04: LoadField: r3 = r4->field_7
    //     0x664d04: ldur            x3, [x4, #7]
    // 0x664d08: eor             x4, x3, #0xff000000
    // 0x664d0c: LoadField: r3 = r0->field_17
    //     0x664d0c: ldur            w3, [x0, #0x17]
    // 0x664d10: DecompressPointer r3
    //     0x664d10: add             x3, x3, HEAP, lsl #32
    // 0x664d14: sxtw            x4, w4
    // 0x664d18: LoadField: r0 = r3->field_7
    //     0x664d18: ldur            x0, [x3, #7]
    // 0x664d1c: str             w4, [x0, #4]
    // 0x664d20: ldur            x16, [fp, #-0x20]
    // 0x664d24: ldur            lr, [fp, #-0x18]
    // 0x664d28: stp             lr, x16, [SP, #-0x10]!
    // 0x664d2c: SaveReg r1
    //     0x664d2c: str             x1, [SP, #-8]!
    // 0x664d30: r0 = drawPath()
    //     0x664d30: bl              #0x664e78  ; [dart:ui] Canvas::drawPath
    // 0x664d34: add             SP, SP, #0x18
    // 0x664d38: ldr             x0, [fp, #0x20]
    // 0x664d3c: LoadField: r1 = r0->field_37
    //     0x664d3c: ldur            w1, [x0, #0x37]
    // 0x664d40: DecompressPointer r1
    //     0x664d40: add             x1, x1, HEAP, lsl #32
    // 0x664d44: r16 = Sentinel
    //     0x664d44: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x664d48: cmp             w1, w16
    // 0x664d4c: b.eq            #0x664e68
    // 0x664d50: stur            x1, [fp, #-0x10]
    // 0x664d54: LoadField: r2 = r0->field_57
    //     0x664d54: ldur            w2, [x0, #0x57]
    // 0x664d58: DecompressPointer r2
    //     0x664d58: add             x2, x2, HEAP, lsl #32
    // 0x664d5c: cmp             w2, NULL
    // 0x664d60: b.eq            #0x664e70
    // 0x664d64: r16 = Instance_Offset
    //     0x664d64: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x664d68: stp             x2, x16, [SP, #-0x10]!
    // 0x664d6c: r0 = &()
    //     0x664d6c: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x664d70: add             SP, SP, #0x10
    // 0x664d74: mov             x4, x0
    // 0x664d78: ldr             x3, [fp, #0x20]
    // 0x664d7c: stur            x4, [fp, #-0x30]
    // 0x664d80: LoadField: r5 = r3->field_6b
    //     0x664d80: ldur            w5, [x3, #0x6b]
    // 0x664d84: DecompressPointer r5
    //     0x664d84: add             x5, x5, HEAP, lsl #32
    // 0x664d88: stur            x5, [fp, #-0x28]
    // 0x664d8c: cmp             w5, NULL
    // 0x664d90: b.eq            #0x664e74
    // 0x664d94: LoadField: r6 = r3->field_2f
    //     0x664d94: ldur            w6, [x3, #0x2f]
    // 0x664d98: DecompressPointer r6
    //     0x664d98: add             x6, x6, HEAP, lsl #32
    // 0x664d9c: stur            x6, [fp, #-0x20]
    // 0x664da0: LoadField: r7 = r6->field_b
    //     0x664da0: ldur            w7, [x6, #0xb]
    // 0x664da4: DecompressPointer r7
    //     0x664da4: add             x7, x7, HEAP, lsl #32
    // 0x664da8: mov             x0, x7
    // 0x664dac: stur            x7, [fp, #-0x18]
    // 0x664db0: r2 = Null
    //     0x664db0: mov             x2, NULL
    // 0x664db4: r1 = Null
    //     0x664db4: mov             x1, NULL
    // 0x664db8: r4 = LoadClassIdInstr(r0)
    //     0x664db8: ldur            x4, [x0, #-1]
    //     0x664dbc: ubfx            x4, x4, #0xc, #0x14
    // 0x664dc0: cmp             x4, #0x953
    // 0x664dc4: b.eq            #0x664ddc
    // 0x664dc8: r8 = ClipPathLayer?
    //     0x664dc8: add             x8, PP, #0x21, lsl #12  ; [pp+0x21aa8] Type: ClipPathLayer?
    //     0x664dcc: ldr             x8, [x8, #0xaa8]
    // 0x664dd0: r3 = Null
    //     0x664dd0: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2d640] Null
    //     0x664dd4: ldr             x3, [x3, #0x640]
    // 0x664dd8: r0 = DefaultNullableTypeTest()
    //     0x664dd8: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x664ddc: ldr             x0, [fp, #0x20]
    // 0x664de0: LoadField: r3 = r0->field_6f
    //     0x664de0: ldur            w3, [x0, #0x6f]
    // 0x664de4: DecompressPointer r3
    //     0x664de4: add             x3, x3, HEAP, lsl #32
    // 0x664de8: ldur            x2, [fp, #-8]
    // 0x664dec: stur            x3, [fp, #-0x38]
    // 0x664df0: r1 = Function '<anonymous closure>':.
    //     0x664df0: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2d650] AnonymousClosure: (0x66450c), in [package:flutter/src/rendering/proxy_box.dart] RenderPhysicalShape::paint (0x664a60)
    //     0x664df4: ldr             x1, [x1, #0x650]
    // 0x664df8: r0 = AllocateClosure()
    //     0x664df8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x664dfc: ldr             x16, [fp, #0x18]
    // 0x664e00: ldur            lr, [fp, #-0x10]
    // 0x664e04: stp             lr, x16, [SP, #-0x10]!
    // 0x664e08: ldr             x16, [fp, #0x10]
    // 0x664e0c: ldur            lr, [fp, #-0x30]
    // 0x664e10: stp             lr, x16, [SP, #-0x10]!
    // 0x664e14: ldur            x16, [fp, #-0x28]
    // 0x664e18: stp             x0, x16, [SP, #-0x10]!
    // 0x664e1c: ldur            x16, [fp, #-0x18]
    // 0x664e20: ldur            lr, [fp, #-0x38]
    // 0x664e24: stp             lr, x16, [SP, #-0x10]!
    // 0x664e28: r4 = const [0, 0x8, 0x8, 0x7, clipBehavior, 0x7, null]
    //     0x664e28: add             x4, PP, #0x21, lsl #12  ; [pp+0x21ac0] List(7) [0, 0x8, 0x8, 0x7, "clipBehavior", 0x7, Null]
    //     0x664e2c: ldr             x4, [x4, #0xac0]
    // 0x664e30: r0 = pushClipPath()
    //     0x664e30: bl              #0x6626a0  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipPath
    // 0x664e34: add             SP, SP, #0x40
    // 0x664e38: ldur            x16, [fp, #-0x20]
    // 0x664e3c: stp             x0, x16, [SP, #-0x10]!
    // 0x664e40: r0 = layer=()
    //     0x664e40: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x664e44: add             SP, SP, #0x10
    // 0x664e48: r0 = Null
    //     0x664e48: mov             x0, NULL
    // 0x664e4c: LeaveFrame
    //     0x664e4c: mov             SP, fp
    //     0x664e50: ldp             fp, lr, [SP], #0x10
    // 0x664e54: ret
    //     0x664e54: ret             
    // 0x664e58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x664e58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x664e5c: b               #0x664a78
    // 0x664e60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x664e60: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x664e64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x664e64: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x664e68: r9 = _needsCompositing
    //     0x664e68: ldr             x9, [PP, #0x4b28]  ; [pp+0x4b28] Field <RenderObject._needsCompositing@904266271>: late (offset: 0x38)
    // 0x664e6c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x664e6c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x664e70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x664e70: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x664e74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x664e74: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _defaultClip(/* No info */) {
    // ** addr: 0xb0df78, size: 0x7c
    // 0xb0df78: EnterFrame
    //     0xb0df78: stp             fp, lr, [SP, #-0x10]!
    //     0xb0df7c: mov             fp, SP
    // 0xb0df80: AllocStack(0x8)
    //     0xb0df80: sub             SP, SP, #8
    // 0xb0df84: CheckStackOverflow
    //     0xb0df84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0df88: cmp             SP, x16
    //     0xb0df8c: b.ls            #0xb0dfe8
    // 0xb0df90: r0 = Path()
    //     0xb0df90: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xb0df94: stur            x0, [fp, #-8]
    // 0xb0df98: SaveReg r0
    //     0xb0df98: str             x0, [SP, #-8]!
    // 0xb0df9c: r0 = _constructor()
    //     0xb0df9c: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xb0dfa0: add             SP, SP, #8
    // 0xb0dfa4: ldr             x0, [fp, #0x10]
    // 0xb0dfa8: LoadField: r1 = r0->field_57
    //     0xb0dfa8: ldur            w1, [x0, #0x57]
    // 0xb0dfac: DecompressPointer r1
    //     0xb0dfac: add             x1, x1, HEAP, lsl #32
    // 0xb0dfb0: cmp             w1, NULL
    // 0xb0dfb4: b.eq            #0xb0dff0
    // 0xb0dfb8: r16 = Instance_Offset
    //     0xb0dfb8: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xb0dfbc: stp             x1, x16, [SP, #-0x10]!
    // 0xb0dfc0: r0 = &()
    //     0xb0dfc0: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0xb0dfc4: add             SP, SP, #0x10
    // 0xb0dfc8: ldur            x16, [fp, #-8]
    // 0xb0dfcc: stp             x0, x16, [SP, #-0x10]!
    // 0xb0dfd0: r0 = addRect()
    //     0xb0dfd0: bl              #0x71a7b0  ; [dart:ui] Path::addRect
    // 0xb0dfd4: add             SP, SP, #0x10
    // 0xb0dfd8: ldur            x0, [fp, #-8]
    // 0xb0dfdc: LeaveFrame
    //     0xb0dfdc: mov             SP, fp
    //     0xb0dfe0: ldp             fp, lr, [SP], #0x10
    // 0xb0dfe4: ret
    //     0xb0dfe4: ret             
    // 0xb0dfe8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0dfe8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0dfec: b               #0xb0df90
    // 0xb0dff0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb0dff0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2499, size: 0x90, field offset: 0x88
class RenderPhysicalModel extends _RenderPhysicalModelBase<RRect> {

  _ hitTest(/* No info */) {
    // ** addr: 0x63f718, size: 0xa0
    // 0x63f718: EnterFrame
    //     0x63f718: stp             fp, lr, [SP, #-0x10]!
    //     0x63f71c: mov             fp, SP
    // 0x63f720: CheckStackOverflow
    //     0x63f720: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63f724: cmp             SP, x16
    //     0x63f728: b.ls            #0x63f7ac
    // 0x63f72c: ldr             x0, [fp, #0x20]
    // 0x63f730: LoadField: r1 = r0->field_67
    //     0x63f730: ldur            w1, [x0, #0x67]
    // 0x63f734: DecompressPointer r1
    //     0x63f734: add             x1, x1, HEAP, lsl #32
    // 0x63f738: cmp             w1, NULL
    // 0x63f73c: b.eq            #0x63f784
    // 0x63f740: SaveReg r0
    //     0x63f740: str             x0, [SP, #-8]!
    // 0x63f744: r0 = _updateClip()
    //     0x63f744: bl              #0x63f548  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_updateClip
    // 0x63f748: add             SP, SP, #8
    // 0x63f74c: ldr             x0, [fp, #0x20]
    // 0x63f750: LoadField: r1 = r0->field_6b
    //     0x63f750: ldur            w1, [x0, #0x6b]
    // 0x63f754: DecompressPointer r1
    //     0x63f754: add             x1, x1, HEAP, lsl #32
    // 0x63f758: cmp             w1, NULL
    // 0x63f75c: b.eq            #0x63f7b4
    // 0x63f760: ldr             x16, [fp, #0x10]
    // 0x63f764: stp             x16, x1, [SP, #-0x10]!
    // 0x63f768: r0 = contains()
    //     0x63f768: bl              #0x63f7dc  ; [dart:ui] RRect::contains
    // 0x63f76c: add             SP, SP, #0x10
    // 0x63f770: tbz             w0, #4, #0x63f784
    // 0x63f774: r0 = false
    //     0x63f774: add             x0, NULL, #0x30  ; false
    // 0x63f778: LeaveFrame
    //     0x63f778: mov             SP, fp
    //     0x63f77c: ldp             fp, lr, [SP], #0x10
    // 0x63f780: ret
    //     0x63f780: ret             
    // 0x63f784: ldr             x16, [fp, #0x20]
    // 0x63f788: ldr             lr, [fp, #0x18]
    // 0x63f78c: stp             lr, x16, [SP, #-0x10]!
    // 0x63f790: ldr             x16, [fp, #0x10]
    // 0x63f794: SaveReg r16
    //     0x63f794: str             x16, [SP, #-8]!
    // 0x63f798: r0 = hitTest()
    //     0x63f798: bl              #0x640b9c  ; [package:flutter/src/rendering/box.dart] RenderBox::hitTest
    // 0x63f79c: add             SP, SP, #0x18
    // 0x63f7a0: LeaveFrame
    //     0x63f7a0: mov             SP, fp
    //     0x63f7a4: ldp             fp, lr, [SP], #0x10
    // 0x63f7a8: ret
    //     0x63f7a8: ret             
    // 0x63f7ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63f7ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63f7b0: b               #0x63f72c
    // 0x63f7b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63f7b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0x66397c, size: 0x418
    // 0x66397c: EnterFrame
    //     0x66397c: stp             fp, lr, [SP, #-0x10]!
    //     0x663980: mov             fp, SP
    // 0x663984: AllocStack(0x38)
    //     0x663984: sub             SP, SP, #0x38
    // 0x663988: CheckStackOverflow
    //     0x663988: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66398c: cmp             SP, x16
    //     0x663990: b.ls            #0x663d78
    // 0x663994: r1 = 2
    //     0x663994: mov             x1, #2
    // 0x663998: r0 = AllocateContext()
    //     0x663998: bl              #0xd68aa4  ; AllocateContextStub
    // 0x66399c: mov             x1, x0
    // 0x6639a0: ldr             x0, [fp, #0x20]
    // 0x6639a4: stur            x1, [fp, #-8]
    // 0x6639a8: StoreField: r1->field_f = r0
    //     0x6639a8: stur            w0, [x1, #0xf]
    // 0x6639ac: LoadField: r2 = r0->field_5f
    //     0x6639ac: ldur            w2, [x0, #0x5f]
    // 0x6639b0: DecompressPointer r2
    //     0x6639b0: add             x2, x2, HEAP, lsl #32
    // 0x6639b4: cmp             w2, NULL
    // 0x6639b8: b.ne            #0x6639e0
    // 0x6639bc: LoadField: r1 = r0->field_2f
    //     0x6639bc: ldur            w1, [x0, #0x2f]
    // 0x6639c0: DecompressPointer r1
    //     0x6639c0: add             x1, x1, HEAP, lsl #32
    // 0x6639c4: stp             NULL, x1, [SP, #-0x10]!
    // 0x6639c8: r0 = layer=()
    //     0x6639c8: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x6639cc: add             SP, SP, #0x10
    // 0x6639d0: r0 = Null
    //     0x6639d0: mov             x0, NULL
    // 0x6639d4: LeaveFrame
    //     0x6639d4: mov             SP, fp
    //     0x6639d8: ldp             fp, lr, [SP], #0x10
    // 0x6639dc: ret
    //     0x6639dc: ret             
    // 0x6639e0: SaveReg r0
    //     0x6639e0: str             x0, [SP, #-8]!
    // 0x6639e4: r0 = _updateClip()
    //     0x6639e4: bl              #0x63f548  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_updateClip
    // 0x6639e8: add             SP, SP, #8
    // 0x6639ec: ldr             x0, [fp, #0x20]
    // 0x6639f0: LoadField: r1 = r0->field_6b
    //     0x6639f0: ldur            w1, [x0, #0x6b]
    // 0x6639f4: DecompressPointer r1
    //     0x6639f4: add             x1, x1, HEAP, lsl #32
    // 0x6639f8: cmp             w1, NULL
    // 0x6639fc: b.eq            #0x663d80
    // 0x663a00: ldr             x16, [fp, #0x10]
    // 0x663a04: stp             x16, x1, [SP, #-0x10]!
    // 0x663a08: r0 = shift()
    //     0x663a08: bl              #0x65fe90  ; [dart:ui] RRect::shift
    // 0x663a0c: add             SP, SP, #0x10
    // 0x663a10: stur            x0, [fp, #-0x10]
    // 0x663a14: SaveReg r0
    //     0x663a14: str             x0, [SP, #-8]!
    // 0x663a18: r0 = toRect()
    //     0x663a18: bl              #0x52231c  ; [dart:ui] TextBox::toRect
    // 0x663a1c: add             SP, SP, #8
    // 0x663a20: stur            x0, [fp, #-0x18]
    // 0x663a24: r0 = Path()
    //     0x663a24: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0x663a28: stur            x0, [fp, #-0x20]
    // 0x663a2c: SaveReg r0
    //     0x663a2c: str             x0, [SP, #-8]!
    // 0x663a30: r0 = _constructor()
    //     0x663a30: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0x663a34: add             SP, SP, #8
    // 0x663a38: ldur            x16, [fp, #-0x20]
    // 0x663a3c: ldur            lr, [fp, #-0x10]
    // 0x663a40: stp             lr, x16, [SP, #-0x10]!
    // 0x663a44: r0 = addRRect()
    //     0x663a44: bl              #0x664194  ; [dart:ui] Path::addRRect
    // 0x663a48: add             SP, SP, #0x10
    // 0x663a4c: ldr             x16, [fp, #0x18]
    // 0x663a50: SaveReg r16
    //     0x663a50: str             x16, [SP, #-8]!
    // 0x663a54: r0 = canvas()
    //     0x663a54: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x663a58: add             SP, SP, #8
    // 0x663a5c: mov             x1, x0
    // 0x663a60: ldr             x0, [fp, #0x20]
    // 0x663a64: stur            x1, [fp, #-0x28]
    // 0x663a68: LoadField: d0 = r0->field_77
    //     0x663a68: ldur            d0, [x0, #0x77]
    // 0x663a6c: d1 = 0.000000
    //     0x663a6c: eor             v1.16b, v1.16b, v1.16b
    // 0x663a70: fcmp            d0, d1
    // 0x663a74: b.eq            #0x663b7c
    // 0x663a78: d0 = 20.000000
    //     0x663a78: fmov            d0, #20.00000000
    // 0x663a7c: ldur            x16, [fp, #-0x18]
    // 0x663a80: SaveReg r16
    //     0x663a80: str             x16, [SP, #-8]!
    // 0x663a84: SaveReg d0
    //     0x663a84: str             d0, [SP, #-8]!
    // 0x663a88: r0 = inflate()
    //     0x663a88: bl              #0x5d1480  ; [dart:ui] Rect::inflate
    // 0x663a8c: add             SP, SP, #0x10
    // 0x663a90: stur            x0, [fp, #-0x18]
    // 0x663a94: r0 = InitLateStaticField(0xed8) // [package:flutter/src/rendering/proxy_box.dart] ::_transparentPaint
    //     0x663a94: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x663a98: ldr             x0, [x0, #0x1db0]
    //     0x663a9c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x663aa0: cmp             w0, w16
    //     0x663aa4: b.ne            #0x663ab4
    //     0x663aa8: add             x2, PP, #0x2d, lsl #12  ; [pp+0x2d638] Field <::._transparentPaint@907160605>: static late final (offset: 0xed8)
    //     0x663aac: ldr             x2, [x2, #0x638]
    //     0x663ab0: bl              #0xd67cdc
    // 0x663ab4: ldur            x16, [fp, #-0x28]
    // 0x663ab8: ldur            lr, [fp, #-0x18]
    // 0x663abc: stp             lr, x16, [SP, #-0x10]!
    // 0x663ac0: SaveReg r0
    //     0x663ac0: str             x0, [SP, #-8]!
    // 0x663ac4: r0 = drawRect()
    //     0x663ac4: bl              #0x65e610  ; [dart:ui] Canvas::drawRect
    // 0x663ac8: add             SP, SP, #0x18
    // 0x663acc: ldr             x0, [fp, #0x20]
    // 0x663ad0: LoadField: r1 = r0->field_7f
    //     0x663ad0: ldur            w1, [x0, #0x7f]
    // 0x663ad4: DecompressPointer r1
    //     0x663ad4: add             x1, x1, HEAP, lsl #32
    // 0x663ad8: LoadField: d0 = r0->field_77
    //     0x663ad8: ldur            d0, [x0, #0x77]
    // 0x663adc: LoadField: r2 = r0->field_83
    //     0x663adc: ldur            w2, [x0, #0x83]
    // 0x663ae0: DecompressPointer r2
    //     0x663ae0: add             x2, x2, HEAP, lsl #32
    // 0x663ae4: r3 = LoadClassIdInstr(r2)
    //     0x663ae4: ldur            x3, [x2, #-1]
    //     0x663ae8: ubfx            x3, x3, #0xc, #0x14
    // 0x663aec: lsl             x3, x3, #1
    // 0x663af0: r17 = 10124
    //     0x663af0: mov             x17, #0x278c
    // 0x663af4: cmp             w3, w17
    // 0x663af8: b.gt            #0x663b08
    // 0x663afc: r17 = 10122
    //     0x663afc: mov             x17, #0x278a
    // 0x663b00: cmp             w3, w17
    // 0x663b04: b.ge            #0x663b20
    // 0x663b08: r17 = 10114
    //     0x663b08: mov             x17, #0x2782
    // 0x663b0c: cmp             w3, w17
    // 0x663b10: b.eq            #0x663b20
    // 0x663b14: r17 = 10118
    //     0x663b14: mov             x17, #0x2786
    // 0x663b18: cmp             w3, w17
    // 0x663b1c: b.ne            #0x663b28
    // 0x663b20: LoadField: r3 = r2->field_7
    //     0x663b20: ldur            x3, [x2, #7]
    // 0x663b24: b               #0x663b38
    // 0x663b28: LoadField: r3 = r2->field_f
    //     0x663b28: ldur            w3, [x2, #0xf]
    // 0x663b2c: DecompressPointer r3
    //     0x663b2c: add             x3, x3, HEAP, lsl #32
    // 0x663b30: LoadField: r2 = r3->field_7
    //     0x663b30: ldur            x2, [x3, #7]
    // 0x663b34: mov             x3, x2
    // 0x663b38: r2 = 4278190080
    //     0x663b38: mov             x2, #0xff000000
    // 0x663b3c: ubfx            x3, x3, #0, #0x20
    // 0x663b40: and             x4, x3, x2
    // 0x663b44: ubfx            x4, x4, #0, #0x20
    // 0x663b48: asr             x2, x4, #0x18
    // 0x663b4c: cmp             x2, #0xff
    // 0x663b50: r16 = true
    //     0x663b50: add             x16, NULL, #0x20  ; true
    // 0x663b54: r17 = false
    //     0x663b54: add             x17, NULL, #0x30  ; false
    // 0x663b58: csel            x3, x16, x17, ne
    // 0x663b5c: ldur            x16, [fp, #-0x28]
    // 0x663b60: ldur            lr, [fp, #-0x20]
    // 0x663b64: stp             lr, x16, [SP, #-0x10]!
    // 0x663b68: SaveReg r1
    //     0x663b68: str             x1, [SP, #-8]!
    // 0x663b6c: SaveReg d0
    //     0x663b6c: str             d0, [SP, #-8]!
    // 0x663b70: SaveReg r3
    //     0x663b70: str             x3, [SP, #-8]!
    // 0x663b74: r0 = drawShadow()
    //     0x663b74: bl              #0x663d94  ; [dart:ui] Canvas::drawShadow
    // 0x663b78: add             SP, SP, #0x28
    // 0x663b7c: ldr             x0, [fp, #0x20]
    // 0x663b80: ldur            x2, [fp, #-8]
    // 0x663b84: LoadField: r1 = r0->field_6f
    //     0x663b84: ldur            w1, [x0, #0x6f]
    // 0x663b88: DecompressPointer r1
    //     0x663b88: add             x1, x1, HEAP, lsl #32
    // 0x663b8c: r16 = Instance_Clip
    //     0x663b8c: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d228] Obj!Clip@b67671
    //     0x663b90: ldr             x16, [x16, #0x228]
    // 0x663b94: cmp             w1, w16
    // 0x663b98: r16 = true
    //     0x663b98: add             x16, NULL, #0x20  ; true
    // 0x663b9c: r17 = false
    //     0x663b9c: add             x17, NULL, #0x30  ; false
    // 0x663ba0: csel            x3, x16, x17, eq
    // 0x663ba4: StoreField: r2->field_13 = r3
    //     0x663ba4: stur            w3, [x2, #0x13]
    // 0x663ba8: tbz             w3, #4, #0x663c60
    // 0x663bac: r16 = 112
    //     0x663bac: mov             x16, #0x70
    // 0x663bb0: stp             x16, NULL, [SP, #-0x10]!
    // 0x663bb4: r0 = ByteData()
    //     0x663bb4: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x663bb8: add             SP, SP, #0x10
    // 0x663bbc: stur            x0, [fp, #-0x18]
    // 0x663bc0: r0 = Paint()
    //     0x663bc0: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x663bc4: mov             x1, x0
    // 0x663bc8: ldur            x0, [fp, #-0x18]
    // 0x663bcc: StoreField: r1->field_7 = r0
    //     0x663bcc: stur            w0, [x1, #7]
    // 0x663bd0: ldr             x2, [fp, #0x20]
    // 0x663bd4: LoadField: r3 = r2->field_83
    //     0x663bd4: ldur            w3, [x2, #0x83]
    // 0x663bd8: DecompressPointer r3
    //     0x663bd8: add             x3, x3, HEAP, lsl #32
    // 0x663bdc: r4 = LoadClassIdInstr(r3)
    //     0x663bdc: ldur            x4, [x3, #-1]
    //     0x663be0: ubfx            x4, x4, #0xc, #0x14
    // 0x663be4: lsl             x4, x4, #1
    // 0x663be8: r17 = 10124
    //     0x663be8: mov             x17, #0x278c
    // 0x663bec: cmp             w4, w17
    // 0x663bf0: b.gt            #0x663c00
    // 0x663bf4: r17 = 10122
    //     0x663bf4: mov             x17, #0x278a
    // 0x663bf8: cmp             w4, w17
    // 0x663bfc: b.ge            #0x663c18
    // 0x663c00: r17 = 10114
    //     0x663c00: mov             x17, #0x2782
    // 0x663c04: cmp             w4, w17
    // 0x663c08: b.eq            #0x663c18
    // 0x663c0c: r17 = 10118
    //     0x663c0c: mov             x17, #0x2786
    // 0x663c10: cmp             w4, w17
    // 0x663c14: b.ne            #0x663c24
    // 0x663c18: LoadField: r4 = r3->field_7
    //     0x663c18: ldur            x4, [x3, #7]
    // 0x663c1c: mov             x3, x4
    // 0x663c20: b               #0x663c30
    // 0x663c24: LoadField: r4 = r3->field_f
    //     0x663c24: ldur            w4, [x3, #0xf]
    // 0x663c28: DecompressPointer r4
    //     0x663c28: add             x4, x4, HEAP, lsl #32
    // 0x663c2c: LoadField: r3 = r4->field_7
    //     0x663c2c: ldur            x3, [x4, #7]
    // 0x663c30: eor             x4, x3, #0xff000000
    // 0x663c34: LoadField: r3 = r0->field_17
    //     0x663c34: ldur            w3, [x0, #0x17]
    // 0x663c38: DecompressPointer r3
    //     0x663c38: add             x3, x3, HEAP, lsl #32
    // 0x663c3c: sxtw            x4, w4
    // 0x663c40: LoadField: r0 = r3->field_7
    //     0x663c40: ldur            x0, [x3, #7]
    // 0x663c44: str             w4, [x0, #4]
    // 0x663c48: ldur            x16, [fp, #-0x28]
    // 0x663c4c: ldur            lr, [fp, #-0x10]
    // 0x663c50: stp             lr, x16, [SP, #-0x10]!
    // 0x663c54: SaveReg r1
    //     0x663c54: str             x1, [SP, #-8]!
    // 0x663c58: r0 = drawRRect()
    //     0x663c58: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0x663c5c: add             SP, SP, #0x18
    // 0x663c60: ldr             x0, [fp, #0x20]
    // 0x663c64: LoadField: r1 = r0->field_37
    //     0x663c64: ldur            w1, [x0, #0x37]
    // 0x663c68: DecompressPointer r1
    //     0x663c68: add             x1, x1, HEAP, lsl #32
    // 0x663c6c: r16 = Sentinel
    //     0x663c6c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x663c70: cmp             w1, w16
    // 0x663c74: b.eq            #0x663d84
    // 0x663c78: stur            x1, [fp, #-0x10]
    // 0x663c7c: LoadField: r2 = r0->field_57
    //     0x663c7c: ldur            w2, [x0, #0x57]
    // 0x663c80: DecompressPointer r2
    //     0x663c80: add             x2, x2, HEAP, lsl #32
    // 0x663c84: cmp             w2, NULL
    // 0x663c88: b.eq            #0x663d8c
    // 0x663c8c: r16 = Instance_Offset
    //     0x663c8c: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x663c90: stp             x2, x16, [SP, #-0x10]!
    // 0x663c94: r0 = &()
    //     0x663c94: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x663c98: add             SP, SP, #0x10
    // 0x663c9c: mov             x4, x0
    // 0x663ca0: ldr             x3, [fp, #0x20]
    // 0x663ca4: stur            x4, [fp, #-0x30]
    // 0x663ca8: LoadField: r5 = r3->field_6b
    //     0x663ca8: ldur            w5, [x3, #0x6b]
    // 0x663cac: DecompressPointer r5
    //     0x663cac: add             x5, x5, HEAP, lsl #32
    // 0x663cb0: stur            x5, [fp, #-0x28]
    // 0x663cb4: cmp             w5, NULL
    // 0x663cb8: b.eq            #0x663d90
    // 0x663cbc: LoadField: r6 = r3->field_2f
    //     0x663cbc: ldur            w6, [x3, #0x2f]
    // 0x663cc0: DecompressPointer r6
    //     0x663cc0: add             x6, x6, HEAP, lsl #32
    // 0x663cc4: stur            x6, [fp, #-0x20]
    // 0x663cc8: LoadField: r7 = r6->field_b
    //     0x663cc8: ldur            w7, [x6, #0xb]
    // 0x663ccc: DecompressPointer r7
    //     0x663ccc: add             x7, x7, HEAP, lsl #32
    // 0x663cd0: mov             x0, x7
    // 0x663cd4: stur            x7, [fp, #-0x18]
    // 0x663cd8: r2 = Null
    //     0x663cd8: mov             x2, NULL
    // 0x663cdc: r1 = Null
    //     0x663cdc: mov             x1, NULL
    // 0x663ce0: r4 = LoadClassIdInstr(r0)
    //     0x663ce0: ldur            x4, [x0, #-1]
    //     0x663ce4: ubfx            x4, x4, #0xc, #0x14
    // 0x663ce8: cmp             x4, #0x954
    // 0x663cec: b.eq            #0x663d04
    // 0x663cf0: r8 = ClipRRectLayer?
    //     0x663cf0: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d688] Type: ClipRRectLayer?
    //     0x663cf4: ldr             x8, [x8, #0x688]
    // 0x663cf8: r3 = Null
    //     0x663cf8: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2d690] Null
    //     0x663cfc: ldr             x3, [x3, #0x690]
    // 0x663d00: r0 = DefaultNullableTypeTest()
    //     0x663d00: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x663d04: ldr             x0, [fp, #0x20]
    // 0x663d08: LoadField: r3 = r0->field_6f
    //     0x663d08: ldur            w3, [x0, #0x6f]
    // 0x663d0c: DecompressPointer r3
    //     0x663d0c: add             x3, x3, HEAP, lsl #32
    // 0x663d10: ldur            x2, [fp, #-8]
    // 0x663d14: stur            x3, [fp, #-0x38]
    // 0x663d18: r1 = Function '<anonymous closure>':.
    //     0x663d18: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2d6a0] AnonymousClosure: (0x66450c), in [package:flutter/src/rendering/proxy_box.dart] RenderPhysicalShape::paint (0x664a60)
    //     0x663d1c: ldr             x1, [x1, #0x6a0]
    // 0x663d20: r0 = AllocateClosure()
    //     0x663d20: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x663d24: ldr             x16, [fp, #0x18]
    // 0x663d28: ldur            lr, [fp, #-0x10]
    // 0x663d2c: stp             lr, x16, [SP, #-0x10]!
    // 0x663d30: ldr             x16, [fp, #0x10]
    // 0x663d34: ldur            lr, [fp, #-0x30]
    // 0x663d38: stp             lr, x16, [SP, #-0x10]!
    // 0x663d3c: ldur            x16, [fp, #-0x28]
    // 0x663d40: stp             x0, x16, [SP, #-0x10]!
    // 0x663d44: ldur            x16, [fp, #-0x38]
    // 0x663d48: ldur            lr, [fp, #-0x18]
    // 0x663d4c: stp             lr, x16, [SP, #-0x10]!
    // 0x663d50: r0 = pushClipRRect()
    //     0x663d50: bl              #0x661d8c  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRRect
    // 0x663d54: add             SP, SP, #0x40
    // 0x663d58: ldur            x16, [fp, #-0x20]
    // 0x663d5c: stp             x0, x16, [SP, #-0x10]!
    // 0x663d60: r0 = layer=()
    //     0x663d60: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x663d64: add             SP, SP, #0x10
    // 0x663d68: r0 = Null
    //     0x663d68: mov             x0, NULL
    // 0x663d6c: LeaveFrame
    //     0x663d6c: mov             SP, fp
    //     0x663d70: ldp             fp, lr, [SP], #0x10
    // 0x663d74: ret
    //     0x663d74: ret             
    // 0x663d78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x663d78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x663d7c: b               #0x663994
    // 0x663d80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x663d80: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x663d84: r9 = _needsCompositing
    //     0x663d84: ldr             x9, [PP, #0x4b28]  ; [pp+0x4b28] Field <RenderObject._needsCompositing@904266271>: late (offset: 0x38)
    // 0x663d88: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x663d88: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x663d8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x663d8c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x663d90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x663d90: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ borderRadius=(/* No info */) {
    // ** addr: 0x6c44f8, size: 0xa0
    // 0x6c44f8: EnterFrame
    //     0x6c44f8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c44fc: mov             fp, SP
    // 0x6c4500: CheckStackOverflow
    //     0x6c4500: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c4504: cmp             SP, x16
    //     0x6c4508: b.ls            #0x6c4590
    // 0x6c450c: ldr             x1, [fp, #0x18]
    // 0x6c4510: LoadField: r0 = r1->field_8b
    //     0x6c4510: ldur            w0, [x1, #0x8b]
    // 0x6c4514: DecompressPointer r0
    //     0x6c4514: add             x0, x0, HEAP, lsl #32
    // 0x6c4518: r2 = LoadClassIdInstr(r0)
    //     0x6c4518: ldur            x2, [x0, #-1]
    //     0x6c451c: ubfx            x2, x2, #0xc, #0x14
    // 0x6c4520: ldr             x16, [fp, #0x10]
    // 0x6c4524: stp             x16, x0, [SP, #-0x10]!
    // 0x6c4528: mov             x0, x2
    // 0x6c452c: mov             lr, x0
    // 0x6c4530: ldr             lr, [x21, lr, lsl #3]
    // 0x6c4534: blr             lr
    // 0x6c4538: add             SP, SP, #0x10
    // 0x6c453c: tbnz            w0, #4, #0x6c4550
    // 0x6c4540: r0 = Null
    //     0x6c4540: mov             x0, NULL
    // 0x6c4544: LeaveFrame
    //     0x6c4544: mov             SP, fp
    //     0x6c4548: ldp             fp, lr, [SP], #0x10
    // 0x6c454c: ret
    //     0x6c454c: ret             
    // 0x6c4550: ldr             x1, [fp, #0x18]
    // 0x6c4554: ldr             x0, [fp, #0x10]
    // 0x6c4558: StoreField: r1->field_8b = r0
    //     0x6c4558: stur            w0, [x1, #0x8b]
    //     0x6c455c: ldurb           w16, [x1, #-1]
    //     0x6c4560: ldurb           w17, [x0, #-1]
    //     0x6c4564: and             x16, x17, x16, lsr #2
    //     0x6c4568: tst             x16, HEAP, lsr #32
    //     0x6c456c: b.eq            #0x6c4574
    //     0x6c4570: bl              #0xd6826c
    // 0x6c4574: SaveReg r1
    //     0x6c4574: str             x1, [SP, #-8]!
    // 0x6c4578: r0 = _markNeedsClip()
    //     0x6c4578: bl              #0x6c16d0  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_markNeedsClip
    // 0x6c457c: add             SP, SP, #8
    // 0x6c4580: r0 = Null
    //     0x6c4580: mov             x0, NULL
    // 0x6c4584: LeaveFrame
    //     0x6c4584: mov             SP, fp
    //     0x6c4588: ldp             fp, lr, [SP], #0x10
    // 0x6c458c: ret
    //     0x6c458c: ret             
    // 0x6c4590: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c4590: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c4594: b               #0x6c450c
  }
  _ RenderPhysicalModel(/* No info */) {
    // ** addr: 0x6eb25c, size: 0x88
    // 0x6eb25c: EnterFrame
    //     0x6eb25c: stp             fp, lr, [SP, #-0x10]!
    //     0x6eb260: mov             fp, SP
    // 0x6eb264: r0 = Instance_BoxShape
    //     0x6eb264: add             x0, PP, #0xe, lsl #12  ; [pp+0xee68] Obj!BoxShape@b64e91
    //     0x6eb268: ldr             x0, [x0, #0xe68]
    // 0x6eb26c: CheckStackOverflow
    //     0x6eb26c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6eb270: cmp             SP, x16
    //     0x6eb274: b.ls            #0x6eb2dc
    // 0x6eb278: ldr             x1, [fp, #0x38]
    // 0x6eb27c: StoreField: r1->field_87 = r0
    //     0x6eb27c: stur            w0, [x1, #0x87]
    // 0x6eb280: ldr             x0, [fp, #0x30]
    // 0x6eb284: StoreField: r1->field_8b = r0
    //     0x6eb284: stur            w0, [x1, #0x8b]
    //     0x6eb288: ldurb           w16, [x1, #-1]
    //     0x6eb28c: ldurb           w17, [x0, #-1]
    //     0x6eb290: and             x16, x17, x16, lsr #2
    //     0x6eb294: tst             x16, HEAP, lsr #32
    //     0x6eb298: b.eq            #0x6eb2a0
    //     0x6eb29c: bl              #0xd6826c
    // 0x6eb2a0: ldr             x16, [fp, #0x28]
    // 0x6eb2a4: stp             x16, x1, [SP, #-0x10]!
    // 0x6eb2a8: ldr             x16, [fp, #0x20]
    // 0x6eb2ac: SaveReg r16
    //     0x6eb2ac: str             x16, [SP, #-8]!
    // 0x6eb2b0: ldr             d0, [fp, #0x18]
    // 0x6eb2b4: SaveReg d0
    //     0x6eb2b4: str             d0, [SP, #-8]!
    // 0x6eb2b8: ldr             x16, [fp, #0x10]
    // 0x6eb2bc: SaveReg r16
    //     0x6eb2bc: str             x16, [SP, #-8]!
    // 0x6eb2c0: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0x6eb2c0: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0x6eb2c4: r0 = _RenderPhysicalModelBase()
    //     0x6eb2c4: bl              #0x6eb2e4  ; [package:flutter/src/rendering/proxy_box.dart] _RenderPhysicalModelBase::_RenderPhysicalModelBase
    // 0x6eb2c8: add             SP, SP, #0x28
    // 0x6eb2cc: r0 = Null
    //     0x6eb2cc: mov             x0, NULL
    // 0x6eb2d0: LeaveFrame
    //     0x6eb2d0: mov             SP, fp
    //     0x6eb2d4: ldp             fp, lr, [SP], #0x10
    // 0x6eb2d8: ret
    //     0x6eb2d8: ret             
    // 0x6eb2dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6eb2dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6eb2e0: b               #0x6eb278
  }
  get _ _defaultClip(/* No info */) {
    // ** addr: 0xb0ddd8, size: 0x144
    // 0xb0ddd8: EnterFrame
    //     0xb0ddd8: stp             fp, lr, [SP, #-0x10]!
    //     0xb0dddc: mov             fp, SP
    // 0xb0dde0: AllocStack(0x20)
    //     0xb0dde0: sub             SP, SP, #0x20
    // 0xb0dde4: CheckStackOverflow
    //     0xb0dde4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0dde8: cmp             SP, x16
    //     0xb0ddec: b.ls            #0xb0def8
    // 0xb0ddf0: ldr             x0, [fp, #0x10]
    // 0xb0ddf4: LoadField: r1 = r0->field_57
    //     0xb0ddf4: ldur            w1, [x0, #0x57]
    // 0xb0ddf8: DecompressPointer r1
    //     0xb0ddf8: add             x1, x1, HEAP, lsl #32
    // 0xb0ddfc: cmp             w1, NULL
    // 0xb0de00: b.eq            #0xb0df00
    // 0xb0de04: r16 = Instance_Offset
    //     0xb0de04: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xb0de08: stp             x1, x16, [SP, #-0x10]!
    // 0xb0de0c: r0 = &()
    //     0xb0de0c: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0xb0de10: add             SP, SP, #0x10
    // 0xb0de14: mov             x1, x0
    // 0xb0de18: ldr             x0, [fp, #0x10]
    // 0xb0de1c: stur            x1, [fp, #-0x10]
    // 0xb0de20: LoadField: r2 = r0->field_87
    //     0xb0de20: ldur            w2, [x0, #0x87]
    // 0xb0de24: DecompressPointer r2
    //     0xb0de24: add             x2, x2, HEAP, lsl #32
    // 0xb0de28: LoadField: r3 = r2->field_7
    //     0xb0de28: ldur            x3, [x2, #7]
    // 0xb0de2c: cmp             x3, #0
    // 0xb0de30: b.gt            #0xb0de6c
    // 0xb0de34: LoadField: r2 = r0->field_8b
    //     0xb0de34: ldur            w2, [x0, #0x8b]
    // 0xb0de38: DecompressPointer r2
    //     0xb0de38: add             x2, x2, HEAP, lsl #32
    // 0xb0de3c: cmp             w2, NULL
    // 0xb0de40: b.ne            #0xb0de50
    // 0xb0de44: r0 = Instance_BorderRadius
    //     0xb0de44: add             x0, PP, #0x15, lsl #12  ; [pp+0x152c0] Obj!BorderRadius@b37471
    //     0xb0de48: ldr             x0, [x0, #0x2c0]
    // 0xb0de4c: b               #0xb0de54
    // 0xb0de50: mov             x0, x2
    // 0xb0de54: stp             x1, x0, [SP, #-0x10]!
    // 0xb0de58: r0 = toRRect()
    //     0xb0de58: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xb0de5c: add             SP, SP, #0x10
    // 0xb0de60: LeaveFrame
    //     0xb0de60: mov             SP, fp
    //     0xb0de64: ldp             fp, lr, [SP], #0x10
    // 0xb0de68: ret
    //     0xb0de68: ret             
    // 0xb0de6c: d0 = 2.000000
    //     0xb0de6c: fmov            d0, #2.00000000
    // 0xb0de70: LoadField: d1 = r1->field_17
    //     0xb0de70: ldur            d1, [x1, #0x17]
    // 0xb0de74: LoadField: d2 = r1->field_7
    //     0xb0de74: ldur            d2, [x1, #7]
    // 0xb0de78: fsub            d3, d1, d2
    // 0xb0de7c: fdiv            d1, d3, d0
    // 0xb0de80: LoadField: d2 = r1->field_1f
    //     0xb0de80: ldur            d2, [x1, #0x1f]
    // 0xb0de84: LoadField: d3 = r1->field_f
    //     0xb0de84: ldur            d3, [x1, #0xf]
    // 0xb0de88: fsub            d4, d2, d3
    // 0xb0de8c: fdiv            d2, d4, d0
    // 0xb0de90: stur            d2, [fp, #-0x20]
    // 0xb0de94: r0 = inline_Allocate_Double()
    //     0xb0de94: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xb0de98: add             x0, x0, #0x10
    //     0xb0de9c: cmp             x2, x0
    //     0xb0dea0: b.ls            #0xb0df04
    //     0xb0dea4: str             x0, [THR, #0x60]  ; THR::top
    //     0xb0dea8: sub             x0, x0, #0xf
    //     0xb0deac: mov             x2, #0xd108
    //     0xb0deb0: movk            x2, #3, lsl #16
    //     0xb0deb4: stur            x2, [x0, #-1]
    // 0xb0deb8: StoreField: r0->field_7 = d1
    //     0xb0deb8: stur            d1, [x0, #7]
    // 0xb0debc: stur            x0, [fp, #-8]
    // 0xb0dec0: r0 = RRect()
    //     0xb0dec0: bl              #0x640078  ; AllocateRRectStub -> RRect (size=0x68)
    // 0xb0dec4: stur            x0, [fp, #-0x18]
    // 0xb0dec8: ldur            x16, [fp, #-0x10]
    // 0xb0decc: stp             x16, x0, [SP, #-0x10]!
    // 0xb0ded0: ldur            x16, [fp, #-8]
    // 0xb0ded4: SaveReg r16
    //     0xb0ded4: str             x16, [SP, #-8]!
    // 0xb0ded8: ldur            d0, [fp, #-0x20]
    // 0xb0dedc: SaveReg d0
    //     0xb0dedc: str             d0, [SP, #-8]!
    // 0xb0dee0: r0 = RRect.fromRectXY()
    //     0xb0dee0: bl              #0xb0df1c  ; [dart:ui] RRect::RRect.fromRectXY
    // 0xb0dee4: add             SP, SP, #0x20
    // 0xb0dee8: ldur            x0, [fp, #-0x18]
    // 0xb0deec: LeaveFrame
    //     0xb0deec: mov             SP, fp
    //     0xb0def0: ldp             fp, lr, [SP], #0x10
    // 0xb0def4: ret
    //     0xb0def4: ret             
    // 0xb0def8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0def8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0defc: b               #0xb0ddf0
    // 0xb0df00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb0df00: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb0df04: stp             q1, q2, [SP, #-0x20]!
    // 0xb0df08: SaveReg r1
    //     0xb0df08: str             x1, [SP, #-8]!
    // 0xb0df0c: r0 = AllocateDouble()
    //     0xb0df0c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0df10: RestoreReg r1
    //     0xb0df10: ldr             x1, [SP], #8
    // 0xb0df14: ldp             q1, q2, [SP], #0x20
    // 0xb0df18: b               #0xb0deb8
  }
}

// class id: 2500, size: 0x78, field offset: 0x78
class RenderClipPath extends _RenderCustomClip<Path> {

  _ paint(/* No info */) {
    // ** addr: 0x663794, size: 0x1e8
    // 0x663794: EnterFrame
    //     0x663794: stp             fp, lr, [SP, #-0x10]!
    //     0x663798: mov             fp, SP
    // 0x66379c: AllocStack(0x38)
    //     0x66379c: sub             SP, SP, #0x38
    // 0x6637a0: CheckStackOverflow
    //     0x6637a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6637a4: cmp             SP, x16
    //     0x6637a8: b.ls            #0x663964
    // 0x6637ac: ldr             x0, [fp, #0x20]
    // 0x6637b0: LoadField: r1 = r0->field_5f
    //     0x6637b0: ldur            w1, [x0, #0x5f]
    // 0x6637b4: DecompressPointer r1
    //     0x6637b4: add             x1, x1, HEAP, lsl #32
    // 0x6637b8: cmp             w1, NULL
    // 0x6637bc: b.eq            #0x663940
    // 0x6637c0: LoadField: r2 = r0->field_6f
    //     0x6637c0: ldur            w2, [x0, #0x6f]
    // 0x6637c4: DecompressPointer r2
    //     0x6637c4: add             x2, x2, HEAP, lsl #32
    // 0x6637c8: r16 = Instance_Clip
    //     0x6637c8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x6637cc: ldr             x16, [x16, #0xb38]
    // 0x6637d0: cmp             w2, w16
    // 0x6637d4: b.eq            #0x66390c
    // 0x6637d8: SaveReg r0
    //     0x6637d8: str             x0, [SP, #-8]!
    // 0x6637dc: r0 = _updateClip()
    //     0x6637dc: bl              #0x63f548  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_updateClip
    // 0x6637e0: add             SP, SP, #8
    // 0x6637e4: ldr             x0, [fp, #0x20]
    // 0x6637e8: LoadField: r1 = r0->field_37
    //     0x6637e8: ldur            w1, [x0, #0x37]
    // 0x6637ec: DecompressPointer r1
    //     0x6637ec: add             x1, x1, HEAP, lsl #32
    // 0x6637f0: r16 = Sentinel
    //     0x6637f0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6637f4: cmp             w1, w16
    // 0x6637f8: b.eq            #0x66396c
    // 0x6637fc: stur            x1, [fp, #-8]
    // 0x663800: LoadField: r2 = r0->field_57
    //     0x663800: ldur            w2, [x0, #0x57]
    // 0x663804: DecompressPointer r2
    //     0x663804: add             x2, x2, HEAP, lsl #32
    // 0x663808: cmp             w2, NULL
    // 0x66380c: b.eq            #0x663974
    // 0x663810: r16 = Instance_Offset
    //     0x663810: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x663814: stp             x2, x16, [SP, #-0x10]!
    // 0x663818: r0 = &()
    //     0x663818: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x66381c: add             SP, SP, #0x10
    // 0x663820: mov             x1, x0
    // 0x663824: ldr             x0, [fp, #0x20]
    // 0x663828: stur            x1, [fp, #-0x18]
    // 0x66382c: LoadField: r2 = r0->field_6b
    //     0x66382c: ldur            w2, [x0, #0x6b]
    // 0x663830: DecompressPointer r2
    //     0x663830: add             x2, x2, HEAP, lsl #32
    // 0x663834: stur            x2, [fp, #-0x10]
    // 0x663838: cmp             w2, NULL
    // 0x66383c: b.eq            #0x663978
    // 0x663840: r1 = 1
    //     0x663840: mov             x1, #1
    // 0x663844: r0 = AllocateContext()
    //     0x663844: bl              #0xd68aa4  ; AllocateContextStub
    // 0x663848: mov             x3, x0
    // 0x66384c: ldr             x0, [fp, #0x20]
    // 0x663850: stur            x3, [fp, #-0x38]
    // 0x663854: StoreField: r3->field_f = r0
    //     0x663854: stur            w0, [x3, #0xf]
    // 0x663858: LoadField: r4 = r0->field_6f
    //     0x663858: ldur            w4, [x0, #0x6f]
    // 0x66385c: DecompressPointer r4
    //     0x66385c: add             x4, x4, HEAP, lsl #32
    // 0x663860: stur            x4, [fp, #-0x30]
    // 0x663864: LoadField: r5 = r0->field_2f
    //     0x663864: ldur            w5, [x0, #0x2f]
    // 0x663868: DecompressPointer r5
    //     0x663868: add             x5, x5, HEAP, lsl #32
    // 0x66386c: stur            x5, [fp, #-0x28]
    // 0x663870: LoadField: r6 = r5->field_b
    //     0x663870: ldur            w6, [x5, #0xb]
    // 0x663874: DecompressPointer r6
    //     0x663874: add             x6, x6, HEAP, lsl #32
    // 0x663878: mov             x0, x6
    // 0x66387c: stur            x6, [fp, #-0x20]
    // 0x663880: r2 = Null
    //     0x663880: mov             x2, NULL
    // 0x663884: r1 = Null
    //     0x663884: mov             x1, NULL
    // 0x663888: r4 = LoadClassIdInstr(r0)
    //     0x663888: ldur            x4, [x0, #-1]
    //     0x66388c: ubfx            x4, x4, #0xc, #0x14
    // 0x663890: cmp             x4, #0x953
    // 0x663894: b.eq            #0x6638ac
    // 0x663898: r8 = ClipPathLayer?
    //     0x663898: add             x8, PP, #0x21, lsl #12  ; [pp+0x21aa8] Type: ClipPathLayer?
    //     0x66389c: ldr             x8, [x8, #0xaa8]
    // 0x6638a0: r3 = Null
    //     0x6638a0: add             x3, PP, #0x21, lsl #12  ; [pp+0x21ab0] Null
    //     0x6638a4: ldr             x3, [x3, #0xab0]
    // 0x6638a8: r0 = DefaultNullableTypeTest()
    //     0x6638a8: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x6638ac: ldur            x2, [fp, #-0x38]
    // 0x6638b0: r1 = Function 'paint':.
    //     0x6638b0: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cef0] AnonymousClosure: (0x661630), in [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::paint (0x669ddc)
    //     0x6638b4: ldr             x1, [x1, #0xef0]
    // 0x6638b8: r0 = AllocateClosure()
    //     0x6638b8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6638bc: ldr             x16, [fp, #0x18]
    // 0x6638c0: ldur            lr, [fp, #-8]
    // 0x6638c4: stp             lr, x16, [SP, #-0x10]!
    // 0x6638c8: ldr             x16, [fp, #0x10]
    // 0x6638cc: ldur            lr, [fp, #-0x18]
    // 0x6638d0: stp             lr, x16, [SP, #-0x10]!
    // 0x6638d4: ldur            x16, [fp, #-0x10]
    // 0x6638d8: stp             x0, x16, [SP, #-0x10]!
    // 0x6638dc: ldur            x16, [fp, #-0x20]
    // 0x6638e0: ldur            lr, [fp, #-0x30]
    // 0x6638e4: stp             lr, x16, [SP, #-0x10]!
    // 0x6638e8: r4 = const [0, 0x8, 0x8, 0x7, clipBehavior, 0x7, null]
    //     0x6638e8: add             x4, PP, #0x21, lsl #12  ; [pp+0x21ac0] List(7) [0, 0x8, 0x8, 0x7, "clipBehavior", 0x7, Null]
    //     0x6638ec: ldr             x4, [x4, #0xac0]
    // 0x6638f0: r0 = pushClipPath()
    //     0x6638f0: bl              #0x6626a0  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipPath
    // 0x6638f4: add             SP, SP, #0x40
    // 0x6638f8: ldur            x16, [fp, #-0x28]
    // 0x6638fc: stp             x0, x16, [SP, #-0x10]!
    // 0x663900: r0 = layer=()
    //     0x663900: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x663904: add             SP, SP, #0x10
    // 0x663908: b               #0x663954
    // 0x66390c: ldr             x16, [fp, #0x18]
    // 0x663910: stp             x1, x16, [SP, #-0x10]!
    // 0x663914: ldr             x16, [fp, #0x10]
    // 0x663918: SaveReg r16
    //     0x663918: str             x16, [SP, #-8]!
    // 0x66391c: r0 = paintChild()
    //     0x66391c: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x663920: add             SP, SP, #0x18
    // 0x663924: ldr             x0, [fp, #0x20]
    // 0x663928: LoadField: r1 = r0->field_2f
    //     0x663928: ldur            w1, [x0, #0x2f]
    // 0x66392c: DecompressPointer r1
    //     0x66392c: add             x1, x1, HEAP, lsl #32
    // 0x663930: stp             NULL, x1, [SP, #-0x10]!
    // 0x663934: r0 = layer=()
    //     0x663934: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x663938: add             SP, SP, #0x10
    // 0x66393c: b               #0x663954
    // 0x663940: LoadField: r1 = r0->field_2f
    //     0x663940: ldur            w1, [x0, #0x2f]
    // 0x663944: DecompressPointer r1
    //     0x663944: add             x1, x1, HEAP, lsl #32
    // 0x663948: stp             NULL, x1, [SP, #-0x10]!
    // 0x66394c: r0 = layer=()
    //     0x66394c: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x663950: add             SP, SP, #0x10
    // 0x663954: r0 = Null
    //     0x663954: mov             x0, NULL
    // 0x663958: LeaveFrame
    //     0x663958: mov             SP, fp
    //     0x66395c: ldp             fp, lr, [SP], #0x10
    // 0x663960: ret
    //     0x663960: ret             
    // 0x663964: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x663964: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x663968: b               #0x6637ac
    // 0x66396c: r9 = _needsCompositing
    //     0x66396c: ldr             x9, [PP, #0x4b28]  ; [pp+0x4b28] Field <RenderObject._needsCompositing@904266271>: late (offset: 0x38)
    // 0x663970: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x663970: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x663974: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x663974: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x663978: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x663978: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2501, size: 0x80, field offset: 0x78
class RenderClipOval extends _RenderCustomClip<Rect> {

  late Path _cachedPath; // offset: 0x7c

  _ hitTest(/* No info */) {
    // ** addr: 0x63f624, size: 0xf4
    // 0x63f624: EnterFrame
    //     0x63f624: stp             fp, lr, [SP, #-0x10]!
    //     0x63f628: mov             fp, SP
    // 0x63f62c: CheckStackOverflow
    //     0x63f62c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63f630: cmp             SP, x16
    //     0x63f634: b.ls            #0x63f708
    // 0x63f638: ldr             x16, [fp, #0x20]
    // 0x63f63c: SaveReg r16
    //     0x63f63c: str             x16, [SP, #-8]!
    // 0x63f640: r0 = _updateClip()
    //     0x63f640: bl              #0x63f548  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_updateClip
    // 0x63f644: add             SP, SP, #8
    // 0x63f648: ldr             x0, [fp, #0x20]
    // 0x63f64c: LoadField: r1 = r0->field_6b
    //     0x63f64c: ldur            w1, [x0, #0x6b]
    // 0x63f650: DecompressPointer r1
    //     0x63f650: add             x1, x1, HEAP, lsl #32
    // 0x63f654: cmp             w1, NULL
    // 0x63f658: b.eq            #0x63f710
    // 0x63f65c: SaveReg r1
    //     0x63f65c: str             x1, [SP, #-8]!
    // 0x63f660: r0 = center()
    //     0x63f660: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x63f664: add             SP, SP, #8
    // 0x63f668: mov             x1, x0
    // 0x63f66c: ldr             x0, [fp, #0x10]
    // 0x63f670: LoadField: d0 = r0->field_7
    //     0x63f670: ldur            d0, [x0, #7]
    // 0x63f674: LoadField: d1 = r1->field_7
    //     0x63f674: ldur            d1, [x1, #7]
    // 0x63f678: fsub            d2, d0, d1
    // 0x63f67c: ldr             x2, [fp, #0x20]
    // 0x63f680: LoadField: r3 = r2->field_6b
    //     0x63f680: ldur            w3, [x2, #0x6b]
    // 0x63f684: DecompressPointer r3
    //     0x63f684: add             x3, x3, HEAP, lsl #32
    // 0x63f688: cmp             w3, NULL
    // 0x63f68c: b.eq            #0x63f714
    // 0x63f690: LoadField: d0 = r3->field_17
    //     0x63f690: ldur            d0, [x3, #0x17]
    // 0x63f694: LoadField: d1 = r3->field_7
    //     0x63f694: ldur            d1, [x3, #7]
    // 0x63f698: fsub            d3, d0, d1
    // 0x63f69c: fdiv            d0, d2, d3
    // 0x63f6a0: LoadField: d1 = r0->field_f
    //     0x63f6a0: ldur            d1, [x0, #0xf]
    // 0x63f6a4: LoadField: d2 = r1->field_f
    //     0x63f6a4: ldur            d2, [x1, #0xf]
    // 0x63f6a8: fsub            d3, d1, d2
    // 0x63f6ac: LoadField: d1 = r3->field_1f
    //     0x63f6ac: ldur            d1, [x3, #0x1f]
    // 0x63f6b0: LoadField: d2 = r3->field_f
    //     0x63f6b0: ldur            d2, [x3, #0xf]
    // 0x63f6b4: fsub            d4, d1, d2
    // 0x63f6b8: fdiv            d1, d3, d4
    // 0x63f6bc: fmul            d2, d0, d0
    // 0x63f6c0: fmul            d0, d1, d1
    // 0x63f6c4: fadd            d1, d2, d0
    // 0x63f6c8: d0 = 0.250000
    //     0x63f6c8: fmov            d0, #0.25000000
    // 0x63f6cc: fcmp            d1, d0
    // 0x63f6d0: b.vs            #0x63f6e8
    // 0x63f6d4: b.le            #0x63f6e8
    // 0x63f6d8: r0 = false
    //     0x63f6d8: add             x0, NULL, #0x30  ; false
    // 0x63f6dc: LeaveFrame
    //     0x63f6dc: mov             SP, fp
    //     0x63f6e0: ldp             fp, lr, [SP], #0x10
    // 0x63f6e4: ret
    //     0x63f6e4: ret             
    // 0x63f6e8: ldr             x16, [fp, #0x18]
    // 0x63f6ec: stp             x16, x2, [SP, #-0x10]!
    // 0x63f6f0: SaveReg r0
    //     0x63f6f0: str             x0, [SP, #-8]!
    // 0x63f6f4: r0 = hitTest()
    //     0x63f6f4: bl              #0x640b9c  ; [package:flutter/src/rendering/box.dart] RenderBox::hitTest
    // 0x63f6f8: add             SP, SP, #0x18
    // 0x63f6fc: LeaveFrame
    //     0x63f6fc: mov             SP, fp
    //     0x63f700: ldp             fp, lr, [SP], #0x10
    // 0x63f704: ret
    //     0x63f704: ret             
    // 0x63f708: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63f708: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63f70c: b               #0x63f638
    // 0x63f710: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63f710: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x63f714: r0 = NullCastErrorSharedWithFPURegs()
    //     0x63f714: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0x6624d8, size: 0x1c8
    // 0x6624d8: EnterFrame
    //     0x6624d8: stp             fp, lr, [SP, #-0x10]!
    //     0x6624dc: mov             fp, SP
    // 0x6624e0: AllocStack(0x38)
    //     0x6624e0: sub             SP, SP, #0x38
    // 0x6624e4: CheckStackOverflow
    //     0x6624e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6624e8: cmp             SP, x16
    //     0x6624ec: b.ls            #0x66268c
    // 0x6624f0: ldr             x0, [fp, #0x20]
    // 0x6624f4: LoadField: r1 = r0->field_5f
    //     0x6624f4: ldur            w1, [x0, #0x5f]
    // 0x6624f8: DecompressPointer r1
    //     0x6624f8: add             x1, x1, HEAP, lsl #32
    // 0x6624fc: cmp             w1, NULL
    // 0x662500: b.eq            #0x662668
    // 0x662504: LoadField: r2 = r0->field_6f
    //     0x662504: ldur            w2, [x0, #0x6f]
    // 0x662508: DecompressPointer r2
    //     0x662508: add             x2, x2, HEAP, lsl #32
    // 0x66250c: r16 = Instance_Clip
    //     0x66250c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x662510: ldr             x16, [x16, #0xb38]
    // 0x662514: cmp             w2, w16
    // 0x662518: b.eq            #0x662634
    // 0x66251c: SaveReg r0
    //     0x66251c: str             x0, [SP, #-8]!
    // 0x662520: r0 = _updateClip()
    //     0x662520: bl              #0x63f548  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_updateClip
    // 0x662524: add             SP, SP, #8
    // 0x662528: ldr             x0, [fp, #0x20]
    // 0x66252c: LoadField: r1 = r0->field_37
    //     0x66252c: ldur            w1, [x0, #0x37]
    // 0x662530: DecompressPointer r1
    //     0x662530: add             x1, x1, HEAP, lsl #32
    // 0x662534: r16 = Sentinel
    //     0x662534: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x662538: cmp             w1, w16
    // 0x66253c: b.eq            #0x662694
    // 0x662540: stur            x1, [fp, #-0x10]
    // 0x662544: LoadField: r2 = r0->field_6b
    //     0x662544: ldur            w2, [x0, #0x6b]
    // 0x662548: DecompressPointer r2
    //     0x662548: add             x2, x2, HEAP, lsl #32
    // 0x66254c: stur            x2, [fp, #-8]
    // 0x662550: cmp             w2, NULL
    // 0x662554: b.eq            #0x66269c
    // 0x662558: stp             x2, x0, [SP, #-0x10]!
    // 0x66255c: r0 = _getClipPath()
    //     0x66255c: bl              #0x66322c  ; [package:flutter/src/rendering/proxy_box.dart] RenderClipOval::_getClipPath
    // 0x662560: add             SP, SP, #0x10
    // 0x662564: stur            x0, [fp, #-0x18]
    // 0x662568: r1 = 1
    //     0x662568: mov             x1, #1
    // 0x66256c: r0 = AllocateContext()
    //     0x66256c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x662570: mov             x3, x0
    // 0x662574: ldr             x0, [fp, #0x20]
    // 0x662578: stur            x3, [fp, #-0x38]
    // 0x66257c: StoreField: r3->field_f = r0
    //     0x66257c: stur            w0, [x3, #0xf]
    // 0x662580: LoadField: r4 = r0->field_6f
    //     0x662580: ldur            w4, [x0, #0x6f]
    // 0x662584: DecompressPointer r4
    //     0x662584: add             x4, x4, HEAP, lsl #32
    // 0x662588: stur            x4, [fp, #-0x30]
    // 0x66258c: LoadField: r5 = r0->field_2f
    //     0x66258c: ldur            w5, [x0, #0x2f]
    // 0x662590: DecompressPointer r5
    //     0x662590: add             x5, x5, HEAP, lsl #32
    // 0x662594: stur            x5, [fp, #-0x28]
    // 0x662598: LoadField: r6 = r5->field_b
    //     0x662598: ldur            w6, [x5, #0xb]
    // 0x66259c: DecompressPointer r6
    //     0x66259c: add             x6, x6, HEAP, lsl #32
    // 0x6625a0: mov             x0, x6
    // 0x6625a4: stur            x6, [fp, #-0x20]
    // 0x6625a8: r2 = Null
    //     0x6625a8: mov             x2, NULL
    // 0x6625ac: r1 = Null
    //     0x6625ac: mov             x1, NULL
    // 0x6625b0: r4 = LoadClassIdInstr(r0)
    //     0x6625b0: ldur            x4, [x0, #-1]
    //     0x6625b4: ubfx            x4, x4, #0xc, #0x14
    // 0x6625b8: cmp             x4, #0x953
    // 0x6625bc: b.eq            #0x6625d4
    // 0x6625c0: r8 = ClipPathLayer?
    //     0x6625c0: add             x8, PP, #0x21, lsl #12  ; [pp+0x21aa8] Type: ClipPathLayer?
    //     0x6625c4: ldr             x8, [x8, #0xaa8]
    // 0x6625c8: r3 = Null
    //     0x6625c8: add             x3, PP, #0x37, lsl #12  ; [pp+0x37038] Null
    //     0x6625cc: ldr             x3, [x3, #0x38]
    // 0x6625d0: r0 = DefaultNullableTypeTest()
    //     0x6625d0: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x6625d4: ldur            x2, [fp, #-0x38]
    // 0x6625d8: r1 = Function 'paint':.
    //     0x6625d8: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cef0] AnonymousClosure: (0x661630), in [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::paint (0x669ddc)
    //     0x6625dc: ldr             x1, [x1, #0xef0]
    // 0x6625e0: r0 = AllocateClosure()
    //     0x6625e0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6625e4: ldr             x16, [fp, #0x18]
    // 0x6625e8: ldur            lr, [fp, #-0x10]
    // 0x6625ec: stp             lr, x16, [SP, #-0x10]!
    // 0x6625f0: ldr             x16, [fp, #0x10]
    // 0x6625f4: ldur            lr, [fp, #-8]
    // 0x6625f8: stp             lr, x16, [SP, #-0x10]!
    // 0x6625fc: ldur            x16, [fp, #-0x18]
    // 0x662600: stp             x0, x16, [SP, #-0x10]!
    // 0x662604: ldur            x16, [fp, #-0x20]
    // 0x662608: ldur            lr, [fp, #-0x30]
    // 0x66260c: stp             lr, x16, [SP, #-0x10]!
    // 0x662610: r4 = const [0, 0x8, 0x8, 0x7, clipBehavior, 0x7, null]
    //     0x662610: add             x4, PP, #0x21, lsl #12  ; [pp+0x21ac0] List(7) [0, 0x8, 0x8, 0x7, "clipBehavior", 0x7, Null]
    //     0x662614: ldr             x4, [x4, #0xac0]
    // 0x662618: r0 = pushClipPath()
    //     0x662618: bl              #0x6626a0  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipPath
    // 0x66261c: add             SP, SP, #0x40
    // 0x662620: ldur            x16, [fp, #-0x28]
    // 0x662624: stp             x0, x16, [SP, #-0x10]!
    // 0x662628: r0 = layer=()
    //     0x662628: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x66262c: add             SP, SP, #0x10
    // 0x662630: b               #0x66267c
    // 0x662634: ldr             x16, [fp, #0x18]
    // 0x662638: stp             x1, x16, [SP, #-0x10]!
    // 0x66263c: ldr             x16, [fp, #0x10]
    // 0x662640: SaveReg r16
    //     0x662640: str             x16, [SP, #-8]!
    // 0x662644: r0 = paintChild()
    //     0x662644: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x662648: add             SP, SP, #0x18
    // 0x66264c: ldr             x0, [fp, #0x20]
    // 0x662650: LoadField: r1 = r0->field_2f
    //     0x662650: ldur            w1, [x0, #0x2f]
    // 0x662654: DecompressPointer r1
    //     0x662654: add             x1, x1, HEAP, lsl #32
    // 0x662658: stp             NULL, x1, [SP, #-0x10]!
    // 0x66265c: r0 = layer=()
    //     0x66265c: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x662660: add             SP, SP, #0x10
    // 0x662664: b               #0x66267c
    // 0x662668: LoadField: r1 = r0->field_2f
    //     0x662668: ldur            w1, [x0, #0x2f]
    // 0x66266c: DecompressPointer r1
    //     0x66266c: add             x1, x1, HEAP, lsl #32
    // 0x662670: stp             NULL, x1, [SP, #-0x10]!
    // 0x662674: r0 = layer=()
    //     0x662674: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x662678: add             SP, SP, #0x10
    // 0x66267c: r0 = Null
    //     0x66267c: mov             x0, NULL
    // 0x662680: LeaveFrame
    //     0x662680: mov             SP, fp
    //     0x662684: ldp             fp, lr, [SP], #0x10
    // 0x662688: ret
    //     0x662688: ret             
    // 0x66268c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66268c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x662690: b               #0x6624f0
    // 0x662694: r9 = _needsCompositing
    //     0x662694: ldr             x9, [PP, #0x4b28]  ; [pp+0x4b28] Field <RenderObject._needsCompositing@904266271>: late (offset: 0x38)
    // 0x662698: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x662698: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x66269c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66269c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getClipPath(/* No info */) {
    // ** addr: 0x66322c, size: 0x180
    // 0x66322c: EnterFrame
    //     0x66322c: stp             fp, lr, [SP, #-0x10]!
    //     0x663230: mov             fp, SP
    // 0x663234: AllocStack(0x8)
    //     0x663234: sub             SP, SP, #8
    // 0x663238: CheckStackOverflow
    //     0x663238: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66323c: cmp             SP, x16
    //     0x663240: b.ls            #0x663394
    // 0x663244: ldr             x0, [fp, #0x18]
    // 0x663248: LoadField: r1 = r0->field_77
    //     0x663248: ldur            w1, [x0, #0x77]
    // 0x66324c: DecompressPointer r1
    //     0x66324c: add             x1, x1, HEAP, lsl #32
    // 0x663250: stur            x1, [fp, #-8]
    // 0x663254: cmp             w1, NULL
    // 0x663258: b.ne            #0x663268
    // 0x66325c: mov             x2, x0
    // 0x663260: ldr             x1, [fp, #0x10]
    // 0x663264: b               #0x6632f8
    // 0x663268: ldr             x2, [fp, #0x10]
    // 0x66326c: cmp             w2, w1
    // 0x663270: b.eq            #0x6632ec
    // 0x663274: r16 = Rect
    //     0x663274: ldr             x16, [PP, #0x5e50]  ; [pp+0x5e50] Type: Rect
    // 0x663278: r30 = Rect
    //     0x663278: ldr             lr, [PP, #0x5e50]  ; [pp+0x5e50] Type: Rect
    // 0x66327c: stp             lr, x16, [SP, #-0x10]!
    // 0x663280: r0 = ==()
    //     0x663280: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x663284: add             SP, SP, #0x10
    // 0x663288: tbz             w0, #4, #0x663298
    // 0x66328c: ldr             x2, [fp, #0x18]
    // 0x663290: ldr             x1, [fp, #0x10]
    // 0x663294: b               #0x6632f8
    // 0x663298: ldr             x1, [fp, #0x10]
    // 0x66329c: ldur            x0, [fp, #-8]
    // 0x6632a0: LoadField: d0 = r0->field_7
    //     0x6632a0: ldur            d0, [x0, #7]
    // 0x6632a4: LoadField: d1 = r1->field_7
    //     0x6632a4: ldur            d1, [x1, #7]
    // 0x6632a8: fcmp            d0, d1
    // 0x6632ac: b.vs            #0x6632f4
    // 0x6632b0: b.ne            #0x6632f4
    // 0x6632b4: LoadField: d0 = r0->field_f
    //     0x6632b4: ldur            d0, [x0, #0xf]
    // 0x6632b8: LoadField: d1 = r1->field_f
    //     0x6632b8: ldur            d1, [x1, #0xf]
    // 0x6632bc: fcmp            d0, d1
    // 0x6632c0: b.vs            #0x6632f4
    // 0x6632c4: b.ne            #0x6632f4
    // 0x6632c8: LoadField: d0 = r0->field_17
    //     0x6632c8: ldur            d0, [x0, #0x17]
    // 0x6632cc: LoadField: d1 = r1->field_17
    //     0x6632cc: ldur            d1, [x1, #0x17]
    // 0x6632d0: fcmp            d0, d1
    // 0x6632d4: b.vs            #0x6632f4
    // 0x6632d8: b.ne            #0x6632f4
    // 0x6632dc: LoadField: d0 = r0->field_1f
    //     0x6632dc: ldur            d0, [x0, #0x1f]
    // 0x6632e0: LoadField: d1 = r1->field_1f
    //     0x6632e0: ldur            d1, [x1, #0x1f]
    // 0x6632e4: fcmp            d0, d1
    // 0x6632e8: b.ne            #0x6632f4
    // 0x6632ec: ldr             x1, [fp, #0x18]
    // 0x6632f0: b               #0x663374
    // 0x6632f4: ldr             x2, [fp, #0x18]
    // 0x6632f8: mov             x0, x1
    // 0x6632fc: StoreField: r2->field_77 = r0
    //     0x6632fc: stur            w0, [x2, #0x77]
    //     0x663300: ldurb           w16, [x2, #-1]
    //     0x663304: ldurb           w17, [x0, #-1]
    //     0x663308: and             x16, x17, x16, lsr #2
    //     0x66330c: tst             x16, HEAP, lsr #32
    //     0x663310: b.eq            #0x663318
    //     0x663314: bl              #0xd6828c
    // 0x663318: r0 = Path()
    //     0x663318: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0x66331c: stur            x0, [fp, #-8]
    // 0x663320: SaveReg r0
    //     0x663320: str             x0, [SP, #-8]!
    // 0x663324: r0 = _constructor()
    //     0x663324: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0x663328: add             SP, SP, #8
    // 0x66332c: ldr             x0, [fp, #0x18]
    // 0x663330: LoadField: r1 = r0->field_77
    //     0x663330: ldur            w1, [x0, #0x77]
    // 0x663334: DecompressPointer r1
    //     0x663334: add             x1, x1, HEAP, lsl #32
    // 0x663338: cmp             w1, NULL
    // 0x66333c: b.eq            #0x66339c
    // 0x663340: ldur            x16, [fp, #-8]
    // 0x663344: stp             x1, x16, [SP, #-0x10]!
    // 0x663348: r0 = addOval()
    //     0x663348: bl              #0x6633ac  ; [dart:ui] Path::addOval
    // 0x66334c: add             SP, SP, #0x10
    // 0x663350: ldur            x0, [fp, #-8]
    // 0x663354: ldr             x1, [fp, #0x18]
    // 0x663358: StoreField: r1->field_7b = r0
    //     0x663358: stur            w0, [x1, #0x7b]
    //     0x66335c: ldurb           w16, [x1, #-1]
    //     0x663360: ldurb           w17, [x0, #-1]
    //     0x663364: and             x16, x17, x16, lsr #2
    //     0x663368: tst             x16, HEAP, lsr #32
    //     0x66336c: b.eq            #0x663374
    //     0x663370: bl              #0xd6826c
    // 0x663374: LoadField: r0 = r1->field_7b
    //     0x663374: ldur            w0, [x1, #0x7b]
    // 0x663378: DecompressPointer r0
    //     0x663378: add             x0, x0, HEAP, lsl #32
    // 0x66337c: r16 = Sentinel
    //     0x66337c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x663380: cmp             w0, w16
    // 0x663384: b.eq            #0x6633a0
    // 0x663388: LeaveFrame
    //     0x663388: mov             SP, fp
    //     0x66338c: ldp             fp, lr, [SP], #0x10
    // 0x663390: ret
    //     0x663390: ret             
    // 0x663394: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x663394: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x663398: b               #0x663244
    // 0x66339c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66339c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6633a0: r9 = _cachedPath
    //     0x6633a0: add             x9, PP, #0x37, lsl #12  ; [pp+0x37048] Field <RenderClipOval._cachedPath@907160605>: late (offset: 0x7c)
    //     0x6633a4: ldr             x9, [x9, #0x48]
    // 0x6633a8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6633a8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ _defaultClip(/* No info */) {
    // ** addr: 0xb0dd88, size: 0x50
    // 0xb0dd88: EnterFrame
    //     0xb0dd88: stp             fp, lr, [SP, #-0x10]!
    //     0xb0dd8c: mov             fp, SP
    // 0xb0dd90: CheckStackOverflow
    //     0xb0dd90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0dd94: cmp             SP, x16
    //     0xb0dd98: b.ls            #0xb0ddcc
    // 0xb0dd9c: ldr             x0, [fp, #0x10]
    // 0xb0dda0: LoadField: r1 = r0->field_57
    //     0xb0dda0: ldur            w1, [x0, #0x57]
    // 0xb0dda4: DecompressPointer r1
    //     0xb0dda4: add             x1, x1, HEAP, lsl #32
    // 0xb0dda8: cmp             w1, NULL
    // 0xb0ddac: b.eq            #0xb0ddd4
    // 0xb0ddb0: r16 = Instance_Offset
    //     0xb0ddb0: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xb0ddb4: stp             x1, x16, [SP, #-0x10]!
    // 0xb0ddb8: r0 = &()
    //     0xb0ddb8: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0xb0ddbc: add             SP, SP, #0x10
    // 0xb0ddc0: LeaveFrame
    //     0xb0ddc0: mov             SP, fp
    //     0xb0ddc4: ldp             fp, lr, [SP], #0x10
    // 0xb0ddc8: ret
    //     0xb0ddc8: ret             
    // 0xb0ddcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0ddcc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0ddd0: b               #0xb0dd9c
    // 0xb0ddd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb0ddd4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2502, size: 0x80, field offset: 0x78
class RenderClipRRect extends _RenderCustomClip<RRect> {

  _ paint(/* No info */) {
    // ** addr: 0x661bb0, size: 0x1dc
    // 0x661bb0: EnterFrame
    //     0x661bb0: stp             fp, lr, [SP, #-0x10]!
    //     0x661bb4: mov             fp, SP
    // 0x661bb8: AllocStack(0x38)
    //     0x661bb8: sub             SP, SP, #0x38
    // 0x661bbc: CheckStackOverflow
    //     0x661bbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x661bc0: cmp             SP, x16
    //     0x661bc4: b.ls            #0x661d74
    // 0x661bc8: ldr             x0, [fp, #0x20]
    // 0x661bcc: LoadField: r1 = r0->field_5f
    //     0x661bcc: ldur            w1, [x0, #0x5f]
    // 0x661bd0: DecompressPointer r1
    //     0x661bd0: add             x1, x1, HEAP, lsl #32
    // 0x661bd4: cmp             w1, NULL
    // 0x661bd8: b.eq            #0x661d50
    // 0x661bdc: LoadField: r2 = r0->field_6f
    //     0x661bdc: ldur            w2, [x0, #0x6f]
    // 0x661be0: DecompressPointer r2
    //     0x661be0: add             x2, x2, HEAP, lsl #32
    // 0x661be4: r16 = Instance_Clip
    //     0x661be4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x661be8: ldr             x16, [x16, #0xb38]
    // 0x661bec: cmp             w2, w16
    // 0x661bf0: b.eq            #0x661d1c
    // 0x661bf4: SaveReg r0
    //     0x661bf4: str             x0, [SP, #-8]!
    // 0x661bf8: r0 = _updateClip()
    //     0x661bf8: bl              #0x63f548  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_updateClip
    // 0x661bfc: add             SP, SP, #8
    // 0x661c00: ldr             x0, [fp, #0x20]
    // 0x661c04: LoadField: r1 = r0->field_37
    //     0x661c04: ldur            w1, [x0, #0x37]
    // 0x661c08: DecompressPointer r1
    //     0x661c08: add             x1, x1, HEAP, lsl #32
    // 0x661c0c: r16 = Sentinel
    //     0x661c0c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x661c10: cmp             w1, w16
    // 0x661c14: b.eq            #0x661d7c
    // 0x661c18: stur            x1, [fp, #-8]
    // 0x661c1c: LoadField: r2 = r0->field_6b
    //     0x661c1c: ldur            w2, [x0, #0x6b]
    // 0x661c20: DecompressPointer r2
    //     0x661c20: add             x2, x2, HEAP, lsl #32
    // 0x661c24: cmp             w2, NULL
    // 0x661c28: b.eq            #0x661d84
    // 0x661c2c: SaveReg r2
    //     0x661c2c: str             x2, [SP, #-8]!
    // 0x661c30: r0 = toRect()
    //     0x661c30: bl              #0x52231c  ; [dart:ui] TextBox::toRect
    // 0x661c34: add             SP, SP, #8
    // 0x661c38: mov             x1, x0
    // 0x661c3c: ldr             x0, [fp, #0x20]
    // 0x661c40: stur            x1, [fp, #-0x18]
    // 0x661c44: LoadField: r2 = r0->field_6b
    //     0x661c44: ldur            w2, [x0, #0x6b]
    // 0x661c48: DecompressPointer r2
    //     0x661c48: add             x2, x2, HEAP, lsl #32
    // 0x661c4c: stur            x2, [fp, #-0x10]
    // 0x661c50: cmp             w2, NULL
    // 0x661c54: b.eq            #0x661d88
    // 0x661c58: r1 = 1
    //     0x661c58: mov             x1, #1
    // 0x661c5c: r0 = AllocateContext()
    //     0x661c5c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x661c60: mov             x3, x0
    // 0x661c64: ldr             x0, [fp, #0x20]
    // 0x661c68: stur            x3, [fp, #-0x38]
    // 0x661c6c: StoreField: r3->field_f = r0
    //     0x661c6c: stur            w0, [x3, #0xf]
    // 0x661c70: LoadField: r4 = r0->field_6f
    //     0x661c70: ldur            w4, [x0, #0x6f]
    // 0x661c74: DecompressPointer r4
    //     0x661c74: add             x4, x4, HEAP, lsl #32
    // 0x661c78: stur            x4, [fp, #-0x30]
    // 0x661c7c: LoadField: r5 = r0->field_2f
    //     0x661c7c: ldur            w5, [x0, #0x2f]
    // 0x661c80: DecompressPointer r5
    //     0x661c80: add             x5, x5, HEAP, lsl #32
    // 0x661c84: stur            x5, [fp, #-0x28]
    // 0x661c88: LoadField: r6 = r5->field_b
    //     0x661c88: ldur            w6, [x5, #0xb]
    // 0x661c8c: DecompressPointer r6
    //     0x661c8c: add             x6, x6, HEAP, lsl #32
    // 0x661c90: mov             x0, x6
    // 0x661c94: stur            x6, [fp, #-0x20]
    // 0x661c98: r2 = Null
    //     0x661c98: mov             x2, NULL
    // 0x661c9c: r1 = Null
    //     0x661c9c: mov             x1, NULL
    // 0x661ca0: r4 = LoadClassIdInstr(r0)
    //     0x661ca0: ldur            x4, [x0, #-1]
    //     0x661ca4: ubfx            x4, x4, #0xc, #0x14
    // 0x661ca8: cmp             x4, #0x954
    // 0x661cac: b.eq            #0x661cc4
    // 0x661cb0: r8 = ClipRRectLayer?
    //     0x661cb0: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d688] Type: ClipRRectLayer?
    //     0x661cb4: ldr             x8, [x8, #0x688]
    // 0x661cb8: r3 = Null
    //     0x661cb8: add             x3, PP, #0x37, lsl #12  ; [pp+0x37060] Null
    //     0x661cbc: ldr             x3, [x3, #0x60]
    // 0x661cc0: r0 = DefaultNullableTypeTest()
    //     0x661cc0: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x661cc4: ldur            x2, [fp, #-0x38]
    // 0x661cc8: r1 = Function 'paint':.
    //     0x661cc8: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cef0] AnonymousClosure: (0x661630), in [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::paint (0x669ddc)
    //     0x661ccc: ldr             x1, [x1, #0xef0]
    // 0x661cd0: r0 = AllocateClosure()
    //     0x661cd0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x661cd4: ldr             x16, [fp, #0x18]
    // 0x661cd8: ldur            lr, [fp, #-8]
    // 0x661cdc: stp             lr, x16, [SP, #-0x10]!
    // 0x661ce0: ldr             x16, [fp, #0x10]
    // 0x661ce4: ldur            lr, [fp, #-0x18]
    // 0x661ce8: stp             lr, x16, [SP, #-0x10]!
    // 0x661cec: ldur            x16, [fp, #-0x10]
    // 0x661cf0: stp             x0, x16, [SP, #-0x10]!
    // 0x661cf4: ldur            x16, [fp, #-0x30]
    // 0x661cf8: ldur            lr, [fp, #-0x20]
    // 0x661cfc: stp             lr, x16, [SP, #-0x10]!
    // 0x661d00: r0 = pushClipRRect()
    //     0x661d00: bl              #0x661d8c  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRRect
    // 0x661d04: add             SP, SP, #0x40
    // 0x661d08: ldur            x16, [fp, #-0x28]
    // 0x661d0c: stp             x0, x16, [SP, #-0x10]!
    // 0x661d10: r0 = layer=()
    //     0x661d10: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x661d14: add             SP, SP, #0x10
    // 0x661d18: b               #0x661d64
    // 0x661d1c: ldr             x16, [fp, #0x18]
    // 0x661d20: stp             x1, x16, [SP, #-0x10]!
    // 0x661d24: ldr             x16, [fp, #0x10]
    // 0x661d28: SaveReg r16
    //     0x661d28: str             x16, [SP, #-8]!
    // 0x661d2c: r0 = paintChild()
    //     0x661d2c: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x661d30: add             SP, SP, #0x18
    // 0x661d34: ldr             x0, [fp, #0x20]
    // 0x661d38: LoadField: r1 = r0->field_2f
    //     0x661d38: ldur            w1, [x0, #0x2f]
    // 0x661d3c: DecompressPointer r1
    //     0x661d3c: add             x1, x1, HEAP, lsl #32
    // 0x661d40: stp             NULL, x1, [SP, #-0x10]!
    // 0x661d44: r0 = layer=()
    //     0x661d44: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x661d48: add             SP, SP, #0x10
    // 0x661d4c: b               #0x661d64
    // 0x661d50: LoadField: r1 = r0->field_2f
    //     0x661d50: ldur            w1, [x0, #0x2f]
    // 0x661d54: DecompressPointer r1
    //     0x661d54: add             x1, x1, HEAP, lsl #32
    // 0x661d58: stp             NULL, x1, [SP, #-0x10]!
    // 0x661d5c: r0 = layer=()
    //     0x661d5c: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x661d60: add             SP, SP, #0x10
    // 0x661d64: r0 = Null
    //     0x661d64: mov             x0, NULL
    // 0x661d68: LeaveFrame
    //     0x661d68: mov             SP, fp
    //     0x661d6c: ldp             fp, lr, [SP], #0x10
    // 0x661d70: ret
    //     0x661d70: ret             
    // 0x661d74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x661d74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x661d78: b               #0x661bc8
    // 0x661d7c: r9 = _needsCompositing
    //     0x661d7c: ldr             x9, [PP, #0x4b28]  ; [pp+0x4b28] Field <RenderObject._needsCompositing@904266271>: late (offset: 0x38)
    // 0x661d80: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x661d80: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x661d84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x661d84: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x661d88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x661d88: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0x6c3db0, size: 0x80
    // 0x6c3db0: EnterFrame
    //     0x6c3db0: stp             fp, lr, [SP, #-0x10]!
    //     0x6c3db4: mov             fp, SP
    // 0x6c3db8: CheckStackOverflow
    //     0x6c3db8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c3dbc: cmp             SP, x16
    //     0x6c3dc0: b.ls            #0x6c3e28
    // 0x6c3dc4: ldr             x1, [fp, #0x18]
    // 0x6c3dc8: LoadField: r0 = r1->field_7b
    //     0x6c3dc8: ldur            w0, [x1, #0x7b]
    // 0x6c3dcc: DecompressPointer r0
    //     0x6c3dcc: add             x0, x0, HEAP, lsl #32
    // 0x6c3dd0: ldr             x2, [fp, #0x10]
    // 0x6c3dd4: cmp             w0, w2
    // 0x6c3dd8: b.ne            #0x6c3dec
    // 0x6c3ddc: r0 = Null
    //     0x6c3ddc: mov             x0, NULL
    // 0x6c3de0: LeaveFrame
    //     0x6c3de0: mov             SP, fp
    //     0x6c3de4: ldp             fp, lr, [SP], #0x10
    // 0x6c3de8: ret
    //     0x6c3de8: ret             
    // 0x6c3dec: mov             x0, x2
    // 0x6c3df0: StoreField: r1->field_7b = r0
    //     0x6c3df0: stur            w0, [x1, #0x7b]
    //     0x6c3df4: ldurb           w16, [x1, #-1]
    //     0x6c3df8: ldurb           w17, [x0, #-1]
    //     0x6c3dfc: and             x16, x17, x16, lsr #2
    //     0x6c3e00: tst             x16, HEAP, lsr #32
    //     0x6c3e04: b.eq            #0x6c3e0c
    //     0x6c3e08: bl              #0xd6826c
    // 0x6c3e0c: SaveReg r1
    //     0x6c3e0c: str             x1, [SP, #-8]!
    // 0x6c3e10: r0 = _markNeedsClip()
    //     0x6c3e10: bl              #0x6c16d0  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_markNeedsClip
    // 0x6c3e14: add             SP, SP, #8
    // 0x6c3e18: r0 = Null
    //     0x6c3e18: mov             x0, NULL
    // 0x6c3e1c: LeaveFrame
    //     0x6c3e1c: mov             SP, fp
    //     0x6c3e20: ldp             fp, lr, [SP], #0x10
    // 0x6c3e24: ret
    //     0x6c3e24: ret             
    // 0x6c3e28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c3e28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c3e2c: b               #0x6c3dc4
  }
  set _ borderRadius=(/* No info */) {
    // ** addr: 0x6c3e30, size: 0x8c
    // 0x6c3e30: EnterFrame
    //     0x6c3e30: stp             fp, lr, [SP, #-0x10]!
    //     0x6c3e34: mov             fp, SP
    // 0x6c3e38: CheckStackOverflow
    //     0x6c3e38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c3e3c: cmp             SP, x16
    //     0x6c3e40: b.ls            #0x6c3eb4
    // 0x6c3e44: ldr             x0, [fp, #0x18]
    // 0x6c3e48: LoadField: r1 = r0->field_77
    //     0x6c3e48: ldur            w1, [x0, #0x77]
    // 0x6c3e4c: DecompressPointer r1
    //     0x6c3e4c: add             x1, x1, HEAP, lsl #32
    // 0x6c3e50: ldr             x16, [fp, #0x10]
    // 0x6c3e54: stp             x16, x1, [SP, #-0x10]!
    // 0x6c3e58: r0 = ==()
    //     0x6c3e58: bl              #0xc9c94c  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0x6c3e5c: add             SP, SP, #0x10
    // 0x6c3e60: tbnz            w0, #4, #0x6c3e74
    // 0x6c3e64: r0 = Null
    //     0x6c3e64: mov             x0, NULL
    // 0x6c3e68: LeaveFrame
    //     0x6c3e68: mov             SP, fp
    //     0x6c3e6c: ldp             fp, lr, [SP], #0x10
    // 0x6c3e70: ret
    //     0x6c3e70: ret             
    // 0x6c3e74: ldr             x1, [fp, #0x18]
    // 0x6c3e78: ldr             x0, [fp, #0x10]
    // 0x6c3e7c: StoreField: r1->field_77 = r0
    //     0x6c3e7c: stur            w0, [x1, #0x77]
    //     0x6c3e80: ldurb           w16, [x1, #-1]
    //     0x6c3e84: ldurb           w17, [x0, #-1]
    //     0x6c3e88: and             x16, x17, x16, lsr #2
    //     0x6c3e8c: tst             x16, HEAP, lsr #32
    //     0x6c3e90: b.eq            #0x6c3e98
    //     0x6c3e94: bl              #0xd6826c
    // 0x6c3e98: SaveReg r1
    //     0x6c3e98: str             x1, [SP, #-8]!
    // 0x6c3e9c: r0 = _markNeedsClip()
    //     0x6c3e9c: bl              #0x6c16d0  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_markNeedsClip
    // 0x6c3ea0: add             SP, SP, #8
    // 0x6c3ea4: r0 = Null
    //     0x6c3ea4: mov             x0, NULL
    // 0x6c3ea8: LeaveFrame
    //     0x6c3ea8: mov             SP, fp
    //     0x6c3eac: ldp             fp, lr, [SP], #0x10
    // 0x6c3eb0: ret
    //     0x6c3eb0: ret             
    // 0x6c3eb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c3eb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c3eb8: b               #0x6c3e44
  }
  _ RenderClipRRect(/* No info */) {
    // ** addr: 0x6eaff8, size: 0x98
    // 0x6eaff8: EnterFrame
    //     0x6eaff8: stp             fp, lr, [SP, #-0x10]!
    //     0x6eaffc: mov             fp, SP
    // 0x6eb000: r1 = Instance_Clip
    //     0x6eb000: add             x1, PP, #0x21, lsl #12  ; [pp+0x21ad0] Obj!Clip@b676b1
    //     0x6eb004: ldr             x1, [x1, #0xad0]
    // 0x6eb008: CheckStackOverflow
    //     0x6eb008: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6eb00c: cmp             SP, x16
    //     0x6eb010: b.ls            #0x6eb088
    // 0x6eb014: ldr             x0, [fp, #0x18]
    // 0x6eb018: ldr             x2, [fp, #0x20]
    // 0x6eb01c: StoreField: r2->field_77 = r0
    //     0x6eb01c: stur            w0, [x2, #0x77]
    //     0x6eb020: ldurb           w16, [x2, #-1]
    //     0x6eb024: ldurb           w17, [x0, #-1]
    //     0x6eb028: and             x16, x17, x16, lsr #2
    //     0x6eb02c: tst             x16, HEAP, lsr #32
    //     0x6eb030: b.eq            #0x6eb038
    //     0x6eb034: bl              #0xd6828c
    // 0x6eb038: ldr             x0, [fp, #0x10]
    // 0x6eb03c: StoreField: r2->field_7b = r0
    //     0x6eb03c: stur            w0, [x2, #0x7b]
    //     0x6eb040: ldurb           w16, [x2, #-1]
    //     0x6eb044: ldurb           w17, [x0, #-1]
    //     0x6eb048: and             x16, x17, x16, lsr #2
    //     0x6eb04c: tst             x16, HEAP, lsr #32
    //     0x6eb050: b.eq            #0x6eb058
    //     0x6eb054: bl              #0xd6828c
    // 0x6eb058: StoreField: r2->field_6f = r1
    //     0x6eb058: stur            w1, [x2, #0x6f]
    // 0x6eb05c: SaveReg r2
    //     0x6eb05c: str             x2, [SP, #-8]!
    // 0x6eb060: r0 = RenderObject()
    //     0x6eb060: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6eb064: add             SP, SP, #8
    // 0x6eb068: ldr             x16, [fp, #0x20]
    // 0x6eb06c: stp             NULL, x16, [SP, #-0x10]!
    // 0x6eb070: r0 = child=()
    //     0x6eb070: bl              #0x6e7da0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::child=
    // 0x6eb074: add             SP, SP, #0x10
    // 0x6eb078: r0 = Null
    //     0x6eb078: mov             x0, NULL
    // 0x6eb07c: LeaveFrame
    //     0x6eb07c: mov             SP, fp
    //     0x6eb080: ldp             fp, lr, [SP], #0x10
    // 0x6eb084: ret
    //     0x6eb084: ret             
    // 0x6eb088: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6eb088: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6eb08c: b               #0x6eb014
  }
  get _ _defaultClip(/* No info */) {
    // ** addr: 0xb0dd18, size: 0x70
    // 0xb0dd18: EnterFrame
    //     0xb0dd18: stp             fp, lr, [SP, #-0x10]!
    //     0xb0dd1c: mov             fp, SP
    // 0xb0dd20: AllocStack(0x8)
    //     0xb0dd20: sub             SP, SP, #8
    // 0xb0dd24: CheckStackOverflow
    //     0xb0dd24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0dd28: cmp             SP, x16
    //     0xb0dd2c: b.ls            #0xb0dd7c
    // 0xb0dd30: ldr             x0, [fp, #0x10]
    // 0xb0dd34: LoadField: r1 = r0->field_77
    //     0xb0dd34: ldur            w1, [x0, #0x77]
    // 0xb0dd38: DecompressPointer r1
    //     0xb0dd38: add             x1, x1, HEAP, lsl #32
    // 0xb0dd3c: stur            x1, [fp, #-8]
    // 0xb0dd40: LoadField: r2 = r0->field_57
    //     0xb0dd40: ldur            w2, [x0, #0x57]
    // 0xb0dd44: DecompressPointer r2
    //     0xb0dd44: add             x2, x2, HEAP, lsl #32
    // 0xb0dd48: cmp             w2, NULL
    // 0xb0dd4c: b.eq            #0xb0dd84
    // 0xb0dd50: r16 = Instance_Offset
    //     0xb0dd50: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xb0dd54: stp             x2, x16, [SP, #-0x10]!
    // 0xb0dd58: r0 = &()
    //     0xb0dd58: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0xb0dd5c: add             SP, SP, #0x10
    // 0xb0dd60: ldur            x16, [fp, #-8]
    // 0xb0dd64: stp             x0, x16, [SP, #-0x10]!
    // 0xb0dd68: r0 = toRRect()
    //     0xb0dd68: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xb0dd6c: add             SP, SP, #0x10
    // 0xb0dd70: LeaveFrame
    //     0xb0dd70: mov             SP, fp
    //     0xb0dd74: ldp             fp, lr, [SP], #0x10
    // 0xb0dd78: ret
    //     0xb0dd78: ret             
    // 0xb0dd7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0dd7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0dd80: b               #0xb0dd30
    // 0xb0dd84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb0dd84: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2503, size: 0x78, field offset: 0x78
class RenderClipRect extends _RenderCustomClip<Rect> {

  _ hitTest(/* No info */) {
    // ** addr: 0x63f4a8, size: 0xa0
    // 0x63f4a8: EnterFrame
    //     0x63f4a8: stp             fp, lr, [SP, #-0x10]!
    //     0x63f4ac: mov             fp, SP
    // 0x63f4b0: CheckStackOverflow
    //     0x63f4b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63f4b4: cmp             SP, x16
    //     0x63f4b8: b.ls            #0x63f53c
    // 0x63f4bc: ldr             x0, [fp, #0x20]
    // 0x63f4c0: LoadField: r1 = r0->field_67
    //     0x63f4c0: ldur            w1, [x0, #0x67]
    // 0x63f4c4: DecompressPointer r1
    //     0x63f4c4: add             x1, x1, HEAP, lsl #32
    // 0x63f4c8: cmp             w1, NULL
    // 0x63f4cc: b.eq            #0x63f514
    // 0x63f4d0: SaveReg r0
    //     0x63f4d0: str             x0, [SP, #-8]!
    // 0x63f4d4: r0 = _updateClip()
    //     0x63f4d4: bl              #0x63f548  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_updateClip
    // 0x63f4d8: add             SP, SP, #8
    // 0x63f4dc: ldr             x0, [fp, #0x20]
    // 0x63f4e0: LoadField: r1 = r0->field_6b
    //     0x63f4e0: ldur            w1, [x0, #0x6b]
    // 0x63f4e4: DecompressPointer r1
    //     0x63f4e4: add             x1, x1, HEAP, lsl #32
    // 0x63f4e8: cmp             w1, NULL
    // 0x63f4ec: b.eq            #0x63f544
    // 0x63f4f0: ldr             x16, [fp, #0x10]
    // 0x63f4f4: stp             x16, x1, [SP, #-0x10]!
    // 0x63f4f8: r0 = contains()
    //     0x63f4f8: bl              #0x627548  ; [dart:ui] Rect::contains
    // 0x63f4fc: add             SP, SP, #0x10
    // 0x63f500: tbz             w0, #4, #0x63f514
    // 0x63f504: r0 = false
    //     0x63f504: add             x0, NULL, #0x30  ; false
    // 0x63f508: LeaveFrame
    //     0x63f508: mov             SP, fp
    //     0x63f50c: ldp             fp, lr, [SP], #0x10
    // 0x63f510: ret
    //     0x63f510: ret             
    // 0x63f514: ldr             x16, [fp, #0x20]
    // 0x63f518: ldr             lr, [fp, #0x18]
    // 0x63f51c: stp             lr, x16, [SP, #-0x10]!
    // 0x63f520: ldr             x16, [fp, #0x10]
    // 0x63f524: SaveReg r16
    //     0x63f524: str             x16, [SP, #-8]!
    // 0x63f528: r0 = hitTest()
    //     0x63f528: bl              #0x640b9c  ; [package:flutter/src/rendering/box.dart] RenderBox::hitTest
    // 0x63f52c: add             SP, SP, #0x18
    // 0x63f530: LeaveFrame
    //     0x63f530: mov             SP, fp
    //     0x63f534: ldp             fp, lr, [SP], #0x10
    // 0x63f538: ret
    //     0x63f538: ret             
    // 0x63f53c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63f53c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63f540: b               #0x63f4bc
    // 0x63f544: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63f544: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0x661a04, size: 0x1ac
    // 0x661a04: EnterFrame
    //     0x661a04: stp             fp, lr, [SP, #-0x10]!
    //     0x661a08: mov             fp, SP
    // 0x661a0c: AllocStack(0x30)
    //     0x661a0c: sub             SP, SP, #0x30
    // 0x661a10: CheckStackOverflow
    //     0x661a10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x661a14: cmp             SP, x16
    //     0x661a18: b.ls            #0x661b9c
    // 0x661a1c: ldr             x0, [fp, #0x20]
    // 0x661a20: LoadField: r1 = r0->field_5f
    //     0x661a20: ldur            w1, [x0, #0x5f]
    // 0x661a24: DecompressPointer r1
    //     0x661a24: add             x1, x1, HEAP, lsl #32
    // 0x661a28: cmp             w1, NULL
    // 0x661a2c: b.eq            #0x661b78
    // 0x661a30: LoadField: r2 = r0->field_6f
    //     0x661a30: ldur            w2, [x0, #0x6f]
    // 0x661a34: DecompressPointer r2
    //     0x661a34: add             x2, x2, HEAP, lsl #32
    // 0x661a38: r16 = Instance_Clip
    //     0x661a38: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x661a3c: ldr             x16, [x16, #0xb38]
    // 0x661a40: cmp             w2, w16
    // 0x661a44: b.eq            #0x661b44
    // 0x661a48: SaveReg r0
    //     0x661a48: str             x0, [SP, #-8]!
    // 0x661a4c: r0 = _updateClip()
    //     0x661a4c: bl              #0x63f548  ; [package:flutter/src/rendering/proxy_box.dart] _RenderCustomClip::_updateClip
    // 0x661a50: add             SP, SP, #8
    // 0x661a54: ldr             x0, [fp, #0x20]
    // 0x661a58: LoadField: r1 = r0->field_37
    //     0x661a58: ldur            w1, [x0, #0x37]
    // 0x661a5c: DecompressPointer r1
    //     0x661a5c: add             x1, x1, HEAP, lsl #32
    // 0x661a60: r16 = Sentinel
    //     0x661a60: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x661a64: cmp             w1, w16
    // 0x661a68: b.eq            #0x661ba4
    // 0x661a6c: stur            x1, [fp, #-0x10]
    // 0x661a70: LoadField: r2 = r0->field_6b
    //     0x661a70: ldur            w2, [x0, #0x6b]
    // 0x661a74: DecompressPointer r2
    //     0x661a74: add             x2, x2, HEAP, lsl #32
    // 0x661a78: stur            x2, [fp, #-8]
    // 0x661a7c: cmp             w2, NULL
    // 0x661a80: b.eq            #0x661bac
    // 0x661a84: r1 = 1
    //     0x661a84: mov             x1, #1
    // 0x661a88: r0 = AllocateContext()
    //     0x661a88: bl              #0xd68aa4  ; AllocateContextStub
    // 0x661a8c: mov             x3, x0
    // 0x661a90: ldr             x0, [fp, #0x20]
    // 0x661a94: stur            x3, [fp, #-0x30]
    // 0x661a98: StoreField: r3->field_f = r0
    //     0x661a98: stur            w0, [x3, #0xf]
    // 0x661a9c: LoadField: r4 = r0->field_6f
    //     0x661a9c: ldur            w4, [x0, #0x6f]
    // 0x661aa0: DecompressPointer r4
    //     0x661aa0: add             x4, x4, HEAP, lsl #32
    // 0x661aa4: stur            x4, [fp, #-0x28]
    // 0x661aa8: LoadField: r5 = r0->field_2f
    //     0x661aa8: ldur            w5, [x0, #0x2f]
    // 0x661aac: DecompressPointer r5
    //     0x661aac: add             x5, x5, HEAP, lsl #32
    // 0x661ab0: stur            x5, [fp, #-0x20]
    // 0x661ab4: LoadField: r6 = r5->field_b
    //     0x661ab4: ldur            w6, [x5, #0xb]
    // 0x661ab8: DecompressPointer r6
    //     0x661ab8: add             x6, x6, HEAP, lsl #32
    // 0x661abc: mov             x0, x6
    // 0x661ac0: stur            x6, [fp, #-0x18]
    // 0x661ac4: r2 = Null
    //     0x661ac4: mov             x2, NULL
    // 0x661ac8: r1 = Null
    //     0x661ac8: mov             x1, NULL
    // 0x661acc: r4 = LoadClassIdInstr(r0)
    //     0x661acc: ldur            x4, [x0, #-1]
    //     0x661ad0: ubfx            x4, x4, #0xc, #0x14
    // 0x661ad4: cmp             x4, #0x955
    // 0x661ad8: b.eq            #0x661af0
    // 0x661adc: r8 = ClipRectLayer?
    //     0x661adc: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4b280] Type: ClipRectLayer?
    //     0x661ae0: ldr             x8, [x8, #0x280]
    // 0x661ae4: r3 = Null
    //     0x661ae4: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b288] Null
    //     0x661ae8: ldr             x3, [x3, #0x288]
    // 0x661aec: r0 = DefaultNullableTypeTest()
    //     0x661aec: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x661af0: ldur            x2, [fp, #-0x30]
    // 0x661af4: r1 = Function 'paint':.
    //     0x661af4: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cef0] AnonymousClosure: (0x661630), in [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::paint (0x669ddc)
    //     0x661af8: ldr             x1, [x1, #0xef0]
    // 0x661afc: r0 = AllocateClosure()
    //     0x661afc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x661b00: ldr             x16, [fp, #0x18]
    // 0x661b04: ldur            lr, [fp, #-0x10]
    // 0x661b08: stp             lr, x16, [SP, #-0x10]!
    // 0x661b0c: ldr             x16, [fp, #0x10]
    // 0x661b10: ldur            lr, [fp, #-8]
    // 0x661b14: stp             lr, x16, [SP, #-0x10]!
    // 0x661b18: ldur            x16, [fp, #-0x28]
    // 0x661b1c: stp             x16, x0, [SP, #-0x10]!
    // 0x661b20: ldur            x16, [fp, #-0x18]
    // 0x661b24: SaveReg r16
    //     0x661b24: str             x16, [SP, #-8]!
    // 0x661b28: r0 = pushClipRect()
    //     0x661b28: bl              #0x65b240  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRect
    // 0x661b2c: add             SP, SP, #0x38
    // 0x661b30: ldur            x16, [fp, #-0x20]
    // 0x661b34: stp             x0, x16, [SP, #-0x10]!
    // 0x661b38: r0 = layer=()
    //     0x661b38: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x661b3c: add             SP, SP, #0x10
    // 0x661b40: b               #0x661b8c
    // 0x661b44: ldr             x16, [fp, #0x18]
    // 0x661b48: stp             x1, x16, [SP, #-0x10]!
    // 0x661b4c: ldr             x16, [fp, #0x10]
    // 0x661b50: SaveReg r16
    //     0x661b50: str             x16, [SP, #-8]!
    // 0x661b54: r0 = paintChild()
    //     0x661b54: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x661b58: add             SP, SP, #0x18
    // 0x661b5c: ldr             x0, [fp, #0x20]
    // 0x661b60: LoadField: r1 = r0->field_2f
    //     0x661b60: ldur            w1, [x0, #0x2f]
    // 0x661b64: DecompressPointer r1
    //     0x661b64: add             x1, x1, HEAP, lsl #32
    // 0x661b68: stp             NULL, x1, [SP, #-0x10]!
    // 0x661b6c: r0 = layer=()
    //     0x661b6c: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x661b70: add             SP, SP, #0x10
    // 0x661b74: b               #0x661b8c
    // 0x661b78: LoadField: r1 = r0->field_2f
    //     0x661b78: ldur            w1, [x0, #0x2f]
    // 0x661b7c: DecompressPointer r1
    //     0x661b7c: add             x1, x1, HEAP, lsl #32
    // 0x661b80: stp             NULL, x1, [SP, #-0x10]!
    // 0x661b84: r0 = layer=()
    //     0x661b84: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x661b88: add             SP, SP, #0x10
    // 0x661b8c: r0 = Null
    //     0x661b8c: mov             x0, NULL
    // 0x661b90: LeaveFrame
    //     0x661b90: mov             SP, fp
    //     0x661b94: ldp             fp, lr, [SP], #0x10
    // 0x661b98: ret
    //     0x661b98: ret             
    // 0x661b9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x661b9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x661ba0: b               #0x661a1c
    // 0x661ba4: r9 = _needsCompositing
    //     0x661ba4: ldr             x9, [PP, #0x4b28]  ; [pp+0x4b28] Field <RenderObject._needsCompositing@904266271>: late (offset: 0x38)
    // 0x661ba8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x661ba8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x661bac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x661bac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2504, size: 0x6c, field offset: 0x64
class RenderBackdropFilter extends RenderProxyBox {

  _ paint(/* No info */) {
    // ** addr: 0x6616e8, size: 0x21c
    // 0x6616e8: EnterFrame
    //     0x6616e8: stp             fp, lr, [SP, #-0x10]!
    //     0x6616ec: mov             fp, SP
    // 0x6616f0: AllocStack(0x10)
    //     0x6616f0: sub             SP, SP, #0x10
    // 0x6616f4: CheckStackOverflow
    //     0x6616f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6616f8: cmp             SP, x16
    //     0x6616fc: b.ls            #0x6618f0
    // 0x661700: ldr             x3, [fp, #0x20]
    // 0x661704: LoadField: r0 = r3->field_5f
    //     0x661704: ldur            w0, [x3, #0x5f]
    // 0x661708: DecompressPointer r0
    //     0x661708: add             x0, x0, HEAP, lsl #32
    // 0x66170c: cmp             w0, NULL
    // 0x661710: b.eq            #0x6618c8
    // 0x661714: LoadField: r4 = r3->field_2f
    //     0x661714: ldur            w4, [x3, #0x2f]
    // 0x661718: DecompressPointer r4
    //     0x661718: add             x4, x4, HEAP, lsl #32
    // 0x66171c: stur            x4, [fp, #-0x10]
    // 0x661720: LoadField: r5 = r4->field_b
    //     0x661720: ldur            w5, [x4, #0xb]
    // 0x661724: DecompressPointer r5
    //     0x661724: add             x5, x5, HEAP, lsl #32
    // 0x661728: mov             x0, x5
    // 0x66172c: stur            x5, [fp, #-8]
    // 0x661730: r2 = Null
    //     0x661730: mov             x2, NULL
    // 0x661734: r1 = Null
    //     0x661734: mov             x1, NULL
    // 0x661738: r4 = LoadClassIdInstr(r0)
    //     0x661738: ldur            x4, [x0, #-1]
    //     0x66173c: ubfx            x4, x4, #0xc, #0x14
    // 0x661740: cmp             x4, #0x952
    // 0x661744: b.eq            #0x66175c
    // 0x661748: r8 = BackdropFilterLayer?
    //     0x661748: add             x8, PP, #0x37, lsl #12  ; [pp+0x37098] Type: BackdropFilterLayer?
    //     0x66174c: ldr             x8, [x8, #0x98]
    // 0x661750: r3 = Null
    //     0x661750: add             x3, PP, #0x37, lsl #12  ; [pp+0x370a0] Null
    //     0x661754: ldr             x3, [x3, #0xa0]
    // 0x661758: r0 = DefaultNullableTypeTest()
    //     0x661758: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x66175c: ldur            x0, [fp, #-8]
    // 0x661760: cmp             w0, NULL
    // 0x661764: b.ne            #0x6617a0
    // 0x661768: r0 = BackdropFilterLayer()
    //     0x661768: bl              #0x6619f8  ; AllocateBackdropFilterLayerStub -> BackdropFilterLayer (size=0x50)
    // 0x66176c: mov             x1, x0
    // 0x661770: r0 = Instance_BlendMode
    //     0x661770: add             x0, PP, #0x27, lsl #12  ; [pp+0x271c0] Obj!BlendMode@b67871
    //     0x661774: ldr             x0, [x0, #0x1c0]
    // 0x661778: stur            x1, [fp, #-8]
    // 0x66177c: StoreField: r1->field_4b = r0
    //     0x66177c: stur            w0, [x1, #0x4b]
    // 0x661780: SaveReg r1
    //     0x661780: str             x1, [SP, #-8]!
    // 0x661784: r0 = Layer()
    //     0x661784: bl              #0x5bbe7c  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0x661788: add             SP, SP, #8
    // 0x66178c: ldur            x16, [fp, #-0x10]
    // 0x661790: ldur            lr, [fp, #-8]
    // 0x661794: stp             lr, x16, [SP, #-0x10]!
    // 0x661798: r0 = layer=()
    //     0x661798: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x66179c: add             SP, SP, #0x10
    // 0x6617a0: ldr             x0, [fp, #0x20]
    // 0x6617a4: ldur            x1, [fp, #-0x10]
    // 0x6617a8: SaveReg r0
    //     0x6617a8: str             x0, [SP, #-8]!
    // 0x6617ac: r0 = layer()
    //     0x6617ac: bl              #0x661994  ; [package:flutter/src/rendering/proxy_box.dart] RenderBackdropFilter::layer
    // 0x6617b0: add             SP, SP, #8
    // 0x6617b4: cmp             w0, NULL
    // 0x6617b8: b.eq            #0x6618f8
    // 0x6617bc: ldr             x1, [fp, #0x20]
    // 0x6617c0: LoadField: r2 = r1->field_63
    //     0x6617c0: ldur            w2, [x1, #0x63]
    // 0x6617c4: DecompressPointer r2
    //     0x6617c4: add             x2, x2, HEAP, lsl #32
    // 0x6617c8: stp             x2, x0, [SP, #-0x10]!
    // 0x6617cc: r0 = filter=()
    //     0x6617cc: bl              #0x661904  ; [package:flutter/src/rendering/layer.dart] BackdropFilterLayer::filter=
    // 0x6617d0: add             SP, SP, #0x10
    // 0x6617d4: ldur            x3, [fp, #-0x10]
    // 0x6617d8: LoadField: r4 = r3->field_b
    //     0x6617d8: ldur            w4, [x3, #0xb]
    // 0x6617dc: DecompressPointer r4
    //     0x6617dc: add             x4, x4, HEAP, lsl #32
    // 0x6617e0: mov             x0, x4
    // 0x6617e4: stur            x4, [fp, #-8]
    // 0x6617e8: r2 = Null
    //     0x6617e8: mov             x2, NULL
    // 0x6617ec: r1 = Null
    //     0x6617ec: mov             x1, NULL
    // 0x6617f0: r4 = LoadClassIdInstr(r0)
    //     0x6617f0: ldur            x4, [x0, #-1]
    //     0x6617f4: ubfx            x4, x4, #0xc, #0x14
    // 0x6617f8: cmp             x4, #0x952
    // 0x6617fc: b.eq            #0x661814
    // 0x661800: r8 = BackdropFilterLayer?
    //     0x661800: add             x8, PP, #0x37, lsl #12  ; [pp+0x37098] Type: BackdropFilterLayer?
    //     0x661804: ldr             x8, [x8, #0x98]
    // 0x661808: r3 = Null
    //     0x661808: add             x3, PP, #0x37, lsl #12  ; [pp+0x370b0] Null
    //     0x66180c: ldr             x3, [x3, #0xb0]
    // 0x661810: r0 = DefaultNullableTypeTest()
    //     0x661810: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x661814: ldur            x0, [fp, #-8]
    // 0x661818: cmp             w0, NULL
    // 0x66181c: b.eq            #0x6618fc
    // 0x661820: r16 = Instance_BlendMode
    //     0x661820: add             x16, PP, #0x27, lsl #12  ; [pp+0x271c0] Obj!BlendMode@b67871
    //     0x661824: ldr             x16, [x16, #0x1c0]
    // 0x661828: stp             x16, x0, [SP, #-0x10]!
    // 0x66182c: r0 = Shader._()
    //     0x66182c: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x661830: add             SP, SP, #0x10
    // 0x661834: ldur            x0, [fp, #-0x10]
    // 0x661838: LoadField: r3 = r0->field_b
    //     0x661838: ldur            w3, [x0, #0xb]
    // 0x66183c: DecompressPointer r3
    //     0x66183c: add             x3, x3, HEAP, lsl #32
    // 0x661840: mov             x0, x3
    // 0x661844: stur            x3, [fp, #-8]
    // 0x661848: r2 = Null
    //     0x661848: mov             x2, NULL
    // 0x66184c: r1 = Null
    //     0x66184c: mov             x1, NULL
    // 0x661850: r4 = LoadClassIdInstr(r0)
    //     0x661850: ldur            x4, [x0, #-1]
    //     0x661854: ubfx            x4, x4, #0xc, #0x14
    // 0x661858: cmp             x4, #0x952
    // 0x66185c: b.eq            #0x661874
    // 0x661860: r8 = BackdropFilterLayer?
    //     0x661860: add             x8, PP, #0x37, lsl #12  ; [pp+0x37098] Type: BackdropFilterLayer?
    //     0x661864: ldr             x8, [x8, #0x98]
    // 0x661868: r3 = Null
    //     0x661868: add             x3, PP, #0x37, lsl #12  ; [pp+0x370c0] Null
    //     0x66186c: ldr             x3, [x3, #0xc0]
    // 0x661870: r0 = DefaultNullableTypeTest()
    //     0x661870: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x661874: ldur            x0, [fp, #-8]
    // 0x661878: cmp             w0, NULL
    // 0x66187c: b.eq            #0x661900
    // 0x661880: r1 = 1
    //     0x661880: mov             x1, #1
    // 0x661884: r0 = AllocateContext()
    //     0x661884: bl              #0xd68aa4  ; AllocateContextStub
    // 0x661888: mov             x1, x0
    // 0x66188c: ldr             x0, [fp, #0x20]
    // 0x661890: StoreField: r1->field_f = r0
    //     0x661890: stur            w0, [x1, #0xf]
    // 0x661894: mov             x2, x1
    // 0x661898: r1 = Function 'paint':.
    //     0x661898: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cef0] AnonymousClosure: (0x661630), in [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::paint (0x669ddc)
    //     0x66189c: ldr             x1, [x1, #0xef0]
    // 0x6618a0: r0 = AllocateClosure()
    //     0x6618a0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6618a4: ldr             x16, [fp, #0x18]
    // 0x6618a8: ldur            lr, [fp, #-8]
    // 0x6618ac: stp             lr, x16, [SP, #-0x10]!
    // 0x6618b0: ldr             x16, [fp, #0x10]
    // 0x6618b4: stp             x16, x0, [SP, #-0x10]!
    // 0x6618b8: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x6618b8: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x6618bc: r0 = pushLayer()
    //     0x6618bc: bl              #0x65bbc8  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0x6618c0: add             SP, SP, #0x20
    // 0x6618c4: b               #0x6618e0
    // 0x6618c8: mov             x0, x3
    // 0x6618cc: LoadField: r1 = r0->field_2f
    //     0x6618cc: ldur            w1, [x0, #0x2f]
    // 0x6618d0: DecompressPointer r1
    //     0x6618d0: add             x1, x1, HEAP, lsl #32
    // 0x6618d4: stp             NULL, x1, [SP, #-0x10]!
    // 0x6618d8: r0 = layer=()
    //     0x6618d8: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x6618dc: add             SP, SP, #0x10
    // 0x6618e0: r0 = Null
    //     0x6618e0: mov             x0, NULL
    // 0x6618e4: LeaveFrame
    //     0x6618e4: mov             SP, fp
    //     0x6618e8: ldp             fp, lr, [SP], #0x10
    // 0x6618ec: ret
    //     0x6618ec: ret             
    // 0x6618f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6618f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6618f4: b               #0x661700
    // 0x6618f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6618f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6618fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6618fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x661900: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x661900: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ layer(/* No info */) {
    // ** addr: 0x661994, size: 0x64
    // 0x661994: EnterFrame
    //     0x661994: stp             fp, lr, [SP, #-0x10]!
    //     0x661998: mov             fp, SP
    // 0x66199c: AllocStack(0x8)
    //     0x66199c: sub             SP, SP, #8
    // 0x6619a0: ldr             x0, [fp, #0x10]
    // 0x6619a4: LoadField: r1 = r0->field_2f
    //     0x6619a4: ldur            w1, [x0, #0x2f]
    // 0x6619a8: DecompressPointer r1
    //     0x6619a8: add             x1, x1, HEAP, lsl #32
    // 0x6619ac: LoadField: r3 = r1->field_b
    //     0x6619ac: ldur            w3, [x1, #0xb]
    // 0x6619b0: DecompressPointer r3
    //     0x6619b0: add             x3, x3, HEAP, lsl #32
    // 0x6619b4: mov             x0, x3
    // 0x6619b8: stur            x3, [fp, #-8]
    // 0x6619bc: r2 = Null
    //     0x6619bc: mov             x2, NULL
    // 0x6619c0: r1 = Null
    //     0x6619c0: mov             x1, NULL
    // 0x6619c4: r4 = LoadClassIdInstr(r0)
    //     0x6619c4: ldur            x4, [x0, #-1]
    //     0x6619c8: ubfx            x4, x4, #0xc, #0x14
    // 0x6619cc: cmp             x4, #0x952
    // 0x6619d0: b.eq            #0x6619e8
    // 0x6619d4: r8 = BackdropFilterLayer?
    //     0x6619d4: add             x8, PP, #0x37, lsl #12  ; [pp+0x37098] Type: BackdropFilterLayer?
    //     0x6619d8: ldr             x8, [x8, #0x98]
    // 0x6619dc: r3 = Null
    //     0x6619dc: add             x3, PP, #0x37, lsl #12  ; [pp+0x370d0] Null
    //     0x6619e0: ldr             x3, [x3, #0xd0]
    // 0x6619e4: r0 = DefaultNullableTypeTest()
    //     0x6619e4: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x6619e8: ldur            x0, [fp, #-8]
    // 0x6619ec: LeaveFrame
    //     0x6619ec: mov             SP, fp
    //     0x6619f0: ldp             fp, lr, [SP], #0x10
    // 0x6619f4: ret
    //     0x6619f4: ret             
  }
  get _ alwaysNeedsCompositing(/* No info */) {
    // ** addr: 0x675b04, size: 0x20
    // 0x675b04: ldr             x1, [SP]
    // 0x675b08: LoadField: r2 = r1->field_5f
    //     0x675b08: ldur            w2, [x1, #0x5f]
    // 0x675b0c: DecompressPointer r2
    //     0x675b0c: add             x2, x2, HEAP, lsl #32
    // 0x675b10: cmp             w2, NULL
    // 0x675b14: r16 = true
    //     0x675b14: add             x16, NULL, #0x20  ; true
    // 0x675b18: r17 = false
    //     0x675b18: add             x17, NULL, #0x30  ; false
    // 0x675b1c: csel            x0, x16, x17, ne
    // 0x675b20: ret
    //     0x675b20: ret             
  }
  set _ filter=(/* No info */) {
    // ** addr: 0x6c3944, size: 0xd8
    // 0x6c3944: EnterFrame
    //     0x6c3944: stp             fp, lr, [SP, #-0x10]!
    //     0x6c3948: mov             fp, SP
    // 0x6c394c: AllocStack(0x8)
    //     0x6c394c: sub             SP, SP, #8
    // 0x6c3950: CheckStackOverflow
    //     0x6c3950: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c3954: cmp             SP, x16
    //     0x6c3958: b.ls            #0x6c3a14
    // 0x6c395c: ldr             x0, [fp, #0x18]
    // 0x6c3960: LoadField: r1 = r0->field_63
    //     0x6c3960: ldur            w1, [x0, #0x63]
    // 0x6c3964: DecompressPointer r1
    //     0x6c3964: add             x1, x1, HEAP, lsl #32
    // 0x6c3968: stur            x1, [fp, #-8]
    // 0x6c396c: r16 = _GaussianBlurImageFilter
    //     0x6c396c: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2ed88] Type: _GaussianBlurImageFilter
    //     0x6c3970: ldr             x16, [x16, #0xd88]
    // 0x6c3974: r30 = _GaussianBlurImageFilter
    //     0x6c3974: add             lr, PP, #0x2e, lsl #12  ; [pp+0x2ed88] Type: _GaussianBlurImageFilter
    //     0x6c3978: ldr             lr, [lr, #0xd88]
    // 0x6c397c: stp             lr, x16, [SP, #-0x10]!
    // 0x6c3980: r0 = ==()
    //     0x6c3980: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x6c3984: add             SP, SP, #0x10
    // 0x6c3988: tbz             w0, #4, #0x6c3994
    // 0x6c398c: ldr             x1, [fp, #0x10]
    // 0x6c3990: b               #0x6c39d4
    // 0x6c3994: ldr             x1, [fp, #0x10]
    // 0x6c3998: ldur            x0, [fp, #-8]
    // 0x6c399c: LoadField: d0 = r1->field_7
    //     0x6c399c: ldur            d0, [x1, #7]
    // 0x6c39a0: LoadField: d1 = r0->field_7
    //     0x6c39a0: ldur            d1, [x0, #7]
    // 0x6c39a4: fcmp            d0, d1
    // 0x6c39a8: b.vs            #0x6c39d4
    // 0x6c39ac: b.ne            #0x6c39d4
    // 0x6c39b0: LoadField: d0 = r1->field_f
    //     0x6c39b0: ldur            d0, [x1, #0xf]
    // 0x6c39b4: LoadField: d1 = r0->field_f
    //     0x6c39b4: ldur            d1, [x0, #0xf]
    // 0x6c39b8: fcmp            d0, d1
    // 0x6c39bc: b.vs            #0x6c39d4
    // 0x6c39c0: b.ne            #0x6c39d4
    // 0x6c39c4: r0 = Null
    //     0x6c39c4: mov             x0, NULL
    // 0x6c39c8: LeaveFrame
    //     0x6c39c8: mov             SP, fp
    //     0x6c39cc: ldp             fp, lr, [SP], #0x10
    // 0x6c39d0: ret
    //     0x6c39d0: ret             
    // 0x6c39d4: ldr             x2, [fp, #0x18]
    // 0x6c39d8: mov             x0, x1
    // 0x6c39dc: StoreField: r2->field_63 = r0
    //     0x6c39dc: stur            w0, [x2, #0x63]
    //     0x6c39e0: ldurb           w16, [x2, #-1]
    //     0x6c39e4: ldurb           w17, [x0, #-1]
    //     0x6c39e8: and             x16, x17, x16, lsr #2
    //     0x6c39ec: tst             x16, HEAP, lsr #32
    //     0x6c39f0: b.eq            #0x6c39f8
    //     0x6c39f4: bl              #0xd6828c
    // 0x6c39f8: SaveReg r2
    //     0x6c39f8: str             x2, [SP, #-8]!
    // 0x6c39fc: r0 = markNeedsPaint()
    //     0x6c39fc: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c3a00: add             SP, SP, #8
    // 0x6c3a04: r0 = Null
    //     0x6c3a04: mov             x0, NULL
    // 0x6c3a08: LeaveFrame
    //     0x6c3a08: mov             SP, fp
    //     0x6c3a0c: ldp             fp, lr, [SP], #0x10
    // 0x6c3a10: ret
    //     0x6c3a10: ret             
    // 0x6c3a14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c3a14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c3a18: b               #0x6c395c
  }
}

// class id: 2505, size: 0x64, field offset: 0x64
//   transformed mixin,
abstract class _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin extends RenderProxyBox
     with RenderProxyBoxMixin<X0 bound RenderBox> {

  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0x62e908, size: 0x9c
    // 0x62e908: EnterFrame
    //     0x62e908: stp             fp, lr, [SP, #-0x10]!
    //     0x62e90c: mov             fp, SP
    // 0x62e910: CheckStackOverflow
    //     0x62e910: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62e914: cmp             SP, x16
    //     0x62e918: b.ls            #0x62e98c
    // 0x62e91c: ldr             x0, [fp, #0x18]
    // 0x62e920: LoadField: r1 = r0->field_5f
    //     0x62e920: ldur            w1, [x0, #0x5f]
    // 0x62e924: DecompressPointer r1
    //     0x62e924: add             x1, x1, HEAP, lsl #32
    // 0x62e928: cmp             w1, NULL
    // 0x62e92c: b.eq            #0x62e97c
    // 0x62e930: ldr             x0, [fp, #0x10]
    // 0x62e934: LoadField: d0 = r0->field_7
    //     0x62e934: ldur            d0, [x0, #7]
    // 0x62e938: SaveReg r1
    //     0x62e938: str             x1, [SP, #-8]!
    // 0x62e93c: SaveReg d0
    //     0x62e93c: str             d0, [SP, #-8]!
    // 0x62e940: r0 = getMaxIntrinsicHeight()
    //     0x62e940: bl              #0x62cb24  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0x62e944: add             SP, SP, #0x10
    // 0x62e948: r0 = inline_Allocate_Double()
    //     0x62e948: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62e94c: add             x0, x0, #0x10
    //     0x62e950: cmp             x1, x0
    //     0x62e954: b.ls            #0x62e994
    //     0x62e958: str             x0, [THR, #0x60]  ; THR::top
    //     0x62e95c: sub             x0, x0, #0xf
    //     0x62e960: mov             x1, #0xd108
    //     0x62e964: movk            x1, #3, lsl #16
    //     0x62e968: stur            x1, [x0, #-1]
    // 0x62e96c: StoreField: r0->field_7 = d0
    //     0x62e96c: stur            d0, [x0, #7]
    // 0x62e970: LeaveFrame
    //     0x62e970: mov             SP, fp
    //     0x62e974: ldp             fp, lr, [SP], #0x10
    // 0x62e978: ret
    //     0x62e978: ret             
    // 0x62e97c: r0 = 0.000000
    //     0x62e97c: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x62e980: LeaveFrame
    //     0x62e980: mov             SP, fp
    //     0x62e984: ldp             fp, lr, [SP], #0x10
    // 0x62e988: ret
    //     0x62e988: ret             
    // 0x62e98c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62e98c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62e990: b               #0x62e91c
    // 0x62e994: SaveReg d0
    //     0x62e994: str             q0, [SP, #-0x10]!
    // 0x62e998: r0 = AllocateDouble()
    //     0x62e998: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62e99c: RestoreReg d0
    //     0x62e99c: ldr             q0, [SP], #0x10
    // 0x62e9a0: b               #0x62e96c
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x62e9a4, size: 0x4c
    // 0x62e9a4: EnterFrame
    //     0x62e9a4: stp             fp, lr, [SP, #-0x10]!
    //     0x62e9a8: mov             fp, SP
    // 0x62e9ac: ldr             x0, [fp, #0x18]
    // 0x62e9b0: LoadField: r1 = r0->field_17
    //     0x62e9b0: ldur            w1, [x0, #0x17]
    // 0x62e9b4: DecompressPointer r1
    //     0x62e9b4: add             x1, x1, HEAP, lsl #32
    // 0x62e9b8: CheckStackOverflow
    //     0x62e9b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62e9bc: cmp             SP, x16
    //     0x62e9c0: b.ls            #0x62e9e8
    // 0x62e9c4: LoadField: r0 = r1->field_f
    //     0x62e9c4: ldur            w0, [x1, #0xf]
    // 0x62e9c8: DecompressPointer r0
    //     0x62e9c8: add             x0, x0, HEAP, lsl #32
    // 0x62e9cc: ldr             x16, [fp, #0x10]
    // 0x62e9d0: stp             x16, x0, [SP, #-0x10]!
    // 0x62e9d4: r0 = computeMaxIntrinsicHeight()
    //     0x62e9d4: bl              #0x62e908  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMaxIntrinsicHeight
    // 0x62e9d8: add             SP, SP, #0x10
    // 0x62e9dc: LeaveFrame
    //     0x62e9dc: mov             SP, fp
    //     0x62e9e0: ldp             fp, lr, [SP], #0x10
    // 0x62e9e4: ret
    //     0x62e9e4: ret             
    // 0x62e9e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62e9e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62e9ec: b               #0x62e9c4
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x62eec8, size: 0x18
    // 0x62eec8: r4 = 0
    //     0x62eec8: mov             x4, #0
    // 0x62eecc: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x62eecc: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b278] AnonymousClosure: (0x62e9a4), in [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMaxIntrinsicHeight (0x62e908)
    //     0x62eed0: ldr             x1, [x17, #0x278]
    // 0x62eed4: r24 = BuildNonGenericMethodExtractorStub
    //     0x62eed4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x62eed8: LoadField: r0 = r24->field_17
    //     0x62eed8: ldur            x0, [x24, #0x17]
    // 0x62eedc: br              x0
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0x635544, size: 0x9c
    // 0x635544: EnterFrame
    //     0x635544: stp             fp, lr, [SP, #-0x10]!
    //     0x635548: mov             fp, SP
    // 0x63554c: CheckStackOverflow
    //     0x63554c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x635550: cmp             SP, x16
    //     0x635554: b.ls            #0x6355c8
    // 0x635558: ldr             x0, [fp, #0x18]
    // 0x63555c: LoadField: r1 = r0->field_5f
    //     0x63555c: ldur            w1, [x0, #0x5f]
    // 0x635560: DecompressPointer r1
    //     0x635560: add             x1, x1, HEAP, lsl #32
    // 0x635564: cmp             w1, NULL
    // 0x635568: b.eq            #0x6355b8
    // 0x63556c: ldr             x0, [fp, #0x10]
    // 0x635570: LoadField: d0 = r0->field_7
    //     0x635570: ldur            d0, [x0, #7]
    // 0x635574: SaveReg r1
    //     0x635574: str             x1, [SP, #-8]!
    // 0x635578: SaveReg d0
    //     0x635578: str             d0, [SP, #-8]!
    // 0x63557c: r0 = getMaxIntrinsicWidth()
    //     0x63557c: bl              #0x62cb94  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0x635580: add             SP, SP, #0x10
    // 0x635584: r0 = inline_Allocate_Double()
    //     0x635584: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x635588: add             x0, x0, #0x10
    //     0x63558c: cmp             x1, x0
    //     0x635590: b.ls            #0x6355d0
    //     0x635594: str             x0, [THR, #0x60]  ; THR::top
    //     0x635598: sub             x0, x0, #0xf
    //     0x63559c: mov             x1, #0xd108
    //     0x6355a0: movk            x1, #3, lsl #16
    //     0x6355a4: stur            x1, [x0, #-1]
    // 0x6355a8: StoreField: r0->field_7 = d0
    //     0x6355a8: stur            d0, [x0, #7]
    // 0x6355ac: LeaveFrame
    //     0x6355ac: mov             SP, fp
    //     0x6355b0: ldp             fp, lr, [SP], #0x10
    // 0x6355b4: ret
    //     0x6355b4: ret             
    // 0x6355b8: r0 = 0.000000
    //     0x6355b8: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x6355bc: LeaveFrame
    //     0x6355bc: mov             SP, fp
    //     0x6355c0: ldp             fp, lr, [SP], #0x10
    // 0x6355c4: ret
    //     0x6355c4: ret             
    // 0x6355c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6355c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6355cc: b               #0x635558
    // 0x6355d0: SaveReg d0
    //     0x6355d0: str             q0, [SP, #-0x10]!
    // 0x6355d4: r0 = AllocateDouble()
    //     0x6355d4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6355d8: RestoreReg d0
    //     0x6355d8: ldr             q0, [SP], #0x10
    // 0x6355dc: b               #0x6355a8
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x6355e0, size: 0x4c
    // 0x6355e0: EnterFrame
    //     0x6355e0: stp             fp, lr, [SP, #-0x10]!
    //     0x6355e4: mov             fp, SP
    // 0x6355e8: ldr             x0, [fp, #0x18]
    // 0x6355ec: LoadField: r1 = r0->field_17
    //     0x6355ec: ldur            w1, [x0, #0x17]
    // 0x6355f0: DecompressPointer r1
    //     0x6355f0: add             x1, x1, HEAP, lsl #32
    // 0x6355f4: CheckStackOverflow
    //     0x6355f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6355f8: cmp             SP, x16
    //     0x6355fc: b.ls            #0x635624
    // 0x635600: LoadField: r0 = r1->field_f
    //     0x635600: ldur            w0, [x1, #0xf]
    // 0x635604: DecompressPointer r0
    //     0x635604: add             x0, x0, HEAP, lsl #32
    // 0x635608: ldr             x16, [fp, #0x10]
    // 0x63560c: stp             x16, x0, [SP, #-0x10]!
    // 0x635610: r0 = computeMaxIntrinsicWidth()
    //     0x635610: bl              #0x635544  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMaxIntrinsicWidth
    // 0x635614: add             SP, SP, #0x10
    // 0x635618: LeaveFrame
    //     0x635618: mov             SP, fp
    //     0x63561c: ldp             fp, lr, [SP], #0x10
    // 0x635620: ret
    //     0x635620: ret             
    // 0x635624: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x635624: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x635628: b               #0x635600
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x6358e0, size: 0x18
    // 0x6358e0: r4 = 0
    //     0x6358e0: mov             x4, #0
    // 0x6358e4: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x6358e4: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fc88] AnonymousClosure: (0x6355e0), in [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMaxIntrinsicWidth (0x635544)
    //     0x6358e8: ldr             x1, [x17, #0xc88]
    // 0x6358ec: r24 = BuildNonGenericMethodExtractorStub
    //     0x6358ec: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x6358f0: LoadField: r0 = r24->field_17
    //     0x6358f0: ldur            x0, [x24, #0x17]
    // 0x6358f4: br              x0
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0x63863c, size: 0x9c
    // 0x63863c: EnterFrame
    //     0x63863c: stp             fp, lr, [SP, #-0x10]!
    //     0x638640: mov             fp, SP
    // 0x638644: CheckStackOverflow
    //     0x638644: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x638648: cmp             SP, x16
    //     0x63864c: b.ls            #0x6386c0
    // 0x638650: ldr             x0, [fp, #0x18]
    // 0x638654: LoadField: r1 = r0->field_5f
    //     0x638654: ldur            w1, [x0, #0x5f]
    // 0x638658: DecompressPointer r1
    //     0x638658: add             x1, x1, HEAP, lsl #32
    // 0x63865c: cmp             w1, NULL
    // 0x638660: b.eq            #0x6386b0
    // 0x638664: ldr             x0, [fp, #0x10]
    // 0x638668: LoadField: d0 = r0->field_7
    //     0x638668: ldur            d0, [x0, #7]
    // 0x63866c: SaveReg r1
    //     0x63866c: str             x1, [SP, #-8]!
    // 0x638670: SaveReg d0
    //     0x638670: str             d0, [SP, #-8]!
    // 0x638674: r0 = getMinIntrinsicHeight()
    //     0x638674: bl              #0x630a58  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0x638678: add             SP, SP, #0x10
    // 0x63867c: r0 = inline_Allocate_Double()
    //     0x63867c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x638680: add             x0, x0, #0x10
    //     0x638684: cmp             x1, x0
    //     0x638688: b.ls            #0x6386c8
    //     0x63868c: str             x0, [THR, #0x60]  ; THR::top
    //     0x638690: sub             x0, x0, #0xf
    //     0x638694: mov             x1, #0xd108
    //     0x638698: movk            x1, #3, lsl #16
    //     0x63869c: stur            x1, [x0, #-1]
    // 0x6386a0: StoreField: r0->field_7 = d0
    //     0x6386a0: stur            d0, [x0, #7]
    // 0x6386a4: LeaveFrame
    //     0x6386a4: mov             SP, fp
    //     0x6386a8: ldp             fp, lr, [SP], #0x10
    // 0x6386ac: ret
    //     0x6386ac: ret             
    // 0x6386b0: r0 = 0.000000
    //     0x6386b0: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x6386b4: LeaveFrame
    //     0x6386b4: mov             SP, fp
    //     0x6386b8: ldp             fp, lr, [SP], #0x10
    // 0x6386bc: ret
    //     0x6386bc: ret             
    // 0x6386c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6386c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6386c4: b               #0x638650
    // 0x6386c8: SaveReg d0
    //     0x6386c8: str             q0, [SP, #-0x10]!
    // 0x6386cc: r0 = AllocateDouble()
    //     0x6386cc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6386d0: RestoreReg d0
    //     0x6386d0: ldr             q0, [SP], #0x10
    // 0x6386d4: b               #0x6386a0
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x6386d8, size: 0x4c
    // 0x6386d8: EnterFrame
    //     0x6386d8: stp             fp, lr, [SP, #-0x10]!
    //     0x6386dc: mov             fp, SP
    // 0x6386e0: ldr             x0, [fp, #0x18]
    // 0x6386e4: LoadField: r1 = r0->field_17
    //     0x6386e4: ldur            w1, [x0, #0x17]
    // 0x6386e8: DecompressPointer r1
    //     0x6386e8: add             x1, x1, HEAP, lsl #32
    // 0x6386ec: CheckStackOverflow
    //     0x6386ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6386f0: cmp             SP, x16
    //     0x6386f4: b.ls            #0x63871c
    // 0x6386f8: LoadField: r0 = r1->field_f
    //     0x6386f8: ldur            w0, [x1, #0xf]
    // 0x6386fc: DecompressPointer r0
    //     0x6386fc: add             x0, x0, HEAP, lsl #32
    // 0x638700: ldr             x16, [fp, #0x10]
    // 0x638704: stp             x16, x0, [SP, #-0x10]!
    // 0x638708: r0 = computeMinIntrinsicHeight()
    //     0x638708: bl              #0x63863c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMinIntrinsicHeight
    // 0x63870c: add             SP, SP, #0x10
    // 0x638710: LeaveFrame
    //     0x638710: mov             SP, fp
    //     0x638714: ldp             fp, lr, [SP], #0x10
    // 0x638718: ret
    //     0x638718: ret             
    // 0x63871c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63871c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x638720: b               #0x6386f8
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x638b14, size: 0x18
    // 0x638b14: r4 = 0
    //     0x638b14: mov             x4, #0
    // 0x638b18: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x638b18: add             x17, PP, #0x52, lsl #12  ; [pp+0x52ea8] AnonymousClosure: (0x6386d8), in [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMinIntrinsicHeight (0x63863c)
    //     0x638b1c: ldr             x1, [x17, #0xea8]
    // 0x638b20: r24 = BuildNonGenericMethodExtractorStub
    //     0x638b20: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x638b24: LoadField: r0 = r24->field_17
    //     0x638b24: ldur            x0, [x24, #0x17]
    // 0x638b28: br              x0
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0x63b368, size: 0x9c
    // 0x63b368: EnterFrame
    //     0x63b368: stp             fp, lr, [SP, #-0x10]!
    //     0x63b36c: mov             fp, SP
    // 0x63b370: CheckStackOverflow
    //     0x63b370: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63b374: cmp             SP, x16
    //     0x63b378: b.ls            #0x63b3ec
    // 0x63b37c: ldr             x0, [fp, #0x18]
    // 0x63b380: LoadField: r1 = r0->field_5f
    //     0x63b380: ldur            w1, [x0, #0x5f]
    // 0x63b384: DecompressPointer r1
    //     0x63b384: add             x1, x1, HEAP, lsl #32
    // 0x63b388: cmp             w1, NULL
    // 0x63b38c: b.eq            #0x63b3dc
    // 0x63b390: ldr             x0, [fp, #0x10]
    // 0x63b394: LoadField: d0 = r0->field_7
    //     0x63b394: ldur            d0, [x0, #7]
    // 0x63b398: SaveReg r1
    //     0x63b398: str             x1, [SP, #-8]!
    // 0x63b39c: SaveReg d0
    //     0x63b39c: str             d0, [SP, #-8]!
    // 0x63b3a0: r0 = getMinIntrinsicWidth()
    //     0x63b3a0: bl              #0x630b18  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicWidth
    // 0x63b3a4: add             SP, SP, #0x10
    // 0x63b3a8: r0 = inline_Allocate_Double()
    //     0x63b3a8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63b3ac: add             x0, x0, #0x10
    //     0x63b3b0: cmp             x1, x0
    //     0x63b3b4: b.ls            #0x63b3f4
    //     0x63b3b8: str             x0, [THR, #0x60]  ; THR::top
    //     0x63b3bc: sub             x0, x0, #0xf
    //     0x63b3c0: mov             x1, #0xd108
    //     0x63b3c4: movk            x1, #3, lsl #16
    //     0x63b3c8: stur            x1, [x0, #-1]
    // 0x63b3cc: StoreField: r0->field_7 = d0
    //     0x63b3cc: stur            d0, [x0, #7]
    // 0x63b3d0: LeaveFrame
    //     0x63b3d0: mov             SP, fp
    //     0x63b3d4: ldp             fp, lr, [SP], #0x10
    // 0x63b3d8: ret
    //     0x63b3d8: ret             
    // 0x63b3dc: r0 = 0.000000
    //     0x63b3dc: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x63b3e0: LeaveFrame
    //     0x63b3e0: mov             SP, fp
    //     0x63b3e4: ldp             fp, lr, [SP], #0x10
    // 0x63b3e8: ret
    //     0x63b3e8: ret             
    // 0x63b3ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63b3ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63b3f0: b               #0x63b37c
    // 0x63b3f4: SaveReg d0
    //     0x63b3f4: str             q0, [SP, #-0x10]!
    // 0x63b3f8: r0 = AllocateDouble()
    //     0x63b3f8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63b3fc: RestoreReg d0
    //     0x63b3fc: ldr             q0, [SP], #0x10
    // 0x63b400: b               #0x63b3cc
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63b404, size: 0x4c
    // 0x63b404: EnterFrame
    //     0x63b404: stp             fp, lr, [SP, #-0x10]!
    //     0x63b408: mov             fp, SP
    // 0x63b40c: ldr             x0, [fp, #0x18]
    // 0x63b410: LoadField: r1 = r0->field_17
    //     0x63b410: ldur            w1, [x0, #0x17]
    // 0x63b414: DecompressPointer r1
    //     0x63b414: add             x1, x1, HEAP, lsl #32
    // 0x63b418: CheckStackOverflow
    //     0x63b418: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63b41c: cmp             SP, x16
    //     0x63b420: b.ls            #0x63b448
    // 0x63b424: LoadField: r0 = r1->field_f
    //     0x63b424: ldur            w0, [x1, #0xf]
    // 0x63b428: DecompressPointer r0
    //     0x63b428: add             x0, x0, HEAP, lsl #32
    // 0x63b42c: ldr             x16, [fp, #0x10]
    // 0x63b430: stp             x16, x0, [SP, #-0x10]!
    // 0x63b434: r0 = computeMinIntrinsicWidth()
    //     0x63b434: bl              #0x63b368  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMinIntrinsicWidth
    // 0x63b438: add             SP, SP, #0x10
    // 0x63b43c: LeaveFrame
    //     0x63b43c: mov             SP, fp
    //     0x63b440: ldp             fp, lr, [SP], #0x10
    // 0x63b444: ret
    //     0x63b444: ret             
    // 0x63b448: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63b448: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63b44c: b               #0x63b424
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63b750, size: 0x18
    // 0x63b750: r4 = 0
    //     0x63b750: mov             x4, #0
    // 0x63b754: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63b754: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fda8] AnonymousClosure: (0x63b404), in [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMinIntrinsicWidth (0x63b368)
    //     0x63b758: ldr             x1, [x17, #0xda8]
    // 0x63b75c: r24 = BuildNonGenericMethodExtractorStub
    //     0x63b75c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63b760: LoadField: r0 = r24->field_17
    //     0x63b760: ldur            x0, [x24, #0x17]
    // 0x63b764: br              x0
  }
  _ computeDistanceToActualBaseline(/* No info */) {
    // ** addr: 0x63e058, size: 0x68
    // 0x63e058: EnterFrame
    //     0x63e058: stp             fp, lr, [SP, #-0x10]!
    //     0x63e05c: mov             fp, SP
    // 0x63e060: CheckStackOverflow
    //     0x63e060: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63e064: cmp             SP, x16
    //     0x63e068: b.ls            #0x63e0b8
    // 0x63e06c: ldr             x0, [fp, #0x18]
    // 0x63e070: LoadField: r1 = r0->field_5f
    //     0x63e070: ldur            w1, [x0, #0x5f]
    // 0x63e074: DecompressPointer r1
    //     0x63e074: add             x1, x1, HEAP, lsl #32
    // 0x63e078: cmp             w1, NULL
    // 0x63e07c: b.eq            #0x63e09c
    // 0x63e080: ldr             x16, [fp, #0x10]
    // 0x63e084: stp             x16, x1, [SP, #-0x10]!
    // 0x63e088: r0 = getDistanceToActualBaseline()
    //     0x63e088: bl              #0x63d634  ; [package:flutter/src/rendering/box.dart] RenderBox::getDistanceToActualBaseline
    // 0x63e08c: add             SP, SP, #0x10
    // 0x63e090: LeaveFrame
    //     0x63e090: mov             SP, fp
    //     0x63e094: ldp             fp, lr, [SP], #0x10
    // 0x63e098: ret
    //     0x63e098: ret             
    // 0x63e09c: ldr             x16, [fp, #0x10]
    // 0x63e0a0: stp             x16, x0, [SP, #-0x10]!
    // 0x63e0a4: r0 = computeDistanceToActualBaseline()
    //     0x63e0a4: bl              #0x63e234  ; [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::computeDistanceToActualBaseline
    // 0x63e0a8: add             SP, SP, #0x10
    // 0x63e0ac: LeaveFrame
    //     0x63e0ac: mov             SP, fp
    //     0x63e0b0: ldp             fp, lr, [SP], #0x10
    // 0x63e0b4: ret
    //     0x63e0b4: ret             
    // 0x63e0b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63e0b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63e0bc: b               #0x63e06c
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x68f854, size: 0x1dc
    // 0x68f854: EnterFrame
    //     0x68f854: stp             fp, lr, [SP, #-0x10]!
    //     0x68f858: mov             fp, SP
    // 0x68f85c: AllocStack(0x10)
    //     0x68f85c: sub             SP, SP, #0x10
    // 0x68f860: CheckStackOverflow
    //     0x68f860: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68f864: cmp             SP, x16
    //     0x68f868: b.ls            #0x68fa20
    // 0x68f86c: ldr             x3, [fp, #0x10]
    // 0x68f870: LoadField: r4 = r3->field_5f
    //     0x68f870: ldur            w4, [x3, #0x5f]
    // 0x68f874: DecompressPointer r4
    //     0x68f874: add             x4, x4, HEAP, lsl #32
    // 0x68f878: stur            x4, [fp, #-0x10]
    // 0x68f87c: cmp             w4, NULL
    // 0x68f880: b.eq            #0x68f950
    // 0x68f884: LoadField: r5 = r3->field_27
    //     0x68f884: ldur            w5, [x3, #0x27]
    // 0x68f888: DecompressPointer r5
    //     0x68f888: add             x5, x5, HEAP, lsl #32
    // 0x68f88c: stur            x5, [fp, #-8]
    // 0x68f890: cmp             w5, NULL
    // 0x68f894: b.eq            #0x68f9e0
    // 0x68f898: mov             x0, x5
    // 0x68f89c: r2 = Null
    //     0x68f89c: mov             x2, NULL
    // 0x68f8a0: r1 = Null
    //     0x68f8a0: mov             x1, NULL
    // 0x68f8a4: r4 = LoadClassIdInstr(r0)
    //     0x68f8a4: ldur            x4, [x0, #-1]
    //     0x68f8a8: ubfx            x4, x4, #0xc, #0x14
    // 0x68f8ac: sub             x4, x4, #0x80d
    // 0x68f8b0: cmp             x4, #1
    // 0x68f8b4: b.ls            #0x68f8cc
    // 0x68f8b8: r8 = BoxConstraints
    //     0x68f8b8: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x68f8bc: ldr             x8, [x8, #0x1d0]
    // 0x68f8c0: r3 = Null
    //     0x68f8c0: add             x3, PP, #0x28, lsl #12  ; [pp+0x28598] Null
    //     0x68f8c4: ldr             x3, [x3, #0x598]
    // 0x68f8c8: r0 = BoxConstraints()
    //     0x68f8c8: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x68f8cc: ldur            x0, [fp, #-0x10]
    // 0x68f8d0: r1 = LoadClassIdInstr(r0)
    //     0x68f8d0: ldur            x1, [x0, #-1]
    //     0x68f8d4: ubfx            x1, x1, #0xc, #0x14
    // 0x68f8d8: ldur            x16, [fp, #-8]
    // 0x68f8dc: stp             x16, x0, [SP, #-0x10]!
    // 0x68f8e0: r16 = true
    //     0x68f8e0: add             x16, NULL, #0x20  ; true
    // 0x68f8e4: SaveReg r16
    //     0x68f8e4: str             x16, [SP, #-8]!
    // 0x68f8e8: mov             x0, x1
    // 0x68f8ec: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x68f8ec: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x68f8f0: ldr             x4, [x4, #0x1c8]
    // 0x68f8f4: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x68f8f4: mov             x17, #0xcdfb
    //     0x68f8f8: add             lr, x0, x17
    //     0x68f8fc: ldr             lr, [x21, lr, lsl #3]
    //     0x68f900: blr             lr
    // 0x68f904: add             SP, SP, #0x18
    // 0x68f908: ldr             x3, [fp, #0x10]
    // 0x68f90c: LoadField: r0 = r3->field_5f
    //     0x68f90c: ldur            w0, [x3, #0x5f]
    // 0x68f910: DecompressPointer r0
    //     0x68f910: add             x0, x0, HEAP, lsl #32
    // 0x68f914: cmp             w0, NULL
    // 0x68f918: b.eq            #0x68fa28
    // 0x68f91c: LoadField: r1 = r0->field_57
    //     0x68f91c: ldur            w1, [x0, #0x57]
    // 0x68f920: DecompressPointer r1
    //     0x68f920: add             x1, x1, HEAP, lsl #32
    // 0x68f924: cmp             w1, NULL
    // 0x68f928: b.eq            #0x68fa2c
    // 0x68f92c: mov             x0, x1
    // 0x68f930: StoreField: r3->field_57 = r0
    //     0x68f930: stur            w0, [x3, #0x57]
    //     0x68f934: ldurb           w16, [x3, #-1]
    //     0x68f938: ldurb           w17, [x0, #-1]
    //     0x68f93c: and             x16, x17, x16, lsr #2
    //     0x68f940: tst             x16, HEAP, lsr #32
    //     0x68f944: b.eq            #0x68f94c
    //     0x68f948: bl              #0xd682ac
    // 0x68f94c: b               #0x68f9d0
    // 0x68f950: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68f950: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68f954: ldr             x0, [x0, #0x1e8]
    // 0x68f958: LoadField: r4 = r3->field_27
    //     0x68f958: ldur            w4, [x3, #0x27]
    // 0x68f95c: DecompressPointer r4
    //     0x68f95c: add             x4, x4, HEAP, lsl #32
    // 0x68f960: stur            x4, [fp, #-8]
    // 0x68f964: cmp             w4, NULL
    // 0x68f968: b.eq            #0x68fa00
    // 0x68f96c: mov             x0, x4
    // 0x68f970: r2 = Null
    //     0x68f970: mov             x2, NULL
    // 0x68f974: r1 = Null
    //     0x68f974: mov             x1, NULL
    // 0x68f978: r4 = LoadClassIdInstr(r0)
    //     0x68f978: ldur            x4, [x0, #-1]
    //     0x68f97c: ubfx            x4, x4, #0xc, #0x14
    // 0x68f980: sub             x4, x4, #0x80d
    // 0x68f984: cmp             x4, #1
    // 0x68f988: b.ls            #0x68f9a0
    // 0x68f98c: r8 = BoxConstraints
    //     0x68f98c: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x68f990: ldr             x8, [x8, #0x1d0]
    // 0x68f994: r3 = Null
    //     0x68f994: add             x3, PP, #0x28, lsl #12  ; [pp+0x285a8] Null
    //     0x68f998: ldr             x3, [x3, #0x5a8]
    // 0x68f99c: r0 = BoxConstraints()
    //     0x68f99c: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x68f9a0: ldur            x16, [fp, #-8]
    // 0x68f9a4: SaveReg r16
    //     0x68f9a4: str             x16, [SP, #-8]!
    // 0x68f9a8: r0 = smallest()
    //     0x68f9a8: bl              #0x62bd18  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0x68f9ac: add             SP, SP, #8
    // 0x68f9b0: ldr             x1, [fp, #0x10]
    // 0x68f9b4: StoreField: r1->field_57 = r0
    //     0x68f9b4: stur            w0, [x1, #0x57]
    //     0x68f9b8: ldurb           w16, [x1, #-1]
    //     0x68f9bc: ldurb           w17, [x0, #-1]
    //     0x68f9c0: and             x16, x17, x16, lsr #2
    //     0x68f9c4: tst             x16, HEAP, lsr #32
    //     0x68f9c8: b.eq            #0x68f9d0
    //     0x68f9cc: bl              #0xd6826c
    // 0x68f9d0: r0 = Null
    //     0x68f9d0: mov             x0, NULL
    // 0x68f9d4: LeaveFrame
    //     0x68f9d4: mov             SP, fp
    //     0x68f9d8: ldp             fp, lr, [SP], #0x10
    // 0x68f9dc: ret
    //     0x68f9dc: ret             
    // 0x68f9e0: r0 = StateError()
    //     0x68f9e0: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68f9e4: mov             x1, x0
    // 0x68f9e8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68f9e8: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68f9ec: ldr             x0, [x0, #0x1e8]
    // 0x68f9f0: StoreField: r1->field_b = r0
    //     0x68f9f0: stur            w0, [x1, #0xb]
    // 0x68f9f4: mov             x0, x1
    // 0x68f9f8: r0 = Throw()
    //     0x68f9f8: bl              #0xd67e38  ; ThrowStub
    // 0x68f9fc: brk             #0
    // 0x68fa00: r0 = StateError()
    //     0x68fa00: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68fa04: mov             x1, x0
    // 0x68fa08: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68fa08: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68fa0c: ldr             x0, [x0, #0x1e8]
    // 0x68fa10: StoreField: r1->field_b = r0
    //     0x68fa10: stur            w0, [x1, #0xb]
    // 0x68fa14: mov             x0, x1
    // 0x68fa18: r0 = Throw()
    //     0x68fa18: bl              #0xd67e38  ; ThrowStub
    // 0x68fa1c: brk             #0
    // 0x68fa20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68fa20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68fa24: b               #0x68f86c
    // 0x68fa28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68fa28: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68fa2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68fa2c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5d7b0, size: 0x68
    // 0xa5d7b0: EnterFrame
    //     0xa5d7b0: stp             fp, lr, [SP, #-0x10]!
    //     0xa5d7b4: mov             fp, SP
    // 0xa5d7b8: CheckStackOverflow
    //     0xa5d7b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5d7bc: cmp             SP, x16
    //     0xa5d7c0: b.ls            #0xa5d810
    // 0xa5d7c4: ldr             x0, [fp, #0x18]
    // 0xa5d7c8: LoadField: r1 = r0->field_5f
    //     0xa5d7c8: ldur            w1, [x0, #0x5f]
    // 0xa5d7cc: DecompressPointer r1
    //     0xa5d7cc: add             x1, x1, HEAP, lsl #32
    // 0xa5d7d0: cmp             w1, NULL
    // 0xa5d7d4: b.eq            #0xa5d7f4
    // 0xa5d7d8: ldr             x16, [fp, #0x10]
    // 0xa5d7dc: stp             x16, x1, [SP, #-0x10]!
    // 0xa5d7e0: r0 = getDryLayout()
    //     0xa5d7e0: bl              #0x62d394  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xa5d7e4: add             SP, SP, #0x10
    // 0xa5d7e8: LeaveFrame
    //     0xa5d7e8: mov             SP, fp
    //     0xa5d7ec: ldp             fp, lr, [SP], #0x10
    // 0xa5d7f0: ret
    //     0xa5d7f0: ret             
    // 0xa5d7f4: ldr             x16, [fp, #0x10]
    // 0xa5d7f8: SaveReg r16
    //     0xa5d7f8: str             x16, [SP, #-8]!
    // 0xa5d7fc: r0 = smallest()
    //     0xa5d7fc: bl              #0x62bd18  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xa5d800: add             SP, SP, #8
    // 0xa5d804: LeaveFrame
    //     0xa5d804: mov             SP, fp
    //     0xa5d808: ldp             fp, lr, [SP], #0x10
    // 0xa5d80c: ret
    //     0xa5d80c: ret             
    // 0xa5d810: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5d810: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5d814: b               #0xa5d7c4
  }
}

// class id: 2506, size: 0x74, field offset: 0x64
//   transformed mixin,
abstract class _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin&RenderAnimatedOpacityMixin extends _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin
     with RenderAnimatedOpacityMixin<X0 bound RenderObject> {

  _ paintsChild(/* No info */) {
    // ** addr: 0x6416a0, size: 0x7c
    // 0x6416a0: EnterFrame
    //     0x6416a0: stp             fp, lr, [SP, #-0x10]!
    //     0x6416a4: mov             fp, SP
    // 0x6416a8: CheckStackOverflow
    //     0x6416a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6416ac: cmp             SP, x16
    //     0x6416b0: b.ls            #0x641710
    // 0x6416b4: ldr             x0, [fp, #0x18]
    // 0x6416b8: LoadField: r1 = r0->field_6b
    //     0x6416b8: ldur            w1, [x0, #0x6b]
    // 0x6416bc: DecompressPointer r1
    //     0x6416bc: add             x1, x1, HEAP, lsl #32
    // 0x6416c0: cmp             w1, NULL
    // 0x6416c4: b.eq            #0x641718
    // 0x6416c8: r0 = LoadClassIdInstr(r1)
    //     0x6416c8: ldur            x0, [x1, #-1]
    //     0x6416cc: ubfx            x0, x0, #0xc, #0x14
    // 0x6416d0: SaveReg r1
    //     0x6416d0: str             x1, [SP, #-8]!
    // 0x6416d4: r0 = GDT[cid_x0 + 0xb7c]()
    //     0x6416d4: add             lr, x0, #0xb7c
    //     0x6416d8: ldr             lr, [x21, lr, lsl #3]
    //     0x6416dc: blr             lr
    // 0x6416e0: add             SP, SP, #8
    // 0x6416e4: LoadField: d0 = r0->field_7
    //     0x6416e4: ldur            d0, [x0, #7]
    // 0x6416e8: d1 = 0.000000
    //     0x6416e8: eor             v1.16b, v1.16b, v1.16b
    // 0x6416ec: fcmp            d0, d1
    // 0x6416f0: b.vs            #0x6416f8
    // 0x6416f4: b.gt            #0x641700
    // 0x6416f8: r0 = false
    //     0x6416f8: add             x0, NULL, #0x30  ; false
    // 0x6416fc: b               #0x641704
    // 0x641700: r0 = true
    //     0x641700: add             x0, NULL, #0x20  ; true
    // 0x641704: LeaveFrame
    //     0x641704: mov             SP, fp
    //     0x641708: ldp             fp, lr, [SP], #0x10
    // 0x64170c: ret
    //     0x64170c: ret             
    // 0x641710: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x641710: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x641714: b               #0x6416b4
    // 0x641718: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x641718: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0x661684, size: 0x64
    // 0x661684: EnterFrame
    //     0x661684: stp             fp, lr, [SP, #-0x10]!
    //     0x661688: mov             fp, SP
    // 0x66168c: CheckStackOverflow
    //     0x66168c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x661690: cmp             SP, x16
    //     0x661694: b.ls            #0x6616e0
    // 0x661698: ldr             x0, [fp, #0x20]
    // 0x66169c: LoadField: r1 = r0->field_63
    //     0x66169c: ldur            w1, [x0, #0x63]
    // 0x6616a0: DecompressPointer r1
    //     0x6616a0: add             x1, x1, HEAP, lsl #32
    // 0x6616a4: cbnz            w1, #0x6616b8
    // 0x6616a8: r0 = Null
    //     0x6616a8: mov             x0, NULL
    // 0x6616ac: LeaveFrame
    //     0x6616ac: mov             SP, fp
    //     0x6616b0: ldp             fp, lr, [SP], #0x10
    // 0x6616b4: ret
    //     0x6616b4: ret             
    // 0x6616b8: ldr             x16, [fp, #0x18]
    // 0x6616bc: stp             x16, x0, [SP, #-0x10]!
    // 0x6616c0: ldr             x16, [fp, #0x10]
    // 0x6616c4: SaveReg r16
    //     0x6616c4: str             x16, [SP, #-8]!
    // 0x6616c8: r0 = paint()
    //     0x6616c8: bl              #0x669ddc  ; [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::paint
    // 0x6616cc: add             SP, SP, #0x18
    // 0x6616d0: r0 = Null
    //     0x6616d0: mov             x0, NULL
    // 0x6616d4: LeaveFrame
    //     0x6616d4: mov             SP, fp
    //     0x6616d8: ldp             fp, lr, [SP], #0x10
    // 0x6616dc: ret
    //     0x6616dc: ret             
    // 0x6616e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6616e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6616e4: b               #0x661698
  }
  _ visitChildrenForSemantics(/* No info */) {
    // ** addr: 0x675cc0, size: 0x80
    // 0x675cc0: EnterFrame
    //     0x675cc0: stp             fp, lr, [SP, #-0x10]!
    //     0x675cc4: mov             fp, SP
    // 0x675cc8: CheckStackOverflow
    //     0x675cc8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x675ccc: cmp             SP, x16
    //     0x675cd0: b.ls            #0x675d34
    // 0x675cd4: ldr             x0, [fp, #0x18]
    // 0x675cd8: LoadField: r1 = r0->field_5f
    //     0x675cd8: ldur            w1, [x0, #0x5f]
    // 0x675cdc: DecompressPointer r1
    //     0x675cdc: add             x1, x1, HEAP, lsl #32
    // 0x675ce0: cmp             w1, NULL
    // 0x675ce4: b.eq            #0x675d24
    // 0x675ce8: LoadField: r2 = r0->field_63
    //     0x675ce8: ldur            w2, [x0, #0x63]
    // 0x675cec: DecompressPointer r2
    //     0x675cec: add             x2, x2, HEAP, lsl #32
    // 0x675cf0: cbnz            w2, #0x675d08
    // 0x675cf4: LoadField: r2 = r0->field_6f
    //     0x675cf4: ldur            w2, [x0, #0x6f]
    // 0x675cf8: DecompressPointer r2
    //     0x675cf8: add             x2, x2, HEAP, lsl #32
    // 0x675cfc: cmp             w2, NULL
    // 0x675d00: b.eq            #0x675d3c
    // 0x675d04: tbnz            w2, #4, #0x675d24
    // 0x675d08: ldr             x16, [fp, #0x10]
    // 0x675d0c: stp             x1, x16, [SP, #-0x10]!
    // 0x675d10: ldr             x0, [fp, #0x10]
    // 0x675d14: ClosureCall
    //     0x675d14: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x675d18: ldur            x2, [x0, #0x1f]
    //     0x675d1c: blr             x2
    // 0x675d20: add             SP, SP, #0x10
    // 0x675d24: r0 = Null
    //     0x675d24: mov             x0, NULL
    // 0x675d28: LeaveFrame
    //     0x675d28: mov             SP, fp
    //     0x675d2c: ldp             fp, lr, [SP], #0x10
    // 0x675d30: ret
    //     0x675d30: ret             
    // 0x675d34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x675d34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x675d38: b               #0x675cd4
    // 0x675d3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x675d3c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ updateCompositedLayer(/* No info */) {
    // ** addr: 0x6a4674, size: 0xbc
    // 0x6a4674: EnterFrame
    //     0x6a4674: stp             fp, lr, [SP, #-0x10]!
    //     0x6a4678: mov             fp, SP
    // 0x6a467c: AllocStack(0x8)
    //     0x6a467c: sub             SP, SP, #8
    // 0x6a4680: CheckStackOverflow
    //     0x6a4680: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6a4684: cmp             SP, x16
    //     0x6a4688: b.ls            #0x6a4728
    // 0x6a468c: ldr             x0, [fp, #0x10]
    // 0x6a4690: r2 = Null
    //     0x6a4690: mov             x2, NULL
    // 0x6a4694: r1 = Null
    //     0x6a4694: mov             x1, NULL
    // 0x6a4698: r4 = 59
    //     0x6a4698: mov             x4, #0x3b
    // 0x6a469c: branchIfSmi(r0, 0x6a46a8)
    //     0x6a469c: tbz             w0, #0, #0x6a46a8
    // 0x6a46a0: r4 = LoadClassIdInstr(r0)
    //     0x6a46a0: ldur            x4, [x0, #-1]
    //     0x6a46a4: ubfx            x4, x4, #0xc, #0x14
    // 0x6a46a8: cmp             x4, #0x957
    // 0x6a46ac: b.eq            #0x6a46c4
    // 0x6a46b0: r8 = OpacityLayer?
    //     0x6a46b0: add             x8, PP, #0x28, lsl #12  ; [pp+0x28568] Type: OpacityLayer?
    //     0x6a46b4: ldr             x8, [x8, #0x568]
    // 0x6a46b8: r3 = Null
    //     0x6a46b8: add             x3, PP, #0x28, lsl #12  ; [pp+0x28570] Null
    //     0x6a46bc: ldr             x3, [x3, #0x570]
    // 0x6a46c0: r0 = DefaultNullableTypeTest()
    //     0x6a46c0: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x6a46c4: ldr             x0, [fp, #0x10]
    // 0x6a46c8: cmp             w0, NULL
    // 0x6a46cc: b.ne            #0x6a46f8
    // 0x6a46d0: r0 = OpacityLayer()
    //     0x6a46d0: bl              #0x661624  ; AllocateOpacityLayerStub -> OpacityLayer (size=0x50)
    // 0x6a46d4: mov             x1, x0
    // 0x6a46d8: r0 = Instance_Offset
    //     0x6a46d8: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x6a46dc: stur            x1, [fp, #-8]
    // 0x6a46e0: StoreField: r1->field_47 = r0
    //     0x6a46e0: stur            w0, [x1, #0x47]
    // 0x6a46e4: SaveReg r1
    //     0x6a46e4: str             x1, [SP, #-8]!
    // 0x6a46e8: r0 = Layer()
    //     0x6a46e8: bl              #0x5bbe7c  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0x6a46ec: add             SP, SP, #8
    // 0x6a46f0: ldur            x1, [fp, #-8]
    // 0x6a46f4: b               #0x6a46fc
    // 0x6a46f8: mov             x1, x0
    // 0x6a46fc: ldr             x0, [fp, #0x18]
    // 0x6a4700: stur            x1, [fp, #-8]
    // 0x6a4704: LoadField: r2 = r0->field_63
    //     0x6a4704: ldur            w2, [x0, #0x63]
    // 0x6a4708: DecompressPointer r2
    //     0x6a4708: add             x2, x2, HEAP, lsl #32
    // 0x6a470c: stp             x2, x1, [SP, #-0x10]!
    // 0x6a4710: r0 = alpha=()
    //     0x6a4710: bl              #0x661234  ; [package:flutter/src/rendering/layer.dart] OpacityLayer::alpha=
    // 0x6a4714: add             SP, SP, #0x10
    // 0x6a4718: ldur            x0, [fp, #-8]
    // 0x6a471c: LeaveFrame
    //     0x6a471c: mov             SP, fp
    //     0x6a4720: ldp             fp, lr, [SP], #0x10
    // 0x6a4724: ret
    //     0x6a4724: ret             
    // 0x6a4728: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a4728: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a472c: b               #0x6a468c
  }
  get _ isRepaintBoundary(/* No info */) {
    // ** addr: 0x6c0be8, size: 0x48
    // 0x6c0be8: EnterFrame
    //     0x6c0be8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c0bec: mov             fp, SP
    // 0x6c0bf0: ldr             x1, [fp, #0x10]
    // 0x6c0bf4: LoadField: r2 = r1->field_5f
    //     0x6c0bf4: ldur            w2, [x1, #0x5f]
    // 0x6c0bf8: DecompressPointer r2
    //     0x6c0bf8: add             x2, x2, HEAP, lsl #32
    // 0x6c0bfc: cmp             w2, NULL
    // 0x6c0c00: b.eq            #0x6c0c1c
    // 0x6c0c04: LoadField: r2 = r1->field_67
    //     0x6c0c04: ldur            w2, [x1, #0x67]
    // 0x6c0c08: DecompressPointer r2
    //     0x6c0c08: add             x2, x2, HEAP, lsl #32
    // 0x6c0c0c: cmp             w2, NULL
    // 0x6c0c10: b.eq            #0x6c0c2c
    // 0x6c0c14: mov             x0, x2
    // 0x6c0c18: b               #0x6c0c20
    // 0x6c0c1c: r0 = false
    //     0x6c0c1c: add             x0, NULL, #0x30  ; false
    // 0x6c0c20: LeaveFrame
    //     0x6c0c20: mov             SP, fp
    //     0x6c0c24: ldp             fp, lr, [SP], #0x10
    // 0x6c0c28: ret
    //     0x6c0c28: ret             
    // 0x6c0c2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6c0c2c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ alwaysIncludeSemantics=(/* No info */) {
    // ** addr: 0x6c8eb8, size: 0x64
    // 0x6c8eb8: EnterFrame
    //     0x6c8eb8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c8ebc: mov             fp, SP
    // 0x6c8ec0: CheckStackOverflow
    //     0x6c8ec0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c8ec4: cmp             SP, x16
    //     0x6c8ec8: b.ls            #0x6c8f14
    // 0x6c8ecc: ldr             x0, [fp, #0x18]
    // 0x6c8ed0: LoadField: r1 = r0->field_6f
    //     0x6c8ed0: ldur            w1, [x0, #0x6f]
    // 0x6c8ed4: DecompressPointer r1
    //     0x6c8ed4: add             x1, x1, HEAP, lsl #32
    // 0x6c8ed8: ldr             x2, [fp, #0x10]
    // 0x6c8edc: cmp             w2, w1
    // 0x6c8ee0: b.ne            #0x6c8ef4
    // 0x6c8ee4: r0 = Null
    //     0x6c8ee4: mov             x0, NULL
    // 0x6c8ee8: LeaveFrame
    //     0x6c8ee8: mov             SP, fp
    //     0x6c8eec: ldp             fp, lr, [SP], #0x10
    // 0x6c8ef0: ret
    //     0x6c8ef0: ret             
    // 0x6c8ef4: StoreField: r0->field_6f = r2
    //     0x6c8ef4: stur            w2, [x0, #0x6f]
    // 0x6c8ef8: SaveReg r0
    //     0x6c8ef8: str             x0, [SP, #-8]!
    // 0x6c8efc: r0 = markNeedsSemanticsUpdate()
    //     0x6c8efc: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6c8f00: add             SP, SP, #8
    // 0x6c8f04: r0 = Null
    //     0x6c8f04: mov             x0, NULL
    // 0x6c8f08: LeaveFrame
    //     0x6c8f08: mov             SP, fp
    //     0x6c8f0c: ldp             fp, lr, [SP], #0x10
    // 0x6c8f10: ret
    //     0x6c8f10: ret             
    // 0x6c8f14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c8f14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c8f18: b               #0x6c8ecc
  }
  set _ opacity=(/* No info */) {
    // ** addr: 0x6c8f1c, size: 0x184
    // 0x6c8f1c: EnterFrame
    //     0x6c8f1c: stp             fp, lr, [SP, #-0x10]!
    //     0x6c8f20: mov             fp, SP
    // 0x6c8f24: AllocStack(0x8)
    //     0x6c8f24: sub             SP, SP, #8
    // 0x6c8f28: CheckStackOverflow
    //     0x6c8f28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c8f2c: cmp             SP, x16
    //     0x6c8f30: b.ls            #0x6c9098
    // 0x6c8f34: ldr             x1, [fp, #0x18]
    // 0x6c8f38: LoadField: r0 = r1->field_6b
    //     0x6c8f38: ldur            w0, [x1, #0x6b]
    // 0x6c8f3c: DecompressPointer r0
    //     0x6c8f3c: add             x0, x0, HEAP, lsl #32
    // 0x6c8f40: r2 = LoadClassIdInstr(r0)
    //     0x6c8f40: ldur            x2, [x0, #-1]
    //     0x6c8f44: ubfx            x2, x2, #0xc, #0x14
    // 0x6c8f48: ldr             x16, [fp, #0x10]
    // 0x6c8f4c: stp             x16, x0, [SP, #-0x10]!
    // 0x6c8f50: mov             x0, x2
    // 0x6c8f54: mov             lr, x0
    // 0x6c8f58: ldr             lr, [x21, lr, lsl #3]
    // 0x6c8f5c: blr             lr
    // 0x6c8f60: add             SP, SP, #0x10
    // 0x6c8f64: tbnz            w0, #4, #0x6c8f78
    // 0x6c8f68: r0 = Null
    //     0x6c8f68: mov             x0, NULL
    // 0x6c8f6c: LeaveFrame
    //     0x6c8f6c: mov             SP, fp
    //     0x6c8f70: ldp             fp, lr, [SP], #0x10
    // 0x6c8f74: ret
    //     0x6c8f74: ret             
    // 0x6c8f78: ldr             x0, [fp, #0x18]
    // 0x6c8f7c: LoadField: r1 = r0->field_f
    //     0x6c8f7c: ldur            w1, [x0, #0xf]
    // 0x6c8f80: DecompressPointer r1
    //     0x6c8f80: add             x1, x1, HEAP, lsl #32
    // 0x6c8f84: cmp             w1, NULL
    // 0x6c8f88: b.eq            #0x6c8ff0
    // 0x6c8f8c: LoadField: r1 = r0->field_6b
    //     0x6c8f8c: ldur            w1, [x0, #0x6b]
    // 0x6c8f90: DecompressPointer r1
    //     0x6c8f90: add             x1, x1, HEAP, lsl #32
    // 0x6c8f94: stur            x1, [fp, #-8]
    // 0x6c8f98: cmp             w1, NULL
    // 0x6c8f9c: b.eq            #0x6c8ff0
    // 0x6c8fa0: r1 = 1
    //     0x6c8fa0: mov             x1, #1
    // 0x6c8fa4: r0 = AllocateContext()
    //     0x6c8fa4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6c8fa8: mov             x1, x0
    // 0x6c8fac: ldr             x0, [fp, #0x18]
    // 0x6c8fb0: StoreField: r1->field_f = r0
    //     0x6c8fb0: stur            w0, [x1, #0xf]
    // 0x6c8fb4: mov             x2, x1
    // 0x6c8fb8: r1 = Function '_updateOpacity@907160605':.
    //     0x6c8fb8: add             x1, PP, #0x22, lsl #12  ; [pp+0x22918] AnonymousClosure: (0x6c9418), in [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin&RenderAnimatedOpacityMixin::_updateOpacity (0x6c90a0)
    //     0x6c8fbc: ldr             x1, [x1, #0x918]
    // 0x6c8fc0: r0 = AllocateClosure()
    //     0x6c8fc0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6c8fc4: mov             x1, x0
    // 0x6c8fc8: ldur            x0, [fp, #-8]
    // 0x6c8fcc: r2 = LoadClassIdInstr(r0)
    //     0x6c8fcc: ldur            x2, [x0, #-1]
    //     0x6c8fd0: ubfx            x2, x2, #0xc, #0x14
    // 0x6c8fd4: stp             x1, x0, [SP, #-0x10]!
    // 0x6c8fd8: mov             x0, x2
    // 0x6c8fdc: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0x6c8fdc: mov             x17, #0xc2d6
    //     0x6c8fe0: add             lr, x0, x17
    //     0x6c8fe4: ldr             lr, [x21, lr, lsl #3]
    //     0x6c8fe8: blr             lr
    // 0x6c8fec: add             SP, SP, #0x10
    // 0x6c8ff0: ldr             x1, [fp, #0x18]
    // 0x6c8ff4: ldr             x0, [fp, #0x10]
    // 0x6c8ff8: StoreField: r1->field_6b = r0
    //     0x6c8ff8: stur            w0, [x1, #0x6b]
    //     0x6c8ffc: ldurb           w16, [x1, #-1]
    //     0x6c9000: ldurb           w17, [x0, #-1]
    //     0x6c9004: and             x16, x17, x16, lsr #2
    //     0x6c9008: tst             x16, HEAP, lsr #32
    //     0x6c900c: b.eq            #0x6c9014
    //     0x6c9010: bl              #0xd6826c
    // 0x6c9014: LoadField: r0 = r1->field_f
    //     0x6c9014: ldur            w0, [x1, #0xf]
    // 0x6c9018: DecompressPointer r0
    //     0x6c9018: add             x0, x0, HEAP, lsl #32
    // 0x6c901c: cmp             w0, NULL
    // 0x6c9020: b.eq            #0x6c9078
    // 0x6c9024: ldr             x0, [fp, #0x10]
    // 0x6c9028: r1 = 1
    //     0x6c9028: mov             x1, #1
    // 0x6c902c: r0 = AllocateContext()
    //     0x6c902c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6c9030: mov             x1, x0
    // 0x6c9034: ldr             x0, [fp, #0x18]
    // 0x6c9038: StoreField: r1->field_f = r0
    //     0x6c9038: stur            w0, [x1, #0xf]
    // 0x6c903c: mov             x2, x1
    // 0x6c9040: r1 = Function '_updateOpacity@907160605':.
    //     0x6c9040: add             x1, PP, #0x22, lsl #12  ; [pp+0x22918] AnonymousClosure: (0x6c9418), in [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin&RenderAnimatedOpacityMixin::_updateOpacity (0x6c90a0)
    //     0x6c9044: ldr             x1, [x1, #0x918]
    // 0x6c9048: r0 = AllocateClosure()
    //     0x6c9048: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6c904c: mov             x1, x0
    // 0x6c9050: ldr             x0, [fp, #0x10]
    // 0x6c9054: r2 = LoadClassIdInstr(r0)
    //     0x6c9054: ldur            x2, [x0, #-1]
    //     0x6c9058: ubfx            x2, x2, #0xc, #0x14
    // 0x6c905c: stp             x1, x0, [SP, #-0x10]!
    // 0x6c9060: mov             x0, x2
    // 0x6c9064: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x6c9064: mov             x17, #0xc3ab
    //     0x6c9068: add             lr, x0, x17
    //     0x6c906c: ldr             lr, [x21, lr, lsl #3]
    //     0x6c9070: blr             lr
    // 0x6c9074: add             SP, SP, #0x10
    // 0x6c9078: ldr             x16, [fp, #0x18]
    // 0x6c907c: SaveReg r16
    //     0x6c907c: str             x16, [SP, #-8]!
    // 0x6c9080: r0 = _updateOpacity()
    //     0x6c9080: bl              #0x6c90a0  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin&RenderAnimatedOpacityMixin::_updateOpacity
    // 0x6c9084: add             SP, SP, #8
    // 0x6c9088: r0 = Null
    //     0x6c9088: mov             x0, NULL
    // 0x6c908c: LeaveFrame
    //     0x6c908c: mov             SP, fp
    //     0x6c9090: ldp             fp, lr, [SP], #0x10
    // 0x6c9094: ret
    //     0x6c9094: ret             
    // 0x6c9098: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c9098: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c909c: b               #0x6c8f34
  }
  _ _updateOpacity(/* No info */) {
    // ** addr: 0x6c90a0, size: 0x188
    // 0x6c90a0: EnterFrame
    //     0x6c90a0: stp             fp, lr, [SP, #-0x10]!
    //     0x6c90a4: mov             fp, SP
    // 0x6c90a8: AllocStack(0x8)
    //     0x6c90a8: sub             SP, SP, #8
    // 0x6c90ac: CheckStackOverflow
    //     0x6c90ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c90b0: cmp             SP, x16
    //     0x6c90b4: b.ls            #0x6c921c
    // 0x6c90b8: ldr             x1, [fp, #0x10]
    // 0x6c90bc: LoadField: r2 = r1->field_63
    //     0x6c90bc: ldur            w2, [x1, #0x63]
    // 0x6c90c0: DecompressPointer r2
    //     0x6c90c0: add             x2, x2, HEAP, lsl #32
    // 0x6c90c4: stur            x2, [fp, #-8]
    // 0x6c90c8: LoadField: r0 = r1->field_6b
    //     0x6c90c8: ldur            w0, [x1, #0x6b]
    // 0x6c90cc: DecompressPointer r0
    //     0x6c90cc: add             x0, x0, HEAP, lsl #32
    // 0x6c90d0: cmp             w0, NULL
    // 0x6c90d4: b.eq            #0x6c9224
    // 0x6c90d8: r3 = LoadClassIdInstr(r0)
    //     0x6c90d8: ldur            x3, [x0, #-1]
    //     0x6c90dc: ubfx            x3, x3, #0xc, #0x14
    // 0x6c90e0: SaveReg r0
    //     0x6c90e0: str             x0, [SP, #-8]!
    // 0x6c90e4: mov             x0, x3
    // 0x6c90e8: r0 = GDT[cid_x0 + 0xb7c]()
    //     0x6c90e8: add             lr, x0, #0xb7c
    //     0x6c90ec: ldr             lr, [x21, lr, lsl #3]
    //     0x6c90f0: blr             lr
    // 0x6c90f4: add             SP, SP, #8
    // 0x6c90f8: LoadField: d0 = r0->field_7
    //     0x6c90f8: ldur            d0, [x0, #7]
    // 0x6c90fc: SaveReg d0
    //     0x6c90fc: str             d0, [SP, #-8]!
    // 0x6c9100: r0 = getAlphaFromOpacity()
    //     0x6c9100: bl              #0x6c37cc  ; [dart:ui] Color::getAlphaFromOpacity
    // 0x6c9104: add             SP, SP, #8
    // 0x6c9108: mov             x2, x0
    // 0x6c910c: r0 = BoxInt64Instr(r2)
    //     0x6c910c: sbfiz           x0, x2, #1, #0x1f
    //     0x6c9110: cmp             x2, x0, asr #1
    //     0x6c9114: b.eq            #0x6c9120
    //     0x6c9118: bl              #0xd69bb8
    //     0x6c911c: stur            x2, [x0, #7]
    // 0x6c9120: mov             x3, x0
    // 0x6c9124: ldr             x1, [fp, #0x10]
    // 0x6c9128: StoreField: r1->field_63 = r0
    //     0x6c9128: stur            w0, [x1, #0x63]
    //     0x6c912c: tbz             w0, #0, #0x6c9148
    //     0x6c9130: ldurb           w16, [x1, #-1]
    //     0x6c9134: ldurb           w17, [x0, #-1]
    //     0x6c9138: and             x16, x17, x16, lsr #2
    //     0x6c913c: tst             x16, HEAP, lsr #32
    //     0x6c9140: b.eq            #0x6c9148
    //     0x6c9144: bl              #0xd6826c
    // 0x6c9148: ldur            x0, [fp, #-8]
    // 0x6c914c: cmp             w0, w3
    // 0x6c9150: b.eq            #0x6c920c
    // 0x6c9154: and             w16, w0, w3
    // 0x6c9158: branchIfSmi(r16, 0x6c918c)
    //     0x6c9158: tbz             w16, #0, #0x6c918c
    // 0x6c915c: r16 = LoadClassIdInstr(r0)
    //     0x6c915c: ldur            x16, [x0, #-1]
    //     0x6c9160: ubfx            x16, x16, #0xc, #0x14
    // 0x6c9164: cmp             x16, #0x3c
    // 0x6c9168: b.ne            #0x6c918c
    // 0x6c916c: r16 = LoadClassIdInstr(r3)
    //     0x6c916c: ldur            x16, [x3, #-1]
    //     0x6c9170: ubfx            x16, x16, #0xc, #0x14
    // 0x6c9174: cmp             x16, #0x3c
    // 0x6c9178: b.ne            #0x6c918c
    // 0x6c917c: LoadField: r16 = r0->field_7
    //     0x6c917c: ldur            x16, [x0, #7]
    // 0x6c9180: LoadField: r17 = r3->field_7
    //     0x6c9180: ldur            x17, [x3, #7]
    // 0x6c9184: cmp             x16, x17
    // 0x6c9188: b.eq            #0x6c920c
    // 0x6c918c: LoadField: r3 = r1->field_67
    //     0x6c918c: ldur            w3, [x1, #0x67]
    // 0x6c9190: DecompressPointer r3
    //     0x6c9190: add             x3, x3, HEAP, lsl #32
    // 0x6c9194: cmp             x2, #0
    // 0x6c9198: r16 = true
    //     0x6c9198: add             x16, NULL, #0x20  ; true
    // 0x6c919c: r17 = false
    //     0x6c919c: add             x17, NULL, #0x30  ; false
    // 0x6c91a0: csel            x4, x16, x17, gt
    // 0x6c91a4: StoreField: r1->field_67 = r4
    //     0x6c91a4: stur            w4, [x1, #0x67]
    // 0x6c91a8: LoadField: r2 = r1->field_5f
    //     0x6c91a8: ldur            w2, [x1, #0x5f]
    // 0x6c91ac: DecompressPointer r2
    //     0x6c91ac: add             x2, x2, HEAP, lsl #32
    // 0x6c91b0: cmp             w2, NULL
    // 0x6c91b4: b.eq            #0x6c91cc
    // 0x6c91b8: cmp             w3, w4
    // 0x6c91bc: b.eq            #0x6c91cc
    // 0x6c91c0: SaveReg r1
    //     0x6c91c0: str             x1, [SP, #-8]!
    // 0x6c91c4: r0 = markNeedsCompositingBitsUpdate()
    //     0x6c91c4: bl              #0x5e5c40  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsCompositingBitsUpdate
    // 0x6c91c8: add             SP, SP, #8
    // 0x6c91cc: ldur            x0, [fp, #-8]
    // 0x6c91d0: ldr             x16, [fp, #0x10]
    // 0x6c91d4: SaveReg r16
    //     0x6c91d4: str             x16, [SP, #-8]!
    // 0x6c91d8: r0 = markNeedsCompositedLayerUpdate()
    //     0x6c91d8: bl              #0x6c9228  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsCompositedLayerUpdate
    // 0x6c91dc: add             SP, SP, #8
    // 0x6c91e0: ldur            x0, [fp, #-8]
    // 0x6c91e4: cbnz            w0, #0x6c91f0
    // 0x6c91e8: ldr             x0, [fp, #0x10]
    // 0x6c91ec: b               #0x6c9200
    // 0x6c91f0: ldr             x0, [fp, #0x10]
    // 0x6c91f4: LoadField: r1 = r0->field_63
    //     0x6c91f4: ldur            w1, [x0, #0x63]
    // 0x6c91f8: DecompressPointer r1
    //     0x6c91f8: add             x1, x1, HEAP, lsl #32
    // 0x6c91fc: cbnz            w1, #0x6c920c
    // 0x6c9200: SaveReg r0
    //     0x6c9200: str             x0, [SP, #-8]!
    // 0x6c9204: r0 = markNeedsSemanticsUpdate()
    //     0x6c9204: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6c9208: add             SP, SP, #8
    // 0x6c920c: r0 = Null
    //     0x6c920c: mov             x0, NULL
    // 0x6c9210: LeaveFrame
    //     0x6c9210: mov             SP, fp
    //     0x6c9214: ldp             fp, lr, [SP], #0x10
    // 0x6c9218: ret
    //     0x6c9218: ret             
    // 0x6c921c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c921c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c9220: b               #0x6c90b8
    // 0x6c9224: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6c9224: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateOpacity(dynamic) {
    // ** addr: 0x6c9418, size: 0x48
    // 0x6c9418: EnterFrame
    //     0x6c9418: stp             fp, lr, [SP, #-0x10]!
    //     0x6c941c: mov             fp, SP
    // 0x6c9420: ldr             x0, [fp, #0x10]
    // 0x6c9424: LoadField: r1 = r0->field_17
    //     0x6c9424: ldur            w1, [x0, #0x17]
    // 0x6c9428: DecompressPointer r1
    //     0x6c9428: add             x1, x1, HEAP, lsl #32
    // 0x6c942c: CheckStackOverflow
    //     0x6c942c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c9430: cmp             SP, x16
    //     0x6c9434: b.ls            #0x6c9458
    // 0x6c9438: LoadField: r0 = r1->field_f
    //     0x6c9438: ldur            w0, [x1, #0xf]
    // 0x6c943c: DecompressPointer r0
    //     0x6c943c: add             x0, x0, HEAP, lsl #32
    // 0x6c9440: SaveReg r0
    //     0x6c9440: str             x0, [SP, #-8]!
    // 0x6c9444: r0 = _updateOpacity()
    //     0x6c9444: bl              #0x6c90a0  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin&RenderAnimatedOpacityMixin::_updateOpacity
    // 0x6c9448: add             SP, SP, #8
    // 0x6c944c: LeaveFrame
    //     0x6c944c: mov             SP, fp
    //     0x6c9450: ldp             fp, lr, [SP], #0x10
    // 0x6c9454: ret
    //     0x6c9454: ret             
    // 0x6c9458: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c9458: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c945c: b               #0x6c9438
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bd2ec, size: 0xf4
    // 0x9bd2ec: EnterFrame
    //     0x9bd2ec: stp             fp, lr, [SP, #-0x10]!
    //     0x9bd2f0: mov             fp, SP
    // 0x9bd2f4: AllocStack(0x8)
    //     0x9bd2f4: sub             SP, SP, #8
    // 0x9bd2f8: CheckStackOverflow
    //     0x9bd2f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bd2fc: cmp             SP, x16
    //     0x9bd300: b.ls            #0x9bd3d4
    // 0x9bd304: ldr             x0, [fp, #0x10]
    // 0x9bd308: r2 = Null
    //     0x9bd308: mov             x2, NULL
    // 0x9bd30c: r1 = Null
    //     0x9bd30c: mov             x1, NULL
    // 0x9bd310: r4 = 59
    //     0x9bd310: mov             x4, #0x3b
    // 0x9bd314: branchIfSmi(r0, 0x9bd320)
    //     0x9bd314: tbz             w0, #0, #0x9bd320
    // 0x9bd318: r4 = LoadClassIdInstr(r0)
    //     0x9bd318: ldur            x4, [x0, #-1]
    //     0x9bd31c: ubfx            x4, x4, #0xc, #0x14
    // 0x9bd320: cmp             x4, #0x7e6
    // 0x9bd324: b.eq            #0x9bd338
    // 0x9bd328: r8 = PipelineOwner
    //     0x9bd328: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9bd32c: r3 = Null
    //     0x9bd32c: add             x3, PP, #0x28, lsl #12  ; [pp+0x28558] Null
    //     0x9bd330: ldr             x3, [x3, #0x558]
    // 0x9bd334: r0 = DefaultTypeTest()
    //     0x9bd334: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bd338: ldr             x16, [fp, #0x18]
    // 0x9bd33c: ldr             lr, [fp, #0x10]
    // 0x9bd340: stp             lr, x16, [SP, #-0x10]!
    // 0x9bd344: r0 = attach()
    //     0x9bd344: bl              #0x9bd674  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::attach
    // 0x9bd348: add             SP, SP, #0x10
    // 0x9bd34c: ldr             x0, [fp, #0x18]
    // 0x9bd350: LoadField: r1 = r0->field_6b
    //     0x9bd350: ldur            w1, [x0, #0x6b]
    // 0x9bd354: DecompressPointer r1
    //     0x9bd354: add             x1, x1, HEAP, lsl #32
    // 0x9bd358: stur            x1, [fp, #-8]
    // 0x9bd35c: cmp             w1, NULL
    // 0x9bd360: b.eq            #0x9bd3dc
    // 0x9bd364: r1 = 1
    //     0x9bd364: mov             x1, #1
    // 0x9bd368: r0 = AllocateContext()
    //     0x9bd368: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9bd36c: mov             x1, x0
    // 0x9bd370: ldr             x0, [fp, #0x18]
    // 0x9bd374: StoreField: r1->field_f = r0
    //     0x9bd374: stur            w0, [x1, #0xf]
    // 0x9bd378: mov             x2, x1
    // 0x9bd37c: r1 = Function '_updateOpacity@907160605':.
    //     0x9bd37c: add             x1, PP, #0x22, lsl #12  ; [pp+0x22918] AnonymousClosure: (0x6c9418), in [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin&RenderAnimatedOpacityMixin::_updateOpacity (0x6c90a0)
    //     0x9bd380: ldr             x1, [x1, #0x918]
    // 0x9bd384: r0 = AllocateClosure()
    //     0x9bd384: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9bd388: mov             x1, x0
    // 0x9bd38c: ldur            x0, [fp, #-8]
    // 0x9bd390: r2 = LoadClassIdInstr(r0)
    //     0x9bd390: ldur            x2, [x0, #-1]
    //     0x9bd394: ubfx            x2, x2, #0xc, #0x14
    // 0x9bd398: stp             x1, x0, [SP, #-0x10]!
    // 0x9bd39c: mov             x0, x2
    // 0x9bd3a0: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x9bd3a0: mov             x17, #0xc3ab
    //     0x9bd3a4: add             lr, x0, x17
    //     0x9bd3a8: ldr             lr, [x21, lr, lsl #3]
    //     0x9bd3ac: blr             lr
    // 0x9bd3b0: add             SP, SP, #0x10
    // 0x9bd3b4: ldr             x16, [fp, #0x18]
    // 0x9bd3b8: SaveReg r16
    //     0x9bd3b8: str             x16, [SP, #-8]!
    // 0x9bd3bc: r0 = _updateOpacity()
    //     0x9bd3bc: bl              #0x6c90a0  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin&RenderAnimatedOpacityMixin::_updateOpacity
    // 0x9bd3c0: add             SP, SP, #8
    // 0x9bd3c4: r0 = Null
    //     0x9bd3c4: mov             x0, NULL
    // 0x9bd3c8: LeaveFrame
    //     0x9bd3c8: mov             SP, fp
    //     0x9bd3cc: ldp             fp, lr, [SP], #0x10
    // 0x9bd3d0: ret
    //     0x9bd3d0: ret             
    // 0x9bd3d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bd3d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bd3d8: b               #0x9bd304
    // 0x9bd3dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9bd3dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ detach(/* No info */) {
    // ** addr: 0xa69064, size: 0xac
    // 0xa69064: EnterFrame
    //     0xa69064: stp             fp, lr, [SP, #-0x10]!
    //     0xa69068: mov             fp, SP
    // 0xa6906c: AllocStack(0x8)
    //     0xa6906c: sub             SP, SP, #8
    // 0xa69070: CheckStackOverflow
    //     0xa69070: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa69074: cmp             SP, x16
    //     0xa69078: b.ls            #0xa69104
    // 0xa6907c: ldr             x0, [fp, #0x10]
    // 0xa69080: LoadField: r1 = r0->field_6b
    //     0xa69080: ldur            w1, [x0, #0x6b]
    // 0xa69084: DecompressPointer r1
    //     0xa69084: add             x1, x1, HEAP, lsl #32
    // 0xa69088: stur            x1, [fp, #-8]
    // 0xa6908c: cmp             w1, NULL
    // 0xa69090: b.eq            #0xa6910c
    // 0xa69094: r1 = 1
    //     0xa69094: mov             x1, #1
    // 0xa69098: r0 = AllocateContext()
    //     0xa69098: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa6909c: mov             x1, x0
    // 0xa690a0: ldr             x0, [fp, #0x10]
    // 0xa690a4: StoreField: r1->field_f = r0
    //     0xa690a4: stur            w0, [x1, #0xf]
    // 0xa690a8: mov             x2, x1
    // 0xa690ac: r1 = Function '_updateOpacity@907160605':.
    //     0xa690ac: add             x1, PP, #0x22, lsl #12  ; [pp+0x22918] AnonymousClosure: (0x6c9418), in [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin&RenderAnimatedOpacityMixin::_updateOpacity (0x6c90a0)
    //     0xa690b0: ldr             x1, [x1, #0x918]
    // 0xa690b4: r0 = AllocateClosure()
    //     0xa690b4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa690b8: mov             x1, x0
    // 0xa690bc: ldur            x0, [fp, #-8]
    // 0xa690c0: r2 = LoadClassIdInstr(r0)
    //     0xa690c0: ldur            x2, [x0, #-1]
    //     0xa690c4: ubfx            x2, x2, #0xc, #0x14
    // 0xa690c8: stp             x1, x0, [SP, #-0x10]!
    // 0xa690cc: mov             x0, x2
    // 0xa690d0: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0xa690d0: mov             x17, #0xc2d6
    //     0xa690d4: add             lr, x0, x17
    //     0xa690d8: ldr             lr, [x21, lr, lsl #3]
    //     0xa690dc: blr             lr
    // 0xa690e0: add             SP, SP, #0x10
    // 0xa690e4: ldr             x16, [fp, #0x10]
    // 0xa690e8: SaveReg r16
    //     0xa690e8: str             x16, [SP, #-8]!
    // 0xa690ec: r0 = detach()
    //     0xa690ec: bl              #0xa693e0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::detach
    // 0xa690f0: add             SP, SP, #8
    // 0xa690f4: r0 = Null
    //     0xa690f4: mov             x0, NULL
    // 0xa690f8: LeaveFrame
    //     0xa690f8: mov             SP, fp
    //     0xa690fc: ldp             fp, lr, [SP], #0x10
    // 0xa69100: ret
    //     0xa69100: ret             
    // 0xa69104: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa69104: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa69108: b               #0xa6907c
    // 0xa6910c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6910c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2507, size: 0x74, field offset: 0x74
class RenderAnimatedOpacity extends _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin&RenderAnimatedOpacityMixin {

  _ RenderAnimatedOpacity(/* No info */) {
    // ** addr: 0x6ed770, size: 0x88
    // 0x6ed770: EnterFrame
    //     0x6ed770: stp             fp, lr, [SP, #-0x10]!
    //     0x6ed774: mov             fp, SP
    // 0x6ed778: CheckStackOverflow
    //     0x6ed778: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ed77c: cmp             SP, x16
    //     0x6ed780: b.ls            #0x6ed7f0
    // 0x6ed784: ldr             x16, [fp, #0x20]
    // 0x6ed788: SaveReg r16
    //     0x6ed788: str             x16, [SP, #-8]!
    // 0x6ed78c: r0 = RenderObject()
    //     0x6ed78c: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6ed790: add             SP, SP, #8
    // 0x6ed794: ldr             x16, [fp, #0x20]
    // 0x6ed798: stp             NULL, x16, [SP, #-0x10]!
    // 0x6ed79c: r0 = child=()
    //     0x6ed79c: bl              #0x6e7da0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::child=
    // 0x6ed7a0: add             SP, SP, #0x10
    // 0x6ed7a4: ldr             x16, [fp, #0x20]
    // 0x6ed7a8: ldr             lr, [fp, #0x10]
    // 0x6ed7ac: stp             lr, x16, [SP, #-0x10]!
    // 0x6ed7b0: r0 = opacity=()
    //     0x6ed7b0: bl              #0x6c8f1c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin&RenderAnimatedOpacityMixin::opacity=
    // 0x6ed7b4: add             SP, SP, #0x10
    // 0x6ed7b8: ldr             x0, [fp, #0x20]
    // 0x6ed7bc: LoadField: r1 = r0->field_6f
    //     0x6ed7bc: ldur            w1, [x0, #0x6f]
    // 0x6ed7c0: DecompressPointer r1
    //     0x6ed7c0: add             x1, x1, HEAP, lsl #32
    // 0x6ed7c4: ldr             x2, [fp, #0x18]
    // 0x6ed7c8: cmp             w2, w1
    // 0x6ed7cc: b.eq            #0x6ed7e0
    // 0x6ed7d0: StoreField: r0->field_6f = r2
    //     0x6ed7d0: stur            w2, [x0, #0x6f]
    // 0x6ed7d4: SaveReg r0
    //     0x6ed7d4: str             x0, [SP, #-8]!
    // 0x6ed7d8: r0 = markNeedsSemanticsUpdate()
    //     0x6ed7d8: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6ed7dc: add             SP, SP, #8
    // 0x6ed7e0: r0 = Null
    //     0x6ed7e0: mov             x0, NULL
    // 0x6ed7e4: LeaveFrame
    //     0x6ed7e4: mov             SP, fp
    //     0x6ed7e8: ldp             fp, lr, [SP], #0x10
    // 0x6ed7ec: ret
    //     0x6ed7ec: ret             
    // 0x6ed7f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ed7f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ed7f4: b               #0x6ed784
  }
}

// class id: 2508, size: 0x78, field offset: 0x64
class RenderOpacity extends RenderProxyBox {

  _ paintsChild(/* No info */) {
    // ** addr: 0x641638, size: 0x68
    // 0x641638: EnterFrame
    //     0x641638: stp             fp, lr, [SP, #-0x10]!
    //     0x64163c: mov             fp, SP
    // 0x641640: ldr             x0, [fp, #0x10]
    // 0x641644: r2 = Null
    //     0x641644: mov             x2, NULL
    // 0x641648: r1 = Null
    //     0x641648: mov             x1, NULL
    // 0x64164c: r4 = 59
    //     0x64164c: mov             x4, #0x3b
    // 0x641650: branchIfSmi(r0, 0x64165c)
    //     0x641650: tbz             w0, #0, #0x64165c
    // 0x641654: r4 = LoadClassIdInstr(r0)
    //     0x641654: ldur            x4, [x0, #-1]
    //     0x641658: ubfx            x4, x4, #0xc, #0x14
    // 0x64165c: sub             x4, x4, #0x965
    // 0x641660: cmp             x4, #0x8b
    // 0x641664: b.ls            #0x64167c
    // 0x641668: r8 = RenderBox
    //     0x641668: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x64166c: ldr             x8, [x8, #0xfa0]
    // 0x641670: r3 = Null
    //     0x641670: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3fc38] Null
    //     0x641674: ldr             x3, [x3, #0xc38]
    // 0x641678: r0 = RenderBox()
    //     0x641678: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x64167c: ldr             x1, [fp, #0x18]
    // 0x641680: LoadField: r2 = r1->field_63
    //     0x641680: ldur            x2, [x1, #0x63]
    // 0x641684: cmp             x2, #0
    // 0x641688: r16 = true
    //     0x641688: add             x16, NULL, #0x20  ; true
    // 0x64168c: r17 = false
    //     0x64168c: add             x17, NULL, #0x30  ; false
    // 0x641690: csel            x0, x16, x17, gt
    // 0x641694: LeaveFrame
    //     0x641694: mov             SP, fp
    //     0x641698: ldp             fp, lr, [SP], #0x10
    // 0x64169c: ret
    //     0x64169c: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0x660ffc, size: 0x128
    // 0x660ffc: EnterFrame
    //     0x660ffc: stp             fp, lr, [SP, #-0x10]!
    //     0x661000: mov             fp, SP
    // 0x661004: AllocStack(0x20)
    //     0x661004: sub             SP, SP, #0x20
    // 0x661008: CheckStackOverflow
    //     0x661008: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66100c: cmp             SP, x16
    //     0x661010: b.ls            #0x66111c
    // 0x661014: ldr             x0, [fp, #0x20]
    // 0x661018: LoadField: r1 = r0->field_5f
    //     0x661018: ldur            w1, [x0, #0x5f]
    // 0x66101c: DecompressPointer r1
    //     0x66101c: add             x1, x1, HEAP, lsl #32
    // 0x661020: cmp             w1, NULL
    // 0x661024: b.ne            #0x661038
    // 0x661028: r0 = Null
    //     0x661028: mov             x0, NULL
    // 0x66102c: LeaveFrame
    //     0x66102c: mov             SP, fp
    //     0x661030: ldp             fp, lr, [SP], #0x10
    // 0x661034: ret
    //     0x661034: ret             
    // 0x661038: LoadField: r1 = r0->field_63
    //     0x661038: ldur            x1, [x0, #0x63]
    // 0x66103c: stur            x1, [fp, #-8]
    // 0x661040: cbnz            x1, #0x661068
    // 0x661044: LoadField: r1 = r0->field_2f
    //     0x661044: ldur            w1, [x0, #0x2f]
    // 0x661048: DecompressPointer r1
    //     0x661048: add             x1, x1, HEAP, lsl #32
    // 0x66104c: stp             NULL, x1, [SP, #-0x10]!
    // 0x661050: r0 = layer=()
    //     0x661050: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x661054: add             SP, SP, #0x10
    // 0x661058: r0 = Null
    //     0x661058: mov             x0, NULL
    // 0x66105c: LeaveFrame
    //     0x66105c: mov             SP, fp
    //     0x661060: ldp             fp, lr, [SP], #0x10
    // 0x661064: ret
    //     0x661064: ret             
    // 0x661068: r1 = 1
    //     0x661068: mov             x1, #1
    // 0x66106c: r0 = AllocateContext()
    //     0x66106c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x661070: mov             x3, x0
    // 0x661074: ldr             x0, [fp, #0x20]
    // 0x661078: stur            x3, [fp, #-0x20]
    // 0x66107c: StoreField: r3->field_f = r0
    //     0x66107c: stur            w0, [x3, #0xf]
    // 0x661080: LoadField: r4 = r0->field_2f
    //     0x661080: ldur            w4, [x0, #0x2f]
    // 0x661084: DecompressPointer r4
    //     0x661084: add             x4, x4, HEAP, lsl #32
    // 0x661088: stur            x4, [fp, #-0x18]
    // 0x66108c: LoadField: r5 = r4->field_b
    //     0x66108c: ldur            w5, [x4, #0xb]
    // 0x661090: DecompressPointer r5
    //     0x661090: add             x5, x5, HEAP, lsl #32
    // 0x661094: mov             x0, x5
    // 0x661098: stur            x5, [fp, #-0x10]
    // 0x66109c: r2 = Null
    //     0x66109c: mov             x2, NULL
    // 0x6610a0: r1 = Null
    //     0x6610a0: mov             x1, NULL
    // 0x6610a4: r4 = LoadClassIdInstr(r0)
    //     0x6610a4: ldur            x4, [x0, #-1]
    //     0x6610a8: ubfx            x4, x4, #0xc, #0x14
    // 0x6610ac: cmp             x4, #0x957
    // 0x6610b0: b.eq            #0x6610c8
    // 0x6610b4: r8 = OpacityLayer?
    //     0x6610b4: add             x8, PP, #0x28, lsl #12  ; [pp+0x28568] Type: OpacityLayer?
    //     0x6610b8: ldr             x8, [x8, #0x568]
    // 0x6610bc: r3 = Null
    //     0x6610bc: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3fc28] Null
    //     0x6610c0: ldr             x3, [x3, #0xc28]
    // 0x6610c4: r0 = DefaultNullableTypeTest()
    //     0x6610c4: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x6610c8: ldur            x2, [fp, #-0x20]
    // 0x6610cc: r1 = Function 'paint':.
    //     0x6610cc: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cef0] AnonymousClosure: (0x661630), in [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::paint (0x669ddc)
    //     0x6610d0: ldr             x1, [x1, #0xef0]
    // 0x6610d4: r0 = AllocateClosure()
    //     0x6610d4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6610d8: ldr             x16, [fp, #0x18]
    // 0x6610dc: ldr             lr, [fp, #0x10]
    // 0x6610e0: stp             lr, x16, [SP, #-0x10]!
    // 0x6610e4: ldur            x1, [fp, #-8]
    // 0x6610e8: stp             x0, x1, [SP, #-0x10]!
    // 0x6610ec: ldur            x16, [fp, #-0x10]
    // 0x6610f0: SaveReg r16
    //     0x6610f0: str             x16, [SP, #-8]!
    // 0x6610f4: r0 = pushOpacity()
    //     0x6610f4: bl              #0x66116c  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushOpacity
    // 0x6610f8: add             SP, SP, #0x28
    // 0x6610fc: ldur            x16, [fp, #-0x18]
    // 0x661100: stp             x0, x16, [SP, #-0x10]!
    // 0x661104: r0 = layer=()
    //     0x661104: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x661108: add             SP, SP, #0x10
    // 0x66110c: r0 = Null
    //     0x66110c: mov             x0, NULL
    // 0x661110: LeaveFrame
    //     0x661110: mov             SP, fp
    //     0x661114: ldp             fp, lr, [SP], #0x10
    // 0x661118: ret
    //     0x661118: ret             
    // 0x66111c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66111c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x661120: b               #0x661014
  }
  get _ alwaysNeedsCompositing(/* No info */) {
    // ** addr: 0x675acc, size: 0x38
    // 0x675acc: ldr             x1, [SP]
    // 0x675ad0: LoadField: r2 = r1->field_5f
    //     0x675ad0: ldur            w2, [x1, #0x5f]
    // 0x675ad4: DecompressPointer r2
    //     0x675ad4: add             x2, x2, HEAP, lsl #32
    // 0x675ad8: cmp             w2, NULL
    // 0x675adc: b.eq            #0x675afc
    // 0x675ae0: LoadField: r2 = r1->field_63
    //     0x675ae0: ldur            x2, [x1, #0x63]
    // 0x675ae4: cmp             x2, #0
    // 0x675ae8: r16 = true
    //     0x675ae8: add             x16, NULL, #0x20  ; true
    // 0x675aec: r17 = false
    //     0x675aec: add             x17, NULL, #0x30  ; false
    // 0x675af0: csel            x1, x16, x17, gt
    // 0x675af4: mov             x0, x1
    // 0x675af8: b               #0x675b00
    // 0x675afc: r0 = false
    //     0x675afc: add             x0, NULL, #0x30  ; false
    // 0x675b00: ret
    //     0x675b00: ret             
  }
  _ visitChildrenForSemantics(/* No info */) {
    // ** addr: 0x675c50, size: 0x70
    // 0x675c50: EnterFrame
    //     0x675c50: stp             fp, lr, [SP, #-0x10]!
    //     0x675c54: mov             fp, SP
    // 0x675c58: CheckStackOverflow
    //     0x675c58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x675c5c: cmp             SP, x16
    //     0x675c60: b.ls            #0x675cb8
    // 0x675c64: ldr             x0, [fp, #0x18]
    // 0x675c68: LoadField: r1 = r0->field_5f
    //     0x675c68: ldur            w1, [x0, #0x5f]
    // 0x675c6c: DecompressPointer r1
    //     0x675c6c: add             x1, x1, HEAP, lsl #32
    // 0x675c70: cmp             w1, NULL
    // 0x675c74: b.eq            #0x675ca8
    // 0x675c78: LoadField: r2 = r0->field_63
    //     0x675c78: ldur            x2, [x0, #0x63]
    // 0x675c7c: cbnz            x2, #0x675c8c
    // 0x675c80: LoadField: r2 = r0->field_73
    //     0x675c80: ldur            w2, [x0, #0x73]
    // 0x675c84: DecompressPointer r2
    //     0x675c84: add             x2, x2, HEAP, lsl #32
    // 0x675c88: tbnz            w2, #4, #0x675ca8
    // 0x675c8c: ldr             x16, [fp, #0x10]
    // 0x675c90: stp             x1, x16, [SP, #-0x10]!
    // 0x675c94: ldr             x0, [fp, #0x10]
    // 0x675c98: ClosureCall
    //     0x675c98: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x675c9c: ldur            x2, [x0, #0x1f]
    //     0x675ca0: blr             x2
    // 0x675ca4: add             SP, SP, #0x10
    // 0x675ca8: r0 = Null
    //     0x675ca8: mov             x0, NULL
    // 0x675cac: LeaveFrame
    //     0x675cac: mov             SP, fp
    //     0x675cb0: ldp             fp, lr, [SP], #0x10
    // 0x675cb4: ret
    //     0x675cb4: ret             
    // 0x675cb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x675cb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x675cbc: b               #0x675c64
  }
  set _ alwaysIncludeSemantics=(/* No info */) {
    // ** addr: 0x6c3630, size: 0x64
    // 0x6c3630: EnterFrame
    //     0x6c3630: stp             fp, lr, [SP, #-0x10]!
    //     0x6c3634: mov             fp, SP
    // 0x6c3638: CheckStackOverflow
    //     0x6c3638: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c363c: cmp             SP, x16
    //     0x6c3640: b.ls            #0x6c368c
    // 0x6c3644: ldr             x0, [fp, #0x18]
    // 0x6c3648: LoadField: r1 = r0->field_73
    //     0x6c3648: ldur            w1, [x0, #0x73]
    // 0x6c364c: DecompressPointer r1
    //     0x6c364c: add             x1, x1, HEAP, lsl #32
    // 0x6c3650: ldr             x2, [fp, #0x10]
    // 0x6c3654: cmp             w2, w1
    // 0x6c3658: b.ne            #0x6c366c
    // 0x6c365c: r0 = Null
    //     0x6c365c: mov             x0, NULL
    // 0x6c3660: LeaveFrame
    //     0x6c3660: mov             SP, fp
    //     0x6c3664: ldp             fp, lr, [SP], #0x10
    // 0x6c3668: ret
    //     0x6c3668: ret             
    // 0x6c366c: StoreField: r0->field_73 = r2
    //     0x6c366c: stur            w2, [x0, #0x73]
    // 0x6c3670: SaveReg r0
    //     0x6c3670: str             x0, [SP, #-8]!
    // 0x6c3674: r0 = markNeedsSemanticsUpdate()
    //     0x6c3674: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6c3678: add             SP, SP, #8
    // 0x6c367c: r0 = Null
    //     0x6c367c: mov             x0, NULL
    // 0x6c3680: LeaveFrame
    //     0x6c3680: mov             SP, fp
    //     0x6c3684: ldp             fp, lr, [SP], #0x10
    // 0x6c3688: ret
    //     0x6c3688: ret             
    // 0x6c368c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c368c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c3690: b               #0x6c3644
  }
  set _ opacity=(/* No info */) {
    // ** addr: 0x6c3694, size: 0x138
    // 0x6c3694: EnterFrame
    //     0x6c3694: stp             fp, lr, [SP, #-0x10]!
    //     0x6c3698: mov             fp, SP
    // 0x6c369c: AllocStack(0x10)
    //     0x6c369c: sub             SP, SP, #0x10
    // 0x6c36a0: CheckStackOverflow
    //     0x6c36a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c36a4: cmp             SP, x16
    //     0x6c36a8: b.ls            #0x6c37c4
    // 0x6c36ac: ldr             x0, [fp, #0x18]
    // 0x6c36b0: LoadField: d0 = r0->field_6b
    //     0x6c36b0: ldur            d0, [x0, #0x6b]
    // 0x6c36b4: ldr             d1, [fp, #0x10]
    // 0x6c36b8: fcmp            d0, d1
    // 0x6c36bc: b.vs            #0x6c36d4
    // 0x6c36c0: b.ne            #0x6c36d4
    // 0x6c36c4: r0 = Null
    //     0x6c36c4: mov             x0, NULL
    // 0x6c36c8: LeaveFrame
    //     0x6c36c8: mov             SP, fp
    //     0x6c36cc: ldp             fp, lr, [SP], #0x10
    // 0x6c36d0: ret
    //     0x6c36d0: ret             
    // 0x6c36d4: SaveReg r0
    //     0x6c36d4: str             x0, [SP, #-8]!
    // 0x6c36d8: r0 = alwaysNeedsCompositing()
    //     0x6c36d8: bl              #0x675acc  ; [package:flutter/src/rendering/proxy_box.dart] RenderOpacity::alwaysNeedsCompositing
    // 0x6c36dc: add             SP, SP, #8
    // 0x6c36e0: mov             x1, x0
    // 0x6c36e4: ldr             x0, [fp, #0x18]
    // 0x6c36e8: stur            x1, [fp, #-0x10]
    // 0x6c36ec: LoadField: r2 = r0->field_63
    //     0x6c36ec: ldur            x2, [x0, #0x63]
    // 0x6c36f0: cbnz            x2, #0x6c36fc
    // 0x6c36f4: r3 = false
    //     0x6c36f4: add             x3, NULL, #0x30  ; false
    // 0x6c36f8: b               #0x6c3700
    // 0x6c36fc: r3 = true
    //     0x6c36fc: add             x3, NULL, #0x20  ; true
    // 0x6c3700: ldr             d0, [fp, #0x10]
    // 0x6c3704: stur            x3, [fp, #-8]
    // 0x6c3708: StoreField: r0->field_6b = d0
    //     0x6c3708: stur            d0, [x0, #0x6b]
    // 0x6c370c: SaveReg d0
    //     0x6c370c: str             d0, [SP, #-8]!
    // 0x6c3710: r0 = getAlphaFromOpacity()
    //     0x6c3710: bl              #0x6c37cc  ; [dart:ui] Color::getAlphaFromOpacity
    // 0x6c3714: add             SP, SP, #8
    // 0x6c3718: mov             x1, x0
    // 0x6c371c: ldr             x0, [fp, #0x18]
    // 0x6c3720: StoreField: r0->field_63 = r1
    //     0x6c3720: stur            x1, [x0, #0x63]
    // 0x6c3724: LoadField: r2 = r0->field_5f
    //     0x6c3724: ldur            w2, [x0, #0x5f]
    // 0x6c3728: DecompressPointer r2
    //     0x6c3728: add             x2, x2, HEAP, lsl #32
    // 0x6c372c: cmp             w2, NULL
    // 0x6c3730: b.eq            #0x6c3748
    // 0x6c3734: cmp             x1, #0
    // 0x6c3738: r16 = true
    //     0x6c3738: add             x16, NULL, #0x20  ; true
    // 0x6c373c: r17 = false
    //     0x6c373c: add             x17, NULL, #0x30  ; false
    // 0x6c3740: csel            x2, x16, x17, gt
    // 0x6c3744: b               #0x6c374c
    // 0x6c3748: r2 = false
    //     0x6c3748: add             x2, NULL, #0x30  ; false
    // 0x6c374c: ldur            x1, [fp, #-0x10]
    // 0x6c3750: cmp             w1, w2
    // 0x6c3754: b.eq            #0x6c3764
    // 0x6c3758: SaveReg r0
    //     0x6c3758: str             x0, [SP, #-8]!
    // 0x6c375c: r0 = markNeedsCompositingBitsUpdate()
    //     0x6c375c: bl              #0x5e5c40  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsCompositingBitsUpdate
    // 0x6c3760: add             SP, SP, #8
    // 0x6c3764: ldr             x0, [fp, #0x18]
    // 0x6c3768: ldur            x1, [fp, #-8]
    // 0x6c376c: SaveReg r0
    //     0x6c376c: str             x0, [SP, #-8]!
    // 0x6c3770: r0 = markNeedsPaint()
    //     0x6c3770: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c3774: add             SP, SP, #8
    // 0x6c3778: ldr             x0, [fp, #0x18]
    // 0x6c377c: LoadField: r1 = r0->field_63
    //     0x6c377c: ldur            x1, [x0, #0x63]
    // 0x6c3780: cbnz            x1, #0x6c378c
    // 0x6c3784: r2 = false
    //     0x6c3784: add             x2, NULL, #0x30  ; false
    // 0x6c3788: b               #0x6c3790
    // 0x6c378c: r2 = true
    //     0x6c378c: add             x2, NULL, #0x20  ; true
    // 0x6c3790: ldur            x1, [fp, #-8]
    // 0x6c3794: cmp             w1, w2
    // 0x6c3798: b.eq            #0x6c37b4
    // 0x6c379c: LoadField: r1 = r0->field_73
    //     0x6c379c: ldur            w1, [x0, #0x73]
    // 0x6c37a0: DecompressPointer r1
    //     0x6c37a0: add             x1, x1, HEAP, lsl #32
    // 0x6c37a4: tbz             w1, #4, #0x6c37b4
    // 0x6c37a8: SaveReg r0
    //     0x6c37a8: str             x0, [SP, #-8]!
    // 0x6c37ac: r0 = markNeedsSemanticsUpdate()
    //     0x6c37ac: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6c37b0: add             SP, SP, #8
    // 0x6c37b4: r0 = Null
    //     0x6c37b4: mov             x0, NULL
    // 0x6c37b8: LeaveFrame
    //     0x6c37b8: mov             SP, fp
    //     0x6c37bc: ldp             fp, lr, [SP], #0x10
    // 0x6c37c0: ret
    //     0x6c37c0: ret             
    // 0x6c37c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c37c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c37c8: b               #0x6c36ac
  }
  _ RenderOpacity(/* No info */) {
    // ** addr: 0x6ead20, size: 0x74
    // 0x6ead20: EnterFrame
    //     0x6ead20: stp             fp, lr, [SP, #-0x10]!
    //     0x6ead24: mov             fp, SP
    // 0x6ead28: CheckStackOverflow
    //     0x6ead28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ead2c: cmp             SP, x16
    //     0x6ead30: b.ls            #0x6ead8c
    // 0x6ead34: ldr             x0, [fp, #0x20]
    // 0x6ead38: ldr             d0, [fp, #0x10]
    // 0x6ead3c: StoreField: r0->field_6b = d0
    //     0x6ead3c: stur            d0, [x0, #0x6b]
    // 0x6ead40: ldr             x1, [fp, #0x18]
    // 0x6ead44: StoreField: r0->field_73 = r1
    //     0x6ead44: stur            w1, [x0, #0x73]
    // 0x6ead48: SaveReg d0
    //     0x6ead48: str             d0, [SP, #-8]!
    // 0x6ead4c: r0 = getAlphaFromOpacity()
    //     0x6ead4c: bl              #0x6c37cc  ; [dart:ui] Color::getAlphaFromOpacity
    // 0x6ead50: add             SP, SP, #8
    // 0x6ead54: mov             x1, x0
    // 0x6ead58: ldr             x0, [fp, #0x20]
    // 0x6ead5c: StoreField: r0->field_63 = r1
    //     0x6ead5c: stur            x1, [x0, #0x63]
    // 0x6ead60: SaveReg r0
    //     0x6ead60: str             x0, [SP, #-8]!
    // 0x6ead64: r0 = RenderObject()
    //     0x6ead64: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6ead68: add             SP, SP, #8
    // 0x6ead6c: ldr             x16, [fp, #0x20]
    // 0x6ead70: stp             NULL, x16, [SP, #-0x10]!
    // 0x6ead74: r0 = child=()
    //     0x6ead74: bl              #0x6e7da0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::child=
    // 0x6ead78: add             SP, SP, #0x10
    // 0x6ead7c: r0 = Null
    //     0x6ead7c: mov             x0, NULL
    // 0x6ead80: LeaveFrame
    //     0x6ead80: mov             SP, fp
    //     0x6ead84: ldp             fp, lr, [SP], #0x10
    // 0x6ead88: ret
    //     0x6ead88: ret             
    // 0x6ead8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ead8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ead90: b               #0x6ead34
  }
}

// class id: 2510, size: 0x6c, field offset: 0x64
class RenderIntrinsicWidth extends RenderProxyBox {

  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x62ec8c, size: 0x18
    // 0x62ec8c: r4 = 0
    //     0x62ec8c: mov             x4, #0
    // 0x62ec90: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x62ec90: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b270] AnonymousClosure: (0x62eca4), in [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::computeMaxIntrinsicHeight (0x62ecf0)
    //     0x62ec94: ldr             x1, [x17, #0x270]
    // 0x62ec98: r24 = BuildNonGenericMethodExtractorStub
    //     0x62ec98: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x62ec9c: LoadField: r0 = r24->field_17
    //     0x62ec9c: ldur            x0, [x24, #0x17]
    // 0x62eca0: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x62eca4, size: 0x4c
    // 0x62eca4: EnterFrame
    //     0x62eca4: stp             fp, lr, [SP, #-0x10]!
    //     0x62eca8: mov             fp, SP
    // 0x62ecac: ldr             x0, [fp, #0x18]
    // 0x62ecb0: LoadField: r1 = r0->field_17
    //     0x62ecb0: ldur            w1, [x0, #0x17]
    // 0x62ecb4: DecompressPointer r1
    //     0x62ecb4: add             x1, x1, HEAP, lsl #32
    // 0x62ecb8: CheckStackOverflow
    //     0x62ecb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62ecbc: cmp             SP, x16
    //     0x62ecc0: b.ls            #0x62ece8
    // 0x62ecc4: LoadField: r0 = r1->field_f
    //     0x62ecc4: ldur            w0, [x1, #0xf]
    // 0x62ecc8: DecompressPointer r0
    //     0x62ecc8: add             x0, x0, HEAP, lsl #32
    // 0x62eccc: ldr             x16, [fp, #0x10]
    // 0x62ecd0: stp             x16, x0, [SP, #-0x10]!
    // 0x62ecd4: r0 = computeMaxIntrinsicHeight()
    //     0x62ecd4: bl              #0x62ecf0  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::computeMaxIntrinsicHeight
    // 0x62ecd8: add             SP, SP, #0x10
    // 0x62ecdc: LeaveFrame
    //     0x62ecdc: mov             SP, fp
    //     0x62ece0: ldp             fp, lr, [SP], #0x10
    // 0x62ece4: ret
    //     0x62ece4: ret             
    // 0x62ece8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62ece8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62ecec: b               #0x62ecc4
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0x62ecf0, size: 0xf0
    // 0x62ecf0: EnterFrame
    //     0x62ecf0: stp             fp, lr, [SP, #-0x10]!
    //     0x62ecf4: mov             fp, SP
    // 0x62ecf8: CheckStackOverflow
    //     0x62ecf8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62ecfc: cmp             SP, x16
    //     0x62ed00: b.ls            #0x62edc4
    // 0x62ed04: ldr             x0, [fp, #0x18]
    // 0x62ed08: LoadField: r1 = r0->field_5f
    //     0x62ed08: ldur            w1, [x0, #0x5f]
    // 0x62ed0c: DecompressPointer r1
    //     0x62ed0c: add             x1, x1, HEAP, lsl #32
    // 0x62ed10: cmp             w1, NULL
    // 0x62ed14: b.ne            #0x62ed28
    // 0x62ed18: r0 = 0.000000
    //     0x62ed18: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x62ed1c: LeaveFrame
    //     0x62ed1c: mov             SP, fp
    //     0x62ed20: ldp             fp, lr, [SP], #0x10
    // 0x62ed24: ret
    //     0x62ed24: ret             
    // 0x62ed28: ldr             x1, [fp, #0x10]
    // 0x62ed2c: LoadField: d0 = r1->field_7
    //     0x62ed2c: ldur            d0, [x1, #7]
    // 0x62ed30: mov             x2, v0.d[0]
    // 0x62ed34: and             x2, x2, #0x7fffffffffffffff
    // 0x62ed38: r17 = 9218868437227405312
    //     0x62ed38: mov             x17, #0x7ff0000000000000
    // 0x62ed3c: cmp             x2, x17
    // 0x62ed40: b.eq            #0x62ed54
    // 0x62ed44: fcmp            d0, d0
    // 0x62ed48: b.vs            #0x62ed54
    // 0x62ed4c: LoadField: d0 = r1->field_7
    //     0x62ed4c: ldur            d0, [x1, #7]
    // 0x62ed50: b               #0x62ed70
    // 0x62ed54: r16 = inf
    //     0x62ed54: add             x16, PP, #0xf, lsl #12  ; [pp+0xf218] inf
    //     0x62ed58: ldr             x16, [x16, #0x218]
    // 0x62ed5c: stp             x16, x0, [SP, #-0x10]!
    // 0x62ed60: r0 = computeMaxIntrinsicWidth()
    //     0x62ed60: bl              #0x62ede0  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::computeMaxIntrinsicWidth
    // 0x62ed64: add             SP, SP, #0x10
    // 0x62ed68: LoadField: d0 = r0->field_7
    //     0x62ed68: ldur            d0, [x0, #7]
    // 0x62ed6c: ldr             x0, [fp, #0x18]
    // 0x62ed70: LoadField: r1 = r0->field_5f
    //     0x62ed70: ldur            w1, [x0, #0x5f]
    // 0x62ed74: DecompressPointer r1
    //     0x62ed74: add             x1, x1, HEAP, lsl #32
    // 0x62ed78: cmp             w1, NULL
    // 0x62ed7c: b.eq            #0x62edcc
    // 0x62ed80: SaveReg r1
    //     0x62ed80: str             x1, [SP, #-8]!
    // 0x62ed84: SaveReg d0
    //     0x62ed84: str             d0, [SP, #-8]!
    // 0x62ed88: r0 = getMaxIntrinsicHeight()
    //     0x62ed88: bl              #0x62cb24  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0x62ed8c: add             SP, SP, #0x10
    // 0x62ed90: r0 = inline_Allocate_Double()
    //     0x62ed90: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62ed94: add             x0, x0, #0x10
    //     0x62ed98: cmp             x1, x0
    //     0x62ed9c: b.ls            #0x62edd0
    //     0x62eda0: str             x0, [THR, #0x60]  ; THR::top
    //     0x62eda4: sub             x0, x0, #0xf
    //     0x62eda8: mov             x1, #0xd108
    //     0x62edac: movk            x1, #3, lsl #16
    //     0x62edb0: stur            x1, [x0, #-1]
    // 0x62edb4: StoreField: r0->field_7 = d0
    //     0x62edb4: stur            d0, [x0, #7]
    // 0x62edb8: LeaveFrame
    //     0x62edb8: mov             SP, fp
    //     0x62edbc: ldp             fp, lr, [SP], #0x10
    // 0x62edc0: ret
    //     0x62edc0: ret             
    // 0x62edc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62edc4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62edc8: b               #0x62ed04
    // 0x62edcc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x62edcc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x62edd0: SaveReg d0
    //     0x62edd0: str             q0, [SP, #-0x10]!
    // 0x62edd4: r0 = AllocateDouble()
    //     0x62edd4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62edd8: RestoreReg d0
    //     0x62edd8: ldr             q0, [SP], #0x10
    // 0x62eddc: b               #0x62edb4
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0x62ede0, size: 0x9c
    // 0x62ede0: EnterFrame
    //     0x62ede0: stp             fp, lr, [SP, #-0x10]!
    //     0x62ede4: mov             fp, SP
    // 0x62ede8: CheckStackOverflow
    //     0x62ede8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62edec: cmp             SP, x16
    //     0x62edf0: b.ls            #0x62ee64
    // 0x62edf4: ldr             x0, [fp, #0x18]
    // 0x62edf8: LoadField: r1 = r0->field_5f
    //     0x62edf8: ldur            w1, [x0, #0x5f]
    // 0x62edfc: DecompressPointer r1
    //     0x62edfc: add             x1, x1, HEAP, lsl #32
    // 0x62ee00: cmp             w1, NULL
    // 0x62ee04: b.ne            #0x62ee18
    // 0x62ee08: r0 = 0.000000
    //     0x62ee08: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x62ee0c: LeaveFrame
    //     0x62ee0c: mov             SP, fp
    //     0x62ee10: ldp             fp, lr, [SP], #0x10
    // 0x62ee14: ret
    //     0x62ee14: ret             
    // 0x62ee18: ldr             x0, [fp, #0x10]
    // 0x62ee1c: LoadField: d0 = r0->field_7
    //     0x62ee1c: ldur            d0, [x0, #7]
    // 0x62ee20: SaveReg r1
    //     0x62ee20: str             x1, [SP, #-8]!
    // 0x62ee24: SaveReg d0
    //     0x62ee24: str             d0, [SP, #-8]!
    // 0x62ee28: r0 = getMaxIntrinsicWidth()
    //     0x62ee28: bl              #0x62cb94  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0x62ee2c: add             SP, SP, #0x10
    // 0x62ee30: r0 = inline_Allocate_Double()
    //     0x62ee30: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62ee34: add             x0, x0, #0x10
    //     0x62ee38: cmp             x1, x0
    //     0x62ee3c: b.ls            #0x62ee6c
    //     0x62ee40: str             x0, [THR, #0x60]  ; THR::top
    //     0x62ee44: sub             x0, x0, #0xf
    //     0x62ee48: mov             x1, #0xd108
    //     0x62ee4c: movk            x1, #3, lsl #16
    //     0x62ee50: stur            x1, [x0, #-1]
    // 0x62ee54: StoreField: r0->field_7 = d0
    //     0x62ee54: stur            d0, [x0, #7]
    // 0x62ee58: LeaveFrame
    //     0x62ee58: mov             SP, fp
    //     0x62ee5c: ldp             fp, lr, [SP], #0x10
    // 0x62ee60: ret
    //     0x62ee60: ret             
    // 0x62ee64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62ee64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62ee68: b               #0x62edf4
    // 0x62ee6c: SaveReg d0
    //     0x62ee6c: str             q0, [SP, #-0x10]!
    // 0x62ee70: r0 = AllocateDouble()
    //     0x62ee70: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62ee74: RestoreReg d0
    //     0x62ee74: ldr             q0, [SP], #0x10
    // 0x62ee78: b               #0x62ee54
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x62ee7c, size: 0x4c
    // 0x62ee7c: EnterFrame
    //     0x62ee7c: stp             fp, lr, [SP, #-0x10]!
    //     0x62ee80: mov             fp, SP
    // 0x62ee84: ldr             x0, [fp, #0x18]
    // 0x62ee88: LoadField: r1 = r0->field_17
    //     0x62ee88: ldur            w1, [x0, #0x17]
    // 0x62ee8c: DecompressPointer r1
    //     0x62ee8c: add             x1, x1, HEAP, lsl #32
    // 0x62ee90: CheckStackOverflow
    //     0x62ee90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62ee94: cmp             SP, x16
    //     0x62ee98: b.ls            #0x62eec0
    // 0x62ee9c: LoadField: r0 = r1->field_f
    //     0x62ee9c: ldur            w0, [x1, #0xf]
    // 0x62eea0: DecompressPointer r0
    //     0x62eea0: add             x0, x0, HEAP, lsl #32
    // 0x62eea4: ldr             x16, [fp, #0x10]
    // 0x62eea8: stp             x16, x0, [SP, #-0x10]!
    // 0x62eeac: r0 = computeMaxIntrinsicWidth()
    //     0x62eeac: bl              #0x62ede0  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::computeMaxIntrinsicWidth
    // 0x62eeb0: add             SP, SP, #0x10
    // 0x62eeb4: LeaveFrame
    //     0x62eeb4: mov             SP, fp
    //     0x62eeb8: ldp             fp, lr, [SP], #0x10
    // 0x62eebc: ret
    //     0x62eebc: ret             
    // 0x62eec0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62eec0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62eec4: b               #0x62ee9c
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x6358c8, size: 0x18
    // 0x6358c8: r4 = 0
    //     0x6358c8: mov             x4, #0
    // 0x6358cc: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x6358cc: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fc48] AnonymousClosure: (0x62ee7c), in [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::computeMaxIntrinsicWidth (0x62ede0)
    //     0x6358d0: ldr             x1, [x17, #0xc48]
    // 0x6358d4: r24 = BuildNonGenericMethodExtractorStub
    //     0x6358d4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x6358d8: LoadField: r0 = r24->field_17
    //     0x6358d8: ldur            x0, [x24, #0x17]
    // 0x6358dc: br              x0
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x6389c0, size: 0x18
    // 0x6389c0: r4 = 0
    //     0x6389c0: mov             x4, #0
    // 0x6389c4: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x6389c4: add             x17, PP, #0x52, lsl #12  ; [pp+0x52ea0] AnonymousClosure: (0x6389d8), in [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::computeMinIntrinsicHeight (0x638a24)
    //     0x6389c8: ldr             x1, [x17, #0xea0]
    // 0x6389cc: r24 = BuildNonGenericMethodExtractorStub
    //     0x6389cc: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x6389d0: LoadField: r0 = r24->field_17
    //     0x6389d0: ldur            x0, [x24, #0x17]
    // 0x6389d4: br              x0
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x6389d8, size: 0x4c
    // 0x6389d8: EnterFrame
    //     0x6389d8: stp             fp, lr, [SP, #-0x10]!
    //     0x6389dc: mov             fp, SP
    // 0x6389e0: ldr             x0, [fp, #0x18]
    // 0x6389e4: LoadField: r1 = r0->field_17
    //     0x6389e4: ldur            w1, [x0, #0x17]
    // 0x6389e8: DecompressPointer r1
    //     0x6389e8: add             x1, x1, HEAP, lsl #32
    // 0x6389ec: CheckStackOverflow
    //     0x6389ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6389f0: cmp             SP, x16
    //     0x6389f4: b.ls            #0x638a1c
    // 0x6389f8: LoadField: r0 = r1->field_f
    //     0x6389f8: ldur            w0, [x1, #0xf]
    // 0x6389fc: DecompressPointer r0
    //     0x6389fc: add             x0, x0, HEAP, lsl #32
    // 0x638a00: ldr             x16, [fp, #0x10]
    // 0x638a04: stp             x16, x0, [SP, #-0x10]!
    // 0x638a08: r0 = computeMinIntrinsicHeight()
    //     0x638a08: bl              #0x638a24  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::computeMinIntrinsicHeight
    // 0x638a0c: add             SP, SP, #0x10
    // 0x638a10: LeaveFrame
    //     0x638a10: mov             SP, fp
    //     0x638a14: ldp             fp, lr, [SP], #0x10
    // 0x638a18: ret
    //     0x638a18: ret             
    // 0x638a1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x638a1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x638a20: b               #0x6389f8
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0x638a24, size: 0xf0
    // 0x638a24: EnterFrame
    //     0x638a24: stp             fp, lr, [SP, #-0x10]!
    //     0x638a28: mov             fp, SP
    // 0x638a2c: CheckStackOverflow
    //     0x638a2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x638a30: cmp             SP, x16
    //     0x638a34: b.ls            #0x638af8
    // 0x638a38: ldr             x0, [fp, #0x18]
    // 0x638a3c: LoadField: r1 = r0->field_5f
    //     0x638a3c: ldur            w1, [x0, #0x5f]
    // 0x638a40: DecompressPointer r1
    //     0x638a40: add             x1, x1, HEAP, lsl #32
    // 0x638a44: cmp             w1, NULL
    // 0x638a48: b.ne            #0x638a5c
    // 0x638a4c: r0 = 0.000000
    //     0x638a4c: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x638a50: LeaveFrame
    //     0x638a50: mov             SP, fp
    //     0x638a54: ldp             fp, lr, [SP], #0x10
    // 0x638a58: ret
    //     0x638a58: ret             
    // 0x638a5c: ldr             x1, [fp, #0x10]
    // 0x638a60: LoadField: d0 = r1->field_7
    //     0x638a60: ldur            d0, [x1, #7]
    // 0x638a64: mov             x2, v0.d[0]
    // 0x638a68: and             x2, x2, #0x7fffffffffffffff
    // 0x638a6c: r17 = 9218868437227405312
    //     0x638a6c: mov             x17, #0x7ff0000000000000
    // 0x638a70: cmp             x2, x17
    // 0x638a74: b.eq            #0x638a88
    // 0x638a78: fcmp            d0, d0
    // 0x638a7c: b.vs            #0x638a88
    // 0x638a80: LoadField: d0 = r1->field_7
    //     0x638a80: ldur            d0, [x1, #7]
    // 0x638a84: b               #0x638aa4
    // 0x638a88: r16 = inf
    //     0x638a88: add             x16, PP, #0xf, lsl #12  ; [pp+0xf218] inf
    //     0x638a8c: ldr             x16, [x16, #0x218]
    // 0x638a90: stp             x16, x0, [SP, #-0x10]!
    // 0x638a94: r0 = computeMaxIntrinsicWidth()
    //     0x638a94: bl              #0x62ede0  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::computeMaxIntrinsicWidth
    // 0x638a98: add             SP, SP, #0x10
    // 0x638a9c: LoadField: d0 = r0->field_7
    //     0x638a9c: ldur            d0, [x0, #7]
    // 0x638aa0: ldr             x0, [fp, #0x18]
    // 0x638aa4: LoadField: r1 = r0->field_5f
    //     0x638aa4: ldur            w1, [x0, #0x5f]
    // 0x638aa8: DecompressPointer r1
    //     0x638aa8: add             x1, x1, HEAP, lsl #32
    // 0x638aac: cmp             w1, NULL
    // 0x638ab0: b.eq            #0x638b00
    // 0x638ab4: SaveReg r1
    //     0x638ab4: str             x1, [SP, #-8]!
    // 0x638ab8: SaveReg d0
    //     0x638ab8: str             d0, [SP, #-8]!
    // 0x638abc: r0 = getMinIntrinsicHeight()
    //     0x638abc: bl              #0x630a58  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0x638ac0: add             SP, SP, #0x10
    // 0x638ac4: r0 = inline_Allocate_Double()
    //     0x638ac4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x638ac8: add             x0, x0, #0x10
    //     0x638acc: cmp             x1, x0
    //     0x638ad0: b.ls            #0x638b04
    //     0x638ad4: str             x0, [THR, #0x60]  ; THR::top
    //     0x638ad8: sub             x0, x0, #0xf
    //     0x638adc: mov             x1, #0xd108
    //     0x638ae0: movk            x1, #3, lsl #16
    //     0x638ae4: stur            x1, [x0, #-1]
    // 0x638ae8: StoreField: r0->field_7 = d0
    //     0x638ae8: stur            d0, [x0, #7]
    // 0x638aec: LeaveFrame
    //     0x638aec: mov             SP, fp
    //     0x638af0: ldp             fp, lr, [SP], #0x10
    // 0x638af4: ret
    //     0x638af4: ret             
    // 0x638af8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x638af8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x638afc: b               #0x638a38
    // 0x638b00: r0 = NullCastErrorSharedWithFPURegs()
    //     0x638b00: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x638b04: SaveReg d0
    //     0x638b04: str             q0, [SP, #-0x10]!
    // 0x638b08: r0 = AllocateDouble()
    //     0x638b08: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x638b0c: RestoreReg d0
    //     0x638b0c: ldr             q0, [SP], #0x10
    // 0x638b10: b               #0x638ae8
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63b6ec, size: 0x18
    // 0x63b6ec: r4 = 0
    //     0x63b6ec: mov             x4, #0
    // 0x63b6f0: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63b6f0: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fda0] AnonymousClosure: (0x63b704), of [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth
    //     0x63b6f4: ldr             x1, [x17, #0xda0]
    // 0x63b6f8: r24 = BuildNonGenericMethodExtractorStub
    //     0x63b6f8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63b6fc: LoadField: r0 = r24->field_17
    //     0x63b6fc: ldur            x0, [x24, #0x17]
    // 0x63b700: br              x0
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63b704, size: 0x4c
    // 0x63b704: EnterFrame
    //     0x63b704: stp             fp, lr, [SP, #-0x10]!
    //     0x63b708: mov             fp, SP
    // 0x63b70c: ldr             x0, [fp, #0x18]
    // 0x63b710: LoadField: r1 = r0->field_17
    //     0x63b710: ldur            w1, [x0, #0x17]
    // 0x63b714: DecompressPointer r1
    //     0x63b714: add             x1, x1, HEAP, lsl #32
    // 0x63b718: CheckStackOverflow
    //     0x63b718: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63b71c: cmp             SP, x16
    //     0x63b720: b.ls            #0x63b748
    // 0x63b724: LoadField: r0 = r1->field_f
    //     0x63b724: ldur            w0, [x1, #0xf]
    // 0x63b728: DecompressPointer r0
    //     0x63b728: add             x0, x0, HEAP, lsl #32
    // 0x63b72c: ldr             x16, [fp, #0x10]
    // 0x63b730: stp             x16, x0, [SP, #-0x10]!
    // 0x63b734: r0 = computeMaxIntrinsicWidth()
    //     0x63b734: bl              #0x62ede0  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::computeMaxIntrinsicWidth
    // 0x63b738: add             SP, SP, #0x10
    // 0x63b73c: LeaveFrame
    //     0x63b73c: mov             SP, fp
    //     0x63b740: ldp             fp, lr, [SP], #0x10
    // 0x63b744: ret
    //     0x63b744: ret             
    // 0x63b748: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63b748: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63b74c: b               #0x63b724
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x68f650, size: 0xdc
    // 0x68f650: EnterFrame
    //     0x68f650: stp             fp, lr, [SP, #-0x10]!
    //     0x68f654: mov             fp, SP
    // 0x68f658: AllocStack(0x8)
    //     0x68f658: sub             SP, SP, #8
    // 0x68f65c: CheckStackOverflow
    //     0x68f65c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68f660: cmp             SP, x16
    //     0x68f664: b.ls            #0x68f724
    // 0x68f668: ldr             x3, [fp, #0x10]
    // 0x68f66c: LoadField: r4 = r3->field_27
    //     0x68f66c: ldur            w4, [x3, #0x27]
    // 0x68f670: DecompressPointer r4
    //     0x68f670: add             x4, x4, HEAP, lsl #32
    // 0x68f674: stur            x4, [fp, #-8]
    // 0x68f678: cmp             w4, NULL
    // 0x68f67c: b.eq            #0x68f704
    // 0x68f680: mov             x0, x4
    // 0x68f684: r2 = Null
    //     0x68f684: mov             x2, NULL
    // 0x68f688: r1 = Null
    //     0x68f688: mov             x1, NULL
    // 0x68f68c: r4 = LoadClassIdInstr(r0)
    //     0x68f68c: ldur            x4, [x0, #-1]
    //     0x68f690: ubfx            x4, x4, #0xc, #0x14
    // 0x68f694: sub             x4, x4, #0x80d
    // 0x68f698: cmp             x4, #1
    // 0x68f69c: b.ls            #0x68f6b4
    // 0x68f6a0: r8 = BoxConstraints
    //     0x68f6a0: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x68f6a4: ldr             x8, [x8, #0x1d0]
    // 0x68f6a8: r3 = Null
    //     0x68f6a8: add             x3, PP, #0x37, lsl #12  ; [pp+0x37070] Null
    //     0x68f6ac: ldr             x3, [x3, #0x70]
    // 0x68f6b0: r0 = BoxConstraints()
    //     0x68f6b0: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x68f6b4: ldr             x16, [fp, #0x10]
    // 0x68f6b8: ldur            lr, [fp, #-8]
    // 0x68f6bc: stp             lr, x16, [SP, #-0x10]!
    // 0x68f6c0: r16 = Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static.
    //     0x68f6c0: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cf80] Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static. (0x7fe6e1e8aefc)
    //     0x68f6c4: ldr             x16, [x16, #0xf80]
    // 0x68f6c8: SaveReg r16
    //     0x68f6c8: str             x16, [SP, #-8]!
    // 0x68f6cc: r0 = _computeSize()
    //     0x68f6cc: bl              #0x68f72c  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::_computeSize
    // 0x68f6d0: add             SP, SP, #0x18
    // 0x68f6d4: ldr             x1, [fp, #0x10]
    // 0x68f6d8: StoreField: r1->field_57 = r0
    //     0x68f6d8: stur            w0, [x1, #0x57]
    //     0x68f6dc: ldurb           w16, [x1, #-1]
    //     0x68f6e0: ldurb           w17, [x0, #-1]
    //     0x68f6e4: and             x16, x17, x16, lsr #2
    //     0x68f6e8: tst             x16, HEAP, lsr #32
    //     0x68f6ec: b.eq            #0x68f6f4
    //     0x68f6f0: bl              #0xd6826c
    // 0x68f6f4: r0 = Null
    //     0x68f6f4: mov             x0, NULL
    // 0x68f6f8: LeaveFrame
    //     0x68f6f8: mov             SP, fp
    //     0x68f6fc: ldp             fp, lr, [SP], #0x10
    // 0x68f700: ret
    //     0x68f700: ret             
    // 0x68f704: r0 = StateError()
    //     0x68f704: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68f708: mov             x1, x0
    // 0x68f70c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68f70c: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68f710: ldr             x0, [x0, #0x1e8]
    // 0x68f714: StoreField: r1->field_b = r0
    //     0x68f714: stur            w0, [x1, #0xb]
    // 0x68f718: mov             x0, x1
    // 0x68f71c: r0 = Throw()
    //     0x68f71c: bl              #0xd67e38  ; ThrowStub
    // 0x68f720: brk             #0
    // 0x68f724: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68f724: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68f728: b               #0x68f668
  }
  _ _computeSize(/* No info */) {
    // ** addr: 0x68f72c, size: 0x128
    // 0x68f72c: EnterFrame
    //     0x68f72c: stp             fp, lr, [SP, #-0x10]!
    //     0x68f730: mov             fp, SP
    // 0x68f734: CheckStackOverflow
    //     0x68f734: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68f738: cmp             SP, x16
    //     0x68f73c: b.ls            #0x68f838
    // 0x68f740: ldr             x0, [fp, #0x20]
    // 0x68f744: LoadField: r1 = r0->field_5f
    //     0x68f744: ldur            w1, [x0, #0x5f]
    // 0x68f748: DecompressPointer r1
    //     0x68f748: add             x1, x1, HEAP, lsl #32
    // 0x68f74c: cmp             w1, NULL
    // 0x68f750: b.eq            #0x68f81c
    // 0x68f754: ldr             x2, [fp, #0x18]
    // 0x68f758: LoadField: d0 = r2->field_7
    //     0x68f758: ldur            d0, [x2, #7]
    // 0x68f75c: LoadField: d1 = r2->field_f
    //     0x68f75c: ldur            d1, [x2, #0xf]
    // 0x68f760: fcmp            d0, d1
    // 0x68f764: b.vs            #0x68f76c
    // 0x68f768: b.ge            #0x68f774
    // 0x68f76c: r3 = false
    //     0x68f76c: add             x3, NULL, #0x30  ; false
    // 0x68f770: b               #0x68f778
    // 0x68f774: r3 = true
    //     0x68f774: add             x3, NULL, #0x20  ; true
    // 0x68f778: tbz             w3, #4, #0x68f7d8
    // 0x68f77c: LoadField: d0 = r2->field_1f
    //     0x68f77c: ldur            d0, [x2, #0x1f]
    // 0x68f780: SaveReg r1
    //     0x68f780: str             x1, [SP, #-8]!
    // 0x68f784: SaveReg d0
    //     0x68f784: str             d0, [SP, #-8]!
    // 0x68f788: r0 = getMaxIntrinsicWidth()
    //     0x68f788: bl              #0x62cb94  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0x68f78c: add             SP, SP, #0x10
    // 0x68f790: r0 = inline_Allocate_Double()
    //     0x68f790: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x68f794: add             x0, x0, #0x10
    //     0x68f798: cmp             x1, x0
    //     0x68f79c: b.ls            #0x68f840
    //     0x68f7a0: str             x0, [THR, #0x60]  ; THR::top
    //     0x68f7a4: sub             x0, x0, #0xf
    //     0x68f7a8: mov             x1, #0xd108
    //     0x68f7ac: movk            x1, #3, lsl #16
    //     0x68f7b0: stur            x1, [x0, #-1]
    // 0x68f7b4: StoreField: r0->field_7 = d0
    //     0x68f7b4: stur            d0, [x0, #7]
    // 0x68f7b8: ldr             x16, [fp, #0x18]
    // 0x68f7bc: stp             x0, x16, [SP, #-0x10]!
    // 0x68f7c0: r4 = const [0, 0x2, 0x2, 0x1, width, 0x1, null]
    //     0x68f7c0: add             x4, PP, #0x21, lsl #12  ; [pp+0x21618] List(7) [0, 0x2, 0x2, 0x1, "width", 0x1, Null]
    //     0x68f7c4: ldr             x4, [x4, #0x618]
    // 0x68f7c8: r0 = tighten()
    //     0x68f7c8: bl              #0x590b84  ; [package:flutter/src/rendering/box.dart] BoxConstraints::tighten
    // 0x68f7cc: add             SP, SP, #0x10
    // 0x68f7d0: mov             x1, x0
    // 0x68f7d4: b               #0x68f7dc
    // 0x68f7d8: ldr             x1, [fp, #0x18]
    // 0x68f7dc: ldr             x0, [fp, #0x20]
    // 0x68f7e0: LoadField: r2 = r0->field_5f
    //     0x68f7e0: ldur            w2, [x0, #0x5f]
    // 0x68f7e4: DecompressPointer r2
    //     0x68f7e4: add             x2, x2, HEAP, lsl #32
    // 0x68f7e8: cmp             w2, NULL
    // 0x68f7ec: b.eq            #0x68f850
    // 0x68f7f0: ldr             x16, [fp, #0x10]
    // 0x68f7f4: stp             x2, x16, [SP, #-0x10]!
    // 0x68f7f8: SaveReg r1
    //     0x68f7f8: str             x1, [SP, #-8]!
    // 0x68f7fc: ldr             x0, [fp, #0x10]
    // 0x68f800: ClosureCall
    //     0x68f800: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x68f804: ldur            x2, [x0, #0x1f]
    //     0x68f808: blr             x2
    // 0x68f80c: add             SP, SP, #0x18
    // 0x68f810: LeaveFrame
    //     0x68f810: mov             SP, fp
    //     0x68f814: ldp             fp, lr, [SP], #0x10
    // 0x68f818: ret
    //     0x68f818: ret             
    // 0x68f81c: ldr             x16, [fp, #0x18]
    // 0x68f820: SaveReg r16
    //     0x68f820: str             x16, [SP, #-8]!
    // 0x68f824: r0 = smallest()
    //     0x68f824: bl              #0x62bd18  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0x68f828: add             SP, SP, #8
    // 0x68f82c: LeaveFrame
    //     0x68f82c: mov             SP, fp
    //     0x68f830: ldp             fp, lr, [SP], #0x10
    // 0x68f834: ret
    //     0x68f834: ret             
    // 0x68f838: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68f838: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68f83c: b               #0x68f740
    // 0x68f840: SaveReg d0
    //     0x68f840: str             q0, [SP, #-0x10]!
    // 0x68f844: r0 = AllocateDouble()
    //     0x68f844: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68f848: RestoreReg d0
    //     0x68f848: ldr             q0, [SP], #0x10
    // 0x68f84c: b               #0x68f7b4
    // 0x68f850: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68f850: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5d768, size: 0x48
    // 0xa5d768: EnterFrame
    //     0xa5d768: stp             fp, lr, [SP, #-0x10]!
    //     0xa5d76c: mov             fp, SP
    // 0xa5d770: CheckStackOverflow
    //     0xa5d770: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5d774: cmp             SP, x16
    //     0xa5d778: b.ls            #0xa5d7a8
    // 0xa5d77c: ldr             x16, [fp, #0x18]
    // 0xa5d780: ldr             lr, [fp, #0x10]
    // 0xa5d784: stp             lr, x16, [SP, #-0x10]!
    // 0xa5d788: r16 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xa5d788: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cf88] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7fe6e1e33c20)
    //     0xa5d78c: ldr             x16, [x16, #0xf88]
    // 0xa5d790: SaveReg r16
    //     0xa5d790: str             x16, [SP, #-8]!
    // 0xa5d794: r0 = _computeSize()
    //     0xa5d794: bl              #0x68f72c  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::_computeSize
    // 0xa5d798: add             SP, SP, #0x18
    // 0xa5d79c: LeaveFrame
    //     0xa5d79c: mov             SP, fp
    //     0xa5d7a0: ldp             fp, lr, [SP], #0x10
    // 0xa5d7a4: ret
    //     0xa5d7a4: ret             
    // 0xa5d7a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5d7a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5d7ac: b               #0xa5d77c
  }
}

// class id: 2511, size: 0x6c, field offset: 0x64
class RenderAspectRatio extends RenderProxyBox {

  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x62eb10, size: 0x18
    // 0x62eb10: r4 = 0
    //     0x62eb10: mov             x4, #0
    // 0x62eb14: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x62eb14: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b268] AnonymousClosure: (0x62eb28), in [package:flutter/src/rendering/proxy_box.dart] RenderAspectRatio::computeMaxIntrinsicHeight (0x62eb74)
    //     0x62eb18: ldr             x1, [x17, #0x268]
    // 0x62eb1c: r24 = BuildNonGenericMethodExtractorStub
    //     0x62eb1c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x62eb20: LoadField: r0 = r24->field_17
    //     0x62eb20: ldur            x0, [x24, #0x17]
    // 0x62eb24: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x62eb28, size: 0x4c
    // 0x62eb28: EnterFrame
    //     0x62eb28: stp             fp, lr, [SP, #-0x10]!
    //     0x62eb2c: mov             fp, SP
    // 0x62eb30: ldr             x0, [fp, #0x18]
    // 0x62eb34: LoadField: r1 = r0->field_17
    //     0x62eb34: ldur            w1, [x0, #0x17]
    // 0x62eb38: DecompressPointer r1
    //     0x62eb38: add             x1, x1, HEAP, lsl #32
    // 0x62eb3c: CheckStackOverflow
    //     0x62eb3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62eb40: cmp             SP, x16
    //     0x62eb44: b.ls            #0x62eb6c
    // 0x62eb48: LoadField: r0 = r1->field_f
    //     0x62eb48: ldur            w0, [x1, #0xf]
    // 0x62eb4c: DecompressPointer r0
    //     0x62eb4c: add             x0, x0, HEAP, lsl #32
    // 0x62eb50: ldr             x16, [fp, #0x10]
    // 0x62eb54: stp             x16, x0, [SP, #-0x10]!
    // 0x62eb58: r0 = computeMaxIntrinsicHeight()
    //     0x62eb58: bl              #0x62eb74  ; [package:flutter/src/rendering/proxy_box.dart] RenderAspectRatio::computeMaxIntrinsicHeight
    // 0x62eb5c: add             SP, SP, #0x10
    // 0x62eb60: LeaveFrame
    //     0x62eb60: mov             SP, fp
    //     0x62eb64: ldp             fp, lr, [SP], #0x10
    // 0x62eb68: ret
    //     0x62eb68: ret             
    // 0x62eb6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62eb6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62eb70: b               #0x62eb48
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0x62eb74, size: 0x118
    // 0x62eb74: EnterFrame
    //     0x62eb74: stp             fp, lr, [SP, #-0x10]!
    //     0x62eb78: mov             fp, SP
    // 0x62eb7c: CheckStackOverflow
    //     0x62eb7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62eb80: cmp             SP, x16
    //     0x62eb84: b.ls            #0x62ec64
    // 0x62eb88: ldr             x0, [fp, #0x10]
    // 0x62eb8c: LoadField: d0 = r0->field_7
    //     0x62eb8c: ldur            d0, [x0, #7]
    // 0x62eb90: mov             x1, v0.d[0]
    // 0x62eb94: and             x1, x1, #0x7fffffffffffffff
    // 0x62eb98: r17 = 9218868437227405312
    //     0x62eb98: mov             x17, #0x7ff0000000000000
    // 0x62eb9c: cmp             x1, x17
    // 0x62eba0: b.eq            #0x62ebf8
    // 0x62eba4: fcmp            d0, d0
    // 0x62eba8: b.vs            #0x62ebf0
    // 0x62ebac: ldr             x1, [fp, #0x18]
    // 0x62ebb0: LoadField: d0 = r1->field_63
    //     0x62ebb0: ldur            d0, [x1, #0x63]
    // 0x62ebb4: LoadField: d1 = r0->field_7
    //     0x62ebb4: ldur            d1, [x0, #7]
    // 0x62ebb8: fdiv            d2, d1, d0
    // 0x62ebbc: r0 = inline_Allocate_Double()
    //     0x62ebbc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62ebc0: add             x0, x0, #0x10
    //     0x62ebc4: cmp             x1, x0
    //     0x62ebc8: b.ls            #0x62ec6c
    //     0x62ebcc: str             x0, [THR, #0x60]  ; THR::top
    //     0x62ebd0: sub             x0, x0, #0xf
    //     0x62ebd4: mov             x1, #0xd108
    //     0x62ebd8: movk            x1, #3, lsl #16
    //     0x62ebdc: stur            x1, [x0, #-1]
    // 0x62ebe0: StoreField: r0->field_7 = d2
    //     0x62ebe0: stur            d2, [x0, #7]
    // 0x62ebe4: LeaveFrame
    //     0x62ebe4: mov             SP, fp
    //     0x62ebe8: ldp             fp, lr, [SP], #0x10
    // 0x62ebec: ret
    //     0x62ebec: ret             
    // 0x62ebf0: ldr             x1, [fp, #0x18]
    // 0x62ebf4: b               #0x62ebfc
    // 0x62ebf8: ldr             x1, [fp, #0x18]
    // 0x62ebfc: LoadField: r2 = r1->field_5f
    //     0x62ebfc: ldur            w2, [x1, #0x5f]
    // 0x62ec00: DecompressPointer r2
    //     0x62ec00: add             x2, x2, HEAP, lsl #32
    // 0x62ec04: cmp             w2, NULL
    // 0x62ec08: b.eq            #0x62ec54
    // 0x62ec0c: LoadField: d0 = r0->field_7
    //     0x62ec0c: ldur            d0, [x0, #7]
    // 0x62ec10: SaveReg r2
    //     0x62ec10: str             x2, [SP, #-8]!
    // 0x62ec14: SaveReg d0
    //     0x62ec14: str             d0, [SP, #-8]!
    // 0x62ec18: r0 = getMaxIntrinsicHeight()
    //     0x62ec18: bl              #0x62cb24  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0x62ec1c: add             SP, SP, #0x10
    // 0x62ec20: r0 = inline_Allocate_Double()
    //     0x62ec20: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62ec24: add             x0, x0, #0x10
    //     0x62ec28: cmp             x1, x0
    //     0x62ec2c: b.ls            #0x62ec7c
    //     0x62ec30: str             x0, [THR, #0x60]  ; THR::top
    //     0x62ec34: sub             x0, x0, #0xf
    //     0x62ec38: mov             x1, #0xd108
    //     0x62ec3c: movk            x1, #3, lsl #16
    //     0x62ec40: stur            x1, [x0, #-1]
    // 0x62ec44: StoreField: r0->field_7 = d0
    //     0x62ec44: stur            d0, [x0, #7]
    // 0x62ec48: LeaveFrame
    //     0x62ec48: mov             SP, fp
    //     0x62ec4c: ldp             fp, lr, [SP], #0x10
    // 0x62ec50: ret
    //     0x62ec50: ret             
    // 0x62ec54: r0 = 0.000000
    //     0x62ec54: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x62ec58: LeaveFrame
    //     0x62ec58: mov             SP, fp
    //     0x62ec5c: ldp             fp, lr, [SP], #0x10
    // 0x62ec60: ret
    //     0x62ec60: ret             
    // 0x62ec64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62ec64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62ec68: b               #0x62eb88
    // 0x62ec6c: SaveReg d2
    //     0x62ec6c: str             q2, [SP, #-0x10]!
    // 0x62ec70: r0 = AllocateDouble()
    //     0x62ec70: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62ec74: RestoreReg d2
    //     0x62ec74: ldr             q2, [SP], #0x10
    // 0x62ec78: b               #0x62ebe0
    // 0x62ec7c: SaveReg d0
    //     0x62ec7c: str             q0, [SP, #-0x10]!
    // 0x62ec80: r0 = AllocateDouble()
    //     0x62ec80: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62ec84: RestoreReg d0
    //     0x62ec84: ldr             q0, [SP], #0x10
    // 0x62ec88: b               #0x62ec44
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x63574c, size: 0x18
    // 0x63574c: r4 = 0
    //     0x63574c: mov             x4, #0
    // 0x635750: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x635750: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fc10] AnonymousClosure: (0x635764), in [package:flutter/src/rendering/proxy_box.dart] RenderAspectRatio::computeMaxIntrinsicWidth (0x6357b0)
    //     0x635754: ldr             x1, [x17, #0xc10]
    // 0x635758: r24 = BuildNonGenericMethodExtractorStub
    //     0x635758: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63575c: LoadField: r0 = r24->field_17
    //     0x63575c: ldur            x0, [x24, #0x17]
    // 0x635760: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x635764, size: 0x4c
    // 0x635764: EnterFrame
    //     0x635764: stp             fp, lr, [SP, #-0x10]!
    //     0x635768: mov             fp, SP
    // 0x63576c: ldr             x0, [fp, #0x18]
    // 0x635770: LoadField: r1 = r0->field_17
    //     0x635770: ldur            w1, [x0, #0x17]
    // 0x635774: DecompressPointer r1
    //     0x635774: add             x1, x1, HEAP, lsl #32
    // 0x635778: CheckStackOverflow
    //     0x635778: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63577c: cmp             SP, x16
    //     0x635780: b.ls            #0x6357a8
    // 0x635784: LoadField: r0 = r1->field_f
    //     0x635784: ldur            w0, [x1, #0xf]
    // 0x635788: DecompressPointer r0
    //     0x635788: add             x0, x0, HEAP, lsl #32
    // 0x63578c: ldr             x16, [fp, #0x10]
    // 0x635790: stp             x16, x0, [SP, #-0x10]!
    // 0x635794: r0 = computeMaxIntrinsicWidth()
    //     0x635794: bl              #0x6357b0  ; [package:flutter/src/rendering/proxy_box.dart] RenderAspectRatio::computeMaxIntrinsicWidth
    // 0x635798: add             SP, SP, #0x10
    // 0x63579c: LeaveFrame
    //     0x63579c: mov             SP, fp
    //     0x6357a0: ldp             fp, lr, [SP], #0x10
    // 0x6357a4: ret
    //     0x6357a4: ret             
    // 0x6357a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6357a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6357ac: b               #0x635784
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0x6357b0, size: 0x118
    // 0x6357b0: EnterFrame
    //     0x6357b0: stp             fp, lr, [SP, #-0x10]!
    //     0x6357b4: mov             fp, SP
    // 0x6357b8: CheckStackOverflow
    //     0x6357b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6357bc: cmp             SP, x16
    //     0x6357c0: b.ls            #0x6358a0
    // 0x6357c4: ldr             x0, [fp, #0x10]
    // 0x6357c8: LoadField: d0 = r0->field_7
    //     0x6357c8: ldur            d0, [x0, #7]
    // 0x6357cc: mov             x1, v0.d[0]
    // 0x6357d0: and             x1, x1, #0x7fffffffffffffff
    // 0x6357d4: r17 = 9218868437227405312
    //     0x6357d4: mov             x17, #0x7ff0000000000000
    // 0x6357d8: cmp             x1, x17
    // 0x6357dc: b.eq            #0x635834
    // 0x6357e0: fcmp            d0, d0
    // 0x6357e4: b.vs            #0x63582c
    // 0x6357e8: ldr             x1, [fp, #0x18]
    // 0x6357ec: LoadField: d0 = r1->field_63
    //     0x6357ec: ldur            d0, [x1, #0x63]
    // 0x6357f0: LoadField: d1 = r0->field_7
    //     0x6357f0: ldur            d1, [x0, #7]
    // 0x6357f4: fmul            d2, d1, d0
    // 0x6357f8: r0 = inline_Allocate_Double()
    //     0x6357f8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6357fc: add             x0, x0, #0x10
    //     0x635800: cmp             x1, x0
    //     0x635804: b.ls            #0x6358a8
    //     0x635808: str             x0, [THR, #0x60]  ; THR::top
    //     0x63580c: sub             x0, x0, #0xf
    //     0x635810: mov             x1, #0xd108
    //     0x635814: movk            x1, #3, lsl #16
    //     0x635818: stur            x1, [x0, #-1]
    // 0x63581c: StoreField: r0->field_7 = d2
    //     0x63581c: stur            d2, [x0, #7]
    // 0x635820: LeaveFrame
    //     0x635820: mov             SP, fp
    //     0x635824: ldp             fp, lr, [SP], #0x10
    // 0x635828: ret
    //     0x635828: ret             
    // 0x63582c: ldr             x1, [fp, #0x18]
    // 0x635830: b               #0x635838
    // 0x635834: ldr             x1, [fp, #0x18]
    // 0x635838: LoadField: r2 = r1->field_5f
    //     0x635838: ldur            w2, [x1, #0x5f]
    // 0x63583c: DecompressPointer r2
    //     0x63583c: add             x2, x2, HEAP, lsl #32
    // 0x635840: cmp             w2, NULL
    // 0x635844: b.eq            #0x635890
    // 0x635848: LoadField: d0 = r0->field_7
    //     0x635848: ldur            d0, [x0, #7]
    // 0x63584c: SaveReg r2
    //     0x63584c: str             x2, [SP, #-8]!
    // 0x635850: SaveReg d0
    //     0x635850: str             d0, [SP, #-8]!
    // 0x635854: r0 = getMaxIntrinsicWidth()
    //     0x635854: bl              #0x62cb94  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0x635858: add             SP, SP, #0x10
    // 0x63585c: r0 = inline_Allocate_Double()
    //     0x63585c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x635860: add             x0, x0, #0x10
    //     0x635864: cmp             x1, x0
    //     0x635868: b.ls            #0x6358b8
    //     0x63586c: str             x0, [THR, #0x60]  ; THR::top
    //     0x635870: sub             x0, x0, #0xf
    //     0x635874: mov             x1, #0xd108
    //     0x635878: movk            x1, #3, lsl #16
    //     0x63587c: stur            x1, [x0, #-1]
    // 0x635880: StoreField: r0->field_7 = d0
    //     0x635880: stur            d0, [x0, #7]
    // 0x635884: LeaveFrame
    //     0x635884: mov             SP, fp
    //     0x635888: ldp             fp, lr, [SP], #0x10
    // 0x63588c: ret
    //     0x63588c: ret             
    // 0x635890: r0 = 0.000000
    //     0x635890: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x635894: LeaveFrame
    //     0x635894: mov             SP, fp
    //     0x635898: ldp             fp, lr, [SP], #0x10
    // 0x63589c: ret
    //     0x63589c: ret             
    // 0x6358a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6358a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6358a4: b               #0x6357c4
    // 0x6358a8: SaveReg d2
    //     0x6358a8: str             q2, [SP, #-0x10]!
    // 0x6358ac: r0 = AllocateDouble()
    //     0x6358ac: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6358b0: RestoreReg d2
    //     0x6358b0: ldr             q2, [SP], #0x10
    // 0x6358b4: b               #0x63581c
    // 0x6358b8: SaveReg d0
    //     0x6358b8: str             q0, [SP, #-0x10]!
    // 0x6358bc: r0 = AllocateDouble()
    //     0x6358bc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6358c0: RestoreReg d0
    //     0x6358c0: ldr             q0, [SP], #0x10
    // 0x6358c4: b               #0x635880
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x638844, size: 0x18
    // 0x638844: r4 = 0
    //     0x638844: mov             x4, #0
    // 0x638848: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x638848: add             x17, PP, #0x52, lsl #12  ; [pp+0x52e98] AnonymousClosure: (0x63885c), in [package:flutter/src/rendering/proxy_box.dart] RenderAspectRatio::computeMinIntrinsicHeight (0x6388a8)
    //     0x63884c: ldr             x1, [x17, #0xe98]
    // 0x638850: r24 = BuildNonGenericMethodExtractorStub
    //     0x638850: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x638854: LoadField: r0 = r24->field_17
    //     0x638854: ldur            x0, [x24, #0x17]
    // 0x638858: br              x0
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x63885c, size: 0x4c
    // 0x63885c: EnterFrame
    //     0x63885c: stp             fp, lr, [SP, #-0x10]!
    //     0x638860: mov             fp, SP
    // 0x638864: ldr             x0, [fp, #0x18]
    // 0x638868: LoadField: r1 = r0->field_17
    //     0x638868: ldur            w1, [x0, #0x17]
    // 0x63886c: DecompressPointer r1
    //     0x63886c: add             x1, x1, HEAP, lsl #32
    // 0x638870: CheckStackOverflow
    //     0x638870: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x638874: cmp             SP, x16
    //     0x638878: b.ls            #0x6388a0
    // 0x63887c: LoadField: r0 = r1->field_f
    //     0x63887c: ldur            w0, [x1, #0xf]
    // 0x638880: DecompressPointer r0
    //     0x638880: add             x0, x0, HEAP, lsl #32
    // 0x638884: ldr             x16, [fp, #0x10]
    // 0x638888: stp             x16, x0, [SP, #-0x10]!
    // 0x63888c: r0 = computeMinIntrinsicHeight()
    //     0x63888c: bl              #0x6388a8  ; [package:flutter/src/rendering/proxy_box.dart] RenderAspectRatio::computeMinIntrinsicHeight
    // 0x638890: add             SP, SP, #0x10
    // 0x638894: LeaveFrame
    //     0x638894: mov             SP, fp
    //     0x638898: ldp             fp, lr, [SP], #0x10
    // 0x63889c: ret
    //     0x63889c: ret             
    // 0x6388a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6388a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6388a4: b               #0x63887c
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0x6388a8, size: 0x118
    // 0x6388a8: EnterFrame
    //     0x6388a8: stp             fp, lr, [SP, #-0x10]!
    //     0x6388ac: mov             fp, SP
    // 0x6388b0: CheckStackOverflow
    //     0x6388b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6388b4: cmp             SP, x16
    //     0x6388b8: b.ls            #0x638998
    // 0x6388bc: ldr             x0, [fp, #0x10]
    // 0x6388c0: LoadField: d0 = r0->field_7
    //     0x6388c0: ldur            d0, [x0, #7]
    // 0x6388c4: mov             x1, v0.d[0]
    // 0x6388c8: and             x1, x1, #0x7fffffffffffffff
    // 0x6388cc: r17 = 9218868437227405312
    //     0x6388cc: mov             x17, #0x7ff0000000000000
    // 0x6388d0: cmp             x1, x17
    // 0x6388d4: b.eq            #0x63892c
    // 0x6388d8: fcmp            d0, d0
    // 0x6388dc: b.vs            #0x638924
    // 0x6388e0: ldr             x1, [fp, #0x18]
    // 0x6388e4: LoadField: d0 = r1->field_63
    //     0x6388e4: ldur            d0, [x1, #0x63]
    // 0x6388e8: LoadField: d1 = r0->field_7
    //     0x6388e8: ldur            d1, [x0, #7]
    // 0x6388ec: fdiv            d2, d1, d0
    // 0x6388f0: r0 = inline_Allocate_Double()
    //     0x6388f0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6388f4: add             x0, x0, #0x10
    //     0x6388f8: cmp             x1, x0
    //     0x6388fc: b.ls            #0x6389a0
    //     0x638900: str             x0, [THR, #0x60]  ; THR::top
    //     0x638904: sub             x0, x0, #0xf
    //     0x638908: mov             x1, #0xd108
    //     0x63890c: movk            x1, #3, lsl #16
    //     0x638910: stur            x1, [x0, #-1]
    // 0x638914: StoreField: r0->field_7 = d2
    //     0x638914: stur            d2, [x0, #7]
    // 0x638918: LeaveFrame
    //     0x638918: mov             SP, fp
    //     0x63891c: ldp             fp, lr, [SP], #0x10
    // 0x638920: ret
    //     0x638920: ret             
    // 0x638924: ldr             x1, [fp, #0x18]
    // 0x638928: b               #0x638930
    // 0x63892c: ldr             x1, [fp, #0x18]
    // 0x638930: LoadField: r2 = r1->field_5f
    //     0x638930: ldur            w2, [x1, #0x5f]
    // 0x638934: DecompressPointer r2
    //     0x638934: add             x2, x2, HEAP, lsl #32
    // 0x638938: cmp             w2, NULL
    // 0x63893c: b.eq            #0x638988
    // 0x638940: LoadField: d0 = r0->field_7
    //     0x638940: ldur            d0, [x0, #7]
    // 0x638944: SaveReg r2
    //     0x638944: str             x2, [SP, #-8]!
    // 0x638948: SaveReg d0
    //     0x638948: str             d0, [SP, #-8]!
    // 0x63894c: r0 = getMinIntrinsicHeight()
    //     0x63894c: bl              #0x630a58  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0x638950: add             SP, SP, #0x10
    // 0x638954: r0 = inline_Allocate_Double()
    //     0x638954: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x638958: add             x0, x0, #0x10
    //     0x63895c: cmp             x1, x0
    //     0x638960: b.ls            #0x6389b0
    //     0x638964: str             x0, [THR, #0x60]  ; THR::top
    //     0x638968: sub             x0, x0, #0xf
    //     0x63896c: mov             x1, #0xd108
    //     0x638970: movk            x1, #3, lsl #16
    //     0x638974: stur            x1, [x0, #-1]
    // 0x638978: StoreField: r0->field_7 = d0
    //     0x638978: stur            d0, [x0, #7]
    // 0x63897c: LeaveFrame
    //     0x63897c: mov             SP, fp
    //     0x638980: ldp             fp, lr, [SP], #0x10
    // 0x638984: ret
    //     0x638984: ret             
    // 0x638988: r0 = 0.000000
    //     0x638988: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x63898c: LeaveFrame
    //     0x63898c: mov             SP, fp
    //     0x638990: ldp             fp, lr, [SP], #0x10
    // 0x638994: ret
    //     0x638994: ret             
    // 0x638998: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x638998: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63899c: b               #0x6388bc
    // 0x6389a0: SaveReg d2
    //     0x6389a0: str             q2, [SP, #-0x10]!
    // 0x6389a4: r0 = AllocateDouble()
    //     0x6389a4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6389a8: RestoreReg d2
    //     0x6389a8: ldr             q2, [SP], #0x10
    // 0x6389ac: b               #0x638914
    // 0x6389b0: SaveReg d0
    //     0x6389b0: str             q0, [SP, #-0x10]!
    // 0x6389b4: r0 = AllocateDouble()
    //     0x6389b4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6389b8: RestoreReg d0
    //     0x6389b8: ldr             q0, [SP], #0x10
    // 0x6389bc: b               #0x638978
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63b570, size: 0x18
    // 0x63b570: r4 = 0
    //     0x63b570: mov             x4, #0
    // 0x63b574: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63b574: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fd28] AnonymousClosure: (0x63b588), in [package:flutter/src/rendering/proxy_box.dart] RenderAspectRatio::computeMinIntrinsicWidth (0x63b5d4)
    //     0x63b578: ldr             x1, [x17, #0xd28]
    // 0x63b57c: r24 = BuildNonGenericMethodExtractorStub
    //     0x63b57c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63b580: LoadField: r0 = r24->field_17
    //     0x63b580: ldur            x0, [x24, #0x17]
    // 0x63b584: br              x0
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63b588, size: 0x4c
    // 0x63b588: EnterFrame
    //     0x63b588: stp             fp, lr, [SP, #-0x10]!
    //     0x63b58c: mov             fp, SP
    // 0x63b590: ldr             x0, [fp, #0x18]
    // 0x63b594: LoadField: r1 = r0->field_17
    //     0x63b594: ldur            w1, [x0, #0x17]
    // 0x63b598: DecompressPointer r1
    //     0x63b598: add             x1, x1, HEAP, lsl #32
    // 0x63b59c: CheckStackOverflow
    //     0x63b59c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63b5a0: cmp             SP, x16
    //     0x63b5a4: b.ls            #0x63b5cc
    // 0x63b5a8: LoadField: r0 = r1->field_f
    //     0x63b5a8: ldur            w0, [x1, #0xf]
    // 0x63b5ac: DecompressPointer r0
    //     0x63b5ac: add             x0, x0, HEAP, lsl #32
    // 0x63b5b0: ldr             x16, [fp, #0x10]
    // 0x63b5b4: stp             x16, x0, [SP, #-0x10]!
    // 0x63b5b8: r0 = computeMinIntrinsicWidth()
    //     0x63b5b8: bl              #0x63b5d4  ; [package:flutter/src/rendering/proxy_box.dart] RenderAspectRatio::computeMinIntrinsicWidth
    // 0x63b5bc: add             SP, SP, #0x10
    // 0x63b5c0: LeaveFrame
    //     0x63b5c0: mov             SP, fp
    //     0x63b5c4: ldp             fp, lr, [SP], #0x10
    // 0x63b5c8: ret
    //     0x63b5c8: ret             
    // 0x63b5cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63b5cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63b5d0: b               #0x63b5a8
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0x63b5d4, size: 0x118
    // 0x63b5d4: EnterFrame
    //     0x63b5d4: stp             fp, lr, [SP, #-0x10]!
    //     0x63b5d8: mov             fp, SP
    // 0x63b5dc: CheckStackOverflow
    //     0x63b5dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63b5e0: cmp             SP, x16
    //     0x63b5e4: b.ls            #0x63b6c4
    // 0x63b5e8: ldr             x0, [fp, #0x10]
    // 0x63b5ec: LoadField: d0 = r0->field_7
    //     0x63b5ec: ldur            d0, [x0, #7]
    // 0x63b5f0: mov             x1, v0.d[0]
    // 0x63b5f4: and             x1, x1, #0x7fffffffffffffff
    // 0x63b5f8: r17 = 9218868437227405312
    //     0x63b5f8: mov             x17, #0x7ff0000000000000
    // 0x63b5fc: cmp             x1, x17
    // 0x63b600: b.eq            #0x63b658
    // 0x63b604: fcmp            d0, d0
    // 0x63b608: b.vs            #0x63b650
    // 0x63b60c: ldr             x1, [fp, #0x18]
    // 0x63b610: LoadField: d0 = r1->field_63
    //     0x63b610: ldur            d0, [x1, #0x63]
    // 0x63b614: LoadField: d1 = r0->field_7
    //     0x63b614: ldur            d1, [x0, #7]
    // 0x63b618: fmul            d2, d1, d0
    // 0x63b61c: r0 = inline_Allocate_Double()
    //     0x63b61c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63b620: add             x0, x0, #0x10
    //     0x63b624: cmp             x1, x0
    //     0x63b628: b.ls            #0x63b6cc
    //     0x63b62c: str             x0, [THR, #0x60]  ; THR::top
    //     0x63b630: sub             x0, x0, #0xf
    //     0x63b634: mov             x1, #0xd108
    //     0x63b638: movk            x1, #3, lsl #16
    //     0x63b63c: stur            x1, [x0, #-1]
    // 0x63b640: StoreField: r0->field_7 = d2
    //     0x63b640: stur            d2, [x0, #7]
    // 0x63b644: LeaveFrame
    //     0x63b644: mov             SP, fp
    //     0x63b648: ldp             fp, lr, [SP], #0x10
    // 0x63b64c: ret
    //     0x63b64c: ret             
    // 0x63b650: ldr             x1, [fp, #0x18]
    // 0x63b654: b               #0x63b65c
    // 0x63b658: ldr             x1, [fp, #0x18]
    // 0x63b65c: LoadField: r2 = r1->field_5f
    //     0x63b65c: ldur            w2, [x1, #0x5f]
    // 0x63b660: DecompressPointer r2
    //     0x63b660: add             x2, x2, HEAP, lsl #32
    // 0x63b664: cmp             w2, NULL
    // 0x63b668: b.eq            #0x63b6b4
    // 0x63b66c: LoadField: d0 = r0->field_7
    //     0x63b66c: ldur            d0, [x0, #7]
    // 0x63b670: SaveReg r2
    //     0x63b670: str             x2, [SP, #-8]!
    // 0x63b674: SaveReg d0
    //     0x63b674: str             d0, [SP, #-8]!
    // 0x63b678: r0 = getMinIntrinsicWidth()
    //     0x63b678: bl              #0x630b18  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicWidth
    // 0x63b67c: add             SP, SP, #0x10
    // 0x63b680: r0 = inline_Allocate_Double()
    //     0x63b680: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63b684: add             x0, x0, #0x10
    //     0x63b688: cmp             x1, x0
    //     0x63b68c: b.ls            #0x63b6dc
    //     0x63b690: str             x0, [THR, #0x60]  ; THR::top
    //     0x63b694: sub             x0, x0, #0xf
    //     0x63b698: mov             x1, #0xd108
    //     0x63b69c: movk            x1, #3, lsl #16
    //     0x63b6a0: stur            x1, [x0, #-1]
    // 0x63b6a4: StoreField: r0->field_7 = d0
    //     0x63b6a4: stur            d0, [x0, #7]
    // 0x63b6a8: LeaveFrame
    //     0x63b6a8: mov             SP, fp
    //     0x63b6ac: ldp             fp, lr, [SP], #0x10
    // 0x63b6b0: ret
    //     0x63b6b0: ret             
    // 0x63b6b4: r0 = 0.000000
    //     0x63b6b4: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x63b6b8: LeaveFrame
    //     0x63b6b8: mov             SP, fp
    //     0x63b6bc: ldp             fp, lr, [SP], #0x10
    // 0x63b6c0: ret
    //     0x63b6c0: ret             
    // 0x63b6c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63b6c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63b6c8: b               #0x63b5e8
    // 0x63b6cc: SaveReg d2
    //     0x63b6cc: str             q2, [SP, #-0x10]!
    // 0x63b6d0: r0 = AllocateDouble()
    //     0x63b6d0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63b6d4: RestoreReg d2
    //     0x63b6d4: ldr             q2, [SP], #0x10
    // 0x63b6d8: b               #0x63b640
    // 0x63b6dc: SaveReg d0
    //     0x63b6dc: str             q0, [SP, #-0x10]!
    // 0x63b6e0: r0 = AllocateDouble()
    //     0x63b6e0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63b6e4: RestoreReg d0
    //     0x63b6e4: ldr             q0, [SP], #0x10
    // 0x63b6e8: b               #0x63b6a4
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x68f398, size: 0x140
    // 0x68f398: EnterFrame
    //     0x68f398: stp             fp, lr, [SP, #-0x10]!
    //     0x68f39c: mov             fp, SP
    // 0x68f3a0: AllocStack(0x18)
    //     0x68f3a0: sub             SP, SP, #0x18
    // 0x68f3a4: CheckStackOverflow
    //     0x68f3a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68f3a8: cmp             SP, x16
    //     0x68f3ac: b.ls            #0x68f4d0
    // 0x68f3b0: ldr             x3, [fp, #0x10]
    // 0x68f3b4: LoadField: r4 = r3->field_27
    //     0x68f3b4: ldur            w4, [x3, #0x27]
    // 0x68f3b8: DecompressPointer r4
    //     0x68f3b8: add             x4, x4, HEAP, lsl #32
    // 0x68f3bc: stur            x4, [fp, #-8]
    // 0x68f3c0: cmp             w4, NULL
    // 0x68f3c4: b.eq            #0x68f4b0
    // 0x68f3c8: mov             x0, x4
    // 0x68f3cc: r2 = Null
    //     0x68f3cc: mov             x2, NULL
    // 0x68f3d0: r1 = Null
    //     0x68f3d0: mov             x1, NULL
    // 0x68f3d4: r4 = LoadClassIdInstr(r0)
    //     0x68f3d4: ldur            x4, [x0, #-1]
    //     0x68f3d8: ubfx            x4, x4, #0xc, #0x14
    // 0x68f3dc: sub             x4, x4, #0x80d
    // 0x68f3e0: cmp             x4, #1
    // 0x68f3e4: b.ls            #0x68f3fc
    // 0x68f3e8: r8 = BoxConstraints
    //     0x68f3e8: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x68f3ec: ldr             x8, [x8, #0x1d0]
    // 0x68f3f0: r3 = Null
    //     0x68f3f0: add             x3, PP, #0x37, lsl #12  ; [pp+0x37050] Null
    //     0x68f3f4: ldr             x3, [x3, #0x50]
    // 0x68f3f8: r0 = BoxConstraints()
    //     0x68f3f8: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x68f3fc: ldr             x16, [fp, #0x10]
    // 0x68f400: ldur            lr, [fp, #-8]
    // 0x68f404: stp             lr, x16, [SP, #-0x10]!
    // 0x68f408: r0 = _applyAspectRatio()
    //     0x68f408: bl              #0x68f4d8  ; [package:flutter/src/rendering/proxy_box.dart] RenderAspectRatio::_applyAspectRatio
    // 0x68f40c: add             SP, SP, #0x10
    // 0x68f410: mov             x2, x0
    // 0x68f414: ldr             x1, [fp, #0x10]
    // 0x68f418: stur            x2, [fp, #-0x10]
    // 0x68f41c: StoreField: r1->field_57 = r0
    //     0x68f41c: stur            w0, [x1, #0x57]
    //     0x68f420: ldurb           w16, [x1, #-1]
    //     0x68f424: ldurb           w17, [x0, #-1]
    //     0x68f428: and             x16, x17, x16, lsr #2
    //     0x68f42c: tst             x16, HEAP, lsr #32
    //     0x68f430: b.eq            #0x68f438
    //     0x68f434: bl              #0xd6826c
    // 0x68f438: LoadField: r0 = r1->field_5f
    //     0x68f438: ldur            w0, [x1, #0x5f]
    // 0x68f43c: DecompressPointer r0
    //     0x68f43c: add             x0, x0, HEAP, lsl #32
    // 0x68f440: stur            x0, [fp, #-8]
    // 0x68f444: cmp             w0, NULL
    // 0x68f448: b.eq            #0x68f4a0
    // 0x68f44c: LoadField: d0 = r2->field_7
    //     0x68f44c: ldur            d0, [x2, #7]
    // 0x68f450: stur            d0, [fp, #-0x18]
    // 0x68f454: r0 = BoxConstraints()
    //     0x68f454: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x68f458: ldur            d0, [fp, #-0x18]
    // 0x68f45c: StoreField: r0->field_7 = d0
    //     0x68f45c: stur            d0, [x0, #7]
    // 0x68f460: StoreField: r0->field_f = d0
    //     0x68f460: stur            d0, [x0, #0xf]
    // 0x68f464: ldur            x1, [fp, #-0x10]
    // 0x68f468: LoadField: d0 = r1->field_f
    //     0x68f468: ldur            d0, [x1, #0xf]
    // 0x68f46c: StoreField: r0->field_17 = d0
    //     0x68f46c: stur            d0, [x0, #0x17]
    // 0x68f470: StoreField: r0->field_1f = d0
    //     0x68f470: stur            d0, [x0, #0x1f]
    // 0x68f474: ldur            x1, [fp, #-8]
    // 0x68f478: r2 = LoadClassIdInstr(r1)
    //     0x68f478: ldur            x2, [x1, #-1]
    //     0x68f47c: ubfx            x2, x2, #0xc, #0x14
    // 0x68f480: stp             x0, x1, [SP, #-0x10]!
    // 0x68f484: mov             x0, x2
    // 0x68f488: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x68f488: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x68f48c: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x68f48c: mov             x17, #0xcdfb
    //     0x68f490: add             lr, x0, x17
    //     0x68f494: ldr             lr, [x21, lr, lsl #3]
    //     0x68f498: blr             lr
    // 0x68f49c: add             SP, SP, #0x10
    // 0x68f4a0: r0 = Null
    //     0x68f4a0: mov             x0, NULL
    // 0x68f4a4: LeaveFrame
    //     0x68f4a4: mov             SP, fp
    //     0x68f4a8: ldp             fp, lr, [SP], #0x10
    // 0x68f4ac: ret
    //     0x68f4ac: ret             
    // 0x68f4b0: r0 = StateError()
    //     0x68f4b0: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68f4b4: mov             x1, x0
    // 0x68f4b8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68f4b8: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68f4bc: ldr             x0, [x0, #0x1e8]
    // 0x68f4c0: StoreField: r1->field_b = r0
    //     0x68f4c0: stur            w0, [x1, #0xb]
    // 0x68f4c4: mov             x0, x1
    // 0x68f4c8: r0 = Throw()
    //     0x68f4c8: bl              #0xd67e38  ; ThrowStub
    // 0x68f4cc: brk             #0
    // 0x68f4d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68f4d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68f4d4: b               #0x68f3b0
  }
  _ _applyAspectRatio(/* No info */) {
    // ** addr: 0x68f4d8, size: 0x178
    // 0x68f4d8: EnterFrame
    //     0x68f4d8: stp             fp, lr, [SP, #-0x10]!
    //     0x68f4dc: mov             fp, SP
    // 0x68f4e0: AllocStack(0x10)
    //     0x68f4e0: sub             SP, SP, #0x10
    // 0x68f4e4: CheckStackOverflow
    //     0x68f4e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68f4e8: cmp             SP, x16
    //     0x68f4ec: b.ls            #0x68f648
    // 0x68f4f0: ldr             x0, [fp, #0x10]
    // 0x68f4f4: LoadField: d0 = r0->field_7
    //     0x68f4f4: ldur            d0, [x0, #7]
    // 0x68f4f8: LoadField: d1 = r0->field_f
    //     0x68f4f8: ldur            d1, [x0, #0xf]
    // 0x68f4fc: fcmp            d0, d1
    // 0x68f500: b.vs            #0x68f534
    // 0x68f504: b.lt            #0x68f534
    // 0x68f508: LoadField: d2 = r0->field_17
    //     0x68f508: ldur            d2, [x0, #0x17]
    // 0x68f50c: LoadField: d3 = r0->field_1f
    //     0x68f50c: ldur            d3, [x0, #0x1f]
    // 0x68f510: fcmp            d2, d3
    // 0x68f514: b.vs            #0x68f534
    // 0x68f518: b.lt            #0x68f534
    // 0x68f51c: SaveReg r0
    //     0x68f51c: str             x0, [SP, #-8]!
    // 0x68f520: r0 = smallest()
    //     0x68f520: bl              #0x62bd18  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0x68f524: add             SP, SP, #8
    // 0x68f528: LeaveFrame
    //     0x68f528: mov             SP, fp
    //     0x68f52c: ldp             fp, lr, [SP], #0x10
    // 0x68f530: ret
    //     0x68f530: ret             
    // 0x68f534: mov             x1, v1.d[0]
    // 0x68f538: and             x1, x1, #0x7fffffffffffffff
    // 0x68f53c: r17 = 9218868437227405312
    //     0x68f53c: mov             x17, #0x7ff0000000000000
    // 0x68f540: cmp             x1, x17
    // 0x68f544: b.eq            #0x68f56c
    // 0x68f548: fcmp            d1, d1
    // 0x68f54c: b.vs            #0x68f564
    // 0x68f550: ldr             x1, [fp, #0x18]
    // 0x68f554: LoadField: d2 = r1->field_63
    //     0x68f554: ldur            d2, [x1, #0x63]
    // 0x68f558: fdiv            d3, d1, d2
    // 0x68f55c: mov             v4.16b, v1.16b
    // 0x68f560: b               #0x68f588
    // 0x68f564: ldr             x1, [fp, #0x18]
    // 0x68f568: b               #0x68f570
    // 0x68f56c: ldr             x1, [fp, #0x18]
    // 0x68f570: LoadField: d2 = r0->field_1f
    //     0x68f570: ldur            d2, [x0, #0x1f]
    // 0x68f574: LoadField: d3 = r1->field_63
    //     0x68f574: ldur            d3, [x1, #0x63]
    // 0x68f578: fmul            d4, d2, d3
    // 0x68f57c: mov             v31.16b, v3.16b
    // 0x68f580: mov             v3.16b, v2.16b
    // 0x68f584: mov             v2.16b, v31.16b
    // 0x68f588: fcmp            d4, d1
    // 0x68f58c: b.vs            #0x68f5a8
    // 0x68f590: b.le            #0x68f5a8
    // 0x68f594: fdiv            d3, d1, d2
    // 0x68f598: mov             v31.16b, v3.16b
    // 0x68f59c: mov             v3.16b, v1.16b
    // 0x68f5a0: mov             v1.16b, v31.16b
    // 0x68f5a4: b               #0x68f5b0
    // 0x68f5a8: mov             v1.16b, v3.16b
    // 0x68f5ac: mov             v3.16b, v4.16b
    // 0x68f5b0: LoadField: d4 = r0->field_1f
    //     0x68f5b0: ldur            d4, [x0, #0x1f]
    // 0x68f5b4: fcmp            d1, d4
    // 0x68f5b8: b.vs            #0x68f5cc
    // 0x68f5bc: b.le            #0x68f5cc
    // 0x68f5c0: fmul            d1, d4, d2
    // 0x68f5c4: mov             v3.16b, v1.16b
    // 0x68f5c8: mov             v1.16b, v4.16b
    // 0x68f5cc: fcmp            d3, d0
    // 0x68f5d0: b.vs            #0x68f5ec
    // 0x68f5d4: b.ge            #0x68f5ec
    // 0x68f5d8: fdiv            d1, d0, d2
    // 0x68f5dc: mov             v31.16b, v1.16b
    // 0x68f5e0: mov             v1.16b, v0.16b
    // 0x68f5e4: mov             v0.16b, v31.16b
    // 0x68f5e8: b               #0x68f5f4
    // 0x68f5ec: mov             v0.16b, v1.16b
    // 0x68f5f0: mov             v1.16b, v3.16b
    // 0x68f5f4: LoadField: d3 = r0->field_17
    //     0x68f5f4: ldur            d3, [x0, #0x17]
    // 0x68f5f8: fcmp            d0, d3
    // 0x68f5fc: b.vs            #0x68f610
    // 0x68f600: b.ge            #0x68f610
    // 0x68f604: fmul            d0, d3, d2
    // 0x68f608: mov             v1.16b, v0.16b
    // 0x68f60c: mov             v0.16b, v3.16b
    // 0x68f610: stur            d1, [fp, #-8]
    // 0x68f614: stur            d0, [fp, #-0x10]
    // 0x68f618: r0 = Size()
    //     0x68f618: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x68f61c: ldur            d0, [fp, #-8]
    // 0x68f620: StoreField: r0->field_7 = d0
    //     0x68f620: stur            d0, [x0, #7]
    // 0x68f624: ldur            d0, [fp, #-0x10]
    // 0x68f628: StoreField: r0->field_f = d0
    //     0x68f628: stur            d0, [x0, #0xf]
    // 0x68f62c: ldr             x16, [fp, #0x10]
    // 0x68f630: stp             x0, x16, [SP, #-0x10]!
    // 0x68f634: r0 = constrain()
    //     0x68f634: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x68f638: add             SP, SP, #0x10
    // 0x68f63c: LeaveFrame
    //     0x68f63c: mov             SP, fp
    //     0x68f640: ldp             fp, lr, [SP], #0x10
    // 0x68f644: ret
    //     0x68f644: ret             
    // 0x68f648: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68f648: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68f64c: b               #0x68f4f0
  }
  set _ aspectRatio=(/* No info */) {
    // ** addr: 0x6c64b8, size: 0x64
    // 0x6c64b8: EnterFrame
    //     0x6c64b8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c64bc: mov             fp, SP
    // 0x6c64c0: CheckStackOverflow
    //     0x6c64c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c64c4: cmp             SP, x16
    //     0x6c64c8: b.ls            #0x6c6514
    // 0x6c64cc: ldr             x0, [fp, #0x18]
    // 0x6c64d0: LoadField: d0 = r0->field_63
    //     0x6c64d0: ldur            d0, [x0, #0x63]
    // 0x6c64d4: ldr             d1, [fp, #0x10]
    // 0x6c64d8: fcmp            d0, d1
    // 0x6c64dc: b.vs            #0x6c64f4
    // 0x6c64e0: b.ne            #0x6c64f4
    // 0x6c64e4: r0 = Null
    //     0x6c64e4: mov             x0, NULL
    // 0x6c64e8: LeaveFrame
    //     0x6c64e8: mov             SP, fp
    //     0x6c64ec: ldp             fp, lr, [SP], #0x10
    // 0x6c64f0: ret
    //     0x6c64f0: ret             
    // 0x6c64f4: StoreField: r0->field_63 = d1
    //     0x6c64f4: stur            d1, [x0, #0x63]
    // 0x6c64f8: SaveReg r0
    //     0x6c64f8: str             x0, [SP, #-8]!
    // 0x6c64fc: r0 = markNeedsLayout()
    //     0x6c64fc: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c6500: add             SP, SP, #8
    // 0x6c6504: r0 = Null
    //     0x6c6504: mov             x0, NULL
    // 0x6c6508: LeaveFrame
    //     0x6c6508: mov             SP, fp
    //     0x6c650c: ldp             fp, lr, [SP], #0x10
    // 0x6c6510: ret
    //     0x6c6510: ret             
    // 0x6c6514: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6514: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c6518: b               #0x6c64cc
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5d72c, size: 0x3c
    // 0xa5d72c: EnterFrame
    //     0xa5d72c: stp             fp, lr, [SP, #-0x10]!
    //     0xa5d730: mov             fp, SP
    // 0xa5d734: CheckStackOverflow
    //     0xa5d734: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5d738: cmp             SP, x16
    //     0xa5d73c: b.ls            #0xa5d760
    // 0xa5d740: ldr             x16, [fp, #0x18]
    // 0xa5d744: ldr             lr, [fp, #0x10]
    // 0xa5d748: stp             lr, x16, [SP, #-0x10]!
    // 0xa5d74c: r0 = _applyAspectRatio()
    //     0xa5d74c: bl              #0x68f4d8  ; [package:flutter/src/rendering/proxy_box.dart] RenderAspectRatio::_applyAspectRatio
    // 0xa5d750: add             SP, SP, #0x10
    // 0xa5d754: LeaveFrame
    //     0xa5d754: mov             SP, fp
    //     0xa5d758: ldp             fp, lr, [SP], #0x10
    // 0xa5d75c: ret
    //     0xa5d75c: ret             
    // 0xa5d760: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5d760: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5d764: b               #0xa5d740
  }
}

// class id: 2512, size: 0x74, field offset: 0x64
class RenderLimitedBox extends RenderProxyBox {

  _ performLayout(/* No info */) {
    // ** addr: 0x68f120, size: 0xdc
    // 0x68f120: EnterFrame
    //     0x68f120: stp             fp, lr, [SP, #-0x10]!
    //     0x68f124: mov             fp, SP
    // 0x68f128: AllocStack(0x8)
    //     0x68f128: sub             SP, SP, #8
    // 0x68f12c: CheckStackOverflow
    //     0x68f12c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68f130: cmp             SP, x16
    //     0x68f134: b.ls            #0x68f1f4
    // 0x68f138: ldr             x3, [fp, #0x10]
    // 0x68f13c: LoadField: r4 = r3->field_27
    //     0x68f13c: ldur            w4, [x3, #0x27]
    // 0x68f140: DecompressPointer r4
    //     0x68f140: add             x4, x4, HEAP, lsl #32
    // 0x68f144: stur            x4, [fp, #-8]
    // 0x68f148: cmp             w4, NULL
    // 0x68f14c: b.eq            #0x68f1d4
    // 0x68f150: mov             x0, x4
    // 0x68f154: r2 = Null
    //     0x68f154: mov             x2, NULL
    // 0x68f158: r1 = Null
    //     0x68f158: mov             x1, NULL
    // 0x68f15c: r4 = LoadClassIdInstr(r0)
    //     0x68f15c: ldur            x4, [x0, #-1]
    //     0x68f160: ubfx            x4, x4, #0xc, #0x14
    // 0x68f164: sub             x4, x4, #0x80d
    // 0x68f168: cmp             x4, #1
    // 0x68f16c: b.ls            #0x68f184
    // 0x68f170: r8 = BoxConstraints
    //     0x68f170: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x68f174: ldr             x8, [x8, #0x1d0]
    // 0x68f178: r3 = Null
    //     0x68f178: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1cf70] Null
    //     0x68f17c: ldr             x3, [x3, #0xf70]
    // 0x68f180: r0 = BoxConstraints()
    //     0x68f180: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x68f184: ldr             x16, [fp, #0x10]
    // 0x68f188: ldur            lr, [fp, #-8]
    // 0x68f18c: stp             lr, x16, [SP, #-0x10]!
    // 0x68f190: r16 = Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static.
    //     0x68f190: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cf80] Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static. (0x7fe6e1e8aefc)
    //     0x68f194: ldr             x16, [x16, #0xf80]
    // 0x68f198: SaveReg r16
    //     0x68f198: str             x16, [SP, #-8]!
    // 0x68f19c: r0 = _computeSize()
    //     0x68f19c: bl              #0x68f1fc  ; [package:flutter/src/rendering/proxy_box.dart] RenderLimitedBox::_computeSize
    // 0x68f1a0: add             SP, SP, #0x18
    // 0x68f1a4: ldr             x1, [fp, #0x10]
    // 0x68f1a8: StoreField: r1->field_57 = r0
    //     0x68f1a8: stur            w0, [x1, #0x57]
    //     0x68f1ac: ldurb           w16, [x1, #-1]
    //     0x68f1b0: ldurb           w17, [x0, #-1]
    //     0x68f1b4: and             x16, x17, x16, lsr #2
    //     0x68f1b8: tst             x16, HEAP, lsr #32
    //     0x68f1bc: b.eq            #0x68f1c4
    //     0x68f1c0: bl              #0xd6826c
    // 0x68f1c4: r0 = Null
    //     0x68f1c4: mov             x0, NULL
    // 0x68f1c8: LeaveFrame
    //     0x68f1c8: mov             SP, fp
    //     0x68f1cc: ldp             fp, lr, [SP], #0x10
    // 0x68f1d0: ret
    //     0x68f1d0: ret             
    // 0x68f1d4: r0 = StateError()
    //     0x68f1d4: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68f1d8: mov             x1, x0
    // 0x68f1dc: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68f1dc: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68f1e0: ldr             x0, [x0, #0x1e8]
    // 0x68f1e4: StoreField: r1->field_b = r0
    //     0x68f1e4: stur            w0, [x1, #0xb]
    // 0x68f1e8: mov             x0, x1
    // 0x68f1ec: r0 = Throw()
    //     0x68f1ec: bl              #0xd67e38  ; ThrowStub
    // 0x68f1f0: brk             #0
    // 0x68f1f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68f1f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68f1f8: b               #0x68f138
  }
  _ _computeSize(/* No info */) {
    // ** addr: 0x68f1fc, size: 0xb4
    // 0x68f1fc: EnterFrame
    //     0x68f1fc: stp             fp, lr, [SP, #-0x10]!
    //     0x68f200: mov             fp, SP
    // 0x68f204: AllocStack(0x8)
    //     0x68f204: sub             SP, SP, #8
    // 0x68f208: CheckStackOverflow
    //     0x68f208: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68f20c: cmp             SP, x16
    //     0x68f210: b.ls            #0x68f2a8
    // 0x68f214: ldr             x0, [fp, #0x20]
    // 0x68f218: LoadField: r1 = r0->field_5f
    //     0x68f218: ldur            w1, [x0, #0x5f]
    // 0x68f21c: DecompressPointer r1
    //     0x68f21c: add             x1, x1, HEAP, lsl #32
    // 0x68f220: stur            x1, [fp, #-8]
    // 0x68f224: cmp             w1, NULL
    // 0x68f228: b.eq            #0x68f27c
    // 0x68f22c: ldr             x16, [fp, #0x18]
    // 0x68f230: stp             x16, x0, [SP, #-0x10]!
    // 0x68f234: r0 = _limitConstraints()
    //     0x68f234: bl              #0x68f2b0  ; [package:flutter/src/rendering/proxy_box.dart] RenderLimitedBox::_limitConstraints
    // 0x68f238: add             SP, SP, #0x10
    // 0x68f23c: ldr             x16, [fp, #0x10]
    // 0x68f240: ldur            lr, [fp, #-8]
    // 0x68f244: stp             lr, x16, [SP, #-0x10]!
    // 0x68f248: SaveReg r0
    //     0x68f248: str             x0, [SP, #-8]!
    // 0x68f24c: ldr             x0, [fp, #0x10]
    // 0x68f250: ClosureCall
    //     0x68f250: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x68f254: ldur            x2, [x0, #0x1f]
    //     0x68f258: blr             x2
    // 0x68f25c: add             SP, SP, #0x18
    // 0x68f260: ldr             x16, [fp, #0x18]
    // 0x68f264: stp             x0, x16, [SP, #-0x10]!
    // 0x68f268: r0 = constrain()
    //     0x68f268: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x68f26c: add             SP, SP, #0x10
    // 0x68f270: LeaveFrame
    //     0x68f270: mov             SP, fp
    //     0x68f274: ldp             fp, lr, [SP], #0x10
    // 0x68f278: ret
    //     0x68f278: ret             
    // 0x68f27c: ldr             x16, [fp, #0x18]
    // 0x68f280: stp             x16, x0, [SP, #-0x10]!
    // 0x68f284: r0 = _limitConstraints()
    //     0x68f284: bl              #0x68f2b0  ; [package:flutter/src/rendering/proxy_box.dart] RenderLimitedBox::_limitConstraints
    // 0x68f288: add             SP, SP, #0x10
    // 0x68f28c: r16 = Instance_Size
    //     0x68f28c: ldr             x16, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0x68f290: stp             x16, x0, [SP, #-0x10]!
    // 0x68f294: r0 = constrain()
    //     0x68f294: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x68f298: add             SP, SP, #0x10
    // 0x68f29c: LeaveFrame
    //     0x68f29c: mov             SP, fp
    //     0x68f2a0: ldp             fp, lr, [SP], #0x10
    // 0x68f2a4: ret
    //     0x68f2a4: ret             
    // 0x68f2a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68f2a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68f2ac: b               #0x68f214
  }
  _ _limitConstraints(/* No info */) {
    // ** addr: 0x68f2b0, size: 0xe8
    // 0x68f2b0: EnterFrame
    //     0x68f2b0: stp             fp, lr, [SP, #-0x10]!
    //     0x68f2b4: mov             fp, SP
    // 0x68f2b8: AllocStack(0x20)
    //     0x68f2b8: sub             SP, SP, #0x20
    // 0x68f2bc: d0 = inf
    //     0x68f2bc: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x68f2c0: CheckStackOverflow
    //     0x68f2c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68f2c4: cmp             SP, x16
    //     0x68f2c8: b.ls            #0x68f390
    // 0x68f2cc: ldr             x0, [fp, #0x10]
    // 0x68f2d0: LoadField: d1 = r0->field_7
    //     0x68f2d0: ldur            d1, [x0, #7]
    // 0x68f2d4: stur            d1, [fp, #-8]
    // 0x68f2d8: LoadField: d2 = r0->field_f
    //     0x68f2d8: ldur            d2, [x0, #0xf]
    // 0x68f2dc: fcmp            d2, d0
    // 0x68f2e0: b.vs            #0x68f2f0
    // 0x68f2e4: b.ge            #0x68f2f0
    // 0x68f2e8: mov             v1.16b, v2.16b
    // 0x68f2ec: b               #0x68f310
    // 0x68f2f0: r16 = 0.000000
    //     0x68f2f0: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x68f2f4: stp             x16, x0, [SP, #-0x10]!
    // 0x68f2f8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x68f2f8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x68f2fc: r0 = constrainWidth()
    //     0x68f2fc: bl              #0x62bc8c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0x68f300: add             SP, SP, #0x10
    // 0x68f304: mov             v1.16b, v0.16b
    // 0x68f308: ldr             x0, [fp, #0x10]
    // 0x68f30c: d0 = inf
    //     0x68f30c: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x68f310: stur            d1, [fp, #-0x18]
    // 0x68f314: LoadField: d2 = r0->field_17
    //     0x68f314: ldur            d2, [x0, #0x17]
    // 0x68f318: stur            d2, [fp, #-0x10]
    // 0x68f31c: LoadField: d3 = r0->field_1f
    //     0x68f31c: ldur            d3, [x0, #0x1f]
    // 0x68f320: fcmp            d3, d0
    // 0x68f324: b.vs            #0x68f338
    // 0x68f328: b.ge            #0x68f338
    // 0x68f32c: mov             v0.16b, v1.16b
    // 0x68f330: mov             v1.16b, v2.16b
    // 0x68f334: b               #0x68f358
    // 0x68f338: r16 = 0.000000
    //     0x68f338: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x68f33c: stp             x16, x0, [SP, #-0x10]!
    // 0x68f340: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x68f340: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x68f344: r0 = constrainHeight()
    //     0x68f344: bl              #0x62bc00  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0x68f348: add             SP, SP, #0x10
    // 0x68f34c: mov             v3.16b, v0.16b
    // 0x68f350: ldur            d0, [fp, #-0x18]
    // 0x68f354: ldur            d1, [fp, #-0x10]
    // 0x68f358: ldur            d2, [fp, #-8]
    // 0x68f35c: stur            d3, [fp, #-0x20]
    // 0x68f360: r0 = BoxConstraints()
    //     0x68f360: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x68f364: ldur            d0, [fp, #-8]
    // 0x68f368: StoreField: r0->field_7 = d0
    //     0x68f368: stur            d0, [x0, #7]
    // 0x68f36c: ldur            d0, [fp, #-0x18]
    // 0x68f370: StoreField: r0->field_f = d0
    //     0x68f370: stur            d0, [x0, #0xf]
    // 0x68f374: ldur            d0, [fp, #-0x10]
    // 0x68f378: StoreField: r0->field_17 = d0
    //     0x68f378: stur            d0, [x0, #0x17]
    // 0x68f37c: ldur            d0, [fp, #-0x20]
    // 0x68f380: StoreField: r0->field_1f = d0
    //     0x68f380: stur            d0, [x0, #0x1f]
    // 0x68f384: LeaveFrame
    //     0x68f384: mov             SP, fp
    //     0x68f388: ldp             fp, lr, [SP], #0x10
    // 0x68f38c: ret
    //     0x68f38c: ret             
    // 0x68f390: r0 = StackOverflowSharedWithFPURegs()
    //     0x68f390: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x68f394: b               #0x68f2cc
  }
  set _ maxHeight=(/* No info */) {
    // ** addr: 0x6c60d0, size: 0x60
    // 0x6c60d0: EnterFrame
    //     0x6c60d0: stp             fp, lr, [SP, #-0x10]!
    //     0x6c60d4: mov             fp, SP
    // 0x6c60d8: d0 = 0.000000
    //     0x6c60d8: eor             v0.16b, v0.16b, v0.16b
    // 0x6c60dc: CheckStackOverflow
    //     0x6c60dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c60e0: cmp             SP, x16
    //     0x6c60e4: b.ls            #0x6c6128
    // 0x6c60e8: fcmp            d0, d0
    // 0x6c60ec: b.vs            #0x6c6104
    // 0x6c60f0: b.ne            #0x6c6104
    // 0x6c60f4: r0 = Null
    //     0x6c60f4: mov             x0, NULL
    // 0x6c60f8: LeaveFrame
    //     0x6c60f8: mov             SP, fp
    //     0x6c60fc: ldp             fp, lr, [SP], #0x10
    // 0x6c6100: ret
    //     0x6c6100: ret             
    // 0x6c6104: ldr             x0, [fp, #0x18]
    // 0x6c6108: StoreField: r0->field_6b = d0
    //     0x6c6108: stur            d0, [x0, #0x6b]
    // 0x6c610c: SaveReg r0
    //     0x6c610c: str             x0, [SP, #-8]!
    // 0x6c6110: r0 = markNeedsLayout()
    //     0x6c6110: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c6114: add             SP, SP, #8
    // 0x6c6118: r0 = Null
    //     0x6c6118: mov             x0, NULL
    // 0x6c611c: LeaveFrame
    //     0x6c611c: mov             SP, fp
    //     0x6c6120: ldp             fp, lr, [SP], #0x10
    // 0x6c6124: ret
    //     0x6c6124: ret             
    // 0x6c6128: r0 = StackOverflowSharedWithFPURegs()
    //     0x6c6128: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x6c612c: b               #0x6c60e8
  }
  set _ maxWidth=(/* No info */) {
    // ** addr: 0x6c6130, size: 0x60
    // 0x6c6130: EnterFrame
    //     0x6c6130: stp             fp, lr, [SP, #-0x10]!
    //     0x6c6134: mov             fp, SP
    // 0x6c6138: d0 = 0.000000
    //     0x6c6138: eor             v0.16b, v0.16b, v0.16b
    // 0x6c613c: CheckStackOverflow
    //     0x6c613c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c6140: cmp             SP, x16
    //     0x6c6144: b.ls            #0x6c6188
    // 0x6c6148: fcmp            d0, d0
    // 0x6c614c: b.vs            #0x6c6164
    // 0x6c6150: b.ne            #0x6c6164
    // 0x6c6154: r0 = Null
    //     0x6c6154: mov             x0, NULL
    // 0x6c6158: LeaveFrame
    //     0x6c6158: mov             SP, fp
    //     0x6c615c: ldp             fp, lr, [SP], #0x10
    // 0x6c6160: ret
    //     0x6c6160: ret             
    // 0x6c6164: ldr             x0, [fp, #0x18]
    // 0x6c6168: StoreField: r0->field_63 = d0
    //     0x6c6168: stur            d0, [x0, #0x63]
    // 0x6c616c: SaveReg r0
    //     0x6c616c: str             x0, [SP, #-8]!
    // 0x6c6170: r0 = markNeedsLayout()
    //     0x6c6170: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c6174: add             SP, SP, #8
    // 0x6c6178: r0 = Null
    //     0x6c6178: mov             x0, NULL
    // 0x6c617c: LeaveFrame
    //     0x6c617c: mov             SP, fp
    //     0x6c6180: ldp             fp, lr, [SP], #0x10
    // 0x6c6184: ret
    //     0x6c6184: ret             
    // 0x6c6188: r0 = StackOverflowSharedWithFPURegs()
    //     0x6c6188: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x6c618c: b               #0x6c6148
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5d6e4, size: 0x48
    // 0xa5d6e4: EnterFrame
    //     0xa5d6e4: stp             fp, lr, [SP, #-0x10]!
    //     0xa5d6e8: mov             fp, SP
    // 0xa5d6ec: CheckStackOverflow
    //     0xa5d6ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5d6f0: cmp             SP, x16
    //     0xa5d6f4: b.ls            #0xa5d724
    // 0xa5d6f8: ldr             x16, [fp, #0x18]
    // 0xa5d6fc: ldr             lr, [fp, #0x10]
    // 0xa5d700: stp             lr, x16, [SP, #-0x10]!
    // 0xa5d704: r16 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xa5d704: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cf88] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7fe6e1e33c20)
    //     0xa5d708: ldr             x16, [x16, #0xf88]
    // 0xa5d70c: SaveReg r16
    //     0xa5d70c: str             x16, [SP, #-8]!
    // 0xa5d710: r0 = _computeSize()
    //     0xa5d710: bl              #0x68f1fc  ; [package:flutter/src/rendering/proxy_box.dart] RenderLimitedBox::_computeSize
    // 0xa5d714: add             SP, SP, #0x18
    // 0xa5d718: LeaveFrame
    //     0xa5d718: mov             SP, fp
    //     0xa5d71c: ldp             fp, lr, [SP], #0x10
    // 0xa5d720: ret
    //     0xa5d720: ret             
    // 0xa5d724: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5d724: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5d728: b               #0xa5d6f8
  }
}

// class id: 2513, size: 0x68, field offset: 0x64
abstract class RenderProxyBoxWithHitTestBehavior extends RenderProxyBox {

  _ hitTestSelf(/* No info */) {
    // ** addr: 0x62b678, size: 0x28
    // 0x62b678: ldr             x1, [SP, #8]
    // 0x62b67c: LoadField: r2 = r1->field_63
    //     0x62b67c: ldur            w2, [x1, #0x63]
    // 0x62b680: DecompressPointer r2
    //     0x62b680: add             x2, x2, HEAP, lsl #32
    // 0x62b684: r16 = Instance_HitTestBehavior
    //     0x62b684: add             x16, PP, #0x15, lsl #12  ; [pp+0x15408] Obj!HitTestBehavior@b648f1
    //     0x62b688: ldr             x16, [x16, #0x408]
    // 0x62b68c: cmp             w2, w16
    // 0x62b690: r16 = true
    //     0x62b690: add             x16, NULL, #0x20  ; true
    // 0x62b694: r17 = false
    //     0x62b694: add             x17, NULL, #0x30  ; false
    // 0x62b698: csel            x0, x16, x17, eq
    // 0x62b69c: ret
    //     0x62b69c: ret             
  }
  _ hitTest(/* No info */) {
    // ** addr: 0x63f3a4, size: 0x104
    // 0x63f3a4: EnterFrame
    //     0x63f3a4: stp             fp, lr, [SP, #-0x10]!
    //     0x63f3a8: mov             fp, SP
    // 0x63f3ac: AllocStack(0x8)
    //     0x63f3ac: sub             SP, SP, #8
    // 0x63f3b0: CheckStackOverflow
    //     0x63f3b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63f3b4: cmp             SP, x16
    //     0x63f3b8: b.ls            #0x63f49c
    // 0x63f3bc: ldr             x0, [fp, #0x20]
    // 0x63f3c0: LoadField: r1 = r0->field_57
    //     0x63f3c0: ldur            w1, [x0, #0x57]
    // 0x63f3c4: DecompressPointer r1
    //     0x63f3c4: add             x1, x1, HEAP, lsl #32
    // 0x63f3c8: cmp             w1, NULL
    // 0x63f3cc: b.eq            #0x63f4a4
    // 0x63f3d0: ldr             x16, [fp, #0x10]
    // 0x63f3d4: stp             x16, x1, [SP, #-0x10]!
    // 0x63f3d8: r0 = contains()
    //     0x63f3d8: bl              #0x63f33c  ; [dart:ui] Size::contains
    // 0x63f3dc: add             SP, SP, #0x10
    // 0x63f3e0: tbnz            w0, #4, #0x63f48c
    // 0x63f3e4: ldr             x16, [fp, #0x20]
    // 0x63f3e8: ldr             lr, [fp, #0x18]
    // 0x63f3ec: stp             lr, x16, [SP, #-0x10]!
    // 0x63f3f0: ldr             x16, [fp, #0x10]
    // 0x63f3f4: SaveReg r16
    //     0x63f3f4: str             x16, [SP, #-8]!
    // 0x63f3f8: r0 = hitTestChildren()
    //     0x63f3f8: bl              #0x627748  ; [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::hitTestChildren
    // 0x63f3fc: add             SP, SP, #0x18
    // 0x63f400: tbnz            w0, #4, #0x63f410
    // 0x63f404: ldr             x0, [fp, #0x20]
    // 0x63f408: r2 = true
    //     0x63f408: add             x2, NULL, #0x20  ; true
    // 0x63f40c: b               #0x63f434
    // 0x63f410: ldr             x0, [fp, #0x20]
    // 0x63f414: LoadField: r1 = r0->field_63
    //     0x63f414: ldur            w1, [x0, #0x63]
    // 0x63f418: DecompressPointer r1
    //     0x63f418: add             x1, x1, HEAP, lsl #32
    // 0x63f41c: r16 = Instance_HitTestBehavior
    //     0x63f41c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15408] Obj!HitTestBehavior@b648f1
    //     0x63f420: ldr             x16, [x16, #0x408]
    // 0x63f424: cmp             w1, w16
    // 0x63f428: r16 = true
    //     0x63f428: add             x16, NULL, #0x20  ; true
    // 0x63f42c: r17 = false
    //     0x63f42c: add             x17, NULL, #0x30  ; false
    // 0x63f430: csel            x2, x16, x17, eq
    // 0x63f434: stur            x2, [fp, #-8]
    // 0x63f438: tbz             w2, #4, #0x63f454
    // 0x63f43c: LoadField: r1 = r0->field_63
    //     0x63f43c: ldur            w1, [x0, #0x63]
    // 0x63f440: DecompressPointer r1
    //     0x63f440: add             x1, x1, HEAP, lsl #32
    // 0x63f444: r16 = Instance_HitTestBehavior
    //     0x63f444: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1ced0] Obj!HitTestBehavior@b64911
    //     0x63f448: ldr             x16, [x16, #0xed0]
    // 0x63f44c: cmp             w1, w16
    // 0x63f450: b.ne            #0x63f484
    // 0x63f454: ldr             x3, [fp, #0x10]
    // 0x63f458: r1 = <RenderBox>
    //     0x63f458: ldr             x1, [PP, #0x3b20]  ; [pp+0x3b20] TypeArguments: <RenderBox>
    // 0x63f45c: r0 = BoxHitTestEntry()
    //     0x63f45c: bl              #0x63f330  ; AllocateBoxHitTestEntryStub -> BoxHitTestEntry (size=0x18)
    // 0x63f460: mov             x1, x0
    // 0x63f464: ldr             x0, [fp, #0x10]
    // 0x63f468: StoreField: r1->field_13 = r0
    //     0x63f468: stur            w0, [x1, #0x13]
    // 0x63f46c: ldr             x0, [fp, #0x20]
    // 0x63f470: StoreField: r1->field_b = r0
    //     0x63f470: stur            w0, [x1, #0xb]
    // 0x63f474: ldr             x16, [fp, #0x18]
    // 0x63f478: stp             x1, x16, [SP, #-0x10]!
    // 0x63f47c: r0 = add()
    //     0x63f47c: bl              #0x50ea24  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::add
    // 0x63f480: add             SP, SP, #0x10
    // 0x63f484: ldur            x0, [fp, #-8]
    // 0x63f488: b               #0x63f490
    // 0x63f48c: r0 = false
    //     0x63f48c: add             x0, NULL, #0x30  ; false
    // 0x63f490: LeaveFrame
    //     0x63f490: mov             SP, fp
    //     0x63f494: ldp             fp, lr, [SP], #0x10
    // 0x63f498: ret
    //     0x63f498: ret             
    // 0x63f49c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63f49c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63f4a0: b               #0x63f3bc
    // 0x63f4a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63f4a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2518, size: 0x84, field offset: 0x68
class RenderSemanticsGestureHandler extends RenderProxyBoxWithHitTestBehavior {

  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0x64e374, size: 0x27c
    // 0x64e374: EnterFrame
    //     0x64e374: stp             fp, lr, [SP, #-0x10]!
    //     0x64e378: mov             fp, SP
    // 0x64e37c: CheckStackOverflow
    //     0x64e37c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64e380: cmp             SP, x16
    //     0x64e384: b.ls            #0x64e5e0
    // 0x64e388: ldr             x0, [fp, #0x18]
    // 0x64e38c: LoadField: r1 = r0->field_6b
    //     0x64e38c: ldur            w1, [x0, #0x6b]
    // 0x64e390: DecompressPointer r1
    //     0x64e390: add             x1, x1, HEAP, lsl #32
    // 0x64e394: cmp             w1, NULL
    // 0x64e398: b.eq            #0x64e3dc
    // 0x64e39c: r16 = Instance_SemanticsAction
    //     0x64e39c: ldr             x16, [PP, #0x4850]  ; [pp+0x4850] Obj!SemanticsAction@b5ce01
    // 0x64e3a0: stp             x16, x0, [SP, #-0x10]!
    // 0x64e3a4: r0 = _isValidAction()
    //     0x64e3a4: bl              #0x64e644  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_isValidAction
    // 0x64e3a8: add             SP, SP, #0x10
    // 0x64e3ac: tbnz            w0, #4, #0x64e3dc
    // 0x64e3b0: ldr             x0, [fp, #0x18]
    // 0x64e3b4: LoadField: r1 = r0->field_6b
    //     0x64e3b4: ldur            w1, [x0, #0x6b]
    // 0x64e3b8: DecompressPointer r1
    //     0x64e3b8: add             x1, x1, HEAP, lsl #32
    // 0x64e3bc: cmp             w1, NULL
    // 0x64e3c0: b.eq            #0x64e5e8
    // 0x64e3c4: ldr             x16, [fp, #0x10]
    // 0x64e3c8: r30 = Instance_SemanticsAction
    //     0x64e3c8: ldr             lr, [PP, #0x4850]  ; [pp+0x4850] Obj!SemanticsAction@b5ce01
    // 0x64e3cc: stp             lr, x16, [SP, #-0x10]!
    // 0x64e3d0: SaveReg r1
    //     0x64e3d0: str             x1, [SP, #-8]!
    // 0x64e3d4: r0 = _addArgumentlessAction()
    //     0x64e3d4: bl              #0x6467e0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addArgumentlessAction
    // 0x64e3d8: add             SP, SP, #0x18
    // 0x64e3dc: ldr             x0, [fp, #0x18]
    // 0x64e3e0: LoadField: r1 = r0->field_6f
    //     0x64e3e0: ldur            w1, [x0, #0x6f]
    // 0x64e3e4: DecompressPointer r1
    //     0x64e3e4: add             x1, x1, HEAP, lsl #32
    // 0x64e3e8: cmp             w1, NULL
    // 0x64e3ec: b.eq            #0x64e430
    // 0x64e3f0: r16 = Instance_SemanticsAction
    //     0x64e3f0: ldr             x16, [PP, #0x4858]  ; [pp+0x4858] Obj!SemanticsAction@b5cdf1
    // 0x64e3f4: stp             x16, x0, [SP, #-0x10]!
    // 0x64e3f8: r0 = _isValidAction()
    //     0x64e3f8: bl              #0x64e644  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_isValidAction
    // 0x64e3fc: add             SP, SP, #0x10
    // 0x64e400: tbnz            w0, #4, #0x64e430
    // 0x64e404: ldr             x0, [fp, #0x18]
    // 0x64e408: LoadField: r1 = r0->field_6f
    //     0x64e408: ldur            w1, [x0, #0x6f]
    // 0x64e40c: DecompressPointer r1
    //     0x64e40c: add             x1, x1, HEAP, lsl #32
    // 0x64e410: cmp             w1, NULL
    // 0x64e414: b.eq            #0x64e5ec
    // 0x64e418: ldr             x16, [fp, #0x10]
    // 0x64e41c: r30 = Instance_SemanticsAction
    //     0x64e41c: ldr             lr, [PP, #0x4858]  ; [pp+0x4858] Obj!SemanticsAction@b5cdf1
    // 0x64e420: stp             lr, x16, [SP, #-0x10]!
    // 0x64e424: SaveReg r1
    //     0x64e424: str             x1, [SP, #-8]!
    // 0x64e428: r0 = _addArgumentlessAction()
    //     0x64e428: bl              #0x6467e0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addArgumentlessAction
    // 0x64e42c: add             SP, SP, #0x18
    // 0x64e430: ldr             x0, [fp, #0x18]
    // 0x64e434: LoadField: r1 = r0->field_73
    //     0x64e434: ldur            w1, [x0, #0x73]
    // 0x64e438: DecompressPointer r1
    //     0x64e438: add             x1, x1, HEAP, lsl #32
    // 0x64e43c: cmp             w1, NULL
    // 0x64e440: b.eq            #0x64e500
    // 0x64e444: r16 = Instance_SemanticsAction
    //     0x64e444: add             x16, PP, #0x33, lsl #12  ; [pp+0x33178] Obj!SemanticsAction@b5cdd1
    //     0x64e448: ldr             x16, [x16, #0x178]
    // 0x64e44c: stp             x16, x0, [SP, #-0x10]!
    // 0x64e450: r0 = _isValidAction()
    //     0x64e450: bl              #0x64e644  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_isValidAction
    // 0x64e454: add             SP, SP, #0x10
    // 0x64e458: tbnz            w0, #4, #0x64e4a0
    // 0x64e45c: ldr             x0, [fp, #0x18]
    // 0x64e460: r1 = 1
    //     0x64e460: mov             x1, #1
    // 0x64e464: r0 = AllocateContext()
    //     0x64e464: bl              #0xd68aa4  ; AllocateContextStub
    // 0x64e468: mov             x1, x0
    // 0x64e46c: ldr             x0, [fp, #0x18]
    // 0x64e470: StoreField: r1->field_f = r0
    //     0x64e470: stur            w0, [x1, #0xf]
    // 0x64e474: mov             x2, x1
    // 0x64e478: r1 = Function '_performSemanticScrollRight@907160605':.
    //     0x64e478: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fc68] AnonymousClosure: (0x64ebc4), in [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_performSemanticScrollRight (0x64ec0c)
    //     0x64e47c: ldr             x1, [x1, #0xc68]
    // 0x64e480: r0 = AllocateClosure()
    //     0x64e480: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x64e484: ldr             x16, [fp, #0x10]
    // 0x64e488: r30 = Instance_SemanticsAction
    //     0x64e488: add             lr, PP, #0x33, lsl #12  ; [pp+0x33178] Obj!SemanticsAction@b5cdd1
    //     0x64e48c: ldr             lr, [lr, #0x178]
    // 0x64e490: stp             lr, x16, [SP, #-0x10]!
    // 0x64e494: SaveReg r0
    //     0x64e494: str             x0, [SP, #-8]!
    // 0x64e498: r0 = _addArgumentlessAction()
    //     0x64e498: bl              #0x6467e0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addArgumentlessAction
    // 0x64e49c: add             SP, SP, #0x18
    // 0x64e4a0: ldr             x16, [fp, #0x18]
    // 0x64e4a4: r30 = Instance_SemanticsAction
    //     0x64e4a4: add             lr, PP, #0x33, lsl #12  ; [pp+0x33170] Obj!SemanticsAction@b5cde1
    //     0x64e4a8: ldr             lr, [lr, #0x170]
    // 0x64e4ac: stp             lr, x16, [SP, #-0x10]!
    // 0x64e4b0: r0 = _isValidAction()
    //     0x64e4b0: bl              #0x64e644  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_isValidAction
    // 0x64e4b4: add             SP, SP, #0x10
    // 0x64e4b8: tbnz            w0, #4, #0x64e500
    // 0x64e4bc: ldr             x0, [fp, #0x18]
    // 0x64e4c0: r1 = 1
    //     0x64e4c0: mov             x1, #1
    // 0x64e4c4: r0 = AllocateContext()
    //     0x64e4c4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x64e4c8: mov             x1, x0
    // 0x64e4cc: ldr             x0, [fp, #0x18]
    // 0x64e4d0: StoreField: r1->field_f = r0
    //     0x64e4d0: stur            w0, [x1, #0xf]
    // 0x64e4d4: mov             x2, x1
    // 0x64e4d8: r1 = Function '_performSemanticScrollLeft@907160605':.
    //     0x64e4d8: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fc70] AnonymousClosure: (0x64ea44), in [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_performSemanticScrollLeft (0x64ea8c)
    //     0x64e4dc: ldr             x1, [x1, #0xc70]
    // 0x64e4e0: r0 = AllocateClosure()
    //     0x64e4e0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x64e4e4: ldr             x16, [fp, #0x10]
    // 0x64e4e8: r30 = Instance_SemanticsAction
    //     0x64e4e8: add             lr, PP, #0x33, lsl #12  ; [pp+0x33170] Obj!SemanticsAction@b5cde1
    //     0x64e4ec: ldr             lr, [lr, #0x170]
    // 0x64e4f0: stp             lr, x16, [SP, #-0x10]!
    // 0x64e4f4: SaveReg r0
    //     0x64e4f4: str             x0, [SP, #-8]!
    // 0x64e4f8: r0 = _addArgumentlessAction()
    //     0x64e4f8: bl              #0x6467e0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addArgumentlessAction
    // 0x64e4fc: add             SP, SP, #0x18
    // 0x64e500: ldr             x0, [fp, #0x18]
    // 0x64e504: LoadField: r1 = r0->field_77
    //     0x64e504: ldur            w1, [x0, #0x77]
    // 0x64e508: DecompressPointer r1
    //     0x64e508: add             x1, x1, HEAP, lsl #32
    // 0x64e50c: cmp             w1, NULL
    // 0x64e510: b.eq            #0x64e5d0
    // 0x64e514: r16 = Instance_SemanticsAction
    //     0x64e514: add             x16, PP, #0x33, lsl #12  ; [pp+0x33168] Obj!SemanticsAction@b5cdc1
    //     0x64e518: ldr             x16, [x16, #0x168]
    // 0x64e51c: stp             x16, x0, [SP, #-0x10]!
    // 0x64e520: r0 = _isValidAction()
    //     0x64e520: bl              #0x64e644  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_isValidAction
    // 0x64e524: add             SP, SP, #0x10
    // 0x64e528: tbnz            w0, #4, #0x64e570
    // 0x64e52c: ldr             x0, [fp, #0x18]
    // 0x64e530: r1 = 1
    //     0x64e530: mov             x1, #1
    // 0x64e534: r0 = AllocateContext()
    //     0x64e534: bl              #0xd68aa4  ; AllocateContextStub
    // 0x64e538: mov             x1, x0
    // 0x64e53c: ldr             x0, [fp, #0x18]
    // 0x64e540: StoreField: r1->field_f = r0
    //     0x64e540: stur            w0, [x1, #0xf]
    // 0x64e544: mov             x2, x1
    // 0x64e548: r1 = Function '_performSemanticScrollUp@907160605':.
    //     0x64e548: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fc78] AnonymousClosure: (0x64e8c4), in [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_performSemanticScrollUp (0x64e90c)
    //     0x64e54c: ldr             x1, [x1, #0xc78]
    // 0x64e550: r0 = AllocateClosure()
    //     0x64e550: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x64e554: ldr             x16, [fp, #0x10]
    // 0x64e558: r30 = Instance_SemanticsAction
    //     0x64e558: add             lr, PP, #0x33, lsl #12  ; [pp+0x33168] Obj!SemanticsAction@b5cdc1
    //     0x64e55c: ldr             lr, [lr, #0x168]
    // 0x64e560: stp             lr, x16, [SP, #-0x10]!
    // 0x64e564: SaveReg r0
    //     0x64e564: str             x0, [SP, #-8]!
    // 0x64e568: r0 = _addArgumentlessAction()
    //     0x64e568: bl              #0x6467e0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addArgumentlessAction
    // 0x64e56c: add             SP, SP, #0x18
    // 0x64e570: ldr             x16, [fp, #0x18]
    // 0x64e574: r30 = Instance_SemanticsAction
    //     0x64e574: add             lr, PP, #0x33, lsl #12  ; [pp+0x33160] Obj!SemanticsAction@b5cdb1
    //     0x64e578: ldr             lr, [lr, #0x160]
    // 0x64e57c: stp             lr, x16, [SP, #-0x10]!
    // 0x64e580: r0 = _isValidAction()
    //     0x64e580: bl              #0x64e644  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_isValidAction
    // 0x64e584: add             SP, SP, #0x10
    // 0x64e588: tbnz            w0, #4, #0x64e5d0
    // 0x64e58c: ldr             x0, [fp, #0x18]
    // 0x64e590: r1 = 1
    //     0x64e590: mov             x1, #1
    // 0x64e594: r0 = AllocateContext()
    //     0x64e594: bl              #0xd68aa4  ; AllocateContextStub
    // 0x64e598: mov             x1, x0
    // 0x64e59c: ldr             x0, [fp, #0x18]
    // 0x64e5a0: StoreField: r1->field_f = r0
    //     0x64e5a0: stur            w0, [x1, #0xf]
    // 0x64e5a4: mov             x2, x1
    // 0x64e5a8: r1 = Function '_performSemanticScrollDown@907160605':.
    //     0x64e5a8: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fc80] AnonymousClosure: (0x64e698), in [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_performSemanticScrollDown (0x64e6e0)
    //     0x64e5ac: ldr             x1, [x1, #0xc80]
    // 0x64e5b0: r0 = AllocateClosure()
    //     0x64e5b0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x64e5b4: ldr             x16, [fp, #0x10]
    // 0x64e5b8: r30 = Instance_SemanticsAction
    //     0x64e5b8: add             lr, PP, #0x33, lsl #12  ; [pp+0x33160] Obj!SemanticsAction@b5cdb1
    //     0x64e5bc: ldr             lr, [lr, #0x160]
    // 0x64e5c0: stp             lr, x16, [SP, #-0x10]!
    // 0x64e5c4: SaveReg r0
    //     0x64e5c4: str             x0, [SP, #-8]!
    // 0x64e5c8: r0 = _addArgumentlessAction()
    //     0x64e5c8: bl              #0x6467e0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addArgumentlessAction
    // 0x64e5cc: add             SP, SP, #0x18
    // 0x64e5d0: r0 = Null
    //     0x64e5d0: mov             x0, NULL
    // 0x64e5d4: LeaveFrame
    //     0x64e5d4: mov             SP, fp
    //     0x64e5d8: ldp             fp, lr, [SP], #0x10
    // 0x64e5dc: ret
    //     0x64e5dc: ret             
    // 0x64e5e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64e5e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64e5e4: b               #0x64e388
    // 0x64e5e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x64e5e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x64e5ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x64e5ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _isValidAction(/* No info */) {
    // ** addr: 0x64e644, size: 0x54
    // 0x64e644: EnterFrame
    //     0x64e644: stp             fp, lr, [SP, #-0x10]!
    //     0x64e648: mov             fp, SP
    // 0x64e64c: CheckStackOverflow
    //     0x64e64c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64e650: cmp             SP, x16
    //     0x64e654: b.ls            #0x64e690
    // 0x64e658: ldr             x0, [fp, #0x18]
    // 0x64e65c: LoadField: r1 = r0->field_67
    //     0x64e65c: ldur            w1, [x0, #0x67]
    // 0x64e660: DecompressPointer r1
    //     0x64e660: add             x1, x1, HEAP, lsl #32
    // 0x64e664: cmp             w1, NULL
    // 0x64e668: b.ne            #0x64e674
    // 0x64e66c: r0 = true
    //     0x64e66c: add             x0, NULL, #0x20  ; true
    // 0x64e670: b               #0x64e684
    // 0x64e674: ldr             x16, [fp, #0x10]
    // 0x64e678: stp             x16, x1, [SP, #-0x10]!
    // 0x64e67c: r0 = contains()
    //     0x64e67c: bl              #0x787194  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x64e680: add             SP, SP, #0x10
    // 0x64e684: LeaveFrame
    //     0x64e684: mov             SP, fp
    //     0x64e688: ldp             fp, lr, [SP], #0x10
    // 0x64e68c: ret
    //     0x64e68c: ret             
    // 0x64e690: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64e690: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64e694: b               #0x64e658
  }
  [closure] void _performSemanticScrollDown(dynamic) {
    // ** addr: 0x64e698, size: 0x48
    // 0x64e698: EnterFrame
    //     0x64e698: stp             fp, lr, [SP, #-0x10]!
    //     0x64e69c: mov             fp, SP
    // 0x64e6a0: ldr             x0, [fp, #0x10]
    // 0x64e6a4: LoadField: r1 = r0->field_17
    //     0x64e6a4: ldur            w1, [x0, #0x17]
    // 0x64e6a8: DecompressPointer r1
    //     0x64e6a8: add             x1, x1, HEAP, lsl #32
    // 0x64e6ac: CheckStackOverflow
    //     0x64e6ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64e6b0: cmp             SP, x16
    //     0x64e6b4: b.ls            #0x64e6d8
    // 0x64e6b8: LoadField: r0 = r1->field_f
    //     0x64e6b8: ldur            w0, [x1, #0xf]
    // 0x64e6bc: DecompressPointer r0
    //     0x64e6bc: add             x0, x0, HEAP, lsl #32
    // 0x64e6c0: SaveReg r0
    //     0x64e6c0: str             x0, [SP, #-8]!
    // 0x64e6c4: r0 = _performSemanticScrollDown()
    //     0x64e6c4: bl              #0x64e6e0  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_performSemanticScrollDown
    // 0x64e6c8: add             SP, SP, #8
    // 0x64e6cc: LeaveFrame
    //     0x64e6cc: mov             SP, fp
    //     0x64e6d0: ldp             fp, lr, [SP], #0x10
    // 0x64e6d4: ret
    //     0x64e6d4: ret             
    // 0x64e6d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64e6d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64e6dc: b               #0x64e6b8
  }
  _ _performSemanticScrollDown(/* No info */) {
    // ** addr: 0x64e6e0, size: 0x134
    // 0x64e6e0: EnterFrame
    //     0x64e6e0: stp             fp, lr, [SP, #-0x10]!
    //     0x64e6e4: mov             fp, SP
    // 0x64e6e8: AllocStack(0x20)
    //     0x64e6e8: sub             SP, SP, #0x20
    // 0x64e6ec: CheckStackOverflow
    //     0x64e6ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64e6f0: cmp             SP, x16
    //     0x64e6f4: b.ls            #0x64e7f0
    // 0x64e6f8: ldr             x0, [fp, #0x10]
    // 0x64e6fc: LoadField: r1 = r0->field_77
    //     0x64e6fc: ldur            w1, [x0, #0x77]
    // 0x64e700: DecompressPointer r1
    //     0x64e700: add             x1, x1, HEAP, lsl #32
    // 0x64e704: stur            x1, [fp, #-0x10]
    // 0x64e708: cmp             w1, NULL
    // 0x64e70c: b.eq            #0x64e7e0
    // 0x64e710: d0 = 0.800000
    //     0x64e710: add             x17, PP, #0x2b, lsl #12  ; [pp+0x2bf68] IMM: double(0.8) from 0x3fe999999999999a
    //     0x64e714: ldr             d0, [x17, #0xf68]
    // 0x64e718: LoadField: r2 = r0->field_57
    //     0x64e718: ldur            w2, [x0, #0x57]
    // 0x64e71c: DecompressPointer r2
    //     0x64e71c: add             x2, x2, HEAP, lsl #32
    // 0x64e720: stur            x2, [fp, #-8]
    // 0x64e724: cmp             w2, NULL
    // 0x64e728: b.eq            #0x64e7f8
    // 0x64e72c: LoadField: d1 = r2->field_f
    //     0x64e72c: ldur            d1, [x2, #0xf]
    // 0x64e730: fmul            d2, d1, d0
    // 0x64e734: stur            d2, [fp, #-0x20]
    // 0x64e738: r0 = Offset()
    //     0x64e738: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x64e73c: d0 = 0.000000
    //     0x64e73c: eor             v0.16b, v0.16b, v0.16b
    // 0x64e740: stur            x0, [fp, #-0x18]
    // 0x64e744: StoreField: r0->field_7 = d0
    //     0x64e744: stur            d0, [x0, #7]
    // 0x64e748: ldur            d0, [fp, #-0x20]
    // 0x64e74c: StoreField: r0->field_f = d0
    //     0x64e74c: stur            d0, [x0, #0xf]
    // 0x64e750: ldur            x16, [fp, #-8]
    // 0x64e754: SaveReg r16
    //     0x64e754: str             x16, [SP, #-8]!
    // 0x64e758: r0 = center()
    //     0x64e758: bl              #0x64082c  ; [dart:ui] Size::center
    // 0x64e75c: add             SP, SP, #8
    // 0x64e760: ldr             x16, [fp, #0x10]
    // 0x64e764: stp             x0, x16, [SP, #-0x10]!
    // 0x64e768: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x64e768: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x64e76c: r0 = localToGlobal()
    //     0x64e76c: bl              #0x64e820  ; [package:flutter/src/rendering/box.dart] RenderBox::localToGlobal
    // 0x64e770: add             SP, SP, #0x10
    // 0x64e774: stur            x0, [fp, #-8]
    // 0x64e778: r0 = DragUpdateDetails()
    //     0x64e778: bl              #0x64e814  ; AllocateDragUpdateDetailsStub -> DragUpdateDetails (size=0x1c)
    // 0x64e77c: mov             x1, x0
    // 0x64e780: ldur            x0, [fp, #-0x18]
    // 0x64e784: StoreField: r1->field_b = r0
    //     0x64e784: stur            w0, [x1, #0xb]
    // 0x64e788: ldur            d0, [fp, #-0x20]
    // 0x64e78c: r0 = inline_Allocate_Double()
    //     0x64e78c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x64e790: add             x0, x0, #0x10
    //     0x64e794: cmp             x2, x0
    //     0x64e798: b.ls            #0x64e7fc
    //     0x64e79c: str             x0, [THR, #0x60]  ; THR::top
    //     0x64e7a0: sub             x0, x0, #0xf
    //     0x64e7a4: mov             x2, #0xd108
    //     0x64e7a8: movk            x2, #3, lsl #16
    //     0x64e7ac: stur            x2, [x0, #-1]
    // 0x64e7b0: StoreField: r0->field_7 = d0
    //     0x64e7b0: stur            d0, [x0, #7]
    // 0x64e7b4: StoreField: r1->field_f = r0
    //     0x64e7b4: stur            w0, [x1, #0xf]
    // 0x64e7b8: ldur            x0, [fp, #-8]
    // 0x64e7bc: StoreField: r1->field_13 = r0
    //     0x64e7bc: stur            w0, [x1, #0x13]
    // 0x64e7c0: StoreField: r1->field_17 = r0
    //     0x64e7c0: stur            w0, [x1, #0x17]
    // 0x64e7c4: ldur            x16, [fp, #-0x10]
    // 0x64e7c8: stp             x1, x16, [SP, #-0x10]!
    // 0x64e7cc: ldur            x0, [fp, #-0x10]
    // 0x64e7d0: ClosureCall
    //     0x64e7d0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x64e7d4: ldur            x2, [x0, #0x1f]
    //     0x64e7d8: blr             x2
    // 0x64e7dc: add             SP, SP, #0x10
    // 0x64e7e0: r0 = Null
    //     0x64e7e0: mov             x0, NULL
    // 0x64e7e4: LeaveFrame
    //     0x64e7e4: mov             SP, fp
    //     0x64e7e8: ldp             fp, lr, [SP], #0x10
    // 0x64e7ec: ret
    //     0x64e7ec: ret             
    // 0x64e7f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64e7f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64e7f4: b               #0x64e6f8
    // 0x64e7f8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x64e7f8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x64e7fc: SaveReg d0
    //     0x64e7fc: str             q0, [SP, #-0x10]!
    // 0x64e800: SaveReg r1
    //     0x64e800: str             x1, [SP, #-8]!
    // 0x64e804: r0 = AllocateDouble()
    //     0x64e804: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x64e808: RestoreReg r1
    //     0x64e808: ldr             x1, [SP], #8
    // 0x64e80c: RestoreReg d0
    //     0x64e80c: ldr             q0, [SP], #0x10
    // 0x64e810: b               #0x64e7b0
  }
  [closure] void _performSemanticScrollUp(dynamic) {
    // ** addr: 0x64e8c4, size: 0x48
    // 0x64e8c4: EnterFrame
    //     0x64e8c4: stp             fp, lr, [SP, #-0x10]!
    //     0x64e8c8: mov             fp, SP
    // 0x64e8cc: ldr             x0, [fp, #0x10]
    // 0x64e8d0: LoadField: r1 = r0->field_17
    //     0x64e8d0: ldur            w1, [x0, #0x17]
    // 0x64e8d4: DecompressPointer r1
    //     0x64e8d4: add             x1, x1, HEAP, lsl #32
    // 0x64e8d8: CheckStackOverflow
    //     0x64e8d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64e8dc: cmp             SP, x16
    //     0x64e8e0: b.ls            #0x64e904
    // 0x64e8e4: LoadField: r0 = r1->field_f
    //     0x64e8e4: ldur            w0, [x1, #0xf]
    // 0x64e8e8: DecompressPointer r0
    //     0x64e8e8: add             x0, x0, HEAP, lsl #32
    // 0x64e8ec: SaveReg r0
    //     0x64e8ec: str             x0, [SP, #-8]!
    // 0x64e8f0: r0 = _performSemanticScrollUp()
    //     0x64e8f0: bl              #0x64e90c  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_performSemanticScrollUp
    // 0x64e8f4: add             SP, SP, #8
    // 0x64e8f8: LeaveFrame
    //     0x64e8f8: mov             SP, fp
    //     0x64e8fc: ldp             fp, lr, [SP], #0x10
    // 0x64e900: ret
    //     0x64e900: ret             
    // 0x64e904: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64e904: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64e908: b               #0x64e8e4
  }
  _ _performSemanticScrollUp(/* No info */) {
    // ** addr: 0x64e90c, size: 0x138
    // 0x64e90c: EnterFrame
    //     0x64e90c: stp             fp, lr, [SP, #-0x10]!
    //     0x64e910: mov             fp, SP
    // 0x64e914: AllocStack(0x20)
    //     0x64e914: sub             SP, SP, #0x20
    // 0x64e918: CheckStackOverflow
    //     0x64e918: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64e91c: cmp             SP, x16
    //     0x64e920: b.ls            #0x64ea20
    // 0x64e924: ldr             x0, [fp, #0x10]
    // 0x64e928: LoadField: r1 = r0->field_77
    //     0x64e928: ldur            w1, [x0, #0x77]
    // 0x64e92c: DecompressPointer r1
    //     0x64e92c: add             x1, x1, HEAP, lsl #32
    // 0x64e930: stur            x1, [fp, #-0x10]
    // 0x64e934: cmp             w1, NULL
    // 0x64e938: b.eq            #0x64ea10
    // 0x64e93c: d0 = 0.800000
    //     0x64e93c: add             x17, PP, #0x2b, lsl #12  ; [pp+0x2bf68] IMM: double(0.8) from 0x3fe999999999999a
    //     0x64e940: ldr             d0, [x17, #0xf68]
    // 0x64e944: LoadField: r2 = r0->field_57
    //     0x64e944: ldur            w2, [x0, #0x57]
    // 0x64e948: DecompressPointer r2
    //     0x64e948: add             x2, x2, HEAP, lsl #32
    // 0x64e94c: stur            x2, [fp, #-8]
    // 0x64e950: cmp             w2, NULL
    // 0x64e954: b.eq            #0x64ea28
    // 0x64e958: LoadField: d1 = r2->field_f
    //     0x64e958: ldur            d1, [x2, #0xf]
    // 0x64e95c: fneg            d2, d0
    // 0x64e960: fmul            d0, d1, d2
    // 0x64e964: stur            d0, [fp, #-0x20]
    // 0x64e968: r0 = Offset()
    //     0x64e968: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x64e96c: d0 = 0.000000
    //     0x64e96c: eor             v0.16b, v0.16b, v0.16b
    // 0x64e970: stur            x0, [fp, #-0x18]
    // 0x64e974: StoreField: r0->field_7 = d0
    //     0x64e974: stur            d0, [x0, #7]
    // 0x64e978: ldur            d0, [fp, #-0x20]
    // 0x64e97c: StoreField: r0->field_f = d0
    //     0x64e97c: stur            d0, [x0, #0xf]
    // 0x64e980: ldur            x16, [fp, #-8]
    // 0x64e984: SaveReg r16
    //     0x64e984: str             x16, [SP, #-8]!
    // 0x64e988: r0 = center()
    //     0x64e988: bl              #0x64082c  ; [dart:ui] Size::center
    // 0x64e98c: add             SP, SP, #8
    // 0x64e990: ldr             x16, [fp, #0x10]
    // 0x64e994: stp             x0, x16, [SP, #-0x10]!
    // 0x64e998: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x64e998: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x64e99c: r0 = localToGlobal()
    //     0x64e99c: bl              #0x64e820  ; [package:flutter/src/rendering/box.dart] RenderBox::localToGlobal
    // 0x64e9a0: add             SP, SP, #0x10
    // 0x64e9a4: stur            x0, [fp, #-8]
    // 0x64e9a8: r0 = DragUpdateDetails()
    //     0x64e9a8: bl              #0x64e814  ; AllocateDragUpdateDetailsStub -> DragUpdateDetails (size=0x1c)
    // 0x64e9ac: mov             x1, x0
    // 0x64e9b0: ldur            x0, [fp, #-0x18]
    // 0x64e9b4: StoreField: r1->field_b = r0
    //     0x64e9b4: stur            w0, [x1, #0xb]
    // 0x64e9b8: ldur            d0, [fp, #-0x20]
    // 0x64e9bc: r0 = inline_Allocate_Double()
    //     0x64e9bc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x64e9c0: add             x0, x0, #0x10
    //     0x64e9c4: cmp             x2, x0
    //     0x64e9c8: b.ls            #0x64ea2c
    //     0x64e9cc: str             x0, [THR, #0x60]  ; THR::top
    //     0x64e9d0: sub             x0, x0, #0xf
    //     0x64e9d4: mov             x2, #0xd108
    //     0x64e9d8: movk            x2, #3, lsl #16
    //     0x64e9dc: stur            x2, [x0, #-1]
    // 0x64e9e0: StoreField: r0->field_7 = d0
    //     0x64e9e0: stur            d0, [x0, #7]
    // 0x64e9e4: StoreField: r1->field_f = r0
    //     0x64e9e4: stur            w0, [x1, #0xf]
    // 0x64e9e8: ldur            x0, [fp, #-8]
    // 0x64e9ec: StoreField: r1->field_13 = r0
    //     0x64e9ec: stur            w0, [x1, #0x13]
    // 0x64e9f0: StoreField: r1->field_17 = r0
    //     0x64e9f0: stur            w0, [x1, #0x17]
    // 0x64e9f4: ldur            x16, [fp, #-0x10]
    // 0x64e9f8: stp             x1, x16, [SP, #-0x10]!
    // 0x64e9fc: ldur            x0, [fp, #-0x10]
    // 0x64ea00: ClosureCall
    //     0x64ea00: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x64ea04: ldur            x2, [x0, #0x1f]
    //     0x64ea08: blr             x2
    // 0x64ea0c: add             SP, SP, #0x10
    // 0x64ea10: r0 = Null
    //     0x64ea10: mov             x0, NULL
    // 0x64ea14: LeaveFrame
    //     0x64ea14: mov             SP, fp
    //     0x64ea18: ldp             fp, lr, [SP], #0x10
    // 0x64ea1c: ret
    //     0x64ea1c: ret             
    // 0x64ea20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64ea20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64ea24: b               #0x64e924
    // 0x64ea28: r0 = NullCastErrorSharedWithFPURegs()
    //     0x64ea28: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x64ea2c: SaveReg d0
    //     0x64ea2c: str             q0, [SP, #-0x10]!
    // 0x64ea30: SaveReg r1
    //     0x64ea30: str             x1, [SP, #-8]!
    // 0x64ea34: r0 = AllocateDouble()
    //     0x64ea34: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x64ea38: RestoreReg r1
    //     0x64ea38: ldr             x1, [SP], #8
    // 0x64ea3c: RestoreReg d0
    //     0x64ea3c: ldr             q0, [SP], #0x10
    // 0x64ea40: b               #0x64e9e0
  }
  [closure] void _performSemanticScrollLeft(dynamic) {
    // ** addr: 0x64ea44, size: 0x48
    // 0x64ea44: EnterFrame
    //     0x64ea44: stp             fp, lr, [SP, #-0x10]!
    //     0x64ea48: mov             fp, SP
    // 0x64ea4c: ldr             x0, [fp, #0x10]
    // 0x64ea50: LoadField: r1 = r0->field_17
    //     0x64ea50: ldur            w1, [x0, #0x17]
    // 0x64ea54: DecompressPointer r1
    //     0x64ea54: add             x1, x1, HEAP, lsl #32
    // 0x64ea58: CheckStackOverflow
    //     0x64ea58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64ea5c: cmp             SP, x16
    //     0x64ea60: b.ls            #0x64ea84
    // 0x64ea64: LoadField: r0 = r1->field_f
    //     0x64ea64: ldur            w0, [x1, #0xf]
    // 0x64ea68: DecompressPointer r0
    //     0x64ea68: add             x0, x0, HEAP, lsl #32
    // 0x64ea6c: SaveReg r0
    //     0x64ea6c: str             x0, [SP, #-8]!
    // 0x64ea70: r0 = _performSemanticScrollLeft()
    //     0x64ea70: bl              #0x64ea8c  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_performSemanticScrollLeft
    // 0x64ea74: add             SP, SP, #8
    // 0x64ea78: LeaveFrame
    //     0x64ea78: mov             SP, fp
    //     0x64ea7c: ldp             fp, lr, [SP], #0x10
    // 0x64ea80: ret
    //     0x64ea80: ret             
    // 0x64ea84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64ea84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64ea88: b               #0x64ea64
  }
  _ _performSemanticScrollLeft(/* No info */) {
    // ** addr: 0x64ea8c, size: 0x138
    // 0x64ea8c: EnterFrame
    //     0x64ea8c: stp             fp, lr, [SP, #-0x10]!
    //     0x64ea90: mov             fp, SP
    // 0x64ea94: AllocStack(0x20)
    //     0x64ea94: sub             SP, SP, #0x20
    // 0x64ea98: CheckStackOverflow
    //     0x64ea98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64ea9c: cmp             SP, x16
    //     0x64eaa0: b.ls            #0x64eba0
    // 0x64eaa4: ldr             x0, [fp, #0x10]
    // 0x64eaa8: LoadField: r1 = r0->field_73
    //     0x64eaa8: ldur            w1, [x0, #0x73]
    // 0x64eaac: DecompressPointer r1
    //     0x64eaac: add             x1, x1, HEAP, lsl #32
    // 0x64eab0: stur            x1, [fp, #-0x10]
    // 0x64eab4: cmp             w1, NULL
    // 0x64eab8: b.eq            #0x64eb90
    // 0x64eabc: d0 = 0.800000
    //     0x64eabc: add             x17, PP, #0x2b, lsl #12  ; [pp+0x2bf68] IMM: double(0.8) from 0x3fe999999999999a
    //     0x64eac0: ldr             d0, [x17, #0xf68]
    // 0x64eac4: LoadField: r2 = r0->field_57
    //     0x64eac4: ldur            w2, [x0, #0x57]
    // 0x64eac8: DecompressPointer r2
    //     0x64eac8: add             x2, x2, HEAP, lsl #32
    // 0x64eacc: stur            x2, [fp, #-8]
    // 0x64ead0: cmp             w2, NULL
    // 0x64ead4: b.eq            #0x64eba8
    // 0x64ead8: LoadField: d1 = r2->field_7
    //     0x64ead8: ldur            d1, [x2, #7]
    // 0x64eadc: fneg            d2, d0
    // 0x64eae0: fmul            d0, d1, d2
    // 0x64eae4: stur            d0, [fp, #-0x20]
    // 0x64eae8: r0 = Offset()
    //     0x64eae8: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x64eaec: ldur            d0, [fp, #-0x20]
    // 0x64eaf0: stur            x0, [fp, #-0x18]
    // 0x64eaf4: StoreField: r0->field_7 = d0
    //     0x64eaf4: stur            d0, [x0, #7]
    // 0x64eaf8: d1 = 0.000000
    //     0x64eaf8: eor             v1.16b, v1.16b, v1.16b
    // 0x64eafc: StoreField: r0->field_f = d1
    //     0x64eafc: stur            d1, [x0, #0xf]
    // 0x64eb00: ldur            x16, [fp, #-8]
    // 0x64eb04: SaveReg r16
    //     0x64eb04: str             x16, [SP, #-8]!
    // 0x64eb08: r0 = center()
    //     0x64eb08: bl              #0x64082c  ; [dart:ui] Size::center
    // 0x64eb0c: add             SP, SP, #8
    // 0x64eb10: ldr             x16, [fp, #0x10]
    // 0x64eb14: stp             x0, x16, [SP, #-0x10]!
    // 0x64eb18: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x64eb18: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x64eb1c: r0 = localToGlobal()
    //     0x64eb1c: bl              #0x64e820  ; [package:flutter/src/rendering/box.dart] RenderBox::localToGlobal
    // 0x64eb20: add             SP, SP, #0x10
    // 0x64eb24: stur            x0, [fp, #-8]
    // 0x64eb28: r0 = DragUpdateDetails()
    //     0x64eb28: bl              #0x64e814  ; AllocateDragUpdateDetailsStub -> DragUpdateDetails (size=0x1c)
    // 0x64eb2c: mov             x1, x0
    // 0x64eb30: ldur            x0, [fp, #-0x18]
    // 0x64eb34: StoreField: r1->field_b = r0
    //     0x64eb34: stur            w0, [x1, #0xb]
    // 0x64eb38: ldur            d0, [fp, #-0x20]
    // 0x64eb3c: r0 = inline_Allocate_Double()
    //     0x64eb3c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x64eb40: add             x0, x0, #0x10
    //     0x64eb44: cmp             x2, x0
    //     0x64eb48: b.ls            #0x64ebac
    //     0x64eb4c: str             x0, [THR, #0x60]  ; THR::top
    //     0x64eb50: sub             x0, x0, #0xf
    //     0x64eb54: mov             x2, #0xd108
    //     0x64eb58: movk            x2, #3, lsl #16
    //     0x64eb5c: stur            x2, [x0, #-1]
    // 0x64eb60: StoreField: r0->field_7 = d0
    //     0x64eb60: stur            d0, [x0, #7]
    // 0x64eb64: StoreField: r1->field_f = r0
    //     0x64eb64: stur            w0, [x1, #0xf]
    // 0x64eb68: ldur            x0, [fp, #-8]
    // 0x64eb6c: StoreField: r1->field_13 = r0
    //     0x64eb6c: stur            w0, [x1, #0x13]
    // 0x64eb70: StoreField: r1->field_17 = r0
    //     0x64eb70: stur            w0, [x1, #0x17]
    // 0x64eb74: ldur            x16, [fp, #-0x10]
    // 0x64eb78: stp             x1, x16, [SP, #-0x10]!
    // 0x64eb7c: ldur            x0, [fp, #-0x10]
    // 0x64eb80: ClosureCall
    //     0x64eb80: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x64eb84: ldur            x2, [x0, #0x1f]
    //     0x64eb88: blr             x2
    // 0x64eb8c: add             SP, SP, #0x10
    // 0x64eb90: r0 = Null
    //     0x64eb90: mov             x0, NULL
    // 0x64eb94: LeaveFrame
    //     0x64eb94: mov             SP, fp
    //     0x64eb98: ldp             fp, lr, [SP], #0x10
    // 0x64eb9c: ret
    //     0x64eb9c: ret             
    // 0x64eba0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64eba0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64eba4: b               #0x64eaa4
    // 0x64eba8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x64eba8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x64ebac: SaveReg d0
    //     0x64ebac: str             q0, [SP, #-0x10]!
    // 0x64ebb0: SaveReg r1
    //     0x64ebb0: str             x1, [SP, #-8]!
    // 0x64ebb4: r0 = AllocateDouble()
    //     0x64ebb4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x64ebb8: RestoreReg r1
    //     0x64ebb8: ldr             x1, [SP], #8
    // 0x64ebbc: RestoreReg d0
    //     0x64ebbc: ldr             q0, [SP], #0x10
    // 0x64ebc0: b               #0x64eb60
  }
  [closure] void _performSemanticScrollRight(dynamic) {
    // ** addr: 0x64ebc4, size: 0x48
    // 0x64ebc4: EnterFrame
    //     0x64ebc4: stp             fp, lr, [SP, #-0x10]!
    //     0x64ebc8: mov             fp, SP
    // 0x64ebcc: ldr             x0, [fp, #0x10]
    // 0x64ebd0: LoadField: r1 = r0->field_17
    //     0x64ebd0: ldur            w1, [x0, #0x17]
    // 0x64ebd4: DecompressPointer r1
    //     0x64ebd4: add             x1, x1, HEAP, lsl #32
    // 0x64ebd8: CheckStackOverflow
    //     0x64ebd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64ebdc: cmp             SP, x16
    //     0x64ebe0: b.ls            #0x64ec04
    // 0x64ebe4: LoadField: r0 = r1->field_f
    //     0x64ebe4: ldur            w0, [x1, #0xf]
    // 0x64ebe8: DecompressPointer r0
    //     0x64ebe8: add             x0, x0, HEAP, lsl #32
    // 0x64ebec: SaveReg r0
    //     0x64ebec: str             x0, [SP, #-8]!
    // 0x64ebf0: r0 = _performSemanticScrollRight()
    //     0x64ebf0: bl              #0x64ec0c  ; [package:flutter/src/rendering/proxy_box.dart] RenderSemanticsGestureHandler::_performSemanticScrollRight
    // 0x64ebf4: add             SP, SP, #8
    // 0x64ebf8: LeaveFrame
    //     0x64ebf8: mov             SP, fp
    //     0x64ebfc: ldp             fp, lr, [SP], #0x10
    // 0x64ec00: ret
    //     0x64ec00: ret             
    // 0x64ec04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64ec04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64ec08: b               #0x64ebe4
  }
  _ _performSemanticScrollRight(/* No info */) {
    // ** addr: 0x64ec0c, size: 0x134
    // 0x64ec0c: EnterFrame
    //     0x64ec0c: stp             fp, lr, [SP, #-0x10]!
    //     0x64ec10: mov             fp, SP
    // 0x64ec14: AllocStack(0x20)
    //     0x64ec14: sub             SP, SP, #0x20
    // 0x64ec18: CheckStackOverflow
    //     0x64ec18: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64ec1c: cmp             SP, x16
    //     0x64ec20: b.ls            #0x64ed1c
    // 0x64ec24: ldr             x0, [fp, #0x10]
    // 0x64ec28: LoadField: r1 = r0->field_73
    //     0x64ec28: ldur            w1, [x0, #0x73]
    // 0x64ec2c: DecompressPointer r1
    //     0x64ec2c: add             x1, x1, HEAP, lsl #32
    // 0x64ec30: stur            x1, [fp, #-0x10]
    // 0x64ec34: cmp             w1, NULL
    // 0x64ec38: b.eq            #0x64ed0c
    // 0x64ec3c: d0 = 0.800000
    //     0x64ec3c: add             x17, PP, #0x2b, lsl #12  ; [pp+0x2bf68] IMM: double(0.8) from 0x3fe999999999999a
    //     0x64ec40: ldr             d0, [x17, #0xf68]
    // 0x64ec44: LoadField: r2 = r0->field_57
    //     0x64ec44: ldur            w2, [x0, #0x57]
    // 0x64ec48: DecompressPointer r2
    //     0x64ec48: add             x2, x2, HEAP, lsl #32
    // 0x64ec4c: stur            x2, [fp, #-8]
    // 0x64ec50: cmp             w2, NULL
    // 0x64ec54: b.eq            #0x64ed24
    // 0x64ec58: LoadField: d1 = r2->field_7
    //     0x64ec58: ldur            d1, [x2, #7]
    // 0x64ec5c: fmul            d2, d1, d0
    // 0x64ec60: stur            d2, [fp, #-0x20]
    // 0x64ec64: r0 = Offset()
    //     0x64ec64: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x64ec68: ldur            d0, [fp, #-0x20]
    // 0x64ec6c: stur            x0, [fp, #-0x18]
    // 0x64ec70: StoreField: r0->field_7 = d0
    //     0x64ec70: stur            d0, [x0, #7]
    // 0x64ec74: d1 = 0.000000
    //     0x64ec74: eor             v1.16b, v1.16b, v1.16b
    // 0x64ec78: StoreField: r0->field_f = d1
    //     0x64ec78: stur            d1, [x0, #0xf]
    // 0x64ec7c: ldur            x16, [fp, #-8]
    // 0x64ec80: SaveReg r16
    //     0x64ec80: str             x16, [SP, #-8]!
    // 0x64ec84: r0 = center()
    //     0x64ec84: bl              #0x64082c  ; [dart:ui] Size::center
    // 0x64ec88: add             SP, SP, #8
    // 0x64ec8c: ldr             x16, [fp, #0x10]
    // 0x64ec90: stp             x0, x16, [SP, #-0x10]!
    // 0x64ec94: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x64ec94: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x64ec98: r0 = localToGlobal()
    //     0x64ec98: bl              #0x64e820  ; [package:flutter/src/rendering/box.dart] RenderBox::localToGlobal
    // 0x64ec9c: add             SP, SP, #0x10
    // 0x64eca0: stur            x0, [fp, #-8]
    // 0x64eca4: r0 = DragUpdateDetails()
    //     0x64eca4: bl              #0x64e814  ; AllocateDragUpdateDetailsStub -> DragUpdateDetails (size=0x1c)
    // 0x64eca8: mov             x1, x0
    // 0x64ecac: ldur            x0, [fp, #-0x18]
    // 0x64ecb0: StoreField: r1->field_b = r0
    //     0x64ecb0: stur            w0, [x1, #0xb]
    // 0x64ecb4: ldur            d0, [fp, #-0x20]
    // 0x64ecb8: r0 = inline_Allocate_Double()
    //     0x64ecb8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x64ecbc: add             x0, x0, #0x10
    //     0x64ecc0: cmp             x2, x0
    //     0x64ecc4: b.ls            #0x64ed28
    //     0x64ecc8: str             x0, [THR, #0x60]  ; THR::top
    //     0x64eccc: sub             x0, x0, #0xf
    //     0x64ecd0: mov             x2, #0xd108
    //     0x64ecd4: movk            x2, #3, lsl #16
    //     0x64ecd8: stur            x2, [x0, #-1]
    // 0x64ecdc: StoreField: r0->field_7 = d0
    //     0x64ecdc: stur            d0, [x0, #7]
    // 0x64ece0: StoreField: r1->field_f = r0
    //     0x64ece0: stur            w0, [x1, #0xf]
    // 0x64ece4: ldur            x0, [fp, #-8]
    // 0x64ece8: StoreField: r1->field_13 = r0
    //     0x64ece8: stur            w0, [x1, #0x13]
    // 0x64ecec: StoreField: r1->field_17 = r0
    //     0x64ecec: stur            w0, [x1, #0x17]
    // 0x64ecf0: ldur            x16, [fp, #-0x10]
    // 0x64ecf4: stp             x1, x16, [SP, #-0x10]!
    // 0x64ecf8: ldur            x0, [fp, #-0x10]
    // 0x64ecfc: ClosureCall
    //     0x64ecfc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x64ed00: ldur            x2, [x0, #0x1f]
    //     0x64ed04: blr             x2
    // 0x64ed08: add             SP, SP, #0x10
    // 0x64ed0c: r0 = Null
    //     0x64ed0c: mov             x0, NULL
    // 0x64ed10: LeaveFrame
    //     0x64ed10: mov             SP, fp
    //     0x64ed14: ldp             fp, lr, [SP], #0x10
    // 0x64ed18: ret
    //     0x64ed18: ret             
    // 0x64ed1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64ed1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64ed20: b               #0x64ec24
    // 0x64ed24: r0 = NullCastErrorSharedWithFPURegs()
    //     0x64ed24: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x64ed28: SaveReg d0
    //     0x64ed28: str             q0, [SP, #-0x10]!
    // 0x64ed2c: SaveReg r1
    //     0x64ed2c: str             x1, [SP, #-8]!
    // 0x64ed30: r0 = AllocateDouble()
    //     0x64ed30: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x64ed34: RestoreReg r1
    //     0x64ed34: ldr             x1, [SP], #8
    // 0x64ed38: RestoreReg d0
    //     0x64ed38: ldr             q0, [SP], #0x10
    // 0x64ed3c: b               #0x64ecdc
  }
  set _ onTap=(/* No info */) {
    // ** addr: 0x87e770, size: 0xd4
    // 0x87e770: EnterFrame
    //     0x87e770: stp             fp, lr, [SP, #-0x10]!
    //     0x87e774: mov             fp, SP
    // 0x87e778: CheckStackOverflow
    //     0x87e778: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x87e77c: cmp             SP, x16
    //     0x87e780: b.ls            #0x87e83c
    // 0x87e784: ldr             x1, [fp, #0x18]
    // 0x87e788: LoadField: r0 = r1->field_6b
    //     0x87e788: ldur            w0, [x1, #0x6b]
    // 0x87e78c: DecompressPointer r0
    //     0x87e78c: add             x0, x0, HEAP, lsl #32
    // 0x87e790: r2 = LoadClassIdInstr(r0)
    //     0x87e790: ldur            x2, [x0, #-1]
    //     0x87e794: ubfx            x2, x2, #0xc, #0x14
    // 0x87e798: ldr             x16, [fp, #0x10]
    // 0x87e79c: stp             x16, x0, [SP, #-0x10]!
    // 0x87e7a0: mov             x0, x2
    // 0x87e7a4: mov             lr, x0
    // 0x87e7a8: ldr             lr, [x21, lr, lsl #3]
    // 0x87e7ac: blr             lr
    // 0x87e7b0: add             SP, SP, #0x10
    // 0x87e7b4: tbnz            w0, #4, #0x87e7c8
    // 0x87e7b8: r0 = Null
    //     0x87e7b8: mov             x0, NULL
    // 0x87e7bc: LeaveFrame
    //     0x87e7bc: mov             SP, fp
    //     0x87e7c0: ldp             fp, lr, [SP], #0x10
    // 0x87e7c4: ret
    //     0x87e7c4: ret             
    // 0x87e7c8: ldr             x1, [fp, #0x18]
    // 0x87e7cc: ldr             x2, [fp, #0x10]
    // 0x87e7d0: LoadField: r0 = r1->field_6b
    //     0x87e7d0: ldur            w0, [x1, #0x6b]
    // 0x87e7d4: DecompressPointer r0
    //     0x87e7d4: add             x0, x0, HEAP, lsl #32
    // 0x87e7d8: cmp             w0, NULL
    // 0x87e7dc: r16 = true
    //     0x87e7dc: add             x16, NULL, #0x20  ; true
    // 0x87e7e0: r17 = false
    //     0x87e7e0: add             x17, NULL, #0x30  ; false
    // 0x87e7e4: csel            x3, x16, x17, ne
    // 0x87e7e8: mov             x0, x2
    // 0x87e7ec: StoreField: r1->field_6b = r0
    //     0x87e7ec: stur            w0, [x1, #0x6b]
    //     0x87e7f0: ldurb           w16, [x1, #-1]
    //     0x87e7f4: ldurb           w17, [x0, #-1]
    //     0x87e7f8: and             x16, x17, x16, lsr #2
    //     0x87e7fc: tst             x16, HEAP, lsr #32
    //     0x87e800: b.eq            #0x87e808
    //     0x87e804: bl              #0xd6826c
    // 0x87e808: cmp             w2, NULL
    // 0x87e80c: r16 = true
    //     0x87e80c: add             x16, NULL, #0x20  ; true
    // 0x87e810: r17 = false
    //     0x87e810: add             x17, NULL, #0x30  ; false
    // 0x87e814: csel            x0, x16, x17, ne
    // 0x87e818: cmp             w0, w3
    // 0x87e81c: b.eq            #0x87e82c
    // 0x87e820: SaveReg r1
    //     0x87e820: str             x1, [SP, #-8]!
    // 0x87e824: r0 = markNeedsSemanticsUpdate()
    //     0x87e824: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x87e828: add             SP, SP, #8
    // 0x87e82c: r0 = Null
    //     0x87e82c: mov             x0, NULL
    // 0x87e830: LeaveFrame
    //     0x87e830: mov             SP, fp
    //     0x87e834: ldp             fp, lr, [SP], #0x10
    // 0x87e838: ret
    //     0x87e838: ret             
    // 0x87e83c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87e83c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87e840: b               #0x87e784
  }
  set _ validActions=(/* No info */) {
    // ** addr: 0xc02558, size: 0x9c
    // 0xc02558: EnterFrame
    //     0xc02558: stp             fp, lr, [SP, #-0x10]!
    //     0xc0255c: mov             fp, SP
    // 0xc02560: CheckStackOverflow
    //     0xc02560: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc02564: cmp             SP, x16
    //     0xc02568: b.ls            #0xc025ec
    // 0xc0256c: ldr             x0, [fp, #0x18]
    // 0xc02570: LoadField: r1 = r0->field_67
    //     0xc02570: ldur            w1, [x0, #0x67]
    // 0xc02574: DecompressPointer r1
    //     0xc02574: add             x1, x1, HEAP, lsl #32
    // 0xc02578: r16 = <SemanticsAction>
    //     0xc02578: add             x16, PP, #0x33, lsl #12  ; [pp+0x33180] TypeArguments: <SemanticsAction>
    //     0xc0257c: ldr             x16, [x16, #0x180]
    // 0xc02580: ldr             lr, [fp, #0x10]
    // 0xc02584: stp             lr, x16, [SP, #-0x10]!
    // 0xc02588: SaveReg r1
    //     0xc02588: str             x1, [SP, #-8]!
    // 0xc0258c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc0258c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc02590: r0 = setEquals()
    //     0xc02590: bl              #0x6d44d4  ; [package:flutter/src/foundation/collections.dart] ::setEquals
    // 0xc02594: add             SP, SP, #0x18
    // 0xc02598: tbnz            w0, #4, #0xc025ac
    // 0xc0259c: r0 = Null
    //     0xc0259c: mov             x0, NULL
    // 0xc025a0: LeaveFrame
    //     0xc025a0: mov             SP, fp
    //     0xc025a4: ldp             fp, lr, [SP], #0x10
    // 0xc025a8: ret
    //     0xc025a8: ret             
    // 0xc025ac: ldr             x1, [fp, #0x18]
    // 0xc025b0: ldr             x0, [fp, #0x10]
    // 0xc025b4: StoreField: r1->field_67 = r0
    //     0xc025b4: stur            w0, [x1, #0x67]
    //     0xc025b8: ldurb           w16, [x1, #-1]
    //     0xc025bc: ldurb           w17, [x0, #-1]
    //     0xc025c0: and             x16, x17, x16, lsr #2
    //     0xc025c4: tst             x16, HEAP, lsr #32
    //     0xc025c8: b.eq            #0xc025d0
    //     0xc025cc: bl              #0xd6826c
    // 0xc025d0: SaveReg r1
    //     0xc025d0: str             x1, [SP, #-8]!
    // 0xc025d4: r0 = markNeedsSemanticsUpdate()
    //     0xc025d4: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xc025d8: add             SP, SP, #8
    // 0xc025dc: r0 = Null
    //     0xc025dc: mov             x0, NULL
    // 0xc025e0: LeaveFrame
    //     0xc025e0: mov             SP, fp
    //     0xc025e4: ldp             fp, lr, [SP], #0x10
    // 0xc025e8: ret
    //     0xc025e8: ret             
    // 0xc025ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc025ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc025f0: b               #0xc0256c
  }
  set _ onVerticalDragUpdate=(/* No info */) {
    // ** addr: 0xd0bca4, size: 0xd4
    // 0xd0bca4: EnterFrame
    //     0xd0bca4: stp             fp, lr, [SP, #-0x10]!
    //     0xd0bca8: mov             fp, SP
    // 0xd0bcac: CheckStackOverflow
    //     0xd0bcac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd0bcb0: cmp             SP, x16
    //     0xd0bcb4: b.ls            #0xd0bd70
    // 0xd0bcb8: ldr             x1, [fp, #0x18]
    // 0xd0bcbc: LoadField: r0 = r1->field_77
    //     0xd0bcbc: ldur            w0, [x1, #0x77]
    // 0xd0bcc0: DecompressPointer r0
    //     0xd0bcc0: add             x0, x0, HEAP, lsl #32
    // 0xd0bcc4: r2 = LoadClassIdInstr(r0)
    //     0xd0bcc4: ldur            x2, [x0, #-1]
    //     0xd0bcc8: ubfx            x2, x2, #0xc, #0x14
    // 0xd0bccc: ldr             x16, [fp, #0x10]
    // 0xd0bcd0: stp             x16, x0, [SP, #-0x10]!
    // 0xd0bcd4: mov             x0, x2
    // 0xd0bcd8: mov             lr, x0
    // 0xd0bcdc: ldr             lr, [x21, lr, lsl #3]
    // 0xd0bce0: blr             lr
    // 0xd0bce4: add             SP, SP, #0x10
    // 0xd0bce8: tbnz            w0, #4, #0xd0bcfc
    // 0xd0bcec: r0 = Null
    //     0xd0bcec: mov             x0, NULL
    // 0xd0bcf0: LeaveFrame
    //     0xd0bcf0: mov             SP, fp
    //     0xd0bcf4: ldp             fp, lr, [SP], #0x10
    // 0xd0bcf8: ret
    //     0xd0bcf8: ret             
    // 0xd0bcfc: ldr             x1, [fp, #0x18]
    // 0xd0bd00: ldr             x2, [fp, #0x10]
    // 0xd0bd04: LoadField: r0 = r1->field_77
    //     0xd0bd04: ldur            w0, [x1, #0x77]
    // 0xd0bd08: DecompressPointer r0
    //     0xd0bd08: add             x0, x0, HEAP, lsl #32
    // 0xd0bd0c: cmp             w0, NULL
    // 0xd0bd10: r16 = true
    //     0xd0bd10: add             x16, NULL, #0x20  ; true
    // 0xd0bd14: r17 = false
    //     0xd0bd14: add             x17, NULL, #0x30  ; false
    // 0xd0bd18: csel            x3, x16, x17, ne
    // 0xd0bd1c: mov             x0, x2
    // 0xd0bd20: StoreField: r1->field_77 = r0
    //     0xd0bd20: stur            w0, [x1, #0x77]
    //     0xd0bd24: ldurb           w16, [x1, #-1]
    //     0xd0bd28: ldurb           w17, [x0, #-1]
    //     0xd0bd2c: and             x16, x17, x16, lsr #2
    //     0xd0bd30: tst             x16, HEAP, lsr #32
    //     0xd0bd34: b.eq            #0xd0bd3c
    //     0xd0bd38: bl              #0xd6826c
    // 0xd0bd3c: cmp             w2, NULL
    // 0xd0bd40: r16 = true
    //     0xd0bd40: add             x16, NULL, #0x20  ; true
    // 0xd0bd44: r17 = false
    //     0xd0bd44: add             x17, NULL, #0x30  ; false
    // 0xd0bd48: csel            x0, x16, x17, ne
    // 0xd0bd4c: cmp             w0, w3
    // 0xd0bd50: b.eq            #0xd0bd60
    // 0xd0bd54: SaveReg r1
    //     0xd0bd54: str             x1, [SP, #-8]!
    // 0xd0bd58: r0 = markNeedsSemanticsUpdate()
    //     0xd0bd58: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xd0bd5c: add             SP, SP, #8
    // 0xd0bd60: r0 = Null
    //     0xd0bd60: mov             x0, NULL
    // 0xd0bd64: LeaveFrame
    //     0xd0bd64: mov             SP, fp
    //     0xd0bd68: ldp             fp, lr, [SP], #0x10
    // 0xd0bd6c: ret
    //     0xd0bd6c: ret             
    // 0xd0bd70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0bd70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0bd74: b               #0xd0bcb8
  }
  set _ onHorizontalDragUpdate=(/* No info */) {
    // ** addr: 0xd0c2d8, size: 0xd4
    // 0xd0c2d8: EnterFrame
    //     0xd0c2d8: stp             fp, lr, [SP, #-0x10]!
    //     0xd0c2dc: mov             fp, SP
    // 0xd0c2e0: CheckStackOverflow
    //     0xd0c2e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd0c2e4: cmp             SP, x16
    //     0xd0c2e8: b.ls            #0xd0c3a4
    // 0xd0c2ec: ldr             x1, [fp, #0x18]
    // 0xd0c2f0: LoadField: r0 = r1->field_73
    //     0xd0c2f0: ldur            w0, [x1, #0x73]
    // 0xd0c2f4: DecompressPointer r0
    //     0xd0c2f4: add             x0, x0, HEAP, lsl #32
    // 0xd0c2f8: r2 = LoadClassIdInstr(r0)
    //     0xd0c2f8: ldur            x2, [x0, #-1]
    //     0xd0c2fc: ubfx            x2, x2, #0xc, #0x14
    // 0xd0c300: ldr             x16, [fp, #0x10]
    // 0xd0c304: stp             x16, x0, [SP, #-0x10]!
    // 0xd0c308: mov             x0, x2
    // 0xd0c30c: mov             lr, x0
    // 0xd0c310: ldr             lr, [x21, lr, lsl #3]
    // 0xd0c314: blr             lr
    // 0xd0c318: add             SP, SP, #0x10
    // 0xd0c31c: tbnz            w0, #4, #0xd0c330
    // 0xd0c320: r0 = Null
    //     0xd0c320: mov             x0, NULL
    // 0xd0c324: LeaveFrame
    //     0xd0c324: mov             SP, fp
    //     0xd0c328: ldp             fp, lr, [SP], #0x10
    // 0xd0c32c: ret
    //     0xd0c32c: ret             
    // 0xd0c330: ldr             x1, [fp, #0x18]
    // 0xd0c334: ldr             x2, [fp, #0x10]
    // 0xd0c338: LoadField: r0 = r1->field_73
    //     0xd0c338: ldur            w0, [x1, #0x73]
    // 0xd0c33c: DecompressPointer r0
    //     0xd0c33c: add             x0, x0, HEAP, lsl #32
    // 0xd0c340: cmp             w0, NULL
    // 0xd0c344: r16 = true
    //     0xd0c344: add             x16, NULL, #0x20  ; true
    // 0xd0c348: r17 = false
    //     0xd0c348: add             x17, NULL, #0x30  ; false
    // 0xd0c34c: csel            x3, x16, x17, ne
    // 0xd0c350: mov             x0, x2
    // 0xd0c354: StoreField: r1->field_73 = r0
    //     0xd0c354: stur            w0, [x1, #0x73]
    //     0xd0c358: ldurb           w16, [x1, #-1]
    //     0xd0c35c: ldurb           w17, [x0, #-1]
    //     0xd0c360: and             x16, x17, x16, lsr #2
    //     0xd0c364: tst             x16, HEAP, lsr #32
    //     0xd0c368: b.eq            #0xd0c370
    //     0xd0c36c: bl              #0xd6826c
    // 0xd0c370: cmp             w2, NULL
    // 0xd0c374: r16 = true
    //     0xd0c374: add             x16, NULL, #0x20  ; true
    // 0xd0c378: r17 = false
    //     0xd0c378: add             x17, NULL, #0x30  ; false
    // 0xd0c37c: csel            x0, x16, x17, ne
    // 0xd0c380: cmp             w0, w3
    // 0xd0c384: b.eq            #0xd0c394
    // 0xd0c388: SaveReg r1
    //     0xd0c388: str             x1, [SP, #-8]!
    // 0xd0c38c: r0 = markNeedsSemanticsUpdate()
    //     0xd0c38c: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xd0c390: add             SP, SP, #8
    // 0xd0c394: r0 = Null
    //     0xd0c394: mov             x0, NULL
    // 0xd0c398: LeaveFrame
    //     0xd0c398: mov             SP, fp
    //     0xd0c39c: ldp             fp, lr, [SP], #0x10
    // 0xd0c3a0: ret
    //     0xd0c3a0: ret             
    // 0xd0c3a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0c3a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0c3a8: b               #0xd0c2ec
  }
  set _ onLongPress=(/* No info */) {
    // ** addr: 0xd0c5b4, size: 0xd4
    // 0xd0c5b4: EnterFrame
    //     0xd0c5b4: stp             fp, lr, [SP, #-0x10]!
    //     0xd0c5b8: mov             fp, SP
    // 0xd0c5bc: CheckStackOverflow
    //     0xd0c5bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd0c5c0: cmp             SP, x16
    //     0xd0c5c4: b.ls            #0xd0c680
    // 0xd0c5c8: ldr             x1, [fp, #0x18]
    // 0xd0c5cc: LoadField: r0 = r1->field_6f
    //     0xd0c5cc: ldur            w0, [x1, #0x6f]
    // 0xd0c5d0: DecompressPointer r0
    //     0xd0c5d0: add             x0, x0, HEAP, lsl #32
    // 0xd0c5d4: r2 = LoadClassIdInstr(r0)
    //     0xd0c5d4: ldur            x2, [x0, #-1]
    //     0xd0c5d8: ubfx            x2, x2, #0xc, #0x14
    // 0xd0c5dc: ldr             x16, [fp, #0x10]
    // 0xd0c5e0: stp             x16, x0, [SP, #-0x10]!
    // 0xd0c5e4: mov             x0, x2
    // 0xd0c5e8: mov             lr, x0
    // 0xd0c5ec: ldr             lr, [x21, lr, lsl #3]
    // 0xd0c5f0: blr             lr
    // 0xd0c5f4: add             SP, SP, #0x10
    // 0xd0c5f8: tbnz            w0, #4, #0xd0c60c
    // 0xd0c5fc: r0 = Null
    //     0xd0c5fc: mov             x0, NULL
    // 0xd0c600: LeaveFrame
    //     0xd0c600: mov             SP, fp
    //     0xd0c604: ldp             fp, lr, [SP], #0x10
    // 0xd0c608: ret
    //     0xd0c608: ret             
    // 0xd0c60c: ldr             x1, [fp, #0x18]
    // 0xd0c610: ldr             x2, [fp, #0x10]
    // 0xd0c614: LoadField: r0 = r1->field_6f
    //     0xd0c614: ldur            w0, [x1, #0x6f]
    // 0xd0c618: DecompressPointer r0
    //     0xd0c618: add             x0, x0, HEAP, lsl #32
    // 0xd0c61c: cmp             w0, NULL
    // 0xd0c620: r16 = true
    //     0xd0c620: add             x16, NULL, #0x20  ; true
    // 0xd0c624: r17 = false
    //     0xd0c624: add             x17, NULL, #0x30  ; false
    // 0xd0c628: csel            x3, x16, x17, ne
    // 0xd0c62c: mov             x0, x2
    // 0xd0c630: StoreField: r1->field_6f = r0
    //     0xd0c630: stur            w0, [x1, #0x6f]
    //     0xd0c634: ldurb           w16, [x1, #-1]
    //     0xd0c638: ldurb           w17, [x0, #-1]
    //     0xd0c63c: and             x16, x17, x16, lsr #2
    //     0xd0c640: tst             x16, HEAP, lsr #32
    //     0xd0c644: b.eq            #0xd0c64c
    //     0xd0c648: bl              #0xd6826c
    // 0xd0c64c: cmp             w2, NULL
    // 0xd0c650: r16 = true
    //     0xd0c650: add             x16, NULL, #0x20  ; true
    // 0xd0c654: r17 = false
    //     0xd0c654: add             x17, NULL, #0x30  ; false
    // 0xd0c658: csel            x0, x16, x17, ne
    // 0xd0c65c: cmp             w0, w3
    // 0xd0c660: b.eq            #0xd0c670
    // 0xd0c664: SaveReg r1
    //     0xd0c664: str             x1, [SP, #-8]!
    // 0xd0c668: r0 = markNeedsSemanticsUpdate()
    //     0xd0c668: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xd0c66c: add             SP, SP, #8
    // 0xd0c670: r0 = Null
    //     0xd0c670: mov             x0, NULL
    // 0xd0c674: LeaveFrame
    //     0xd0c674: mov             SP, fp
    //     0xd0c678: ldp             fp, lr, [SP], #0x10
    // 0xd0c67c: ret
    //     0xd0c67c: ret             
    // 0xd0c680: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0c680: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0c684: b               #0xd0c5c8
  }
}

// class id: 2519, size: 0x80, field offset: 0x68
class RenderMouseRegion extends RenderProxyBoxWithHitTestBehavior
    implements MouseTrackerAnnotation {

  _ hitTest(/* No info */) {
    // ** addr: 0x63f1c4, size: 0x54
    // 0x63f1c4: EnterFrame
    //     0x63f1c4: stp             fp, lr, [SP, #-0x10]!
    //     0x63f1c8: mov             fp, SP
    // 0x63f1cc: CheckStackOverflow
    //     0x63f1cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63f1d0: cmp             SP, x16
    //     0x63f1d4: b.ls            #0x63f210
    // 0x63f1d8: ldr             x16, [fp, #0x20]
    // 0x63f1dc: ldr             lr, [fp, #0x18]
    // 0x63f1e0: stp             lr, x16, [SP, #-0x10]!
    // 0x63f1e4: ldr             x16, [fp, #0x10]
    // 0x63f1e8: SaveReg r16
    //     0x63f1e8: str             x16, [SP, #-8]!
    // 0x63f1ec: r0 = hitTest()
    //     0x63f1ec: bl              #0x63f3a4  ; [package:flutter/src/rendering/proxy_box.dart] RenderProxyBoxWithHitTestBehavior::hitTest
    // 0x63f1f0: add             SP, SP, #0x18
    // 0x63f1f4: tbnz            w0, #4, #0x63f200
    // 0x63f1f8: r0 = true
    //     0x63f1f8: add             x0, NULL, #0x20  ; true
    // 0x63f1fc: b               #0x63f204
    // 0x63f200: r0 = false
    //     0x63f200: add             x0, NULL, #0x30  ; false
    // 0x63f204: LeaveFrame
    //     0x63f204: mov             SP, fp
    //     0x63f208: ldp             fp, lr, [SP], #0x10
    // 0x63f20c: ret
    //     0x63f20c: ret             
    // 0x63f210: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63f210: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63f214: b               #0x63f1d8
  }
  set _ hitTestBehavior=(/* No info */) {
    // ** addr: 0x6c69fc, size: 0x60
    // 0x6c69fc: EnterFrame
    //     0x6c69fc: stp             fp, lr, [SP, #-0x10]!
    //     0x6c6a00: mov             fp, SP
    // 0x6c6a04: CheckStackOverflow
    //     0x6c6a04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c6a08: cmp             SP, x16
    //     0x6c6a0c: b.ls            #0x6c6a54
    // 0x6c6a10: ldr             x0, [fp, #0x18]
    // 0x6c6a14: LoadField: r1 = r0->field_63
    //     0x6c6a14: ldur            w1, [x0, #0x63]
    // 0x6c6a18: DecompressPointer r1
    //     0x6c6a18: add             x1, x1, HEAP, lsl #32
    // 0x6c6a1c: r16 = Instance_HitTestBehavior
    //     0x6c6a1c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15408] Obj!HitTestBehavior@b648f1
    //     0x6c6a20: ldr             x16, [x16, #0x408]
    // 0x6c6a24: cmp             w1, w16
    // 0x6c6a28: b.eq            #0x6c6a44
    // 0x6c6a2c: r1 = Instance_HitTestBehavior
    //     0x6c6a2c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15408] Obj!HitTestBehavior@b648f1
    //     0x6c6a30: ldr             x1, [x1, #0x408]
    // 0x6c6a34: StoreField: r0->field_63 = r1
    //     0x6c6a34: stur            w1, [x0, #0x63]
    // 0x6c6a38: SaveReg r0
    //     0x6c6a38: str             x0, [SP, #-8]!
    // 0x6c6a3c: r0 = markNeedsPaint()
    //     0x6c6a3c: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c6a40: add             SP, SP, #8
    // 0x6c6a44: r0 = Null
    //     0x6c6a44: mov             x0, NULL
    // 0x6c6a48: LeaveFrame
    //     0x6c6a48: mov             SP, fp
    //     0x6c6a4c: ldp             fp, lr, [SP], #0x10
    // 0x6c6a50: ret
    //     0x6c6a50: ret             
    // 0x6c6a54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6a54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c6a58: b               #0x6c6a10
  }
  set _ cursor=(/* No info */) {
    // ** addr: 0x6c6a5c, size: 0x90
    // 0x6c6a5c: EnterFrame
    //     0x6c6a5c: stp             fp, lr, [SP, #-0x10]!
    //     0x6c6a60: mov             fp, SP
    // 0x6c6a64: CheckStackOverflow
    //     0x6c6a64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c6a68: cmp             SP, x16
    //     0x6c6a6c: b.ls            #0x6c6ae4
    // 0x6c6a70: ldr             x1, [fp, #0x18]
    // 0x6c6a74: LoadField: r0 = r1->field_77
    //     0x6c6a74: ldur            w0, [x1, #0x77]
    // 0x6c6a78: DecompressPointer r0
    //     0x6c6a78: add             x0, x0, HEAP, lsl #32
    // 0x6c6a7c: r2 = LoadClassIdInstr(r0)
    //     0x6c6a7c: ldur            x2, [x0, #-1]
    //     0x6c6a80: ubfx            x2, x2, #0xc, #0x14
    // 0x6c6a84: ldr             x16, [fp, #0x10]
    // 0x6c6a88: stp             x16, x0, [SP, #-0x10]!
    // 0x6c6a8c: mov             x0, x2
    // 0x6c6a90: mov             lr, x0
    // 0x6c6a94: ldr             lr, [x21, lr, lsl #3]
    // 0x6c6a98: blr             lr
    // 0x6c6a9c: add             SP, SP, #0x10
    // 0x6c6aa0: tbz             w0, #4, #0x6c6ad4
    // 0x6c6aa4: ldr             x1, [fp, #0x18]
    // 0x6c6aa8: ldr             x0, [fp, #0x10]
    // 0x6c6aac: StoreField: r1->field_77 = r0
    //     0x6c6aac: stur            w0, [x1, #0x77]
    //     0x6c6ab0: ldurb           w16, [x1, #-1]
    //     0x6c6ab4: ldurb           w17, [x0, #-1]
    //     0x6c6ab8: and             x16, x17, x16, lsr #2
    //     0x6c6abc: tst             x16, HEAP, lsr #32
    //     0x6c6ac0: b.eq            #0x6c6ac8
    //     0x6c6ac4: bl              #0xd6826c
    // 0x6c6ac8: SaveReg r1
    //     0x6c6ac8: str             x1, [SP, #-8]!
    // 0x6c6acc: r0 = markNeedsPaint()
    //     0x6c6acc: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c6ad0: add             SP, SP, #8
    // 0x6c6ad4: r0 = Null
    //     0x6c6ad4: mov             x0, NULL
    // 0x6c6ad8: LeaveFrame
    //     0x6c6ad8: mov             SP, fp
    //     0x6c6adc: ldp             fp, lr, [SP], #0x10
    // 0x6c6ae0: ret
    //     0x6c6ae0: ret             
    // 0x6c6ae4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6ae4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c6ae8: b               #0x6c6a70
  }
  _ RenderMouseRegion(/* No info */) {
    // ** addr: 0x6ec604, size: 0xe4
    // 0x6ec604: EnterFrame
    //     0x6ec604: stp             fp, lr, [SP, #-0x10]!
    //     0x6ec608: mov             fp, SP
    // 0x6ec60c: r2 = true
    //     0x6ec60c: add             x2, NULL, #0x20  ; true
    // 0x6ec610: r1 = Instance_HitTestBehavior
    //     0x6ec610: add             x1, PP, #0x15, lsl #12  ; [pp+0x15408] Obj!HitTestBehavior@b648f1
    //     0x6ec614: ldr             x1, [x1, #0x408]
    // 0x6ec618: CheckStackOverflow
    //     0x6ec618: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ec61c: cmp             SP, x16
    //     0x6ec620: b.ls            #0x6ec6e0
    // 0x6ec624: ldr             x0, [fp, #0x20]
    // 0x6ec628: ldr             x3, [fp, #0x30]
    // 0x6ec62c: StoreField: r3->field_6b = r0
    //     0x6ec62c: stur            w0, [x3, #0x6b]
    //     0x6ec630: ldurb           w16, [x3, #-1]
    //     0x6ec634: ldurb           w17, [x0, #-1]
    //     0x6ec638: and             x16, x17, x16, lsr #2
    //     0x6ec63c: tst             x16, HEAP, lsr #32
    //     0x6ec640: b.eq            #0x6ec648
    //     0x6ec644: bl              #0xd682ac
    // 0x6ec648: ldr             x0, [fp, #0x10]
    // 0x6ec64c: StoreField: r3->field_6f = r0
    //     0x6ec64c: stur            w0, [x3, #0x6f]
    //     0x6ec650: ldurb           w16, [x3, #-1]
    //     0x6ec654: ldurb           w17, [x0, #-1]
    //     0x6ec658: and             x16, x17, x16, lsr #2
    //     0x6ec65c: tst             x16, HEAP, lsr #32
    //     0x6ec660: b.eq            #0x6ec668
    //     0x6ec664: bl              #0xd682ac
    // 0x6ec668: ldr             x0, [fp, #0x18]
    // 0x6ec66c: StoreField: r3->field_73 = r0
    //     0x6ec66c: stur            w0, [x3, #0x73]
    //     0x6ec670: ldurb           w16, [x3, #-1]
    //     0x6ec674: ldurb           w17, [x0, #-1]
    //     0x6ec678: and             x16, x17, x16, lsr #2
    //     0x6ec67c: tst             x16, HEAP, lsr #32
    //     0x6ec680: b.eq            #0x6ec688
    //     0x6ec684: bl              #0xd682ac
    // 0x6ec688: ldr             x0, [fp, #0x28]
    // 0x6ec68c: StoreField: r3->field_77 = r0
    //     0x6ec68c: stur            w0, [x3, #0x77]
    //     0x6ec690: ldurb           w16, [x3, #-1]
    //     0x6ec694: ldurb           w17, [x0, #-1]
    //     0x6ec698: and             x16, x17, x16, lsr #2
    //     0x6ec69c: tst             x16, HEAP, lsr #32
    //     0x6ec6a0: b.eq            #0x6ec6a8
    //     0x6ec6a4: bl              #0xd682ac
    // 0x6ec6a8: StoreField: r3->field_7b = r2
    //     0x6ec6a8: stur            w2, [x3, #0x7b]
    // 0x6ec6ac: StoreField: r3->field_67 = r2
    //     0x6ec6ac: stur            w2, [x3, #0x67]
    // 0x6ec6b0: StoreField: r3->field_63 = r1
    //     0x6ec6b0: stur            w1, [x3, #0x63]
    // 0x6ec6b4: SaveReg r3
    //     0x6ec6b4: str             x3, [SP, #-8]!
    // 0x6ec6b8: r0 = RenderObject()
    //     0x6ec6b8: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6ec6bc: add             SP, SP, #8
    // 0x6ec6c0: ldr             x16, [fp, #0x30]
    // 0x6ec6c4: stp             NULL, x16, [SP, #-0x10]!
    // 0x6ec6c8: r0 = child=()
    //     0x6ec6c8: bl              #0x6e7da0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::child=
    // 0x6ec6cc: add             SP, SP, #0x10
    // 0x6ec6d0: r0 = Null
    //     0x6ec6d0: mov             x0, NULL
    // 0x6ec6d4: LeaveFrame
    //     0x6ec6d4: mov             SP, fp
    //     0x6ec6d8: ldp             fp, lr, [SP], #0x10
    // 0x6ec6dc: ret
    //     0x6ec6dc: ret             
    // 0x6ec6e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ec6e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ec6e4: b               #0x6ec624
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0x715f74, size: 0xd0
    // 0x715f74: EnterFrame
    //     0x715f74: stp             fp, lr, [SP, #-0x10]!
    //     0x715f78: mov             fp, SP
    // 0x715f7c: AllocStack(0x8)
    //     0x715f7c: sub             SP, SP, #8
    // 0x715f80: CheckStackOverflow
    //     0x715f80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x715f84: cmp             SP, x16
    //     0x715f88: b.ls            #0x71603c
    // 0x715f8c: ldr             x0, [fp, #0x10]
    // 0x715f90: r2 = Null
    //     0x715f90: mov             x2, NULL
    // 0x715f94: r1 = Null
    //     0x715f94: mov             x1, NULL
    // 0x715f98: r8 = HitTestEntry<HitTestTarget>
    //     0x715f98: ldr             x8, [PP, #0x72c0]  ; [pp+0x72c0] Type: HitTestEntry<HitTestTarget>
    // 0x715f9c: r3 = Null
    //     0x715f9c: add             x3, PP, #0x21, lsl #12  ; [pp+0x21c60] Null
    //     0x715fa0: ldr             x3, [x3, #0xc60]
    // 0x715fa4: r0 = HitTestEntry<HitTestTarget>()
    //     0x715fa4: bl              #0x50f268  ; IsType_HitTestEntry<HitTestTarget>_Stub
    // 0x715fa8: ldr             x0, [fp, #0x20]
    // 0x715fac: LoadField: r3 = r0->field_6f
    //     0x715fac: ldur            w3, [x0, #0x6f]
    // 0x715fb0: DecompressPointer r3
    //     0x715fb0: add             x3, x3, HEAP, lsl #32
    // 0x715fb4: stur            x3, [fp, #-8]
    // 0x715fb8: cmp             w3, NULL
    // 0x715fbc: b.eq            #0x71602c
    // 0x715fc0: ldr             x0, [fp, #0x18]
    // 0x715fc4: r2 = Null
    //     0x715fc4: mov             x2, NULL
    // 0x715fc8: r1 = Null
    //     0x715fc8: mov             x1, NULL
    // 0x715fcc: cmp             w0, NULL
    // 0x715fd0: b.eq            #0x715ff0
    // 0x715fd4: branchIfSmi(r0, 0x715ff0)
    //     0x715fd4: tbz             w0, #0, #0x715ff0
    // 0x715fd8: r3 = LoadClassIdInstr(r0)
    //     0x715fd8: ldur            x3, [x0, #-1]
    //     0x715fdc: ubfx            x3, x3, #0xc, #0x14
    // 0x715fe0: cmp             x3, #0x910
    // 0x715fe4: b.eq            #0x715ff8
    // 0x715fe8: cmp             x3, #0xb47
    // 0x715fec: b.eq            #0x715ff8
    // 0x715ff0: r0 = false
    //     0x715ff0: add             x0, NULL, #0x30  ; false
    // 0x715ff4: b               #0x715ffc
    // 0x715ff8: r0 = true
    //     0x715ff8: add             x0, NULL, #0x20  ; true
    // 0x715ffc: tbnz            w0, #4, #0x71602c
    // 0x716000: ldur            x16, [fp, #-8]
    // 0x716004: ldr             lr, [fp, #0x18]
    // 0x716008: stp             lr, x16, [SP, #-0x10]!
    // 0x71600c: ldur            x0, [fp, #-8]
    // 0x716010: ClosureCall
    //     0x716010: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x716014: ldur            x2, [x0, #0x1f]
    //     0x716018: blr             x2
    // 0x71601c: add             SP, SP, #0x10
    // 0x716020: LeaveFrame
    //     0x716020: mov             SP, fp
    //     0x716024: ldp             fp, lr, [SP], #0x10
    // 0x716028: ret
    //     0x716028: ret             
    // 0x71602c: r0 = Null
    //     0x71602c: mov             x0, NULL
    // 0x716030: LeaveFrame
    //     0x716030: mov             SP, fp
    //     0x716034: ldp             fp, lr, [SP], #0x10
    // 0x716038: ret
    //     0x716038: ret             
    // 0x71603c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71603c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x716040: b               #0x715f8c
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bd26c, size: 0x80
    // 0x9bd26c: EnterFrame
    //     0x9bd26c: stp             fp, lr, [SP, #-0x10]!
    //     0x9bd270: mov             fp, SP
    // 0x9bd274: CheckStackOverflow
    //     0x9bd274: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bd278: cmp             SP, x16
    //     0x9bd27c: b.ls            #0x9bd2e4
    // 0x9bd280: ldr             x0, [fp, #0x10]
    // 0x9bd284: r2 = Null
    //     0x9bd284: mov             x2, NULL
    // 0x9bd288: r1 = Null
    //     0x9bd288: mov             x1, NULL
    // 0x9bd28c: r4 = 59
    //     0x9bd28c: mov             x4, #0x3b
    // 0x9bd290: branchIfSmi(r0, 0x9bd29c)
    //     0x9bd290: tbz             w0, #0, #0x9bd29c
    // 0x9bd294: r4 = LoadClassIdInstr(r0)
    //     0x9bd294: ldur            x4, [x0, #-1]
    //     0x9bd298: ubfx            x4, x4, #0xc, #0x14
    // 0x9bd29c: cmp             x4, #0x7e6
    // 0x9bd2a0: b.eq            #0x9bd2b4
    // 0x9bd2a4: r8 = PipelineOwner
    //     0x9bd2a4: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9bd2a8: r3 = Null
    //     0x9bd2a8: add             x3, PP, #0x21, lsl #12  ; [pp+0x21c50] Null
    //     0x9bd2ac: ldr             x3, [x3, #0xc50]
    // 0x9bd2b0: r0 = DefaultTypeTest()
    //     0x9bd2b0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bd2b4: ldr             x16, [fp, #0x18]
    // 0x9bd2b8: ldr             lr, [fp, #0x10]
    // 0x9bd2bc: stp             lr, x16, [SP, #-0x10]!
    // 0x9bd2c0: r0 = attach()
    //     0x9bd2c0: bl              #0x9bd674  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::attach
    // 0x9bd2c4: add             SP, SP, #0x10
    // 0x9bd2c8: ldr             x2, [fp, #0x18]
    // 0x9bd2cc: r1 = true
    //     0x9bd2cc: add             x1, NULL, #0x20  ; true
    // 0x9bd2d0: StoreField: r2->field_7b = r1
    //     0x9bd2d0: stur            w1, [x2, #0x7b]
    // 0x9bd2d4: r0 = Null
    //     0x9bd2d4: mov             x0, NULL
    // 0x9bd2d8: LeaveFrame
    //     0x9bd2d8: mov             SP, fp
    //     0x9bd2dc: ldp             fp, lr, [SP], #0x10
    // 0x9bd2e0: ret
    //     0x9bd2e0: ret             
    // 0x9bd2e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bd2e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bd2e8: b               #0x9bd280
  }
  _ detach(/* No info */) {
    // ** addr: 0xa69020, size: 0x44
    // 0xa69020: EnterFrame
    //     0xa69020: stp             fp, lr, [SP, #-0x10]!
    //     0xa69024: mov             fp, SP
    // 0xa69028: r0 = false
    //     0xa69028: add             x0, NULL, #0x30  ; false
    // 0xa6902c: CheckStackOverflow
    //     0xa6902c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa69030: cmp             SP, x16
    //     0xa69034: b.ls            #0xa6905c
    // 0xa69038: ldr             x1, [fp, #0x10]
    // 0xa6903c: StoreField: r1->field_7b = r0
    //     0xa6903c: stur            w0, [x1, #0x7b]
    // 0xa69040: SaveReg r1
    //     0xa69040: str             x1, [SP, #-8]!
    // 0xa69044: r0 = detach()
    //     0xa69044: bl              #0xa693e0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::detach
    // 0xa69048: add             SP, SP, #8
    // 0xa6904c: r0 = Null
    //     0xa6904c: mov             x0, NULL
    // 0xa69050: LeaveFrame
    //     0xa69050: mov             SP, fp
    //     0xa69054: ldp             fp, lr, [SP], #0x10
    // 0xa69058: ret
    //     0xa69058: ret             
    // 0xa6905c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6905c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa69060: b               #0xa69038
  }
  get _ onEnter(/* No info */) {
    // ** addr: 0xb806b0, size: 0x10
    // 0xb806b0: ldr             x1, [SP]
    // 0xb806b4: LoadField: r0 = r1->field_6b
    //     0xb806b4: ldur            w0, [x1, #0x6b]
    // 0xb806b8: DecompressPointer r0
    //     0xb806b8: add             x0, x0, HEAP, lsl #32
    // 0xb806bc: ret
    //     0xb806bc: ret             
  }
  get _ validForMouseTracker(/* No info */) {
    // ** addr: 0xc6f300, size: 0x10
    // 0xc6f300: ldr             x1, [SP]
    // 0xc6f304: LoadField: r0 = r1->field_7b
    //     0xc6f304: ldur            w0, [x1, #0x7b]
    // 0xc6f308: DecompressPointer r0
    //     0xc6f308: add             x0, x0, HEAP, lsl #32
    // 0xc6f30c: ret
    //     0xc6f30c: ret             
  }
}

// class id: 2520, size: 0x8c, field offset: 0x68
class RenderPointerListener extends RenderProxyBoxWithHitTestBehavior {

  _ RenderPointerListener(/* No info */) {
    // ** addr: 0x6ec43c, size: 0x12c
    // 0x6ec43c: EnterFrame
    //     0x6ec43c: stp             fp, lr, [SP, #-0x10]!
    //     0x6ec440: mov             fp, SP
    // 0x6ec444: CheckStackOverflow
    //     0x6ec444: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ec448: cmp             SP, x16
    //     0x6ec44c: b.ls            #0x6ec560
    // 0x6ec450: ldr             x0, [fp, #0x30]
    // 0x6ec454: ldr             x1, [fp, #0x48]
    // 0x6ec458: StoreField: r1->field_67 = r0
    //     0x6ec458: stur            w0, [x1, #0x67]
    //     0x6ec45c: ldurb           w16, [x1, #-1]
    //     0x6ec460: ldurb           w17, [x0, #-1]
    //     0x6ec464: and             x16, x17, x16, lsr #2
    //     0x6ec468: tst             x16, HEAP, lsr #32
    //     0x6ec46c: b.eq            #0x6ec474
    //     0x6ec470: bl              #0xd6826c
    // 0x6ec474: ldr             x0, [fp, #0x28]
    // 0x6ec478: StoreField: r1->field_6b = r0
    //     0x6ec478: stur            w0, [x1, #0x6b]
    //     0x6ec47c: ldurb           w16, [x1, #-1]
    //     0x6ec480: ldurb           w17, [x0, #-1]
    //     0x6ec484: and             x16, x17, x16, lsr #2
    //     0x6ec488: tst             x16, HEAP, lsr #32
    //     0x6ec48c: b.eq            #0x6ec494
    //     0x6ec490: bl              #0xd6826c
    // 0x6ec494: ldr             x0, [fp, #0x10]
    // 0x6ec498: StoreField: r1->field_6f = r0
    //     0x6ec498: stur            w0, [x1, #0x6f]
    //     0x6ec49c: ldurb           w16, [x1, #-1]
    //     0x6ec4a0: ldurb           w17, [x0, #-1]
    //     0x6ec4a4: and             x16, x17, x16, lsr #2
    //     0x6ec4a8: tst             x16, HEAP, lsr #32
    //     0x6ec4ac: b.eq            #0x6ec4b4
    //     0x6ec4b0: bl              #0xd6826c
    // 0x6ec4b4: ldr             x0, [fp, #0x38]
    // 0x6ec4b8: StoreField: r1->field_77 = r0
    //     0x6ec4b8: stur            w0, [x1, #0x77]
    //     0x6ec4bc: ldurb           w16, [x1, #-1]
    //     0x6ec4c0: ldurb           w17, [x0, #-1]
    //     0x6ec4c4: and             x16, x17, x16, lsr #2
    //     0x6ec4c8: tst             x16, HEAP, lsr #32
    //     0x6ec4cc: b.eq            #0x6ec4d4
    //     0x6ec4d0: bl              #0xd6826c
    // 0x6ec4d4: ldr             x0, [fp, #0x20]
    // 0x6ec4d8: StoreField: r1->field_7b = r0
    //     0x6ec4d8: stur            w0, [x1, #0x7b]
    //     0x6ec4dc: ldurb           w16, [x1, #-1]
    //     0x6ec4e0: ldurb           w17, [x0, #-1]
    //     0x6ec4e4: and             x16, x17, x16, lsr #2
    //     0x6ec4e8: tst             x16, HEAP, lsr #32
    //     0x6ec4ec: b.eq            #0x6ec4f4
    //     0x6ec4f0: bl              #0xd6826c
    // 0x6ec4f4: ldr             x0, [fp, #0x18]
    // 0x6ec4f8: StoreField: r1->field_87 = r0
    //     0x6ec4f8: stur            w0, [x1, #0x87]
    //     0x6ec4fc: ldurb           w16, [x1, #-1]
    //     0x6ec500: ldurb           w17, [x0, #-1]
    //     0x6ec504: and             x16, x17, x16, lsr #2
    //     0x6ec508: tst             x16, HEAP, lsr #32
    //     0x6ec50c: b.eq            #0x6ec514
    //     0x6ec510: bl              #0xd6826c
    // 0x6ec514: ldr             x0, [fp, #0x40]
    // 0x6ec518: StoreField: r1->field_63 = r0
    //     0x6ec518: stur            w0, [x1, #0x63]
    //     0x6ec51c: ldurb           w16, [x1, #-1]
    //     0x6ec520: ldurb           w17, [x0, #-1]
    //     0x6ec524: and             x16, x17, x16, lsr #2
    //     0x6ec528: tst             x16, HEAP, lsr #32
    //     0x6ec52c: b.eq            #0x6ec534
    //     0x6ec530: bl              #0xd6826c
    // 0x6ec534: SaveReg r1
    //     0x6ec534: str             x1, [SP, #-8]!
    // 0x6ec538: r0 = RenderObject()
    //     0x6ec538: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6ec53c: add             SP, SP, #8
    // 0x6ec540: ldr             x16, [fp, #0x48]
    // 0x6ec544: stp             NULL, x16, [SP, #-0x10]!
    // 0x6ec548: r0 = child=()
    //     0x6ec548: bl              #0x6e7da0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::child=
    // 0x6ec54c: add             SP, SP, #0x10
    // 0x6ec550: r0 = Null
    //     0x6ec550: mov             x0, NULL
    // 0x6ec554: LeaveFrame
    //     0x6ec554: mov             SP, fp
    //     0x6ec558: ldp             fp, lr, [SP], #0x10
    // 0x6ec55c: ret
    //     0x6ec55c: ret             
    // 0x6ec560: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ec560: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ec564: b               #0x6ec450
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0x715b1c, size: 0x458
    // 0x715b1c: EnterFrame
    //     0x715b1c: stp             fp, lr, [SP, #-0x10]!
    //     0x715b20: mov             fp, SP
    // 0x715b24: CheckStackOverflow
    //     0x715b24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x715b28: cmp             SP, x16
    //     0x715b2c: b.ls            #0x715f6c
    // 0x715b30: ldr             x0, [fp, #0x10]
    // 0x715b34: r2 = Null
    //     0x715b34: mov             x2, NULL
    // 0x715b38: r1 = Null
    //     0x715b38: mov             x1, NULL
    // 0x715b3c: r8 = HitTestEntry<HitTestTarget>
    //     0x715b3c: ldr             x8, [PP, #0x72c0]  ; [pp+0x72c0] Type: HitTestEntry<HitTestTarget>
    // 0x715b40: r3 = Null
    //     0x715b40: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3fc18] Null
    //     0x715b44: ldr             x3, [x3, #0xc18]
    // 0x715b48: r0 = HitTestEntry<HitTestTarget>()
    //     0x715b48: bl              #0x50f268  ; IsType_HitTestEntry<HitTestTarget>_Stub
    // 0x715b4c: ldr             x0, [fp, #0x18]
    // 0x715b50: r2 = Null
    //     0x715b50: mov             x2, NULL
    // 0x715b54: r1 = Null
    //     0x715b54: mov             x1, NULL
    // 0x715b58: cmp             w0, NULL
    // 0x715b5c: b.eq            #0x715b7c
    // 0x715b60: branchIfSmi(r0, 0x715b7c)
    //     0x715b60: tbz             w0, #0, #0x715b7c
    // 0x715b64: r3 = LoadClassIdInstr(r0)
    //     0x715b64: ldur            x3, [x0, #-1]
    //     0x715b68: ubfx            x3, x3, #0xc, #0x14
    // 0x715b6c: cmp             x3, #0x90a
    // 0x715b70: b.eq            #0x715b84
    // 0x715b74: cmp             x3, #0xb41
    // 0x715b78: b.eq            #0x715b84
    // 0x715b7c: r0 = false
    //     0x715b7c: add             x0, NULL, #0x30  ; false
    // 0x715b80: b               #0x715b88
    // 0x715b84: r0 = true
    //     0x715b84: add             x0, NULL, #0x20  ; true
    // 0x715b88: tbnz            w0, #4, #0x715bcc
    // 0x715b8c: ldr             x3, [fp, #0x20]
    // 0x715b90: LoadField: r0 = r3->field_67
    //     0x715b90: ldur            w0, [x3, #0x67]
    // 0x715b94: DecompressPointer r0
    //     0x715b94: add             x0, x0, HEAP, lsl #32
    // 0x715b98: cmp             w0, NULL
    // 0x715b9c: b.ne            #0x715ba8
    // 0x715ba0: r0 = Null
    //     0x715ba0: mov             x0, NULL
    // 0x715ba4: b               #0x715bc0
    // 0x715ba8: ldr             x16, [fp, #0x18]
    // 0x715bac: stp             x16, x0, [SP, #-0x10]!
    // 0x715bb0: ClosureCall
    //     0x715bb0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x715bb4: ldur            x2, [x0, #0x1f]
    //     0x715bb8: blr             x2
    // 0x715bbc: add             SP, SP, #0x10
    // 0x715bc0: LeaveFrame
    //     0x715bc0: mov             SP, fp
    //     0x715bc4: ldp             fp, lr, [SP], #0x10
    // 0x715bc8: ret
    //     0x715bc8: ret             
    // 0x715bcc: ldr             x3, [fp, #0x20]
    // 0x715bd0: ldr             x0, [fp, #0x18]
    // 0x715bd4: r2 = Null
    //     0x715bd4: mov             x2, NULL
    // 0x715bd8: r1 = Null
    //     0x715bd8: mov             x1, NULL
    // 0x715bdc: cmp             w0, NULL
    // 0x715be0: b.eq            #0x715c00
    // 0x715be4: branchIfSmi(r0, 0x715c00)
    //     0x715be4: tbz             w0, #0, #0x715c00
    // 0x715be8: r3 = LoadClassIdInstr(r0)
    //     0x715be8: ldur            x3, [x0, #-1]
    //     0x715bec: ubfx            x3, x3, #0xc, #0x14
    // 0x715bf0: cmp             x3, #0x908
    // 0x715bf4: b.eq            #0x715c08
    // 0x715bf8: cmp             x3, #0xb3f
    // 0x715bfc: b.eq            #0x715c08
    // 0x715c00: r0 = false
    //     0x715c00: add             x0, NULL, #0x30  ; false
    // 0x715c04: b               #0x715c0c
    // 0x715c08: r0 = true
    //     0x715c08: add             x0, NULL, #0x20  ; true
    // 0x715c0c: tbnz            w0, #4, #0x715c50
    // 0x715c10: ldr             x3, [fp, #0x20]
    // 0x715c14: LoadField: r0 = r3->field_6b
    //     0x715c14: ldur            w0, [x3, #0x6b]
    // 0x715c18: DecompressPointer r0
    //     0x715c18: add             x0, x0, HEAP, lsl #32
    // 0x715c1c: cmp             w0, NULL
    // 0x715c20: b.ne            #0x715c2c
    // 0x715c24: r0 = Null
    //     0x715c24: mov             x0, NULL
    // 0x715c28: b               #0x715c44
    // 0x715c2c: ldr             x16, [fp, #0x18]
    // 0x715c30: stp             x16, x0, [SP, #-0x10]!
    // 0x715c34: ClosureCall
    //     0x715c34: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x715c38: ldur            x2, [x0, #0x1f]
    //     0x715c3c: blr             x2
    // 0x715c40: add             SP, SP, #0x10
    // 0x715c44: LeaveFrame
    //     0x715c44: mov             SP, fp
    //     0x715c48: ldp             fp, lr, [SP], #0x10
    // 0x715c4c: ret
    //     0x715c4c: ret             
    // 0x715c50: ldr             x3, [fp, #0x20]
    // 0x715c54: ldr             x0, [fp, #0x18]
    // 0x715c58: r2 = Null
    //     0x715c58: mov             x2, NULL
    // 0x715c5c: r1 = Null
    //     0x715c5c: mov             x1, NULL
    // 0x715c60: cmp             w0, NULL
    // 0x715c64: b.eq            #0x715c84
    // 0x715c68: branchIfSmi(r0, 0x715c84)
    //     0x715c68: tbz             w0, #0, #0x715c84
    // 0x715c6c: r3 = LoadClassIdInstr(r0)
    //     0x715c6c: ldur            x3, [x0, #-1]
    //     0x715c70: ubfx            x3, x3, #0xc, #0x14
    // 0x715c74: cmp             x3, #0x906
    // 0x715c78: b.eq            #0x715c8c
    // 0x715c7c: cmp             x3, #0xb3d
    // 0x715c80: b.eq            #0x715c8c
    // 0x715c84: r0 = false
    //     0x715c84: add             x0, NULL, #0x30  ; false
    // 0x715c88: b               #0x715c90
    // 0x715c8c: r0 = true
    //     0x715c8c: add             x0, NULL, #0x20  ; true
    // 0x715c90: tbnz            w0, #4, #0x715cd4
    // 0x715c94: ldr             x3, [fp, #0x20]
    // 0x715c98: LoadField: r0 = r3->field_6f
    //     0x715c98: ldur            w0, [x3, #0x6f]
    // 0x715c9c: DecompressPointer r0
    //     0x715c9c: add             x0, x0, HEAP, lsl #32
    // 0x715ca0: cmp             w0, NULL
    // 0x715ca4: b.ne            #0x715cb0
    // 0x715ca8: r0 = Null
    //     0x715ca8: mov             x0, NULL
    // 0x715cac: b               #0x715cc8
    // 0x715cb0: ldr             x16, [fp, #0x18]
    // 0x715cb4: stp             x16, x0, [SP, #-0x10]!
    // 0x715cb8: ClosureCall
    //     0x715cb8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x715cbc: ldur            x2, [x0, #0x1f]
    //     0x715cc0: blr             x2
    // 0x715cc4: add             SP, SP, #0x10
    // 0x715cc8: LeaveFrame
    //     0x715cc8: mov             SP, fp
    //     0x715ccc: ldp             fp, lr, [SP], #0x10
    // 0x715cd0: ret
    //     0x715cd0: ret             
    // 0x715cd4: ldr             x3, [fp, #0x20]
    // 0x715cd8: ldr             x0, [fp, #0x18]
    // 0x715cdc: r2 = Null
    //     0x715cdc: mov             x2, NULL
    // 0x715ce0: r1 = Null
    //     0x715ce0: mov             x1, NULL
    // 0x715ce4: cmp             w0, NULL
    // 0x715ce8: b.eq            #0x715d08
    // 0x715cec: branchIfSmi(r0, 0x715d08)
    //     0x715cec: tbz             w0, #0, #0x715d08
    // 0x715cf0: r3 = LoadClassIdInstr(r0)
    //     0x715cf0: ldur            x3, [x0, #-1]
    //     0x715cf4: ubfx            x3, x3, #0xc, #0x14
    // 0x715cf8: cmp             x3, #0x910
    // 0x715cfc: b.eq            #0x715d10
    // 0x715d00: cmp             x3, #0xb47
    // 0x715d04: b.eq            #0x715d10
    // 0x715d08: r0 = false
    //     0x715d08: add             x0, NULL, #0x30  ; false
    // 0x715d0c: b               #0x715d14
    // 0x715d10: r0 = true
    //     0x715d10: add             x0, NULL, #0x20  ; true
    // 0x715d14: tbnz            w0, #4, #0x715d28
    // 0x715d18: r0 = Null
    //     0x715d18: mov             x0, NULL
    // 0x715d1c: LeaveFrame
    //     0x715d1c: mov             SP, fp
    //     0x715d20: ldp             fp, lr, [SP], #0x10
    // 0x715d24: ret
    //     0x715d24: ret             
    // 0x715d28: ldr             x0, [fp, #0x18]
    // 0x715d2c: r2 = Null
    //     0x715d2c: mov             x2, NULL
    // 0x715d30: r1 = Null
    //     0x715d30: mov             x1, NULL
    // 0x715d34: cmp             w0, NULL
    // 0x715d38: b.eq            #0x715d58
    // 0x715d3c: branchIfSmi(r0, 0x715d58)
    //     0x715d3c: tbz             w0, #0, #0x715d58
    // 0x715d40: r3 = LoadClassIdInstr(r0)
    //     0x715d40: ldur            x3, [x0, #-1]
    //     0x715d44: ubfx            x3, x3, #0xc, #0x14
    // 0x715d48: cmp             x3, #0x8f8
    // 0x715d4c: b.eq            #0x715d60
    // 0x715d50: cmp             x3, #0xb35
    // 0x715d54: b.eq            #0x715d60
    // 0x715d58: r0 = false
    //     0x715d58: add             x0, NULL, #0x30  ; false
    // 0x715d5c: b               #0x715d64
    // 0x715d60: r0 = true
    //     0x715d60: add             x0, NULL, #0x20  ; true
    // 0x715d64: tbnz            w0, #4, #0x715da8
    // 0x715d68: ldr             x3, [fp, #0x20]
    // 0x715d6c: LoadField: r0 = r3->field_77
    //     0x715d6c: ldur            w0, [x3, #0x77]
    // 0x715d70: DecompressPointer r0
    //     0x715d70: add             x0, x0, HEAP, lsl #32
    // 0x715d74: cmp             w0, NULL
    // 0x715d78: b.ne            #0x715d84
    // 0x715d7c: r0 = Null
    //     0x715d7c: mov             x0, NULL
    // 0x715d80: b               #0x715d9c
    // 0x715d84: ldr             x16, [fp, #0x18]
    // 0x715d88: stp             x16, x0, [SP, #-0x10]!
    // 0x715d8c: ClosureCall
    //     0x715d8c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x715d90: ldur            x2, [x0, #0x1f]
    //     0x715d94: blr             x2
    // 0x715d98: add             SP, SP, #0x10
    // 0x715d9c: LeaveFrame
    //     0x715d9c: mov             SP, fp
    //     0x715da0: ldp             fp, lr, [SP], #0x10
    // 0x715da4: ret
    //     0x715da4: ret             
    // 0x715da8: ldr             x3, [fp, #0x20]
    // 0x715dac: ldr             x0, [fp, #0x18]
    // 0x715db0: r2 = Null
    //     0x715db0: mov             x2, NULL
    // 0x715db4: r1 = Null
    //     0x715db4: mov             x1, NULL
    // 0x715db8: cmp             w0, NULL
    // 0x715dbc: b.eq            #0x715ddc
    // 0x715dc0: branchIfSmi(r0, 0x715ddc)
    //     0x715dc0: tbz             w0, #0, #0x715ddc
    // 0x715dc4: r3 = LoadClassIdInstr(r0)
    //     0x715dc4: ldur            x3, [x0, #-1]
    //     0x715dc8: ubfx            x3, x3, #0xc, #0x14
    // 0x715dcc: cmp             x3, #0x8fe
    // 0x715dd0: b.eq            #0x715de4
    // 0x715dd4: cmp             x3, #0xb3b
    // 0x715dd8: b.eq            #0x715de4
    // 0x715ddc: r0 = false
    //     0x715ddc: add             x0, NULL, #0x30  ; false
    // 0x715de0: b               #0x715de8
    // 0x715de4: r0 = true
    //     0x715de4: add             x0, NULL, #0x20  ; true
    // 0x715de8: tbnz            w0, #4, #0x715e2c
    // 0x715dec: ldr             x3, [fp, #0x20]
    // 0x715df0: LoadField: r0 = r3->field_7b
    //     0x715df0: ldur            w0, [x3, #0x7b]
    // 0x715df4: DecompressPointer r0
    //     0x715df4: add             x0, x0, HEAP, lsl #32
    // 0x715df8: cmp             w0, NULL
    // 0x715dfc: b.ne            #0x715e08
    // 0x715e00: r0 = Null
    //     0x715e00: mov             x0, NULL
    // 0x715e04: b               #0x715e20
    // 0x715e08: ldr             x16, [fp, #0x18]
    // 0x715e0c: stp             x16, x0, [SP, #-0x10]!
    // 0x715e10: ClosureCall
    //     0x715e10: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x715e14: ldur            x2, [x0, #0x1f]
    //     0x715e18: blr             x2
    // 0x715e1c: add             SP, SP, #0x10
    // 0x715e20: LeaveFrame
    //     0x715e20: mov             SP, fp
    //     0x715e24: ldp             fp, lr, [SP], #0x10
    // 0x715e28: ret
    //     0x715e28: ret             
    // 0x715e2c: ldr             x3, [fp, #0x20]
    // 0x715e30: ldr             x0, [fp, #0x18]
    // 0x715e34: r2 = Null
    //     0x715e34: mov             x2, NULL
    // 0x715e38: r1 = Null
    //     0x715e38: mov             x1, NULL
    // 0x715e3c: cmp             w0, NULL
    // 0x715e40: b.eq            #0x715e60
    // 0x715e44: branchIfSmi(r0, 0x715e60)
    //     0x715e44: tbz             w0, #0, #0x715e60
    // 0x715e48: r3 = LoadClassIdInstr(r0)
    //     0x715e48: ldur            x3, [x0, #-1]
    //     0x715e4c: ubfx            x3, x3, #0xc, #0x14
    // 0x715e50: cmp             x3, #0x8fc
    // 0x715e54: b.eq            #0x715e68
    // 0x715e58: cmp             x3, #0xb39
    // 0x715e5c: b.eq            #0x715e68
    // 0x715e60: r0 = false
    //     0x715e60: add             x0, NULL, #0x30  ; false
    // 0x715e64: b               #0x715e6c
    // 0x715e68: r0 = true
    //     0x715e68: add             x0, NULL, #0x20  ; true
    // 0x715e6c: tbnz            w0, #4, #0x715e80
    // 0x715e70: r0 = Null
    //     0x715e70: mov             x0, NULL
    // 0x715e74: LeaveFrame
    //     0x715e74: mov             SP, fp
    //     0x715e78: ldp             fp, lr, [SP], #0x10
    // 0x715e7c: ret
    //     0x715e7c: ret             
    // 0x715e80: ldr             x0, [fp, #0x18]
    // 0x715e84: r2 = Null
    //     0x715e84: mov             x2, NULL
    // 0x715e88: r1 = Null
    //     0x715e88: mov             x1, NULL
    // 0x715e8c: cmp             w0, NULL
    // 0x715e90: b.eq            #0x715eb0
    // 0x715e94: branchIfSmi(r0, 0x715eb0)
    //     0x715e94: tbz             w0, #0, #0x715eb0
    // 0x715e98: r3 = LoadClassIdInstr(r0)
    //     0x715e98: ldur            x3, [x0, #-1]
    //     0x715e9c: ubfx            x3, x3, #0xc, #0x14
    // 0x715ea0: cmp             x3, #0x8fa
    // 0x715ea4: b.eq            #0x715eb8
    // 0x715ea8: cmp             x3, #0xb37
    // 0x715eac: b.eq            #0x715eb8
    // 0x715eb0: r0 = false
    //     0x715eb0: add             x0, NULL, #0x30  ; false
    // 0x715eb4: b               #0x715ebc
    // 0x715eb8: r0 = true
    //     0x715eb8: add             x0, NULL, #0x20  ; true
    // 0x715ebc: tbnz            w0, #4, #0x715ed0
    // 0x715ec0: r0 = Null
    //     0x715ec0: mov             x0, NULL
    // 0x715ec4: LeaveFrame
    //     0x715ec4: mov             SP, fp
    //     0x715ec8: ldp             fp, lr, [SP], #0x10
    // 0x715ecc: ret
    //     0x715ecc: ret             
    // 0x715ed0: ldr             x0, [fp, #0x18]
    // 0x715ed4: r2 = Null
    //     0x715ed4: mov             x2, NULL
    // 0x715ed8: r1 = Null
    //     0x715ed8: mov             x1, NULL
    // 0x715edc: cmp             w0, NULL
    // 0x715ee0: b.eq            #0x715f08
    // 0x715ee4: branchIfSmi(r0, 0x715f08)
    //     0x715ee4: tbz             w0, #0, #0x715f08
    // 0x715ee8: r3 = LoadClassIdInstr(r0)
    //     0x715ee8: ldur            x3, [x0, #-1]
    //     0x715eec: ubfx            x3, x3, #0xc, #0x14
    // 0x715ef0: sub             x3, x3, #0x900
    // 0x715ef4: cmp             x3, #4
    // 0x715ef8: b.ls            #0x715f10
    // 0x715efc: sub             x3, x3, #0x227
    // 0x715f00: cmp             x3, #4
    // 0x715f04: b.ls            #0x715f10
    // 0x715f08: r0 = false
    //     0x715f08: add             x0, NULL, #0x30  ; false
    // 0x715f0c: b               #0x715f14
    // 0x715f10: r0 = true
    //     0x715f10: add             x0, NULL, #0x20  ; true
    // 0x715f14: tbnz            w0, #4, #0x715f5c
    // 0x715f18: ldr             x0, [fp, #0x20]
    // 0x715f1c: LoadField: r1 = r0->field_87
    //     0x715f1c: ldur            w1, [x0, #0x87]
    // 0x715f20: DecompressPointer r1
    //     0x715f20: add             x1, x1, HEAP, lsl #32
    // 0x715f24: cmp             w1, NULL
    // 0x715f28: b.ne            #0x715f34
    // 0x715f2c: r0 = Null
    //     0x715f2c: mov             x0, NULL
    // 0x715f30: b               #0x715f50
    // 0x715f34: ldr             x16, [fp, #0x18]
    // 0x715f38: stp             x16, x1, [SP, #-0x10]!
    // 0x715f3c: mov             x0, x1
    // 0x715f40: ClosureCall
    //     0x715f40: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x715f44: ldur            x2, [x0, #0x1f]
    //     0x715f48: blr             x2
    // 0x715f4c: add             SP, SP, #0x10
    // 0x715f50: LeaveFrame
    //     0x715f50: mov             SP, fp
    //     0x715f54: ldp             fp, lr, [SP], #0x10
    // 0x715f58: ret
    //     0x715f58: ret             
    // 0x715f5c: r0 = Null
    //     0x715f5c: mov             x0, NULL
    // 0x715f60: LeaveFrame
    //     0x715f60: mov             SP, fp
    //     0x715f64: ldp             fp, lr, [SP], #0x10
    // 0x715f68: ret
    //     0x715f68: ret             
    // 0x715f6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x715f6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x715f70: b               #0x715b30
  }
}

// class id: 2524, size: 0x68, field offset: 0x64
class RenderConstrainedBox extends RenderProxyBox {

  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x62e76c, size: 0x18
    // 0x62e76c: r4 = 0
    //     0x62e76c: mov             x4, #0
    // 0x62e770: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x62e770: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b260] AnonymousClosure: (0x62e784), in [package:flutter/src/rendering/proxy_box.dart] RenderConstrainedBox::computeMaxIntrinsicHeight (0x62e7d0)
    //     0x62e774: ldr             x1, [x17, #0x260]
    // 0x62e778: r24 = BuildNonGenericMethodExtractorStub
    //     0x62e778: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x62e77c: LoadField: r0 = r24->field_17
    //     0x62e77c: ldur            x0, [x24, #0x17]
    // 0x62e780: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x62e784, size: 0x4c
    // 0x62e784: EnterFrame
    //     0x62e784: stp             fp, lr, [SP, #-0x10]!
    //     0x62e788: mov             fp, SP
    // 0x62e78c: ldr             x0, [fp, #0x18]
    // 0x62e790: LoadField: r1 = r0->field_17
    //     0x62e790: ldur            w1, [x0, #0x17]
    // 0x62e794: DecompressPointer r1
    //     0x62e794: add             x1, x1, HEAP, lsl #32
    // 0x62e798: CheckStackOverflow
    //     0x62e798: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62e79c: cmp             SP, x16
    //     0x62e7a0: b.ls            #0x62e7c8
    // 0x62e7a4: LoadField: r0 = r1->field_f
    //     0x62e7a4: ldur            w0, [x1, #0xf]
    // 0x62e7a8: DecompressPointer r0
    //     0x62e7a8: add             x0, x0, HEAP, lsl #32
    // 0x62e7ac: ldr             x16, [fp, #0x10]
    // 0x62e7b0: stp             x16, x0, [SP, #-0x10]!
    // 0x62e7b4: r0 = computeMaxIntrinsicHeight()
    //     0x62e7b4: bl              #0x62e7d0  ; [package:flutter/src/rendering/proxy_box.dart] RenderConstrainedBox::computeMaxIntrinsicHeight
    // 0x62e7b8: add             SP, SP, #0x10
    // 0x62e7bc: LeaveFrame
    //     0x62e7bc: mov             SP, fp
    //     0x62e7c0: ldp             fp, lr, [SP], #0x10
    // 0x62e7c4: ret
    //     0x62e7c4: ret             
    // 0x62e7c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62e7c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62e7cc: b               #0x62e7a4
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0x62e7d0, size: 0x138
    // 0x62e7d0: EnterFrame
    //     0x62e7d0: stp             fp, lr, [SP, #-0x10]!
    //     0x62e7d4: mov             fp, SP
    // 0x62e7d8: d0 = inf
    //     0x62e7d8: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62e7dc: CheckStackOverflow
    //     0x62e7dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62e7e0: cmp             SP, x16
    //     0x62e7e4: b.ls            #0x62e8e0
    // 0x62e7e8: ldr             x0, [fp, #0x18]
    // 0x62e7ec: LoadField: r1 = r0->field_63
    //     0x62e7ec: ldur            w1, [x0, #0x63]
    // 0x62e7f0: DecompressPointer r1
    //     0x62e7f0: add             x1, x1, HEAP, lsl #32
    // 0x62e7f4: LoadField: d1 = r1->field_1f
    //     0x62e7f4: ldur            d1, [x1, #0x1f]
    // 0x62e7f8: fcmp            d1, d0
    // 0x62e7fc: b.vs            #0x62e848
    // 0x62e800: b.ge            #0x62e848
    // 0x62e804: LoadField: d2 = r1->field_17
    //     0x62e804: ldur            d2, [x1, #0x17]
    // 0x62e808: fcmp            d2, d1
    // 0x62e80c: b.vs            #0x62e848
    // 0x62e810: b.lt            #0x62e848
    // 0x62e814: r0 = inline_Allocate_Double()
    //     0x62e814: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62e818: add             x0, x0, #0x10
    //     0x62e81c: cmp             x1, x0
    //     0x62e820: b.ls            #0x62e8e8
    //     0x62e824: str             x0, [THR, #0x60]  ; THR::top
    //     0x62e828: sub             x0, x0, #0xf
    //     0x62e82c: mov             x1, #0xd108
    //     0x62e830: movk            x1, #3, lsl #16
    //     0x62e834: stur            x1, [x0, #-1]
    // 0x62e838: StoreField: r0->field_7 = d2
    //     0x62e838: stur            d2, [x0, #7]
    // 0x62e83c: LeaveFrame
    //     0x62e83c: mov             SP, fp
    //     0x62e840: ldp             fp, lr, [SP], #0x10
    // 0x62e844: ret
    //     0x62e844: ret             
    // 0x62e848: ldr             x16, [fp, #0x10]
    // 0x62e84c: stp             x16, x0, [SP, #-0x10]!
    // 0x62e850: r0 = computeMaxIntrinsicHeight()
    //     0x62e850: bl              #0x62e908  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMaxIntrinsicHeight
    // 0x62e854: add             SP, SP, #0x10
    // 0x62e858: mov             x1, x0
    // 0x62e85c: ldr             x0, [fp, #0x18]
    // 0x62e860: LoadField: r2 = r0->field_63
    //     0x62e860: ldur            w2, [x0, #0x63]
    // 0x62e864: DecompressPointer r2
    //     0x62e864: add             x2, x2, HEAP, lsl #32
    // 0x62e868: LoadField: d0 = r2->field_17
    //     0x62e868: ldur            d0, [x2, #0x17]
    // 0x62e86c: d1 = inf
    //     0x62e86c: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62e870: fcmp            d0, d1
    // 0x62e874: b.vs            #0x62e87c
    // 0x62e878: b.ge            #0x62e884
    // 0x62e87c: r0 = false
    //     0x62e87c: add             x0, NULL, #0x30  ; false
    // 0x62e880: b               #0x62e888
    // 0x62e884: r0 = true
    //     0x62e884: add             x0, NULL, #0x20  ; true
    // 0x62e888: tbz             w0, #4, #0x62e8d0
    // 0x62e88c: stp             x1, x2, [SP, #-0x10]!
    // 0x62e890: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x62e890: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x62e894: r0 = constrainHeight()
    //     0x62e894: bl              #0x62bc00  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0x62e898: add             SP, SP, #0x10
    // 0x62e89c: r0 = inline_Allocate_Double()
    //     0x62e89c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x62e8a0: add             x0, x0, #0x10
    //     0x62e8a4: cmp             x2, x0
    //     0x62e8a8: b.ls            #0x62e8f8
    //     0x62e8ac: str             x0, [THR, #0x60]  ; THR::top
    //     0x62e8b0: sub             x0, x0, #0xf
    //     0x62e8b4: mov             x2, #0xd108
    //     0x62e8b8: movk            x2, #3, lsl #16
    //     0x62e8bc: stur            x2, [x0, #-1]
    // 0x62e8c0: StoreField: r0->field_7 = d0
    //     0x62e8c0: stur            d0, [x0, #7]
    // 0x62e8c4: LeaveFrame
    //     0x62e8c4: mov             SP, fp
    //     0x62e8c8: ldp             fp, lr, [SP], #0x10
    // 0x62e8cc: ret
    //     0x62e8cc: ret             
    // 0x62e8d0: mov             x0, x1
    // 0x62e8d4: LeaveFrame
    //     0x62e8d4: mov             SP, fp
    //     0x62e8d8: ldp             fp, lr, [SP], #0x10
    // 0x62e8dc: ret
    //     0x62e8dc: ret             
    // 0x62e8e0: r0 = StackOverflowSharedWithFPURegs()
    //     0x62e8e0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x62e8e4: b               #0x62e7e8
    // 0x62e8e8: SaveReg d2
    //     0x62e8e8: str             q2, [SP, #-0x10]!
    // 0x62e8ec: r0 = AllocateDouble()
    //     0x62e8ec: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62e8f0: RestoreReg d2
    //     0x62e8f0: ldr             q2, [SP], #0x10
    // 0x62e8f4: b               #0x62e838
    // 0x62e8f8: SaveReg d0
    //     0x62e8f8: str             q0, [SP, #-0x10]!
    // 0x62e8fc: r0 = AllocateDouble()
    //     0x62e8fc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62e900: RestoreReg d0
    //     0x62e900: ldr             q0, [SP], #0x10
    // 0x62e904: b               #0x62e8c0
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x6353a8, size: 0x18
    // 0x6353a8: r4 = 0
    //     0x6353a8: mov             x4, #0
    // 0x6353ac: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x6353ac: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fc08] AnonymousClosure: (0x6353c0), in [package:flutter/src/rendering/proxy_box.dart] RenderConstrainedBox::computeMaxIntrinsicWidth (0x63540c)
    //     0x6353b0: ldr             x1, [x17, #0xc08]
    // 0x6353b4: r24 = BuildNonGenericMethodExtractorStub
    //     0x6353b4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x6353b8: LoadField: r0 = r24->field_17
    //     0x6353b8: ldur            x0, [x24, #0x17]
    // 0x6353bc: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x6353c0, size: 0x4c
    // 0x6353c0: EnterFrame
    //     0x6353c0: stp             fp, lr, [SP, #-0x10]!
    //     0x6353c4: mov             fp, SP
    // 0x6353c8: ldr             x0, [fp, #0x18]
    // 0x6353cc: LoadField: r1 = r0->field_17
    //     0x6353cc: ldur            w1, [x0, #0x17]
    // 0x6353d0: DecompressPointer r1
    //     0x6353d0: add             x1, x1, HEAP, lsl #32
    // 0x6353d4: CheckStackOverflow
    //     0x6353d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6353d8: cmp             SP, x16
    //     0x6353dc: b.ls            #0x635404
    // 0x6353e0: LoadField: r0 = r1->field_f
    //     0x6353e0: ldur            w0, [x1, #0xf]
    // 0x6353e4: DecompressPointer r0
    //     0x6353e4: add             x0, x0, HEAP, lsl #32
    // 0x6353e8: ldr             x16, [fp, #0x10]
    // 0x6353ec: stp             x16, x0, [SP, #-0x10]!
    // 0x6353f0: r0 = computeMaxIntrinsicWidth()
    //     0x6353f0: bl              #0x63540c  ; [package:flutter/src/rendering/proxy_box.dart] RenderConstrainedBox::computeMaxIntrinsicWidth
    // 0x6353f4: add             SP, SP, #0x10
    // 0x6353f8: LeaveFrame
    //     0x6353f8: mov             SP, fp
    //     0x6353fc: ldp             fp, lr, [SP], #0x10
    // 0x635400: ret
    //     0x635400: ret             
    // 0x635404: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x635404: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x635408: b               #0x6353e0
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0x63540c, size: 0x138
    // 0x63540c: EnterFrame
    //     0x63540c: stp             fp, lr, [SP, #-0x10]!
    //     0x635410: mov             fp, SP
    // 0x635414: d0 = inf
    //     0x635414: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x635418: CheckStackOverflow
    //     0x635418: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63541c: cmp             SP, x16
    //     0x635420: b.ls            #0x63551c
    // 0x635424: ldr             x0, [fp, #0x18]
    // 0x635428: LoadField: r1 = r0->field_63
    //     0x635428: ldur            w1, [x0, #0x63]
    // 0x63542c: DecompressPointer r1
    //     0x63542c: add             x1, x1, HEAP, lsl #32
    // 0x635430: LoadField: d1 = r1->field_f
    //     0x635430: ldur            d1, [x1, #0xf]
    // 0x635434: fcmp            d1, d0
    // 0x635438: b.vs            #0x635484
    // 0x63543c: b.ge            #0x635484
    // 0x635440: LoadField: d2 = r1->field_7
    //     0x635440: ldur            d2, [x1, #7]
    // 0x635444: fcmp            d2, d1
    // 0x635448: b.vs            #0x635484
    // 0x63544c: b.lt            #0x635484
    // 0x635450: r0 = inline_Allocate_Double()
    //     0x635450: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x635454: add             x0, x0, #0x10
    //     0x635458: cmp             x1, x0
    //     0x63545c: b.ls            #0x635524
    //     0x635460: str             x0, [THR, #0x60]  ; THR::top
    //     0x635464: sub             x0, x0, #0xf
    //     0x635468: mov             x1, #0xd108
    //     0x63546c: movk            x1, #3, lsl #16
    //     0x635470: stur            x1, [x0, #-1]
    // 0x635474: StoreField: r0->field_7 = d2
    //     0x635474: stur            d2, [x0, #7]
    // 0x635478: LeaveFrame
    //     0x635478: mov             SP, fp
    //     0x63547c: ldp             fp, lr, [SP], #0x10
    // 0x635480: ret
    //     0x635480: ret             
    // 0x635484: ldr             x16, [fp, #0x10]
    // 0x635488: stp             x16, x0, [SP, #-0x10]!
    // 0x63548c: r0 = computeMaxIntrinsicWidth()
    //     0x63548c: bl              #0x635544  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMaxIntrinsicWidth
    // 0x635490: add             SP, SP, #0x10
    // 0x635494: mov             x1, x0
    // 0x635498: ldr             x0, [fp, #0x18]
    // 0x63549c: LoadField: r2 = r0->field_63
    //     0x63549c: ldur            w2, [x0, #0x63]
    // 0x6354a0: DecompressPointer r2
    //     0x6354a0: add             x2, x2, HEAP, lsl #32
    // 0x6354a4: LoadField: d0 = r2->field_7
    //     0x6354a4: ldur            d0, [x2, #7]
    // 0x6354a8: d1 = inf
    //     0x6354a8: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x6354ac: fcmp            d0, d1
    // 0x6354b0: b.vs            #0x6354b8
    // 0x6354b4: b.ge            #0x6354c0
    // 0x6354b8: r0 = false
    //     0x6354b8: add             x0, NULL, #0x30  ; false
    // 0x6354bc: b               #0x6354c4
    // 0x6354c0: r0 = true
    //     0x6354c0: add             x0, NULL, #0x20  ; true
    // 0x6354c4: tbz             w0, #4, #0x63550c
    // 0x6354c8: stp             x1, x2, [SP, #-0x10]!
    // 0x6354cc: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x6354cc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x6354d0: r0 = constrainWidth()
    //     0x6354d0: bl              #0x62bc8c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0x6354d4: add             SP, SP, #0x10
    // 0x6354d8: r0 = inline_Allocate_Double()
    //     0x6354d8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x6354dc: add             x0, x0, #0x10
    //     0x6354e0: cmp             x2, x0
    //     0x6354e4: b.ls            #0x635534
    //     0x6354e8: str             x0, [THR, #0x60]  ; THR::top
    //     0x6354ec: sub             x0, x0, #0xf
    //     0x6354f0: mov             x2, #0xd108
    //     0x6354f4: movk            x2, #3, lsl #16
    //     0x6354f8: stur            x2, [x0, #-1]
    // 0x6354fc: StoreField: r0->field_7 = d0
    //     0x6354fc: stur            d0, [x0, #7]
    // 0x635500: LeaveFrame
    //     0x635500: mov             SP, fp
    //     0x635504: ldp             fp, lr, [SP], #0x10
    // 0x635508: ret
    //     0x635508: ret             
    // 0x63550c: mov             x0, x1
    // 0x635510: LeaveFrame
    //     0x635510: mov             SP, fp
    //     0x635514: ldp             fp, lr, [SP], #0x10
    // 0x635518: ret
    //     0x635518: ret             
    // 0x63551c: r0 = StackOverflowSharedWithFPURegs()
    //     0x63551c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x635520: b               #0x635424
    // 0x635524: SaveReg d2
    //     0x635524: str             q2, [SP, #-0x10]!
    // 0x635528: r0 = AllocateDouble()
    //     0x635528: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63552c: RestoreReg d2
    //     0x63552c: ldr             q2, [SP], #0x10
    // 0x635530: b               #0x635474
    // 0x635534: SaveReg d0
    //     0x635534: str             q0, [SP, #-0x10]!
    // 0x635538: r0 = AllocateDouble()
    //     0x635538: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63553c: RestoreReg d0
    //     0x63553c: ldr             q0, [SP], #0x10
    // 0x635540: b               #0x6354fc
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x6384a0, size: 0x18
    // 0x6384a0: r4 = 0
    //     0x6384a0: mov             x4, #0
    // 0x6384a4: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x6384a4: add             x17, PP, #0x52, lsl #12  ; [pp+0x52e90] AnonymousClosure: (0x6384b8), in [package:flutter/src/rendering/proxy_box.dart] RenderConstrainedBox::computeMinIntrinsicHeight (0x638504)
    //     0x6384a8: ldr             x1, [x17, #0xe90]
    // 0x6384ac: r24 = BuildNonGenericMethodExtractorStub
    //     0x6384ac: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x6384b0: LoadField: r0 = r24->field_17
    //     0x6384b0: ldur            x0, [x24, #0x17]
    // 0x6384b4: br              x0
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x6384b8, size: 0x4c
    // 0x6384b8: EnterFrame
    //     0x6384b8: stp             fp, lr, [SP, #-0x10]!
    //     0x6384bc: mov             fp, SP
    // 0x6384c0: ldr             x0, [fp, #0x18]
    // 0x6384c4: LoadField: r1 = r0->field_17
    //     0x6384c4: ldur            w1, [x0, #0x17]
    // 0x6384c8: DecompressPointer r1
    //     0x6384c8: add             x1, x1, HEAP, lsl #32
    // 0x6384cc: CheckStackOverflow
    //     0x6384cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6384d0: cmp             SP, x16
    //     0x6384d4: b.ls            #0x6384fc
    // 0x6384d8: LoadField: r0 = r1->field_f
    //     0x6384d8: ldur            w0, [x1, #0xf]
    // 0x6384dc: DecompressPointer r0
    //     0x6384dc: add             x0, x0, HEAP, lsl #32
    // 0x6384e0: ldr             x16, [fp, #0x10]
    // 0x6384e4: stp             x16, x0, [SP, #-0x10]!
    // 0x6384e8: r0 = computeMinIntrinsicHeight()
    //     0x6384e8: bl              #0x638504  ; [package:flutter/src/rendering/proxy_box.dart] RenderConstrainedBox::computeMinIntrinsicHeight
    // 0x6384ec: add             SP, SP, #0x10
    // 0x6384f0: LeaveFrame
    //     0x6384f0: mov             SP, fp
    //     0x6384f4: ldp             fp, lr, [SP], #0x10
    // 0x6384f8: ret
    //     0x6384f8: ret             
    // 0x6384fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6384fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x638500: b               #0x6384d8
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0x638504, size: 0x138
    // 0x638504: EnterFrame
    //     0x638504: stp             fp, lr, [SP, #-0x10]!
    //     0x638508: mov             fp, SP
    // 0x63850c: d0 = inf
    //     0x63850c: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x638510: CheckStackOverflow
    //     0x638510: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x638514: cmp             SP, x16
    //     0x638518: b.ls            #0x638614
    // 0x63851c: ldr             x0, [fp, #0x18]
    // 0x638520: LoadField: r1 = r0->field_63
    //     0x638520: ldur            w1, [x0, #0x63]
    // 0x638524: DecompressPointer r1
    //     0x638524: add             x1, x1, HEAP, lsl #32
    // 0x638528: LoadField: d1 = r1->field_1f
    //     0x638528: ldur            d1, [x1, #0x1f]
    // 0x63852c: fcmp            d1, d0
    // 0x638530: b.vs            #0x63857c
    // 0x638534: b.ge            #0x63857c
    // 0x638538: LoadField: d2 = r1->field_17
    //     0x638538: ldur            d2, [x1, #0x17]
    // 0x63853c: fcmp            d2, d1
    // 0x638540: b.vs            #0x63857c
    // 0x638544: b.lt            #0x63857c
    // 0x638548: r0 = inline_Allocate_Double()
    //     0x638548: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63854c: add             x0, x0, #0x10
    //     0x638550: cmp             x1, x0
    //     0x638554: b.ls            #0x63861c
    //     0x638558: str             x0, [THR, #0x60]  ; THR::top
    //     0x63855c: sub             x0, x0, #0xf
    //     0x638560: mov             x1, #0xd108
    //     0x638564: movk            x1, #3, lsl #16
    //     0x638568: stur            x1, [x0, #-1]
    // 0x63856c: StoreField: r0->field_7 = d2
    //     0x63856c: stur            d2, [x0, #7]
    // 0x638570: LeaveFrame
    //     0x638570: mov             SP, fp
    //     0x638574: ldp             fp, lr, [SP], #0x10
    // 0x638578: ret
    //     0x638578: ret             
    // 0x63857c: ldr             x16, [fp, #0x10]
    // 0x638580: stp             x16, x0, [SP, #-0x10]!
    // 0x638584: r0 = computeMinIntrinsicHeight()
    //     0x638584: bl              #0x63863c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMinIntrinsicHeight
    // 0x638588: add             SP, SP, #0x10
    // 0x63858c: mov             x1, x0
    // 0x638590: ldr             x0, [fp, #0x18]
    // 0x638594: LoadField: r2 = r0->field_63
    //     0x638594: ldur            w2, [x0, #0x63]
    // 0x638598: DecompressPointer r2
    //     0x638598: add             x2, x2, HEAP, lsl #32
    // 0x63859c: LoadField: d0 = r2->field_17
    //     0x63859c: ldur            d0, [x2, #0x17]
    // 0x6385a0: d1 = inf
    //     0x6385a0: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x6385a4: fcmp            d0, d1
    // 0x6385a8: b.vs            #0x6385b0
    // 0x6385ac: b.ge            #0x6385b8
    // 0x6385b0: r0 = false
    //     0x6385b0: add             x0, NULL, #0x30  ; false
    // 0x6385b4: b               #0x6385bc
    // 0x6385b8: r0 = true
    //     0x6385b8: add             x0, NULL, #0x20  ; true
    // 0x6385bc: tbz             w0, #4, #0x638604
    // 0x6385c0: stp             x1, x2, [SP, #-0x10]!
    // 0x6385c4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x6385c4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x6385c8: r0 = constrainHeight()
    //     0x6385c8: bl              #0x62bc00  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0x6385cc: add             SP, SP, #0x10
    // 0x6385d0: r0 = inline_Allocate_Double()
    //     0x6385d0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x6385d4: add             x0, x0, #0x10
    //     0x6385d8: cmp             x2, x0
    //     0x6385dc: b.ls            #0x63862c
    //     0x6385e0: str             x0, [THR, #0x60]  ; THR::top
    //     0x6385e4: sub             x0, x0, #0xf
    //     0x6385e8: mov             x2, #0xd108
    //     0x6385ec: movk            x2, #3, lsl #16
    //     0x6385f0: stur            x2, [x0, #-1]
    // 0x6385f4: StoreField: r0->field_7 = d0
    //     0x6385f4: stur            d0, [x0, #7]
    // 0x6385f8: LeaveFrame
    //     0x6385f8: mov             SP, fp
    //     0x6385fc: ldp             fp, lr, [SP], #0x10
    // 0x638600: ret
    //     0x638600: ret             
    // 0x638604: mov             x0, x1
    // 0x638608: LeaveFrame
    //     0x638608: mov             SP, fp
    //     0x63860c: ldp             fp, lr, [SP], #0x10
    // 0x638610: ret
    //     0x638610: ret             
    // 0x638614: r0 = StackOverflowSharedWithFPURegs()
    //     0x638614: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x638618: b               #0x63851c
    // 0x63861c: SaveReg d2
    //     0x63861c: str             q2, [SP, #-0x10]!
    // 0x638620: r0 = AllocateDouble()
    //     0x638620: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x638624: RestoreReg d2
    //     0x638624: ldr             q2, [SP], #0x10
    // 0x638628: b               #0x63856c
    // 0x63862c: SaveReg d0
    //     0x63862c: str             q0, [SP, #-0x10]!
    // 0x638630: r0 = AllocateDouble()
    //     0x638630: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x638634: RestoreReg d0
    //     0x638634: ldr             q0, [SP], #0x10
    // 0x638638: b               #0x6385f4
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63b1cc, size: 0x18
    // 0x63b1cc: r4 = 0
    //     0x63b1cc: mov             x4, #0
    // 0x63b1d0: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63b1d0: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fd20] AnonymousClosure: (0x63b1e4), in [package:flutter/src/rendering/proxy_box.dart] RenderConstrainedBox::computeMinIntrinsicWidth (0x63b230)
    //     0x63b1d4: ldr             x1, [x17, #0xd20]
    // 0x63b1d8: r24 = BuildNonGenericMethodExtractorStub
    //     0x63b1d8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63b1dc: LoadField: r0 = r24->field_17
    //     0x63b1dc: ldur            x0, [x24, #0x17]
    // 0x63b1e0: br              x0
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63b1e4, size: 0x4c
    // 0x63b1e4: EnterFrame
    //     0x63b1e4: stp             fp, lr, [SP, #-0x10]!
    //     0x63b1e8: mov             fp, SP
    // 0x63b1ec: ldr             x0, [fp, #0x18]
    // 0x63b1f0: LoadField: r1 = r0->field_17
    //     0x63b1f0: ldur            w1, [x0, #0x17]
    // 0x63b1f4: DecompressPointer r1
    //     0x63b1f4: add             x1, x1, HEAP, lsl #32
    // 0x63b1f8: CheckStackOverflow
    //     0x63b1f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63b1fc: cmp             SP, x16
    //     0x63b200: b.ls            #0x63b228
    // 0x63b204: LoadField: r0 = r1->field_f
    //     0x63b204: ldur            w0, [x1, #0xf]
    // 0x63b208: DecompressPointer r0
    //     0x63b208: add             x0, x0, HEAP, lsl #32
    // 0x63b20c: ldr             x16, [fp, #0x10]
    // 0x63b210: stp             x16, x0, [SP, #-0x10]!
    // 0x63b214: r0 = computeMinIntrinsicWidth()
    //     0x63b214: bl              #0x63b230  ; [package:flutter/src/rendering/proxy_box.dart] RenderConstrainedBox::computeMinIntrinsicWidth
    // 0x63b218: add             SP, SP, #0x10
    // 0x63b21c: LeaveFrame
    //     0x63b21c: mov             SP, fp
    //     0x63b220: ldp             fp, lr, [SP], #0x10
    // 0x63b224: ret
    //     0x63b224: ret             
    // 0x63b228: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63b228: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63b22c: b               #0x63b204
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0x63b230, size: 0x138
    // 0x63b230: EnterFrame
    //     0x63b230: stp             fp, lr, [SP, #-0x10]!
    //     0x63b234: mov             fp, SP
    // 0x63b238: d0 = inf
    //     0x63b238: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x63b23c: CheckStackOverflow
    //     0x63b23c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63b240: cmp             SP, x16
    //     0x63b244: b.ls            #0x63b340
    // 0x63b248: ldr             x0, [fp, #0x18]
    // 0x63b24c: LoadField: r1 = r0->field_63
    //     0x63b24c: ldur            w1, [x0, #0x63]
    // 0x63b250: DecompressPointer r1
    //     0x63b250: add             x1, x1, HEAP, lsl #32
    // 0x63b254: LoadField: d1 = r1->field_f
    //     0x63b254: ldur            d1, [x1, #0xf]
    // 0x63b258: fcmp            d1, d0
    // 0x63b25c: b.vs            #0x63b2a8
    // 0x63b260: b.ge            #0x63b2a8
    // 0x63b264: LoadField: d2 = r1->field_7
    //     0x63b264: ldur            d2, [x1, #7]
    // 0x63b268: fcmp            d2, d1
    // 0x63b26c: b.vs            #0x63b2a8
    // 0x63b270: b.lt            #0x63b2a8
    // 0x63b274: r0 = inline_Allocate_Double()
    //     0x63b274: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63b278: add             x0, x0, #0x10
    //     0x63b27c: cmp             x1, x0
    //     0x63b280: b.ls            #0x63b348
    //     0x63b284: str             x0, [THR, #0x60]  ; THR::top
    //     0x63b288: sub             x0, x0, #0xf
    //     0x63b28c: mov             x1, #0xd108
    //     0x63b290: movk            x1, #3, lsl #16
    //     0x63b294: stur            x1, [x0, #-1]
    // 0x63b298: StoreField: r0->field_7 = d2
    //     0x63b298: stur            d2, [x0, #7]
    // 0x63b29c: LeaveFrame
    //     0x63b29c: mov             SP, fp
    //     0x63b2a0: ldp             fp, lr, [SP], #0x10
    // 0x63b2a4: ret
    //     0x63b2a4: ret             
    // 0x63b2a8: ldr             x16, [fp, #0x10]
    // 0x63b2ac: stp             x16, x0, [SP, #-0x10]!
    // 0x63b2b0: r0 = computeMinIntrinsicWidth()
    //     0x63b2b0: bl              #0x63b368  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMinIntrinsicWidth
    // 0x63b2b4: add             SP, SP, #0x10
    // 0x63b2b8: mov             x1, x0
    // 0x63b2bc: ldr             x0, [fp, #0x18]
    // 0x63b2c0: LoadField: r2 = r0->field_63
    //     0x63b2c0: ldur            w2, [x0, #0x63]
    // 0x63b2c4: DecompressPointer r2
    //     0x63b2c4: add             x2, x2, HEAP, lsl #32
    // 0x63b2c8: LoadField: d0 = r2->field_7
    //     0x63b2c8: ldur            d0, [x2, #7]
    // 0x63b2cc: d1 = inf
    //     0x63b2cc: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x63b2d0: fcmp            d0, d1
    // 0x63b2d4: b.vs            #0x63b2dc
    // 0x63b2d8: b.ge            #0x63b2e4
    // 0x63b2dc: r0 = false
    //     0x63b2dc: add             x0, NULL, #0x30  ; false
    // 0x63b2e0: b               #0x63b2e8
    // 0x63b2e4: r0 = true
    //     0x63b2e4: add             x0, NULL, #0x20  ; true
    // 0x63b2e8: tbz             w0, #4, #0x63b330
    // 0x63b2ec: stp             x1, x2, [SP, #-0x10]!
    // 0x63b2f0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x63b2f0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x63b2f4: r0 = constrainWidth()
    //     0x63b2f4: bl              #0x62bc8c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0x63b2f8: add             SP, SP, #0x10
    // 0x63b2fc: r0 = inline_Allocate_Double()
    //     0x63b2fc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x63b300: add             x0, x0, #0x10
    //     0x63b304: cmp             x2, x0
    //     0x63b308: b.ls            #0x63b358
    //     0x63b30c: str             x0, [THR, #0x60]  ; THR::top
    //     0x63b310: sub             x0, x0, #0xf
    //     0x63b314: mov             x2, #0xd108
    //     0x63b318: movk            x2, #3, lsl #16
    //     0x63b31c: stur            x2, [x0, #-1]
    // 0x63b320: StoreField: r0->field_7 = d0
    //     0x63b320: stur            d0, [x0, #7]
    // 0x63b324: LeaveFrame
    //     0x63b324: mov             SP, fp
    //     0x63b328: ldp             fp, lr, [SP], #0x10
    // 0x63b32c: ret
    //     0x63b32c: ret             
    // 0x63b330: mov             x0, x1
    // 0x63b334: LeaveFrame
    //     0x63b334: mov             SP, fp
    //     0x63b338: ldp             fp, lr, [SP], #0x10
    // 0x63b33c: ret
    //     0x63b33c: ret             
    // 0x63b340: r0 = StackOverflowSharedWithFPURegs()
    //     0x63b340: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x63b344: b               #0x63b248
    // 0x63b348: SaveReg d2
    //     0x63b348: str             q2, [SP, #-0x10]!
    // 0x63b34c: r0 = AllocateDouble()
    //     0x63b34c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63b350: RestoreReg d2
    //     0x63b350: ldr             q2, [SP], #0x10
    // 0x63b354: b               #0x63b298
    // 0x63b358: SaveReg d0
    //     0x63b358: str             q0, [SP, #-0x10]!
    // 0x63b35c: r0 = AllocateDouble()
    //     0x63b35c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63b360: RestoreReg d0
    //     0x63b360: ldr             q0, [SP], #0x10
    // 0x63b364: b               #0x63b320
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x68eb08, size: 0x1a4
    // 0x68eb08: EnterFrame
    //     0x68eb08: stp             fp, lr, [SP, #-0x10]!
    //     0x68eb0c: mov             fp, SP
    // 0x68eb10: AllocStack(0x10)
    //     0x68eb10: sub             SP, SP, #0x10
    // 0x68eb14: CheckStackOverflow
    //     0x68eb14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68eb18: cmp             SP, x16
    //     0x68eb1c: b.ls            #0x68ec9c
    // 0x68eb20: ldr             x3, [fp, #0x10]
    // 0x68eb24: LoadField: r4 = r3->field_27
    //     0x68eb24: ldur            w4, [x3, #0x27]
    // 0x68eb28: DecompressPointer r4
    //     0x68eb28: add             x4, x4, HEAP, lsl #32
    // 0x68eb2c: stur            x4, [fp, #-8]
    // 0x68eb30: cmp             w4, NULL
    // 0x68eb34: b.eq            #0x68ec7c
    // 0x68eb38: mov             x0, x4
    // 0x68eb3c: r2 = Null
    //     0x68eb3c: mov             x2, NULL
    // 0x68eb40: r1 = Null
    //     0x68eb40: mov             x1, NULL
    // 0x68eb44: r4 = LoadClassIdInstr(r0)
    //     0x68eb44: ldur            x4, [x0, #-1]
    //     0x68eb48: ubfx            x4, x4, #0xc, #0x14
    // 0x68eb4c: sub             x4, x4, #0x80d
    // 0x68eb50: cmp             x4, #1
    // 0x68eb54: b.ls            #0x68eb6c
    // 0x68eb58: r8 = BoxConstraints
    //     0x68eb58: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x68eb5c: ldr             x8, [x8, #0x1d0]
    // 0x68eb60: r3 = Null
    //     0x68eb60: add             x3, PP, #0x15, lsl #12  ; [pp+0x15218] Null
    //     0x68eb64: ldr             x3, [x3, #0x218]
    // 0x68eb68: r0 = BoxConstraints()
    //     0x68eb68: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x68eb6c: ldr             x0, [fp, #0x10]
    // 0x68eb70: LoadField: r1 = r0->field_5f
    //     0x68eb70: ldur            w1, [x0, #0x5f]
    // 0x68eb74: DecompressPointer r1
    //     0x68eb74: add             x1, x1, HEAP, lsl #32
    // 0x68eb78: stur            x1, [fp, #-0x10]
    // 0x68eb7c: cmp             w1, NULL
    // 0x68eb80: b.eq            #0x68ec20
    // 0x68eb84: LoadField: r2 = r0->field_63
    //     0x68eb84: ldur            w2, [x0, #0x63]
    // 0x68eb88: DecompressPointer r2
    //     0x68eb88: add             x2, x2, HEAP, lsl #32
    // 0x68eb8c: ldur            x16, [fp, #-8]
    // 0x68eb90: stp             x16, x2, [SP, #-0x10]!
    // 0x68eb94: r0 = enforce()
    //     0x68eb94: bl              #0x62bd90  ; [package:flutter/src/rendering/box.dart] BoxConstraints::enforce
    // 0x68eb98: add             SP, SP, #0x10
    // 0x68eb9c: mov             x1, x0
    // 0x68eba0: ldur            x0, [fp, #-0x10]
    // 0x68eba4: r2 = LoadClassIdInstr(r0)
    //     0x68eba4: ldur            x2, [x0, #-1]
    //     0x68eba8: ubfx            x2, x2, #0xc, #0x14
    // 0x68ebac: stp             x1, x0, [SP, #-0x10]!
    // 0x68ebb0: r16 = true
    //     0x68ebb0: add             x16, NULL, #0x20  ; true
    // 0x68ebb4: SaveReg r16
    //     0x68ebb4: str             x16, [SP, #-8]!
    // 0x68ebb8: mov             x0, x2
    // 0x68ebbc: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x68ebbc: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x68ebc0: ldr             x4, [x4, #0x1c8]
    // 0x68ebc4: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x68ebc4: mov             x17, #0xcdfb
    //     0x68ebc8: add             lr, x0, x17
    //     0x68ebcc: ldr             lr, [x21, lr, lsl #3]
    //     0x68ebd0: blr             lr
    // 0x68ebd4: add             SP, SP, #0x18
    // 0x68ebd8: ldr             x1, [fp, #0x10]
    // 0x68ebdc: LoadField: r0 = r1->field_5f
    //     0x68ebdc: ldur            w0, [x1, #0x5f]
    // 0x68ebe0: DecompressPointer r0
    //     0x68ebe0: add             x0, x0, HEAP, lsl #32
    // 0x68ebe4: cmp             w0, NULL
    // 0x68ebe8: b.eq            #0x68eca4
    // 0x68ebec: LoadField: r2 = r0->field_57
    //     0x68ebec: ldur            w2, [x0, #0x57]
    // 0x68ebf0: DecompressPointer r2
    //     0x68ebf0: add             x2, x2, HEAP, lsl #32
    // 0x68ebf4: cmp             w2, NULL
    // 0x68ebf8: b.eq            #0x68eca8
    // 0x68ebfc: mov             x0, x2
    // 0x68ec00: StoreField: r1->field_57 = r0
    //     0x68ec00: stur            w0, [x1, #0x57]
    //     0x68ec04: ldurb           w16, [x1, #-1]
    //     0x68ec08: ldurb           w17, [x0, #-1]
    //     0x68ec0c: and             x16, x17, x16, lsr #2
    //     0x68ec10: tst             x16, HEAP, lsr #32
    //     0x68ec14: b.eq            #0x68ec1c
    //     0x68ec18: bl              #0xd6826c
    // 0x68ec1c: b               #0x68ec6c
    // 0x68ec20: mov             x1, x0
    // 0x68ec24: LoadField: r0 = r1->field_63
    //     0x68ec24: ldur            w0, [x1, #0x63]
    // 0x68ec28: DecompressPointer r0
    //     0x68ec28: add             x0, x0, HEAP, lsl #32
    // 0x68ec2c: ldur            x16, [fp, #-8]
    // 0x68ec30: stp             x16, x0, [SP, #-0x10]!
    // 0x68ec34: r0 = enforce()
    //     0x68ec34: bl              #0x62bd90  ; [package:flutter/src/rendering/box.dart] BoxConstraints::enforce
    // 0x68ec38: add             SP, SP, #0x10
    // 0x68ec3c: r16 = Instance_Size
    //     0x68ec3c: ldr             x16, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0x68ec40: stp             x16, x0, [SP, #-0x10]!
    // 0x68ec44: r0 = constrain()
    //     0x68ec44: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x68ec48: add             SP, SP, #0x10
    // 0x68ec4c: ldr             x1, [fp, #0x10]
    // 0x68ec50: StoreField: r1->field_57 = r0
    //     0x68ec50: stur            w0, [x1, #0x57]
    //     0x68ec54: ldurb           w16, [x1, #-1]
    //     0x68ec58: ldurb           w17, [x0, #-1]
    //     0x68ec5c: and             x16, x17, x16, lsr #2
    //     0x68ec60: tst             x16, HEAP, lsr #32
    //     0x68ec64: b.eq            #0x68ec6c
    //     0x68ec68: bl              #0xd6826c
    // 0x68ec6c: r0 = Null
    //     0x68ec6c: mov             x0, NULL
    // 0x68ec70: LeaveFrame
    //     0x68ec70: mov             SP, fp
    //     0x68ec74: ldp             fp, lr, [SP], #0x10
    // 0x68ec78: ret
    //     0x68ec78: ret             
    // 0x68ec7c: r0 = StateError()
    //     0x68ec7c: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68ec80: mov             x1, x0
    // 0x68ec84: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68ec84: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68ec88: ldr             x0, [x0, #0x1e8]
    // 0x68ec8c: StoreField: r1->field_b = r0
    //     0x68ec8c: stur            w0, [x1, #0xb]
    // 0x68ec90: mov             x0, x1
    // 0x68ec94: r0 = Throw()
    //     0x68ec94: bl              #0xd67e38  ; ThrowStub
    // 0x68ec98: brk             #0
    // 0x68ec9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68ec9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68eca0: b               #0x68eb20
    // 0x68eca4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68eca4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68eca8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68eca8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ additionalConstraints=(/* No info */) {
    // ** addr: 0x6c5970, size: 0x138
    // 0x6c5970: EnterFrame
    //     0x6c5970: stp             fp, lr, [SP, #-0x10]!
    //     0x6c5974: mov             fp, SP
    // 0x6c5978: AllocStack(0x8)
    //     0x6c5978: sub             SP, SP, #8
    // 0x6c597c: CheckStackOverflow
    //     0x6c597c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c5980: cmp             SP, x16
    //     0x6c5984: b.ls            #0x6c5aa0
    // 0x6c5988: ldr             x0, [fp, #0x18]
    // 0x6c598c: LoadField: r1 = r0->field_63
    //     0x6c598c: ldur            w1, [x0, #0x63]
    // 0x6c5990: DecompressPointer r1
    //     0x6c5990: add             x1, x1, HEAP, lsl #32
    // 0x6c5994: stur            x1, [fp, #-8]
    // 0x6c5998: r2 = LoadClassIdInstr(r1)
    //     0x6c5998: ldur            x2, [x1, #-1]
    //     0x6c599c: ubfx            x2, x2, #0xc, #0x14
    // 0x6c59a0: lsl             x2, x2, #1
    // 0x6c59a4: r17 = 4124
    //     0x6c59a4: mov             x17, #0x101c
    // 0x6c59a8: cmp             w2, w17
    // 0x6c59ac: b.ne            #0x6c5a24
    // 0x6c59b0: ldr             x16, [fp, #0x10]
    // 0x6c59b4: stp             x16, x1, [SP, #-0x10]!
    // 0x6c59b8: r0 = ==()
    //     0x6c59b8: bl              #0xc9e8ac  ; [package:flutter/src/rendering/box.dart] BoxConstraints::==
    // 0x6c59bc: add             SP, SP, #0x10
    // 0x6c59c0: tbnz            w0, #4, #0x6c5a60
    // 0x6c59c4: ldr             x1, [fp, #0x10]
    // 0x6c59c8: r0 = LoadClassIdInstr(r1)
    //     0x6c59c8: ldur            x0, [x1, #-1]
    //     0x6c59cc: ubfx            x0, x0, #0xc, #0x14
    // 0x6c59d0: lsl             x0, x0, #1
    // 0x6c59d4: r17 = 4124
    //     0x6c59d4: mov             x17, #0x101c
    // 0x6c59d8: cmp             w0, w17
    // 0x6c59dc: b.ne            #0x6c5a60
    // 0x6c59e0: ldur            x0, [fp, #-8]
    // 0x6c59e4: LoadField: d0 = r1->field_37
    //     0x6c59e4: ldur            d0, [x1, #0x37]
    // 0x6c59e8: LoadField: d1 = r0->field_37
    //     0x6c59e8: ldur            d1, [x0, #0x37]
    // 0x6c59ec: fcmp            d0, d1
    // 0x6c59f0: b.vs            #0x6c5a60
    // 0x6c59f4: b.ne            #0x6c5a60
    // 0x6c59f8: LoadField: d0 = r1->field_27
    //     0x6c59f8: ldur            d0, [x1, #0x27]
    // 0x6c59fc: LoadField: d1 = r0->field_27
    //     0x6c59fc: ldur            d1, [x0, #0x27]
    // 0x6c5a00: fcmp            d0, d1
    // 0x6c5a04: b.vs            #0x6c5a60
    // 0x6c5a08: b.ne            #0x6c5a60
    // 0x6c5a0c: LoadField: d0 = r1->field_2f
    //     0x6c5a0c: ldur            d0, [x1, #0x2f]
    // 0x6c5a10: LoadField: d1 = r0->field_2f
    //     0x6c5a10: ldur            d1, [x0, #0x2f]
    // 0x6c5a14: fcmp            d0, d1
    // 0x6c5a18: b.vs            #0x6c5a60
    // 0x6c5a1c: b.ne            #0x6c5a60
    // 0x6c5a20: b               #0x6c5a50
    // 0x6c5a24: mov             x0, x1
    // 0x6c5a28: ldr             x1, [fp, #0x10]
    // 0x6c5a2c: r2 = LoadClassIdInstr(r0)
    //     0x6c5a2c: ldur            x2, [x0, #-1]
    //     0x6c5a30: ubfx            x2, x2, #0xc, #0x14
    // 0x6c5a34: stp             x1, x0, [SP, #-0x10]!
    // 0x6c5a38: mov             x0, x2
    // 0x6c5a3c: mov             lr, x0
    // 0x6c5a40: ldr             lr, [x21, lr, lsl #3]
    // 0x6c5a44: blr             lr
    // 0x6c5a48: add             SP, SP, #0x10
    // 0x6c5a4c: tbnz            w0, #4, #0x6c5a60
    // 0x6c5a50: r0 = Null
    //     0x6c5a50: mov             x0, NULL
    // 0x6c5a54: LeaveFrame
    //     0x6c5a54: mov             SP, fp
    //     0x6c5a58: ldp             fp, lr, [SP], #0x10
    // 0x6c5a5c: ret
    //     0x6c5a5c: ret             
    // 0x6c5a60: ldr             x1, [fp, #0x18]
    // 0x6c5a64: ldr             x0, [fp, #0x10]
    // 0x6c5a68: StoreField: r1->field_63 = r0
    //     0x6c5a68: stur            w0, [x1, #0x63]
    //     0x6c5a6c: ldurb           w16, [x1, #-1]
    //     0x6c5a70: ldurb           w17, [x0, #-1]
    //     0x6c5a74: and             x16, x17, x16, lsr #2
    //     0x6c5a78: tst             x16, HEAP, lsr #32
    //     0x6c5a7c: b.eq            #0x6c5a84
    //     0x6c5a80: bl              #0xd6826c
    // 0x6c5a84: SaveReg r1
    //     0x6c5a84: str             x1, [SP, #-8]!
    // 0x6c5a88: r0 = markNeedsLayout()
    //     0x6c5a88: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c5a8c: add             SP, SP, #8
    // 0x6c5a90: r0 = Null
    //     0x6c5a90: mov             x0, NULL
    // 0x6c5a94: LeaveFrame
    //     0x6c5a94: mov             SP, fp
    //     0x6c5a98: ldp             fp, lr, [SP], #0x10
    // 0x6c5a9c: ret
    //     0x6c5a9c: ret             
    // 0x6c5aa0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c5aa0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c5aa4: b               #0x6c5988
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5d644, size: 0xa0
    // 0xa5d644: EnterFrame
    //     0xa5d644: stp             fp, lr, [SP, #-0x10]!
    //     0xa5d648: mov             fp, SP
    // 0xa5d64c: AllocStack(0x8)
    //     0xa5d64c: sub             SP, SP, #8
    // 0xa5d650: CheckStackOverflow
    //     0xa5d650: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5d654: cmp             SP, x16
    //     0xa5d658: b.ls            #0xa5d6dc
    // 0xa5d65c: ldr             x0, [fp, #0x18]
    // 0xa5d660: LoadField: r1 = r0->field_5f
    //     0xa5d660: ldur            w1, [x0, #0x5f]
    // 0xa5d664: DecompressPointer r1
    //     0xa5d664: add             x1, x1, HEAP, lsl #32
    // 0xa5d668: stur            x1, [fp, #-8]
    // 0xa5d66c: cmp             w1, NULL
    // 0xa5d670: b.eq            #0xa5d6a8
    // 0xa5d674: LoadField: r2 = r0->field_63
    //     0xa5d674: ldur            w2, [x0, #0x63]
    // 0xa5d678: DecompressPointer r2
    //     0xa5d678: add             x2, x2, HEAP, lsl #32
    // 0xa5d67c: ldr             x16, [fp, #0x10]
    // 0xa5d680: stp             x16, x2, [SP, #-0x10]!
    // 0xa5d684: r0 = enforce()
    //     0xa5d684: bl              #0x62bd90  ; [package:flutter/src/rendering/box.dart] BoxConstraints::enforce
    // 0xa5d688: add             SP, SP, #0x10
    // 0xa5d68c: ldur            x16, [fp, #-8]
    // 0xa5d690: stp             x0, x16, [SP, #-0x10]!
    // 0xa5d694: r0 = getDryLayout()
    //     0xa5d694: bl              #0x62d394  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xa5d698: add             SP, SP, #0x10
    // 0xa5d69c: LeaveFrame
    //     0xa5d69c: mov             SP, fp
    //     0xa5d6a0: ldp             fp, lr, [SP], #0x10
    // 0xa5d6a4: ret
    //     0xa5d6a4: ret             
    // 0xa5d6a8: LoadField: r1 = r0->field_63
    //     0xa5d6a8: ldur            w1, [x0, #0x63]
    // 0xa5d6ac: DecompressPointer r1
    //     0xa5d6ac: add             x1, x1, HEAP, lsl #32
    // 0xa5d6b0: ldr             x16, [fp, #0x10]
    // 0xa5d6b4: stp             x16, x1, [SP, #-0x10]!
    // 0xa5d6b8: r0 = enforce()
    //     0xa5d6b8: bl              #0x62bd90  ; [package:flutter/src/rendering/box.dart] BoxConstraints::enforce
    // 0xa5d6bc: add             SP, SP, #0x10
    // 0xa5d6c0: r16 = Instance_Size
    //     0xa5d6c0: ldr             x16, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0xa5d6c4: stp             x16, x0, [SP, #-0x10]!
    // 0xa5d6c8: r0 = constrain()
    //     0xa5d6c8: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xa5d6cc: add             SP, SP, #0x10
    // 0xa5d6d0: LeaveFrame
    //     0xa5d6d0: mov             SP, fp
    //     0xa5d6d4: ldp             fp, lr, [SP], #0x10
    // 0xa5d6d8: ret
    //     0xa5d6d8: ret             
    // 0xa5d6dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5d6dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5d6e0: b               #0xa5d65c
  }
}

// class id: 2547, size: 0x54, field offset: 0x54
abstract class RenderAnimatedOpacityMixin<X0 bound RenderObject> extends RenderObjectWithChildMixin<X0 bound RenderObject> {
}

// class id: 4318, size: 0x10, field offset: 0x8
//   const constructor, 
abstract class CustomClipper<X0> extends Listenable {

  _ toString(/* No info */) {
    // ** addr: 0xad4d48, size: 0xc
    // 0xad4d48: r0 = "CustomClipper"
    //     0xad4d48: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1ced8] "CustomClipper"
    //     0xad4d4c: ldr             x0, [x0, #0xed8]
    // 0xad4d50: ret
    //     0xad4d50: ret             
  }
}

// class id: 4324, size: 0x18, field offset: 0x10
//   const constructor, 
class ShapeBorderClipper extends CustomClipper<Path> {

  _ shouldReclip(/* No info */) {
    // ** addr: 0xc09a10, size: 0x140
    // 0xc09a10: EnterFrame
    //     0xc09a10: stp             fp, lr, [SP, #-0x10]!
    //     0xc09a14: mov             fp, SP
    // 0xc09a18: CheckStackOverflow
    //     0xc09a18: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc09a1c: cmp             SP, x16
    //     0xc09a20: b.ls            #0xc09b48
    // 0xc09a24: ldr             x0, [fp, #0x10]
    // 0xc09a28: r2 = Null
    //     0xc09a28: mov             x2, NULL
    // 0xc09a2c: r1 = Null
    //     0xc09a2c: mov             x1, NULL
    // 0xc09a30: r8 = CustomClipper<Path>
    //     0xc09a30: add             x8, PP, #0x21, lsl #12  ; [pp+0x21b40] Type: CustomClipper<Path>
    //     0xc09a34: ldr             x8, [x8, #0xb40]
    // 0xc09a38: r3 = Null
    //     0xc09a38: add             x3, PP, #0x21, lsl #12  ; [pp+0x21b48] Null
    //     0xc09a3c: ldr             x3, [x3, #0xb48]
    // 0xc09a40: r0 = CustomClipper<Path>()
    //     0xc09a40: bl              #0x8603e0  ; IsType_CustomClipper<Path>_Stub
    // 0xc09a44: ldr             x16, [fp, #0x10]
    // 0xc09a48: SaveReg r16
    //     0xc09a48: str             x16, [SP, #-8]!
    // 0xc09a4c: r0 = runtimeType()
    //     0xc09a4c: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc09a50: add             SP, SP, #8
    // 0xc09a54: r1 = LoadClassIdInstr(r0)
    //     0xc09a54: ldur            x1, [x0, #-1]
    //     0xc09a58: ubfx            x1, x1, #0xc, #0x14
    // 0xc09a5c: r16 = ShapeBorderClipper<Path>
    //     0xc09a5c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21b58] Type: ShapeBorderClipper<Path>
    //     0xc09a60: ldr             x16, [x16, #0xb58]
    // 0xc09a64: stp             x16, x0, [SP, #-0x10]!
    // 0xc09a68: mov             x0, x1
    // 0xc09a6c: mov             lr, x0
    // 0xc09a70: ldr             lr, [x21, lr, lsl #3]
    // 0xc09a74: blr             lr
    // 0xc09a78: add             SP, SP, #0x10
    // 0xc09a7c: tbz             w0, #4, #0xc09a90
    // 0xc09a80: r0 = true
    //     0xc09a80: add             x0, NULL, #0x20  ; true
    // 0xc09a84: LeaveFrame
    //     0xc09a84: mov             SP, fp
    //     0xc09a88: ldp             fp, lr, [SP], #0x10
    // 0xc09a8c: ret
    //     0xc09a8c: ret             
    // 0xc09a90: ldr             x4, [fp, #0x18]
    // 0xc09a94: ldr             x3, [fp, #0x10]
    // 0xc09a98: mov             x0, x3
    // 0xc09a9c: r2 = Null
    //     0xc09a9c: mov             x2, NULL
    // 0xc09aa0: r1 = Null
    //     0xc09aa0: mov             x1, NULL
    // 0xc09aa4: r4 = LoadClassIdInstr(r0)
    //     0xc09aa4: ldur            x4, [x0, #-1]
    //     0xc09aa8: ubfx            x4, x4, #0xc, #0x14
    // 0xc09aac: r17 = 4324
    //     0xc09aac: mov             x17, #0x10e4
    // 0xc09ab0: cmp             x4, x17
    // 0xc09ab4: b.eq            #0xc09acc
    // 0xc09ab8: r8 = ShapeBorderClipper<Path>
    //     0xc09ab8: add             x8, PP, #0x21, lsl #12  ; [pp+0x21b58] Type: ShapeBorderClipper<Path>
    //     0xc09abc: ldr             x8, [x8, #0xb58]
    // 0xc09ac0: r3 = Null
    //     0xc09ac0: add             x3, PP, #0x21, lsl #12  ; [pp+0x21b60] Null
    //     0xc09ac4: ldr             x3, [x3, #0xb60]
    // 0xc09ac8: r0 = DefaultTypeTest()
    //     0xc09ac8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xc09acc: ldr             x1, [fp, #0x10]
    // 0xc09ad0: LoadField: r0 = r1->field_f
    //     0xc09ad0: ldur            w0, [x1, #0xf]
    // 0xc09ad4: DecompressPointer r0
    //     0xc09ad4: add             x0, x0, HEAP, lsl #32
    // 0xc09ad8: ldr             x2, [fp, #0x18]
    // 0xc09adc: LoadField: r3 = r2->field_f
    //     0xc09adc: ldur            w3, [x2, #0xf]
    // 0xc09ae0: DecompressPointer r3
    //     0xc09ae0: add             x3, x3, HEAP, lsl #32
    // 0xc09ae4: r4 = LoadClassIdInstr(r0)
    //     0xc09ae4: ldur            x4, [x0, #-1]
    //     0xc09ae8: ubfx            x4, x4, #0xc, #0x14
    // 0xc09aec: stp             x3, x0, [SP, #-0x10]!
    // 0xc09af0: mov             x0, x4
    // 0xc09af4: mov             lr, x0
    // 0xc09af8: ldr             lr, [x21, lr, lsl #3]
    // 0xc09afc: blr             lr
    // 0xc09b00: add             SP, SP, #0x10
    // 0xc09b04: tbz             w0, #4, #0xc09b10
    // 0xc09b08: r0 = true
    //     0xc09b08: add             x0, NULL, #0x20  ; true
    // 0xc09b0c: b               #0xc09b3c
    // 0xc09b10: ldr             x2, [fp, #0x18]
    // 0xc09b14: ldr             x1, [fp, #0x10]
    // 0xc09b18: LoadField: r3 = r1->field_13
    //     0xc09b18: ldur            w3, [x1, #0x13]
    // 0xc09b1c: DecompressPointer r3
    //     0xc09b1c: add             x3, x3, HEAP, lsl #32
    // 0xc09b20: LoadField: r1 = r2->field_13
    //     0xc09b20: ldur            w1, [x2, #0x13]
    // 0xc09b24: DecompressPointer r1
    //     0xc09b24: add             x1, x1, HEAP, lsl #32
    // 0xc09b28: cmp             w3, w1
    // 0xc09b2c: r16 = true
    //     0xc09b2c: add             x16, NULL, #0x20  ; true
    // 0xc09b30: r17 = false
    //     0xc09b30: add             x17, NULL, #0x30  ; false
    // 0xc09b34: csel            x2, x16, x17, ne
    // 0xc09b38: mov             x0, x2
    // 0xc09b3c: LeaveFrame
    //     0xc09b3c: mov             SP, fp
    //     0xc09b40: ldp             fp, lr, [SP], #0x10
    // 0xc09b44: ret
    //     0xc09b44: ret             
    // 0xc09b48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc09b48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc09b4c: b               #0xc09a24
  }
  _ getClip(/* No info */) {
    // ** addr: 0xc0ac34, size: 0x90
    // 0xc0ac34: EnterFrame
    //     0xc0ac34: stp             fp, lr, [SP, #-0x10]!
    //     0xc0ac38: mov             fp, SP
    // 0xc0ac3c: AllocStack(0x8)
    //     0xc0ac3c: sub             SP, SP, #8
    // 0xc0ac40: CheckStackOverflow
    //     0xc0ac40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc0ac44: cmp             SP, x16
    //     0xc0ac48: b.ls            #0xc0acbc
    // 0xc0ac4c: ldr             x0, [fp, #0x18]
    // 0xc0ac50: LoadField: r1 = r0->field_f
    //     0xc0ac50: ldur            w1, [x0, #0xf]
    // 0xc0ac54: DecompressPointer r1
    //     0xc0ac54: add             x1, x1, HEAP, lsl #32
    // 0xc0ac58: stur            x1, [fp, #-8]
    // 0xc0ac5c: r16 = Instance_Offset
    //     0xc0ac5c: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xc0ac60: ldr             lr, [fp, #0x10]
    // 0xc0ac64: stp             lr, x16, [SP, #-0x10]!
    // 0xc0ac68: r0 = &()
    //     0xc0ac68: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0xc0ac6c: add             SP, SP, #0x10
    // 0xc0ac70: mov             x1, x0
    // 0xc0ac74: ldr             x0, [fp, #0x18]
    // 0xc0ac78: LoadField: r2 = r0->field_13
    //     0xc0ac78: ldur            w2, [x0, #0x13]
    // 0xc0ac7c: DecompressPointer r2
    //     0xc0ac7c: add             x2, x2, HEAP, lsl #32
    // 0xc0ac80: ldur            x0, [fp, #-8]
    // 0xc0ac84: r3 = LoadClassIdInstr(r0)
    //     0xc0ac84: ldur            x3, [x0, #-1]
    //     0xc0ac88: ubfx            x3, x3, #0xc, #0x14
    // 0xc0ac8c: stp             x1, x0, [SP, #-0x10]!
    // 0xc0ac90: SaveReg r2
    //     0xc0ac90: str             x2, [SP, #-8]!
    // 0xc0ac94: mov             x0, x3
    // 0xc0ac98: r4 = const [0, 0x3, 0x3, 0x2, textDirection, 0x2, null]
    //     0xc0ac98: add             x4, PP, #0x28, lsl #12  ; [pp+0x285b8] List(7) [0, 0x3, 0x3, 0x2, "textDirection", 0x2, Null]
    //     0xc0ac9c: ldr             x4, [x4, #0x5b8]
    // 0xc0aca0: r0 = GDT[cid_x0 + -0xfde]()
    //     0xc0aca0: sub             lr, x0, #0xfde
    //     0xc0aca4: ldr             lr, [x21, lr, lsl #3]
    //     0xc0aca8: blr             lr
    // 0xc0acac: add             SP, SP, #0x18
    // 0xc0acb0: LeaveFrame
    //     0xc0acb0: mov             SP, fp
    //     0xc0acb4: ldp             fp, lr, [SP], #0x10
    // 0xc0acb8: ret
    //     0xc0acb8: ret             
    // 0xc0acbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0acbc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0acc0: b               #0xc0ac4c
  }
}

// class id: 5918, size: 0x14, field offset: 0x14
enum DecorationPosition extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16e84, size: 0x5c
    // 0xb16e84: EnterFrame
    //     0xb16e84: stp             fp, lr, [SP, #-0x10]!
    //     0xb16e88: mov             fp, SP
    // 0xb16e8c: CheckStackOverflow
    //     0xb16e8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16e90: cmp             SP, x16
    //     0xb16e94: b.ls            #0xb16ed8
    // 0xb16e98: r1 = Null
    //     0xb16e98: mov             x1, NULL
    // 0xb16e9c: r2 = 4
    //     0xb16e9c: mov             x2, #4
    // 0xb16ea0: r0 = AllocateArray()
    //     0xb16ea0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16ea4: r17 = "DecorationPosition."
    //     0xb16ea4: add             x17, PP, #0x15, lsl #12  ; [pp+0x15228] "DecorationPosition."
    //     0xb16ea8: ldr             x17, [x17, #0x228]
    // 0xb16eac: StoreField: r0->field_f = r17
    //     0xb16eac: stur            w17, [x0, #0xf]
    // 0xb16eb0: ldr             x1, [fp, #0x10]
    // 0xb16eb4: LoadField: r2 = r1->field_f
    //     0xb16eb4: ldur            w2, [x1, #0xf]
    // 0xb16eb8: DecompressPointer r2
    //     0xb16eb8: add             x2, x2, HEAP, lsl #32
    // 0xb16ebc: StoreField: r0->field_13 = r2
    //     0xb16ebc: stur            w2, [x0, #0x13]
    // 0xb16ec0: SaveReg r0
    //     0xb16ec0: str             x0, [SP, #-8]!
    // 0xb16ec4: r0 = _interpolate()
    //     0xb16ec4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16ec8: add             SP, SP, #8
    // 0xb16ecc: LeaveFrame
    //     0xb16ecc: mov             SP, fp
    //     0xb16ed0: ldp             fp, lr, [SP], #0x10
    // 0xb16ed4: ret
    //     0xb16ed4: ret             
    // 0xb16ed8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16ed8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16edc: b               #0xb16e98
  }
}

// class id: 5919, size: 0x14, field offset: 0x14
enum HitTestBehavior extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16e28, size: 0x5c
    // 0xb16e28: EnterFrame
    //     0xb16e28: stp             fp, lr, [SP, #-0x10]!
    //     0xb16e2c: mov             fp, SP
    // 0xb16e30: CheckStackOverflow
    //     0xb16e30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16e34: cmp             SP, x16
    //     0xb16e38: b.ls            #0xb16e7c
    // 0xb16e3c: r1 = Null
    //     0xb16e3c: mov             x1, NULL
    // 0xb16e40: r2 = 4
    //     0xb16e40: mov             x2, #4
    // 0xb16e44: r0 = AllocateArray()
    //     0xb16e44: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16e48: r17 = "HitTestBehavior."
    //     0xb16e48: add             x17, PP, #0x1c, lsl #12  ; [pp+0x1cf68] "HitTestBehavior."
    //     0xb16e4c: ldr             x17, [x17, #0xf68]
    // 0xb16e50: StoreField: r0->field_f = r17
    //     0xb16e50: stur            w17, [x0, #0xf]
    // 0xb16e54: ldr             x1, [fp, #0x10]
    // 0xb16e58: LoadField: r2 = r1->field_f
    //     0xb16e58: ldur            w2, [x1, #0xf]
    // 0xb16e5c: DecompressPointer r2
    //     0xb16e5c: add             x2, x2, HEAP, lsl #32
    // 0xb16e60: StoreField: r0->field_13 = r2
    //     0xb16e60: stur            w2, [x0, #0x13]
    // 0xb16e64: SaveReg r0
    //     0xb16e64: str             x0, [SP, #-8]!
    // 0xb16e68: r0 = _interpolate()
    //     0xb16e68: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16e6c: add             SP, SP, #8
    // 0xb16e70: LeaveFrame
    //     0xb16e70: mov             SP, fp
    //     0xb16e74: ldp             fp, lr, [SP], #0x10
    // 0xb16e78: ret
    //     0xb16e78: ret             
    // 0xb16e7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16e7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16e80: b               #0xb16e3c
  }
}

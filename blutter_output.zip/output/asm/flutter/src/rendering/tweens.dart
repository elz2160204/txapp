// lib: , url: package:flutter/src/rendering/tweens.dart

// class id: 1049432, size: 0x8
class :: {
}

// class id: 4265, size: 0x14, field offset: 0x14
class AlignmentGeometryTween extends Tween<AlignmentGeometry?> {

  _ lerp(/* No info */) {
    // ** addr: 0xbf8ba4, size: 0x50
    // 0xbf8ba4: EnterFrame
    //     0xbf8ba4: stp             fp, lr, [SP, #-0x10]!
    //     0xbf8ba8: mov             fp, SP
    // 0xbf8bac: CheckStackOverflow
    //     0xbf8bac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf8bb0: cmp             SP, x16
    //     0xbf8bb4: b.ls            #0xbf8bec
    // 0xbf8bb8: ldr             x0, [fp, #0x18]
    // 0xbf8bbc: LoadField: r1 = r0->field_b
    //     0xbf8bbc: ldur            w1, [x0, #0xb]
    // 0xbf8bc0: DecompressPointer r1
    //     0xbf8bc0: add             x1, x1, HEAP, lsl #32
    // 0xbf8bc4: LoadField: r2 = r0->field_f
    //     0xbf8bc4: ldur            w2, [x0, #0xf]
    // 0xbf8bc8: DecompressPointer r2
    //     0xbf8bc8: add             x2, x2, HEAP, lsl #32
    // 0xbf8bcc: stp             x2, x1, [SP, #-0x10]!
    // 0xbf8bd0: ldr             d0, [fp, #0x10]
    // 0xbf8bd4: SaveReg d0
    //     0xbf8bd4: str             d0, [SP, #-8]!
    // 0xbf8bd8: r0 = lerp()
    //     0xbf8bd8: bl              #0xbefd44  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::lerp
    // 0xbf8bdc: add             SP, SP, #0x18
    // 0xbf8be0: LeaveFrame
    //     0xbf8be0: mov             SP, fp
    //     0xbf8be4: ldp             fp, lr, [SP], #0x10
    // 0xbf8be8: ret
    //     0xbf8be8: ret             
    // 0xbf8bec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf8bec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf8bf0: b               #0xbf8bb8
  }
}

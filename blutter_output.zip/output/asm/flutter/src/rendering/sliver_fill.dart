// lib: , url: package:flutter/src/rendering/sliver_fill.dart

// class id: 1049421, size: 0x8
class :: {
}

// class id: 2573, size: 0x58, field offset: 0x58
class RenderSliverFillRemainingWithScrollable extends RenderSliverSingleBoxAdapter {

  _ performLayout(/* No info */) {
    // ** addr: 0x6856d0, size: 0x338
    // 0x6856d0: EnterFrame
    //     0x6856d0: stp             fp, lr, [SP, #-0x10]!
    //     0x6856d4: mov             fp, SP
    // 0x6856d8: AllocStack(0x30)
    //     0x6856d8: sub             SP, SP, #0x30
    // 0x6856dc: CheckStackOverflow
    //     0x6856dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6856e0: cmp             SP, x16
    //     0x6856e4: b.ls            #0x6859c8
    // 0x6856e8: ldr             x3, [fp, #0x10]
    // 0x6856ec: LoadField: r4 = r3->field_27
    //     0x6856ec: ldur            w4, [x3, #0x27]
    // 0x6856f0: DecompressPointer r4
    //     0x6856f0: add             x4, x4, HEAP, lsl #32
    // 0x6856f4: stur            x4, [fp, #-8]
    // 0x6856f8: cmp             w4, NULL
    // 0x6856fc: b.eq            #0x6859a8
    // 0x685700: mov             x0, x4
    // 0x685704: r2 = Null
    //     0x685704: mov             x2, NULL
    // 0x685708: r1 = Null
    //     0x685708: mov             x1, NULL
    // 0x68570c: r4 = LoadClassIdInstr(r0)
    //     0x68570c: ldur            x4, [x0, #-1]
    //     0x685710: ubfx            x4, x4, #0xc, #0x14
    // 0x685714: cmp             x4, #0x80c
    // 0x685718: b.eq            #0x685730
    // 0x68571c: r8 = SliverConstraints
    //     0x68571c: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x685720: ldr             x8, [x8, #0x5a8]
    // 0x685724: r3 = Null
    //     0x685724: add             x3, PP, #0x40, lsl #12  ; [pp+0x40d50] Null
    //     0x685728: ldr             x3, [x3, #0xd50]
    // 0x68572c: r0 = DefaultTypeTest()
    //     0x68572c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x685730: ldur            x0, [fp, #-8]
    // 0x685734: LoadField: d0 = r0->field_2b
    //     0x685734: ldur            d0, [x0, #0x2b]
    // 0x685738: stur            d0, [fp, #-0x20]
    // 0x68573c: LoadField: d1 = r0->field_23
    //     0x68573c: ldur            d1, [x0, #0x23]
    // 0x685740: stur            d1, [fp, #-0x18]
    // 0x685744: d2 = 0.000000
    //     0x685744: eor             v2.16b, v2.16b, v2.16b
    // 0x685748: fcmp            d1, d2
    // 0x68574c: b.vs            #0x68575c
    // 0x685750: b.le            #0x68575c
    // 0x685754: d1 = 0.000000
    //     0x685754: eor             v1.16b, v1.16b, v1.16b
    // 0x685758: b               #0x6857c0
    // 0x68575c: fcmp            d1, d2
    // 0x685760: b.vs            #0x685768
    // 0x685764: b.lt            #0x6857c0
    // 0x685768: fcmp            d1, d2
    // 0x68576c: b.vs            #0x685774
    // 0x685770: b.eq            #0x68577c
    // 0x685774: r1 = false
    //     0x685774: add             x1, NULL, #0x30  ; false
    // 0x685778: b               #0x685780
    // 0x68577c: r1 = true
    //     0x68577c: add             x1, NULL, #0x20  ; true
    // 0x685780: tbnz            w1, #4, #0x685794
    // 0x685784: fadd            d3, d1, d2
    // 0x685788: fmul            d4, d3, d1
    // 0x68578c: fmul            d1, d4, d2
    // 0x685790: b               #0x6857c0
    // 0x685794: tbnz            w1, #4, #0x6857b8
    // 0x685798: r16 = 0.000000
    //     0x685798: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x68579c: SaveReg r16
    //     0x68579c: str             x16, [SP, #-8]!
    // 0x6857a0: r0 = isNegative()
    //     0x6857a0: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x6857a4: add             SP, SP, #8
    // 0x6857a8: tbnz            w0, #4, #0x6857b8
    // 0x6857ac: ldur            d0, [fp, #-0x20]
    // 0x6857b0: d1 = 0.000000
    //     0x6857b0: eor             v1.16b, v1.16b, v1.16b
    // 0x6857b4: b               #0x6857c0
    // 0x6857b8: ldur            d1, [fp, #-0x18]
    // 0x6857bc: ldur            d0, [fp, #-0x20]
    // 0x6857c0: ldr             x0, [fp, #0x10]
    // 0x6857c4: fsub            d2, d0, d1
    // 0x6857c8: stur            d2, [fp, #-0x18]
    // 0x6857cc: LoadField: r1 = r0->field_53
    //     0x6857cc: ldur            w1, [x0, #0x53]
    // 0x6857d0: DecompressPointer r1
    //     0x6857d0: add             x1, x1, HEAP, lsl #32
    // 0x6857d4: stur            x1, [fp, #-0x10]
    // 0x6857d8: cmp             w1, NULL
    // 0x6857dc: b.eq            #0x685854
    // 0x6857e0: r2 = inline_Allocate_Double()
    //     0x6857e0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x6857e4: add             x2, x2, #0x10
    //     0x6857e8: cmp             x3, x2
    //     0x6857ec: b.ls            #0x6859d0
    //     0x6857f0: str             x2, [THR, #0x60]  ; THR::top
    //     0x6857f4: sub             x2, x2, #0xf
    //     0x6857f8: mov             x3, #0xd108
    //     0x6857fc: movk            x3, #3, lsl #16
    //     0x685800: stur            x3, [x2, #-1]
    // 0x685804: StoreField: r2->field_7 = d2
    //     0x685804: stur            d2, [x2, #7]
    // 0x685808: ldur            x16, [fp, #-8]
    // 0x68580c: stp             x2, x16, [SP, #-0x10]!
    // 0x685810: SaveReg r2
    //     0x685810: str             x2, [SP, #-8]!
    // 0x685814: r4 = const [0, 0x3, 0x3, 0x1, maxExtent, 0x2, minExtent, 0x1, null]
    //     0x685814: add             x4, PP, #0x40, lsl #12  ; [pp+0x40d60] List(9) [0, 0x3, 0x3, 0x1, "maxExtent", 0x2, "minExtent", 0x1, Null]
    //     0x685818: ldr             x4, [x4, #0xd60]
    // 0x68581c: r0 = asBoxConstraints()
    //     0x68581c: bl              #0x67a528  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::asBoxConstraints
    // 0x685820: add             SP, SP, #0x18
    // 0x685824: mov             x1, x0
    // 0x685828: ldur            x0, [fp, #-0x10]
    // 0x68582c: r2 = LoadClassIdInstr(r0)
    //     0x68582c: ldur            x2, [x0, #-1]
    //     0x685830: ubfx            x2, x2, #0xc, #0x14
    // 0x685834: stp             x1, x0, [SP, #-0x10]!
    // 0x685838: mov             x0, x2
    // 0x68583c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x68583c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x685840: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x685840: mov             x17, #0xcdfb
    //     0x685844: add             lr, x0, x17
    //     0x685848: ldr             lr, [x21, lr, lsl #3]
    //     0x68584c: blr             lr
    // 0x685850: add             SP, SP, #0x10
    // 0x685854: ldur            d0, [fp, #-0x20]
    // 0x685858: ldur            d1, [fp, #-0x18]
    // 0x68585c: ldur            x0, [fp, #-8]
    // 0x685860: r1 = inline_Allocate_Double()
    //     0x685860: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x685864: add             x1, x1, #0x10
    //     0x685868: cmp             x2, x1
    //     0x68586c: b.ls            #0x6859ec
    //     0x685870: str             x1, [THR, #0x60]  ; THR::top
    //     0x685874: sub             x1, x1, #0xf
    //     0x685878: mov             x2, #0xd108
    //     0x68587c: movk            x2, #3, lsl #16
    //     0x685880: stur            x2, [x1, #-1]
    // 0x685884: StoreField: r1->field_7 = d1
    //     0x685884: stur            d1, [x1, #7]
    // 0x685888: ldr             x16, [fp, #0x10]
    // 0x68588c: stp             x0, x16, [SP, #-0x10]!
    // 0x685890: stp             x1, xzr, [SP, #-0x10]!
    // 0x685894: r0 = calculatePaintOffset()
    //     0x685894: bl              #0x677ba0  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0x685898: add             SP, SP, #0x20
    // 0x68589c: ldur            x0, [fp, #-8]
    // 0x6858a0: stur            d0, [fp, #-0x30]
    // 0x6858a4: LoadField: d1 = r0->field_3f
    //     0x6858a4: ldur            d1, [x0, #0x3f]
    // 0x6858a8: ldur            d2, [fp, #-0x20]
    // 0x6858ac: ldur            d3, [fp, #-0x18]
    // 0x6858b0: stur            d1, [fp, #-0x28]
    // 0x6858b4: fcmp            d3, d2
    // 0x6858b8: b.vs            #0x6858cc
    // 0x6858bc: b.le            #0x6858cc
    // 0x6858c0: r2 = true
    //     0x6858c0: add             x2, NULL, #0x20  ; true
    // 0x6858c4: d2 = 0.000000
    //     0x6858c4: eor             v2.16b, v2.16b, v2.16b
    // 0x6858c8: b               #0x6858f0
    // 0x6858cc: d2 = 0.000000
    //     0x6858cc: eor             v2.16b, v2.16b, v2.16b
    // 0x6858d0: LoadField: d3 = r0->field_13
    //     0x6858d0: ldur            d3, [x0, #0x13]
    // 0x6858d4: fcmp            d3, d2
    // 0x6858d8: b.vs            #0x6858e0
    // 0x6858dc: b.gt            #0x6858e8
    // 0x6858e0: r1 = false
    //     0x6858e0: add             x1, NULL, #0x30  ; false
    // 0x6858e4: b               #0x6858ec
    // 0x6858e8: r1 = true
    //     0x6858e8: add             x1, NULL, #0x20  ; true
    // 0x6858ec: mov             x2, x1
    // 0x6858f0: ldr             x1, [fp, #0x10]
    // 0x6858f4: stur            x2, [fp, #-0x10]
    // 0x6858f8: r0 = SliverGeometry()
    //     0x6858f8: bl              #0x679334  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x54)
    // 0x6858fc: mov             x1, x0
    // 0x685900: ldur            d0, [fp, #-0x28]
    // 0x685904: StoreField: r1->field_7 = d0
    //     0x685904: stur            d0, [x1, #7]
    // 0x685908: ldur            d0, [fp, #-0x30]
    // 0x68590c: StoreField: r1->field_17 = d0
    //     0x68590c: stur            d0, [x1, #0x17]
    // 0x685910: d1 = 0.000000
    //     0x685910: eor             v1.16b, v1.16b, v1.16b
    // 0x685914: StoreField: r1->field_f = d1
    //     0x685914: stur            d1, [x1, #0xf]
    // 0x685918: StoreField: r1->field_27 = d0
    //     0x685918: stur            d0, [x1, #0x27]
    // 0x68591c: StoreField: r1->field_2f = d1
    //     0x68591c: stur            d1, [x1, #0x2f]
    // 0x685920: ldur            x0, [fp, #-0x10]
    // 0x685924: StoreField: r1->field_43 = r0
    //     0x685924: stur            w0, [x1, #0x43]
    // 0x685928: StoreField: r1->field_1f = d0
    //     0x685928: stur            d0, [x1, #0x1f]
    // 0x68592c: StoreField: r1->field_37 = d0
    //     0x68592c: stur            d0, [x1, #0x37]
    // 0x685930: StoreField: r1->field_4b = d0
    //     0x685930: stur            d0, [x1, #0x4b]
    // 0x685934: fcmp            d0, d1
    // 0x685938: b.vs            #0x685940
    // 0x68593c: b.gt            #0x685948
    // 0x685940: r0 = false
    //     0x685940: add             x0, NULL, #0x30  ; false
    // 0x685944: b               #0x68594c
    // 0x685948: r0 = true
    //     0x685948: add             x0, NULL, #0x20  ; true
    // 0x68594c: StoreField: r1->field_3f = r0
    //     0x68594c: stur            w0, [x1, #0x3f]
    // 0x685950: mov             x0, x1
    // 0x685954: ldr             x2, [fp, #0x10]
    // 0x685958: StoreField: r2->field_4f = r0
    //     0x685958: stur            w0, [x2, #0x4f]
    //     0x68595c: ldurb           w16, [x2, #-1]
    //     0x685960: ldurb           w17, [x0, #-1]
    //     0x685964: and             x16, x17, x16, lsr #2
    //     0x685968: tst             x16, HEAP, lsr #32
    //     0x68596c: b.eq            #0x685974
    //     0x685970: bl              #0xd6828c
    // 0x685974: LoadField: r0 = r2->field_53
    //     0x685974: ldur            w0, [x2, #0x53]
    // 0x685978: DecompressPointer r0
    //     0x685978: add             x0, x0, HEAP, lsl #32
    // 0x68597c: cmp             w0, NULL
    // 0x685980: b.eq            #0x685998
    // 0x685984: stp             x0, x2, [SP, #-0x10]!
    // 0x685988: ldur            x16, [fp, #-8]
    // 0x68598c: stp             x1, x16, [SP, #-0x10]!
    // 0x685990: r0 = setChildParentData()
    //     0x685990: bl              #0x685a08  ; [package:flutter/src/rendering/sliver.dart] RenderSliverSingleBoxAdapter::setChildParentData
    // 0x685994: add             SP, SP, #0x20
    // 0x685998: r0 = Null
    //     0x685998: mov             x0, NULL
    // 0x68599c: LeaveFrame
    //     0x68599c: mov             SP, fp
    //     0x6859a0: ldp             fp, lr, [SP], #0x10
    // 0x6859a4: ret
    //     0x6859a4: ret             
    // 0x6859a8: r0 = StateError()
    //     0x6859a8: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6859ac: mov             x1, x0
    // 0x6859b0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6859b0: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6859b4: ldr             x0, [x0, #0x1e8]
    // 0x6859b8: StoreField: r1->field_b = r0
    //     0x6859b8: stur            w0, [x1, #0xb]
    // 0x6859bc: mov             x0, x1
    // 0x6859c0: r0 = Throw()
    //     0x6859c0: bl              #0xd67e38  ; ThrowStub
    // 0x6859c4: brk             #0
    // 0x6859c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6859c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6859cc: b               #0x6856e8
    // 0x6859d0: stp             q0, q2, [SP, #-0x20]!
    // 0x6859d4: stp             x0, x1, [SP, #-0x10]!
    // 0x6859d8: r0 = AllocateDouble()
    //     0x6859d8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6859dc: mov             x2, x0
    // 0x6859e0: ldp             x0, x1, [SP], #0x10
    // 0x6859e4: ldp             q0, q2, [SP], #0x20
    // 0x6859e8: b               #0x685804
    // 0x6859ec: stp             q0, q1, [SP, #-0x20]!
    // 0x6859f0: SaveReg r0
    //     0x6859f0: str             x0, [SP, #-8]!
    // 0x6859f4: r0 = AllocateDouble()
    //     0x6859f4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6859f8: mov             x1, x0
    // 0x6859fc: RestoreReg r0
    //     0x6859fc: ldr             x0, [SP], #8
    // 0x685a00: ldp             q0, q1, [SP], #0x20
    // 0x685a04: b               #0x685884
  }
}

// class id: 2590, size: 0x74, field offset: 0x6c
class RenderSliverFillViewport extends RenderSliverFixedExtentBoxAdaptor {

  set _ viewportFraction=(/* No info */) {
    // ** addr: 0x6c1f90, size: 0x64
    // 0x6c1f90: EnterFrame
    //     0x6c1f90: stp             fp, lr, [SP, #-0x10]!
    //     0x6c1f94: mov             fp, SP
    // 0x6c1f98: CheckStackOverflow
    //     0x6c1f98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c1f9c: cmp             SP, x16
    //     0x6c1fa0: b.ls            #0x6c1fec
    // 0x6c1fa4: ldr             x0, [fp, #0x18]
    // 0x6c1fa8: LoadField: d0 = r0->field_6b
    //     0x6c1fa8: ldur            d0, [x0, #0x6b]
    // 0x6c1fac: ldr             d1, [fp, #0x10]
    // 0x6c1fb0: fcmp            d0, d1
    // 0x6c1fb4: b.vs            #0x6c1fcc
    // 0x6c1fb8: b.ne            #0x6c1fcc
    // 0x6c1fbc: r0 = Null
    //     0x6c1fbc: mov             x0, NULL
    // 0x6c1fc0: LeaveFrame
    //     0x6c1fc0: mov             SP, fp
    //     0x6c1fc4: ldp             fp, lr, [SP], #0x10
    // 0x6c1fc8: ret
    //     0x6c1fc8: ret             
    // 0x6c1fcc: StoreField: r0->field_6b = d1
    //     0x6c1fcc: stur            d1, [x0, #0x6b]
    // 0x6c1fd0: SaveReg r0
    //     0x6c1fd0: str             x0, [SP, #-8]!
    // 0x6c1fd4: r0 = markNeedsLayout()
    //     0x6c1fd4: bl              #0x6c0ee8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsLayout
    // 0x6c1fd8: add             SP, SP, #8
    // 0x6c1fdc: r0 = Null
    //     0x6c1fdc: mov             x0, NULL
    // 0x6c1fe0: LeaveFrame
    //     0x6c1fe0: mov             SP, fp
    //     0x6c1fe4: ldp             fp, lr, [SP], #0x10
    // 0x6c1fe8: ret
    //     0x6c1fe8: ret             
    // 0x6c1fec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c1fec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c1ff0: b               #0x6c1fa4
  }
  _ RenderSliverFillViewport(/* No info */) {
    // ** addr: 0x6e9c98, size: 0x48
    // 0x6e9c98: EnterFrame
    //     0x6e9c98: stp             fp, lr, [SP, #-0x10]!
    //     0x6e9c9c: mov             fp, SP
    // 0x6e9ca0: CheckStackOverflow
    //     0x6e9ca0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e9ca4: cmp             SP, x16
    //     0x6e9ca8: b.ls            #0x6e9cd8
    // 0x6e9cac: ldr             x0, [fp, #0x20]
    // 0x6e9cb0: ldr             d0, [fp, #0x10]
    // 0x6e9cb4: StoreField: r0->field_6b = d0
    //     0x6e9cb4: stur            d0, [x0, #0x6b]
    // 0x6e9cb8: ldr             x16, [fp, #0x18]
    // 0x6e9cbc: stp             x16, x0, [SP, #-0x10]!
    // 0x6e9cc0: r0 = RenderSliverMultiBoxAdaptor()
    //     0x6e9cc0: bl              #0x6e9998  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::RenderSliverMultiBoxAdaptor
    // 0x6e9cc4: add             SP, SP, #0x10
    // 0x6e9cc8: r0 = Null
    //     0x6e9cc8: mov             x0, NULL
    // 0x6e9ccc: LeaveFrame
    //     0x6e9ccc: mov             SP, fp
    //     0x6e9cd0: ldp             fp, lr, [SP], #0x10
    // 0x6e9cd4: ret
    //     0x6e9cd4: ret             
    // 0x6e9cd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e9cd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e9cdc: b               #0x6e9cac
  }
}

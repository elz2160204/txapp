// lib: , url: package:flutter/src/rendering/flex.dart

// class id: 1049402, size: 0x8
class :: {

  static _ _startIsTopLeft(/* No info */) {
    // ** addr: 0x68a50c, size: 0xc8
    // 0x68a50c: EnterFrame
    //     0x68a50c: stp             fp, lr, [SP, #-0x10]!
    //     0x68a510: mov             fp, SP
    // 0x68a514: ldr             x0, [fp, #0x18]
    // 0x68a518: cmp             w0, NULL
    // 0x68a51c: b.eq            #0x68a590
    // 0x68a520: LoadField: r1 = r0->field_7
    //     0x68a520: ldur            x1, [x0, #7]
    // 0x68a524: cmp             x1, #0
    // 0x68a528: b.gt            #0x68a580
    // 0x68a52c: ldr             x0, [fp, #0x10]
    // 0x68a530: r16 = Instance_TextDirection
    //     0x68a530: ldr             x16, [PP, #0x4808]  ; [pp+0x4808] Obj!TextDirection@b66e31
    // 0x68a534: cmp             w0, w16
    // 0x68a538: b.ne            #0x68a54c
    // 0x68a53c: r0 = true
    //     0x68a53c: add             x0, NULL, #0x20  ; true
    // 0x68a540: LeaveFrame
    //     0x68a540: mov             SP, fp
    //     0x68a544: ldp             fp, lr, [SP], #0x10
    // 0x68a548: ret
    //     0x68a548: ret             
    // 0x68a54c: r16 = Instance_TextDirection
    //     0x68a54c: ldr             x16, [PP, #0x4780]  ; [pp+0x4780] Obj!TextDirection@b66e11
    // 0x68a550: cmp             w0, w16
    // 0x68a554: b.ne            #0x68a568
    // 0x68a558: r0 = false
    //     0x68a558: add             x0, NULL, #0x30  ; false
    // 0x68a55c: LeaveFrame
    //     0x68a55c: mov             SP, fp
    //     0x68a560: ldp             fp, lr, [SP], #0x10
    // 0x68a564: ret
    //     0x68a564: ret             
    // 0x68a568: cmp             w0, NULL
    // 0x68a56c: b.ne            #0x68a5a0
    // 0x68a570: r0 = Null
    //     0x68a570: mov             x0, NULL
    // 0x68a574: LeaveFrame
    //     0x68a574: mov             SP, fp
    //     0x68a578: ldp             fp, lr, [SP], #0x10
    // 0x68a57c: ret
    //     0x68a57c: ret             
    // 0x68a580: r0 = true
    //     0x68a580: add             x0, NULL, #0x20  ; true
    // 0x68a584: LeaveFrame
    //     0x68a584: mov             SP, fp
    //     0x68a588: ldp             fp, lr, [SP], #0x10
    // 0x68a58c: ret
    //     0x68a58c: ret             
    // 0x68a590: r0 = Null
    //     0x68a590: mov             x0, NULL
    // 0x68a594: LeaveFrame
    //     0x68a594: mov             SP, fp
    //     0x68a598: ldp             fp, lr, [SP], #0x10
    // 0x68a59c: ret
    //     0x68a59c: ret             
    // 0x68a5a0: r0 = FallThroughError()
    //     0x68a5a0: bl              #0x55cf84  ; AllocateFallThroughErrorStub -> FallThroughError (size=0x18)
    // 0x68a5a4: mov             x1, x0
    // 0x68a5a8: r0 = "::__startIsTopLeft@474478290"
    //     0x68a5a8: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d2a8] "::__startIsTopLeft@474478290"
    //     0x68a5ac: ldr             x0, [x0, #0x2a8]
    // 0x68a5b0: StoreField: r1->field_b = r0
    //     0x68a5b0: stur            w0, [x1, #0xb]
    // 0x68a5b4: r0 = Null
    //     0x68a5b4: mov             x0, NULL
    // 0x68a5b8: r2 = LoadInt32Instr(r0)
    //     0x68a5b8: sbfx            x2, x0, #1, #0x1f
    //     0x68a5bc: tbz             w0, #0, #0x68a5c4
    //     0x68a5c0: ldur            x2, [x0, #7]
    // 0x68a5c4: StoreField: r1->field_f = r2
    //     0x68a5c4: stur            x2, [x1, #0xf]
    // 0x68a5c8: mov             x0, x1
    // 0x68a5cc: r0 = Throw()
    //     0x68a5cc: bl              #0xd67e38  ; ThrowStub
    // 0x68a5d0: brk             #0
  }
}

// class id: 2030, size: 0x20, field offset: 0x8
//   const constructor, 
class _LayoutSizes extends Object {
}

// class id: 2057, size: 0x20, field offset: 0x18
class FlexParentData extends ContainerBoxParentData<RenderBox> {

  _ toString(/* No info */) {
    // ** addr: 0xae459c, size: 0x98
    // 0xae459c: EnterFrame
    //     0xae459c: stp             fp, lr, [SP, #-0x10]!
    //     0xae45a0: mov             fp, SP
    // 0xae45a4: AllocStack(0x8)
    //     0xae45a4: sub             SP, SP, #8
    // 0xae45a8: CheckStackOverflow
    //     0xae45a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae45ac: cmp             SP, x16
    //     0xae45b0: b.ls            #0xae462c
    // 0xae45b4: ldr             x16, [fp, #0x10]
    // 0xae45b8: SaveReg r16
    //     0xae45b8: str             x16, [SP, #-8]!
    // 0xae45bc: r0 = toString()
    //     0xae45bc: bl              #0xae516c  ; [package:flutter/src/rendering/box.dart] BoxParentData::toString
    // 0xae45c0: add             SP, SP, #8
    // 0xae45c4: r1 = Null
    //     0xae45c4: mov             x1, NULL
    // 0xae45c8: r2 = 10
    //     0xae45c8: mov             x2, #0xa
    // 0xae45cc: stur            x0, [fp, #-8]
    // 0xae45d0: r0 = AllocateArray()
    //     0xae45d0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae45d4: mov             x1, x0
    // 0xae45d8: ldur            x0, [fp, #-8]
    // 0xae45dc: StoreField: r1->field_f = r0
    //     0xae45dc: stur            w0, [x1, #0xf]
    // 0xae45e0: r17 = "; flex="
    //     0xae45e0: add             x17, PP, #0x22, lsl #12  ; [pp+0x22710] "; flex="
    //     0xae45e4: ldr             x17, [x17, #0x710]
    // 0xae45e8: StoreField: r1->field_13 = r17
    //     0xae45e8: stur            w17, [x1, #0x13]
    // 0xae45ec: ldr             x0, [fp, #0x10]
    // 0xae45f0: LoadField: r2 = r0->field_17
    //     0xae45f0: ldur            w2, [x0, #0x17]
    // 0xae45f4: DecompressPointer r2
    //     0xae45f4: add             x2, x2, HEAP, lsl #32
    // 0xae45f8: StoreField: r1->field_17 = r2
    //     0xae45f8: stur            w2, [x1, #0x17]
    // 0xae45fc: r17 = "; fit="
    //     0xae45fc: add             x17, PP, #0x22, lsl #12  ; [pp+0x22718] "; fit="
    //     0xae4600: ldr             x17, [x17, #0x718]
    // 0xae4604: StoreField: r1->field_1b = r17
    //     0xae4604: stur            w17, [x1, #0x1b]
    // 0xae4608: LoadField: r2 = r0->field_1b
    //     0xae4608: ldur            w2, [x0, #0x1b]
    // 0xae460c: DecompressPointer r2
    //     0xae460c: add             x2, x2, HEAP, lsl #32
    // 0xae4610: StoreField: r1->field_1f = r2
    //     0xae4610: stur            w2, [x1, #0x1f]
    // 0xae4614: SaveReg r1
    //     0xae4614: str             x1, [SP, #-8]!
    // 0xae4618: r0 = _interpolate()
    //     0xae4618: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae461c: add             SP, SP, #8
    // 0xae4620: LeaveFrame
    //     0xae4620: mov             SP, fp
    //     0xae4624: ldp             fp, lr, [SP], #0x10
    // 0xae4628: ret
    //     0xae4628: ret             
    // 0xae462c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae462c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae4630: b               #0xae45b4
  }
}

// class id: 2538, size: 0x70, field offset: 0x60
//   transformed mixin,
abstract class _RenderFlex&RenderBox&ContainerRenderObjectMixin extends RenderBox
     with ContainerRenderObjectMixin<X0 bound RenderObject, X1 bound ContainerParentDataMixin<X0 bound RenderObject>> {

  _ move(/* No info */) {
    // ** addr: 0x5ad564, size: 0x170
    // 0x5ad564: EnterFrame
    //     0x5ad564: stp             fp, lr, [SP, #-0x10]!
    //     0x5ad568: mov             fp, SP
    // 0x5ad56c: AllocStack(0x8)
    //     0x5ad56c: sub             SP, SP, #8
    // 0x5ad570: CheckStackOverflow
    //     0x5ad570: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5ad574: cmp             SP, x16
    //     0x5ad578: b.ls            #0x5ad6c8
    // 0x5ad57c: ldr             x0, [fp, #0x18]
    // 0x5ad580: r2 = Null
    //     0x5ad580: mov             x2, NULL
    // 0x5ad584: r1 = Null
    //     0x5ad584: mov             x1, NULL
    // 0x5ad588: r4 = 59
    //     0x5ad588: mov             x4, #0x3b
    // 0x5ad58c: branchIfSmi(r0, 0x5ad598)
    //     0x5ad58c: tbz             w0, #0, #0x5ad598
    // 0x5ad590: r4 = LoadClassIdInstr(r0)
    //     0x5ad590: ldur            x4, [x0, #-1]
    //     0x5ad594: ubfx            x4, x4, #0xc, #0x14
    // 0x5ad598: sub             x4, x4, #0x965
    // 0x5ad59c: cmp             x4, #0x8b
    // 0x5ad5a0: b.ls            #0x5ad5b8
    // 0x5ad5a4: r8 = RenderBox
    //     0x5ad5a4: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x5ad5a8: ldr             x8, [x8, #0xfa0]
    // 0x5ad5ac: r3 = Null
    //     0x5ad5ac: add             x3, PP, #0x22, lsl #12  ; [pp+0x22728] Null
    //     0x5ad5b0: ldr             x3, [x3, #0x728]
    // 0x5ad5b4: r0 = RenderBox()
    //     0x5ad5b4: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x5ad5b8: ldr             x0, [fp, #0x10]
    // 0x5ad5bc: r2 = Null
    //     0x5ad5bc: mov             x2, NULL
    // 0x5ad5c0: r1 = Null
    //     0x5ad5c0: mov             x1, NULL
    // 0x5ad5c4: r4 = 59
    //     0x5ad5c4: mov             x4, #0x3b
    // 0x5ad5c8: branchIfSmi(r0, 0x5ad5d4)
    //     0x5ad5c8: tbz             w0, #0, #0x5ad5d4
    // 0x5ad5cc: r4 = LoadClassIdInstr(r0)
    //     0x5ad5cc: ldur            x4, [x0, #-1]
    //     0x5ad5d0: ubfx            x4, x4, #0xc, #0x14
    // 0x5ad5d4: sub             x4, x4, #0x965
    // 0x5ad5d8: cmp             x4, #0x8b
    // 0x5ad5dc: b.ls            #0x5ad5f0
    // 0x5ad5e0: r8 = RenderBox?
    //     0x5ad5e0: ldr             x8, [PP, #0x4de8]  ; [pp+0x4de8] Type: RenderBox?
    // 0x5ad5e4: r3 = Null
    //     0x5ad5e4: add             x3, PP, #0x22, lsl #12  ; [pp+0x22738] Null
    //     0x5ad5e8: ldr             x3, [x3, #0x738]
    // 0x5ad5ec: r0 = RenderBox?()
    //     0x5ad5ec: bl              #0x5ad534  ; IsType_RenderBox?_Stub
    // 0x5ad5f0: ldr             x3, [fp, #0x18]
    // 0x5ad5f4: LoadField: r4 = r3->field_17
    //     0x5ad5f4: ldur            w4, [x3, #0x17]
    // 0x5ad5f8: DecompressPointer r4
    //     0x5ad5f8: add             x4, x4, HEAP, lsl #32
    // 0x5ad5fc: stur            x4, [fp, #-8]
    // 0x5ad600: cmp             w4, NULL
    // 0x5ad604: b.eq            #0x5ad6d0
    // 0x5ad608: mov             x0, x4
    // 0x5ad60c: r2 = Null
    //     0x5ad60c: mov             x2, NULL
    // 0x5ad610: r1 = Null
    //     0x5ad610: mov             x1, NULL
    // 0x5ad614: r4 = LoadClassIdInstr(r0)
    //     0x5ad614: ldur            x4, [x0, #-1]
    //     0x5ad618: ubfx            x4, x4, #0xc, #0x14
    // 0x5ad61c: cmp             x4, #0x809
    // 0x5ad620: b.eq            #0x5ad638
    // 0x5ad624: r8 = FlexParentData<RenderBox>
    //     0x5ad624: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x5ad628: ldr             x8, [x8, #0x248]
    // 0x5ad62c: r3 = Null
    //     0x5ad62c: add             x3, PP, #0x22, lsl #12  ; [pp+0x22748] Null
    //     0x5ad630: ldr             x3, [x3, #0x748]
    // 0x5ad634: r0 = DefaultTypeTest()
    //     0x5ad634: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5ad638: ldur            x0, [fp, #-8]
    // 0x5ad63c: LoadField: r1 = r0->field_f
    //     0x5ad63c: ldur            w1, [x0, #0xf]
    // 0x5ad640: DecompressPointer r1
    //     0x5ad640: add             x1, x1, HEAP, lsl #32
    // 0x5ad644: r0 = LoadClassIdInstr(r1)
    //     0x5ad644: ldur            x0, [x1, #-1]
    //     0x5ad648: ubfx            x0, x0, #0xc, #0x14
    // 0x5ad64c: ldr             x16, [fp, #0x10]
    // 0x5ad650: stp             x16, x1, [SP, #-0x10]!
    // 0x5ad654: mov             lr, x0
    // 0x5ad658: ldr             lr, [x21, lr, lsl #3]
    // 0x5ad65c: blr             lr
    // 0x5ad660: add             SP, SP, #0x10
    // 0x5ad664: tbnz            w0, #4, #0x5ad678
    // 0x5ad668: r0 = Null
    //     0x5ad668: mov             x0, NULL
    // 0x5ad66c: LeaveFrame
    //     0x5ad66c: mov             SP, fp
    //     0x5ad670: ldp             fp, lr, [SP], #0x10
    // 0x5ad674: ret
    //     0x5ad674: ret             
    // 0x5ad678: ldr             x16, [fp, #0x20]
    // 0x5ad67c: ldr             lr, [fp, #0x18]
    // 0x5ad680: stp             lr, x16, [SP, #-0x10]!
    // 0x5ad684: r0 = _removeFromChildList()
    //     0x5ad684: bl              #0x5adc34  ; [package:flutter/src/rendering/flex.dart] _RenderFlex&RenderBox&ContainerRenderObjectMixin::_removeFromChildList
    // 0x5ad688: add             SP, SP, #0x10
    // 0x5ad68c: ldr             x16, [fp, #0x20]
    // 0x5ad690: ldr             lr, [fp, #0x18]
    // 0x5ad694: stp             lr, x16, [SP, #-0x10]!
    // 0x5ad698: ldr             x16, [fp, #0x10]
    // 0x5ad69c: SaveReg r16
    //     0x5ad69c: str             x16, [SP, #-8]!
    // 0x5ad6a0: r0 = _insertIntoChildList()
    //     0x5ad6a0: bl              #0x5ad6d4  ; [package:flutter/src/rendering/flex.dart] _RenderFlex&RenderBox&ContainerRenderObjectMixin::_insertIntoChildList
    // 0x5ad6a4: add             SP, SP, #0x18
    // 0x5ad6a8: ldr             x16, [fp, #0x20]
    // 0x5ad6ac: SaveReg r16
    //     0x5ad6ac: str             x16, [SP, #-8]!
    // 0x5ad6b0: r0 = markNeedsLayout()
    //     0x5ad6b0: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x5ad6b4: add             SP, SP, #8
    // 0x5ad6b8: r0 = Null
    //     0x5ad6b8: mov             x0, NULL
    // 0x5ad6bc: LeaveFrame
    //     0x5ad6bc: mov             SP, fp
    //     0x5ad6c0: ldp             fp, lr, [SP], #0x10
    // 0x5ad6c4: ret
    //     0x5ad6c4: ret             
    // 0x5ad6c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5ad6c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5ad6cc: b               #0x5ad57c
    // 0x5ad6d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5ad6d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _insertIntoChildList(/* No info */) {
    // ** addr: 0x5ad6d4, size: 0x560
    // 0x5ad6d4: EnterFrame
    //     0x5ad6d4: stp             fp, lr, [SP, #-0x10]!
    //     0x5ad6d8: mov             fp, SP
    // 0x5ad6dc: AllocStack(0x20)
    //     0x5ad6dc: sub             SP, SP, #0x20
    // 0x5ad6e0: ldr             x3, [fp, #0x18]
    // 0x5ad6e4: LoadField: r4 = r3->field_17
    //     0x5ad6e4: ldur            w4, [x3, #0x17]
    // 0x5ad6e8: DecompressPointer r4
    //     0x5ad6e8: add             x4, x4, HEAP, lsl #32
    // 0x5ad6ec: stur            x4, [fp, #-8]
    // 0x5ad6f0: cmp             w4, NULL
    // 0x5ad6f4: b.eq            #0x5adc24
    // 0x5ad6f8: mov             x0, x4
    // 0x5ad6fc: r2 = Null
    //     0x5ad6fc: mov             x2, NULL
    // 0x5ad700: r1 = Null
    //     0x5ad700: mov             x1, NULL
    // 0x5ad704: r4 = LoadClassIdInstr(r0)
    //     0x5ad704: ldur            x4, [x0, #-1]
    //     0x5ad708: ubfx            x4, x4, #0xc, #0x14
    // 0x5ad70c: cmp             x4, #0x809
    // 0x5ad710: b.eq            #0x5ad728
    // 0x5ad714: r8 = FlexParentData<RenderBox>
    //     0x5ad714: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x5ad718: ldr             x8, [x8, #0x248]
    // 0x5ad71c: r3 = Null
    //     0x5ad71c: add             x3, PP, #0x22, lsl #12  ; [pp+0x22758] Null
    //     0x5ad720: ldr             x3, [x3, #0x758]
    // 0x5ad724: r0 = DefaultTypeTest()
    //     0x5ad724: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5ad728: ldr             x3, [fp, #0x20]
    // 0x5ad72c: LoadField: r0 = r3->field_5f
    //     0x5ad72c: ldur            x0, [x3, #0x5f]
    // 0x5ad730: add             x1, x0, #1
    // 0x5ad734: StoreField: r3->field_5f = r1
    //     0x5ad734: stur            x1, [x3, #0x5f]
    // 0x5ad738: ldr             x4, [fp, #0x10]
    // 0x5ad73c: cmp             w4, NULL
    // 0x5ad740: b.ne            #0x5ad8c8
    // 0x5ad744: ldur            x4, [fp, #-8]
    // 0x5ad748: LoadField: r5 = r3->field_67
    //     0x5ad748: ldur            w5, [x3, #0x67]
    // 0x5ad74c: DecompressPointer r5
    //     0x5ad74c: add             x5, x5, HEAP, lsl #32
    // 0x5ad750: stur            x5, [fp, #-0x10]
    // 0x5ad754: LoadField: r2 = r4->field_b
    //     0x5ad754: ldur            w2, [x4, #0xb]
    // 0x5ad758: DecompressPointer r2
    //     0x5ad758: add             x2, x2, HEAP, lsl #32
    // 0x5ad75c: mov             x0, x5
    // 0x5ad760: r1 = Null
    //     0x5ad760: mov             x1, NULL
    // 0x5ad764: cmp             w0, NULL
    // 0x5ad768: b.eq            #0x5ad794
    // 0x5ad76c: cmp             w2, NULL
    // 0x5ad770: b.eq            #0x5ad794
    // 0x5ad774: LoadField: r4 = r2->field_17
    //     0x5ad774: ldur            w4, [x2, #0x17]
    // 0x5ad778: DecompressPointer r4
    //     0x5ad778: add             x4, x4, HEAP, lsl #32
    // 0x5ad77c: r8 = X0? bound RenderObject
    //     0x5ad77c: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5ad780: ldr             x8, [x8, #0x6e8]
    // 0x5ad784: LoadField: r9 = r4->field_7
    //     0x5ad784: ldur            x9, [x4, #7]
    // 0x5ad788: r3 = Null
    //     0x5ad788: add             x3, PP, #0x22, lsl #12  ; [pp+0x22768] Null
    //     0x5ad78c: ldr             x3, [x3, #0x768]
    // 0x5ad790: blr             x9
    // 0x5ad794: ldur            x0, [fp, #-0x10]
    // 0x5ad798: ldur            x3, [fp, #-8]
    // 0x5ad79c: StoreField: r3->field_13 = r0
    //     0x5ad79c: stur            w0, [x3, #0x13]
    //     0x5ad7a0: ldurb           w16, [x3, #-1]
    //     0x5ad7a4: ldurb           w17, [x0, #-1]
    //     0x5ad7a8: and             x16, x17, x16, lsr #2
    //     0x5ad7ac: tst             x16, HEAP, lsr #32
    //     0x5ad7b0: b.eq            #0x5ad7b8
    //     0x5ad7b4: bl              #0xd682ac
    // 0x5ad7b8: ldur            x0, [fp, #-0x10]
    // 0x5ad7bc: cmp             w0, NULL
    // 0x5ad7c0: b.eq            #0x5ad870
    // 0x5ad7c4: LoadField: r3 = r0->field_17
    //     0x5ad7c4: ldur            w3, [x0, #0x17]
    // 0x5ad7c8: DecompressPointer r3
    //     0x5ad7c8: add             x3, x3, HEAP, lsl #32
    // 0x5ad7cc: stur            x3, [fp, #-0x18]
    // 0x5ad7d0: cmp             w3, NULL
    // 0x5ad7d4: b.eq            #0x5adc28
    // 0x5ad7d8: mov             x0, x3
    // 0x5ad7dc: r2 = Null
    //     0x5ad7dc: mov             x2, NULL
    // 0x5ad7e0: r1 = Null
    //     0x5ad7e0: mov             x1, NULL
    // 0x5ad7e4: r4 = LoadClassIdInstr(r0)
    //     0x5ad7e4: ldur            x4, [x0, #-1]
    //     0x5ad7e8: ubfx            x4, x4, #0xc, #0x14
    // 0x5ad7ec: cmp             x4, #0x809
    // 0x5ad7f0: b.eq            #0x5ad808
    // 0x5ad7f4: r8 = FlexParentData<RenderBox>
    //     0x5ad7f4: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x5ad7f8: ldr             x8, [x8, #0x248]
    // 0x5ad7fc: r3 = Null
    //     0x5ad7fc: add             x3, PP, #0x22, lsl #12  ; [pp+0x22778] Null
    //     0x5ad800: ldr             x3, [x3, #0x778]
    // 0x5ad804: r0 = DefaultTypeTest()
    //     0x5ad804: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5ad808: ldur            x3, [fp, #-0x18]
    // 0x5ad80c: LoadField: r2 = r3->field_b
    //     0x5ad80c: ldur            w2, [x3, #0xb]
    // 0x5ad810: DecompressPointer r2
    //     0x5ad810: add             x2, x2, HEAP, lsl #32
    // 0x5ad814: ldr             x0, [fp, #0x18]
    // 0x5ad818: r1 = Null
    //     0x5ad818: mov             x1, NULL
    // 0x5ad81c: cmp             w0, NULL
    // 0x5ad820: b.eq            #0x5ad84c
    // 0x5ad824: cmp             w2, NULL
    // 0x5ad828: b.eq            #0x5ad84c
    // 0x5ad82c: LoadField: r4 = r2->field_17
    //     0x5ad82c: ldur            w4, [x2, #0x17]
    // 0x5ad830: DecompressPointer r4
    //     0x5ad830: add             x4, x4, HEAP, lsl #32
    // 0x5ad834: r8 = X0? bound RenderObject
    //     0x5ad834: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5ad838: ldr             x8, [x8, #0x6e8]
    // 0x5ad83c: LoadField: r9 = r4->field_7
    //     0x5ad83c: ldur            x9, [x4, #7]
    // 0x5ad840: r3 = Null
    //     0x5ad840: add             x3, PP, #0x22, lsl #12  ; [pp+0x22788] Null
    //     0x5ad844: ldr             x3, [x3, #0x788]
    // 0x5ad848: blr             x9
    // 0x5ad84c: ldr             x0, [fp, #0x18]
    // 0x5ad850: ldur            x1, [fp, #-0x18]
    // 0x5ad854: StoreField: r1->field_f = r0
    //     0x5ad854: stur            w0, [x1, #0xf]
    //     0x5ad858: ldurb           w16, [x1, #-1]
    //     0x5ad85c: ldurb           w17, [x0, #-1]
    //     0x5ad860: and             x16, x17, x16, lsr #2
    //     0x5ad864: tst             x16, HEAP, lsr #32
    //     0x5ad868: b.eq            #0x5ad870
    //     0x5ad86c: bl              #0xd6826c
    // 0x5ad870: ldr             x5, [fp, #0x20]
    // 0x5ad874: ldr             x0, [fp, #0x18]
    // 0x5ad878: StoreField: r5->field_67 = r0
    //     0x5ad878: stur            w0, [x5, #0x67]
    //     0x5ad87c: ldurb           w16, [x5, #-1]
    //     0x5ad880: ldurb           w17, [x0, #-1]
    //     0x5ad884: and             x16, x17, x16, lsr #2
    //     0x5ad888: tst             x16, HEAP, lsr #32
    //     0x5ad88c: b.eq            #0x5ad894
    //     0x5ad890: bl              #0xd682ec
    // 0x5ad894: LoadField: r0 = r5->field_6b
    //     0x5ad894: ldur            w0, [x5, #0x6b]
    // 0x5ad898: DecompressPointer r0
    //     0x5ad898: add             x0, x0, HEAP, lsl #32
    // 0x5ad89c: cmp             w0, NULL
    // 0x5ad8a0: b.ne            #0x5adc14
    // 0x5ad8a4: ldr             x0, [fp, #0x18]
    // 0x5ad8a8: StoreField: r5->field_6b = r0
    //     0x5ad8a8: stur            w0, [x5, #0x6b]
    //     0x5ad8ac: ldurb           w16, [x5, #-1]
    //     0x5ad8b0: ldurb           w17, [x0, #-1]
    //     0x5ad8b4: and             x16, x17, x16, lsr #2
    //     0x5ad8b8: tst             x16, HEAP, lsr #32
    //     0x5ad8bc: b.eq            #0x5ad8c4
    //     0x5ad8c0: bl              #0xd682ec
    // 0x5ad8c4: b               #0x5adc14
    // 0x5ad8c8: mov             x5, x3
    // 0x5ad8cc: ldur            x3, [fp, #-8]
    // 0x5ad8d0: LoadField: r6 = r4->field_17
    //     0x5ad8d0: ldur            w6, [x4, #0x17]
    // 0x5ad8d4: DecompressPointer r6
    //     0x5ad8d4: add             x6, x6, HEAP, lsl #32
    // 0x5ad8d8: stur            x6, [fp, #-0x10]
    // 0x5ad8dc: cmp             w6, NULL
    // 0x5ad8e0: b.eq            #0x5adc2c
    // 0x5ad8e4: mov             x0, x6
    // 0x5ad8e8: r2 = Null
    //     0x5ad8e8: mov             x2, NULL
    // 0x5ad8ec: r1 = Null
    //     0x5ad8ec: mov             x1, NULL
    // 0x5ad8f0: r4 = LoadClassIdInstr(r0)
    //     0x5ad8f0: ldur            x4, [x0, #-1]
    //     0x5ad8f4: ubfx            x4, x4, #0xc, #0x14
    // 0x5ad8f8: cmp             x4, #0x809
    // 0x5ad8fc: b.eq            #0x5ad914
    // 0x5ad900: r8 = FlexParentData<RenderBox>
    //     0x5ad900: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x5ad904: ldr             x8, [x8, #0x248]
    // 0x5ad908: r3 = Null
    //     0x5ad908: add             x3, PP, #0x22, lsl #12  ; [pp+0x22798] Null
    //     0x5ad90c: ldr             x3, [x3, #0x798]
    // 0x5ad910: r0 = DefaultTypeTest()
    //     0x5ad910: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5ad914: ldur            x3, [fp, #-0x10]
    // 0x5ad918: LoadField: r4 = r3->field_13
    //     0x5ad918: ldur            w4, [x3, #0x13]
    // 0x5ad91c: DecompressPointer r4
    //     0x5ad91c: add             x4, x4, HEAP, lsl #32
    // 0x5ad920: stur            x4, [fp, #-0x20]
    // 0x5ad924: cmp             w4, NULL
    // 0x5ad928: b.ne            #0x5ada28
    // 0x5ad92c: ldr             x5, [fp, #0x20]
    // 0x5ad930: ldur            x4, [fp, #-8]
    // 0x5ad934: LoadField: r2 = r4->field_b
    //     0x5ad934: ldur            w2, [x4, #0xb]
    // 0x5ad938: DecompressPointer r2
    //     0x5ad938: add             x2, x2, HEAP, lsl #32
    // 0x5ad93c: ldr             x0, [fp, #0x10]
    // 0x5ad940: r1 = Null
    //     0x5ad940: mov             x1, NULL
    // 0x5ad944: cmp             w0, NULL
    // 0x5ad948: b.eq            #0x5ad974
    // 0x5ad94c: cmp             w2, NULL
    // 0x5ad950: b.eq            #0x5ad974
    // 0x5ad954: LoadField: r4 = r2->field_17
    //     0x5ad954: ldur            w4, [x2, #0x17]
    // 0x5ad958: DecompressPointer r4
    //     0x5ad958: add             x4, x4, HEAP, lsl #32
    // 0x5ad95c: r8 = X0? bound RenderObject
    //     0x5ad95c: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5ad960: ldr             x8, [x8, #0x6e8]
    // 0x5ad964: LoadField: r9 = r4->field_7
    //     0x5ad964: ldur            x9, [x4, #7]
    // 0x5ad968: r3 = Null
    //     0x5ad968: add             x3, PP, #0x22, lsl #12  ; [pp+0x227a8] Null
    //     0x5ad96c: ldr             x3, [x3, #0x7a8]
    // 0x5ad970: blr             x9
    // 0x5ad974: ldr             x0, [fp, #0x10]
    // 0x5ad978: ldur            x3, [fp, #-8]
    // 0x5ad97c: StoreField: r3->field_f = r0
    //     0x5ad97c: stur            w0, [x3, #0xf]
    //     0x5ad980: ldurb           w16, [x3, #-1]
    //     0x5ad984: ldurb           w17, [x0, #-1]
    //     0x5ad988: and             x16, x17, x16, lsr #2
    //     0x5ad98c: tst             x16, HEAP, lsr #32
    //     0x5ad990: b.eq            #0x5ad998
    //     0x5ad994: bl              #0xd682ac
    // 0x5ad998: ldur            x3, [fp, #-0x10]
    // 0x5ad99c: LoadField: r2 = r3->field_b
    //     0x5ad99c: ldur            w2, [x3, #0xb]
    // 0x5ad9a0: DecompressPointer r2
    //     0x5ad9a0: add             x2, x2, HEAP, lsl #32
    // 0x5ad9a4: ldr             x0, [fp, #0x18]
    // 0x5ad9a8: r1 = Null
    //     0x5ad9a8: mov             x1, NULL
    // 0x5ad9ac: cmp             w0, NULL
    // 0x5ad9b0: b.eq            #0x5ad9dc
    // 0x5ad9b4: cmp             w2, NULL
    // 0x5ad9b8: b.eq            #0x5ad9dc
    // 0x5ad9bc: LoadField: r4 = r2->field_17
    //     0x5ad9bc: ldur            w4, [x2, #0x17]
    // 0x5ad9c0: DecompressPointer r4
    //     0x5ad9c0: add             x4, x4, HEAP, lsl #32
    // 0x5ad9c4: r8 = X0? bound RenderObject
    //     0x5ad9c4: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5ad9c8: ldr             x8, [x8, #0x6e8]
    // 0x5ad9cc: LoadField: r9 = r4->field_7
    //     0x5ad9cc: ldur            x9, [x4, #7]
    // 0x5ad9d0: r3 = Null
    //     0x5ad9d0: add             x3, PP, #0x22, lsl #12  ; [pp+0x227b8] Null
    //     0x5ad9d4: ldr             x3, [x3, #0x7b8]
    // 0x5ad9d8: blr             x9
    // 0x5ad9dc: ldr             x0, [fp, #0x18]
    // 0x5ad9e0: ldur            x5, [fp, #-0x10]
    // 0x5ad9e4: StoreField: r5->field_13 = r0
    //     0x5ad9e4: stur            w0, [x5, #0x13]
    //     0x5ad9e8: ldurb           w16, [x5, #-1]
    //     0x5ad9ec: ldurb           w17, [x0, #-1]
    //     0x5ad9f0: and             x16, x17, x16, lsr #2
    //     0x5ad9f4: tst             x16, HEAP, lsr #32
    //     0x5ad9f8: b.eq            #0x5ada00
    //     0x5ad9fc: bl              #0xd682ec
    // 0x5ada00: ldr             x0, [fp, #0x18]
    // 0x5ada04: ldr             x1, [fp, #0x20]
    // 0x5ada08: StoreField: r1->field_6b = r0
    //     0x5ada08: stur            w0, [x1, #0x6b]
    //     0x5ada0c: ldurb           w16, [x1, #-1]
    //     0x5ada10: ldurb           w17, [x0, #-1]
    //     0x5ada14: and             x16, x17, x16, lsr #2
    //     0x5ada18: tst             x16, HEAP, lsr #32
    //     0x5ada1c: b.eq            #0x5ada24
    //     0x5ada20: bl              #0xd6826c
    // 0x5ada24: b               #0x5adc14
    // 0x5ada28: mov             x5, x3
    // 0x5ada2c: ldur            x3, [fp, #-8]
    // 0x5ada30: LoadField: r6 = r3->field_b
    //     0x5ada30: ldur            w6, [x3, #0xb]
    // 0x5ada34: DecompressPointer r6
    //     0x5ada34: add             x6, x6, HEAP, lsl #32
    // 0x5ada38: mov             x0, x4
    // 0x5ada3c: mov             x2, x6
    // 0x5ada40: stur            x6, [fp, #-0x18]
    // 0x5ada44: r1 = Null
    //     0x5ada44: mov             x1, NULL
    // 0x5ada48: cmp             w0, NULL
    // 0x5ada4c: b.eq            #0x5ada78
    // 0x5ada50: cmp             w2, NULL
    // 0x5ada54: b.eq            #0x5ada78
    // 0x5ada58: LoadField: r4 = r2->field_17
    //     0x5ada58: ldur            w4, [x2, #0x17]
    // 0x5ada5c: DecompressPointer r4
    //     0x5ada5c: add             x4, x4, HEAP, lsl #32
    // 0x5ada60: r8 = X0? bound RenderObject
    //     0x5ada60: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5ada64: ldr             x8, [x8, #0x6e8]
    // 0x5ada68: LoadField: r9 = r4->field_7
    //     0x5ada68: ldur            x9, [x4, #7]
    // 0x5ada6c: r3 = Null
    //     0x5ada6c: add             x3, PP, #0x22, lsl #12  ; [pp+0x227c8] Null
    //     0x5ada70: ldr             x3, [x3, #0x7c8]
    // 0x5ada74: blr             x9
    // 0x5ada78: ldur            x0, [fp, #-0x20]
    // 0x5ada7c: ldur            x3, [fp, #-8]
    // 0x5ada80: StoreField: r3->field_13 = r0
    //     0x5ada80: stur            w0, [x3, #0x13]
    //     0x5ada84: ldurb           w16, [x3, #-1]
    //     0x5ada88: ldurb           w17, [x0, #-1]
    //     0x5ada8c: and             x16, x17, x16, lsr #2
    //     0x5ada90: tst             x16, HEAP, lsr #32
    //     0x5ada94: b.eq            #0x5ada9c
    //     0x5ada98: bl              #0xd682ac
    // 0x5ada9c: ldr             x0, [fp, #0x10]
    // 0x5adaa0: ldur            x2, [fp, #-0x18]
    // 0x5adaa4: r1 = Null
    //     0x5adaa4: mov             x1, NULL
    // 0x5adaa8: cmp             w0, NULL
    // 0x5adaac: b.eq            #0x5adad8
    // 0x5adab0: cmp             w2, NULL
    // 0x5adab4: b.eq            #0x5adad8
    // 0x5adab8: LoadField: r4 = r2->field_17
    //     0x5adab8: ldur            w4, [x2, #0x17]
    // 0x5adabc: DecompressPointer r4
    //     0x5adabc: add             x4, x4, HEAP, lsl #32
    // 0x5adac0: r8 = X0? bound RenderObject
    //     0x5adac0: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5adac4: ldr             x8, [x8, #0x6e8]
    // 0x5adac8: LoadField: r9 = r4->field_7
    //     0x5adac8: ldur            x9, [x4, #7]
    // 0x5adacc: r3 = Null
    //     0x5adacc: add             x3, PP, #0x22, lsl #12  ; [pp+0x227d8] Null
    //     0x5adad0: ldr             x3, [x3, #0x7d8]
    // 0x5adad4: blr             x9
    // 0x5adad8: ldr             x0, [fp, #0x10]
    // 0x5adadc: ldur            x1, [fp, #-8]
    // 0x5adae0: StoreField: r1->field_f = r0
    //     0x5adae0: stur            w0, [x1, #0xf]
    //     0x5adae4: ldurb           w16, [x1, #-1]
    //     0x5adae8: ldurb           w17, [x0, #-1]
    //     0x5adaec: and             x16, x17, x16, lsr #2
    //     0x5adaf0: tst             x16, HEAP, lsr #32
    //     0x5adaf4: b.eq            #0x5adafc
    //     0x5adaf8: bl              #0xd6826c
    // 0x5adafc: ldur            x0, [fp, #-0x20]
    // 0x5adb00: LoadField: r3 = r0->field_17
    //     0x5adb00: ldur            w3, [x0, #0x17]
    // 0x5adb04: DecompressPointer r3
    //     0x5adb04: add             x3, x3, HEAP, lsl #32
    // 0x5adb08: stur            x3, [fp, #-8]
    // 0x5adb0c: cmp             w3, NULL
    // 0x5adb10: b.eq            #0x5adc30
    // 0x5adb14: mov             x0, x3
    // 0x5adb18: r2 = Null
    //     0x5adb18: mov             x2, NULL
    // 0x5adb1c: r1 = Null
    //     0x5adb1c: mov             x1, NULL
    // 0x5adb20: r4 = LoadClassIdInstr(r0)
    //     0x5adb20: ldur            x4, [x0, #-1]
    //     0x5adb24: ubfx            x4, x4, #0xc, #0x14
    // 0x5adb28: cmp             x4, #0x809
    // 0x5adb2c: b.eq            #0x5adb44
    // 0x5adb30: r8 = FlexParentData<RenderBox>
    //     0x5adb30: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x5adb34: ldr             x8, [x8, #0x248]
    // 0x5adb38: r3 = Null
    //     0x5adb38: add             x3, PP, #0x22, lsl #12  ; [pp+0x227e8] Null
    //     0x5adb3c: ldr             x3, [x3, #0x7e8]
    // 0x5adb40: r0 = DefaultTypeTest()
    //     0x5adb40: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5adb44: ldur            x3, [fp, #-0x10]
    // 0x5adb48: LoadField: r2 = r3->field_b
    //     0x5adb48: ldur            w2, [x3, #0xb]
    // 0x5adb4c: DecompressPointer r2
    //     0x5adb4c: add             x2, x2, HEAP, lsl #32
    // 0x5adb50: ldr             x0, [fp, #0x18]
    // 0x5adb54: r1 = Null
    //     0x5adb54: mov             x1, NULL
    // 0x5adb58: cmp             w0, NULL
    // 0x5adb5c: b.eq            #0x5adb88
    // 0x5adb60: cmp             w2, NULL
    // 0x5adb64: b.eq            #0x5adb88
    // 0x5adb68: LoadField: r4 = r2->field_17
    //     0x5adb68: ldur            w4, [x2, #0x17]
    // 0x5adb6c: DecompressPointer r4
    //     0x5adb6c: add             x4, x4, HEAP, lsl #32
    // 0x5adb70: r8 = X0? bound RenderObject
    //     0x5adb70: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5adb74: ldr             x8, [x8, #0x6e8]
    // 0x5adb78: LoadField: r9 = r4->field_7
    //     0x5adb78: ldur            x9, [x4, #7]
    // 0x5adb7c: r3 = Null
    //     0x5adb7c: add             x3, PP, #0x22, lsl #12  ; [pp+0x227f8] Null
    //     0x5adb80: ldr             x3, [x3, #0x7f8]
    // 0x5adb84: blr             x9
    // 0x5adb88: ldr             x0, [fp, #0x18]
    // 0x5adb8c: ldur            x1, [fp, #-0x10]
    // 0x5adb90: StoreField: r1->field_13 = r0
    //     0x5adb90: stur            w0, [x1, #0x13]
    //     0x5adb94: ldurb           w16, [x1, #-1]
    //     0x5adb98: ldurb           w17, [x0, #-1]
    //     0x5adb9c: and             x16, x17, x16, lsr #2
    //     0x5adba0: tst             x16, HEAP, lsr #32
    //     0x5adba4: b.eq            #0x5adbac
    //     0x5adba8: bl              #0xd6826c
    // 0x5adbac: ldur            x3, [fp, #-8]
    // 0x5adbb0: LoadField: r2 = r3->field_b
    //     0x5adbb0: ldur            w2, [x3, #0xb]
    // 0x5adbb4: DecompressPointer r2
    //     0x5adbb4: add             x2, x2, HEAP, lsl #32
    // 0x5adbb8: ldr             x0, [fp, #0x18]
    // 0x5adbbc: r1 = Null
    //     0x5adbbc: mov             x1, NULL
    // 0x5adbc0: cmp             w0, NULL
    // 0x5adbc4: b.eq            #0x5adbf0
    // 0x5adbc8: cmp             w2, NULL
    // 0x5adbcc: b.eq            #0x5adbf0
    // 0x5adbd0: LoadField: r4 = r2->field_17
    //     0x5adbd0: ldur            w4, [x2, #0x17]
    // 0x5adbd4: DecompressPointer r4
    //     0x5adbd4: add             x4, x4, HEAP, lsl #32
    // 0x5adbd8: r8 = X0? bound RenderObject
    //     0x5adbd8: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5adbdc: ldr             x8, [x8, #0x6e8]
    // 0x5adbe0: LoadField: r9 = r4->field_7
    //     0x5adbe0: ldur            x9, [x4, #7]
    // 0x5adbe4: r3 = Null
    //     0x5adbe4: add             x3, PP, #0x22, lsl #12  ; [pp+0x22808] Null
    //     0x5adbe8: ldr             x3, [x3, #0x808]
    // 0x5adbec: blr             x9
    // 0x5adbf0: ldr             x0, [fp, #0x18]
    // 0x5adbf4: ldur            x1, [fp, #-8]
    // 0x5adbf8: StoreField: r1->field_f = r0
    //     0x5adbf8: stur            w0, [x1, #0xf]
    //     0x5adbfc: ldurb           w16, [x1, #-1]
    //     0x5adc00: ldurb           w17, [x0, #-1]
    //     0x5adc04: and             x16, x17, x16, lsr #2
    //     0x5adc08: tst             x16, HEAP, lsr #32
    //     0x5adc0c: b.eq            #0x5adc14
    //     0x5adc10: bl              #0xd6826c
    // 0x5adc14: r0 = Null
    //     0x5adc14: mov             x0, NULL
    // 0x5adc18: LeaveFrame
    //     0x5adc18: mov             SP, fp
    //     0x5adc1c: ldp             fp, lr, [SP], #0x10
    // 0x5adc20: ret
    //     0x5adc20: ret             
    // 0x5adc24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5adc24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5adc28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5adc28: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5adc2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5adc2c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5adc30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5adc30: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _removeFromChildList(/* No info */) {
    // ** addr: 0x5adc34, size: 0x2c4
    // 0x5adc34: EnterFrame
    //     0x5adc34: stp             fp, lr, [SP, #-0x10]!
    //     0x5adc38: mov             fp, SP
    // 0x5adc3c: AllocStack(0x20)
    //     0x5adc3c: sub             SP, SP, #0x20
    // 0x5adc40: ldr             x0, [fp, #0x10]
    // 0x5adc44: LoadField: r3 = r0->field_17
    //     0x5adc44: ldur            w3, [x0, #0x17]
    // 0x5adc48: DecompressPointer r3
    //     0x5adc48: add             x3, x3, HEAP, lsl #32
    // 0x5adc4c: stur            x3, [fp, #-8]
    // 0x5adc50: cmp             w3, NULL
    // 0x5adc54: b.eq            #0x5adeec
    // 0x5adc58: mov             x0, x3
    // 0x5adc5c: r2 = Null
    //     0x5adc5c: mov             x2, NULL
    // 0x5adc60: r1 = Null
    //     0x5adc60: mov             x1, NULL
    // 0x5adc64: r4 = LoadClassIdInstr(r0)
    //     0x5adc64: ldur            x4, [x0, #-1]
    //     0x5adc68: ubfx            x4, x4, #0xc, #0x14
    // 0x5adc6c: cmp             x4, #0x809
    // 0x5adc70: b.eq            #0x5adc88
    // 0x5adc74: r8 = FlexParentData<RenderBox>
    //     0x5adc74: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x5adc78: ldr             x8, [x8, #0x248]
    // 0x5adc7c: r3 = Null
    //     0x5adc7c: add             x3, PP, #0x22, lsl #12  ; [pp+0x22818] Null
    //     0x5adc80: ldr             x3, [x3, #0x818]
    // 0x5adc84: r0 = DefaultTypeTest()
    //     0x5adc84: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5adc88: ldur            x3, [fp, #-8]
    // 0x5adc8c: LoadField: r4 = r3->field_f
    //     0x5adc8c: ldur            w4, [x3, #0xf]
    // 0x5adc90: DecompressPointer r4
    //     0x5adc90: add             x4, x4, HEAP, lsl #32
    // 0x5adc94: stur            x4, [fp, #-0x18]
    // 0x5adc98: cmp             w4, NULL
    // 0x5adc9c: b.ne            #0x5adccc
    // 0x5adca0: ldr             x5, [fp, #0x18]
    // 0x5adca4: LoadField: r0 = r3->field_13
    //     0x5adca4: ldur            w0, [x3, #0x13]
    // 0x5adca8: DecompressPointer r0
    //     0x5adca8: add             x0, x0, HEAP, lsl #32
    // 0x5adcac: StoreField: r5->field_67 = r0
    //     0x5adcac: stur            w0, [x5, #0x67]
    //     0x5adcb0: ldurb           w16, [x5, #-1]
    //     0x5adcb4: ldurb           w17, [x0, #-1]
    //     0x5adcb8: and             x16, x17, x16, lsr #2
    //     0x5adcbc: tst             x16, HEAP, lsr #32
    //     0x5adcc0: b.eq            #0x5adcc8
    //     0x5adcc4: bl              #0xd682ec
    // 0x5adcc8: b               #0x5add90
    // 0x5adccc: ldr             x5, [fp, #0x18]
    // 0x5adcd0: LoadField: r6 = r4->field_17
    //     0x5adcd0: ldur            w6, [x4, #0x17]
    // 0x5adcd4: DecompressPointer r6
    //     0x5adcd4: add             x6, x6, HEAP, lsl #32
    // 0x5adcd8: stur            x6, [fp, #-0x10]
    // 0x5adcdc: cmp             w6, NULL
    // 0x5adce0: b.eq            #0x5adef0
    // 0x5adce4: mov             x0, x6
    // 0x5adce8: r2 = Null
    //     0x5adce8: mov             x2, NULL
    // 0x5adcec: r1 = Null
    //     0x5adcec: mov             x1, NULL
    // 0x5adcf0: r4 = LoadClassIdInstr(r0)
    //     0x5adcf0: ldur            x4, [x0, #-1]
    //     0x5adcf4: ubfx            x4, x4, #0xc, #0x14
    // 0x5adcf8: cmp             x4, #0x809
    // 0x5adcfc: b.eq            #0x5add14
    // 0x5add00: r8 = FlexParentData<RenderBox>
    //     0x5add00: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x5add04: ldr             x8, [x8, #0x248]
    // 0x5add08: r3 = Null
    //     0x5add08: add             x3, PP, #0x22, lsl #12  ; [pp+0x22828] Null
    //     0x5add0c: ldr             x3, [x3, #0x828]
    // 0x5add10: r0 = DefaultTypeTest()
    //     0x5add10: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5add14: ldur            x3, [fp, #-8]
    // 0x5add18: LoadField: r4 = r3->field_13
    //     0x5add18: ldur            w4, [x3, #0x13]
    // 0x5add1c: DecompressPointer r4
    //     0x5add1c: add             x4, x4, HEAP, lsl #32
    // 0x5add20: ldur            x5, [fp, #-0x10]
    // 0x5add24: stur            x4, [fp, #-0x20]
    // 0x5add28: LoadField: r2 = r5->field_b
    //     0x5add28: ldur            w2, [x5, #0xb]
    // 0x5add2c: DecompressPointer r2
    //     0x5add2c: add             x2, x2, HEAP, lsl #32
    // 0x5add30: mov             x0, x4
    // 0x5add34: r1 = Null
    //     0x5add34: mov             x1, NULL
    // 0x5add38: cmp             w0, NULL
    // 0x5add3c: b.eq            #0x5add68
    // 0x5add40: cmp             w2, NULL
    // 0x5add44: b.eq            #0x5add68
    // 0x5add48: LoadField: r4 = r2->field_17
    //     0x5add48: ldur            w4, [x2, #0x17]
    // 0x5add4c: DecompressPointer r4
    //     0x5add4c: add             x4, x4, HEAP, lsl #32
    // 0x5add50: r8 = X0? bound RenderObject
    //     0x5add50: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5add54: ldr             x8, [x8, #0x6e8]
    // 0x5add58: LoadField: r9 = r4->field_7
    //     0x5add58: ldur            x9, [x4, #7]
    // 0x5add5c: r3 = Null
    //     0x5add5c: add             x3, PP, #0x22, lsl #12  ; [pp+0x22838] Null
    //     0x5add60: ldr             x3, [x3, #0x838]
    // 0x5add64: blr             x9
    // 0x5add68: ldur            x0, [fp, #-0x20]
    // 0x5add6c: ldur            x1, [fp, #-0x10]
    // 0x5add70: StoreField: r1->field_13 = r0
    //     0x5add70: stur            w0, [x1, #0x13]
    //     0x5add74: ldurb           w16, [x1, #-1]
    //     0x5add78: ldurb           w17, [x0, #-1]
    //     0x5add7c: and             x16, x17, x16, lsr #2
    //     0x5add80: tst             x16, HEAP, lsr #32
    //     0x5add84: b.eq            #0x5add8c
    //     0x5add88: bl              #0xd6826c
    // 0x5add8c: ldur            x3, [fp, #-8]
    // 0x5add90: LoadField: r0 = r3->field_13
    //     0x5add90: ldur            w0, [x3, #0x13]
    // 0x5add94: DecompressPointer r0
    //     0x5add94: add             x0, x0, HEAP, lsl #32
    // 0x5add98: cmp             w0, NULL
    // 0x5add9c: b.ne            #0x5addc8
    // 0x5adda0: ldr             x4, [fp, #0x18]
    // 0x5adda4: ldur            x0, [fp, #-0x18]
    // 0x5adda8: StoreField: r4->field_6b = r0
    //     0x5adda8: stur            w0, [x4, #0x6b]
    //     0x5addac: ldurb           w16, [x4, #-1]
    //     0x5addb0: ldurb           w17, [x0, #-1]
    //     0x5addb4: and             x16, x17, x16, lsr #2
    //     0x5addb8: tst             x16, HEAP, lsr #32
    //     0x5addbc: b.eq            #0x5addc4
    //     0x5addc0: bl              #0xd682cc
    // 0x5addc4: b               #0x5ade80
    // 0x5addc8: ldr             x4, [fp, #0x18]
    // 0x5addcc: LoadField: r5 = r0->field_17
    //     0x5addcc: ldur            w5, [x0, #0x17]
    // 0x5addd0: DecompressPointer r5
    //     0x5addd0: add             x5, x5, HEAP, lsl #32
    // 0x5addd4: stur            x5, [fp, #-0x10]
    // 0x5addd8: cmp             w5, NULL
    // 0x5adddc: b.eq            #0x5adef4
    // 0x5adde0: mov             x0, x5
    // 0x5adde4: r2 = Null
    //     0x5adde4: mov             x2, NULL
    // 0x5adde8: r1 = Null
    //     0x5adde8: mov             x1, NULL
    // 0x5addec: r4 = LoadClassIdInstr(r0)
    //     0x5addec: ldur            x4, [x0, #-1]
    //     0x5addf0: ubfx            x4, x4, #0xc, #0x14
    // 0x5addf4: cmp             x4, #0x809
    // 0x5addf8: b.eq            #0x5ade10
    // 0x5addfc: r8 = FlexParentData<RenderBox>
    //     0x5addfc: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x5ade00: ldr             x8, [x8, #0x248]
    // 0x5ade04: r3 = Null
    //     0x5ade04: add             x3, PP, #0x22, lsl #12  ; [pp+0x22848] Null
    //     0x5ade08: ldr             x3, [x3, #0x848]
    // 0x5ade0c: r0 = DefaultTypeTest()
    //     0x5ade0c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5ade10: ldur            x3, [fp, #-0x10]
    // 0x5ade14: LoadField: r2 = r3->field_b
    //     0x5ade14: ldur            w2, [x3, #0xb]
    // 0x5ade18: DecompressPointer r2
    //     0x5ade18: add             x2, x2, HEAP, lsl #32
    // 0x5ade1c: ldur            x0, [fp, #-0x18]
    // 0x5ade20: r1 = Null
    //     0x5ade20: mov             x1, NULL
    // 0x5ade24: cmp             w0, NULL
    // 0x5ade28: b.eq            #0x5ade54
    // 0x5ade2c: cmp             w2, NULL
    // 0x5ade30: b.eq            #0x5ade54
    // 0x5ade34: LoadField: r4 = r2->field_17
    //     0x5ade34: ldur            w4, [x2, #0x17]
    // 0x5ade38: DecompressPointer r4
    //     0x5ade38: add             x4, x4, HEAP, lsl #32
    // 0x5ade3c: r8 = X0? bound RenderObject
    //     0x5ade3c: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5ade40: ldr             x8, [x8, #0x6e8]
    // 0x5ade44: LoadField: r9 = r4->field_7
    //     0x5ade44: ldur            x9, [x4, #7]
    // 0x5ade48: r3 = Null
    //     0x5ade48: add             x3, PP, #0x22, lsl #12  ; [pp+0x22858] Null
    //     0x5ade4c: ldr             x3, [x3, #0x858]
    // 0x5ade50: blr             x9
    // 0x5ade54: ldur            x0, [fp, #-0x18]
    // 0x5ade58: ldur            x1, [fp, #-0x10]
    // 0x5ade5c: StoreField: r1->field_f = r0
    //     0x5ade5c: stur            w0, [x1, #0xf]
    //     0x5ade60: ldurb           w16, [x1, #-1]
    //     0x5ade64: ldurb           w17, [x0, #-1]
    //     0x5ade68: and             x16, x17, x16, lsr #2
    //     0x5ade6c: tst             x16, HEAP, lsr #32
    //     0x5ade70: b.eq            #0x5ade78
    //     0x5ade74: bl              #0xd6826c
    // 0x5ade78: ldr             x4, [fp, #0x18]
    // 0x5ade7c: ldur            x3, [fp, #-8]
    // 0x5ade80: LoadField: r2 = r3->field_b
    //     0x5ade80: ldur            w2, [x3, #0xb]
    // 0x5ade84: DecompressPointer r2
    //     0x5ade84: add             x2, x2, HEAP, lsl #32
    // 0x5ade88: r0 = Null
    //     0x5ade88: mov             x0, NULL
    // 0x5ade8c: r1 = Null
    //     0x5ade8c: mov             x1, NULL
    // 0x5ade90: cmp             w0, NULL
    // 0x5ade94: b.eq            #0x5adec0
    // 0x5ade98: cmp             w2, NULL
    // 0x5ade9c: b.eq            #0x5adec0
    // 0x5adea0: LoadField: r4 = r2->field_17
    //     0x5adea0: ldur            w4, [x2, #0x17]
    // 0x5adea4: DecompressPointer r4
    //     0x5adea4: add             x4, x4, HEAP, lsl #32
    // 0x5adea8: r8 = X0? bound RenderObject
    //     0x5adea8: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5adeac: ldr             x8, [x8, #0x6e8]
    // 0x5adeb0: LoadField: r9 = r4->field_7
    //     0x5adeb0: ldur            x9, [x4, #7]
    // 0x5adeb4: r3 = Null
    //     0x5adeb4: add             x3, PP, #0x22, lsl #12  ; [pp+0x22868] Null
    //     0x5adeb8: ldr             x3, [x3, #0x868]
    // 0x5adebc: blr             x9
    // 0x5adec0: ldur            x1, [fp, #-8]
    // 0x5adec4: StoreField: r1->field_f = rNULL
    //     0x5adec4: stur            NULL, [x1, #0xf]
    // 0x5adec8: StoreField: r1->field_13 = rNULL
    //     0x5adec8: stur            NULL, [x1, #0x13]
    // 0x5adecc: ldr             x1, [fp, #0x18]
    // 0x5aded0: LoadField: r2 = r1->field_5f
    //     0x5aded0: ldur            x2, [x1, #0x5f]
    // 0x5aded4: sub             x3, x2, #1
    // 0x5aded8: StoreField: r1->field_5f = r3
    //     0x5aded8: stur            x3, [x1, #0x5f]
    // 0x5adedc: r0 = Null
    //     0x5adedc: mov             x0, NULL
    // 0x5adee0: LeaveFrame
    //     0x5adee0: mov             SP, fp
    //     0x5adee4: ldp             fp, lr, [SP], #0x10
    // 0x5adee8: ret
    //     0x5adee8: ret             
    // 0x5adeec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5adeec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5adef0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5adef0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5adef4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5adef4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ remove(/* No info */) {
    // ** addr: 0x5e92d0, size: 0x90
    // 0x5e92d0: EnterFrame
    //     0x5e92d0: stp             fp, lr, [SP, #-0x10]!
    //     0x5e92d4: mov             fp, SP
    // 0x5e92d8: CheckStackOverflow
    //     0x5e92d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e92dc: cmp             SP, x16
    //     0x5e92e0: b.ls            #0x5e9358
    // 0x5e92e4: ldr             x0, [fp, #0x10]
    // 0x5e92e8: r2 = Null
    //     0x5e92e8: mov             x2, NULL
    // 0x5e92ec: r1 = Null
    //     0x5e92ec: mov             x1, NULL
    // 0x5e92f0: r4 = 59
    //     0x5e92f0: mov             x4, #0x3b
    // 0x5e92f4: branchIfSmi(r0, 0x5e9300)
    //     0x5e92f4: tbz             w0, #0, #0x5e9300
    // 0x5e92f8: r4 = LoadClassIdInstr(r0)
    //     0x5e92f8: ldur            x4, [x0, #-1]
    //     0x5e92fc: ubfx            x4, x4, #0xc, #0x14
    // 0x5e9300: sub             x4, x4, #0x965
    // 0x5e9304: cmp             x4, #0x8b
    // 0x5e9308: b.ls            #0x5e9320
    // 0x5e930c: r8 = RenderBox
    //     0x5e930c: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x5e9310: ldr             x8, [x8, #0xfa0]
    // 0x5e9314: r3 = Null
    //     0x5e9314: add             x3, PP, #0x22, lsl #12  ; [pp+0x22878] Null
    //     0x5e9318: ldr             x3, [x3, #0x878]
    // 0x5e931c: r0 = RenderBox()
    //     0x5e931c: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x5e9320: ldr             x16, [fp, #0x18]
    // 0x5e9324: ldr             lr, [fp, #0x10]
    // 0x5e9328: stp             lr, x16, [SP, #-0x10]!
    // 0x5e932c: r0 = _removeFromChildList()
    //     0x5e932c: bl              #0x5adc34  ; [package:flutter/src/rendering/flex.dart] _RenderFlex&RenderBox&ContainerRenderObjectMixin::_removeFromChildList
    // 0x5e9330: add             SP, SP, #0x10
    // 0x5e9334: ldr             x16, [fp, #0x18]
    // 0x5e9338: ldr             lr, [fp, #0x10]
    // 0x5e933c: stp             lr, x16, [SP, #-0x10]!
    // 0x5e9340: r0 = dropChild()
    //     0x5e9340: bl              #0x5e5aec  ; [package:flutter/src/rendering/object.dart] RenderObject::dropChild
    // 0x5e9344: add             SP, SP, #0x10
    // 0x5e9348: r0 = Null
    //     0x5e9348: mov             x0, NULL
    // 0x5e934c: LeaveFrame
    //     0x5e934c: mov             SP, fp
    //     0x5e9350: ldp             fp, lr, [SP], #0x10
    // 0x5e9354: ret
    //     0x5e9354: ret             
    // 0x5e9358: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e9358: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e935c: b               #0x5e92e4
  }
  _ insert(/* No info */) {
    // ** addr: 0x5e93f0, size: 0xd0
    // 0x5e93f0: EnterFrame
    //     0x5e93f0: stp             fp, lr, [SP, #-0x10]!
    //     0x5e93f4: mov             fp, SP
    // 0x5e93f8: CheckStackOverflow
    //     0x5e93f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e93fc: cmp             SP, x16
    //     0x5e9400: b.ls            #0x5e94b8
    // 0x5e9404: ldr             x0, [fp, #0x18]
    // 0x5e9408: r2 = Null
    //     0x5e9408: mov             x2, NULL
    // 0x5e940c: r1 = Null
    //     0x5e940c: mov             x1, NULL
    // 0x5e9410: r4 = 59
    //     0x5e9410: mov             x4, #0x3b
    // 0x5e9414: branchIfSmi(r0, 0x5e9420)
    //     0x5e9414: tbz             w0, #0, #0x5e9420
    // 0x5e9418: r4 = LoadClassIdInstr(r0)
    //     0x5e9418: ldur            x4, [x0, #-1]
    //     0x5e941c: ubfx            x4, x4, #0xc, #0x14
    // 0x5e9420: sub             x4, x4, #0x965
    // 0x5e9424: cmp             x4, #0x8b
    // 0x5e9428: b.ls            #0x5e9440
    // 0x5e942c: r8 = RenderBox
    //     0x5e942c: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x5e9430: ldr             x8, [x8, #0xfa0]
    // 0x5e9434: r3 = Null
    //     0x5e9434: add             x3, PP, #0x22, lsl #12  ; [pp+0x22888] Null
    //     0x5e9438: ldr             x3, [x3, #0x888]
    // 0x5e943c: r0 = RenderBox()
    //     0x5e943c: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x5e9440: ldr             x0, [fp, #0x10]
    // 0x5e9444: r2 = Null
    //     0x5e9444: mov             x2, NULL
    // 0x5e9448: r1 = Null
    //     0x5e9448: mov             x1, NULL
    // 0x5e944c: r4 = 59
    //     0x5e944c: mov             x4, #0x3b
    // 0x5e9450: branchIfSmi(r0, 0x5e945c)
    //     0x5e9450: tbz             w0, #0, #0x5e945c
    // 0x5e9454: r4 = LoadClassIdInstr(r0)
    //     0x5e9454: ldur            x4, [x0, #-1]
    //     0x5e9458: ubfx            x4, x4, #0xc, #0x14
    // 0x5e945c: sub             x4, x4, #0x965
    // 0x5e9460: cmp             x4, #0x8b
    // 0x5e9464: b.ls            #0x5e9478
    // 0x5e9468: r8 = RenderBox?
    //     0x5e9468: ldr             x8, [PP, #0x4de8]  ; [pp+0x4de8] Type: RenderBox?
    // 0x5e946c: r3 = Null
    //     0x5e946c: add             x3, PP, #0x22, lsl #12  ; [pp+0x22898] Null
    //     0x5e9470: ldr             x3, [x3, #0x898]
    // 0x5e9474: r0 = RenderBox?()
    //     0x5e9474: bl              #0x5ad534  ; IsType_RenderBox?_Stub
    // 0x5e9478: ldr             x16, [fp, #0x20]
    // 0x5e947c: ldr             lr, [fp, #0x18]
    // 0x5e9480: stp             lr, x16, [SP, #-0x10]!
    // 0x5e9484: r0 = adoptChild()
    //     0x5e9484: bl              #0x5e61d4  ; [package:flutter/src/rendering/object.dart] RenderObject::adoptChild
    // 0x5e9488: add             SP, SP, #0x10
    // 0x5e948c: ldr             x16, [fp, #0x20]
    // 0x5e9490: ldr             lr, [fp, #0x18]
    // 0x5e9494: stp             lr, x16, [SP, #-0x10]!
    // 0x5e9498: ldr             x16, [fp, #0x10]
    // 0x5e949c: SaveReg r16
    //     0x5e949c: str             x16, [SP, #-8]!
    // 0x5e94a0: r0 = _insertIntoChildList()
    //     0x5e94a0: bl              #0x5ad6d4  ; [package:flutter/src/rendering/flex.dart] _RenderFlex&RenderBox&ContainerRenderObjectMixin::_insertIntoChildList
    // 0x5e94a4: add             SP, SP, #0x18
    // 0x5e94a8: r0 = Null
    //     0x5e94a8: mov             x0, NULL
    // 0x5e94ac: LeaveFrame
    //     0x5e94ac: mov             SP, fp
    //     0x5e94b0: ldp             fp, lr, [SP], #0x10
    // 0x5e94b4: ret
    //     0x5e94b4: ret             
    // 0x5e94b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e94b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e94bc: b               #0x5e9404
  }
  _ visitChildren(/* No info */) {
    // ** addr: 0x6bf5dc, size: 0xd8
    // 0x6bf5dc: EnterFrame
    //     0x6bf5dc: stp             fp, lr, [SP, #-0x10]!
    //     0x6bf5e0: mov             fp, SP
    // 0x6bf5e4: AllocStack(0x10)
    //     0x6bf5e4: sub             SP, SP, #0x10
    // 0x6bf5e8: CheckStackOverflow
    //     0x6bf5e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bf5ec: cmp             SP, x16
    //     0x6bf5f0: b.ls            #0x6bf6a0
    // 0x6bf5f4: ldr             x0, [fp, #0x18]
    // 0x6bf5f8: LoadField: r1 = r0->field_67
    //     0x6bf5f8: ldur            w1, [x0, #0x67]
    // 0x6bf5fc: DecompressPointer r1
    //     0x6bf5fc: add             x1, x1, HEAP, lsl #32
    // 0x6bf600: stur            x1, [fp, #-8]
    // 0x6bf604: CheckStackOverflow
    //     0x6bf604: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bf608: cmp             SP, x16
    //     0x6bf60c: b.ls            #0x6bf6a8
    // 0x6bf610: cmp             w1, NULL
    // 0x6bf614: b.eq            #0x6bf690
    // 0x6bf618: ldr             x16, [fp, #0x10]
    // 0x6bf61c: stp             x1, x16, [SP, #-0x10]!
    // 0x6bf620: ldr             x0, [fp, #0x10]
    // 0x6bf624: ClosureCall
    //     0x6bf624: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6bf628: ldur            x2, [x0, #0x1f]
    //     0x6bf62c: blr             x2
    // 0x6bf630: add             SP, SP, #0x10
    // 0x6bf634: ldur            x0, [fp, #-8]
    // 0x6bf638: LoadField: r3 = r0->field_17
    //     0x6bf638: ldur            w3, [x0, #0x17]
    // 0x6bf63c: DecompressPointer r3
    //     0x6bf63c: add             x3, x3, HEAP, lsl #32
    // 0x6bf640: stur            x3, [fp, #-0x10]
    // 0x6bf644: cmp             w3, NULL
    // 0x6bf648: b.eq            #0x6bf6b0
    // 0x6bf64c: mov             x0, x3
    // 0x6bf650: r2 = Null
    //     0x6bf650: mov             x2, NULL
    // 0x6bf654: r1 = Null
    //     0x6bf654: mov             x1, NULL
    // 0x6bf658: r4 = LoadClassIdInstr(r0)
    //     0x6bf658: ldur            x4, [x0, #-1]
    //     0x6bf65c: ubfx            x4, x4, #0xc, #0x14
    // 0x6bf660: cmp             x4, #0x809
    // 0x6bf664: b.eq            #0x6bf67c
    // 0x6bf668: r8 = FlexParentData<RenderBox>
    //     0x6bf668: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x6bf66c: ldr             x8, [x8, #0x248]
    // 0x6bf670: r3 = Null
    //     0x6bf670: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d328] Null
    //     0x6bf674: ldr             x3, [x3, #0x328]
    // 0x6bf678: r0 = DefaultTypeTest()
    //     0x6bf678: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6bf67c: ldur            x1, [fp, #-0x10]
    // 0x6bf680: LoadField: r0 = r1->field_13
    //     0x6bf680: ldur            w0, [x1, #0x13]
    // 0x6bf684: DecompressPointer r0
    //     0x6bf684: add             x0, x0, HEAP, lsl #32
    // 0x6bf688: mov             x1, x0
    // 0x6bf68c: b               #0x6bf600
    // 0x6bf690: r0 = Null
    //     0x6bf690: mov             x0, NULL
    // 0x6bf694: LeaveFrame
    //     0x6bf694: mov             SP, fp
    //     0x6bf698: ldp             fp, lr, [SP], #0x10
    // 0x6bf69c: ret
    //     0x6bf69c: ret             
    // 0x6bf6a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bf6a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bf6a4: b               #0x6bf5f4
    // 0x6bf6a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bf6a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bf6ac: b               #0x6bf610
    // 0x6bf6b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6bf6b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ redepthChildren(/* No info */) {
    // ** addr: 0x792888, size: 0xf8
    // 0x792888: EnterFrame
    //     0x792888: stp             fp, lr, [SP, #-0x10]!
    //     0x79288c: mov             fp, SP
    // 0x792890: AllocStack(0x10)
    //     0x792890: sub             SP, SP, #0x10
    // 0x792894: CheckStackOverflow
    //     0x792894: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x792898: cmp             SP, x16
    //     0x79289c: b.ls            #0x79296c
    // 0x7928a0: ldr             x1, [fp, #0x10]
    // 0x7928a4: LoadField: r0 = r1->field_67
    //     0x7928a4: ldur            w0, [x1, #0x67]
    // 0x7928a8: DecompressPointer r0
    //     0x7928a8: add             x0, x0, HEAP, lsl #32
    // 0x7928ac: mov             x2, x0
    // 0x7928b0: stur            x2, [fp, #-8]
    // 0x7928b4: CheckStackOverflow
    //     0x7928b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7928b8: cmp             SP, x16
    //     0x7928bc: b.ls            #0x792974
    // 0x7928c0: cmp             w2, NULL
    // 0x7928c4: b.eq            #0x79295c
    // 0x7928c8: LoadField: r0 = r2->field_7
    //     0x7928c8: ldur            x0, [x2, #7]
    // 0x7928cc: LoadField: r3 = r1->field_7
    //     0x7928cc: ldur            x3, [x1, #7]
    // 0x7928d0: cmp             x0, x3
    // 0x7928d4: b.gt            #0x792900
    // 0x7928d8: add             x0, x3, #1
    // 0x7928dc: StoreField: r2->field_7 = r0
    //     0x7928dc: stur            x0, [x2, #7]
    // 0x7928e0: r0 = LoadClassIdInstr(r2)
    //     0x7928e0: ldur            x0, [x2, #-1]
    //     0x7928e4: ubfx            x0, x0, #0xc, #0x14
    // 0x7928e8: SaveReg r2
    //     0x7928e8: str             x2, [SP, #-8]!
    // 0x7928ec: r0 = GDT[cid_x0 + 0xbdf1]()
    //     0x7928ec: mov             x17, #0xbdf1
    //     0x7928f0: add             lr, x0, x17
    //     0x7928f4: ldr             lr, [x21, lr, lsl #3]
    //     0x7928f8: blr             lr
    // 0x7928fc: add             SP, SP, #8
    // 0x792900: ldur            x0, [fp, #-8]
    // 0x792904: LoadField: r3 = r0->field_17
    //     0x792904: ldur            w3, [x0, #0x17]
    // 0x792908: DecompressPointer r3
    //     0x792908: add             x3, x3, HEAP, lsl #32
    // 0x79290c: stur            x3, [fp, #-0x10]
    // 0x792910: cmp             w3, NULL
    // 0x792914: b.eq            #0x79297c
    // 0x792918: mov             x0, x3
    // 0x79291c: r2 = Null
    //     0x79291c: mov             x2, NULL
    // 0x792920: r1 = Null
    //     0x792920: mov             x1, NULL
    // 0x792924: r4 = LoadClassIdInstr(r0)
    //     0x792924: ldur            x4, [x0, #-1]
    //     0x792928: ubfx            x4, x4, #0xc, #0x14
    // 0x79292c: cmp             x4, #0x809
    // 0x792930: b.eq            #0x792948
    // 0x792934: r8 = FlexParentData<RenderBox>
    //     0x792934: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x792938: ldr             x8, [x8, #0x248]
    // 0x79293c: r3 = Null
    //     0x79293c: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d338] Null
    //     0x792940: ldr             x3, [x3, #0x338]
    // 0x792944: r0 = DefaultTypeTest()
    //     0x792944: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x792948: ldur            x1, [fp, #-0x10]
    // 0x79294c: LoadField: r2 = r1->field_13
    //     0x79294c: ldur            w2, [x1, #0x13]
    // 0x792950: DecompressPointer r2
    //     0x792950: add             x2, x2, HEAP, lsl #32
    // 0x792954: ldr             x1, [fp, #0x10]
    // 0x792958: b               #0x7928b0
    // 0x79295c: r0 = Null
    //     0x79295c: mov             x0, NULL
    // 0x792960: LeaveFrame
    //     0x792960: mov             SP, fp
    //     0x792964: ldp             fp, lr, [SP], #0x10
    // 0x792968: ret
    //     0x792968: ret             
    // 0x79296c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79296c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x792970: b               #0x7928a0
    // 0x792974: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x792974: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x792978: b               #0x7928c0
    // 0x79297c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79297c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bc43c, size: 0x128
    // 0x9bc43c: EnterFrame
    //     0x9bc43c: stp             fp, lr, [SP, #-0x10]!
    //     0x9bc440: mov             fp, SP
    // 0x9bc444: AllocStack(0x10)
    //     0x9bc444: sub             SP, SP, #0x10
    // 0x9bc448: CheckStackOverflow
    //     0x9bc448: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bc44c: cmp             SP, x16
    //     0x9bc450: b.ls            #0x9bc550
    // 0x9bc454: ldr             x0, [fp, #0x10]
    // 0x9bc458: r2 = Null
    //     0x9bc458: mov             x2, NULL
    // 0x9bc45c: r1 = Null
    //     0x9bc45c: mov             x1, NULL
    // 0x9bc460: r4 = 59
    //     0x9bc460: mov             x4, #0x3b
    // 0x9bc464: branchIfSmi(r0, 0x9bc470)
    //     0x9bc464: tbz             w0, #0, #0x9bc470
    // 0x9bc468: r4 = LoadClassIdInstr(r0)
    //     0x9bc468: ldur            x4, [x0, #-1]
    //     0x9bc46c: ubfx            x4, x4, #0xc, #0x14
    // 0x9bc470: cmp             x4, #0x7e6
    // 0x9bc474: b.eq            #0x9bc488
    // 0x9bc478: r8 = PipelineOwner
    //     0x9bc478: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9bc47c: r3 = Null
    //     0x9bc47c: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d358] Null
    //     0x9bc480: ldr             x3, [x3, #0x358]
    // 0x9bc484: r0 = DefaultTypeTest()
    //     0x9bc484: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bc488: ldr             x16, [fp, #0x18]
    // 0x9bc48c: ldr             lr, [fp, #0x10]
    // 0x9bc490: stp             lr, x16, [SP, #-0x10]!
    // 0x9bc494: r0 = attach()
    //     0x9bc494: bl              #0x9bf794  ; [package:flutter/src/rendering/object.dart] RenderObject::attach
    // 0x9bc498: add             SP, SP, #0x10
    // 0x9bc49c: ldr             x0, [fp, #0x18]
    // 0x9bc4a0: LoadField: r1 = r0->field_67
    //     0x9bc4a0: ldur            w1, [x0, #0x67]
    // 0x9bc4a4: DecompressPointer r1
    //     0x9bc4a4: add             x1, x1, HEAP, lsl #32
    // 0x9bc4a8: stur            x1, [fp, #-8]
    // 0x9bc4ac: CheckStackOverflow
    //     0x9bc4ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bc4b0: cmp             SP, x16
    //     0x9bc4b4: b.ls            #0x9bc558
    // 0x9bc4b8: cmp             w1, NULL
    // 0x9bc4bc: b.eq            #0x9bc540
    // 0x9bc4c0: r0 = LoadClassIdInstr(r1)
    //     0x9bc4c0: ldur            x0, [x1, #-1]
    //     0x9bc4c4: ubfx            x0, x0, #0xc, #0x14
    // 0x9bc4c8: ldr             x16, [fp, #0x10]
    // 0x9bc4cc: stp             x16, x1, [SP, #-0x10]!
    // 0x9bc4d0: r0 = GDT[cid_x0 + 0xaf1f]()
    //     0x9bc4d0: mov             x17, #0xaf1f
    //     0x9bc4d4: add             lr, x0, x17
    //     0x9bc4d8: ldr             lr, [x21, lr, lsl #3]
    //     0x9bc4dc: blr             lr
    // 0x9bc4e0: add             SP, SP, #0x10
    // 0x9bc4e4: ldur            x0, [fp, #-8]
    // 0x9bc4e8: LoadField: r3 = r0->field_17
    //     0x9bc4e8: ldur            w3, [x0, #0x17]
    // 0x9bc4ec: DecompressPointer r3
    //     0x9bc4ec: add             x3, x3, HEAP, lsl #32
    // 0x9bc4f0: stur            x3, [fp, #-0x10]
    // 0x9bc4f4: cmp             w3, NULL
    // 0x9bc4f8: b.eq            #0x9bc560
    // 0x9bc4fc: mov             x0, x3
    // 0x9bc500: r2 = Null
    //     0x9bc500: mov             x2, NULL
    // 0x9bc504: r1 = Null
    //     0x9bc504: mov             x1, NULL
    // 0x9bc508: r4 = LoadClassIdInstr(r0)
    //     0x9bc508: ldur            x4, [x0, #-1]
    //     0x9bc50c: ubfx            x4, x4, #0xc, #0x14
    // 0x9bc510: cmp             x4, #0x809
    // 0x9bc514: b.eq            #0x9bc52c
    // 0x9bc518: r8 = FlexParentData<RenderBox>
    //     0x9bc518: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x9bc51c: ldr             x8, [x8, #0x248]
    // 0x9bc520: r3 = Null
    //     0x9bc520: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d368] Null
    //     0x9bc524: ldr             x3, [x3, #0x368]
    // 0x9bc528: r0 = DefaultTypeTest()
    //     0x9bc528: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bc52c: ldur            x1, [fp, #-0x10]
    // 0x9bc530: LoadField: r0 = r1->field_13
    //     0x9bc530: ldur            w0, [x1, #0x13]
    // 0x9bc534: DecompressPointer r0
    //     0x9bc534: add             x0, x0, HEAP, lsl #32
    // 0x9bc538: mov             x1, x0
    // 0x9bc53c: b               #0x9bc4a8
    // 0x9bc540: r0 = Null
    //     0x9bc540: mov             x0, NULL
    // 0x9bc544: LeaveFrame
    //     0x9bc544: mov             SP, fp
    //     0x9bc548: ldp             fp, lr, [SP], #0x10
    // 0x9bc54c: ret
    //     0x9bc54c: ret             
    // 0x9bc550: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bc550: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bc554: b               #0x9bc454
    // 0x9bc558: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bc558: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bc55c: b               #0x9bc4b8
    // 0x9bc560: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9bc560: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ detach(/* No info */) {
    // ** addr: 0xa6891c, size: 0xec
    // 0xa6891c: EnterFrame
    //     0xa6891c: stp             fp, lr, [SP, #-0x10]!
    //     0xa68920: mov             fp, SP
    // 0xa68924: AllocStack(0x10)
    //     0xa68924: sub             SP, SP, #0x10
    // 0xa68928: CheckStackOverflow
    //     0xa68928: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6892c: cmp             SP, x16
    //     0xa68930: b.ls            #0xa689f4
    // 0xa68934: ldr             x16, [fp, #0x10]
    // 0xa68938: SaveReg r16
    //     0xa68938: str             x16, [SP, #-8]!
    // 0xa6893c: r0 = detach()
    //     0xa6893c: bl              #0xa6ade0  ; [package:flutter/src/foundation/node.dart] AbstractNode::detach
    // 0xa68940: add             SP, SP, #8
    // 0xa68944: ldr             x0, [fp, #0x10]
    // 0xa68948: LoadField: r1 = r0->field_67
    //     0xa68948: ldur            w1, [x0, #0x67]
    // 0xa6894c: DecompressPointer r1
    //     0xa6894c: add             x1, x1, HEAP, lsl #32
    // 0xa68950: stur            x1, [fp, #-8]
    // 0xa68954: CheckStackOverflow
    //     0xa68954: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa68958: cmp             SP, x16
    //     0xa6895c: b.ls            #0xa689fc
    // 0xa68960: cmp             w1, NULL
    // 0xa68964: b.eq            #0xa689e4
    // 0xa68968: r0 = LoadClassIdInstr(r1)
    //     0xa68968: ldur            x0, [x1, #-1]
    //     0xa6896c: ubfx            x0, x0, #0xc, #0x14
    // 0xa68970: SaveReg r1
    //     0xa68970: str             x1, [SP, #-8]!
    // 0xa68974: r0 = GDT[cid_x0 + 0xa3cc]()
    //     0xa68974: mov             x17, #0xa3cc
    //     0xa68978: add             lr, x0, x17
    //     0xa6897c: ldr             lr, [x21, lr, lsl #3]
    //     0xa68980: blr             lr
    // 0xa68984: add             SP, SP, #8
    // 0xa68988: ldur            x0, [fp, #-8]
    // 0xa6898c: LoadField: r3 = r0->field_17
    //     0xa6898c: ldur            w3, [x0, #0x17]
    // 0xa68990: DecompressPointer r3
    //     0xa68990: add             x3, x3, HEAP, lsl #32
    // 0xa68994: stur            x3, [fp, #-0x10]
    // 0xa68998: cmp             w3, NULL
    // 0xa6899c: b.eq            #0xa68a04
    // 0xa689a0: mov             x0, x3
    // 0xa689a4: r2 = Null
    //     0xa689a4: mov             x2, NULL
    // 0xa689a8: r1 = Null
    //     0xa689a8: mov             x1, NULL
    // 0xa689ac: r4 = LoadClassIdInstr(r0)
    //     0xa689ac: ldur            x4, [x0, #-1]
    //     0xa689b0: ubfx            x4, x4, #0xc, #0x14
    // 0xa689b4: cmp             x4, #0x809
    // 0xa689b8: b.eq            #0xa689d0
    // 0xa689bc: r8 = FlexParentData<RenderBox>
    //     0xa689bc: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0xa689c0: ldr             x8, [x8, #0x248]
    // 0xa689c4: r3 = Null
    //     0xa689c4: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d348] Null
    //     0xa689c8: ldr             x3, [x3, #0x348]
    // 0xa689cc: r0 = DefaultTypeTest()
    //     0xa689cc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa689d0: ldur            x1, [fp, #-0x10]
    // 0xa689d4: LoadField: r0 = r1->field_13
    //     0xa689d4: ldur            w0, [x1, #0x13]
    // 0xa689d8: DecompressPointer r0
    //     0xa689d8: add             x0, x0, HEAP, lsl #32
    // 0xa689dc: mov             x1, x0
    // 0xa689e0: b               #0xa68950
    // 0xa689e4: r0 = Null
    //     0xa689e4: mov             x0, NULL
    // 0xa689e8: LeaveFrame
    //     0xa689e8: mov             SP, fp
    //     0xa689ec: ldp             fp, lr, [SP], #0x10
    // 0xa689f0: ret
    //     0xa689f0: ret             
    // 0xa689f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa689f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa689f8: b               #0xa68934
    // 0xa689fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa689fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa68a00: b               #0xa68960
    // 0xa68a04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa68a04: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2539, size: 0x70, field offset: 0x70
//   transformed mixin,
abstract class _RenderFlex&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin extends _RenderFlex&RenderBox&ContainerRenderObjectMixin
     with RenderBoxContainerDefaultsMixin<X0 bound RenderBox, X1 bound ContainerBoxParentData<X0 bound RenderBox>> {

  _ defaultHitTestChildren(/* No info */) {
    // ** addr: 0x6226c4, size: 0x15c
    // 0x6226c4: EnterFrame
    //     0x6226c4: stp             fp, lr, [SP, #-0x10]!
    //     0x6226c8: mov             fp, SP
    // 0x6226cc: AllocStack(0x20)
    //     0x6226cc: sub             SP, SP, #0x20
    // 0x6226d0: CheckStackOverflow
    //     0x6226d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6226d4: cmp             SP, x16
    //     0x6226d8: b.ls            #0x62280c
    // 0x6226dc: ldr             x0, [fp, #0x20]
    // 0x6226e0: LoadField: r1 = r0->field_6b
    //     0x6226e0: ldur            w1, [x0, #0x6b]
    // 0x6226e4: DecompressPointer r1
    //     0x6226e4: add             x1, x1, HEAP, lsl #32
    // 0x6226e8: mov             x3, x1
    // 0x6226ec: stur            x3, [fp, #-0x10]
    // 0x6226f0: CheckStackOverflow
    //     0x6226f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6226f4: cmp             SP, x16
    //     0x6226f8: b.ls            #0x622814
    // 0x6226fc: cmp             w3, NULL
    // 0x622700: b.eq            #0x6227fc
    // 0x622704: LoadField: r4 = r3->field_17
    //     0x622704: ldur            w4, [x3, #0x17]
    // 0x622708: DecompressPointer r4
    //     0x622708: add             x4, x4, HEAP, lsl #32
    // 0x62270c: stur            x4, [fp, #-8]
    // 0x622710: cmp             w4, NULL
    // 0x622714: b.eq            #0x62281c
    // 0x622718: mov             x0, x4
    // 0x62271c: r2 = Null
    //     0x62271c: mov             x2, NULL
    // 0x622720: r1 = Null
    //     0x622720: mov             x1, NULL
    // 0x622724: r4 = LoadClassIdInstr(r0)
    //     0x622724: ldur            x4, [x0, #-1]
    //     0x622728: ubfx            x4, x4, #0xc, #0x14
    // 0x62272c: cmp             x4, #0x809
    // 0x622730: b.eq            #0x622748
    // 0x622734: r8 = FlexParentData<RenderBox>
    //     0x622734: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x622738: ldr             x8, [x8, #0x248]
    // 0x62273c: r3 = Null
    //     0x62273c: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d260] Null
    //     0x622740: ldr             x3, [x3, #0x260]
    // 0x622744: r0 = DefaultTypeTest()
    //     0x622744: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x622748: ldur            x0, [fp, #-8]
    // 0x62274c: LoadField: r1 = r0->field_7
    //     0x62274c: ldur            w1, [x0, #7]
    // 0x622750: DecompressPointer r1
    //     0x622750: add             x1, x1, HEAP, lsl #32
    // 0x622754: stur            x1, [fp, #-0x18]
    // 0x622758: ldr             x16, [fp, #0x10]
    // 0x62275c: stp             x1, x16, [SP, #-0x10]!
    // 0x622760: r0 = -()
    //     0x622760: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x622764: add             SP, SP, #0x10
    // 0x622768: stur            x0, [fp, #-0x20]
    // 0x62276c: ldur            x16, [fp, #-0x18]
    // 0x622770: SaveReg r16
    //     0x622770: str             x16, [SP, #-8]!
    // 0x622774: r0 = unary-()
    //     0x622774: bl              #0x622a88  ; [dart:ui] Offset::unary-
    // 0x622778: add             SP, SP, #8
    // 0x62277c: ldr             x16, [fp, #0x18]
    // 0x622780: stp             x0, x16, [SP, #-0x10]!
    // 0x622784: r0 = pushOffset()
    //     0x622784: bl              #0x622998  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::pushOffset
    // 0x622788: add             SP, SP, #0x10
    // 0x62278c: ldur            x0, [fp, #-0x10]
    // 0x622790: r1 = LoadClassIdInstr(r0)
    //     0x622790: ldur            x1, [x0, #-1]
    //     0x622794: ubfx            x1, x1, #0xc, #0x14
    // 0x622798: ldr             x16, [fp, #0x18]
    // 0x62279c: stp             x16, x0, [SP, #-0x10]!
    // 0x6227a0: ldur            x16, [fp, #-0x20]
    // 0x6227a4: SaveReg r16
    //     0x6227a4: str             x16, [SP, #-8]!
    // 0x6227a8: mov             x0, x1
    // 0x6227ac: r0 = GDT[cid_x0 + 0xefa2]()
    //     0x6227ac: mov             x17, #0xefa2
    //     0x6227b0: add             lr, x0, x17
    //     0x6227b4: ldr             lr, [x21, lr, lsl #3]
    //     0x6227b8: blr             lr
    // 0x6227bc: add             SP, SP, #0x18
    // 0x6227c0: stur            x0, [fp, #-0x10]
    // 0x6227c4: ldr             x16, [fp, #0x18]
    // 0x6227c8: SaveReg r16
    //     0x6227c8: str             x16, [SP, #-8]!
    // 0x6227cc: r0 = popTransform()
    //     0x6227cc: bl              #0x6228f4  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::popTransform
    // 0x6227d0: add             SP, SP, #8
    // 0x6227d4: ldur            x1, [fp, #-0x10]
    // 0x6227d8: tbnz            w1, #4, #0x6227ec
    // 0x6227dc: r0 = true
    //     0x6227dc: add             x0, NULL, #0x20  ; true
    // 0x6227e0: LeaveFrame
    //     0x6227e0: mov             SP, fp
    //     0x6227e4: ldp             fp, lr, [SP], #0x10
    // 0x6227e8: ret
    //     0x6227e8: ret             
    // 0x6227ec: ldur            x1, [fp, #-8]
    // 0x6227f0: LoadField: r3 = r1->field_f
    //     0x6227f0: ldur            w3, [x1, #0xf]
    // 0x6227f4: DecompressPointer r3
    //     0x6227f4: add             x3, x3, HEAP, lsl #32
    // 0x6227f8: b               #0x6226ec
    // 0x6227fc: r0 = false
    //     0x6227fc: add             x0, NULL, #0x30  ; false
    // 0x622800: LeaveFrame
    //     0x622800: mov             SP, fp
    //     0x622804: ldp             fp, lr, [SP], #0x10
    // 0x622808: ret
    //     0x622808: ret             
    // 0x62280c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62280c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x622810: b               #0x6226dc
    // 0x622814: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x622814: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x622818: b               #0x6226fc
    // 0x62281c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x62281c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ defaultComputeDistanceToFirstActualBaseline(/* No info */) {
    // ** addr: 0x63d4f8, size: 0x13c
    // 0x63d4f8: EnterFrame
    //     0x63d4f8: stp             fp, lr, [SP, #-0x10]!
    //     0x63d4fc: mov             fp, SP
    // 0x63d500: AllocStack(0x10)
    //     0x63d500: sub             SP, SP, #0x10
    // 0x63d504: CheckStackOverflow
    //     0x63d504: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63d508: cmp             SP, x16
    //     0x63d50c: b.ls            #0x63d60c
    // 0x63d510: ldr             x0, [fp, #0x18]
    // 0x63d514: LoadField: r1 = r0->field_67
    //     0x63d514: ldur            w1, [x0, #0x67]
    // 0x63d518: DecompressPointer r1
    //     0x63d518: add             x1, x1, HEAP, lsl #32
    // 0x63d51c: mov             x3, x1
    // 0x63d520: stur            x3, [fp, #-0x10]
    // 0x63d524: CheckStackOverflow
    //     0x63d524: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63d528: cmp             SP, x16
    //     0x63d52c: b.ls            #0x63d614
    // 0x63d530: cmp             w3, NULL
    // 0x63d534: b.eq            #0x63d5fc
    // 0x63d538: LoadField: r4 = r3->field_17
    //     0x63d538: ldur            w4, [x3, #0x17]
    // 0x63d53c: DecompressPointer r4
    //     0x63d53c: add             x4, x4, HEAP, lsl #32
    // 0x63d540: mov             x0, x4
    // 0x63d544: stur            x4, [fp, #-8]
    // 0x63d548: r2 = Null
    //     0x63d548: mov             x2, NULL
    // 0x63d54c: r1 = Null
    //     0x63d54c: mov             x1, NULL
    // 0x63d550: r4 = LoadClassIdInstr(r0)
    //     0x63d550: ldur            x4, [x0, #-1]
    //     0x63d554: ubfx            x4, x4, #0xc, #0x14
    // 0x63d558: cmp             x4, #0x809
    // 0x63d55c: b.eq            #0x63d574
    // 0x63d560: r8 = FlexParentData<RenderBox>?
    //     0x63d560: add             x8, PP, #0x22, lsl #12  ; [pp+0x226e8] Type: FlexParentData<RenderBox>?
    //     0x63d564: ldr             x8, [x8, #0x6e8]
    // 0x63d568: r3 = Null
    //     0x63d568: add             x3, PP, #0x22, lsl #12  ; [pp+0x226f0] Null
    //     0x63d56c: ldr             x3, [x3, #0x6f0]
    // 0x63d570: r0 = DefaultNullableTypeTest()
    //     0x63d570: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x63d574: ldur            x16, [fp, #-0x10]
    // 0x63d578: ldr             lr, [fp, #0x10]
    // 0x63d57c: stp             lr, x16, [SP, #-0x10]!
    // 0x63d580: r0 = getDistanceToActualBaseline()
    //     0x63d580: bl              #0x63d634  ; [package:flutter/src/rendering/box.dart] RenderBox::getDistanceToActualBaseline
    // 0x63d584: add             SP, SP, #0x10
    // 0x63d588: cmp             w0, NULL
    // 0x63d58c: b.eq            #0x63d5e4
    // 0x63d590: ldur            x1, [fp, #-8]
    // 0x63d594: cmp             w1, NULL
    // 0x63d598: b.eq            #0x63d61c
    // 0x63d59c: LoadField: r2 = r1->field_7
    //     0x63d59c: ldur            w2, [x1, #7]
    // 0x63d5a0: DecompressPointer r2
    //     0x63d5a0: add             x2, x2, HEAP, lsl #32
    // 0x63d5a4: LoadField: d0 = r2->field_f
    //     0x63d5a4: ldur            d0, [x2, #0xf]
    // 0x63d5a8: LoadField: d1 = r0->field_7
    //     0x63d5a8: ldur            d1, [x0, #7]
    // 0x63d5ac: fadd            d2, d1, d0
    // 0x63d5b0: r0 = inline_Allocate_Double()
    //     0x63d5b0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x63d5b4: add             x0, x0, #0x10
    //     0x63d5b8: cmp             x2, x0
    //     0x63d5bc: b.ls            #0x63d620
    //     0x63d5c0: str             x0, [THR, #0x60]  ; THR::top
    //     0x63d5c4: sub             x0, x0, #0xf
    //     0x63d5c8: mov             x2, #0xd108
    //     0x63d5cc: movk            x2, #3, lsl #16
    //     0x63d5d0: stur            x2, [x0, #-1]
    // 0x63d5d4: StoreField: r0->field_7 = d2
    //     0x63d5d4: stur            d2, [x0, #7]
    // 0x63d5d8: LeaveFrame
    //     0x63d5d8: mov             SP, fp
    //     0x63d5dc: ldp             fp, lr, [SP], #0x10
    // 0x63d5e0: ret
    //     0x63d5e0: ret             
    // 0x63d5e4: ldur            x1, [fp, #-8]
    // 0x63d5e8: cmp             w1, NULL
    // 0x63d5ec: b.eq            #0x63d630
    // 0x63d5f0: LoadField: r3 = r1->field_13
    //     0x63d5f0: ldur            w3, [x1, #0x13]
    // 0x63d5f4: DecompressPointer r3
    //     0x63d5f4: add             x3, x3, HEAP, lsl #32
    // 0x63d5f8: b               #0x63d520
    // 0x63d5fc: r0 = Null
    //     0x63d5fc: mov             x0, NULL
    // 0x63d600: LeaveFrame
    //     0x63d600: mov             SP, fp
    //     0x63d604: ldp             fp, lr, [SP], #0x10
    // 0x63d608: ret
    //     0x63d608: ret             
    // 0x63d60c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63d60c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63d610: b               #0x63d510
    // 0x63d614: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63d614: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63d618: b               #0x63d530
    // 0x63d61c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63d61c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x63d620: SaveReg d2
    //     0x63d620: str             q2, [SP, #-0x10]!
    // 0x63d624: r0 = AllocateDouble()
    //     0x63d624: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63d628: RestoreReg d2
    //     0x63d628: ldr             q2, [SP], #0x10
    // 0x63d62c: b               #0x63d5d4
    // 0x63d630: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63d630: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ defaultComputeDistanceToHighestActualBaseline(/* No info */) {
    // ** addr: 0x63d800, size: 0x23c
    // 0x63d800: EnterFrame
    //     0x63d800: stp             fp, lr, [SP, #-0x10]!
    //     0x63d804: mov             fp, SP
    // 0x63d808: AllocStack(0x20)
    //     0x63d808: sub             SP, SP, #0x20
    // 0x63d80c: CheckStackOverflow
    //     0x63d80c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63d810: cmp             SP, x16
    //     0x63d814: b.ls            #0x63d9fc
    // 0x63d818: ldr             x0, [fp, #0x18]
    // 0x63d81c: LoadField: r1 = r0->field_67
    //     0x63d81c: ldur            w1, [x0, #0x67]
    // 0x63d820: DecompressPointer r1
    //     0x63d820: add             x1, x1, HEAP, lsl #32
    // 0x63d824: mov             x3, x1
    // 0x63d828: r4 = Null
    //     0x63d828: mov             x4, NULL
    // 0x63d82c: stur            x4, [fp, #-0x10]
    // 0x63d830: stur            x3, [fp, #-0x18]
    // 0x63d834: CheckStackOverflow
    //     0x63d834: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63d838: cmp             SP, x16
    //     0x63d83c: b.ls            #0x63da04
    // 0x63d840: cmp             w3, NULL
    // 0x63d844: b.eq            #0x63d9e8
    // 0x63d848: LoadField: r5 = r3->field_17
    //     0x63d848: ldur            w5, [x3, #0x17]
    // 0x63d84c: DecompressPointer r5
    //     0x63d84c: add             x5, x5, HEAP, lsl #32
    // 0x63d850: stur            x5, [fp, #-8]
    // 0x63d854: cmp             w5, NULL
    // 0x63d858: b.eq            #0x63da0c
    // 0x63d85c: mov             x0, x5
    // 0x63d860: r2 = Null
    //     0x63d860: mov             x2, NULL
    // 0x63d864: r1 = Null
    //     0x63d864: mov             x1, NULL
    // 0x63d868: r4 = LoadClassIdInstr(r0)
    //     0x63d868: ldur            x4, [x0, #-1]
    //     0x63d86c: ubfx            x4, x4, #0xc, #0x14
    // 0x63d870: cmp             x4, #0x809
    // 0x63d874: b.eq            #0x63d88c
    // 0x63d878: r8 = FlexParentData<RenderBox>
    //     0x63d878: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x63d87c: ldr             x8, [x8, #0x248]
    // 0x63d880: r3 = Null
    //     0x63d880: add             x3, PP, #0x22, lsl #12  ; [pp+0x22700] Null
    //     0x63d884: ldr             x3, [x3, #0x700]
    // 0x63d888: r0 = DefaultTypeTest()
    //     0x63d888: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x63d88c: ldur            x16, [fp, #-0x18]
    // 0x63d890: ldr             lr, [fp, #0x10]
    // 0x63d894: stp             lr, x16, [SP, #-0x10]!
    // 0x63d898: r0 = getDistanceToActualBaseline()
    //     0x63d898: bl              #0x63d634  ; [package:flutter/src/rendering/box.dart] RenderBox::getDistanceToActualBaseline
    // 0x63d89c: add             SP, SP, #0x10
    // 0x63d8a0: cmp             w0, NULL
    // 0x63d8a4: b.eq            #0x63d9d0
    // 0x63d8a8: ldur            x1, [fp, #-0x10]
    // 0x63d8ac: ldur            x2, [fp, #-8]
    // 0x63d8b0: LoadField: r3 = r2->field_7
    //     0x63d8b0: ldur            w3, [x2, #7]
    // 0x63d8b4: DecompressPointer r3
    //     0x63d8b4: add             x3, x3, HEAP, lsl #32
    // 0x63d8b8: LoadField: d0 = r3->field_f
    //     0x63d8b8: ldur            d0, [x3, #0xf]
    // 0x63d8bc: LoadField: d1 = r0->field_7
    //     0x63d8bc: ldur            d1, [x0, #7]
    // 0x63d8c0: fadd            d2, d1, d0
    // 0x63d8c4: stur            d2, [fp, #-0x20]
    // 0x63d8c8: cmp             w1, NULL
    // 0x63d8cc: b.eq            #0x63d99c
    // 0x63d8d0: LoadField: d0 = r1->field_7
    //     0x63d8d0: ldur            d0, [x1, #7]
    // 0x63d8d4: fcmp            d0, d2
    // 0x63d8d8: b.vs            #0x63d8e8
    // 0x63d8dc: b.le            #0x63d8e8
    // 0x63d8e0: mov             v1.16b, v2.16b
    // 0x63d8e4: b               #0x63d994
    // 0x63d8e8: fcmp            d0, d2
    // 0x63d8ec: b.vs            #0x63d900
    // 0x63d8f0: b.ge            #0x63d900
    // 0x63d8f4: LoadField: d0 = r1->field_7
    //     0x63d8f4: ldur            d0, [x1, #7]
    // 0x63d8f8: mov             v1.16b, v0.16b
    // 0x63d8fc: b               #0x63d994
    // 0x63d900: d1 = 0.000000
    //     0x63d900: eor             v1.16b, v1.16b, v1.16b
    // 0x63d904: fcmp            d0, d1
    // 0x63d908: b.vs            #0x63d910
    // 0x63d90c: b.eq            #0x63d918
    // 0x63d910: r0 = false
    //     0x63d910: add             x0, NULL, #0x30  ; false
    // 0x63d914: b               #0x63d91c
    // 0x63d918: r0 = true
    //     0x63d918: add             x0, NULL, #0x20  ; true
    // 0x63d91c: tbnz            w0, #4, #0x63d934
    // 0x63d920: fadd            d3, d0, d2
    // 0x63d924: fmul            d4, d3, d0
    // 0x63d928: fmul            d0, d4, d2
    // 0x63d92c: mov             v1.16b, v0.16b
    // 0x63d930: b               #0x63d994
    // 0x63d934: tbnz            w0, #4, #0x63d978
    // 0x63d938: r0 = inline_Allocate_Double()
    //     0x63d938: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x63d93c: add             x0, x0, #0x10
    //     0x63d940: cmp             x3, x0
    //     0x63d944: b.ls            #0x63da10
    //     0x63d948: str             x0, [THR, #0x60]  ; THR::top
    //     0x63d94c: sub             x0, x0, #0xf
    //     0x63d950: mov             x3, #0xd108
    //     0x63d954: movk            x3, #3, lsl #16
    //     0x63d958: stur            x3, [x0, #-1]
    // 0x63d95c: StoreField: r0->field_7 = d2
    //     0x63d95c: stur            d2, [x0, #7]
    // 0x63d960: SaveReg r0
    //     0x63d960: str             x0, [SP, #-8]!
    // 0x63d964: r0 = isNegative()
    //     0x63d964: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x63d968: add             SP, SP, #8
    // 0x63d96c: tbnz            w0, #4, #0x63d978
    // 0x63d970: ldur            d0, [fp, #-0x20]
    // 0x63d974: b               #0x63d984
    // 0x63d978: ldur            d0, [fp, #-0x20]
    // 0x63d97c: fcmp            d0, d0
    // 0x63d980: b.vc            #0x63d98c
    // 0x63d984: mov             v1.16b, v0.16b
    // 0x63d988: b               #0x63d994
    // 0x63d98c: ldur            x1, [fp, #-0x10]
    // 0x63d990: LoadField: d1 = r1->field_7
    //     0x63d990: ldur            d1, [x1, #7]
    // 0x63d994: mov             v0.16b, v1.16b
    // 0x63d998: b               #0x63d9a0
    // 0x63d99c: mov             v0.16b, v2.16b
    // 0x63d9a0: r2 = inline_Allocate_Double()
    //     0x63d9a0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x63d9a4: add             x2, x2, #0x10
    //     0x63d9a8: cmp             x3, x2
    //     0x63d9ac: b.ls            #0x63da28
    //     0x63d9b0: str             x2, [THR, #0x60]  ; THR::top
    //     0x63d9b4: sub             x2, x2, #0xf
    //     0x63d9b8: mov             x3, #0xd108
    //     0x63d9bc: movk            x3, #3, lsl #16
    //     0x63d9c0: stur            x3, [x2, #-1]
    // 0x63d9c4: StoreField: r2->field_7 = d0
    //     0x63d9c4: stur            d0, [x2, #7]
    // 0x63d9c8: mov             x4, x2
    // 0x63d9cc: b               #0x63d9d8
    // 0x63d9d0: ldur            x1, [fp, #-0x10]
    // 0x63d9d4: mov             x4, x1
    // 0x63d9d8: ldur            x2, [fp, #-8]
    // 0x63d9dc: LoadField: r3 = r2->field_13
    //     0x63d9dc: ldur            w3, [x2, #0x13]
    // 0x63d9e0: DecompressPointer r3
    //     0x63d9e0: add             x3, x3, HEAP, lsl #32
    // 0x63d9e4: b               #0x63d82c
    // 0x63d9e8: mov             x1, x4
    // 0x63d9ec: mov             x0, x1
    // 0x63d9f0: LeaveFrame
    //     0x63d9f0: mov             SP, fp
    //     0x63d9f4: ldp             fp, lr, [SP], #0x10
    // 0x63d9f8: ret
    //     0x63d9f8: ret             
    // 0x63d9fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63d9fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63da00: b               #0x63d818
    // 0x63da04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63da04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63da08: b               #0x63d840
    // 0x63da0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63da0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x63da10: stp             q1, q2, [SP, #-0x20]!
    // 0x63da14: stp             x1, x2, [SP, #-0x10]!
    // 0x63da18: r0 = AllocateDouble()
    //     0x63da18: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63da1c: ldp             x1, x2, [SP], #0x10
    // 0x63da20: ldp             q1, q2, [SP], #0x20
    // 0x63da24: b               #0x63d95c
    // 0x63da28: SaveReg d0
    //     0x63da28: str             q0, [SP, #-0x10]!
    // 0x63da2c: r0 = AllocateDouble()
    //     0x63da2c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63da30: mov             x2, x0
    // 0x63da34: RestoreReg d0
    //     0x63da34: ldr             q0, [SP], #0x10
    // 0x63da38: b               #0x63d9c4
  }
  _ defaultPaint(/* No info */) {
    // ** addr: 0x65bf44, size: 0x12c
    // 0x65bf44: EnterFrame
    //     0x65bf44: stp             fp, lr, [SP, #-0x10]!
    //     0x65bf48: mov             fp, SP
    // 0x65bf4c: AllocStack(0x30)
    //     0x65bf4c: sub             SP, SP, #0x30
    // 0x65bf50: CheckStackOverflow
    //     0x65bf50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65bf54: cmp             SP, x16
    //     0x65bf58: b.ls            #0x65c05c
    // 0x65bf5c: ldr             x0, [fp, #0x20]
    // 0x65bf60: LoadField: r1 = r0->field_67
    //     0x65bf60: ldur            w1, [x0, #0x67]
    // 0x65bf64: DecompressPointer r1
    //     0x65bf64: add             x1, x1, HEAP, lsl #32
    // 0x65bf68: ldr             x0, [fp, #0x10]
    // 0x65bf6c: LoadField: d0 = r0->field_7
    //     0x65bf6c: ldur            d0, [x0, #7]
    // 0x65bf70: stur            d0, [fp, #-0x20]
    // 0x65bf74: LoadField: d1 = r0->field_f
    //     0x65bf74: ldur            d1, [x0, #0xf]
    // 0x65bf78: stur            d1, [fp, #-0x18]
    // 0x65bf7c: mov             x3, x1
    // 0x65bf80: stur            x3, [fp, #-0x10]
    // 0x65bf84: CheckStackOverflow
    //     0x65bf84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65bf88: cmp             SP, x16
    //     0x65bf8c: b.ls            #0x65c064
    // 0x65bf90: cmp             w3, NULL
    // 0x65bf94: b.eq            #0x65c04c
    // 0x65bf98: LoadField: r4 = r3->field_17
    //     0x65bf98: ldur            w4, [x3, #0x17]
    // 0x65bf9c: DecompressPointer r4
    //     0x65bf9c: add             x4, x4, HEAP, lsl #32
    // 0x65bfa0: stur            x4, [fp, #-8]
    // 0x65bfa4: cmp             w4, NULL
    // 0x65bfa8: b.eq            #0x65c06c
    // 0x65bfac: mov             x0, x4
    // 0x65bfb0: r2 = Null
    //     0x65bfb0: mov             x2, NULL
    // 0x65bfb4: r1 = Null
    //     0x65bfb4: mov             x1, NULL
    // 0x65bfb8: r4 = LoadClassIdInstr(r0)
    //     0x65bfb8: ldur            x4, [x0, #-1]
    //     0x65bfbc: ubfx            x4, x4, #0xc, #0x14
    // 0x65bfc0: cmp             x4, #0x809
    // 0x65bfc4: b.eq            #0x65bfdc
    // 0x65bfc8: r8 = FlexParentData<RenderBox>
    //     0x65bfc8: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x65bfcc: ldr             x8, [x8, #0x248]
    // 0x65bfd0: r3 = Null
    //     0x65bfd0: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d250] Null
    //     0x65bfd4: ldr             x3, [x3, #0x250]
    // 0x65bfd8: r0 = DefaultTypeTest()
    //     0x65bfd8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x65bfdc: ldur            x0, [fp, #-8]
    // 0x65bfe0: LoadField: r1 = r0->field_7
    //     0x65bfe0: ldur            w1, [x0, #7]
    // 0x65bfe4: DecompressPointer r1
    //     0x65bfe4: add             x1, x1, HEAP, lsl #32
    // 0x65bfe8: LoadField: d0 = r1->field_7
    //     0x65bfe8: ldur            d0, [x1, #7]
    // 0x65bfec: ldur            d1, [fp, #-0x20]
    // 0x65bff0: fadd            d2, d0, d1
    // 0x65bff4: stur            d2, [fp, #-0x30]
    // 0x65bff8: LoadField: d0 = r1->field_f
    //     0x65bff8: ldur            d0, [x1, #0xf]
    // 0x65bffc: ldur            d3, [fp, #-0x18]
    // 0x65c000: fadd            d4, d0, d3
    // 0x65c004: stur            d4, [fp, #-0x28]
    // 0x65c008: r0 = Offset()
    //     0x65c008: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x65c00c: ldur            d0, [fp, #-0x30]
    // 0x65c010: StoreField: r0->field_7 = d0
    //     0x65c010: stur            d0, [x0, #7]
    // 0x65c014: ldur            d0, [fp, #-0x28]
    // 0x65c018: StoreField: r0->field_f = d0
    //     0x65c018: stur            d0, [x0, #0xf]
    // 0x65c01c: ldr             x16, [fp, #0x18]
    // 0x65c020: ldur            lr, [fp, #-0x10]
    // 0x65c024: stp             lr, x16, [SP, #-0x10]!
    // 0x65c028: SaveReg r0
    //     0x65c028: str             x0, [SP, #-8]!
    // 0x65c02c: r0 = paintChild()
    //     0x65c02c: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x65c030: add             SP, SP, #0x18
    // 0x65c034: ldur            x1, [fp, #-8]
    // 0x65c038: LoadField: r3 = r1->field_13
    //     0x65c038: ldur            w3, [x1, #0x13]
    // 0x65c03c: DecompressPointer r3
    //     0x65c03c: add             x3, x3, HEAP, lsl #32
    // 0x65c040: ldur            d0, [fp, #-0x20]
    // 0x65c044: ldur            d1, [fp, #-0x18]
    // 0x65c048: b               #0x65bf80
    // 0x65c04c: r0 = Null
    //     0x65c04c: mov             x0, NULL
    // 0x65c050: LeaveFrame
    //     0x65c050: mov             SP, fp
    //     0x65c054: ldp             fp, lr, [SP], #0x10
    // 0x65c058: ret
    //     0x65c058: ret             
    // 0x65c05c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65c05c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65c060: b               #0x65bf5c
    // 0x65c064: r0 = StackOverflowSharedWithFPURegs()
    //     0x65c064: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x65c068: b               #0x65bf90
    // 0x65c06c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x65c06c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] void defaultPaint(dynamic, PaintingContext, Offset) {
    // ** addr: 0x65c070, size: 0x54
    // 0x65c070: EnterFrame
    //     0x65c070: stp             fp, lr, [SP, #-0x10]!
    //     0x65c074: mov             fp, SP
    // 0x65c078: ldr             x0, [fp, #0x20]
    // 0x65c07c: LoadField: r1 = r0->field_17
    //     0x65c07c: ldur            w1, [x0, #0x17]
    // 0x65c080: DecompressPointer r1
    //     0x65c080: add             x1, x1, HEAP, lsl #32
    // 0x65c084: CheckStackOverflow
    //     0x65c084: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65c088: cmp             SP, x16
    //     0x65c08c: b.ls            #0x65c0bc
    // 0x65c090: LoadField: r0 = r1->field_f
    //     0x65c090: ldur            w0, [x1, #0xf]
    // 0x65c094: DecompressPointer r0
    //     0x65c094: add             x0, x0, HEAP, lsl #32
    // 0x65c098: ldr             x16, [fp, #0x18]
    // 0x65c09c: stp             x16, x0, [SP, #-0x10]!
    // 0x65c0a0: ldr             x16, [fp, #0x10]
    // 0x65c0a4: SaveReg r16
    //     0x65c0a4: str             x16, [SP, #-8]!
    // 0x65c0a8: r0 = defaultPaint()
    //     0x65c0a8: bl              #0x65bf44  ; [package:flutter/src/rendering/flex.dart] _RenderFlex&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultPaint
    // 0x65c0ac: add             SP, SP, #0x18
    // 0x65c0b0: LeaveFrame
    //     0x65c0b0: mov             SP, fp
    //     0x65c0b4: ldp             fp, lr, [SP], #0x10
    // 0x65c0b8: ret
    //     0x65c0b8: ret             
    // 0x65c0bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65c0bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65c0c0: b               #0x65c090
  }
}

// class id: 2540, size: 0x74, field offset: 0x70
//   transformed mixin,
abstract class _RenderFlex&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin&DebugOverflowIndicatorMixin extends _RenderFlex&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin
     with DebugOverflowIndicatorMixin {

  _ dispose(/* No info */) {
    // ** addr: 0x652540, size: 0x140
    // 0x652540: EnterFrame
    //     0x652540: stp             fp, lr, [SP, #-0x10]!
    //     0x652544: mov             fp, SP
    // 0x652548: AllocStack(0x28)
    //     0x652548: sub             SP, SP, #0x28
    // 0x65254c: CheckStackOverflow
    //     0x65254c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x652550: cmp             SP, x16
    //     0x652554: b.ls            #0x652670
    // 0x652558: ldr             x3, [fp, #0x10]
    // 0x65255c: LoadField: r4 = r3->field_6f
    //     0x65255c: ldur            w4, [x3, #0x6f]
    // 0x652560: DecompressPointer r4
    //     0x652560: add             x4, x4, HEAP, lsl #32
    // 0x652564: stur            x4, [fp, #-0x28]
    // 0x652568: LoadField: r5 = r4->field_7
    //     0x652568: ldur            w5, [x4, #7]
    // 0x65256c: DecompressPointer r5
    //     0x65256c: add             x5, x5, HEAP, lsl #32
    // 0x652570: stur            x5, [fp, #-0x20]
    // 0x652574: LoadField: r0 = r4->field_b
    //     0x652574: ldur            w0, [x4, #0xb]
    // 0x652578: DecompressPointer r0
    //     0x652578: add             x0, x0, HEAP, lsl #32
    // 0x65257c: r6 = LoadInt32Instr(r0)
    //     0x65257c: sbfx            x6, x0, #1, #0x1f
    // 0x652580: stur            x6, [fp, #-0x18]
    // 0x652584: r0 = 0
    //     0x652584: mov             x0, #0
    // 0x652588: CheckStackOverflow
    //     0x652588: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65258c: cmp             SP, x16
    //     0x652590: b.ls            #0x652678
    // 0x652594: cmp             x0, x6
    // 0x652598: b.lt            #0x6525b8
    // 0x65259c: SaveReg r3
    //     0x65259c: str             x3, [SP, #-8]!
    // 0x6525a0: r0 = dispose()
    //     0x6525a0: bl              #0x65378c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0x6525a4: add             SP, SP, #8
    // 0x6525a8: r0 = Null
    //     0x6525a8: mov             x0, NULL
    // 0x6525ac: LeaveFrame
    //     0x6525ac: mov             SP, fp
    //     0x6525b0: ldp             fp, lr, [SP], #0x10
    // 0x6525b4: ret
    //     0x6525b4: ret             
    // 0x6525b8: ArrayLoad: r7 = r4[r0]  ; Unknown_4
    //     0x6525b8: add             x16, x4, x0, lsl #2
    //     0x6525bc: ldur            w7, [x16, #0xf]
    // 0x6525c0: DecompressPointer r7
    //     0x6525c0: add             x7, x7, HEAP, lsl #32
    // 0x6525c4: stur            x7, [fp, #-0x10]
    // 0x6525c8: add             x8, x0, #1
    // 0x6525cc: stur            x8, [fp, #-8]
    // 0x6525d0: cmp             w7, NULL
    // 0x6525d4: b.ne            #0x652608
    // 0x6525d8: mov             x0, x7
    // 0x6525dc: mov             x2, x5
    // 0x6525e0: r1 = Null
    //     0x6525e0: mov             x1, NULL
    // 0x6525e4: cmp             w2, NULL
    // 0x6525e8: b.eq            #0x652608
    // 0x6525ec: LoadField: r4 = r2->field_17
    //     0x6525ec: ldur            w4, [x2, #0x17]
    // 0x6525f0: DecompressPointer r4
    //     0x6525f0: add             x4, x4, HEAP, lsl #32
    // 0x6525f4: r8 = X0
    //     0x6525f4: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6525f8: LoadField: r9 = r4->field_7
    //     0x6525f8: ldur            x9, [x4, #7]
    // 0x6525fc: r3 = Null
    //     0x6525fc: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d300] Null
    //     0x652600: ldr             x3, [x3, #0x300]
    // 0x652604: blr             x9
    // 0x652608: ldur            x0, [fp, #-0x10]
    // 0x65260c: LoadField: r1 = r0->field_4b
    //     0x65260c: ldur            w1, [x0, #0x4b]
    // 0x652610: DecompressPointer r1
    //     0x652610: add             x1, x1, HEAP, lsl #32
    // 0x652614: cmp             w1, NULL
    // 0x652618: b.eq            #0x65262c
    // 0x65261c: SaveReg r1
    //     0x65261c: str             x1, [SP, #-8]!
    // 0x652620: r0 = _dispose()
    //     0x652620: bl              #0x62d5b4  ; [dart:ui] Paragraph::_dispose
    // 0x652624: add             SP, SP, #8
    // 0x652628: ldur            x0, [fp, #-0x10]
    // 0x65262c: StoreField: r0->field_4b = rNULL
    //     0x65262c: stur            NULL, [x0, #0x4b]
    // 0x652630: LoadField: r1 = r0->field_7
    //     0x652630: ldur            w1, [x0, #7]
    // 0x652634: DecompressPointer r1
    //     0x652634: add             x1, x1, HEAP, lsl #32
    // 0x652638: cmp             w1, NULL
    // 0x65263c: b.eq            #0x652650
    // 0x652640: SaveReg r1
    //     0x652640: str             x1, [SP, #-8]!
    // 0x652644: r0 = _dispose()
    //     0x652644: bl              #0x62d5b4  ; [dart:ui] Paragraph::_dispose
    // 0x652648: add             SP, SP, #8
    // 0x65264c: ldur            x0, [fp, #-0x10]
    // 0x652650: StoreField: r0->field_7 = rNULL
    //     0x652650: stur            NULL, [x0, #7]
    // 0x652654: StoreField: r0->field_f = rNULL
    //     0x652654: stur            NULL, [x0, #0xf]
    // 0x652658: ldur            x0, [fp, #-8]
    // 0x65265c: ldr             x3, [fp, #0x10]
    // 0x652660: ldur            x4, [fp, #-0x28]
    // 0x652664: ldur            x5, [fp, #-0x20]
    // 0x652668: ldur            x6, [fp, #-0x18]
    // 0x65266c: b               #0x652588
    // 0x652670: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x652670: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x652674: b               #0x652558
    // 0x652678: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x652678: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65267c: b               #0x652594
  }
  _ _RenderFlex&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin&DebugOverflowIndicatorMixin(/* No info */) {
    // ** addr: 0x6f2b58, size: 0xf0
    // 0x6f2b58: EnterFrame
    //     0x6f2b58: stp             fp, lr, [SP, #-0x10]!
    //     0x6f2b5c: mov             fp, SP
    // 0x6f2b60: AllocStack(0x8)
    //     0x6f2b60: sub             SP, SP, #8
    // 0x6f2b64: CheckStackOverflow
    //     0x6f2b64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f2b68: cmp             SP, x16
    //     0x6f2b6c: b.ls            #0x6f2c38
    // 0x6f2b70: r0 = TextPainter()
    //     0x6f2b70: bl              #0x68dbc4  ; AllocateTextPainterStub -> TextPainter (size=0x68)
    // 0x6f2b74: mov             x3, x0
    // 0x6f2b78: r0 = true
    //     0x6f2b78: add             x0, NULL, #0x20  ; true
    // 0x6f2b7c: stur            x3, [fp, #-8]
    // 0x6f2b80: StoreField: r3->field_b = r0
    //     0x6f2b80: stur            w0, [x3, #0xb]
    // 0x6f2b84: r0 = Sentinel
    //     0x6f2b84: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6f2b88: StoreField: r3->field_57 = r0
    //     0x6f2b88: stur            w0, [x3, #0x57]
    // 0x6f2b8c: r0 = Instance_TextAlign
    //     0x6f2b8c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14fe8] Obj!TextAlign@b66f71
    //     0x6f2b90: ldr             x0, [x0, #0xfe8]
    // 0x6f2b94: StoreField: r3->field_17 = r0
    //     0x6f2b94: stur            w0, [x3, #0x17]
    // 0x6f2b98: r0 = Instance_TextDirection
    //     0x6f2b98: ldr             x0, [PP, #0x4808]  ; [pp+0x4808] Obj!TextDirection@b66e31
    // 0x6f2b9c: StoreField: r3->field_1b = r0
    //     0x6f2b9c: stur            w0, [x3, #0x1b]
    // 0x6f2ba0: d0 = 1.000000
    //     0x6f2ba0: fmov            d0, #1.00000000
    // 0x6f2ba4: StoreField: r3->field_1f = d0
    //     0x6f2ba4: stur            d0, [x3, #0x1f]
    // 0x6f2ba8: r0 = Instance_TextWidthBasis
    //     0x6f2ba8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15148] Obj!TextWidthBasis@b64d31
    //     0x6f2bac: ldr             x0, [x0, #0x148]
    // 0x6f2bb0: StoreField: r3->field_37 = r0
    //     0x6f2bb0: stur            w0, [x3, #0x37]
    // 0x6f2bb4: r1 = <TextPainter>
    //     0x6f2bb4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15390] TypeArguments: <TextPainter>
    //     0x6f2bb8: ldr             x1, [x1, #0x390]
    // 0x6f2bbc: r2 = 8
    //     0x6f2bbc: mov             x2, #8
    // 0x6f2bc0: r0 = AllocateArray()
    //     0x6f2bc0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x6f2bc4: ldur            x1, [fp, #-8]
    // 0x6f2bc8: r2 = 0
    //     0x6f2bc8: mov             x2, #0
    // 0x6f2bcc: CheckStackOverflow
    //     0x6f2bcc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f2bd0: cmp             SP, x16
    //     0x6f2bd4: b.ls            #0x6f2c40
    // 0x6f2bd8: cmp             x2, #4
    // 0x6f2bdc: b.ge            #0x6f2bf4
    // 0x6f2be0: ArrayStore: r0[r2] = r1  ; Unknown_4
    //     0x6f2be0: add             x3, x0, x2, lsl #2
    //     0x6f2be4: stur            w1, [x3, #0xf]
    // 0x6f2be8: add             x3, x2, #1
    // 0x6f2bec: mov             x2, x3
    // 0x6f2bf0: b               #0x6f2bcc
    // 0x6f2bf4: ldr             x2, [fp, #0x10]
    // 0x6f2bf8: r1 = 0
    //     0x6f2bf8: mov             x1, #0
    // 0x6f2bfc: StoreField: r2->field_6f = r0
    //     0x6f2bfc: stur            w0, [x2, #0x6f]
    //     0x6f2c00: ldurb           w16, [x2, #-1]
    //     0x6f2c04: ldurb           w17, [x0, #-1]
    //     0x6f2c08: and             x16, x17, x16, lsr #2
    //     0x6f2c0c: tst             x16, HEAP, lsr #32
    //     0x6f2c10: b.eq            #0x6f2c18
    //     0x6f2c14: bl              #0xd6828c
    // 0x6f2c18: StoreField: r2->field_5f = r1
    //     0x6f2c18: stur            x1, [x2, #0x5f]
    // 0x6f2c1c: SaveReg r2
    //     0x6f2c1c: str             x2, [SP, #-8]!
    // 0x6f2c20: r0 = RenderObject()
    //     0x6f2c20: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6f2c24: add             SP, SP, #8
    // 0x6f2c28: r0 = Null
    //     0x6f2c28: mov             x0, NULL
    // 0x6f2c2c: LeaveFrame
    //     0x6f2c2c: mov             SP, fp
    //     0x6f2c30: ldp             fp, lr, [SP], #0x10
    // 0x6f2c34: ret
    //     0x6f2c34: ret             
    // 0x6f2c38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f2c38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f2c3c: b               #0x6f2b70
    // 0x6f2c40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f2c40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f2c44: b               #0x6f2bd8
  }
}

// class id: 2541, size: 0xa0, field offset: 0x74
class RenderFlex extends _RenderFlex&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin&DebugOverflowIndicatorMixin {

  _ hitTestChildren(/* No info */) {
    // ** addr: 0x622680, size: 0x44
    // 0x622680: EnterFrame
    //     0x622680: stp             fp, lr, [SP, #-0x10]!
    //     0x622684: mov             fp, SP
    // 0x622688: CheckStackOverflow
    //     0x622688: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62268c: cmp             SP, x16
    //     0x622690: b.ls            #0x6226bc
    // 0x622694: ldr             x16, [fp, #0x20]
    // 0x622698: ldr             lr, [fp, #0x18]
    // 0x62269c: stp             lr, x16, [SP, #-0x10]!
    // 0x6226a0: ldr             x16, [fp, #0x10]
    // 0x6226a4: SaveReg r16
    //     0x6226a4: str             x16, [SP, #-8]!
    // 0x6226a8: r0 = defaultHitTestChildren()
    //     0x6226a8: bl              #0x6226c4  ; [package:flutter/src/rendering/flex.dart] _RenderFlex&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultHitTestChildren
    // 0x6226ac: add             SP, SP, #0x18
    // 0x6226b0: LeaveFrame
    //     0x6226b0: mov             SP, fp
    //     0x6226b4: ldp             fp, lr, [SP], #0x10
    // 0x6226b8: ret
    //     0x6226b8: ret             
    // 0x6226bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6226bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6226c0: b               #0x622694
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x62bed4, size: 0x18
    // 0x62bed4: r4 = 0
    //     0x62bed4: mov             x4, #0
    // 0x62bed8: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x62bed8: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4beb8] AnonymousClosure: (0x62beec), in [package:flutter/src/rendering/flex.dart] RenderFlex::computeMaxIntrinsicHeight (0x62bf38)
    //     0x62bedc: ldr             x1, [x17, #0xeb8]
    // 0x62bee0: r24 = BuildNonGenericMethodExtractorStub
    //     0x62bee0: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x62bee4: LoadField: r0 = r24->field_17
    //     0x62bee4: ldur            x0, [x24, #0x17]
    // 0x62bee8: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x62beec, size: 0x4c
    // 0x62beec: EnterFrame
    //     0x62beec: stp             fp, lr, [SP, #-0x10]!
    //     0x62bef0: mov             fp, SP
    // 0x62bef4: ldr             x0, [fp, #0x18]
    // 0x62bef8: LoadField: r1 = r0->field_17
    //     0x62bef8: ldur            w1, [x0, #0x17]
    // 0x62befc: DecompressPointer r1
    //     0x62befc: add             x1, x1, HEAP, lsl #32
    // 0x62bf00: CheckStackOverflow
    //     0x62bf00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62bf04: cmp             SP, x16
    //     0x62bf08: b.ls            #0x62bf30
    // 0x62bf0c: LoadField: r0 = r1->field_f
    //     0x62bf0c: ldur            w0, [x1, #0xf]
    // 0x62bf10: DecompressPointer r0
    //     0x62bf10: add             x0, x0, HEAP, lsl #32
    // 0x62bf14: ldr             x16, [fp, #0x10]
    // 0x62bf18: stp             x16, x0, [SP, #-0x10]!
    // 0x62bf1c: r0 = computeMaxIntrinsicHeight()
    //     0x62bf1c: bl              #0x62bf38  ; [package:flutter/src/rendering/flex.dart] RenderFlex::computeMaxIntrinsicHeight
    // 0x62bf20: add             SP, SP, #0x10
    // 0x62bf24: LeaveFrame
    //     0x62bf24: mov             SP, fp
    //     0x62bf28: ldp             fp, lr, [SP], #0x10
    // 0x62bf2c: ret
    //     0x62bf2c: ret             
    // 0x62bf30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62bf30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62bf34: b               #0x62bf0c
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0x62bf38, size: 0xa4
    // 0x62bf38: EnterFrame
    //     0x62bf38: stp             fp, lr, [SP, #-0x10]!
    //     0x62bf3c: mov             fp, SP
    // 0x62bf40: AllocStack(0x8)
    //     0x62bf40: sub             SP, SP, #8
    // 0x62bf44: CheckStackOverflow
    //     0x62bf44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62bf48: cmp             SP, x16
    //     0x62bf4c: b.ls            #0x62bfc4
    // 0x62bf50: ldr             x0, [fp, #0x10]
    // 0x62bf54: LoadField: d0 = r0->field_7
    //     0x62bf54: ldur            d0, [x0, #7]
    // 0x62bf58: stur            d0, [fp, #-8]
    // 0x62bf5c: r1 = Function '<anonymous closure>':.
    //     0x62bf5c: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bec0] AnonymousClosure: (0x62cdf0), in [package:flutter/src/rendering/flex.dart] RenderFlex::computeMaxIntrinsicHeight (0x62bf38)
    //     0x62bf60: ldr             x1, [x1, #0xec0]
    // 0x62bf64: r2 = Null
    //     0x62bf64: mov             x2, NULL
    // 0x62bf68: r0 = AllocateClosure()
    //     0x62bf68: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x62bf6c: ldr             x16, [fp, #0x18]
    // 0x62bf70: stp             x0, x16, [SP, #-0x10]!
    // 0x62bf74: ldur            d0, [fp, #-8]
    // 0x62bf78: SaveReg d0
    //     0x62bf78: str             d0, [SP, #-8]!
    // 0x62bf7c: r16 = Instance_Axis
    //     0x62bf7c: add             x16, PP, #0xe, lsl #12  ; [pp+0xef00] Obj!Axis@b64ff1
    //     0x62bf80: ldr             x16, [x16, #0xf00]
    // 0x62bf84: SaveReg r16
    //     0x62bf84: str             x16, [SP, #-8]!
    // 0x62bf88: r0 = _getIntrinsicSize()
    //     0x62bf88: bl              #0x62bfdc  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_getIntrinsicSize
    // 0x62bf8c: add             SP, SP, #0x20
    // 0x62bf90: r0 = inline_Allocate_Double()
    //     0x62bf90: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62bf94: add             x0, x0, #0x10
    //     0x62bf98: cmp             x1, x0
    //     0x62bf9c: b.ls            #0x62bfcc
    //     0x62bfa0: str             x0, [THR, #0x60]  ; THR::top
    //     0x62bfa4: sub             x0, x0, #0xf
    //     0x62bfa8: mov             x1, #0xd108
    //     0x62bfac: movk            x1, #3, lsl #16
    //     0x62bfb0: stur            x1, [x0, #-1]
    // 0x62bfb4: StoreField: r0->field_7 = d0
    //     0x62bfb4: stur            d0, [x0, #7]
    // 0x62bfb8: LeaveFrame
    //     0x62bfb8: mov             SP, fp
    //     0x62bfbc: ldp             fp, lr, [SP], #0x10
    // 0x62bfc0: ret
    //     0x62bfc0: ret             
    // 0x62bfc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62bfc4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62bfc8: b               #0x62bf50
    // 0x62bfcc: SaveReg d0
    //     0x62bfcc: str             q0, [SP, #-0x10]!
    // 0x62bfd0: r0 = AllocateDouble()
    //     0x62bfd0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62bfd4: RestoreReg d0
    //     0x62bfd4: ldr             q0, [SP], #0x10
    // 0x62bfd8: b               #0x62bfb4
  }
  _ _getIntrinsicSize(/* No info */) {
    // ** addr: 0x62bfdc, size: 0xb48
    // 0x62bfdc: EnterFrame
    //     0x62bfdc: stp             fp, lr, [SP, #-0x10]!
    //     0x62bfe0: mov             fp, SP
    // 0x62bfe4: AllocStack(0x68)
    //     0x62bfe4: sub             SP, SP, #0x68
    // 0x62bfe8: CheckStackOverflow
    //     0x62bfe8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62bfec: cmp             SP, x16
    //     0x62bff0: b.ls            #0x62ca40
    // 0x62bff4: ldr             x3, [fp, #0x28]
    // 0x62bff8: LoadField: r0 = r3->field_7f
    //     0x62bff8: ldur            w0, [x3, #0x7f]
    // 0x62bffc: DecompressPointer r0
    //     0x62bffc: add             x0, x0, HEAP, lsl #32
    // 0x62c000: r16 = Instance_CrossAxisAlignment
    //     0x62c000: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d280] Obj!CrossAxisAlignment@b649f1
    //     0x62c004: ldr             x16, [x16, #0x280]
    // 0x62c008: cmp             w0, w16
    // 0x62c00c: b.ne            #0x62c020
    // 0x62c010: d0 = 0.000000
    //     0x62c010: eor             v0.16b, v0.16b, v0.16b
    // 0x62c014: LeaveFrame
    //     0x62c014: mov             SP, fp
    //     0x62c018: ldp             fp, lr, [SP], #0x10
    // 0x62c01c: ret
    //     0x62c01c: ret             
    // 0x62c020: ldr             x0, [fp, #0x10]
    // 0x62c024: LoadField: r1 = r3->field_73
    //     0x62c024: ldur            w1, [x3, #0x73]
    // 0x62c028: DecompressPointer r1
    //     0x62c028: add             x1, x1, HEAP, lsl #32
    // 0x62c02c: cmp             w1, w0
    // 0x62c030: b.ne            #0x62c374
    // 0x62c034: ldr             d0, [fp, #0x18]
    // 0x62c038: LoadField: r0 = r3->field_67
    //     0x62c038: ldur            w0, [x3, #0x67]
    // 0x62c03c: DecompressPointer r0
    //     0x62c03c: add             x0, x0, HEAP, lsl #32
    // 0x62c040: r3 = inline_Allocate_Double()
    //     0x62c040: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0x62c044: add             x3, x3, #0x10
    //     0x62c048: cmp             x1, x3
    //     0x62c04c: b.ls            #0x62ca48
    //     0x62c050: str             x3, [THR, #0x60]  ; THR::top
    //     0x62c054: sub             x3, x3, #0xf
    //     0x62c058: mov             x1, #0xd108
    //     0x62c05c: movk            x1, #3, lsl #16
    //     0x62c060: stur            x1, [x3, #-1]
    // 0x62c064: StoreField: r3->field_7 = d0
    //     0x62c064: stur            d0, [x3, #7]
    // 0x62c068: stur            x3, [fp, #-0x20]
    // 0x62c06c: r4 = inline_Allocate_Double()
    //     0x62c06c: ldp             x4, x1, [THR, #0x60]  ; THR::top
    //     0x62c070: add             x4, x4, #0x10
    //     0x62c074: cmp             x1, x4
    //     0x62c078: b.ls            #0x62ca64
    //     0x62c07c: str             x4, [THR, #0x60]  ; THR::top
    //     0x62c080: sub             x4, x4, #0xf
    //     0x62c084: mov             x1, #0xd108
    //     0x62c088: movk            x1, #3, lsl #16
    //     0x62c08c: stur            x1, [x4, #-1]
    // 0x62c090: StoreField: r4->field_7 = d0
    //     0x62c090: stur            d0, [x4, #7]
    // 0x62c094: stur            x4, [fp, #-0x18]
    // 0x62c098: mov             x5, x0
    // 0x62c09c: d2 = 0.000000
    //     0x62c09c: eor             v2.16b, v2.16b, v2.16b
    // 0x62c0a0: d1 = 0.000000
    //     0x62c0a0: eor             v1.16b, v1.16b, v1.16b
    // 0x62c0a4: d0 = 0.000000
    //     0x62c0a4: eor             v0.16b, v0.16b, v0.16b
    // 0x62c0a8: stur            x5, [fp, #-0x10]
    // 0x62c0ac: stur            d2, [fp, #-0x40]
    // 0x62c0b0: stur            d1, [fp, #-0x48]
    // 0x62c0b4: stur            d0, [fp, #-0x50]
    // 0x62c0b8: CheckStackOverflow
    //     0x62c0b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62c0bc: cmp             SP, x16
    //     0x62c0c0: b.ls            #0x62ca80
    // 0x62c0c4: cmp             w5, NULL
    // 0x62c0c8: b.eq            #0x62c354
    // 0x62c0cc: LoadField: r6 = r5->field_17
    //     0x62c0cc: ldur            w6, [x5, #0x17]
    // 0x62c0d0: DecompressPointer r6
    //     0x62c0d0: add             x6, x6, HEAP, lsl #32
    // 0x62c0d4: stur            x6, [fp, #-8]
    // 0x62c0d8: cmp             w6, NULL
    // 0x62c0dc: b.eq            #0x62ca88
    // 0x62c0e0: mov             x0, x6
    // 0x62c0e4: r2 = Null
    //     0x62c0e4: mov             x2, NULL
    // 0x62c0e8: r1 = Null
    //     0x62c0e8: mov             x1, NULL
    // 0x62c0ec: r4 = LoadClassIdInstr(r0)
    //     0x62c0ec: ldur            x4, [x0, #-1]
    //     0x62c0f0: ubfx            x4, x4, #0xc, #0x14
    // 0x62c0f4: cmp             x4, #0x809
    // 0x62c0f8: b.eq            #0x62c110
    // 0x62c0fc: r8 = FlexParentData<RenderBox>
    //     0x62c0fc: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x62c100: ldr             x8, [x8, #0x248]
    // 0x62c104: r3 = Null
    //     0x62c104: add             x3, PP, #0x40, lsl #12  ; [pp+0x40b90] Null
    //     0x62c108: ldr             x3, [x3, #0xb90]
    // 0x62c10c: r0 = DefaultTypeTest()
    //     0x62c10c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x62c110: ldur            x0, [fp, #-8]
    // 0x62c114: LoadField: r1 = r0->field_17
    //     0x62c114: ldur            w1, [x0, #0x17]
    // 0x62c118: DecompressPointer r1
    //     0x62c118: add             x1, x1, HEAP, lsl #32
    // 0x62c11c: cmp             w1, NULL
    // 0x62c120: b.ne            #0x62c12c
    // 0x62c124: r0 = 0
    //     0x62c124: mov             x0, #0
    // 0x62c128: b               #0x62c130
    // 0x62c12c: r0 = LoadInt32Instr(r1)
    //     0x62c12c: sbfx            x0, x1, #1, #0x1f
    // 0x62c130: ldur            d0, [fp, #-0x40]
    // 0x62c134: lsl             x1, x0, #1
    // 0x62c138: r16 = LoadInt32Instr(r1)
    //     0x62c138: sbfx            x16, x1, #1, #0x1f
    // 0x62c13c: scvtf           d1, w16
    // 0x62c140: fadd            d2, d0, d1
    // 0x62c144: stur            d2, [fp, #-0x58]
    // 0x62c148: cmp             x0, #0
    // 0x62c14c: b.le            #0x62c26c
    // 0x62c150: ldur            x1, [fp, #-0x10]
    // 0x62c154: ldr             x16, [fp, #0x20]
    // 0x62c158: stp             x1, x16, [SP, #-0x10]!
    // 0x62c15c: ldur            x16, [fp, #-0x18]
    // 0x62c160: SaveReg r16
    //     0x62c160: str             x16, [SP, #-8]!
    // 0x62c164: ldr             x0, [fp, #0x20]
    // 0x62c168: ClosureCall
    //     0x62c168: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x62c16c: ldur            x2, [x0, #0x1f]
    //     0x62c170: blr             x2
    // 0x62c174: add             SP, SP, #0x18
    // 0x62c178: mov             x4, x0
    // 0x62c17c: ldur            x3, [fp, #-0x10]
    // 0x62c180: stur            x4, [fp, #-0x28]
    // 0x62c184: LoadField: r5 = r3->field_17
    //     0x62c184: ldur            w5, [x3, #0x17]
    // 0x62c188: DecompressPointer r5
    //     0x62c188: add             x5, x5, HEAP, lsl #32
    // 0x62c18c: stur            x5, [fp, #-8]
    // 0x62c190: cmp             w5, NULL
    // 0x62c194: b.eq            #0x62ca8c
    // 0x62c198: mov             x0, x5
    // 0x62c19c: r2 = Null
    //     0x62c19c: mov             x2, NULL
    // 0x62c1a0: r1 = Null
    //     0x62c1a0: mov             x1, NULL
    // 0x62c1a4: r4 = LoadClassIdInstr(r0)
    //     0x62c1a4: ldur            x4, [x0, #-1]
    //     0x62c1a8: ubfx            x4, x4, #0xc, #0x14
    // 0x62c1ac: cmp             x4, #0x809
    // 0x62c1b0: b.eq            #0x62c1c8
    // 0x62c1b4: r8 = FlexParentData<RenderBox>
    //     0x62c1b4: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x62c1b8: ldr             x8, [x8, #0x248]
    // 0x62c1bc: r3 = Null
    //     0x62c1bc: add             x3, PP, #0x40, lsl #12  ; [pp+0x40ba0] Null
    //     0x62c1c0: ldr             x3, [x3, #0xba0]
    // 0x62c1c4: r0 = DefaultTypeTest()
    //     0x62c1c4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x62c1c8: ldur            x0, [fp, #-8]
    // 0x62c1cc: LoadField: r1 = r0->field_17
    //     0x62c1cc: ldur            w1, [x0, #0x17]
    // 0x62c1d0: DecompressPointer r1
    //     0x62c1d0: add             x1, x1, HEAP, lsl #32
    // 0x62c1d4: cmp             w1, NULL
    // 0x62c1d8: b.ne            #0x62c1e4
    // 0x62c1dc: r1 = 0
    //     0x62c1dc: mov             x1, #0
    // 0x62c1e0: b               #0x62c1ec
    // 0x62c1e4: r0 = LoadInt32Instr(r1)
    //     0x62c1e4: sbfx            x0, x1, #1, #0x1f
    // 0x62c1e8: mov             x1, x0
    // 0x62c1ec: ldur            d0, [fp, #-0x50]
    // 0x62c1f0: ldur            x0, [fp, #-0x28]
    // 0x62c1f4: cmp             w0, NULL
    // 0x62c1f8: b.eq            #0x62ca90
    // 0x62c1fc: lsl             x2, x1, #1
    // 0x62c200: r16 = LoadInt32Instr(r2)
    //     0x62c200: sbfx            x16, x2, #1, #0x1f
    // 0x62c204: scvtf           d1, w16
    // 0x62c208: LoadField: d2 = r0->field_7
    //     0x62c208: ldur            d2, [x0, #7]
    // 0x62c20c: fdiv            d3, d2, d1
    // 0x62c210: fcmp            d0, d3
    // 0x62c214: b.vs            #0x62c224
    // 0x62c218: b.le            #0x62c224
    // 0x62c21c: d1 = 0.000000
    //     0x62c21c: eor             v1.16b, v1.16b, v1.16b
    // 0x62c220: b               #0x62c264
    // 0x62c224: fcmp            d0, d3
    // 0x62c228: b.vs            #0x62c23c
    // 0x62c22c: b.ge            #0x62c23c
    // 0x62c230: mov             v0.16b, v3.16b
    // 0x62c234: d1 = 0.000000
    //     0x62c234: eor             v1.16b, v1.16b, v1.16b
    // 0x62c238: b               #0x62c264
    // 0x62c23c: d1 = 0.000000
    //     0x62c23c: eor             v1.16b, v1.16b, v1.16b
    // 0x62c240: fcmp            d0, d1
    // 0x62c244: b.vs            #0x62c258
    // 0x62c248: b.ne            #0x62c258
    // 0x62c24c: fadd            d4, d0, d3
    // 0x62c250: mov             v0.16b, v4.16b
    // 0x62c254: b               #0x62c264
    // 0x62c258: fcmp            d3, d3
    // 0x62c25c: b.vc            #0x62c264
    // 0x62c260: mov             v0.16b, v3.16b
    // 0x62c264: ldur            d1, [fp, #-0x48]
    // 0x62c268: b               #0x62c2e0
    // 0x62c26c: ldur            d2, [fp, #-0x48]
    // 0x62c270: ldur            d0, [fp, #-0x50]
    // 0x62c274: d1 = 0.000000
    //     0x62c274: eor             v1.16b, v1.16b, v1.16b
    // 0x62c278: ldr             x16, [fp, #0x20]
    // 0x62c27c: ldur            lr, [fp, #-0x10]
    // 0x62c280: stp             lr, x16, [SP, #-0x10]!
    // 0x62c284: ldur            x16, [fp, #-0x20]
    // 0x62c288: SaveReg r16
    //     0x62c288: str             x16, [SP, #-8]!
    // 0x62c28c: ldr             x0, [fp, #0x20]
    // 0x62c290: ClosureCall
    //     0x62c290: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x62c294: ldur            x2, [x0, #0x1f]
    //     0x62c298: blr             x2
    // 0x62c29c: add             SP, SP, #0x18
    // 0x62c2a0: ldur            d1, [fp, #-0x48]
    // 0x62c2a4: r1 = inline_Allocate_Double()
    //     0x62c2a4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x62c2a8: add             x1, x1, #0x10
    //     0x62c2ac: cmp             x2, x1
    //     0x62c2b0: b.ls            #0x62ca94
    //     0x62c2b4: str             x1, [THR, #0x60]  ; THR::top
    //     0x62c2b8: sub             x1, x1, #0xf
    //     0x62c2bc: mov             x2, #0xd108
    //     0x62c2c0: movk            x2, #3, lsl #16
    //     0x62c2c4: stur            x2, [x1, #-1]
    // 0x62c2c8: StoreField: r1->field_7 = d1
    //     0x62c2c8: stur            d1, [x1, #7]
    // 0x62c2cc: stp             x0, x1, [SP, #-0x10]!
    // 0x62c2d0: r0 = +()
    //     0x62c2d0: bl              #0xd67370  ; [dart:core] _Double::+
    // 0x62c2d4: add             SP, SP, #0x10
    // 0x62c2d8: LoadField: d1 = r0->field_7
    //     0x62c2d8: ldur            d1, [x0, #7]
    // 0x62c2dc: ldur            d0, [fp, #-0x50]
    // 0x62c2e0: ldur            x0, [fp, #-0x10]
    // 0x62c2e4: stur            d1, [fp, #-0x60]
    // 0x62c2e8: stur            d0, [fp, #-0x68]
    // 0x62c2ec: LoadField: r3 = r0->field_17
    //     0x62c2ec: ldur            w3, [x0, #0x17]
    // 0x62c2f0: DecompressPointer r3
    //     0x62c2f0: add             x3, x3, HEAP, lsl #32
    // 0x62c2f4: stur            x3, [fp, #-8]
    // 0x62c2f8: cmp             w3, NULL
    // 0x62c2fc: b.eq            #0x62cab0
    // 0x62c300: mov             x0, x3
    // 0x62c304: r2 = Null
    //     0x62c304: mov             x2, NULL
    // 0x62c308: r1 = Null
    //     0x62c308: mov             x1, NULL
    // 0x62c30c: r4 = LoadClassIdInstr(r0)
    //     0x62c30c: ldur            x4, [x0, #-1]
    //     0x62c310: ubfx            x4, x4, #0xc, #0x14
    // 0x62c314: cmp             x4, #0x809
    // 0x62c318: b.eq            #0x62c330
    // 0x62c31c: r8 = FlexParentData<RenderBox>
    //     0x62c31c: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x62c320: ldr             x8, [x8, #0x248]
    // 0x62c324: r3 = Null
    //     0x62c324: add             x3, PP, #0x40, lsl #12  ; [pp+0x40bb0] Null
    //     0x62c328: ldr             x3, [x3, #0xbb0]
    // 0x62c32c: r0 = DefaultTypeTest()
    //     0x62c32c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x62c330: ldur            x0, [fp, #-8]
    // 0x62c334: LoadField: r5 = r0->field_13
    //     0x62c334: ldur            w5, [x0, #0x13]
    // 0x62c338: DecompressPointer r5
    //     0x62c338: add             x5, x5, HEAP, lsl #32
    // 0x62c33c: ldur            d2, [fp, #-0x58]
    // 0x62c340: ldur            d1, [fp, #-0x60]
    // 0x62c344: ldur            d0, [fp, #-0x68]
    // 0x62c348: ldur            x4, [fp, #-0x18]
    // 0x62c34c: ldur            x3, [fp, #-0x20]
    // 0x62c350: b               #0x62c0a8
    // 0x62c354: mov             v31.16b, v0.16b
    // 0x62c358: mov             v0.16b, v2.16b
    // 0x62c35c: mov             v2.16b, v31.16b
    // 0x62c360: fmul            d3, d2, d0
    // 0x62c364: fadd            d0, d3, d1
    // 0x62c368: LeaveFrame
    //     0x62c368: mov             SP, fp
    //     0x62c36c: ldp             fp, lr, [SP], #0x10
    // 0x62c370: ret
    //     0x62c370: ret             
    // 0x62c374: ldr             d0, [fp, #0x18]
    // 0x62c378: LoadField: r0 = r3->field_67
    //     0x62c378: ldur            w0, [x3, #0x67]
    // 0x62c37c: DecompressPointer r0
    //     0x62c37c: add             x0, x0, HEAP, lsl #32
    // 0x62c380: mov             x4, x0
    // 0x62c384: r6 = 0
    //     0x62c384: mov             x6, #0
    // 0x62c388: d1 = 0.000000
    //     0x62c388: eor             v1.16b, v1.16b, v1.16b
    // 0x62c38c: r5 = 0.000000
    //     0x62c38c: ldr             x5, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x62c390: stur            x6, [fp, #-0x30]
    // 0x62c394: stur            x5, [fp, #-0x10]
    // 0x62c398: stur            x4, [fp, #-0x18]
    // 0x62c39c: stur            d1, [fp, #-0x40]
    // 0x62c3a0: CheckStackOverflow
    //     0x62c3a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62c3a4: cmp             SP, x16
    //     0x62c3a8: b.ls            #0x62cab4
    // 0x62c3ac: cmp             w4, NULL
    // 0x62c3b0: b.eq            #0x62c734
    // 0x62c3b4: LoadField: r7 = r4->field_17
    //     0x62c3b4: ldur            w7, [x4, #0x17]
    // 0x62c3b8: DecompressPointer r7
    //     0x62c3b8: add             x7, x7, HEAP, lsl #32
    // 0x62c3bc: stur            x7, [fp, #-8]
    // 0x62c3c0: cmp             w7, NULL
    // 0x62c3c4: b.eq            #0x62cabc
    // 0x62c3c8: mov             x0, x7
    // 0x62c3cc: r2 = Null
    //     0x62c3cc: mov             x2, NULL
    // 0x62c3d0: r1 = Null
    //     0x62c3d0: mov             x1, NULL
    // 0x62c3d4: r4 = LoadClassIdInstr(r0)
    //     0x62c3d4: ldur            x4, [x0, #-1]
    //     0x62c3d8: ubfx            x4, x4, #0xc, #0x14
    // 0x62c3dc: cmp             x4, #0x809
    // 0x62c3e0: b.eq            #0x62c3f8
    // 0x62c3e4: r8 = FlexParentData<RenderBox>
    //     0x62c3e4: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x62c3e8: ldr             x8, [x8, #0x248]
    // 0x62c3ec: r3 = Null
    //     0x62c3ec: add             x3, PP, #0x40, lsl #12  ; [pp+0x40bc0] Null
    //     0x62c3f0: ldr             x3, [x3, #0xbc0]
    // 0x62c3f4: r0 = DefaultTypeTest()
    //     0x62c3f4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x62c3f8: ldur            x0, [fp, #-8]
    // 0x62c3fc: LoadField: r1 = r0->field_17
    //     0x62c3fc: ldur            w1, [x0, #0x17]
    // 0x62c400: DecompressPointer r1
    //     0x62c400: add             x1, x1, HEAP, lsl #32
    // 0x62c404: cmp             w1, NULL
    // 0x62c408: b.ne            #0x62c414
    // 0x62c40c: r1 = 0
    //     0x62c40c: mov             x1, #0
    // 0x62c410: b               #0x62c41c
    // 0x62c414: r0 = LoadInt32Instr(r1)
    //     0x62c414: sbfx            x0, x1, #1, #0x1f
    // 0x62c418: mov             x1, x0
    // 0x62c41c: ldur            x0, [fp, #-0x30]
    // 0x62c420: add             x6, x0, x1
    // 0x62c424: stur            x6, [fp, #-0x38]
    // 0x62c428: lsl             x0, x1, #1
    // 0x62c42c: cbnz            w0, #0x62c6b4
    // 0x62c430: ldr             x1, [fp, #0x28]
    // 0x62c434: LoadField: r0 = r1->field_73
    //     0x62c434: ldur            w0, [x1, #0x73]
    // 0x62c438: DecompressPointer r0
    //     0x62c438: add             x0, x0, HEAP, lsl #32
    // 0x62c43c: LoadField: r2 = r0->field_7
    //     0x62c43c: ldur            x2, [x0, #7]
    // 0x62c440: cmp             x2, #0
    // 0x62c444: b.gt            #0x62c4e8
    // 0x62c448: ldur            x2, [fp, #-0x18]
    // 0x62c44c: r0 = LoadClassIdInstr(r2)
    //     0x62c44c: ldur            x0, [x2, #-1]
    //     0x62c450: ubfx            x0, x0, #0xc, #0x14
    // 0x62c454: SaveReg r2
    //     0x62c454: str             x2, [SP, #-8]!
    // 0x62c458: r0 = GDT[cid_x0 + 0xf204]()
    //     0x62c458: mov             x17, #0xf204
    //     0x62c45c: add             lr, x0, x17
    //     0x62c460: ldr             lr, [x21, lr, lsl #3]
    //     0x62c464: blr             lr
    // 0x62c468: add             SP, SP, #8
    // 0x62c46c: ldur            x16, [fp, #-0x18]
    // 0x62c470: r30 = Instance__IntrinsicDimension
    //     0x62c470: add             lr, PP, #0x37, lsl #12  ; [pp+0x37080] Obj!_IntrinsicDimension@b64bf1
    //     0x62c474: ldr             lr, [lr, #0x80]
    // 0x62c478: stp             lr, x16, [SP, #-0x10]!
    // 0x62c47c: d0 = inf
    //     0x62c47c: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62c480: SaveReg d0
    //     0x62c480: str             d0, [SP, #-8]!
    // 0x62c484: SaveReg r0
    //     0x62c484: str             x0, [SP, #-8]!
    // 0x62c488: r0 = _computeIntrinsicDimension()
    //     0x62c488: bl              #0x62cc04  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsicDimension
    // 0x62c48c: add             SP, SP, #0x20
    // 0x62c490: stur            d0, [fp, #-0x48]
    // 0x62c494: r0 = inline_Allocate_Double()
    //     0x62c494: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62c498: add             x0, x0, #0x10
    //     0x62c49c: cmp             x1, x0
    //     0x62c4a0: b.ls            #0x62cac0
    //     0x62c4a4: str             x0, [THR, #0x60]  ; THR::top
    //     0x62c4a8: sub             x0, x0, #0xf
    //     0x62c4ac: mov             x1, #0xd108
    //     0x62c4b0: movk            x1, #3, lsl #16
    //     0x62c4b4: stur            x1, [x0, #-1]
    // 0x62c4b8: StoreField: r0->field_7 = d0
    //     0x62c4b8: stur            d0, [x0, #7]
    // 0x62c4bc: ldr             x16, [fp, #0x20]
    // 0x62c4c0: ldur            lr, [fp, #-0x18]
    // 0x62c4c4: stp             lr, x16, [SP, #-0x10]!
    // 0x62c4c8: SaveReg r0
    //     0x62c4c8: str             x0, [SP, #-8]!
    // 0x62c4cc: ldr             x0, [fp, #0x20]
    // 0x62c4d0: ClosureCall
    //     0x62c4d0: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x62c4d4: ldur            x2, [x0, #0x1f]
    //     0x62c4d8: blr             x2
    // 0x62c4dc: add             SP, SP, #0x18
    // 0x62c4e0: ldur            d1, [fp, #-0x48]
    // 0x62c4e4: b               #0x62c584
    // 0x62c4e8: ldur            x1, [fp, #-0x18]
    // 0x62c4ec: r0 = LoadClassIdInstr(r1)
    //     0x62c4ec: ldur            x0, [x1, #-1]
    //     0x62c4f0: ubfx            x0, x0, #0xc, #0x14
    // 0x62c4f4: SaveReg r1
    //     0x62c4f4: str             x1, [SP, #-8]!
    // 0x62c4f8: r0 = GDT[cid_x0 + 0xf291]()
    //     0x62c4f8: mov             x17, #0xf291
    //     0x62c4fc: add             lr, x0, x17
    //     0x62c500: ldr             lr, [x21, lr, lsl #3]
    //     0x62c504: blr             lr
    // 0x62c508: add             SP, SP, #8
    // 0x62c50c: ldur            x16, [fp, #-0x18]
    // 0x62c510: r30 = Instance__IntrinsicDimension
    //     0x62c510: add             lr, PP, #0x40, lsl #12  ; [pp+0x40bd0] Obj!_IntrinsicDimension@b64bd1
    //     0x62c514: ldr             lr, [lr, #0xbd0]
    // 0x62c518: stp             lr, x16, [SP, #-0x10]!
    // 0x62c51c: d0 = inf
    //     0x62c51c: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62c520: SaveReg d0
    //     0x62c520: str             d0, [SP, #-8]!
    // 0x62c524: SaveReg r0
    //     0x62c524: str             x0, [SP, #-8]!
    // 0x62c528: r0 = _computeIntrinsicDimension()
    //     0x62c528: bl              #0x62cc04  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsicDimension
    // 0x62c52c: add             SP, SP, #0x20
    // 0x62c530: stur            d0, [fp, #-0x48]
    // 0x62c534: r0 = inline_Allocate_Double()
    //     0x62c534: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62c538: add             x0, x0, #0x10
    //     0x62c53c: cmp             x1, x0
    //     0x62c540: b.ls            #0x62cad0
    //     0x62c544: str             x0, [THR, #0x60]  ; THR::top
    //     0x62c548: sub             x0, x0, #0xf
    //     0x62c54c: mov             x1, #0xd108
    //     0x62c550: movk            x1, #3, lsl #16
    //     0x62c554: stur            x1, [x0, #-1]
    // 0x62c558: StoreField: r0->field_7 = d0
    //     0x62c558: stur            d0, [x0, #7]
    // 0x62c55c: ldr             x16, [fp, #0x20]
    // 0x62c560: ldur            lr, [fp, #-0x18]
    // 0x62c564: stp             lr, x16, [SP, #-0x10]!
    // 0x62c568: SaveReg r0
    //     0x62c568: str             x0, [SP, #-8]!
    // 0x62c56c: ldr             x0, [fp, #0x20]
    // 0x62c570: ClosureCall
    //     0x62c570: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x62c574: ldur            x2, [x0, #0x1f]
    //     0x62c578: blr             x2
    // 0x62c57c: add             SP, SP, #0x18
    // 0x62c580: ldur            d1, [fp, #-0x48]
    // 0x62c584: ldur            d0, [fp, #-0x40]
    // 0x62c588: stur            x0, [fp, #-8]
    // 0x62c58c: fadd            d2, d0, d1
    // 0x62c590: stur            d2, [fp, #-0x48]
    // 0x62c594: ldur            x16, [fp, #-0x10]
    // 0x62c598: stp             x0, x16, [SP, #-0x10]!
    // 0x62c59c: r0 = >()
    //     0x62c59c: bl              #0xd6719c  ; [dart:core] _Double::>
    // 0x62c5a0: add             SP, SP, #0x10
    // 0x62c5a4: tbnz            w0, #4, #0x62c5b0
    // 0x62c5a8: ldur            x0, [fp, #-0x10]
    // 0x62c5ac: b               #0x62c6a8
    // 0x62c5b0: ldur            x16, [fp, #-0x10]
    // 0x62c5b4: ldur            lr, [fp, #-8]
    // 0x62c5b8: stp             lr, x16, [SP, #-0x10]!
    // 0x62c5bc: r0 = <()
    //     0x62c5bc: bl              #0xd64ef8  ; [dart:core] _Double::<
    // 0x62c5c0: add             SP, SP, #0x10
    // 0x62c5c4: tbnz            w0, #4, #0x62c5d0
    // 0x62c5c8: ldur            x0, [fp, #-8]
    // 0x62c5cc: b               #0x62c6a8
    // 0x62c5d0: ldur            x1, [fp, #-8]
    // 0x62c5d4: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0x62c5d4: mov             x0, #0x76
    //     0x62c5d8: tbz             w1, #0, #0x62c5e8
    //     0x62c5dc: ldur            x0, [x1, #-1]
    //     0x62c5e0: ubfx            x0, x0, #0xc, #0x14
    //     0x62c5e4: lsl             x0, x0, #1
    // 0x62c5e8: cmp             w0, #0x7a
    // 0x62c5ec: b.ne            #0x62c658
    // 0x62c5f0: ldur            x2, [fp, #-0x10]
    // 0x62c5f4: d0 = 0.000000
    //     0x62c5f4: eor             v0.16b, v0.16b, v0.16b
    // 0x62c5f8: LoadField: d1 = r2->field_7
    //     0x62c5f8: ldur            d1, [x2, #7]
    // 0x62c5fc: fcmp            d1, d0
    // 0x62c600: b.vs            #0x62c63c
    // 0x62c604: b.ne            #0x62c63c
    // 0x62c608: LoadField: d2 = r1->field_7
    //     0x62c608: ldur            d2, [x1, #7]
    // 0x62c60c: fadd            d3, d1, d2
    // 0x62c610: r0 = inline_Allocate_Double()
    //     0x62c610: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62c614: add             x0, x0, #0x10
    //     0x62c618: cmp             x1, x0
    //     0x62c61c: b.ls            #0x62cae0
    //     0x62c620: str             x0, [THR, #0x60]  ; THR::top
    //     0x62c624: sub             x0, x0, #0xf
    //     0x62c628: mov             x1, #0xd108
    //     0x62c62c: movk            x1, #3, lsl #16
    //     0x62c630: stur            x1, [x0, #-1]
    // 0x62c634: StoreField: r0->field_7 = d3
    //     0x62c634: stur            d3, [x0, #7]
    // 0x62c638: b               #0x62c6a8
    // 0x62c63c: LoadField: d1 = r1->field_7
    //     0x62c63c: ldur            d1, [x1, #7]
    // 0x62c640: fcmp            d1, d1
    // 0x62c644: b.vc            #0x62c650
    // 0x62c648: mov             x0, x1
    // 0x62c64c: b               #0x62c6a8
    // 0x62c650: mov             x0, x2
    // 0x62c654: b               #0x62c6a8
    // 0x62c658: ldur            x2, [fp, #-0x10]
    // 0x62c65c: d0 = 0.000000
    //     0x62c65c: eor             v0.16b, v0.16b, v0.16b
    // 0x62c660: r0 = 59
    //     0x62c660: mov             x0, #0x3b
    // 0x62c664: branchIfSmi(r1, 0x62c670)
    //     0x62c664: tbz             w1, #0, #0x62c670
    // 0x62c668: r0 = LoadClassIdInstr(r1)
    //     0x62c668: ldur            x0, [x1, #-1]
    //     0x62c66c: ubfx            x0, x0, #0xc, #0x14
    // 0x62c670: stp             xzr, x1, [SP, #-0x10]!
    // 0x62c674: mov             lr, x0
    // 0x62c678: ldr             lr, [x21, lr, lsl #3]
    // 0x62c67c: blr             lr
    // 0x62c680: add             SP, SP, #0x10
    // 0x62c684: tbnz            w0, #4, #0x62c6a4
    // 0x62c688: ldur            x16, [fp, #-0x10]
    // 0x62c68c: SaveReg r16
    //     0x62c68c: str             x16, [SP, #-8]!
    // 0x62c690: r0 = isNegative()
    //     0x62c690: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x62c694: add             SP, SP, #8
    // 0x62c698: tbnz            w0, #4, #0x62c6a4
    // 0x62c69c: ldur            x0, [fp, #-8]
    // 0x62c6a0: b               #0x62c6a8
    // 0x62c6a4: ldur            x0, [fp, #-0x10]
    // 0x62c6a8: ldur            d1, [fp, #-0x48]
    // 0x62c6ac: mov             x5, x0
    // 0x62c6b0: b               #0x62c6c0
    // 0x62c6b4: ldur            d0, [fp, #-0x40]
    // 0x62c6b8: mov             v1.16b, v0.16b
    // 0x62c6bc: ldur            x5, [fp, #-0x10]
    // 0x62c6c0: ldur            x0, [fp, #-0x18]
    // 0x62c6c4: stur            x5, [fp, #-0x20]
    // 0x62c6c8: stur            d1, [fp, #-0x48]
    // 0x62c6cc: LoadField: r3 = r0->field_17
    //     0x62c6cc: ldur            w3, [x0, #0x17]
    // 0x62c6d0: DecompressPointer r3
    //     0x62c6d0: add             x3, x3, HEAP, lsl #32
    // 0x62c6d4: stur            x3, [fp, #-8]
    // 0x62c6d8: cmp             w3, NULL
    // 0x62c6dc: b.eq            #0x62caf0
    // 0x62c6e0: mov             x0, x3
    // 0x62c6e4: r2 = Null
    //     0x62c6e4: mov             x2, NULL
    // 0x62c6e8: r1 = Null
    //     0x62c6e8: mov             x1, NULL
    // 0x62c6ec: r4 = LoadClassIdInstr(r0)
    //     0x62c6ec: ldur            x4, [x0, #-1]
    //     0x62c6f0: ubfx            x4, x4, #0xc, #0x14
    // 0x62c6f4: cmp             x4, #0x809
    // 0x62c6f8: b.eq            #0x62c710
    // 0x62c6fc: r8 = FlexParentData<RenderBox>
    //     0x62c6fc: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x62c700: ldr             x8, [x8, #0x248]
    // 0x62c704: r3 = Null
    //     0x62c704: add             x3, PP, #0x40, lsl #12  ; [pp+0x40bd8] Null
    //     0x62c708: ldr             x3, [x3, #0xbd8]
    // 0x62c70c: r0 = DefaultTypeTest()
    //     0x62c70c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x62c710: ldur            x0, [fp, #-8]
    // 0x62c714: LoadField: r4 = r0->field_13
    //     0x62c714: ldur            w4, [x0, #0x13]
    // 0x62c718: DecompressPointer r4
    //     0x62c718: add             x4, x4, HEAP, lsl #32
    // 0x62c71c: ldur            x6, [fp, #-0x38]
    // 0x62c720: ldur            d1, [fp, #-0x48]
    // 0x62c724: ldur            x5, [fp, #-0x20]
    // 0x62c728: ldr             x3, [fp, #0x28]
    // 0x62c72c: ldr             d0, [fp, #0x18]
    // 0x62c730: b               #0x62c390
    // 0x62c734: mov             v2.16b, v0.16b
    // 0x62c738: mov             x0, x6
    // 0x62c73c: mov             v0.16b, v1.16b
    // 0x62c740: d1 = 0.000000
    //     0x62c740: eor             v1.16b, v1.16b, v1.16b
    // 0x62c744: fsub            d3, d2, d0
    // 0x62c748: scvtf           d0, x0
    // 0x62c74c: fdiv            d2, d3, d0
    // 0x62c750: fcmp            d1, d2
    // 0x62c754: b.vs            #0x62c764
    // 0x62c758: b.le            #0x62c764
    // 0x62c75c: d0 = 0.000000
    //     0x62c75c: eor             v0.16b, v0.16b, v0.16b
    // 0x62c760: b               #0x62c7a0
    // 0x62c764: fcmp            d1, d2
    // 0x62c768: b.vs            #0x62c778
    // 0x62c76c: b.ge            #0x62c778
    // 0x62c770: mov             v0.16b, v2.16b
    // 0x62c774: b               #0x62c7a0
    // 0x62c778: fcmp            d1, d1
    // 0x62c77c: b.vs            #0x62c78c
    // 0x62c780: b.ne            #0x62c78c
    // 0x62c784: fadd            d0, d1, d2
    // 0x62c788: b               #0x62c7a0
    // 0x62c78c: fcmp            d2, d2
    // 0x62c790: b.vc            #0x62c79c
    // 0x62c794: mov             v0.16b, v2.16b
    // 0x62c798: b               #0x62c7a0
    // 0x62c79c: d0 = 0.000000
    //     0x62c79c: eor             v0.16b, v0.16b, v0.16b
    // 0x62c7a0: ldr             x0, [fp, #0x28]
    // 0x62c7a4: stur            d0, [fp, #-0x40]
    // 0x62c7a8: LoadField: r1 = r0->field_67
    //     0x62c7a8: ldur            w1, [x0, #0x67]
    // 0x62c7ac: DecompressPointer r1
    //     0x62c7ac: add             x1, x1, HEAP, lsl #32
    // 0x62c7b0: ldur            x4, [fp, #-0x10]
    // 0x62c7b4: mov             x3, x1
    // 0x62c7b8: stur            x4, [fp, #-0x10]
    // 0x62c7bc: stur            x3, [fp, #-0x18]
    // 0x62c7c0: CheckStackOverflow
    //     0x62c7c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62c7c4: cmp             SP, x16
    //     0x62c7c8: b.ls            #0x62caf4
    // 0x62c7cc: cmp             w3, NULL
    // 0x62c7d0: b.eq            #0x62ca2c
    // 0x62c7d4: LoadField: r5 = r3->field_17
    //     0x62c7d4: ldur            w5, [x3, #0x17]
    // 0x62c7d8: DecompressPointer r5
    //     0x62c7d8: add             x5, x5, HEAP, lsl #32
    // 0x62c7dc: stur            x5, [fp, #-8]
    // 0x62c7e0: cmp             w5, NULL
    // 0x62c7e4: b.eq            #0x62cafc
    // 0x62c7e8: mov             x0, x5
    // 0x62c7ec: r2 = Null
    //     0x62c7ec: mov             x2, NULL
    // 0x62c7f0: r1 = Null
    //     0x62c7f0: mov             x1, NULL
    // 0x62c7f4: r4 = LoadClassIdInstr(r0)
    //     0x62c7f4: ldur            x4, [x0, #-1]
    //     0x62c7f8: ubfx            x4, x4, #0xc, #0x14
    // 0x62c7fc: cmp             x4, #0x809
    // 0x62c800: b.eq            #0x62c818
    // 0x62c804: r8 = FlexParentData<RenderBox>
    //     0x62c804: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x62c808: ldr             x8, [x8, #0x248]
    // 0x62c80c: r3 = Null
    //     0x62c80c: add             x3, PP, #0x40, lsl #12  ; [pp+0x40be8] Null
    //     0x62c810: ldr             x3, [x3, #0xbe8]
    // 0x62c814: r0 = DefaultTypeTest()
    //     0x62c814: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x62c818: ldur            x0, [fp, #-8]
    // 0x62c81c: LoadField: r1 = r0->field_17
    //     0x62c81c: ldur            w1, [x0, #0x17]
    // 0x62c820: DecompressPointer r1
    //     0x62c820: add             x1, x1, HEAP, lsl #32
    // 0x62c824: cmp             w1, NULL
    // 0x62c828: b.ne            #0x62c834
    // 0x62c82c: r0 = 0
    //     0x62c82c: mov             x0, #0
    // 0x62c830: b               #0x62c838
    // 0x62c834: r0 = LoadInt32Instr(r1)
    //     0x62c834: sbfx            x0, x1, #1, #0x1f
    // 0x62c838: cmp             x0, #0
    // 0x62c83c: b.le            #0x62c9c0
    // 0x62c840: ldur            d0, [fp, #-0x40]
    // 0x62c844: lsl             x1, x0, #1
    // 0x62c848: r16 = LoadInt32Instr(r1)
    //     0x62c848: sbfx            x16, x1, #1, #0x1f
    // 0x62c84c: scvtf           d1, w16
    // 0x62c850: fmul            d2, d0, d1
    // 0x62c854: r0 = inline_Allocate_Double()
    //     0x62c854: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62c858: add             x0, x0, #0x10
    //     0x62c85c: cmp             x1, x0
    //     0x62c860: b.ls            #0x62cb00
    //     0x62c864: str             x0, [THR, #0x60]  ; THR::top
    //     0x62c868: sub             x0, x0, #0xf
    //     0x62c86c: mov             x1, #0xd108
    //     0x62c870: movk            x1, #3, lsl #16
    //     0x62c874: stur            x1, [x0, #-1]
    // 0x62c878: StoreField: r0->field_7 = d2
    //     0x62c878: stur            d2, [x0, #7]
    // 0x62c87c: ldr             x16, [fp, #0x20]
    // 0x62c880: ldur            lr, [fp, #-0x18]
    // 0x62c884: stp             lr, x16, [SP, #-0x10]!
    // 0x62c888: SaveReg r0
    //     0x62c888: str             x0, [SP, #-8]!
    // 0x62c88c: ldr             x0, [fp, #0x20]
    // 0x62c890: ClosureCall
    //     0x62c890: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x62c894: ldur            x2, [x0, #0x1f]
    //     0x62c898: blr             x2
    // 0x62c89c: add             SP, SP, #0x18
    // 0x62c8a0: stur            x0, [fp, #-8]
    // 0x62c8a4: ldur            x16, [fp, #-0x10]
    // 0x62c8a8: stp             x0, x16, [SP, #-0x10]!
    // 0x62c8ac: r0 = >()
    //     0x62c8ac: bl              #0xd6719c  ; [dart:core] _Double::>
    // 0x62c8b0: add             SP, SP, #0x10
    // 0x62c8b4: tbnz            w0, #4, #0x62c8c0
    // 0x62c8b8: ldur            x0, [fp, #-0x10]
    // 0x62c8bc: b               #0x62c9b8
    // 0x62c8c0: ldur            x16, [fp, #-0x10]
    // 0x62c8c4: ldur            lr, [fp, #-8]
    // 0x62c8c8: stp             lr, x16, [SP, #-0x10]!
    // 0x62c8cc: r0 = <()
    //     0x62c8cc: bl              #0xd64ef8  ; [dart:core] _Double::<
    // 0x62c8d0: add             SP, SP, #0x10
    // 0x62c8d4: tbnz            w0, #4, #0x62c8e0
    // 0x62c8d8: ldur            x0, [fp, #-8]
    // 0x62c8dc: b               #0x62c9b8
    // 0x62c8e0: ldur            x1, [fp, #-8]
    // 0x62c8e4: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0x62c8e4: mov             x0, #0x76
    //     0x62c8e8: tbz             w1, #0, #0x62c8f8
    //     0x62c8ec: ldur            x0, [x1, #-1]
    //     0x62c8f0: ubfx            x0, x0, #0xc, #0x14
    //     0x62c8f4: lsl             x0, x0, #1
    // 0x62c8f8: cmp             w0, #0x7a
    // 0x62c8fc: b.ne            #0x62c968
    // 0x62c900: ldur            x2, [fp, #-0x10]
    // 0x62c904: d0 = 0.000000
    //     0x62c904: eor             v0.16b, v0.16b, v0.16b
    // 0x62c908: LoadField: d1 = r2->field_7
    //     0x62c908: ldur            d1, [x2, #7]
    // 0x62c90c: fcmp            d1, d0
    // 0x62c910: b.vs            #0x62c94c
    // 0x62c914: b.ne            #0x62c94c
    // 0x62c918: LoadField: d2 = r1->field_7
    //     0x62c918: ldur            d2, [x1, #7]
    // 0x62c91c: fadd            d3, d1, d2
    // 0x62c920: r0 = inline_Allocate_Double()
    //     0x62c920: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62c924: add             x0, x0, #0x10
    //     0x62c928: cmp             x1, x0
    //     0x62c92c: b.ls            #0x62cb10
    //     0x62c930: str             x0, [THR, #0x60]  ; THR::top
    //     0x62c934: sub             x0, x0, #0xf
    //     0x62c938: mov             x1, #0xd108
    //     0x62c93c: movk            x1, #3, lsl #16
    //     0x62c940: stur            x1, [x0, #-1]
    // 0x62c944: StoreField: r0->field_7 = d3
    //     0x62c944: stur            d3, [x0, #7]
    // 0x62c948: b               #0x62c9b8
    // 0x62c94c: LoadField: d1 = r1->field_7
    //     0x62c94c: ldur            d1, [x1, #7]
    // 0x62c950: fcmp            d1, d1
    // 0x62c954: b.vc            #0x62c960
    // 0x62c958: mov             x0, x1
    // 0x62c95c: b               #0x62c9b8
    // 0x62c960: mov             x0, x2
    // 0x62c964: b               #0x62c9b8
    // 0x62c968: ldur            x2, [fp, #-0x10]
    // 0x62c96c: d0 = 0.000000
    //     0x62c96c: eor             v0.16b, v0.16b, v0.16b
    // 0x62c970: r0 = 59
    //     0x62c970: mov             x0, #0x3b
    // 0x62c974: branchIfSmi(r1, 0x62c980)
    //     0x62c974: tbz             w1, #0, #0x62c980
    // 0x62c978: r0 = LoadClassIdInstr(r1)
    //     0x62c978: ldur            x0, [x1, #-1]
    //     0x62c97c: ubfx            x0, x0, #0xc, #0x14
    // 0x62c980: stp             xzr, x1, [SP, #-0x10]!
    // 0x62c984: mov             lr, x0
    // 0x62c988: ldr             lr, [x21, lr, lsl #3]
    // 0x62c98c: blr             lr
    // 0x62c990: add             SP, SP, #0x10
    // 0x62c994: tbnz            w0, #4, #0x62c9b4
    // 0x62c998: ldur            x16, [fp, #-0x10]
    // 0x62c99c: SaveReg r16
    //     0x62c99c: str             x16, [SP, #-8]!
    // 0x62c9a0: r0 = isNegative()
    //     0x62c9a0: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x62c9a4: add             SP, SP, #8
    // 0x62c9a8: tbnz            w0, #4, #0x62c9b4
    // 0x62c9ac: ldur            x0, [fp, #-8]
    // 0x62c9b0: b               #0x62c9b8
    // 0x62c9b4: ldur            x0, [fp, #-0x10]
    // 0x62c9b8: mov             x4, x0
    // 0x62c9bc: b               #0x62c9c4
    // 0x62c9c0: ldur            x4, [fp, #-0x10]
    // 0x62c9c4: ldur            x0, [fp, #-0x18]
    // 0x62c9c8: stur            x4, [fp, #-0x20]
    // 0x62c9cc: LoadField: r3 = r0->field_17
    //     0x62c9cc: ldur            w3, [x0, #0x17]
    // 0x62c9d0: DecompressPointer r3
    //     0x62c9d0: add             x3, x3, HEAP, lsl #32
    // 0x62c9d4: stur            x3, [fp, #-8]
    // 0x62c9d8: cmp             w3, NULL
    // 0x62c9dc: b.eq            #0x62cb20
    // 0x62c9e0: mov             x0, x3
    // 0x62c9e4: r2 = Null
    //     0x62c9e4: mov             x2, NULL
    // 0x62c9e8: r1 = Null
    //     0x62c9e8: mov             x1, NULL
    // 0x62c9ec: r4 = LoadClassIdInstr(r0)
    //     0x62c9ec: ldur            x4, [x0, #-1]
    //     0x62c9f0: ubfx            x4, x4, #0xc, #0x14
    // 0x62c9f4: cmp             x4, #0x809
    // 0x62c9f8: b.eq            #0x62ca10
    // 0x62c9fc: r8 = FlexParentData<RenderBox>
    //     0x62c9fc: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x62ca00: ldr             x8, [x8, #0x248]
    // 0x62ca04: r3 = Null
    //     0x62ca04: add             x3, PP, #0x40, lsl #12  ; [pp+0x40bf8] Null
    //     0x62ca08: ldr             x3, [x3, #0xbf8]
    // 0x62ca0c: r0 = DefaultTypeTest()
    //     0x62ca0c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x62ca10: ldur            x0, [fp, #-8]
    // 0x62ca14: LoadField: r3 = r0->field_13
    //     0x62ca14: ldur            w3, [x0, #0x13]
    // 0x62ca18: DecompressPointer r3
    //     0x62ca18: add             x3, x3, HEAP, lsl #32
    // 0x62ca1c: ldur            x4, [fp, #-0x20]
    // 0x62ca20: ldur            d0, [fp, #-0x40]
    // 0x62ca24: d1 = 0.000000
    //     0x62ca24: eor             v1.16b, v1.16b, v1.16b
    // 0x62ca28: b               #0x62c7b8
    // 0x62ca2c: mov             x0, x4
    // 0x62ca30: LoadField: d0 = r0->field_7
    //     0x62ca30: ldur            d0, [x0, #7]
    // 0x62ca34: LeaveFrame
    //     0x62ca34: mov             SP, fp
    //     0x62ca38: ldp             fp, lr, [SP], #0x10
    // 0x62ca3c: ret
    //     0x62ca3c: ret             
    // 0x62ca40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62ca40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62ca44: b               #0x62bff4
    // 0x62ca48: SaveReg d0
    //     0x62ca48: str             q0, [SP, #-0x10]!
    // 0x62ca4c: SaveReg r0
    //     0x62ca4c: str             x0, [SP, #-8]!
    // 0x62ca50: r0 = AllocateDouble()
    //     0x62ca50: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62ca54: mov             x3, x0
    // 0x62ca58: RestoreReg r0
    //     0x62ca58: ldr             x0, [SP], #8
    // 0x62ca5c: RestoreReg d0
    //     0x62ca5c: ldr             q0, [SP], #0x10
    // 0x62ca60: b               #0x62c064
    // 0x62ca64: SaveReg d0
    //     0x62ca64: str             q0, [SP, #-0x10]!
    // 0x62ca68: stp             x0, x3, [SP, #-0x10]!
    // 0x62ca6c: r0 = AllocateDouble()
    //     0x62ca6c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62ca70: mov             x4, x0
    // 0x62ca74: ldp             x0, x3, [SP], #0x10
    // 0x62ca78: RestoreReg d0
    //     0x62ca78: ldr             q0, [SP], #0x10
    // 0x62ca7c: b               #0x62c090
    // 0x62ca80: r0 = StackOverflowSharedWithFPURegs()
    //     0x62ca80: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x62ca84: b               #0x62c0c4
    // 0x62ca88: r0 = NullCastErrorSharedWithFPURegs()
    //     0x62ca88: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x62ca8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x62ca8c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x62ca90: r0 = NullErrorSharedWithFPURegs()
    //     0x62ca90: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x62ca94: SaveReg d1
    //     0x62ca94: str             q1, [SP, #-0x10]!
    // 0x62ca98: SaveReg r0
    //     0x62ca98: str             x0, [SP, #-8]!
    // 0x62ca9c: r0 = AllocateDouble()
    //     0x62ca9c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62caa0: mov             x1, x0
    // 0x62caa4: RestoreReg r0
    //     0x62caa4: ldr             x0, [SP], #8
    // 0x62caa8: RestoreReg d1
    //     0x62caa8: ldr             q1, [SP], #0x10
    // 0x62caac: b               #0x62c2c8
    // 0x62cab0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x62cab0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x62cab4: r0 = StackOverflowSharedWithFPURegs()
    //     0x62cab4: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x62cab8: b               #0x62c3ac
    // 0x62cabc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x62cabc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x62cac0: SaveReg d0
    //     0x62cac0: str             q0, [SP, #-0x10]!
    // 0x62cac4: r0 = AllocateDouble()
    //     0x62cac4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62cac8: RestoreReg d0
    //     0x62cac8: ldr             q0, [SP], #0x10
    // 0x62cacc: b               #0x62c4b8
    // 0x62cad0: SaveReg d0
    //     0x62cad0: str             q0, [SP, #-0x10]!
    // 0x62cad4: r0 = AllocateDouble()
    //     0x62cad4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62cad8: RestoreReg d0
    //     0x62cad8: ldr             q0, [SP], #0x10
    // 0x62cadc: b               #0x62c558
    // 0x62cae0: stp             q0, q3, [SP, #-0x20]!
    // 0x62cae4: r0 = AllocateDouble()
    //     0x62cae4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62cae8: ldp             q0, q3, [SP], #0x20
    // 0x62caec: b               #0x62c634
    // 0x62caf0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x62caf0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x62caf4: r0 = StackOverflowSharedWithFPURegs()
    //     0x62caf4: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x62caf8: b               #0x62c7cc
    // 0x62cafc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x62cafc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x62cb00: stp             q0, q2, [SP, #-0x20]!
    // 0x62cb04: r0 = AllocateDouble()
    //     0x62cb04: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62cb08: ldp             q0, q2, [SP], #0x20
    // 0x62cb0c: b               #0x62c878
    // 0x62cb10: stp             q0, q3, [SP, #-0x20]!
    // 0x62cb14: r0 = AllocateDouble()
    //     0x62cb14: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62cb18: ldp             q0, q3, [SP], #0x20
    // 0x62cb1c: b               #0x62c944
    // 0x62cb20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x62cb20: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] double <anonymous closure>(dynamic, RenderBox, double) {
    // ** addr: 0x62cdf0, size: 0x7c
    // 0x62cdf0: EnterFrame
    //     0x62cdf0: stp             fp, lr, [SP, #-0x10]!
    //     0x62cdf4: mov             fp, SP
    // 0x62cdf8: CheckStackOverflow
    //     0x62cdf8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62cdfc: cmp             SP, x16
    //     0x62ce00: b.ls            #0x62ce54
    // 0x62ce04: ldr             x0, [fp, #0x10]
    // 0x62ce08: LoadField: d0 = r0->field_7
    //     0x62ce08: ldur            d0, [x0, #7]
    // 0x62ce0c: ldr             x16, [fp, #0x18]
    // 0x62ce10: SaveReg r16
    //     0x62ce10: str             x16, [SP, #-8]!
    // 0x62ce14: SaveReg d0
    //     0x62ce14: str             d0, [SP, #-8]!
    // 0x62ce18: r0 = getMaxIntrinsicHeight()
    //     0x62ce18: bl              #0x62cb24  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0x62ce1c: add             SP, SP, #0x10
    // 0x62ce20: r0 = inline_Allocate_Double()
    //     0x62ce20: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62ce24: add             x0, x0, #0x10
    //     0x62ce28: cmp             x1, x0
    //     0x62ce2c: b.ls            #0x62ce5c
    //     0x62ce30: str             x0, [THR, #0x60]  ; THR::top
    //     0x62ce34: sub             x0, x0, #0xf
    //     0x62ce38: mov             x1, #0xd108
    //     0x62ce3c: movk            x1, #3, lsl #16
    //     0x62ce40: stur            x1, [x0, #-1]
    // 0x62ce44: StoreField: r0->field_7 = d0
    //     0x62ce44: stur            d0, [x0, #7]
    // 0x62ce48: LeaveFrame
    //     0x62ce48: mov             SP, fp
    //     0x62ce4c: ldp             fp, lr, [SP], #0x10
    // 0x62ce50: ret
    //     0x62ce50: ret             
    // 0x62ce54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62ce54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62ce58: b               #0x62ce04
    // 0x62ce5c: SaveReg d0
    //     0x62ce5c: str             q0, [SP, #-0x10]!
    // 0x62ce60: r0 = AllocateDouble()
    //     0x62ce60: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62ce64: RestoreReg d0
    //     0x62ce64: ldr             q0, [SP], #0x10
    // 0x62ce68: b               #0x62ce44
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x634818, size: 0x18
    // 0x634818: r4 = 0
    //     0x634818: mov             x4, #0
    // 0x63481c: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x63481c: add             x17, PP, #0x40, lsl #12  ; [pp+0x40b80] AnonymousClosure: (0x634830), in [package:flutter/src/rendering/flex.dart] RenderFlex::computeMaxIntrinsicWidth (0x63487c)
    //     0x634820: ldr             x1, [x17, #0xb80]
    // 0x634824: r24 = BuildNonGenericMethodExtractorStub
    //     0x634824: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x634828: LoadField: r0 = r24->field_17
    //     0x634828: ldur            x0, [x24, #0x17]
    // 0x63482c: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x634830, size: 0x4c
    // 0x634830: EnterFrame
    //     0x634830: stp             fp, lr, [SP, #-0x10]!
    //     0x634834: mov             fp, SP
    // 0x634838: ldr             x0, [fp, #0x18]
    // 0x63483c: LoadField: r1 = r0->field_17
    //     0x63483c: ldur            w1, [x0, #0x17]
    // 0x634840: DecompressPointer r1
    //     0x634840: add             x1, x1, HEAP, lsl #32
    // 0x634844: CheckStackOverflow
    //     0x634844: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x634848: cmp             SP, x16
    //     0x63484c: b.ls            #0x634874
    // 0x634850: LoadField: r0 = r1->field_f
    //     0x634850: ldur            w0, [x1, #0xf]
    // 0x634854: DecompressPointer r0
    //     0x634854: add             x0, x0, HEAP, lsl #32
    // 0x634858: ldr             x16, [fp, #0x10]
    // 0x63485c: stp             x16, x0, [SP, #-0x10]!
    // 0x634860: r0 = computeMaxIntrinsicWidth()
    //     0x634860: bl              #0x63487c  ; [package:flutter/src/rendering/flex.dart] RenderFlex::computeMaxIntrinsicWidth
    // 0x634864: add             SP, SP, #0x10
    // 0x634868: LeaveFrame
    //     0x634868: mov             SP, fp
    //     0x63486c: ldp             fp, lr, [SP], #0x10
    // 0x634870: ret
    //     0x634870: ret             
    // 0x634874: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x634874: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x634878: b               #0x634850
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0x63487c, size: 0xa4
    // 0x63487c: EnterFrame
    //     0x63487c: stp             fp, lr, [SP, #-0x10]!
    //     0x634880: mov             fp, SP
    // 0x634884: AllocStack(0x8)
    //     0x634884: sub             SP, SP, #8
    // 0x634888: CheckStackOverflow
    //     0x634888: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63488c: cmp             SP, x16
    //     0x634890: b.ls            #0x634908
    // 0x634894: ldr             x0, [fp, #0x10]
    // 0x634898: LoadField: d0 = r0->field_7
    //     0x634898: ldur            d0, [x0, #7]
    // 0x63489c: stur            d0, [fp, #-8]
    // 0x6348a0: r1 = Function '<anonymous closure>':.
    //     0x6348a0: add             x1, PP, #0x40, lsl #12  ; [pp+0x40b88] AnonymousClosure: (0x634920), in [package:flutter/src/rendering/flex.dart] RenderFlex::computeMaxIntrinsicWidth (0x63487c)
    //     0x6348a4: ldr             x1, [x1, #0xb88]
    // 0x6348a8: r2 = Null
    //     0x6348a8: mov             x2, NULL
    // 0x6348ac: r0 = AllocateClosure()
    //     0x6348ac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6348b0: ldr             x16, [fp, #0x18]
    // 0x6348b4: stp             x0, x16, [SP, #-0x10]!
    // 0x6348b8: ldur            d0, [fp, #-8]
    // 0x6348bc: SaveReg d0
    //     0x6348bc: str             d0, [SP, #-8]!
    // 0x6348c0: r16 = Instance_Axis
    //     0x6348c0: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x6348c4: ldr             x16, [x16, #0x440]
    // 0x6348c8: SaveReg r16
    //     0x6348c8: str             x16, [SP, #-8]!
    // 0x6348cc: r0 = _getIntrinsicSize()
    //     0x6348cc: bl              #0x62bfdc  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_getIntrinsicSize
    // 0x6348d0: add             SP, SP, #0x20
    // 0x6348d4: r0 = inline_Allocate_Double()
    //     0x6348d4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6348d8: add             x0, x0, #0x10
    //     0x6348dc: cmp             x1, x0
    //     0x6348e0: b.ls            #0x634910
    //     0x6348e4: str             x0, [THR, #0x60]  ; THR::top
    //     0x6348e8: sub             x0, x0, #0xf
    //     0x6348ec: mov             x1, #0xd108
    //     0x6348f0: movk            x1, #3, lsl #16
    //     0x6348f4: stur            x1, [x0, #-1]
    // 0x6348f8: StoreField: r0->field_7 = d0
    //     0x6348f8: stur            d0, [x0, #7]
    // 0x6348fc: LeaveFrame
    //     0x6348fc: mov             SP, fp
    //     0x634900: ldp             fp, lr, [SP], #0x10
    // 0x634904: ret
    //     0x634904: ret             
    // 0x634908: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x634908: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63490c: b               #0x634894
    // 0x634910: SaveReg d0
    //     0x634910: str             q0, [SP, #-0x10]!
    // 0x634914: r0 = AllocateDouble()
    //     0x634914: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x634918: RestoreReg d0
    //     0x634918: ldr             q0, [SP], #0x10
    // 0x63491c: b               #0x6348f8
  }
  [closure] double <anonymous closure>(dynamic, RenderBox, double) {
    // ** addr: 0x634920, size: 0x7c
    // 0x634920: EnterFrame
    //     0x634920: stp             fp, lr, [SP, #-0x10]!
    //     0x634924: mov             fp, SP
    // 0x634928: CheckStackOverflow
    //     0x634928: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63492c: cmp             SP, x16
    //     0x634930: b.ls            #0x634984
    // 0x634934: ldr             x0, [fp, #0x10]
    // 0x634938: LoadField: d0 = r0->field_7
    //     0x634938: ldur            d0, [x0, #7]
    // 0x63493c: ldr             x16, [fp, #0x18]
    // 0x634940: SaveReg r16
    //     0x634940: str             x16, [SP, #-8]!
    // 0x634944: SaveReg d0
    //     0x634944: str             d0, [SP, #-8]!
    // 0x634948: r0 = getMaxIntrinsicWidth()
    //     0x634948: bl              #0x62cb94  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0x63494c: add             SP, SP, #0x10
    // 0x634950: r0 = inline_Allocate_Double()
    //     0x634950: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x634954: add             x0, x0, #0x10
    //     0x634958: cmp             x1, x0
    //     0x63495c: b.ls            #0x63498c
    //     0x634960: str             x0, [THR, #0x60]  ; THR::top
    //     0x634964: sub             x0, x0, #0xf
    //     0x634968: mov             x1, #0xd108
    //     0x63496c: movk            x1, #3, lsl #16
    //     0x634970: stur            x1, [x0, #-1]
    // 0x634974: StoreField: r0->field_7 = d0
    //     0x634974: stur            d0, [x0, #7]
    // 0x634978: LeaveFrame
    //     0x634978: mov             SP, fp
    //     0x63497c: ldp             fp, lr, [SP], #0x10
    // 0x634980: ret
    //     0x634980: ret             
    // 0x634984: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x634984: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x634988: b               #0x634934
    // 0x63498c: SaveReg d0
    //     0x63498c: str             q0, [SP, #-0x10]!
    // 0x634990: r0 = AllocateDouble()
    //     0x634990: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x634994: RestoreReg d0
    //     0x634994: ldr             q0, [SP], #0x10
    // 0x634998: b               #0x634974
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x6382d4, size: 0x18
    // 0x6382d4: r4 = 0
    //     0x6382d4: mov             x4, #0
    // 0x6382d8: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x6382d8: add             x17, PP, #0x53, lsl #12  ; [pp+0x53668] AnonymousClosure: (0x6382ec), in [package:flutter/src/rendering/flex.dart] RenderFlex::computeMinIntrinsicHeight (0x638338)
    //     0x6382dc: ldr             x1, [x17, #0x668]
    // 0x6382e0: r24 = BuildNonGenericMethodExtractorStub
    //     0x6382e0: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x6382e4: LoadField: r0 = r24->field_17
    //     0x6382e4: ldur            x0, [x24, #0x17]
    // 0x6382e8: br              x0
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x6382ec, size: 0x4c
    // 0x6382ec: EnterFrame
    //     0x6382ec: stp             fp, lr, [SP, #-0x10]!
    //     0x6382f0: mov             fp, SP
    // 0x6382f4: ldr             x0, [fp, #0x18]
    // 0x6382f8: LoadField: r1 = r0->field_17
    //     0x6382f8: ldur            w1, [x0, #0x17]
    // 0x6382fc: DecompressPointer r1
    //     0x6382fc: add             x1, x1, HEAP, lsl #32
    // 0x638300: CheckStackOverflow
    //     0x638300: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x638304: cmp             SP, x16
    //     0x638308: b.ls            #0x638330
    // 0x63830c: LoadField: r0 = r1->field_f
    //     0x63830c: ldur            w0, [x1, #0xf]
    // 0x638310: DecompressPointer r0
    //     0x638310: add             x0, x0, HEAP, lsl #32
    // 0x638314: ldr             x16, [fp, #0x10]
    // 0x638318: stp             x16, x0, [SP, #-0x10]!
    // 0x63831c: r0 = computeMinIntrinsicHeight()
    //     0x63831c: bl              #0x638338  ; [package:flutter/src/rendering/flex.dart] RenderFlex::computeMinIntrinsicHeight
    // 0x638320: add             SP, SP, #0x10
    // 0x638324: LeaveFrame
    //     0x638324: mov             SP, fp
    //     0x638328: ldp             fp, lr, [SP], #0x10
    // 0x63832c: ret
    //     0x63832c: ret             
    // 0x638330: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x638330: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x638334: b               #0x63830c
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0x638338, size: 0xa4
    // 0x638338: EnterFrame
    //     0x638338: stp             fp, lr, [SP, #-0x10]!
    //     0x63833c: mov             fp, SP
    // 0x638340: AllocStack(0x8)
    //     0x638340: sub             SP, SP, #8
    // 0x638344: CheckStackOverflow
    //     0x638344: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x638348: cmp             SP, x16
    //     0x63834c: b.ls            #0x6383c4
    // 0x638350: ldr             x0, [fp, #0x10]
    // 0x638354: LoadField: d0 = r0->field_7
    //     0x638354: ldur            d0, [x0, #7]
    // 0x638358: stur            d0, [fp, #-8]
    // 0x63835c: r1 = Function '<anonymous closure>':.
    //     0x63835c: add             x1, PP, #0x53, lsl #12  ; [pp+0x53670] AnonymousClosure: (0x6383dc), in [package:flutter/src/rendering/flex.dart] RenderFlex::computeMinIntrinsicHeight (0x638338)
    //     0x638360: ldr             x1, [x1, #0x670]
    // 0x638364: r2 = Null
    //     0x638364: mov             x2, NULL
    // 0x638368: r0 = AllocateClosure()
    //     0x638368: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x63836c: ldr             x16, [fp, #0x18]
    // 0x638370: stp             x0, x16, [SP, #-0x10]!
    // 0x638374: ldur            d0, [fp, #-8]
    // 0x638378: SaveReg d0
    //     0x638378: str             d0, [SP, #-8]!
    // 0x63837c: r16 = Instance_Axis
    //     0x63837c: add             x16, PP, #0xe, lsl #12  ; [pp+0xef00] Obj!Axis@b64ff1
    //     0x638380: ldr             x16, [x16, #0xf00]
    // 0x638384: SaveReg r16
    //     0x638384: str             x16, [SP, #-8]!
    // 0x638388: r0 = _getIntrinsicSize()
    //     0x638388: bl              #0x62bfdc  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_getIntrinsicSize
    // 0x63838c: add             SP, SP, #0x20
    // 0x638390: r0 = inline_Allocate_Double()
    //     0x638390: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x638394: add             x0, x0, #0x10
    //     0x638398: cmp             x1, x0
    //     0x63839c: b.ls            #0x6383cc
    //     0x6383a0: str             x0, [THR, #0x60]  ; THR::top
    //     0x6383a4: sub             x0, x0, #0xf
    //     0x6383a8: mov             x1, #0xd108
    //     0x6383ac: movk            x1, #3, lsl #16
    //     0x6383b0: stur            x1, [x0, #-1]
    // 0x6383b4: StoreField: r0->field_7 = d0
    //     0x6383b4: stur            d0, [x0, #7]
    // 0x6383b8: LeaveFrame
    //     0x6383b8: mov             SP, fp
    //     0x6383bc: ldp             fp, lr, [SP], #0x10
    // 0x6383c0: ret
    //     0x6383c0: ret             
    // 0x6383c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6383c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6383c8: b               #0x638350
    // 0x6383cc: SaveReg d0
    //     0x6383cc: str             q0, [SP, #-0x10]!
    // 0x6383d0: r0 = AllocateDouble()
    //     0x6383d0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6383d4: RestoreReg d0
    //     0x6383d4: ldr             q0, [SP], #0x10
    // 0x6383d8: b               #0x6383b4
  }
  [closure] double <anonymous closure>(dynamic, RenderBox, double) {
    // ** addr: 0x6383dc, size: 0x7c
    // 0x6383dc: EnterFrame
    //     0x6383dc: stp             fp, lr, [SP, #-0x10]!
    //     0x6383e0: mov             fp, SP
    // 0x6383e4: CheckStackOverflow
    //     0x6383e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6383e8: cmp             SP, x16
    //     0x6383ec: b.ls            #0x638440
    // 0x6383f0: ldr             x0, [fp, #0x10]
    // 0x6383f4: LoadField: d0 = r0->field_7
    //     0x6383f4: ldur            d0, [x0, #7]
    // 0x6383f8: ldr             x16, [fp, #0x18]
    // 0x6383fc: SaveReg r16
    //     0x6383fc: str             x16, [SP, #-8]!
    // 0x638400: SaveReg d0
    //     0x638400: str             d0, [SP, #-8]!
    // 0x638404: r0 = getMinIntrinsicHeight()
    //     0x638404: bl              #0x630a58  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0x638408: add             SP, SP, #0x10
    // 0x63840c: r0 = inline_Allocate_Double()
    //     0x63840c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x638410: add             x0, x0, #0x10
    //     0x638414: cmp             x1, x0
    //     0x638418: b.ls            #0x638448
    //     0x63841c: str             x0, [THR, #0x60]  ; THR::top
    //     0x638420: sub             x0, x0, #0xf
    //     0x638424: mov             x1, #0xd108
    //     0x638428: movk            x1, #3, lsl #16
    //     0x63842c: stur            x1, [x0, #-1]
    // 0x638430: StoreField: r0->field_7 = d0
    //     0x638430: stur            d0, [x0, #7]
    // 0x638434: LeaveFrame
    //     0x638434: mov             SP, fp
    //     0x638438: ldp             fp, lr, [SP], #0x10
    // 0x63843c: ret
    //     0x63843c: ret             
    // 0x638440: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x638440: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x638444: b               #0x6383f0
    // 0x638448: SaveReg d0
    //     0x638448: str             q0, [SP, #-0x10]!
    // 0x63844c: r0 = AllocateDouble()
    //     0x63844c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x638450: RestoreReg d0
    //     0x638450: ldr             q0, [SP], #0x10
    // 0x638454: b               #0x638430
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63a5ec, size: 0x18
    // 0x63a5ec: r4 = 0
    //     0x63a5ec: mov             x4, #0
    // 0x63a5f0: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63a5f0: add             x17, PP, #0x51, lsl #12  ; [pp+0x51130] AnonymousClosure: (0x63a604), in [package:flutter/src/rendering/flex.dart] RenderFlex::computeMinIntrinsicWidth (0x63a650)
    //     0x63a5f4: ldr             x1, [x17, #0x130]
    // 0x63a5f8: r24 = BuildNonGenericMethodExtractorStub
    //     0x63a5f8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63a5fc: LoadField: r0 = r24->field_17
    //     0x63a5fc: ldur            x0, [x24, #0x17]
    // 0x63a600: br              x0
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63a604, size: 0x4c
    // 0x63a604: EnterFrame
    //     0x63a604: stp             fp, lr, [SP, #-0x10]!
    //     0x63a608: mov             fp, SP
    // 0x63a60c: ldr             x0, [fp, #0x18]
    // 0x63a610: LoadField: r1 = r0->field_17
    //     0x63a610: ldur            w1, [x0, #0x17]
    // 0x63a614: DecompressPointer r1
    //     0x63a614: add             x1, x1, HEAP, lsl #32
    // 0x63a618: CheckStackOverflow
    //     0x63a618: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63a61c: cmp             SP, x16
    //     0x63a620: b.ls            #0x63a648
    // 0x63a624: LoadField: r0 = r1->field_f
    //     0x63a624: ldur            w0, [x1, #0xf]
    // 0x63a628: DecompressPointer r0
    //     0x63a628: add             x0, x0, HEAP, lsl #32
    // 0x63a62c: ldr             x16, [fp, #0x10]
    // 0x63a630: stp             x16, x0, [SP, #-0x10]!
    // 0x63a634: r0 = computeMinIntrinsicWidth()
    //     0x63a634: bl              #0x63a650  ; [package:flutter/src/rendering/flex.dart] RenderFlex::computeMinIntrinsicWidth
    // 0x63a638: add             SP, SP, #0x10
    // 0x63a63c: LeaveFrame
    //     0x63a63c: mov             SP, fp
    //     0x63a640: ldp             fp, lr, [SP], #0x10
    // 0x63a644: ret
    //     0x63a644: ret             
    // 0x63a648: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63a648: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63a64c: b               #0x63a624
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0x63a650, size: 0xa4
    // 0x63a650: EnterFrame
    //     0x63a650: stp             fp, lr, [SP, #-0x10]!
    //     0x63a654: mov             fp, SP
    // 0x63a658: AllocStack(0x8)
    //     0x63a658: sub             SP, SP, #8
    // 0x63a65c: CheckStackOverflow
    //     0x63a65c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63a660: cmp             SP, x16
    //     0x63a664: b.ls            #0x63a6dc
    // 0x63a668: ldr             x0, [fp, #0x10]
    // 0x63a66c: LoadField: d0 = r0->field_7
    //     0x63a66c: ldur            d0, [x0, #7]
    // 0x63a670: stur            d0, [fp, #-8]
    // 0x63a674: r1 = Function '<anonymous closure>':.
    //     0x63a674: add             x1, PP, #0x51, lsl #12  ; [pp+0x51138] AnonymousClosure: (0x63a6f4), in [package:flutter/src/rendering/flex.dart] RenderFlex::computeMinIntrinsicWidth (0x63a650)
    //     0x63a678: ldr             x1, [x1, #0x138]
    // 0x63a67c: r2 = Null
    //     0x63a67c: mov             x2, NULL
    // 0x63a680: r0 = AllocateClosure()
    //     0x63a680: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x63a684: ldr             x16, [fp, #0x18]
    // 0x63a688: stp             x0, x16, [SP, #-0x10]!
    // 0x63a68c: ldur            d0, [fp, #-8]
    // 0x63a690: SaveReg d0
    //     0x63a690: str             d0, [SP, #-8]!
    // 0x63a694: r16 = Instance_Axis
    //     0x63a694: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x63a698: ldr             x16, [x16, #0x440]
    // 0x63a69c: SaveReg r16
    //     0x63a69c: str             x16, [SP, #-8]!
    // 0x63a6a0: r0 = _getIntrinsicSize()
    //     0x63a6a0: bl              #0x62bfdc  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_getIntrinsicSize
    // 0x63a6a4: add             SP, SP, #0x20
    // 0x63a6a8: r0 = inline_Allocate_Double()
    //     0x63a6a8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63a6ac: add             x0, x0, #0x10
    //     0x63a6b0: cmp             x1, x0
    //     0x63a6b4: b.ls            #0x63a6e4
    //     0x63a6b8: str             x0, [THR, #0x60]  ; THR::top
    //     0x63a6bc: sub             x0, x0, #0xf
    //     0x63a6c0: mov             x1, #0xd108
    //     0x63a6c4: movk            x1, #3, lsl #16
    //     0x63a6c8: stur            x1, [x0, #-1]
    // 0x63a6cc: StoreField: r0->field_7 = d0
    //     0x63a6cc: stur            d0, [x0, #7]
    // 0x63a6d0: LeaveFrame
    //     0x63a6d0: mov             SP, fp
    //     0x63a6d4: ldp             fp, lr, [SP], #0x10
    // 0x63a6d8: ret
    //     0x63a6d8: ret             
    // 0x63a6dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63a6dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63a6e0: b               #0x63a668
    // 0x63a6e4: SaveReg d0
    //     0x63a6e4: str             q0, [SP, #-0x10]!
    // 0x63a6e8: r0 = AllocateDouble()
    //     0x63a6e8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63a6ec: RestoreReg d0
    //     0x63a6ec: ldr             q0, [SP], #0x10
    // 0x63a6f0: b               #0x63a6cc
  }
  [closure] double <anonymous closure>(dynamic, RenderBox, double) {
    // ** addr: 0x63a6f4, size: 0x7c
    // 0x63a6f4: EnterFrame
    //     0x63a6f4: stp             fp, lr, [SP, #-0x10]!
    //     0x63a6f8: mov             fp, SP
    // 0x63a6fc: CheckStackOverflow
    //     0x63a6fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63a700: cmp             SP, x16
    //     0x63a704: b.ls            #0x63a758
    // 0x63a708: ldr             x0, [fp, #0x10]
    // 0x63a70c: LoadField: d0 = r0->field_7
    //     0x63a70c: ldur            d0, [x0, #7]
    // 0x63a710: ldr             x16, [fp, #0x18]
    // 0x63a714: SaveReg r16
    //     0x63a714: str             x16, [SP, #-8]!
    // 0x63a718: SaveReg d0
    //     0x63a718: str             d0, [SP, #-8]!
    // 0x63a71c: r0 = getMinIntrinsicWidth()
    //     0x63a71c: bl              #0x630b18  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicWidth
    // 0x63a720: add             SP, SP, #0x10
    // 0x63a724: r0 = inline_Allocate_Double()
    //     0x63a724: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63a728: add             x0, x0, #0x10
    //     0x63a72c: cmp             x1, x0
    //     0x63a730: b.ls            #0x63a760
    //     0x63a734: str             x0, [THR, #0x60]  ; THR::top
    //     0x63a738: sub             x0, x0, #0xf
    //     0x63a73c: mov             x1, #0xd108
    //     0x63a740: movk            x1, #3, lsl #16
    //     0x63a744: stur            x1, [x0, #-1]
    // 0x63a748: StoreField: r0->field_7 = d0
    //     0x63a748: stur            d0, [x0, #7]
    // 0x63a74c: LeaveFrame
    //     0x63a74c: mov             SP, fp
    //     0x63a750: ldp             fp, lr, [SP], #0x10
    // 0x63a754: ret
    //     0x63a754: ret             
    // 0x63a758: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63a758: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63a75c: b               #0x63a708
    // 0x63a760: SaveReg d0
    //     0x63a760: str             q0, [SP, #-0x10]!
    // 0x63a764: r0 = AllocateDouble()
    //     0x63a764: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63a768: RestoreReg d0
    //     0x63a768: ldr             q0, [SP], #0x10
    // 0x63a76c: b               #0x63a748
  }
  _ computeDistanceToActualBaseline(/* No info */) {
    // ** addr: 0x63d488, size: 0x70
    // 0x63d488: EnterFrame
    //     0x63d488: stp             fp, lr, [SP, #-0x10]!
    //     0x63d48c: mov             fp, SP
    // 0x63d490: CheckStackOverflow
    //     0x63d490: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63d494: cmp             SP, x16
    //     0x63d498: b.ls            #0x63d4f0
    // 0x63d49c: ldr             x0, [fp, #0x18]
    // 0x63d4a0: LoadField: r1 = r0->field_73
    //     0x63d4a0: ldur            w1, [x0, #0x73]
    // 0x63d4a4: DecompressPointer r1
    //     0x63d4a4: add             x1, x1, HEAP, lsl #32
    // 0x63d4a8: r16 = Instance_Axis
    //     0x63d4a8: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x63d4ac: ldr             x16, [x16, #0x440]
    // 0x63d4b0: cmp             w1, w16
    // 0x63d4b4: b.ne            #0x63d4d4
    // 0x63d4b8: ldr             x16, [fp, #0x10]
    // 0x63d4bc: stp             x16, x0, [SP, #-0x10]!
    // 0x63d4c0: r0 = defaultComputeDistanceToHighestActualBaseline()
    //     0x63d4c0: bl              #0x63d800  ; [package:flutter/src/rendering/flex.dart] _RenderFlex&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultComputeDistanceToHighestActualBaseline
    // 0x63d4c4: add             SP, SP, #0x10
    // 0x63d4c8: LeaveFrame
    //     0x63d4c8: mov             SP, fp
    //     0x63d4cc: ldp             fp, lr, [SP], #0x10
    // 0x63d4d0: ret
    //     0x63d4d0: ret             
    // 0x63d4d4: ldr             x16, [fp, #0x10]
    // 0x63d4d8: stp             x16, x0, [SP, #-0x10]!
    // 0x63d4dc: r0 = defaultComputeDistanceToFirstActualBaseline()
    //     0x63d4dc: bl              #0x63d4f8  ; [package:flutter/src/rendering/flex.dart] _RenderFlex&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultComputeDistanceToFirstActualBaseline
    // 0x63d4e0: add             SP, SP, #0x10
    // 0x63d4e4: LeaveFrame
    //     0x63d4e4: mov             SP, fp
    //     0x63d4e8: ldp             fp, lr, [SP], #0x10
    // 0x63d4ec: ret
    //     0x63d4ec: ret             
    // 0x63d4f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63d4f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63d4f4: b               #0x63d49c
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0x64b83c, size: 0x6c
    // 0x64b83c: EnterFrame
    //     0x64b83c: stp             fp, lr, [SP, #-0x10]!
    //     0x64b840: mov             fp, SP
    // 0x64b844: ldr             x0, [fp, #0x10]
    // 0x64b848: LoadField: r1 = r0->field_17
    //     0x64b848: ldur            w1, [x0, #0x17]
    // 0x64b84c: DecompressPointer r1
    //     0x64b84c: add             x1, x1, HEAP, lsl #32
    // 0x64b850: r2 = LoadClassIdInstr(r1)
    //     0x64b850: ldur            x2, [x1, #-1]
    //     0x64b854: ubfx            x2, x2, #0xc, #0x14
    // 0x64b858: lsl             x2, x2, #1
    // 0x64b85c: r17 = 4114
    //     0x64b85c: mov             x17, #0x1012
    // 0x64b860: cmp             w2, w17
    // 0x64b864: b.eq            #0x64b898
    // 0x64b868: r1 = <RenderBox>
    //     0x64b868: ldr             x1, [PP, #0x3b20]  ; [pp+0x3b20] TypeArguments: <RenderBox>
    // 0x64b86c: r0 = FlexParentData()
    //     0x64b86c: bl              #0x64b8a8  ; AllocateFlexParentDataStub -> FlexParentData (size=0x20)
    // 0x64b870: r1 = Instance_Offset
    //     0x64b870: ldr             x1, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x64b874: StoreField: r0->field_7 = r1
    //     0x64b874: stur            w1, [x0, #7]
    // 0x64b878: ldr             x1, [fp, #0x10]
    // 0x64b87c: StoreField: r1->field_17 = r0
    //     0x64b87c: stur            w0, [x1, #0x17]
    //     0x64b880: ldurb           w16, [x1, #-1]
    //     0x64b884: ldurb           w17, [x0, #-1]
    //     0x64b888: and             x16, x17, x16, lsr #2
    //     0x64b88c: tst             x16, HEAP, lsr #32
    //     0x64b890: b.eq            #0x64b898
    //     0x64b894: bl              #0xd6826c
    // 0x64b898: r0 = Null
    //     0x64b898: mov             x0, NULL
    // 0x64b89c: LeaveFrame
    //     0x64b89c: mov             SP, fp
    //     0x64b8a0: ldp             fp, lr, [SP], #0x10
    // 0x64b8a4: ret
    //     0x64b8a4: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x6524ec, size: 0x54
    // 0x6524ec: EnterFrame
    //     0x6524ec: stp             fp, lr, [SP, #-0x10]!
    //     0x6524f0: mov             fp, SP
    // 0x6524f4: CheckStackOverflow
    //     0x6524f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6524f8: cmp             SP, x16
    //     0x6524fc: b.ls            #0x652538
    // 0x652500: ldr             x0, [fp, #0x10]
    // 0x652504: LoadField: r1 = r0->field_9b
    //     0x652504: ldur            w1, [x0, #0x9b]
    // 0x652508: DecompressPointer r1
    //     0x652508: add             x1, x1, HEAP, lsl #32
    // 0x65250c: stp             NULL, x1, [SP, #-0x10]!
    // 0x652510: r0 = layer=()
    //     0x652510: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x652514: add             SP, SP, #0x10
    // 0x652518: ldr             x16, [fp, #0x10]
    // 0x65251c: SaveReg r16
    //     0x65251c: str             x16, [SP, #-8]!
    // 0x652520: r0 = dispose()
    //     0x652520: bl              #0x652540  ; [package:flutter/src/rendering/flex.dart] _RenderFlex&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin&DebugOverflowIndicatorMixin::dispose
    // 0x652524: add             SP, SP, #8
    // 0x652528: r0 = Null
    //     0x652528: mov             x0, NULL
    // 0x65252c: LeaveFrame
    //     0x65252c: mov             SP, fp
    //     0x652530: ldp             fp, lr, [SP], #0x10
    // 0x652534: ret
    //     0x652534: ret             
    // 0x652538: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x652538: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65253c: b               #0x652500
  }
  _ paint(/* No info */) {
    // ** addr: 0x65b0b8, size: 0x188
    // 0x65b0b8: EnterFrame
    //     0x65b0b8: stp             fp, lr, [SP, #-0x10]!
    //     0x65b0bc: mov             fp, SP
    // 0x65b0c0: AllocStack(0x20)
    //     0x65b0c0: sub             SP, SP, #0x20
    // 0x65b0c4: d0 = 0.000000
    //     0x65b0c4: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1e0] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    //     0x65b0c8: ldr             d0, [x17, #0x1e0]
    // 0x65b0cc: CheckStackOverflow
    //     0x65b0cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65b0d0: cmp             SP, x16
    //     0x65b0d4: b.ls            #0x65b228
    // 0x65b0d8: ldr             x0, [fp, #0x20]
    // 0x65b0dc: LoadField: d1 = r0->field_8f
    //     0x65b0dc: ldur            d1, [x0, #0x8f]
    // 0x65b0e0: fcmp            d1, d0
    // 0x65b0e4: b.vs            #0x65b0ec
    // 0x65b0e8: b.gt            #0x65b0f4
    // 0x65b0ec: r1 = false
    //     0x65b0ec: add             x1, NULL, #0x30  ; false
    // 0x65b0f0: b               #0x65b0f8
    // 0x65b0f4: r1 = true
    //     0x65b0f4: add             x1, NULL, #0x20  ; true
    // 0x65b0f8: tbz             w1, #4, #0x65b124
    // 0x65b0fc: ldr             x16, [fp, #0x18]
    // 0x65b100: stp             x16, x0, [SP, #-0x10]!
    // 0x65b104: ldr             x16, [fp, #0x10]
    // 0x65b108: SaveReg r16
    //     0x65b108: str             x16, [SP, #-8]!
    // 0x65b10c: r0 = defaultPaint()
    //     0x65b10c: bl              #0x65bf44  ; [package:flutter/src/rendering/flex.dart] _RenderFlex&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultPaint
    // 0x65b110: add             SP, SP, #0x18
    // 0x65b114: r0 = Null
    //     0x65b114: mov             x0, NULL
    // 0x65b118: LeaveFrame
    //     0x65b118: mov             SP, fp
    //     0x65b11c: ldp             fp, lr, [SP], #0x10
    // 0x65b120: ret
    //     0x65b120: ret             
    // 0x65b124: LoadField: r1 = r0->field_57
    //     0x65b124: ldur            w1, [x0, #0x57]
    // 0x65b128: DecompressPointer r1
    //     0x65b128: add             x1, x1, HEAP, lsl #32
    // 0x65b12c: cmp             w1, NULL
    // 0x65b130: b.eq            #0x65b230
    // 0x65b134: SaveReg r1
    //     0x65b134: str             x1, [SP, #-8]!
    // 0x65b138: r0 = isEmpty()
    //     0x65b138: bl              #0x50e460  ; [dart:ui] Size::isEmpty
    // 0x65b13c: add             SP, SP, #8
    // 0x65b140: tbnz            w0, #4, #0x65b154
    // 0x65b144: r0 = Null
    //     0x65b144: mov             x0, NULL
    // 0x65b148: LeaveFrame
    //     0x65b148: mov             SP, fp
    //     0x65b14c: ldp             fp, lr, [SP], #0x10
    // 0x65b150: ret
    //     0x65b150: ret             
    // 0x65b154: ldr             x0, [fp, #0x20]
    // 0x65b158: LoadField: r1 = r0->field_9b
    //     0x65b158: ldur            w1, [x0, #0x9b]
    // 0x65b15c: DecompressPointer r1
    //     0x65b15c: add             x1, x1, HEAP, lsl #32
    // 0x65b160: stur            x1, [fp, #-0x10]
    // 0x65b164: LoadField: r2 = r0->field_37
    //     0x65b164: ldur            w2, [x0, #0x37]
    // 0x65b168: DecompressPointer r2
    //     0x65b168: add             x2, x2, HEAP, lsl #32
    // 0x65b16c: r16 = Sentinel
    //     0x65b16c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x65b170: cmp             w2, w16
    // 0x65b174: b.eq            #0x65b234
    // 0x65b178: stur            x2, [fp, #-8]
    // 0x65b17c: LoadField: r3 = r0->field_57
    //     0x65b17c: ldur            w3, [x0, #0x57]
    // 0x65b180: DecompressPointer r3
    //     0x65b180: add             x3, x3, HEAP, lsl #32
    // 0x65b184: cmp             w3, NULL
    // 0x65b188: b.eq            #0x65b23c
    // 0x65b18c: r16 = Instance_Offset
    //     0x65b18c: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x65b190: stp             x3, x16, [SP, #-0x10]!
    // 0x65b194: r0 = &()
    //     0x65b194: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x65b198: add             SP, SP, #0x10
    // 0x65b19c: stur            x0, [fp, #-0x18]
    // 0x65b1a0: r1 = 1
    //     0x65b1a0: mov             x1, #1
    // 0x65b1a4: r0 = AllocateContext()
    //     0x65b1a4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x65b1a8: mov             x1, x0
    // 0x65b1ac: ldr             x0, [fp, #0x20]
    // 0x65b1b0: StoreField: r1->field_f = r0
    //     0x65b1b0: stur            w0, [x1, #0xf]
    // 0x65b1b4: ldur            x0, [fp, #-0x10]
    // 0x65b1b8: LoadField: r3 = r0->field_b
    //     0x65b1b8: ldur            w3, [x0, #0xb]
    // 0x65b1bc: DecompressPointer r3
    //     0x65b1bc: add             x3, x3, HEAP, lsl #32
    // 0x65b1c0: mov             x2, x1
    // 0x65b1c4: stur            x3, [fp, #-0x20]
    // 0x65b1c8: r1 = Function 'defaultPaint':.
    //     0x65b1c8: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d1e8] AnonymousClosure: (0x65c070), in [package:flutter/src/rendering/flex.dart] _RenderFlex&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultPaint (0x65bf44)
    //     0x65b1cc: ldr             x1, [x1, #0x1e8]
    // 0x65b1d0: r0 = AllocateClosure()
    //     0x65b1d0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x65b1d4: ldr             x16, [fp, #0x18]
    // 0x65b1d8: ldur            lr, [fp, #-8]
    // 0x65b1dc: stp             lr, x16, [SP, #-0x10]!
    // 0x65b1e0: ldr             x16, [fp, #0x10]
    // 0x65b1e4: ldur            lr, [fp, #-0x18]
    // 0x65b1e8: stp             lr, x16, [SP, #-0x10]!
    // 0x65b1ec: r16 = Instance_Clip
    //     0x65b1ec: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x65b1f0: ldr             x16, [x16, #0xb38]
    // 0x65b1f4: stp             x16, x0, [SP, #-0x10]!
    // 0x65b1f8: ldur            x16, [fp, #-0x20]
    // 0x65b1fc: SaveReg r16
    //     0x65b1fc: str             x16, [SP, #-8]!
    // 0x65b200: r0 = pushClipRect()
    //     0x65b200: bl              #0x65b240  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRect
    // 0x65b204: add             SP, SP, #0x38
    // 0x65b208: ldur            x16, [fp, #-0x10]
    // 0x65b20c: stp             x0, x16, [SP, #-0x10]!
    // 0x65b210: r0 = layer=()
    //     0x65b210: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x65b214: add             SP, SP, #0x10
    // 0x65b218: r0 = Null
    //     0x65b218: mov             x0, NULL
    // 0x65b21c: LeaveFrame
    //     0x65b21c: mov             SP, fp
    //     0x65b220: ldp             fp, lr, [SP], #0x10
    // 0x65b224: ret
    //     0x65b224: ret             
    // 0x65b228: r0 = StackOverflowSharedWithFPURegs()
    //     0x65b228: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x65b22c: b               #0x65b0d8
    // 0x65b230: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65b230: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x65b234: r9 = _needsCompositing
    //     0x65b234: ldr             x9, [PP, #0x4b28]  ; [pp+0x4b28] Field <RenderObject._needsCompositing@904266271>: late (offset: 0x38)
    // 0x65b238: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x65b238: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x65b23c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65b23c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x6899c0, size: 0xa44
    // 0x6899c0: EnterFrame
    //     0x6899c0: stp             fp, lr, [SP, #-0x10]!
    //     0x6899c4: mov             fp, SP
    // 0x6899c8: AllocStack(0x60)
    //     0x6899c8: sub             SP, SP, #0x60
    // 0x6899cc: CheckStackOverflow
    //     0x6899cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6899d0: cmp             SP, x16
    //     0x6899d4: b.ls            #0x68a3c8
    // 0x6899d8: ldr             x3, [fp, #0x10]
    // 0x6899dc: LoadField: r4 = r3->field_27
    //     0x6899dc: ldur            w4, [x3, #0x27]
    // 0x6899e0: DecompressPointer r4
    //     0x6899e0: add             x4, x4, HEAP, lsl #32
    // 0x6899e4: stur            x4, [fp, #-8]
    // 0x6899e8: cmp             w4, NULL
    // 0x6899ec: b.eq            #0x68a3a8
    // 0x6899f0: mov             x0, x4
    // 0x6899f4: r2 = Null
    //     0x6899f4: mov             x2, NULL
    // 0x6899f8: r1 = Null
    //     0x6899f8: mov             x1, NULL
    // 0x6899fc: r4 = LoadClassIdInstr(r0)
    //     0x6899fc: ldur            x4, [x0, #-1]
    //     0x689a00: ubfx            x4, x4, #0xc, #0x14
    // 0x689a04: sub             x4, x4, #0x80d
    // 0x689a08: cmp             x4, #1
    // 0x689a0c: b.ls            #0x689a24
    // 0x689a10: r8 = BoxConstraints
    //     0x689a10: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x689a14: ldr             x8, [x8, #0x1d0]
    // 0x689a18: r3 = Null
    //     0x689a18: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d270] Null
    //     0x689a1c: ldr             x3, [x3, #0x270]
    // 0x689a20: r0 = BoxConstraints()
    //     0x689a20: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x689a24: ldr             x16, [fp, #0x10]
    // 0x689a28: ldur            lr, [fp, #-8]
    // 0x689a2c: stp             lr, x16, [SP, #-0x10]!
    // 0x689a30: r16 = Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static.
    //     0x689a30: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cf80] Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static. (0x7fe6e1e8aefc)
    //     0x689a34: ldr             x16, [x16, #0xf80]
    // 0x689a38: SaveReg r16
    //     0x689a38: str             x16, [SP, #-8]!
    // 0x689a3c: r0 = _computeSizes()
    //     0x689a3c: bl              #0x68a5d4  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_computeSizes
    // 0x689a40: add             SP, SP, #0x18
    // 0x689a44: LoadField: d0 = r0->field_17
    //     0x689a44: ldur            d0, [x0, #0x17]
    // 0x689a48: stur            d0, [fp, #-0x50]
    // 0x689a4c: LoadField: d1 = r0->field_7
    //     0x689a4c: ldur            d1, [x0, #7]
    // 0x689a50: stur            d1, [fp, #-0x48]
    // 0x689a54: LoadField: d2 = r0->field_f
    //     0x689a54: ldur            d2, [x0, #0xf]
    // 0x689a58: ldr             x0, [fp, #0x10]
    // 0x689a5c: LoadField: r1 = r0->field_7f
    //     0x689a5c: ldur            w1, [x0, #0x7f]
    // 0x689a60: DecompressPointer r1
    //     0x689a60: add             x1, x1, HEAP, lsl #32
    // 0x689a64: r16 = Instance_CrossAxisAlignment
    //     0x689a64: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d280] Obj!CrossAxisAlignment@b649f1
    //     0x689a68: ldr             x16, [x16, #0x280]
    // 0x689a6c: cmp             w1, w16
    // 0x689a70: b.ne            #0x689cf0
    // 0x689a74: LoadField: r1 = r0->field_67
    //     0x689a74: ldur            w1, [x0, #0x67]
    // 0x689a78: DecompressPointer r1
    //     0x689a78: add             x1, x1, HEAP, lsl #32
    // 0x689a7c: mov             v5.16b, v2.16b
    // 0x689a80: d4 = 0.000000
    //     0x689a80: eor             v4.16b, v4.16b, v4.16b
    // 0x689a84: d3 = 0.000000
    //     0x689a84: eor             v3.16b, v3.16b, v3.16b
    // 0x689a88: d2 = 0.000000
    //     0x689a88: eor             v2.16b, v2.16b, v2.16b
    // 0x689a8c: stur            x1, [fp, #-0x10]
    // 0x689a90: stur            d5, [fp, #-0x28]
    // 0x689a94: stur            d4, [fp, #-0x30]
    // 0x689a98: stur            d3, [fp, #-0x38]
    // 0x689a9c: stur            d2, [fp, #-0x40]
    // 0x689aa0: CheckStackOverflow
    //     0x689aa0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x689aa4: cmp             SP, x16
    //     0x689aa8: b.ls            #0x68a3d0
    // 0x689aac: cmp             w1, NULL
    // 0x689ab0: b.eq            #0x689ce4
    // 0x689ab4: LoadField: r2 = r0->field_8b
    //     0x689ab4: ldur            w2, [x0, #0x8b]
    // 0x689ab8: DecompressPointer r2
    //     0x689ab8: add             x2, x2, HEAP, lsl #32
    // 0x689abc: cmp             w2, NULL
    // 0x689ac0: b.eq            #0x68a3d8
    // 0x689ac4: stp             x2, x1, [SP, #-0x10]!
    // 0x689ac8: r0 = getDistanceToActualBaseline()
    //     0x689ac8: bl              #0x63d634  ; [package:flutter/src/rendering/box.dart] RenderBox::getDistanceToActualBaseline
    // 0x689acc: add             SP, SP, #0x10
    // 0x689ad0: cmp             w0, NULL
    // 0x689ad4: b.eq            #0x689c40
    // 0x689ad8: ldur            d0, [fp, #-0x30]
    // 0x689adc: LoadField: d1 = r0->field_7
    //     0x689adc: ldur            d1, [x0, #7]
    // 0x689ae0: fcmp            d0, d1
    // 0x689ae4: b.vs            #0x689af4
    // 0x689ae8: b.le            #0x689af4
    // 0x689aec: d2 = 0.000000
    //     0x689aec: eor             v2.16b, v2.16b, v2.16b
    // 0x689af0: b               #0x689b38
    // 0x689af4: fcmp            d0, d1
    // 0x689af8: b.vs            #0x689b0c
    // 0x689afc: b.ge            #0x689b0c
    // 0x689b00: LoadField: d0 = r0->field_7
    //     0x689b00: ldur            d0, [x0, #7]
    // 0x689b04: d2 = 0.000000
    //     0x689b04: eor             v2.16b, v2.16b, v2.16b
    // 0x689b08: b               #0x689b38
    // 0x689b0c: d2 = 0.000000
    //     0x689b0c: eor             v2.16b, v2.16b, v2.16b
    // 0x689b10: fcmp            d0, d2
    // 0x689b14: b.vs            #0x689b28
    // 0x689b18: b.ne            #0x689b28
    // 0x689b1c: fadd            d4, d0, d1
    // 0x689b20: mov             v0.16b, v4.16b
    // 0x689b24: b               #0x689b38
    // 0x689b28: LoadField: d3 = r0->field_7
    //     0x689b28: ldur            d3, [x0, #7]
    // 0x689b2c: fcmp            d3, d3
    // 0x689b30: b.vc            #0x689b38
    // 0x689b34: LoadField: d0 = r0->field_7
    //     0x689b34: ldur            d0, [x0, #7]
    // 0x689b38: ldur            d3, [fp, #-0x38]
    // 0x689b3c: fcmp            d1, d3
    // 0x689b40: b.vs            #0x689b50
    // 0x689b44: b.le            #0x689b50
    // 0x689b48: LoadField: d3 = r0->field_7
    //     0x689b48: ldur            d3, [x0, #7]
    // 0x689b4c: b               #0x689b80
    // 0x689b50: fcmp            d1, d3
    // 0x689b54: b.vs            #0x689b5c
    // 0x689b58: b.lt            #0x689b80
    // 0x689b5c: fcmp            d1, d2
    // 0x689b60: b.vs            #0x689b74
    // 0x689b64: b.ne            #0x689b74
    // 0x689b68: fadd            d6, d1, d3
    // 0x689b6c: mov             v3.16b, v6.16b
    // 0x689b70: b               #0x689b80
    // 0x689b74: fcmp            d3, d3
    // 0x689b78: b.vs            #0x689b80
    // 0x689b7c: LoadField: d3 = r0->field_7
    //     0x689b7c: ldur            d3, [x0, #7]
    // 0x689b80: ldur            x0, [fp, #-0x10]
    // 0x689b84: ldur            d6, [fp, #-0x40]
    // 0x689b88: LoadField: r1 = r0->field_57
    //     0x689b88: ldur            w1, [x0, #0x57]
    // 0x689b8c: DecompressPointer r1
    //     0x689b8c: add             x1, x1, HEAP, lsl #32
    // 0x689b90: cmp             w1, NULL
    // 0x689b94: b.eq            #0x68a3dc
    // 0x689b98: LoadField: d4 = r1->field_f
    //     0x689b98: ldur            d4, [x1, #0xf]
    // 0x689b9c: fsub            d7, d4, d1
    // 0x689ba0: fcmp            d7, d6
    // 0x689ba4: b.vs            #0x689bb4
    // 0x689ba8: b.le            #0x689bb4
    // 0x689bac: mov             v6.16b, v7.16b
    // 0x689bb0: b               #0x689be4
    // 0x689bb4: fcmp            d7, d6
    // 0x689bb8: b.vs            #0x689bc0
    // 0x689bbc: b.lt            #0x689be4
    // 0x689bc0: fcmp            d7, d2
    // 0x689bc4: b.vs            #0x689bd8
    // 0x689bc8: b.ne            #0x689bd8
    // 0x689bcc: fadd            d1, d7, d6
    // 0x689bd0: mov             v6.16b, v1.16b
    // 0x689bd4: b               #0x689be4
    // 0x689bd8: fcmp            d6, d6
    // 0x689bdc: b.vs            #0x689be4
    // 0x689be0: mov             v6.16b, v7.16b
    // 0x689be4: ldur            d1, [fp, #-0x28]
    // 0x689be8: fadd            d5, d3, d6
    // 0x689bec: fcmp            d5, d1
    // 0x689bf0: b.vs            #0x689c00
    // 0x689bf4: b.le            #0x689c00
    // 0x689bf8: mov             v1.16b, v5.16b
    // 0x689bfc: b               #0x689c30
    // 0x689c00: fcmp            d5, d1
    // 0x689c04: b.vs            #0x689c0c
    // 0x689c08: b.lt            #0x689c30
    // 0x689c0c: fcmp            d5, d2
    // 0x689c10: b.vs            #0x689c24
    // 0x689c14: b.ne            #0x689c24
    // 0x689c18: fadd            d7, d5, d1
    // 0x689c1c: mov             v1.16b, v7.16b
    // 0x689c20: b               #0x689c30
    // 0x689c24: fcmp            d1, d1
    // 0x689c28: b.vs            #0x689c30
    // 0x689c2c: mov             v1.16b, v5.16b
    // 0x689c30: mov             v5.16b, v1.16b
    // 0x689c34: mov             v4.16b, v0.16b
    // 0x689c38: mov             v0.16b, v6.16b
    // 0x689c3c: b               #0x689c64
    // 0x689c40: ldur            d1, [fp, #-0x28]
    // 0x689c44: ldur            d0, [fp, #-0x30]
    // 0x689c48: ldur            x0, [fp, #-0x10]
    // 0x689c4c: ldur            d3, [fp, #-0x38]
    // 0x689c50: ldur            d6, [fp, #-0x40]
    // 0x689c54: d2 = 0.000000
    //     0x689c54: eor             v2.16b, v2.16b, v2.16b
    // 0x689c58: mov             v5.16b, v1.16b
    // 0x689c5c: mov             v4.16b, v0.16b
    // 0x689c60: mov             v0.16b, v6.16b
    // 0x689c64: stur            d5, [fp, #-0x38]
    // 0x689c68: stur            d4, [fp, #-0x40]
    // 0x689c6c: stur            d3, [fp, #-0x58]
    // 0x689c70: stur            d0, [fp, #-0x60]
    // 0x689c74: LoadField: r3 = r0->field_17
    //     0x689c74: ldur            w3, [x0, #0x17]
    // 0x689c78: DecompressPointer r3
    //     0x689c78: add             x3, x3, HEAP, lsl #32
    // 0x689c7c: stur            x3, [fp, #-0x18]
    // 0x689c80: cmp             w3, NULL
    // 0x689c84: b.eq            #0x68a3e0
    // 0x689c88: mov             x0, x3
    // 0x689c8c: r2 = Null
    //     0x689c8c: mov             x2, NULL
    // 0x689c90: r1 = Null
    //     0x689c90: mov             x1, NULL
    // 0x689c94: r4 = LoadClassIdInstr(r0)
    //     0x689c94: ldur            x4, [x0, #-1]
    //     0x689c98: ubfx            x4, x4, #0xc, #0x14
    // 0x689c9c: cmp             x4, #0x809
    // 0x689ca0: b.eq            #0x689cb8
    // 0x689ca4: r8 = FlexParentData<RenderBox>
    //     0x689ca4: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x689ca8: ldr             x8, [x8, #0x248]
    // 0x689cac: r3 = Null
    //     0x689cac: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d288] Null
    //     0x689cb0: ldr             x3, [x3, #0x288]
    // 0x689cb4: r0 = DefaultTypeTest()
    //     0x689cb4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x689cb8: ldur            x0, [fp, #-0x18]
    // 0x689cbc: LoadField: r1 = r0->field_13
    //     0x689cbc: ldur            w1, [x0, #0x13]
    // 0x689cc0: DecompressPointer r1
    //     0x689cc0: add             x1, x1, HEAP, lsl #32
    // 0x689cc4: ldur            d5, [fp, #-0x38]
    // 0x689cc8: ldur            d4, [fp, #-0x40]
    // 0x689ccc: ldur            d3, [fp, #-0x58]
    // 0x689cd0: ldur            d2, [fp, #-0x60]
    // 0x689cd4: ldr             x0, [fp, #0x10]
    // 0x689cd8: ldur            d0, [fp, #-0x50]
    // 0x689cdc: ldur            d1, [fp, #-0x48]
    // 0x689ce0: b               #0x689a8c
    // 0x689ce4: mov             v1.16b, v5.16b
    // 0x689ce8: mov             v0.16b, v4.16b
    // 0x689cec: b               #0x689cf8
    // 0x689cf0: mov             v1.16b, v2.16b
    // 0x689cf4: d0 = 0.000000
    //     0x689cf4: eor             v0.16b, v0.16b, v0.16b
    // 0x689cf8: ldr             x0, [fp, #0x10]
    // 0x689cfc: stur            d1, [fp, #-0x28]
    // 0x689d00: stur            d0, [fp, #-0x30]
    // 0x689d04: LoadField: r1 = r0->field_73
    //     0x689d04: ldur            w1, [x0, #0x73]
    // 0x689d08: DecompressPointer r1
    //     0x689d08: add             x1, x1, HEAP, lsl #32
    // 0x689d0c: LoadField: r2 = r1->field_7
    //     0x689d0c: ldur            x2, [x1, #7]
    // 0x689d10: cmp             x2, #0
    // 0x689d14: b.gt            #0x689d78
    // 0x689d18: ldur            d2, [fp, #-0x48]
    // 0x689d1c: r0 = Size()
    //     0x689d1c: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x689d20: ldur            d0, [fp, #-0x48]
    // 0x689d24: StoreField: r0->field_7 = d0
    //     0x689d24: stur            d0, [x0, #7]
    // 0x689d28: ldur            d1, [fp, #-0x28]
    // 0x689d2c: StoreField: r0->field_f = d1
    //     0x689d2c: stur            d1, [x0, #0xf]
    // 0x689d30: ldur            x16, [fp, #-8]
    // 0x689d34: stp             x0, x16, [SP, #-0x10]!
    // 0x689d38: r0 = constrain()
    //     0x689d38: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x689d3c: add             SP, SP, #0x10
    // 0x689d40: mov             x2, x0
    // 0x689d44: ldr             x1, [fp, #0x10]
    // 0x689d48: StoreField: r1->field_57 = r0
    //     0x689d48: stur            w0, [x1, #0x57]
    //     0x689d4c: ldurb           w16, [x1, #-1]
    //     0x689d50: ldurb           w17, [x0, #-1]
    //     0x689d54: and             x16, x17, x16, lsr #2
    //     0x689d58: tst             x16, HEAP, lsr #32
    //     0x689d5c: b.eq            #0x689d64
    //     0x689d60: bl              #0xd6826c
    // 0x689d64: LoadField: d0 = r2->field_7
    //     0x689d64: ldur            d0, [x2, #7]
    // 0x689d68: LoadField: d1 = r2->field_f
    //     0x689d68: ldur            d1, [x2, #0xf]
    // 0x689d6c: mov             v3.16b, v0.16b
    // 0x689d70: mov             v2.16b, v1.16b
    // 0x689d74: b               #0x689dd8
    // 0x689d78: mov             x1, x0
    // 0x689d7c: ldur            d0, [fp, #-0x48]
    // 0x689d80: r0 = Size()
    //     0x689d80: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x689d84: ldur            d0, [fp, #-0x28]
    // 0x689d88: StoreField: r0->field_7 = d0
    //     0x689d88: stur            d0, [x0, #7]
    // 0x689d8c: ldur            d0, [fp, #-0x48]
    // 0x689d90: StoreField: r0->field_f = d0
    //     0x689d90: stur            d0, [x0, #0xf]
    // 0x689d94: ldur            x16, [fp, #-8]
    // 0x689d98: stp             x0, x16, [SP, #-0x10]!
    // 0x689d9c: r0 = constrain()
    //     0x689d9c: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x689da0: add             SP, SP, #0x10
    // 0x689da4: mov             x2, x0
    // 0x689da8: ldr             x1, [fp, #0x10]
    // 0x689dac: StoreField: r1->field_57 = r0
    //     0x689dac: stur            w0, [x1, #0x57]
    //     0x689db0: ldurb           w16, [x1, #-1]
    //     0x689db4: ldurb           w17, [x0, #-1]
    //     0x689db8: and             x16, x17, x16, lsr #2
    //     0x689dbc: tst             x16, HEAP, lsr #32
    //     0x689dc0: b.eq            #0x689dc8
    //     0x689dc4: bl              #0xd6826c
    // 0x689dc8: LoadField: d0 = r2->field_f
    //     0x689dc8: ldur            d0, [x2, #0xf]
    // 0x689dcc: LoadField: d1 = r2->field_7
    //     0x689dcc: ldur            d1, [x2, #7]
    // 0x689dd0: mov             v3.16b, v0.16b
    // 0x689dd4: mov             v2.16b, v1.16b
    // 0x689dd8: ldur            d1, [fp, #-0x50]
    // 0x689ddc: d0 = 0.000000
    //     0x689ddc: eor             v0.16b, v0.16b, v0.16b
    // 0x689de0: stur            d3, [fp, #-0x38]
    // 0x689de4: stur            d2, [fp, #-0x40]
    // 0x689de8: fsub            d4, d3, d1
    // 0x689dec: fneg            d1, d4
    // 0x689df0: fcmp            d0, d1
    // 0x689df4: b.vs            #0x689e04
    // 0x689df8: b.le            #0x689e04
    // 0x689dfc: d1 = 0.000000
    //     0x689dfc: eor             v1.16b, v1.16b, v1.16b
    // 0x689e00: b               #0x689e34
    // 0x689e04: fcmp            d0, d1
    // 0x689e08: b.vs            #0x689e10
    // 0x689e0c: b.lt            #0x689e34
    // 0x689e10: fcmp            d0, d0
    // 0x689e14: b.vs            #0x689e28
    // 0x689e18: b.ne            #0x689e28
    // 0x689e1c: fadd            d5, d0, d1
    // 0x689e20: mov             v1.16b, v5.16b
    // 0x689e24: b               #0x689e34
    // 0x689e28: fcmp            d1, d1
    // 0x689e2c: b.vs            #0x689e34
    // 0x689e30: d1 = 0.000000
    //     0x689e30: eor             v1.16b, v1.16b, v1.16b
    // 0x689e34: StoreField: r1->field_8f = d1
    //     0x689e34: stur            d1, [x1, #0x8f]
    // 0x689e38: fcmp            d0, d4
    // 0x689e3c: b.vs            #0x689e4c
    // 0x689e40: b.le            #0x689e4c
    // 0x689e44: d0 = 0.000000
    //     0x689e44: eor             v0.16b, v0.16b, v0.16b
    // 0x689e48: b               #0x689e8c
    // 0x689e4c: fcmp            d0, d4
    // 0x689e50: b.vs            #0x689e60
    // 0x689e54: b.ge            #0x689e60
    // 0x689e58: mov             v0.16b, v4.16b
    // 0x689e5c: b               #0x689e8c
    // 0x689e60: fcmp            d0, d0
    // 0x689e64: b.vs            #0x689e78
    // 0x689e68: b.ne            #0x689e78
    // 0x689e6c: fadd            d1, d0, d4
    // 0x689e70: mov             v0.16b, v1.16b
    // 0x689e74: b               #0x689e8c
    // 0x689e78: fcmp            d4, d4
    // 0x689e7c: b.vc            #0x689e88
    // 0x689e80: mov             v0.16b, v4.16b
    // 0x689e84: b               #0x689e8c
    // 0x689e88: d0 = 0.000000
    //     0x689e88: eor             v0.16b, v0.16b, v0.16b
    // 0x689e8c: stur            d0, [fp, #-0x28]
    // 0x689e90: LoadField: r0 = r1->field_73
    //     0x689e90: ldur            w0, [x1, #0x73]
    // 0x689e94: DecompressPointer r0
    //     0x689e94: add             x0, x0, HEAP, lsl #32
    // 0x689e98: LoadField: r2 = r1->field_83
    //     0x689e98: ldur            w2, [x1, #0x83]
    // 0x689e9c: DecompressPointer r2
    //     0x689e9c: add             x2, x2, HEAP, lsl #32
    // 0x689ea0: stp             x2, x0, [SP, #-0x10]!
    // 0x689ea4: r0 = _startIsTopLeft()
    //     0x689ea4: bl              #0x68a50c  ; [package:flutter/src/rendering/flex.dart] ::_startIsTopLeft
    // 0x689ea8: add             SP, SP, #0x10
    // 0x689eac: cmp             w0, NULL
    // 0x689eb0: b.ne            #0x689eb8
    // 0x689eb4: r0 = true
    //     0x689eb4: add             x0, NULL, #0x20  ; true
    // 0x689eb8: ldr             x3, [fp, #0x10]
    // 0x689ebc: eor             x4, x0, #0x10
    // 0x689ec0: stur            x4, [fp, #-0x18]
    // 0x689ec4: LoadField: r0 = r3->field_77
    //     0x689ec4: ldur            w0, [x3, #0x77]
    // 0x689ec8: DecompressPointer r0
    //     0x689ec8: add             x0, x0, HEAP, lsl #32
    // 0x689ecc: LoadField: r1 = r0->field_7
    //     0x689ecc: ldur            x1, [x0, #7]
    // 0x689ed0: cmp             x1, #2
    // 0x689ed4: b.gt            #0x689f1c
    // 0x689ed8: cmp             x1, #1
    // 0x689edc: b.gt            #0x689f08
    // 0x689ee0: cmp             x1, #0
    // 0x689ee4: b.gt            #0x689ef8
    // 0x689ee8: d2 = 0.000000
    //     0x689ee8: eor             v2.16b, v2.16b, v2.16b
    // 0x689eec: d0 = 0.000000
    //     0x689eec: eor             v0.16b, v0.16b, v0.16b
    // 0x689ef0: d1 = 2.000000
    //     0x689ef0: fmov            d1, #2.00000000
    // 0x689ef4: b               #0x689fb0
    // 0x689ef8: ldur            d2, [fp, #-0x28]
    // 0x689efc: d0 = 0.000000
    //     0x689efc: eor             v0.16b, v0.16b, v0.16b
    // 0x689f00: d1 = 2.000000
    //     0x689f00: fmov            d1, #2.00000000
    // 0x689f04: b               #0x689fb0
    // 0x689f08: ldur            d0, [fp, #-0x28]
    // 0x689f0c: d1 = 2.000000
    //     0x689f0c: fmov            d1, #2.00000000
    // 0x689f10: fdiv            d2, d0, d1
    // 0x689f14: d0 = 0.000000
    //     0x689f14: eor             v0.16b, v0.16b, v0.16b
    // 0x689f18: b               #0x689fb0
    // 0x689f1c: ldur            d0, [fp, #-0x28]
    // 0x689f20: d1 = 2.000000
    //     0x689f20: fmov            d1, #2.00000000
    // 0x689f24: cmp             x1, #4
    // 0x689f28: b.gt            #0x689f88
    // 0x689f2c: cmp             x1, #3
    // 0x689f30: b.gt            #0x689f60
    // 0x689f34: LoadField: r0 = r3->field_5f
    //     0x689f34: ldur            x0, [x3, #0x5f]
    // 0x689f38: cmp             x0, #1
    // 0x689f3c: b.le            #0x689f54
    // 0x689f40: sub             x1, x0, #1
    // 0x689f44: scvtf           d2, x1
    // 0x689f48: fdiv            d3, d0, d2
    // 0x689f4c: mov             v0.16b, v3.16b
    // 0x689f50: b               #0x689f58
    // 0x689f54: d0 = 0.000000
    //     0x689f54: eor             v0.16b, v0.16b, v0.16b
    // 0x689f58: d2 = 0.000000
    //     0x689f58: eor             v2.16b, v2.16b, v2.16b
    // 0x689f5c: b               #0x689fb0
    // 0x689f60: LoadField: r0 = r3->field_5f
    //     0x689f60: ldur            x0, [x3, #0x5f]
    // 0x689f64: cmp             x0, #0
    // 0x689f68: b.le            #0x689f7c
    // 0x689f6c: scvtf           d2, x0
    // 0x689f70: fdiv            d3, d0, d2
    // 0x689f74: mov             v0.16b, v3.16b
    // 0x689f78: b               #0x689f80
    // 0x689f7c: d0 = 0.000000
    //     0x689f7c: eor             v0.16b, v0.16b, v0.16b
    // 0x689f80: fdiv            d2, d0, d1
    // 0x689f84: b               #0x689fb0
    // 0x689f88: LoadField: r0 = r3->field_5f
    //     0x689f88: ldur            x0, [x3, #0x5f]
    // 0x689f8c: cmp             x0, #0
    // 0x689f90: b.le            #0x689fa8
    // 0x689f94: add             x1, x0, #1
    // 0x689f98: scvtf           d2, x1
    // 0x689f9c: fdiv            d3, d0, d2
    // 0x689fa0: mov             v0.16b, v3.16b
    // 0x689fa4: b               #0x689fac
    // 0x689fa8: d0 = 0.000000
    //     0x689fa8: eor             v0.16b, v0.16b, v0.16b
    // 0x689fac: mov             v2.16b, v0.16b
    // 0x689fb0: stur            d0, [fp, #-0x48]
    // 0x689fb4: tbnz            w4, #4, #0x689fc8
    // 0x689fb8: ldur            d3, [fp, #-0x38]
    // 0x689fbc: fsub            d4, d3, d2
    // 0x689fc0: mov             v3.16b, v4.16b
    // 0x689fc4: b               #0x689fcc
    // 0x689fc8: mov             v3.16b, v2.16b
    // 0x689fcc: ldur            d2, [fp, #-0x40]
    // 0x689fd0: LoadField: r0 = r3->field_67
    //     0x689fd0: ldur            w0, [x3, #0x67]
    // 0x689fd4: DecompressPointer r0
    //     0x689fd4: add             x0, x0, HEAP, lsl #32
    // 0x689fd8: fdiv            d4, d2, d1
    // 0x689fdc: stur            d4, [fp, #-0x38]
    // 0x689fe0: mov             v5.16b, v3.16b
    // 0x689fe4: mov             x5, x0
    // 0x689fe8: ldur            d3, [fp, #-0x30]
    // 0x689fec: stur            x5, [fp, #-0x10]
    // 0x689ff0: stur            d5, [fp, #-0x28]
    // 0x689ff4: CheckStackOverflow
    //     0x689ff4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x689ff8: cmp             SP, x16
    //     0x689ffc: b.ls            #0x68a3e4
    // 0x68a000: cmp             w5, NULL
    // 0x68a004: b.eq            #0x68a398
    // 0x68a008: LoadField: r6 = r5->field_17
    //     0x68a008: ldur            w6, [x5, #0x17]
    // 0x68a00c: DecompressPointer r6
    //     0x68a00c: add             x6, x6, HEAP, lsl #32
    // 0x68a010: stur            x6, [fp, #-8]
    // 0x68a014: cmp             w6, NULL
    // 0x68a018: b.eq            #0x68a3ec
    // 0x68a01c: mov             x0, x6
    // 0x68a020: r2 = Null
    //     0x68a020: mov             x2, NULL
    // 0x68a024: r1 = Null
    //     0x68a024: mov             x1, NULL
    // 0x68a028: r4 = LoadClassIdInstr(r0)
    //     0x68a028: ldur            x4, [x0, #-1]
    //     0x68a02c: ubfx            x4, x4, #0xc, #0x14
    // 0x68a030: cmp             x4, #0x809
    // 0x68a034: b.eq            #0x68a04c
    // 0x68a038: r8 = FlexParentData<RenderBox>
    //     0x68a038: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x68a03c: ldr             x8, [x8, #0x248]
    // 0x68a040: r3 = Null
    //     0x68a040: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d298] Null
    //     0x68a044: ldr             x3, [x3, #0x298]
    // 0x68a048: r0 = DefaultTypeTest()
    //     0x68a048: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x68a04c: ldr             x0, [fp, #0x10]
    // 0x68a050: LoadField: r1 = r0->field_7f
    //     0x68a050: ldur            w1, [x0, #0x7f]
    // 0x68a054: DecompressPointer r1
    //     0x68a054: add             x1, x1, HEAP, lsl #32
    // 0x68a058: LoadField: r2 = r1->field_7
    //     0x68a058: ldur            x2, [x1, #7]
    // 0x68a05c: cmp             x2, #2
    // 0x68a060: b.gt            #0x68a194
    // 0x68a064: cmp             x2, #1
    // 0x68a068: b.gt            #0x68a138
    // 0x68a06c: LoadField: r1 = r0->field_73
    //     0x68a06c: ldur            w1, [x0, #0x73]
    // 0x68a070: DecompressPointer r1
    //     0x68a070: add             x1, x1, HEAP, lsl #32
    // 0x68a074: LoadField: r2 = r1->field_7
    //     0x68a074: ldur            x2, [x1, #7]
    // 0x68a078: cmp             x2, #0
    // 0x68a07c: b.gt            #0x68a08c
    // 0x68a080: r1 = Instance_Axis
    //     0x68a080: add             x1, PP, #0xe, lsl #12  ; [pp+0xef00] Obj!Axis@b64ff1
    //     0x68a084: ldr             x1, [x1, #0xf00]
    // 0x68a088: b               #0x68a094
    // 0x68a08c: r1 = Instance_Axis
    //     0x68a08c: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x68a090: ldr             x1, [x1, #0x440]
    // 0x68a094: LoadField: r2 = r0->field_83
    //     0x68a094: ldur            w2, [x0, #0x83]
    // 0x68a098: DecompressPointer r2
    //     0x68a098: add             x2, x2, HEAP, lsl #32
    // 0x68a09c: stp             x2, x1, [SP, #-0x10]!
    // 0x68a0a0: r0 = _startIsTopLeft()
    //     0x68a0a0: bl              #0x68a50c  ; [package:flutter/src/rendering/flex.dart] ::_startIsTopLeft
    // 0x68a0a4: add             SP, SP, #0x10
    // 0x68a0a8: mov             x1, x0
    // 0x68a0ac: ldr             x0, [fp, #0x10]
    // 0x68a0b0: LoadField: r2 = r0->field_7f
    //     0x68a0b0: ldur            w2, [x0, #0x7f]
    // 0x68a0b4: DecompressPointer r2
    //     0x68a0b4: add             x2, x2, HEAP, lsl #32
    // 0x68a0b8: r16 = Instance_CrossAxisAlignment
    //     0x68a0b8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15370] Obj!CrossAxisAlignment@b64a31
    //     0x68a0bc: ldr             x16, [x16, #0x370]
    // 0x68a0c0: cmp             w2, w16
    // 0x68a0c4: r16 = true
    //     0x68a0c4: add             x16, NULL, #0x20  ; true
    // 0x68a0c8: r17 = false
    //     0x68a0c8: add             x17, NULL, #0x30  ; false
    // 0x68a0cc: csel            x3, x16, x17, eq
    // 0x68a0d0: cmp             w1, w3
    // 0x68a0d4: b.ne            #0x68a0e8
    // 0x68a0d8: ldur            d0, [fp, #-0x40]
    // 0x68a0dc: ldur            x1, [fp, #-0x10]
    // 0x68a0e0: d1 = 0.000000
    //     0x68a0e0: eor             v1.16b, v1.16b, v1.16b
    // 0x68a0e4: b               #0x68a130
    // 0x68a0e8: ldur            x1, [fp, #-0x10]
    // 0x68a0ec: LoadField: r2 = r1->field_57
    //     0x68a0ec: ldur            w2, [x1, #0x57]
    // 0x68a0f0: DecompressPointer r2
    //     0x68a0f0: add             x2, x2, HEAP, lsl #32
    // 0x68a0f4: cmp             w2, NULL
    // 0x68a0f8: b.eq            #0x68a3f0
    // 0x68a0fc: LoadField: r3 = r0->field_73
    //     0x68a0fc: ldur            w3, [x0, #0x73]
    // 0x68a100: DecompressPointer r3
    //     0x68a100: add             x3, x3, HEAP, lsl #32
    // 0x68a104: LoadField: r4 = r3->field_7
    //     0x68a104: ldur            x4, [x3, #7]
    // 0x68a108: cmp             x4, #0
    // 0x68a10c: b.gt            #0x68a11c
    // 0x68a110: LoadField: d0 = r2->field_f
    //     0x68a110: ldur            d0, [x2, #0xf]
    // 0x68a114: mov             v1.16b, v0.16b
    // 0x68a118: b               #0x68a124
    // 0x68a11c: LoadField: d0 = r2->field_7
    //     0x68a11c: ldur            d0, [x2, #7]
    // 0x68a120: mov             v1.16b, v0.16b
    // 0x68a124: ldur            d0, [fp, #-0x40]
    // 0x68a128: fsub            d2, d0, d1
    // 0x68a12c: mov             v1.16b, v2.16b
    // 0x68a130: ldur            d0, [fp, #-0x30]
    // 0x68a134: b               #0x68a21c
    // 0x68a138: ldur            d0, [fp, #-0x40]
    // 0x68a13c: ldur            x1, [fp, #-0x10]
    // 0x68a140: LoadField: r2 = r1->field_57
    //     0x68a140: ldur            w2, [x1, #0x57]
    // 0x68a144: DecompressPointer r2
    //     0x68a144: add             x2, x2, HEAP, lsl #32
    // 0x68a148: cmp             w2, NULL
    // 0x68a14c: b.eq            #0x68a3f4
    // 0x68a150: LoadField: r3 = r0->field_73
    //     0x68a150: ldur            w3, [x0, #0x73]
    // 0x68a154: DecompressPointer r3
    //     0x68a154: add             x3, x3, HEAP, lsl #32
    // 0x68a158: LoadField: r4 = r3->field_7
    //     0x68a158: ldur            x4, [x3, #7]
    // 0x68a15c: cmp             x4, #0
    // 0x68a160: b.gt            #0x68a170
    // 0x68a164: LoadField: d1 = r2->field_f
    //     0x68a164: ldur            d1, [x2, #0xf]
    // 0x68a168: mov             v3.16b, v1.16b
    // 0x68a16c: b               #0x68a178
    // 0x68a170: LoadField: d1 = r2->field_7
    //     0x68a170: ldur            d1, [x2, #7]
    // 0x68a174: mov             v3.16b, v1.16b
    // 0x68a178: ldur            d2, [fp, #-0x38]
    // 0x68a17c: d1 = 2.000000
    //     0x68a17c: fmov            d1, #2.00000000
    // 0x68a180: fdiv            d4, d3, d1
    // 0x68a184: fsub            d3, d2, d4
    // 0x68a188: mov             v1.16b, v3.16b
    // 0x68a18c: ldur            d0, [fp, #-0x30]
    // 0x68a190: b               #0x68a21c
    // 0x68a194: ldur            d0, [fp, #-0x40]
    // 0x68a198: ldur            x1, [fp, #-0x10]
    // 0x68a19c: ldur            d2, [fp, #-0x38]
    // 0x68a1a0: d1 = 2.000000
    //     0x68a1a0: fmov            d1, #2.00000000
    // 0x68a1a4: cmp             x2, #3
    // 0x68a1a8: b.gt            #0x68a1b8
    // 0x68a1ac: ldur            d0, [fp, #-0x30]
    // 0x68a1b0: d1 = 0.000000
    //     0x68a1b0: eor             v1.16b, v1.16b, v1.16b
    // 0x68a1b4: b               #0x68a21c
    // 0x68a1b8: LoadField: r2 = r0->field_73
    //     0x68a1b8: ldur            w2, [x0, #0x73]
    // 0x68a1bc: DecompressPointer r2
    //     0x68a1bc: add             x2, x2, HEAP, lsl #32
    // 0x68a1c0: r16 = Instance_Axis
    //     0x68a1c0: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x68a1c4: ldr             x16, [x16, #0x440]
    // 0x68a1c8: cmp             w2, w16
    // 0x68a1cc: b.ne            #0x68a214
    // 0x68a1d0: LoadField: r2 = r0->field_8b
    //     0x68a1d0: ldur            w2, [x0, #0x8b]
    // 0x68a1d4: DecompressPointer r2
    //     0x68a1d4: add             x2, x2, HEAP, lsl #32
    // 0x68a1d8: cmp             w2, NULL
    // 0x68a1dc: b.eq            #0x68a3f8
    // 0x68a1e0: stp             x2, x1, [SP, #-0x10]!
    // 0x68a1e4: r0 = getDistanceToActualBaseline()
    //     0x68a1e4: bl              #0x63d634  ; [package:flutter/src/rendering/box.dart] RenderBox::getDistanceToActualBaseline
    // 0x68a1e8: add             SP, SP, #0x10
    // 0x68a1ec: cmp             w0, NULL
    // 0x68a1f0: b.eq            #0x68a208
    // 0x68a1f4: ldur            d0, [fp, #-0x30]
    // 0x68a1f8: LoadField: d1 = r0->field_7
    //     0x68a1f8: ldur            d1, [x0, #7]
    // 0x68a1fc: fsub            d2, d0, d1
    // 0x68a200: mov             v1.16b, v2.16b
    // 0x68a204: b               #0x68a21c
    // 0x68a208: ldur            d0, [fp, #-0x30]
    // 0x68a20c: d1 = 0.000000
    //     0x68a20c: eor             v1.16b, v1.16b, v1.16b
    // 0x68a210: b               #0x68a21c
    // 0x68a214: ldur            d0, [fp, #-0x30]
    // 0x68a218: d1 = 0.000000
    //     0x68a218: eor             v1.16b, v1.16b, v1.16b
    // 0x68a21c: ldur            x0, [fp, #-0x18]
    // 0x68a220: stur            d1, [fp, #-0x50]
    // 0x68a224: tbnz            w0, #4, #0x68a278
    // 0x68a228: ldr             x1, [fp, #0x10]
    // 0x68a22c: ldur            x2, [fp, #-0x10]
    // 0x68a230: LoadField: r3 = r2->field_57
    //     0x68a230: ldur            w3, [x2, #0x57]
    // 0x68a234: DecompressPointer r3
    //     0x68a234: add             x3, x3, HEAP, lsl #32
    // 0x68a238: cmp             w3, NULL
    // 0x68a23c: b.eq            #0x68a3fc
    // 0x68a240: LoadField: r4 = r1->field_73
    //     0x68a240: ldur            w4, [x1, #0x73]
    // 0x68a244: DecompressPointer r4
    //     0x68a244: add             x4, x4, HEAP, lsl #32
    // 0x68a248: LoadField: r5 = r4->field_7
    //     0x68a248: ldur            x5, [x4, #7]
    // 0x68a24c: cmp             x5, #0
    // 0x68a250: b.gt            #0x68a260
    // 0x68a254: LoadField: d2 = r3->field_7
    //     0x68a254: ldur            d2, [x3, #7]
    // 0x68a258: mov             v3.16b, v2.16b
    // 0x68a25c: b               #0x68a268
    // 0x68a260: LoadField: d2 = r3->field_f
    //     0x68a260: ldur            d2, [x3, #0xf]
    // 0x68a264: mov             v3.16b, v2.16b
    // 0x68a268: ldur            d2, [fp, #-0x28]
    // 0x68a26c: fsub            d4, d2, d3
    // 0x68a270: mov             v2.16b, v4.16b
    // 0x68a274: b               #0x68a284
    // 0x68a278: ldr             x1, [fp, #0x10]
    // 0x68a27c: ldur            d2, [fp, #-0x28]
    // 0x68a280: ldur            x2, [fp, #-0x10]
    // 0x68a284: stur            d2, [fp, #-0x28]
    // 0x68a288: LoadField: r3 = r1->field_73
    //     0x68a288: ldur            w3, [x1, #0x73]
    // 0x68a28c: DecompressPointer r3
    //     0x68a28c: add             x3, x3, HEAP, lsl #32
    // 0x68a290: LoadField: r4 = r3->field_7
    //     0x68a290: ldur            x4, [x3, #7]
    // 0x68a294: cmp             x4, #0
    // 0x68a298: r16 = true
    //     0x68a298: add             x16, NULL, #0x20  ; true
    // 0x68a29c: r17 = false
    //     0x68a29c: add             x17, NULL, #0x30  ; false
    // 0x68a2a0: csel            x3, x16, x17, le
    // 0x68a2a4: stur            x3, [fp, #-0x20]
    // 0x68a2a8: tbnz            w3, #4, #0x68a2e8
    // 0x68a2ac: ldur            x4, [fp, #-8]
    // 0x68a2b0: r0 = Offset()
    //     0x68a2b0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x68a2b4: ldur            d0, [fp, #-0x28]
    // 0x68a2b8: StoreField: r0->field_7 = d0
    //     0x68a2b8: stur            d0, [x0, #7]
    // 0x68a2bc: ldur            d1, [fp, #-0x50]
    // 0x68a2c0: StoreField: r0->field_f = d1
    //     0x68a2c0: stur            d1, [x0, #0xf]
    // 0x68a2c4: ldur            x1, [fp, #-8]
    // 0x68a2c8: StoreField: r1->field_7 = r0
    //     0x68a2c8: stur            w0, [x1, #7]
    //     0x68a2cc: ldurb           w16, [x1, #-1]
    //     0x68a2d0: ldurb           w17, [x0, #-1]
    //     0x68a2d4: and             x16, x17, x16, lsr #2
    //     0x68a2d8: tst             x16, HEAP, lsr #32
    //     0x68a2dc: b.eq            #0x68a2e4
    //     0x68a2e0: bl              #0xd6826c
    // 0x68a2e4: b               #0x68a324
    // 0x68a2e8: ldur            x1, [fp, #-8]
    // 0x68a2ec: mov             v0.16b, v2.16b
    // 0x68a2f0: r0 = Offset()
    //     0x68a2f0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x68a2f4: ldur            d0, [fp, #-0x50]
    // 0x68a2f8: StoreField: r0->field_7 = d0
    //     0x68a2f8: stur            d0, [x0, #7]
    // 0x68a2fc: ldur            d0, [fp, #-0x28]
    // 0x68a300: StoreField: r0->field_f = d0
    //     0x68a300: stur            d0, [x0, #0xf]
    // 0x68a304: ldur            x1, [fp, #-8]
    // 0x68a308: StoreField: r1->field_7 = r0
    //     0x68a308: stur            w0, [x1, #7]
    //     0x68a30c: ldurb           w16, [x1, #-1]
    //     0x68a310: ldurb           w17, [x0, #-1]
    //     0x68a314: and             x16, x17, x16, lsr #2
    //     0x68a318: tst             x16, HEAP, lsr #32
    //     0x68a31c: b.eq            #0x68a324
    //     0x68a320: bl              #0xd6826c
    // 0x68a324: ldur            x2, [fp, #-0x18]
    // 0x68a328: tbnz            w2, #4, #0x68a33c
    // 0x68a32c: ldur            d1, [fp, #-0x48]
    // 0x68a330: fsub            d2, d0, d1
    // 0x68a334: mov             v5.16b, v2.16b
    // 0x68a338: b               #0x68a374
    // 0x68a33c: ldur            d1, [fp, #-0x48]
    // 0x68a340: ldur            x3, [fp, #-0x10]
    // 0x68a344: ldur            x4, [fp, #-0x20]
    // 0x68a348: LoadField: r5 = r3->field_57
    //     0x68a348: ldur            w5, [x3, #0x57]
    // 0x68a34c: DecompressPointer r5
    //     0x68a34c: add             x5, x5, HEAP, lsl #32
    // 0x68a350: cmp             w5, NULL
    // 0x68a354: b.eq            #0x68a400
    // 0x68a358: tbnz            w4, #4, #0x68a364
    // 0x68a35c: LoadField: d2 = r5->field_7
    //     0x68a35c: ldur            d2, [x5, #7]
    // 0x68a360: b               #0x68a368
    // 0x68a364: LoadField: d2 = r5->field_f
    //     0x68a364: ldur            d2, [x5, #0xf]
    // 0x68a368: fadd            d3, d2, d1
    // 0x68a36c: fadd            d2, d0, d3
    // 0x68a370: mov             v5.16b, v2.16b
    // 0x68a374: LoadField: r5 = r1->field_13
    //     0x68a374: ldur            w5, [x1, #0x13]
    // 0x68a378: DecompressPointer r5
    //     0x68a378: add             x5, x5, HEAP, lsl #32
    // 0x68a37c: ldr             x3, [fp, #0x10]
    // 0x68a380: ldur            d2, [fp, #-0x40]
    // 0x68a384: mov             x4, x2
    // 0x68a388: mov             v0.16b, v1.16b
    // 0x68a38c: ldur            d4, [fp, #-0x38]
    // 0x68a390: d1 = 2.000000
    //     0x68a390: fmov            d1, #2.00000000
    // 0x68a394: b               #0x689fe8
    // 0x68a398: r0 = Null
    //     0x68a398: mov             x0, NULL
    // 0x68a39c: LeaveFrame
    //     0x68a39c: mov             SP, fp
    //     0x68a3a0: ldp             fp, lr, [SP], #0x10
    // 0x68a3a4: ret
    //     0x68a3a4: ret             
    // 0x68a3a8: r0 = StateError()
    //     0x68a3a8: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68a3ac: mov             x1, x0
    // 0x68a3b0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68a3b0: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68a3b4: ldr             x0, [x0, #0x1e8]
    // 0x68a3b8: StoreField: r1->field_b = r0
    //     0x68a3b8: stur            w0, [x1, #0xb]
    // 0x68a3bc: mov             x0, x1
    // 0x68a3c0: r0 = Throw()
    //     0x68a3c0: bl              #0xd67e38  ; ThrowStub
    // 0x68a3c4: brk             #0
    // 0x68a3c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68a3c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68a3cc: b               #0x6899d8
    // 0x68a3d0: r0 = StackOverflowSharedWithFPURegs()
    //     0x68a3d0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x68a3d4: b               #0x689aac
    // 0x68a3d8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68a3d8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x68a3dc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68a3dc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x68a3e0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68a3e0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x68a3e4: r0 = StackOverflowSharedWithFPURegs()
    //     0x68a3e4: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x68a3e8: b               #0x68a000
    // 0x68a3ec: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68a3ec: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x68a3f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68a3f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68a3f4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68a3f4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x68a3f8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68a3f8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x68a3fc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68a3fc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x68a400: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68a400: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _computeSizes(/* No info */) {
    // ** addr: 0x68a5d4, size: 0x91c
    // 0x68a5d4: EnterFrame
    //     0x68a5d4: stp             fp, lr, [SP, #-0x10]!
    //     0x68a5d8: mov             fp, SP
    // 0x68a5dc: AllocStack(0x90)
    //     0x68a5dc: sub             SP, SP, #0x90
    // 0x68a5e0: CheckStackOverflow
    //     0x68a5e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68a5e4: cmp             SP, x16
    //     0x68a5e8: b.ls            #0x68aecc
    // 0x68a5ec: ldr             x3, [fp, #0x20]
    // 0x68a5f0: LoadField: r0 = r3->field_73
    //     0x68a5f0: ldur            w0, [x3, #0x73]
    // 0x68a5f4: DecompressPointer r0
    //     0x68a5f4: add             x0, x0, HEAP, lsl #32
    // 0x68a5f8: r16 = Instance_Axis
    //     0x68a5f8: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x68a5fc: ldr             x16, [x16, #0x440]
    // 0x68a600: cmp             w0, w16
    // 0x68a604: b.ne            #0x68a618
    // 0x68a608: ldr             x1, [fp, #0x18]
    // 0x68a60c: LoadField: d0 = r1->field_f
    //     0x68a60c: ldur            d0, [x1, #0xf]
    // 0x68a610: mov             v1.16b, v0.16b
    // 0x68a614: b               #0x68a624
    // 0x68a618: ldr             x1, [fp, #0x18]
    // 0x68a61c: LoadField: d0 = r1->field_1f
    //     0x68a61c: ldur            d0, [x1, #0x1f]
    // 0x68a620: mov             v1.16b, v0.16b
    // 0x68a624: d0 = inf
    //     0x68a624: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x68a628: stur            d1, [fp, #-0x58]
    // 0x68a62c: fcmp            d1, d0
    // 0x68a630: b.vs            #0x68a638
    // 0x68a634: b.lt            #0x68a640
    // 0x68a638: r4 = false
    //     0x68a638: add             x4, NULL, #0x30  ; false
    // 0x68a63c: b               #0x68a644
    // 0x68a640: r4 = true
    //     0x68a640: add             x4, NULL, #0x20  ; true
    // 0x68a644: stur            x4, [fp, #-0x30]
    // 0x68a648: LoadField: r2 = r3->field_67
    //     0x68a648: ldur            w2, [x3, #0x67]
    // 0x68a64c: DecompressPointer r2
    //     0x68a64c: add             x2, x2, HEAP, lsl #32
    // 0x68a650: LoadField: d2 = r1->field_f
    //     0x68a650: ldur            d2, [x1, #0xf]
    // 0x68a654: stur            d2, [fp, #-0x50]
    // 0x68a658: LoadField: d3 = r1->field_1f
    //     0x68a658: ldur            d3, [x1, #0x1f]
    // 0x68a65c: stur            d3, [fp, #-0x48]
    // 0x68a660: mov             x7, x2
    // 0x68a664: mov             x5, x0
    // 0x68a668: r8 = 0
    //     0x68a668: mov             x8, #0
    // 0x68a66c: d5 = 0.000000
    //     0x68a66c: eor             v5.16b, v5.16b, v5.16b
    // 0x68a670: d4 = 0.000000
    //     0x68a670: eor             v4.16b, v4.16b, v4.16b
    // 0x68a674: r6 = Null
    //     0x68a674: mov             x6, NULL
    // 0x68a678: stur            x8, [fp, #-0x10]
    // 0x68a67c: stur            x7, [fp, #-0x18]
    // 0x68a680: stur            x6, [fp, #-0x20]
    // 0x68a684: stur            x5, [fp, #-0x28]
    // 0x68a688: stur            d5, [fp, #-0x38]
    // 0x68a68c: stur            d4, [fp, #-0x40]
    // 0x68a690: CheckStackOverflow
    //     0x68a690: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68a694: cmp             SP, x16
    //     0x68a698: b.ls            #0x68aed4
    // 0x68a69c: cmp             w7, NULL
    // 0x68a6a0: b.eq            #0x68a968
    // 0x68a6a4: LoadField: r9 = r7->field_17
    //     0x68a6a4: ldur            w9, [x7, #0x17]
    // 0x68a6a8: DecompressPointer r9
    //     0x68a6a8: add             x9, x9, HEAP, lsl #32
    // 0x68a6ac: stur            x9, [fp, #-8]
    // 0x68a6b0: cmp             w9, NULL
    // 0x68a6b4: b.eq            #0x68aedc
    // 0x68a6b8: mov             x0, x9
    // 0x68a6bc: r2 = Null
    //     0x68a6bc: mov             x2, NULL
    // 0x68a6c0: r1 = Null
    //     0x68a6c0: mov             x1, NULL
    // 0x68a6c4: r4 = LoadClassIdInstr(r0)
    //     0x68a6c4: ldur            x4, [x0, #-1]
    //     0x68a6c8: ubfx            x4, x4, #0xc, #0x14
    // 0x68a6cc: cmp             x4, #0x809
    // 0x68a6d0: b.eq            #0x68a6e8
    // 0x68a6d4: r8 = FlexParentData<RenderBox>
    //     0x68a6d4: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x68a6d8: ldr             x8, [x8, #0x248]
    // 0x68a6dc: r3 = Null
    //     0x68a6dc: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d2c0] Null
    //     0x68a6e0: ldr             x3, [x3, #0x2c0]
    // 0x68a6e4: r0 = DefaultTypeTest()
    //     0x68a6e4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x68a6e8: ldur            x0, [fp, #-8]
    // 0x68a6ec: LoadField: r1 = r0->field_17
    //     0x68a6ec: ldur            w1, [x0, #0x17]
    // 0x68a6f0: DecompressPointer r1
    //     0x68a6f0: add             x1, x1, HEAP, lsl #32
    // 0x68a6f4: cmp             w1, NULL
    // 0x68a6f8: b.ne            #0x68a704
    // 0x68a6fc: r1 = 0
    //     0x68a6fc: mov             x1, #0
    // 0x68a700: b               #0x68a70c
    // 0x68a704: r2 = LoadInt32Instr(r1)
    //     0x68a704: sbfx            x2, x1, #1, #0x1f
    // 0x68a708: mov             x1, x2
    // 0x68a70c: cmp             x1, #0
    // 0x68a710: b.le            #0x68a73c
    // 0x68a714: ldur            x2, [fp, #-0x10]
    // 0x68a718: add             x3, x2, x1
    // 0x68a71c: mov             x8, x3
    // 0x68a720: ldur            d5, [fp, #-0x38]
    // 0x68a724: ldur            d4, [fp, #-0x40]
    // 0x68a728: ldur            x6, [fp, #-0x18]
    // 0x68a72c: ldur            x5, [fp, #-0x28]
    // 0x68a730: ldr             x4, [fp, #0x20]
    // 0x68a734: d3 = 0.000000
    //     0x68a734: eor             v3.16b, v3.16b, v3.16b
    // 0x68a738: b               #0x68a944
    // 0x68a73c: ldr             x1, [fp, #0x20]
    // 0x68a740: ldur            x2, [fp, #-0x10]
    // 0x68a744: LoadField: r3 = r1->field_7f
    //     0x68a744: ldur            w3, [x1, #0x7f]
    // 0x68a748: DecompressPointer r3
    //     0x68a748: add             x3, x3, HEAP, lsl #32
    // 0x68a74c: r16 = Instance_CrossAxisAlignment
    //     0x68a74c: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d2d0] Obj!CrossAxisAlignment@b64a11
    //     0x68a750: ldr             x16, [x16, #0x2d0]
    // 0x68a754: cmp             w3, w16
    // 0x68a758: b.ne            #0x68a7e0
    // 0x68a75c: ldur            x3, [fp, #-0x28]
    // 0x68a760: LoadField: r4 = r3->field_7
    //     0x68a760: ldur            x4, [x3, #7]
    // 0x68a764: cmp             x4, #0
    // 0x68a768: b.gt            #0x68a7a0
    // 0x68a76c: ldur            d0, [fp, #-0x48]
    // 0x68a770: r0 = BoxConstraints()
    //     0x68a770: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x68a774: d0 = 0.000000
    //     0x68a774: eor             v0.16b, v0.16b, v0.16b
    // 0x68a778: StoreField: r0->field_7 = d0
    //     0x68a778: stur            d0, [x0, #7]
    // 0x68a77c: d1 = inf
    //     0x68a77c: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x68a780: StoreField: r0->field_f = d1
    //     0x68a780: stur            d1, [x0, #0xf]
    // 0x68a784: ldur            d2, [fp, #-0x48]
    // 0x68a788: StoreField: r0->field_17 = d2
    //     0x68a788: stur            d2, [x0, #0x17]
    // 0x68a78c: StoreField: r0->field_1f = d2
    //     0x68a78c: stur            d2, [x0, #0x1f]
    // 0x68a790: mov             v2.16b, v1.16b
    // 0x68a794: mov             v1.16b, v0.16b
    // 0x68a798: ldur            d0, [fp, #-0x50]
    // 0x68a79c: b               #0x68a7d0
    // 0x68a7a0: ldur            d3, [fp, #-0x50]
    // 0x68a7a4: ldur            d2, [fp, #-0x48]
    // 0x68a7a8: d1 = inf
    //     0x68a7a8: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x68a7ac: d0 = 0.000000
    //     0x68a7ac: eor             v0.16b, v0.16b, v0.16b
    // 0x68a7b0: r0 = BoxConstraints()
    //     0x68a7b0: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x68a7b4: ldur            d0, [fp, #-0x50]
    // 0x68a7b8: StoreField: r0->field_7 = d0
    //     0x68a7b8: stur            d0, [x0, #7]
    // 0x68a7bc: StoreField: r0->field_f = d0
    //     0x68a7bc: stur            d0, [x0, #0xf]
    // 0x68a7c0: d1 = 0.000000
    //     0x68a7c0: eor             v1.16b, v1.16b, v1.16b
    // 0x68a7c4: StoreField: r0->field_17 = d1
    //     0x68a7c4: stur            d1, [x0, #0x17]
    // 0x68a7c8: d2 = inf
    //     0x68a7c8: ldr             d2, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x68a7cc: StoreField: r0->field_1f = d2
    //     0x68a7cc: stur            d2, [x0, #0x1f]
    // 0x68a7d0: mov             v31.16b, v1.16b
    // 0x68a7d4: mov             v1.16b, v0.16b
    // 0x68a7d8: mov             v0.16b, v31.16b
    // 0x68a7dc: b               #0x68a85c
    // 0x68a7e0: ldur            d0, [fp, #-0x50]
    // 0x68a7e4: ldur            x3, [fp, #-0x28]
    // 0x68a7e8: d2 = inf
    //     0x68a7e8: ldr             d2, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x68a7ec: d1 = 0.000000
    //     0x68a7ec: eor             v1.16b, v1.16b, v1.16b
    // 0x68a7f0: LoadField: r0 = r3->field_7
    //     0x68a7f0: ldur            x0, [x3, #7]
    // 0x68a7f4: cmp             x0, #0
    // 0x68a7f8: b.gt            #0x68a82c
    // 0x68a7fc: ldur            d3, [fp, #-0x48]
    // 0x68a800: r0 = BoxConstraints()
    //     0x68a800: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x68a804: d0 = 0.000000
    //     0x68a804: eor             v0.16b, v0.16b, v0.16b
    // 0x68a808: StoreField: r0->field_7 = d0
    //     0x68a808: stur            d0, [x0, #7]
    // 0x68a80c: d1 = inf
    //     0x68a80c: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x68a810: StoreField: r0->field_f = d1
    //     0x68a810: stur            d1, [x0, #0xf]
    // 0x68a814: StoreField: r0->field_17 = d0
    //     0x68a814: stur            d0, [x0, #0x17]
    // 0x68a818: ldur            d2, [fp, #-0x48]
    // 0x68a81c: StoreField: r0->field_1f = d2
    //     0x68a81c: stur            d2, [x0, #0x1f]
    // 0x68a820: mov             v2.16b, v1.16b
    // 0x68a824: ldur            d1, [fp, #-0x50]
    // 0x68a828: b               #0x68a85c
    // 0x68a82c: mov             v3.16b, v0.16b
    // 0x68a830: mov             v0.16b, v1.16b
    // 0x68a834: mov             v1.16b, v2.16b
    // 0x68a838: ldur            d2, [fp, #-0x48]
    // 0x68a83c: r0 = BoxConstraints()
    //     0x68a83c: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x68a840: d0 = 0.000000
    //     0x68a840: eor             v0.16b, v0.16b, v0.16b
    // 0x68a844: StoreField: r0->field_7 = d0
    //     0x68a844: stur            d0, [x0, #7]
    // 0x68a848: ldur            d1, [fp, #-0x50]
    // 0x68a84c: StoreField: r0->field_f = d1
    //     0x68a84c: stur            d1, [x0, #0xf]
    // 0x68a850: StoreField: r0->field_17 = d0
    //     0x68a850: stur            d0, [x0, #0x17]
    // 0x68a854: d2 = inf
    //     0x68a854: ldr             d2, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x68a858: StoreField: r0->field_1f = d2
    //     0x68a858: stur            d2, [x0, #0x1f]
    // 0x68a85c: ldr             x1, [fp, #0x20]
    // 0x68a860: ldr             x16, [fp, #0x10]
    // 0x68a864: ldur            lr, [fp, #-0x18]
    // 0x68a868: stp             lr, x16, [SP, #-0x10]!
    // 0x68a86c: SaveReg r0
    //     0x68a86c: str             x0, [SP, #-8]!
    // 0x68a870: ldr             x0, [fp, #0x10]
    // 0x68a874: ClosureCall
    //     0x68a874: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x68a878: ldur            x2, [x0, #0x1f]
    //     0x68a87c: blr             x2
    // 0x68a880: add             SP, SP, #0x18
    // 0x68a884: ldr             x4, [fp, #0x20]
    // 0x68a888: LoadField: r1 = r4->field_73
    //     0x68a888: ldur            w1, [x4, #0x73]
    // 0x68a88c: DecompressPointer r1
    //     0x68a88c: add             x1, x1, HEAP, lsl #32
    // 0x68a890: LoadField: r2 = r1->field_7
    //     0x68a890: ldur            x2, [x1, #7]
    // 0x68a894: cmp             x2, #0
    // 0x68a898: r16 = true
    //     0x68a898: add             x16, NULL, #0x20  ; true
    // 0x68a89c: r17 = false
    //     0x68a89c: add             x17, NULL, #0x30  ; false
    // 0x68a8a0: csel            x3, x16, x17, le
    // 0x68a8a4: tbnz            w3, #4, #0x68a8b4
    // 0x68a8a8: LoadField: d0 = r0->field_7
    //     0x68a8a8: ldur            d0, [x0, #7]
    // 0x68a8ac: mov             v1.16b, v0.16b
    // 0x68a8b0: b               #0x68a8bc
    // 0x68a8b4: LoadField: d0 = r0->field_f
    //     0x68a8b4: ldur            d0, [x0, #0xf]
    // 0x68a8b8: mov             v1.16b, v0.16b
    // 0x68a8bc: ldur            d0, [fp, #-0x40]
    // 0x68a8c0: fadd            d2, d0, d1
    // 0x68a8c4: tbnz            w3, #4, #0x68a8d0
    // 0x68a8c8: LoadField: d0 = r0->field_f
    //     0x68a8c8: ldur            d0, [x0, #0xf]
    // 0x68a8cc: b               #0x68a8d4
    // 0x68a8d0: LoadField: d0 = r0->field_7
    //     0x68a8d0: ldur            d0, [x0, #7]
    // 0x68a8d4: ldur            d1, [fp, #-0x38]
    // 0x68a8d8: fcmp            d1, d0
    // 0x68a8dc: b.vs            #0x68a8f0
    // 0x68a8e0: b.le            #0x68a8f0
    // 0x68a8e4: mov             v0.16b, v1.16b
    // 0x68a8e8: d3 = 0.000000
    //     0x68a8e8: eor             v3.16b, v3.16b, v3.16b
    // 0x68a8ec: b               #0x68a92c
    // 0x68a8f0: fcmp            d1, d0
    // 0x68a8f4: b.vs            #0x68a904
    // 0x68a8f8: b.ge            #0x68a904
    // 0x68a8fc: d3 = 0.000000
    //     0x68a8fc: eor             v3.16b, v3.16b, v3.16b
    // 0x68a900: b               #0x68a92c
    // 0x68a904: d3 = 0.000000
    //     0x68a904: eor             v3.16b, v3.16b, v3.16b
    // 0x68a908: fcmp            d1, d3
    // 0x68a90c: b.vs            #0x68a920
    // 0x68a910: b.ne            #0x68a920
    // 0x68a914: fadd            d5, d1, d0
    // 0x68a918: mov             v0.16b, v5.16b
    // 0x68a91c: b               #0x68a92c
    // 0x68a920: fcmp            d0, d0
    // 0x68a924: b.vs            #0x68a92c
    // 0x68a928: mov             v0.16b, v1.16b
    // 0x68a92c: ldur            x8, [fp, #-0x10]
    // 0x68a930: mov             v5.16b, v0.16b
    // 0x68a934: mov             v4.16b, v2.16b
    // 0x68a938: ldur            x6, [fp, #-0x20]
    // 0x68a93c: mov             x5, x1
    // 0x68a940: ldur            x0, [fp, #-8]
    // 0x68a944: LoadField: r7 = r0->field_13
    //     0x68a944: ldur            w7, [x0, #0x13]
    // 0x68a948: DecompressPointer r7
    //     0x68a948: add             x7, x7, HEAP, lsl #32
    // 0x68a94c: mov             x3, x4
    // 0x68a950: ldur            d1, [fp, #-0x58]
    // 0x68a954: ldur            x4, [fp, #-0x30]
    // 0x68a958: ldur            d2, [fp, #-0x50]
    // 0x68a95c: ldur            d3, [fp, #-0x48]
    // 0x68a960: d0 = inf
    //     0x68a960: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x68a964: b               #0x68a678
    // 0x68a968: mov             x16, x5
    // 0x68a96c: mov             x5, x3
    // 0x68a970: mov             x3, x16
    // 0x68a974: mov             x16, x4
    // 0x68a978: mov             x4, x5
    // 0x68a97c: mov             x5, x16
    // 0x68a980: mov             v1.16b, v5.16b
    // 0x68a984: mov             v0.16b, v4.16b
    // 0x68a988: d3 = 0.000000
    //     0x68a988: eor             v3.16b, v3.16b, v3.16b
    // 0x68a98c: tbnz            w5, #4, #0x68a998
    // 0x68a990: ldur            d2, [fp, #-0x58]
    // 0x68a994: b               #0x68a99c
    // 0x68a998: d2 = 0.000000
    //     0x68a998: eor             v2.16b, v2.16b, v2.16b
    // 0x68a99c: fsub            d4, d2, d0
    // 0x68a9a0: fcmp            d3, d4
    // 0x68a9a4: b.vs            #0x68a9b4
    // 0x68a9a8: b.le            #0x68a9b4
    // 0x68a9ac: d2 = 0.000000
    //     0x68a9ac: eor             v2.16b, v2.16b, v2.16b
    // 0x68a9b0: b               #0x68a9f0
    // 0x68a9b4: fcmp            d3, d4
    // 0x68a9b8: b.vs            #0x68a9c8
    // 0x68a9bc: b.ge            #0x68a9c8
    // 0x68a9c0: mov             v2.16b, v4.16b
    // 0x68a9c4: b               #0x68a9f0
    // 0x68a9c8: fcmp            d3, d3
    // 0x68a9cc: b.vs            #0x68a9dc
    // 0x68a9d0: b.ne            #0x68a9dc
    // 0x68a9d4: fadd            d2, d3, d4
    // 0x68a9d8: b               #0x68a9f0
    // 0x68a9dc: fcmp            d4, d4
    // 0x68a9e0: b.vc            #0x68a9ec
    // 0x68a9e4: mov             v2.16b, v4.16b
    // 0x68a9e8: b               #0x68a9f0
    // 0x68a9ec: d2 = 0.000000
    //     0x68a9ec: eor             v2.16b, v2.16b, v2.16b
    // 0x68a9f0: ldur            x0, [fp, #-0x10]
    // 0x68a9f4: stur            d2, [fp, #-0x80]
    // 0x68a9f8: cmp             x0, #0
    // 0x68a9fc: b.le            #0x68ae68
    // 0x68aa00: tbnz            w5, #4, #0x68aa14
    // 0x68aa04: scvtf           d4, x0
    // 0x68aa08: fdiv            d5, d2, d4
    // 0x68aa0c: mov             v4.16b, v5.16b
    // 0x68aa10: b               #0x68aa18
    // 0x68aa14: d4 = -nan
    //     0x68aa14: ldr             d4, [PP, #0x4650]  ; [pp+0x4650] IMM: double(-nan) from 0xfff8000000000000
    // 0x68aa18: stur            d4, [fp, #-0x78]
    // 0x68aa1c: LoadField: r0 = r4->field_67
    //     0x68aa1c: ldur            w0, [x4, #0x67]
    // 0x68aa20: DecompressPointer r0
    //     0x68aa20: add             x0, x0, HEAP, lsl #32
    // 0x68aa24: mov             v7.16b, v1.16b
    // 0x68aa28: mov             v6.16b, v0.16b
    // 0x68aa2c: mov             x7, x0
    // 0x68aa30: mov             x6, x3
    // 0x68aa34: d5 = 0.000000
    //     0x68aa34: eor             v5.16b, v5.16b, v5.16b
    // 0x68aa38: ldur            x3, [fp, #-0x20]
    // 0x68aa3c: ldur            d0, [fp, #-0x50]
    // 0x68aa40: ldur            d1, [fp, #-0x48]
    // 0x68aa44: stur            x7, [fp, #-0x18]
    // 0x68aa48: stur            x6, [fp, #-0x28]
    // 0x68aa4c: stur            d7, [fp, #-0x60]
    // 0x68aa50: stur            d6, [fp, #-0x68]
    // 0x68aa54: stur            d5, [fp, #-0x70]
    // 0x68aa58: CheckStackOverflow
    //     0x68aa58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68aa5c: cmp             SP, x16
    //     0x68aa60: b.ls            #0x68aee0
    // 0x68aa64: cmp             w7, NULL
    // 0x68aa68: b.eq            #0x68ae58
    // 0x68aa6c: LoadField: r8 = r7->field_17
    //     0x68aa6c: ldur            w8, [x7, #0x17]
    // 0x68aa70: DecompressPointer r8
    //     0x68aa70: add             x8, x8, HEAP, lsl #32
    // 0x68aa74: stur            x8, [fp, #-8]
    // 0x68aa78: cmp             w8, NULL
    // 0x68aa7c: b.eq            #0x68aee8
    // 0x68aa80: mov             x0, x8
    // 0x68aa84: r2 = Null
    //     0x68aa84: mov             x2, NULL
    // 0x68aa88: r1 = Null
    //     0x68aa88: mov             x1, NULL
    // 0x68aa8c: r4 = LoadClassIdInstr(r0)
    //     0x68aa8c: ldur            x4, [x0, #-1]
    //     0x68aa90: ubfx            x4, x4, #0xc, #0x14
    // 0x68aa94: cmp             x4, #0x809
    // 0x68aa98: b.eq            #0x68aab0
    // 0x68aa9c: r8 = FlexParentData<RenderBox>
    //     0x68aa9c: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x68aaa0: ldr             x8, [x8, #0x248]
    // 0x68aaa4: r3 = Null
    //     0x68aaa4: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d2d8] Null
    //     0x68aaa8: ldr             x3, [x3, #0x2d8]
    // 0x68aaac: r0 = DefaultTypeTest()
    //     0x68aaac: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x68aab0: ldur            x0, [fp, #-8]
    // 0x68aab4: LoadField: r1 = r0->field_17
    //     0x68aab4: ldur            w1, [x0, #0x17]
    // 0x68aab8: DecompressPointer r1
    //     0x68aab8: add             x1, x1, HEAP, lsl #32
    // 0x68aabc: cmp             w1, NULL
    // 0x68aac0: b.ne            #0x68aacc
    // 0x68aac4: r1 = 0
    //     0x68aac4: mov             x1, #0
    // 0x68aac8: b               #0x68aad4
    // 0x68aacc: r2 = LoadInt32Instr(r1)
    //     0x68aacc: sbfx            x2, x1, #1, #0x1f
    // 0x68aad0: mov             x1, x2
    // 0x68aad4: cmp             x1, #0
    // 0x68aad8: b.le            #0x68ada4
    // 0x68aadc: ldur            x2, [fp, #-0x30]
    // 0x68aae0: tbnz            w2, #4, #0x68ab30
    // 0x68aae4: ldur            x3, [fp, #-0x20]
    // 0x68aae8: ldur            x4, [fp, #-0x18]
    // 0x68aaec: cmp             w4, w3
    // 0x68aaf0: b.ne            #0x68ab0c
    // 0x68aaf4: ldur            d1, [fp, #-0x70]
    // 0x68aaf8: ldur            d0, [fp, #-0x80]
    // 0x68aafc: fsub            d2, d0, d1
    // 0x68ab00: mov             v3.16b, v2.16b
    // 0x68ab04: ldur            d2, [fp, #-0x78]
    // 0x68ab08: b               #0x68ab48
    // 0x68ab0c: ldur            d2, [fp, #-0x78]
    // 0x68ab10: ldur            d1, [fp, #-0x70]
    // 0x68ab14: ldur            d0, [fp, #-0x80]
    // 0x68ab18: lsl             x5, x1, #1
    // 0x68ab1c: r16 = LoadInt32Instr(r5)
    //     0x68ab1c: sbfx            x16, x5, #1, #0x1f
    // 0x68ab20: scvtf           d3, w16
    // 0x68ab24: fmul            d4, d2, d3
    // 0x68ab28: mov             v3.16b, v4.16b
    // 0x68ab2c: b               #0x68ab48
    // 0x68ab30: ldur            x3, [fp, #-0x20]
    // 0x68ab34: ldur            d2, [fp, #-0x78]
    // 0x68ab38: ldur            x4, [fp, #-0x18]
    // 0x68ab3c: ldur            d1, [fp, #-0x70]
    // 0x68ab40: ldur            d0, [fp, #-0x80]
    // 0x68ab44: d3 = inf
    //     0x68ab44: ldr             d3, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x68ab48: stur            d3, [fp, #-0x90]
    // 0x68ab4c: LoadField: r1 = r0->field_1b
    //     0x68ab4c: ldur            w1, [x0, #0x1b]
    // 0x68ab50: DecompressPointer r1
    //     0x68ab50: add             x1, x1, HEAP, lsl #32
    // 0x68ab54: cmp             w1, NULL
    // 0x68ab58: b.ne            #0x68ab68
    // 0x68ab5c: r0 = Instance_FlexFit
    //     0x68ab5c: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d2e8] Obj!FlexFit@b64b91
    //     0x68ab60: ldr             x0, [x0, #0x2e8]
    // 0x68ab64: b               #0x68ab6c
    // 0x68ab68: mov             x0, x1
    // 0x68ab6c: LoadField: r1 = r0->field_7
    //     0x68ab6c: ldur            x1, [x0, #7]
    // 0x68ab70: cmp             x1, #0
    // 0x68ab74: b.gt            #0x68ab80
    // 0x68ab78: mov             v4.16b, v3.16b
    // 0x68ab7c: b               #0x68ab84
    // 0x68ab80: d4 = 0.000000
    //     0x68ab80: eor             v4.16b, v4.16b, v4.16b
    // 0x68ab84: ldr             x0, [fp, #0x20]
    // 0x68ab88: stur            d4, [fp, #-0x88]
    // 0x68ab8c: LoadField: r1 = r0->field_7f
    //     0x68ab8c: ldur            w1, [x0, #0x7f]
    // 0x68ab90: DecompressPointer r1
    //     0x68ab90: add             x1, x1, HEAP, lsl #32
    // 0x68ab94: r16 = Instance_CrossAxisAlignment
    //     0x68ab94: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d2d0] Obj!CrossAxisAlignment@b64a11
    //     0x68ab98: ldr             x16, [x16, #0x2d0]
    // 0x68ab9c: cmp             w1, w16
    // 0x68aba0: b.ne            #0x68ac20
    // 0x68aba4: ldur            x1, [fp, #-0x28]
    // 0x68aba8: LoadField: r5 = r1->field_7
    //     0x68aba8: ldur            x5, [x1, #7]
    // 0x68abac: cmp             x5, #0
    // 0x68abb0: b.gt            #0x68abe4
    // 0x68abb4: ldur            d5, [fp, #-0x48]
    // 0x68abb8: r0 = BoxConstraints()
    //     0x68abb8: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x68abbc: ldur            d0, [fp, #-0x88]
    // 0x68abc0: StoreField: r0->field_7 = d0
    //     0x68abc0: stur            d0, [x0, #7]
    // 0x68abc4: ldur            d1, [fp, #-0x90]
    // 0x68abc8: StoreField: r0->field_f = d1
    //     0x68abc8: stur            d1, [x0, #0xf]
    // 0x68abcc: ldur            d2, [fp, #-0x48]
    // 0x68abd0: StoreField: r0->field_17 = d2
    //     0x68abd0: stur            d2, [x0, #0x17]
    // 0x68abd4: StoreField: r0->field_1f = d2
    //     0x68abd4: stur            d2, [x0, #0x1f]
    // 0x68abd8: mov             v2.16b, v1.16b
    // 0x68abdc: ldur            d0, [fp, #-0x50]
    // 0x68abe0: b               #0x68ac14
    // 0x68abe4: mov             v1.16b, v3.16b
    // 0x68abe8: mov             v0.16b, v4.16b
    // 0x68abec: ldur            d3, [fp, #-0x50]
    // 0x68abf0: ldur            d2, [fp, #-0x48]
    // 0x68abf4: r0 = BoxConstraints()
    //     0x68abf4: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x68abf8: ldur            d0, [fp, #-0x50]
    // 0x68abfc: StoreField: r0->field_7 = d0
    //     0x68abfc: stur            d0, [x0, #7]
    // 0x68ac00: StoreField: r0->field_f = d0
    //     0x68ac00: stur            d0, [x0, #0xf]
    // 0x68ac04: ldur            d1, [fp, #-0x88]
    // 0x68ac08: StoreField: r0->field_17 = d1
    //     0x68ac08: stur            d1, [x0, #0x17]
    // 0x68ac0c: ldur            d2, [fp, #-0x90]
    // 0x68ac10: StoreField: r0->field_1f = d2
    //     0x68ac10: stur            d2, [x0, #0x1f]
    // 0x68ac14: mov             v1.16b, v0.16b
    // 0x68ac18: d0 = 0.000000
    //     0x68ac18: eor             v0.16b, v0.16b, v0.16b
    // 0x68ac1c: b               #0x68acac
    // 0x68ac20: mov             v2.16b, v3.16b
    // 0x68ac24: mov             v1.16b, v4.16b
    // 0x68ac28: ldur            d0, [fp, #-0x50]
    // 0x68ac2c: ldur            x1, [fp, #-0x28]
    // 0x68ac30: LoadField: r0 = r1->field_7
    //     0x68ac30: ldur            x0, [x1, #7]
    // 0x68ac34: cmp             x0, #0
    // 0x68ac38: b.gt            #0x68ac74
    // 0x68ac3c: ldur            d3, [fp, #-0x48]
    // 0x68ac40: r0 = BoxConstraints()
    //     0x68ac40: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x68ac44: ldur            d0, [fp, #-0x88]
    // 0x68ac48: StoreField: r0->field_7 = d0
    //     0x68ac48: stur            d0, [x0, #7]
    // 0x68ac4c: ldur            d1, [fp, #-0x90]
    // 0x68ac50: StoreField: r0->field_f = d1
    //     0x68ac50: stur            d1, [x0, #0xf]
    // 0x68ac54: d2 = 0.000000
    //     0x68ac54: eor             v2.16b, v2.16b, v2.16b
    // 0x68ac58: StoreField: r0->field_17 = d2
    //     0x68ac58: stur            d2, [x0, #0x17]
    // 0x68ac5c: ldur            d3, [fp, #-0x48]
    // 0x68ac60: StoreField: r0->field_1f = d3
    //     0x68ac60: stur            d3, [x0, #0x1f]
    // 0x68ac64: mov             v0.16b, v2.16b
    // 0x68ac68: mov             v2.16b, v1.16b
    // 0x68ac6c: ldur            d1, [fp, #-0x50]
    // 0x68ac70: b               #0x68acac
    // 0x68ac74: mov             v4.16b, v0.16b
    // 0x68ac78: mov             v0.16b, v1.16b
    // 0x68ac7c: mov             v1.16b, v2.16b
    // 0x68ac80: ldur            d3, [fp, #-0x48]
    // 0x68ac84: d2 = 0.000000
    //     0x68ac84: eor             v2.16b, v2.16b, v2.16b
    // 0x68ac88: r0 = BoxConstraints()
    //     0x68ac88: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x68ac8c: d0 = 0.000000
    //     0x68ac8c: eor             v0.16b, v0.16b, v0.16b
    // 0x68ac90: StoreField: r0->field_7 = d0
    //     0x68ac90: stur            d0, [x0, #7]
    // 0x68ac94: ldur            d1, [fp, #-0x50]
    // 0x68ac98: StoreField: r0->field_f = d1
    //     0x68ac98: stur            d1, [x0, #0xf]
    // 0x68ac9c: ldur            d2, [fp, #-0x88]
    // 0x68aca0: StoreField: r0->field_17 = d2
    //     0x68aca0: stur            d2, [x0, #0x17]
    // 0x68aca4: ldur            d2, [fp, #-0x90]
    // 0x68aca8: StoreField: r0->field_1f = d2
    //     0x68aca8: stur            d2, [x0, #0x1f]
    // 0x68acac: ldr             x1, [fp, #0x20]
    // 0x68acb0: ldr             x16, [fp, #0x10]
    // 0x68acb4: ldur            lr, [fp, #-0x18]
    // 0x68acb8: stp             lr, x16, [SP, #-0x10]!
    // 0x68acbc: SaveReg r0
    //     0x68acbc: str             x0, [SP, #-8]!
    // 0x68acc0: ldr             x0, [fp, #0x10]
    // 0x68acc4: ClosureCall
    //     0x68acc4: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x68acc8: ldur            x2, [x0, #0x1f]
    //     0x68accc: blr             x2
    // 0x68acd0: add             SP, SP, #0x18
    // 0x68acd4: ldr             x3, [fp, #0x20]
    // 0x68acd8: LoadField: r1 = r3->field_73
    //     0x68acd8: ldur            w1, [x3, #0x73]
    // 0x68acdc: DecompressPointer r1
    //     0x68acdc: add             x1, x1, HEAP, lsl #32
    // 0x68ace0: LoadField: r2 = r1->field_7
    //     0x68ace0: ldur            x2, [x1, #7]
    // 0x68ace4: cmp             x2, #0
    // 0x68ace8: r16 = true
    //     0x68ace8: add             x16, NULL, #0x20  ; true
    // 0x68acec: r17 = false
    //     0x68acec: add             x17, NULL, #0x30  ; false
    // 0x68acf0: csel            x4, x16, x17, le
    // 0x68acf4: tbnz            w4, #4, #0x68ad04
    // 0x68acf8: LoadField: d0 = r0->field_7
    //     0x68acf8: ldur            d0, [x0, #7]
    // 0x68acfc: mov             v3.16b, v0.16b
    // 0x68ad00: b               #0x68ad0c
    // 0x68ad04: LoadField: d0 = r0->field_f
    //     0x68ad04: ldur            d0, [x0, #0xf]
    // 0x68ad08: mov             v3.16b, v0.16b
    // 0x68ad0c: ldur            d2, [fp, #-0x68]
    // 0x68ad10: ldur            d1, [fp, #-0x70]
    // 0x68ad14: ldur            d0, [fp, #-0x90]
    // 0x68ad18: fadd            d4, d2, d3
    // 0x68ad1c: fadd            d2, d1, d0
    // 0x68ad20: tbnz            w4, #4, #0x68ad30
    // 0x68ad24: LoadField: d0 = r0->field_f
    //     0x68ad24: ldur            d0, [x0, #0xf]
    // 0x68ad28: mov             v1.16b, v0.16b
    // 0x68ad2c: b               #0x68ad38
    // 0x68ad30: LoadField: d0 = r0->field_7
    //     0x68ad30: ldur            d0, [x0, #7]
    // 0x68ad34: mov             v1.16b, v0.16b
    // 0x68ad38: ldur            d0, [fp, #-0x60]
    // 0x68ad3c: fcmp            d0, d1
    // 0x68ad40: b.vs            #0x68ad50
    // 0x68ad44: b.le            #0x68ad50
    // 0x68ad48: d3 = 0.000000
    //     0x68ad48: eor             v3.16b, v3.16b, v3.16b
    // 0x68ad4c: b               #0x68ad90
    // 0x68ad50: fcmp            d0, d1
    // 0x68ad54: b.vs            #0x68ad68
    // 0x68ad58: b.ge            #0x68ad68
    // 0x68ad5c: mov             v0.16b, v1.16b
    // 0x68ad60: d3 = 0.000000
    //     0x68ad60: eor             v3.16b, v3.16b, v3.16b
    // 0x68ad64: b               #0x68ad90
    // 0x68ad68: d3 = 0.000000
    //     0x68ad68: eor             v3.16b, v3.16b, v3.16b
    // 0x68ad6c: fcmp            d0, d3
    // 0x68ad70: b.vs            #0x68ad84
    // 0x68ad74: b.ne            #0x68ad84
    // 0x68ad78: fadd            d7, d0, d1
    // 0x68ad7c: mov             v0.16b, v7.16b
    // 0x68ad80: b               #0x68ad90
    // 0x68ad84: fcmp            d1, d1
    // 0x68ad88: b.vc            #0x68ad90
    // 0x68ad8c: mov             v0.16b, v1.16b
    // 0x68ad90: mov             v7.16b, v0.16b
    // 0x68ad94: mov             v6.16b, v4.16b
    // 0x68ad98: mov             v5.16b, v2.16b
    // 0x68ad9c: mov             x6, x1
    // 0x68ada0: b               #0x68adcc
    // 0x68ada4: ldr             x3, [fp, #0x20]
    // 0x68ada8: ldur            d0, [fp, #-0x60]
    // 0x68adac: ldur            d2, [fp, #-0x68]
    // 0x68adb0: ldur            d1, [fp, #-0x70]
    // 0x68adb4: ldur            x1, [fp, #-0x28]
    // 0x68adb8: d3 = 0.000000
    //     0x68adb8: eor             v3.16b, v3.16b, v3.16b
    // 0x68adbc: mov             v7.16b, v0.16b
    // 0x68adc0: mov             v6.16b, v2.16b
    // 0x68adc4: mov             v5.16b, v1.16b
    // 0x68adc8: mov             x6, x1
    // 0x68adcc: ldur            x0, [fp, #-0x18]
    // 0x68add0: stur            x6, [fp, #-0x28]
    // 0x68add4: stur            d7, [fp, #-0x70]
    // 0x68add8: stur            d6, [fp, #-0x88]
    // 0x68addc: stur            d5, [fp, #-0x90]
    // 0x68ade0: LoadField: r4 = r0->field_17
    //     0x68ade0: ldur            w4, [x0, #0x17]
    // 0x68ade4: DecompressPointer r4
    //     0x68ade4: add             x4, x4, HEAP, lsl #32
    // 0x68ade8: stur            x4, [fp, #-8]
    // 0x68adec: cmp             w4, NULL
    // 0x68adf0: b.eq            #0x68aeec
    // 0x68adf4: mov             x0, x4
    // 0x68adf8: r2 = Null
    //     0x68adf8: mov             x2, NULL
    // 0x68adfc: r1 = Null
    //     0x68adfc: mov             x1, NULL
    // 0x68ae00: r4 = LoadClassIdInstr(r0)
    //     0x68ae00: ldur            x4, [x0, #-1]
    //     0x68ae04: ubfx            x4, x4, #0xc, #0x14
    // 0x68ae08: cmp             x4, #0x809
    // 0x68ae0c: b.eq            #0x68ae24
    // 0x68ae10: r8 = FlexParentData<RenderBox>
    //     0x68ae10: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x68ae14: ldr             x8, [x8, #0x248]
    // 0x68ae18: r3 = Null
    //     0x68ae18: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d2f0] Null
    //     0x68ae1c: ldr             x3, [x3, #0x2f0]
    // 0x68ae20: r0 = DefaultTypeTest()
    //     0x68ae20: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x68ae24: ldur            x0, [fp, #-8]
    // 0x68ae28: LoadField: r7 = r0->field_13
    //     0x68ae28: ldur            w7, [x0, #0x13]
    // 0x68ae2c: DecompressPointer r7
    //     0x68ae2c: add             x7, x7, HEAP, lsl #32
    // 0x68ae30: ldur            d7, [fp, #-0x70]
    // 0x68ae34: ldur            d6, [fp, #-0x88]
    // 0x68ae38: ldur            d5, [fp, #-0x90]
    // 0x68ae3c: ldur            x6, [fp, #-0x28]
    // 0x68ae40: ldr             x4, [fp, #0x20]
    // 0x68ae44: ldur            x5, [fp, #-0x30]
    // 0x68ae48: ldur            d4, [fp, #-0x78]
    // 0x68ae4c: ldur            d2, [fp, #-0x80]
    // 0x68ae50: d3 = 0.000000
    //     0x68ae50: eor             v3.16b, v3.16b, v3.16b
    // 0x68ae54: b               #0x68aa38
    // 0x68ae58: mov             v0.16b, v7.16b
    // 0x68ae5c: mov             v2.16b, v6.16b
    // 0x68ae60: mov             v1.16b, v0.16b
    // 0x68ae64: mov             v0.16b, v2.16b
    // 0x68ae68: ldur            x0, [fp, #-0x30]
    // 0x68ae6c: stur            d1, [fp, #-0x40]
    // 0x68ae70: stur            d0, [fp, #-0x48]
    // 0x68ae74: tbnz            w0, #4, #0x68ae9c
    // 0x68ae78: ldr             x0, [fp, #0x20]
    // 0x68ae7c: LoadField: r1 = r0->field_7b
    //     0x68ae7c: ldur            w1, [x0, #0x7b]
    // 0x68ae80: DecompressPointer r1
    //     0x68ae80: add             x1, x1, HEAP, lsl #32
    // 0x68ae84: r16 = Instance_MainAxisSize
    //     0x68ae84: add             x16, PP, #0xe, lsl #12  ; [pp+0xeef8] Obj!MainAxisSize@b64b51
    //     0x68ae88: ldr             x16, [x16, #0xef8]
    // 0x68ae8c: cmp             w1, w16
    // 0x68ae90: b.ne            #0x68ae9c
    // 0x68ae94: ldur            d2, [fp, #-0x58]
    // 0x68ae98: b               #0x68aea0
    // 0x68ae9c: mov             v2.16b, v0.16b
    // 0x68aea0: stur            d2, [fp, #-0x38]
    // 0x68aea4: r0 = _LayoutSizes()
    //     0x68aea4: bl              #0x68aef0  ; Allocate_LayoutSizesStub -> _LayoutSizes (size=0x20)
    // 0x68aea8: ldur            d0, [fp, #-0x38]
    // 0x68aeac: StoreField: r0->field_7 = d0
    //     0x68aeac: stur            d0, [x0, #7]
    // 0x68aeb0: ldur            d0, [fp, #-0x40]
    // 0x68aeb4: StoreField: r0->field_f = d0
    //     0x68aeb4: stur            d0, [x0, #0xf]
    // 0x68aeb8: ldur            d0, [fp, #-0x48]
    // 0x68aebc: StoreField: r0->field_17 = d0
    //     0x68aebc: stur            d0, [x0, #0x17]
    // 0x68aec0: LeaveFrame
    //     0x68aec0: mov             SP, fp
    //     0x68aec4: ldp             fp, lr, [SP], #0x10
    // 0x68aec8: ret
    //     0x68aec8: ret             
    // 0x68aecc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68aecc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68aed0: b               #0x68a5ec
    // 0x68aed4: r0 = StackOverflowSharedWithFPURegs()
    //     0x68aed4: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x68aed8: b               #0x68a69c
    // 0x68aedc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68aedc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x68aee0: r0 = StackOverflowSharedWithFPURegs()
    //     0x68aee0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x68aee4: b               #0x68aa64
    // 0x68aee8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68aee8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x68aeec: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68aeec: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  set _ textBaseline=(/* No info */) {
    // ** addr: 0x6ddb80, size: 0x70
    // 0x6ddb80: EnterFrame
    //     0x6ddb80: stp             fp, lr, [SP, #-0x10]!
    //     0x6ddb84: mov             fp, SP
    // 0x6ddb88: CheckStackOverflow
    //     0x6ddb88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ddb8c: cmp             SP, x16
    //     0x6ddb90: b.ls            #0x6ddbe8
    // 0x6ddb94: ldr             x1, [fp, #0x18]
    // 0x6ddb98: LoadField: r0 = r1->field_8b
    //     0x6ddb98: ldur            w0, [x1, #0x8b]
    // 0x6ddb9c: DecompressPointer r0
    //     0x6ddb9c: add             x0, x0, HEAP, lsl #32
    // 0x6ddba0: ldr             x2, [fp, #0x10]
    // 0x6ddba4: cmp             w0, w2
    // 0x6ddba8: b.eq            #0x6ddbd8
    // 0x6ddbac: mov             x0, x2
    // 0x6ddbb0: StoreField: r1->field_8b = r0
    //     0x6ddbb0: stur            w0, [x1, #0x8b]
    //     0x6ddbb4: ldurb           w16, [x1, #-1]
    //     0x6ddbb8: ldurb           w17, [x0, #-1]
    //     0x6ddbbc: and             x16, x17, x16, lsr #2
    //     0x6ddbc0: tst             x16, HEAP, lsr #32
    //     0x6ddbc4: b.eq            #0x6ddbcc
    //     0x6ddbc8: bl              #0xd6826c
    // 0x6ddbcc: SaveReg r1
    //     0x6ddbcc: str             x1, [SP, #-8]!
    // 0x6ddbd0: r0 = markNeedsLayout()
    //     0x6ddbd0: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6ddbd4: add             SP, SP, #8
    // 0x6ddbd8: r0 = Null
    //     0x6ddbd8: mov             x0, NULL
    // 0x6ddbdc: LeaveFrame
    //     0x6ddbdc: mov             SP, fp
    //     0x6ddbe0: ldp             fp, lr, [SP], #0x10
    // 0x6ddbe4: ret
    //     0x6ddbe4: ret             
    // 0x6ddbe8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ddbe8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ddbec: b               #0x6ddb94
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0x6ddbf0, size: 0x70
    // 0x6ddbf0: EnterFrame
    //     0x6ddbf0: stp             fp, lr, [SP, #-0x10]!
    //     0x6ddbf4: mov             fp, SP
    // 0x6ddbf8: CheckStackOverflow
    //     0x6ddbf8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ddbfc: cmp             SP, x16
    //     0x6ddc00: b.ls            #0x6ddc58
    // 0x6ddc04: ldr             x1, [fp, #0x18]
    // 0x6ddc08: LoadField: r0 = r1->field_83
    //     0x6ddc08: ldur            w0, [x1, #0x83]
    // 0x6ddc0c: DecompressPointer r0
    //     0x6ddc0c: add             x0, x0, HEAP, lsl #32
    // 0x6ddc10: ldr             x2, [fp, #0x10]
    // 0x6ddc14: cmp             w0, w2
    // 0x6ddc18: b.eq            #0x6ddc48
    // 0x6ddc1c: mov             x0, x2
    // 0x6ddc20: StoreField: r1->field_83 = r0
    //     0x6ddc20: stur            w0, [x1, #0x83]
    //     0x6ddc24: ldurb           w16, [x1, #-1]
    //     0x6ddc28: ldurb           w17, [x0, #-1]
    //     0x6ddc2c: and             x16, x17, x16, lsr #2
    //     0x6ddc30: tst             x16, HEAP, lsr #32
    //     0x6ddc34: b.eq            #0x6ddc3c
    //     0x6ddc38: bl              #0xd6826c
    // 0x6ddc3c: SaveReg r1
    //     0x6ddc3c: str             x1, [SP, #-8]!
    // 0x6ddc40: r0 = markNeedsLayout()
    //     0x6ddc40: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6ddc44: add             SP, SP, #8
    // 0x6ddc48: r0 = Null
    //     0x6ddc48: mov             x0, NULL
    // 0x6ddc4c: LeaveFrame
    //     0x6ddc4c: mov             SP, fp
    //     0x6ddc50: ldp             fp, lr, [SP], #0x10
    // 0x6ddc54: ret
    //     0x6ddc54: ret             
    // 0x6ddc58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ddc58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ddc5c: b               #0x6ddc04
  }
  set _ crossAxisAlignment=(/* No info */) {
    // ** addr: 0x6ddd00, size: 0x70
    // 0x6ddd00: EnterFrame
    //     0x6ddd00: stp             fp, lr, [SP, #-0x10]!
    //     0x6ddd04: mov             fp, SP
    // 0x6ddd08: CheckStackOverflow
    //     0x6ddd08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ddd0c: cmp             SP, x16
    //     0x6ddd10: b.ls            #0x6ddd68
    // 0x6ddd14: ldr             x1, [fp, #0x18]
    // 0x6ddd18: LoadField: r0 = r1->field_7f
    //     0x6ddd18: ldur            w0, [x1, #0x7f]
    // 0x6ddd1c: DecompressPointer r0
    //     0x6ddd1c: add             x0, x0, HEAP, lsl #32
    // 0x6ddd20: ldr             x2, [fp, #0x10]
    // 0x6ddd24: cmp             w0, w2
    // 0x6ddd28: b.eq            #0x6ddd58
    // 0x6ddd2c: mov             x0, x2
    // 0x6ddd30: StoreField: r1->field_7f = r0
    //     0x6ddd30: stur            w0, [x1, #0x7f]
    //     0x6ddd34: ldurb           w16, [x1, #-1]
    //     0x6ddd38: ldurb           w17, [x0, #-1]
    //     0x6ddd3c: and             x16, x17, x16, lsr #2
    //     0x6ddd40: tst             x16, HEAP, lsr #32
    //     0x6ddd44: b.eq            #0x6ddd4c
    //     0x6ddd48: bl              #0xd6826c
    // 0x6ddd4c: SaveReg r1
    //     0x6ddd4c: str             x1, [SP, #-8]!
    // 0x6ddd50: r0 = markNeedsLayout()
    //     0x6ddd50: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6ddd54: add             SP, SP, #8
    // 0x6ddd58: r0 = Null
    //     0x6ddd58: mov             x0, NULL
    // 0x6ddd5c: LeaveFrame
    //     0x6ddd5c: mov             SP, fp
    //     0x6ddd60: ldp             fp, lr, [SP], #0x10
    // 0x6ddd64: ret
    //     0x6ddd64: ret             
    // 0x6ddd68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ddd68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ddd6c: b               #0x6ddd14
  }
  set _ mainAxisSize=(/* No info */) {
    // ** addr: 0x6ddd70, size: 0x70
    // 0x6ddd70: EnterFrame
    //     0x6ddd70: stp             fp, lr, [SP, #-0x10]!
    //     0x6ddd74: mov             fp, SP
    // 0x6ddd78: CheckStackOverflow
    //     0x6ddd78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ddd7c: cmp             SP, x16
    //     0x6ddd80: b.ls            #0x6dddd8
    // 0x6ddd84: ldr             x1, [fp, #0x18]
    // 0x6ddd88: LoadField: r0 = r1->field_7b
    //     0x6ddd88: ldur            w0, [x1, #0x7b]
    // 0x6ddd8c: DecompressPointer r0
    //     0x6ddd8c: add             x0, x0, HEAP, lsl #32
    // 0x6ddd90: ldr             x2, [fp, #0x10]
    // 0x6ddd94: cmp             w0, w2
    // 0x6ddd98: b.eq            #0x6dddc8
    // 0x6ddd9c: mov             x0, x2
    // 0x6ddda0: StoreField: r1->field_7b = r0
    //     0x6ddda0: stur            w0, [x1, #0x7b]
    //     0x6ddda4: ldurb           w16, [x1, #-1]
    //     0x6ddda8: ldurb           w17, [x0, #-1]
    //     0x6dddac: and             x16, x17, x16, lsr #2
    //     0x6dddb0: tst             x16, HEAP, lsr #32
    //     0x6dddb4: b.eq            #0x6dddbc
    //     0x6dddb8: bl              #0xd6826c
    // 0x6dddbc: SaveReg r1
    //     0x6dddbc: str             x1, [SP, #-8]!
    // 0x6dddc0: r0 = markNeedsLayout()
    //     0x6dddc0: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6dddc4: add             SP, SP, #8
    // 0x6dddc8: r0 = Null
    //     0x6dddc8: mov             x0, NULL
    // 0x6dddcc: LeaveFrame
    //     0x6dddcc: mov             SP, fp
    //     0x6dddd0: ldp             fp, lr, [SP], #0x10
    // 0x6dddd4: ret
    //     0x6dddd4: ret             
    // 0x6dddd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6dddd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ddddc: b               #0x6ddd84
  }
  set _ mainAxisAlignment=(/* No info */) {
    // ** addr: 0x6ddde0, size: 0x70
    // 0x6ddde0: EnterFrame
    //     0x6ddde0: stp             fp, lr, [SP, #-0x10]!
    //     0x6ddde4: mov             fp, SP
    // 0x6ddde8: CheckStackOverflow
    //     0x6ddde8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6dddec: cmp             SP, x16
    //     0x6dddf0: b.ls            #0x6dde48
    // 0x6dddf4: ldr             x1, [fp, #0x18]
    // 0x6dddf8: LoadField: r0 = r1->field_77
    //     0x6dddf8: ldur            w0, [x1, #0x77]
    // 0x6dddfc: DecompressPointer r0
    //     0x6dddfc: add             x0, x0, HEAP, lsl #32
    // 0x6dde00: ldr             x2, [fp, #0x10]
    // 0x6dde04: cmp             w0, w2
    // 0x6dde08: b.eq            #0x6dde38
    // 0x6dde0c: mov             x0, x2
    // 0x6dde10: StoreField: r1->field_77 = r0
    //     0x6dde10: stur            w0, [x1, #0x77]
    //     0x6dde14: ldurb           w16, [x1, #-1]
    //     0x6dde18: ldurb           w17, [x0, #-1]
    //     0x6dde1c: and             x16, x17, x16, lsr #2
    //     0x6dde20: tst             x16, HEAP, lsr #32
    //     0x6dde24: b.eq            #0x6dde2c
    //     0x6dde28: bl              #0xd6826c
    // 0x6dde2c: SaveReg r1
    //     0x6dde2c: str             x1, [SP, #-8]!
    // 0x6dde30: r0 = markNeedsLayout()
    //     0x6dde30: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6dde34: add             SP, SP, #8
    // 0x6dde38: r0 = Null
    //     0x6dde38: mov             x0, NULL
    // 0x6dde3c: LeaveFrame
    //     0x6dde3c: mov             SP, fp
    //     0x6dde40: ldp             fp, lr, [SP], #0x10
    // 0x6dde44: ret
    //     0x6dde44: ret             
    // 0x6dde48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6dde48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6dde4c: b               #0x6dddf4
  }
  set _ direction=(/* No info */) {
    // ** addr: 0x6dde50, size: 0x70
    // 0x6dde50: EnterFrame
    //     0x6dde50: stp             fp, lr, [SP, #-0x10]!
    //     0x6dde54: mov             fp, SP
    // 0x6dde58: CheckStackOverflow
    //     0x6dde58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6dde5c: cmp             SP, x16
    //     0x6dde60: b.ls            #0x6ddeb8
    // 0x6dde64: ldr             x1, [fp, #0x18]
    // 0x6dde68: LoadField: r0 = r1->field_73
    //     0x6dde68: ldur            w0, [x1, #0x73]
    // 0x6dde6c: DecompressPointer r0
    //     0x6dde6c: add             x0, x0, HEAP, lsl #32
    // 0x6dde70: ldr             x2, [fp, #0x10]
    // 0x6dde74: cmp             w0, w2
    // 0x6dde78: b.eq            #0x6ddea8
    // 0x6dde7c: mov             x0, x2
    // 0x6dde80: StoreField: r1->field_73 = r0
    //     0x6dde80: stur            w0, [x1, #0x73]
    //     0x6dde84: ldurb           w16, [x1, #-1]
    //     0x6dde88: ldurb           w17, [x0, #-1]
    //     0x6dde8c: and             x16, x17, x16, lsr #2
    //     0x6dde90: tst             x16, HEAP, lsr #32
    //     0x6dde94: b.eq            #0x6dde9c
    //     0x6dde98: bl              #0xd6826c
    // 0x6dde9c: SaveReg r1
    //     0x6dde9c: str             x1, [SP, #-8]!
    // 0x6ddea0: r0 = markNeedsLayout()
    //     0x6ddea0: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6ddea4: add             SP, SP, #8
    // 0x6ddea8: r0 = Null
    //     0x6ddea8: mov             x0, NULL
    // 0x6ddeac: LeaveFrame
    //     0x6ddeac: mov             SP, fp
    //     0x6ddeb0: ldp             fp, lr, [SP], #0x10
    // 0x6ddeb4: ret
    //     0x6ddeb4: ret             
    // 0x6ddeb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ddeb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ddebc: b               #0x6dde64
  }
  _ RenderFlex(/* No info */) {
    // ** addr: 0x6f297c, size: 0x1dc
    // 0x6f297c: EnterFrame
    //     0x6f297c: stp             fp, lr, [SP, #-0x10]!
    //     0x6f2980: mov             fp, SP
    // 0x6f2984: AllocStack(0x38)
    //     0x6f2984: sub             SP, SP, #0x38
    // 0x6f2988: SetupParameters(RenderFlex this /* r3, fp-0x38 */, dynamic _ /* r4, fp-0x30 */, dynamic _ /* r5, fp-0x28 */, dynamic _ /* r6, fp-0x20 */, dynamic _ /* r7, fp-0x18 */, dynamic _ /* r8, fp-0x10 */, {dynamic textBaseline = Null /* r0, fp-0x8 */})
    //     0x6f2988: mov             x0, x4
    //     0x6f298c: ldur            w1, [x0, #0x13]
    //     0x6f2990: add             x1, x1, HEAP, lsl #32
    //     0x6f2994: sub             x2, x1, #0xc
    //     0x6f2998: add             x3, fp, w2, sxtw #2
    //     0x6f299c: ldr             x3, [x3, #0x38]
    //     0x6f29a0: stur            x3, [fp, #-0x38]
    //     0x6f29a4: add             x4, fp, w2, sxtw #2
    //     0x6f29a8: ldr             x4, [x4, #0x30]
    //     0x6f29ac: stur            x4, [fp, #-0x30]
    //     0x6f29b0: add             x5, fp, w2, sxtw #2
    //     0x6f29b4: ldr             x5, [x5, #0x28]
    //     0x6f29b8: stur            x5, [fp, #-0x28]
    //     0x6f29bc: add             x6, fp, w2, sxtw #2
    //     0x6f29c0: ldr             x6, [x6, #0x20]
    //     0x6f29c4: stur            x6, [fp, #-0x20]
    //     0x6f29c8: add             x7, fp, w2, sxtw #2
    //     0x6f29cc: ldr             x7, [x7, #0x18]
    //     0x6f29d0: stur            x7, [fp, #-0x18]
    //     0x6f29d4: add             x8, fp, w2, sxtw #2
    //     0x6f29d8: ldr             x8, [x8, #0x10]
    //     0x6f29dc: stur            x8, [fp, #-0x10]
    //     0x6f29e0: ldur            w2, [x0, #0x1f]
    //     0x6f29e4: add             x2, x2, HEAP, lsl #32
    //     0x6f29e8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe058] "textBaseline"
    //     0x6f29ec: ldr             x16, [x16, #0x58]
    //     0x6f29f0: cmp             w2, w16
    //     0x6f29f4: b.ne            #0x6f2a14
    //     0x6f29f8: ldur            w2, [x0, #0x23]
    //     0x6f29fc: add             x2, x2, HEAP, lsl #32
    //     0x6f2a00: sub             w0, w1, w2
    //     0x6f2a04: add             x1, fp, w0, sxtw #2
    //     0x6f2a08: ldr             x1, [x1, #8]
    //     0x6f2a0c: mov             x0, x1
    //     0x6f2a10: b               #0x6f2a18
    //     0x6f2a14: mov             x0, NULL
    //     0x6f2a18: eor             v0.16b, v0.16b, v0.16b
    //     0x6f2a1c: stur            x0, [fp, #-8]
    // 0x6f2a18: d0 = 0.000000
    // 0x6f2a20: CheckStackOverflow
    //     0x6f2a20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f2a24: cmp             SP, x16
    //     0x6f2a28: b.ls            #0x6f2b50
    // 0x6f2a2c: StoreField: r3->field_8f = d0
    //     0x6f2a2c: stur            d0, [x3, #0x8f]
    // 0x6f2a30: r1 = <ClipRectLayer>
    //     0x6f2a30: add             x1, PP, #0x15, lsl #12  ; [pp+0x15388] TypeArguments: <ClipRectLayer>
    //     0x6f2a34: ldr             x1, [x1, #0x388]
    // 0x6f2a38: r0 = LayerHandle()
    //     0x6f2a38: bl              #0x5bbf28  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x6f2a3c: ldur            x1, [fp, #-0x38]
    // 0x6f2a40: StoreField: r1->field_9b = r0
    //     0x6f2a40: stur            w0, [x1, #0x9b]
    //     0x6f2a44: ldurb           w16, [x1, #-1]
    //     0x6f2a48: ldurb           w17, [x0, #-1]
    //     0x6f2a4c: and             x16, x17, x16, lsr #2
    //     0x6f2a50: tst             x16, HEAP, lsr #32
    //     0x6f2a54: b.eq            #0x6f2a5c
    //     0x6f2a58: bl              #0xd6826c
    // 0x6f2a5c: ldur            x0, [fp, #-0x28]
    // 0x6f2a60: StoreField: r1->field_73 = r0
    //     0x6f2a60: stur            w0, [x1, #0x73]
    //     0x6f2a64: ldurb           w16, [x1, #-1]
    //     0x6f2a68: ldurb           w17, [x0, #-1]
    //     0x6f2a6c: and             x16, x17, x16, lsr #2
    //     0x6f2a70: tst             x16, HEAP, lsr #32
    //     0x6f2a74: b.eq            #0x6f2a7c
    //     0x6f2a78: bl              #0xd6826c
    // 0x6f2a7c: ldur            x0, [fp, #-0x20]
    // 0x6f2a80: StoreField: r1->field_77 = r0
    //     0x6f2a80: stur            w0, [x1, #0x77]
    //     0x6f2a84: ldurb           w16, [x1, #-1]
    //     0x6f2a88: ldurb           w17, [x0, #-1]
    //     0x6f2a8c: and             x16, x17, x16, lsr #2
    //     0x6f2a90: tst             x16, HEAP, lsr #32
    //     0x6f2a94: b.eq            #0x6f2a9c
    //     0x6f2a98: bl              #0xd6826c
    // 0x6f2a9c: ldur            x0, [fp, #-0x18]
    // 0x6f2aa0: StoreField: r1->field_7b = r0
    //     0x6f2aa0: stur            w0, [x1, #0x7b]
    //     0x6f2aa4: ldurb           w16, [x1, #-1]
    //     0x6f2aa8: ldurb           w17, [x0, #-1]
    //     0x6f2aac: and             x16, x17, x16, lsr #2
    //     0x6f2ab0: tst             x16, HEAP, lsr #32
    //     0x6f2ab4: b.eq            #0x6f2abc
    //     0x6f2ab8: bl              #0xd6826c
    // 0x6f2abc: ldur            x0, [fp, #-0x30]
    // 0x6f2ac0: StoreField: r1->field_7f = r0
    //     0x6f2ac0: stur            w0, [x1, #0x7f]
    //     0x6f2ac4: ldurb           w16, [x1, #-1]
    //     0x6f2ac8: ldurb           w17, [x0, #-1]
    //     0x6f2acc: and             x16, x17, x16, lsr #2
    //     0x6f2ad0: tst             x16, HEAP, lsr #32
    //     0x6f2ad4: b.eq            #0x6f2adc
    //     0x6f2ad8: bl              #0xd6826c
    // 0x6f2adc: ldur            x0, [fp, #-0x10]
    // 0x6f2ae0: StoreField: r1->field_83 = r0
    //     0x6f2ae0: stur            w0, [x1, #0x83]
    //     0x6f2ae4: ldurb           w16, [x1, #-1]
    //     0x6f2ae8: ldurb           w17, [x0, #-1]
    //     0x6f2aec: and             x16, x17, x16, lsr #2
    //     0x6f2af0: tst             x16, HEAP, lsr #32
    //     0x6f2af4: b.eq            #0x6f2afc
    //     0x6f2af8: bl              #0xd6826c
    // 0x6f2afc: r0 = Instance_VerticalDirection
    //     0x6f2afc: add             x0, PP, #0xe, lsl #12  ; [pp+0xef18] Obj!VerticalDirection@b64fb1
    //     0x6f2b00: ldr             x0, [x0, #0xf18]
    // 0x6f2b04: StoreField: r1->field_87 = r0
    //     0x6f2b04: stur            w0, [x1, #0x87]
    // 0x6f2b08: ldur            x0, [fp, #-8]
    // 0x6f2b0c: StoreField: r1->field_8b = r0
    //     0x6f2b0c: stur            w0, [x1, #0x8b]
    //     0x6f2b10: ldurb           w16, [x1, #-1]
    //     0x6f2b14: ldurb           w17, [x0, #-1]
    //     0x6f2b18: and             x16, x17, x16, lsr #2
    //     0x6f2b1c: tst             x16, HEAP, lsr #32
    //     0x6f2b20: b.eq            #0x6f2b28
    //     0x6f2b24: bl              #0xd6826c
    // 0x6f2b28: r0 = Instance_Clip
    //     0x6f2b28: add             x0, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x6f2b2c: ldr             x0, [x0, #0xb38]
    // 0x6f2b30: StoreField: r1->field_97 = r0
    //     0x6f2b30: stur            w0, [x1, #0x97]
    // 0x6f2b34: SaveReg r1
    //     0x6f2b34: str             x1, [SP, #-8]!
    // 0x6f2b38: r0 = _RenderFlex&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin&DebugOverflowIndicatorMixin()
    //     0x6f2b38: bl              #0x6f2b58  ; [package:flutter/src/rendering/flex.dart] _RenderFlex&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin&DebugOverflowIndicatorMixin::_RenderFlex&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin&DebugOverflowIndicatorMixin
    // 0x6f2b3c: add             SP, SP, #8
    // 0x6f2b40: r0 = Null
    //     0x6f2b40: mov             x0, NULL
    // 0x6f2b44: LeaveFrame
    //     0x6f2b44: mov             SP, fp
    //     0x6f2b48: ldp             fp, lr, [SP], #0x10
    // 0x6f2b4c: ret
    //     0x6f2b4c: ret             
    // 0x6f2b50: r0 = StackOverflowSharedWithFPURegs()
    //     0x6f2b50: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x6f2b54: b               #0x6f2a2c
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5cd34, size: 0x100
    // 0xa5cd34: EnterFrame
    //     0xa5cd34: stp             fp, lr, [SP, #-0x10]!
    //     0xa5cd38: mov             fp, SP
    // 0xa5cd3c: AllocStack(0x10)
    //     0xa5cd3c: sub             SP, SP, #0x10
    // 0xa5cd40: CheckStackOverflow
    //     0xa5cd40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5cd44: cmp             SP, x16
    //     0xa5cd48: b.ls            #0xa5ce2c
    // 0xa5cd4c: ldr             x16, [fp, #0x18]
    // 0xa5cd50: SaveReg r16
    //     0xa5cd50: str             x16, [SP, #-8]!
    // 0xa5cd54: r0 = _canComputeIntrinsics()
    //     0xa5cd54: bl              #0xa5ce34  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_canComputeIntrinsics
    // 0xa5cd58: add             SP, SP, #8
    // 0xa5cd5c: tbz             w0, #4, #0xa5cd70
    // 0xa5cd60: r0 = Instance_Size
    //     0xa5cd60: ldr             x0, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0xa5cd64: LeaveFrame
    //     0xa5cd64: mov             SP, fp
    //     0xa5cd68: ldp             fp, lr, [SP], #0x10
    // 0xa5cd6c: ret
    //     0xa5cd6c: ret             
    // 0xa5cd70: ldr             x0, [fp, #0x18]
    // 0xa5cd74: ldr             x16, [fp, #0x10]
    // 0xa5cd78: stp             x16, x0, [SP, #-0x10]!
    // 0xa5cd7c: r16 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xa5cd7c: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cf88] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7fe6e1e33c20)
    //     0xa5cd80: ldr             x16, [x16, #0xf88]
    // 0xa5cd84: SaveReg r16
    //     0xa5cd84: str             x16, [SP, #-8]!
    // 0xa5cd88: r0 = _computeSizes()
    //     0xa5cd88: bl              #0x68a5d4  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_computeSizes
    // 0xa5cd8c: add             SP, SP, #0x18
    // 0xa5cd90: mov             x1, x0
    // 0xa5cd94: ldr             x0, [fp, #0x18]
    // 0xa5cd98: LoadField: r2 = r0->field_73
    //     0xa5cd98: ldur            w2, [x0, #0x73]
    // 0xa5cd9c: DecompressPointer r2
    //     0xa5cd9c: add             x2, x2, HEAP, lsl #32
    // 0xa5cda0: LoadField: r0 = r2->field_7
    //     0xa5cda0: ldur            x0, [x2, #7]
    // 0xa5cda4: cmp             x0, #0
    // 0xa5cda8: b.gt            #0xa5cdec
    // 0xa5cdac: LoadField: d0 = r1->field_7
    //     0xa5cdac: ldur            d0, [x1, #7]
    // 0xa5cdb0: stur            d0, [fp, #-0x10]
    // 0xa5cdb4: LoadField: d1 = r1->field_f
    //     0xa5cdb4: ldur            d1, [x1, #0xf]
    // 0xa5cdb8: stur            d1, [fp, #-8]
    // 0xa5cdbc: r0 = Size()
    //     0xa5cdbc: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xa5cdc0: ldur            d0, [fp, #-0x10]
    // 0xa5cdc4: StoreField: r0->field_7 = d0
    //     0xa5cdc4: stur            d0, [x0, #7]
    // 0xa5cdc8: ldur            d0, [fp, #-8]
    // 0xa5cdcc: StoreField: r0->field_f = d0
    //     0xa5cdcc: stur            d0, [x0, #0xf]
    // 0xa5cdd0: ldr             x16, [fp, #0x10]
    // 0xa5cdd4: stp             x0, x16, [SP, #-0x10]!
    // 0xa5cdd8: r0 = constrain()
    //     0xa5cdd8: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xa5cddc: add             SP, SP, #0x10
    // 0xa5cde0: LeaveFrame
    //     0xa5cde0: mov             SP, fp
    //     0xa5cde4: ldp             fp, lr, [SP], #0x10
    // 0xa5cde8: ret
    //     0xa5cde8: ret             
    // 0xa5cdec: LoadField: d0 = r1->field_f
    //     0xa5cdec: ldur            d0, [x1, #0xf]
    // 0xa5cdf0: stur            d0, [fp, #-0x10]
    // 0xa5cdf4: LoadField: d1 = r1->field_7
    //     0xa5cdf4: ldur            d1, [x1, #7]
    // 0xa5cdf8: stur            d1, [fp, #-8]
    // 0xa5cdfc: r0 = Size()
    //     0xa5cdfc: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xa5ce00: ldur            d0, [fp, #-0x10]
    // 0xa5ce04: StoreField: r0->field_7 = d0
    //     0xa5ce04: stur            d0, [x0, #7]
    // 0xa5ce08: ldur            d0, [fp, #-8]
    // 0xa5ce0c: StoreField: r0->field_f = d0
    //     0xa5ce0c: stur            d0, [x0, #0xf]
    // 0xa5ce10: ldr             x16, [fp, #0x10]
    // 0xa5ce14: stp             x0, x16, [SP, #-0x10]!
    // 0xa5ce18: r0 = constrain()
    //     0xa5ce18: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xa5ce1c: add             SP, SP, #0x10
    // 0xa5ce20: LeaveFrame
    //     0xa5ce20: mov             SP, fp
    //     0xa5ce24: ldp             fp, lr, [SP], #0x10
    // 0xa5ce28: ret
    //     0xa5ce28: ret             
    // 0xa5ce2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5ce2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5ce30: b               #0xa5cd4c
  }
  get _ _canComputeIntrinsics(/* No info */) {
    // ** addr: 0xa5ce34, size: 0x28
    // 0xa5ce34: ldr             x1, [SP]
    // 0xa5ce38: LoadField: r2 = r1->field_7f
    //     0xa5ce38: ldur            w2, [x1, #0x7f]
    // 0xa5ce3c: DecompressPointer r2
    //     0xa5ce3c: add             x2, x2, HEAP, lsl #32
    // 0xa5ce40: r16 = Instance_CrossAxisAlignment
    //     0xa5ce40: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d280] Obj!CrossAxisAlignment@b649f1
    //     0xa5ce44: ldr             x16, [x16, #0x280]
    // 0xa5ce48: cmp             w2, w16
    // 0xa5ce4c: r16 = true
    //     0xa5ce4c: add             x16, NULL, #0x20  ; true
    // 0xa5ce50: r17 = false
    //     0xa5ce50: add             x17, NULL, #0x30  ; false
    // 0xa5ce54: csel            x0, x16, x17, ne
    // 0xa5ce58: ret
    //     0xa5ce58: ret             
  }
}

// class id: 5923, size: 0x14, field offset: 0x14
enum CrossAxisAlignment extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16d14, size: 0x5c
    // 0xb16d14: EnterFrame
    //     0xb16d14: stp             fp, lr, [SP, #-0x10]!
    //     0xb16d18: mov             fp, SP
    // 0xb16d1c: CheckStackOverflow
    //     0xb16d1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16d20: cmp             SP, x16
    //     0xb16d24: b.ls            #0xb16d68
    // 0xb16d28: r1 = Null
    //     0xb16d28: mov             x1, NULL
    // 0xb16d2c: r2 = 4
    //     0xb16d2c: mov             x2, #4
    // 0xb16d30: r0 = AllocateArray()
    //     0xb16d30: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16d34: r17 = "CrossAxisAlignment."
    //     0xb16d34: add             x17, PP, #0x15, lsl #12  ; [pp+0x15338] "CrossAxisAlignment."
    //     0xb16d38: ldr             x17, [x17, #0x338]
    // 0xb16d3c: StoreField: r0->field_f = r17
    //     0xb16d3c: stur            w17, [x0, #0xf]
    // 0xb16d40: ldr             x1, [fp, #0x10]
    // 0xb16d44: LoadField: r2 = r1->field_f
    //     0xb16d44: ldur            w2, [x1, #0xf]
    // 0xb16d48: DecompressPointer r2
    //     0xb16d48: add             x2, x2, HEAP, lsl #32
    // 0xb16d4c: StoreField: r0->field_13 = r2
    //     0xb16d4c: stur            w2, [x0, #0x13]
    // 0xb16d50: SaveReg r0
    //     0xb16d50: str             x0, [SP, #-8]!
    // 0xb16d54: r0 = _interpolate()
    //     0xb16d54: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16d58: add             SP, SP, #8
    // 0xb16d5c: LeaveFrame
    //     0xb16d5c: mov             SP, fp
    //     0xb16d60: ldp             fp, lr, [SP], #0x10
    // 0xb16d64: ret
    //     0xb16d64: ret             
    // 0xb16d68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16d68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16d6c: b               #0xb16d28
  }
}

// class id: 5924, size: 0x14, field offset: 0x14
enum MainAxisAlignment extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16cb8, size: 0x5c
    // 0xb16cb8: EnterFrame
    //     0xb16cb8: stp             fp, lr, [SP, #-0x10]!
    //     0xb16cbc: mov             fp, SP
    // 0xb16cc0: CheckStackOverflow
    //     0xb16cc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16cc4: cmp             SP, x16
    //     0xb16cc8: b.ls            #0xb16d0c
    // 0xb16ccc: r1 = Null
    //     0xb16ccc: mov             x1, NULL
    // 0xb16cd0: r2 = 4
    //     0xb16cd0: mov             x2, #4
    // 0xb16cd4: r0 = AllocateArray()
    //     0xb16cd4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16cd8: r17 = "MainAxisAlignment."
    //     0xb16cd8: add             x17, PP, #0x15, lsl #12  ; [pp+0x15330] "MainAxisAlignment."
    //     0xb16cdc: ldr             x17, [x17, #0x330]
    // 0xb16ce0: StoreField: r0->field_f = r17
    //     0xb16ce0: stur            w17, [x0, #0xf]
    // 0xb16ce4: ldr             x1, [fp, #0x10]
    // 0xb16ce8: LoadField: r2 = r1->field_f
    //     0xb16ce8: ldur            w2, [x1, #0xf]
    // 0xb16cec: DecompressPointer r2
    //     0xb16cec: add             x2, x2, HEAP, lsl #32
    // 0xb16cf0: StoreField: r0->field_13 = r2
    //     0xb16cf0: stur            w2, [x0, #0x13]
    // 0xb16cf4: SaveReg r0
    //     0xb16cf4: str             x0, [SP, #-8]!
    // 0xb16cf8: r0 = _interpolate()
    //     0xb16cf8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16cfc: add             SP, SP, #8
    // 0xb16d00: LeaveFrame
    //     0xb16d00: mov             SP, fp
    //     0xb16d04: ldp             fp, lr, [SP], #0x10
    // 0xb16d08: ret
    //     0xb16d08: ret             
    // 0xb16d0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16d0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16d10: b               #0xb16ccc
  }
}

// class id: 5925, size: 0x14, field offset: 0x14
enum MainAxisSize extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16c5c, size: 0x5c
    // 0xb16c5c: EnterFrame
    //     0xb16c5c: stp             fp, lr, [SP, #-0x10]!
    //     0xb16c60: mov             fp, SP
    // 0xb16c64: CheckStackOverflow
    //     0xb16c64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16c68: cmp             SP, x16
    //     0xb16c6c: b.ls            #0xb16cb0
    // 0xb16c70: r1 = Null
    //     0xb16c70: mov             x1, NULL
    // 0xb16c74: r2 = 4
    //     0xb16c74: mov             x2, #4
    // 0xb16c78: r0 = AllocateArray()
    //     0xb16c78: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16c7c: r17 = "MainAxisSize."
    //     0xb16c7c: add             x17, PP, #0x15, lsl #12  ; [pp+0x15328] "MainAxisSize."
    //     0xb16c80: ldr             x17, [x17, #0x328]
    // 0xb16c84: StoreField: r0->field_f = r17
    //     0xb16c84: stur            w17, [x0, #0xf]
    // 0xb16c88: ldr             x1, [fp, #0x10]
    // 0xb16c8c: LoadField: r2 = r1->field_f
    //     0xb16c8c: ldur            w2, [x1, #0xf]
    // 0xb16c90: DecompressPointer r2
    //     0xb16c90: add             x2, x2, HEAP, lsl #32
    // 0xb16c94: StoreField: r0->field_13 = r2
    //     0xb16c94: stur            w2, [x0, #0x13]
    // 0xb16c98: SaveReg r0
    //     0xb16c98: str             x0, [SP, #-8]!
    // 0xb16c9c: r0 = _interpolate()
    //     0xb16c9c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16ca0: add             SP, SP, #8
    // 0xb16ca4: LeaveFrame
    //     0xb16ca4: mov             SP, fp
    //     0xb16ca8: ldp             fp, lr, [SP], #0x10
    // 0xb16cac: ret
    //     0xb16cac: ret             
    // 0xb16cb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16cb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16cb4: b               #0xb16c70
  }
}

// class id: 5926, size: 0x14, field offset: 0x14
enum FlexFit extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16c00, size: 0x5c
    // 0xb16c00: EnterFrame
    //     0xb16c00: stp             fp, lr, [SP, #-0x10]!
    //     0xb16c04: mov             fp, SP
    // 0xb16c08: CheckStackOverflow
    //     0xb16c08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16c0c: cmp             SP, x16
    //     0xb16c10: b.ls            #0xb16c54
    // 0xb16c14: r1 = Null
    //     0xb16c14: mov             x1, NULL
    // 0xb16c18: r2 = 4
    //     0xb16c18: mov             x2, #4
    // 0xb16c1c: r0 = AllocateArray()
    //     0xb16c1c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16c20: r17 = "FlexFit."
    //     0xb16c20: add             x17, PP, #0x22, lsl #12  ; [pp+0x22720] "FlexFit."
    //     0xb16c24: ldr             x17, [x17, #0x720]
    // 0xb16c28: StoreField: r0->field_f = r17
    //     0xb16c28: stur            w17, [x0, #0xf]
    // 0xb16c2c: ldr             x1, [fp, #0x10]
    // 0xb16c30: LoadField: r2 = r1->field_f
    //     0xb16c30: ldur            w2, [x1, #0xf]
    // 0xb16c34: DecompressPointer r2
    //     0xb16c34: add             x2, x2, HEAP, lsl #32
    // 0xb16c38: StoreField: r0->field_13 = r2
    //     0xb16c38: stur            w2, [x0, #0x13]
    // 0xb16c3c: SaveReg r0
    //     0xb16c3c: str             x0, [SP, #-8]!
    // 0xb16c40: r0 = _interpolate()
    //     0xb16c40: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16c44: add             SP, SP, #8
    // 0xb16c48: LeaveFrame
    //     0xb16c48: mov             SP, fp
    //     0xb16c4c: ldp             fp, lr, [SP], #0x10
    // 0xb16c50: ret
    //     0xb16c50: ret             
    // 0xb16c54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16c54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16c58: b               #0xb16c14
  }
}

// lib: , url: package:flutter/src/rendering/debug_overflow_indicator.dart

// class id: 1049399, size: 0x8
class :: {
}

// class id: 2403, size: 0x50, field offset: 0x50
abstract class DebugOverflowIndicatorMixin extends RenderObject {
}

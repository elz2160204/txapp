// lib: , url: package:flutter/src/rendering/image.dart

// class id: 1049404, size: 0x8
class :: {
}

// class id: 2435, size: 0xb4, field offset: 0x60
class RenderImage extends RenderBox {

  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x631f38, size: 0x18
    // 0x631f38: r4 = 0
    //     0x631f38: mov             x4, #0
    // 0x631f3c: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x631f3c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b380] AnonymousClosure: (0x631f50), in [package:flutter/src/rendering/image.dart] RenderImage::computeMaxIntrinsicHeight (0x631f9c)
    //     0x631f40: ldr             x1, [x17, #0x380]
    // 0x631f44: r24 = BuildNonGenericMethodExtractorStub
    //     0x631f44: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x631f48: LoadField: r0 = r24->field_17
    //     0x631f48: ldur            x0, [x24, #0x17]
    // 0x631f4c: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x631f50, size: 0x4c
    // 0x631f50: EnterFrame
    //     0x631f50: stp             fp, lr, [SP, #-0x10]!
    //     0x631f54: mov             fp, SP
    // 0x631f58: ldr             x0, [fp, #0x18]
    // 0x631f5c: LoadField: r1 = r0->field_17
    //     0x631f5c: ldur            w1, [x0, #0x17]
    // 0x631f60: DecompressPointer r1
    //     0x631f60: add             x1, x1, HEAP, lsl #32
    // 0x631f64: CheckStackOverflow
    //     0x631f64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x631f68: cmp             SP, x16
    //     0x631f6c: b.ls            #0x631f94
    // 0x631f70: LoadField: r0 = r1->field_f
    //     0x631f70: ldur            w0, [x1, #0xf]
    // 0x631f74: DecompressPointer r0
    //     0x631f74: add             x0, x0, HEAP, lsl #32
    // 0x631f78: ldr             x16, [fp, #0x10]
    // 0x631f7c: stp             x16, x0, [SP, #-0x10]!
    // 0x631f80: r0 = computeMaxIntrinsicHeight()
    //     0x631f80: bl              #0x631f9c  ; [package:flutter/src/rendering/image.dart] RenderImage::computeMaxIntrinsicHeight
    // 0x631f84: add             SP, SP, #0x10
    // 0x631f88: LeaveFrame
    //     0x631f88: mov             SP, fp
    //     0x631f8c: ldp             fp, lr, [SP], #0x10
    // 0x631f90: ret
    //     0x631f90: ret             
    // 0x631f94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x631f94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x631f98: b               #0x631f70
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0x631f9c, size: 0xfc
    // 0x631f9c: EnterFrame
    //     0x631f9c: stp             fp, lr, [SP, #-0x10]!
    //     0x631fa0: mov             fp, SP
    // 0x631fa4: AllocStack(0x18)
    //     0x631fa4: sub             SP, SP, #0x18
    // 0x631fa8: d0 = inf
    //     0x631fa8: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x631fac: CheckStackOverflow
    //     0x631fac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x631fb0: cmp             SP, x16
    //     0x631fb4: b.ls            #0x632080
    // 0x631fb8: ldr             x0, [fp, #0x10]
    // 0x631fbc: LoadField: d1 = r0->field_7
    //     0x631fbc: ldur            d1, [x0, #7]
    // 0x631fc0: stur            d1, [fp, #-0x18]
    // 0x631fc4: fcmp            d1, d0
    // 0x631fc8: b.vs            #0x631fd0
    // 0x631fcc: b.eq            #0x631fd8
    // 0x631fd0: r0 = false
    //     0x631fd0: add             x0, NULL, #0x30  ; false
    // 0x631fd4: b               #0x631fdc
    // 0x631fd8: r0 = true
    //     0x631fd8: add             x0, NULL, #0x20  ; true
    // 0x631fdc: stur            x0, [fp, #-8]
    // 0x631fe0: tbz             w0, #4, #0x631fec
    // 0x631fe4: mov             v2.16b, v1.16b
    // 0x631fe8: b               #0x631ff0
    // 0x631fec: d2 = 0.000000
    //     0x631fec: eor             v2.16b, v2.16b, v2.16b
    // 0x631ff0: stur            d2, [fp, #-0x10]
    // 0x631ff4: r0 = BoxConstraints()
    //     0x631ff4: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x631ff8: ldur            d0, [fp, #-0x10]
    // 0x631ffc: StoreField: r0->field_7 = d0
    //     0x631ffc: stur            d0, [x0, #7]
    // 0x632000: ldur            x1, [fp, #-8]
    // 0x632004: tbz             w1, #4, #0x632010
    // 0x632008: ldur            d1, [fp, #-0x18]
    // 0x63200c: b               #0x632014
    // 0x632010: d1 = inf
    //     0x632010: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x632014: d0 = inf
    //     0x632014: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x632018: StoreField: r0->field_f = d1
    //     0x632018: stur            d1, [x0, #0xf]
    // 0x63201c: fcmp            d0, d0
    // 0x632020: b.eq            #0x63202c
    // 0x632024: d1 = inf
    //     0x632024: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x632028: b               #0x632030
    // 0x63202c: d1 = 0.000000
    //     0x63202c: eor             v1.16b, v1.16b, v1.16b
    // 0x632030: StoreField: r0->field_17 = d1
    //     0x632030: stur            d1, [x0, #0x17]
    // 0x632034: StoreField: r0->field_1f = d0
    //     0x632034: stur            d0, [x0, #0x1f]
    // 0x632038: ldr             x16, [fp, #0x18]
    // 0x63203c: stp             x0, x16, [SP, #-0x10]!
    // 0x632040: r0 = _sizeForConstraints()
    //     0x632040: bl              #0x632098  ; [package:flutter/src/rendering/image.dart] RenderImage::_sizeForConstraints
    // 0x632044: add             SP, SP, #0x10
    // 0x632048: LoadField: d0 = r0->field_f
    //     0x632048: ldur            d0, [x0, #0xf]
    // 0x63204c: r0 = inline_Allocate_Double()
    //     0x63204c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x632050: add             x0, x0, #0x10
    //     0x632054: cmp             x1, x0
    //     0x632058: b.ls            #0x632088
    //     0x63205c: str             x0, [THR, #0x60]  ; THR::top
    //     0x632060: sub             x0, x0, #0xf
    //     0x632064: mov             x1, #0xd108
    //     0x632068: movk            x1, #3, lsl #16
    //     0x63206c: stur            x1, [x0, #-1]
    // 0x632070: StoreField: r0->field_7 = d0
    //     0x632070: stur            d0, [x0, #7]
    // 0x632074: LeaveFrame
    //     0x632074: mov             SP, fp
    //     0x632078: ldp             fp, lr, [SP], #0x10
    // 0x63207c: ret
    //     0x63207c: ret             
    // 0x632080: r0 = StackOverflowSharedWithFPURegs()
    //     0x632080: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x632084: b               #0x631fb8
    // 0x632088: SaveReg d0
    //     0x632088: str             q0, [SP, #-0x10]!
    // 0x63208c: r0 = AllocateDouble()
    //     0x63208c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x632090: RestoreReg d0
    //     0x632090: ldr             q0, [SP], #0x10
    // 0x632094: b               #0x632070
  }
  _ _sizeForConstraints(/* No info */) {
    // ** addr: 0x632098, size: 0x1b0
    // 0x632098: EnterFrame
    //     0x632098: stp             fp, lr, [SP, #-0x10]!
    //     0x63209c: mov             fp, SP
    // 0x6320a0: AllocStack(0x20)
    //     0x6320a0: sub             SP, SP, #0x20
    // 0x6320a4: CheckStackOverflow
    //     0x6320a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6320a8: cmp             SP, x16
    //     0x6320ac: b.ls            #0x63223c
    // 0x6320b0: ldr             x0, [fp, #0x18]
    // 0x6320b4: LoadField: r1 = r0->field_6f
    //     0x6320b4: ldur            w1, [x0, #0x6f]
    // 0x6320b8: DecompressPointer r1
    //     0x6320b8: add             x1, x1, HEAP, lsl #32
    // 0x6320bc: stur            x1, [fp, #-0x10]
    // 0x6320c0: LoadField: r2 = r0->field_73
    //     0x6320c0: ldur            w2, [x0, #0x73]
    // 0x6320c4: DecompressPointer r2
    //     0x6320c4: add             x2, x2, HEAP, lsl #32
    // 0x6320c8: stur            x2, [fp, #-8]
    // 0x6320cc: cmp             w1, NULL
    // 0x6320d0: b.ne            #0x6320dc
    // 0x6320d4: d0 = 0.000000
    //     0x6320d4: eor             v0.16b, v0.16b, v0.16b
    // 0x6320d8: b               #0x6320e0
    // 0x6320dc: LoadField: d0 = r1->field_7
    //     0x6320dc: ldur            d0, [x1, #7]
    // 0x6320e0: stur            d0, [fp, #-0x18]
    // 0x6320e4: r0 = BoxConstraints()
    //     0x6320e4: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x6320e8: ldur            d0, [fp, #-0x18]
    // 0x6320ec: StoreField: r0->field_7 = d0
    //     0x6320ec: stur            d0, [x0, #7]
    // 0x6320f0: ldur            x1, [fp, #-0x10]
    // 0x6320f4: cmp             w1, NULL
    // 0x6320f8: b.ne            #0x632104
    // 0x6320fc: d0 = inf
    //     0x6320fc: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x632100: b               #0x632108
    // 0x632104: LoadField: d0 = r1->field_7
    //     0x632104: ldur            d0, [x1, #7]
    // 0x632108: ldur            x1, [fp, #-8]
    // 0x63210c: StoreField: r0->field_f = d0
    //     0x63210c: stur            d0, [x0, #0xf]
    // 0x632110: cmp             w1, NULL
    // 0x632114: b.ne            #0x632120
    // 0x632118: d0 = 0.000000
    //     0x632118: eor             v0.16b, v0.16b, v0.16b
    // 0x63211c: b               #0x632124
    // 0x632120: LoadField: d0 = r1->field_7
    //     0x632120: ldur            d0, [x1, #7]
    // 0x632124: StoreField: r0->field_17 = d0
    //     0x632124: stur            d0, [x0, #0x17]
    // 0x632128: cmp             w1, NULL
    // 0x63212c: b.ne            #0x632138
    // 0x632130: d0 = inf
    //     0x632130: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x632134: b               #0x63213c
    // 0x632138: LoadField: d0 = r1->field_7
    //     0x632138: ldur            d0, [x1, #7]
    // 0x63213c: ldr             x1, [fp, #0x18]
    // 0x632140: StoreField: r0->field_1f = d0
    //     0x632140: stur            d0, [x0, #0x1f]
    // 0x632144: ldr             x16, [fp, #0x10]
    // 0x632148: stp             x16, x0, [SP, #-0x10]!
    // 0x63214c: r0 = enforce()
    //     0x63214c: bl              #0x62bd90  ; [package:flutter/src/rendering/box.dart] BoxConstraints::enforce
    // 0x632150: add             SP, SP, #0x10
    // 0x632154: mov             x3, x0
    // 0x632158: ldr             x2, [fp, #0x18]
    // 0x63215c: stur            x3, [fp, #-8]
    // 0x632160: LoadField: r0 = r2->field_67
    //     0x632160: ldur            w0, [x2, #0x67]
    // 0x632164: DecompressPointer r0
    //     0x632164: add             x0, x0, HEAP, lsl #32
    // 0x632168: cmp             w0, NULL
    // 0x63216c: b.ne            #0x632188
    // 0x632170: SaveReg r3
    //     0x632170: str             x3, [SP, #-8]!
    // 0x632174: r0 = smallest()
    //     0x632174: bl              #0x62bd18  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0x632178: add             SP, SP, #8
    // 0x63217c: LeaveFrame
    //     0x63217c: mov             SP, fp
    //     0x632180: ldp             fp, lr, [SP], #0x10
    // 0x632184: ret
    //     0x632184: ret             
    // 0x632188: LoadField: r4 = r0->field_f
    //     0x632188: ldur            x4, [x0, #0xf]
    // 0x63218c: r0 = BoxInt64Instr(r4)
    //     0x63218c: sbfiz           x0, x4, #1, #0x1f
    //     0x632190: cmp             x4, x0, asr #1
    //     0x632194: b.eq            #0x6321a0
    //     0x632198: bl              #0xd69bb8
    //     0x63219c: stur            x4, [x0, #7]
    // 0x6321a0: stp             x0, NULL, [SP, #-0x10]!
    // 0x6321a4: r0 = _Double.fromInteger()
    //     0x6321a4: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x6321a8: add             SP, SP, #0x10
    // 0x6321ac: ldr             x2, [fp, #0x18]
    // 0x6321b0: LoadField: d0 = r2->field_77
    //     0x6321b0: ldur            d0, [x2, #0x77]
    // 0x6321b4: LoadField: d1 = r0->field_7
    //     0x6321b4: ldur            d1, [x0, #7]
    // 0x6321b8: fdiv            d2, d1, d0
    // 0x6321bc: stur            d2, [fp, #-0x18]
    // 0x6321c0: LoadField: r0 = r2->field_67
    //     0x6321c0: ldur            w0, [x2, #0x67]
    // 0x6321c4: DecompressPointer r0
    //     0x6321c4: add             x0, x0, HEAP, lsl #32
    // 0x6321c8: cmp             w0, NULL
    // 0x6321cc: b.eq            #0x632244
    // 0x6321d0: LoadField: r3 = r0->field_17
    //     0x6321d0: ldur            x3, [x0, #0x17]
    // 0x6321d4: r0 = BoxInt64Instr(r3)
    //     0x6321d4: sbfiz           x0, x3, #1, #0x1f
    //     0x6321d8: cmp             x3, x0, asr #1
    //     0x6321dc: b.eq            #0x6321e8
    //     0x6321e0: bl              #0xd69c6c
    //     0x6321e4: stur            x3, [x0, #7]
    // 0x6321e8: stp             x0, NULL, [SP, #-0x10]!
    // 0x6321ec: r0 = _Double.fromInteger()
    //     0x6321ec: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x6321f0: add             SP, SP, #0x10
    // 0x6321f4: mov             x1, x0
    // 0x6321f8: ldr             x0, [fp, #0x18]
    // 0x6321fc: LoadField: d0 = r0->field_77
    //     0x6321fc: ldur            d0, [x0, #0x77]
    // 0x632200: LoadField: d1 = r1->field_7
    //     0x632200: ldur            d1, [x1, #7]
    // 0x632204: fdiv            d2, d1, d0
    // 0x632208: stur            d2, [fp, #-0x20]
    // 0x63220c: r0 = Size()
    //     0x63220c: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x632210: ldur            d0, [fp, #-0x18]
    // 0x632214: StoreField: r0->field_7 = d0
    //     0x632214: stur            d0, [x0, #7]
    // 0x632218: ldur            d0, [fp, #-0x20]
    // 0x63221c: StoreField: r0->field_f = d0
    //     0x63221c: stur            d0, [x0, #0xf]
    // 0x632220: ldur            x16, [fp, #-8]
    // 0x632224: stp             x0, x16, [SP, #-0x10]!
    // 0x632228: r0 = constrainSizeAndAttemptToPreserveAspectRatio()
    //     0x632228: bl              #0x62ba34  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainSizeAndAttemptToPreserveAspectRatio
    // 0x63222c: add             SP, SP, #0x10
    // 0x632230: LeaveFrame
    //     0x632230: mov             SP, fp
    //     0x632234: ldp             fp, lr, [SP], #0x10
    // 0x632238: ret
    //     0x632238: ret             
    // 0x63223c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63223c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x632240: b               #0x6320b0
    // 0x632244: r0 = NullCastErrorSharedWithFPURegs()
    //     0x632244: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x636d84, size: 0x18
    // 0x636d84: r4 = 0
    //     0x636d84: mov             x4, #0
    // 0x636d88: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x636d88: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fd30] AnonymousClosure: (0x636d9c), in [package:flutter/src/rendering/image.dart] RenderImage::computeMaxIntrinsicWidth (0x636de8)
    //     0x636d8c: ldr             x1, [x17, #0xd30]
    // 0x636d90: r24 = BuildNonGenericMethodExtractorStub
    //     0x636d90: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x636d94: LoadField: r0 = r24->field_17
    //     0x636d94: ldur            x0, [x24, #0x17]
    // 0x636d98: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x636d9c, size: 0x4c
    // 0x636d9c: EnterFrame
    //     0x636d9c: stp             fp, lr, [SP, #-0x10]!
    //     0x636da0: mov             fp, SP
    // 0x636da4: ldr             x0, [fp, #0x18]
    // 0x636da8: LoadField: r1 = r0->field_17
    //     0x636da8: ldur            w1, [x0, #0x17]
    // 0x636dac: DecompressPointer r1
    //     0x636dac: add             x1, x1, HEAP, lsl #32
    // 0x636db0: CheckStackOverflow
    //     0x636db0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x636db4: cmp             SP, x16
    //     0x636db8: b.ls            #0x636de0
    // 0x636dbc: LoadField: r0 = r1->field_f
    //     0x636dbc: ldur            w0, [x1, #0xf]
    // 0x636dc0: DecompressPointer r0
    //     0x636dc0: add             x0, x0, HEAP, lsl #32
    // 0x636dc4: ldr             x16, [fp, #0x10]
    // 0x636dc8: stp             x16, x0, [SP, #-0x10]!
    // 0x636dcc: r0 = computeMaxIntrinsicWidth()
    //     0x636dcc: bl              #0x636de8  ; [package:flutter/src/rendering/image.dart] RenderImage::computeMaxIntrinsicWidth
    // 0x636dd0: add             SP, SP, #0x10
    // 0x636dd4: LeaveFrame
    //     0x636dd4: mov             SP, fp
    //     0x636dd8: ldp             fp, lr, [SP], #0x10
    // 0x636ddc: ret
    //     0x636ddc: ret             
    // 0x636de0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x636de0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x636de4: b               #0x636dbc
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0x636de8, size: 0xf4
    // 0x636de8: EnterFrame
    //     0x636de8: stp             fp, lr, [SP, #-0x10]!
    //     0x636dec: mov             fp, SP
    // 0x636df0: AllocStack(0x8)
    //     0x636df0: sub             SP, SP, #8
    // 0x636df4: d0 = inf
    //     0x636df4: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x636df8: CheckStackOverflow
    //     0x636df8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x636dfc: cmp             SP, x16
    //     0x636e00: b.ls            #0x636ec4
    // 0x636e04: fcmp            d0, d0
    // 0x636e08: b.eq            #0x636e14
    // 0x636e0c: d1 = inf
    //     0x636e0c: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x636e10: b               #0x636e18
    // 0x636e14: d1 = 0.000000
    //     0x636e14: eor             v1.16b, v1.16b, v1.16b
    // 0x636e18: ldr             x0, [fp, #0x10]
    // 0x636e1c: stur            d1, [fp, #-8]
    // 0x636e20: r0 = BoxConstraints()
    //     0x636e20: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x636e24: ldur            d0, [fp, #-8]
    // 0x636e28: StoreField: r0->field_7 = d0
    //     0x636e28: stur            d0, [x0, #7]
    // 0x636e2c: d0 = inf
    //     0x636e2c: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x636e30: StoreField: r0->field_f = d0
    //     0x636e30: stur            d0, [x0, #0xf]
    // 0x636e34: ldr             x1, [fp, #0x10]
    // 0x636e38: LoadField: d1 = r1->field_7
    //     0x636e38: ldur            d1, [x1, #7]
    // 0x636e3c: fcmp            d1, d0
    // 0x636e40: b.vs            #0x636e48
    // 0x636e44: b.eq            #0x636e50
    // 0x636e48: r1 = false
    //     0x636e48: add             x1, NULL, #0x30  ; false
    // 0x636e4c: b               #0x636e54
    // 0x636e50: r1 = true
    //     0x636e50: add             x1, NULL, #0x20  ; true
    // 0x636e54: tbz             w1, #4, #0x636e60
    // 0x636e58: mov             v0.16b, v1.16b
    // 0x636e5c: b               #0x636e64
    // 0x636e60: d0 = 0.000000
    //     0x636e60: eor             v0.16b, v0.16b, v0.16b
    // 0x636e64: StoreField: r0->field_17 = d0
    //     0x636e64: stur            d0, [x0, #0x17]
    // 0x636e68: tbz             w1, #4, #0x636e74
    // 0x636e6c: mov             v0.16b, v1.16b
    // 0x636e70: b               #0x636e78
    // 0x636e74: d0 = inf
    //     0x636e74: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x636e78: StoreField: r0->field_1f = d0
    //     0x636e78: stur            d0, [x0, #0x1f]
    // 0x636e7c: ldr             x16, [fp, #0x18]
    // 0x636e80: stp             x0, x16, [SP, #-0x10]!
    // 0x636e84: r0 = _sizeForConstraints()
    //     0x636e84: bl              #0x632098  ; [package:flutter/src/rendering/image.dart] RenderImage::_sizeForConstraints
    // 0x636e88: add             SP, SP, #0x10
    // 0x636e8c: LoadField: d0 = r0->field_7
    //     0x636e8c: ldur            d0, [x0, #7]
    // 0x636e90: r0 = inline_Allocate_Double()
    //     0x636e90: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x636e94: add             x0, x0, #0x10
    //     0x636e98: cmp             x1, x0
    //     0x636e9c: b.ls            #0x636ecc
    //     0x636ea0: str             x0, [THR, #0x60]  ; THR::top
    //     0x636ea4: sub             x0, x0, #0xf
    //     0x636ea8: mov             x1, #0xd108
    //     0x636eac: movk            x1, #3, lsl #16
    //     0x636eb0: stur            x1, [x0, #-1]
    // 0x636eb4: StoreField: r0->field_7 = d0
    //     0x636eb4: stur            d0, [x0, #7]
    // 0x636eb8: LeaveFrame
    //     0x636eb8: mov             SP, fp
    //     0x636ebc: ldp             fp, lr, [SP], #0x10
    // 0x636ec0: ret
    //     0x636ec0: ret             
    // 0x636ec4: r0 = StackOverflowSharedWithFPURegs()
    //     0x636ec4: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x636ec8: b               #0x636e04
    // 0x636ecc: SaveReg d0
    //     0x636ecc: str             q0, [SP, #-0x10]!
    // 0x636ed0: r0 = AllocateDouble()
    //     0x636ed0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x636ed4: RestoreReg d0
    //     0x636ed4: ldr             q0, [SP], #0x10
    // 0x636ed8: b               #0x636eb4
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x6395c8, size: 0x18
    // 0x6395c8: r4 = 0
    //     0x6395c8: mov             x4, #0
    // 0x6395cc: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x6395cc: add             x17, PP, #0x52, lsl #12  ; [pp+0x52f10] AnonymousClosure: (0x6395e0), in [package:flutter/src/rendering/image.dart] RenderImage::computeMinIntrinsicHeight (0x63962c)
    //     0x6395d0: ldr             x1, [x17, #0xf10]
    // 0x6395d4: r24 = BuildNonGenericMethodExtractorStub
    //     0x6395d4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x6395d8: LoadField: r0 = r24->field_17
    //     0x6395d8: ldur            x0, [x24, #0x17]
    // 0x6395dc: br              x0
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x6395e0, size: 0x4c
    // 0x6395e0: EnterFrame
    //     0x6395e0: stp             fp, lr, [SP, #-0x10]!
    //     0x6395e4: mov             fp, SP
    // 0x6395e8: ldr             x0, [fp, #0x18]
    // 0x6395ec: LoadField: r1 = r0->field_17
    //     0x6395ec: ldur            w1, [x0, #0x17]
    // 0x6395f0: DecompressPointer r1
    //     0x6395f0: add             x1, x1, HEAP, lsl #32
    // 0x6395f4: CheckStackOverflow
    //     0x6395f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6395f8: cmp             SP, x16
    //     0x6395fc: b.ls            #0x639624
    // 0x639600: LoadField: r0 = r1->field_f
    //     0x639600: ldur            w0, [x1, #0xf]
    // 0x639604: DecompressPointer r0
    //     0x639604: add             x0, x0, HEAP, lsl #32
    // 0x639608: ldr             x16, [fp, #0x10]
    // 0x63960c: stp             x16, x0, [SP, #-0x10]!
    // 0x639610: r0 = computeMinIntrinsicHeight()
    //     0x639610: bl              #0x63962c  ; [package:flutter/src/rendering/image.dart] RenderImage::computeMinIntrinsicHeight
    // 0x639614: add             SP, SP, #0x10
    // 0x639618: LeaveFrame
    //     0x639618: mov             SP, fp
    //     0x63961c: ldp             fp, lr, [SP], #0x10
    // 0x639620: ret
    //     0x639620: ret             
    // 0x639624: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x639624: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x639628: b               #0x639600
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0x63962c, size: 0x130
    // 0x63962c: EnterFrame
    //     0x63962c: stp             fp, lr, [SP, #-0x10]!
    //     0x639630: mov             fp, SP
    // 0x639634: AllocStack(0x18)
    //     0x639634: sub             SP, SP, #0x18
    // 0x639638: CheckStackOverflow
    //     0x639638: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63963c: cmp             SP, x16
    //     0x639640: b.ls            #0x639744
    // 0x639644: ldr             x0, [fp, #0x18]
    // 0x639648: LoadField: r1 = r0->field_6f
    //     0x639648: ldur            w1, [x0, #0x6f]
    // 0x63964c: DecompressPointer r1
    //     0x63964c: add             x1, x1, HEAP, lsl #32
    // 0x639650: cmp             w1, NULL
    // 0x639654: b.ne            #0x639678
    // 0x639658: LoadField: r1 = r0->field_73
    //     0x639658: ldur            w1, [x0, #0x73]
    // 0x63965c: DecompressPointer r1
    //     0x63965c: add             x1, x1, HEAP, lsl #32
    // 0x639660: cmp             w1, NULL
    // 0x639664: b.ne            #0x639678
    // 0x639668: r0 = 0.000000
    //     0x639668: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x63966c: LeaveFrame
    //     0x63966c: mov             SP, fp
    //     0x639670: ldp             fp, lr, [SP], #0x10
    // 0x639674: ret
    //     0x639674: ret             
    // 0x639678: ldr             x1, [fp, #0x10]
    // 0x63967c: d0 = inf
    //     0x63967c: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x639680: LoadField: d1 = r1->field_7
    //     0x639680: ldur            d1, [x1, #7]
    // 0x639684: stur            d1, [fp, #-0x18]
    // 0x639688: fcmp            d1, d0
    // 0x63968c: b.vs            #0x639694
    // 0x639690: b.eq            #0x63969c
    // 0x639694: r1 = false
    //     0x639694: add             x1, NULL, #0x30  ; false
    // 0x639698: b               #0x6396a0
    // 0x63969c: r1 = true
    //     0x63969c: add             x1, NULL, #0x20  ; true
    // 0x6396a0: stur            x1, [fp, #-8]
    // 0x6396a4: tbz             w1, #4, #0x6396b0
    // 0x6396a8: mov             v2.16b, v1.16b
    // 0x6396ac: b               #0x6396b4
    // 0x6396b0: d2 = 0.000000
    //     0x6396b0: eor             v2.16b, v2.16b, v2.16b
    // 0x6396b4: stur            d2, [fp, #-0x10]
    // 0x6396b8: r0 = BoxConstraints()
    //     0x6396b8: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x6396bc: ldur            d0, [fp, #-0x10]
    // 0x6396c0: StoreField: r0->field_7 = d0
    //     0x6396c0: stur            d0, [x0, #7]
    // 0x6396c4: ldur            x1, [fp, #-8]
    // 0x6396c8: tbz             w1, #4, #0x6396d4
    // 0x6396cc: ldur            d1, [fp, #-0x18]
    // 0x6396d0: b               #0x6396d8
    // 0x6396d4: d1 = inf
    //     0x6396d4: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x6396d8: d0 = inf
    //     0x6396d8: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x6396dc: StoreField: r0->field_f = d1
    //     0x6396dc: stur            d1, [x0, #0xf]
    // 0x6396e0: fcmp            d0, d0
    // 0x6396e4: b.eq            #0x6396f0
    // 0x6396e8: d1 = inf
    //     0x6396e8: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x6396ec: b               #0x6396f4
    // 0x6396f0: d1 = 0.000000
    //     0x6396f0: eor             v1.16b, v1.16b, v1.16b
    // 0x6396f4: StoreField: r0->field_17 = d1
    //     0x6396f4: stur            d1, [x0, #0x17]
    // 0x6396f8: StoreField: r0->field_1f = d0
    //     0x6396f8: stur            d0, [x0, #0x1f]
    // 0x6396fc: ldr             x16, [fp, #0x18]
    // 0x639700: stp             x0, x16, [SP, #-0x10]!
    // 0x639704: r0 = _sizeForConstraints()
    //     0x639704: bl              #0x632098  ; [package:flutter/src/rendering/image.dart] RenderImage::_sizeForConstraints
    // 0x639708: add             SP, SP, #0x10
    // 0x63970c: LoadField: d0 = r0->field_f
    //     0x63970c: ldur            d0, [x0, #0xf]
    // 0x639710: r0 = inline_Allocate_Double()
    //     0x639710: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x639714: add             x0, x0, #0x10
    //     0x639718: cmp             x1, x0
    //     0x63971c: b.ls            #0x63974c
    //     0x639720: str             x0, [THR, #0x60]  ; THR::top
    //     0x639724: sub             x0, x0, #0xf
    //     0x639728: mov             x1, #0xd108
    //     0x63972c: movk            x1, #3, lsl #16
    //     0x639730: stur            x1, [x0, #-1]
    // 0x639734: StoreField: r0->field_7 = d0
    //     0x639734: stur            d0, [x0, #7]
    // 0x639738: LeaveFrame
    //     0x639738: mov             SP, fp
    //     0x63973c: ldp             fp, lr, [SP], #0x10
    // 0x639740: ret
    //     0x639740: ret             
    // 0x639744: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x639744: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x639748: b               #0x639644
    // 0x63974c: SaveReg d0
    //     0x63974c: str             q0, [SP, #-0x10]!
    // 0x639750: r0 = AllocateDouble()
    //     0x639750: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x639754: RestoreReg d0
    //     0x639754: ldr             q0, [SP], #0x10
    // 0x639758: b               #0x639734
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63c8d0, size: 0x18
    // 0x63c8d0: r4 = 0
    //     0x63c8d0: mov             x4, #0
    // 0x63c8d4: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63c8d4: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fed8] AnonymousClosure: (0x63c8e8), in [package:flutter/src/rendering/image.dart] RenderImage::computeMinIntrinsicWidth (0x63c934)
    //     0x63c8d8: ldr             x1, [x17, #0xed8]
    // 0x63c8dc: r24 = BuildNonGenericMethodExtractorStub
    //     0x63c8dc: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63c8e0: LoadField: r0 = r24->field_17
    //     0x63c8e0: ldur            x0, [x24, #0x17]
    // 0x63c8e4: br              x0
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63c8e8, size: 0x4c
    // 0x63c8e8: EnterFrame
    //     0x63c8e8: stp             fp, lr, [SP, #-0x10]!
    //     0x63c8ec: mov             fp, SP
    // 0x63c8f0: ldr             x0, [fp, #0x18]
    // 0x63c8f4: LoadField: r1 = r0->field_17
    //     0x63c8f4: ldur            w1, [x0, #0x17]
    // 0x63c8f8: DecompressPointer r1
    //     0x63c8f8: add             x1, x1, HEAP, lsl #32
    // 0x63c8fc: CheckStackOverflow
    //     0x63c8fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63c900: cmp             SP, x16
    //     0x63c904: b.ls            #0x63c92c
    // 0x63c908: LoadField: r0 = r1->field_f
    //     0x63c908: ldur            w0, [x1, #0xf]
    // 0x63c90c: DecompressPointer r0
    //     0x63c90c: add             x0, x0, HEAP, lsl #32
    // 0x63c910: ldr             x16, [fp, #0x10]
    // 0x63c914: stp             x16, x0, [SP, #-0x10]!
    // 0x63c918: r0 = computeMinIntrinsicWidth()
    //     0x63c918: bl              #0x63c934  ; [package:flutter/src/rendering/image.dart] RenderImage::computeMinIntrinsicWidth
    // 0x63c91c: add             SP, SP, #0x10
    // 0x63c920: LeaveFrame
    //     0x63c920: mov             SP, fp
    //     0x63c924: ldp             fp, lr, [SP], #0x10
    // 0x63c928: ret
    //     0x63c928: ret             
    // 0x63c92c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63c92c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63c930: b               #0x63c908
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0x63c934, size: 0x128
    // 0x63c934: EnterFrame
    //     0x63c934: stp             fp, lr, [SP, #-0x10]!
    //     0x63c938: mov             fp, SP
    // 0x63c93c: AllocStack(0x8)
    //     0x63c93c: sub             SP, SP, #8
    // 0x63c940: CheckStackOverflow
    //     0x63c940: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63c944: cmp             SP, x16
    //     0x63c948: b.ls            #0x63ca44
    // 0x63c94c: ldr             x0, [fp, #0x18]
    // 0x63c950: LoadField: r1 = r0->field_6f
    //     0x63c950: ldur            w1, [x0, #0x6f]
    // 0x63c954: DecompressPointer r1
    //     0x63c954: add             x1, x1, HEAP, lsl #32
    // 0x63c958: cmp             w1, NULL
    // 0x63c95c: b.ne            #0x63c980
    // 0x63c960: LoadField: r1 = r0->field_73
    //     0x63c960: ldur            w1, [x0, #0x73]
    // 0x63c964: DecompressPointer r1
    //     0x63c964: add             x1, x1, HEAP, lsl #32
    // 0x63c968: cmp             w1, NULL
    // 0x63c96c: b.ne            #0x63c980
    // 0x63c970: r0 = 0.000000
    //     0x63c970: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x63c974: LeaveFrame
    //     0x63c974: mov             SP, fp
    //     0x63c978: ldp             fp, lr, [SP], #0x10
    // 0x63c97c: ret
    //     0x63c97c: ret             
    // 0x63c980: d0 = inf
    //     0x63c980: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x63c984: fcmp            d0, d0
    // 0x63c988: b.eq            #0x63c994
    // 0x63c98c: d1 = inf
    //     0x63c98c: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x63c990: b               #0x63c998
    // 0x63c994: d1 = 0.000000
    //     0x63c994: eor             v1.16b, v1.16b, v1.16b
    // 0x63c998: ldr             x1, [fp, #0x10]
    // 0x63c99c: stur            d1, [fp, #-8]
    // 0x63c9a0: r0 = BoxConstraints()
    //     0x63c9a0: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x63c9a4: ldur            d0, [fp, #-8]
    // 0x63c9a8: StoreField: r0->field_7 = d0
    //     0x63c9a8: stur            d0, [x0, #7]
    // 0x63c9ac: d0 = inf
    //     0x63c9ac: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x63c9b0: StoreField: r0->field_f = d0
    //     0x63c9b0: stur            d0, [x0, #0xf]
    // 0x63c9b4: ldr             x1, [fp, #0x10]
    // 0x63c9b8: LoadField: d1 = r1->field_7
    //     0x63c9b8: ldur            d1, [x1, #7]
    // 0x63c9bc: fcmp            d1, d0
    // 0x63c9c0: b.vs            #0x63c9c8
    // 0x63c9c4: b.eq            #0x63c9d0
    // 0x63c9c8: r1 = false
    //     0x63c9c8: add             x1, NULL, #0x30  ; false
    // 0x63c9cc: b               #0x63c9d4
    // 0x63c9d0: r1 = true
    //     0x63c9d0: add             x1, NULL, #0x20  ; true
    // 0x63c9d4: tbz             w1, #4, #0x63c9e0
    // 0x63c9d8: mov             v0.16b, v1.16b
    // 0x63c9dc: b               #0x63c9e4
    // 0x63c9e0: d0 = 0.000000
    //     0x63c9e0: eor             v0.16b, v0.16b, v0.16b
    // 0x63c9e4: StoreField: r0->field_17 = d0
    //     0x63c9e4: stur            d0, [x0, #0x17]
    // 0x63c9e8: tbz             w1, #4, #0x63c9f4
    // 0x63c9ec: mov             v0.16b, v1.16b
    // 0x63c9f0: b               #0x63c9f8
    // 0x63c9f4: d0 = inf
    //     0x63c9f4: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x63c9f8: StoreField: r0->field_1f = d0
    //     0x63c9f8: stur            d0, [x0, #0x1f]
    // 0x63c9fc: ldr             x16, [fp, #0x18]
    // 0x63ca00: stp             x0, x16, [SP, #-0x10]!
    // 0x63ca04: r0 = _sizeForConstraints()
    //     0x63ca04: bl              #0x632098  ; [package:flutter/src/rendering/image.dart] RenderImage::_sizeForConstraints
    // 0x63ca08: add             SP, SP, #0x10
    // 0x63ca0c: LoadField: d0 = r0->field_7
    //     0x63ca0c: ldur            d0, [x0, #7]
    // 0x63ca10: r0 = inline_Allocate_Double()
    //     0x63ca10: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63ca14: add             x0, x0, #0x10
    //     0x63ca18: cmp             x1, x0
    //     0x63ca1c: b.ls            #0x63ca4c
    //     0x63ca20: str             x0, [THR, #0x60]  ; THR::top
    //     0x63ca24: sub             x0, x0, #0xf
    //     0x63ca28: mov             x1, #0xd108
    //     0x63ca2c: movk            x1, #3, lsl #16
    //     0x63ca30: stur            x1, [x0, #-1]
    // 0x63ca34: StoreField: r0->field_7 = d0
    //     0x63ca34: stur            d0, [x0, #7]
    // 0x63ca38: LeaveFrame
    //     0x63ca38: mov             SP, fp
    //     0x63ca3c: ldp             fp, lr, [SP], #0x10
    // 0x63ca40: ret
    //     0x63ca40: ret             
    // 0x63ca44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63ca44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63ca48: b               #0x63c94c
    // 0x63ca4c: SaveReg d0
    //     0x63ca4c: str             q0, [SP, #-0x10]!
    // 0x63ca50: r0 = AllocateDouble()
    //     0x63ca50: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63ca54: RestoreReg d0
    //     0x63ca54: ldr             q0, [SP], #0x10
    // 0x63ca58: b               #0x63ca34
  }
  _ dispose(/* No info */) {
    // ** addr: 0x6533a0, size: 0x60
    // 0x6533a0: EnterFrame
    //     0x6533a0: stp             fp, lr, [SP, #-0x10]!
    //     0x6533a4: mov             fp, SP
    // 0x6533a8: CheckStackOverflow
    //     0x6533a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6533ac: cmp             SP, x16
    //     0x6533b0: b.ls            #0x6533f8
    // 0x6533b4: ldr             x0, [fp, #0x10]
    // 0x6533b8: LoadField: r1 = r0->field_67
    //     0x6533b8: ldur            w1, [x0, #0x67]
    // 0x6533bc: DecompressPointer r1
    //     0x6533bc: add             x1, x1, HEAP, lsl #32
    // 0x6533c0: cmp             w1, NULL
    // 0x6533c4: b.eq            #0x6533d8
    // 0x6533c8: SaveReg r1
    //     0x6533c8: str             x1, [SP, #-8]!
    // 0x6533cc: r0 = dispose()
    //     0x6533cc: bl              #0x6522a4  ; [dart:ui] Image::dispose
    // 0x6533d0: add             SP, SP, #8
    // 0x6533d4: ldr             x0, [fp, #0x10]
    // 0x6533d8: StoreField: r0->field_67 = rNULL
    //     0x6533d8: stur            NULL, [x0, #0x67]
    // 0x6533dc: SaveReg r0
    //     0x6533dc: str             x0, [SP, #-8]!
    // 0x6533e0: r0 = dispose()
    //     0x6533e0: bl              #0x65378c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0x6533e4: add             SP, SP, #8
    // 0x6533e8: r0 = Null
    //     0x6533e8: mov             x0, NULL
    // 0x6533ec: LeaveFrame
    //     0x6533ec: mov             SP, fp
    //     0x6533f0: ldp             fp, lr, [SP], #0x10
    // 0x6533f4: ret
    //     0x6533f4: ret             
    // 0x6533f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6533f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6533fc: b               #0x6533b4
  }
  _ paint(/* No info */) {
    // ** addr: 0x66d8a4, size: 0x1cc
    // 0x66d8a4: EnterFrame
    //     0x66d8a4: stp             fp, lr, [SP, #-0x10]!
    //     0x66d8a8: mov             fp, SP
    // 0x66d8ac: AllocStack(0x20)
    //     0x66d8ac: sub             SP, SP, #0x20
    // 0x66d8b0: CheckStackOverflow
    //     0x66d8b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66d8b4: cmp             SP, x16
    //     0x66d8b8: b.ls            #0x66da38
    // 0x66d8bc: ldr             x0, [fp, #0x20]
    // 0x66d8c0: LoadField: r1 = r0->field_67
    //     0x66d8c0: ldur            w1, [x0, #0x67]
    // 0x66d8c4: DecompressPointer r1
    //     0x66d8c4: add             x1, x1, HEAP, lsl #32
    // 0x66d8c8: cmp             w1, NULL
    // 0x66d8cc: b.ne            #0x66d8e0
    // 0x66d8d0: r0 = Null
    //     0x66d8d0: mov             x0, NULL
    // 0x66d8d4: LeaveFrame
    //     0x66d8d4: mov             SP, fp
    //     0x66d8d8: ldp             fp, lr, [SP], #0x10
    // 0x66d8dc: ret
    //     0x66d8dc: ret             
    // 0x66d8e0: SaveReg r0
    //     0x66d8e0: str             x0, [SP, #-8]!
    // 0x66d8e4: r0 = _resolve()
    //     0x66d8e4: bl              #0x66eb38  ; [package:flutter/src/rendering/image.dart] RenderImage::_resolve
    // 0x66d8e8: add             SP, SP, #8
    // 0x66d8ec: ldr             x16, [fp, #0x18]
    // 0x66d8f0: SaveReg r16
    //     0x66d8f0: str             x16, [SP, #-8]!
    // 0x66d8f4: r0 = canvas()
    //     0x66d8f4: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x66d8f8: add             SP, SP, #8
    // 0x66d8fc: mov             x1, x0
    // 0x66d900: ldr             x0, [fp, #0x20]
    // 0x66d904: stur            x1, [fp, #-8]
    // 0x66d908: LoadField: r2 = r0->field_57
    //     0x66d908: ldur            w2, [x0, #0x57]
    // 0x66d90c: DecompressPointer r2
    //     0x66d90c: add             x2, x2, HEAP, lsl #32
    // 0x66d910: cmp             w2, NULL
    // 0x66d914: b.eq            #0x66da40
    // 0x66d918: ldr             x16, [fp, #0x10]
    // 0x66d91c: stp             x2, x16, [SP, #-0x10]!
    // 0x66d920: r0 = &()
    //     0x66d920: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x66d924: add             SP, SP, #0x10
    // 0x66d928: mov             x1, x0
    // 0x66d92c: ldr             x0, [fp, #0x20]
    // 0x66d930: stur            x1, [fp, #-0x18]
    // 0x66d934: LoadField: r2 = r0->field_67
    //     0x66d934: ldur            w2, [x0, #0x67]
    // 0x66d938: DecompressPointer r2
    //     0x66d938: add             x2, x2, HEAP, lsl #32
    // 0x66d93c: stur            x2, [fp, #-0x10]
    // 0x66d940: cmp             w2, NULL
    // 0x66d944: b.eq            #0x66da44
    // 0x66d948: LoadField: d0 = r0->field_77
    //     0x66d948: ldur            d0, [x0, #0x77]
    // 0x66d94c: stur            d0, [fp, #-0x20]
    // 0x66d950: LoadField: r3 = r0->field_87
    //     0x66d950: ldur            w3, [x0, #0x87]
    // 0x66d954: DecompressPointer r3
    //     0x66d954: add             x3, x3, HEAP, lsl #32
    // 0x66d958: cmp             w3, NULL
    // 0x66d95c: b.ne            #0x66d968
    // 0x66d960: r0 = Null
    //     0x66d960: mov             x0, NULL
    // 0x66d964: b               #0x66d974
    // 0x66d968: SaveReg r3
    //     0x66d968: str             x3, [SP, #-8]!
    // 0x66d96c: r0 = value()
    //     0x66d96c: bl              #0xc24c94  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::value
    // 0x66d970: add             SP, SP, #8
    // 0x66d974: cmp             w0, NULL
    // 0x66d978: b.ne            #0x66d984
    // 0x66d97c: d1 = 1.000000
    //     0x66d97c: fmov            d1, #1.00000000
    // 0x66d980: b               #0x66d98c
    // 0x66d984: LoadField: d0 = r0->field_7
    //     0x66d984: ldur            d0, [x0, #7]
    // 0x66d988: mov             v1.16b, v0.16b
    // 0x66d98c: ldr             x0, [fp, #0x20]
    // 0x66d990: ldur            d0, [fp, #-0x20]
    // 0x66d994: LoadField: r1 = r0->field_7f
    //     0x66d994: ldur            w1, [x0, #0x7f]
    // 0x66d998: DecompressPointer r1
    //     0x66d998: add             x1, x1, HEAP, lsl #32
    // 0x66d99c: LoadField: r2 = r0->field_93
    //     0x66d99c: ldur            w2, [x0, #0x93]
    // 0x66d9a0: DecompressPointer r2
    //     0x66d9a0: add             x2, x2, HEAP, lsl #32
    // 0x66d9a4: LoadField: r3 = r0->field_5f
    //     0x66d9a4: ldur            w3, [x0, #0x5f]
    // 0x66d9a8: DecompressPointer r3
    //     0x66d9a8: add             x3, x3, HEAP, lsl #32
    // 0x66d9ac: cmp             w3, NULL
    // 0x66d9b0: b.eq            #0x66da48
    // 0x66d9b4: LoadField: r3 = r0->field_63
    //     0x66d9b4: ldur            w3, [x0, #0x63]
    // 0x66d9b8: DecompressPointer r3
    //     0x66d9b8: add             x3, x3, HEAP, lsl #32
    // 0x66d9bc: cmp             w3, NULL
    // 0x66d9c0: b.eq            #0x66da4c
    // 0x66d9c4: LoadField: r4 = r0->field_a3
    //     0x66d9c4: ldur            w4, [x0, #0xa3]
    // 0x66d9c8: DecompressPointer r4
    //     0x66d9c8: add             x4, x4, HEAP, lsl #32
    // 0x66d9cc: r0 = inline_Allocate_Double()
    //     0x66d9cc: ldp             x0, x5, [THR, #0x60]  ; THR::top
    //     0x66d9d0: add             x0, x0, #0x10
    //     0x66d9d4: cmp             x5, x0
    //     0x66d9d8: b.ls            #0x66da50
    //     0x66d9dc: str             x0, [THR, #0x60]  ; THR::top
    //     0x66d9e0: sub             x0, x0, #0xf
    //     0x66d9e4: mov             x5, #0xd108
    //     0x66d9e8: movk            x5, #3, lsl #16
    //     0x66d9ec: stur            x5, [x0, #-1]
    // 0x66d9f0: StoreField: r0->field_7 = d1
    //     0x66d9f0: stur            d1, [x0, #7]
    // 0x66d9f4: ldur            x16, [fp, #-8]
    // 0x66d9f8: stp             x1, x16, [SP, #-0x10]!
    // 0x66d9fc: stp             x3, x2, [SP, #-0x10]!
    // 0x66da00: ldur            x16, [fp, #-0x10]
    // 0x66da04: stp             x4, x16, [SP, #-0x10]!
    // 0x66da08: ldur            x16, [fp, #-0x18]
    // 0x66da0c: stp             x16, x0, [SP, #-0x10]!
    // 0x66da10: r16 = Instance_ImageRepeat
    //     0x66da10: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c540] Obj!ImageRepeat@b64dd1
    //     0x66da14: ldr             x16, [x16, #0x540]
    // 0x66da18: SaveReg r16
    //     0x66da18: str             x16, [SP, #-8]!
    // 0x66da1c: SaveReg d0
    //     0x66da1c: str             d0, [SP, #-8]!
    // 0x66da20: r0 = paintImage()
    //     0x66da20: bl              #0x66da70  ; [package:flutter/src/painting/decoration_image.dart] ::paintImage
    // 0x66da24: add             SP, SP, #0x50
    // 0x66da28: r0 = Null
    //     0x66da28: mov             x0, NULL
    // 0x66da2c: LeaveFrame
    //     0x66da2c: mov             SP, fp
    //     0x66da30: ldp             fp, lr, [SP], #0x10
    // 0x66da34: ret
    //     0x66da34: ret             
    // 0x66da38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66da38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66da3c: b               #0x66d8bc
    // 0x66da40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66da40: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x66da44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66da44: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x66da48: r0 = NullCastErrorSharedWithFPURegs()
    //     0x66da48: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x66da4c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x66da4c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x66da50: stp             q0, q1, [SP, #-0x20]!
    // 0x66da54: stp             x3, x4, [SP, #-0x10]!
    // 0x66da58: stp             x1, x2, [SP, #-0x10]!
    // 0x66da5c: r0 = AllocateDouble()
    //     0x66da5c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x66da60: ldp             x1, x2, [SP], #0x10
    // 0x66da64: ldp             x3, x4, [SP], #0x10
    // 0x66da68: ldp             q0, q1, [SP], #0x20
    // 0x66da6c: b               #0x66d9f0
  }
  _ _resolve(/* No info */) {
    // ** addr: 0x66eb38, size: 0x38
    // 0x66eb38: ldr             x1, [SP]
    // 0x66eb3c: LoadField: r2 = r1->field_5f
    //     0x66eb3c: ldur            w2, [x1, #0x5f]
    // 0x66eb40: DecompressPointer r2
    //     0x66eb40: add             x2, x2, HEAP, lsl #32
    // 0x66eb44: cmp             w2, NULL
    // 0x66eb48: b.eq            #0x66eb54
    // 0x66eb4c: r0 = Null
    //     0x66eb4c: mov             x0, NULL
    // 0x66eb50: ret
    //     0x66eb50: ret             
    // 0x66eb54: r3 = Instance_Alignment
    //     0x66eb54: add             x3, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x66eb58: ldr             x3, [x3, #0xc70]
    // 0x66eb5c: r2 = false
    //     0x66eb5c: add             x2, NULL, #0x30  ; false
    // 0x66eb60: StoreField: r1->field_5f = r3
    //     0x66eb60: stur            w3, [x1, #0x5f]
    // 0x66eb64: StoreField: r1->field_63 = r2
    //     0x66eb64: stur            w2, [x1, #0x63]
    // 0x66eb68: r0 = Null
    //     0x66eb68: mov             x0, NULL
    // 0x66eb6c: ret
    //     0x66eb6c: ret             
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x69cc54, size: 0xd0
    // 0x69cc54: EnterFrame
    //     0x69cc54: stp             fp, lr, [SP, #-0x10]!
    //     0x69cc58: mov             fp, SP
    // 0x69cc5c: AllocStack(0x8)
    //     0x69cc5c: sub             SP, SP, #8
    // 0x69cc60: CheckStackOverflow
    //     0x69cc60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x69cc64: cmp             SP, x16
    //     0x69cc68: b.ls            #0x69cd1c
    // 0x69cc6c: ldr             x3, [fp, #0x10]
    // 0x69cc70: LoadField: r4 = r3->field_27
    //     0x69cc70: ldur            w4, [x3, #0x27]
    // 0x69cc74: DecompressPointer r4
    //     0x69cc74: add             x4, x4, HEAP, lsl #32
    // 0x69cc78: stur            x4, [fp, #-8]
    // 0x69cc7c: cmp             w4, NULL
    // 0x69cc80: b.eq            #0x69ccfc
    // 0x69cc84: mov             x0, x4
    // 0x69cc88: r2 = Null
    //     0x69cc88: mov             x2, NULL
    // 0x69cc8c: r1 = Null
    //     0x69cc8c: mov             x1, NULL
    // 0x69cc90: r4 = LoadClassIdInstr(r0)
    //     0x69cc90: ldur            x4, [x0, #-1]
    //     0x69cc94: ubfx            x4, x4, #0xc, #0x14
    // 0x69cc98: sub             x4, x4, #0x80d
    // 0x69cc9c: cmp             x4, #1
    // 0x69cca0: b.ls            #0x69ccb8
    // 0x69cca4: r8 = BoxConstraints
    //     0x69cca4: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x69cca8: ldr             x8, [x8, #0x1d0]
    // 0x69ccac: r3 = Null
    //     0x69ccac: add             x3, PP, #0x37, lsl #12  ; [pp+0x37128] Null
    //     0x69ccb0: ldr             x3, [x3, #0x128]
    // 0x69ccb4: r0 = BoxConstraints()
    //     0x69ccb4: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x69ccb8: ldr             x16, [fp, #0x10]
    // 0x69ccbc: ldur            lr, [fp, #-8]
    // 0x69ccc0: stp             lr, x16, [SP, #-0x10]!
    // 0x69ccc4: r0 = _sizeForConstraints()
    //     0x69ccc4: bl              #0x632098  ; [package:flutter/src/rendering/image.dart] RenderImage::_sizeForConstraints
    // 0x69ccc8: add             SP, SP, #0x10
    // 0x69cccc: ldr             x1, [fp, #0x10]
    // 0x69ccd0: StoreField: r1->field_57 = r0
    //     0x69ccd0: stur            w0, [x1, #0x57]
    //     0x69ccd4: ldurb           w16, [x1, #-1]
    //     0x69ccd8: ldurb           w17, [x0, #-1]
    //     0x69ccdc: and             x16, x17, x16, lsr #2
    //     0x69cce0: tst             x16, HEAP, lsr #32
    //     0x69cce4: b.eq            #0x69ccec
    //     0x69cce8: bl              #0xd6826c
    // 0x69ccec: r0 = Null
    //     0x69ccec: mov             x0, NULL
    // 0x69ccf0: LeaveFrame
    //     0x69ccf0: mov             SP, fp
    //     0x69ccf4: ldp             fp, lr, [SP], #0x10
    // 0x69ccf8: ret
    //     0x69ccf8: ret             
    // 0x69ccfc: r0 = StateError()
    //     0x69ccfc: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x69cd00: mov             x1, x0
    // 0x69cd04: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x69cd04: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x69cd08: ldr             x0, [x0, #0x1e8]
    // 0x69cd0c: StoreField: r1->field_b = r0
    //     0x69cd0c: stur            w0, [x1, #0xb]
    // 0x69cd10: mov             x0, x1
    // 0x69cd14: r0 = Throw()
    //     0x69cd14: bl              #0xd67e38  ; ThrowStub
    // 0x69cd18: brk             #0
    // 0x69cd1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69cd1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69cd20: b               #0x69cc6c
  }
  set _ image=(/* No info */) {
    // ** addr: 0x6c1b28, size: 0x114
    // 0x6c1b28: EnterFrame
    //     0x6c1b28: stp             fp, lr, [SP, #-0x10]!
    //     0x6c1b2c: mov             fp, SP
    // 0x6c1b30: CheckStackOverflow
    //     0x6c1b30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c1b34: cmp             SP, x16
    //     0x6c1b38: b.ls            #0x6c1c34
    // 0x6c1b3c: ldr             x0, [fp, #0x18]
    // 0x6c1b40: LoadField: r1 = r0->field_67
    //     0x6c1b40: ldur            w1, [x0, #0x67]
    // 0x6c1b44: DecompressPointer r1
    //     0x6c1b44: add             x1, x1, HEAP, lsl #32
    // 0x6c1b48: ldr             x2, [fp, #0x10]
    // 0x6c1b4c: cmp             w2, w1
    // 0x6c1b50: b.ne            #0x6c1b64
    // 0x6c1b54: r0 = Null
    //     0x6c1b54: mov             x0, NULL
    // 0x6c1b58: LeaveFrame
    //     0x6c1b58: mov             SP, fp
    //     0x6c1b5c: ldp             fp, lr, [SP], #0x10
    // 0x6c1b60: ret
    //     0x6c1b60: ret             
    // 0x6c1b64: cmp             w2, NULL
    // 0x6c1b68: b.eq            #0x6c1ba8
    // 0x6c1b6c: cmp             w1, NULL
    // 0x6c1b70: b.eq            #0x6c1ba8
    // 0x6c1b74: LoadField: r3 = r1->field_7
    //     0x6c1b74: ldur            w3, [x1, #7]
    // 0x6c1b78: DecompressPointer r3
    //     0x6c1b78: add             x3, x3, HEAP, lsl #32
    // 0x6c1b7c: LoadField: r4 = r2->field_7
    //     0x6c1b7c: ldur            w4, [x2, #7]
    // 0x6c1b80: DecompressPointer r4
    //     0x6c1b80: add             x4, x4, HEAP, lsl #32
    // 0x6c1b84: cmp             w3, w4
    // 0x6c1b88: b.ne            #0x6c1ba8
    // 0x6c1b8c: SaveReg r2
    //     0x6c1b8c: str             x2, [SP, #-8]!
    // 0x6c1b90: r0 = dispose()
    //     0x6c1b90: bl              #0x6522a4  ; [dart:ui] Image::dispose
    // 0x6c1b94: add             SP, SP, #8
    // 0x6c1b98: r0 = Null
    //     0x6c1b98: mov             x0, NULL
    // 0x6c1b9c: LeaveFrame
    //     0x6c1b9c: mov             SP, fp
    //     0x6c1ba0: ldp             fp, lr, [SP], #0x10
    // 0x6c1ba4: ret
    //     0x6c1ba4: ret             
    // 0x6c1ba8: cmp             w1, NULL
    // 0x6c1bac: b.ne            #0x6c1bb8
    // 0x6c1bb0: mov             x1, x0
    // 0x6c1bb4: b               #0x6c1bc8
    // 0x6c1bb8: SaveReg r1
    //     0x6c1bb8: str             x1, [SP, #-8]!
    // 0x6c1bbc: r0 = dispose()
    //     0x6c1bbc: bl              #0x6522a4  ; [dart:ui] Image::dispose
    // 0x6c1bc0: add             SP, SP, #8
    // 0x6c1bc4: ldr             x1, [fp, #0x18]
    // 0x6c1bc8: ldr             x0, [fp, #0x10]
    // 0x6c1bcc: StoreField: r1->field_67 = r0
    //     0x6c1bcc: stur            w0, [x1, #0x67]
    //     0x6c1bd0: ldurb           w16, [x1, #-1]
    //     0x6c1bd4: ldurb           w17, [x0, #-1]
    //     0x6c1bd8: and             x16, x17, x16, lsr #2
    //     0x6c1bdc: tst             x16, HEAP, lsr #32
    //     0x6c1be0: b.eq            #0x6c1be8
    //     0x6c1be4: bl              #0xd6826c
    // 0x6c1be8: SaveReg r1
    //     0x6c1be8: str             x1, [SP, #-8]!
    // 0x6c1bec: r0 = markNeedsPaint()
    //     0x6c1bec: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c1bf0: add             SP, SP, #8
    // 0x6c1bf4: ldr             x0, [fp, #0x18]
    // 0x6c1bf8: LoadField: r1 = r0->field_6f
    //     0x6c1bf8: ldur            w1, [x0, #0x6f]
    // 0x6c1bfc: DecompressPointer r1
    //     0x6c1bfc: add             x1, x1, HEAP, lsl #32
    // 0x6c1c00: cmp             w1, NULL
    // 0x6c1c04: b.eq            #0x6c1c18
    // 0x6c1c08: LoadField: r1 = r0->field_73
    //     0x6c1c08: ldur            w1, [x0, #0x73]
    // 0x6c1c0c: DecompressPointer r1
    //     0x6c1c0c: add             x1, x1, HEAP, lsl #32
    // 0x6c1c10: cmp             w1, NULL
    // 0x6c1c14: b.ne            #0x6c1c24
    // 0x6c1c18: SaveReg r0
    //     0x6c1c18: str             x0, [SP, #-8]!
    // 0x6c1c1c: r0 = markNeedsLayout()
    //     0x6c1c1c: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c1c20: add             SP, SP, #8
    // 0x6c1c24: r0 = Null
    //     0x6c1c24: mov             x0, NULL
    // 0x6c1c28: LeaveFrame
    //     0x6c1c28: mov             SP, fp
    //     0x6c1c2c: ldp             fp, lr, [SP], #0x10
    // 0x6c1c30: ret
    //     0x6c1c30: ret             
    // 0x6c1c34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c1c34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c1c38: b               #0x6c1b3c
  }
  set _ invertColors=(/* No info */) {
    // ** addr: 0x6d35bc, size: 0x64
    // 0x6d35bc: EnterFrame
    //     0x6d35bc: stp             fp, lr, [SP, #-0x10]!
    //     0x6d35c0: mov             fp, SP
    // 0x6d35c4: CheckStackOverflow
    //     0x6d35c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d35c8: cmp             SP, x16
    //     0x6d35cc: b.ls            #0x6d3618
    // 0x6d35d0: ldr             x0, [fp, #0x18]
    // 0x6d35d4: LoadField: r1 = r0->field_a3
    //     0x6d35d4: ldur            w1, [x0, #0xa3]
    // 0x6d35d8: DecompressPointer r1
    //     0x6d35d8: add             x1, x1, HEAP, lsl #32
    // 0x6d35dc: ldr             x2, [fp, #0x10]
    // 0x6d35e0: cmp             w2, w1
    // 0x6d35e4: b.ne            #0x6d35f8
    // 0x6d35e8: r0 = Null
    //     0x6d35e8: mov             x0, NULL
    // 0x6d35ec: LeaveFrame
    //     0x6d35ec: mov             SP, fp
    //     0x6d35f0: ldp             fp, lr, [SP], #0x10
    // 0x6d35f4: ret
    //     0x6d35f4: ret             
    // 0x6d35f8: StoreField: r0->field_a3 = r2
    //     0x6d35f8: stur            w2, [x0, #0xa3]
    // 0x6d35fc: SaveReg r0
    //     0x6d35fc: str             x0, [SP, #-8]!
    // 0x6d3600: r0 = markNeedsPaint()
    //     0x6d3600: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6d3604: add             SP, SP, #8
    // 0x6d3608: r0 = Null
    //     0x6d3608: mov             x0, NULL
    // 0x6d360c: LeaveFrame
    //     0x6d360c: mov             SP, fp
    //     0x6d3610: ldp             fp, lr, [SP], #0x10
    // 0x6d3614: ret
    //     0x6d3614: ret             
    // 0x6d3618: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d3618: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d361c: b               #0x6d35d0
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0x6d3620, size: 0x80
    // 0x6d3620: EnterFrame
    //     0x6d3620: stp             fp, lr, [SP, #-0x10]!
    //     0x6d3624: mov             fp, SP
    // 0x6d3628: CheckStackOverflow
    //     0x6d3628: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d362c: cmp             SP, x16
    //     0x6d3630: b.ls            #0x6d3698
    // 0x6d3634: ldr             x1, [fp, #0x18]
    // 0x6d3638: LoadField: r0 = r1->field_ab
    //     0x6d3638: ldur            w0, [x1, #0xab]
    // 0x6d363c: DecompressPointer r0
    //     0x6d363c: add             x0, x0, HEAP, lsl #32
    // 0x6d3640: ldr             x2, [fp, #0x10]
    // 0x6d3644: cmp             w0, w2
    // 0x6d3648: b.ne            #0x6d365c
    // 0x6d364c: r0 = Null
    //     0x6d364c: mov             x0, NULL
    // 0x6d3650: LeaveFrame
    //     0x6d3650: mov             SP, fp
    //     0x6d3654: ldp             fp, lr, [SP], #0x10
    // 0x6d3658: ret
    //     0x6d3658: ret             
    // 0x6d365c: mov             x0, x2
    // 0x6d3660: StoreField: r1->field_ab = r0
    //     0x6d3660: stur            w0, [x1, #0xab]
    //     0x6d3664: ldurb           w16, [x1, #-1]
    //     0x6d3668: ldurb           w17, [x0, #-1]
    //     0x6d366c: and             x16, x17, x16, lsr #2
    //     0x6d3670: tst             x16, HEAP, lsr #32
    //     0x6d3674: b.eq            #0x6d367c
    //     0x6d3678: bl              #0xd6826c
    // 0x6d367c: SaveReg r1
    //     0x6d367c: str             x1, [SP, #-8]!
    // 0x6d3680: r0 = _markNeedResolution()
    //     0x6d3680: bl              #0x6d36a0  ; [package:flutter/src/rendering/image.dart] RenderImage::_markNeedResolution
    // 0x6d3684: add             SP, SP, #8
    // 0x6d3688: r0 = Null
    //     0x6d3688: mov             x0, NULL
    // 0x6d368c: LeaveFrame
    //     0x6d368c: mov             SP, fp
    //     0x6d3690: ldp             fp, lr, [SP], #0x10
    // 0x6d3694: ret
    //     0x6d3694: ret             
    // 0x6d3698: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d3698: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d369c: b               #0x6d3634
  }
  _ _markNeedResolution(/* No info */) {
    // ** addr: 0x6d36a0, size: 0x44
    // 0x6d36a0: EnterFrame
    //     0x6d36a0: stp             fp, lr, [SP, #-0x10]!
    //     0x6d36a4: mov             fp, SP
    // 0x6d36a8: CheckStackOverflow
    //     0x6d36a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d36ac: cmp             SP, x16
    //     0x6d36b0: b.ls            #0x6d36dc
    // 0x6d36b4: ldr             x0, [fp, #0x10]
    // 0x6d36b8: StoreField: r0->field_5f = rNULL
    //     0x6d36b8: stur            NULL, [x0, #0x5f]
    // 0x6d36bc: StoreField: r0->field_63 = rNULL
    //     0x6d36bc: stur            NULL, [x0, #0x63]
    // 0x6d36c0: SaveReg r0
    //     0x6d36c0: str             x0, [SP, #-8]!
    // 0x6d36c4: r0 = markNeedsPaint()
    //     0x6d36c4: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6d36c8: add             SP, SP, #8
    // 0x6d36cc: r0 = Null
    //     0x6d36cc: mov             x0, NULL
    // 0x6d36d0: LeaveFrame
    //     0x6d36d0: mov             SP, fp
    //     0x6d36d4: ldp             fp, lr, [SP], #0x10
    // 0x6d36d8: ret
    //     0x6d36d8: ret             
    // 0x6d36dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d36dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d36e0: b               #0x6d36b4
  }
  set _ alignment=(/* No info */) {
    // ** addr: 0x6d36e4, size: 0x78
    // 0x6d36e4: EnterFrame
    //     0x6d36e4: stp             fp, lr, [SP, #-0x10]!
    //     0x6d36e8: mov             fp, SP
    // 0x6d36ec: CheckStackOverflow
    //     0x6d36ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d36f0: cmp             SP, x16
    //     0x6d36f4: b.ls            #0x6d3754
    // 0x6d36f8: r16 = Instance_Alignment
    //     0x6d36f8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x6d36fc: ldr             x16, [x16, #0xc70]
    // 0x6d3700: r30 = Instance_Alignment
    //     0x6d3700: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x6d3704: ldr             lr, [lr, #0xc70]
    // 0x6d3708: stp             lr, x16, [SP, #-0x10]!
    // 0x6d370c: r0 = ==()
    //     0x6d370c: bl              #0xc9c720  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::==
    // 0x6d3710: add             SP, SP, #0x10
    // 0x6d3714: tbnz            w0, #4, #0x6d3728
    // 0x6d3718: r0 = Null
    //     0x6d3718: mov             x0, NULL
    // 0x6d371c: LeaveFrame
    //     0x6d371c: mov             SP, fp
    //     0x6d3720: ldp             fp, lr, [SP], #0x10
    // 0x6d3724: ret
    //     0x6d3724: ret             
    // 0x6d3728: ldr             x1, [fp, #0x18]
    // 0x6d372c: r0 = Instance_Alignment
    //     0x6d372c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x6d3730: ldr             x0, [x0, #0xc70]
    // 0x6d3734: StoreField: r1->field_97 = r0
    //     0x6d3734: stur            w0, [x1, #0x97]
    // 0x6d3738: SaveReg r1
    //     0x6d3738: str             x1, [SP, #-8]!
    // 0x6d373c: r0 = _markNeedResolution()
    //     0x6d373c: bl              #0x6d36a0  ; [package:flutter/src/rendering/image.dart] RenderImage::_markNeedResolution
    // 0x6d3740: add             SP, SP, #8
    // 0x6d3744: r0 = Null
    //     0x6d3744: mov             x0, NULL
    // 0x6d3748: LeaveFrame
    //     0x6d3748: mov             SP, fp
    //     0x6d374c: ldp             fp, lr, [SP], #0x10
    // 0x6d3750: ret
    //     0x6d3750: ret             
    // 0x6d3754: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d3754: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d3758: b               #0x6d36f8
  }
  set _ fit=(/* No info */) {
    // ** addr: 0x6d375c, size: 0x80
    // 0x6d375c: EnterFrame
    //     0x6d375c: stp             fp, lr, [SP, #-0x10]!
    //     0x6d3760: mov             fp, SP
    // 0x6d3764: CheckStackOverflow
    //     0x6d3764: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d3768: cmp             SP, x16
    //     0x6d376c: b.ls            #0x6d37d4
    // 0x6d3770: ldr             x1, [fp, #0x18]
    // 0x6d3774: LoadField: r0 = r1->field_93
    //     0x6d3774: ldur            w0, [x1, #0x93]
    // 0x6d3778: DecompressPointer r0
    //     0x6d3778: add             x0, x0, HEAP, lsl #32
    // 0x6d377c: ldr             x2, [fp, #0x10]
    // 0x6d3780: cmp             w2, w0
    // 0x6d3784: b.ne            #0x6d3798
    // 0x6d3788: r0 = Null
    //     0x6d3788: mov             x0, NULL
    // 0x6d378c: LeaveFrame
    //     0x6d378c: mov             SP, fp
    //     0x6d3790: ldp             fp, lr, [SP], #0x10
    // 0x6d3794: ret
    //     0x6d3794: ret             
    // 0x6d3798: mov             x0, x2
    // 0x6d379c: StoreField: r1->field_93 = r0
    //     0x6d379c: stur            w0, [x1, #0x93]
    //     0x6d37a0: ldurb           w16, [x1, #-1]
    //     0x6d37a4: ldurb           w17, [x0, #-1]
    //     0x6d37a8: and             x16, x17, x16, lsr #2
    //     0x6d37ac: tst             x16, HEAP, lsr #32
    //     0x6d37b0: b.eq            #0x6d37b8
    //     0x6d37b4: bl              #0xd6826c
    // 0x6d37b8: SaveReg r1
    //     0x6d37b8: str             x1, [SP, #-8]!
    // 0x6d37bc: r0 = markNeedsPaint()
    //     0x6d37bc: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6d37c0: add             SP, SP, #8
    // 0x6d37c4: r0 = Null
    //     0x6d37c4: mov             x0, NULL
    // 0x6d37c8: LeaveFrame
    //     0x6d37c8: mov             SP, fp
    //     0x6d37cc: ldp             fp, lr, [SP], #0x10
    // 0x6d37d0: ret
    //     0x6d37d0: ret             
    // 0x6d37d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d37d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d37d8: b               #0x6d3770
  }
  set _ opacity=(/* No info */) {
    // ** addr: 0x6d37dc, size: 0x11c
    // 0x6d37dc: EnterFrame
    //     0x6d37dc: stp             fp, lr, [SP, #-0x10]!
    //     0x6d37e0: mov             fp, SP
    // 0x6d37e4: AllocStack(0x8)
    //     0x6d37e4: sub             SP, SP, #8
    // 0x6d37e8: CheckStackOverflow
    //     0x6d37e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d37ec: cmp             SP, x16
    //     0x6d37f0: b.ls            #0x6d38f0
    // 0x6d37f4: ldr             x0, [fp, #0x18]
    // 0x6d37f8: LoadField: r1 = r0->field_87
    //     0x6d37f8: ldur            w1, [x0, #0x87]
    // 0x6d37fc: DecompressPointer r1
    //     0x6d37fc: add             x1, x1, HEAP, lsl #32
    // 0x6d3800: ldr             x2, [fp, #0x10]
    // 0x6d3804: stur            x1, [fp, #-8]
    // 0x6d3808: cmp             w2, w1
    // 0x6d380c: b.ne            #0x6d3820
    // 0x6d3810: r0 = Null
    //     0x6d3810: mov             x0, NULL
    // 0x6d3814: LeaveFrame
    //     0x6d3814: mov             SP, fp
    //     0x6d3818: ldp             fp, lr, [SP], #0x10
    // 0x6d381c: ret
    //     0x6d381c: ret             
    // 0x6d3820: LoadField: r3 = r0->field_f
    //     0x6d3820: ldur            w3, [x0, #0xf]
    // 0x6d3824: DecompressPointer r3
    //     0x6d3824: add             x3, x3, HEAP, lsl #32
    // 0x6d3828: cmp             w3, NULL
    // 0x6d382c: b.eq            #0x6d386c
    // 0x6d3830: cmp             w1, NULL
    // 0x6d3834: b.eq            #0x6d386c
    // 0x6d3838: r1 = 1
    //     0x6d3838: mov             x1, #1
    // 0x6d383c: r0 = AllocateContext()
    //     0x6d383c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6d3840: mov             x1, x0
    // 0x6d3844: ldr             x0, [fp, #0x18]
    // 0x6d3848: StoreField: r1->field_f = r0
    //     0x6d3848: stur            w0, [x1, #0xf]
    // 0x6d384c: mov             x2, x1
    // 0x6d3850: r1 = Function 'markNeedsPaint':.
    //     0x6d3850: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x6d3854: ldr             x1, [x1, #0xf60]
    // 0x6d3858: r0 = AllocateClosure()
    //     0x6d3858: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6d385c: ldur            x16, [fp, #-8]
    // 0x6d3860: stp             x0, x16, [SP, #-0x10]!
    // 0x6d3864: r0 = removeStatusListener()
    //     0x6d3864: bl              #0xc5dfb8  ; [package:flutter/src/animation/animations.dart] _ReverseAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalStatusListenersMixin::removeStatusListener
    // 0x6d3868: add             SP, SP, #0x10
    // 0x6d386c: ldr             x1, [fp, #0x18]
    // 0x6d3870: ldr             x0, [fp, #0x10]
    // 0x6d3874: StoreField: r1->field_87 = r0
    //     0x6d3874: stur            w0, [x1, #0x87]
    //     0x6d3878: ldurb           w16, [x1, #-1]
    //     0x6d387c: ldurb           w17, [x0, #-1]
    //     0x6d3880: and             x16, x17, x16, lsr #2
    //     0x6d3884: tst             x16, HEAP, lsr #32
    //     0x6d3888: b.eq            #0x6d3890
    //     0x6d388c: bl              #0xd6826c
    // 0x6d3890: LoadField: r0 = r1->field_f
    //     0x6d3890: ldur            w0, [x1, #0xf]
    // 0x6d3894: DecompressPointer r0
    //     0x6d3894: add             x0, x0, HEAP, lsl #32
    // 0x6d3898: cmp             w0, NULL
    // 0x6d389c: b.eq            #0x6d38e0
    // 0x6d38a0: ldr             x0, [fp, #0x10]
    // 0x6d38a4: cmp             w0, NULL
    // 0x6d38a8: b.eq            #0x6d38e0
    // 0x6d38ac: r1 = 1
    //     0x6d38ac: mov             x1, #1
    // 0x6d38b0: r0 = AllocateContext()
    //     0x6d38b0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6d38b4: mov             x1, x0
    // 0x6d38b8: ldr             x0, [fp, #0x18]
    // 0x6d38bc: StoreField: r1->field_f = r0
    //     0x6d38bc: stur            w0, [x1, #0xf]
    // 0x6d38c0: mov             x2, x1
    // 0x6d38c4: r1 = Function 'markNeedsPaint':.
    //     0x6d38c4: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x6d38c8: ldr             x1, [x1, #0xf60]
    // 0x6d38cc: r0 = AllocateClosure()
    //     0x6d38cc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6d38d0: ldr             x16, [fp, #0x10]
    // 0x6d38d4: stp             x0, x16, [SP, #-0x10]!
    // 0x6d38d8: r0 = addStatusListener()
    //     0x6d38d8: bl              #0xc52dc8  ; [package:flutter/src/animation/animations.dart] _ReverseAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0x6d38dc: add             SP, SP, #0x10
    // 0x6d38e0: r0 = Null
    //     0x6d38e0: mov             x0, NULL
    // 0x6d38e4: LeaveFrame
    //     0x6d38e4: mov             SP, fp
    //     0x6d38e8: ldp             fp, lr, [SP], #0x10
    // 0x6d38ec: ret
    //     0x6d38ec: ret             
    // 0x6d38f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d38f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d38f4: b               #0x6d37f4
  }
  set _ color=(/* No info */) {
    // ** addr: 0x6d38f8, size: 0xb0
    // 0x6d38f8: EnterFrame
    //     0x6d38f8: stp             fp, lr, [SP, #-0x10]!
    //     0x6d38fc: mov             fp, SP
    // 0x6d3900: CheckStackOverflow
    //     0x6d3900: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d3904: cmp             SP, x16
    //     0x6d3908: b.ls            #0x6d39a0
    // 0x6d390c: ldr             x1, [fp, #0x18]
    // 0x6d3910: LoadField: r0 = r1->field_83
    //     0x6d3910: ldur            w0, [x1, #0x83]
    // 0x6d3914: DecompressPointer r0
    //     0x6d3914: add             x0, x0, HEAP, lsl #32
    // 0x6d3918: ldr             x2, [fp, #0x10]
    // 0x6d391c: r3 = LoadClassIdInstr(r2)
    //     0x6d391c: ldur            x3, [x2, #-1]
    //     0x6d3920: ubfx            x3, x3, #0xc, #0x14
    // 0x6d3924: stp             x0, x2, [SP, #-0x10]!
    // 0x6d3928: mov             x0, x3
    // 0x6d392c: mov             lr, x0
    // 0x6d3930: ldr             lr, [x21, lr, lsl #3]
    // 0x6d3934: blr             lr
    // 0x6d3938: add             SP, SP, #0x10
    // 0x6d393c: tbnz            w0, #4, #0x6d3950
    // 0x6d3940: r0 = Null
    //     0x6d3940: mov             x0, NULL
    // 0x6d3944: LeaveFrame
    //     0x6d3944: mov             SP, fp
    //     0x6d3948: ldp             fp, lr, [SP], #0x10
    // 0x6d394c: ret
    //     0x6d394c: ret             
    // 0x6d3950: ldr             x1, [fp, #0x18]
    // 0x6d3954: ldr             x0, [fp, #0x10]
    // 0x6d3958: StoreField: r1->field_83 = r0
    //     0x6d3958: stur            w0, [x1, #0x83]
    //     0x6d395c: ldurb           w16, [x1, #-1]
    //     0x6d3960: ldurb           w17, [x0, #-1]
    //     0x6d3964: and             x16, x17, x16, lsr #2
    //     0x6d3968: tst             x16, HEAP, lsr #32
    //     0x6d396c: b.eq            #0x6d3974
    //     0x6d3970: bl              #0xd6826c
    // 0x6d3974: SaveReg r1
    //     0x6d3974: str             x1, [SP, #-8]!
    // 0x6d3978: r0 = _updateColorFilter()
    //     0x6d3978: bl              #0x6d39a8  ; [package:flutter/src/rendering/image.dart] RenderImage::_updateColorFilter
    // 0x6d397c: add             SP, SP, #8
    // 0x6d3980: ldr             x16, [fp, #0x18]
    // 0x6d3984: SaveReg r16
    //     0x6d3984: str             x16, [SP, #-8]!
    // 0x6d3988: r0 = markNeedsPaint()
    //     0x6d3988: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6d398c: add             SP, SP, #8
    // 0x6d3990: r0 = Null
    //     0x6d3990: mov             x0, NULL
    // 0x6d3994: LeaveFrame
    //     0x6d3994: mov             SP, fp
    //     0x6d3998: ldp             fp, lr, [SP], #0x10
    // 0x6d399c: ret
    //     0x6d399c: ret             
    // 0x6d39a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d39a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d39a4: b               #0x6d390c
  }
  _ _updateColorFilter(/* No info */) {
    // ** addr: 0x6d39a8, size: 0x7c
    // 0x6d39a8: EnterFrame
    //     0x6d39a8: stp             fp, lr, [SP, #-0x10]!
    //     0x6d39ac: mov             fp, SP
    // 0x6d39b0: AllocStack(0x8)
    //     0x6d39b0: sub             SP, SP, #8
    // 0x6d39b4: ldr             x0, [fp, #0x10]
    // 0x6d39b8: LoadField: r1 = r0->field_83
    //     0x6d39b8: ldur            w1, [x0, #0x83]
    // 0x6d39bc: DecompressPointer r1
    //     0x6d39bc: add             x1, x1, HEAP, lsl #32
    // 0x6d39c0: stur            x1, [fp, #-8]
    // 0x6d39c4: cmp             w1, NULL
    // 0x6d39c8: b.ne            #0x6d39d4
    // 0x6d39cc: StoreField: r0->field_7f = rNULL
    //     0x6d39cc: stur            NULL, [x0, #0x7f]
    // 0x6d39d0: b               #0x6d3a14
    // 0x6d39d4: r0 = ColorFilter()
    //     0x6d39d4: bl              #0x6d3a24  ; AllocateColorFilterStub -> ColorFilter (size=0x1c)
    // 0x6d39d8: ldur            x1, [fp, #-8]
    // 0x6d39dc: StoreField: r0->field_7 = r1
    //     0x6d39dc: stur            w1, [x0, #7]
    // 0x6d39e0: r1 = Instance_BlendMode
    //     0x6d39e0: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2ecf8] Obj!BlendMode@b67891
    //     0x6d39e4: ldr             x1, [x1, #0xcf8]
    // 0x6d39e8: StoreField: r0->field_b = r1
    //     0x6d39e8: stur            w1, [x0, #0xb]
    // 0x6d39ec: r1 = 1
    //     0x6d39ec: mov             x1, #1
    // 0x6d39f0: StoreField: r0->field_13 = r1
    //     0x6d39f0: stur            x1, [x0, #0x13]
    // 0x6d39f4: ldr             x1, [fp, #0x10]
    // 0x6d39f8: StoreField: r1->field_7f = r0
    //     0x6d39f8: stur            w0, [x1, #0x7f]
    //     0x6d39fc: ldurb           w16, [x1, #-1]
    //     0x6d3a00: ldurb           w17, [x0, #-1]
    //     0x6d3a04: and             x16, x17, x16, lsr #2
    //     0x6d3a08: tst             x16, HEAP, lsr #32
    //     0x6d3a0c: b.eq            #0x6d3a14
    //     0x6d3a10: bl              #0xd6826c
    // 0x6d3a14: r0 = Null
    //     0x6d3a14: mov             x0, NULL
    // 0x6d3a18: LeaveFrame
    //     0x6d3a18: mov             SP, fp
    //     0x6d3a1c: ldp             fp, lr, [SP], #0x10
    // 0x6d3a20: ret
    //     0x6d3a20: ret             
  }
  set _ scale=(/* No info */) {
    // ** addr: 0x6d3a30, size: 0x64
    // 0x6d3a30: EnterFrame
    //     0x6d3a30: stp             fp, lr, [SP, #-0x10]!
    //     0x6d3a34: mov             fp, SP
    // 0x6d3a38: CheckStackOverflow
    //     0x6d3a38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d3a3c: cmp             SP, x16
    //     0x6d3a40: b.ls            #0x6d3a8c
    // 0x6d3a44: ldr             x0, [fp, #0x18]
    // 0x6d3a48: LoadField: d0 = r0->field_77
    //     0x6d3a48: ldur            d0, [x0, #0x77]
    // 0x6d3a4c: ldr             d1, [fp, #0x10]
    // 0x6d3a50: fcmp            d1, d0
    // 0x6d3a54: b.vs            #0x6d3a6c
    // 0x6d3a58: b.ne            #0x6d3a6c
    // 0x6d3a5c: r0 = Null
    //     0x6d3a5c: mov             x0, NULL
    // 0x6d3a60: LeaveFrame
    //     0x6d3a60: mov             SP, fp
    //     0x6d3a64: ldp             fp, lr, [SP], #0x10
    // 0x6d3a68: ret
    //     0x6d3a68: ret             
    // 0x6d3a6c: StoreField: r0->field_77 = d1
    //     0x6d3a6c: stur            d1, [x0, #0x77]
    // 0x6d3a70: SaveReg r0
    //     0x6d3a70: str             x0, [SP, #-8]!
    // 0x6d3a74: r0 = markNeedsLayout()
    //     0x6d3a74: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6d3a78: add             SP, SP, #8
    // 0x6d3a7c: r0 = Null
    //     0x6d3a7c: mov             x0, NULL
    // 0x6d3a80: LeaveFrame
    //     0x6d3a80: mov             SP, fp
    //     0x6d3a84: ldp             fp, lr, [SP], #0x10
    // 0x6d3a88: ret
    //     0x6d3a88: ret             
    // 0x6d3a8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d3a8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d3a90: b               #0x6d3a44
  }
  set _ height=(/* No info */) {
    // ** addr: 0x6d3a94, size: 0xa0
    // 0x6d3a94: EnterFrame
    //     0x6d3a94: stp             fp, lr, [SP, #-0x10]!
    //     0x6d3a98: mov             fp, SP
    // 0x6d3a9c: CheckStackOverflow
    //     0x6d3a9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d3aa0: cmp             SP, x16
    //     0x6d3aa4: b.ls            #0x6d3b2c
    // 0x6d3aa8: ldr             x1, [fp, #0x18]
    // 0x6d3aac: LoadField: r0 = r1->field_73
    //     0x6d3aac: ldur            w0, [x1, #0x73]
    // 0x6d3ab0: DecompressPointer r0
    //     0x6d3ab0: add             x0, x0, HEAP, lsl #32
    // 0x6d3ab4: ldr             x2, [fp, #0x10]
    // 0x6d3ab8: r3 = LoadClassIdInstr(r2)
    //     0x6d3ab8: ldur            x3, [x2, #-1]
    //     0x6d3abc: ubfx            x3, x3, #0xc, #0x14
    // 0x6d3ac0: stp             x0, x2, [SP, #-0x10]!
    // 0x6d3ac4: mov             x0, x3
    // 0x6d3ac8: mov             lr, x0
    // 0x6d3acc: ldr             lr, [x21, lr, lsl #3]
    // 0x6d3ad0: blr             lr
    // 0x6d3ad4: add             SP, SP, #0x10
    // 0x6d3ad8: tbnz            w0, #4, #0x6d3aec
    // 0x6d3adc: r0 = Null
    //     0x6d3adc: mov             x0, NULL
    // 0x6d3ae0: LeaveFrame
    //     0x6d3ae0: mov             SP, fp
    //     0x6d3ae4: ldp             fp, lr, [SP], #0x10
    // 0x6d3ae8: ret
    //     0x6d3ae8: ret             
    // 0x6d3aec: ldr             x1, [fp, #0x18]
    // 0x6d3af0: ldr             x0, [fp, #0x10]
    // 0x6d3af4: StoreField: r1->field_73 = r0
    //     0x6d3af4: stur            w0, [x1, #0x73]
    //     0x6d3af8: ldurb           w16, [x1, #-1]
    //     0x6d3afc: ldurb           w17, [x0, #-1]
    //     0x6d3b00: and             x16, x17, x16, lsr #2
    //     0x6d3b04: tst             x16, HEAP, lsr #32
    //     0x6d3b08: b.eq            #0x6d3b10
    //     0x6d3b0c: bl              #0xd6826c
    // 0x6d3b10: SaveReg r1
    //     0x6d3b10: str             x1, [SP, #-8]!
    // 0x6d3b14: r0 = markNeedsLayout()
    //     0x6d3b14: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6d3b18: add             SP, SP, #8
    // 0x6d3b1c: r0 = Null
    //     0x6d3b1c: mov             x0, NULL
    // 0x6d3b20: LeaveFrame
    //     0x6d3b20: mov             SP, fp
    //     0x6d3b24: ldp             fp, lr, [SP], #0x10
    // 0x6d3b28: ret
    //     0x6d3b28: ret             
    // 0x6d3b2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d3b2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d3b30: b               #0x6d3aa8
  }
  set _ width=(/* No info */) {
    // ** addr: 0x6d3b34, size: 0xa0
    // 0x6d3b34: EnterFrame
    //     0x6d3b34: stp             fp, lr, [SP, #-0x10]!
    //     0x6d3b38: mov             fp, SP
    // 0x6d3b3c: CheckStackOverflow
    //     0x6d3b3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d3b40: cmp             SP, x16
    //     0x6d3b44: b.ls            #0x6d3bcc
    // 0x6d3b48: ldr             x1, [fp, #0x18]
    // 0x6d3b4c: LoadField: r0 = r1->field_6f
    //     0x6d3b4c: ldur            w0, [x1, #0x6f]
    // 0x6d3b50: DecompressPointer r0
    //     0x6d3b50: add             x0, x0, HEAP, lsl #32
    // 0x6d3b54: ldr             x2, [fp, #0x10]
    // 0x6d3b58: r3 = LoadClassIdInstr(r2)
    //     0x6d3b58: ldur            x3, [x2, #-1]
    //     0x6d3b5c: ubfx            x3, x3, #0xc, #0x14
    // 0x6d3b60: stp             x0, x2, [SP, #-0x10]!
    // 0x6d3b64: mov             x0, x3
    // 0x6d3b68: mov             lr, x0
    // 0x6d3b6c: ldr             lr, [x21, lr, lsl #3]
    // 0x6d3b70: blr             lr
    // 0x6d3b74: add             SP, SP, #0x10
    // 0x6d3b78: tbnz            w0, #4, #0x6d3b8c
    // 0x6d3b7c: r0 = Null
    //     0x6d3b7c: mov             x0, NULL
    // 0x6d3b80: LeaveFrame
    //     0x6d3b80: mov             SP, fp
    //     0x6d3b84: ldp             fp, lr, [SP], #0x10
    // 0x6d3b88: ret
    //     0x6d3b88: ret             
    // 0x6d3b8c: ldr             x1, [fp, #0x18]
    // 0x6d3b90: ldr             x0, [fp, #0x10]
    // 0x6d3b94: StoreField: r1->field_6f = r0
    //     0x6d3b94: stur            w0, [x1, #0x6f]
    //     0x6d3b98: ldurb           w16, [x1, #-1]
    //     0x6d3b9c: ldurb           w17, [x0, #-1]
    //     0x6d3ba0: and             x16, x17, x16, lsr #2
    //     0x6d3ba4: tst             x16, HEAP, lsr #32
    //     0x6d3ba8: b.eq            #0x6d3bb0
    //     0x6d3bac: bl              #0xd6826c
    // 0x6d3bb0: SaveReg r1
    //     0x6d3bb0: str             x1, [SP, #-8]!
    // 0x6d3bb4: r0 = markNeedsLayout()
    //     0x6d3bb4: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6d3bb8: add             SP, SP, #8
    // 0x6d3bbc: r0 = Null
    //     0x6d3bbc: mov             x0, NULL
    // 0x6d3bc0: LeaveFrame
    //     0x6d3bc0: mov             SP, fp
    //     0x6d3bc4: ldp             fp, lr, [SP], #0x10
    // 0x6d3bc8: ret
    //     0x6d3bc8: ret             
    // 0x6d3bcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d3bcc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d3bd0: b               #0x6d3b48
  }
  _ RenderImage(/* No info */) {
    // ** addr: 0x6f0350, size: 0x18c
    // 0x6f0350: EnterFrame
    //     0x6f0350: stp             fp, lr, [SP, #-0x10]!
    //     0x6f0354: mov             fp, SP
    // 0x6f0358: r4 = Instance_Alignment
    //     0x6f0358: add             x4, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x6f035c: ldr             x4, [x4, #0xc70]
    // 0x6f0360: r3 = Instance_ImageRepeat
    //     0x6f0360: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1c540] Obj!ImageRepeat@b64dd1
    //     0x6f0364: ldr             x3, [x3, #0x540]
    // 0x6f0368: r2 = false
    //     0x6f0368: add             x2, NULL, #0x30  ; false
    // 0x6f036c: r1 = Instance_FilterQuality
    //     0x6f036c: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c548] Obj!FilterQuality@b67811
    //     0x6f0370: ldr             x1, [x1, #0x548]
    // 0x6f0374: CheckStackOverflow
    //     0x6f0374: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f0378: cmp             SP, x16
    //     0x6f037c: b.ls            #0x6f04d4
    // 0x6f0380: ldr             x0, [fp, #0x50]
    // 0x6f0384: ldr             x5, [fp, #0x60]
    // 0x6f0388: StoreField: r5->field_6b = r0
    //     0x6f0388: stur            w0, [x5, #0x6b]
    //     0x6f038c: ldurb           w16, [x5, #-1]
    //     0x6f0390: ldurb           w17, [x0, #-1]
    //     0x6f0394: and             x16, x17, x16, lsr #2
    //     0x6f0398: tst             x16, HEAP, lsr #32
    //     0x6f039c: b.eq            #0x6f03a4
    //     0x6f03a0: bl              #0xd682ec
    // 0x6f03a4: ldr             x0, [fp, #0x38]
    // 0x6f03a8: StoreField: r5->field_67 = r0
    //     0x6f03a8: stur            w0, [x5, #0x67]
    //     0x6f03ac: ldurb           w16, [x5, #-1]
    //     0x6f03b0: ldurb           w17, [x0, #-1]
    //     0x6f03b4: and             x16, x17, x16, lsr #2
    //     0x6f03b8: tst             x16, HEAP, lsr #32
    //     0x6f03bc: b.eq            #0x6f03c4
    //     0x6f03c0: bl              #0xd682ec
    // 0x6f03c4: ldr             x0, [fp, #0x10]
    // 0x6f03c8: StoreField: r5->field_6f = r0
    //     0x6f03c8: stur            w0, [x5, #0x6f]
    //     0x6f03cc: ldurb           w16, [x5, #-1]
    //     0x6f03d0: ldurb           w17, [x0, #-1]
    //     0x6f03d4: and             x16, x17, x16, lsr #2
    //     0x6f03d8: tst             x16, HEAP, lsr #32
    //     0x6f03dc: b.eq            #0x6f03e4
    //     0x6f03e0: bl              #0xd682ec
    // 0x6f03e4: ldr             x0, [fp, #0x40]
    // 0x6f03e8: StoreField: r5->field_73 = r0
    //     0x6f03e8: stur            w0, [x5, #0x73]
    //     0x6f03ec: ldurb           w16, [x5, #-1]
    //     0x6f03f0: ldurb           w17, [x0, #-1]
    //     0x6f03f4: and             x16, x17, x16, lsr #2
    //     0x6f03f8: tst             x16, HEAP, lsr #32
    //     0x6f03fc: b.eq            #0x6f0404
    //     0x6f0400: bl              #0xd682ec
    // 0x6f0404: ldr             d0, [fp, #0x20]
    // 0x6f0408: StoreField: r5->field_77 = d0
    //     0x6f0408: stur            d0, [x5, #0x77]
    // 0x6f040c: ldr             x0, [fp, #0x58]
    // 0x6f0410: StoreField: r5->field_83 = r0
    //     0x6f0410: stur            w0, [x5, #0x83]
    //     0x6f0414: ldurb           w16, [x5, #-1]
    //     0x6f0418: ldurb           w17, [x0, #-1]
    //     0x6f041c: and             x16, x17, x16, lsr #2
    //     0x6f0420: tst             x16, HEAP, lsr #32
    //     0x6f0424: b.eq            #0x6f042c
    //     0x6f0428: bl              #0xd682ec
    // 0x6f042c: ldr             x0, [fp, #0x28]
    // 0x6f0430: StoreField: r5->field_87 = r0
    //     0x6f0430: stur            w0, [x5, #0x87]
    //     0x6f0434: ldurb           w16, [x5, #-1]
    //     0x6f0438: ldurb           w17, [x0, #-1]
    //     0x6f043c: and             x16, x17, x16, lsr #2
    //     0x6f0440: tst             x16, HEAP, lsr #32
    //     0x6f0444: b.eq            #0x6f044c
    //     0x6f0448: bl              #0xd682ec
    // 0x6f044c: ldr             x0, [fp, #0x48]
    // 0x6f0450: StoreField: r5->field_93 = r0
    //     0x6f0450: stur            w0, [x5, #0x93]
    //     0x6f0454: ldurb           w16, [x5, #-1]
    //     0x6f0458: ldurb           w17, [x0, #-1]
    //     0x6f045c: and             x16, x17, x16, lsr #2
    //     0x6f0460: tst             x16, HEAP, lsr #32
    //     0x6f0464: b.eq            #0x6f046c
    //     0x6f0468: bl              #0xd682ec
    // 0x6f046c: StoreField: r5->field_97 = r4
    //     0x6f046c: stur            w4, [x5, #0x97]
    // 0x6f0470: StoreField: r5->field_9b = r3
    //     0x6f0470: stur            w3, [x5, #0x9b]
    // 0x6f0474: StoreField: r5->field_a7 = r2
    //     0x6f0474: stur            w2, [x5, #0xa7]
    // 0x6f0478: ldr             x0, [fp, #0x30]
    // 0x6f047c: StoreField: r5->field_a3 = r0
    //     0x6f047c: stur            w0, [x5, #0xa3]
    // 0x6f0480: ldr             x0, [fp, #0x18]
    // 0x6f0484: StoreField: r5->field_ab = r0
    //     0x6f0484: stur            w0, [x5, #0xab]
    //     0x6f0488: ldurb           w16, [x5, #-1]
    //     0x6f048c: ldurb           w17, [x0, #-1]
    //     0x6f0490: and             x16, x17, x16, lsr #2
    //     0x6f0494: tst             x16, HEAP, lsr #32
    //     0x6f0498: b.eq            #0x6f04a0
    //     0x6f049c: bl              #0xd682ec
    // 0x6f04a0: StoreField: r5->field_af = r2
    //     0x6f04a0: stur            w2, [x5, #0xaf]
    // 0x6f04a4: StoreField: r5->field_8b = r1
    //     0x6f04a4: stur            w1, [x5, #0x8b]
    // 0x6f04a8: SaveReg r5
    //     0x6f04a8: str             x5, [SP, #-8]!
    // 0x6f04ac: r0 = RenderObject()
    //     0x6f04ac: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6f04b0: add             SP, SP, #8
    // 0x6f04b4: ldr             x16, [fp, #0x60]
    // 0x6f04b8: SaveReg r16
    //     0x6f04b8: str             x16, [SP, #-8]!
    // 0x6f04bc: r0 = _updateColorFilter()
    //     0x6f04bc: bl              #0x6d39a8  ; [package:flutter/src/rendering/image.dart] RenderImage::_updateColorFilter
    // 0x6f04c0: add             SP, SP, #8
    // 0x6f04c4: r0 = Null
    //     0x6f04c4: mov             x0, NULL
    // 0x6f04c8: LeaveFrame
    //     0x6f04c8: mov             SP, fp
    //     0x6f04cc: ldp             fp, lr, [SP], #0x10
    // 0x6f04d0: ret
    //     0x6f04d0: ret             
    // 0x6f04d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f04d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f04d8: b               #0x6f0380
  }
  _ attach(/* No info */) {
    // ** addr: 0x9be990, size: 0xc4
    // 0x9be990: EnterFrame
    //     0x9be990: stp             fp, lr, [SP, #-0x10]!
    //     0x9be994: mov             fp, SP
    // 0x9be998: AllocStack(0x8)
    //     0x9be998: sub             SP, SP, #8
    // 0x9be99c: CheckStackOverflow
    //     0x9be99c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9be9a0: cmp             SP, x16
    //     0x9be9a4: b.ls            #0x9bea4c
    // 0x9be9a8: ldr             x0, [fp, #0x10]
    // 0x9be9ac: r2 = Null
    //     0x9be9ac: mov             x2, NULL
    // 0x9be9b0: r1 = Null
    //     0x9be9b0: mov             x1, NULL
    // 0x9be9b4: r4 = 59
    //     0x9be9b4: mov             x4, #0x3b
    // 0x9be9b8: branchIfSmi(r0, 0x9be9c4)
    //     0x9be9b8: tbz             w0, #0, #0x9be9c4
    // 0x9be9bc: r4 = LoadClassIdInstr(r0)
    //     0x9be9bc: ldur            x4, [x0, #-1]
    //     0x9be9c0: ubfx            x4, x4, #0xc, #0x14
    // 0x9be9c4: cmp             x4, #0x7e6
    // 0x9be9c8: b.eq            #0x9be9dc
    // 0x9be9cc: r8 = PipelineOwner
    //     0x9be9cc: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9be9d0: r3 = Null
    //     0x9be9d0: add             x3, PP, #0x37, lsl #12  ; [pp+0x37118] Null
    //     0x9be9d4: ldr             x3, [x3, #0x118]
    // 0x9be9d8: r0 = DefaultTypeTest()
    //     0x9be9d8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9be9dc: ldr             x16, [fp, #0x18]
    // 0x9be9e0: ldr             lr, [fp, #0x10]
    // 0x9be9e4: stp             lr, x16, [SP, #-0x10]!
    // 0x9be9e8: r0 = attach()
    //     0x9be9e8: bl              #0x9bf794  ; [package:flutter/src/rendering/object.dart] RenderObject::attach
    // 0x9be9ec: add             SP, SP, #0x10
    // 0x9be9f0: ldr             x0, [fp, #0x18]
    // 0x9be9f4: LoadField: r1 = r0->field_87
    //     0x9be9f4: ldur            w1, [x0, #0x87]
    // 0x9be9f8: DecompressPointer r1
    //     0x9be9f8: add             x1, x1, HEAP, lsl #32
    // 0x9be9fc: stur            x1, [fp, #-8]
    // 0x9bea00: cmp             w1, NULL
    // 0x9bea04: b.eq            #0x9bea3c
    // 0x9bea08: r1 = 1
    //     0x9bea08: mov             x1, #1
    // 0x9bea0c: r0 = AllocateContext()
    //     0x9bea0c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9bea10: mov             x1, x0
    // 0x9bea14: ldr             x0, [fp, #0x18]
    // 0x9bea18: StoreField: r1->field_f = r0
    //     0x9bea18: stur            w0, [x1, #0xf]
    // 0x9bea1c: mov             x2, x1
    // 0x9bea20: r1 = Function 'markNeedsPaint':.
    //     0x9bea20: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x9bea24: ldr             x1, [x1, #0xf60]
    // 0x9bea28: r0 = AllocateClosure()
    //     0x9bea28: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9bea2c: ldur            x16, [fp, #-8]
    // 0x9bea30: stp             x0, x16, [SP, #-0x10]!
    // 0x9bea34: r0 = addStatusListener()
    //     0x9bea34: bl              #0xc52dc8  ; [package:flutter/src/animation/animations.dart] _ReverseAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0x9bea38: add             SP, SP, #0x10
    // 0x9bea3c: r0 = Null
    //     0x9bea3c: mov             x0, NULL
    // 0x9bea40: LeaveFrame
    //     0x9bea40: mov             SP, fp
    //     0x9bea44: ldp             fp, lr, [SP], #0x10
    // 0x9bea48: ret
    //     0x9bea48: ret             
    // 0x9bea4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bea4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bea50: b               #0x9be9a8
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5ed00, size: 0x3c
    // 0xa5ed00: EnterFrame
    //     0xa5ed00: stp             fp, lr, [SP, #-0x10]!
    //     0xa5ed04: mov             fp, SP
    // 0xa5ed08: CheckStackOverflow
    //     0xa5ed08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5ed0c: cmp             SP, x16
    //     0xa5ed10: b.ls            #0xa5ed34
    // 0xa5ed14: ldr             x16, [fp, #0x18]
    // 0xa5ed18: ldr             lr, [fp, #0x10]
    // 0xa5ed1c: stp             lr, x16, [SP, #-0x10]!
    // 0xa5ed20: r0 = _sizeForConstraints()
    //     0xa5ed20: bl              #0x632098  ; [package:flutter/src/rendering/image.dart] RenderImage::_sizeForConstraints
    // 0xa5ed24: add             SP, SP, #0x10
    // 0xa5ed28: LeaveFrame
    //     0xa5ed28: mov             SP, fp
    //     0xa5ed2c: ldp             fp, lr, [SP], #0x10
    // 0xa5ed30: ret
    //     0xa5ed30: ret             
    // 0xa5ed34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5ed34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5ed38: b               #0xa5ed14
  }
  _ detach(/* No info */) {
    // ** addr: 0xa6a0e0, size: 0x8c
    // 0xa6a0e0: EnterFrame
    //     0xa6a0e0: stp             fp, lr, [SP, #-0x10]!
    //     0xa6a0e4: mov             fp, SP
    // 0xa6a0e8: AllocStack(0x8)
    //     0xa6a0e8: sub             SP, SP, #8
    // 0xa6a0ec: CheckStackOverflow
    //     0xa6a0ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6a0f0: cmp             SP, x16
    //     0xa6a0f4: b.ls            #0xa6a164
    // 0xa6a0f8: ldr             x0, [fp, #0x10]
    // 0xa6a0fc: LoadField: r1 = r0->field_87
    //     0xa6a0fc: ldur            w1, [x0, #0x87]
    // 0xa6a100: DecompressPointer r1
    //     0xa6a100: add             x1, x1, HEAP, lsl #32
    // 0xa6a104: stur            x1, [fp, #-8]
    // 0xa6a108: cmp             w1, NULL
    // 0xa6a10c: b.eq            #0xa6a144
    // 0xa6a110: r1 = 1
    //     0xa6a110: mov             x1, #1
    // 0xa6a114: r0 = AllocateContext()
    //     0xa6a114: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa6a118: mov             x1, x0
    // 0xa6a11c: ldr             x0, [fp, #0x10]
    // 0xa6a120: StoreField: r1->field_f = r0
    //     0xa6a120: stur            w0, [x1, #0xf]
    // 0xa6a124: mov             x2, x1
    // 0xa6a128: r1 = Function 'markNeedsPaint':.
    //     0xa6a128: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0xa6a12c: ldr             x1, [x1, #0xf60]
    // 0xa6a130: r0 = AllocateClosure()
    //     0xa6a130: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa6a134: ldur            x16, [fp, #-8]
    // 0xa6a138: stp             x0, x16, [SP, #-0x10]!
    // 0xa6a13c: r0 = removeStatusListener()
    //     0xa6a13c: bl              #0xc5dfb8  ; [package:flutter/src/animation/animations.dart] _ReverseAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalStatusListenersMixin::removeStatusListener
    // 0xa6a140: add             SP, SP, #0x10
    // 0xa6a144: ldr             x16, [fp, #0x10]
    // 0xa6a148: SaveReg r16
    //     0xa6a148: str             x16, [SP, #-8]!
    // 0xa6a14c: r0 = detach()
    //     0xa6a14c: bl              #0xa6ade0  ; [package:flutter/src/foundation/node.dart] AbstractNode::detach
    // 0xa6a150: add             SP, SP, #8
    // 0xa6a154: r0 = Null
    //     0xa6a154: mov             x0, NULL
    // 0xa6a158: LeaveFrame
    //     0xa6a158: mov             SP, fp
    //     0xa6a15c: ldp             fp, lr, [SP], #0x10
    // 0xa6a160: ret
    //     0xa6a160: ret             
    // 0xa6a164: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6a164: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6a168: b               #0xa6a0f8
  }
}

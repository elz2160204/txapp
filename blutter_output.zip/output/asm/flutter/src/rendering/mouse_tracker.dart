// lib: , url: package:flutter/src/rendering/mouse_tracker.dart

// class id: 1049409, size: 0x8
class :: {
}

// class id: 2024, size: 0x10, field offset: 0x8
class _MouseState extends Object {

  _ replaceAnnotations(/* No info */) {
    // ** addr: 0x50d918, size: 0x3c
    // 0x50d918: ldr             x1, [SP, #8]
    // 0x50d91c: LoadField: r2 = r1->field_7
    //     0x50d91c: ldur            w2, [x1, #7]
    // 0x50d920: DecompressPointer r2
    //     0x50d920: add             x2, x2, HEAP, lsl #32
    // 0x50d924: ldr             x0, [SP]
    // 0x50d928: StoreField: r1->field_7 = r0
    //     0x50d928: stur            w0, [x1, #7]
    //     0x50d92c: ldurb           w16, [x1, #-1]
    //     0x50d930: ldurb           w17, [x0, #-1]
    //     0x50d934: and             x16, x17, x16, lsr #2
    //     0x50d938: tst             x16, HEAP, lsr #32
    //     0x50d93c: b.eq            #0x50d94c
    //     0x50d940: str             lr, [SP, #-8]!
    //     0x50d944: bl              #0xd6826c
    //     0x50d948: ldr             lr, [SP], #8
    // 0x50d94c: mov             x0, x2
    // 0x50d950: ret
    //     0x50d950: ret             
  }
  _ replaceLatestEvent(/* No info */) {
    // ** addr: 0x50dc00, size: 0x3c
    // 0x50dc00: ldr             x1, [SP, #8]
    // 0x50dc04: LoadField: r2 = r1->field_b
    //     0x50dc04: ldur            w2, [x1, #0xb]
    // 0x50dc08: DecompressPointer r2
    //     0x50dc08: add             x2, x2, HEAP, lsl #32
    // 0x50dc0c: ldr             x0, [SP]
    // 0x50dc10: StoreField: r1->field_b = r0
    //     0x50dc10: stur            w0, [x1, #0xb]
    //     0x50dc14: ldurb           w16, [x1, #-1]
    //     0x50dc18: ldurb           w17, [x0, #-1]
    //     0x50dc1c: and             x16, x17, x16, lsr #2
    //     0x50dc20: tst             x16, HEAP, lsr #32
    //     0x50dc24: b.eq            #0x50dc34
    //     0x50dc28: str             lr, [SP, #-8]!
    //     0x50dc2c: bl              #0xd6826c
    //     0x50dc30: ldr             lr, [SP], #8
    // 0x50dc34: mov             x0, x2
    // 0x50dc38: ret
    //     0x50dc38: ret             
  }
  _ _MouseState(/* No info */) {
    // ** addr: 0x50dc3c, size: 0xdc
    // 0x50dc3c: EnterFrame
    //     0x50dc3c: stp             fp, lr, [SP, #-0x10]!
    //     0x50dc40: mov             fp, SP
    // 0x50dc44: AllocStack(0x10)
    //     0x50dc44: sub             SP, SP, #0x10
    // 0x50dc48: CheckStackOverflow
    //     0x50dc48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50dc4c: cmp             SP, x16
    //     0x50dc50: b.ls            #0x50dd10
    // 0x50dc54: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x50dc54: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x50dc58: ldr             x0, [x0, #0x598]
    //     0x50dc5c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x50dc60: cmp             w0, w16
    //     0x50dc64: b.ne            #0x50dc70
    //     0x50dc68: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x50dc6c: bl              #0xd67cdc
    // 0x50dc70: r1 = <MouseTrackerAnnotation, Matrix4>
    //     0x50dc70: ldr             x1, [PP, #0x3970]  ; [pp+0x3970] TypeArguments: <MouseTrackerAnnotation, Matrix4>
    // 0x50dc74: stur            x0, [fp, #-8]
    // 0x50dc78: r0 = _Map()
    //     0x50dc78: bl              #0x4b4914  ; Allocate_MapStub -> _Map<X0, X1> (size=-0x8)
    // 0x50dc7c: mov             x1, x0
    // 0x50dc80: ldur            x0, [fp, #-8]
    // 0x50dc84: stur            x1, [fp, #-0x10]
    // 0x50dc88: StoreField: r1->field_1b = r0
    //     0x50dc88: stur            w0, [x1, #0x1b]
    // 0x50dc8c: StoreField: r1->field_b = rZR
    //     0x50dc8c: stur            wzr, [x1, #0xb]
    // 0x50dc90: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x50dc90: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x50dc94: ldr             x0, [x0, #0x5a0]
    //     0x50dc98: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x50dc9c: cmp             w0, w16
    //     0x50dca0: b.ne            #0x50dcac
    //     0x50dca4: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x50dca8: bl              #0xd67cdc
    // 0x50dcac: mov             x1, x0
    // 0x50dcb0: ldur            x0, [fp, #-0x10]
    // 0x50dcb4: StoreField: r0->field_f = r1
    //     0x50dcb4: stur            w1, [x0, #0xf]
    // 0x50dcb8: StoreField: r0->field_13 = rZR
    //     0x50dcb8: stur            wzr, [x0, #0x13]
    // 0x50dcbc: StoreField: r0->field_17 = rZR
    //     0x50dcbc: stur            wzr, [x0, #0x17]
    // 0x50dcc0: ldr             x1, [fp, #0x18]
    // 0x50dcc4: StoreField: r1->field_7 = r0
    //     0x50dcc4: stur            w0, [x1, #7]
    //     0x50dcc8: ldurb           w16, [x1, #-1]
    //     0x50dccc: ldurb           w17, [x0, #-1]
    //     0x50dcd0: and             x16, x17, x16, lsr #2
    //     0x50dcd4: tst             x16, HEAP, lsr #32
    //     0x50dcd8: b.eq            #0x50dce0
    //     0x50dcdc: bl              #0xd6826c
    // 0x50dce0: ldr             x0, [fp, #0x10]
    // 0x50dce4: StoreField: r1->field_b = r0
    //     0x50dce4: stur            w0, [x1, #0xb]
    //     0x50dce8: ldurb           w16, [x1, #-1]
    //     0x50dcec: ldurb           w17, [x0, #-1]
    //     0x50dcf0: and             x16, x17, x16, lsr #2
    //     0x50dcf4: tst             x16, HEAP, lsr #32
    //     0x50dcf8: b.eq            #0x50dd00
    //     0x50dcfc: bl              #0xd6826c
    // 0x50dd00: r0 = Null
    //     0x50dd00: mov             x0, NULL
    // 0x50dd04: LeaveFrame
    //     0x50dd04: mov             SP, fp
    //     0x50dd08: ldp             fp, lr, [SP], #0x10
    // 0x50dd0c: ret
    //     0x50dd0c: ret             
    // 0x50dd10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50dd10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50dd14: b               #0x50dc54
  }
  get _ device(/* No info */) {
    // ** addr: 0x5cdd50, size: 0x54
    // 0x5cdd50: EnterFrame
    //     0x5cdd50: stp             fp, lr, [SP, #-0x10]!
    //     0x5cdd54: mov             fp, SP
    // 0x5cdd58: CheckStackOverflow
    //     0x5cdd58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5cdd5c: cmp             SP, x16
    //     0x5cdd60: b.ls            #0x5cdd9c
    // 0x5cdd64: ldr             x0, [fp, #0x10]
    // 0x5cdd68: LoadField: r1 = r0->field_b
    //     0x5cdd68: ldur            w1, [x0, #0xb]
    // 0x5cdd6c: DecompressPointer r1
    //     0x5cdd6c: add             x1, x1, HEAP, lsl #32
    // 0x5cdd70: r0 = LoadClassIdInstr(r1)
    //     0x5cdd70: ldur            x0, [x1, #-1]
    //     0x5cdd74: ubfx            x0, x0, #0xc, #0x14
    // 0x5cdd78: SaveReg r1
    //     0x5cdd78: str             x1, [SP, #-8]!
    // 0x5cdd7c: r0 = GDT[cid_x0 + 0x8864]()
    //     0x5cdd7c: mov             x17, #0x8864
    //     0x5cdd80: add             lr, x0, x17
    //     0x5cdd84: ldr             lr, [x21, lr, lsl #3]
    //     0x5cdd88: blr             lr
    // 0x5cdd8c: add             SP, SP, #8
    // 0x5cdd90: LeaveFrame
    //     0x5cdd90: mov             SP, fp
    //     0x5cdd94: ldp             fp, lr, [SP], #0x10
    // 0x5cdd98: ret
    //     0x5cdd98: ret             
    // 0x5cdd9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5cdd9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5cdda0: b               #0x5cdd64
  }
  _ toString(/* No info */) {
    // ** addr: 0xae580c, size: 0x158
    // 0xae580c: EnterFrame
    //     0xae580c: stp             fp, lr, [SP, #-0x10]!
    //     0xae5810: mov             fp, SP
    // 0xae5814: AllocStack(0x18)
    //     0xae5814: sub             SP, SP, #0x18
    // 0xae5818: CheckStackOverflow
    //     0xae5818: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae581c: cmp             SP, x16
    //     0xae5820: b.ls            #0xae595c
    // 0xae5824: r1 = Null
    //     0xae5824: mov             x1, NULL
    // 0xae5828: r2 = 4
    //     0xae5828: mov             x2, #4
    // 0xae582c: r0 = AllocateArray()
    //     0xae582c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae5830: stur            x0, [fp, #-8]
    // 0xae5834: r17 = "latestEvent: "
    //     0xae5834: ldr             x17, [PP, #0x7398]  ; [pp+0x7398] "latestEvent: "
    // 0xae5838: StoreField: r0->field_f = r17
    //     0xae5838: stur            w17, [x0, #0xf]
    // 0xae583c: ldr             x1, [fp, #0x10]
    // 0xae5840: LoadField: r2 = r1->field_b
    //     0xae5840: ldur            w2, [x1, #0xb]
    // 0xae5844: DecompressPointer r2
    //     0xae5844: add             x2, x2, HEAP, lsl #32
    // 0xae5848: SaveReg r2
    //     0xae5848: str             x2, [SP, #-8]!
    // 0xae584c: r0 = describeIdentity()
    //     0xae584c: bl              #0xa77c6c  ; [package:flutter/src/foundation/diagnostics.dart] ::describeIdentity
    // 0xae5850: add             SP, SP, #8
    // 0xae5854: ldur            x1, [fp, #-8]
    // 0xae5858: ArrayStore: r1[1] = r0  ; List_4
    //     0xae5858: add             x25, x1, #0x13
    //     0xae585c: str             w0, [x25]
    //     0xae5860: tbz             w0, #0, #0xae587c
    //     0xae5864: ldurb           w16, [x1, #-1]
    //     0xae5868: ldurb           w17, [x0, #-1]
    //     0xae586c: and             x16, x17, x16, lsr #2
    //     0xae5870: tst             x16, HEAP, lsr #32
    //     0xae5874: b.eq            #0xae587c
    //     0xae5878: bl              #0xd67e5c
    // 0xae587c: ldur            x16, [fp, #-8]
    // 0xae5880: SaveReg r16
    //     0xae5880: str             x16, [SP, #-8]!
    // 0xae5884: r0 = _interpolate()
    //     0xae5884: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae5888: add             SP, SP, #8
    // 0xae588c: r1 = Null
    //     0xae588c: mov             x1, NULL
    // 0xae5890: r2 = 6
    //     0xae5890: mov             x2, #6
    // 0xae5894: stur            x0, [fp, #-8]
    // 0xae5898: r0 = AllocateArray()
    //     0xae5898: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae589c: r17 = "annotations: [list of "
    //     0xae589c: ldr             x17, [PP, #0x73a0]  ; [pp+0x73a0] "annotations: [list of "
    // 0xae58a0: StoreField: r0->field_f = r17
    //     0xae58a0: stur            w17, [x0, #0xf]
    // 0xae58a4: ldr             x1, [fp, #0x10]
    // 0xae58a8: LoadField: r2 = r1->field_7
    //     0xae58a8: ldur            w2, [x1, #7]
    // 0xae58ac: DecompressPointer r2
    //     0xae58ac: add             x2, x2, HEAP, lsl #32
    // 0xae58b0: LoadField: r3 = r2->field_13
    //     0xae58b0: ldur            w3, [x2, #0x13]
    // 0xae58b4: DecompressPointer r3
    //     0xae58b4: add             x3, x3, HEAP, lsl #32
    // 0xae58b8: r4 = LoadInt32Instr(r3)
    //     0xae58b8: sbfx            x4, x3, #1, #0x1f
    // 0xae58bc: asr             x3, x4, #1
    // 0xae58c0: LoadField: r4 = r2->field_17
    //     0xae58c0: ldur            w4, [x2, #0x17]
    // 0xae58c4: DecompressPointer r4
    //     0xae58c4: add             x4, x4, HEAP, lsl #32
    // 0xae58c8: r2 = LoadInt32Instr(r4)
    //     0xae58c8: sbfx            x2, x4, #1, #0x1f
    // 0xae58cc: sub             x4, x3, x2
    // 0xae58d0: lsl             x2, x4, #1
    // 0xae58d4: StoreField: r0->field_13 = r2
    //     0xae58d4: stur            w2, [x0, #0x13]
    // 0xae58d8: r17 = "]"
    //     0xae58d8: ldr             x17, [PP, #0x1460]  ; [pp+0x1460] "]"
    // 0xae58dc: StoreField: r0->field_17 = r17
    //     0xae58dc: stur            w17, [x0, #0x17]
    // 0xae58e0: SaveReg r0
    //     0xae58e0: str             x0, [SP, #-8]!
    // 0xae58e4: r0 = _interpolate()
    //     0xae58e4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae58e8: add             SP, SP, #8
    // 0xae58ec: stur            x0, [fp, #-0x10]
    // 0xae58f0: ldr             x16, [fp, #0x10]
    // 0xae58f4: SaveReg r16
    //     0xae58f4: str             x16, [SP, #-8]!
    // 0xae58f8: r0 = describeIdentity()
    //     0xae58f8: bl              #0xa77c6c  ; [package:flutter/src/foundation/diagnostics.dart] ::describeIdentity
    // 0xae58fc: add             SP, SP, #8
    // 0xae5900: r1 = Null
    //     0xae5900: mov             x1, NULL
    // 0xae5904: r2 = 12
    //     0xae5904: mov             x2, #0xc
    // 0xae5908: stur            x0, [fp, #-0x18]
    // 0xae590c: r0 = AllocateArray()
    //     0xae590c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae5910: mov             x1, x0
    // 0xae5914: ldur            x0, [fp, #-0x18]
    // 0xae5918: StoreField: r1->field_f = r0
    //     0xae5918: stur            w0, [x1, #0xf]
    // 0xae591c: r17 = "("
    //     0xae591c: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xae5920: StoreField: r1->field_13 = r17
    //     0xae5920: stur            w17, [x1, #0x13]
    // 0xae5924: ldur            x0, [fp, #-8]
    // 0xae5928: StoreField: r1->field_17 = r0
    //     0xae5928: stur            w0, [x1, #0x17]
    // 0xae592c: r17 = ", "
    //     0xae592c: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae5930: StoreField: r1->field_1b = r17
    //     0xae5930: stur            w17, [x1, #0x1b]
    // 0xae5934: ldur            x0, [fp, #-0x10]
    // 0xae5938: StoreField: r1->field_1f = r0
    //     0xae5938: stur            w0, [x1, #0x1f]
    // 0xae593c: r17 = ")"
    //     0xae593c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae5940: StoreField: r1->field_23 = r17
    //     0xae5940: stur            w17, [x1, #0x23]
    // 0xae5944: SaveReg r1
    //     0xae5944: str             x1, [SP, #-8]!
    // 0xae5948: r0 = _interpolate()
    //     0xae5948: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae594c: add             SP, SP, #8
    // 0xae5950: LeaveFrame
    //     0xae5950: mov             SP, fp
    //     0xae5954: ldp             fp, lr, [SP], #0x10
    // 0xae5958: ret
    //     0xae5958: ret             
    // 0xae595c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae595c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae5960: b               #0xae5824
  }
}

// class id: 2706, size: 0x18, field offset: 0x8
//   const constructor, 
class _MouseTrackerUpdateDetails extends _DiagnosticableTree&Object&Diagnosticable {

  get _ device(/* No info */) {
    // ** addr: 0x50c98c, size: 0x60
    // 0x50c98c: EnterFrame
    //     0x50c98c: stp             fp, lr, [SP, #-0x10]!
    //     0x50c990: mov             fp, SP
    // 0x50c994: CheckStackOverflow
    //     0x50c994: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50c998: cmp             SP, x16
    //     0x50c99c: b.ls            #0x50c9e0
    // 0x50c9a0: ldr             x0, [fp, #0x10]
    // 0x50c9a4: LoadField: r1 = r0->field_f
    //     0x50c9a4: ldur            w1, [x0, #0xf]
    // 0x50c9a8: DecompressPointer r1
    //     0x50c9a8: add             x1, x1, HEAP, lsl #32
    // 0x50c9ac: cmp             w1, NULL
    // 0x50c9b0: b.eq            #0x50c9e8
    // 0x50c9b4: r0 = LoadClassIdInstr(r1)
    //     0x50c9b4: ldur            x0, [x1, #-1]
    //     0x50c9b8: ubfx            x0, x0, #0xc, #0x14
    // 0x50c9bc: SaveReg r1
    //     0x50c9bc: str             x1, [SP, #-8]!
    // 0x50c9c0: r0 = GDT[cid_x0 + 0x8864]()
    //     0x50c9c0: mov             x17, #0x8864
    //     0x50c9c4: add             lr, x0, x17
    //     0x50c9c8: ldr             lr, [x21, lr, lsl #3]
    //     0x50c9cc: blr             lr
    // 0x50c9d0: add             SP, SP, #8
    // 0x50c9d4: LeaveFrame
    //     0x50c9d4: mov             SP, fp
    //     0x50c9d8: ldp             fp, lr, [SP], #0x10
    // 0x50c9dc: ret
    //     0x50c9dc: ret             
    // 0x50c9e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50c9e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50c9e4: b               #0x50c9a0
    // 0x50c9e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x50c9e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4823, size: 0x2c, field offset: 0x24
class MouseTracker extends ChangeNotifier {

  _ updateWithEvent(/* No info */) {
    // ** addr: 0x50ba1c, size: 0x2a0
    // 0x50ba1c: EnterFrame
    //     0x50ba1c: stp             fp, lr, [SP, #-0x10]!
    //     0x50ba20: mov             fp, SP
    // 0x50ba24: AllocStack(0x10)
    //     0x50ba24: sub             SP, SP, #0x10
    // 0x50ba28: CheckStackOverflow
    //     0x50ba28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50ba2c: cmp             SP, x16
    //     0x50ba30: b.ls            #0x50bcb4
    // 0x50ba34: r1 = 5
    //     0x50ba34: mov             x1, #5
    // 0x50ba38: r0 = AllocateContext()
    //     0x50ba38: bl              #0xd68aa4  ; AllocateContextStub
    // 0x50ba3c: mov             x2, x0
    // 0x50ba40: ldr             x1, [fp, #0x20]
    // 0x50ba44: stur            x2, [fp, #-8]
    // 0x50ba48: StoreField: r2->field_f = r1
    //     0x50ba48: stur            w1, [x2, #0xf]
    // 0x50ba4c: ldr             x0, [fp, #0x18]
    // 0x50ba50: StoreField: r2->field_13 = r0
    //     0x50ba50: stur            w0, [x2, #0x13]
    // 0x50ba54: r3 = LoadClassIdInstr(r0)
    //     0x50ba54: ldur            x3, [x0, #-1]
    //     0x50ba58: ubfx            x3, x3, #0xc, #0x14
    // 0x50ba5c: SaveReg r0
    //     0x50ba5c: str             x0, [SP, #-8]!
    // 0x50ba60: mov             x0, x3
    // 0x50ba64: r0 = GDT[cid_x0 + -0xf60]()
    //     0x50ba64: sub             lr, x0, #0xf60
    //     0x50ba68: ldr             lr, [x21, lr, lsl #3]
    //     0x50ba6c: blr             lr
    // 0x50ba70: add             SP, SP, #8
    // 0x50ba74: r16 = Instance_PointerDeviceKind
    //     0x50ba74: ldr             x16, [PP, #0x3958]  ; [pp+0x3958] Obj!PointerDeviceKind@b67191
    // 0x50ba78: cmp             w0, w16
    // 0x50ba7c: b.eq            #0x50ba90
    // 0x50ba80: r0 = Null
    //     0x50ba80: mov             x0, NULL
    // 0x50ba84: LeaveFrame
    //     0x50ba84: mov             SP, fp
    //     0x50ba88: ldp             fp, lr, [SP], #0x10
    // 0x50ba8c: ret
    //     0x50ba8c: ret             
    // 0x50ba90: ldur            x3, [fp, #-8]
    // 0x50ba94: LoadField: r4 = r3->field_13
    //     0x50ba94: ldur            w4, [x3, #0x13]
    // 0x50ba98: DecompressPointer r4
    //     0x50ba98: add             x4, x4, HEAP, lsl #32
    // 0x50ba9c: mov             x0, x4
    // 0x50baa0: stur            x4, [fp, #-0x10]
    // 0x50baa4: r2 = Null
    //     0x50baa4: mov             x2, NULL
    // 0x50baa8: r1 = Null
    //     0x50baa8: mov             x1, NULL
    // 0x50baac: cmp             w0, NULL
    // 0x50bab0: b.eq            #0x50bad8
    // 0x50bab4: branchIfSmi(r0, 0x50bad8)
    //     0x50bab4: tbz             w0, #0, #0x50bad8
    // 0x50bab8: r3 = LoadClassIdInstr(r0)
    //     0x50bab8: ldur            x3, [x0, #-1]
    //     0x50babc: ubfx            x3, x3, #0xc, #0x14
    // 0x50bac0: sub             x3, x3, #0x900
    // 0x50bac4: cmp             x3, #4
    // 0x50bac8: b.ls            #0x50bae0
    // 0x50bacc: sub             x3, x3, #0x227
    // 0x50bad0: cmp             x3, #4
    // 0x50bad4: b.ls            #0x50bae0
    // 0x50bad8: r0 = false
    //     0x50bad8: add             x0, NULL, #0x30  ; false
    // 0x50badc: b               #0x50bae4
    // 0x50bae0: r0 = true
    //     0x50bae0: add             x0, NULL, #0x20  ; true
    // 0x50bae4: tbnz            w0, #4, #0x50baf8
    // 0x50bae8: r0 = Null
    //     0x50bae8: mov             x0, NULL
    // 0x50baec: LeaveFrame
    //     0x50baec: mov             SP, fp
    //     0x50baf0: ldp             fp, lr, [SP], #0x10
    // 0x50baf4: ret
    //     0x50baf4: ret             
    // 0x50baf8: ldur            x0, [fp, #-0x10]
    // 0x50bafc: r2 = Null
    //     0x50bafc: mov             x2, NULL
    // 0x50bb00: r1 = Null
    //     0x50bb00: mov             x1, NULL
    // 0x50bb04: cmp             w0, NULL
    // 0x50bb08: b.eq            #0x50bb28
    // 0x50bb0c: branchIfSmi(r0, 0x50bb28)
    //     0x50bb0c: tbz             w0, #0, #0x50bb28
    // 0x50bb10: r3 = LoadClassIdInstr(r0)
    //     0x50bb10: ldur            x3, [x0, #-1]
    //     0x50bb14: ubfx            x3, x3, #0xc, #0x14
    // 0x50bb18: cmp             x3, #0x912
    // 0x50bb1c: b.eq            #0x50bb30
    // 0x50bb20: cmp             x3, #0xb49
    // 0x50bb24: b.eq            #0x50bb30
    // 0x50bb28: r0 = false
    //     0x50bb28: add             x0, NULL, #0x30  ; false
    // 0x50bb2c: b               #0x50bb34
    // 0x50bb30: r0 = true
    //     0x50bb30: add             x0, NULL, #0x20  ; true
    // 0x50bb34: tbnz            w0, #4, #0x50bb54
    // 0x50bb38: r0 = HitTestResult()
    //     0x50bb38: bl              #0x50f360  ; AllocateHitTestResultStub -> HitTestResult (size=0x14)
    // 0x50bb3c: stur            x0, [fp, #-0x10]
    // 0x50bb40: SaveReg r0
    //     0x50bb40: str             x0, [SP, #-8]!
    // 0x50bb44: r0 = HitTestResult()
    //     0x50bb44: bl              #0x50ef3c  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::HitTestResult
    // 0x50bb48: add             SP, SP, #8
    // 0x50bb4c: ldur            x0, [fp, #-0x10]
    // 0x50bb50: b               #0x50bb70
    // 0x50bb54: ldr             x16, [fp, #0x10]
    // 0x50bb58: SaveReg r16
    //     0x50bb58: str             x16, [SP, #-8]!
    // 0x50bb5c: ldr             x0, [fp, #0x10]
    // 0x50bb60: ClosureCall
    //     0x50bb60: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x50bb64: ldur            x2, [x0, #0x1f]
    //     0x50bb68: blr             x2
    // 0x50bb6c: add             SP, SP, #8
    // 0x50bb70: ldr             x1, [fp, #0x20]
    // 0x50bb74: ldur            x2, [fp, #-8]
    // 0x50bb78: StoreField: r2->field_17 = r0
    //     0x50bb78: stur            w0, [x2, #0x17]
    //     0x50bb7c: tbz             w0, #0, #0x50bb98
    //     0x50bb80: ldurb           w16, [x2, #-1]
    //     0x50bb84: ldurb           w17, [x0, #-1]
    //     0x50bb88: and             x16, x17, x16, lsr #2
    //     0x50bb8c: tst             x16, HEAP, lsr #32
    //     0x50bb90: b.eq            #0x50bb98
    //     0x50bb94: bl              #0xd6828c
    // 0x50bb98: LoadField: r0 = r2->field_13
    //     0x50bb98: ldur            w0, [x2, #0x13]
    // 0x50bb9c: DecompressPointer r0
    //     0x50bb9c: add             x0, x0, HEAP, lsl #32
    // 0x50bba0: r3 = LoadClassIdInstr(r0)
    //     0x50bba0: ldur            x3, [x0, #-1]
    //     0x50bba4: ubfx            x3, x3, #0xc, #0x14
    // 0x50bba8: SaveReg r0
    //     0x50bba8: str             x0, [SP, #-8]!
    // 0x50bbac: mov             x0, x3
    // 0x50bbb0: r0 = GDT[cid_x0 + 0x8864]()
    //     0x50bbb0: mov             x17, #0x8864
    //     0x50bbb4: add             lr, x0, x17
    //     0x50bbb8: ldr             lr, [x21, lr, lsl #3]
    //     0x50bbbc: blr             lr
    // 0x50bbc0: add             SP, SP, #8
    // 0x50bbc4: mov             x2, x0
    // 0x50bbc8: r0 = BoxInt64Instr(r2)
    //     0x50bbc8: sbfiz           x0, x2, #1, #0x1f
    //     0x50bbcc: cmp             x2, x0, asr #1
    //     0x50bbd0: b.eq            #0x50bbdc
    //     0x50bbd4: bl              #0xd69bb8
    //     0x50bbd8: stur            x2, [x0, #7]
    // 0x50bbdc: mov             x1, x0
    // 0x50bbe0: ldur            x2, [fp, #-8]
    // 0x50bbe4: StoreField: r2->field_1b = r0
    //     0x50bbe4: stur            w0, [x2, #0x1b]
    //     0x50bbe8: tbz             w0, #0, #0x50bc04
    //     0x50bbec: ldurb           w16, [x2, #-1]
    //     0x50bbf0: ldurb           w17, [x0, #-1]
    //     0x50bbf4: and             x16, x17, x16, lsr #2
    //     0x50bbf8: tst             x16, HEAP, lsr #32
    //     0x50bbfc: b.eq            #0x50bc04
    //     0x50bc00: bl              #0xd6828c
    // 0x50bc04: ldr             x0, [fp, #0x20]
    // 0x50bc08: LoadField: r3 = r0->field_27
    //     0x50bc08: ldur            w3, [x0, #0x27]
    // 0x50bc0c: DecompressPointer r3
    //     0x50bc0c: add             x3, x3, HEAP, lsl #32
    // 0x50bc10: stur            x3, [fp, #-0x10]
    // 0x50bc14: stp             x1, x3, [SP, #-0x10]!
    // 0x50bc18: r0 = _getValueOrData()
    //     0x50bc18: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x50bc1c: add             SP, SP, #0x10
    // 0x50bc20: mov             x1, x0
    // 0x50bc24: ldur            x0, [fp, #-0x10]
    // 0x50bc28: LoadField: r2 = r0->field_f
    //     0x50bc28: ldur            w2, [x0, #0xf]
    // 0x50bc2c: DecompressPointer r2
    //     0x50bc2c: add             x2, x2, HEAP, lsl #32
    // 0x50bc30: cmp             w2, w1
    // 0x50bc34: b.ne            #0x50bc3c
    // 0x50bc38: r1 = Null
    //     0x50bc38: mov             x1, NULL
    // 0x50bc3c: ldur            x2, [fp, #-8]
    // 0x50bc40: mov             x0, x1
    // 0x50bc44: StoreField: r2->field_1f = r0
    //     0x50bc44: stur            w0, [x2, #0x1f]
    //     0x50bc48: ldurb           w16, [x2, #-1]
    //     0x50bc4c: ldurb           w17, [x0, #-1]
    //     0x50bc50: and             x16, x17, x16, lsr #2
    //     0x50bc54: tst             x16, HEAP, lsr #32
    //     0x50bc58: b.eq            #0x50bc60
    //     0x50bc5c: bl              #0xd6828c
    // 0x50bc60: LoadField: r0 = r2->field_13
    //     0x50bc60: ldur            w0, [x2, #0x13]
    // 0x50bc64: DecompressPointer r0
    //     0x50bc64: add             x0, x0, HEAP, lsl #32
    // 0x50bc68: stp             x0, x1, [SP, #-0x10]!
    // 0x50bc6c: r0 = _shouldMarkStateDirty()
    //     0x50bc6c: bl              #0x50bda8  ; [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_shouldMarkStateDirty
    // 0x50bc70: add             SP, SP, #0x10
    // 0x50bc74: tbz             w0, #4, #0x50bc88
    // 0x50bc78: r0 = Null
    //     0x50bc78: mov             x0, NULL
    // 0x50bc7c: LeaveFrame
    //     0x50bc7c: mov             SP, fp
    //     0x50bc80: ldp             fp, lr, [SP], #0x10
    // 0x50bc84: ret
    //     0x50bc84: ret             
    // 0x50bc88: ldur            x2, [fp, #-8]
    // 0x50bc8c: r1 = Function '<anonymous closure>':.
    //     0x50bc8c: ldr             x1, [PP, #0x3960]  ; [pp+0x3960] AnonymousClosure: (0x50bf48), in [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::updateWithEvent (0x50ba1c)
    // 0x50bc90: r0 = AllocateClosure()
    //     0x50bc90: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x50bc94: ldr             x16, [fp, #0x20]
    // 0x50bc98: stp             x0, x16, [SP, #-0x10]!
    // 0x50bc9c: r0 = _monitorMouseConnection()
    //     0x50bc9c: bl              #0x50bcbc  ; [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_monitorMouseConnection
    // 0x50bca0: add             SP, SP, #0x10
    // 0x50bca4: r0 = Null
    //     0x50bca4: mov             x0, NULL
    // 0x50bca8: LeaveFrame
    //     0x50bca8: mov             SP, fp
    //     0x50bcac: ldp             fp, lr, [SP], #0x10
    // 0x50bcb0: ret
    //     0x50bcb0: ret             
    // 0x50bcb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50bcb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50bcb8: b               #0x50ba34
  }
  _ _monitorMouseConnection(/* No info */) {
    // ** addr: 0x50bcbc, size: 0x9c
    // 0x50bcbc: EnterFrame
    //     0x50bcbc: stp             fp, lr, [SP, #-0x10]!
    //     0x50bcc0: mov             fp, SP
    // 0x50bcc4: AllocStack(0x8)
    //     0x50bcc4: sub             SP, SP, #8
    // 0x50bcc8: CheckStackOverflow
    //     0x50bcc8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50bccc: cmp             SP, x16
    //     0x50bcd0: b.ls            #0x50bd50
    // 0x50bcd4: ldr             x16, [fp, #0x18]
    // 0x50bcd8: SaveReg r16
    //     0x50bcd8: str             x16, [SP, #-8]!
    // 0x50bcdc: r0 = mouseIsConnected()
    //     0x50bcdc: bl              #0x50bd58  ; [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::mouseIsConnected
    // 0x50bce0: add             SP, SP, #8
    // 0x50bce4: mov             x1, x0
    // 0x50bce8: stur            x1, [fp, #-8]
    // 0x50bcec: ldr             x16, [fp, #0x10]
    // 0x50bcf0: SaveReg r16
    //     0x50bcf0: str             x16, [SP, #-8]!
    // 0x50bcf4: ldr             x0, [fp, #0x10]
    // 0x50bcf8: ClosureCall
    //     0x50bcf8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x50bcfc: ldur            x2, [x0, #0x1f]
    //     0x50bd00: blr             x2
    // 0x50bd04: add             SP, SP, #8
    // 0x50bd08: ldr             x0, [fp, #0x18]
    // 0x50bd0c: LoadField: r1 = r0->field_27
    //     0x50bd0c: ldur            w1, [x0, #0x27]
    // 0x50bd10: DecompressPointer r1
    //     0x50bd10: add             x1, x1, HEAP, lsl #32
    // 0x50bd14: SaveReg r1
    //     0x50bd14: str             x1, [SP, #-8]!
    // 0x50bd18: r0 = isNotEmpty()
    //     0x50bd18: bl              #0xc96084  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin::isNotEmpty
    // 0x50bd1c: add             SP, SP, #8
    // 0x50bd20: mov             x1, x0
    // 0x50bd24: ldur            x0, [fp, #-8]
    // 0x50bd28: cmp             w0, w1
    // 0x50bd2c: b.eq            #0x50bd40
    // 0x50bd30: ldr             x16, [fp, #0x18]
    // 0x50bd34: SaveReg r16
    //     0x50bd34: str             x16, [SP, #-8]!
    // 0x50bd38: r0 = notifyListeners()
    //     0x50bd38: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x50bd3c: add             SP, SP, #8
    // 0x50bd40: r0 = Null
    //     0x50bd40: mov             x0, NULL
    // 0x50bd44: LeaveFrame
    //     0x50bd44: mov             SP, fp
    //     0x50bd48: ldp             fp, lr, [SP], #0x10
    // 0x50bd4c: ret
    //     0x50bd4c: ret             
    // 0x50bd50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50bd50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50bd54: b               #0x50bcd4
  }
  get _ mouseIsConnected(/* No info */) {
    // ** addr: 0x50bd58, size: 0x50
    // 0x50bd58: EnterFrame
    //     0x50bd58: stp             fp, lr, [SP, #-0x10]!
    //     0x50bd5c: mov             fp, SP
    // 0x50bd60: ldr             x1, [fp, #0x10]
    // 0x50bd64: LoadField: r2 = r1->field_27
    //     0x50bd64: ldur            w2, [x1, #0x27]
    // 0x50bd68: DecompressPointer r2
    //     0x50bd68: add             x2, x2, HEAP, lsl #32
    // 0x50bd6c: LoadField: r1 = r2->field_13
    //     0x50bd6c: ldur            w1, [x2, #0x13]
    // 0x50bd70: DecompressPointer r1
    //     0x50bd70: add             x1, x1, HEAP, lsl #32
    // 0x50bd74: r3 = LoadInt32Instr(r1)
    //     0x50bd74: sbfx            x3, x1, #1, #0x1f
    // 0x50bd78: asr             x1, x3, #1
    // 0x50bd7c: LoadField: r3 = r2->field_17
    //     0x50bd7c: ldur            w3, [x2, #0x17]
    // 0x50bd80: DecompressPointer r3
    //     0x50bd80: add             x3, x3, HEAP, lsl #32
    // 0x50bd84: r2 = LoadInt32Instr(r3)
    //     0x50bd84: sbfx            x2, x3, #1, #0x1f
    // 0x50bd88: sub             x3, x1, x2
    // 0x50bd8c: cbnz            x3, #0x50bd98
    // 0x50bd90: r0 = false
    //     0x50bd90: add             x0, NULL, #0x30  ; false
    // 0x50bd94: b               #0x50bd9c
    // 0x50bd98: r0 = true
    //     0x50bd98: add             x0, NULL, #0x20  ; true
    // 0x50bd9c: LeaveFrame
    //     0x50bd9c: mov             SP, fp
    //     0x50bda0: ldp             fp, lr, [SP], #0x10
    // 0x50bda4: ret
    //     0x50bda4: ret             
  }
  static _ _shouldMarkStateDirty(/* No info */) {
    // ** addr: 0x50bda8, size: 0x1a0
    // 0x50bda8: EnterFrame
    //     0x50bda8: stp             fp, lr, [SP, #-0x10]!
    //     0x50bdac: mov             fp, SP
    // 0x50bdb0: AllocStack(0x8)
    //     0x50bdb0: sub             SP, SP, #8
    // 0x50bdb4: CheckStackOverflow
    //     0x50bdb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50bdb8: cmp             SP, x16
    //     0x50bdbc: b.ls            #0x50bf40
    // 0x50bdc0: ldr             x0, [fp, #0x18]
    // 0x50bdc4: cmp             w0, NULL
    // 0x50bdc8: b.ne            #0x50bddc
    // 0x50bdcc: r0 = true
    //     0x50bdcc: add             x0, NULL, #0x20  ; true
    // 0x50bdd0: LeaveFrame
    //     0x50bdd0: mov             SP, fp
    //     0x50bdd4: ldp             fp, lr, [SP], #0x10
    // 0x50bdd8: ret
    //     0x50bdd8: ret             
    // 0x50bddc: LoadField: r3 = r0->field_b
    //     0x50bddc: ldur            w3, [x0, #0xb]
    // 0x50bde0: DecompressPointer r3
    //     0x50bde0: add             x3, x3, HEAP, lsl #32
    // 0x50bde4: ldr             x0, [fp, #0x10]
    // 0x50bde8: stur            x3, [fp, #-8]
    // 0x50bdec: r2 = Null
    //     0x50bdec: mov             x2, NULL
    // 0x50bdf0: r1 = Null
    //     0x50bdf0: mov             x1, NULL
    // 0x50bdf4: cmp             w0, NULL
    // 0x50bdf8: b.eq            #0x50be20
    // 0x50bdfc: branchIfSmi(r0, 0x50be20)
    //     0x50bdfc: tbz             w0, #0, #0x50be20
    // 0x50be00: r3 = LoadClassIdInstr(r0)
    //     0x50be00: ldur            x3, [x0, #-1]
    //     0x50be04: ubfx            x3, x3, #0xc, #0x14
    // 0x50be08: sub             x3, x3, #0x900
    // 0x50be0c: cmp             x3, #4
    // 0x50be10: b.ls            #0x50be28
    // 0x50be14: sub             x3, x3, #0x227
    // 0x50be18: cmp             x3, #4
    // 0x50be1c: b.ls            #0x50be28
    // 0x50be20: r0 = false
    //     0x50be20: add             x0, NULL, #0x30  ; false
    // 0x50be24: b               #0x50be2c
    // 0x50be28: r0 = true
    //     0x50be28: add             x0, NULL, #0x20  ; true
    // 0x50be2c: tbnz            w0, #4, #0x50be40
    // 0x50be30: r0 = false
    //     0x50be30: add             x0, NULL, #0x30  ; false
    // 0x50be34: LeaveFrame
    //     0x50be34: mov             SP, fp
    //     0x50be38: ldp             fp, lr, [SP], #0x10
    // 0x50be3c: ret
    //     0x50be3c: ret             
    // 0x50be40: ldur            x0, [fp, #-8]
    // 0x50be44: r2 = Null
    //     0x50be44: mov             x2, NULL
    // 0x50be48: r1 = Null
    //     0x50be48: mov             x1, NULL
    // 0x50be4c: cmp             w0, NULL
    // 0x50be50: b.eq            #0x50be70
    // 0x50be54: branchIfSmi(r0, 0x50be70)
    //     0x50be54: tbz             w0, #0, #0x50be70
    // 0x50be58: r3 = LoadClassIdInstr(r0)
    //     0x50be58: ldur            x3, [x0, #-1]
    //     0x50be5c: ubfx            x3, x3, #0xc, #0x14
    // 0x50be60: cmp             x3, #0x914
    // 0x50be64: b.eq            #0x50be78
    // 0x50be68: cmp             x3, #0xb4b
    // 0x50be6c: b.eq            #0x50be78
    // 0x50be70: r0 = false
    //     0x50be70: add             x0, NULL, #0x30  ; false
    // 0x50be74: b               #0x50be7c
    // 0x50be78: r0 = true
    //     0x50be78: add             x0, NULL, #0x20  ; true
    // 0x50be7c: tbz             w0, #4, #0x50bec0
    // 0x50be80: ldr             x0, [fp, #0x10]
    // 0x50be84: r2 = Null
    //     0x50be84: mov             x2, NULL
    // 0x50be88: r1 = Null
    //     0x50be88: mov             x1, NULL
    // 0x50be8c: cmp             w0, NULL
    // 0x50be90: b.eq            #0x50beb0
    // 0x50be94: branchIfSmi(r0, 0x50beb0)
    //     0x50be94: tbz             w0, #0, #0x50beb0
    // 0x50be98: r3 = LoadClassIdInstr(r0)
    //     0x50be98: ldur            x3, [x0, #-1]
    //     0x50be9c: ubfx            x3, x3, #0xc, #0x14
    // 0x50bea0: cmp             x3, #0x912
    // 0x50bea4: b.eq            #0x50beb8
    // 0x50bea8: cmp             x3, #0xb49
    // 0x50beac: b.eq            #0x50beb8
    // 0x50beb0: r0 = false
    //     0x50beb0: add             x0, NULL, #0x30  ; false
    // 0x50beb4: b               #0x50bebc
    // 0x50beb8: r0 = true
    //     0x50beb8: add             x0, NULL, #0x20  ; true
    // 0x50bebc: tbnz            w0, #4, #0x50bec8
    // 0x50bec0: r0 = true
    //     0x50bec0: add             x0, NULL, #0x20  ; true
    // 0x50bec4: b               #0x50bf34
    // 0x50bec8: ldr             x1, [fp, #0x10]
    // 0x50becc: ldur            x0, [fp, #-8]
    // 0x50bed0: r2 = LoadClassIdInstr(r0)
    //     0x50bed0: ldur            x2, [x0, #-1]
    //     0x50bed4: ubfx            x2, x2, #0xc, #0x14
    // 0x50bed8: SaveReg r0
    //     0x50bed8: str             x0, [SP, #-8]!
    // 0x50bedc: mov             x0, x2
    // 0x50bee0: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x50bee0: sub             lr, x0, #0xfd9
    //     0x50bee4: ldr             lr, [x21, lr, lsl #3]
    //     0x50bee8: blr             lr
    // 0x50beec: add             SP, SP, #8
    // 0x50bef0: mov             x1, x0
    // 0x50bef4: ldr             x0, [fp, #0x10]
    // 0x50bef8: stur            x1, [fp, #-8]
    // 0x50befc: r2 = LoadClassIdInstr(r0)
    //     0x50befc: ldur            x2, [x0, #-1]
    //     0x50bf00: ubfx            x2, x2, #0xc, #0x14
    // 0x50bf04: SaveReg r0
    //     0x50bf04: str             x0, [SP, #-8]!
    // 0x50bf08: mov             x0, x2
    // 0x50bf0c: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x50bf0c: sub             lr, x0, #0xfd9
    //     0x50bf10: ldr             lr, [x21, lr, lsl #3]
    //     0x50bf14: blr             lr
    // 0x50bf18: add             SP, SP, #8
    // 0x50bf1c: ldur            x16, [fp, #-8]
    // 0x50bf20: stp             x0, x16, [SP, #-0x10]!
    // 0x50bf24: r0 = ==()
    //     0x50bf24: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0x50bf28: add             SP, SP, #0x10
    // 0x50bf2c: eor             x1, x0, #0x10
    // 0x50bf30: mov             x0, x1
    // 0x50bf34: LeaveFrame
    //     0x50bf34: mov             SP, fp
    //     0x50bf38: ldp             fp, lr, [SP], #0x10
    // 0x50bf3c: ret
    //     0x50bf3c: ret             
    // 0x50bf40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50bf40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50bf44: b               #0x50bdc0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x50bf48, size: 0x60
    // 0x50bf48: EnterFrame
    //     0x50bf48: stp             fp, lr, [SP, #-0x10]!
    //     0x50bf4c: mov             fp, SP
    // 0x50bf50: AllocStack(0x8)
    //     0x50bf50: sub             SP, SP, #8
    // 0x50bf54: SetupParameters()
    //     0x50bf54: ldr             x0, [fp, #0x10]
    //     0x50bf58: ldur            w2, [x0, #0x17]
    //     0x50bf5c: add             x2, x2, HEAP, lsl #32
    // 0x50bf60: CheckStackOverflow
    //     0x50bf60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50bf64: cmp             SP, x16
    //     0x50bf68: b.ls            #0x50bfa0
    // 0x50bf6c: LoadField: r0 = r2->field_f
    //     0x50bf6c: ldur            w0, [x2, #0xf]
    // 0x50bf70: DecompressPointer r0
    //     0x50bf70: add             x0, x0, HEAP, lsl #32
    // 0x50bf74: stur            x0, [fp, #-8]
    // 0x50bf78: r1 = Function '<anonymous closure>':.
    //     0x50bf78: ldr             x1, [PP, #0x3968]  ; [pp+0x3968] AnonymousClosure: (0x50bff0), in [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::updateWithEvent (0x50ba1c)
    // 0x50bf7c: r0 = AllocateClosure()
    //     0x50bf7c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x50bf80: ldur            x16, [fp, #-8]
    // 0x50bf84: stp             x0, x16, [SP, #-0x10]!
    // 0x50bf88: r0 = lockState()
    //     0x50bf88: bl              #0x50bfa8  ; [package:flutter/src/widgets/framework.dart] BuildOwner::lockState
    // 0x50bf8c: add             SP, SP, #0x10
    // 0x50bf90: r0 = Null
    //     0x50bf90: mov             x0, NULL
    // 0x50bf94: LeaveFrame
    //     0x50bf94: mov             SP, fp
    //     0x50bf98: ldp             fp, lr, [SP], #0x10
    // 0x50bf9c: ret
    //     0x50bf9c: ret             
    // 0x50bfa0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50bfa0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50bfa4: b               #0x50bf6c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x50bff0, size: 0x3c4
    // 0x50bff0: EnterFrame
    //     0x50bff0: stp             fp, lr, [SP, #-0x10]!
    //     0x50bff4: mov             fp, SP
    // 0x50bff8: AllocStack(0x30)
    //     0x50bff8: sub             SP, SP, #0x30
    // 0x50bffc: SetupParameters()
    //     0x50bffc: ldr             x0, [fp, #0x10]
    //     0x50c000: ldur            w3, [x0, #0x17]
    //     0x50c004: add             x3, x3, HEAP, lsl #32
    //     0x50c008: stur            x3, [fp, #-0x18]
    // 0x50c00c: CheckStackOverflow
    //     0x50c00c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50c010: cmp             SP, x16
    //     0x50c014: b.ls            #0x50c3a8
    // 0x50c018: LoadField: r4 = r3->field_1f
    //     0x50c018: ldur            w4, [x3, #0x1f]
    // 0x50c01c: DecompressPointer r4
    //     0x50c01c: add             x4, x4, HEAP, lsl #32
    // 0x50c020: stur            x4, [fp, #-0x10]
    // 0x50c024: cmp             w4, NULL
    // 0x50c028: b.ne            #0x50c0f8
    // 0x50c02c: LoadField: r5 = r3->field_13
    //     0x50c02c: ldur            w5, [x3, #0x13]
    // 0x50c030: DecompressPointer r5
    //     0x50c030: add             x5, x5, HEAP, lsl #32
    // 0x50c034: mov             x0, x5
    // 0x50c038: stur            x5, [fp, #-8]
    // 0x50c03c: r2 = Null
    //     0x50c03c: mov             x2, NULL
    // 0x50c040: r1 = Null
    //     0x50c040: mov             x1, NULL
    // 0x50c044: cmp             w0, NULL
    // 0x50c048: b.eq            #0x50c068
    // 0x50c04c: branchIfSmi(r0, 0x50c068)
    //     0x50c04c: tbz             w0, #0, #0x50c068
    // 0x50c050: r3 = LoadClassIdInstr(r0)
    //     0x50c050: ldur            x3, [x0, #-1]
    //     0x50c054: ubfx            x3, x3, #0xc, #0x14
    // 0x50c058: cmp             x3, #0x912
    // 0x50c05c: b.eq            #0x50c070
    // 0x50c060: cmp             x3, #0xb49
    // 0x50c064: b.eq            #0x50c070
    // 0x50c068: r0 = false
    //     0x50c068: add             x0, NULL, #0x30  ; false
    // 0x50c06c: b               #0x50c074
    // 0x50c070: r0 = true
    //     0x50c070: add             x0, NULL, #0x20  ; true
    // 0x50c074: tbnz            w0, #4, #0x50c088
    // 0x50c078: r0 = Null
    //     0x50c078: mov             x0, NULL
    // 0x50c07c: LeaveFrame
    //     0x50c07c: mov             SP, fp
    //     0x50c080: ldp             fp, lr, [SP], #0x10
    // 0x50c084: ret
    //     0x50c084: ret             
    // 0x50c088: ldur            x0, [fp, #-0x18]
    // 0x50c08c: LoadField: r1 = r0->field_f
    //     0x50c08c: ldur            w1, [x0, #0xf]
    // 0x50c090: DecompressPointer r1
    //     0x50c090: add             x1, x1, HEAP, lsl #32
    // 0x50c094: LoadField: r2 = r1->field_27
    //     0x50c094: ldur            w2, [x1, #0x27]
    // 0x50c098: DecompressPointer r2
    //     0x50c098: add             x2, x2, HEAP, lsl #32
    // 0x50c09c: stur            x2, [fp, #-0x28]
    // 0x50c0a0: LoadField: r1 = r0->field_1b
    //     0x50c0a0: ldur            w1, [x0, #0x1b]
    // 0x50c0a4: DecompressPointer r1
    //     0x50c0a4: add             x1, x1, HEAP, lsl #32
    // 0x50c0a8: stur            x1, [fp, #-0x20]
    // 0x50c0ac: r0 = _MouseState()
    //     0x50c0ac: bl              #0x50dd18  ; Allocate_MouseStateStub -> _MouseState (size=0x10)
    // 0x50c0b0: stur            x0, [fp, #-0x30]
    // 0x50c0b4: ldur            x16, [fp, #-8]
    // 0x50c0b8: stp             x16, x0, [SP, #-0x10]!
    // 0x50c0bc: r0 = _MouseState()
    //     0x50c0bc: bl              #0x50dc3c  ; [package:flutter/src/rendering/mouse_tracker.dart] _MouseState::_MouseState
    // 0x50c0c0: add             SP, SP, #0x10
    // 0x50c0c4: ldur            x16, [fp, #-0x28]
    // 0x50c0c8: ldur            lr, [fp, #-0x20]
    // 0x50c0cc: stp             lr, x16, [SP, #-0x10]!
    // 0x50c0d0: r0 = hash()
    //     0x50c0d0: bl              #0xc0483c  ; [package:collection/src/equality.dart] DefaultEquality::hash
    // 0x50c0d4: add             SP, SP, #0x10
    // 0x50c0d8: ldur            x16, [fp, #-0x28]
    // 0x50c0dc: ldur            lr, [fp, #-0x20]
    // 0x50c0e0: stp             lr, x16, [SP, #-0x10]!
    // 0x50c0e4: ldur            x16, [fp, #-0x30]
    // 0x50c0e8: stp             x0, x16, [SP, #-0x10]!
    // 0x50c0ec: r0 = _set()
    //     0x50c0ec: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x50c0f0: add             SP, SP, #0x20
    // 0x50c0f4: b               #0x50c1ac
    // 0x50c0f8: LoadField: r4 = r3->field_13
    //     0x50c0f8: ldur            w4, [x3, #0x13]
    // 0x50c0fc: DecompressPointer r4
    //     0x50c0fc: add             x4, x4, HEAP, lsl #32
    // 0x50c100: mov             x0, x4
    // 0x50c104: stur            x4, [fp, #-8]
    // 0x50c108: r2 = Null
    //     0x50c108: mov             x2, NULL
    // 0x50c10c: r1 = Null
    //     0x50c10c: mov             x1, NULL
    // 0x50c110: cmp             w0, NULL
    // 0x50c114: b.eq            #0x50c134
    // 0x50c118: branchIfSmi(r0, 0x50c134)
    //     0x50c118: tbz             w0, #0, #0x50c134
    // 0x50c11c: r3 = LoadClassIdInstr(r0)
    //     0x50c11c: ldur            x3, [x0, #-1]
    //     0x50c120: ubfx            x3, x3, #0xc, #0x14
    // 0x50c124: cmp             x3, #0x912
    // 0x50c128: b.eq            #0x50c13c
    // 0x50c12c: cmp             x3, #0xb49
    // 0x50c130: b.eq            #0x50c13c
    // 0x50c134: r0 = false
    //     0x50c134: add             x0, NULL, #0x30  ; false
    // 0x50c138: b               #0x50c140
    // 0x50c13c: r0 = true
    //     0x50c13c: add             x0, NULL, #0x20  ; true
    // 0x50c140: tbnz            w0, #4, #0x50c1ac
    // 0x50c144: ldur            x1, [fp, #-0x18]
    // 0x50c148: ldur            x0, [fp, #-8]
    // 0x50c14c: LoadField: r2 = r1->field_f
    //     0x50c14c: ldur            w2, [x1, #0xf]
    // 0x50c150: DecompressPointer r2
    //     0x50c150: add             x2, x2, HEAP, lsl #32
    // 0x50c154: LoadField: r3 = r2->field_27
    //     0x50c154: ldur            w3, [x2, #0x27]
    // 0x50c158: DecompressPointer r3
    //     0x50c158: add             x3, x3, HEAP, lsl #32
    // 0x50c15c: stur            x3, [fp, #-0x20]
    // 0x50c160: r2 = LoadClassIdInstr(r0)
    //     0x50c160: ldur            x2, [x0, #-1]
    //     0x50c164: ubfx            x2, x2, #0xc, #0x14
    // 0x50c168: SaveReg r0
    //     0x50c168: str             x0, [SP, #-8]!
    // 0x50c16c: mov             x0, x2
    // 0x50c170: r0 = GDT[cid_x0 + 0x8864]()
    //     0x50c170: mov             x17, #0x8864
    //     0x50c174: add             lr, x0, x17
    //     0x50c178: ldr             lr, [x21, lr, lsl #3]
    //     0x50c17c: blr             lr
    // 0x50c180: add             SP, SP, #8
    // 0x50c184: mov             x2, x0
    // 0x50c188: r0 = BoxInt64Instr(r2)
    //     0x50c188: sbfiz           x0, x2, #1, #0x1f
    //     0x50c18c: cmp             x2, x0, asr #1
    //     0x50c190: b.eq            #0x50c19c
    //     0x50c194: bl              #0xd69bb8
    //     0x50c198: stur            x2, [x0, #7]
    // 0x50c19c: ldur            x16, [fp, #-0x20]
    // 0x50c1a0: stp             x0, x16, [SP, #-0x10]!
    // 0x50c1a4: r0 = remove()
    //     0x50c1a4: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x50c1a8: add             SP, SP, #0x10
    // 0x50c1ac: ldur            x0, [fp, #-0x18]
    // 0x50c1b0: LoadField: r1 = r0->field_f
    //     0x50c1b0: ldur            w1, [x0, #0xf]
    // 0x50c1b4: DecompressPointer r1
    //     0x50c1b4: add             x1, x1, HEAP, lsl #32
    // 0x50c1b8: LoadField: r2 = r1->field_27
    //     0x50c1b8: ldur            w2, [x1, #0x27]
    // 0x50c1bc: DecompressPointer r2
    //     0x50c1bc: add             x2, x2, HEAP, lsl #32
    // 0x50c1c0: stur            x2, [fp, #-8]
    // 0x50c1c4: LoadField: r1 = r0->field_1b
    //     0x50c1c4: ldur            w1, [x0, #0x1b]
    // 0x50c1c8: DecompressPointer r1
    //     0x50c1c8: add             x1, x1, HEAP, lsl #32
    // 0x50c1cc: stp             x1, x2, [SP, #-0x10]!
    // 0x50c1d0: r0 = _getValueOrData()
    //     0x50c1d0: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x50c1d4: add             SP, SP, #0x10
    // 0x50c1d8: mov             x1, x0
    // 0x50c1dc: ldur            x0, [fp, #-8]
    // 0x50c1e0: LoadField: r2 = r0->field_f
    //     0x50c1e0: ldur            w2, [x0, #0xf]
    // 0x50c1e4: DecompressPointer r2
    //     0x50c1e4: add             x2, x2, HEAP, lsl #32
    // 0x50c1e8: cmp             w2, w1
    // 0x50c1ec: b.ne            #0x50c1f8
    // 0x50c1f0: r0 = Null
    //     0x50c1f0: mov             x0, NULL
    // 0x50c1f4: b               #0x50c1fc
    // 0x50c1f8: mov             x0, x1
    // 0x50c1fc: cmp             w0, NULL
    // 0x50c200: b.ne            #0x50c218
    // 0x50c204: ldur            x0, [fp, #-0x10]
    // 0x50c208: cmp             w0, NULL
    // 0x50c20c: b.eq            #0x50c3b0
    // 0x50c210: mov             x1, x0
    // 0x50c214: b               #0x50c21c
    // 0x50c218: mov             x1, x0
    // 0x50c21c: ldur            x0, [fp, #-0x18]
    // 0x50c220: stur            x1, [fp, #-8]
    // 0x50c224: LoadField: r2 = r0->field_13
    //     0x50c224: ldur            w2, [x0, #0x13]
    // 0x50c228: DecompressPointer r2
    //     0x50c228: add             x2, x2, HEAP, lsl #32
    // 0x50c22c: stp             x2, x1, [SP, #-0x10]!
    // 0x50c230: r0 = replaceLatestEvent()
    //     0x50c230: bl              #0x50dc00  ; [package:flutter/src/rendering/mouse_tracker.dart] _MouseState::replaceLatestEvent
    // 0x50c234: add             SP, SP, #0x10
    // 0x50c238: mov             x4, x0
    // 0x50c23c: ldur            x3, [fp, #-0x18]
    // 0x50c240: stur            x4, [fp, #-0x10]
    // 0x50c244: LoadField: r0 = r3->field_13
    //     0x50c244: ldur            w0, [x3, #0x13]
    // 0x50c248: DecompressPointer r0
    //     0x50c248: add             x0, x0, HEAP, lsl #32
    // 0x50c24c: r2 = Null
    //     0x50c24c: mov             x2, NULL
    // 0x50c250: r1 = Null
    //     0x50c250: mov             x1, NULL
    // 0x50c254: cmp             w0, NULL
    // 0x50c258: b.eq            #0x50c278
    // 0x50c25c: branchIfSmi(r0, 0x50c278)
    //     0x50c25c: tbz             w0, #0, #0x50c278
    // 0x50c260: r3 = LoadClassIdInstr(r0)
    //     0x50c260: ldur            x3, [x0, #-1]
    //     0x50c264: ubfx            x3, x3, #0xc, #0x14
    // 0x50c268: cmp             x3, #0x912
    // 0x50c26c: b.eq            #0x50c280
    // 0x50c270: cmp             x3, #0xb49
    // 0x50c274: b.eq            #0x50c280
    // 0x50c278: r0 = false
    //     0x50c278: add             x0, NULL, #0x30  ; false
    // 0x50c27c: b               #0x50c284
    // 0x50c280: r0 = true
    //     0x50c280: add             x0, NULL, #0x20  ; true
    // 0x50c284: tbnz            w0, #4, #0x50c2fc
    // 0x50c288: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x50c288: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x50c28c: ldr             x0, [x0, #0x598]
    //     0x50c290: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x50c294: cmp             w0, w16
    //     0x50c298: b.ne            #0x50c2a4
    //     0x50c29c: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x50c2a0: bl              #0xd67cdc
    // 0x50c2a4: r1 = <MouseTrackerAnnotation, Matrix4>
    //     0x50c2a4: ldr             x1, [PP, #0x3970]  ; [pp+0x3970] TypeArguments: <MouseTrackerAnnotation, Matrix4>
    // 0x50c2a8: stur            x0, [fp, #-0x20]
    // 0x50c2ac: r0 = _Map()
    //     0x50c2ac: bl              #0x4b4914  ; Allocate_MapStub -> _Map<X0, X1> (size=-0x8)
    // 0x50c2b0: mov             x1, x0
    // 0x50c2b4: ldur            x0, [fp, #-0x20]
    // 0x50c2b8: stur            x1, [fp, #-0x28]
    // 0x50c2bc: StoreField: r1->field_1b = r0
    //     0x50c2bc: stur            w0, [x1, #0x1b]
    // 0x50c2c0: StoreField: r1->field_b = rZR
    //     0x50c2c0: stur            wzr, [x1, #0xb]
    // 0x50c2c4: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x50c2c4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x50c2c8: ldr             x0, [x0, #0x5a0]
    //     0x50c2cc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x50c2d0: cmp             w0, w16
    //     0x50c2d4: b.ne            #0x50c2e0
    //     0x50c2d8: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x50c2dc: bl              #0xd67cdc
    // 0x50c2e0: mov             x1, x0
    // 0x50c2e4: ldur            x0, [fp, #-0x28]
    // 0x50c2e8: StoreField: r0->field_f = r1
    //     0x50c2e8: stur            w1, [x0, #0xf]
    // 0x50c2ec: StoreField: r0->field_13 = rZR
    //     0x50c2ec: stur            wzr, [x0, #0x13]
    // 0x50c2f0: StoreField: r0->field_17 = rZR
    //     0x50c2f0: stur            wzr, [x0, #0x17]
    // 0x50c2f4: mov             x2, x0
    // 0x50c2f8: b               #0x50c320
    // 0x50c2fc: ldur            x0, [fp, #-0x18]
    // 0x50c300: LoadField: r1 = r0->field_f
    //     0x50c300: ldur            w1, [x0, #0xf]
    // 0x50c304: DecompressPointer r1
    //     0x50c304: add             x1, x1, HEAP, lsl #32
    // 0x50c308: LoadField: r2 = r0->field_17
    //     0x50c308: ldur            w2, [x0, #0x17]
    // 0x50c30c: DecompressPointer r2
    //     0x50c30c: add             x2, x2, HEAP, lsl #32
    // 0x50c310: stp             x2, x1, [SP, #-0x10]!
    // 0x50c314: r0 = _hitTestResultToAnnotations()
    //     0x50c314: bl              #0x50d974  ; [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_hitTestResultToAnnotations
    // 0x50c318: add             SP, SP, #0x10
    // 0x50c31c: mov             x2, x0
    // 0x50c320: ldur            x0, [fp, #-0x18]
    // 0x50c324: ldur            x1, [fp, #-0x10]
    // 0x50c328: stur            x2, [fp, #-0x20]
    // 0x50c32c: ldur            x16, [fp, #-8]
    // 0x50c330: stp             x2, x16, [SP, #-0x10]!
    // 0x50c334: r0 = replaceAnnotations()
    //     0x50c334: bl              #0x50d918  ; [package:flutter/src/rendering/mouse_tracker.dart] _MouseState::replaceAnnotations
    // 0x50c338: add             SP, SP, #0x10
    // 0x50c33c: mov             x1, x0
    // 0x50c340: ldur            x0, [fp, #-0x18]
    // 0x50c344: stur            x1, [fp, #-0x30]
    // 0x50c348: LoadField: r2 = r0->field_f
    //     0x50c348: ldur            w2, [x0, #0xf]
    // 0x50c34c: DecompressPointer r2
    //     0x50c34c: add             x2, x2, HEAP, lsl #32
    // 0x50c350: stur            x2, [fp, #-0x28]
    // 0x50c354: LoadField: r3 = r0->field_13
    //     0x50c354: ldur            w3, [x0, #0x13]
    // 0x50c358: DecompressPointer r3
    //     0x50c358: add             x3, x3, HEAP, lsl #32
    // 0x50c35c: stur            x3, [fp, #-8]
    // 0x50c360: r0 = _MouseTrackerUpdateDetails()
    //     0x50c360: bl              #0x50d90c  ; Allocate_MouseTrackerUpdateDetailsStub -> _MouseTrackerUpdateDetails (size=0x18)
    // 0x50c364: mov             x1, x0
    // 0x50c368: ldur            x0, [fp, #-0x30]
    // 0x50c36c: StoreField: r1->field_7 = r0
    //     0x50c36c: stur            w0, [x1, #7]
    // 0x50c370: ldur            x0, [fp, #-0x20]
    // 0x50c374: StoreField: r1->field_b = r0
    //     0x50c374: stur            w0, [x1, #0xb]
    // 0x50c378: ldur            x0, [fp, #-0x10]
    // 0x50c37c: StoreField: r1->field_f = r0
    //     0x50c37c: stur            w0, [x1, #0xf]
    // 0x50c380: ldur            x0, [fp, #-8]
    // 0x50c384: StoreField: r1->field_13 = r0
    //     0x50c384: stur            w0, [x1, #0x13]
    // 0x50c388: ldur            x16, [fp, #-0x28]
    // 0x50c38c: stp             x1, x16, [SP, #-0x10]!
    // 0x50c390: r0 = _handleDeviceUpdate()
    //     0x50c390: bl              #0x50c3b4  ; [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_handleDeviceUpdate
    // 0x50c394: add             SP, SP, #0x10
    // 0x50c398: r0 = Null
    //     0x50c398: mov             x0, NULL
    // 0x50c39c: LeaveFrame
    //     0x50c39c: mov             SP, fp
    //     0x50c3a0: ldp             fp, lr, [SP], #0x10
    // 0x50c3a4: ret
    //     0x50c3a4: ret             
    // 0x50c3a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50c3a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50c3ac: b               #0x50c018
    // 0x50c3b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x50c3b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _handleDeviceUpdate(/* No info */) {
    // ** addr: 0x50c3b4, size: 0xd8
    // 0x50c3b4: EnterFrame
    //     0x50c3b4: stp             fp, lr, [SP, #-0x10]!
    //     0x50c3b8: mov             fp, SP
    // 0x50c3bc: AllocStack(0x20)
    //     0x50c3bc: sub             SP, SP, #0x20
    // 0x50c3c0: CheckStackOverflow
    //     0x50c3c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50c3c4: cmp             SP, x16
    //     0x50c3c8: b.ls            #0x50c484
    // 0x50c3cc: ldr             x16, [fp, #0x10]
    // 0x50c3d0: SaveReg r16
    //     0x50c3d0: str             x16, [SP, #-8]!
    // 0x50c3d4: r0 = _handleDeviceUpdateMouseEvents()
    //     0x50c3d4: bl              #0x50c9ec  ; [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_handleDeviceUpdateMouseEvents
    // 0x50c3d8: add             SP, SP, #8
    // 0x50c3dc: ldr             x0, [fp, #0x18]
    // 0x50c3e0: LoadField: r1 = r0->field_23
    //     0x50c3e0: ldur            w1, [x0, #0x23]
    // 0x50c3e4: DecompressPointer r1
    //     0x50c3e4: add             x1, x1, HEAP, lsl #32
    // 0x50c3e8: stur            x1, [fp, #-8]
    // 0x50c3ec: ldr             x16, [fp, #0x10]
    // 0x50c3f0: SaveReg r16
    //     0x50c3f0: str             x16, [SP, #-8]!
    // 0x50c3f4: r0 = device()
    //     0x50c3f4: bl              #0x50c98c  ; [package:flutter/src/rendering/mouse_tracker.dart] _MouseTrackerUpdateDetails::device
    // 0x50c3f8: add             SP, SP, #8
    // 0x50c3fc: mov             x1, x0
    // 0x50c400: ldr             x0, [fp, #0x10]
    // 0x50c404: stur            x1, [fp, #-0x18]
    // 0x50c408: LoadField: r2 = r0->field_13
    //     0x50c408: ldur            w2, [x0, #0x13]
    // 0x50c40c: DecompressPointer r2
    //     0x50c40c: add             x2, x2, HEAP, lsl #32
    // 0x50c410: stur            x2, [fp, #-0x10]
    // 0x50c414: LoadField: r3 = r0->field_b
    //     0x50c414: ldur            w3, [x0, #0xb]
    // 0x50c418: DecompressPointer r3
    //     0x50c418: add             x3, x3, HEAP, lsl #32
    // 0x50c41c: SaveReg r3
    //     0x50c41c: str             x3, [SP, #-8]!
    // 0x50c420: r0 = keys()
    //     0x50c420: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0x50c424: add             SP, SP, #8
    // 0x50c428: r1 = Function '<anonymous closure>':.
    //     0x50c428: ldr             x1, [PP, #0x3978]  ; [pp+0x3978] AnonymousClosure: (0x50d8bc), in [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_handleDeviceUpdate (0x50c3b4)
    // 0x50c42c: r2 = Null
    //     0x50c42c: mov             x2, NULL
    // 0x50c430: stur            x0, [fp, #-0x20]
    // 0x50c434: r0 = AllocateClosure()
    //     0x50c434: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x50c438: r16 = <MouseCursor>
    //     0x50c438: ldr             x16, [PP, #0x3980]  ; [pp+0x3980] TypeArguments: <MouseCursor>
    // 0x50c43c: ldur            lr, [fp, #-0x20]
    // 0x50c440: stp             lr, x16, [SP, #-0x10]!
    // 0x50c444: SaveReg r0
    //     0x50c444: str             x0, [SP, #-8]!
    // 0x50c448: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x50c448: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x50c44c: r0 = map()
    //     0x50c44c: bl              #0x6ba600  ; [dart:core] Iterable::map
    // 0x50c450: add             SP, SP, #0x18
    // 0x50c454: ldur            x16, [fp, #-8]
    // 0x50c458: SaveReg r16
    //     0x50c458: str             x16, [SP, #-8]!
    // 0x50c45c: ldur            x1, [fp, #-0x18]
    // 0x50c460: ldur            x16, [fp, #-0x10]
    // 0x50c464: stp             x16, x1, [SP, #-0x10]!
    // 0x50c468: SaveReg r0
    //     0x50c468: str             x0, [SP, #-8]!
    // 0x50c46c: r0 = handleDeviceCursorUpdate()
    //     0x50c46c: bl              #0x50c48c  ; [package:flutter/src/services/mouse_cursor.dart] MouseCursorManager::handleDeviceCursorUpdate
    // 0x50c470: add             SP, SP, #0x20
    // 0x50c474: r0 = Null
    //     0x50c474: mov             x0, NULL
    // 0x50c478: LeaveFrame
    //     0x50c478: mov             SP, fp
    //     0x50c47c: ldp             fp, lr, [SP], #0x10
    // 0x50c480: ret
    //     0x50c480: ret             
    // 0x50c484: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50c484: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50c488: b               #0x50c3cc
  }
  static _ _handleDeviceUpdateMouseEvents(/* No info */) {
    // ** addr: 0x50c9ec, size: 0x3a4
    // 0x50c9ec: EnterFrame
    //     0x50c9ec: stp             fp, lr, [SP, #-0x10]!
    //     0x50c9f0: mov             fp, SP
    // 0x50c9f4: AllocStack(0x40)
    //     0x50c9f4: sub             SP, SP, #0x40
    // 0x50c9f8: CheckStackOverflow
    //     0x50c9f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50c9fc: cmp             SP, x16
    //     0x50ca00: b.ls            #0x50cd7c
    // 0x50ca04: ldr             x0, [fp, #0x10]
    // 0x50ca08: LoadField: r1 = r0->field_13
    //     0x50ca08: ldur            w1, [x0, #0x13]
    // 0x50ca0c: DecompressPointer r1
    //     0x50ca0c: add             x1, x1, HEAP, lsl #32
    // 0x50ca10: cmp             w1, NULL
    // 0x50ca14: b.ne            #0x50ca20
    // 0x50ca18: LoadField: r1 = r0->field_f
    //     0x50ca18: ldur            w1, [x0, #0xf]
    // 0x50ca1c: DecompressPointer r1
    //     0x50ca1c: add             x1, x1, HEAP, lsl #32
    // 0x50ca20: stur            x1, [fp, #-0x10]
    // 0x50ca24: LoadField: r2 = r0->field_7
    //     0x50ca24: ldur            w2, [x0, #7]
    // 0x50ca28: DecompressPointer r2
    //     0x50ca28: add             x2, x2, HEAP, lsl #32
    // 0x50ca2c: stur            x2, [fp, #-8]
    // 0x50ca30: r1 = 3
    //     0x50ca30: mov             x1, #3
    // 0x50ca34: r0 = AllocateContext()
    //     0x50ca34: bl              #0xd68aa4  ; AllocateContextStub
    // 0x50ca38: mov             x1, x0
    // 0x50ca3c: ldur            x0, [fp, #-8]
    // 0x50ca40: stur            x1, [fp, #-0x20]
    // 0x50ca44: StoreField: r1->field_f = r0
    //     0x50ca44: stur            w0, [x1, #0xf]
    // 0x50ca48: ldr             x2, [fp, #0x10]
    // 0x50ca4c: LoadField: r3 = r2->field_b
    //     0x50ca4c: ldur            w3, [x2, #0xb]
    // 0x50ca50: DecompressPointer r3
    //     0x50ca50: add             x3, x3, HEAP, lsl #32
    // 0x50ca54: stur            x3, [fp, #-0x18]
    // 0x50ca58: StoreField: r1->field_13 = r3
    //     0x50ca58: stur            w3, [x1, #0x13]
    // 0x50ca5c: ldur            x16, [fp, #-0x10]
    // 0x50ca60: stp             x16, NULL, [SP, #-0x10]!
    // 0x50ca64: r0 = PointerExitEvent.fromMouseEvent()
    //     0x50ca64: bl              #0x50d228  ; [package:flutter/src/gestures/events.dart] PointerExitEvent::PointerExitEvent.fromMouseEvent
    // 0x50ca68: add             SP, SP, #0x10
    // 0x50ca6c: ldur            x3, [fp, #-0x20]
    // 0x50ca70: StoreField: r3->field_17 = r0
    //     0x50ca70: stur            w0, [x3, #0x17]
    //     0x50ca74: ldurb           w16, [x3, #-1]
    //     0x50ca78: ldurb           w17, [x0, #-1]
    //     0x50ca7c: and             x16, x17, x16, lsr #2
    //     0x50ca80: tst             x16, HEAP, lsr #32
    //     0x50ca84: b.eq            #0x50ca8c
    //     0x50ca88: bl              #0xd682ac
    // 0x50ca8c: mov             x2, x3
    // 0x50ca90: r1 = Function '<anonymous closure>': static.
    //     0x50ca90: ldr             x1, [PP, #0x39e0]  ; [pp+0x39e0] AnonymousClosure: static (0x50d754), in [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_handleDeviceUpdateMouseEvents (0x50c9ec)
    // 0x50ca94: r0 = AllocateClosure()
    //     0x50ca94: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x50ca98: ldur            x16, [fp, #-8]
    // 0x50ca9c: stp             x0, x16, [SP, #-0x10]!
    // 0x50caa0: r0 = forEach()
    //     0x50caa0: bl              #0xca3d28  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::forEach
    // 0x50caa4: add             SP, SP, #0x10
    // 0x50caa8: ldur            x16, [fp, #-0x18]
    // 0x50caac: SaveReg r16
    //     0x50caac: str             x16, [SP, #-8]!
    // 0x50cab0: r0 = keys()
    //     0x50cab0: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0x50cab4: add             SP, SP, #8
    // 0x50cab8: ldur            x2, [fp, #-0x20]
    // 0x50cabc: r1 = Function '<anonymous closure>': static.
    //     0x50cabc: ldr             x1, [PP, #0x39e8]  ; [pp+0x39e8] AnonymousClosure: static (0x50d6c0), in [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_handleDeviceUpdateMouseEvents (0x50c9ec)
    // 0x50cac0: stur            x0, [fp, #-8]
    // 0x50cac4: r0 = AllocateClosure()
    //     0x50cac4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x50cac8: ldur            x16, [fp, #-8]
    // 0x50cacc: stp             x0, x16, [SP, #-0x10]!
    // 0x50cad0: r0 = where()
    //     0x50cad0: bl              #0x6fa13c  ; [dart:collection] __Set&_HashVMBase&SetMixin::where
    // 0x50cad4: add             SP, SP, #0x10
    // 0x50cad8: SaveReg r0
    //     0x50cad8: str             x0, [SP, #-8]!
    // 0x50cadc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x50cadc: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x50cae0: r0 = toList()
    //     0x50cae0: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0x50cae4: add             SP, SP, #8
    // 0x50cae8: stur            x0, [fp, #-8]
    // 0x50caec: ldur            x16, [fp, #-0x10]
    // 0x50caf0: stp             x16, NULL, [SP, #-0x10]!
    // 0x50caf4: r0 = PointerEnterEvent.fromMouseEvent()
    //     0x50caf4: bl              #0x50cd90  ; [package:flutter/src/gestures/events.dart] PointerEnterEvent::PointerEnterEvent.fromMouseEvent
    // 0x50caf8: add             SP, SP, #0x10
    // 0x50cafc: stur            x0, [fp, #-0x10]
    // 0x50cb00: ldur            x16, [fp, #-8]
    // 0x50cb04: SaveReg r16
    //     0x50cb04: str             x16, [SP, #-8]!
    // 0x50cb08: r0 = reversed()
    //     0x50cb08: bl              #0x5edeb4  ; [dart:collection] _ListBase&Object&ListMixin::reversed
    // 0x50cb0c: add             SP, SP, #8
    // 0x50cb10: SaveReg r0
    //     0x50cb10: str             x0, [SP, #-8]!
    // 0x50cb14: r0 = iterator()
    //     0x50cb14: bl              #0x70b268  ; [dart:collection] ListMixin::iterator
    // 0x50cb18: add             SP, SP, #8
    // 0x50cb1c: mov             x1, x0
    // 0x50cb20: stur            x1, [fp, #-0x30]
    // 0x50cb24: LoadField: r2 = r1->field_b
    //     0x50cb24: ldur            w2, [x1, #0xb]
    // 0x50cb28: DecompressPointer r2
    //     0x50cb28: add             x2, x2, HEAP, lsl #32
    // 0x50cb2c: stur            x2, [fp, #-0x20]
    // 0x50cb30: LoadField: r3 = r1->field_f
    //     0x50cb30: ldur            x3, [x1, #0xf]
    // 0x50cb34: stur            x3, [fp, #-0x28]
    // 0x50cb38: LoadField: r4 = r1->field_7
    //     0x50cb38: ldur            w4, [x1, #7]
    // 0x50cb3c: DecompressPointer r4
    //     0x50cb3c: add             x4, x4, HEAP, lsl #32
    // 0x50cb40: stur            x4, [fp, #-8]
    // 0x50cb44: ldur            x6, [fp, #-0x18]
    // 0x50cb48: ldur            x5, [fp, #-0x10]
    // 0x50cb4c: CheckStackOverflow
    //     0x50cb4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50cb50: cmp             SP, x16
    //     0x50cb54: b.ls            #0x50cd84
    // 0x50cb58: r0 = LoadClassIdInstr(r2)
    //     0x50cb58: ldur            x0, [x2, #-1]
    //     0x50cb5c: ubfx            x0, x0, #0xc, #0x14
    // 0x50cb60: SaveReg r2
    //     0x50cb60: str             x2, [SP, #-8]!
    // 0x50cb64: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x50cb64: mov             x17, #0xb8ea
    //     0x50cb68: add             lr, x0, x17
    //     0x50cb6c: ldr             lr, [x21, lr, lsl #3]
    //     0x50cb70: blr             lr
    // 0x50cb74: add             SP, SP, #8
    // 0x50cb78: r1 = LoadInt32Instr(r0)
    //     0x50cb78: sbfx            x1, x0, #1, #0x1f
    //     0x50cb7c: tbz             w0, #0, #0x50cb84
    //     0x50cb80: ldur            x1, [x0, #7]
    // 0x50cb84: ldur            x2, [fp, #-0x28]
    // 0x50cb88: cmp             x2, x1
    // 0x50cb8c: b.ne            #0x50cd64
    // 0x50cb90: ldur            x4, [fp, #-0x30]
    // 0x50cb94: ldur            x3, [fp, #-0x20]
    // 0x50cb98: LoadField: r5 = r4->field_17
    //     0x50cb98: ldur            x5, [x4, #0x17]
    // 0x50cb9c: cmp             x5, x1
    // 0x50cba0: b.lt            #0x50cbb8
    // 0x50cba4: StoreField: r4->field_1f = rNULL
    //     0x50cba4: stur            NULL, [x4, #0x1f]
    // 0x50cba8: r0 = Null
    //     0x50cba8: mov             x0, NULL
    // 0x50cbac: LeaveFrame
    //     0x50cbac: mov             SP, fp
    //     0x50cbb0: ldp             fp, lr, [SP], #0x10
    // 0x50cbb4: ret
    //     0x50cbb4: ret             
    // 0x50cbb8: r0 = BoxInt64Instr(r5)
    //     0x50cbb8: sbfiz           x0, x5, #1, #0x1f
    //     0x50cbbc: cmp             x5, x0, asr #1
    //     0x50cbc0: b.eq            #0x50cbcc
    //     0x50cbc4: bl              #0xd69bb8
    //     0x50cbc8: stur            x5, [x0, #7]
    // 0x50cbcc: r1 = LoadClassIdInstr(r3)
    //     0x50cbcc: ldur            x1, [x3, #-1]
    //     0x50cbd0: ubfx            x1, x1, #0xc, #0x14
    // 0x50cbd4: stp             x0, x3, [SP, #-0x10]!
    // 0x50cbd8: mov             x0, x1
    // 0x50cbdc: r0 = GDT[cid_x0 + 0xd175]()
    //     0x50cbdc: mov             x17, #0xd175
    //     0x50cbe0: add             lr, x0, x17
    //     0x50cbe4: ldr             lr, [x21, lr, lsl #3]
    //     0x50cbe8: blr             lr
    // 0x50cbec: add             SP, SP, #0x10
    // 0x50cbf0: mov             x4, x0
    // 0x50cbf4: ldur            x3, [fp, #-0x30]
    // 0x50cbf8: stur            x4, [fp, #-0x38]
    // 0x50cbfc: StoreField: r3->field_1f = r0
    //     0x50cbfc: stur            w0, [x3, #0x1f]
    //     0x50cc00: tbz             w0, #0, #0x50cc1c
    //     0x50cc04: ldurb           w16, [x3, #-1]
    //     0x50cc08: ldurb           w17, [x0, #-1]
    //     0x50cc0c: and             x16, x17, x16, lsr #2
    //     0x50cc10: tst             x16, HEAP, lsr #32
    //     0x50cc14: b.eq            #0x50cc1c
    //     0x50cc18: bl              #0xd682ac
    // 0x50cc1c: LoadField: r0 = r3->field_17
    //     0x50cc1c: ldur            x0, [x3, #0x17]
    // 0x50cc20: add             x1, x0, #1
    // 0x50cc24: StoreField: r3->field_17 = r1
    //     0x50cc24: stur            x1, [x3, #0x17]
    // 0x50cc28: cmp             w4, NULL
    // 0x50cc2c: b.ne            #0x50cc5c
    // 0x50cc30: mov             x0, x4
    // 0x50cc34: ldur            x2, [fp, #-8]
    // 0x50cc38: r1 = Null
    //     0x50cc38: mov             x1, NULL
    // 0x50cc3c: cmp             w2, NULL
    // 0x50cc40: b.eq            #0x50cc5c
    // 0x50cc44: LoadField: r4 = r2->field_17
    //     0x50cc44: ldur            w4, [x2, #0x17]
    // 0x50cc48: DecompressPointer r4
    //     0x50cc48: add             x4, x4, HEAP, lsl #32
    // 0x50cc4c: r8 = X0
    //     0x50cc4c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x50cc50: LoadField: r9 = r4->field_7
    //     0x50cc50: ldur            x9, [x4, #7]
    // 0x50cc54: r3 = Null
    //     0x50cc54: ldr             x3, [PP, #0x39f0]  ; [pp+0x39f0] Null
    // 0x50cc58: blr             x9
    // 0x50cc5c: ldur            x1, [fp, #-0x38]
    // 0x50cc60: r0 = LoadClassIdInstr(r1)
    //     0x50cc60: ldur            x0, [x1, #-1]
    //     0x50cc64: ubfx            x0, x0, #0xc, #0x14
    // 0x50cc68: SaveReg r1
    //     0x50cc68: str             x1, [SP, #-8]!
    // 0x50cc6c: r0 = GDT[cid_x0 + 0x7d4]()
    //     0x50cc6c: add             lr, x0, #0x7d4
    //     0x50cc70: ldr             lr, [x21, lr, lsl #3]
    //     0x50cc74: blr             lr
    // 0x50cc78: add             SP, SP, #8
    // 0x50cc7c: tbnz            w0, #4, #0x50cd50
    // 0x50cc80: ldur            x1, [fp, #-0x38]
    // 0x50cc84: r0 = LoadClassIdInstr(r1)
    //     0x50cc84: ldur            x0, [x1, #-1]
    //     0x50cc88: ubfx            x0, x0, #0xc, #0x14
    // 0x50cc8c: SaveReg r1
    //     0x50cc8c: str             x1, [SP, #-8]!
    // 0x50cc90: r0 = GDT[cid_x0 + 0x1aff]()
    //     0x50cc90: mov             x17, #0x1aff
    //     0x50cc94: add             lr, x0, x17
    //     0x50cc98: ldr             lr, [x21, lr, lsl #3]
    //     0x50cc9c: blr             lr
    // 0x50cca0: add             SP, SP, #8
    // 0x50cca4: cmp             w0, NULL
    // 0x50cca8: b.eq            #0x50cd50
    // 0x50ccac: ldur            x2, [fp, #-0x18]
    // 0x50ccb0: ldur            x1, [fp, #-0x38]
    // 0x50ccb4: r0 = LoadClassIdInstr(r1)
    //     0x50ccb4: ldur            x0, [x1, #-1]
    //     0x50ccb8: ubfx            x0, x0, #0xc, #0x14
    // 0x50ccbc: SaveReg r1
    //     0x50ccbc: str             x1, [SP, #-8]!
    // 0x50ccc0: r0 = GDT[cid_x0 + 0x1aff]()
    //     0x50ccc0: mov             x17, #0x1aff
    //     0x50ccc4: add             lr, x0, x17
    //     0x50ccc8: ldr             lr, [x21, lr, lsl #3]
    //     0x50cccc: blr             lr
    // 0x50ccd0: add             SP, SP, #8
    // 0x50ccd4: stur            x0, [fp, #-0x40]
    // 0x50ccd8: cmp             w0, NULL
    // 0x50ccdc: b.eq            #0x50cd8c
    // 0x50cce0: ldur            x16, [fp, #-0x18]
    // 0x50cce4: ldur            lr, [fp, #-0x38]
    // 0x50cce8: stp             lr, x16, [SP, #-0x10]!
    // 0x50ccec: r0 = _getValueOrData()
    //     0x50ccec: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x50ccf0: add             SP, SP, #0x10
    // 0x50ccf4: ldur            x1, [fp, #-0x18]
    // 0x50ccf8: LoadField: r2 = r1->field_f
    //     0x50ccf8: ldur            w2, [x1, #0xf]
    // 0x50ccfc: DecompressPointer r2
    //     0x50ccfc: add             x2, x2, HEAP, lsl #32
    // 0x50cd00: cmp             w2, w0
    // 0x50cd04: b.ne            #0x50cd0c
    // 0x50cd08: r0 = Null
    //     0x50cd08: mov             x0, NULL
    // 0x50cd0c: ldur            x2, [fp, #-0x10]
    // 0x50cd10: r3 = LoadClassIdInstr(r2)
    //     0x50cd10: ldur            x3, [x2, #-1]
    //     0x50cd14: ubfx            x3, x3, #0xc, #0x14
    // 0x50cd18: stp             x0, x2, [SP, #-0x10]!
    // 0x50cd1c: mov             x0, x3
    // 0x50cd20: r0 = GDT[cid_x0 + 0xdefd]()
    //     0x50cd20: mov             x17, #0xdefd
    //     0x50cd24: add             lr, x0, x17
    //     0x50cd28: ldr             lr, [x21, lr, lsl #3]
    //     0x50cd2c: blr             lr
    // 0x50cd30: add             SP, SP, #0x10
    // 0x50cd34: ldur            x16, [fp, #-0x40]
    // 0x50cd38: stp             x0, x16, [SP, #-0x10]!
    // 0x50cd3c: ldur            x0, [fp, #-0x40]
    // 0x50cd40: ClosureCall
    //     0x50cd40: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x50cd44: ldur            x2, [x0, #0x1f]
    //     0x50cd48: blr             x2
    // 0x50cd4c: add             SP, SP, #0x10
    // 0x50cd50: ldur            x1, [fp, #-0x30]
    // 0x50cd54: ldur            x4, [fp, #-8]
    // 0x50cd58: ldur            x2, [fp, #-0x20]
    // 0x50cd5c: ldur            x3, [fp, #-0x28]
    // 0x50cd60: b               #0x50cb44
    // 0x50cd64: ldur            x0, [fp, #-0x20]
    // 0x50cd68: r0 = ConcurrentModificationError()
    //     0x50cd68: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x50cd6c: ldur            x3, [fp, #-0x20]
    // 0x50cd70: StoreField: r0->field_b = r3
    //     0x50cd70: stur            w3, [x0, #0xb]
    // 0x50cd74: r0 = Throw()
    //     0x50cd74: bl              #0xd67e38  ; ThrowStub
    // 0x50cd78: brk             #0
    // 0x50cd7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50cd7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50cd80: b               #0x50ca04
    // 0x50cd84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50cd84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50cd88: b               #0x50cb58
    // 0x50cd8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x50cd8c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] static bool <anonymous closure>(dynamic, MouseTrackerAnnotation) {
    // ** addr: 0x50d6c0, size: 0x54
    // 0x50d6c0: EnterFrame
    //     0x50d6c0: stp             fp, lr, [SP, #-0x10]!
    //     0x50d6c4: mov             fp, SP
    // 0x50d6c8: ldr             x0, [fp, #0x18]
    // 0x50d6cc: LoadField: r1 = r0->field_17
    //     0x50d6cc: ldur            w1, [x0, #0x17]
    // 0x50d6d0: DecompressPointer r1
    //     0x50d6d0: add             x1, x1, HEAP, lsl #32
    // 0x50d6d4: CheckStackOverflow
    //     0x50d6d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50d6d8: cmp             SP, x16
    //     0x50d6dc: b.ls            #0x50d70c
    // 0x50d6e0: LoadField: r0 = r1->field_f
    //     0x50d6e0: ldur            w0, [x1, #0xf]
    // 0x50d6e4: DecompressPointer r0
    //     0x50d6e4: add             x0, x0, HEAP, lsl #32
    // 0x50d6e8: ldr             x16, [fp, #0x10]
    // 0x50d6ec: stp             x16, x0, [SP, #-0x10]!
    // 0x50d6f0: r0 = containsKey()
    //     0x50d6f0: bl              #0xca679c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x50d6f4: add             SP, SP, #0x10
    // 0x50d6f8: eor             x1, x0, #0x10
    // 0x50d6fc: mov             x0, x1
    // 0x50d700: LeaveFrame
    //     0x50d700: mov             SP, fp
    //     0x50d704: ldp             fp, lr, [SP], #0x10
    // 0x50d708: ret
    //     0x50d708: ret             
    // 0x50d70c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50d70c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50d710: b               #0x50d6e0
  }
  [closure] static void <anonymous closure>(dynamic, MouseTrackerAnnotation, Matrix4) {
    // ** addr: 0x50d754, size: 0x168
    // 0x50d754: EnterFrame
    //     0x50d754: stp             fp, lr, [SP, #-0x10]!
    //     0x50d758: mov             fp, SP
    // 0x50d75c: AllocStack(0x20)
    //     0x50d75c: sub             SP, SP, #0x20
    // 0x50d760: SetupParameters()
    //     0x50d760: ldr             x0, [fp, #0x20]
    //     0x50d764: ldur            w1, [x0, #0x17]
    //     0x50d768: add             x1, x1, HEAP, lsl #32
    //     0x50d76c: stur            x1, [fp, #-8]
    // 0x50d770: CheckStackOverflow
    //     0x50d770: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50d774: cmp             SP, x16
    //     0x50d778: b.ls            #0x50d8b0
    // 0x50d77c: LoadField: r0 = r1->field_13
    //     0x50d77c: ldur            w0, [x1, #0x13]
    // 0x50d780: DecompressPointer r0
    //     0x50d780: add             x0, x0, HEAP, lsl #32
    // 0x50d784: ldr             x16, [fp, #0x18]
    // 0x50d788: stp             x16, x0, [SP, #-0x10]!
    // 0x50d78c: r0 = containsKey()
    //     0x50d78c: bl              #0xca679c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x50d790: add             SP, SP, #0x10
    // 0x50d794: tbz             w0, #4, #0x50d8a0
    // 0x50d798: ldr             x1, [fp, #0x18]
    // 0x50d79c: r0 = LoadClassIdInstr(r1)
    //     0x50d79c: ldur            x0, [x1, #-1]
    //     0x50d7a0: ubfx            x0, x0, #0xc, #0x14
    // 0x50d7a4: SaveReg r1
    //     0x50d7a4: str             x1, [SP, #-8]!
    // 0x50d7a8: r0 = GDT[cid_x0 + 0x7d4]()
    //     0x50d7a8: add             lr, x0, #0x7d4
    //     0x50d7ac: ldr             lr, [x21, lr, lsl #3]
    //     0x50d7b0: blr             lr
    // 0x50d7b4: add             SP, SP, #8
    // 0x50d7b8: tbnz            w0, #4, #0x50d8a0
    // 0x50d7bc: ldr             x1, [fp, #0x18]
    // 0x50d7c0: r0 = LoadClassIdInstr(r1)
    //     0x50d7c0: ldur            x0, [x1, #-1]
    //     0x50d7c4: ubfx            x0, x0, #0xc, #0x14
    // 0x50d7c8: SaveReg r1
    //     0x50d7c8: str             x1, [SP, #-8]!
    // 0x50d7cc: r0 = GDT[cid_x0 + 0xef1]()
    //     0x50d7cc: add             lr, x0, #0xef1
    //     0x50d7d0: ldr             lr, [x21, lr, lsl #3]
    //     0x50d7d4: blr             lr
    // 0x50d7d8: add             SP, SP, #8
    // 0x50d7dc: cmp             w0, NULL
    // 0x50d7e0: b.eq            #0x50d8a0
    // 0x50d7e4: ldr             x1, [fp, #0x18]
    // 0x50d7e8: ldur            x2, [fp, #-8]
    // 0x50d7ec: r0 = LoadClassIdInstr(r1)
    //     0x50d7ec: ldur            x0, [x1, #-1]
    //     0x50d7f0: ubfx            x0, x0, #0xc, #0x14
    // 0x50d7f4: SaveReg r1
    //     0x50d7f4: str             x1, [SP, #-8]!
    // 0x50d7f8: r0 = GDT[cid_x0 + 0xef1]()
    //     0x50d7f8: add             lr, x0, #0xef1
    //     0x50d7fc: ldr             lr, [x21, lr, lsl #3]
    //     0x50d800: blr             lr
    // 0x50d804: add             SP, SP, #8
    // 0x50d808: stur            x0, [fp, #-0x20]
    // 0x50d80c: cmp             w0, NULL
    // 0x50d810: b.eq            #0x50d8b8
    // 0x50d814: ldur            x1, [fp, #-8]
    // 0x50d818: LoadField: r2 = r1->field_17
    //     0x50d818: ldur            w2, [x1, #0x17]
    // 0x50d81c: DecompressPointer r2
    //     0x50d81c: add             x2, x2, HEAP, lsl #32
    // 0x50d820: stur            x2, [fp, #-0x18]
    // 0x50d824: LoadField: r3 = r1->field_f
    //     0x50d824: ldur            w3, [x1, #0xf]
    // 0x50d828: DecompressPointer r3
    //     0x50d828: add             x3, x3, HEAP, lsl #32
    // 0x50d82c: stur            x3, [fp, #-0x10]
    // 0x50d830: ldr             x16, [fp, #0x18]
    // 0x50d834: stp             x16, x3, [SP, #-0x10]!
    // 0x50d838: r0 = _getValueOrData()
    //     0x50d838: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x50d83c: add             SP, SP, #0x10
    // 0x50d840: mov             x1, x0
    // 0x50d844: ldur            x0, [fp, #-0x10]
    // 0x50d848: LoadField: r2 = r0->field_f
    //     0x50d848: ldur            w2, [x0, #0xf]
    // 0x50d84c: DecompressPointer r2
    //     0x50d84c: add             x2, x2, HEAP, lsl #32
    // 0x50d850: cmp             w2, w1
    // 0x50d854: b.ne            #0x50d85c
    // 0x50d858: r1 = Null
    //     0x50d858: mov             x1, NULL
    // 0x50d85c: ldur            x0, [fp, #-0x18]
    // 0x50d860: r2 = LoadClassIdInstr(r0)
    //     0x50d860: ldur            x2, [x0, #-1]
    //     0x50d864: ubfx            x2, x2, #0xc, #0x14
    // 0x50d868: stp             x1, x0, [SP, #-0x10]!
    // 0x50d86c: mov             x0, x2
    // 0x50d870: r0 = GDT[cid_x0 + 0xdefd]()
    //     0x50d870: mov             x17, #0xdefd
    //     0x50d874: add             lr, x0, x17
    //     0x50d878: ldr             lr, [x21, lr, lsl #3]
    //     0x50d87c: blr             lr
    // 0x50d880: add             SP, SP, #0x10
    // 0x50d884: ldur            x16, [fp, #-0x20]
    // 0x50d888: stp             x0, x16, [SP, #-0x10]!
    // 0x50d88c: ldur            x0, [fp, #-0x20]
    // 0x50d890: ClosureCall
    //     0x50d890: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x50d894: ldur            x2, [x0, #0x1f]
    //     0x50d898: blr             x2
    // 0x50d89c: add             SP, SP, #0x10
    // 0x50d8a0: r0 = Null
    //     0x50d8a0: mov             x0, NULL
    // 0x50d8a4: LeaveFrame
    //     0x50d8a4: mov             SP, fp
    //     0x50d8a8: ldp             fp, lr, [SP], #0x10
    // 0x50d8ac: ret
    //     0x50d8ac: ret             
    // 0x50d8b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50d8b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50d8b4: b               #0x50d77c
    // 0x50d8b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x50d8b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] MouseCursor <anonymous closure>(dynamic, MouseTrackerAnnotation) {
    // ** addr: 0x50d8bc, size: 0x50
    // 0x50d8bc: EnterFrame
    //     0x50d8bc: stp             fp, lr, [SP, #-0x10]!
    //     0x50d8c0: mov             fp, SP
    // 0x50d8c4: CheckStackOverflow
    //     0x50d8c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50d8c8: cmp             SP, x16
    //     0x50d8cc: b.ls            #0x50d904
    // 0x50d8d0: ldr             x0, [fp, #0x10]
    // 0x50d8d4: r1 = LoadClassIdInstr(r0)
    //     0x50d8d4: ldur            x1, [x0, #-1]
    //     0x50d8d8: ubfx            x1, x1, #0xc, #0x14
    // 0x50d8dc: SaveReg r0
    //     0x50d8dc: str             x0, [SP, #-8]!
    // 0x50d8e0: mov             x0, x1
    // 0x50d8e4: r0 = GDT[cid_x0 + 0x2e8c]()
    //     0x50d8e4: mov             x17, #0x2e8c
    //     0x50d8e8: add             lr, x0, x17
    //     0x50d8ec: ldr             lr, [x21, lr, lsl #3]
    //     0x50d8f0: blr             lr
    // 0x50d8f4: add             SP, SP, #8
    // 0x50d8f8: LeaveFrame
    //     0x50d8f8: mov             SP, fp
    //     0x50d8fc: ldp             fp, lr, [SP], #0x10
    // 0x50d900: ret
    //     0x50d900: ret             
    // 0x50d904: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50d904: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50d908: b               #0x50d8d0
  }
  _ _hitTestResultToAnnotations(/* No info */) {
    // ** addr: 0x50d974, size: 0x28c
    // 0x50d974: EnterFrame
    //     0x50d974: stp             fp, lr, [SP, #-0x10]!
    //     0x50d978: mov             fp, SP
    // 0x50d97c: AllocStack(0x48)
    //     0x50d97c: sub             SP, SP, #0x48
    // 0x50d980: CheckStackOverflow
    //     0x50d980: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50d984: cmp             SP, x16
    //     0x50d988: b.ls            #0x50dbec
    // 0x50d98c: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x50d98c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x50d990: ldr             x0, [x0, #0x598]
    //     0x50d994: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x50d998: cmp             w0, w16
    //     0x50d99c: b.ne            #0x50d9a8
    //     0x50d9a0: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x50d9a4: bl              #0xd67cdc
    // 0x50d9a8: r1 = <MouseTrackerAnnotation, Matrix4>
    //     0x50d9a8: ldr             x1, [PP, #0x3970]  ; [pp+0x3970] TypeArguments: <MouseTrackerAnnotation, Matrix4>
    // 0x50d9ac: stur            x0, [fp, #-8]
    // 0x50d9b0: r0 = _Map()
    //     0x50d9b0: bl              #0x4b4914  ; Allocate_MapStub -> _Map<X0, X1> (size=-0x8)
    // 0x50d9b4: mov             x1, x0
    // 0x50d9b8: ldur            x0, [fp, #-8]
    // 0x50d9bc: stur            x1, [fp, #-0x10]
    // 0x50d9c0: StoreField: r1->field_1b = r0
    //     0x50d9c0: stur            w0, [x1, #0x1b]
    // 0x50d9c4: StoreField: r1->field_b = rZR
    //     0x50d9c4: stur            wzr, [x1, #0xb]
    // 0x50d9c8: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x50d9c8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x50d9cc: ldr             x0, [x0, #0x5a0]
    //     0x50d9d0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x50d9d4: cmp             w0, w16
    //     0x50d9d8: b.ne            #0x50d9e4
    //     0x50d9dc: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x50d9e0: bl              #0xd67cdc
    // 0x50d9e4: ldur            x1, [fp, #-0x10]
    // 0x50d9e8: StoreField: r1->field_f = r0
    //     0x50d9e8: stur            w0, [x1, #0xf]
    // 0x50d9ec: StoreField: r1->field_13 = rZR
    //     0x50d9ec: stur            wzr, [x1, #0x13]
    // 0x50d9f0: StoreField: r1->field_17 = rZR
    //     0x50d9f0: stur            wzr, [x1, #0x17]
    // 0x50d9f4: ldr             x0, [fp, #0x10]
    // 0x50d9f8: LoadField: r2 = r0->field_7
    //     0x50d9f8: ldur            w2, [x0, #7]
    // 0x50d9fc: DecompressPointer r2
    //     0x50d9fc: add             x2, x2, HEAP, lsl #32
    // 0x50da00: stur            x2, [fp, #-0x28]
    // 0x50da04: LoadField: r3 = r2->field_7
    //     0x50da04: ldur            w3, [x2, #7]
    // 0x50da08: DecompressPointer r3
    //     0x50da08: add             x3, x3, HEAP, lsl #32
    // 0x50da0c: stur            x3, [fp, #-8]
    // 0x50da10: LoadField: r0 = r2->field_b
    //     0x50da10: ldur            w0, [x2, #0xb]
    // 0x50da14: DecompressPointer r0
    //     0x50da14: add             x0, x0, HEAP, lsl #32
    // 0x50da18: r4 = LoadInt32Instr(r0)
    //     0x50da18: sbfx            x4, x0, #1, #0x1f
    // 0x50da1c: stur            x4, [fp, #-0x20]
    // 0x50da20: r5 = 0
    //     0x50da20: mov             x5, #0
    // 0x50da24: stur            x5, [fp, #-0x18]
    // 0x50da28: CheckStackOverflow
    //     0x50da28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50da2c: cmp             SP, x16
    //     0x50da30: b.ls            #0x50dbf4
    // 0x50da34: r0 = LoadClassIdInstr(r2)
    //     0x50da34: ldur            x0, [x2, #-1]
    //     0x50da38: ubfx            x0, x0, #0xc, #0x14
    // 0x50da3c: SaveReg r2
    //     0x50da3c: str             x2, [SP, #-8]!
    // 0x50da40: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x50da40: mov             x17, #0xb8ea
    //     0x50da44: add             lr, x0, x17
    //     0x50da48: ldr             lr, [x21, lr, lsl #3]
    //     0x50da4c: blr             lr
    // 0x50da50: add             SP, SP, #8
    // 0x50da54: r1 = LoadInt32Instr(r0)
    //     0x50da54: sbfx            x1, x0, #1, #0x1f
    //     0x50da58: tbz             w0, #0, #0x50da60
    //     0x50da5c: ldur            x1, [x0, #7]
    // 0x50da60: ldur            x2, [fp, #-0x20]
    // 0x50da64: cmp             x2, x1
    // 0x50da68: b.ne            #0x50dbd4
    // 0x50da6c: ldur            x3, [fp, #-0x28]
    // 0x50da70: ldur            x4, [fp, #-0x18]
    // 0x50da74: cmp             x4, x1
    // 0x50da78: b.lt            #0x50da8c
    // 0x50da7c: ldur            x0, [fp, #-0x10]
    // 0x50da80: LeaveFrame
    //     0x50da80: mov             SP, fp
    //     0x50da84: ldp             fp, lr, [SP], #0x10
    // 0x50da88: ret
    //     0x50da88: ret             
    // 0x50da8c: r0 = BoxInt64Instr(r4)
    //     0x50da8c: sbfiz           x0, x4, #1, #0x1f
    //     0x50da90: cmp             x4, x0, asr #1
    //     0x50da94: b.eq            #0x50daa0
    //     0x50da98: bl              #0xd69bb8
    //     0x50da9c: stur            x4, [x0, #7]
    // 0x50daa0: r1 = LoadClassIdInstr(r3)
    //     0x50daa0: ldur            x1, [x3, #-1]
    //     0x50daa4: ubfx            x1, x1, #0xc, #0x14
    // 0x50daa8: stp             x0, x3, [SP, #-0x10]!
    // 0x50daac: mov             x0, x1
    // 0x50dab0: r0 = GDT[cid_x0 + 0xd175]()
    //     0x50dab0: mov             x17, #0xd175
    //     0x50dab4: add             lr, x0, x17
    //     0x50dab8: ldr             lr, [x21, lr, lsl #3]
    //     0x50dabc: blr             lr
    // 0x50dac0: add             SP, SP, #0x10
    // 0x50dac4: mov             x3, x0
    // 0x50dac8: ldur            x0, [fp, #-0x18]
    // 0x50dacc: stur            x3, [fp, #-0x38]
    // 0x50dad0: add             x5, x0, #1
    // 0x50dad4: stur            x5, [fp, #-0x30]
    // 0x50dad8: cmp             w3, NULL
    // 0x50dadc: b.ne            #0x50db0c
    // 0x50dae0: mov             x0, x3
    // 0x50dae4: ldur            x2, [fp, #-8]
    // 0x50dae8: r1 = Null
    //     0x50dae8: mov             x1, NULL
    // 0x50daec: cmp             w2, NULL
    // 0x50daf0: b.eq            #0x50db0c
    // 0x50daf4: LoadField: r4 = r2->field_17
    //     0x50daf4: ldur            w4, [x2, #0x17]
    // 0x50daf8: DecompressPointer r4
    //     0x50daf8: add             x4, x4, HEAP, lsl #32
    // 0x50dafc: r8 = X0
    //     0x50dafc: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x50db00: LoadField: r9 = r4->field_7
    //     0x50db00: ldur            x9, [x4, #7]
    // 0x50db04: r3 = Null
    //     0x50db04: ldr             x3, [PP, #0x3a00]  ; [pp+0x3a00] Null
    // 0x50db08: blr             x9
    // 0x50db0c: ldur            x3, [fp, #-0x38]
    // 0x50db10: LoadField: r4 = r3->field_b
    //     0x50db10: ldur            w4, [x3, #0xb]
    // 0x50db14: DecompressPointer r4
    //     0x50db14: add             x4, x4, HEAP, lsl #32
    // 0x50db18: mov             x0, x4
    // 0x50db1c: stur            x4, [fp, #-0x40]
    // 0x50db20: r2 = Null
    //     0x50db20: mov             x2, NULL
    // 0x50db24: r1 = Null
    //     0x50db24: mov             x1, NULL
    // 0x50db28: cmp             w0, NULL
    // 0x50db2c: b.eq            #0x50db64
    // 0x50db30: branchIfSmi(r0, 0x50db64)
    //     0x50db30: tbz             w0, #0, #0x50db64
    // 0x50db34: r3 = LoadClassIdInstr(r0)
    //     0x50db34: ldur            x3, [x0, #-1]
    //     0x50db38: ubfx            x3, x3, #0xc, #0x14
    // 0x50db3c: sub             x3, x3, #0x97f
    // 0x50db40: cmp             x3, #1
    // 0x50db44: b.ls            #0x50db6c
    // 0x50db48: cmp             x3, #0x58
    // 0x50db4c: b.eq            #0x50db6c
    // 0x50db50: cmp             x3, #0x5f
    // 0x50db54: b.eq            #0x50db6c
    // 0x50db58: sub             x3, x3, #0x412
    // 0x50db5c: cmp             x3, #2
    // 0x50db60: b.ls            #0x50db6c
    // 0x50db64: r0 = false
    //     0x50db64: add             x0, NULL, #0x30  ; false
    // 0x50db68: b               #0x50db70
    // 0x50db6c: r0 = true
    //     0x50db6c: add             x0, NULL, #0x20  ; true
    // 0x50db70: tbnz            w0, #4, #0x50dbbc
    // 0x50db74: ldur            x0, [fp, #-0x38]
    // 0x50db78: LoadField: r1 = r0->field_f
    //     0x50db78: ldur            w1, [x0, #0xf]
    // 0x50db7c: DecompressPointer r1
    //     0x50db7c: add             x1, x1, HEAP, lsl #32
    // 0x50db80: stur            x1, [fp, #-0x48]
    // 0x50db84: cmp             w1, NULL
    // 0x50db88: b.eq            #0x50dbfc
    // 0x50db8c: ldur            x16, [fp, #-0x10]
    // 0x50db90: ldur            lr, [fp, #-0x40]
    // 0x50db94: stp             lr, x16, [SP, #-0x10]!
    // 0x50db98: r0 = hash()
    //     0x50db98: bl              #0xc0483c  ; [package:collection/src/equality.dart] DefaultEquality::hash
    // 0x50db9c: add             SP, SP, #0x10
    // 0x50dba0: ldur            x16, [fp, #-0x10]
    // 0x50dba4: ldur            lr, [fp, #-0x40]
    // 0x50dba8: stp             lr, x16, [SP, #-0x10]!
    // 0x50dbac: ldur            x16, [fp, #-0x48]
    // 0x50dbb0: stp             x0, x16, [SP, #-0x10]!
    // 0x50dbb4: r0 = _set()
    //     0x50dbb4: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x50dbb8: add             SP, SP, #0x20
    // 0x50dbbc: ldur            x5, [fp, #-0x30]
    // 0x50dbc0: ldur            x1, [fp, #-0x10]
    // 0x50dbc4: ldur            x2, [fp, #-0x28]
    // 0x50dbc8: ldur            x3, [fp, #-8]
    // 0x50dbcc: ldur            x4, [fp, #-0x20]
    // 0x50dbd0: b               #0x50da24
    // 0x50dbd4: ldur            x0, [fp, #-0x28]
    // 0x50dbd8: r0 = ConcurrentModificationError()
    //     0x50dbd8: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x50dbdc: ldur            x3, [fp, #-0x28]
    // 0x50dbe0: StoreField: r0->field_b = r3
    //     0x50dbe0: stur            w3, [x0, #0xb]
    // 0x50dbe4: r0 = Throw()
    //     0x50dbe4: bl              #0xd67e38  ; ThrowStub
    // 0x50dbe8: brk             #0
    // 0x50dbec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50dbec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50dbf0: b               #0x50d98c
    // 0x50dbf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50dbf4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50dbf8: b               #0x50da34
    // 0x50dbfc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x50dbfc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ MouseTracker(/* No info */) {
    // ** addr: 0x5bb2f0, size: 0x108
    // 0x5bb2f0: EnterFrame
    //     0x5bb2f0: stp             fp, lr, [SP, #-0x10]!
    //     0x5bb2f4: mov             fp, SP
    // 0x5bb2f8: AllocStack(0x8)
    //     0x5bb2f8: sub             SP, SP, #8
    // 0x5bb2fc: CheckStackOverflow
    //     0x5bb2fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5bb300: cmp             SP, x16
    //     0x5bb304: b.ls            #0x5bb3f0
    // 0x5bb308: r16 = <int, MouseCursorSession>
    //     0x5bb308: ldr             x16, [PP, #0x4d00]  ; [pp+0x4d00] TypeArguments: <int, MouseCursorSession>
    // 0x5bb30c: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x5bb310: stp             lr, x16, [SP, #-0x10]!
    // 0x5bb314: r0 = Map._fromLiteral()
    //     0x5bb314: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x5bb318: add             SP, SP, #0x10
    // 0x5bb31c: stur            x0, [fp, #-8]
    // 0x5bb320: r0 = MouseCursorManager()
    //     0x5bb320: bl              #0x5bb3f8  ; AllocateMouseCursorManagerStub -> MouseCursorManager (size=0x10)
    // 0x5bb324: mov             x1, x0
    // 0x5bb328: ldur            x0, [fp, #-8]
    // 0x5bb32c: StoreField: r1->field_b = r0
    //     0x5bb32c: stur            w0, [x1, #0xb]
    // 0x5bb330: r0 = Instance_SystemMouseCursor
    //     0x5bb330: ldr             x0, [PP, #0x3988]  ; [pp+0x3988] Obj!SystemMouseCursor@b489a1
    // 0x5bb334: StoreField: r1->field_7 = r0
    //     0x5bb334: stur            w0, [x1, #7]
    // 0x5bb338: mov             x0, x1
    // 0x5bb33c: ldr             x1, [fp, #0x10]
    // 0x5bb340: StoreField: r1->field_23 = r0
    //     0x5bb340: stur            w0, [x1, #0x23]
    //     0x5bb344: ldurb           w16, [x1, #-1]
    //     0x5bb348: ldurb           w17, [x0, #-1]
    //     0x5bb34c: and             x16, x17, x16, lsr #2
    //     0x5bb350: tst             x16, HEAP, lsr #32
    //     0x5bb354: b.eq            #0x5bb35c
    //     0x5bb358: bl              #0xd6826c
    // 0x5bb35c: r16 = <int, _MouseState>
    //     0x5bb35c: ldr             x16, [PP, #0x4d08]  ; [pp+0x4d08] TypeArguments: <int, _MouseState>
    // 0x5bb360: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x5bb364: stp             lr, x16, [SP, #-0x10]!
    // 0x5bb368: r0 = Map._fromLiteral()
    //     0x5bb368: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x5bb36c: add             SP, SP, #0x10
    // 0x5bb370: ldr             x1, [fp, #0x10]
    // 0x5bb374: StoreField: r1->field_27 = r0
    //     0x5bb374: stur            w0, [x1, #0x27]
    //     0x5bb378: tbz             w0, #0, #0x5bb394
    //     0x5bb37c: ldurb           w16, [x1, #-1]
    //     0x5bb380: ldurb           w17, [x0, #-1]
    //     0x5bb384: and             x16, x17, x16, lsr #2
    //     0x5bb388: tst             x16, HEAP, lsr #32
    //     0x5bb38c: b.eq            #0x5bb394
    //     0x5bb390: bl              #0xd6826c
    // 0x5bb394: r0 = 0
    //     0x5bb394: mov             x0, #0
    // 0x5bb398: StoreField: r1->field_7 = r0
    //     0x5bb398: stur            x0, [x1, #7]
    // 0x5bb39c: StoreField: r1->field_13 = r0
    //     0x5bb39c: stur            x0, [x1, #0x13]
    // 0x5bb3a0: StoreField: r1->field_1b = r0
    //     0x5bb3a0: stur            x0, [x1, #0x1b]
    // 0x5bb3a4: r0 = InitLateStaticField(0xac0) // [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_emptyListeners
    //     0x5bb3a4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5bb3a8: ldr             x0, [x0, #0x1580]
    //     0x5bb3ac: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5bb3b0: cmp             w0, w16
    //     0x5bb3b4: b.ne            #0x5bb3c0
    //     0x5bb3b8: ldr             x2, [PP, #0x44a0]  ; [pp+0x44a0] Field <ChangeNotifier._emptyListeners@171329750>: static late final (offset: 0xac0)
    //     0x5bb3bc: bl              #0xd67cdc
    // 0x5bb3c0: ldr             x1, [fp, #0x10]
    // 0x5bb3c4: StoreField: r1->field_f = r0
    //     0x5bb3c4: stur            w0, [x1, #0xf]
    //     0x5bb3c8: ldurb           w16, [x1, #-1]
    //     0x5bb3cc: ldurb           w17, [x0, #-1]
    //     0x5bb3d0: and             x16, x17, x16, lsr #2
    //     0x5bb3d4: tst             x16, HEAP, lsr #32
    //     0x5bb3d8: b.eq            #0x5bb3e0
    //     0x5bb3dc: bl              #0xd6826c
    // 0x5bb3e0: r0 = Null
    //     0x5bb3e0: mov             x0, NULL
    // 0x5bb3e4: LeaveFrame
    //     0x5bb3e4: mov             SP, fp
    //     0x5bb3e8: ldp             fp, lr, [SP], #0x10
    // 0x5bb3ec: ret
    //     0x5bb3ec: ret             
    // 0x5bb3f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5bb3f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5bb3f4: b               #0x5bb308
  }
  _ updateAllDevices(/* No info */) {
    // ** addr: 0x5cd968, size: 0x64
    // 0x5cd968: EnterFrame
    //     0x5cd968: stp             fp, lr, [SP, #-0x10]!
    //     0x5cd96c: mov             fp, SP
    // 0x5cd970: CheckStackOverflow
    //     0x5cd970: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5cd974: cmp             SP, x16
    //     0x5cd978: b.ls            #0x5cd9c4
    // 0x5cd97c: r1 = 2
    //     0x5cd97c: mov             x1, #2
    // 0x5cd980: r0 = AllocateContext()
    //     0x5cd980: bl              #0xd68aa4  ; AllocateContextStub
    // 0x5cd984: mov             x1, x0
    // 0x5cd988: ldr             x0, [fp, #0x18]
    // 0x5cd98c: StoreField: r1->field_f = r0
    //     0x5cd98c: stur            w0, [x1, #0xf]
    // 0x5cd990: ldr             x2, [fp, #0x10]
    // 0x5cd994: StoreField: r1->field_13 = r2
    //     0x5cd994: stur            w2, [x1, #0x13]
    // 0x5cd998: mov             x2, x1
    // 0x5cd99c: r1 = Function '<anonymous closure>':.
    //     0x5cd99c: ldr             x1, [PP, #0x4550]  ; [pp+0x4550] AnonymousClosure: (0x5cd9cc), in [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::updateAllDevices (0x5cd968)
    // 0x5cd9a0: r0 = AllocateClosure()
    //     0x5cd9a0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5cd9a4: ldr             x16, [fp, #0x18]
    // 0x5cd9a8: stp             x0, x16, [SP, #-0x10]!
    // 0x5cd9ac: r0 = lockState()
    //     0x5cd9ac: bl              #0x50bfa8  ; [package:flutter/src/widgets/framework.dart] BuildOwner::lockState
    // 0x5cd9b0: add             SP, SP, #0x10
    // 0x5cd9b4: r0 = Null
    //     0x5cd9b4: mov             x0, NULL
    // 0x5cd9b8: LeaveFrame
    //     0x5cd9b8: mov             SP, fp
    //     0x5cd9bc: ldp             fp, lr, [SP], #0x10
    // 0x5cd9c0: ret
    //     0x5cd9c0: ret             
    // 0x5cd9c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5cd9c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5cd9c8: b               #0x5cd97c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x5cd9cc, size: 0x384
    // 0x5cd9cc: EnterFrame
    //     0x5cd9cc: stp             fp, lr, [SP, #-0x10]!
    //     0x5cd9d0: mov             fp, SP
    // 0x5cd9d4: AllocStack(0x50)
    //     0x5cd9d4: sub             SP, SP, #0x50
    // 0x5cd9d8: SetupParameters()
    //     0x5cd9d8: ldr             x0, [fp, #0x10]
    //     0x5cd9dc: ldur            w1, [x0, #0x17]
    //     0x5cd9e0: add             x1, x1, HEAP, lsl #32
    //     0x5cd9e4: stur            x1, [fp, #-8]
    // 0x5cd9e8: CheckStackOverflow
    //     0x5cd9e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5cd9ec: cmp             SP, x16
    //     0x5cd9f0: b.ls            #0x5cdd3c
    // 0x5cd9f4: LoadField: r0 = r1->field_f
    //     0x5cd9f4: ldur            w0, [x1, #0xf]
    // 0x5cd9f8: DecompressPointer r0
    //     0x5cd9f8: add             x0, x0, HEAP, lsl #32
    // 0x5cd9fc: LoadField: r2 = r0->field_27
    //     0x5cd9fc: ldur            w2, [x0, #0x27]
    // 0x5cda00: DecompressPointer r2
    //     0x5cda00: add             x2, x2, HEAP, lsl #32
    // 0x5cda04: SaveReg r2
    //     0x5cda04: str             x2, [SP, #-8]!
    // 0x5cda08: r0 = values()
    //     0x5cda08: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0x5cda0c: add             SP, SP, #8
    // 0x5cda10: SaveReg r0
    //     0x5cda10: str             x0, [SP, #-8]!
    // 0x5cda14: r0 = iterator()
    //     0x5cda14: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0x5cda18: add             SP, SP, #8
    // 0x5cda1c: stur            x0, [fp, #-0x18]
    // 0x5cda20: LoadField: r2 = r0->field_7
    //     0x5cda20: ldur            w2, [x0, #7]
    // 0x5cda24: DecompressPointer r2
    //     0x5cda24: add             x2, x2, HEAP, lsl #32
    // 0x5cda28: stur            x2, [fp, #-0x10]
    // 0x5cda2c: ldur            x1, [fp, #-8]
    // 0x5cda30: CheckStackOverflow
    //     0x5cda30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5cda34: cmp             SP, x16
    //     0x5cda38: b.ls            #0x5cdd44
    // 0x5cda3c: SaveReg r0
    //     0x5cda3c: str             x0, [SP, #-8]!
    // 0x5cda40: r0 = moveNext()
    //     0x5cda40: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x5cda44: add             SP, SP, #8
    // 0x5cda48: tbnz            w0, #4, #0x5cdd2c
    // 0x5cda4c: ldur            x3, [fp, #-0x18]
    // 0x5cda50: LoadField: r4 = r3->field_33
    //     0x5cda50: ldur            w4, [x3, #0x33]
    // 0x5cda54: DecompressPointer r4
    //     0x5cda54: add             x4, x4, HEAP, lsl #32
    // 0x5cda58: stur            x4, [fp, #-0x20]
    // 0x5cda5c: cmp             w4, NULL
    // 0x5cda60: b.ne            #0x5cda90
    // 0x5cda64: mov             x0, x4
    // 0x5cda68: ldur            x2, [fp, #-0x10]
    // 0x5cda6c: r1 = Null
    //     0x5cda6c: mov             x1, NULL
    // 0x5cda70: cmp             w2, NULL
    // 0x5cda74: b.eq            #0x5cda90
    // 0x5cda78: LoadField: r4 = r2->field_17
    //     0x5cda78: ldur            w4, [x2, #0x17]
    // 0x5cda7c: DecompressPointer r4
    //     0x5cda7c: add             x4, x4, HEAP, lsl #32
    // 0x5cda80: r8 = X0
    //     0x5cda80: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5cda84: LoadField: r9 = r4->field_7
    //     0x5cda84: ldur            x9, [x4, #7]
    // 0x5cda88: r3 = Null
    //     0x5cda88: ldr             x3, [PP, #0x4558]  ; [pp+0x4558] Null
    // 0x5cda8c: blr             x9
    // 0x5cda90: ldur            x2, [fp, #-8]
    // 0x5cda94: ldur            x1, [fp, #-0x20]
    // 0x5cda98: LoadField: r3 = r1->field_b
    //     0x5cda98: ldur            w3, [x1, #0xb]
    // 0x5cda9c: DecompressPointer r3
    //     0x5cda9c: add             x3, x3, HEAP, lsl #32
    // 0x5cdaa0: stur            x3, [fp, #-0x38]
    // 0x5cdaa4: LoadField: r4 = r2->field_f
    //     0x5cdaa4: ldur            w4, [x2, #0xf]
    // 0x5cdaa8: DecompressPointer r4
    //     0x5cdaa8: add             x4, x4, HEAP, lsl #32
    // 0x5cdaac: stur            x4, [fp, #-0x30]
    // 0x5cdab0: LoadField: r5 = r2->field_13
    //     0x5cdab0: ldur            w5, [x2, #0x13]
    // 0x5cdab4: DecompressPointer r5
    //     0x5cdab4: add             x5, x5, HEAP, lsl #32
    // 0x5cdab8: stur            x5, [fp, #-0x28]
    // 0x5cdabc: r0 = LoadClassIdInstr(r3)
    //     0x5cdabc: ldur            x0, [x3, #-1]
    //     0x5cdac0: ubfx            x0, x0, #0xc, #0x14
    // 0x5cdac4: SaveReg r3
    //     0x5cdac4: str             x3, [SP, #-8]!
    // 0x5cdac8: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x5cdac8: sub             lr, x0, #0xfd9
    //     0x5cdacc: ldr             lr, [x21, lr, lsl #3]
    //     0x5cdad0: blr             lr
    // 0x5cdad4: add             SP, SP, #8
    // 0x5cdad8: stur            x0, [fp, #-0x40]
    // 0x5cdadc: ldur            x16, [fp, #-0x20]
    // 0x5cdae0: SaveReg r16
    //     0x5cdae0: str             x16, [SP, #-8]!
    // 0x5cdae4: r0 = device()
    //     0x5cdae4: bl              #0x5cdd50  ; [package:flutter/src/rendering/mouse_tracker.dart] _MouseState::device
    // 0x5cdae8: add             SP, SP, #8
    // 0x5cdaec: mov             x3, x0
    // 0x5cdaf0: ldur            x2, [fp, #-0x30]
    // 0x5cdaf4: LoadField: r4 = r2->field_27
    //     0x5cdaf4: ldur            w4, [x2, #0x27]
    // 0x5cdaf8: DecompressPointer r4
    //     0x5cdaf8: add             x4, x4, HEAP, lsl #32
    // 0x5cdafc: r0 = BoxInt64Instr(r3)
    //     0x5cdafc: sbfiz           x0, x3, #1, #0x1f
    //     0x5cdb00: cmp             x3, x0, asr #1
    //     0x5cdb04: b.eq            #0x5cdb10
    //     0x5cdb08: bl              #0xd69bb8
    //     0x5cdb0c: stur            x3, [x0, #7]
    // 0x5cdb10: stp             x0, x4, [SP, #-0x10]!
    // 0x5cdb14: r0 = containsKey()
    //     0x5cdb14: bl              #0xca679c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x5cdb18: add             SP, SP, #0x10
    // 0x5cdb1c: tbz             w0, #4, #0x5cdbc4
    // 0x5cdb20: r1 = <MouseTrackerAnnotation, Matrix4>
    //     0x5cdb20: ldr             x1, [PP, #0x3970]  ; [pp+0x3970] TypeArguments: <MouseTrackerAnnotation, Matrix4>
    // 0x5cdb24: r0 = _Map()
    //     0x5cdb24: bl              #0x4b4914  ; Allocate_MapStub -> _Map<X0, X1> (size=-0x8)
    // 0x5cdb28: stur            x0, [fp, #-0x48]
    // 0x5cdb2c: SaveReg r0
    //     0x5cdb2c: str             x0, [SP, #-8]!
    // 0x5cdb30: r0 = Shader._()
    //     0x5cdb30: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x5cdb34: add             SP, SP, #8
    // 0x5cdb38: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x5cdb38: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5cdb3c: ldr             x0, [x0, #0x598]
    //     0x5cdb40: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5cdb44: cmp             w0, w16
    //     0x5cdb48: b.ne            #0x5cdb54
    //     0x5cdb4c: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x5cdb50: bl              #0xd67cdc
    // 0x5cdb54: ldur            x1, [fp, #-0x48]
    // 0x5cdb58: StoreField: r1->field_1b = r0
    //     0x5cdb58: stur            w0, [x1, #0x1b]
    //     0x5cdb5c: ldurb           w16, [x1, #-1]
    //     0x5cdb60: ldurb           w17, [x0, #-1]
    //     0x5cdb64: and             x16, x17, x16, lsr #2
    //     0x5cdb68: tst             x16, HEAP, lsr #32
    //     0x5cdb6c: b.eq            #0x5cdb74
    //     0x5cdb70: bl              #0xd6826c
    // 0x5cdb74: StoreField: r1->field_b = rZR
    //     0x5cdb74: stur            wzr, [x1, #0xb]
    // 0x5cdb78: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x5cdb78: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5cdb7c: ldr             x0, [x0, #0x5a0]
    //     0x5cdb80: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5cdb84: cmp             w0, w16
    //     0x5cdb88: b.ne            #0x5cdb94
    //     0x5cdb8c: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x5cdb90: bl              #0xd67cdc
    // 0x5cdb94: ldur            x1, [fp, #-0x48]
    // 0x5cdb98: StoreField: r1->field_f = r0
    //     0x5cdb98: stur            w0, [x1, #0xf]
    //     0x5cdb9c: ldurb           w16, [x1, #-1]
    //     0x5cdba0: ldurb           w17, [x0, #-1]
    //     0x5cdba4: and             x16, x17, x16, lsr #2
    //     0x5cdba8: tst             x16, HEAP, lsr #32
    //     0x5cdbac: b.eq            #0x5cdbb4
    //     0x5cdbb0: bl              #0xd6826c
    // 0x5cdbb4: StoreField: r1->field_13 = rZR
    //     0x5cdbb4: stur            wzr, [x1, #0x13]
    // 0x5cdbb8: StoreField: r1->field_17 = rZR
    //     0x5cdbb8: stur            wzr, [x1, #0x17]
    // 0x5cdbbc: mov             x4, x1
    // 0x5cdbc0: b               #0x5cdbfc
    // 0x5cdbc4: ldur            x0, [fp, #-0x28]
    // 0x5cdbc8: cmp             w0, NULL
    // 0x5cdbcc: b.eq            #0x5cdd4c
    // 0x5cdbd0: ldur            x16, [fp, #-0x40]
    // 0x5cdbd4: stp             x16, x0, [SP, #-0x10]!
    // 0x5cdbd8: ClosureCall
    //     0x5cdbd8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x5cdbdc: ldur            x2, [x0, #0x1f]
    //     0x5cdbe0: blr             x2
    // 0x5cdbe4: add             SP, SP, #0x10
    // 0x5cdbe8: ldur            x16, [fp, #-0x30]
    // 0x5cdbec: stp             x0, x16, [SP, #-0x10]!
    // 0x5cdbf0: r0 = _hitTestResultToAnnotations()
    //     0x5cdbf0: bl              #0x50d974  ; [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_hitTestResultToAnnotations
    // 0x5cdbf4: add             SP, SP, #0x10
    // 0x5cdbf8: mov             x4, x0
    // 0x5cdbfc: ldur            x2, [fp, #-8]
    // 0x5cdc00: ldur            x1, [fp, #-0x20]
    // 0x5cdc04: ldur            x3, [fp, #-0x38]
    // 0x5cdc08: stur            x4, [fp, #-0x30]
    // 0x5cdc0c: LoadField: r5 = r1->field_7
    //     0x5cdc0c: ldur            w5, [x1, #7]
    // 0x5cdc10: DecompressPointer r5
    //     0x5cdc10: add             x5, x5, HEAP, lsl #32
    // 0x5cdc14: mov             x0, x4
    // 0x5cdc18: stur            x5, [fp, #-0x28]
    // 0x5cdc1c: StoreField: r1->field_7 = r0
    //     0x5cdc1c: stur            w0, [x1, #7]
    //     0x5cdc20: ldurb           w16, [x1, #-1]
    //     0x5cdc24: ldurb           w17, [x0, #-1]
    //     0x5cdc28: and             x16, x17, x16, lsr #2
    //     0x5cdc2c: tst             x16, HEAP, lsr #32
    //     0x5cdc30: b.eq            #0x5cdc38
    //     0x5cdc34: bl              #0xd6826c
    // 0x5cdc38: LoadField: r0 = r2->field_f
    //     0x5cdc38: ldur            w0, [x2, #0xf]
    // 0x5cdc3c: DecompressPointer r0
    //     0x5cdc3c: add             x0, x0, HEAP, lsl #32
    // 0x5cdc40: stur            x0, [fp, #-0x20]
    // 0x5cdc44: r0 = _MouseTrackerUpdateDetails()
    //     0x5cdc44: bl              #0x50d90c  ; Allocate_MouseTrackerUpdateDetailsStub -> _MouseTrackerUpdateDetails (size=0x18)
    // 0x5cdc48: mov             x1, x0
    // 0x5cdc4c: ldur            x0, [fp, #-0x28]
    // 0x5cdc50: stur            x1, [fp, #-0x40]
    // 0x5cdc54: StoreField: r1->field_7 = r0
    //     0x5cdc54: stur            w0, [x1, #7]
    // 0x5cdc58: ldur            x0, [fp, #-0x30]
    // 0x5cdc5c: StoreField: r1->field_b = r0
    //     0x5cdc5c: stur            w0, [x1, #0xb]
    // 0x5cdc60: ldur            x2, [fp, #-0x38]
    // 0x5cdc64: StoreField: r1->field_f = r2
    //     0x5cdc64: stur            w2, [x1, #0xf]
    // 0x5cdc68: SaveReg r1
    //     0x5cdc68: str             x1, [SP, #-8]!
    // 0x5cdc6c: r0 = _handleDeviceUpdateMouseEvents()
    //     0x5cdc6c: bl              #0x50c9ec  ; [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_handleDeviceUpdateMouseEvents
    // 0x5cdc70: add             SP, SP, #8
    // 0x5cdc74: ldur            x0, [fp, #-0x20]
    // 0x5cdc78: LoadField: r1 = r0->field_23
    //     0x5cdc78: ldur            w1, [x0, #0x23]
    // 0x5cdc7c: DecompressPointer r1
    //     0x5cdc7c: add             x1, x1, HEAP, lsl #32
    // 0x5cdc80: ldur            x0, [fp, #-0x38]
    // 0x5cdc84: stur            x1, [fp, #-0x28]
    // 0x5cdc88: r2 = LoadClassIdInstr(r0)
    //     0x5cdc88: ldur            x2, [x0, #-1]
    //     0x5cdc8c: ubfx            x2, x2, #0xc, #0x14
    // 0x5cdc90: SaveReg r0
    //     0x5cdc90: str             x0, [SP, #-8]!
    // 0x5cdc94: mov             x0, x2
    // 0x5cdc98: r0 = GDT[cid_x0 + 0x8864]()
    //     0x5cdc98: mov             x17, #0x8864
    //     0x5cdc9c: add             lr, x0, x17
    //     0x5cdca0: ldr             lr, [x21, lr, lsl #3]
    //     0x5cdca4: blr             lr
    // 0x5cdca8: add             SP, SP, #8
    // 0x5cdcac: mov             x1, x0
    // 0x5cdcb0: ldur            x0, [fp, #-0x40]
    // 0x5cdcb4: stur            x1, [fp, #-0x50]
    // 0x5cdcb8: LoadField: r2 = r0->field_13
    //     0x5cdcb8: ldur            w2, [x0, #0x13]
    // 0x5cdcbc: DecompressPointer r2
    //     0x5cdcbc: add             x2, x2, HEAP, lsl #32
    // 0x5cdcc0: stur            x2, [fp, #-0x20]
    // 0x5cdcc4: ldur            x16, [fp, #-0x30]
    // 0x5cdcc8: SaveReg r16
    //     0x5cdcc8: str             x16, [SP, #-8]!
    // 0x5cdccc: r0 = keys()
    //     0x5cdccc: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0x5cdcd0: add             SP, SP, #8
    // 0x5cdcd4: r1 = Function '<anonymous closure>':.
    //     0x5cdcd4: ldr             x1, [PP, #0x3978]  ; [pp+0x3978] AnonymousClosure: (0x50d8bc), in [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_handleDeviceUpdate (0x50c3b4)
    // 0x5cdcd8: r2 = Null
    //     0x5cdcd8: mov             x2, NULL
    // 0x5cdcdc: stur            x0, [fp, #-0x30]
    // 0x5cdce0: r0 = AllocateClosure()
    //     0x5cdce0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5cdce4: r16 = <MouseCursor>
    //     0x5cdce4: ldr             x16, [PP, #0x3980]  ; [pp+0x3980] TypeArguments: <MouseCursor>
    // 0x5cdce8: ldur            lr, [fp, #-0x30]
    // 0x5cdcec: stp             lr, x16, [SP, #-0x10]!
    // 0x5cdcf0: SaveReg r0
    //     0x5cdcf0: str             x0, [SP, #-8]!
    // 0x5cdcf4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5cdcf4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5cdcf8: r0 = map()
    //     0x5cdcf8: bl              #0x6ba600  ; [dart:core] Iterable::map
    // 0x5cdcfc: add             SP, SP, #0x18
    // 0x5cdd00: ldur            x16, [fp, #-0x28]
    // 0x5cdd04: SaveReg r16
    //     0x5cdd04: str             x16, [SP, #-8]!
    // 0x5cdd08: ldur            x1, [fp, #-0x50]
    // 0x5cdd0c: ldur            x16, [fp, #-0x20]
    // 0x5cdd10: stp             x16, x1, [SP, #-0x10]!
    // 0x5cdd14: SaveReg r0
    //     0x5cdd14: str             x0, [SP, #-8]!
    // 0x5cdd18: r0 = handleDeviceCursorUpdate()
    //     0x5cdd18: bl              #0x50c48c  ; [package:flutter/src/services/mouse_cursor.dart] MouseCursorManager::handleDeviceCursorUpdate
    // 0x5cdd1c: add             SP, SP, #0x20
    // 0x5cdd20: ldur            x0, [fp, #-0x18]
    // 0x5cdd24: ldur            x2, [fp, #-0x10]
    // 0x5cdd28: b               #0x5cda2c
    // 0x5cdd2c: r0 = Null
    //     0x5cdd2c: mov             x0, NULL
    // 0x5cdd30: LeaveFrame
    //     0x5cdd30: mov             SP, fp
    //     0x5cdd34: ldp             fp, lr, [SP], #0x10
    // 0x5cdd38: ret
    //     0x5cdd38: ret             
    // 0x5cdd3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5cdd3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5cdd40: b               #0x5cd9f4
    // 0x5cdd44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5cdd44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5cdd48: b               #0x5cda3c
    // 0x5cdd4c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x5cdd4c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
}

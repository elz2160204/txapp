// lib: , url: package:flutter/src/rendering/sliver_list.dart

// class id: 1049424, size: 0x8
class :: {
}

// class id: 2585, size: 0x6c, field offset: 0x6c
class RenderSliverList extends RenderSliverMultiBoxAdaptor {

  _ performLayout(/* No info */) {
    // ** addr: 0x67d40c, size: 0x19b4
    // 0x67d40c: EnterFrame
    //     0x67d40c: stp             fp, lr, [SP, #-0x10]!
    //     0x67d410: mov             fp, SP
    // 0x67d414: AllocStack(0x90)
    //     0x67d414: sub             SP, SP, #0x90
    // 0x67d418: CheckStackOverflow
    //     0x67d418: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67d41c: cmp             SP, x16
    //     0x67d420: b.ls            #0x67ec3c
    // 0x67d424: r1 = 7
    //     0x67d424: mov             x1, #7
    // 0x67d428: r0 = AllocateContext()
    //     0x67d428: bl              #0xd68aa4  ; AllocateContextStub
    // 0x67d42c: mov             x4, x0
    // 0x67d430: ldr             x3, [fp, #0x10]
    // 0x67d434: stur            x4, [fp, #-0x10]
    // 0x67d438: StoreField: r4->field_f = r3
    //     0x67d438: stur            w3, [x4, #0xf]
    // 0x67d43c: LoadField: r5 = r3->field_27
    //     0x67d43c: ldur            w5, [x3, #0x27]
    // 0x67d440: DecompressPointer r5
    //     0x67d440: add             x5, x5, HEAP, lsl #32
    // 0x67d444: stur            x5, [fp, #-8]
    // 0x67d448: cmp             w5, NULL
    // 0x67d44c: b.eq            #0x67ebf4
    // 0x67d450: r6 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x67d450: add             x6, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x67d454: ldr             x6, [x6, #0x1e8]
    // 0x67d458: mov             x0, x5
    // 0x67d45c: r2 = Null
    //     0x67d45c: mov             x2, NULL
    // 0x67d460: r1 = Null
    //     0x67d460: mov             x1, NULL
    // 0x67d464: r4 = LoadClassIdInstr(r0)
    //     0x67d464: ldur            x4, [x0, #-1]
    //     0x67d468: ubfx            x4, x4, #0xc, #0x14
    // 0x67d46c: cmp             x4, #0x80c
    // 0x67d470: b.eq            #0x67d488
    // 0x67d474: r8 = SliverConstraints
    //     0x67d474: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x67d478: ldr             x8, [x8, #0x5a8]
    // 0x67d47c: r3 = Null
    //     0x67d47c: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4aec8] Null
    //     0x67d480: ldr             x3, [x3, #0xec8]
    // 0x67d484: r0 = DefaultTypeTest()
    //     0x67d484: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67d488: ldr             x0, [fp, #0x10]
    // 0x67d48c: LoadField: r1 = r0->field_63
    //     0x67d48c: ldur            w1, [x0, #0x63]
    // 0x67d490: DecompressPointer r1
    //     0x67d490: add             x1, x1, HEAP, lsl #32
    // 0x67d494: stur            x1, [fp, #-0x18]
    // 0x67d498: r2 = false
    //     0x67d498: add             x2, NULL, #0x30  ; false
    // 0x67d49c: StoreField: r1->field_53 = r2
    //     0x67d49c: stur            w2, [x1, #0x53]
    // 0x67d4a0: ldur            x3, [fp, #-8]
    // 0x67d4a4: LoadField: d0 = r3->field_13
    //     0x67d4a4: ldur            d0, [x3, #0x13]
    // 0x67d4a8: stur            d0, [fp, #-0x78]
    // 0x67d4ac: LoadField: d1 = r3->field_47
    //     0x67d4ac: ldur            d1, [x3, #0x47]
    // 0x67d4b0: fadd            d2, d0, d1
    // 0x67d4b4: stur            d2, [fp, #-0x70]
    // 0x67d4b8: LoadField: d1 = r3->field_4f
    //     0x67d4b8: ldur            d1, [x3, #0x4f]
    // 0x67d4bc: fadd            d3, d2, d1
    // 0x67d4c0: stur            d3, [fp, #-0x68]
    // 0x67d4c4: SaveReg r3
    //     0x67d4c4: str             x3, [SP, #-8]!
    // 0x67d4c8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x67d4c8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x67d4cc: r0 = asBoxConstraints()
    //     0x67d4cc: bl              #0x67a528  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::asBoxConstraints
    // 0x67d4d0: add             SP, SP, #8
    // 0x67d4d4: mov             x1, x0
    // 0x67d4d8: ldur            x2, [fp, #-0x10]
    // 0x67d4dc: stur            x1, [fp, #-0x20]
    // 0x67d4e0: StoreField: r2->field_13 = r0
    //     0x67d4e0: stur            w0, [x2, #0x13]
    //     0x67d4e4: ldurb           w16, [x2, #-1]
    //     0x67d4e8: ldurb           w17, [x0, #-1]
    //     0x67d4ec: and             x16, x17, x16, lsr #2
    //     0x67d4f0: tst             x16, HEAP, lsr #32
    //     0x67d4f4: b.eq            #0x67d4fc
    //     0x67d4f8: bl              #0xd6828c
    // 0x67d4fc: ldr             x0, [fp, #0x10]
    // 0x67d500: LoadField: r3 = r0->field_5b
    //     0x67d500: ldur            w3, [x0, #0x5b]
    // 0x67d504: DecompressPointer r3
    //     0x67d504: add             x3, x3, HEAP, lsl #32
    // 0x67d508: cmp             w3, NULL
    // 0x67d50c: b.ne            #0x67d564
    // 0x67d510: SaveReg r0
    //     0x67d510: str             x0, [SP, #-8]!
    // 0x67d514: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x67d514: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x67d518: r0 = addInitialChild()
    //     0x67d518: bl              #0x6795e8  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::addInitialChild
    // 0x67d51c: add             SP, SP, #8
    // 0x67d520: tbz             w0, #4, #0x67d554
    // 0x67d524: ldr             x3, [fp, #0x10]
    // 0x67d528: r4 = Instance_SliverGeometry
    //     0x67d528: add             x4, PP, #0x2d, lsl #12  ; [pp+0x2d608] Obj!SliverGeometry@b3bed1
    //     0x67d52c: ldr             x4, [x4, #0x608]
    // 0x67d530: StoreField: r3->field_4f = r4
    //     0x67d530: stur            w4, [x3, #0x4f]
    // 0x67d534: ldur            x16, [fp, #-0x18]
    // 0x67d538: SaveReg r16
    //     0x67d538: str             x16, [SP, #-8]!
    // 0x67d53c: r0 = didFinishLayout()
    //     0x67d53c: bl              #0x678c84  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::didFinishLayout
    // 0x67d540: add             SP, SP, #8
    // 0x67d544: r0 = Null
    //     0x67d544: mov             x0, NULL
    // 0x67d548: LeaveFrame
    //     0x67d548: mov             SP, fp
    //     0x67d54c: ldp             fp, lr, [SP], #0x10
    // 0x67d550: ret
    //     0x67d550: ret             
    // 0x67d554: ldr             x3, [fp, #0x10]
    // 0x67d558: r4 = Instance_SliverGeometry
    //     0x67d558: add             x4, PP, #0x2d, lsl #12  ; [pp+0x2d608] Obj!SliverGeometry@b3bed1
    //     0x67d55c: ldr             x4, [x4, #0x608]
    // 0x67d560: b               #0x67d570
    // 0x67d564: mov             x3, x0
    // 0x67d568: r4 = Instance_SliverGeometry
    //     0x67d568: add             x4, PP, #0x2d, lsl #12  ; [pp+0x2d608] Obj!SliverGeometry@b3bed1
    //     0x67d56c: ldr             x4, [x4, #0x608]
    // 0x67d570: ldur            x5, [fp, #-0x10]
    // 0x67d574: StoreField: r5->field_17 = rNULL
    //     0x67d574: stur            NULL, [x5, #0x17]
    // 0x67d578: LoadField: r6 = r3->field_5b
    //     0x67d578: ldur            w6, [x3, #0x5b]
    // 0x67d57c: DecompressPointer r6
    //     0x67d57c: add             x6, x6, HEAP, lsl #32
    // 0x67d580: stur            x6, [fp, #-0x28]
    // 0x67d584: cmp             w6, NULL
    // 0x67d588: b.eq            #0x67ec44
    // 0x67d58c: mov             x0, x6
    // 0x67d590: r2 = Null
    //     0x67d590: mov             x2, NULL
    // 0x67d594: r1 = Null
    //     0x67d594: mov             x1, NULL
    // 0x67d598: r4 = LoadClassIdInstr(r0)
    //     0x67d598: ldur            x4, [x0, #-1]
    //     0x67d59c: ubfx            x4, x4, #0xc, #0x14
    // 0x67d5a0: sub             x4, x4, #0x961
    // 0x67d5a4: cmp             x4, #0xbe
    // 0x67d5a8: b.ls            #0x67d5bc
    // 0x67d5ac: r8 = RenderObject
    //     0x67d5ac: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x67d5b0: r3 = Null
    //     0x67d5b0: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4aed8] Null
    //     0x67d5b4: ldr             x3, [x3, #0xed8]
    // 0x67d5b8: r0 = RenderObject()
    //     0x67d5b8: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x67d5bc: ldur            x3, [fp, #-0x28]
    // 0x67d5c0: LoadField: r4 = r3->field_17
    //     0x67d5c0: ldur            w4, [x3, #0x17]
    // 0x67d5c4: DecompressPointer r4
    //     0x67d5c4: add             x4, x4, HEAP, lsl #32
    // 0x67d5c8: stur            x4, [fp, #-0x30]
    // 0x67d5cc: cmp             w4, NULL
    // 0x67d5d0: b.eq            #0x67ec48
    // 0x67d5d4: mov             x0, x4
    // 0x67d5d8: r2 = Null
    //     0x67d5d8: mov             x2, NULL
    // 0x67d5dc: r1 = Null
    //     0x67d5dc: mov             x1, NULL
    // 0x67d5e0: r4 = LoadClassIdInstr(r0)
    //     0x67d5e0: ldur            x4, [x0, #-1]
    //     0x67d5e4: ubfx            x4, x4, #0xc, #0x14
    // 0x67d5e8: sub             x4, x4, #0x7f9
    // 0x67d5ec: cmp             x4, #2
    // 0x67d5f0: b.ls            #0x67d608
    // 0x67d5f4: r8 = SliverMultiBoxAdaptorParentData
    //     0x67d5f4: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67d5f8: ldr             x8, [x8, #0x120]
    // 0x67d5fc: r3 = Null
    //     0x67d5fc: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4aee8] Null
    //     0x67d600: ldr             x3, [x3, #0xee8]
    // 0x67d604: r0 = DefaultTypeTest()
    //     0x67d604: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67d608: ldur            x0, [fp, #-0x30]
    // 0x67d60c: LoadField: r1 = r0->field_7
    //     0x67d60c: ldur            w1, [x0, #7]
    // 0x67d610: DecompressPointer r1
    //     0x67d610: add             x1, x1, HEAP, lsl #32
    // 0x67d614: cmp             w1, NULL
    // 0x67d618: b.ne            #0x67d780
    // 0x67d61c: ldur            x4, [fp, #-0x28]
    // 0x67d620: r3 = 0
    //     0x67d620: mov             x3, #0
    // 0x67d624: stur            x4, [fp, #-0x28]
    // 0x67d628: stur            x3, [fp, #-0x38]
    // 0x67d62c: CheckStackOverflow
    //     0x67d62c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67d630: cmp             SP, x16
    //     0x67d634: b.ls            #0x67ec4c
    // 0x67d638: cmp             w4, NULL
    // 0x67d63c: b.eq            #0x67d6ec
    // 0x67d640: mov             x0, x4
    // 0x67d644: r2 = Null
    //     0x67d644: mov             x2, NULL
    // 0x67d648: r1 = Null
    //     0x67d648: mov             x1, NULL
    // 0x67d64c: r4 = LoadClassIdInstr(r0)
    //     0x67d64c: ldur            x4, [x0, #-1]
    //     0x67d650: ubfx            x4, x4, #0xc, #0x14
    // 0x67d654: sub             x4, x4, #0x961
    // 0x67d658: cmp             x4, #0xbe
    // 0x67d65c: b.ls            #0x67d670
    // 0x67d660: r8 = RenderObject
    //     0x67d660: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x67d664: r3 = Null
    //     0x67d664: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4aef8] Null
    //     0x67d668: ldr             x3, [x3, #0xef8]
    // 0x67d66c: r0 = RenderObject()
    //     0x67d66c: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x67d670: ldur            x0, [fp, #-0x28]
    // 0x67d674: LoadField: r3 = r0->field_17
    //     0x67d674: ldur            w3, [x0, #0x17]
    // 0x67d678: DecompressPointer r3
    //     0x67d678: add             x3, x3, HEAP, lsl #32
    // 0x67d67c: stur            x3, [fp, #-0x30]
    // 0x67d680: cmp             w3, NULL
    // 0x67d684: b.eq            #0x67ec54
    // 0x67d688: mov             x0, x3
    // 0x67d68c: r2 = Null
    //     0x67d68c: mov             x2, NULL
    // 0x67d690: r1 = Null
    //     0x67d690: mov             x1, NULL
    // 0x67d694: r4 = LoadClassIdInstr(r0)
    //     0x67d694: ldur            x4, [x0, #-1]
    //     0x67d698: ubfx            x4, x4, #0xc, #0x14
    // 0x67d69c: sub             x4, x4, #0x7f9
    // 0x67d6a0: cmp             x4, #2
    // 0x67d6a4: b.ls            #0x67d6bc
    // 0x67d6a8: r8 = SliverMultiBoxAdaptorParentData
    //     0x67d6a8: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67d6ac: ldr             x8, [x8, #0x120]
    // 0x67d6b0: r3 = Null
    //     0x67d6b0: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4af08] Null
    //     0x67d6b4: ldr             x3, [x3, #0xf08]
    // 0x67d6b8: r0 = DefaultTypeTest()
    //     0x67d6b8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67d6bc: ldur            x0, [fp, #-0x30]
    // 0x67d6c0: LoadField: r1 = r0->field_7
    //     0x67d6c0: ldur            w1, [x0, #7]
    // 0x67d6c4: DecompressPointer r1
    //     0x67d6c4: add             x1, x1, HEAP, lsl #32
    // 0x67d6c8: cmp             w1, NULL
    // 0x67d6cc: b.ne            #0x67d6e4
    // 0x67d6d0: ldur            x2, [fp, #-0x38]
    // 0x67d6d4: LoadField: r4 = r0->field_f
    //     0x67d6d4: ldur            w4, [x0, #0xf]
    // 0x67d6d8: DecompressPointer r4
    //     0x67d6d8: add             x4, x4, HEAP, lsl #32
    // 0x67d6dc: add             x3, x2, #1
    // 0x67d6e0: b               #0x67d624
    // 0x67d6e4: ldur            x2, [fp, #-0x38]
    // 0x67d6e8: b               #0x67d6f0
    // 0x67d6ec: mov             x2, x3
    // 0x67d6f0: ldr             x3, [fp, #0x10]
    // 0x67d6f4: r0 = BoxInt64Instr(r2)
    //     0x67d6f4: sbfiz           x0, x2, #1, #0x1f
    //     0x67d6f8: cmp             x2, x0, asr #1
    //     0x67d6fc: b.eq            #0x67d708
    //     0x67d700: bl              #0xd69bb8
    //     0x67d704: stur            x2, [x0, #7]
    // 0x67d708: stp             x0, x3, [SP, #-0x10]!
    // 0x67d70c: SaveReg rZR
    //     0x67d70c: str             xzr, [SP, #-8]!
    // 0x67d710: r0 = collectGarbage()
    //     0x67d710: bl              #0x6797bc  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::collectGarbage
    // 0x67d714: add             SP, SP, #0x18
    // 0x67d718: ldr             x0, [fp, #0x10]
    // 0x67d71c: LoadField: r1 = r0->field_5b
    //     0x67d71c: ldur            w1, [x0, #0x5b]
    // 0x67d720: DecompressPointer r1
    //     0x67d720: add             x1, x1, HEAP, lsl #32
    // 0x67d724: cmp             w1, NULL
    // 0x67d728: b.ne            #0x67d778
    // 0x67d72c: SaveReg r0
    //     0x67d72c: str             x0, [SP, #-8]!
    // 0x67d730: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x67d730: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x67d734: r0 = addInitialChild()
    //     0x67d734: bl              #0x6795e8  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::addInitialChild
    // 0x67d738: add             SP, SP, #8
    // 0x67d73c: tbz             w0, #4, #0x67d770
    // 0x67d740: ldr             x3, [fp, #0x10]
    // 0x67d744: r0 = Instance_SliverGeometry
    //     0x67d744: add             x0, PP, #0x2d, lsl #12  ; [pp+0x2d608] Obj!SliverGeometry@b3bed1
    //     0x67d748: ldr             x0, [x0, #0x608]
    // 0x67d74c: StoreField: r3->field_4f = r0
    //     0x67d74c: stur            w0, [x3, #0x4f]
    // 0x67d750: ldur            x16, [fp, #-0x18]
    // 0x67d754: SaveReg r16
    //     0x67d754: str             x16, [SP, #-8]!
    // 0x67d758: r0 = didFinishLayout()
    //     0x67d758: bl              #0x678c84  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::didFinishLayout
    // 0x67d75c: add             SP, SP, #8
    // 0x67d760: r0 = Null
    //     0x67d760: mov             x0, NULL
    // 0x67d764: LeaveFrame
    //     0x67d764: mov             SP, fp
    //     0x67d768: ldp             fp, lr, [SP], #0x10
    // 0x67d76c: ret
    //     0x67d76c: ret             
    // 0x67d770: ldr             x3, [fp, #0x10]
    // 0x67d774: b               #0x67d784
    // 0x67d778: mov             x3, x0
    // 0x67d77c: b               #0x67d784
    // 0x67d780: ldr             x3, [fp, #0x10]
    // 0x67d784: LoadField: r4 = r3->field_5b
    //     0x67d784: ldur            w4, [x3, #0x5b]
    // 0x67d788: DecompressPointer r4
    //     0x67d788: add             x4, x4, HEAP, lsl #32
    // 0x67d78c: stur            x4, [fp, #-0x28]
    // 0x67d790: cmp             w4, NULL
    // 0x67d794: b.eq            #0x67ec58
    // 0x67d798: mov             x0, x4
    // 0x67d79c: r2 = Null
    //     0x67d79c: mov             x2, NULL
    // 0x67d7a0: r1 = Null
    //     0x67d7a0: mov             x1, NULL
    // 0x67d7a4: r4 = LoadClassIdInstr(r0)
    //     0x67d7a4: ldur            x4, [x0, #-1]
    //     0x67d7a8: ubfx            x4, x4, #0xc, #0x14
    // 0x67d7ac: sub             x4, x4, #0x961
    // 0x67d7b0: cmp             x4, #0xbe
    // 0x67d7b4: b.ls            #0x67d7c8
    // 0x67d7b8: r8 = RenderObject
    //     0x67d7b8: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x67d7bc: r3 = Null
    //     0x67d7bc: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4af18] Null
    //     0x67d7c0: ldr             x3, [x3, #0xf18]
    // 0x67d7c4: r0 = RenderObject()
    //     0x67d7c4: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x67d7c8: ldur            x3, [fp, #-0x28]
    // 0x67d7cc: LoadField: r4 = r3->field_17
    //     0x67d7cc: ldur            w4, [x3, #0x17]
    // 0x67d7d0: DecompressPointer r4
    //     0x67d7d0: add             x4, x4, HEAP, lsl #32
    // 0x67d7d4: stur            x4, [fp, #-0x30]
    // 0x67d7d8: cmp             w4, NULL
    // 0x67d7dc: b.eq            #0x67ec5c
    // 0x67d7e0: mov             x0, x4
    // 0x67d7e4: r2 = Null
    //     0x67d7e4: mov             x2, NULL
    // 0x67d7e8: r1 = Null
    //     0x67d7e8: mov             x1, NULL
    // 0x67d7ec: r4 = LoadClassIdInstr(r0)
    //     0x67d7ec: ldur            x4, [x0, #-1]
    //     0x67d7f0: ubfx            x4, x4, #0xc, #0x14
    // 0x67d7f4: sub             x4, x4, #0x7f9
    // 0x67d7f8: cmp             x4, #2
    // 0x67d7fc: b.ls            #0x67d814
    // 0x67d800: r8 = SliverMultiBoxAdaptorParentData
    //     0x67d800: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67d804: ldr             x8, [x8, #0x120]
    // 0x67d808: r3 = Null
    //     0x67d808: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4af28] Null
    //     0x67d80c: ldr             x3, [x3, #0xf28]
    // 0x67d810: r0 = DefaultTypeTest()
    //     0x67d810: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67d814: ldur            x0, [fp, #-0x30]
    // 0x67d818: LoadField: r1 = r0->field_7
    //     0x67d818: ldur            w1, [x0, #7]
    // 0x67d81c: DecompressPointer r1
    //     0x67d81c: add             x1, x1, HEAP, lsl #32
    // 0x67d820: cmp             w1, NULL
    // 0x67d824: b.eq            #0x67ec60
    // 0x67d828: LoadField: d0 = r1->field_7
    //     0x67d828: ldur            d0, [x1, #7]
    // 0x67d82c: d1 = 0.000000
    //     0x67d82c: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1e0] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    //     0x67d830: ldr             d1, [x17, #0x1e0]
    // 0x67d834: fneg            d2, d1
    // 0x67d838: stur            d2, [fp, #-0x88]
    // 0x67d83c: ldur            x1, [fp, #-0x28]
    // 0x67d840: mov             v3.16b, v0.16b
    // 0x67d844: r3 = Null
    //     0x67d844: mov             x3, NULL
    // 0x67d848: ldr             x0, [fp, #0x10]
    // 0x67d84c: ldur            x2, [fp, #-0x10]
    // 0x67d850: ldur            d0, [fp, #-0x70]
    // 0x67d854: stur            d3, [fp, #-0x80]
    // 0x67d858: CheckStackOverflow
    //     0x67d858: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67d85c: cmp             SP, x16
    //     0x67d860: b.ls            #0x67ec64
    // 0x67d864: fcmp            d3, d0
    // 0x67d868: b.vs            #0x67dd9c
    // 0x67d86c: b.le            #0x67dd9c
    // 0x67d870: ldur            x16, [fp, #-0x20]
    // 0x67d874: stp             x16, x0, [SP, #-0x10]!
    // 0x67d878: r16 = true
    //     0x67d878: add             x16, NULL, #0x20  ; true
    // 0x67d87c: SaveReg r16
    //     0x67d87c: str             x16, [SP, #-8]!
    // 0x67d880: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x67d880: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x67d884: ldr             x4, [x4, #0x1c8]
    // 0x67d888: r0 = insertAndLayoutLeadingChild()
    //     0x67d888: bl              #0x678a4c  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::insertAndLayoutLeadingChild
    // 0x67d88c: add             SP, SP, #0x18
    // 0x67d890: mov             x3, x0
    // 0x67d894: stur            x3, [fp, #-0x40]
    // 0x67d898: cmp             w3, NULL
    // 0x67d89c: b.ne            #0x67da6c
    // 0x67d8a0: ldr             x3, [fp, #0x10]
    // 0x67d8a4: ldur            d0, [fp, #-0x70]
    // 0x67d8a8: LoadField: r4 = r3->field_5b
    //     0x67d8a8: ldur            w4, [x3, #0x5b]
    // 0x67d8ac: DecompressPointer r4
    //     0x67d8ac: add             x4, x4, HEAP, lsl #32
    // 0x67d8b0: stur            x4, [fp, #-0x30]
    // 0x67d8b4: cmp             w4, NULL
    // 0x67d8b8: b.eq            #0x67ec6c
    // 0x67d8bc: LoadField: r5 = r4->field_17
    //     0x67d8bc: ldur            w5, [x4, #0x17]
    // 0x67d8c0: DecompressPointer r5
    //     0x67d8c0: add             x5, x5, HEAP, lsl #32
    // 0x67d8c4: stur            x5, [fp, #-0x28]
    // 0x67d8c8: cmp             w5, NULL
    // 0x67d8cc: b.eq            #0x67ec70
    // 0x67d8d0: mov             x0, x5
    // 0x67d8d4: r2 = Null
    //     0x67d8d4: mov             x2, NULL
    // 0x67d8d8: r1 = Null
    //     0x67d8d8: mov             x1, NULL
    // 0x67d8dc: r4 = LoadClassIdInstr(r0)
    //     0x67d8dc: ldur            x4, [x0, #-1]
    //     0x67d8e0: ubfx            x4, x4, #0xc, #0x14
    // 0x67d8e4: sub             x4, x4, #0x7f9
    // 0x67d8e8: cmp             x4, #2
    // 0x67d8ec: b.ls            #0x67d904
    // 0x67d8f0: r8 = SliverMultiBoxAdaptorParentData
    //     0x67d8f0: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67d8f4: ldr             x8, [x8, #0x120]
    // 0x67d8f8: r3 = Null
    //     0x67d8f8: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4af38] Null
    //     0x67d8fc: ldr             x3, [x3, #0xf38]
    // 0x67d900: r0 = DefaultTypeTest()
    //     0x67d900: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67d904: ldur            x0, [fp, #-0x28]
    // 0x67d908: r1 = 0.000000
    //     0x67d908: ldr             x1, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x67d90c: StoreField: r0->field_7 = r1
    //     0x67d90c: stur            w1, [x0, #7]
    // 0x67d910: ldur            d0, [fp, #-0x70]
    // 0x67d914: d1 = 0.000000
    //     0x67d914: eor             v1.16b, v1.16b, v1.16b
    // 0x67d918: fcmp            d0, d1
    // 0x67d91c: b.vs            #0x67d9b4
    // 0x67d920: b.ne            #0x67d9b4
    // 0x67d924: ldr             x2, [fp, #0x10]
    // 0x67d928: ldur            x3, [fp, #-0x10]
    // 0x67d92c: ldur            x0, [fp, #-0x30]
    // 0x67d930: r4 = LoadClassIdInstr(r0)
    //     0x67d930: ldur            x4, [x0, #-1]
    //     0x67d934: ubfx            x4, x4, #0xc, #0x14
    // 0x67d938: ldur            x16, [fp, #-0x20]
    // 0x67d93c: stp             x16, x0, [SP, #-0x10]!
    // 0x67d940: r16 = true
    //     0x67d940: add             x16, NULL, #0x20  ; true
    // 0x67d944: SaveReg r16
    //     0x67d944: str             x16, [SP, #-8]!
    // 0x67d948: mov             x0, x4
    // 0x67d94c: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x67d94c: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x67d950: ldr             x4, [x4, #0x1c8]
    // 0x67d954: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x67d954: mov             x17, #0xcdfb
    //     0x67d958: add             lr, x0, x17
    //     0x67d95c: ldr             lr, [x21, lr, lsl #3]
    //     0x67d960: blr             lr
    // 0x67d964: add             SP, SP, #0x18
    // 0x67d968: ldr             x1, [fp, #0x10]
    // 0x67d96c: LoadField: r2 = r1->field_5b
    //     0x67d96c: ldur            w2, [x1, #0x5b]
    // 0x67d970: DecompressPointer r2
    //     0x67d970: add             x2, x2, HEAP, lsl #32
    // 0x67d974: ldur            x4, [fp, #-0x10]
    // 0x67d978: LoadField: r0 = r4->field_17
    //     0x67d978: ldur            w0, [x4, #0x17]
    // 0x67d97c: DecompressPointer r0
    //     0x67d97c: add             x0, x0, HEAP, lsl #32
    // 0x67d980: cmp             w0, NULL
    // 0x67d984: b.ne            #0x67d9a8
    // 0x67d988: mov             x0, x2
    // 0x67d98c: StoreField: r4->field_17 = r0
    //     0x67d98c: stur            w0, [x4, #0x17]
    //     0x67d990: ldurb           w16, [x4, #-1]
    //     0x67d994: ldurb           w17, [x0, #-1]
    //     0x67d998: and             x16, x17, x16, lsr #2
    //     0x67d99c: tst             x16, HEAP, lsr #32
    //     0x67d9a0: b.eq            #0x67d9a8
    //     0x67d9a4: bl              #0xd682cc
    // 0x67d9a8: mov             x3, x2
    // 0x67d9ac: mov             x0, x2
    // 0x67d9b0: b               #0x67dda0
    // 0x67d9b4: ldr             x1, [fp, #0x10]
    // 0x67d9b8: fneg            d1, d0
    // 0x67d9bc: stur            d1, [fp, #-0x90]
    // 0x67d9c0: r0 = SliverGeometry()
    //     0x67d9c0: bl              #0x679334  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x54)
    // 0x67d9c4: d1 = 0.000000
    //     0x67d9c4: eor             v1.16b, v1.16b, v1.16b
    // 0x67d9c8: StoreField: r0->field_7 = d1
    //     0x67d9c8: stur            d1, [x0, #7]
    // 0x67d9cc: StoreField: r0->field_17 = d1
    //     0x67d9cc: stur            d1, [x0, #0x17]
    // 0x67d9d0: StoreField: r0->field_f = d1
    //     0x67d9d0: stur            d1, [x0, #0xf]
    // 0x67d9d4: StoreField: r0->field_27 = d1
    //     0x67d9d4: stur            d1, [x0, #0x27]
    // 0x67d9d8: StoreField: r0->field_2f = d1
    //     0x67d9d8: stur            d1, [x0, #0x2f]
    // 0x67d9dc: r5 = false
    //     0x67d9dc: add             x5, NULL, #0x30  ; false
    // 0x67d9e0: StoreField: r0->field_43 = r5
    //     0x67d9e0: stur            w5, [x0, #0x43]
    // 0x67d9e4: ldur            d0, [fp, #-0x90]
    // 0x67d9e8: r1 = inline_Allocate_Double()
    //     0x67d9e8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x67d9ec: add             x1, x1, #0x10
    //     0x67d9f0: cmp             x2, x1
    //     0x67d9f4: b.ls            #0x67ec74
    //     0x67d9f8: str             x1, [THR, #0x60]  ; THR::top
    //     0x67d9fc: sub             x1, x1, #0xf
    //     0x67da00: mov             x2, #0xd108
    //     0x67da04: movk            x2, #3, lsl #16
    //     0x67da08: stur            x2, [x1, #-1]
    // 0x67da0c: StoreField: r1->field_7 = d0
    //     0x67da0c: stur            d0, [x1, #7]
    // 0x67da10: StoreField: r0->field_47 = r1
    //     0x67da10: stur            w1, [x0, #0x47]
    // 0x67da14: StoreField: r0->field_1f = d1
    //     0x67da14: stur            d1, [x0, #0x1f]
    // 0x67da18: StoreField: r0->field_37 = d1
    //     0x67da18: stur            d1, [x0, #0x37]
    // 0x67da1c: StoreField: r0->field_4b = d1
    //     0x67da1c: stur            d1, [x0, #0x4b]
    // 0x67da20: fcmp            d1, d1
    // 0x67da24: b.vs            #0x67da2c
    // 0x67da28: b.gt            #0x67da34
    // 0x67da2c: r1 = false
    //     0x67da2c: add             x1, NULL, #0x30  ; false
    // 0x67da30: b               #0x67da38
    // 0x67da34: r1 = true
    //     0x67da34: add             x1, NULL, #0x20  ; true
    // 0x67da38: StoreField: r0->field_3f = r1
    //     0x67da38: stur            w1, [x0, #0x3f]
    // 0x67da3c: ldr             x6, [fp, #0x10]
    // 0x67da40: StoreField: r6->field_4f = r0
    //     0x67da40: stur            w0, [x6, #0x4f]
    //     0x67da44: ldurb           w16, [x6, #-1]
    //     0x67da48: ldurb           w17, [x0, #-1]
    //     0x67da4c: and             x16, x17, x16, lsr #2
    //     0x67da50: tst             x16, HEAP, lsr #32
    //     0x67da54: b.eq            #0x67da5c
    //     0x67da58: bl              #0xd6830c
    // 0x67da5c: r0 = Null
    //     0x67da5c: mov             x0, NULL
    // 0x67da60: LeaveFrame
    //     0x67da60: mov             SP, fp
    //     0x67da64: ldp             fp, lr, [SP], #0x10
    // 0x67da68: ret
    //     0x67da68: ret             
    // 0x67da6c: ldr             x6, [fp, #0x10]
    // 0x67da70: ldur            x4, [fp, #-0x10]
    // 0x67da74: ldur            d0, [fp, #-0x70]
    // 0x67da78: r5 = false
    //     0x67da78: add             x5, NULL, #0x30  ; false
    // 0x67da7c: d1 = 0.000000
    //     0x67da7c: eor             v1.16b, v1.16b, v1.16b
    // 0x67da80: LoadField: r7 = r6->field_5b
    //     0x67da80: ldur            w7, [x6, #0x5b]
    // 0x67da84: DecompressPointer r7
    //     0x67da84: add             x7, x7, HEAP, lsl #32
    // 0x67da88: stur            x7, [fp, #-0x30]
    // 0x67da8c: cmp             w7, NULL
    // 0x67da90: b.eq            #0x67ec90
    // 0x67da94: LoadField: r8 = r6->field_27
    //     0x67da94: ldur            w8, [x6, #0x27]
    // 0x67da98: DecompressPointer r8
    //     0x67da98: add             x8, x8, HEAP, lsl #32
    // 0x67da9c: stur            x8, [fp, #-0x28]
    // 0x67daa0: cmp             w8, NULL
    // 0x67daa4: b.eq            #0x67ec0c
    // 0x67daa8: r9 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x67daa8: add             x9, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x67daac: ldr             x9, [x9, #0x1e8]
    // 0x67dab0: mov             x0, x8
    // 0x67dab4: r2 = Null
    //     0x67dab4: mov             x2, NULL
    // 0x67dab8: r1 = Null
    //     0x67dab8: mov             x1, NULL
    // 0x67dabc: r4 = LoadClassIdInstr(r0)
    //     0x67dabc: ldur            x4, [x0, #-1]
    //     0x67dac0: ubfx            x4, x4, #0xc, #0x14
    // 0x67dac4: cmp             x4, #0x80c
    // 0x67dac8: b.eq            #0x67dae0
    // 0x67dacc: r8 = SliverConstraints
    //     0x67dacc: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x67dad0: ldr             x8, [x8, #0x5a8]
    // 0x67dad4: r3 = Null
    //     0x67dad4: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4af48] Null
    //     0x67dad8: ldr             x3, [x3, #0xf48]
    // 0x67dadc: r0 = DefaultTypeTest()
    //     0x67dadc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67dae0: ldur            x16, [fp, #-0x28]
    // 0x67dae4: SaveReg r16
    //     0x67dae4: str             x16, [SP, #-8]!
    // 0x67dae8: r0 = axis()
    //     0x67dae8: bl              #0x643150  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0x67daec: add             SP, SP, #8
    // 0x67daf0: LoadField: r1 = r0->field_7
    //     0x67daf0: ldur            x1, [x0, #7]
    // 0x67daf4: cmp             x1, #0
    // 0x67daf8: b.gt            #0x67db1c
    // 0x67dafc: ldur            x0, [fp, #-0x30]
    // 0x67db00: LoadField: r1 = r0->field_57
    //     0x67db00: ldur            w1, [x0, #0x57]
    // 0x67db04: DecompressPointer r1
    //     0x67db04: add             x1, x1, HEAP, lsl #32
    // 0x67db08: cmp             w1, NULL
    // 0x67db0c: b.eq            #0x67ec94
    // 0x67db10: LoadField: d0 = r1->field_7
    //     0x67db10: ldur            d0, [x1, #7]
    // 0x67db14: mov             v2.16b, v0.16b
    // 0x67db18: b               #0x67db38
    // 0x67db1c: ldur            x0, [fp, #-0x30]
    // 0x67db20: LoadField: r1 = r0->field_57
    //     0x67db20: ldur            w1, [x0, #0x57]
    // 0x67db24: DecompressPointer r1
    //     0x67db24: add             x1, x1, HEAP, lsl #32
    // 0x67db28: cmp             w1, NULL
    // 0x67db2c: b.eq            #0x67ec98
    // 0x67db30: LoadField: d0 = r1->field_f
    //     0x67db30: ldur            d0, [x1, #0xf]
    // 0x67db34: mov             v2.16b, v0.16b
    // 0x67db38: ldur            d1, [fp, #-0x80]
    // 0x67db3c: ldur            d0, [fp, #-0x88]
    // 0x67db40: fsub            d3, d1, d2
    // 0x67db44: stur            d3, [fp, #-0x90]
    // 0x67db48: fcmp            d3, d0
    // 0x67db4c: b.vs            #0x67dc70
    // 0x67db50: b.ge            #0x67dc70
    // 0x67db54: ldr             x0, [fp, #0x10]
    // 0x67db58: fneg            d0, d3
    // 0x67db5c: stur            d0, [fp, #-0x80]
    // 0x67db60: r0 = SliverGeometry()
    //     0x67db60: bl              #0x679334  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x54)
    // 0x67db64: d1 = 0.000000
    //     0x67db64: eor             v1.16b, v1.16b, v1.16b
    // 0x67db68: StoreField: r0->field_7 = d1
    //     0x67db68: stur            d1, [x0, #7]
    // 0x67db6c: StoreField: r0->field_17 = d1
    //     0x67db6c: stur            d1, [x0, #0x17]
    // 0x67db70: StoreField: r0->field_f = d1
    //     0x67db70: stur            d1, [x0, #0xf]
    // 0x67db74: StoreField: r0->field_27 = d1
    //     0x67db74: stur            d1, [x0, #0x27]
    // 0x67db78: StoreField: r0->field_2f = d1
    //     0x67db78: stur            d1, [x0, #0x2f]
    // 0x67db7c: r3 = false
    //     0x67db7c: add             x3, NULL, #0x30  ; false
    // 0x67db80: StoreField: r0->field_43 = r3
    //     0x67db80: stur            w3, [x0, #0x43]
    // 0x67db84: ldur            d0, [fp, #-0x80]
    // 0x67db88: r1 = inline_Allocate_Double()
    //     0x67db88: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x67db8c: add             x1, x1, #0x10
    //     0x67db90: cmp             x2, x1
    //     0x67db94: b.ls            #0x67ec9c
    //     0x67db98: str             x1, [THR, #0x60]  ; THR::top
    //     0x67db9c: sub             x1, x1, #0xf
    //     0x67dba0: mov             x2, #0xd108
    //     0x67dba4: movk            x2, #3, lsl #16
    //     0x67dba8: stur            x2, [x1, #-1]
    // 0x67dbac: StoreField: r1->field_7 = d0
    //     0x67dbac: stur            d0, [x1, #7]
    // 0x67dbb0: StoreField: r0->field_47 = r1
    //     0x67dbb0: stur            w1, [x0, #0x47]
    // 0x67dbb4: StoreField: r0->field_1f = d1
    //     0x67dbb4: stur            d1, [x0, #0x1f]
    // 0x67dbb8: StoreField: r0->field_37 = d1
    //     0x67dbb8: stur            d1, [x0, #0x37]
    // 0x67dbbc: StoreField: r0->field_4b = d1
    //     0x67dbbc: stur            d1, [x0, #0x4b]
    // 0x67dbc0: fcmp            d1, d1
    // 0x67dbc4: b.vs            #0x67dbcc
    // 0x67dbc8: b.gt            #0x67dbd4
    // 0x67dbcc: r1 = false
    //     0x67dbcc: add             x1, NULL, #0x30  ; false
    // 0x67dbd0: b               #0x67dbd8
    // 0x67dbd4: r1 = true
    //     0x67dbd4: add             x1, NULL, #0x20  ; true
    // 0x67dbd8: StoreField: r0->field_3f = r1
    //     0x67dbd8: stur            w1, [x0, #0x3f]
    // 0x67dbdc: ldr             x4, [fp, #0x10]
    // 0x67dbe0: StoreField: r4->field_4f = r0
    //     0x67dbe0: stur            w0, [x4, #0x4f]
    //     0x67dbe4: ldurb           w16, [x4, #-1]
    //     0x67dbe8: ldurb           w17, [x0, #-1]
    //     0x67dbec: and             x16, x17, x16, lsr #2
    //     0x67dbf0: tst             x16, HEAP, lsr #32
    //     0x67dbf4: b.eq            #0x67dbfc
    //     0x67dbf8: bl              #0xd682cc
    // 0x67dbfc: LoadField: r0 = r4->field_5b
    //     0x67dbfc: ldur            w0, [x4, #0x5b]
    // 0x67dc00: DecompressPointer r0
    //     0x67dc00: add             x0, x0, HEAP, lsl #32
    // 0x67dc04: cmp             w0, NULL
    // 0x67dc08: b.eq            #0x67ecb8
    // 0x67dc0c: LoadField: r3 = r0->field_17
    //     0x67dc0c: ldur            w3, [x0, #0x17]
    // 0x67dc10: DecompressPointer r3
    //     0x67dc10: add             x3, x3, HEAP, lsl #32
    // 0x67dc14: stur            x3, [fp, #-0x28]
    // 0x67dc18: cmp             w3, NULL
    // 0x67dc1c: b.eq            #0x67ecbc
    // 0x67dc20: mov             x0, x3
    // 0x67dc24: r2 = Null
    //     0x67dc24: mov             x2, NULL
    // 0x67dc28: r1 = Null
    //     0x67dc28: mov             x1, NULL
    // 0x67dc2c: r4 = LoadClassIdInstr(r0)
    //     0x67dc2c: ldur            x4, [x0, #-1]
    //     0x67dc30: ubfx            x4, x4, #0xc, #0x14
    // 0x67dc34: sub             x4, x4, #0x7f9
    // 0x67dc38: cmp             x4, #2
    // 0x67dc3c: b.ls            #0x67dc54
    // 0x67dc40: r8 = SliverMultiBoxAdaptorParentData
    //     0x67dc40: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67dc44: ldr             x8, [x8, #0x120]
    // 0x67dc48: r3 = Null
    //     0x67dc48: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4af58] Null
    //     0x67dc4c: ldr             x3, [x3, #0xf58]
    // 0x67dc50: r0 = DefaultTypeTest()
    //     0x67dc50: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67dc54: ldur            x0, [fp, #-0x28]
    // 0x67dc58: r5 = 0.000000
    //     0x67dc58: ldr             x5, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x67dc5c: StoreField: r0->field_7 = r5
    //     0x67dc5c: stur            w5, [x0, #7]
    // 0x67dc60: r0 = Null
    //     0x67dc60: mov             x0, NULL
    // 0x67dc64: LeaveFrame
    //     0x67dc64: mov             SP, fp
    //     0x67dc68: ldp             fp, lr, [SP], #0x10
    // 0x67dc6c: ret
    //     0x67dc6c: ret             
    // 0x67dc70: ldr             x4, [fp, #0x10]
    // 0x67dc74: ldur            x7, [fp, #-0x10]
    // 0x67dc78: ldur            x6, [fp, #-0x40]
    // 0x67dc7c: r3 = false
    //     0x67dc7c: add             x3, NULL, #0x30  ; false
    // 0x67dc80: r5 = 0.000000
    //     0x67dc80: ldr             x5, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x67dc84: d1 = 0.000000
    //     0x67dc84: eor             v1.16b, v1.16b, v1.16b
    // 0x67dc88: LoadField: r8 = r6->field_17
    //     0x67dc88: ldur            w8, [x6, #0x17]
    // 0x67dc8c: DecompressPointer r8
    //     0x67dc8c: add             x8, x8, HEAP, lsl #32
    // 0x67dc90: stur            x8, [fp, #-0x28]
    // 0x67dc94: cmp             w8, NULL
    // 0x67dc98: b.eq            #0x67ecc0
    // 0x67dc9c: mov             x0, x8
    // 0x67dca0: r2 = Null
    //     0x67dca0: mov             x2, NULL
    // 0x67dca4: r1 = Null
    //     0x67dca4: mov             x1, NULL
    // 0x67dca8: r4 = LoadClassIdInstr(r0)
    //     0x67dca8: ldur            x4, [x0, #-1]
    //     0x67dcac: ubfx            x4, x4, #0xc, #0x14
    // 0x67dcb0: sub             x4, x4, #0x7f9
    // 0x67dcb4: cmp             x4, #2
    // 0x67dcb8: b.ls            #0x67dcd0
    // 0x67dcbc: r8 = SliverMultiBoxAdaptorParentData
    //     0x67dcbc: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67dcc0: ldr             x8, [x8, #0x120]
    // 0x67dcc4: r3 = Null
    //     0x67dcc4: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4af68] Null
    //     0x67dcc8: ldr             x3, [x3, #0xf68]
    // 0x67dccc: r0 = DefaultTypeTest()
    //     0x67dccc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67dcd0: ldur            d3, [fp, #-0x90]
    // 0x67dcd4: r0 = inline_Allocate_Double()
    //     0x67dcd4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x67dcd8: add             x0, x0, #0x10
    //     0x67dcdc: cmp             x1, x0
    //     0x67dce0: b.ls            #0x67ecc4
    //     0x67dce4: str             x0, [THR, #0x60]  ; THR::top
    //     0x67dce8: sub             x0, x0, #0xf
    //     0x67dcec: mov             x1, #0xd108
    //     0x67dcf0: movk            x1, #3, lsl #16
    //     0x67dcf4: stur            x1, [x0, #-1]
    // 0x67dcf8: StoreField: r0->field_7 = d3
    //     0x67dcf8: stur            d3, [x0, #7]
    // 0x67dcfc: ldur            x1, [fp, #-0x28]
    // 0x67dd00: StoreField: r1->field_7 = r0
    //     0x67dd00: stur            w0, [x1, #7]
    //     0x67dd04: ldurb           w16, [x1, #-1]
    //     0x67dd08: ldurb           w17, [x0, #-1]
    //     0x67dd0c: and             x16, x17, x16, lsr #2
    //     0x67dd10: tst             x16, HEAP, lsr #32
    //     0x67dd14: b.eq            #0x67dd1c
    //     0x67dd18: bl              #0xd6826c
    // 0x67dd1c: ldur            x3, [fp, #-0x10]
    // 0x67dd20: LoadField: r0 = r3->field_17
    //     0x67dd20: ldur            w0, [x3, #0x17]
    // 0x67dd24: DecompressPointer r0
    //     0x67dd24: add             x0, x0, HEAP, lsl #32
    // 0x67dd28: cmp             w0, NULL
    // 0x67dd2c: b.ne            #0x67dd50
    // 0x67dd30: ldur            x0, [fp, #-0x40]
    // 0x67dd34: StoreField: r3->field_17 = r0
    //     0x67dd34: stur            w0, [x3, #0x17]
    //     0x67dd38: ldurb           w16, [x3, #-1]
    //     0x67dd3c: ldurb           w17, [x0, #-1]
    //     0x67dd40: and             x16, x17, x16, lsr #2
    //     0x67dd44: tst             x16, HEAP, lsr #32
    //     0x67dd48: b.eq            #0x67dd50
    //     0x67dd4c: bl              #0xd682ac
    // 0x67dd50: ldur            x0, [fp, #-0x40]
    // 0x67dd54: r2 = Null
    //     0x67dd54: mov             x2, NULL
    // 0x67dd58: r1 = Null
    //     0x67dd58: mov             x1, NULL
    // 0x67dd5c: r4 = LoadClassIdInstr(r0)
    //     0x67dd5c: ldur            x4, [x0, #-1]
    //     0x67dd60: ubfx            x4, x4, #0xc, #0x14
    // 0x67dd64: sub             x4, x4, #0x961
    // 0x67dd68: cmp             x4, #0xbe
    // 0x67dd6c: b.ls            #0x67dd80
    // 0x67dd70: r8 = RenderObject
    //     0x67dd70: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x67dd74: r3 = Null
    //     0x67dd74: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4af78] Null
    //     0x67dd78: ldr             x3, [x3, #0xf78]
    // 0x67dd7c: r0 = RenderObject()
    //     0x67dd7c: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x67dd80: ldur            x3, [fp, #-0x40]
    // 0x67dd84: ldur            x1, [fp, #-0x40]
    // 0x67dd88: ldur            d3, [fp, #-0x90]
    // 0x67dd8c: ldur            d2, [fp, #-0x88]
    // 0x67dd90: d1 = 0.000000
    //     0x67dd90: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1e0] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    //     0x67dd94: ldr             d1, [x17, #0x1e0]
    // 0x67dd98: b               #0x67d848
    // 0x67dd9c: mov             x0, x1
    // 0x67dda0: ldur            d0, [fp, #-0x70]
    // 0x67dda4: d1 = 0.000000
    //     0x67dda4: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1e0] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    //     0x67dda8: ldr             d1, [x17, #0x1e0]
    // 0x67ddac: stur            x3, [fp, #-0x48]
    // 0x67ddb0: fcmp            d0, d1
    // 0x67ddb4: b.vs            #0x67e114
    // 0x67ddb8: b.ge            #0x67e114
    // 0x67ddbc: fneg            d2, d1
    // 0x67ddc0: stur            d2, [fp, #-0x80]
    // 0x67ddc4: mov             x5, x0
    // 0x67ddc8: ldr             x4, [fp, #0x10]
    // 0x67ddcc: stur            x5, [fp, #-0x40]
    // 0x67ddd0: CheckStackOverflow
    //     0x67ddd0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67ddd4: cmp             SP, x16
    //     0x67ddd8: b.ls            #0x67ecd4
    // 0x67dddc: LoadField: r6 = r4->field_5b
    //     0x67dddc: ldur            w6, [x4, #0x5b]
    // 0x67dde0: DecompressPointer r6
    //     0x67dde0: add             x6, x6, HEAP, lsl #32
    // 0x67dde4: stur            x6, [fp, #-0x30]
    // 0x67dde8: cmp             w6, NULL
    // 0x67ddec: b.eq            #0x67ecdc
    // 0x67ddf0: LoadField: r7 = r6->field_17
    //     0x67ddf0: ldur            w7, [x6, #0x17]
    // 0x67ddf4: DecompressPointer r7
    //     0x67ddf4: add             x7, x7, HEAP, lsl #32
    // 0x67ddf8: stur            x7, [fp, #-0x28]
    // 0x67ddfc: cmp             w7, NULL
    // 0x67de00: b.eq            #0x67ece0
    // 0x67de04: mov             x0, x7
    // 0x67de08: r2 = Null
    //     0x67de08: mov             x2, NULL
    // 0x67de0c: r1 = Null
    //     0x67de0c: mov             x1, NULL
    // 0x67de10: r4 = LoadClassIdInstr(r0)
    //     0x67de10: ldur            x4, [x0, #-1]
    //     0x67de14: ubfx            x4, x4, #0xc, #0x14
    // 0x67de18: sub             x4, x4, #0x7f9
    // 0x67de1c: cmp             x4, #2
    // 0x67de20: b.ls            #0x67de38
    // 0x67de24: r8 = SliverMultiBoxAdaptorParentData
    //     0x67de24: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67de28: ldr             x8, [x8, #0x120]
    // 0x67de2c: r3 = Null
    //     0x67de2c: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4af88] Null
    //     0x67de30: ldr             x3, [x3, #0xf88]
    // 0x67de34: r0 = DefaultTypeTest()
    //     0x67de34: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67de38: ldur            x3, [fp, #-0x28]
    // 0x67de3c: LoadField: r0 = r3->field_17
    //     0x67de3c: ldur            w0, [x3, #0x17]
    // 0x67de40: DecompressPointer r0
    //     0x67de40: add             x0, x0, HEAP, lsl #32
    // 0x67de44: cmp             w0, NULL
    // 0x67de48: b.eq            #0x67ece4
    // 0x67de4c: r1 = LoadInt32Instr(r0)
    //     0x67de4c: sbfx            x1, x0, #1, #0x1f
    //     0x67de50: tbz             w0, #0, #0x67de58
    //     0x67de54: ldur            x1, [x0, #7]
    // 0x67de58: cmp             x1, #0
    // 0x67de5c: b.le            #0x67e100
    // 0x67de60: ldr             x4, [fp, #0x10]
    // 0x67de64: ldur            x0, [fp, #-0x30]
    // 0x67de68: r2 = Null
    //     0x67de68: mov             x2, NULL
    // 0x67de6c: r1 = Null
    //     0x67de6c: mov             x1, NULL
    // 0x67de70: r4 = LoadClassIdInstr(r0)
    //     0x67de70: ldur            x4, [x0, #-1]
    //     0x67de74: ubfx            x4, x4, #0xc, #0x14
    // 0x67de78: sub             x4, x4, #0x961
    // 0x67de7c: cmp             x4, #0xbe
    // 0x67de80: b.ls            #0x67de94
    // 0x67de84: r8 = RenderObject
    //     0x67de84: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x67de88: r3 = Null
    //     0x67de88: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4af98] Null
    //     0x67de8c: ldr             x3, [x3, #0xf98]
    // 0x67de90: r0 = RenderObject()
    //     0x67de90: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x67de94: ldur            x0, [fp, #-0x28]
    // 0x67de98: LoadField: r1 = r0->field_7
    //     0x67de98: ldur            w1, [x0, #7]
    // 0x67de9c: DecompressPointer r1
    //     0x67de9c: add             x1, x1, HEAP, lsl #32
    // 0x67dea0: stur            x1, [fp, #-0x30]
    // 0x67dea4: cmp             w1, NULL
    // 0x67dea8: b.eq            #0x67ece8
    // 0x67deac: ldr             x16, [fp, #0x10]
    // 0x67deb0: ldur            lr, [fp, #-0x20]
    // 0x67deb4: stp             lr, x16, [SP, #-0x10]!
    // 0x67deb8: r16 = true
    //     0x67deb8: add             x16, NULL, #0x20  ; true
    // 0x67debc: SaveReg r16
    //     0x67debc: str             x16, [SP, #-8]!
    // 0x67dec0: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x67dec0: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x67dec4: ldr             x4, [x4, #0x1c8]
    // 0x67dec8: r0 = insertAndLayoutLeadingChild()
    //     0x67dec8: bl              #0x678a4c  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::insertAndLayoutLeadingChild
    // 0x67decc: add             SP, SP, #0x18
    // 0x67ded0: mov             x4, x0
    // 0x67ded4: ldr             x3, [fp, #0x10]
    // 0x67ded8: stur            x4, [fp, #-0x58]
    // 0x67dedc: LoadField: r5 = r3->field_5b
    //     0x67dedc: ldur            w5, [x3, #0x5b]
    // 0x67dee0: DecompressPointer r5
    //     0x67dee0: add             x5, x5, HEAP, lsl #32
    // 0x67dee4: stur            x5, [fp, #-0x50]
    // 0x67dee8: cmp             w5, NULL
    // 0x67deec: b.eq            #0x67ecec
    // 0x67def0: LoadField: r6 = r3->field_27
    //     0x67def0: ldur            w6, [x3, #0x27]
    // 0x67def4: DecompressPointer r6
    //     0x67def4: add             x6, x6, HEAP, lsl #32
    // 0x67def8: stur            x6, [fp, #-0x28]
    // 0x67defc: cmp             w6, NULL
    // 0x67df00: b.eq            #0x67ec24
    // 0x67df04: r7 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x67df04: add             x7, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x67df08: ldr             x7, [x7, #0x1e8]
    // 0x67df0c: mov             x0, x6
    // 0x67df10: r2 = Null
    //     0x67df10: mov             x2, NULL
    // 0x67df14: r1 = Null
    //     0x67df14: mov             x1, NULL
    // 0x67df18: r4 = LoadClassIdInstr(r0)
    //     0x67df18: ldur            x4, [x0, #-1]
    //     0x67df1c: ubfx            x4, x4, #0xc, #0x14
    // 0x67df20: cmp             x4, #0x80c
    // 0x67df24: b.eq            #0x67df3c
    // 0x67df28: r8 = SliverConstraints
    //     0x67df28: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x67df2c: ldr             x8, [x8, #0x5a8]
    // 0x67df30: r3 = Null
    //     0x67df30: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4afa8] Null
    //     0x67df34: ldr             x3, [x3, #0xfa8]
    // 0x67df38: r0 = DefaultTypeTest()
    //     0x67df38: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67df3c: ldur            x16, [fp, #-0x28]
    // 0x67df40: SaveReg r16
    //     0x67df40: str             x16, [SP, #-8]!
    // 0x67df44: r0 = axis()
    //     0x67df44: bl              #0x643150  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0x67df48: add             SP, SP, #8
    // 0x67df4c: LoadField: r1 = r0->field_7
    //     0x67df4c: ldur            x1, [x0, #7]
    // 0x67df50: cmp             x1, #0
    // 0x67df54: b.gt            #0x67df78
    // 0x67df58: ldur            x0, [fp, #-0x50]
    // 0x67df5c: LoadField: r1 = r0->field_57
    //     0x67df5c: ldur            w1, [x0, #0x57]
    // 0x67df60: DecompressPointer r1
    //     0x67df60: add             x1, x1, HEAP, lsl #32
    // 0x67df64: cmp             w1, NULL
    // 0x67df68: b.eq            #0x67ecf0
    // 0x67df6c: LoadField: d0 = r1->field_7
    //     0x67df6c: ldur            d0, [x1, #7]
    // 0x67df70: mov             v1.16b, v0.16b
    // 0x67df74: b               #0x67df94
    // 0x67df78: ldur            x0, [fp, #-0x50]
    // 0x67df7c: LoadField: r1 = r0->field_57
    //     0x67df7c: ldur            w1, [x0, #0x57]
    // 0x67df80: DecompressPointer r1
    //     0x67df80: add             x1, x1, HEAP, lsl #32
    // 0x67df84: cmp             w1, NULL
    // 0x67df88: b.eq            #0x67ecf4
    // 0x67df8c: LoadField: d0 = r1->field_f
    //     0x67df8c: ldur            d0, [x1, #0xf]
    // 0x67df90: mov             v1.16b, v0.16b
    // 0x67df94: ldr             x3, [fp, #0x10]
    // 0x67df98: ldur            d0, [fp, #-0x80]
    // 0x67df9c: ldur            x0, [fp, #-0x30]
    // 0x67dfa0: LoadField: d2 = r0->field_7
    //     0x67dfa0: ldur            d2, [x0, #7]
    // 0x67dfa4: fsub            d3, d2, d1
    // 0x67dfa8: stur            d3, [fp, #-0x88]
    // 0x67dfac: LoadField: r0 = r3->field_5b
    //     0x67dfac: ldur            w0, [x3, #0x5b]
    // 0x67dfb0: DecompressPointer r0
    //     0x67dfb0: add             x0, x0, HEAP, lsl #32
    // 0x67dfb4: cmp             w0, NULL
    // 0x67dfb8: b.eq            #0x67ecf8
    // 0x67dfbc: LoadField: r4 = r0->field_17
    //     0x67dfbc: ldur            w4, [x0, #0x17]
    // 0x67dfc0: DecompressPointer r4
    //     0x67dfc0: add             x4, x4, HEAP, lsl #32
    // 0x67dfc4: stur            x4, [fp, #-0x28]
    // 0x67dfc8: cmp             w4, NULL
    // 0x67dfcc: b.eq            #0x67ecfc
    // 0x67dfd0: mov             x0, x4
    // 0x67dfd4: r2 = Null
    //     0x67dfd4: mov             x2, NULL
    // 0x67dfd8: r1 = Null
    //     0x67dfd8: mov             x1, NULL
    // 0x67dfdc: r4 = LoadClassIdInstr(r0)
    //     0x67dfdc: ldur            x4, [x0, #-1]
    //     0x67dfe0: ubfx            x4, x4, #0xc, #0x14
    // 0x67dfe4: sub             x4, x4, #0x7f9
    // 0x67dfe8: cmp             x4, #2
    // 0x67dfec: b.ls            #0x67e004
    // 0x67dff0: r8 = SliverMultiBoxAdaptorParentData
    //     0x67dff0: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67dff4: ldr             x8, [x8, #0x120]
    // 0x67dff8: r3 = Null
    //     0x67dff8: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4afb8] Null
    //     0x67dffc: ldr             x3, [x3, #0xfb8]
    // 0x67e000: r0 = DefaultTypeTest()
    //     0x67e000: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67e004: ldur            x1, [fp, #-0x28]
    // 0x67e008: r0 = 0.000000
    //     0x67e008: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x67e00c: StoreField: r1->field_7 = r0
    //     0x67e00c: stur            w0, [x1, #7]
    // 0x67e010: ldur            d1, [fp, #-0x88]
    // 0x67e014: ldur            d0, [fp, #-0x80]
    // 0x67e018: fcmp            d1, d0
    // 0x67e01c: b.vs            #0x67e0dc
    // 0x67e020: b.ge            #0x67e0dc
    // 0x67e024: ldr             x0, [fp, #0x10]
    // 0x67e028: fneg            d0, d1
    // 0x67e02c: stur            d0, [fp, #-0x90]
    // 0x67e030: r0 = SliverGeometry()
    //     0x67e030: bl              #0x679334  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x54)
    // 0x67e034: d1 = 0.000000
    //     0x67e034: eor             v1.16b, v1.16b, v1.16b
    // 0x67e038: StoreField: r0->field_7 = d1
    //     0x67e038: stur            d1, [x0, #7]
    // 0x67e03c: StoreField: r0->field_17 = d1
    //     0x67e03c: stur            d1, [x0, #0x17]
    // 0x67e040: StoreField: r0->field_f = d1
    //     0x67e040: stur            d1, [x0, #0xf]
    // 0x67e044: StoreField: r0->field_27 = d1
    //     0x67e044: stur            d1, [x0, #0x27]
    // 0x67e048: StoreField: r0->field_2f = d1
    //     0x67e048: stur            d1, [x0, #0x2f]
    // 0x67e04c: r1 = false
    //     0x67e04c: add             x1, NULL, #0x30  ; false
    // 0x67e050: StoreField: r0->field_43 = r1
    //     0x67e050: stur            w1, [x0, #0x43]
    // 0x67e054: ldur            d0, [fp, #-0x90]
    // 0x67e058: r1 = inline_Allocate_Double()
    //     0x67e058: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x67e05c: add             x1, x1, #0x10
    //     0x67e060: cmp             x2, x1
    //     0x67e064: b.ls            #0x67ed00
    //     0x67e068: str             x1, [THR, #0x60]  ; THR::top
    //     0x67e06c: sub             x1, x1, #0xf
    //     0x67e070: mov             x2, #0xd108
    //     0x67e074: movk            x2, #3, lsl #16
    //     0x67e078: stur            x2, [x1, #-1]
    // 0x67e07c: StoreField: r1->field_7 = d0
    //     0x67e07c: stur            d0, [x1, #7]
    // 0x67e080: StoreField: r0->field_47 = r1
    //     0x67e080: stur            w1, [x0, #0x47]
    // 0x67e084: StoreField: r0->field_1f = d1
    //     0x67e084: stur            d1, [x0, #0x1f]
    // 0x67e088: StoreField: r0->field_37 = d1
    //     0x67e088: stur            d1, [x0, #0x37]
    // 0x67e08c: StoreField: r0->field_4b = d1
    //     0x67e08c: stur            d1, [x0, #0x4b]
    // 0x67e090: fcmp            d1, d1
    // 0x67e094: b.vs            #0x67e09c
    // 0x67e098: b.gt            #0x67e0a4
    // 0x67e09c: r1 = false
    //     0x67e09c: add             x1, NULL, #0x30  ; false
    // 0x67e0a0: b               #0x67e0a8
    // 0x67e0a4: r1 = true
    //     0x67e0a4: add             x1, NULL, #0x20  ; true
    // 0x67e0a8: StoreField: r0->field_3f = r1
    //     0x67e0a8: stur            w1, [x0, #0x3f]
    // 0x67e0ac: ldr             x2, [fp, #0x10]
    // 0x67e0b0: StoreField: r2->field_4f = r0
    //     0x67e0b0: stur            w0, [x2, #0x4f]
    //     0x67e0b4: ldurb           w16, [x2, #-1]
    //     0x67e0b8: ldurb           w17, [x0, #-1]
    //     0x67e0bc: and             x16, x17, x16, lsr #2
    //     0x67e0c0: tst             x16, HEAP, lsr #32
    //     0x67e0c4: b.eq            #0x67e0cc
    //     0x67e0c8: bl              #0xd6828c
    // 0x67e0cc: r0 = Null
    //     0x67e0cc: mov             x0, NULL
    // 0x67e0d0: LeaveFrame
    //     0x67e0d0: mov             SP, fp
    //     0x67e0d4: ldp             fp, lr, [SP], #0x10
    // 0x67e0d8: ret
    //     0x67e0d8: ret             
    // 0x67e0dc: ldr             x2, [fp, #0x10]
    // 0x67e0e0: r1 = false
    //     0x67e0e0: add             x1, NULL, #0x30  ; false
    // 0x67e0e4: d1 = 0.000000
    //     0x67e0e4: eor             v1.16b, v1.16b, v1.16b
    // 0x67e0e8: ldur            x5, [fp, #-0x58]
    // 0x67e0ec: mov             x4, x2
    // 0x67e0f0: mov             v2.16b, v0.16b
    // 0x67e0f4: ldur            d0, [fp, #-0x70]
    // 0x67e0f8: ldur            x3, [fp, #-0x48]
    // 0x67e0fc: b               #0x67ddcc
    // 0x67e100: ldr             x2, [fp, #0x10]
    // 0x67e104: r1 = false
    //     0x67e104: add             x1, NULL, #0x30  ; false
    // 0x67e108: d1 = 0.000000
    //     0x67e108: eor             v1.16b, v1.16b, v1.16b
    // 0x67e10c: ldur            x3, [fp, #-0x40]
    // 0x67e110: b               #0x67e124
    // 0x67e114: ldr             x2, [fp, #0x10]
    // 0x67e118: r1 = false
    //     0x67e118: add             x1, NULL, #0x30  ; false
    // 0x67e11c: d1 = 0.000000
    //     0x67e11c: eor             v1.16b, v1.16b, v1.16b
    // 0x67e120: mov             x3, x0
    // 0x67e124: ldur            x0, [fp, #-0x48]
    // 0x67e128: stur            x3, [fp, #-0x28]
    // 0x67e12c: cmp             w0, NULL
    // 0x67e130: b.ne            #0x67e19c
    // 0x67e134: ldur            x4, [fp, #-0x10]
    // 0x67e138: cmp             w3, NULL
    // 0x67e13c: b.eq            #0x67ed1c
    // 0x67e140: r0 = LoadClassIdInstr(r3)
    //     0x67e140: ldur            x0, [x3, #-1]
    //     0x67e144: ubfx            x0, x0, #0xc, #0x14
    // 0x67e148: ldur            x16, [fp, #-0x20]
    // 0x67e14c: stp             x16, x3, [SP, #-0x10]!
    // 0x67e150: r16 = true
    //     0x67e150: add             x16, NULL, #0x20  ; true
    // 0x67e154: SaveReg r16
    //     0x67e154: str             x16, [SP, #-8]!
    // 0x67e158: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x67e158: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x67e15c: ldr             x4, [x4, #0x1c8]
    // 0x67e160: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x67e160: mov             x17, #0xcdfb
    //     0x67e164: add             lr, x0, x17
    //     0x67e168: ldr             lr, [x21, lr, lsl #3]
    //     0x67e16c: blr             lr
    // 0x67e170: add             SP, SP, #0x18
    // 0x67e174: ldur            x0, [fp, #-0x28]
    // 0x67e178: ldur            x3, [fp, #-0x10]
    // 0x67e17c: StoreField: r3->field_17 = r0
    //     0x67e17c: stur            w0, [x3, #0x17]
    //     0x67e180: ldurb           w16, [x3, #-1]
    //     0x67e184: ldurb           w17, [x0, #-1]
    //     0x67e188: and             x16, x17, x16, lsr #2
    //     0x67e18c: tst             x16, HEAP, lsr #32
    //     0x67e190: b.eq            #0x67e198
    //     0x67e194: bl              #0xd682ac
    // 0x67e198: b               #0x67e1a0
    // 0x67e19c: ldur            x3, [fp, #-0x10]
    // 0x67e1a0: ldur            x4, [fp, #-0x28]
    // 0x67e1a4: r5 = true
    //     0x67e1a4: add             x5, NULL, #0x20  ; true
    // 0x67e1a8: StoreField: r3->field_1b = r5
    //     0x67e1a8: stur            w5, [x3, #0x1b]
    // 0x67e1ac: mov             x0, x4
    // 0x67e1b0: StoreField: r3->field_1f = r0
    //     0x67e1b0: stur            w0, [x3, #0x1f]
    //     0x67e1b4: tbz             w0, #0, #0x67e1d0
    //     0x67e1b8: ldurb           w16, [x3, #-1]
    //     0x67e1bc: ldurb           w17, [x0, #-1]
    //     0x67e1c0: and             x16, x17, x16, lsr #2
    //     0x67e1c4: tst             x16, HEAP, lsr #32
    //     0x67e1c8: b.eq            #0x67e1d0
    //     0x67e1cc: bl              #0xd682ac
    // 0x67e1d0: cmp             w4, NULL
    // 0x67e1d4: b.eq            #0x67ed20
    // 0x67e1d8: LoadField: r6 = r4->field_17
    //     0x67e1d8: ldur            w6, [x4, #0x17]
    // 0x67e1dc: DecompressPointer r6
    //     0x67e1dc: add             x6, x6, HEAP, lsl #32
    // 0x67e1e0: stur            x6, [fp, #-0x20]
    // 0x67e1e4: cmp             w6, NULL
    // 0x67e1e8: b.eq            #0x67ed24
    // 0x67e1ec: mov             x0, x6
    // 0x67e1f0: r2 = Null
    //     0x67e1f0: mov             x2, NULL
    // 0x67e1f4: r1 = Null
    //     0x67e1f4: mov             x1, NULL
    // 0x67e1f8: r4 = LoadClassIdInstr(r0)
    //     0x67e1f8: ldur            x4, [x0, #-1]
    //     0x67e1fc: ubfx            x4, x4, #0xc, #0x14
    // 0x67e200: sub             x4, x4, #0x7f9
    // 0x67e204: cmp             x4, #2
    // 0x67e208: b.ls            #0x67e220
    // 0x67e20c: r8 = SliverMultiBoxAdaptorParentData
    //     0x67e20c: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67e210: ldr             x8, [x8, #0x120]
    // 0x67e214: r3 = Null
    //     0x67e214: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4afc8] Null
    //     0x67e218: ldr             x3, [x3, #0xfc8]
    // 0x67e21c: r0 = DefaultTypeTest()
    //     0x67e21c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67e220: ldur            x3, [fp, #-0x20]
    // 0x67e224: LoadField: r0 = r3->field_17
    //     0x67e224: ldur            w0, [x3, #0x17]
    // 0x67e228: DecompressPointer r0
    //     0x67e228: add             x0, x0, HEAP, lsl #32
    // 0x67e22c: cmp             w0, NULL
    // 0x67e230: b.eq            #0x67ed28
    // 0x67e234: ldur            x4, [fp, #-0x10]
    // 0x67e238: StoreField: r4->field_23 = r0
    //     0x67e238: stur            w0, [x4, #0x23]
    //     0x67e23c: tbz             w0, #0, #0x67e258
    //     0x67e240: ldurb           w16, [x4, #-1]
    //     0x67e244: ldurb           w17, [x0, #-1]
    //     0x67e248: and             x16, x17, x16, lsr #2
    //     0x67e24c: tst             x16, HEAP, lsr #32
    //     0x67e250: b.eq            #0x67e258
    //     0x67e254: bl              #0xd682cc
    // 0x67e258: ldur            x0, [fp, #-0x28]
    // 0x67e25c: r2 = Null
    //     0x67e25c: mov             x2, NULL
    // 0x67e260: r1 = Null
    //     0x67e260: mov             x1, NULL
    // 0x67e264: r4 = LoadClassIdInstr(r0)
    //     0x67e264: ldur            x4, [x0, #-1]
    //     0x67e268: ubfx            x4, x4, #0xc, #0x14
    // 0x67e26c: sub             x4, x4, #0x961
    // 0x67e270: cmp             x4, #0xbe
    // 0x67e274: b.ls            #0x67e288
    // 0x67e278: r8 = RenderObject
    //     0x67e278: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x67e27c: r3 = Null
    //     0x67e27c: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4afd8] Null
    //     0x67e280: ldr             x3, [x3, #0xfd8]
    // 0x67e284: r0 = RenderObject()
    //     0x67e284: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x67e288: ldur            x0, [fp, #-0x20]
    // 0x67e28c: LoadField: r1 = r0->field_7
    //     0x67e28c: ldur            w1, [x0, #7]
    // 0x67e290: DecompressPointer r1
    //     0x67e290: add             x1, x1, HEAP, lsl #32
    // 0x67e294: stur            x1, [fp, #-0x30]
    // 0x67e298: cmp             w1, NULL
    // 0x67e29c: b.eq            #0x67ed2c
    // 0x67e2a0: ldr             x16, [fp, #0x10]
    // 0x67e2a4: ldur            lr, [fp, #-0x28]
    // 0x67e2a8: stp             lr, x16, [SP, #-0x10]!
    // 0x67e2ac: r0 = paintExtentOf()
    //     0x67e2ac: bl              #0x653e78  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::paintExtentOf
    // 0x67e2b0: add             SP, SP, #0x10
    // 0x67e2b4: cmp             w0, NULL
    // 0x67e2b8: b.eq            #0x67ed30
    // 0x67e2bc: ldur            x1, [fp, #-0x30]
    // 0x67e2c0: LoadField: d0 = r1->field_7
    //     0x67e2c0: ldur            d0, [x1, #7]
    // 0x67e2c4: LoadField: d1 = r0->field_7
    //     0x67e2c4: ldur            d1, [x0, #7]
    // 0x67e2c8: fadd            d2, d0, d1
    // 0x67e2cc: r0 = inline_Allocate_Double()
    //     0x67e2cc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x67e2d0: add             x0, x0, #0x10
    //     0x67e2d4: cmp             x1, x0
    //     0x67e2d8: b.ls            #0x67ed34
    //     0x67e2dc: str             x0, [THR, #0x60]  ; THR::top
    //     0x67e2e0: sub             x0, x0, #0xf
    //     0x67e2e4: mov             x1, #0xd108
    //     0x67e2e8: movk            x1, #3, lsl #16
    //     0x67e2ec: stur            x1, [x0, #-1]
    // 0x67e2f0: StoreField: r0->field_7 = d2
    //     0x67e2f0: stur            d2, [x0, #7]
    // 0x67e2f4: ldur            x3, [fp, #-0x10]
    // 0x67e2f8: StoreField: r3->field_27 = r0
    //     0x67e2f8: stur            w0, [x3, #0x27]
    //     0x67e2fc: ldurb           w16, [x3, #-1]
    //     0x67e300: ldurb           w17, [x0, #-1]
    //     0x67e304: and             x16, x17, x16, lsr #2
    //     0x67e308: tst             x16, HEAP, lsr #32
    //     0x67e30c: b.eq            #0x67e314
    //     0x67e310: bl              #0xd682ac
    // 0x67e314: mov             x2, x3
    // 0x67e318: r1 = Function 'advance':.
    //     0x67e318: add             x1, PP, #0x4a, lsl #12  ; [pp+0x4afe8] AnonymousClosure: (0x67edc0), in [package:flutter/src/rendering/sliver_list.dart] RenderSliverList::performLayout (0x67d40c)
    //     0x67e31c: ldr             x1, [x1, #0xfe8]
    // 0x67e320: r0 = AllocateClosure()
    //     0x67e320: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x67e324: mov             x1, x0
    // 0x67e328: stur            x1, [fp, #-0x20]
    // 0x67e32c: ldr             x3, [fp, #0x10]
    // 0x67e330: r4 = 0
    //     0x67e330: mov             x4, #0
    // 0x67e334: ldur            x2, [fp, #-0x10]
    // 0x67e338: ldur            d0, [fp, #-0x70]
    // 0x67e33c: stur            x4, [fp, #-0x60]
    // 0x67e340: CheckStackOverflow
    //     0x67e340: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67e344: cmp             SP, x16
    //     0x67e348: b.ls            #0x67ed44
    // 0x67e34c: LoadField: r0 = r2->field_27
    //     0x67e34c: ldur            w0, [x2, #0x27]
    // 0x67e350: DecompressPointer r0
    //     0x67e350: add             x0, x0, HEAP, lsl #32
    // 0x67e354: cmp             w0, NULL
    // 0x67e358: b.eq            #0x67ed4c
    // 0x67e35c: LoadField: d1 = r0->field_7
    //     0x67e35c: ldur            d1, [x0, #7]
    // 0x67e360: fcmp            d1, d0
    // 0x67e364: b.vs            #0x67e54c
    // 0x67e368: b.ge            #0x67e54c
    // 0x67e36c: add             x5, x4, #1
    // 0x67e370: stur            x5, [fp, #-0x38]
    // 0x67e374: SaveReg r1
    //     0x67e374: str             x1, [SP, #-8]!
    // 0x67e378: mov             x0, x1
    // 0x67e37c: ClosureCall
    //     0x67e37c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x67e380: ldur            x2, [x0, #0x1f]
    //     0x67e384: blr             x2
    // 0x67e388: add             SP, SP, #8
    // 0x67e38c: mov             x1, x0
    // 0x67e390: stur            x1, [fp, #-0x28]
    // 0x67e394: tbnz            w0, #5, #0x67e39c
    // 0x67e398: r0 = AssertBoolean()
    //     0x67e398: bl              #0xd67df0  ; AssertBooleanStub
    // 0x67e39c: ldur            x0, [fp, #-0x28]
    // 0x67e3a0: tbz             w0, #4, #0x67e530
    // 0x67e3a4: ldr             x2, [fp, #0x10]
    // 0x67e3a8: ldur            x4, [fp, #-0x38]
    // 0x67e3ac: sub             x3, x4, #1
    // 0x67e3b0: r0 = BoxInt64Instr(r3)
    //     0x67e3b0: sbfiz           x0, x3, #1, #0x1f
    //     0x67e3b4: cmp             x3, x0, asr #1
    //     0x67e3b8: b.eq            #0x67e3c4
    //     0x67e3bc: bl              #0xd69bb8
    //     0x67e3c0: stur            x3, [x0, #7]
    // 0x67e3c4: stp             x0, x2, [SP, #-0x10]!
    // 0x67e3c8: SaveReg rZR
    //     0x67e3c8: str             xzr, [SP, #-8]!
    // 0x67e3cc: r0 = collectGarbage()
    //     0x67e3cc: bl              #0x6797bc  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::collectGarbage
    // 0x67e3d0: add             SP, SP, #0x18
    // 0x67e3d4: ldr             x3, [fp, #0x10]
    // 0x67e3d8: LoadField: r4 = r3->field_5f
    //     0x67e3d8: ldur            w4, [x3, #0x5f]
    // 0x67e3dc: DecompressPointer r4
    //     0x67e3dc: add             x4, x4, HEAP, lsl #32
    // 0x67e3e0: stur            x4, [fp, #-0x28]
    // 0x67e3e4: cmp             w4, NULL
    // 0x67e3e8: b.eq            #0x67ed50
    // 0x67e3ec: mov             x0, x4
    // 0x67e3f0: r2 = Null
    //     0x67e3f0: mov             x2, NULL
    // 0x67e3f4: r1 = Null
    //     0x67e3f4: mov             x1, NULL
    // 0x67e3f8: r4 = LoadClassIdInstr(r0)
    //     0x67e3f8: ldur            x4, [x0, #-1]
    //     0x67e3fc: ubfx            x4, x4, #0xc, #0x14
    // 0x67e400: sub             x4, x4, #0x961
    // 0x67e404: cmp             x4, #0xbe
    // 0x67e408: b.ls            #0x67e41c
    // 0x67e40c: r8 = RenderObject
    //     0x67e40c: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x67e410: r3 = Null
    //     0x67e410: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4aff0] Null
    //     0x67e414: ldr             x3, [x3, #0xff0]
    // 0x67e418: r0 = RenderObject()
    //     0x67e418: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x67e41c: ldur            x3, [fp, #-0x28]
    // 0x67e420: LoadField: r4 = r3->field_17
    //     0x67e420: ldur            w4, [x3, #0x17]
    // 0x67e424: DecompressPointer r4
    //     0x67e424: add             x4, x4, HEAP, lsl #32
    // 0x67e428: stur            x4, [fp, #-0x30]
    // 0x67e42c: cmp             w4, NULL
    // 0x67e430: b.eq            #0x67ed54
    // 0x67e434: mov             x0, x4
    // 0x67e438: r2 = Null
    //     0x67e438: mov             x2, NULL
    // 0x67e43c: r1 = Null
    //     0x67e43c: mov             x1, NULL
    // 0x67e440: r4 = LoadClassIdInstr(r0)
    //     0x67e440: ldur            x4, [x0, #-1]
    //     0x67e444: ubfx            x4, x4, #0xc, #0x14
    // 0x67e448: sub             x4, x4, #0x7f9
    // 0x67e44c: cmp             x4, #2
    // 0x67e450: b.ls            #0x67e468
    // 0x67e454: r8 = SliverMultiBoxAdaptorParentData
    //     0x67e454: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67e458: ldr             x8, [x8, #0x120]
    // 0x67e45c: r3 = Null
    //     0x67e45c: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b000] Null
    //     0x67e460: ldr             x3, [x3]
    // 0x67e464: r0 = DefaultTypeTest()
    //     0x67e464: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67e468: ldur            x0, [fp, #-0x30]
    // 0x67e46c: LoadField: r1 = r0->field_7
    //     0x67e46c: ldur            w1, [x0, #7]
    // 0x67e470: DecompressPointer r1
    //     0x67e470: add             x1, x1, HEAP, lsl #32
    // 0x67e474: stur            x1, [fp, #-0x40]
    // 0x67e478: cmp             w1, NULL
    // 0x67e47c: b.eq            #0x67ed58
    // 0x67e480: ldr             x16, [fp, #0x10]
    // 0x67e484: ldur            lr, [fp, #-0x28]
    // 0x67e488: stp             lr, x16, [SP, #-0x10]!
    // 0x67e48c: r0 = paintExtentOf()
    //     0x67e48c: bl              #0x653e78  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::paintExtentOf
    // 0x67e490: add             SP, SP, #0x10
    // 0x67e494: cmp             w0, NULL
    // 0x67e498: b.eq            #0x67ed5c
    // 0x67e49c: ldur            x1, [fp, #-0x40]
    // 0x67e4a0: LoadField: d0 = r1->field_7
    //     0x67e4a0: ldur            d0, [x1, #7]
    // 0x67e4a4: LoadField: d1 = r0->field_7
    //     0x67e4a4: ldur            d1, [x0, #7]
    // 0x67e4a8: fadd            d2, d0, d1
    // 0x67e4ac: stur            d2, [fp, #-0x80]
    // 0x67e4b0: r0 = SliverGeometry()
    //     0x67e4b0: bl              #0x679334  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x54)
    // 0x67e4b4: ldur            d0, [fp, #-0x80]
    // 0x67e4b8: StoreField: r0->field_7 = d0
    //     0x67e4b8: stur            d0, [x0, #7]
    // 0x67e4bc: d1 = 0.000000
    //     0x67e4bc: eor             v1.16b, v1.16b, v1.16b
    // 0x67e4c0: StoreField: r0->field_17 = d1
    //     0x67e4c0: stur            d1, [x0, #0x17]
    // 0x67e4c4: StoreField: r0->field_f = d1
    //     0x67e4c4: stur            d1, [x0, #0xf]
    // 0x67e4c8: StoreField: r0->field_27 = d0
    //     0x67e4c8: stur            d0, [x0, #0x27]
    // 0x67e4cc: StoreField: r0->field_2f = d1
    //     0x67e4cc: stur            d1, [x0, #0x2f]
    // 0x67e4d0: r1 = false
    //     0x67e4d0: add             x1, NULL, #0x30  ; false
    // 0x67e4d4: StoreField: r0->field_43 = r1
    //     0x67e4d4: stur            w1, [x0, #0x43]
    // 0x67e4d8: StoreField: r0->field_1f = d1
    //     0x67e4d8: stur            d1, [x0, #0x1f]
    // 0x67e4dc: StoreField: r0->field_37 = d1
    //     0x67e4dc: stur            d1, [x0, #0x37]
    // 0x67e4e0: StoreField: r0->field_4b = d1
    //     0x67e4e0: stur            d1, [x0, #0x4b]
    // 0x67e4e4: fcmp            d1, d1
    // 0x67e4e8: b.vs            #0x67e4f0
    // 0x67e4ec: b.gt            #0x67e4f8
    // 0x67e4f0: r1 = false
    //     0x67e4f0: add             x1, NULL, #0x30  ; false
    // 0x67e4f4: b               #0x67e4fc
    // 0x67e4f8: r1 = true
    //     0x67e4f8: add             x1, NULL, #0x20  ; true
    // 0x67e4fc: StoreField: r0->field_3f = r1
    //     0x67e4fc: stur            w1, [x0, #0x3f]
    // 0x67e500: ldr             x2, [fp, #0x10]
    // 0x67e504: StoreField: r2->field_4f = r0
    //     0x67e504: stur            w0, [x2, #0x4f]
    //     0x67e508: ldurb           w16, [x2, #-1]
    //     0x67e50c: ldurb           w17, [x0, #-1]
    //     0x67e510: and             x16, x17, x16, lsr #2
    //     0x67e514: tst             x16, HEAP, lsr #32
    //     0x67e518: b.eq            #0x67e520
    //     0x67e51c: bl              #0xd6828c
    // 0x67e520: r0 = Null
    //     0x67e520: mov             x0, NULL
    // 0x67e524: LeaveFrame
    //     0x67e524: mov             SP, fp
    //     0x67e528: ldp             fp, lr, [SP], #0x10
    // 0x67e52c: ret
    //     0x67e52c: ret             
    // 0x67e530: ldr             x2, [fp, #0x10]
    // 0x67e534: ldur            x4, [fp, #-0x38]
    // 0x67e538: r1 = false
    //     0x67e538: add             x1, NULL, #0x30  ; false
    // 0x67e53c: d1 = 0.000000
    //     0x67e53c: eor             v1.16b, v1.16b, v1.16b
    // 0x67e540: mov             x3, x2
    // 0x67e544: ldur            x1, [fp, #-0x20]
    // 0x67e548: b               #0x67e334
    // 0x67e54c: mov             x2, x3
    // 0x67e550: d1 = 0.000000
    //     0x67e550: eor             v1.16b, v1.16b, v1.16b
    // 0x67e554: ldur            x1, [fp, #-0x10]
    // 0x67e558: ldur            d0, [fp, #-0x68]
    // 0x67e55c: CheckStackOverflow
    //     0x67e55c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67e560: cmp             SP, x16
    //     0x67e564: b.ls            #0x67ed60
    // 0x67e568: LoadField: r0 = r1->field_27
    //     0x67e568: ldur            w0, [x1, #0x27]
    // 0x67e56c: DecompressPointer r0
    //     0x67e56c: add             x0, x0, HEAP, lsl #32
    // 0x67e570: cmp             w0, NULL
    // 0x67e574: b.eq            #0x67ed68
    // 0x67e578: LoadField: d2 = r0->field_7
    //     0x67e578: ldur            d2, [x0, #7]
    // 0x67e57c: fcmp            d2, d0
    // 0x67e580: b.vs            #0x67e5d4
    // 0x67e584: b.ge            #0x67e5d4
    // 0x67e588: ldur            x16, [fp, #-0x20]
    // 0x67e58c: SaveReg r16
    //     0x67e58c: str             x16, [SP, #-8]!
    // 0x67e590: ldur            x0, [fp, #-0x20]
    // 0x67e594: ClosureCall
    //     0x67e594: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x67e598: ldur            x2, [x0, #0x1f]
    //     0x67e59c: blr             x2
    // 0x67e5a0: add             SP, SP, #8
    // 0x67e5a4: mov             x1, x0
    // 0x67e5a8: stur            x1, [fp, #-0x28]
    // 0x67e5ac: tbnz            w0, #5, #0x67e5b4
    // 0x67e5b0: r0 = AssertBoolean()
    //     0x67e5b0: bl              #0xd67df0  ; AssertBooleanStub
    // 0x67e5b4: ldur            x0, [fp, #-0x28]
    // 0x67e5b8: tbz             w0, #4, #0x67e5c4
    // 0x67e5bc: r4 = true
    //     0x67e5bc: add             x4, NULL, #0x20  ; true
    // 0x67e5c0: b               #0x67e5d8
    // 0x67e5c4: ldr             x2, [fp, #0x10]
    // 0x67e5c8: ldur            x4, [fp, #-0x60]
    // 0x67e5cc: d1 = 0.000000
    //     0x67e5cc: eor             v1.16b, v1.16b, v1.16b
    // 0x67e5d0: b               #0x67e554
    // 0x67e5d4: r4 = false
    //     0x67e5d4: add             x4, NULL, #0x30  ; false
    // 0x67e5d8: ldur            x3, [fp, #-0x10]
    // 0x67e5dc: stur            x4, [fp, #-0x28]
    // 0x67e5e0: LoadField: r0 = r3->field_1f
    //     0x67e5e0: ldur            w0, [x3, #0x1f]
    // 0x67e5e4: DecompressPointer r0
    //     0x67e5e4: add             x0, x0, HEAP, lsl #32
    // 0x67e5e8: cmp             w0, NULL
    // 0x67e5ec: b.eq            #0x67e718
    // 0x67e5f0: LoadField: r5 = r0->field_17
    //     0x67e5f0: ldur            w5, [x0, #0x17]
    // 0x67e5f4: DecompressPointer r5
    //     0x67e5f4: add             x5, x5, HEAP, lsl #32
    // 0x67e5f8: stur            x5, [fp, #-0x20]
    // 0x67e5fc: cmp             w5, NULL
    // 0x67e600: b.eq            #0x67ed6c
    // 0x67e604: mov             x0, x5
    // 0x67e608: r2 = Null
    //     0x67e608: mov             x2, NULL
    // 0x67e60c: r1 = Null
    //     0x67e60c: mov             x1, NULL
    // 0x67e610: r4 = LoadClassIdInstr(r0)
    //     0x67e610: ldur            x4, [x0, #-1]
    //     0x67e614: ubfx            x4, x4, #0xc, #0x14
    // 0x67e618: sub             x4, x4, #0x7f9
    // 0x67e61c: cmp             x4, #2
    // 0x67e620: b.ls            #0x67e638
    // 0x67e624: r8 = SliverMultiBoxAdaptorParentData
    //     0x67e624: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67e628: ldr             x8, [x8, #0x120]
    // 0x67e62c: r3 = Null
    //     0x67e62c: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b010] Null
    //     0x67e630: ldr             x3, [x3, #0x10]
    // 0x67e634: r0 = DefaultTypeTest()
    //     0x67e634: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67e638: ldur            x0, [fp, #-0x20]
    // 0x67e63c: LoadField: r1 = r0->field_f
    //     0x67e63c: ldur            w1, [x0, #0xf]
    // 0x67e640: DecompressPointer r1
    //     0x67e640: add             x1, x1, HEAP, lsl #32
    // 0x67e644: mov             x0, x1
    // 0x67e648: ldur            x3, [fp, #-0x10]
    // 0x67e64c: StoreField: r3->field_1f = r0
    //     0x67e64c: stur            w0, [x3, #0x1f]
    //     0x67e650: ldurb           w16, [x3, #-1]
    //     0x67e654: ldurb           w17, [x0, #-1]
    //     0x67e658: and             x16, x17, x16, lsr #2
    //     0x67e65c: tst             x16, HEAP, lsr #32
    //     0x67e660: b.eq            #0x67e668
    //     0x67e664: bl              #0xd682ac
    // 0x67e668: mov             x0, x1
    // 0x67e66c: r1 = 0
    //     0x67e66c: mov             x1, #0
    // 0x67e670: CheckStackOverflow
    //     0x67e670: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67e674: cmp             SP, x16
    //     0x67e678: b.ls            #0x67ed70
    // 0x67e67c: cmp             w0, NULL
    // 0x67e680: b.eq            #0x67e710
    // 0x67e684: add             x4, x1, #1
    // 0x67e688: stur            x4, [fp, #-0x38]
    // 0x67e68c: LoadField: r5 = r0->field_17
    //     0x67e68c: ldur            w5, [x0, #0x17]
    // 0x67e690: DecompressPointer r5
    //     0x67e690: add             x5, x5, HEAP, lsl #32
    // 0x67e694: stur            x5, [fp, #-0x20]
    // 0x67e698: cmp             w5, NULL
    // 0x67e69c: b.eq            #0x67ed78
    // 0x67e6a0: mov             x0, x5
    // 0x67e6a4: r2 = Null
    //     0x67e6a4: mov             x2, NULL
    // 0x67e6a8: r1 = Null
    //     0x67e6a8: mov             x1, NULL
    // 0x67e6ac: r4 = LoadClassIdInstr(r0)
    //     0x67e6ac: ldur            x4, [x0, #-1]
    //     0x67e6b0: ubfx            x4, x4, #0xc, #0x14
    // 0x67e6b4: sub             x4, x4, #0x7f9
    // 0x67e6b8: cmp             x4, #2
    // 0x67e6bc: b.ls            #0x67e6d4
    // 0x67e6c0: r8 = SliverMultiBoxAdaptorParentData
    //     0x67e6c0: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67e6c4: ldr             x8, [x8, #0x120]
    // 0x67e6c8: r3 = Null
    //     0x67e6c8: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b020] Null
    //     0x67e6cc: ldr             x3, [x3, #0x20]
    // 0x67e6d0: r0 = DefaultTypeTest()
    //     0x67e6d0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67e6d4: ldur            x0, [fp, #-0x20]
    // 0x67e6d8: LoadField: r2 = r0->field_f
    //     0x67e6d8: ldur            w2, [x0, #0xf]
    // 0x67e6dc: DecompressPointer r2
    //     0x67e6dc: add             x2, x2, HEAP, lsl #32
    // 0x67e6e0: mov             x0, x2
    // 0x67e6e4: ldur            x3, [fp, #-0x10]
    // 0x67e6e8: StoreField: r3->field_1f = r0
    //     0x67e6e8: stur            w0, [x3, #0x1f]
    //     0x67e6ec: ldurb           w16, [x3, #-1]
    //     0x67e6f0: ldurb           w17, [x0, #-1]
    //     0x67e6f4: and             x16, x17, x16, lsr #2
    //     0x67e6f8: tst             x16, HEAP, lsr #32
    //     0x67e6fc: b.eq            #0x67e704
    //     0x67e700: bl              #0xd682ac
    // 0x67e704: ldur            x1, [fp, #-0x38]
    // 0x67e708: mov             x0, x2
    // 0x67e70c: b               #0x67e670
    // 0x67e710: mov             x5, x1
    // 0x67e714: b               #0x67e71c
    // 0x67e718: r5 = 0
    //     0x67e718: mov             x5, #0
    // 0x67e71c: ldur            x4, [fp, #-0x60]
    // 0x67e720: ldur            x2, [fp, #-0x28]
    // 0x67e724: r0 = BoxInt64Instr(r4)
    //     0x67e724: sbfiz           x0, x4, #1, #0x1f
    //     0x67e728: cmp             x4, x0, asr #1
    //     0x67e72c: b.eq            #0x67e738
    //     0x67e730: bl              #0xd69bb8
    //     0x67e734: stur            x4, [x0, #7]
    // 0x67e738: ldr             x16, [fp, #0x10]
    // 0x67e73c: stp             x0, x16, [SP, #-0x10]!
    // 0x67e740: SaveReg r5
    //     0x67e740: str             x5, [SP, #-8]!
    // 0x67e744: r0 = collectGarbage()
    //     0x67e744: bl              #0x6797bc  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::collectGarbage
    // 0x67e748: add             SP, SP, #0x18
    // 0x67e74c: ldur            x0, [fp, #-0x28]
    // 0x67e750: tbnz            w0, #4, #0x67e768
    // 0x67e754: ldur            x3, [fp, #-0x10]
    // 0x67e758: LoadField: r0 = r3->field_27
    //     0x67e758: ldur            w0, [x3, #0x27]
    // 0x67e75c: DecompressPointer r0
    //     0x67e75c: add             x0, x0, HEAP, lsl #32
    // 0x67e760: mov             x6, x0
    // 0x67e764: b               #0x67e8fc
    // 0x67e768: ldr             x4, [fp, #0x10]
    // 0x67e76c: ldur            x3, [fp, #-0x10]
    // 0x67e770: LoadField: r5 = r4->field_5b
    //     0x67e770: ldur            w5, [x4, #0x5b]
    // 0x67e774: DecompressPointer r5
    //     0x67e774: add             x5, x5, HEAP, lsl #32
    // 0x67e778: stur            x5, [fp, #-0x28]
    // 0x67e77c: cmp             w5, NULL
    // 0x67e780: b.eq            #0x67ed7c
    // 0x67e784: LoadField: r6 = r5->field_17
    //     0x67e784: ldur            w6, [x5, #0x17]
    // 0x67e788: DecompressPointer r6
    //     0x67e788: add             x6, x6, HEAP, lsl #32
    // 0x67e78c: stur            x6, [fp, #-0x20]
    // 0x67e790: cmp             w6, NULL
    // 0x67e794: b.eq            #0x67ed80
    // 0x67e798: mov             x0, x6
    // 0x67e79c: r2 = Null
    //     0x67e79c: mov             x2, NULL
    // 0x67e7a0: r1 = Null
    //     0x67e7a0: mov             x1, NULL
    // 0x67e7a4: r4 = LoadClassIdInstr(r0)
    //     0x67e7a4: ldur            x4, [x0, #-1]
    //     0x67e7a8: ubfx            x4, x4, #0xc, #0x14
    // 0x67e7ac: sub             x4, x4, #0x7f9
    // 0x67e7b0: cmp             x4, #2
    // 0x67e7b4: b.ls            #0x67e7cc
    // 0x67e7b8: r8 = SliverMultiBoxAdaptorParentData
    //     0x67e7b8: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67e7bc: ldr             x8, [x8, #0x120]
    // 0x67e7c0: r3 = Null
    //     0x67e7c0: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b030] Null
    //     0x67e7c4: ldr             x3, [x3, #0x30]
    // 0x67e7c8: r0 = DefaultTypeTest()
    //     0x67e7c8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67e7cc: ldur            x3, [fp, #-0x20]
    // 0x67e7d0: LoadField: r4 = r3->field_17
    //     0x67e7d0: ldur            w4, [x3, #0x17]
    // 0x67e7d4: DecompressPointer r4
    //     0x67e7d4: add             x4, x4, HEAP, lsl #32
    // 0x67e7d8: stur            x4, [fp, #-0x40]
    // 0x67e7dc: cmp             w4, NULL
    // 0x67e7e0: b.eq            #0x67ed84
    // 0x67e7e4: ldr             x5, [fp, #0x10]
    // 0x67e7e8: LoadField: r0 = r5->field_5f
    //     0x67e7e8: ldur            w0, [x5, #0x5f]
    // 0x67e7ec: DecompressPointer r0
    //     0x67e7ec: add             x0, x0, HEAP, lsl #32
    // 0x67e7f0: cmp             w0, NULL
    // 0x67e7f4: b.eq            #0x67ed88
    // 0x67e7f8: LoadField: r6 = r0->field_17
    //     0x67e7f8: ldur            w6, [x0, #0x17]
    // 0x67e7fc: DecompressPointer r6
    //     0x67e7fc: add             x6, x6, HEAP, lsl #32
    // 0x67e800: stur            x6, [fp, #-0x30]
    // 0x67e804: cmp             w6, NULL
    // 0x67e808: b.eq            #0x67ed8c
    // 0x67e80c: mov             x0, x6
    // 0x67e810: r2 = Null
    //     0x67e810: mov             x2, NULL
    // 0x67e814: r1 = Null
    //     0x67e814: mov             x1, NULL
    // 0x67e818: r4 = LoadClassIdInstr(r0)
    //     0x67e818: ldur            x4, [x0, #-1]
    //     0x67e81c: ubfx            x4, x4, #0xc, #0x14
    // 0x67e820: sub             x4, x4, #0x7f9
    // 0x67e824: cmp             x4, #2
    // 0x67e828: b.ls            #0x67e840
    // 0x67e82c: r8 = SliverMultiBoxAdaptorParentData
    //     0x67e82c: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67e830: ldr             x8, [x8, #0x120]
    // 0x67e834: r3 = Null
    //     0x67e834: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b040] Null
    //     0x67e838: ldr             x3, [x3, #0x40]
    // 0x67e83c: r0 = DefaultTypeTest()
    //     0x67e83c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67e840: ldur            x0, [fp, #-0x30]
    // 0x67e844: LoadField: r3 = r0->field_17
    //     0x67e844: ldur            w3, [x0, #0x17]
    // 0x67e848: DecompressPointer r3
    //     0x67e848: add             x3, x3, HEAP, lsl #32
    // 0x67e84c: stur            x3, [fp, #-0x48]
    // 0x67e850: cmp             w3, NULL
    // 0x67e854: b.eq            #0x67ed90
    // 0x67e858: ldur            x0, [fp, #-0x28]
    // 0x67e85c: r2 = Null
    //     0x67e85c: mov             x2, NULL
    // 0x67e860: r1 = Null
    //     0x67e860: mov             x1, NULL
    // 0x67e864: r4 = LoadClassIdInstr(r0)
    //     0x67e864: ldur            x4, [x0, #-1]
    //     0x67e868: ubfx            x4, x4, #0xc, #0x14
    // 0x67e86c: sub             x4, x4, #0x961
    // 0x67e870: cmp             x4, #0xbe
    // 0x67e874: b.ls            #0x67e888
    // 0x67e878: r8 = RenderObject
    //     0x67e878: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x67e87c: r3 = Null
    //     0x67e87c: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b050] Null
    //     0x67e880: ldr             x3, [x3, #0x50]
    // 0x67e884: r0 = RenderObject()
    //     0x67e884: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x67e888: ldur            x0, [fp, #-0x20]
    // 0x67e88c: LoadField: r1 = r0->field_7
    //     0x67e88c: ldur            w1, [x0, #7]
    // 0x67e890: DecompressPointer r1
    //     0x67e890: add             x1, x1, HEAP, lsl #32
    // 0x67e894: ldur            x0, [fp, #-0x10]
    // 0x67e898: LoadField: r2 = r0->field_27
    //     0x67e898: ldur            w2, [x0, #0x27]
    // 0x67e89c: DecompressPointer r2
    //     0x67e89c: add             x2, x2, HEAP, lsl #32
    // 0x67e8a0: LoadField: d0 = r2->field_7
    //     0x67e8a0: ldur            d0, [x2, #7]
    // 0x67e8a4: ldur            x16, [fp, #-0x18]
    // 0x67e8a8: ldur            lr, [fp, #-8]
    // 0x67e8ac: stp             lr, x16, [SP, #-0x10]!
    // 0x67e8b0: ldur            x16, [fp, #-0x40]
    // 0x67e8b4: ldur            lr, [fp, #-0x48]
    // 0x67e8b8: stp             lr, x16, [SP, #-0x10]!
    // 0x67e8bc: SaveReg r1
    //     0x67e8bc: str             x1, [SP, #-8]!
    // 0x67e8c0: SaveReg d0
    //     0x67e8c0: str             d0, [SP, #-8]!
    // 0x67e8c4: r0 = estimateMaxScrollOffset()
    //     0x67e8c4: bl              #0x677cec  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::estimateMaxScrollOffset
    // 0x67e8c8: add             SP, SP, #0x30
    // 0x67e8cc: r0 = inline_Allocate_Double()
    //     0x67e8cc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x67e8d0: add             x0, x0, #0x10
    //     0x67e8d4: cmp             x1, x0
    //     0x67e8d8: b.ls            #0x67ed94
    //     0x67e8dc: str             x0, [THR, #0x60]  ; THR::top
    //     0x67e8e0: sub             x0, x0, #0xf
    //     0x67e8e4: mov             x1, #0xd108
    //     0x67e8e8: movk            x1, #3, lsl #16
    //     0x67e8ec: stur            x1, [x0, #-1]
    // 0x67e8f0: StoreField: r0->field_7 = d0
    //     0x67e8f0: stur            d0, [x0, #7]
    // 0x67e8f4: mov             x6, x0
    // 0x67e8f8: ldur            x3, [fp, #-0x10]
    // 0x67e8fc: ldr             x4, [fp, #0x10]
    // 0x67e900: ldur            d0, [fp, #-0x78]
    // 0x67e904: ldur            x5, [fp, #-8]
    // 0x67e908: stur            x6, [fp, #-0x28]
    // 0x67e90c: LoadField: r7 = r4->field_5b
    //     0x67e90c: ldur            w7, [x4, #0x5b]
    // 0x67e910: DecompressPointer r7
    //     0x67e910: add             x7, x7, HEAP, lsl #32
    // 0x67e914: stur            x7, [fp, #-0x20]
    // 0x67e918: cmp             w7, NULL
    // 0x67e91c: b.eq            #0x67eda4
    // 0x67e920: mov             x0, x7
    // 0x67e924: r2 = Null
    //     0x67e924: mov             x2, NULL
    // 0x67e928: r1 = Null
    //     0x67e928: mov             x1, NULL
    // 0x67e92c: r4 = LoadClassIdInstr(r0)
    //     0x67e92c: ldur            x4, [x0, #-1]
    //     0x67e930: ubfx            x4, x4, #0xc, #0x14
    // 0x67e934: sub             x4, x4, #0x961
    // 0x67e938: cmp             x4, #0xbe
    // 0x67e93c: b.ls            #0x67e950
    // 0x67e940: r8 = RenderObject
    //     0x67e940: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x67e944: r3 = Null
    //     0x67e944: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b060] Null
    //     0x67e948: ldr             x3, [x3, #0x60]
    // 0x67e94c: r0 = RenderObject()
    //     0x67e94c: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x67e950: ldur            x0, [fp, #-0x20]
    // 0x67e954: LoadField: r3 = r0->field_17
    //     0x67e954: ldur            w3, [x0, #0x17]
    // 0x67e958: DecompressPointer r3
    //     0x67e958: add             x3, x3, HEAP, lsl #32
    // 0x67e95c: stur            x3, [fp, #-0x30]
    // 0x67e960: cmp             w3, NULL
    // 0x67e964: b.eq            #0x67eda8
    // 0x67e968: mov             x0, x3
    // 0x67e96c: r2 = Null
    //     0x67e96c: mov             x2, NULL
    // 0x67e970: r1 = Null
    //     0x67e970: mov             x1, NULL
    // 0x67e974: r4 = LoadClassIdInstr(r0)
    //     0x67e974: ldur            x4, [x0, #-1]
    //     0x67e978: ubfx            x4, x4, #0xc, #0x14
    // 0x67e97c: sub             x4, x4, #0x7f9
    // 0x67e980: cmp             x4, #2
    // 0x67e984: b.ls            #0x67e99c
    // 0x67e988: r8 = SliverMultiBoxAdaptorParentData
    //     0x67e988: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67e98c: ldr             x8, [x8, #0x120]
    // 0x67e990: r3 = Null
    //     0x67e990: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b070] Null
    //     0x67e994: ldr             x3, [x3, #0x70]
    // 0x67e998: r0 = DefaultTypeTest()
    //     0x67e998: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67e99c: ldur            x0, [fp, #-0x30]
    // 0x67e9a0: LoadField: r1 = r0->field_7
    //     0x67e9a0: ldur            w1, [x0, #7]
    // 0x67e9a4: DecompressPointer r1
    //     0x67e9a4: add             x1, x1, HEAP, lsl #32
    // 0x67e9a8: cmp             w1, NULL
    // 0x67e9ac: b.eq            #0x67edac
    // 0x67e9b0: ldur            x0, [fp, #-0x10]
    // 0x67e9b4: LoadField: r2 = r0->field_27
    //     0x67e9b4: ldur            w2, [x0, #0x27]
    // 0x67e9b8: DecompressPointer r2
    //     0x67e9b8: add             x2, x2, HEAP, lsl #32
    // 0x67e9bc: LoadField: d0 = r1->field_7
    //     0x67e9bc: ldur            d0, [x1, #7]
    // 0x67e9c0: ldr             x16, [fp, #0x10]
    // 0x67e9c4: ldur            lr, [fp, #-8]
    // 0x67e9c8: stp             lr, x16, [SP, #-0x10]!
    // 0x67e9cc: SaveReg d0
    //     0x67e9cc: str             d0, [SP, #-8]!
    // 0x67e9d0: SaveReg r2
    //     0x67e9d0: str             x2, [SP, #-8]!
    // 0x67e9d4: r0 = calculatePaintOffset()
    //     0x67e9d4: bl              #0x677ba0  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0x67e9d8: add             SP, SP, #0x20
    // 0x67e9dc: ldr             x3, [fp, #0x10]
    // 0x67e9e0: stur            d0, [fp, #-0x68]
    // 0x67e9e4: LoadField: r4 = r3->field_5b
    //     0x67e9e4: ldur            w4, [x3, #0x5b]
    // 0x67e9e8: DecompressPointer r4
    //     0x67e9e8: add             x4, x4, HEAP, lsl #32
    // 0x67e9ec: stur            x4, [fp, #-0x20]
    // 0x67e9f0: cmp             w4, NULL
    // 0x67e9f4: b.eq            #0x67edb0
    // 0x67e9f8: mov             x0, x4
    // 0x67e9fc: r2 = Null
    //     0x67e9fc: mov             x2, NULL
    // 0x67ea00: r1 = Null
    //     0x67ea00: mov             x1, NULL
    // 0x67ea04: r4 = LoadClassIdInstr(r0)
    //     0x67ea04: ldur            x4, [x0, #-1]
    //     0x67ea08: ubfx            x4, x4, #0xc, #0x14
    // 0x67ea0c: sub             x4, x4, #0x961
    // 0x67ea10: cmp             x4, #0xbe
    // 0x67ea14: b.ls            #0x67ea28
    // 0x67ea18: r8 = RenderObject
    //     0x67ea18: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x67ea1c: r3 = Null
    //     0x67ea1c: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b080] Null
    //     0x67ea20: ldr             x3, [x3, #0x80]
    // 0x67ea24: r0 = RenderObject()
    //     0x67ea24: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x67ea28: ldur            x0, [fp, #-0x20]
    // 0x67ea2c: LoadField: r3 = r0->field_17
    //     0x67ea2c: ldur            w3, [x0, #0x17]
    // 0x67ea30: DecompressPointer r3
    //     0x67ea30: add             x3, x3, HEAP, lsl #32
    // 0x67ea34: stur            x3, [fp, #-0x30]
    // 0x67ea38: cmp             w3, NULL
    // 0x67ea3c: b.eq            #0x67edb4
    // 0x67ea40: mov             x0, x3
    // 0x67ea44: r2 = Null
    //     0x67ea44: mov             x2, NULL
    // 0x67ea48: r1 = Null
    //     0x67ea48: mov             x1, NULL
    // 0x67ea4c: r4 = LoadClassIdInstr(r0)
    //     0x67ea4c: ldur            x4, [x0, #-1]
    //     0x67ea50: ubfx            x4, x4, #0xc, #0x14
    // 0x67ea54: sub             x4, x4, #0x7f9
    // 0x67ea58: cmp             x4, #2
    // 0x67ea5c: b.ls            #0x67ea74
    // 0x67ea60: r8 = SliverMultiBoxAdaptorParentData
    //     0x67ea60: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67ea64: ldr             x8, [x8, #0x120]
    // 0x67ea68: r3 = Null
    //     0x67ea68: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b090] Null
    //     0x67ea6c: ldr             x3, [x3, #0x90]
    // 0x67ea70: r0 = DefaultTypeTest()
    //     0x67ea70: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67ea74: ldur            x0, [fp, #-0x30]
    // 0x67ea78: LoadField: r1 = r0->field_7
    //     0x67ea78: ldur            w1, [x0, #7]
    // 0x67ea7c: DecompressPointer r1
    //     0x67ea7c: add             x1, x1, HEAP, lsl #32
    // 0x67ea80: cmp             w1, NULL
    // 0x67ea84: b.eq            #0x67edb8
    // 0x67ea88: ldur            x0, [fp, #-0x10]
    // 0x67ea8c: LoadField: r2 = r0->field_27
    //     0x67ea8c: ldur            w2, [x0, #0x27]
    // 0x67ea90: DecompressPointer r2
    //     0x67ea90: add             x2, x2, HEAP, lsl #32
    // 0x67ea94: LoadField: d0 = r1->field_7
    //     0x67ea94: ldur            d0, [x1, #7]
    // 0x67ea98: ldr             x16, [fp, #0x10]
    // 0x67ea9c: ldur            lr, [fp, #-8]
    // 0x67eaa0: stp             lr, x16, [SP, #-0x10]!
    // 0x67eaa4: SaveReg d0
    //     0x67eaa4: str             d0, [SP, #-8]!
    // 0x67eaa8: SaveReg r2
    //     0x67eaa8: str             x2, [SP, #-8]!
    // 0x67eaac: r0 = calculateCacheOffset()
    //     0x67eaac: bl              #0x677aa4  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculateCacheOffset
    // 0x67eab0: add             SP, SP, #0x20
    // 0x67eab4: ldur            x0, [fp, #-8]
    // 0x67eab8: stur            d0, [fp, #-0x80]
    // 0x67eabc: LoadField: d1 = r0->field_2b
    //     0x67eabc: ldur            d1, [x0, #0x2b]
    // 0x67eac0: ldur            d2, [fp, #-0x78]
    // 0x67eac4: fadd            d3, d2, d1
    // 0x67eac8: ldur            x0, [fp, #-0x10]
    // 0x67eacc: LoadField: r1 = r0->field_27
    //     0x67eacc: ldur            w1, [x0, #0x27]
    // 0x67ead0: DecompressPointer r1
    //     0x67ead0: add             x1, x1, HEAP, lsl #32
    // 0x67ead4: stur            x1, [fp, #-0x20]
    // 0x67ead8: cmp             w1, NULL
    // 0x67eadc: b.eq            #0x67edbc
    // 0x67eae0: LoadField: d1 = r1->field_7
    //     0x67eae0: ldur            d1, [x1, #7]
    // 0x67eae4: fcmp            d1, d3
    // 0x67eae8: b.vs            #0x67eafc
    // 0x67eaec: b.le            #0x67eafc
    // 0x67eaf0: r3 = true
    //     0x67eaf0: add             x3, NULL, #0x20  ; true
    // 0x67eaf4: d1 = 0.000000
    //     0x67eaf4: eor             v1.16b, v1.16b, v1.16b
    // 0x67eaf8: b               #0x67eb1c
    // 0x67eafc: d1 = 0.000000
    //     0x67eafc: eor             v1.16b, v1.16b, v1.16b
    // 0x67eb00: fcmp            d2, d1
    // 0x67eb04: b.vs            #0x67eb0c
    // 0x67eb08: b.gt            #0x67eb14
    // 0x67eb0c: r0 = false
    //     0x67eb0c: add             x0, NULL, #0x30  ; false
    // 0x67eb10: b               #0x67eb18
    // 0x67eb14: r0 = true
    //     0x67eb14: add             x0, NULL, #0x20  ; true
    // 0x67eb18: mov             x3, x0
    // 0x67eb1c: ldr             x0, [fp, #0x10]
    // 0x67eb20: ldur            x2, [fp, #-0x28]
    // 0x67eb24: ldur            d2, [fp, #-0x68]
    // 0x67eb28: stur            x3, [fp, #-8]
    // 0x67eb2c: LoadField: d3 = r2->field_7
    //     0x67eb2c: ldur            d3, [x2, #7]
    // 0x67eb30: stur            d3, [fp, #-0x70]
    // 0x67eb34: r0 = SliverGeometry()
    //     0x67eb34: bl              #0x679334  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x54)
    // 0x67eb38: ldur            d0, [fp, #-0x70]
    // 0x67eb3c: StoreField: r0->field_7 = d0
    //     0x67eb3c: stur            d0, [x0, #7]
    // 0x67eb40: ldur            d1, [fp, #-0x68]
    // 0x67eb44: StoreField: r0->field_17 = d1
    //     0x67eb44: stur            d1, [x0, #0x17]
    // 0x67eb48: d2 = 0.000000
    //     0x67eb48: eor             v2.16b, v2.16b, v2.16b
    // 0x67eb4c: StoreField: r0->field_f = d2
    //     0x67eb4c: stur            d2, [x0, #0xf]
    // 0x67eb50: StoreField: r0->field_27 = d0
    //     0x67eb50: stur            d0, [x0, #0x27]
    // 0x67eb54: StoreField: r0->field_2f = d2
    //     0x67eb54: stur            d2, [x0, #0x2f]
    // 0x67eb58: ldur            x1, [fp, #-8]
    // 0x67eb5c: StoreField: r0->field_43 = r1
    //     0x67eb5c: stur            w1, [x0, #0x43]
    // 0x67eb60: StoreField: r0->field_1f = d1
    //     0x67eb60: stur            d1, [x0, #0x1f]
    // 0x67eb64: StoreField: r0->field_37 = d1
    //     0x67eb64: stur            d1, [x0, #0x37]
    // 0x67eb68: ldur            d0, [fp, #-0x80]
    // 0x67eb6c: StoreField: r0->field_4b = d0
    //     0x67eb6c: stur            d0, [x0, #0x4b]
    // 0x67eb70: fcmp            d1, d2
    // 0x67eb74: b.vs            #0x67eb7c
    // 0x67eb78: b.gt            #0x67eb84
    // 0x67eb7c: r1 = false
    //     0x67eb7c: add             x1, NULL, #0x30  ; false
    // 0x67eb80: b               #0x67eb88
    // 0x67eb84: r1 = true
    //     0x67eb84: add             x1, NULL, #0x20  ; true
    // 0x67eb88: StoreField: r0->field_3f = r1
    //     0x67eb88: stur            w1, [x0, #0x3f]
    // 0x67eb8c: ldr             x1, [fp, #0x10]
    // 0x67eb90: StoreField: r1->field_4f = r0
    //     0x67eb90: stur            w0, [x1, #0x4f]
    //     0x67eb94: ldurb           w16, [x1, #-1]
    //     0x67eb98: ldurb           w17, [x0, #-1]
    //     0x67eb9c: and             x16, x17, x16, lsr #2
    //     0x67eba0: tst             x16, HEAP, lsr #32
    //     0x67eba4: b.eq            #0x67ebac
    //     0x67eba8: bl              #0xd6826c
    // 0x67ebac: ldur            x16, [fp, #-0x28]
    // 0x67ebb0: ldur            lr, [fp, #-0x20]
    // 0x67ebb4: stp             lr, x16, [SP, #-0x10]!
    // 0x67ebb8: r0 = ==()
    //     0x67ebb8: bl              #0xcbbae4  ; [dart:core] _Double::==
    // 0x67ebbc: add             SP, SP, #0x10
    // 0x67ebc0: tbnz            w0, #4, #0x67ebd4
    // 0x67ebc4: ldur            x1, [fp, #-0x18]
    // 0x67ebc8: r0 = true
    //     0x67ebc8: add             x0, NULL, #0x20  ; true
    // 0x67ebcc: StoreField: r1->field_53 = r0
    //     0x67ebcc: stur            w0, [x1, #0x53]
    // 0x67ebd0: b               #0x67ebd8
    // 0x67ebd4: ldur            x1, [fp, #-0x18]
    // 0x67ebd8: SaveReg r1
    //     0x67ebd8: str             x1, [SP, #-8]!
    // 0x67ebdc: r0 = didFinishLayout()
    //     0x67ebdc: bl              #0x678c84  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::didFinishLayout
    // 0x67ebe0: add             SP, SP, #8
    // 0x67ebe4: r0 = Null
    //     0x67ebe4: mov             x0, NULL
    // 0x67ebe8: LeaveFrame
    //     0x67ebe8: mov             SP, fp
    //     0x67ebec: ldp             fp, lr, [SP], #0x10
    // 0x67ebf0: ret
    //     0x67ebf0: ret             
    // 0x67ebf4: r0 = StateError()
    //     0x67ebf4: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x67ebf8: r6 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x67ebf8: add             x6, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x67ebfc: ldr             x6, [x6, #0x1e8]
    // 0x67ec00: StoreField: r0->field_b = r6
    //     0x67ec00: stur            w6, [x0, #0xb]
    // 0x67ec04: r0 = Throw()
    //     0x67ec04: bl              #0xd67e38  ; ThrowStub
    // 0x67ec08: brk             #0
    // 0x67ec0c: r0 = StateError()
    //     0x67ec0c: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x67ec10: r9 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x67ec10: add             x9, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x67ec14: ldr             x9, [x9, #0x1e8]
    // 0x67ec18: StoreField: r0->field_b = r9
    //     0x67ec18: stur            w9, [x0, #0xb]
    // 0x67ec1c: r0 = Throw()
    //     0x67ec1c: bl              #0xd67e38  ; ThrowStub
    // 0x67ec20: brk             #0
    // 0x67ec24: r0 = StateError()
    //     0x67ec24: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x67ec28: r7 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x67ec28: add             x7, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x67ec2c: ldr             x7, [x7, #0x1e8]
    // 0x67ec30: StoreField: r0->field_b = r7
    //     0x67ec30: stur            w7, [x0, #0xb]
    // 0x67ec34: r0 = Throw()
    //     0x67ec34: bl              #0xd67e38  ; ThrowStub
    // 0x67ec38: brk             #0
    // 0x67ec3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x67ec3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x67ec40: b               #0x67d424
    // 0x67ec44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ec44: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ec48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ec48: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ec4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x67ec4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x67ec50: b               #0x67d638
    // 0x67ec54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ec54: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ec58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ec58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ec5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ec5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ec60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ec60: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ec64: r0 = StackOverflowSharedWithFPURegs()
    //     0x67ec64: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x67ec68: b               #0x67d864
    // 0x67ec6c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67ec6c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67ec70: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67ec70: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67ec74: stp             q0, q1, [SP, #-0x20]!
    // 0x67ec78: SaveReg r0
    //     0x67ec78: str             x0, [SP, #-8]!
    // 0x67ec7c: r0 = AllocateDouble()
    //     0x67ec7c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67ec80: mov             x1, x0
    // 0x67ec84: RestoreReg r0
    //     0x67ec84: ldr             x0, [SP], #8
    // 0x67ec88: ldp             q0, q1, [SP], #0x20
    // 0x67ec8c: b               #0x67da0c
    // 0x67ec90: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67ec90: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67ec94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ec94: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ec98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ec98: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ec9c: stp             q0, q1, [SP, #-0x20]!
    // 0x67eca0: SaveReg r0
    //     0x67eca0: str             x0, [SP, #-8]!
    // 0x67eca4: r0 = AllocateDouble()
    //     0x67eca4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67eca8: mov             x1, x0
    // 0x67ecac: RestoreReg r0
    //     0x67ecac: ldr             x0, [SP], #8
    // 0x67ecb0: ldp             q0, q1, [SP], #0x20
    // 0x67ecb4: b               #0x67dbac
    // 0x67ecb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ecb8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ecbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ecbc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ecc0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67ecc0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67ecc4: SaveReg d3
    //     0x67ecc4: str             q3, [SP, #-0x10]!
    // 0x67ecc8: r0 = AllocateDouble()
    //     0x67ecc8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67eccc: RestoreReg d3
    //     0x67eccc: ldr             q3, [SP], #0x10
    // 0x67ecd0: b               #0x67dcf8
    // 0x67ecd4: r0 = StackOverflowSharedWithFPURegs()
    //     0x67ecd4: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x67ecd8: b               #0x67dddc
    // 0x67ecdc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67ecdc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67ece0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67ece0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67ece4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ece4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ece8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ece8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ecec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ecec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ecf0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ecf0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ecf4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ecf4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ecf8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67ecf8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67ecfc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67ecfc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67ed00: stp             q0, q1, [SP, #-0x20]!
    // 0x67ed04: SaveReg r0
    //     0x67ed04: str             x0, [SP, #-8]!
    // 0x67ed08: r0 = AllocateDouble()
    //     0x67ed08: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67ed0c: mov             x1, x0
    // 0x67ed10: RestoreReg r0
    //     0x67ed10: ldr             x0, [SP], #8
    // 0x67ed14: ldp             q0, q1, [SP], #0x20
    // 0x67ed18: b               #0x67e07c
    // 0x67ed1c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67ed1c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67ed20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ed20: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ed24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ed24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ed28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ed28: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ed2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ed2c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ed30: r0 = NullErrorSharedWithoutFPURegs()
    //     0x67ed30: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x67ed34: SaveReg d2
    //     0x67ed34: str             q2, [SP, #-0x10]!
    // 0x67ed38: r0 = AllocateDouble()
    //     0x67ed38: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67ed3c: RestoreReg d2
    //     0x67ed3c: ldr             q2, [SP], #0x10
    // 0x67ed40: b               #0x67e2f0
    // 0x67ed44: r0 = StackOverflowSharedWithFPURegs()
    //     0x67ed44: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x67ed48: b               #0x67e34c
    // 0x67ed4c: r0 = NullErrorSharedWithFPURegs()
    //     0x67ed4c: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x67ed50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ed50: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ed54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ed54: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ed58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ed58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ed5c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x67ed5c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x67ed60: r0 = StackOverflowSharedWithFPURegs()
    //     0x67ed60: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x67ed64: b               #0x67e568
    // 0x67ed68: r0 = NullErrorSharedWithFPURegs()
    //     0x67ed68: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x67ed6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ed6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ed70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x67ed70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x67ed74: b               #0x67e67c
    // 0x67ed78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ed78: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ed7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ed7c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ed80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ed80: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ed84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ed84: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ed88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ed88: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ed8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ed8c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ed90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ed90: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ed94: SaveReg d0
    //     0x67ed94: str             q0, [SP, #-0x10]!
    // 0x67ed98: r0 = AllocateDouble()
    //     0x67ed98: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67ed9c: RestoreReg d0
    //     0x67ed9c: ldr             q0, [SP], #0x10
    // 0x67eda0: b               #0x67e8f0
    // 0x67eda4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67eda4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67eda8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67eda8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67edac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67edac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67edb0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67edb0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67edb4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67edb4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67edb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67edb8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67edbc: r0 = NullErrorSharedWithFPURegs()
    //     0x67edbc: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
  }
  [closure] bool advance(dynamic) {
    // ** addr: 0x67edc0, size: 0x4dc
    // 0x67edc0: EnterFrame
    //     0x67edc0: stp             fp, lr, [SP, #-0x10]!
    //     0x67edc4: mov             fp, SP
    // 0x67edc8: AllocStack(0x28)
    //     0x67edc8: sub             SP, SP, #0x28
    // 0x67edcc: SetupParameters()
    //     0x67edcc: ldr             x0, [fp, #0x10]
    //     0x67edd0: ldur            w1, [x0, #0x17]
    //     0x67edd4: add             x1, x1, HEAP, lsl #32
    //     0x67edd8: stur            x1, [fp, #-8]
    // 0x67eddc: CheckStackOverflow
    //     0x67eddc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67ede0: cmp             SP, x16
    //     0x67ede4: b.ls            #0x67f260
    // 0x67ede8: LoadField: r0 = r1->field_1f
    //     0x67ede8: ldur            w0, [x1, #0x1f]
    // 0x67edec: DecompressPointer r0
    //     0x67edec: add             x0, x0, HEAP, lsl #32
    // 0x67edf0: LoadField: r2 = r1->field_17
    //     0x67edf0: ldur            w2, [x1, #0x17]
    // 0x67edf4: DecompressPointer r2
    //     0x67edf4: add             x2, x2, HEAP, lsl #32
    // 0x67edf8: r3 = LoadClassIdInstr(r0)
    //     0x67edf8: ldur            x3, [x0, #-1]
    //     0x67edfc: ubfx            x3, x3, #0xc, #0x14
    // 0x67ee00: stp             x2, x0, [SP, #-0x10]!
    // 0x67ee04: mov             x0, x3
    // 0x67ee08: mov             lr, x0
    // 0x67ee0c: ldr             lr, [x21, lr, lsl #3]
    // 0x67ee10: blr             lr
    // 0x67ee14: add             SP, SP, #0x10
    // 0x67ee18: tbnz            w0, #4, #0x67ee2c
    // 0x67ee1c: ldur            x3, [fp, #-8]
    // 0x67ee20: r4 = false
    //     0x67ee20: add             x4, NULL, #0x30  ; false
    // 0x67ee24: StoreField: r3->field_1b = r4
    //     0x67ee24: stur            w4, [x3, #0x1b]
    // 0x67ee28: b               #0x67ee34
    // 0x67ee2c: ldur            x3, [fp, #-8]
    // 0x67ee30: r4 = false
    //     0x67ee30: add             x4, NULL, #0x30  ; false
    // 0x67ee34: LoadField: r5 = r3->field_f
    //     0x67ee34: ldur            w5, [x3, #0xf]
    // 0x67ee38: DecompressPointer r5
    //     0x67ee38: add             x5, x5, HEAP, lsl #32
    // 0x67ee3c: stur            x5, [fp, #-0x18]
    // 0x67ee40: LoadField: r0 = r3->field_1f
    //     0x67ee40: ldur            w0, [x3, #0x1f]
    // 0x67ee44: DecompressPointer r0
    //     0x67ee44: add             x0, x0, HEAP, lsl #32
    // 0x67ee48: cmp             w0, NULL
    // 0x67ee4c: b.eq            #0x67f268
    // 0x67ee50: LoadField: r6 = r0->field_17
    //     0x67ee50: ldur            w6, [x0, #0x17]
    // 0x67ee54: DecompressPointer r6
    //     0x67ee54: add             x6, x6, HEAP, lsl #32
    // 0x67ee58: stur            x6, [fp, #-0x10]
    // 0x67ee5c: cmp             w6, NULL
    // 0x67ee60: b.eq            #0x67f26c
    // 0x67ee64: mov             x0, x6
    // 0x67ee68: r2 = Null
    //     0x67ee68: mov             x2, NULL
    // 0x67ee6c: r1 = Null
    //     0x67ee6c: mov             x1, NULL
    // 0x67ee70: r4 = LoadClassIdInstr(r0)
    //     0x67ee70: ldur            x4, [x0, #-1]
    //     0x67ee74: ubfx            x4, x4, #0xc, #0x14
    // 0x67ee78: sub             x4, x4, #0x7f9
    // 0x67ee7c: cmp             x4, #2
    // 0x67ee80: b.ls            #0x67ee98
    // 0x67ee84: r8 = SliverMultiBoxAdaptorParentData
    //     0x67ee84: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67ee88: ldr             x8, [x8, #0x120]
    // 0x67ee8c: r3 = Null
    //     0x67ee8c: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b0a0] Null
    //     0x67ee90: ldr             x3, [x3, #0xa0]
    // 0x67ee94: r0 = DefaultTypeTest()
    //     0x67ee94: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67ee98: ldur            x0, [fp, #-0x10]
    // 0x67ee9c: LoadField: r2 = r0->field_f
    //     0x67ee9c: ldur            w2, [x0, #0xf]
    // 0x67eea0: DecompressPointer r2
    //     0x67eea0: add             x2, x2, HEAP, lsl #32
    // 0x67eea4: mov             x0, x2
    // 0x67eea8: ldur            x3, [fp, #-8]
    // 0x67eeac: stur            x2, [fp, #-0x28]
    // 0x67eeb0: StoreField: r3->field_1f = r0
    //     0x67eeb0: stur            w0, [x3, #0x1f]
    //     0x67eeb4: ldurb           w16, [x3, #-1]
    //     0x67eeb8: ldurb           w17, [x0, #-1]
    //     0x67eebc: and             x16, x17, x16, lsr #2
    //     0x67eec0: tst             x16, HEAP, lsr #32
    //     0x67eec4: b.eq            #0x67eecc
    //     0x67eec8: bl              #0xd682ac
    // 0x67eecc: cmp             w2, NULL
    // 0x67eed0: b.ne            #0x67eee0
    // 0x67eed4: r4 = false
    //     0x67eed4: add             x4, NULL, #0x30  ; false
    // 0x67eed8: StoreField: r3->field_1b = r4
    //     0x67eed8: stur            w4, [x3, #0x1b]
    // 0x67eedc: b               #0x67eee4
    // 0x67eee0: r4 = false
    //     0x67eee0: add             x4, NULL, #0x30  ; false
    // 0x67eee4: LoadField: r0 = r3->field_23
    //     0x67eee4: ldur            w0, [x3, #0x23]
    // 0x67eee8: DecompressPointer r0
    //     0x67eee8: add             x0, x0, HEAP, lsl #32
    // 0x67eeec: cmp             w0, NULL
    // 0x67eef0: b.eq            #0x67f270
    // 0x67eef4: r1 = LoadInt32Instr(r0)
    //     0x67eef4: sbfx            x1, x0, #1, #0x1f
    //     0x67eef8: tbz             w0, #0, #0x67ef00
    //     0x67eefc: ldur            x1, [x0, #7]
    // 0x67ef00: add             x5, x1, #1
    // 0x67ef04: r0 = BoxInt64Instr(r5)
    //     0x67ef04: sbfiz           x0, x5, #1, #0x1f
    //     0x67ef08: cmp             x5, x0, asr #1
    //     0x67ef0c: b.eq            #0x67ef18
    //     0x67ef10: bl              #0xd69bb8
    //     0x67ef14: stur            x5, [x0, #7]
    // 0x67ef18: mov             x1, x0
    // 0x67ef1c: stur            x1, [fp, #-0x20]
    // 0x67ef20: StoreField: r3->field_23 = r0
    //     0x67ef20: stur            w0, [x3, #0x23]
    //     0x67ef24: tbz             w0, #0, #0x67ef40
    //     0x67ef28: ldurb           w16, [x3, #-1]
    //     0x67ef2c: ldurb           w17, [x0, #-1]
    //     0x67ef30: and             x16, x17, x16, lsr #2
    //     0x67ef34: tst             x16, HEAP, lsr #32
    //     0x67ef38: b.eq            #0x67ef40
    //     0x67ef3c: bl              #0xd682ac
    // 0x67ef40: LoadField: r5 = r3->field_1b
    //     0x67ef40: ldur            w5, [x3, #0x1b]
    // 0x67ef44: DecompressPointer r5
    //     0x67ef44: add             x5, x5, HEAP, lsl #32
    // 0x67ef48: mov             x0, x5
    // 0x67ef4c: stur            x5, [fp, #-0x10]
    // 0x67ef50: tbnz            w0, #5, #0x67ef58
    // 0x67ef54: r0 = AssertBoolean()
    //     0x67ef54: bl              #0xd67df0  ; AssertBooleanStub
    // 0x67ef58: ldur            x0, [fp, #-0x10]
    // 0x67ef5c: tbz             w0, #4, #0x67f100
    // 0x67ef60: ldur            x3, [fp, #-0x28]
    // 0x67ef64: cmp             w3, NULL
    // 0x67ef68: b.eq            #0x67f010
    // 0x67ef6c: ldur            x4, [fp, #-0x20]
    // 0x67ef70: LoadField: r5 = r3->field_17
    //     0x67ef70: ldur            w5, [x3, #0x17]
    // 0x67ef74: DecompressPointer r5
    //     0x67ef74: add             x5, x5, HEAP, lsl #32
    // 0x67ef78: stur            x5, [fp, #-0x10]
    // 0x67ef7c: cmp             w5, NULL
    // 0x67ef80: b.eq            #0x67f274
    // 0x67ef84: mov             x0, x5
    // 0x67ef88: r2 = Null
    //     0x67ef88: mov             x2, NULL
    // 0x67ef8c: r1 = Null
    //     0x67ef8c: mov             x1, NULL
    // 0x67ef90: r4 = LoadClassIdInstr(r0)
    //     0x67ef90: ldur            x4, [x0, #-1]
    //     0x67ef94: ubfx            x4, x4, #0xc, #0x14
    // 0x67ef98: sub             x4, x4, #0x7f9
    // 0x67ef9c: cmp             x4, #2
    // 0x67efa0: b.ls            #0x67efb8
    // 0x67efa4: r8 = SliverMultiBoxAdaptorParentData
    //     0x67efa4: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67efa8: ldr             x8, [x8, #0x120]
    // 0x67efac: r3 = Null
    //     0x67efac: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b0b0] Null
    //     0x67efb0: ldr             x3, [x3, #0xb0]
    // 0x67efb4: r0 = DefaultTypeTest()
    //     0x67efb4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67efb8: ldur            x0, [fp, #-0x10]
    // 0x67efbc: LoadField: r1 = r0->field_17
    //     0x67efbc: ldur            w1, [x0, #0x17]
    // 0x67efc0: DecompressPointer r1
    //     0x67efc0: add             x1, x1, HEAP, lsl #32
    // 0x67efc4: cmp             w1, NULL
    // 0x67efc8: b.eq            #0x67f278
    // 0x67efcc: ldur            x0, [fp, #-0x20]
    // 0x67efd0: cmp             w1, w0
    // 0x67efd4: b.eq            #0x67f088
    // 0x67efd8: and             w16, w1, w0
    // 0x67efdc: branchIfSmi(r16, 0x67f010)
    //     0x67efdc: tbz             w16, #0, #0x67f010
    // 0x67efe0: r16 = LoadClassIdInstr(r1)
    //     0x67efe0: ldur            x16, [x1, #-1]
    //     0x67efe4: ubfx            x16, x16, #0xc, #0x14
    // 0x67efe8: cmp             x16, #0x3c
    // 0x67efec: b.ne            #0x67f010
    // 0x67eff0: r16 = LoadClassIdInstr(r0)
    //     0x67eff0: ldur            x16, [x0, #-1]
    //     0x67eff4: ubfx            x16, x16, #0xc, #0x14
    // 0x67eff8: cmp             x16, #0x3c
    // 0x67effc: b.ne            #0x67f010
    // 0x67f000: LoadField: r16 = r1->field_7
    //     0x67f000: ldur            x16, [x1, #7]
    // 0x67f004: LoadField: r17 = r0->field_7
    //     0x67f004: ldur            x17, [x0, #7]
    // 0x67f008: cmp             x16, x17
    // 0x67f00c: b.eq            #0x67f088
    // 0x67f010: ldur            x0, [fp, #-8]
    // 0x67f014: LoadField: r1 = r0->field_13
    //     0x67f014: ldur            w1, [x0, #0x13]
    // 0x67f018: DecompressPointer r1
    //     0x67f018: add             x1, x1, HEAP, lsl #32
    // 0x67f01c: LoadField: r2 = r0->field_17
    //     0x67f01c: ldur            w2, [x0, #0x17]
    // 0x67f020: DecompressPointer r2
    //     0x67f020: add             x2, x2, HEAP, lsl #32
    // 0x67f024: ldur            x16, [fp, #-0x18]
    // 0x67f028: stp             x1, x16, [SP, #-0x10]!
    // 0x67f02c: r16 = true
    //     0x67f02c: add             x16, NULL, #0x20  ; true
    // 0x67f030: stp             x16, x2, [SP, #-0x10]!
    // 0x67f034: r4 = const [0, 0x4, 0x4, 0x3, parentUsesSize, 0x3, null]
    //     0x67f034: add             x4, PP, #0x43, lsl #12  ; [pp+0x43178] List(7) [0, 0x4, 0x4, 0x3, "parentUsesSize", 0x3, Null]
    //     0x67f038: ldr             x4, [x4, #0x178]
    // 0x67f03c: r0 = insertAndLayoutChild()
    //     0x67f03c: bl              #0x677f44  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::insertAndLayoutChild
    // 0x67f040: add             SP, SP, #0x20
    // 0x67f044: mov             x2, x0
    // 0x67f048: ldur            x1, [fp, #-8]
    // 0x67f04c: StoreField: r1->field_1f = r0
    //     0x67f04c: stur            w0, [x1, #0x1f]
    //     0x67f050: ldurb           w16, [x1, #-1]
    //     0x67f054: ldurb           w17, [x0, #-1]
    //     0x67f058: and             x16, x17, x16, lsr #2
    //     0x67f05c: tst             x16, HEAP, lsr #32
    //     0x67f060: b.eq            #0x67f068
    //     0x67f064: bl              #0xd6826c
    // 0x67f068: cmp             w2, NULL
    // 0x67f06c: b.ne            #0x67f080
    // 0x67f070: r0 = false
    //     0x67f070: add             x0, NULL, #0x30  ; false
    // 0x67f074: LeaveFrame
    //     0x67f074: mov             SP, fp
    //     0x67f078: ldp             fp, lr, [SP], #0x10
    // 0x67f07c: ret
    //     0x67f07c: ret             
    // 0x67f080: mov             x3, x1
    // 0x67f084: b               #0x67f0d0
    // 0x67f088: ldur            x1, [fp, #-8]
    // 0x67f08c: ldur            x0, [fp, #-0x28]
    // 0x67f090: LoadField: r2 = r1->field_13
    //     0x67f090: ldur            w2, [x1, #0x13]
    // 0x67f094: DecompressPointer r2
    //     0x67f094: add             x2, x2, HEAP, lsl #32
    // 0x67f098: r3 = LoadClassIdInstr(r0)
    //     0x67f098: ldur            x3, [x0, #-1]
    //     0x67f09c: ubfx            x3, x3, #0xc, #0x14
    // 0x67f0a0: stp             x2, x0, [SP, #-0x10]!
    // 0x67f0a4: r16 = true
    //     0x67f0a4: add             x16, NULL, #0x20  ; true
    // 0x67f0a8: SaveReg r16
    //     0x67f0a8: str             x16, [SP, #-8]!
    // 0x67f0ac: mov             x0, x3
    // 0x67f0b0: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x67f0b0: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x67f0b4: ldr             x4, [x4, #0x1c8]
    // 0x67f0b8: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x67f0b8: mov             x17, #0xcdfb
    //     0x67f0bc: add             lr, x0, x17
    //     0x67f0c0: ldr             lr, [x21, lr, lsl #3]
    //     0x67f0c4: blr             lr
    // 0x67f0c8: add             SP, SP, #0x18
    // 0x67f0cc: ldur            x3, [fp, #-8]
    // 0x67f0d0: LoadField: r1 = r3->field_1f
    //     0x67f0d0: ldur            w1, [x3, #0x1f]
    // 0x67f0d4: DecompressPointer r1
    //     0x67f0d4: add             x1, x1, HEAP, lsl #32
    // 0x67f0d8: mov             x0, x1
    // 0x67f0dc: StoreField: r3->field_17 = r0
    //     0x67f0dc: stur            w0, [x3, #0x17]
    //     0x67f0e0: ldurb           w16, [x3, #-1]
    //     0x67f0e4: ldurb           w17, [x0, #-1]
    //     0x67f0e8: and             x16, x17, x16, lsr #2
    //     0x67f0ec: tst             x16, HEAP, lsr #32
    //     0x67f0f0: b.eq            #0x67f0f8
    //     0x67f0f4: bl              #0xd682ac
    // 0x67f0f8: mov             x4, x1
    // 0x67f0fc: b               #0x67f10c
    // 0x67f100: ldur            x3, [fp, #-8]
    // 0x67f104: ldur            x0, [fp, #-0x28]
    // 0x67f108: mov             x4, x0
    // 0x67f10c: stur            x4, [fp, #-0x18]
    // 0x67f110: cmp             w4, NULL
    // 0x67f114: b.eq            #0x67f27c
    // 0x67f118: LoadField: r5 = r4->field_17
    //     0x67f118: ldur            w5, [x4, #0x17]
    // 0x67f11c: DecompressPointer r5
    //     0x67f11c: add             x5, x5, HEAP, lsl #32
    // 0x67f120: stur            x5, [fp, #-0x10]
    // 0x67f124: cmp             w5, NULL
    // 0x67f128: b.eq            #0x67f280
    // 0x67f12c: mov             x0, x5
    // 0x67f130: r2 = Null
    //     0x67f130: mov             x2, NULL
    // 0x67f134: r1 = Null
    //     0x67f134: mov             x1, NULL
    // 0x67f138: r4 = LoadClassIdInstr(r0)
    //     0x67f138: ldur            x4, [x0, #-1]
    //     0x67f13c: ubfx            x4, x4, #0xc, #0x14
    // 0x67f140: sub             x4, x4, #0x7f9
    // 0x67f144: cmp             x4, #2
    // 0x67f148: b.ls            #0x67f160
    // 0x67f14c: r8 = SliverMultiBoxAdaptorParentData
    //     0x67f14c: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67f150: ldr             x8, [x8, #0x120]
    // 0x67f154: r3 = Null
    //     0x67f154: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b0c0] Null
    //     0x67f158: ldr             x3, [x3, #0xc0]
    // 0x67f15c: r0 = DefaultTypeTest()
    //     0x67f15c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67f160: ldur            x3, [fp, #-8]
    // 0x67f164: LoadField: r4 = r3->field_27
    //     0x67f164: ldur            w4, [x3, #0x27]
    // 0x67f168: DecompressPointer r4
    //     0x67f168: add             x4, x4, HEAP, lsl #32
    // 0x67f16c: mov             x0, x4
    // 0x67f170: ldur            x1, [fp, #-0x10]
    // 0x67f174: stur            x4, [fp, #-0x20]
    // 0x67f178: StoreField: r1->field_7 = r0
    //     0x67f178: stur            w0, [x1, #7]
    //     0x67f17c: ldurb           w16, [x1, #-1]
    //     0x67f180: ldurb           w17, [x0, #-1]
    //     0x67f184: and             x16, x17, x16, lsr #2
    //     0x67f188: tst             x16, HEAP, lsr #32
    //     0x67f18c: b.eq            #0x67f194
    //     0x67f190: bl              #0xd6826c
    // 0x67f194: LoadField: r5 = r3->field_f
    //     0x67f194: ldur            w5, [x3, #0xf]
    // 0x67f198: DecompressPointer r5
    //     0x67f198: add             x5, x5, HEAP, lsl #32
    // 0x67f19c: ldur            x0, [fp, #-0x18]
    // 0x67f1a0: stur            x5, [fp, #-0x10]
    // 0x67f1a4: r2 = Null
    //     0x67f1a4: mov             x2, NULL
    // 0x67f1a8: r1 = Null
    //     0x67f1a8: mov             x1, NULL
    // 0x67f1ac: r4 = LoadClassIdInstr(r0)
    //     0x67f1ac: ldur            x4, [x0, #-1]
    //     0x67f1b0: ubfx            x4, x4, #0xc, #0x14
    // 0x67f1b4: sub             x4, x4, #0x961
    // 0x67f1b8: cmp             x4, #0xbe
    // 0x67f1bc: b.ls            #0x67f1d0
    // 0x67f1c0: r8 = RenderObject
    //     0x67f1c0: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x67f1c4: r3 = Null
    //     0x67f1c4: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b0d0] Null
    //     0x67f1c8: ldr             x3, [x3, #0xd0]
    // 0x67f1cc: r0 = RenderObject()
    //     0x67f1cc: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x67f1d0: ldur            x0, [fp, #-0x20]
    // 0x67f1d4: cmp             w0, NULL
    // 0x67f1d8: b.eq            #0x67f284
    // 0x67f1dc: ldur            x16, [fp, #-0x10]
    // 0x67f1e0: ldur            lr, [fp, #-0x18]
    // 0x67f1e4: stp             lr, x16, [SP, #-0x10]!
    // 0x67f1e8: r0 = paintExtentOf()
    //     0x67f1e8: bl              #0x653e78  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::paintExtentOf
    // 0x67f1ec: add             SP, SP, #0x10
    // 0x67f1f0: cmp             w0, NULL
    // 0x67f1f4: b.eq            #0x67f288
    // 0x67f1f8: ldur            x1, [fp, #-0x20]
    // 0x67f1fc: LoadField: d0 = r1->field_7
    //     0x67f1fc: ldur            d0, [x1, #7]
    // 0x67f200: LoadField: d1 = r0->field_7
    //     0x67f200: ldur            d1, [x0, #7]
    // 0x67f204: fadd            d2, d0, d1
    // 0x67f208: r0 = inline_Allocate_Double()
    //     0x67f208: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x67f20c: add             x0, x0, #0x10
    //     0x67f210: cmp             x1, x0
    //     0x67f214: b.ls            #0x67f28c
    //     0x67f218: str             x0, [THR, #0x60]  ; THR::top
    //     0x67f21c: sub             x0, x0, #0xf
    //     0x67f220: mov             x1, #0xd108
    //     0x67f224: movk            x1, #3, lsl #16
    //     0x67f228: stur            x1, [x0, #-1]
    // 0x67f22c: StoreField: r0->field_7 = d2
    //     0x67f22c: stur            d2, [x0, #7]
    // 0x67f230: ldur            x1, [fp, #-8]
    // 0x67f234: StoreField: r1->field_27 = r0
    //     0x67f234: stur            w0, [x1, #0x27]
    //     0x67f238: ldurb           w16, [x1, #-1]
    //     0x67f23c: ldurb           w17, [x0, #-1]
    //     0x67f240: and             x16, x17, x16, lsr #2
    //     0x67f244: tst             x16, HEAP, lsr #32
    //     0x67f248: b.eq            #0x67f250
    //     0x67f24c: bl              #0xd6826c
    // 0x67f250: r0 = true
    //     0x67f250: add             x0, NULL, #0x20  ; true
    // 0x67f254: LeaveFrame
    //     0x67f254: mov             SP, fp
    //     0x67f258: ldp             fp, lr, [SP], #0x10
    // 0x67f25c: ret
    //     0x67f25c: ret             
    // 0x67f260: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x67f260: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x67f264: b               #0x67ede8
    // 0x67f268: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67f268: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67f26c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67f26c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67f270: r0 = NullErrorSharedWithoutFPURegs()
    //     0x67f270: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x67f274: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67f274: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67f278: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67f278: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67f27c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67f27c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67f280: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67f280: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67f284: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67f284: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67f288: r0 = NullErrorSharedWithoutFPURegs()
    //     0x67f288: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x67f28c: SaveReg d2
    //     0x67f28c: str             q2, [SP, #-0x10]!
    // 0x67f290: r0 = AllocateDouble()
    //     0x67f290: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67f294: RestoreReg d2
    //     0x67f294: ldr             q2, [SP], #0x10
    // 0x67f298: b               #0x67f22c
  }
  _ RenderSliverList(/* No info */) {
    // ** addr: 0x6e9abc, size: 0x40
    // 0x6e9abc: EnterFrame
    //     0x6e9abc: stp             fp, lr, [SP, #-0x10]!
    //     0x6e9ac0: mov             fp, SP
    // 0x6e9ac4: CheckStackOverflow
    //     0x6e9ac4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e9ac8: cmp             SP, x16
    //     0x6e9acc: b.ls            #0x6e9af4
    // 0x6e9ad0: ldr             x16, [fp, #0x18]
    // 0x6e9ad4: ldr             lr, [fp, #0x10]
    // 0x6e9ad8: stp             lr, x16, [SP, #-0x10]!
    // 0x6e9adc: r0 = RenderSliverMultiBoxAdaptor()
    //     0x6e9adc: bl              #0x6e9998  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::RenderSliverMultiBoxAdaptor
    // 0x6e9ae0: add             SP, SP, #0x10
    // 0x6e9ae4: r0 = Null
    //     0x6e9ae4: mov             x0, NULL
    // 0x6e9ae8: LeaveFrame
    //     0x6e9ae8: mov             SP, fp
    //     0x6e9aec: ldp             fp, lr, [SP], #0x10
    // 0x6e9af0: ret
    //     0x6e9af0: ret             
    // 0x6e9af4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e9af4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e9af8: b               #0x6e9ad0
  }
}

// lib: , url: package:flutter/src/rendering/sliver_fixed_extent_list.dart

// class id: 1049422, size: 0x8
class :: {
}

// class id: 2587, size: 0x6c, field offset: 0x6c
abstract class RenderSliverFixedExtentBoxAdaptor extends RenderSliverMultiBoxAdaptor {

  _ estimateMaxScrollOffset(/* No info */) {
    // ** addr: 0x677c8c, size: 0x60
    // 0x677c8c: EnterFrame
    //     0x677c8c: stp             fp, lr, [SP, #-0x10]!
    //     0x677c90: mov             fp, SP
    // 0x677c94: CheckStackOverflow
    //     0x677c94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x677c98: cmp             SP, x16
    //     0x677c9c: b.ls            #0x677ce4
    // 0x677ca0: ldr             x0, [fp, #0x38]
    // 0x677ca4: LoadField: r1 = r0->field_63
    //     0x677ca4: ldur            w1, [x0, #0x63]
    // 0x677ca8: DecompressPointer r1
    //     0x677ca8: add             x1, x1, HEAP, lsl #32
    // 0x677cac: ldr             x16, [fp, #0x30]
    // 0x677cb0: stp             x16, x1, [SP, #-0x10]!
    // 0x677cb4: ldr             x16, [fp, #0x28]
    // 0x677cb8: ldr             lr, [fp, #0x20]
    // 0x677cbc: stp             lr, x16, [SP, #-0x10]!
    // 0x677cc0: ldr             x16, [fp, #0x18]
    // 0x677cc4: SaveReg r16
    //     0x677cc4: str             x16, [SP, #-8]!
    // 0x677cc8: ldr             d0, [fp, #0x10]
    // 0x677ccc: SaveReg d0
    //     0x677ccc: str             d0, [SP, #-8]!
    // 0x677cd0: r0 = estimateMaxScrollOffset()
    //     0x677cd0: bl              #0x677cec  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::estimateMaxScrollOffset
    // 0x677cd4: add             SP, SP, #0x30
    // 0x677cd8: LeaveFrame
    //     0x677cd8: mov             SP, fp
    //     0x677cdc: ldp             fp, lr, [SP], #0x10
    // 0x677ce0: ret
    //     0x677ce0: ret             
    // 0x677ce4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x677ce4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x677ce8: b               #0x677ca0
  }
  _ computeMaxScrollOffset(/* No info */) {
    // ** addr: 0x679340, size: 0x4c
    // 0x679340: EnterFrame
    //     0x679340: stp             fp, lr, [SP, #-0x10]!
    //     0x679344: mov             fp, SP
    // 0x679348: CheckStackOverflow
    //     0x679348: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67934c: cmp             SP, x16
    //     0x679350: b.ls            #0x679384
    // 0x679354: ldr             x0, [fp, #0x18]
    // 0x679358: LoadField: r1 = r0->field_63
    //     0x679358: ldur            w1, [x0, #0x63]
    // 0x67935c: DecompressPointer r1
    //     0x67935c: add             x1, x1, HEAP, lsl #32
    // 0x679360: SaveReg r1
    //     0x679360: str             x1, [SP, #-8]!
    // 0x679364: r0 = childCount()
    //     0x679364: bl              #0x67938c  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::childCount
    // 0x679368: add             SP, SP, #8
    // 0x67936c: scvtf           d1, x0
    // 0x679370: ldr             d2, [fp, #0x10]
    // 0x679374: fmul            d0, d1, d2
    // 0x679378: LeaveFrame
    //     0x679378: mov             SP, fp
    //     0x67937c: ldp             fp, lr, [SP], #0x10
    // 0x679380: ret
    //     0x679380: ret             
    // 0x679384: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x679384: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x679388: b               #0x679354
  }
  _ getMaxChildIndexForScrollOffset(/* No info */) {
    // ** addr: 0x67a178, size: 0x230
    // 0x67a178: EnterFrame
    //     0x67a178: stp             fp, lr, [SP, #-0x10]!
    //     0x67a17c: mov             fp, SP
    // 0x67a180: AllocStack(0x8)
    //     0x67a180: sub             SP, SP, #8
    // 0x67a184: d1 = 0.000000
    //     0x67a184: eor             v1.16b, v1.16b, v1.16b
    // 0x67a188: ldr             d2, [fp, #0x10]
    // 0x67a18c: fcmp            d2, d1
    // 0x67a190: b.vs            #0x67a354
    // 0x67a194: b.le            #0x67a354
    // 0x67a198: ldr             x0, [fp, #0x18]
    // 0x67a19c: d0 = 1.000000
    //     0x67a19c: fmov            d0, #1.00000000
    // 0x67a1a0: LoadField: d3 = r0->field_7
    //     0x67a1a0: ldur            d3, [x0, #7]
    // 0x67a1a4: fdiv            d4, d3, d2
    // 0x67a1a8: fsub            d3, d4, d0
    // 0x67a1ac: mov             v0.16b, v3.16b
    // 0x67a1b0: stur            d3, [fp, #-8]
    // 0x67a1b4: stp             fp, lr, [SP, #-0x10]!
    // 0x67a1b8: mov             fp, SP
    // 0x67a1bc: CallRuntime_LibcRound(double) -> double
    //     0x67a1bc: and             SP, SP, #0xfffffffffffffff0
    //     0x67a1c0: mov             sp, SP
    //     0x67a1c4: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0x67a1c8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x67a1cc: blr             x16
    //     0x67a1d0: mov             x16, #8
    //     0x67a1d4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x67a1d8: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x67a1dc: sub             sp, x16, #1, lsl #12
    //     0x67a1e0: mov             SP, fp
    //     0x67a1e4: ldp             fp, lr, [SP], #0x10
    // 0x67a1e8: fcmp            d0, d0
    // 0x67a1ec: b.vs            #0x67a364
    // 0x67a1f0: fcvtzs          x1, d0
    // 0x67a1f4: asr             x16, x1, #0x1e
    // 0x67a1f8: cmp             x16, x1, asr #63
    // 0x67a1fc: b.ne            #0x67a364
    // 0x67a200: lsl             x1, x1, #1
    // 0x67a204: ldr             d0, [fp, #0x10]
    // 0x67a208: ldur            d1, [fp, #-8]
    // 0x67a20c: fmul            d2, d1, d0
    // 0x67a210: r2 = LoadInt32Instr(r1)
    //     0x67a210: sbfx            x2, x1, #1, #0x1f
    //     0x67a214: tbz             w1, #0, #0x67a21c
    //     0x67a218: ldur            x2, [x1, #7]
    // 0x67a21c: scvtf           d3, x2
    // 0x67a220: fmul            d4, d3, d0
    // 0x67a224: fsub            d0, d2, d4
    // 0x67a228: d2 = 0.000000
    //     0x67a228: eor             v2.16b, v2.16b, v2.16b
    // 0x67a22c: fcmp            d0, d2
    // 0x67a230: b.vs            #0x67a240
    // 0x67a234: b.ne            #0x67a240
    // 0x67a238: d2 = 0.000000
    //     0x67a238: eor             v2.16b, v2.16b, v2.16b
    // 0x67a23c: b               #0x67a258
    // 0x67a240: fcmp            d0, d2
    // 0x67a244: b.vs            #0x67a254
    // 0x67a248: b.ge            #0x67a254
    // 0x67a24c: fneg            d2, d0
    // 0x67a250: mov             v0.16b, v2.16b
    // 0x67a254: mov             v2.16b, v0.16b
    // 0x67a258: d0 = 0.000000
    //     0x67a258: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1e0] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    //     0x67a25c: ldr             d0, [x17, #0x1e0]
    // 0x67a260: fcmp            d2, d0
    // 0x67a264: b.vs            #0x67a2cc
    // 0x67a268: b.ge            #0x67a2cc
    // 0x67a26c: tbz             x2, #0x3f, #0x67a278
    // 0x67a270: r1 = 0
    //     0x67a270: mov             x1, #0
    // 0x67a274: b               #0x67a2b4
    // 0x67a278: cmp             x2, #0
    // 0x67a27c: b.gt            #0x67a2b4
    // 0x67a280: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0x67a280: mov             x2, #0x76
    //     0x67a284: tbz             w1, #0, #0x67a294
    //     0x67a288: ldur            x2, [x1, #-1]
    //     0x67a28c: ubfx            x2, x2, #0xc, #0x14
    //     0x67a290: lsl             x2, x2, #1
    // 0x67a294: cmp             w2, #0x7a
    // 0x67a298: b.ne            #0x67a2b0
    // 0x67a29c: LoadField: d0 = r1->field_7
    //     0x67a29c: ldur            d0, [x1, #7]
    // 0x67a2a0: fcmp            d0, d0
    // 0x67a2a4: b.vs            #0x67a2b4
    // 0x67a2a8: r1 = 0
    //     0x67a2a8: mov             x1, #0
    // 0x67a2ac: b               #0x67a2b4
    // 0x67a2b0: r1 = 0
    //     0x67a2b0: mov             x1, #0
    // 0x67a2b4: r0 = LoadInt32Instr(r1)
    //     0x67a2b4: sbfx            x0, x1, #1, #0x1f
    //     0x67a2b8: tbz             w1, #0, #0x67a2c0
    //     0x67a2bc: ldur            x0, [x1, #7]
    // 0x67a2c0: LeaveFrame
    //     0x67a2c0: mov             SP, fp
    //     0x67a2c4: ldp             fp, lr, [SP], #0x10
    // 0x67a2c8: ret
    //     0x67a2c8: ret             
    // 0x67a2cc: fcmp            d1, d1
    // 0x67a2d0: b.vs            #0x67a384
    // 0x67a2d4: fcvtps          x1, d1
    // 0x67a2d8: asr             x16, x1, #0x1e
    // 0x67a2dc: cmp             x16, x1, asr #63
    // 0x67a2e0: b.ne            #0x67a384
    // 0x67a2e4: lsl             x1, x1, #1
    // 0x67a2e8: r2 = LoadInt32Instr(r1)
    //     0x67a2e8: sbfx            x2, x1, #1, #0x1f
    //     0x67a2ec: tbz             w1, #0, #0x67a2f4
    //     0x67a2f0: ldur            x2, [x1, #7]
    // 0x67a2f4: tbz             x2, #0x3f, #0x67a300
    // 0x67a2f8: r1 = 0
    //     0x67a2f8: mov             x1, #0
    // 0x67a2fc: b               #0x67a33c
    // 0x67a300: cmp             x2, #0
    // 0x67a304: b.gt            #0x67a33c
    // 0x67a308: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0x67a308: mov             x2, #0x76
    //     0x67a30c: tbz             w1, #0, #0x67a31c
    //     0x67a310: ldur            x2, [x1, #-1]
    //     0x67a314: ubfx            x2, x2, #0xc, #0x14
    //     0x67a318: lsl             x2, x2, #1
    // 0x67a31c: cmp             w2, #0x7a
    // 0x67a320: b.ne            #0x67a338
    // 0x67a324: LoadField: d0 = r1->field_7
    //     0x67a324: ldur            d0, [x1, #7]
    // 0x67a328: fcmp            d0, d0
    // 0x67a32c: b.vs            #0x67a33c
    // 0x67a330: r1 = 0
    //     0x67a330: mov             x1, #0
    // 0x67a334: b               #0x67a33c
    // 0x67a338: r1 = 0
    //     0x67a338: mov             x1, #0
    // 0x67a33c: r0 = LoadInt32Instr(r1)
    //     0x67a33c: sbfx            x0, x1, #1, #0x1f
    //     0x67a340: tbz             w1, #0, #0x67a348
    //     0x67a344: ldur            x0, [x1, #7]
    // 0x67a348: LeaveFrame
    //     0x67a348: mov             SP, fp
    //     0x67a34c: ldp             fp, lr, [SP], #0x10
    // 0x67a350: ret
    //     0x67a350: ret             
    // 0x67a354: r0 = 0
    //     0x67a354: mov             x0, #0
    // 0x67a358: LeaveFrame
    //     0x67a358: mov             SP, fp
    //     0x67a35c: ldp             fp, lr, [SP], #0x10
    // 0x67a360: ret
    //     0x67a360: ret             
    // 0x67a364: SaveReg d0
    //     0x67a364: str             q0, [SP, #-0x10]!
    // 0x67a368: r0 = 218
    //     0x67a368: mov             x0, #0xda
    // 0x67a36c: r24 = DoubleToIntegerStub
    //     0x67a36c: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x67a370: LoadField: r30 = r24->field_7
    //     0x67a370: ldur            lr, [x24, #7]
    // 0x67a374: blr             lr
    // 0x67a378: mov             x1, x0
    // 0x67a37c: RestoreReg d0
    //     0x67a37c: ldr             q0, [SP], #0x10
    // 0x67a380: b               #0x67a204
    // 0x67a384: SaveReg d1
    //     0x67a384: str             q1, [SP, #-0x10]!
    // 0x67a388: d0 = 0.000000
    //     0x67a388: fmov            d0, d1
    // 0x67a38c: r0 = 208
    //     0x67a38c: mov             x0, #0xd0
    // 0x67a390: r24 = DoubleToIntegerStub
    //     0x67a390: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x67a394: LoadField: r30 = r24->field_7
    //     0x67a394: ldur            lr, [x24, #7]
    // 0x67a398: blr             lr
    // 0x67a39c: mov             x1, x0
    // 0x67a3a0: RestoreReg d1
    //     0x67a3a0: ldr             q1, [SP], #0x10
    // 0x67a3a4: b               #0x67a2e8
  }
  _ getMinChildIndexForScrollOffset(/* No info */) {
    // ** addr: 0x67a3a8, size: 0x180
    // 0x67a3a8: EnterFrame
    //     0x67a3a8: stp             fp, lr, [SP, #-0x10]!
    //     0x67a3ac: mov             fp, SP
    // 0x67a3b0: AllocStack(0x8)
    //     0x67a3b0: sub             SP, SP, #8
    // 0x67a3b4: d1 = 0.000000
    //     0x67a3b4: eor             v1.16b, v1.16b, v1.16b
    // 0x67a3b8: ldr             d2, [fp, #0x10]
    // 0x67a3bc: fcmp            d2, d1
    // 0x67a3c0: b.vs            #0x67a4d4
    // 0x67a3c4: b.le            #0x67a4d4
    // 0x67a3c8: ldr             x0, [fp, #0x18]
    // 0x67a3cc: LoadField: d0 = r0->field_7
    //     0x67a3cc: ldur            d0, [x0, #7]
    // 0x67a3d0: fdiv            d3, d0, d2
    // 0x67a3d4: mov             v0.16b, v3.16b
    // 0x67a3d8: stur            d3, [fp, #-8]
    // 0x67a3dc: stp             fp, lr, [SP, #-0x10]!
    // 0x67a3e0: mov             fp, SP
    // 0x67a3e4: CallRuntime_LibcRound(double) -> double
    //     0x67a3e4: and             SP, SP, #0xfffffffffffffff0
    //     0x67a3e8: mov             sp, SP
    //     0x67a3ec: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0x67a3f0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x67a3f4: blr             x16
    //     0x67a3f8: mov             x16, #8
    //     0x67a3fc: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x67a400: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x67a404: sub             sp, x16, #1, lsl #12
    //     0x67a408: mov             SP, fp
    //     0x67a40c: ldp             fp, lr, [SP], #0x10
    // 0x67a410: fcmp            d0, d0
    // 0x67a414: b.vs            #0x67a4e4
    // 0x67a418: fcvtzs          x1, d0
    // 0x67a41c: asr             x16, x1, #0x1e
    // 0x67a420: cmp             x16, x1, asr #63
    // 0x67a424: b.ne            #0x67a4e4
    // 0x67a428: lsl             x1, x1, #1
    // 0x67a42c: ldr             d0, [fp, #0x10]
    // 0x67a430: ldur            d1, [fp, #-8]
    // 0x67a434: fmul            d2, d1, d0
    // 0x67a438: r0 = LoadInt32Instr(r1)
    //     0x67a438: sbfx            x0, x1, #1, #0x1f
    //     0x67a43c: tbz             w1, #0, #0x67a444
    //     0x67a440: ldur            x0, [x1, #7]
    // 0x67a444: scvtf           d3, x0
    // 0x67a448: fmul            d4, d3, d0
    // 0x67a44c: fsub            d0, d2, d4
    // 0x67a450: d2 = 0.000000
    //     0x67a450: eor             v2.16b, v2.16b, v2.16b
    // 0x67a454: fcmp            d0, d2
    // 0x67a458: b.vs            #0x67a468
    // 0x67a45c: b.ne            #0x67a468
    // 0x67a460: d2 = 0.000000
    //     0x67a460: eor             v2.16b, v2.16b, v2.16b
    // 0x67a464: b               #0x67a480
    // 0x67a468: fcmp            d0, d2
    // 0x67a46c: b.vs            #0x67a47c
    // 0x67a470: b.ge            #0x67a47c
    // 0x67a474: fneg            d2, d0
    // 0x67a478: mov             v0.16b, v2.16b
    // 0x67a47c: mov             v2.16b, v0.16b
    // 0x67a480: d0 = 0.000000
    //     0x67a480: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1e0] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    //     0x67a484: ldr             d0, [x17, #0x1e0]
    // 0x67a488: fcmp            d2, d0
    // 0x67a48c: b.vs            #0x67a4a0
    // 0x67a490: b.ge            #0x67a4a0
    // 0x67a494: LeaveFrame
    //     0x67a494: mov             SP, fp
    //     0x67a498: ldp             fp, lr, [SP], #0x10
    // 0x67a49c: ret
    //     0x67a49c: ret             
    // 0x67a4a0: fcmp            d1, d1
    // 0x67a4a4: b.vs            #0x67a504
    // 0x67a4a8: fcvtms          x1, d1
    // 0x67a4ac: asr             x16, x1, #0x1e
    // 0x67a4b0: cmp             x16, x1, asr #63
    // 0x67a4b4: b.ne            #0x67a504
    // 0x67a4b8: lsl             x1, x1, #1
    // 0x67a4bc: r0 = LoadInt32Instr(r1)
    //     0x67a4bc: sbfx            x0, x1, #1, #0x1f
    //     0x67a4c0: tbz             w1, #0, #0x67a4c8
    //     0x67a4c4: ldur            x0, [x1, #7]
    // 0x67a4c8: LeaveFrame
    //     0x67a4c8: mov             SP, fp
    //     0x67a4cc: ldp             fp, lr, [SP], #0x10
    // 0x67a4d0: ret
    //     0x67a4d0: ret             
    // 0x67a4d4: r0 = 0
    //     0x67a4d4: mov             x0, #0
    // 0x67a4d8: LeaveFrame
    //     0x67a4d8: mov             SP, fp
    //     0x67a4dc: ldp             fp, lr, [SP], #0x10
    // 0x67a4e0: ret
    //     0x67a4e0: ret             
    // 0x67a4e4: SaveReg d0
    //     0x67a4e4: str             q0, [SP, #-0x10]!
    // 0x67a4e8: r0 = 218
    //     0x67a4e8: mov             x0, #0xda
    // 0x67a4ec: r24 = DoubleToIntegerStub
    //     0x67a4ec: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x67a4f0: LoadField: r30 = r24->field_7
    //     0x67a4f0: ldur            lr, [x24, #7]
    // 0x67a4f4: blr             lr
    // 0x67a4f8: mov             x1, x0
    // 0x67a4fc: RestoreReg d0
    //     0x67a4fc: ldr             q0, [SP], #0x10
    // 0x67a500: b               #0x67a42c
    // 0x67a504: SaveReg d1
    //     0x67a504: str             q1, [SP, #-0x10]!
    // 0x67a508: d0 = 0.000000
    //     0x67a508: fmov            d0, d1
    // 0x67a50c: r0 = 212
    //     0x67a50c: mov             x0, #0xd4
    // 0x67a510: r24 = DoubleToIntegerStub
    //     0x67a510: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x67a514: LoadField: r30 = r24->field_7
    //     0x67a514: ldur            lr, [x24, #7]
    // 0x67a518: blr             lr
    // 0x67a51c: mov             x1, x0
    // 0x67a520: RestoreReg d1
    //     0x67a520: ldr             q1, [SP], #0x10
    // 0x67a524: b               #0x67a4bc
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x67a6f4, size: 0x1154
    // 0x67a6f4: EnterFrame
    //     0x67a6f4: stp             fp, lr, [SP, #-0x10]!
    //     0x67a6f8: mov             fp, SP
    // 0x67a6fc: AllocStack(0x78)
    //     0x67a6fc: sub             SP, SP, #0x78
    // 0x67a700: CheckStackOverflow
    //     0x67a700: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67a704: cmp             SP, x16
    //     0x67a708: b.ls            #0x67b650
    // 0x67a70c: ldr             x3, [fp, #0x10]
    // 0x67a710: LoadField: r4 = r3->field_27
    //     0x67a710: ldur            w4, [x3, #0x27]
    // 0x67a714: DecompressPointer r4
    //     0x67a714: add             x4, x4, HEAP, lsl #32
    // 0x67a718: stur            x4, [fp, #-8]
    // 0x67a71c: cmp             w4, NULL
    // 0x67a720: b.eq            #0x67b630
    // 0x67a724: mov             x0, x4
    // 0x67a728: r2 = Null
    //     0x67a728: mov             x2, NULL
    // 0x67a72c: r1 = Null
    //     0x67a72c: mov             x1, NULL
    // 0x67a730: r4 = LoadClassIdInstr(r0)
    //     0x67a730: ldur            x4, [x0, #-1]
    //     0x67a734: ubfx            x4, x4, #0xc, #0x14
    // 0x67a738: cmp             x4, #0x80c
    // 0x67a73c: b.eq            #0x67a754
    // 0x67a740: r8 = SliverConstraints
    //     0x67a740: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x67a744: ldr             x8, [x8, #0x5a8]
    // 0x67a748: r3 = Null
    //     0x67a748: add             x3, PP, #0x55, lsl #12  ; [pp+0x55bb8] Null
    //     0x67a74c: ldr             x3, [x3, #0xbb8]
    // 0x67a750: r0 = DefaultTypeTest()
    //     0x67a750: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67a754: ldr             x0, [fp, #0x10]
    // 0x67a758: LoadField: r1 = r0->field_63
    //     0x67a758: ldur            w1, [x0, #0x63]
    // 0x67a75c: DecompressPointer r1
    //     0x67a75c: add             x1, x1, HEAP, lsl #32
    // 0x67a760: stur            x1, [fp, #-0x10]
    // 0x67a764: r2 = false
    //     0x67a764: add             x2, NULL, #0x30  ; false
    // 0x67a768: StoreField: r1->field_53 = r2
    //     0x67a768: stur            w2, [x1, #0x53]
    // 0x67a76c: r3 = LoadClassIdInstr(r0)
    //     0x67a76c: ldur            x3, [x0, #-1]
    //     0x67a770: ubfx            x3, x3, #0xc, #0x14
    // 0x67a774: lsl             x3, x3, #1
    // 0x67a778: r17 = 5176
    //     0x67a778: mov             x17, #0x1438
    // 0x67a77c: cmp             w3, w17
    // 0x67a780: b.ne            #0x67a82c
    // 0x67a784: ldur            x16, [fp, #-8]
    // 0x67a788: SaveReg r16
    //     0x67a788: str             x16, [SP, #-8]!
    // 0x67a78c: r0 = axis()
    //     0x67a78c: bl              #0x643150  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0x67a790: add             SP, SP, #8
    // 0x67a794: r16 = Instance_Axis
    //     0x67a794: add             x16, PP, #0xe, lsl #12  ; [pp+0xef00] Obj!Axis@b64ff1
    //     0x67a798: ldr             x16, [x16, #0xf00]
    // 0x67a79c: cmp             w0, w16
    // 0x67a7a0: b.ne            #0x67a7d0
    // 0x67a7a4: ldr             x0, [fp, #0x10]
    // 0x67a7a8: LoadField: r1 = r0->field_6b
    //     0x67a7a8: ldur            w1, [x0, #0x6b]
    // 0x67a7ac: DecompressPointer r1
    //     0x67a7ac: add             x1, x1, HEAP, lsl #32
    // 0x67a7b0: cmp             w1, NULL
    // 0x67a7b4: b.eq            #0x67b658
    // 0x67a7b8: LoadField: r2 = r1->field_57
    //     0x67a7b8: ldur            w2, [x1, #0x57]
    // 0x67a7bc: DecompressPointer r2
    //     0x67a7bc: add             x2, x2, HEAP, lsl #32
    // 0x67a7c0: cmp             w2, NULL
    // 0x67a7c4: b.eq            #0x67b65c
    // 0x67a7c8: LoadField: d0 = r2->field_f
    //     0x67a7c8: ldur            d0, [x2, #0xf]
    // 0x67a7cc: b               #0x67a7f8
    // 0x67a7d0: ldr             x0, [fp, #0x10]
    // 0x67a7d4: LoadField: r1 = r0->field_6b
    //     0x67a7d4: ldur            w1, [x0, #0x6b]
    // 0x67a7d8: DecompressPointer r1
    //     0x67a7d8: add             x1, x1, HEAP, lsl #32
    // 0x67a7dc: cmp             w1, NULL
    // 0x67a7e0: b.eq            #0x67b660
    // 0x67a7e4: LoadField: r2 = r1->field_57
    //     0x67a7e4: ldur            w2, [x1, #0x57]
    // 0x67a7e8: DecompressPointer r2
    //     0x67a7e8: add             x2, x2, HEAP, lsl #32
    // 0x67a7ec: cmp             w2, NULL
    // 0x67a7f0: b.eq            #0x67b664
    // 0x67a7f4: LoadField: d0 = r2->field_7
    //     0x67a7f4: ldur            d0, [x2, #7]
    // 0x67a7f8: r1 = inline_Allocate_Double()
    //     0x67a7f8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x67a7fc: add             x1, x1, #0x10
    //     0x67a800: cmp             x2, x1
    //     0x67a804: b.ls            #0x67b668
    //     0x67a808: str             x1, [THR, #0x60]  ; THR::top
    //     0x67a80c: sub             x1, x1, #0xf
    //     0x67a810: mov             x2, #0xd108
    //     0x67a814: movk            x2, #3, lsl #16
    //     0x67a818: stur            x2, [x1, #-1]
    // 0x67a81c: StoreField: r1->field_7 = d0
    //     0x67a81c: stur            d0, [x1, #7]
    // 0x67a820: mov             x2, x1
    // 0x67a824: ldur            x1, [fp, #-8]
    // 0x67a828: b               #0x67a8c4
    // 0x67a82c: r17 = 5178
    //     0x67a82c: mov             x17, #0x143a
    // 0x67a830: cmp             w3, w17
    // 0x67a834: b.ne            #0x67a84c
    // 0x67a838: LoadField: r1 = r0->field_6b
    //     0x67a838: ldur            w1, [x0, #0x6b]
    // 0x67a83c: DecompressPointer r1
    //     0x67a83c: add             x1, x1, HEAP, lsl #32
    // 0x67a840: mov             x2, x1
    // 0x67a844: ldur            x1, [fp, #-8]
    // 0x67a848: b               #0x67a8c4
    // 0x67a84c: r17 = 5180
    //     0x67a84c: mov             x17, #0x143c
    // 0x67a850: cmp             w3, w17
    // 0x67a854: b.ne            #0x67a894
    // 0x67a858: ldur            x1, [fp, #-8]
    // 0x67a85c: LoadField: d0 = r1->field_3f
    //     0x67a85c: ldur            d0, [x1, #0x3f]
    // 0x67a860: LoadField: d1 = r0->field_6b
    //     0x67a860: ldur            d1, [x0, #0x6b]
    // 0x67a864: fmul            d2, d0, d1
    // 0x67a868: r2 = inline_Allocate_Double()
    //     0x67a868: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x67a86c: add             x2, x2, #0x10
    //     0x67a870: cmp             x3, x2
    //     0x67a874: b.ls            #0x67b684
    //     0x67a878: str             x2, [THR, #0x60]  ; THR::top
    //     0x67a87c: sub             x2, x2, #0xf
    //     0x67a880: mov             x3, #0xd108
    //     0x67a884: movk            x3, #3, lsl #16
    //     0x67a888: stur            x3, [x2, #-1]
    // 0x67a88c: StoreField: r2->field_7 = d2
    //     0x67a88c: stur            d2, [x2, #7]
    // 0x67a890: b               #0x67a8c4
    // 0x67a894: ldur            x1, [fp, #-8]
    // 0x67a898: LoadField: d0 = r1->field_3f
    //     0x67a898: ldur            d0, [x1, #0x3f]
    // 0x67a89c: r2 = inline_Allocate_Double()
    //     0x67a89c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x67a8a0: add             x2, x2, #0x10
    //     0x67a8a4: cmp             x3, x2
    //     0x67a8a8: b.ls            #0x67b6a0
    //     0x67a8ac: str             x2, [THR, #0x60]  ; THR::top
    //     0x67a8b0: sub             x2, x2, #0xf
    //     0x67a8b4: mov             x3, #0xd108
    //     0x67a8b8: movk            x3, #3, lsl #16
    //     0x67a8bc: stur            x3, [x2, #-1]
    // 0x67a8c0: StoreField: r2->field_7 = d0
    //     0x67a8c0: stur            d0, [x2, #7]
    // 0x67a8c4: stur            x2, [fp, #-0x18]
    // 0x67a8c8: LoadField: d0 = r1->field_13
    //     0x67a8c8: ldur            d0, [x1, #0x13]
    // 0x67a8cc: stur            d0, [fp, #-0x60]
    // 0x67a8d0: LoadField: d1 = r1->field_47
    //     0x67a8d0: ldur            d1, [x1, #0x47]
    // 0x67a8d4: fadd            d2, d0, d1
    // 0x67a8d8: stur            d2, [fp, #-0x58]
    // 0x67a8dc: LoadField: d1 = r1->field_4f
    //     0x67a8dc: ldur            d1, [x1, #0x4f]
    // 0x67a8e0: fadd            d3, d2, d1
    // 0x67a8e4: stur            d3, [fp, #-0x50]
    // 0x67a8e8: stp             x2, x1, [SP, #-0x10]!
    // 0x67a8ec: SaveReg r2
    //     0x67a8ec: str             x2, [SP, #-8]!
    // 0x67a8f0: r4 = const [0, 0x3, 0x3, 0x1, maxExtent, 0x2, minExtent, 0x1, null]
    //     0x67a8f0: add             x4, PP, #0x40, lsl #12  ; [pp+0x40d60] List(9) [0, 0x3, 0x3, 0x1, "maxExtent", 0x2, "minExtent", 0x1, Null]
    //     0x67a8f4: ldr             x4, [x4, #0xd60]
    // 0x67a8f8: r0 = asBoxConstraints()
    //     0x67a8f8: bl              #0x67a528  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::asBoxConstraints
    // 0x67a8fc: add             SP, SP, #0x18
    // 0x67a900: mov             x1, x0
    // 0x67a904: ldur            x0, [fp, #-0x18]
    // 0x67a908: stur            x1, [fp, #-0x20]
    // 0x67a90c: LoadField: d0 = r0->field_7
    //     0x67a90c: ldur            d0, [x0, #7]
    // 0x67a910: ldur            d1, [fp, #-0x58]
    // 0x67a914: stur            d0, [fp, #-0x68]
    // 0x67a918: r0 = inline_Allocate_Double()
    //     0x67a918: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x67a91c: add             x0, x0, #0x10
    //     0x67a920: cmp             x2, x0
    //     0x67a924: b.ls            #0x67b6bc
    //     0x67a928: str             x0, [THR, #0x60]  ; THR::top
    //     0x67a92c: sub             x0, x0, #0xf
    //     0x67a930: mov             x2, #0xd108
    //     0x67a934: movk            x2, #3, lsl #16
    //     0x67a938: stur            x2, [x0, #-1]
    // 0x67a93c: StoreField: r0->field_7 = d1
    //     0x67a93c: stur            d1, [x0, #7]
    // 0x67a940: ldr             x16, [fp, #0x10]
    // 0x67a944: stp             x0, x16, [SP, #-0x10]!
    // 0x67a948: SaveReg d0
    //     0x67a948: str             d0, [SP, #-8]!
    // 0x67a94c: r0 = getMinChildIndexForScrollOffset()
    //     0x67a94c: bl              #0x67a3a8  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::getMinChildIndexForScrollOffset
    // 0x67a950: add             SP, SP, #0x18
    // 0x67a954: ldur            d0, [fp, #-0x50]
    // 0x67a958: stur            x0, [fp, #-0x28]
    // 0x67a95c: mov             x1, v0.d[0]
    // 0x67a960: and             x1, x1, #0x7fffffffffffffff
    // 0x67a964: r17 = 9218868437227405312
    //     0x67a964: mov             x17, #0x7ff0000000000000
    // 0x67a968: cmp             x1, x17
    // 0x67a96c: b.eq            #0x67a9d8
    // 0x67a970: fcmp            d0, d0
    // 0x67a974: b.vs            #0x67a9d8
    // 0x67a978: ldur            d1, [fp, #-0x68]
    // 0x67a97c: r1 = inline_Allocate_Double()
    //     0x67a97c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x67a980: add             x1, x1, #0x10
    //     0x67a984: cmp             x2, x1
    //     0x67a988: b.ls            #0x67b6d4
    //     0x67a98c: str             x1, [THR, #0x60]  ; THR::top
    //     0x67a990: sub             x1, x1, #0xf
    //     0x67a994: mov             x2, #0xd108
    //     0x67a998: movk            x2, #3, lsl #16
    //     0x67a99c: stur            x2, [x1, #-1]
    // 0x67a9a0: StoreField: r1->field_7 = d0
    //     0x67a9a0: stur            d0, [x1, #7]
    // 0x67a9a4: ldr             x16, [fp, #0x10]
    // 0x67a9a8: stp             x1, x16, [SP, #-0x10]!
    // 0x67a9ac: SaveReg d1
    //     0x67a9ac: str             d1, [SP, #-8]!
    // 0x67a9b0: r0 = getMaxChildIndexForScrollOffset()
    //     0x67a9b0: bl              #0x67a178  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::getMaxChildIndexForScrollOffset
    // 0x67a9b4: add             SP, SP, #0x18
    // 0x67a9b8: mov             x2, x0
    // 0x67a9bc: r0 = BoxInt64Instr(r2)
    //     0x67a9bc: sbfiz           x0, x2, #1, #0x1f
    //     0x67a9c0: cmp             x2, x0, asr #1
    //     0x67a9c4: b.eq            #0x67a9d0
    //     0x67a9c8: bl              #0xd69bb8
    //     0x67a9cc: stur            x2, [x0, #7]
    // 0x67a9d0: mov             x1, x0
    // 0x67a9d4: b               #0x67a9dc
    // 0x67a9d8: r1 = Null
    //     0x67a9d8: mov             x1, NULL
    // 0x67a9dc: ldr             x0, [fp, #0x10]
    // 0x67a9e0: stur            x1, [fp, #-0x18]
    // 0x67a9e4: LoadField: r2 = r0->field_5b
    //     0x67a9e4: ldur            w2, [x0, #0x5b]
    // 0x67a9e8: DecompressPointer r2
    //     0x67a9e8: add             x2, x2, HEAP, lsl #32
    // 0x67a9ec: cmp             w2, NULL
    // 0x67a9f0: b.eq            #0x67aa70
    // 0x67a9f4: ldur            x2, [fp, #-0x28]
    // 0x67a9f8: stp             x2, x0, [SP, #-0x10]!
    // 0x67a9fc: r0 = _calculateLeadingGarbage()
    //     0x67a9fc: bl              #0x67b938  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::_calculateLeadingGarbage
    // 0x67aa00: add             SP, SP, #0x10
    // 0x67aa04: mov             x1, x0
    // 0x67aa08: ldur            x0, [fp, #-0x18]
    // 0x67aa0c: stur            x1, [fp, #-0x30]
    // 0x67aa10: cmp             w0, NULL
    // 0x67aa14: b.eq            #0x67aa3c
    // 0x67aa18: r2 = LoadInt32Instr(r0)
    //     0x67aa18: sbfx            x2, x0, #1, #0x1f
    //     0x67aa1c: tbz             w0, #0, #0x67aa24
    //     0x67aa20: ldur            x2, [x0, #7]
    // 0x67aa24: ldr             x16, [fp, #0x10]
    // 0x67aa28: stp             x2, x16, [SP, #-0x10]!
    // 0x67aa2c: r0 = _calculateTrailingGarbage()
    //     0x67aa2c: bl              #0x67b848  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::_calculateTrailingGarbage
    // 0x67aa30: add             SP, SP, #0x10
    // 0x67aa34: mov             x3, x0
    // 0x67aa38: b               #0x67aa40
    // 0x67aa3c: r3 = 0
    //     0x67aa3c: mov             x3, #0
    // 0x67aa40: ldur            x2, [fp, #-0x30]
    // 0x67aa44: r0 = BoxInt64Instr(r2)
    //     0x67aa44: sbfiz           x0, x2, #1, #0x1f
    //     0x67aa48: cmp             x2, x0, asr #1
    //     0x67aa4c: b.eq            #0x67aa58
    //     0x67aa50: bl              #0xd69bb8
    //     0x67aa54: stur            x2, [x0, #7]
    // 0x67aa58: ldr             x16, [fp, #0x10]
    // 0x67aa5c: stp             x0, x16, [SP, #-0x10]!
    // 0x67aa60: SaveReg r3
    //     0x67aa60: str             x3, [SP, #-8]!
    // 0x67aa64: r0 = collectGarbage()
    //     0x67aa64: bl              #0x6797bc  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::collectGarbage
    // 0x67aa68: add             SP, SP, #0x18
    // 0x67aa6c: b               #0x67aa84
    // 0x67aa70: ldr             x16, [fp, #0x10]
    // 0x67aa74: stp             xzr, x16, [SP, #-0x10]!
    // 0x67aa78: SaveReg rZR
    //     0x67aa78: str             xzr, [SP, #-8]!
    // 0x67aa7c: r0 = collectGarbage()
    //     0x67aa7c: bl              #0x6797bc  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::collectGarbage
    // 0x67aa80: add             SP, SP, #0x18
    // 0x67aa84: ldr             x2, [fp, #0x10]
    // 0x67aa88: LoadField: r0 = r2->field_5b
    //     0x67aa88: ldur            w0, [x2, #0x5b]
    // 0x67aa8c: DecompressPointer r0
    //     0x67aa8c: add             x0, x0, HEAP, lsl #32
    // 0x67aa90: cmp             w0, NULL
    // 0x67aa94: b.ne            #0x67abdc
    // 0x67aa98: ldur            x3, [fp, #-0x28]
    // 0x67aa9c: ldur            d0, [fp, #-0x68]
    // 0x67aaa0: scvtf           d1, x3
    // 0x67aaa4: fmul            d2, d0, d1
    // 0x67aaa8: r0 = BoxInt64Instr(r3)
    //     0x67aaa8: sbfiz           x0, x3, #1, #0x1f
    //     0x67aaac: cmp             x3, x0, asr #1
    //     0x67aab0: b.eq            #0x67aabc
    //     0x67aab4: bl              #0xd69c6c
    //     0x67aab8: stur            x3, [x0, #7]
    // 0x67aabc: r1 = inline_Allocate_Double()
    //     0x67aabc: ldp             x1, x4, [THR, #0x60]  ; THR::top
    //     0x67aac0: add             x1, x1, #0x10
    //     0x67aac4: cmp             x4, x1
    //     0x67aac8: b.ls            #0x67b6f0
    //     0x67aacc: str             x1, [THR, #0x60]  ; THR::top
    //     0x67aad0: sub             x1, x1, #0xf
    //     0x67aad4: mov             x4, #0xd108
    //     0x67aad8: movk            x4, #3, lsl #16
    //     0x67aadc: stur            x4, [x1, #-1]
    // 0x67aae0: StoreField: r1->field_7 = d2
    //     0x67aae0: stur            d2, [x1, #7]
    // 0x67aae4: stp             x0, x2, [SP, #-0x10]!
    // 0x67aae8: SaveReg r1
    //     0x67aae8: str             x1, [SP, #-8]!
    // 0x67aaec: r4 = const [0, 0x3, 0x3, 0x1, index, 0x1, layoutOffset, 0x2, null]
    //     0x67aaec: add             x4, PP, #0x43, lsl #12  ; [pp+0x43530] List(9) [0, 0x3, 0x3, 0x1, "index", 0x1, "layoutOffset", 0x2, Null]
    //     0x67aaf0: ldr             x4, [x4, #0x530]
    // 0x67aaf4: r0 = addInitialChild()
    //     0x67aaf4: bl              #0x6795e8  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::addInitialChild
    // 0x67aaf8: add             SP, SP, #0x18
    // 0x67aafc: tbz             w0, #4, #0x67abc4
    // 0x67ab00: ldur            x3, [fp, #-0x28]
    // 0x67ab04: cmp             x3, #0
    // 0x67ab08: b.gt            #0x67ab14
    // 0x67ab0c: d0 = 0.000000
    //     0x67ab0c: eor             v0.16b, v0.16b, v0.16b
    // 0x67ab10: b               #0x67ab2c
    // 0x67ab14: ldur            d0, [fp, #-0x68]
    // 0x67ab18: ldr             x16, [fp, #0x10]
    // 0x67ab1c: SaveReg r16
    //     0x67ab1c: str             x16, [SP, #-8]!
    // 0x67ab20: SaveReg d0
    //     0x67ab20: str             d0, [SP, #-8]!
    // 0x67ab24: r0 = computeMaxScrollOffset()
    //     0x67ab24: bl              #0x679340  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::computeMaxScrollOffset
    // 0x67ab28: add             SP, SP, #0x10
    // 0x67ab2c: ldr             x0, [fp, #0x10]
    // 0x67ab30: stur            d0, [fp, #-0x50]
    // 0x67ab34: r0 = SliverGeometry()
    //     0x67ab34: bl              #0x679334  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x54)
    // 0x67ab38: ldur            d0, [fp, #-0x50]
    // 0x67ab3c: StoreField: r0->field_7 = d0
    //     0x67ab3c: stur            d0, [x0, #7]
    // 0x67ab40: d1 = 0.000000
    //     0x67ab40: eor             v1.16b, v1.16b, v1.16b
    // 0x67ab44: StoreField: r0->field_17 = d1
    //     0x67ab44: stur            d1, [x0, #0x17]
    // 0x67ab48: StoreField: r0->field_f = d1
    //     0x67ab48: stur            d1, [x0, #0xf]
    // 0x67ab4c: StoreField: r0->field_27 = d0
    //     0x67ab4c: stur            d0, [x0, #0x27]
    // 0x67ab50: StoreField: r0->field_2f = d1
    //     0x67ab50: stur            d1, [x0, #0x2f]
    // 0x67ab54: r4 = false
    //     0x67ab54: add             x4, NULL, #0x30  ; false
    // 0x67ab58: StoreField: r0->field_43 = r4
    //     0x67ab58: stur            w4, [x0, #0x43]
    // 0x67ab5c: StoreField: r0->field_1f = d1
    //     0x67ab5c: stur            d1, [x0, #0x1f]
    // 0x67ab60: StoreField: r0->field_37 = d1
    //     0x67ab60: stur            d1, [x0, #0x37]
    // 0x67ab64: StoreField: r0->field_4b = d1
    //     0x67ab64: stur            d1, [x0, #0x4b]
    // 0x67ab68: fcmp            d1, d1
    // 0x67ab6c: b.vs            #0x67ab74
    // 0x67ab70: b.gt            #0x67ab7c
    // 0x67ab74: r1 = false
    //     0x67ab74: add             x1, NULL, #0x30  ; false
    // 0x67ab78: b               #0x67ab80
    // 0x67ab7c: r1 = true
    //     0x67ab7c: add             x1, NULL, #0x20  ; true
    // 0x67ab80: StoreField: r0->field_3f = r1
    //     0x67ab80: stur            w1, [x0, #0x3f]
    // 0x67ab84: ldr             x5, [fp, #0x10]
    // 0x67ab88: StoreField: r5->field_4f = r0
    //     0x67ab88: stur            w0, [x5, #0x4f]
    //     0x67ab8c: ldurb           w16, [x5, #-1]
    //     0x67ab90: ldurb           w17, [x0, #-1]
    //     0x67ab94: and             x16, x17, x16, lsr #2
    //     0x67ab98: tst             x16, HEAP, lsr #32
    //     0x67ab9c: b.eq            #0x67aba4
    //     0x67aba0: bl              #0xd682ec
    // 0x67aba4: ldur            x16, [fp, #-0x10]
    // 0x67aba8: SaveReg r16
    //     0x67aba8: str             x16, [SP, #-8]!
    // 0x67abac: r0 = didFinishLayout()
    //     0x67abac: bl              #0x678c84  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::didFinishLayout
    // 0x67abb0: add             SP, SP, #8
    // 0x67abb4: r0 = Null
    //     0x67abb4: mov             x0, NULL
    // 0x67abb8: LeaveFrame
    //     0x67abb8: mov             SP, fp
    //     0x67abbc: ldp             fp, lr, [SP], #0x10
    // 0x67abc0: ret
    //     0x67abc0: ret             
    // 0x67abc4: ldr             x5, [fp, #0x10]
    // 0x67abc8: ldur            x3, [fp, #-0x28]
    // 0x67abcc: ldur            d0, [fp, #-0x68]
    // 0x67abd0: r4 = false
    //     0x67abd0: add             x4, NULL, #0x30  ; false
    // 0x67abd4: d1 = 0.000000
    //     0x67abd4: eor             v1.16b, v1.16b, v1.16b
    // 0x67abd8: b               #0x67abf0
    // 0x67abdc: mov             x5, x2
    // 0x67abe0: ldur            x3, [fp, #-0x28]
    // 0x67abe4: ldur            d0, [fp, #-0x68]
    // 0x67abe8: r4 = false
    //     0x67abe8: add             x4, NULL, #0x30  ; false
    // 0x67abec: d1 = 0.000000
    //     0x67abec: eor             v1.16b, v1.16b, v1.16b
    // 0x67abf0: LoadField: r0 = r5->field_5b
    //     0x67abf0: ldur            w0, [x5, #0x5b]
    // 0x67abf4: DecompressPointer r0
    //     0x67abf4: add             x0, x0, HEAP, lsl #32
    // 0x67abf8: cmp             w0, NULL
    // 0x67abfc: b.eq            #0x67b714
    // 0x67ac00: LoadField: r6 = r0->field_17
    //     0x67ac00: ldur            w6, [x0, #0x17]
    // 0x67ac04: DecompressPointer r6
    //     0x67ac04: add             x6, x6, HEAP, lsl #32
    // 0x67ac08: stur            x6, [fp, #-0x38]
    // 0x67ac0c: cmp             w6, NULL
    // 0x67ac10: b.eq            #0x67b718
    // 0x67ac14: mov             x0, x6
    // 0x67ac18: r2 = Null
    //     0x67ac18: mov             x2, NULL
    // 0x67ac1c: r1 = Null
    //     0x67ac1c: mov             x1, NULL
    // 0x67ac20: r4 = LoadClassIdInstr(r0)
    //     0x67ac20: ldur            x4, [x0, #-1]
    //     0x67ac24: ubfx            x4, x4, #0xc, #0x14
    // 0x67ac28: sub             x4, x4, #0x7f9
    // 0x67ac2c: cmp             x4, #2
    // 0x67ac30: b.ls            #0x67ac48
    // 0x67ac34: r8 = SliverMultiBoxAdaptorParentData
    //     0x67ac34: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67ac38: ldr             x8, [x8, #0x120]
    // 0x67ac3c: r3 = Null
    //     0x67ac3c: add             x3, PP, #0x55, lsl #12  ; [pp+0x55bc8] Null
    //     0x67ac40: ldr             x3, [x3, #0xbc8]
    // 0x67ac44: r0 = DefaultTypeTest()
    //     0x67ac44: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67ac48: ldur            x0, [fp, #-0x38]
    // 0x67ac4c: LoadField: r1 = r0->field_17
    //     0x67ac4c: ldur            w1, [x0, #0x17]
    // 0x67ac50: DecompressPointer r1
    //     0x67ac50: add             x1, x1, HEAP, lsl #32
    // 0x67ac54: cmp             w1, NULL
    // 0x67ac58: b.eq            #0x67b71c
    // 0x67ac5c: r0 = LoadInt32Instr(r1)
    //     0x67ac5c: sbfx            x0, x1, #1, #0x1f
    //     0x67ac60: tbz             w1, #0, #0x67ac68
    //     0x67ac64: ldur            x0, [x1, #7]
    // 0x67ac68: sub             x1, x0, #1
    // 0x67ac6c: mov             x2, x1
    // 0x67ac70: ldur            d0, [fp, #-0x68]
    // 0x67ac74: r3 = Null
    //     0x67ac74: mov             x3, NULL
    // 0x67ac78: ldr             x1, [fp, #0x10]
    // 0x67ac7c: ldur            x0, [fp, #-0x28]
    // 0x67ac80: stur            x3, [fp, #-0x38]
    // 0x67ac84: stur            x2, [fp, #-0x30]
    // 0x67ac88: CheckStackOverflow
    //     0x67ac88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67ac8c: cmp             SP, x16
    //     0x67ac90: b.ls            #0x67b720
    // 0x67ac94: cmp             x2, x0
    // 0x67ac98: b.lt            #0x67ae60
    // 0x67ac9c: ldur            x16, [fp, #-0x20]
    // 0x67aca0: stp             x16, x1, [SP, #-0x10]!
    // 0x67aca4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x67aca4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x67aca8: r0 = insertAndLayoutLeadingChild()
    //     0x67aca8: bl              #0x678a4c  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::insertAndLayoutLeadingChild
    // 0x67acac: add             SP, SP, #0x10
    // 0x67acb0: mov             x3, x0
    // 0x67acb4: stur            x3, [fp, #-0x48]
    // 0x67acb8: cmp             w3, NULL
    // 0x67acbc: b.ne            #0x67ad84
    // 0x67acc0: ldr             x0, [fp, #0x10]
    // 0x67acc4: ldur            x4, [fp, #-0x30]
    // 0x67acc8: ldur            d0, [fp, #-0x68]
    // 0x67accc: scvtf           d1, x4
    // 0x67acd0: fmul            d2, d1, d0
    // 0x67acd4: stur            d2, [fp, #-0x50]
    // 0x67acd8: r0 = SliverGeometry()
    //     0x67acd8: bl              #0x679334  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x54)
    // 0x67acdc: d1 = 0.000000
    //     0x67acdc: eor             v1.16b, v1.16b, v1.16b
    // 0x67ace0: StoreField: r0->field_7 = d1
    //     0x67ace0: stur            d1, [x0, #7]
    // 0x67ace4: StoreField: r0->field_17 = d1
    //     0x67ace4: stur            d1, [x0, #0x17]
    // 0x67ace8: StoreField: r0->field_f = d1
    //     0x67ace8: stur            d1, [x0, #0xf]
    // 0x67acec: StoreField: r0->field_27 = d1
    //     0x67acec: stur            d1, [x0, #0x27]
    // 0x67acf0: StoreField: r0->field_2f = d1
    //     0x67acf0: stur            d1, [x0, #0x2f]
    // 0x67acf4: r5 = false
    //     0x67acf4: add             x5, NULL, #0x30  ; false
    // 0x67acf8: StoreField: r0->field_43 = r5
    //     0x67acf8: stur            w5, [x0, #0x43]
    // 0x67acfc: ldur            d0, [fp, #-0x50]
    // 0x67ad00: r1 = inline_Allocate_Double()
    //     0x67ad00: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x67ad04: add             x1, x1, #0x10
    //     0x67ad08: cmp             x2, x1
    //     0x67ad0c: b.ls            #0x67b728
    //     0x67ad10: str             x1, [THR, #0x60]  ; THR::top
    //     0x67ad14: sub             x1, x1, #0xf
    //     0x67ad18: mov             x2, #0xd108
    //     0x67ad1c: movk            x2, #3, lsl #16
    //     0x67ad20: stur            x2, [x1, #-1]
    // 0x67ad24: StoreField: r1->field_7 = d0
    //     0x67ad24: stur            d0, [x1, #7]
    // 0x67ad28: StoreField: r0->field_47 = r1
    //     0x67ad28: stur            w1, [x0, #0x47]
    // 0x67ad2c: StoreField: r0->field_1f = d1
    //     0x67ad2c: stur            d1, [x0, #0x1f]
    // 0x67ad30: StoreField: r0->field_37 = d1
    //     0x67ad30: stur            d1, [x0, #0x37]
    // 0x67ad34: StoreField: r0->field_4b = d1
    //     0x67ad34: stur            d1, [x0, #0x4b]
    // 0x67ad38: fcmp            d1, d1
    // 0x67ad3c: b.vs            #0x67ad44
    // 0x67ad40: b.gt            #0x67ad4c
    // 0x67ad44: r1 = false
    //     0x67ad44: add             x1, NULL, #0x30  ; false
    // 0x67ad48: b               #0x67ad50
    // 0x67ad4c: r1 = true
    //     0x67ad4c: add             x1, NULL, #0x20  ; true
    // 0x67ad50: StoreField: r0->field_3f = r1
    //     0x67ad50: stur            w1, [x0, #0x3f]
    // 0x67ad54: ldr             x6, [fp, #0x10]
    // 0x67ad58: StoreField: r6->field_4f = r0
    //     0x67ad58: stur            w0, [x6, #0x4f]
    //     0x67ad5c: ldurb           w16, [x6, #-1]
    //     0x67ad60: ldurb           w17, [x0, #-1]
    //     0x67ad64: and             x16, x17, x16, lsr #2
    //     0x67ad68: tst             x16, HEAP, lsr #32
    //     0x67ad6c: b.eq            #0x67ad74
    //     0x67ad70: bl              #0xd6830c
    // 0x67ad74: r0 = Null
    //     0x67ad74: mov             x0, NULL
    // 0x67ad78: LeaveFrame
    //     0x67ad78: mov             SP, fp
    //     0x67ad7c: ldp             fp, lr, [SP], #0x10
    // 0x67ad80: ret
    //     0x67ad80: ret             
    // 0x67ad84: ldr             x6, [fp, #0x10]
    // 0x67ad88: ldur            x7, [fp, #-0x38]
    // 0x67ad8c: ldur            x4, [fp, #-0x30]
    // 0x67ad90: ldur            d0, [fp, #-0x68]
    // 0x67ad94: r5 = false
    //     0x67ad94: add             x5, NULL, #0x30  ; false
    // 0x67ad98: d1 = 0.000000
    //     0x67ad98: eor             v1.16b, v1.16b, v1.16b
    // 0x67ad9c: LoadField: r8 = r3->field_17
    //     0x67ad9c: ldur            w8, [x3, #0x17]
    // 0x67ada0: DecompressPointer r8
    //     0x67ada0: add             x8, x8, HEAP, lsl #32
    // 0x67ada4: stur            x8, [fp, #-0x40]
    // 0x67ada8: cmp             w8, NULL
    // 0x67adac: b.eq            #0x67b744
    // 0x67adb0: mov             x0, x8
    // 0x67adb4: r2 = Null
    //     0x67adb4: mov             x2, NULL
    // 0x67adb8: r1 = Null
    //     0x67adb8: mov             x1, NULL
    // 0x67adbc: r4 = LoadClassIdInstr(r0)
    //     0x67adbc: ldur            x4, [x0, #-1]
    //     0x67adc0: ubfx            x4, x4, #0xc, #0x14
    // 0x67adc4: sub             x4, x4, #0x7f9
    // 0x67adc8: cmp             x4, #2
    // 0x67adcc: b.ls            #0x67ade4
    // 0x67add0: r8 = SliverMultiBoxAdaptorParentData
    //     0x67add0: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67add4: ldr             x8, [x8, #0x120]
    // 0x67add8: r3 = Null
    //     0x67add8: add             x3, PP, #0x55, lsl #12  ; [pp+0x55bd8] Null
    //     0x67addc: ldr             x3, [x3, #0xbd8]
    // 0x67ade0: r0 = DefaultTypeTest()
    //     0x67ade0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67ade4: ldur            x1, [fp, #-0x30]
    // 0x67ade8: scvtf           d0, x1
    // 0x67adec: ldur            d1, [fp, #-0x68]
    // 0x67adf0: fmul            d2, d1, d0
    // 0x67adf4: r0 = inline_Allocate_Double()
    //     0x67adf4: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x67adf8: add             x0, x0, #0x10
    //     0x67adfc: cmp             x2, x0
    //     0x67ae00: b.ls            #0x67b748
    //     0x67ae04: str             x0, [THR, #0x60]  ; THR::top
    //     0x67ae08: sub             x0, x0, #0xf
    //     0x67ae0c: mov             x2, #0xd108
    //     0x67ae10: movk            x2, #3, lsl #16
    //     0x67ae14: stur            x2, [x0, #-1]
    // 0x67ae18: StoreField: r0->field_7 = d2
    //     0x67ae18: stur            d2, [x0, #7]
    // 0x67ae1c: ldur            x2, [fp, #-0x40]
    // 0x67ae20: StoreField: r2->field_7 = r0
    //     0x67ae20: stur            w0, [x2, #7]
    //     0x67ae24: ldurb           w16, [x2, #-1]
    //     0x67ae28: ldurb           w17, [x0, #-1]
    //     0x67ae2c: and             x16, x17, x16, lsr #2
    //     0x67ae30: tst             x16, HEAP, lsr #32
    //     0x67ae34: b.eq            #0x67ae3c
    //     0x67ae38: bl              #0xd6828c
    // 0x67ae3c: ldur            x0, [fp, #-0x38]
    // 0x67ae40: cmp             w0, NULL
    // 0x67ae44: b.ne            #0x67ae50
    // 0x67ae48: ldur            x3, [fp, #-0x48]
    // 0x67ae4c: b               #0x67ae54
    // 0x67ae50: mov             x3, x0
    // 0x67ae54: sub             x2, x1, #1
    // 0x67ae58: mov             v0.16b, v1.16b
    // 0x67ae5c: b               #0x67ac78
    // 0x67ae60: mov             x0, x3
    // 0x67ae64: mov             v1.16b, v0.16b
    // 0x67ae68: cmp             w0, NULL
    // 0x67ae6c: b.ne            #0x67af74
    // 0x67ae70: ldr             x1, [fp, #0x10]
    // 0x67ae74: ldur            x2, [fp, #-0x28]
    // 0x67ae78: LoadField: r0 = r1->field_5b
    //     0x67ae78: ldur            w0, [x1, #0x5b]
    // 0x67ae7c: DecompressPointer r0
    //     0x67ae7c: add             x0, x0, HEAP, lsl #32
    // 0x67ae80: cmp             w0, NULL
    // 0x67ae84: b.eq            #0x67b760
    // 0x67ae88: r3 = LoadClassIdInstr(r0)
    //     0x67ae88: ldur            x3, [x0, #-1]
    //     0x67ae8c: ubfx            x3, x3, #0xc, #0x14
    // 0x67ae90: ldur            x16, [fp, #-0x20]
    // 0x67ae94: stp             x16, x0, [SP, #-0x10]!
    // 0x67ae98: mov             x0, x3
    // 0x67ae9c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x67ae9c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x67aea0: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x67aea0: mov             x17, #0xcdfb
    //     0x67aea4: add             lr, x0, x17
    //     0x67aea8: ldr             lr, [x21, lr, lsl #3]
    //     0x67aeac: blr             lr
    // 0x67aeb0: add             SP, SP, #0x10
    // 0x67aeb4: ldr             x3, [fp, #0x10]
    // 0x67aeb8: LoadField: r4 = r3->field_5b
    //     0x67aeb8: ldur            w4, [x3, #0x5b]
    // 0x67aebc: DecompressPointer r4
    //     0x67aebc: add             x4, x4, HEAP, lsl #32
    // 0x67aec0: stur            x4, [fp, #-0x48]
    // 0x67aec4: cmp             w4, NULL
    // 0x67aec8: b.eq            #0x67b764
    // 0x67aecc: LoadField: r5 = r4->field_17
    //     0x67aecc: ldur            w5, [x4, #0x17]
    // 0x67aed0: DecompressPointer r5
    //     0x67aed0: add             x5, x5, HEAP, lsl #32
    // 0x67aed4: stur            x5, [fp, #-0x40]
    // 0x67aed8: cmp             w5, NULL
    // 0x67aedc: b.eq            #0x67b768
    // 0x67aee0: mov             x0, x5
    // 0x67aee4: r2 = Null
    //     0x67aee4: mov             x2, NULL
    // 0x67aee8: r1 = Null
    //     0x67aee8: mov             x1, NULL
    // 0x67aeec: r4 = LoadClassIdInstr(r0)
    //     0x67aeec: ldur            x4, [x0, #-1]
    //     0x67aef0: ubfx            x4, x4, #0xc, #0x14
    // 0x67aef4: sub             x4, x4, #0x7f9
    // 0x67aef8: cmp             x4, #2
    // 0x67aefc: b.ls            #0x67af14
    // 0x67af00: r8 = SliverMultiBoxAdaptorParentData
    //     0x67af00: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67af04: ldr             x8, [x8, #0x120]
    // 0x67af08: r3 = Null
    //     0x67af08: add             x3, PP, #0x55, lsl #12  ; [pp+0x55be8] Null
    //     0x67af0c: ldr             x3, [x3, #0xbe8]
    // 0x67af10: r0 = DefaultTypeTest()
    //     0x67af10: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67af14: ldur            x3, [fp, #-0x28]
    // 0x67af18: scvtf           d0, x3
    // 0x67af1c: ldur            d1, [fp, #-0x68]
    // 0x67af20: fmul            d2, d1, d0
    // 0x67af24: r0 = inline_Allocate_Double()
    //     0x67af24: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x67af28: add             x0, x0, #0x10
    //     0x67af2c: cmp             x1, x0
    //     0x67af30: b.ls            #0x67b76c
    //     0x67af34: str             x0, [THR, #0x60]  ; THR::top
    //     0x67af38: sub             x0, x0, #0xf
    //     0x67af3c: mov             x1, #0xd108
    //     0x67af40: movk            x1, #3, lsl #16
    //     0x67af44: stur            x1, [x0, #-1]
    // 0x67af48: StoreField: r0->field_7 = d2
    //     0x67af48: stur            d2, [x0, #7]
    // 0x67af4c: ldur            x1, [fp, #-0x40]
    // 0x67af50: StoreField: r1->field_7 = r0
    //     0x67af50: stur            w0, [x1, #7]
    //     0x67af54: ldurb           w16, [x1, #-1]
    //     0x67af58: ldurb           w17, [x0, #-1]
    //     0x67af5c: and             x16, x17, x16, lsr #2
    //     0x67af60: tst             x16, HEAP, lsr #32
    //     0x67af64: b.eq            #0x67af6c
    //     0x67af68: bl              #0xd6826c
    // 0x67af6c: ldur            x4, [fp, #-0x48]
    // 0x67af70: b               #0x67af7c
    // 0x67af74: ldur            x3, [fp, #-0x28]
    // 0x67af78: mov             x4, x0
    // 0x67af7c: stur            x4, [fp, #-0x40]
    // 0x67af80: LoadField: r5 = r4->field_17
    //     0x67af80: ldur            w5, [x4, #0x17]
    // 0x67af84: DecompressPointer r5
    //     0x67af84: add             x5, x5, HEAP, lsl #32
    // 0x67af88: stur            x5, [fp, #-0x38]
    // 0x67af8c: cmp             w5, NULL
    // 0x67af90: b.eq            #0x67b784
    // 0x67af94: mov             x0, x5
    // 0x67af98: r2 = Null
    //     0x67af98: mov             x2, NULL
    // 0x67af9c: r1 = Null
    //     0x67af9c: mov             x1, NULL
    // 0x67afa0: r4 = LoadClassIdInstr(r0)
    //     0x67afa0: ldur            x4, [x0, #-1]
    //     0x67afa4: ubfx            x4, x4, #0xc, #0x14
    // 0x67afa8: sub             x4, x4, #0x7f9
    // 0x67afac: cmp             x4, #2
    // 0x67afb0: b.ls            #0x67afc8
    // 0x67afb4: r8 = SliverMultiBoxAdaptorParentData
    //     0x67afb4: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67afb8: ldr             x8, [x8, #0x120]
    // 0x67afbc: r3 = Null
    //     0x67afbc: add             x3, PP, #0x55, lsl #12  ; [pp+0x55bf8] Null
    //     0x67afc0: ldr             x3, [x3, #0xbf8]
    // 0x67afc4: r0 = DefaultTypeTest()
    //     0x67afc4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67afc8: ldur            x0, [fp, #-0x38]
    // 0x67afcc: LoadField: r1 = r0->field_17
    //     0x67afcc: ldur            w1, [x0, #0x17]
    // 0x67afd0: DecompressPointer r1
    //     0x67afd0: add             x1, x1, HEAP, lsl #32
    // 0x67afd4: cmp             w1, NULL
    // 0x67afd8: b.eq            #0x67b788
    // 0x67afdc: r2 = LoadInt32Instr(r1)
    //     0x67afdc: sbfx            x2, x1, #1, #0x1f
    //     0x67afe0: tbz             w1, #0, #0x67afe8
    //     0x67afe4: ldur            x2, [x1, #7]
    // 0x67afe8: add             x1, x2, #1
    // 0x67afec: ldur            x5, [fp, #-0x40]
    // 0x67aff0: mov             x4, x1
    // 0x67aff4: ldur            d0, [fp, #-0x68]
    // 0x67aff8: ldur            x3, [fp, #-0x18]
    // 0x67affc: stur            x5, [fp, #-0x48]
    // 0x67b000: stur            x4, [fp, #-0x30]
    // 0x67b004: CheckStackOverflow
    //     0x67b004: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67b008: cmp             SP, x16
    //     0x67b00c: b.ls            #0x67b78c
    // 0x67b010: cmp             w3, NULL
    // 0x67b014: b.eq            #0x67b02c
    // 0x67b018: r1 = LoadInt32Instr(r3)
    //     0x67b018: sbfx            x1, x3, #1, #0x1f
    //     0x67b01c: tbz             w3, #0, #0x67b024
    //     0x67b020: ldur            x1, [x3, #7]
    // 0x67b024: cmp             x4, x1
    // 0x67b028: b.gt            #0x67b22c
    // 0x67b02c: LoadField: r6 = r0->field_f
    //     0x67b02c: ldur            w6, [x0, #0xf]
    // 0x67b030: DecompressPointer r6
    //     0x67b030: add             x6, x6, HEAP, lsl #32
    // 0x67b034: stur            x6, [fp, #-0x40]
    // 0x67b038: cmp             w6, NULL
    // 0x67b03c: b.ne            #0x67b048
    // 0x67b040: mov             x1, x4
    // 0x67b044: b               #0x67b0bc
    // 0x67b048: LoadField: r7 = r6->field_17
    //     0x67b048: ldur            w7, [x6, #0x17]
    // 0x67b04c: DecompressPointer r7
    //     0x67b04c: add             x7, x7, HEAP, lsl #32
    // 0x67b050: stur            x7, [fp, #-0x38]
    // 0x67b054: cmp             w7, NULL
    // 0x67b058: b.eq            #0x67b794
    // 0x67b05c: mov             x0, x7
    // 0x67b060: r2 = Null
    //     0x67b060: mov             x2, NULL
    // 0x67b064: r1 = Null
    //     0x67b064: mov             x1, NULL
    // 0x67b068: r4 = LoadClassIdInstr(r0)
    //     0x67b068: ldur            x4, [x0, #-1]
    //     0x67b06c: ubfx            x4, x4, #0xc, #0x14
    // 0x67b070: sub             x4, x4, #0x7f9
    // 0x67b074: cmp             x4, #2
    // 0x67b078: b.ls            #0x67b090
    // 0x67b07c: r8 = SliverMultiBoxAdaptorParentData
    //     0x67b07c: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67b080: ldr             x8, [x8, #0x120]
    // 0x67b084: r3 = Null
    //     0x67b084: add             x3, PP, #0x55, lsl #12  ; [pp+0x55c08] Null
    //     0x67b088: ldr             x3, [x3, #0xc08]
    // 0x67b08c: r0 = DefaultTypeTest()
    //     0x67b08c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67b090: ldur            x0, [fp, #-0x38]
    // 0x67b094: LoadField: r1 = r0->field_17
    //     0x67b094: ldur            w1, [x0, #0x17]
    // 0x67b098: DecompressPointer r1
    //     0x67b098: add             x1, x1, HEAP, lsl #32
    // 0x67b09c: cmp             w1, NULL
    // 0x67b0a0: b.eq            #0x67b798
    // 0x67b0a4: r0 = LoadInt32Instr(r1)
    //     0x67b0a4: sbfx            x0, x1, #1, #0x1f
    //     0x67b0a8: tbz             w1, #0, #0x67b0b0
    //     0x67b0ac: ldur            x0, [x1, #7]
    // 0x67b0b0: ldur            x1, [fp, #-0x30]
    // 0x67b0b4: cmp             x0, x1
    // 0x67b0b8: b.eq            #0x67b118
    // 0x67b0bc: ldr             x16, [fp, #0x10]
    // 0x67b0c0: ldur            lr, [fp, #-0x20]
    // 0x67b0c4: stp             lr, x16, [SP, #-0x10]!
    // 0x67b0c8: ldur            x16, [fp, #-0x48]
    // 0x67b0cc: SaveReg r16
    //     0x67b0cc: str             x16, [SP, #-8]!
    // 0x67b0d0: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x67b0d0: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x67b0d4: r0 = insertAndLayoutChild()
    //     0x67b0d4: bl              #0x677f44  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::insertAndLayoutChild
    // 0x67b0d8: add             SP, SP, #0x18
    // 0x67b0dc: mov             x1, x0
    // 0x67b0e0: cmp             w1, NULL
    // 0x67b0e4: b.ne            #0x67b104
    // 0x67b0e8: ldur            x2, [fp, #-0x30]
    // 0x67b0ec: ldur            d0, [fp, #-0x68]
    // 0x67b0f0: scvtf           d1, x2
    // 0x67b0f4: fmul            d2, d1, d0
    // 0x67b0f8: mov             v1.16b, v0.16b
    // 0x67b0fc: mov             v0.16b, v2.16b
    // 0x67b100: b               #0x67b234
    // 0x67b104: ldur            x2, [fp, #-0x30]
    // 0x67b108: ldur            d0, [fp, #-0x68]
    // 0x67b10c: mov             x5, x1
    // 0x67b110: mov             x3, x2
    // 0x67b114: b               #0x67b158
    // 0x67b118: mov             x2, x1
    // 0x67b11c: ldur            x1, [fp, #-0x40]
    // 0x67b120: ldur            d0, [fp, #-0x68]
    // 0x67b124: r0 = LoadClassIdInstr(r1)
    //     0x67b124: ldur            x0, [x1, #-1]
    //     0x67b128: ubfx            x0, x0, #0xc, #0x14
    // 0x67b12c: ldur            x16, [fp, #-0x20]
    // 0x67b130: stp             x16, x1, [SP, #-0x10]!
    // 0x67b134: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x67b134: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x67b138: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x67b138: mov             x17, #0xcdfb
    //     0x67b13c: add             lr, x0, x17
    //     0x67b140: ldr             lr, [x21, lr, lsl #3]
    //     0x67b144: blr             lr
    // 0x67b148: add             SP, SP, #0x10
    // 0x67b14c: ldur            x5, [fp, #-0x40]
    // 0x67b150: ldur            x3, [fp, #-0x30]
    // 0x67b154: ldur            d0, [fp, #-0x68]
    // 0x67b158: stur            x5, [fp, #-0x40]
    // 0x67b15c: LoadField: r4 = r5->field_17
    //     0x67b15c: ldur            w4, [x5, #0x17]
    // 0x67b160: DecompressPointer r4
    //     0x67b160: add             x4, x4, HEAP, lsl #32
    // 0x67b164: stur            x4, [fp, #-0x38]
    // 0x67b168: cmp             w4, NULL
    // 0x67b16c: b.eq            #0x67b79c
    // 0x67b170: mov             x0, x4
    // 0x67b174: r2 = Null
    //     0x67b174: mov             x2, NULL
    // 0x67b178: r1 = Null
    //     0x67b178: mov             x1, NULL
    // 0x67b17c: r4 = LoadClassIdInstr(r0)
    //     0x67b17c: ldur            x4, [x0, #-1]
    //     0x67b180: ubfx            x4, x4, #0xc, #0x14
    // 0x67b184: sub             x4, x4, #0x7f9
    // 0x67b188: cmp             x4, #2
    // 0x67b18c: b.ls            #0x67b1a4
    // 0x67b190: r8 = SliverMultiBoxAdaptorParentData
    //     0x67b190: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67b194: ldr             x8, [x8, #0x120]
    // 0x67b198: r3 = Null
    //     0x67b198: add             x3, PP, #0x55, lsl #12  ; [pp+0x55c18] Null
    //     0x67b19c: ldr             x3, [x3, #0xc18]
    // 0x67b1a0: r0 = DefaultTypeTest()
    //     0x67b1a0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67b1a4: ldur            x1, [fp, #-0x38]
    // 0x67b1a8: LoadField: r0 = r1->field_17
    //     0x67b1a8: ldur            w0, [x1, #0x17]
    // 0x67b1ac: DecompressPointer r0
    //     0x67b1ac: add             x0, x0, HEAP, lsl #32
    // 0x67b1b0: cmp             w0, NULL
    // 0x67b1b4: b.eq            #0x67b7a0
    // 0x67b1b8: r2 = LoadInt32Instr(r0)
    //     0x67b1b8: sbfx            x2, x0, #1, #0x1f
    //     0x67b1bc: tbz             w0, #0, #0x67b1c4
    //     0x67b1c0: ldur            x2, [x0, #7]
    // 0x67b1c4: scvtf           d0, x2
    // 0x67b1c8: ldur            d1, [fp, #-0x68]
    // 0x67b1cc: fmul            d2, d1, d0
    // 0x67b1d0: r0 = inline_Allocate_Double()
    //     0x67b1d0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x67b1d4: add             x0, x0, #0x10
    //     0x67b1d8: cmp             x2, x0
    //     0x67b1dc: b.ls            #0x67b7a4
    //     0x67b1e0: str             x0, [THR, #0x60]  ; THR::top
    //     0x67b1e4: sub             x0, x0, #0xf
    //     0x67b1e8: mov             x2, #0xd108
    //     0x67b1ec: movk            x2, #3, lsl #16
    //     0x67b1f0: stur            x2, [x0, #-1]
    // 0x67b1f4: StoreField: r0->field_7 = d2
    //     0x67b1f4: stur            d2, [x0, #7]
    // 0x67b1f8: StoreField: r1->field_7 = r0
    //     0x67b1f8: stur            w0, [x1, #7]
    //     0x67b1fc: ldurb           w16, [x1, #-1]
    //     0x67b200: ldurb           w17, [x0, #-1]
    //     0x67b204: and             x16, x17, x16, lsr #2
    //     0x67b208: tst             x16, HEAP, lsr #32
    //     0x67b20c: b.eq            #0x67b214
    //     0x67b210: bl              #0xd6826c
    // 0x67b214: ldur            x0, [fp, #-0x30]
    // 0x67b218: add             x4, x0, #1
    // 0x67b21c: ldur            x5, [fp, #-0x40]
    // 0x67b220: mov             x0, x1
    // 0x67b224: mov             v0.16b, v1.16b
    // 0x67b228: b               #0x67aff8
    // 0x67b22c: mov             v1.16b, v0.16b
    // 0x67b230: d0 = inf
    //     0x67b230: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x67b234: ldr             x4, [fp, #0x10]
    // 0x67b238: ldur            x3, [fp, #-0x28]
    // 0x67b23c: stur            d0, [fp, #-0x50]
    // 0x67b240: LoadField: r0 = r4->field_5f
    //     0x67b240: ldur            w0, [x4, #0x5f]
    // 0x67b244: DecompressPointer r0
    //     0x67b244: add             x0, x0, HEAP, lsl #32
    // 0x67b248: cmp             w0, NULL
    // 0x67b24c: b.eq            #0x67b7bc
    // 0x67b250: LoadField: r5 = r0->field_17
    //     0x67b250: ldur            w5, [x0, #0x17]
    // 0x67b254: DecompressPointer r5
    //     0x67b254: add             x5, x5, HEAP, lsl #32
    // 0x67b258: stur            x5, [fp, #-0x18]
    // 0x67b25c: cmp             w5, NULL
    // 0x67b260: b.eq            #0x67b7c0
    // 0x67b264: mov             x0, x5
    // 0x67b268: r2 = Null
    //     0x67b268: mov             x2, NULL
    // 0x67b26c: r1 = Null
    //     0x67b26c: mov             x1, NULL
    // 0x67b270: r4 = LoadClassIdInstr(r0)
    //     0x67b270: ldur            x4, [x0, #-1]
    //     0x67b274: ubfx            x4, x4, #0xc, #0x14
    // 0x67b278: sub             x4, x4, #0x7f9
    // 0x67b27c: cmp             x4, #2
    // 0x67b280: b.ls            #0x67b298
    // 0x67b284: r8 = SliverMultiBoxAdaptorParentData
    //     0x67b284: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67b288: ldr             x8, [x8, #0x120]
    // 0x67b28c: r3 = Null
    //     0x67b28c: add             x3, PP, #0x55, lsl #12  ; [pp+0x55c28] Null
    //     0x67b290: ldr             x3, [x3, #0xc28]
    // 0x67b294: r0 = DefaultTypeTest()
    //     0x67b294: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67b298: ldur            x0, [fp, #-0x18]
    // 0x67b29c: LoadField: r2 = r0->field_17
    //     0x67b29c: ldur            w2, [x0, #0x17]
    // 0x67b2a0: DecompressPointer r2
    //     0x67b2a0: add             x2, x2, HEAP, lsl #32
    // 0x67b2a4: cmp             w2, NULL
    // 0x67b2a8: b.eq            #0x67b7c4
    // 0x67b2ac: ldur            x3, [fp, #-0x28]
    // 0x67b2b0: scvtf           d0, x3
    // 0x67b2b4: ldur            d1, [fp, #-0x68]
    // 0x67b2b8: fmul            d2, d1, d0
    // 0x67b2bc: stur            d2, [fp, #-0x70]
    // 0x67b2c0: r4 = LoadInt32Instr(r2)
    //     0x67b2c0: sbfx            x4, x2, #1, #0x1f
    //     0x67b2c4: tbz             w2, #0, #0x67b2cc
    //     0x67b2c8: ldur            x4, [x2, #7]
    // 0x67b2cc: stur            x4, [fp, #-0x30]
    // 0x67b2d0: add             x0, x4, #1
    // 0x67b2d4: scvtf           d0, x0
    // 0x67b2d8: fmul            d3, d1, d0
    // 0x67b2dc: stur            d3, [fp, #-0x58]
    // 0x67b2e0: r0 = BoxInt64Instr(r3)
    //     0x67b2e0: sbfiz           x0, x3, #1, #0x1f
    //     0x67b2e4: cmp             x3, x0, asr #1
    //     0x67b2e8: b.eq            #0x67b2f4
    //     0x67b2ec: bl              #0xd69c6c
    //     0x67b2f0: stur            x3, [x0, #7]
    // 0x67b2f4: r1 = inline_Allocate_Double()
    //     0x67b2f4: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x67b2f8: add             x1, x1, #0x10
    //     0x67b2fc: cmp             x3, x1
    //     0x67b300: b.ls            #0x67b7c8
    //     0x67b304: str             x1, [THR, #0x60]  ; THR::top
    //     0x67b308: sub             x1, x1, #0xf
    //     0x67b30c: mov             x3, #0xd108
    //     0x67b310: movk            x3, #3, lsl #16
    //     0x67b314: stur            x3, [x1, #-1]
    // 0x67b318: StoreField: r1->field_7 = d2
    //     0x67b318: stur            d2, [x1, #7]
    // 0x67b31c: ldr             x16, [fp, #0x10]
    // 0x67b320: ldur            lr, [fp, #-8]
    // 0x67b324: stp             lr, x16, [SP, #-0x10]!
    // 0x67b328: stp             x2, x0, [SP, #-0x10]!
    // 0x67b32c: SaveReg r1
    //     0x67b32c: str             x1, [SP, #-8]!
    // 0x67b330: SaveReg d3
    //     0x67b330: str             d3, [SP, #-8]!
    // 0x67b334: r0 = estimateMaxScrollOffset()
    //     0x67b334: bl              #0x677c8c  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::estimateMaxScrollOffset
    // 0x67b338: add             SP, SP, #0x30
    // 0x67b33c: mov             v1.16b, v0.16b
    // 0x67b340: ldur            d0, [fp, #-0x50]
    // 0x67b344: stur            d1, [fp, #-0x78]
    // 0x67b348: fcmp            d0, d1
    // 0x67b34c: b.vs            #0x67b35c
    // 0x67b350: b.le            #0x67b35c
    // 0x67b354: mov             v3.16b, v1.16b
    // 0x67b358: b               #0x67b400
    // 0x67b35c: fcmp            d0, d1
    // 0x67b360: b.vs            #0x67b370
    // 0x67b364: b.ge            #0x67b370
    // 0x67b368: mov             v3.16b, v0.16b
    // 0x67b36c: b               #0x67b400
    // 0x67b370: d2 = 0.000000
    //     0x67b370: eor             v2.16b, v2.16b, v2.16b
    // 0x67b374: fcmp            d0, d2
    // 0x67b378: b.vs            #0x67b380
    // 0x67b37c: b.eq            #0x67b388
    // 0x67b380: r0 = false
    //     0x67b380: add             x0, NULL, #0x30  ; false
    // 0x67b384: b               #0x67b38c
    // 0x67b388: r0 = true
    //     0x67b388: add             x0, NULL, #0x20  ; true
    // 0x67b38c: tbnz            w0, #4, #0x67b3a4
    // 0x67b390: fadd            d3, d0, d1
    // 0x67b394: fmul            d4, d3, d0
    // 0x67b398: fmul            d0, d4, d1
    // 0x67b39c: mov             v3.16b, v0.16b
    // 0x67b3a0: b               #0x67b400
    // 0x67b3a4: tbnz            w0, #4, #0x67b3e8
    // 0x67b3a8: r0 = inline_Allocate_Double()
    //     0x67b3a8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x67b3ac: add             x0, x0, #0x10
    //     0x67b3b0: cmp             x1, x0
    //     0x67b3b4: b.ls            #0x67b7f4
    //     0x67b3b8: str             x0, [THR, #0x60]  ; THR::top
    //     0x67b3bc: sub             x0, x0, #0xf
    //     0x67b3c0: mov             x1, #0xd108
    //     0x67b3c4: movk            x1, #3, lsl #16
    //     0x67b3c8: stur            x1, [x0, #-1]
    // 0x67b3cc: StoreField: r0->field_7 = d1
    //     0x67b3cc: stur            d1, [x0, #7]
    // 0x67b3d0: SaveReg r0
    //     0x67b3d0: str             x0, [SP, #-8]!
    // 0x67b3d4: r0 = isNegative()
    //     0x67b3d4: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x67b3d8: add             SP, SP, #8
    // 0x67b3dc: tbnz            w0, #4, #0x67b3e8
    // 0x67b3e0: ldur            d0, [fp, #-0x78]
    // 0x67b3e4: b               #0x67b3f4
    // 0x67b3e8: ldur            d0, [fp, #-0x78]
    // 0x67b3ec: fcmp            d0, d0
    // 0x67b3f0: b.vc            #0x67b3fc
    // 0x67b3f4: mov             v3.16b, v0.16b
    // 0x67b3f8: b               #0x67b400
    // 0x67b3fc: ldur            d3, [fp, #-0x50]
    // 0x67b400: ldur            d2, [fp, #-0x60]
    // 0x67b404: ldur            d0, [fp, #-0x70]
    // 0x67b408: ldur            d1, [fp, #-0x58]
    // 0x67b40c: ldur            x0, [fp, #-8]
    // 0x67b410: stur            d3, [fp, #-0x50]
    // 0x67b414: r1 = inline_Allocate_Double()
    //     0x67b414: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x67b418: add             x1, x1, #0x10
    //     0x67b41c: cmp             x2, x1
    //     0x67b420: b.ls            #0x67b80c
    //     0x67b424: str             x1, [THR, #0x60]  ; THR::top
    //     0x67b428: sub             x1, x1, #0xf
    //     0x67b42c: mov             x2, #0xd108
    //     0x67b430: movk            x2, #3, lsl #16
    //     0x67b434: stur            x2, [x1, #-1]
    // 0x67b438: StoreField: r1->field_7 = d1
    //     0x67b438: stur            d1, [x1, #7]
    // 0x67b43c: stur            x1, [fp, #-0x18]
    // 0x67b440: ldr             x16, [fp, #0x10]
    // 0x67b444: stp             x0, x16, [SP, #-0x10]!
    // 0x67b448: SaveReg d0
    //     0x67b448: str             d0, [SP, #-8]!
    // 0x67b44c: SaveReg r1
    //     0x67b44c: str             x1, [SP, #-8]!
    // 0x67b450: r0 = calculatePaintOffset()
    //     0x67b450: bl              #0x677ba0  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0x67b454: add             SP, SP, #0x20
    // 0x67b458: stur            d0, [fp, #-0x78]
    // 0x67b45c: ldr             x16, [fp, #0x10]
    // 0x67b460: ldur            lr, [fp, #-8]
    // 0x67b464: stp             lr, x16, [SP, #-0x10]!
    // 0x67b468: ldur            d1, [fp, #-0x70]
    // 0x67b46c: SaveReg d1
    //     0x67b46c: str             d1, [SP, #-8]!
    // 0x67b470: ldur            x16, [fp, #-0x18]
    // 0x67b474: SaveReg r16
    //     0x67b474: str             x16, [SP, #-8]!
    // 0x67b478: r0 = calculateCacheOffset()
    //     0x67b478: bl              #0x677aa4  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculateCacheOffset
    // 0x67b47c: add             SP, SP, #0x20
    // 0x67b480: ldur            x0, [fp, #-8]
    // 0x67b484: stur            d0, [fp, #-0x70]
    // 0x67b488: LoadField: d1 = r0->field_2b
    //     0x67b488: ldur            d1, [x0, #0x2b]
    // 0x67b48c: ldur            d2, [fp, #-0x60]
    // 0x67b490: fadd            d3, d2, d1
    // 0x67b494: mov             x0, v3.d[0]
    // 0x67b498: and             x0, x0, #0x7fffffffffffffff
    // 0x67b49c: r17 = 9218868437227405312
    //     0x67b49c: mov             x17, #0x7ff0000000000000
    // 0x67b4a0: cmp             x0, x17
    // 0x67b4a4: b.eq            #0x67b50c
    // 0x67b4a8: fcmp            d3, d3
    // 0x67b4ac: b.vs            #0x67b50c
    // 0x67b4b0: ldur            d1, [fp, #-0x68]
    // 0x67b4b4: r0 = inline_Allocate_Double()
    //     0x67b4b4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x67b4b8: add             x0, x0, #0x10
    //     0x67b4bc: cmp             x1, x0
    //     0x67b4c0: b.ls            #0x67b830
    //     0x67b4c4: str             x0, [THR, #0x60]  ; THR::top
    //     0x67b4c8: sub             x0, x0, #0xf
    //     0x67b4cc: mov             x1, #0xd108
    //     0x67b4d0: movk            x1, #3, lsl #16
    //     0x67b4d4: stur            x1, [x0, #-1]
    // 0x67b4d8: StoreField: r0->field_7 = d3
    //     0x67b4d8: stur            d3, [x0, #7]
    // 0x67b4dc: ldr             x16, [fp, #0x10]
    // 0x67b4e0: stp             x0, x16, [SP, #-0x10]!
    // 0x67b4e4: SaveReg d1
    //     0x67b4e4: str             d1, [SP, #-8]!
    // 0x67b4e8: r0 = getMaxChildIndexForScrollOffset()
    //     0x67b4e8: bl              #0x67a178  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::getMaxChildIndexForScrollOffset
    // 0x67b4ec: add             SP, SP, #0x18
    // 0x67b4f0: mov             x2, x0
    // 0x67b4f4: r0 = BoxInt64Instr(r2)
    //     0x67b4f4: sbfiz           x0, x2, #1, #0x1f
    //     0x67b4f8: cmp             x2, x0, asr #1
    //     0x67b4fc: b.eq            #0x67b508
    //     0x67b500: bl              #0xd69bb8
    //     0x67b504: stur            x2, [x0, #7]
    // 0x67b508: b               #0x67b510
    // 0x67b50c: r0 = Null
    //     0x67b50c: mov             x0, NULL
    // 0x67b510: cmp             w0, NULL
    // 0x67b514: b.eq            #0x67b53c
    // 0x67b518: ldur            x1, [fp, #-0x30]
    // 0x67b51c: r2 = LoadInt32Instr(r0)
    //     0x67b51c: sbfx            x2, x0, #1, #0x1f
    //     0x67b520: tbz             w0, #0, #0x67b528
    //     0x67b524: ldur            x2, [x0, #7]
    // 0x67b528: cmp             x1, x2
    // 0x67b52c: b.lt            #0x67b53c
    // 0x67b530: r1 = true
    //     0x67b530: add             x1, NULL, #0x20  ; true
    // 0x67b534: d1 = 0.000000
    //     0x67b534: eor             v1.16b, v1.16b, v1.16b
    // 0x67b538: b               #0x67b560
    // 0x67b53c: ldur            d0, [fp, #-0x60]
    // 0x67b540: d1 = 0.000000
    //     0x67b540: eor             v1.16b, v1.16b, v1.16b
    // 0x67b544: fcmp            d0, d1
    // 0x67b548: b.vs            #0x67b550
    // 0x67b54c: b.gt            #0x67b558
    // 0x67b550: r0 = false
    //     0x67b550: add             x0, NULL, #0x30  ; false
    // 0x67b554: b               #0x67b55c
    // 0x67b558: r0 = true
    //     0x67b558: add             x0, NULL, #0x20  ; true
    // 0x67b55c: mov             x1, x0
    // 0x67b560: ldr             x0, [fp, #0x10]
    // 0x67b564: ldur            d2, [fp, #-0x78]
    // 0x67b568: ldur            d0, [fp, #-0x70]
    // 0x67b56c: ldur            d3, [fp, #-0x58]
    // 0x67b570: ldur            d4, [fp, #-0x50]
    // 0x67b574: stur            x1, [fp, #-8]
    // 0x67b578: r0 = SliverGeometry()
    //     0x67b578: bl              #0x679334  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x54)
    // 0x67b57c: ldur            d0, [fp, #-0x50]
    // 0x67b580: StoreField: r0->field_7 = d0
    //     0x67b580: stur            d0, [x0, #7]
    // 0x67b584: ldur            d1, [fp, #-0x78]
    // 0x67b588: StoreField: r0->field_17 = d1
    //     0x67b588: stur            d1, [x0, #0x17]
    // 0x67b58c: d2 = 0.000000
    //     0x67b58c: eor             v2.16b, v2.16b, v2.16b
    // 0x67b590: StoreField: r0->field_f = d2
    //     0x67b590: stur            d2, [x0, #0xf]
    // 0x67b594: StoreField: r0->field_27 = d0
    //     0x67b594: stur            d0, [x0, #0x27]
    // 0x67b598: StoreField: r0->field_2f = d2
    //     0x67b598: stur            d2, [x0, #0x2f]
    // 0x67b59c: ldur            x1, [fp, #-8]
    // 0x67b5a0: StoreField: r0->field_43 = r1
    //     0x67b5a0: stur            w1, [x0, #0x43]
    // 0x67b5a4: StoreField: r0->field_1f = d1
    //     0x67b5a4: stur            d1, [x0, #0x1f]
    // 0x67b5a8: StoreField: r0->field_37 = d1
    //     0x67b5a8: stur            d1, [x0, #0x37]
    // 0x67b5ac: ldur            d3, [fp, #-0x70]
    // 0x67b5b0: StoreField: r0->field_4b = d3
    //     0x67b5b0: stur            d3, [x0, #0x4b]
    // 0x67b5b4: fcmp            d1, d2
    // 0x67b5b8: b.vs            #0x67b5c0
    // 0x67b5bc: b.gt            #0x67b5c8
    // 0x67b5c0: r1 = false
    //     0x67b5c0: add             x1, NULL, #0x30  ; false
    // 0x67b5c4: b               #0x67b5cc
    // 0x67b5c8: r1 = true
    //     0x67b5c8: add             x1, NULL, #0x20  ; true
    // 0x67b5cc: StoreField: r0->field_3f = r1
    //     0x67b5cc: stur            w1, [x0, #0x3f]
    // 0x67b5d0: ldr             x1, [fp, #0x10]
    // 0x67b5d4: StoreField: r1->field_4f = r0
    //     0x67b5d4: stur            w0, [x1, #0x4f]
    //     0x67b5d8: ldurb           w16, [x1, #-1]
    //     0x67b5dc: ldurb           w17, [x0, #-1]
    //     0x67b5e0: and             x16, x17, x16, lsr #2
    //     0x67b5e4: tst             x16, HEAP, lsr #32
    //     0x67b5e8: b.eq            #0x67b5f0
    //     0x67b5ec: bl              #0xd6826c
    // 0x67b5f0: ldur            d1, [fp, #-0x58]
    // 0x67b5f4: fcmp            d0, d1
    // 0x67b5f8: b.vs            #0x67b610
    // 0x67b5fc: b.ne            #0x67b610
    // 0x67b600: ldur            x0, [fp, #-0x10]
    // 0x67b604: r1 = true
    //     0x67b604: add             x1, NULL, #0x20  ; true
    // 0x67b608: StoreField: r0->field_53 = r1
    //     0x67b608: stur            w1, [x0, #0x53]
    // 0x67b60c: b               #0x67b614
    // 0x67b610: ldur            x0, [fp, #-0x10]
    // 0x67b614: SaveReg r0
    //     0x67b614: str             x0, [SP, #-8]!
    // 0x67b618: r0 = didFinishLayout()
    //     0x67b618: bl              #0x678c84  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::didFinishLayout
    // 0x67b61c: add             SP, SP, #8
    // 0x67b620: r0 = Null
    //     0x67b620: mov             x0, NULL
    // 0x67b624: LeaveFrame
    //     0x67b624: mov             SP, fp
    //     0x67b628: ldp             fp, lr, [SP], #0x10
    // 0x67b62c: ret
    //     0x67b62c: ret             
    // 0x67b630: r0 = StateError()
    //     0x67b630: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x67b634: mov             x1, x0
    // 0x67b638: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x67b638: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x67b63c: ldr             x0, [x0, #0x1e8]
    // 0x67b640: StoreField: r1->field_b = r0
    //     0x67b640: stur            w0, [x1, #0xb]
    // 0x67b644: mov             x0, x1
    // 0x67b648: r0 = Throw()
    //     0x67b648: bl              #0xd67e38  ; ThrowStub
    // 0x67b64c: brk             #0
    // 0x67b650: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x67b650: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x67b654: b               #0x67a70c
    // 0x67b658: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67b658: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67b65c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67b65c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67b660: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67b660: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67b664: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67b664: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67b668: SaveReg d0
    //     0x67b668: str             q0, [SP, #-0x10]!
    // 0x67b66c: SaveReg r0
    //     0x67b66c: str             x0, [SP, #-8]!
    // 0x67b670: r0 = AllocateDouble()
    //     0x67b670: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67b674: mov             x1, x0
    // 0x67b678: RestoreReg r0
    //     0x67b678: ldr             x0, [SP], #8
    // 0x67b67c: RestoreReg d0
    //     0x67b67c: ldr             q0, [SP], #0x10
    // 0x67b680: b               #0x67a81c
    // 0x67b684: SaveReg d2
    //     0x67b684: str             q2, [SP, #-0x10]!
    // 0x67b688: stp             x0, x1, [SP, #-0x10]!
    // 0x67b68c: r0 = AllocateDouble()
    //     0x67b68c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67b690: mov             x2, x0
    // 0x67b694: ldp             x0, x1, [SP], #0x10
    // 0x67b698: RestoreReg d2
    //     0x67b698: ldr             q2, [SP], #0x10
    // 0x67b69c: b               #0x67a88c
    // 0x67b6a0: SaveReg d0
    //     0x67b6a0: str             q0, [SP, #-0x10]!
    // 0x67b6a4: stp             x0, x1, [SP, #-0x10]!
    // 0x67b6a8: r0 = AllocateDouble()
    //     0x67b6a8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67b6ac: mov             x2, x0
    // 0x67b6b0: ldp             x0, x1, [SP], #0x10
    // 0x67b6b4: RestoreReg d0
    //     0x67b6b4: ldr             q0, [SP], #0x10
    // 0x67b6b8: b               #0x67a8c0
    // 0x67b6bc: stp             q0, q1, [SP, #-0x20]!
    // 0x67b6c0: SaveReg r1
    //     0x67b6c0: str             x1, [SP, #-8]!
    // 0x67b6c4: r0 = AllocateDouble()
    //     0x67b6c4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67b6c8: RestoreReg r1
    //     0x67b6c8: ldr             x1, [SP], #8
    // 0x67b6cc: ldp             q0, q1, [SP], #0x20
    // 0x67b6d0: b               #0x67a93c
    // 0x67b6d4: stp             q0, q1, [SP, #-0x20]!
    // 0x67b6d8: SaveReg r0
    //     0x67b6d8: str             x0, [SP, #-8]!
    // 0x67b6dc: r0 = AllocateDouble()
    //     0x67b6dc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67b6e0: mov             x1, x0
    // 0x67b6e4: RestoreReg r0
    //     0x67b6e4: ldr             x0, [SP], #8
    // 0x67b6e8: ldp             q0, q1, [SP], #0x20
    // 0x67b6ec: b               #0x67a9a0
    // 0x67b6f0: stp             q0, q2, [SP, #-0x20]!
    // 0x67b6f4: stp             x2, x3, [SP, #-0x10]!
    // 0x67b6f8: SaveReg r0
    //     0x67b6f8: str             x0, [SP, #-8]!
    // 0x67b6fc: r0 = AllocateDouble()
    //     0x67b6fc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67b700: mov             x1, x0
    // 0x67b704: RestoreReg r0
    //     0x67b704: ldr             x0, [SP], #8
    // 0x67b708: ldp             x2, x3, [SP], #0x10
    // 0x67b70c: ldp             q0, q2, [SP], #0x20
    // 0x67b710: b               #0x67aae0
    // 0x67b714: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67b714: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67b718: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67b718: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67b71c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67b71c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67b720: r0 = StackOverflowSharedWithFPURegs()
    //     0x67b720: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x67b724: b               #0x67ac94
    // 0x67b728: stp             q0, q1, [SP, #-0x20]!
    // 0x67b72c: SaveReg r0
    //     0x67b72c: str             x0, [SP, #-8]!
    // 0x67b730: r0 = AllocateDouble()
    //     0x67b730: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67b734: mov             x1, x0
    // 0x67b738: RestoreReg r0
    //     0x67b738: ldr             x0, [SP], #8
    // 0x67b73c: ldp             q0, q1, [SP], #0x20
    // 0x67b740: b               #0x67ad24
    // 0x67b744: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67b744: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67b748: stp             q1, q2, [SP, #-0x20]!
    // 0x67b74c: SaveReg r1
    //     0x67b74c: str             x1, [SP, #-8]!
    // 0x67b750: r0 = AllocateDouble()
    //     0x67b750: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67b754: RestoreReg r1
    //     0x67b754: ldr             x1, [SP], #8
    // 0x67b758: ldp             q1, q2, [SP], #0x20
    // 0x67b75c: b               #0x67ae18
    // 0x67b760: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67b760: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67b764: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67b764: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67b768: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67b768: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67b76c: stp             q1, q2, [SP, #-0x20]!
    // 0x67b770: SaveReg r3
    //     0x67b770: str             x3, [SP, #-8]!
    // 0x67b774: r0 = AllocateDouble()
    //     0x67b774: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67b778: RestoreReg r3
    //     0x67b778: ldr             x3, [SP], #8
    // 0x67b77c: ldp             q1, q2, [SP], #0x20
    // 0x67b780: b               #0x67af48
    // 0x67b784: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67b784: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67b788: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67b788: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67b78c: r0 = StackOverflowSharedWithFPURegs()
    //     0x67b78c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x67b790: b               #0x67b010
    // 0x67b794: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67b794: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67b798: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67b798: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67b79c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67b79c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67b7a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67b7a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67b7a4: stp             q1, q2, [SP, #-0x20]!
    // 0x67b7a8: SaveReg r1
    //     0x67b7a8: str             x1, [SP, #-8]!
    // 0x67b7ac: r0 = AllocateDouble()
    //     0x67b7ac: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67b7b0: RestoreReg r1
    //     0x67b7b0: ldr             x1, [SP], #8
    // 0x67b7b4: ldp             q1, q2, [SP], #0x20
    // 0x67b7b8: b               #0x67b1f4
    // 0x67b7bc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67b7bc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67b7c0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67b7c0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67b7c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67b7c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67b7c8: stp             q2, q3, [SP, #-0x20]!
    // 0x67b7cc: SaveReg d1
    //     0x67b7cc: str             q1, [SP, #-0x10]!
    // 0x67b7d0: stp             x2, x4, [SP, #-0x10]!
    // 0x67b7d4: SaveReg r0
    //     0x67b7d4: str             x0, [SP, #-8]!
    // 0x67b7d8: r0 = AllocateDouble()
    //     0x67b7d8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67b7dc: mov             x1, x0
    // 0x67b7e0: RestoreReg r0
    //     0x67b7e0: ldr             x0, [SP], #8
    // 0x67b7e4: ldp             x2, x4, [SP], #0x10
    // 0x67b7e8: RestoreReg d1
    //     0x67b7e8: ldr             q1, [SP], #0x10
    // 0x67b7ec: ldp             q2, q3, [SP], #0x20
    // 0x67b7f0: b               #0x67b318
    // 0x67b7f4: stp             q1, q2, [SP, #-0x20]!
    // 0x67b7f8: SaveReg d0
    //     0x67b7f8: str             q0, [SP, #-0x10]!
    // 0x67b7fc: r0 = AllocateDouble()
    //     0x67b7fc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67b800: RestoreReg d0
    //     0x67b800: ldr             q0, [SP], #0x10
    // 0x67b804: ldp             q1, q2, [SP], #0x20
    // 0x67b808: b               #0x67b3cc
    // 0x67b80c: stp             q2, q3, [SP, #-0x20]!
    // 0x67b810: stp             q0, q1, [SP, #-0x20]!
    // 0x67b814: SaveReg r0
    //     0x67b814: str             x0, [SP, #-8]!
    // 0x67b818: r0 = AllocateDouble()
    //     0x67b818: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67b81c: mov             x1, x0
    // 0x67b820: RestoreReg r0
    //     0x67b820: ldr             x0, [SP], #8
    // 0x67b824: ldp             q0, q1, [SP], #0x20
    // 0x67b828: ldp             q2, q3, [SP], #0x20
    // 0x67b82c: b               #0x67b438
    // 0x67b830: stp             q2, q3, [SP, #-0x20]!
    // 0x67b834: stp             q0, q1, [SP, #-0x20]!
    // 0x67b838: r0 = AllocateDouble()
    //     0x67b838: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67b83c: ldp             q0, q1, [SP], #0x20
    // 0x67b840: ldp             q2, q3, [SP], #0x20
    // 0x67b844: b               #0x67b4d8
  }
  _ _calculateTrailingGarbage(/* No info */) {
    // ** addr: 0x67b848, size: 0xf0
    // 0x67b848: EnterFrame
    //     0x67b848: stp             fp, lr, [SP, #-0x10]!
    //     0x67b84c: mov             fp, SP
    // 0x67b850: AllocStack(0x10)
    //     0x67b850: sub             SP, SP, #0x10
    // 0x67b854: ldr             x0, [fp, #0x18]
    // 0x67b858: LoadField: r1 = r0->field_5f
    //     0x67b858: ldur            w1, [x0, #0x5f]
    // 0x67b85c: DecompressPointer r1
    //     0x67b85c: add             x1, x1, HEAP, lsl #32
    // 0x67b860: mov             x0, x1
    // 0x67b864: ldr             x3, [fp, #0x10]
    // 0x67b868: r4 = 0
    //     0x67b868: mov             x4, #0
    // 0x67b86c: stur            x4, [fp, #-0x10]
    // 0x67b870: CheckStackOverflow
    //     0x67b870: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67b874: cmp             SP, x16
    //     0x67b878: b.ls            #0x67b928
    // 0x67b87c: cmp             w0, NULL
    // 0x67b880: b.eq            #0x67b918
    // 0x67b884: LoadField: r5 = r0->field_17
    //     0x67b884: ldur            w5, [x0, #0x17]
    // 0x67b888: DecompressPointer r5
    //     0x67b888: add             x5, x5, HEAP, lsl #32
    // 0x67b88c: stur            x5, [fp, #-8]
    // 0x67b890: cmp             w5, NULL
    // 0x67b894: b.eq            #0x67b930
    // 0x67b898: mov             x0, x5
    // 0x67b89c: r2 = Null
    //     0x67b89c: mov             x2, NULL
    // 0x67b8a0: r1 = Null
    //     0x67b8a0: mov             x1, NULL
    // 0x67b8a4: r4 = LoadClassIdInstr(r0)
    //     0x67b8a4: ldur            x4, [x0, #-1]
    //     0x67b8a8: ubfx            x4, x4, #0xc, #0x14
    // 0x67b8ac: sub             x4, x4, #0x7f9
    // 0x67b8b0: cmp             x4, #2
    // 0x67b8b4: b.ls            #0x67b8cc
    // 0x67b8b8: r8 = SliverMultiBoxAdaptorParentData
    //     0x67b8b8: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67b8bc: ldr             x8, [x8, #0x120]
    // 0x67b8c0: r3 = Null
    //     0x67b8c0: add             x3, PP, #0x55, lsl #12  ; [pp+0x55c38] Null
    //     0x67b8c4: ldr             x3, [x3, #0xc38]
    // 0x67b8c8: r0 = DefaultTypeTest()
    //     0x67b8c8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67b8cc: ldur            x1, [fp, #-8]
    // 0x67b8d0: LoadField: r2 = r1->field_17
    //     0x67b8d0: ldur            w2, [x1, #0x17]
    // 0x67b8d4: DecompressPointer r2
    //     0x67b8d4: add             x2, x2, HEAP, lsl #32
    // 0x67b8d8: cmp             w2, NULL
    // 0x67b8dc: b.eq            #0x67b934
    // 0x67b8e0: r3 = LoadInt32Instr(r2)
    //     0x67b8e0: sbfx            x3, x2, #1, #0x1f
    //     0x67b8e4: tbz             w2, #0, #0x67b8ec
    //     0x67b8e8: ldur            x3, [x2, #7]
    // 0x67b8ec: ldr             x2, [fp, #0x10]
    // 0x67b8f0: cmp             x3, x2
    // 0x67b8f4: b.le            #0x67b910
    // 0x67b8f8: ldur            x0, [fp, #-0x10]
    // 0x67b8fc: add             x4, x0, #1
    // 0x67b900: LoadField: r0 = r1->field_b
    //     0x67b900: ldur            w0, [x1, #0xb]
    // 0x67b904: DecompressPointer r0
    //     0x67b904: add             x0, x0, HEAP, lsl #32
    // 0x67b908: mov             x3, x2
    // 0x67b90c: b               #0x67b86c
    // 0x67b910: ldur            x0, [fp, #-0x10]
    // 0x67b914: b               #0x67b91c
    // 0x67b918: mov             x0, x4
    // 0x67b91c: LeaveFrame
    //     0x67b91c: mov             SP, fp
    //     0x67b920: ldp             fp, lr, [SP], #0x10
    // 0x67b924: ret
    //     0x67b924: ret             
    // 0x67b928: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x67b928: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x67b92c: b               #0x67b87c
    // 0x67b930: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67b930: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67b934: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67b934: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _calculateLeadingGarbage(/* No info */) {
    // ** addr: 0x67b938, size: 0xf0
    // 0x67b938: EnterFrame
    //     0x67b938: stp             fp, lr, [SP, #-0x10]!
    //     0x67b93c: mov             fp, SP
    // 0x67b940: AllocStack(0x10)
    //     0x67b940: sub             SP, SP, #0x10
    // 0x67b944: ldr             x0, [fp, #0x18]
    // 0x67b948: LoadField: r1 = r0->field_5b
    //     0x67b948: ldur            w1, [x0, #0x5b]
    // 0x67b94c: DecompressPointer r1
    //     0x67b94c: add             x1, x1, HEAP, lsl #32
    // 0x67b950: mov             x0, x1
    // 0x67b954: ldr             x3, [fp, #0x10]
    // 0x67b958: r4 = 0
    //     0x67b958: mov             x4, #0
    // 0x67b95c: stur            x4, [fp, #-0x10]
    // 0x67b960: CheckStackOverflow
    //     0x67b960: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67b964: cmp             SP, x16
    //     0x67b968: b.ls            #0x67ba18
    // 0x67b96c: cmp             w0, NULL
    // 0x67b970: b.eq            #0x67ba08
    // 0x67b974: LoadField: r5 = r0->field_17
    //     0x67b974: ldur            w5, [x0, #0x17]
    // 0x67b978: DecompressPointer r5
    //     0x67b978: add             x5, x5, HEAP, lsl #32
    // 0x67b97c: stur            x5, [fp, #-8]
    // 0x67b980: cmp             w5, NULL
    // 0x67b984: b.eq            #0x67ba20
    // 0x67b988: mov             x0, x5
    // 0x67b98c: r2 = Null
    //     0x67b98c: mov             x2, NULL
    // 0x67b990: r1 = Null
    //     0x67b990: mov             x1, NULL
    // 0x67b994: r4 = LoadClassIdInstr(r0)
    //     0x67b994: ldur            x4, [x0, #-1]
    //     0x67b998: ubfx            x4, x4, #0xc, #0x14
    // 0x67b99c: sub             x4, x4, #0x7f9
    // 0x67b9a0: cmp             x4, #2
    // 0x67b9a4: b.ls            #0x67b9bc
    // 0x67b9a8: r8 = SliverMultiBoxAdaptorParentData
    //     0x67b9a8: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67b9ac: ldr             x8, [x8, #0x120]
    // 0x67b9b0: r3 = Null
    //     0x67b9b0: add             x3, PP, #0x55, lsl #12  ; [pp+0x55c48] Null
    //     0x67b9b4: ldr             x3, [x3, #0xc48]
    // 0x67b9b8: r0 = DefaultTypeTest()
    //     0x67b9b8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67b9bc: ldur            x1, [fp, #-8]
    // 0x67b9c0: LoadField: r2 = r1->field_17
    //     0x67b9c0: ldur            w2, [x1, #0x17]
    // 0x67b9c4: DecompressPointer r2
    //     0x67b9c4: add             x2, x2, HEAP, lsl #32
    // 0x67b9c8: cmp             w2, NULL
    // 0x67b9cc: b.eq            #0x67ba24
    // 0x67b9d0: r3 = LoadInt32Instr(r2)
    //     0x67b9d0: sbfx            x3, x2, #1, #0x1f
    //     0x67b9d4: tbz             w2, #0, #0x67b9dc
    //     0x67b9d8: ldur            x3, [x2, #7]
    // 0x67b9dc: ldr             x2, [fp, #0x10]
    // 0x67b9e0: cmp             x3, x2
    // 0x67b9e4: b.ge            #0x67ba00
    // 0x67b9e8: ldur            x0, [fp, #-0x10]
    // 0x67b9ec: add             x4, x0, #1
    // 0x67b9f0: LoadField: r0 = r1->field_f
    //     0x67b9f0: ldur            w0, [x1, #0xf]
    // 0x67b9f4: DecompressPointer r0
    //     0x67b9f4: add             x0, x0, HEAP, lsl #32
    // 0x67b9f8: mov             x3, x2
    // 0x67b9fc: b               #0x67b95c
    // 0x67ba00: ldur            x0, [fp, #-0x10]
    // 0x67ba04: b               #0x67ba0c
    // 0x67ba08: mov             x0, x4
    // 0x67ba0c: LeaveFrame
    //     0x67ba0c: mov             SP, fp
    //     0x67ba10: ldp             fp, lr, [SP], #0x10
    // 0x67ba14: ret
    //     0x67ba14: ret             
    // 0x67ba18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x67ba18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x67ba1c: b               #0x67b96c
    // 0x67ba20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ba20: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ba24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ba24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// lib: , url: package:flutter/src/rendering/selection.dart

// class id: 1049417, size: 0x8
class :: {
}

// class id: 2001, size: 0x8, field offset: 0x8
abstract class SelectionRegistrar extends Object {
}

// class id: 2005, size: 0x18, field offset: 0x8
//   const constructor, 
class SelectionGeometry extends Object {

  SelectionStatus field_10;
  bool field_14;

  get _ hashCode(/* No info */) {
    // ** addr: 0xb0f4c0, size: 0x68
    // 0xb0f4c0: EnterFrame
    //     0xb0f4c0: stp             fp, lr, [SP, #-0x10]!
    //     0xb0f4c4: mov             fp, SP
    // 0xb0f4c8: CheckStackOverflow
    //     0xb0f4c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0f4cc: cmp             SP, x16
    //     0xb0f4d0: b.ls            #0xb0f520
    // 0xb0f4d4: ldr             x0, [fp, #0x10]
    // 0xb0f4d8: LoadField: r1 = r0->field_f
    //     0xb0f4d8: ldur            w1, [x0, #0xf]
    // 0xb0f4dc: DecompressPointer r1
    //     0xb0f4dc: add             x1, x1, HEAP, lsl #32
    // 0xb0f4e0: LoadField: r2 = r0->field_13
    //     0xb0f4e0: ldur            w2, [x0, #0x13]
    // 0xb0f4e4: DecompressPointer r2
    //     0xb0f4e4: add             x2, x2, HEAP, lsl #32
    // 0xb0f4e8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb0f4ec: stp             x2, x1, [SP, #-0x10]!
    // 0xb0f4f0: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0xb0f4f0: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0xb0f4f4: r0 = hash()
    //     0xb0f4f4: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0f4f8: add             SP, SP, #0x20
    // 0xb0f4fc: mov             x2, x0
    // 0xb0f500: r0 = BoxInt64Instr(r2)
    //     0xb0f500: sbfiz           x0, x2, #1, #0x1f
    //     0xb0f504: cmp             x2, x0, asr #1
    //     0xb0f508: b.eq            #0xb0f514
    //     0xb0f50c: bl              #0xd69bb8
    //     0xb0f510: stur            x2, [x0, #7]
    // 0xb0f514: LeaveFrame
    //     0xb0f514: mov             SP, fp
    //     0xb0f518: ldp             fp, lr, [SP], #0x10
    // 0xb0f51c: ret
    //     0xb0f51c: ret             
    // 0xb0f520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0f520: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0f524: b               #0xb0f4d4
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9f2e0, size: 0x12c
    // 0xc9f2e0: EnterFrame
    //     0xc9f2e0: stp             fp, lr, [SP, #-0x10]!
    //     0xc9f2e4: mov             fp, SP
    // 0xc9f2e8: CheckStackOverflow
    //     0xc9f2e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc9f2ec: cmp             SP, x16
    //     0xc9f2f0: b.ls            #0xc9f404
    // 0xc9f2f4: ldr             x1, [fp, #0x10]
    // 0xc9f2f8: cmp             w1, NULL
    // 0xc9f2fc: b.ne            #0xc9f310
    // 0xc9f300: r0 = false
    //     0xc9f300: add             x0, NULL, #0x30  ; false
    // 0xc9f304: LeaveFrame
    //     0xc9f304: mov             SP, fp
    //     0xc9f308: ldp             fp, lr, [SP], #0x10
    // 0xc9f30c: ret
    //     0xc9f30c: ret             
    // 0xc9f310: ldr             x2, [fp, #0x18]
    // 0xc9f314: cmp             w2, w1
    // 0xc9f318: b.ne            #0xc9f32c
    // 0xc9f31c: r0 = true
    //     0xc9f31c: add             x0, NULL, #0x20  ; true
    // 0xc9f320: LeaveFrame
    //     0xc9f320: mov             SP, fp
    //     0xc9f324: ldp             fp, lr, [SP], #0x10
    // 0xc9f328: ret
    //     0xc9f328: ret             
    // 0xc9f32c: r0 = 59
    //     0xc9f32c: mov             x0, #0x3b
    // 0xc9f330: branchIfSmi(r1, 0xc9f33c)
    //     0xc9f330: tbz             w1, #0, #0xc9f33c
    // 0xc9f334: r0 = LoadClassIdInstr(r1)
    //     0xc9f334: ldur            x0, [x1, #-1]
    //     0xc9f338: ubfx            x0, x0, #0xc, #0x14
    // 0xc9f33c: SaveReg r1
    //     0xc9f33c: str             x1, [SP, #-8]!
    // 0xc9f340: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc9f340: mov             x17, #0x57c5
    //     0xc9f344: add             lr, x0, x17
    //     0xc9f348: ldr             lr, [x21, lr, lsl #3]
    //     0xc9f34c: blr             lr
    // 0xc9f350: add             SP, SP, #8
    // 0xc9f354: r1 = LoadClassIdInstr(r0)
    //     0xc9f354: ldur            x1, [x0, #-1]
    //     0xc9f358: ubfx            x1, x1, #0xc, #0x14
    // 0xc9f35c: r16 = SelectionGeometry
    //     0xc9f35c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21a98] Type: SelectionGeometry
    //     0xc9f360: ldr             x16, [x16, #0xa98]
    // 0xc9f364: stp             x16, x0, [SP, #-0x10]!
    // 0xc9f368: mov             x0, x1
    // 0xc9f36c: mov             lr, x0
    // 0xc9f370: ldr             lr, [x21, lr, lsl #3]
    // 0xc9f374: blr             lr
    // 0xc9f378: add             SP, SP, #0x10
    // 0xc9f37c: tbz             w0, #4, #0xc9f390
    // 0xc9f380: r0 = false
    //     0xc9f380: add             x0, NULL, #0x30  ; false
    // 0xc9f384: LeaveFrame
    //     0xc9f384: mov             SP, fp
    //     0xc9f388: ldp             fp, lr, [SP], #0x10
    // 0xc9f38c: ret
    //     0xc9f38c: ret             
    // 0xc9f390: ldr             x1, [fp, #0x10]
    // 0xc9f394: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc9f394: mov             x2, #0x76
    //     0xc9f398: tbz             w1, #0, #0xc9f3a8
    //     0xc9f39c: ldur            x2, [x1, #-1]
    //     0xc9f3a0: ubfx            x2, x2, #0xc, #0x14
    //     0xc9f3a4: lsl             x2, x2, #1
    // 0xc9f3a8: cmp             w2, #0xfaa
    // 0xc9f3ac: b.ne            #0xc9f3f4
    // 0xc9f3b0: ldr             x2, [fp, #0x18]
    // 0xc9f3b4: LoadField: r3 = r1->field_f
    //     0xc9f3b4: ldur            w3, [x1, #0xf]
    // 0xc9f3b8: DecompressPointer r3
    //     0xc9f3b8: add             x3, x3, HEAP, lsl #32
    // 0xc9f3bc: LoadField: r4 = r2->field_f
    //     0xc9f3bc: ldur            w4, [x2, #0xf]
    // 0xc9f3c0: DecompressPointer r4
    //     0xc9f3c0: add             x4, x4, HEAP, lsl #32
    // 0xc9f3c4: cmp             w3, w4
    // 0xc9f3c8: b.ne            #0xc9f3f4
    // 0xc9f3cc: LoadField: r3 = r1->field_13
    //     0xc9f3cc: ldur            w3, [x1, #0x13]
    // 0xc9f3d0: DecompressPointer r3
    //     0xc9f3d0: add             x3, x3, HEAP, lsl #32
    // 0xc9f3d4: LoadField: r1 = r2->field_13
    //     0xc9f3d4: ldur            w1, [x2, #0x13]
    // 0xc9f3d8: DecompressPointer r1
    //     0xc9f3d8: add             x1, x1, HEAP, lsl #32
    // 0xc9f3dc: cmp             w3, w1
    // 0xc9f3e0: r16 = true
    //     0xc9f3e0: add             x16, NULL, #0x20  ; true
    // 0xc9f3e4: r17 = false
    //     0xc9f3e4: add             x17, NULL, #0x30  ; false
    // 0xc9f3e8: csel            x2, x16, x17, eq
    // 0xc9f3ec: mov             x0, x2
    // 0xc9f3f0: b               #0xc9f3f8
    // 0xc9f3f4: r0 = false
    //     0xc9f3f4: add             x0, NULL, #0x30  ; false
    // 0xc9f3f8: LeaveFrame
    //     0xc9f3f8: mov             SP, fp
    //     0xc9f3fc: ldp             fp, lr, [SP], #0x10
    // 0xc9f400: ret
    //     0xc9f400: ret             
    // 0xc9f404: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc9f404: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc9f408: b               #0xc9f2f4
  }
}

// class id: 2006, size: 0x8, field offset: 0x8
abstract class SelectionHandler extends Object
    implements ValueListenable<X0> {
}

// class id: 2009, size: 0x8, field offset: 0x8
abstract class Selectable extends Object
    implements SelectionHandler {
}

// class id: 2010, size: 0x8, field offset: 0x8
abstract class SelectionRegistrant extends Selectable {
}

// class id: 5912, size: 0x14, field offset: 0x14
enum TextSelectionHandleType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16f3c, size: 0x5c
    // 0xb16f3c: EnterFrame
    //     0xb16f3c: stp             fp, lr, [SP, #-0x10]!
    //     0xb16f40: mov             fp, SP
    // 0xb16f44: CheckStackOverflow
    //     0xb16f44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16f48: cmp             SP, x16
    //     0xb16f4c: b.ls            #0xb16f90
    // 0xb16f50: r1 = Null
    //     0xb16f50: mov             x1, NULL
    // 0xb16f54: r2 = 4
    //     0xb16f54: mov             x2, #4
    // 0xb16f58: r0 = AllocateArray()
    //     0xb16f58: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16f5c: r17 = "TextSelectionHandleType."
    //     0xb16f5c: add             x17, PP, #0x28, lsl #12  ; [pp+0x28540] "TextSelectionHandleType."
    //     0xb16f60: ldr             x17, [x17, #0x540]
    // 0xb16f64: StoreField: r0->field_f = r17
    //     0xb16f64: stur            w17, [x0, #0xf]
    // 0xb16f68: ldr             x1, [fp, #0x10]
    // 0xb16f6c: LoadField: r2 = r1->field_f
    //     0xb16f6c: ldur            w2, [x1, #0xf]
    // 0xb16f70: DecompressPointer r2
    //     0xb16f70: add             x2, x2, HEAP, lsl #32
    // 0xb16f74: StoreField: r0->field_13 = r2
    //     0xb16f74: stur            w2, [x0, #0x13]
    // 0xb16f78: SaveReg r0
    //     0xb16f78: str             x0, [SP, #-8]!
    // 0xb16f7c: r0 = _interpolate()
    //     0xb16f7c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16f80: add             SP, SP, #8
    // 0xb16f84: LeaveFrame
    //     0xb16f84: mov             SP, fp
    //     0xb16f88: ldp             fp, lr, [SP], #0x10
    // 0xb16f8c: ret
    //     0xb16f8c: ret             
    // 0xb16f90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16f90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16f94: b               #0xb16f50
  }
}

// class id: 5913, size: 0x14, field offset: 0x14
enum SelectionStatus extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16ee0, size: 0x5c
    // 0xb16ee0: EnterFrame
    //     0xb16ee0: stp             fp, lr, [SP, #-0x10]!
    //     0xb16ee4: mov             fp, SP
    // 0xb16ee8: CheckStackOverflow
    //     0xb16ee8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16eec: cmp             SP, x16
    //     0xb16ef0: b.ls            #0xb16f34
    // 0xb16ef4: r1 = Null
    //     0xb16ef4: mov             x1, NULL
    // 0xb16ef8: r2 = 4
    //     0xb16ef8: mov             x2, #4
    // 0xb16efc: r0 = AllocateArray()
    //     0xb16efc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16f00: r17 = "SelectionStatus."
    //     0xb16f00: add             x17, PP, #0x21, lsl #12  ; [pp+0x21aa0] "SelectionStatus."
    //     0xb16f04: ldr             x17, [x17, #0xaa0]
    // 0xb16f08: StoreField: r0->field_f = r17
    //     0xb16f08: stur            w17, [x0, #0xf]
    // 0xb16f0c: ldr             x1, [fp, #0x10]
    // 0xb16f10: LoadField: r2 = r1->field_f
    //     0xb16f10: ldur            w2, [x1, #0xf]
    // 0xb16f14: DecompressPointer r2
    //     0xb16f14: add             x2, x2, HEAP, lsl #32
    // 0xb16f18: StoreField: r0->field_13 = r2
    //     0xb16f18: stur            w2, [x0, #0x13]
    // 0xb16f1c: SaveReg r0
    //     0xb16f1c: str             x0, [SP, #-8]!
    // 0xb16f20: r0 = _interpolate()
    //     0xb16f20: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16f24: add             SP, SP, #8
    // 0xb16f28: LeaveFrame
    //     0xb16f28: mov             SP, fp
    //     0xb16f2c: ldp             fp, lr, [SP], #0x10
    // 0xb16f30: ret
    //     0xb16f30: ret             
    // 0xb16f34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16f34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16f38: b               #0xb16ef4
  }
}

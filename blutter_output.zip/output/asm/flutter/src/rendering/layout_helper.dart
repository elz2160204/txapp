// lib: , url: package:flutter/src/rendering/layout_helper.dart

// class id: 1049406, size: 0x8
class :: {
}

// class id: 2025, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class ChildLayoutHelper extends Object {

  [closure] static Size dryLayoutChild(dynamic, RenderBox, BoxConstraints) {
    // ** addr: 0x633c20, size: 0x3c
    // 0x633c20: EnterFrame
    //     0x633c20: stp             fp, lr, [SP, #-0x10]!
    //     0x633c24: mov             fp, SP
    // 0x633c28: CheckStackOverflow
    //     0x633c28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x633c2c: cmp             SP, x16
    //     0x633c30: b.ls            #0x633c54
    // 0x633c34: ldr             x16, [fp, #0x18]
    // 0x633c38: ldr             lr, [fp, #0x10]
    // 0x633c3c: stp             lr, x16, [SP, #-0x10]!
    // 0x633c40: r0 = getDryLayout()
    //     0x633c40: bl              #0x62d394  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0x633c44: add             SP, SP, #0x10
    // 0x633c48: LeaveFrame
    //     0x633c48: mov             SP, fp
    //     0x633c4c: ldp             fp, lr, [SP], #0x10
    // 0x633c50: ret
    //     0x633c50: ret             
    // 0x633c54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x633c54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x633c58: b               #0x633c34
  }
  [closure] static Size layoutChild(dynamic, RenderBox, BoxConstraints) {
    // ** addr: 0x68aefc, size: 0x3c
    // 0x68aefc: EnterFrame
    //     0x68aefc: stp             fp, lr, [SP, #-0x10]!
    //     0x68af00: mov             fp, SP
    // 0x68af04: CheckStackOverflow
    //     0x68af04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68af08: cmp             SP, x16
    //     0x68af0c: b.ls            #0x68af30
    // 0x68af10: ldr             x16, [fp, #0x18]
    // 0x68af14: ldr             lr, [fp, #0x10]
    // 0x68af18: stp             lr, x16, [SP, #-0x10]!
    // 0x68af1c: r0 = layoutChild()
    //     0x68af1c: bl              #0x68af38  ; [package:flutter/src/rendering/layout_helper.dart] ChildLayoutHelper::layoutChild
    // 0x68af20: add             SP, SP, #0x10
    // 0x68af24: LeaveFrame
    //     0x68af24: mov             SP, fp
    //     0x68af28: ldp             fp, lr, [SP], #0x10
    // 0x68af2c: ret
    //     0x68af2c: ret             
    // 0x68af30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68af30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68af34: b               #0x68af10
  }
  static _ layoutChild(/* No info */) {
    // ** addr: 0x68af38, size: 0x78
    // 0x68af38: EnterFrame
    //     0x68af38: stp             fp, lr, [SP, #-0x10]!
    //     0x68af3c: mov             fp, SP
    // 0x68af40: CheckStackOverflow
    //     0x68af40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68af44: cmp             SP, x16
    //     0x68af48: b.ls            #0x68afa4
    // 0x68af4c: ldr             x1, [fp, #0x18]
    // 0x68af50: r0 = LoadClassIdInstr(r1)
    //     0x68af50: ldur            x0, [x1, #-1]
    //     0x68af54: ubfx            x0, x0, #0xc, #0x14
    // 0x68af58: ldr             x16, [fp, #0x10]
    // 0x68af5c: stp             x16, x1, [SP, #-0x10]!
    // 0x68af60: r16 = true
    //     0x68af60: add             x16, NULL, #0x20  ; true
    // 0x68af64: SaveReg r16
    //     0x68af64: str             x16, [SP, #-8]!
    // 0x68af68: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x68af68: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x68af6c: ldr             x4, [x4, #0x1c8]
    // 0x68af70: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x68af70: mov             x17, #0xcdfb
    //     0x68af74: add             lr, x0, x17
    //     0x68af78: ldr             lr, [x21, lr, lsl #3]
    //     0x68af7c: blr             lr
    // 0x68af80: add             SP, SP, #0x18
    // 0x68af84: ldr             x1, [fp, #0x18]
    // 0x68af88: LoadField: r0 = r1->field_57
    //     0x68af88: ldur            w0, [x1, #0x57]
    // 0x68af8c: DecompressPointer r0
    //     0x68af8c: add             x0, x0, HEAP, lsl #32
    // 0x68af90: cmp             w0, NULL
    // 0x68af94: b.eq            #0x68afac
    // 0x68af98: LeaveFrame
    //     0x68af98: mov             SP, fp
    //     0x68af9c: ldp             fp, lr, [SP], #0x10
    // 0x68afa0: ret
    //     0x68afa0: ret             
    // 0x68afa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68afa4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68afa8: b               #0x68af4c
    // 0x68afac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68afac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// lib: , url: package:flutter/src/rendering/sliver_persistent_header.dart

// class id: 1049427, size: 0x8
class :: {

  static _ _trim(/* No info */) {
    // ** addr: 0x642ac4, size: 0x1e4
    // 0x642ac4: EnterFrame
    //     0x642ac4: stp             fp, lr, [SP, #-0x10]!
    //     0x642ac8: mov             fp, SP
    // 0x642acc: AllocStack(0x28)
    //     0x642acc: sub             SP, SP, #0x28
    // 0x642ad0: SetupParameters(dynamic _ /* r3, fp-0x8 */, {_Double bottom = inf /* d0, fp-0x28 */, _Double left = -inf /* d1, fp-0x20 */, _Double right = inf /* d2, fp-0x18 */, _Double top = -inf /* d3, fp-0x10 */})
    //     0x642ad0: mov             x0, x4
    //     0x642ad4: ldur            w1, [x0, #0x13]
    //     0x642ad8: add             x1, x1, HEAP, lsl #32
    //     0x642adc: sub             x2, x1, #2
    //     0x642ae0: add             x3, fp, w2, sxtw #2
    //     0x642ae4: ldr             x3, [x3, #0x10]
    //     0x642ae8: stur            x3, [fp, #-8]
    //     0x642aec: ldur            w2, [x0, #0x1f]
    //     0x642af0: add             x2, x2, HEAP, lsl #32
    //     0x642af4: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fbe8] "bottom"
    //     0x642af8: ldr             x16, [x16, #0xbe8]
    //     0x642afc: cmp             w2, w16
    //     0x642b00: b.ne            #0x642b24
    //     0x642b04: ldur            w2, [x0, #0x23]
    //     0x642b08: add             x2, x2, HEAP, lsl #32
    //     0x642b0c: sub             w4, w1, w2
    //     0x642b10: add             x2, fp, w4, sxtw #2
    //     0x642b14: ldr             x2, [x2, #8]
    //     0x642b18: ldur            d0, [x2, #7]
    //     0x642b1c: mov             x2, #1
    //     0x642b20: b               #0x642b2c
    //     0x642b24: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    //     0x642b28: mov             x2, #0
    //     0x642b2c: stur            d0, [fp, #-0x28]
    //     0x642b30: lsl             x4, x2, #1
    //     0x642b34: lsl             w5, w4, #1
    //     0x642b38: add             w6, w5, #8
    //     0x642b3c: add             x16, x0, w6, sxtw #1
    //     0x642b40: ldur            w7, [x16, #0xf]
    //     0x642b44: add             x7, x7, HEAP, lsl #32
    //     0x642b48: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fbf0] "left"
    //     0x642b4c: ldr             x16, [x16, #0xbf0]
    //     0x642b50: cmp             w7, w16
    //     0x642b54: b.ne            #0x642b88
    //     0x642b58: add             w2, w5, #0xa
    //     0x642b5c: add             x16, x0, w2, sxtw #1
    //     0x642b60: ldur            w5, [x16, #0xf]
    //     0x642b64: add             x5, x5, HEAP, lsl #32
    //     0x642b68: sub             w2, w1, w5
    //     0x642b6c: add             x5, fp, w2, sxtw #2
    //     0x642b70: ldr             x5, [x5, #8]
    //     0x642b74: add             w2, w4, #2
    //     0x642b78: ldur            d1, [x5, #7]
    //     0x642b7c: sbfx            x4, x2, #1, #0x1f
    //     0x642b80: mov             x2, x4
    //     0x642b84: b               #0x642b8c
    //     0x642b88: ldr             d1, [PP, #0x22c8]  ; [pp+0x22c8] IMM: double(-inf) from 0xfff0000000000000
    //     0x642b8c: stur            d1, [fp, #-0x20]
    //     0x642b90: lsl             x4, x2, #1
    //     0x642b94: lsl             w5, w4, #1
    //     0x642b98: add             w6, w5, #8
    //     0x642b9c: add             x16, x0, w6, sxtw #1
    //     0x642ba0: ldur            w7, [x16, #0xf]
    //     0x642ba4: add             x7, x7, HEAP, lsl #32
    //     0x642ba8: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fbf8] "right"
    //     0x642bac: ldr             x16, [x16, #0xbf8]
    //     0x642bb0: cmp             w7, w16
    //     0x642bb4: b.ne            #0x642be8
    //     0x642bb8: add             w2, w5, #0xa
    //     0x642bbc: add             x16, x0, w2, sxtw #1
    //     0x642bc0: ldur            w5, [x16, #0xf]
    //     0x642bc4: add             x5, x5, HEAP, lsl #32
    //     0x642bc8: sub             w2, w1, w5
    //     0x642bcc: add             x5, fp, w2, sxtw #2
    //     0x642bd0: ldr             x5, [x5, #8]
    //     0x642bd4: add             w2, w4, #2
    //     0x642bd8: ldur            d2, [x5, #7]
    //     0x642bdc: sbfx            x4, x2, #1, #0x1f
    //     0x642be0: mov             x2, x4
    //     0x642be4: b               #0x642bec
    //     0x642be8: ldr             d2, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    //     0x642bec: stur            d2, [fp, #-0x18]
    //     0x642bf0: lsl             x4, x2, #1
    //     0x642bf4: lsl             w2, w4, #1
    //     0x642bf8: add             w4, w2, #8
    //     0x642bfc: add             x16, x0, w4, sxtw #1
    //     0x642c00: ldur            w5, [x16, #0xf]
    //     0x642c04: add             x5, x5, HEAP, lsl #32
    //     0x642c08: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fc00] "top"
    //     0x642c0c: ldr             x16, [x16, #0xc00]
    //     0x642c10: cmp             w5, w16
    //     0x642c14: b.ne            #0x642c3c
    //     0x642c18: add             w4, w2, #0xa
    //     0x642c1c: add             x16, x0, w4, sxtw #1
    //     0x642c20: ldur            w2, [x16, #0xf]
    //     0x642c24: add             x2, x2, HEAP, lsl #32
    //     0x642c28: sub             w0, w1, w2
    //     0x642c2c: add             x1, fp, w0, sxtw #2
    //     0x642c30: ldr             x1, [x1, #8]
    //     0x642c34: ldur            d3, [x1, #7]
    //     0x642c38: b               #0x642c40
    //     0x642c3c: ldr             d3, [PP, #0x22c8]  ; [pp+0x22c8] IMM: double(-inf) from 0xfff0000000000000
    //     0x642c40: stur            d3, [fp, #-0x10]
    // 0x642c44: CheckStackOverflow
    //     0x642c44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x642c48: cmp             SP, x16
    //     0x642c4c: b.ls            #0x642ca0
    // 0x642c50: cmp             w3, NULL
    // 0x642c54: b.ne            #0x642c60
    // 0x642c58: r0 = Null
    //     0x642c58: mov             x0, NULL
    // 0x642c5c: b               #0x642c94
    // 0x642c60: r0 = Rect()
    //     0x642c60: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x642c64: ldur            d0, [fp, #-0x20]
    // 0x642c68: StoreField: r0->field_7 = d0
    //     0x642c68: stur            d0, [x0, #7]
    // 0x642c6c: ldur            d0, [fp, #-0x10]
    // 0x642c70: StoreField: r0->field_f = d0
    //     0x642c70: stur            d0, [x0, #0xf]
    // 0x642c74: ldur            d0, [fp, #-0x18]
    // 0x642c78: StoreField: r0->field_17 = d0
    //     0x642c78: stur            d0, [x0, #0x17]
    // 0x642c7c: ldur            d0, [fp, #-0x28]
    // 0x642c80: StoreField: r0->field_1f = d0
    //     0x642c80: stur            d0, [x0, #0x1f]
    // 0x642c84: ldur            x16, [fp, #-8]
    // 0x642c88: stp             x0, x16, [SP, #-0x10]!
    // 0x642c8c: r0 = intersect()
    //     0x642c8c: bl              #0x642ca8  ; [dart:ui] Rect::intersect
    // 0x642c90: add             SP, SP, #0x10
    // 0x642c94: LeaveFrame
    //     0x642c94: mov             SP, fp
    //     0x642c98: ldp             fp, lr, [SP], #0x10
    // 0x642c9c: ret
    //     0x642c9c: ret             
    // 0x642ca0: r0 = StackOverflowSharedWithFPURegs()
    //     0x642ca0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x642ca4: b               #0x642c50
  }
}

// class id: 2550, size: 0x58, field offset: 0x54
//   transformed mixin,
abstract class _RenderSliverPersistentHeader&RenderSliver&RenderObjectWithChildMixin extends RenderSliver
     with RenderObjectWithChildMixin<X0 bound RenderObject> {

  _ visitChildren(/* No info */) {
    // ** addr: 0x6bf580, size: 0x5c
    // 0x6bf580: EnterFrame
    //     0x6bf580: stp             fp, lr, [SP, #-0x10]!
    //     0x6bf584: mov             fp, SP
    // 0x6bf588: CheckStackOverflow
    //     0x6bf588: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bf58c: cmp             SP, x16
    //     0x6bf590: b.ls            #0x6bf5d4
    // 0x6bf594: ldr             x0, [fp, #0x18]
    // 0x6bf598: LoadField: r1 = r0->field_53
    //     0x6bf598: ldur            w1, [x0, #0x53]
    // 0x6bf59c: DecompressPointer r1
    //     0x6bf59c: add             x1, x1, HEAP, lsl #32
    // 0x6bf5a0: cmp             w1, NULL
    // 0x6bf5a4: b.eq            #0x6bf5c4
    // 0x6bf5a8: ldr             x16, [fp, #0x10]
    // 0x6bf5ac: stp             x1, x16, [SP, #-0x10]!
    // 0x6bf5b0: ldr             x0, [fp, #0x10]
    // 0x6bf5b4: ClosureCall
    //     0x6bf5b4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6bf5b8: ldur            x2, [x0, #0x1f]
    //     0x6bf5bc: blr             x2
    // 0x6bf5c0: add             SP, SP, #0x10
    // 0x6bf5c4: r0 = Null
    //     0x6bf5c4: mov             x0, NULL
    // 0x6bf5c8: LeaveFrame
    //     0x6bf5c8: mov             SP, fp
    //     0x6bf5cc: ldp             fp, lr, [SP], #0x10
    // 0x6bf5d0: ret
    //     0x6bf5d0: ret             
    // 0x6bf5d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bf5d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bf5d8: b               #0x6bf594
  }
  set _ child=(/* No info */) {
    // ** addr: 0x6e7ce0, size: 0xc0
    // 0x6e7ce0: EnterFrame
    //     0x6e7ce0: stp             fp, lr, [SP, #-0x10]!
    //     0x6e7ce4: mov             fp, SP
    // 0x6e7ce8: CheckStackOverflow
    //     0x6e7ce8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e7cec: cmp             SP, x16
    //     0x6e7cf0: b.ls            #0x6e7d98
    // 0x6e7cf4: ldr             x0, [fp, #0x10]
    // 0x6e7cf8: r2 = Null
    //     0x6e7cf8: mov             x2, NULL
    // 0x6e7cfc: r1 = Null
    //     0x6e7cfc: mov             x1, NULL
    // 0x6e7d00: r4 = 59
    //     0x6e7d00: mov             x4, #0x3b
    // 0x6e7d04: branchIfSmi(r0, 0x6e7d10)
    //     0x6e7d04: tbz             w0, #0, #0x6e7d10
    // 0x6e7d08: r4 = LoadClassIdInstr(r0)
    //     0x6e7d08: ldur            x4, [x0, #-1]
    //     0x6e7d0c: ubfx            x4, x4, #0xc, #0x14
    // 0x6e7d10: sub             x4, x4, #0x965
    // 0x6e7d14: cmp             x4, #0x8b
    // 0x6e7d18: b.ls            #0x6e7d2c
    // 0x6e7d1c: r8 = RenderBox?
    //     0x6e7d1c: ldr             x8, [PP, #0x4de8]  ; [pp+0x4de8] Type: RenderBox?
    // 0x6e7d20: r3 = Null
    //     0x6e7d20: add             x3, PP, #0x29, lsl #12  ; [pp+0x29130] Null
    //     0x6e7d24: ldr             x3, [x3, #0x130]
    // 0x6e7d28: r0 = RenderBox?()
    //     0x6e7d28: bl              #0x5ad534  ; IsType_RenderBox?_Stub
    // 0x6e7d2c: ldr             x0, [fp, #0x18]
    // 0x6e7d30: LoadField: r1 = r0->field_53
    //     0x6e7d30: ldur            w1, [x0, #0x53]
    // 0x6e7d34: DecompressPointer r1
    //     0x6e7d34: add             x1, x1, HEAP, lsl #32
    // 0x6e7d38: cmp             w1, NULL
    // 0x6e7d3c: b.eq            #0x6e7d4c
    // 0x6e7d40: stp             x1, x0, [SP, #-0x10]!
    // 0x6e7d44: r0 = dropChild()
    //     0x6e7d44: bl              #0x5e5aec  ; [package:flutter/src/rendering/object.dart] RenderObject::dropChild
    // 0x6e7d48: add             SP, SP, #0x10
    // 0x6e7d4c: ldr             x1, [fp, #0x18]
    // 0x6e7d50: ldr             x2, [fp, #0x10]
    // 0x6e7d54: mov             x0, x2
    // 0x6e7d58: StoreField: r1->field_53 = r0
    //     0x6e7d58: stur            w0, [x1, #0x53]
    //     0x6e7d5c: ldurb           w16, [x1, #-1]
    //     0x6e7d60: ldurb           w17, [x0, #-1]
    //     0x6e7d64: and             x16, x17, x16, lsr #2
    //     0x6e7d68: tst             x16, HEAP, lsr #32
    //     0x6e7d6c: b.eq            #0x6e7d74
    //     0x6e7d70: bl              #0xd6826c
    // 0x6e7d74: cmp             w2, NULL
    // 0x6e7d78: b.eq            #0x6e7d88
    // 0x6e7d7c: stp             x2, x1, [SP, #-0x10]!
    // 0x6e7d80: r0 = adoptChild()
    //     0x6e7d80: bl              #0x5e61d4  ; [package:flutter/src/rendering/object.dart] RenderObject::adoptChild
    // 0x6e7d84: add             SP, SP, #0x10
    // 0x6e7d88: r0 = Null
    //     0x6e7d88: mov             x0, NULL
    // 0x6e7d8c: LeaveFrame
    //     0x6e7d8c: mov             SP, fp
    //     0x6e7d90: ldp             fp, lr, [SP], #0x10
    // 0x6e7d94: ret
    //     0x6e7d94: ret             
    // 0x6e7d98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e7d98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e7d9c: b               #0x6e7cf4
  }
  _ redepthChildren(/* No info */) {
    // ** addr: 0x7927f4, size: 0x4c
    // 0x7927f4: EnterFrame
    //     0x7927f4: stp             fp, lr, [SP, #-0x10]!
    //     0x7927f8: mov             fp, SP
    // 0x7927fc: CheckStackOverflow
    //     0x7927fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x792800: cmp             SP, x16
    //     0x792804: b.ls            #0x792838
    // 0x792808: ldr             x0, [fp, #0x10]
    // 0x79280c: LoadField: r1 = r0->field_53
    //     0x79280c: ldur            w1, [x0, #0x53]
    // 0x792810: DecompressPointer r1
    //     0x792810: add             x1, x1, HEAP, lsl #32
    // 0x792814: cmp             w1, NULL
    // 0x792818: b.eq            #0x792828
    // 0x79281c: stp             x1, x0, [SP, #-0x10]!
    // 0x792820: r0 = redepthChild()
    //     0x792820: bl              #0x5e631c  ; [package:flutter/src/foundation/node.dart] AbstractNode::redepthChild
    // 0x792824: add             SP, SP, #0x10
    // 0x792828: r0 = Null
    //     0x792828: mov             x0, NULL
    // 0x79282c: LeaveFrame
    //     0x79282c: mov             SP, fp
    //     0x792830: ldp             fp, lr, [SP], #0x10
    // 0x792834: ret
    //     0x792834: ret             
    // 0x792838: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x792838: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79283c: b               #0x792808
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bc2cc, size: 0xac
    // 0x9bc2cc: EnterFrame
    //     0x9bc2cc: stp             fp, lr, [SP, #-0x10]!
    //     0x9bc2d0: mov             fp, SP
    // 0x9bc2d4: CheckStackOverflow
    //     0x9bc2d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bc2d8: cmp             SP, x16
    //     0x9bc2dc: b.ls            #0x9bc370
    // 0x9bc2e0: ldr             x0, [fp, #0x10]
    // 0x9bc2e4: r2 = Null
    //     0x9bc2e4: mov             x2, NULL
    // 0x9bc2e8: r1 = Null
    //     0x9bc2e8: mov             x1, NULL
    // 0x9bc2ec: r4 = 59
    //     0x9bc2ec: mov             x4, #0x3b
    // 0x9bc2f0: branchIfSmi(r0, 0x9bc2fc)
    //     0x9bc2f0: tbz             w0, #0, #0x9bc2fc
    // 0x9bc2f4: r4 = LoadClassIdInstr(r0)
    //     0x9bc2f4: ldur            x4, [x0, #-1]
    //     0x9bc2f8: ubfx            x4, x4, #0xc, #0x14
    // 0x9bc2fc: cmp             x4, #0x7e6
    // 0x9bc300: b.eq            #0x9bc314
    // 0x9bc304: r8 = PipelineOwner
    //     0x9bc304: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9bc308: r3 = Null
    //     0x9bc308: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2d580] Null
    //     0x9bc30c: ldr             x3, [x3, #0x580]
    // 0x9bc310: r0 = DefaultTypeTest()
    //     0x9bc310: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bc314: ldr             x16, [fp, #0x18]
    // 0x9bc318: ldr             lr, [fp, #0x10]
    // 0x9bc31c: stp             lr, x16, [SP, #-0x10]!
    // 0x9bc320: r0 = attach()
    //     0x9bc320: bl              #0x9bf794  ; [package:flutter/src/rendering/object.dart] RenderObject::attach
    // 0x9bc324: add             SP, SP, #0x10
    // 0x9bc328: ldr             x0, [fp, #0x18]
    // 0x9bc32c: LoadField: r1 = r0->field_53
    //     0x9bc32c: ldur            w1, [x0, #0x53]
    // 0x9bc330: DecompressPointer r1
    //     0x9bc330: add             x1, x1, HEAP, lsl #32
    // 0x9bc334: cmp             w1, NULL
    // 0x9bc338: b.eq            #0x9bc360
    // 0x9bc33c: r0 = LoadClassIdInstr(r1)
    //     0x9bc33c: ldur            x0, [x1, #-1]
    //     0x9bc340: ubfx            x0, x0, #0xc, #0x14
    // 0x9bc344: ldr             x16, [fp, #0x10]
    // 0x9bc348: stp             x16, x1, [SP, #-0x10]!
    // 0x9bc34c: r0 = GDT[cid_x0 + 0xaf1f]()
    //     0x9bc34c: mov             x17, #0xaf1f
    //     0x9bc350: add             lr, x0, x17
    //     0x9bc354: ldr             lr, [x21, lr, lsl #3]
    //     0x9bc358: blr             lr
    // 0x9bc35c: add             SP, SP, #0x10
    // 0x9bc360: r0 = Null
    //     0x9bc360: mov             x0, NULL
    // 0x9bc364: LeaveFrame
    //     0x9bc364: mov             SP, fp
    //     0x9bc368: ldp             fp, lr, [SP], #0x10
    // 0x9bc36c: ret
    //     0x9bc36c: ret             
    // 0x9bc370: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bc370: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bc374: b               #0x9bc2e0
  }
  _ detach(/* No info */) {
    // ** addr: 0xa66fe8, size: 0x70
    // 0xa66fe8: EnterFrame
    //     0xa66fe8: stp             fp, lr, [SP, #-0x10]!
    //     0xa66fec: mov             fp, SP
    // 0xa66ff0: CheckStackOverflow
    //     0xa66ff0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa66ff4: cmp             SP, x16
    //     0xa66ff8: b.ls            #0xa67050
    // 0xa66ffc: ldr             x16, [fp, #0x10]
    // 0xa67000: SaveReg r16
    //     0xa67000: str             x16, [SP, #-8]!
    // 0xa67004: r0 = detach()
    //     0xa67004: bl              #0xa6ade0  ; [package:flutter/src/foundation/node.dart] AbstractNode::detach
    // 0xa67008: add             SP, SP, #8
    // 0xa6700c: ldr             x0, [fp, #0x10]
    // 0xa67010: LoadField: r1 = r0->field_53
    //     0xa67010: ldur            w1, [x0, #0x53]
    // 0xa67014: DecompressPointer r1
    //     0xa67014: add             x1, x1, HEAP, lsl #32
    // 0xa67018: cmp             w1, NULL
    // 0xa6701c: b.eq            #0xa67040
    // 0xa67020: r0 = LoadClassIdInstr(r1)
    //     0xa67020: ldur            x0, [x1, #-1]
    //     0xa67024: ubfx            x0, x0, #0xc, #0x14
    // 0xa67028: SaveReg r1
    //     0xa67028: str             x1, [SP, #-8]!
    // 0xa6702c: r0 = GDT[cid_x0 + 0xa3cc]()
    //     0xa6702c: mov             x17, #0xa3cc
    //     0xa67030: add             lr, x0, x17
    //     0xa67034: ldr             lr, [x21, lr, lsl #3]
    //     0xa67038: blr             lr
    // 0xa6703c: add             SP, SP, #8
    // 0xa67040: r0 = Null
    //     0xa67040: mov             x0, NULL
    // 0xa67044: LeaveFrame
    //     0xa67044: mov             SP, fp
    //     0xa67048: ldp             fp, lr, [SP], #0x10
    // 0xa6704c: ret
    //     0xa6704c: ret             
    // 0xa67050: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa67050: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa67054: b               #0xa66ffc
  }
}

// class id: 2551, size: 0x58, field offset: 0x58
//   transformed mixin,
abstract class _RenderSliverPersistentHeader&RenderSliver&RenderObjectWithChildMixin&RenderSliverHelpers extends _RenderSliverPersistentHeader&RenderSliver&RenderObjectWithChildMixin
     with RenderSliverHelpers {

  _ applyPaintTransformForBoxChild(/* No info */) {
    // ** addr: 0x6bbf78, size: 0x2b8
    // 0x6bbf78: EnterFrame
    //     0x6bbf78: stp             fp, lr, [SP, #-0x10]!
    //     0x6bbf7c: mov             fp, SP
    // 0x6bbf80: AllocStack(0x18)
    //     0x6bbf80: sub             SP, SP, #0x18
    // 0x6bbf84: CheckStackOverflow
    //     0x6bbf84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bbf88: cmp             SP, x16
    //     0x6bbf8c: b.ls            #0x6bc208
    // 0x6bbf90: ldr             x3, [fp, #0x20]
    // 0x6bbf94: LoadField: r4 = r3->field_27
    //     0x6bbf94: ldur            w4, [x3, #0x27]
    // 0x6bbf98: DecompressPointer r4
    //     0x6bbf98: add             x4, x4, HEAP, lsl #32
    // 0x6bbf9c: stur            x4, [fp, #-8]
    // 0x6bbfa0: cmp             w4, NULL
    // 0x6bbfa4: b.eq            #0x6bc1d0
    // 0x6bbfa8: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6bbfa8: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6bbfac: ldr             x5, [x5, #0x1e8]
    // 0x6bbfb0: mov             x0, x4
    // 0x6bbfb4: r2 = Null
    //     0x6bbfb4: mov             x2, NULL
    // 0x6bbfb8: r1 = Null
    //     0x6bbfb8: mov             x1, NULL
    // 0x6bbfbc: r4 = LoadClassIdInstr(r0)
    //     0x6bbfbc: ldur            x4, [x0, #-1]
    //     0x6bbfc0: ubfx            x4, x4, #0xc, #0x14
    // 0x6bbfc4: cmp             x4, #0x80c
    // 0x6bbfc8: b.eq            #0x6bbfe0
    // 0x6bbfcc: r8 = SliverConstraints
    //     0x6bbfcc: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x6bbfd0: ldr             x8, [x8, #0x5a8]
    // 0x6bbfd4: r3 = Null
    //     0x6bbfd4: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fb08] Null
    //     0x6bbfd8: ldr             x3, [x3, #0xb08]
    // 0x6bbfdc: r0 = DefaultTypeTest()
    //     0x6bbfdc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6bbfe0: ldur            x0, [fp, #-8]
    // 0x6bbfe4: LoadField: r1 = r0->field_7
    //     0x6bbfe4: ldur            w1, [x0, #7]
    // 0x6bbfe8: DecompressPointer r1
    //     0x6bbfe8: add             x1, x1, HEAP, lsl #32
    // 0x6bbfec: LoadField: r2 = r1->field_7
    //     0x6bbfec: ldur            x2, [x1, #7]
    // 0x6bbff0: cmp             x2, #1
    // 0x6bbff4: b.gt            #0x6bc004
    // 0x6bbff8: cmp             x2, #0
    // 0x6bbffc: b.gt            #0x6bc00c
    // 0x6bc000: b               #0x6bc014
    // 0x6bc004: cmp             x2, #2
    // 0x6bc008: b.gt            #0x6bc014
    // 0x6bc00c: r1 = true
    //     0x6bc00c: add             x1, NULL, #0x20  ; true
    // 0x6bc010: b               #0x6bc018
    // 0x6bc014: r1 = false
    //     0x6bc014: add             x1, NULL, #0x30  ; false
    // 0x6bc018: LoadField: r2 = r0->field_b
    //     0x6bc018: ldur            w2, [x0, #0xb]
    // 0x6bc01c: DecompressPointer r2
    //     0x6bc01c: add             x2, x2, HEAP, lsl #32
    // 0x6bc020: LoadField: r0 = r2->field_7
    //     0x6bc020: ldur            x0, [x2, #7]
    // 0x6bc024: cmp             x0, #0
    // 0x6bc028: b.gt            #0x6bc034
    // 0x6bc02c: mov             x2, x1
    // 0x6bc030: b               #0x6bc03c
    // 0x6bc034: eor             x0, x1, #0x10
    // 0x6bc038: mov             x2, x0
    // 0x6bc03c: ldr             x1, [fp, #0x20]
    // 0x6bc040: stur            x2, [fp, #-8]
    // 0x6bc044: r0 = LoadClassIdInstr(r1)
    //     0x6bc044: ldur            x0, [x1, #-1]
    //     0x6bc048: ubfx            x0, x0, #0xc, #0x14
    // 0x6bc04c: ldr             x16, [fp, #0x18]
    // 0x6bc050: stp             x16, x1, [SP, #-0x10]!
    // 0x6bc054: r0 = GDT[cid_x0 + 0x1a8b]()
    //     0x6bc054: mov             x17, #0x1a8b
    //     0x6bc058: add             lr, x0, x17
    //     0x6bc05c: ldr             lr, [x21, lr, lsl #3]
    //     0x6bc060: blr             lr
    // 0x6bc064: add             SP, SP, #0x10
    // 0x6bc068: ldr             x3, [fp, #0x20]
    // 0x6bc06c: stur            d0, [fp, #-0x18]
    // 0x6bc070: LoadField: r4 = r3->field_27
    //     0x6bc070: ldur            w4, [x3, #0x27]
    // 0x6bc074: DecompressPointer r4
    //     0x6bc074: add             x4, x4, HEAP, lsl #32
    // 0x6bc078: stur            x4, [fp, #-0x10]
    // 0x6bc07c: cmp             w4, NULL
    // 0x6bc080: b.eq            #0x6bc1e8
    // 0x6bc084: mov             x0, x4
    // 0x6bc088: r2 = Null
    //     0x6bc088: mov             x2, NULL
    // 0x6bc08c: r1 = Null
    //     0x6bc08c: mov             x1, NULL
    // 0x6bc090: r4 = LoadClassIdInstr(r0)
    //     0x6bc090: ldur            x4, [x0, #-1]
    //     0x6bc094: ubfx            x4, x4, #0xc, #0x14
    // 0x6bc098: cmp             x4, #0x80c
    // 0x6bc09c: b.eq            #0x6bc0b4
    // 0x6bc0a0: r8 = SliverConstraints
    //     0x6bc0a0: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x6bc0a4: ldr             x8, [x8, #0x5a8]
    // 0x6bc0a8: r3 = Null
    //     0x6bc0a8: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fb18] Null
    //     0x6bc0ac: ldr             x3, [x3, #0xb18]
    // 0x6bc0b0: r0 = DefaultTypeTest()
    //     0x6bc0b0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6bc0b4: ldur            x16, [fp, #-0x10]
    // 0x6bc0b8: SaveReg r16
    //     0x6bc0b8: str             x16, [SP, #-8]!
    // 0x6bc0bc: r0 = axis()
    //     0x6bc0bc: bl              #0x643150  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0x6bc0c0: add             SP, SP, #8
    // 0x6bc0c4: LoadField: r1 = r0->field_7
    //     0x6bc0c4: ldur            x1, [x0, #7]
    // 0x6bc0c8: cmp             x1, #0
    // 0x6bc0cc: b.gt            #0x6bc160
    // 0x6bc0d0: ldur            x0, [fp, #-8]
    // 0x6bc0d4: tbz             w0, #4, #0x6bc11c
    // 0x6bc0d8: ldr             x1, [fp, #0x20]
    // 0x6bc0dc: ldr             x2, [fp, #0x18]
    // 0x6bc0e0: ldur            d0, [fp, #-0x18]
    // 0x6bc0e4: LoadField: r0 = r1->field_4f
    //     0x6bc0e4: ldur            w0, [x1, #0x4f]
    // 0x6bc0e8: DecompressPointer r0
    //     0x6bc0e8: add             x0, x0, HEAP, lsl #32
    // 0x6bc0ec: cmp             w0, NULL
    // 0x6bc0f0: b.eq            #0x6bc210
    // 0x6bc0f4: LoadField: d1 = r0->field_17
    //     0x6bc0f4: ldur            d1, [x0, #0x17]
    // 0x6bc0f8: LoadField: r0 = r2->field_57
    //     0x6bc0f8: ldur            w0, [x2, #0x57]
    // 0x6bc0fc: DecompressPointer r0
    //     0x6bc0fc: add             x0, x0, HEAP, lsl #32
    // 0x6bc100: cmp             w0, NULL
    // 0x6bc104: b.eq            #0x6bc214
    // 0x6bc108: LoadField: d2 = r0->field_7
    //     0x6bc108: ldur            d2, [x0, #7]
    // 0x6bc10c: fsub            d3, d1, d2
    // 0x6bc110: fsub            d1, d3, d0
    // 0x6bc114: mov             v0.16b, v1.16b
    // 0x6bc118: b               #0x6bc120
    // 0x6bc11c: ldur            d0, [fp, #-0x18]
    // 0x6bc120: r0 = inline_Allocate_Double()
    //     0x6bc120: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6bc124: add             x0, x0, #0x10
    //     0x6bc128: cmp             x1, x0
    //     0x6bc12c: b.ls            #0x6bc218
    //     0x6bc130: str             x0, [THR, #0x60]  ; THR::top
    //     0x6bc134: sub             x0, x0, #0xf
    //     0x6bc138: mov             x1, #0xd108
    //     0x6bc13c: movk            x1, #3, lsl #16
    //     0x6bc140: stur            x1, [x0, #-1]
    // 0x6bc144: StoreField: r0->field_7 = d0
    //     0x6bc144: stur            d0, [x0, #7]
    // 0x6bc148: ldr             x16, [fp, #0x10]
    // 0x6bc14c: stp             x0, x16, [SP, #-0x10]!
    // 0x6bc150: SaveReg rZR
    //     0x6bc150: str             xzr, [SP, #-8]!
    // 0x6bc154: r0 = translate()
    //     0x6bc154: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0x6bc158: add             SP, SP, #0x18
    // 0x6bc15c: b               #0x6bc1c0
    // 0x6bc160: ldr             x1, [fp, #0x20]
    // 0x6bc164: ldr             x2, [fp, #0x18]
    // 0x6bc168: ldur            d0, [fp, #-0x18]
    // 0x6bc16c: ldur            x0, [fp, #-8]
    // 0x6bc170: tbz             w0, #4, #0x6bc1a8
    // 0x6bc174: LoadField: r0 = r1->field_4f
    //     0x6bc174: ldur            w0, [x1, #0x4f]
    // 0x6bc178: DecompressPointer r0
    //     0x6bc178: add             x0, x0, HEAP, lsl #32
    // 0x6bc17c: cmp             w0, NULL
    // 0x6bc180: b.eq            #0x6bc228
    // 0x6bc184: LoadField: d1 = r0->field_17
    //     0x6bc184: ldur            d1, [x0, #0x17]
    // 0x6bc188: LoadField: r0 = r2->field_57
    //     0x6bc188: ldur            w0, [x2, #0x57]
    // 0x6bc18c: DecompressPointer r0
    //     0x6bc18c: add             x0, x0, HEAP, lsl #32
    // 0x6bc190: cmp             w0, NULL
    // 0x6bc194: b.eq            #0x6bc22c
    // 0x6bc198: LoadField: d2 = r0->field_f
    //     0x6bc198: ldur            d2, [x0, #0xf]
    // 0x6bc19c: fsub            d3, d1, d2
    // 0x6bc1a0: fsub            d1, d3, d0
    // 0x6bc1a4: mov             v0.16b, v1.16b
    // 0x6bc1a8: ldr             x16, [fp, #0x10]
    // 0x6bc1ac: r30 = 0.000000
    //     0x6bc1ac: ldr             lr, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x6bc1b0: stp             lr, x16, [SP, #-0x10]!
    // 0x6bc1b4: SaveReg d0
    //     0x6bc1b4: str             d0, [SP, #-8]!
    // 0x6bc1b8: r0 = translate()
    //     0x6bc1b8: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0x6bc1bc: add             SP, SP, #0x18
    // 0x6bc1c0: r0 = Null
    //     0x6bc1c0: mov             x0, NULL
    // 0x6bc1c4: LeaveFrame
    //     0x6bc1c4: mov             SP, fp
    //     0x6bc1c8: ldp             fp, lr, [SP], #0x10
    // 0x6bc1cc: ret
    //     0x6bc1cc: ret             
    // 0x6bc1d0: r0 = StateError()
    //     0x6bc1d0: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6bc1d4: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6bc1d4: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6bc1d8: ldr             x5, [x5, #0x1e8]
    // 0x6bc1dc: StoreField: r0->field_b = r5
    //     0x6bc1dc: stur            w5, [x0, #0xb]
    // 0x6bc1e0: r0 = Throw()
    //     0x6bc1e0: bl              #0xd67e38  ; ThrowStub
    // 0x6bc1e4: brk             #0
    // 0x6bc1e8: r0 = StateError()
    //     0x6bc1e8: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6bc1ec: mov             x1, x0
    // 0x6bc1f0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6bc1f0: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6bc1f4: ldr             x0, [x0, #0x1e8]
    // 0x6bc1f8: StoreField: r1->field_b = r0
    //     0x6bc1f8: stur            w0, [x1, #0xb]
    // 0x6bc1fc: mov             x0, x1
    // 0x6bc200: r0 = Throw()
    //     0x6bc200: bl              #0xd67e38  ; ThrowStub
    // 0x6bc204: brk             #0
    // 0x6bc208: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bc208: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bc20c: b               #0x6bbf90
    // 0x6bc210: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6bc210: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6bc214: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6bc214: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6bc218: SaveReg d0
    //     0x6bc218: str             q0, [SP, #-0x10]!
    // 0x6bc21c: r0 = AllocateDouble()
    //     0x6bc21c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6bc220: RestoreReg d0
    //     0x6bc220: ldr             q0, [SP], #0x10
    // 0x6bc224: b               #0x6bc144
    // 0x6bc228: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6bc228: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6bc22c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6bc22c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, BoxHitTestResult) {
    // ** addr: 0xa8b854, size: 0x70
    // 0xa8b854: EnterFrame
    //     0xa8b854: stp             fp, lr, [SP, #-0x10]!
    //     0xa8b858: mov             fp, SP
    // 0xa8b85c: ldr             x0, [fp, #0x18]
    // 0xa8b860: LoadField: r1 = r0->field_17
    //     0xa8b860: ldur            w1, [x0, #0x17]
    // 0xa8b864: DecompressPointer r1
    //     0xa8b864: add             x1, x1, HEAP, lsl #32
    // 0xa8b868: CheckStackOverflow
    //     0xa8b868: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8b86c: cmp             SP, x16
    //     0xa8b870: b.ls            #0xa8b8bc
    // 0xa8b874: LoadField: r0 = r1->field_f
    //     0xa8b874: ldur            w0, [x1, #0xf]
    // 0xa8b878: DecompressPointer r0
    //     0xa8b878: add             x0, x0, HEAP, lsl #32
    // 0xa8b87c: LoadField: r2 = r1->field_13
    //     0xa8b87c: ldur            w2, [x1, #0x13]
    // 0xa8b880: DecompressPointer r2
    //     0xa8b880: add             x2, x2, HEAP, lsl #32
    // 0xa8b884: r1 = LoadClassIdInstr(r0)
    //     0xa8b884: ldur            x1, [x0, #-1]
    //     0xa8b888: ubfx            x1, x1, #0xc, #0x14
    // 0xa8b88c: ldr             x16, [fp, #0x10]
    // 0xa8b890: stp             x16, x0, [SP, #-0x10]!
    // 0xa8b894: SaveReg r2
    //     0xa8b894: str             x2, [SP, #-8]!
    // 0xa8b898: mov             x0, x1
    // 0xa8b89c: r0 = GDT[cid_x0 + 0xefa2]()
    //     0xa8b89c: mov             x17, #0xefa2
    //     0xa8b8a0: add             lr, x0, x17
    //     0xa8b8a4: ldr             lr, [x21, lr, lsl #3]
    //     0xa8b8a8: blr             lr
    // 0xa8b8ac: add             SP, SP, #0x18
    // 0xa8b8b0: LeaveFrame
    //     0xa8b8b0: mov             SP, fp
    //     0xa8b8b4: ldp             fp, lr, [SP], #0x10
    // 0xa8b8b8: ret
    //     0xa8b8b8: ret             
    // 0xa8b8bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8b8bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8b8c0: b               #0xa8b874
  }
  _ hitTestBoxChild(/* No info */) {
    // ** addr: 0xa8b8c4, size: 0x3cc
    // 0xa8b8c4: EnterFrame
    //     0xa8b8c4: stp             fp, lr, [SP, #-0x10]!
    //     0xa8b8c8: mov             fp, SP
    // 0xa8b8cc: AllocStack(0x40)
    //     0xa8b8cc: sub             SP, SP, #0x40
    // 0xa8b8d0: CheckStackOverflow
    //     0xa8b8d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8b8d4: cmp             SP, x16
    //     0xa8b8d8: b.ls            #0xa8bc78
    // 0xa8b8dc: r1 = 2
    //     0xa8b8dc: mov             x1, #2
    // 0xa8b8e0: r0 = AllocateContext()
    //     0xa8b8e0: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa8b8e4: mov             x4, x0
    // 0xa8b8e8: ldr             x3, [fp, #0x20]
    // 0xa8b8ec: stur            x4, [fp, #-0x10]
    // 0xa8b8f0: StoreField: r4->field_f = r3
    //     0xa8b8f0: stur            w3, [x4, #0xf]
    // 0xa8b8f4: ldr             x5, [fp, #0x30]
    // 0xa8b8f8: LoadField: r6 = r5->field_27
    //     0xa8b8f8: ldur            w6, [x5, #0x27]
    // 0xa8b8fc: DecompressPointer r6
    //     0xa8b8fc: add             x6, x6, HEAP, lsl #32
    // 0xa8b900: stur            x6, [fp, #-8]
    // 0xa8b904: cmp             w6, NULL
    // 0xa8b908: b.eq            #0xa8bc40
    // 0xa8b90c: r7 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xa8b90c: add             x7, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0xa8b910: ldr             x7, [x7, #0x1e8]
    // 0xa8b914: mov             x0, x6
    // 0xa8b918: r2 = Null
    //     0xa8b918: mov             x2, NULL
    // 0xa8b91c: r1 = Null
    //     0xa8b91c: mov             x1, NULL
    // 0xa8b920: r4 = LoadClassIdInstr(r0)
    //     0xa8b920: ldur            x4, [x0, #-1]
    //     0xa8b924: ubfx            x4, x4, #0xc, #0x14
    // 0xa8b928: cmp             x4, #0x80c
    // 0xa8b92c: b.eq            #0xa8b944
    // 0xa8b930: r8 = SliverConstraints
    //     0xa8b930: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0xa8b934: ldr             x8, [x8, #0x5a8]
    // 0xa8b938: r3 = Null
    //     0xa8b938: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fb28] Null
    //     0xa8b93c: ldr             x3, [x3, #0xb28]
    // 0xa8b940: r0 = DefaultTypeTest()
    //     0xa8b940: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa8b944: ldur            x0, [fp, #-8]
    // 0xa8b948: LoadField: r1 = r0->field_7
    //     0xa8b948: ldur            w1, [x0, #7]
    // 0xa8b94c: DecompressPointer r1
    //     0xa8b94c: add             x1, x1, HEAP, lsl #32
    // 0xa8b950: LoadField: r2 = r1->field_7
    //     0xa8b950: ldur            x2, [x1, #7]
    // 0xa8b954: cmp             x2, #1
    // 0xa8b958: b.gt            #0xa8b968
    // 0xa8b95c: cmp             x2, #0
    // 0xa8b960: b.gt            #0xa8b970
    // 0xa8b964: b               #0xa8b978
    // 0xa8b968: cmp             x2, #2
    // 0xa8b96c: b.gt            #0xa8b978
    // 0xa8b970: r1 = true
    //     0xa8b970: add             x1, NULL, #0x20  ; true
    // 0xa8b974: b               #0xa8b97c
    // 0xa8b978: r1 = false
    //     0xa8b978: add             x1, NULL, #0x30  ; false
    // 0xa8b97c: LoadField: r2 = r0->field_b
    //     0xa8b97c: ldur            w2, [x0, #0xb]
    // 0xa8b980: DecompressPointer r2
    //     0xa8b980: add             x2, x2, HEAP, lsl #32
    // 0xa8b984: LoadField: r0 = r2->field_7
    //     0xa8b984: ldur            x0, [x2, #7]
    // 0xa8b988: cmp             x0, #0
    // 0xa8b98c: b.gt            #0xa8b998
    // 0xa8b990: mov             x4, x1
    // 0xa8b994: b               #0xa8b9a0
    // 0xa8b998: eor             x0, x1, #0x10
    // 0xa8b99c: mov             x4, x0
    // 0xa8b9a0: ldr             x1, [fp, #0x30]
    // 0xa8b9a4: ldr             x3, [fp, #0x18]
    // 0xa8b9a8: ldr             d0, [fp, #0x10]
    // 0xa8b9ac: ldur            x2, [fp, #-0x10]
    // 0xa8b9b0: stur            x4, [fp, #-8]
    // 0xa8b9b4: r0 = LoadClassIdInstr(r1)
    //     0xa8b9b4: ldur            x0, [x1, #-1]
    //     0xa8b9b8: ubfx            x0, x0, #0xc, #0x14
    // 0xa8b9bc: ldr             x16, [fp, #0x20]
    // 0xa8b9c0: stp             x16, x1, [SP, #-0x10]!
    // 0xa8b9c4: r0 = GDT[cid_x0 + 0x1a8b]()
    //     0xa8b9c4: mov             x17, #0x1a8b
    //     0xa8b9c8: add             lr, x0, x17
    //     0xa8b9cc: ldr             lr, [x21, lr, lsl #3]
    //     0xa8b9d0: blr             lr
    // 0xa8b9d4: add             SP, SP, #0x10
    // 0xa8b9d8: mov             v1.16b, v0.16b
    // 0xa8b9dc: ldr             d0, [fp, #0x10]
    // 0xa8b9e0: stur            d1, [fp, #-0x30]
    // 0xa8b9e4: fsub            d2, d0, d1
    // 0xa8b9e8: ldr             x0, [fp, #0x18]
    // 0xa8b9ec: stur            d2, [fp, #-0x28]
    // 0xa8b9f0: LoadField: d0 = r0->field_7
    //     0xa8b9f0: ldur            d0, [x0, #7]
    // 0xa8b9f4: d3 = 0.000000
    //     0xa8b9f4: eor             v3.16b, v3.16b, v3.16b
    // 0xa8b9f8: fsub            d4, d0, d3
    // 0xa8b9fc: ldur            x3, [fp, #-0x10]
    // 0xa8ba00: stur            d4, [fp, #-0x20]
    // 0xa8ba04: StoreField: r3->field_13 = rNULL
    //     0xa8ba04: stur            NULL, [x3, #0x13]
    // 0xa8ba08: ldr             x4, [fp, #0x30]
    // 0xa8ba0c: LoadField: r5 = r4->field_27
    //     0xa8ba0c: ldur            w5, [x4, #0x27]
    // 0xa8ba10: DecompressPointer r5
    //     0xa8ba10: add             x5, x5, HEAP, lsl #32
    // 0xa8ba14: stur            x5, [fp, #-0x18]
    // 0xa8ba18: cmp             w5, NULL
    // 0xa8ba1c: b.eq            #0xa8bc58
    // 0xa8ba20: mov             x0, x5
    // 0xa8ba24: r2 = Null
    //     0xa8ba24: mov             x2, NULL
    // 0xa8ba28: r1 = Null
    //     0xa8ba28: mov             x1, NULL
    // 0xa8ba2c: r4 = LoadClassIdInstr(r0)
    //     0xa8ba2c: ldur            x4, [x0, #-1]
    //     0xa8ba30: ubfx            x4, x4, #0xc, #0x14
    // 0xa8ba34: cmp             x4, #0x80c
    // 0xa8ba38: b.eq            #0xa8ba50
    // 0xa8ba3c: r8 = SliverConstraints
    //     0xa8ba3c: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0xa8ba40: ldr             x8, [x8, #0x5a8]
    // 0xa8ba44: r3 = Null
    //     0xa8ba44: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fb38] Null
    //     0xa8ba48: ldr             x3, [x3, #0xb38]
    // 0xa8ba4c: r0 = DefaultTypeTest()
    //     0xa8ba4c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa8ba50: ldur            x16, [fp, #-0x18]
    // 0xa8ba54: SaveReg r16
    //     0xa8ba54: str             x16, [SP, #-8]!
    // 0xa8ba58: r0 = axis()
    //     0xa8ba58: bl              #0x643150  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0xa8ba5c: add             SP, SP, #8
    // 0xa8ba60: LoadField: r1 = r0->field_7
    //     0xa8ba60: ldur            x1, [x0, #7]
    // 0xa8ba64: cmp             x1, #0
    // 0xa8ba68: b.gt            #0xa8bb3c
    // 0xa8ba6c: ldur            x0, [fp, #-8]
    // 0xa8ba70: tbz             w0, #4, #0xa8bacc
    // 0xa8ba74: ldr             x1, [fp, #0x30]
    // 0xa8ba78: ldur            x2, [fp, #-0x10]
    // 0xa8ba7c: ldur            d0, [fp, #-0x30]
    // 0xa8ba80: ldur            d1, [fp, #-0x28]
    // 0xa8ba84: LoadField: r0 = r2->field_f
    //     0xa8ba84: ldur            w0, [x2, #0xf]
    // 0xa8ba88: DecompressPointer r0
    //     0xa8ba88: add             x0, x0, HEAP, lsl #32
    // 0xa8ba8c: LoadField: r3 = r0->field_57
    //     0xa8ba8c: ldur            w3, [x0, #0x57]
    // 0xa8ba90: DecompressPointer r3
    //     0xa8ba90: add             x3, x3, HEAP, lsl #32
    // 0xa8ba94: cmp             w3, NULL
    // 0xa8ba98: b.eq            #0xa8bc80
    // 0xa8ba9c: LoadField: d2 = r3->field_7
    //     0xa8ba9c: ldur            d2, [x3, #7]
    // 0xa8baa0: fsub            d3, d2, d1
    // 0xa8baa4: LoadField: r0 = r1->field_4f
    //     0xa8baa4: ldur            w0, [x1, #0x4f]
    // 0xa8baa8: DecompressPointer r0
    //     0xa8baa8: add             x0, x0, HEAP, lsl #32
    // 0xa8baac: cmp             w0, NULL
    // 0xa8bab0: b.eq            #0xa8bc84
    // 0xa8bab4: LoadField: d1 = r0->field_17
    //     0xa8bab4: ldur            d1, [x0, #0x17]
    // 0xa8bab8: fsub            d4, d1, d2
    // 0xa8babc: fsub            d1, d4, d0
    // 0xa8bac0: mov             v2.16b, v1.16b
    // 0xa8bac4: mov             v1.16b, v3.16b
    // 0xa8bac8: b               #0xa8badc
    // 0xa8bacc: ldur            x2, [fp, #-0x10]
    // 0xa8bad0: ldur            d0, [fp, #-0x30]
    // 0xa8bad4: ldur            d1, [fp, #-0x28]
    // 0xa8bad8: mov             v2.16b, v0.16b
    // 0xa8badc: ldur            d0, [fp, #-0x20]
    // 0xa8bae0: stur            d2, [fp, #-0x38]
    // 0xa8bae4: stur            d1, [fp, #-0x40]
    // 0xa8bae8: r0 = Offset()
    //     0xa8bae8: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa8baec: ldur            d0, [fp, #-0x38]
    // 0xa8baf0: stur            x0, [fp, #-0x18]
    // 0xa8baf4: StoreField: r0->field_7 = d0
    //     0xa8baf4: stur            d0, [x0, #7]
    // 0xa8baf8: d2 = 0.000000
    //     0xa8baf8: eor             v2.16b, v2.16b, v2.16b
    // 0xa8bafc: StoreField: r0->field_f = d2
    //     0xa8bafc: stur            d2, [x0, #0xf]
    // 0xa8bb00: r0 = Offset()
    //     0xa8bb00: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa8bb04: ldur            d0, [fp, #-0x40]
    // 0xa8bb08: StoreField: r0->field_7 = d0
    //     0xa8bb08: stur            d0, [x0, #7]
    // 0xa8bb0c: ldur            d3, [fp, #-0x20]
    // 0xa8bb10: StoreField: r0->field_f = d3
    //     0xa8bb10: stur            d3, [x0, #0xf]
    // 0xa8bb14: ldur            x2, [fp, #-0x10]
    // 0xa8bb18: StoreField: r2->field_13 = r0
    //     0xa8bb18: stur            w0, [x2, #0x13]
    //     0xa8bb1c: ldurb           w16, [x2, #-1]
    //     0xa8bb20: ldurb           w17, [x0, #-1]
    //     0xa8bb24: and             x16, x17, x16, lsr #2
    //     0xa8bb28: tst             x16, HEAP, lsr #32
    //     0xa8bb2c: b.eq            #0xa8bb34
    //     0xa8bb30: bl              #0xd6828c
    // 0xa8bb34: ldur            x0, [fp, #-0x18]
    // 0xa8bb38: b               #0xa8bc04
    // 0xa8bb3c: ldr             x1, [fp, #0x30]
    // 0xa8bb40: ldur            x2, [fp, #-0x10]
    // 0xa8bb44: ldur            d0, [fp, #-0x30]
    // 0xa8bb48: ldur            d1, [fp, #-0x28]
    // 0xa8bb4c: ldur            d3, [fp, #-0x20]
    // 0xa8bb50: ldur            x0, [fp, #-8]
    // 0xa8bb54: d2 = 0.000000
    //     0xa8bb54: eor             v2.16b, v2.16b, v2.16b
    // 0xa8bb58: tbz             w0, #4, #0xa8bba0
    // 0xa8bb5c: LoadField: r0 = r2->field_f
    //     0xa8bb5c: ldur            w0, [x2, #0xf]
    // 0xa8bb60: DecompressPointer r0
    //     0xa8bb60: add             x0, x0, HEAP, lsl #32
    // 0xa8bb64: LoadField: r3 = r0->field_57
    //     0xa8bb64: ldur            w3, [x0, #0x57]
    // 0xa8bb68: DecompressPointer r3
    //     0xa8bb68: add             x3, x3, HEAP, lsl #32
    // 0xa8bb6c: cmp             w3, NULL
    // 0xa8bb70: b.eq            #0xa8bc88
    // 0xa8bb74: LoadField: d4 = r3->field_f
    //     0xa8bb74: ldur            d4, [x3, #0xf]
    // 0xa8bb78: fsub            d5, d4, d1
    // 0xa8bb7c: LoadField: r0 = r1->field_4f
    //     0xa8bb7c: ldur            w0, [x1, #0x4f]
    // 0xa8bb80: DecompressPointer r0
    //     0xa8bb80: add             x0, x0, HEAP, lsl #32
    // 0xa8bb84: cmp             w0, NULL
    // 0xa8bb88: b.eq            #0xa8bc8c
    // 0xa8bb8c: LoadField: d1 = r0->field_17
    //     0xa8bb8c: ldur            d1, [x0, #0x17]
    // 0xa8bb90: fsub            d6, d1, d4
    // 0xa8bb94: fsub            d1, d6, d0
    // 0xa8bb98: mov             v0.16b, v5.16b
    // 0xa8bb9c: b               #0xa8bbac
    // 0xa8bba0: mov             v31.16b, v1.16b
    // 0xa8bba4: mov             v1.16b, v0.16b
    // 0xa8bba8: mov             v0.16b, v31.16b
    // 0xa8bbac: stur            d1, [fp, #-0x28]
    // 0xa8bbb0: stur            d0, [fp, #-0x30]
    // 0xa8bbb4: r0 = Offset()
    //     0xa8bbb4: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa8bbb8: d0 = 0.000000
    //     0xa8bbb8: eor             v0.16b, v0.16b, v0.16b
    // 0xa8bbbc: stur            x0, [fp, #-8]
    // 0xa8bbc0: StoreField: r0->field_7 = d0
    //     0xa8bbc0: stur            d0, [x0, #7]
    // 0xa8bbc4: ldur            d0, [fp, #-0x28]
    // 0xa8bbc8: StoreField: r0->field_f = d0
    //     0xa8bbc8: stur            d0, [x0, #0xf]
    // 0xa8bbcc: r0 = Offset()
    //     0xa8bbcc: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa8bbd0: ldur            d0, [fp, #-0x20]
    // 0xa8bbd4: StoreField: r0->field_7 = d0
    //     0xa8bbd4: stur            d0, [x0, #7]
    // 0xa8bbd8: ldur            d0, [fp, #-0x30]
    // 0xa8bbdc: StoreField: r0->field_f = d0
    //     0xa8bbdc: stur            d0, [x0, #0xf]
    // 0xa8bbe0: ldur            x2, [fp, #-0x10]
    // 0xa8bbe4: StoreField: r2->field_13 = r0
    //     0xa8bbe4: stur            w0, [x2, #0x13]
    //     0xa8bbe8: ldurb           w16, [x2, #-1]
    //     0xa8bbec: ldurb           w17, [x0, #-1]
    //     0xa8bbf0: and             x16, x17, x16, lsr #2
    //     0xa8bbf4: tst             x16, HEAP, lsr #32
    //     0xa8bbf8: b.eq            #0xa8bc00
    //     0xa8bbfc: bl              #0xd6828c
    // 0xa8bc00: ldur            x0, [fp, #-8]
    // 0xa8bc04: stur            x0, [fp, #-8]
    // 0xa8bc08: r1 = Function '<anonymous closure>':.
    //     0xa8bc08: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4fb48] AnonymousClosure: (0xa8b854), in [package:flutter/src/rendering/sliver_persistent_header.dart] _RenderSliverPersistentHeader&RenderSliver&RenderObjectWithChildMixin&RenderSliverHelpers::hitTestBoxChild (0xa8b8c4)
    //     0xa8bc0c: ldr             x1, [x1, #0xb48]
    // 0xa8bc10: r0 = AllocateClosure()
    //     0xa8bc10: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa8bc14: ldr             x16, [fp, #0x28]
    // 0xa8bc18: stp             x0, x16, [SP, #-0x10]!
    // 0xa8bc1c: ldur            x16, [fp, #-8]
    // 0xa8bc20: SaveReg r16
    //     0xa8bc20: str             x16, [SP, #-8]!
    // 0xa8bc24: r4 = const [0, 0x3, 0x3, 0x2, paintOffset, 0x2, null]
    //     0xa8bc24: add             x4, PP, #0x4f, lsl #12  ; [pp+0x4fb50] List(7) [0, 0x3, 0x3, 0x2, "paintOffset", 0x2, Null]
    //     0xa8bc28: ldr             x4, [x4, #0xb50]
    // 0xa8bc2c: r0 = addWithOutOfBandPosition()
    //     0xa8bc2c: bl              #0x62a858  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithOutOfBandPosition
    // 0xa8bc30: add             SP, SP, #0x18
    // 0xa8bc34: LeaveFrame
    //     0xa8bc34: mov             SP, fp
    //     0xa8bc38: ldp             fp, lr, [SP], #0x10
    // 0xa8bc3c: ret
    //     0xa8bc3c: ret             
    // 0xa8bc40: r0 = StateError()
    //     0xa8bc40: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xa8bc44: r7 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xa8bc44: add             x7, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0xa8bc48: ldr             x7, [x7, #0x1e8]
    // 0xa8bc4c: StoreField: r0->field_b = r7
    //     0xa8bc4c: stur            w7, [x0, #0xb]
    // 0xa8bc50: r0 = Throw()
    //     0xa8bc50: bl              #0xd67e38  ; ThrowStub
    // 0xa8bc54: brk             #0
    // 0xa8bc58: r0 = StateError()
    //     0xa8bc58: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xa8bc5c: mov             x1, x0
    // 0xa8bc60: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xa8bc60: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0xa8bc64: ldr             x0, [x0, #0x1e8]
    // 0xa8bc68: StoreField: r1->field_b = r0
    //     0xa8bc68: stur            w0, [x1, #0xb]
    // 0xa8bc6c: mov             x0, x1
    // 0xa8bc70: r0 = Throw()
    //     0xa8bc70: bl              #0xd67e38  ; ThrowStub
    // 0xa8bc74: brk             #0
    // 0xa8bc78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8bc78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8bc7c: b               #0xa8b8dc
    // 0xa8bc80: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa8bc80: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa8bc84: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa8bc84: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa8bc88: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa8bc88: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa8bc8c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa8bc8c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
}

// class id: 2552, size: 0x70, field offset: 0x58
abstract class RenderSliverPersistentHeader extends _RenderSliverPersistentHeader&RenderSliver&RenderObjectWithChildMixin&RenderSliverHelpers {

  get _ childExtent(/* No info */) {
    // ** addr: 0x642fa4, size: 0x1ac
    // 0x642fa4: EnterFrame
    //     0x642fa4: stp             fp, lr, [SP, #-0x10]!
    //     0x642fa8: mov             fp, SP
    // 0x642fac: AllocStack(0x8)
    //     0x642fac: sub             SP, SP, #8
    // 0x642fb0: CheckStackOverflow
    //     0x642fb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x642fb4: cmp             SP, x16
    //     0x642fb8: b.ls            #0x643118
    // 0x642fbc: ldr             x3, [fp, #0x10]
    // 0x642fc0: LoadField: r0 = r3->field_53
    //     0x642fc0: ldur            w0, [x3, #0x53]
    // 0x642fc4: DecompressPointer r0
    //     0x642fc4: add             x0, x0, HEAP, lsl #32
    // 0x642fc8: cmp             w0, NULL
    // 0x642fcc: b.ne            #0x642fe0
    // 0x642fd0: r0 = 0.000000
    //     0x642fd0: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x642fd4: LeaveFrame
    //     0x642fd4: mov             SP, fp
    //     0x642fd8: ldp             fp, lr, [SP], #0x10
    // 0x642fdc: ret
    //     0x642fdc: ret             
    // 0x642fe0: LoadField: r4 = r3->field_27
    //     0x642fe0: ldur            w4, [x3, #0x27]
    // 0x642fe4: DecompressPointer r4
    //     0x642fe4: add             x4, x4, HEAP, lsl #32
    // 0x642fe8: stur            x4, [fp, #-8]
    // 0x642fec: cmp             w4, NULL
    // 0x642ff0: b.eq            #0x6430f8
    // 0x642ff4: mov             x0, x4
    // 0x642ff8: r2 = Null
    //     0x642ff8: mov             x2, NULL
    // 0x642ffc: r1 = Null
    //     0x642ffc: mov             x1, NULL
    // 0x643000: r4 = LoadClassIdInstr(r0)
    //     0x643000: ldur            x4, [x0, #-1]
    //     0x643004: ubfx            x4, x4, #0xc, #0x14
    // 0x643008: cmp             x4, #0x80c
    // 0x64300c: b.eq            #0x643024
    // 0x643010: r8 = SliverConstraints
    //     0x643010: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x643014: ldr             x8, [x8, #0x5a8]
    // 0x643018: r3 = Null
    //     0x643018: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fa78] Null
    //     0x64301c: ldr             x3, [x3, #0xa78]
    // 0x643020: r0 = DefaultTypeTest()
    //     0x643020: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x643024: ldur            x16, [fp, #-8]
    // 0x643028: SaveReg r16
    //     0x643028: str             x16, [SP, #-8]!
    // 0x64302c: r0 = axis()
    //     0x64302c: bl              #0x643150  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0x643030: add             SP, SP, #8
    // 0x643034: LoadField: r1 = r0->field_7
    //     0x643034: ldur            x1, [x0, #7]
    // 0x643038: cmp             x1, #0
    // 0x64303c: b.gt            #0x64309c
    // 0x643040: ldr             x1, [fp, #0x10]
    // 0x643044: LoadField: r2 = r1->field_53
    //     0x643044: ldur            w2, [x1, #0x53]
    // 0x643048: DecompressPointer r2
    //     0x643048: add             x2, x2, HEAP, lsl #32
    // 0x64304c: cmp             w2, NULL
    // 0x643050: b.eq            #0x643120
    // 0x643054: LoadField: r3 = r2->field_57
    //     0x643054: ldur            w3, [x2, #0x57]
    // 0x643058: DecompressPointer r3
    //     0x643058: add             x3, x3, HEAP, lsl #32
    // 0x64305c: cmp             w3, NULL
    // 0x643060: b.eq            #0x643124
    // 0x643064: LoadField: d0 = r3->field_7
    //     0x643064: ldur            d0, [x3, #7]
    // 0x643068: r0 = inline_Allocate_Double()
    //     0x643068: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x64306c: add             x0, x0, #0x10
    //     0x643070: cmp             x2, x0
    //     0x643074: b.ls            #0x643128
    //     0x643078: str             x0, [THR, #0x60]  ; THR::top
    //     0x64307c: sub             x0, x0, #0xf
    //     0x643080: mov             x2, #0xd108
    //     0x643084: movk            x2, #3, lsl #16
    //     0x643088: stur            x2, [x0, #-1]
    // 0x64308c: StoreField: r0->field_7 = d0
    //     0x64308c: stur            d0, [x0, #7]
    // 0x643090: LeaveFrame
    //     0x643090: mov             SP, fp
    //     0x643094: ldp             fp, lr, [SP], #0x10
    // 0x643098: ret
    //     0x643098: ret             
    // 0x64309c: ldr             x1, [fp, #0x10]
    // 0x6430a0: LoadField: r2 = r1->field_53
    //     0x6430a0: ldur            w2, [x1, #0x53]
    // 0x6430a4: DecompressPointer r2
    //     0x6430a4: add             x2, x2, HEAP, lsl #32
    // 0x6430a8: cmp             w2, NULL
    // 0x6430ac: b.eq            #0x643138
    // 0x6430b0: LoadField: r1 = r2->field_57
    //     0x6430b0: ldur            w1, [x2, #0x57]
    // 0x6430b4: DecompressPointer r1
    //     0x6430b4: add             x1, x1, HEAP, lsl #32
    // 0x6430b8: cmp             w1, NULL
    // 0x6430bc: b.eq            #0x64313c
    // 0x6430c0: LoadField: d0 = r1->field_f
    //     0x6430c0: ldur            d0, [x1, #0xf]
    // 0x6430c4: r0 = inline_Allocate_Double()
    //     0x6430c4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6430c8: add             x0, x0, #0x10
    //     0x6430cc: cmp             x1, x0
    //     0x6430d0: b.ls            #0x643140
    //     0x6430d4: str             x0, [THR, #0x60]  ; THR::top
    //     0x6430d8: sub             x0, x0, #0xf
    //     0x6430dc: mov             x1, #0xd108
    //     0x6430e0: movk            x1, #3, lsl #16
    //     0x6430e4: stur            x1, [x0, #-1]
    // 0x6430e8: StoreField: r0->field_7 = d0
    //     0x6430e8: stur            d0, [x0, #7]
    // 0x6430ec: LeaveFrame
    //     0x6430ec: mov             SP, fp
    //     0x6430f0: ldp             fp, lr, [SP], #0x10
    // 0x6430f4: ret
    //     0x6430f4: ret             
    // 0x6430f8: r0 = StateError()
    //     0x6430f8: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6430fc: mov             x1, x0
    // 0x643100: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x643100: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x643104: ldr             x0, [x0, #0x1e8]
    // 0x643108: StoreField: r1->field_b = r0
    //     0x643108: stur            w0, [x1, #0xb]
    // 0x64310c: mov             x0, x1
    // 0x643110: r0 = Throw()
    //     0x643110: bl              #0xd67e38  ; ThrowStub
    // 0x643114: brk             #0
    // 0x643118: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x643118: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64311c: b               #0x642fbc
    // 0x643120: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x643120: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x643124: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x643124: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x643128: SaveReg d0
    //     0x643128: str             q0, [SP, #-0x10]!
    // 0x64312c: r0 = AllocateDouble()
    //     0x64312c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x643130: RestoreReg d0
    //     0x643130: ldr             q0, [SP], #0x10
    // 0x643134: b               #0x64308c
    // 0x643138: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x643138: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x64313c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x64313c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x643140: SaveReg d0
    //     0x643140: str             q0, [SP, #-0x10]!
    // 0x643144: r0 = AllocateDouble()
    //     0x643144: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x643148: RestoreReg d0
    //     0x643148: ldr             q0, [SP], #0x10
    // 0x64314c: b               #0x6430e8
  }
  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0x64be44, size: 0x44
    // 0x64be44: EnterFrame
    //     0x64be44: stp             fp, lr, [SP, #-0x10]!
    //     0x64be48: mov             fp, SP
    // 0x64be4c: CheckStackOverflow
    //     0x64be4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64be50: cmp             SP, x16
    //     0x64be54: b.ls            #0x64be80
    // 0x64be58: ldr             x16, [fp, #0x10]
    // 0x64be5c: r30 = Instance_SemanticsTag
    //     0x64be5c: add             lr, PP, #0x4f, lsl #12  ; [pp+0x4fae0] Obj!SemanticsTag@b35331
    //     0x64be60: ldr             lr, [lr, #0xae0]
    // 0x64be64: stp             lr, x16, [SP, #-0x10]!
    // 0x64be68: r0 = addTagForChildren()
    //     0x64be68: bl              #0x64be88  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::addTagForChildren
    // 0x64be6c: add             SP, SP, #0x10
    // 0x64be70: r0 = Null
    //     0x64be70: mov             x0, NULL
    // 0x64be74: LeaveFrame
    //     0x64be74: mov             SP, fp
    //     0x64be78: ldp             fp, lr, [SP], #0x10
    // 0x64be7c: ret
    //     0x64be7c: ret             
    // 0x64be80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64be80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64be84: b               #0x64be58
  }
  _ paint(/* No info */) {
    // ** addr: 0x654840, size: 0x49c
    // 0x654840: EnterFrame
    //     0x654840: stp             fp, lr, [SP, #-0x10]!
    //     0x654844: mov             fp, SP
    // 0x654848: AllocStack(0x18)
    //     0x654848: sub             SP, SP, #0x18
    // 0x65484c: CheckStackOverflow
    //     0x65484c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x654850: cmp             SP, x16
    //     0x654854: b.ls            #0x654c9c
    // 0x654858: ldr             x3, [fp, #0x20]
    // 0x65485c: LoadField: r0 = r3->field_53
    //     0x65485c: ldur            w0, [x3, #0x53]
    // 0x654860: DecompressPointer r0
    //     0x654860: add             x0, x0, HEAP, lsl #32
    // 0x654864: cmp             w0, NULL
    // 0x654868: b.eq            #0x654c6c
    // 0x65486c: LoadField: r0 = r3->field_4f
    //     0x65486c: ldur            w0, [x3, #0x4f]
    // 0x654870: DecompressPointer r0
    //     0x654870: add             x0, x0, HEAP, lsl #32
    // 0x654874: cmp             w0, NULL
    // 0x654878: b.eq            #0x654ca4
    // 0x65487c: LoadField: r1 = r0->field_3f
    //     0x65487c: ldur            w1, [x0, #0x3f]
    // 0x654880: DecompressPointer r1
    //     0x654880: add             x1, x1, HEAP, lsl #32
    // 0x654884: tbnz            w1, #4, #0x654c6c
    // 0x654888: LoadField: r4 = r3->field_27
    //     0x654888: ldur            w4, [x3, #0x27]
    // 0x65488c: DecompressPointer r4
    //     0x65488c: add             x4, x4, HEAP, lsl #32
    // 0x654890: stur            x4, [fp, #-8]
    // 0x654894: cmp             w4, NULL
    // 0x654898: b.eq            #0x654c7c
    // 0x65489c: mov             x0, x4
    // 0x6548a0: r2 = Null
    //     0x6548a0: mov             x2, NULL
    // 0x6548a4: r1 = Null
    //     0x6548a4: mov             x1, NULL
    // 0x6548a8: r4 = LoadClassIdInstr(r0)
    //     0x6548a8: ldur            x4, [x0, #-1]
    //     0x6548ac: ubfx            x4, x4, #0xc, #0x14
    // 0x6548b0: cmp             x4, #0x80c
    // 0x6548b4: b.eq            #0x6548cc
    // 0x6548b8: r8 = SliverConstraints
    //     0x6548b8: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x6548bc: ldr             x8, [x8, #0x5a8]
    // 0x6548c0: r3 = Null
    //     0x6548c0: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fae8] Null
    //     0x6548c4: ldr             x3, [x3, #0xae8]
    // 0x6548c8: r0 = DefaultTypeTest()
    //     0x6548c8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6548cc: ldur            x0, [fp, #-8]
    // 0x6548d0: LoadField: r1 = r0->field_7
    //     0x6548d0: ldur            w1, [x0, #7]
    // 0x6548d4: DecompressPointer r1
    //     0x6548d4: add             x1, x1, HEAP, lsl #32
    // 0x6548d8: LoadField: r2 = r0->field_b
    //     0x6548d8: ldur            w2, [x0, #0xb]
    // 0x6548dc: DecompressPointer r2
    //     0x6548dc: add             x2, x2, HEAP, lsl #32
    // 0x6548e0: stp             x2, x1, [SP, #-0x10]!
    // 0x6548e4: r0 = applyGrowthDirectionToAxisDirection()
    //     0x6548e4: bl              #0x643194  ; [package:flutter/src/rendering/sliver.dart] ::applyGrowthDirectionToAxisDirection
    // 0x6548e8: add             SP, SP, #0x10
    // 0x6548ec: LoadField: r1 = r0->field_7
    //     0x6548ec: ldur            x1, [x0, #7]
    // 0x6548f0: cmp             x1, #1
    // 0x6548f4: b.gt            #0x654aa0
    // 0x6548f8: cmp             x1, #0
    // 0x6548fc: b.gt            #0x6549ec
    // 0x654900: ldr             x0, [fp, #0x20]
    // 0x654904: LoadField: r1 = r0->field_4f
    //     0x654904: ldur            w1, [x0, #0x4f]
    // 0x654908: DecompressPointer r1
    //     0x654908: add             x1, x1, HEAP, lsl #32
    // 0x65490c: cmp             w1, NULL
    // 0x654910: b.eq            #0x654ca8
    // 0x654914: LoadField: d0 = r1->field_17
    //     0x654914: ldur            d0, [x1, #0x17]
    // 0x654918: LoadField: r1 = r0->field_53
    //     0x654918: ldur            w1, [x0, #0x53]
    // 0x65491c: DecompressPointer r1
    //     0x65491c: add             x1, x1, HEAP, lsl #32
    // 0x654920: cmp             w1, NULL
    // 0x654924: b.eq            #0x654cac
    // 0x654928: r1 = LoadClassIdInstr(r0)
    //     0x654928: ldur            x1, [x0, #-1]
    //     0x65492c: ubfx            x1, x1, #0xc, #0x14
    // 0x654930: lsl             x1, x1, #1
    // 0x654934: r17 = 5112
    //     0x654934: mov             x17, #0x13f8
    // 0x654938: cmp             w1, w17
    // 0x65493c: b.eq            #0x65494c
    // 0x654940: r17 = 5118
    //     0x654940: mov             x17, #0x13fe
    // 0x654944: cmp             w1, w17
    // 0x654948: b.ne            #0x65496c
    // 0x65494c: LoadField: r1 = r0->field_83
    //     0x65494c: ldur            w1, [x0, #0x83]
    // 0x654950: DecompressPointer r1
    //     0x654950: add             x1, x1, HEAP, lsl #32
    // 0x654954: cmp             w1, NULL
    // 0x654958: b.ne            #0x654964
    // 0x65495c: d1 = 0.000000
    //     0x65495c: eor             v1.16b, v1.16b, v1.16b
    // 0x654960: b               #0x654994
    // 0x654964: LoadField: d1 = r1->field_7
    //     0x654964: ldur            d1, [x1, #7]
    // 0x654968: b               #0x654994
    // 0x65496c: r17 = 5124
    //     0x65496c: mov             x17, #0x1404
    // 0x654970: cmp             w1, w17
    // 0x654974: b.ne            #0x654980
    // 0x654978: d1 = 0.000000
    //     0x654978: eor             v1.16b, v1.16b, v1.16b
    // 0x65497c: b               #0x654994
    // 0x654980: LoadField: r1 = r0->field_6f
    //     0x654980: ldur            w1, [x0, #0x6f]
    // 0x654984: DecompressPointer r1
    //     0x654984: add             x1, x1, HEAP, lsl #32
    // 0x654988: cmp             w1, NULL
    // 0x65498c: b.eq            #0x654cb0
    // 0x654990: LoadField: d1 = r1->field_7
    //     0x654990: ldur            d1, [x1, #7]
    // 0x654994: fsub            d2, d0, d1
    // 0x654998: stur            d2, [fp, #-0x10]
    // 0x65499c: SaveReg r0
    //     0x65499c: str             x0, [SP, #-8]!
    // 0x6549a0: r0 = childExtent()
    //     0x6549a0: bl              #0x642fa4  ; [package:flutter/src/rendering/sliver_persistent_header.dart] RenderSliverPersistentHeader::childExtent
    // 0x6549a4: add             SP, SP, #8
    // 0x6549a8: cmp             w0, NULL
    // 0x6549ac: b.eq            #0x654cb4
    // 0x6549b0: LoadField: d0 = r0->field_7
    //     0x6549b0: ldur            d0, [x0, #7]
    // 0x6549b4: ldur            d1, [fp, #-0x10]
    // 0x6549b8: fsub            d2, d1, d0
    // 0x6549bc: stur            d2, [fp, #-0x18]
    // 0x6549c0: r0 = Offset()
    //     0x6549c0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x6549c4: d0 = 0.000000
    //     0x6549c4: eor             v0.16b, v0.16b, v0.16b
    // 0x6549c8: StoreField: r0->field_7 = d0
    //     0x6549c8: stur            d0, [x0, #7]
    // 0x6549cc: ldur            d0, [fp, #-0x18]
    // 0x6549d0: StoreField: r0->field_f = d0
    //     0x6549d0: stur            d0, [x0, #0xf]
    // 0x6549d4: ldr             x16, [fp, #0x10]
    // 0x6549d8: stp             x0, x16, [SP, #-0x10]!
    // 0x6549dc: r0 = +()
    //     0x6549dc: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x6549e0: add             SP, SP, #0x10
    // 0x6549e4: mov             x1, x0
    // 0x6549e8: b               #0x654c44
    // 0x6549ec: ldr             x0, [fp, #0x20]
    // 0x6549f0: d0 = 0.000000
    //     0x6549f0: eor             v0.16b, v0.16b, v0.16b
    // 0x6549f4: LoadField: r1 = r0->field_53
    //     0x6549f4: ldur            w1, [x0, #0x53]
    // 0x6549f8: DecompressPointer r1
    //     0x6549f8: add             x1, x1, HEAP, lsl #32
    // 0x6549fc: cmp             w1, NULL
    // 0x654a00: b.eq            #0x654cb8
    // 0x654a04: r1 = LoadClassIdInstr(r0)
    //     0x654a04: ldur            x1, [x0, #-1]
    //     0x654a08: ubfx            x1, x1, #0xc, #0x14
    // 0x654a0c: lsl             x1, x1, #1
    // 0x654a10: r17 = 5112
    //     0x654a10: mov             x17, #0x13f8
    // 0x654a14: cmp             w1, w17
    // 0x654a18: b.eq            #0x654a28
    // 0x654a1c: r17 = 5118
    //     0x654a1c: mov             x17, #0x13fe
    // 0x654a20: cmp             w1, w17
    // 0x654a24: b.ne            #0x654a48
    // 0x654a28: LoadField: r1 = r0->field_83
    //     0x654a28: ldur            w1, [x0, #0x83]
    // 0x654a2c: DecompressPointer r1
    //     0x654a2c: add             x1, x1, HEAP, lsl #32
    // 0x654a30: cmp             w1, NULL
    // 0x654a34: b.ne            #0x654a40
    // 0x654a38: d1 = 0.000000
    //     0x654a38: eor             v1.16b, v1.16b, v1.16b
    // 0x654a3c: b               #0x654a70
    // 0x654a40: LoadField: d1 = r1->field_7
    //     0x654a40: ldur            d1, [x1, #7]
    // 0x654a44: b               #0x654a70
    // 0x654a48: r17 = 5124
    //     0x654a48: mov             x17, #0x1404
    // 0x654a4c: cmp             w1, w17
    // 0x654a50: b.ne            #0x654a5c
    // 0x654a54: d1 = 0.000000
    //     0x654a54: eor             v1.16b, v1.16b, v1.16b
    // 0x654a58: b               #0x654a70
    // 0x654a5c: LoadField: r1 = r0->field_6f
    //     0x654a5c: ldur            w1, [x0, #0x6f]
    // 0x654a60: DecompressPointer r1
    //     0x654a60: add             x1, x1, HEAP, lsl #32
    // 0x654a64: cmp             w1, NULL
    // 0x654a68: b.eq            #0x654cbc
    // 0x654a6c: LoadField: d1 = r1->field_7
    //     0x654a6c: ldur            d1, [x1, #7]
    // 0x654a70: stur            d1, [fp, #-0x10]
    // 0x654a74: r0 = Offset()
    //     0x654a74: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x654a78: ldur            d0, [fp, #-0x10]
    // 0x654a7c: StoreField: r0->field_7 = d0
    //     0x654a7c: stur            d0, [x0, #7]
    // 0x654a80: d0 = 0.000000
    //     0x654a80: eor             v0.16b, v0.16b, v0.16b
    // 0x654a84: StoreField: r0->field_f = d0
    //     0x654a84: stur            d0, [x0, #0xf]
    // 0x654a88: ldr             x16, [fp, #0x10]
    // 0x654a8c: stp             x0, x16, [SP, #-0x10]!
    // 0x654a90: r0 = +()
    //     0x654a90: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x654a94: add             SP, SP, #0x10
    // 0x654a98: mov             x1, x0
    // 0x654a9c: b               #0x654c44
    // 0x654aa0: d0 = 0.000000
    //     0x654aa0: eor             v0.16b, v0.16b, v0.16b
    // 0x654aa4: cmp             x1, #2
    // 0x654aa8: b.gt            #0x654b5c
    // 0x654aac: ldr             x0, [fp, #0x20]
    // 0x654ab0: LoadField: r1 = r0->field_53
    //     0x654ab0: ldur            w1, [x0, #0x53]
    // 0x654ab4: DecompressPointer r1
    //     0x654ab4: add             x1, x1, HEAP, lsl #32
    // 0x654ab8: cmp             w1, NULL
    // 0x654abc: b.eq            #0x654cc0
    // 0x654ac0: r1 = LoadClassIdInstr(r0)
    //     0x654ac0: ldur            x1, [x0, #-1]
    //     0x654ac4: ubfx            x1, x1, #0xc, #0x14
    // 0x654ac8: lsl             x1, x1, #1
    // 0x654acc: r17 = 5112
    //     0x654acc: mov             x17, #0x13f8
    // 0x654ad0: cmp             w1, w17
    // 0x654ad4: b.eq            #0x654ae4
    // 0x654ad8: r17 = 5118
    //     0x654ad8: mov             x17, #0x13fe
    // 0x654adc: cmp             w1, w17
    // 0x654ae0: b.ne            #0x654b04
    // 0x654ae4: LoadField: r1 = r0->field_83
    //     0x654ae4: ldur            w1, [x0, #0x83]
    // 0x654ae8: DecompressPointer r1
    //     0x654ae8: add             x1, x1, HEAP, lsl #32
    // 0x654aec: cmp             w1, NULL
    // 0x654af0: b.ne            #0x654afc
    // 0x654af4: d1 = 0.000000
    //     0x654af4: eor             v1.16b, v1.16b, v1.16b
    // 0x654af8: b               #0x654b2c
    // 0x654afc: LoadField: d1 = r1->field_7
    //     0x654afc: ldur            d1, [x1, #7]
    // 0x654b00: b               #0x654b2c
    // 0x654b04: r17 = 5124
    //     0x654b04: mov             x17, #0x1404
    // 0x654b08: cmp             w1, w17
    // 0x654b0c: b.ne            #0x654b18
    // 0x654b10: d1 = 0.000000
    //     0x654b10: eor             v1.16b, v1.16b, v1.16b
    // 0x654b14: b               #0x654b2c
    // 0x654b18: LoadField: r1 = r0->field_6f
    //     0x654b18: ldur            w1, [x0, #0x6f]
    // 0x654b1c: DecompressPointer r1
    //     0x654b1c: add             x1, x1, HEAP, lsl #32
    // 0x654b20: cmp             w1, NULL
    // 0x654b24: b.eq            #0x654cc4
    // 0x654b28: LoadField: d1 = r1->field_7
    //     0x654b28: ldur            d1, [x1, #7]
    // 0x654b2c: stur            d1, [fp, #-0x10]
    // 0x654b30: r0 = Offset()
    //     0x654b30: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x654b34: d0 = 0.000000
    //     0x654b34: eor             v0.16b, v0.16b, v0.16b
    // 0x654b38: StoreField: r0->field_7 = d0
    //     0x654b38: stur            d0, [x0, #7]
    // 0x654b3c: ldur            d0, [fp, #-0x10]
    // 0x654b40: StoreField: r0->field_f = d0
    //     0x654b40: stur            d0, [x0, #0xf]
    // 0x654b44: ldr             x16, [fp, #0x10]
    // 0x654b48: stp             x0, x16, [SP, #-0x10]!
    // 0x654b4c: r0 = +()
    //     0x654b4c: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x654b50: add             SP, SP, #0x10
    // 0x654b54: mov             x1, x0
    // 0x654b58: b               #0x654c44
    // 0x654b5c: ldr             x0, [fp, #0x20]
    // 0x654b60: LoadField: r1 = r0->field_4f
    //     0x654b60: ldur            w1, [x0, #0x4f]
    // 0x654b64: DecompressPointer r1
    //     0x654b64: add             x1, x1, HEAP, lsl #32
    // 0x654b68: cmp             w1, NULL
    // 0x654b6c: b.eq            #0x654cc8
    // 0x654b70: LoadField: d1 = r1->field_17
    //     0x654b70: ldur            d1, [x1, #0x17]
    // 0x654b74: LoadField: r1 = r0->field_53
    //     0x654b74: ldur            w1, [x0, #0x53]
    // 0x654b78: DecompressPointer r1
    //     0x654b78: add             x1, x1, HEAP, lsl #32
    // 0x654b7c: cmp             w1, NULL
    // 0x654b80: b.eq            #0x654ccc
    // 0x654b84: r1 = LoadClassIdInstr(r0)
    //     0x654b84: ldur            x1, [x0, #-1]
    //     0x654b88: ubfx            x1, x1, #0xc, #0x14
    // 0x654b8c: lsl             x1, x1, #1
    // 0x654b90: r17 = 5112
    //     0x654b90: mov             x17, #0x13f8
    // 0x654b94: cmp             w1, w17
    // 0x654b98: b.eq            #0x654ba8
    // 0x654b9c: r17 = 5118
    //     0x654b9c: mov             x17, #0x13fe
    // 0x654ba0: cmp             w1, w17
    // 0x654ba4: b.ne            #0x654bc8
    // 0x654ba8: LoadField: r1 = r0->field_83
    //     0x654ba8: ldur            w1, [x0, #0x83]
    // 0x654bac: DecompressPointer r1
    //     0x654bac: add             x1, x1, HEAP, lsl #32
    // 0x654bb0: cmp             w1, NULL
    // 0x654bb4: b.ne            #0x654bc0
    // 0x654bb8: d2 = 0.000000
    //     0x654bb8: eor             v2.16b, v2.16b, v2.16b
    // 0x654bbc: b               #0x654bf0
    // 0x654bc0: LoadField: d2 = r1->field_7
    //     0x654bc0: ldur            d2, [x1, #7]
    // 0x654bc4: b               #0x654bf0
    // 0x654bc8: r17 = 5124
    //     0x654bc8: mov             x17, #0x1404
    // 0x654bcc: cmp             w1, w17
    // 0x654bd0: b.ne            #0x654bdc
    // 0x654bd4: d2 = 0.000000
    //     0x654bd4: eor             v2.16b, v2.16b, v2.16b
    // 0x654bd8: b               #0x654bf0
    // 0x654bdc: LoadField: r1 = r0->field_6f
    //     0x654bdc: ldur            w1, [x0, #0x6f]
    // 0x654be0: DecompressPointer r1
    //     0x654be0: add             x1, x1, HEAP, lsl #32
    // 0x654be4: cmp             w1, NULL
    // 0x654be8: b.eq            #0x654cd0
    // 0x654bec: LoadField: d2 = r1->field_7
    //     0x654bec: ldur            d2, [x1, #7]
    // 0x654bf0: fsub            d3, d1, d2
    // 0x654bf4: stur            d3, [fp, #-0x10]
    // 0x654bf8: SaveReg r0
    //     0x654bf8: str             x0, [SP, #-8]!
    // 0x654bfc: r0 = childExtent()
    //     0x654bfc: bl              #0x642fa4  ; [package:flutter/src/rendering/sliver_persistent_header.dart] RenderSliverPersistentHeader::childExtent
    // 0x654c00: add             SP, SP, #8
    // 0x654c04: cmp             w0, NULL
    // 0x654c08: b.eq            #0x654cd4
    // 0x654c0c: LoadField: d0 = r0->field_7
    //     0x654c0c: ldur            d0, [x0, #7]
    // 0x654c10: ldur            d1, [fp, #-0x10]
    // 0x654c14: fsub            d2, d1, d0
    // 0x654c18: stur            d2, [fp, #-0x18]
    // 0x654c1c: r0 = Offset()
    //     0x654c1c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x654c20: ldur            d0, [fp, #-0x18]
    // 0x654c24: StoreField: r0->field_7 = d0
    //     0x654c24: stur            d0, [x0, #7]
    // 0x654c28: d0 = 0.000000
    //     0x654c28: eor             v0.16b, v0.16b, v0.16b
    // 0x654c2c: StoreField: r0->field_f = d0
    //     0x654c2c: stur            d0, [x0, #0xf]
    // 0x654c30: ldr             x16, [fp, #0x10]
    // 0x654c34: stp             x0, x16, [SP, #-0x10]!
    // 0x654c38: r0 = +()
    //     0x654c38: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x654c3c: add             SP, SP, #0x10
    // 0x654c40: mov             x1, x0
    // 0x654c44: ldr             x0, [fp, #0x20]
    // 0x654c48: LoadField: r2 = r0->field_53
    //     0x654c48: ldur            w2, [x0, #0x53]
    // 0x654c4c: DecompressPointer r2
    //     0x654c4c: add             x2, x2, HEAP, lsl #32
    // 0x654c50: cmp             w2, NULL
    // 0x654c54: b.eq            #0x654cd8
    // 0x654c58: ldr             x16, [fp, #0x18]
    // 0x654c5c: stp             x2, x16, [SP, #-0x10]!
    // 0x654c60: SaveReg r1
    //     0x654c60: str             x1, [SP, #-8]!
    // 0x654c64: r0 = paintChild()
    //     0x654c64: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x654c68: add             SP, SP, #0x18
    // 0x654c6c: r0 = Null
    //     0x654c6c: mov             x0, NULL
    // 0x654c70: LeaveFrame
    //     0x654c70: mov             SP, fp
    //     0x654c74: ldp             fp, lr, [SP], #0x10
    // 0x654c78: ret
    //     0x654c78: ret             
    // 0x654c7c: r0 = StateError()
    //     0x654c7c: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x654c80: mov             x1, x0
    // 0x654c84: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x654c84: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x654c88: ldr             x0, [x0, #0x1e8]
    // 0x654c8c: StoreField: r1->field_b = r0
    //     0x654c8c: stur            w0, [x1, #0xb]
    // 0x654c90: mov             x0, x1
    // 0x654c94: r0 = Throw()
    //     0x654c94: bl              #0xd67e38  ; ThrowStub
    // 0x654c98: brk             #0
    // 0x654c9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x654c9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x654ca0: b               #0x654858
    // 0x654ca4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x654ca4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x654ca8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x654ca8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x654cac: r0 = NullCastErrorSharedWithFPURegs()
    //     0x654cac: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x654cb0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x654cb0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x654cb4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x654cb4: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x654cb8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x654cb8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x654cbc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x654cbc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x654cc0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x654cc0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x654cc4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x654cc4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x654cc8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x654cc8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x654ccc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x654ccc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x654cd0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x654cd0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x654cd4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x654cd4: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x654cd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x654cd8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ layoutChild(/* No info */) {
    // ** addr: 0x6887dc, size: 0x6a8
    // 0x6887dc: EnterFrame
    //     0x6887dc: stp             fp, lr, [SP, #-0x10]!
    //     0x6887e0: mov             fp, SP
    // 0x6887e4: AllocStack(0x38)
    //     0x6887e4: sub             SP, SP, #0x38
    // 0x6887e8: SetupParameters(RenderSliverPersistentHeader this /* r3, fp-0x18 */, dynamic _ /* r4, fp-0x10 */, dynamic _ /* d0, fp-0x28 */, {dynamic overlapsContent = false /* r0, fp-0x8 */})
    //     0x6887e8: mov             x0, x4
    //     0x6887ec: ldur            w1, [x0, #0x13]
    //     0x6887f0: add             x1, x1, HEAP, lsl #32
    //     0x6887f4: sub             x2, x1, #6
    //     0x6887f8: add             x3, fp, w2, sxtw #2
    //     0x6887fc: ldr             x3, [x3, #0x20]
    //     0x688800: stur            x3, [fp, #-0x18]
    //     0x688804: add             x4, fp, w2, sxtw #2
    //     0x688808: ldr             x4, [x4, #0x18]
    //     0x68880c: stur            x4, [fp, #-0x10]
    //     0x688810: add             x5, fp, w2, sxtw #2
    //     0x688814: ldr             d0, [x5, #0x10]
    //     0x688818: stur            d0, [fp, #-0x28]
    //     0x68881c: ldur            w2, [x0, #0x1f]
    //     0x688820: add             x2, x2, HEAP, lsl #32
    //     0x688824: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4faa0] "overlapsContent"
    //     0x688828: ldr             x16, [x16, #0xaa0]
    //     0x68882c: cmp             w2, w16
    //     0x688830: b.ne            #0x688850
    //     0x688834: ldur            w2, [x0, #0x23]
    //     0x688838: add             x2, x2, HEAP, lsl #32
    //     0x68883c: sub             w0, w1, w2
    //     0x688840: add             x1, fp, w0, sxtw #2
    //     0x688844: ldr             x1, [x1, #8]
    //     0x688848: mov             x0, x1
    //     0x68884c: b               #0x688854
    //     0x688850: add             x0, NULL, #0x30  ; false
    //     0x688854: stur            x0, [fp, #-8]
    // 0x688858: CheckStackOverflow
    //     0x688858: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68885c: cmp             SP, x16
    //     0x688860: b.ls            #0x688dc8
    // 0x688864: r1 = 3
    //     0x688864: mov             x1, #3
    // 0x688868: r0 = AllocateContext()
    //     0x688868: bl              #0xd68aa4  ; AllocateContextStub
    // 0x68886c: mov             x1, x0
    // 0x688870: ldur            x0, [fp, #-0x18]
    // 0x688874: stur            x1, [fp, #-0x20]
    // 0x688878: StoreField: r1->field_f = r0
    //     0x688878: stur            w0, [x1, #0xf]
    // 0x68887c: ldur            x2, [fp, #-8]
    // 0x688880: StoreField: r1->field_13 = r2
    //     0x688880: stur            w2, [x1, #0x13]
    // 0x688884: ldur            x2, [fp, #-0x10]
    // 0x688888: LoadField: d0 = r2->field_7
    //     0x688888: ldur            d0, [x2, #7]
    // 0x68888c: ldur            d1, [fp, #-0x28]
    // 0x688890: fcmp            d0, d1
    // 0x688894: b.vs            #0x6888ac
    // 0x688898: b.le            #0x6888ac
    // 0x68889c: mov             x2, x1
    // 0x6888a0: mov             x1, x0
    // 0x6888a4: mov             v0.16b, v1.16b
    // 0x6888a8: b               #0x688988
    // 0x6888ac: fcmp            d0, d1
    // 0x6888b0: b.vs            #0x6888d4
    // 0x6888b4: b.ge            #0x6888d4
    // 0x6888b8: LoadField: d0 = r2->field_7
    //     0x6888b8: ldur            d0, [x2, #7]
    // 0x6888bc: mov             v31.16b, v1.16b
    // 0x6888c0: mov             v1.16b, v0.16b
    // 0x6888c4: mov             v0.16b, v31.16b
    // 0x6888c8: mov             x2, x1
    // 0x6888cc: mov             x1, x0
    // 0x6888d0: b               #0x688988
    // 0x6888d4: d2 = 0.000000
    //     0x6888d4: eor             v2.16b, v2.16b, v2.16b
    // 0x6888d8: fcmp            d0, d2
    // 0x6888dc: b.vs            #0x6888e4
    // 0x6888e0: b.eq            #0x6888ec
    // 0x6888e4: r3 = false
    //     0x6888e4: add             x3, NULL, #0x30  ; false
    // 0x6888e8: b               #0x6888f0
    // 0x6888ec: r3 = true
    //     0x6888ec: add             x3, NULL, #0x20  ; true
    // 0x6888f0: tbnz            w3, #4, #0x688918
    // 0x6888f4: fadd            d3, d0, d1
    // 0x6888f8: fmul            d4, d3, d0
    // 0x6888fc: fmul            d0, d4, d1
    // 0x688900: mov             v31.16b, v1.16b
    // 0x688904: mov             v1.16b, v0.16b
    // 0x688908: mov             v0.16b, v31.16b
    // 0x68890c: mov             x2, x1
    // 0x688910: mov             x1, x0
    // 0x688914: b               #0x688988
    // 0x688918: tbnz            w3, #4, #0x68895c
    // 0x68891c: r3 = inline_Allocate_Double()
    //     0x68891c: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x688920: add             x3, x3, #0x10
    //     0x688924: cmp             x4, x3
    //     0x688928: b.ls            #0x688dd0
    //     0x68892c: str             x3, [THR, #0x60]  ; THR::top
    //     0x688930: sub             x3, x3, #0xf
    //     0x688934: mov             x4, #0xd108
    //     0x688938: movk            x4, #3, lsl #16
    //     0x68893c: stur            x4, [x3, #-1]
    // 0x688940: StoreField: r3->field_7 = d1
    //     0x688940: stur            d1, [x3, #7]
    // 0x688944: SaveReg r3
    //     0x688944: str             x3, [SP, #-8]!
    // 0x688948: r0 = isNegative()
    //     0x688948: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x68894c: add             SP, SP, #8
    // 0x688950: tbnz            w0, #4, #0x68895c
    // 0x688954: ldur            d0, [fp, #-0x28]
    // 0x688958: b               #0x688968
    // 0x68895c: ldur            d0, [fp, #-0x28]
    // 0x688960: fcmp            d0, d0
    // 0x688964: b.vc            #0x688978
    // 0x688968: mov             v1.16b, v0.16b
    // 0x68896c: ldur            x1, [fp, #-0x18]
    // 0x688970: ldur            x2, [fp, #-0x20]
    // 0x688974: b               #0x688988
    // 0x688978: ldur            x0, [fp, #-0x10]
    // 0x68897c: LoadField: d1 = r0->field_7
    //     0x68897c: ldur            d1, [x0, #7]
    // 0x688980: ldur            x1, [fp, #-0x18]
    // 0x688984: ldur            x2, [fp, #-0x20]
    // 0x688988: stur            d1, [fp, #-0x30]
    // 0x68898c: r0 = inline_Allocate_Double()
    //     0x68898c: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x688990: add             x0, x0, #0x10
    //     0x688994: cmp             x3, x0
    //     0x688998: b.ls            #0x688df4
    //     0x68899c: str             x0, [THR, #0x60]  ; THR::top
    //     0x6889a0: sub             x0, x0, #0xf
    //     0x6889a4: mov             x3, #0xd108
    //     0x6889a8: movk            x3, #3, lsl #16
    //     0x6889ac: stur            x3, [x0, #-1]
    // 0x6889b0: StoreField: r0->field_7 = d1
    //     0x6889b0: stur            d1, [x0, #7]
    // 0x6889b4: StoreField: r2->field_17 = r0
    //     0x6889b4: stur            w0, [x2, #0x17]
    //     0x6889b8: ldurb           w16, [x2, #-1]
    //     0x6889bc: ldurb           w17, [x0, #-1]
    //     0x6889c0: and             x16, x17, x16, lsr #2
    //     0x6889c4: tst             x16, HEAP, lsr #32
    //     0x6889c8: b.eq            #0x6889d0
    //     0x6889cc: bl              #0xd6828c
    // 0x6889d0: LoadField: r0 = r1->field_5b
    //     0x6889d0: ldur            w0, [x1, #0x5b]
    // 0x6889d4: DecompressPointer r0
    //     0x6889d4: add             x0, x0, HEAP, lsl #32
    // 0x6889d8: tbnz            w0, #4, #0x6889ec
    // 0x6889dc: mov             x0, x1
    // 0x6889e0: mov             x3, x2
    // 0x6889e4: mov             v0.16b, v1.16b
    // 0x6889e8: b               #0x688a84
    // 0x6889ec: LoadField: d2 = r1->field_5f
    //     0x6889ec: ldur            d2, [x1, #0x5f]
    // 0x6889f0: r0 = inline_Allocate_Double()
    //     0x6889f0: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x6889f4: add             x0, x0, #0x10
    //     0x6889f8: cmp             x3, x0
    //     0x6889fc: b.ls            #0x688e0c
    //     0x688a00: str             x0, [THR, #0x60]  ; THR::top
    //     0x688a04: sub             x0, x0, #0xf
    //     0x688a08: mov             x3, #0xd108
    //     0x688a0c: movk            x3, #3, lsl #16
    //     0x688a10: stur            x3, [x0, #-1]
    // 0x688a14: StoreField: r0->field_7 = d2
    //     0x688a14: stur            d2, [x0, #7]
    // 0x688a18: r3 = inline_Allocate_Double()
    //     0x688a18: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x688a1c: add             x3, x3, #0x10
    //     0x688a20: cmp             x4, x3
    //     0x688a24: b.ls            #0x688e2c
    //     0x688a28: str             x3, [THR, #0x60]  ; THR::top
    //     0x688a2c: sub             x3, x3, #0xf
    //     0x688a30: mov             x4, #0xd108
    //     0x688a34: movk            x4, #3, lsl #16
    //     0x688a38: stur            x4, [x3, #-1]
    // 0x688a3c: StoreField: r3->field_7 = d1
    //     0x688a3c: stur            d1, [x3, #7]
    // 0x688a40: stp             x3, x0, [SP, #-0x10]!
    // 0x688a44: r0 = ==()
    //     0x688a44: bl              #0xcbbae4  ; [dart:core] _Double::==
    // 0x688a48: add             SP, SP, #0x10
    // 0x688a4c: tbz             w0, #4, #0x688a60
    // 0x688a50: ldur            x0, [fp, #-0x18]
    // 0x688a54: ldur            x3, [fp, #-0x20]
    // 0x688a58: ldur            d0, [fp, #-0x30]
    // 0x688a5c: b               #0x688a84
    // 0x688a60: ldur            x0, [fp, #-0x18]
    // 0x688a64: ldur            x3, [fp, #-0x20]
    // 0x688a68: LoadField: r1 = r0->field_67
    //     0x688a68: ldur            w1, [x0, #0x67]
    // 0x688a6c: DecompressPointer r1
    //     0x688a6c: add             x1, x1, HEAP, lsl #32
    // 0x688a70: LoadField: r2 = r3->field_13
    //     0x688a70: ldur            w2, [x3, #0x13]
    // 0x688a74: DecompressPointer r2
    //     0x688a74: add             x2, x2, HEAP, lsl #32
    // 0x688a78: cmp             w1, w2
    // 0x688a7c: b.eq            #0x688af8
    // 0x688a80: ldur            d0, [fp, #-0x30]
    // 0x688a84: mov             x2, x3
    // 0x688a88: r1 = Function '<anonymous closure>':.
    //     0x688a88: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4faa8] AnonymousClosure: (0x688e84), in [package:flutter/src/rendering/sliver_persistent_header.dart] RenderSliverPersistentHeader::layoutChild (0x6887dc)
    //     0x688a8c: ldr             x1, [x1, #0xaa8]
    // 0x688a90: r0 = AllocateClosure()
    //     0x688a90: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x688a94: r16 = <SliverConstraints>
    //     0x688a94: add             x16, PP, #0x43, lsl #12  ; [pp+0x43478] TypeArguments: <SliverConstraints>
    //     0x688a98: ldr             x16, [x16, #0x478]
    // 0x688a9c: ldur            lr, [fp, #-0x18]
    // 0x688aa0: stp             lr, x16, [SP, #-0x10]!
    // 0x688aa4: SaveReg r0
    //     0x688aa4: str             x0, [SP, #-8]!
    // 0x688aa8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x688aa8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x688aac: r0 = invokeLayoutCallback()
    //     0x688aac: bl              #0x678254  ; [package:flutter/src/rendering/object.dart] RenderObject::invokeLayoutCallback
    // 0x688ab0: add             SP, SP, #0x18
    // 0x688ab4: ldur            x3, [fp, #-0x18]
    // 0x688ab8: ldur            d0, [fp, #-0x30]
    // 0x688abc: StoreField: r3->field_5f = d0
    //     0x688abc: stur            d0, [x3, #0x5f]
    // 0x688ac0: ldur            x0, [fp, #-0x20]
    // 0x688ac4: LoadField: r1 = r0->field_13
    //     0x688ac4: ldur            w1, [x0, #0x13]
    // 0x688ac8: DecompressPointer r1
    //     0x688ac8: add             x1, x1, HEAP, lsl #32
    // 0x688acc: mov             x0, x1
    // 0x688ad0: StoreField: r3->field_67 = r0
    //     0x688ad0: stur            w0, [x3, #0x67]
    //     0x688ad4: ldurb           w16, [x3, #-1]
    //     0x688ad8: ldurb           w17, [x0, #-1]
    //     0x688adc: and             x16, x17, x16, lsr #2
    //     0x688ae0: tst             x16, HEAP, lsr #32
    //     0x688ae4: b.eq            #0x688aec
    //     0x688ae8: bl              #0xd682ac
    // 0x688aec: r0 = false
    //     0x688aec: add             x0, NULL, #0x30  ; false
    // 0x688af0: StoreField: r3->field_5b = r0
    //     0x688af0: stur            w0, [x3, #0x5b]
    // 0x688af4: b               #0x688b00
    // 0x688af8: mov             x3, x0
    // 0x688afc: ldur            d0, [fp, #-0x30]
    // 0x688b00: LoadField: r0 = r3->field_6b
    //     0x688b00: ldur            w0, [x3, #0x6b]
    // 0x688b04: DecompressPointer r0
    //     0x688b04: add             x0, x0, HEAP, lsl #32
    // 0x688b08: cmp             w0, NULL
    // 0x688b0c: b.eq            #0x688bac
    // 0x688b10: LoadField: r4 = r3->field_27
    //     0x688b10: ldur            w4, [x3, #0x27]
    // 0x688b14: DecompressPointer r4
    //     0x688b14: add             x4, x4, HEAP, lsl #32
    // 0x688b18: stur            x4, [fp, #-8]
    // 0x688b1c: cmp             w4, NULL
    // 0x688b20: b.eq            #0x688d90
    // 0x688b24: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x688b24: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x688b28: ldr             x5, [x5, #0x1e8]
    // 0x688b2c: mov             x0, x4
    // 0x688b30: r2 = Null
    //     0x688b30: mov             x2, NULL
    // 0x688b34: r1 = Null
    //     0x688b34: mov             x1, NULL
    // 0x688b38: r4 = LoadClassIdInstr(r0)
    //     0x688b38: ldur            x4, [x0, #-1]
    //     0x688b3c: ubfx            x4, x4, #0xc, #0x14
    // 0x688b40: cmp             x4, #0x80c
    // 0x688b44: b.eq            #0x688b5c
    // 0x688b48: r8 = SliverConstraints
    //     0x688b48: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x688b4c: ldr             x8, [x8, #0x5a8]
    // 0x688b50: r3 = Null
    //     0x688b50: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fab0] Null
    //     0x688b54: ldr             x3, [x3, #0xab0]
    // 0x688b58: r0 = DefaultTypeTest()
    //     0x688b58: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x688b5c: ldur            x0, [fp, #-8]
    // 0x688b60: LoadField: d0 = r0->field_13
    //     0x688b60: ldur            d0, [x0, #0x13]
    // 0x688b64: d1 = 0.000000
    //     0x688b64: eor             v1.16b, v1.16b, v1.16b
    // 0x688b68: fcmp            d0, d1
    // 0x688b6c: b.vs            #0x688bb0
    // 0x688b70: b.ne            #0x688bb0
    // 0x688b74: LoadField: d0 = r0->field_23
    //     0x688b74: ldur            d0, [x0, #0x23]
    // 0x688b78: fcmp            d0, d1
    // 0x688b7c: b.vs            #0x688b8c
    // 0x688b80: b.ne            #0x688b8c
    // 0x688b84: d0 = 0.000000
    //     0x688b84: eor             v0.16b, v0.16b, v0.16b
    // 0x688b88: b               #0x688ba0
    // 0x688b8c: fcmp            d0, d1
    // 0x688b90: b.vs            #0x688ba0
    // 0x688b94: b.ge            #0x688ba0
    // 0x688b98: fneg            d2, d0
    // 0x688b9c: mov             v0.16b, v2.16b
    // 0x688ba0: fadd            d2, d1, d0
    // 0x688ba4: mov             v0.16b, v2.16b
    // 0x688ba8: b               #0x688bb4
    // 0x688bac: d1 = 0.000000
    //     0x688bac: eor             v1.16b, v1.16b, v1.16b
    // 0x688bb0: d0 = 0.000000
    //     0x688bb0: eor             v0.16b, v0.16b, v0.16b
    // 0x688bb4: ldur            x3, [fp, #-0x18]
    // 0x688bb8: stur            d0, [fp, #-0x38]
    // 0x688bbc: LoadField: r4 = r3->field_53
    //     0x688bbc: ldur            w4, [x3, #0x53]
    // 0x688bc0: DecompressPointer r4
    //     0x688bc0: add             x4, x4, HEAP, lsl #32
    // 0x688bc4: stur            x4, [fp, #-0x10]
    // 0x688bc8: cmp             w4, NULL
    // 0x688bcc: b.ne            #0x688bd8
    // 0x688bd0: mov             x1, x3
    // 0x688bd4: b               #0x688d3c
    // 0x688bd8: LoadField: r5 = r3->field_27
    //     0x688bd8: ldur            w5, [x3, #0x27]
    // 0x688bdc: DecompressPointer r5
    //     0x688bdc: add             x5, x5, HEAP, lsl #32
    // 0x688be0: stur            x5, [fp, #-8]
    // 0x688be4: cmp             w5, NULL
    // 0x688be8: b.eq            #0x688da8
    // 0x688bec: ldur            d3, [fp, #-0x28]
    // 0x688bf0: ldur            d2, [fp, #-0x30]
    // 0x688bf4: mov             x0, x5
    // 0x688bf8: r2 = Null
    //     0x688bf8: mov             x2, NULL
    // 0x688bfc: r1 = Null
    //     0x688bfc: mov             x1, NULL
    // 0x688c00: r4 = LoadClassIdInstr(r0)
    //     0x688c00: ldur            x4, [x0, #-1]
    //     0x688c04: ubfx            x4, x4, #0xc, #0x14
    // 0x688c08: cmp             x4, #0x80c
    // 0x688c0c: b.eq            #0x688c24
    // 0x688c10: r8 = SliverConstraints
    //     0x688c10: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x688c14: ldr             x8, [x8, #0x5a8]
    // 0x688c18: r3 = Null
    //     0x688c18: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fac0] Null
    //     0x688c1c: ldr             x3, [x3, #0xac0]
    // 0x688c20: r0 = DefaultTypeTest()
    //     0x688c20: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x688c24: ldur            x1, [fp, #-0x18]
    // 0x688c28: r0 = LoadClassIdInstr(r1)
    //     0x688c28: ldur            x0, [x1, #-1]
    //     0x688c2c: ubfx            x0, x0, #0xc, #0x14
    // 0x688c30: SaveReg r1
    //     0x688c30: str             x1, [SP, #-8]!
    // 0x688c34: r0 = GDT[cid_x0 + 0x543]()
    //     0x688c34: add             lr, x0, #0x543
    //     0x688c38: ldr             lr, [x21, lr, lsl #3]
    //     0x688c3c: blr             lr
    // 0x688c40: add             SP, SP, #8
    // 0x688c44: mov             v2.16b, v0.16b
    // 0x688c48: ldur            d1, [fp, #-0x28]
    // 0x688c4c: ldur            d0, [fp, #-0x30]
    // 0x688c50: fsub            d3, d1, d0
    // 0x688c54: fcmp            d2, d3
    // 0x688c58: b.vs            #0x688c68
    // 0x688c5c: b.le            #0x688c68
    // 0x688c60: mov             v1.16b, v2.16b
    // 0x688c64: b               #0x688cac
    // 0x688c68: fcmp            d2, d3
    // 0x688c6c: b.vs            #0x688c7c
    // 0x688c70: b.ge            #0x688c7c
    // 0x688c74: mov             v1.16b, v3.16b
    // 0x688c78: b               #0x688cac
    // 0x688c7c: d0 = 0.000000
    //     0x688c7c: eor             v0.16b, v0.16b, v0.16b
    // 0x688c80: fcmp            d2, d0
    // 0x688c84: b.vs            #0x688c98
    // 0x688c88: b.ne            #0x688c98
    // 0x688c8c: fadd            d0, d2, d3
    // 0x688c90: mov             v1.16b, v0.16b
    // 0x688c94: b               #0x688cac
    // 0x688c98: fcmp            d3, d3
    // 0x688c9c: b.vc            #0x688ca8
    // 0x688ca0: mov             v1.16b, v3.16b
    // 0x688ca4: b               #0x688cac
    // 0x688ca8: mov             v1.16b, v2.16b
    // 0x688cac: ldur            d0, [fp, #-0x38]
    // 0x688cb0: ldur            x0, [fp, #-0x10]
    // 0x688cb4: fadd            d2, d1, d0
    // 0x688cb8: r1 = inline_Allocate_Double()
    //     0x688cb8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x688cbc: add             x1, x1, #0x10
    //     0x688cc0: cmp             x2, x1
    //     0x688cc4: b.ls            #0x688e50
    //     0x688cc8: str             x1, [THR, #0x60]  ; THR::top
    //     0x688ccc: sub             x1, x1, #0xf
    //     0x688cd0: mov             x2, #0xd108
    //     0x688cd4: movk            x2, #3, lsl #16
    //     0x688cd8: stur            x2, [x1, #-1]
    // 0x688cdc: StoreField: r1->field_7 = d2
    //     0x688cdc: stur            d2, [x1, #7]
    // 0x688ce0: ldur            x16, [fp, #-8]
    // 0x688ce4: stp             x1, x16, [SP, #-0x10]!
    // 0x688ce8: r4 = const [0, 0x2, 0x2, 0x1, maxExtent, 0x1, null]
    //     0x688ce8: add             x4, PP, #0x42, lsl #12  ; [pp+0x42ab0] List(7) [0, 0x2, 0x2, 0x1, "maxExtent", 0x1, Null]
    //     0x688cec: ldr             x4, [x4, #0xab0]
    // 0x688cf0: r0 = asBoxConstraints()
    //     0x688cf0: bl              #0x67a528  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::asBoxConstraints
    // 0x688cf4: add             SP, SP, #0x10
    // 0x688cf8: mov             x1, x0
    // 0x688cfc: ldur            x0, [fp, #-0x10]
    // 0x688d00: r2 = LoadClassIdInstr(r0)
    //     0x688d00: ldur            x2, [x0, #-1]
    //     0x688d04: ubfx            x2, x2, #0xc, #0x14
    // 0x688d08: stp             x1, x0, [SP, #-0x10]!
    // 0x688d0c: r16 = true
    //     0x688d0c: add             x16, NULL, #0x20  ; true
    // 0x688d10: SaveReg r16
    //     0x688d10: str             x16, [SP, #-8]!
    // 0x688d14: mov             x0, x2
    // 0x688d18: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x688d18: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x688d1c: ldr             x4, [x4, #0x1c8]
    // 0x688d20: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x688d20: mov             x17, #0xcdfb
    //     0x688d24: add             lr, x0, x17
    //     0x688d28: ldr             lr, [x21, lr, lsl #3]
    //     0x688d2c: blr             lr
    // 0x688d30: add             SP, SP, #0x18
    // 0x688d34: ldur            x1, [fp, #-0x18]
    // 0x688d38: ldur            d0, [fp, #-0x38]
    // 0x688d3c: r0 = inline_Allocate_Double()
    //     0x688d3c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x688d40: add             x0, x0, #0x10
    //     0x688d44: cmp             x2, x0
    //     0x688d48: b.ls            #0x688e6c
    //     0x688d4c: str             x0, [THR, #0x60]  ; THR::top
    //     0x688d50: sub             x0, x0, #0xf
    //     0x688d54: mov             x2, #0xd108
    //     0x688d58: movk            x2, #3, lsl #16
    //     0x688d5c: stur            x2, [x0, #-1]
    // 0x688d60: StoreField: r0->field_7 = d0
    //     0x688d60: stur            d0, [x0, #7]
    // 0x688d64: StoreField: r1->field_57 = r0
    //     0x688d64: stur            w0, [x1, #0x57]
    //     0x688d68: ldurb           w16, [x1, #-1]
    //     0x688d6c: ldurb           w17, [x0, #-1]
    //     0x688d70: and             x16, x17, x16, lsr #2
    //     0x688d74: tst             x16, HEAP, lsr #32
    //     0x688d78: b.eq            #0x688d80
    //     0x688d7c: bl              #0xd6826c
    // 0x688d80: r0 = Null
    //     0x688d80: mov             x0, NULL
    // 0x688d84: LeaveFrame
    //     0x688d84: mov             SP, fp
    //     0x688d88: ldp             fp, lr, [SP], #0x10
    // 0x688d8c: ret
    //     0x688d8c: ret             
    // 0x688d90: r0 = StateError()
    //     0x688d90: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x688d94: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x688d94: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x688d98: ldr             x5, [x5, #0x1e8]
    // 0x688d9c: StoreField: r0->field_b = r5
    //     0x688d9c: stur            w5, [x0, #0xb]
    // 0x688da0: r0 = Throw()
    //     0x688da0: bl              #0xd67e38  ; ThrowStub
    // 0x688da4: brk             #0
    // 0x688da8: r0 = StateError()
    //     0x688da8: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x688dac: mov             x1, x0
    // 0x688db0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x688db0: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x688db4: ldr             x0, [x0, #0x1e8]
    // 0x688db8: StoreField: r1->field_b = r0
    //     0x688db8: stur            w0, [x1, #0xb]
    // 0x688dbc: mov             x0, x1
    // 0x688dc0: r0 = Throw()
    //     0x688dc0: bl              #0xd67e38  ; ThrowStub
    // 0x688dc4: brk             #0
    // 0x688dc8: r0 = StackOverflowSharedWithFPURegs()
    //     0x688dc8: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x688dcc: b               #0x688864
    // 0x688dd0: stp             q1, q2, [SP, #-0x20]!
    // 0x688dd4: stp             x1, x2, [SP, #-0x10]!
    // 0x688dd8: SaveReg r0
    //     0x688dd8: str             x0, [SP, #-8]!
    // 0x688ddc: r0 = AllocateDouble()
    //     0x688ddc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x688de0: mov             x3, x0
    // 0x688de4: RestoreReg r0
    //     0x688de4: ldr             x0, [SP], #8
    // 0x688de8: ldp             x1, x2, [SP], #0x10
    // 0x688dec: ldp             q1, q2, [SP], #0x20
    // 0x688df0: b               #0x688940
    // 0x688df4: stp             q0, q1, [SP, #-0x20]!
    // 0x688df8: stp             x1, x2, [SP, #-0x10]!
    // 0x688dfc: r0 = AllocateDouble()
    //     0x688dfc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x688e00: ldp             x1, x2, [SP], #0x10
    // 0x688e04: ldp             q0, q1, [SP], #0x20
    // 0x688e08: b               #0x6889b0
    // 0x688e0c: stp             q1, q2, [SP, #-0x20]!
    // 0x688e10: SaveReg d0
    //     0x688e10: str             q0, [SP, #-0x10]!
    // 0x688e14: stp             x1, x2, [SP, #-0x10]!
    // 0x688e18: r0 = AllocateDouble()
    //     0x688e18: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x688e1c: ldp             x1, x2, [SP], #0x10
    // 0x688e20: RestoreReg d0
    //     0x688e20: ldr             q0, [SP], #0x10
    // 0x688e24: ldp             q1, q2, [SP], #0x20
    // 0x688e28: b               #0x688a14
    // 0x688e2c: stp             q0, q1, [SP, #-0x20]!
    // 0x688e30: stp             x1, x2, [SP, #-0x10]!
    // 0x688e34: SaveReg r0
    //     0x688e34: str             x0, [SP, #-8]!
    // 0x688e38: r0 = AllocateDouble()
    //     0x688e38: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x688e3c: mov             x3, x0
    // 0x688e40: RestoreReg r0
    //     0x688e40: ldr             x0, [SP], #8
    // 0x688e44: ldp             x1, x2, [SP], #0x10
    // 0x688e48: ldp             q0, q1, [SP], #0x20
    // 0x688e4c: b               #0x688a3c
    // 0x688e50: stp             q0, q2, [SP, #-0x20]!
    // 0x688e54: SaveReg r0
    //     0x688e54: str             x0, [SP, #-8]!
    // 0x688e58: r0 = AllocateDouble()
    //     0x688e58: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x688e5c: mov             x1, x0
    // 0x688e60: RestoreReg r0
    //     0x688e60: ldr             x0, [SP], #8
    // 0x688e64: ldp             q0, q2, [SP], #0x20
    // 0x688e68: b               #0x688cdc
    // 0x688e6c: SaveReg d0
    //     0x688e6c: str             q0, [SP, #-0x10]!
    // 0x688e70: SaveReg r1
    //     0x688e70: str             x1, [SP, #-8]!
    // 0x688e74: r0 = AllocateDouble()
    //     0x688e74: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x688e78: RestoreReg r1
    //     0x688e78: ldr             x1, [SP], #8
    // 0x688e7c: RestoreReg d0
    //     0x688e7c: ldr             q0, [SP], #0x10
    // 0x688e80: b               #0x688d60
  }
  [closure] void <anonymous closure>(dynamic, SliverConstraints) {
    // ** addr: 0x688e84, size: 0x7c
    // 0x688e84: EnterFrame
    //     0x688e84: stp             fp, lr, [SP, #-0x10]!
    //     0x688e88: mov             fp, SP
    // 0x688e8c: ldr             x0, [fp, #0x18]
    // 0x688e90: LoadField: r1 = r0->field_17
    //     0x688e90: ldur            w1, [x0, #0x17]
    // 0x688e94: DecompressPointer r1
    //     0x688e94: add             x1, x1, HEAP, lsl #32
    // 0x688e98: CheckStackOverflow
    //     0x688e98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x688e9c: cmp             SP, x16
    //     0x688ea0: b.ls            #0x688ef8
    // 0x688ea4: LoadField: r0 = r1->field_f
    //     0x688ea4: ldur            w0, [x1, #0xf]
    // 0x688ea8: DecompressPointer r0
    //     0x688ea8: add             x0, x0, HEAP, lsl #32
    // 0x688eac: LoadField: r2 = r1->field_17
    //     0x688eac: ldur            w2, [x1, #0x17]
    // 0x688eb0: DecompressPointer r2
    //     0x688eb0: add             x2, x2, HEAP, lsl #32
    // 0x688eb4: LoadField: r3 = r1->field_13
    //     0x688eb4: ldur            w3, [x1, #0x13]
    // 0x688eb8: DecompressPointer r3
    //     0x688eb8: add             x3, x3, HEAP, lsl #32
    // 0x688ebc: LoadField: d0 = r2->field_7
    //     0x688ebc: ldur            d0, [x2, #7]
    // 0x688ec0: r1 = LoadClassIdInstr(r0)
    //     0x688ec0: ldur            x1, [x0, #-1]
    //     0x688ec4: ubfx            x1, x1, #0xc, #0x14
    // 0x688ec8: SaveReg r0
    //     0x688ec8: str             x0, [SP, #-8]!
    // 0x688ecc: SaveReg d0
    //     0x688ecc: str             d0, [SP, #-8]!
    // 0x688ed0: SaveReg r3
    //     0x688ed0: str             x3, [SP, #-8]!
    // 0x688ed4: mov             x0, x1
    // 0x688ed8: r0 = GDT[cid_x0 + 0x927]()
    //     0x688ed8: add             lr, x0, #0x927
    //     0x688edc: ldr             lr, [x21, lr, lsl #3]
    //     0x688ee0: blr             lr
    // 0x688ee4: add             SP, SP, #0x18
    // 0x688ee8: r0 = Null
    //     0x688ee8: mov             x0, NULL
    // 0x688eec: LeaveFrame
    //     0x688eec: mov             SP, fp
    //     0x688ef0: ldp             fp, lr, [SP], #0x10
    // 0x688ef4: ret
    //     0x688ef4: ret             
    // 0x688ef8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x688ef8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x688efc: b               #0x688ea4
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0x6bbefc, size: 0x7c
    // 0x6bbefc: EnterFrame
    //     0x6bbefc: stp             fp, lr, [SP, #-0x10]!
    //     0x6bbf00: mov             fp, SP
    // 0x6bbf04: CheckStackOverflow
    //     0x6bbf04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bbf08: cmp             SP, x16
    //     0x6bbf0c: b.ls            #0x6bbf70
    // 0x6bbf10: ldr             x0, [fp, #0x18]
    // 0x6bbf14: r2 = Null
    //     0x6bbf14: mov             x2, NULL
    // 0x6bbf18: r1 = Null
    //     0x6bbf18: mov             x1, NULL
    // 0x6bbf1c: r4 = LoadClassIdInstr(r0)
    //     0x6bbf1c: ldur            x4, [x0, #-1]
    //     0x6bbf20: ubfx            x4, x4, #0xc, #0x14
    // 0x6bbf24: sub             x4, x4, #0x965
    // 0x6bbf28: cmp             x4, #0x8b
    // 0x6bbf2c: b.ls            #0x6bbf44
    // 0x6bbf30: r8 = RenderBox
    //     0x6bbf30: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x6bbf34: ldr             x8, [x8, #0xfa0]
    // 0x6bbf38: r3 = Null
    //     0x6bbf38: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4faf8] Null
    //     0x6bbf3c: ldr             x3, [x3, #0xaf8]
    // 0x6bbf40: r0 = RenderBox()
    //     0x6bbf40: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x6bbf44: ldr             x16, [fp, #0x20]
    // 0x6bbf48: ldr             lr, [fp, #0x18]
    // 0x6bbf4c: stp             lr, x16, [SP, #-0x10]!
    // 0x6bbf50: ldr             x16, [fp, #0x10]
    // 0x6bbf54: SaveReg r16
    //     0x6bbf54: str             x16, [SP, #-8]!
    // 0x6bbf58: r0 = applyPaintTransformForBoxChild()
    //     0x6bbf58: bl              #0x6bbf78  ; [package:flutter/src/rendering/sliver_persistent_header.dart] _RenderSliverPersistentHeader&RenderSliver&RenderObjectWithChildMixin&RenderSliverHelpers::applyPaintTransformForBoxChild
    // 0x6bbf5c: add             SP, SP, #0x18
    // 0x6bbf60: r0 = Null
    //     0x6bbf60: mov             x0, NULL
    // 0x6bbf64: LeaveFrame
    //     0x6bbf64: mov             SP, fp
    //     0x6bbf68: ldp             fp, lr, [SP], #0x10
    // 0x6bbf6c: ret
    //     0x6bbf6c: ret             
    // 0x6bbf70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bbf70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bbf74: b               #0x6bbf10
  }
  _ markNeedsLayout(/* No info */) {
    // ** addr: 0x6c0c30, size: 0x44
    // 0x6c0c30: EnterFrame
    //     0x6c0c30: stp             fp, lr, [SP, #-0x10]!
    //     0x6c0c34: mov             fp, SP
    // 0x6c0c38: r0 = true
    //     0x6c0c38: add             x0, NULL, #0x20  ; true
    // 0x6c0c3c: CheckStackOverflow
    //     0x6c0c3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c0c40: cmp             SP, x16
    //     0x6c0c44: b.ls            #0x6c0c6c
    // 0x6c0c48: ldr             x1, [fp, #0x10]
    // 0x6c0c4c: StoreField: r1->field_5b = r0
    //     0x6c0c4c: stur            w0, [x1, #0x5b]
    // 0x6c0c50: SaveReg r1
    //     0x6c0c50: str             x1, [SP, #-8]!
    // 0x6c0c54: r0 = markNeedsLayout()
    //     0x6c0c54: bl              #0x6c0ee8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsLayout
    // 0x6c0c58: add             SP, SP, #8
    // 0x6c0c5c: r0 = Null
    //     0x6c0c5c: mov             x0, NULL
    // 0x6c0c60: LeaveFrame
    //     0x6c0c60: mov             SP, fp
    //     0x6c0c64: ldp             fp, lr, [SP], #0x10
    // 0x6c0c68: ret
    //     0x6c0c68: ret             
    // 0x6c0c6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c0c6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c0c70: b               #0x6c0c48
  }
  _ RenderSliverPersistentHeader(/* No info */) {
    // ** addr: 0x6f5944, size: 0x8c
    // 0x6f5944: EnterFrame
    //     0x6f5944: stp             fp, lr, [SP, #-0x10]!
    //     0x6f5948: mov             fp, SP
    // 0x6f594c: r2 = Sentinel
    //     0x6f594c: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6f5950: r1 = true
    //     0x6f5950: add             x1, NULL, #0x20  ; true
    // 0x6f5954: r0 = false
    //     0x6f5954: add             x0, NULL, #0x30  ; false
    // 0x6f5958: d0 = 0.000000
    //     0x6f5958: eor             v0.16b, v0.16b, v0.16b
    // 0x6f595c: CheckStackOverflow
    //     0x6f595c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f5960: cmp             SP, x16
    //     0x6f5964: b.ls            #0x6f59c8
    // 0x6f5968: ldr             x3, [fp, #0x18]
    // 0x6f596c: StoreField: r3->field_57 = r2
    //     0x6f596c: stur            w2, [x3, #0x57]
    // 0x6f5970: StoreField: r3->field_5b = r1
    //     0x6f5970: stur            w1, [x3, #0x5b]
    // 0x6f5974: StoreField: r3->field_5f = d0
    //     0x6f5974: stur            d0, [x3, #0x5f]
    // 0x6f5978: StoreField: r3->field_67 = r0
    //     0x6f5978: stur            w0, [x3, #0x67]
    // 0x6f597c: ldr             x0, [fp, #0x10]
    // 0x6f5980: StoreField: r3->field_6b = r0
    //     0x6f5980: stur            w0, [x3, #0x6b]
    //     0x6f5984: ldurb           w16, [x3, #-1]
    //     0x6f5988: ldurb           w17, [x0, #-1]
    //     0x6f598c: and             x16, x17, x16, lsr #2
    //     0x6f5990: tst             x16, HEAP, lsr #32
    //     0x6f5994: b.eq            #0x6f599c
    //     0x6f5998: bl              #0xd682ac
    // 0x6f599c: SaveReg r3
    //     0x6f599c: str             x3, [SP, #-8]!
    // 0x6f59a0: r0 = RenderObject()
    //     0x6f59a0: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6f59a4: add             SP, SP, #8
    // 0x6f59a8: ldr             x16, [fp, #0x18]
    // 0x6f59ac: stp             NULL, x16, [SP, #-0x10]!
    // 0x6f59b0: r0 = child=()
    //     0x6f59b0: bl              #0x6e7ce0  ; [package:flutter/src/rendering/sliver_persistent_header.dart] _RenderSliverPersistentHeader&RenderSliver&RenderObjectWithChildMixin::child=
    // 0x6f59b4: add             SP, SP, #0x10
    // 0x6f59b8: r0 = Null
    //     0x6f59b8: mov             x0, NULL
    // 0x6f59bc: LeaveFrame
    //     0x6f59bc: mov             SP, fp
    //     0x6f59c0: ldp             fp, lr, [SP], #0x10
    // 0x6f59c4: ret
    //     0x6f59c4: ret             
    // 0x6f59c8: r0 = StackOverflowSharedWithFPURegs()
    //     0x6f59c8: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x6f59cc: b               #0x6f5968
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0xa8bf8c, size: 0xb8
    // 0xa8bf8c: EnterFrame
    //     0xa8bf8c: stp             fp, lr, [SP, #-0x10]!
    //     0xa8bf90: mov             fp, SP
    // 0xa8bf94: AllocStack(0x10)
    //     0xa8bf94: sub             SP, SP, #0x10
    // 0xa8bf98: CheckStackOverflow
    //     0xa8bf98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8bf9c: cmp             SP, x16
    //     0xa8bfa0: b.ls            #0xa8c03c
    // 0xa8bfa4: ldr             x0, [fp, #0x28]
    // 0xa8bfa8: LoadField: r1 = r0->field_53
    //     0xa8bfa8: ldur            w1, [x0, #0x53]
    // 0xa8bfac: DecompressPointer r1
    //     0xa8bfac: add             x1, x1, HEAP, lsl #32
    // 0xa8bfb0: stur            x1, [fp, #-0x10]
    // 0xa8bfb4: cmp             w1, NULL
    // 0xa8bfb8: b.eq            #0xa8c02c
    // 0xa8bfbc: ldr             x2, [fp, #0x20]
    // 0xa8bfc0: ldr             d0, [fp, #0x10]
    // 0xa8bfc4: LoadField: r3 = r2->field_7
    //     0xa8bfc4: ldur            w3, [x2, #7]
    // 0xa8bfc8: DecompressPointer r3
    //     0xa8bfc8: add             x3, x3, HEAP, lsl #32
    // 0xa8bfcc: stur            x3, [fp, #-8]
    // 0xa8bfd0: r0 = BoxHitTestResult()
    //     0xa8bfd0: bl              #0x50ee04  ; AllocateBoxHitTestResultStub -> BoxHitTestResult (size=0x14)
    // 0xa8bfd4: mov             x1, x0
    // 0xa8bfd8: ldur            x0, [fp, #-8]
    // 0xa8bfdc: StoreField: r1->field_7 = r0
    //     0xa8bfdc: stur            w0, [x1, #7]
    // 0xa8bfe0: ldr             x0, [fp, #0x20]
    // 0xa8bfe4: LoadField: r2 = r0->field_b
    //     0xa8bfe4: ldur            w2, [x0, #0xb]
    // 0xa8bfe8: DecompressPointer r2
    //     0xa8bfe8: add             x2, x2, HEAP, lsl #32
    // 0xa8bfec: StoreField: r1->field_b = r2
    //     0xa8bfec: stur            w2, [x1, #0xb]
    // 0xa8bff0: LoadField: r2 = r0->field_f
    //     0xa8bff0: ldur            w2, [x0, #0xf]
    // 0xa8bff4: DecompressPointer r2
    //     0xa8bff4: add             x2, x2, HEAP, lsl #32
    // 0xa8bff8: StoreField: r1->field_f = r2
    //     0xa8bff8: stur            w2, [x1, #0xf]
    // 0xa8bffc: ldr             x16, [fp, #0x28]
    // 0xa8c000: stp             x1, x16, [SP, #-0x10]!
    // 0xa8c004: ldur            x16, [fp, #-0x10]
    // 0xa8c008: ldr             lr, [fp, #0x18]
    // 0xa8c00c: stp             lr, x16, [SP, #-0x10]!
    // 0xa8c010: ldr             d0, [fp, #0x10]
    // 0xa8c014: SaveReg d0
    //     0xa8c014: str             d0, [SP, #-8]!
    // 0xa8c018: r0 = hitTestBoxChild()
    //     0xa8c018: bl              #0xa8b8c4  ; [package:flutter/src/rendering/sliver_persistent_header.dart] _RenderSliverPersistentHeader&RenderSliver&RenderObjectWithChildMixin&RenderSliverHelpers::hitTestBoxChild
    // 0xa8c01c: add             SP, SP, #0x28
    // 0xa8c020: LeaveFrame
    //     0xa8c020: mov             SP, fp
    //     0xa8c024: ldp             fp, lr, [SP], #0x10
    // 0xa8c028: ret
    //     0xa8c028: ret             
    // 0xa8c02c: r0 = false
    //     0xa8c02c: add             x0, NULL, #0x30  ; false
    // 0xa8c030: LeaveFrame
    //     0xa8c030: mov             SP, fp
    //     0xa8c034: ldp             fp, lr, [SP], #0x10
    // 0xa8c038: ret
    //     0xa8c038: ret             
    // 0xa8c03c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8c03c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8c040: b               #0xa8bfa4
  }
}

// class id: 2554, size: 0x94, field offset: 0x70
abstract class RenderSliverFloatingPersistentHeader extends RenderSliverPersistentHeader {

  late Animation<double> _animation; // offset: 0x74

  _ maybeStartSnapAnimation(/* No info */) {
    // ** addr: 0xa558a8, size: 0x5a4
    // 0xa558a8: EnterFrame
    //     0xa558a8: stp             fp, lr, [SP, #-0x10]!
    //     0xa558ac: mov             fp, SP
    // 0xa558b0: AllocStack(0x10)
    //     0xa558b0: sub             SP, SP, #0x10
    // 0xa558b4: CheckStackOverflow
    //     0xa558b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa558b8: cmp             SP, x16
    //     0xa558bc: b.ls            #0xa55e1c
    // 0xa558c0: ldr             x3, [fp, #0x18]
    // 0xa558c4: LoadField: r0 = r3->field_8b
    //     0xa558c4: ldur            w0, [x3, #0x8b]
    // 0xa558c8: DecompressPointer r0
    //     0xa558c8: add             x0, x0, HEAP, lsl #32
    // 0xa558cc: cmp             w0, NULL
    // 0xa558d0: b.ne            #0xa558e4
    // 0xa558d4: r0 = Null
    //     0xa558d4: mov             x0, NULL
    // 0xa558d8: LeaveFrame
    //     0xa558d8: mov             SP, fp
    //     0xa558dc: ldp             fp, lr, [SP], #0x10
    // 0xa558e0: ret
    //     0xa558e0: ret             
    // 0xa558e4: ldr             x4, [fp, #0x10]
    // 0xa558e8: r16 = Instance_ScrollDirection
    //     0xa558e8: add             x16, PP, #0x38, lsl #12  ; [pp+0x38f70] Obj!ScrollDirection@b646d1
    //     0xa558ec: ldr             x16, [x16, #0xf70]
    // 0xa558f0: cmp             w4, w16
    // 0xa558f4: b.ne            #0xa5592c
    // 0xa558f8: d0 = 0.000000
    //     0xa558f8: eor             v0.16b, v0.16b, v0.16b
    // 0xa558fc: LoadField: r0 = r3->field_7b
    //     0xa558fc: ldur            w0, [x3, #0x7b]
    // 0xa55900: DecompressPointer r0
    //     0xa55900: add             x0, x0, HEAP, lsl #32
    // 0xa55904: cmp             w0, NULL
    // 0xa55908: b.eq            #0xa55e24
    // 0xa5590c: LoadField: d1 = r0->field_7
    //     0xa5590c: ldur            d1, [x0, #7]
    // 0xa55910: fcmp            d1, d0
    // 0xa55914: b.vs            #0xa55930
    // 0xa55918: b.gt            #0xa55930
    // 0xa5591c: r0 = Null
    //     0xa5591c: mov             x0, NULL
    // 0xa55920: LeaveFrame
    //     0xa55920: mov             SP, fp
    //     0xa55924: ldp             fp, lr, [SP], #0x10
    // 0xa55928: ret
    //     0xa55928: ret             
    // 0xa5592c: d0 = 0.000000
    //     0xa5592c: eor             v0.16b, v0.16b, v0.16b
    // 0xa55930: r16 = Instance_ScrollDirection
    //     0xa55930: add             x16, PP, #0x4a, lsl #12  ; [pp+0x4a938] Obj!ScrollDirection@b646b1
    //     0xa55934: ldr             x16, [x16, #0x938]
    // 0xa55938: cmp             w4, w16
    // 0xa5593c: b.ne            #0xa55b98
    // 0xa55940: LoadField: r5 = r3->field_7b
    //     0xa55940: ldur            w5, [x3, #0x7b]
    // 0xa55944: DecompressPointer r5
    //     0xa55944: add             x5, x5, HEAP, lsl #32
    // 0xa55948: stur            x5, [fp, #-0x10]
    // 0xa5594c: cmp             w5, NULL
    // 0xa55950: b.eq            #0xa55e28
    // 0xa55954: r0 = LoadClassIdInstr(r3)
    //     0xa55954: ldur            x0, [x3, #-1]
    //     0xa55958: ubfx            x0, x0, #0xc, #0x14
    // 0xa5595c: lsl             x0, x0, #1
    // 0xa55960: r17 = 5112
    //     0xa55960: mov             x17, #0x13f8
    // 0xa55964: cmp             w0, w17
    // 0xa55968: b.ne            #0xa55a70
    // 0xa5596c: LoadField: r0 = r3->field_93
    //     0xa5596c: ldur            w0, [x3, #0x93]
    // 0xa55970: DecompressPointer r0
    //     0xa55970: add             x0, x0, HEAP, lsl #32
    // 0xa55974: cmp             w0, NULL
    // 0xa55978: b.eq            #0xa55e2c
    // 0xa5597c: LoadField: r6 = r0->field_1b
    //     0xa5597c: ldur            w6, [x0, #0x1b]
    // 0xa55980: DecompressPointer r6
    //     0xa55980: add             x6, x6, HEAP, lsl #32
    // 0xa55984: stur            x6, [fp, #-8]
    // 0xa55988: cmp             w6, NULL
    // 0xa5598c: b.eq            #0xa55e30
    // 0xa55990: mov             x0, x6
    // 0xa55994: r2 = Null
    //     0xa55994: mov             x2, NULL
    // 0xa55998: r1 = Null
    //     0xa55998: mov             x1, NULL
    // 0xa5599c: r4 = LoadClassIdInstr(r0)
    //     0xa5599c: ldur            x4, [x0, #-1]
    //     0xa559a0: ubfx            x4, x4, #0xc, #0x14
    // 0xa559a4: sub             x4, x4, #0xde5
    // 0xa559a8: cmp             x4, #3
    // 0xa559ac: b.ls            #0xa559c4
    // 0xa559b0: r8 = _SliverPersistentHeaderRenderObjectWidget
    //     0xa559b0: add             x8, PP, #0x4f, lsl #12  ; [pp+0x4f620] Type: _SliverPersistentHeaderRenderObjectWidget
    //     0xa559b4: ldr             x8, [x8, #0x620]
    // 0xa559b8: r3 = Null
    //     0xa559b8: add             x3, PP, #0x56, lsl #12  ; [pp+0x563a0] Null
    //     0xa559bc: ldr             x3, [x3, #0x3a0]
    // 0xa559c0: r0 = DefaultTypeTest()
    //     0xa559c0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa559c4: ldur            x0, [fp, #-8]
    // 0xa559c8: LoadField: r1 = r0->field_b
    //     0xa559c8: ldur            w1, [x0, #0xb]
    // 0xa559cc: DecompressPointer r1
    //     0xa559cc: add             x1, x1, HEAP, lsl #32
    // 0xa559d0: r0 = LoadClassIdInstr(r1)
    //     0xa559d0: ldur            x0, [x1, #-1]
    //     0xa559d4: ubfx            x0, x0, #0xc, #0x14
    // 0xa559d8: lsl             x0, x0, #1
    // 0xa559dc: r17 = 4478
    //     0xa559dc: mov             x17, #0x117e
    // 0xa559e0: cmp             w0, w17
    // 0xa559e4: b.ne            #0xa55a08
    // 0xa559e8: LoadField: r0 = r1->field_7
    //     0xa559e8: ldur            w0, [x1, #7]
    // 0xa559ec: DecompressPointer r0
    //     0xa559ec: add             x0, x0, HEAP, lsl #32
    // 0xa559f0: SaveReg r0
    //     0xa559f0: str             x0, [SP, #-8]!
    // 0xa559f4: r0 = preferredSize()
    //     0xa559f4: bl              #0xcb98f0  ; [package:flutter/src/material/tabs.dart] TabBar::preferredSize
    // 0xa559f8: add             SP, SP, #8
    // 0xa559fc: LoadField: d0 = r0->field_f
    //     0xa559fc: ldur            d0, [x0, #0xf]
    // 0xa55a00: d1 = 0.000000
    //     0xa55a00: eor             v1.16b, v1.16b, v1.16b
    // 0xa55a04: b               #0xa55b74
    // 0xa55a08: LoadField: d0 = r1->field_6b
    //     0xa55a08: ldur            d0, [x1, #0x6b]
    // 0xa55a0c: LoadField: d1 = r1->field_5b
    //     0xa55a0c: ldur            d1, [x1, #0x5b]
    // 0xa55a10: fadd            d2, d0, d1
    // 0xa55a14: LoadField: d0 = r1->field_63
    //     0xa55a14: ldur            d0, [x1, #0x63]
    // 0xa55a18: fcmp            d2, d0
    // 0xa55a1c: b.vs            #0xa55a30
    // 0xa55a20: b.le            #0xa55a30
    // 0xa55a24: mov             v0.16b, v2.16b
    // 0xa55a28: d1 = 0.000000
    //     0xa55a28: eor             v1.16b, v1.16b, v1.16b
    // 0xa55a2c: b               #0xa55b74
    // 0xa55a30: fcmp            d2, d0
    // 0xa55a34: b.vs            #0xa55a44
    // 0xa55a38: b.ge            #0xa55a44
    // 0xa55a3c: d1 = 0.000000
    //     0xa55a3c: eor             v1.16b, v1.16b, v1.16b
    // 0xa55a40: b               #0xa55b74
    // 0xa55a44: d1 = 0.000000
    //     0xa55a44: eor             v1.16b, v1.16b, v1.16b
    // 0xa55a48: fcmp            d2, d1
    // 0xa55a4c: b.vs            #0xa55a60
    // 0xa55a50: b.ne            #0xa55a60
    // 0xa55a54: fadd            d3, d2, d0
    // 0xa55a58: mov             v0.16b, v3.16b
    // 0xa55a5c: b               #0xa55b74
    // 0xa55a60: fcmp            d0, d0
    // 0xa55a64: b.vs            #0xa55b74
    // 0xa55a68: mov             v0.16b, v2.16b
    // 0xa55a6c: b               #0xa55b74
    // 0xa55a70: mov             v1.16b, v0.16b
    // 0xa55a74: LoadField: r0 = r3->field_93
    //     0xa55a74: ldur            w0, [x3, #0x93]
    // 0xa55a78: DecompressPointer r0
    //     0xa55a78: add             x0, x0, HEAP, lsl #32
    // 0xa55a7c: cmp             w0, NULL
    // 0xa55a80: b.eq            #0xa55e34
    // 0xa55a84: LoadField: r4 = r0->field_1b
    //     0xa55a84: ldur            w4, [x0, #0x1b]
    // 0xa55a88: DecompressPointer r4
    //     0xa55a88: add             x4, x4, HEAP, lsl #32
    // 0xa55a8c: stur            x4, [fp, #-8]
    // 0xa55a90: cmp             w4, NULL
    // 0xa55a94: b.eq            #0xa55e38
    // 0xa55a98: mov             x0, x4
    // 0xa55a9c: r2 = Null
    //     0xa55a9c: mov             x2, NULL
    // 0xa55aa0: r1 = Null
    //     0xa55aa0: mov             x1, NULL
    // 0xa55aa4: r4 = LoadClassIdInstr(r0)
    //     0xa55aa4: ldur            x4, [x0, #-1]
    //     0xa55aa8: ubfx            x4, x4, #0xc, #0x14
    // 0xa55aac: sub             x4, x4, #0xde5
    // 0xa55ab0: cmp             x4, #3
    // 0xa55ab4: b.ls            #0xa55acc
    // 0xa55ab8: r8 = _SliverPersistentHeaderRenderObjectWidget
    //     0xa55ab8: add             x8, PP, #0x4f, lsl #12  ; [pp+0x4f620] Type: _SliverPersistentHeaderRenderObjectWidget
    //     0xa55abc: ldr             x8, [x8, #0x620]
    // 0xa55ac0: r3 = Null
    //     0xa55ac0: add             x3, PP, #0x56, lsl #12  ; [pp+0x563b0] Null
    //     0xa55ac4: ldr             x3, [x3, #0x3b0]
    // 0xa55ac8: r0 = DefaultTypeTest()
    //     0xa55ac8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa55acc: ldur            x0, [fp, #-8]
    // 0xa55ad0: LoadField: r1 = r0->field_b
    //     0xa55ad0: ldur            w1, [x0, #0xb]
    // 0xa55ad4: DecompressPointer r1
    //     0xa55ad4: add             x1, x1, HEAP, lsl #32
    // 0xa55ad8: r0 = LoadClassIdInstr(r1)
    //     0xa55ad8: ldur            x0, [x1, #-1]
    //     0xa55adc: ubfx            x0, x0, #0xc, #0x14
    // 0xa55ae0: lsl             x0, x0, #1
    // 0xa55ae4: r17 = 4478
    //     0xa55ae4: mov             x17, #0x117e
    // 0xa55ae8: cmp             w0, w17
    // 0xa55aec: b.ne            #0xa55b10
    // 0xa55af0: LoadField: r0 = r1->field_7
    //     0xa55af0: ldur            w0, [x1, #7]
    // 0xa55af4: DecompressPointer r0
    //     0xa55af4: add             x0, x0, HEAP, lsl #32
    // 0xa55af8: SaveReg r0
    //     0xa55af8: str             x0, [SP, #-8]!
    // 0xa55afc: r0 = preferredSize()
    //     0xa55afc: bl              #0xcb98f0  ; [package:flutter/src/material/tabs.dart] TabBar::preferredSize
    // 0xa55b00: add             SP, SP, #8
    // 0xa55b04: LoadField: d0 = r0->field_f
    //     0xa55b04: ldur            d0, [x0, #0xf]
    // 0xa55b08: d1 = 0.000000
    //     0xa55b08: eor             v1.16b, v1.16b, v1.16b
    // 0xa55b0c: b               #0xa55b74
    // 0xa55b10: LoadField: d0 = r1->field_6b
    //     0xa55b10: ldur            d0, [x1, #0x6b]
    // 0xa55b14: LoadField: d1 = r1->field_5b
    //     0xa55b14: ldur            d1, [x1, #0x5b]
    // 0xa55b18: fadd            d2, d0, d1
    // 0xa55b1c: LoadField: d0 = r1->field_63
    //     0xa55b1c: ldur            d0, [x1, #0x63]
    // 0xa55b20: fcmp            d2, d0
    // 0xa55b24: b.vs            #0xa55b38
    // 0xa55b28: b.le            #0xa55b38
    // 0xa55b2c: mov             v0.16b, v2.16b
    // 0xa55b30: d1 = 0.000000
    //     0xa55b30: eor             v1.16b, v1.16b, v1.16b
    // 0xa55b34: b               #0xa55b74
    // 0xa55b38: fcmp            d2, d0
    // 0xa55b3c: b.vs            #0xa55b4c
    // 0xa55b40: b.ge            #0xa55b4c
    // 0xa55b44: d1 = 0.000000
    //     0xa55b44: eor             v1.16b, v1.16b, v1.16b
    // 0xa55b48: b               #0xa55b74
    // 0xa55b4c: d1 = 0.000000
    //     0xa55b4c: eor             v1.16b, v1.16b, v1.16b
    // 0xa55b50: fcmp            d2, d1
    // 0xa55b54: b.vs            #0xa55b68
    // 0xa55b58: b.ne            #0xa55b68
    // 0xa55b5c: fadd            d3, d2, d0
    // 0xa55b60: mov             v0.16b, v3.16b
    // 0xa55b64: b               #0xa55b74
    // 0xa55b68: fcmp            d0, d0
    // 0xa55b6c: b.vs            #0xa55b74
    // 0xa55b70: mov             v0.16b, v2.16b
    // 0xa55b74: ldur            x0, [fp, #-0x10]
    // 0xa55b78: LoadField: d2 = r0->field_7
    //     0xa55b78: ldur            d2, [x0, #7]
    // 0xa55b7c: fcmp            d2, d0
    // 0xa55b80: b.vs            #0xa55b9c
    // 0xa55b84: b.lt            #0xa55b9c
    // 0xa55b88: r0 = Null
    //     0xa55b88: mov             x0, NULL
    // 0xa55b8c: LeaveFrame
    //     0xa55b8c: mov             SP, fp
    //     0xa55b90: ldp             fp, lr, [SP], #0x10
    // 0xa55b94: ret
    //     0xa55b94: ret             
    // 0xa55b98: mov             v1.16b, v0.16b
    // 0xa55b9c: ldr             x0, [fp, #0x10]
    // 0xa55ba0: r16 = Instance_ScrollDirection
    //     0xa55ba0: add             x16, PP, #0x38, lsl #12  ; [pp+0x38f70] Obj!ScrollDirection@b646d1
    //     0xa55ba4: ldr             x16, [x16, #0xf70]
    // 0xa55ba8: cmp             w0, w16
    // 0xa55bac: b.ne            #0xa55bb8
    // 0xa55bb0: d0 = 0.000000
    //     0xa55bb0: eor             v0.16b, v0.16b, v0.16b
    // 0xa55bb4: b               #0xa55db8
    // 0xa55bb8: ldr             x3, [fp, #0x18]
    // 0xa55bbc: r0 = LoadClassIdInstr(r3)
    //     0xa55bbc: ldur            x0, [x3, #-1]
    //     0xa55bc0: ubfx            x0, x0, #0xc, #0x14
    // 0xa55bc4: lsl             x0, x0, #1
    // 0xa55bc8: r17 = 5112
    //     0xa55bc8: mov             x17, #0x13f8
    // 0xa55bcc: cmp             w0, w17
    // 0xa55bd0: b.ne            #0xa55cc8
    // 0xa55bd4: LoadField: r0 = r3->field_93
    //     0xa55bd4: ldur            w0, [x3, #0x93]
    // 0xa55bd8: DecompressPointer r0
    //     0xa55bd8: add             x0, x0, HEAP, lsl #32
    // 0xa55bdc: cmp             w0, NULL
    // 0xa55be0: b.eq            #0xa55e3c
    // 0xa55be4: LoadField: r4 = r0->field_1b
    //     0xa55be4: ldur            w4, [x0, #0x1b]
    // 0xa55be8: DecompressPointer r4
    //     0xa55be8: add             x4, x4, HEAP, lsl #32
    // 0xa55bec: stur            x4, [fp, #-8]
    // 0xa55bf0: cmp             w4, NULL
    // 0xa55bf4: b.eq            #0xa55e40
    // 0xa55bf8: mov             x0, x4
    // 0xa55bfc: r2 = Null
    //     0xa55bfc: mov             x2, NULL
    // 0xa55c00: r1 = Null
    //     0xa55c00: mov             x1, NULL
    // 0xa55c04: r4 = LoadClassIdInstr(r0)
    //     0xa55c04: ldur            x4, [x0, #-1]
    //     0xa55c08: ubfx            x4, x4, #0xc, #0x14
    // 0xa55c0c: sub             x4, x4, #0xde5
    // 0xa55c10: cmp             x4, #3
    // 0xa55c14: b.ls            #0xa55c2c
    // 0xa55c18: r8 = _SliverPersistentHeaderRenderObjectWidget
    //     0xa55c18: add             x8, PP, #0x4f, lsl #12  ; [pp+0x4f620] Type: _SliverPersistentHeaderRenderObjectWidget
    //     0xa55c1c: ldr             x8, [x8, #0x620]
    // 0xa55c20: r3 = Null
    //     0xa55c20: add             x3, PP, #0x56, lsl #12  ; [pp+0x563c0] Null
    //     0xa55c24: ldr             x3, [x3, #0x3c0]
    // 0xa55c28: r0 = DefaultTypeTest()
    //     0xa55c28: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa55c2c: ldur            x0, [fp, #-8]
    // 0xa55c30: LoadField: r1 = r0->field_b
    //     0xa55c30: ldur            w1, [x0, #0xb]
    // 0xa55c34: DecompressPointer r1
    //     0xa55c34: add             x1, x1, HEAP, lsl #32
    // 0xa55c38: r0 = LoadClassIdInstr(r1)
    //     0xa55c38: ldur            x0, [x1, #-1]
    //     0xa55c3c: ubfx            x0, x0, #0xc, #0x14
    // 0xa55c40: lsl             x0, x0, #1
    // 0xa55c44: r17 = 4478
    //     0xa55c44: mov             x17, #0x117e
    // 0xa55c48: cmp             w0, w17
    // 0xa55c4c: b.ne            #0xa55c6c
    // 0xa55c50: LoadField: r0 = r1->field_7
    //     0xa55c50: ldur            w0, [x1, #7]
    // 0xa55c54: DecompressPointer r0
    //     0xa55c54: add             x0, x0, HEAP, lsl #32
    // 0xa55c58: SaveReg r0
    //     0xa55c58: str             x0, [SP, #-8]!
    // 0xa55c5c: r0 = preferredSize()
    //     0xa55c5c: bl              #0xcb98f0  ; [package:flutter/src/material/tabs.dart] TabBar::preferredSize
    // 0xa55c60: add             SP, SP, #8
    // 0xa55c64: LoadField: d0 = r0->field_f
    //     0xa55c64: ldur            d0, [x0, #0xf]
    // 0xa55c68: b               #0xa55db8
    // 0xa55c6c: LoadField: d0 = r1->field_6b
    //     0xa55c6c: ldur            d0, [x1, #0x6b]
    // 0xa55c70: LoadField: d1 = r1->field_5b
    //     0xa55c70: ldur            d1, [x1, #0x5b]
    // 0xa55c74: fadd            d2, d0, d1
    // 0xa55c78: LoadField: d0 = r1->field_63
    //     0xa55c78: ldur            d0, [x1, #0x63]
    // 0xa55c7c: fcmp            d2, d0
    // 0xa55c80: b.vs            #0xa55c90
    // 0xa55c84: b.le            #0xa55c90
    // 0xa55c88: mov             v0.16b, v2.16b
    // 0xa55c8c: b               #0xa55db8
    // 0xa55c90: fcmp            d2, d0
    // 0xa55c94: b.vs            #0xa55c9c
    // 0xa55c98: b.lt            #0xa55db8
    // 0xa55c9c: d1 = 0.000000
    //     0xa55c9c: eor             v1.16b, v1.16b, v1.16b
    // 0xa55ca0: fcmp            d2, d1
    // 0xa55ca4: b.vs            #0xa55cb8
    // 0xa55ca8: b.ne            #0xa55cb8
    // 0xa55cac: fadd            d1, d2, d0
    // 0xa55cb0: mov             v0.16b, v1.16b
    // 0xa55cb4: b               #0xa55db8
    // 0xa55cb8: fcmp            d0, d0
    // 0xa55cbc: b.vs            #0xa55db8
    // 0xa55cc0: mov             v0.16b, v2.16b
    // 0xa55cc4: b               #0xa55db8
    // 0xa55cc8: LoadField: r0 = r3->field_93
    //     0xa55cc8: ldur            w0, [x3, #0x93]
    // 0xa55ccc: DecompressPointer r0
    //     0xa55ccc: add             x0, x0, HEAP, lsl #32
    // 0xa55cd0: cmp             w0, NULL
    // 0xa55cd4: b.eq            #0xa55e44
    // 0xa55cd8: LoadField: r4 = r0->field_1b
    //     0xa55cd8: ldur            w4, [x0, #0x1b]
    // 0xa55cdc: DecompressPointer r4
    //     0xa55cdc: add             x4, x4, HEAP, lsl #32
    // 0xa55ce0: stur            x4, [fp, #-8]
    // 0xa55ce4: cmp             w4, NULL
    // 0xa55ce8: b.eq            #0xa55e48
    // 0xa55cec: mov             x0, x4
    // 0xa55cf0: r2 = Null
    //     0xa55cf0: mov             x2, NULL
    // 0xa55cf4: r1 = Null
    //     0xa55cf4: mov             x1, NULL
    // 0xa55cf8: r4 = LoadClassIdInstr(r0)
    //     0xa55cf8: ldur            x4, [x0, #-1]
    //     0xa55cfc: ubfx            x4, x4, #0xc, #0x14
    // 0xa55d00: sub             x4, x4, #0xde5
    // 0xa55d04: cmp             x4, #3
    // 0xa55d08: b.ls            #0xa55d20
    // 0xa55d0c: r8 = _SliverPersistentHeaderRenderObjectWidget
    //     0xa55d0c: add             x8, PP, #0x4f, lsl #12  ; [pp+0x4f620] Type: _SliverPersistentHeaderRenderObjectWidget
    //     0xa55d10: ldr             x8, [x8, #0x620]
    // 0xa55d14: r3 = Null
    //     0xa55d14: add             x3, PP, #0x56, lsl #12  ; [pp+0x563d0] Null
    //     0xa55d18: ldr             x3, [x3, #0x3d0]
    // 0xa55d1c: r0 = DefaultTypeTest()
    //     0xa55d1c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa55d20: ldur            x0, [fp, #-8]
    // 0xa55d24: LoadField: r1 = r0->field_b
    //     0xa55d24: ldur            w1, [x0, #0xb]
    // 0xa55d28: DecompressPointer r1
    //     0xa55d28: add             x1, x1, HEAP, lsl #32
    // 0xa55d2c: r0 = LoadClassIdInstr(r1)
    //     0xa55d2c: ldur            x0, [x1, #-1]
    //     0xa55d30: ubfx            x0, x0, #0xc, #0x14
    // 0xa55d34: lsl             x0, x0, #1
    // 0xa55d38: r17 = 4478
    //     0xa55d38: mov             x17, #0x117e
    // 0xa55d3c: cmp             w0, w17
    // 0xa55d40: b.ne            #0xa55d60
    // 0xa55d44: LoadField: r0 = r1->field_7
    //     0xa55d44: ldur            w0, [x1, #7]
    // 0xa55d48: DecompressPointer r0
    //     0xa55d48: add             x0, x0, HEAP, lsl #32
    // 0xa55d4c: SaveReg r0
    //     0xa55d4c: str             x0, [SP, #-8]!
    // 0xa55d50: r0 = preferredSize()
    //     0xa55d50: bl              #0xcb98f0  ; [package:flutter/src/material/tabs.dart] TabBar::preferredSize
    // 0xa55d54: add             SP, SP, #8
    // 0xa55d58: LoadField: d0 = r0->field_f
    //     0xa55d58: ldur            d0, [x0, #0xf]
    // 0xa55d5c: b               #0xa55db8
    // 0xa55d60: LoadField: d0 = r1->field_6b
    //     0xa55d60: ldur            d0, [x1, #0x6b]
    // 0xa55d64: LoadField: d1 = r1->field_5b
    //     0xa55d64: ldur            d1, [x1, #0x5b]
    // 0xa55d68: fadd            d2, d0, d1
    // 0xa55d6c: LoadField: d0 = r1->field_63
    //     0xa55d6c: ldur            d0, [x1, #0x63]
    // 0xa55d70: fcmp            d2, d0
    // 0xa55d74: b.vs            #0xa55d84
    // 0xa55d78: b.le            #0xa55d84
    // 0xa55d7c: mov             v0.16b, v2.16b
    // 0xa55d80: b               #0xa55db8
    // 0xa55d84: fcmp            d2, d0
    // 0xa55d88: b.vs            #0xa55d90
    // 0xa55d8c: b.lt            #0xa55db8
    // 0xa55d90: d1 = 0.000000
    //     0xa55d90: eor             v1.16b, v1.16b, v1.16b
    // 0xa55d94: fcmp            d2, d1
    // 0xa55d98: b.vs            #0xa55dac
    // 0xa55d9c: b.ne            #0xa55dac
    // 0xa55da0: fadd            d1, d2, d0
    // 0xa55da4: mov             v0.16b, v1.16b
    // 0xa55da8: b               #0xa55db8
    // 0xa55dac: fcmp            d0, d0
    // 0xa55db0: b.vs            #0xa55db8
    // 0xa55db4: mov             v0.16b, v2.16b
    // 0xa55db8: ldr             x0, [fp, #0x18]
    // 0xa55dbc: r16 = Instance_Duration
    //     0xa55dbc: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0xa55dc0: ldr             x16, [x16, #0x9e0]
    // 0xa55dc4: stp             x16, x0, [SP, #-0x10]!
    // 0xa55dc8: SaveReg d0
    //     0xa55dc8: str             d0, [SP, #-8]!
    // 0xa55dcc: r16 = Instance_Cubic
    //     0xa55dcc: add             x16, PP, #0x20, lsl #12  ; [pp+0x20970] Obj!Cubic<double>@b4f3a1
    //     0xa55dd0: ldr             x16, [x16, #0x970]
    // 0xa55dd4: SaveReg r16
    //     0xa55dd4: str             x16, [SP, #-8]!
    // 0xa55dd8: r0 = _updateAnimation()
    //     0xa55dd8: bl              #0xa55e4c  ; [package:flutter/src/rendering/sliver_persistent_header.dart] RenderSliverFloatingPersistentHeader::_updateAnimation
    // 0xa55ddc: add             SP, SP, #0x20
    // 0xa55de0: ldr             x0, [fp, #0x18]
    // 0xa55de4: LoadField: r1 = r0->field_6f
    //     0xa55de4: ldur            w1, [x0, #0x6f]
    // 0xa55de8: DecompressPointer r1
    //     0xa55de8: add             x1, x1, HEAP, lsl #32
    // 0xa55dec: cmp             w1, NULL
    // 0xa55df0: b.eq            #0xa55e0c
    // 0xa55df4: r16 = 0.000000
    //     0xa55df4: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xa55df8: stp             x16, x1, [SP, #-0x10]!
    // 0xa55dfc: r4 = const [0, 0x2, 0x2, 0x1, from, 0x1, null]
    //     0xa55dfc: add             x4, PP, #0x50, lsl #12  ; [pp+0x50438] List(7) [0, 0x2, 0x2, 0x1, "from", 0x1, Null]
    //     0xa55e00: ldr             x4, [x4, #0x438]
    // 0xa55e04: r0 = forward()
    //     0xa55e04: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xa55e08: add             SP, SP, #0x10
    // 0xa55e0c: r0 = Null
    //     0xa55e0c: mov             x0, NULL
    // 0xa55e10: LeaveFrame
    //     0xa55e10: mov             SP, fp
    //     0xa55e14: ldp             fp, lr, [SP], #0x10
    // 0xa55e18: ret
    //     0xa55e18: ret             
    // 0xa55e1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa55e1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa55e20: b               #0xa558c0
    // 0xa55e24: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa55e24: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa55e28: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa55e28: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa55e2c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa55e2c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa55e30: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa55e30: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa55e34: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa55e34: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa55e38: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa55e38: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa55e3c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa55e3c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa55e40: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa55e40: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa55e44: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa55e44: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa55e48: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa55e48: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _updateAnimation(/* No info */) {
    // ** addr: 0xa55e4c, size: 0x1bc
    // 0xa55e4c: EnterFrame
    //     0xa55e4c: stp             fp, lr, [SP, #-0x10]!
    //     0xa55e50: mov             fp, SP
    // 0xa55e54: AllocStack(0x18)
    //     0xa55e54: sub             SP, SP, #0x18
    // 0xa55e58: CheckStackOverflow
    //     0xa55e58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa55e5c: cmp             SP, x16
    //     0xa55e60: b.ls            #0xa55fe4
    // 0xa55e64: r1 = 1
    //     0xa55e64: mov             x1, #1
    // 0xa55e68: r0 = AllocateContext()
    //     0xa55e68: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa55e6c: mov             x2, x0
    // 0xa55e70: ldr             x0, [fp, #0x28]
    // 0xa55e74: stur            x2, [fp, #-0x10]
    // 0xa55e78: StoreField: r2->field_f = r0
    //     0xa55e78: stur            w0, [x2, #0xf]
    // 0xa55e7c: LoadField: r1 = r0->field_6f
    //     0xa55e7c: ldur            w1, [x0, #0x6f]
    // 0xa55e80: DecompressPointer r1
    //     0xa55e80: add             x1, x1, HEAP, lsl #32
    // 0xa55e84: cmp             w1, NULL
    // 0xa55e88: b.ne            #0xa55f18
    // 0xa55e8c: LoadField: r3 = r0->field_87
    //     0xa55e8c: ldur            w3, [x0, #0x87]
    // 0xa55e90: DecompressPointer r3
    //     0xa55e90: add             x3, x3, HEAP, lsl #32
    // 0xa55e94: stur            x3, [fp, #-8]
    // 0xa55e98: cmp             w3, NULL
    // 0xa55e9c: b.eq            #0xa55fec
    // 0xa55ea0: r1 = <double>
    //     0xa55ea0: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xa55ea4: r0 = AnimationController()
    //     0xa55ea4: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xa55ea8: stur            x0, [fp, #-0x18]
    // 0xa55eac: ldur            x16, [fp, #-8]
    // 0xa55eb0: stp             x16, x0, [SP, #-0x10]!
    // 0xa55eb4: ldr             x16, [fp, #0x20]
    // 0xa55eb8: SaveReg r16
    //     0xa55eb8: str             x16, [SP, #-8]!
    // 0xa55ebc: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0xa55ebc: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0xa55ec0: ldr             x4, [x4, #0xa0]
    // 0xa55ec4: r0 = AnimationController()
    //     0xa55ec4: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xa55ec8: add             SP, SP, #0x18
    // 0xa55ecc: ldur            x2, [fp, #-0x10]
    // 0xa55ed0: r1 = Function '<anonymous closure>':.
    //     0xa55ed0: add             x1, PP, #0x56, lsl #12  ; [pp+0x563e0] AnonymousClosure: (0xa56008), in [package:flutter/src/rendering/sliver_persistent_header.dart] RenderSliverFloatingPersistentHeader::_updateAnimation (0xa55e4c)
    //     0xa55ed4: ldr             x1, [x1, #0x3e0]
    // 0xa55ed8: r0 = AllocateClosure()
    //     0xa55ed8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa55edc: ldur            x16, [fp, #-0x18]
    // 0xa55ee0: stp             x0, x16, [SP, #-0x10]!
    // 0xa55ee4: r0 = addActionListener()
    //     0xa55ee4: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0xa55ee8: add             SP, SP, #0x10
    // 0xa55eec: ldur            x0, [fp, #-0x18]
    // 0xa55ef0: ldr             x2, [fp, #0x28]
    // 0xa55ef4: StoreField: r2->field_6f = r0
    //     0xa55ef4: stur            w0, [x2, #0x6f]
    //     0xa55ef8: ldurb           w16, [x2, #-1]
    //     0xa55efc: ldurb           w17, [x0, #-1]
    //     0xa55f00: and             x16, x17, x16, lsr #2
    //     0xa55f04: tst             x16, HEAP, lsr #32
    //     0xa55f08: b.eq            #0xa55f10
    //     0xa55f0c: bl              #0xd6828c
    // 0xa55f10: ldur            x3, [fp, #-0x18]
    // 0xa55f14: b               #0xa55f20
    // 0xa55f18: mov             x2, x0
    // 0xa55f1c: mov             x3, x1
    // 0xa55f20: ldr             d0, [fp, #0x18]
    // 0xa55f24: ldr             x0, [fp, #0x10]
    // 0xa55f28: stur            x3, [fp, #-0x10]
    // 0xa55f2c: LoadField: r4 = r2->field_7b
    //     0xa55f2c: ldur            w4, [x2, #0x7b]
    // 0xa55f30: DecompressPointer r4
    //     0xa55f30: add             x4, x4, HEAP, lsl #32
    // 0xa55f34: stur            x4, [fp, #-8]
    // 0xa55f38: r1 = <double>
    //     0xa55f38: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xa55f3c: r0 = Tween()
    //     0xa55f3c: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xa55f40: mov             x2, x0
    // 0xa55f44: ldur            x0, [fp, #-8]
    // 0xa55f48: stur            x2, [fp, #-0x18]
    // 0xa55f4c: StoreField: r2->field_b = r0
    //     0xa55f4c: stur            w0, [x2, #0xb]
    // 0xa55f50: ldr             d0, [fp, #0x18]
    // 0xa55f54: r0 = inline_Allocate_Double()
    //     0xa55f54: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa55f58: add             x0, x0, #0x10
    //     0xa55f5c: cmp             x1, x0
    //     0xa55f60: b.ls            #0xa55ff0
    //     0xa55f64: str             x0, [THR, #0x60]  ; THR::top
    //     0xa55f68: sub             x0, x0, #0xf
    //     0xa55f6c: mov             x1, #0xd108
    //     0xa55f70: movk            x1, #3, lsl #16
    //     0xa55f74: stur            x1, [x0, #-1]
    // 0xa55f78: StoreField: r0->field_7 = d0
    //     0xa55f78: stur            d0, [x0, #7]
    // 0xa55f7c: StoreField: r2->field_f = r0
    //     0xa55f7c: stur            w0, [x2, #0xf]
    // 0xa55f80: r1 = <double>
    //     0xa55f80: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xa55f84: r0 = CurveTween()
    //     0xa55f84: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xa55f88: mov             x1, x0
    // 0xa55f8c: ldr             x0, [fp, #0x10]
    // 0xa55f90: StoreField: r1->field_b = r0
    //     0xa55f90: stur            w0, [x1, #0xb]
    // 0xa55f94: ldur            x16, [fp, #-0x18]
    // 0xa55f98: stp             x1, x16, [SP, #-0x10]!
    // 0xa55f9c: r0 = chain()
    //     0xa55f9c: bl              #0x7b76c8  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xa55fa0: add             SP, SP, #0x10
    // 0xa55fa4: ldur            x16, [fp, #-0x10]
    // 0xa55fa8: stp             x16, x0, [SP, #-0x10]!
    // 0xa55fac: r0 = animate()
    //     0xa55fac: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xa55fb0: add             SP, SP, #0x10
    // 0xa55fb4: ldr             x1, [fp, #0x28]
    // 0xa55fb8: StoreField: r1->field_73 = r0
    //     0xa55fb8: stur            w0, [x1, #0x73]
    //     0xa55fbc: ldurb           w16, [x1, #-1]
    //     0xa55fc0: ldurb           w17, [x0, #-1]
    //     0xa55fc4: and             x16, x17, x16, lsr #2
    //     0xa55fc8: tst             x16, HEAP, lsr #32
    //     0xa55fcc: b.eq            #0xa55fd4
    //     0xa55fd0: bl              #0xd6826c
    // 0xa55fd4: r0 = Null
    //     0xa55fd4: mov             x0, NULL
    // 0xa55fd8: LeaveFrame
    //     0xa55fd8: mov             SP, fp
    //     0xa55fdc: ldp             fp, lr, [SP], #0x10
    // 0xa55fe0: ret
    //     0xa55fe0: ret             
    // 0xa55fe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa55fe4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa55fe8: b               #0xa55e64
    // 0xa55fec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa55fec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa55ff0: SaveReg d0
    //     0xa55ff0: str             q0, [SP, #-0x10]!
    // 0xa55ff4: SaveReg r2
    //     0xa55ff4: str             x2, [SP, #-8]!
    // 0xa55ff8: r0 = AllocateDouble()
    //     0xa55ff8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa55ffc: RestoreReg r2
    //     0xa55ffc: ldr             x2, [SP], #8
    // 0xa56000: RestoreReg d0
    //     0xa56000: ldr             q0, [SP], #0x10
    // 0xa56004: b               #0xa55f78
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xa56008, size: 0x150
    // 0xa56008: EnterFrame
    //     0xa56008: stp             fp, lr, [SP, #-0x10]!
    //     0xa5600c: mov             fp, SP
    // 0xa56010: AllocStack(0x10)
    //     0xa56010: sub             SP, SP, #0x10
    // 0xa56014: SetupParameters()
    //     0xa56014: ldr             x0, [fp, #0x10]
    //     0xa56018: ldur            w1, [x0, #0x17]
    //     0xa5601c: add             x1, x1, HEAP, lsl #32
    //     0xa56020: stur            x1, [fp, #-0x10]
    // 0xa56024: CheckStackOverflow
    //     0xa56024: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa56028: cmp             SP, x16
    //     0xa5602c: b.ls            #0xa56138
    // 0xa56030: LoadField: r0 = r1->field_f
    //     0xa56030: ldur            w0, [x1, #0xf]
    // 0xa56034: DecompressPointer r0
    //     0xa56034: add             x0, x0, HEAP, lsl #32
    // 0xa56038: LoadField: r2 = r0->field_7b
    //     0xa56038: ldur            w2, [x0, #0x7b]
    // 0xa5603c: DecompressPointer r2
    //     0xa5603c: add             x2, x2, HEAP, lsl #32
    // 0xa56040: stur            x2, [fp, #-8]
    // 0xa56044: LoadField: r3 = r0->field_73
    //     0xa56044: ldur            w3, [x0, #0x73]
    // 0xa56048: DecompressPointer r3
    //     0xa56048: add             x3, x3, HEAP, lsl #32
    // 0xa5604c: r16 = Sentinel
    //     0xa5604c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa56050: cmp             w3, w16
    // 0xa56054: b.eq            #0xa56140
    // 0xa56058: LoadField: r0 = r3->field_f
    //     0xa56058: ldur            w0, [x3, #0xf]
    // 0xa5605c: DecompressPointer r0
    //     0xa5605c: add             x0, x0, HEAP, lsl #32
    // 0xa56060: LoadField: r4 = r3->field_b
    //     0xa56060: ldur            w4, [x3, #0xb]
    // 0xa56064: DecompressPointer r4
    //     0xa56064: add             x4, x4, HEAP, lsl #32
    // 0xa56068: stp             x4, x0, [SP, #-0x10]!
    // 0xa5606c: r0 = evaluate()
    //     0xa5606c: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xa56070: add             SP, SP, #0x10
    // 0xa56074: mov             x1, x0
    // 0xa56078: ldur            x0, [fp, #-8]
    // 0xa5607c: r2 = LoadClassIdInstr(r0)
    //     0xa5607c: ldur            x2, [x0, #-1]
    //     0xa56080: ubfx            x2, x2, #0xc, #0x14
    // 0xa56084: stp             x1, x0, [SP, #-0x10]!
    // 0xa56088: mov             x0, x2
    // 0xa5608c: mov             lr, x0
    // 0xa56090: ldr             lr, [x21, lr, lsl #3]
    // 0xa56094: blr             lr
    // 0xa56098: add             SP, SP, #0x10
    // 0xa5609c: tbnz            w0, #4, #0xa560b0
    // 0xa560a0: r0 = Null
    //     0xa560a0: mov             x0, NULL
    // 0xa560a4: LeaveFrame
    //     0xa560a4: mov             SP, fp
    //     0xa560a8: ldp             fp, lr, [SP], #0x10
    // 0xa560ac: ret
    //     0xa560ac: ret             
    // 0xa560b0: ldur            x0, [fp, #-0x10]
    // 0xa560b4: LoadField: r1 = r0->field_f
    //     0xa560b4: ldur            w1, [x0, #0xf]
    // 0xa560b8: DecompressPointer r1
    //     0xa560b8: add             x1, x1, HEAP, lsl #32
    // 0xa560bc: stur            x1, [fp, #-8]
    // 0xa560c0: LoadField: r2 = r1->field_73
    //     0xa560c0: ldur            w2, [x1, #0x73]
    // 0xa560c4: DecompressPointer r2
    //     0xa560c4: add             x2, x2, HEAP, lsl #32
    // 0xa560c8: r16 = Sentinel
    //     0xa560c8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa560cc: cmp             w2, w16
    // 0xa560d0: b.eq            #0xa5614c
    // 0xa560d4: LoadField: r3 = r2->field_f
    //     0xa560d4: ldur            w3, [x2, #0xf]
    // 0xa560d8: DecompressPointer r3
    //     0xa560d8: add             x3, x3, HEAP, lsl #32
    // 0xa560dc: LoadField: r4 = r2->field_b
    //     0xa560dc: ldur            w4, [x2, #0xb]
    // 0xa560e0: DecompressPointer r4
    //     0xa560e0: add             x4, x4, HEAP, lsl #32
    // 0xa560e4: stp             x4, x3, [SP, #-0x10]!
    // 0xa560e8: r0 = evaluate()
    //     0xa560e8: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xa560ec: add             SP, SP, #0x10
    // 0xa560f0: ldur            x1, [fp, #-8]
    // 0xa560f4: StoreField: r1->field_7b = r0
    //     0xa560f4: stur            w0, [x1, #0x7b]
    //     0xa560f8: ldurb           w16, [x1, #-1]
    //     0xa560fc: ldurb           w17, [x0, #-1]
    //     0xa56100: and             x16, x17, x16, lsr #2
    //     0xa56104: tst             x16, HEAP, lsr #32
    //     0xa56108: b.eq            #0xa56110
    //     0xa5610c: bl              #0xd6826c
    // 0xa56110: ldur            x0, [fp, #-0x10]
    // 0xa56114: LoadField: r1 = r0->field_f
    //     0xa56114: ldur            w1, [x0, #0xf]
    // 0xa56118: DecompressPointer r1
    //     0xa56118: add             x1, x1, HEAP, lsl #32
    // 0xa5611c: SaveReg r1
    //     0xa5611c: str             x1, [SP, #-8]!
    // 0xa56120: r0 = markNeedsLayout()
    //     0xa56120: bl              #0x6c0c30  ; [package:flutter/src/rendering/sliver_persistent_header.dart] RenderSliverPersistentHeader::markNeedsLayout
    // 0xa56124: add             SP, SP, #8
    // 0xa56128: r0 = Null
    //     0xa56128: mov             x0, NULL
    // 0xa5612c: LeaveFrame
    //     0xa5612c: mov             SP, fp
    //     0xa56130: ldp             fp, lr, [SP], #0x10
    // 0xa56134: ret
    //     0xa56134: ret             
    // 0xa56138: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa56138: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5613c: b               #0xa56030
    // 0xa56140: r9 = _animation
    //     0xa56140: add             x9, PP, #0x56, lsl #12  ; [pp+0x563e8] Field <RenderSliverFloatingPersistentHeader._animation@917212274>: late (offset: 0x74)
    //     0xa56144: ldr             x9, [x9, #0x3e8]
    // 0xa56148: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa56148: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa5614c: r9 = _animation
    //     0xa5614c: add             x9, PP, #0x56, lsl #12  ; [pp+0x563e8] Field <RenderSliverFloatingPersistentHeader._animation@917212274>: late (offset: 0x74)
    //     0xa56150: ldr             x9, [x9, #0x3e8]
    // 0xa56154: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa56154: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ maybeStopSnapAnimation(/* No info */) {
    // ** addr: 0xa56158, size: 0x50
    // 0xa56158: EnterFrame
    //     0xa56158: stp             fp, lr, [SP, #-0x10]!
    //     0xa5615c: mov             fp, SP
    // 0xa56160: CheckStackOverflow
    //     0xa56160: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa56164: cmp             SP, x16
    //     0xa56168: b.ls            #0xa561a0
    // 0xa5616c: ldr             x0, [fp, #0x10]
    // 0xa56170: LoadField: r1 = r0->field_6f
    //     0xa56170: ldur            w1, [x0, #0x6f]
    // 0xa56174: DecompressPointer r1
    //     0xa56174: add             x1, x1, HEAP, lsl #32
    // 0xa56178: cmp             w1, NULL
    // 0xa5617c: b.eq            #0xa56190
    // 0xa56180: SaveReg r1
    //     0xa56180: str             x1, [SP, #-8]!
    // 0xa56184: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa56184: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa56188: r0 = stop()
    //     0xa56188: bl              #0x593468  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0xa5618c: add             SP, SP, #8
    // 0xa56190: r0 = Null
    //     0xa56190: mov             x0, NULL
    // 0xa56194: LeaveFrame
    //     0xa56194: mov             SP, fp
    //     0xa56198: ldp             fp, lr, [SP], #0x10
    // 0xa5619c: ret
    //     0xa5619c: ret             
    // 0xa561a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa561a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa561a4: b               #0xa5616c
  }
}

// class id: 2557, size: 0x94, field offset: 0x94
abstract class RenderSliverFloatingPinnedPersistentHeader extends RenderSliverFloatingPersistentHeader {
}

// class id: 2560, size: 0x70, field offset: 0x70
abstract class RenderSliverPinnedPersistentHeader extends RenderSliverPersistentHeader {

  _ showOnScreen(/* No info */) {
    // ** addr: 0x642590, size: 0x37c
    // 0x642590: EnterFrame
    //     0x642590: stp             fp, lr, [SP, #-0x10]!
    //     0x642594: mov             fp, SP
    // 0x642598: AllocStack(0x30)
    //     0x642598: sub             SP, SP, #0x30
    // 0x64259c: SetupParameters(RenderSliverPinnedPersistentHeader this /* r3, fp-0x28 */, {dynamic curve = Instance_Cubic /* r4, fp-0x20 */, dynamic descendant = Null /* r5, fp-0x18 */, dynamic duration = Instance_Duration /* r6, fp-0x10 */, dynamic rect = Null /* r0, fp-0x8 */})
    //     0x64259c: mov             x0, x4
    //     0x6425a0: ldur            w1, [x0, #0x13]
    //     0x6425a4: add             x1, x1, HEAP, lsl #32
    //     0x6425a8: sub             x2, x1, #2
    //     0x6425ac: add             x3, fp, w2, sxtw #2
    //     0x6425b0: ldr             x3, [x3, #0x10]
    //     0x6425b4: stur            x3, [fp, #-0x28]
    //     0x6425b8: ldur            w2, [x0, #0x1f]
    //     0x6425bc: add             x2, x2, HEAP, lsl #32
    //     0x6425c0: add             x16, PP, #0xa, lsl #12  ; [pp+0xafc0] "curve"
    //     0x6425c4: ldr             x16, [x16, #0xfc0]
    //     0x6425c8: cmp             w2, w16
    //     0x6425cc: b.ne            #0x6425f0
    //     0x6425d0: ldur            w2, [x0, #0x23]
    //     0x6425d4: add             x2, x2, HEAP, lsl #32
    //     0x6425d8: sub             w4, w1, w2
    //     0x6425dc: add             x2, fp, w4, sxtw #2
    //     0x6425e0: ldr             x2, [x2, #8]
    //     0x6425e4: mov             x4, x2
    //     0x6425e8: mov             x2, #1
    //     0x6425ec: b               #0x6425fc
    //     0x6425f0: add             x4, PP, #0xa, lsl #12  ; [pp+0xafc8] Obj!Cubic<double>@b4f341
    //     0x6425f4: ldr             x4, [x4, #0xfc8]
    //     0x6425f8: mov             x2, #0
    //     0x6425fc: stur            x4, [fp, #-0x20]
    //     0x642600: lsl             x5, x2, #1
    //     0x642604: lsl             w6, w5, #1
    //     0x642608: add             w7, w6, #8
    //     0x64260c: add             x16, x0, w7, sxtw #1
    //     0x642610: ldur            w8, [x16, #0xf]
    //     0x642614: add             x8, x8, HEAP, lsl #32
    //     0x642618: add             x16, PP, #0xa, lsl #12  ; [pp+0xafd0] "descendant"
    //     0x64261c: ldr             x16, [x16, #0xfd0]
    //     0x642620: cmp             w8, w16
    //     0x642624: b.ne            #0x642658
    //     0x642628: add             w2, w6, #0xa
    //     0x64262c: add             x16, x0, w2, sxtw #1
    //     0x642630: ldur            w6, [x16, #0xf]
    //     0x642634: add             x6, x6, HEAP, lsl #32
    //     0x642638: sub             w2, w1, w6
    //     0x64263c: add             x6, fp, w2, sxtw #2
    //     0x642640: ldr             x6, [x6, #8]
    //     0x642644: add             w2, w5, #2
    //     0x642648: sbfx            x5, x2, #1, #0x1f
    //     0x64264c: mov             x2, x5
    //     0x642650: mov             x5, x6
    //     0x642654: b               #0x64265c
    //     0x642658: mov             x5, NULL
    //     0x64265c: stur            x5, [fp, #-0x18]
    //     0x642660: lsl             x6, x2, #1
    //     0x642664: lsl             w7, w6, #1
    //     0x642668: add             w8, w7, #8
    //     0x64266c: add             x16, x0, w8, sxtw #1
    //     0x642670: ldur            w9, [x16, #0xf]
    //     0x642674: add             x9, x9, HEAP, lsl #32
    //     0x642678: add             x16, PP, #0xa, lsl #12  ; [pp+0xafd8] "duration"
    //     0x64267c: ldr             x16, [x16, #0xfd8]
    //     0x642680: cmp             w9, w16
    //     0x642684: b.ne            #0x6426b8
    //     0x642688: add             w2, w7, #0xa
    //     0x64268c: add             x16, x0, w2, sxtw #1
    //     0x642690: ldur            w7, [x16, #0xf]
    //     0x642694: add             x7, x7, HEAP, lsl #32
    //     0x642698: sub             w2, w1, w7
    //     0x64269c: add             x7, fp, w2, sxtw #2
    //     0x6426a0: ldr             x7, [x7, #8]
    //     0x6426a4: add             w2, w6, #2
    //     0x6426a8: sbfx            x6, x2, #1, #0x1f
    //     0x6426ac: mov             x2, x6
    //     0x6426b0: mov             x6, x7
    //     0x6426b4: b               #0x6426bc
    //     0x6426b8: ldr             x6, [PP, #0x33e0]  ; [pp+0x33e0] Obj!Duration@b67a11
    //     0x6426bc: stur            x6, [fp, #-0x10]
    //     0x6426c0: lsl             x7, x2, #1
    //     0x6426c4: lsl             w2, w7, #1
    //     0x6426c8: add             w7, w2, #8
    //     0x6426cc: add             x16, x0, w7, sxtw #1
    //     0x6426d0: ldur            w8, [x16, #0xf]
    //     0x6426d4: add             x8, x8, HEAP, lsl #32
    //     0x6426d8: add             x16, PP, #0xa, lsl #12  ; [pp+0xafe0] "rect"
    //     0x6426dc: ldr             x16, [x16, #0xfe0]
    //     0x6426e0: cmp             w8, w16
    //     0x6426e4: b.ne            #0x64270c
    //     0x6426e8: add             w7, w2, #0xa
    //     0x6426ec: add             x16, x0, w7, sxtw #1
    //     0x6426f0: ldur            w2, [x16, #0xf]
    //     0x6426f4: add             x2, x2, HEAP, lsl #32
    //     0x6426f8: sub             w0, w1, w2
    //     0x6426fc: add             x1, fp, w0, sxtw #2
    //     0x642700: ldr             x1, [x1, #8]
    //     0x642704: mov             x0, x1
    //     0x642708: b               #0x642710
    //     0x64270c: mov             x0, NULL
    //     0x642710: stur            x0, [fp, #-8]
    // 0x642714: CheckStackOverflow
    //     0x642714: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x642718: cmp             SP, x16
    //     0x64271c: b.ls            #0x642904
    // 0x642720: cmp             w5, NULL
    // 0x642724: b.eq            #0x642788
    // 0x642728: stp             x3, x5, [SP, #-0x10]!
    // 0x64272c: r0 = getTransformTo()
    //     0x64272c: bl              #0x643bcc  ; [package:flutter/src/rendering/object.dart] RenderObject::getTransformTo
    // 0x642730: add             SP, SP, #0x10
    // 0x642734: mov             x1, x0
    // 0x642738: ldur            x0, [fp, #-8]
    // 0x64273c: stur            x1, [fp, #-0x30]
    // 0x642740: cmp             w0, NULL
    // 0x642744: b.ne            #0x642770
    // 0x642748: ldur            x0, [fp, #-0x18]
    // 0x64274c: r2 = LoadClassIdInstr(r0)
    //     0x64274c: ldur            x2, [x0, #-1]
    //     0x642750: ubfx            x2, x2, #0xc, #0x14
    // 0x642754: SaveReg r0
    //     0x642754: str             x0, [SP, #-8]!
    // 0x642758: mov             x0, x2
    // 0x64275c: r0 = GDT[cid_x0 + 0xd215]()
    //     0x64275c: mov             x17, #0xd215
    //     0x642760: add             lr, x0, x17
    //     0x642764: ldr             lr, [x21, lr, lsl #3]
    //     0x642768: blr             lr
    // 0x64276c: add             SP, SP, #8
    // 0x642770: ldur            x16, [fp, #-0x30]
    // 0x642774: stp             x0, x16, [SP, #-0x10]!
    // 0x642778: r0 = transformRect()
    //     0x642778: bl              #0x6431fc  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::transformRect
    // 0x64277c: add             SP, SP, #0x10
    // 0x642780: mov             x4, x0
    // 0x642784: b               #0x64278c
    // 0x642788: mov             x4, x0
    // 0x64278c: ldur            x3, [fp, #-0x28]
    // 0x642790: stur            x4, [fp, #-0x18]
    // 0x642794: LoadField: r5 = r3->field_27
    //     0x642794: ldur            w5, [x3, #0x27]
    // 0x642798: DecompressPointer r5
    //     0x642798: add             x5, x5, HEAP, lsl #32
    // 0x64279c: stur            x5, [fp, #-8]
    // 0x6427a0: cmp             w5, NULL
    // 0x6427a4: b.eq            #0x6428e4
    // 0x6427a8: mov             x0, x5
    // 0x6427ac: r2 = Null
    //     0x6427ac: mov             x2, NULL
    // 0x6427b0: r1 = Null
    //     0x6427b0: mov             x1, NULL
    // 0x6427b4: r4 = LoadClassIdInstr(r0)
    //     0x6427b4: ldur            x4, [x0, #-1]
    //     0x6427b8: ubfx            x4, x4, #0xc, #0x14
    // 0x6427bc: cmp             x4, #0x80c
    // 0x6427c0: b.eq            #0x6427d8
    // 0x6427c4: r8 = SliverConstraints
    //     0x6427c4: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x6427c8: ldr             x8, [x8, #0x5a8]
    // 0x6427cc: r3 = Null
    //     0x6427cc: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fa68] Null
    //     0x6427d0: ldr             x3, [x3, #0xa68]
    // 0x6427d4: r0 = DefaultTypeTest()
    //     0x6427d4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6427d8: ldur            x0, [fp, #-8]
    // 0x6427dc: LoadField: r1 = r0->field_7
    //     0x6427dc: ldur            w1, [x0, #7]
    // 0x6427e0: DecompressPointer r1
    //     0x6427e0: add             x1, x1, HEAP, lsl #32
    // 0x6427e4: LoadField: r2 = r0->field_b
    //     0x6427e4: ldur            w2, [x0, #0xb]
    // 0x6427e8: DecompressPointer r2
    //     0x6427e8: add             x2, x2, HEAP, lsl #32
    // 0x6427ec: stp             x2, x1, [SP, #-0x10]!
    // 0x6427f0: r0 = applyGrowthDirectionToAxisDirection()
    //     0x6427f0: bl              #0x643194  ; [package:flutter/src/rendering/sliver.dart] ::applyGrowthDirectionToAxisDirection
    // 0x6427f4: add             SP, SP, #0x10
    // 0x6427f8: LoadField: r1 = r0->field_7
    //     0x6427f8: ldur            x1, [x0, #7]
    // 0x6427fc: cmp             x1, #1
    // 0x642800: b.gt            #0x642858
    // 0x642804: cmp             x1, #0
    // 0x642808: b.gt            #0x642838
    // 0x64280c: ldur            x16, [fp, #-0x28]
    // 0x642810: SaveReg r16
    //     0x642810: str             x16, [SP, #-8]!
    // 0x642814: r0 = childExtent()
    //     0x642814: bl              #0x642fa4  ; [package:flutter/src/rendering/sliver_persistent_header.dart] RenderSliverPersistentHeader::childExtent
    // 0x642818: add             SP, SP, #8
    // 0x64281c: ldur            x16, [fp, #-0x18]
    // 0x642820: stp             x0, x16, [SP, #-0x10]!
    // 0x642824: r4 = const [0, 0x2, 0x2, 0x1, bottom, 0x1, null]
    //     0x642824: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1fbd8] List(7) [0, 0x2, 0x2, 0x1, "bottom", 0x1, Null]
    //     0x642828: ldr             x4, [x4, #0xbd8]
    // 0x64282c: r0 = _trim()
    //     0x64282c: bl              #0x642ac4  ; [package:flutter/src/rendering/sliver_persistent_header.dart] ::_trim
    // 0x642830: add             SP, SP, #0x10
    // 0x642834: b               #0x6428a8
    // 0x642838: ldur            x16, [fp, #-0x18]
    // 0x64283c: r30 = 0.000000
    //     0x64283c: ldr             lr, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x642840: stp             lr, x16, [SP, #-0x10]!
    // 0x642844: r4 = const [0, 0x2, 0x2, 0x1, left, 0x1, null]
    //     0x642844: add             x4, PP, #0x27, lsl #12  ; [pp+0x272f8] List(7) [0, 0x2, 0x2, 0x1, "left", 0x1, Null]
    //     0x642848: ldr             x4, [x4, #0x2f8]
    // 0x64284c: r0 = _trim()
    //     0x64284c: bl              #0x642ac4  ; [package:flutter/src/rendering/sliver_persistent_header.dart] ::_trim
    // 0x642850: add             SP, SP, #0x10
    // 0x642854: b               #0x6428a8
    // 0x642858: cmp             x1, #2
    // 0x64285c: b.gt            #0x642880
    // 0x642860: ldur            x16, [fp, #-0x18]
    // 0x642864: r30 = 0.000000
    //     0x642864: ldr             lr, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x642868: stp             lr, x16, [SP, #-0x10]!
    // 0x64286c: r4 = const [0, 0x2, 0x2, 0x1, top, 0x1, null]
    //     0x64286c: add             x4, PP, #0x30, lsl #12  ; [pp+0x30338] List(7) [0, 0x2, 0x2, 0x1, "top", 0x1, Null]
    //     0x642870: ldr             x4, [x4, #0x338]
    // 0x642874: r0 = _trim()
    //     0x642874: bl              #0x642ac4  ; [package:flutter/src/rendering/sliver_persistent_header.dart] ::_trim
    // 0x642878: add             SP, SP, #0x10
    // 0x64287c: b               #0x6428a8
    // 0x642880: ldur            x16, [fp, #-0x28]
    // 0x642884: SaveReg r16
    //     0x642884: str             x16, [SP, #-8]!
    // 0x642888: r0 = childExtent()
    //     0x642888: bl              #0x642fa4  ; [package:flutter/src/rendering/sliver_persistent_header.dart] RenderSliverPersistentHeader::childExtent
    // 0x64288c: add             SP, SP, #8
    // 0x642890: ldur            x16, [fp, #-0x18]
    // 0x642894: stp             x0, x16, [SP, #-0x10]!
    // 0x642898: r4 = const [0, 0x2, 0x2, 0x1, right, 0x1, null]
    //     0x642898: add             x4, PP, #0x3c, lsl #12  ; [pp+0x3c6c8] List(7) [0, 0x2, 0x2, 0x1, "right", 0x1, Null]
    //     0x64289c: ldr             x4, [x4, #0x6c8]
    // 0x6428a0: r0 = _trim()
    //     0x6428a0: bl              #0x642ac4  ; [package:flutter/src/rendering/sliver_persistent_header.dart] ::_trim
    // 0x6428a4: add             SP, SP, #0x10
    // 0x6428a8: ldur            x16, [fp, #-0x28]
    // 0x6428ac: ldur            lr, [fp, #-0x28]
    // 0x6428b0: stp             lr, x16, [SP, #-0x10]!
    // 0x6428b4: ldur            x16, [fp, #-0x10]
    // 0x6428b8: stp             x16, x0, [SP, #-0x10]!
    // 0x6428bc: ldur            x16, [fp, #-0x20]
    // 0x6428c0: SaveReg r16
    //     0x6428c0: str             x16, [SP, #-8]!
    // 0x6428c4: r4 = const [0, 0x5, 0x5, 0x1, curve, 0x4, descendant, 0x1, duration, 0x3, rect, 0x2, null]
    //     0x6428c4: add             x4, PP, #0xa, lsl #12  ; [pp+0xafe8] List(13) [0, 0x5, 0x5, 0x1, "curve", 0x4, "descendant", 0x1, "duration", 0x3, "rect", 0x2, Null]
    //     0x6428c8: ldr             x4, [x4, #0xfe8]
    // 0x6428cc: r0 = showOnScreen()
    //     0x6428cc: bl              #0x644c40  ; [package:flutter/src/rendering/object.dart] RenderObject::showOnScreen
    // 0x6428d0: add             SP, SP, #0x28
    // 0x6428d4: r0 = Null
    //     0x6428d4: mov             x0, NULL
    // 0x6428d8: LeaveFrame
    //     0x6428d8: mov             SP, fp
    //     0x6428dc: ldp             fp, lr, [SP], #0x10
    // 0x6428e0: ret
    //     0x6428e0: ret             
    // 0x6428e4: r0 = StateError()
    //     0x6428e4: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6428e8: mov             x1, x0
    // 0x6428ec: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6428ec: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6428f0: ldr             x0, [x0, #0x1e8]
    // 0x6428f4: StoreField: r1->field_b = r0
    //     0x6428f4: stur            w0, [x1, #0xb]
    // 0x6428f8: mov             x0, x1
    // 0x6428fc: r0 = Throw()
    //     0x6428fc: bl              #0xd67e38  ; ThrowStub
    // 0x642900: brk             #0
    // 0x642904: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x642904: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x642908: b               #0x642720
  }
  [closure] void showOnScreen(dynamic, {RenderObject? descendant, Rect? rect, Duration duration, Curve curve}) {
    // ** addr: 0x64290c, size: 0x1b8
    // 0x64290c: EnterFrame
    //     0x64290c: stp             fp, lr, [SP, #-0x10]!
    //     0x642910: mov             fp, SP
    // 0x642914: mov             x0, x4
    // 0x642918: LoadField: r1 = r0->field_13
    //     0x642918: ldur            w1, [x0, #0x13]
    // 0x64291c: DecompressPointer r1
    //     0x64291c: add             x1, x1, HEAP, lsl #32
    // 0x642920: sub             x2, x1, #2
    // 0x642924: add             x3, fp, w2, sxtw #2
    // 0x642928: ldr             x3, [x3, #0x10]
    // 0x64292c: LoadField: r2 = r0->field_1f
    //     0x64292c: ldur            w2, [x0, #0x1f]
    // 0x642930: DecompressPointer r2
    //     0x642930: add             x2, x2, HEAP, lsl #32
    // 0x642934: r16 = "curve"
    //     0x642934: add             x16, PP, #0xa, lsl #12  ; [pp+0xafc0] "curve"
    //     0x642938: ldr             x16, [x16, #0xfc0]
    // 0x64293c: cmp             w2, w16
    // 0x642940: b.ne            #0x642964
    // 0x642944: LoadField: r2 = r0->field_23
    //     0x642944: ldur            w2, [x0, #0x23]
    // 0x642948: DecompressPointer r2
    //     0x642948: add             x2, x2, HEAP, lsl #32
    // 0x64294c: sub             w4, w1, w2
    // 0x642950: add             x2, fp, w4, sxtw #2
    // 0x642954: ldr             x2, [x2, #8]
    // 0x642958: mov             x4, x2
    // 0x64295c: r2 = 1
    //     0x64295c: mov             x2, #1
    // 0x642960: b               #0x642970
    // 0x642964: r4 = Instance_Cubic
    //     0x642964: add             x4, PP, #0xa, lsl #12  ; [pp+0xafc8] Obj!Cubic<double>@b4f341
    //     0x642968: ldr             x4, [x4, #0xfc8]
    // 0x64296c: r2 = 0
    //     0x64296c: mov             x2, #0
    // 0x642970: lsl             x5, x2, #1
    // 0x642974: lsl             w6, w5, #1
    // 0x642978: add             w7, w6, #8
    // 0x64297c: ArrayLoad: r8 = r0[r7]  ; Unknown_4
    //     0x64297c: add             x16, x0, w7, sxtw #1
    //     0x642980: ldur            w8, [x16, #0xf]
    // 0x642984: DecompressPointer r8
    //     0x642984: add             x8, x8, HEAP, lsl #32
    // 0x642988: r16 = "descendant"
    //     0x642988: add             x16, PP, #0xa, lsl #12  ; [pp+0xafd0] "descendant"
    //     0x64298c: ldr             x16, [x16, #0xfd0]
    // 0x642990: cmp             w8, w16
    // 0x642994: b.ne            #0x6429c8
    // 0x642998: add             w2, w6, #0xa
    // 0x64299c: ArrayLoad: r6 = r0[r2]  ; Unknown_4
    //     0x64299c: add             x16, x0, w2, sxtw #1
    //     0x6429a0: ldur            w6, [x16, #0xf]
    // 0x6429a4: DecompressPointer r6
    //     0x6429a4: add             x6, x6, HEAP, lsl #32
    // 0x6429a8: sub             w2, w1, w6
    // 0x6429ac: add             x6, fp, w2, sxtw #2
    // 0x6429b0: ldr             x6, [x6, #8]
    // 0x6429b4: add             w2, w5, #2
    // 0x6429b8: r5 = LoadInt32Instr(r2)
    //     0x6429b8: sbfx            x5, x2, #1, #0x1f
    // 0x6429bc: mov             x2, x5
    // 0x6429c0: mov             x5, x6
    // 0x6429c4: b               #0x6429cc
    // 0x6429c8: r5 = Null
    //     0x6429c8: mov             x5, NULL
    // 0x6429cc: lsl             x6, x2, #1
    // 0x6429d0: lsl             w7, w6, #1
    // 0x6429d4: add             w8, w7, #8
    // 0x6429d8: ArrayLoad: r9 = r0[r8]  ; Unknown_4
    //     0x6429d8: add             x16, x0, w8, sxtw #1
    //     0x6429dc: ldur            w9, [x16, #0xf]
    // 0x6429e0: DecompressPointer r9
    //     0x6429e0: add             x9, x9, HEAP, lsl #32
    // 0x6429e4: r16 = "duration"
    //     0x6429e4: add             x16, PP, #0xa, lsl #12  ; [pp+0xafd8] "duration"
    //     0x6429e8: ldr             x16, [x16, #0xfd8]
    // 0x6429ec: cmp             w9, w16
    // 0x6429f0: b.ne            #0x642a24
    // 0x6429f4: add             w2, w7, #0xa
    // 0x6429f8: ArrayLoad: r7 = r0[r2]  ; Unknown_4
    //     0x6429f8: add             x16, x0, w2, sxtw #1
    //     0x6429fc: ldur            w7, [x16, #0xf]
    // 0x642a00: DecompressPointer r7
    //     0x642a00: add             x7, x7, HEAP, lsl #32
    // 0x642a04: sub             w2, w1, w7
    // 0x642a08: add             x7, fp, w2, sxtw #2
    // 0x642a0c: ldr             x7, [x7, #8]
    // 0x642a10: add             w2, w6, #2
    // 0x642a14: r6 = LoadInt32Instr(r2)
    //     0x642a14: sbfx            x6, x2, #1, #0x1f
    // 0x642a18: mov             x2, x6
    // 0x642a1c: mov             x6, x7
    // 0x642a20: b               #0x642a28
    // 0x642a24: r6 = Instance_Duration
    //     0x642a24: ldr             x6, [PP, #0x33e0]  ; [pp+0x33e0] Obj!Duration@b67a11
    // 0x642a28: lsl             x7, x2, #1
    // 0x642a2c: lsl             w2, w7, #1
    // 0x642a30: add             w7, w2, #8
    // 0x642a34: ArrayLoad: r8 = r0[r7]  ; Unknown_4
    //     0x642a34: add             x16, x0, w7, sxtw #1
    //     0x642a38: ldur            w8, [x16, #0xf]
    // 0x642a3c: DecompressPointer r8
    //     0x642a3c: add             x8, x8, HEAP, lsl #32
    // 0x642a40: r16 = "rect"
    //     0x642a40: add             x16, PP, #0xa, lsl #12  ; [pp+0xafe0] "rect"
    //     0x642a44: ldr             x16, [x16, #0xfe0]
    // 0x642a48: cmp             w8, w16
    // 0x642a4c: b.ne            #0x642a74
    // 0x642a50: add             w7, w2, #0xa
    // 0x642a54: ArrayLoad: r2 = r0[r7]  ; Unknown_4
    //     0x642a54: add             x16, x0, w7, sxtw #1
    //     0x642a58: ldur            w2, [x16, #0xf]
    // 0x642a5c: DecompressPointer r2
    //     0x642a5c: add             x2, x2, HEAP, lsl #32
    // 0x642a60: sub             w0, w1, w2
    // 0x642a64: add             x1, fp, w0, sxtw #2
    // 0x642a68: ldr             x1, [x1, #8]
    // 0x642a6c: mov             x0, x1
    // 0x642a70: b               #0x642a78
    // 0x642a74: r0 = Null
    //     0x642a74: mov             x0, NULL
    // 0x642a78: LoadField: r1 = r3->field_17
    //     0x642a78: ldur            w1, [x3, #0x17]
    // 0x642a7c: DecompressPointer r1
    //     0x642a7c: add             x1, x1, HEAP, lsl #32
    // 0x642a80: CheckStackOverflow
    //     0x642a80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x642a84: cmp             SP, x16
    //     0x642a88: b.ls            #0x642abc
    // 0x642a8c: LoadField: r2 = r1->field_f
    //     0x642a8c: ldur            w2, [x1, #0xf]
    // 0x642a90: DecompressPointer r2
    //     0x642a90: add             x2, x2, HEAP, lsl #32
    // 0x642a94: stp             x5, x2, [SP, #-0x10]!
    // 0x642a98: stp             x6, x0, [SP, #-0x10]!
    // 0x642a9c: SaveReg r4
    //     0x642a9c: str             x4, [SP, #-8]!
    // 0x642aa0: r4 = const [0, 0x5, 0x5, 0x1, curve, 0x4, descendant, 0x1, duration, 0x3, rect, 0x2, null]
    //     0x642aa0: add             x4, PP, #0xa, lsl #12  ; [pp+0xafe8] List(13) [0, 0x5, 0x5, 0x1, "curve", 0x4, "descendant", 0x1, "duration", 0x3, "rect", 0x2, Null]
    //     0x642aa4: ldr             x4, [x4, #0xfe8]
    // 0x642aa8: r0 = showOnScreen()
    //     0x642aa8: bl              #0x642590  ; [package:flutter/src/rendering/sliver_persistent_header.dart] RenderSliverPinnedPersistentHeader::showOnScreen
    // 0x642aac: add             SP, SP, #0x28
    // 0x642ab0: LeaveFrame
    //     0x642ab0: mov             SP, fp
    //     0x642ab4: ldp             fp, lr, [SP], #0x10
    // 0x642ab8: ret
    //     0x642ab8: ret             
    // 0x642abc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x642abc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x642ac0: b               #0x642a8c
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x68838c, size: 0x450
    // 0x68838c: EnterFrame
    //     0x68838c: stp             fp, lr, [SP, #-0x10]!
    //     0x688390: mov             fp, SP
    // 0x688394: AllocStack(0x48)
    //     0x688394: sub             SP, SP, #0x48
    // 0x688398: CheckStackOverflow
    //     0x688398: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68839c: cmp             SP, x16
    //     0x6883a0: b.ls            #0x688790
    // 0x6883a4: ldr             x3, [fp, #0x10]
    // 0x6883a8: LoadField: r4 = r3->field_27
    //     0x6883a8: ldur            w4, [x3, #0x27]
    // 0x6883ac: DecompressPointer r4
    //     0x6883ac: add             x4, x4, HEAP, lsl #32
    // 0x6883b0: stur            x4, [fp, #-8]
    // 0x6883b4: cmp             w4, NULL
    // 0x6883b8: b.eq            #0x688770
    // 0x6883bc: mov             x0, x4
    // 0x6883c0: r2 = Null
    //     0x6883c0: mov             x2, NULL
    // 0x6883c4: r1 = Null
    //     0x6883c4: mov             x1, NULL
    // 0x6883c8: r4 = LoadClassIdInstr(r0)
    //     0x6883c8: ldur            x4, [x0, #-1]
    //     0x6883cc: ubfx            x4, x4, #0xc, #0x14
    // 0x6883d0: cmp             x4, #0x80c
    // 0x6883d4: b.eq            #0x6883ec
    // 0x6883d8: r8 = SliverConstraints
    //     0x6883d8: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x6883dc: ldr             x8, [x8, #0x5a8]
    // 0x6883e0: r3 = Null
    //     0x6883e0: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fa88] Null
    //     0x6883e4: ldr             x3, [x3, #0xa88]
    // 0x6883e8: r0 = DefaultTypeTest()
    //     0x6883e8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6883ec: ldr             x16, [fp, #0x10]
    // 0x6883f0: SaveReg r16
    //     0x6883f0: str             x16, [SP, #-8]!
    // 0x6883f4: r0 = maxExtent()
    //     0x6883f4: bl              #0xcefcdc  ; [package:flutter/src/widgets/sliver_persistent_header.dart] __RenderSliverPinnedPersistentHeaderForWidgets&RenderSliverPinnedPersistentHeader&_RenderSliverPersistentHeaderForWidgetsMixin::maxExtent
    // 0x6883f8: add             SP, SP, #8
    // 0x6883fc: ldur            x0, [fp, #-8]
    // 0x688400: stur            d0, [fp, #-0x28]
    // 0x688404: LoadField: d1 = r0->field_23
    //     0x688404: ldur            d1, [x0, #0x23]
    // 0x688408: stur            d1, [fp, #-0x20]
    // 0x68840c: d2 = 0.000000
    //     0x68840c: eor             v2.16b, v2.16b, v2.16b
    // 0x688410: fcmp            d1, d2
    // 0x688414: b.vs            #0x68841c
    // 0x688418: b.gt            #0x688424
    // 0x68841c: r1 = false
    //     0x68841c: add             x1, NULL, #0x30  ; false
    // 0x688420: b               #0x688428
    // 0x688424: r1 = true
    //     0x688424: add             x1, NULL, #0x20  ; true
    // 0x688428: LoadField: d3 = r0->field_13
    //     0x688428: ldur            d3, [x0, #0x13]
    // 0x68842c: stur            d3, [fp, #-0x18]
    // 0x688430: r2 = inline_Allocate_Double()
    //     0x688430: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x688434: add             x2, x2, #0x10
    //     0x688438: cmp             x3, x2
    //     0x68843c: b.ls            #0x688798
    //     0x688440: str             x2, [THR, #0x60]  ; THR::top
    //     0x688444: sub             x2, x2, #0xf
    //     0x688448: mov             x3, #0xd108
    //     0x68844c: movk            x3, #3, lsl #16
    //     0x688450: stur            x3, [x2, #-1]
    // 0x688454: StoreField: r2->field_7 = d3
    //     0x688454: stur            d3, [x2, #7]
    // 0x688458: ldr             x16, [fp, #0x10]
    // 0x68845c: stp             x2, x16, [SP, #-0x10]!
    // 0x688460: SaveReg d0
    //     0x688460: str             d0, [SP, #-8]!
    // 0x688464: SaveReg r1
    //     0x688464: str             x1, [SP, #-8]!
    // 0x688468: r4 = const [0, 0x4, 0x4, 0x3, overlapsContent, 0x3, null]
    //     0x688468: add             x4, PP, #0x4f, lsl #12  ; [pp+0x4fa98] List(7) [0, 0x4, 0x4, 0x3, "overlapsContent", 0x3, Null]
    //     0x68846c: ldr             x4, [x4, #0xa98]
    // 0x688470: r0 = layoutChild()
    //     0x688470: bl              #0x6887dc  ; [package:flutter/src/rendering/sliver_persistent_header.dart] RenderSliverPersistentHeader::layoutChild
    // 0x688474: add             SP, SP, #0x20
    // 0x688478: ldur            x0, [fp, #-8]
    // 0x68847c: LoadField: d0 = r0->field_2b
    //     0x68847c: ldur            d0, [x0, #0x2b]
    // 0x688480: ldur            d1, [fp, #-0x20]
    // 0x688484: fsub            d2, d0, d1
    // 0x688488: d0 = 0.000000
    //     0x688488: eor             v0.16b, v0.16b, v0.16b
    // 0x68848c: fcmp            d0, d2
    // 0x688490: b.vs            #0x6884a0
    // 0x688494: b.le            #0x6884a0
    // 0x688498: d4 = 0.000000
    //     0x688498: eor             v4.16b, v4.16b, v4.16b
    // 0x68849c: b               #0x6884e0
    // 0x6884a0: fcmp            d0, d2
    // 0x6884a4: b.vs            #0x6884b4
    // 0x6884a8: b.ge            #0x6884b4
    // 0x6884ac: mov             v4.16b, v2.16b
    // 0x6884b0: b               #0x6884e0
    // 0x6884b4: fcmp            d0, d0
    // 0x6884b8: b.vs            #0x6884cc
    // 0x6884bc: b.ne            #0x6884cc
    // 0x6884c0: fadd            d3, d0, d2
    // 0x6884c4: mov             v4.16b, v3.16b
    // 0x6884c8: b               #0x6884e0
    // 0x6884cc: fcmp            d2, d2
    // 0x6884d0: b.vc            #0x6884dc
    // 0x6884d4: mov             v4.16b, v2.16b
    // 0x6884d8: b               #0x6884e0
    // 0x6884dc: d4 = 0.000000
    //     0x6884dc: eor             v4.16b, v4.16b, v4.16b
    // 0x6884e0: ldur            d2, [fp, #-0x28]
    // 0x6884e4: ldur            d3, [fp, #-0x18]
    // 0x6884e8: stur            d4, [fp, #-0x38]
    // 0x6884ec: fsub            d5, d2, d3
    // 0x6884f0: fcmp            d5, d0
    // 0x6884f4: b.vs            #0x688504
    // 0x6884f8: b.ge            #0x688504
    // 0x6884fc: d3 = 0.000000
    //     0x6884fc: eor             v3.16b, v3.16b, v3.16b
    // 0x688500: b               #0x68852c
    // 0x688504: fcmp            d5, d4
    // 0x688508: b.vs            #0x688518
    // 0x68850c: b.le            #0x688518
    // 0x688510: mov             v3.16b, v4.16b
    // 0x688514: b               #0x68852c
    // 0x688518: fcmp            d5, d5
    // 0x68851c: b.vc            #0x688528
    // 0x688520: mov             v3.16b, v4.16b
    // 0x688524: b               #0x68852c
    // 0x688528: mov             v3.16b, v5.16b
    // 0x68852c: ldr             x1, [fp, #0x10]
    // 0x688530: stur            d3, [fp, #-0x30]
    // 0x688534: LoadField: r2 = r1->field_6b
    //     0x688534: ldur            w2, [x1, #0x6b]
    // 0x688538: DecompressPointer r2
    //     0x688538: add             x2, x2, HEAP, lsl #32
    // 0x68853c: cmp             w2, NULL
    // 0x688540: b.eq            #0x688574
    // 0x688544: fcmp            d1, d0
    // 0x688548: b.vs            #0x688558
    // 0x68854c: b.ne            #0x688558
    // 0x688550: d5 = 0.000000
    //     0x688550: eor             v5.16b, v5.16b, v5.16b
    // 0x688554: b               #0x688578
    // 0x688558: fcmp            d1, d0
    // 0x68855c: b.vs            #0x68856c
    // 0x688560: b.ge            #0x68856c
    // 0x688564: fneg            d5, d1
    // 0x688568: b               #0x688578
    // 0x68856c: mov             v5.16b, v1.16b
    // 0x688570: b               #0x688578
    // 0x688574: d5 = 0.000000
    //     0x688574: eor             v5.16b, v5.16b, v5.16b
    // 0x688578: stur            d5, [fp, #-0x18]
    // 0x68857c: SaveReg r1
    //     0x68857c: str             x1, [SP, #-8]!
    // 0x688580: r0 = childExtent()
    //     0x688580: bl              #0x642fa4  ; [package:flutter/src/rendering/sliver_persistent_header.dart] RenderSliverPersistentHeader::childExtent
    // 0x688584: add             SP, SP, #8
    // 0x688588: stur            x0, [fp, #-0x10]
    // 0x68858c: cmp             w0, NULL
    // 0x688590: b.eq            #0x6887bc
    // 0x688594: LoadField: d0 = r0->field_7
    //     0x688594: ldur            d0, [x0, #7]
    // 0x688598: ldur            d1, [fp, #-0x38]
    // 0x68859c: fcmp            d0, d1
    // 0x6885a0: b.vs            #0x6885b0
    // 0x6885a4: b.le            #0x6885b0
    // 0x6885a8: mov             v3.16b, v1.16b
    // 0x6885ac: b               #0x688660
    // 0x6885b0: fcmp            d0, d1
    // 0x6885b4: b.vs            #0x6885c8
    // 0x6885b8: b.ge            #0x6885c8
    // 0x6885bc: LoadField: d0 = r0->field_7
    //     0x6885bc: ldur            d0, [x0, #7]
    // 0x6885c0: mov             v3.16b, v0.16b
    // 0x6885c4: b               #0x688660
    // 0x6885c8: d2 = 0.000000
    //     0x6885c8: eor             v2.16b, v2.16b, v2.16b
    // 0x6885cc: fcmp            d0, d2
    // 0x6885d0: b.vs            #0x6885d8
    // 0x6885d4: b.eq            #0x6885e0
    // 0x6885d8: r1 = false
    //     0x6885d8: add             x1, NULL, #0x30  ; false
    // 0x6885dc: b               #0x6885e4
    // 0x6885e0: r1 = true
    //     0x6885e0: add             x1, NULL, #0x20  ; true
    // 0x6885e4: tbnz            w1, #4, #0x6885fc
    // 0x6885e8: fadd            d3, d0, d1
    // 0x6885ec: fmul            d4, d3, d0
    // 0x6885f0: fmul            d0, d4, d1
    // 0x6885f4: mov             v3.16b, v0.16b
    // 0x6885f8: b               #0x688660
    // 0x6885fc: tbnz            w1, #4, #0x688640
    // 0x688600: r1 = inline_Allocate_Double()
    //     0x688600: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x688604: add             x1, x1, #0x10
    //     0x688608: cmp             x2, x1
    //     0x68860c: b.ls            #0x6887c0
    //     0x688610: str             x1, [THR, #0x60]  ; THR::top
    //     0x688614: sub             x1, x1, #0xf
    //     0x688618: mov             x2, #0xd108
    //     0x68861c: movk            x2, #3, lsl #16
    //     0x688620: stur            x2, [x1, #-1]
    // 0x688624: StoreField: r1->field_7 = d1
    //     0x688624: stur            d1, [x1, #7]
    // 0x688628: SaveReg r1
    //     0x688628: str             x1, [SP, #-8]!
    // 0x68862c: r0 = isNegative()
    //     0x68862c: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x688630: add             SP, SP, #8
    // 0x688634: tbnz            w0, #4, #0x688640
    // 0x688638: ldur            d0, [fp, #-0x38]
    // 0x68863c: b               #0x68864c
    // 0x688640: ldur            d0, [fp, #-0x38]
    // 0x688644: fcmp            d0, d0
    // 0x688648: b.vc            #0x688654
    // 0x68864c: mov             v3.16b, v0.16b
    // 0x688650: b               #0x688660
    // 0x688654: ldur            x0, [fp, #-0x10]
    // 0x688658: LoadField: d0 = r0->field_7
    //     0x688658: ldur            d0, [x0, #7]
    // 0x68865c: mov             v3.16b, v0.16b
    // 0x688660: ldur            d0, [fp, #-0x28]
    // 0x688664: ldur            d2, [fp, #-0x18]
    // 0x688668: ldur            d1, [fp, #-0x30]
    // 0x68866c: stur            d3, [fp, #-0x40]
    // 0x688670: fadd            d4, d0, d2
    // 0x688674: stur            d4, [fp, #-0x38]
    // 0x688678: ldr             x16, [fp, #0x10]
    // 0x68867c: SaveReg r16
    //     0x68867c: str             x16, [SP, #-8]!
    // 0x688680: r0 = minExtent()
    //     0x688680: bl              #0xc74c54  ; [package:flutter/src/widgets/sliver_persistent_header.dart] __RenderSliverPinnedPersistentHeaderForWidgets&RenderSliverPinnedPersistentHeader&_RenderSliverPersistentHeaderForWidgetsMixin::minExtent
    // 0x688684: add             SP, SP, #8
    // 0x688688: mov             v2.16b, v0.16b
    // 0x68868c: ldur            d1, [fp, #-0x30]
    // 0x688690: d0 = 0.000000
    //     0x688690: eor             v0.16b, v0.16b, v0.16b
    // 0x688694: stur            d2, [fp, #-0x48]
    // 0x688698: fcmp            d1, d0
    // 0x68869c: b.vs            #0x6886bc
    // 0x6886a0: b.le            #0x6886bc
    // 0x6886a4: ldur            x0, [fp, #-8]
    // 0x6886a8: LoadField: d3 = r0->field_47
    //     0x6886a8: ldur            d3, [x0, #0x47]
    // 0x6886ac: fneg            d4, d3
    // 0x6886b0: fadd            d3, d4, d1
    // 0x6886b4: mov             v7.16b, v3.16b
    // 0x6886b8: b               #0x6886c0
    // 0x6886bc: mov             v7.16b, v1.16b
    // 0x6886c0: ldr             x0, [fp, #0x10]
    // 0x6886c4: ldur            d3, [fp, #-0x28]
    // 0x6886c8: ldur            d6, [fp, #-0x20]
    // 0x6886cc: ldur            d5, [fp, #-0x38]
    // 0x6886d0: ldur            d4, [fp, #-0x40]
    // 0x6886d4: stur            d7, [fp, #-0x18]
    // 0x6886d8: r0 = SliverGeometry()
    //     0x6886d8: bl              #0x679334  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x54)
    // 0x6886dc: ldur            d0, [fp, #-0x28]
    // 0x6886e0: StoreField: r0->field_7 = d0
    //     0x6886e0: stur            d0, [x0, #7]
    // 0x6886e4: ldur            d0, [fp, #-0x40]
    // 0x6886e8: StoreField: r0->field_17 = d0
    //     0x6886e8: stur            d0, [x0, #0x17]
    // 0x6886ec: ldur            d1, [fp, #-0x20]
    // 0x6886f0: StoreField: r0->field_f = d1
    //     0x6886f0: stur            d1, [x0, #0xf]
    // 0x6886f4: ldur            d1, [fp, #-0x38]
    // 0x6886f8: StoreField: r0->field_27 = d1
    //     0x6886f8: stur            d1, [x0, #0x27]
    // 0x6886fc: ldur            d1, [fp, #-0x48]
    // 0x688700: StoreField: r0->field_2f = d1
    //     0x688700: stur            d1, [x0, #0x2f]
    // 0x688704: r1 = true
    //     0x688704: add             x1, NULL, #0x20  ; true
    // 0x688708: StoreField: r0->field_43 = r1
    //     0x688708: stur            w1, [x0, #0x43]
    // 0x68870c: ldur            d1, [fp, #-0x30]
    // 0x688710: StoreField: r0->field_1f = d1
    //     0x688710: stur            d1, [x0, #0x1f]
    // 0x688714: StoreField: r0->field_37 = d0
    //     0x688714: stur            d0, [x0, #0x37]
    // 0x688718: ldur            d1, [fp, #-0x18]
    // 0x68871c: StoreField: r0->field_4b = d1
    //     0x68871c: stur            d1, [x0, #0x4b]
    // 0x688720: d1 = 0.000000
    //     0x688720: eor             v1.16b, v1.16b, v1.16b
    // 0x688724: fcmp            d0, d1
    // 0x688728: b.vs            #0x688730
    // 0x68872c: b.gt            #0x688738
    // 0x688730: r1 = false
    //     0x688730: add             x1, NULL, #0x30  ; false
    // 0x688734: b               #0x68873c
    // 0x688738: r1 = true
    //     0x688738: add             x1, NULL, #0x20  ; true
    // 0x68873c: StoreField: r0->field_3f = r1
    //     0x68873c: stur            w1, [x0, #0x3f]
    // 0x688740: ldr             x1, [fp, #0x10]
    // 0x688744: StoreField: r1->field_4f = r0
    //     0x688744: stur            w0, [x1, #0x4f]
    //     0x688748: ldurb           w16, [x1, #-1]
    //     0x68874c: ldurb           w17, [x0, #-1]
    //     0x688750: and             x16, x17, x16, lsr #2
    //     0x688754: tst             x16, HEAP, lsr #32
    //     0x688758: b.eq            #0x688760
    //     0x68875c: bl              #0xd6826c
    // 0x688760: r0 = Null
    //     0x688760: mov             x0, NULL
    // 0x688764: LeaveFrame
    //     0x688764: mov             SP, fp
    //     0x688768: ldp             fp, lr, [SP], #0x10
    // 0x68876c: ret
    //     0x68876c: ret             
    // 0x688770: r0 = StateError()
    //     0x688770: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x688774: mov             x1, x0
    // 0x688778: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x688778: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68877c: ldr             x0, [x0, #0x1e8]
    // 0x688780: StoreField: r1->field_b = r0
    //     0x688780: stur            w0, [x1, #0xb]
    // 0x688784: mov             x0, x1
    // 0x688788: r0 = Throw()
    //     0x688788: bl              #0xd67e38  ; ThrowStub
    // 0x68878c: brk             #0
    // 0x688790: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x688790: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x688794: b               #0x6883a4
    // 0x688798: stp             q2, q3, [SP, #-0x20]!
    // 0x68879c: stp             q0, q1, [SP, #-0x20]!
    // 0x6887a0: stp             x0, x1, [SP, #-0x10]!
    // 0x6887a4: r0 = AllocateDouble()
    //     0x6887a4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6887a8: mov             x2, x0
    // 0x6887ac: ldp             x0, x1, [SP], #0x10
    // 0x6887b0: ldp             q0, q1, [SP], #0x20
    // 0x6887b4: ldp             q2, q3, [SP], #0x20
    // 0x6887b8: b               #0x688454
    // 0x6887bc: r0 = NullErrorSharedWithoutFPURegs()
    //     0x6887bc: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x6887c0: stp             q1, q2, [SP, #-0x20]!
    // 0x6887c4: SaveReg r0
    //     0x6887c4: str             x0, [SP, #-8]!
    // 0x6887c8: r0 = AllocateDouble()
    //     0x6887c8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6887cc: mov             x1, x0
    // 0x6887d0: RestoreReg r0
    //     0x6887d0: ldr             x0, [SP], #8
    // 0x6887d4: ldp             q1, q2, [SP], #0x20
    // 0x6887d8: b               #0x688624
  }
  dynamic showOnScreen(dynamic) {
    // ** addr: 0x6aba30, size: 0x18
    // 0x6aba30: r4 = 0
    //     0x6aba30: mov             x4, #0
    // 0x6aba34: r1 = Function 'showOnScreen':.
    //     0x6aba34: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fa60] AnonymousClosure: (0x64290c), in [package:flutter/src/rendering/sliver_persistent_header.dart] RenderSliverPinnedPersistentHeader::showOnScreen (0x642590)
    //     0x6aba38: ldr             x1, [x17, #0xa60]
    // 0x6aba3c: r24 = BuildNonGenericMethodExtractorStub
    //     0x6aba3c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x6aba40: LoadField: r0 = r24->field_17
    //     0x6aba40: ldur            x0, [x24, #0x17]
    // 0x6aba44: br              x0
  }
}

// class id: 2563, size: 0x74, field offset: 0x70
abstract class RenderSliverScrollingPersistentHeader extends RenderSliverPersistentHeader {
}

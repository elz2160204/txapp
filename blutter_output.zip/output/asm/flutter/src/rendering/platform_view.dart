// lib: , url: package:flutter/src/rendering/platform_view.dart

// class id: 1049413, size: 0x8
class :: {

  static _ _factoryTypesSetEquals(/* No info */) {
    // ** addr: 0x6d43d0, size: 0x104
    // 0x6d43d0: EnterFrame
    //     0x6d43d0: stp             fp, lr, [SP, #-0x10]!
    //     0x6d43d4: mov             fp, SP
    // 0x6d43d8: AllocStack(0x10)
    //     0x6d43d8: sub             SP, SP, #0x10
    // 0x6d43dc: SetupParameters()
    //     0x6d43dc: mov             x0, x4
    //     0x6d43e0: ldur            w1, [x0, #0xf]
    //     0x6d43e4: add             x1, x1, HEAP, lsl #32
    //     0x6d43e8: cbnz            w1, #0x6d43f4
    //     0x6d43ec: mov             x2, NULL
    //     0x6d43f0: b               #0x6d4408
    //     0x6d43f4: ldur            w1, [x0, #0x17]
    //     0x6d43f8: add             x1, x1, HEAP, lsl #32
    //     0x6d43fc: add             x0, fp, w1, sxtw #2
    //     0x6d4400: ldr             x0, [x0, #0x10]
    //     0x6d4404: mov             x2, x0
    //     0x6d4408: ldr             x1, [fp, #0x18]
    //     0x6d440c: stur            x2, [fp, #-8]
    // 0x6d4410: CheckStackOverflow
    //     0x6d4410: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d4414: cmp             SP, x16
    //     0x6d4418: b.ls            #0x6d44cc
    // 0x6d441c: r0 = LoadClassIdInstr(r1)
    //     0x6d441c: ldur            x0, [x1, #-1]
    //     0x6d4420: ubfx            x0, x0, #0xc, #0x14
    // 0x6d4424: ldr             x16, [fp, #0x10]
    // 0x6d4428: stp             x16, x1, [SP, #-0x10]!
    // 0x6d442c: mov             lr, x0
    // 0x6d4430: ldr             lr, [x21, lr, lsl #3]
    // 0x6d4434: blr             lr
    // 0x6d4438: add             SP, SP, #0x10
    // 0x6d443c: tbnz            w0, #4, #0x6d4450
    // 0x6d4440: r0 = true
    //     0x6d4440: add             x0, NULL, #0x20  ; true
    // 0x6d4444: LeaveFrame
    //     0x6d4444: mov             SP, fp
    //     0x6d4448: ldp             fp, lr, [SP], #0x10
    // 0x6d444c: ret
    //     0x6d444c: ret             
    // 0x6d4450: ldr             x0, [fp, #0x10]
    // 0x6d4454: cmp             w0, NULL
    // 0x6d4458: b.ne            #0x6d446c
    // 0x6d445c: r0 = false
    //     0x6d445c: add             x0, NULL, #0x30  ; false
    // 0x6d4460: LeaveFrame
    //     0x6d4460: mov             SP, fp
    //     0x6d4464: ldp             fp, lr, [SP], #0x10
    // 0x6d4468: ret
    //     0x6d4468: ret             
    // 0x6d446c: ldur            x16, [fp, #-8]
    // 0x6d4470: ldr             lr, [fp, #0x18]
    // 0x6d4474: stp             lr, x16, [SP, #-0x10]!
    // 0x6d4478: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x6d4478: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x6d447c: r0 = _factoriesTypeSet()
    //     0x6d447c: bl              #0x6d4674  ; [package:flutter/src/rendering/platform_view.dart] ::_factoriesTypeSet
    // 0x6d4480: add             SP, SP, #0x10
    // 0x6d4484: stur            x0, [fp, #-0x10]
    // 0x6d4488: ldur            x16, [fp, #-8]
    // 0x6d448c: ldr             lr, [fp, #0x10]
    // 0x6d4490: stp             lr, x16, [SP, #-0x10]!
    // 0x6d4494: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x6d4494: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x6d4498: r0 = _factoriesTypeSet()
    //     0x6d4498: bl              #0x6d4674  ; [package:flutter/src/rendering/platform_view.dart] ::_factoriesTypeSet
    // 0x6d449c: add             SP, SP, #0x10
    // 0x6d44a0: r16 = <Type>
    //     0x6d44a0: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fb00] TypeArguments: <Type>
    //     0x6d44a4: ldr             x16, [x16, #0xb00]
    // 0x6d44a8: ldur            lr, [fp, #-0x10]
    // 0x6d44ac: stp             lr, x16, [SP, #-0x10]!
    // 0x6d44b0: SaveReg r0
    //     0x6d44b0: str             x0, [SP, #-8]!
    // 0x6d44b4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x6d44b4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x6d44b8: r0 = setEquals()
    //     0x6d44b8: bl              #0x6d44d4  ; [package:flutter/src/foundation/collections.dart] ::setEquals
    // 0x6d44bc: add             SP, SP, #0x18
    // 0x6d44c0: LeaveFrame
    //     0x6d44c0: mov             SP, fp
    //     0x6d44c4: ldp             fp, lr, [SP], #0x10
    // 0x6d44c8: ret
    //     0x6d44c8: ret             
    // 0x6d44cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d44cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d44d0: b               #0x6d441c
  }
  static _ _factoriesTypeSet(/* No info */) {
    // ** addr: 0x6d4674, size: 0xc0
    // 0x6d4674: EnterFrame
    //     0x6d4674: stp             fp, lr, [SP, #-0x10]!
    //     0x6d4678: mov             fp, SP
    // 0x6d467c: AllocStack(0x8)
    //     0x6d467c: sub             SP, SP, #8
    // 0x6d4680: SetupParameters()
    //     0x6d4680: mov             x0, x4
    //     0x6d4684: ldur            w1, [x0, #0xf]
    //     0x6d4688: add             x1, x1, HEAP, lsl #32
    //     0x6d468c: cbnz            w1, #0x6d4698
    //     0x6d4690: mov             x3, NULL
    //     0x6d4694: b               #0x6d46ac
    //     0x6d4698: ldur            w1, [x0, #0x17]
    //     0x6d469c: add             x1, x1, HEAP, lsl #32
    //     0x6d46a0: add             x0, fp, w1, sxtw #2
    //     0x6d46a4: ldr             x0, [x0, #0x10]
    //     0x6d46a8: mov             x3, x0
    //     0x6d46ac: ldr             x0, [fp, #0x10]
    //     0x6d46b0: stur            x3, [fp, #-8]
    // 0x6d46b4: CheckStackOverflow
    //     0x6d46b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d46b8: cmp             SP, x16
    //     0x6d46bc: b.ls            #0x6d472c
    // 0x6d46c0: r1 = Function '<anonymous closure>': static.
    //     0x6d46c0: add             x1, PP, #0x49, lsl #12  ; [pp+0x49970] AnonymousClosure: static (0x6d4734), in [package:flutter/src/rendering/platform_view.dart] ::_factoriesTypeSet (0x6d4674)
    //     0x6d46c4: ldr             x1, [x1, #0x970]
    // 0x6d46c8: r2 = Null
    //     0x6d46c8: mov             x2, NULL
    // 0x6d46cc: r0 = AllocateClosure()
    //     0x6d46cc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6d46d0: mov             x1, x0
    // 0x6d46d4: ldur            x0, [fp, #-8]
    // 0x6d46d8: StoreField: r1->field_b = r0
    //     0x6d46d8: stur            w0, [x1, #0xb]
    // 0x6d46dc: ldr             x0, [fp, #0x10]
    // 0x6d46e0: r2 = LoadClassIdInstr(r0)
    //     0x6d46e0: ldur            x2, [x0, #-1]
    //     0x6d46e4: ubfx            x2, x2, #0xc, #0x14
    // 0x6d46e8: r16 = <Type>
    //     0x6d46e8: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fb00] TypeArguments: <Type>
    //     0x6d46ec: ldr             x16, [x16, #0xb00]
    // 0x6d46f0: stp             x0, x16, [SP, #-0x10]!
    // 0x6d46f4: SaveReg r1
    //     0x6d46f4: str             x1, [SP, #-8]!
    // 0x6d46f8: mov             x0, x2
    // 0x6d46fc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x6d46fc: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x6d4700: r0 = GDT[cid_x0 + 0xc934]()
    //     0x6d4700: mov             x17, #0xc934
    //     0x6d4704: add             lr, x0, x17
    //     0x6d4708: ldr             lr, [x21, lr, lsl #3]
    //     0x6d470c: blr             lr
    // 0x6d4710: add             SP, SP, #0x18
    // 0x6d4714: SaveReg r0
    //     0x6d4714: str             x0, [SP, #-8]!
    // 0x6d4718: r0 = toSet()
    //     0x6d4718: bl              #0x6aa2c4  ; [dart:core] _GrowableList::toSet
    // 0x6d471c: add             SP, SP, #8
    // 0x6d4720: LeaveFrame
    //     0x6d4720: mov             SP, fp
    //     0x6d4724: ldp             fp, lr, [SP], #0x10
    // 0x6d4728: ret
    //     0x6d4728: ret             
    // 0x6d472c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d472c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d4730: b               #0x6d46c0
  }
  [closure] static Type <anonymous closure>(dynamic, Factory<Y0>) {
    // ** addr: 0x6d4734, size: 0x4c
    // 0x6d4734: EnterFrame
    //     0x6d4734: stp             fp, lr, [SP, #-0x10]!
    //     0x6d4738: mov             fp, SP
    // 0x6d473c: CheckStackOverflow
    //     0x6d473c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d4740: cmp             SP, x16
    //     0x6d4744: b.ls            #0x6d4778
    // 0x6d4748: ldr             x16, [fp, #0x10]
    // 0x6d474c: SaveReg r16
    //     0x6d474c: str             x16, [SP, #-8]!
    // 0x6d4750: r4 = 0
    //     0x6d4750: mov             x4, #0
    // 0x6d4754: ldr             x0, [SP]
    // 0x6d4758: r16 = UnlinkedCall_0x4aeefc
    //     0x6d4758: add             x16, PP, #0x49, lsl #12  ; [pp+0x49978] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x6d475c: add             x16, x16, #0x978
    // 0x6d4760: ldp             x5, lr, [x16]
    // 0x6d4764: blr             lr
    // 0x6d4768: add             SP, SP, #8
    // 0x6d476c: LeaveFrame
    //     0x6d476c: mov             SP, fp
    //     0x6d4770: ldp             fp, lr, [SP], #0x10
    // 0x6d4774: ret
    //     0x6d4774: ret             
    // 0x6d4778: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d4778: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d477c: b               #0x6d4748
  }
}

// class id: 2349, size: 0x34, field offset: 0x20
class _PlatformViewGestureRecognizer extends OneSequenceGestureRecognizer {

  late (dynamic, PointerEvent) => Future<void> _handlePointerEvent; // offset: 0x20
  late Set<OneSequenceGestureRecognizer> _gestureRecognizers; // offset: 0x30

  _ _PlatformViewGestureRecognizer(/* No info */) {
    // ** addr: 0x6d4afc, size: 0x20c
    // 0x6d4afc: EnterFrame
    //     0x6d4afc: stp             fp, lr, [SP, #-0x10]!
    //     0x6d4b00: mov             fp, SP
    // 0x6d4b04: AllocStack(0x18)
    //     0x6d4b04: sub             SP, SP, #0x18
    // 0x6d4b08: CheckStackOverflow
    //     0x6d4b08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d4b0c: cmp             SP, x16
    //     0x6d4b10: b.ls            #0x6d4d00
    // 0x6d4b14: r1 = 1
    //     0x6d4b14: mov             x1, #1
    // 0x6d4b18: r0 = AllocateContext()
    //     0x6d4b18: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6d4b1c: mov             x1, x0
    // 0x6d4b20: ldr             x0, [fp, #0x18]
    // 0x6d4b24: stur            x1, [fp, #-8]
    // 0x6d4b28: StoreField: r1->field_f = r0
    //     0x6d4b28: stur            w0, [x1, #0xf]
    // 0x6d4b2c: r2 = Sentinel
    //     0x6d4b2c: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6d4b30: StoreField: r0->field_1f = r2
    //     0x6d4b30: stur            w2, [x0, #0x1f]
    // 0x6d4b34: StoreField: r0->field_2f = r2
    //     0x6d4b34: stur            w2, [x0, #0x2f]
    // 0x6d4b38: r16 = <int, List<PointerEvent>>
    //     0x6d4b38: add             x16, PP, #0x49, lsl #12  ; [pp+0x49a38] TypeArguments: <int, List<PointerEvent>>
    //     0x6d4b3c: ldr             x16, [x16, #0xa38]
    // 0x6d4b40: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x6d4b44: stp             lr, x16, [SP, #-0x10]!
    // 0x6d4b48: r0 = Map._fromLiteral()
    //     0x6d4b48: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x6d4b4c: add             SP, SP, #0x10
    // 0x6d4b50: ldr             x1, [fp, #0x18]
    // 0x6d4b54: StoreField: r1->field_23 = r0
    //     0x6d4b54: stur            w0, [x1, #0x23]
    //     0x6d4b58: tbz             w0, #0, #0x6d4b74
    //     0x6d4b5c: ldurb           w16, [x1, #-1]
    //     0x6d4b60: ldurb           w17, [x0, #-1]
    //     0x6d4b64: and             x16, x17, x16, lsr #2
    //     0x6d4b68: tst             x16, HEAP, lsr #32
    //     0x6d4b6c: b.eq            #0x6d4b74
    //     0x6d4b70: bl              #0xd6826c
    // 0x6d4b74: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x6d4b74: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6d4b78: ldr             x0, [x0, #0x598]
    //     0x6d4b7c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6d4b80: cmp             w0, w16
    //     0x6d4b84: b.ne            #0x6d4b90
    //     0x6d4b88: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x6d4b8c: bl              #0xd67cdc
    // 0x6d4b90: r1 = <int>
    //     0x6d4b90: ldr             x1, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0x6d4b94: stur            x0, [fp, #-0x10]
    // 0x6d4b98: r0 = _Set()
    //     0x6d4b98: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x6d4b9c: mov             x1, x0
    // 0x6d4ba0: ldur            x0, [fp, #-0x10]
    // 0x6d4ba4: stur            x1, [fp, #-0x18]
    // 0x6d4ba8: StoreField: r1->field_1b = r0
    //     0x6d4ba8: stur            w0, [x1, #0x1b]
    // 0x6d4bac: StoreField: r1->field_b = rZR
    //     0x6d4bac: stur            wzr, [x1, #0xb]
    // 0x6d4bb0: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x6d4bb0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6d4bb4: ldr             x0, [x0, #0x5a0]
    //     0x6d4bb8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6d4bbc: cmp             w0, w16
    //     0x6d4bc0: b.ne            #0x6d4bcc
    //     0x6d4bc4: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x6d4bc8: bl              #0xd67cdc
    // 0x6d4bcc: mov             x1, x0
    // 0x6d4bd0: ldur            x0, [fp, #-0x18]
    // 0x6d4bd4: StoreField: r0->field_f = r1
    //     0x6d4bd4: stur            w1, [x0, #0xf]
    // 0x6d4bd8: StoreField: r0->field_13 = rZR
    //     0x6d4bd8: stur            wzr, [x0, #0x13]
    // 0x6d4bdc: StoreField: r0->field_17 = rZR
    //     0x6d4bdc: stur            wzr, [x0, #0x17]
    // 0x6d4be0: ldr             x1, [fp, #0x18]
    // 0x6d4be4: StoreField: r1->field_27 = r0
    //     0x6d4be4: stur            w0, [x1, #0x27]
    //     0x6d4be8: ldurb           w16, [x1, #-1]
    //     0x6d4bec: ldurb           w17, [x0, #-1]
    //     0x6d4bf0: and             x16, x17, x16, lsr #2
    //     0x6d4bf4: tst             x16, HEAP, lsr #32
    //     0x6d4bf8: b.eq            #0x6d4c00
    //     0x6d4bfc: bl              #0xd6826c
    // 0x6d4c00: r0 = _ConstSet len:0
    //     0x6d4c00: add             x0, PP, #0x23, lsl #12  ; [pp+0x23a78] Set<Factory<OneSequenceGestureRecognizer>>(0)
    //     0x6d4c04: ldr             x0, [x0, #0xa78]
    // 0x6d4c08: StoreField: r1->field_2b = r0
    //     0x6d4c08: stur            w0, [x1, #0x2b]
    // 0x6d4c0c: SaveReg r1
    //     0x6d4c0c: str             x1, [SP, #-8]!
    // 0x6d4c10: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6d4c10: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6d4c14: r0 = OneSequenceGestureRecognizer()
    //     0x6d4c14: bl              #0x6d3ef4  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::OneSequenceGestureRecognizer
    // 0x6d4c18: add             SP, SP, #8
    // 0x6d4c1c: r16 = <int, _CombiningGestureArenaMember>
    //     0x6d4c1c: add             x16, PP, #0x49, lsl #12  ; [pp+0x49938] TypeArguments: <int, _CombiningGestureArenaMember>
    //     0x6d4c20: ldr             x16, [x16, #0x938]
    // 0x6d4c24: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x6d4c28: stp             lr, x16, [SP, #-0x10]!
    // 0x6d4c2c: r0 = Map._fromLiteral()
    //     0x6d4c2c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x6d4c30: add             SP, SP, #0x10
    // 0x6d4c34: stur            x0, [fp, #-0x10]
    // 0x6d4c38: r0 = GestureArenaTeam()
    //     0x6d4c38: bl              #0x6d3ee8  ; AllocateGestureArenaTeamStub -> GestureArenaTeam (size=0x10)
    // 0x6d4c3c: mov             x1, x0
    // 0x6d4c40: ldur            x0, [fp, #-0x10]
    // 0x6d4c44: StoreField: r1->field_7 = r0
    //     0x6d4c44: stur            w0, [x1, #7]
    // 0x6d4c48: ldr             x3, [fp, #0x18]
    // 0x6d4c4c: StoreField: r1->field_b = r3
    //     0x6d4c4c: stur            w3, [x1, #0xb]
    // 0x6d4c50: mov             x0, x1
    // 0x6d4c54: StoreField: r3->field_1b = r0
    //     0x6d4c54: stur            w0, [x3, #0x1b]
    //     0x6d4c58: ldurb           w16, [x3, #-1]
    //     0x6d4c5c: ldurb           w17, [x0, #-1]
    //     0x6d4c60: and             x16, x17, x16, lsr #2
    //     0x6d4c64: tst             x16, HEAP, lsr #32
    //     0x6d4c68: b.eq            #0x6d4c70
    //     0x6d4c6c: bl              #0xd682ac
    // 0x6d4c70: ldur            x2, [fp, #-8]
    // 0x6d4c74: r1 = Function '<anonymous closure>':.
    //     0x6d4c74: add             x1, PP, #0x49, lsl #12  ; [pp+0x49a40] AnonymousClosure: (0x6d4d08), in [package:flutter/src/rendering/platform_view.dart] _PlatformViewGestureRecognizer::_PlatformViewGestureRecognizer (0x6d4afc)
    //     0x6d4c78: ldr             x1, [x1, #0xa40]
    // 0x6d4c7c: r0 = AllocateClosure()
    //     0x6d4c7c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6d4c80: r16 = <OneSequenceGestureRecognizer>
    //     0x6d4c80: add             x16, PP, #0x49, lsl #12  ; [pp+0x49930] TypeArguments: <OneSequenceGestureRecognizer>
    //     0x6d4c84: ldr             x16, [x16, #0x930]
    // 0x6d4c88: r30 = _ConstSet len:0
    //     0x6d4c88: add             lr, PP, #0x23, lsl #12  ; [pp+0x23a78] Set<Factory<OneSequenceGestureRecognizer>>(0)
    //     0x6d4c8c: ldr             lr, [lr, #0xa78]
    // 0x6d4c90: stp             lr, x16, [SP, #-0x10]!
    // 0x6d4c94: SaveReg r0
    //     0x6d4c94: str             x0, [SP, #-8]!
    // 0x6d4c98: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x6d4c98: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x6d4c9c: r0 = map()
    //     0x6d4c9c: bl              #0x78e0f8  ; [dart:collection] __Set&_HashVMBase&SetMixin::map
    // 0x6d4ca0: add             SP, SP, #0x18
    // 0x6d4ca4: SaveReg r0
    //     0x6d4ca4: str             x0, [SP, #-8]!
    // 0x6d4ca8: r0 = toSet()
    //     0x6d4ca8: bl              #0x6aa2c4  ; [dart:core] _GrowableList::toSet
    // 0x6d4cac: add             SP, SP, #8
    // 0x6d4cb0: ldr             x1, [fp, #0x18]
    // 0x6d4cb4: StoreField: r1->field_2f = r0
    //     0x6d4cb4: stur            w0, [x1, #0x2f]
    //     0x6d4cb8: ldurb           w16, [x1, #-1]
    //     0x6d4cbc: ldurb           w17, [x0, #-1]
    //     0x6d4cc0: and             x16, x17, x16, lsr #2
    //     0x6d4cc4: tst             x16, HEAP, lsr #32
    //     0x6d4cc8: b.eq            #0x6d4cd0
    //     0x6d4ccc: bl              #0xd6826c
    // 0x6d4cd0: ldr             x0, [fp, #0x10]
    // 0x6d4cd4: StoreField: r1->field_1f = r0
    //     0x6d4cd4: stur            w0, [x1, #0x1f]
    //     0x6d4cd8: ldurb           w16, [x1, #-1]
    //     0x6d4cdc: ldurb           w17, [x0, #-1]
    //     0x6d4ce0: and             x16, x17, x16, lsr #2
    //     0x6d4ce4: tst             x16, HEAP, lsr #32
    //     0x6d4ce8: b.eq            #0x6d4cf0
    //     0x6d4cec: bl              #0xd6826c
    // 0x6d4cf0: r0 = Null
    //     0x6d4cf0: mov             x0, NULL
    // 0x6d4cf4: LeaveFrame
    //     0x6d4cf4: mov             SP, fp
    //     0x6d4cf8: ldp             fp, lr, [SP], #0x10
    // 0x6d4cfc: ret
    //     0x6d4cfc: ret             
    // 0x6d4d00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d4d00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d4d04: b               #0x6d4b14
  }
  [closure] OneSequenceGestureRecognizer <anonymous closure>(dynamic, Factory<OneSequenceGestureRecognizer>) {
    // ** addr: 0x6d4d08, size: 0x1ec
    // 0x6d4d08: EnterFrame
    //     0x6d4d08: stp             fp, lr, [SP, #-0x10]!
    //     0x6d4d0c: mov             fp, SP
    // 0x6d4d10: AllocStack(0x10)
    //     0x6d4d10: sub             SP, SP, #0x10
    // 0x6d4d14: SetupParameters()
    //     0x6d4d14: ldr             x0, [fp, #0x18]
    //     0x6d4d18: ldur            w1, [x0, #0x17]
    //     0x6d4d1c: add             x1, x1, HEAP, lsl #32
    //     0x6d4d20: stur            x1, [fp, #-8]
    // 0x6d4d24: CheckStackOverflow
    //     0x6d4d24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d4d28: cmp             SP, x16
    //     0x6d4d2c: b.ls            #0x6d4ee8
    // 0x6d4d30: ldr             x16, [fp, #0x10]
    // 0x6d4d34: SaveReg r16
    //     0x6d4d34: str             x16, [SP, #-8]!
    // 0x6d4d38: r4 = 0
    //     0x6d4d38: mov             x4, #0
    // 0x6d4d3c: ldr             x0, [SP]
    // 0x6d4d40: r16 = UnlinkedCall_0x4aeefc
    //     0x6d4d40: add             x16, PP, #0x49, lsl #12  ; [pp+0x49a48] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x6d4d44: add             x16, x16, #0xa48
    // 0x6d4d48: ldp             x5, lr, [x16]
    // 0x6d4d4c: blr             lr
    // 0x6d4d50: add             SP, SP, #8
    // 0x6d4d54: cmp             w0, NULL
    // 0x6d4d58: b.eq            #0x6d4ef0
    // 0x6d4d5c: SaveReg r0
    //     0x6d4d5c: str             x0, [SP, #-8]!
    // 0x6d4d60: ClosureCall
    //     0x6d4d60: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x6d4d64: ldur            x2, [x0, #0x1f]
    //     0x6d4d68: blr             x2
    // 0x6d4d6c: add             SP, SP, #8
    // 0x6d4d70: mov             x3, x0
    // 0x6d4d74: ldur            x0, [fp, #-8]
    // 0x6d4d78: stur            x3, [fp, #-0x10]
    // 0x6d4d7c: LoadField: r1 = r0->field_f
    //     0x6d4d7c: ldur            w1, [x0, #0xf]
    // 0x6d4d80: DecompressPointer r1
    //     0x6d4d80: add             x1, x1, HEAP, lsl #32
    // 0x6d4d84: LoadField: r0 = r1->field_1b
    //     0x6d4d84: ldur            w0, [x1, #0x1b]
    // 0x6d4d88: DecompressPointer r0
    //     0x6d4d88: add             x0, x0, HEAP, lsl #32
    // 0x6d4d8c: StoreField: r3->field_1b = r0
    //     0x6d4d8c: stur            w0, [x3, #0x1b]
    //     0x6d4d90: ldurb           w16, [x3, #-1]
    //     0x6d4d94: ldurb           w17, [x0, #-1]
    //     0x6d4d98: and             x16, x17, x16, lsr #2
    //     0x6d4d9c: tst             x16, HEAP, lsr #32
    //     0x6d4da0: b.eq            #0x6d4da8
    //     0x6d4da4: bl              #0xd682ac
    // 0x6d4da8: r0 = LoadTaggedClassIdMayBeSmiInstr(r3)
    //     0x6d4da8: mov             x0, #0x76
    //     0x6d4dac: tbz             w3, #0, #0x6d4dbc
    //     0x6d4db0: ldur            x0, [x3, #-1]
    //     0x6d4db4: ubfx            x0, x0, #0xc, #0x14
    //     0x6d4db8: lsl             x0, x0, #1
    // 0x6d4dbc: r1 = LoadInt32Instr(r0)
    //     0x6d4dbc: sbfx            x1, x0, #1, #0x1f
    // 0x6d4dc0: cmp             x1, #0x939
    // 0x6d4dc4: b.lt            #0x6d4e18
    // 0x6d4dc8: cmp             x1, #0x93a
    // 0x6d4dcc: b.gt            #0x6d4e18
    // 0x6d4dd0: LoadField: r0 = r3->field_57
    //     0x6d4dd0: ldur            w0, [x3, #0x57]
    // 0x6d4dd4: DecompressPointer r0
    //     0x6d4dd4: add             x0, x0, HEAP, lsl #32
    // 0x6d4dd8: cmp             w0, NULL
    // 0x6d4ddc: b.ne            #0x6d4e10
    // 0x6d4de0: r1 = Function '<anonymous closure>':.
    //     0x6d4de0: add             x1, PP, #0x49, lsl #12  ; [pp+0x49a58] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x6d4de4: ldr             x1, [x1, #0xa58]
    // 0x6d4de8: r2 = Null
    //     0x6d4de8: mov             x2, NULL
    // 0x6d4dec: r0 = AllocateClosure()
    //     0x6d4dec: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6d4df0: ldur            x3, [fp, #-0x10]
    // 0x6d4df4: StoreField: r3->field_57 = r0
    //     0x6d4df4: stur            w0, [x3, #0x57]
    //     0x6d4df8: ldurb           w16, [x3, #-1]
    //     0x6d4dfc: ldurb           w17, [x0, #-1]
    //     0x6d4e00: and             x16, x17, x16, lsr #2
    //     0x6d4e04: tst             x16, HEAP, lsr #32
    //     0x6d4e08: b.eq            #0x6d4e10
    //     0x6d4e0c: bl              #0xd682ac
    // 0x6d4e10: mov             x1, x3
    // 0x6d4e14: b               #0x6d4ed8
    // 0x6d4e18: cmp             x1, #0x931
    // 0x6d4e1c: b.lt            #0x6d4e70
    // 0x6d4e20: cmp             x1, #0x933
    // 0x6d4e24: b.gt            #0x6d4e70
    // 0x6d4e28: LoadField: r0 = r3->field_23
    //     0x6d4e28: ldur            w0, [x3, #0x23]
    // 0x6d4e2c: DecompressPointer r0
    //     0x6d4e2c: add             x0, x0, HEAP, lsl #32
    // 0x6d4e30: cmp             w0, NULL
    // 0x6d4e34: b.ne            #0x6d4e68
    // 0x6d4e38: r1 = Function '<anonymous closure>':.
    //     0x6d4e38: add             x1, PP, #0x49, lsl #12  ; [pp+0x49a60] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x6d4e3c: ldr             x1, [x1, #0xa60]
    // 0x6d4e40: r2 = Null
    //     0x6d4e40: mov             x2, NULL
    // 0x6d4e44: r0 = AllocateClosure()
    //     0x6d4e44: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6d4e48: ldur            x3, [fp, #-0x10]
    // 0x6d4e4c: StoreField: r3->field_23 = r0
    //     0x6d4e4c: stur            w0, [x3, #0x23]
    //     0x6d4e50: ldurb           w16, [x3, #-1]
    //     0x6d4e54: ldurb           w17, [x0, #-1]
    //     0x6d4e58: and             x16, x17, x16, lsr #2
    //     0x6d4e5c: tst             x16, HEAP, lsr #32
    //     0x6d4e60: b.eq            #0x6d4e68
    //     0x6d4e64: bl              #0xd682ac
    // 0x6d4e68: mov             x1, x3
    // 0x6d4e6c: b               #0x6d4ed8
    // 0x6d4e70: cmp             x1, #0x937
    // 0x6d4e74: b.lt            #0x6d4ed4
    // 0x6d4e78: cmp             x1, #0x938
    // 0x6d4e7c: b.gt            #0x6d4ecc
    // 0x6d4e80: LoadField: r0 = r3->field_53
    //     0x6d4e80: ldur            w0, [x3, #0x53]
    // 0x6d4e84: DecompressPointer r0
    //     0x6d4e84: add             x0, x0, HEAP, lsl #32
    // 0x6d4e88: cmp             w0, NULL
    // 0x6d4e8c: b.ne            #0x6d4ec4
    // 0x6d4e90: r1 = Function '<anonymous closure>':.
    //     0x6d4e90: add             x1, PP, #0x49, lsl #12  ; [pp+0x49a68] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x6d4e94: ldr             x1, [x1, #0xa68]
    // 0x6d4e98: r2 = Null
    //     0x6d4e98: mov             x2, NULL
    // 0x6d4e9c: r0 = AllocateClosure()
    //     0x6d4e9c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6d4ea0: ldur            x1, [fp, #-0x10]
    // 0x6d4ea4: StoreField: r1->field_53 = r0
    //     0x6d4ea4: stur            w0, [x1, #0x53]
    //     0x6d4ea8: ldurb           w16, [x1, #-1]
    //     0x6d4eac: ldurb           w17, [x0, #-1]
    //     0x6d4eb0: and             x16, x17, x16, lsr #2
    //     0x6d4eb4: tst             x16, HEAP, lsr #32
    //     0x6d4eb8: b.eq            #0x6d4ec0
    //     0x6d4ebc: bl              #0xd6826c
    // 0x6d4ec0: b               #0x6d4ed8
    // 0x6d4ec4: mov             x1, x3
    // 0x6d4ec8: b               #0x6d4ed8
    // 0x6d4ecc: mov             x1, x3
    // 0x6d4ed0: b               #0x6d4ed8
    // 0x6d4ed4: mov             x1, x3
    // 0x6d4ed8: mov             x0, x1
    // 0x6d4edc: LeaveFrame
    //     0x6d4edc: mov             SP, fp
    //     0x6d4ee0: ldp             fp, lr, [SP], #0x10
    // 0x6d4ee4: ret
    //     0x6d4ee4: ret             
    // 0x6d4ee8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d4ee8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d4eec: b               #0x6d4d30
    // 0x6d4ef0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x6d4ef0: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ stopTrackingPointer(/* No info */) {
    // ** addr: 0x7135c8, size: 0x5c
    // 0x7135c8: EnterFrame
    //     0x7135c8: stp             fp, lr, [SP, #-0x10]!
    //     0x7135cc: mov             fp, SP
    // 0x7135d0: CheckStackOverflow
    //     0x7135d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7135d4: cmp             SP, x16
    //     0x7135d8: b.ls            #0x71361c
    // 0x7135dc: ldr             x16, [fp, #0x18]
    // 0x7135e0: ldr             lr, [fp, #0x10]
    // 0x7135e4: stp             lr, x16, [SP, #-0x10]!
    // 0x7135e8: r0 = stopTrackingPointer()
    //     0x7135e8: bl              #0x71334c  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingPointer
    // 0x7135ec: add             SP, SP, #0x10
    // 0x7135f0: ldr             x0, [fp, #0x18]
    // 0x7135f4: LoadField: r1 = r0->field_27
    //     0x7135f4: ldur            w1, [x0, #0x27]
    // 0x7135f8: DecompressPointer r1
    //     0x7135f8: add             x1, x1, HEAP, lsl #32
    // 0x7135fc: ldr             x16, [fp, #0x10]
    // 0x713600: stp             x16, x1, [SP, #-0x10]!
    // 0x713604: r0 = remove()
    //     0x713604: bl              #0xcbad38  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0x713608: add             SP, SP, #0x10
    // 0x71360c: r0 = Null
    //     0x71360c: mov             x0, NULL
    // 0x713610: LeaveFrame
    //     0x713610: mov             SP, fp
    //     0x713614: ldp             fp, lr, [SP], #0x10
    // 0x713618: ret
    //     0x713618: ret             
    // 0x71361c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71361c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x713620: b               #0x7135dc
  }
  _ addAllowedPointer(/* No info */) {
    // ** addr: 0x7832c4, size: 0x20c
    // 0x7832c4: EnterFrame
    //     0x7832c4: stp             fp, lr, [SP, #-0x10]!
    //     0x7832c8: mov             fp, SP
    // 0x7832cc: AllocStack(0x28)
    //     0x7832cc: sub             SP, SP, #0x28
    // 0x7832d0: CheckStackOverflow
    //     0x7832d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7832d4: cmp             SP, x16
    //     0x7832d8: b.ls            #0x7834b4
    // 0x7832dc: ldr             x16, [fp, #0x18]
    // 0x7832e0: ldr             lr, [fp, #0x10]
    // 0x7832e4: stp             lr, x16, [SP, #-0x10]!
    // 0x7832e8: r0 = addAllowedPointer()
    //     0x7832e8: bl              #0x782114  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::addAllowedPointer
    // 0x7832ec: add             SP, SP, #0x10
    // 0x7832f0: ldr             x0, [fp, #0x18]
    // 0x7832f4: LoadField: r1 = r0->field_2f
    //     0x7832f4: ldur            w1, [x0, #0x2f]
    // 0x7832f8: DecompressPointer r1
    //     0x7832f8: add             x1, x1, HEAP, lsl #32
    // 0x7832fc: r16 = Sentinel
    //     0x7832fc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x783300: cmp             w1, w16
    // 0x783304: b.eq            #0x7834bc
    // 0x783308: SaveReg r1
    //     0x783308: str             x1, [SP, #-8]!
    // 0x78330c: r0 = iterator()
    //     0x78330c: bl              #0x9bb174  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x783310: add             SP, SP, #8
    // 0x783314: stur            x0, [fp, #-0x10]
    // 0x783318: LoadField: r2 = r0->field_7
    //     0x783318: ldur            w2, [x0, #7]
    // 0x78331c: DecompressPointer r2
    //     0x78331c: add             x2, x2, HEAP, lsl #32
    // 0x783320: stur            x2, [fp, #-8]
    // 0x783324: ldr             x1, [fp, #0x10]
    // 0x783328: CheckStackOverflow
    //     0x783328: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78332c: cmp             SP, x16
    //     0x783330: b.ls            #0x7834c8
    // 0x783334: SaveReg r0
    //     0x783334: str             x0, [SP, #-8]!
    // 0x783338: r0 = moveNext()
    //     0x783338: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x78333c: add             SP, SP, #8
    // 0x783340: tbnz            w0, #4, #0x7834a4
    // 0x783344: ldur            x3, [fp, #-0x10]
    // 0x783348: LoadField: r4 = r3->field_33
    //     0x783348: ldur            w4, [x3, #0x33]
    // 0x78334c: DecompressPointer r4
    //     0x78334c: add             x4, x4, HEAP, lsl #32
    // 0x783350: stur            x4, [fp, #-0x18]
    // 0x783354: cmp             w4, NULL
    // 0x783358: b.ne            #0x78338c
    // 0x78335c: mov             x0, x4
    // 0x783360: ldur            x2, [fp, #-8]
    // 0x783364: r1 = Null
    //     0x783364: mov             x1, NULL
    // 0x783368: cmp             w2, NULL
    // 0x78336c: b.eq            #0x78338c
    // 0x783370: LoadField: r4 = r2->field_17
    //     0x783370: ldur            w4, [x2, #0x17]
    // 0x783374: DecompressPointer r4
    //     0x783374: add             x4, x4, HEAP, lsl #32
    // 0x783378: r8 = X0
    //     0x783378: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x78337c: LoadField: r9 = r4->field_7
    //     0x78337c: ldur            x9, [x4, #7]
    // 0x783380: r3 = Null
    //     0x783380: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fe28] Null
    //     0x783384: ldr             x3, [x3, #0xe28]
    // 0x783388: blr             x9
    // 0x78338c: ldr             x2, [fp, #0x10]
    // 0x783390: ldur            x1, [fp, #-0x18]
    // 0x783394: LoadField: r3 = r1->field_f
    //     0x783394: ldur            w3, [x1, #0xf]
    // 0x783398: DecompressPointer r3
    //     0x783398: add             x3, x3, HEAP, lsl #32
    // 0x78339c: stur            x3, [fp, #-0x20]
    // 0x7833a0: r0 = LoadClassIdInstr(r2)
    //     0x7833a0: ldur            x0, [x2, #-1]
    //     0x7833a4: ubfx            x0, x0, #0xc, #0x14
    // 0x7833a8: SaveReg r2
    //     0x7833a8: str             x2, [SP, #-8]!
    // 0x7833ac: r0 = GDT[cid_x0 + -0xfff]()
    //     0x7833ac: sub             lr, x0, #0xfff
    //     0x7833b0: ldr             lr, [x21, lr, lsl #3]
    //     0x7833b4: blr             lr
    // 0x7833b8: add             SP, SP, #8
    // 0x7833bc: mov             x2, x0
    // 0x7833c0: ldr             x1, [fp, #0x10]
    // 0x7833c4: stur            x2, [fp, #-0x28]
    // 0x7833c8: r0 = LoadClassIdInstr(r1)
    //     0x7833c8: ldur            x0, [x1, #-1]
    //     0x7833cc: ubfx            x0, x0, #0xc, #0x14
    // 0x7833d0: SaveReg r1
    //     0x7833d0: str             x1, [SP, #-8]!
    // 0x7833d4: r0 = GDT[cid_x0 + -0xf60]()
    //     0x7833d4: sub             lr, x0, #0xf60
    //     0x7833d8: ldr             lr, [x21, lr, lsl #3]
    //     0x7833dc: blr             lr
    // 0x7833e0: add             SP, SP, #8
    // 0x7833e4: mov             x3, x0
    // 0x7833e8: ldur            x2, [fp, #-0x28]
    // 0x7833ec: r0 = BoxInt64Instr(r2)
    //     0x7833ec: sbfiz           x0, x2, #1, #0x1f
    //     0x7833f0: cmp             x2, x0, asr #1
    //     0x7833f4: b.eq            #0x783400
    //     0x7833f8: bl              #0xd69bb8
    //     0x7833fc: stur            x2, [x0, #7]
    // 0x783400: ldur            x16, [fp, #-0x20]
    // 0x783404: stp             x0, x16, [SP, #-0x10]!
    // 0x783408: SaveReg r3
    //     0x783408: str             x3, [SP, #-8]!
    // 0x78340c: r0 = []=()
    //     0x78340c: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x783410: add             SP, SP, #0x18
    // 0x783414: ldur            x1, [fp, #-0x18]
    // 0x783418: r0 = LoadClassIdInstr(r1)
    //     0x783418: ldur            x0, [x1, #-1]
    //     0x78341c: ubfx            x0, x0, #0xc, #0x14
    // 0x783420: ldr             x16, [fp, #0x10]
    // 0x783424: stp             x16, x1, [SP, #-0x10]!
    // 0x783428: r0 = GDT[cid_x0 + 0x939e]()
    //     0x783428: mov             x17, #0x939e
    //     0x78342c: add             lr, x0, x17
    //     0x783430: ldr             lr, [x21, lr, lsl #3]
    //     0x783434: blr             lr
    // 0x783438: add             SP, SP, #0x10
    // 0x78343c: tbnz            w0, #4, #0x783470
    // 0x783440: ldur            x0, [fp, #-0x18]
    // 0x783444: r1 = LoadClassIdInstr(r0)
    //     0x783444: ldur            x1, [x0, #-1]
    //     0x783448: ubfx            x1, x1, #0xc, #0x14
    // 0x78344c: ldr             x16, [fp, #0x10]
    // 0x783450: stp             x16, x0, [SP, #-0x10]!
    // 0x783454: mov             x0, x1
    // 0x783458: r0 = GDT[cid_x0 + 0xc112]()
    //     0x783458: mov             x17, #0xc112
    //     0x78345c: add             lr, x0, x17
    //     0x783460: ldr             lr, [x21, lr, lsl #3]
    //     0x783464: blr             lr
    // 0x783468: add             SP, SP, #0x10
    // 0x78346c: b               #0x783498
    // 0x783470: ldur            x0, [fp, #-0x18]
    // 0x783474: r1 = LoadClassIdInstr(r0)
    //     0x783474: ldur            x1, [x0, #-1]
    //     0x783478: ubfx            x1, x1, #0xc, #0x14
    // 0x78347c: SaveReg r0
    //     0x78347c: str             x0, [SP, #-8]!
    // 0x783480: mov             x0, x1
    // 0x783484: r0 = GDT[cid_x0 + 0xc293]()
    //     0x783484: mov             x17, #0xc293
    //     0x783488: add             lr, x0, x17
    //     0x78348c: ldr             lr, [x21, lr, lsl #3]
    //     0x783490: blr             lr
    // 0x783494: add             SP, SP, #8
    // 0x783498: ldur            x0, [fp, #-0x10]
    // 0x78349c: ldur            x2, [fp, #-8]
    // 0x7834a0: b               #0x783324
    // 0x7834a4: r0 = Null
    //     0x7834a4: mov             x0, NULL
    // 0x7834a8: LeaveFrame
    //     0x7834a8: mov             SP, fp
    //     0x7834ac: ldp             fp, lr, [SP], #0x10
    // 0x7834b0: ret
    //     0x7834b0: ret             
    // 0x7834b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7834b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7834b8: b               #0x7832dc
    // 0x7834bc: r9 = _gestureRecognizers
    //     0x7834bc: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4fe38] Field <_PlatformViewGestureRecognizer@906508051._gestureRecognizers@906508051>: late (offset: 0x30)
    //     0x7834c0: ldr             x9, [x9, #0xe38]
    // 0x7834c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7834c4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7834c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7834c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7834cc: b               #0x783334
  }
  dynamic handleEvent(dynamic) {
    // ** addr: 0x78dd7c, size: 0x18
    // 0x78dd7c: r4 = 0
    //     0x78dd7c: mov             x4, #0
    // 0x78dd80: r1 = Function 'handleEvent':.
    //     0x78dd80: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fe18] AnonymousClosure: (0x78dd94), in [package:flutter/src/rendering/platform_view.dart] _PlatformViewGestureRecognizer::handleEvent (0x78dde0)
    //     0x78dd84: ldr             x1, [x17, #0xe18]
    // 0x78dd88: r24 = BuildNonGenericMethodExtractorStub
    //     0x78dd88: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x78dd8c: LoadField: r0 = r24->field_17
    //     0x78dd8c: ldur            x0, [x24, #0x17]
    // 0x78dd90: br              x0
  }
  [closure] void handleEvent(dynamic, PointerEvent) {
    // ** addr: 0x78dd94, size: 0x4c
    // 0x78dd94: EnterFrame
    //     0x78dd94: stp             fp, lr, [SP, #-0x10]!
    //     0x78dd98: mov             fp, SP
    // 0x78dd9c: ldr             x0, [fp, #0x18]
    // 0x78dda0: LoadField: r1 = r0->field_17
    //     0x78dda0: ldur            w1, [x0, #0x17]
    // 0x78dda4: DecompressPointer r1
    //     0x78dda4: add             x1, x1, HEAP, lsl #32
    // 0x78dda8: CheckStackOverflow
    //     0x78dda8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78ddac: cmp             SP, x16
    //     0x78ddb0: b.ls            #0x78ddd8
    // 0x78ddb4: LoadField: r0 = r1->field_f
    //     0x78ddb4: ldur            w0, [x1, #0xf]
    // 0x78ddb8: DecompressPointer r0
    //     0x78ddb8: add             x0, x0, HEAP, lsl #32
    // 0x78ddbc: ldr             x16, [fp, #0x10]
    // 0x78ddc0: stp             x16, x0, [SP, #-0x10]!
    // 0x78ddc4: r0 = handleEvent()
    //     0x78ddc4: bl              #0x78dde0  ; [package:flutter/src/rendering/platform_view.dart] _PlatformViewGestureRecognizer::handleEvent
    // 0x78ddc8: add             SP, SP, #0x10
    // 0x78ddcc: LeaveFrame
    //     0x78ddcc: mov             SP, fp
    //     0x78ddd0: ldp             fp, lr, [SP], #0x10
    // 0x78ddd4: ret
    //     0x78ddd4: ret             
    // 0x78ddd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78ddd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78dddc: b               #0x78ddb4
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0x78dde0, size: 0xf4
    // 0x78dde0: EnterFrame
    //     0x78dde0: stp             fp, lr, [SP, #-0x10]!
    //     0x78dde4: mov             fp, SP
    // 0x78dde8: AllocStack(0x8)
    //     0x78dde8: sub             SP, SP, #8
    // 0x78ddec: CheckStackOverflow
    //     0x78ddec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78ddf0: cmp             SP, x16
    //     0x78ddf4: b.ls            #0x78dec0
    // 0x78ddf8: ldr             x1, [fp, #0x18]
    // 0x78ddfc: LoadField: r2 = r1->field_27
    //     0x78ddfc: ldur            w2, [x1, #0x27]
    // 0x78de00: DecompressPointer r2
    //     0x78de00: add             x2, x2, HEAP, lsl #32
    // 0x78de04: ldr             x3, [fp, #0x10]
    // 0x78de08: stur            x2, [fp, #-8]
    // 0x78de0c: r0 = LoadClassIdInstr(r3)
    //     0x78de0c: ldur            x0, [x3, #-1]
    //     0x78de10: ubfx            x0, x0, #0xc, #0x14
    // 0x78de14: SaveReg r3
    //     0x78de14: str             x3, [SP, #-8]!
    // 0x78de18: r0 = GDT[cid_x0 + -0xfff]()
    //     0x78de18: sub             lr, x0, #0xfff
    //     0x78de1c: ldr             lr, [x21, lr, lsl #3]
    //     0x78de20: blr             lr
    // 0x78de24: add             SP, SP, #8
    // 0x78de28: mov             x2, x0
    // 0x78de2c: r0 = BoxInt64Instr(r2)
    //     0x78de2c: sbfiz           x0, x2, #1, #0x1f
    //     0x78de30: cmp             x2, x0, asr #1
    //     0x78de34: b.eq            #0x78de40
    //     0x78de38: bl              #0xd69bb8
    //     0x78de3c: stur            x2, [x0, #7]
    // 0x78de40: ldur            x16, [fp, #-8]
    // 0x78de44: stp             x0, x16, [SP, #-0x10]!
    // 0x78de48: r0 = contains()
    //     0x78de48: bl              #0x787194  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x78de4c: add             SP, SP, #0x10
    // 0x78de50: tbz             w0, #4, #0x78de6c
    // 0x78de54: ldr             x16, [fp, #0x18]
    // 0x78de58: ldr             lr, [fp, #0x10]
    // 0x78de5c: stp             lr, x16, [SP, #-0x10]!
    // 0x78de60: r0 = _cacheEvent()
    //     0x78de60: bl              #0x78ded4  ; [package:flutter/src/rendering/platform_view.dart] _PlatformViewGestureRecognizer::_cacheEvent
    // 0x78de64: add             SP, SP, #0x10
    // 0x78de68: b               #0x78de9c
    // 0x78de6c: ldr             x1, [fp, #0x18]
    // 0x78de70: LoadField: r0 = r1->field_1f
    //     0x78de70: ldur            w0, [x1, #0x1f]
    // 0x78de74: DecompressPointer r0
    //     0x78de74: add             x0, x0, HEAP, lsl #32
    // 0x78de78: r16 = Sentinel
    //     0x78de78: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x78de7c: cmp             w0, w16
    // 0x78de80: b.eq            #0x78dec8
    // 0x78de84: ldr             x16, [fp, #0x10]
    // 0x78de88: stp             x16, x0, [SP, #-0x10]!
    // 0x78de8c: ClosureCall
    //     0x78de8c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x78de90: ldur            x2, [x0, #0x1f]
    //     0x78de94: blr             x2
    // 0x78de98: add             SP, SP, #0x10
    // 0x78de9c: ldr             x16, [fp, #0x18]
    // 0x78dea0: ldr             lr, [fp, #0x10]
    // 0x78dea4: stp             lr, x16, [SP, #-0x10]!
    // 0x78dea8: r0 = stopTrackingIfPointerNoLongerDown()
    //     0x78dea8: bl              #0x7891a8  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingIfPointerNoLongerDown
    // 0x78deac: add             SP, SP, #0x10
    // 0x78deb0: r0 = Null
    //     0x78deb0: mov             x0, NULL
    // 0x78deb4: LeaveFrame
    //     0x78deb4: mov             SP, fp
    //     0x78deb8: ldp             fp, lr, [SP], #0x10
    // 0x78debc: ret
    //     0x78debc: ret             
    // 0x78dec0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78dec0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78dec4: b               #0x78ddf8
    // 0x78dec8: r9 = _handlePointerEvent
    //     0x78dec8: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4fe20] Field <_PlatformViewGestureRecognizer@906508051._handlePointerEvent@906508051>: late (offset: 0x20)
    //     0x78decc: ldr             x9, [x9, #0xe20]
    // 0x78ded0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x78ded0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _cacheEvent(/* No info */) {
    // ** addr: 0x78ded4, size: 0x198
    // 0x78ded4: EnterFrame
    //     0x78ded4: stp             fp, lr, [SP, #-0x10]!
    //     0x78ded8: mov             fp, SP
    // 0x78dedc: AllocStack(0x10)
    //     0x78dedc: sub             SP, SP, #0x10
    // 0x78dee0: CheckStackOverflow
    //     0x78dee0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78dee4: cmp             SP, x16
    //     0x78dee8: b.ls            #0x78e060
    // 0x78deec: ldr             x0, [fp, #0x18]
    // 0x78def0: LoadField: r1 = r0->field_23
    //     0x78def0: ldur            w1, [x0, #0x23]
    // 0x78def4: DecompressPointer r1
    //     0x78def4: add             x1, x1, HEAP, lsl #32
    // 0x78def8: ldr             x2, [fp, #0x10]
    // 0x78defc: stur            x1, [fp, #-8]
    // 0x78df00: r0 = LoadClassIdInstr(r2)
    //     0x78df00: ldur            x0, [x2, #-1]
    //     0x78df04: ubfx            x0, x0, #0xc, #0x14
    // 0x78df08: SaveReg r2
    //     0x78df08: str             x2, [SP, #-8]!
    // 0x78df0c: r0 = GDT[cid_x0 + -0xfff]()
    //     0x78df0c: sub             lr, x0, #0xfff
    //     0x78df10: ldr             lr, [x21, lr, lsl #3]
    //     0x78df14: blr             lr
    // 0x78df18: add             SP, SP, #8
    // 0x78df1c: mov             x2, x0
    // 0x78df20: r0 = BoxInt64Instr(r2)
    //     0x78df20: sbfiz           x0, x2, #1, #0x1f
    //     0x78df24: cmp             x2, x0, asr #1
    //     0x78df28: b.eq            #0x78df34
    //     0x78df2c: bl              #0xd69bb8
    //     0x78df30: stur            x2, [x0, #7]
    // 0x78df34: ldur            x16, [fp, #-8]
    // 0x78df38: stp             x0, x16, [SP, #-0x10]!
    // 0x78df3c: r0 = containsKey()
    //     0x78df3c: bl              #0xca679c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x78df40: add             SP, SP, #0x10
    // 0x78df44: tbz             w0, #4, #0x78dfac
    // 0x78df48: ldr             x1, [fp, #0x10]
    // 0x78df4c: r0 = LoadClassIdInstr(r1)
    //     0x78df4c: ldur            x0, [x1, #-1]
    //     0x78df50: ubfx            x0, x0, #0xc, #0x14
    // 0x78df54: SaveReg r1
    //     0x78df54: str             x1, [SP, #-8]!
    // 0x78df58: r0 = GDT[cid_x0 + -0xfff]()
    //     0x78df58: sub             lr, x0, #0xfff
    //     0x78df5c: ldr             lr, [x21, lr, lsl #3]
    //     0x78df60: blr             lr
    // 0x78df64: add             SP, SP, #8
    // 0x78df68: stur            x0, [fp, #-0x10]
    // 0x78df6c: r16 = <PointerEvent>
    //     0x78df6c: ldr             x16, [PP, #0x3928]  ; [pp+0x3928] TypeArguments: <PointerEvent>
    // 0x78df70: stp             xzr, x16, [SP, #-0x10]!
    // 0x78df74: r0 = _GrowableList()
    //     0x78df74: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x78df78: add             SP, SP, #0x10
    // 0x78df7c: mov             x3, x0
    // 0x78df80: ldur            x2, [fp, #-0x10]
    // 0x78df84: r0 = BoxInt64Instr(r2)
    //     0x78df84: sbfiz           x0, x2, #1, #0x1f
    //     0x78df88: cmp             x2, x0, asr #1
    //     0x78df8c: b.eq            #0x78df98
    //     0x78df90: bl              #0xd69bb8
    //     0x78df94: stur            x2, [x0, #7]
    // 0x78df98: ldur            x16, [fp, #-8]
    // 0x78df9c: stp             x0, x16, [SP, #-0x10]!
    // 0x78dfa0: SaveReg r3
    //     0x78dfa0: str             x3, [SP, #-8]!
    // 0x78dfa4: r0 = []=()
    //     0x78dfa4: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x78dfa8: add             SP, SP, #0x18
    // 0x78dfac: ldr             x1, [fp, #0x10]
    // 0x78dfb0: ldur            x2, [fp, #-8]
    // 0x78dfb4: r0 = LoadClassIdInstr(r1)
    //     0x78dfb4: ldur            x0, [x1, #-1]
    //     0x78dfb8: ubfx            x0, x0, #0xc, #0x14
    // 0x78dfbc: SaveReg r1
    //     0x78dfbc: str             x1, [SP, #-8]!
    // 0x78dfc0: r0 = GDT[cid_x0 + -0xfff]()
    //     0x78dfc0: sub             lr, x0, #0xfff
    //     0x78dfc4: ldr             lr, [x21, lr, lsl #3]
    //     0x78dfc8: blr             lr
    // 0x78dfcc: add             SP, SP, #8
    // 0x78dfd0: mov             x2, x0
    // 0x78dfd4: r0 = BoxInt64Instr(r2)
    //     0x78dfd4: sbfiz           x0, x2, #1, #0x1f
    //     0x78dfd8: cmp             x2, x0, asr #1
    //     0x78dfdc: b.eq            #0x78dfe8
    //     0x78dfe0: bl              #0xd69bb8
    //     0x78dfe4: stur            x2, [x0, #7]
    // 0x78dfe8: ldur            x16, [fp, #-8]
    // 0x78dfec: stp             x0, x16, [SP, #-0x10]!
    // 0x78dff0: r0 = _getValueOrData()
    //     0x78dff0: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x78dff4: add             SP, SP, #0x10
    // 0x78dff8: mov             x1, x0
    // 0x78dffc: ldur            x0, [fp, #-8]
    // 0x78e000: LoadField: r2 = r0->field_f
    //     0x78e000: ldur            w2, [x0, #0xf]
    // 0x78e004: DecompressPointer r2
    //     0x78e004: add             x2, x2, HEAP, lsl #32
    // 0x78e008: cmp             w2, w1
    // 0x78e00c: b.ne            #0x78e018
    // 0x78e010: r0 = Null
    //     0x78e010: mov             x0, NULL
    // 0x78e014: b               #0x78e01c
    // 0x78e018: mov             x0, x1
    // 0x78e01c: cmp             w0, NULL
    // 0x78e020: b.eq            #0x78e068
    // 0x78e024: r1 = LoadClassIdInstr(r0)
    //     0x78e024: ldur            x1, [x0, #-1]
    //     0x78e028: ubfx            x1, x1, #0xc, #0x14
    // 0x78e02c: ldr             x16, [fp, #0x10]
    // 0x78e030: stp             x16, x0, [SP, #-0x10]!
    // 0x78e034: mov             x0, x1
    // 0x78e038: r0 = GDT[cid_x0 + 0x101bb]()
    //     0x78e038: mov             x17, #0x1bb
    //     0x78e03c: movk            x17, #1, lsl #16
    //     0x78e040: add             lr, x0, x17
    //     0x78e044: ldr             lr, [x21, lr, lsl #3]
    //     0x78e048: blr             lr
    // 0x78e04c: add             SP, SP, #0x10
    // 0x78e050: r0 = Null
    //     0x78e050: mov             x0, NULL
    // 0x78e054: LeaveFrame
    //     0x78e054: mov             SP, fp
    //     0x78e058: ldp             fp, lr, [SP], #0x10
    // 0x78e05c: ret
    //     0x78e05c: ret             
    // 0x78e060: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78e060: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78e064: b               #0x78deec
    // 0x78e068: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x78e068: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ reset(/* No info */) {
    // ** addr: 0xa6a1cc, size: 0x100
    // 0xa6a1cc: EnterFrame
    //     0xa6a1cc: stp             fp, lr, [SP, #-0x10]!
    //     0xa6a1d0: mov             fp, SP
    // 0xa6a1d4: AllocStack(0x10)
    //     0xa6a1d4: sub             SP, SP, #0x10
    // 0xa6a1d8: CheckStackOverflow
    //     0xa6a1d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6a1dc: cmp             SP, x16
    //     0xa6a1e0: b.ls            #0xa6a2c4
    // 0xa6a1e4: ldr             x0, [fp, #0x10]
    // 0xa6a1e8: LoadField: r1 = r0->field_27
    //     0xa6a1e8: ldur            w1, [x0, #0x27]
    // 0xa6a1ec: DecompressPointer r1
    //     0xa6a1ec: add             x1, x1, HEAP, lsl #32
    // 0xa6a1f0: stur            x1, [fp, #-8]
    // 0xa6a1f4: r1 = 1
    //     0xa6a1f4: mov             x1, #1
    // 0xa6a1f8: r0 = AllocateContext()
    //     0xa6a1f8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa6a1fc: mov             x1, x0
    // 0xa6a200: ldr             x0, [fp, #0x10]
    // 0xa6a204: StoreField: r1->field_f = r0
    //     0xa6a204: stur            w0, [x1, #0xf]
    // 0xa6a208: mov             x2, x1
    // 0xa6a20c: r1 = Function 'stopTrackingPointer':.
    //     0xa6a20c: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4fdf0] AnonymousClosure: (0x713488), in [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingPointer (0x71334c)
    //     0xa6a210: ldr             x1, [x1, #0xdf0]
    // 0xa6a214: r0 = AllocateClosure()
    //     0xa6a214: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa6a218: ldur            x16, [fp, #-8]
    // 0xa6a21c: stp             x0, x16, [SP, #-0x10]!
    // 0xa6a220: r0 = forEach()
    //     0xa6a220: bl              #0x7020fc  ; [dart:collection] __Set&_HashVMBase&SetMixin::forEach
    // 0xa6a224: add             SP, SP, #0x10
    // 0xa6a228: ldur            x16, [fp, #-8]
    // 0xa6a22c: SaveReg r16
    //     0xa6a22c: str             x16, [SP, #-8]!
    // 0xa6a230: r0 = clear()
    //     0xa6a230: bl              #0x536e88  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::clear
    // 0xa6a234: add             SP, SP, #8
    // 0xa6a238: ldr             x0, [fp, #0x10]
    // 0xa6a23c: LoadField: r1 = r0->field_23
    //     0xa6a23c: ldur            w1, [x0, #0x23]
    // 0xa6a240: DecompressPointer r1
    //     0xa6a240: add             x1, x1, HEAP, lsl #32
    // 0xa6a244: stur            x1, [fp, #-8]
    // 0xa6a248: SaveReg r1
    //     0xa6a248: str             x1, [SP, #-8]!
    // 0xa6a24c: r0 = keys()
    //     0xa6a24c: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0xa6a250: add             SP, SP, #8
    // 0xa6a254: stur            x0, [fp, #-0x10]
    // 0xa6a258: r1 = 1
    //     0xa6a258: mov             x1, #1
    // 0xa6a25c: r0 = AllocateContext()
    //     0xa6a25c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa6a260: mov             x1, x0
    // 0xa6a264: ldr             x0, [fp, #0x10]
    // 0xa6a268: StoreField: r1->field_f = r0
    //     0xa6a268: stur            w0, [x1, #0xf]
    // 0xa6a26c: mov             x2, x1
    // 0xa6a270: r1 = Function 'stopTrackingPointer':.
    //     0xa6a270: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4fdf0] AnonymousClosure: (0x713488), in [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingPointer (0x71334c)
    //     0xa6a274: ldr             x1, [x1, #0xdf0]
    // 0xa6a278: r0 = AllocateClosure()
    //     0xa6a278: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa6a27c: ldur            x16, [fp, #-0x10]
    // 0xa6a280: stp             x0, x16, [SP, #-0x10]!
    // 0xa6a284: r0 = forEach()
    //     0xa6a284: bl              #0x6ab958  ; [dart:core] Iterable::forEach
    // 0xa6a288: add             SP, SP, #0x10
    // 0xa6a28c: ldur            x16, [fp, #-8]
    // 0xa6a290: SaveReg r16
    //     0xa6a290: str             x16, [SP, #-8]!
    // 0xa6a294: r0 = clear()
    //     0xa6a294: bl              #0x4e32e4  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0xa6a298: add             SP, SP, #8
    // 0xa6a29c: ldr             x16, [fp, #0x10]
    // 0xa6a2a0: r30 = Instance_GestureDisposition
    //     0xa6a2a0: add             lr, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0xa6a2a4: ldr             lr, [lr, #0xeb8]
    // 0xa6a2a8: stp             lr, x16, [SP, #-0x10]!
    // 0xa6a2ac: r0 = resolve()
    //     0xa6a2ac: bl              #0x715700  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xa6a2b0: add             SP, SP, #0x10
    // 0xa6a2b4: r0 = Null
    //     0xa6a2b4: mov             x0, NULL
    // 0xa6a2b8: LeaveFrame
    //     0xa6a2b8: mov             SP, fp
    //     0xa6a2bc: ldp             fp, lr, [SP], #0x10
    // 0xa6a2c0: ret
    //     0xa6a2c0: ret             
    // 0xa6a2c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6a2c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6a2c8: b               #0xa6a1e4
  }
  _ acceptGesture(/* No info */) {
    // ** addr: 0xbdc204, size: 0x74
    // 0xbdc204: EnterFrame
    //     0xbdc204: stp             fp, lr, [SP, #-0x10]!
    //     0xbdc208: mov             fp, SP
    // 0xbdc20c: CheckStackOverflow
    //     0xbdc20c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdc210: cmp             SP, x16
    //     0xbdc214: b.ls            #0xbdc270
    // 0xbdc218: ldr             x16, [fp, #0x18]
    // 0xbdc21c: SaveReg r16
    //     0xbdc21c: str             x16, [SP, #-8]!
    // 0xbdc220: ldr             x0, [fp, #0x10]
    // 0xbdc224: SaveReg r0
    //     0xbdc224: str             x0, [SP, #-8]!
    // 0xbdc228: r0 = _flushPointerCache()
    //     0xbdc228: bl              #0xbdc278  ; [package:flutter/src/rendering/platform_view.dart] _PlatformViewGestureRecognizer::_flushPointerCache
    // 0xbdc22c: add             SP, SP, #0x10
    // 0xbdc230: ldr             x0, [fp, #0x18]
    // 0xbdc234: LoadField: r2 = r0->field_27
    //     0xbdc234: ldur            w2, [x0, #0x27]
    // 0xbdc238: DecompressPointer r2
    //     0xbdc238: add             x2, x2, HEAP, lsl #32
    // 0xbdc23c: ldr             x3, [fp, #0x10]
    // 0xbdc240: r0 = BoxInt64Instr(r3)
    //     0xbdc240: sbfiz           x0, x3, #1, #0x1f
    //     0xbdc244: cmp             x3, x0, asr #1
    //     0xbdc248: b.eq            #0xbdc254
    //     0xbdc24c: bl              #0xd69bb8
    //     0xbdc250: stur            x3, [x0, #7]
    // 0xbdc254: stp             x0, x2, [SP, #-0x10]!
    // 0xbdc258: r0 = add()
    //     0xbdc258: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xbdc25c: add             SP, SP, #0x10
    // 0xbdc260: r0 = Null
    //     0xbdc260: mov             x0, NULL
    // 0xbdc264: LeaveFrame
    //     0xbdc264: mov             SP, fp
    //     0xbdc268: ldp             fp, lr, [SP], #0x10
    // 0xbdc26c: ret
    //     0xbdc26c: ret             
    // 0xbdc270: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdc270: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdc274: b               #0xbdc218
  }
  _ _flushPointerCache(/* No info */) {
    // ** addr: 0xbdc278, size: 0xac
    // 0xbdc278: EnterFrame
    //     0xbdc278: stp             fp, lr, [SP, #-0x10]!
    //     0xbdc27c: mov             fp, SP
    // 0xbdc280: CheckStackOverflow
    //     0xbdc280: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdc284: cmp             SP, x16
    //     0xbdc288: b.ls            #0xbdc310
    // 0xbdc28c: ldr             x2, [fp, #0x18]
    // 0xbdc290: LoadField: r3 = r2->field_23
    //     0xbdc290: ldur            w3, [x2, #0x23]
    // 0xbdc294: DecompressPointer r3
    //     0xbdc294: add             x3, x3, HEAP, lsl #32
    // 0xbdc298: ldr             x4, [fp, #0x10]
    // 0xbdc29c: r0 = BoxInt64Instr(r4)
    //     0xbdc29c: sbfiz           x0, x4, #1, #0x1f
    //     0xbdc2a0: cmp             x4, x0, asr #1
    //     0xbdc2a4: b.eq            #0xbdc2b0
    //     0xbdc2a8: bl              #0xd69bb8
    //     0xbdc2ac: stur            x4, [x0, #7]
    // 0xbdc2b0: stp             x0, x3, [SP, #-0x10]!
    // 0xbdc2b4: r0 = remove()
    //     0xbdc2b4: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xbdc2b8: add             SP, SP, #0x10
    // 0xbdc2bc: cmp             w0, NULL
    // 0xbdc2c0: b.eq            #0xbdc300
    // 0xbdc2c4: ldr             x1, [fp, #0x18]
    // 0xbdc2c8: LoadField: r2 = r1->field_1f
    //     0xbdc2c8: ldur            w2, [x1, #0x1f]
    // 0xbdc2cc: DecompressPointer r2
    //     0xbdc2cc: add             x2, x2, HEAP, lsl #32
    // 0xbdc2d0: r16 = Sentinel
    //     0xbdc2d0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbdc2d4: cmp             w2, w16
    // 0xbdc2d8: b.eq            #0xbdc318
    // 0xbdc2dc: r1 = LoadClassIdInstr(r0)
    //     0xbdc2dc: ldur            x1, [x0, #-1]
    //     0xbdc2e0: ubfx            x1, x1, #0xc, #0x14
    // 0xbdc2e4: stp             x2, x0, [SP, #-0x10]!
    // 0xbdc2e8: mov             x0, x1
    // 0xbdc2ec: r0 = GDT[cid_x0 + 0xce6e]()
    //     0xbdc2ec: mov             x17, #0xce6e
    //     0xbdc2f0: add             lr, x0, x17
    //     0xbdc2f4: ldr             lr, [x21, lr, lsl #3]
    //     0xbdc2f8: blr             lr
    // 0xbdc2fc: add             SP, SP, #0x10
    // 0xbdc300: r0 = Null
    //     0xbdc300: mov             x0, NULL
    // 0xbdc304: LeaveFrame
    //     0xbdc304: mov             SP, fp
    //     0xbdc308: ldp             fp, lr, [SP], #0x10
    // 0xbdc30c: ret
    //     0xbdc30c: ret             
    // 0xbdc310: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdc310: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdc314: b               #0xbdc28c
    // 0xbdc318: r9 = _handlePointerEvent
    //     0xbdc318: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4fe20] Field <_PlatformViewGestureRecognizer@906508051._handlePointerEvent@906508051>: late (offset: 0x20)
    //     0xbdc31c: ldr             x9, [x9, #0xe20]
    // 0xbdc320: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbdc320: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ rejectGesture(/* No info */) {
    // ** addr: 0xcee5bc, size: 0x78
    // 0xcee5bc: EnterFrame
    //     0xcee5bc: stp             fp, lr, [SP, #-0x10]!
    //     0xcee5c0: mov             fp, SP
    // 0xcee5c4: AllocStack(0x8)
    //     0xcee5c4: sub             SP, SP, #8
    // 0xcee5c8: CheckStackOverflow
    //     0xcee5c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcee5cc: cmp             SP, x16
    //     0xcee5d0: b.ls            #0xcee62c
    // 0xcee5d4: ldr             x2, [fp, #0x10]
    // 0xcee5d8: r0 = BoxInt64Instr(r2)
    //     0xcee5d8: sbfiz           x0, x2, #1, #0x1f
    //     0xcee5dc: cmp             x2, x0, asr #1
    //     0xcee5e0: b.eq            #0xcee5ec
    //     0xcee5e4: bl              #0xd69bb8
    //     0xcee5e8: stur            x2, [x0, #7]
    // 0xcee5ec: stur            x0, [fp, #-8]
    // 0xcee5f0: ldr             x16, [fp, #0x18]
    // 0xcee5f4: stp             x0, x16, [SP, #-0x10]!
    // 0xcee5f8: r0 = stopTrackingPointer()
    //     0xcee5f8: bl              #0x7135c8  ; [package:flutter/src/rendering/platform_view.dart] _PlatformViewGestureRecognizer::stopTrackingPointer
    // 0xcee5fc: add             SP, SP, #0x10
    // 0xcee600: ldr             x0, [fp, #0x18]
    // 0xcee604: LoadField: r1 = r0->field_23
    //     0xcee604: ldur            w1, [x0, #0x23]
    // 0xcee608: DecompressPointer r1
    //     0xcee608: add             x1, x1, HEAP, lsl #32
    // 0xcee60c: ldur            x16, [fp, #-8]
    // 0xcee610: stp             x16, x1, [SP, #-0x10]!
    // 0xcee614: r0 = remove()
    //     0xcee614: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xcee618: add             SP, SP, #0x10
    // 0xcee61c: r0 = Null
    //     0xcee61c: mov             x0, NULL
    // 0xcee620: LeaveFrame
    //     0xcee620: mov             SP, fp
    //     0xcee624: ldp             fp, lr, [SP], #0x10
    // 0xcee628: ret
    //     0xcee628: ret             
    // 0xcee62c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee62c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee630: b               #0xcee5d4
  }
}

// class id: 2350, size: 0x2c, field offset: 0x20
class _UiKitViewGestureRecognizer extends OneSequenceGestureRecognizer {

  late Set<OneSequenceGestureRecognizer> _gestureRecognizers; // offset: 0x24

  _ _UiKitViewGestureRecognizer(/* No info */) {
    // ** addr: 0x6d3d7c, size: 0x16c
    // 0x6d3d7c: EnterFrame
    //     0x6d3d7c: stp             fp, lr, [SP, #-0x10]!
    //     0x6d3d80: mov             fp, SP
    // 0x6d3d84: AllocStack(0x10)
    //     0x6d3d84: sub             SP, SP, #0x10
    // 0x6d3d88: CheckStackOverflow
    //     0x6d3d88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d3d8c: cmp             SP, x16
    //     0x6d3d90: b.ls            #0x6d3ee0
    // 0x6d3d94: r1 = 1
    //     0x6d3d94: mov             x1, #1
    // 0x6d3d98: r0 = AllocateContext()
    //     0x6d3d98: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6d3d9c: mov             x2, x0
    // 0x6d3da0: ldr             x1, [fp, #0x20]
    // 0x6d3da4: stur            x2, [fp, #-8]
    // 0x6d3da8: StoreField: r2->field_f = r1
    //     0x6d3da8: stur            w1, [x2, #0xf]
    // 0x6d3dac: r0 = Sentinel
    //     0x6d3dac: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6d3db0: StoreField: r1->field_23 = r0
    //     0x6d3db0: stur            w0, [x1, #0x23]
    // 0x6d3db4: ldr             x0, [fp, #0x18]
    // 0x6d3db8: StoreField: r1->field_27 = r0
    //     0x6d3db8: stur            w0, [x1, #0x27]
    //     0x6d3dbc: ldurb           w16, [x1, #-1]
    //     0x6d3dc0: ldurb           w17, [x0, #-1]
    //     0x6d3dc4: and             x16, x17, x16, lsr #2
    //     0x6d3dc8: tst             x16, HEAP, lsr #32
    //     0x6d3dcc: b.eq            #0x6d3dd4
    //     0x6d3dd0: bl              #0xd6826c
    // 0x6d3dd4: ldr             x0, [fp, #0x10]
    // 0x6d3dd8: StoreField: r1->field_1f = r0
    //     0x6d3dd8: stur            w0, [x1, #0x1f]
    //     0x6d3ddc: ldurb           w16, [x1, #-1]
    //     0x6d3de0: ldurb           w17, [x0, #-1]
    //     0x6d3de4: and             x16, x17, x16, lsr #2
    //     0x6d3de8: tst             x16, HEAP, lsr #32
    //     0x6d3dec: b.eq            #0x6d3df4
    //     0x6d3df0: bl              #0xd6826c
    // 0x6d3df4: SaveReg r1
    //     0x6d3df4: str             x1, [SP, #-8]!
    // 0x6d3df8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6d3df8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6d3dfc: r0 = OneSequenceGestureRecognizer()
    //     0x6d3dfc: bl              #0x6d3ef4  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::OneSequenceGestureRecognizer
    // 0x6d3e00: add             SP, SP, #8
    // 0x6d3e04: r16 = <int, _CombiningGestureArenaMember>
    //     0x6d3e04: add             x16, PP, #0x49, lsl #12  ; [pp+0x49938] TypeArguments: <int, _CombiningGestureArenaMember>
    //     0x6d3e08: ldr             x16, [x16, #0x938]
    // 0x6d3e0c: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x6d3e10: stp             lr, x16, [SP, #-0x10]!
    // 0x6d3e14: r0 = Map._fromLiteral()
    //     0x6d3e14: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x6d3e18: add             SP, SP, #0x10
    // 0x6d3e1c: stur            x0, [fp, #-0x10]
    // 0x6d3e20: r0 = GestureArenaTeam()
    //     0x6d3e20: bl              #0x6d3ee8  ; AllocateGestureArenaTeamStub -> GestureArenaTeam (size=0x10)
    // 0x6d3e24: mov             x1, x0
    // 0x6d3e28: ldur            x0, [fp, #-0x10]
    // 0x6d3e2c: StoreField: r1->field_7 = r0
    //     0x6d3e2c: stur            w0, [x1, #7]
    // 0x6d3e30: ldr             x3, [fp, #0x20]
    // 0x6d3e34: StoreField: r1->field_b = r3
    //     0x6d3e34: stur            w3, [x1, #0xb]
    // 0x6d3e38: mov             x0, x1
    // 0x6d3e3c: StoreField: r3->field_1b = r0
    //     0x6d3e3c: stur            w0, [x3, #0x1b]
    //     0x6d3e40: ldurb           w16, [x3, #-1]
    //     0x6d3e44: ldurb           w17, [x0, #-1]
    //     0x6d3e48: and             x16, x17, x16, lsr #2
    //     0x6d3e4c: tst             x16, HEAP, lsr #32
    //     0x6d3e50: b.eq            #0x6d3e58
    //     0x6d3e54: bl              #0xd682ac
    // 0x6d3e58: ldur            x2, [fp, #-8]
    // 0x6d3e5c: r1 = Function '<anonymous closure>':.
    //     0x6d3e5c: add             x1, PP, #0x49, lsl #12  ; [pp+0x49940] AnonymousClosure: (0x6d41b0), in [package:flutter/src/rendering/platform_view.dart] _UiKitViewGestureRecognizer::_UiKitViewGestureRecognizer (0x6d3d7c)
    //     0x6d3e60: ldr             x1, [x1, #0x940]
    // 0x6d3e64: r0 = AllocateClosure()
    //     0x6d3e64: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6d3e68: mov             x1, x0
    // 0x6d3e6c: ldr             x0, [fp, #0x10]
    // 0x6d3e70: r2 = LoadClassIdInstr(r0)
    //     0x6d3e70: ldur            x2, [x0, #-1]
    //     0x6d3e74: ubfx            x2, x2, #0xc, #0x14
    // 0x6d3e78: r16 = <OneSequenceGestureRecognizer>
    //     0x6d3e78: add             x16, PP, #0x49, lsl #12  ; [pp+0x49930] TypeArguments: <OneSequenceGestureRecognizer>
    //     0x6d3e7c: ldr             x16, [x16, #0x930]
    // 0x6d3e80: stp             x0, x16, [SP, #-0x10]!
    // 0x6d3e84: SaveReg r1
    //     0x6d3e84: str             x1, [SP, #-8]!
    // 0x6d3e88: mov             x0, x2
    // 0x6d3e8c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x6d3e8c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x6d3e90: r0 = GDT[cid_x0 + 0xc934]()
    //     0x6d3e90: mov             x17, #0xc934
    //     0x6d3e94: add             lr, x0, x17
    //     0x6d3e98: ldr             lr, [x21, lr, lsl #3]
    //     0x6d3e9c: blr             lr
    // 0x6d3ea0: add             SP, SP, #0x18
    // 0x6d3ea4: SaveReg r0
    //     0x6d3ea4: str             x0, [SP, #-8]!
    // 0x6d3ea8: r0 = toSet()
    //     0x6d3ea8: bl              #0x6aa2c4  ; [dart:core] _GrowableList::toSet
    // 0x6d3eac: add             SP, SP, #8
    // 0x6d3eb0: ldr             x1, [fp, #0x20]
    // 0x6d3eb4: StoreField: r1->field_23 = r0
    //     0x6d3eb4: stur            w0, [x1, #0x23]
    //     0x6d3eb8: ldurb           w16, [x1, #-1]
    //     0x6d3ebc: ldurb           w17, [x0, #-1]
    //     0x6d3ec0: and             x16, x17, x16, lsr #2
    //     0x6d3ec4: tst             x16, HEAP, lsr #32
    //     0x6d3ec8: b.eq            #0x6d3ed0
    //     0x6d3ecc: bl              #0xd6826c
    // 0x6d3ed0: r0 = Null
    //     0x6d3ed0: mov             x0, NULL
    // 0x6d3ed4: LeaveFrame
    //     0x6d3ed4: mov             SP, fp
    //     0x6d3ed8: ldp             fp, lr, [SP], #0x10
    // 0x6d3edc: ret
    //     0x6d3edc: ret             
    // 0x6d3ee0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d3ee0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d3ee4: b               #0x6d3d94
  }
  [closure] OneSequenceGestureRecognizer <anonymous closure>(dynamic, Factory<OneSequenceGestureRecognizer>) {
    // ** addr: 0x6d41b0, size: 0x1ec
    // 0x6d41b0: EnterFrame
    //     0x6d41b0: stp             fp, lr, [SP, #-0x10]!
    //     0x6d41b4: mov             fp, SP
    // 0x6d41b8: AllocStack(0x10)
    //     0x6d41b8: sub             SP, SP, #0x10
    // 0x6d41bc: SetupParameters()
    //     0x6d41bc: ldr             x0, [fp, #0x18]
    //     0x6d41c0: ldur            w1, [x0, #0x17]
    //     0x6d41c4: add             x1, x1, HEAP, lsl #32
    //     0x6d41c8: stur            x1, [fp, #-8]
    // 0x6d41cc: CheckStackOverflow
    //     0x6d41cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d41d0: cmp             SP, x16
    //     0x6d41d4: b.ls            #0x6d4390
    // 0x6d41d8: ldr             x16, [fp, #0x10]
    // 0x6d41dc: SaveReg r16
    //     0x6d41dc: str             x16, [SP, #-8]!
    // 0x6d41e0: r4 = 0
    //     0x6d41e0: mov             x4, #0
    // 0x6d41e4: ldr             x0, [SP]
    // 0x6d41e8: r16 = UnlinkedCall_0x4aeefc
    //     0x6d41e8: add             x16, PP, #0x49, lsl #12  ; [pp+0x49948] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x6d41ec: add             x16, x16, #0x948
    // 0x6d41f0: ldp             x5, lr, [x16]
    // 0x6d41f4: blr             lr
    // 0x6d41f8: add             SP, SP, #8
    // 0x6d41fc: cmp             w0, NULL
    // 0x6d4200: b.eq            #0x6d4398
    // 0x6d4204: SaveReg r0
    //     0x6d4204: str             x0, [SP, #-8]!
    // 0x6d4208: ClosureCall
    //     0x6d4208: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x6d420c: ldur            x2, [x0, #0x1f]
    //     0x6d4210: blr             x2
    // 0x6d4214: add             SP, SP, #8
    // 0x6d4218: mov             x3, x0
    // 0x6d421c: ldur            x0, [fp, #-8]
    // 0x6d4220: stur            x3, [fp, #-0x10]
    // 0x6d4224: LoadField: r1 = r0->field_f
    //     0x6d4224: ldur            w1, [x0, #0xf]
    // 0x6d4228: DecompressPointer r1
    //     0x6d4228: add             x1, x1, HEAP, lsl #32
    // 0x6d422c: LoadField: r0 = r1->field_1b
    //     0x6d422c: ldur            w0, [x1, #0x1b]
    // 0x6d4230: DecompressPointer r0
    //     0x6d4230: add             x0, x0, HEAP, lsl #32
    // 0x6d4234: StoreField: r3->field_1b = r0
    //     0x6d4234: stur            w0, [x3, #0x1b]
    //     0x6d4238: ldurb           w16, [x3, #-1]
    //     0x6d423c: ldurb           w17, [x0, #-1]
    //     0x6d4240: and             x16, x17, x16, lsr #2
    //     0x6d4244: tst             x16, HEAP, lsr #32
    //     0x6d4248: b.eq            #0x6d4250
    //     0x6d424c: bl              #0xd682ac
    // 0x6d4250: r0 = LoadTaggedClassIdMayBeSmiInstr(r3)
    //     0x6d4250: mov             x0, #0x76
    //     0x6d4254: tbz             w3, #0, #0x6d4264
    //     0x6d4258: ldur            x0, [x3, #-1]
    //     0x6d425c: ubfx            x0, x0, #0xc, #0x14
    //     0x6d4260: lsl             x0, x0, #1
    // 0x6d4264: r1 = LoadInt32Instr(r0)
    //     0x6d4264: sbfx            x1, x0, #1, #0x1f
    // 0x6d4268: cmp             x1, #0x939
    // 0x6d426c: b.lt            #0x6d42c0
    // 0x6d4270: cmp             x1, #0x93a
    // 0x6d4274: b.gt            #0x6d42c0
    // 0x6d4278: LoadField: r0 = r3->field_57
    //     0x6d4278: ldur            w0, [x3, #0x57]
    // 0x6d427c: DecompressPointer r0
    //     0x6d427c: add             x0, x0, HEAP, lsl #32
    // 0x6d4280: cmp             w0, NULL
    // 0x6d4284: b.ne            #0x6d42b8
    // 0x6d4288: r1 = Function '<anonymous closure>':.
    //     0x6d4288: add             x1, PP, #0x49, lsl #12  ; [pp+0x49958] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x6d428c: ldr             x1, [x1, #0x958]
    // 0x6d4290: r2 = Null
    //     0x6d4290: mov             x2, NULL
    // 0x6d4294: r0 = AllocateClosure()
    //     0x6d4294: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6d4298: ldur            x3, [fp, #-0x10]
    // 0x6d429c: StoreField: r3->field_57 = r0
    //     0x6d429c: stur            w0, [x3, #0x57]
    //     0x6d42a0: ldurb           w16, [x3, #-1]
    //     0x6d42a4: ldurb           w17, [x0, #-1]
    //     0x6d42a8: and             x16, x17, x16, lsr #2
    //     0x6d42ac: tst             x16, HEAP, lsr #32
    //     0x6d42b0: b.eq            #0x6d42b8
    //     0x6d42b4: bl              #0xd682ac
    // 0x6d42b8: mov             x1, x3
    // 0x6d42bc: b               #0x6d4380
    // 0x6d42c0: cmp             x1, #0x931
    // 0x6d42c4: b.lt            #0x6d4318
    // 0x6d42c8: cmp             x1, #0x933
    // 0x6d42cc: b.gt            #0x6d4318
    // 0x6d42d0: LoadField: r0 = r3->field_23
    //     0x6d42d0: ldur            w0, [x3, #0x23]
    // 0x6d42d4: DecompressPointer r0
    //     0x6d42d4: add             x0, x0, HEAP, lsl #32
    // 0x6d42d8: cmp             w0, NULL
    // 0x6d42dc: b.ne            #0x6d4310
    // 0x6d42e0: r1 = Function '<anonymous closure>':.
    //     0x6d42e0: add             x1, PP, #0x49, lsl #12  ; [pp+0x49960] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x6d42e4: ldr             x1, [x1, #0x960]
    // 0x6d42e8: r2 = Null
    //     0x6d42e8: mov             x2, NULL
    // 0x6d42ec: r0 = AllocateClosure()
    //     0x6d42ec: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6d42f0: ldur            x3, [fp, #-0x10]
    // 0x6d42f4: StoreField: r3->field_23 = r0
    //     0x6d42f4: stur            w0, [x3, #0x23]
    //     0x6d42f8: ldurb           w16, [x3, #-1]
    //     0x6d42fc: ldurb           w17, [x0, #-1]
    //     0x6d4300: and             x16, x17, x16, lsr #2
    //     0x6d4304: tst             x16, HEAP, lsr #32
    //     0x6d4308: b.eq            #0x6d4310
    //     0x6d430c: bl              #0xd682ac
    // 0x6d4310: mov             x1, x3
    // 0x6d4314: b               #0x6d4380
    // 0x6d4318: cmp             x1, #0x937
    // 0x6d431c: b.lt            #0x6d437c
    // 0x6d4320: cmp             x1, #0x938
    // 0x6d4324: b.gt            #0x6d4374
    // 0x6d4328: LoadField: r0 = r3->field_53
    //     0x6d4328: ldur            w0, [x3, #0x53]
    // 0x6d432c: DecompressPointer r0
    //     0x6d432c: add             x0, x0, HEAP, lsl #32
    // 0x6d4330: cmp             w0, NULL
    // 0x6d4334: b.ne            #0x6d436c
    // 0x6d4338: r1 = Function '<anonymous closure>':.
    //     0x6d4338: add             x1, PP, #0x49, lsl #12  ; [pp+0x49968] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x6d433c: ldr             x1, [x1, #0x968]
    // 0x6d4340: r2 = Null
    //     0x6d4340: mov             x2, NULL
    // 0x6d4344: r0 = AllocateClosure()
    //     0x6d4344: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6d4348: ldur            x1, [fp, #-0x10]
    // 0x6d434c: StoreField: r1->field_53 = r0
    //     0x6d434c: stur            w0, [x1, #0x53]
    //     0x6d4350: ldurb           w16, [x1, #-1]
    //     0x6d4354: ldurb           w17, [x0, #-1]
    //     0x6d4358: and             x16, x17, x16, lsr #2
    //     0x6d435c: tst             x16, HEAP, lsr #32
    //     0x6d4360: b.eq            #0x6d4368
    //     0x6d4364: bl              #0xd6826c
    // 0x6d4368: b               #0x6d4380
    // 0x6d436c: mov             x1, x3
    // 0x6d4370: b               #0x6d4380
    // 0x6d4374: mov             x1, x3
    // 0x6d4378: b               #0x6d4380
    // 0x6d437c: mov             x1, x3
    // 0x6d4380: mov             x0, x1
    // 0x6d4384: LeaveFrame
    //     0x6d4384: mov             SP, fp
    //     0x6d4388: ldp             fp, lr, [SP], #0x10
    // 0x6d438c: ret
    //     0x6d438c: ret             
    // 0x6d4390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d4390: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d4394: b               #0x6d41d8
    // 0x6d4398: r0 = NullErrorSharedWithoutFPURegs()
    //     0x6d4398: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ addAllowedPointer(/* No info */) {
    // ** addr: 0x7830b8, size: 0x20c
    // 0x7830b8: EnterFrame
    //     0x7830b8: stp             fp, lr, [SP, #-0x10]!
    //     0x7830bc: mov             fp, SP
    // 0x7830c0: AllocStack(0x28)
    //     0x7830c0: sub             SP, SP, #0x28
    // 0x7830c4: CheckStackOverflow
    //     0x7830c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7830c8: cmp             SP, x16
    //     0x7830cc: b.ls            #0x7832a8
    // 0x7830d0: ldr             x16, [fp, #0x18]
    // 0x7830d4: ldr             lr, [fp, #0x10]
    // 0x7830d8: stp             lr, x16, [SP, #-0x10]!
    // 0x7830dc: r0 = addAllowedPointer()
    //     0x7830dc: bl              #0x782114  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::addAllowedPointer
    // 0x7830e0: add             SP, SP, #0x10
    // 0x7830e4: ldr             x0, [fp, #0x18]
    // 0x7830e8: LoadField: r1 = r0->field_23
    //     0x7830e8: ldur            w1, [x0, #0x23]
    // 0x7830ec: DecompressPointer r1
    //     0x7830ec: add             x1, x1, HEAP, lsl #32
    // 0x7830f0: r16 = Sentinel
    //     0x7830f0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7830f4: cmp             w1, w16
    // 0x7830f8: b.eq            #0x7832b0
    // 0x7830fc: SaveReg r1
    //     0x7830fc: str             x1, [SP, #-8]!
    // 0x783100: r0 = iterator()
    //     0x783100: bl              #0x9bb174  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x783104: add             SP, SP, #8
    // 0x783108: stur            x0, [fp, #-0x10]
    // 0x78310c: LoadField: r2 = r0->field_7
    //     0x78310c: ldur            w2, [x0, #7]
    // 0x783110: DecompressPointer r2
    //     0x783110: add             x2, x2, HEAP, lsl #32
    // 0x783114: stur            x2, [fp, #-8]
    // 0x783118: ldr             x1, [fp, #0x10]
    // 0x78311c: CheckStackOverflow
    //     0x78311c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x783120: cmp             SP, x16
    //     0x783124: b.ls            #0x7832bc
    // 0x783128: SaveReg r0
    //     0x783128: str             x0, [SP, #-8]!
    // 0x78312c: r0 = moveNext()
    //     0x78312c: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x783130: add             SP, SP, #8
    // 0x783134: tbnz            w0, #4, #0x783298
    // 0x783138: ldur            x3, [fp, #-0x10]
    // 0x78313c: LoadField: r4 = r3->field_33
    //     0x78313c: ldur            w4, [x3, #0x33]
    // 0x783140: DecompressPointer r4
    //     0x783140: add             x4, x4, HEAP, lsl #32
    // 0x783144: stur            x4, [fp, #-0x18]
    // 0x783148: cmp             w4, NULL
    // 0x78314c: b.ne            #0x783180
    // 0x783150: mov             x0, x4
    // 0x783154: ldur            x2, [fp, #-8]
    // 0x783158: r1 = Null
    //     0x783158: mov             x1, NULL
    // 0x78315c: cmp             w2, NULL
    // 0x783160: b.eq            #0x783180
    // 0x783164: LoadField: r4 = r2->field_17
    //     0x783164: ldur            w4, [x2, #0x17]
    // 0x783168: DecompressPointer r4
    //     0x783168: add             x4, x4, HEAP, lsl #32
    // 0x78316c: r8 = X0
    //     0x78316c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x783170: LoadField: r9 = r4->field_7
    //     0x783170: ldur            x9, [x4, #7]
    // 0x783174: r3 = Null
    //     0x783174: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fe80] Null
    //     0x783178: ldr             x3, [x3, #0xe80]
    // 0x78317c: blr             x9
    // 0x783180: ldr             x2, [fp, #0x10]
    // 0x783184: ldur            x1, [fp, #-0x18]
    // 0x783188: LoadField: r3 = r1->field_f
    //     0x783188: ldur            w3, [x1, #0xf]
    // 0x78318c: DecompressPointer r3
    //     0x78318c: add             x3, x3, HEAP, lsl #32
    // 0x783190: stur            x3, [fp, #-0x20]
    // 0x783194: r0 = LoadClassIdInstr(r2)
    //     0x783194: ldur            x0, [x2, #-1]
    //     0x783198: ubfx            x0, x0, #0xc, #0x14
    // 0x78319c: SaveReg r2
    //     0x78319c: str             x2, [SP, #-8]!
    // 0x7831a0: r0 = GDT[cid_x0 + -0xfff]()
    //     0x7831a0: sub             lr, x0, #0xfff
    //     0x7831a4: ldr             lr, [x21, lr, lsl #3]
    //     0x7831a8: blr             lr
    // 0x7831ac: add             SP, SP, #8
    // 0x7831b0: mov             x2, x0
    // 0x7831b4: ldr             x1, [fp, #0x10]
    // 0x7831b8: stur            x2, [fp, #-0x28]
    // 0x7831bc: r0 = LoadClassIdInstr(r1)
    //     0x7831bc: ldur            x0, [x1, #-1]
    //     0x7831c0: ubfx            x0, x0, #0xc, #0x14
    // 0x7831c4: SaveReg r1
    //     0x7831c4: str             x1, [SP, #-8]!
    // 0x7831c8: r0 = GDT[cid_x0 + -0xf60]()
    //     0x7831c8: sub             lr, x0, #0xf60
    //     0x7831cc: ldr             lr, [x21, lr, lsl #3]
    //     0x7831d0: blr             lr
    // 0x7831d4: add             SP, SP, #8
    // 0x7831d8: mov             x3, x0
    // 0x7831dc: ldur            x2, [fp, #-0x28]
    // 0x7831e0: r0 = BoxInt64Instr(r2)
    //     0x7831e0: sbfiz           x0, x2, #1, #0x1f
    //     0x7831e4: cmp             x2, x0, asr #1
    //     0x7831e8: b.eq            #0x7831f4
    //     0x7831ec: bl              #0xd69bb8
    //     0x7831f0: stur            x2, [x0, #7]
    // 0x7831f4: ldur            x16, [fp, #-0x20]
    // 0x7831f8: stp             x0, x16, [SP, #-0x10]!
    // 0x7831fc: SaveReg r3
    //     0x7831fc: str             x3, [SP, #-8]!
    // 0x783200: r0 = []=()
    //     0x783200: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x783204: add             SP, SP, #0x18
    // 0x783208: ldur            x1, [fp, #-0x18]
    // 0x78320c: r0 = LoadClassIdInstr(r1)
    //     0x78320c: ldur            x0, [x1, #-1]
    //     0x783210: ubfx            x0, x0, #0xc, #0x14
    // 0x783214: ldr             x16, [fp, #0x10]
    // 0x783218: stp             x16, x1, [SP, #-0x10]!
    // 0x78321c: r0 = GDT[cid_x0 + 0x939e]()
    //     0x78321c: mov             x17, #0x939e
    //     0x783220: add             lr, x0, x17
    //     0x783224: ldr             lr, [x21, lr, lsl #3]
    //     0x783228: blr             lr
    // 0x78322c: add             SP, SP, #0x10
    // 0x783230: tbnz            w0, #4, #0x783264
    // 0x783234: ldur            x0, [fp, #-0x18]
    // 0x783238: r1 = LoadClassIdInstr(r0)
    //     0x783238: ldur            x1, [x0, #-1]
    //     0x78323c: ubfx            x1, x1, #0xc, #0x14
    // 0x783240: ldr             x16, [fp, #0x10]
    // 0x783244: stp             x16, x0, [SP, #-0x10]!
    // 0x783248: mov             x0, x1
    // 0x78324c: r0 = GDT[cid_x0 + 0xc112]()
    //     0x78324c: mov             x17, #0xc112
    //     0x783250: add             lr, x0, x17
    //     0x783254: ldr             lr, [x21, lr, lsl #3]
    //     0x783258: blr             lr
    // 0x78325c: add             SP, SP, #0x10
    // 0x783260: b               #0x78328c
    // 0x783264: ldur            x0, [fp, #-0x18]
    // 0x783268: r1 = LoadClassIdInstr(r0)
    //     0x783268: ldur            x1, [x0, #-1]
    //     0x78326c: ubfx            x1, x1, #0xc, #0x14
    // 0x783270: SaveReg r0
    //     0x783270: str             x0, [SP, #-8]!
    // 0x783274: mov             x0, x1
    // 0x783278: r0 = GDT[cid_x0 + 0xc293]()
    //     0x783278: mov             x17, #0xc293
    //     0x78327c: add             lr, x0, x17
    //     0x783280: ldr             lr, [x21, lr, lsl #3]
    //     0x783284: blr             lr
    // 0x783288: add             SP, SP, #8
    // 0x78328c: ldur            x0, [fp, #-0x10]
    // 0x783290: ldur            x2, [fp, #-8]
    // 0x783294: b               #0x783118
    // 0x783298: r0 = Null
    //     0x783298: mov             x0, NULL
    // 0x78329c: LeaveFrame
    //     0x78329c: mov             SP, fp
    //     0x7832a0: ldp             fp, lr, [SP], #0x10
    // 0x7832a4: ret
    //     0x7832a4: ret             
    // 0x7832a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7832a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7832ac: b               #0x7830d0
    // 0x7832b0: r9 = _gestureRecognizers
    //     0x7832b0: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4fe90] Field <_UiKitViewGestureRecognizer@906508051._gestureRecognizers@906508051>: late (offset: 0x24)
    //     0x7832b4: ldr             x9, [x9, #0xe90]
    // 0x7832b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7832b8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7832bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7832bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7832c0: b               #0x783128
  }
  dynamic handleEvent(dynamic) {
    // ** addr: 0x78dd14, size: 0x18
    // 0x78dd14: r4 = 0
    //     0x78dd14: mov             x4, #0
    // 0x78dd18: r1 = Function 'handleEvent':.
    //     0x78dd18: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fe70] AnonymousClosure: (0x78dd2c), of [package:flutter/src/rendering/platform_view.dart] _UiKitViewGestureRecognizer
    //     0x78dd1c: ldr             x1, [x17, #0xe70]
    // 0x78dd20: r24 = BuildNonGenericMethodExtractorStub
    //     0x78dd20: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x78dd24: LoadField: r0 = r24->field_17
    //     0x78dd24: ldur            x0, [x24, #0x17]
    // 0x78dd28: br              x0
  }
  [closure] void handleEvent(dynamic, PointerEvent) {
    // ** addr: 0x78dd2c, size: 0x50
    // 0x78dd2c: EnterFrame
    //     0x78dd2c: stp             fp, lr, [SP, #-0x10]!
    //     0x78dd30: mov             fp, SP
    // 0x78dd34: ldr             x0, [fp, #0x18]
    // 0x78dd38: LoadField: r1 = r0->field_17
    //     0x78dd38: ldur            w1, [x0, #0x17]
    // 0x78dd3c: DecompressPointer r1
    //     0x78dd3c: add             x1, x1, HEAP, lsl #32
    // 0x78dd40: CheckStackOverflow
    //     0x78dd40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78dd44: cmp             SP, x16
    //     0x78dd48: b.ls            #0x78dd74
    // 0x78dd4c: LoadField: r0 = r1->field_f
    //     0x78dd4c: ldur            w0, [x1, #0xf]
    // 0x78dd50: DecompressPointer r0
    //     0x78dd50: add             x0, x0, HEAP, lsl #32
    // 0x78dd54: ldr             x16, [fp, #0x10]
    // 0x78dd58: stp             x16, x0, [SP, #-0x10]!
    // 0x78dd5c: r0 = stopTrackingIfPointerNoLongerDown()
    //     0x78dd5c: bl              #0x7891a8  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingIfPointerNoLongerDown
    // 0x78dd60: add             SP, SP, #0x10
    // 0x78dd64: r0 = Null
    //     0x78dd64: mov             x0, NULL
    // 0x78dd68: LeaveFrame
    //     0x78dd68: mov             SP, fp
    //     0x78dd6c: ldp             fp, lr, [SP], #0x10
    // 0x78dd70: ret
    //     0x78dd70: ret             
    // 0x78dd74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78dd74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78dd78: b               #0x78dd4c
  }
  _ reset(/* No info */) {
    // ** addr: 0xa6a384, size: 0x44
    // 0xa6a384: EnterFrame
    //     0xa6a384: stp             fp, lr, [SP, #-0x10]!
    //     0xa6a388: mov             fp, SP
    // 0xa6a38c: CheckStackOverflow
    //     0xa6a38c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6a390: cmp             SP, x16
    //     0xa6a394: b.ls            #0xa6a3c0
    // 0xa6a398: ldr             x16, [fp, #0x10]
    // 0xa6a39c: r30 = Instance_GestureDisposition
    //     0xa6a39c: add             lr, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0xa6a3a0: ldr             lr, [lr, #0xeb8]
    // 0xa6a3a4: stp             lr, x16, [SP, #-0x10]!
    // 0xa6a3a8: r0 = resolve()
    //     0xa6a3a8: bl              #0x715700  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xa6a3ac: add             SP, SP, #0x10
    // 0xa6a3b0: r0 = Null
    //     0xa6a3b0: mov             x0, NULL
    // 0xa6a3b4: LeaveFrame
    //     0xa6a3b4: mov             SP, fp
    //     0xa6a3b8: ldp             fp, lr, [SP], #0x10
    // 0xa6a3bc: ret
    //     0xa6a3bc: ret             
    // 0xa6a3c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6a3c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6a3c4: b               #0xa6a398
  }
  _ acceptGesture(/* No info */) {
    // ** addr: 0xbdc128, size: 0x44
    // 0xbdc128: EnterFrame
    //     0xbdc128: stp             fp, lr, [SP, #-0x10]!
    //     0xbdc12c: mov             fp, SP
    // 0xbdc130: CheckStackOverflow
    //     0xbdc130: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdc134: cmp             SP, x16
    //     0xbdc138: b.ls            #0xbdc164
    // 0xbdc13c: ldr             x0, [fp, #0x18]
    // 0xbdc140: LoadField: r1 = r0->field_27
    //     0xbdc140: ldur            w1, [x0, #0x27]
    // 0xbdc144: DecompressPointer r1
    //     0xbdc144: add             x1, x1, HEAP, lsl #32
    // 0xbdc148: SaveReg r1
    //     0xbdc148: str             x1, [SP, #-8]!
    // 0xbdc14c: r0 = acceptGesture()
    //     0xbdc14c: bl              #0xbdc16c  ; [package:flutter/src/services/platform_views.dart] UiKitViewController::acceptGesture
    // 0xbdc150: add             SP, SP, #8
    // 0xbdc154: r0 = Null
    //     0xbdc154: mov             x0, NULL
    // 0xbdc158: LeaveFrame
    //     0xbdc158: mov             SP, fp
    //     0xbdc15c: ldp             fp, lr, [SP], #0x10
    // 0xbdc160: ret
    //     0xbdc160: ret             
    // 0xbdc164: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdc164: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdc168: b               #0xbdc13c
  }
  _ rejectGesture(/* No info */) {
    // ** addr: 0xcee578, size: 0x44
    // 0xcee578: EnterFrame
    //     0xcee578: stp             fp, lr, [SP, #-0x10]!
    //     0xcee57c: mov             fp, SP
    // 0xcee580: CheckStackOverflow
    //     0xcee580: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcee584: cmp             SP, x16
    //     0xcee588: b.ls            #0xcee5b4
    // 0xcee58c: ldr             x0, [fp, #0x18]
    // 0xcee590: LoadField: r1 = r0->field_27
    //     0xcee590: ldur            w1, [x0, #0x27]
    // 0xcee594: DecompressPointer r1
    //     0xcee594: add             x1, x1, HEAP, lsl #32
    // 0xcee598: SaveReg r1
    //     0xcee598: str             x1, [SP, #-8]!
    // 0xcee59c: r0 = rejectGesture()
    //     0xcee59c: bl              #0x9becd8  ; [package:flutter/src/services/platform_views.dart] UiKitViewController::rejectGesture
    // 0xcee5a0: add             SP, SP, #8
    // 0xcee5a4: r0 = Null
    //     0xcee5a4: mov             x0, NULL
    // 0xcee5a8: LeaveFrame
    //     0xcee5a8: mov             SP, fp
    //     0xcee5ac: ldp             fp, lr, [SP], #0x10
    // 0xcee5b0: ret
    //     0xcee5b0: ret             
    // 0xcee5b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee5b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee5b8: b               #0xcee58c
  }
}

// class id: 2429, size: 0x70, field offset: 0x60
class RenderUiKitView extends RenderBox {

  _ hitTest(/* No info */) {
    // ** addr: 0x640af4, size: 0xa8
    // 0x640af4: EnterFrame
    //     0x640af4: stp             fp, lr, [SP, #-0x10]!
    //     0x640af8: mov             fp, SP
    // 0x640afc: CheckStackOverflow
    //     0x640afc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x640b00: cmp             SP, x16
    //     0x640b04: b.ls            #0x640b8c
    // 0x640b08: ldr             x0, [fp, #0x20]
    // 0x640b0c: LoadField: r1 = r0->field_57
    //     0x640b0c: ldur            w1, [x0, #0x57]
    // 0x640b10: DecompressPointer r1
    //     0x640b10: add             x1, x1, HEAP, lsl #32
    // 0x640b14: cmp             w1, NULL
    // 0x640b18: b.eq            #0x640b94
    // 0x640b1c: ldr             x2, [fp, #0x10]
    // 0x640b20: cmp             w2, NULL
    // 0x640b24: b.eq            #0x640b98
    // 0x640b28: stp             x2, x1, [SP, #-0x10]!
    // 0x640b2c: r0 = contains()
    //     0x640b2c: bl              #0x63f33c  ; [dart:ui] Size::contains
    // 0x640b30: add             SP, SP, #0x10
    // 0x640b34: tbz             w0, #4, #0x640b48
    // 0x640b38: r0 = false
    //     0x640b38: add             x0, NULL, #0x30  ; false
    // 0x640b3c: LeaveFrame
    //     0x640b3c: mov             SP, fp
    //     0x640b40: ldp             fp, lr, [SP], #0x10
    // 0x640b44: ret
    //     0x640b44: ret             
    // 0x640b48: ldr             x0, [fp, #0x20]
    // 0x640b4c: ldr             x2, [fp, #0x10]
    // 0x640b50: r1 = <RenderBox>
    //     0x640b50: ldr             x1, [PP, #0x3b20]  ; [pp+0x3b20] TypeArguments: <RenderBox>
    // 0x640b54: r0 = BoxHitTestEntry()
    //     0x640b54: bl              #0x63f330  ; AllocateBoxHitTestEntryStub -> BoxHitTestEntry (size=0x18)
    // 0x640b58: mov             x1, x0
    // 0x640b5c: ldr             x0, [fp, #0x10]
    // 0x640b60: StoreField: r1->field_13 = r0
    //     0x640b60: stur            w0, [x1, #0x13]
    // 0x640b64: ldr             x0, [fp, #0x20]
    // 0x640b68: StoreField: r1->field_b = r0
    //     0x640b68: stur            w0, [x1, #0xb]
    // 0x640b6c: ldr             x16, [fp, #0x18]
    // 0x640b70: stp             x1, x16, [SP, #-0x10]!
    // 0x640b74: r0 = add()
    //     0x640b74: bl              #0x50ea24  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::add
    // 0x640b78: add             SP, SP, #0x10
    // 0x640b7c: r0 = true
    //     0x640b7c: add             x0, NULL, #0x20  ; true
    // 0x640b80: LeaveFrame
    //     0x640b80: mov             SP, fp
    //     0x640b84: ldp             fp, lr, [SP], #0x10
    // 0x640b88: ret
    //     0x640b88: ret             
    // 0x640b8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x640b8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x640b90: b               #0x640b08
    // 0x640b94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x640b94: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x640b98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x640b98: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0x6517f8, size: 0x54
    // 0x6517f8: EnterFrame
    //     0x6517f8: stp             fp, lr, [SP, #-0x10]!
    //     0x6517fc: mov             fp, SP
    // 0x651800: r0 = true
    //     0x651800: add             x0, NULL, #0x20  ; true
    // 0x651804: CheckStackOverflow
    //     0x651804: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x651808: cmp             SP, x16
    //     0x65180c: b.ls            #0x651844
    // 0x651810: ldr             x1, [fp, #0x10]
    // 0x651814: StoreField: r1->field_7 = r0
    //     0x651814: stur            w0, [x1, #7]
    // 0x651818: ldr             x0, [fp, #0x18]
    // 0x65181c: LoadField: r2 = r0->field_5f
    //     0x65181c: ldur            w2, [x0, #0x5f]
    // 0x651820: DecompressPointer r2
    //     0x651820: add             x2, x2, HEAP, lsl #32
    // 0x651824: LoadField: r0 = r2->field_7
    //     0x651824: ldur            x0, [x2, #7]
    // 0x651828: stp             x0, x1, [SP, #-0x10]!
    // 0x65182c: r0 = platformViewId=()
    //     0x65182c: bl              #0x651690  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::platformViewId=
    // 0x651830: add             SP, SP, #0x10
    // 0x651834: r0 = Null
    //     0x651834: mov             x0, NULL
    // 0x651838: LeaveFrame
    //     0x651838: mov             SP, fp
    //     0x65183c: ldp             fp, lr, [SP], #0x10
    // 0x651840: ret
    //     0x651840: ret             
    // 0x651844: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x651844: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x651848: b               #0x651810
  }
  _ paint(/* No info */) {
    // ** addr: 0x66f030, size: 0xb0
    // 0x66f030: EnterFrame
    //     0x66f030: stp             fp, lr, [SP, #-0x10]!
    //     0x66f034: mov             fp, SP
    // 0x66f038: AllocStack(0x18)
    //     0x66f038: sub             SP, SP, #0x18
    // 0x66f03c: CheckStackOverflow
    //     0x66f03c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66f040: cmp             SP, x16
    //     0x66f044: b.ls            #0x66f0d4
    // 0x66f048: ldr             x0, [fp, #0x20]
    // 0x66f04c: LoadField: r1 = r0->field_57
    //     0x66f04c: ldur            w1, [x0, #0x57]
    // 0x66f050: DecompressPointer r1
    //     0x66f050: add             x1, x1, HEAP, lsl #32
    // 0x66f054: cmp             w1, NULL
    // 0x66f058: b.eq            #0x66f0dc
    // 0x66f05c: ldr             x16, [fp, #0x10]
    // 0x66f060: stp             x1, x16, [SP, #-0x10]!
    // 0x66f064: r0 = &()
    //     0x66f064: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x66f068: add             SP, SP, #0x10
    // 0x66f06c: mov             x1, x0
    // 0x66f070: ldr             x0, [fp, #0x20]
    // 0x66f074: stur            x1, [fp, #-0x10]
    // 0x66f078: LoadField: r2 = r0->field_5f
    //     0x66f078: ldur            w2, [x0, #0x5f]
    // 0x66f07c: DecompressPointer r2
    //     0x66f07c: add             x2, x2, HEAP, lsl #32
    // 0x66f080: LoadField: r0 = r2->field_7
    //     0x66f080: ldur            x0, [x2, #7]
    // 0x66f084: stur            x0, [fp, #-8]
    // 0x66f088: r0 = PlatformViewLayer()
    //     0x66f088: bl              #0x66f024  ; AllocatePlatformViewLayerStub -> PlatformViewLayer (size=0x4c)
    // 0x66f08c: mov             x1, x0
    // 0x66f090: ldur            x0, [fp, #-0x10]
    // 0x66f094: stur            x1, [fp, #-0x18]
    // 0x66f098: StoreField: r1->field_3f = r0
    //     0x66f098: stur            w0, [x1, #0x3f]
    // 0x66f09c: ldur            x0, [fp, #-8]
    // 0x66f0a0: StoreField: r1->field_43 = r0
    //     0x66f0a0: stur            x0, [x1, #0x43]
    // 0x66f0a4: SaveReg r1
    //     0x66f0a4: str             x1, [SP, #-8]!
    // 0x66f0a8: r0 = Layer()
    //     0x66f0a8: bl              #0x5bbe7c  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0x66f0ac: add             SP, SP, #8
    // 0x66f0b0: ldr             x16, [fp, #0x18]
    // 0x66f0b4: ldur            lr, [fp, #-0x18]
    // 0x66f0b8: stp             lr, x16, [SP, #-0x10]!
    // 0x66f0bc: r0 = addLayer()
    //     0x66f0bc: bl              #0x66eec4  ; [package:flutter/src/rendering/object.dart] PaintingContext::addLayer
    // 0x66f0c0: add             SP, SP, #0x10
    // 0x66f0c4: r0 = Null
    //     0x66f0c4: mov             x0, NULL
    // 0x66f0c8: LeaveFrame
    //     0x66f0c8: mov             SP, fp
    //     0x66f0cc: ldp             fp, lr, [SP], #0x10
    // 0x66f0d0: ret
    //     0x66f0d0: ret             
    // 0x66f0d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66f0d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66f0d8: b               #0x66f048
    // 0x66f0dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66f0dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ updateGestureRecognizers(/* No info */) {
    // ** addr: 0x6d3c7c, size: 0x100
    // 0x6d3c7c: EnterFrame
    //     0x6d3c7c: stp             fp, lr, [SP, #-0x10]!
    //     0x6d3c80: mov             fp, SP
    // 0x6d3c84: AllocStack(0x10)
    //     0x6d3c84: sub             SP, SP, #0x10
    // 0x6d3c88: CheckStackOverflow
    //     0x6d3c88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d3c8c: cmp             SP, x16
    //     0x6d3c90: b.ls            #0x6d3d74
    // 0x6d3c94: ldr             x0, [fp, #0x18]
    // 0x6d3c98: LoadField: r1 = r0->field_67
    //     0x6d3c98: ldur            w1, [x0, #0x67]
    // 0x6d3c9c: DecompressPointer r1
    //     0x6d3c9c: add             x1, x1, HEAP, lsl #32
    // 0x6d3ca0: cmp             w1, NULL
    // 0x6d3ca4: b.ne            #0x6d3cb0
    // 0x6d3ca8: r1 = Null
    //     0x6d3ca8: mov             x1, NULL
    // 0x6d3cac: b               #0x6d3cbc
    // 0x6d3cb0: LoadField: r2 = r1->field_1f
    //     0x6d3cb0: ldur            w2, [x1, #0x1f]
    // 0x6d3cb4: DecompressPointer r2
    //     0x6d3cb4: add             x2, x2, HEAP, lsl #32
    // 0x6d3cb8: mov             x1, x2
    // 0x6d3cbc: r16 = <OneSequenceGestureRecognizer>
    //     0x6d3cbc: add             x16, PP, #0x49, lsl #12  ; [pp+0x49930] TypeArguments: <OneSequenceGestureRecognizer>
    //     0x6d3cc0: ldr             x16, [x16, #0x930]
    // 0x6d3cc4: ldr             lr, [fp, #0x10]
    // 0x6d3cc8: stp             lr, x16, [SP, #-0x10]!
    // 0x6d3ccc: SaveReg r1
    //     0x6d3ccc: str             x1, [SP, #-8]!
    // 0x6d3cd0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x6d3cd0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x6d3cd4: r0 = _factoryTypesSetEquals()
    //     0x6d3cd4: bl              #0x6d43d0  ; [package:flutter/src/rendering/platform_view.dart] ::_factoryTypesSetEquals
    // 0x6d3cd8: add             SP, SP, #0x18
    // 0x6d3cdc: tbnz            w0, #4, #0x6d3cf0
    // 0x6d3ce0: r0 = Null
    //     0x6d3ce0: mov             x0, NULL
    // 0x6d3ce4: LeaveFrame
    //     0x6d3ce4: mov             SP, fp
    //     0x6d3ce8: ldp             fp, lr, [SP], #0x10
    // 0x6d3cec: ret
    //     0x6d3cec: ret             
    // 0x6d3cf0: ldr             x0, [fp, #0x18]
    // 0x6d3cf4: LoadField: r1 = r0->field_67
    //     0x6d3cf4: ldur            w1, [x0, #0x67]
    // 0x6d3cf8: DecompressPointer r1
    //     0x6d3cf8: add             x1, x1, HEAP, lsl #32
    // 0x6d3cfc: cmp             w1, NULL
    // 0x6d3d00: b.eq            #0x6d3d14
    // 0x6d3d04: SaveReg r1
    //     0x6d3d04: str             x1, [SP, #-8]!
    // 0x6d3d08: r0 = dispose()
    //     0x6d3d08: bl              #0xbd93a4  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::dispose
    // 0x6d3d0c: add             SP, SP, #8
    // 0x6d3d10: ldr             x0, [fp, #0x18]
    // 0x6d3d14: LoadField: r1 = r0->field_5f
    //     0x6d3d14: ldur            w1, [x0, #0x5f]
    // 0x6d3d18: DecompressPointer r1
    //     0x6d3d18: add             x1, x1, HEAP, lsl #32
    // 0x6d3d1c: stur            x1, [fp, #-8]
    // 0x6d3d20: r0 = _UiKitViewGestureRecognizer()
    //     0x6d3d20: bl              #0x6d43c4  ; Allocate_UiKitViewGestureRecognizerStub -> _UiKitViewGestureRecognizer (size=0x2c)
    // 0x6d3d24: stur            x0, [fp, #-0x10]
    // 0x6d3d28: ldur            x16, [fp, #-8]
    // 0x6d3d2c: stp             x16, x0, [SP, #-0x10]!
    // 0x6d3d30: ldr             x16, [fp, #0x10]
    // 0x6d3d34: SaveReg r16
    //     0x6d3d34: str             x16, [SP, #-8]!
    // 0x6d3d38: r0 = _UiKitViewGestureRecognizer()
    //     0x6d3d38: bl              #0x6d3d7c  ; [package:flutter/src/rendering/platform_view.dart] _UiKitViewGestureRecognizer::_UiKitViewGestureRecognizer
    // 0x6d3d3c: add             SP, SP, #0x18
    // 0x6d3d40: ldur            x0, [fp, #-0x10]
    // 0x6d3d44: ldr             x1, [fp, #0x18]
    // 0x6d3d48: StoreField: r1->field_67 = r0
    //     0x6d3d48: stur            w0, [x1, #0x67]
    //     0x6d3d4c: ldurb           w16, [x1, #-1]
    //     0x6d3d50: ldurb           w17, [x0, #-1]
    //     0x6d3d54: and             x16, x17, x16, lsr #2
    //     0x6d3d58: tst             x16, HEAP, lsr #32
    //     0x6d3d5c: b.eq            #0x6d3d64
    //     0x6d3d60: bl              #0xd6826c
    // 0x6d3d64: r0 = Null
    //     0x6d3d64: mov             x0, NULL
    // 0x6d3d68: LeaveFrame
    //     0x6d3d68: mov             SP, fp
    //     0x6d3d6c: ldp             fp, lr, [SP], #0x10
    // 0x6d3d70: ret
    //     0x6d3d70: ret             
    // 0x6d3d74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d3d74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d3d78: b               #0x6d3c94
  }
  set _ viewController=(/* No info */) {
    // ** addr: 0x6d4780, size: 0xb4
    // 0x6d4780: EnterFrame
    //     0x6d4780: stp             fp, lr, [SP, #-0x10]!
    //     0x6d4784: mov             fp, SP
    // 0x6d4788: AllocStack(0x10)
    //     0x6d4788: sub             SP, SP, #0x10
    // 0x6d478c: CheckStackOverflow
    //     0x6d478c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d4790: cmp             SP, x16
    //     0x6d4794: b.ls            #0x6d482c
    // 0x6d4798: ldr             x1, [fp, #0x18]
    // 0x6d479c: LoadField: r0 = r1->field_5f
    //     0x6d479c: ldur            w0, [x1, #0x5f]
    // 0x6d47a0: DecompressPointer r0
    //     0x6d47a0: add             x0, x0, HEAP, lsl #32
    // 0x6d47a4: ldr             x2, [fp, #0x10]
    // 0x6d47a8: cmp             w0, w2
    // 0x6d47ac: b.ne            #0x6d47c0
    // 0x6d47b0: r0 = Null
    //     0x6d47b0: mov             x0, NULL
    // 0x6d47b4: LeaveFrame
    //     0x6d47b4: mov             SP, fp
    //     0x6d47b8: ldp             fp, lr, [SP], #0x10
    // 0x6d47bc: ret
    //     0x6d47bc: ret             
    // 0x6d47c0: LoadField: r3 = r0->field_7
    //     0x6d47c0: ldur            x3, [x0, #7]
    // 0x6d47c4: stur            x3, [fp, #-0x10]
    // 0x6d47c8: LoadField: r4 = r2->field_7
    //     0x6d47c8: ldur            x4, [x2, #7]
    // 0x6d47cc: mov             x0, x2
    // 0x6d47d0: stur            x4, [fp, #-8]
    // 0x6d47d4: StoreField: r1->field_5f = r0
    //     0x6d47d4: stur            w0, [x1, #0x5f]
    //     0x6d47d8: ldurb           w16, [x1, #-1]
    //     0x6d47dc: ldurb           w17, [x0, #-1]
    //     0x6d47e0: and             x16, x17, x16, lsr #2
    //     0x6d47e4: tst             x16, HEAP, lsr #32
    //     0x6d47e8: b.eq            #0x6d47f0
    //     0x6d47ec: bl              #0xd6826c
    // 0x6d47f0: SaveReg r1
    //     0x6d47f0: str             x1, [SP, #-8]!
    // 0x6d47f4: r0 = markNeedsPaint()
    //     0x6d47f4: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6d47f8: add             SP, SP, #8
    // 0x6d47fc: ldur            x0, [fp, #-0x10]
    // 0x6d4800: ldur            x1, [fp, #-8]
    // 0x6d4804: cmp             x0, x1
    // 0x6d4808: b.eq            #0x6d481c
    // 0x6d480c: ldr             x16, [fp, #0x18]
    // 0x6d4810: SaveReg r16
    //     0x6d4810: str             x16, [SP, #-8]!
    // 0x6d4814: r0 = markNeedsSemanticsUpdate()
    //     0x6d4814: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6d4818: add             SP, SP, #8
    // 0x6d481c: r0 = Null
    //     0x6d481c: mov             x0, NULL
    // 0x6d4820: LeaveFrame
    //     0x6d4820: mov             SP, fp
    //     0x6d4824: ldp             fp, lr, [SP], #0x10
    // 0x6d4828: ret
    //     0x6d4828: ret             
    // 0x6d482c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d482c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d4830: b               #0x6d4798
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0x716f78, size: 0x10c
    // 0x716f78: EnterFrame
    //     0x716f78: stp             fp, lr, [SP, #-0x10]!
    //     0x716f7c: mov             fp, SP
    // 0x716f80: CheckStackOverflow
    //     0x716f80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x716f84: cmp             SP, x16
    //     0x716f88: b.ls            #0x717078
    // 0x716f8c: ldr             x0, [fp, #0x10]
    // 0x716f90: r2 = Null
    //     0x716f90: mov             x2, NULL
    // 0x716f94: r1 = Null
    //     0x716f94: mov             x1, NULL
    // 0x716f98: r8 = HitTestEntry<HitTestTarget>
    //     0x716f98: ldr             x8, [PP, #0x72c0]  ; [pp+0x72c0] Type: HitTestEntry<HitTestTarget>
    // 0x716f9c: r3 = Null
    //     0x716f9c: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fde0] Null
    //     0x716fa0: ldr             x3, [x3, #0xde0]
    // 0x716fa4: r0 = HitTestEntry<HitTestTarget>()
    //     0x716fa4: bl              #0x50f268  ; IsType_HitTestEntry<HitTestTarget>_Stub
    // 0x716fa8: ldr             x0, [fp, #0x18]
    // 0x716fac: r2 = Null
    //     0x716fac: mov             x2, NULL
    // 0x716fb0: r1 = Null
    //     0x716fb0: mov             x1, NULL
    // 0x716fb4: cmp             w0, NULL
    // 0x716fb8: b.eq            #0x716fd8
    // 0x716fbc: branchIfSmi(r0, 0x716fd8)
    //     0x716fbc: tbz             w0, #0, #0x716fd8
    // 0x716fc0: r3 = LoadClassIdInstr(r0)
    //     0x716fc0: ldur            x3, [x0, #-1]
    //     0x716fc4: ubfx            x3, x3, #0xc, #0x14
    // 0x716fc8: cmp             x3, #0x90a
    // 0x716fcc: b.eq            #0x716fe0
    // 0x716fd0: cmp             x3, #0xb41
    // 0x716fd4: b.eq            #0x716fe0
    // 0x716fd8: r0 = false
    //     0x716fd8: add             x0, NULL, #0x30  ; false
    // 0x716fdc: b               #0x716fe4
    // 0x716fe0: r0 = true
    //     0x716fe0: add             x0, NULL, #0x20  ; true
    // 0x716fe4: tbz             w0, #4, #0x716ff8
    // 0x716fe8: r0 = Null
    //     0x716fe8: mov             x0, NULL
    // 0x716fec: LeaveFrame
    //     0x716fec: mov             SP, fp
    //     0x716ff0: ldp             fp, lr, [SP], #0x10
    // 0x716ff4: ret
    //     0x716ff4: ret             
    // 0x716ff8: ldr             x1, [fp, #0x20]
    // 0x716ffc: ldr             x0, [fp, #0x18]
    // 0x717000: LoadField: r2 = r1->field_67
    //     0x717000: ldur            w2, [x1, #0x67]
    // 0x717004: DecompressPointer r2
    //     0x717004: add             x2, x2, HEAP, lsl #32
    // 0x717008: cmp             w2, NULL
    // 0x71700c: b.eq            #0x717080
    // 0x717010: stp             x0, x2, [SP, #-0x10]!
    // 0x717014: r0 = addPointer()
    //     0x717014: bl              #0x6fd9cc  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::addPointer
    // 0x717018: add             SP, SP, #0x10
    // 0x71701c: ldr             x1, [fp, #0x18]
    // 0x717020: r0 = LoadClassIdInstr(r1)
    //     0x717020: ldur            x0, [x1, #-1]
    //     0x717024: ubfx            x0, x0, #0xc, #0x14
    // 0x717028: SaveReg r1
    //     0x717028: str             x1, [SP, #-8]!
    // 0x71702c: r0 = GDT[cid_x0 + -0x1]()
    //     0x71702c: sub             lr, x0, #1
    //     0x717030: ldr             lr, [x21, lr, lsl #3]
    //     0x717034: blr             lr
    // 0x717038: add             SP, SP, #8
    // 0x71703c: cmp             w0, NULL
    // 0x717040: b.ne            #0x717048
    // 0x717044: ldr             x0, [fp, #0x18]
    // 0x717048: ldr             x1, [fp, #0x20]
    // 0x71704c: StoreField: r1->field_6b = r0
    //     0x71704c: stur            w0, [x1, #0x6b]
    //     0x717050: ldurb           w16, [x1, #-1]
    //     0x717054: ldurb           w17, [x0, #-1]
    //     0x717058: and             x16, x17, x16, lsr #2
    //     0x71705c: tst             x16, HEAP, lsr #32
    //     0x717060: b.eq            #0x717068
    //     0x717064: bl              #0xd6826c
    // 0x717068: r0 = Null
    //     0x717068: mov             x0, NULL
    // 0x71706c: LeaveFrame
    //     0x71706c: mov             SP, fp
    //     0x717070: ldp             fp, lr, [SP], #0x10
    // 0x717074: ret
    //     0x717074: ret             
    // 0x717078: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x717078: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71707c: b               #0x716f8c
    // 0x717080: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x717080: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bea54, size: 0xcc
    // 0x9bea54: EnterFrame
    //     0x9bea54: stp             fp, lr, [SP, #-0x10]!
    //     0x9bea58: mov             fp, SP
    // 0x9bea5c: AllocStack(0x8)
    //     0x9bea5c: sub             SP, SP, #8
    // 0x9bea60: CheckStackOverflow
    //     0x9bea60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bea64: cmp             SP, x16
    //     0x9bea68: b.ls            #0x9beb14
    // 0x9bea6c: ldr             x0, [fp, #0x10]
    // 0x9bea70: r2 = Null
    //     0x9bea70: mov             x2, NULL
    // 0x9bea74: r1 = Null
    //     0x9bea74: mov             x1, NULL
    // 0x9bea78: r4 = 59
    //     0x9bea78: mov             x4, #0x3b
    // 0x9bea7c: branchIfSmi(r0, 0x9bea88)
    //     0x9bea7c: tbz             w0, #0, #0x9bea88
    // 0x9bea80: r4 = LoadClassIdInstr(r0)
    //     0x9bea80: ldur            x4, [x0, #-1]
    //     0x9bea84: ubfx            x4, x4, #0xc, #0x14
    // 0x9bea88: cmp             x4, #0x7e6
    // 0x9bea8c: b.eq            #0x9beaa0
    // 0x9bea90: r8 = PipelineOwner
    //     0x9bea90: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9bea94: r3 = Null
    //     0x9bea94: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fdd0] Null
    //     0x9bea98: ldr             x3, [x3, #0xdd0]
    // 0x9bea9c: r0 = DefaultTypeTest()
    //     0x9bea9c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9beaa0: ldr             x16, [fp, #0x18]
    // 0x9beaa4: ldr             lr, [fp, #0x10]
    // 0x9beaa8: stp             lr, x16, [SP, #-0x10]!
    // 0x9beaac: r0 = attach()
    //     0x9beaac: bl              #0x9bf794  ; [package:flutter/src/rendering/object.dart] RenderObject::attach
    // 0x9beab0: add             SP, SP, #0x10
    // 0x9beab4: r0 = LoadStaticField(0xd54)
    //     0x9beab4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9beab8: ldr             x0, [x0, #0x1aa8]
    // 0x9beabc: cmp             w0, NULL
    // 0x9beac0: b.eq            #0x9beb1c
    // 0x9beac4: LoadField: r1 = r0->field_13
    //     0x9beac4: ldur            w1, [x0, #0x13]
    // 0x9beac8: DecompressPointer r1
    //     0x9beac8: add             x1, x1, HEAP, lsl #32
    // 0x9beacc: stur            x1, [fp, #-8]
    // 0x9bead0: r1 = 1
    //     0x9bead0: mov             x1, #1
    // 0x9bead4: r0 = AllocateContext()
    //     0x9bead4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9bead8: mov             x1, x0
    // 0x9beadc: ldr             x0, [fp, #0x18]
    // 0x9beae0: StoreField: r1->field_f = r0
    //     0x9beae0: stur            w0, [x1, #0xf]
    // 0x9beae4: mov             x2, x1
    // 0x9beae8: r1 = Function '_handleGlobalPointerEvent@906508051':.
    //     0x9beae8: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4fdc0] AnonymousClosure: (0x9beb20), in [package:flutter/src/rendering/platform_view.dart] RenderUiKitView::_handleGlobalPointerEvent (0x9beb6c)
    //     0x9beaec: ldr             x1, [x1, #0xdc0]
    // 0x9beaf0: r0 = AllocateClosure()
    //     0x9beaf0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9beaf4: ldur            x16, [fp, #-8]
    // 0x9beaf8: stp             x0, x16, [SP, #-0x10]!
    // 0x9beafc: r0 = addGlobalRoute()
    //     0x9beafc: bl              #0x5b9b94  ; [package:flutter/src/gestures/pointer_router.dart] PointerRouter::addGlobalRoute
    // 0x9beb00: add             SP, SP, #0x10
    // 0x9beb04: r0 = Null
    //     0x9beb04: mov             x0, NULL
    // 0x9beb08: LeaveFrame
    //     0x9beb08: mov             SP, fp
    //     0x9beb0c: ldp             fp, lr, [SP], #0x10
    // 0x9beb10: ret
    //     0x9beb10: ret             
    // 0x9beb14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9beb14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9beb18: b               #0x9bea6c
    // 0x9beb1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9beb1c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleGlobalPointerEvent(dynamic, PointerEvent) {
    // ** addr: 0x9beb20, size: 0x4c
    // 0x9beb20: EnterFrame
    //     0x9beb20: stp             fp, lr, [SP, #-0x10]!
    //     0x9beb24: mov             fp, SP
    // 0x9beb28: ldr             x0, [fp, #0x18]
    // 0x9beb2c: LoadField: r1 = r0->field_17
    //     0x9beb2c: ldur            w1, [x0, #0x17]
    // 0x9beb30: DecompressPointer r1
    //     0x9beb30: add             x1, x1, HEAP, lsl #32
    // 0x9beb34: CheckStackOverflow
    //     0x9beb34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9beb38: cmp             SP, x16
    //     0x9beb3c: b.ls            #0x9beb64
    // 0x9beb40: LoadField: r0 = r1->field_f
    //     0x9beb40: ldur            w0, [x1, #0xf]
    // 0x9beb44: DecompressPointer r0
    //     0x9beb44: add             x0, x0, HEAP, lsl #32
    // 0x9beb48: ldr             x16, [fp, #0x10]
    // 0x9beb4c: stp             x16, x0, [SP, #-0x10]!
    // 0x9beb50: r0 = _handleGlobalPointerEvent()
    //     0x9beb50: bl              #0x9beb6c  ; [package:flutter/src/rendering/platform_view.dart] RenderUiKitView::_handleGlobalPointerEvent
    // 0x9beb54: add             SP, SP, #0x10
    // 0x9beb58: LeaveFrame
    //     0x9beb58: mov             SP, fp
    //     0x9beb5c: ldp             fp, lr, [SP], #0x10
    // 0x9beb60: ret
    //     0x9beb60: ret             
    // 0x9beb64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9beb64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9beb68: b               #0x9beb40
  }
  _ _handleGlobalPointerEvent(/* No info */) {
    // ** addr: 0x9beb6c, size: 0x16c
    // 0x9beb6c: EnterFrame
    //     0x9beb6c: stp             fp, lr, [SP, #-0x10]!
    //     0x9beb70: mov             fp, SP
    // 0x9beb74: AllocStack(0x8)
    //     0x9beb74: sub             SP, SP, #8
    // 0x9beb78: CheckStackOverflow
    //     0x9beb78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9beb7c: cmp             SP, x16
    //     0x9beb80: b.ls            #0x9beccc
    // 0x9beb84: ldr             x0, [fp, #0x10]
    // 0x9beb88: r2 = Null
    //     0x9beb88: mov             x2, NULL
    // 0x9beb8c: r1 = Null
    //     0x9beb8c: mov             x1, NULL
    // 0x9beb90: cmp             w0, NULL
    // 0x9beb94: b.eq            #0x9bebb4
    // 0x9beb98: branchIfSmi(r0, 0x9bebb4)
    //     0x9beb98: tbz             w0, #0, #0x9bebb4
    // 0x9beb9c: r3 = LoadClassIdInstr(r0)
    //     0x9beb9c: ldur            x3, [x0, #-1]
    //     0x9beba0: ubfx            x3, x3, #0xc, #0x14
    // 0x9beba4: cmp             x3, #0x90a
    // 0x9beba8: b.eq            #0x9bebbc
    // 0x9bebac: cmp             x3, #0xb41
    // 0x9bebb0: b.eq            #0x9bebbc
    // 0x9bebb4: r0 = false
    //     0x9bebb4: add             x0, NULL, #0x30  ; false
    // 0x9bebb8: b               #0x9bebc0
    // 0x9bebbc: r0 = true
    //     0x9bebbc: add             x0, NULL, #0x20  ; true
    // 0x9bebc0: tbz             w0, #4, #0x9bebd4
    // 0x9bebc4: r0 = Null
    //     0x9bebc4: mov             x0, NULL
    // 0x9bebc8: LeaveFrame
    //     0x9bebc8: mov             SP, fp
    //     0x9bebcc: ldp             fp, lr, [SP], #0x10
    // 0x9bebd0: ret
    //     0x9bebd0: ret             
    // 0x9bebd4: ldr             x1, [fp, #0x18]
    // 0x9bebd8: ldr             x0, [fp, #0x10]
    // 0x9bebdc: LoadField: r2 = r1->field_57
    //     0x9bebdc: ldur            w2, [x1, #0x57]
    // 0x9bebe0: DecompressPointer r2
    //     0x9bebe0: add             x2, x2, HEAP, lsl #32
    // 0x9bebe4: cmp             w2, NULL
    // 0x9bebe8: b.eq            #0x9becd4
    // 0x9bebec: r16 = Instance_Offset
    //     0x9bebec: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x9bebf0: stp             x2, x16, [SP, #-0x10]!
    // 0x9bebf4: r0 = &()
    //     0x9bebf4: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x9bebf8: add             SP, SP, #0x10
    // 0x9bebfc: mov             x2, x0
    // 0x9bec00: ldr             x1, [fp, #0x10]
    // 0x9bec04: stur            x2, [fp, #-8]
    // 0x9bec08: r0 = LoadClassIdInstr(r1)
    //     0x9bec08: ldur            x0, [x1, #-1]
    //     0x9bec0c: ubfx            x0, x0, #0xc, #0x14
    // 0x9bec10: SaveReg r1
    //     0x9bec10: str             x1, [SP, #-8]!
    // 0x9bec14: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x9bec14: sub             lr, x0, #0xfd9
    //     0x9bec18: ldr             lr, [x21, lr, lsl #3]
    //     0x9bec1c: blr             lr
    // 0x9bec20: add             SP, SP, #8
    // 0x9bec24: ldr             x16, [fp, #0x18]
    // 0x9bec28: stp             x0, x16, [SP, #-0x10]!
    // 0x9bec2c: r0 = globalToLocal()
    //     0x9bec2c: bl              #0x669450  ; [package:flutter/src/rendering/box.dart] RenderBox::globalToLocal
    // 0x9bec30: add             SP, SP, #0x10
    // 0x9bec34: ldur            x16, [fp, #-8]
    // 0x9bec38: stp             x0, x16, [SP, #-0x10]!
    // 0x9bec3c: r0 = contains()
    //     0x9bec3c: bl              #0x627548  ; [dart:ui] Rect::contains
    // 0x9bec40: add             SP, SP, #0x10
    // 0x9bec44: tbz             w0, #4, #0x9bec58
    // 0x9bec48: r0 = Null
    //     0x9bec48: mov             x0, NULL
    // 0x9bec4c: LeaveFrame
    //     0x9bec4c: mov             SP, fp
    //     0x9bec50: ldp             fp, lr, [SP], #0x10
    // 0x9bec54: ret
    //     0x9bec54: ret             
    // 0x9bec58: ldr             x1, [fp, #0x10]
    // 0x9bec5c: r0 = LoadClassIdInstr(r1)
    //     0x9bec5c: ldur            x0, [x1, #-1]
    //     0x9bec60: ubfx            x0, x0, #0xc, #0x14
    // 0x9bec64: SaveReg r1
    //     0x9bec64: str             x1, [SP, #-8]!
    // 0x9bec68: r0 = GDT[cid_x0 + -0x1]()
    //     0x9bec68: sub             lr, x0, #1
    //     0x9bec6c: ldr             lr, [x21, lr, lsl #3]
    //     0x9bec70: blr             lr
    // 0x9bec74: add             SP, SP, #8
    // 0x9bec78: cmp             w0, NULL
    // 0x9bec7c: b.ne            #0x9bec88
    // 0x9bec80: ldr             x1, [fp, #0x10]
    // 0x9bec84: b               #0x9bec8c
    // 0x9bec88: mov             x1, x0
    // 0x9bec8c: ldr             x0, [fp, #0x18]
    // 0x9bec90: LoadField: r2 = r0->field_6b
    //     0x9bec90: ldur            w2, [x0, #0x6b]
    // 0x9bec94: DecompressPointer r2
    //     0x9bec94: add             x2, x2, HEAP, lsl #32
    // 0x9bec98: cmp             w1, w2
    // 0x9bec9c: b.eq            #0x9becb4
    // 0x9beca0: LoadField: r1 = r0->field_5f
    //     0x9beca0: ldur            w1, [x0, #0x5f]
    // 0x9beca4: DecompressPointer r1
    //     0x9beca4: add             x1, x1, HEAP, lsl #32
    // 0x9beca8: SaveReg r1
    //     0x9beca8: str             x1, [SP, #-8]!
    // 0x9becac: r0 = rejectGesture()
    //     0x9becac: bl              #0x9becd8  ; [package:flutter/src/services/platform_views.dart] UiKitViewController::rejectGesture
    // 0x9becb0: add             SP, SP, #8
    // 0x9becb4: ldr             x1, [fp, #0x18]
    // 0x9becb8: StoreField: r1->field_6b = rNULL
    //     0x9becb8: stur            NULL, [x1, #0x6b]
    // 0x9becbc: r0 = Null
    //     0x9becbc: mov             x0, NULL
    // 0x9becc0: LeaveFrame
    //     0x9becc0: mov             SP, fp
    //     0x9becc4: ldp             fp, lr, [SP], #0x10
    // 0x9becc8: ret
    //     0x9becc8: ret             
    // 0x9beccc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9beccc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9becd0: b               #0x9beb84
    // 0x9becd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9becd4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ detach(/* No info */) {
    // ** addr: 0xa6a2cc, size: 0xb8
    // 0xa6a2cc: EnterFrame
    //     0xa6a2cc: stp             fp, lr, [SP, #-0x10]!
    //     0xa6a2d0: mov             fp, SP
    // 0xa6a2d4: AllocStack(0x8)
    //     0xa6a2d4: sub             SP, SP, #8
    // 0xa6a2d8: CheckStackOverflow
    //     0xa6a2d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6a2dc: cmp             SP, x16
    //     0xa6a2e0: b.ls            #0xa6a374
    // 0xa6a2e4: r0 = LoadStaticField(0xd54)
    //     0xa6a2e4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa6a2e8: ldr             x0, [x0, #0x1aa8]
    // 0xa6a2ec: cmp             w0, NULL
    // 0xa6a2f0: b.eq            #0xa6a37c
    // 0xa6a2f4: LoadField: r1 = r0->field_13
    //     0xa6a2f4: ldur            w1, [x0, #0x13]
    // 0xa6a2f8: DecompressPointer r1
    //     0xa6a2f8: add             x1, x1, HEAP, lsl #32
    // 0xa6a2fc: stur            x1, [fp, #-8]
    // 0xa6a300: r1 = 1
    //     0xa6a300: mov             x1, #1
    // 0xa6a304: r0 = AllocateContext()
    //     0xa6a304: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa6a308: mov             x1, x0
    // 0xa6a30c: ldr             x0, [fp, #0x10]
    // 0xa6a310: StoreField: r1->field_f = r0
    //     0xa6a310: stur            w0, [x1, #0xf]
    // 0xa6a314: mov             x2, x1
    // 0xa6a318: r1 = Function '_handleGlobalPointerEvent@906508051':.
    //     0xa6a318: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4fdc0] AnonymousClosure: (0x9beb20), in [package:flutter/src/rendering/platform_view.dart] RenderUiKitView::_handleGlobalPointerEvent (0x9beb6c)
    //     0xa6a31c: ldr             x1, [x1, #0xdc0]
    // 0xa6a320: r0 = AllocateClosure()
    //     0xa6a320: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa6a324: ldur            x16, [fp, #-8]
    // 0xa6a328: stp             x0, x16, [SP, #-0x10]!
    // 0xa6a32c: r0 = removeGlobalRoute()
    //     0xa6a32c: bl              #0xa535e8  ; [package:flutter/src/gestures/pointer_router.dart] PointerRouter::removeGlobalRoute
    // 0xa6a330: add             SP, SP, #0x10
    // 0xa6a334: ldr             x0, [fp, #0x10]
    // 0xa6a338: LoadField: r1 = r0->field_67
    //     0xa6a338: ldur            w1, [x0, #0x67]
    // 0xa6a33c: DecompressPointer r1
    //     0xa6a33c: add             x1, x1, HEAP, lsl #32
    // 0xa6a340: cmp             w1, NULL
    // 0xa6a344: b.eq            #0xa6a380
    // 0xa6a348: SaveReg r1
    //     0xa6a348: str             x1, [SP, #-8]!
    // 0xa6a34c: r0 = reset()
    //     0xa6a34c: bl              #0xa6a384  ; [package:flutter/src/rendering/platform_view.dart] _UiKitViewGestureRecognizer::reset
    // 0xa6a350: add             SP, SP, #8
    // 0xa6a354: ldr             x16, [fp, #0x10]
    // 0xa6a358: SaveReg r16
    //     0xa6a358: str             x16, [SP, #-8]!
    // 0xa6a35c: r0 = detach()
    //     0xa6a35c: bl              #0xa6ade0  ; [package:flutter/src/foundation/node.dart] AbstractNode::detach
    // 0xa6a360: add             SP, SP, #8
    // 0xa6a364: r0 = Null
    //     0xa6a364: mov             x0, NULL
    // 0xa6a368: LeaveFrame
    //     0xa6a368: mov             SP, fp
    //     0xa6a36c: ldp             fp, lr, [SP], #0x10
    // 0xa6a370: ret
    //     0xa6a370: ret             
    // 0xa6a374: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6a374: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6a378: b               #0xa6a2e4
    // 0xa6a37c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6a37c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa6a380: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6a380: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2430, size: 0x6c, field offset: 0x60
//   transformed mixin,
abstract class _PlatformViewRenderBox&RenderBox&_PlatformViewGestureMixin extends RenderBox
     with _PlatformViewGestureMixin {

  _ hitTest(/* No info */) {
    // ** addr: 0x640a20, size: 0xd4
    // 0x640a20: EnterFrame
    //     0x640a20: stp             fp, lr, [SP, #-0x10]!
    //     0x640a24: mov             fp, SP
    // 0x640a28: CheckStackOverflow
    //     0x640a28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x640a2c: cmp             SP, x16
    //     0x640a30: b.ls            #0x640ae8
    // 0x640a34: ldr             x0, [fp, #0x20]
    // 0x640a38: LoadField: r1 = r0->field_5f
    //     0x640a38: ldur            w1, [x0, #0x5f]
    // 0x640a3c: DecompressPointer r1
    //     0x640a3c: add             x1, x1, HEAP, lsl #32
    // 0x640a40: r16 = Instance_PlatformViewHitTestBehavior
    //     0x640a40: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4fe10] Obj!PlatformViewHitTestBehavior@b649b1
    //     0x640a44: ldr             x16, [x16, #0xe10]
    // 0x640a48: cmp             w1, w16
    // 0x640a4c: b.eq            #0x640a74
    // 0x640a50: LoadField: r1 = r0->field_57
    //     0x640a50: ldur            w1, [x0, #0x57]
    // 0x640a54: DecompressPointer r1
    //     0x640a54: add             x1, x1, HEAP, lsl #32
    // 0x640a58: cmp             w1, NULL
    // 0x640a5c: b.eq            #0x640af0
    // 0x640a60: ldr             x16, [fp, #0x10]
    // 0x640a64: stp             x16, x1, [SP, #-0x10]!
    // 0x640a68: r0 = contains()
    //     0x640a68: bl              #0x63f33c  ; [dart:ui] Size::contains
    // 0x640a6c: add             SP, SP, #0x10
    // 0x640a70: tbz             w0, #4, #0x640a84
    // 0x640a74: r0 = false
    //     0x640a74: add             x0, NULL, #0x30  ; false
    // 0x640a78: LeaveFrame
    //     0x640a78: mov             SP, fp
    //     0x640a7c: ldp             fp, lr, [SP], #0x10
    // 0x640a80: ret
    //     0x640a80: ret             
    // 0x640a84: ldr             x0, [fp, #0x20]
    // 0x640a88: ldr             x2, [fp, #0x10]
    // 0x640a8c: r1 = <RenderBox>
    //     0x640a8c: ldr             x1, [PP, #0x3b20]  ; [pp+0x3b20] TypeArguments: <RenderBox>
    // 0x640a90: r0 = BoxHitTestEntry()
    //     0x640a90: bl              #0x63f330  ; AllocateBoxHitTestEntryStub -> BoxHitTestEntry (size=0x18)
    // 0x640a94: mov             x1, x0
    // 0x640a98: ldr             x0, [fp, #0x10]
    // 0x640a9c: StoreField: r1->field_13 = r0
    //     0x640a9c: stur            w0, [x1, #0x13]
    // 0x640aa0: ldr             x0, [fp, #0x20]
    // 0x640aa4: StoreField: r1->field_b = r0
    //     0x640aa4: stur            w0, [x1, #0xb]
    // 0x640aa8: ldr             x16, [fp, #0x18]
    // 0x640aac: stp             x1, x16, [SP, #-0x10]!
    // 0x640ab0: r0 = add()
    //     0x640ab0: bl              #0x50ea24  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::add
    // 0x640ab4: add             SP, SP, #0x10
    // 0x640ab8: ldr             x1, [fp, #0x20]
    // 0x640abc: LoadField: r2 = r1->field_5f
    //     0x640abc: ldur            w2, [x1, #0x5f]
    // 0x640ac0: DecompressPointer r2
    //     0x640ac0: add             x2, x2, HEAP, lsl #32
    // 0x640ac4: r16 = Instance_PlatformViewHitTestBehavior
    //     0x640ac4: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2a378] Obj!PlatformViewHitTestBehavior@b649d1
    //     0x640ac8: ldr             x16, [x16, #0x378]
    // 0x640acc: cmp             w2, w16
    // 0x640ad0: r16 = true
    //     0x640ad0: add             x16, NULL, #0x20  ; true
    // 0x640ad4: r17 = false
    //     0x640ad4: add             x17, NULL, #0x30  ; false
    // 0x640ad8: csel            x0, x16, x17, eq
    // 0x640adc: LeaveFrame
    //     0x640adc: mov             SP, fp
    //     0x640ae0: ldp             fp, lr, [SP], #0x10
    // 0x640ae4: ret
    //     0x640ae4: ret             
    // 0x640ae8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x640ae8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x640aec: b               #0x640a34
    // 0x640af0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x640af0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateGestureRecognizersWithCallBack(/* No info */) {
    // ** addr: 0x6d49f0, size: 0x10c
    // 0x6d49f0: EnterFrame
    //     0x6d49f0: stp             fp, lr, [SP, #-0x10]!
    //     0x6d49f4: mov             fp, SP
    // 0x6d49f8: AllocStack(0x8)
    //     0x6d49f8: sub             SP, SP, #8
    // 0x6d49fc: CheckStackOverflow
    //     0x6d49fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d4a00: cmp             SP, x16
    //     0x6d4a04: b.ls            #0x6d4af4
    // 0x6d4a08: ldr             x0, [fp, #0x18]
    // 0x6d4a0c: LoadField: r1 = r0->field_67
    //     0x6d4a0c: ldur            w1, [x0, #0x67]
    // 0x6d4a10: DecompressPointer r1
    //     0x6d4a10: add             x1, x1, HEAP, lsl #32
    // 0x6d4a14: cmp             w1, NULL
    // 0x6d4a18: b.ne            #0x6d4a24
    // 0x6d4a1c: r1 = Null
    //     0x6d4a1c: mov             x1, NULL
    // 0x6d4a20: b               #0x6d4a2c
    // 0x6d4a24: r1 = _ConstSet len:0
    //     0x6d4a24: add             x1, PP, #0x23, lsl #12  ; [pp+0x23a78] Set<Factory<OneSequenceGestureRecognizer>>(0)
    //     0x6d4a28: ldr             x1, [x1, #0xa78]
    // 0x6d4a2c: r16 = <OneSequenceGestureRecognizer>
    //     0x6d4a2c: add             x16, PP, #0x49, lsl #12  ; [pp+0x49930] TypeArguments: <OneSequenceGestureRecognizer>
    //     0x6d4a30: ldr             x16, [x16, #0x930]
    // 0x6d4a34: r30 = _ConstSet len:0
    //     0x6d4a34: add             lr, PP, #0x23, lsl #12  ; [pp+0x23a78] Set<Factory<OneSequenceGestureRecognizer>>(0)
    //     0x6d4a38: ldr             lr, [lr, #0xa78]
    // 0x6d4a3c: stp             lr, x16, [SP, #-0x10]!
    // 0x6d4a40: SaveReg r1
    //     0x6d4a40: str             x1, [SP, #-8]!
    // 0x6d4a44: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x6d4a44: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x6d4a48: r0 = _factoryTypesSetEquals()
    //     0x6d4a48: bl              #0x6d43d0  ; [package:flutter/src/rendering/platform_view.dart] ::_factoryTypesSetEquals
    // 0x6d4a4c: add             SP, SP, #0x18
    // 0x6d4a50: tbnz            w0, #4, #0x6d4a64
    // 0x6d4a54: r0 = Null
    //     0x6d4a54: mov             x0, NULL
    // 0x6d4a58: LeaveFrame
    //     0x6d4a58: mov             SP, fp
    //     0x6d4a5c: ldp             fp, lr, [SP], #0x10
    // 0x6d4a60: ret
    //     0x6d4a60: ret             
    // 0x6d4a64: ldr             x0, [fp, #0x18]
    // 0x6d4a68: LoadField: r1 = r0->field_67
    //     0x6d4a68: ldur            w1, [x0, #0x67]
    // 0x6d4a6c: DecompressPointer r1
    //     0x6d4a6c: add             x1, x1, HEAP, lsl #32
    // 0x6d4a70: cmp             w1, NULL
    // 0x6d4a74: b.eq            #0x6d4a88
    // 0x6d4a78: SaveReg r1
    //     0x6d4a78: str             x1, [SP, #-8]!
    // 0x6d4a7c: r0 = dispose()
    //     0x6d4a7c: bl              #0xbd93a4  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::dispose
    // 0x6d4a80: add             SP, SP, #8
    // 0x6d4a84: ldr             x0, [fp, #0x18]
    // 0x6d4a88: r0 = _PlatformViewGestureRecognizer()
    //     0x6d4a88: bl              #0x6d4fa8  ; Allocate_PlatformViewGestureRecognizerStub -> _PlatformViewGestureRecognizer (size=0x34)
    // 0x6d4a8c: stur            x0, [fp, #-8]
    // 0x6d4a90: ldr             x16, [fp, #0x10]
    // 0x6d4a94: stp             x16, x0, [SP, #-0x10]!
    // 0x6d4a98: r0 = _PlatformViewGestureRecognizer()
    //     0x6d4a98: bl              #0x6d4afc  ; [package:flutter/src/rendering/platform_view.dart] _PlatformViewGestureRecognizer::_PlatformViewGestureRecognizer
    // 0x6d4a9c: add             SP, SP, #0x10
    // 0x6d4aa0: ldur            x0, [fp, #-8]
    // 0x6d4aa4: ldr             x1, [fp, #0x18]
    // 0x6d4aa8: StoreField: r1->field_67 = r0
    //     0x6d4aa8: stur            w0, [x1, #0x67]
    //     0x6d4aac: ldurb           w16, [x1, #-1]
    //     0x6d4ab0: ldurb           w17, [x0, #-1]
    //     0x6d4ab4: and             x16, x17, x16, lsr #2
    //     0x6d4ab8: tst             x16, HEAP, lsr #32
    //     0x6d4abc: b.eq            #0x6d4ac4
    //     0x6d4ac0: bl              #0xd6826c
    // 0x6d4ac4: ldr             x0, [fp, #0x10]
    // 0x6d4ac8: StoreField: r1->field_63 = r0
    //     0x6d4ac8: stur            w0, [x1, #0x63]
    //     0x6d4acc: ldurb           w16, [x1, #-1]
    //     0x6d4ad0: ldurb           w17, [x0, #-1]
    //     0x6d4ad4: and             x16, x17, x16, lsr #2
    //     0x6d4ad8: tst             x16, HEAP, lsr #32
    //     0x6d4adc: b.eq            #0x6d4ae4
    //     0x6d4ae0: bl              #0xd6826c
    // 0x6d4ae4: r0 = Null
    //     0x6d4ae4: mov             x0, NULL
    // 0x6d4ae8: LeaveFrame
    //     0x6d4ae8: mov             SP, fp
    //     0x6d4aec: ldp             fp, lr, [SP], #0x10
    // 0x6d4af0: ret
    //     0x6d4af0: ret             
    // 0x6d4af4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d4af4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d4af8: b               #0x6d4a08
  }
  set _ hitTestBehavior=(/* No info */) {
    // ** addr: 0x6d68ac, size: 0xb4
    // 0x6d68ac: EnterFrame
    //     0x6d68ac: stp             fp, lr, [SP, #-0x10]!
    //     0x6d68b0: mov             fp, SP
    // 0x6d68b4: AllocStack(0x8)
    //     0x6d68b4: sub             SP, SP, #8
    // 0x6d68b8: CheckStackOverflow
    //     0x6d68b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d68bc: cmp             SP, x16
    //     0x6d68c0: b.ls            #0x6d6958
    // 0x6d68c4: ldr             x3, [fp, #0x18]
    // 0x6d68c8: LoadField: r0 = r3->field_5f
    //     0x6d68c8: ldur            w0, [x3, #0x5f]
    // 0x6d68cc: DecompressPointer r0
    //     0x6d68cc: add             x0, x0, HEAP, lsl #32
    // 0x6d68d0: r16 = Instance_PlatformViewHitTestBehavior
    //     0x6d68d0: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2a378] Obj!PlatformViewHitTestBehavior@b649d1
    //     0x6d68d4: ldr             x16, [x16, #0x378]
    // 0x6d68d8: cmp             w0, w16
    // 0x6d68dc: b.eq            #0x6d6948
    // 0x6d68e0: r0 = Instance_PlatformViewHitTestBehavior
    //     0x6d68e0: add             x0, PP, #0x2a, lsl #12  ; [pp+0x2a378] Obj!PlatformViewHitTestBehavior@b649d1
    //     0x6d68e4: ldr             x0, [x0, #0x378]
    // 0x6d68e8: StoreField: r3->field_5f = r0
    //     0x6d68e8: stur            w0, [x3, #0x5f]
    // 0x6d68ec: LoadField: r4 = r3->field_f
    //     0x6d68ec: ldur            w4, [x3, #0xf]
    // 0x6d68f0: DecompressPointer r4
    //     0x6d68f0: add             x4, x4, HEAP, lsl #32
    // 0x6d68f4: mov             x0, x4
    // 0x6d68f8: stur            x4, [fp, #-8]
    // 0x6d68fc: r2 = Null
    //     0x6d68fc: mov             x2, NULL
    // 0x6d6900: r1 = Null
    //     0x6d6900: mov             x1, NULL
    // 0x6d6904: r4 = 59
    //     0x6d6904: mov             x4, #0x3b
    // 0x6d6908: branchIfSmi(r0, 0x6d6914)
    //     0x6d6908: tbz             w0, #0, #0x6d6914
    // 0x6d690c: r4 = LoadClassIdInstr(r0)
    //     0x6d690c: ldur            x4, [x0, #-1]
    //     0x6d6910: ubfx            x4, x4, #0xc, #0x14
    // 0x6d6914: cmp             x4, #0x7e6
    // 0x6d6918: b.eq            #0x6d692c
    // 0x6d691c: r8 = PipelineOwner?
    //     0x6d691c: ldr             x8, [PP, #0x45c8]  ; [pp+0x45c8] Type: PipelineOwner?
    // 0x6d6920: r3 = Null
    //     0x6d6920: add             x3, PP, #0x49, lsl #12  ; [pp+0x499d8] Null
    //     0x6d6924: ldr             x3, [x3, #0x9d8]
    // 0x6d6928: r0 = DefaultNullableTypeTest()
    //     0x6d6928: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x6d692c: ldur            x0, [fp, #-8]
    // 0x6d6930: cmp             w0, NULL
    // 0x6d6934: b.eq            #0x6d6948
    // 0x6d6938: ldr             x16, [fp, #0x18]
    // 0x6d693c: SaveReg r16
    //     0x6d693c: str             x16, [SP, #-8]!
    // 0x6d6940: r0 = markNeedsPaint()
    //     0x6d6940: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6d6944: add             SP, SP, #8
    // 0x6d6948: r0 = Null
    //     0x6d6948: mov             x0, NULL
    // 0x6d694c: LeaveFrame
    //     0x6d694c: mov             SP, fp
    //     0x6d6950: ldp             fp, lr, [SP], #0x10
    // 0x6d6954: ret
    //     0x6d6954: ret             
    // 0x6d6958: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d6958: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d695c: b               #0x6d68c4
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0x716e58, size: 0x120
    // 0x716e58: EnterFrame
    //     0x716e58: stp             fp, lr, [SP, #-0x10]!
    //     0x716e5c: mov             fp, SP
    // 0x716e60: CheckStackOverflow
    //     0x716e60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x716e64: cmp             SP, x16
    //     0x716e68: b.ls            #0x716f6c
    // 0x716e6c: ldr             x0, [fp, #0x10]
    // 0x716e70: r2 = Null
    //     0x716e70: mov             x2, NULL
    // 0x716e74: r1 = Null
    //     0x716e74: mov             x1, NULL
    // 0x716e78: r8 = HitTestEntry<HitTestTarget>
    //     0x716e78: ldr             x8, [PP, #0x72c0]  ; [pp+0x72c0] Type: HitTestEntry<HitTestTarget>
    // 0x716e7c: r3 = Null
    //     0x716e7c: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fdf8] Null
    //     0x716e80: ldr             x3, [x3, #0xdf8]
    // 0x716e84: r0 = HitTestEntry<HitTestTarget>()
    //     0x716e84: bl              #0x50f268  ; IsType_HitTestEntry<HitTestTarget>_Stub
    // 0x716e88: ldr             x0, [fp, #0x18]
    // 0x716e8c: r2 = Null
    //     0x716e8c: mov             x2, NULL
    // 0x716e90: r1 = Null
    //     0x716e90: mov             x1, NULL
    // 0x716e94: cmp             w0, NULL
    // 0x716e98: b.eq            #0x716eb8
    // 0x716e9c: branchIfSmi(r0, 0x716eb8)
    //     0x716e9c: tbz             w0, #0, #0x716eb8
    // 0x716ea0: r3 = LoadClassIdInstr(r0)
    //     0x716ea0: ldur            x3, [x0, #-1]
    //     0x716ea4: ubfx            x3, x3, #0xc, #0x14
    // 0x716ea8: cmp             x3, #0x90a
    // 0x716eac: b.eq            #0x716ec0
    // 0x716eb0: cmp             x3, #0xb41
    // 0x716eb4: b.eq            #0x716ec0
    // 0x716eb8: r0 = false
    //     0x716eb8: add             x0, NULL, #0x30  ; false
    // 0x716ebc: b               #0x716ec4
    // 0x716ec0: r0 = true
    //     0x716ec0: add             x0, NULL, #0x20  ; true
    // 0x716ec4: tbnz            w0, #4, #0x716eec
    // 0x716ec8: ldr             x0, [fp, #0x20]
    // 0x716ecc: LoadField: r1 = r0->field_67
    //     0x716ecc: ldur            w1, [x0, #0x67]
    // 0x716ed0: DecompressPointer r1
    //     0x716ed0: add             x1, x1, HEAP, lsl #32
    // 0x716ed4: cmp             w1, NULL
    // 0x716ed8: b.eq            #0x716f74
    // 0x716edc: ldr             x16, [fp, #0x18]
    // 0x716ee0: stp             x16, x1, [SP, #-0x10]!
    // 0x716ee4: r0 = addPointer()
    //     0x716ee4: bl              #0x6fd9cc  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::addPointer
    // 0x716ee8: add             SP, SP, #0x10
    // 0x716eec: ldr             x0, [fp, #0x18]
    // 0x716ef0: r2 = Null
    //     0x716ef0: mov             x2, NULL
    // 0x716ef4: r1 = Null
    //     0x716ef4: mov             x1, NULL
    // 0x716ef8: cmp             w0, NULL
    // 0x716efc: b.eq            #0x716f1c
    // 0x716f00: branchIfSmi(r0, 0x716f1c)
    //     0x716f00: tbz             w0, #0, #0x716f1c
    // 0x716f04: r3 = LoadClassIdInstr(r0)
    //     0x716f04: ldur            x3, [x0, #-1]
    //     0x716f08: ubfx            x3, x3, #0xc, #0x14
    // 0x716f0c: cmp             x3, #0x910
    // 0x716f10: b.eq            #0x716f24
    // 0x716f14: cmp             x3, #0xb47
    // 0x716f18: b.eq            #0x716f24
    // 0x716f1c: r0 = false
    //     0x716f1c: add             x0, NULL, #0x30  ; false
    // 0x716f20: b               #0x716f28
    // 0x716f24: r0 = true
    //     0x716f24: add             x0, NULL, #0x20  ; true
    // 0x716f28: tbnz            w0, #4, #0x716f5c
    // 0x716f2c: ldr             x0, [fp, #0x20]
    // 0x716f30: LoadField: r1 = r0->field_63
    //     0x716f30: ldur            w1, [x0, #0x63]
    // 0x716f34: DecompressPointer r1
    //     0x716f34: add             x1, x1, HEAP, lsl #32
    // 0x716f38: cmp             w1, NULL
    // 0x716f3c: b.eq            #0x716f5c
    // 0x716f40: ldr             x16, [fp, #0x18]
    // 0x716f44: stp             x16, x1, [SP, #-0x10]!
    // 0x716f48: mov             x0, x1
    // 0x716f4c: ClosureCall
    //     0x716f4c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x716f50: ldur            x2, [x0, #0x1f]
    //     0x716f54: blr             x2
    // 0x716f58: add             SP, SP, #0x10
    // 0x716f5c: r0 = Null
    //     0x716f5c: mov             x0, NULL
    // 0x716f60: LeaveFrame
    //     0x716f60: mov             SP, fp
    //     0x716f64: ldp             fp, lr, [SP], #0x10
    // 0x716f68: ret
    //     0x716f68: ret             
    // 0x716f6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x716f6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x716f70: b               #0x716e6c
    // 0x716f74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x716f74: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ detach(/* No info */) {
    // ** addr: 0xa6a16c, size: 0x60
    // 0xa6a16c: EnterFrame
    //     0xa6a16c: stp             fp, lr, [SP, #-0x10]!
    //     0xa6a170: mov             fp, SP
    // 0xa6a174: CheckStackOverflow
    //     0xa6a174: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6a178: cmp             SP, x16
    //     0xa6a17c: b.ls            #0xa6a1c0
    // 0xa6a180: ldr             x0, [fp, #0x10]
    // 0xa6a184: LoadField: r1 = r0->field_67
    //     0xa6a184: ldur            w1, [x0, #0x67]
    // 0xa6a188: DecompressPointer r1
    //     0xa6a188: add             x1, x1, HEAP, lsl #32
    // 0xa6a18c: cmp             w1, NULL
    // 0xa6a190: b.eq            #0xa6a1c8
    // 0xa6a194: SaveReg r1
    //     0xa6a194: str             x1, [SP, #-8]!
    // 0xa6a198: r0 = reset()
    //     0xa6a198: bl              #0xa6a1cc  ; [package:flutter/src/rendering/platform_view.dart] _PlatformViewGestureRecognizer::reset
    // 0xa6a19c: add             SP, SP, #8
    // 0xa6a1a0: ldr             x16, [fp, #0x10]
    // 0xa6a1a4: SaveReg r16
    //     0xa6a1a4: str             x16, [SP, #-8]!
    // 0xa6a1a8: r0 = detach()
    //     0xa6a1a8: bl              #0xa6ade0  ; [package:flutter/src/foundation/node.dart] AbstractNode::detach
    // 0xa6a1ac: add             SP, SP, #8
    // 0xa6a1b0: r0 = Null
    //     0xa6a1b0: mov             x0, NULL
    // 0xa6a1b4: LeaveFrame
    //     0xa6a1b4: mov             SP, fp
    //     0xa6a1b8: ldp             fp, lr, [SP], #0x10
    // 0xa6a1bc: ret
    //     0xa6a1bc: ret             
    // 0xa6a1c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6a1c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6a1c4: b               #0xa6a180
    // 0xa6a1c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6a1c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ cursor(/* No info */) {
    // ** addr: 0xafb4bc, size: 0xc
    // 0xafb4bc: r0 = Instance__NoopMouseCursor
    //     0xafb4bc: add             x0, PP, #0x4f, lsl #12  ; [pp+0x4fe08] Obj!_NoopMouseCursor@b489d1
    //     0xafb4c0: ldr             x0, [x0, #0xe08]
    // 0xafb4c4: ret
    //     0xafb4c4: ret             
  }
}

// class id: 2431, size: 0x70, field offset: 0x6c
class PlatformViewRenderBox extends _PlatformViewRenderBox&RenderBox&_PlatformViewGestureMixin {

  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0x651744, size: 0xb4
    // 0x651744: EnterFrame
    //     0x651744: stp             fp, lr, [SP, #-0x10]!
    //     0x651748: mov             fp, SP
    // 0x65174c: r2 = true
    //     0x65174c: add             x2, NULL, #0x20  ; true
    // 0x651750: ldr             x3, [fp, #0x10]
    // 0x651754: StoreField: r3->field_7 = r2
    //     0x651754: stur            w2, [x3, #7]
    // 0x651758: ldr             x4, [fp, #0x18]
    // 0x65175c: LoadField: r5 = r4->field_6b
    //     0x65175c: ldur            w5, [x4, #0x6b]
    // 0x651760: DecompressPointer r5
    //     0x651760: add             x5, x5, HEAP, lsl #32
    // 0x651764: LoadField: r4 = r5->field_7
    //     0x651764: ldur            x4, [x5, #7]
    // 0x651768: LoadField: r5 = r3->field_33
    //     0x651768: ldur            w5, [x3, #0x33]
    // 0x65176c: DecompressPointer r5
    //     0x65176c: add             x5, x5, HEAP, lsl #32
    // 0x651770: r0 = BoxInt64Instr(r4)
    //     0x651770: sbfiz           x0, x4, #1, #0x1f
    //     0x651774: cmp             x4, x0, asr #1
    //     0x651778: b.eq            #0x651784
    //     0x65177c: bl              #0xd69bb8
    //     0x651780: stur            x4, [x0, #7]
    // 0x651784: cmp             w0, w5
    // 0x651788: b.eq            #0x6517e8
    // 0x65178c: and             w16, w0, w5
    // 0x651790: branchIfSmi(r16, 0x6517c4)
    //     0x651790: tbz             w16, #0, #0x6517c4
    // 0x651794: r16 = LoadClassIdInstr(r0)
    //     0x651794: ldur            x16, [x0, #-1]
    //     0x651798: ubfx            x16, x16, #0xc, #0x14
    // 0x65179c: cmp             x16, #0x3c
    // 0x6517a0: b.ne            #0x6517c4
    // 0x6517a4: r16 = LoadClassIdInstr(r5)
    //     0x6517a4: ldur            x16, [x5, #-1]
    //     0x6517a8: ubfx            x16, x16, #0xc, #0x14
    // 0x6517ac: cmp             x16, #0x3c
    // 0x6517b0: b.ne            #0x6517c4
    // 0x6517b4: LoadField: r16 = r0->field_7
    //     0x6517b4: ldur            x16, [x0, #7]
    // 0x6517b8: LoadField: r17 = r5->field_7
    //     0x6517b8: ldur            x17, [x5, #7]
    // 0x6517bc: cmp             x16, x17
    // 0x6517c0: b.eq            #0x6517e8
    // 0x6517c4: StoreField: r3->field_33 = r0
    //     0x6517c4: stur            w0, [x3, #0x33]
    //     0x6517c8: tbz             w0, #0, #0x6517e4
    //     0x6517cc: ldurb           w16, [x3, #-1]
    //     0x6517d0: ldurb           w17, [x0, #-1]
    //     0x6517d4: and             x16, x17, x16, lsr #2
    //     0x6517d8: tst             x16, HEAP, lsr #32
    //     0x6517dc: b.eq            #0x6517e4
    //     0x6517e0: bl              #0xd682ac
    // 0x6517e4: StoreField: r3->field_13 = r2
    //     0x6517e4: stur            w2, [x3, #0x13]
    // 0x6517e8: r0 = Null
    //     0x6517e8: mov             x0, NULL
    // 0x6517ec: LeaveFrame
    //     0x6517ec: mov             SP, fp
    //     0x6517f0: ldp             fp, lr, [SP], #0x10
    // 0x6517f4: ret
    //     0x6517f4: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0x66ef74, size: 0xb0
    // 0x66ef74: EnterFrame
    //     0x66ef74: stp             fp, lr, [SP, #-0x10]!
    //     0x66ef78: mov             fp, SP
    // 0x66ef7c: AllocStack(0x18)
    //     0x66ef7c: sub             SP, SP, #0x18
    // 0x66ef80: CheckStackOverflow
    //     0x66ef80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66ef84: cmp             SP, x16
    //     0x66ef88: b.ls            #0x66f018
    // 0x66ef8c: ldr             x0, [fp, #0x20]
    // 0x66ef90: LoadField: r1 = r0->field_57
    //     0x66ef90: ldur            w1, [x0, #0x57]
    // 0x66ef94: DecompressPointer r1
    //     0x66ef94: add             x1, x1, HEAP, lsl #32
    // 0x66ef98: cmp             w1, NULL
    // 0x66ef9c: b.eq            #0x66f020
    // 0x66efa0: ldr             x16, [fp, #0x10]
    // 0x66efa4: stp             x1, x16, [SP, #-0x10]!
    // 0x66efa8: r0 = &()
    //     0x66efa8: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x66efac: add             SP, SP, #0x10
    // 0x66efb0: mov             x1, x0
    // 0x66efb4: ldr             x0, [fp, #0x20]
    // 0x66efb8: stur            x1, [fp, #-0x10]
    // 0x66efbc: LoadField: r2 = r0->field_6b
    //     0x66efbc: ldur            w2, [x0, #0x6b]
    // 0x66efc0: DecompressPointer r2
    //     0x66efc0: add             x2, x2, HEAP, lsl #32
    // 0x66efc4: LoadField: r0 = r2->field_7
    //     0x66efc4: ldur            x0, [x2, #7]
    // 0x66efc8: stur            x0, [fp, #-8]
    // 0x66efcc: r0 = PlatformViewLayer()
    //     0x66efcc: bl              #0x66f024  ; AllocatePlatformViewLayerStub -> PlatformViewLayer (size=0x4c)
    // 0x66efd0: mov             x1, x0
    // 0x66efd4: ldur            x0, [fp, #-0x10]
    // 0x66efd8: stur            x1, [fp, #-0x18]
    // 0x66efdc: StoreField: r1->field_3f = r0
    //     0x66efdc: stur            w0, [x1, #0x3f]
    // 0x66efe0: ldur            x0, [fp, #-8]
    // 0x66efe4: StoreField: r1->field_43 = r0
    //     0x66efe4: stur            x0, [x1, #0x43]
    // 0x66efe8: SaveReg r1
    //     0x66efe8: str             x1, [SP, #-8]!
    // 0x66efec: r0 = Layer()
    //     0x66efec: bl              #0x5bbe7c  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0x66eff0: add             SP, SP, #8
    // 0x66eff4: ldr             x16, [fp, #0x18]
    // 0x66eff8: ldur            lr, [fp, #-0x18]
    // 0x66effc: stp             lr, x16, [SP, #-0x10]!
    // 0x66f000: r0 = addLayer()
    //     0x66f000: bl              #0x66eec4  ; [package:flutter/src/rendering/object.dart] PaintingContext::addLayer
    // 0x66f004: add             SP, SP, #0x10
    // 0x66f008: r0 = Null
    //     0x66f008: mov             x0, NULL
    // 0x66f00c: LeaveFrame
    //     0x66f00c: mov             SP, fp
    //     0x66f010: ldp             fp, lr, [SP], #0x10
    // 0x66f014: ret
    //     0x66f014: ret             
    // 0x66f018: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66f018: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66f01c: b               #0x66ef8c
    // 0x66f020: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66f020: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ updateGestureRecognizers(/* No info */) {
    // ** addr: 0x6d497c, size: 0x74
    // 0x6d497c: EnterFrame
    //     0x6d497c: stp             fp, lr, [SP, #-0x10]!
    //     0x6d4980: mov             fp, SP
    // 0x6d4984: AllocStack(0x8)
    //     0x6d4984: sub             SP, SP, #8
    // 0x6d4988: CheckStackOverflow
    //     0x6d4988: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d498c: cmp             SP, x16
    //     0x6d4990: b.ls            #0x6d49e8
    // 0x6d4994: ldr             x0, [fp, #0x10]
    // 0x6d4998: LoadField: r1 = r0->field_6b
    //     0x6d4998: ldur            w1, [x0, #0x6b]
    // 0x6d499c: DecompressPointer r1
    //     0x6d499c: add             x1, x1, HEAP, lsl #32
    // 0x6d49a0: stur            x1, [fp, #-8]
    // 0x6d49a4: r1 = 1
    //     0x6d49a4: mov             x1, #1
    // 0x6d49a8: r0 = AllocateContext()
    //     0x6d49a8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6d49ac: mov             x1, x0
    // 0x6d49b0: ldur            x0, [fp, #-8]
    // 0x6d49b4: StoreField: r1->field_f = r0
    //     0x6d49b4: stur            w0, [x1, #0xf]
    // 0x6d49b8: mov             x2, x1
    // 0x6d49bc: r1 = Function 'dispatchPointerEvent':.
    //     0x6d49bc: add             x1, PP, #0x49, lsl #12  ; [pp+0x499e8] AnonymousClosure: (0x6d4fb4), in [package:flutter/src/services/platform_views.dart] AndroidViewController::dispatchPointerEvent (0x6d5000)
    //     0x6d49c0: ldr             x1, [x1, #0x9e8]
    // 0x6d49c4: r0 = AllocateClosure()
    //     0x6d49c4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6d49c8: ldr             x16, [fp, #0x10]
    // 0x6d49cc: stp             x0, x16, [SP, #-0x10]!
    // 0x6d49d0: r0 = _updateGestureRecognizersWithCallBack()
    //     0x6d49d0: bl              #0x6d49f0  ; [package:flutter/src/rendering/platform_view.dart] _PlatformViewRenderBox&RenderBox&_PlatformViewGestureMixin::_updateGestureRecognizersWithCallBack
    // 0x6d49d4: add             SP, SP, #0x10
    // 0x6d49d8: r0 = Null
    //     0x6d49d8: mov             x0, NULL
    // 0x6d49dc: LeaveFrame
    //     0x6d49dc: mov             SP, fp
    //     0x6d49e0: ldp             fp, lr, [SP], #0x10
    // 0x6d49e4: ret
    //     0x6d49e4: ret             
    // 0x6d49e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d49e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d49ec: b               #0x6d4994
  }
  _ PlatformViewRenderBox(/* No info */) {
    // ** addr: 0x6f0c08, size: 0x84
    // 0x6f0c08: EnterFrame
    //     0x6f0c08: stp             fp, lr, [SP, #-0x10]!
    //     0x6f0c0c: mov             fp, SP
    // 0x6f0c10: CheckStackOverflow
    //     0x6f0c10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f0c14: cmp             SP, x16
    //     0x6f0c18: b.ls            #0x6f0c84
    // 0x6f0c1c: ldr             x0, [fp, #0x10]
    // 0x6f0c20: ldr             x1, [fp, #0x18]
    // 0x6f0c24: StoreField: r1->field_6b = r0
    //     0x6f0c24: stur            w0, [x1, #0x6b]
    //     0x6f0c28: ldurb           w16, [x1, #-1]
    //     0x6f0c2c: ldurb           w17, [x0, #-1]
    //     0x6f0c30: and             x16, x17, x16, lsr #2
    //     0x6f0c34: tst             x16, HEAP, lsr #32
    //     0x6f0c38: b.eq            #0x6f0c40
    //     0x6f0c3c: bl              #0xd6826c
    // 0x6f0c40: SaveReg r1
    //     0x6f0c40: str             x1, [SP, #-8]!
    // 0x6f0c44: r0 = RenderObject()
    //     0x6f0c44: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6f0c48: add             SP, SP, #8
    // 0x6f0c4c: ldr             x16, [fp, #0x18]
    // 0x6f0c50: r30 = Instance_PlatformViewHitTestBehavior
    //     0x6f0c50: add             lr, PP, #0x2a, lsl #12  ; [pp+0x2a378] Obj!PlatformViewHitTestBehavior@b649d1
    //     0x6f0c54: ldr             lr, [lr, #0x378]
    // 0x6f0c58: stp             lr, x16, [SP, #-0x10]!
    // 0x6f0c5c: r0 = hitTestBehavior=()
    //     0x6f0c5c: bl              #0x6d68ac  ; [package:flutter/src/rendering/platform_view.dart] _PlatformViewRenderBox&RenderBox&_PlatformViewGestureMixin::hitTestBehavior=
    // 0x6f0c60: add             SP, SP, #0x10
    // 0x6f0c64: ldr             x16, [fp, #0x18]
    // 0x6f0c68: SaveReg r16
    //     0x6f0c68: str             x16, [SP, #-8]!
    // 0x6f0c6c: r0 = updateGestureRecognizers()
    //     0x6f0c6c: bl              #0x6d497c  ; [package:flutter/src/rendering/platform_view.dart] PlatformViewRenderBox::updateGestureRecognizers
    // 0x6f0c70: add             SP, SP, #8
    // 0x6f0c74: r0 = Null
    //     0x6f0c74: mov             x0, NULL
    // 0x6f0c78: LeaveFrame
    //     0x6f0c78: mov             SP, fp
    //     0x6f0c7c: ldp             fp, lr, [SP], #0x10
    // 0x6f0c80: ret
    //     0x6f0c80: ret             
    // 0x6f0c84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f0c84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f0c88: b               #0x6f0c1c
  }
  set _ controller=(/* No info */) {
    // ** addr: 0xcf0a50, size: 0xb4
    // 0xcf0a50: EnterFrame
    //     0xcf0a50: stp             fp, lr, [SP, #-0x10]!
    //     0xcf0a54: mov             fp, SP
    // 0xcf0a58: AllocStack(0x10)
    //     0xcf0a58: sub             SP, SP, #0x10
    // 0xcf0a5c: CheckStackOverflow
    //     0xcf0a5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf0a60: cmp             SP, x16
    //     0xcf0a64: b.ls            #0xcf0afc
    // 0xcf0a68: ldr             x1, [fp, #0x18]
    // 0xcf0a6c: LoadField: r0 = r1->field_6b
    //     0xcf0a6c: ldur            w0, [x1, #0x6b]
    // 0xcf0a70: DecompressPointer r0
    //     0xcf0a70: add             x0, x0, HEAP, lsl #32
    // 0xcf0a74: ldr             x2, [fp, #0x10]
    // 0xcf0a78: cmp             w0, w2
    // 0xcf0a7c: b.ne            #0xcf0a90
    // 0xcf0a80: r0 = Null
    //     0xcf0a80: mov             x0, NULL
    // 0xcf0a84: LeaveFrame
    //     0xcf0a84: mov             SP, fp
    //     0xcf0a88: ldp             fp, lr, [SP], #0x10
    // 0xcf0a8c: ret
    //     0xcf0a8c: ret             
    // 0xcf0a90: LoadField: r3 = r0->field_7
    //     0xcf0a90: ldur            x3, [x0, #7]
    // 0xcf0a94: stur            x3, [fp, #-0x10]
    // 0xcf0a98: LoadField: r4 = r2->field_7
    //     0xcf0a98: ldur            x4, [x2, #7]
    // 0xcf0a9c: mov             x0, x2
    // 0xcf0aa0: stur            x4, [fp, #-8]
    // 0xcf0aa4: StoreField: r1->field_6b = r0
    //     0xcf0aa4: stur            w0, [x1, #0x6b]
    //     0xcf0aa8: ldurb           w16, [x1, #-1]
    //     0xcf0aac: ldurb           w17, [x0, #-1]
    //     0xcf0ab0: and             x16, x17, x16, lsr #2
    //     0xcf0ab4: tst             x16, HEAP, lsr #32
    //     0xcf0ab8: b.eq            #0xcf0ac0
    //     0xcf0abc: bl              #0xd6826c
    // 0xcf0ac0: SaveReg r1
    //     0xcf0ac0: str             x1, [SP, #-8]!
    // 0xcf0ac4: r0 = markNeedsPaint()
    //     0xcf0ac4: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf0ac8: add             SP, SP, #8
    // 0xcf0acc: ldur            x0, [fp, #-0x10]
    // 0xcf0ad0: ldur            x1, [fp, #-8]
    // 0xcf0ad4: cmp             x0, x1
    // 0xcf0ad8: b.eq            #0xcf0aec
    // 0xcf0adc: ldr             x16, [fp, #0x18]
    // 0xcf0ae0: SaveReg r16
    //     0xcf0ae0: str             x16, [SP, #-8]!
    // 0xcf0ae4: r0 = markNeedsSemanticsUpdate()
    //     0xcf0ae4: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcf0ae8: add             SP, SP, #8
    // 0xcf0aec: r0 = Null
    //     0xcf0aec: mov             x0, NULL
    // 0xcf0af0: LeaveFrame
    //     0xcf0af0: mov             SP, fp
    //     0xcf0af4: ldp             fp, lr, [SP], #0x10
    // 0xcf0af8: ret
    //     0xcf0af8: ret             
    // 0xcf0afc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0afc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf0b00: b               #0xcf0a68
  }
}

// class id: 2432, size: 0x88, field offset: 0x70
class RenderAndroidView extends PlatformViewRenderBox {

  _ performResize(/* No info */) {
    // ** addr: 0x640eb0, size: 0x4c
    // 0x640eb0: EnterFrame
    //     0x640eb0: stp             fp, lr, [SP, #-0x10]!
    //     0x640eb4: mov             fp, SP
    // 0x640eb8: CheckStackOverflow
    //     0x640eb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x640ebc: cmp             SP, x16
    //     0x640ec0: b.ls            #0x640ef4
    // 0x640ec4: ldr             x16, [fp, #0x10]
    // 0x640ec8: SaveReg r16
    //     0x640ec8: str             x16, [SP, #-8]!
    // 0x640ecc: r0 = performResize()
    //     0x640ecc: bl              #0x641464  ; [package:flutter/src/rendering/box.dart] RenderBox::performResize
    // 0x640ed0: add             SP, SP, #8
    // 0x640ed4: ldr             x16, [fp, #0x10]
    // 0x640ed8: SaveReg r16
    //     0x640ed8: str             x16, [SP, #-8]!
    // 0x640edc: r0 = _sizePlatformView()
    //     0x640edc: bl              #0x640efc  ; [package:flutter/src/rendering/platform_view.dart] RenderAndroidView::_sizePlatformView
    // 0x640ee0: add             SP, SP, #8
    // 0x640ee4: r0 = Null
    //     0x640ee4: mov             x0, NULL
    // 0x640ee8: LeaveFrame
    //     0x640ee8: mov             SP, fp
    //     0x640eec: ldp             fp, lr, [SP], #0x10
    // 0x640ef0: ret
    //     0x640ef0: ret             
    // 0x640ef4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x640ef4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x640ef8: b               #0x640ec4
  }
  _ _sizePlatformView(/* No info */) async {
    // ** addr: 0x640efc, size: 0x1b0
    // 0x640efc: EnterFrame
    //     0x640efc: stp             fp, lr, [SP, #-0x10]!
    //     0x640f00: mov             fp, SP
    // 0x640f04: AllocStack(0x20)
    //     0x640f04: sub             SP, SP, #0x20
    // 0x640f08: SetupParameters(RenderAndroidView this /* r1, fp-0x10 */)
    //     0x640f08: stur            NULL, [fp, #-8]
    //     0x640f0c: mov             x0, #0
    //     0x640f10: add             x1, fp, w0, sxtw #2
    //     0x640f14: ldr             x1, [x1, #0x10]
    //     0x640f18: stur            x1, [fp, #-0x10]
    // 0x640f1c: CheckStackOverflow
    //     0x640f1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x640f20: cmp             SP, x16
    //     0x640f24: b.ls            #0x641090
    // 0x640f28: InitAsync() -> Future<void?>
    //     0x640f28: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x640f2c: bl              #0x4b92e4
    // 0x640f30: ldur            x0, [fp, #-0x10]
    // 0x640f34: LoadField: r1 = r0->field_6f
    //     0x640f34: ldur            w1, [x0, #0x6f]
    // 0x640f38: DecompressPointer r1
    //     0x640f38: add             x1, x1, HEAP, lsl #32
    // 0x640f3c: r16 = Instance__PlatformViewState
    //     0x640f3c: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4fe48] Obj!_PlatformViewState@b64971
    //     0x640f40: ldr             x16, [x16, #0xe48]
    // 0x640f44: cmp             w1, w16
    // 0x640f48: b.eq            #0x640f80
    // 0x640f4c: d0 = 0.000000
    //     0x640f4c: eor             v0.16b, v0.16b, v0.16b
    // 0x640f50: LoadField: r1 = r0->field_57
    //     0x640f50: ldur            w1, [x0, #0x57]
    // 0x640f54: DecompressPointer r1
    //     0x640f54: add             x1, x1, HEAP, lsl #32
    // 0x640f58: cmp             w1, NULL
    // 0x640f5c: b.eq            #0x641098
    // 0x640f60: LoadField: d1 = r1->field_7
    //     0x640f60: ldur            d1, [x1, #7]
    // 0x640f64: fcmp            d1, d0
    // 0x640f68: b.vs            #0x640f70
    // 0x640f6c: b.le            #0x640f80
    // 0x640f70: LoadField: d1 = r1->field_f
    //     0x640f70: ldur            d1, [x1, #0xf]
    // 0x640f74: fcmp            d1, d0
    // 0x640f78: b.vs            #0x640f88
    // 0x640f7c: b.gt            #0x640f88
    // 0x640f80: r0 = Null
    //     0x640f80: mov             x0, NULL
    // 0x640f84: r0 = ReturnAsyncNotFuture()
    //     0x640f84: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x640f88: r1 = Instance__PlatformViewState
    //     0x640f88: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4fe48] Obj!_PlatformViewState@b64971
    //     0x640f8c: ldr             x1, [x1, #0xe48]
    // 0x640f90: StoreField: r0->field_6f = r1
    //     0x640f90: stur            w1, [x0, #0x6f]
    // 0x640f94: SaveReg r0
    //     0x640f94: str             x0, [SP, #-8]!
    // 0x640f98: r0 = markNeedsPaint()
    //     0x640f98: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x640f9c: add             SP, SP, #8
    // 0x640fa0: ldur            x0, [fp, #-0x10]
    // 0x640fa4: CheckStackOverflow
    //     0x640fa4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x640fa8: cmp             SP, x16
    //     0x640fac: b.ls            #0x64109c
    // 0x640fb0: LoadField: r1 = r0->field_57
    //     0x640fb0: ldur            w1, [x0, #0x57]
    // 0x640fb4: DecompressPointer r1
    //     0x640fb4: add             x1, x1, HEAP, lsl #32
    // 0x640fb8: stur            x1, [fp, #-0x18]
    // 0x640fbc: cmp             w1, NULL
    // 0x640fc0: b.eq            #0x6410a4
    // 0x640fc4: LoadField: r2 = r0->field_7b
    //     0x640fc4: ldur            w2, [x0, #0x7b]
    // 0x640fc8: DecompressPointer r2
    //     0x640fc8: add             x2, x2, HEAP, lsl #32
    // 0x640fcc: stp             x1, x2, [SP, #-0x10]!
    // 0x640fd0: r0 = setSize()
    //     0x640fd0: bl              #0x6410ac  ; [package:flutter/src/services/platform_views.dart] AndroidViewController::setSize
    // 0x640fd4: add             SP, SP, #0x10
    // 0x640fd8: mov             x1, x0
    // 0x640fdc: stur            x1, [fp, #-0x20]
    // 0x640fe0: r0 = Await()
    //     0x640fe0: bl              #0x4b8e6c  ; AwaitStub
    // 0x640fe4: ldur            x1, [fp, #-0x10]
    // 0x640fe8: StoreField: r1->field_73 = r0
    //     0x640fe8: stur            w0, [x1, #0x73]
    //     0x640fec: tbz             w0, #0, #0x641008
    //     0x640ff0: ldurb           w16, [x1, #-1]
    //     0x640ff4: ldurb           w17, [x0, #-1]
    //     0x640ff8: and             x16, x17, x16, lsr #2
    //     0x640ffc: tst             x16, HEAP, lsr #32
    //     0x641000: b.eq            #0x641008
    //     0x641004: bl              #0xd6826c
    // 0x641008: LoadField: r0 = r1->field_77
    //     0x641008: ldur            w0, [x1, #0x77]
    // 0x64100c: DecompressPointer r0
    //     0x64100c: add             x0, x0, HEAP, lsl #32
    // 0x641010: tbnz            w0, #4, #0x64101c
    // 0x641014: r0 = Null
    //     0x641014: mov             x0, NULL
    // 0x641018: r0 = ReturnAsyncNotFuture()
    //     0x641018: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x64101c: ldur            x0, [fp, #-0x18]
    // 0x641020: LoadField: r2 = r1->field_57
    //     0x641020: ldur            w2, [x1, #0x57]
    // 0x641024: DecompressPointer r2
    //     0x641024: add             x2, x2, HEAP, lsl #32
    // 0x641028: cmp             w2, NULL
    // 0x64102c: b.eq            #0x6410a8
    // 0x641030: LoadField: d0 = r0->field_7
    //     0x641030: ldur            d0, [x0, #7]
    // 0x641034: LoadField: d1 = r2->field_7
    //     0x641034: ldur            d1, [x2, #7]
    // 0x641038: fcmp            d0, d1
    // 0x64103c: b.vs            #0x641080
    // 0x641040: b.ne            #0x641080
    // 0x641044: LoadField: d0 = r0->field_f
    //     0x641044: ldur            d0, [x0, #0xf]
    // 0x641048: LoadField: d1 = r2->field_f
    //     0x641048: ldur            d1, [x2, #0xf]
    // 0x64104c: fcmp            d0, d1
    // 0x641050: b.eq            #0x641060
    // 0x641054: r0 = Instance__PlatformViewState
    //     0x641054: add             x0, PP, #0x4f, lsl #12  ; [pp+0x4fe50] Obj!_PlatformViewState@b64951
    //     0x641058: ldr             x0, [x0, #0xe50]
    // 0x64105c: b               #0x641088
    // 0x641060: r0 = Instance__PlatformViewState
    //     0x641060: add             x0, PP, #0x4f, lsl #12  ; [pp+0x4fe50] Obj!_PlatformViewState@b64951
    //     0x641064: ldr             x0, [x0, #0xe50]
    // 0x641068: StoreField: r1->field_6f = r0
    //     0x641068: stur            w0, [x1, #0x6f]
    // 0x64106c: SaveReg r1
    //     0x64106c: str             x1, [SP, #-8]!
    // 0x641070: r0 = markNeedsPaint()
    //     0x641070: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x641074: add             SP, SP, #8
    // 0x641078: r0 = Null
    //     0x641078: mov             x0, NULL
    // 0x64107c: r0 = ReturnAsyncNotFuture()
    //     0x64107c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x641080: r0 = Instance__PlatformViewState
    //     0x641080: add             x0, PP, #0x4f, lsl #12  ; [pp+0x4fe50] Obj!_PlatformViewState@b64951
    //     0x641084: ldr             x0, [x0, #0xe50]
    // 0x641088: mov             x0, x1
    // 0x64108c: b               #0x640fa4
    // 0x641090: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x641090: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x641094: b               #0x640f28
    // 0x641098: r0 = NullCastErrorSharedWithFPURegs()
    //     0x641098: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x64109c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64109c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6410a0: b               #0x640fb0
    // 0x6410a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6410a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6410a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6410a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0x6515c4, size: 0xcc
    // 0x6515c4: EnterFrame
    //     0x6515c4: stp             fp, lr, [SP, #-0x10]!
    //     0x6515c8: mov             fp, SP
    // 0x6515cc: r2 = true
    //     0x6515cc: add             x2, NULL, #0x20  ; true
    // 0x6515d0: ldr             x3, [fp, #0x10]
    // 0x6515d4: StoreField: r3->field_7 = r2
    //     0x6515d4: stur            w2, [x3, #7]
    // 0x6515d8: ldr             x4, [fp, #0x18]
    // 0x6515dc: LoadField: r5 = r4->field_7b
    //     0x6515dc: ldur            w5, [x4, #0x7b]
    // 0x6515e0: DecompressPointer r5
    //     0x6515e0: add             x5, x5, HEAP, lsl #32
    // 0x6515e4: LoadField: r4 = r5->field_1b
    //     0x6515e4: ldur            w4, [x5, #0x1b]
    // 0x6515e8: DecompressPointer r4
    //     0x6515e8: add             x4, x4, HEAP, lsl #32
    // 0x6515ec: r16 = Instance__AndroidViewState
    //     0x6515ec: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2a3d0] Obj!_AndroidViewState@b644d1
    //     0x6515f0: ldr             x16, [x16, #0x3d0]
    // 0x6515f4: cmp             w4, w16
    // 0x6515f8: b.ne            #0x651680
    // 0x6515fc: LoadField: r4 = r5->field_7
    //     0x6515fc: ldur            x4, [x5, #7]
    // 0x651600: LoadField: r5 = r3->field_33
    //     0x651600: ldur            w5, [x3, #0x33]
    // 0x651604: DecompressPointer r5
    //     0x651604: add             x5, x5, HEAP, lsl #32
    // 0x651608: r0 = BoxInt64Instr(r4)
    //     0x651608: sbfiz           x0, x4, #1, #0x1f
    //     0x65160c: cmp             x4, x0, asr #1
    //     0x651610: b.eq            #0x65161c
    //     0x651614: bl              #0xd69bb8
    //     0x651618: stur            x4, [x0, #7]
    // 0x65161c: cmp             w0, w5
    // 0x651620: b.eq            #0x651680
    // 0x651624: and             w16, w0, w5
    // 0x651628: branchIfSmi(r16, 0x65165c)
    //     0x651628: tbz             w16, #0, #0x65165c
    // 0x65162c: r16 = LoadClassIdInstr(r0)
    //     0x65162c: ldur            x16, [x0, #-1]
    //     0x651630: ubfx            x16, x16, #0xc, #0x14
    // 0x651634: cmp             x16, #0x3c
    // 0x651638: b.ne            #0x65165c
    // 0x65163c: r16 = LoadClassIdInstr(r5)
    //     0x65163c: ldur            x16, [x5, #-1]
    //     0x651640: ubfx            x16, x16, #0xc, #0x14
    // 0x651644: cmp             x16, #0x3c
    // 0x651648: b.ne            #0x65165c
    // 0x65164c: LoadField: r16 = r0->field_7
    //     0x65164c: ldur            x16, [x0, #7]
    // 0x651650: LoadField: r17 = r5->field_7
    //     0x651650: ldur            x17, [x5, #7]
    // 0x651654: cmp             x16, x17
    // 0x651658: b.eq            #0x651680
    // 0x65165c: StoreField: r3->field_33 = r0
    //     0x65165c: stur            w0, [x3, #0x33]
    //     0x651660: tbz             w0, #0, #0x65167c
    //     0x651664: ldurb           w16, [x3, #-1]
    //     0x651668: ldurb           w17, [x0, #-1]
    //     0x65166c: and             x16, x17, x16, lsr #2
    //     0x651670: tst             x16, HEAP, lsr #32
    //     0x651674: b.eq            #0x65167c
    //     0x651678: bl              #0xd682ac
    // 0x65167c: StoreField: r3->field_13 = r2
    //     0x65167c: stur            w2, [x3, #0x13]
    // 0x651680: r0 = Null
    //     0x651680: mov             x0, NULL
    // 0x651684: LeaveFrame
    //     0x651684: mov             SP, fp
    //     0x651688: ldp             fp, lr, [SP], #0x10
    // 0x65168c: ret
    //     0x65168c: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x653400, size: 0xa4
    // 0x653400: EnterFrame
    //     0x653400: stp             fp, lr, [SP, #-0x10]!
    //     0x653404: mov             fp, SP
    // 0x653408: AllocStack(0x8)
    //     0x653408: sub             SP, SP, #8
    // 0x65340c: r0 = true
    //     0x65340c: add             x0, NULL, #0x20  ; true
    // 0x653410: CheckStackOverflow
    //     0x653410: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x653414: cmp             SP, x16
    //     0x653418: b.ls            #0x65349c
    // 0x65341c: ldr             x1, [fp, #0x10]
    // 0x653420: StoreField: r1->field_77 = r0
    //     0x653420: stur            w0, [x1, #0x77]
    // 0x653424: LoadField: r0 = r1->field_83
    //     0x653424: ldur            w0, [x1, #0x83]
    // 0x653428: DecompressPointer r0
    //     0x653428: add             x0, x0, HEAP, lsl #32
    // 0x65342c: stp             NULL, x0, [SP, #-0x10]!
    // 0x653430: r0 = layer=()
    //     0x653430: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x653434: add             SP, SP, #0x10
    // 0x653438: ldr             x0, [fp, #0x10]
    // 0x65343c: LoadField: r1 = r0->field_7b
    //     0x65343c: ldur            w1, [x0, #0x7b]
    // 0x653440: DecompressPointer r1
    //     0x653440: add             x1, x1, HEAP, lsl #32
    // 0x653444: stur            x1, [fp, #-8]
    // 0x653448: r1 = 1
    //     0x653448: mov             x1, #1
    // 0x65344c: r0 = AllocateContext()
    //     0x65344c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x653450: mov             x1, x0
    // 0x653454: ldr             x0, [fp, #0x10]
    // 0x653458: StoreField: r1->field_f = r0
    //     0x653458: stur            w0, [x1, #0xf]
    // 0x65345c: mov             x2, x1
    // 0x653460: r1 = Function '_onPlatformViewCreated@906508051':.
    //     0x653460: add             x1, PP, #0x49, lsl #12  ; [pp+0x499a0] AnonymousClosure: (0x6534ec), of [package:flutter/src/rendering/platform_view.dart] RenderAndroidView
    //     0x653464: ldr             x1, [x1, #0x9a0]
    // 0x653468: r0 = AllocateClosure()
    //     0x653468: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x65346c: ldur            x16, [fp, #-8]
    // 0x653470: stp             x0, x16, [SP, #-0x10]!
    // 0x653474: r0 = removeOnPlatformViewCreatedListener()
    //     0x653474: bl              #0x6534a4  ; [package:flutter/src/services/platform_views.dart] AndroidViewController::removeOnPlatformViewCreatedListener
    // 0x653478: add             SP, SP, #0x10
    // 0x65347c: ldr             x16, [fp, #0x10]
    // 0x653480: SaveReg r16
    //     0x653480: str             x16, [SP, #-8]!
    // 0x653484: r0 = dispose()
    //     0x653484: bl              #0x65378c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0x653488: add             SP, SP, #8
    // 0x65348c: r0 = Null
    //     0x65348c: mov             x0, NULL
    // 0x653490: LeaveFrame
    //     0x653490: mov             SP, fp
    //     0x653494: ldp             fp, lr, [SP], #0x10
    // 0x653498: ret
    //     0x653498: ret             
    // 0x65349c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65349c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6534a0: b               #0x65341c
  }
  [closure] void _onPlatformViewCreated(dynamic, int) {
    // ** addr: 0x6534ec, size: 0x4c
    // 0x6534ec: EnterFrame
    //     0x6534ec: stp             fp, lr, [SP, #-0x10]!
    //     0x6534f0: mov             fp, SP
    // 0x6534f4: ldr             x0, [fp, #0x18]
    // 0x6534f8: LoadField: r1 = r0->field_17
    //     0x6534f8: ldur            w1, [x0, #0x17]
    // 0x6534fc: DecompressPointer r1
    //     0x6534fc: add             x1, x1, HEAP, lsl #32
    // 0x653500: CheckStackOverflow
    //     0x653500: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x653504: cmp             SP, x16
    //     0x653508: b.ls            #0x653530
    // 0x65350c: LoadField: r0 = r1->field_f
    //     0x65350c: ldur            w0, [x1, #0xf]
    // 0x653510: DecompressPointer r0
    //     0x653510: add             x0, x0, HEAP, lsl #32
    // 0x653514: SaveReg r0
    //     0x653514: str             x0, [SP, #-8]!
    // 0x653518: r0 = markNeedsSemanticsUpdate()
    //     0x653518: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x65351c: add             SP, SP, #8
    // 0x653520: r0 = Null
    //     0x653520: mov             x0, NULL
    // 0x653524: LeaveFrame
    //     0x653524: mov             SP, fp
    //     0x653528: ldp             fp, lr, [SP], #0x10
    // 0x65352c: ret
    //     0x65352c: ret             
    // 0x653530: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x653530: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x653534: b               #0x65350c
  }
  _ paint(/* No info */) {
    // ** addr: 0x66eb70, size: 0x1f0
    // 0x66eb70: EnterFrame
    //     0x66eb70: stp             fp, lr, [SP, #-0x10]!
    //     0x66eb74: mov             fp, SP
    // 0x66eb78: AllocStack(0x18)
    //     0x66eb78: sub             SP, SP, #0x18
    // 0x66eb7c: CheckStackOverflow
    //     0x66eb7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66eb80: cmp             SP, x16
    //     0x66eb84: b.ls            #0x66ed54
    // 0x66eb88: ldr             x0, [fp, #0x20]
    // 0x66eb8c: LoadField: r1 = r0->field_7b
    //     0x66eb8c: ldur            w1, [x0, #0x7b]
    // 0x66eb90: DecompressPointer r1
    //     0x66eb90: add             x1, x1, HEAP, lsl #32
    // 0x66eb94: r2 = LoadClassIdInstr(r1)
    //     0x66eb94: ldur            x2, [x1, #-1]
    //     0x66eb98: ubfx            x2, x2, #0xc, #0x14
    // 0x66eb9c: lsl             x2, x2, #1
    // 0x66eba0: cmp             w2, #0xed6
    // 0x66eba4: b.eq            #0x66ed1c
    // 0x66eba8: r2 = "Not supported for hybrid composition."
    //     0x66eba8: add             x2, PP, #0x49, lsl #12  ; [pp+0x499d0] "Not supported for hybrid composition."
    //     0x66ebac: ldr             x2, [x2, #0x9d0]
    // 0x66ebb0: LoadField: r3 = r1->field_27
    //     0x66ebb0: ldur            w3, [x1, #0x27]
    // 0x66ebb4: DecompressPointer r3
    //     0x66ebb4: add             x3, x3, HEAP, lsl #32
    // 0x66ebb8: r1 = LoadClassIdInstr(r3)
    //     0x66ebb8: ldur            x1, [x3, #-1]
    //     0x66ebbc: ubfx            x1, x1, #0xc, #0x14
    // 0x66ebc0: lsl             x1, x1, #1
    // 0x66ebc4: cmp             w1, #0xece
    // 0x66ebc8: b.eq            #0x66ed34
    // 0x66ebcc: LoadField: r1 = r3->field_b
    //     0x66ebcc: ldur            w1, [x3, #0xb]
    // 0x66ebd0: DecompressPointer r1
    //     0x66ebd0: add             x1, x1, HEAP, lsl #32
    // 0x66ebd4: cmp             w1, NULL
    // 0x66ebd8: b.eq            #0x66ebec
    // 0x66ebdc: LoadField: r1 = r0->field_73
    //     0x66ebdc: ldur            w1, [x0, #0x73]
    // 0x66ebe0: DecompressPointer r1
    //     0x66ebe0: add             x1, x1, HEAP, lsl #32
    // 0x66ebe4: cmp             w1, NULL
    // 0x66ebe8: b.ne            #0x66ebfc
    // 0x66ebec: r0 = Null
    //     0x66ebec: mov             x0, NULL
    // 0x66ebf0: LeaveFrame
    //     0x66ebf0: mov             SP, fp
    //     0x66ebf4: ldp             fp, lr, [SP], #0x10
    // 0x66ebf8: ret
    //     0x66ebf8: ret             
    // 0x66ebfc: LoadField: d0 = r1->field_7
    //     0x66ebfc: ldur            d0, [x1, #7]
    // 0x66ec00: LoadField: r2 = r0->field_57
    //     0x66ec00: ldur            w2, [x0, #0x57]
    // 0x66ec04: DecompressPointer r2
    //     0x66ec04: add             x2, x2, HEAP, lsl #32
    // 0x66ec08: cmp             w2, NULL
    // 0x66ec0c: b.eq            #0x66ed5c
    // 0x66ec10: LoadField: d1 = r2->field_7
    //     0x66ec10: ldur            d1, [x2, #7]
    // 0x66ec14: fcmp            d0, d1
    // 0x66ec18: b.vs            #0x66ec20
    // 0x66ec1c: b.gt            #0x66ec34
    // 0x66ec20: LoadField: d0 = r1->field_f
    //     0x66ec20: ldur            d0, [x1, #0xf]
    // 0x66ec24: LoadField: d1 = r2->field_f
    //     0x66ec24: ldur            d1, [x2, #0xf]
    // 0x66ec28: fcmp            d0, d1
    // 0x66ec2c: b.vs            #0x66ecdc
    // 0x66ec30: b.le            #0x66ecdc
    // 0x66ec34: LoadField: r1 = r0->field_83
    //     0x66ec34: ldur            w1, [x0, #0x83]
    // 0x66ec38: DecompressPointer r1
    //     0x66ec38: add             x1, x1, HEAP, lsl #32
    // 0x66ec3c: stur            x1, [fp, #-8]
    // 0x66ec40: ldr             x16, [fp, #0x10]
    // 0x66ec44: stp             x2, x16, [SP, #-0x10]!
    // 0x66ec48: r0 = &()
    //     0x66ec48: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x66ec4c: add             SP, SP, #0x10
    // 0x66ec50: stur            x0, [fp, #-0x10]
    // 0x66ec54: r1 = 1
    //     0x66ec54: mov             x1, #1
    // 0x66ec58: r0 = AllocateContext()
    //     0x66ec58: bl              #0xd68aa4  ; AllocateContextStub
    // 0x66ec5c: mov             x1, x0
    // 0x66ec60: ldr             x0, [fp, #0x20]
    // 0x66ec64: StoreField: r1->field_f = r0
    //     0x66ec64: stur            w0, [x1, #0xf]
    // 0x66ec68: ldur            x0, [fp, #-8]
    // 0x66ec6c: LoadField: r3 = r0->field_b
    //     0x66ec6c: ldur            w3, [x0, #0xb]
    // 0x66ec70: DecompressPointer r3
    //     0x66ec70: add             x3, x3, HEAP, lsl #32
    // 0x66ec74: mov             x2, x1
    // 0x66ec78: stur            x3, [fp, #-0x18]
    // 0x66ec7c: r1 = Function '_paintTexture@906508051':.
    //     0x66ec7c: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4fe40] AnonymousClosure: (0x66ef20), in [package:flutter/src/rendering/platform_view.dart] RenderAndroidView::_paintTexture (0x66ed60)
    //     0x66ec80: ldr             x1, [x1, #0xe40]
    // 0x66ec84: r0 = AllocateClosure()
    //     0x66ec84: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x66ec88: ldr             x16, [fp, #0x18]
    // 0x66ec8c: r30 = true
    //     0x66ec8c: add             lr, NULL, #0x20  ; true
    // 0x66ec90: stp             lr, x16, [SP, #-0x10]!
    // 0x66ec94: ldr             x16, [fp, #0x10]
    // 0x66ec98: ldur            lr, [fp, #-0x10]
    // 0x66ec9c: stp             lr, x16, [SP, #-0x10]!
    // 0x66eca0: r16 = Instance_Clip
    //     0x66eca0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x66eca4: ldr             x16, [x16, #0x678]
    // 0x66eca8: stp             x16, x0, [SP, #-0x10]!
    // 0x66ecac: ldur            x16, [fp, #-0x18]
    // 0x66ecb0: SaveReg r16
    //     0x66ecb0: str             x16, [SP, #-8]!
    // 0x66ecb4: r0 = pushClipRect()
    //     0x66ecb4: bl              #0x65b240  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRect
    // 0x66ecb8: add             SP, SP, #0x38
    // 0x66ecbc: ldur            x16, [fp, #-8]
    // 0x66ecc0: stp             x0, x16, [SP, #-0x10]!
    // 0x66ecc4: r0 = layer=()
    //     0x66ecc4: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x66ecc8: add             SP, SP, #0x10
    // 0x66eccc: r0 = Null
    //     0x66eccc: mov             x0, NULL
    // 0x66ecd0: LeaveFrame
    //     0x66ecd0: mov             SP, fp
    //     0x66ecd4: ldp             fp, lr, [SP], #0x10
    // 0x66ecd8: ret
    //     0x66ecd8: ret             
    // 0x66ecdc: LoadField: r1 = r0->field_83
    //     0x66ecdc: ldur            w1, [x0, #0x83]
    // 0x66ece0: DecompressPointer r1
    //     0x66ece0: add             x1, x1, HEAP, lsl #32
    // 0x66ece4: stp             NULL, x1, [SP, #-0x10]!
    // 0x66ece8: r0 = layer=()
    //     0x66ece8: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x66ecec: add             SP, SP, #0x10
    // 0x66ecf0: ldr             x16, [fp, #0x20]
    // 0x66ecf4: ldr             lr, [fp, #0x18]
    // 0x66ecf8: stp             lr, x16, [SP, #-0x10]!
    // 0x66ecfc: ldr             x16, [fp, #0x10]
    // 0x66ed00: SaveReg r16
    //     0x66ed00: str             x16, [SP, #-8]!
    // 0x66ed04: r0 = _paintTexture()
    //     0x66ed04: bl              #0x66ed60  ; [package:flutter/src/rendering/platform_view.dart] RenderAndroidView::_paintTexture
    // 0x66ed08: add             SP, SP, #0x18
    // 0x66ed0c: r0 = Null
    //     0x66ed0c: mov             x0, NULL
    // 0x66ed10: LeaveFrame
    //     0x66ed10: mov             SP, fp
    //     0x66ed14: ldp             fp, lr, [SP], #0x10
    // 0x66ed18: ret
    //     0x66ed18: ret             
    // 0x66ed1c: r0 = UnimplementedError()
    //     0x66ed1c: bl              #0x4c1104  ; AllocateUnimplementedErrorStub -> UnimplementedError (size=0x10)
    // 0x66ed20: r2 = "Not supported for hybrid composition."
    //     0x66ed20: add             x2, PP, #0x49, lsl #12  ; [pp+0x499d0] "Not supported for hybrid composition."
    //     0x66ed24: ldr             x2, [x2, #0x9d0]
    // 0x66ed28: StoreField: r0->field_b = r2
    //     0x66ed28: stur            w2, [x0, #0xb]
    // 0x66ed2c: r0 = Throw()
    //     0x66ed2c: bl              #0xd67e38  ; ThrowStub
    // 0x66ed30: brk             #0
    // 0x66ed34: r0 = UnimplementedError()
    //     0x66ed34: bl              #0x4c1104  ; AllocateUnimplementedErrorStub -> UnimplementedError (size=0x10)
    // 0x66ed38: mov             x1, x0
    // 0x66ed3c: r0 = "Not supported for hybrid composition."
    //     0x66ed3c: add             x0, PP, #0x49, lsl #12  ; [pp+0x499d0] "Not supported for hybrid composition."
    //     0x66ed40: ldr             x0, [x0, #0x9d0]
    // 0x66ed44: StoreField: r1->field_b = r0
    //     0x66ed44: stur            w0, [x1, #0xb]
    // 0x66ed48: mov             x0, x1
    // 0x66ed4c: r0 = Throw()
    //     0x66ed4c: bl              #0xd67e38  ; ThrowStub
    // 0x66ed50: brk             #0
    // 0x66ed54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66ed54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66ed58: b               #0x66eb88
    // 0x66ed5c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x66ed5c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _paintTexture(/* No info */) {
    // ** addr: 0x66ed60, size: 0x164
    // 0x66ed60: EnterFrame
    //     0x66ed60: stp             fp, lr, [SP, #-0x10]!
    //     0x66ed64: mov             fp, SP
    // 0x66ed68: AllocStack(0x18)
    //     0x66ed68: sub             SP, SP, #0x18
    // 0x66ed6c: CheckStackOverflow
    //     0x66ed6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66ed70: cmp             SP, x16
    //     0x66ed74: b.ls            #0x66eeb8
    // 0x66ed78: ldr             x0, [fp, #0x20]
    // 0x66ed7c: LoadField: r1 = r0->field_73
    //     0x66ed7c: ldur            w1, [x0, #0x73]
    // 0x66ed80: DecompressPointer r1
    //     0x66ed80: add             x1, x1, HEAP, lsl #32
    // 0x66ed84: cmp             w1, NULL
    // 0x66ed88: b.ne            #0x66ed9c
    // 0x66ed8c: r0 = Null
    //     0x66ed8c: mov             x0, NULL
    // 0x66ed90: LeaveFrame
    //     0x66ed90: mov             SP, fp
    //     0x66ed94: ldp             fp, lr, [SP], #0x10
    // 0x66ed98: ret
    //     0x66ed98: ret             
    // 0x66ed9c: ldr             x16, [fp, #0x10]
    // 0x66eda0: stp             x1, x16, [SP, #-0x10]!
    // 0x66eda4: r0 = &()
    //     0x66eda4: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x66eda8: add             SP, SP, #0x10
    // 0x66edac: mov             x1, x0
    // 0x66edb0: ldr             x0, [fp, #0x20]
    // 0x66edb4: stur            x1, [fp, #-0x10]
    // 0x66edb8: LoadField: r2 = r0->field_7b
    //     0x66edb8: ldur            w2, [x0, #0x7b]
    // 0x66edbc: DecompressPointer r2
    //     0x66edbc: add             x2, x2, HEAP, lsl #32
    // 0x66edc0: r0 = LoadClassIdInstr(r2)
    //     0x66edc0: ldur            x0, [x2, #-1]
    //     0x66edc4: ubfx            x0, x0, #0xc, #0x14
    // 0x66edc8: lsl             x0, x0, #1
    // 0x66edcc: cmp             w0, #0xed6
    // 0x66edd0: b.eq            #0x66ee78
    // 0x66edd4: r0 = "Not supported for hybrid composition."
    //     0x66edd4: add             x0, PP, #0x49, lsl #12  ; [pp+0x499d0] "Not supported for hybrid composition."
    //     0x66edd8: ldr             x0, [x0, #0x9d0]
    // 0x66eddc: LoadField: r3 = r2->field_27
    //     0x66eddc: ldur            w3, [x2, #0x27]
    // 0x66ede0: DecompressPointer r3
    //     0x66ede0: add             x3, x3, HEAP, lsl #32
    // 0x66ede4: r2 = LoadClassIdInstr(r3)
    //     0x66ede4: ldur            x2, [x3, #-1]
    //     0x66ede8: ubfx            x2, x2, #0xc, #0x14
    // 0x66edec: lsl             x2, x2, #1
    // 0x66edf0: cmp             w2, #0xece
    // 0x66edf4: b.eq            #0x66ee98
    // 0x66edf8: LoadField: r0 = r3->field_b
    //     0x66edf8: ldur            w0, [x3, #0xb]
    // 0x66edfc: DecompressPointer r0
    //     0x66edfc: add             x0, x0, HEAP, lsl #32
    // 0x66ee00: stur            x0, [fp, #-8]
    // 0x66ee04: cmp             w0, NULL
    // 0x66ee08: b.eq            #0x66eec0
    // 0x66ee0c: r0 = TextureLayer()
    //     0x66ee0c: bl              #0x66ef14  ; AllocateTextureLayerStub -> TextureLayer (size=0x54)
    // 0x66ee10: mov             x1, x0
    // 0x66ee14: ldur            x0, [fp, #-0x10]
    // 0x66ee18: stur            x1, [fp, #-0x18]
    // 0x66ee1c: StoreField: r1->field_3f = r0
    //     0x66ee1c: stur            w0, [x1, #0x3f]
    // 0x66ee20: ldur            x0, [fp, #-8]
    // 0x66ee24: r2 = LoadInt32Instr(r0)
    //     0x66ee24: sbfx            x2, x0, #1, #0x1f
    //     0x66ee28: tbz             w0, #0, #0x66ee30
    //     0x66ee2c: ldur            x2, [x0, #7]
    // 0x66ee30: StoreField: r1->field_43 = r2
    //     0x66ee30: stur            x2, [x1, #0x43]
    // 0x66ee34: r0 = false
    //     0x66ee34: add             x0, NULL, #0x30  ; false
    // 0x66ee38: StoreField: r1->field_4b = r0
    //     0x66ee38: stur            w0, [x1, #0x4b]
    // 0x66ee3c: r0 = Instance_FilterQuality
    //     0x66ee3c: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c548] Obj!FilterQuality@b67811
    //     0x66ee40: ldr             x0, [x0, #0x548]
    // 0x66ee44: StoreField: r1->field_4f = r0
    //     0x66ee44: stur            w0, [x1, #0x4f]
    // 0x66ee48: SaveReg r1
    //     0x66ee48: str             x1, [SP, #-8]!
    // 0x66ee4c: r0 = Layer()
    //     0x66ee4c: bl              #0x5bbe7c  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0x66ee50: add             SP, SP, #8
    // 0x66ee54: ldr             x16, [fp, #0x18]
    // 0x66ee58: ldur            lr, [fp, #-0x18]
    // 0x66ee5c: stp             lr, x16, [SP, #-0x10]!
    // 0x66ee60: r0 = addLayer()
    //     0x66ee60: bl              #0x66eec4  ; [package:flutter/src/rendering/object.dart] PaintingContext::addLayer
    // 0x66ee64: add             SP, SP, #0x10
    // 0x66ee68: r0 = Null
    //     0x66ee68: mov             x0, NULL
    // 0x66ee6c: LeaveFrame
    //     0x66ee6c: mov             SP, fp
    //     0x66ee70: ldp             fp, lr, [SP], #0x10
    // 0x66ee74: ret
    //     0x66ee74: ret             
    // 0x66ee78: r0 = UnimplementedError()
    //     0x66ee78: bl              #0x4c1104  ; AllocateUnimplementedErrorStub -> UnimplementedError (size=0x10)
    // 0x66ee7c: mov             x1, x0
    // 0x66ee80: r0 = "Not supported for hybrid composition."
    //     0x66ee80: add             x0, PP, #0x49, lsl #12  ; [pp+0x499d0] "Not supported for hybrid composition."
    //     0x66ee84: ldr             x0, [x0, #0x9d0]
    // 0x66ee88: StoreField: r1->field_b = r0
    //     0x66ee88: stur            w0, [x1, #0xb]
    // 0x66ee8c: mov             x0, x1
    // 0x66ee90: r0 = Throw()
    //     0x66ee90: bl              #0xd67e38  ; ThrowStub
    // 0x66ee94: brk             #0
    // 0x66ee98: r0 = UnimplementedError()
    //     0x66ee98: bl              #0x4c1104  ; AllocateUnimplementedErrorStub -> UnimplementedError (size=0x10)
    // 0x66ee9c: mov             x1, x0
    // 0x66eea0: r0 = "Not supported for hybrid composition."
    //     0x66eea0: add             x0, PP, #0x49, lsl #12  ; [pp+0x499d0] "Not supported for hybrid composition."
    //     0x66eea4: ldr             x0, [x0, #0x9d0]
    // 0x66eea8: StoreField: r1->field_b = r0
    //     0x66eea8: stur            w0, [x1, #0xb]
    // 0x66eeac: mov             x0, x1
    // 0x66eeb0: r0 = Throw()
    //     0x66eeb0: bl              #0xd67e38  ; ThrowStub
    // 0x66eeb4: brk             #0
    // 0x66eeb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66eeb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66eebc: b               #0x66ed78
    // 0x66eec0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66eec0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _paintTexture(dynamic, PaintingContext, Offset) {
    // ** addr: 0x66ef20, size: 0x54
    // 0x66ef20: EnterFrame
    //     0x66ef20: stp             fp, lr, [SP, #-0x10]!
    //     0x66ef24: mov             fp, SP
    // 0x66ef28: ldr             x0, [fp, #0x20]
    // 0x66ef2c: LoadField: r1 = r0->field_17
    //     0x66ef2c: ldur            w1, [x0, #0x17]
    // 0x66ef30: DecompressPointer r1
    //     0x66ef30: add             x1, x1, HEAP, lsl #32
    // 0x66ef34: CheckStackOverflow
    //     0x66ef34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66ef38: cmp             SP, x16
    //     0x66ef3c: b.ls            #0x66ef6c
    // 0x66ef40: LoadField: r0 = r1->field_f
    //     0x66ef40: ldur            w0, [x1, #0xf]
    // 0x66ef44: DecompressPointer r0
    //     0x66ef44: add             x0, x0, HEAP, lsl #32
    // 0x66ef48: ldr             x16, [fp, #0x18]
    // 0x66ef4c: stp             x16, x0, [SP, #-0x10]!
    // 0x66ef50: ldr             x16, [fp, #0x10]
    // 0x66ef54: SaveReg r16
    //     0x66ef54: str             x16, [SP, #-8]!
    // 0x66ef58: r0 = _paintTexture()
    //     0x66ef58: bl              #0x66ed60  ; [package:flutter/src/rendering/platform_view.dart] RenderAndroidView::_paintTexture
    // 0x66ef5c: add             SP, SP, #0x18
    // 0x66ef60: LeaveFrame
    //     0x66ef60: mov             SP, fp
    //     0x66ef64: ldp             fp, lr, [SP], #0x10
    // 0x66ef68: ret
    //     0x66ef68: ret             
    // 0x66ef6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66ef6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66ef70: b               #0x66ef40
  }
  _ RenderAndroidView(/* No info */) {
    // ** addr: 0x6f0710, size: 0x258
    // 0x6f0710: EnterFrame
    //     0x6f0710: stp             fp, lr, [SP, #-0x10]!
    //     0x6f0714: mov             fp, SP
    // 0x6f0718: AllocStack(0x18)
    //     0x6f0718: sub             SP, SP, #0x18
    // 0x6f071c: CheckStackOverflow
    //     0x6f071c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f0720: cmp             SP, x16
    //     0x6f0724: b.ls            #0x6f095c
    // 0x6f0728: r1 = 1
    //     0x6f0728: mov             x1, #1
    // 0x6f072c: r0 = AllocateContext()
    //     0x6f072c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6f0730: mov             x2, x0
    // 0x6f0734: ldr             x0, [fp, #0x18]
    // 0x6f0738: stur            x2, [fp, #-8]
    // 0x6f073c: StoreField: r2->field_f = r0
    //     0x6f073c: stur            w0, [x2, #0xf]
    // 0x6f0740: r1 = Instance__PlatformViewState
    //     0x6f0740: add             x1, PP, #0x49, lsl #12  ; [pp+0x49990] Obj!_PlatformViewState@b64991
    //     0x6f0744: ldr             x1, [x1, #0x990]
    // 0x6f0748: StoreField: r0->field_6f = r1
    //     0x6f0748: stur            w1, [x0, #0x6f]
    // 0x6f074c: r1 = false
    //     0x6f074c: add             x1, NULL, #0x30  ; false
    // 0x6f0750: StoreField: r0->field_77 = r1
    //     0x6f0750: stur            w1, [x0, #0x77]
    // 0x6f0754: r1 = <ClipRectLayer>
    //     0x6f0754: add             x1, PP, #0x15, lsl #12  ; [pp+0x15388] TypeArguments: <ClipRectLayer>
    //     0x6f0758: ldr             x1, [x1, #0x388]
    // 0x6f075c: r0 = LayerHandle()
    //     0x6f075c: bl              #0x5bbf28  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x6f0760: ldr             x1, [fp, #0x18]
    // 0x6f0764: StoreField: r1->field_83 = r0
    //     0x6f0764: stur            w0, [x1, #0x83]
    //     0x6f0768: ldurb           w16, [x1, #-1]
    //     0x6f076c: ldurb           w17, [x0, #-1]
    //     0x6f0770: and             x16, x17, x16, lsr #2
    //     0x6f0774: tst             x16, HEAP, lsr #32
    //     0x6f0778: b.eq            #0x6f0780
    //     0x6f077c: bl              #0xd6826c
    // 0x6f0780: ldr             x0, [fp, #0x10]
    // 0x6f0784: StoreField: r1->field_7b = r0
    //     0x6f0784: stur            w0, [x1, #0x7b]
    //     0x6f0788: ldurb           w16, [x1, #-1]
    //     0x6f078c: ldurb           w17, [x0, #-1]
    //     0x6f0790: and             x16, x17, x16, lsr #2
    //     0x6f0794: tst             x16, HEAP, lsr #32
    //     0x6f0798: b.eq            #0x6f07a0
    //     0x6f079c: bl              #0xd6826c
    // 0x6f07a0: r0 = Instance_Clip
    //     0x6f07a0: add             x0, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x6f07a4: ldr             x0, [x0, #0x678]
    // 0x6f07a8: StoreField: r1->field_7f = r0
    //     0x6f07a8: stur            w0, [x1, #0x7f]
    // 0x6f07ac: ldr             x16, [fp, #0x10]
    // 0x6f07b0: stp             x16, x1, [SP, #-0x10]!
    // 0x6f07b4: r0 = PlatformViewRenderBox()
    //     0x6f07b4: bl              #0x6f0c08  ; [package:flutter/src/rendering/platform_view.dart] PlatformViewRenderBox::PlatformViewRenderBox
    // 0x6f07b8: add             SP, SP, #0x10
    // 0x6f07bc: ldr             x0, [fp, #0x18]
    // 0x6f07c0: LoadField: r1 = r0->field_7b
    //     0x6f07c0: ldur            w1, [x0, #0x7b]
    // 0x6f07c4: DecompressPointer r1
    //     0x6f07c4: add             x1, x1, HEAP, lsl #32
    // 0x6f07c8: LoadField: r3 = r1->field_13
    //     0x6f07c8: ldur            w3, [x1, #0x13]
    // 0x6f07cc: DecompressPointer r3
    //     0x6f07cc: add             x3, x3, HEAP, lsl #32
    // 0x6f07d0: ldur            x2, [fp, #-8]
    // 0x6f07d4: stur            x3, [fp, #-0x10]
    // 0x6f07d8: r1 = Function '<anonymous closure>':.
    //     0x6f07d8: add             x1, PP, #0x49, lsl #12  ; [pp+0x49998] AnonymousClosure: (0x6f0c8c), in [package:flutter/src/widgets/platform_view.dart] _TextureBasedAndroidViewSurface::createRenderObject (0x6f0664)
    //     0x6f07dc: ldr             x1, [x1, #0x998]
    // 0x6f07e0: r0 = AllocateClosure()
    //     0x6f07e0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6f07e4: ldur            x1, [fp, #-0x10]
    // 0x6f07e8: StoreField: r1->field_13 = r0
    //     0x6f07e8: stur            w0, [x1, #0x13]
    //     0x6f07ec: ldurb           w16, [x1, #-1]
    //     0x6f07f0: ldurb           w17, [x0, #-1]
    //     0x6f07f4: and             x16, x17, x16, lsr #2
    //     0x6f07f8: tst             x16, HEAP, lsr #32
    //     0x6f07fc: b.eq            #0x6f0804
    //     0x6f0800: bl              #0xd6826c
    // 0x6f0804: ldr             x16, [fp, #0x18]
    // 0x6f0808: SaveReg r16
    //     0x6f0808: str             x16, [SP, #-8]!
    // 0x6f080c: r0 = updateGestureRecognizers()
    //     0x6f080c: bl              #0x6d497c  ; [package:flutter/src/rendering/platform_view.dart] PlatformViewRenderBox::updateGestureRecognizers
    // 0x6f0810: add             SP, SP, #8
    // 0x6f0814: ldr             x0, [fp, #0x18]
    // 0x6f0818: LoadField: r1 = r0->field_7b
    //     0x6f0818: ldur            w1, [x0, #0x7b]
    // 0x6f081c: DecompressPointer r1
    //     0x6f081c: add             x1, x1, HEAP, lsl #32
    // 0x6f0820: stur            x1, [fp, #-8]
    // 0x6f0824: r1 = 1
    //     0x6f0824: mov             x1, #1
    // 0x6f0828: r0 = AllocateContext()
    //     0x6f0828: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6f082c: mov             x1, x0
    // 0x6f0830: ldr             x0, [fp, #0x18]
    // 0x6f0834: StoreField: r1->field_f = r0
    //     0x6f0834: stur            w0, [x1, #0xf]
    // 0x6f0838: ldur            x2, [fp, #-8]
    // 0x6f083c: LoadField: r3 = r2->field_23
    //     0x6f083c: ldur            w3, [x2, #0x23]
    // 0x6f0840: DecompressPointer r3
    //     0x6f0840: add             x3, x3, HEAP, lsl #32
    // 0x6f0844: stur            x3, [fp, #-0x10]
    // 0x6f0848: LoadField: r4 = r3->field_7
    //     0x6f0848: ldur            w4, [x3, #7]
    // 0x6f084c: DecompressPointer r4
    //     0x6f084c: add             x4, x4, HEAP, lsl #32
    // 0x6f0850: mov             x2, x1
    // 0x6f0854: stur            x4, [fp, #-8]
    // 0x6f0858: r1 = Function '_onPlatformViewCreated@906508051':.
    //     0x6f0858: add             x1, PP, #0x49, lsl #12  ; [pp+0x499a0] AnonymousClosure: (0x6534ec), of [package:flutter/src/rendering/platform_view.dart] RenderAndroidView
    //     0x6f085c: ldr             x1, [x1, #0x9a0]
    // 0x6f0860: r0 = AllocateClosure()
    //     0x6f0860: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6f0864: ldur            x2, [fp, #-8]
    // 0x6f0868: mov             x3, x0
    // 0x6f086c: r1 = Null
    //     0x6f086c: mov             x1, NULL
    // 0x6f0870: stur            x3, [fp, #-8]
    // 0x6f0874: cmp             w2, NULL
    // 0x6f0878: b.eq            #0x6f0898
    // 0x6f087c: LoadField: r4 = r2->field_17
    //     0x6f087c: ldur            w4, [x2, #0x17]
    // 0x6f0880: DecompressPointer r4
    //     0x6f0880: add             x4, x4, HEAP, lsl #32
    // 0x6f0884: r8 = X0
    //     0x6f0884: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6f0888: LoadField: r9 = r4->field_7
    //     0x6f0888: ldur            x9, [x4, #7]
    // 0x6f088c: r3 = Null
    //     0x6f088c: add             x3, PP, #0x49, lsl #12  ; [pp+0x499a8] Null
    //     0x6f0890: ldr             x3, [x3, #0x9a8]
    // 0x6f0894: blr             x9
    // 0x6f0898: ldur            x0, [fp, #-0x10]
    // 0x6f089c: LoadField: r1 = r0->field_b
    //     0x6f089c: ldur            w1, [x0, #0xb]
    // 0x6f08a0: DecompressPointer r1
    //     0x6f08a0: add             x1, x1, HEAP, lsl #32
    // 0x6f08a4: stur            x1, [fp, #-0x18]
    // 0x6f08a8: LoadField: r2 = r0->field_f
    //     0x6f08a8: ldur            w2, [x0, #0xf]
    // 0x6f08ac: DecompressPointer r2
    //     0x6f08ac: add             x2, x2, HEAP, lsl #32
    // 0x6f08b0: LoadField: r3 = r2->field_b
    //     0x6f08b0: ldur            w3, [x2, #0xb]
    // 0x6f08b4: DecompressPointer r3
    //     0x6f08b4: add             x3, x3, HEAP, lsl #32
    // 0x6f08b8: cmp             w1, w3
    // 0x6f08bc: b.ne            #0x6f08cc
    // 0x6f08c0: SaveReg r0
    //     0x6f08c0: str             x0, [SP, #-8]!
    // 0x6f08c4: r0 = _growToNextCapacity()
    //     0x6f08c4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6f08c8: add             SP, SP, #8
    // 0x6f08cc: ldur            x2, [fp, #-0x10]
    // 0x6f08d0: ldur            x0, [fp, #-0x18]
    // 0x6f08d4: r3 = LoadInt32Instr(r0)
    //     0x6f08d4: sbfx            x3, x0, #1, #0x1f
    // 0x6f08d8: add             x0, x3, #1
    // 0x6f08dc: lsl             x1, x0, #1
    // 0x6f08e0: StoreField: r2->field_b = r1
    //     0x6f08e0: stur            w1, [x2, #0xb]
    // 0x6f08e4: mov             x1, x3
    // 0x6f08e8: cmp             x1, x0
    // 0x6f08ec: b.hs            #0x6f0964
    // 0x6f08f0: LoadField: r1 = r2->field_f
    //     0x6f08f0: ldur            w1, [x2, #0xf]
    // 0x6f08f4: DecompressPointer r1
    //     0x6f08f4: add             x1, x1, HEAP, lsl #32
    // 0x6f08f8: ldur            x0, [fp, #-8]
    // 0x6f08fc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x6f08fc: add             x25, x1, x3, lsl #2
    //     0x6f0900: add             x25, x25, #0xf
    //     0x6f0904: str             w0, [x25]
    //     0x6f0908: tbz             w0, #0, #0x6f0924
    //     0x6f090c: ldurb           w16, [x1, #-1]
    //     0x6f0910: ldurb           w17, [x0, #-1]
    //     0x6f0914: and             x16, x17, x16, lsr #2
    //     0x6f0918: tst             x16, HEAP, lsr #32
    //     0x6f091c: b.eq            #0x6f0924
    //     0x6f0920: bl              #0xd67e5c
    // 0x6f0924: ldr             x16, [fp, #0x18]
    // 0x6f0928: r30 = Instance_PlatformViewHitTestBehavior
    //     0x6f0928: add             lr, PP, #0x2a, lsl #12  ; [pp+0x2a378] Obj!PlatformViewHitTestBehavior@b649d1
    //     0x6f092c: ldr             lr, [lr, #0x378]
    // 0x6f0930: stp             lr, x16, [SP, #-0x10]!
    // 0x6f0934: r0 = hitTestBehavior=()
    //     0x6f0934: bl              #0x6d68ac  ; [package:flutter/src/rendering/platform_view.dart] _PlatformViewRenderBox&RenderBox&_PlatformViewGestureMixin::hitTestBehavior=
    // 0x6f0938: add             SP, SP, #0x10
    // 0x6f093c: ldr             x16, [fp, #0x18]
    // 0x6f0940: SaveReg r16
    //     0x6f0940: str             x16, [SP, #-8]!
    // 0x6f0944: r0 = _setOffset()
    //     0x6f0944: bl              #0x6f0968  ; [package:flutter/src/rendering/platform_view.dart] RenderAndroidView::_setOffset
    // 0x6f0948: add             SP, SP, #8
    // 0x6f094c: r0 = Null
    //     0x6f094c: mov             x0, NULL
    // 0x6f0950: LeaveFrame
    //     0x6f0950: mov             SP, fp
    //     0x6f0954: ldp             fp, lr, [SP], #0x10
    // 0x6f0958: ret
    //     0x6f0958: ret             
    // 0x6f095c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f095c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f0960: b               #0x6f0728
    // 0x6f0964: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6f0964: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _setOffset(/* No info */) {
    // ** addr: 0x6f0968, size: 0x144
    // 0x6f0968: EnterFrame
    //     0x6f0968: stp             fp, lr, [SP, #-0x10]!
    //     0x6f096c: mov             fp, SP
    // 0x6f0970: AllocStack(0x18)
    //     0x6f0970: sub             SP, SP, #0x18
    // 0x6f0974: CheckStackOverflow
    //     0x6f0974: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f0978: cmp             SP, x16
    //     0x6f097c: b.ls            #0x6f0a9c
    // 0x6f0980: r1 = 1
    //     0x6f0980: mov             x1, #1
    // 0x6f0984: r0 = AllocateContext()
    //     0x6f0984: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6f0988: mov             x1, x0
    // 0x6f098c: ldr             x0, [fp, #0x10]
    // 0x6f0990: StoreField: r1->field_f = r0
    //     0x6f0990: stur            w0, [x1, #0xf]
    // 0x6f0994: r0 = LoadStaticField(0xf10)
    //     0x6f0994: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6f0998: ldr             x0, [x0, #0x1e20]
    // 0x6f099c: cmp             w0, NULL
    // 0x6f09a0: b.eq            #0x6f0aa4
    // 0x6f09a4: LoadField: r3 = r0->field_57
    //     0x6f09a4: ldur            w3, [x0, #0x57]
    // 0x6f09a8: DecompressPointer r3
    //     0x6f09a8: add             x3, x3, HEAP, lsl #32
    // 0x6f09ac: stur            x3, [fp, #-0x10]
    // 0x6f09b0: LoadField: r0 = r3->field_7
    //     0x6f09b0: ldur            w0, [x3, #7]
    // 0x6f09b4: DecompressPointer r0
    //     0x6f09b4: add             x0, x0, HEAP, lsl #32
    // 0x6f09b8: mov             x2, x1
    // 0x6f09bc: stur            x0, [fp, #-8]
    // 0x6f09c0: r1 = Function '<anonymous closure>':.
    //     0x6f09c0: add             x1, PP, #0x49, lsl #12  ; [pp+0x499b8] AnonymousClosure: (0x6f0aac), in [package:flutter/src/rendering/platform_view.dart] RenderAndroidView::_setOffset (0x6f0968)
    //     0x6f09c4: ldr             x1, [x1, #0x9b8]
    // 0x6f09c8: r0 = AllocateClosure()
    //     0x6f09c8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6f09cc: ldur            x2, [fp, #-8]
    // 0x6f09d0: mov             x3, x0
    // 0x6f09d4: r1 = Null
    //     0x6f09d4: mov             x1, NULL
    // 0x6f09d8: stur            x3, [fp, #-8]
    // 0x6f09dc: cmp             w2, NULL
    // 0x6f09e0: b.eq            #0x6f0a00
    // 0x6f09e4: LoadField: r4 = r2->field_17
    //     0x6f09e4: ldur            w4, [x2, #0x17]
    // 0x6f09e8: DecompressPointer r4
    //     0x6f09e8: add             x4, x4, HEAP, lsl #32
    // 0x6f09ec: r8 = X0
    //     0x6f09ec: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6f09f0: LoadField: r9 = r4->field_7
    //     0x6f09f0: ldur            x9, [x4, #7]
    // 0x6f09f4: r3 = Null
    //     0x6f09f4: add             x3, PP, #0x49, lsl #12  ; [pp+0x499c0] Null
    //     0x6f09f8: ldr             x3, [x3, #0x9c0]
    // 0x6f09fc: blr             x9
    // 0x6f0a00: ldur            x0, [fp, #-0x10]
    // 0x6f0a04: LoadField: r1 = r0->field_b
    //     0x6f0a04: ldur            w1, [x0, #0xb]
    // 0x6f0a08: DecompressPointer r1
    //     0x6f0a08: add             x1, x1, HEAP, lsl #32
    // 0x6f0a0c: stur            x1, [fp, #-0x18]
    // 0x6f0a10: LoadField: r2 = r0->field_f
    //     0x6f0a10: ldur            w2, [x0, #0xf]
    // 0x6f0a14: DecompressPointer r2
    //     0x6f0a14: add             x2, x2, HEAP, lsl #32
    // 0x6f0a18: LoadField: r3 = r2->field_b
    //     0x6f0a18: ldur            w3, [x2, #0xb]
    // 0x6f0a1c: DecompressPointer r3
    //     0x6f0a1c: add             x3, x3, HEAP, lsl #32
    // 0x6f0a20: cmp             w1, w3
    // 0x6f0a24: b.ne            #0x6f0a34
    // 0x6f0a28: SaveReg r0
    //     0x6f0a28: str             x0, [SP, #-8]!
    // 0x6f0a2c: r0 = _growToNextCapacity()
    //     0x6f0a2c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6f0a30: add             SP, SP, #8
    // 0x6f0a34: ldur            x2, [fp, #-0x10]
    // 0x6f0a38: ldur            x3, [fp, #-0x18]
    // 0x6f0a3c: r4 = LoadInt32Instr(r3)
    //     0x6f0a3c: sbfx            x4, x3, #1, #0x1f
    // 0x6f0a40: add             x0, x4, #1
    // 0x6f0a44: lsl             x3, x0, #1
    // 0x6f0a48: StoreField: r2->field_b = r3
    //     0x6f0a48: stur            w3, [x2, #0xb]
    // 0x6f0a4c: mov             x1, x4
    // 0x6f0a50: cmp             x1, x0
    // 0x6f0a54: b.hs            #0x6f0aa8
    // 0x6f0a58: LoadField: r1 = r2->field_f
    //     0x6f0a58: ldur            w1, [x2, #0xf]
    // 0x6f0a5c: DecompressPointer r1
    //     0x6f0a5c: add             x1, x1, HEAP, lsl #32
    // 0x6f0a60: ldur            x0, [fp, #-8]
    // 0x6f0a64: ArrayStore: r1[r4] = r0  ; List_4
    //     0x6f0a64: add             x25, x1, x4, lsl #2
    //     0x6f0a68: add             x25, x25, #0xf
    //     0x6f0a6c: str             w0, [x25]
    //     0x6f0a70: tbz             w0, #0, #0x6f0a8c
    //     0x6f0a74: ldurb           w16, [x1, #-1]
    //     0x6f0a78: ldurb           w17, [x0, #-1]
    //     0x6f0a7c: and             x16, x17, x16, lsr #2
    //     0x6f0a80: tst             x16, HEAP, lsr #32
    //     0x6f0a84: b.eq            #0x6f0a8c
    //     0x6f0a88: bl              #0xd67e5c
    // 0x6f0a8c: r0 = Null
    //     0x6f0a8c: mov             x0, NULL
    // 0x6f0a90: LeaveFrame
    //     0x6f0a90: mov             SP, fp
    //     0x6f0a94: ldp             fp, lr, [SP], #0x10
    // 0x6f0a98: ret
    //     0x6f0a98: ret             
    // 0x6f0a9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f0a9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f0aa0: b               #0x6f0980
    // 0x6f0aa4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6f0aa4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6f0aa8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6f0aa8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic, Duration) async {
    // ** addr: 0x6f0aac, size: 0x15c
    // 0x6f0aac: EnterFrame
    //     0x6f0aac: stp             fp, lr, [SP, #-0x10]!
    //     0x6f0ab0: mov             fp, SP
    // 0x6f0ab4: AllocStack(0x18)
    //     0x6f0ab4: sub             SP, SP, #0x18
    // 0x6f0ab8: SetupParameters(RenderAndroidView this /* r1 */)
    //     0x6f0ab8: stur            NULL, [fp, #-8]
    //     0x6f0abc: mov             x0, #0
    //     0x6f0ac0: add             x1, fp, w0, sxtw #2
    //     0x6f0ac4: ldr             x1, [x1, #0x18]
    //     0x6f0ac8: ldur            w2, [x1, #0x17]
    //     0x6f0acc: add             x2, x2, HEAP, lsl #32
    //     0x6f0ad0: stur            x2, [fp, #-0x10]
    // 0x6f0ad4: CheckStackOverflow
    //     0x6f0ad4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f0ad8: cmp             SP, x16
    //     0x6f0adc: b.ls            #0x6f0c00
    // 0x6f0ae0: InitAsync() -> Future<void?>
    //     0x6f0ae0: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x6f0ae4: bl              #0x4b92e4
    // 0x6f0ae8: ldur            x0, [fp, #-0x10]
    // 0x6f0aec: LoadField: r1 = r0->field_f
    //     0x6f0aec: ldur            w1, [x0, #0xf]
    // 0x6f0af0: DecompressPointer r1
    //     0x6f0af0: add             x1, x1, HEAP, lsl #32
    // 0x6f0af4: LoadField: r2 = r1->field_77
    //     0x6f0af4: ldur            w2, [x1, #0x77]
    // 0x6f0af8: DecompressPointer r2
    //     0x6f0af8: add             x2, x2, HEAP, lsl #32
    // 0x6f0afc: tbz             w2, #4, #0x6f0bc0
    // 0x6f0b00: LoadField: r2 = r1->field_f
    //     0x6f0b00: ldur            w2, [x1, #0xf]
    // 0x6f0b04: DecompressPointer r2
    //     0x6f0b04: add             x2, x2, HEAP, lsl #32
    // 0x6f0b08: cmp             w2, NULL
    // 0x6f0b0c: b.eq            #0x6f0ba8
    // 0x6f0b10: LoadField: r2 = r1->field_7b
    //     0x6f0b10: ldur            w2, [x1, #0x7b]
    // 0x6f0b14: DecompressPointer r2
    //     0x6f0b14: add             x2, x2, HEAP, lsl #32
    // 0x6f0b18: stur            x2, [fp, #-0x18]
    // 0x6f0b1c: r16 = Instance_Offset
    //     0x6f0b1c: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x6f0b20: stp             x16, x1, [SP, #-0x10]!
    // 0x6f0b24: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x6f0b24: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x6f0b28: r0 = localToGlobal()
    //     0x6f0b28: bl              #0x64e820  ; [package:flutter/src/rendering/box.dart] RenderBox::localToGlobal
    // 0x6f0b2c: add             SP, SP, #0x10
    // 0x6f0b30: mov             x1, x0
    // 0x6f0b34: ldur            x0, [fp, #-0x18]
    // 0x6f0b38: r2 = LoadClassIdInstr(r0)
    //     0x6f0b38: ldur            x2, [x0, #-1]
    //     0x6f0b3c: ubfx            x2, x2, #0xc, #0x14
    // 0x6f0b40: lsl             x2, x2, #1
    // 0x6f0b44: cmp             w2, #0xed6
    // 0x6f0b48: b.eq            #0x6f0bc8
    // 0x6f0b4c: r2 = "Not supported for hybrid composition."
    //     0x6f0b4c: add             x2, PP, #0x49, lsl #12  ; [pp+0x499d0] "Not supported for hybrid composition."
    //     0x6f0b50: ldr             x2, [x2, #0x9d0]
    // 0x6f0b54: LoadField: r3 = r0->field_27
    //     0x6f0b54: ldur            w3, [x0, #0x27]
    // 0x6f0b58: DecompressPointer r3
    //     0x6f0b58: add             x3, x3, HEAP, lsl #32
    // 0x6f0b5c: LoadField: r4 = r0->field_7
    //     0x6f0b5c: ldur            x4, [x0, #7]
    // 0x6f0b60: LoadField: r5 = r0->field_1b
    //     0x6f0b60: ldur            w5, [x0, #0x1b]
    // 0x6f0b64: DecompressPointer r5
    //     0x6f0b64: add             x5, x5, HEAP, lsl #32
    // 0x6f0b68: r0 = LoadClassIdInstr(r3)
    //     0x6f0b68: ldur            x0, [x3, #-1]
    //     0x6f0b6c: ubfx            x0, x0, #0xc, #0x14
    // 0x6f0b70: lsl             x0, x0, #1
    // 0x6f0b74: cmp             w0, #0xece
    // 0x6f0b78: b.eq            #0x6f0be0
    // 0x6f0b7c: r0 = LoadClassIdInstr(r3)
    //     0x6f0b7c: ldur            x0, [x3, #-1]
    //     0x6f0b80: ubfx            x0, x0, #0xc, #0x14
    // 0x6f0b84: stp             x1, x3, [SP, #-0x10]!
    // 0x6f0b88: stp             x5, x4, [SP, #-0x10]!
    // 0x6f0b8c: r0 = GDT[cid_x0 + -0xfdc]()
    //     0x6f0b8c: sub             lr, x0, #0xfdc
    //     0x6f0b90: ldr             lr, [x21, lr, lsl #3]
    //     0x6f0b94: blr             lr
    // 0x6f0b98: add             SP, SP, #0x20
    // 0x6f0b9c: mov             x1, x0
    // 0x6f0ba0: stur            x1, [fp, #-0x18]
    // 0x6f0ba4: r0 = Await()
    //     0x6f0ba4: bl              #0x4b8e6c  ; AwaitStub
    // 0x6f0ba8: ldur            x0, [fp, #-0x10]
    // 0x6f0bac: LoadField: r1 = r0->field_f
    //     0x6f0bac: ldur            w1, [x0, #0xf]
    // 0x6f0bb0: DecompressPointer r1
    //     0x6f0bb0: add             x1, x1, HEAP, lsl #32
    // 0x6f0bb4: SaveReg r1
    //     0x6f0bb4: str             x1, [SP, #-8]!
    // 0x6f0bb8: r0 = _setOffset()
    //     0x6f0bb8: bl              #0x6f0968  ; [package:flutter/src/rendering/platform_view.dart] RenderAndroidView::_setOffset
    // 0x6f0bbc: add             SP, SP, #8
    // 0x6f0bc0: r0 = Null
    //     0x6f0bc0: mov             x0, NULL
    // 0x6f0bc4: r0 = ReturnAsyncNotFuture()
    //     0x6f0bc4: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x6f0bc8: r0 = UnimplementedError()
    //     0x6f0bc8: bl              #0x4c1104  ; AllocateUnimplementedErrorStub -> UnimplementedError (size=0x10)
    // 0x6f0bcc: r2 = "Not supported for hybrid composition."
    //     0x6f0bcc: add             x2, PP, #0x49, lsl #12  ; [pp+0x499d0] "Not supported for hybrid composition."
    //     0x6f0bd0: ldr             x2, [x2, #0x9d0]
    // 0x6f0bd4: StoreField: r0->field_b = r2
    //     0x6f0bd4: stur            w2, [x0, #0xb]
    // 0x6f0bd8: r0 = Throw()
    //     0x6f0bd8: bl              #0xd67e38  ; ThrowStub
    // 0x6f0bdc: brk             #0
    // 0x6f0be0: r0 = UnimplementedError()
    //     0x6f0be0: bl              #0x4c1104  ; AllocateUnimplementedErrorStub -> UnimplementedError (size=0x10)
    // 0x6f0be4: mov             x1, x0
    // 0x6f0be8: r0 = "Not supported for hybrid composition."
    //     0x6f0be8: add             x0, PP, #0x49, lsl #12  ; [pp+0x499d0] "Not supported for hybrid composition."
    //     0x6f0bec: ldr             x0, [x0, #0x9d0]
    // 0x6f0bf0: StoreField: r1->field_b = r0
    //     0x6f0bf0: stur            w0, [x1, #0xb]
    // 0x6f0bf4: mov             x0, x1
    // 0x6f0bf8: r0 = Throw()
    //     0x6f0bf8: bl              #0xd67e38  ; ThrowStub
    // 0x6f0bfc: brk             #0
    // 0x6f0c00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f0c00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f0c04: b               #0x6f0ae0
  }
  set _ controller=(/* No info */) {
    // ** addr: 0xcf07e0, size: 0x270
    // 0xcf07e0: EnterFrame
    //     0xcf07e0: stp             fp, lr, [SP, #-0x10]!
    //     0xcf07e4: mov             fp, SP
    // 0xcf07e8: AllocStack(0x18)
    //     0xcf07e8: sub             SP, SP, #0x18
    // 0xcf07ec: CheckStackOverflow
    //     0xcf07ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf07f0: cmp             SP, x16
    //     0xcf07f4: b.ls            #0xcf0a44
    // 0xcf07f8: r1 = 1
    //     0xcf07f8: mov             x1, #1
    // 0xcf07fc: r0 = AllocateContext()
    //     0xcf07fc: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcf0800: mov             x1, x0
    // 0xcf0804: ldr             x0, [fp, #0x18]
    // 0xcf0808: stur            x1, [fp, #-0x10]
    // 0xcf080c: StoreField: r1->field_f = r0
    //     0xcf080c: stur            w0, [x1, #0xf]
    // 0xcf0810: LoadField: r2 = r0->field_7b
    //     0xcf0810: ldur            w2, [x0, #0x7b]
    // 0xcf0814: DecompressPointer r2
    //     0xcf0814: add             x2, x2, HEAP, lsl #32
    // 0xcf0818: ldr             x3, [fp, #0x10]
    // 0xcf081c: stur            x2, [fp, #-8]
    // 0xcf0820: cmp             w2, w3
    // 0xcf0824: b.ne            #0xcf0838
    // 0xcf0828: r0 = Null
    //     0xcf0828: mov             x0, NULL
    // 0xcf082c: LeaveFrame
    //     0xcf082c: mov             SP, fp
    //     0xcf0830: ldp             fp, lr, [SP], #0x10
    // 0xcf0834: ret
    //     0xcf0834: ret             
    // 0xcf0838: r1 = 1
    //     0xcf0838: mov             x1, #1
    // 0xcf083c: r0 = AllocateContext()
    //     0xcf083c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcf0840: mov             x1, x0
    // 0xcf0844: ldr             x0, [fp, #0x18]
    // 0xcf0848: StoreField: r1->field_f = r0
    //     0xcf0848: stur            w0, [x1, #0xf]
    // 0xcf084c: mov             x2, x1
    // 0xcf0850: r1 = Function '_onPlatformViewCreated@906508051':.
    //     0xcf0850: add             x1, PP, #0x49, lsl #12  ; [pp+0x499a0] AnonymousClosure: (0x6534ec), of [package:flutter/src/rendering/platform_view.dart] RenderAndroidView
    //     0xcf0854: ldr             x1, [x1, #0x9a0]
    // 0xcf0858: r0 = AllocateClosure()
    //     0xcf0858: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcf085c: ldur            x16, [fp, #-8]
    // 0xcf0860: stp             x0, x16, [SP, #-0x10]!
    // 0xcf0864: r0 = removeOnPlatformViewCreatedListener()
    //     0xcf0864: bl              #0x6534a4  ; [package:flutter/src/services/platform_views.dart] AndroidViewController::removeOnPlatformViewCreatedListener
    // 0xcf0868: add             SP, SP, #0x10
    // 0xcf086c: ldr             x16, [fp, #0x18]
    // 0xcf0870: ldr             lr, [fp, #0x10]
    // 0xcf0874: stp             lr, x16, [SP, #-0x10]!
    // 0xcf0878: r0 = controller=()
    //     0xcf0878: bl              #0xcf0a50  ; [package:flutter/src/rendering/platform_view.dart] PlatformViewRenderBox::controller=
    // 0xcf087c: add             SP, SP, #0x10
    // 0xcf0880: ldr             x0, [fp, #0x10]
    // 0xcf0884: ldr             x3, [fp, #0x18]
    // 0xcf0888: StoreField: r3->field_7b = r0
    //     0xcf0888: stur            w0, [x3, #0x7b]
    //     0xcf088c: ldurb           w16, [x3, #-1]
    //     0xcf0890: ldurb           w17, [x0, #-1]
    //     0xcf0894: and             x16, x17, x16, lsr #2
    //     0xcf0898: tst             x16, HEAP, lsr #32
    //     0xcf089c: b.eq            #0xcf08a4
    //     0xcf08a0: bl              #0xd682ac
    // 0xcf08a4: ldr             x0, [fp, #0x10]
    // 0xcf08a8: LoadField: r4 = r0->field_13
    //     0xcf08a8: ldur            w4, [x0, #0x13]
    // 0xcf08ac: DecompressPointer r4
    //     0xcf08ac: add             x4, x4, HEAP, lsl #32
    // 0xcf08b0: ldur            x2, [fp, #-0x10]
    // 0xcf08b4: stur            x4, [fp, #-8]
    // 0xcf08b8: r1 = Function '<anonymous closure>':.
    //     0xcf08b8: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4fe58] AnonymousClosure: (0x6f0c8c), in [package:flutter/src/widgets/platform_view.dart] _TextureBasedAndroidViewSurface::createRenderObject (0x6f0664)
    //     0xcf08bc: ldr             x1, [x1, #0xe58]
    // 0xcf08c0: r0 = AllocateClosure()
    //     0xcf08c0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcf08c4: ldur            x1, [fp, #-8]
    // 0xcf08c8: StoreField: r1->field_13 = r0
    //     0xcf08c8: stur            w0, [x1, #0x13]
    //     0xcf08cc: ldurb           w16, [x1, #-1]
    //     0xcf08d0: ldurb           w17, [x0, #-1]
    //     0xcf08d4: and             x16, x17, x16, lsr #2
    //     0xcf08d8: tst             x16, HEAP, lsr #32
    //     0xcf08dc: b.eq            #0xcf08e4
    //     0xcf08e0: bl              #0xd6826c
    // 0xcf08e4: ldr             x16, [fp, #0x18]
    // 0xcf08e8: SaveReg r16
    //     0xcf08e8: str             x16, [SP, #-8]!
    // 0xcf08ec: r0 = _sizePlatformView()
    //     0xcf08ec: bl              #0x640efc  ; [package:flutter/src/rendering/platform_view.dart] RenderAndroidView::_sizePlatformView
    // 0xcf08f0: add             SP, SP, #8
    // 0xcf08f4: ldr             x0, [fp, #0x18]
    // 0xcf08f8: LoadField: r1 = r0->field_7b
    //     0xcf08f8: ldur            w1, [x0, #0x7b]
    // 0xcf08fc: DecompressPointer r1
    //     0xcf08fc: add             x1, x1, HEAP, lsl #32
    // 0xcf0900: LoadField: r2 = r1->field_1b
    //     0xcf0900: ldur            w2, [x1, #0x1b]
    // 0xcf0904: DecompressPointer r2
    //     0xcf0904: add             x2, x2, HEAP, lsl #32
    // 0xcf0908: r16 = Instance__AndroidViewState
    //     0xcf0908: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2a3d0] Obj!_AndroidViewState@b644d1
    //     0xcf090c: ldr             x16, [x16, #0x3d0]
    // 0xcf0910: cmp             w2, w16
    // 0xcf0914: b.ne            #0xcf0924
    // 0xcf0918: SaveReg r0
    //     0xcf0918: str             x0, [SP, #-8]!
    // 0xcf091c: r0 = markNeedsSemanticsUpdate()
    //     0xcf091c: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcf0920: add             SP, SP, #8
    // 0xcf0924: ldr             x0, [fp, #0x18]
    // 0xcf0928: LoadField: r1 = r0->field_7b
    //     0xcf0928: ldur            w1, [x0, #0x7b]
    // 0xcf092c: DecompressPointer r1
    //     0xcf092c: add             x1, x1, HEAP, lsl #32
    // 0xcf0930: stur            x1, [fp, #-8]
    // 0xcf0934: r1 = 1
    //     0xcf0934: mov             x1, #1
    // 0xcf0938: r0 = AllocateContext()
    //     0xcf0938: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcf093c: mov             x1, x0
    // 0xcf0940: ldr             x0, [fp, #0x18]
    // 0xcf0944: StoreField: r1->field_f = r0
    //     0xcf0944: stur            w0, [x1, #0xf]
    // 0xcf0948: ldur            x0, [fp, #-8]
    // 0xcf094c: LoadField: r3 = r0->field_23
    //     0xcf094c: ldur            w3, [x0, #0x23]
    // 0xcf0950: DecompressPointer r3
    //     0xcf0950: add             x3, x3, HEAP, lsl #32
    // 0xcf0954: stur            x3, [fp, #-0x10]
    // 0xcf0958: LoadField: r0 = r3->field_7
    //     0xcf0958: ldur            w0, [x3, #7]
    // 0xcf095c: DecompressPointer r0
    //     0xcf095c: add             x0, x0, HEAP, lsl #32
    // 0xcf0960: mov             x2, x1
    // 0xcf0964: stur            x0, [fp, #-8]
    // 0xcf0968: r1 = Function '_onPlatformViewCreated@906508051':.
    //     0xcf0968: add             x1, PP, #0x49, lsl #12  ; [pp+0x499a0] AnonymousClosure: (0x6534ec), of [package:flutter/src/rendering/platform_view.dart] RenderAndroidView
    //     0xcf096c: ldr             x1, [x1, #0x9a0]
    // 0xcf0970: r0 = AllocateClosure()
    //     0xcf0970: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcf0974: ldur            x2, [fp, #-8]
    // 0xcf0978: mov             x3, x0
    // 0xcf097c: r1 = Null
    //     0xcf097c: mov             x1, NULL
    // 0xcf0980: stur            x3, [fp, #-8]
    // 0xcf0984: cmp             w2, NULL
    // 0xcf0988: b.eq            #0xcf09a8
    // 0xcf098c: LoadField: r4 = r2->field_17
    //     0xcf098c: ldur            w4, [x2, #0x17]
    // 0xcf0990: DecompressPointer r4
    //     0xcf0990: add             x4, x4, HEAP, lsl #32
    // 0xcf0994: r8 = X0
    //     0xcf0994: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xcf0998: LoadField: r9 = r4->field_7
    //     0xcf0998: ldur            x9, [x4, #7]
    // 0xcf099c: r3 = Null
    //     0xcf099c: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fe60] Null
    //     0xcf09a0: ldr             x3, [x3, #0xe60]
    // 0xcf09a4: blr             x9
    // 0xcf09a8: ldur            x0, [fp, #-0x10]
    // 0xcf09ac: LoadField: r1 = r0->field_b
    //     0xcf09ac: ldur            w1, [x0, #0xb]
    // 0xcf09b0: DecompressPointer r1
    //     0xcf09b0: add             x1, x1, HEAP, lsl #32
    // 0xcf09b4: stur            x1, [fp, #-0x18]
    // 0xcf09b8: LoadField: r2 = r0->field_f
    //     0xcf09b8: ldur            w2, [x0, #0xf]
    // 0xcf09bc: DecompressPointer r2
    //     0xcf09bc: add             x2, x2, HEAP, lsl #32
    // 0xcf09c0: LoadField: r3 = r2->field_b
    //     0xcf09c0: ldur            w3, [x2, #0xb]
    // 0xcf09c4: DecompressPointer r3
    //     0xcf09c4: add             x3, x3, HEAP, lsl #32
    // 0xcf09c8: cmp             w1, w3
    // 0xcf09cc: b.ne            #0xcf09dc
    // 0xcf09d0: SaveReg r0
    //     0xcf09d0: str             x0, [SP, #-8]!
    // 0xcf09d4: r0 = _growToNextCapacity()
    //     0xcf09d4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xcf09d8: add             SP, SP, #8
    // 0xcf09dc: ldur            x2, [fp, #-0x10]
    // 0xcf09e0: ldur            x3, [fp, #-0x18]
    // 0xcf09e4: r4 = LoadInt32Instr(r3)
    //     0xcf09e4: sbfx            x4, x3, #1, #0x1f
    // 0xcf09e8: add             x0, x4, #1
    // 0xcf09ec: lsl             x3, x0, #1
    // 0xcf09f0: StoreField: r2->field_b = r3
    //     0xcf09f0: stur            w3, [x2, #0xb]
    // 0xcf09f4: mov             x1, x4
    // 0xcf09f8: cmp             x1, x0
    // 0xcf09fc: b.hs            #0xcf0a4c
    // 0xcf0a00: LoadField: r1 = r2->field_f
    //     0xcf0a00: ldur            w1, [x2, #0xf]
    // 0xcf0a04: DecompressPointer r1
    //     0xcf0a04: add             x1, x1, HEAP, lsl #32
    // 0xcf0a08: ldur            x0, [fp, #-8]
    // 0xcf0a0c: ArrayStore: r1[r4] = r0  ; List_4
    //     0xcf0a0c: add             x25, x1, x4, lsl #2
    //     0xcf0a10: add             x25, x25, #0xf
    //     0xcf0a14: str             w0, [x25]
    //     0xcf0a18: tbz             w0, #0, #0xcf0a34
    //     0xcf0a1c: ldurb           w16, [x1, #-1]
    //     0xcf0a20: ldurb           w17, [x0, #-1]
    //     0xcf0a24: and             x16, x17, x16, lsr #2
    //     0xcf0a28: tst             x16, HEAP, lsr #32
    //     0xcf0a2c: b.eq            #0xcf0a34
    //     0xcf0a30: bl              #0xd67e5c
    // 0xcf0a34: r0 = Null
    //     0xcf0a34: mov             x0, NULL
    // 0xcf0a38: LeaveFrame
    //     0xcf0a38: mov             SP, fp
    //     0xcf0a3c: ldp             fp, lr, [SP], #0x10
    // 0xcf0a40: ret
    //     0xcf0a40: ret             
    // 0xcf0a44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0a44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf0a48: b               #0xcf07f8
    // 0xcf0a4c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcf0a4c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 2433, size: 0x60, field offset: 0x60
abstract class _PlatformViewGestureMixin extends RenderBox
    implements MouseTrackerAnnotation {
}

// class id: 5920, size: 0x14, field offset: 0x14
enum _PlatformViewState extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16dcc, size: 0x5c
    // 0xb16dcc: EnterFrame
    //     0xb16dcc: stp             fp, lr, [SP, #-0x10]!
    //     0xb16dd0: mov             fp, SP
    // 0xb16dd4: CheckStackOverflow
    //     0xb16dd4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16dd8: cmp             SP, x16
    //     0xb16ddc: b.ls            #0xb16e20
    // 0xb16de0: r1 = Null
    //     0xb16de0: mov             x1, NULL
    // 0xb16de4: r2 = 4
    //     0xb16de4: mov             x2, #4
    // 0xb16de8: r0 = AllocateArray()
    //     0xb16de8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16dec: r17 = "_PlatformViewState."
    //     0xb16dec: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fdb8] "_PlatformViewState."
    //     0xb16df0: ldr             x17, [x17, #0xdb8]
    // 0xb16df4: StoreField: r0->field_f = r17
    //     0xb16df4: stur            w17, [x0, #0xf]
    // 0xb16df8: ldr             x1, [fp, #0x10]
    // 0xb16dfc: LoadField: r2 = r1->field_f
    //     0xb16dfc: ldur            w2, [x1, #0xf]
    // 0xb16e00: DecompressPointer r2
    //     0xb16e00: add             x2, x2, HEAP, lsl #32
    // 0xb16e04: StoreField: r0->field_13 = r2
    //     0xb16e04: stur            w2, [x0, #0x13]
    // 0xb16e08: SaveReg r0
    //     0xb16e08: str             x0, [SP, #-8]!
    // 0xb16e0c: r0 = _interpolate()
    //     0xb16e0c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16e10: add             SP, SP, #8
    // 0xb16e14: LeaveFrame
    //     0xb16e14: mov             SP, fp
    //     0xb16e18: ldp             fp, lr, [SP], #0x10
    // 0xb16e1c: ret
    //     0xb16e1c: ret             
    // 0xb16e20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16e20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16e24: b               #0xb16de0
  }
}

// class id: 5921, size: 0x14, field offset: 0x14
enum PlatformViewHitTestBehavior extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16d70, size: 0x5c
    // 0xb16d70: EnterFrame
    //     0xb16d70: stp             fp, lr, [SP, #-0x10]!
    //     0xb16d74: mov             fp, SP
    // 0xb16d78: CheckStackOverflow
    //     0xb16d78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16d7c: cmp             SP, x16
    //     0xb16d80: b.ls            #0xb16dc4
    // 0xb16d84: r1 = Null
    //     0xb16d84: mov             x1, NULL
    // 0xb16d88: r2 = 4
    //     0xb16d88: mov             x2, #4
    // 0xb16d8c: r0 = AllocateArray()
    //     0xb16d8c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16d90: r17 = "PlatformViewHitTestBehavior."
    //     0xb16d90: add             x17, PP, #0x37, lsl #12  ; [pp+0x370e0] "PlatformViewHitTestBehavior."
    //     0xb16d94: ldr             x17, [x17, #0xe0]
    // 0xb16d98: StoreField: r0->field_f = r17
    //     0xb16d98: stur            w17, [x0, #0xf]
    // 0xb16d9c: ldr             x1, [fp, #0x10]
    // 0xb16da0: LoadField: r2 = r1->field_f
    //     0xb16da0: ldur            w2, [x1, #0xf]
    // 0xb16da4: DecompressPointer r2
    //     0xb16da4: add             x2, x2, HEAP, lsl #32
    // 0xb16da8: StoreField: r0->field_13 = r2
    //     0xb16da8: stur            w2, [x0, #0x13]
    // 0xb16dac: SaveReg r0
    //     0xb16dac: str             x0, [SP, #-8]!
    // 0xb16db0: r0 = _interpolate()
    //     0xb16db0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16db4: add             SP, SP, #8
    // 0xb16db8: LeaveFrame
    //     0xb16db8: mov             SP, fp
    //     0xb16dbc: ldp             fp, lr, [SP], #0x10
    // 0xb16dc0: ret
    //     0xb16dc0: ret             
    // 0xb16dc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16dc4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16dc8: b               #0xb16d84
  }
}

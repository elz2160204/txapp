// lib: , url: package:flutter/src/rendering/sliver_grid.dart

// class id: 1049423, size: 0x8
class :: {
}

// class id: 1994, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class SliverGridDelegate extends Object {
}

// class id: 1995, size: 0x2c, field offset: 0x8
//   const constructor, 
class SliverGridDelegateWithFixedCrossAxisCount extends SliverGridDelegate {

  _Mint field_8;
  _Double field_10;
  _Double field_18;
  _Double field_20;

  _ getLayout(/* No info */) {
    // ** addr: 0x67d2c8, size: 0x138
    // 0x67d2c8: EnterFrame
    //     0x67d2c8: stp             fp, lr, [SP, #-0x10]!
    //     0x67d2cc: mov             fp, SP
    // 0x67d2d0: AllocStack(0x30)
    //     0x67d2d0: sub             SP, SP, #0x30
    // 0x67d2d4: d0 = 0.000000
    //     0x67d2d4: eor             v0.16b, v0.16b, v0.16b
    // 0x67d2d8: ldr             x0, [fp, #0x10]
    // 0x67d2dc: LoadField: d1 = r0->field_33
    //     0x67d2dc: ldur            d1, [x0, #0x33]
    // 0x67d2e0: ldr             x1, [fp, #0x18]
    // 0x67d2e4: LoadField: d2 = r1->field_17
    //     0x67d2e4: ldur            d2, [x1, #0x17]
    // 0x67d2e8: LoadField: r2 = r1->field_7
    //     0x67d2e8: ldur            x2, [x1, #7]
    // 0x67d2ec: stur            x2, [fp, #-0x10]
    // 0x67d2f0: sub             x3, x2, #1
    // 0x67d2f4: scvtf           d3, x3
    // 0x67d2f8: fmul            d4, d2, d3
    // 0x67d2fc: fsub            d3, d1, d4
    // 0x67d300: fcmp            d0, d3
    // 0x67d304: b.vs            #0x67d314
    // 0x67d308: b.le            #0x67d314
    // 0x67d30c: d0 = 0.000000
    //     0x67d30c: eor             v0.16b, v0.16b, v0.16b
    // 0x67d310: b               #0x67d354
    // 0x67d314: fcmp            d0, d3
    // 0x67d318: b.vs            #0x67d328
    // 0x67d31c: b.ge            #0x67d328
    // 0x67d320: mov             v0.16b, v3.16b
    // 0x67d324: b               #0x67d354
    // 0x67d328: fcmp            d0, d0
    // 0x67d32c: b.vs            #0x67d340
    // 0x67d330: b.ne            #0x67d340
    // 0x67d334: fadd            d1, d0, d3
    // 0x67d338: mov             v0.16b, v1.16b
    // 0x67d33c: b               #0x67d354
    // 0x67d340: fcmp            d3, d3
    // 0x67d344: b.vc            #0x67d350
    // 0x67d348: mov             v0.16b, v3.16b
    // 0x67d34c: b               #0x67d354
    // 0x67d350: d0 = 0.000000
    //     0x67d350: eor             v0.16b, v0.16b, v0.16b
    // 0x67d354: lsl             x3, x2, #1
    // 0x67d358: r16 = LoadInt32Instr(r3)
    //     0x67d358: sbfx            x16, x3, #1, #0x1f
    // 0x67d35c: scvtf           d1, w16
    // 0x67d360: fdiv            d3, d0, d1
    // 0x67d364: stur            d3, [fp, #-0x30]
    // 0x67d368: LoadField: d0 = r1->field_1f
    //     0x67d368: ldur            d0, [x1, #0x1f]
    // 0x67d36c: fdiv            d1, d3, d0
    // 0x67d370: stur            d1, [fp, #-0x28]
    // 0x67d374: LoadField: d0 = r1->field_f
    //     0x67d374: ldur            d0, [x1, #0xf]
    // 0x67d378: fadd            d4, d1, d0
    // 0x67d37c: stur            d4, [fp, #-0x20]
    // 0x67d380: fadd            d0, d3, d2
    // 0x67d384: stur            d0, [fp, #-0x18]
    // 0x67d388: LoadField: r1 = r0->field_3b
    //     0x67d388: ldur            w1, [x0, #0x3b]
    // 0x67d38c: DecompressPointer r1
    //     0x67d38c: add             x1, x1, HEAP, lsl #32
    // 0x67d390: LoadField: r0 = r1->field_7
    //     0x67d390: ldur            x0, [x1, #7]
    // 0x67d394: cmp             x0, #1
    // 0x67d398: b.gt            #0x67d3a8
    // 0x67d39c: cmp             x0, #0
    // 0x67d3a0: b.gt            #0x67d3b0
    // 0x67d3a4: b               #0x67d3b8
    // 0x67d3a8: cmp             x0, #2
    // 0x67d3ac: b.gt            #0x67d3b8
    // 0x67d3b0: r0 = false
    //     0x67d3b0: add             x0, NULL, #0x30  ; false
    // 0x67d3b4: b               #0x67d3bc
    // 0x67d3b8: r0 = true
    //     0x67d3b8: add             x0, NULL, #0x20  ; true
    // 0x67d3bc: stur            x0, [fp, #-8]
    // 0x67d3c0: r0 = SliverGridRegularTileLayout()
    //     0x67d3c0: bl              #0x67d400  ; AllocateSliverGridRegularTileLayoutStub -> SliverGridRegularTileLayout (size=0x34)
    // 0x67d3c4: ldur            x1, [fp, #-0x10]
    // 0x67d3c8: StoreField: r0->field_7 = r1
    //     0x67d3c8: stur            x1, [x0, #7]
    // 0x67d3cc: ldur            d0, [fp, #-0x20]
    // 0x67d3d0: StoreField: r0->field_f = d0
    //     0x67d3d0: stur            d0, [x0, #0xf]
    // 0x67d3d4: ldur            d0, [fp, #-0x18]
    // 0x67d3d8: StoreField: r0->field_17 = d0
    //     0x67d3d8: stur            d0, [x0, #0x17]
    // 0x67d3dc: ldur            d0, [fp, #-0x28]
    // 0x67d3e0: StoreField: r0->field_1f = d0
    //     0x67d3e0: stur            d0, [x0, #0x1f]
    // 0x67d3e4: ldur            d0, [fp, #-0x30]
    // 0x67d3e8: StoreField: r0->field_27 = d0
    //     0x67d3e8: stur            d0, [x0, #0x27]
    // 0x67d3ec: ldur            x1, [fp, #-8]
    // 0x67d3f0: StoreField: r0->field_2f = r1
    //     0x67d3f0: stur            w1, [x0, #0x2f]
    // 0x67d3f4: LeaveFrame
    //     0x67d3f4: mov             SP, fp
    //     0x67d3f8: ldp             fp, lr, [SP], #0x10
    // 0x67d3fc: ret
    //     0x67d3fc: ret             
  }
}

// class id: 1996, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class SliverGridLayout extends Object {
}

// class id: 1997, size: 0x34, field offset: 0x8
//   const constructor, 
class SliverGridRegularTileLayout extends SliverGridLayout {

  _ getGeometryForChildIndex(/* No info */) {
    // ** addr: 0x67d09c, size: 0x11c
    // 0x67d09c: EnterFrame
    //     0x67d09c: stp             fp, lr, [SP, #-0x10]!
    //     0x67d0a0: mov             fp, SP
    // 0x67d0a4: AllocStack(0x20)
    //     0x67d0a4: sub             SP, SP, #0x20
    // 0x67d0a8: ldr             x0, [fp, #0x18]
    // 0x67d0ac: LoadField: r1 = r0->field_7
    //     0x67d0ac: ldur            x1, [x0, #7]
    // 0x67d0b0: ldr             x2, [fp, #0x10]
    // 0x67d0b4: cbz             x1, #0x67d168
    // 0x67d0b8: sdiv            x4, x2, x1
    // 0x67d0bc: msub            x3, x4, x1, x2
    // 0x67d0c0: cmp             x3, xzr
    // 0x67d0c4: b.lt            #0x67d184
    // 0x67d0c8: LoadField: d0 = r0->field_17
    //     0x67d0c8: ldur            d0, [x0, #0x17]
    // 0x67d0cc: scvtf           d1, x3
    // 0x67d0d0: fmul            d2, d1, d0
    // 0x67d0d4: cbz             x1, #0x67d198
    // 0x67d0d8: sdiv            x3, x2, x1
    // 0x67d0dc: LoadField: d1 = r0->field_f
    //     0x67d0dc: ldur            d1, [x0, #0xf]
    // 0x67d0e0: scvtf           d3, x3
    // 0x67d0e4: fmul            d4, d3, d1
    // 0x67d0e8: stur            d4, [fp, #-0x20]
    // 0x67d0ec: LoadField: r2 = r0->field_2f
    //     0x67d0ec: ldur            w2, [x0, #0x2f]
    // 0x67d0f0: DecompressPointer r2
    //     0x67d0f0: add             x2, x2, HEAP, lsl #32
    // 0x67d0f4: tbnz            w2, #4, #0x67d120
    // 0x67d0f8: lsl             x2, x1, #1
    // 0x67d0fc: r16 = LoadInt32Instr(r2)
    //     0x67d0fc: sbfx            x16, x2, #1, #0x1f
    // 0x67d100: scvtf           d1, w16
    // 0x67d104: fmul            d3, d1, d0
    // 0x67d108: fsub            d1, d3, d2
    // 0x67d10c: LoadField: d2 = r0->field_27
    //     0x67d10c: ldur            d2, [x0, #0x27]
    // 0x67d110: fsub            d3, d1, d2
    // 0x67d114: fsub            d1, d0, d2
    // 0x67d118: fsub            d0, d3, d1
    // 0x67d11c: b               #0x67d124
    // 0x67d120: mov             v0.16b, v2.16b
    // 0x67d124: stur            d0, [fp, #-0x18]
    // 0x67d128: LoadField: d1 = r0->field_1f
    //     0x67d128: ldur            d1, [x0, #0x1f]
    // 0x67d12c: stur            d1, [fp, #-0x10]
    // 0x67d130: LoadField: d2 = r0->field_27
    //     0x67d130: ldur            d2, [x0, #0x27]
    // 0x67d134: stur            d2, [fp, #-8]
    // 0x67d138: r0 = SliverGridGeometry()
    //     0x67d138: bl              #0x67d1b8  ; AllocateSliverGridGeometryStub -> SliverGridGeometry (size=0x28)
    // 0x67d13c: ldur            d0, [fp, #-0x20]
    // 0x67d140: StoreField: r0->field_7 = d0
    //     0x67d140: stur            d0, [x0, #7]
    // 0x67d144: ldur            d0, [fp, #-0x18]
    // 0x67d148: StoreField: r0->field_f = d0
    //     0x67d148: stur            d0, [x0, #0xf]
    // 0x67d14c: ldur            d0, [fp, #-0x10]
    // 0x67d150: StoreField: r0->field_17 = d0
    //     0x67d150: stur            d0, [x0, #0x17]
    // 0x67d154: ldur            d0, [fp, #-8]
    // 0x67d158: StoreField: r0->field_1f = d0
    //     0x67d158: stur            d0, [x0, #0x1f]
    // 0x67d15c: LeaveFrame
    //     0x67d15c: mov             SP, fp
    //     0x67d160: ldp             fp, lr, [SP], #0x10
    // 0x67d164: ret
    //     0x67d164: ret             
    // 0x67d168: stp             x1, x2, [SP, #-0x10]!
    // 0x67d16c: SaveReg r0
    //     0x67d16c: str             x0, [SP, #-8]!
    // 0x67d170: ldr             x5, [THR, #0x4a8]  ; THR::IntegerDivisionByZeroException
    // 0x67d174: r4 = 0
    //     0x67d174: mov             x4, #0
    // 0x67d178: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x67d17c: blr             lr
    // 0x67d180: brk             #0
    // 0x67d184: cmp             x1, xzr
    // 0x67d188: sub             x4, x3, x1
    // 0x67d18c: add             x3, x3, x1
    // 0x67d190: csel            x3, x4, x3, lt
    // 0x67d194: b               #0x67d0c8
    // 0x67d198: stp             q0, q2, [SP, #-0x20]!
    // 0x67d19c: stp             x1, x2, [SP, #-0x10]!
    // 0x67d1a0: SaveReg r0
    //     0x67d1a0: str             x0, [SP, #-8]!
    // 0x67d1a4: ldr             x5, [THR, #0x4a8]  ; THR::IntegerDivisionByZeroException
    // 0x67d1a8: r4 = 0
    //     0x67d1a8: mov             x4, #0
    // 0x67d1ac: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x67d1b0: blr             lr
    // 0x67d1b4: brk             #0
  }
  _ getMinChildIndexForScrollOffset(/* No info */) {
    // ** addr: 0x67d1c4, size: 0x104
    // 0x67d1c4: EnterFrame
    //     0x67d1c4: stp             fp, lr, [SP, #-0x10]!
    //     0x67d1c8: mov             fp, SP
    // 0x67d1cc: AllocStack(0x8)
    //     0x67d1cc: sub             SP, SP, #8
    // 0x67d1d0: d0 = 0.000000
    //     0x67d1d0: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1e0] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    //     0x67d1d4: ldr             d0, [x17, #0x1e0]
    // 0x67d1d8: CheckStackOverflow
    //     0x67d1d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67d1dc: cmp             SP, x16
    //     0x67d1e0: b.ls            #0x67d28c
    // 0x67d1e4: ldr             x0, [fp, #0x18]
    // 0x67d1e8: LoadField: d1 = r0->field_f
    //     0x67d1e8: ldur            d1, [x0, #0xf]
    // 0x67d1ec: fcmp            d1, d0
    // 0x67d1f0: b.vs            #0x67d27c
    // 0x67d1f4: b.le            #0x67d27c
    // 0x67d1f8: ldr             d0, [fp, #0x10]
    // 0x67d1fc: LoadField: r1 = r0->field_7
    //     0x67d1fc: ldur            x1, [x0, #7]
    // 0x67d200: stur            x1, [fp, #-8]
    // 0x67d204: r0 = inline_Allocate_Double()
    //     0x67d204: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x67d208: add             x0, x0, #0x10
    //     0x67d20c: cmp             x2, x0
    //     0x67d210: b.ls            #0x67d294
    //     0x67d214: str             x0, [THR, #0x60]  ; THR::top
    //     0x67d218: sub             x0, x0, #0xf
    //     0x67d21c: mov             x2, #0xd108
    //     0x67d220: movk            x2, #3, lsl #16
    //     0x67d224: stur            x2, [x0, #-1]
    // 0x67d228: StoreField: r0->field_7 = d0
    //     0x67d228: stur            d0, [x0, #7]
    // 0x67d22c: r2 = inline_Allocate_Double()
    //     0x67d22c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x67d230: add             x2, x2, #0x10
    //     0x67d234: cmp             x3, x2
    //     0x67d238: b.ls            #0x67d2ac
    //     0x67d23c: str             x2, [THR, #0x60]  ; THR::top
    //     0x67d240: sub             x2, x2, #0xf
    //     0x67d244: mov             x3, #0xd108
    //     0x67d248: movk            x3, #3, lsl #16
    //     0x67d24c: stur            x3, [x2, #-1]
    // 0x67d250: StoreField: r2->field_7 = d1
    //     0x67d250: stur            d1, [x2, #7]
    // 0x67d254: stp             x2, x0, [SP, #-0x10]!
    // 0x67d258: r0 = ~/()
    //     0x67d258: bl              #0x65adc0  ; [dart:core] _Double::~/
    // 0x67d25c: add             SP, SP, #0x10
    // 0x67d260: r1 = LoadInt32Instr(r0)
    //     0x67d260: sbfx            x1, x0, #1, #0x1f
    //     0x67d264: tbz             w0, #0, #0x67d26c
    //     0x67d268: ldur            x1, [x0, #7]
    // 0x67d26c: ldur            x2, [fp, #-8]
    // 0x67d270: mul             x3, x2, x1
    // 0x67d274: mov             x0, x3
    // 0x67d278: b               #0x67d280
    // 0x67d27c: r0 = 0
    //     0x67d27c: mov             x0, #0
    // 0x67d280: LeaveFrame
    //     0x67d280: mov             SP, fp
    //     0x67d284: ldp             fp, lr, [SP], #0x10
    // 0x67d288: ret
    //     0x67d288: ret             
    // 0x67d28c: r0 = StackOverflowSharedWithFPURegs()
    //     0x67d28c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x67d290: b               #0x67d1e4
    // 0x67d294: stp             q0, q1, [SP, #-0x20]!
    // 0x67d298: SaveReg r1
    //     0x67d298: str             x1, [SP, #-8]!
    // 0x67d29c: r0 = AllocateDouble()
    //     0x67d29c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67d2a0: RestoreReg r1
    //     0x67d2a0: ldr             x1, [SP], #8
    // 0x67d2a4: ldp             q0, q1, [SP], #0x20
    // 0x67d2a8: b               #0x67d228
    // 0x67d2ac: SaveReg d1
    //     0x67d2ac: str             q1, [SP, #-0x10]!
    // 0x67d2b0: stp             x0, x1, [SP, #-0x10]!
    // 0x67d2b4: r0 = AllocateDouble()
    //     0x67d2b4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67d2b8: mov             x2, x0
    // 0x67d2bc: ldp             x0, x1, [SP], #0x10
    // 0x67d2c0: RestoreReg d1
    //     0x67d2c0: ldr             q1, [SP], #0x10
    // 0x67d2c4: b               #0x67d250
  }
}

// class id: 1998, size: 0x28, field offset: 0x8
//   const constructor, 
class SliverGridGeometry extends Object {

  _ getBoxConstraints(/* No info */) {
    // ** addr: 0x67cfd0, size: 0xcc
    // 0x67cfd0: EnterFrame
    //     0x67cfd0: stp             fp, lr, [SP, #-0x10]!
    //     0x67cfd4: mov             fp, SP
    // 0x67cfd8: CheckStackOverflow
    //     0x67cfd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67cfdc: cmp             SP, x16
    //     0x67cfe0: b.ls            #0x67d068
    // 0x67cfe4: ldr             x0, [fp, #0x18]
    // 0x67cfe8: LoadField: d0 = r0->field_17
    //     0x67cfe8: ldur            d0, [x0, #0x17]
    // 0x67cfec: LoadField: d1 = r0->field_1f
    //     0x67cfec: ldur            d1, [x0, #0x1f]
    // 0x67cff0: r0 = inline_Allocate_Double()
    //     0x67cff0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x67cff4: add             x0, x0, #0x10
    //     0x67cff8: cmp             x1, x0
    //     0x67cffc: b.ls            #0x67d070
    //     0x67d000: str             x0, [THR, #0x60]  ; THR::top
    //     0x67d004: sub             x0, x0, #0xf
    //     0x67d008: mov             x1, #0xd108
    //     0x67d00c: movk            x1, #3, lsl #16
    //     0x67d010: stur            x1, [x0, #-1]
    // 0x67d014: StoreField: r0->field_7 = d0
    //     0x67d014: stur            d0, [x0, #7]
    // 0x67d018: r1 = inline_Allocate_Double()
    //     0x67d018: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x67d01c: add             x1, x1, #0x10
    //     0x67d020: cmp             x2, x1
    //     0x67d024: b.ls            #0x67d080
    //     0x67d028: str             x1, [THR, #0x60]  ; THR::top
    //     0x67d02c: sub             x1, x1, #0xf
    //     0x67d030: mov             x2, #0xd108
    //     0x67d034: movk            x2, #3, lsl #16
    //     0x67d038: stur            x2, [x1, #-1]
    // 0x67d03c: StoreField: r1->field_7 = d1
    //     0x67d03c: stur            d1, [x1, #7]
    // 0x67d040: ldr             x16, [fp, #0x10]
    // 0x67d044: stp             x0, x16, [SP, #-0x10]!
    // 0x67d048: stp             x1, x0, [SP, #-0x10]!
    // 0x67d04c: r4 = const [0, 0x4, 0x4, 0x1, crossAxisExtent, 0x3, maxExtent, 0x2, minExtent, 0x1, null]
    //     0x67d04c: add             x4, PP, #0x4b, lsl #12  ; [pp+0x4b120] List(11) [0, 0x4, 0x4, 0x1, "crossAxisExtent", 0x3, "maxExtent", 0x2, "minExtent", 0x1, Null]
    //     0x67d050: ldr             x4, [x4, #0x120]
    // 0x67d054: r0 = asBoxConstraints()
    //     0x67d054: bl              #0x67a528  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::asBoxConstraints
    // 0x67d058: add             SP, SP, #0x20
    // 0x67d05c: LeaveFrame
    //     0x67d05c: mov             SP, fp
    //     0x67d060: ldp             fp, lr, [SP], #0x10
    // 0x67d064: ret
    //     0x67d064: ret             
    // 0x67d068: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x67d068: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x67d06c: b               #0x67cfe4
    // 0x67d070: stp             q0, q1, [SP, #-0x20]!
    // 0x67d074: r0 = AllocateDouble()
    //     0x67d074: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67d078: ldp             q0, q1, [SP], #0x20
    // 0x67d07c: b               #0x67d014
    // 0x67d080: SaveReg d1
    //     0x67d080: str             q1, [SP, #-0x10]!
    // 0x67d084: SaveReg r0
    //     0x67d084: str             x0, [SP, #-8]!
    // 0x67d088: r0 = AllocateDouble()
    //     0x67d088: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67d08c: mov             x1, x0
    // 0x67d090: RestoreReg r0
    //     0x67d090: ldr             x0, [SP], #8
    // 0x67d094: RestoreReg d1
    //     0x67d094: ldr             q1, [SP], #0x10
    // 0x67d098: b               #0x67d03c
  }
  _ toString(/* No info */) {
    // ** addr: 0xae59d0, size: 0x2d4
    // 0xae59d0: EnterFrame
    //     0xae59d0: stp             fp, lr, [SP, #-0x10]!
    //     0xae59d4: mov             fp, SP
    // 0xae59d8: AllocStack(0x28)
    //     0xae59d8: sub             SP, SP, #0x28
    // 0xae59dc: CheckStackOverflow
    //     0xae59dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae59e0: cmp             SP, x16
    //     0xae59e4: b.ls            #0xae5c2c
    // 0xae59e8: r1 = Null
    //     0xae59e8: mov             x1, NULL
    // 0xae59ec: r2 = 4
    //     0xae59ec: mov             x2, #4
    // 0xae59f0: r0 = AllocateArray()
    //     0xae59f0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae59f4: r17 = "scrollOffset: "
    //     0xae59f4: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fbf0] "scrollOffset: "
    //     0xae59f8: ldr             x17, [x17, #0xbf0]
    // 0xae59fc: StoreField: r0->field_f = r17
    //     0xae59fc: stur            w17, [x0, #0xf]
    // 0xae5a00: ldr             x1, [fp, #0x10]
    // 0xae5a04: LoadField: d0 = r1->field_7
    //     0xae5a04: ldur            d0, [x1, #7]
    // 0xae5a08: r2 = inline_Allocate_Double()
    //     0xae5a08: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xae5a0c: add             x2, x2, #0x10
    //     0xae5a10: cmp             x3, x2
    //     0xae5a14: b.ls            #0xae5c34
    //     0xae5a18: str             x2, [THR, #0x60]  ; THR::top
    //     0xae5a1c: sub             x2, x2, #0xf
    //     0xae5a20: mov             x3, #0xd108
    //     0xae5a24: movk            x3, #3, lsl #16
    //     0xae5a28: stur            x3, [x2, #-1]
    // 0xae5a2c: StoreField: r2->field_7 = d0
    //     0xae5a2c: stur            d0, [x2, #7]
    // 0xae5a30: StoreField: r0->field_13 = r2
    //     0xae5a30: stur            w2, [x0, #0x13]
    // 0xae5a34: SaveReg r0
    //     0xae5a34: str             x0, [SP, #-8]!
    // 0xae5a38: r0 = _interpolate()
    //     0xae5a38: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae5a3c: add             SP, SP, #8
    // 0xae5a40: r1 = Null
    //     0xae5a40: mov             x1, NULL
    // 0xae5a44: r2 = 4
    //     0xae5a44: mov             x2, #4
    // 0xae5a48: stur            x0, [fp, #-8]
    // 0xae5a4c: r0 = AllocateArray()
    //     0xae5a4c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae5a50: r17 = "crossAxisOffset: "
    //     0xae5a50: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fbf8] "crossAxisOffset: "
    //     0xae5a54: ldr             x17, [x17, #0xbf8]
    // 0xae5a58: StoreField: r0->field_f = r17
    //     0xae5a58: stur            w17, [x0, #0xf]
    // 0xae5a5c: ldr             x1, [fp, #0x10]
    // 0xae5a60: LoadField: d0 = r1->field_f
    //     0xae5a60: ldur            d0, [x1, #0xf]
    // 0xae5a64: r2 = inline_Allocate_Double()
    //     0xae5a64: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xae5a68: add             x2, x2, #0x10
    //     0xae5a6c: cmp             x3, x2
    //     0xae5a70: b.ls            #0xae5c50
    //     0xae5a74: str             x2, [THR, #0x60]  ; THR::top
    //     0xae5a78: sub             x2, x2, #0xf
    //     0xae5a7c: mov             x3, #0xd108
    //     0xae5a80: movk            x3, #3, lsl #16
    //     0xae5a84: stur            x3, [x2, #-1]
    // 0xae5a88: StoreField: r2->field_7 = d0
    //     0xae5a88: stur            d0, [x2, #7]
    // 0xae5a8c: StoreField: r0->field_13 = r2
    //     0xae5a8c: stur            w2, [x0, #0x13]
    // 0xae5a90: SaveReg r0
    //     0xae5a90: str             x0, [SP, #-8]!
    // 0xae5a94: r0 = _interpolate()
    //     0xae5a94: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae5a98: add             SP, SP, #8
    // 0xae5a9c: r1 = Null
    //     0xae5a9c: mov             x1, NULL
    // 0xae5aa0: r2 = 4
    //     0xae5aa0: mov             x2, #4
    // 0xae5aa4: stur            x0, [fp, #-0x10]
    // 0xae5aa8: r0 = AllocateArray()
    //     0xae5aa8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae5aac: r17 = "mainAxisExtent: "
    //     0xae5aac: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fc00] "mainAxisExtent: "
    //     0xae5ab0: ldr             x17, [x17, #0xc00]
    // 0xae5ab4: StoreField: r0->field_f = r17
    //     0xae5ab4: stur            w17, [x0, #0xf]
    // 0xae5ab8: ldr             x1, [fp, #0x10]
    // 0xae5abc: LoadField: d0 = r1->field_17
    //     0xae5abc: ldur            d0, [x1, #0x17]
    // 0xae5ac0: r2 = inline_Allocate_Double()
    //     0xae5ac0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xae5ac4: add             x2, x2, #0x10
    //     0xae5ac8: cmp             x3, x2
    //     0xae5acc: b.ls            #0xae5c6c
    //     0xae5ad0: str             x2, [THR, #0x60]  ; THR::top
    //     0xae5ad4: sub             x2, x2, #0xf
    //     0xae5ad8: mov             x3, #0xd108
    //     0xae5adc: movk            x3, #3, lsl #16
    //     0xae5ae0: stur            x3, [x2, #-1]
    // 0xae5ae4: StoreField: r2->field_7 = d0
    //     0xae5ae4: stur            d0, [x2, #7]
    // 0xae5ae8: StoreField: r0->field_13 = r2
    //     0xae5ae8: stur            w2, [x0, #0x13]
    // 0xae5aec: SaveReg r0
    //     0xae5aec: str             x0, [SP, #-8]!
    // 0xae5af0: r0 = _interpolate()
    //     0xae5af0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae5af4: add             SP, SP, #8
    // 0xae5af8: r1 = Null
    //     0xae5af8: mov             x1, NULL
    // 0xae5afc: r2 = 4
    //     0xae5afc: mov             x2, #4
    // 0xae5b00: stur            x0, [fp, #-0x18]
    // 0xae5b04: r0 = AllocateArray()
    //     0xae5b04: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae5b08: r17 = "crossAxisExtent: "
    //     0xae5b08: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fc08] "crossAxisExtent: "
    //     0xae5b0c: ldr             x17, [x17, #0xc08]
    // 0xae5b10: StoreField: r0->field_f = r17
    //     0xae5b10: stur            w17, [x0, #0xf]
    // 0xae5b14: ldr             x1, [fp, #0x10]
    // 0xae5b18: LoadField: d0 = r1->field_1f
    //     0xae5b18: ldur            d0, [x1, #0x1f]
    // 0xae5b1c: r1 = inline_Allocate_Double()
    //     0xae5b1c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xae5b20: add             x1, x1, #0x10
    //     0xae5b24: cmp             x2, x1
    //     0xae5b28: b.ls            #0xae5c88
    //     0xae5b2c: str             x1, [THR, #0x60]  ; THR::top
    //     0xae5b30: sub             x1, x1, #0xf
    //     0xae5b34: mov             x2, #0xd108
    //     0xae5b38: movk            x2, #3, lsl #16
    //     0xae5b3c: stur            x2, [x1, #-1]
    // 0xae5b40: StoreField: r1->field_7 = d0
    //     0xae5b40: stur            d0, [x1, #7]
    // 0xae5b44: StoreField: r0->field_13 = r1
    //     0xae5b44: stur            w1, [x0, #0x13]
    // 0xae5b48: SaveReg r0
    //     0xae5b48: str             x0, [SP, #-8]!
    // 0xae5b4c: r0 = _interpolate()
    //     0xae5b4c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae5b50: add             SP, SP, #8
    // 0xae5b54: r1 = Null
    //     0xae5b54: mov             x1, NULL
    // 0xae5b58: r2 = 8
    //     0xae5b58: mov             x2, #8
    // 0xae5b5c: stur            x0, [fp, #-0x20]
    // 0xae5b60: r0 = AllocateArray()
    //     0xae5b60: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae5b64: mov             x2, x0
    // 0xae5b68: ldur            x0, [fp, #-8]
    // 0xae5b6c: stur            x2, [fp, #-0x28]
    // 0xae5b70: StoreField: r2->field_f = r0
    //     0xae5b70: stur            w0, [x2, #0xf]
    // 0xae5b74: ldur            x0, [fp, #-0x10]
    // 0xae5b78: StoreField: r2->field_13 = r0
    //     0xae5b78: stur            w0, [x2, #0x13]
    // 0xae5b7c: ldur            x0, [fp, #-0x18]
    // 0xae5b80: StoreField: r2->field_17 = r0
    //     0xae5b80: stur            w0, [x2, #0x17]
    // 0xae5b84: ldur            x0, [fp, #-0x20]
    // 0xae5b88: StoreField: r2->field_1b = r0
    //     0xae5b88: stur            w0, [x2, #0x1b]
    // 0xae5b8c: r1 = <String>
    //     0xae5b8c: ldr             x1, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xae5b90: r0 = AllocateGrowableArray()
    //     0xae5b90: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xae5b94: mov             x3, x0
    // 0xae5b98: ldur            x0, [fp, #-0x28]
    // 0xae5b9c: stur            x3, [fp, #-8]
    // 0xae5ba0: StoreField: r3->field_f = r0
    //     0xae5ba0: stur            w0, [x3, #0xf]
    // 0xae5ba4: r0 = 8
    //     0xae5ba4: mov             x0, #8
    // 0xae5ba8: StoreField: r3->field_b = r0
    //     0xae5ba8: stur            w0, [x3, #0xb]
    // 0xae5bac: r1 = Null
    //     0xae5bac: mov             x1, NULL
    // 0xae5bb0: r2 = 6
    //     0xae5bb0: mov             x2, #6
    // 0xae5bb4: r0 = AllocateArray()
    //     0xae5bb4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae5bb8: stur            x0, [fp, #-0x10]
    // 0xae5bbc: r17 = "SliverGridGeometry("
    //     0xae5bbc: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fc10] "SliverGridGeometry("
    //     0xae5bc0: ldr             x17, [x17, #0xc10]
    // 0xae5bc4: StoreField: r0->field_f = r17
    //     0xae5bc4: stur            w17, [x0, #0xf]
    // 0xae5bc8: ldur            x16, [fp, #-8]
    // 0xae5bcc: r30 = ", "
    //     0xae5bcc: ldr             lr, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae5bd0: stp             lr, x16, [SP, #-0x10]!
    // 0xae5bd4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xae5bd4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xae5bd8: r0 = join()
    //     0xae5bd8: bl              #0x6fddb0  ; [dart:core] _GrowableList::join
    // 0xae5bdc: add             SP, SP, #0x10
    // 0xae5be0: ldur            x1, [fp, #-0x10]
    // 0xae5be4: ArrayStore: r1[1] = r0  ; List_4
    //     0xae5be4: add             x25, x1, #0x13
    //     0xae5be8: str             w0, [x25]
    //     0xae5bec: tbz             w0, #0, #0xae5c08
    //     0xae5bf0: ldurb           w16, [x1, #-1]
    //     0xae5bf4: ldurb           w17, [x0, #-1]
    //     0xae5bf8: and             x16, x17, x16, lsr #2
    //     0xae5bfc: tst             x16, HEAP, lsr #32
    //     0xae5c00: b.eq            #0xae5c08
    //     0xae5c04: bl              #0xd67e5c
    // 0xae5c08: ldur            x0, [fp, #-0x10]
    // 0xae5c0c: r17 = ")"
    //     0xae5c0c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae5c10: StoreField: r0->field_17 = r17
    //     0xae5c10: stur            w17, [x0, #0x17]
    // 0xae5c14: SaveReg r0
    //     0xae5c14: str             x0, [SP, #-8]!
    // 0xae5c18: r0 = _interpolate()
    //     0xae5c18: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae5c1c: add             SP, SP, #8
    // 0xae5c20: LeaveFrame
    //     0xae5c20: mov             SP, fp
    //     0xae5c24: ldp             fp, lr, [SP], #0x10
    // 0xae5c28: ret
    //     0xae5c28: ret             
    // 0xae5c2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae5c2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae5c30: b               #0xae59e8
    // 0xae5c34: SaveReg d0
    //     0xae5c34: str             q0, [SP, #-0x10]!
    // 0xae5c38: stp             x0, x1, [SP, #-0x10]!
    // 0xae5c3c: r0 = AllocateDouble()
    //     0xae5c3c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae5c40: mov             x2, x0
    // 0xae5c44: ldp             x0, x1, [SP], #0x10
    // 0xae5c48: RestoreReg d0
    //     0xae5c48: ldr             q0, [SP], #0x10
    // 0xae5c4c: b               #0xae5a2c
    // 0xae5c50: SaveReg d0
    //     0xae5c50: str             q0, [SP, #-0x10]!
    // 0xae5c54: stp             x0, x1, [SP, #-0x10]!
    // 0xae5c58: r0 = AllocateDouble()
    //     0xae5c58: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae5c5c: mov             x2, x0
    // 0xae5c60: ldp             x0, x1, [SP], #0x10
    // 0xae5c64: RestoreReg d0
    //     0xae5c64: ldr             q0, [SP], #0x10
    // 0xae5c68: b               #0xae5a88
    // 0xae5c6c: SaveReg d0
    //     0xae5c6c: str             q0, [SP, #-0x10]!
    // 0xae5c70: stp             x0, x1, [SP, #-0x10]!
    // 0xae5c74: r0 = AllocateDouble()
    //     0xae5c74: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae5c78: mov             x2, x0
    // 0xae5c7c: ldp             x0, x1, [SP], #0x10
    // 0xae5c80: RestoreReg d0
    //     0xae5c80: ldr             q0, [SP], #0x10
    // 0xae5c84: b               #0xae5ae4
    // 0xae5c88: SaveReg d0
    //     0xae5c88: str             q0, [SP, #-0x10]!
    // 0xae5c8c: SaveReg r0
    //     0xae5c8c: str             x0, [SP, #-8]!
    // 0xae5c90: r0 = AllocateDouble()
    //     0xae5c90: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae5c94: mov             x1, x0
    // 0xae5c98: RestoreReg r0
    //     0xae5c98: ldr             x0, [SP], #8
    // 0xae5c9c: RestoreReg d0
    //     0xae5c9c: ldr             q0, [SP], #0x10
    // 0xae5ca0: b               #0xae5b40
  }
}

// class id: 2043, size: 0x24, field offset: 0x20
class SliverGridParentData extends SliverMultiBoxAdaptorParentData {

  _ toString(/* No info */) {
    // ** addr: 0xae5278, size: 0xa8
    // 0xae5278: EnterFrame
    //     0xae5278: stp             fp, lr, [SP, #-0x10]!
    //     0xae527c: mov             fp, SP
    // 0xae5280: AllocStack(0x8)
    //     0xae5280: sub             SP, SP, #8
    // 0xae5284: CheckStackOverflow
    //     0xae5284: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae5288: cmp             SP, x16
    //     0xae528c: b.ls            #0xae5318
    // 0xae5290: r1 = Null
    //     0xae5290: mov             x1, NULL
    // 0xae5294: r2 = 8
    //     0xae5294: mov             x2, #8
    // 0xae5298: r0 = AllocateArray()
    //     0xae5298: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae529c: stur            x0, [fp, #-8]
    // 0xae52a0: r17 = "crossAxisOffset="
    //     0xae52a0: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fc18] "crossAxisOffset="
    //     0xae52a4: ldr             x17, [x17, #0xc18]
    // 0xae52a8: StoreField: r0->field_f = r17
    //     0xae52a8: stur            w17, [x0, #0xf]
    // 0xae52ac: ldr             x1, [fp, #0x10]
    // 0xae52b0: LoadField: r2 = r1->field_1f
    //     0xae52b0: ldur            w2, [x1, #0x1f]
    // 0xae52b4: DecompressPointer r2
    //     0xae52b4: add             x2, x2, HEAP, lsl #32
    // 0xae52b8: StoreField: r0->field_13 = r2
    //     0xae52b8: stur            w2, [x0, #0x13]
    // 0xae52bc: r17 = "; "
    //     0xae52bc: add             x17, PP, #0x1b, lsl #12  ; [pp+0x1bca8] "; "
    //     0xae52c0: ldr             x17, [x17, #0xca8]
    // 0xae52c4: StoreField: r0->field_17 = r17
    //     0xae52c4: stur            w17, [x0, #0x17]
    // 0xae52c8: SaveReg r1
    //     0xae52c8: str             x1, [SP, #-8]!
    // 0xae52cc: r0 = toString()
    //     0xae52cc: bl              #0xae53c8  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] SliverMultiBoxAdaptorParentData::toString
    // 0xae52d0: add             SP, SP, #8
    // 0xae52d4: ldur            x1, [fp, #-8]
    // 0xae52d8: ArrayStore: r1[3] = r0  ; List_4
    //     0xae52d8: add             x25, x1, #0x1b
    //     0xae52dc: str             w0, [x25]
    //     0xae52e0: tbz             w0, #0, #0xae52fc
    //     0xae52e4: ldurb           w16, [x1, #-1]
    //     0xae52e8: ldurb           w17, [x0, #-1]
    //     0xae52ec: and             x16, x17, x16, lsr #2
    //     0xae52f0: tst             x16, HEAP, lsr #32
    //     0xae52f4: b.eq            #0xae52fc
    //     0xae52f8: bl              #0xd67e5c
    // 0xae52fc: ldur            x16, [fp, #-8]
    // 0xae5300: SaveReg r16
    //     0xae5300: str             x16, [SP, #-8]!
    // 0xae5304: r0 = _interpolate()
    //     0xae5304: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae5308: add             SP, SP, #8
    // 0xae530c: LeaveFrame
    //     0xae530c: mov             SP, fp
    //     0xae5310: ldp             fp, lr, [SP], #0x10
    // 0xae5314: ret
    //     0xae5314: ret             
    // 0xae5318: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae5318: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae531c: b               #0xae5290
  }
}

// class id: 2586, size: 0x70, field offset: 0x6c
class RenderSliverGrid extends RenderSliverMultiBoxAdaptor {

  _ setupParentData(/* No info */) {
    // ** addr: 0x64b658, size: 0x68
    // 0x64b658: EnterFrame
    //     0x64b658: stp             fp, lr, [SP, #-0x10]!
    //     0x64b65c: mov             fp, SP
    // 0x64b660: ldr             x0, [fp, #0x10]
    // 0x64b664: LoadField: r1 = r0->field_17
    //     0x64b664: ldur            w1, [x0, #0x17]
    // 0x64b668: DecompressPointer r1
    //     0x64b668: add             x1, x1, HEAP, lsl #32
    // 0x64b66c: r2 = LoadClassIdInstr(r1)
    //     0x64b66c: ldur            x2, [x1, #-1]
    //     0x64b670: ubfx            x2, x2, #0xc, #0x14
    // 0x64b674: lsl             x2, x2, #1
    // 0x64b678: cmp             w2, #0xff6
    // 0x64b67c: b.eq            #0x64b6b0
    // 0x64b680: r0 = SliverGridParentData()
    //     0x64b680: bl              #0x64b6c0  ; AllocateSliverGridParentDataStub -> SliverGridParentData (size=0x24)
    // 0x64b684: r1 = false
    //     0x64b684: add             x1, NULL, #0x30  ; false
    // 0x64b688: StoreField: r0->field_1b = r1
    //     0x64b688: stur            w1, [x0, #0x1b]
    // 0x64b68c: StoreField: r0->field_13 = r1
    //     0x64b68c: stur            w1, [x0, #0x13]
    // 0x64b690: ldr             x1, [fp, #0x10]
    // 0x64b694: StoreField: r1->field_17 = r0
    //     0x64b694: stur            w0, [x1, #0x17]
    //     0x64b698: ldurb           w16, [x1, #-1]
    //     0x64b69c: ldurb           w17, [x0, #-1]
    //     0x64b6a0: and             x16, x17, x16, lsr #2
    //     0x64b6a4: tst             x16, HEAP, lsr #32
    //     0x64b6a8: b.eq            #0x64b6b0
    //     0x64b6ac: bl              #0xd6826c
    // 0x64b6b0: r0 = Null
    //     0x64b6b0: mov             x0, NULL
    // 0x64b6b4: LeaveFrame
    //     0x64b6b4: mov             SP, fp
    //     0x64b6b8: ldp             fp, lr, [SP], #0x10
    // 0x64b6bc: ret
    //     0x64b6bc: ret             
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x67ba28, size: 0x15a8
    // 0x67ba28: EnterFrame
    //     0x67ba28: stp             fp, lr, [SP, #-0x10]!
    //     0x67ba2c: mov             fp, SP
    // 0x67ba30: AllocStack(0xc0)
    //     0x67ba30: sub             SP, SP, #0xc0
    // 0x67ba34: CheckStackOverflow
    //     0x67ba34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67ba38: cmp             SP, x16
    //     0x67ba3c: b.ls            #0x67ccbc
    // 0x67ba40: ldr             x3, [fp, #0x10]
    // 0x67ba44: LoadField: r4 = r3->field_27
    //     0x67ba44: ldur            w4, [x3, #0x27]
    // 0x67ba48: DecompressPointer r4
    //     0x67ba48: add             x4, x4, HEAP, lsl #32
    // 0x67ba4c: stur            x4, [fp, #-8]
    // 0x67ba50: cmp             w4, NULL
    // 0x67ba54: b.eq            #0x67cc9c
    // 0x67ba58: mov             x0, x4
    // 0x67ba5c: r2 = Null
    //     0x67ba5c: mov             x2, NULL
    // 0x67ba60: r1 = Null
    //     0x67ba60: mov             x1, NULL
    // 0x67ba64: r4 = LoadClassIdInstr(r0)
    //     0x67ba64: ldur            x4, [x0, #-1]
    //     0x67ba68: ubfx            x4, x4, #0xc, #0x14
    // 0x67ba6c: cmp             x4, #0x80c
    // 0x67ba70: b.eq            #0x67ba88
    // 0x67ba74: r8 = SliverConstraints
    //     0x67ba74: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x67ba78: ldr             x8, [x8, #0x5a8]
    // 0x67ba7c: r3 = Null
    //     0x67ba7c: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b0e0] Null
    //     0x67ba80: ldr             x3, [x3, #0xe0]
    // 0x67ba84: r0 = DefaultTypeTest()
    //     0x67ba84: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67ba88: ldr             x0, [fp, #0x10]
    // 0x67ba8c: LoadField: r1 = r0->field_63
    //     0x67ba8c: ldur            w1, [x0, #0x63]
    // 0x67ba90: DecompressPointer r1
    //     0x67ba90: add             x1, x1, HEAP, lsl #32
    // 0x67ba94: stur            x1, [fp, #-0x10]
    // 0x67ba98: r2 = false
    //     0x67ba98: add             x2, NULL, #0x30  ; false
    // 0x67ba9c: StoreField: r1->field_53 = r2
    //     0x67ba9c: stur            w2, [x1, #0x53]
    // 0x67baa0: ldur            x3, [fp, #-8]
    // 0x67baa4: LoadField: d0 = r3->field_13
    //     0x67baa4: ldur            d0, [x3, #0x13]
    // 0x67baa8: stur            d0, [fp, #-0x80]
    // 0x67baac: LoadField: d1 = r3->field_47
    //     0x67baac: ldur            d1, [x3, #0x47]
    // 0x67bab0: fadd            d2, d0, d1
    // 0x67bab4: stur            d2, [fp, #-0x78]
    // 0x67bab8: LoadField: d1 = r3->field_4f
    //     0x67bab8: ldur            d1, [x3, #0x4f]
    // 0x67babc: fadd            d3, d2, d1
    // 0x67bac0: stur            d3, [fp, #-0x70]
    // 0x67bac4: LoadField: r4 = r0->field_6b
    //     0x67bac4: ldur            w4, [x0, #0x6b]
    // 0x67bac8: DecompressPointer r4
    //     0x67bac8: add             x4, x4, HEAP, lsl #32
    // 0x67bacc: stp             x3, x4, [SP, #-0x10]!
    // 0x67bad0: r0 = getLayout()
    //     0x67bad0: bl              #0x67d2c8  ; [package:flutter/src/rendering/sliver_grid.dart] SliverGridDelegateWithFixedCrossAxisCount::getLayout
    // 0x67bad4: add             SP, SP, #0x10
    // 0x67bad8: stur            x0, [fp, #-0x18]
    // 0x67badc: SaveReg r0
    //     0x67badc: str             x0, [SP, #-8]!
    // 0x67bae0: ldur            d0, [fp, #-0x78]
    // 0x67bae4: SaveReg d0
    //     0x67bae4: str             d0, [SP, #-8]!
    // 0x67bae8: r0 = getMinChildIndexForScrollOffset()
    //     0x67bae8: bl              #0x67d1c4  ; [package:flutter/src/rendering/sliver_grid.dart] SliverGridRegularTileLayout::getMinChildIndexForScrollOffset
    // 0x67baec: add             SP, SP, #0x10
    // 0x67baf0: mov             x3, x0
    // 0x67baf4: ldur            d0, [fp, #-0x70]
    // 0x67baf8: stur            x3, [fp, #-0x30]
    // 0x67bafc: mov             x0, v0.d[0]
    // 0x67bb00: and             x0, x0, #0x7fffffffffffffff
    // 0x67bb04: r17 = 9218868437227405312
    //     0x67bb04: mov             x17, #0x7ff0000000000000
    // 0x67bb08: cmp             x0, x17
    // 0x67bb0c: b.eq            #0x67bbf8
    // 0x67bb10: fcmp            d0, d0
    // 0x67bb14: b.vs            #0x67bbec
    // 0x67bb18: ldur            x4, [fp, #-0x18]
    // 0x67bb1c: d1 = 0.000000
    //     0x67bb1c: eor             v1.16b, v1.16b, v1.16b
    // 0x67bb20: LoadField: d2 = r4->field_f
    //     0x67bb20: ldur            d2, [x4, #0xf]
    // 0x67bb24: fcmp            d2, d1
    // 0x67bb28: b.vs            #0x67bbe0
    // 0x67bb2c: b.le            #0x67bbe0
    // 0x67bb30: fdiv            d3, d0, d2
    // 0x67bb34: fcmp            d3, d3
    // 0x67bb38: b.vs            #0x67ccc4
    // 0x67bb3c: fcvtps          x0, d3
    // 0x67bb40: asr             x16, x0, #0x1e
    // 0x67bb44: cmp             x16, x0, asr #63
    // 0x67bb48: b.ne            #0x67ccc4
    // 0x67bb4c: lsl             x0, x0, #1
    // 0x67bb50: LoadField: r1 = r4->field_7
    //     0x67bb50: ldur            x1, [x4, #7]
    // 0x67bb54: r2 = LoadInt32Instr(r0)
    //     0x67bb54: sbfx            x2, x0, #1, #0x1f
    //     0x67bb58: tbz             w0, #0, #0x67bb60
    //     0x67bb5c: ldur            x2, [x0, #7]
    // 0x67bb60: mul             x0, x1, x2
    // 0x67bb64: sub             x2, x0, #1
    // 0x67bb68: tbz             x2, #0x3f, #0x67bb74
    // 0x67bb6c: r0 = 0
    //     0x67bb6c: mov             x0, #0
    // 0x67bb70: b               #0x67bbe4
    // 0x67bb74: cmp             x2, #0
    // 0x67bb78: b.le            #0x67bb94
    // 0x67bb7c: r0 = BoxInt64Instr(r2)
    //     0x67bb7c: sbfiz           x0, x2, #1, #0x1f
    //     0x67bb80: cmp             x2, x0, asr #1
    //     0x67bb84: b.eq            #0x67bb90
    //     0x67bb88: bl              #0xd69c6c
    //     0x67bb8c: stur            x2, [x0, #7]
    // 0x67bb90: b               #0x67bbe4
    // 0x67bb94: r0 = BoxInt64Instr(r2)
    //     0x67bb94: sbfiz           x0, x2, #1, #0x1f
    //     0x67bb98: cmp             x2, x0, asr #1
    //     0x67bb9c: b.eq            #0x67bba8
    //     0x67bba0: bl              #0xd69c6c
    //     0x67bba4: stur            x2, [x0, #7]
    // 0x67bba8: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x67bba8: mov             x1, #0x76
    //     0x67bbac: tbz             w0, #0, #0x67bbbc
    //     0x67bbb0: ldur            x1, [x0, #-1]
    //     0x67bbb4: ubfx            x1, x1, #0xc, #0x14
    //     0x67bbb8: lsl             x1, x1, #1
    // 0x67bbbc: cmp             w1, #0x7a
    // 0x67bbc0: b.ne            #0x67bbd8
    // 0x67bbc4: LoadField: d0 = r0->field_7
    //     0x67bbc4: ldur            d0, [x0, #7]
    // 0x67bbc8: fcmp            d0, d0
    // 0x67bbcc: b.vs            #0x67bbe4
    // 0x67bbd0: r0 = 0
    //     0x67bbd0: mov             x0, #0
    // 0x67bbd4: b               #0x67bbe4
    // 0x67bbd8: r0 = 0
    //     0x67bbd8: mov             x0, #0
    // 0x67bbdc: b               #0x67bbe4
    // 0x67bbe0: r0 = 0
    //     0x67bbe0: mov             x0, #0
    // 0x67bbe4: mov             x6, x0
    // 0x67bbe8: b               #0x67bc04
    // 0x67bbec: ldur            x4, [fp, #-0x18]
    // 0x67bbf0: d1 = 0.000000
    //     0x67bbf0: eor             v1.16b, v1.16b, v1.16b
    // 0x67bbf4: b               #0x67bc00
    // 0x67bbf8: ldur            x4, [fp, #-0x18]
    // 0x67bbfc: d1 = 0.000000
    //     0x67bbfc: eor             v1.16b, v1.16b, v1.16b
    // 0x67bc00: r6 = Null
    //     0x67bc00: mov             x6, NULL
    // 0x67bc04: ldr             x5, [fp, #0x10]
    // 0x67bc08: stur            x6, [fp, #-0x28]
    // 0x67bc0c: LoadField: r0 = r5->field_5b
    //     0x67bc0c: ldur            w0, [x5, #0x5b]
    // 0x67bc10: DecompressPointer r0
    //     0x67bc10: add             x0, x0, HEAP, lsl #32
    // 0x67bc14: cmp             w0, NULL
    // 0x67bc18: b.eq            #0x67bdf8
    // 0x67bc1c: LoadField: r7 = r0->field_17
    //     0x67bc1c: ldur            w7, [x0, #0x17]
    // 0x67bc20: DecompressPointer r7
    //     0x67bc20: add             x7, x7, HEAP, lsl #32
    // 0x67bc24: stur            x7, [fp, #-0x20]
    // 0x67bc28: cmp             w7, NULL
    // 0x67bc2c: b.eq            #0x67ccec
    // 0x67bc30: mov             x0, x7
    // 0x67bc34: r2 = Null
    //     0x67bc34: mov             x2, NULL
    // 0x67bc38: r1 = Null
    //     0x67bc38: mov             x1, NULL
    // 0x67bc3c: r4 = LoadClassIdInstr(r0)
    //     0x67bc3c: ldur            x4, [x0, #-1]
    //     0x67bc40: ubfx            x4, x4, #0xc, #0x14
    // 0x67bc44: sub             x4, x4, #0x7f9
    // 0x67bc48: cmp             x4, #2
    // 0x67bc4c: b.ls            #0x67bc64
    // 0x67bc50: r8 = SliverMultiBoxAdaptorParentData
    //     0x67bc50: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67bc54: ldr             x8, [x8, #0x120]
    // 0x67bc58: r3 = Null
    //     0x67bc58: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b0f0] Null
    //     0x67bc5c: ldr             x3, [x3, #0xf0]
    // 0x67bc60: r0 = DefaultTypeTest()
    //     0x67bc60: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67bc64: ldur            x0, [fp, #-0x20]
    // 0x67bc68: LoadField: r3 = r0->field_17
    //     0x67bc68: ldur            w3, [x0, #0x17]
    // 0x67bc6c: DecompressPointer r3
    //     0x67bc6c: add             x3, x3, HEAP, lsl #32
    // 0x67bc70: stur            x3, [fp, #-0x38]
    // 0x67bc74: cmp             w3, NULL
    // 0x67bc78: b.eq            #0x67ccf0
    // 0x67bc7c: ldr             x4, [fp, #0x10]
    // 0x67bc80: LoadField: r0 = r4->field_5f
    //     0x67bc80: ldur            w0, [x4, #0x5f]
    // 0x67bc84: DecompressPointer r0
    //     0x67bc84: add             x0, x0, HEAP, lsl #32
    // 0x67bc88: cmp             w0, NULL
    // 0x67bc8c: b.eq            #0x67ccf4
    // 0x67bc90: LoadField: r5 = r0->field_17
    //     0x67bc90: ldur            w5, [x0, #0x17]
    // 0x67bc94: DecompressPointer r5
    //     0x67bc94: add             x5, x5, HEAP, lsl #32
    // 0x67bc98: stur            x5, [fp, #-0x20]
    // 0x67bc9c: cmp             w5, NULL
    // 0x67bca0: b.eq            #0x67ccf8
    // 0x67bca4: mov             x0, x5
    // 0x67bca8: r2 = Null
    //     0x67bca8: mov             x2, NULL
    // 0x67bcac: r1 = Null
    //     0x67bcac: mov             x1, NULL
    // 0x67bcb0: r4 = LoadClassIdInstr(r0)
    //     0x67bcb0: ldur            x4, [x0, #-1]
    //     0x67bcb4: ubfx            x4, x4, #0xc, #0x14
    // 0x67bcb8: sub             x4, x4, #0x7f9
    // 0x67bcbc: cmp             x4, #2
    // 0x67bcc0: b.ls            #0x67bcd8
    // 0x67bcc4: r8 = SliverMultiBoxAdaptorParentData
    //     0x67bcc4: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67bcc8: ldr             x8, [x8, #0x120]
    // 0x67bccc: r3 = Null
    //     0x67bccc: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b100] Null
    //     0x67bcd0: ldr             x3, [x3, #0x100]
    // 0x67bcd4: r0 = DefaultTypeTest()
    //     0x67bcd4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67bcd8: ldur            x0, [fp, #-0x20]
    // 0x67bcdc: LoadField: r2 = r0->field_17
    //     0x67bcdc: ldur            w2, [x0, #0x17]
    // 0x67bce0: DecompressPointer r2
    //     0x67bce0: add             x2, x2, HEAP, lsl #32
    // 0x67bce4: stur            x2, [fp, #-0x40]
    // 0x67bce8: cmp             w2, NULL
    // 0x67bcec: b.eq            #0x67ccfc
    // 0x67bcf0: ldur            x0, [fp, #-0x38]
    // 0x67bcf4: r1 = LoadInt32Instr(r0)
    //     0x67bcf4: sbfx            x1, x0, #1, #0x1f
    //     0x67bcf8: tbz             w0, #0, #0x67bd00
    //     0x67bcfc: ldur            x1, [x0, #7]
    // 0x67bd00: ldur            x3, [fp, #-0x30]
    // 0x67bd04: sub             x4, x3, x1
    // 0x67bd08: ldr             x5, [fp, #0x10]
    // 0x67bd0c: LoadField: r6 = r5->field_53
    //     0x67bd0c: ldur            x6, [x5, #0x53]
    // 0x67bd10: r0 = BoxInt64Instr(r4)
    //     0x67bd10: sbfiz           x0, x4, #1, #0x1f
    //     0x67bd14: cmp             x4, x0, asr #1
    //     0x67bd18: b.eq            #0x67bd24
    //     0x67bd1c: bl              #0xd69bb8
    //     0x67bd20: stur            x4, [x0, #7]
    // 0x67bd24: mov             x4, x0
    // 0x67bd28: r0 = BoxInt64Instr(r6)
    //     0x67bd28: sbfiz           x0, x6, #1, #0x1f
    //     0x67bd2c: cmp             x6, x0, asr #1
    //     0x67bd30: b.eq            #0x67bd3c
    //     0x67bd34: bl              #0xd69bb8
    //     0x67bd38: stur            x6, [x0, #7]
    // 0x67bd3c: stp             xzr, x4, [SP, #-0x10]!
    // 0x67bd40: SaveReg r0
    //     0x67bd40: str             x0, [SP, #-8]!
    // 0x67bd44: r0 = clamp()
    //     0x67bd44: bl              #0xd66d18  ; [dart:core] _IntegerImplementation::clamp
    // 0x67bd48: add             SP, SP, #0x18
    // 0x67bd4c: mov             x3, x0
    // 0x67bd50: ldur            x2, [fp, #-0x28]
    // 0x67bd54: stur            x3, [fp, #-0x20]
    // 0x67bd58: cmp             w2, NULL
    // 0x67bd5c: b.ne            #0x67bd68
    // 0x67bd60: r0 = 0
    //     0x67bd60: mov             x0, #0
    // 0x67bd64: b               #0x67bddc
    // 0x67bd68: ldr             x4, [fp, #0x10]
    // 0x67bd6c: ldur            x0, [fp, #-0x40]
    // 0x67bd70: r1 = LoadInt32Instr(r0)
    //     0x67bd70: sbfx            x1, x0, #1, #0x1f
    //     0x67bd74: tbz             w0, #0, #0x67bd7c
    //     0x67bd78: ldur            x1, [x0, #7]
    // 0x67bd7c: r0 = LoadInt32Instr(r2)
    //     0x67bd7c: sbfx            x0, x2, #1, #0x1f
    //     0x67bd80: tbz             w2, #0, #0x67bd88
    //     0x67bd84: ldur            x0, [x2, #7]
    // 0x67bd88: sub             x5, x1, x0
    // 0x67bd8c: LoadField: r6 = r4->field_53
    //     0x67bd8c: ldur            x6, [x4, #0x53]
    // 0x67bd90: r0 = BoxInt64Instr(r5)
    //     0x67bd90: sbfiz           x0, x5, #1, #0x1f
    //     0x67bd94: cmp             x5, x0, asr #1
    //     0x67bd98: b.eq            #0x67bda4
    //     0x67bd9c: bl              #0xd69bb8
    //     0x67bda0: stur            x5, [x0, #7]
    // 0x67bda4: mov             x5, x0
    // 0x67bda8: r0 = BoxInt64Instr(r6)
    //     0x67bda8: sbfiz           x0, x6, #1, #0x1f
    //     0x67bdac: cmp             x6, x0, asr #1
    //     0x67bdb0: b.eq            #0x67bdbc
    //     0x67bdb4: bl              #0xd69bb8
    //     0x67bdb8: stur            x6, [x0, #7]
    // 0x67bdbc: stp             xzr, x5, [SP, #-0x10]!
    // 0x67bdc0: SaveReg r0
    //     0x67bdc0: str             x0, [SP, #-8]!
    // 0x67bdc4: r0 = clamp()
    //     0x67bdc4: bl              #0xd66d18  ; [dart:core] _IntegerImplementation::clamp
    // 0x67bdc8: add             SP, SP, #0x18
    // 0x67bdcc: r1 = LoadInt32Instr(r0)
    //     0x67bdcc: sbfx            x1, x0, #1, #0x1f
    //     0x67bdd0: tbz             w0, #0, #0x67bdd8
    //     0x67bdd4: ldur            x1, [x0, #7]
    // 0x67bdd8: mov             x0, x1
    // 0x67bddc: ldr             x16, [fp, #0x10]
    // 0x67bde0: ldur            lr, [fp, #-0x20]
    // 0x67bde4: stp             lr, x16, [SP, #-0x10]!
    // 0x67bde8: SaveReg r0
    //     0x67bde8: str             x0, [SP, #-8]!
    // 0x67bdec: r0 = collectGarbage()
    //     0x67bdec: bl              #0x6797bc  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::collectGarbage
    // 0x67bdf0: add             SP, SP, #0x18
    // 0x67bdf4: b               #0x67be0c
    // 0x67bdf8: ldr             x16, [fp, #0x10]
    // 0x67bdfc: stp             xzr, x16, [SP, #-0x10]!
    // 0x67be00: SaveReg rZR
    //     0x67be00: str             xzr, [SP, #-8]!
    // 0x67be04: r0 = collectGarbage()
    //     0x67be04: bl              #0x6797bc  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::collectGarbage
    // 0x67be08: add             SP, SP, #0x18
    // 0x67be0c: ldr             x0, [fp, #0x10]
    // 0x67be10: ldur            x1, [fp, #-0x30]
    // 0x67be14: ldur            x16, [fp, #-0x18]
    // 0x67be18: stp             x1, x16, [SP, #-0x10]!
    // 0x67be1c: r0 = getGeometryForChildIndex()
    //     0x67be1c: bl              #0x67d09c  ; [package:flutter/src/rendering/sliver_grid.dart] SliverGridRegularTileLayout::getGeometryForChildIndex
    // 0x67be20: add             SP, SP, #0x10
    // 0x67be24: mov             x3, x0
    // 0x67be28: ldr             x2, [fp, #0x10]
    // 0x67be2c: stur            x3, [fp, #-0x20]
    // 0x67be30: LoadField: r0 = r2->field_5b
    //     0x67be30: ldur            w0, [x2, #0x5b]
    // 0x67be34: DecompressPointer r0
    //     0x67be34: add             x0, x0, HEAP, lsl #32
    // 0x67be38: cmp             w0, NULL
    // 0x67be3c: b.ne            #0x67bf8c
    // 0x67be40: ldur            x4, [fp, #-0x30]
    // 0x67be44: LoadField: d0 = r3->field_7
    //     0x67be44: ldur            d0, [x3, #7]
    // 0x67be48: r0 = BoxInt64Instr(r4)
    //     0x67be48: sbfiz           x0, x4, #1, #0x1f
    //     0x67be4c: cmp             x4, x0, asr #1
    //     0x67be50: b.eq            #0x67be5c
    //     0x67be54: bl              #0xd69c6c
    //     0x67be58: stur            x4, [x0, #7]
    // 0x67be5c: r1 = inline_Allocate_Double()
    //     0x67be5c: ldp             x1, x5, [THR, #0x60]  ; THR::top
    //     0x67be60: add             x1, x1, #0x10
    //     0x67be64: cmp             x5, x1
    //     0x67be68: b.ls            #0x67cd00
    //     0x67be6c: str             x1, [THR, #0x60]  ; THR::top
    //     0x67be70: sub             x1, x1, #0xf
    //     0x67be74: mov             x5, #0xd108
    //     0x67be78: movk            x5, #3, lsl #16
    //     0x67be7c: stur            x5, [x1, #-1]
    // 0x67be80: StoreField: r1->field_7 = d0
    //     0x67be80: stur            d0, [x1, #7]
    // 0x67be84: stp             x0, x2, [SP, #-0x10]!
    // 0x67be88: SaveReg r1
    //     0x67be88: str             x1, [SP, #-8]!
    // 0x67be8c: r4 = const [0, 0x3, 0x3, 0x1, index, 0x1, layoutOffset, 0x2, null]
    //     0x67be8c: add             x4, PP, #0x43, lsl #12  ; [pp+0x43530] List(9) [0, 0x3, 0x3, 0x1, "index", 0x1, "layoutOffset", 0x2, Null]
    //     0x67be90: ldr             x4, [x4, #0x530]
    // 0x67be94: r0 = addInitialChild()
    //     0x67be94: bl              #0x6795e8  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::addInitialChild
    // 0x67be98: add             SP, SP, #0x18
    // 0x67be9c: tbz             w0, #4, #0x67bf7c
    // 0x67bea0: ldr             x0, [fp, #0x10]
    // 0x67bea4: ldur            x1, [fp, #-0x18]
    // 0x67bea8: ldur            x16, [fp, #-0x10]
    // 0x67beac: SaveReg r16
    //     0x67beac: str             x16, [SP, #-8]!
    // 0x67beb0: r0 = childCount()
    //     0x67beb0: bl              #0x67938c  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::childCount
    // 0x67beb4: add             SP, SP, #8
    // 0x67beb8: sub             x1, x0, #1
    // 0x67bebc: ldur            x3, [fp, #-0x18]
    // 0x67bec0: LoadField: r0 = r3->field_7
    //     0x67bec0: ldur            x0, [x3, #7]
    // 0x67bec4: cbz             x0, #0x67cd24
    // 0x67bec8: sdiv            x2, x1, x0
    // 0x67becc: add             x0, x2, #1
    // 0x67bed0: LoadField: d0 = r3->field_f
    //     0x67bed0: ldur            d0, [x3, #0xf]
    // 0x67bed4: LoadField: d1 = r3->field_1f
    //     0x67bed4: ldur            d1, [x3, #0x1f]
    // 0x67bed8: fsub            d2, d0, d1
    // 0x67bedc: scvtf           d1, x0
    // 0x67bee0: fmul            d3, d0, d1
    // 0x67bee4: fsub            d0, d3, d2
    // 0x67bee8: stur            d0, [fp, #-0x70]
    // 0x67beec: r0 = SliverGeometry()
    //     0x67beec: bl              #0x679334  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x54)
    // 0x67bef0: ldur            d0, [fp, #-0x70]
    // 0x67bef4: StoreField: r0->field_7 = d0
    //     0x67bef4: stur            d0, [x0, #7]
    // 0x67bef8: d1 = 0.000000
    //     0x67bef8: eor             v1.16b, v1.16b, v1.16b
    // 0x67befc: StoreField: r0->field_17 = d1
    //     0x67befc: stur            d1, [x0, #0x17]
    // 0x67bf00: StoreField: r0->field_f = d1
    //     0x67bf00: stur            d1, [x0, #0xf]
    // 0x67bf04: StoreField: r0->field_27 = d0
    //     0x67bf04: stur            d0, [x0, #0x27]
    // 0x67bf08: StoreField: r0->field_2f = d1
    //     0x67bf08: stur            d1, [x0, #0x2f]
    // 0x67bf0c: r1 = false
    //     0x67bf0c: add             x1, NULL, #0x30  ; false
    // 0x67bf10: StoreField: r0->field_43 = r1
    //     0x67bf10: stur            w1, [x0, #0x43]
    // 0x67bf14: StoreField: r0->field_1f = d1
    //     0x67bf14: stur            d1, [x0, #0x1f]
    // 0x67bf18: StoreField: r0->field_37 = d1
    //     0x67bf18: stur            d1, [x0, #0x37]
    // 0x67bf1c: StoreField: r0->field_4b = d1
    //     0x67bf1c: stur            d1, [x0, #0x4b]
    // 0x67bf20: fcmp            d1, d1
    // 0x67bf24: b.vs            #0x67bf2c
    // 0x67bf28: b.gt            #0x67bf34
    // 0x67bf2c: r1 = false
    //     0x67bf2c: add             x1, NULL, #0x30  ; false
    // 0x67bf30: b               #0x67bf38
    // 0x67bf34: r1 = true
    //     0x67bf34: add             x1, NULL, #0x20  ; true
    // 0x67bf38: StoreField: r0->field_3f = r1
    //     0x67bf38: stur            w1, [x0, #0x3f]
    // 0x67bf3c: ldr             x4, [fp, #0x10]
    // 0x67bf40: StoreField: r4->field_4f = r0
    //     0x67bf40: stur            w0, [x4, #0x4f]
    //     0x67bf44: ldurb           w16, [x4, #-1]
    //     0x67bf48: ldurb           w17, [x0, #-1]
    //     0x67bf4c: and             x16, x17, x16, lsr #2
    //     0x67bf50: tst             x16, HEAP, lsr #32
    //     0x67bf54: b.eq            #0x67bf5c
    //     0x67bf58: bl              #0xd682cc
    // 0x67bf5c: ldur            x16, [fp, #-0x10]
    // 0x67bf60: SaveReg r16
    //     0x67bf60: str             x16, [SP, #-8]!
    // 0x67bf64: r0 = didFinishLayout()
    //     0x67bf64: bl              #0x678c84  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::didFinishLayout
    // 0x67bf68: add             SP, SP, #8
    // 0x67bf6c: r0 = Null
    //     0x67bf6c: mov             x0, NULL
    // 0x67bf70: LeaveFrame
    //     0x67bf70: mov             SP, fp
    //     0x67bf74: ldp             fp, lr, [SP], #0x10
    // 0x67bf78: ret
    //     0x67bf78: ret             
    // 0x67bf7c: ldr             x4, [fp, #0x10]
    // 0x67bf80: ldur            x3, [fp, #-0x18]
    // 0x67bf84: d1 = 0.000000
    //     0x67bf84: eor             v1.16b, v1.16b, v1.16b
    // 0x67bf88: b               #0x67bf98
    // 0x67bf8c: mov             x4, x2
    // 0x67bf90: ldur            x3, [fp, #-0x18]
    // 0x67bf94: d1 = 0.000000
    //     0x67bf94: eor             v1.16b, v1.16b, v1.16b
    // 0x67bf98: ldur            x5, [fp, #-0x20]
    // 0x67bf9c: LoadField: d0 = r5->field_7
    //     0x67bf9c: ldur            d0, [x5, #7]
    // 0x67bfa0: stur            d0, [fp, #-0x78]
    // 0x67bfa4: LoadField: d2 = r5->field_17
    //     0x67bfa4: ldur            d2, [x5, #0x17]
    // 0x67bfa8: fadd            d3, d0, d2
    // 0x67bfac: stur            d3, [fp, #-0x70]
    // 0x67bfb0: LoadField: r0 = r4->field_5b
    //     0x67bfb0: ldur            w0, [x4, #0x5b]
    // 0x67bfb4: DecompressPointer r0
    //     0x67bfb4: add             x0, x0, HEAP, lsl #32
    // 0x67bfb8: cmp             w0, NULL
    // 0x67bfbc: b.eq            #0x67cd40
    // 0x67bfc0: LoadField: r6 = r0->field_17
    //     0x67bfc0: ldur            w6, [x0, #0x17]
    // 0x67bfc4: DecompressPointer r6
    //     0x67bfc4: add             x6, x6, HEAP, lsl #32
    // 0x67bfc8: stur            x6, [fp, #-0x38]
    // 0x67bfcc: cmp             w6, NULL
    // 0x67bfd0: b.eq            #0x67cd44
    // 0x67bfd4: mov             x0, x6
    // 0x67bfd8: r2 = Null
    //     0x67bfd8: mov             x2, NULL
    // 0x67bfdc: r1 = Null
    //     0x67bfdc: mov             x1, NULL
    // 0x67bfe0: r4 = LoadClassIdInstr(r0)
    //     0x67bfe0: ldur            x4, [x0, #-1]
    //     0x67bfe4: ubfx            x4, x4, #0xc, #0x14
    // 0x67bfe8: sub             x4, x4, #0x7f9
    // 0x67bfec: cmp             x4, #2
    // 0x67bff0: b.ls            #0x67c008
    // 0x67bff4: r8 = SliverMultiBoxAdaptorParentData
    //     0x67bff4: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67bff8: ldr             x8, [x8, #0x120]
    // 0x67bffc: r3 = Null
    //     0x67bffc: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b110] Null
    //     0x67c000: ldr             x3, [x3, #0x110]
    // 0x67c004: r0 = DefaultTypeTest()
    //     0x67c004: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67c008: ldur            x0, [fp, #-0x38]
    // 0x67c00c: LoadField: r1 = r0->field_17
    //     0x67c00c: ldur            w1, [x0, #0x17]
    // 0x67c010: DecompressPointer r1
    //     0x67c010: add             x1, x1, HEAP, lsl #32
    // 0x67c014: cmp             w1, NULL
    // 0x67c018: b.eq            #0x67cd48
    // 0x67c01c: r0 = LoadInt32Instr(r1)
    //     0x67c01c: sbfx            x0, x1, #1, #0x1f
    //     0x67c020: tbz             w1, #0, #0x67c028
    //     0x67c024: ldur            x0, [x1, #7]
    // 0x67c028: sub             x1, x0, #1
    // 0x67c02c: ldur            x0, [fp, #-0x18]
    // 0x67c030: LoadField: r2 = r0->field_7
    //     0x67c030: ldur            x2, [x0, #7]
    // 0x67c034: stur            x2, [fp, #-0x58]
    // 0x67c038: LoadField: d0 = r0->field_17
    //     0x67c038: ldur            d0, [x0, #0x17]
    // 0x67c03c: stur            d0, [fp, #-0xc0]
    // 0x67c040: LoadField: d1 = r0->field_f
    //     0x67c040: ldur            d1, [x0, #0xf]
    // 0x67c044: stur            d1, [fp, #-0xb8]
    // 0x67c048: LoadField: r3 = r0->field_2f
    //     0x67c048: ldur            w3, [x0, #0x2f]
    // 0x67c04c: DecompressPointer r3
    //     0x67c04c: add             x3, x3, HEAP, lsl #32
    // 0x67c050: stur            x3, [fp, #-0x50]
    // 0x67c054: LoadField: d2 = r0->field_1f
    //     0x67c054: ldur            d2, [x0, #0x1f]
    // 0x67c058: stur            d2, [fp, #-0xb0]
    // 0x67c05c: LoadField: d3 = r0->field_27
    //     0x67c05c: ldur            d3, [x0, #0x27]
    // 0x67c060: stur            d3, [fp, #-0xa8]
    // 0x67c064: r0 = inline_Allocate_Double()
    //     0x67c064: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0x67c068: add             x0, x0, #0x10
    //     0x67c06c: cmp             x4, x0
    //     0x67c070: b.ls            #0x67cd4c
    //     0x67c074: str             x0, [THR, #0x60]  ; THR::top
    //     0x67c078: sub             x0, x0, #0xf
    //     0x67c07c: mov             x4, #0xd108
    //     0x67c080: movk            x4, #3, lsl #16
    //     0x67c084: stur            x4, [x0, #-1]
    // 0x67c088: StoreField: r0->field_7 = d2
    //     0x67c088: stur            d2, [x0, #7]
    // 0x67c08c: stur            x0, [fp, #-0x40]
    // 0x67c090: r4 = inline_Allocate_Double()
    //     0x67c090: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x67c094: add             x4, x4, #0x10
    //     0x67c098: cmp             x5, x4
    //     0x67c09c: b.ls            #0x67cd74
    //     0x67c0a0: str             x4, [THR, #0x60]  ; THR::top
    //     0x67c0a4: sub             x4, x4, #0xf
    //     0x67c0a8: mov             x5, #0xd108
    //     0x67c0ac: movk            x5, #3, lsl #16
    //     0x67c0b0: stur            x5, [x4, #-1]
    // 0x67c0b4: StoreField: r4->field_7 = d3
    //     0x67c0b4: stur            d3, [x4, #7]
    // 0x67c0b8: stur            x4, [fp, #-0x38]
    // 0x67c0bc: lsl             x5, x2, #1
    // 0x67c0c0: r16 = LoadInt32Instr(r5)
    //     0x67c0c0: sbfx            x16, x5, #1, #0x1f
    // 0x67c0c4: scvtf           d4, w16
    // 0x67c0c8: fmul            d5, d4, d0
    // 0x67c0cc: stur            d5, [fp, #-0xa0]
    // 0x67c0d0: fsub            d4, d0, d3
    // 0x67c0d4: stur            d4, [fp, #-0x98]
    // 0x67c0d8: ldur            d6, [fp, #-0x70]
    // 0x67c0dc: mov             x5, x1
    // 0x67c0e0: r6 = Null
    //     0x67c0e0: mov             x6, NULL
    // 0x67c0e4: ldur            x1, [fp, #-0x30]
    // 0x67c0e8: stur            x6, [fp, #-0x18]
    // 0x67c0ec: stur            x5, [fp, #-0x48]
    // 0x67c0f0: stur            d6, [fp, #-0x90]
    // 0x67c0f4: CheckStackOverflow
    //     0x67c0f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67c0f8: cmp             SP, x16
    //     0x67c0fc: b.ls            #0x67cda0
    // 0x67c100: cmp             x5, x1
    // 0x67c104: b.lt            #0x67c324
    // 0x67c108: cbz             x2, #0x67cda8
    // 0x67c10c: sdiv            x8, x5, x2
    // 0x67c110: msub            x7, x8, x2, x5
    // 0x67c114: cmp             x7, xzr
    // 0x67c118: b.lt            #0x67cddc
    // 0x67c11c: scvtf           d7, x7
    // 0x67c120: fmul            d8, d7, d0
    // 0x67c124: cbz             x2, #0x67cdf0
    // 0x67c128: sdiv            x7, x5, x2
    // 0x67c12c: scvtf           d7, x7
    // 0x67c130: fmul            d9, d7, d1
    // 0x67c134: stur            d9, [fp, #-0x88]
    // 0x67c138: tbnz            w3, #4, #0x67c14c
    // 0x67c13c: fsub            d7, d5, d8
    // 0x67c140: fsub            d8, d7, d3
    // 0x67c144: fsub            d7, d8, d4
    // 0x67c148: b               #0x67c150
    // 0x67c14c: mov             v7.16b, v8.16b
    // 0x67c150: stur            d7, [fp, #-0x70]
    // 0x67c154: ldur            x16, [fp, #-8]
    // 0x67c158: stp             x0, x16, [SP, #-0x10]!
    // 0x67c15c: stp             x4, x0, [SP, #-0x10]!
    // 0x67c160: r4 = const [0, 0x4, 0x4, 0x1, crossAxisExtent, 0x3, maxExtent, 0x2, minExtent, 0x1, null]
    //     0x67c160: add             x4, PP, #0x4b, lsl #12  ; [pp+0x4b120] List(11) [0, 0x4, 0x4, 0x1, "crossAxisExtent", 0x3, "maxExtent", 0x2, "minExtent", 0x1, Null]
    //     0x67c164: ldr             x4, [x4, #0x120]
    // 0x67c168: r0 = asBoxConstraints()
    //     0x67c168: bl              #0x67a528  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::asBoxConstraints
    // 0x67c16c: add             SP, SP, #0x20
    // 0x67c170: ldr             x16, [fp, #0x10]
    // 0x67c174: stp             x0, x16, [SP, #-0x10]!
    // 0x67c178: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x67c178: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x67c17c: r0 = insertAndLayoutLeadingChild()
    //     0x67c17c: bl              #0x678a4c  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::insertAndLayoutLeadingChild
    // 0x67c180: add             SP, SP, #0x10
    // 0x67c184: mov             x3, x0
    // 0x67c188: stur            x3, [fp, #-0x68]
    // 0x67c18c: cmp             w3, NULL
    // 0x67c190: b.eq            #0x67ce24
    // 0x67c194: LoadField: r4 = r3->field_17
    //     0x67c194: ldur            w4, [x3, #0x17]
    // 0x67c198: DecompressPointer r4
    //     0x67c198: add             x4, x4, HEAP, lsl #32
    // 0x67c19c: stur            x4, [fp, #-0x60]
    // 0x67c1a0: cmp             w4, NULL
    // 0x67c1a4: b.eq            #0x67ce28
    // 0x67c1a8: mov             x0, x4
    // 0x67c1ac: r2 = Null
    //     0x67c1ac: mov             x2, NULL
    // 0x67c1b0: r1 = Null
    //     0x67c1b0: mov             x1, NULL
    // 0x67c1b4: r4 = LoadClassIdInstr(r0)
    //     0x67c1b4: ldur            x4, [x0, #-1]
    //     0x67c1b8: ubfx            x4, x4, #0xc, #0x14
    // 0x67c1bc: cmp             x4, #0x7fb
    // 0x67c1c0: b.eq            #0x67c1d8
    // 0x67c1c4: r8 = SliverGridParentData
    //     0x67c1c4: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4b128] Type: SliverGridParentData
    //     0x67c1c8: ldr             x8, [x8, #0x128]
    // 0x67c1cc: r3 = Null
    //     0x67c1cc: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b130] Null
    //     0x67c1d0: ldr             x3, [x3, #0x130]
    // 0x67c1d4: r0 = DefaultTypeTest()
    //     0x67c1d4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67c1d8: ldur            d0, [fp, #-0x88]
    // 0x67c1dc: r0 = inline_Allocate_Double()
    //     0x67c1dc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x67c1e0: add             x0, x0, #0x10
    //     0x67c1e4: cmp             x1, x0
    //     0x67c1e8: b.ls            #0x67ce2c
    //     0x67c1ec: str             x0, [THR, #0x60]  ; THR::top
    //     0x67c1f0: sub             x0, x0, #0xf
    //     0x67c1f4: mov             x1, #0xd108
    //     0x67c1f8: movk            x1, #3, lsl #16
    //     0x67c1fc: stur            x1, [x0, #-1]
    // 0x67c200: StoreField: r0->field_7 = d0
    //     0x67c200: stur            d0, [x0, #7]
    // 0x67c204: ldur            x1, [fp, #-0x60]
    // 0x67c208: StoreField: r1->field_7 = r0
    //     0x67c208: stur            w0, [x1, #7]
    //     0x67c20c: ldurb           w16, [x1, #-1]
    //     0x67c210: ldurb           w17, [x0, #-1]
    //     0x67c214: and             x16, x17, x16, lsr #2
    //     0x67c218: tst             x16, HEAP, lsr #32
    //     0x67c21c: b.eq            #0x67c224
    //     0x67c220: bl              #0xd6826c
    // 0x67c224: ldur            d1, [fp, #-0x70]
    // 0x67c228: r0 = inline_Allocate_Double()
    //     0x67c228: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x67c22c: add             x0, x0, #0x10
    //     0x67c230: cmp             x2, x0
    //     0x67c234: b.ls            #0x67ce3c
    //     0x67c238: str             x0, [THR, #0x60]  ; THR::top
    //     0x67c23c: sub             x0, x0, #0xf
    //     0x67c240: mov             x2, #0xd108
    //     0x67c244: movk            x2, #3, lsl #16
    //     0x67c248: stur            x2, [x0, #-1]
    // 0x67c24c: StoreField: r0->field_7 = d1
    //     0x67c24c: stur            d1, [x0, #7]
    // 0x67c250: StoreField: r1->field_1f = r0
    //     0x67c250: stur            w0, [x1, #0x1f]
    //     0x67c254: ldurb           w16, [x1, #-1]
    //     0x67c258: ldurb           w17, [x0, #-1]
    //     0x67c25c: and             x16, x17, x16, lsr #2
    //     0x67c260: tst             x16, HEAP, lsr #32
    //     0x67c264: b.eq            #0x67c26c
    //     0x67c268: bl              #0xd6826c
    // 0x67c26c: ldur            x0, [fp, #-0x18]
    // 0x67c270: cmp             w0, NULL
    // 0x67c274: b.ne            #0x67c280
    // 0x67c278: ldur            x6, [fp, #-0x68]
    // 0x67c27c: b               #0x67c284
    // 0x67c280: mov             x6, x0
    // 0x67c284: ldur            d2, [fp, #-0x90]
    // 0x67c288: ldur            d1, [fp, #-0xb0]
    // 0x67c28c: fadd            d3, d0, d1
    // 0x67c290: fcmp            d2, d3
    // 0x67c294: b.vs            #0x67c2a8
    // 0x67c298: b.le            #0x67c2a8
    // 0x67c29c: mov             v6.16b, v2.16b
    // 0x67c2a0: d0 = 0.000000
    //     0x67c2a0: eor             v0.16b, v0.16b, v0.16b
    // 0x67c2a4: b               #0x67c2f0
    // 0x67c2a8: fcmp            d2, d3
    // 0x67c2ac: b.vs            #0x67c2c0
    // 0x67c2b0: b.ge            #0x67c2c0
    // 0x67c2b4: mov             v6.16b, v3.16b
    // 0x67c2b8: d0 = 0.000000
    //     0x67c2b8: eor             v0.16b, v0.16b, v0.16b
    // 0x67c2bc: b               #0x67c2f0
    // 0x67c2c0: d0 = 0.000000
    //     0x67c2c0: eor             v0.16b, v0.16b, v0.16b
    // 0x67c2c4: fcmp            d2, d0
    // 0x67c2c8: b.vs            #0x67c2dc
    // 0x67c2cc: b.ne            #0x67c2dc
    // 0x67c2d0: fadd            d4, d2, d3
    // 0x67c2d4: mov             v6.16b, v4.16b
    // 0x67c2d8: b               #0x67c2f0
    // 0x67c2dc: fcmp            d3, d3
    // 0x67c2e0: b.vc            #0x67c2ec
    // 0x67c2e4: mov             v6.16b, v3.16b
    // 0x67c2e8: b               #0x67c2f0
    // 0x67c2ec: mov             v6.16b, v2.16b
    // 0x67c2f0: ldur            x0, [fp, #-0x48]
    // 0x67c2f4: sub             x5, x0, #1
    // 0x67c2f8: ldur            x2, [fp, #-0x58]
    // 0x67c2fc: ldur            d0, [fp, #-0xc0]
    // 0x67c300: mov             v2.16b, v1.16b
    // 0x67c304: ldur            d1, [fp, #-0xb8]
    // 0x67c308: ldur            d3, [fp, #-0xa8]
    // 0x67c30c: ldur            x3, [fp, #-0x50]
    // 0x67c310: ldur            d5, [fp, #-0xa0]
    // 0x67c314: ldur            d4, [fp, #-0x98]
    // 0x67c318: ldur            x0, [fp, #-0x40]
    // 0x67c31c: ldur            x4, [fp, #-0x38]
    // 0x67c320: b               #0x67c0e4
    // 0x67c324: mov             v1.16b, v2.16b
    // 0x67c328: mov             v2.16b, v6.16b
    // 0x67c32c: mov             x0, x6
    // 0x67c330: d0 = 0.000000
    //     0x67c330: eor             v0.16b, v0.16b, v0.16b
    // 0x67c334: cmp             w0, NULL
    // 0x67c338: b.ne            #0x67c498
    // 0x67c33c: ldr             x0, [fp, #0x10]
    // 0x67c340: ldur            x1, [fp, #-0x20]
    // 0x67c344: ldur            d3, [fp, #-0x78]
    // 0x67c348: LoadField: r2 = r0->field_5b
    //     0x67c348: ldur            w2, [x0, #0x5b]
    // 0x67c34c: DecompressPointer r2
    //     0x67c34c: add             x2, x2, HEAP, lsl #32
    // 0x67c350: stur            x2, [fp, #-0x38]
    // 0x67c354: cmp             w2, NULL
    // 0x67c358: b.eq            #0x67ce54
    // 0x67c35c: ldur            x16, [fp, #-8]
    // 0x67c360: stp             x16, x1, [SP, #-0x10]!
    // 0x67c364: r0 = getBoxConstraints()
    //     0x67c364: bl              #0x67cfd0  ; [package:flutter/src/rendering/sliver_grid.dart] SliverGridGeometry::getBoxConstraints
    // 0x67c368: add             SP, SP, #0x10
    // 0x67c36c: mov             x1, x0
    // 0x67c370: ldur            x0, [fp, #-0x38]
    // 0x67c374: r2 = LoadClassIdInstr(r0)
    //     0x67c374: ldur            x2, [x0, #-1]
    //     0x67c378: ubfx            x2, x2, #0xc, #0x14
    // 0x67c37c: stp             x1, x0, [SP, #-0x10]!
    // 0x67c380: mov             x0, x2
    // 0x67c384: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x67c384: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x67c388: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x67c388: mov             x17, #0xcdfb
    //     0x67c38c: add             lr, x0, x17
    //     0x67c390: ldr             lr, [x21, lr, lsl #3]
    //     0x67c394: blr             lr
    // 0x67c398: add             SP, SP, #0x10
    // 0x67c39c: ldr             x3, [fp, #0x10]
    // 0x67c3a0: LoadField: r4 = r3->field_5b
    //     0x67c3a0: ldur            w4, [x3, #0x5b]
    // 0x67c3a4: DecompressPointer r4
    //     0x67c3a4: add             x4, x4, HEAP, lsl #32
    // 0x67c3a8: stur            x4, [fp, #-0x40]
    // 0x67c3ac: cmp             w4, NULL
    // 0x67c3b0: b.eq            #0x67ce58
    // 0x67c3b4: LoadField: r5 = r4->field_17
    //     0x67c3b4: ldur            w5, [x4, #0x17]
    // 0x67c3b8: DecompressPointer r5
    //     0x67c3b8: add             x5, x5, HEAP, lsl #32
    // 0x67c3bc: stur            x5, [fp, #-0x38]
    // 0x67c3c0: cmp             w5, NULL
    // 0x67c3c4: b.eq            #0x67ce5c
    // 0x67c3c8: mov             x0, x5
    // 0x67c3cc: r2 = Null
    //     0x67c3cc: mov             x2, NULL
    // 0x67c3d0: r1 = Null
    //     0x67c3d0: mov             x1, NULL
    // 0x67c3d4: r4 = LoadClassIdInstr(r0)
    //     0x67c3d4: ldur            x4, [x0, #-1]
    //     0x67c3d8: ubfx            x4, x4, #0xc, #0x14
    // 0x67c3dc: cmp             x4, #0x7fb
    // 0x67c3e0: b.eq            #0x67c3f8
    // 0x67c3e4: r8 = SliverGridParentData
    //     0x67c3e4: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4b128] Type: SliverGridParentData
    //     0x67c3e8: ldr             x8, [x8, #0x128]
    // 0x67c3ec: r3 = Null
    //     0x67c3ec: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b140] Null
    //     0x67c3f0: ldr             x3, [x3, #0x140]
    // 0x67c3f4: r0 = DefaultTypeTest()
    //     0x67c3f4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67c3f8: ldur            d0, [fp, #-0x78]
    // 0x67c3fc: r0 = inline_Allocate_Double()
    //     0x67c3fc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x67c400: add             x0, x0, #0x10
    //     0x67c404: cmp             x1, x0
    //     0x67c408: b.ls            #0x67ce60
    //     0x67c40c: str             x0, [THR, #0x60]  ; THR::top
    //     0x67c410: sub             x0, x0, #0xf
    //     0x67c414: mov             x1, #0xd108
    //     0x67c418: movk            x1, #3, lsl #16
    //     0x67c41c: stur            x1, [x0, #-1]
    // 0x67c420: StoreField: r0->field_7 = d0
    //     0x67c420: stur            d0, [x0, #7]
    // 0x67c424: ldur            x1, [fp, #-0x38]
    // 0x67c428: StoreField: r1->field_7 = r0
    //     0x67c428: stur            w0, [x1, #7]
    //     0x67c42c: ldurb           w16, [x1, #-1]
    //     0x67c430: ldurb           w17, [x0, #-1]
    //     0x67c434: and             x16, x17, x16, lsr #2
    //     0x67c438: tst             x16, HEAP, lsr #32
    //     0x67c43c: b.eq            #0x67c444
    //     0x67c440: bl              #0xd6826c
    // 0x67c444: ldur            x0, [fp, #-0x20]
    // 0x67c448: LoadField: d1 = r0->field_f
    //     0x67c448: ldur            d1, [x0, #0xf]
    // 0x67c44c: r0 = inline_Allocate_Double()
    //     0x67c44c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x67c450: add             x0, x0, #0x10
    //     0x67c454: cmp             x2, x0
    //     0x67c458: b.ls            #0x67ce70
    //     0x67c45c: str             x0, [THR, #0x60]  ; THR::top
    //     0x67c460: sub             x0, x0, #0xf
    //     0x67c464: mov             x2, #0xd108
    //     0x67c468: movk            x2, #3, lsl #16
    //     0x67c46c: stur            x2, [x0, #-1]
    // 0x67c470: StoreField: r0->field_7 = d1
    //     0x67c470: stur            d1, [x0, #7]
    // 0x67c474: StoreField: r1->field_1f = r0
    //     0x67c474: stur            w0, [x1, #0x1f]
    //     0x67c478: ldurb           w16, [x1, #-1]
    //     0x67c47c: ldurb           w17, [x0, #-1]
    //     0x67c480: and             x16, x17, x16, lsr #2
    //     0x67c484: tst             x16, HEAP, lsr #32
    //     0x67c488: b.eq            #0x67c490
    //     0x67c48c: bl              #0xd6826c
    // 0x67c490: ldur            x4, [fp, #-0x40]
    // 0x67c494: b               #0x67c4a0
    // 0x67c498: ldur            d0, [fp, #-0x78]
    // 0x67c49c: mov             x4, x0
    // 0x67c4a0: ldur            x3, [fp, #-0x58]
    // 0x67c4a4: ldur            d2, [fp, #-0xc0]
    // 0x67c4a8: ldur            d1, [fp, #-0xb0]
    // 0x67c4ac: ldur            d3, [fp, #-0xa8]
    // 0x67c4b0: stur            x4, [fp, #-0x20]
    // 0x67c4b4: LoadField: r5 = r4->field_17
    //     0x67c4b4: ldur            w5, [x4, #0x17]
    // 0x67c4b8: DecompressPointer r5
    //     0x67c4b8: add             x5, x5, HEAP, lsl #32
    // 0x67c4bc: stur            x5, [fp, #-0x18]
    // 0x67c4c0: cmp             w5, NULL
    // 0x67c4c4: b.eq            #0x67ce88
    // 0x67c4c8: mov             x0, x5
    // 0x67c4cc: r2 = Null
    //     0x67c4cc: mov             x2, NULL
    // 0x67c4d0: r1 = Null
    //     0x67c4d0: mov             x1, NULL
    // 0x67c4d4: r4 = LoadClassIdInstr(r0)
    //     0x67c4d4: ldur            x4, [x0, #-1]
    //     0x67c4d8: ubfx            x4, x4, #0xc, #0x14
    // 0x67c4dc: sub             x4, x4, #0x7f9
    // 0x67c4e0: cmp             x4, #2
    // 0x67c4e4: b.ls            #0x67c4fc
    // 0x67c4e8: r8 = SliverMultiBoxAdaptorParentData
    //     0x67c4e8: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67c4ec: ldr             x8, [x8, #0x120]
    // 0x67c4f0: r3 = Null
    //     0x67c4f0: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b150] Null
    //     0x67c4f4: ldr             x3, [x3, #0x150]
    // 0x67c4f8: r0 = DefaultTypeTest()
    //     0x67c4f8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67c4fc: ldur            x0, [fp, #-0x18]
    // 0x67c500: LoadField: r1 = r0->field_17
    //     0x67c500: ldur            w1, [x0, #0x17]
    // 0x67c504: DecompressPointer r1
    //     0x67c504: add             x1, x1, HEAP, lsl #32
    // 0x67c508: cmp             w1, NULL
    // 0x67c50c: b.eq            #0x67ce8c
    // 0x67c510: r0 = LoadInt32Instr(r1)
    //     0x67c510: sbfx            x0, x1, #1, #0x1f
    //     0x67c514: tbz             w1, #0, #0x67c51c
    //     0x67c518: ldur            x0, [x1, #7]
    // 0x67c51c: add             x1, x0, #1
    // 0x67c520: ldur            d0, [fp, #-0xb0]
    // 0x67c524: r0 = inline_Allocate_Double()
    //     0x67c524: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x67c528: add             x0, x0, #0x10
    //     0x67c52c: cmp             x2, x0
    //     0x67c530: b.ls            #0x67ce90
    //     0x67c534: str             x0, [THR, #0x60]  ; THR::top
    //     0x67c538: sub             x0, x0, #0xf
    //     0x67c53c: mov             x2, #0xd108
    //     0x67c540: movk            x2, #3, lsl #16
    //     0x67c544: stur            x2, [x0, #-1]
    // 0x67c548: StoreField: r0->field_7 = d0
    //     0x67c548: stur            d0, [x0, #7]
    // 0x67c54c: ldur            d1, [fp, #-0xa8]
    // 0x67c550: stur            x0, [fp, #-0x40]
    // 0x67c554: r2 = inline_Allocate_Double()
    //     0x67c554: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x67c558: add             x2, x2, #0x10
    //     0x67c55c: cmp             x3, x2
    //     0x67c560: b.ls            #0x67cea8
    //     0x67c564: str             x2, [THR, #0x60]  ; THR::top
    //     0x67c568: sub             x2, x2, #0xf
    //     0x67c56c: mov             x3, #0xd108
    //     0x67c570: movk            x3, #3, lsl #16
    //     0x67c574: stur            x3, [x2, #-1]
    // 0x67c578: StoreField: r2->field_7 = d1
    //     0x67c578: stur            d1, [x2, #7]
    // 0x67c57c: ldur            x3, [fp, #-0x58]
    // 0x67c580: stur            x2, [fp, #-0x38]
    // 0x67c584: lsl             x4, x3, #1
    // 0x67c588: r16 = LoadInt32Instr(r4)
    //     0x67c588: sbfx            x16, x4, #1, #0x1f
    // 0x67c58c: scvtf           d2, w16
    // 0x67c590: ldur            d3, [fp, #-0xc0]
    // 0x67c594: fmul            d4, d2, d3
    // 0x67c598: stur            d4, [fp, #-0xa0]
    // 0x67c59c: fsub            d2, d3, d1
    // 0x67c5a0: stur            d2, [fp, #-0x98]
    // 0x67c5a4: ldur            d6, [fp, #-0x90]
    // 0x67c5a8: ldur            x6, [fp, #-0x20]
    // 0x67c5ac: mov             x5, x1
    // 0x67c5b0: ldur            x4, [fp, #-0x28]
    // 0x67c5b4: ldur            d5, [fp, #-0xb8]
    // 0x67c5b8: ldur            x1, [fp, #-0x50]
    // 0x67c5bc: stur            x6, [fp, #-0x18]
    // 0x67c5c0: stur            x5, [fp, #-0x48]
    // 0x67c5c4: stur            d6, [fp, #-0x90]
    // 0x67c5c8: CheckStackOverflow
    //     0x67c5c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67c5cc: cmp             SP, x16
    //     0x67c5d0: b.ls            #0x67cec4
    // 0x67c5d4: cmp             w4, NULL
    // 0x67c5d8: b.eq            #0x67c5f0
    // 0x67c5dc: r7 = LoadInt32Instr(r4)
    //     0x67c5dc: sbfx            x7, x4, #1, #0x1f
    //     0x67c5e0: tbz             w4, #0, #0x67c5e8
    //     0x67c5e4: ldur            x7, [x4, #7]
    // 0x67c5e8: cmp             x5, x7
    // 0x67c5ec: b.gt            #0x67c938
    // 0x67c5f0: cbz             x3, #0x67cecc
    // 0x67c5f4: sdiv            x8, x5, x3
    // 0x67c5f8: msub            x7, x8, x3, x5
    // 0x67c5fc: cmp             x7, xzr
    // 0x67c600: b.lt            #0x67cf00
    // 0x67c604: scvtf           d7, x7
    // 0x67c608: fmul            d8, d7, d3
    // 0x67c60c: cbz             x3, #0x67cf14
    // 0x67c610: sdiv            x7, x5, x3
    // 0x67c614: scvtf           d7, x7
    // 0x67c618: fmul            d9, d7, d5
    // 0x67c61c: stur            d9, [fp, #-0x88]
    // 0x67c620: tbnz            w1, #4, #0x67c634
    // 0x67c624: fsub            d7, d4, d8
    // 0x67c628: fsub            d8, d7, d1
    // 0x67c62c: fsub            d7, d8, d2
    // 0x67c630: b               #0x67c638
    // 0x67c634: mov             v7.16b, v8.16b
    // 0x67c638: stur            d7, [fp, #-0x70]
    // 0x67c63c: ldur            x16, [fp, #-8]
    // 0x67c640: stp             x0, x16, [SP, #-0x10]!
    // 0x67c644: stp             x2, x0, [SP, #-0x10]!
    // 0x67c648: r4 = const [0, 0x4, 0x4, 0x1, crossAxisExtent, 0x3, maxExtent, 0x2, minExtent, 0x1, null]
    //     0x67c648: add             x4, PP, #0x4b, lsl #12  ; [pp+0x4b120] List(11) [0, 0x4, 0x4, 0x1, "crossAxisExtent", 0x3, "maxExtent", 0x2, "minExtent", 0x1, Null]
    //     0x67c64c: ldr             x4, [x4, #0x120]
    // 0x67c650: r0 = asBoxConstraints()
    //     0x67c650: bl              #0x67a528  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::asBoxConstraints
    // 0x67c654: add             SP, SP, #0x20
    // 0x67c658: mov             x4, x0
    // 0x67c65c: ldur            x3, [fp, #-0x18]
    // 0x67c660: stur            x4, [fp, #-0x60]
    // 0x67c664: LoadField: r5 = r3->field_17
    //     0x67c664: ldur            w5, [x3, #0x17]
    // 0x67c668: DecompressPointer r5
    //     0x67c668: add             x5, x5, HEAP, lsl #32
    // 0x67c66c: stur            x5, [fp, #-0x20]
    // 0x67c670: cmp             w5, NULL
    // 0x67c674: b.eq            #0x67cf48
    // 0x67c678: mov             x0, x5
    // 0x67c67c: r2 = Null
    //     0x67c67c: mov             x2, NULL
    // 0x67c680: r1 = Null
    //     0x67c680: mov             x1, NULL
    // 0x67c684: r4 = LoadClassIdInstr(r0)
    //     0x67c684: ldur            x4, [x0, #-1]
    //     0x67c688: ubfx            x4, x4, #0xc, #0x14
    // 0x67c68c: sub             x4, x4, #0x7f9
    // 0x67c690: cmp             x4, #2
    // 0x67c694: b.ls            #0x67c6ac
    // 0x67c698: r8 = SliverMultiBoxAdaptorParentData
    //     0x67c698: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67c69c: ldr             x8, [x8, #0x120]
    // 0x67c6a0: r3 = Null
    //     0x67c6a0: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b160] Null
    //     0x67c6a4: ldr             x3, [x3, #0x160]
    // 0x67c6a8: r0 = DefaultTypeTest()
    //     0x67c6a8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67c6ac: ldur            x0, [fp, #-0x20]
    // 0x67c6b0: LoadField: r3 = r0->field_f
    //     0x67c6b0: ldur            w3, [x0, #0xf]
    // 0x67c6b4: DecompressPointer r3
    //     0x67c6b4: add             x3, x3, HEAP, lsl #32
    // 0x67c6b8: stur            x3, [fp, #-0x68]
    // 0x67c6bc: cmp             w3, NULL
    // 0x67c6c0: b.ne            #0x67c6cc
    // 0x67c6c4: ldur            x1, [fp, #-0x48]
    // 0x67c6c8: b               #0x67c744
    // 0x67c6cc: ldur            x4, [fp, #-0x48]
    // 0x67c6d0: LoadField: r5 = r3->field_17
    //     0x67c6d0: ldur            w5, [x3, #0x17]
    // 0x67c6d4: DecompressPointer r5
    //     0x67c6d4: add             x5, x5, HEAP, lsl #32
    // 0x67c6d8: stur            x5, [fp, #-0x20]
    // 0x67c6dc: cmp             w5, NULL
    // 0x67c6e0: b.eq            #0x67cf4c
    // 0x67c6e4: mov             x0, x5
    // 0x67c6e8: r2 = Null
    //     0x67c6e8: mov             x2, NULL
    // 0x67c6ec: r1 = Null
    //     0x67c6ec: mov             x1, NULL
    // 0x67c6f0: r4 = LoadClassIdInstr(r0)
    //     0x67c6f0: ldur            x4, [x0, #-1]
    //     0x67c6f4: ubfx            x4, x4, #0xc, #0x14
    // 0x67c6f8: sub             x4, x4, #0x7f9
    // 0x67c6fc: cmp             x4, #2
    // 0x67c700: b.ls            #0x67c718
    // 0x67c704: r8 = SliverMultiBoxAdaptorParentData
    //     0x67c704: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67c708: ldr             x8, [x8, #0x120]
    // 0x67c70c: r3 = Null
    //     0x67c70c: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b170] Null
    //     0x67c710: ldr             x3, [x3, #0x170]
    // 0x67c714: r0 = DefaultTypeTest()
    //     0x67c714: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67c718: ldur            x0, [fp, #-0x20]
    // 0x67c71c: LoadField: r1 = r0->field_17
    //     0x67c71c: ldur            w1, [x0, #0x17]
    // 0x67c720: DecompressPointer r1
    //     0x67c720: add             x1, x1, HEAP, lsl #32
    // 0x67c724: cmp             w1, NULL
    // 0x67c728: b.eq            #0x67cf50
    // 0x67c72c: r0 = LoadInt32Instr(r1)
    //     0x67c72c: sbfx            x0, x1, #1, #0x1f
    //     0x67c730: tbz             w1, #0, #0x67c738
    //     0x67c734: ldur            x0, [x1, #7]
    // 0x67c738: ldur            x1, [fp, #-0x48]
    // 0x67c73c: cmp             x0, x1
    // 0x67c740: b.eq            #0x67c780
    // 0x67c744: ldr             x16, [fp, #0x10]
    // 0x67c748: ldur            lr, [fp, #-0x60]
    // 0x67c74c: stp             lr, x16, [SP, #-0x10]!
    // 0x67c750: ldur            x16, [fp, #-0x18]
    // 0x67c754: SaveReg r16
    //     0x67c754: str             x16, [SP, #-8]!
    // 0x67c758: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x67c758: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x67c75c: r0 = insertAndLayoutChild()
    //     0x67c75c: bl              #0x677f44  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::insertAndLayoutChild
    // 0x67c760: add             SP, SP, #0x18
    // 0x67c764: cmp             w0, NULL
    // 0x67c768: b.ne            #0x67c778
    // 0x67c76c: ldur            d0, [fp, #-0x90]
    // 0x67c770: d3 = 0.000000
    //     0x67c770: eor             v3.16b, v3.16b, v3.16b
    // 0x67c774: b               #0x67c940
    // 0x67c778: mov             x6, x0
    // 0x67c77c: b               #0x67c7b0
    // 0x67c780: ldur            x1, [fp, #-0x68]
    // 0x67c784: r0 = LoadClassIdInstr(r1)
    //     0x67c784: ldur            x0, [x1, #-1]
    //     0x67c788: ubfx            x0, x0, #0xc, #0x14
    // 0x67c78c: ldur            x16, [fp, #-0x60]
    // 0x67c790: stp             x16, x1, [SP, #-0x10]!
    // 0x67c794: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x67c794: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x67c798: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x67c798: mov             x17, #0xcdfb
    //     0x67c79c: add             lr, x0, x17
    //     0x67c7a0: ldr             lr, [x21, lr, lsl #3]
    //     0x67c7a4: blr             lr
    // 0x67c7a8: add             SP, SP, #0x10
    // 0x67c7ac: ldur            x6, [fp, #-0x68]
    // 0x67c7b0: ldur            d1, [fp, #-0x90]
    // 0x67c7b4: ldur            d2, [fp, #-0x88]
    // 0x67c7b8: ldur            d0, [fp, #-0xb0]
    // 0x67c7bc: ldur            d3, [fp, #-0x70]
    // 0x67c7c0: stur            x6, [fp, #-0x20]
    // 0x67c7c4: LoadField: r3 = r6->field_17
    //     0x67c7c4: ldur            w3, [x6, #0x17]
    // 0x67c7c8: DecompressPointer r3
    //     0x67c7c8: add             x3, x3, HEAP, lsl #32
    // 0x67c7cc: stur            x3, [fp, #-0x18]
    // 0x67c7d0: cmp             w3, NULL
    // 0x67c7d4: b.eq            #0x67cf54
    // 0x67c7d8: mov             x0, x3
    // 0x67c7dc: r2 = Null
    //     0x67c7dc: mov             x2, NULL
    // 0x67c7e0: r1 = Null
    //     0x67c7e0: mov             x1, NULL
    // 0x67c7e4: r4 = LoadClassIdInstr(r0)
    //     0x67c7e4: ldur            x4, [x0, #-1]
    //     0x67c7e8: ubfx            x4, x4, #0xc, #0x14
    // 0x67c7ec: cmp             x4, #0x7fb
    // 0x67c7f0: b.eq            #0x67c808
    // 0x67c7f4: r8 = SliverGridParentData
    //     0x67c7f4: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4b128] Type: SliverGridParentData
    //     0x67c7f8: ldr             x8, [x8, #0x128]
    // 0x67c7fc: r3 = Null
    //     0x67c7fc: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b180] Null
    //     0x67c800: ldr             x3, [x3, #0x180]
    // 0x67c804: r0 = DefaultTypeTest()
    //     0x67c804: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67c808: ldur            d0, [fp, #-0x88]
    // 0x67c80c: r0 = inline_Allocate_Double()
    //     0x67c80c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x67c810: add             x0, x0, #0x10
    //     0x67c814: cmp             x1, x0
    //     0x67c818: b.ls            #0x67cf58
    //     0x67c81c: str             x0, [THR, #0x60]  ; THR::top
    //     0x67c820: sub             x0, x0, #0xf
    //     0x67c824: mov             x1, #0xd108
    //     0x67c828: movk            x1, #3, lsl #16
    //     0x67c82c: stur            x1, [x0, #-1]
    // 0x67c830: StoreField: r0->field_7 = d0
    //     0x67c830: stur            d0, [x0, #7]
    // 0x67c834: ldur            x1, [fp, #-0x18]
    // 0x67c838: StoreField: r1->field_7 = r0
    //     0x67c838: stur            w0, [x1, #7]
    //     0x67c83c: ldurb           w16, [x1, #-1]
    //     0x67c840: ldurb           w17, [x0, #-1]
    //     0x67c844: and             x16, x17, x16, lsr #2
    //     0x67c848: tst             x16, HEAP, lsr #32
    //     0x67c84c: b.eq            #0x67c854
    //     0x67c850: bl              #0xd6826c
    // 0x67c854: ldur            d1, [fp, #-0x70]
    // 0x67c858: r0 = inline_Allocate_Double()
    //     0x67c858: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x67c85c: add             x0, x0, #0x10
    //     0x67c860: cmp             x2, x0
    //     0x67c864: b.ls            #0x67cf68
    //     0x67c868: str             x0, [THR, #0x60]  ; THR::top
    //     0x67c86c: sub             x0, x0, #0xf
    //     0x67c870: mov             x2, #0xd108
    //     0x67c874: movk            x2, #3, lsl #16
    //     0x67c878: stur            x2, [x0, #-1]
    // 0x67c87c: StoreField: r0->field_7 = d1
    //     0x67c87c: stur            d1, [x0, #7]
    // 0x67c880: StoreField: r1->field_1f = r0
    //     0x67c880: stur            w0, [x1, #0x1f]
    //     0x67c884: ldurb           w16, [x1, #-1]
    //     0x67c888: ldurb           w17, [x0, #-1]
    //     0x67c88c: and             x16, x17, x16, lsr #2
    //     0x67c890: tst             x16, HEAP, lsr #32
    //     0x67c894: b.eq            #0x67c89c
    //     0x67c898: bl              #0xd6826c
    // 0x67c89c: ldur            d1, [fp, #-0xb0]
    // 0x67c8a0: fadd            d2, d0, d1
    // 0x67c8a4: ldur            d0, [fp, #-0x90]
    // 0x67c8a8: fcmp            d0, d2
    // 0x67c8ac: b.vs            #0x67c8c0
    // 0x67c8b0: b.le            #0x67c8c0
    // 0x67c8b4: mov             v6.16b, v0.16b
    // 0x67c8b8: d3 = 0.000000
    //     0x67c8b8: eor             v3.16b, v3.16b, v3.16b
    // 0x67c8bc: b               #0x67c908
    // 0x67c8c0: fcmp            d0, d2
    // 0x67c8c4: b.vs            #0x67c8d8
    // 0x67c8c8: b.ge            #0x67c8d8
    // 0x67c8cc: mov             v6.16b, v2.16b
    // 0x67c8d0: d3 = 0.000000
    //     0x67c8d0: eor             v3.16b, v3.16b, v3.16b
    // 0x67c8d4: b               #0x67c908
    // 0x67c8d8: d3 = 0.000000
    //     0x67c8d8: eor             v3.16b, v3.16b, v3.16b
    // 0x67c8dc: fcmp            d0, d3
    // 0x67c8e0: b.vs            #0x67c8f4
    // 0x67c8e4: b.ne            #0x67c8f4
    // 0x67c8e8: fadd            d4, d0, d2
    // 0x67c8ec: mov             v6.16b, v4.16b
    // 0x67c8f0: b               #0x67c908
    // 0x67c8f4: fcmp            d2, d2
    // 0x67c8f8: b.vc            #0x67c904
    // 0x67c8fc: mov             v6.16b, v2.16b
    // 0x67c900: b               #0x67c908
    // 0x67c904: mov             v6.16b, v0.16b
    // 0x67c908: ldur            x0, [fp, #-0x48]
    // 0x67c90c: add             x5, x0, #1
    // 0x67c910: ldur            x6, [fp, #-0x20]
    // 0x67c914: ldur            x3, [fp, #-0x58]
    // 0x67c918: ldur            d3, [fp, #-0xc0]
    // 0x67c91c: mov             v0.16b, v1.16b
    // 0x67c920: ldur            d1, [fp, #-0xa8]
    // 0x67c924: ldur            d4, [fp, #-0xa0]
    // 0x67c928: ldur            d2, [fp, #-0x98]
    // 0x67c92c: ldur            x0, [fp, #-0x40]
    // 0x67c930: ldur            x2, [fp, #-0x38]
    // 0x67c934: b               #0x67c5b0
    // 0x67c938: mov             v0.16b, v6.16b
    // 0x67c93c: d3 = 0.000000
    //     0x67c93c: eor             v3.16b, v3.16b, v3.16b
    // 0x67c940: ldr             x3, [fp, #0x10]
    // 0x67c944: ldur            d2, [fp, #-0x80]
    // 0x67c948: ldur            x4, [fp, #-0x30]
    // 0x67c94c: ldur            d1, [fp, #-0x78]
    // 0x67c950: LoadField: r0 = r3->field_5f
    //     0x67c950: ldur            w0, [x3, #0x5f]
    // 0x67c954: DecompressPointer r0
    //     0x67c954: add             x0, x0, HEAP, lsl #32
    // 0x67c958: cmp             w0, NULL
    // 0x67c95c: b.eq            #0x67cf80
    // 0x67c960: LoadField: r5 = r0->field_17
    //     0x67c960: ldur            w5, [x0, #0x17]
    // 0x67c964: DecompressPointer r5
    //     0x67c964: add             x5, x5, HEAP, lsl #32
    // 0x67c968: stur            x5, [fp, #-0x18]
    // 0x67c96c: cmp             w5, NULL
    // 0x67c970: b.eq            #0x67cf84
    // 0x67c974: mov             x0, x5
    // 0x67c978: r2 = Null
    //     0x67c978: mov             x2, NULL
    // 0x67c97c: r1 = Null
    //     0x67c97c: mov             x1, NULL
    // 0x67c980: r4 = LoadClassIdInstr(r0)
    //     0x67c980: ldur            x4, [x0, #-1]
    //     0x67c984: ubfx            x4, x4, #0xc, #0x14
    // 0x67c988: sub             x4, x4, #0x7f9
    // 0x67c98c: cmp             x4, #2
    // 0x67c990: b.ls            #0x67c9a8
    // 0x67c994: r8 = SliverMultiBoxAdaptorParentData
    //     0x67c994: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67c998: ldr             x8, [x8, #0x120]
    // 0x67c99c: r3 = Null
    //     0x67c99c: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b190] Null
    //     0x67c9a0: ldr             x3, [x3, #0x190]
    // 0x67c9a4: r0 = DefaultTypeTest()
    //     0x67c9a4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67c9a8: ldur            x0, [fp, #-0x18]
    // 0x67c9ac: LoadField: r2 = r0->field_17
    //     0x67c9ac: ldur            w2, [x0, #0x17]
    // 0x67c9b0: DecompressPointer r2
    //     0x67c9b0: add             x2, x2, HEAP, lsl #32
    // 0x67c9b4: cmp             w2, NULL
    // 0x67c9b8: b.eq            #0x67cf88
    // 0x67c9bc: ldur            x3, [fp, #-0x30]
    // 0x67c9c0: r0 = BoxInt64Instr(r3)
    //     0x67c9c0: sbfiz           x0, x3, #1, #0x1f
    //     0x67c9c4: cmp             x3, x0, asr #1
    //     0x67c9c8: b.eq            #0x67c9d4
    //     0x67c9cc: bl              #0xd69bb8
    //     0x67c9d0: stur            x3, [x0, #7]
    // 0x67c9d4: ldur            d0, [fp, #-0x78]
    // 0x67c9d8: r1 = inline_Allocate_Double()
    //     0x67c9d8: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x67c9dc: add             x1, x1, #0x10
    //     0x67c9e0: cmp             x3, x1
    //     0x67c9e4: b.ls            #0x67cf8c
    //     0x67c9e8: str             x1, [THR, #0x60]  ; THR::top
    //     0x67c9ec: sub             x1, x1, #0xf
    //     0x67c9f0: mov             x3, #0xd108
    //     0x67c9f4: movk            x3, #3, lsl #16
    //     0x67c9f8: stur            x3, [x1, #-1]
    // 0x67c9fc: StoreField: r1->field_7 = d0
    //     0x67c9fc: stur            d0, [x1, #7]
    // 0x67ca00: stur            x1, [fp, #-0x18]
    // 0x67ca04: ldur            x16, [fp, #-0x10]
    // 0x67ca08: ldur            lr, [fp, #-8]
    // 0x67ca0c: stp             lr, x16, [SP, #-0x10]!
    // 0x67ca10: stp             x2, x0, [SP, #-0x10]!
    // 0x67ca14: SaveReg r1
    //     0x67ca14: str             x1, [SP, #-8]!
    // 0x67ca18: ldur            d1, [fp, #-0x90]
    // 0x67ca1c: SaveReg d1
    //     0x67ca1c: str             d1, [SP, #-8]!
    // 0x67ca20: r0 = estimateMaxScrollOffset()
    //     0x67ca20: bl              #0x677cec  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::estimateMaxScrollOffset
    // 0x67ca24: add             SP, SP, #0x30
    // 0x67ca28: mov             v2.16b, v0.16b
    // 0x67ca2c: ldur            d1, [fp, #-0x80]
    // 0x67ca30: ldur            d0, [fp, #-0x78]
    // 0x67ca34: stur            d2, [fp, #-0x70]
    // 0x67ca38: fcmp            d1, d0
    // 0x67ca3c: b.vs            #0x67ca50
    // 0x67ca40: b.le            #0x67ca50
    // 0x67ca44: mov             v3.16b, v0.16b
    // 0x67ca48: mov             v1.16b, v2.16b
    // 0x67ca4c: b               #0x67cae0
    // 0x67ca50: fcmp            d1, d0
    // 0x67ca54: b.vs            #0x67ca68
    // 0x67ca58: b.ge            #0x67ca68
    // 0x67ca5c: mov             v3.16b, v1.16b
    // 0x67ca60: mov             v1.16b, v2.16b
    // 0x67ca64: b               #0x67cae0
    // 0x67ca68: d3 = 0.000000
    //     0x67ca68: eor             v3.16b, v3.16b, v3.16b
    // 0x67ca6c: fcmp            d1, d3
    // 0x67ca70: b.vs            #0x67ca78
    // 0x67ca74: b.eq            #0x67ca80
    // 0x67ca78: r0 = false
    //     0x67ca78: add             x0, NULL, #0x30  ; false
    // 0x67ca7c: b               #0x67ca84
    // 0x67ca80: r0 = true
    //     0x67ca80: add             x0, NULL, #0x20  ; true
    // 0x67ca84: tbnz            w0, #4, #0x67caa0
    // 0x67ca88: fadd            d4, d1, d0
    // 0x67ca8c: fmul            d5, d4, d1
    // 0x67ca90: fmul            d4, d5, d0
    // 0x67ca94: mov             v3.16b, v4.16b
    // 0x67ca98: mov             v1.16b, v2.16b
    // 0x67ca9c: b               #0x67cae0
    // 0x67caa0: tbnz            w0, #4, #0x67cac0
    // 0x67caa4: ldur            x16, [fp, #-0x18]
    // 0x67caa8: SaveReg r16
    //     0x67caa8: str             x16, [SP, #-8]!
    // 0x67caac: r0 = isNegative()
    //     0x67caac: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x67cab0: add             SP, SP, #8
    // 0x67cab4: tbnz            w0, #4, #0x67cac0
    // 0x67cab8: ldur            d0, [fp, #-0x78]
    // 0x67cabc: b               #0x67cacc
    // 0x67cac0: ldur            d0, [fp, #-0x78]
    // 0x67cac4: fcmp            d0, d0
    // 0x67cac8: b.vc            #0x67cad8
    // 0x67cacc: mov             v3.16b, v0.16b
    // 0x67cad0: ldur            d1, [fp, #-0x70]
    // 0x67cad4: b               #0x67cae0
    // 0x67cad8: ldur            d3, [fp, #-0x80]
    // 0x67cadc: ldur            d1, [fp, #-0x70]
    // 0x67cae0: ldur            d2, [fp, #-0x90]
    // 0x67cae4: r0 = inline_Allocate_Double()
    //     0x67cae4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x67cae8: add             x0, x0, #0x10
    //     0x67caec: cmp             x1, x0
    //     0x67caf0: b.ls            #0x67cfa8
    //     0x67caf4: str             x0, [THR, #0x60]  ; THR::top
    //     0x67caf8: sub             x0, x0, #0xf
    //     0x67cafc: mov             x1, #0xd108
    //     0x67cb00: movk            x1, #3, lsl #16
    //     0x67cb04: stur            x1, [x0, #-1]
    // 0x67cb08: StoreField: r0->field_7 = d2
    //     0x67cb08: stur            d2, [x0, #7]
    // 0x67cb0c: ldr             x16, [fp, #0x10]
    // 0x67cb10: ldur            lr, [fp, #-8]
    // 0x67cb14: stp             lr, x16, [SP, #-0x10]!
    // 0x67cb18: SaveReg d3
    //     0x67cb18: str             d3, [SP, #-8]!
    // 0x67cb1c: SaveReg r0
    //     0x67cb1c: str             x0, [SP, #-8]!
    // 0x67cb20: r0 = calculatePaintOffset()
    //     0x67cb20: bl              #0x677ba0  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0x67cb24: add             SP, SP, #0x20
    // 0x67cb28: mov             v1.16b, v0.16b
    // 0x67cb2c: ldur            d0, [fp, #-0x90]
    // 0x67cb30: stur            d1, [fp, #-0x88]
    // 0x67cb34: r0 = inline_Allocate_Double()
    //     0x67cb34: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x67cb38: add             x0, x0, #0x10
    //     0x67cb3c: cmp             x1, x0
    //     0x67cb40: b.ls            #0x67cfc0
    //     0x67cb44: str             x0, [THR, #0x60]  ; THR::top
    //     0x67cb48: sub             x0, x0, #0xf
    //     0x67cb4c: mov             x1, #0xd108
    //     0x67cb50: movk            x1, #3, lsl #16
    //     0x67cb54: stur            x1, [x0, #-1]
    // 0x67cb58: StoreField: r0->field_7 = d0
    //     0x67cb58: stur            d0, [x0, #7]
    // 0x67cb5c: ldr             x16, [fp, #0x10]
    // 0x67cb60: ldur            lr, [fp, #-8]
    // 0x67cb64: stp             lr, x16, [SP, #-0x10]!
    // 0x67cb68: ldur            d2, [fp, #-0x78]
    // 0x67cb6c: SaveReg d2
    //     0x67cb6c: str             d2, [SP, #-8]!
    // 0x67cb70: SaveReg r0
    //     0x67cb70: str             x0, [SP, #-8]!
    // 0x67cb74: r0 = calculateCacheOffset()
    //     0x67cb74: bl              #0x677aa4  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculateCacheOffset
    // 0x67cb78: add             SP, SP, #0x20
    // 0x67cb7c: mov             v2.16b, v0.16b
    // 0x67cb80: ldur            d1, [fp, #-0x70]
    // 0x67cb84: ldur            d0, [fp, #-0x88]
    // 0x67cb88: stur            d2, [fp, #-0x78]
    // 0x67cb8c: fcmp            d1, d0
    // 0x67cb90: b.vs            #0x67cba0
    // 0x67cb94: b.le            #0x67cba0
    // 0x67cb98: d4 = 0.000000
    //     0x67cb98: eor             v4.16b, v4.16b, v4.16b
    // 0x67cb9c: b               #0x67cbb4
    // 0x67cba0: ldur            d3, [fp, #-0x80]
    // 0x67cba4: d4 = 0.000000
    //     0x67cba4: eor             v4.16b, v4.16b, v4.16b
    // 0x67cba8: fcmp            d3, d4
    // 0x67cbac: b.vs            #0x67cbbc
    // 0x67cbb0: b.le            #0x67cbbc
    // 0x67cbb4: r1 = true
    //     0x67cbb4: add             x1, NULL, #0x20  ; true
    // 0x67cbb8: b               #0x67cbd8
    // 0x67cbbc: ldur            x0, [fp, #-8]
    // 0x67cbc0: LoadField: d3 = r0->field_23
    //     0x67cbc0: ldur            d3, [x0, #0x23]
    // 0x67cbc4: fcmp            d3, d4
    // 0x67cbc8: r16 = true
    //     0x67cbc8: add             x16, NULL, #0x20  ; true
    // 0x67cbcc: r17 = false
    //     0x67cbcc: add             x17, NULL, #0x30  ; false
    // 0x67cbd0: csel            x0, x16, x17, ne
    // 0x67cbd4: mov             x1, x0
    // 0x67cbd8: ldr             x0, [fp, #0x10]
    // 0x67cbdc: ldur            d3, [fp, #-0x90]
    // 0x67cbe0: stur            x1, [fp, #-8]
    // 0x67cbe4: r0 = SliverGeometry()
    //     0x67cbe4: bl              #0x679334  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x54)
    // 0x67cbe8: ldur            d0, [fp, #-0x70]
    // 0x67cbec: StoreField: r0->field_7 = d0
    //     0x67cbec: stur            d0, [x0, #7]
    // 0x67cbf0: ldur            d1, [fp, #-0x88]
    // 0x67cbf4: StoreField: r0->field_17 = d1
    //     0x67cbf4: stur            d1, [x0, #0x17]
    // 0x67cbf8: d2 = 0.000000
    //     0x67cbf8: eor             v2.16b, v2.16b, v2.16b
    // 0x67cbfc: StoreField: r0->field_f = d2
    //     0x67cbfc: stur            d2, [x0, #0xf]
    // 0x67cc00: StoreField: r0->field_27 = d0
    //     0x67cc00: stur            d0, [x0, #0x27]
    // 0x67cc04: StoreField: r0->field_2f = d2
    //     0x67cc04: stur            d2, [x0, #0x2f]
    // 0x67cc08: ldur            x1, [fp, #-8]
    // 0x67cc0c: StoreField: r0->field_43 = r1
    //     0x67cc0c: stur            w1, [x0, #0x43]
    // 0x67cc10: StoreField: r0->field_1f = d1
    //     0x67cc10: stur            d1, [x0, #0x1f]
    // 0x67cc14: StoreField: r0->field_37 = d1
    //     0x67cc14: stur            d1, [x0, #0x37]
    // 0x67cc18: ldur            d3, [fp, #-0x78]
    // 0x67cc1c: StoreField: r0->field_4b = d3
    //     0x67cc1c: stur            d3, [x0, #0x4b]
    // 0x67cc20: fcmp            d1, d2
    // 0x67cc24: b.vs            #0x67cc2c
    // 0x67cc28: b.gt            #0x67cc34
    // 0x67cc2c: r1 = false
    //     0x67cc2c: add             x1, NULL, #0x30  ; false
    // 0x67cc30: b               #0x67cc38
    // 0x67cc34: r1 = true
    //     0x67cc34: add             x1, NULL, #0x20  ; true
    // 0x67cc38: StoreField: r0->field_3f = r1
    //     0x67cc38: stur            w1, [x0, #0x3f]
    // 0x67cc3c: ldr             x1, [fp, #0x10]
    // 0x67cc40: StoreField: r1->field_4f = r0
    //     0x67cc40: stur            w0, [x1, #0x4f]
    //     0x67cc44: ldurb           w16, [x1, #-1]
    //     0x67cc48: ldurb           w17, [x0, #-1]
    //     0x67cc4c: and             x16, x17, x16, lsr #2
    //     0x67cc50: tst             x16, HEAP, lsr #32
    //     0x67cc54: b.eq            #0x67cc5c
    //     0x67cc58: bl              #0xd6826c
    // 0x67cc5c: ldur            d1, [fp, #-0x90]
    // 0x67cc60: fcmp            d0, d1
    // 0x67cc64: b.vs            #0x67cc7c
    // 0x67cc68: b.ne            #0x67cc7c
    // 0x67cc6c: ldur            x0, [fp, #-0x10]
    // 0x67cc70: r1 = true
    //     0x67cc70: add             x1, NULL, #0x20  ; true
    // 0x67cc74: StoreField: r0->field_53 = r1
    //     0x67cc74: stur            w1, [x0, #0x53]
    // 0x67cc78: b               #0x67cc80
    // 0x67cc7c: ldur            x0, [fp, #-0x10]
    // 0x67cc80: SaveReg r0
    //     0x67cc80: str             x0, [SP, #-8]!
    // 0x67cc84: r0 = didFinishLayout()
    //     0x67cc84: bl              #0x678c84  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::didFinishLayout
    // 0x67cc88: add             SP, SP, #8
    // 0x67cc8c: r0 = Null
    //     0x67cc8c: mov             x0, NULL
    // 0x67cc90: LeaveFrame
    //     0x67cc90: mov             SP, fp
    //     0x67cc94: ldp             fp, lr, [SP], #0x10
    // 0x67cc98: ret
    //     0x67cc98: ret             
    // 0x67cc9c: r0 = StateError()
    //     0x67cc9c: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x67cca0: mov             x1, x0
    // 0x67cca4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x67cca4: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x67cca8: ldr             x0, [x0, #0x1e8]
    // 0x67ccac: StoreField: r1->field_b = r0
    //     0x67ccac: stur            w0, [x1, #0xb]
    // 0x67ccb0: mov             x0, x1
    // 0x67ccb4: r0 = Throw()
    //     0x67ccb4: bl              #0xd67e38  ; ThrowStub
    // 0x67ccb8: brk             #0
    // 0x67ccbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x67ccbc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x67ccc0: b               #0x67ba40
    // 0x67ccc4: stp             q1, q3, [SP, #-0x20]!
    // 0x67ccc8: stp             x3, x4, [SP, #-0x10]!
    // 0x67cccc: d0 = 0.000000
    //     0x67cccc: fmov            d0, d3
    // 0x67ccd0: r0 = 208
    //     0x67ccd0: mov             x0, #0xd0
    // 0x67ccd4: r24 = DoubleToIntegerStub
    //     0x67ccd4: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x67ccd8: LoadField: r30 = r24->field_7
    //     0x67ccd8: ldur            lr, [x24, #7]
    // 0x67ccdc: blr             lr
    // 0x67cce0: ldp             x3, x4, [SP], #0x10
    // 0x67cce4: ldp             q1, q3, [SP], #0x20
    // 0x67cce8: b               #0x67bb50
    // 0x67ccec: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67ccec: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67ccf0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ccf0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ccf4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ccf4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ccf8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ccf8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ccfc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ccfc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67cd00: SaveReg d0
    //     0x67cd00: str             q0, [SP, #-0x10]!
    // 0x67cd04: stp             x3, x4, [SP, #-0x10]!
    // 0x67cd08: stp             x0, x2, [SP, #-0x10]!
    // 0x67cd0c: r0 = AllocateDouble()
    //     0x67cd0c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67cd10: mov             x1, x0
    // 0x67cd14: ldp             x0, x2, [SP], #0x10
    // 0x67cd18: ldp             x3, x4, [SP], #0x10
    // 0x67cd1c: RestoreReg d0
    //     0x67cd1c: ldr             q0, [SP], #0x10
    // 0x67cd20: b               #0x67be80
    // 0x67cd24: stp             x1, x3, [SP, #-0x10]!
    // 0x67cd28: SaveReg r0
    //     0x67cd28: str             x0, [SP, #-8]!
    // 0x67cd2c: ldr             x5, [THR, #0x4a8]  ; THR::IntegerDivisionByZeroException
    // 0x67cd30: r4 = 0
    //     0x67cd30: mov             x4, #0
    // 0x67cd34: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x67cd38: blr             lr
    // 0x67cd3c: brk             #0
    // 0x67cd40: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67cd40: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67cd44: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67cd44: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67cd48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67cd48: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67cd4c: stp             q2, q3, [SP, #-0x20]!
    // 0x67cd50: stp             q0, q1, [SP, #-0x20]!
    // 0x67cd54: stp             x2, x3, [SP, #-0x10]!
    // 0x67cd58: SaveReg r1
    //     0x67cd58: str             x1, [SP, #-8]!
    // 0x67cd5c: r0 = AllocateDouble()
    //     0x67cd5c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67cd60: RestoreReg r1
    //     0x67cd60: ldr             x1, [SP], #8
    // 0x67cd64: ldp             x2, x3, [SP], #0x10
    // 0x67cd68: ldp             q0, q1, [SP], #0x20
    // 0x67cd6c: ldp             q2, q3, [SP], #0x20
    // 0x67cd70: b               #0x67c088
    // 0x67cd74: stp             q2, q3, [SP, #-0x20]!
    // 0x67cd78: stp             q0, q1, [SP, #-0x20]!
    // 0x67cd7c: stp             x2, x3, [SP, #-0x10]!
    // 0x67cd80: stp             x0, x1, [SP, #-0x10]!
    // 0x67cd84: r0 = AllocateDouble()
    //     0x67cd84: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67cd88: mov             x4, x0
    // 0x67cd8c: ldp             x0, x1, [SP], #0x10
    // 0x67cd90: ldp             x2, x3, [SP], #0x10
    // 0x67cd94: ldp             q0, q1, [SP], #0x20
    // 0x67cd98: ldp             q2, q3, [SP], #0x20
    // 0x67cd9c: b               #0x67c0b4
    // 0x67cda0: r0 = StackOverflowSharedWithFPURegs()
    //     0x67cda0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x67cda4: b               #0x67c100
    // 0x67cda8: stp             q5, q6, [SP, #-0x20]!
    // 0x67cdac: stp             q3, q4, [SP, #-0x20]!
    // 0x67cdb0: stp             q1, q2, [SP, #-0x20]!
    // 0x67cdb4: SaveReg d0
    //     0x67cdb4: str             q0, [SP, #-0x10]!
    // 0x67cdb8: stp             x5, x6, [SP, #-0x10]!
    // 0x67cdbc: stp             x3, x4, [SP, #-0x10]!
    // 0x67cdc0: stp             x1, x2, [SP, #-0x10]!
    // 0x67cdc4: SaveReg r0
    //     0x67cdc4: str             x0, [SP, #-8]!
    // 0x67cdc8: ldr             x5, [THR, #0x4a8]  ; THR::IntegerDivisionByZeroException
    // 0x67cdcc: r4 = 0
    //     0x67cdcc: mov             x4, #0
    // 0x67cdd0: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x67cdd4: blr             lr
    // 0x67cdd8: brk             #0
    // 0x67cddc: cmp             x2, xzr
    // 0x67cde0: sub             x8, x7, x2
    // 0x67cde4: add             x7, x7, x2
    // 0x67cde8: csel            x7, x8, x7, lt
    // 0x67cdec: b               #0x67c11c
    // 0x67cdf0: stp             q6, q8, [SP, #-0x20]!
    // 0x67cdf4: stp             q4, q5, [SP, #-0x20]!
    // 0x67cdf8: stp             q2, q3, [SP, #-0x20]!
    // 0x67cdfc: stp             q0, q1, [SP, #-0x20]!
    // 0x67ce00: stp             x5, x6, [SP, #-0x10]!
    // 0x67ce04: stp             x3, x4, [SP, #-0x10]!
    // 0x67ce08: stp             x1, x2, [SP, #-0x10]!
    // 0x67ce0c: SaveReg r0
    //     0x67ce0c: str             x0, [SP, #-8]!
    // 0x67ce10: ldr             x5, [THR, #0x4a8]  ; THR::IntegerDivisionByZeroException
    // 0x67ce14: r4 = 0
    //     0x67ce14: mov             x4, #0
    // 0x67ce18: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x67ce1c: blr             lr
    // 0x67ce20: brk             #0
    // 0x67ce24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ce24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ce28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ce28: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ce2c: SaveReg d0
    //     0x67ce2c: str             q0, [SP, #-0x10]!
    // 0x67ce30: r0 = AllocateDouble()
    //     0x67ce30: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67ce34: RestoreReg d0
    //     0x67ce34: ldr             q0, [SP], #0x10
    // 0x67ce38: b               #0x67c200
    // 0x67ce3c: stp             q0, q1, [SP, #-0x20]!
    // 0x67ce40: SaveReg r1
    //     0x67ce40: str             x1, [SP, #-8]!
    // 0x67ce44: r0 = AllocateDouble()
    //     0x67ce44: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67ce48: RestoreReg r1
    //     0x67ce48: ldr             x1, [SP], #8
    // 0x67ce4c: ldp             q0, q1, [SP], #0x20
    // 0x67ce50: b               #0x67c24c
    // 0x67ce54: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67ce54: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67ce58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ce58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ce5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ce5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ce60: SaveReg d0
    //     0x67ce60: str             q0, [SP, #-0x10]!
    // 0x67ce64: r0 = AllocateDouble()
    //     0x67ce64: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67ce68: RestoreReg d0
    //     0x67ce68: ldr             q0, [SP], #0x10
    // 0x67ce6c: b               #0x67c420
    // 0x67ce70: stp             q0, q1, [SP, #-0x20]!
    // 0x67ce74: SaveReg r1
    //     0x67ce74: str             x1, [SP, #-8]!
    // 0x67ce78: r0 = AllocateDouble()
    //     0x67ce78: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67ce7c: RestoreReg r1
    //     0x67ce7c: ldr             x1, [SP], #8
    // 0x67ce80: ldp             q0, q1, [SP], #0x20
    // 0x67ce84: b               #0x67c470
    // 0x67ce88: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67ce88: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67ce8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67ce8c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67ce90: SaveReg d0
    //     0x67ce90: str             q0, [SP, #-0x10]!
    // 0x67ce94: SaveReg r1
    //     0x67ce94: str             x1, [SP, #-8]!
    // 0x67ce98: r0 = AllocateDouble()
    //     0x67ce98: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67ce9c: RestoreReg r1
    //     0x67ce9c: ldr             x1, [SP], #8
    // 0x67cea0: RestoreReg d0
    //     0x67cea0: ldr             q0, [SP], #0x10
    // 0x67cea4: b               #0x67c548
    // 0x67cea8: stp             q0, q1, [SP, #-0x20]!
    // 0x67ceac: stp             x0, x1, [SP, #-0x10]!
    // 0x67ceb0: r0 = AllocateDouble()
    //     0x67ceb0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67ceb4: mov             x2, x0
    // 0x67ceb8: ldp             x0, x1, [SP], #0x10
    // 0x67cebc: ldp             q0, q1, [SP], #0x20
    // 0x67cec0: b               #0x67c578
    // 0x67cec4: r0 = StackOverflowSharedWithFPURegs()
    //     0x67cec4: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x67cec8: b               #0x67c5d4
    // 0x67cecc: stp             q5, q6, [SP, #-0x20]!
    // 0x67ced0: stp             q3, q4, [SP, #-0x20]!
    // 0x67ced4: stp             q1, q2, [SP, #-0x20]!
    // 0x67ced8: SaveReg d0
    //     0x67ced8: str             q0, [SP, #-0x10]!
    // 0x67cedc: stp             x5, x6, [SP, #-0x10]!
    // 0x67cee0: stp             x3, x4, [SP, #-0x10]!
    // 0x67cee4: stp             x1, x2, [SP, #-0x10]!
    // 0x67cee8: SaveReg r0
    //     0x67cee8: str             x0, [SP, #-8]!
    // 0x67ceec: ldr             x5, [THR, #0x4a8]  ; THR::IntegerDivisionByZeroException
    // 0x67cef0: r4 = 0
    //     0x67cef0: mov             x4, #0
    // 0x67cef4: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x67cef8: blr             lr
    // 0x67cefc: brk             #0
    // 0x67cf00: cmp             x3, xzr
    // 0x67cf04: sub             x8, x7, x3
    // 0x67cf08: add             x7, x7, x3
    // 0x67cf0c: csel            x7, x8, x7, lt
    // 0x67cf10: b               #0x67c604
    // 0x67cf14: stp             q6, q8, [SP, #-0x20]!
    // 0x67cf18: stp             q4, q5, [SP, #-0x20]!
    // 0x67cf1c: stp             q2, q3, [SP, #-0x20]!
    // 0x67cf20: stp             q0, q1, [SP, #-0x20]!
    // 0x67cf24: stp             x5, x6, [SP, #-0x10]!
    // 0x67cf28: stp             x3, x4, [SP, #-0x10]!
    // 0x67cf2c: stp             x1, x2, [SP, #-0x10]!
    // 0x67cf30: SaveReg r0
    //     0x67cf30: str             x0, [SP, #-8]!
    // 0x67cf34: ldr             x5, [THR, #0x4a8]  ; THR::IntegerDivisionByZeroException
    // 0x67cf38: r4 = 0
    //     0x67cf38: mov             x4, #0
    // 0x67cf3c: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x67cf40: blr             lr
    // 0x67cf44: brk             #0
    // 0x67cf48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67cf48: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67cf4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67cf4c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67cf50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67cf50: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67cf54: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67cf54: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67cf58: SaveReg d0
    //     0x67cf58: str             q0, [SP, #-0x10]!
    // 0x67cf5c: r0 = AllocateDouble()
    //     0x67cf5c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67cf60: RestoreReg d0
    //     0x67cf60: ldr             q0, [SP], #0x10
    // 0x67cf64: b               #0x67c830
    // 0x67cf68: stp             q0, q1, [SP, #-0x20]!
    // 0x67cf6c: SaveReg r1
    //     0x67cf6c: str             x1, [SP, #-8]!
    // 0x67cf70: r0 = AllocateDouble()
    //     0x67cf70: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67cf74: RestoreReg r1
    //     0x67cf74: ldr             x1, [SP], #8
    // 0x67cf78: ldp             q0, q1, [SP], #0x20
    // 0x67cf7c: b               #0x67c87c
    // 0x67cf80: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67cf80: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67cf84: r0 = NullCastErrorSharedWithFPURegs()
    //     0x67cf84: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x67cf88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67cf88: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x67cf8c: SaveReg d0
    //     0x67cf8c: str             q0, [SP, #-0x10]!
    // 0x67cf90: stp             x0, x2, [SP, #-0x10]!
    // 0x67cf94: r0 = AllocateDouble()
    //     0x67cf94: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67cf98: mov             x1, x0
    // 0x67cf9c: ldp             x0, x2, [SP], #0x10
    // 0x67cfa0: RestoreReg d0
    //     0x67cfa0: ldr             q0, [SP], #0x10
    // 0x67cfa4: b               #0x67c9fc
    // 0x67cfa8: stp             q2, q3, [SP, #-0x20]!
    // 0x67cfac: stp             q0, q1, [SP, #-0x20]!
    // 0x67cfb0: r0 = AllocateDouble()
    //     0x67cfb0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67cfb4: ldp             q0, q1, [SP], #0x20
    // 0x67cfb8: ldp             q2, q3, [SP], #0x20
    // 0x67cfbc: b               #0x67cb08
    // 0x67cfc0: stp             q0, q1, [SP, #-0x20]!
    // 0x67cfc4: r0 = AllocateDouble()
    //     0x67cfc4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67cfc8: ldp             q0, q1, [SP], #0x20
    // 0x67cfcc: b               #0x67cb58
  }
  set _ gridDelegate=(/* No info */) {
    // ** addr: 0x6c1e08, size: 0x108
    // 0x6c1e08: EnterFrame
    //     0x6c1e08: stp             fp, lr, [SP, #-0x10]!
    //     0x6c1e0c: mov             fp, SP
    // 0x6c1e10: CheckStackOverflow
    //     0x6c1e10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c1e14: cmp             SP, x16
    //     0x6c1e18: b.ls            #0x6c1f08
    // 0x6c1e1c: ldr             x0, [fp, #0x18]
    // 0x6c1e20: LoadField: r1 = r0->field_6b
    //     0x6c1e20: ldur            w1, [x0, #0x6b]
    // 0x6c1e24: DecompressPointer r1
    //     0x6c1e24: add             x1, x1, HEAP, lsl #32
    // 0x6c1e28: ldr             x2, [fp, #0x10]
    // 0x6c1e2c: cmp             w1, w2
    // 0x6c1e30: b.ne            #0x6c1e44
    // 0x6c1e34: r0 = Null
    //     0x6c1e34: mov             x0, NULL
    // 0x6c1e38: LeaveFrame
    //     0x6c1e38: mov             SP, fp
    //     0x6c1e3c: ldp             fp, lr, [SP], #0x10
    // 0x6c1e40: ret
    //     0x6c1e40: ret             
    // 0x6c1e44: r16 = SliverGridDelegateWithFixedCrossAxisCount
    //     0x6c1e44: add             x16, PP, #0x40, lsl #12  ; [pp+0x40e28] Type: SliverGridDelegateWithFixedCrossAxisCount
    //     0x6c1e48: ldr             x16, [x16, #0xe28]
    // 0x6c1e4c: r30 = SliverGridDelegateWithFixedCrossAxisCount
    //     0x6c1e4c: add             lr, PP, #0x40, lsl #12  ; [pp+0x40e28] Type: SliverGridDelegateWithFixedCrossAxisCount
    //     0x6c1e50: ldr             lr, [lr, #0xe28]
    // 0x6c1e54: stp             lr, x16, [SP, #-0x10]!
    // 0x6c1e58: r0 = ==()
    //     0x6c1e58: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x6c1e5c: add             SP, SP, #0x10
    // 0x6c1e60: tbz             w0, #4, #0x6c1e70
    // 0x6c1e64: ldr             x0, [fp, #0x18]
    // 0x6c1e68: ldr             x1, [fp, #0x10]
    // 0x6c1e6c: b               #0x6c1ec8
    // 0x6c1e70: ldr             x0, [fp, #0x18]
    // 0x6c1e74: ldr             x1, [fp, #0x10]
    // 0x6c1e78: LoadField: r2 = r0->field_6b
    //     0x6c1e78: ldur            w2, [x0, #0x6b]
    // 0x6c1e7c: DecompressPointer r2
    //     0x6c1e7c: add             x2, x2, HEAP, lsl #32
    // 0x6c1e80: LoadField: r3 = r2->field_7
    //     0x6c1e80: ldur            x3, [x2, #7]
    // 0x6c1e84: LoadField: r4 = r1->field_7
    //     0x6c1e84: ldur            x4, [x1, #7]
    // 0x6c1e88: lsl             x5, x3, #1
    // 0x6c1e8c: lsl             x3, x4, #1
    // 0x6c1e90: cmp             w5, w3
    // 0x6c1e94: b.ne            #0x6c1ec8
    // 0x6c1e98: LoadField: d0 = r2->field_f
    //     0x6c1e98: ldur            d0, [x2, #0xf]
    // 0x6c1e9c: LoadField: d1 = r1->field_f
    //     0x6c1e9c: ldur            d1, [x1, #0xf]
    // 0x6c1ea0: fcmp            d0, d1
    // 0x6c1ea4: b.ne            #0x6c1ec8
    // 0x6c1ea8: LoadField: d0 = r2->field_17
    //     0x6c1ea8: ldur            d0, [x2, #0x17]
    // 0x6c1eac: LoadField: d1 = r1->field_17
    //     0x6c1eac: ldur            d1, [x1, #0x17]
    // 0x6c1eb0: fcmp            d0, d1
    // 0x6c1eb4: b.ne            #0x6c1ec8
    // 0x6c1eb8: LoadField: d0 = r2->field_1f
    //     0x6c1eb8: ldur            d0, [x2, #0x1f]
    // 0x6c1ebc: LoadField: d1 = r1->field_1f
    //     0x6c1ebc: ldur            d1, [x1, #0x1f]
    // 0x6c1ec0: fcmp            d0, d1
    // 0x6c1ec4: b.eq            #0x6c1ed4
    // 0x6c1ec8: SaveReg r0
    //     0x6c1ec8: str             x0, [SP, #-8]!
    // 0x6c1ecc: r0 = markNeedsLayout()
    //     0x6c1ecc: bl              #0x6c0ee8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsLayout
    // 0x6c1ed0: add             SP, SP, #8
    // 0x6c1ed4: ldr             x1, [fp, #0x18]
    // 0x6c1ed8: ldr             x0, [fp, #0x10]
    // 0x6c1edc: StoreField: r1->field_6b = r0
    //     0x6c1edc: stur            w0, [x1, #0x6b]
    //     0x6c1ee0: ldurb           w16, [x1, #-1]
    //     0x6c1ee4: ldurb           w17, [x0, #-1]
    //     0x6c1ee8: and             x16, x17, x16, lsr #2
    //     0x6c1eec: tst             x16, HEAP, lsr #32
    //     0x6c1ef0: b.eq            #0x6c1ef8
    //     0x6c1ef4: bl              #0xd6826c
    // 0x6c1ef8: r0 = Null
    //     0x6c1ef8: mov             x0, NULL
    // 0x6c1efc: LeaveFrame
    //     0x6c1efc: mov             SP, fp
    //     0x6c1f00: ldp             fp, lr, [SP], #0x10
    // 0x6c1f04: ret
    //     0x6c1f04: ret             
    // 0x6c1f08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c1f08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c1f0c: b               #0x6c1e1c
  }
  _ RenderSliverGrid(/* No info */) {
    // ** addr: 0x6e9b9c, size: 0x60
    // 0x6e9b9c: EnterFrame
    //     0x6e9b9c: stp             fp, lr, [SP, #-0x10]!
    //     0x6e9ba0: mov             fp, SP
    // 0x6e9ba4: CheckStackOverflow
    //     0x6e9ba4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e9ba8: cmp             SP, x16
    //     0x6e9bac: b.ls            #0x6e9bf4
    // 0x6e9bb0: ldr             x0, [fp, #0x10]
    // 0x6e9bb4: ldr             x1, [fp, #0x20]
    // 0x6e9bb8: StoreField: r1->field_6b = r0
    //     0x6e9bb8: stur            w0, [x1, #0x6b]
    //     0x6e9bbc: ldurb           w16, [x1, #-1]
    //     0x6e9bc0: ldurb           w17, [x0, #-1]
    //     0x6e9bc4: and             x16, x17, x16, lsr #2
    //     0x6e9bc8: tst             x16, HEAP, lsr #32
    //     0x6e9bcc: b.eq            #0x6e9bd4
    //     0x6e9bd0: bl              #0xd6826c
    // 0x6e9bd4: ldr             x16, [fp, #0x18]
    // 0x6e9bd8: stp             x16, x1, [SP, #-0x10]!
    // 0x6e9bdc: r0 = RenderSliverMultiBoxAdaptor()
    //     0x6e9bdc: bl              #0x6e9998  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::RenderSliverMultiBoxAdaptor
    // 0x6e9be0: add             SP, SP, #0x10
    // 0x6e9be4: r0 = Null
    //     0x6e9be4: mov             x0, NULL
    // 0x6e9be8: LeaveFrame
    //     0x6e9be8: mov             SP, fp
    //     0x6e9bec: ldp             fp, lr, [SP], #0x10
    // 0x6e9bf0: ret
    //     0x6e9bf0: ret             
    // 0x6e9bf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e9bf4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e9bf8: b               #0x6e9bb0
  }
  _ childCrossAxisPosition(/* No info */) {
    // ** addr: 0xb135bc, size: 0x7c
    // 0xb135bc: EnterFrame
    //     0xb135bc: stp             fp, lr, [SP, #-0x10]!
    //     0xb135c0: mov             fp, SP
    // 0xb135c4: AllocStack(0x8)
    //     0xb135c4: sub             SP, SP, #8
    // 0xb135c8: ldr             x0, [fp, #0x10]
    // 0xb135cc: LoadField: r3 = r0->field_17
    //     0xb135cc: ldur            w3, [x0, #0x17]
    // 0xb135d0: DecompressPointer r3
    //     0xb135d0: add             x3, x3, HEAP, lsl #32
    // 0xb135d4: stur            x3, [fp, #-8]
    // 0xb135d8: cmp             w3, NULL
    // 0xb135dc: b.eq            #0xb13630
    // 0xb135e0: mov             x0, x3
    // 0xb135e4: r2 = Null
    //     0xb135e4: mov             x2, NULL
    // 0xb135e8: r1 = Null
    //     0xb135e8: mov             x1, NULL
    // 0xb135ec: r4 = LoadClassIdInstr(r0)
    //     0xb135ec: ldur            x4, [x0, #-1]
    //     0xb135f0: ubfx            x4, x4, #0xc, #0x14
    // 0xb135f4: cmp             x4, #0x7fb
    // 0xb135f8: b.eq            #0xb13610
    // 0xb135fc: r8 = SliverGridParentData
    //     0xb135fc: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4b128] Type: SliverGridParentData
    //     0xb13600: ldr             x8, [x8, #0x128]
    // 0xb13604: r3 = Null
    //     0xb13604: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fc20] Null
    //     0xb13608: ldr             x3, [x3, #0xc20]
    // 0xb1360c: r0 = DefaultTypeTest()
    //     0xb1360c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xb13610: ldur            x1, [fp, #-8]
    // 0xb13614: LoadField: r0 = r1->field_1f
    //     0xb13614: ldur            w0, [x1, #0x1f]
    // 0xb13618: DecompressPointer r0
    //     0xb13618: add             x0, x0, HEAP, lsl #32
    // 0xb1361c: cmp             w0, NULL
    // 0xb13620: b.eq            #0xb13634
    // 0xb13624: LeaveFrame
    //     0xb13624: mov             SP, fp
    //     0xb13628: ldp             fp, lr, [SP], #0x10
    // 0xb1362c: ret
    //     0xb1362c: ret             
    // 0xb13630: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb13630: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb13634: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb13634: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

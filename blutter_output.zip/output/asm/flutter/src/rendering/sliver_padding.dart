// lib: , url: package:flutter/src/rendering/sliver_padding.dart

// class id: 1049426, size: 0x8
class :: {
}

// class id: 2576, size: 0x58, field offset: 0x58
abstract class RenderSliverEdgeInsetsPadding extends _RenderSliverOverlapAbsorber&RenderSliver&RenderObjectWithChildMixin {

  _ paint(/* No info */) {
    // ** addr: 0x6545dc, size: 0xe8
    // 0x6545dc: EnterFrame
    //     0x6545dc: stp             fp, lr, [SP, #-0x10]!
    //     0x6545e0: mov             fp, SP
    // 0x6545e4: AllocStack(0x10)
    //     0x6545e4: sub             SP, SP, #0x10
    // 0x6545e8: CheckStackOverflow
    //     0x6545e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6545ec: cmp             SP, x16
    //     0x6545f0: b.ls            #0x6546b4
    // 0x6545f4: ldr             x0, [fp, #0x20]
    // 0x6545f8: LoadField: r3 = r0->field_53
    //     0x6545f8: ldur            w3, [x0, #0x53]
    // 0x6545fc: DecompressPointer r3
    //     0x6545fc: add             x3, x3, HEAP, lsl #32
    // 0x654600: stur            x3, [fp, #-0x10]
    // 0x654604: cmp             w3, NULL
    // 0x654608: b.eq            #0x6546a4
    // 0x65460c: LoadField: r0 = r3->field_4f
    //     0x65460c: ldur            w0, [x3, #0x4f]
    // 0x654610: DecompressPointer r0
    //     0x654610: add             x0, x0, HEAP, lsl #32
    // 0x654614: cmp             w0, NULL
    // 0x654618: b.eq            #0x6546bc
    // 0x65461c: LoadField: r1 = r0->field_3f
    //     0x65461c: ldur            w1, [x0, #0x3f]
    // 0x654620: DecompressPointer r1
    //     0x654620: add             x1, x1, HEAP, lsl #32
    // 0x654624: tbnz            w1, #4, #0x6546a4
    // 0x654628: LoadField: r4 = r3->field_17
    //     0x654628: ldur            w4, [x3, #0x17]
    // 0x65462c: DecompressPointer r4
    //     0x65462c: add             x4, x4, HEAP, lsl #32
    // 0x654630: stur            x4, [fp, #-8]
    // 0x654634: cmp             w4, NULL
    // 0x654638: b.eq            #0x6546c0
    // 0x65463c: mov             x0, x4
    // 0x654640: r2 = Null
    //     0x654640: mov             x2, NULL
    // 0x654644: r1 = Null
    //     0x654644: mov             x1, NULL
    // 0x654648: r4 = LoadClassIdInstr(r0)
    //     0x654648: ldur            x4, [x0, #-1]
    //     0x65464c: ubfx            x4, x4, #0xc, #0x14
    // 0x654650: sub             x4, x4, #0x7f3
    // 0x654654: cmp             x4, #2
    // 0x654658: b.ls            #0x654670
    // 0x65465c: r8 = SliverPhysicalParentData
    //     0x65465c: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5e0] Type: SliverPhysicalParentData
    //     0x654660: ldr             x8, [x8, #0x5e0]
    // 0x654664: r3 = Null
    //     0x654664: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c188] Null
    //     0x654668: ldr             x3, [x3, #0x188]
    // 0x65466c: r0 = DefaultTypeTest()
    //     0x65466c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x654670: ldur            x0, [fp, #-8]
    // 0x654674: LoadField: r1 = r0->field_7
    //     0x654674: ldur            w1, [x0, #7]
    // 0x654678: DecompressPointer r1
    //     0x654678: add             x1, x1, HEAP, lsl #32
    // 0x65467c: ldr             x16, [fp, #0x10]
    // 0x654680: stp             x1, x16, [SP, #-0x10]!
    // 0x654684: r0 = +()
    //     0x654684: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x654688: add             SP, SP, #0x10
    // 0x65468c: ldr             x16, [fp, #0x18]
    // 0x654690: ldur            lr, [fp, #-0x10]
    // 0x654694: stp             lr, x16, [SP, #-0x10]!
    // 0x654698: SaveReg r0
    //     0x654698: str             x0, [SP, #-8]!
    // 0x65469c: r0 = paintChild()
    //     0x65469c: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x6546a0: add             SP, SP, #0x18
    // 0x6546a4: r0 = Null
    //     0x6546a4: mov             x0, NULL
    // 0x6546a8: LeaveFrame
    //     0x6546a8: mov             SP, fp
    //     0x6546ac: ldp             fp, lr, [SP], #0x10
    // 0x6546b0: ret
    //     0x6546b0: ret             
    // 0x6546b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6546b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6546b8: b               #0x6545f4
    // 0x6546bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6546bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6546c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6546c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x682c74, size: 0x16a8
    // 0x682c74: EnterFrame
    //     0x682c74: stp             fp, lr, [SP, #-0x10]!
    //     0x682c78: mov             fp, SP
    // 0x682c7c: AllocStack(0x88)
    //     0x682c7c: sub             SP, SP, #0x88
    // 0x682c80: CheckStackOverflow
    //     0x682c80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x682c84: cmp             SP, x16
    //     0x682c88: b.ls            #0x683fa8
    // 0x682c8c: ldr             x3, [fp, #0x10]
    // 0x682c90: LoadField: r4 = r3->field_27
    //     0x682c90: ldur            w4, [x3, #0x27]
    // 0x682c94: DecompressPointer r4
    //     0x682c94: add             x4, x4, HEAP, lsl #32
    // 0x682c98: stur            x4, [fp, #-8]
    // 0x682c9c: cmp             w4, NULL
    // 0x682ca0: b.eq            #0x683f88
    // 0x682ca4: mov             x0, x4
    // 0x682ca8: r2 = Null
    //     0x682ca8: mov             x2, NULL
    // 0x682cac: r1 = Null
    //     0x682cac: mov             x1, NULL
    // 0x682cb0: r4 = LoadClassIdInstr(r0)
    //     0x682cb0: ldur            x4, [x0, #-1]
    //     0x682cb4: ubfx            x4, x4, #0xc, #0x14
    // 0x682cb8: cmp             x4, #0x80c
    // 0x682cbc: b.eq            #0x682cd4
    // 0x682cc0: r8 = SliverConstraints
    //     0x682cc0: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x682cc4: ldr             x8, [x8, #0x5a8]
    // 0x682cc8: r3 = Null
    //     0x682cc8: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c1a8] Null
    //     0x682ccc: ldr             x3, [x3, #0x1a8]
    // 0x682cd0: r0 = DefaultTypeTest()
    //     0x682cd0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x682cd4: ldr             x16, [fp, #0x10]
    // 0x682cd8: SaveReg r16
    //     0x682cd8: str             x16, [SP, #-8]!
    // 0x682cdc: r0 = beforePadding()
    //     0x682cdc: bl              #0x684dd0  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverEdgeInsetsPadding::beforePadding
    // 0x682ce0: add             SP, SP, #8
    // 0x682ce4: stur            x0, [fp, #-0x10]
    // 0x682ce8: ldr             x16, [fp, #0x10]
    // 0x682cec: SaveReg r16
    //     0x682cec: str             x16, [SP, #-8]!
    // 0x682cf0: r0 = afterPadding()
    //     0x682cf0: bl              #0x684a90  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverEdgeInsetsPadding::afterPadding
    // 0x682cf4: add             SP, SP, #8
    // 0x682cf8: ldr             x16, [fp, #0x10]
    // 0x682cfc: SaveReg r16
    //     0x682cfc: str             x16, [SP, #-8]!
    // 0x682d00: r0 = mainAxisPadding()
    //     0x682d00: bl              #0x684898  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverEdgeInsetsPadding::mainAxisPadding
    // 0x682d04: add             SP, SP, #8
    // 0x682d08: stur            x0, [fp, #-0x18]
    // 0x682d0c: ldr             x16, [fp, #0x10]
    // 0x682d10: SaveReg r16
    //     0x682d10: str             x16, [SP, #-8]!
    // 0x682d14: r0 = crossAxisPadding()
    //     0x682d14: bl              #0x684690  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverEdgeInsetsPadding::crossAxisPadding
    // 0x682d18: add             SP, SP, #8
    // 0x682d1c: mov             x1, x0
    // 0x682d20: ldr             x0, [fp, #0x10]
    // 0x682d24: stur            x1, [fp, #-0x20]
    // 0x682d28: LoadField: r2 = r0->field_53
    //     0x682d28: ldur            w2, [x0, #0x53]
    // 0x682d2c: DecompressPointer r2
    //     0x682d2c: add             x2, x2, HEAP, lsl #32
    // 0x682d30: cmp             w2, NULL
    // 0x682d34: b.ne            #0x682ed8
    // 0x682d38: ldur            x1, [fp, #-8]
    // 0x682d3c: stp             x1, x0, [SP, #-0x10]!
    // 0x682d40: ldur            x16, [fp, #-0x18]
    // 0x682d44: stp             x16, xzr, [SP, #-0x10]!
    // 0x682d48: r0 = calculatePaintOffset()
    //     0x682d48: bl              #0x677ba0  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0x682d4c: add             SP, SP, #0x20
    // 0x682d50: stur            d0, [fp, #-0x30]
    // 0x682d54: ldr             x16, [fp, #0x10]
    // 0x682d58: ldur            lr, [fp, #-8]
    // 0x682d5c: stp             lr, x16, [SP, #-0x10]!
    // 0x682d60: ldur            x16, [fp, #-0x18]
    // 0x682d64: stp             x16, xzr, [SP, #-0x10]!
    // 0x682d68: r0 = calculateCacheOffset()
    //     0x682d68: bl              #0x677aa4  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculateCacheOffset
    // 0x682d6c: add             SP, SP, #0x20
    // 0x682d70: ldur            x0, [fp, #-8]
    // 0x682d74: stur            d0, [fp, #-0x40]
    // 0x682d78: LoadField: d1 = r0->field_2b
    //     0x682d78: ldur            d1, [x0, #0x2b]
    // 0x682d7c: ldur            d2, [fp, #-0x30]
    // 0x682d80: stur            d1, [fp, #-0x38]
    // 0x682d84: fcmp            d2, d1
    // 0x682d88: b.vs            #0x682d90
    // 0x682d8c: b.gt            #0x682e3c
    // 0x682d90: fcmp            d2, d1
    // 0x682d94: b.vs            #0x682da4
    // 0x682d98: b.ge            #0x682da4
    // 0x682d9c: mov             v1.16b, v2.16b
    // 0x682da0: b               #0x682e3c
    // 0x682da4: d3 = 0.000000
    //     0x682da4: eor             v3.16b, v3.16b, v3.16b
    // 0x682da8: fcmp            d2, d3
    // 0x682dac: b.vs            #0x682db4
    // 0x682db0: b.eq            #0x682dbc
    // 0x682db4: r0 = false
    //     0x682db4: add             x0, NULL, #0x30  ; false
    // 0x682db8: b               #0x682dc0
    // 0x682dbc: r0 = true
    //     0x682dbc: add             x0, NULL, #0x20  ; true
    // 0x682dc0: tbnz            w0, #4, #0x682dd8
    // 0x682dc4: fadd            d4, d2, d1
    // 0x682dc8: fmul            d5, d4, d2
    // 0x682dcc: fmul            d2, d5, d1
    // 0x682dd0: mov             v1.16b, v2.16b
    // 0x682dd4: b               #0x682e3c
    // 0x682dd8: tbnz            w0, #4, #0x682e1c
    // 0x682ddc: r0 = inline_Allocate_Double()
    //     0x682ddc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x682de0: add             x0, x0, #0x10
    //     0x682de4: cmp             x1, x0
    //     0x682de8: b.ls            #0x683fb0
    //     0x682dec: str             x0, [THR, #0x60]  ; THR::top
    //     0x682df0: sub             x0, x0, #0xf
    //     0x682df4: mov             x1, #0xd108
    //     0x682df8: movk            x1, #3, lsl #16
    //     0x682dfc: stur            x1, [x0, #-1]
    // 0x682e00: StoreField: r0->field_7 = d1
    //     0x682e00: stur            d1, [x0, #7]
    // 0x682e04: SaveReg r0
    //     0x682e04: str             x0, [SP, #-8]!
    // 0x682e08: r0 = isNegative()
    //     0x682e08: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x682e0c: add             SP, SP, #8
    // 0x682e10: tbnz            w0, #4, #0x682e1c
    // 0x682e14: ldur            d0, [fp, #-0x38]
    // 0x682e18: b               #0x682e28
    // 0x682e1c: ldur            d0, [fp, #-0x38]
    // 0x682e20: fcmp            d0, d0
    // 0x682e24: b.vc            #0x682e34
    // 0x682e28: mov             v1.16b, v0.16b
    // 0x682e2c: ldur            d0, [fp, #-0x40]
    // 0x682e30: b               #0x682e3c
    // 0x682e34: ldur            d1, [fp, #-0x30]
    // 0x682e38: ldur            d0, [fp, #-0x40]
    // 0x682e3c: ldr             x0, [fp, #0x10]
    // 0x682e40: ldur            x2, [fp, #-0x18]
    // 0x682e44: stur            d1, [fp, #-0x38]
    // 0x682e48: LoadField: d2 = r2->field_7
    //     0x682e48: ldur            d2, [x2, #7]
    // 0x682e4c: stur            d2, [fp, #-0x30]
    // 0x682e50: r0 = SliverGeometry()
    //     0x682e50: bl              #0x679334  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x54)
    // 0x682e54: ldur            d0, [fp, #-0x30]
    // 0x682e58: StoreField: r0->field_7 = d0
    //     0x682e58: stur            d0, [x0, #7]
    // 0x682e5c: ldur            d1, [fp, #-0x38]
    // 0x682e60: StoreField: r0->field_17 = d1
    //     0x682e60: stur            d1, [x0, #0x17]
    // 0x682e64: d2 = 0.000000
    //     0x682e64: eor             v2.16b, v2.16b, v2.16b
    // 0x682e68: StoreField: r0->field_f = d2
    //     0x682e68: stur            d2, [x0, #0xf]
    // 0x682e6c: StoreField: r0->field_27 = d0
    //     0x682e6c: stur            d0, [x0, #0x27]
    // 0x682e70: StoreField: r0->field_2f = d2
    //     0x682e70: stur            d2, [x0, #0x2f]
    // 0x682e74: r3 = false
    //     0x682e74: add             x3, NULL, #0x30  ; false
    // 0x682e78: StoreField: r0->field_43 = r3
    //     0x682e78: stur            w3, [x0, #0x43]
    // 0x682e7c: StoreField: r0->field_1f = d1
    //     0x682e7c: stur            d1, [x0, #0x1f]
    // 0x682e80: StoreField: r0->field_37 = d1
    //     0x682e80: stur            d1, [x0, #0x37]
    // 0x682e84: ldur            d0, [fp, #-0x40]
    // 0x682e88: StoreField: r0->field_4b = d0
    //     0x682e88: stur            d0, [x0, #0x4b]
    // 0x682e8c: fcmp            d1, d2
    // 0x682e90: b.vs            #0x682e98
    // 0x682e94: b.gt            #0x682ea0
    // 0x682e98: r1 = false
    //     0x682e98: add             x1, NULL, #0x30  ; false
    // 0x682e9c: b               #0x682ea4
    // 0x682ea0: r1 = true
    //     0x682ea0: add             x1, NULL, #0x20  ; true
    // 0x682ea4: StoreField: r0->field_3f = r1
    //     0x682ea4: stur            w1, [x0, #0x3f]
    // 0x682ea8: ldr             x4, [fp, #0x10]
    // 0x682eac: StoreField: r4->field_4f = r0
    //     0x682eac: stur            w0, [x4, #0x4f]
    //     0x682eb0: ldurb           w16, [x4, #-1]
    //     0x682eb4: ldurb           w17, [x0, #-1]
    //     0x682eb8: and             x16, x17, x16, lsr #2
    //     0x682ebc: tst             x16, HEAP, lsr #32
    //     0x682ec0: b.eq            #0x682ec8
    //     0x682ec4: bl              #0xd682cc
    // 0x682ec8: r0 = Null
    //     0x682ec8: mov             x0, NULL
    // 0x682ecc: LeaveFrame
    //     0x682ecc: mov             SP, fp
    //     0x682ed0: ldp             fp, lr, [SP], #0x10
    // 0x682ed4: ret
    //     0x682ed4: ret             
    // 0x682ed8: mov             x4, x0
    // 0x682edc: ldur            x2, [fp, #-0x18]
    // 0x682ee0: ldur            x0, [fp, #-8]
    // 0x682ee4: r3 = false
    //     0x682ee4: add             x3, NULL, #0x30  ; false
    // 0x682ee8: d2 = 0.000000
    //     0x682ee8: eor             v2.16b, v2.16b, v2.16b
    // 0x682eec: stp             x0, x4, [SP, #-0x10]!
    // 0x682ef0: ldur            x16, [fp, #-0x10]
    // 0x682ef4: stp             x16, xzr, [SP, #-0x10]!
    // 0x682ef8: r0 = calculatePaintOffset()
    //     0x682ef8: bl              #0x677ba0  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0x682efc: add             SP, SP, #0x20
    // 0x682f00: ldur            x0, [fp, #-8]
    // 0x682f04: stur            d0, [fp, #-0x50]
    // 0x682f08: LoadField: d1 = r0->field_23
    //     0x682f08: ldur            d1, [x0, #0x23]
    // 0x682f0c: d2 = 0.000000
    //     0x682f0c: eor             v2.16b, v2.16b, v2.16b
    // 0x682f10: fcmp            d1, d2
    // 0x682f14: b.vs            #0x682f70
    // 0x682f18: b.le            #0x682f70
    // 0x682f1c: fsub            d3, d1, d0
    // 0x682f20: fcmp            d2, d3
    // 0x682f24: b.vs            #0x682f34
    // 0x682f28: b.le            #0x682f34
    // 0x682f2c: d1 = 0.000000
    //     0x682f2c: eor             v1.16b, v1.16b, v1.16b
    // 0x682f30: b               #0x682f70
    // 0x682f34: fcmp            d2, d3
    // 0x682f38: b.vs            #0x682f48
    // 0x682f3c: b.ge            #0x682f48
    // 0x682f40: mov             v1.16b, v3.16b
    // 0x682f44: b               #0x682f70
    // 0x682f48: fcmp            d2, d2
    // 0x682f4c: b.vs            #0x682f5c
    // 0x682f50: b.ne            #0x682f5c
    // 0x682f54: fadd            d1, d2, d3
    // 0x682f58: b               #0x682f70
    // 0x682f5c: fcmp            d3, d3
    // 0x682f60: b.vc            #0x682f6c
    // 0x682f64: mov             v1.16b, v3.16b
    // 0x682f68: b               #0x682f70
    // 0x682f6c: d1 = 0.000000
    //     0x682f6c: eor             v1.16b, v1.16b, v1.16b
    // 0x682f70: ldr             x1, [fp, #0x10]
    // 0x682f74: ldur            x2, [fp, #-0x10]
    // 0x682f78: stur            d1, [fp, #-0x48]
    // 0x682f7c: LoadField: r3 = r1->field_53
    //     0x682f7c: ldur            w3, [x1, #0x53]
    // 0x682f80: DecompressPointer r3
    //     0x682f80: add             x3, x3, HEAP, lsl #32
    // 0x682f84: stur            x3, [fp, #-0x28]
    // 0x682f88: cmp             w3, NULL
    // 0x682f8c: b.eq            #0x683fc8
    // 0x682f90: LoadField: d3 = r0->field_13
    //     0x682f90: ldur            d3, [x0, #0x13]
    // 0x682f94: cmp             w2, NULL
    // 0x682f98: b.eq            #0x683fcc
    // 0x682f9c: LoadField: d4 = r2->field_7
    //     0x682f9c: ldur            d4, [x2, #7]
    // 0x682fa0: stur            d4, [fp, #-0x40]
    // 0x682fa4: fsub            d5, d3, d4
    // 0x682fa8: fcmp            d2, d5
    // 0x682fac: b.vs            #0x682fbc
    // 0x682fb0: b.le            #0x682fbc
    // 0x682fb4: d3 = 0.000000
    //     0x682fb4: eor             v3.16b, v3.16b, v3.16b
    // 0x682fb8: b               #0x682ff8
    // 0x682fbc: fcmp            d2, d5
    // 0x682fc0: b.vs            #0x682fd0
    // 0x682fc4: b.ge            #0x682fd0
    // 0x682fc8: mov             v3.16b, v5.16b
    // 0x682fcc: b               #0x682ff8
    // 0x682fd0: fcmp            d2, d2
    // 0x682fd4: b.vs            #0x682fe4
    // 0x682fd8: b.ne            #0x682fe4
    // 0x682fdc: fadd            d3, d2, d5
    // 0x682fe0: b               #0x682ff8
    // 0x682fe4: fcmp            d5, d5
    // 0x682fe8: b.vc            #0x682ff4
    // 0x682fec: mov             v3.16b, v5.16b
    // 0x682ff0: b               #0x682ff8
    // 0x682ff4: d3 = 0.000000
    //     0x682ff4: eor             v3.16b, v3.16b, v3.16b
    // 0x682ff8: stur            d3, [fp, #-0x38]
    // 0x682ffc: LoadField: d5 = r0->field_47
    //     0x682ffc: ldur            d5, [x0, #0x47]
    // 0x683000: fadd            d6, d5, d4
    // 0x683004: stur            d6, [fp, #-0x30]
    // 0x683008: fcmp            d2, d6
    // 0x68300c: b.vs            #0x68301c
    // 0x683010: b.le            #0x68301c
    // 0x683014: mov             v0.16b, v6.16b
    // 0x683018: b               #0x6830c0
    // 0x68301c: fcmp            d2, d6
    // 0x683020: b.vs            #0x683030
    // 0x683024: b.ge            #0x683030
    // 0x683028: d0 = 0.000000
    //     0x683028: eor             v0.16b, v0.16b, v0.16b
    // 0x68302c: b               #0x6830c0
    // 0x683030: fcmp            d2, d2
    // 0x683034: b.vs            #0x68303c
    // 0x683038: b.eq            #0x683044
    // 0x68303c: r4 = false
    //     0x68303c: add             x4, NULL, #0x30  ; false
    // 0x683040: b               #0x683048
    // 0x683044: r4 = true
    //     0x683044: add             x4, NULL, #0x20  ; true
    // 0x683048: tbnz            w4, #4, #0x683060
    // 0x68304c: fadd            d5, d2, d6
    // 0x683050: fmul            d7, d5, d2
    // 0x683054: fmul            d5, d7, d6
    // 0x683058: mov             v0.16b, v5.16b
    // 0x68305c: b               #0x6830c0
    // 0x683060: tbnz            w4, #4, #0x6830a4
    // 0x683064: r4 = inline_Allocate_Double()
    //     0x683064: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x683068: add             x4, x4, #0x10
    //     0x68306c: cmp             x5, x4
    //     0x683070: b.ls            #0x683fd0
    //     0x683074: str             x4, [THR, #0x60]  ; THR::top
    //     0x683078: sub             x4, x4, #0xf
    //     0x68307c: mov             x5, #0xd108
    //     0x683080: movk            x5, #3, lsl #16
    //     0x683084: stur            x5, [x4, #-1]
    // 0x683088: StoreField: r4->field_7 = d6
    //     0x683088: stur            d6, [x4, #7]
    // 0x68308c: SaveReg r4
    //     0x68308c: str             x4, [SP, #-8]!
    // 0x683090: r0 = isNegative()
    //     0x683090: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x683094: add             SP, SP, #8
    // 0x683098: tbnz            w0, #4, #0x6830a4
    // 0x68309c: ldur            d0, [fp, #-0x30]
    // 0x6830a0: b               #0x6830b0
    // 0x6830a4: ldur            d0, [fp, #-0x30]
    // 0x6830a8: fcmp            d0, d0
    // 0x6830ac: b.vc            #0x6830b8
    // 0x6830b0: ldur            x0, [fp, #-8]
    // 0x6830b4: b               #0x6830c0
    // 0x6830b8: ldur            x0, [fp, #-8]
    // 0x6830bc: d0 = 0.000000
    //     0x6830bc: eor             v0.16b, v0.16b, v0.16b
    // 0x6830c0: ldur            x1, [fp, #-0x20]
    // 0x6830c4: stur            d0, [fp, #-0x58]
    // 0x6830c8: LoadField: d1 = r0->field_2b
    //     0x6830c8: ldur            d1, [x0, #0x2b]
    // 0x6830cc: stur            d1, [fp, #-0x30]
    // 0x6830d0: ldr             x16, [fp, #0x10]
    // 0x6830d4: stp             x0, x16, [SP, #-0x10]!
    // 0x6830d8: ldur            x16, [fp, #-0x10]
    // 0x6830dc: stp             x16, xzr, [SP, #-0x10]!
    // 0x6830e0: r0 = calculatePaintOffset()
    //     0x6830e0: bl              #0x677ba0  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0x6830e4: add             SP, SP, #0x20
    // 0x6830e8: mov             v1.16b, v0.16b
    // 0x6830ec: ldur            d0, [fp, #-0x30]
    // 0x6830f0: fsub            d2, d0, d1
    // 0x6830f4: ldur            x0, [fp, #-8]
    // 0x6830f8: stur            d2, [fp, #-0x68]
    // 0x6830fc: LoadField: d1 = r0->field_4f
    //     0x6830fc: ldur            d1, [x0, #0x4f]
    // 0x683100: stur            d1, [fp, #-0x60]
    // 0x683104: ldr             x16, [fp, #0x10]
    // 0x683108: stp             x0, x16, [SP, #-0x10]!
    // 0x68310c: ldur            x16, [fp, #-0x10]
    // 0x683110: stp             x16, xzr, [SP, #-0x10]!
    // 0x683114: r0 = calculateCacheOffset()
    //     0x683114: bl              #0x677aa4  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculateCacheOffset
    // 0x683118: add             SP, SP, #0x20
    // 0x68311c: mov             v1.16b, v0.16b
    // 0x683120: ldur            d0, [fp, #-0x60]
    // 0x683124: fsub            d2, d0, d1
    // 0x683128: ldur            x0, [fp, #-8]
    // 0x68312c: LoadField: d1 = r0->field_33
    //     0x68312c: ldur            d1, [x0, #0x33]
    // 0x683130: ldur            x1, [fp, #-0x20]
    // 0x683134: cmp             w1, NULL
    // 0x683138: b.eq            #0x684004
    // 0x68313c: LoadField: d3 = r1->field_7
    //     0x68313c: ldur            d3, [x1, #7]
    // 0x683140: fsub            d4, d1, d3
    // 0x683144: d1 = 0.000000
    //     0x683144: eor             v1.16b, v1.16b, v1.16b
    // 0x683148: fcmp            d1, d4
    // 0x68314c: b.vs            #0x68315c
    // 0x683150: b.le            #0x68315c
    // 0x683154: d8 = 0.000000
    //     0x683154: eor             v8.16b, v8.16b, v8.16b
    // 0x683158: b               #0x68319c
    // 0x68315c: fcmp            d1, d4
    // 0x683160: b.vs            #0x683170
    // 0x683164: b.ge            #0x683170
    // 0x683168: mov             v8.16b, v4.16b
    // 0x68316c: b               #0x68319c
    // 0x683170: fcmp            d1, d1
    // 0x683174: b.vs            #0x683188
    // 0x683178: b.ne            #0x683188
    // 0x68317c: fadd            d3, d1, d4
    // 0x683180: mov             v8.16b, v3.16b
    // 0x683184: b               #0x68319c
    // 0x683188: fcmp            d4, d4
    // 0x68318c: b.vc            #0x683198
    // 0x683190: mov             v8.16b, v4.16b
    // 0x683194: b               #0x68319c
    // 0x683198: d8 = 0.000000
    //     0x683198: eor             v8.16b, v8.16b, v8.16b
    // 0x68319c: ldr             x1, [fp, #0x10]
    // 0x6831a0: ldur            d5, [fp, #-0x48]
    // 0x6831a4: ldur            d3, [fp, #-0x68]
    // 0x6831a8: ldur            x2, [fp, #-0x28]
    // 0x6831ac: ldur            d7, [fp, #-0x38]
    // 0x6831b0: ldur            d4, [fp, #-0x58]
    // 0x6831b4: ldur            d6, [fp, #-0x40]
    // 0x6831b8: LoadField: d9 = r0->field_1b
    //     0x6831b8: ldur            d9, [x0, #0x1b]
    // 0x6831bc: fadd            d10, d6, d9
    // 0x6831c0: r3 = inline_Allocate_Double()
    //     0x6831c0: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x6831c4: add             x3, x3, #0x10
    //     0x6831c8: cmp             x4, x3
    //     0x6831cc: b.ls            #0x684008
    //     0x6831d0: str             x3, [THR, #0x60]  ; THR::top
    //     0x6831d4: sub             x3, x3, #0xf
    //     0x6831d8: mov             x4, #0xd108
    //     0x6831dc: movk            x4, #3, lsl #16
    //     0x6831e0: stur            x4, [x3, #-1]
    // 0x6831e4: StoreField: r3->field_7 = d3
    //     0x6831e4: stur            d3, [x3, #7]
    // 0x6831e8: r4 = inline_Allocate_Double()
    //     0x6831e8: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x6831ec: add             x4, x4, #0x10
    //     0x6831f0: cmp             x5, x4
    //     0x6831f4: b.ls            #0x68404c
    //     0x6831f8: str             x4, [THR, #0x60]  ; THR::top
    //     0x6831fc: sub             x4, x4, #0xf
    //     0x683200: mov             x5, #0xd108
    //     0x683204: movk            x5, #3, lsl #16
    //     0x683208: stur            x5, [x4, #-1]
    // 0x68320c: StoreField: r4->field_7 = d2
    //     0x68320c: stur            d2, [x4, #7]
    // 0x683210: r5 = inline_Allocate_Double()
    //     0x683210: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0x683214: add             x5, x5, #0x10
    //     0x683218: cmp             x6, x5
    //     0x68321c: b.ls            #0x684090
    //     0x683220: str             x5, [THR, #0x60]  ; THR::top
    //     0x683224: sub             x5, x5, #0xf
    //     0x683228: mov             x6, #0xd108
    //     0x68322c: movk            x6, #3, lsl #16
    //     0x683230: stur            x6, [x5, #-1]
    // 0x683234: StoreField: r5->field_7 = d10
    //     0x683234: stur            d10, [x5, #7]
    // 0x683238: r6 = inline_Allocate_Double()
    //     0x683238: ldp             x6, x7, [THR, #0x60]  ; THR::top
    //     0x68323c: add             x6, x6, #0x10
    //     0x683240: cmp             x7, x6
    //     0x683244: b.ls            #0x6840d4
    //     0x683248: str             x6, [THR, #0x60]  ; THR::top
    //     0x68324c: sub             x6, x6, #0xf
    //     0x683250: mov             x7, #0xd108
    //     0x683254: movk            x7, #3, lsl #16
    //     0x683258: stur            x7, [x6, #-1]
    // 0x68325c: StoreField: r6->field_7 = d7
    //     0x68325c: stur            d7, [x6, #7]
    // 0x683260: r7 = inline_Allocate_Double()
    //     0x683260: ldp             x7, x8, [THR, #0x60]  ; THR::top
    //     0x683264: add             x7, x7, #0x10
    //     0x683268: cmp             x8, x7
    //     0x68326c: b.ls            #0x684118
    //     0x683270: str             x7, [THR, #0x60]  ; THR::top
    //     0x683274: sub             x7, x7, #0xf
    //     0x683278: mov             x8, #0xd108
    //     0x68327c: movk            x8, #3, lsl #16
    //     0x683280: stur            x8, [x7, #-1]
    // 0x683284: StoreField: r7->field_7 = d4
    //     0x683284: stur            d4, [x7, #7]
    // 0x683288: r8 = inline_Allocate_Double()
    //     0x683288: ldp             x8, x9, [THR, #0x60]  ; THR::top
    //     0x68328c: add             x8, x8, #0x10
    //     0x683290: cmp             x9, x8
    //     0x683294: b.ls            #0x68415c
    //     0x683298: str             x8, [THR, #0x60]  ; THR::top
    //     0x68329c: sub             x8, x8, #0xf
    //     0x6832a0: mov             x9, #0xd108
    //     0x6832a4: movk            x9, #3, lsl #16
    //     0x6832a8: stur            x9, [x8, #-1]
    // 0x6832ac: StoreField: r8->field_7 = d8
    //     0x6832ac: stur            d8, [x8, #7]
    // 0x6832b0: SaveReg r0
    //     0x6832b0: str             x0, [SP, #-8]!
    // 0x6832b4: SaveReg d5
    //     0x6832b4: str             d5, [SP, #-8]!
    // 0x6832b8: stp             x7, x6, [SP, #-0x10]!
    // 0x6832bc: stp             x4, x3, [SP, #-0x10]!
    // 0x6832c0: stp             x5, x8, [SP, #-0x10]!
    // 0x6832c4: r4 = const [0, 0x8, 0x8, 0x2, cacheOrigin, 0x3, crossAxisExtent, 0x6, precedingScrollExtent, 0x7, remainingCacheExtent, 0x5, remainingPaintExtent, 0x4, scrollOffset, 0x2, null]
    //     0x6832c4: add             x4, PP, #0x4c, lsl #12  ; [pp+0x4c1b8] List(17) [0, 0x8, 0x8, 0x2, "cacheOrigin", 0x3, "crossAxisExtent", 0x6, "precedingScrollExtent", 0x7, "remainingCacheExtent", 0x5, "remainingPaintExtent", 0x4, "scrollOffset", 0x2, Null]
    //     0x6832c8: ldr             x4, [x4, #0x1b8]
    // 0x6832cc: r0 = copyWith()
    //     0x6832cc: bl              #0x68431c  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::copyWith
    // 0x6832d0: add             SP, SP, #0x40
    // 0x6832d4: mov             x1, x0
    // 0x6832d8: ldur            x0, [fp, #-0x28]
    // 0x6832dc: r2 = LoadClassIdInstr(r0)
    //     0x6832dc: ldur            x2, [x0, #-1]
    //     0x6832e0: ubfx            x2, x2, #0xc, #0x14
    // 0x6832e4: stp             x1, x0, [SP, #-0x10]!
    // 0x6832e8: r16 = true
    //     0x6832e8: add             x16, NULL, #0x20  ; true
    // 0x6832ec: SaveReg r16
    //     0x6832ec: str             x16, [SP, #-8]!
    // 0x6832f0: mov             x0, x2
    // 0x6832f4: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x6832f4: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x6832f8: ldr             x4, [x4, #0x1c8]
    // 0x6832fc: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x6832fc: mov             x17, #0xcdfb
    //     0x683300: add             lr, x0, x17
    //     0x683304: ldr             lr, [x21, lr, lsl #3]
    //     0x683308: blr             lr
    // 0x68330c: add             SP, SP, #0x18
    // 0x683310: ldr             x0, [fp, #0x10]
    // 0x683314: LoadField: r1 = r0->field_53
    //     0x683314: ldur            w1, [x0, #0x53]
    // 0x683318: DecompressPointer r1
    //     0x683318: add             x1, x1, HEAP, lsl #32
    // 0x68331c: cmp             w1, NULL
    // 0x683320: b.eq            #0x6841a0
    // 0x683324: LoadField: r2 = r1->field_4f
    //     0x683324: ldur            w2, [x1, #0x4f]
    // 0x683328: DecompressPointer r2
    //     0x683328: add             x2, x2, HEAP, lsl #32
    // 0x68332c: stur            x2, [fp, #-0x28]
    // 0x683330: cmp             w2, NULL
    // 0x683334: b.eq            #0x6841a4
    // 0x683338: LoadField: r1 = r2->field_47
    //     0x683338: ldur            w1, [x2, #0x47]
    // 0x68333c: DecompressPointer r1
    //     0x68333c: add             x1, x1, HEAP, lsl #32
    // 0x683340: stur            x1, [fp, #-0x20]
    // 0x683344: cmp             w1, NULL
    // 0x683348: b.eq            #0x6833d0
    // 0x68334c: r0 = SliverGeometry()
    //     0x68334c: bl              #0x679334  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x54)
    // 0x683350: d0 = 0.000000
    //     0x683350: eor             v0.16b, v0.16b, v0.16b
    // 0x683354: StoreField: r0->field_7 = d0
    //     0x683354: stur            d0, [x0, #7]
    // 0x683358: StoreField: r0->field_17 = d0
    //     0x683358: stur            d0, [x0, #0x17]
    // 0x68335c: StoreField: r0->field_f = d0
    //     0x68335c: stur            d0, [x0, #0xf]
    // 0x683360: StoreField: r0->field_27 = d0
    //     0x683360: stur            d0, [x0, #0x27]
    // 0x683364: StoreField: r0->field_2f = d0
    //     0x683364: stur            d0, [x0, #0x2f]
    // 0x683368: r1 = false
    //     0x683368: add             x1, NULL, #0x30  ; false
    // 0x68336c: StoreField: r0->field_43 = r1
    //     0x68336c: stur            w1, [x0, #0x43]
    // 0x683370: ldur            x1, [fp, #-0x20]
    // 0x683374: StoreField: r0->field_47 = r1
    //     0x683374: stur            w1, [x0, #0x47]
    // 0x683378: StoreField: r0->field_1f = d0
    //     0x683378: stur            d0, [x0, #0x1f]
    // 0x68337c: StoreField: r0->field_37 = d0
    //     0x68337c: stur            d0, [x0, #0x37]
    // 0x683380: StoreField: r0->field_4b = d0
    //     0x683380: stur            d0, [x0, #0x4b]
    // 0x683384: fcmp            d0, d0
    // 0x683388: b.vs            #0x683390
    // 0x68338c: b.gt            #0x683398
    // 0x683390: r1 = false
    //     0x683390: add             x1, NULL, #0x30  ; false
    // 0x683394: b               #0x68339c
    // 0x683398: r1 = true
    //     0x683398: add             x1, NULL, #0x20  ; true
    // 0x68339c: StoreField: r0->field_3f = r1
    //     0x68339c: stur            w1, [x0, #0x3f]
    // 0x6833a0: ldr             x1, [fp, #0x10]
    // 0x6833a4: StoreField: r1->field_4f = r0
    //     0x6833a4: stur            w0, [x1, #0x4f]
    //     0x6833a8: ldurb           w16, [x1, #-1]
    //     0x6833ac: ldurb           w17, [x0, #-1]
    //     0x6833b0: and             x16, x17, x16, lsr #2
    //     0x6833b4: tst             x16, HEAP, lsr #32
    //     0x6833b8: b.eq            #0x6833c0
    //     0x6833bc: bl              #0xd6826c
    // 0x6833c0: r0 = Null
    //     0x6833c0: mov             x0, NULL
    // 0x6833c4: LeaveFrame
    //     0x6833c4: mov             SP, fp
    //     0x6833c8: ldp             fp, lr, [SP], #0x10
    // 0x6833cc: ret
    //     0x6833cc: ret             
    // 0x6833d0: mov             x1, x0
    // 0x6833d4: ldur            x0, [fp, #-0x18]
    // 0x6833d8: ldur            d2, [fp, #-0x50]
    // 0x6833dc: ldur            d1, [fp, #-0x40]
    // 0x6833e0: d0 = 0.000000
    //     0x6833e0: eor             v0.16b, v0.16b, v0.16b
    // 0x6833e4: LoadField: d3 = r2->field_7
    //     0x6833e4: ldur            d3, [x2, #7]
    // 0x6833e8: stur            d3, [fp, #-0x58]
    // 0x6833ec: fadd            d4, d1, d3
    // 0x6833f0: stur            d4, [fp, #-0x48]
    // 0x6833f4: cmp             w0, NULL
    // 0x6833f8: b.eq            #0x6841a8
    // 0x6833fc: LoadField: d1 = r0->field_7
    //     0x6833fc: ldur            d1, [x0, #7]
    // 0x683400: stur            d1, [fp, #-0x40]
    // 0x683404: fadd            d5, d1, d3
    // 0x683408: stur            d5, [fp, #-0x38]
    // 0x68340c: r0 = inline_Allocate_Double()
    //     0x68340c: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x683410: add             x0, x0, #0x10
    //     0x683414: cmp             x3, x0
    //     0x683418: b.ls            #0x6841ac
    //     0x68341c: str             x0, [THR, #0x60]  ; THR::top
    //     0x683420: sub             x0, x0, #0xf
    //     0x683424: mov             x3, #0xd108
    //     0x683428: movk            x3, #3, lsl #16
    //     0x68342c: stur            x3, [x0, #-1]
    // 0x683430: StoreField: r0->field_7 = d5
    //     0x683430: stur            d5, [x0, #7]
    // 0x683434: stur            x0, [fp, #-0x18]
    // 0x683438: ldur            x16, [fp, #-8]
    // 0x68343c: stp             x16, x1, [SP, #-0x10]!
    // 0x683440: SaveReg d4
    //     0x683440: str             d4, [SP, #-8]!
    // 0x683444: SaveReg r0
    //     0x683444: str             x0, [SP, #-8]!
    // 0x683448: r0 = calculatePaintOffset()
    //     0x683448: bl              #0x677ba0  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0x68344c: add             SP, SP, #0x20
    // 0x683450: mov             v1.16b, v0.16b
    // 0x683454: ldur            d0, [fp, #-0x50]
    // 0x683458: stur            d1, [fp, #-0x70]
    // 0x68345c: fadd            d2, d0, d1
    // 0x683460: stur            d2, [fp, #-0x68]
    // 0x683464: ldr             x16, [fp, #0x10]
    // 0x683468: ldur            lr, [fp, #-8]
    // 0x68346c: stp             lr, x16, [SP, #-0x10]!
    // 0x683470: ldur            x16, [fp, #-0x10]
    // 0x683474: stp             x16, xzr, [SP, #-0x10]!
    // 0x683478: r0 = calculateCacheOffset()
    //     0x683478: bl              #0x677aa4  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculateCacheOffset
    // 0x68347c: add             SP, SP, #0x20
    // 0x683480: stur            d0, [fp, #-0x78]
    // 0x683484: ldr             x16, [fp, #0x10]
    // 0x683488: ldur            lr, [fp, #-8]
    // 0x68348c: stp             lr, x16, [SP, #-0x10]!
    // 0x683490: ldur            d1, [fp, #-0x48]
    // 0x683494: SaveReg d1
    //     0x683494: str             d1, [SP, #-8]!
    // 0x683498: ldur            x16, [fp, #-0x18]
    // 0x68349c: SaveReg r16
    //     0x68349c: str             x16, [SP, #-8]!
    // 0x6834a0: r0 = calculateCacheOffset()
    //     0x6834a0: bl              #0x677aa4  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculateCacheOffset
    // 0x6834a4: add             SP, SP, #0x20
    // 0x6834a8: mov             v1.16b, v0.16b
    // 0x6834ac: ldur            d0, [fp, #-0x78]
    // 0x6834b0: fadd            d2, d1, d0
    // 0x6834b4: ldur            x0, [fp, #-0x28]
    // 0x6834b8: stur            d2, [fp, #-0x88]
    // 0x6834bc: LoadField: d0 = r0->field_17
    //     0x6834bc: ldur            d0, [x0, #0x17]
    // 0x6834c0: stur            d0, [fp, #-0x80]
    // 0x6834c4: LoadField: d1 = r0->field_1f
    //     0x6834c4: ldur            d1, [x0, #0x1f]
    // 0x6834c8: ldur            d3, [fp, #-0x70]
    // 0x6834cc: stur            d1, [fp, #-0x78]
    // 0x6834d0: fadd            d4, d1, d3
    // 0x6834d4: fcmp            d0, d4
    // 0x6834d8: b.vs            #0x6834ec
    // 0x6834dc: b.le            #0x6834ec
    // 0x6834e0: mov             v6.16b, v0.16b
    // 0x6834e4: d3 = 0.000000
    //     0x6834e4: eor             v3.16b, v3.16b, v3.16b
    // 0x6834e8: b               #0x683534
    // 0x6834ec: fcmp            d0, d4
    // 0x6834f0: b.vs            #0x683504
    // 0x6834f4: b.ge            #0x683504
    // 0x6834f8: mov             v6.16b, v4.16b
    // 0x6834fc: d3 = 0.000000
    //     0x6834fc: eor             v3.16b, v3.16b, v3.16b
    // 0x683500: b               #0x683534
    // 0x683504: d3 = 0.000000
    //     0x683504: eor             v3.16b, v3.16b, v3.16b
    // 0x683508: fcmp            d0, d3
    // 0x68350c: b.vs            #0x683520
    // 0x683510: b.ne            #0x683520
    // 0x683514: fadd            d5, d0, d4
    // 0x683518: mov             v6.16b, v5.16b
    // 0x68351c: b               #0x683534
    // 0x683520: fcmp            d4, d4
    // 0x683524: b.vc            #0x683530
    // 0x683528: mov             v6.16b, v4.16b
    // 0x68352c: b               #0x683534
    // 0x683530: mov             v6.16b, v0.16b
    // 0x683534: ldur            d4, [fp, #-0x50]
    // 0x683538: ldur            d5, [fp, #-0x30]
    // 0x68353c: fadd            d7, d4, d6
    // 0x683540: stur            d7, [fp, #-0x48]
    // 0x683544: fcmp            d7, d5
    // 0x683548: b.vs            #0x68355c
    // 0x68354c: b.le            #0x68355c
    // 0x683550: mov             v2.16b, v5.16b
    // 0x683554: mov             v0.16b, v1.16b
    // 0x683558: b               #0x683614
    // 0x68355c: fcmp            d7, d5
    // 0x683560: b.vs            #0x683574
    // 0x683564: b.ge            #0x683574
    // 0x683568: mov             v2.16b, v7.16b
    // 0x68356c: mov             v0.16b, v1.16b
    // 0x683570: b               #0x683614
    // 0x683574: fcmp            d7, d3
    // 0x683578: b.vs            #0x683580
    // 0x68357c: b.eq            #0x683588
    // 0x683580: r1 = false
    //     0x683580: add             x1, NULL, #0x30  ; false
    // 0x683584: b               #0x68358c
    // 0x683588: r1 = true
    //     0x683588: add             x1, NULL, #0x20  ; true
    // 0x68358c: tbnz            w1, #4, #0x6835a8
    // 0x683590: fadd            d6, d7, d5
    // 0x683594: fmul            d8, d6, d7
    // 0x683598: fmul            d6, d8, d5
    // 0x68359c: mov             v2.16b, v6.16b
    // 0x6835a0: mov             v0.16b, v1.16b
    // 0x6835a4: b               #0x683614
    // 0x6835a8: tbnz            w1, #4, #0x6835ec
    // 0x6835ac: r1 = inline_Allocate_Double()
    //     0x6835ac: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x6835b0: add             x1, x1, #0x10
    //     0x6835b4: cmp             x2, x1
    //     0x6835b8: b.ls            #0x6841d4
    //     0x6835bc: str             x1, [THR, #0x60]  ; THR::top
    //     0x6835c0: sub             x1, x1, #0xf
    //     0x6835c4: mov             x2, #0xd108
    //     0x6835c8: movk            x2, #3, lsl #16
    //     0x6835cc: stur            x2, [x1, #-1]
    // 0x6835d0: StoreField: r1->field_7 = d5
    //     0x6835d0: stur            d5, [x1, #7]
    // 0x6835d4: SaveReg r1
    //     0x6835d4: str             x1, [SP, #-8]!
    // 0x6835d8: r0 = isNegative()
    //     0x6835d8: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x6835dc: add             SP, SP, #8
    // 0x6835e0: tbnz            w0, #4, #0x6835ec
    // 0x6835e4: ldur            d0, [fp, #-0x30]
    // 0x6835e8: b               #0x6835f8
    // 0x6835ec: ldur            d0, [fp, #-0x30]
    // 0x6835f0: fcmp            d0, d0
    // 0x6835f4: b.vc            #0x683608
    // 0x6835f8: mov             v2.16b, v0.16b
    // 0x6835fc: ldur            d0, [fp, #-0x78]
    // 0x683600: ldur            x0, [fp, #-0x28]
    // 0x683604: b               #0x683614
    // 0x683608: ldur            d2, [fp, #-0x48]
    // 0x68360c: ldur            d0, [fp, #-0x78]
    // 0x683610: ldur            x0, [fp, #-0x28]
    // 0x683614: ldur            d1, [fp, #-0x68]
    // 0x683618: stur            d2, [fp, #-0x70]
    // 0x68361c: LoadField: d3 = r0->field_f
    //     0x68361c: ldur            d3, [x0, #0xf]
    // 0x683620: stur            d3, [fp, #-0x48]
    // 0x683624: fadd            d4, d1, d0
    // 0x683628: stur            d4, [fp, #-0x30]
    // 0x68362c: fcmp            d4, d2
    // 0x683630: b.vs            #0x683644
    // 0x683634: b.le            #0x683644
    // 0x683638: mov             v3.16b, v2.16b
    // 0x68363c: mov             v0.16b, v2.16b
    // 0x683640: b               #0x6836f8
    // 0x683644: fcmp            d4, d2
    // 0x683648: b.vs            #0x68365c
    // 0x68364c: b.ge            #0x68365c
    // 0x683650: mov             v3.16b, v4.16b
    // 0x683654: mov             v0.16b, v2.16b
    // 0x683658: b               #0x6836f8
    // 0x68365c: d0 = 0.000000
    //     0x68365c: eor             v0.16b, v0.16b, v0.16b
    // 0x683660: fcmp            d4, d0
    // 0x683664: b.vs            #0x68366c
    // 0x683668: b.eq            #0x683674
    // 0x68366c: r1 = false
    //     0x68366c: add             x1, NULL, #0x30  ; false
    // 0x683670: b               #0x683678
    // 0x683674: r1 = true
    //     0x683674: add             x1, NULL, #0x20  ; true
    // 0x683678: tbnz            w1, #4, #0x683694
    // 0x68367c: fadd            d5, d4, d2
    // 0x683680: fmul            d6, d5, d4
    // 0x683684: fmul            d4, d6, d2
    // 0x683688: mov             v3.16b, v4.16b
    // 0x68368c: mov             v0.16b, v2.16b
    // 0x683690: b               #0x6836f8
    // 0x683694: tbnz            w1, #4, #0x6836d8
    // 0x683698: r1 = inline_Allocate_Double()
    //     0x683698: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x68369c: add             x1, x1, #0x10
    //     0x6836a0: cmp             x2, x1
    //     0x6836a4: b.ls            #0x684208
    //     0x6836a8: str             x1, [THR, #0x60]  ; THR::top
    //     0x6836ac: sub             x1, x1, #0xf
    //     0x6836b0: mov             x2, #0xd108
    //     0x6836b4: movk            x2, #3, lsl #16
    //     0x6836b8: stur            x2, [x1, #-1]
    // 0x6836bc: StoreField: r1->field_7 = d2
    //     0x6836bc: stur            d2, [x1, #7]
    // 0x6836c0: SaveReg r1
    //     0x6836c0: str             x1, [SP, #-8]!
    // 0x6836c4: r0 = isNegative()
    //     0x6836c4: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x6836c8: add             SP, SP, #8
    // 0x6836cc: tbnz            w0, #4, #0x6836d8
    // 0x6836d0: ldur            d0, [fp, #-0x70]
    // 0x6836d4: b               #0x6836e4
    // 0x6836d8: ldur            d0, [fp, #-0x70]
    // 0x6836dc: fcmp            d0, d0
    // 0x6836e0: b.vc            #0x6836f0
    // 0x6836e4: mov             v3.16b, v0.16b
    // 0x6836e8: ldur            x0, [fp, #-0x28]
    // 0x6836ec: b               #0x6836f8
    // 0x6836f0: ldur            d3, [fp, #-0x30]
    // 0x6836f4: ldur            x0, [fp, #-0x28]
    // 0x6836f8: ldur            d2, [fp, #-0x60]
    // 0x6836fc: ldur            d1, [fp, #-0x88]
    // 0x683700: stur            d3, [fp, #-0x78]
    // 0x683704: LoadField: d4 = r0->field_4b
    //     0x683704: ldur            d4, [x0, #0x4b]
    // 0x683708: fadd            d5, d1, d4
    // 0x68370c: stur            d5, [fp, #-0x30]
    // 0x683710: fcmp            d5, d2
    // 0x683714: b.vs            #0x683724
    // 0x683718: b.le            #0x683724
    // 0x68371c: mov             v4.16b, v2.16b
    // 0x683720: b               #0x6837cc
    // 0x683724: fcmp            d5, d2
    // 0x683728: b.vs            #0x683738
    // 0x68372c: b.ge            #0x683738
    // 0x683730: mov             v4.16b, v5.16b
    // 0x683734: b               #0x6837cc
    // 0x683738: d1 = 0.000000
    //     0x683738: eor             v1.16b, v1.16b, v1.16b
    // 0x68373c: fcmp            d5, d1
    // 0x683740: b.vs            #0x683748
    // 0x683744: b.eq            #0x683750
    // 0x683748: r1 = false
    //     0x683748: add             x1, NULL, #0x30  ; false
    // 0x68374c: b               #0x683754
    // 0x683750: r1 = true
    //     0x683750: add             x1, NULL, #0x20  ; true
    // 0x683754: tbnz            w1, #4, #0x683768
    // 0x683758: fadd            d4, d5, d2
    // 0x68375c: fmul            d6, d4, d5
    // 0x683760: fmul            d4, d6, d2
    // 0x683764: b               #0x6837cc
    // 0x683768: tbnz            w1, #4, #0x6837ac
    // 0x68376c: r1 = inline_Allocate_Double()
    //     0x68376c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x683770: add             x1, x1, #0x10
    //     0x683774: cmp             x2, x1
    //     0x683778: b.ls            #0x684234
    //     0x68377c: str             x1, [THR, #0x60]  ; THR::top
    //     0x683780: sub             x1, x1, #0xf
    //     0x683784: mov             x2, #0xd108
    //     0x683788: movk            x2, #3, lsl #16
    //     0x68378c: stur            x2, [x1, #-1]
    // 0x683790: StoreField: r1->field_7 = d2
    //     0x683790: stur            d2, [x1, #7]
    // 0x683794: SaveReg r1
    //     0x683794: str             x1, [SP, #-8]!
    // 0x683798: r0 = isNegative()
    //     0x683798: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x68379c: add             SP, SP, #8
    // 0x6837a0: tbnz            w0, #4, #0x6837ac
    // 0x6837a4: ldur            d0, [fp, #-0x60]
    // 0x6837a8: b               #0x6837b8
    // 0x6837ac: ldur            d0, [fp, #-0x60]
    // 0x6837b0: fcmp            d0, d0
    // 0x6837b4: b.vc            #0x6837c4
    // 0x6837b8: mov             v4.16b, v0.16b
    // 0x6837bc: ldur            x0, [fp, #-0x28]
    // 0x6837c0: b               #0x6837cc
    // 0x6837c4: ldur            d4, [fp, #-0x30]
    // 0x6837c8: ldur            x0, [fp, #-0x28]
    // 0x6837cc: ldur            d2, [fp, #-0x50]
    // 0x6837d0: ldur            d0, [fp, #-0x68]
    // 0x6837d4: ldur            d1, [fp, #-0x80]
    // 0x6837d8: ldur            d3, [fp, #-0x40]
    // 0x6837dc: stur            d4, [fp, #-0x88]
    // 0x6837e0: LoadField: d5 = r0->field_27
    //     0x6837e0: ldur            d5, [x0, #0x27]
    // 0x6837e4: fadd            d6, d3, d5
    // 0x6837e8: stur            d6, [fp, #-0x60]
    // 0x6837ec: fadd            d3, d0, d1
    // 0x6837f0: LoadField: d0 = r0->field_37
    //     0x6837f0: ldur            d0, [x0, #0x37]
    // 0x6837f4: fadd            d1, d2, d0
    // 0x6837f8: fcmp            d3, d1
    // 0x6837fc: b.vs            #0x683810
    // 0x683800: b.le            #0x683810
    // 0x683804: mov             v7.16b, v3.16b
    // 0x683808: d0 = 0.000000
    //     0x683808: eor             v0.16b, v0.16b, v0.16b
    // 0x68380c: b               #0x683858
    // 0x683810: fcmp            d3, d1
    // 0x683814: b.vs            #0x683828
    // 0x683818: b.ge            #0x683828
    // 0x68381c: mov             v7.16b, v1.16b
    // 0x683820: d0 = 0.000000
    //     0x683820: eor             v0.16b, v0.16b, v0.16b
    // 0x683824: b               #0x683858
    // 0x683828: d0 = 0.000000
    //     0x683828: eor             v0.16b, v0.16b, v0.16b
    // 0x68382c: fcmp            d3, d0
    // 0x683830: b.vs            #0x683844
    // 0x683834: b.ne            #0x683844
    // 0x683838: fadd            d2, d3, d1
    // 0x68383c: mov             v7.16b, v2.16b
    // 0x683840: b               #0x683858
    // 0x683844: fcmp            d1, d1
    // 0x683848: b.vc            #0x683854
    // 0x68384c: mov             v7.16b, v1.16b
    // 0x683850: b               #0x683858
    // 0x683854: mov             v7.16b, v3.16b
    // 0x683858: ldr             x1, [fp, #0x10]
    // 0x68385c: ldur            d5, [fp, #-0x38]
    // 0x683860: ldur            d3, [fp, #-0x48]
    // 0x683864: ldur            d1, [fp, #-0x70]
    // 0x683868: ldur            d2, [fp, #-0x78]
    // 0x68386c: ldur            x2, [fp, #-8]
    // 0x683870: stur            d7, [fp, #-0x30]
    // 0x683874: LoadField: r3 = r0->field_43
    //     0x683874: ldur            w3, [x0, #0x43]
    // 0x683878: DecompressPointer r3
    //     0x683878: add             x3, x3, HEAP, lsl #32
    // 0x68387c: stur            x3, [fp, #-0x10]
    // 0x683880: r0 = SliverGeometry()
    //     0x683880: bl              #0x679334  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x54)
    // 0x683884: ldur            d0, [fp, #-0x38]
    // 0x683888: StoreField: r0->field_7 = d0
    //     0x683888: stur            d0, [x0, #7]
    // 0x68388c: ldur            d0, [fp, #-0x70]
    // 0x683890: StoreField: r0->field_17 = d0
    //     0x683890: stur            d0, [x0, #0x17]
    // 0x683894: ldur            d1, [fp, #-0x48]
    // 0x683898: StoreField: r0->field_f = d1
    //     0x683898: stur            d1, [x0, #0xf]
    // 0x68389c: ldur            d1, [fp, #-0x60]
    // 0x6838a0: StoreField: r0->field_27 = d1
    //     0x6838a0: stur            d1, [x0, #0x27]
    // 0x6838a4: d1 = 0.000000
    //     0x6838a4: eor             v1.16b, v1.16b, v1.16b
    // 0x6838a8: StoreField: r0->field_2f = d1
    //     0x6838a8: stur            d1, [x0, #0x2f]
    // 0x6838ac: ldur            x1, [fp, #-0x10]
    // 0x6838b0: StoreField: r0->field_43 = r1
    //     0x6838b0: stur            w1, [x0, #0x43]
    // 0x6838b4: ldur            d2, [fp, #-0x78]
    // 0x6838b8: StoreField: r0->field_1f = d2
    //     0x6838b8: stur            d2, [x0, #0x1f]
    // 0x6838bc: ldur            d2, [fp, #-0x30]
    // 0x6838c0: StoreField: r0->field_37 = d2
    //     0x6838c0: stur            d2, [x0, #0x37]
    // 0x6838c4: ldur            d2, [fp, #-0x88]
    // 0x6838c8: StoreField: r0->field_4b = d2
    //     0x6838c8: stur            d2, [x0, #0x4b]
    // 0x6838cc: fcmp            d0, d1
    // 0x6838d0: b.vs            #0x6838d8
    // 0x6838d4: b.gt            #0x6838e0
    // 0x6838d8: r1 = false
    //     0x6838d8: add             x1, NULL, #0x30  ; false
    // 0x6838dc: b               #0x6838e4
    // 0x6838e0: r1 = true
    //     0x6838e0: add             x1, NULL, #0x20  ; true
    // 0x6838e4: StoreField: r0->field_3f = r1
    //     0x6838e4: stur            w1, [x0, #0x3f]
    // 0x6838e8: ldr             x3, [fp, #0x10]
    // 0x6838ec: StoreField: r3->field_4f = r0
    //     0x6838ec: stur            w0, [x3, #0x4f]
    //     0x6838f0: ldurb           w16, [x3, #-1]
    //     0x6838f4: ldurb           w17, [x0, #-1]
    //     0x6838f8: and             x16, x17, x16, lsr #2
    //     0x6838fc: tst             x16, HEAP, lsr #32
    //     0x683900: b.eq            #0x683908
    //     0x683904: bl              #0xd682ac
    // 0x683908: LoadField: r0 = r3->field_53
    //     0x683908: ldur            w0, [x3, #0x53]
    // 0x68390c: DecompressPointer r0
    //     0x68390c: add             x0, x0, HEAP, lsl #32
    // 0x683910: cmp             w0, NULL
    // 0x683914: b.eq            #0x684260
    // 0x683918: LoadField: r4 = r0->field_17
    //     0x683918: ldur            w4, [x0, #0x17]
    // 0x68391c: DecompressPointer r4
    //     0x68391c: add             x4, x4, HEAP, lsl #32
    // 0x683920: stur            x4, [fp, #-0x10]
    // 0x683924: cmp             w4, NULL
    // 0x683928: b.eq            #0x684264
    // 0x68392c: mov             x0, x4
    // 0x683930: r2 = Null
    //     0x683930: mov             x2, NULL
    // 0x683934: r1 = Null
    //     0x683934: mov             x1, NULL
    // 0x683938: r4 = LoadClassIdInstr(r0)
    //     0x683938: ldur            x4, [x0, #-1]
    //     0x68393c: ubfx            x4, x4, #0xc, #0x14
    // 0x683940: sub             x4, x4, #0x7f3
    // 0x683944: cmp             x4, #2
    // 0x683948: b.ls            #0x683960
    // 0x68394c: r8 = SliverPhysicalParentData
    //     0x68394c: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5e0] Type: SliverPhysicalParentData
    //     0x683950: ldr             x8, [x8, #0x5e0]
    // 0x683954: r3 = Null
    //     0x683954: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c1c0] Null
    //     0x683958: ldr             x3, [x3, #0x1c0]
    // 0x68395c: r0 = DefaultTypeTest()
    //     0x68395c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x683960: ldur            x0, [fp, #-8]
    // 0x683964: LoadField: r1 = r0->field_7
    //     0x683964: ldur            w1, [x0, #7]
    // 0x683968: DecompressPointer r1
    //     0x683968: add             x1, x1, HEAP, lsl #32
    // 0x68396c: LoadField: r2 = r0->field_b
    //     0x68396c: ldur            w2, [x0, #0xb]
    // 0x683970: DecompressPointer r2
    //     0x683970: add             x2, x2, HEAP, lsl #32
    // 0x683974: stp             x2, x1, [SP, #-0x10]!
    // 0x683978: r0 = applyGrowthDirectionToAxisDirection()
    //     0x683978: bl              #0x643194  ; [package:flutter/src/rendering/sliver.dart] ::applyGrowthDirectionToAxisDirection
    // 0x68397c: add             SP, SP, #0x10
    // 0x683980: LoadField: r1 = r0->field_7
    //     0x683980: ldur            x1, [x0, #7]
    // 0x683984: cmp             x1, #1
    // 0x683988: b.gt            #0x683c8c
    // 0x68398c: cmp             x1, #0
    // 0x683990: b.gt            #0x683b54
    // 0x683994: ldr             x0, [fp, #0x10]
    // 0x683998: r1 = LoadClassIdInstr(r0)
    //     0x683998: ldur            x1, [x0, #-1]
    //     0x68399c: ubfx            x1, x1, #0xc, #0x14
    // 0x6839a0: lsl             x1, x1, #1
    // 0x6839a4: r17 = 5154
    //     0x6839a4: mov             x17, #0x1422
    // 0x6839a8: cmp             w1, w17
    // 0x6839ac: b.ne            #0x6839bc
    // 0x6839b0: LoadField: r2 = r0->field_63
    //     0x6839b0: ldur            w2, [x0, #0x63]
    // 0x6839b4: DecompressPointer r2
    //     0x6839b4: add             x2, x2, HEAP, lsl #32
    // 0x6839b8: b               #0x6839dc
    // 0x6839bc: r17 = 5156
    //     0x6839bc: mov             x17, #0x1424
    // 0x6839c0: cmp             w1, w17
    // 0x6839c4: b.ne            #0x6839d4
    // 0x6839c8: LoadField: r2 = r0->field_57
    //     0x6839c8: ldur            w2, [x0, #0x57]
    // 0x6839cc: DecompressPointer r2
    //     0x6839cc: add             x2, x2, HEAP, lsl #32
    // 0x6839d0: b               #0x6839dc
    // 0x6839d4: LoadField: r2 = r0->field_63
    //     0x6839d4: ldur            w2, [x0, #0x63]
    // 0x6839d8: DecompressPointer r2
    //     0x6839d8: add             x2, x2, HEAP, lsl #32
    // 0x6839dc: cmp             w2, NULL
    // 0x6839e0: b.eq            #0x684268
    // 0x6839e4: LoadField: d0 = r2->field_7
    //     0x6839e4: ldur            d0, [x2, #7]
    // 0x6839e8: stur            d0, [fp, #-0x30]
    // 0x6839ec: r17 = 5154
    //     0x6839ec: mov             x17, #0x1422
    // 0x6839f0: cmp             w1, w17
    // 0x6839f4: b.ne            #0x683a04
    // 0x6839f8: LoadField: r2 = r0->field_63
    //     0x6839f8: ldur            w2, [x0, #0x63]
    // 0x6839fc: DecompressPointer r2
    //     0x6839fc: add             x2, x2, HEAP, lsl #32
    // 0x683a00: b               #0x683a24
    // 0x683a04: r17 = 5156
    //     0x683a04: mov             x17, #0x1424
    // 0x683a08: cmp             w1, w17
    // 0x683a0c: b.ne            #0x683a1c
    // 0x683a10: LoadField: r2 = r0->field_57
    //     0x683a10: ldur            w2, [x0, #0x57]
    // 0x683a14: DecompressPointer r2
    //     0x683a14: add             x2, x2, HEAP, lsl #32
    // 0x683a18: b               #0x683a24
    // 0x683a1c: LoadField: r2 = r0->field_63
    //     0x683a1c: ldur            w2, [x0, #0x63]
    // 0x683a20: DecompressPointer r2
    //     0x683a20: add             x2, x2, HEAP, lsl #32
    // 0x683a24: ldur            d1, [fp, #-0x58]
    // 0x683a28: cmp             w2, NULL
    // 0x683a2c: b.eq            #0x68426c
    // 0x683a30: LoadField: d2 = r2->field_1f
    //     0x683a30: ldur            d2, [x2, #0x1f]
    // 0x683a34: fadd            d3, d2, d1
    // 0x683a38: r17 = 5154
    //     0x683a38: mov             x17, #0x1422
    // 0x683a3c: cmp             w1, w17
    // 0x683a40: b.ne            #0x683a50
    // 0x683a44: LoadField: r2 = r0->field_63
    //     0x683a44: ldur            w2, [x0, #0x63]
    // 0x683a48: DecompressPointer r2
    //     0x683a48: add             x2, x2, HEAP, lsl #32
    // 0x683a4c: b               #0x683a70
    // 0x683a50: r17 = 5156
    //     0x683a50: mov             x17, #0x1424
    // 0x683a54: cmp             w1, w17
    // 0x683a58: b.ne            #0x683a68
    // 0x683a5c: LoadField: r2 = r0->field_57
    //     0x683a5c: ldur            w2, [x0, #0x57]
    // 0x683a60: DecompressPointer r2
    //     0x683a60: add             x2, x2, HEAP, lsl #32
    // 0x683a64: b               #0x683a70
    // 0x683a68: LoadField: r2 = r0->field_63
    //     0x683a68: ldur            w2, [x0, #0x63]
    // 0x683a6c: DecompressPointer r2
    //     0x683a6c: add             x2, x2, HEAP, lsl #32
    // 0x683a70: cmp             w2, NULL
    // 0x683a74: b.eq            #0x684270
    // 0x683a78: LoadField: d2 = r2->field_1f
    //     0x683a78: ldur            d2, [x2, #0x1f]
    // 0x683a7c: fadd            d4, d2, d1
    // 0x683a80: r17 = 5154
    //     0x683a80: mov             x17, #0x1422
    // 0x683a84: cmp             w1, w17
    // 0x683a88: b.ne            #0x683a9c
    // 0x683a8c: LoadField: r1 = r0->field_63
    //     0x683a8c: ldur            w1, [x0, #0x63]
    // 0x683a90: DecompressPointer r1
    //     0x683a90: add             x1, x1, HEAP, lsl #32
    // 0x683a94: mov             x2, x1
    // 0x683a98: b               #0x683ac4
    // 0x683a9c: r17 = 5156
    //     0x683a9c: mov             x17, #0x1424
    // 0x683aa0: cmp             w1, w17
    // 0x683aa4: b.ne            #0x683ab8
    // 0x683aa8: LoadField: r1 = r0->field_57
    //     0x683aa8: ldur            w1, [x0, #0x57]
    // 0x683aac: DecompressPointer r1
    //     0x683aac: add             x1, x1, HEAP, lsl #32
    // 0x683ab0: mov             x2, x1
    // 0x683ab4: b               #0x683ac4
    // 0x683ab8: LoadField: r1 = r0->field_63
    //     0x683ab8: ldur            w1, [x0, #0x63]
    // 0x683abc: DecompressPointer r1
    //     0x683abc: add             x1, x1, HEAP, lsl #32
    // 0x683ac0: mov             x2, x1
    // 0x683ac4: ldur            x1, [fp, #-0x10]
    // 0x683ac8: cmp             w2, NULL
    // 0x683acc: b.eq            #0x684274
    // 0x683ad0: LoadField: d1 = r2->field_f
    //     0x683ad0: ldur            d1, [x2, #0xf]
    // 0x683ad4: fadd            d2, d4, d1
    // 0x683ad8: r2 = inline_Allocate_Double()
    //     0x683ad8: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x683adc: add             x2, x2, #0x10
    //     0x683ae0: cmp             x3, x2
    //     0x683ae4: b.ls            #0x684278
    //     0x683ae8: str             x2, [THR, #0x60]  ; THR::top
    //     0x683aec: sub             x2, x2, #0xf
    //     0x683af0: mov             x3, #0xd108
    //     0x683af4: movk            x3, #3, lsl #16
    //     0x683af8: stur            x3, [x2, #-1]
    // 0x683afc: StoreField: r2->field_7 = d2
    //     0x683afc: stur            d2, [x2, #7]
    // 0x683b00: ldur            x16, [fp, #-8]
    // 0x683b04: stp             x16, x0, [SP, #-0x10]!
    // 0x683b08: SaveReg d3
    //     0x683b08: str             d3, [SP, #-8]!
    // 0x683b0c: SaveReg r2
    //     0x683b0c: str             x2, [SP, #-8]!
    // 0x683b10: r0 = calculatePaintOffset()
    //     0x683b10: bl              #0x677ba0  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0x683b14: add             SP, SP, #0x20
    // 0x683b18: stur            d0, [fp, #-0x38]
    // 0x683b1c: r0 = Offset()
    //     0x683b1c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x683b20: ldur            d0, [fp, #-0x30]
    // 0x683b24: StoreField: r0->field_7 = d0
    //     0x683b24: stur            d0, [x0, #7]
    // 0x683b28: ldur            d0, [fp, #-0x38]
    // 0x683b2c: StoreField: r0->field_f = d0
    //     0x683b2c: stur            d0, [x0, #0xf]
    // 0x683b30: ldur            x1, [fp, #-0x10]
    // 0x683b34: StoreField: r1->field_7 = r0
    //     0x683b34: stur            w0, [x1, #7]
    //     0x683b38: ldurb           w16, [x1, #-1]
    //     0x683b3c: ldurb           w17, [x0, #-1]
    //     0x683b40: and             x16, x17, x16, lsr #2
    //     0x683b44: tst             x16, HEAP, lsr #32
    //     0x683b48: b.eq            #0x683b50
    //     0x683b4c: bl              #0xd6826c
    // 0x683b50: b               #0x683f78
    // 0x683b54: ldr             x0, [fp, #0x10]
    // 0x683b58: ldur            x1, [fp, #-0x10]
    // 0x683b5c: r2 = LoadClassIdInstr(r0)
    //     0x683b5c: ldur            x2, [x0, #-1]
    //     0x683b60: ubfx            x2, x2, #0xc, #0x14
    // 0x683b64: lsl             x2, x2, #1
    // 0x683b68: stur            x2, [fp, #-0x18]
    // 0x683b6c: r17 = 5154
    //     0x683b6c: mov             x17, #0x1422
    // 0x683b70: cmp             w2, w17
    // 0x683b74: b.ne            #0x683b84
    // 0x683b78: LoadField: r3 = r0->field_63
    //     0x683b78: ldur            w3, [x0, #0x63]
    // 0x683b7c: DecompressPointer r3
    //     0x683b7c: add             x3, x3, HEAP, lsl #32
    // 0x683b80: b               #0x683ba4
    // 0x683b84: r17 = 5156
    //     0x683b84: mov             x17, #0x1424
    // 0x683b88: cmp             w2, w17
    // 0x683b8c: b.ne            #0x683b9c
    // 0x683b90: LoadField: r3 = r0->field_57
    //     0x683b90: ldur            w3, [x0, #0x57]
    // 0x683b94: DecompressPointer r3
    //     0x683b94: add             x3, x3, HEAP, lsl #32
    // 0x683b98: b               #0x683ba4
    // 0x683b9c: LoadField: r3 = r0->field_63
    //     0x683b9c: ldur            w3, [x0, #0x63]
    // 0x683ba0: DecompressPointer r3
    //     0x683ba0: add             x3, x3, HEAP, lsl #32
    // 0x683ba4: cmp             w3, NULL
    // 0x683ba8: b.eq            #0x68429c
    // 0x683bac: LoadField: d0 = r3->field_7
    //     0x683bac: ldur            d0, [x3, #7]
    // 0x683bb0: r3 = inline_Allocate_Double()
    //     0x683bb0: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x683bb4: add             x3, x3, #0x10
    //     0x683bb8: cmp             x4, x3
    //     0x683bbc: b.ls            #0x6842a0
    //     0x683bc0: str             x3, [THR, #0x60]  ; THR::top
    //     0x683bc4: sub             x3, x3, #0xf
    //     0x683bc8: mov             x4, #0xd108
    //     0x683bcc: movk            x4, #3, lsl #16
    //     0x683bd0: stur            x4, [x3, #-1]
    // 0x683bd4: StoreField: r3->field_7 = d0
    //     0x683bd4: stur            d0, [x3, #7]
    // 0x683bd8: ldur            x16, [fp, #-8]
    // 0x683bdc: stp             x16, x0, [SP, #-0x10]!
    // 0x683be0: stp             x3, xzr, [SP, #-0x10]!
    // 0x683be4: r0 = calculatePaintOffset()
    //     0x683be4: bl              #0x677ba0  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0x683be8: add             SP, SP, #0x20
    // 0x683bec: ldur            x0, [fp, #-0x18]
    // 0x683bf0: stur            d0, [fp, #-0x38]
    // 0x683bf4: r17 = 5154
    //     0x683bf4: mov             x17, #0x1422
    // 0x683bf8: cmp             w0, w17
    // 0x683bfc: b.ne            #0x683c14
    // 0x683c00: ldr             x2, [fp, #0x10]
    // 0x683c04: LoadField: r0 = r2->field_63
    //     0x683c04: ldur            w0, [x2, #0x63]
    // 0x683c08: DecompressPointer r0
    //     0x683c08: add             x0, x0, HEAP, lsl #32
    // 0x683c0c: mov             x1, x0
    // 0x683c10: b               #0x683c40
    // 0x683c14: ldr             x2, [fp, #0x10]
    // 0x683c18: r17 = 5156
    //     0x683c18: mov             x17, #0x1424
    // 0x683c1c: cmp             w0, w17
    // 0x683c20: b.ne            #0x683c34
    // 0x683c24: LoadField: r0 = r2->field_57
    //     0x683c24: ldur            w0, [x2, #0x57]
    // 0x683c28: DecompressPointer r0
    //     0x683c28: add             x0, x0, HEAP, lsl #32
    // 0x683c2c: mov             x1, x0
    // 0x683c30: b               #0x683c40
    // 0x683c34: LoadField: r0 = r2->field_63
    //     0x683c34: ldur            w0, [x2, #0x63]
    // 0x683c38: DecompressPointer r0
    //     0x683c38: add             x0, x0, HEAP, lsl #32
    // 0x683c3c: mov             x1, x0
    // 0x683c40: ldur            x0, [fp, #-0x10]
    // 0x683c44: cmp             w1, NULL
    // 0x683c48: b.eq            #0x6842c4
    // 0x683c4c: LoadField: d1 = r1->field_f
    //     0x683c4c: ldur            d1, [x1, #0xf]
    // 0x683c50: stur            d1, [fp, #-0x30]
    // 0x683c54: r0 = Offset()
    //     0x683c54: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x683c58: ldur            d0, [fp, #-0x38]
    // 0x683c5c: StoreField: r0->field_7 = d0
    //     0x683c5c: stur            d0, [x0, #7]
    // 0x683c60: ldur            d0, [fp, #-0x30]
    // 0x683c64: StoreField: r0->field_f = d0
    //     0x683c64: stur            d0, [x0, #0xf]
    // 0x683c68: ldur            x3, [fp, #-0x10]
    // 0x683c6c: StoreField: r3->field_7 = r0
    //     0x683c6c: stur            w0, [x3, #7]
    //     0x683c70: ldurb           w16, [x3, #-1]
    //     0x683c74: ldurb           w17, [x0, #-1]
    //     0x683c78: and             x16, x17, x16, lsr #2
    //     0x683c7c: tst             x16, HEAP, lsr #32
    //     0x683c80: b.eq            #0x683c88
    //     0x683c84: bl              #0xd682ac
    // 0x683c88: b               #0x683f78
    // 0x683c8c: ldr             x2, [fp, #0x10]
    // 0x683c90: ldur            d1, [fp, #-0x58]
    // 0x683c94: ldur            x3, [fp, #-0x10]
    // 0x683c98: cmp             x1, #2
    // 0x683c9c: b.gt            #0x683db0
    // 0x683ca0: r0 = LoadClassIdInstr(r2)
    //     0x683ca0: ldur            x0, [x2, #-1]
    //     0x683ca4: ubfx            x0, x0, #0xc, #0x14
    // 0x683ca8: lsl             x0, x0, #1
    // 0x683cac: r17 = 5154
    //     0x683cac: mov             x17, #0x1422
    // 0x683cb0: cmp             w0, w17
    // 0x683cb4: b.ne            #0x683cc4
    // 0x683cb8: LoadField: r1 = r2->field_63
    //     0x683cb8: ldur            w1, [x2, #0x63]
    // 0x683cbc: DecompressPointer r1
    //     0x683cbc: add             x1, x1, HEAP, lsl #32
    // 0x683cc0: b               #0x683ce4
    // 0x683cc4: r17 = 5156
    //     0x683cc4: mov             x17, #0x1424
    // 0x683cc8: cmp             w0, w17
    // 0x683ccc: b.ne            #0x683cdc
    // 0x683cd0: LoadField: r1 = r2->field_57
    //     0x683cd0: ldur            w1, [x2, #0x57]
    // 0x683cd4: DecompressPointer r1
    //     0x683cd4: add             x1, x1, HEAP, lsl #32
    // 0x683cd8: b               #0x683ce4
    // 0x683cdc: LoadField: r1 = r2->field_63
    //     0x683cdc: ldur            w1, [x2, #0x63]
    // 0x683ce0: DecompressPointer r1
    //     0x683ce0: add             x1, x1, HEAP, lsl #32
    // 0x683ce4: cmp             w1, NULL
    // 0x683ce8: b.eq            #0x6842c8
    // 0x683cec: LoadField: d0 = r1->field_7
    //     0x683cec: ldur            d0, [x1, #7]
    // 0x683cf0: stur            d0, [fp, #-0x30]
    // 0x683cf4: r17 = 5154
    //     0x683cf4: mov             x17, #0x1422
    // 0x683cf8: cmp             w0, w17
    // 0x683cfc: b.ne            #0x683d0c
    // 0x683d00: LoadField: r0 = r2->field_63
    //     0x683d00: ldur            w0, [x2, #0x63]
    // 0x683d04: DecompressPointer r0
    //     0x683d04: add             x0, x0, HEAP, lsl #32
    // 0x683d08: b               #0x683d2c
    // 0x683d0c: r17 = 5156
    //     0x683d0c: mov             x17, #0x1424
    // 0x683d10: cmp             w0, w17
    // 0x683d14: b.ne            #0x683d24
    // 0x683d18: LoadField: r0 = r2->field_57
    //     0x683d18: ldur            w0, [x2, #0x57]
    // 0x683d1c: DecompressPointer r0
    //     0x683d1c: add             x0, x0, HEAP, lsl #32
    // 0x683d20: b               #0x683d2c
    // 0x683d24: LoadField: r0 = r2->field_63
    //     0x683d24: ldur            w0, [x2, #0x63]
    // 0x683d28: DecompressPointer r0
    //     0x683d28: add             x0, x0, HEAP, lsl #32
    // 0x683d2c: cmp             w0, NULL
    // 0x683d30: b.eq            #0x6842cc
    // 0x683d34: LoadField: d1 = r0->field_f
    //     0x683d34: ldur            d1, [x0, #0xf]
    // 0x683d38: r0 = inline_Allocate_Double()
    //     0x683d38: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x683d3c: add             x0, x0, #0x10
    //     0x683d40: cmp             x1, x0
    //     0x683d44: b.ls            #0x6842d0
    //     0x683d48: str             x0, [THR, #0x60]  ; THR::top
    //     0x683d4c: sub             x0, x0, #0xf
    //     0x683d50: mov             x1, #0xd108
    //     0x683d54: movk            x1, #3, lsl #16
    //     0x683d58: stur            x1, [x0, #-1]
    // 0x683d5c: StoreField: r0->field_7 = d1
    //     0x683d5c: stur            d1, [x0, #7]
    // 0x683d60: ldur            x16, [fp, #-8]
    // 0x683d64: stp             x16, x2, [SP, #-0x10]!
    // 0x683d68: stp             x0, xzr, [SP, #-0x10]!
    // 0x683d6c: r0 = calculatePaintOffset()
    //     0x683d6c: bl              #0x677ba0  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0x683d70: add             SP, SP, #0x20
    // 0x683d74: stur            d0, [fp, #-0x38]
    // 0x683d78: r0 = Offset()
    //     0x683d78: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x683d7c: ldur            d0, [fp, #-0x30]
    // 0x683d80: StoreField: r0->field_7 = d0
    //     0x683d80: stur            d0, [x0, #7]
    // 0x683d84: ldur            d0, [fp, #-0x38]
    // 0x683d88: StoreField: r0->field_f = d0
    //     0x683d88: stur            d0, [x0, #0xf]
    // 0x683d8c: ldur            x1, [fp, #-0x10]
    // 0x683d90: StoreField: r1->field_7 = r0
    //     0x683d90: stur            w0, [x1, #7]
    //     0x683d94: ldurb           w16, [x1, #-1]
    //     0x683d98: ldurb           w17, [x0, #-1]
    //     0x683d9c: and             x16, x17, x16, lsr #2
    //     0x683da0: tst             x16, HEAP, lsr #32
    //     0x683da4: b.eq            #0x683dac
    //     0x683da8: bl              #0xd6826c
    // 0x683dac: b               #0x683f78
    // 0x683db0: mov             x1, x3
    // 0x683db4: r0 = LoadClassIdInstr(r2)
    //     0x683db4: ldur            x0, [x2, #-1]
    //     0x683db8: ubfx            x0, x0, #0xc, #0x14
    // 0x683dbc: lsl             x0, x0, #1
    // 0x683dc0: stur            x0, [fp, #-0x18]
    // 0x683dc4: r17 = 5154
    //     0x683dc4: mov             x17, #0x1422
    // 0x683dc8: cmp             w0, w17
    // 0x683dcc: b.ne            #0x683ddc
    // 0x683dd0: LoadField: r3 = r2->field_63
    //     0x683dd0: ldur            w3, [x2, #0x63]
    // 0x683dd4: DecompressPointer r3
    //     0x683dd4: add             x3, x3, HEAP, lsl #32
    // 0x683dd8: b               #0x683dfc
    // 0x683ddc: r17 = 5156
    //     0x683ddc: mov             x17, #0x1424
    // 0x683de0: cmp             w0, w17
    // 0x683de4: b.ne            #0x683df4
    // 0x683de8: LoadField: r3 = r2->field_57
    //     0x683de8: ldur            w3, [x2, #0x57]
    // 0x683dec: DecompressPointer r3
    //     0x683dec: add             x3, x3, HEAP, lsl #32
    // 0x683df0: b               #0x683dfc
    // 0x683df4: LoadField: r3 = r2->field_63
    //     0x683df4: ldur            w3, [x2, #0x63]
    // 0x683df8: DecompressPointer r3
    //     0x683df8: add             x3, x3, HEAP, lsl #32
    // 0x683dfc: cmp             w3, NULL
    // 0x683e00: b.eq            #0x6842e8
    // 0x683e04: LoadField: d0 = r3->field_17
    //     0x683e04: ldur            d0, [x3, #0x17]
    // 0x683e08: fadd            d2, d0, d1
    // 0x683e0c: r17 = 5154
    //     0x683e0c: mov             x17, #0x1422
    // 0x683e10: cmp             w0, w17
    // 0x683e14: b.ne            #0x683e24
    // 0x683e18: LoadField: r3 = r2->field_63
    //     0x683e18: ldur            w3, [x2, #0x63]
    // 0x683e1c: DecompressPointer r3
    //     0x683e1c: add             x3, x3, HEAP, lsl #32
    // 0x683e20: b               #0x683e44
    // 0x683e24: r17 = 5156
    //     0x683e24: mov             x17, #0x1424
    // 0x683e28: cmp             w0, w17
    // 0x683e2c: b.ne            #0x683e3c
    // 0x683e30: LoadField: r3 = r2->field_57
    //     0x683e30: ldur            w3, [x2, #0x57]
    // 0x683e34: DecompressPointer r3
    //     0x683e34: add             x3, x3, HEAP, lsl #32
    // 0x683e38: b               #0x683e44
    // 0x683e3c: LoadField: r3 = r2->field_63
    //     0x683e3c: ldur            w3, [x2, #0x63]
    // 0x683e40: DecompressPointer r3
    //     0x683e40: add             x3, x3, HEAP, lsl #32
    // 0x683e44: cmp             w3, NULL
    // 0x683e48: b.eq            #0x6842ec
    // 0x683e4c: LoadField: d0 = r3->field_17
    //     0x683e4c: ldur            d0, [x3, #0x17]
    // 0x683e50: fadd            d3, d0, d1
    // 0x683e54: r17 = 5154
    //     0x683e54: mov             x17, #0x1422
    // 0x683e58: cmp             w0, w17
    // 0x683e5c: b.ne            #0x683e6c
    // 0x683e60: LoadField: r3 = r2->field_63
    //     0x683e60: ldur            w3, [x2, #0x63]
    // 0x683e64: DecompressPointer r3
    //     0x683e64: add             x3, x3, HEAP, lsl #32
    // 0x683e68: b               #0x683e8c
    // 0x683e6c: r17 = 5156
    //     0x683e6c: mov             x17, #0x1424
    // 0x683e70: cmp             w0, w17
    // 0x683e74: b.ne            #0x683e84
    // 0x683e78: LoadField: r3 = r2->field_57
    //     0x683e78: ldur            w3, [x2, #0x57]
    // 0x683e7c: DecompressPointer r3
    //     0x683e7c: add             x3, x3, HEAP, lsl #32
    // 0x683e80: b               #0x683e8c
    // 0x683e84: LoadField: r3 = r2->field_63
    //     0x683e84: ldur            w3, [x2, #0x63]
    // 0x683e88: DecompressPointer r3
    //     0x683e88: add             x3, x3, HEAP, lsl #32
    // 0x683e8c: cmp             w3, NULL
    // 0x683e90: b.eq            #0x6842f0
    // 0x683e94: LoadField: d0 = r3->field_7
    //     0x683e94: ldur            d0, [x3, #7]
    // 0x683e98: fadd            d1, d3, d0
    // 0x683e9c: r3 = inline_Allocate_Double()
    //     0x683e9c: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x683ea0: add             x3, x3, #0x10
    //     0x683ea4: cmp             x4, x3
    //     0x683ea8: b.ls            #0x6842f4
    //     0x683eac: str             x3, [THR, #0x60]  ; THR::top
    //     0x683eb0: sub             x3, x3, #0xf
    //     0x683eb4: mov             x4, #0xd108
    //     0x683eb8: movk            x4, #3, lsl #16
    //     0x683ebc: stur            x4, [x3, #-1]
    // 0x683ec0: StoreField: r3->field_7 = d1
    //     0x683ec0: stur            d1, [x3, #7]
    // 0x683ec4: ldur            x16, [fp, #-8]
    // 0x683ec8: stp             x16, x2, [SP, #-0x10]!
    // 0x683ecc: SaveReg d2
    //     0x683ecc: str             d2, [SP, #-8]!
    // 0x683ed0: SaveReg r3
    //     0x683ed0: str             x3, [SP, #-8]!
    // 0x683ed4: r0 = calculatePaintOffset()
    //     0x683ed4: bl              #0x677ba0  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0x683ed8: add             SP, SP, #0x20
    // 0x683edc: ldur            x0, [fp, #-0x18]
    // 0x683ee0: stur            d0, [fp, #-0x38]
    // 0x683ee4: r17 = 5154
    //     0x683ee4: mov             x17, #0x1422
    // 0x683ee8: cmp             w0, w17
    // 0x683eec: b.ne            #0x683f04
    // 0x683ef0: ldr             x1, [fp, #0x10]
    // 0x683ef4: LoadField: r0 = r1->field_63
    //     0x683ef4: ldur            w0, [x1, #0x63]
    // 0x683ef8: DecompressPointer r0
    //     0x683ef8: add             x0, x0, HEAP, lsl #32
    // 0x683efc: mov             x1, x0
    // 0x683f00: b               #0x683f30
    // 0x683f04: ldr             x1, [fp, #0x10]
    // 0x683f08: r17 = 5156
    //     0x683f08: mov             x17, #0x1424
    // 0x683f0c: cmp             w0, w17
    // 0x683f10: b.ne            #0x683f24
    // 0x683f14: LoadField: r0 = r1->field_57
    //     0x683f14: ldur            w0, [x1, #0x57]
    // 0x683f18: DecompressPointer r0
    //     0x683f18: add             x0, x0, HEAP, lsl #32
    // 0x683f1c: mov             x1, x0
    // 0x683f20: b               #0x683f30
    // 0x683f24: LoadField: r0 = r1->field_63
    //     0x683f24: ldur            w0, [x1, #0x63]
    // 0x683f28: DecompressPointer r0
    //     0x683f28: add             x0, x0, HEAP, lsl #32
    // 0x683f2c: mov             x1, x0
    // 0x683f30: ldur            x0, [fp, #-0x10]
    // 0x683f34: cmp             w1, NULL
    // 0x683f38: b.eq            #0x684318
    // 0x683f3c: LoadField: d1 = r1->field_f
    //     0x683f3c: ldur            d1, [x1, #0xf]
    // 0x683f40: stur            d1, [fp, #-0x30]
    // 0x683f44: r0 = Offset()
    //     0x683f44: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x683f48: ldur            d0, [fp, #-0x38]
    // 0x683f4c: StoreField: r0->field_7 = d0
    //     0x683f4c: stur            d0, [x0, #7]
    // 0x683f50: ldur            d0, [fp, #-0x30]
    // 0x683f54: StoreField: r0->field_f = d0
    //     0x683f54: stur            d0, [x0, #0xf]
    // 0x683f58: ldur            x1, [fp, #-0x10]
    // 0x683f5c: StoreField: r1->field_7 = r0
    //     0x683f5c: stur            w0, [x1, #7]
    //     0x683f60: ldurb           w16, [x1, #-1]
    //     0x683f64: ldurb           w17, [x0, #-1]
    //     0x683f68: and             x16, x17, x16, lsr #2
    //     0x683f6c: tst             x16, HEAP, lsr #32
    //     0x683f70: b.eq            #0x683f78
    //     0x683f74: bl              #0xd6826c
    // 0x683f78: r0 = Null
    //     0x683f78: mov             x0, NULL
    // 0x683f7c: LeaveFrame
    //     0x683f7c: mov             SP, fp
    //     0x683f80: ldp             fp, lr, [SP], #0x10
    // 0x683f84: ret
    //     0x683f84: ret             
    // 0x683f88: r0 = StateError()
    //     0x683f88: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x683f8c: mov             x1, x0
    // 0x683f90: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x683f90: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x683f94: ldr             x0, [x0, #0x1e8]
    // 0x683f98: StoreField: r1->field_b = r0
    //     0x683f98: stur            w0, [x1, #0xb]
    // 0x683f9c: mov             x0, x1
    // 0x683fa0: r0 = Throw()
    //     0x683fa0: bl              #0xd67e38  ; ThrowStub
    // 0x683fa4: brk             #0
    // 0x683fa8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x683fa8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x683fac: b               #0x682c8c
    // 0x683fb0: stp             q2, q3, [SP, #-0x20]!
    // 0x683fb4: stp             q0, q1, [SP, #-0x20]!
    // 0x683fb8: r0 = AllocateDouble()
    //     0x683fb8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x683fbc: ldp             q0, q1, [SP], #0x20
    // 0x683fc0: ldp             q2, q3, [SP], #0x20
    // 0x683fc4: b               #0x682e00
    // 0x683fc8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x683fc8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x683fcc: r0 = NullErrorSharedWithFPURegs()
    //     0x683fcc: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x683fd0: stp             q4, q6, [SP, #-0x20]!
    // 0x683fd4: stp             q2, q3, [SP, #-0x20]!
    // 0x683fd8: stp             q0, q1, [SP, #-0x20]!
    // 0x683fdc: stp             x2, x3, [SP, #-0x10]!
    // 0x683fe0: stp             x0, x1, [SP, #-0x10]!
    // 0x683fe4: r0 = AllocateDouble()
    //     0x683fe4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x683fe8: mov             x4, x0
    // 0x683fec: ldp             x0, x1, [SP], #0x10
    // 0x683ff0: ldp             x2, x3, [SP], #0x10
    // 0x683ff4: ldp             q0, q1, [SP], #0x20
    // 0x683ff8: ldp             q2, q3, [SP], #0x20
    // 0x683ffc: ldp             q4, q6, [SP], #0x20
    // 0x684000: b               #0x683088
    // 0x684004: r0 = NullErrorSharedWithFPURegs()
    //     0x684004: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x684008: stp             q8, q10, [SP, #-0x20]!
    // 0x68400c: stp             q6, q7, [SP, #-0x20]!
    // 0x684010: stp             q4, q5, [SP, #-0x20]!
    // 0x684014: stp             q2, q3, [SP, #-0x20]!
    // 0x684018: stp             q0, q1, [SP, #-0x20]!
    // 0x68401c: stp             x1, x2, [SP, #-0x10]!
    // 0x684020: SaveReg r0
    //     0x684020: str             x0, [SP, #-8]!
    // 0x684024: r0 = AllocateDouble()
    //     0x684024: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x684028: mov             x3, x0
    // 0x68402c: RestoreReg r0
    //     0x68402c: ldr             x0, [SP], #8
    // 0x684030: ldp             x1, x2, [SP], #0x10
    // 0x684034: ldp             q0, q1, [SP], #0x20
    // 0x684038: ldp             q2, q3, [SP], #0x20
    // 0x68403c: ldp             q4, q5, [SP], #0x20
    // 0x684040: ldp             q6, q7, [SP], #0x20
    // 0x684044: ldp             q8, q10, [SP], #0x20
    // 0x684048: b               #0x6831e4
    // 0x68404c: stp             q8, q10, [SP, #-0x20]!
    // 0x684050: stp             q6, q7, [SP, #-0x20]!
    // 0x684054: stp             q4, q5, [SP, #-0x20]!
    // 0x684058: stp             q1, q2, [SP, #-0x20]!
    // 0x68405c: SaveReg d0
    //     0x68405c: str             q0, [SP, #-0x10]!
    // 0x684060: stp             x2, x3, [SP, #-0x10]!
    // 0x684064: stp             x0, x1, [SP, #-0x10]!
    // 0x684068: r0 = AllocateDouble()
    //     0x684068: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68406c: mov             x4, x0
    // 0x684070: ldp             x0, x1, [SP], #0x10
    // 0x684074: ldp             x2, x3, [SP], #0x10
    // 0x684078: RestoreReg d0
    //     0x684078: ldr             q0, [SP], #0x10
    // 0x68407c: ldp             q1, q2, [SP], #0x20
    // 0x684080: ldp             q4, q5, [SP], #0x20
    // 0x684084: ldp             q6, q7, [SP], #0x20
    // 0x684088: ldp             q8, q10, [SP], #0x20
    // 0x68408c: b               #0x68320c
    // 0x684090: stp             q8, q10, [SP, #-0x20]!
    // 0x684094: stp             q6, q7, [SP, #-0x20]!
    // 0x684098: stp             q4, q5, [SP, #-0x20]!
    // 0x68409c: stp             q0, q1, [SP, #-0x20]!
    // 0x6840a0: stp             x3, x4, [SP, #-0x10]!
    // 0x6840a4: stp             x1, x2, [SP, #-0x10]!
    // 0x6840a8: SaveReg r0
    //     0x6840a8: str             x0, [SP, #-8]!
    // 0x6840ac: r0 = AllocateDouble()
    //     0x6840ac: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6840b0: mov             x5, x0
    // 0x6840b4: RestoreReg r0
    //     0x6840b4: ldr             x0, [SP], #8
    // 0x6840b8: ldp             x1, x2, [SP], #0x10
    // 0x6840bc: ldp             x3, x4, [SP], #0x10
    // 0x6840c0: ldp             q0, q1, [SP], #0x20
    // 0x6840c4: ldp             q4, q5, [SP], #0x20
    // 0x6840c8: ldp             q6, q7, [SP], #0x20
    // 0x6840cc: ldp             q8, q10, [SP], #0x20
    // 0x6840d0: b               #0x683234
    // 0x6840d4: stp             q7, q8, [SP, #-0x20]!
    // 0x6840d8: stp             q5, q6, [SP, #-0x20]!
    // 0x6840dc: stp             q1, q4, [SP, #-0x20]!
    // 0x6840e0: SaveReg d0
    //     0x6840e0: str             q0, [SP, #-0x10]!
    // 0x6840e4: stp             x4, x5, [SP, #-0x10]!
    // 0x6840e8: stp             x2, x3, [SP, #-0x10]!
    // 0x6840ec: stp             x0, x1, [SP, #-0x10]!
    // 0x6840f0: r0 = AllocateDouble()
    //     0x6840f0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6840f4: mov             x6, x0
    // 0x6840f8: ldp             x0, x1, [SP], #0x10
    // 0x6840fc: ldp             x2, x3, [SP], #0x10
    // 0x684100: ldp             x4, x5, [SP], #0x10
    // 0x684104: RestoreReg d0
    //     0x684104: ldr             q0, [SP], #0x10
    // 0x684108: ldp             q1, q4, [SP], #0x20
    // 0x68410c: ldp             q5, q6, [SP], #0x20
    // 0x684110: ldp             q7, q8, [SP], #0x20
    // 0x684114: b               #0x68325c
    // 0x684118: stp             q6, q8, [SP, #-0x20]!
    // 0x68411c: stp             q4, q5, [SP, #-0x20]!
    // 0x684120: stp             q0, q1, [SP, #-0x20]!
    // 0x684124: stp             x5, x6, [SP, #-0x10]!
    // 0x684128: stp             x3, x4, [SP, #-0x10]!
    // 0x68412c: stp             x1, x2, [SP, #-0x10]!
    // 0x684130: SaveReg r0
    //     0x684130: str             x0, [SP, #-8]!
    // 0x684134: r0 = AllocateDouble()
    //     0x684134: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x684138: mov             x7, x0
    // 0x68413c: RestoreReg r0
    //     0x68413c: ldr             x0, [SP], #8
    // 0x684140: ldp             x1, x2, [SP], #0x10
    // 0x684144: ldp             x3, x4, [SP], #0x10
    // 0x684148: ldp             x5, x6, [SP], #0x10
    // 0x68414c: ldp             q0, q1, [SP], #0x20
    // 0x684150: ldp             q4, q5, [SP], #0x20
    // 0x684154: ldp             q6, q8, [SP], #0x20
    // 0x684158: b               #0x683284
    // 0x68415c: stp             q6, q8, [SP, #-0x20]!
    // 0x684160: stp             q1, q5, [SP, #-0x20]!
    // 0x684164: SaveReg d0
    //     0x684164: str             q0, [SP, #-0x10]!
    // 0x684168: stp             x6, x7, [SP, #-0x10]!
    // 0x68416c: stp             x4, x5, [SP, #-0x10]!
    // 0x684170: stp             x2, x3, [SP, #-0x10]!
    // 0x684174: stp             x0, x1, [SP, #-0x10]!
    // 0x684178: r0 = AllocateDouble()
    //     0x684178: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68417c: mov             x8, x0
    // 0x684180: ldp             x0, x1, [SP], #0x10
    // 0x684184: ldp             x2, x3, [SP], #0x10
    // 0x684188: ldp             x4, x5, [SP], #0x10
    // 0x68418c: ldp             x6, x7, [SP], #0x10
    // 0x684190: RestoreReg d0
    //     0x684190: ldr             q0, [SP], #0x10
    // 0x684194: ldp             q1, q5, [SP], #0x20
    // 0x684198: ldp             q6, q8, [SP], #0x20
    // 0x68419c: b               #0x6832ac
    // 0x6841a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6841a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6841a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6841a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6841a8: r0 = NullErrorSharedWithFPURegs()
    //     0x6841a8: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x6841ac: stp             q4, q5, [SP, #-0x20]!
    // 0x6841b0: stp             q2, q3, [SP, #-0x20]!
    // 0x6841b4: stp             q0, q1, [SP, #-0x20]!
    // 0x6841b8: stp             x1, x2, [SP, #-0x10]!
    // 0x6841bc: r0 = AllocateDouble()
    //     0x6841bc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6841c0: ldp             x1, x2, [SP], #0x10
    // 0x6841c4: ldp             q0, q1, [SP], #0x20
    // 0x6841c8: ldp             q2, q3, [SP], #0x20
    // 0x6841cc: ldp             q4, q5, [SP], #0x20
    // 0x6841d0: b               #0x683430
    // 0x6841d4: stp             q5, q7, [SP, #-0x20]!
    // 0x6841d8: stp             q3, q4, [SP, #-0x20]!
    // 0x6841dc: stp             q1, q2, [SP, #-0x20]!
    // 0x6841e0: SaveReg d0
    //     0x6841e0: str             q0, [SP, #-0x10]!
    // 0x6841e4: SaveReg r0
    //     0x6841e4: str             x0, [SP, #-8]!
    // 0x6841e8: r0 = AllocateDouble()
    //     0x6841e8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6841ec: mov             x1, x0
    // 0x6841f0: RestoreReg r0
    //     0x6841f0: ldr             x0, [SP], #8
    // 0x6841f4: RestoreReg d0
    //     0x6841f4: ldr             q0, [SP], #0x10
    // 0x6841f8: ldp             q1, q2, [SP], #0x20
    // 0x6841fc: ldp             q3, q4, [SP], #0x20
    // 0x684200: ldp             q5, q7, [SP], #0x20
    // 0x684204: b               #0x6835d0
    // 0x684208: stp             q3, q4, [SP, #-0x20]!
    // 0x68420c: stp             q1, q2, [SP, #-0x20]!
    // 0x684210: SaveReg d0
    //     0x684210: str             q0, [SP, #-0x10]!
    // 0x684214: SaveReg r0
    //     0x684214: str             x0, [SP, #-8]!
    // 0x684218: r0 = AllocateDouble()
    //     0x684218: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68421c: mov             x1, x0
    // 0x684220: RestoreReg r0
    //     0x684220: ldr             x0, [SP], #8
    // 0x684224: RestoreReg d0
    //     0x684224: ldr             q0, [SP], #0x10
    // 0x684228: ldp             q1, q2, [SP], #0x20
    // 0x68422c: ldp             q3, q4, [SP], #0x20
    // 0x684230: b               #0x6836bc
    // 0x684234: stp             q3, q5, [SP, #-0x20]!
    // 0x684238: stp             q1, q2, [SP, #-0x20]!
    // 0x68423c: SaveReg d0
    //     0x68423c: str             q0, [SP, #-0x10]!
    // 0x684240: SaveReg r0
    //     0x684240: str             x0, [SP, #-8]!
    // 0x684244: r0 = AllocateDouble()
    //     0x684244: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x684248: mov             x1, x0
    // 0x68424c: RestoreReg r0
    //     0x68424c: ldr             x0, [SP], #8
    // 0x684250: RestoreReg d0
    //     0x684250: ldr             q0, [SP], #0x10
    // 0x684254: ldp             q1, q2, [SP], #0x20
    // 0x684258: ldp             q3, q5, [SP], #0x20
    // 0x68425c: b               #0x683790
    // 0x684260: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x684260: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x684264: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x684264: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x684268: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x684268: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68426c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68426c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x684270: r0 = NullCastErrorSharedWithFPURegs()
    //     0x684270: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x684274: r0 = NullCastErrorSharedWithFPURegs()
    //     0x684274: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x684278: stp             q2, q3, [SP, #-0x20]!
    // 0x68427c: SaveReg d0
    //     0x68427c: str             q0, [SP, #-0x10]!
    // 0x684280: stp             x0, x1, [SP, #-0x10]!
    // 0x684284: r0 = AllocateDouble()
    //     0x684284: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x684288: mov             x2, x0
    // 0x68428c: ldp             x0, x1, [SP], #0x10
    // 0x684290: RestoreReg d0
    //     0x684290: ldr             q0, [SP], #0x10
    // 0x684294: ldp             q2, q3, [SP], #0x20
    // 0x684298: b               #0x683afc
    // 0x68429c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68429c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6842a0: SaveReg d0
    //     0x6842a0: str             q0, [SP, #-0x10]!
    // 0x6842a4: stp             x1, x2, [SP, #-0x10]!
    // 0x6842a8: SaveReg r0
    //     0x6842a8: str             x0, [SP, #-8]!
    // 0x6842ac: r0 = AllocateDouble()
    //     0x6842ac: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6842b0: mov             x3, x0
    // 0x6842b4: RestoreReg r0
    //     0x6842b4: ldr             x0, [SP], #8
    // 0x6842b8: ldp             x1, x2, [SP], #0x10
    // 0x6842bc: RestoreReg d0
    //     0x6842bc: ldr             q0, [SP], #0x10
    // 0x6842c0: b               #0x683bd4
    // 0x6842c4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6842c4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6842c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6842c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6842cc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6842cc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6842d0: stp             q0, q1, [SP, #-0x20]!
    // 0x6842d4: stp             x2, x3, [SP, #-0x10]!
    // 0x6842d8: r0 = AllocateDouble()
    //     0x6842d8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6842dc: ldp             x2, x3, [SP], #0x10
    // 0x6842e0: ldp             q0, q1, [SP], #0x20
    // 0x6842e4: b               #0x683d5c
    // 0x6842e8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6842e8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6842ec: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6842ec: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6842f0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6842f0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6842f4: stp             q1, q2, [SP, #-0x20]!
    // 0x6842f8: stp             x1, x2, [SP, #-0x10]!
    // 0x6842fc: SaveReg r0
    //     0x6842fc: str             x0, [SP, #-8]!
    // 0x684300: r0 = AllocateDouble()
    //     0x684300: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x684304: mov             x3, x0
    // 0x684308: RestoreReg r0
    //     0x684308: ldr             x0, [SP], #8
    // 0x68430c: ldp             x1, x2, [SP], #0x10
    // 0x684310: ldp             q1, q2, [SP], #0x20
    // 0x684314: b               #0x683ec0
    // 0x684318: r0 = NullCastErrorSharedWithFPURegs()
    //     0x684318: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  get _ crossAxisPadding(/* No info */) {
    // ** addr: 0x684690, size: 0x208
    // 0x684690: EnterFrame
    //     0x684690: stp             fp, lr, [SP, #-0x10]!
    //     0x684694: mov             fp, SP
    // 0x684698: AllocStack(0x8)
    //     0x684698: sub             SP, SP, #8
    // 0x68469c: CheckStackOverflow
    //     0x68469c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6846a0: cmp             SP, x16
    //     0x6846a4: b.ls            #0x684868
    // 0x6846a8: ldr             x3, [fp, #0x10]
    // 0x6846ac: LoadField: r4 = r3->field_27
    //     0x6846ac: ldur            w4, [x3, #0x27]
    // 0x6846b0: DecompressPointer r4
    //     0x6846b0: add             x4, x4, HEAP, lsl #32
    // 0x6846b4: stur            x4, [fp, #-8]
    // 0x6846b8: cmp             w4, NULL
    // 0x6846bc: b.eq            #0x684848
    // 0x6846c0: mov             x0, x4
    // 0x6846c4: r2 = Null
    //     0x6846c4: mov             x2, NULL
    // 0x6846c8: r1 = Null
    //     0x6846c8: mov             x1, NULL
    // 0x6846cc: r4 = LoadClassIdInstr(r0)
    //     0x6846cc: ldur            x4, [x0, #-1]
    //     0x6846d0: ubfx            x4, x4, #0xc, #0x14
    // 0x6846d4: cmp             x4, #0x80c
    // 0x6846d8: b.eq            #0x6846f0
    // 0x6846dc: r8 = SliverConstraints
    //     0x6846dc: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x6846e0: ldr             x8, [x8, #0x5a8]
    // 0x6846e4: r3 = Null
    //     0x6846e4: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c1d0] Null
    //     0x6846e8: ldr             x3, [x3, #0x1d0]
    // 0x6846ec: r0 = DefaultTypeTest()
    //     0x6846ec: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6846f0: ldur            x16, [fp, #-8]
    // 0x6846f4: SaveReg r16
    //     0x6846f4: str             x16, [SP, #-8]!
    // 0x6846f8: r0 = axis()
    //     0x6846f8: bl              #0x643150  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0x6846fc: add             SP, SP, #8
    // 0x684700: LoadField: r1 = r0->field_7
    //     0x684700: ldur            x1, [x0, #7]
    // 0x684704: cmp             x1, #0
    // 0x684708: b.gt            #0x6847a0
    // 0x68470c: ldr             x1, [fp, #0x10]
    // 0x684710: r2 = LoadClassIdInstr(r1)
    //     0x684710: ldur            x2, [x1, #-1]
    //     0x684714: ubfx            x2, x2, #0xc, #0x14
    // 0x684718: lsl             x2, x2, #1
    // 0x68471c: r17 = 5154
    //     0x68471c: mov             x17, #0x1422
    // 0x684720: cmp             w2, w17
    // 0x684724: b.ne            #0x684738
    // 0x684728: LoadField: r3 = r1->field_63
    //     0x684728: ldur            w3, [x1, #0x63]
    // 0x68472c: DecompressPointer r3
    //     0x68472c: add             x3, x3, HEAP, lsl #32
    // 0x684730: mov             x2, x3
    // 0x684734: b               #0x684758
    // 0x684738: r17 = 5156
    //     0x684738: mov             x17, #0x1424
    // 0x68473c: cmp             w2, w17
    // 0x684740: b.ne            #0x684750
    // 0x684744: LoadField: r2 = r1->field_57
    //     0x684744: ldur            w2, [x1, #0x57]
    // 0x684748: DecompressPointer r2
    //     0x684748: add             x2, x2, HEAP, lsl #32
    // 0x68474c: b               #0x684758
    // 0x684750: LoadField: r2 = r1->field_63
    //     0x684750: ldur            w2, [x1, #0x63]
    // 0x684754: DecompressPointer r2
    //     0x684754: add             x2, x2, HEAP, lsl #32
    // 0x684758: cmp             w2, NULL
    // 0x68475c: b.eq            #0x684870
    // 0x684760: LoadField: d0 = r2->field_f
    //     0x684760: ldur            d0, [x2, #0xf]
    // 0x684764: LoadField: d1 = r2->field_1f
    //     0x684764: ldur            d1, [x2, #0x1f]
    // 0x684768: fadd            d2, d0, d1
    // 0x68476c: r0 = inline_Allocate_Double()
    //     0x68476c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x684770: add             x0, x0, #0x10
    //     0x684774: cmp             x2, x0
    //     0x684778: b.ls            #0x684874
    //     0x68477c: str             x0, [THR, #0x60]  ; THR::top
    //     0x684780: sub             x0, x0, #0xf
    //     0x684784: mov             x2, #0xd108
    //     0x684788: movk            x2, #3, lsl #16
    //     0x68478c: stur            x2, [x0, #-1]
    // 0x684790: StoreField: r0->field_7 = d2
    //     0x684790: stur            d2, [x0, #7]
    // 0x684794: LeaveFrame
    //     0x684794: mov             SP, fp
    //     0x684798: ldp             fp, lr, [SP], #0x10
    // 0x68479c: ret
    //     0x68479c: ret             
    // 0x6847a0: ldr             x1, [fp, #0x10]
    // 0x6847a4: r2 = LoadClassIdInstr(r1)
    //     0x6847a4: ldur            x2, [x1, #-1]
    //     0x6847a8: ubfx            x2, x2, #0xc, #0x14
    // 0x6847ac: lsl             x2, x2, #1
    // 0x6847b0: r17 = 5154
    //     0x6847b0: mov             x17, #0x1422
    // 0x6847b4: cmp             w2, w17
    // 0x6847b8: b.ne            #0x6847cc
    // 0x6847bc: LoadField: r3 = r1->field_63
    //     0x6847bc: ldur            w3, [x1, #0x63]
    // 0x6847c0: DecompressPointer r3
    //     0x6847c0: add             x3, x3, HEAP, lsl #32
    // 0x6847c4: mov             x1, x3
    // 0x6847c8: b               #0x6847f4
    // 0x6847cc: r17 = 5156
    //     0x6847cc: mov             x17, #0x1424
    // 0x6847d0: cmp             w2, w17
    // 0x6847d4: b.ne            #0x6847e8
    // 0x6847d8: LoadField: r2 = r1->field_57
    //     0x6847d8: ldur            w2, [x1, #0x57]
    // 0x6847dc: DecompressPointer r2
    //     0x6847dc: add             x2, x2, HEAP, lsl #32
    // 0x6847e0: mov             x1, x2
    // 0x6847e4: b               #0x6847f4
    // 0x6847e8: LoadField: r2 = r1->field_63
    //     0x6847e8: ldur            w2, [x1, #0x63]
    // 0x6847ec: DecompressPointer r2
    //     0x6847ec: add             x2, x2, HEAP, lsl #32
    // 0x6847f0: mov             x1, x2
    // 0x6847f4: d0 = 0.000000
    //     0x6847f4: eor             v0.16b, v0.16b, v0.16b
    // 0x6847f8: cmp             w1, NULL
    // 0x6847fc: b.eq            #0x684884
    // 0x684800: LoadField: d1 = r1->field_7
    //     0x684800: ldur            d1, [x1, #7]
    // 0x684804: LoadField: d2 = r1->field_17
    //     0x684804: ldur            d2, [x1, #0x17]
    // 0x684808: fadd            d3, d1, d2
    // 0x68480c: fadd            d1, d3, d0
    // 0x684810: fadd            d2, d1, d0
    // 0x684814: r0 = inline_Allocate_Double()
    //     0x684814: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x684818: add             x0, x0, #0x10
    //     0x68481c: cmp             x1, x0
    //     0x684820: b.ls            #0x684888
    //     0x684824: str             x0, [THR, #0x60]  ; THR::top
    //     0x684828: sub             x0, x0, #0xf
    //     0x68482c: mov             x1, #0xd108
    //     0x684830: movk            x1, #3, lsl #16
    //     0x684834: stur            x1, [x0, #-1]
    // 0x684838: StoreField: r0->field_7 = d2
    //     0x684838: stur            d2, [x0, #7]
    // 0x68483c: LeaveFrame
    //     0x68483c: mov             SP, fp
    //     0x684840: ldp             fp, lr, [SP], #0x10
    // 0x684844: ret
    //     0x684844: ret             
    // 0x684848: r0 = StateError()
    //     0x684848: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68484c: mov             x1, x0
    // 0x684850: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x684850: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x684854: ldr             x0, [x0, #0x1e8]
    // 0x684858: StoreField: r1->field_b = r0
    //     0x684858: stur            w0, [x1, #0xb]
    // 0x68485c: mov             x0, x1
    // 0x684860: r0 = Throw()
    //     0x684860: bl              #0xd67e38  ; ThrowStub
    // 0x684864: brk             #0
    // 0x684868: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x684868: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68486c: b               #0x6846a8
    // 0x684870: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x684870: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x684874: SaveReg d2
    //     0x684874: str             q2, [SP, #-0x10]!
    // 0x684878: r0 = AllocateDouble()
    //     0x684878: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68487c: RestoreReg d2
    //     0x68487c: ldr             q2, [SP], #0x10
    // 0x684880: b               #0x684790
    // 0x684884: r0 = NullCastErrorSharedWithFPURegs()
    //     0x684884: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x684888: SaveReg d2
    //     0x684888: str             q2, [SP, #-0x10]!
    // 0x68488c: r0 = AllocateDouble()
    //     0x68488c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x684890: RestoreReg d2
    //     0x684890: ldr             q2, [SP], #0x10
    // 0x684894: b               #0x684838
  }
  get _ mainAxisPadding(/* No info */) {
    // ** addr: 0x684898, size: 0x114
    // 0x684898: EnterFrame
    //     0x684898: stp             fp, lr, [SP, #-0x10]!
    //     0x68489c: mov             fp, SP
    // 0x6848a0: AllocStack(0x10)
    //     0x6848a0: sub             SP, SP, #0x10
    // 0x6848a4: CheckStackOverflow
    //     0x6848a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6848a8: cmp             SP, x16
    //     0x6848ac: b.ls            #0x6849a0
    // 0x6848b0: ldr             x0, [fp, #0x10]
    // 0x6848b4: r1 = LoadClassIdInstr(r0)
    //     0x6848b4: ldur            x1, [x0, #-1]
    //     0x6848b8: ubfx            x1, x1, #0xc, #0x14
    // 0x6848bc: lsl             x1, x1, #1
    // 0x6848c0: r17 = 5154
    //     0x6848c0: mov             x17, #0x1422
    // 0x6848c4: cmp             w1, w17
    // 0x6848c8: b.ne            #0x6848dc
    // 0x6848cc: LoadField: r1 = r0->field_63
    //     0x6848cc: ldur            w1, [x0, #0x63]
    // 0x6848d0: DecompressPointer r1
    //     0x6848d0: add             x1, x1, HEAP, lsl #32
    // 0x6848d4: mov             x3, x1
    // 0x6848d8: b               #0x684904
    // 0x6848dc: r17 = 5156
    //     0x6848dc: mov             x17, #0x1424
    // 0x6848e0: cmp             w1, w17
    // 0x6848e4: b.ne            #0x6848f8
    // 0x6848e8: LoadField: r1 = r0->field_57
    //     0x6848e8: ldur            w1, [x0, #0x57]
    // 0x6848ec: DecompressPointer r1
    //     0x6848ec: add             x1, x1, HEAP, lsl #32
    // 0x6848f0: mov             x3, x1
    // 0x6848f4: b               #0x684904
    // 0x6848f8: LoadField: r1 = r0->field_63
    //     0x6848f8: ldur            w1, [x0, #0x63]
    // 0x6848fc: DecompressPointer r1
    //     0x6848fc: add             x1, x1, HEAP, lsl #32
    // 0x684900: mov             x3, x1
    // 0x684904: stur            x3, [fp, #-0x10]
    // 0x684908: cmp             w3, NULL
    // 0x68490c: b.eq            #0x6849a8
    // 0x684910: LoadField: r4 = r0->field_27
    //     0x684910: ldur            w4, [x0, #0x27]
    // 0x684914: DecompressPointer r4
    //     0x684914: add             x4, x4, HEAP, lsl #32
    // 0x684918: stur            x4, [fp, #-8]
    // 0x68491c: cmp             w4, NULL
    // 0x684920: b.eq            #0x684980
    // 0x684924: mov             x0, x4
    // 0x684928: r2 = Null
    //     0x684928: mov             x2, NULL
    // 0x68492c: r1 = Null
    //     0x68492c: mov             x1, NULL
    // 0x684930: r4 = LoadClassIdInstr(r0)
    //     0x684930: ldur            x4, [x0, #-1]
    //     0x684934: ubfx            x4, x4, #0xc, #0x14
    // 0x684938: cmp             x4, #0x80c
    // 0x68493c: b.eq            #0x684954
    // 0x684940: r8 = SliverConstraints
    //     0x684940: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x684944: ldr             x8, [x8, #0x5a8]
    // 0x684948: r3 = Null
    //     0x684948: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c1e0] Null
    //     0x68494c: ldr             x3, [x3, #0x1e0]
    // 0x684950: r0 = DefaultTypeTest()
    //     0x684950: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x684954: ldur            x16, [fp, #-8]
    // 0x684958: SaveReg r16
    //     0x684958: str             x16, [SP, #-8]!
    // 0x68495c: r0 = axis()
    //     0x68495c: bl              #0x643150  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0x684960: add             SP, SP, #8
    // 0x684964: ldur            x16, [fp, #-0x10]
    // 0x684968: stp             x0, x16, [SP, #-0x10]!
    // 0x68496c: r0 = along()
    //     0x68496c: bl              #0x6849ac  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::along
    // 0x684970: add             SP, SP, #0x10
    // 0x684974: LeaveFrame
    //     0x684974: mov             SP, fp
    //     0x684978: ldp             fp, lr, [SP], #0x10
    // 0x68497c: ret
    //     0x68497c: ret             
    // 0x684980: r0 = StateError()
    //     0x684980: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x684984: mov             x1, x0
    // 0x684988: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x684988: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68498c: ldr             x0, [x0, #0x1e8]
    // 0x684990: StoreField: r1->field_b = r0
    //     0x684990: stur            w0, [x1, #0xb]
    // 0x684994: mov             x0, x1
    // 0x684998: r0 = Throw()
    //     0x684998: bl              #0xd67e38  ; ThrowStub
    // 0x68499c: brk             #0
    // 0x6849a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6849a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6849a4: b               #0x6848b0
    // 0x6849a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6849a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ afterPadding(/* No info */) {
    // ** addr: 0x684a90, size: 0x340
    // 0x684a90: EnterFrame
    //     0x684a90: stp             fp, lr, [SP, #-0x10]!
    //     0x684a94: mov             fp, SP
    // 0x684a98: AllocStack(0x8)
    //     0x684a98: sub             SP, SP, #8
    // 0x684a9c: CheckStackOverflow
    //     0x684a9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x684aa0: cmp             SP, x16
    //     0x684aa4: b.ls            #0x684d78
    // 0x684aa8: ldr             x3, [fp, #0x10]
    // 0x684aac: LoadField: r4 = r3->field_27
    //     0x684aac: ldur            w4, [x3, #0x27]
    // 0x684ab0: DecompressPointer r4
    //     0x684ab0: add             x4, x4, HEAP, lsl #32
    // 0x684ab4: stur            x4, [fp, #-8]
    // 0x684ab8: cmp             w4, NULL
    // 0x684abc: b.eq            #0x684d58
    // 0x684ac0: mov             x0, x4
    // 0x684ac4: r2 = Null
    //     0x684ac4: mov             x2, NULL
    // 0x684ac8: r1 = Null
    //     0x684ac8: mov             x1, NULL
    // 0x684acc: r4 = LoadClassIdInstr(r0)
    //     0x684acc: ldur            x4, [x0, #-1]
    //     0x684ad0: ubfx            x4, x4, #0xc, #0x14
    // 0x684ad4: cmp             x4, #0x80c
    // 0x684ad8: b.eq            #0x684af0
    // 0x684adc: r8 = SliverConstraints
    //     0x684adc: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x684ae0: ldr             x8, [x8, #0x5a8]
    // 0x684ae4: r3 = Null
    //     0x684ae4: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c1f0] Null
    //     0x684ae8: ldr             x3, [x3, #0x1f0]
    // 0x684aec: r0 = DefaultTypeTest()
    //     0x684aec: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x684af0: ldur            x0, [fp, #-8]
    // 0x684af4: LoadField: r1 = r0->field_7
    //     0x684af4: ldur            w1, [x0, #7]
    // 0x684af8: DecompressPointer r1
    //     0x684af8: add             x1, x1, HEAP, lsl #32
    // 0x684afc: LoadField: r2 = r0->field_b
    //     0x684afc: ldur            w2, [x0, #0xb]
    // 0x684b00: DecompressPointer r2
    //     0x684b00: add             x2, x2, HEAP, lsl #32
    // 0x684b04: stp             x2, x1, [SP, #-0x10]!
    // 0x684b08: r0 = applyGrowthDirectionToAxisDirection()
    //     0x684b08: bl              #0x643194  ; [package:flutter/src/rendering/sliver.dart] ::applyGrowthDirectionToAxisDirection
    // 0x684b0c: add             SP, SP, #0x10
    // 0x684b10: LoadField: r1 = r0->field_7
    //     0x684b10: ldur            x1, [x0, #7]
    // 0x684b14: cmp             x1, #1
    // 0x684b18: b.gt            #0x684c3c
    // 0x684b1c: cmp             x1, #0
    // 0x684b20: b.gt            #0x684bb0
    // 0x684b24: ldr             x2, [fp, #0x10]
    // 0x684b28: r3 = LoadClassIdInstr(r2)
    //     0x684b28: ldur            x3, [x2, #-1]
    //     0x684b2c: ubfx            x3, x3, #0xc, #0x14
    // 0x684b30: lsl             x3, x3, #1
    // 0x684b34: r17 = 5154
    //     0x684b34: mov             x17, #0x1422
    // 0x684b38: cmp             w3, w17
    // 0x684b3c: b.ne            #0x684b50
    // 0x684b40: LoadField: r4 = r2->field_63
    //     0x684b40: ldur            w4, [x2, #0x63]
    // 0x684b44: DecompressPointer r4
    //     0x684b44: add             x4, x4, HEAP, lsl #32
    // 0x684b48: mov             x3, x4
    // 0x684b4c: b               #0x684b70
    // 0x684b50: r17 = 5156
    //     0x684b50: mov             x17, #0x1424
    // 0x684b54: cmp             w3, w17
    // 0x684b58: b.ne            #0x684b68
    // 0x684b5c: LoadField: r3 = r2->field_57
    //     0x684b5c: ldur            w3, [x2, #0x57]
    // 0x684b60: DecompressPointer r3
    //     0x684b60: add             x3, x3, HEAP, lsl #32
    // 0x684b64: b               #0x684b70
    // 0x684b68: LoadField: r3 = r2->field_63
    //     0x684b68: ldur            w3, [x2, #0x63]
    // 0x684b6c: DecompressPointer r3
    //     0x684b6c: add             x3, x3, HEAP, lsl #32
    // 0x684b70: cmp             w3, NULL
    // 0x684b74: b.eq            #0x684d80
    // 0x684b78: LoadField: d0 = r3->field_f
    //     0x684b78: ldur            d0, [x3, #0xf]
    // 0x684b7c: r0 = inline_Allocate_Double()
    //     0x684b7c: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x684b80: add             x0, x0, #0x10
    //     0x684b84: cmp             x3, x0
    //     0x684b88: b.ls            #0x684d84
    //     0x684b8c: str             x0, [THR, #0x60]  ; THR::top
    //     0x684b90: sub             x0, x0, #0xf
    //     0x684b94: mov             x3, #0xd108
    //     0x684b98: movk            x3, #3, lsl #16
    //     0x684b9c: stur            x3, [x0, #-1]
    // 0x684ba0: StoreField: r0->field_7 = d0
    //     0x684ba0: stur            d0, [x0, #7]
    // 0x684ba4: LeaveFrame
    //     0x684ba4: mov             SP, fp
    //     0x684ba8: ldp             fp, lr, [SP], #0x10
    // 0x684bac: ret
    //     0x684bac: ret             
    // 0x684bb0: ldr             x2, [fp, #0x10]
    // 0x684bb4: r3 = LoadClassIdInstr(r2)
    //     0x684bb4: ldur            x3, [x2, #-1]
    //     0x684bb8: ubfx            x3, x3, #0xc, #0x14
    // 0x684bbc: lsl             x3, x3, #1
    // 0x684bc0: r17 = 5154
    //     0x684bc0: mov             x17, #0x1422
    // 0x684bc4: cmp             w3, w17
    // 0x684bc8: b.ne            #0x684bdc
    // 0x684bcc: LoadField: r4 = r2->field_63
    //     0x684bcc: ldur            w4, [x2, #0x63]
    // 0x684bd0: DecompressPointer r4
    //     0x684bd0: add             x4, x4, HEAP, lsl #32
    // 0x684bd4: mov             x3, x4
    // 0x684bd8: b               #0x684bfc
    // 0x684bdc: r17 = 5156
    //     0x684bdc: mov             x17, #0x1424
    // 0x684be0: cmp             w3, w17
    // 0x684be4: b.ne            #0x684bf4
    // 0x684be8: LoadField: r3 = r2->field_57
    //     0x684be8: ldur            w3, [x2, #0x57]
    // 0x684bec: DecompressPointer r3
    //     0x684bec: add             x3, x3, HEAP, lsl #32
    // 0x684bf0: b               #0x684bfc
    // 0x684bf4: LoadField: r3 = r2->field_63
    //     0x684bf4: ldur            w3, [x2, #0x63]
    // 0x684bf8: DecompressPointer r3
    //     0x684bf8: add             x3, x3, HEAP, lsl #32
    // 0x684bfc: cmp             w3, NULL
    // 0x684c00: b.eq            #0x684d94
    // 0x684c04: LoadField: d0 = r3->field_17
    //     0x684c04: ldur            d0, [x3, #0x17]
    // 0x684c08: r0 = inline_Allocate_Double()
    //     0x684c08: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x684c0c: add             x0, x0, #0x10
    //     0x684c10: cmp             x3, x0
    //     0x684c14: b.ls            #0x684d98
    //     0x684c18: str             x0, [THR, #0x60]  ; THR::top
    //     0x684c1c: sub             x0, x0, #0xf
    //     0x684c20: mov             x3, #0xd108
    //     0x684c24: movk            x3, #3, lsl #16
    //     0x684c28: stur            x3, [x0, #-1]
    // 0x684c2c: StoreField: r0->field_7 = d0
    //     0x684c2c: stur            d0, [x0, #7]
    // 0x684c30: LeaveFrame
    //     0x684c30: mov             SP, fp
    //     0x684c34: ldp             fp, lr, [SP], #0x10
    // 0x684c38: ret
    //     0x684c38: ret             
    // 0x684c3c: ldr             x2, [fp, #0x10]
    // 0x684c40: cmp             x1, #2
    // 0x684c44: b.gt            #0x684cd0
    // 0x684c48: r1 = LoadClassIdInstr(r2)
    //     0x684c48: ldur            x1, [x2, #-1]
    //     0x684c4c: ubfx            x1, x1, #0xc, #0x14
    // 0x684c50: lsl             x1, x1, #1
    // 0x684c54: r17 = 5154
    //     0x684c54: mov             x17, #0x1422
    // 0x684c58: cmp             w1, w17
    // 0x684c5c: b.ne            #0x684c70
    // 0x684c60: LoadField: r3 = r2->field_63
    //     0x684c60: ldur            w3, [x2, #0x63]
    // 0x684c64: DecompressPointer r3
    //     0x684c64: add             x3, x3, HEAP, lsl #32
    // 0x684c68: mov             x1, x3
    // 0x684c6c: b               #0x684c90
    // 0x684c70: r17 = 5156
    //     0x684c70: mov             x17, #0x1424
    // 0x684c74: cmp             w1, w17
    // 0x684c78: b.ne            #0x684c88
    // 0x684c7c: LoadField: r1 = r2->field_57
    //     0x684c7c: ldur            w1, [x2, #0x57]
    // 0x684c80: DecompressPointer r1
    //     0x684c80: add             x1, x1, HEAP, lsl #32
    // 0x684c84: b               #0x684c90
    // 0x684c88: LoadField: r1 = r2->field_63
    //     0x684c88: ldur            w1, [x2, #0x63]
    // 0x684c8c: DecompressPointer r1
    //     0x684c8c: add             x1, x1, HEAP, lsl #32
    // 0x684c90: cmp             w1, NULL
    // 0x684c94: b.eq            #0x684da8
    // 0x684c98: LoadField: d0 = r1->field_1f
    //     0x684c98: ldur            d0, [x1, #0x1f]
    // 0x684c9c: r0 = inline_Allocate_Double()
    //     0x684c9c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x684ca0: add             x0, x0, #0x10
    //     0x684ca4: cmp             x1, x0
    //     0x684ca8: b.ls            #0x684dac
    //     0x684cac: str             x0, [THR, #0x60]  ; THR::top
    //     0x684cb0: sub             x0, x0, #0xf
    //     0x684cb4: mov             x1, #0xd108
    //     0x684cb8: movk            x1, #3, lsl #16
    //     0x684cbc: stur            x1, [x0, #-1]
    // 0x684cc0: StoreField: r0->field_7 = d0
    //     0x684cc0: stur            d0, [x0, #7]
    // 0x684cc4: LeaveFrame
    //     0x684cc4: mov             SP, fp
    //     0x684cc8: ldp             fp, lr, [SP], #0x10
    // 0x684ccc: ret
    //     0x684ccc: ret             
    // 0x684cd0: r1 = LoadClassIdInstr(r2)
    //     0x684cd0: ldur            x1, [x2, #-1]
    //     0x684cd4: ubfx            x1, x1, #0xc, #0x14
    // 0x684cd8: lsl             x1, x1, #1
    // 0x684cdc: r17 = 5154
    //     0x684cdc: mov             x17, #0x1422
    // 0x684ce0: cmp             w1, w17
    // 0x684ce4: b.ne            #0x684cf8
    // 0x684ce8: LoadField: r3 = r2->field_63
    //     0x684ce8: ldur            w3, [x2, #0x63]
    // 0x684cec: DecompressPointer r3
    //     0x684cec: add             x3, x3, HEAP, lsl #32
    // 0x684cf0: mov             x1, x3
    // 0x684cf4: b               #0x684d18
    // 0x684cf8: r17 = 5156
    //     0x684cf8: mov             x17, #0x1424
    // 0x684cfc: cmp             w1, w17
    // 0x684d00: b.ne            #0x684d10
    // 0x684d04: LoadField: r1 = r2->field_57
    //     0x684d04: ldur            w1, [x2, #0x57]
    // 0x684d08: DecompressPointer r1
    //     0x684d08: add             x1, x1, HEAP, lsl #32
    // 0x684d0c: b               #0x684d18
    // 0x684d10: LoadField: r1 = r2->field_63
    //     0x684d10: ldur            w1, [x2, #0x63]
    // 0x684d14: DecompressPointer r1
    //     0x684d14: add             x1, x1, HEAP, lsl #32
    // 0x684d18: cmp             w1, NULL
    // 0x684d1c: b.eq            #0x684dbc
    // 0x684d20: LoadField: d0 = r1->field_7
    //     0x684d20: ldur            d0, [x1, #7]
    // 0x684d24: r0 = inline_Allocate_Double()
    //     0x684d24: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x684d28: add             x0, x0, #0x10
    //     0x684d2c: cmp             x1, x0
    //     0x684d30: b.ls            #0x684dc0
    //     0x684d34: str             x0, [THR, #0x60]  ; THR::top
    //     0x684d38: sub             x0, x0, #0xf
    //     0x684d3c: mov             x1, #0xd108
    //     0x684d40: movk            x1, #3, lsl #16
    //     0x684d44: stur            x1, [x0, #-1]
    // 0x684d48: StoreField: r0->field_7 = d0
    //     0x684d48: stur            d0, [x0, #7]
    // 0x684d4c: LeaveFrame
    //     0x684d4c: mov             SP, fp
    //     0x684d50: ldp             fp, lr, [SP], #0x10
    // 0x684d54: ret
    //     0x684d54: ret             
    // 0x684d58: r0 = StateError()
    //     0x684d58: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x684d5c: mov             x1, x0
    // 0x684d60: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x684d60: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x684d64: ldr             x0, [x0, #0x1e8]
    // 0x684d68: StoreField: r1->field_b = r0
    //     0x684d68: stur            w0, [x1, #0xb]
    // 0x684d6c: mov             x0, x1
    // 0x684d70: r0 = Throw()
    //     0x684d70: bl              #0xd67e38  ; ThrowStub
    // 0x684d74: brk             #0
    // 0x684d78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x684d78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x684d7c: b               #0x684aa8
    // 0x684d80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x684d80: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x684d84: SaveReg d0
    //     0x684d84: str             q0, [SP, #-0x10]!
    // 0x684d88: r0 = AllocateDouble()
    //     0x684d88: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x684d8c: RestoreReg d0
    //     0x684d8c: ldr             q0, [SP], #0x10
    // 0x684d90: b               #0x684ba0
    // 0x684d94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x684d94: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x684d98: SaveReg d0
    //     0x684d98: str             q0, [SP, #-0x10]!
    // 0x684d9c: r0 = AllocateDouble()
    //     0x684d9c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x684da0: RestoreReg d0
    //     0x684da0: ldr             q0, [SP], #0x10
    // 0x684da4: b               #0x684c2c
    // 0x684da8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x684da8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x684dac: SaveReg d0
    //     0x684dac: str             q0, [SP, #-0x10]!
    // 0x684db0: r0 = AllocateDouble()
    //     0x684db0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x684db4: RestoreReg d0
    //     0x684db4: ldr             q0, [SP], #0x10
    // 0x684db8: b               #0x684cc0
    // 0x684dbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x684dbc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x684dc0: SaveReg d0
    //     0x684dc0: str             q0, [SP, #-0x10]!
    // 0x684dc4: r0 = AllocateDouble()
    //     0x684dc4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x684dc8: RestoreReg d0
    //     0x684dc8: ldr             q0, [SP], #0x10
    // 0x684dcc: b               #0x684d48
  }
  get _ beforePadding(/* No info */) {
    // ** addr: 0x684dd0, size: 0x340
    // 0x684dd0: EnterFrame
    //     0x684dd0: stp             fp, lr, [SP, #-0x10]!
    //     0x684dd4: mov             fp, SP
    // 0x684dd8: AllocStack(0x8)
    //     0x684dd8: sub             SP, SP, #8
    // 0x684ddc: CheckStackOverflow
    //     0x684ddc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x684de0: cmp             SP, x16
    //     0x684de4: b.ls            #0x6850b8
    // 0x684de8: ldr             x3, [fp, #0x10]
    // 0x684dec: LoadField: r4 = r3->field_27
    //     0x684dec: ldur            w4, [x3, #0x27]
    // 0x684df0: DecompressPointer r4
    //     0x684df0: add             x4, x4, HEAP, lsl #32
    // 0x684df4: stur            x4, [fp, #-8]
    // 0x684df8: cmp             w4, NULL
    // 0x684dfc: b.eq            #0x685098
    // 0x684e00: mov             x0, x4
    // 0x684e04: r2 = Null
    //     0x684e04: mov             x2, NULL
    // 0x684e08: r1 = Null
    //     0x684e08: mov             x1, NULL
    // 0x684e0c: r4 = LoadClassIdInstr(r0)
    //     0x684e0c: ldur            x4, [x0, #-1]
    //     0x684e10: ubfx            x4, x4, #0xc, #0x14
    // 0x684e14: cmp             x4, #0x80c
    // 0x684e18: b.eq            #0x684e30
    // 0x684e1c: r8 = SliverConstraints
    //     0x684e1c: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x684e20: ldr             x8, [x8, #0x5a8]
    // 0x684e24: r3 = Null
    //     0x684e24: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c200] Null
    //     0x684e28: ldr             x3, [x3, #0x200]
    // 0x684e2c: r0 = DefaultTypeTest()
    //     0x684e2c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x684e30: ldur            x0, [fp, #-8]
    // 0x684e34: LoadField: r1 = r0->field_7
    //     0x684e34: ldur            w1, [x0, #7]
    // 0x684e38: DecompressPointer r1
    //     0x684e38: add             x1, x1, HEAP, lsl #32
    // 0x684e3c: LoadField: r2 = r0->field_b
    //     0x684e3c: ldur            w2, [x0, #0xb]
    // 0x684e40: DecompressPointer r2
    //     0x684e40: add             x2, x2, HEAP, lsl #32
    // 0x684e44: stp             x2, x1, [SP, #-0x10]!
    // 0x684e48: r0 = applyGrowthDirectionToAxisDirection()
    //     0x684e48: bl              #0x643194  ; [package:flutter/src/rendering/sliver.dart] ::applyGrowthDirectionToAxisDirection
    // 0x684e4c: add             SP, SP, #0x10
    // 0x684e50: LoadField: r1 = r0->field_7
    //     0x684e50: ldur            x1, [x0, #7]
    // 0x684e54: cmp             x1, #1
    // 0x684e58: b.gt            #0x684f7c
    // 0x684e5c: cmp             x1, #0
    // 0x684e60: b.gt            #0x684ef0
    // 0x684e64: ldr             x2, [fp, #0x10]
    // 0x684e68: r3 = LoadClassIdInstr(r2)
    //     0x684e68: ldur            x3, [x2, #-1]
    //     0x684e6c: ubfx            x3, x3, #0xc, #0x14
    // 0x684e70: lsl             x3, x3, #1
    // 0x684e74: r17 = 5154
    //     0x684e74: mov             x17, #0x1422
    // 0x684e78: cmp             w3, w17
    // 0x684e7c: b.ne            #0x684e90
    // 0x684e80: LoadField: r4 = r2->field_63
    //     0x684e80: ldur            w4, [x2, #0x63]
    // 0x684e84: DecompressPointer r4
    //     0x684e84: add             x4, x4, HEAP, lsl #32
    // 0x684e88: mov             x3, x4
    // 0x684e8c: b               #0x684eb0
    // 0x684e90: r17 = 5156
    //     0x684e90: mov             x17, #0x1424
    // 0x684e94: cmp             w3, w17
    // 0x684e98: b.ne            #0x684ea8
    // 0x684e9c: LoadField: r3 = r2->field_57
    //     0x684e9c: ldur            w3, [x2, #0x57]
    // 0x684ea0: DecompressPointer r3
    //     0x684ea0: add             x3, x3, HEAP, lsl #32
    // 0x684ea4: b               #0x684eb0
    // 0x684ea8: LoadField: r3 = r2->field_63
    //     0x684ea8: ldur            w3, [x2, #0x63]
    // 0x684eac: DecompressPointer r3
    //     0x684eac: add             x3, x3, HEAP, lsl #32
    // 0x684eb0: cmp             w3, NULL
    // 0x684eb4: b.eq            #0x6850c0
    // 0x684eb8: LoadField: d0 = r3->field_1f
    //     0x684eb8: ldur            d0, [x3, #0x1f]
    // 0x684ebc: r0 = inline_Allocate_Double()
    //     0x684ebc: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x684ec0: add             x0, x0, #0x10
    //     0x684ec4: cmp             x3, x0
    //     0x684ec8: b.ls            #0x6850c4
    //     0x684ecc: str             x0, [THR, #0x60]  ; THR::top
    //     0x684ed0: sub             x0, x0, #0xf
    //     0x684ed4: mov             x3, #0xd108
    //     0x684ed8: movk            x3, #3, lsl #16
    //     0x684edc: stur            x3, [x0, #-1]
    // 0x684ee0: StoreField: r0->field_7 = d0
    //     0x684ee0: stur            d0, [x0, #7]
    // 0x684ee4: LeaveFrame
    //     0x684ee4: mov             SP, fp
    //     0x684ee8: ldp             fp, lr, [SP], #0x10
    // 0x684eec: ret
    //     0x684eec: ret             
    // 0x684ef0: ldr             x2, [fp, #0x10]
    // 0x684ef4: r3 = LoadClassIdInstr(r2)
    //     0x684ef4: ldur            x3, [x2, #-1]
    //     0x684ef8: ubfx            x3, x3, #0xc, #0x14
    // 0x684efc: lsl             x3, x3, #1
    // 0x684f00: r17 = 5154
    //     0x684f00: mov             x17, #0x1422
    // 0x684f04: cmp             w3, w17
    // 0x684f08: b.ne            #0x684f1c
    // 0x684f0c: LoadField: r4 = r2->field_63
    //     0x684f0c: ldur            w4, [x2, #0x63]
    // 0x684f10: DecompressPointer r4
    //     0x684f10: add             x4, x4, HEAP, lsl #32
    // 0x684f14: mov             x3, x4
    // 0x684f18: b               #0x684f3c
    // 0x684f1c: r17 = 5156
    //     0x684f1c: mov             x17, #0x1424
    // 0x684f20: cmp             w3, w17
    // 0x684f24: b.ne            #0x684f34
    // 0x684f28: LoadField: r3 = r2->field_57
    //     0x684f28: ldur            w3, [x2, #0x57]
    // 0x684f2c: DecompressPointer r3
    //     0x684f2c: add             x3, x3, HEAP, lsl #32
    // 0x684f30: b               #0x684f3c
    // 0x684f34: LoadField: r3 = r2->field_63
    //     0x684f34: ldur            w3, [x2, #0x63]
    // 0x684f38: DecompressPointer r3
    //     0x684f38: add             x3, x3, HEAP, lsl #32
    // 0x684f3c: cmp             w3, NULL
    // 0x684f40: b.eq            #0x6850d4
    // 0x684f44: LoadField: d0 = r3->field_7
    //     0x684f44: ldur            d0, [x3, #7]
    // 0x684f48: r0 = inline_Allocate_Double()
    //     0x684f48: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x684f4c: add             x0, x0, #0x10
    //     0x684f50: cmp             x3, x0
    //     0x684f54: b.ls            #0x6850d8
    //     0x684f58: str             x0, [THR, #0x60]  ; THR::top
    //     0x684f5c: sub             x0, x0, #0xf
    //     0x684f60: mov             x3, #0xd108
    //     0x684f64: movk            x3, #3, lsl #16
    //     0x684f68: stur            x3, [x0, #-1]
    // 0x684f6c: StoreField: r0->field_7 = d0
    //     0x684f6c: stur            d0, [x0, #7]
    // 0x684f70: LeaveFrame
    //     0x684f70: mov             SP, fp
    //     0x684f74: ldp             fp, lr, [SP], #0x10
    // 0x684f78: ret
    //     0x684f78: ret             
    // 0x684f7c: ldr             x2, [fp, #0x10]
    // 0x684f80: cmp             x1, #2
    // 0x684f84: b.gt            #0x685010
    // 0x684f88: r1 = LoadClassIdInstr(r2)
    //     0x684f88: ldur            x1, [x2, #-1]
    //     0x684f8c: ubfx            x1, x1, #0xc, #0x14
    // 0x684f90: lsl             x1, x1, #1
    // 0x684f94: r17 = 5154
    //     0x684f94: mov             x17, #0x1422
    // 0x684f98: cmp             w1, w17
    // 0x684f9c: b.ne            #0x684fb0
    // 0x684fa0: LoadField: r3 = r2->field_63
    //     0x684fa0: ldur            w3, [x2, #0x63]
    // 0x684fa4: DecompressPointer r3
    //     0x684fa4: add             x3, x3, HEAP, lsl #32
    // 0x684fa8: mov             x1, x3
    // 0x684fac: b               #0x684fd0
    // 0x684fb0: r17 = 5156
    //     0x684fb0: mov             x17, #0x1424
    // 0x684fb4: cmp             w1, w17
    // 0x684fb8: b.ne            #0x684fc8
    // 0x684fbc: LoadField: r1 = r2->field_57
    //     0x684fbc: ldur            w1, [x2, #0x57]
    // 0x684fc0: DecompressPointer r1
    //     0x684fc0: add             x1, x1, HEAP, lsl #32
    // 0x684fc4: b               #0x684fd0
    // 0x684fc8: LoadField: r1 = r2->field_63
    //     0x684fc8: ldur            w1, [x2, #0x63]
    // 0x684fcc: DecompressPointer r1
    //     0x684fcc: add             x1, x1, HEAP, lsl #32
    // 0x684fd0: cmp             w1, NULL
    // 0x684fd4: b.eq            #0x6850e8
    // 0x684fd8: LoadField: d0 = r1->field_f
    //     0x684fd8: ldur            d0, [x1, #0xf]
    // 0x684fdc: r0 = inline_Allocate_Double()
    //     0x684fdc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x684fe0: add             x0, x0, #0x10
    //     0x684fe4: cmp             x1, x0
    //     0x684fe8: b.ls            #0x6850ec
    //     0x684fec: str             x0, [THR, #0x60]  ; THR::top
    //     0x684ff0: sub             x0, x0, #0xf
    //     0x684ff4: mov             x1, #0xd108
    //     0x684ff8: movk            x1, #3, lsl #16
    //     0x684ffc: stur            x1, [x0, #-1]
    // 0x685000: StoreField: r0->field_7 = d0
    //     0x685000: stur            d0, [x0, #7]
    // 0x685004: LeaveFrame
    //     0x685004: mov             SP, fp
    //     0x685008: ldp             fp, lr, [SP], #0x10
    // 0x68500c: ret
    //     0x68500c: ret             
    // 0x685010: r1 = LoadClassIdInstr(r2)
    //     0x685010: ldur            x1, [x2, #-1]
    //     0x685014: ubfx            x1, x1, #0xc, #0x14
    // 0x685018: lsl             x1, x1, #1
    // 0x68501c: r17 = 5154
    //     0x68501c: mov             x17, #0x1422
    // 0x685020: cmp             w1, w17
    // 0x685024: b.ne            #0x685038
    // 0x685028: LoadField: r3 = r2->field_63
    //     0x685028: ldur            w3, [x2, #0x63]
    // 0x68502c: DecompressPointer r3
    //     0x68502c: add             x3, x3, HEAP, lsl #32
    // 0x685030: mov             x1, x3
    // 0x685034: b               #0x685058
    // 0x685038: r17 = 5156
    //     0x685038: mov             x17, #0x1424
    // 0x68503c: cmp             w1, w17
    // 0x685040: b.ne            #0x685050
    // 0x685044: LoadField: r1 = r2->field_57
    //     0x685044: ldur            w1, [x2, #0x57]
    // 0x685048: DecompressPointer r1
    //     0x685048: add             x1, x1, HEAP, lsl #32
    // 0x68504c: b               #0x685058
    // 0x685050: LoadField: r1 = r2->field_63
    //     0x685050: ldur            w1, [x2, #0x63]
    // 0x685054: DecompressPointer r1
    //     0x685054: add             x1, x1, HEAP, lsl #32
    // 0x685058: cmp             w1, NULL
    // 0x68505c: b.eq            #0x6850fc
    // 0x685060: LoadField: d0 = r1->field_17
    //     0x685060: ldur            d0, [x1, #0x17]
    // 0x685064: r0 = inline_Allocate_Double()
    //     0x685064: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x685068: add             x0, x0, #0x10
    //     0x68506c: cmp             x1, x0
    //     0x685070: b.ls            #0x685100
    //     0x685074: str             x0, [THR, #0x60]  ; THR::top
    //     0x685078: sub             x0, x0, #0xf
    //     0x68507c: mov             x1, #0xd108
    //     0x685080: movk            x1, #3, lsl #16
    //     0x685084: stur            x1, [x0, #-1]
    // 0x685088: StoreField: r0->field_7 = d0
    //     0x685088: stur            d0, [x0, #7]
    // 0x68508c: LeaveFrame
    //     0x68508c: mov             SP, fp
    //     0x685090: ldp             fp, lr, [SP], #0x10
    // 0x685094: ret
    //     0x685094: ret             
    // 0x685098: r0 = StateError()
    //     0x685098: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68509c: mov             x1, x0
    // 0x6850a0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6850a0: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6850a4: ldr             x0, [x0, #0x1e8]
    // 0x6850a8: StoreField: r1->field_b = r0
    //     0x6850a8: stur            w0, [x1, #0xb]
    // 0x6850ac: mov             x0, x1
    // 0x6850b0: r0 = Throw()
    //     0x6850b0: bl              #0xd67e38  ; ThrowStub
    // 0x6850b4: brk             #0
    // 0x6850b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6850b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6850bc: b               #0x684de8
    // 0x6850c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6850c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6850c4: SaveReg d0
    //     0x6850c4: str             q0, [SP, #-0x10]!
    // 0x6850c8: r0 = AllocateDouble()
    //     0x6850c8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6850cc: RestoreReg d0
    //     0x6850cc: ldr             q0, [SP], #0x10
    // 0x6850d0: b               #0x684ee0
    // 0x6850d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6850d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6850d8: SaveReg d0
    //     0x6850d8: str             q0, [SP, #-0x10]!
    // 0x6850dc: r0 = AllocateDouble()
    //     0x6850dc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6850e0: RestoreReg d0
    //     0x6850e0: ldr             q0, [SP], #0x10
    // 0x6850e4: b               #0x684f6c
    // 0x6850e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6850e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6850ec: SaveReg d0
    //     0x6850ec: str             q0, [SP, #-0x10]!
    // 0x6850f0: r0 = AllocateDouble()
    //     0x6850f0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6850f4: RestoreReg d0
    //     0x6850f4: ldr             q0, [SP], #0x10
    // 0x6850f8: b               #0x685000
    // 0x6850fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6850fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x685100: SaveReg d0
    //     0x685100: str             q0, [SP, #-0x10]!
    // 0x685104: r0 = AllocateDouble()
    //     0x685104: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x685108: RestoreReg d0
    //     0x685108: ldr             q0, [SP], #0x10
    // 0x68510c: b               #0x685088
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0x6bbdd4, size: 0x94
    // 0x6bbdd4: EnterFrame
    //     0x6bbdd4: stp             fp, lr, [SP, #-0x10]!
    //     0x6bbdd8: mov             fp, SP
    // 0x6bbddc: AllocStack(0x8)
    //     0x6bbddc: sub             SP, SP, #8
    // 0x6bbde0: CheckStackOverflow
    //     0x6bbde0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bbde4: cmp             SP, x16
    //     0x6bbde8: b.ls            #0x6bbe5c
    // 0x6bbdec: ldr             x0, [fp, #0x18]
    // 0x6bbdf0: LoadField: r3 = r0->field_17
    //     0x6bbdf0: ldur            w3, [x0, #0x17]
    // 0x6bbdf4: DecompressPointer r3
    //     0x6bbdf4: add             x3, x3, HEAP, lsl #32
    // 0x6bbdf8: stur            x3, [fp, #-8]
    // 0x6bbdfc: cmp             w3, NULL
    // 0x6bbe00: b.eq            #0x6bbe64
    // 0x6bbe04: mov             x0, x3
    // 0x6bbe08: r2 = Null
    //     0x6bbe08: mov             x2, NULL
    // 0x6bbe0c: r1 = Null
    //     0x6bbe0c: mov             x1, NULL
    // 0x6bbe10: r4 = LoadClassIdInstr(r0)
    //     0x6bbe10: ldur            x4, [x0, #-1]
    //     0x6bbe14: ubfx            x4, x4, #0xc, #0x14
    // 0x6bbe18: sub             x4, x4, #0x7f3
    // 0x6bbe1c: cmp             x4, #2
    // 0x6bbe20: b.ls            #0x6bbe38
    // 0x6bbe24: r8 = SliverPhysicalParentData
    //     0x6bbe24: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5e0] Type: SliverPhysicalParentData
    //     0x6bbe28: ldr             x8, [x8, #0x5e0]
    // 0x6bbe2c: r3 = Null
    //     0x6bbe2c: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c198] Null
    //     0x6bbe30: ldr             x3, [x3, #0x198]
    // 0x6bbe34: r0 = DefaultTypeTest()
    //     0x6bbe34: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6bbe38: ldur            x16, [fp, #-8]
    // 0x6bbe3c: ldr             lr, [fp, #0x10]
    // 0x6bbe40: stp             lr, x16, [SP, #-0x10]!
    // 0x6bbe44: r0 = applyPaintTransform()
    //     0x6bbe44: bl              #0x62adac  ; [package:flutter/src/rendering/sliver.dart] SliverPhysicalParentData::applyPaintTransform
    // 0x6bbe48: add             SP, SP, #0x10
    // 0x6bbe4c: r0 = Null
    //     0x6bbe4c: mov             x0, NULL
    // 0x6bbe50: LeaveFrame
    //     0x6bbe50: mov             SP, fp
    //     0x6bbe54: ldp             fp, lr, [SP], #0x10
    // 0x6bbe58: ret
    //     0x6bbe58: ret             
    // 0x6bbe5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bbe5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bbe60: b               #0x6bbdec
    // 0x6bbe64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6bbe64: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ childScrollOffset(/* No info */) {
    // ** addr: 0xa82dec, size: 0x38
    // 0xa82dec: EnterFrame
    //     0xa82dec: stp             fp, lr, [SP, #-0x10]!
    //     0xa82df0: mov             fp, SP
    // 0xa82df4: CheckStackOverflow
    //     0xa82df4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa82df8: cmp             SP, x16
    //     0xa82dfc: b.ls            #0xa82e1c
    // 0xa82e00: ldr             x16, [fp, #0x18]
    // 0xa82e04: SaveReg r16
    //     0xa82e04: str             x16, [SP, #-8]!
    // 0xa82e08: r0 = beforePadding()
    //     0xa82e08: bl              #0x684dd0  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverEdgeInsetsPadding::beforePadding
    // 0xa82e0c: add             SP, SP, #8
    // 0xa82e10: LeaveFrame
    //     0xa82e10: mov             SP, fp
    //     0xa82e14: ldp             fp, lr, [SP], #0x10
    // 0xa82e18: ret
    //     0xa82e18: ret             
    // 0xa82e1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa82e1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa82e20: b               #0xa82e00
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0xa8bc90, size: 0x1c4
    // 0xa8bc90: EnterFrame
    //     0xa8bc90: stp             fp, lr, [SP, #-0x10]!
    //     0xa8bc94: mov             fp, SP
    // 0xa8bc98: AllocStack(0x20)
    //     0xa8bc98: sub             SP, SP, #0x20
    // 0xa8bc9c: CheckStackOverflow
    //     0xa8bc9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8bca0: cmp             SP, x16
    //     0xa8bca4: b.ls            #0xa8be20
    // 0xa8bca8: ldr             x3, [fp, #0x28]
    // 0xa8bcac: LoadField: r4 = r3->field_53
    //     0xa8bcac: ldur            w4, [x3, #0x53]
    // 0xa8bcb0: DecompressPointer r4
    //     0xa8bcb0: add             x4, x4, HEAP, lsl #32
    // 0xa8bcb4: stur            x4, [fp, #-0x10]
    // 0xa8bcb8: cmp             w4, NULL
    // 0xa8bcbc: b.eq            #0xa8be10
    // 0xa8bcc0: d0 = 0.000000
    //     0xa8bcc0: eor             v0.16b, v0.16b, v0.16b
    // 0xa8bcc4: LoadField: r0 = r4->field_4f
    //     0xa8bcc4: ldur            w0, [x4, #0x4f]
    // 0xa8bcc8: DecompressPointer r0
    //     0xa8bcc8: add             x0, x0, HEAP, lsl #32
    // 0xa8bccc: cmp             w0, NULL
    // 0xa8bcd0: b.eq            #0xa8be28
    // 0xa8bcd4: LoadField: d1 = r0->field_37
    //     0xa8bcd4: ldur            d1, [x0, #0x37]
    // 0xa8bcd8: fcmp            d1, d0
    // 0xa8bcdc: b.vs            #0xa8be10
    // 0xa8bce0: b.le            #0xa8be10
    // 0xa8bce4: ldr             d0, [fp, #0x10]
    // 0xa8bce8: LoadField: r5 = r4->field_17
    //     0xa8bce8: ldur            w5, [x4, #0x17]
    // 0xa8bcec: DecompressPointer r5
    //     0xa8bcec: add             x5, x5, HEAP, lsl #32
    // 0xa8bcf0: stur            x5, [fp, #-8]
    // 0xa8bcf4: cmp             w5, NULL
    // 0xa8bcf8: b.eq            #0xa8be2c
    // 0xa8bcfc: mov             x0, x5
    // 0xa8bd00: r2 = Null
    //     0xa8bd00: mov             x2, NULL
    // 0xa8bd04: r1 = Null
    //     0xa8bd04: mov             x1, NULL
    // 0xa8bd08: r4 = LoadClassIdInstr(r0)
    //     0xa8bd08: ldur            x4, [x0, #-1]
    //     0xa8bd0c: ubfx            x4, x4, #0xc, #0x14
    // 0xa8bd10: sub             x4, x4, #0x7f3
    // 0xa8bd14: cmp             x4, #2
    // 0xa8bd18: b.ls            #0xa8bd30
    // 0xa8bd1c: r8 = SliverPhysicalParentData
    //     0xa8bd1c: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5e0] Type: SliverPhysicalParentData
    //     0xa8bd20: ldr             x8, [x8, #0x5e0]
    // 0xa8bd24: r3 = Null
    //     0xa8bd24: add             x3, PP, #0x51, lsl #12  ; [pp+0x51258] Null
    //     0xa8bd28: ldr             x3, [x3, #0x258]
    // 0xa8bd2c: r0 = DefaultTypeTest()
    //     0xa8bd2c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa8bd30: ldr             x16, [fp, #0x28]
    // 0xa8bd34: ldur            lr, [fp, #-0x10]
    // 0xa8bd38: stp             lr, x16, [SP, #-0x10]!
    // 0xa8bd3c: r0 = childMainAxisPosition()
    //     0xa8bd3c: bl              #0xbcdd5c  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverEdgeInsetsPadding::childMainAxisPosition
    // 0xa8bd40: add             SP, SP, #0x10
    // 0xa8bd44: ldr             x0, [fp, #0x28]
    // 0xa8bd48: stur            d0, [fp, #-0x20]
    // 0xa8bd4c: LoadField: r1 = r0->field_53
    //     0xa8bd4c: ldur            w1, [x0, #0x53]
    // 0xa8bd50: DecompressPointer r1
    //     0xa8bd50: add             x1, x1, HEAP, lsl #32
    // 0xa8bd54: cmp             w1, NULL
    // 0xa8bd58: b.eq            #0xa8be30
    // 0xa8bd5c: stp             x1, x0, [SP, #-0x10]!
    // 0xa8bd60: r0 = childCrossAxisPosition()
    //     0xa8bd60: bl              #0xb13704  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverEdgeInsetsPadding::childCrossAxisPosition
    // 0xa8bd64: add             SP, SP, #0x10
    // 0xa8bd68: mov             x1, x0
    // 0xa8bd6c: ldur            x0, [fp, #-8]
    // 0xa8bd70: stur            x1, [fp, #-0x18]
    // 0xa8bd74: LoadField: r2 = r0->field_7
    //     0xa8bd74: ldur            w2, [x0, #7]
    // 0xa8bd78: DecompressPointer r2
    //     0xa8bd78: add             x2, x2, HEAP, lsl #32
    // 0xa8bd7c: ldr             x0, [fp, #0x28]
    // 0xa8bd80: stur            x2, [fp, #-0x10]
    // 0xa8bd84: LoadField: r3 = r0->field_53
    //     0xa8bd84: ldur            w3, [x0, #0x53]
    // 0xa8bd88: DecompressPointer r3
    //     0xa8bd88: add             x3, x3, HEAP, lsl #32
    // 0xa8bd8c: cmp             w3, NULL
    // 0xa8bd90: b.eq            #0xa8be34
    // 0xa8bd94: r0 = LoadClassIdInstr(r3)
    //     0xa8bd94: ldur            x0, [x3, #-1]
    //     0xa8bd98: ubfx            x0, x0, #0xc, #0x14
    // 0xa8bd9c: SaveReg r3
    //     0xa8bd9c: str             x3, [SP, #-8]!
    // 0xa8bda0: r0 = GDT[cid_x0 + 0x4e7a]()
    //     0xa8bda0: mov             x17, #0x4e7a
    //     0xa8bda4: add             lr, x0, x17
    //     0xa8bda8: ldr             lr, [x21, lr, lsl #3]
    //     0xa8bdac: blr             lr
    // 0xa8bdb0: add             SP, SP, #8
    // 0xa8bdb4: ldur            d0, [fp, #-0x20]
    // 0xa8bdb8: r1 = inline_Allocate_Double()
    //     0xa8bdb8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xa8bdbc: add             x1, x1, #0x10
    //     0xa8bdc0: cmp             x2, x1
    //     0xa8bdc4: b.ls            #0xa8be38
    //     0xa8bdc8: str             x1, [THR, #0x60]  ; THR::top
    //     0xa8bdcc: sub             x1, x1, #0xf
    //     0xa8bdd0: mov             x2, #0xd108
    //     0xa8bdd4: movk            x2, #3, lsl #16
    //     0xa8bdd8: stur            x2, [x1, #-1]
    // 0xa8bddc: StoreField: r1->field_7 = d0
    //     0xa8bddc: stur            d0, [x1, #7]
    // 0xa8bde0: ldr             x16, [fp, #0x20]
    // 0xa8bde4: ldur            lr, [fp, #-0x18]
    // 0xa8bde8: stp             lr, x16, [SP, #-0x10]!
    // 0xa8bdec: ldr             x16, [fp, #0x18]
    // 0xa8bdf0: stp             x0, x16, [SP, #-0x10]!
    // 0xa8bdf4: SaveReg r1
    //     0xa8bdf4: str             x1, [SP, #-8]!
    // 0xa8bdf8: ldr             d0, [fp, #0x10]
    // 0xa8bdfc: SaveReg d0
    //     0xa8bdfc: str             d0, [SP, #-8]!
    // 0xa8be00: ldur            x16, [fp, #-0x10]
    // 0xa8be04: SaveReg r16
    //     0xa8be04: str             x16, [SP, #-8]!
    // 0xa8be08: r0 = addWithAxisOffset()
    //     0xa8be08: bl              #0xa8be54  ; [package:flutter/src/rendering/sliver.dart] SliverHitTestResult::addWithAxisOffset
    // 0xa8be0c: add             SP, SP, #0x38
    // 0xa8be10: r0 = false
    //     0xa8be10: add             x0, NULL, #0x30  ; false
    // 0xa8be14: LeaveFrame
    //     0xa8be14: mov             SP, fp
    //     0xa8be18: ldp             fp, lr, [SP], #0x10
    // 0xa8be1c: ret
    //     0xa8be1c: ret             
    // 0xa8be20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8be20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8be24: b               #0xa8bca8
    // 0xa8be28: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa8be28: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa8be2c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa8be2c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa8be30: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa8be30: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa8be34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa8be34: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa8be38: SaveReg d0
    //     0xa8be38: str             q0, [SP, #-0x10]!
    // 0xa8be3c: SaveReg r0
    //     0xa8be3c: str             x0, [SP, #-8]!
    // 0xa8be40: r0 = AllocateDouble()
    //     0xa8be40: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa8be44: mov             x1, x0
    // 0xa8be48: RestoreReg r0
    //     0xa8be48: ldr             x0, [SP], #8
    // 0xa8be4c: RestoreReg d0
    //     0xa8be4c: ldr             q0, [SP], #0x10
    // 0xa8be50: b               #0xa8bddc
  }
  _ childCrossAxisPosition(/* No info */) {
    // ** addr: 0xb13704, size: 0x214
    // 0xb13704: EnterFrame
    //     0xb13704: stp             fp, lr, [SP, #-0x10]!
    //     0xb13708: mov             fp, SP
    // 0xb1370c: AllocStack(0x8)
    //     0xb1370c: sub             SP, SP, #8
    // 0xb13710: CheckStackOverflow
    //     0xb13710: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb13714: cmp             SP, x16
    //     0xb13718: b.ls            #0xb138e8
    // 0xb1371c: ldr             x3, [fp, #0x18]
    // 0xb13720: LoadField: r4 = r3->field_27
    //     0xb13720: ldur            w4, [x3, #0x27]
    // 0xb13724: DecompressPointer r4
    //     0xb13724: add             x4, x4, HEAP, lsl #32
    // 0xb13728: stur            x4, [fp, #-8]
    // 0xb1372c: cmp             w4, NULL
    // 0xb13730: b.eq            #0xb138c8
    // 0xb13734: mov             x0, x4
    // 0xb13738: r2 = Null
    //     0xb13738: mov             x2, NULL
    // 0xb1373c: r1 = Null
    //     0xb1373c: mov             x1, NULL
    // 0xb13740: r4 = LoadClassIdInstr(r0)
    //     0xb13740: ldur            x4, [x0, #-1]
    //     0xb13744: ubfx            x4, x4, #0xc, #0x14
    // 0xb13748: cmp             x4, #0x80c
    // 0xb1374c: b.eq            #0xb13764
    // 0xb13750: r8 = SliverConstraints
    //     0xb13750: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0xb13754: ldr             x8, [x8, #0x5a8]
    // 0xb13758: r3 = Null
    //     0xb13758: add             x3, PP, #0x51, lsl #12  ; [pp+0x51248] Null
    //     0xb1375c: ldr             x3, [x3, #0x248]
    // 0xb13760: r0 = DefaultTypeTest()
    //     0xb13760: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xb13764: ldur            x0, [fp, #-8]
    // 0xb13768: LoadField: r1 = r0->field_7
    //     0xb13768: ldur            w1, [x0, #7]
    // 0xb1376c: DecompressPointer r1
    //     0xb1376c: add             x1, x1, HEAP, lsl #32
    // 0xb13770: LoadField: r2 = r0->field_b
    //     0xb13770: ldur            w2, [x0, #0xb]
    // 0xb13774: DecompressPointer r2
    //     0xb13774: add             x2, x2, HEAP, lsl #32
    // 0xb13778: stp             x2, x1, [SP, #-0x10]!
    // 0xb1377c: r0 = applyGrowthDirectionToAxisDirection()
    //     0xb1377c: bl              #0x643194  ; [package:flutter/src/rendering/sliver.dart] ::applyGrowthDirectionToAxisDirection
    // 0xb13780: add             SP, SP, #0x10
    // 0xb13784: LoadField: r1 = r0->field_7
    //     0xb13784: ldur            x1, [x0, #7]
    // 0xb13788: cmp             x1, #1
    // 0xb1378c: b.gt            #0xb137a0
    // 0xb13790: cmp             x1, #0
    // 0xb13794: b.le            #0xb137a8
    // 0xb13798: ldr             x1, [fp, #0x18]
    // 0xb1379c: b               #0xb13838
    // 0xb137a0: cmp             x1, #2
    // 0xb137a4: b.gt            #0xb13834
    // 0xb137a8: ldr             x1, [fp, #0x18]
    // 0xb137ac: r2 = LoadClassIdInstr(r1)
    //     0xb137ac: ldur            x2, [x1, #-1]
    //     0xb137b0: ubfx            x2, x2, #0xc, #0x14
    // 0xb137b4: lsl             x2, x2, #1
    // 0xb137b8: r17 = 5154
    //     0xb137b8: mov             x17, #0x1422
    // 0xb137bc: cmp             w2, w17
    // 0xb137c0: b.ne            #0xb137d4
    // 0xb137c4: LoadField: r3 = r1->field_63
    //     0xb137c4: ldur            w3, [x1, #0x63]
    // 0xb137c8: DecompressPointer r3
    //     0xb137c8: add             x3, x3, HEAP, lsl #32
    // 0xb137cc: mov             x2, x3
    // 0xb137d0: b               #0xb137f4
    // 0xb137d4: r17 = 5156
    //     0xb137d4: mov             x17, #0x1424
    // 0xb137d8: cmp             w2, w17
    // 0xb137dc: b.ne            #0xb137ec
    // 0xb137e0: LoadField: r2 = r1->field_57
    //     0xb137e0: ldur            w2, [x1, #0x57]
    // 0xb137e4: DecompressPointer r2
    //     0xb137e4: add             x2, x2, HEAP, lsl #32
    // 0xb137e8: b               #0xb137f4
    // 0xb137ec: LoadField: r2 = r1->field_63
    //     0xb137ec: ldur            w2, [x1, #0x63]
    // 0xb137f0: DecompressPointer r2
    //     0xb137f0: add             x2, x2, HEAP, lsl #32
    // 0xb137f4: cmp             w2, NULL
    // 0xb137f8: b.eq            #0xb138f0
    // 0xb137fc: LoadField: d0 = r2->field_7
    //     0xb137fc: ldur            d0, [x2, #7]
    // 0xb13800: r0 = inline_Allocate_Double()
    //     0xb13800: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xb13804: add             x0, x0, #0x10
    //     0xb13808: cmp             x2, x0
    //     0xb1380c: b.ls            #0xb138f4
    //     0xb13810: str             x0, [THR, #0x60]  ; THR::top
    //     0xb13814: sub             x0, x0, #0xf
    //     0xb13818: mov             x2, #0xd108
    //     0xb1381c: movk            x2, #3, lsl #16
    //     0xb13820: stur            x2, [x0, #-1]
    // 0xb13824: StoreField: r0->field_7 = d0
    //     0xb13824: stur            d0, [x0, #7]
    // 0xb13828: LeaveFrame
    //     0xb13828: mov             SP, fp
    //     0xb1382c: ldp             fp, lr, [SP], #0x10
    // 0xb13830: ret
    //     0xb13830: ret             
    // 0xb13834: ldr             x1, [fp, #0x18]
    // 0xb13838: r2 = LoadClassIdInstr(r1)
    //     0xb13838: ldur            x2, [x1, #-1]
    //     0xb1383c: ubfx            x2, x2, #0xc, #0x14
    // 0xb13840: lsl             x2, x2, #1
    // 0xb13844: r17 = 5154
    //     0xb13844: mov             x17, #0x1422
    // 0xb13848: cmp             w2, w17
    // 0xb1384c: b.ne            #0xb13860
    // 0xb13850: LoadField: r3 = r1->field_63
    //     0xb13850: ldur            w3, [x1, #0x63]
    // 0xb13854: DecompressPointer r3
    //     0xb13854: add             x3, x3, HEAP, lsl #32
    // 0xb13858: mov             x1, x3
    // 0xb1385c: b               #0xb13888
    // 0xb13860: r17 = 5156
    //     0xb13860: mov             x17, #0x1424
    // 0xb13864: cmp             w2, w17
    // 0xb13868: b.ne            #0xb1387c
    // 0xb1386c: LoadField: r2 = r1->field_57
    //     0xb1386c: ldur            w2, [x1, #0x57]
    // 0xb13870: DecompressPointer r2
    //     0xb13870: add             x2, x2, HEAP, lsl #32
    // 0xb13874: mov             x1, x2
    // 0xb13878: b               #0xb13888
    // 0xb1387c: LoadField: r2 = r1->field_63
    //     0xb1387c: ldur            w2, [x1, #0x63]
    // 0xb13880: DecompressPointer r2
    //     0xb13880: add             x2, x2, HEAP, lsl #32
    // 0xb13884: mov             x1, x2
    // 0xb13888: cmp             w1, NULL
    // 0xb1388c: b.eq            #0xb13904
    // 0xb13890: LoadField: d0 = r1->field_f
    //     0xb13890: ldur            d0, [x1, #0xf]
    // 0xb13894: r0 = inline_Allocate_Double()
    //     0xb13894: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb13898: add             x0, x0, #0x10
    //     0xb1389c: cmp             x1, x0
    //     0xb138a0: b.ls            #0xb13908
    //     0xb138a4: str             x0, [THR, #0x60]  ; THR::top
    //     0xb138a8: sub             x0, x0, #0xf
    //     0xb138ac: mov             x1, #0xd108
    //     0xb138b0: movk            x1, #3, lsl #16
    //     0xb138b4: stur            x1, [x0, #-1]
    // 0xb138b8: StoreField: r0->field_7 = d0
    //     0xb138b8: stur            d0, [x0, #7]
    // 0xb138bc: LeaveFrame
    //     0xb138bc: mov             SP, fp
    //     0xb138c0: ldp             fp, lr, [SP], #0x10
    // 0xb138c4: ret
    //     0xb138c4: ret             
    // 0xb138c8: r0 = StateError()
    //     0xb138c8: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xb138cc: mov             x1, x0
    // 0xb138d0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xb138d0: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0xb138d4: ldr             x0, [x0, #0x1e8]
    // 0xb138d8: StoreField: r1->field_b = r0
    //     0xb138d8: stur            w0, [x1, #0xb]
    // 0xb138dc: mov             x0, x1
    // 0xb138e0: r0 = Throw()
    //     0xb138e0: bl              #0xd67e38  ; ThrowStub
    // 0xb138e4: brk             #0
    // 0xb138e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb138e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb138ec: b               #0xb1371c
    // 0xb138f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb138f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb138f4: SaveReg d0
    //     0xb138f4: str             q0, [SP, #-0x10]!
    // 0xb138f8: r0 = AllocateDouble()
    //     0xb138f8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb138fc: RestoreReg d0
    //     0xb138fc: ldr             q0, [SP], #0x10
    // 0xb13900: b               #0xb13824
    // 0xb13904: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb13904: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb13908: SaveReg d0
    //     0xb13908: str             q0, [SP, #-0x10]!
    // 0xb1390c: r0 = AllocateDouble()
    //     0xb1390c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb13910: RestoreReg d0
    //     0xb13910: ldr             q0, [SP], #0x10
    // 0xb13914: b               #0xb138b8
  }
  _ childMainAxisPosition(/* No info */) {
    // ** addr: 0xbcdd5c, size: 0xbc
    // 0xbcdd5c: EnterFrame
    //     0xbcdd5c: stp             fp, lr, [SP, #-0x10]!
    //     0xbcdd60: mov             fp, SP
    // 0xbcdd64: AllocStack(0x8)
    //     0xbcdd64: sub             SP, SP, #8
    // 0xbcdd68: CheckStackOverflow
    //     0xbcdd68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbcdd6c: cmp             SP, x16
    //     0xbcdd70: b.ls            #0xbcde10
    // 0xbcdd74: ldr             x3, [fp, #0x18]
    // 0xbcdd78: LoadField: r4 = r3->field_27
    //     0xbcdd78: ldur            w4, [x3, #0x27]
    // 0xbcdd7c: DecompressPointer r4
    //     0xbcdd7c: add             x4, x4, HEAP, lsl #32
    // 0xbcdd80: stur            x4, [fp, #-8]
    // 0xbcdd84: cmp             w4, NULL
    // 0xbcdd88: b.eq            #0xbcddf0
    // 0xbcdd8c: mov             x0, x4
    // 0xbcdd90: r2 = Null
    //     0xbcdd90: mov             x2, NULL
    // 0xbcdd94: r1 = Null
    //     0xbcdd94: mov             x1, NULL
    // 0xbcdd98: r4 = LoadClassIdInstr(r0)
    //     0xbcdd98: ldur            x4, [x0, #-1]
    //     0xbcdd9c: ubfx            x4, x4, #0xc, #0x14
    // 0xbcdda0: cmp             x4, #0x80c
    // 0xbcdda4: b.eq            #0xbcddbc
    // 0xbcdda8: r8 = SliverConstraints
    //     0xbcdda8: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0xbcddac: ldr             x8, [x8, #0x5a8]
    // 0xbcddb0: r3 = Null
    //     0xbcddb0: add             x3, PP, #0x51, lsl #12  ; [pp+0x51268] Null
    //     0xbcddb4: ldr             x3, [x3, #0x268]
    // 0xbcddb8: r0 = DefaultTypeTest()
    //     0xbcddb8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xbcddbc: ldr             x16, [fp, #0x18]
    // 0xbcddc0: SaveReg r16
    //     0xbcddc0: str             x16, [SP, #-8]!
    // 0xbcddc4: r0 = beforePadding()
    //     0xbcddc4: bl              #0x684dd0  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverEdgeInsetsPadding::beforePadding
    // 0xbcddc8: add             SP, SP, #8
    // 0xbcddcc: ldr             x16, [fp, #0x18]
    // 0xbcddd0: ldur            lr, [fp, #-8]
    // 0xbcddd4: stp             lr, x16, [SP, #-0x10]!
    // 0xbcddd8: stp             x0, xzr, [SP, #-0x10]!
    // 0xbcdddc: r0 = calculatePaintOffset()
    //     0xbcdddc: bl              #0x677ba0  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0xbcdde0: add             SP, SP, #0x20
    // 0xbcdde4: LeaveFrame
    //     0xbcdde4: mov             SP, fp
    //     0xbcdde8: ldp             fp, lr, [SP], #0x10
    // 0xbcddec: ret
    //     0xbcddec: ret             
    // 0xbcddf0: r0 = StateError()
    //     0xbcddf0: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbcddf4: mov             x1, x0
    // 0xbcddf8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbcddf8: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0xbcddfc: ldr             x0, [x0, #0x1e8]
    // 0xbcde00: StoreField: r1->field_b = r0
    //     0xbcde00: stur            w0, [x1, #0xb]
    // 0xbcde04: mov             x0, x1
    // 0xbcde08: r0 = Throw()
    //     0xbcde08: bl              #0xd67e38  ; ThrowStub
    // 0xbcde0c: brk             #0
    // 0xbcde10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbcde10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbcde14: b               #0xbcdd74
  }
}

// class id: 2578, size: 0x64, field offset: 0x58
class RenderSliverPadding extends RenderSliverEdgeInsetsPadding {

  _ performLayout(/* No info */) {
    // ** addr: 0x685348, size: 0x4c
    // 0x685348: EnterFrame
    //     0x685348: stp             fp, lr, [SP, #-0x10]!
    //     0x68534c: mov             fp, SP
    // 0x685350: CheckStackOverflow
    //     0x685350: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x685354: cmp             SP, x16
    //     0x685358: b.ls            #0x68538c
    // 0x68535c: ldr             x16, [fp, #0x10]
    // 0x685360: SaveReg r16
    //     0x685360: str             x16, [SP, #-8]!
    // 0x685364: r0 = _resolve()
    //     0x685364: bl              #0x685394  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverPadding::_resolve
    // 0x685368: add             SP, SP, #8
    // 0x68536c: ldr             x16, [fp, #0x10]
    // 0x685370: SaveReg r16
    //     0x685370: str             x16, [SP, #-8]!
    // 0x685374: r0 = performLayout()
    //     0x685374: bl              #0x682c74  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverEdgeInsetsPadding::performLayout
    // 0x685378: add             SP, SP, #8
    // 0x68537c: r0 = Null
    //     0x68537c: mov             x0, NULL
    // 0x685380: LeaveFrame
    //     0x685380: mov             SP, fp
    //     0x685384: ldp             fp, lr, [SP], #0x10
    // 0x685388: ret
    //     0x685388: ret             
    // 0x68538c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68538c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x685390: b               #0x68535c
  }
  _ _resolve(/* No info */) {
    // ** addr: 0x685394, size: 0xb8
    // 0x685394: EnterFrame
    //     0x685394: stp             fp, lr, [SP, #-0x10]!
    //     0x685398: mov             fp, SP
    // 0x68539c: CheckStackOverflow
    //     0x68539c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6853a0: cmp             SP, x16
    //     0x6853a4: b.ls            #0x685444
    // 0x6853a8: ldr             x1, [fp, #0x10]
    // 0x6853ac: LoadField: r0 = r1->field_57
    //     0x6853ac: ldur            w0, [x1, #0x57]
    // 0x6853b0: DecompressPointer r0
    //     0x6853b0: add             x0, x0, HEAP, lsl #32
    // 0x6853b4: cmp             w0, NULL
    // 0x6853b8: b.eq            #0x6853cc
    // 0x6853bc: r0 = Null
    //     0x6853bc: mov             x0, NULL
    // 0x6853c0: LeaveFrame
    //     0x6853c0: mov             SP, fp
    //     0x6853c4: ldp             fp, lr, [SP], #0x10
    // 0x6853c8: ret
    //     0x6853c8: ret             
    // 0x6853cc: LoadField: r0 = r1->field_5b
    //     0x6853cc: ldur            w0, [x1, #0x5b]
    // 0x6853d0: DecompressPointer r0
    //     0x6853d0: add             x0, x0, HEAP, lsl #32
    // 0x6853d4: LoadField: r2 = r1->field_5f
    //     0x6853d4: ldur            w2, [x1, #0x5f]
    // 0x6853d8: DecompressPointer r2
    //     0x6853d8: add             x2, x2, HEAP, lsl #32
    // 0x6853dc: r3 = LoadClassIdInstr(r0)
    //     0x6853dc: ldur            x3, [x0, #-1]
    //     0x6853e0: ubfx            x3, x3, #0xc, #0x14
    // 0x6853e4: lsl             x3, x3, #1
    // 0x6853e8: r17 = 4206
    //     0x6853e8: mov             x17, #0x106e
    // 0x6853ec: cmp             w3, w17
    // 0x6853f0: b.eq            #0x685418
    // 0x6853f4: r3 = LoadClassIdInstr(r0)
    //     0x6853f4: ldur            x3, [x0, #-1]
    //     0x6853f8: ubfx            x3, x3, #0xc, #0x14
    // 0x6853fc: stp             x2, x0, [SP, #-0x10]!
    // 0x685400: mov             x0, x3
    // 0x685404: r0 = GDT[cid_x0 + -0xfdb]()
    //     0x685404: sub             lr, x0, #0xfdb
    //     0x685408: ldr             lr, [x21, lr, lsl #3]
    //     0x68540c: blr             lr
    // 0x685410: add             SP, SP, #0x10
    // 0x685414: ldr             x1, [fp, #0x10]
    // 0x685418: StoreField: r1->field_57 = r0
    //     0x685418: stur            w0, [x1, #0x57]
    //     0x68541c: ldurb           w16, [x1, #-1]
    //     0x685420: ldurb           w17, [x0, #-1]
    //     0x685424: and             x16, x17, x16, lsr #2
    //     0x685428: tst             x16, HEAP, lsr #32
    //     0x68542c: b.eq            #0x685434
    //     0x685430: bl              #0xd6826c
    // 0x685434: r0 = Null
    //     0x685434: mov             x0, NULL
    // 0x685438: LeaveFrame
    //     0x685438: mov             SP, fp
    //     0x68543c: ldp             fp, lr, [SP], #0x10
    // 0x685440: ret
    //     0x685440: ret             
    // 0x685444: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x685444: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x685448: b               #0x6853a8
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0x6c6640, size: 0x80
    // 0x6c6640: EnterFrame
    //     0x6c6640: stp             fp, lr, [SP, #-0x10]!
    //     0x6c6644: mov             fp, SP
    // 0x6c6648: CheckStackOverflow
    //     0x6c6648: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c664c: cmp             SP, x16
    //     0x6c6650: b.ls            #0x6c66b8
    // 0x6c6654: ldr             x1, [fp, #0x18]
    // 0x6c6658: LoadField: r0 = r1->field_5f
    //     0x6c6658: ldur            w0, [x1, #0x5f]
    // 0x6c665c: DecompressPointer r0
    //     0x6c665c: add             x0, x0, HEAP, lsl #32
    // 0x6c6660: ldr             x2, [fp, #0x10]
    // 0x6c6664: cmp             w0, w2
    // 0x6c6668: b.ne            #0x6c667c
    // 0x6c666c: r0 = Null
    //     0x6c666c: mov             x0, NULL
    // 0x6c6670: LeaveFrame
    //     0x6c6670: mov             SP, fp
    //     0x6c6674: ldp             fp, lr, [SP], #0x10
    // 0x6c6678: ret
    //     0x6c6678: ret             
    // 0x6c667c: mov             x0, x2
    // 0x6c6680: StoreField: r1->field_5f = r0
    //     0x6c6680: stur            w0, [x1, #0x5f]
    //     0x6c6684: ldurb           w16, [x1, #-1]
    //     0x6c6688: ldurb           w17, [x0, #-1]
    //     0x6c668c: and             x16, x17, x16, lsr #2
    //     0x6c6690: tst             x16, HEAP, lsr #32
    //     0x6c6694: b.eq            #0x6c669c
    //     0x6c6698: bl              #0xd6826c
    // 0x6c669c: SaveReg r1
    //     0x6c669c: str             x1, [SP, #-8]!
    // 0x6c66a0: r0 = _markNeedsResolution()
    //     0x6c66a0: bl              #0x6c66c0  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverPadding::_markNeedsResolution
    // 0x6c66a4: add             SP, SP, #8
    // 0x6c66a8: r0 = Null
    //     0x6c66a8: mov             x0, NULL
    // 0x6c66ac: LeaveFrame
    //     0x6c66ac: mov             SP, fp
    //     0x6c66b0: ldp             fp, lr, [SP], #0x10
    // 0x6c66b4: ret
    //     0x6c66b4: ret             
    // 0x6c66b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c66b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c66bc: b               #0x6c6654
  }
  _ _markNeedsResolution(/* No info */) {
    // ** addr: 0x6c66c0, size: 0x40
    // 0x6c66c0: EnterFrame
    //     0x6c66c0: stp             fp, lr, [SP, #-0x10]!
    //     0x6c66c4: mov             fp, SP
    // 0x6c66c8: CheckStackOverflow
    //     0x6c66c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c66cc: cmp             SP, x16
    //     0x6c66d0: b.ls            #0x6c66f8
    // 0x6c66d4: ldr             x0, [fp, #0x10]
    // 0x6c66d8: StoreField: r0->field_57 = rNULL
    //     0x6c66d8: stur            NULL, [x0, #0x57]
    // 0x6c66dc: SaveReg r0
    //     0x6c66dc: str             x0, [SP, #-8]!
    // 0x6c66e0: r0 = markNeedsLayout()
    //     0x6c66e0: bl              #0x6c0ee8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsLayout
    // 0x6c66e4: add             SP, SP, #8
    // 0x6c66e8: r0 = Null
    //     0x6c66e8: mov             x0, NULL
    // 0x6c66ec: LeaveFrame
    //     0x6c66ec: mov             SP, fp
    //     0x6c66f0: ldp             fp, lr, [SP], #0x10
    // 0x6c66f4: ret
    //     0x6c66f4: ret             
    // 0x6c66f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c66f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c66fc: b               #0x6c66d4
  }
  set _ padding=(/* No info */) {
    // ** addr: 0x6c6700, size: 0x8c
    // 0x6c6700: EnterFrame
    //     0x6c6700: stp             fp, lr, [SP, #-0x10]!
    //     0x6c6704: mov             fp, SP
    // 0x6c6708: CheckStackOverflow
    //     0x6c6708: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c670c: cmp             SP, x16
    //     0x6c6710: b.ls            #0x6c6784
    // 0x6c6714: ldr             x0, [fp, #0x18]
    // 0x6c6718: LoadField: r1 = r0->field_5b
    //     0x6c6718: ldur            w1, [x0, #0x5b]
    // 0x6c671c: DecompressPointer r1
    //     0x6c671c: add             x1, x1, HEAP, lsl #32
    // 0x6c6720: ldr             x16, [fp, #0x10]
    // 0x6c6724: stp             x16, x1, [SP, #-0x10]!
    // 0x6c6728: r0 = ==()
    //     0x6c6728: bl              #0xc9d2f4  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::==
    // 0x6c672c: add             SP, SP, #0x10
    // 0x6c6730: tbnz            w0, #4, #0x6c6744
    // 0x6c6734: r0 = Null
    //     0x6c6734: mov             x0, NULL
    // 0x6c6738: LeaveFrame
    //     0x6c6738: mov             SP, fp
    //     0x6c673c: ldp             fp, lr, [SP], #0x10
    // 0x6c6740: ret
    //     0x6c6740: ret             
    // 0x6c6744: ldr             x1, [fp, #0x18]
    // 0x6c6748: ldr             x0, [fp, #0x10]
    // 0x6c674c: StoreField: r1->field_5b = r0
    //     0x6c674c: stur            w0, [x1, #0x5b]
    //     0x6c6750: ldurb           w16, [x1, #-1]
    //     0x6c6754: ldurb           w17, [x0, #-1]
    //     0x6c6758: and             x16, x17, x16, lsr #2
    //     0x6c675c: tst             x16, HEAP, lsr #32
    //     0x6c6760: b.eq            #0x6c6768
    //     0x6c6764: bl              #0xd6826c
    // 0x6c6768: SaveReg r1
    //     0x6c6768: str             x1, [SP, #-8]!
    // 0x6c676c: r0 = _markNeedsResolution()
    //     0x6c676c: bl              #0x6c66c0  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverPadding::_markNeedsResolution
    // 0x6c6770: add             SP, SP, #8
    // 0x6c6774: r0 = Null
    //     0x6c6774: mov             x0, NULL
    // 0x6c6778: LeaveFrame
    //     0x6c6778: mov             SP, fp
    //     0x6c677c: ldp             fp, lr, [SP], #0x10
    // 0x6c6780: ret
    //     0x6c6780: ret             
    // 0x6c6784: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c6784: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c6788: b               #0x6c6714
  }
}

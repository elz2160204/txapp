// lib: , url: package:flutter/src/rendering/animated_size.dart

// class id: 1049393, size: 0x8
class :: {
}

// class id: 2469, size: 0x94, field offset: 0x70
class RenderAnimatedSize extends RenderAligningShiftedBox {

  late final AnimationController _controller; // offset: 0x70
  late final CurvedAnimation _animation; // offset: 0x74
  late bool _hasVisualOverflow; // offset: 0x7c

  _ dispose(/* No info */) {
    // ** addr: 0x652dac, size: 0x54
    // 0x652dac: EnterFrame
    //     0x652dac: stp             fp, lr, [SP, #-0x10]!
    //     0x652db0: mov             fp, SP
    // 0x652db4: CheckStackOverflow
    //     0x652db4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x652db8: cmp             SP, x16
    //     0x652dbc: b.ls            #0x652df8
    // 0x652dc0: ldr             x0, [fp, #0x10]
    // 0x652dc4: LoadField: r1 = r0->field_8f
    //     0x652dc4: ldur            w1, [x0, #0x8f]
    // 0x652dc8: DecompressPointer r1
    //     0x652dc8: add             x1, x1, HEAP, lsl #32
    // 0x652dcc: stp             NULL, x1, [SP, #-0x10]!
    // 0x652dd0: r0 = layer=()
    //     0x652dd0: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x652dd4: add             SP, SP, #0x10
    // 0x652dd8: ldr             x16, [fp, #0x10]
    // 0x652ddc: SaveReg r16
    //     0x652ddc: str             x16, [SP, #-8]!
    // 0x652de0: r0 = dispose()
    //     0x652de0: bl              #0x65378c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0x652de4: add             SP, SP, #8
    // 0x652de8: r0 = Null
    //     0x652de8: mov             x0, NULL
    // 0x652dec: LeaveFrame
    //     0x652dec: mov             SP, fp
    //     0x652df0: ldp             fp, lr, [SP], #0x10
    // 0x652df4: ret
    //     0x652df4: ret             
    // 0x652df8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x652df8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x652dfc: b               #0x652dc0
  }
  _ paint(/* No info */) {
    // ** addr: 0x669814, size: 0x170
    // 0x669814: EnterFrame
    //     0x669814: stp             fp, lr, [SP, #-0x10]!
    //     0x669818: mov             fp, SP
    // 0x66981c: AllocStack(0x20)
    //     0x66981c: sub             SP, SP, #0x20
    // 0x669820: CheckStackOverflow
    //     0x669820: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x669824: cmp             SP, x16
    //     0x669828: b.ls            #0x669964
    // 0x66982c: ldr             x0, [fp, #0x20]
    // 0x669830: LoadField: r1 = r0->field_5f
    //     0x669830: ldur            w1, [x0, #0x5f]
    // 0x669834: DecompressPointer r1
    //     0x669834: add             x1, x1, HEAP, lsl #32
    // 0x669838: cmp             w1, NULL
    // 0x66983c: b.eq            #0x669924
    // 0x669840: LoadField: r1 = r0->field_7b
    //     0x669840: ldur            w1, [x0, #0x7b]
    // 0x669844: DecompressPointer r1
    //     0x669844: add             x1, x1, HEAP, lsl #32
    // 0x669848: r16 = Sentinel
    //     0x669848: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x66984c: cmp             w1, w16
    // 0x669850: b.eq            #0x66996c
    // 0x669854: tbnz            w1, #4, #0x669924
    // 0x669858: LoadField: r1 = r0->field_57
    //     0x669858: ldur            w1, [x0, #0x57]
    // 0x66985c: DecompressPointer r1
    //     0x66985c: add             x1, x1, HEAP, lsl #32
    // 0x669860: cmp             w1, NULL
    // 0x669864: b.eq            #0x669978
    // 0x669868: r16 = Instance_Offset
    //     0x669868: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x66986c: stp             x1, x16, [SP, #-0x10]!
    // 0x669870: r0 = &()
    //     0x669870: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x669874: add             SP, SP, #0x10
    // 0x669878: mov             x1, x0
    // 0x66987c: ldr             x0, [fp, #0x20]
    // 0x669880: stur            x1, [fp, #-0x18]
    // 0x669884: LoadField: r2 = r0->field_8f
    //     0x669884: ldur            w2, [x0, #0x8f]
    // 0x669888: DecompressPointer r2
    //     0x669888: add             x2, x2, HEAP, lsl #32
    // 0x66988c: stur            x2, [fp, #-0x10]
    // 0x669890: LoadField: r3 = r0->field_37
    //     0x669890: ldur            w3, [x0, #0x37]
    // 0x669894: DecompressPointer r3
    //     0x669894: add             x3, x3, HEAP, lsl #32
    // 0x669898: r16 = Sentinel
    //     0x669898: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x66989c: cmp             w3, w16
    // 0x6698a0: b.eq            #0x66997c
    // 0x6698a4: stur            x3, [fp, #-8]
    // 0x6698a8: r1 = 1
    //     0x6698a8: mov             x1, #1
    // 0x6698ac: r0 = AllocateContext()
    //     0x6698ac: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6698b0: mov             x1, x0
    // 0x6698b4: ldr             x0, [fp, #0x20]
    // 0x6698b8: StoreField: r1->field_f = r0
    //     0x6698b8: stur            w0, [x1, #0xf]
    // 0x6698bc: ldur            x0, [fp, #-0x10]
    // 0x6698c0: LoadField: r3 = r0->field_b
    //     0x6698c0: ldur            w3, [x0, #0xb]
    // 0x6698c4: DecompressPointer r3
    //     0x6698c4: add             x3, x3, HEAP, lsl #32
    // 0x6698c8: mov             x2, x1
    // 0x6698cc: stur            x3, [fp, #-0x20]
    // 0x6698d0: r1 = Function 'paint':.
    //     0x6698d0: add             x1, PP, #0x55, lsl #12  ; [pp+0x55650] AnonymousClosure: (0x669984), in [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::paint (0x669b50)
    //     0x6698d4: ldr             x1, [x1, #0x650]
    // 0x6698d8: r0 = AllocateClosure()
    //     0x6698d8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6698dc: ldr             x16, [fp, #0x18]
    // 0x6698e0: ldur            lr, [fp, #-8]
    // 0x6698e4: stp             lr, x16, [SP, #-0x10]!
    // 0x6698e8: ldr             x16, [fp, #0x10]
    // 0x6698ec: ldur            lr, [fp, #-0x18]
    // 0x6698f0: stp             lr, x16, [SP, #-0x10]!
    // 0x6698f4: r16 = Instance_Clip
    //     0x6698f4: add             x16, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x6698f8: ldr             x16, [x16, #0x678]
    // 0x6698fc: stp             x16, x0, [SP, #-0x10]!
    // 0x669900: ldur            x16, [fp, #-0x20]
    // 0x669904: SaveReg r16
    //     0x669904: str             x16, [SP, #-8]!
    // 0x669908: r0 = pushClipRect()
    //     0x669908: bl              #0x65b240  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRect
    // 0x66990c: add             SP, SP, #0x38
    // 0x669910: ldur            x16, [fp, #-0x10]
    // 0x669914: stp             x0, x16, [SP, #-0x10]!
    // 0x669918: r0 = layer=()
    //     0x669918: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x66991c: add             SP, SP, #0x10
    // 0x669920: b               #0x669954
    // 0x669924: LoadField: r1 = r0->field_8f
    //     0x669924: ldur            w1, [x0, #0x8f]
    // 0x669928: DecompressPointer r1
    //     0x669928: add             x1, x1, HEAP, lsl #32
    // 0x66992c: stp             NULL, x1, [SP, #-0x10]!
    // 0x669930: r0 = layer=()
    //     0x669930: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x669934: add             SP, SP, #0x10
    // 0x669938: ldr             x16, [fp, #0x20]
    // 0x66993c: ldr             lr, [fp, #0x18]
    // 0x669940: stp             lr, x16, [SP, #-0x10]!
    // 0x669944: ldr             x16, [fp, #0x10]
    // 0x669948: SaveReg r16
    //     0x669948: str             x16, [SP, #-8]!
    // 0x66994c: r0 = paint()
    //     0x66994c: bl              #0x669b50  ; [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::paint
    // 0x669950: add             SP, SP, #0x18
    // 0x669954: r0 = Null
    //     0x669954: mov             x0, NULL
    // 0x669958: LeaveFrame
    //     0x669958: mov             SP, fp
    //     0x66995c: ldp             fp, lr, [SP], #0x10
    // 0x669960: ret
    //     0x669960: ret             
    // 0x669964: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x669964: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x669968: b               #0x66982c
    // 0x66996c: r9 = _hasVisualOverflow
    //     0x66996c: add             x9, PP, #0x55, lsl #12  ; [pp+0x55690] Field <RenderAnimatedSize._hasVisualOverflow@890160358>: late (offset: 0x7c)
    //     0x669970: ldr             x9, [x9, #0x690]
    // 0x669974: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x669974: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x669978: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x669978: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x66997c: r9 = _needsCompositing
    //     0x66997c: ldr             x9, [PP, #0x4b28]  ; [pp+0x4b28] Field <RenderObject._needsCompositing@904266271>: late (offset: 0x38)
    // 0x669980: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x669980: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x690fac, size: 0x41c
    // 0x690fac: EnterFrame
    //     0x690fac: stp             fp, lr, [SP, #-0x10]!
    //     0x690fb0: mov             fp, SP
    // 0x690fb4: AllocStack(0x18)
    //     0x690fb4: sub             SP, SP, #0x18
    // 0x690fb8: r1 = false
    //     0x690fb8: add             x1, NULL, #0x30  ; false
    // 0x690fbc: CheckStackOverflow
    //     0x690fbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x690fc0: cmp             SP, x16
    //     0x690fc4: b.ls            #0x691390
    // 0x690fc8: ldr             x3, [fp, #0x10]
    // 0x690fcc: LoadField: r4 = r3->field_6f
    //     0x690fcc: ldur            w4, [x3, #0x6f]
    // 0x690fd0: DecompressPointer r4
    //     0x690fd0: add             x4, x4, HEAP, lsl #32
    // 0x690fd4: r16 = Sentinel
    //     0x690fd4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x690fd8: cmp             w4, w16
    // 0x690fdc: b.eq            #0x691398
    // 0x690fe0: stur            x4, [fp, #-0x10]
    // 0x690fe4: LoadField: r0 = r4->field_37
    //     0x690fe4: ldur            w0, [x4, #0x37]
    // 0x690fe8: DecompressPointer r0
    //     0x690fe8: add             x0, x0, HEAP, lsl #32
    // 0x690fec: r16 = Sentinel
    //     0x690fec: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x690ff0: cmp             w0, w16
    // 0x690ff4: b.eq            #0x6913a4
    // 0x690ff8: StoreField: r3->field_7f = r0
    //     0x690ff8: stur            w0, [x3, #0x7f]
    //     0x690ffc: ldurb           w16, [x3, #-1]
    //     0x691000: ldurb           w17, [x0, #-1]
    //     0x691004: and             x16, x17, x16, lsr #2
    //     0x691008: tst             x16, HEAP, lsr #32
    //     0x69100c: b.eq            #0x691014
    //     0x691010: bl              #0xd682ac
    // 0x691014: StoreField: r3->field_7b = r1
    //     0x691014: stur            w1, [x3, #0x7b]
    // 0x691018: LoadField: r5 = r3->field_27
    //     0x691018: ldur            w5, [x3, #0x27]
    // 0x69101c: DecompressPointer r5
    //     0x69101c: add             x5, x5, HEAP, lsl #32
    // 0x691020: stur            x5, [fp, #-8]
    // 0x691024: cmp             w5, NULL
    // 0x691028: b.eq            #0x691370
    // 0x69102c: mov             x0, x5
    // 0x691030: r2 = Null
    //     0x691030: mov             x2, NULL
    // 0x691034: r1 = Null
    //     0x691034: mov             x1, NULL
    // 0x691038: r4 = LoadClassIdInstr(r0)
    //     0x691038: ldur            x4, [x0, #-1]
    //     0x69103c: ubfx            x4, x4, #0xc, #0x14
    // 0x691040: sub             x4, x4, #0x80d
    // 0x691044: cmp             x4, #1
    // 0x691048: b.ls            #0x691060
    // 0x69104c: r8 = BoxConstraints
    //     0x69104c: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x691050: ldr             x8, [x8, #0x1d0]
    // 0x691054: r3 = Null
    //     0x691054: add             x3, PP, #0x55, lsl #12  ; [pp+0x55698] Null
    //     0x691058: ldr             x3, [x3, #0x698]
    // 0x69105c: r0 = BoxConstraints()
    //     0x69105c: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x691060: ldr             x0, [fp, #0x10]
    // 0x691064: LoadField: r1 = r0->field_5f
    //     0x691064: ldur            w1, [x0, #0x5f]
    // 0x691068: DecompressPointer r1
    //     0x691068: add             x1, x1, HEAP, lsl #32
    // 0x69106c: cmp             w1, NULL
    // 0x691070: b.ne            #0x69107c
    // 0x691074: ldur            x2, [fp, #-8]
    // 0x691078: b               #0x6910a8
    // 0x69107c: ldur            x2, [fp, #-8]
    // 0x691080: LoadField: d0 = r2->field_7
    //     0x691080: ldur            d0, [x2, #7]
    // 0x691084: LoadField: d1 = r2->field_f
    //     0x691084: ldur            d1, [x2, #0xf]
    // 0x691088: fcmp            d0, d1
    // 0x69108c: b.vs            #0x6911ec
    // 0x691090: b.lt            #0x6911ec
    // 0x691094: LoadField: d0 = r2->field_17
    //     0x691094: ldur            d0, [x2, #0x17]
    // 0x691098: LoadField: d1 = r2->field_1f
    //     0x691098: ldur            d1, [x2, #0x1f]
    // 0x69109c: fcmp            d0, d1
    // 0x6910a0: b.vs            #0x6911e4
    // 0x6910a4: b.lt            #0x6911e4
    // 0x6910a8: ldur            x16, [fp, #-0x10]
    // 0x6910ac: SaveReg r16
    //     0x6910ac: str             x16, [SP, #-8]!
    // 0x6910b0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6910b0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6910b4: r0 = stop()
    //     0x6910b4: bl              #0x593468  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x6910b8: add             SP, SP, #8
    // 0x6910bc: ldr             x0, [fp, #0x10]
    // 0x6910c0: LoadField: r1 = r0->field_77
    //     0x6910c0: ldur            w1, [x0, #0x77]
    // 0x6910c4: DecompressPointer r1
    //     0x6910c4: add             x1, x1, HEAP, lsl #32
    // 0x6910c8: stur            x1, [fp, #-0x10]
    // 0x6910cc: ldur            x16, [fp, #-8]
    // 0x6910d0: SaveReg r16
    //     0x6910d0: str             x16, [SP, #-8]!
    // 0x6910d4: r0 = smallest()
    //     0x6910d4: bl              #0x62bd18  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0x6910d8: add             SP, SP, #8
    // 0x6910dc: mov             x4, x0
    // 0x6910e0: ldur            x3, [fp, #-0x10]
    // 0x6910e4: stur            x4, [fp, #-0x18]
    // 0x6910e8: LoadField: r2 = r3->field_7
    //     0x6910e8: ldur            w2, [x3, #7]
    // 0x6910ec: DecompressPointer r2
    //     0x6910ec: add             x2, x2, HEAP, lsl #32
    // 0x6910f0: mov             x0, x4
    // 0x6910f4: r1 = Null
    //     0x6910f4: mov             x1, NULL
    // 0x6910f8: cmp             w0, NULL
    // 0x6910fc: b.eq            #0x691124
    // 0x691100: cmp             w2, NULL
    // 0x691104: b.eq            #0x691124
    // 0x691108: LoadField: r4 = r2->field_17
    //     0x691108: ldur            w4, [x2, #0x17]
    // 0x69110c: DecompressPointer r4
    //     0x69110c: add             x4, x4, HEAP, lsl #32
    // 0x691110: r8 = X0?
    //     0x691110: ldr             x8, [PP, #0x1e8]  ; [pp+0x1e8] TypeParameter: X0?
    // 0x691114: LoadField: r9 = r4->field_7
    //     0x691114: ldur            x9, [x4, #7]
    // 0x691118: r3 = Null
    //     0x691118: add             x3, PP, #0x55, lsl #12  ; [pp+0x556a8] Null
    //     0x69111c: ldr             x3, [x3, #0x6a8]
    // 0x691120: blr             x9
    // 0x691124: ldur            x0, [fp, #-0x18]
    // 0x691128: ldur            x1, [fp, #-0x10]
    // 0x69112c: StoreField: r1->field_f = r0
    //     0x69112c: stur            w0, [x1, #0xf]
    //     0x691130: ldurb           w16, [x1, #-1]
    //     0x691134: ldurb           w17, [x0, #-1]
    //     0x691138: and             x16, x17, x16, lsr #2
    //     0x69113c: tst             x16, HEAP, lsr #32
    //     0x691140: b.eq            #0x691148
    //     0x691144: bl              #0xd6826c
    // 0x691148: ldur            x0, [fp, #-0x18]
    // 0x69114c: StoreField: r1->field_b = r0
    //     0x69114c: stur            w0, [x1, #0xb]
    //     0x691150: ldurb           w16, [x1, #-1]
    //     0x691154: ldurb           w17, [x0, #-1]
    //     0x691158: and             x16, x17, x16, lsr #2
    //     0x69115c: tst             x16, HEAP, lsr #32
    //     0x691160: b.eq            #0x691168
    //     0x691164: bl              #0xd6826c
    // 0x691168: ldur            x0, [fp, #-0x18]
    // 0x69116c: ldr             x2, [fp, #0x10]
    // 0x691170: StoreField: r2->field_57 = r0
    //     0x691170: stur            w0, [x2, #0x57]
    //     0x691174: ldurb           w16, [x2, #-1]
    //     0x691178: ldurb           w17, [x0, #-1]
    //     0x69117c: and             x16, x17, x16, lsr #2
    //     0x691180: tst             x16, HEAP, lsr #32
    //     0x691184: b.eq            #0x69118c
    //     0x691188: bl              #0xd6828c
    // 0x69118c: r0 = Instance_RenderAnimatedSizeState
    //     0x69118c: add             x0, PP, #0x52, lsl #12  ; [pp+0x52b78] Obj!RenderAnimatedSizeState@b64cb1
    //     0x691190: ldr             x0, [x0, #0xb78]
    // 0x691194: StoreField: r2->field_83 = r0
    //     0x691194: stur            w0, [x2, #0x83]
    // 0x691198: LoadField: r0 = r2->field_5f
    //     0x691198: ldur            w0, [x2, #0x5f]
    // 0x69119c: DecompressPointer r0
    //     0x69119c: add             x0, x0, HEAP, lsl #32
    // 0x6911a0: cmp             w0, NULL
    // 0x6911a4: b.eq            #0x6911d4
    // 0x6911a8: r1 = LoadClassIdInstr(r0)
    //     0x6911a8: ldur            x1, [x0, #-1]
    //     0x6911ac: ubfx            x1, x1, #0xc, #0x14
    // 0x6911b0: ldur            x16, [fp, #-8]
    // 0x6911b4: stp             x16, x0, [SP, #-0x10]!
    // 0x6911b8: mov             x0, x1
    // 0x6911bc: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x6911bc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x6911c0: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x6911c0: mov             x17, #0xcdfb
    //     0x6911c4: add             lr, x0, x17
    //     0x6911c8: ldr             lr, [x21, lr, lsl #3]
    //     0x6911cc: blr             lr
    // 0x6911d0: add             SP, SP, #0x10
    // 0x6911d4: r0 = Null
    //     0x6911d4: mov             x0, NULL
    // 0x6911d8: LeaveFrame
    //     0x6911d8: mov             SP, fp
    //     0x6911dc: ldp             fp, lr, [SP], #0x10
    // 0x6911e0: ret
    //     0x6911e0: ret             
    // 0x6911e4: mov             x2, x0
    // 0x6911e8: b               #0x6911f0
    // 0x6911ec: mov             x2, x0
    // 0x6911f0: r0 = LoadClassIdInstr(r1)
    //     0x6911f0: ldur            x0, [x1, #-1]
    //     0x6911f4: ubfx            x0, x0, #0xc, #0x14
    // 0x6911f8: ldur            x16, [fp, #-8]
    // 0x6911fc: stp             x16, x1, [SP, #-0x10]!
    // 0x691200: r16 = true
    //     0x691200: add             x16, NULL, #0x20  ; true
    // 0x691204: SaveReg r16
    //     0x691204: str             x16, [SP, #-8]!
    // 0x691208: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x691208: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x69120c: ldr             x4, [x4, #0x1c8]
    // 0x691210: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x691210: mov             x17, #0xcdfb
    //     0x691214: add             lr, x0, x17
    //     0x691218: ldr             lr, [x21, lr, lsl #3]
    //     0x69121c: blr             lr
    // 0x691220: add             SP, SP, #0x18
    // 0x691224: ldr             x0, [fp, #0x10]
    // 0x691228: LoadField: r1 = r0->field_83
    //     0x691228: ldur            w1, [x0, #0x83]
    // 0x69122c: DecompressPointer r1
    //     0x69122c: add             x1, x1, HEAP, lsl #32
    // 0x691230: LoadField: r2 = r1->field_7
    //     0x691230: ldur            x2, [x1, #7]
    // 0x691234: cmp             x2, #1
    // 0x691238: b.gt            #0x691268
    // 0x69123c: cmp             x2, #0
    // 0x691240: b.gt            #0x691254
    // 0x691244: SaveReg r0
    //     0x691244: str             x0, [SP, #-8]!
    // 0x691248: r0 = _layoutStart()
    //     0x691248: bl              #0x691bcc  ; [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::_layoutStart
    // 0x69124c: add             SP, SP, #8
    // 0x691250: b               #0x691294
    // 0x691254: ldr             x16, [fp, #0x10]
    // 0x691258: SaveReg r16
    //     0x691258: str             x16, [SP, #-8]!
    // 0x69125c: r0 = _layoutStable()
    //     0x69125c: bl              #0x6918c4  ; [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::_layoutStable
    // 0x691260: add             SP, SP, #8
    // 0x691264: b               #0x691294
    // 0x691268: cmp             x2, #2
    // 0x69126c: b.gt            #0x691284
    // 0x691270: ldr             x16, [fp, #0x10]
    // 0x691274: SaveReg r16
    //     0x691274: str             x16, [SP, #-8]!
    // 0x691278: r0 = _layoutChanged()
    //     0x691278: bl              #0x6916f8  ; [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::_layoutChanged
    // 0x69127c: add             SP, SP, #8
    // 0x691280: b               #0x691294
    // 0x691284: ldr             x16, [fp, #0x10]
    // 0x691288: SaveReg r16
    //     0x691288: str             x16, [SP, #-8]!
    // 0x69128c: r0 = _layoutUnstable()
    //     0x69128c: bl              #0x691428  ; [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::_layoutUnstable
    // 0x691290: add             SP, SP, #8
    // 0x691294: ldr             x0, [fp, #0x10]
    // 0x691298: LoadField: r1 = r0->field_77
    //     0x691298: ldur            w1, [x0, #0x77]
    // 0x69129c: DecompressPointer r1
    //     0x69129c: add             x1, x1, HEAP, lsl #32
    // 0x6912a0: stur            x1, [fp, #-0x10]
    // 0x6912a4: LoadField: r2 = r0->field_73
    //     0x6912a4: ldur            w2, [x0, #0x73]
    // 0x6912a8: DecompressPointer r2
    //     0x6912a8: add             x2, x2, HEAP, lsl #32
    // 0x6912ac: r16 = Sentinel
    //     0x6912ac: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6912b0: cmp             w2, w16
    // 0x6912b4: b.eq            #0x6913b0
    // 0x6912b8: stp             x2, x1, [SP, #-0x10]!
    // 0x6912bc: r0 = evaluate()
    //     0x6912bc: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x6912c0: add             SP, SP, #0x10
    // 0x6912c4: cmp             w0, NULL
    // 0x6912c8: b.eq            #0x6913bc
    // 0x6912cc: ldur            x16, [fp, #-8]
    // 0x6912d0: stp             x0, x16, [SP, #-0x10]!
    // 0x6912d4: r0 = constrain()
    //     0x6912d4: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x6912d8: add             SP, SP, #0x10
    // 0x6912dc: ldr             x1, [fp, #0x10]
    // 0x6912e0: StoreField: r1->field_57 = r0
    //     0x6912e0: stur            w0, [x1, #0x57]
    //     0x6912e4: ldurb           w16, [x1, #-1]
    //     0x6912e8: ldurb           w17, [x0, #-1]
    //     0x6912ec: and             x16, x17, x16, lsr #2
    //     0x6912f0: tst             x16, HEAP, lsr #32
    //     0x6912f4: b.eq            #0x6912fc
    //     0x6912f8: bl              #0xd6826c
    // 0x6912fc: SaveReg r1
    //     0x6912fc: str             x1, [SP, #-8]!
    // 0x691300: r0 = alignChild()
    //     0x691300: bl              #0x69064c  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::alignChild
    // 0x691304: add             SP, SP, #8
    // 0x691308: ldr             x1, [fp, #0x10]
    // 0x69130c: LoadField: r2 = r1->field_57
    //     0x69130c: ldur            w2, [x1, #0x57]
    // 0x691310: DecompressPointer r2
    //     0x691310: add             x2, x2, HEAP, lsl #32
    // 0x691314: cmp             w2, NULL
    // 0x691318: b.eq            #0x6913c0
    // 0x69131c: LoadField: d0 = r2->field_7
    //     0x69131c: ldur            d0, [x2, #7]
    // 0x691320: ldur            x3, [fp, #-0x10]
    // 0x691324: LoadField: r4 = r3->field_f
    //     0x691324: ldur            w4, [x3, #0xf]
    // 0x691328: DecompressPointer r4
    //     0x691328: add             x4, x4, HEAP, lsl #32
    // 0x69132c: cmp             w4, NULL
    // 0x691330: b.eq            #0x6913c4
    // 0x691334: LoadField: d1 = r4->field_7
    //     0x691334: ldur            d1, [x4, #7]
    // 0x691338: fcmp            d0, d1
    // 0x69133c: b.vs            #0x691344
    // 0x691340: b.lt            #0x691358
    // 0x691344: LoadField: d0 = r2->field_f
    //     0x691344: ldur            d0, [x2, #0xf]
    // 0x691348: LoadField: d1 = r4->field_f
    //     0x691348: ldur            d1, [x4, #0xf]
    // 0x69134c: fcmp            d0, d1
    // 0x691350: b.vs            #0x691360
    // 0x691354: b.ge            #0x691360
    // 0x691358: r2 = true
    //     0x691358: add             x2, NULL, #0x20  ; true
    // 0x69135c: StoreField: r1->field_7b = r2
    //     0x69135c: stur            w2, [x1, #0x7b]
    // 0x691360: r0 = Null
    //     0x691360: mov             x0, NULL
    // 0x691364: LeaveFrame
    //     0x691364: mov             SP, fp
    //     0x691368: ldp             fp, lr, [SP], #0x10
    // 0x69136c: ret
    //     0x69136c: ret             
    // 0x691370: r0 = StateError()
    //     0x691370: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x691374: mov             x1, x0
    // 0x691378: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x691378: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x69137c: ldr             x0, [x0, #0x1e8]
    // 0x691380: StoreField: r1->field_b = r0
    //     0x691380: stur            w0, [x1, #0xb]
    // 0x691384: mov             x0, x1
    // 0x691388: r0 = Throw()
    //     0x691388: bl              #0xd67e38  ; ThrowStub
    // 0x69138c: brk             #0
    // 0x691390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x691390: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x691394: b               #0x690fc8
    // 0x691398: r9 = _controller
    //     0x691398: add             x9, PP, #0x52, lsl #12  ; [pp+0x52b68] Field <RenderAnimatedSize._controller@890160358>: late final (offset: 0x70)
    //     0x69139c: ldr             x9, [x9, #0xb68]
    // 0x6913a0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6913a0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6913a4: r9 = _value
    //     0x6913a4: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x6913a8: ldr             x9, [x9, #0xbb0]
    // 0x6913ac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6913ac: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6913b0: r9 = _animation
    //     0x6913b0: add             x9, PP, #0x52, lsl #12  ; [pp+0x52b70] Field <RenderAnimatedSize._animation@890160358>: late final (offset: 0x74)
    //     0x6913b4: ldr             x9, [x9, #0xb70]
    // 0x6913b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6913b8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6913bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6913bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6913c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6913c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6913c4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6913c4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  get _ _animatedSize(/* No info */) {
    // ** addr: 0x6913c8, size: 0x60
    // 0x6913c8: EnterFrame
    //     0x6913c8: stp             fp, lr, [SP, #-0x10]!
    //     0x6913cc: mov             fp, SP
    // 0x6913d0: CheckStackOverflow
    //     0x6913d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6913d4: cmp             SP, x16
    //     0x6913d8: b.ls            #0x691414
    // 0x6913dc: ldr             x0, [fp, #0x10]
    // 0x6913e0: LoadField: r1 = r0->field_77
    //     0x6913e0: ldur            w1, [x0, #0x77]
    // 0x6913e4: DecompressPointer r1
    //     0x6913e4: add             x1, x1, HEAP, lsl #32
    // 0x6913e8: LoadField: r2 = r0->field_73
    //     0x6913e8: ldur            w2, [x0, #0x73]
    // 0x6913ec: DecompressPointer r2
    //     0x6913ec: add             x2, x2, HEAP, lsl #32
    // 0x6913f0: r16 = Sentinel
    //     0x6913f0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6913f4: cmp             w2, w16
    // 0x6913f8: b.eq            #0x69141c
    // 0x6913fc: stp             x2, x1, [SP, #-0x10]!
    // 0x691400: r0 = evaluate()
    //     0x691400: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x691404: add             SP, SP, #0x10
    // 0x691408: LeaveFrame
    //     0x691408: mov             SP, fp
    //     0x69140c: ldp             fp, lr, [SP], #0x10
    // 0x691410: ret
    //     0x691410: ret             
    // 0x691414: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x691414: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x691418: b               #0x6913dc
    // 0x69141c: r9 = _animation
    //     0x69141c: add             x9, PP, #0x52, lsl #12  ; [pp+0x52b70] Field <RenderAnimatedSize._animation@890160358>: late final (offset: 0x74)
    //     0x691420: ldr             x9, [x9, #0xb70]
    // 0x691424: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x691424: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _layoutUnstable(/* No info */) {
    // ** addr: 0x691428, size: 0x1a0
    // 0x691428: EnterFrame
    //     0x691428: stp             fp, lr, [SP, #-0x10]!
    //     0x69142c: mov             fp, SP
    // 0x691430: AllocStack(0x10)
    //     0x691430: sub             SP, SP, #0x10
    // 0x691434: CheckStackOverflow
    //     0x691434: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x691438: cmp             SP, x16
    //     0x69143c: b.ls            #0x6915a4
    // 0x691440: ldr             x1, [fp, #0x10]
    // 0x691444: LoadField: r2 = r1->field_77
    //     0x691444: ldur            w2, [x1, #0x77]
    // 0x691448: DecompressPointer r2
    //     0x691448: add             x2, x2, HEAP, lsl #32
    // 0x69144c: stur            x2, [fp, #-8]
    // 0x691450: LoadField: r0 = r2->field_f
    //     0x691450: ldur            w0, [x2, #0xf]
    // 0x691454: DecompressPointer r0
    //     0x691454: add             x0, x0, HEAP, lsl #32
    // 0x691458: LoadField: r3 = r1->field_5f
    //     0x691458: ldur            w3, [x1, #0x5f]
    // 0x69145c: DecompressPointer r3
    //     0x69145c: add             x3, x3, HEAP, lsl #32
    // 0x691460: cmp             w3, NULL
    // 0x691464: b.eq            #0x6915ac
    // 0x691468: LoadField: r4 = r3->field_57
    //     0x691468: ldur            w4, [x3, #0x57]
    // 0x69146c: DecompressPointer r4
    //     0x69146c: add             x4, x4, HEAP, lsl #32
    // 0x691470: cmp             w4, NULL
    // 0x691474: b.eq            #0x6915b0
    // 0x691478: r3 = LoadClassIdInstr(r0)
    //     0x691478: ldur            x3, [x0, #-1]
    //     0x69147c: ubfx            x3, x3, #0xc, #0x14
    // 0x691480: stp             x4, x0, [SP, #-0x10]!
    // 0x691484: mov             x0, x3
    // 0x691488: mov             lr, x0
    // 0x69148c: ldr             lr, [x21, lr, lsl #3]
    // 0x691490: blr             lr
    // 0x691494: add             SP, SP, #0x10
    // 0x691498: tbz             w0, #4, #0x69155c
    // 0x69149c: ldr             x3, [fp, #0x10]
    // 0x6914a0: ldur            x4, [fp, #-8]
    // 0x6914a4: LoadField: r0 = r3->field_5f
    //     0x6914a4: ldur            w0, [x3, #0x5f]
    // 0x6914a8: DecompressPointer r0
    //     0x6914a8: add             x0, x0, HEAP, lsl #32
    // 0x6914ac: cmp             w0, NULL
    // 0x6914b0: b.eq            #0x6915b4
    // 0x6914b4: LoadField: r5 = r0->field_57
    //     0x6914b4: ldur            w5, [x0, #0x57]
    // 0x6914b8: DecompressPointer r5
    //     0x6914b8: add             x5, x5, HEAP, lsl #32
    // 0x6914bc: stur            x5, [fp, #-0x10]
    // 0x6914c0: cmp             w5, NULL
    // 0x6914c4: b.eq            #0x6915b8
    // 0x6914c8: LoadField: r2 = r4->field_7
    //     0x6914c8: ldur            w2, [x4, #7]
    // 0x6914cc: DecompressPointer r2
    //     0x6914cc: add             x2, x2, HEAP, lsl #32
    // 0x6914d0: mov             x0, x5
    // 0x6914d4: r1 = Null
    //     0x6914d4: mov             x1, NULL
    // 0x6914d8: cmp             w0, NULL
    // 0x6914dc: b.eq            #0x691504
    // 0x6914e0: cmp             w2, NULL
    // 0x6914e4: b.eq            #0x691504
    // 0x6914e8: LoadField: r4 = r2->field_17
    //     0x6914e8: ldur            w4, [x2, #0x17]
    // 0x6914ec: DecompressPointer r4
    //     0x6914ec: add             x4, x4, HEAP, lsl #32
    // 0x6914f0: r8 = X0?
    //     0x6914f0: ldr             x8, [PP, #0x1e8]  ; [pp+0x1e8] TypeParameter: X0?
    // 0x6914f4: LoadField: r9 = r4->field_7
    //     0x6914f4: ldur            x9, [x4, #7]
    // 0x6914f8: r3 = Null
    //     0x6914f8: add             x3, PP, #0x55, lsl #12  ; [pp+0x556b8] Null
    //     0x6914fc: ldr             x3, [x3, #0x6b8]
    // 0x691500: blr             x9
    // 0x691504: ldur            x0, [fp, #-0x10]
    // 0x691508: ldur            x1, [fp, #-8]
    // 0x69150c: StoreField: r1->field_f = r0
    //     0x69150c: stur            w0, [x1, #0xf]
    //     0x691510: ldurb           w16, [x1, #-1]
    //     0x691514: ldurb           w17, [x0, #-1]
    //     0x691518: and             x16, x17, x16, lsr #2
    //     0x69151c: tst             x16, HEAP, lsr #32
    //     0x691520: b.eq            #0x691528
    //     0x691524: bl              #0xd6826c
    // 0x691528: ldur            x0, [fp, #-0x10]
    // 0x69152c: StoreField: r1->field_b = r0
    //     0x69152c: stur            w0, [x1, #0xb]
    //     0x691530: ldurb           w16, [x1, #-1]
    //     0x691534: ldurb           w17, [x0, #-1]
    //     0x691538: and             x16, x17, x16, lsr #2
    //     0x69153c: tst             x16, HEAP, lsr #32
    //     0x691540: b.eq            #0x691548
    //     0x691544: bl              #0xd6826c
    // 0x691548: ldr             x16, [fp, #0x10]
    // 0x69154c: SaveReg r16
    //     0x69154c: str             x16, [SP, #-8]!
    // 0x691550: r0 = _restartAnimation()
    //     0x691550: bl              #0x6915c8  ; [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::_restartAnimation
    // 0x691554: add             SP, SP, #8
    // 0x691558: b               #0x691594
    // 0x69155c: ldr             x0, [fp, #0x10]
    // 0x691560: LoadField: r1 = r0->field_6f
    //     0x691560: ldur            w1, [x0, #0x6f]
    // 0x691564: DecompressPointer r1
    //     0x691564: add             x1, x1, HEAP, lsl #32
    // 0x691568: r16 = Sentinel
    //     0x691568: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x69156c: cmp             w1, w16
    // 0x691570: b.eq            #0x6915bc
    // 0x691574: SaveReg r1
    //     0x691574: str             x1, [SP, #-8]!
    // 0x691578: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x691578: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x69157c: r0 = stop()
    //     0x69157c: bl              #0x593468  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x691580: add             SP, SP, #8
    // 0x691584: ldr             x1, [fp, #0x10]
    // 0x691588: r2 = Instance_RenderAnimatedSizeState
    //     0x691588: add             x2, PP, #0x55, lsl #12  ; [pp+0x556c8] Obj!RenderAnimatedSizeState@b64c51
    //     0x69158c: ldr             x2, [x2, #0x6c8]
    // 0x691590: StoreField: r1->field_83 = r2
    //     0x691590: stur            w2, [x1, #0x83]
    // 0x691594: r0 = Null
    //     0x691594: mov             x0, NULL
    // 0x691598: LeaveFrame
    //     0x691598: mov             SP, fp
    //     0x69159c: ldp             fp, lr, [SP], #0x10
    // 0x6915a0: ret
    //     0x6915a0: ret             
    // 0x6915a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6915a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6915a8: b               #0x691440
    // 0x6915ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6915ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6915b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6915b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6915b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6915b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6915b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6915b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6915bc: r9 = _controller
    //     0x6915bc: add             x9, PP, #0x52, lsl #12  ; [pp+0x52b68] Field <RenderAnimatedSize._controller@890160358>: late final (offset: 0x70)
    //     0x6915c0: ldr             x9, [x9, #0xb68]
    // 0x6915c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6915c4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _restartAnimation(/* No info */) {
    // ** addr: 0x6915c8, size: 0x70
    // 0x6915c8: EnterFrame
    //     0x6915c8: stp             fp, lr, [SP, #-0x10]!
    //     0x6915cc: mov             fp, SP
    // 0x6915d0: r0 = 0.000000
    //     0x6915d0: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x6915d4: CheckStackOverflow
    //     0x6915d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6915d8: cmp             SP, x16
    //     0x6915dc: b.ls            #0x691624
    // 0x6915e0: ldr             x1, [fp, #0x10]
    // 0x6915e4: StoreField: r1->field_7f = r0
    //     0x6915e4: stur            w0, [x1, #0x7f]
    // 0x6915e8: LoadField: r0 = r1->field_6f
    //     0x6915e8: ldur            w0, [x1, #0x6f]
    // 0x6915ec: DecompressPointer r0
    //     0x6915ec: add             x0, x0, HEAP, lsl #32
    // 0x6915f0: r16 = Sentinel
    //     0x6915f0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6915f4: cmp             w0, w16
    // 0x6915f8: b.eq            #0x69162c
    // 0x6915fc: r16 = 0.000000
    //     0x6915fc: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x691600: stp             x16, x0, [SP, #-0x10]!
    // 0x691604: r4 = const [0, 0x2, 0x2, 0x1, from, 0x1, null]
    //     0x691604: add             x4, PP, #0x50, lsl #12  ; [pp+0x50438] List(7) [0, 0x2, 0x2, 0x1, "from", 0x1, Null]
    //     0x691608: ldr             x4, [x4, #0x438]
    // 0x69160c: r0 = forward()
    //     0x69160c: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x691610: add             SP, SP, #0x10
    // 0x691614: r0 = Null
    //     0x691614: mov             x0, NULL
    // 0x691618: LeaveFrame
    //     0x691618: mov             SP, fp
    //     0x69161c: ldp             fp, lr, [SP], #0x10
    // 0x691620: ret
    //     0x691620: ret             
    // 0x691624: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x691624: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x691628: b               #0x6915e0
    // 0x69162c: r9 = _controller
    //     0x69162c: add             x9, PP, #0x52, lsl #12  ; [pp+0x52b68] Field <RenderAnimatedSize._controller@890160358>: late final (offset: 0x70)
    //     0x691630: ldr             x9, [x9, #0xb68]
    // 0x691634: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x691634: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _layoutChanged(/* No info */) {
    // ** addr: 0x6916f8, size: 0x1cc
    // 0x6916f8: EnterFrame
    //     0x6916f8: stp             fp, lr, [SP, #-0x10]!
    //     0x6916fc: mov             fp, SP
    // 0x691700: AllocStack(0x10)
    //     0x691700: sub             SP, SP, #0x10
    // 0x691704: CheckStackOverflow
    //     0x691704: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x691708: cmp             SP, x16
    //     0x69170c: b.ls            #0x6918a0
    // 0x691710: ldr             x1, [fp, #0x10]
    // 0x691714: LoadField: r2 = r1->field_77
    //     0x691714: ldur            w2, [x1, #0x77]
    // 0x691718: DecompressPointer r2
    //     0x691718: add             x2, x2, HEAP, lsl #32
    // 0x69171c: stur            x2, [fp, #-8]
    // 0x691720: LoadField: r0 = r2->field_f
    //     0x691720: ldur            w0, [x2, #0xf]
    // 0x691724: DecompressPointer r0
    //     0x691724: add             x0, x0, HEAP, lsl #32
    // 0x691728: LoadField: r3 = r1->field_5f
    //     0x691728: ldur            w3, [x1, #0x5f]
    // 0x69172c: DecompressPointer r3
    //     0x69172c: add             x3, x3, HEAP, lsl #32
    // 0x691730: cmp             w3, NULL
    // 0x691734: b.eq            #0x6918a8
    // 0x691738: LoadField: r4 = r3->field_57
    //     0x691738: ldur            w4, [x3, #0x57]
    // 0x69173c: DecompressPointer r4
    //     0x69173c: add             x4, x4, HEAP, lsl #32
    // 0x691740: cmp             w4, NULL
    // 0x691744: b.eq            #0x6918ac
    // 0x691748: r3 = LoadClassIdInstr(r0)
    //     0x691748: ldur            x3, [x0, #-1]
    //     0x69174c: ubfx            x3, x3, #0xc, #0x14
    // 0x691750: stp             x4, x0, [SP, #-0x10]!
    // 0x691754: mov             x0, x3
    // 0x691758: mov             lr, x0
    // 0x69175c: ldr             lr, [x21, lr, lsl #3]
    // 0x691760: blr             lr
    // 0x691764: add             SP, SP, #0x10
    // 0x691768: tbz             w0, #4, #0x69183c
    // 0x69176c: ldr             x3, [fp, #0x10]
    // 0x691770: ldur            x4, [fp, #-8]
    // 0x691774: LoadField: r0 = r3->field_5f
    //     0x691774: ldur            w0, [x3, #0x5f]
    // 0x691778: DecompressPointer r0
    //     0x691778: add             x0, x0, HEAP, lsl #32
    // 0x69177c: cmp             w0, NULL
    // 0x691780: b.eq            #0x6918b0
    // 0x691784: LoadField: r5 = r0->field_57
    //     0x691784: ldur            w5, [x0, #0x57]
    // 0x691788: DecompressPointer r5
    //     0x691788: add             x5, x5, HEAP, lsl #32
    // 0x69178c: stur            x5, [fp, #-0x10]
    // 0x691790: cmp             w5, NULL
    // 0x691794: b.eq            #0x6918b4
    // 0x691798: LoadField: r2 = r4->field_7
    //     0x691798: ldur            w2, [x4, #7]
    // 0x69179c: DecompressPointer r2
    //     0x69179c: add             x2, x2, HEAP, lsl #32
    // 0x6917a0: mov             x0, x5
    // 0x6917a4: r1 = Null
    //     0x6917a4: mov             x1, NULL
    // 0x6917a8: cmp             w0, NULL
    // 0x6917ac: b.eq            #0x6917d4
    // 0x6917b0: cmp             w2, NULL
    // 0x6917b4: b.eq            #0x6917d4
    // 0x6917b8: LoadField: r4 = r2->field_17
    //     0x6917b8: ldur            w4, [x2, #0x17]
    // 0x6917bc: DecompressPointer r4
    //     0x6917bc: add             x4, x4, HEAP, lsl #32
    // 0x6917c0: r8 = X0?
    //     0x6917c0: ldr             x8, [PP, #0x1e8]  ; [pp+0x1e8] TypeParameter: X0?
    // 0x6917c4: LoadField: r9 = r4->field_7
    //     0x6917c4: ldur            x9, [x4, #7]
    // 0x6917c8: r3 = Null
    //     0x6917c8: add             x3, PP, #0x55, lsl #12  ; [pp+0x556d0] Null
    //     0x6917cc: ldr             x3, [x3, #0x6d0]
    // 0x6917d0: blr             x9
    // 0x6917d4: ldur            x0, [fp, #-0x10]
    // 0x6917d8: ldur            x1, [fp, #-8]
    // 0x6917dc: StoreField: r1->field_f = r0
    //     0x6917dc: stur            w0, [x1, #0xf]
    //     0x6917e0: ldurb           w16, [x1, #-1]
    //     0x6917e4: ldurb           w17, [x0, #-1]
    //     0x6917e8: and             x16, x17, x16, lsr #2
    //     0x6917ec: tst             x16, HEAP, lsr #32
    //     0x6917f0: b.eq            #0x6917f8
    //     0x6917f4: bl              #0xd6826c
    // 0x6917f8: ldur            x0, [fp, #-0x10]
    // 0x6917fc: StoreField: r1->field_b = r0
    //     0x6917fc: stur            w0, [x1, #0xb]
    //     0x691800: ldurb           w16, [x1, #-1]
    //     0x691804: ldurb           w17, [x0, #-1]
    //     0x691808: and             x16, x17, x16, lsr #2
    //     0x69180c: tst             x16, HEAP, lsr #32
    //     0x691810: b.eq            #0x691818
    //     0x691814: bl              #0xd6826c
    // 0x691818: ldr             x16, [fp, #0x10]
    // 0x69181c: SaveReg r16
    //     0x69181c: str             x16, [SP, #-8]!
    // 0x691820: r0 = _restartAnimation()
    //     0x691820: bl              #0x6915c8  ; [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::_restartAnimation
    // 0x691824: add             SP, SP, #8
    // 0x691828: ldr             x0, [fp, #0x10]
    // 0x69182c: r1 = Instance_RenderAnimatedSizeState
    //     0x69182c: add             x1, PP, #0x55, lsl #12  ; [pp+0x556e0] Obj!RenderAnimatedSizeState@b64c71
    //     0x691830: ldr             x1, [x1, #0x6e0]
    // 0x691834: StoreField: r0->field_83 = r1
    //     0x691834: stur            w1, [x0, #0x83]
    // 0x691838: b               #0x691890
    // 0x69183c: ldr             x0, [fp, #0x10]
    // 0x691840: r1 = Instance_RenderAnimatedSizeState
    //     0x691840: add             x1, PP, #0x55, lsl #12  ; [pp+0x556c8] Obj!RenderAnimatedSizeState@b64c51
    //     0x691844: ldr             x1, [x1, #0x6c8]
    // 0x691848: StoreField: r0->field_83 = r1
    //     0x691848: stur            w1, [x0, #0x83]
    // 0x69184c: LoadField: r1 = r0->field_6f
    //     0x69184c: ldur            w1, [x0, #0x6f]
    // 0x691850: DecompressPointer r1
    //     0x691850: add             x1, x1, HEAP, lsl #32
    // 0x691854: r16 = Sentinel
    //     0x691854: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x691858: cmp             w1, w16
    // 0x69185c: b.eq            #0x6918b8
    // 0x691860: LoadField: r0 = r1->field_2f
    //     0x691860: ldur            w0, [x1, #0x2f]
    // 0x691864: DecompressPointer r0
    //     0x691864: add             x0, x0, HEAP, lsl #32
    // 0x691868: cmp             w0, NULL
    // 0x69186c: b.eq            #0x691880
    // 0x691870: LoadField: r2 = r0->field_7
    //     0x691870: ldur            w2, [x0, #7]
    // 0x691874: DecompressPointer r2
    //     0x691874: add             x2, x2, HEAP, lsl #32
    // 0x691878: cmp             w2, NULL
    // 0x69187c: b.ne            #0x691890
    // 0x691880: SaveReg r1
    //     0x691880: str             x1, [SP, #-8]!
    // 0x691884: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x691884: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x691888: r0 = forward()
    //     0x691888: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x69188c: add             SP, SP, #8
    // 0x691890: r0 = Null
    //     0x691890: mov             x0, NULL
    // 0x691894: LeaveFrame
    //     0x691894: mov             SP, fp
    //     0x691898: ldp             fp, lr, [SP], #0x10
    // 0x69189c: ret
    //     0x69189c: ret             
    // 0x6918a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6918a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6918a4: b               #0x691710
    // 0x6918a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6918a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6918ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6918ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6918b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6918b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6918b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6918b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6918b8: r9 = _controller
    //     0x6918b8: add             x9, PP, #0x52, lsl #12  ; [pp+0x52b68] Field <RenderAnimatedSize._controller@890160358>: late final (offset: 0x70)
    //     0x6918bc: ldr             x9, [x9, #0xb68]
    // 0x6918c0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6918c0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _layoutStable(/* No info */) {
    // ** addr: 0x6918c4, size: 0x308
    // 0x6918c4: EnterFrame
    //     0x6918c4: stp             fp, lr, [SP, #-0x10]!
    //     0x6918c8: mov             fp, SP
    // 0x6918cc: AllocStack(0x18)
    //     0x6918cc: sub             SP, SP, #0x18
    // 0x6918d0: CheckStackOverflow
    //     0x6918d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6918d4: cmp             SP, x16
    //     0x6918d8: b.ls            #0x691b90
    // 0x6918dc: ldr             x1, [fp, #0x10]
    // 0x6918e0: LoadField: r2 = r1->field_77
    //     0x6918e0: ldur            w2, [x1, #0x77]
    // 0x6918e4: DecompressPointer r2
    //     0x6918e4: add             x2, x2, HEAP, lsl #32
    // 0x6918e8: stur            x2, [fp, #-8]
    // 0x6918ec: LoadField: r0 = r2->field_f
    //     0x6918ec: ldur            w0, [x2, #0xf]
    // 0x6918f0: DecompressPointer r0
    //     0x6918f0: add             x0, x0, HEAP, lsl #32
    // 0x6918f4: LoadField: r3 = r1->field_5f
    //     0x6918f4: ldur            w3, [x1, #0x5f]
    // 0x6918f8: DecompressPointer r3
    //     0x6918f8: add             x3, x3, HEAP, lsl #32
    // 0x6918fc: cmp             w3, NULL
    // 0x691900: b.eq            #0x691b98
    // 0x691904: LoadField: r4 = r3->field_57
    //     0x691904: ldur            w4, [x3, #0x57]
    // 0x691908: DecompressPointer r4
    //     0x691908: add             x4, x4, HEAP, lsl #32
    // 0x69190c: cmp             w4, NULL
    // 0x691910: b.eq            #0x691b9c
    // 0x691914: r3 = LoadClassIdInstr(r0)
    //     0x691914: ldur            x3, [x0, #-1]
    //     0x691918: ubfx            x3, x3, #0xc, #0x14
    // 0x69191c: stp             x4, x0, [SP, #-0x10]!
    // 0x691920: mov             x0, x3
    // 0x691924: mov             lr, x0
    // 0x691928: ldr             lr, [x21, lr, lsl #3]
    // 0x69192c: blr             lr
    // 0x691930: add             SP, SP, #0x10
    // 0x691934: tbz             w0, #4, #0x691a64
    // 0x691938: ldr             x3, [fp, #0x10]
    // 0x69193c: ldur            x4, [fp, #-8]
    // 0x691940: LoadField: r5 = r3->field_57
    //     0x691940: ldur            w5, [x3, #0x57]
    // 0x691944: DecompressPointer r5
    //     0x691944: add             x5, x5, HEAP, lsl #32
    // 0x691948: stur            x5, [fp, #-0x18]
    // 0x69194c: cmp             w5, NULL
    // 0x691950: b.eq            #0x691ba0
    // 0x691954: LoadField: r6 = r4->field_7
    //     0x691954: ldur            w6, [x4, #7]
    // 0x691958: DecompressPointer r6
    //     0x691958: add             x6, x6, HEAP, lsl #32
    // 0x69195c: mov             x0, x5
    // 0x691960: mov             x2, x6
    // 0x691964: stur            x6, [fp, #-0x10]
    // 0x691968: r1 = Null
    //     0x691968: mov             x1, NULL
    // 0x69196c: cmp             w0, NULL
    // 0x691970: b.eq            #0x691998
    // 0x691974: cmp             w2, NULL
    // 0x691978: b.eq            #0x691998
    // 0x69197c: LoadField: r4 = r2->field_17
    //     0x69197c: ldur            w4, [x2, #0x17]
    // 0x691980: DecompressPointer r4
    //     0x691980: add             x4, x4, HEAP, lsl #32
    // 0x691984: r8 = X0?
    //     0x691984: ldr             x8, [PP, #0x1e8]  ; [pp+0x1e8] TypeParameter: X0?
    // 0x691988: LoadField: r9 = r4->field_7
    //     0x691988: ldur            x9, [x4, #7]
    // 0x69198c: r3 = Null
    //     0x69198c: add             x3, PP, #0x55, lsl #12  ; [pp+0x556e8] Null
    //     0x691990: ldr             x3, [x3, #0x6e8]
    // 0x691994: blr             x9
    // 0x691998: ldur            x0, [fp, #-0x18]
    // 0x69199c: ldur            x3, [fp, #-8]
    // 0x6919a0: StoreField: r3->field_b = r0
    //     0x6919a0: stur            w0, [x3, #0xb]
    //     0x6919a4: ldurb           w16, [x3, #-1]
    //     0x6919a8: ldurb           w17, [x0, #-1]
    //     0x6919ac: and             x16, x17, x16, lsr #2
    //     0x6919b0: tst             x16, HEAP, lsr #32
    //     0x6919b4: b.eq            #0x6919bc
    //     0x6919b8: bl              #0xd682ac
    // 0x6919bc: ldr             x4, [fp, #0x10]
    // 0x6919c0: LoadField: r0 = r4->field_5f
    //     0x6919c0: ldur            w0, [x4, #0x5f]
    // 0x6919c4: DecompressPointer r0
    //     0x6919c4: add             x0, x0, HEAP, lsl #32
    // 0x6919c8: cmp             w0, NULL
    // 0x6919cc: b.eq            #0x691ba4
    // 0x6919d0: LoadField: r5 = r0->field_57
    //     0x6919d0: ldur            w5, [x0, #0x57]
    // 0x6919d4: DecompressPointer r5
    //     0x6919d4: add             x5, x5, HEAP, lsl #32
    // 0x6919d8: stur            x5, [fp, #-0x18]
    // 0x6919dc: cmp             w5, NULL
    // 0x6919e0: b.eq            #0x691ba8
    // 0x6919e4: mov             x0, x5
    // 0x6919e8: ldur            x2, [fp, #-0x10]
    // 0x6919ec: r1 = Null
    //     0x6919ec: mov             x1, NULL
    // 0x6919f0: cmp             w0, NULL
    // 0x6919f4: b.eq            #0x691a1c
    // 0x6919f8: cmp             w2, NULL
    // 0x6919fc: b.eq            #0x691a1c
    // 0x691a00: LoadField: r4 = r2->field_17
    //     0x691a00: ldur            w4, [x2, #0x17]
    // 0x691a04: DecompressPointer r4
    //     0x691a04: add             x4, x4, HEAP, lsl #32
    // 0x691a08: r8 = X0?
    //     0x691a08: ldr             x8, [PP, #0x1e8]  ; [pp+0x1e8] TypeParameter: X0?
    // 0x691a0c: LoadField: r9 = r4->field_7
    //     0x691a0c: ldur            x9, [x4, #7]
    // 0x691a10: r3 = Null
    //     0x691a10: add             x3, PP, #0x55, lsl #12  ; [pp+0x556f8] Null
    //     0x691a14: ldr             x3, [x3, #0x6f8]
    // 0x691a18: blr             x9
    // 0x691a1c: ldur            x0, [fp, #-0x18]
    // 0x691a20: ldur            x3, [fp, #-8]
    // 0x691a24: StoreField: r3->field_f = r0
    //     0x691a24: stur            w0, [x3, #0xf]
    //     0x691a28: ldurb           w16, [x3, #-1]
    //     0x691a2c: ldurb           w17, [x0, #-1]
    //     0x691a30: and             x16, x17, x16, lsr #2
    //     0x691a34: tst             x16, HEAP, lsr #32
    //     0x691a38: b.eq            #0x691a40
    //     0x691a3c: bl              #0xd682ac
    // 0x691a40: ldr             x16, [fp, #0x10]
    // 0x691a44: SaveReg r16
    //     0x691a44: str             x16, [SP, #-8]!
    // 0x691a48: r0 = _restartAnimation()
    //     0x691a48: bl              #0x6915c8  ; [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::_restartAnimation
    // 0x691a4c: add             SP, SP, #8
    // 0x691a50: ldr             x0, [fp, #0x10]
    // 0x691a54: r1 = Instance_RenderAnimatedSizeState
    //     0x691a54: add             x1, PP, #0x55, lsl #12  ; [pp+0x55708] Obj!RenderAnimatedSizeState@b64c91
    //     0x691a58: ldr             x1, [x1, #0x708]
    // 0x691a5c: StoreField: r0->field_83 = r1
    //     0x691a5c: stur            w1, [x0, #0x83]
    // 0x691a60: b               #0x691b80
    // 0x691a64: ldr             x0, [fp, #0x10]
    // 0x691a68: ldur            x3, [fp, #-8]
    // 0x691a6c: LoadField: r1 = r0->field_6f
    //     0x691a6c: ldur            w1, [x0, #0x6f]
    // 0x691a70: DecompressPointer r1
    //     0x691a70: add             x1, x1, HEAP, lsl #32
    // 0x691a74: r16 = Sentinel
    //     0x691a74: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x691a78: cmp             w1, w16
    // 0x691a7c: b.eq            #0x691bac
    // 0x691a80: LoadField: r2 = r1->field_37
    //     0x691a80: ldur            w2, [x1, #0x37]
    // 0x691a84: DecompressPointer r2
    //     0x691a84: add             x2, x2, HEAP, lsl #32
    // 0x691a88: r16 = Sentinel
    //     0x691a88: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x691a8c: cmp             w2, w16
    // 0x691a90: b.eq            #0x691bb8
    // 0x691a94: LoadField: d0 = r1->field_1b
    //     0x691a94: ldur            d0, [x1, #0x1b]
    // 0x691a98: LoadField: d1 = r2->field_7
    //     0x691a98: ldur            d1, [x2, #7]
    // 0x691a9c: fcmp            d1, d0
    // 0x691aa0: b.vs            #0x691b50
    // 0x691aa4: b.ne            #0x691b50
    // 0x691aa8: LoadField: r1 = r0->field_5f
    //     0x691aa8: ldur            w1, [x0, #0x5f]
    // 0x691aac: DecompressPointer r1
    //     0x691aac: add             x1, x1, HEAP, lsl #32
    // 0x691ab0: cmp             w1, NULL
    // 0x691ab4: b.eq            #0x691bc4
    // 0x691ab8: LoadField: r4 = r1->field_57
    //     0x691ab8: ldur            w4, [x1, #0x57]
    // 0x691abc: DecompressPointer r4
    //     0x691abc: add             x4, x4, HEAP, lsl #32
    // 0x691ac0: stur            x4, [fp, #-0x10]
    // 0x691ac4: cmp             w4, NULL
    // 0x691ac8: b.eq            #0x691bc8
    // 0x691acc: LoadField: r2 = r3->field_7
    //     0x691acc: ldur            w2, [x3, #7]
    // 0x691ad0: DecompressPointer r2
    //     0x691ad0: add             x2, x2, HEAP, lsl #32
    // 0x691ad4: mov             x0, x4
    // 0x691ad8: r1 = Null
    //     0x691ad8: mov             x1, NULL
    // 0x691adc: cmp             w0, NULL
    // 0x691ae0: b.eq            #0x691b08
    // 0x691ae4: cmp             w2, NULL
    // 0x691ae8: b.eq            #0x691b08
    // 0x691aec: LoadField: r4 = r2->field_17
    //     0x691aec: ldur            w4, [x2, #0x17]
    // 0x691af0: DecompressPointer r4
    //     0x691af0: add             x4, x4, HEAP, lsl #32
    // 0x691af4: r8 = X0?
    //     0x691af4: ldr             x8, [PP, #0x1e8]  ; [pp+0x1e8] TypeParameter: X0?
    // 0x691af8: LoadField: r9 = r4->field_7
    //     0x691af8: ldur            x9, [x4, #7]
    // 0x691afc: r3 = Null
    //     0x691afc: add             x3, PP, #0x55, lsl #12  ; [pp+0x55710] Null
    //     0x691b00: ldr             x3, [x3, #0x710]
    // 0x691b04: blr             x9
    // 0x691b08: ldur            x0, [fp, #-0x10]
    // 0x691b0c: ldur            x1, [fp, #-8]
    // 0x691b10: StoreField: r1->field_f = r0
    //     0x691b10: stur            w0, [x1, #0xf]
    //     0x691b14: ldurb           w16, [x1, #-1]
    //     0x691b18: ldurb           w17, [x0, #-1]
    //     0x691b1c: and             x16, x17, x16, lsr #2
    //     0x691b20: tst             x16, HEAP, lsr #32
    //     0x691b24: b.eq            #0x691b2c
    //     0x691b28: bl              #0xd6826c
    // 0x691b2c: ldur            x0, [fp, #-0x10]
    // 0x691b30: StoreField: r1->field_b = r0
    //     0x691b30: stur            w0, [x1, #0xb]
    //     0x691b34: ldurb           w16, [x1, #-1]
    //     0x691b38: ldurb           w17, [x0, #-1]
    //     0x691b3c: and             x16, x17, x16, lsr #2
    //     0x691b40: tst             x16, HEAP, lsr #32
    //     0x691b44: b.eq            #0x691b4c
    //     0x691b48: bl              #0xd6826c
    // 0x691b4c: b               #0x691b80
    // 0x691b50: LoadField: r0 = r1->field_2f
    //     0x691b50: ldur            w0, [x1, #0x2f]
    // 0x691b54: DecompressPointer r0
    //     0x691b54: add             x0, x0, HEAP, lsl #32
    // 0x691b58: cmp             w0, NULL
    // 0x691b5c: b.eq            #0x691b70
    // 0x691b60: LoadField: r2 = r0->field_7
    //     0x691b60: ldur            w2, [x0, #7]
    // 0x691b64: DecompressPointer r2
    //     0x691b64: add             x2, x2, HEAP, lsl #32
    // 0x691b68: cmp             w2, NULL
    // 0x691b6c: b.ne            #0x691b80
    // 0x691b70: SaveReg r1
    //     0x691b70: str             x1, [SP, #-8]!
    // 0x691b74: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x691b74: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x691b78: r0 = forward()
    //     0x691b78: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x691b7c: add             SP, SP, #8
    // 0x691b80: r0 = Null
    //     0x691b80: mov             x0, NULL
    // 0x691b84: LeaveFrame
    //     0x691b84: mov             SP, fp
    //     0x691b88: ldp             fp, lr, [SP], #0x10
    // 0x691b8c: ret
    //     0x691b8c: ret             
    // 0x691b90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x691b90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x691b94: b               #0x6918dc
    // 0x691b98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x691b98: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x691b9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x691b9c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x691ba0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x691ba0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x691ba4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x691ba4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x691ba8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x691ba8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x691bac: r9 = _controller
    //     0x691bac: add             x9, PP, #0x52, lsl #12  ; [pp+0x52b68] Field <RenderAnimatedSize._controller@890160358>: late final (offset: 0x70)
    //     0x691bb0: ldr             x9, [x9, #0xb68]
    // 0x691bb4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x691bb4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x691bb8: r9 = _value
    //     0x691bb8: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x691bbc: ldr             x9, [x9, #0xbb0]
    // 0x691bc0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x691bc0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x691bc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x691bc4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x691bc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x691bc8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _layoutStart(/* No info */) {
    // ** addr: 0x691bcc, size: 0xe8
    // 0x691bcc: EnterFrame
    //     0x691bcc: stp             fp, lr, [SP, #-0x10]!
    //     0x691bd0: mov             fp, SP
    // 0x691bd4: AllocStack(0x10)
    //     0x691bd4: sub             SP, SP, #0x10
    // 0x691bd8: ldr             x3, [fp, #0x10]
    // 0x691bdc: LoadField: r4 = r3->field_77
    //     0x691bdc: ldur            w4, [x3, #0x77]
    // 0x691be0: DecompressPointer r4
    //     0x691be0: add             x4, x4, HEAP, lsl #32
    // 0x691be4: stur            x4, [fp, #-0x10]
    // 0x691be8: LoadField: r0 = r3->field_5f
    //     0x691be8: ldur            w0, [x3, #0x5f]
    // 0x691bec: DecompressPointer r0
    //     0x691bec: add             x0, x0, HEAP, lsl #32
    // 0x691bf0: cmp             w0, NULL
    // 0x691bf4: b.eq            #0x691cac
    // 0x691bf8: LoadField: r5 = r0->field_57
    //     0x691bf8: ldur            w5, [x0, #0x57]
    // 0x691bfc: DecompressPointer r5
    //     0x691bfc: add             x5, x5, HEAP, lsl #32
    // 0x691c00: stur            x5, [fp, #-8]
    // 0x691c04: cmp             w5, NULL
    // 0x691c08: b.eq            #0x691cb0
    // 0x691c0c: LoadField: r2 = r4->field_7
    //     0x691c0c: ldur            w2, [x4, #7]
    // 0x691c10: DecompressPointer r2
    //     0x691c10: add             x2, x2, HEAP, lsl #32
    // 0x691c14: mov             x0, x5
    // 0x691c18: r1 = Null
    //     0x691c18: mov             x1, NULL
    // 0x691c1c: cmp             w0, NULL
    // 0x691c20: b.eq            #0x691c48
    // 0x691c24: cmp             w2, NULL
    // 0x691c28: b.eq            #0x691c48
    // 0x691c2c: LoadField: r4 = r2->field_17
    //     0x691c2c: ldur            w4, [x2, #0x17]
    // 0x691c30: DecompressPointer r4
    //     0x691c30: add             x4, x4, HEAP, lsl #32
    // 0x691c34: r8 = X0?
    //     0x691c34: ldr             x8, [PP, #0x1e8]  ; [pp+0x1e8] TypeParameter: X0?
    // 0x691c38: LoadField: r9 = r4->field_7
    //     0x691c38: ldur            x9, [x4, #7]
    // 0x691c3c: r3 = Null
    //     0x691c3c: add             x3, PP, #0x55, lsl #12  ; [pp+0x55720] Null
    //     0x691c40: ldr             x3, [x3, #0x720]
    // 0x691c44: blr             x9
    // 0x691c48: ldur            x0, [fp, #-8]
    // 0x691c4c: ldur            x1, [fp, #-0x10]
    // 0x691c50: StoreField: r1->field_f = r0
    //     0x691c50: stur            w0, [x1, #0xf]
    //     0x691c54: ldurb           w16, [x1, #-1]
    //     0x691c58: ldurb           w17, [x0, #-1]
    //     0x691c5c: and             x16, x17, x16, lsr #2
    //     0x691c60: tst             x16, HEAP, lsr #32
    //     0x691c64: b.eq            #0x691c6c
    //     0x691c68: bl              #0xd6826c
    // 0x691c6c: ldur            x0, [fp, #-8]
    // 0x691c70: StoreField: r1->field_b = r0
    //     0x691c70: stur            w0, [x1, #0xb]
    //     0x691c74: ldurb           w16, [x1, #-1]
    //     0x691c78: ldurb           w17, [x0, #-1]
    //     0x691c7c: and             x16, x17, x16, lsr #2
    //     0x691c80: tst             x16, HEAP, lsr #32
    //     0x691c84: b.eq            #0x691c8c
    //     0x691c88: bl              #0xd6826c
    // 0x691c8c: ldr             x2, [fp, #0x10]
    // 0x691c90: r1 = Instance_RenderAnimatedSizeState
    //     0x691c90: add             x1, PP, #0x55, lsl #12  ; [pp+0x556c8] Obj!RenderAnimatedSizeState@b64c51
    //     0x691c94: ldr             x1, [x1, #0x6c8]
    // 0x691c98: StoreField: r2->field_83 = r1
    //     0x691c98: stur            w1, [x2, #0x83]
    // 0x691c9c: r0 = Null
    //     0x691c9c: mov             x0, NULL
    // 0x691ca0: LeaveFrame
    //     0x691ca0: mov             SP, fp
    //     0x691ca4: ldp             fp, lr, [SP], #0x10
    // 0x691ca8: ret
    //     0x691ca8: ret             
    // 0x691cac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x691cac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x691cb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x691cb0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ vsync=(/* No info */) {
    // ** addr: 0x6c2cb8, size: 0xa0
    // 0x6c2cb8: EnterFrame
    //     0x6c2cb8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c2cbc: mov             fp, SP
    // 0x6c2cc0: CheckStackOverflow
    //     0x6c2cc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c2cc4: cmp             SP, x16
    //     0x6c2cc8: b.ls            #0x6c2d44
    // 0x6c2ccc: ldr             x1, [fp, #0x18]
    // 0x6c2cd0: LoadField: r0 = r1->field_8b
    //     0x6c2cd0: ldur            w0, [x1, #0x8b]
    // 0x6c2cd4: DecompressPointer r0
    //     0x6c2cd4: add             x0, x0, HEAP, lsl #32
    // 0x6c2cd8: ldr             x2, [fp, #0x10]
    // 0x6c2cdc: cmp             w2, w0
    // 0x6c2ce0: b.ne            #0x6c2cf4
    // 0x6c2ce4: r0 = Null
    //     0x6c2ce4: mov             x0, NULL
    // 0x6c2ce8: LeaveFrame
    //     0x6c2ce8: mov             SP, fp
    //     0x6c2cec: ldp             fp, lr, [SP], #0x10
    // 0x6c2cf0: ret
    //     0x6c2cf0: ret             
    // 0x6c2cf4: mov             x0, x2
    // 0x6c2cf8: StoreField: r1->field_8b = r0
    //     0x6c2cf8: stur            w0, [x1, #0x8b]
    //     0x6c2cfc: ldurb           w16, [x1, #-1]
    //     0x6c2d00: ldurb           w17, [x0, #-1]
    //     0x6c2d04: and             x16, x17, x16, lsr #2
    //     0x6c2d08: tst             x16, HEAP, lsr #32
    //     0x6c2d0c: b.eq            #0x6c2d14
    //     0x6c2d10: bl              #0xd6826c
    // 0x6c2d14: LoadField: r0 = r1->field_6f
    //     0x6c2d14: ldur            w0, [x1, #0x6f]
    // 0x6c2d18: DecompressPointer r0
    //     0x6c2d18: add             x0, x0, HEAP, lsl #32
    // 0x6c2d1c: r16 = Sentinel
    //     0x6c2d1c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6c2d20: cmp             w0, w16
    // 0x6c2d24: b.eq            #0x6c2d4c
    // 0x6c2d28: stp             x2, x0, [SP, #-0x10]!
    // 0x6c2d2c: r0 = resync()
    //     0x6c2d2c: bl              #0x6c2d58  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::resync
    // 0x6c2d30: add             SP, SP, #0x10
    // 0x6c2d34: r0 = Null
    //     0x6c2d34: mov             x0, NULL
    // 0x6c2d38: LeaveFrame
    //     0x6c2d38: mov             SP, fp
    //     0x6c2d3c: ldp             fp, lr, [SP], #0x10
    // 0x6c2d40: ret
    //     0x6c2d40: ret             
    // 0x6c2d44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c2d44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c2d48: b               #0x6c2ccc
    // 0x6c2d4c: r9 = _controller
    //     0x6c2d4c: add             x9, PP, #0x52, lsl #12  ; [pp+0x52b68] Field <RenderAnimatedSize._controller@890160358>: late final (offset: 0x70)
    //     0x6c2d50: ldr             x9, [x9, #0xb68]
    // 0x6c2d54: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6c2d54: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ curve=(/* No info */) {
    // ** addr: 0x6c3234, size: 0x7c
    // 0x6c3234: EnterFrame
    //     0x6c3234: stp             fp, lr, [SP, #-0x10]!
    //     0x6c3238: mov             fp, SP
    // 0x6c323c: ldr             x1, [fp, #0x18]
    // 0x6c3240: LoadField: r2 = r1->field_73
    //     0x6c3240: ldur            w2, [x1, #0x73]
    // 0x6c3244: DecompressPointer r2
    //     0x6c3244: add             x2, x2, HEAP, lsl #32
    // 0x6c3248: r16 = Sentinel
    //     0x6c3248: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6c324c: cmp             w2, w16
    // 0x6c3250: b.eq            #0x6c32a4
    // 0x6c3254: LoadField: r1 = r2->field_f
    //     0x6c3254: ldur            w1, [x2, #0xf]
    // 0x6c3258: DecompressPointer r1
    //     0x6c3258: add             x1, x1, HEAP, lsl #32
    // 0x6c325c: ldr             x0, [fp, #0x10]
    // 0x6c3260: cmp             w0, w1
    // 0x6c3264: b.ne            #0x6c3278
    // 0x6c3268: r0 = Null
    //     0x6c3268: mov             x0, NULL
    // 0x6c326c: LeaveFrame
    //     0x6c326c: mov             SP, fp
    //     0x6c3270: ldp             fp, lr, [SP], #0x10
    // 0x6c3274: ret
    //     0x6c3274: ret             
    // 0x6c3278: StoreField: r2->field_f = r0
    //     0x6c3278: stur            w0, [x2, #0xf]
    //     0x6c327c: ldurb           w16, [x2, #-1]
    //     0x6c3280: ldurb           w17, [x0, #-1]
    //     0x6c3284: and             x16, x17, x16, lsr #2
    //     0x6c3288: tst             x16, HEAP, lsr #32
    //     0x6c328c: b.eq            #0x6c3294
    //     0x6c3290: bl              #0xd6828c
    // 0x6c3294: r0 = Null
    //     0x6c3294: mov             x0, NULL
    // 0x6c3298: LeaveFrame
    //     0x6c3298: mov             SP, fp
    //     0x6c329c: ldp             fp, lr, [SP], #0x10
    // 0x6c32a0: ret
    //     0x6c32a0: ret             
    // 0x6c32a4: r9 = _animation
    //     0x6c32a4: add             x9, PP, #0x52, lsl #12  ; [pp+0x52b70] Field <RenderAnimatedSize._animation@890160358>: late final (offset: 0x74)
    //     0x6c32a8: ldr             x9, [x9, #0xb70]
    // 0x6c32ac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6c32ac: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ reverseDuration=(/* No info */) {
    // ** addr: 0x6c32b0, size: 0x60
    // 0x6c32b0: EnterFrame
    //     0x6c32b0: stp             fp, lr, [SP, #-0x10]!
    //     0x6c32b4: mov             fp, SP
    // 0x6c32b8: ldr             x1, [fp, #0x18]
    // 0x6c32bc: LoadField: r2 = r1->field_6f
    //     0x6c32bc: ldur            w2, [x1, #0x6f]
    // 0x6c32c0: DecompressPointer r2
    //     0x6c32c0: add             x2, x2, HEAP, lsl #32
    // 0x6c32c4: r16 = Sentinel
    //     0x6c32c4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6c32c8: cmp             w2, w16
    // 0x6c32cc: b.eq            #0x6c3304
    // 0x6c32d0: LoadField: r1 = r2->field_2b
    //     0x6c32d0: ldur            w1, [x2, #0x2b]
    // 0x6c32d4: DecompressPointer r1
    //     0x6c32d4: add             x1, x1, HEAP, lsl #32
    // 0x6c32d8: cmp             w1, NULL
    // 0x6c32dc: b.ne            #0x6c32f0
    // 0x6c32e0: r0 = Null
    //     0x6c32e0: mov             x0, NULL
    // 0x6c32e4: LeaveFrame
    //     0x6c32e4: mov             SP, fp
    //     0x6c32e8: ldp             fp, lr, [SP], #0x10
    // 0x6c32ec: ret
    //     0x6c32ec: ret             
    // 0x6c32f0: StoreField: r2->field_2b = rNULL
    //     0x6c32f0: stur            NULL, [x2, #0x2b]
    // 0x6c32f4: r0 = Null
    //     0x6c32f4: mov             x0, NULL
    // 0x6c32f8: LeaveFrame
    //     0x6c32f8: mov             SP, fp
    //     0x6c32fc: ldp             fp, lr, [SP], #0x10
    // 0x6c3300: ret
    //     0x6c3300: ret             
    // 0x6c3304: r9 = _controller
    //     0x6c3304: add             x9, PP, #0x52, lsl #12  ; [pp+0x52b68] Field <RenderAnimatedSize._controller@890160358>: late final (offset: 0x70)
    //     0x6c3308: ldr             x9, [x9, #0xb68]
    // 0x6c330c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6c330c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ duration=(/* No info */) {
    // ** addr: 0x6c3310, size: 0xa8
    // 0x6c3310: EnterFrame
    //     0x6c3310: stp             fp, lr, [SP, #-0x10]!
    //     0x6c3314: mov             fp, SP
    // 0x6c3318: CheckStackOverflow
    //     0x6c3318: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c331c: cmp             SP, x16
    //     0x6c3320: b.ls            #0x6c33a4
    // 0x6c3324: ldr             x0, [fp, #0x18]
    // 0x6c3328: LoadField: r1 = r0->field_6f
    //     0x6c3328: ldur            w1, [x0, #0x6f]
    // 0x6c332c: DecompressPointer r1
    //     0x6c332c: add             x1, x1, HEAP, lsl #32
    // 0x6c3330: r16 = Sentinel
    //     0x6c3330: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6c3334: cmp             w1, w16
    // 0x6c3338: b.eq            #0x6c33ac
    // 0x6c333c: LoadField: r2 = r1->field_27
    //     0x6c333c: ldur            w2, [x1, #0x27]
    // 0x6c3340: DecompressPointer r2
    //     0x6c3340: add             x2, x2, HEAP, lsl #32
    // 0x6c3344: ldr             x16, [fp, #0x10]
    // 0x6c3348: stp             x2, x16, [SP, #-0x10]!
    // 0x6c334c: r0 = ==()
    //     0x6c334c: bl              #0xc5bcc0  ; [dart:core] Duration::==
    // 0x6c3350: add             SP, SP, #0x10
    // 0x6c3354: tbnz            w0, #4, #0x6c3368
    // 0x6c3358: r0 = Null
    //     0x6c3358: mov             x0, NULL
    // 0x6c335c: LeaveFrame
    //     0x6c335c: mov             SP, fp
    //     0x6c3360: ldp             fp, lr, [SP], #0x10
    // 0x6c3364: ret
    //     0x6c3364: ret             
    // 0x6c3368: ldr             x1, [fp, #0x18]
    // 0x6c336c: LoadField: r2 = r1->field_6f
    //     0x6c336c: ldur            w2, [x1, #0x6f]
    // 0x6c3370: DecompressPointer r2
    //     0x6c3370: add             x2, x2, HEAP, lsl #32
    // 0x6c3374: ldr             x0, [fp, #0x10]
    // 0x6c3378: StoreField: r2->field_27 = r0
    //     0x6c3378: stur            w0, [x2, #0x27]
    //     0x6c337c: ldurb           w16, [x2, #-1]
    //     0x6c3380: ldurb           w17, [x0, #-1]
    //     0x6c3384: and             x16, x17, x16, lsr #2
    //     0x6c3388: tst             x16, HEAP, lsr #32
    //     0x6c338c: b.eq            #0x6c3394
    //     0x6c3390: bl              #0xd6828c
    // 0x6c3394: r0 = Null
    //     0x6c3394: mov             x0, NULL
    // 0x6c3398: LeaveFrame
    //     0x6c3398: mov             SP, fp
    //     0x6c339c: ldp             fp, lr, [SP], #0x10
    // 0x6c33a0: ret
    //     0x6c33a0: ret             
    // 0x6c33a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c33a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c33a8: b               #0x6c3324
    // 0x6c33ac: r9 = _controller
    //     0x6c33ac: add             x9, PP, #0x52, lsl #12  ; [pp+0x52b68] Field <RenderAnimatedSize._controller@890160358>: late final (offset: 0x70)
    //     0x6c33b0: ldr             x9, [x9, #0xb68]
    // 0x6c33b4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6c33b4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ RenderAnimatedSize(/* No info */) {
    // ** addr: 0x6ea504, size: 0x268
    // 0x6ea504: EnterFrame
    //     0x6ea504: stp             fp, lr, [SP, #-0x10]!
    //     0x6ea508: mov             fp, SP
    // 0x6ea50c: AllocStack(0x10)
    //     0x6ea50c: sub             SP, SP, #0x10
    // 0x6ea510: CheckStackOverflow
    //     0x6ea510: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ea514: cmp             SP, x16
    //     0x6ea518: b.ls            #0x6ea764
    // 0x6ea51c: r1 = 1
    //     0x6ea51c: mov             x1, #1
    // 0x6ea520: r0 = AllocateContext()
    //     0x6ea520: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6ea524: mov             x2, x0
    // 0x6ea528: ldr             x0, [fp, #0x38]
    // 0x6ea52c: stur            x2, [fp, #-8]
    // 0x6ea530: StoreField: r2->field_f = r0
    //     0x6ea530: stur            w0, [x2, #0xf]
    // 0x6ea534: r1 = Sentinel
    //     0x6ea534: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6ea538: StoreField: r0->field_6f = r1
    //     0x6ea538: stur            w1, [x0, #0x6f]
    // 0x6ea53c: StoreField: r0->field_73 = r1
    //     0x6ea53c: stur            w1, [x0, #0x73]
    // 0x6ea540: StoreField: r0->field_7b = r1
    //     0x6ea540: stur            w1, [x0, #0x7b]
    // 0x6ea544: r1 = Instance_RenderAnimatedSizeState
    //     0x6ea544: add             x1, PP, #0x52, lsl #12  ; [pp+0x52b78] Obj!RenderAnimatedSizeState@b64cb1
    //     0x6ea548: ldr             x1, [x1, #0xb78]
    // 0x6ea54c: StoreField: r0->field_83 = r1
    //     0x6ea54c: stur            w1, [x0, #0x83]
    // 0x6ea550: r1 = <Size?>
    //     0x6ea550: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dba8] TypeArguments: <Size?>
    //     0x6ea554: ldr             x1, [x1, #0xba8]
    // 0x6ea558: r0 = SizeTween()
    //     0x6ea558: bl              #0x6eab04  ; AllocateSizeTweenStub -> SizeTween (size=0x14)
    // 0x6ea55c: ldr             x2, [fp, #0x38]
    // 0x6ea560: StoreField: r2->field_77 = r0
    //     0x6ea560: stur            w0, [x2, #0x77]
    //     0x6ea564: ldurb           w16, [x2, #-1]
    //     0x6ea568: ldurb           w17, [x0, #-1]
    //     0x6ea56c: and             x16, x17, x16, lsr #2
    //     0x6ea570: tst             x16, HEAP, lsr #32
    //     0x6ea574: b.eq            #0x6ea57c
    //     0x6ea578: bl              #0xd6828c
    // 0x6ea57c: r1 = <ClipRectLayer>
    //     0x6ea57c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15388] TypeArguments: <ClipRectLayer>
    //     0x6ea580: ldr             x1, [x1, #0x388]
    // 0x6ea584: r0 = LayerHandle()
    //     0x6ea584: bl              #0x5bbf28  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x6ea588: ldr             x1, [fp, #0x38]
    // 0x6ea58c: StoreField: r1->field_8f = r0
    //     0x6ea58c: stur            w0, [x1, #0x8f]
    //     0x6ea590: ldurb           w16, [x1, #-1]
    //     0x6ea594: ldurb           w17, [x0, #-1]
    //     0x6ea598: and             x16, x17, x16, lsr #2
    //     0x6ea59c: tst             x16, HEAP, lsr #32
    //     0x6ea5a0: b.eq            #0x6ea5a8
    //     0x6ea5a4: bl              #0xd6826c
    // 0x6ea5a8: ldr             x0, [fp, #0x10]
    // 0x6ea5ac: StoreField: r1->field_8b = r0
    //     0x6ea5ac: stur            w0, [x1, #0x8b]
    //     0x6ea5b0: ldurb           w16, [x1, #-1]
    //     0x6ea5b4: ldurb           w17, [x0, #-1]
    //     0x6ea5b8: and             x16, x17, x16, lsr #2
    //     0x6ea5bc: tst             x16, HEAP, lsr #32
    //     0x6ea5c0: b.eq            #0x6ea5c8
    //     0x6ea5c4: bl              #0xd6826c
    // 0x6ea5c8: r0 = Instance_Clip
    //     0x6ea5c8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x6ea5cc: ldr             x0, [x0, #0x678]
    // 0x6ea5d0: StoreField: r1->field_87 = r0
    //     0x6ea5d0: stur            w0, [x1, #0x87]
    // 0x6ea5d4: ldr             x0, [fp, #0x30]
    // 0x6ea5d8: StoreField: r1->field_67 = r0
    //     0x6ea5d8: stur            w0, [x1, #0x67]
    //     0x6ea5dc: ldurb           w16, [x1, #-1]
    //     0x6ea5e0: ldurb           w17, [x0, #-1]
    //     0x6ea5e4: and             x16, x17, x16, lsr #2
    //     0x6ea5e8: tst             x16, HEAP, lsr #32
    //     0x6ea5ec: b.eq            #0x6ea5f4
    //     0x6ea5f0: bl              #0xd6826c
    // 0x6ea5f4: ldr             x0, [fp, #0x18]
    // 0x6ea5f8: StoreField: r1->field_6b = r0
    //     0x6ea5f8: stur            w0, [x1, #0x6b]
    //     0x6ea5fc: ldurb           w16, [x1, #-1]
    //     0x6ea600: ldurb           w17, [x0, #-1]
    //     0x6ea604: and             x16, x17, x16, lsr #2
    //     0x6ea608: tst             x16, HEAP, lsr #32
    //     0x6ea60c: b.eq            #0x6ea614
    //     0x6ea610: bl              #0xd6826c
    // 0x6ea614: SaveReg r1
    //     0x6ea614: str             x1, [SP, #-8]!
    // 0x6ea618: r0 = RenderObject()
    //     0x6ea618: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6ea61c: add             SP, SP, #8
    // 0x6ea620: ldr             x16, [fp, #0x38]
    // 0x6ea624: stp             NULL, x16, [SP, #-0x10]!
    // 0x6ea628: r0 = child=()
    //     0x6ea628: bl              #0x6e7da0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::child=
    // 0x6ea62c: add             SP, SP, #0x10
    // 0x6ea630: r1 = <double>
    //     0x6ea630: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x6ea634: r0 = AnimationController()
    //     0x6ea634: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x6ea638: stur            x0, [fp, #-0x10]
    // 0x6ea63c: ldr             x16, [fp, #0x10]
    // 0x6ea640: stp             x16, x0, [SP, #-0x10]!
    // 0x6ea644: ldr             x16, [fp, #0x20]
    // 0x6ea648: stp             NULL, x16, [SP, #-0x10]!
    // 0x6ea64c: r4 = const [0, 0x4, 0x4, 0x2, duration, 0x2, reverseDuration, 0x3, null]
    //     0x6ea64c: add             x4, PP, #0x21, lsl #12  ; [pp+0x218b8] List(9) [0, 0x4, 0x4, 0x2, "duration", 0x2, "reverseDuration", 0x3, Null]
    //     0x6ea650: ldr             x4, [x4, #0x8b8]
    // 0x6ea654: r0 = AnimationController()
    //     0x6ea654: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x6ea658: add             SP, SP, #0x20
    // 0x6ea65c: ldur            x2, [fp, #-8]
    // 0x6ea660: r1 = Function '<anonymous closure>':.
    //     0x6ea660: add             x1, PP, #0x52, lsl #12  ; [pp+0x52b80] AnonymousClosure: (0x6eab10), in [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::RenderAnimatedSize (0x6ea504)
    //     0x6ea664: ldr             x1, [x1, #0xb80]
    // 0x6ea668: r0 = AllocateClosure()
    //     0x6ea668: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6ea66c: ldur            x16, [fp, #-0x10]
    // 0x6ea670: stp             x0, x16, [SP, #-0x10]!
    // 0x6ea674: r0 = addActionListener()
    //     0x6ea674: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x6ea678: add             SP, SP, #0x10
    // 0x6ea67c: ldr             x0, [fp, #0x38]
    // 0x6ea680: LoadField: r1 = r0->field_6f
    //     0x6ea680: ldur            w1, [x0, #0x6f]
    // 0x6ea684: DecompressPointer r1
    //     0x6ea684: add             x1, x1, HEAP, lsl #32
    // 0x6ea688: r16 = Sentinel
    //     0x6ea688: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6ea68c: cmp             w1, w16
    // 0x6ea690: b.ne            #0x6ea69c
    // 0x6ea694: mov             x2, x0
    // 0x6ea698: b               #0x6ea6b4
    // 0x6ea69c: r16 = "_controller@890160358"
    //     0x6ea69c: add             x16, PP, #0x52, lsl #12  ; [pp+0x52b88] "_controller@890160358"
    //     0x6ea6a0: ldr             x16, [x16, #0xb88]
    // 0x6ea6a4: SaveReg r16
    //     0x6ea6a4: str             x16, [SP, #-8]!
    // 0x6ea6a8: r0 = _throwFieldAlreadyInitialized()
    //     0x6ea6a8: bl              #0x4fb6c8  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x6ea6ac: add             SP, SP, #8
    // 0x6ea6b0: ldr             x2, [fp, #0x38]
    // 0x6ea6b4: ldur            x0, [fp, #-0x10]
    // 0x6ea6b8: StoreField: r2->field_6f = r0
    //     0x6ea6b8: stur            w0, [x2, #0x6f]
    //     0x6ea6bc: ldurb           w16, [x2, #-1]
    //     0x6ea6c0: ldurb           w17, [x0, #-1]
    //     0x6ea6c4: and             x16, x17, x16, lsr #2
    //     0x6ea6c8: tst             x16, HEAP, lsr #32
    //     0x6ea6cc: b.eq            #0x6ea6d4
    //     0x6ea6d0: bl              #0xd6828c
    // 0x6ea6d4: r1 = <double>
    //     0x6ea6d4: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x6ea6d8: r0 = CurvedAnimation()
    //     0x6ea6d8: bl              #0x5a14dc  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x6ea6dc: stur            x0, [fp, #-8]
    // 0x6ea6e0: ldr             x16, [fp, #0x28]
    // 0x6ea6e4: stp             x16, x0, [SP, #-0x10]!
    // 0x6ea6e8: ldur            x16, [fp, #-0x10]
    // 0x6ea6ec: SaveReg r16
    //     0x6ea6ec: str             x16, [SP, #-8]!
    // 0x6ea6f0: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x6ea6f0: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x6ea6f4: r0 = CurvedAnimation()
    //     0x6ea6f4: bl              #0x5a12a0  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x6ea6f8: add             SP, SP, #0x18
    // 0x6ea6fc: ldr             x0, [fp, #0x38]
    // 0x6ea700: LoadField: r1 = r0->field_73
    //     0x6ea700: ldur            w1, [x0, #0x73]
    // 0x6ea704: DecompressPointer r1
    //     0x6ea704: add             x1, x1, HEAP, lsl #32
    // 0x6ea708: r16 = Sentinel
    //     0x6ea708: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6ea70c: cmp             w1, w16
    // 0x6ea710: b.ne            #0x6ea71c
    // 0x6ea714: mov             x1, x0
    // 0x6ea718: b               #0x6ea734
    // 0x6ea71c: r16 = "_animation@890160358"
    //     0x6ea71c: add             x16, PP, #0x52, lsl #12  ; [pp+0x52b90] "_animation@890160358"
    //     0x6ea720: ldr             x16, [x16, #0xb90]
    // 0x6ea724: SaveReg r16
    //     0x6ea724: str             x16, [SP, #-8]!
    // 0x6ea728: r0 = _throwFieldAlreadyInitialized()
    //     0x6ea728: bl              #0x4fb6c8  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x6ea72c: add             SP, SP, #8
    // 0x6ea730: ldr             x1, [fp, #0x38]
    // 0x6ea734: ldur            x0, [fp, #-8]
    // 0x6ea738: StoreField: r1->field_73 = r0
    //     0x6ea738: stur            w0, [x1, #0x73]
    //     0x6ea73c: ldurb           w16, [x1, #-1]
    //     0x6ea740: ldurb           w17, [x0, #-1]
    //     0x6ea744: and             x16, x17, x16, lsr #2
    //     0x6ea748: tst             x16, HEAP, lsr #32
    //     0x6ea74c: b.eq            #0x6ea754
    //     0x6ea750: bl              #0xd6826c
    // 0x6ea754: r0 = Null
    //     0x6ea754: mov             x0, NULL
    // 0x6ea758: LeaveFrame
    //     0x6ea758: mov             SP, fp
    //     0x6ea75c: ldp             fp, lr, [SP], #0x10
    // 0x6ea760: ret
    //     0x6ea760: ret             
    // 0x6ea764: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ea764: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ea768: b               #0x6ea51c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6eab10, size: 0xb8
    // 0x6eab10: EnterFrame
    //     0x6eab10: stp             fp, lr, [SP, #-0x10]!
    //     0x6eab14: mov             fp, SP
    // 0x6eab18: AllocStack(0x8)
    //     0x6eab18: sub             SP, SP, #8
    // 0x6eab1c: SetupParameters()
    //     0x6eab1c: ldr             x0, [fp, #0x10]
    //     0x6eab20: ldur            w1, [x0, #0x17]
    //     0x6eab24: add             x1, x1, HEAP, lsl #32
    //     0x6eab28: stur            x1, [fp, #-8]
    // 0x6eab2c: CheckStackOverflow
    //     0x6eab2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6eab30: cmp             SP, x16
    //     0x6eab34: b.ls            #0x6eaba8
    // 0x6eab38: LoadField: r0 = r1->field_f
    //     0x6eab38: ldur            w0, [x1, #0xf]
    // 0x6eab3c: DecompressPointer r0
    //     0x6eab3c: add             x0, x0, HEAP, lsl #32
    // 0x6eab40: LoadField: r2 = r0->field_6f
    //     0x6eab40: ldur            w2, [x0, #0x6f]
    // 0x6eab44: DecompressPointer r2
    //     0x6eab44: add             x2, x2, HEAP, lsl #32
    // 0x6eab48: r16 = Sentinel
    //     0x6eab48: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6eab4c: cmp             w2, w16
    // 0x6eab50: b.eq            #0x6eabb0
    // 0x6eab54: LoadField: r3 = r2->field_37
    //     0x6eab54: ldur            w3, [x2, #0x37]
    // 0x6eab58: DecompressPointer r3
    //     0x6eab58: add             x3, x3, HEAP, lsl #32
    // 0x6eab5c: r16 = Sentinel
    //     0x6eab5c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6eab60: cmp             w3, w16
    // 0x6eab64: b.eq            #0x6eabbc
    // 0x6eab68: LoadField: r2 = r0->field_7f
    //     0x6eab68: ldur            w2, [x0, #0x7f]
    // 0x6eab6c: DecompressPointer r2
    //     0x6eab6c: add             x2, x2, HEAP, lsl #32
    // 0x6eab70: stp             x2, x3, [SP, #-0x10]!
    // 0x6eab74: r0 = ==()
    //     0x6eab74: bl              #0xcbbae4  ; [dart:core] _Double::==
    // 0x6eab78: add             SP, SP, #0x10
    // 0x6eab7c: tbz             w0, #4, #0x6eab98
    // 0x6eab80: ldur            x0, [fp, #-8]
    // 0x6eab84: LoadField: r1 = r0->field_f
    //     0x6eab84: ldur            w1, [x0, #0xf]
    // 0x6eab88: DecompressPointer r1
    //     0x6eab88: add             x1, x1, HEAP, lsl #32
    // 0x6eab8c: SaveReg r1
    //     0x6eab8c: str             x1, [SP, #-8]!
    // 0x6eab90: r0 = markNeedsLayout()
    //     0x6eab90: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6eab94: add             SP, SP, #8
    // 0x6eab98: r0 = Null
    //     0x6eab98: mov             x0, NULL
    // 0x6eab9c: LeaveFrame
    //     0x6eab9c: mov             SP, fp
    //     0x6eaba0: ldp             fp, lr, [SP], #0x10
    // 0x6eaba4: ret
    //     0x6eaba4: ret             
    // 0x6eaba8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6eaba8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6eabac: b               #0x6eab38
    // 0x6eabb0: r9 = _controller
    //     0x6eabb0: add             x9, PP, #0x52, lsl #12  ; [pp+0x52b68] Field <RenderAnimatedSize._controller@890160358>: late final (offset: 0x70)
    //     0x6eabb4: ldr             x9, [x9, #0xb68]
    // 0x6eabb8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6eabb8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6eabbc: r9 = _value
    //     0x6eabbc: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x6eabc0: ldr             x9, [x9, #0xbb0]
    // 0x6eabc4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6eabc4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bd568, size: 0x98
    // 0x9bd568: EnterFrame
    //     0x9bd568: stp             fp, lr, [SP, #-0x10]!
    //     0x9bd56c: mov             fp, SP
    // 0x9bd570: CheckStackOverflow
    //     0x9bd570: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bd574: cmp             SP, x16
    //     0x9bd578: b.ls            #0x9bd5f8
    // 0x9bd57c: ldr             x0, [fp, #0x10]
    // 0x9bd580: r2 = Null
    //     0x9bd580: mov             x2, NULL
    // 0x9bd584: r1 = Null
    //     0x9bd584: mov             x1, NULL
    // 0x9bd588: r4 = 59
    //     0x9bd588: mov             x4, #0x3b
    // 0x9bd58c: branchIfSmi(r0, 0x9bd598)
    //     0x9bd58c: tbz             w0, #0, #0x9bd598
    // 0x9bd590: r4 = LoadClassIdInstr(r0)
    //     0x9bd590: ldur            x4, [x0, #-1]
    //     0x9bd594: ubfx            x4, x4, #0xc, #0x14
    // 0x9bd598: cmp             x4, #0x7e6
    // 0x9bd59c: b.eq            #0x9bd5b0
    // 0x9bd5a0: r8 = PipelineOwner
    //     0x9bd5a0: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9bd5a4: r3 = Null
    //     0x9bd5a4: add             x3, PP, #0x55, lsl #12  ; [pp+0x55730] Null
    //     0x9bd5a8: ldr             x3, [x3, #0x730]
    // 0x9bd5ac: r0 = DefaultTypeTest()
    //     0x9bd5ac: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bd5b0: ldr             x16, [fp, #0x18]
    // 0x9bd5b4: ldr             lr, [fp, #0x10]
    // 0x9bd5b8: stp             lr, x16, [SP, #-0x10]!
    // 0x9bd5bc: r0 = attach()
    //     0x9bd5bc: bl              #0x9bd674  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::attach
    // 0x9bd5c0: add             SP, SP, #0x10
    // 0x9bd5c4: ldr             x0, [fp, #0x18]
    // 0x9bd5c8: LoadField: r1 = r0->field_83
    //     0x9bd5c8: ldur            w1, [x0, #0x83]
    // 0x9bd5cc: DecompressPointer r1
    //     0x9bd5cc: add             x1, x1, HEAP, lsl #32
    // 0x9bd5d0: LoadField: r2 = r1->field_7
    //     0x9bd5d0: ldur            x2, [x1, #7]
    // 0x9bd5d4: cmp             x2, #1
    // 0x9bd5d8: b.le            #0x9bd5e8
    // 0x9bd5dc: SaveReg r0
    //     0x9bd5dc: str             x0, [SP, #-8]!
    // 0x9bd5e0: r0 = markNeedsLayout()
    //     0x9bd5e0: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x9bd5e4: add             SP, SP, #8
    // 0x9bd5e8: r0 = Null
    //     0x9bd5e8: mov             x0, NULL
    // 0x9bd5ec: LeaveFrame
    //     0x9bd5ec: mov             SP, fp
    //     0x9bd5f0: ldp             fp, lr, [SP], #0x10
    // 0x9bd5f4: ret
    //     0x9bd5f4: ret             
    // 0x9bd5f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bd5f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bd5fc: b               #0x9bd57c
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5ddd0, size: 0x238
    // 0xa5ddd0: EnterFrame
    //     0xa5ddd0: stp             fp, lr, [SP, #-0x10]!
    //     0xa5ddd4: mov             fp, SP
    // 0xa5ddd8: AllocStack(0x8)
    //     0xa5ddd8: sub             SP, SP, #8
    // 0xa5dddc: CheckStackOverflow
    //     0xa5dddc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5dde0: cmp             SP, x16
    //     0xa5dde4: b.ls            #0xa5dfe0
    // 0xa5dde8: ldr             x0, [fp, #0x18]
    // 0xa5ddec: LoadField: r1 = r0->field_5f
    //     0xa5ddec: ldur            w1, [x0, #0x5f]
    // 0xa5ddf0: DecompressPointer r1
    //     0xa5ddf0: add             x1, x1, HEAP, lsl #32
    // 0xa5ddf4: cmp             w1, NULL
    // 0xa5ddf8: b.ne            #0xa5de04
    // 0xa5ddfc: ldr             x2, [fp, #0x10]
    // 0xa5de00: b               #0xa5de30
    // 0xa5de04: ldr             x2, [fp, #0x10]
    // 0xa5de08: LoadField: d0 = r2->field_7
    //     0xa5de08: ldur            d0, [x2, #7]
    // 0xa5de0c: LoadField: d1 = r2->field_f
    //     0xa5de0c: ldur            d1, [x2, #0xf]
    // 0xa5de10: fcmp            d0, d1
    // 0xa5de14: b.vs            #0xa5de48
    // 0xa5de18: b.lt            #0xa5de48
    // 0xa5de1c: LoadField: d0 = r2->field_17
    //     0xa5de1c: ldur            d0, [x2, #0x17]
    // 0xa5de20: LoadField: d1 = r2->field_1f
    //     0xa5de20: ldur            d1, [x2, #0x1f]
    // 0xa5de24: fcmp            d0, d1
    // 0xa5de28: b.vs            #0xa5de48
    // 0xa5de2c: b.lt            #0xa5de48
    // 0xa5de30: SaveReg r2
    //     0xa5de30: str             x2, [SP, #-8]!
    // 0xa5de34: r0 = smallest()
    //     0xa5de34: bl              #0x62bd18  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xa5de38: add             SP, SP, #8
    // 0xa5de3c: LeaveFrame
    //     0xa5de3c: mov             SP, fp
    //     0xa5de40: ldp             fp, lr, [SP], #0x10
    // 0xa5de44: ret
    //     0xa5de44: ret             
    // 0xa5de48: stp             x2, x1, [SP, #-0x10]!
    // 0xa5de4c: r0 = getDryLayout()
    //     0xa5de4c: bl              #0x62d394  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xa5de50: add             SP, SP, #0x10
    // 0xa5de54: mov             x2, x0
    // 0xa5de58: ldr             x1, [fp, #0x18]
    // 0xa5de5c: stur            x2, [fp, #-8]
    // 0xa5de60: LoadField: r0 = r1->field_83
    //     0xa5de60: ldur            w0, [x1, #0x83]
    // 0xa5de64: DecompressPointer r0
    //     0xa5de64: add             x0, x0, HEAP, lsl #32
    // 0xa5de68: LoadField: r3 = r0->field_7
    //     0xa5de68: ldur            x3, [x0, #7]
    // 0xa5de6c: cmp             x3, #1
    // 0xa5de70: b.gt            #0xa5df58
    // 0xa5de74: cmp             x3, #0
    // 0xa5de78: b.gt            #0xa5de98
    // 0xa5de7c: ldr             x16, [fp, #0x10]
    // 0xa5de80: stp             x2, x16, [SP, #-0x10]!
    // 0xa5de84: r0 = constrain()
    //     0xa5de84: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xa5de88: add             SP, SP, #0x10
    // 0xa5de8c: LeaveFrame
    //     0xa5de8c: mov             SP, fp
    //     0xa5de90: ldp             fp, lr, [SP], #0x10
    // 0xa5de94: ret
    //     0xa5de94: ret             
    // 0xa5de98: LoadField: r0 = r1->field_77
    //     0xa5de98: ldur            w0, [x1, #0x77]
    // 0xa5de9c: DecompressPointer r0
    //     0xa5de9c: add             x0, x0, HEAP, lsl #32
    // 0xa5dea0: LoadField: r3 = r0->field_f
    //     0xa5dea0: ldur            w3, [x0, #0xf]
    // 0xa5dea4: DecompressPointer r3
    //     0xa5dea4: add             x3, x3, HEAP, lsl #32
    // 0xa5dea8: r0 = LoadClassIdInstr(r3)
    //     0xa5dea8: ldur            x0, [x3, #-1]
    //     0xa5deac: ubfx            x0, x0, #0xc, #0x14
    // 0xa5deb0: stp             x2, x3, [SP, #-0x10]!
    // 0xa5deb4: mov             lr, x0
    // 0xa5deb8: ldr             lr, [x21, lr, lsl #3]
    // 0xa5debc: blr             lr
    // 0xa5dec0: add             SP, SP, #0x10
    // 0xa5dec4: tbz             w0, #4, #0xa5def8
    // 0xa5dec8: ldr             x1, [fp, #0x18]
    // 0xa5decc: LoadField: r0 = r1->field_57
    //     0xa5decc: ldur            w0, [x1, #0x57]
    // 0xa5ded0: DecompressPointer r0
    //     0xa5ded0: add             x0, x0, HEAP, lsl #32
    // 0xa5ded4: cmp             w0, NULL
    // 0xa5ded8: b.eq            #0xa5dfe8
    // 0xa5dedc: ldr             x16, [fp, #0x10]
    // 0xa5dee0: stp             x0, x16, [SP, #-0x10]!
    // 0xa5dee4: r0 = constrain()
    //     0xa5dee4: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xa5dee8: add             SP, SP, #0x10
    // 0xa5deec: LeaveFrame
    //     0xa5deec: mov             SP, fp
    //     0xa5def0: ldp             fp, lr, [SP], #0x10
    // 0xa5def4: ret
    //     0xa5def4: ret             
    // 0xa5def8: ldr             x1, [fp, #0x18]
    // 0xa5defc: LoadField: r0 = r1->field_6f
    //     0xa5defc: ldur            w0, [x1, #0x6f]
    // 0xa5df00: DecompressPointer r0
    //     0xa5df00: add             x0, x0, HEAP, lsl #32
    // 0xa5df04: r16 = Sentinel
    //     0xa5df04: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa5df08: cmp             w0, w16
    // 0xa5df0c: b.eq            #0xa5dfec
    // 0xa5df10: LoadField: r2 = r0->field_37
    //     0xa5df10: ldur            w2, [x0, #0x37]
    // 0xa5df14: DecompressPointer r2
    //     0xa5df14: add             x2, x2, HEAP, lsl #32
    // 0xa5df18: r16 = Sentinel
    //     0xa5df18: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa5df1c: cmp             w2, w16
    // 0xa5df20: b.eq            #0xa5dff8
    // 0xa5df24: LoadField: d0 = r0->field_1b
    //     0xa5df24: ldur            d0, [x0, #0x1b]
    // 0xa5df28: LoadField: d1 = r2->field_7
    //     0xa5df28: ldur            d1, [x2, #7]
    // 0xa5df2c: fcmp            d1, d0
    // 0xa5df30: b.vs            #0xa5dfac
    // 0xa5df34: b.ne            #0xa5dfac
    // 0xa5df38: ldr             x16, [fp, #0x10]
    // 0xa5df3c: ldur            lr, [fp, #-8]
    // 0xa5df40: stp             lr, x16, [SP, #-0x10]!
    // 0xa5df44: r0 = constrain()
    //     0xa5df44: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xa5df48: add             SP, SP, #0x10
    // 0xa5df4c: LeaveFrame
    //     0xa5df4c: mov             SP, fp
    //     0xa5df50: ldp             fp, lr, [SP], #0x10
    // 0xa5df54: ret
    //     0xa5df54: ret             
    // 0xa5df58: LoadField: r0 = r1->field_77
    //     0xa5df58: ldur            w0, [x1, #0x77]
    // 0xa5df5c: DecompressPointer r0
    //     0xa5df5c: add             x0, x0, HEAP, lsl #32
    // 0xa5df60: LoadField: r2 = r0->field_f
    //     0xa5df60: ldur            w2, [x0, #0xf]
    // 0xa5df64: DecompressPointer r2
    //     0xa5df64: add             x2, x2, HEAP, lsl #32
    // 0xa5df68: r0 = LoadClassIdInstr(r2)
    //     0xa5df68: ldur            x0, [x2, #-1]
    //     0xa5df6c: ubfx            x0, x0, #0xc, #0x14
    // 0xa5df70: ldur            x16, [fp, #-8]
    // 0xa5df74: stp             x16, x2, [SP, #-0x10]!
    // 0xa5df78: mov             lr, x0
    // 0xa5df7c: ldr             lr, [x21, lr, lsl #3]
    // 0xa5df80: blr             lr
    // 0xa5df84: add             SP, SP, #0x10
    // 0xa5df88: tbz             w0, #4, #0xa5dfac
    // 0xa5df8c: ldr             x16, [fp, #0x10]
    // 0xa5df90: ldur            lr, [fp, #-8]
    // 0xa5df94: stp             lr, x16, [SP, #-0x10]!
    // 0xa5df98: r0 = constrain()
    //     0xa5df98: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xa5df9c: add             SP, SP, #0x10
    // 0xa5dfa0: LeaveFrame
    //     0xa5dfa0: mov             SP, fp
    //     0xa5dfa4: ldp             fp, lr, [SP], #0x10
    // 0xa5dfa8: ret
    //     0xa5dfa8: ret             
    // 0xa5dfac: ldr             x16, [fp, #0x18]
    // 0xa5dfb0: SaveReg r16
    //     0xa5dfb0: str             x16, [SP, #-8]!
    // 0xa5dfb4: r0 = _animatedSize()
    //     0xa5dfb4: bl              #0x6913c8  ; [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::_animatedSize
    // 0xa5dfb8: add             SP, SP, #8
    // 0xa5dfbc: cmp             w0, NULL
    // 0xa5dfc0: b.eq            #0xa5e004
    // 0xa5dfc4: ldr             x16, [fp, #0x10]
    // 0xa5dfc8: stp             x0, x16, [SP, #-0x10]!
    // 0xa5dfcc: r0 = constrain()
    //     0xa5dfcc: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xa5dfd0: add             SP, SP, #0x10
    // 0xa5dfd4: LeaveFrame
    //     0xa5dfd4: mov             SP, fp
    //     0xa5dfd8: ldp             fp, lr, [SP], #0x10
    // 0xa5dfdc: ret
    //     0xa5dfdc: ret             
    // 0xa5dfe0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5dfe0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5dfe4: b               #0xa5dde8
    // 0xa5dfe8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa5dfe8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa5dfec: r9 = _controller
    //     0xa5dfec: add             x9, PP, #0x52, lsl #12  ; [pp+0x52b68] Field <RenderAnimatedSize._controller@890160358>: late final (offset: 0x70)
    //     0xa5dff0: ldr             x9, [x9, #0xb68]
    // 0xa5dff4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa5dff4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa5dff8: r9 = _value
    //     0xa5dff8: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0xa5dffc: ldr             x9, [x9, #0xbb0]
    // 0xa5e000: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa5e000: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa5e004: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa5e004: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ detach(/* No info */) {
    // ** addr: 0xa69334, size: 0x70
    // 0xa69334: EnterFrame
    //     0xa69334: stp             fp, lr, [SP, #-0x10]!
    //     0xa69338: mov             fp, SP
    // 0xa6933c: CheckStackOverflow
    //     0xa6933c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa69340: cmp             SP, x16
    //     0xa69344: b.ls            #0xa69390
    // 0xa69348: ldr             x0, [fp, #0x10]
    // 0xa6934c: LoadField: r1 = r0->field_6f
    //     0xa6934c: ldur            w1, [x0, #0x6f]
    // 0xa69350: DecompressPointer r1
    //     0xa69350: add             x1, x1, HEAP, lsl #32
    // 0xa69354: r16 = Sentinel
    //     0xa69354: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa69358: cmp             w1, w16
    // 0xa6935c: b.eq            #0xa69398
    // 0xa69360: SaveReg r1
    //     0xa69360: str             x1, [SP, #-8]!
    // 0xa69364: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa69364: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa69368: r0 = stop()
    //     0xa69368: bl              #0x593468  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0xa6936c: add             SP, SP, #8
    // 0xa69370: ldr             x16, [fp, #0x10]
    // 0xa69374: SaveReg r16
    //     0xa69374: str             x16, [SP, #-8]!
    // 0xa69378: r0 = detach()
    //     0xa69378: bl              #0xa693e0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::detach
    // 0xa6937c: add             SP, SP, #8
    // 0xa69380: r0 = Null
    //     0xa69380: mov             x0, NULL
    // 0xa69384: LeaveFrame
    //     0xa69384: mov             SP, fp
    //     0xa69388: ldp             fp, lr, [SP], #0x10
    // 0xa6938c: ret
    //     0xa6938c: ret             
    // 0xa69390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa69390: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa69394: b               #0xa69348
    // 0xa69398: r9 = _controller
    //     0xa69398: add             x9, PP, #0x52, lsl #12  ; [pp+0x52b68] Field <RenderAnimatedSize._controller@890160358>: late final (offset: 0x70)
    //     0xa6939c: ldr             x9, [x9, #0xb68]
    // 0xa693a0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa693a0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 5929, size: 0x14, field offset: 0x14
enum RenderAnimatedSizeState extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16b48, size: 0x5c
    // 0xb16b48: EnterFrame
    //     0xb16b48: stp             fp, lr, [SP, #-0x10]!
    //     0xb16b4c: mov             fp, SP
    // 0xb16b50: CheckStackOverflow
    //     0xb16b50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16b54: cmp             SP, x16
    //     0xb16b58: b.ls            #0xb16b9c
    // 0xb16b5c: r1 = Null
    //     0xb16b5c: mov             x1, NULL
    // 0xb16b60: r2 = 4
    //     0xb16b60: mov             x2, #4
    // 0xb16b64: r0 = AllocateArray()
    //     0xb16b64: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16b68: r17 = "RenderAnimatedSizeState."
    //     0xb16b68: add             x17, PP, #0x55, lsl #12  ; [pp+0x55688] "RenderAnimatedSizeState."
    //     0xb16b6c: ldr             x17, [x17, #0x688]
    // 0xb16b70: StoreField: r0->field_f = r17
    //     0xb16b70: stur            w17, [x0, #0xf]
    // 0xb16b74: ldr             x1, [fp, #0x10]
    // 0xb16b78: LoadField: r2 = r1->field_f
    //     0xb16b78: ldur            w2, [x1, #0xf]
    // 0xb16b7c: DecompressPointer r2
    //     0xb16b7c: add             x2, x2, HEAP, lsl #32
    // 0xb16b80: StoreField: r0->field_13 = r2
    //     0xb16b80: stur            w2, [x0, #0x13]
    // 0xb16b84: SaveReg r0
    //     0xb16b84: str             x0, [SP, #-8]!
    // 0xb16b88: r0 = _interpolate()
    //     0xb16b88: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16b8c: add             SP, SP, #8
    // 0xb16b90: LeaveFrame
    //     0xb16b90: mov             SP, fp
    //     0xb16b94: ldp             fp, lr, [SP], #0x10
    // 0xb16b98: ret
    //     0xb16b98: ret             
    // 0xb16b9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16b9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16ba0: b               #0xb16b5c
  }
}

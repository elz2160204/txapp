// lib: , url: package:flutter/src/rendering/box.dart

// class id: 1049395, size: 0x8
class :: {
}

// class id: 2033, size: 0x14, field offset: 0x8
//   const constructor, 
class _IntrinsicDimensionsCacheEntry extends Object {

  _ ==(/* No info */) {
    // ** addr: 0xc9eef8, size: 0x7c
    // 0xc9eef8: ldr             x1, [SP]
    // 0xc9eefc: cmp             w1, NULL
    // 0xc9ef00: b.ne            #0xc9ef0c
    // 0xc9ef04: r0 = false
    //     0xc9ef04: add             x0, NULL, #0x30  ; false
    // 0xc9ef08: ret
    //     0xc9ef08: ret             
    // 0xc9ef0c: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc9ef0c: mov             x2, #0x76
    //     0xc9ef10: tbz             w1, #0, #0xc9ef20
    //     0xc9ef14: ldur            x2, [x1, #-1]
    //     0xc9ef18: ubfx            x2, x2, #0xc, #0x14
    //     0xc9ef1c: lsl             x2, x2, #1
    // 0xc9ef20: cmp             w2, #0xfe2
    // 0xc9ef24: b.ne            #0xc9ef6c
    // 0xc9ef28: ldr             x2, [SP, #8]
    // 0xc9ef2c: LoadField: r3 = r1->field_7
    //     0xc9ef2c: ldur            w3, [x1, #7]
    // 0xc9ef30: DecompressPointer r3
    //     0xc9ef30: add             x3, x3, HEAP, lsl #32
    // 0xc9ef34: LoadField: r4 = r2->field_7
    //     0xc9ef34: ldur            w4, [x2, #7]
    // 0xc9ef38: DecompressPointer r4
    //     0xc9ef38: add             x4, x4, HEAP, lsl #32
    // 0xc9ef3c: cmp             w3, w4
    // 0xc9ef40: b.ne            #0xc9ef6c
    // 0xc9ef44: LoadField: d0 = r1->field_b
    //     0xc9ef44: ldur            d0, [x1, #0xb]
    // 0xc9ef48: LoadField: d1 = r2->field_b
    //     0xc9ef48: ldur            d1, [x2, #0xb]
    // 0xc9ef4c: fcmp            d0, d1
    // 0xc9ef50: b.vs            #0xc9ef58
    // 0xc9ef54: b.eq            #0xc9ef60
    // 0xc9ef58: r1 = false
    //     0xc9ef58: add             x1, NULL, #0x30  ; false
    // 0xc9ef5c: b               #0xc9ef64
    // 0xc9ef60: r1 = true
    //     0xc9ef60: add             x1, NULL, #0x20  ; true
    // 0xc9ef64: mov             x0, x1
    // 0xc9ef68: b               #0xc9ef70
    // 0xc9ef6c: r0 = false
    //     0xc9ef6c: add             x0, NULL, #0x30  ; false
    // 0xc9ef70: ret
    //     0xc9ef70: ret             
  }
}

// class id: 2047, size: 0xc, field offset: 0x8
class BoxParentData extends ParentData {

  _ toString(/* No info */) {
    // ** addr: 0xae516c, size: 0x5c
    // 0xae516c: EnterFrame
    //     0xae516c: stp             fp, lr, [SP, #-0x10]!
    //     0xae5170: mov             fp, SP
    // 0xae5174: CheckStackOverflow
    //     0xae5174: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae5178: cmp             SP, x16
    //     0xae517c: b.ls            #0xae51c0
    // 0xae5180: r1 = Null
    //     0xae5180: mov             x1, NULL
    // 0xae5184: r2 = 4
    //     0xae5184: mov             x2, #4
    // 0xae5188: r0 = AllocateArray()
    //     0xae5188: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae518c: r17 = "offset="
    //     0xae518c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc7c0] "offset="
    //     0xae5190: ldr             x17, [x17, #0x7c0]
    // 0xae5194: StoreField: r0->field_f = r17
    //     0xae5194: stur            w17, [x0, #0xf]
    // 0xae5198: ldr             x1, [fp, #0x10]
    // 0xae519c: LoadField: r2 = r1->field_7
    //     0xae519c: ldur            w2, [x1, #7]
    // 0xae51a0: DecompressPointer r2
    //     0xae51a0: add             x2, x2, HEAP, lsl #32
    // 0xae51a4: StoreField: r0->field_13 = r2
    //     0xae51a4: stur            w2, [x0, #0x13]
    // 0xae51a8: SaveReg r0
    //     0xae51a8: str             x0, [SP, #-8]!
    // 0xae51ac: r0 = _interpolate()
    //     0xae51ac: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae51b0: add             SP, SP, #8
    // 0xae51b4: LeaveFrame
    //     0xae51b4: mov             SP, fp
    //     0xae51b8: ldp             fp, lr, [SP], #0x10
    // 0xae51bc: ret
    //     0xae51bc: ret             
    // 0xae51c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae51c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae51c4: b               #0xae5180
  }
}

// class id: 2049, size: 0x18, field offset: 0xc
//   transformed mixin,
abstract class _ContainerBoxParentData&BoxParentData&ContainerParentDataMixin<X0 bound RenderObject> extends BoxParentData
     with ContainerParentDataMixin<X0 bound RenderObject> {

  set _ nextSibling=(/* No info */) {
    // ** addr: 0xceee6c, size: 0x80
    // 0xceee6c: EnterFrame
    //     0xceee6c: stp             fp, lr, [SP, #-0x10]!
    //     0xceee70: mov             fp, SP
    // 0xceee74: ldr             x3, [fp, #0x18]
    // 0xceee78: LoadField: r2 = r3->field_b
    //     0xceee78: ldur            w2, [x3, #0xb]
    // 0xceee7c: DecompressPointer r2
    //     0xceee7c: add             x2, x2, HEAP, lsl #32
    // 0xceee80: ldr             x0, [fp, #0x10]
    // 0xceee84: r1 = Null
    //     0xceee84: mov             x1, NULL
    // 0xceee88: cmp             w0, NULL
    // 0xceee8c: b.eq            #0xceeeb8
    // 0xceee90: cmp             w2, NULL
    // 0xceee94: b.eq            #0xceeeb8
    // 0xceee98: LoadField: r4 = r2->field_17
    //     0xceee98: ldur            w4, [x2, #0x17]
    // 0xceee9c: DecompressPointer r4
    //     0xceee9c: add             x4, x4, HEAP, lsl #32
    // 0xceeea0: r8 = X0? bound RenderObject
    //     0xceeea0: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0xceeea4: ldr             x8, [x8, #0x6e8]
    // 0xceeea8: LoadField: r9 = r4->field_7
    //     0xceeea8: ldur            x9, [x4, #7]
    // 0xceeeac: r3 = Null
    //     0xceeeac: add             x3, PP, #0x51, lsl #12  ; [pp+0x51220] Null
    //     0xceeeb0: ldr             x3, [x3, #0x220]
    // 0xceeeb4: blr             x9
    // 0xceeeb8: ldr             x0, [fp, #0x10]
    // 0xceeebc: ldr             x1, [fp, #0x18]
    // 0xceeec0: StoreField: r1->field_13 = r0
    //     0xceeec0: stur            w0, [x1, #0x13]
    //     0xceeec4: ldurb           w16, [x1, #-1]
    //     0xceeec8: ldurb           w17, [x0, #-1]
    //     0xceeecc: and             x16, x17, x16, lsr #2
    //     0xceeed0: tst             x16, HEAP, lsr #32
    //     0xceeed4: b.eq            #0xceeedc
    //     0xceeed8: bl              #0xd6826c
    // 0xceeedc: r0 = Null
    //     0xceeedc: mov             x0, NULL
    // 0xceeee0: LeaveFrame
    //     0xceeee0: mov             SP, fp
    //     0xceeee4: ldp             fp, lr, [SP], #0x10
    // 0xceeee8: ret
    //     0xceeee8: ret             
  }
  set _ previousSibling=(/* No info */) {
    // ** addr: 0xcef54c, size: 0x80
    // 0xcef54c: EnterFrame
    //     0xcef54c: stp             fp, lr, [SP, #-0x10]!
    //     0xcef550: mov             fp, SP
    // 0xcef554: ldr             x3, [fp, #0x18]
    // 0xcef558: LoadField: r2 = r3->field_b
    //     0xcef558: ldur            w2, [x3, #0xb]
    // 0xcef55c: DecompressPointer r2
    //     0xcef55c: add             x2, x2, HEAP, lsl #32
    // 0xcef560: ldr             x0, [fp, #0x10]
    // 0xcef564: r1 = Null
    //     0xcef564: mov             x1, NULL
    // 0xcef568: cmp             w0, NULL
    // 0xcef56c: b.eq            #0xcef598
    // 0xcef570: cmp             w2, NULL
    // 0xcef574: b.eq            #0xcef598
    // 0xcef578: LoadField: r4 = r2->field_17
    //     0xcef578: ldur            w4, [x2, #0x17]
    // 0xcef57c: DecompressPointer r4
    //     0xcef57c: add             x4, x4, HEAP, lsl #32
    // 0xcef580: r8 = X0? bound RenderObject
    //     0xcef580: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0xcef584: ldr             x8, [x8, #0x6e8]
    // 0xcef588: LoadField: r9 = r4->field_7
    //     0xcef588: ldur            x9, [x4, #7]
    // 0xcef58c: r3 = Null
    //     0xcef58c: add             x3, PP, #0x51, lsl #12  ; [pp+0x51230] Null
    //     0xcef590: ldr             x3, [x3, #0x230]
    // 0xcef594: blr             x9
    // 0xcef598: ldr             x0, [fp, #0x10]
    // 0xcef59c: ldr             x1, [fp, #0x18]
    // 0xcef5a0: StoreField: r1->field_f = r0
    //     0xcef5a0: stur            w0, [x1, #0xf]
    //     0xcef5a4: ldurb           w16, [x1, #-1]
    //     0xcef5a8: ldurb           w17, [x0, #-1]
    //     0xcef5ac: and             x16, x17, x16, lsr #2
    //     0xcef5b0: tst             x16, HEAP, lsr #32
    //     0xcef5b4: b.eq            #0xcef5bc
    //     0xcef5b8: bl              #0xd6826c
    // 0xcef5bc: r0 = Null
    //     0xcef5bc: mov             x0, NULL
    // 0xcef5c0: LeaveFrame
    //     0xcef5c0: mov             SP, fp
    //     0xcef5c4: ldp             fp, lr, [SP], #0x10
    // 0xcef5c8: ret
    //     0xcef5c8: ret             
  }
}

// class id: 2050, size: 0x18, field offset: 0x18
abstract class ContainerBoxParentData<X0 bound RenderObject> extends _ContainerBoxParentData&BoxParentData&ContainerParentDataMixin<X0 bound RenderObject> {
}

// class id: 2061, size: 0x28, field offset: 0x8
//   const constructor, 
class BoxConstraints extends Constraints {

  _Double field_8;
  _Double field_10;
  _Double field_18;
  _Double field_20;

  BoxConstraints /(BoxConstraints, double) {
    // ** addr: 0x5241c4, size: 0x88
    // 0x5241c4: EnterFrame
    //     0x5241c4: stp             fp, lr, [SP, #-0x10]!
    //     0x5241c8: mov             fp, SP
    // 0x5241cc: CheckStackOverflow
    //     0x5241cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5241d0: cmp             SP, x16
    //     0x5241d4: b.ls            #0x52422c
    // 0x5241d8: ldr             x0, [fp, #0x10]
    // 0x5241dc: r2 = Null
    //     0x5241dc: mov             x2, NULL
    // 0x5241e0: r1 = Null
    //     0x5241e0: mov             x1, NULL
    // 0x5241e4: r4 = 59
    //     0x5241e4: mov             x4, #0x3b
    // 0x5241e8: branchIfSmi(r0, 0x5241f4)
    //     0x5241e8: tbz             w0, #0, #0x5241f4
    // 0x5241ec: r4 = LoadClassIdInstr(r0)
    //     0x5241ec: ldur            x4, [x0, #-1]
    //     0x5241f0: ubfx            x4, x4, #0xc, #0x14
    // 0x5241f4: cmp             x4, #0x3d
    // 0x5241f8: b.eq            #0x52420c
    // 0x5241fc: r8 = double
    //     0x5241fc: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0x524200: r3 = Null
    //     0x524200: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c138] Null
    //     0x524204: ldr             x3, [x3, #0x138]
    // 0x524208: r0 = double()
    //     0x524208: bl              #0xd72bac  ; IsType_double_Stub
    // 0x52420c: ldr             x16, [fp, #0x18]
    // 0x524210: ldr             lr, [fp, #0x10]
    // 0x524214: stp             lr, x16, [SP, #-0x10]!
    // 0x524218: r0 = /()
    //     0x524218: bl              #0x524234  ; [package:flutter/src/rendering/box.dart] BoxConstraints::/
    // 0x52421c: add             SP, SP, #0x10
    // 0x524220: LeaveFrame
    //     0x524220: mov             SP, fp
    //     0x524224: ldp             fp, lr, [SP], #0x10
    // 0x524228: ret
    //     0x524228: ret             
    // 0x52422c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52422c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x524230: b               #0x5241d8
  }
  BoxConstraints /(BoxConstraints, double) {
    // ** addr: 0x524234, size: 0x78
    // 0x524234: EnterFrame
    //     0x524234: stp             fp, lr, [SP, #-0x10]!
    //     0x524238: mov             fp, SP
    // 0x52423c: AllocStack(0x20)
    //     0x52423c: sub             SP, SP, #0x20
    // 0x524240: ldr             x0, [fp, #0x18]
    // 0x524244: LoadField: d0 = r0->field_7
    //     0x524244: ldur            d0, [x0, #7]
    // 0x524248: ldr             x1, [fp, #0x10]
    // 0x52424c: LoadField: d1 = r1->field_7
    //     0x52424c: ldur            d1, [x1, #7]
    // 0x524250: fdiv            d2, d0, d1
    // 0x524254: stur            d2, [fp, #-0x20]
    // 0x524258: LoadField: d0 = r0->field_f
    //     0x524258: ldur            d0, [x0, #0xf]
    // 0x52425c: fdiv            d3, d0, d1
    // 0x524260: stur            d3, [fp, #-0x18]
    // 0x524264: LoadField: d0 = r0->field_17
    //     0x524264: ldur            d0, [x0, #0x17]
    // 0x524268: fdiv            d4, d0, d1
    // 0x52426c: stur            d4, [fp, #-0x10]
    // 0x524270: LoadField: d0 = r0->field_1f
    //     0x524270: ldur            d0, [x0, #0x1f]
    // 0x524274: fdiv            d5, d0, d1
    // 0x524278: stur            d5, [fp, #-8]
    // 0x52427c: r0 = BoxConstraints()
    //     0x52427c: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x524280: ldur            d0, [fp, #-0x20]
    // 0x524284: StoreField: r0->field_7 = d0
    //     0x524284: stur            d0, [x0, #7]
    // 0x524288: ldur            d0, [fp, #-0x18]
    // 0x52428c: StoreField: r0->field_f = d0
    //     0x52428c: stur            d0, [x0, #0xf]
    // 0x524290: ldur            d0, [fp, #-0x10]
    // 0x524294: StoreField: r0->field_17 = d0
    //     0x524294: stur            d0, [x0, #0x17]
    // 0x524298: ldur            d0, [fp, #-8]
    // 0x52429c: StoreField: r0->field_1f = d0
    //     0x52429c: stur            d0, [x0, #0x1f]
    // 0x5242a0: LeaveFrame
    //     0x5242a0: mov             SP, fp
    //     0x5242a4: ldp             fp, lr, [SP], #0x10
    // 0x5242a8: ret
    //     0x5242a8: ret             
  }
  BoxConstraints *(BoxConstraints, double) {
    // ** addr: 0x5242d0, size: 0x88
    // 0x5242d0: EnterFrame
    //     0x5242d0: stp             fp, lr, [SP, #-0x10]!
    //     0x5242d4: mov             fp, SP
    // 0x5242d8: CheckStackOverflow
    //     0x5242d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5242dc: cmp             SP, x16
    //     0x5242e0: b.ls            #0x524338
    // 0x5242e4: ldr             x0, [fp, #0x10]
    // 0x5242e8: r2 = Null
    //     0x5242e8: mov             x2, NULL
    // 0x5242ec: r1 = Null
    //     0x5242ec: mov             x1, NULL
    // 0x5242f0: r4 = 59
    //     0x5242f0: mov             x4, #0x3b
    // 0x5242f4: branchIfSmi(r0, 0x524300)
    //     0x5242f4: tbz             w0, #0, #0x524300
    // 0x5242f8: r4 = LoadClassIdInstr(r0)
    //     0x5242f8: ldur            x4, [x0, #-1]
    //     0x5242fc: ubfx            x4, x4, #0xc, #0x14
    // 0x524300: cmp             x4, #0x3d
    // 0x524304: b.eq            #0x524318
    // 0x524308: r8 = double
    //     0x524308: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0x52430c: r3 = Null
    //     0x52430c: add             x3, PP, #0x2f, lsl #12  ; [pp+0x2f028] Null
    //     0x524310: ldr             x3, [x3, #0x28]
    // 0x524314: r0 = double()
    //     0x524314: bl              #0xd72bac  ; IsType_double_Stub
    // 0x524318: ldr             x16, [fp, #0x18]
    // 0x52431c: ldr             lr, [fp, #0x10]
    // 0x524320: stp             lr, x16, [SP, #-0x10]!
    // 0x524324: r0 = *()
    //     0x524324: bl              #0x524340  ; [package:flutter/src/rendering/box.dart] BoxConstraints::*
    // 0x524328: add             SP, SP, #0x10
    // 0x52432c: LeaveFrame
    //     0x52432c: mov             SP, fp
    //     0x524330: ldp             fp, lr, [SP], #0x10
    // 0x524334: ret
    //     0x524334: ret             
    // 0x524338: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x524338: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52433c: b               #0x5242e4
  }
  BoxConstraints *(BoxConstraints, double) {
    // ** addr: 0x524340, size: 0x78
    // 0x524340: EnterFrame
    //     0x524340: stp             fp, lr, [SP, #-0x10]!
    //     0x524344: mov             fp, SP
    // 0x524348: AllocStack(0x20)
    //     0x524348: sub             SP, SP, #0x20
    // 0x52434c: ldr             x0, [fp, #0x18]
    // 0x524350: LoadField: d0 = r0->field_7
    //     0x524350: ldur            d0, [x0, #7]
    // 0x524354: ldr             x1, [fp, #0x10]
    // 0x524358: LoadField: d1 = r1->field_7
    //     0x524358: ldur            d1, [x1, #7]
    // 0x52435c: fmul            d2, d0, d1
    // 0x524360: stur            d2, [fp, #-0x20]
    // 0x524364: LoadField: d0 = r0->field_f
    //     0x524364: ldur            d0, [x0, #0xf]
    // 0x524368: fmul            d3, d0, d1
    // 0x52436c: stur            d3, [fp, #-0x18]
    // 0x524370: LoadField: d0 = r0->field_17
    //     0x524370: ldur            d0, [x0, #0x17]
    // 0x524374: fmul            d4, d0, d1
    // 0x524378: stur            d4, [fp, #-0x10]
    // 0x52437c: LoadField: d0 = r0->field_1f
    //     0x52437c: ldur            d0, [x0, #0x1f]
    // 0x524380: fmul            d5, d0, d1
    // 0x524384: stur            d5, [fp, #-8]
    // 0x524388: r0 = BoxConstraints()
    //     0x524388: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x52438c: ldur            d0, [fp, #-0x20]
    // 0x524390: StoreField: r0->field_7 = d0
    //     0x524390: stur            d0, [x0, #7]
    // 0x524394: ldur            d0, [fp, #-0x18]
    // 0x524398: StoreField: r0->field_f = d0
    //     0x524398: stur            d0, [x0, #0xf]
    // 0x52439c: ldur            d0, [fp, #-0x10]
    // 0x5243a0: StoreField: r0->field_17 = d0
    //     0x5243a0: stur            d0, [x0, #0x17]
    // 0x5243a4: ldur            d0, [fp, #-8]
    // 0x5243a8: StoreField: r0->field_1f = d0
    //     0x5243a8: stur            d0, [x0, #0x1f]
    // 0x5243ac: LeaveFrame
    //     0x5243ac: mov             SP, fp
    //     0x5243b0: ldp             fp, lr, [SP], #0x10
    // 0x5243b4: ret
    //     0x5243b4: ret             
  }
  _ tighten(/* No info */) {
    // ** addr: 0x590b84, size: 0x234
    // 0x590b84: EnterFrame
    //     0x590b84: stp             fp, lr, [SP, #-0x10]!
    //     0x590b88: mov             fp, SP
    // 0x590b8c: AllocStack(0x20)
    //     0x590b8c: sub             SP, SP, #0x20
    // 0x590b90: SetupParameters(BoxConstraints this /* r3 */, {dynamic height = Null /* r4 */, dynamic width = Null /* r0 */})
    //     0x590b90: mov             x0, x4
    //     0x590b94: ldur            w1, [x0, #0x13]
    //     0x590b98: add             x1, x1, HEAP, lsl #32
    //     0x590b9c: sub             x2, x1, #2
    //     0x590ba0: add             x3, fp, w2, sxtw #2
    //     0x590ba4: ldr             x3, [x3, #0x10]
    //     0x590ba8: ldur            w2, [x0, #0x1f]
    //     0x590bac: add             x2, x2, HEAP, lsl #32
    //     0x590bb0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb08] "height"
    //     0x590bb4: ldr             x16, [x16, #0xb08]
    //     0x590bb8: cmp             w2, w16
    //     0x590bbc: b.ne            #0x590be0
    //     0x590bc0: ldur            w2, [x0, #0x23]
    //     0x590bc4: add             x2, x2, HEAP, lsl #32
    //     0x590bc8: sub             w4, w1, w2
    //     0x590bcc: add             x2, fp, w4, sxtw #2
    //     0x590bd0: ldr             x2, [x2, #8]
    //     0x590bd4: mov             x4, x2
    //     0x590bd8: mov             x2, #1
    //     0x590bdc: b               #0x590be8
    //     0x590be0: mov             x4, NULL
    //     0x590be4: mov             x2, #0
    //     0x590be8: lsl             x5, x2, #1
    //     0x590bec: lsl             w2, w5, #1
    //     0x590bf0: add             w5, w2, #8
    //     0x590bf4: add             x16, x0, w5, sxtw #1
    //     0x590bf8: ldur            w6, [x16, #0xf]
    //     0x590bfc: add             x6, x6, HEAP, lsl #32
    //     0x590c00: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb30] "width"
    //     0x590c04: ldr             x16, [x16, #0xb30]
    //     0x590c08: cmp             w6, w16
    //     0x590c0c: b.ne            #0x590c34
    //     0x590c10: add             w5, w2, #0xa
    //     0x590c14: add             x16, x0, w5, sxtw #1
    //     0x590c18: ldur            w2, [x16, #0xf]
    //     0x590c1c: add             x2, x2, HEAP, lsl #32
    //     0x590c20: sub             w0, w1, w2
    //     0x590c24: add             x1, fp, w0, sxtw #2
    //     0x590c28: ldr             x1, [x1, #8]
    //     0x590c2c: mov             x0, x1
    //     0x590c30: b               #0x590c38
    //     0x590c34: mov             x0, NULL
    // 0x590c38: cmp             w0, NULL
    // 0x590c3c: b.ne            #0x590c4c
    // 0x590c40: LoadField: d0 = r3->field_7
    //     0x590c40: ldur            d0, [x3, #7]
    // 0x590c44: mov             v1.16b, v0.16b
    // 0x590c48: b               #0x590c88
    // 0x590c4c: LoadField: d0 = r3->field_7
    //     0x590c4c: ldur            d0, [x3, #7]
    // 0x590c50: LoadField: d1 = r3->field_f
    //     0x590c50: ldur            d1, [x3, #0xf]
    // 0x590c54: LoadField: d2 = r0->field_7
    //     0x590c54: ldur            d2, [x0, #7]
    // 0x590c58: fcmp            d2, d0
    // 0x590c5c: b.vs            #0x590c6c
    // 0x590c60: b.ge            #0x590c6c
    // 0x590c64: mov             v1.16b, v0.16b
    // 0x590c68: b               #0x590c88
    // 0x590c6c: fcmp            d2, d1
    // 0x590c70: b.vs            #0x590c78
    // 0x590c74: b.gt            #0x590c88
    // 0x590c78: LoadField: d3 = r0->field_7
    //     0x590c78: ldur            d3, [x0, #7]
    // 0x590c7c: fcmp            d3, d3
    // 0x590c80: b.vs            #0x590c88
    // 0x590c84: mov             v1.16b, v2.16b
    // 0x590c88: stur            d1, [fp, #-0x20]
    // 0x590c8c: cmp             w0, NULL
    // 0x590c90: b.ne            #0x590c9c
    // 0x590c94: LoadField: d0 = r3->field_f
    //     0x590c94: ldur            d0, [x3, #0xf]
    // 0x590c98: b               #0x590cdc
    // 0x590c9c: LoadField: d2 = r3->field_f
    //     0x590c9c: ldur            d2, [x3, #0xf]
    // 0x590ca0: LoadField: d3 = r0->field_7
    //     0x590ca0: ldur            d3, [x0, #7]
    // 0x590ca4: fcmp            d3, d0
    // 0x590ca8: b.vs            #0x590cb0
    // 0x590cac: b.lt            #0x590cdc
    // 0x590cb0: fcmp            d3, d2
    // 0x590cb4: b.vs            #0x590cc4
    // 0x590cb8: b.le            #0x590cc4
    // 0x590cbc: mov             v0.16b, v2.16b
    // 0x590cc0: b               #0x590cdc
    // 0x590cc4: LoadField: d0 = r0->field_7
    //     0x590cc4: ldur            d0, [x0, #7]
    // 0x590cc8: fcmp            d0, d0
    // 0x590ccc: b.vc            #0x590cd8
    // 0x590cd0: mov             v0.16b, v2.16b
    // 0x590cd4: b               #0x590cdc
    // 0x590cd8: mov             v0.16b, v3.16b
    // 0x590cdc: stur            d0, [fp, #-0x18]
    // 0x590ce0: cmp             w4, NULL
    // 0x590ce4: b.ne            #0x590cf4
    // 0x590ce8: LoadField: d2 = r3->field_17
    //     0x590ce8: ldur            d2, [x3, #0x17]
    // 0x590cec: mov             v3.16b, v2.16b
    // 0x590cf0: b               #0x590d30
    // 0x590cf4: LoadField: d2 = r3->field_17
    //     0x590cf4: ldur            d2, [x3, #0x17]
    // 0x590cf8: LoadField: d3 = r3->field_1f
    //     0x590cf8: ldur            d3, [x3, #0x1f]
    // 0x590cfc: LoadField: d4 = r4->field_7
    //     0x590cfc: ldur            d4, [x4, #7]
    // 0x590d00: fcmp            d4, d2
    // 0x590d04: b.vs            #0x590d14
    // 0x590d08: b.ge            #0x590d14
    // 0x590d0c: mov             v3.16b, v2.16b
    // 0x590d10: b               #0x590d30
    // 0x590d14: fcmp            d4, d3
    // 0x590d18: b.vs            #0x590d20
    // 0x590d1c: b.gt            #0x590d30
    // 0x590d20: LoadField: d5 = r4->field_7
    //     0x590d20: ldur            d5, [x4, #7]
    // 0x590d24: fcmp            d5, d5
    // 0x590d28: b.vs            #0x590d30
    // 0x590d2c: mov             v3.16b, v4.16b
    // 0x590d30: stur            d3, [fp, #-0x10]
    // 0x590d34: cmp             w4, NULL
    // 0x590d38: b.ne            #0x590d44
    // 0x590d3c: LoadField: d2 = r3->field_1f
    //     0x590d3c: ldur            d2, [x3, #0x1f]
    // 0x590d40: b               #0x590d84
    // 0x590d44: LoadField: d4 = r3->field_1f
    //     0x590d44: ldur            d4, [x3, #0x1f]
    // 0x590d48: LoadField: d5 = r4->field_7
    //     0x590d48: ldur            d5, [x4, #7]
    // 0x590d4c: fcmp            d5, d2
    // 0x590d50: b.vs            #0x590d58
    // 0x590d54: b.lt            #0x590d84
    // 0x590d58: fcmp            d5, d4
    // 0x590d5c: b.vs            #0x590d6c
    // 0x590d60: b.le            #0x590d6c
    // 0x590d64: mov             v2.16b, v4.16b
    // 0x590d68: b               #0x590d84
    // 0x590d6c: LoadField: d2 = r4->field_7
    //     0x590d6c: ldur            d2, [x4, #7]
    // 0x590d70: fcmp            d2, d2
    // 0x590d74: b.vc            #0x590d80
    // 0x590d78: mov             v2.16b, v4.16b
    // 0x590d7c: b               #0x590d84
    // 0x590d80: mov             v2.16b, v5.16b
    // 0x590d84: stur            d2, [fp, #-8]
    // 0x590d88: r0 = BoxConstraints()
    //     0x590d88: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x590d8c: ldur            d0, [fp, #-0x20]
    // 0x590d90: StoreField: r0->field_7 = d0
    //     0x590d90: stur            d0, [x0, #7]
    // 0x590d94: ldur            d0, [fp, #-0x18]
    // 0x590d98: StoreField: r0->field_f = d0
    //     0x590d98: stur            d0, [x0, #0xf]
    // 0x590d9c: ldur            d0, [fp, #-0x10]
    // 0x590da0: StoreField: r0->field_17 = d0
    //     0x590da0: stur            d0, [x0, #0x17]
    // 0x590da4: ldur            d0, [fp, #-8]
    // 0x590da8: StoreField: r0->field_1f = d0
    //     0x590da8: stur            d0, [x0, #0x1f]
    // 0x590dac: LeaveFrame
    //     0x590dac: mov             SP, fp
    //     0x590db0: ldp             fp, lr, [SP], #0x10
    // 0x590db4: ret
    //     0x590db4: ret             
  }
  _ constrainSizeAndAttemptToPreserveAspectRatio(/* No info */) {
    // ** addr: 0x62ba34, size: 0x1cc
    // 0x62ba34: EnterFrame
    //     0x62ba34: stp             fp, lr, [SP, #-0x10]!
    //     0x62ba38: mov             fp, SP
    // 0x62ba3c: AllocStack(0x10)
    //     0x62ba3c: sub             SP, SP, #0x10
    // 0x62ba40: CheckStackOverflow
    //     0x62ba40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62ba44: cmp             SP, x16
    //     0x62ba48: b.ls            #0x62bbcc
    // 0x62ba4c: ldr             x0, [fp, #0x18]
    // 0x62ba50: LoadField: d0 = r0->field_7
    //     0x62ba50: ldur            d0, [x0, #7]
    // 0x62ba54: LoadField: d1 = r0->field_f
    //     0x62ba54: ldur            d1, [x0, #0xf]
    // 0x62ba58: fcmp            d0, d1
    // 0x62ba5c: b.vs            #0x62ba90
    // 0x62ba60: b.lt            #0x62ba90
    // 0x62ba64: LoadField: d2 = r0->field_17
    //     0x62ba64: ldur            d2, [x0, #0x17]
    // 0x62ba68: LoadField: d3 = r0->field_1f
    //     0x62ba68: ldur            d3, [x0, #0x1f]
    // 0x62ba6c: fcmp            d2, d3
    // 0x62ba70: b.vs            #0x62ba90
    // 0x62ba74: b.lt            #0x62ba90
    // 0x62ba78: SaveReg r0
    //     0x62ba78: str             x0, [SP, #-8]!
    // 0x62ba7c: r0 = smallest()
    //     0x62ba7c: bl              #0x62bd18  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0x62ba80: add             SP, SP, #8
    // 0x62ba84: LeaveFrame
    //     0x62ba84: mov             SP, fp
    //     0x62ba88: ldp             fp, lr, [SP], #0x10
    // 0x62ba8c: ret
    //     0x62ba8c: ret             
    // 0x62ba90: ldr             x1, [fp, #0x10]
    // 0x62ba94: LoadField: d2 = r1->field_7
    //     0x62ba94: ldur            d2, [x1, #7]
    // 0x62ba98: LoadField: d3 = r1->field_f
    //     0x62ba98: ldur            d3, [x1, #0xf]
    // 0x62ba9c: fdiv            d4, d2, d3
    // 0x62baa0: fcmp            d2, d1
    // 0x62baa4: b.vs            #0x62bac0
    // 0x62baa8: b.le            #0x62bac0
    // 0x62baac: fdiv            d2, d1, d4
    // 0x62bab0: mov             v31.16b, v2.16b
    // 0x62bab4: mov             v2.16b, v1.16b
    // 0x62bab8: mov             v1.16b, v31.16b
    // 0x62babc: b               #0x62bac4
    // 0x62bac0: mov             v1.16b, v3.16b
    // 0x62bac4: LoadField: d3 = r0->field_1f
    //     0x62bac4: ldur            d3, [x0, #0x1f]
    // 0x62bac8: fcmp            d1, d3
    // 0x62bacc: b.vs            #0x62bae0
    // 0x62bad0: b.le            #0x62bae0
    // 0x62bad4: fmul            d1, d3, d4
    // 0x62bad8: mov             v2.16b, v1.16b
    // 0x62badc: mov             v1.16b, v3.16b
    // 0x62bae0: fcmp            d2, d0
    // 0x62bae4: b.vs            #0x62bb00
    // 0x62bae8: b.ge            #0x62bb00
    // 0x62baec: fdiv            d1, d0, d4
    // 0x62baf0: mov             v31.16b, v1.16b
    // 0x62baf4: mov             v1.16b, v0.16b
    // 0x62baf8: mov             v0.16b, v31.16b
    // 0x62bafc: b               #0x62bb08
    // 0x62bb00: mov             v0.16b, v1.16b
    // 0x62bb04: mov             v1.16b, v2.16b
    // 0x62bb08: LoadField: d2 = r0->field_17
    //     0x62bb08: ldur            d2, [x0, #0x17]
    // 0x62bb0c: fcmp            d0, d2
    // 0x62bb10: b.vs            #0x62bb24
    // 0x62bb14: b.ge            #0x62bb24
    // 0x62bb18: fmul            d0, d2, d4
    // 0x62bb1c: mov             v1.16b, v0.16b
    // 0x62bb20: mov             v0.16b, v2.16b
    // 0x62bb24: stur            d0, [fp, #-8]
    // 0x62bb28: r1 = inline_Allocate_Double()
    //     0x62bb28: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x62bb2c: add             x1, x1, #0x10
    //     0x62bb30: cmp             x2, x1
    //     0x62bb34: b.ls            #0x62bbd4
    //     0x62bb38: str             x1, [THR, #0x60]  ; THR::top
    //     0x62bb3c: sub             x1, x1, #0xf
    //     0x62bb40: mov             x2, #0xd108
    //     0x62bb44: movk            x2, #3, lsl #16
    //     0x62bb48: stur            x2, [x1, #-1]
    // 0x62bb4c: StoreField: r1->field_7 = d1
    //     0x62bb4c: stur            d1, [x1, #7]
    // 0x62bb50: stp             x1, x0, [SP, #-0x10]!
    // 0x62bb54: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x62bb54: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x62bb58: r0 = constrainWidth()
    //     0x62bb58: bl              #0x62bc8c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0x62bb5c: add             SP, SP, #0x10
    // 0x62bb60: mov             v1.16b, v0.16b
    // 0x62bb64: ldur            d0, [fp, #-8]
    // 0x62bb68: stur            d1, [fp, #-0x10]
    // 0x62bb6c: r0 = inline_Allocate_Double()
    //     0x62bb6c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62bb70: add             x0, x0, #0x10
    //     0x62bb74: cmp             x1, x0
    //     0x62bb78: b.ls            #0x62bbf0
    //     0x62bb7c: str             x0, [THR, #0x60]  ; THR::top
    //     0x62bb80: sub             x0, x0, #0xf
    //     0x62bb84: mov             x1, #0xd108
    //     0x62bb88: movk            x1, #3, lsl #16
    //     0x62bb8c: stur            x1, [x0, #-1]
    // 0x62bb90: StoreField: r0->field_7 = d0
    //     0x62bb90: stur            d0, [x0, #7]
    // 0x62bb94: ldr             x16, [fp, #0x18]
    // 0x62bb98: stp             x0, x16, [SP, #-0x10]!
    // 0x62bb9c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x62bb9c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x62bba0: r0 = constrainHeight()
    //     0x62bba0: bl              #0x62bc00  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0x62bba4: add             SP, SP, #0x10
    // 0x62bba8: stur            d0, [fp, #-8]
    // 0x62bbac: r0 = Size()
    //     0x62bbac: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x62bbb0: ldur            d0, [fp, #-0x10]
    // 0x62bbb4: StoreField: r0->field_7 = d0
    //     0x62bbb4: stur            d0, [x0, #7]
    // 0x62bbb8: ldur            d0, [fp, #-8]
    // 0x62bbbc: StoreField: r0->field_f = d0
    //     0x62bbbc: stur            d0, [x0, #0xf]
    // 0x62bbc0: LeaveFrame
    //     0x62bbc0: mov             SP, fp
    //     0x62bbc4: ldp             fp, lr, [SP], #0x10
    // 0x62bbc8: ret
    //     0x62bbc8: ret             
    // 0x62bbcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62bbcc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62bbd0: b               #0x62ba4c
    // 0x62bbd4: stp             q0, q1, [SP, #-0x20]!
    // 0x62bbd8: SaveReg r0
    //     0x62bbd8: str             x0, [SP, #-8]!
    // 0x62bbdc: r0 = AllocateDouble()
    //     0x62bbdc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62bbe0: mov             x1, x0
    // 0x62bbe4: RestoreReg r0
    //     0x62bbe4: ldr             x0, [SP], #8
    // 0x62bbe8: ldp             q0, q1, [SP], #0x20
    // 0x62bbec: b               #0x62bb4c
    // 0x62bbf0: stp             q0, q1, [SP, #-0x20]!
    // 0x62bbf4: r0 = AllocateDouble()
    //     0x62bbf4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62bbf8: ldp             q0, q1, [SP], #0x20
    // 0x62bbfc: b               #0x62bb90
  }
  _ constrainHeight(/* No info */) {
    // ** addr: 0x62bc00, size: 0x8c
    // 0x62bc00: EnterFrame
    //     0x62bc00: stp             fp, lr, [SP, #-0x10]!
    //     0x62bc04: mov             fp, SP
    // 0x62bc08: mov             x0, x4
    // 0x62bc0c: LoadField: r1 = r0->field_13
    //     0x62bc0c: ldur            w1, [x0, #0x13]
    // 0x62bc10: DecompressPointer r1
    //     0x62bc10: add             x1, x1, HEAP, lsl #32
    // 0x62bc14: sub             x0, x1, #2
    // 0x62bc18: add             x1, fp, w0, sxtw #2
    // 0x62bc1c: ldr             x1, [x1, #0x10]
    // 0x62bc20: cmp             w0, #2
    // 0x62bc24: b.lt            #0x62bc38
    // 0x62bc28: add             x2, fp, w0, sxtw #2
    // 0x62bc2c: ldr             x2, [x2, #8]
    // 0x62bc30: LoadField: d1 = r2->field_7
    //     0x62bc30: ldur            d1, [x2, #7]
    // 0x62bc34: b               #0x62bc3c
    // 0x62bc38: d1 = inf
    //     0x62bc38: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62bc3c: LoadField: d2 = r1->field_17
    //     0x62bc3c: ldur            d2, [x1, #0x17]
    // 0x62bc40: LoadField: d3 = r1->field_1f
    //     0x62bc40: ldur            d3, [x1, #0x1f]
    // 0x62bc44: fcmp            d1, d2
    // 0x62bc48: b.vs            #0x62bc58
    // 0x62bc4c: b.ge            #0x62bc58
    // 0x62bc50: mov             v0.16b, v2.16b
    // 0x62bc54: b               #0x62bc80
    // 0x62bc58: fcmp            d1, d3
    // 0x62bc5c: b.vs            #0x62bc6c
    // 0x62bc60: b.le            #0x62bc6c
    // 0x62bc64: mov             v0.16b, v3.16b
    // 0x62bc68: b               #0x62bc80
    // 0x62bc6c: fcmp            d1, d1
    // 0x62bc70: b.vc            #0x62bc7c
    // 0x62bc74: mov             v0.16b, v3.16b
    // 0x62bc78: b               #0x62bc80
    // 0x62bc7c: mov             v0.16b, v1.16b
    // 0x62bc80: LeaveFrame
    //     0x62bc80: mov             SP, fp
    //     0x62bc84: ldp             fp, lr, [SP], #0x10
    // 0x62bc88: ret
    //     0x62bc88: ret             
  }
  _ constrainWidth(/* No info */) {
    // ** addr: 0x62bc8c, size: 0x8c
    // 0x62bc8c: EnterFrame
    //     0x62bc8c: stp             fp, lr, [SP, #-0x10]!
    //     0x62bc90: mov             fp, SP
    // 0x62bc94: mov             x0, x4
    // 0x62bc98: LoadField: r1 = r0->field_13
    //     0x62bc98: ldur            w1, [x0, #0x13]
    // 0x62bc9c: DecompressPointer r1
    //     0x62bc9c: add             x1, x1, HEAP, lsl #32
    // 0x62bca0: sub             x0, x1, #2
    // 0x62bca4: add             x1, fp, w0, sxtw #2
    // 0x62bca8: ldr             x1, [x1, #0x10]
    // 0x62bcac: cmp             w0, #2
    // 0x62bcb0: b.lt            #0x62bcc4
    // 0x62bcb4: add             x2, fp, w0, sxtw #2
    // 0x62bcb8: ldr             x2, [x2, #8]
    // 0x62bcbc: LoadField: d1 = r2->field_7
    //     0x62bcbc: ldur            d1, [x2, #7]
    // 0x62bcc0: b               #0x62bcc8
    // 0x62bcc4: d1 = inf
    //     0x62bcc4: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62bcc8: LoadField: d2 = r1->field_7
    //     0x62bcc8: ldur            d2, [x1, #7]
    // 0x62bccc: LoadField: d3 = r1->field_f
    //     0x62bccc: ldur            d3, [x1, #0xf]
    // 0x62bcd0: fcmp            d1, d2
    // 0x62bcd4: b.vs            #0x62bce4
    // 0x62bcd8: b.ge            #0x62bce4
    // 0x62bcdc: mov             v0.16b, v2.16b
    // 0x62bce0: b               #0x62bd0c
    // 0x62bce4: fcmp            d1, d3
    // 0x62bce8: b.vs            #0x62bcf8
    // 0x62bcec: b.le            #0x62bcf8
    // 0x62bcf0: mov             v0.16b, v3.16b
    // 0x62bcf4: b               #0x62bd0c
    // 0x62bcf8: fcmp            d1, d1
    // 0x62bcfc: b.vc            #0x62bd08
    // 0x62bd00: mov             v0.16b, v3.16b
    // 0x62bd04: b               #0x62bd0c
    // 0x62bd08: mov             v0.16b, v1.16b
    // 0x62bd0c: LeaveFrame
    //     0x62bd0c: mov             SP, fp
    //     0x62bd10: ldp             fp, lr, [SP], #0x10
    // 0x62bd14: ret
    //     0x62bd14: ret             
  }
  get _ smallest(/* No info */) {
    // ** addr: 0x62bd18, size: 0x78
    // 0x62bd18: EnterFrame
    //     0x62bd18: stp             fp, lr, [SP, #-0x10]!
    //     0x62bd1c: mov             fp, SP
    // 0x62bd20: AllocStack(0x10)
    //     0x62bd20: sub             SP, SP, #0x10
    // 0x62bd24: CheckStackOverflow
    //     0x62bd24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62bd28: cmp             SP, x16
    //     0x62bd2c: b.ls            #0x62bd88
    // 0x62bd30: ldr             x16, [fp, #0x10]
    // 0x62bd34: r30 = 0.000000
    //     0x62bd34: ldr             lr, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x62bd38: stp             lr, x16, [SP, #-0x10]!
    // 0x62bd3c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x62bd3c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x62bd40: r0 = constrainWidth()
    //     0x62bd40: bl              #0x62bc8c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0x62bd44: add             SP, SP, #0x10
    // 0x62bd48: stur            d0, [fp, #-8]
    // 0x62bd4c: ldr             x16, [fp, #0x10]
    // 0x62bd50: r30 = 0.000000
    //     0x62bd50: ldr             lr, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x62bd54: stp             lr, x16, [SP, #-0x10]!
    // 0x62bd58: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x62bd58: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x62bd5c: r0 = constrainHeight()
    //     0x62bd5c: bl              #0x62bc00  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0x62bd60: add             SP, SP, #0x10
    // 0x62bd64: stur            d0, [fp, #-0x10]
    // 0x62bd68: r0 = Size()
    //     0x62bd68: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x62bd6c: ldur            d0, [fp, #-8]
    // 0x62bd70: StoreField: r0->field_7 = d0
    //     0x62bd70: stur            d0, [x0, #7]
    // 0x62bd74: ldur            d0, [fp, #-0x10]
    // 0x62bd78: StoreField: r0->field_f = d0
    //     0x62bd78: stur            d0, [x0, #0xf]
    // 0x62bd7c: LeaveFrame
    //     0x62bd7c: mov             SP, fp
    //     0x62bd80: ldp             fp, lr, [SP], #0x10
    // 0x62bd84: ret
    //     0x62bd84: ret             
    // 0x62bd88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62bd88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62bd8c: b               #0x62bd30
  }
  _ enforce(/* No info */) {
    // ** addr: 0x62bd90, size: 0x144
    // 0x62bd90: EnterFrame
    //     0x62bd90: stp             fp, lr, [SP, #-0x10]!
    //     0x62bd94: mov             fp, SP
    // 0x62bd98: AllocStack(0x20)
    //     0x62bd98: sub             SP, SP, #0x20
    // 0x62bd9c: ldr             x0, [fp, #0x18]
    // 0x62bda0: LoadField: d0 = r0->field_7
    //     0x62bda0: ldur            d0, [x0, #7]
    // 0x62bda4: ldr             x1, [fp, #0x10]
    // 0x62bda8: LoadField: d1 = r1->field_7
    //     0x62bda8: ldur            d1, [x1, #7]
    // 0x62bdac: LoadField: d2 = r1->field_f
    //     0x62bdac: ldur            d2, [x1, #0xf]
    // 0x62bdb0: fcmp            d0, d1
    // 0x62bdb4: b.vs            #0x62bdc4
    // 0x62bdb8: b.ge            #0x62bdc4
    // 0x62bdbc: mov             v0.16b, v1.16b
    // 0x62bdc0: b               #0x62bde4
    // 0x62bdc4: fcmp            d0, d2
    // 0x62bdc8: b.vs            #0x62bdd8
    // 0x62bdcc: b.le            #0x62bdd8
    // 0x62bdd0: mov             v0.16b, v2.16b
    // 0x62bdd4: b               #0x62bde4
    // 0x62bdd8: fcmp            d0, d0
    // 0x62bddc: b.vc            #0x62bde4
    // 0x62bde0: mov             v0.16b, v2.16b
    // 0x62bde4: stur            d0, [fp, #-0x20]
    // 0x62bde8: LoadField: d3 = r0->field_f
    //     0x62bde8: ldur            d3, [x0, #0xf]
    // 0x62bdec: fcmp            d3, d1
    // 0x62bdf0: b.vs            #0x62bdf8
    // 0x62bdf4: b.lt            #0x62be20
    // 0x62bdf8: fcmp            d3, d2
    // 0x62bdfc: b.vs            #0x62be0c
    // 0x62be00: b.le            #0x62be0c
    // 0x62be04: mov             v1.16b, v2.16b
    // 0x62be08: b               #0x62be20
    // 0x62be0c: fcmp            d3, d3
    // 0x62be10: b.vc            #0x62be1c
    // 0x62be14: mov             v1.16b, v2.16b
    // 0x62be18: b               #0x62be20
    // 0x62be1c: mov             v1.16b, v3.16b
    // 0x62be20: stur            d1, [fp, #-0x18]
    // 0x62be24: LoadField: d2 = r0->field_17
    //     0x62be24: ldur            d2, [x0, #0x17]
    // 0x62be28: LoadField: d3 = r1->field_17
    //     0x62be28: ldur            d3, [x1, #0x17]
    // 0x62be2c: LoadField: d4 = r1->field_1f
    //     0x62be2c: ldur            d4, [x1, #0x1f]
    // 0x62be30: fcmp            d2, d3
    // 0x62be34: b.vs            #0x62be44
    // 0x62be38: b.ge            #0x62be44
    // 0x62be3c: mov             v2.16b, v3.16b
    // 0x62be40: b               #0x62be64
    // 0x62be44: fcmp            d2, d4
    // 0x62be48: b.vs            #0x62be58
    // 0x62be4c: b.le            #0x62be58
    // 0x62be50: mov             v2.16b, v4.16b
    // 0x62be54: b               #0x62be64
    // 0x62be58: fcmp            d2, d2
    // 0x62be5c: b.vc            #0x62be64
    // 0x62be60: mov             v2.16b, v4.16b
    // 0x62be64: stur            d2, [fp, #-0x10]
    // 0x62be68: LoadField: d5 = r0->field_1f
    //     0x62be68: ldur            d5, [x0, #0x1f]
    // 0x62be6c: fcmp            d5, d3
    // 0x62be70: b.vs            #0x62be78
    // 0x62be74: b.lt            #0x62bea0
    // 0x62be78: fcmp            d5, d4
    // 0x62be7c: b.vs            #0x62be8c
    // 0x62be80: b.le            #0x62be8c
    // 0x62be84: mov             v3.16b, v4.16b
    // 0x62be88: b               #0x62bea0
    // 0x62be8c: fcmp            d5, d5
    // 0x62be90: b.vc            #0x62be9c
    // 0x62be94: mov             v3.16b, v4.16b
    // 0x62be98: b               #0x62bea0
    // 0x62be9c: mov             v3.16b, v5.16b
    // 0x62bea0: stur            d3, [fp, #-8]
    // 0x62bea4: r0 = BoxConstraints()
    //     0x62bea4: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x62bea8: ldur            d0, [fp, #-0x20]
    // 0x62beac: StoreField: r0->field_7 = d0
    //     0x62beac: stur            d0, [x0, #7]
    // 0x62beb0: ldur            d0, [fp, #-0x18]
    // 0x62beb4: StoreField: r0->field_f = d0
    //     0x62beb4: stur            d0, [x0, #0xf]
    // 0x62beb8: ldur            d0, [fp, #-0x10]
    // 0x62bebc: StoreField: r0->field_17 = d0
    //     0x62bebc: stur            d0, [x0, #0x17]
    // 0x62bec0: ldur            d0, [fp, #-8]
    // 0x62bec4: StoreField: r0->field_1f = d0
    //     0x62bec4: stur            d0, [x0, #0x1f]
    // 0x62bec8: LeaveFrame
    //     0x62bec8: mov             SP, fp
    //     0x62becc: ldp             fp, lr, [SP], #0x10
    // 0x62bed0: ret
    //     0x62bed0: ret             
  }
  _ constrain(/* No info */) {
    // ** addr: 0x62e4a8, size: 0xfc
    // 0x62e4a8: EnterFrame
    //     0x62e4a8: stp             fp, lr, [SP, #-0x10]!
    //     0x62e4ac: mov             fp, SP
    // 0x62e4b0: AllocStack(0x10)
    //     0x62e4b0: sub             SP, SP, #0x10
    // 0x62e4b4: CheckStackOverflow
    //     0x62e4b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62e4b8: cmp             SP, x16
    //     0x62e4bc: b.ls            #0x62e570
    // 0x62e4c0: ldr             x0, [fp, #0x10]
    // 0x62e4c4: LoadField: d0 = r0->field_7
    //     0x62e4c4: ldur            d0, [x0, #7]
    // 0x62e4c8: r1 = inline_Allocate_Double()
    //     0x62e4c8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x62e4cc: add             x1, x1, #0x10
    //     0x62e4d0: cmp             x2, x1
    //     0x62e4d4: b.ls            #0x62e578
    //     0x62e4d8: str             x1, [THR, #0x60]  ; THR::top
    //     0x62e4dc: sub             x1, x1, #0xf
    //     0x62e4e0: mov             x2, #0xd108
    //     0x62e4e4: movk            x2, #3, lsl #16
    //     0x62e4e8: stur            x2, [x1, #-1]
    // 0x62e4ec: StoreField: r1->field_7 = d0
    //     0x62e4ec: stur            d0, [x1, #7]
    // 0x62e4f0: ldr             x16, [fp, #0x18]
    // 0x62e4f4: stp             x1, x16, [SP, #-0x10]!
    // 0x62e4f8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x62e4f8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x62e4fc: r0 = constrainWidth()
    //     0x62e4fc: bl              #0x62bc8c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0x62e500: add             SP, SP, #0x10
    // 0x62e504: ldr             x0, [fp, #0x10]
    // 0x62e508: stur            d0, [fp, #-8]
    // 0x62e50c: LoadField: d1 = r0->field_f
    //     0x62e50c: ldur            d1, [x0, #0xf]
    // 0x62e510: r0 = inline_Allocate_Double()
    //     0x62e510: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62e514: add             x0, x0, #0x10
    //     0x62e518: cmp             x1, x0
    //     0x62e51c: b.ls            #0x62e594
    //     0x62e520: str             x0, [THR, #0x60]  ; THR::top
    //     0x62e524: sub             x0, x0, #0xf
    //     0x62e528: mov             x1, #0xd108
    //     0x62e52c: movk            x1, #3, lsl #16
    //     0x62e530: stur            x1, [x0, #-1]
    // 0x62e534: StoreField: r0->field_7 = d1
    //     0x62e534: stur            d1, [x0, #7]
    // 0x62e538: ldr             x16, [fp, #0x18]
    // 0x62e53c: stp             x0, x16, [SP, #-0x10]!
    // 0x62e540: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x62e540: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x62e544: r0 = constrainHeight()
    //     0x62e544: bl              #0x62bc00  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0x62e548: add             SP, SP, #0x10
    // 0x62e54c: stur            d0, [fp, #-0x10]
    // 0x62e550: r0 = Size()
    //     0x62e550: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x62e554: ldur            d0, [fp, #-8]
    // 0x62e558: StoreField: r0->field_7 = d0
    //     0x62e558: stur            d0, [x0, #7]
    // 0x62e55c: ldur            d0, [fp, #-0x10]
    // 0x62e560: StoreField: r0->field_f = d0
    //     0x62e560: stur            d0, [x0, #0xf]
    // 0x62e564: LeaveFrame
    //     0x62e564: mov             SP, fp
    //     0x62e568: ldp             fp, lr, [SP], #0x10
    // 0x62e56c: ret
    //     0x62e56c: ret             
    // 0x62e570: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62e570: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62e574: b               #0x62e4c0
    // 0x62e578: SaveReg d0
    //     0x62e578: str             q0, [SP, #-0x10]!
    // 0x62e57c: SaveReg r0
    //     0x62e57c: str             x0, [SP, #-8]!
    // 0x62e580: r0 = AllocateDouble()
    //     0x62e580: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62e584: mov             x1, x0
    // 0x62e588: RestoreReg r0
    //     0x62e588: ldr             x0, [SP], #8
    // 0x62e58c: RestoreReg d0
    //     0x62e58c: ldr             q0, [SP], #0x10
    // 0x62e590: b               #0x62e4ec
    // 0x62e594: stp             q0, q1, [SP, #-0x20]!
    // 0x62e598: r0 = AllocateDouble()
    //     0x62e598: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62e59c: ldp             q0, q1, [SP], #0x20
    // 0x62e5a0: b               #0x62e534
  }
  _ loosen(/* No info */) {
    // ** addr: 0x68f088, size: 0x4c
    // 0x68f088: EnterFrame
    //     0x68f088: stp             fp, lr, [SP, #-0x10]!
    //     0x68f08c: mov             fp, SP
    // 0x68f090: AllocStack(0x10)
    //     0x68f090: sub             SP, SP, #0x10
    // 0x68f094: ldr             x0, [fp, #0x10]
    // 0x68f098: LoadField: d0 = r0->field_f
    //     0x68f098: ldur            d0, [x0, #0xf]
    // 0x68f09c: stur            d0, [fp, #-0x10]
    // 0x68f0a0: LoadField: d1 = r0->field_1f
    //     0x68f0a0: ldur            d1, [x0, #0x1f]
    // 0x68f0a4: stur            d1, [fp, #-8]
    // 0x68f0a8: r0 = BoxConstraints()
    //     0x68f0a8: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x68f0ac: d0 = 0.000000
    //     0x68f0ac: eor             v0.16b, v0.16b, v0.16b
    // 0x68f0b0: StoreField: r0->field_7 = d0
    //     0x68f0b0: stur            d0, [x0, #7]
    // 0x68f0b4: ldur            d1, [fp, #-0x10]
    // 0x68f0b8: StoreField: r0->field_f = d1
    //     0x68f0b8: stur            d1, [x0, #0xf]
    // 0x68f0bc: StoreField: r0->field_17 = d0
    //     0x68f0bc: stur            d0, [x0, #0x17]
    // 0x68f0c0: ldur            d0, [fp, #-8]
    // 0x68f0c4: StoreField: r0->field_1f = d0
    //     0x68f0c4: stur            d0, [x0, #0x1f]
    // 0x68f0c8: LeaveFrame
    //     0x68f0c8: mov             SP, fp
    //     0x68f0cc: ldp             fp, lr, [SP], #0x10
    // 0x68f0d0: ret
    //     0x68f0d0: ret             
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x690914, size: 0x1fc
    // 0x690914: EnterFrame
    //     0x690914: stp             fp, lr, [SP, #-0x10]!
    //     0x690918: mov             fp, SP
    // 0x69091c: AllocStack(0x20)
    //     0x69091c: sub             SP, SP, #0x20
    // 0x690920: SetupParameters(BoxConstraints this /* r3 */, {dynamic maxHeight = Null /* r4 */, dynamic maxWidth = Null /* r5 */, dynamic minHeight = Null /* r6 */, dynamic minWidth = Null /* r0 */})
    //     0x690920: mov             x0, x4
    //     0x690924: ldur            w1, [x0, #0x13]
    //     0x690928: add             x1, x1, HEAP, lsl #32
    //     0x69092c: sub             x2, x1, #2
    //     0x690930: add             x3, fp, w2, sxtw #2
    //     0x690934: ldr             x3, [x3, #0x10]
    //     0x690938: ldur            w2, [x0, #0x1f]
    //     0x69093c: add             x2, x2, HEAP, lsl #32
    //     0x690940: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e700] "maxHeight"
    //     0x690944: ldr             x16, [x16, #0x700]
    //     0x690948: cmp             w2, w16
    //     0x69094c: b.ne            #0x690970
    //     0x690950: ldur            w2, [x0, #0x23]
    //     0x690954: add             x2, x2, HEAP, lsl #32
    //     0x690958: sub             w4, w1, w2
    //     0x69095c: add             x2, fp, w4, sxtw #2
    //     0x690960: ldr             x2, [x2, #8]
    //     0x690964: mov             x4, x2
    //     0x690968: mov             x2, #1
    //     0x69096c: b               #0x690978
    //     0x690970: mov             x4, NULL
    //     0x690974: mov             x2, #0
    //     0x690978: lsl             x5, x2, #1
    //     0x69097c: lsl             w6, w5, #1
    //     0x690980: add             w7, w6, #8
    //     0x690984: add             x16, x0, w7, sxtw #1
    //     0x690988: ldur            w8, [x16, #0xf]
    //     0x69098c: add             x8, x8, HEAP, lsl #32
    //     0x690990: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f590] "maxWidth"
    //     0x690994: ldr             x16, [x16, #0x590]
    //     0x690998: cmp             w8, w16
    //     0x69099c: b.ne            #0x6909d0
    //     0x6909a0: add             w2, w6, #0xa
    //     0x6909a4: add             x16, x0, w2, sxtw #1
    //     0x6909a8: ldur            w6, [x16, #0xf]
    //     0x6909ac: add             x6, x6, HEAP, lsl #32
    //     0x6909b0: sub             w2, w1, w6
    //     0x6909b4: add             x6, fp, w2, sxtw #2
    //     0x6909b8: ldr             x6, [x6, #8]
    //     0x6909bc: add             w2, w5, #2
    //     0x6909c0: sbfx            x5, x2, #1, #0x1f
    //     0x6909c4: mov             x2, x5
    //     0x6909c8: mov             x5, x6
    //     0x6909cc: b               #0x6909d4
    //     0x6909d0: mov             x5, NULL
    //     0x6909d4: lsl             x6, x2, #1
    //     0x6909d8: lsl             w7, w6, #1
    //     0x6909dc: add             w8, w7, #8
    //     0x6909e0: add             x16, x0, w8, sxtw #1
    //     0x6909e4: ldur            w9, [x16, #0xf]
    //     0x6909e8: add             x9, x9, HEAP, lsl #32
    //     0x6909ec: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e708] "minHeight"
    //     0x6909f0: ldr             x16, [x16, #0x708]
    //     0x6909f4: cmp             w9, w16
    //     0x6909f8: b.ne            #0x690a2c
    //     0x6909fc: add             w2, w7, #0xa
    //     0x690a00: add             x16, x0, w2, sxtw #1
    //     0x690a04: ldur            w7, [x16, #0xf]
    //     0x690a08: add             x7, x7, HEAP, lsl #32
    //     0x690a0c: sub             w2, w1, w7
    //     0x690a10: add             x7, fp, w2, sxtw #2
    //     0x690a14: ldr             x7, [x7, #8]
    //     0x690a18: add             w2, w6, #2
    //     0x690a1c: sbfx            x6, x2, #1, #0x1f
    //     0x690a20: mov             x2, x6
    //     0x690a24: mov             x6, x7
    //     0x690a28: b               #0x690a30
    //     0x690a2c: mov             x6, NULL
    //     0x690a30: lsl             x7, x2, #1
    //     0x690a34: lsl             w2, w7, #1
    //     0x690a38: add             w7, w2, #8
    //     0x690a3c: add             x16, x0, w7, sxtw #1
    //     0x690a40: ldur            w8, [x16, #0xf]
    //     0x690a44: add             x8, x8, HEAP, lsl #32
    //     0x690a48: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f598] "minWidth"
    //     0x690a4c: ldr             x16, [x16, #0x598]
    //     0x690a50: cmp             w8, w16
    //     0x690a54: b.ne            #0x690a7c
    //     0x690a58: add             w7, w2, #0xa
    //     0x690a5c: add             x16, x0, w7, sxtw #1
    //     0x690a60: ldur            w2, [x16, #0xf]
    //     0x690a64: add             x2, x2, HEAP, lsl #32
    //     0x690a68: sub             w0, w1, w2
    //     0x690a6c: add             x1, fp, w0, sxtw #2
    //     0x690a70: ldr             x1, [x1, #8]
    //     0x690a74: mov             x0, x1
    //     0x690a78: b               #0x690a80
    //     0x690a7c: mov             x0, NULL
    // 0x690a80: cmp             w0, NULL
    // 0x690a84: b.ne            #0x690a90
    // 0x690a88: LoadField: d0 = r3->field_7
    //     0x690a88: ldur            d0, [x3, #7]
    // 0x690a8c: b               #0x690a94
    // 0x690a90: LoadField: d0 = r0->field_7
    //     0x690a90: ldur            d0, [x0, #7]
    // 0x690a94: stur            d0, [fp, #-0x20]
    // 0x690a98: cmp             w5, NULL
    // 0x690a9c: b.ne            #0x690aa8
    // 0x690aa0: LoadField: d1 = r3->field_f
    //     0x690aa0: ldur            d1, [x3, #0xf]
    // 0x690aa4: b               #0x690aac
    // 0x690aa8: LoadField: d1 = r5->field_7
    //     0x690aa8: ldur            d1, [x5, #7]
    // 0x690aac: stur            d1, [fp, #-0x18]
    // 0x690ab0: cmp             w6, NULL
    // 0x690ab4: b.ne            #0x690ac0
    // 0x690ab8: LoadField: d2 = r3->field_17
    //     0x690ab8: ldur            d2, [x3, #0x17]
    // 0x690abc: b               #0x690ac4
    // 0x690ac0: LoadField: d2 = r6->field_7
    //     0x690ac0: ldur            d2, [x6, #7]
    // 0x690ac4: stur            d2, [fp, #-0x10]
    // 0x690ac8: cmp             w4, NULL
    // 0x690acc: b.ne            #0x690ad8
    // 0x690ad0: LoadField: d3 = r3->field_1f
    //     0x690ad0: ldur            d3, [x3, #0x1f]
    // 0x690ad4: b               #0x690adc
    // 0x690ad8: LoadField: d3 = r4->field_7
    //     0x690ad8: ldur            d3, [x4, #7]
    // 0x690adc: stur            d3, [fp, #-8]
    // 0x690ae0: r0 = BoxConstraints()
    //     0x690ae0: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x690ae4: ldur            d0, [fp, #-0x20]
    // 0x690ae8: StoreField: r0->field_7 = d0
    //     0x690ae8: stur            d0, [x0, #7]
    // 0x690aec: ldur            d0, [fp, #-0x18]
    // 0x690af0: StoreField: r0->field_f = d0
    //     0x690af0: stur            d0, [x0, #0xf]
    // 0x690af4: ldur            d0, [fp, #-0x10]
    // 0x690af8: StoreField: r0->field_17 = d0
    //     0x690af8: stur            d0, [x0, #0x17]
    // 0x690afc: ldur            d0, [fp, #-8]
    // 0x690b00: StoreField: r0->field_1f = d0
    //     0x690b00: stur            d0, [x0, #0x1f]
    // 0x690b04: LeaveFrame
    //     0x690b04: mov             SP, fp
    //     0x690b08: ldp             fp, lr, [SP], #0x10
    // 0x690b0c: ret
    //     0x690b0c: ret             
  }
  _ deflate(/* No info */) {
    // ** addr: 0x692fcc, size: 0x1e4
    // 0x692fcc: EnterFrame
    //     0x692fcc: stp             fp, lr, [SP, #-0x10]!
    //     0x692fd0: mov             fp, SP
    // 0x692fd4: AllocStack(0x20)
    //     0x692fd4: sub             SP, SP, #0x20
    // 0x692fd8: CheckStackOverflow
    //     0x692fd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x692fdc: cmp             SP, x16
    //     0x692fe0: b.ls            #0x6931a8
    // 0x692fe4: ldr             x16, [fp, #0x10]
    // 0x692fe8: SaveReg r16
    //     0x692fe8: str             x16, [SP, #-8]!
    // 0x692fec: r0 = horizontal()
    //     0x692fec: bl              #0x6931c4  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::horizontal
    // 0x692ff0: add             SP, SP, #8
    // 0x692ff4: stur            d0, [fp, #-8]
    // 0x692ff8: ldr             x16, [fp, #0x10]
    // 0x692ffc: SaveReg r16
    //     0x692ffc: str             x16, [SP, #-8]!
    // 0x693000: r0 = vertical()
    //     0x693000: bl              #0x6931b0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::vertical
    // 0x693004: add             SP, SP, #8
    // 0x693008: ldr             x0, [fp, #0x18]
    // 0x69300c: LoadField: d1 = r0->field_7
    //     0x69300c: ldur            d1, [x0, #7]
    // 0x693010: ldur            d2, [fp, #-8]
    // 0x693014: fsub            d3, d1, d2
    // 0x693018: d1 = 0.000000
    //     0x693018: eor             v1.16b, v1.16b, v1.16b
    // 0x69301c: fcmp            d1, d3
    // 0x693020: b.vs            #0x693030
    // 0x693024: b.le            #0x693030
    // 0x693028: d3 = 0.000000
    //     0x693028: eor             v3.16b, v3.16b, v3.16b
    // 0x69302c: b               #0x693060
    // 0x693030: fcmp            d1, d3
    // 0x693034: b.vs            #0x69303c
    // 0x693038: b.lt            #0x693060
    // 0x69303c: fcmp            d1, d1
    // 0x693040: b.vs            #0x693054
    // 0x693044: b.ne            #0x693054
    // 0x693048: fadd            d4, d1, d3
    // 0x69304c: mov             v3.16b, v4.16b
    // 0x693050: b               #0x693060
    // 0x693054: fcmp            d3, d3
    // 0x693058: b.vs            #0x693060
    // 0x69305c: d3 = 0.000000
    //     0x69305c: eor             v3.16b, v3.16b, v3.16b
    // 0x693060: stur            d3, [fp, #-0x20]
    // 0x693064: LoadField: d4 = r0->field_17
    //     0x693064: ldur            d4, [x0, #0x17]
    // 0x693068: fsub            d5, d4, d0
    // 0x69306c: fcmp            d1, d5
    // 0x693070: b.vs            #0x693080
    // 0x693074: b.le            #0x693080
    // 0x693078: d4 = 0.000000
    //     0x693078: eor             v4.16b, v4.16b, v4.16b
    // 0x69307c: b               #0x6930bc
    // 0x693080: fcmp            d1, d5
    // 0x693084: b.vs            #0x693094
    // 0x693088: b.ge            #0x693094
    // 0x69308c: mov             v4.16b, v5.16b
    // 0x693090: b               #0x6930bc
    // 0x693094: fcmp            d1, d1
    // 0x693098: b.vs            #0x6930a8
    // 0x69309c: b.ne            #0x6930a8
    // 0x6930a0: fadd            d4, d1, d5
    // 0x6930a4: b               #0x6930bc
    // 0x6930a8: fcmp            d5, d5
    // 0x6930ac: b.vc            #0x6930b8
    // 0x6930b0: mov             v4.16b, v5.16b
    // 0x6930b4: b               #0x6930bc
    // 0x6930b8: d4 = 0.000000
    //     0x6930b8: eor             v4.16b, v4.16b, v4.16b
    // 0x6930bc: stur            d4, [fp, #-0x18]
    // 0x6930c0: LoadField: d5 = r0->field_f
    //     0x6930c0: ldur            d5, [x0, #0xf]
    // 0x6930c4: fsub            d6, d5, d2
    // 0x6930c8: fcmp            d3, d6
    // 0x6930cc: b.vs            #0x6930dc
    // 0x6930d0: b.le            #0x6930dc
    // 0x6930d4: mov             v2.16b, v3.16b
    // 0x6930d8: b               #0x693118
    // 0x6930dc: fcmp            d3, d6
    // 0x6930e0: b.vs            #0x6930f0
    // 0x6930e4: b.ge            #0x6930f0
    // 0x6930e8: mov             v2.16b, v6.16b
    // 0x6930ec: b               #0x693118
    // 0x6930f0: fcmp            d3, d1
    // 0x6930f4: b.vs            #0x693104
    // 0x6930f8: b.ne            #0x693104
    // 0x6930fc: fadd            d2, d3, d6
    // 0x693100: b               #0x693118
    // 0x693104: fcmp            d6, d6
    // 0x693108: b.vc            #0x693114
    // 0x69310c: mov             v2.16b, v6.16b
    // 0x693110: b               #0x693118
    // 0x693114: mov             v2.16b, v3.16b
    // 0x693118: stur            d2, [fp, #-0x10]
    // 0x69311c: LoadField: d5 = r0->field_1f
    //     0x69311c: ldur            d5, [x0, #0x1f]
    // 0x693120: fsub            d6, d5, d0
    // 0x693124: fcmp            d4, d6
    // 0x693128: b.vs            #0x693138
    // 0x69312c: b.le            #0x693138
    // 0x693130: mov             v0.16b, v4.16b
    // 0x693134: b               #0x693174
    // 0x693138: fcmp            d4, d6
    // 0x69313c: b.vs            #0x69314c
    // 0x693140: b.ge            #0x69314c
    // 0x693144: mov             v0.16b, v6.16b
    // 0x693148: b               #0x693174
    // 0x69314c: fcmp            d4, d1
    // 0x693150: b.vs            #0x693160
    // 0x693154: b.ne            #0x693160
    // 0x693158: fadd            d0, d4, d6
    // 0x69315c: b               #0x693174
    // 0x693160: fcmp            d6, d6
    // 0x693164: b.vc            #0x693170
    // 0x693168: mov             v0.16b, v6.16b
    // 0x69316c: b               #0x693174
    // 0x693170: mov             v0.16b, v4.16b
    // 0x693174: stur            d0, [fp, #-8]
    // 0x693178: r0 = BoxConstraints()
    //     0x693178: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x69317c: ldur            d0, [fp, #-0x20]
    // 0x693180: StoreField: r0->field_7 = d0
    //     0x693180: stur            d0, [x0, #7]
    // 0x693184: ldur            d0, [fp, #-0x10]
    // 0x693188: StoreField: r0->field_f = d0
    //     0x693188: stur            d0, [x0, #0xf]
    // 0x69318c: ldur            d0, [fp, #-0x18]
    // 0x693190: StoreField: r0->field_17 = d0
    //     0x693190: stur            d0, [x0, #0x17]
    // 0x693194: ldur            d0, [fp, #-8]
    // 0x693198: StoreField: r0->field_1f = d0
    //     0x693198: stur            d0, [x0, #0x1f]
    // 0x69319c: LeaveFrame
    //     0x69319c: mov             SP, fp
    //     0x6931a0: ldp             fp, lr, [SP], #0x10
    // 0x6931a4: ret
    //     0x6931a4: ret             
    // 0x6931a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6931a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6931ac: b               #0x692fe4
  }
  get _ flipped(/* No info */) {
    // ** addr: 0x693b9c, size: 0x60
    // 0x693b9c: EnterFrame
    //     0x693b9c: stp             fp, lr, [SP, #-0x10]!
    //     0x693ba0: mov             fp, SP
    // 0x693ba4: AllocStack(0x20)
    //     0x693ba4: sub             SP, SP, #0x20
    // 0x693ba8: ldr             x0, [fp, #0x10]
    // 0x693bac: LoadField: d0 = r0->field_17
    //     0x693bac: ldur            d0, [x0, #0x17]
    // 0x693bb0: stur            d0, [fp, #-0x20]
    // 0x693bb4: LoadField: d1 = r0->field_1f
    //     0x693bb4: ldur            d1, [x0, #0x1f]
    // 0x693bb8: stur            d1, [fp, #-0x18]
    // 0x693bbc: LoadField: d2 = r0->field_7
    //     0x693bbc: ldur            d2, [x0, #7]
    // 0x693bc0: stur            d2, [fp, #-0x10]
    // 0x693bc4: LoadField: d3 = r0->field_f
    //     0x693bc4: ldur            d3, [x0, #0xf]
    // 0x693bc8: stur            d3, [fp, #-8]
    // 0x693bcc: r0 = BoxConstraints()
    //     0x693bcc: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x693bd0: ldur            d0, [fp, #-0x20]
    // 0x693bd4: StoreField: r0->field_7 = d0
    //     0x693bd4: stur            d0, [x0, #7]
    // 0x693bd8: ldur            d0, [fp, #-0x18]
    // 0x693bdc: StoreField: r0->field_f = d0
    //     0x693bdc: stur            d0, [x0, #0xf]
    // 0x693be0: ldur            d0, [fp, #-0x10]
    // 0x693be4: StoreField: r0->field_17 = d0
    //     0x693be4: stur            d0, [x0, #0x17]
    // 0x693be8: ldur            d0, [fp, #-8]
    // 0x693bec: StoreField: r0->field_1f = d0
    //     0x693bec: stur            d0, [x0, #0x1f]
    // 0x693bf0: LeaveFrame
    //     0x693bf0: mov             SP, fp
    //     0x693bf4: ldp             fp, lr, [SP], #0x10
    // 0x693bf8: ret
    //     0x693bf8: ret             
  }
  _ widthConstraints(/* No info */) {
    // ** addr: 0x69437c, size: 0x50
    // 0x69437c: EnterFrame
    //     0x69437c: stp             fp, lr, [SP, #-0x10]!
    //     0x694380: mov             fp, SP
    // 0x694384: AllocStack(0x10)
    //     0x694384: sub             SP, SP, #0x10
    // 0x694388: ldr             x0, [fp, #0x10]
    // 0x69438c: LoadField: d0 = r0->field_7
    //     0x69438c: ldur            d0, [x0, #7]
    // 0x694390: stur            d0, [fp, #-0x10]
    // 0x694394: LoadField: d1 = r0->field_f
    //     0x694394: ldur            d1, [x0, #0xf]
    // 0x694398: stur            d1, [fp, #-8]
    // 0x69439c: r0 = BoxConstraints()
    //     0x69439c: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x6943a0: ldur            d0, [fp, #-0x10]
    // 0x6943a4: StoreField: r0->field_7 = d0
    //     0x6943a4: stur            d0, [x0, #7]
    // 0x6943a8: ldur            d0, [fp, #-8]
    // 0x6943ac: StoreField: r0->field_f = d0
    //     0x6943ac: stur            d0, [x0, #0xf]
    // 0x6943b0: d0 = 0.000000
    //     0x6943b0: eor             v0.16b, v0.16b, v0.16b
    // 0x6943b4: StoreField: r0->field_17 = d0
    //     0x6943b4: stur            d0, [x0, #0x17]
    // 0x6943b8: d0 = inf
    //     0x6943b8: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x6943bc: StoreField: r0->field_1f = d0
    //     0x6943bc: stur            d0, [x0, #0x1f]
    // 0x6943c0: LeaveFrame
    //     0x6943c0: mov             SP, fp
    //     0x6943c4: ldp             fp, lr, [SP], #0x10
    // 0x6943c8: ret
    //     0x6943c8: ret             
  }
  _ heightConstraints(/* No info */) {
    // ** addr: 0x6943cc, size: 0x50
    // 0x6943cc: EnterFrame
    //     0x6943cc: stp             fp, lr, [SP, #-0x10]!
    //     0x6943d0: mov             fp, SP
    // 0x6943d4: AllocStack(0x10)
    //     0x6943d4: sub             SP, SP, #0x10
    // 0x6943d8: ldr             x0, [fp, #0x10]
    // 0x6943dc: LoadField: d0 = r0->field_17
    //     0x6943dc: ldur            d0, [x0, #0x17]
    // 0x6943e0: stur            d0, [fp, #-0x10]
    // 0x6943e4: LoadField: d1 = r0->field_1f
    //     0x6943e4: ldur            d1, [x0, #0x1f]
    // 0x6943e8: stur            d1, [fp, #-8]
    // 0x6943ec: r0 = BoxConstraints()
    //     0x6943ec: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x6943f0: d0 = 0.000000
    //     0x6943f0: eor             v0.16b, v0.16b, v0.16b
    // 0x6943f4: StoreField: r0->field_7 = d0
    //     0x6943f4: stur            d0, [x0, #7]
    // 0x6943f8: d0 = inf
    //     0x6943f8: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x6943fc: StoreField: r0->field_f = d0
    //     0x6943fc: stur            d0, [x0, #0xf]
    // 0x694400: ldur            d0, [fp, #-0x10]
    // 0x694404: StoreField: r0->field_17 = d0
    //     0x694404: stur            d0, [x0, #0x17]
    // 0x694408: ldur            d0, [fp, #-8]
    // 0x69440c: StoreField: r0->field_1f = d0
    //     0x69440c: stur            d0, [x0, #0x1f]
    // 0x694410: LeaveFrame
    //     0x694410: mov             SP, fp
    //     0x694414: ldp             fp, lr, [SP], #0x10
    // 0x694418: ret
    //     0x694418: ret             
  }
  _ constrainDimensions(/* No info */) {
    // ** addr: 0x6a0e88, size: 0x78
    // 0x6a0e88: EnterFrame
    //     0x6a0e88: stp             fp, lr, [SP, #-0x10]!
    //     0x6a0e8c: mov             fp, SP
    // 0x6a0e90: AllocStack(0x10)
    //     0x6a0e90: sub             SP, SP, #0x10
    // 0x6a0e94: CheckStackOverflow
    //     0x6a0e94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6a0e98: cmp             SP, x16
    //     0x6a0e9c: b.ls            #0x6a0ef8
    // 0x6a0ea0: ldr             x16, [fp, #0x20]
    // 0x6a0ea4: ldr             lr, [fp, #0x18]
    // 0x6a0ea8: stp             lr, x16, [SP, #-0x10]!
    // 0x6a0eac: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x6a0eac: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x6a0eb0: r0 = constrainWidth()
    //     0x6a0eb0: bl              #0x62bc8c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0x6a0eb4: add             SP, SP, #0x10
    // 0x6a0eb8: stur            d0, [fp, #-8]
    // 0x6a0ebc: ldr             x16, [fp, #0x20]
    // 0x6a0ec0: ldr             lr, [fp, #0x10]
    // 0x6a0ec4: stp             lr, x16, [SP, #-0x10]!
    // 0x6a0ec8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x6a0ec8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x6a0ecc: r0 = constrainHeight()
    //     0x6a0ecc: bl              #0x62bc00  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0x6a0ed0: add             SP, SP, #0x10
    // 0x6a0ed4: stur            d0, [fp, #-0x10]
    // 0x6a0ed8: r0 = Size()
    //     0x6a0ed8: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x6a0edc: ldur            d0, [fp, #-8]
    // 0x6a0ee0: StoreField: r0->field_7 = d0
    //     0x6a0ee0: stur            d0, [x0, #7]
    // 0x6a0ee4: ldur            d0, [fp, #-0x10]
    // 0x6a0ee8: StoreField: r0->field_f = d0
    //     0x6a0ee8: stur            d0, [x0, #0xf]
    // 0x6a0eec: LeaveFrame
    //     0x6a0eec: mov             SP, fp
    //     0x6a0ef0: ldp             fp, lr, [SP], #0x10
    // 0x6a0ef4: ret
    //     0x6a0ef4: ret             
    // 0x6a0ef8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a0ef8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a0efc: b               #0x6a0ea0
  }
  _ toString(/* No info */) {
    // ** addr: 0xae3630, size: 0x348
    // 0xae3630: EnterFrame
    //     0xae3630: stp             fp, lr, [SP, #-0x10]!
    //     0xae3634: mov             fp, SP
    // 0xae3638: AllocStack(0x20)
    //     0xae3638: sub             SP, SP, #0x20
    // 0xae363c: d0 = 0.000000
    //     0xae363c: eor             v0.16b, v0.16b, v0.16b
    // 0xae3640: CheckStackOverflow
    //     0xae3640: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae3644: cmp             SP, x16
    //     0xae3648: b.ls            #0xae3900
    // 0xae364c: ldr             x0, [fp, #0x10]
    // 0xae3650: LoadField: d1 = r0->field_7
    //     0xae3650: ldur            d1, [x0, #7]
    // 0xae3654: stur            d1, [fp, #-0x20]
    // 0xae3658: fcmp            d1, d0
    // 0xae365c: b.vs            #0xae369c
    // 0xae3660: b.lt            #0xae369c
    // 0xae3664: LoadField: d2 = r0->field_f
    //     0xae3664: ldur            d2, [x0, #0xf]
    // 0xae3668: fcmp            d1, d2
    // 0xae366c: b.vs            #0xae369c
    // 0xae3670: b.gt            #0xae369c
    // 0xae3674: LoadField: d2 = r0->field_17
    //     0xae3674: ldur            d2, [x0, #0x17]
    // 0xae3678: fcmp            d2, d0
    // 0xae367c: b.vs            #0xae369c
    // 0xae3680: b.lt            #0xae369c
    // 0xae3684: LoadField: d3 = r0->field_1f
    //     0xae3684: ldur            d3, [x0, #0x1f]
    // 0xae3688: fcmp            d2, d3
    // 0xae368c: b.vs            #0xae369c
    // 0xae3690: b.gt            #0xae369c
    // 0xae3694: r3 = ""
    //     0xae3694: ldr             x3, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xae3698: b               #0xae36a4
    // 0xae369c: r3 = "; NOT NORMALIZED"
    //     0xae369c: add             x3, PP, #0xb, lsl #12  ; [pp+0xb168] "; NOT NORMALIZED"
    //     0xae36a0: ldr             x3, [x3, #0x168]
    // 0xae36a4: d2 = inf
    //     0xae36a4: ldr             d2, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xae36a8: stur            x3, [fp, #-8]
    // 0xae36ac: fcmp            d1, d2
    // 0xae36b0: b.vs            #0xae3708
    // 0xae36b4: b.ne            #0xae3708
    // 0xae36b8: LoadField: d3 = r0->field_17
    //     0xae36b8: ldur            d3, [x0, #0x17]
    // 0xae36bc: fcmp            d3, d2
    // 0xae36c0: b.vs            #0xae3708
    // 0xae36c4: b.ne            #0xae3708
    // 0xae36c8: r1 = Null
    //     0xae36c8: mov             x1, NULL
    // 0xae36cc: r2 = 6
    //     0xae36cc: mov             x2, #6
    // 0xae36d0: r0 = AllocateArray()
    //     0xae36d0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae36d4: r17 = "BoxConstraints(biggest"
    //     0xae36d4: add             x17, PP, #0xb, lsl #12  ; [pp+0xb170] "BoxConstraints(biggest"
    //     0xae36d8: ldr             x17, [x17, #0x170]
    // 0xae36dc: StoreField: r0->field_f = r17
    //     0xae36dc: stur            w17, [x0, #0xf]
    // 0xae36e0: ldur            x3, [fp, #-8]
    // 0xae36e4: StoreField: r0->field_13 = r3
    //     0xae36e4: stur            w3, [x0, #0x13]
    // 0xae36e8: r17 = ")"
    //     0xae36e8: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae36ec: StoreField: r0->field_17 = r17
    //     0xae36ec: stur            w17, [x0, #0x17]
    // 0xae36f0: SaveReg r0
    //     0xae36f0: str             x0, [SP, #-8]!
    // 0xae36f4: r0 = _interpolate()
    //     0xae36f4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae36f8: add             SP, SP, #8
    // 0xae36fc: LeaveFrame
    //     0xae36fc: mov             SP, fp
    //     0xae3700: ldp             fp, lr, [SP], #0x10
    // 0xae3704: ret
    //     0xae3704: ret             
    // 0xae3708: fcmp            d1, d0
    // 0xae370c: b.vs            #0xae3784
    // 0xae3710: b.ne            #0xae3784
    // 0xae3714: LoadField: d3 = r0->field_f
    //     0xae3714: ldur            d3, [x0, #0xf]
    // 0xae3718: fcmp            d3, d2
    // 0xae371c: b.vs            #0xae3784
    // 0xae3720: b.ne            #0xae3784
    // 0xae3724: LoadField: d3 = r0->field_17
    //     0xae3724: ldur            d3, [x0, #0x17]
    // 0xae3728: fcmp            d3, d0
    // 0xae372c: b.vs            #0xae3784
    // 0xae3730: b.ne            #0xae3784
    // 0xae3734: LoadField: d0 = r0->field_1f
    //     0xae3734: ldur            d0, [x0, #0x1f]
    // 0xae3738: fcmp            d0, d2
    // 0xae373c: b.vs            #0xae3784
    // 0xae3740: b.ne            #0xae3784
    // 0xae3744: r1 = Null
    //     0xae3744: mov             x1, NULL
    // 0xae3748: r2 = 6
    //     0xae3748: mov             x2, #6
    // 0xae374c: r0 = AllocateArray()
    //     0xae374c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae3750: r17 = "BoxConstraints(unconstrained"
    //     0xae3750: add             x17, PP, #0xb, lsl #12  ; [pp+0xb178] "BoxConstraints(unconstrained"
    //     0xae3754: ldr             x17, [x17, #0x178]
    // 0xae3758: StoreField: r0->field_f = r17
    //     0xae3758: stur            w17, [x0, #0xf]
    // 0xae375c: ldur            x3, [fp, #-8]
    // 0xae3760: StoreField: r0->field_13 = r3
    //     0xae3760: stur            w3, [x0, #0x13]
    // 0xae3764: r17 = ")"
    //     0xae3764: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae3768: StoreField: r0->field_17 = r17
    //     0xae3768: stur            w17, [x0, #0x17]
    // 0xae376c: SaveReg r0
    //     0xae376c: str             x0, [SP, #-8]!
    // 0xae3770: r0 = _interpolate()
    //     0xae3770: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae3774: add             SP, SP, #8
    // 0xae3778: LeaveFrame
    //     0xae3778: mov             SP, fp
    //     0xae377c: ldp             fp, lr, [SP], #0x10
    // 0xae3780: ret
    //     0xae3780: ret             
    // 0xae3784: r1 = Function 'describe':.
    //     0xae3784: add             x1, PP, #0xb, lsl #12  ; [pp+0xb180] AnonymousClosure: (0xae3978), in [package:flutter/src/rendering/box.dart] BoxConstraints::toString (0xae3630)
    //     0xae3788: ldr             x1, [x1, #0x180]
    // 0xae378c: r2 = Null
    //     0xae378c: mov             x2, NULL
    // 0xae3790: r0 = AllocateClosure()
    //     0xae3790: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xae3794: mov             x2, x0
    // 0xae3798: ldr             x1, [fp, #0x10]
    // 0xae379c: stur            x2, [fp, #-0x10]
    // 0xae37a0: LoadField: d0 = r1->field_f
    //     0xae37a0: ldur            d0, [x1, #0xf]
    // 0xae37a4: ldur            d1, [fp, #-0x20]
    // 0xae37a8: r0 = inline_Allocate_Double()
    //     0xae37a8: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xae37ac: add             x0, x0, #0x10
    //     0xae37b0: cmp             x3, x0
    //     0xae37b4: b.ls            #0xae3908
    //     0xae37b8: str             x0, [THR, #0x60]  ; THR::top
    //     0xae37bc: sub             x0, x0, #0xf
    //     0xae37c0: mov             x3, #0xd108
    //     0xae37c4: movk            x3, #3, lsl #16
    //     0xae37c8: stur            x3, [x0, #-1]
    // 0xae37cc: StoreField: r0->field_7 = d1
    //     0xae37cc: stur            d1, [x0, #7]
    // 0xae37d0: r3 = inline_Allocate_Double()
    //     0xae37d0: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xae37d4: add             x3, x3, #0x10
    //     0xae37d8: cmp             x4, x3
    //     0xae37dc: b.ls            #0xae3920
    //     0xae37e0: str             x3, [THR, #0x60]  ; THR::top
    //     0xae37e4: sub             x3, x3, #0xf
    //     0xae37e8: mov             x4, #0xd108
    //     0xae37ec: movk            x4, #3, lsl #16
    //     0xae37f0: stur            x4, [x3, #-1]
    // 0xae37f4: StoreField: r3->field_7 = d0
    //     0xae37f4: stur            d0, [x3, #7]
    // 0xae37f8: stp             x0, x2, [SP, #-0x10]!
    // 0xae37fc: r16 = "w"
    //     0xae37fc: add             x16, PP, #0xb, lsl #12  ; [pp+0xb188] "w"
    //     0xae3800: ldr             x16, [x16, #0x188]
    // 0xae3804: stp             x16, x3, [SP, #-0x10]!
    // 0xae3808: mov             x0, x2
    // 0xae380c: ClosureCall
    //     0xae380c: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0xae3810: ldur            x2, [x0, #0x1f]
    //     0xae3814: blr             x2
    // 0xae3818: add             SP, SP, #0x20
    // 0xae381c: mov             x1, x0
    // 0xae3820: ldr             x0, [fp, #0x10]
    // 0xae3824: stur            x1, [fp, #-0x18]
    // 0xae3828: LoadField: d0 = r0->field_17
    //     0xae3828: ldur            d0, [x0, #0x17]
    // 0xae382c: LoadField: d1 = r0->field_1f
    //     0xae382c: ldur            d1, [x0, #0x1f]
    // 0xae3830: r0 = inline_Allocate_Double()
    //     0xae3830: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xae3834: add             x0, x0, #0x10
    //     0xae3838: cmp             x2, x0
    //     0xae383c: b.ls            #0xae3944
    //     0xae3840: str             x0, [THR, #0x60]  ; THR::top
    //     0xae3844: sub             x0, x0, #0xf
    //     0xae3848: mov             x2, #0xd108
    //     0xae384c: movk            x2, #3, lsl #16
    //     0xae3850: stur            x2, [x0, #-1]
    // 0xae3854: StoreField: r0->field_7 = d0
    //     0xae3854: stur            d0, [x0, #7]
    // 0xae3858: r2 = inline_Allocate_Double()
    //     0xae3858: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xae385c: add             x2, x2, #0x10
    //     0xae3860: cmp             x3, x2
    //     0xae3864: b.ls            #0xae395c
    //     0xae3868: str             x2, [THR, #0x60]  ; THR::top
    //     0xae386c: sub             x2, x2, #0xf
    //     0xae3870: mov             x3, #0xd108
    //     0xae3874: movk            x3, #3, lsl #16
    //     0xae3878: stur            x3, [x2, #-1]
    // 0xae387c: StoreField: r2->field_7 = d1
    //     0xae387c: stur            d1, [x2, #7]
    // 0xae3880: ldur            x16, [fp, #-0x10]
    // 0xae3884: stp             x0, x16, [SP, #-0x10]!
    // 0xae3888: r16 = "h"
    //     0xae3888: ldr             x16, [PP, #0x7918]  ; [pp+0x7918] "h"
    // 0xae388c: stp             x16, x2, [SP, #-0x10]!
    // 0xae3890: ldur            x0, [fp, #-0x10]
    // 0xae3894: ClosureCall
    //     0xae3894: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0xae3898: ldur            x2, [x0, #0x1f]
    //     0xae389c: blr             x2
    // 0xae38a0: add             SP, SP, #0x20
    // 0xae38a4: r1 = Null
    //     0xae38a4: mov             x1, NULL
    // 0xae38a8: r2 = 12
    //     0xae38a8: mov             x2, #0xc
    // 0xae38ac: stur            x0, [fp, #-0x10]
    // 0xae38b0: r0 = AllocateArray()
    //     0xae38b0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae38b4: r17 = "BoxConstraints("
    //     0xae38b4: add             x17, PP, #0xb, lsl #12  ; [pp+0xb190] "BoxConstraints("
    //     0xae38b8: ldr             x17, [x17, #0x190]
    // 0xae38bc: StoreField: r0->field_f = r17
    //     0xae38bc: stur            w17, [x0, #0xf]
    // 0xae38c0: ldur            x1, [fp, #-0x18]
    // 0xae38c4: StoreField: r0->field_13 = r1
    //     0xae38c4: stur            w1, [x0, #0x13]
    // 0xae38c8: r17 = ", "
    //     0xae38c8: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae38cc: StoreField: r0->field_17 = r17
    //     0xae38cc: stur            w17, [x0, #0x17]
    // 0xae38d0: ldur            x1, [fp, #-0x10]
    // 0xae38d4: StoreField: r0->field_1b = r1
    //     0xae38d4: stur            w1, [x0, #0x1b]
    // 0xae38d8: ldur            x1, [fp, #-8]
    // 0xae38dc: StoreField: r0->field_1f = r1
    //     0xae38dc: stur            w1, [x0, #0x1f]
    // 0xae38e0: r17 = ")"
    //     0xae38e0: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae38e4: StoreField: r0->field_23 = r17
    //     0xae38e4: stur            w17, [x0, #0x23]
    // 0xae38e8: SaveReg r0
    //     0xae38e8: str             x0, [SP, #-8]!
    // 0xae38ec: r0 = _interpolate()
    //     0xae38ec: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae38f0: add             SP, SP, #8
    // 0xae38f4: LeaveFrame
    //     0xae38f4: mov             SP, fp
    //     0xae38f8: ldp             fp, lr, [SP], #0x10
    // 0xae38fc: ret
    //     0xae38fc: ret             
    // 0xae3900: r0 = StackOverflowSharedWithFPURegs()
    //     0xae3900: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xae3904: b               #0xae364c
    // 0xae3908: stp             q0, q1, [SP, #-0x20]!
    // 0xae390c: stp             x1, x2, [SP, #-0x10]!
    // 0xae3910: r0 = AllocateDouble()
    //     0xae3910: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae3914: ldp             x1, x2, [SP], #0x10
    // 0xae3918: ldp             q0, q1, [SP], #0x20
    // 0xae391c: b               #0xae37cc
    // 0xae3920: SaveReg d0
    //     0xae3920: str             q0, [SP, #-0x10]!
    // 0xae3924: stp             x1, x2, [SP, #-0x10]!
    // 0xae3928: SaveReg r0
    //     0xae3928: str             x0, [SP, #-8]!
    // 0xae392c: r0 = AllocateDouble()
    //     0xae392c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae3930: mov             x3, x0
    // 0xae3934: RestoreReg r0
    //     0xae3934: ldr             x0, [SP], #8
    // 0xae3938: ldp             x1, x2, [SP], #0x10
    // 0xae393c: RestoreReg d0
    //     0xae393c: ldr             q0, [SP], #0x10
    // 0xae3940: b               #0xae37f4
    // 0xae3944: stp             q0, q1, [SP, #-0x20]!
    // 0xae3948: SaveReg r1
    //     0xae3948: str             x1, [SP, #-8]!
    // 0xae394c: r0 = AllocateDouble()
    //     0xae394c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae3950: RestoreReg r1
    //     0xae3950: ldr             x1, [SP], #8
    // 0xae3954: ldp             q0, q1, [SP], #0x20
    // 0xae3958: b               #0xae3854
    // 0xae395c: SaveReg d1
    //     0xae395c: str             q1, [SP, #-0x10]!
    // 0xae3960: stp             x0, x1, [SP, #-0x10]!
    // 0xae3964: r0 = AllocateDouble()
    //     0xae3964: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae3968: mov             x2, x0
    // 0xae396c: ldp             x0, x1, [SP], #0x10
    // 0xae3970: RestoreReg d1
    //     0xae3970: ldr             q1, [SP], #0x10
    // 0xae3974: b               #0xae387c
  }
  [closure] String describe(dynamic, double, double, String) {
    // ** addr: 0xae3978, size: 0x16c
    // 0xae3978: EnterFrame
    //     0xae3978: stp             fp, lr, [SP, #-0x10]!
    //     0xae397c: mov             fp, SP
    // 0xae3980: AllocStack(0x10)
    //     0xae3980: sub             SP, SP, #0x10
    // 0xae3984: CheckStackOverflow
    //     0xae3984: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae3988: cmp             SP, x16
    //     0xae398c: b.ls            #0xae3adc
    // 0xae3990: ldr             x0, [fp, #0x20]
    // 0xae3994: LoadField: d0 = r0->field_7
    //     0xae3994: ldur            d0, [x0, #7]
    // 0xae3998: ldr             x1, [fp, #0x18]
    // 0xae399c: LoadField: d1 = r1->field_7
    //     0xae399c: ldur            d1, [x1, #7]
    // 0xae39a0: fcmp            d0, d1
    // 0xae39a4: b.vs            #0xae3a30
    // 0xae39a8: b.ne            #0xae3a30
    // 0xae39ac: ldr             x3, [fp, #0x10]
    // 0xae39b0: r1 = Null
    //     0xae39b0: mov             x1, NULL
    // 0xae39b4: r2 = 6
    //     0xae39b4: mov             x2, #6
    // 0xae39b8: r0 = AllocateArray()
    //     0xae39b8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae39bc: mov             x1, x0
    // 0xae39c0: ldr             x0, [fp, #0x10]
    // 0xae39c4: stur            x1, [fp, #-8]
    // 0xae39c8: StoreField: r1->field_f = r0
    //     0xae39c8: stur            w0, [x1, #0xf]
    // 0xae39cc: r17 = "="
    //     0xae39cc: ldr             x17, [PP, #0x2a8]  ; [pp+0x2a8] "="
    // 0xae39d0: StoreField: r1->field_13 = r17
    //     0xae39d0: stur            w17, [x1, #0x13]
    // 0xae39d4: ldr             x16, [fp, #0x20]
    // 0xae39d8: SaveReg r16
    //     0xae39d8: str             x16, [SP, #-8]!
    // 0xae39dc: r2 = 1
    //     0xae39dc: mov             x2, #1
    // 0xae39e0: SaveReg r2
    //     0xae39e0: str             x2, [SP, #-8]!
    // 0xae39e4: r0 = toStringAsFixed()
    //     0xae39e4: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae39e8: add             SP, SP, #0x10
    // 0xae39ec: ldur            x1, [fp, #-8]
    // 0xae39f0: ArrayStore: r1[2] = r0  ; List_4
    //     0xae39f0: add             x25, x1, #0x17
    //     0xae39f4: str             w0, [x25]
    //     0xae39f8: tbz             w0, #0, #0xae3a14
    //     0xae39fc: ldurb           w16, [x1, #-1]
    //     0xae3a00: ldurb           w17, [x0, #-1]
    //     0xae3a04: and             x16, x17, x16, lsr #2
    //     0xae3a08: tst             x16, HEAP, lsr #32
    //     0xae3a0c: b.eq            #0xae3a14
    //     0xae3a10: bl              #0xd67e5c
    // 0xae3a14: ldur            x16, [fp, #-8]
    // 0xae3a18: SaveReg r16
    //     0xae3a18: str             x16, [SP, #-8]!
    // 0xae3a1c: r0 = _interpolate()
    //     0xae3a1c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae3a20: add             SP, SP, #8
    // 0xae3a24: LeaveFrame
    //     0xae3a24: mov             SP, fp
    //     0xae3a28: ldp             fp, lr, [SP], #0x10
    // 0xae3a2c: ret
    //     0xae3a2c: ret             
    // 0xae3a30: ldr             x0, [fp, #0x10]
    // 0xae3a34: r2 = 1
    //     0xae3a34: mov             x2, #1
    // 0xae3a38: ldr             x16, [fp, #0x20]
    // 0xae3a3c: stp             x2, x16, [SP, #-0x10]!
    // 0xae3a40: r0 = toStringAsFixed()
    //     0xae3a40: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae3a44: add             SP, SP, #0x10
    // 0xae3a48: r1 = Null
    //     0xae3a48: mov             x1, NULL
    // 0xae3a4c: r2 = 10
    //     0xae3a4c: mov             x2, #0xa
    // 0xae3a50: stur            x0, [fp, #-8]
    // 0xae3a54: r0 = AllocateArray()
    //     0xae3a54: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae3a58: mov             x1, x0
    // 0xae3a5c: ldur            x0, [fp, #-8]
    // 0xae3a60: stur            x1, [fp, #-0x10]
    // 0xae3a64: StoreField: r1->field_f = r0
    //     0xae3a64: stur            w0, [x1, #0xf]
    // 0xae3a68: r17 = "<="
    //     0xae3a68: ldr             x17, [PP, #0xd20]  ; [pp+0xd20] "<="
    // 0xae3a6c: StoreField: r1->field_13 = r17
    //     0xae3a6c: stur            w17, [x1, #0x13]
    // 0xae3a70: ldr             x0, [fp, #0x10]
    // 0xae3a74: StoreField: r1->field_17 = r0
    //     0xae3a74: stur            w0, [x1, #0x17]
    // 0xae3a78: r17 = "<="
    //     0xae3a78: ldr             x17, [PP, #0xd20]  ; [pp+0xd20] "<="
    // 0xae3a7c: StoreField: r1->field_1b = r17
    //     0xae3a7c: stur            w17, [x1, #0x1b]
    // 0xae3a80: ldr             x16, [fp, #0x18]
    // 0xae3a84: SaveReg r16
    //     0xae3a84: str             x16, [SP, #-8]!
    // 0xae3a88: r0 = 1
    //     0xae3a88: mov             x0, #1
    // 0xae3a8c: SaveReg r0
    //     0xae3a8c: str             x0, [SP, #-8]!
    // 0xae3a90: r0 = toStringAsFixed()
    //     0xae3a90: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae3a94: add             SP, SP, #0x10
    // 0xae3a98: ldur            x1, [fp, #-0x10]
    // 0xae3a9c: ArrayStore: r1[4] = r0  ; List_4
    //     0xae3a9c: add             x25, x1, #0x1f
    //     0xae3aa0: str             w0, [x25]
    //     0xae3aa4: tbz             w0, #0, #0xae3ac0
    //     0xae3aa8: ldurb           w16, [x1, #-1]
    //     0xae3aac: ldurb           w17, [x0, #-1]
    //     0xae3ab0: and             x16, x17, x16, lsr #2
    //     0xae3ab4: tst             x16, HEAP, lsr #32
    //     0xae3ab8: b.eq            #0xae3ac0
    //     0xae3abc: bl              #0xd67e5c
    // 0xae3ac0: ldur            x16, [fp, #-0x10]
    // 0xae3ac4: SaveReg r16
    //     0xae3ac4: str             x16, [SP, #-8]!
    // 0xae3ac8: r0 = _interpolate()
    //     0xae3ac8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae3acc: add             SP, SP, #8
    // 0xae3ad0: LeaveFrame
    //     0xae3ad0: mov             SP, fp
    //     0xae3ad4: ldp             fp, lr, [SP], #0x10
    // 0xae3ad8: ret
    //     0xae3ad8: ret             
    // 0xae3adc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae3adc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae3ae0: b               #0xae3990
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbee9cc, size: 0x674
    // 0xbee9cc: EnterFrame
    //     0xbee9cc: stp             fp, lr, [SP, #-0x10]!
    //     0xbee9d0: mov             fp, SP
    // 0xbee9d4: AllocStack(0x20)
    //     0xbee9d4: sub             SP, SP, #0x20
    // 0xbee9d8: CheckStackOverflow
    //     0xbee9d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbee9dc: cmp             SP, x16
    //     0xbee9e0: b.ls            #0xbeee2c
    // 0xbee9e4: ldr             x0, [fp, #0x20]
    // 0xbee9e8: cmp             w0, NULL
    // 0xbee9ec: b.ne            #0xbeea0c
    // 0xbee9f0: ldr             x1, [fp, #0x18]
    // 0xbee9f4: cmp             w1, NULL
    // 0xbee9f8: b.ne            #0xbeea10
    // 0xbee9fc: r0 = Null
    //     0xbee9fc: mov             x0, NULL
    // 0xbeea00: LeaveFrame
    //     0xbeea00: mov             SP, fp
    //     0xbeea04: ldp             fp, lr, [SP], #0x10
    // 0xbeea08: ret
    //     0xbeea08: ret             
    // 0xbeea0c: ldr             x1, [fp, #0x18]
    // 0xbeea10: cmp             w0, NULL
    // 0xbeea14: b.ne            #0xbeea64
    // 0xbeea18: ldr             d0, [fp, #0x10]
    // 0xbeea1c: cmp             w1, NULL
    // 0xbeea20: b.eq            #0xbeee34
    // 0xbeea24: r0 = inline_Allocate_Double()
    //     0xbeea24: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xbeea28: add             x0, x0, #0x10
    //     0xbeea2c: cmp             x2, x0
    //     0xbeea30: b.ls            #0xbeee38
    //     0xbeea34: str             x0, [THR, #0x60]  ; THR::top
    //     0xbeea38: sub             x0, x0, #0xf
    //     0xbeea3c: mov             x2, #0xd108
    //     0xbeea40: movk            x2, #3, lsl #16
    //     0xbeea44: stur            x2, [x0, #-1]
    // 0xbeea48: StoreField: r0->field_7 = d0
    //     0xbeea48: stur            d0, [x0, #7]
    // 0xbeea4c: stp             x0, x1, [SP, #-0x10]!
    // 0xbeea50: r0 = *()
    //     0xbeea50: bl              #0x524340  ; [package:flutter/src/rendering/box.dart] BoxConstraints::*
    // 0xbeea54: add             SP, SP, #0x10
    // 0xbeea58: LeaveFrame
    //     0xbeea58: mov             SP, fp
    //     0xbeea5c: ldp             fp, lr, [SP], #0x10
    // 0xbeea60: ret
    //     0xbeea60: ret             
    // 0xbeea64: ldr             d0, [fp, #0x10]
    // 0xbeea68: cmp             w1, NULL
    // 0xbeea6c: b.ne            #0xbeeab8
    // 0xbeea70: d1 = 1.000000
    //     0xbeea70: fmov            d1, #1.00000000
    // 0xbeea74: fsub            d2, d1, d0
    // 0xbeea78: r1 = inline_Allocate_Double()
    //     0xbeea78: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbeea7c: add             x1, x1, #0x10
    //     0xbeea80: cmp             x2, x1
    //     0xbeea84: b.ls            #0xbeee50
    //     0xbeea88: str             x1, [THR, #0x60]  ; THR::top
    //     0xbeea8c: sub             x1, x1, #0xf
    //     0xbeea90: mov             x2, #0xd108
    //     0xbeea94: movk            x2, #3, lsl #16
    //     0xbeea98: stur            x2, [x1, #-1]
    // 0xbeea9c: StoreField: r1->field_7 = d2
    //     0xbeea9c: stur            d2, [x1, #7]
    // 0xbeeaa0: stp             x1, x0, [SP, #-0x10]!
    // 0xbeeaa4: r0 = *()
    //     0xbeeaa4: bl              #0x524340  ; [package:flutter/src/rendering/box.dart] BoxConstraints::*
    // 0xbeeaa8: add             SP, SP, #0x10
    // 0xbeeaac: LeaveFrame
    //     0xbeeaac: mov             SP, fp
    //     0xbeeab0: ldp             fp, lr, [SP], #0x10
    // 0xbeeab4: ret
    //     0xbeeab4: ret             
    // 0xbeeab8: LoadField: d1 = r0->field_7
    //     0xbeeab8: ldur            d1, [x0, #7]
    // 0xbeeabc: mov             x2, v1.d[0]
    // 0xbeeac0: and             x2, x2, #0x7fffffffffffffff
    // 0xbeeac4: r17 = 9218868437227405312
    //     0xbeeac4: mov             x17, #0x7ff0000000000000
    // 0xbeeac8: cmp             x2, x17
    // 0xbeeacc: b.eq            #0xbeeb74
    // 0xbeead0: fcmp            d1, d1
    // 0xbeead4: b.vs            #0xbeeb74
    // 0xbeead8: LoadField: d2 = r1->field_7
    //     0xbeead8: ldur            d2, [x1, #7]
    // 0xbeeadc: r2 = inline_Allocate_Double()
    //     0xbeeadc: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbeeae0: add             x2, x2, #0x10
    //     0xbeeae4: cmp             x3, x2
    //     0xbeeae8: b.ls            #0xbeee6c
    //     0xbeeaec: str             x2, [THR, #0x60]  ; THR::top
    //     0xbeeaf0: sub             x2, x2, #0xf
    //     0xbeeaf4: mov             x3, #0xd108
    //     0xbeeaf8: movk            x3, #3, lsl #16
    //     0xbeeafc: stur            x3, [x2, #-1]
    // 0xbeeb00: StoreField: r2->field_7 = d0
    //     0xbeeb00: stur            d0, [x2, #7]
    // 0xbeeb04: r3 = inline_Allocate_Double()
    //     0xbeeb04: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xbeeb08: add             x3, x3, #0x10
    //     0xbeeb0c: cmp             x4, x3
    //     0xbeeb10: b.ls            #0xbeee90
    //     0xbeeb14: str             x3, [THR, #0x60]  ; THR::top
    //     0xbeeb18: sub             x3, x3, #0xf
    //     0xbeeb1c: mov             x4, #0xd108
    //     0xbeeb20: movk            x4, #3, lsl #16
    //     0xbeeb24: stur            x4, [x3, #-1]
    // 0xbeeb28: StoreField: r3->field_7 = d1
    //     0xbeeb28: stur            d1, [x3, #7]
    // 0xbeeb2c: r4 = inline_Allocate_Double()
    //     0xbeeb2c: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbeeb30: add             x4, x4, #0x10
    //     0xbeeb34: cmp             x5, x4
    //     0xbeeb38: b.ls            #0xbeeebc
    //     0xbeeb3c: str             x4, [THR, #0x60]  ; THR::top
    //     0xbeeb40: sub             x4, x4, #0xf
    //     0xbeeb44: mov             x5, #0xd108
    //     0xbeeb48: movk            x5, #3, lsl #16
    //     0xbeeb4c: stur            x5, [x4, #-1]
    // 0xbeeb50: StoreField: r4->field_7 = d2
    //     0xbeeb50: stur            d2, [x4, #7]
    // 0xbeeb54: stp             x4, x3, [SP, #-0x10]!
    // 0xbeeb58: SaveReg r2
    //     0xbeeb58: str             x2, [SP, #-8]!
    // 0xbeeb5c: r0 = lerpDouble()
    //     0xbeeb5c: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbeeb60: add             SP, SP, #0x18
    // 0xbeeb64: cmp             w0, NULL
    // 0xbeeb68: b.eq            #0xbeeee0
    // 0xbeeb6c: LoadField: d0 = r0->field_7
    //     0xbeeb6c: ldur            d0, [x0, #7]
    // 0xbeeb70: b               #0xbeeb78
    // 0xbeeb74: d0 = inf
    //     0xbeeb74: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xbeeb78: ldr             x0, [fp, #0x20]
    // 0xbeeb7c: stur            d0, [fp, #-8]
    // 0xbeeb80: LoadField: d1 = r0->field_f
    //     0xbeeb80: ldur            d1, [x0, #0xf]
    // 0xbeeb84: mov             x1, v1.d[0]
    // 0xbeeb88: and             x1, x1, #0x7fffffffffffffff
    // 0xbeeb8c: r17 = 9218868437227405312
    //     0xbeeb8c: mov             x17, #0x7ff0000000000000
    // 0xbeeb90: cmp             x1, x17
    // 0xbeeb94: b.eq            #0xbeec44
    // 0xbeeb98: fcmp            d1, d1
    // 0xbeeb9c: b.vs            #0xbeec44
    // 0xbeeba0: ldr             x1, [fp, #0x18]
    // 0xbeeba4: ldr             d2, [fp, #0x10]
    // 0xbeeba8: LoadField: d3 = r1->field_f
    //     0xbeeba8: ldur            d3, [x1, #0xf]
    // 0xbeebac: r2 = inline_Allocate_Double()
    //     0xbeebac: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbeebb0: add             x2, x2, #0x10
    //     0xbeebb4: cmp             x3, x2
    //     0xbeebb8: b.ls            #0xbeeee4
    //     0xbeebbc: str             x2, [THR, #0x60]  ; THR::top
    //     0xbeebc0: sub             x2, x2, #0xf
    //     0xbeebc4: mov             x3, #0xd108
    //     0xbeebc8: movk            x3, #3, lsl #16
    //     0xbeebcc: stur            x3, [x2, #-1]
    // 0xbeebd0: StoreField: r2->field_7 = d2
    //     0xbeebd0: stur            d2, [x2, #7]
    // 0xbeebd4: r3 = inline_Allocate_Double()
    //     0xbeebd4: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xbeebd8: add             x3, x3, #0x10
    //     0xbeebdc: cmp             x4, x3
    //     0xbeebe0: b.ls            #0xbeef08
    //     0xbeebe4: str             x3, [THR, #0x60]  ; THR::top
    //     0xbeebe8: sub             x3, x3, #0xf
    //     0xbeebec: mov             x4, #0xd108
    //     0xbeebf0: movk            x4, #3, lsl #16
    //     0xbeebf4: stur            x4, [x3, #-1]
    // 0xbeebf8: StoreField: r3->field_7 = d1
    //     0xbeebf8: stur            d1, [x3, #7]
    // 0xbeebfc: r4 = inline_Allocate_Double()
    //     0xbeebfc: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbeec00: add             x4, x4, #0x10
    //     0xbeec04: cmp             x5, x4
    //     0xbeec08: b.ls            #0xbeef34
    //     0xbeec0c: str             x4, [THR, #0x60]  ; THR::top
    //     0xbeec10: sub             x4, x4, #0xf
    //     0xbeec14: mov             x5, #0xd108
    //     0xbeec18: movk            x5, #3, lsl #16
    //     0xbeec1c: stur            x5, [x4, #-1]
    // 0xbeec20: StoreField: r4->field_7 = d3
    //     0xbeec20: stur            d3, [x4, #7]
    // 0xbeec24: stp             x4, x3, [SP, #-0x10]!
    // 0xbeec28: SaveReg r2
    //     0xbeec28: str             x2, [SP, #-8]!
    // 0xbeec2c: r0 = lerpDouble()
    //     0xbeec2c: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbeec30: add             SP, SP, #0x18
    // 0xbeec34: cmp             w0, NULL
    // 0xbeec38: b.eq            #0xbeef60
    // 0xbeec3c: LoadField: d0 = r0->field_7
    //     0xbeec3c: ldur            d0, [x0, #7]
    // 0xbeec40: b               #0xbeec48
    // 0xbeec44: d0 = inf
    //     0xbeec44: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xbeec48: ldr             x0, [fp, #0x20]
    // 0xbeec4c: stur            d0, [fp, #-0x10]
    // 0xbeec50: LoadField: d1 = r0->field_17
    //     0xbeec50: ldur            d1, [x0, #0x17]
    // 0xbeec54: mov             x1, v1.d[0]
    // 0xbeec58: and             x1, x1, #0x7fffffffffffffff
    // 0xbeec5c: r17 = 9218868437227405312
    //     0xbeec5c: mov             x17, #0x7ff0000000000000
    // 0xbeec60: cmp             x1, x17
    // 0xbeec64: b.eq            #0xbeed14
    // 0xbeec68: fcmp            d1, d1
    // 0xbeec6c: b.vs            #0xbeed14
    // 0xbeec70: ldr             x1, [fp, #0x18]
    // 0xbeec74: ldr             d2, [fp, #0x10]
    // 0xbeec78: LoadField: d3 = r1->field_17
    //     0xbeec78: ldur            d3, [x1, #0x17]
    // 0xbeec7c: r2 = inline_Allocate_Double()
    //     0xbeec7c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbeec80: add             x2, x2, #0x10
    //     0xbeec84: cmp             x3, x2
    //     0xbeec88: b.ls            #0xbeef64
    //     0xbeec8c: str             x2, [THR, #0x60]  ; THR::top
    //     0xbeec90: sub             x2, x2, #0xf
    //     0xbeec94: mov             x3, #0xd108
    //     0xbeec98: movk            x3, #3, lsl #16
    //     0xbeec9c: stur            x3, [x2, #-1]
    // 0xbeeca0: StoreField: r2->field_7 = d2
    //     0xbeeca0: stur            d2, [x2, #7]
    // 0xbeeca4: r3 = inline_Allocate_Double()
    //     0xbeeca4: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xbeeca8: add             x3, x3, #0x10
    //     0xbeecac: cmp             x4, x3
    //     0xbeecb0: b.ls            #0xbeef88
    //     0xbeecb4: str             x3, [THR, #0x60]  ; THR::top
    //     0xbeecb8: sub             x3, x3, #0xf
    //     0xbeecbc: mov             x4, #0xd108
    //     0xbeecc0: movk            x4, #3, lsl #16
    //     0xbeecc4: stur            x4, [x3, #-1]
    // 0xbeecc8: StoreField: r3->field_7 = d1
    //     0xbeecc8: stur            d1, [x3, #7]
    // 0xbeeccc: r4 = inline_Allocate_Double()
    //     0xbeeccc: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbeecd0: add             x4, x4, #0x10
    //     0xbeecd4: cmp             x5, x4
    //     0xbeecd8: b.ls            #0xbeefb4
    //     0xbeecdc: str             x4, [THR, #0x60]  ; THR::top
    //     0xbeece0: sub             x4, x4, #0xf
    //     0xbeece4: mov             x5, #0xd108
    //     0xbeece8: movk            x5, #3, lsl #16
    //     0xbeecec: stur            x5, [x4, #-1]
    // 0xbeecf0: StoreField: r4->field_7 = d3
    //     0xbeecf0: stur            d3, [x4, #7]
    // 0xbeecf4: stp             x4, x3, [SP, #-0x10]!
    // 0xbeecf8: SaveReg r2
    //     0xbeecf8: str             x2, [SP, #-8]!
    // 0xbeecfc: r0 = lerpDouble()
    //     0xbeecfc: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbeed00: add             SP, SP, #0x18
    // 0xbeed04: cmp             w0, NULL
    // 0xbeed08: b.eq            #0xbeefe0
    // 0xbeed0c: LoadField: d0 = r0->field_7
    //     0xbeed0c: ldur            d0, [x0, #7]
    // 0xbeed10: b               #0xbeed18
    // 0xbeed14: d0 = inf
    //     0xbeed14: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xbeed18: ldr             x0, [fp, #0x20]
    // 0xbeed1c: stur            d0, [fp, #-0x18]
    // 0xbeed20: LoadField: d1 = r0->field_1f
    //     0xbeed20: ldur            d1, [x0, #0x1f]
    // 0xbeed24: mov             x0, v1.d[0]
    // 0xbeed28: and             x0, x0, #0x7fffffffffffffff
    // 0xbeed2c: r17 = 9218868437227405312
    //     0xbeed2c: mov             x17, #0x7ff0000000000000
    // 0xbeed30: cmp             x0, x17
    // 0xbeed34: b.eq            #0xbeede8
    // 0xbeed38: fcmp            d1, d1
    // 0xbeed3c: b.vs            #0xbeede8
    // 0xbeed40: ldr             x0, [fp, #0x18]
    // 0xbeed44: ldr             d2, [fp, #0x10]
    // 0xbeed48: LoadField: d3 = r0->field_1f
    //     0xbeed48: ldur            d3, [x0, #0x1f]
    // 0xbeed4c: r0 = inline_Allocate_Double()
    //     0xbeed4c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbeed50: add             x0, x0, #0x10
    //     0xbeed54: cmp             x1, x0
    //     0xbeed58: b.ls            #0xbeefe4
    //     0xbeed5c: str             x0, [THR, #0x60]  ; THR::top
    //     0xbeed60: sub             x0, x0, #0xf
    //     0xbeed64: mov             x1, #0xd108
    //     0xbeed68: movk            x1, #3, lsl #16
    //     0xbeed6c: stur            x1, [x0, #-1]
    // 0xbeed70: StoreField: r0->field_7 = d2
    //     0xbeed70: stur            d2, [x0, #7]
    // 0xbeed74: r1 = inline_Allocate_Double()
    //     0xbeed74: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbeed78: add             x1, x1, #0x10
    //     0xbeed7c: cmp             x2, x1
    //     0xbeed80: b.ls            #0xbeeffc
    //     0xbeed84: str             x1, [THR, #0x60]  ; THR::top
    //     0xbeed88: sub             x1, x1, #0xf
    //     0xbeed8c: mov             x2, #0xd108
    //     0xbeed90: movk            x2, #3, lsl #16
    //     0xbeed94: stur            x2, [x1, #-1]
    // 0xbeed98: StoreField: r1->field_7 = d1
    //     0xbeed98: stur            d1, [x1, #7]
    // 0xbeed9c: r2 = inline_Allocate_Double()
    //     0xbeed9c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbeeda0: add             x2, x2, #0x10
    //     0xbeeda4: cmp             x3, x2
    //     0xbeeda8: b.ls            #0xbef020
    //     0xbeedac: str             x2, [THR, #0x60]  ; THR::top
    //     0xbeedb0: sub             x2, x2, #0xf
    //     0xbeedb4: mov             x3, #0xd108
    //     0xbeedb8: movk            x3, #3, lsl #16
    //     0xbeedbc: stur            x3, [x2, #-1]
    // 0xbeedc0: StoreField: r2->field_7 = d3
    //     0xbeedc0: stur            d3, [x2, #7]
    // 0xbeedc4: stp             x2, x1, [SP, #-0x10]!
    // 0xbeedc8: SaveReg r0
    //     0xbeedc8: str             x0, [SP, #-8]!
    // 0xbeedcc: r0 = lerpDouble()
    //     0xbeedcc: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbeedd0: add             SP, SP, #0x18
    // 0xbeedd4: cmp             w0, NULL
    // 0xbeedd8: b.eq            #0xbef03c
    // 0xbeeddc: LoadField: d0 = r0->field_7
    //     0xbeeddc: ldur            d0, [x0, #7]
    // 0xbeede0: mov             v3.16b, v0.16b
    // 0xbeede4: b               #0xbeedec
    // 0xbeede8: d3 = inf
    //     0xbeede8: ldr             d3, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xbeedec: ldur            d2, [fp, #-8]
    // 0xbeedf0: ldur            d1, [fp, #-0x10]
    // 0xbeedf4: ldur            d0, [fp, #-0x18]
    // 0xbeedf8: stur            d3, [fp, #-0x20]
    // 0xbeedfc: r0 = BoxConstraints()
    //     0xbeedfc: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xbeee00: ldur            d0, [fp, #-8]
    // 0xbeee04: StoreField: r0->field_7 = d0
    //     0xbeee04: stur            d0, [x0, #7]
    // 0xbeee08: ldur            d0, [fp, #-0x10]
    // 0xbeee0c: StoreField: r0->field_f = d0
    //     0xbeee0c: stur            d0, [x0, #0xf]
    // 0xbeee10: ldur            d0, [fp, #-0x18]
    // 0xbeee14: StoreField: r0->field_17 = d0
    //     0xbeee14: stur            d0, [x0, #0x17]
    // 0xbeee18: ldur            d0, [fp, #-0x20]
    // 0xbeee1c: StoreField: r0->field_1f = d0
    //     0xbeee1c: stur            d0, [x0, #0x1f]
    // 0xbeee20: LeaveFrame
    //     0xbeee20: mov             SP, fp
    //     0xbeee24: ldp             fp, lr, [SP], #0x10
    // 0xbeee28: ret
    //     0xbeee28: ret             
    // 0xbeee2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbeee2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbeee30: b               #0xbee9e4
    // 0xbeee34: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbeee34: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xbeee38: SaveReg d0
    //     0xbeee38: str             q0, [SP, #-0x10]!
    // 0xbeee3c: SaveReg r1
    //     0xbeee3c: str             x1, [SP, #-8]!
    // 0xbeee40: r0 = AllocateDouble()
    //     0xbeee40: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeee44: RestoreReg r1
    //     0xbeee44: ldr             x1, [SP], #8
    // 0xbeee48: RestoreReg d0
    //     0xbeee48: ldr             q0, [SP], #0x10
    // 0xbeee4c: b               #0xbeea48
    // 0xbeee50: SaveReg d2
    //     0xbeee50: str             q2, [SP, #-0x10]!
    // 0xbeee54: SaveReg r0
    //     0xbeee54: str             x0, [SP, #-8]!
    // 0xbeee58: r0 = AllocateDouble()
    //     0xbeee58: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeee5c: mov             x1, x0
    // 0xbeee60: RestoreReg r0
    //     0xbeee60: ldr             x0, [SP], #8
    // 0xbeee64: RestoreReg d2
    //     0xbeee64: ldr             q2, [SP], #0x10
    // 0xbeee68: b               #0xbeea9c
    // 0xbeee6c: stp             q1, q2, [SP, #-0x20]!
    // 0xbeee70: SaveReg d0
    //     0xbeee70: str             q0, [SP, #-0x10]!
    // 0xbeee74: stp             x0, x1, [SP, #-0x10]!
    // 0xbeee78: r0 = AllocateDouble()
    //     0xbeee78: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeee7c: mov             x2, x0
    // 0xbeee80: ldp             x0, x1, [SP], #0x10
    // 0xbeee84: RestoreReg d0
    //     0xbeee84: ldr             q0, [SP], #0x10
    // 0xbeee88: ldp             q1, q2, [SP], #0x20
    // 0xbeee8c: b               #0xbeeb00
    // 0xbeee90: stp             q1, q2, [SP, #-0x20]!
    // 0xbeee94: SaveReg d0
    //     0xbeee94: str             q0, [SP, #-0x10]!
    // 0xbeee98: stp             x1, x2, [SP, #-0x10]!
    // 0xbeee9c: SaveReg r0
    //     0xbeee9c: str             x0, [SP, #-8]!
    // 0xbeeea0: r0 = AllocateDouble()
    //     0xbeeea0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeeea4: mov             x3, x0
    // 0xbeeea8: RestoreReg r0
    //     0xbeeea8: ldr             x0, [SP], #8
    // 0xbeeeac: ldp             x1, x2, [SP], #0x10
    // 0xbeeeb0: RestoreReg d0
    //     0xbeeeb0: ldr             q0, [SP], #0x10
    // 0xbeeeb4: ldp             q1, q2, [SP], #0x20
    // 0xbeeeb8: b               #0xbeeb28
    // 0xbeeebc: stp             q0, q2, [SP, #-0x20]!
    // 0xbeeec0: stp             x2, x3, [SP, #-0x10]!
    // 0xbeeec4: stp             x0, x1, [SP, #-0x10]!
    // 0xbeeec8: r0 = AllocateDouble()
    //     0xbeeec8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeeecc: mov             x4, x0
    // 0xbeeed0: ldp             x0, x1, [SP], #0x10
    // 0xbeeed4: ldp             x2, x3, [SP], #0x10
    // 0xbeeed8: ldp             q0, q2, [SP], #0x20
    // 0xbeeedc: b               #0xbeeb50
    // 0xbeeee0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbeeee0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbeeee4: stp             q2, q3, [SP, #-0x20]!
    // 0xbeeee8: stp             q0, q1, [SP, #-0x20]!
    // 0xbeeeec: stp             x0, x1, [SP, #-0x10]!
    // 0xbeeef0: r0 = AllocateDouble()
    //     0xbeeef0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeeef4: mov             x2, x0
    // 0xbeeef8: ldp             x0, x1, [SP], #0x10
    // 0xbeeefc: ldp             q0, q1, [SP], #0x20
    // 0xbeef00: ldp             q2, q3, [SP], #0x20
    // 0xbeef04: b               #0xbeebd0
    // 0xbeef08: stp             q2, q3, [SP, #-0x20]!
    // 0xbeef0c: stp             q0, q1, [SP, #-0x20]!
    // 0xbeef10: stp             x1, x2, [SP, #-0x10]!
    // 0xbeef14: SaveReg r0
    //     0xbeef14: str             x0, [SP, #-8]!
    // 0xbeef18: r0 = AllocateDouble()
    //     0xbeef18: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeef1c: mov             x3, x0
    // 0xbeef20: RestoreReg r0
    //     0xbeef20: ldr             x0, [SP], #8
    // 0xbeef24: ldp             x1, x2, [SP], #0x10
    // 0xbeef28: ldp             q0, q1, [SP], #0x20
    // 0xbeef2c: ldp             q2, q3, [SP], #0x20
    // 0xbeef30: b               #0xbeebf8
    // 0xbeef34: stp             q2, q3, [SP, #-0x20]!
    // 0xbeef38: SaveReg d0
    //     0xbeef38: str             q0, [SP, #-0x10]!
    // 0xbeef3c: stp             x2, x3, [SP, #-0x10]!
    // 0xbeef40: stp             x0, x1, [SP, #-0x10]!
    // 0xbeef44: r0 = AllocateDouble()
    //     0xbeef44: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeef48: mov             x4, x0
    // 0xbeef4c: ldp             x0, x1, [SP], #0x10
    // 0xbeef50: ldp             x2, x3, [SP], #0x10
    // 0xbeef54: RestoreReg d0
    //     0xbeef54: ldr             q0, [SP], #0x10
    // 0xbeef58: ldp             q2, q3, [SP], #0x20
    // 0xbeef5c: b               #0xbeec20
    // 0xbeef60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbeef60: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbeef64: stp             q2, q3, [SP, #-0x20]!
    // 0xbeef68: stp             q0, q1, [SP, #-0x20]!
    // 0xbeef6c: stp             x0, x1, [SP, #-0x10]!
    // 0xbeef70: r0 = AllocateDouble()
    //     0xbeef70: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeef74: mov             x2, x0
    // 0xbeef78: ldp             x0, x1, [SP], #0x10
    // 0xbeef7c: ldp             q0, q1, [SP], #0x20
    // 0xbeef80: ldp             q2, q3, [SP], #0x20
    // 0xbeef84: b               #0xbeeca0
    // 0xbeef88: stp             q2, q3, [SP, #-0x20]!
    // 0xbeef8c: stp             q0, q1, [SP, #-0x20]!
    // 0xbeef90: stp             x1, x2, [SP, #-0x10]!
    // 0xbeef94: SaveReg r0
    //     0xbeef94: str             x0, [SP, #-8]!
    // 0xbeef98: r0 = AllocateDouble()
    //     0xbeef98: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeef9c: mov             x3, x0
    // 0xbeefa0: RestoreReg r0
    //     0xbeefa0: ldr             x0, [SP], #8
    // 0xbeefa4: ldp             x1, x2, [SP], #0x10
    // 0xbeefa8: ldp             q0, q1, [SP], #0x20
    // 0xbeefac: ldp             q2, q3, [SP], #0x20
    // 0xbeefb0: b               #0xbeecc8
    // 0xbeefb4: stp             q2, q3, [SP, #-0x20]!
    // 0xbeefb8: SaveReg d0
    //     0xbeefb8: str             q0, [SP, #-0x10]!
    // 0xbeefbc: stp             x2, x3, [SP, #-0x10]!
    // 0xbeefc0: stp             x0, x1, [SP, #-0x10]!
    // 0xbeefc4: r0 = AllocateDouble()
    //     0xbeefc4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeefc8: mov             x4, x0
    // 0xbeefcc: ldp             x0, x1, [SP], #0x10
    // 0xbeefd0: ldp             x2, x3, [SP], #0x10
    // 0xbeefd4: RestoreReg d0
    //     0xbeefd4: ldr             q0, [SP], #0x10
    // 0xbeefd8: ldp             q2, q3, [SP], #0x20
    // 0xbeefdc: b               #0xbeecf0
    // 0xbeefe0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbeefe0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbeefe4: stp             q2, q3, [SP, #-0x20]!
    // 0xbeefe8: stp             q0, q1, [SP, #-0x20]!
    // 0xbeefec: r0 = AllocateDouble()
    //     0xbeefec: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeeff0: ldp             q0, q1, [SP], #0x20
    // 0xbeeff4: ldp             q2, q3, [SP], #0x20
    // 0xbeeff8: b               #0xbeed70
    // 0xbeeffc: stp             q1, q3, [SP, #-0x20]!
    // 0xbef000: SaveReg d0
    //     0xbef000: str             q0, [SP, #-0x10]!
    // 0xbef004: SaveReg r0
    //     0xbef004: str             x0, [SP, #-8]!
    // 0xbef008: r0 = AllocateDouble()
    //     0xbef008: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbef00c: mov             x1, x0
    // 0xbef010: RestoreReg r0
    //     0xbef010: ldr             x0, [SP], #8
    // 0xbef014: RestoreReg d0
    //     0xbef014: ldr             q0, [SP], #0x10
    // 0xbef018: ldp             q1, q3, [SP], #0x20
    // 0xbef01c: b               #0xbeed98
    // 0xbef020: stp             q0, q3, [SP, #-0x20]!
    // 0xbef024: stp             x0, x1, [SP, #-0x10]!
    // 0xbef028: r0 = AllocateDouble()
    //     0xbef028: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbef02c: mov             x2, x0
    // 0xbef030: ldp             x0, x1, [SP], #0x10
    // 0xbef034: ldp             q0, q3, [SP], #0x20
    // 0xbef038: b               #0xbeedc0
    // 0xbef03c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbef03c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9e8ac, size: 0x174
    // 0xc9e8ac: EnterFrame
    //     0xc9e8ac: stp             fp, lr, [SP, #-0x10]!
    //     0xc9e8b0: mov             fp, SP
    // 0xc9e8b4: AllocStack(0x8)
    //     0xc9e8b4: sub             SP, SP, #8
    // 0xc9e8b8: CheckStackOverflow
    //     0xc9e8b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc9e8bc: cmp             SP, x16
    //     0xc9e8c0: b.ls            #0xc9ea18
    // 0xc9e8c4: ldr             x1, [fp, #0x10]
    // 0xc9e8c8: cmp             w1, NULL
    // 0xc9e8cc: b.ne            #0xc9e8e0
    // 0xc9e8d0: r0 = false
    //     0xc9e8d0: add             x0, NULL, #0x30  ; false
    // 0xc9e8d4: LeaveFrame
    //     0xc9e8d4: mov             SP, fp
    //     0xc9e8d8: ldp             fp, lr, [SP], #0x10
    // 0xc9e8dc: ret
    //     0xc9e8dc: ret             
    // 0xc9e8e0: ldr             x2, [fp, #0x18]
    // 0xc9e8e4: cmp             w2, w1
    // 0xc9e8e8: b.ne            #0xc9e8fc
    // 0xc9e8ec: r0 = true
    //     0xc9e8ec: add             x0, NULL, #0x20  ; true
    // 0xc9e8f0: LeaveFrame
    //     0xc9e8f0: mov             SP, fp
    //     0xc9e8f4: ldp             fp, lr, [SP], #0x10
    // 0xc9e8f8: ret
    //     0xc9e8f8: ret             
    // 0xc9e8fc: r0 = 59
    //     0xc9e8fc: mov             x0, #0x3b
    // 0xc9e900: branchIfSmi(r1, 0xc9e90c)
    //     0xc9e900: tbz             w1, #0, #0xc9e90c
    // 0xc9e904: r0 = LoadClassIdInstr(r1)
    //     0xc9e904: ldur            x0, [x1, #-1]
    //     0xc9e908: ubfx            x0, x0, #0xc, #0x14
    // 0xc9e90c: SaveReg r1
    //     0xc9e90c: str             x1, [SP, #-8]!
    // 0xc9e910: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc9e910: mov             x17, #0x57c5
    //     0xc9e914: add             lr, x0, x17
    //     0xc9e918: ldr             lr, [x21, lr, lsl #3]
    //     0xc9e91c: blr             lr
    // 0xc9e920: add             SP, SP, #8
    // 0xc9e924: stur            x0, [fp, #-8]
    // 0xc9e928: ldr             x16, [fp, #0x18]
    // 0xc9e92c: SaveReg r16
    //     0xc9e92c: str             x16, [SP, #-8]!
    // 0xc9e930: r0 = runtimeType()
    //     0xc9e930: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc9e934: add             SP, SP, #8
    // 0xc9e938: mov             x1, x0
    // 0xc9e93c: ldur            x0, [fp, #-8]
    // 0xc9e940: r2 = LoadClassIdInstr(r0)
    //     0xc9e940: ldur            x2, [x0, #-1]
    //     0xc9e944: ubfx            x2, x2, #0xc, #0x14
    // 0xc9e948: stp             x1, x0, [SP, #-0x10]!
    // 0xc9e94c: mov             x0, x2
    // 0xc9e950: mov             lr, x0
    // 0xc9e954: ldr             lr, [x21, lr, lsl #3]
    // 0xc9e958: blr             lr
    // 0xc9e95c: add             SP, SP, #0x10
    // 0xc9e960: tbz             w0, #4, #0xc9e974
    // 0xc9e964: r0 = false
    //     0xc9e964: add             x0, NULL, #0x30  ; false
    // 0xc9e968: LeaveFrame
    //     0xc9e968: mov             SP, fp
    //     0xc9e96c: ldp             fp, lr, [SP], #0x10
    // 0xc9e970: ret
    //     0xc9e970: ret             
    // 0xc9e974: ldr             x1, [fp, #0x10]
    // 0xc9e978: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc9e978: mov             x2, #0x76
    //     0xc9e97c: tbz             w1, #0, #0xc9e98c
    //     0xc9e980: ldur            x2, [x1, #-1]
    //     0xc9e984: ubfx            x2, x2, #0xc, #0x14
    //     0xc9e988: lsl             x2, x2, #1
    // 0xc9e98c: r3 = LoadInt32Instr(r2)
    //     0xc9e98c: sbfx            x3, x2, #1, #0x1f
    // 0xc9e990: cmp             x3, #0x80d
    // 0xc9e994: b.lt            #0xc9ea08
    // 0xc9e998: cmp             x3, #0x80e
    // 0xc9e99c: b.gt            #0xc9ea08
    // 0xc9e9a0: ldr             x2, [fp, #0x18]
    // 0xc9e9a4: LoadField: d0 = r1->field_7
    //     0xc9e9a4: ldur            d0, [x1, #7]
    // 0xc9e9a8: LoadField: d1 = r2->field_7
    //     0xc9e9a8: ldur            d1, [x2, #7]
    // 0xc9e9ac: fcmp            d0, d1
    // 0xc9e9b0: b.vs            #0xc9ea08
    // 0xc9e9b4: b.ne            #0xc9ea08
    // 0xc9e9b8: LoadField: d0 = r1->field_f
    //     0xc9e9b8: ldur            d0, [x1, #0xf]
    // 0xc9e9bc: LoadField: d1 = r2->field_f
    //     0xc9e9bc: ldur            d1, [x2, #0xf]
    // 0xc9e9c0: fcmp            d0, d1
    // 0xc9e9c4: b.vs            #0xc9ea08
    // 0xc9e9c8: b.ne            #0xc9ea08
    // 0xc9e9cc: LoadField: d0 = r1->field_17
    //     0xc9e9cc: ldur            d0, [x1, #0x17]
    // 0xc9e9d0: LoadField: d1 = r2->field_17
    //     0xc9e9d0: ldur            d1, [x2, #0x17]
    // 0xc9e9d4: fcmp            d0, d1
    // 0xc9e9d8: b.vs            #0xc9ea08
    // 0xc9e9dc: b.ne            #0xc9ea08
    // 0xc9e9e0: LoadField: d0 = r1->field_1f
    //     0xc9e9e0: ldur            d0, [x1, #0x1f]
    // 0xc9e9e4: LoadField: d1 = r2->field_1f
    //     0xc9e9e4: ldur            d1, [x2, #0x1f]
    // 0xc9e9e8: fcmp            d0, d1
    // 0xc9e9ec: b.vs            #0xc9e9f4
    // 0xc9e9f0: b.eq            #0xc9e9fc
    // 0xc9e9f4: r1 = false
    //     0xc9e9f4: add             x1, NULL, #0x30  ; false
    // 0xc9e9f8: b               #0xc9ea00
    // 0xc9e9fc: r1 = true
    //     0xc9e9fc: add             x1, NULL, #0x20  ; true
    // 0xc9ea00: mov             x0, x1
    // 0xc9ea04: b               #0xc9ea0c
    // 0xc9ea08: r0 = false
    //     0xc9ea08: add             x0, NULL, #0x30  ; false
    // 0xc9ea0c: LeaveFrame
    //     0xc9ea0c: mov             SP, fp
    //     0xc9ea10: ldp             fp, lr, [SP], #0x10
    // 0xc9ea14: ret
    //     0xc9ea14: ret             
    // 0xc9ea18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc9ea18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc9ea1c: b               #0xc9e8c4
  }
}

// class id: 2282, size: 0x14, field offset: 0x14
class BoxHitTestResult extends HitTestResult {

  _ addWithPaintOffset(/* No info */) {
    // ** addr: 0x622820, size: 0xd4
    // 0x622820: EnterFrame
    //     0x622820: stp             fp, lr, [SP, #-0x10]!
    //     0x622824: mov             fp, SP
    // 0x622828: AllocStack(0x8)
    //     0x622828: sub             SP, SP, #8
    // 0x62282c: CheckStackOverflow
    //     0x62282c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x622830: cmp             SP, x16
    //     0x622834: b.ls            #0x6228ec
    // 0x622838: ldr             x0, [fp, #0x18]
    // 0x62283c: cmp             w0, NULL
    // 0x622840: b.ne            #0x62284c
    // 0x622844: ldr             x1, [fp, #0x10]
    // 0x622848: b               #0x622864
    // 0x62284c: ldr             x1, [fp, #0x10]
    // 0x622850: stp             x0, x1, [SP, #-0x10]!
    // 0x622854: r0 = -()
    //     0x622854: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x622858: add             SP, SP, #0x10
    // 0x62285c: mov             x1, x0
    // 0x622860: ldr             x0, [fp, #0x18]
    // 0x622864: stur            x1, [fp, #-8]
    // 0x622868: cmp             w0, NULL
    // 0x62286c: b.eq            #0x62288c
    // 0x622870: SaveReg r0
    //     0x622870: str             x0, [SP, #-8]!
    // 0x622874: r0 = unary-()
    //     0x622874: bl              #0x622a88  ; [dart:ui] Offset::unary-
    // 0x622878: add             SP, SP, #8
    // 0x62287c: ldr             x16, [fp, #0x28]
    // 0x622880: stp             x0, x16, [SP, #-0x10]!
    // 0x622884: r0 = pushOffset()
    //     0x622884: bl              #0x622998  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::pushOffset
    // 0x622888: add             SP, SP, #0x10
    // 0x62288c: ldr             x1, [fp, #0x18]
    // 0x622890: ldr             x16, [fp, #0x20]
    // 0x622894: ldr             lr, [fp, #0x28]
    // 0x622898: stp             lr, x16, [SP, #-0x10]!
    // 0x62289c: ldur            x16, [fp, #-8]
    // 0x6228a0: SaveReg r16
    //     0x6228a0: str             x16, [SP, #-8]!
    // 0x6228a4: ldr             x0, [fp, #0x20]
    // 0x6228a8: ClosureCall
    //     0x6228a8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x6228ac: ldur            x2, [x0, #0x1f]
    //     0x6228b0: blr             x2
    // 0x6228b4: add             SP, SP, #0x18
    // 0x6228b8: mov             x1, x0
    // 0x6228bc: ldr             x0, [fp, #0x18]
    // 0x6228c0: stur            x1, [fp, #-8]
    // 0x6228c4: cmp             w0, NULL
    // 0x6228c8: b.eq            #0x6228dc
    // 0x6228cc: ldr             x16, [fp, #0x28]
    // 0x6228d0: SaveReg r16
    //     0x6228d0: str             x16, [SP, #-8]!
    // 0x6228d4: r0 = popTransform()
    //     0x6228d4: bl              #0x6228f4  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::popTransform
    // 0x6228d8: add             SP, SP, #8
    // 0x6228dc: ldur            x0, [fp, #-8]
    // 0x6228e0: LeaveFrame
    //     0x6228e0: mov             SP, fp
    //     0x6228e4: ldp             fp, lr, [SP], #0x10
    // 0x6228e8: ret
    //     0x6228e8: ret             
    // 0x6228ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6228ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6228f0: b               #0x622838
  }
  _ addWithPaintTransform(/* No info */) {
    // ** addr: 0x622f04, size: 0x80
    // 0x622f04: EnterFrame
    //     0x622f04: stp             fp, lr, [SP, #-0x10]!
    //     0x622f08: mov             fp, SP
    // 0x622f0c: CheckStackOverflow
    //     0x622f0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x622f10: cmp             SP, x16
    //     0x622f14: b.ls            #0x622f7c
    // 0x622f18: ldr             x0, [fp, #0x10]
    // 0x622f1c: cmp             w0, NULL
    // 0x622f20: b.eq            #0x622f54
    // 0x622f24: SaveReg r0
    //     0x622f24: str             x0, [SP, #-8]!
    // 0x622f28: r0 = removePerspectiveTransform()
    //     0x622f28: bl              #0x623918  ; [package:flutter/src/gestures/events.dart] PointerEvent::removePerspectiveTransform
    // 0x622f2c: add             SP, SP, #8
    // 0x622f30: SaveReg r0
    //     0x622f30: str             x0, [SP, #-8]!
    // 0x622f34: r0 = tryInvert()
    //     0x622f34: bl              #0x623294  ; [package:vector_math/vector_math_64.dart] Matrix4::tryInvert
    // 0x622f38: add             SP, SP, #8
    // 0x622f3c: cmp             w0, NULL
    // 0x622f40: b.ne            #0x622f54
    // 0x622f44: r0 = false
    //     0x622f44: add             x0, NULL, #0x30  ; false
    // 0x622f48: LeaveFrame
    //     0x622f48: mov             SP, fp
    //     0x622f4c: ldp             fp, lr, [SP], #0x10
    // 0x622f50: ret
    //     0x622f50: ret             
    // 0x622f54: ldr             x16, [fp, #0x28]
    // 0x622f58: ldr             lr, [fp, #0x20]
    // 0x622f5c: stp             lr, x16, [SP, #-0x10]!
    // 0x622f60: ldr             x16, [fp, #0x18]
    // 0x622f64: stp             x0, x16, [SP, #-0x10]!
    // 0x622f68: r0 = addWithRawTransform()
    //     0x622f68: bl              #0x622f84  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithRawTransform
    // 0x622f6c: add             SP, SP, #0x20
    // 0x622f70: LeaveFrame
    //     0x622f70: mov             SP, fp
    //     0x622f74: ldp             fp, lr, [SP], #0x10
    // 0x622f78: ret
    //     0x622f78: ret             
    // 0x622f7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x622f7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x622f80: b               #0x622f18
  }
  _ addWithRawTransform(/* No info */) {
    // ** addr: 0x622f84, size: 0xc8
    // 0x622f84: EnterFrame
    //     0x622f84: stp             fp, lr, [SP, #-0x10]!
    //     0x622f88: mov             fp, SP
    // 0x622f8c: AllocStack(0x8)
    //     0x622f8c: sub             SP, SP, #8
    // 0x622f90: CheckStackOverflow
    //     0x622f90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x622f94: cmp             SP, x16
    //     0x622f98: b.ls            #0x623044
    // 0x622f9c: ldr             x0, [fp, #0x10]
    // 0x622fa0: cmp             w0, NULL
    // 0x622fa4: b.ne            #0x622fb0
    // 0x622fa8: ldr             x1, [fp, #0x18]
    // 0x622fac: b               #0x622fc8
    // 0x622fb0: ldr             x1, [fp, #0x18]
    // 0x622fb4: stp             x1, x0, [SP, #-0x10]!
    // 0x622fb8: r0 = transformPoint()
    //     0x622fb8: bl              #0x62313c  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::transformPoint
    // 0x622fbc: add             SP, SP, #0x10
    // 0x622fc0: mov             x1, x0
    // 0x622fc4: ldr             x0, [fp, #0x10]
    // 0x622fc8: stur            x1, [fp, #-8]
    // 0x622fcc: cmp             w0, NULL
    // 0x622fd0: b.eq            #0x622fe4
    // 0x622fd4: ldr             x16, [fp, #0x28]
    // 0x622fd8: stp             x0, x16, [SP, #-0x10]!
    // 0x622fdc: r0 = pushTransform()
    //     0x622fdc: bl              #0x62304c  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::pushTransform
    // 0x622fe0: add             SP, SP, #0x10
    // 0x622fe4: ldr             x1, [fp, #0x10]
    // 0x622fe8: ldr             x16, [fp, #0x20]
    // 0x622fec: ldr             lr, [fp, #0x28]
    // 0x622ff0: stp             lr, x16, [SP, #-0x10]!
    // 0x622ff4: ldur            x16, [fp, #-8]
    // 0x622ff8: SaveReg r16
    //     0x622ff8: str             x16, [SP, #-8]!
    // 0x622ffc: ldr             x0, [fp, #0x20]
    // 0x623000: ClosureCall
    //     0x623000: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x623004: ldur            x2, [x0, #0x1f]
    //     0x623008: blr             x2
    // 0x62300c: add             SP, SP, #0x18
    // 0x623010: mov             x1, x0
    // 0x623014: ldr             x0, [fp, #0x10]
    // 0x623018: stur            x1, [fp, #-8]
    // 0x62301c: cmp             w0, NULL
    // 0x623020: b.eq            #0x623034
    // 0x623024: ldr             x16, [fp, #0x28]
    // 0x623028: SaveReg r16
    //     0x623028: str             x16, [SP, #-8]!
    // 0x62302c: r0 = popTransform()
    //     0x62302c: bl              #0x6228f4  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::popTransform
    // 0x623030: add             SP, SP, #8
    // 0x623034: ldur            x0, [fp, #-8]
    // 0x623038: LeaveFrame
    //     0x623038: mov             SP, fp
    //     0x62303c: ldp             fp, lr, [SP], #0x10
    // 0x623040: ret
    //     0x623040: ret             
    // 0x623044: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x623044: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x623048: b               #0x622f9c
  }
  _ addWithOutOfBandPosition(/* No info */) {
    // ** addr: 0x62a858, size: 0x184
    // 0x62a858: EnterFrame
    //     0x62a858: stp             fp, lr, [SP, #-0x10]!
    //     0x62a85c: mov             fp, SP
    // 0x62a860: AllocStack(0x10)
    //     0x62a860: sub             SP, SP, #0x10
    // 0x62a864: SetupParameters(BoxHitTestResult this /* r3, fp-0x10 */, dynamic _ /* r4, fp-0x8 */, {dynamic paintOffset = Null /* r5 */, dynamic paintTransform = Null /* r0 */})
    //     0x62a864: mov             x0, x4
    //     0x62a868: ldur            w1, [x0, #0x13]
    //     0x62a86c: add             x1, x1, HEAP, lsl #32
    //     0x62a870: sub             x2, x1, #4
    //     0x62a874: add             x3, fp, w2, sxtw #2
    //     0x62a878: ldr             x3, [x3, #0x18]
    //     0x62a87c: stur            x3, [fp, #-0x10]
    //     0x62a880: add             x4, fp, w2, sxtw #2
    //     0x62a884: ldr             x4, [x4, #0x10]
    //     0x62a888: stur            x4, [fp, #-8]
    //     0x62a88c: ldur            w2, [x0, #0x1f]
    //     0x62a890: add             x2, x2, HEAP, lsl #32
    //     0x62a894: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4fb58] "paintOffset"
    //     0x62a898: ldr             x16, [x16, #0xb58]
    //     0x62a89c: cmp             w2, w16
    //     0x62a8a0: b.ne            #0x62a8c4
    //     0x62a8a4: ldur            w2, [x0, #0x23]
    //     0x62a8a8: add             x2, x2, HEAP, lsl #32
    //     0x62a8ac: sub             w5, w1, w2
    //     0x62a8b0: add             x2, fp, w5, sxtw #2
    //     0x62a8b4: ldr             x2, [x2, #8]
    //     0x62a8b8: mov             x5, x2
    //     0x62a8bc: mov             x2, #1
    //     0x62a8c0: b               #0x62a8cc
    //     0x62a8c4: mov             x5, NULL
    //     0x62a8c8: mov             x2, #0
    //     0x62a8cc: lsl             x6, x2, #1
    //     0x62a8d0: lsl             w2, w6, #1
    //     0x62a8d4: add             w6, w2, #8
    //     0x62a8d8: add             x16, x0, w6, sxtw #1
    //     0x62a8dc: ldur            w7, [x16, #0xf]
    //     0x62a8e0: add             x7, x7, HEAP, lsl #32
    //     0x62a8e4: add             x16, PP, #0x4f, lsl #12  ; [pp+0x4fb60] "paintTransform"
    //     0x62a8e8: ldr             x16, [x16, #0xb60]
    //     0x62a8ec: cmp             w7, w16
    //     0x62a8f0: b.ne            #0x62a918
    //     0x62a8f4: add             w6, w2, #0xa
    //     0x62a8f8: add             x16, x0, w6, sxtw #1
    //     0x62a8fc: ldur            w2, [x16, #0xf]
    //     0x62a900: add             x2, x2, HEAP, lsl #32
    //     0x62a904: sub             w0, w1, w2
    //     0x62a908: add             x1, fp, w0, sxtw #2
    //     0x62a90c: ldr             x1, [x1, #8]
    //     0x62a910: mov             x0, x1
    //     0x62a914: b               #0x62a91c
    //     0x62a918: mov             x0, NULL
    // 0x62a91c: CheckStackOverflow
    //     0x62a91c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62a920: cmp             SP, x16
    //     0x62a924: b.ls            #0x62a9cc
    // 0x62a928: cmp             w5, NULL
    // 0x62a92c: b.eq            #0x62a950
    // 0x62a930: SaveReg r5
    //     0x62a930: str             x5, [SP, #-8]!
    // 0x62a934: r0 = unary-()
    //     0x62a934: bl              #0x622a88  ; [dart:ui] Offset::unary-
    // 0x62a938: add             SP, SP, #8
    // 0x62a93c: ldur            x16, [fp, #-0x10]
    // 0x62a940: stp             x0, x16, [SP, #-0x10]!
    // 0x62a944: r0 = pushOffset()
    //     0x62a944: bl              #0x622998  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::pushOffset
    // 0x62a948: add             SP, SP, #0x10
    // 0x62a94c: b               #0x62a988
    // 0x62a950: cmp             w0, NULL
    // 0x62a954: b.eq            #0x62a9d4
    // 0x62a958: SaveReg r0
    //     0x62a958: str             x0, [SP, #-8]!
    // 0x62a95c: r0 = removePerspectiveTransform()
    //     0x62a95c: bl              #0x623918  ; [package:flutter/src/gestures/events.dart] PointerEvent::removePerspectiveTransform
    // 0x62a960: add             SP, SP, #8
    // 0x62a964: SaveReg r0
    //     0x62a964: str             x0, [SP, #-8]!
    // 0x62a968: r0 = tryInvert()
    //     0x62a968: bl              #0x623294  ; [package:vector_math/vector_math_64.dart] Matrix4::tryInvert
    // 0x62a96c: add             SP, SP, #8
    // 0x62a970: cmp             w0, NULL
    // 0x62a974: b.eq            #0x62a9d8
    // 0x62a978: ldur            x16, [fp, #-0x10]
    // 0x62a97c: stp             x0, x16, [SP, #-0x10]!
    // 0x62a980: r0 = pushTransform()
    //     0x62a980: bl              #0x62304c  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::pushTransform
    // 0x62a984: add             SP, SP, #0x10
    // 0x62a988: ldur            x16, [fp, #-8]
    // 0x62a98c: ldur            lr, [fp, #-0x10]
    // 0x62a990: stp             lr, x16, [SP, #-0x10]!
    // 0x62a994: ldur            x0, [fp, #-8]
    // 0x62a998: ClosureCall
    //     0x62a998: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x62a99c: ldur            x2, [x0, #0x1f]
    //     0x62a9a0: blr             x2
    // 0x62a9a4: add             SP, SP, #0x10
    // 0x62a9a8: stur            x0, [fp, #-8]
    // 0x62a9ac: ldur            x16, [fp, #-0x10]
    // 0x62a9b0: SaveReg r16
    //     0x62a9b0: str             x16, [SP, #-8]!
    // 0x62a9b4: r0 = popTransform()
    //     0x62a9b4: bl              #0x6228f4  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::popTransform
    // 0x62a9b8: add             SP, SP, #8
    // 0x62a9bc: ldur            x0, [fp, #-8]
    // 0x62a9c0: LeaveFrame
    //     0x62a9c0: mov             SP, fp
    //     0x62a9c4: ldp             fp, lr, [SP], #0x10
    // 0x62a9c8: ret
    //     0x62a9c8: ret             
    // 0x62a9cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62a9cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62a9d0: b               #0x62a928
    // 0x62a9d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x62a9d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x62a9d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x62a9d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2288, size: 0x18, field offset: 0x14
class BoxHitTestEntry extends HitTestEntry<RenderBox> {

  _ toString(/* No info */) {
    // ** addr: 0xad9524, size: 0x84
    // 0xad9524: EnterFrame
    //     0xad9524: stp             fp, lr, [SP, #-0x10]!
    //     0xad9528: mov             fp, SP
    // 0xad952c: AllocStack(0x8)
    //     0xad952c: sub             SP, SP, #8
    // 0xad9530: CheckStackOverflow
    //     0xad9530: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad9534: cmp             SP, x16
    //     0xad9538: b.ls            #0xad95a0
    // 0xad953c: ldr             x0, [fp, #0x10]
    // 0xad9540: LoadField: r1 = r0->field_b
    //     0xad9540: ldur            w1, [x0, #0xb]
    // 0xad9544: DecompressPointer r1
    //     0xad9544: add             x1, x1, HEAP, lsl #32
    // 0xad9548: SaveReg r1
    //     0xad9548: str             x1, [SP, #-8]!
    // 0xad954c: r0 = describeIdentity()
    //     0xad954c: bl              #0xa77c6c  ; [package:flutter/src/foundation/diagnostics.dart] ::describeIdentity
    // 0xad9550: add             SP, SP, #8
    // 0xad9554: r1 = Null
    //     0xad9554: mov             x1, NULL
    // 0xad9558: r2 = 6
    //     0xad9558: mov             x2, #6
    // 0xad955c: stur            x0, [fp, #-8]
    // 0xad9560: r0 = AllocateArray()
    //     0xad9560: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad9564: mov             x1, x0
    // 0xad9568: ldur            x0, [fp, #-8]
    // 0xad956c: StoreField: r1->field_f = r0
    //     0xad956c: stur            w0, [x1, #0xf]
    // 0xad9570: r17 = "@"
    //     0xad9570: ldr             x17, [PP, #0x1568]  ; [pp+0x1568] "@"
    // 0xad9574: StoreField: r1->field_13 = r17
    //     0xad9574: stur            w17, [x1, #0x13]
    // 0xad9578: ldr             x0, [fp, #0x10]
    // 0xad957c: LoadField: r2 = r0->field_13
    //     0xad957c: ldur            w2, [x0, #0x13]
    // 0xad9580: DecompressPointer r2
    //     0xad9580: add             x2, x2, HEAP, lsl #32
    // 0xad9584: StoreField: r1->field_17 = r2
    //     0xad9584: stur            w2, [x1, #0x17]
    // 0xad9588: SaveReg r1
    //     0xad9588: str             x1, [SP, #-8]!
    // 0xad958c: r0 = _interpolate()
    //     0xad958c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad9590: add             SP, SP, #8
    // 0xad9594: LeaveFrame
    //     0xad9594: mov             SP, fp
    //     0xad9598: ldp             fp, lr, [SP], #0x10
    // 0xad959c: ret
    //     0xad959c: ret             
    // 0xad95a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad95a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad95a4: b               #0xad953c
  }
}

// class id: 2404, size: 0x60, field offset: 0x50
abstract class RenderBox extends RenderObject {

  [closure] void markNeedsLayout(dynamic) {
    // ** addr: 0x5ae100, size: 0x48
    // 0x5ae100: EnterFrame
    //     0x5ae100: stp             fp, lr, [SP, #-0x10]!
    //     0x5ae104: mov             fp, SP
    // 0x5ae108: ldr             x0, [fp, #0x10]
    // 0x5ae10c: LoadField: r1 = r0->field_17
    //     0x5ae10c: ldur            w1, [x0, #0x17]
    // 0x5ae110: DecompressPointer r1
    //     0x5ae110: add             x1, x1, HEAP, lsl #32
    // 0x5ae114: CheckStackOverflow
    //     0x5ae114: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5ae118: cmp             SP, x16
    //     0x5ae11c: b.ls            #0x5ae140
    // 0x5ae120: LoadField: r0 = r1->field_f
    //     0x5ae120: ldur            w0, [x1, #0xf]
    // 0x5ae124: DecompressPointer r0
    //     0x5ae124: add             x0, x0, HEAP, lsl #32
    // 0x5ae128: SaveReg r0
    //     0x5ae128: str             x0, [SP, #-8]!
    // 0x5ae12c: r0 = markNeedsLayout()
    //     0x5ae12c: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x5ae130: add             SP, SP, #8
    // 0x5ae134: LeaveFrame
    //     0x5ae134: mov             SP, fp
    //     0x5ae138: ldp             fp, lr, [SP], #0x10
    // 0x5ae13c: ret
    //     0x5ae13c: ret             
    // 0x5ae140: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5ae140: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5ae144: b               #0x5ae120
  }
  _ _clearCachedData(/* No info */) {
    // ** addr: 0x5ae21c, size: 0x130
    // 0x5ae21c: EnterFrame
    //     0x5ae21c: stp             fp, lr, [SP, #-0x10]!
    //     0x5ae220: mov             fp, SP
    // 0x5ae224: CheckStackOverflow
    //     0x5ae224: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5ae228: cmp             SP, x16
    //     0x5ae22c: b.ls            #0x5ae344
    // 0x5ae230: ldr             x0, [fp, #0x10]
    // 0x5ae234: LoadField: r1 = r0->field_5b
    //     0x5ae234: ldur            w1, [x0, #0x5b]
    // 0x5ae238: DecompressPointer r1
    //     0x5ae238: add             x1, x1, HEAP, lsl #32
    // 0x5ae23c: cmp             w1, NULL
    // 0x5ae240: b.eq            #0x5ae268
    // 0x5ae244: LoadField: r2 = r1->field_13
    //     0x5ae244: ldur            w2, [x1, #0x13]
    // 0x5ae248: DecompressPointer r2
    //     0x5ae248: add             x2, x2, HEAP, lsl #32
    // 0x5ae24c: r3 = LoadInt32Instr(r2)
    //     0x5ae24c: sbfx            x3, x2, #1, #0x1f
    // 0x5ae250: asr             x2, x3, #1
    // 0x5ae254: LoadField: r3 = r1->field_17
    //     0x5ae254: ldur            w3, [x1, #0x17]
    // 0x5ae258: DecompressPointer r3
    //     0x5ae258: add             x3, x3, HEAP, lsl #32
    // 0x5ae25c: r4 = LoadInt32Instr(r3)
    //     0x5ae25c: sbfx            x4, x3, #1, #0x1f
    // 0x5ae260: sub             x3, x2, x4
    // 0x5ae264: cbnz            x3, #0x5ae2d0
    // 0x5ae268: LoadField: r2 = r0->field_4f
    //     0x5ae268: ldur            w2, [x0, #0x4f]
    // 0x5ae26c: DecompressPointer r2
    //     0x5ae26c: add             x2, x2, HEAP, lsl #32
    // 0x5ae270: cmp             w2, NULL
    // 0x5ae274: b.eq            #0x5ae29c
    // 0x5ae278: LoadField: r3 = r2->field_13
    //     0x5ae278: ldur            w3, [x2, #0x13]
    // 0x5ae27c: DecompressPointer r3
    //     0x5ae27c: add             x3, x3, HEAP, lsl #32
    // 0x5ae280: r4 = LoadInt32Instr(r3)
    //     0x5ae280: sbfx            x4, x3, #1, #0x1f
    // 0x5ae284: asr             x3, x4, #1
    // 0x5ae288: LoadField: r4 = r2->field_17
    //     0x5ae288: ldur            w4, [x2, #0x17]
    // 0x5ae28c: DecompressPointer r4
    //     0x5ae28c: add             x4, x4, HEAP, lsl #32
    // 0x5ae290: r2 = LoadInt32Instr(r4)
    //     0x5ae290: sbfx            x2, x4, #1, #0x1f
    // 0x5ae294: sub             x4, x3, x2
    // 0x5ae298: cbnz            x4, #0x5ae2d0
    // 0x5ae29c: LoadField: r2 = r0->field_53
    //     0x5ae29c: ldur            w2, [x0, #0x53]
    // 0x5ae2a0: DecompressPointer r2
    //     0x5ae2a0: add             x2, x2, HEAP, lsl #32
    // 0x5ae2a4: cmp             w2, NULL
    // 0x5ae2a8: b.eq            #0x5ae334
    // 0x5ae2ac: LoadField: r3 = r2->field_13
    //     0x5ae2ac: ldur            w3, [x2, #0x13]
    // 0x5ae2b0: DecompressPointer r3
    //     0x5ae2b0: add             x3, x3, HEAP, lsl #32
    // 0x5ae2b4: r4 = LoadInt32Instr(r3)
    //     0x5ae2b4: sbfx            x4, x3, #1, #0x1f
    // 0x5ae2b8: asr             x3, x4, #1
    // 0x5ae2bc: LoadField: r4 = r2->field_17
    //     0x5ae2bc: ldur            w4, [x2, #0x17]
    // 0x5ae2c0: DecompressPointer r4
    //     0x5ae2c0: add             x4, x4, HEAP, lsl #32
    // 0x5ae2c4: r2 = LoadInt32Instr(r4)
    //     0x5ae2c4: sbfx            x2, x4, #1, #0x1f
    // 0x5ae2c8: sub             x4, x3, x2
    // 0x5ae2cc: cbz             x4, #0x5ae334
    // 0x5ae2d0: cmp             w1, NULL
    // 0x5ae2d4: b.eq            #0x5ae2e8
    // 0x5ae2d8: SaveReg r1
    //     0x5ae2d8: str             x1, [SP, #-8]!
    // 0x5ae2dc: r0 = clear()
    //     0x5ae2dc: bl              #0x4e32e4  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x5ae2e0: add             SP, SP, #8
    // 0x5ae2e4: ldr             x0, [fp, #0x10]
    // 0x5ae2e8: LoadField: r1 = r0->field_4f
    //     0x5ae2e8: ldur            w1, [x0, #0x4f]
    // 0x5ae2ec: DecompressPointer r1
    //     0x5ae2ec: add             x1, x1, HEAP, lsl #32
    // 0x5ae2f0: cmp             w1, NULL
    // 0x5ae2f4: b.eq            #0x5ae308
    // 0x5ae2f8: SaveReg r1
    //     0x5ae2f8: str             x1, [SP, #-8]!
    // 0x5ae2fc: r0 = clear()
    //     0x5ae2fc: bl              #0x4e32e4  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x5ae300: add             SP, SP, #8
    // 0x5ae304: ldr             x0, [fp, #0x10]
    // 0x5ae308: LoadField: r1 = r0->field_53
    //     0x5ae308: ldur            w1, [x0, #0x53]
    // 0x5ae30c: DecompressPointer r1
    //     0x5ae30c: add             x1, x1, HEAP, lsl #32
    // 0x5ae310: cmp             w1, NULL
    // 0x5ae314: b.eq            #0x5ae324
    // 0x5ae318: SaveReg r1
    //     0x5ae318: str             x1, [SP, #-8]!
    // 0x5ae31c: r0 = clear()
    //     0x5ae31c: bl              #0x4e32e4  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x5ae320: add             SP, SP, #8
    // 0x5ae324: r0 = true
    //     0x5ae324: add             x0, NULL, #0x20  ; true
    // 0x5ae328: LeaveFrame
    //     0x5ae328: mov             SP, fp
    //     0x5ae32c: ldp             fp, lr, [SP], #0x10
    // 0x5ae330: ret
    //     0x5ae330: ret             
    // 0x5ae334: r0 = false
    //     0x5ae334: add             x0, NULL, #0x30  ; false
    // 0x5ae338: LeaveFrame
    //     0x5ae338: mov             SP, fp
    //     0x5ae33c: ldp             fp, lr, [SP], #0x10
    // 0x5ae340: ret
    //     0x5ae340: ret             
    // 0x5ae344: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5ae344: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5ae348: b               #0x5ae230
  }
  _ getMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0x62cb24, size: 0x70
    // 0x62cb24: EnterFrame
    //     0x62cb24: stp             fp, lr, [SP, #-0x10]!
    //     0x62cb28: mov             fp, SP
    // 0x62cb2c: CheckStackOverflow
    //     0x62cb2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62cb30: cmp             SP, x16
    //     0x62cb34: b.ls            #0x62cb8c
    // 0x62cb38: ldr             x1, [fp, #0x18]
    // 0x62cb3c: r0 = LoadClassIdInstr(r1)
    //     0x62cb3c: ldur            x0, [x1, #-1]
    //     0x62cb40: ubfx            x0, x0, #0xc, #0x14
    // 0x62cb44: SaveReg r1
    //     0x62cb44: str             x1, [SP, #-8]!
    // 0x62cb48: r0 = GDT[cid_x0 + 0xf291]()
    //     0x62cb48: mov             x17, #0xf291
    //     0x62cb4c: add             lr, x0, x17
    //     0x62cb50: ldr             lr, [x21, lr, lsl #3]
    //     0x62cb54: blr             lr
    // 0x62cb58: add             SP, SP, #8
    // 0x62cb5c: ldr             x16, [fp, #0x18]
    // 0x62cb60: r30 = Instance__IntrinsicDimension
    //     0x62cb60: add             lr, PP, #0x40, lsl #12  ; [pp+0x40bd0] Obj!_IntrinsicDimension@b64bd1
    //     0x62cb64: ldr             lr, [lr, #0xbd0]
    // 0x62cb68: stp             lr, x16, [SP, #-0x10]!
    // 0x62cb6c: ldr             d0, [fp, #0x10]
    // 0x62cb70: SaveReg d0
    //     0x62cb70: str             d0, [SP, #-8]!
    // 0x62cb74: SaveReg r0
    //     0x62cb74: str             x0, [SP, #-8]!
    // 0x62cb78: r0 = _computeIntrinsicDimension()
    //     0x62cb78: bl              #0x62cc04  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsicDimension
    // 0x62cb7c: add             SP, SP, #0x20
    // 0x62cb80: LeaveFrame
    //     0x62cb80: mov             SP, fp
    //     0x62cb84: ldp             fp, lr, [SP], #0x10
    // 0x62cb88: ret
    //     0x62cb88: ret             
    // 0x62cb8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62cb8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62cb90: b               #0x62cb38
  }
  _ getMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0x62cb94, size: 0x70
    // 0x62cb94: EnterFrame
    //     0x62cb94: stp             fp, lr, [SP, #-0x10]!
    //     0x62cb98: mov             fp, SP
    // 0x62cb9c: CheckStackOverflow
    //     0x62cb9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62cba0: cmp             SP, x16
    //     0x62cba4: b.ls            #0x62cbfc
    // 0x62cba8: ldr             x1, [fp, #0x18]
    // 0x62cbac: r0 = LoadClassIdInstr(r1)
    //     0x62cbac: ldur            x0, [x1, #-1]
    //     0x62cbb0: ubfx            x0, x0, #0xc, #0x14
    // 0x62cbb4: SaveReg r1
    //     0x62cbb4: str             x1, [SP, #-8]!
    // 0x62cbb8: r0 = GDT[cid_x0 + 0xf204]()
    //     0x62cbb8: mov             x17, #0xf204
    //     0x62cbbc: add             lr, x0, x17
    //     0x62cbc0: ldr             lr, [x21, lr, lsl #3]
    //     0x62cbc4: blr             lr
    // 0x62cbc8: add             SP, SP, #8
    // 0x62cbcc: ldr             x16, [fp, #0x18]
    // 0x62cbd0: r30 = Instance__IntrinsicDimension
    //     0x62cbd0: add             lr, PP, #0x37, lsl #12  ; [pp+0x37080] Obj!_IntrinsicDimension@b64bf1
    //     0x62cbd4: ldr             lr, [lr, #0x80]
    // 0x62cbd8: stp             lr, x16, [SP, #-0x10]!
    // 0x62cbdc: ldr             d0, [fp, #0x10]
    // 0x62cbe0: SaveReg d0
    //     0x62cbe0: str             d0, [SP, #-8]!
    // 0x62cbe4: SaveReg r0
    //     0x62cbe4: str             x0, [SP, #-8]!
    // 0x62cbe8: r0 = _computeIntrinsicDimension()
    //     0x62cbe8: bl              #0x62cc04  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsicDimension
    // 0x62cbec: add             SP, SP, #0x20
    // 0x62cbf0: LeaveFrame
    //     0x62cbf0: mov             SP, fp
    //     0x62cbf4: ldp             fp, lr, [SP], #0x10
    // 0x62cbf8: ret
    //     0x62cbf8: ret             
    // 0x62cbfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62cbfc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62cc00: b               #0x62cba8
  }
  _ _computeIntrinsicDimension(/* No info */) {
    // ** addr: 0x62cc04, size: 0x15c
    // 0x62cc04: EnterFrame
    //     0x62cc04: stp             fp, lr, [SP, #-0x10]!
    //     0x62cc08: mov             fp, SP
    // 0x62cc0c: AllocStack(0x20)
    //     0x62cc0c: sub             SP, SP, #0x20
    // 0x62cc10: CheckStackOverflow
    //     0x62cc10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62cc14: cmp             SP, x16
    //     0x62cc18: b.ls            #0x62cd44
    // 0x62cc1c: ldr             d0, [fp, #0x18]
    // 0x62cc20: r0 = inline_Allocate_Double()
    //     0x62cc20: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62cc24: add             x0, x0, #0x10
    //     0x62cc28: cmp             x1, x0
    //     0x62cc2c: b.ls            #0x62cd4c
    //     0x62cc30: str             x0, [THR, #0x60]  ; THR::top
    //     0x62cc34: sub             x0, x0, #0xf
    //     0x62cc38: mov             x1, #0xd108
    //     0x62cc3c: movk            x1, #3, lsl #16
    //     0x62cc40: stur            x1, [x0, #-1]
    // 0x62cc44: StoreField: r0->field_7 = d0
    //     0x62cc44: stur            d0, [x0, #7]
    // 0x62cc48: stur            x0, [fp, #-8]
    // 0x62cc4c: r1 = 2
    //     0x62cc4c: mov             x1, #2
    // 0x62cc50: r0 = AllocateContext()
    //     0x62cc50: bl              #0xd68aa4  ; AllocateContextStub
    // 0x62cc54: mov             x1, x0
    // 0x62cc58: ldur            x0, [fp, #-8]
    // 0x62cc5c: stur            x1, [fp, #-0x10]
    // 0x62cc60: StoreField: r1->field_f = r0
    //     0x62cc60: stur            w0, [x1, #0xf]
    // 0x62cc64: ldr             x0, [fp, #0x10]
    // 0x62cc68: StoreField: r1->field_13 = r0
    //     0x62cc68: stur            w0, [x1, #0x13]
    // 0x62cc6c: ldr             x0, [fp, #0x28]
    // 0x62cc70: LoadField: r2 = r0->field_4f
    //     0x62cc70: ldur            w2, [x0, #0x4f]
    // 0x62cc74: DecompressPointer r2
    //     0x62cc74: add             x2, x2, HEAP, lsl #32
    // 0x62cc78: cmp             w2, NULL
    // 0x62cc7c: b.ne            #0x62ccc8
    // 0x62cc80: r16 = <_IntrinsicDimensionsCacheEntry, double>
    //     0x62cc80: add             x16, PP, #0x37, lsl #12  ; [pp+0x37088] TypeArguments: <_IntrinsicDimensionsCacheEntry, double>
    //     0x62cc84: ldr             x16, [x16, #0x88]
    // 0x62cc88: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x62cc8c: stp             lr, x16, [SP, #-0x10]!
    // 0x62cc90: r0 = Map._fromLiteral()
    //     0x62cc90: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x62cc94: add             SP, SP, #0x10
    // 0x62cc98: mov             x2, x0
    // 0x62cc9c: ldr             x1, [fp, #0x28]
    // 0x62cca0: StoreField: r1->field_4f = r0
    //     0x62cca0: stur            w0, [x1, #0x4f]
    //     0x62cca4: tbz             w0, #0, #0x62ccc0
    //     0x62cca8: ldurb           w16, [x1, #-1]
    //     0x62ccac: ldurb           w17, [x0, #-1]
    //     0x62ccb0: and             x16, x17, x16, lsr #2
    //     0x62ccb4: tst             x16, HEAP, lsr #32
    //     0x62ccb8: b.eq            #0x62ccc0
    //     0x62ccbc: bl              #0xd6826c
    // 0x62ccc0: mov             x1, x2
    // 0x62ccc4: b               #0x62cccc
    // 0x62ccc8: mov             x1, x2
    // 0x62cccc: ldr             x0, [fp, #0x20]
    // 0x62ccd0: ldur            x2, [fp, #-0x10]
    // 0x62ccd4: stur            x1, [fp, #-0x18]
    // 0x62ccd8: cmp             w1, NULL
    // 0x62ccdc: b.eq            #0x62cd5c
    // 0x62cce0: LoadField: r3 = r2->field_f
    //     0x62cce0: ldur            w3, [x2, #0xf]
    // 0x62cce4: DecompressPointer r3
    //     0x62cce4: add             x3, x3, HEAP, lsl #32
    // 0x62cce8: stur            x3, [fp, #-8]
    // 0x62ccec: r0 = _IntrinsicDimensionsCacheEntry()
    //     0x62ccec: bl              #0x62cd60  ; Allocate_IntrinsicDimensionsCacheEntryStub -> _IntrinsicDimensionsCacheEntry (size=0x14)
    // 0x62ccf0: mov             x3, x0
    // 0x62ccf4: ldr             x0, [fp, #0x20]
    // 0x62ccf8: stur            x3, [fp, #-0x20]
    // 0x62ccfc: StoreField: r3->field_7 = r0
    //     0x62ccfc: stur            w0, [x3, #7]
    // 0x62cd00: ldur            x0, [fp, #-8]
    // 0x62cd04: LoadField: d0 = r0->field_7
    //     0x62cd04: ldur            d0, [x0, #7]
    // 0x62cd08: StoreField: r3->field_b = d0
    //     0x62cd08: stur            d0, [x3, #0xb]
    // 0x62cd0c: ldur            x2, [fp, #-0x10]
    // 0x62cd10: r1 = Function '<anonymous closure>':.
    //     0x62cd10: add             x1, PP, #0x37, lsl #12  ; [pp+0x37090] AnonymousClosure: (0x62cd8c), in [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsicDimension (0x62cc04)
    //     0x62cd14: ldr             x1, [x1, #0x90]
    // 0x62cd18: r0 = AllocateClosure()
    //     0x62cd18: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x62cd1c: ldur            x16, [fp, #-0x18]
    // 0x62cd20: ldur            lr, [fp, #-0x20]
    // 0x62cd24: stp             lr, x16, [SP, #-0x10]!
    // 0x62cd28: SaveReg r0
    //     0x62cd28: str             x0, [SP, #-8]!
    // 0x62cd2c: r0 = putIfAbsent()
    //     0x62cd2c: bl              #0xc7a83c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0x62cd30: add             SP, SP, #0x18
    // 0x62cd34: LoadField: d0 = r0->field_7
    //     0x62cd34: ldur            d0, [x0, #7]
    // 0x62cd38: LeaveFrame
    //     0x62cd38: mov             SP, fp
    //     0x62cd3c: ldp             fp, lr, [SP], #0x10
    // 0x62cd40: ret
    //     0x62cd40: ret             
    // 0x62cd44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62cd44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62cd48: b               #0x62cc1c
    // 0x62cd4c: SaveReg d0
    //     0x62cd4c: str             q0, [SP, #-0x10]!
    // 0x62cd50: r0 = AllocateDouble()
    //     0x62cd50: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62cd54: RestoreReg d0
    //     0x62cd54: ldr             q0, [SP], #0x10
    // 0x62cd58: b               #0x62cc44
    // 0x62cd5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x62cd5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] double <anonymous closure>(dynamic) {
    // ** addr: 0x62cd8c, size: 0x64
    // 0x62cd8c: EnterFrame
    //     0x62cd8c: stp             fp, lr, [SP, #-0x10]!
    //     0x62cd90: mov             fp, SP
    // 0x62cd94: ldr             x0, [fp, #0x10]
    // 0x62cd98: LoadField: r1 = r0->field_17
    //     0x62cd98: ldur            w1, [x0, #0x17]
    // 0x62cd9c: DecompressPointer r1
    //     0x62cd9c: add             x1, x1, HEAP, lsl #32
    // 0x62cda0: CheckStackOverflow
    //     0x62cda0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62cda4: cmp             SP, x16
    //     0x62cda8: b.ls            #0x62cde4
    // 0x62cdac: LoadField: r0 = r1->field_13
    //     0x62cdac: ldur            w0, [x1, #0x13]
    // 0x62cdb0: DecompressPointer r0
    //     0x62cdb0: add             x0, x0, HEAP, lsl #32
    // 0x62cdb4: LoadField: r2 = r1->field_f
    //     0x62cdb4: ldur            w2, [x1, #0xf]
    // 0x62cdb8: DecompressPointer r2
    //     0x62cdb8: add             x2, x2, HEAP, lsl #32
    // 0x62cdbc: cmp             w0, NULL
    // 0x62cdc0: b.eq            #0x62cdec
    // 0x62cdc4: stp             x2, x0, [SP, #-0x10]!
    // 0x62cdc8: ClosureCall
    //     0x62cdc8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x62cdcc: ldur            x2, [x0, #0x1f]
    //     0x62cdd0: blr             x2
    // 0x62cdd4: add             SP, SP, #0x10
    // 0x62cdd8: LeaveFrame
    //     0x62cdd8: mov             SP, fp
    //     0x62cddc: ldp             fp, lr, [SP], #0x10
    // 0x62cde0: ret
    //     0x62cde0: ret             
    // 0x62cde4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62cde4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62cde8: b               #0x62cdac
    // 0x62cdec: r0 = NullErrorSharedWithoutFPURegs()
    //     0x62cdec: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ getDryLayout(/* No info */) {
    // ** addr: 0x62d394, size: 0xec
    // 0x62d394: EnterFrame
    //     0x62d394: stp             fp, lr, [SP, #-0x10]!
    //     0x62d398: mov             fp, SP
    // 0x62d39c: AllocStack(0x18)
    //     0x62d39c: sub             SP, SP, #0x18
    // 0x62d3a0: CheckStackOverflow
    //     0x62d3a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62d3a4: cmp             SP, x16
    //     0x62d3a8: b.ls            #0x62d474
    // 0x62d3ac: r1 = 2
    //     0x62d3ac: mov             x1, #2
    // 0x62d3b0: r0 = AllocateContext()
    //     0x62d3b0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x62d3b4: mov             x1, x0
    // 0x62d3b8: ldr             x0, [fp, #0x18]
    // 0x62d3bc: stur            x1, [fp, #-8]
    // 0x62d3c0: StoreField: r1->field_f = r0
    //     0x62d3c0: stur            w0, [x1, #0xf]
    // 0x62d3c4: ldr             x2, [fp, #0x10]
    // 0x62d3c8: StoreField: r1->field_13 = r2
    //     0x62d3c8: stur            w2, [x1, #0x13]
    // 0x62d3cc: LoadField: r2 = r0->field_53
    //     0x62d3cc: ldur            w2, [x0, #0x53]
    // 0x62d3d0: DecompressPointer r2
    //     0x62d3d0: add             x2, x2, HEAP, lsl #32
    // 0x62d3d4: cmp             w2, NULL
    // 0x62d3d8: b.ne            #0x62d424
    // 0x62d3dc: r16 = <BoxConstraints, Size>
    //     0x62d3dc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15208] TypeArguments: <BoxConstraints, Size>
    //     0x62d3e0: ldr             x16, [x16, #0x208]
    // 0x62d3e4: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x62d3e8: stp             lr, x16, [SP, #-0x10]!
    // 0x62d3ec: r0 = Map._fromLiteral()
    //     0x62d3ec: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x62d3f0: add             SP, SP, #0x10
    // 0x62d3f4: mov             x2, x0
    // 0x62d3f8: ldr             x1, [fp, #0x18]
    // 0x62d3fc: StoreField: r1->field_53 = r0
    //     0x62d3fc: stur            w0, [x1, #0x53]
    //     0x62d400: tbz             w0, #0, #0x62d41c
    //     0x62d404: ldurb           w16, [x1, #-1]
    //     0x62d408: ldurb           w17, [x0, #-1]
    //     0x62d40c: and             x16, x17, x16, lsr #2
    //     0x62d410: tst             x16, HEAP, lsr #32
    //     0x62d414: b.eq            #0x62d41c
    //     0x62d418: bl              #0xd6826c
    // 0x62d41c: mov             x0, x2
    // 0x62d420: b               #0x62d428
    // 0x62d424: mov             x0, x2
    // 0x62d428: ldur            x2, [fp, #-8]
    // 0x62d42c: stur            x0, [fp, #-0x18]
    // 0x62d430: cmp             w0, NULL
    // 0x62d434: b.eq            #0x62d47c
    // 0x62d438: LoadField: r3 = r2->field_13
    //     0x62d438: ldur            w3, [x2, #0x13]
    // 0x62d43c: DecompressPointer r3
    //     0x62d43c: add             x3, x3, HEAP, lsl #32
    // 0x62d440: stur            x3, [fp, #-0x10]
    // 0x62d444: r1 = Function '<anonymous closure>':.
    //     0x62d444: add             x1, PP, #0x15, lsl #12  ; [pp+0x15210] AnonymousClosure: (0x62d778), in [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout (0x62d394)
    //     0x62d448: ldr             x1, [x1, #0x210]
    // 0x62d44c: r0 = AllocateClosure()
    //     0x62d44c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x62d450: ldur            x16, [fp, #-0x18]
    // 0x62d454: ldur            lr, [fp, #-0x10]
    // 0x62d458: stp             lr, x16, [SP, #-0x10]!
    // 0x62d45c: SaveReg r0
    //     0x62d45c: str             x0, [SP, #-8]!
    // 0x62d460: r0 = putIfAbsent()
    //     0x62d460: bl              #0xc7a83c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0x62d464: add             SP, SP, #0x18
    // 0x62d468: LeaveFrame
    //     0x62d468: mov             SP, fp
    //     0x62d46c: ldp             fp, lr, [SP], #0x10
    // 0x62d470: ret
    //     0x62d470: ret             
    // 0x62d474: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62d474: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62d478: b               #0x62d3ac
    // 0x62d47c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x62d47c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Size <anonymous closure>(dynamic) {
    // ** addr: 0x62d778, size: 0x50
    // 0x62d778: EnterFrame
    //     0x62d778: stp             fp, lr, [SP, #-0x10]!
    //     0x62d77c: mov             fp, SP
    // 0x62d780: ldr             x0, [fp, #0x10]
    // 0x62d784: LoadField: r1 = r0->field_17
    //     0x62d784: ldur            w1, [x0, #0x17]
    // 0x62d788: DecompressPointer r1
    //     0x62d788: add             x1, x1, HEAP, lsl #32
    // 0x62d78c: CheckStackOverflow
    //     0x62d78c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62d790: cmp             SP, x16
    //     0x62d794: b.ls            #0x62d7c0
    // 0x62d798: LoadField: r0 = r1->field_f
    //     0x62d798: ldur            w0, [x1, #0xf]
    // 0x62d79c: DecompressPointer r0
    //     0x62d79c: add             x0, x0, HEAP, lsl #32
    // 0x62d7a0: LoadField: r2 = r1->field_13
    //     0x62d7a0: ldur            w2, [x1, #0x13]
    // 0x62d7a4: DecompressPointer r2
    //     0x62d7a4: add             x2, x2, HEAP, lsl #32
    // 0x62d7a8: stp             x2, x0, [SP, #-0x10]!
    // 0x62d7ac: r0 = _computeDryLayout()
    //     0x62d7ac: bl              #0x62d7c8  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeDryLayout
    // 0x62d7b0: add             SP, SP, #0x10
    // 0x62d7b4: LeaveFrame
    //     0x62d7b4: mov             SP, fp
    //     0x62d7b8: ldp             fp, lr, [SP], #0x10
    // 0x62d7bc: ret
    //     0x62d7bc: ret             
    // 0x62d7c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62d7c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62d7c4: b               #0x62d798
  }
  _ _computeDryLayout(/* No info */) {
    // ** addr: 0x62d7c8, size: 0x54
    // 0x62d7c8: EnterFrame
    //     0x62d7c8: stp             fp, lr, [SP, #-0x10]!
    //     0x62d7cc: mov             fp, SP
    // 0x62d7d0: CheckStackOverflow
    //     0x62d7d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62d7d4: cmp             SP, x16
    //     0x62d7d8: b.ls            #0x62d814
    // 0x62d7dc: ldr             x0, [fp, #0x18]
    // 0x62d7e0: r1 = LoadClassIdInstr(r0)
    //     0x62d7e0: ldur            x1, [x0, #-1]
    //     0x62d7e4: ubfx            x1, x1, #0xc, #0x14
    // 0x62d7e8: ldr             x16, [fp, #0x10]
    // 0x62d7ec: stp             x16, x0, [SP, #-0x10]!
    // 0x62d7f0: mov             x0, x1
    // 0x62d7f4: r0 = GDT[cid_x0 + 0xa6df]()
    //     0x62d7f4: mov             x17, #0xa6df
    //     0x62d7f8: add             lr, x0, x17
    //     0x62d7fc: ldr             lr, [x21, lr, lsl #3]
    //     0x62d800: blr             lr
    // 0x62d804: add             SP, SP, #0x10
    // 0x62d808: LeaveFrame
    //     0x62d808: mov             SP, fp
    //     0x62d80c: ldp             fp, lr, [SP], #0x10
    // 0x62d810: ret
    //     0x62d810: ret             
    // 0x62d814: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62d814: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62d818: b               #0x62d7dc
  }
  _ getMinIntrinsicHeight(/* No info */) {
    // ** addr: 0x630a58, size: 0x70
    // 0x630a58: EnterFrame
    //     0x630a58: stp             fp, lr, [SP, #-0x10]!
    //     0x630a5c: mov             fp, SP
    // 0x630a60: CheckStackOverflow
    //     0x630a60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x630a64: cmp             SP, x16
    //     0x630a68: b.ls            #0x630ac0
    // 0x630a6c: ldr             x1, [fp, #0x18]
    // 0x630a70: r0 = LoadClassIdInstr(r1)
    //     0x630a70: ldur            x0, [x1, #-1]
    //     0x630a74: ubfx            x0, x0, #0xc, #0x14
    // 0x630a78: SaveReg r1
    //     0x630a78: str             x1, [SP, #-8]!
    // 0x630a7c: r0 = GDT[cid_x0 + 0xf169]()
    //     0x630a7c: mov             x17, #0xf169
    //     0x630a80: add             lr, x0, x17
    //     0x630a84: ldr             lr, [x21, lr, lsl #3]
    //     0x630a88: blr             lr
    // 0x630a8c: add             SP, SP, #8
    // 0x630a90: ldr             x16, [fp, #0x18]
    // 0x630a94: r30 = Instance__IntrinsicDimension
    //     0x630a94: add             lr, PP, #0x4f, lsl #12  ; [pp+0x4fcf8] Obj!_IntrinsicDimension@b64c11
    //     0x630a98: ldr             lr, [lr, #0xcf8]
    // 0x630a9c: stp             lr, x16, [SP, #-0x10]!
    // 0x630aa0: ldr             d0, [fp, #0x10]
    // 0x630aa4: SaveReg d0
    //     0x630aa4: str             d0, [SP, #-8]!
    // 0x630aa8: SaveReg r0
    //     0x630aa8: str             x0, [SP, #-8]!
    // 0x630aac: r0 = _computeIntrinsicDimension()
    //     0x630aac: bl              #0x62cc04  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsicDimension
    // 0x630ab0: add             SP, SP, #0x20
    // 0x630ab4: LeaveFrame
    //     0x630ab4: mov             SP, fp
    //     0x630ab8: ldp             fp, lr, [SP], #0x10
    // 0x630abc: ret
    //     0x630abc: ret             
    // 0x630ac0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x630ac0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x630ac4: b               #0x630a6c
  }
  _ getMinIntrinsicWidth(/* No info */) {
    // ** addr: 0x630b18, size: 0x70
    // 0x630b18: EnterFrame
    //     0x630b18: stp             fp, lr, [SP, #-0x10]!
    //     0x630b1c: mov             fp, SP
    // 0x630b20: CheckStackOverflow
    //     0x630b20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x630b24: cmp             SP, x16
    //     0x630b28: b.ls            #0x630b80
    // 0x630b2c: ldr             x1, [fp, #0x18]
    // 0x630b30: r0 = LoadClassIdInstr(r1)
    //     0x630b30: ldur            x0, [x1, #-1]
    //     0x630b34: ubfx            x0, x0, #0xc, #0x14
    // 0x630b38: SaveReg r1
    //     0x630b38: str             x1, [SP, #-8]!
    // 0x630b3c: r0 = GDT[cid_x0 + 0xf0dd]()
    //     0x630b3c: mov             x17, #0xf0dd
    //     0x630b40: add             lr, x0, x17
    //     0x630b44: ldr             lr, [x21, lr, lsl #3]
    //     0x630b48: blr             lr
    // 0x630b4c: add             SP, SP, #8
    // 0x630b50: ldr             x16, [fp, #0x18]
    // 0x630b54: r30 = Instance__IntrinsicDimension
    //     0x630b54: add             lr, PP, #0x49, lsl #12  ; [pp+0x49ac8] Obj!_IntrinsicDimension@b64c31
    //     0x630b58: ldr             lr, [lr, #0xac8]
    // 0x630b5c: stp             lr, x16, [SP, #-0x10]!
    // 0x630b60: ldr             d0, [fp, #0x10]
    // 0x630b64: SaveReg d0
    //     0x630b64: str             d0, [SP, #-8]!
    // 0x630b68: SaveReg r0
    //     0x630b68: str             x0, [SP, #-8]!
    // 0x630b6c: r0 = _computeIntrinsicDimension()
    //     0x630b6c: bl              #0x62cc04  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsicDimension
    // 0x630b70: add             SP, SP, #0x20
    // 0x630b74: LeaveFrame
    //     0x630b74: mov             SP, fp
    //     0x630b78: ldp             fp, lr, [SP], #0x10
    // 0x630b7c: ret
    //     0x630b7c: ret             
    // 0x630b80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x630b80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x630b84: b               #0x630b2c
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x634120, size: 0x18
    // 0x634120: r4 = 0
    //     0x634120: mov             x4, #0
    // 0x634124: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x634124: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4c148] AnonymousClosure: (0xc24c8c), of [package:flutter/src/rendering/box.dart] RenderBox
    //     0x634128: ldr             x1, [x17, #0x148]
    // 0x63412c: r24 = BuildNonGenericMethodExtractorStub
    //     0x63412c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x634130: LoadField: r0 = r24->field_17
    //     0x634130: ldur            x0, [x24, #0x17]
    // 0x634134: br              x0
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x637768, size: 0x18
    // 0x637768: r4 = 0
    //     0x637768: mov             x4, #0
    // 0x63776c: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x63776c: add             x17, PP, #0x40, lsl #12  ; [pp+0x40dd0] AnonymousClosure: (0xc24c8c), of [package:flutter/src/rendering/box.dart] RenderBox
    //     0x637770: ldr             x1, [x17, #0xdd0]
    // 0x637774: r24 = BuildNonGenericMethodExtractorStub
    //     0x637774: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x637778: LoadField: r0 = r24->field_17
    //     0x637778: ldur            x0, [x24, #0x17]
    // 0x63777c: br              x0
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x63a29c, size: 0x18
    // 0x63a29c: r4 = 0
    //     0x63a29c: mov             x4, #0
    // 0x63a2a0: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x63a2a0: add             x17, PP, #0x53, lsl #12  ; [pp+0x53718] AnonymousClosure: (0xc24c8c), of [package:flutter/src/rendering/box.dart] RenderBox
    //     0x63a2a4: ldr             x1, [x17, #0x718]
    // 0x63a2a8: r24 = BuildNonGenericMethodExtractorStub
    //     0x63a2a8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63a2ac: LoadField: r0 = r24->field_17
    //     0x63a2ac: ldur            x0, [x24, #0x17]
    // 0x63a2b0: br              x0
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63d2cc, size: 0x18
    // 0x63d2cc: r4 = 0
    //     0x63d2cc: mov             x4, #0
    // 0x63d2d0: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63d2d0: add             x17, PP, #0x51, lsl #12  ; [pp+0x51240] AnonymousClosure: (0xc24c8c), of [package:flutter/src/rendering/box.dart] RenderBox
    //     0x63d2d4: ldr             x1, [x17, #0x240]
    // 0x63d2d8: r24 = BuildNonGenericMethodExtractorStub
    //     0x63d2d8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63d2dc: LoadField: r0 = r24->field_17
    //     0x63d2dc: ldur            x0, [x24, #0x17]
    // 0x63d2e0: br              x0
  }
  _ getDistanceToActualBaseline(/* No info */) {
    // ** addr: 0x63d634, size: 0x140
    // 0x63d634: EnterFrame
    //     0x63d634: stp             fp, lr, [SP, #-0x10]!
    //     0x63d638: mov             fp, SP
    // 0x63d63c: AllocStack(0x18)
    //     0x63d63c: sub             SP, SP, #0x18
    // 0x63d640: CheckStackOverflow
    //     0x63d640: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63d644: cmp             SP, x16
    //     0x63d648: b.ls            #0x63d764
    // 0x63d64c: r1 = 2
    //     0x63d64c: mov             x1, #2
    // 0x63d650: r0 = AllocateContext()
    //     0x63d650: bl              #0xd68aa4  ; AllocateContextStub
    // 0x63d654: mov             x1, x0
    // 0x63d658: ldr             x0, [fp, #0x18]
    // 0x63d65c: stur            x1, [fp, #-8]
    // 0x63d660: StoreField: r1->field_f = r0
    //     0x63d660: stur            w0, [x1, #0xf]
    // 0x63d664: ldr             x2, [fp, #0x10]
    // 0x63d668: StoreField: r1->field_13 = r2
    //     0x63d668: stur            w2, [x1, #0x13]
    // 0x63d66c: LoadField: r2 = r0->field_5b
    //     0x63d66c: ldur            w2, [x0, #0x5b]
    // 0x63d670: DecompressPointer r2
    //     0x63d670: add             x2, x2, HEAP, lsl #32
    // 0x63d674: cmp             w2, NULL
    // 0x63d678: b.ne            #0x63d6c4
    // 0x63d67c: r16 = <TextBaseline, double?>
    //     0x63d67c: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d2b0] TypeArguments: <TextBaseline, double?>
    //     0x63d680: ldr             x16, [x16, #0x2b0]
    // 0x63d684: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x63d688: stp             lr, x16, [SP, #-0x10]!
    // 0x63d68c: r0 = Map._fromLiteral()
    //     0x63d68c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x63d690: add             SP, SP, #0x10
    // 0x63d694: mov             x1, x0
    // 0x63d698: ldr             x3, [fp, #0x18]
    // 0x63d69c: StoreField: r3->field_5b = r0
    //     0x63d69c: stur            w0, [x3, #0x5b]
    //     0x63d6a0: tbz             w0, #0, #0x63d6bc
    //     0x63d6a4: ldurb           w16, [x3, #-1]
    //     0x63d6a8: ldurb           w17, [x0, #-1]
    //     0x63d6ac: and             x16, x17, x16, lsr #2
    //     0x63d6b0: tst             x16, HEAP, lsr #32
    //     0x63d6b4: b.eq            #0x63d6bc
    //     0x63d6b8: bl              #0xd682ac
    // 0x63d6bc: mov             x4, x1
    // 0x63d6c0: b               #0x63d6cc
    // 0x63d6c4: mov             x3, x0
    // 0x63d6c8: mov             x4, x2
    // 0x63d6cc: ldur            x0, [fp, #-8]
    // 0x63d6d0: stur            x4, [fp, #-0x18]
    // 0x63d6d4: cmp             w4, NULL
    // 0x63d6d8: b.eq            #0x63d76c
    // 0x63d6dc: LoadField: r5 = r0->field_13
    //     0x63d6dc: ldur            w5, [x0, #0x13]
    // 0x63d6e0: DecompressPointer r5
    //     0x63d6e0: add             x5, x5, HEAP, lsl #32
    // 0x63d6e4: mov             x2, x0
    // 0x63d6e8: stur            x5, [fp, #-0x10]
    // 0x63d6ec: r1 = Function '<anonymous closure>':.
    //     0x63d6ec: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d2b8] AnonymousClosure: (0x63d774), in [package:flutter/src/rendering/box.dart] RenderBox::getDistanceToActualBaseline (0x63d634)
    //     0x63d6f0: ldr             x1, [x1, #0x2b8]
    // 0x63d6f4: r0 = AllocateClosure()
    //     0x63d6f4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x63d6f8: ldur            x16, [fp, #-0x18]
    // 0x63d6fc: ldur            lr, [fp, #-0x10]
    // 0x63d700: stp             lr, x16, [SP, #-0x10]!
    // 0x63d704: SaveReg r0
    //     0x63d704: str             x0, [SP, #-8]!
    // 0x63d708: r0 = putIfAbsent()
    //     0x63d708: bl              #0xc7a83c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0x63d70c: add             SP, SP, #0x18
    // 0x63d710: ldr             x0, [fp, #0x18]
    // 0x63d714: LoadField: r1 = r0->field_5b
    //     0x63d714: ldur            w1, [x0, #0x5b]
    // 0x63d718: DecompressPointer r1
    //     0x63d718: add             x1, x1, HEAP, lsl #32
    // 0x63d71c: stur            x1, [fp, #-0x10]
    // 0x63d720: cmp             w1, NULL
    // 0x63d724: b.eq            #0x63d770
    // 0x63d728: ldur            x0, [fp, #-8]
    // 0x63d72c: LoadField: r2 = r0->field_13
    //     0x63d72c: ldur            w2, [x0, #0x13]
    // 0x63d730: DecompressPointer r2
    //     0x63d730: add             x2, x2, HEAP, lsl #32
    // 0x63d734: stp             x2, x1, [SP, #-0x10]!
    // 0x63d738: r0 = _getValueOrData()
    //     0x63d738: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x63d73c: add             SP, SP, #0x10
    // 0x63d740: ldur            x1, [fp, #-0x10]
    // 0x63d744: LoadField: r2 = r1->field_f
    //     0x63d744: ldur            w2, [x1, #0xf]
    // 0x63d748: DecompressPointer r2
    //     0x63d748: add             x2, x2, HEAP, lsl #32
    // 0x63d74c: cmp             w2, w0
    // 0x63d750: b.ne            #0x63d758
    // 0x63d754: r0 = Null
    //     0x63d754: mov             x0, NULL
    // 0x63d758: LeaveFrame
    //     0x63d758: mov             SP, fp
    //     0x63d75c: ldp             fp, lr, [SP], #0x10
    // 0x63d760: ret
    //     0x63d760: ret             
    // 0x63d764: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63d764: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63d768: b               #0x63d64c
    // 0x63d76c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63d76c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x63d770: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63d770: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] double? <anonymous closure>(dynamic) {
    // ** addr: 0x63d774, size: 0x68
    // 0x63d774: EnterFrame
    //     0x63d774: stp             fp, lr, [SP, #-0x10]!
    //     0x63d778: mov             fp, SP
    // 0x63d77c: ldr             x0, [fp, #0x10]
    // 0x63d780: LoadField: r1 = r0->field_17
    //     0x63d780: ldur            w1, [x0, #0x17]
    // 0x63d784: DecompressPointer r1
    //     0x63d784: add             x1, x1, HEAP, lsl #32
    // 0x63d788: CheckStackOverflow
    //     0x63d788: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63d78c: cmp             SP, x16
    //     0x63d790: b.ls            #0x63d7d4
    // 0x63d794: LoadField: r0 = r1->field_f
    //     0x63d794: ldur            w0, [x1, #0xf]
    // 0x63d798: DecompressPointer r0
    //     0x63d798: add             x0, x0, HEAP, lsl #32
    // 0x63d79c: LoadField: r2 = r1->field_13
    //     0x63d79c: ldur            w2, [x1, #0x13]
    // 0x63d7a0: DecompressPointer r2
    //     0x63d7a0: add             x2, x2, HEAP, lsl #32
    // 0x63d7a4: r1 = LoadClassIdInstr(r0)
    //     0x63d7a4: ldur            x1, [x0, #-1]
    //     0x63d7a8: ubfx            x1, x1, #0xc, #0x14
    // 0x63d7ac: stp             x2, x0, [SP, #-0x10]!
    // 0x63d7b0: mov             x0, x1
    // 0x63d7b4: r0 = GDT[cid_x0 + 0xf037]()
    //     0x63d7b4: mov             x17, #0xf037
    //     0x63d7b8: add             lr, x0, x17
    //     0x63d7bc: ldr             lr, [x21, lr, lsl #3]
    //     0x63d7c0: blr             lr
    // 0x63d7c4: add             SP, SP, #0x10
    // 0x63d7c8: LeaveFrame
    //     0x63d7c8: mov             SP, fp
    //     0x63d7cc: ldp             fp, lr, [SP], #0x10
    // 0x63d7d0: ret
    //     0x63d7d0: ret             
    // 0x63d7d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63d7d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63d7d8: b               #0x63d794
  }
  _ hitTest(/* No info */) {
    // ** addr: 0x640b9c, size: 0xfc
    // 0x640b9c: EnterFrame
    //     0x640b9c: stp             fp, lr, [SP, #-0x10]!
    //     0x640ba0: mov             fp, SP
    // 0x640ba4: CheckStackOverflow
    //     0x640ba4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x640ba8: cmp             SP, x16
    //     0x640bac: b.ls            #0x640c8c
    // 0x640bb0: ldr             x0, [fp, #0x20]
    // 0x640bb4: LoadField: r1 = r0->field_57
    //     0x640bb4: ldur            w1, [x0, #0x57]
    // 0x640bb8: DecompressPointer r1
    //     0x640bb8: add             x1, x1, HEAP, lsl #32
    // 0x640bbc: cmp             w1, NULL
    // 0x640bc0: b.eq            #0x640c94
    // 0x640bc4: ldr             x16, [fp, #0x10]
    // 0x640bc8: stp             x16, x1, [SP, #-0x10]!
    // 0x640bcc: r0 = contains()
    //     0x640bcc: bl              #0x63f33c  ; [dart:ui] Size::contains
    // 0x640bd0: add             SP, SP, #0x10
    // 0x640bd4: tbnz            w0, #4, #0x640c7c
    // 0x640bd8: ldr             x1, [fp, #0x20]
    // 0x640bdc: r0 = LoadClassIdInstr(r1)
    //     0x640bdc: ldur            x0, [x1, #-1]
    //     0x640be0: ubfx            x0, x0, #0xc, #0x14
    // 0x640be4: ldr             x16, [fp, #0x18]
    // 0x640be8: stp             x16, x1, [SP, #-0x10]!
    // 0x640bec: ldr             x16, [fp, #0x10]
    // 0x640bf0: SaveReg r16
    //     0x640bf0: str             x16, [SP, #-8]!
    // 0x640bf4: r0 = GDT[cid_x0 + 0xf3c3]()
    //     0x640bf4: mov             x17, #0xf3c3
    //     0x640bf8: add             lr, x0, x17
    //     0x640bfc: ldr             lr, [x21, lr, lsl #3]
    //     0x640c00: blr             lr
    // 0x640c04: add             SP, SP, #0x18
    // 0x640c08: tbz             w0, #4, #0x640c38
    // 0x640c0c: ldr             x1, [fp, #0x20]
    // 0x640c10: r0 = LoadClassIdInstr(r1)
    //     0x640c10: ldur            x0, [x1, #-1]
    //     0x640c14: ubfx            x0, x0, #0xc, #0x14
    // 0x640c18: ldr             x16, [fp, #0x10]
    // 0x640c1c: stp             x16, x1, [SP, #-0x10]!
    // 0x640c20: r0 = GDT[cid_x0 + 0xf31d]()
    //     0x640c20: mov             x17, #0xf31d
    //     0x640c24: add             lr, x0, x17
    //     0x640c28: ldr             lr, [x21, lr, lsl #3]
    //     0x640c2c: blr             lr
    // 0x640c30: add             SP, SP, #0x10
    // 0x640c34: tbnz            w0, #4, #0x640c7c
    // 0x640c38: ldr             x0, [fp, #0x20]
    // 0x640c3c: ldr             x2, [fp, #0x10]
    // 0x640c40: r1 = <RenderBox>
    //     0x640c40: ldr             x1, [PP, #0x3b20]  ; [pp+0x3b20] TypeArguments: <RenderBox>
    // 0x640c44: r0 = BoxHitTestEntry()
    //     0x640c44: bl              #0x63f330  ; AllocateBoxHitTestEntryStub -> BoxHitTestEntry (size=0x18)
    // 0x640c48: mov             x1, x0
    // 0x640c4c: ldr             x0, [fp, #0x10]
    // 0x640c50: StoreField: r1->field_13 = r0
    //     0x640c50: stur            w0, [x1, #0x13]
    // 0x640c54: ldr             x0, [fp, #0x20]
    // 0x640c58: StoreField: r1->field_b = r0
    //     0x640c58: stur            w0, [x1, #0xb]
    // 0x640c5c: ldr             x16, [fp, #0x18]
    // 0x640c60: stp             x1, x16, [SP, #-0x10]!
    // 0x640c64: r0 = add()
    //     0x640c64: bl              #0x50ea24  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::add
    // 0x640c68: add             SP, SP, #0x10
    // 0x640c6c: r0 = true
    //     0x640c6c: add             x0, NULL, #0x20  ; true
    // 0x640c70: LeaveFrame
    //     0x640c70: mov             SP, fp
    //     0x640c74: ldp             fp, lr, [SP], #0x10
    // 0x640c78: ret
    //     0x640c78: ret             
    // 0x640c7c: r0 = false
    //     0x640c7c: add             x0, NULL, #0x30  ; false
    // 0x640c80: LeaveFrame
    //     0x640c80: mov             SP, fp
    //     0x640c84: ldp             fp, lr, [SP], #0x10
    // 0x640c88: ret
    //     0x640c88: ret             
    // 0x640c8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x640c8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x640c90: b               #0x640bb0
    // 0x640c94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x640c94: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ performResize(/* No info */) {
    // ** addr: 0x641464, size: 0xe4
    // 0x641464: EnterFrame
    //     0x641464: stp             fp, lr, [SP, #-0x10]!
    //     0x641468: mov             fp, SP
    // 0x64146c: AllocStack(0x8)
    //     0x64146c: sub             SP, SP, #8
    // 0x641470: CheckStackOverflow
    //     0x641470: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x641474: cmp             SP, x16
    //     0x641478: b.ls            #0x641540
    // 0x64147c: ldr             x3, [fp, #0x10]
    // 0x641480: LoadField: r4 = r3->field_27
    //     0x641480: ldur            w4, [x3, #0x27]
    // 0x641484: DecompressPointer r4
    //     0x641484: add             x4, x4, HEAP, lsl #32
    // 0x641488: stur            x4, [fp, #-8]
    // 0x64148c: cmp             w4, NULL
    // 0x641490: b.eq            #0x641520
    // 0x641494: mov             x0, x4
    // 0x641498: r2 = Null
    //     0x641498: mov             x2, NULL
    // 0x64149c: r1 = Null
    //     0x64149c: mov             x1, NULL
    // 0x6414a0: r4 = LoadClassIdInstr(r0)
    //     0x6414a0: ldur            x4, [x0, #-1]
    //     0x6414a4: ubfx            x4, x4, #0xc, #0x14
    // 0x6414a8: sub             x4, x4, #0x80d
    // 0x6414ac: cmp             x4, #1
    // 0x6414b0: b.ls            #0x6414c8
    // 0x6414b4: r8 = BoxConstraints
    //     0x6414b4: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x6414b8: ldr             x8, [x8, #0x1d0]
    // 0x6414bc: r3 = Null
    //     0x6414bc: add             x3, PP, #0xc, lsl #12  ; [pp+0xc7b0] Null
    //     0x6414c0: ldr             x3, [x3, #0x7b0]
    // 0x6414c4: r0 = BoxConstraints()
    //     0x6414c4: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x6414c8: ldr             x1, [fp, #0x10]
    // 0x6414cc: r0 = LoadClassIdInstr(r1)
    //     0x6414cc: ldur            x0, [x1, #-1]
    //     0x6414d0: ubfx            x0, x0, #0xc, #0x14
    // 0x6414d4: ldur            x16, [fp, #-8]
    // 0x6414d8: stp             x16, x1, [SP, #-0x10]!
    // 0x6414dc: r0 = GDT[cid_x0 + 0xa6df]()
    //     0x6414dc: mov             x17, #0xa6df
    //     0x6414e0: add             lr, x0, x17
    //     0x6414e4: ldr             lr, [x21, lr, lsl #3]
    //     0x6414e8: blr             lr
    // 0x6414ec: add             SP, SP, #0x10
    // 0x6414f0: ldr             x1, [fp, #0x10]
    // 0x6414f4: StoreField: r1->field_57 = r0
    //     0x6414f4: stur            w0, [x1, #0x57]
    //     0x6414f8: ldurb           w16, [x1, #-1]
    //     0x6414fc: ldurb           w17, [x0, #-1]
    //     0x641500: and             x16, x17, x16, lsr #2
    //     0x641504: tst             x16, HEAP, lsr #32
    //     0x641508: b.eq            #0x641510
    //     0x64150c: bl              #0xd6826c
    // 0x641510: r0 = Null
    //     0x641510: mov             x0, NULL
    // 0x641514: LeaveFrame
    //     0x641514: mov             SP, fp
    //     0x641518: ldp             fp, lr, [SP], #0x10
    // 0x64151c: ret
    //     0x64151c: ret             
    // 0x641520: r0 = StateError()
    //     0x641520: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x641524: mov             x1, x0
    // 0x641528: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x641528: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x64152c: ldr             x0, [x0, #0x1e8]
    // 0x641530: StoreField: r1->field_b = r0
    //     0x641530: stur            w0, [x1, #0xb]
    // 0x641534: mov             x0, x1
    // 0x641538: r0 = Throw()
    //     0x641538: bl              #0xd67e38  ; ThrowStub
    // 0x64153c: brk             #0
    // 0x641540: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x641540: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x641544: b               #0x64147c
  }
  get _ constraints(/* No info */) {
    // ** addr: 0x641a58, size: 0x78
    // 0x641a58: EnterFrame
    //     0x641a58: stp             fp, lr, [SP, #-0x10]!
    //     0x641a5c: mov             fp, SP
    // 0x641a60: AllocStack(0x8)
    //     0x641a60: sub             SP, SP, #8
    // 0x641a64: CheckStackOverflow
    //     0x641a64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x641a68: cmp             SP, x16
    //     0x641a6c: b.ls            #0x641ac8
    // 0x641a70: ldr             x16, [fp, #0x10]
    // 0x641a74: SaveReg r16
    //     0x641a74: str             x16, [SP, #-8]!
    // 0x641a78: r0 = constraints()
    //     0x641a78: bl              #0x641ad0  ; [package:flutter/src/rendering/object.dart] RenderObject::constraints
    // 0x641a7c: add             SP, SP, #8
    // 0x641a80: mov             x3, x0
    // 0x641a84: r2 = Null
    //     0x641a84: mov             x2, NULL
    // 0x641a88: r1 = Null
    //     0x641a88: mov             x1, NULL
    // 0x641a8c: stur            x3, [fp, #-8]
    // 0x641a90: r4 = LoadClassIdInstr(r0)
    //     0x641a90: ldur            x4, [x0, #-1]
    //     0x641a94: ubfx            x4, x4, #0xc, #0x14
    // 0x641a98: sub             x4, x4, #0x80d
    // 0x641a9c: cmp             x4, #1
    // 0x641aa0: b.ls            #0x641ab8
    // 0x641aa4: r8 = BoxConstraints
    //     0x641aa4: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x641aa8: ldr             x8, [x8, #0x1d0]
    // 0x641aac: r3 = Null
    //     0x641aac: add             x3, PP, #0xb, lsl #12  ; [pp+0xb1d8] Null
    //     0x641ab0: ldr             x3, [x3, #0x1d8]
    // 0x641ab4: r0 = BoxConstraints()
    //     0x641ab4: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x641ab8: ldur            x0, [fp, #-8]
    // 0x641abc: LeaveFrame
    //     0x641abc: mov             SP, fp
    //     0x641ac0: ldp             fp, lr, [SP], #0x10
    // 0x641ac4: ret
    //     0x641ac4: ret             
    // 0x641ac8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x641ac8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x641acc: b               #0x641a70
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0x64bd54, size: 0x70
    // 0x64bd54: EnterFrame
    //     0x64bd54: stp             fp, lr, [SP, #-0x10]!
    //     0x64bd58: mov             fp, SP
    // 0x64bd5c: ldr             x0, [fp, #0x10]
    // 0x64bd60: LoadField: r1 = r0->field_17
    //     0x64bd60: ldur            w1, [x0, #0x17]
    // 0x64bd64: DecompressPointer r1
    //     0x64bd64: add             x1, x1, HEAP, lsl #32
    // 0x64bd68: r2 = LoadClassIdInstr(r1)
    //     0x64bd68: ldur            x2, [x1, #-1]
    //     0x64bd6c: ubfx            x2, x2, #0xc, #0x14
    // 0x64bd70: lsl             x2, x2, #1
    // 0x64bd74: r1 = LoadInt32Instr(r2)
    //     0x64bd74: sbfx            x1, x2, #1, #0x1f
    // 0x64bd78: cmp             x1, #0x7ff
    // 0x64bd7c: b.lt            #0x64bd88
    // 0x64bd80: cmp             x1, #0x80a
    // 0x64bd84: b.le            #0x64bdb4
    // 0x64bd88: r0 = BoxParentData()
    //     0x64bd88: bl              #0x64bdc4  ; AllocateBoxParentDataStub -> BoxParentData (size=0xc)
    // 0x64bd8c: r1 = Instance_Offset
    //     0x64bd8c: ldr             x1, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x64bd90: StoreField: r0->field_7 = r1
    //     0x64bd90: stur            w1, [x0, #7]
    // 0x64bd94: ldr             x1, [fp, #0x10]
    // 0x64bd98: StoreField: r1->field_17 = r0
    //     0x64bd98: stur            w0, [x1, #0x17]
    //     0x64bd9c: ldurb           w16, [x1, #-1]
    //     0x64bda0: ldurb           w17, [x0, #-1]
    //     0x64bda4: and             x16, x17, x16, lsr #2
    //     0x64bda8: tst             x16, HEAP, lsr #32
    //     0x64bdac: b.eq            #0x64bdb4
    //     0x64bdb0: bl              #0xd6826c
    // 0x64bdb4: r0 = Null
    //     0x64bdb4: mov             x0, NULL
    // 0x64bdb8: LeaveFrame
    //     0x64bdb8: mov             SP, fp
    //     0x64bdbc: ldp             fp, lr, [SP], #0x10
    // 0x64bdc0: ret
    //     0x64bdc0: ret             
  }
  _ localToGlobal(/* No info */) {
    // ** addr: 0x64e820, size: 0xa4
    // 0x64e820: EnterFrame
    //     0x64e820: stp             fp, lr, [SP, #-0x10]!
    //     0x64e824: mov             fp, SP
    // 0x64e828: AllocStack(0x8)
    //     0x64e828: sub             SP, SP, #8
    // 0x64e82c: SetupParameters(RenderBox this /* r3 */, dynamic _ /* r4, fp-0x8 */, {dynamic ancestor = Null /* r0 */})
    //     0x64e82c: mov             x0, x4
    //     0x64e830: ldur            w1, [x0, #0x13]
    //     0x64e834: add             x1, x1, HEAP, lsl #32
    //     0x64e838: sub             x2, x1, #4
    //     0x64e83c: add             x3, fp, w2, sxtw #2
    //     0x64e840: ldr             x3, [x3, #0x18]
    //     0x64e844: add             x4, fp, w2, sxtw #2
    //     0x64e848: ldr             x4, [x4, #0x10]
    //     0x64e84c: stur            x4, [fp, #-8]
    //     0x64e850: ldur            w2, [x0, #0x1f]
    //     0x64e854: add             x2, x2, HEAP, lsl #32
    //     0x64e858: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1ca28] "ancestor"
    //     0x64e85c: ldr             x16, [x16, #0xa28]
    //     0x64e860: cmp             w2, w16
    //     0x64e864: b.ne            #0x64e884
    //     0x64e868: ldur            w2, [x0, #0x23]
    //     0x64e86c: add             x2, x2, HEAP, lsl #32
    //     0x64e870: sub             w0, w1, w2
    //     0x64e874: add             x1, fp, w0, sxtw #2
    //     0x64e878: ldr             x1, [x1, #8]
    //     0x64e87c: mov             x0, x1
    //     0x64e880: b               #0x64e888
    //     0x64e884: mov             x0, NULL
    // 0x64e888: CheckStackOverflow
    //     0x64e888: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64e88c: cmp             SP, x16
    //     0x64e890: b.ls            #0x64e8bc
    // 0x64e894: stp             x0, x3, [SP, #-0x10]!
    // 0x64e898: r0 = getTransformTo()
    //     0x64e898: bl              #0x643bcc  ; [package:flutter/src/rendering/object.dart] RenderObject::getTransformTo
    // 0x64e89c: add             SP, SP, #0x10
    // 0x64e8a0: ldur            x16, [fp, #-8]
    // 0x64e8a4: stp             x16, x0, [SP, #-0x10]!
    // 0x64e8a8: r0 = transformPoint()
    //     0x64e8a8: bl              #0x62313c  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::transformPoint
    // 0x64e8ac: add             SP, SP, #0x10
    // 0x64e8b0: LeaveFrame
    //     0x64e8b0: mov             SP, fp
    //     0x64e8b4: ldp             fp, lr, [SP], #0x10
    // 0x64e8b8: ret
    //     0x64e8b8: ret             
    // 0x64e8bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64e8bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64e8c0: b               #0x64e894
  }
  _ globalToLocal(/* No info */) {
    // ** addr: 0x669450, size: 0x35c
    // 0x669450: EnterFrame
    //     0x669450: stp             fp, lr, [SP, #-0x10]!
    //     0x669454: mov             fp, SP
    // 0x669458: AllocStack(0x28)
    //     0x669458: sub             SP, SP, #0x28
    // 0x66945c: CheckStackOverflow
    //     0x66945c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x669460: cmp             SP, x16
    //     0x669464: b.ls            #0x669774
    // 0x669468: ldr             x16, [fp, #0x18]
    // 0x66946c: stp             NULL, x16, [SP, #-0x10]!
    // 0x669470: r0 = getTransformTo()
    //     0x669470: bl              #0x643bcc  ; [package:flutter/src/rendering/object.dart] RenderObject::getTransformTo
    // 0x669474: add             SP, SP, #0x10
    // 0x669478: stur            x0, [fp, #-8]
    // 0x66947c: SaveReg r0
    //     0x66947c: str             x0, [SP, #-8]!
    // 0x669480: r0 = invert()
    //     0x669480: bl              #0x65d460  ; [package:vector_math/vector_math_64.dart] Matrix4::invert
    // 0x669484: add             SP, SP, #8
    // 0x669488: mov             v1.16b, v0.16b
    // 0x66948c: d0 = 0.000000
    //     0x66948c: eor             v0.16b, v0.16b, v0.16b
    // 0x669490: fcmp            d1, d0
    // 0x669494: b.vs            #0x6694ac
    // 0x669498: b.ne            #0x6694ac
    // 0x66949c: r0 = Instance_Offset
    //     0x66949c: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x6694a0: LeaveFrame
    //     0x6694a0: mov             SP, fp
    //     0x6694a4: ldp             fp, lr, [SP], #0x10
    // 0x6694a8: ret
    //     0x6694a8: ret             
    // 0x6694ac: ldr             x0, [fp, #0x10]
    // 0x6694b0: r0 = Vector3()
    //     0x6694b0: bl              #0x5b717c  ; AllocateVector3Stub -> Vector3 (size=0xc)
    // 0x6694b4: r4 = 6
    //     0x6694b4: mov             x4, #6
    // 0x6694b8: stur            x0, [fp, #-0x10]
    // 0x6694bc: r0 = AllocateFloat64Array()
    //     0x6694bc: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0x6694c0: mov             x1, x0
    // 0x6694c4: ldur            x0, [fp, #-0x10]
    // 0x6694c8: StoreField: r0->field_7 = r1
    //     0x6694c8: stur            w1, [x0, #7]
    // 0x6694cc: StoreField: r1->field_17 = rZR
    //     0x6694cc: stur            xzr, [x1, #0x17]
    // 0x6694d0: StoreField: r1->field_1f = rZR
    //     0x6694d0: stur            xzr, [x1, #0x1f]
    // 0x6694d4: StoreField: r1->field_27 = rZR
    //     0x6694d4: stur            xzr, [x1, #0x27]
    // 0x6694d8: ldur            x16, [fp, #-8]
    // 0x6694dc: stp             x0, x16, [SP, #-0x10]!
    // 0x6694e0: r0 = perspectiveTransform()
    //     0x6694e0: bl              #0x5b6f78  ; [package:vector_math/vector_math_64.dart] Matrix4::perspectiveTransform
    // 0x6694e4: add             SP, SP, #0x10
    // 0x6694e8: stur            x0, [fp, #-0x10]
    // 0x6694ec: r0 = Vector3()
    //     0x6694ec: bl              #0x5b717c  ; AllocateVector3Stub -> Vector3 (size=0xc)
    // 0x6694f0: r4 = 6
    //     0x6694f0: mov             x4, #6
    // 0x6694f4: stur            x0, [fp, #-0x18]
    // 0x6694f8: r0 = AllocateFloat64Array()
    //     0x6694f8: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0x6694fc: mov             x1, x0
    // 0x669500: ldur            x0, [fp, #-0x18]
    // 0x669504: StoreField: r0->field_7 = r1
    //     0x669504: stur            w1, [x0, #7]
    // 0x669508: StoreField: r1->field_17 = rZR
    //     0x669508: stur            xzr, [x1, #0x17]
    // 0x66950c: StoreField: r1->field_1f = rZR
    //     0x66950c: stur            xzr, [x1, #0x1f]
    // 0x669510: d0 = 1.000000
    //     0x669510: fmov            d0, #1.00000000
    // 0x669514: StoreField: r1->field_27 = d0
    //     0x669514: stur            d0, [x1, #0x27]
    // 0x669518: ldur            x16, [fp, #-8]
    // 0x66951c: stp             x0, x16, [SP, #-0x10]!
    // 0x669520: r0 = perspectiveTransform()
    //     0x669520: bl              #0x5b6f78  ; [package:vector_math/vector_math_64.dart] Matrix4::perspectiveTransform
    // 0x669524: add             SP, SP, #0x10
    // 0x669528: ldur            x16, [fp, #-0x10]
    // 0x66952c: stp             x16, x0, [SP, #-0x10]!
    // 0x669530: r0 = -()
    //     0x669530: bl              #0x5b6e10  ; [package:vector_math/vector_math_64.dart] Vector3::-
    // 0x669534: add             SP, SP, #0x10
    // 0x669538: mov             x1, x0
    // 0x66953c: ldr             x0, [fp, #0x10]
    // 0x669540: stur            x1, [fp, #-0x10]
    // 0x669544: LoadField: d0 = r0->field_7
    //     0x669544: ldur            d0, [x0, #7]
    // 0x669548: stur            d0, [fp, #-0x28]
    // 0x66954c: LoadField: d1 = r0->field_f
    //     0x66954c: ldur            d1, [x0, #0xf]
    // 0x669550: stur            d1, [fp, #-0x20]
    // 0x669554: r0 = Vector3()
    //     0x669554: bl              #0x5b717c  ; AllocateVector3Stub -> Vector3 (size=0xc)
    // 0x669558: r4 = 6
    //     0x669558: mov             x4, #6
    // 0x66955c: stur            x0, [fp, #-0x18]
    // 0x669560: r0 = AllocateFloat64Array()
    //     0x669560: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0x669564: mov             x1, x0
    // 0x669568: ldur            x0, [fp, #-0x18]
    // 0x66956c: StoreField: r0->field_7 = r1
    //     0x66956c: stur            w1, [x0, #7]
    // 0x669570: ldur            d0, [fp, #-0x28]
    // 0x669574: StoreField: r1->field_17 = d0
    //     0x669574: stur            d0, [x1, #0x17]
    // 0x669578: ldur            d0, [fp, #-0x20]
    // 0x66957c: StoreField: r1->field_1f = d0
    //     0x66957c: stur            d0, [x1, #0x1f]
    // 0x669580: StoreField: r1->field_27 = rZR
    //     0x669580: stur            xzr, [x1, #0x27]
    // 0x669584: ldur            x16, [fp, #-8]
    // 0x669588: stp             x0, x16, [SP, #-0x10]!
    // 0x66958c: r0 = perspectiveTransform()
    //     0x66958c: bl              #0x5b6f78  ; [package:vector_math/vector_math_64.dart] Matrix4::perspectiveTransform
    // 0x669590: add             SP, SP, #0x10
    // 0x669594: mov             x2, x0
    // 0x669598: stur            x2, [fp, #-8]
    // 0x66959c: LoadField: r3 = r2->field_7
    //     0x66959c: ldur            w3, [x2, #7]
    // 0x6695a0: DecompressPointer r3
    //     0x6695a0: add             x3, x3, HEAP, lsl #32
    // 0x6695a4: LoadField: r0 = r3->field_13
    //     0x6695a4: ldur            w0, [x3, #0x13]
    // 0x6695a8: DecompressPointer r0
    //     0x6695a8: add             x0, x0, HEAP, lsl #32
    // 0x6695ac: r4 = LoadInt32Instr(r0)
    //     0x6695ac: sbfx            x4, x0, #1, #0x1f
    // 0x6695b0: mov             x0, x4
    // 0x6695b4: r1 = 0
    //     0x6695b4: mov             x1, #0
    // 0x6695b8: cmp             x1, x0
    // 0x6695bc: b.hs            #0x66977c
    // 0x6695c0: LoadField: d0 = r3->field_17
    //     0x6695c0: ldur            d0, [x3, #0x17]
    // 0x6695c4: d1 = 0.000000
    //     0x6695c4: eor             v1.16b, v1.16b, v1.16b
    // 0x6695c8: fmul            d2, d1, d0
    // 0x6695cc: mov             x0, x4
    // 0x6695d0: r1 = 1
    //     0x6695d0: mov             x1, #1
    // 0x6695d4: cmp             x1, x0
    // 0x6695d8: b.hs            #0x669780
    // 0x6695dc: LoadField: d0 = r3->field_1f
    //     0x6695dc: ldur            d0, [x3, #0x1f]
    // 0x6695e0: fmul            d3, d1, d0
    // 0x6695e4: fadd            d0, d2, d3
    // 0x6695e8: mov             x0, x4
    // 0x6695ec: r1 = 2
    //     0x6695ec: mov             x1, #2
    // 0x6695f0: cmp             x1, x0
    // 0x6695f4: b.hs            #0x669784
    // 0x6695f8: LoadField: d2 = r3->field_27
    //     0x6695f8: ldur            d2, [x3, #0x27]
    // 0x6695fc: fadd            d3, d0, d2
    // 0x669600: ldur            x3, [fp, #-0x10]
    // 0x669604: LoadField: r4 = r3->field_7
    //     0x669604: ldur            w4, [x3, #7]
    // 0x669608: DecompressPointer r4
    //     0x669608: add             x4, x4, HEAP, lsl #32
    // 0x66960c: LoadField: r0 = r4->field_13
    //     0x66960c: ldur            w0, [x4, #0x13]
    // 0x669610: DecompressPointer r0
    //     0x669610: add             x0, x0, HEAP, lsl #32
    // 0x669614: r5 = LoadInt32Instr(r0)
    //     0x669614: sbfx            x5, x0, #1, #0x1f
    // 0x669618: mov             x0, x5
    // 0x66961c: r1 = 0
    //     0x66961c: mov             x1, #0
    // 0x669620: cmp             x1, x0
    // 0x669624: b.hs            #0x669788
    // 0x669628: LoadField: d0 = r4->field_17
    //     0x669628: ldur            d0, [x4, #0x17]
    // 0x66962c: fmul            d2, d1, d0
    // 0x669630: mov             x0, x5
    // 0x669634: r1 = 1
    //     0x669634: mov             x1, #1
    // 0x669638: cmp             x1, x0
    // 0x66963c: b.hs            #0x66978c
    // 0x669640: LoadField: d0 = r4->field_1f
    //     0x669640: ldur            d0, [x4, #0x1f]
    // 0x669644: fmul            d4, d1, d0
    // 0x669648: fadd            d0, d2, d4
    // 0x66964c: mov             x0, x5
    // 0x669650: r1 = 2
    //     0x669650: mov             x1, #2
    // 0x669654: cmp             x1, x0
    // 0x669658: b.hs            #0x669790
    // 0x66965c: LoadField: d1 = r4->field_27
    //     0x66965c: ldur            d1, [x4, #0x27]
    // 0x669660: fadd            d2, d0, d1
    // 0x669664: fdiv            d0, d3, d2
    // 0x669668: SaveReg r3
    //     0x669668: str             x3, [SP, #-8]!
    // 0x66966c: SaveReg d0
    //     0x66966c: str             d0, [SP, #-8]!
    // 0x669670: r0 = scaled()
    //     0x669670: bl              #0x5b69a8  ; [package:vector_math/vector_math_64.dart] Vector3::scaled
    // 0x669674: add             SP, SP, #0x10
    // 0x669678: stur            x0, [fp, #-0x10]
    // 0x66967c: ldur            x16, [fp, #-8]
    // 0x669680: SaveReg r16
    //     0x669680: str             x16, [SP, #-8]!
    // 0x669684: r0 = clone()
    //     0x669684: bl              #0x5b6a34  ; [package:vector_math/vector_math_64.dart] Vector3::clone
    // 0x669688: add             SP, SP, #8
    // 0x66968c: mov             x1, x0
    // 0x669690: ldur            x0, [fp, #-0x10]
    // 0x669694: LoadField: r2 = r0->field_7
    //     0x669694: ldur            w2, [x0, #7]
    // 0x669698: DecompressPointer r2
    //     0x669698: add             x2, x2, HEAP, lsl #32
    // 0x66969c: LoadField: r3 = r1->field_7
    //     0x66969c: ldur            w3, [x1, #7]
    // 0x6696a0: DecompressPointer r3
    //     0x6696a0: add             x3, x3, HEAP, lsl #32
    // 0x6696a4: LoadField: r0 = r3->field_13
    //     0x6696a4: ldur            w0, [x3, #0x13]
    // 0x6696a8: DecompressPointer r0
    //     0x6696a8: add             x0, x0, HEAP, lsl #32
    // 0x6696ac: r4 = LoadInt32Instr(r0)
    //     0x6696ac: sbfx            x4, x0, #1, #0x1f
    // 0x6696b0: mov             x0, x4
    // 0x6696b4: r1 = 0
    //     0x6696b4: mov             x1, #0
    // 0x6696b8: cmp             x1, x0
    // 0x6696bc: b.hs            #0x669794
    // 0x6696c0: LoadField: d0 = r3->field_17
    //     0x6696c0: ldur            d0, [x3, #0x17]
    // 0x6696c4: LoadField: r0 = r2->field_13
    //     0x6696c4: ldur            w0, [x2, #0x13]
    // 0x6696c8: DecompressPointer r0
    //     0x6696c8: add             x0, x0, HEAP, lsl #32
    // 0x6696cc: r5 = LoadInt32Instr(r0)
    //     0x6696cc: sbfx            x5, x0, #1, #0x1f
    // 0x6696d0: mov             x0, x5
    // 0x6696d4: r1 = 0
    //     0x6696d4: mov             x1, #0
    // 0x6696d8: cmp             x1, x0
    // 0x6696dc: b.hs            #0x669798
    // 0x6696e0: LoadField: d1 = r2->field_17
    //     0x6696e0: ldur            d1, [x2, #0x17]
    // 0x6696e4: fsub            d2, d0, d1
    // 0x6696e8: stur            d2, [fp, #-0x28]
    // 0x6696ec: StoreField: r3->field_17 = d2
    //     0x6696ec: stur            d2, [x3, #0x17]
    // 0x6696f0: mov             x0, x4
    // 0x6696f4: r1 = 1
    //     0x6696f4: mov             x1, #1
    // 0x6696f8: cmp             x1, x0
    // 0x6696fc: b.hs            #0x66979c
    // 0x669700: LoadField: d0 = r3->field_1f
    //     0x669700: ldur            d0, [x3, #0x1f]
    // 0x669704: mov             x0, x5
    // 0x669708: r1 = 1
    //     0x669708: mov             x1, #1
    // 0x66970c: cmp             x1, x0
    // 0x669710: b.hs            #0x6697a0
    // 0x669714: LoadField: d1 = r2->field_1f
    //     0x669714: ldur            d1, [x2, #0x1f]
    // 0x669718: fsub            d3, d0, d1
    // 0x66971c: stur            d3, [fp, #-0x20]
    // 0x669720: StoreField: r3->field_1f = d3
    //     0x669720: stur            d3, [x3, #0x1f]
    // 0x669724: mov             x0, x4
    // 0x669728: r1 = 2
    //     0x669728: mov             x1, #2
    // 0x66972c: cmp             x1, x0
    // 0x669730: b.hs            #0x6697a4
    // 0x669734: LoadField: d0 = r3->field_27
    //     0x669734: ldur            d0, [x3, #0x27]
    // 0x669738: mov             x0, x5
    // 0x66973c: r1 = 2
    //     0x66973c: mov             x1, #2
    // 0x669740: cmp             x1, x0
    // 0x669744: b.hs            #0x6697a8
    // 0x669748: LoadField: d1 = r2->field_27
    //     0x669748: ldur            d1, [x2, #0x27]
    // 0x66974c: fsub            d4, d0, d1
    // 0x669750: StoreField: r3->field_27 = d4
    //     0x669750: stur            d4, [x3, #0x27]
    // 0x669754: r0 = Offset()
    //     0x669754: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x669758: ldur            d0, [fp, #-0x28]
    // 0x66975c: StoreField: r0->field_7 = d0
    //     0x66975c: stur            d0, [x0, #7]
    // 0x669760: ldur            d0, [fp, #-0x20]
    // 0x669764: StoreField: r0->field_f = d0
    //     0x669764: stur            d0, [x0, #0xf]
    // 0x669768: LeaveFrame
    //     0x669768: mov             SP, fp
    //     0x66976c: ldp             fp, lr, [SP], #0x10
    // 0x669770: ret
    //     0x669770: ret             
    // 0x669774: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x669774: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x669778: b               #0x669468
    // 0x66977c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x66977c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x669780: r0 = RangeErrorSharedWithFPURegs()
    //     0x669780: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x669784: r0 = RangeErrorSharedWithFPURegs()
    //     0x669784: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x669788: r0 = RangeErrorSharedWithFPURegs()
    //     0x669788: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x66978c: r0 = RangeErrorSharedWithFPURegs()
    //     0x66978c: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x669790: r0 = RangeErrorSharedWithFPURegs()
    //     0x669790: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x669794: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x669794: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x669798: r0 = RangeErrorSharedWithFPURegs()
    //     0x669798: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x66979c: r0 = RangeErrorSharedWithFPURegs()
    //     0x66979c: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x6697a0: r0 = RangeErrorSharedWithFPURegs()
    //     0x6697a0: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x6697a4: r0 = RangeErrorSharedWithFPURegs()
    //     0x6697a4: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x6697a8: r0 = RangeErrorSharedWithFPURegs()
    //     0x6697a8: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
  }
  _ getDistanceToBaseline(/* No info */) {
    // ** addr: 0x68a404, size: 0x108
    // 0x68a404: EnterFrame
    //     0x68a404: stp             fp, lr, [SP, #-0x10]!
    //     0x68a408: mov             fp, SP
    // 0x68a40c: AllocStack(0x10)
    //     0x68a40c: sub             SP, SP, #0x10
    // 0x68a410: SetupParameters(RenderBox this /* r3, fp-0x10 */, dynamic _ /* r4 */, {dynamic onlyReal = false /* r0, fp-0x8 */})
    //     0x68a410: mov             x0, x4
    //     0x68a414: ldur            w1, [x0, #0x13]
    //     0x68a418: add             x1, x1, HEAP, lsl #32
    //     0x68a41c: sub             x2, x1, #4
    //     0x68a420: add             x3, fp, w2, sxtw #2
    //     0x68a424: ldr             x3, [x3, #0x18]
    //     0x68a428: stur            x3, [fp, #-0x10]
    //     0x68a42c: add             x4, fp, w2, sxtw #2
    //     0x68a430: ldr             x4, [x4, #0x10]
    //     0x68a434: ldur            w2, [x0, #0x1f]
    //     0x68a438: add             x2, x2, HEAP, lsl #32
    //     0x68a43c: add             x16, PP, #0x50, lsl #12  ; [pp+0x50bf8] "onlyReal"
    //     0x68a440: ldr             x16, [x16, #0xbf8]
    //     0x68a444: cmp             w2, w16
    //     0x68a448: b.ne            #0x68a468
    //     0x68a44c: ldur            w2, [x0, #0x23]
    //     0x68a450: add             x2, x2, HEAP, lsl #32
    //     0x68a454: sub             w0, w1, w2
    //     0x68a458: add             x1, fp, w0, sxtw #2
    //     0x68a45c: ldr             x1, [x1, #8]
    //     0x68a460: mov             x0, x1
    //     0x68a464: b               #0x68a46c
    //     0x68a468: add             x0, NULL, #0x30  ; false
    //     0x68a46c: stur            x0, [fp, #-8]
    // 0x68a470: CheckStackOverflow
    //     0x68a470: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68a474: cmp             SP, x16
    //     0x68a478: b.ls            #0x68a4f0
    // 0x68a47c: stp             x4, x3, [SP, #-0x10]!
    // 0x68a480: r0 = getDistanceToActualBaseline()
    //     0x68a480: bl              #0x63d634  ; [package:flutter/src/rendering/box.dart] RenderBox::getDistanceToActualBaseline
    // 0x68a484: add             SP, SP, #0x10
    // 0x68a488: cmp             w0, NULL
    // 0x68a48c: b.ne            #0x68a4e4
    // 0x68a490: ldur            x1, [fp, #-8]
    // 0x68a494: tbz             w1, #4, #0x68a4e4
    // 0x68a498: ldur            x1, [fp, #-0x10]
    // 0x68a49c: LoadField: r2 = r1->field_57
    //     0x68a49c: ldur            w2, [x1, #0x57]
    // 0x68a4a0: DecompressPointer r2
    //     0x68a4a0: add             x2, x2, HEAP, lsl #32
    // 0x68a4a4: cmp             w2, NULL
    // 0x68a4a8: b.eq            #0x68a4f8
    // 0x68a4ac: LoadField: d0 = r2->field_f
    //     0x68a4ac: ldur            d0, [x2, #0xf]
    // 0x68a4b0: r0 = inline_Allocate_Double()
    //     0x68a4b0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x68a4b4: add             x0, x0, #0x10
    //     0x68a4b8: cmp             x1, x0
    //     0x68a4bc: b.ls            #0x68a4fc
    //     0x68a4c0: str             x0, [THR, #0x60]  ; THR::top
    //     0x68a4c4: sub             x0, x0, #0xf
    //     0x68a4c8: mov             x1, #0xd108
    //     0x68a4cc: movk            x1, #3, lsl #16
    //     0x68a4d0: stur            x1, [x0, #-1]
    // 0x68a4d4: StoreField: r0->field_7 = d0
    //     0x68a4d4: stur            d0, [x0, #7]
    // 0x68a4d8: LeaveFrame
    //     0x68a4d8: mov             SP, fp
    //     0x68a4dc: ldp             fp, lr, [SP], #0x10
    // 0x68a4e0: ret
    //     0x68a4e0: ret             
    // 0x68a4e4: LeaveFrame
    //     0x68a4e4: mov             SP, fp
    //     0x68a4e8: ldp             fp, lr, [SP], #0x10
    // 0x68a4ec: ret
    //     0x68a4ec: ret             
    // 0x68a4f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68a4f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68a4f4: b               #0x68a47c
    // 0x68a4f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68a4f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68a4fc: SaveReg d0
    //     0x68a4fc: str             q0, [SP, #-0x10]!
    // 0x68a500: r0 = AllocateDouble()
    //     0x68a500: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68a504: RestoreReg d0
    //     0x68a504: ldr             q0, [SP], #0x10
    // 0x68a508: b               #0x68a4d4
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0x6bcaf8, size: 0xe0
    // 0x6bcaf8: EnterFrame
    //     0x6bcaf8: stp             fp, lr, [SP, #-0x10]!
    //     0x6bcafc: mov             fp, SP
    // 0x6bcb00: AllocStack(0x8)
    //     0x6bcb00: sub             SP, SP, #8
    // 0x6bcb04: CheckStackOverflow
    //     0x6bcb04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bcb08: cmp             SP, x16
    //     0x6bcb0c: b.ls            #0x6bcbbc
    // 0x6bcb10: ldr             x0, [fp, #0x18]
    // 0x6bcb14: LoadField: r3 = r0->field_17
    //     0x6bcb14: ldur            w3, [x0, #0x17]
    // 0x6bcb18: DecompressPointer r3
    //     0x6bcb18: add             x3, x3, HEAP, lsl #32
    // 0x6bcb1c: stur            x3, [fp, #-8]
    // 0x6bcb20: cmp             w3, NULL
    // 0x6bcb24: b.eq            #0x6bcbc4
    // 0x6bcb28: mov             x0, x3
    // 0x6bcb2c: r2 = Null
    //     0x6bcb2c: mov             x2, NULL
    // 0x6bcb30: r1 = Null
    //     0x6bcb30: mov             x1, NULL
    // 0x6bcb34: r4 = LoadClassIdInstr(r0)
    //     0x6bcb34: ldur            x4, [x0, #-1]
    //     0x6bcb38: ubfx            x4, x4, #0xc, #0x14
    // 0x6bcb3c: sub             x4, x4, #0x7ff
    // 0x6bcb40: cmp             x4, #0xb
    // 0x6bcb44: b.ls            #0x6bcb5c
    // 0x6bcb48: r8 = BoxParentData
    //     0x6bcb48: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x6bcb4c: ldr             x8, [x8, #0x1b0]
    // 0x6bcb50: r3 = Null
    //     0x6bcb50: add             x3, PP, #0xb, lsl #12  ; [pp+0xb1b8] Null
    //     0x6bcb54: ldr             x3, [x3, #0x1b8]
    // 0x6bcb58: r0 = DefaultTypeTest()
    //     0x6bcb58: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6bcb5c: ldur            x0, [fp, #-8]
    // 0x6bcb60: LoadField: r1 = r0->field_7
    //     0x6bcb60: ldur            w1, [x0, #7]
    // 0x6bcb64: DecompressPointer r1
    //     0x6bcb64: add             x1, x1, HEAP, lsl #32
    // 0x6bcb68: LoadField: d0 = r1->field_7
    //     0x6bcb68: ldur            d0, [x1, #7]
    // 0x6bcb6c: LoadField: d1 = r1->field_f
    //     0x6bcb6c: ldur            d1, [x1, #0xf]
    // 0x6bcb70: r0 = inline_Allocate_Double()
    //     0x6bcb70: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6bcb74: add             x0, x0, #0x10
    //     0x6bcb78: cmp             x1, x0
    //     0x6bcb7c: b.ls            #0x6bcbc8
    //     0x6bcb80: str             x0, [THR, #0x60]  ; THR::top
    //     0x6bcb84: sub             x0, x0, #0xf
    //     0x6bcb88: mov             x1, #0xd108
    //     0x6bcb8c: movk            x1, #3, lsl #16
    //     0x6bcb90: stur            x1, [x0, #-1]
    // 0x6bcb94: StoreField: r0->field_7 = d0
    //     0x6bcb94: stur            d0, [x0, #7]
    // 0x6bcb98: ldr             x16, [fp, #0x10]
    // 0x6bcb9c: stp             x0, x16, [SP, #-0x10]!
    // 0x6bcba0: SaveReg d1
    //     0x6bcba0: str             d1, [SP, #-8]!
    // 0x6bcba4: r0 = translate()
    //     0x6bcba4: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0x6bcba8: add             SP, SP, #0x18
    // 0x6bcbac: r0 = Null
    //     0x6bcbac: mov             x0, NULL
    // 0x6bcbb0: LeaveFrame
    //     0x6bcbb0: mov             SP, fp
    //     0x6bcbb4: ldp             fp, lr, [SP], #0x10
    // 0x6bcbb8: ret
    //     0x6bcbb8: ret             
    // 0x6bcbbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bcbbc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bcbc0: b               #0x6bcb10
    // 0x6bcbc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6bcbc4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6bcbc8: stp             q0, q1, [SP, #-0x20]!
    // 0x6bcbcc: r0 = AllocateDouble()
    //     0x6bcbcc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6bcbd0: ldp             q0, q1, [SP], #0x20
    // 0x6bcbd4: b               #0x6bcb94
  }
  _ markNeedsLayout(/* No info */) {
    // ** addr: 0x6c0e34, size: 0xb4
    // 0x6c0e34: EnterFrame
    //     0x6c0e34: stp             fp, lr, [SP, #-0x10]!
    //     0x6c0e38: mov             fp, SP
    // 0x6c0e3c: CheckStackOverflow
    //     0x6c0e3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c0e40: cmp             SP, x16
    //     0x6c0e44: b.ls            #0x6c0ee0
    // 0x6c0e48: ldr             x16, [fp, #0x10]
    // 0x6c0e4c: SaveReg r16
    //     0x6c0e4c: str             x16, [SP, #-8]!
    // 0x6c0e50: r0 = _clearCachedData()
    //     0x6c0e50: bl              #0x5ae21c  ; [package:flutter/src/rendering/box.dart] RenderBox::_clearCachedData
    // 0x6c0e54: add             SP, SP, #8
    // 0x6c0e58: tbnz            w0, #4, #0x6c0ec0
    // 0x6c0e5c: ldr             x1, [fp, #0x10]
    // 0x6c0e60: r0 = LoadClassIdInstr(r1)
    //     0x6c0e60: ldur            x0, [x1, #-1]
    //     0x6c0e64: ubfx            x0, x0, #0xc, #0x14
    // 0x6c0e68: SaveReg r1
    //     0x6c0e68: str             x1, [SP, #-8]!
    // 0x6c0e6c: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0x6c0e6c: mov             x17, #0xa2f1
    //     0x6c0e70: add             lr, x0, x17
    //     0x6c0e74: ldr             lr, [x21, lr, lsl #3]
    //     0x6c0e78: blr             lr
    // 0x6c0e7c: add             SP, SP, #8
    // 0x6c0e80: r1 = LoadClassIdInstr(r0)
    //     0x6c0e80: ldur            x1, [x0, #-1]
    //     0x6c0e84: ubfx            x1, x1, #0xc, #0x14
    // 0x6c0e88: lsl             x1, x1, #1
    // 0x6c0e8c: r0 = LoadInt32Instr(r1)
    //     0x6c0e8c: sbfx            x0, x1, #1, #0x1f
    // 0x6c0e90: cmp             x0, #0x961
    // 0x6c0e94: b.lt            #0x6c0ec0
    // 0x6c0e98: cmp             x0, #0xa1f
    // 0x6c0e9c: b.gt            #0x6c0ec0
    // 0x6c0ea0: ldr             x16, [fp, #0x10]
    // 0x6c0ea4: SaveReg r16
    //     0x6c0ea4: str             x16, [SP, #-8]!
    // 0x6c0ea8: r0 = markParentNeedsLayout()
    //     0x6c0ea8: bl              #0x5ae148  ; [package:flutter/src/rendering/object.dart] RenderObject::markParentNeedsLayout
    // 0x6c0eac: add             SP, SP, #8
    // 0x6c0eb0: r0 = Null
    //     0x6c0eb0: mov             x0, NULL
    // 0x6c0eb4: LeaveFrame
    //     0x6c0eb4: mov             SP, fp
    //     0x6c0eb8: ldp             fp, lr, [SP], #0x10
    // 0x6c0ebc: ret
    //     0x6c0ebc: ret             
    // 0x6c0ec0: ldr             x16, [fp, #0x10]
    // 0x6c0ec4: SaveReg r16
    //     0x6c0ec4: str             x16, [SP, #-8]!
    // 0x6c0ec8: r0 = markNeedsLayout()
    //     0x6c0ec8: bl              #0x6c0ee8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsLayout
    // 0x6c0ecc: add             SP, SP, #8
    // 0x6c0ed0: r0 = Null
    //     0x6c0ed0: mov             x0, NULL
    // 0x6c0ed4: LeaveFrame
    //     0x6c0ed4: mov             SP, fp
    //     0x6c0ed8: ldp             fp, lr, [SP], #0x10
    // 0x6c0edc: ret
    //     0x6c0edc: ret             
    // 0x6c0ee0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c0ee0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c0ee4: b               #0x6c0e48
  }
  _ layout(/* No info */) {
    // ** addr: 0x6e6cc0, size: 0x1e0
    // 0x6e6cc0: EnterFrame
    //     0x6e6cc0: stp             fp, lr, [SP, #-0x10]!
    //     0x6e6cc4: mov             fp, SP
    // 0x6e6cc8: AllocStack(0x20)
    //     0x6e6cc8: sub             SP, SP, #0x20
    // 0x6e6ccc: SetupParameters(RenderBox this /* r3, fp-0x18 */, dynamic _ /* r4, fp-0x10 */, {dynamic parentUsesSize = false /* r0, fp-0x8 */})
    //     0x6e6ccc: mov             x0, x4
    //     0x6e6cd0: ldur            w1, [x0, #0x13]
    //     0x6e6cd4: add             x1, x1, HEAP, lsl #32
    //     0x6e6cd8: sub             x2, x1, #4
    //     0x6e6cdc: add             x3, fp, w2, sxtw #2
    //     0x6e6ce0: ldr             x3, [x3, #0x18]
    //     0x6e6ce4: stur            x3, [fp, #-0x18]
    //     0x6e6ce8: add             x4, fp, w2, sxtw #2
    //     0x6e6cec: ldr             x4, [x4, #0x10]
    //     0x6e6cf0: stur            x4, [fp, #-0x10]
    //     0x6e6cf4: ldur            w2, [x0, #0x1f]
    //     0x6e6cf8: add             x2, x2, HEAP, lsl #32
    //     0x6e6cfc: add             x16, PP, #0xb, lsl #12  ; [pp+0xb000] "parentUsesSize"
    //     0x6e6d00: ldr             x16, [x16]
    //     0x6e6d04: cmp             w2, w16
    //     0x6e6d08: b.ne            #0x6e6d28
    //     0x6e6d0c: ldur            w2, [x0, #0x23]
    //     0x6e6d10: add             x2, x2, HEAP, lsl #32
    //     0x6e6d14: sub             w0, w1, w2
    //     0x6e6d18: add             x1, fp, w0, sxtw #2
    //     0x6e6d1c: ldr             x1, [x1, #8]
    //     0x6e6d20: mov             x0, x1
    //     0x6e6d24: b               #0x6e6d2c
    //     0x6e6d28: add             x0, NULL, #0x30  ; false
    //     0x6e6d2c: stur            x0, [fp, #-8]
    // 0x6e6d30: CheckStackOverflow
    //     0x6e6d30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e6d34: cmp             SP, x16
    //     0x6e6d38: b.ls            #0x6e6e98
    // 0x6e6d3c: LoadField: r1 = r3->field_57
    //     0x6e6d3c: ldur            w1, [x3, #0x57]
    // 0x6e6d40: DecompressPointer r1
    //     0x6e6d40: add             x1, x1, HEAP, lsl #32
    // 0x6e6d44: cmp             w1, NULL
    // 0x6e6d48: b.eq            #0x6e6e64
    // 0x6e6d4c: SaveReg r3
    //     0x6e6d4c: str             x3, [SP, #-8]!
    // 0x6e6d50: r0 = constraints()
    //     0x6e6d50: bl              #0x641a58  ; [package:flutter/src/rendering/box.dart] RenderBox::constraints
    // 0x6e6d54: add             SP, SP, #8
    // 0x6e6d58: mov             x1, x0
    // 0x6e6d5c: ldur            x0, [fp, #-0x10]
    // 0x6e6d60: stur            x1, [fp, #-0x20]
    // 0x6e6d64: r2 = LoadClassIdInstr(r0)
    //     0x6e6d64: ldur            x2, [x0, #-1]
    //     0x6e6d68: ubfx            x2, x2, #0xc, #0x14
    // 0x6e6d6c: lsl             x2, x2, #1
    // 0x6e6d70: r17 = 4124
    //     0x6e6d70: mov             x17, #0x101c
    // 0x6e6d74: cmp             w2, w17
    // 0x6e6d78: b.ne            #0x6e6df0
    // 0x6e6d7c: stp             x1, x0, [SP, #-0x10]!
    // 0x6e6d80: r0 = ==()
    //     0x6e6d80: bl              #0xc9e8ac  ; [package:flutter/src/rendering/box.dart] BoxConstraints::==
    // 0x6e6d84: add             SP, SP, #0x10
    // 0x6e6d88: tbnz            w0, #4, #0x6e6e20
    // 0x6e6d8c: ldur            x0, [fp, #-0x20]
    // 0x6e6d90: r1 = LoadClassIdInstr(r0)
    //     0x6e6d90: ldur            x1, [x0, #-1]
    //     0x6e6d94: ubfx            x1, x1, #0xc, #0x14
    // 0x6e6d98: lsl             x1, x1, #1
    // 0x6e6d9c: r17 = 4124
    //     0x6e6d9c: mov             x17, #0x101c
    // 0x6e6da0: cmp             w1, w17
    // 0x6e6da4: b.ne            #0x6e6de8
    // 0x6e6da8: ldur            x1, [fp, #-0x10]
    // 0x6e6dac: LoadField: d0 = r0->field_37
    //     0x6e6dac: ldur            d0, [x0, #0x37]
    // 0x6e6db0: LoadField: d1 = r1->field_37
    //     0x6e6db0: ldur            d1, [x1, #0x37]
    // 0x6e6db4: fcmp            d0, d1
    // 0x6e6db8: b.vs            #0x6e6e20
    // 0x6e6dbc: b.ne            #0x6e6e20
    // 0x6e6dc0: LoadField: d0 = r0->field_27
    //     0x6e6dc0: ldur            d0, [x0, #0x27]
    // 0x6e6dc4: LoadField: d1 = r1->field_27
    //     0x6e6dc4: ldur            d1, [x1, #0x27]
    // 0x6e6dc8: fcmp            d0, d1
    // 0x6e6dcc: b.vs            #0x6e6e20
    // 0x6e6dd0: b.ne            #0x6e6e20
    // 0x6e6dd4: LoadField: d0 = r0->field_2f
    //     0x6e6dd4: ldur            d0, [x0, #0x2f]
    // 0x6e6dd8: LoadField: d1 = r1->field_2f
    //     0x6e6dd8: ldur            d1, [x1, #0x2f]
    // 0x6e6ddc: fcmp            d0, d1
    // 0x6e6de0: b.eq            #0x6e6e64
    // 0x6e6de4: b               #0x6e6e20
    // 0x6e6de8: ldur            x1, [fp, #-0x10]
    // 0x6e6dec: b               #0x6e6e20
    // 0x6e6df0: mov             x16, x1
    // 0x6e6df4: mov             x1, x0
    // 0x6e6df8: mov             x0, x16
    // 0x6e6dfc: r2 = LoadClassIdInstr(r1)
    //     0x6e6dfc: ldur            x2, [x1, #-1]
    //     0x6e6e00: ubfx            x2, x2, #0xc, #0x14
    // 0x6e6e04: stp             x0, x1, [SP, #-0x10]!
    // 0x6e6e08: mov             x0, x2
    // 0x6e6e0c: mov             lr, x0
    // 0x6e6e10: ldr             lr, [x21, lr, lsl #3]
    // 0x6e6e14: blr             lr
    // 0x6e6e18: add             SP, SP, #0x10
    // 0x6e6e1c: tbz             w0, #4, #0x6e6e64
    // 0x6e6e20: ldur            x0, [fp, #-0x18]
    // 0x6e6e24: LoadField: r1 = r0->field_5b
    //     0x6e6e24: ldur            w1, [x0, #0x5b]
    // 0x6e6e28: DecompressPointer r1
    //     0x6e6e28: add             x1, x1, HEAP, lsl #32
    // 0x6e6e2c: cmp             w1, NULL
    // 0x6e6e30: b.eq            #0x6e6e64
    // 0x6e6e34: LoadField: r2 = r1->field_13
    //     0x6e6e34: ldur            w2, [x1, #0x13]
    // 0x6e6e38: DecompressPointer r2
    //     0x6e6e38: add             x2, x2, HEAP, lsl #32
    // 0x6e6e3c: r3 = LoadInt32Instr(r2)
    //     0x6e6e3c: sbfx            x3, x2, #1, #0x1f
    // 0x6e6e40: asr             x2, x3, #1
    // 0x6e6e44: LoadField: r3 = r1->field_17
    //     0x6e6e44: ldur            w3, [x1, #0x17]
    // 0x6e6e48: DecompressPointer r3
    //     0x6e6e48: add             x3, x3, HEAP, lsl #32
    // 0x6e6e4c: r4 = LoadInt32Instr(r3)
    //     0x6e6e4c: sbfx            x4, x3, #1, #0x1f
    // 0x6e6e50: sub             x3, x2, x4
    // 0x6e6e54: cbz             x3, #0x6e6e64
    // 0x6e6e58: SaveReg r1
    //     0x6e6e58: str             x1, [SP, #-8]!
    // 0x6e6e5c: r0 = clear()
    //     0x6e6e5c: bl              #0x4e32e4  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x6e6e60: add             SP, SP, #8
    // 0x6e6e64: ldur            x16, [fp, #-0x18]
    // 0x6e6e68: ldur            lr, [fp, #-0x10]
    // 0x6e6e6c: stp             lr, x16, [SP, #-0x10]!
    // 0x6e6e70: ldur            x16, [fp, #-8]
    // 0x6e6e74: SaveReg r16
    //     0x6e6e74: str             x16, [SP, #-8]!
    // 0x6e6e78: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x6e6e78: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x6e6e7c: ldr             x4, [x4, #0x1c8]
    // 0x6e6e80: r0 = layout()
    //     0x6e6e80: bl              #0x6e6ea0  ; [package:flutter/src/rendering/object.dart] RenderObject::layout
    // 0x6e6e84: add             SP, SP, #0x18
    // 0x6e6e88: r0 = Null
    //     0x6e6e88: mov             x0, NULL
    // 0x6e6e8c: LeaveFrame
    //     0x6e6e8c: mov             SP, fp
    //     0x6e6e90: ldp             fp, lr, [SP], #0x10
    // 0x6e6e94: ret
    //     0x6e6e94: ret             
    // 0x6e6e98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e6e98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e6e9c: b               #0x6e6d3c
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0x7171c4, size: 0x50
    // 0x7171c4: EnterFrame
    //     0x7171c4: stp             fp, lr, [SP, #-0x10]!
    //     0x7171c8: mov             fp, SP
    // 0x7171cc: ldr             x0, [fp, #0x10]
    // 0x7171d0: r2 = Null
    //     0x7171d0: mov             x2, NULL
    // 0x7171d4: r1 = Null
    //     0x7171d4: mov             x1, NULL
    // 0x7171d8: r4 = 59
    //     0x7171d8: mov             x4, #0x3b
    // 0x7171dc: branchIfSmi(r0, 0x7171e8)
    //     0x7171dc: tbz             w0, #0, #0x7171e8
    // 0x7171e0: r4 = LoadClassIdInstr(r0)
    //     0x7171e0: ldur            x4, [x0, #-1]
    //     0x7171e4: ubfx            x4, x4, #0xc, #0x14
    // 0x7171e8: cmp             x4, #0x8f0
    // 0x7171ec: b.eq            #0x717204
    // 0x7171f0: r8 = BoxHitTestEntry<RenderBox>
    //     0x7171f0: add             x8, PP, #0xb, lsl #12  ; [pp+0xb198] Type: BoxHitTestEntry<RenderBox>
    //     0x7171f4: ldr             x8, [x8, #0x198]
    // 0x7171f8: r3 = Null
    //     0x7171f8: add             x3, PP, #0xb, lsl #12  ; [pp+0xb1a0] Null
    //     0x7171fc: ldr             x3, [x3, #0x1a0]
    // 0x717200: r0 = DefaultTypeTest()
    //     0x717200: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x717204: r0 = Null
    //     0x717204: mov             x0, NULL
    // 0x717208: LeaveFrame
    //     0x717208: mov             SP, fp
    //     0x71720c: ldp             fp, lr, [SP], #0x10
    // 0x717210: ret
    //     0x717210: ret             
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xc24c8c, size: 0x8
    // 0xc24c8c: r0 = 0.000000
    //     0xc24c8c: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xc24c90: ret
    //     0xc24c90: ret             
  }
}

// class id: 4236, size: 0xc, field offset: 0x8
abstract class RenderBoxContainerDefaultsMixin<X0 bound RenderBox, X1 bound ContainerBoxParentData<X0 bound RenderBox>> extends Object
    implements ContainerRenderObjectMixin<X0 bound RenderObject, X1 bound ContainerParentDataMixin<X0 bound RenderObject>> {
}

// class id: 5928, size: 0x14, field offset: 0x14
enum _IntrinsicDimension extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16ba4, size: 0x5c
    // 0xb16ba4: EnterFrame
    //     0xb16ba4: stp             fp, lr, [SP, #-0x10]!
    //     0xb16ba8: mov             fp, SP
    // 0xb16bac: CheckStackOverflow
    //     0xb16bac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16bb0: cmp             SP, x16
    //     0xb16bb4: b.ls            #0xb16bf8
    // 0xb16bb8: r1 = Null
    //     0xb16bb8: mov             x1, NULL
    // 0xb16bbc: r2 = 4
    //     0xb16bbc: mov             x2, #4
    // 0xb16bc0: r0 = AllocateArray()
    //     0xb16bc0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16bc4: r17 = "_IntrinsicDimension."
    //     0xb16bc4: add             x17, PP, #0x40, lsl #12  ; [pp+0x40dc8] "_IntrinsicDimension."
    //     0xb16bc8: ldr             x17, [x17, #0xdc8]
    // 0xb16bcc: StoreField: r0->field_f = r17
    //     0xb16bcc: stur            w17, [x0, #0xf]
    // 0xb16bd0: ldr             x1, [fp, #0x10]
    // 0xb16bd4: LoadField: r2 = r1->field_f
    //     0xb16bd4: ldur            w2, [x1, #0xf]
    // 0xb16bd8: DecompressPointer r2
    //     0xb16bd8: add             x2, x2, HEAP, lsl #32
    // 0xb16bdc: StoreField: r0->field_13 = r2
    //     0xb16bdc: stur            w2, [x0, #0x13]
    // 0xb16be0: SaveReg r0
    //     0xb16be0: str             x0, [SP, #-8]!
    // 0xb16be4: r0 = _interpolate()
    //     0xb16be4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16be8: add             SP, SP, #8
    // 0xb16bec: LeaveFrame
    //     0xb16bec: mov             SP, fp
    //     0xb16bf0: ldp             fp, lr, [SP], #0x10
    // 0xb16bf4: ret
    //     0xb16bf4: ret             
    // 0xb16bf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16bf8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16bfc: b               #0xb16bb8
  }
}

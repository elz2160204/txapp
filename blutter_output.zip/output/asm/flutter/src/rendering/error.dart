// lib: , url: package:flutter/src/rendering/error.dart

// class id: 1049401, size: 0x8
class :: {
}

// class id: 2436, size: 0x68, field offset: 0x60
class RenderErrorBox extends RenderBox {

  static late Color backgroundColor; // offset: 0xeb4
  static late EdgeInsets padding; // offset: 0xeac
  late final Paragraph? _paragraph; // offset: 0x64

  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x631f14, size: 0x18
    // 0x631f14: r4 = 0
    //     0x631f14: mov             x4, #0
    // 0x631f18: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x631f18: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b388] AnonymousClosure: (0x631f2c), of [package:flutter/src/rendering/error.dart] RenderErrorBox
    //     0x631f1c: ldr             x1, [x17, #0x388]
    // 0x631f20: r24 = BuildNonGenericMethodExtractorStub
    //     0x631f20: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x631f24: LoadField: r0 = r24->field_17
    //     0x631f24: ldur            x0, [x24, #0x17]
    // 0x631f28: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x631f2c, size: 0xc
    // 0x631f2c: r0 = 100000.000000
    //     0x631f2c: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3fd40] 1e+05
    //     0x631f30: ldr             x0, [x0, #0xd40]
    // 0x631f34: ret
    //     0x631f34: ret             
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x636d6c, size: 0x18
    // 0x636d6c: r4 = 0
    //     0x636d6c: mov             x4, #0
    // 0x636d70: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x636d70: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fd38] AnonymousClosure: (0x631f2c), of [package:flutter/src/rendering/error.dart] RenderErrorBox
    //     0x636d74: ldr             x1, [x17, #0xd38]
    // 0x636d78: r24 = BuildNonGenericMethodExtractorStub
    //     0x636d78: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x636d7c: LoadField: r0 = r24->field_17
    //     0x636d7c: ldur            x0, [x24, #0x17]
    // 0x636d80: br              x0
  }
  _ paint(/* No info */) {
    // ** addr: 0x66d55c, size: 0x324
    // 0x66d55c: EnterFrame
    //     0x66d55c: stp             fp, lr, [SP, #-0x10]!
    //     0x66d560: mov             fp, SP
    // 0x66d564: AllocStack(0x78)
    //     0x66d564: sub             SP, SP, #0x78
    // 0x66d568: CheckStackOverflow
    //     0x66d568: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66d56c: cmp             SP, x16
    //     0x66d570: b.ls            #0x66d850
    // 0x66d574: ldr             x0, [fp, #0x18]
    // 0x66d578: LoadField: r1 = r0->field_17
    //     0x66d578: ldur            w1, [x0, #0x17]
    // 0x66d57c: DecompressPointer r1
    //     0x66d57c: add             x1, x1, HEAP, lsl #32
    // 0x66d580: cmp             w1, NULL
    // 0x66d584: b.ne            #0x66d594
    // 0x66d588: SaveReg r0
    //     0x66d588: str             x0, [SP, #-8]!
    // 0x66d58c: r0 = _startRecording()
    //     0x66d58c: bl              #0x65af44  ; [package:flutter/src/rendering/object.dart] PaintingContext::_startRecording
    // 0x66d590: add             SP, SP, #8
    // 0x66d594: ldr             x1, [fp, #0x20]
    // 0x66d598: ldr             x0, [fp, #0x18]
    // 0x66d59c: LoadField: r2 = r0->field_17
    //     0x66d59c: ldur            w2, [x0, #0x17]
    // 0x66d5a0: DecompressPointer r2
    //     0x66d5a0: add             x2, x2, HEAP, lsl #32
    // 0x66d5a4: stur            x2, [fp, #-0x48]
    // 0x66d5a8: cmp             w2, NULL
    // 0x66d5ac: b.eq            #0x66d858
    // 0x66d5b0: LoadField: r3 = r1->field_57
    //     0x66d5b0: ldur            w3, [x1, #0x57]
    // 0x66d5b4: DecompressPointer r3
    //     0x66d5b4: add             x3, x3, HEAP, lsl #32
    // 0x66d5b8: cmp             w3, NULL
    // 0x66d5bc: b.eq            #0x66d85c
    // 0x66d5c0: ldr             x16, [fp, #0x10]
    // 0x66d5c4: stp             x3, x16, [SP, #-0x10]!
    // 0x66d5c8: r0 = &()
    //     0x66d5c8: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x66d5cc: add             SP, SP, #0x10
    // 0x66d5d0: stur            x0, [fp, #-0x50]
    // 0x66d5d4: r0 = Paint()
    //     0x66d5d4: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x66d5d8: stur            x0, [fp, #-0x58]
    // 0x66d5dc: r16 = 112
    //     0x66d5dc: mov             x16, #0x70
    // 0x66d5e0: stp             x16, NULL, [SP, #-0x10]!
    // 0x66d5e4: r0 = ByteData()
    //     0x66d5e4: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x66d5e8: add             SP, SP, #0x10
    // 0x66d5ec: mov             x2, x0
    // 0x66d5f0: ldur            x1, [fp, #-0x58]
    // 0x66d5f4: stur            x2, [fp, #-0x60]
    // 0x66d5f8: StoreField: r1->field_7 = r0
    //     0x66d5f8: stur            w0, [x1, #7]
    //     0x66d5fc: ldurb           w16, [x1, #-1]
    //     0x66d600: ldurb           w17, [x0, #-1]
    //     0x66d604: and             x16, x17, x16, lsr #2
    //     0x66d608: tst             x16, HEAP, lsr #32
    //     0x66d60c: b.eq            #0x66d614
    //     0x66d610: bl              #0xd6826c
    // 0x66d614: r0 = InitLateStaticField(0xeb4) // [package:flutter/src/rendering/error.dart] RenderErrorBox::backgroundColor
    //     0x66d614: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x66d618: ldr             x0, [x0, #0x1d68]
    //     0x66d61c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x66d620: cmp             w0, w16
    //     0x66d624: b.ne            #0x66d634
    //     0x66d628: add             x2, PP, #0xb, lsl #12  ; [pp+0xb048] Field <RenderErrorBox.backgroundColor>: static late (offset: 0xeb4)
    //     0x66d62c: ldr             x2, [x2, #0x48]
    //     0x66d630: bl              #0xd67d44
    // 0x66d634: ldur            x0, [fp, #-0x60]
    // 0x66d638: LoadField: r1 = r0->field_17
    //     0x66d638: ldur            w1, [x0, #0x17]
    // 0x66d63c: DecompressPointer r1
    //     0x66d63c: add             x1, x1, HEAP, lsl #32
    // 0x66d640: LoadField: r0 = r1->field_7
    //     0x66d640: ldur            x0, [x1, #7]
    // 0x66d644: r1 = 264290496
    //     0x66d644: mov             x1, #0xc0c0
    //     0x66d648: movk            x1, #0xfc0, lsl #16
    // 0x66d64c: str             w1, [x0, #4]
    // 0x66d650: ldur            x16, [fp, #-0x48]
    // 0x66d654: ldur            lr, [fp, #-0x50]
    // 0x66d658: stp             lr, x16, [SP, #-0x10]!
    // 0x66d65c: ldur            x16, [fp, #-0x58]
    // 0x66d660: SaveReg r16
    //     0x66d660: str             x16, [SP, #-8]!
    // 0x66d664: r0 = drawRect()
    //     0x66d664: bl              #0x65e610  ; [dart:ui] Canvas::drawRect
    // 0x66d668: add             SP, SP, #0x18
    // 0x66d66c: ldr             x0, [fp, #0x20]
    // 0x66d670: LoadField: r1 = r0->field_63
    //     0x66d670: ldur            w1, [x0, #0x63]
    // 0x66d674: DecompressPointer r1
    //     0x66d674: add             x1, x1, HEAP, lsl #32
    // 0x66d678: r16 = Sentinel
    //     0x66d678: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x66d67c: cmp             w1, w16
    // 0x66d680: b.eq            #0x66d860
    // 0x66d684: cmp             w1, NULL
    // 0x66d688: b.eq            #0x66d840
    // 0x66d68c: LoadField: r1 = r0->field_57
    //     0x66d68c: ldur            w1, [x0, #0x57]
    // 0x66d690: DecompressPointer r1
    //     0x66d690: add             x1, x1, HEAP, lsl #32
    // 0x66d694: cmp             w1, NULL
    // 0x66d698: b.eq            #0x66d86c
    // 0x66d69c: LoadField: d0 = r1->field_7
    //     0x66d69c: ldur            d0, [x1, #7]
    // 0x66d6a0: stur            d0, [fp, #-0x68]
    // 0x66d6a4: r0 = InitLateStaticField(0xeac) // [package:flutter/src/rendering/error.dart] RenderErrorBox::padding
    //     0x66d6a4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x66d6a8: ldr             x0, [x0, #0x1d58]
    //     0x66d6ac: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x66d6b0: cmp             w0, w16
    //     0x66d6b4: b.ne            #0x66d6c4
    //     0x66d6b8: add             x2, PP, #0xb, lsl #12  ; [pp+0xb050] Field <RenderErrorBox.padding>: static late (offset: 0xeac)
    //     0x66d6bc: ldr             x2, [x2, #0x50]
    //     0x66d6c0: bl              #0xd67d44
    // 0x66d6c4: ldur            d1, [fp, #-0x68]
    // 0x66d6c8: d0 = 328.000000
    //     0x66d6c8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb058] IMM: double(328) from 0x4074800000000000
    //     0x66d6cc: ldr             d0, [x17, #0x58]
    // 0x66d6d0: fcmp            d1, d0
    // 0x66d6d4: b.vs            #0x66d6f8
    // 0x66d6d8: b.le            #0x66d6f8
    // 0x66d6dc: d0 = 128.000000
    //     0x66d6dc: add             x17, PP, #0xb, lsl #12  ; [pp+0xb060] IMM: double(128) from 0x4060000000000000
    //     0x66d6e0: ldr             d0, [x17, #0x60]
    // 0x66d6e4: fsub            d2, d1, d0
    // 0x66d6e8: mov             v0.16b, v2.16b
    // 0x66d6ec: d1 = 64.000000
    //     0x66d6ec: add             x17, PP, #0xb, lsl #12  ; [pp+0xb068] IMM: double(64) from 0x4050000000000000
    //     0x66d6f0: ldr             d1, [x17, #0x68]
    // 0x66d6f4: b               #0x66d700
    // 0x66d6f8: mov             v0.16b, v1.16b
    // 0x66d6fc: d1 = 0.000000
    //     0x66d6fc: eor             v1.16b, v1.16b, v1.16b
    // 0x66d700: ldr             x0, [fp, #0x20]
    // 0x66d704: stur            d1, [fp, #-0x68]
    // 0x66d708: stur            d0, [fp, #-0x70]
    // 0x66d70c: LoadField: r1 = r0->field_63
    //     0x66d70c: ldur            w1, [x0, #0x63]
    // 0x66d710: DecompressPointer r1
    //     0x66d710: add             x1, x1, HEAP, lsl #32
    // 0x66d714: stur            x1, [fp, #-0x48]
    // 0x66d718: cmp             w1, NULL
    // 0x66d71c: b.eq            #0x66d870
    // 0x66d720: r0 = ParagraphConstraints()
    //     0x66d720: bl              #0x52404c  ; AllocateParagraphConstraintsStub -> ParagraphConstraints (size=0x10)
    // 0x66d724: ldur            d0, [fp, #-0x70]
    // 0x66d728: StoreField: r0->field_7 = d0
    //     0x66d728: stur            d0, [x0, #7]
    // 0x66d72c: ldur            x16, [fp, #-0x48]
    // 0x66d730: stp             x0, x16, [SP, #-0x10]!
    // 0x66d734: r0 = layout()
    //     0x66d734: bl              #0x51a818  ; [dart:ui] Paragraph::layout
    // 0x66d738: add             SP, SP, #0x10
    // 0x66d73c: ldr             x0, [fp, #0x20]
    // 0x66d740: LoadField: r1 = r0->field_57
    //     0x66d740: ldur            w1, [x0, #0x57]
    // 0x66d744: DecompressPointer r1
    //     0x66d744: add             x1, x1, HEAP, lsl #32
    // 0x66d748: cmp             w1, NULL
    // 0x66d74c: b.eq            #0x66d874
    // 0x66d750: LoadField: d0 = r1->field_f
    //     0x66d750: ldur            d0, [x1, #0xf]
    // 0x66d754: stur            d0, [fp, #-0x78]
    // 0x66d758: r1 = Instance_EdgeInsets
    //     0x66d758: add             x1, PP, #0xb, lsl #12  ; [pp+0xb070] Obj!EdgeInsets@b35ae1
    //     0x66d75c: ldr             x1, [x1, #0x70]
    // 0x66d760: LoadField: d1 = r1->field_f
    //     0x66d760: ldur            d1, [x1, #0xf]
    // 0x66d764: stur            d1, [fp, #-0x70]
    // 0x66d768: LoadField: r2 = r0->field_63
    //     0x66d768: ldur            w2, [x0, #0x63]
    // 0x66d76c: DecompressPointer r2
    //     0x66d76c: add             x2, x2, HEAP, lsl #32
    // 0x66d770: cmp             w2, NULL
    // 0x66d774: b.eq            #0x66d878
    // 0x66d778: SaveReg r2
    //     0x66d778: str             x2, [SP, #-8]!
    // 0x66d77c: r0 = height()
    //     0x66d77c: bl              #0x51a4dc  ; [dart:ui] Paragraph::height
    // 0x66d780: add             SP, SP, #8
    // 0x66d784: mov             v1.16b, v0.16b
    // 0x66d788: ldur            d0, [fp, #-0x70]
    // 0x66d78c: fadd            d2, d0, d1
    // 0x66d790: r0 = Instance_EdgeInsets
    //     0x66d790: add             x0, PP, #0xb, lsl #12  ; [pp+0xb070] Obj!EdgeInsets@b35ae1
    //     0x66d794: ldr             x0, [x0, #0x70]
    // 0x66d798: LoadField: d0 = r0->field_1f
    //     0x66d798: ldur            d0, [x0, #0x1f]
    // 0x66d79c: fadd            d1, d2, d0
    // 0x66d7a0: ldur            d0, [fp, #-0x78]
    // 0x66d7a4: fcmp            d0, d1
    // 0x66d7a8: b.vs            #0x66d7bc
    // 0x66d7ac: b.le            #0x66d7bc
    // 0x66d7b0: d1 = 96.000000
    //     0x66d7b0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb078] IMM: double(96) from 0x4058000000000000
    //     0x66d7b4: ldr             d1, [x17, #0x78]
    // 0x66d7b8: b               #0x66d7c0
    // 0x66d7bc: d1 = 0.000000
    //     0x66d7bc: eor             v1.16b, v1.16b, v1.16b
    // 0x66d7c0: ldr             x0, [fp, #0x20]
    // 0x66d7c4: ldur            d0, [fp, #-0x68]
    // 0x66d7c8: stur            d1, [fp, #-0x70]
    // 0x66d7cc: ldr             x16, [fp, #0x18]
    // 0x66d7d0: SaveReg r16
    //     0x66d7d0: str             x16, [SP, #-8]!
    // 0x66d7d4: r0 = canvas()
    //     0x66d7d4: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x66d7d8: add             SP, SP, #8
    // 0x66d7dc: mov             x1, x0
    // 0x66d7e0: ldr             x0, [fp, #0x20]
    // 0x66d7e4: stur            x1, [fp, #-0x50]
    // 0x66d7e8: LoadField: r2 = r0->field_63
    //     0x66d7e8: ldur            w2, [x0, #0x63]
    // 0x66d7ec: DecompressPointer r2
    //     0x66d7ec: add             x2, x2, HEAP, lsl #32
    // 0x66d7f0: stur            x2, [fp, #-0x48]
    // 0x66d7f4: cmp             w2, NULL
    // 0x66d7f8: b.eq            #0x66d87c
    // 0x66d7fc: r0 = Offset()
    //     0x66d7fc: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x66d800: ldur            d0, [fp, #-0x68]
    // 0x66d804: StoreField: r0->field_7 = d0
    //     0x66d804: stur            d0, [x0, #7]
    // 0x66d808: ldur            d0, [fp, #-0x70]
    // 0x66d80c: StoreField: r0->field_f = d0
    //     0x66d80c: stur            d0, [x0, #0xf]
    // 0x66d810: ldr             x16, [fp, #0x10]
    // 0x66d814: stp             x0, x16, [SP, #-0x10]!
    // 0x66d818: r0 = +()
    //     0x66d818: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x66d81c: add             SP, SP, #0x10
    // 0x66d820: ldur            x16, [fp, #-0x50]
    // 0x66d824: ldur            lr, [fp, #-0x48]
    // 0x66d828: stp             lr, x16, [SP, #-0x10]!
    // 0x66d82c: SaveReg r0
    //     0x66d82c: str             x0, [SP, #-8]!
    // 0x66d830: r0 = drawParagraph()
    //     0x66d830: bl              #0x65d914  ; [dart:ui] Canvas::drawParagraph
    // 0x66d834: add             SP, SP, #0x18
    // 0x66d838: b               #0x66d840
    // 0x66d83c: sub             SP, fp, #0x78
    // 0x66d840: r0 = Null
    //     0x66d840: mov             x0, NULL
    // 0x66d844: LeaveFrame
    //     0x66d844: mov             SP, fp
    //     0x66d848: ldp             fp, lr, [SP], #0x10
    // 0x66d84c: ret
    //     0x66d84c: ret             
    // 0x66d850: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66d850: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66d854: b               #0x66d574
    // 0x66d858: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66d858: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x66d85c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66d85c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x66d860: r9 = _paragraph
    //     0x66d860: add             x9, PP, #0xb, lsl #12  ; [pp+0xb080] Field <RenderErrorBox._paragraph@896451017>: late final (offset: 0x64)
    //     0x66d864: ldr             x9, [x9, #0x80]
    // 0x66d868: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x66d868: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x66d86c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66d86c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x66d870: r0 = NullCastErrorSharedWithFPURegs()
    //     0x66d870: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x66d874: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66d874: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x66d878: r0 = NullCastErrorSharedWithFPURegs()
    //     0x66d878: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x66d87c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66d87c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static EdgeInsets padding() {
    // ** addr: 0x66d88c, size: 0xc
    // 0x66d88c: r0 = Instance_EdgeInsets
    //     0x66d88c: add             x0, PP, #0xb, lsl #12  ; [pp+0xb070] Obj!EdgeInsets@b35ae1
    //     0x66d890: ldr             x0, [x0, #0x70]
    // 0x66d894: ret
    //     0x66d894: ret             
  }
  static Color backgroundColor() {
    // ** addr: 0x66d898, size: 0xc
    // 0x66d898: r0 = Instance_Color
    //     0x66d898: add             x0, PP, #0xb, lsl #12  ; [pp+0xb0e8] Obj!Color@b5d0e1
    //     0x66d89c: ldr             x0, [x0, #0xe8]
    // 0x66d8a0: ret
    //     0x66d8a0: ret             
  }
  _ RenderErrorBox(/* No info */) {
    // ** addr: 0x6f052c, size: 0x94
    // 0x6f052c: EnterFrame
    //     0x6f052c: stp             fp, lr, [SP, #-0x10]!
    //     0x6f0530: mov             fp, SP
    // 0x6f0534: AllocStack(0x28)
    //     0x6f0534: sub             SP, SP, #0x28
    // 0x6f0538: r1 = Sentinel
    //     0x6f0538: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6f053c: r0 = ""
    //     0x6f053c: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x6f0540: CheckStackOverflow
    //     0x6f0540: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f0544: cmp             SP, x16
    //     0x6f0548: b.ls            #0x6f05b8
    // 0x6f054c: ldr             x2, [fp, #0x10]
    // 0x6f0550: StoreField: r2->field_63 = r1
    //     0x6f0550: stur            w1, [x2, #0x63]
    // 0x6f0554: StoreField: r2->field_5f = r0
    //     0x6f0554: stur            w0, [x2, #0x5f]
    // 0x6f0558: SaveReg r2
    //     0x6f0558: str             x2, [SP, #-8]!
    // 0x6f055c: r0 = RenderObject()
    //     0x6f055c: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6f0560: add             SP, SP, #8
    // 0x6f0564: ldr             x0, [fp, #0x10]
    // 0x6f0568: LoadField: r1 = r0->field_63
    //     0x6f0568: ldur            w1, [x0, #0x63]
    // 0x6f056c: DecompressPointer r1
    //     0x6f056c: add             x1, x1, HEAP, lsl #32
    // 0x6f0570: r16 = Sentinel
    //     0x6f0570: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6f0574: cmp             w1, w16
    // 0x6f0578: b.ne            #0x6f0584
    // 0x6f057c: mov             x2, x0
    // 0x6f0580: b               #0x6f059c
    // 0x6f0584: r16 = "_paragraph@896451017"
    //     0x6f0584: add             x16, PP, #8, lsl #12  ; [pp+0x8930] "_paragraph@896451017"
    //     0x6f0588: ldr             x16, [x16, #0x930]
    // 0x6f058c: SaveReg r16
    //     0x6f058c: str             x16, [SP, #-8]!
    // 0x6f0590: r0 = _throwFieldAlreadyInitialized()
    //     0x6f0590: bl              #0x4fb6c8  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x6f0594: add             SP, SP, #8
    // 0x6f0598: ldr             x2, [fp, #0x10]
    // 0x6f059c: StoreField: r2->field_63 = rNULL
    //     0x6f059c: stur            NULL, [x2, #0x63]
    // 0x6f05a0: b               #0x6f05a8
    // 0x6f05a4: sub             SP, fp, #0x28
    // 0x6f05a8: r0 = Null
    //     0x6f05a8: mov             x0, NULL
    // 0x6f05ac: LeaveFrame
    //     0x6f05ac: mov             SP, fp
    //     0x6f05b0: ldp             fp, lr, [SP], #0x10
    // 0x6f05b4: ret
    //     0x6f05b4: ret             
    // 0x6f05b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f05b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f05bc: b               #0x6f054c
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5ecc0, size: 0x40
    // 0xa5ecc0: EnterFrame
    //     0xa5ecc0: stp             fp, lr, [SP, #-0x10]!
    //     0xa5ecc4: mov             fp, SP
    // 0xa5ecc8: CheckStackOverflow
    //     0xa5ecc8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5eccc: cmp             SP, x16
    //     0xa5ecd0: b.ls            #0xa5ecf8
    // 0xa5ecd4: ldr             x16, [fp, #0x10]
    // 0xa5ecd8: r30 = Instance_Size
    //     0xa5ecd8: add             lr, PP, #0xd, lsl #12  ; [pp+0xd510] Obj!Size@b5edd1
    //     0xa5ecdc: ldr             lr, [lr, #0x510]
    // 0xa5ece0: stp             lr, x16, [SP, #-0x10]!
    // 0xa5ece4: r0 = constrain()
    //     0xa5ece4: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xa5ece8: add             SP, SP, #0x10
    // 0xa5ecec: LeaveFrame
    //     0xa5ecec: mov             SP, fp
    //     0xa5ecf0: ldp             fp, lr, [SP], #0x10
    // 0xa5ecf4: ret
    //     0xa5ecf4: ret             
    // 0xa5ecf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5ecf8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5ecfc: b               #0xa5ecd4
  }
}

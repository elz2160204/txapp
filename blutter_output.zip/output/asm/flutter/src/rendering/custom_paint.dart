// lib: , url: package:flutter/src/rendering/custom_paint.dart

// class id: 1049397, size: 0x8
class :: {
}

// class id: 2032, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class CustomPainterSemantics extends Object {
}

// class id: 2521, size: 0x88, field offset: 0x64
class RenderCustomPaint extends RenderProxyBox {

  _ hitTestChildren(/* No info */) {
    // ** addr: 0x62547c, size: 0x9c
    // 0x62547c: EnterFrame
    //     0x62547c: stp             fp, lr, [SP, #-0x10]!
    //     0x625480: mov             fp, SP
    // 0x625484: CheckStackOverflow
    //     0x625484: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x625488: cmp             SP, x16
    //     0x62548c: b.ls            #0x625510
    // 0x625490: ldr             x1, [fp, #0x20]
    // 0x625494: LoadField: r0 = r1->field_67
    //     0x625494: ldur            w0, [x1, #0x67]
    // 0x625498: DecompressPointer r0
    //     0x625498: add             x0, x0, HEAP, lsl #32
    // 0x62549c: cmp             w0, NULL
    // 0x6254a0: b.eq            #0x6254e8
    // 0x6254a4: r2 = LoadClassIdInstr(r0)
    //     0x6254a4: ldur            x2, [x0, #-1]
    //     0x6254a8: ubfx            x2, x2, #0xc, #0x14
    // 0x6254ac: ldr             x16, [fp, #0x10]
    // 0x6254b0: stp             x16, x0, [SP, #-0x10]!
    // 0x6254b4: mov             x0, x2
    // 0x6254b8: r0 = GDT[cid_x0 + 0x8ffd]()
    //     0x6254b8: mov             x17, #0x8ffd
    //     0x6254bc: add             lr, x0, x17
    //     0x6254c0: ldr             lr, [x21, lr, lsl #3]
    //     0x6254c4: blr             lr
    // 0x6254c8: add             SP, SP, #0x10
    // 0x6254cc: cmp             w0, NULL
    // 0x6254d0: b.eq            #0x6254e8
    // 0x6254d4: tbnz            w0, #4, #0x6254e8
    // 0x6254d8: r0 = true
    //     0x6254d8: add             x0, NULL, #0x20  ; true
    // 0x6254dc: LeaveFrame
    //     0x6254dc: mov             SP, fp
    //     0x6254e0: ldp             fp, lr, [SP], #0x10
    // 0x6254e4: ret
    //     0x6254e4: ret             
    // 0x6254e8: ldr             x16, [fp, #0x20]
    // 0x6254ec: ldr             lr, [fp, #0x18]
    // 0x6254f0: stp             lr, x16, [SP, #-0x10]!
    // 0x6254f4: ldr             x16, [fp, #0x10]
    // 0x6254f8: SaveReg r16
    //     0x6254f8: str             x16, [SP, #-8]!
    // 0x6254fc: r0 = hitTestChildren()
    //     0x6254fc: bl              #0x627748  ; [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::hitTestChildren
    // 0x625500: add             SP, SP, #0x18
    // 0x625504: LeaveFrame
    //     0x625504: mov             SP, fp
    //     0x625508: ldp             fp, lr, [SP], #0x10
    // 0x62550c: ret
    //     0x62550c: ret             
    // 0x625510: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x625510: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x625514: b               #0x625490
  }
  _ hitTestSelf(/* No info */) {
    // ** addr: 0x62b60c, size: 0x6c
    // 0x62b60c: EnterFrame
    //     0x62b60c: stp             fp, lr, [SP, #-0x10]!
    //     0x62b610: mov             fp, SP
    // 0x62b614: CheckStackOverflow
    //     0x62b614: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62b618: cmp             SP, x16
    //     0x62b61c: b.ls            #0x62b670
    // 0x62b620: ldr             x0, [fp, #0x18]
    // 0x62b624: LoadField: r1 = r0->field_63
    //     0x62b624: ldur            w1, [x0, #0x63]
    // 0x62b628: DecompressPointer r1
    //     0x62b628: add             x1, x1, HEAP, lsl #32
    // 0x62b62c: cmp             w1, NULL
    // 0x62b630: b.eq            #0x62b660
    // 0x62b634: r0 = LoadClassIdInstr(r1)
    //     0x62b634: ldur            x0, [x1, #-1]
    //     0x62b638: ubfx            x0, x0, #0xc, #0x14
    // 0x62b63c: ldr             x16, [fp, #0x10]
    // 0x62b640: stp             x16, x1, [SP, #-0x10]!
    // 0x62b644: r0 = GDT[cid_x0 + 0x8ffd]()
    //     0x62b644: mov             x17, #0x8ffd
    //     0x62b648: add             lr, x0, x17
    //     0x62b64c: ldr             lr, [x21, lr, lsl #3]
    //     0x62b650: blr             lr
    // 0x62b654: add             SP, SP, #0x10
    // 0x62b658: r0 = true
    //     0x62b658: add             x0, NULL, #0x20  ; true
    // 0x62b65c: b               #0x62b664
    // 0x62b660: r0 = false
    //     0x62b660: add             x0, NULL, #0x30  ; false
    // 0x62b664: LeaveFrame
    //     0x62b664: mov             SP, fp
    //     0x62b668: ldp             fp, lr, [SP], #0x10
    // 0x62b66c: ret
    //     0x62b66c: ret             
    // 0x62b670: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62b670: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62b674: b               #0x62b620
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x62e9f0, size: 0x18
    // 0x62e9f0: r4 = 0
    //     0x62e9f0: mov             x4, #0
    // 0x62e9f4: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x62e9f4: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cb20] AnonymousClosure: (0x62ea08), in [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::computeMaxIntrinsicHeight (0x62ea54)
    //     0x62e9f8: ldr             x1, [x17, #0xb20]
    // 0x62e9fc: r24 = BuildNonGenericMethodExtractorStub
    //     0x62e9fc: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x62ea00: LoadField: r0 = r24->field_17
    //     0x62ea00: ldur            x0, [x24, #0x17]
    // 0x62ea04: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x62ea08, size: 0x4c
    // 0x62ea08: EnterFrame
    //     0x62ea08: stp             fp, lr, [SP, #-0x10]!
    //     0x62ea0c: mov             fp, SP
    // 0x62ea10: ldr             x0, [fp, #0x18]
    // 0x62ea14: LoadField: r1 = r0->field_17
    //     0x62ea14: ldur            w1, [x0, #0x17]
    // 0x62ea18: DecompressPointer r1
    //     0x62ea18: add             x1, x1, HEAP, lsl #32
    // 0x62ea1c: CheckStackOverflow
    //     0x62ea1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62ea20: cmp             SP, x16
    //     0x62ea24: b.ls            #0x62ea4c
    // 0x62ea28: LoadField: r0 = r1->field_f
    //     0x62ea28: ldur            w0, [x1, #0xf]
    // 0x62ea2c: DecompressPointer r0
    //     0x62ea2c: add             x0, x0, HEAP, lsl #32
    // 0x62ea30: ldr             x16, [fp, #0x10]
    // 0x62ea34: stp             x16, x0, [SP, #-0x10]!
    // 0x62ea38: r0 = computeMaxIntrinsicHeight()
    //     0x62ea38: bl              #0x62ea54  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::computeMaxIntrinsicHeight
    // 0x62ea3c: add             SP, SP, #0x10
    // 0x62ea40: LeaveFrame
    //     0x62ea40: mov             SP, fp
    //     0x62ea44: ldp             fp, lr, [SP], #0x10
    // 0x62ea48: ret
    //     0x62ea48: ret             
    // 0x62ea4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62ea4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62ea50: b               #0x62ea28
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0x62ea54, size: 0xbc
    // 0x62ea54: EnterFrame
    //     0x62ea54: stp             fp, lr, [SP, #-0x10]!
    //     0x62ea58: mov             fp, SP
    // 0x62ea5c: CheckStackOverflow
    //     0x62ea5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62ea60: cmp             SP, x16
    //     0x62ea64: b.ls            #0x62eaf8
    // 0x62ea68: ldr             x0, [fp, #0x18]
    // 0x62ea6c: LoadField: r1 = r0->field_5f
    //     0x62ea6c: ldur            w1, [x0, #0x5f]
    // 0x62ea70: DecompressPointer r1
    //     0x62ea70: add             x1, x1, HEAP, lsl #32
    // 0x62ea74: cmp             w1, NULL
    // 0x62ea78: b.ne            #0x62eadc
    // 0x62ea7c: LoadField: r1 = r0->field_6b
    //     0x62ea7c: ldur            w1, [x0, #0x6b]
    // 0x62ea80: DecompressPointer r1
    //     0x62ea80: add             x1, x1, HEAP, lsl #32
    // 0x62ea84: LoadField: d0 = r1->field_f
    //     0x62ea84: ldur            d0, [x1, #0xf]
    // 0x62ea88: mov             x0, v0.d[0]
    // 0x62ea8c: and             x0, x0, #0x7fffffffffffffff
    // 0x62ea90: r17 = 9218868437227405312
    //     0x62ea90: mov             x17, #0x7ff0000000000000
    // 0x62ea94: cmp             x0, x17
    // 0x62ea98: b.eq            #0x62eaa4
    // 0x62ea9c: fcmp            d0, d0
    // 0x62eaa0: b.vc            #0x62eaa8
    // 0x62eaa4: d0 = 0.000000
    //     0x62eaa4: eor             v0.16b, v0.16b, v0.16b
    // 0x62eaa8: r0 = inline_Allocate_Double()
    //     0x62eaa8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62eaac: add             x0, x0, #0x10
    //     0x62eab0: cmp             x1, x0
    //     0x62eab4: b.ls            #0x62eb00
    //     0x62eab8: str             x0, [THR, #0x60]  ; THR::top
    //     0x62eabc: sub             x0, x0, #0xf
    //     0x62eac0: mov             x1, #0xd108
    //     0x62eac4: movk            x1, #3, lsl #16
    //     0x62eac8: stur            x1, [x0, #-1]
    // 0x62eacc: StoreField: r0->field_7 = d0
    //     0x62eacc: stur            d0, [x0, #7]
    // 0x62ead0: LeaveFrame
    //     0x62ead0: mov             SP, fp
    //     0x62ead4: ldp             fp, lr, [SP], #0x10
    // 0x62ead8: ret
    //     0x62ead8: ret             
    // 0x62eadc: ldr             x16, [fp, #0x10]
    // 0x62eae0: stp             x16, x0, [SP, #-0x10]!
    // 0x62eae4: r0 = computeMaxIntrinsicHeight()
    //     0x62eae4: bl              #0x62e908  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMaxIntrinsicHeight
    // 0x62eae8: add             SP, SP, #0x10
    // 0x62eaec: LeaveFrame
    //     0x62eaec: mov             SP, fp
    //     0x62eaf0: ldp             fp, lr, [SP], #0x10
    // 0x62eaf4: ret
    //     0x62eaf4: ret             
    // 0x62eaf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62eaf8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62eafc: b               #0x62ea68
    // 0x62eb00: SaveReg d0
    //     0x62eb00: str             q0, [SP, #-0x10]!
    // 0x62eb04: r0 = AllocateDouble()
    //     0x62eb04: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62eb08: RestoreReg d0
    //     0x62eb08: ldr             q0, [SP], #0x10
    // 0x62eb0c: b               #0x62eacc
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x63562c, size: 0x18
    // 0x63562c: r4 = 0
    //     0x63562c: mov             x4, #0
    // 0x635630: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x635630: add             x17, PP, #0x41, lsl #12  ; [pp+0x41408] AnonymousClosure: (0x635644), in [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::computeMaxIntrinsicWidth (0x635690)
    //     0x635634: ldr             x1, [x17, #0x408]
    // 0x635638: r24 = BuildNonGenericMethodExtractorStub
    //     0x635638: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63563c: LoadField: r0 = r24->field_17
    //     0x63563c: ldur            x0, [x24, #0x17]
    // 0x635640: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x635644, size: 0x4c
    // 0x635644: EnterFrame
    //     0x635644: stp             fp, lr, [SP, #-0x10]!
    //     0x635648: mov             fp, SP
    // 0x63564c: ldr             x0, [fp, #0x18]
    // 0x635650: LoadField: r1 = r0->field_17
    //     0x635650: ldur            w1, [x0, #0x17]
    // 0x635654: DecompressPointer r1
    //     0x635654: add             x1, x1, HEAP, lsl #32
    // 0x635658: CheckStackOverflow
    //     0x635658: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63565c: cmp             SP, x16
    //     0x635660: b.ls            #0x635688
    // 0x635664: LoadField: r0 = r1->field_f
    //     0x635664: ldur            w0, [x1, #0xf]
    // 0x635668: DecompressPointer r0
    //     0x635668: add             x0, x0, HEAP, lsl #32
    // 0x63566c: ldr             x16, [fp, #0x10]
    // 0x635670: stp             x16, x0, [SP, #-0x10]!
    // 0x635674: r0 = computeMaxIntrinsicWidth()
    //     0x635674: bl              #0x635690  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::computeMaxIntrinsicWidth
    // 0x635678: add             SP, SP, #0x10
    // 0x63567c: LeaveFrame
    //     0x63567c: mov             SP, fp
    //     0x635680: ldp             fp, lr, [SP], #0x10
    // 0x635684: ret
    //     0x635684: ret             
    // 0x635688: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x635688: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63568c: b               #0x635664
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0x635690, size: 0xbc
    // 0x635690: EnterFrame
    //     0x635690: stp             fp, lr, [SP, #-0x10]!
    //     0x635694: mov             fp, SP
    // 0x635698: CheckStackOverflow
    //     0x635698: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63569c: cmp             SP, x16
    //     0x6356a0: b.ls            #0x635734
    // 0x6356a4: ldr             x0, [fp, #0x18]
    // 0x6356a8: LoadField: r1 = r0->field_5f
    //     0x6356a8: ldur            w1, [x0, #0x5f]
    // 0x6356ac: DecompressPointer r1
    //     0x6356ac: add             x1, x1, HEAP, lsl #32
    // 0x6356b0: cmp             w1, NULL
    // 0x6356b4: b.ne            #0x635718
    // 0x6356b8: LoadField: r1 = r0->field_6b
    //     0x6356b8: ldur            w1, [x0, #0x6b]
    // 0x6356bc: DecompressPointer r1
    //     0x6356bc: add             x1, x1, HEAP, lsl #32
    // 0x6356c0: LoadField: d0 = r1->field_7
    //     0x6356c0: ldur            d0, [x1, #7]
    // 0x6356c4: mov             x0, v0.d[0]
    // 0x6356c8: and             x0, x0, #0x7fffffffffffffff
    // 0x6356cc: r17 = 9218868437227405312
    //     0x6356cc: mov             x17, #0x7ff0000000000000
    // 0x6356d0: cmp             x0, x17
    // 0x6356d4: b.eq            #0x6356e0
    // 0x6356d8: fcmp            d0, d0
    // 0x6356dc: b.vc            #0x6356e4
    // 0x6356e0: d0 = 0.000000
    //     0x6356e0: eor             v0.16b, v0.16b, v0.16b
    // 0x6356e4: r0 = inline_Allocate_Double()
    //     0x6356e4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6356e8: add             x0, x0, #0x10
    //     0x6356ec: cmp             x1, x0
    //     0x6356f0: b.ls            #0x63573c
    //     0x6356f4: str             x0, [THR, #0x60]  ; THR::top
    //     0x6356f8: sub             x0, x0, #0xf
    //     0x6356fc: mov             x1, #0xd108
    //     0x635700: movk            x1, #3, lsl #16
    //     0x635704: stur            x1, [x0, #-1]
    // 0x635708: StoreField: r0->field_7 = d0
    //     0x635708: stur            d0, [x0, #7]
    // 0x63570c: LeaveFrame
    //     0x63570c: mov             SP, fp
    //     0x635710: ldp             fp, lr, [SP], #0x10
    // 0x635714: ret
    //     0x635714: ret             
    // 0x635718: ldr             x16, [fp, #0x10]
    // 0x63571c: stp             x16, x0, [SP, #-0x10]!
    // 0x635720: r0 = computeMaxIntrinsicWidth()
    //     0x635720: bl              #0x635544  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMaxIntrinsicWidth
    // 0x635724: add             SP, SP, #0x10
    // 0x635728: LeaveFrame
    //     0x635728: mov             SP, fp
    //     0x63572c: ldp             fp, lr, [SP], #0x10
    // 0x635730: ret
    //     0x635730: ret             
    // 0x635734: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x635734: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x635738: b               #0x6356a4
    // 0x63573c: SaveReg d0
    //     0x63573c: str             q0, [SP, #-0x10]!
    // 0x635740: r0 = AllocateDouble()
    //     0x635740: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x635744: RestoreReg d0
    //     0x635744: ldr             q0, [SP], #0x10
    // 0x635748: b               #0x635708
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x638724, size: 0x18
    // 0x638724: r4 = 0
    //     0x638724: mov             x4, #0
    // 0x638728: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x638728: add             x17, PP, #0x54, lsl #12  ; [pp+0x543c0] AnonymousClosure: (0x63873c), in [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::computeMinIntrinsicHeight (0x638788)
    //     0x63872c: ldr             x1, [x17, #0x3c0]
    // 0x638730: r24 = BuildNonGenericMethodExtractorStub
    //     0x638730: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x638734: LoadField: r0 = r24->field_17
    //     0x638734: ldur            x0, [x24, #0x17]
    // 0x638738: br              x0
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x63873c, size: 0x4c
    // 0x63873c: EnterFrame
    //     0x63873c: stp             fp, lr, [SP, #-0x10]!
    //     0x638740: mov             fp, SP
    // 0x638744: ldr             x0, [fp, #0x18]
    // 0x638748: LoadField: r1 = r0->field_17
    //     0x638748: ldur            w1, [x0, #0x17]
    // 0x63874c: DecompressPointer r1
    //     0x63874c: add             x1, x1, HEAP, lsl #32
    // 0x638750: CheckStackOverflow
    //     0x638750: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x638754: cmp             SP, x16
    //     0x638758: b.ls            #0x638780
    // 0x63875c: LoadField: r0 = r1->field_f
    //     0x63875c: ldur            w0, [x1, #0xf]
    // 0x638760: DecompressPointer r0
    //     0x638760: add             x0, x0, HEAP, lsl #32
    // 0x638764: ldr             x16, [fp, #0x10]
    // 0x638768: stp             x16, x0, [SP, #-0x10]!
    // 0x63876c: r0 = computeMinIntrinsicHeight()
    //     0x63876c: bl              #0x638788  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::computeMinIntrinsicHeight
    // 0x638770: add             SP, SP, #0x10
    // 0x638774: LeaveFrame
    //     0x638774: mov             SP, fp
    //     0x638778: ldp             fp, lr, [SP], #0x10
    // 0x63877c: ret
    //     0x63877c: ret             
    // 0x638780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x638780: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x638784: b               #0x63875c
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0x638788, size: 0xbc
    // 0x638788: EnterFrame
    //     0x638788: stp             fp, lr, [SP, #-0x10]!
    //     0x63878c: mov             fp, SP
    // 0x638790: CheckStackOverflow
    //     0x638790: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x638794: cmp             SP, x16
    //     0x638798: b.ls            #0x63882c
    // 0x63879c: ldr             x0, [fp, #0x18]
    // 0x6387a0: LoadField: r1 = r0->field_5f
    //     0x6387a0: ldur            w1, [x0, #0x5f]
    // 0x6387a4: DecompressPointer r1
    //     0x6387a4: add             x1, x1, HEAP, lsl #32
    // 0x6387a8: cmp             w1, NULL
    // 0x6387ac: b.ne            #0x638810
    // 0x6387b0: LoadField: r1 = r0->field_6b
    //     0x6387b0: ldur            w1, [x0, #0x6b]
    // 0x6387b4: DecompressPointer r1
    //     0x6387b4: add             x1, x1, HEAP, lsl #32
    // 0x6387b8: LoadField: d0 = r1->field_f
    //     0x6387b8: ldur            d0, [x1, #0xf]
    // 0x6387bc: mov             x0, v0.d[0]
    // 0x6387c0: and             x0, x0, #0x7fffffffffffffff
    // 0x6387c4: r17 = 9218868437227405312
    //     0x6387c4: mov             x17, #0x7ff0000000000000
    // 0x6387c8: cmp             x0, x17
    // 0x6387cc: b.eq            #0x6387d8
    // 0x6387d0: fcmp            d0, d0
    // 0x6387d4: b.vc            #0x6387dc
    // 0x6387d8: d0 = 0.000000
    //     0x6387d8: eor             v0.16b, v0.16b, v0.16b
    // 0x6387dc: r0 = inline_Allocate_Double()
    //     0x6387dc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6387e0: add             x0, x0, #0x10
    //     0x6387e4: cmp             x1, x0
    //     0x6387e8: b.ls            #0x638834
    //     0x6387ec: str             x0, [THR, #0x60]  ; THR::top
    //     0x6387f0: sub             x0, x0, #0xf
    //     0x6387f4: mov             x1, #0xd108
    //     0x6387f8: movk            x1, #3, lsl #16
    //     0x6387fc: stur            x1, [x0, #-1]
    // 0x638800: StoreField: r0->field_7 = d0
    //     0x638800: stur            d0, [x0, #7]
    // 0x638804: LeaveFrame
    //     0x638804: mov             SP, fp
    //     0x638808: ldp             fp, lr, [SP], #0x10
    // 0x63880c: ret
    //     0x63880c: ret             
    // 0x638810: ldr             x16, [fp, #0x10]
    // 0x638814: stp             x16, x0, [SP, #-0x10]!
    // 0x638818: r0 = computeMinIntrinsicHeight()
    //     0x638818: bl              #0x63863c  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMinIntrinsicHeight
    // 0x63881c: add             SP, SP, #0x10
    // 0x638820: LeaveFrame
    //     0x638820: mov             SP, fp
    //     0x638824: ldp             fp, lr, [SP], #0x10
    // 0x638828: ret
    //     0x638828: ret             
    // 0x63882c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63882c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x638830: b               #0x63879c
    // 0x638834: SaveReg d0
    //     0x638834: str             q0, [SP, #-0x10]!
    // 0x638838: r0 = AllocateDouble()
    //     0x638838: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63883c: RestoreReg d0
    //     0x63883c: ldr             q0, [SP], #0x10
    // 0x638840: b               #0x638800
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63b450, size: 0x18
    // 0x63b450: r4 = 0
    //     0x63b450: mov             x4, #0
    // 0x63b454: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63b454: add             x17, PP, #0x51, lsl #12  ; [pp+0x514b8] AnonymousClosure: (0x63b468), in [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::computeMinIntrinsicWidth (0x63b4b4)
    //     0x63b458: ldr             x1, [x17, #0x4b8]
    // 0x63b45c: r24 = BuildNonGenericMethodExtractorStub
    //     0x63b45c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63b460: LoadField: r0 = r24->field_17
    //     0x63b460: ldur            x0, [x24, #0x17]
    // 0x63b464: br              x0
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63b468, size: 0x4c
    // 0x63b468: EnterFrame
    //     0x63b468: stp             fp, lr, [SP, #-0x10]!
    //     0x63b46c: mov             fp, SP
    // 0x63b470: ldr             x0, [fp, #0x18]
    // 0x63b474: LoadField: r1 = r0->field_17
    //     0x63b474: ldur            w1, [x0, #0x17]
    // 0x63b478: DecompressPointer r1
    //     0x63b478: add             x1, x1, HEAP, lsl #32
    // 0x63b47c: CheckStackOverflow
    //     0x63b47c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63b480: cmp             SP, x16
    //     0x63b484: b.ls            #0x63b4ac
    // 0x63b488: LoadField: r0 = r1->field_f
    //     0x63b488: ldur            w0, [x1, #0xf]
    // 0x63b48c: DecompressPointer r0
    //     0x63b48c: add             x0, x0, HEAP, lsl #32
    // 0x63b490: ldr             x16, [fp, #0x10]
    // 0x63b494: stp             x16, x0, [SP, #-0x10]!
    // 0x63b498: r0 = computeMinIntrinsicWidth()
    //     0x63b498: bl              #0x63b4b4  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::computeMinIntrinsicWidth
    // 0x63b49c: add             SP, SP, #0x10
    // 0x63b4a0: LeaveFrame
    //     0x63b4a0: mov             SP, fp
    //     0x63b4a4: ldp             fp, lr, [SP], #0x10
    // 0x63b4a8: ret
    //     0x63b4a8: ret             
    // 0x63b4ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63b4ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63b4b0: b               #0x63b488
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0x63b4b4, size: 0xbc
    // 0x63b4b4: EnterFrame
    //     0x63b4b4: stp             fp, lr, [SP, #-0x10]!
    //     0x63b4b8: mov             fp, SP
    // 0x63b4bc: CheckStackOverflow
    //     0x63b4bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63b4c0: cmp             SP, x16
    //     0x63b4c4: b.ls            #0x63b558
    // 0x63b4c8: ldr             x0, [fp, #0x18]
    // 0x63b4cc: LoadField: r1 = r0->field_5f
    //     0x63b4cc: ldur            w1, [x0, #0x5f]
    // 0x63b4d0: DecompressPointer r1
    //     0x63b4d0: add             x1, x1, HEAP, lsl #32
    // 0x63b4d4: cmp             w1, NULL
    // 0x63b4d8: b.ne            #0x63b53c
    // 0x63b4dc: LoadField: r1 = r0->field_6b
    //     0x63b4dc: ldur            w1, [x0, #0x6b]
    // 0x63b4e0: DecompressPointer r1
    //     0x63b4e0: add             x1, x1, HEAP, lsl #32
    // 0x63b4e4: LoadField: d0 = r1->field_7
    //     0x63b4e4: ldur            d0, [x1, #7]
    // 0x63b4e8: mov             x0, v0.d[0]
    // 0x63b4ec: and             x0, x0, #0x7fffffffffffffff
    // 0x63b4f0: r17 = 9218868437227405312
    //     0x63b4f0: mov             x17, #0x7ff0000000000000
    // 0x63b4f4: cmp             x0, x17
    // 0x63b4f8: b.eq            #0x63b504
    // 0x63b4fc: fcmp            d0, d0
    // 0x63b500: b.vc            #0x63b508
    // 0x63b504: d0 = 0.000000
    //     0x63b504: eor             v0.16b, v0.16b, v0.16b
    // 0x63b508: r0 = inline_Allocate_Double()
    //     0x63b508: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63b50c: add             x0, x0, #0x10
    //     0x63b510: cmp             x1, x0
    //     0x63b514: b.ls            #0x63b560
    //     0x63b518: str             x0, [THR, #0x60]  ; THR::top
    //     0x63b51c: sub             x0, x0, #0xf
    //     0x63b520: mov             x1, #0xd108
    //     0x63b524: movk            x1, #3, lsl #16
    //     0x63b528: stur            x1, [x0, #-1]
    // 0x63b52c: StoreField: r0->field_7 = d0
    //     0x63b52c: stur            d0, [x0, #7]
    // 0x63b530: LeaveFrame
    //     0x63b530: mov             SP, fp
    //     0x63b534: ldp             fp, lr, [SP], #0x10
    // 0x63b538: ret
    //     0x63b538: ret             
    // 0x63b53c: ldr             x16, [fp, #0x10]
    // 0x63b540: stp             x16, x0, [SP, #-0x10]!
    // 0x63b544: r0 = computeMinIntrinsicWidth()
    //     0x63b544: bl              #0x63b368  ; [package:flutter/src/rendering/proxy_box.dart] _RenderAnimatedOpacity&RenderProxyBox&RenderProxyBoxMixin::computeMinIntrinsicWidth
    // 0x63b548: add             SP, SP, #0x10
    // 0x63b54c: LeaveFrame
    //     0x63b54c: mov             SP, fp
    //     0x63b550: ldp             fp, lr, [SP], #0x10
    // 0x63b554: ret
    //     0x63b554: ret             
    // 0x63b558: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63b558: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63b55c: b               #0x63b4c8
    // 0x63b560: SaveReg d0
    //     0x63b560: str             q0, [SP, #-0x10]!
    // 0x63b564: r0 = AllocateDouble()
    //     0x63b564: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63b568: RestoreReg d0
    //     0x63b568: ldr             q0, [SP], #0x10
    // 0x63b56c: b               #0x63b52c
  }
  _ clearSemantics(/* No info */) {
    // ** addr: 0x6450e8, size: 0x48
    // 0x6450e8: EnterFrame
    //     0x6450e8: stp             fp, lr, [SP, #-0x10]!
    //     0x6450ec: mov             fp, SP
    // 0x6450f0: CheckStackOverflow
    //     0x6450f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6450f4: cmp             SP, x16
    //     0x6450f8: b.ls            #0x645128
    // 0x6450fc: ldr             x16, [fp, #0x10]
    // 0x645100: SaveReg r16
    //     0x645100: str             x16, [SP, #-8]!
    // 0x645104: r0 = clearSemantics()
    //     0x645104: bl              #0x645174  ; [package:flutter/src/rendering/object.dart] RenderObject::clearSemantics
    // 0x645108: add             SP, SP, #8
    // 0x64510c: ldr             x1, [fp, #0x10]
    // 0x645110: StoreField: r1->field_7f = rNULL
    //     0x645110: stur            NULL, [x1, #0x7f]
    // 0x645114: StoreField: r1->field_83 = rNULL
    //     0x645114: stur            NULL, [x1, #0x83]
    // 0x645118: r0 = Null
    //     0x645118: mov             x0, NULL
    // 0x64511c: LeaveFrame
    //     0x64511c: mov             SP, fp
    //     0x645120: ldp             fp, lr, [SP], #0x10
    // 0x645124: ret
    //     0x645124: ret             
    // 0x645128: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x645128: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64512c: b               #0x6450fc
  }
  _ assembleSemanticsNode(/* No info */) {
    // ** addr: 0x6494d8, size: 0x1f0
    // 0x6494d8: EnterFrame
    //     0x6494d8: stp             fp, lr, [SP, #-0x10]!
    //     0x6494dc: mov             fp, SP
    // 0x6494e0: AllocStack(0x18)
    //     0x6494e0: sub             SP, SP, #0x18
    // 0x6494e4: CheckStackOverflow
    //     0x6494e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6494e8: cmp             SP, x16
    //     0x6494ec: b.ls            #0x6496b8
    // 0x6494f0: ldr             x0, [fp, #0x28]
    // 0x6494f4: LoadField: r1 = r0->field_7f
    //     0x6494f4: ldur            w1, [x0, #0x7f]
    // 0x6494f8: DecompressPointer r1
    //     0x6494f8: add             x1, x1, HEAP, lsl #32
    // 0x6494fc: r16 = const []
    //     0x6494fc: add             x16, PP, #0x29, lsl #12  ; [pp+0x29410] List<CustomPainterSemantics>(0)
    //     0x649500: ldr             x16, [x16, #0x410]
    // 0x649504: stp             x16, x1, [SP, #-0x10]!
    // 0x649508: r0 = _updateSemanticsChildren()
    //     0x649508: bl              #0x6496c8  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::_updateSemanticsChildren
    // 0x64950c: add             SP, SP, #0x10
    // 0x649510: ldr             x1, [fp, #0x28]
    // 0x649514: StoreField: r1->field_7f = r0
    //     0x649514: stur            w0, [x1, #0x7f]
    //     0x649518: ldurb           w16, [x1, #-1]
    //     0x64951c: ldurb           w17, [x0, #-1]
    //     0x649520: and             x16, x17, x16, lsr #2
    //     0x649524: tst             x16, HEAP, lsr #32
    //     0x649528: b.eq            #0x649530
    //     0x64952c: bl              #0xd6826c
    // 0x649530: LoadField: r0 = r1->field_83
    //     0x649530: ldur            w0, [x1, #0x83]
    // 0x649534: DecompressPointer r0
    //     0x649534: add             x0, x0, HEAP, lsl #32
    // 0x649538: r16 = const []
    //     0x649538: add             x16, PP, #0x29, lsl #12  ; [pp+0x29410] List<CustomPainterSemantics>(0)
    //     0x64953c: ldr             x16, [x16, #0x410]
    // 0x649540: stp             x16, x0, [SP, #-0x10]!
    // 0x649544: r0 = _updateSemanticsChildren()
    //     0x649544: bl              #0x6496c8  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::_updateSemanticsChildren
    // 0x649548: add             SP, SP, #0x10
    // 0x64954c: ldr             x1, [fp, #0x28]
    // 0x649550: StoreField: r1->field_83 = r0
    //     0x649550: stur            w0, [x1, #0x83]
    //     0x649554: ldurb           w16, [x1, #-1]
    //     0x649558: ldurb           w17, [x0, #-1]
    //     0x64955c: and             x16, x17, x16, lsr #2
    //     0x649560: tst             x16, HEAP, lsr #32
    //     0x649564: b.eq            #0x64956c
    //     0x649568: bl              #0xd6826c
    // 0x64956c: LoadField: r0 = r1->field_7f
    //     0x64956c: ldur            w0, [x1, #0x7f]
    // 0x649570: DecompressPointer r0
    //     0x649570: add             x0, x0, HEAP, lsl #32
    // 0x649574: cmp             w0, NULL
    // 0x649578: b.eq            #0x6495ac
    // 0x64957c: SaveReg r0
    //     0x64957c: str             x0, [SP, #-8]!
    // 0x649580: r0 = length()
    //     0x649580: bl              #0x6fd47c  ; [dart:_internal] _CastIterableBase::length
    // 0x649584: add             SP, SP, #8
    // 0x649588: r1 = LoadInt32Instr(r0)
    //     0x649588: sbfx            x1, x0, #1, #0x1f
    //     0x64958c: tbz             w0, #0, #0x649594
    //     0x649590: ldur            x1, [x0, #7]
    // 0x649594: cbnz            x1, #0x6495a0
    // 0x649598: r0 = false
    //     0x649598: add             x0, NULL, #0x30  ; false
    // 0x64959c: b               #0x6495a4
    // 0x6495a0: r0 = true
    //     0x6495a0: add             x0, NULL, #0x20  ; true
    // 0x6495a4: mov             x1, x0
    // 0x6495a8: b               #0x6495b0
    // 0x6495ac: r1 = false
    //     0x6495ac: add             x1, NULL, #0x30  ; false
    // 0x6495b0: ldr             x0, [fp, #0x28]
    // 0x6495b4: stur            x1, [fp, #-8]
    // 0x6495b8: LoadField: r2 = r0->field_83
    //     0x6495b8: ldur            w2, [x0, #0x83]
    // 0x6495bc: DecompressPointer r2
    //     0x6495bc: add             x2, x2, HEAP, lsl #32
    // 0x6495c0: cmp             w2, NULL
    // 0x6495c4: b.eq            #0x6495f8
    // 0x6495c8: SaveReg r2
    //     0x6495c8: str             x2, [SP, #-8]!
    // 0x6495cc: r0 = length()
    //     0x6495cc: bl              #0x6fd47c  ; [dart:_internal] _CastIterableBase::length
    // 0x6495d0: add             SP, SP, #8
    // 0x6495d4: r1 = LoadInt32Instr(r0)
    //     0x6495d4: sbfx            x1, x0, #1, #0x1f
    //     0x6495d8: tbz             w0, #0, #0x6495e0
    //     0x6495dc: ldur            x1, [x0, #7]
    // 0x6495e0: cbnz            x1, #0x6495ec
    // 0x6495e4: r0 = false
    //     0x6495e4: add             x0, NULL, #0x30  ; false
    // 0x6495e8: b               #0x6495f0
    // 0x6495ec: r0 = true
    //     0x6495ec: add             x0, NULL, #0x20  ; true
    // 0x6495f0: mov             x1, x0
    // 0x6495f4: b               #0x6495fc
    // 0x6495f8: r1 = false
    //     0x6495f8: add             x1, NULL, #0x30  ; false
    // 0x6495fc: ldur            x0, [fp, #-8]
    // 0x649600: stur            x1, [fp, #-0x10]
    // 0x649604: r16 = <SemanticsNode>
    //     0x649604: ldr             x16, [PP, #0x45e0]  ; [pp+0x45e0] TypeArguments: <SemanticsNode>
    // 0x649608: stp             xzr, x16, [SP, #-0x10]!
    // 0x64960c: r0 = _GrowableList()
    //     0x64960c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x649610: add             SP, SP, #0x10
    // 0x649614: mov             x1, x0
    // 0x649618: ldur            x0, [fp, #-8]
    // 0x64961c: stur            x1, [fp, #-0x18]
    // 0x649620: tbnz            w0, #4, #0x649644
    // 0x649624: ldr             x0, [fp, #0x28]
    // 0x649628: LoadField: r2 = r0->field_7f
    //     0x649628: ldur            w2, [x0, #0x7f]
    // 0x64962c: DecompressPointer r2
    //     0x64962c: add             x2, x2, HEAP, lsl #32
    // 0x649630: cmp             w2, NULL
    // 0x649634: b.eq            #0x6496c0
    // 0x649638: stp             x2, x1, [SP, #-0x10]!
    // 0x64963c: r0 = addAll()
    //     0x64963c: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0x649640: add             SP, SP, #0x10
    // 0x649644: ldur            x0, [fp, #-0x10]
    // 0x649648: ldur            x16, [fp, #-0x18]
    // 0x64964c: ldr             lr, [fp, #0x10]
    // 0x649650: stp             lr, x16, [SP, #-0x10]!
    // 0x649654: r0 = addAll()
    //     0x649654: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0x649658: add             SP, SP, #0x10
    // 0x64965c: ldur            x0, [fp, #-0x10]
    // 0x649660: tbnz            w0, #4, #0x649688
    // 0x649664: ldr             x0, [fp, #0x28]
    // 0x649668: LoadField: r1 = r0->field_83
    //     0x649668: ldur            w1, [x0, #0x83]
    // 0x64966c: DecompressPointer r1
    //     0x64966c: add             x1, x1, HEAP, lsl #32
    // 0x649670: cmp             w1, NULL
    // 0x649674: b.eq            #0x6496c4
    // 0x649678: ldur            x16, [fp, #-0x18]
    // 0x64967c: stp             x1, x16, [SP, #-0x10]!
    // 0x649680: r0 = addAll()
    //     0x649680: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0x649684: add             SP, SP, #0x10
    // 0x649688: ldr             x16, [fp, #0x20]
    // 0x64968c: ldr             lr, [fp, #0x18]
    // 0x649690: stp             lr, x16, [SP, #-0x10]!
    // 0x649694: ldur            x16, [fp, #-0x18]
    // 0x649698: SaveReg r16
    //     0x649698: str             x16, [SP, #-8]!
    // 0x64969c: r4 = const [0, 0x3, 0x3, 0x2, childrenInInversePaintOrder, 0x2, null]
    //     0x64969c: ldr             x4, [PP, #0x7218]  ; [pp+0x7218] List(7) [0, 0x3, 0x3, 0x2, "childrenInInversePaintOrder", 0x2, Null]
    // 0x6496a0: r0 = updateWith()
    //     0x6496a0: bl              #0x6469d8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::updateWith
    // 0x6496a4: add             SP, SP, #0x18
    // 0x6496a8: r0 = Null
    //     0x6496a8: mov             x0, NULL
    // 0x6496ac: LeaveFrame
    //     0x6496ac: mov             SP, fp
    //     0x6496b0: ldp             fp, lr, [SP], #0x10
    // 0x6496b4: ret
    //     0x6496b4: ret             
    // 0x6496b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6496b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6496bc: b               #0x6494f0
    // 0x6496c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6496c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6496c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6496c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ _updateSemanticsChildren(/* No info */) {
    // ** addr: 0x6496c8, size: 0x454
    // 0x6496c8: EnterFrame
    //     0x6496c8: stp             fp, lr, [SP, #-0x10]!
    //     0x6496cc: mov             fp, SP
    // 0x6496d0: AllocStack(0x48)
    //     0x6496d0: sub             SP, SP, #0x48
    // 0x6496d4: CheckStackOverflow
    //     0x6496d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6496d8: cmp             SP, x16
    //     0x6496dc: b.ls            #0x649b04
    // 0x6496e0: ldr             x0, [fp, #0x18]
    // 0x6496e4: cmp             w0, NULL
    // 0x6496e8: b.ne            #0x6496f4
    // 0x6496ec: r2 = const []
    //     0x6496ec: ldr             x2, [PP, #0x7240]  ; [pp+0x7240] List<SemanticsNode>(0)
    // 0x6496f0: b               #0x6496f8
    // 0x6496f4: mov             x2, x0
    // 0x6496f8: ldr             x1, [fp, #0x10]
    // 0x6496fc: stur            x2, [fp, #-8]
    // 0x649700: r0 = LoadClassIdInstr(r1)
    //     0x649700: ldur            x0, [x1, #-1]
    //     0x649704: ubfx            x0, x0, #0xc, #0x14
    // 0x649708: SaveReg r1
    //     0x649708: str             x1, [SP, #-8]!
    // 0x64970c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x64970c: mov             x17, #0xb8ea
    //     0x649710: add             lr, x0, x17
    //     0x649714: ldr             lr, [x21, lr, lsl #3]
    //     0x649718: blr             lr
    // 0x64971c: add             SP, SP, #8
    // 0x649720: r1 = LoadInt32Instr(r0)
    //     0x649720: sbfx            x1, x0, #1, #0x1f
    //     0x649724: tbz             w0, #0, #0x64972c
    //     0x649728: ldur            x1, [x0, #7]
    // 0x64972c: sub             x2, x1, #1
    // 0x649730: ldur            x1, [fp, #-8]
    // 0x649734: stur            x2, [fp, #-0x10]
    // 0x649738: r0 = LoadClassIdInstr(r1)
    //     0x649738: ldur            x0, [x1, #-1]
    //     0x64973c: ubfx            x0, x0, #0xc, #0x14
    // 0x649740: SaveReg r1
    //     0x649740: str             x1, [SP, #-8]!
    // 0x649744: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x649744: mov             x17, #0xb8ea
    //     0x649748: add             lr, x0, x17
    //     0x64974c: ldr             lr, [x21, lr, lsl #3]
    //     0x649750: blr             lr
    // 0x649754: add             SP, SP, #8
    // 0x649758: r1 = LoadInt32Instr(r0)
    //     0x649758: sbfx            x1, x0, #1, #0x1f
    //     0x64975c: tbz             w0, #0, #0x649764
    //     0x649760: ldur            x1, [x0, #7]
    // 0x649764: sub             x2, x1, #1
    // 0x649768: ldr             x1, [fp, #0x10]
    // 0x64976c: stur            x2, [fp, #-0x18]
    // 0x649770: r0 = LoadClassIdInstr(r1)
    //     0x649770: ldur            x0, [x1, #-1]
    //     0x649774: ubfx            x0, x0, #0xc, #0x14
    // 0x649778: SaveReg r1
    //     0x649778: str             x1, [SP, #-8]!
    // 0x64977c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x64977c: mov             x17, #0xb8ea
    //     0x649780: add             lr, x0, x17
    //     0x649784: ldr             lr, [x21, lr, lsl #3]
    //     0x649788: blr             lr
    // 0x64978c: add             SP, SP, #8
    // 0x649790: ldur            x2, [fp, #-0x18]
    // 0x649794: stur            x0, [fp, #-0x28]
    // 0x649798: tbz             x2, #0x3f, #0x6497a4
    // 0x64979c: r1 = false
    //     0x64979c: add             x1, NULL, #0x30  ; false
    // 0x6497a0: b               #0x6497a8
    // 0x6497a4: r1 = true
    //     0x6497a4: add             x1, NULL, #0x20  ; true
    // 0x6497a8: stur            x1, [fp, #-0x20]
    // 0x6497ac: tbnz            w1, #4, #0x6497c4
    // 0x6497b0: ldur            x3, [fp, #-0x10]
    // 0x6497b4: tbz             x3, #0x3f, #0x6499b4
    // 0x6497b8: ldr             x5, [fp, #0x10]
    // 0x6497bc: ldur            x4, [fp, #-8]
    // 0x6497c0: b               #0x6497d0
    // 0x6497c4: ldr             x5, [fp, #0x10]
    // 0x6497c8: ldur            x4, [fp, #-8]
    // 0x6497cc: ldur            x3, [fp, #-0x10]
    // 0x6497d0: CheckStackOverflow
    //     0x6497d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6497d4: cmp             SP, x16
    //     0x6497d8: b.ls            #0x649b0c
    // 0x6497dc: tbnz            w1, #4, #0x6497e4
    // 0x6497e0: tbz             x3, #0x3f, #0x649a04
    // 0x6497e4: tbnz            w1, #4, #0x6498c0
    // 0x6497e8: r16 = <Key, SemanticsNode>
    //     0x6497e8: add             x16, PP, #0x22, lsl #12  ; [pp+0x22280] TypeArguments: <Key, SemanticsNode>
    //     0x6497ec: ldr             x16, [x16, #0x280]
    // 0x6497f0: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x6497f4: stp             lr, x16, [SP, #-0x10]!
    // 0x6497f8: r0 = Map._fromLiteral()
    //     0x6497f8: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x6497fc: add             SP, SP, #0x10
    // 0x649800: mov             x2, x0
    // 0x649804: stur            x2, [fp, #-0x38]
    // 0x649808: r5 = 0
    //     0x649808: mov             x5, #0
    // 0x64980c: ldur            x4, [fp, #-8]
    // 0x649810: ldur            x3, [fp, #-0x18]
    // 0x649814: stur            x5, [fp, #-0x30]
    // 0x649818: CheckStackOverflow
    //     0x649818: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64981c: cmp             SP, x16
    //     0x649820: b.ls            #0x649b14
    // 0x649824: cmp             x5, x3
    // 0x649828: b.gt            #0x6498b4
    // 0x64982c: r0 = BoxInt64Instr(r5)
    //     0x64982c: sbfiz           x0, x5, #1, #0x1f
    //     0x649830: cmp             x5, x0, asr #1
    //     0x649834: b.eq            #0x649840
    //     0x649838: bl              #0xd69bb8
    //     0x64983c: stur            x5, [x0, #7]
    // 0x649840: r1 = LoadClassIdInstr(r4)
    //     0x649840: ldur            x1, [x4, #-1]
    //     0x649844: ubfx            x1, x1, #0xc, #0x14
    // 0x649848: stp             x0, x4, [SP, #-0x10]!
    // 0x64984c: mov             x0, x1
    // 0x649850: r0 = GDT[cid_x0 + -0xd83]()
    //     0x649850: sub             lr, x0, #0xd83
    //     0x649854: ldr             lr, [x21, lr, lsl #3]
    //     0x649858: blr             lr
    // 0x64985c: add             SP, SP, #0x10
    // 0x649860: stur            x0, [fp, #-0x48]
    // 0x649864: LoadField: r1 = r0->field_17
    //     0x649864: ldur            w1, [x0, #0x17]
    // 0x649868: DecompressPointer r1
    //     0x649868: add             x1, x1, HEAP, lsl #32
    // 0x64986c: stur            x1, [fp, #-0x40]
    // 0x649870: cmp             w1, NULL
    // 0x649874: b.eq            #0x6498a4
    // 0x649878: SaveReg r1
    //     0x649878: str             x1, [SP, #-8]!
    // 0x64987c: r0 = _getHash()
    //     0x64987c: bl              #0x5c2424  ; [dart:core] ::_getHash
    // 0x649880: add             SP, SP, #8
    // 0x649884: r1 = LoadInt32Instr(r0)
    //     0x649884: sbfx            x1, x0, #1, #0x1f
    // 0x649888: ldur            x16, [fp, #-0x38]
    // 0x64988c: ldur            lr, [fp, #-0x40]
    // 0x649890: stp             lr, x16, [SP, #-0x10]!
    // 0x649894: ldur            x16, [fp, #-0x48]
    // 0x649898: stp             x1, x16, [SP, #-0x10]!
    // 0x64989c: r0 = _set()
    //     0x64989c: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x6498a0: add             SP, SP, #0x20
    // 0x6498a4: ldur            x0, [fp, #-0x30]
    // 0x6498a8: add             x5, x0, #1
    // 0x6498ac: ldur            x2, [fp, #-0x38]
    // 0x6498b0: b               #0x64980c
    // 0x6498b4: mov             x0, x5
    // 0x6498b8: mov             x1, x0
    // 0x6498bc: b               #0x6498c4
    // 0x6498c0: r1 = 0
    //     0x6498c0: mov             x1, #0
    // 0x6498c4: ldur            x0, [fp, #-0x10]
    // 0x6498c8: stur            x1, [fp, #-0x18]
    // 0x6498cc: tbnz            x0, #0x3f, #0x649900
    // 0x6498d0: ldr             x2, [fp, #0x10]
    // 0x6498d4: ldur            x1, [fp, #-0x20]
    // 0x6498d8: r0 = LoadClassIdInstr(r2)
    //     0x6498d8: ldur            x0, [x2, #-1]
    //     0x6498dc: ubfx            x0, x0, #0xc, #0x14
    // 0x6498e0: stp             xzr, x2, [SP, #-0x10]!
    // 0x6498e4: r0 = GDT[cid_x0 + -0xd83]()
    //     0x6498e4: sub             lr, x0, #0xd83
    //     0x6498e8: ldr             lr, [x21, lr, lsl #3]
    //     0x6498ec: blr             lr
    // 0x6498f0: add             SP, SP, #0x10
    // 0x6498f4: ldur            x0, [fp, #-0x20]
    // 0x6498f8: tbnz            w0, #4, #0x649a8c
    // 0x6498fc: b               #0x649a80
    // 0x649900: ldr             x2, [fp, #0x10]
    // 0x649904: ldur            x3, [fp, #-8]
    // 0x649908: r0 = LoadClassIdInstr(r2)
    //     0x649908: ldur            x0, [x2, #-1]
    //     0x64990c: ubfx            x0, x0, #0xc, #0x14
    // 0x649910: SaveReg r2
    //     0x649910: str             x2, [SP, #-8]!
    // 0x649914: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x649914: mov             x17, #0xb8ea
    //     0x649918: add             lr, x0, x17
    //     0x64991c: ldr             lr, [x21, lr, lsl #3]
    //     0x649920: blr             lr
    // 0x649924: add             SP, SP, #8
    // 0x649928: r1 = LoadInt32Instr(r0)
    //     0x649928: sbfx            x1, x0, #1, #0x1f
    //     0x64992c: tbz             w0, #0, #0x649934
    //     0x649930: ldur            x1, [x0, #7]
    // 0x649934: sub             x2, x1, #1
    // 0x649938: ldur            x1, [fp, #-8]
    // 0x64993c: stur            x2, [fp, #-0x10]
    // 0x649940: r0 = LoadClassIdInstr(r1)
    //     0x649940: ldur            x0, [x1, #-1]
    //     0x649944: ubfx            x0, x0, #0xc, #0x14
    // 0x649948: SaveReg r1
    //     0x649948: str             x1, [SP, #-8]!
    // 0x64994c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x64994c: mov             x17, #0xb8ea
    //     0x649950: add             lr, x0, x17
    //     0x649954: ldr             lr, [x21, lr, lsl #3]
    //     0x649958: blr             lr
    // 0x64995c: add             SP, SP, #8
    // 0x649960: r1 = LoadInt32Instr(r0)
    //     0x649960: sbfx            x1, x0, #1, #0x1f
    //     0x649964: tbz             w0, #0, #0x64996c
    //     0x649968: ldur            x1, [x0, #7]
    // 0x64996c: sub             x0, x1, #1
    // 0x649970: ldur            x2, [fp, #-0x18]
    // 0x649974: cmp             x2, x0
    // 0x649978: b.gt            #0x649984
    // 0x64997c: ldur            x0, [fp, #-0x10]
    // 0x649980: tbz             x0, #0x3f, #0x649a98
    // 0x649984: ldur            x2, [fp, #-0x28]
    // 0x649988: r1 = <SemanticsNode?>
    //     0x649988: add             x1, PP, #0x29, lsl #12  ; [pp+0x29418] TypeArguments: <SemanticsNode?>
    //     0x64998c: ldr             x1, [x1, #0x418]
    // 0x649990: r0 = AllocateArray()
    //     0x649990: bl              #0xd6987c  ; AllocateArrayStub
    // 0x649994: r16 = <SemanticsNode>
    //     0x649994: ldr             x16, [PP, #0x45e0]  ; [pp+0x45e0] TypeArguments: <SemanticsNode>
    // 0x649998: stp             x0, x16, [SP, #-0x10]!
    // 0x64999c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x64999c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x6499a0: r0 = cast()
    //     0x6499a0: bl              #0x6fad9c  ; [dart:collection] ListMixin::cast
    // 0x6499a4: add             SP, SP, #0x10
    // 0x6499a8: LeaveFrame
    //     0x6499a8: mov             SP, fp
    //     0x6499ac: ldp             fp, lr, [SP], #0x10
    // 0x6499b0: ret
    //     0x6499b0: ret             
    // 0x6499b4: ldr             x1, [fp, #0x10]
    // 0x6499b8: ldur            x4, [fp, #-8]
    // 0x6499bc: r0 = LoadClassIdInstr(r4)
    //     0x6499bc: ldur            x0, [x4, #-1]
    //     0x6499c0: ubfx            x0, x0, #0xc, #0x14
    // 0x6499c4: stp             xzr, x4, [SP, #-0x10]!
    // 0x6499c8: r0 = GDT[cid_x0 + -0xd83]()
    //     0x6499c8: sub             lr, x0, #0xd83
    //     0x6499cc: ldr             lr, [x21, lr, lsl #3]
    //     0x6499d0: blr             lr
    // 0x6499d4: add             SP, SP, #0x10
    // 0x6499d8: ldr             x5, [fp, #0x10]
    // 0x6499dc: r0 = LoadClassIdInstr(r5)
    //     0x6499dc: ldur            x0, [x5, #-1]
    //     0x6499e0: ubfx            x0, x0, #0xc, #0x14
    // 0x6499e4: stp             xzr, x5, [SP, #-0x10]!
    // 0x6499e8: r0 = GDT[cid_x0 + -0xd83]()
    //     0x6499e8: sub             lr, x0, #0xd83
    //     0x6499ec: ldr             lr, [x21, lr, lsl #3]
    //     0x6499f0: blr             lr
    // 0x6499f4: add             SP, SP, #0x10
    // 0x6499f8: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x6499f8: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x6499fc: r0 = Throw()
    //     0x6499fc: bl              #0xd67e38  ; ThrowStub
    // 0x649a00: brk             #0
    // 0x649a04: r0 = BoxInt64Instr(r2)
    //     0x649a04: sbfiz           x0, x2, #1, #0x1f
    //     0x649a08: cmp             x2, x0, asr #1
    //     0x649a0c: b.eq            #0x649a18
    //     0x649a10: bl              #0xd69bb8
    //     0x649a14: stur            x2, [x0, #7]
    // 0x649a18: r1 = LoadClassIdInstr(r4)
    //     0x649a18: ldur            x1, [x4, #-1]
    //     0x649a1c: ubfx            x1, x1, #0xc, #0x14
    // 0x649a20: stp             x0, x4, [SP, #-0x10]!
    // 0x649a24: mov             x0, x1
    // 0x649a28: r0 = GDT[cid_x0 + -0xd83]()
    //     0x649a28: sub             lr, x0, #0xd83
    //     0x649a2c: ldr             lr, [x21, lr, lsl #3]
    //     0x649a30: blr             lr
    // 0x649a34: add             SP, SP, #0x10
    // 0x649a38: ldur            x3, [fp, #-0x10]
    // 0x649a3c: r0 = BoxInt64Instr(r3)
    //     0x649a3c: sbfiz           x0, x3, #1, #0x1f
    //     0x649a40: cmp             x3, x0, asr #1
    //     0x649a44: b.eq            #0x649a50
    //     0x649a48: bl              #0xd69bb8
    //     0x649a4c: stur            x3, [x0, #7]
    // 0x649a50: ldr             x5, [fp, #0x10]
    // 0x649a54: r1 = LoadClassIdInstr(r5)
    //     0x649a54: ldur            x1, [x5, #-1]
    //     0x649a58: ubfx            x1, x1, #0xc, #0x14
    // 0x649a5c: stp             x0, x5, [SP, #-0x10]!
    // 0x649a60: mov             x0, x1
    // 0x649a64: r0 = GDT[cid_x0 + -0xd83]()
    //     0x649a64: sub             lr, x0, #0xd83
    //     0x649a68: ldr             lr, [x21, lr, lsl #3]
    //     0x649a6c: blr             lr
    // 0x649a70: add             SP, SP, #0x10
    // 0x649a74: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x649a74: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x649a78: r0 = Throw()
    //     0x649a78: bl              #0xd67e38  ; ThrowStub
    // 0x649a7c: brk             #0
    // 0x649a80: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x649a80: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x649a84: r0 = Throw()
    //     0x649a84: bl              #0xd67e38  ; ThrowStub
    // 0x649a88: brk             #0
    // 0x649a8c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x649a8c: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x649a90: r0 = Throw()
    //     0x649a90: bl              #0xd67e38  ; ThrowStub
    // 0x649a94: brk             #0
    // 0x649a98: ldr             x4, [fp, #0x10]
    // 0x649a9c: ldur            x3, [fp, #-8]
    // 0x649aa0: r0 = BoxInt64Instr(r2)
    //     0x649aa0: sbfiz           x0, x2, #1, #0x1f
    //     0x649aa4: cmp             x2, x0, asr #1
    //     0x649aa8: b.eq            #0x649ab4
    //     0x649aac: bl              #0xd69bb8
    //     0x649ab0: stur            x2, [x0, #7]
    // 0x649ab4: r1 = LoadClassIdInstr(r3)
    //     0x649ab4: ldur            x1, [x3, #-1]
    //     0x649ab8: ubfx            x1, x1, #0xc, #0x14
    // 0x649abc: stp             x0, x3, [SP, #-0x10]!
    // 0x649ac0: mov             x0, x1
    // 0x649ac4: r0 = GDT[cid_x0 + -0xd83]()
    //     0x649ac4: sub             lr, x0, #0xd83
    //     0x649ac8: ldr             lr, [x21, lr, lsl #3]
    //     0x649acc: blr             lr
    // 0x649ad0: add             SP, SP, #0x10
    // 0x649ad4: ldr             x0, [fp, #0x10]
    // 0x649ad8: r1 = LoadClassIdInstr(r0)
    //     0x649ad8: ldur            x1, [x0, #-1]
    //     0x649adc: ubfx            x1, x1, #0xc, #0x14
    // 0x649ae0: stp             xzr, x0, [SP, #-0x10]!
    // 0x649ae4: mov             x0, x1
    // 0x649ae8: r0 = GDT[cid_x0 + -0xd83]()
    //     0x649ae8: sub             lr, x0, #0xd83
    //     0x649aec: ldr             lr, [x21, lr, lsl #3]
    //     0x649af0: blr             lr
    // 0x649af4: add             SP, SP, #0x10
    // 0x649af8: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x649af8: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x649afc: r0 = Throw()
    //     0x649afc: bl              #0xd67e38  ; ThrowStub
    // 0x649b00: brk             #0
    // 0x649b04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x649b04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x649b08: b               #0x6496e0
    // 0x649b0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x649b0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x649b10: b               #0x6497dc
    // 0x649b14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x649b14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x649b18: b               #0x649824
  }
  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0x64e2c0, size: 0xb4
    // 0x64e2c0: EnterFrame
    //     0x64e2c0: stp             fp, lr, [SP, #-0x10]!
    //     0x64e2c4: mov             fp, SP
    // 0x64e2c8: CheckStackOverflow
    //     0x64e2c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64e2cc: cmp             SP, x16
    //     0x64e2d0: b.ls            #0x64e36c
    // 0x64e2d4: ldr             x1, [fp, #0x18]
    // 0x64e2d8: LoadField: r0 = r1->field_63
    //     0x64e2d8: ldur            w0, [x1, #0x63]
    // 0x64e2dc: DecompressPointer r0
    //     0x64e2dc: add             x0, x0, HEAP, lsl #32
    // 0x64e2e0: cmp             w0, NULL
    // 0x64e2e4: b.eq            #0x64e310
    // 0x64e2e8: r2 = LoadClassIdInstr(r0)
    //     0x64e2e8: ldur            x2, [x0, #-1]
    //     0x64e2ec: ubfx            x2, x2, #0xc, #0x14
    // 0x64e2f0: SaveReg r0
    //     0x64e2f0: str             x0, [SP, #-8]!
    // 0x64e2f4: mov             x0, x2
    // 0x64e2f8: r0 = GDT[cid_x0 + 0x9045]()
    //     0x64e2f8: mov             x17, #0x9045
    //     0x64e2fc: add             lr, x0, x17
    //     0x64e300: ldr             lr, [x21, lr, lsl #3]
    //     0x64e304: blr             lr
    // 0x64e308: add             SP, SP, #8
    // 0x64e30c: ldr             x1, [fp, #0x18]
    // 0x64e310: StoreField: r1->field_77 = rNULL
    //     0x64e310: stur            NULL, [x1, #0x77]
    // 0x64e314: LoadField: r0 = r1->field_67
    //     0x64e314: ldur            w0, [x1, #0x67]
    // 0x64e318: DecompressPointer r0
    //     0x64e318: add             x0, x0, HEAP, lsl #32
    // 0x64e31c: cmp             w0, NULL
    // 0x64e320: b.eq            #0x64e34c
    // 0x64e324: r2 = LoadClassIdInstr(r0)
    //     0x64e324: ldur            x2, [x0, #-1]
    //     0x64e328: ubfx            x2, x2, #0xc, #0x14
    // 0x64e32c: SaveReg r0
    //     0x64e32c: str             x0, [SP, #-8]!
    // 0x64e330: mov             x0, x2
    // 0x64e334: r0 = GDT[cid_x0 + 0x9045]()
    //     0x64e334: mov             x17, #0x9045
    //     0x64e338: add             lr, x0, x17
    //     0x64e33c: ldr             lr, [x21, lr, lsl #3]
    //     0x64e340: blr             lr
    // 0x64e344: add             SP, SP, #8
    // 0x64e348: ldr             x1, [fp, #0x18]
    // 0x64e34c: ldr             x3, [fp, #0x10]
    // 0x64e350: r2 = false
    //     0x64e350: add             x2, NULL, #0x30  ; false
    // 0x64e354: StoreField: r1->field_7b = rNULL
    //     0x64e354: stur            NULL, [x1, #0x7b]
    // 0x64e358: StoreField: r3->field_7 = r2
    //     0x64e358: stur            w2, [x3, #7]
    // 0x64e35c: r0 = Null
    //     0x64e35c: mov             x0, NULL
    // 0x64e360: LeaveFrame
    //     0x64e360: mov             SP, fp
    //     0x64e364: ldp             fp, lr, [SP], #0x10
    // 0x64e368: ret
    //     0x64e368: ret             
    // 0x64e36c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64e36c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64e370: b               #0x64e2d4
  }
  _ paint(/* No info */) {
    // ** addr: 0x660c70, size: 0xf0
    // 0x660c70: EnterFrame
    //     0x660c70: stp             fp, lr, [SP, #-0x10]!
    //     0x660c74: mov             fp, SP
    // 0x660c78: CheckStackOverflow
    //     0x660c78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x660c7c: cmp             SP, x16
    //     0x660c80: b.ls            #0x660d50
    // 0x660c84: ldr             x0, [fp, #0x20]
    // 0x660c88: LoadField: r1 = r0->field_63
    //     0x660c88: ldur            w1, [x0, #0x63]
    // 0x660c8c: DecompressPointer r1
    //     0x660c8c: add             x1, x1, HEAP, lsl #32
    // 0x660c90: cmp             w1, NULL
    // 0x660c94: b.eq            #0x660cd4
    // 0x660c98: ldr             x16, [fp, #0x18]
    // 0x660c9c: SaveReg r16
    //     0x660c9c: str             x16, [SP, #-8]!
    // 0x660ca0: r0 = canvas()
    //     0x660ca0: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x660ca4: add             SP, SP, #8
    // 0x660ca8: mov             x1, x0
    // 0x660cac: ldr             x0, [fp, #0x20]
    // 0x660cb0: LoadField: r2 = r0->field_63
    //     0x660cb0: ldur            w2, [x0, #0x63]
    // 0x660cb4: DecompressPointer r2
    //     0x660cb4: add             x2, x2, HEAP, lsl #32
    // 0x660cb8: cmp             w2, NULL
    // 0x660cbc: b.eq            #0x660d58
    // 0x660cc0: stp             x1, x0, [SP, #-0x10]!
    // 0x660cc4: ldr             x16, [fp, #0x10]
    // 0x660cc8: stp             x2, x16, [SP, #-0x10]!
    // 0x660ccc: r0 = _paintWithPainter()
    //     0x660ccc: bl              #0x660d60  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::_paintWithPainter
    // 0x660cd0: add             SP, SP, #0x20
    // 0x660cd4: ldr             x0, [fp, #0x20]
    // 0x660cd8: ldr             x16, [fp, #0x18]
    // 0x660cdc: stp             x16, x0, [SP, #-0x10]!
    // 0x660ce0: ldr             x16, [fp, #0x10]
    // 0x660ce4: SaveReg r16
    //     0x660ce4: str             x16, [SP, #-8]!
    // 0x660ce8: r0 = paint()
    //     0x660ce8: bl              #0x669ddc  ; [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::paint
    // 0x660cec: add             SP, SP, #0x18
    // 0x660cf0: ldr             x0, [fp, #0x20]
    // 0x660cf4: LoadField: r1 = r0->field_67
    //     0x660cf4: ldur            w1, [x0, #0x67]
    // 0x660cf8: DecompressPointer r1
    //     0x660cf8: add             x1, x1, HEAP, lsl #32
    // 0x660cfc: cmp             w1, NULL
    // 0x660d00: b.eq            #0x660d40
    // 0x660d04: ldr             x16, [fp, #0x18]
    // 0x660d08: SaveReg r16
    //     0x660d08: str             x16, [SP, #-8]!
    // 0x660d0c: r0 = canvas()
    //     0x660d0c: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x660d10: add             SP, SP, #8
    // 0x660d14: mov             x1, x0
    // 0x660d18: ldr             x0, [fp, #0x20]
    // 0x660d1c: LoadField: r2 = r0->field_67
    //     0x660d1c: ldur            w2, [x0, #0x67]
    // 0x660d20: DecompressPointer r2
    //     0x660d20: add             x2, x2, HEAP, lsl #32
    // 0x660d24: cmp             w2, NULL
    // 0x660d28: b.eq            #0x660d5c
    // 0x660d2c: stp             x1, x0, [SP, #-0x10]!
    // 0x660d30: ldr             x16, [fp, #0x10]
    // 0x660d34: stp             x2, x16, [SP, #-0x10]!
    // 0x660d38: r0 = _paintWithPainter()
    //     0x660d38: bl              #0x660d60  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::_paintWithPainter
    // 0x660d3c: add             SP, SP, #0x20
    // 0x660d40: r0 = Null
    //     0x660d40: mov             x0, NULL
    // 0x660d44: LeaveFrame
    //     0x660d44: mov             SP, fp
    //     0x660d48: ldp             fp, lr, [SP], #0x10
    // 0x660d4c: ret
    //     0x660d4c: ret             
    // 0x660d50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x660d50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x660d54: b               #0x660c84
    // 0x660d58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x660d58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x660d5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x660d5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _paintWithPainter(/* No info */) {
    // ** addr: 0x660d60, size: 0x104
    // 0x660d60: EnterFrame
    //     0x660d60: stp             fp, lr, [SP, #-0x10]!
    //     0x660d64: mov             fp, SP
    // 0x660d68: CheckStackOverflow
    //     0x660d68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x660d6c: cmp             SP, x16
    //     0x660d70: b.ls            #0x660e48
    // 0x660d74: ldr             x16, [fp, #0x20]
    // 0x660d78: SaveReg r16
    //     0x660d78: str             x16, [SP, #-8]!
    // 0x660d7c: r0 = save()
    //     0x660d7c: bl              #0x6595b0  ; [dart:ui] Canvas::save
    // 0x660d80: add             SP, SP, #8
    // 0x660d84: ldr             x16, [fp, #0x18]
    // 0x660d88: r30 = Instance_Offset
    //     0x660d88: ldr             lr, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x660d8c: stp             lr, x16, [SP, #-0x10]!
    // 0x660d90: r0 = ==()
    //     0x660d90: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0x660d94: add             SP, SP, #0x10
    // 0x660d98: tbz             w0, #4, #0x660de4
    // 0x660d9c: ldr             x0, [fp, #0x18]
    // 0x660da0: LoadField: d0 = r0->field_7
    //     0x660da0: ldur            d0, [x0, #7]
    // 0x660da4: LoadField: d1 = r0->field_f
    //     0x660da4: ldur            d1, [x0, #0xf]
    // 0x660da8: r0 = inline_Allocate_Double()
    //     0x660da8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x660dac: add             x0, x0, #0x10
    //     0x660db0: cmp             x1, x0
    //     0x660db4: b.ls            #0x660e50
    //     0x660db8: str             x0, [THR, #0x60]  ; THR::top
    //     0x660dbc: sub             x0, x0, #0xf
    //     0x660dc0: mov             x1, #0xd108
    //     0x660dc4: movk            x1, #3, lsl #16
    //     0x660dc8: stur            x1, [x0, #-1]
    // 0x660dcc: StoreField: r0->field_7 = d0
    //     0x660dcc: stur            d0, [x0, #7]
    // 0x660dd0: ldr             x16, [fp, #0x20]
    // 0x660dd4: stp             x0, x16, [SP, #-0x10]!
    // 0x660dd8: SaveReg d1
    //     0x660dd8: str             d1, [SP, #-8]!
    // 0x660ddc: r0 = translate()
    //     0x660ddc: bl              #0x6566d0  ; [dart:ui] Canvas::translate
    // 0x660de0: add             SP, SP, #0x18
    // 0x660de4: ldr             x1, [fp, #0x28]
    // 0x660de8: ldr             x0, [fp, #0x10]
    // 0x660dec: LoadField: r2 = r1->field_57
    //     0x660dec: ldur            w2, [x1, #0x57]
    // 0x660df0: DecompressPointer r2
    //     0x660df0: add             x2, x2, HEAP, lsl #32
    // 0x660df4: cmp             w2, NULL
    // 0x660df8: b.eq            #0x660e60
    // 0x660dfc: r1 = LoadClassIdInstr(r0)
    //     0x660dfc: ldur            x1, [x0, #-1]
    //     0x660e00: ubfx            x1, x1, #0xc, #0x14
    // 0x660e04: ldr             x16, [fp, #0x20]
    // 0x660e08: stp             x16, x0, [SP, #-0x10]!
    // 0x660e0c: SaveReg r2
    //     0x660e0c: str             x2, [SP, #-8]!
    // 0x660e10: mov             x0, x1
    // 0x660e14: r0 = GDT[cid_x0 + 0x9afd]()
    //     0x660e14: mov             x17, #0x9afd
    //     0x660e18: add             lr, x0, x17
    //     0x660e1c: ldr             lr, [x21, lr, lsl #3]
    //     0x660e20: blr             lr
    // 0x660e24: add             SP, SP, #0x18
    // 0x660e28: ldr             x16, [fp, #0x20]
    // 0x660e2c: SaveReg r16
    //     0x660e2c: str             x16, [SP, #-8]!
    // 0x660e30: r0 = restore()
    //     0x660e30: bl              #0x65586c  ; [dart:ui] Canvas::restore
    // 0x660e34: add             SP, SP, #8
    // 0x660e38: r0 = Null
    //     0x660e38: mov             x0, NULL
    // 0x660e3c: LeaveFrame
    //     0x660e3c: mov             SP, fp
    //     0x660e40: ldp             fp, lr, [SP], #0x10
    // 0x660e44: ret
    //     0x660e44: ret             
    // 0x660e48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x660e48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x660e4c: b               #0x660d74
    // 0x660e50: stp             q0, q1, [SP, #-0x20]!
    // 0x660e54: r0 = AllocateDouble()
    //     0x660e54: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x660e58: ldp             q0, q1, [SP], #0x20
    // 0x660e5c: b               #0x660dcc
    // 0x660e60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x660e60: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x68f0d4, size: 0x4c
    // 0x68f0d4: EnterFrame
    //     0x68f0d4: stp             fp, lr, [SP, #-0x10]!
    //     0x68f0d8: mov             fp, SP
    // 0x68f0dc: CheckStackOverflow
    //     0x68f0dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68f0e0: cmp             SP, x16
    //     0x68f0e4: b.ls            #0x68f118
    // 0x68f0e8: ldr             x16, [fp, #0x10]
    // 0x68f0ec: SaveReg r16
    //     0x68f0ec: str             x16, [SP, #-8]!
    // 0x68f0f0: r0 = performLayout()
    //     0x68f0f0: bl              #0x68fff8  ; [package:flutter/src/rendering/proxy_box.dart] _RenderProxyBox&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::performLayout
    // 0x68f0f4: add             SP, SP, #8
    // 0x68f0f8: ldr             x16, [fp, #0x10]
    // 0x68f0fc: SaveReg r16
    //     0x68f0fc: str             x16, [SP, #-8]!
    // 0x68f100: r0 = markNeedsSemanticsUpdate()
    //     0x68f100: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x68f104: add             SP, SP, #8
    // 0x68f108: r0 = Null
    //     0x68f108: mov             x0, NULL
    // 0x68f10c: LeaveFrame
    //     0x68f10c: mov             SP, fp
    //     0x68f110: ldp             fp, lr, [SP], #0x10
    // 0x68f114: ret
    //     0x68f114: ret             
    // 0x68f118: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68f118: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68f11c: b               #0x68f0e8
  }
  set _ foregroundPainter=(/* No info */) {
    // ** addr: 0x6c11a4, size: 0xb0
    // 0x6c11a4: EnterFrame
    //     0x6c11a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6c11a8: mov             fp, SP
    // 0x6c11ac: CheckStackOverflow
    //     0x6c11ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c11b0: cmp             SP, x16
    //     0x6c11b4: b.ls            #0x6c124c
    // 0x6c11b8: ldr             x1, [fp, #0x18]
    // 0x6c11bc: LoadField: r0 = r1->field_67
    //     0x6c11bc: ldur            w0, [x1, #0x67]
    // 0x6c11c0: DecompressPointer r0
    //     0x6c11c0: add             x0, x0, HEAP, lsl #32
    // 0x6c11c4: r2 = LoadClassIdInstr(r0)
    //     0x6c11c4: ldur            x2, [x0, #-1]
    //     0x6c11c8: ubfx            x2, x2, #0xc, #0x14
    // 0x6c11cc: ldr             x16, [fp, #0x10]
    // 0x6c11d0: stp             x16, x0, [SP, #-0x10]!
    // 0x6c11d4: mov             x0, x2
    // 0x6c11d8: mov             lr, x0
    // 0x6c11dc: ldr             lr, [x21, lr, lsl #3]
    // 0x6c11e0: blr             lr
    // 0x6c11e4: add             SP, SP, #0x10
    // 0x6c11e8: tbnz            w0, #4, #0x6c11fc
    // 0x6c11ec: r0 = Null
    //     0x6c11ec: mov             x0, NULL
    // 0x6c11f0: LeaveFrame
    //     0x6c11f0: mov             SP, fp
    //     0x6c11f4: ldp             fp, lr, [SP], #0x10
    // 0x6c11f8: ret
    //     0x6c11f8: ret             
    // 0x6c11fc: ldr             x1, [fp, #0x18]
    // 0x6c1200: LoadField: r2 = r1->field_67
    //     0x6c1200: ldur            w2, [x1, #0x67]
    // 0x6c1204: DecompressPointer r2
    //     0x6c1204: add             x2, x2, HEAP, lsl #32
    // 0x6c1208: ldr             x0, [fp, #0x10]
    // 0x6c120c: StoreField: r1->field_67 = r0
    //     0x6c120c: stur            w0, [x1, #0x67]
    //     0x6c1210: ldurb           w16, [x1, #-1]
    //     0x6c1214: ldurb           w17, [x0, #-1]
    //     0x6c1218: and             x16, x17, x16, lsr #2
    //     0x6c121c: tst             x16, HEAP, lsr #32
    //     0x6c1220: b.eq            #0x6c1228
    //     0x6c1224: bl              #0xd6826c
    // 0x6c1228: ldr             x16, [fp, #0x10]
    // 0x6c122c: stp             x16, x1, [SP, #-0x10]!
    // 0x6c1230: SaveReg r2
    //     0x6c1230: str             x2, [SP, #-8]!
    // 0x6c1234: r0 = _didUpdatePainter()
    //     0x6c1234: bl              #0x6c1254  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::_didUpdatePainter
    // 0x6c1238: add             SP, SP, #0x18
    // 0x6c123c: r0 = Null
    //     0x6c123c: mov             x0, NULL
    // 0x6c1240: LeaveFrame
    //     0x6c1240: mov             SP, fp
    //     0x6c1244: ldp             fp, lr, [SP], #0x10
    // 0x6c1248: ret
    //     0x6c1248: ret             
    // 0x6c124c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c124c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c1250: b               #0x6c11b8
  }
  _ _didUpdatePainter(/* No info */) {
    // ** addr: 0x6c1254, size: 0x200
    // 0x6c1254: EnterFrame
    //     0x6c1254: stp             fp, lr, [SP, #-0x10]!
    //     0x6c1258: mov             fp, SP
    // 0x6c125c: CheckStackOverflow
    //     0x6c125c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c1260: cmp             SP, x16
    //     0x6c1264: b.ls            #0x6c144c
    // 0x6c1268: ldr             x0, [fp, #0x18]
    // 0x6c126c: cmp             w0, NULL
    // 0x6c1270: b.ne            #0x6c1288
    // 0x6c1274: ldr             x16, [fp, #0x20]
    // 0x6c1278: SaveReg r16
    //     0x6c1278: str             x16, [SP, #-8]!
    // 0x6c127c: r0 = markNeedsPaint()
    //     0x6c127c: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c1280: add             SP, SP, #8
    // 0x6c1284: b               #0x6c12e4
    // 0x6c1288: ldr             x0, [fp, #0x10]
    // 0x6c128c: cmp             w0, NULL
    // 0x6c1290: b.eq            #0x6c12d4
    // 0x6c1294: ldr             x16, [fp, #0x18]
    // 0x6c1298: stp             x0, x16, [SP, #-0x10]!
    // 0x6c129c: r0 = _haveSameRuntimeType()
    //     0x6c129c: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0x6c12a0: add             SP, SP, #0x10
    // 0x6c12a4: tbnz            w0, #4, #0x6c12d4
    // 0x6c12a8: ldr             x1, [fp, #0x18]
    // 0x6c12ac: r0 = LoadClassIdInstr(r1)
    //     0x6c12ac: ldur            x0, [x1, #-1]
    //     0x6c12b0: ubfx            x0, x0, #0xc, #0x14
    // 0x6c12b4: ldr             x16, [fp, #0x10]
    // 0x6c12b8: stp             x16, x1, [SP, #-0x10]!
    // 0x6c12bc: r0 = GDT[cid_x0 + 0x8fdf]()
    //     0x6c12bc: mov             x17, #0x8fdf
    //     0x6c12c0: add             lr, x0, x17
    //     0x6c12c4: ldr             lr, [x21, lr, lsl #3]
    //     0x6c12c8: blr             lr
    // 0x6c12cc: add             SP, SP, #0x10
    // 0x6c12d0: tbnz            w0, #4, #0x6c12e4
    // 0x6c12d4: ldr             x16, [fp, #0x20]
    // 0x6c12d8: SaveReg r16
    //     0x6c12d8: str             x16, [SP, #-8]!
    // 0x6c12dc: r0 = markNeedsPaint()
    //     0x6c12dc: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6c12e0: add             SP, SP, #8
    // 0x6c12e4: ldr             x0, [fp, #0x20]
    // 0x6c12e8: LoadField: r1 = r0->field_f
    //     0x6c12e8: ldur            w1, [x0, #0xf]
    // 0x6c12ec: DecompressPointer r1
    //     0x6c12ec: add             x1, x1, HEAP, lsl #32
    // 0x6c12f0: cmp             w1, NULL
    // 0x6c12f4: b.eq            #0x6c13ac
    // 0x6c12f8: ldr             x1, [fp, #0x10]
    // 0x6c12fc: cmp             w1, NULL
    // 0x6c1300: b.eq            #0x6c1350
    // 0x6c1304: r1 = 1
    //     0x6c1304: mov             x1, #1
    // 0x6c1308: r0 = AllocateContext()
    //     0x6c1308: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6c130c: mov             x1, x0
    // 0x6c1310: ldr             x0, [fp, #0x20]
    // 0x6c1314: StoreField: r1->field_f = r0
    //     0x6c1314: stur            w0, [x1, #0xf]
    // 0x6c1318: mov             x2, x1
    // 0x6c131c: r1 = Function 'markNeedsPaint':.
    //     0x6c131c: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x6c1320: ldr             x1, [x1, #0xf60]
    // 0x6c1324: r0 = AllocateClosure()
    //     0x6c1324: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6c1328: ldr             x1, [fp, #0x10]
    // 0x6c132c: r2 = LoadClassIdInstr(r1)
    //     0x6c132c: ldur            x2, [x1, #-1]
    //     0x6c1330: ubfx            x2, x2, #0xc, #0x14
    // 0x6c1334: stp             x0, x1, [SP, #-0x10]!
    // 0x6c1338: mov             x0, x2
    // 0x6c133c: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0x6c133c: mov             x17, #0xc2d6
    //     0x6c1340: add             lr, x0, x17
    //     0x6c1344: ldr             lr, [x21, lr, lsl #3]
    //     0x6c1348: blr             lr
    // 0x6c134c: add             SP, SP, #0x10
    // 0x6c1350: ldr             x0, [fp, #0x18]
    // 0x6c1354: cmp             w0, NULL
    // 0x6c1358: b.eq            #0x6c13ac
    // 0x6c135c: ldr             x1, [fp, #0x20]
    // 0x6c1360: r1 = 1
    //     0x6c1360: mov             x1, #1
    // 0x6c1364: r0 = AllocateContext()
    //     0x6c1364: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6c1368: mov             x1, x0
    // 0x6c136c: ldr             x0, [fp, #0x20]
    // 0x6c1370: StoreField: r1->field_f = r0
    //     0x6c1370: stur            w0, [x1, #0xf]
    // 0x6c1374: mov             x2, x1
    // 0x6c1378: r1 = Function 'markNeedsPaint':.
    //     0x6c1378: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x6c137c: ldr             x1, [x1, #0xf60]
    // 0x6c1380: r0 = AllocateClosure()
    //     0x6c1380: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6c1384: ldr             x1, [fp, #0x18]
    // 0x6c1388: r2 = LoadClassIdInstr(r1)
    //     0x6c1388: ldur            x2, [x1, #-1]
    //     0x6c138c: ubfx            x2, x2, #0xc, #0x14
    // 0x6c1390: stp             x0, x1, [SP, #-0x10]!
    // 0x6c1394: mov             x0, x2
    // 0x6c1398: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x6c1398: mov             x17, #0xc3ab
    //     0x6c139c: add             lr, x0, x17
    //     0x6c13a0: ldr             lr, [x21, lr, lsl #3]
    //     0x6c13a4: blr             lr
    // 0x6c13a8: add             SP, SP, #0x10
    // 0x6c13ac: ldr             x0, [fp, #0x18]
    // 0x6c13b0: cmp             w0, NULL
    // 0x6c13b4: b.ne            #0x6c13dc
    // 0x6c13b8: ldr             x1, [fp, #0x20]
    // 0x6c13bc: LoadField: r0 = r1->field_f
    //     0x6c13bc: ldur            w0, [x1, #0xf]
    // 0x6c13c0: DecompressPointer r0
    //     0x6c13c0: add             x0, x0, HEAP, lsl #32
    // 0x6c13c4: cmp             w0, NULL
    // 0x6c13c8: b.eq            #0x6c143c
    // 0x6c13cc: SaveReg r1
    //     0x6c13cc: str             x1, [SP, #-8]!
    // 0x6c13d0: r0 = markNeedsSemanticsUpdate()
    //     0x6c13d0: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6c13d4: add             SP, SP, #8
    // 0x6c13d8: b               #0x6c143c
    // 0x6c13dc: ldr             x1, [fp, #0x20]
    // 0x6c13e0: ldr             x2, [fp, #0x10]
    // 0x6c13e4: cmp             w2, NULL
    // 0x6c13e8: b.eq            #0x6c142c
    // 0x6c13ec: stp             x2, x0, [SP, #-0x10]!
    // 0x6c13f0: r0 = _haveSameRuntimeType()
    //     0x6c13f0: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0x6c13f4: add             SP, SP, #0x10
    // 0x6c13f8: tbnz            w0, #4, #0x6c142c
    // 0x6c13fc: ldr             x0, [fp, #0x18]
    // 0x6c1400: r1 = LoadClassIdInstr(r0)
    //     0x6c1400: ldur            x1, [x0, #-1]
    //     0x6c1404: ubfx            x1, x1, #0xc, #0x14
    // 0x6c1408: ldr             x16, [fp, #0x10]
    // 0x6c140c: stp             x16, x0, [SP, #-0x10]!
    // 0x6c1410: mov             x0, x1
    // 0x6c1414: r0 = GDT[cid_x0 + 0xb949]()
    //     0x6c1414: mov             x17, #0xb949
    //     0x6c1418: add             lr, x0, x17
    //     0x6c141c: ldr             lr, [x21, lr, lsl #3]
    //     0x6c1420: blr             lr
    // 0x6c1424: add             SP, SP, #0x10
    // 0x6c1428: tbnz            w0, #4, #0x6c143c
    // 0x6c142c: ldr             x16, [fp, #0x20]
    // 0x6c1430: SaveReg r16
    //     0x6c1430: str             x16, [SP, #-8]!
    // 0x6c1434: r0 = markNeedsSemanticsUpdate()
    //     0x6c1434: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6c1438: add             SP, SP, #8
    // 0x6c143c: r0 = Null
    //     0x6c143c: mov             x0, NULL
    // 0x6c1440: LeaveFrame
    //     0x6c1440: mov             SP, fp
    //     0x6c1444: ldp             fp, lr, [SP], #0x10
    // 0x6c1448: ret
    //     0x6c1448: ret             
    // 0x6c144c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c144c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c1450: b               #0x6c1268
  }
  set _ painter=(/* No info */) {
    // ** addr: 0x6c1454, size: 0xb0
    // 0x6c1454: EnterFrame
    //     0x6c1454: stp             fp, lr, [SP, #-0x10]!
    //     0x6c1458: mov             fp, SP
    // 0x6c145c: CheckStackOverflow
    //     0x6c145c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c1460: cmp             SP, x16
    //     0x6c1464: b.ls            #0x6c14fc
    // 0x6c1468: ldr             x1, [fp, #0x18]
    // 0x6c146c: LoadField: r0 = r1->field_63
    //     0x6c146c: ldur            w0, [x1, #0x63]
    // 0x6c1470: DecompressPointer r0
    //     0x6c1470: add             x0, x0, HEAP, lsl #32
    // 0x6c1474: r2 = LoadClassIdInstr(r0)
    //     0x6c1474: ldur            x2, [x0, #-1]
    //     0x6c1478: ubfx            x2, x2, #0xc, #0x14
    // 0x6c147c: ldr             x16, [fp, #0x10]
    // 0x6c1480: stp             x16, x0, [SP, #-0x10]!
    // 0x6c1484: mov             x0, x2
    // 0x6c1488: mov             lr, x0
    // 0x6c148c: ldr             lr, [x21, lr, lsl #3]
    // 0x6c1490: blr             lr
    // 0x6c1494: add             SP, SP, #0x10
    // 0x6c1498: tbnz            w0, #4, #0x6c14ac
    // 0x6c149c: r0 = Null
    //     0x6c149c: mov             x0, NULL
    // 0x6c14a0: LeaveFrame
    //     0x6c14a0: mov             SP, fp
    //     0x6c14a4: ldp             fp, lr, [SP], #0x10
    // 0x6c14a8: ret
    //     0x6c14a8: ret             
    // 0x6c14ac: ldr             x1, [fp, #0x18]
    // 0x6c14b0: LoadField: r2 = r1->field_63
    //     0x6c14b0: ldur            w2, [x1, #0x63]
    // 0x6c14b4: DecompressPointer r2
    //     0x6c14b4: add             x2, x2, HEAP, lsl #32
    // 0x6c14b8: ldr             x0, [fp, #0x10]
    // 0x6c14bc: StoreField: r1->field_63 = r0
    //     0x6c14bc: stur            w0, [x1, #0x63]
    //     0x6c14c0: ldurb           w16, [x1, #-1]
    //     0x6c14c4: ldurb           w17, [x0, #-1]
    //     0x6c14c8: and             x16, x17, x16, lsr #2
    //     0x6c14cc: tst             x16, HEAP, lsr #32
    //     0x6c14d0: b.eq            #0x6c14d8
    //     0x6c14d4: bl              #0xd6826c
    // 0x6c14d8: ldr             x16, [fp, #0x10]
    // 0x6c14dc: stp             x16, x1, [SP, #-0x10]!
    // 0x6c14e0: SaveReg r2
    //     0x6c14e0: str             x2, [SP, #-8]!
    // 0x6c14e4: r0 = _didUpdatePainter()
    //     0x6c14e4: bl              #0x6c1254  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::_didUpdatePainter
    // 0x6c14e8: add             SP, SP, #0x18
    // 0x6c14ec: r0 = Null
    //     0x6c14ec: mov             x0, NULL
    // 0x6c14f0: LeaveFrame
    //     0x6c14f0: mov             SP, fp
    //     0x6c14f4: ldp             fp, lr, [SP], #0x10
    // 0x6c14f8: ret
    //     0x6c14f8: ret             
    // 0x6c14fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c14fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c1500: b               #0x6c1468
  }
  set _ preferredSize=(/* No info */) {
    // ** addr: 0x6c3ae4, size: 0xa0
    // 0x6c3ae4: EnterFrame
    //     0x6c3ae4: stp             fp, lr, [SP, #-0x10]!
    //     0x6c3ae8: mov             fp, SP
    // 0x6c3aec: CheckStackOverflow
    //     0x6c3aec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c3af0: cmp             SP, x16
    //     0x6c3af4: b.ls            #0x6c3b7c
    // 0x6c3af8: ldr             x1, [fp, #0x18]
    // 0x6c3afc: LoadField: r0 = r1->field_6b
    //     0x6c3afc: ldur            w0, [x1, #0x6b]
    // 0x6c3b00: DecompressPointer r0
    //     0x6c3b00: add             x0, x0, HEAP, lsl #32
    // 0x6c3b04: ldr             x2, [fp, #0x10]
    // 0x6c3b08: LoadField: d0 = r2->field_7
    //     0x6c3b08: ldur            d0, [x2, #7]
    // 0x6c3b0c: LoadField: d1 = r0->field_7
    //     0x6c3b0c: ldur            d1, [x0, #7]
    // 0x6c3b10: fcmp            d0, d1
    // 0x6c3b14: b.vs            #0x6c3b40
    // 0x6c3b18: b.ne            #0x6c3b40
    // 0x6c3b1c: LoadField: d0 = r2->field_f
    //     0x6c3b1c: ldur            d0, [x2, #0xf]
    // 0x6c3b20: LoadField: d1 = r0->field_f
    //     0x6c3b20: ldur            d1, [x0, #0xf]
    // 0x6c3b24: fcmp            d0, d1
    // 0x6c3b28: b.vs            #0x6c3b40
    // 0x6c3b2c: b.ne            #0x6c3b40
    // 0x6c3b30: r0 = Null
    //     0x6c3b30: mov             x0, NULL
    // 0x6c3b34: LeaveFrame
    //     0x6c3b34: mov             SP, fp
    //     0x6c3b38: ldp             fp, lr, [SP], #0x10
    // 0x6c3b3c: ret
    //     0x6c3b3c: ret             
    // 0x6c3b40: mov             x0, x2
    // 0x6c3b44: StoreField: r1->field_6b = r0
    //     0x6c3b44: stur            w0, [x1, #0x6b]
    //     0x6c3b48: ldurb           w16, [x1, #-1]
    //     0x6c3b4c: ldurb           w17, [x0, #-1]
    //     0x6c3b50: and             x16, x17, x16, lsr #2
    //     0x6c3b54: tst             x16, HEAP, lsr #32
    //     0x6c3b58: b.eq            #0x6c3b60
    //     0x6c3b5c: bl              #0xd6826c
    // 0x6c3b60: SaveReg r1
    //     0x6c3b60: str             x1, [SP, #-8]!
    // 0x6c3b64: r0 = markNeedsLayout()
    //     0x6c3b64: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c3b68: add             SP, SP, #8
    // 0x6c3b6c: r0 = Null
    //     0x6c3b6c: mov             x0, NULL
    // 0x6c3b70: LeaveFrame
    //     0x6c3b70: mov             SP, fp
    //     0x6c3b74: ldp             fp, lr, [SP], #0x10
    // 0x6c3b78: ret
    //     0x6c3b78: ret             
    // 0x6c3b7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c3b7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c3b80: b               #0x6c3af8
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bd124, size: 0x148
    // 0x9bd124: EnterFrame
    //     0x9bd124: stp             fp, lr, [SP, #-0x10]!
    //     0x9bd128: mov             fp, SP
    // 0x9bd12c: AllocStack(0x8)
    //     0x9bd12c: sub             SP, SP, #8
    // 0x9bd130: CheckStackOverflow
    //     0x9bd130: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bd134: cmp             SP, x16
    //     0x9bd138: b.ls            #0x9bd264
    // 0x9bd13c: ldr             x0, [fp, #0x10]
    // 0x9bd140: r2 = Null
    //     0x9bd140: mov             x2, NULL
    // 0x9bd144: r1 = Null
    //     0x9bd144: mov             x1, NULL
    // 0x9bd148: r4 = 59
    //     0x9bd148: mov             x4, #0x3b
    // 0x9bd14c: branchIfSmi(r0, 0x9bd158)
    //     0x9bd14c: tbz             w0, #0, #0x9bd158
    // 0x9bd150: r4 = LoadClassIdInstr(r0)
    //     0x9bd150: ldur            x4, [x0, #-1]
    //     0x9bd154: ubfx            x4, x4, #0xc, #0x14
    // 0x9bd158: cmp             x4, #0x7e6
    // 0x9bd15c: b.eq            #0x9bd170
    // 0x9bd160: r8 = PipelineOwner
    //     0x9bd160: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9bd164: r3 = Null
    //     0x9bd164: add             x3, PP, #0x29, lsl #12  ; [pp+0x29420] Null
    //     0x9bd168: ldr             x3, [x3, #0x420]
    // 0x9bd16c: r0 = DefaultTypeTest()
    //     0x9bd16c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bd170: ldr             x16, [fp, #0x18]
    // 0x9bd174: ldr             lr, [fp, #0x10]
    // 0x9bd178: stp             lr, x16, [SP, #-0x10]!
    // 0x9bd17c: r0 = attach()
    //     0x9bd17c: bl              #0x9bd674  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::attach
    // 0x9bd180: add             SP, SP, #0x10
    // 0x9bd184: ldr             x0, [fp, #0x18]
    // 0x9bd188: LoadField: r1 = r0->field_63
    //     0x9bd188: ldur            w1, [x0, #0x63]
    // 0x9bd18c: DecompressPointer r1
    //     0x9bd18c: add             x1, x1, HEAP, lsl #32
    // 0x9bd190: stur            x1, [fp, #-8]
    // 0x9bd194: cmp             w1, NULL
    // 0x9bd198: b.eq            #0x9bd1f0
    // 0x9bd19c: r1 = 1
    //     0x9bd19c: mov             x1, #1
    // 0x9bd1a0: r0 = AllocateContext()
    //     0x9bd1a0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9bd1a4: mov             x1, x0
    // 0x9bd1a8: ldr             x0, [fp, #0x18]
    // 0x9bd1ac: StoreField: r1->field_f = r0
    //     0x9bd1ac: stur            w0, [x1, #0xf]
    // 0x9bd1b0: mov             x2, x1
    // 0x9bd1b4: r1 = Function 'markNeedsPaint':.
    //     0x9bd1b4: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x9bd1b8: ldr             x1, [x1, #0xf60]
    // 0x9bd1bc: r0 = AllocateClosure()
    //     0x9bd1bc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9bd1c0: mov             x1, x0
    // 0x9bd1c4: ldur            x0, [fp, #-8]
    // 0x9bd1c8: r2 = LoadClassIdInstr(r0)
    //     0x9bd1c8: ldur            x2, [x0, #-1]
    //     0x9bd1cc: ubfx            x2, x2, #0xc, #0x14
    // 0x9bd1d0: stp             x1, x0, [SP, #-0x10]!
    // 0x9bd1d4: mov             x0, x2
    // 0x9bd1d8: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x9bd1d8: mov             x17, #0xc3ab
    //     0x9bd1dc: add             lr, x0, x17
    //     0x9bd1e0: ldr             lr, [x21, lr, lsl #3]
    //     0x9bd1e4: blr             lr
    // 0x9bd1e8: add             SP, SP, #0x10
    // 0x9bd1ec: ldr             x0, [fp, #0x18]
    // 0x9bd1f0: LoadField: r1 = r0->field_67
    //     0x9bd1f0: ldur            w1, [x0, #0x67]
    // 0x9bd1f4: DecompressPointer r1
    //     0x9bd1f4: add             x1, x1, HEAP, lsl #32
    // 0x9bd1f8: stur            x1, [fp, #-8]
    // 0x9bd1fc: cmp             w1, NULL
    // 0x9bd200: b.eq            #0x9bd254
    // 0x9bd204: r1 = 1
    //     0x9bd204: mov             x1, #1
    // 0x9bd208: r0 = AllocateContext()
    //     0x9bd208: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9bd20c: mov             x1, x0
    // 0x9bd210: ldr             x0, [fp, #0x18]
    // 0x9bd214: StoreField: r1->field_f = r0
    //     0x9bd214: stur            w0, [x1, #0xf]
    // 0x9bd218: mov             x2, x1
    // 0x9bd21c: r1 = Function 'markNeedsPaint':.
    //     0x9bd21c: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x9bd220: ldr             x1, [x1, #0xf60]
    // 0x9bd224: r0 = AllocateClosure()
    //     0x9bd224: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9bd228: mov             x1, x0
    // 0x9bd22c: ldur            x0, [fp, #-8]
    // 0x9bd230: r2 = LoadClassIdInstr(r0)
    //     0x9bd230: ldur            x2, [x0, #-1]
    //     0x9bd234: ubfx            x2, x2, #0xc, #0x14
    // 0x9bd238: stp             x1, x0, [SP, #-0x10]!
    // 0x9bd23c: mov             x0, x2
    // 0x9bd240: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x9bd240: mov             x17, #0xc3ab
    //     0x9bd244: add             lr, x0, x17
    //     0x9bd248: ldr             lr, [x21, lr, lsl #3]
    //     0x9bd24c: blr             lr
    // 0x9bd250: add             SP, SP, #0x10
    // 0x9bd254: r0 = Null
    //     0x9bd254: mov             x0, NULL
    // 0x9bd258: LeaveFrame
    //     0x9bd258: mov             SP, fp
    //     0x9bd25c: ldp             fp, lr, [SP], #0x10
    // 0x9bd260: ret
    //     0x9bd260: ret             
    // 0x9bd264: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bd264: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bd268: b               #0x9bd13c
  }
  _ detach(/* No info */) {
    // ** addr: 0xa68f10, size: 0x110
    // 0xa68f10: EnterFrame
    //     0xa68f10: stp             fp, lr, [SP, #-0x10]!
    //     0xa68f14: mov             fp, SP
    // 0xa68f18: AllocStack(0x8)
    //     0xa68f18: sub             SP, SP, #8
    // 0xa68f1c: CheckStackOverflow
    //     0xa68f1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa68f20: cmp             SP, x16
    //     0xa68f24: b.ls            #0xa69018
    // 0xa68f28: ldr             x0, [fp, #0x10]
    // 0xa68f2c: LoadField: r1 = r0->field_63
    //     0xa68f2c: ldur            w1, [x0, #0x63]
    // 0xa68f30: DecompressPointer r1
    //     0xa68f30: add             x1, x1, HEAP, lsl #32
    // 0xa68f34: stur            x1, [fp, #-8]
    // 0xa68f38: cmp             w1, NULL
    // 0xa68f3c: b.eq            #0xa68f94
    // 0xa68f40: r1 = 1
    //     0xa68f40: mov             x1, #1
    // 0xa68f44: r0 = AllocateContext()
    //     0xa68f44: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa68f48: mov             x1, x0
    // 0xa68f4c: ldr             x0, [fp, #0x10]
    // 0xa68f50: StoreField: r1->field_f = r0
    //     0xa68f50: stur            w0, [x1, #0xf]
    // 0xa68f54: mov             x2, x1
    // 0xa68f58: r1 = Function 'markNeedsPaint':.
    //     0xa68f58: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0xa68f5c: ldr             x1, [x1, #0xf60]
    // 0xa68f60: r0 = AllocateClosure()
    //     0xa68f60: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa68f64: mov             x1, x0
    // 0xa68f68: ldur            x0, [fp, #-8]
    // 0xa68f6c: r2 = LoadClassIdInstr(r0)
    //     0xa68f6c: ldur            x2, [x0, #-1]
    //     0xa68f70: ubfx            x2, x2, #0xc, #0x14
    // 0xa68f74: stp             x1, x0, [SP, #-0x10]!
    // 0xa68f78: mov             x0, x2
    // 0xa68f7c: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0xa68f7c: mov             x17, #0xc2d6
    //     0xa68f80: add             lr, x0, x17
    //     0xa68f84: ldr             lr, [x21, lr, lsl #3]
    //     0xa68f88: blr             lr
    // 0xa68f8c: add             SP, SP, #0x10
    // 0xa68f90: ldr             x0, [fp, #0x10]
    // 0xa68f94: LoadField: r1 = r0->field_67
    //     0xa68f94: ldur            w1, [x0, #0x67]
    // 0xa68f98: DecompressPointer r1
    //     0xa68f98: add             x1, x1, HEAP, lsl #32
    // 0xa68f9c: stur            x1, [fp, #-8]
    // 0xa68fa0: cmp             w1, NULL
    // 0xa68fa4: b.eq            #0xa68ff8
    // 0xa68fa8: r1 = 1
    //     0xa68fa8: mov             x1, #1
    // 0xa68fac: r0 = AllocateContext()
    //     0xa68fac: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa68fb0: mov             x1, x0
    // 0xa68fb4: ldr             x0, [fp, #0x10]
    // 0xa68fb8: StoreField: r1->field_f = r0
    //     0xa68fb8: stur            w0, [x1, #0xf]
    // 0xa68fbc: mov             x2, x1
    // 0xa68fc0: r1 = Function 'markNeedsPaint':.
    //     0xa68fc0: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0xa68fc4: ldr             x1, [x1, #0xf60]
    // 0xa68fc8: r0 = AllocateClosure()
    //     0xa68fc8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa68fcc: mov             x1, x0
    // 0xa68fd0: ldur            x0, [fp, #-8]
    // 0xa68fd4: r2 = LoadClassIdInstr(r0)
    //     0xa68fd4: ldur            x2, [x0, #-1]
    //     0xa68fd8: ubfx            x2, x2, #0xc, #0x14
    // 0xa68fdc: stp             x1, x0, [SP, #-0x10]!
    // 0xa68fe0: mov             x0, x2
    // 0xa68fe4: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0xa68fe4: mov             x17, #0xc2d6
    //     0xa68fe8: add             lr, x0, x17
    //     0xa68fec: ldr             lr, [x21, lr, lsl #3]
    //     0xa68ff0: blr             lr
    // 0xa68ff4: add             SP, SP, #0x10
    // 0xa68ff8: ldr             x16, [fp, #0x10]
    // 0xa68ffc: SaveReg r16
    //     0xa68ffc: str             x16, [SP, #-8]!
    // 0xa69000: r0 = detach()
    //     0xa69000: bl              #0xa693e0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::detach
    // 0xa69004: add             SP, SP, #8
    // 0xa69008: r0 = Null
    //     0xa69008: mov             x0, NULL
    // 0xa6900c: LeaveFrame
    //     0xa6900c: mov             SP, fp
    //     0xa69010: ldp             fp, lr, [SP], #0x10
    // 0xa69014: ret
    //     0xa69014: ret             
    // 0xa69018: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa69018: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6901c: b               #0xa68f28
  }
  _ computeSizeForNoChild(/* No info */) {
    // ** addr: 0xb1b578, size: 0x44
    // 0xb1b578: EnterFrame
    //     0xb1b578: stp             fp, lr, [SP, #-0x10]!
    //     0xb1b57c: mov             fp, SP
    // 0xb1b580: CheckStackOverflow
    //     0xb1b580: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1b584: cmp             SP, x16
    //     0xb1b588: b.ls            #0xb1b5b4
    // 0xb1b58c: ldr             x0, [fp, #0x18]
    // 0xb1b590: LoadField: r1 = r0->field_6b
    //     0xb1b590: ldur            w1, [x0, #0x6b]
    // 0xb1b594: DecompressPointer r1
    //     0xb1b594: add             x1, x1, HEAP, lsl #32
    // 0xb1b598: ldr             x16, [fp, #0x10]
    // 0xb1b59c: stp             x1, x16, [SP, #-0x10]!
    // 0xb1b5a0: r0 = constrain()
    //     0xb1b5a0: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb1b5a4: add             SP, SP, #0x10
    // 0xb1b5a8: LeaveFrame
    //     0xb1b5a8: mov             SP, fp
    //     0xb1b5ac: ldp             fp, lr, [SP], #0x10
    // 0xb1b5b0: ret
    //     0xb1b5b0: ret             
    // 0xb1b5b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1b5b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1b5b8: b               #0xb1b58c
  }
}

// class id: 4361, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class CustomPainter extends Listenable {

  _ addListener(/* No info */) {
    // ** addr: 0x6e888c, size: 0x64
    // 0x6e888c: EnterFrame
    //     0x6e888c: stp             fp, lr, [SP, #-0x10]!
    //     0x6e8890: mov             fp, SP
    // 0x6e8894: CheckStackOverflow
    //     0x6e8894: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e8898: cmp             SP, x16
    //     0x6e889c: b.ls            #0x6e88e8
    // 0x6e88a0: ldr             x0, [fp, #0x18]
    // 0x6e88a4: LoadField: r1 = r0->field_7
    //     0x6e88a4: ldur            w1, [x0, #7]
    // 0x6e88a8: DecompressPointer r1
    //     0x6e88a8: add             x1, x1, HEAP, lsl #32
    // 0x6e88ac: cmp             w1, NULL
    // 0x6e88b0: b.eq            #0x6e88d8
    // 0x6e88b4: r0 = LoadClassIdInstr(r1)
    //     0x6e88b4: ldur            x0, [x1, #-1]
    //     0x6e88b8: ubfx            x0, x0, #0xc, #0x14
    // 0x6e88bc: ldr             x16, [fp, #0x10]
    // 0x6e88c0: stp             x16, x1, [SP, #-0x10]!
    // 0x6e88c4: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x6e88c4: mov             x17, #0xc3ab
    //     0x6e88c8: add             lr, x0, x17
    //     0x6e88cc: ldr             lr, [x21, lr, lsl #3]
    //     0x6e88d0: blr             lr
    // 0x6e88d4: add             SP, SP, #0x10
    // 0x6e88d8: r0 = Null
    //     0x6e88d8: mov             x0, NULL
    // 0x6e88dc: LeaveFrame
    //     0x6e88dc: mov             SP, fp
    //     0x6e88e0: ldp             fp, lr, [SP], #0x10
    // 0x6e88e4: ret
    //     0x6e88e4: ret             
    // 0x6e88e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e88e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e88ec: b               #0x6e88a0
  }
  _ removeListener(/* No info */) {
    // ** addr: 0x6f5d00, size: 0x64
    // 0x6f5d00: EnterFrame
    //     0x6f5d00: stp             fp, lr, [SP, #-0x10]!
    //     0x6f5d04: mov             fp, SP
    // 0x6f5d08: CheckStackOverflow
    //     0x6f5d08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f5d0c: cmp             SP, x16
    //     0x6f5d10: b.ls            #0x6f5d5c
    // 0x6f5d14: ldr             x0, [fp, #0x18]
    // 0x6f5d18: LoadField: r1 = r0->field_7
    //     0x6f5d18: ldur            w1, [x0, #7]
    // 0x6f5d1c: DecompressPointer r1
    //     0x6f5d1c: add             x1, x1, HEAP, lsl #32
    // 0x6f5d20: cmp             w1, NULL
    // 0x6f5d24: b.eq            #0x6f5d4c
    // 0x6f5d28: r0 = LoadClassIdInstr(r1)
    //     0x6f5d28: ldur            x0, [x1, #-1]
    //     0x6f5d2c: ubfx            x0, x0, #0xc, #0x14
    // 0x6f5d30: ldr             x16, [fp, #0x10]
    // 0x6f5d34: stp             x16, x1, [SP, #-0x10]!
    // 0x6f5d38: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0x6f5d38: mov             x17, #0xc2d6
    //     0x6f5d3c: add             lr, x0, x17
    //     0x6f5d40: ldr             lr, [x21, lr, lsl #3]
    //     0x6f5d44: blr             lr
    // 0x6f5d48: add             SP, SP, #0x10
    // 0x6f5d4c: r0 = Null
    //     0x6f5d4c: mov             x0, NULL
    // 0x6f5d50: LeaveFrame
    //     0x6f5d50: mov             SP, fp
    //     0x6f5d54: ldp             fp, lr, [SP], #0x10
    // 0x6f5d58: ret
    //     0x6f5d58: ret             
    // 0x6f5d5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f5d5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f5d60: b               #0x6f5d14
  }
  _ shouldRebuildSemantics(/* No info */) {
    // ** addr: 0x781ff4, size: 0x54
    // 0x781ff4: EnterFrame
    //     0x781ff4: stp             fp, lr, [SP, #-0x10]!
    //     0x781ff8: mov             fp, SP
    // 0x781ffc: CheckStackOverflow
    //     0x781ffc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x782000: cmp             SP, x16
    //     0x782004: b.ls            #0x782040
    // 0x782008: ldr             x0, [fp, #0x18]
    // 0x78200c: r1 = LoadClassIdInstr(r0)
    //     0x78200c: ldur            x1, [x0, #-1]
    //     0x782010: ubfx            x1, x1, #0xc, #0x14
    // 0x782014: ldr             x16, [fp, #0x10]
    // 0x782018: stp             x16, x0, [SP, #-0x10]!
    // 0x78201c: mov             x0, x1
    // 0x782020: r0 = GDT[cid_x0 + 0x8fdf]()
    //     0x782020: mov             x17, #0x8fdf
    //     0x782024: add             lr, x0, x17
    //     0x782028: ldr             lr, [x21, lr, lsl #3]
    //     0x78202c: blr             lr
    // 0x782030: add             SP, SP, #0x10
    // 0x782034: LeaveFrame
    //     0x782034: mov             SP, fp
    //     0x782038: ldp             fp, lr, [SP], #0x10
    // 0x78203c: ret
    //     0x78203c: ret             
    // 0x782040: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x782040: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x782044: b               #0x782008
  }
  _ toString(/* No info */) {
    // ** addr: 0xad4488, size: 0xf0
    // 0xad4488: EnterFrame
    //     0xad4488: stp             fp, lr, [SP, #-0x10]!
    //     0xad448c: mov             fp, SP
    // 0xad4490: AllocStack(0x10)
    //     0xad4490: sub             SP, SP, #0x10
    // 0xad4494: CheckStackOverflow
    //     0xad4494: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad4498: cmp             SP, x16
    //     0xad449c: b.ls            #0xad4570
    // 0xad44a0: ldr             x16, [fp, #0x10]
    // 0xad44a4: SaveReg r16
    //     0xad44a4: str             x16, [SP, #-8]!
    // 0xad44a8: r0 = describeIdentity()
    //     0xad44a8: bl              #0xa77c6c  ; [package:flutter/src/foundation/diagnostics.dart] ::describeIdentity
    // 0xad44ac: add             SP, SP, #8
    // 0xad44b0: r1 = Null
    //     0xad44b0: mov             x1, NULL
    // 0xad44b4: r2 = 8
    //     0xad44b4: mov             x2, #8
    // 0xad44b8: stur            x0, [fp, #-8]
    // 0xad44bc: r0 = AllocateArray()
    //     0xad44bc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad44c0: mov             x1, x0
    // 0xad44c4: ldur            x0, [fp, #-8]
    // 0xad44c8: stur            x1, [fp, #-0x10]
    // 0xad44cc: StoreField: r1->field_f = r0
    //     0xad44cc: stur            w0, [x1, #0xf]
    // 0xad44d0: r17 = "("
    //     0xad44d0: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad44d4: StoreField: r1->field_13 = r17
    //     0xad44d4: stur            w17, [x1, #0x13]
    // 0xad44d8: ldr             x0, [fp, #0x10]
    // 0xad44dc: LoadField: r2 = r0->field_7
    //     0xad44dc: ldur            w2, [x0, #7]
    // 0xad44e0: DecompressPointer r2
    //     0xad44e0: add             x2, x2, HEAP, lsl #32
    // 0xad44e4: cmp             w2, NULL
    // 0xad44e8: b.ne            #0xad44f4
    // 0xad44ec: r0 = Null
    //     0xad44ec: mov             x0, NULL
    // 0xad44f0: b               #0xad4518
    // 0xad44f4: r0 = LoadClassIdInstr(r2)
    //     0xad44f4: ldur            x0, [x2, #-1]
    //     0xad44f8: ubfx            x0, x0, #0xc, #0x14
    // 0xad44fc: SaveReg r2
    //     0xad44fc: str             x2, [SP, #-8]!
    // 0xad4500: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xad4500: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xad4504: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xad4504: mov             x17, #0x3f73
    //     0xad4508: add             lr, x0, x17
    //     0xad450c: ldr             lr, [x21, lr, lsl #3]
    //     0xad4510: blr             lr
    // 0xad4514: add             SP, SP, #8
    // 0xad4518: cmp             w0, NULL
    // 0xad451c: b.ne            #0xad4524
    // 0xad4520: r0 = ""
    //     0xad4520: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xad4524: ldur            x2, [fp, #-0x10]
    // 0xad4528: mov             x1, x2
    // 0xad452c: ArrayStore: r1[2] = r0  ; List_4
    //     0xad452c: add             x25, x1, #0x17
    //     0xad4530: str             w0, [x25]
    //     0xad4534: tbz             w0, #0, #0xad4550
    //     0xad4538: ldurb           w16, [x1, #-1]
    //     0xad453c: ldurb           w17, [x0, #-1]
    //     0xad4540: and             x16, x17, x16, lsr #2
    //     0xad4544: tst             x16, HEAP, lsr #32
    //     0xad4548: b.eq            #0xad4550
    //     0xad454c: bl              #0xd67e5c
    // 0xad4550: r17 = ")"
    //     0xad4550: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad4554: StoreField: r2->field_1b = r17
    //     0xad4554: stur            w17, [x2, #0x1b]
    // 0xad4558: SaveReg r2
    //     0xad4558: str             x2, [SP, #-8]!
    // 0xad455c: r0 = _interpolate()
    //     0xad455c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad4560: add             SP, SP, #8
    // 0xad4564: LeaveFrame
    //     0xad4564: mov             SP, fp
    //     0xad4568: ldp             fp, lr, [SP], #0x10
    // 0xad456c: ret
    //     0xad456c: ret             
    // 0xad4570: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad4570: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad4574: b               #0xad44a0
  }
}

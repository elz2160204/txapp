// lib: , url: package:flutter/src/rendering/sliver.dart

// class id: 1049420, size: 0x8
class :: {

  static _ applyGrowthDirectionToAxisDirection(/* No info */) {
    // ** addr: 0x643194, size: 0x68
    // 0x643194: ldr             x1, [SP]
    // 0x643198: LoadField: r2 = r1->field_7
    //     0x643198: ldur            x2, [x1, #7]
    // 0x64319c: cmp             x2, #0
    // 0x6431a0: b.gt            #0x6431ac
    // 0x6431a4: ldr             x0, [SP, #8]
    // 0x6431a8: ret
    //     0x6431a8: ret             
    // 0x6431ac: ldr             x1, [SP, #8]
    // 0x6431b0: LoadField: r2 = r1->field_7
    //     0x6431b0: ldur            x2, [x1, #7]
    // 0x6431b4: cmp             x2, #1
    // 0x6431b8: b.gt            #0x6431dc
    // 0x6431bc: cmp             x2, #0
    // 0x6431c0: b.gt            #0x6431d0
    // 0x6431c4: r0 = Instance_AxisDirection
    //     0x6431c4: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2cce0] Obj!AxisDirection@b64f71
    //     0x6431c8: ldr             x0, [x0, #0xce0]
    // 0x6431cc: b               #0x6431f8
    // 0x6431d0: r0 = Instance_AxisDirection
    //     0x6431d0: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c578] Obj!AxisDirection@b64f51
    //     0x6431d4: ldr             x0, [x0, #0x578]
    // 0x6431d8: b               #0x6431f8
    // 0x6431dc: cmp             x2, #2
    // 0x6431e0: b.gt            #0x6431f0
    // 0x6431e4: r0 = Instance_AxisDirection
    //     0x6431e4: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2cce8] Obj!AxisDirection@b64f31
    //     0x6431e8: ldr             x0, [x0, #0xce8]
    // 0x6431ec: b               #0x6431f8
    // 0x6431f0: r0 = Instance_AxisDirection
    //     0x6431f0: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2ccd8] Obj!AxisDirection@b64f11
    //     0x6431f4: ldr             x0, [x0, #0xcd8]
    // 0x6431f8: ret
    //     0x6431f8: ret             
  }
  static _ applyGrowthDirectionToScrollDirection(/* No info */) {
    // ** addr: 0x6a06a4, size: 0x54
    // 0x6a06a4: ldr             x1, [SP]
    // 0x6a06a8: LoadField: r2 = r1->field_7
    //     0x6a06a8: ldur            x2, [x1, #7]
    // 0x6a06ac: cmp             x2, #0
    // 0x6a06b0: b.gt            #0x6a06bc
    // 0x6a06b4: ldr             x0, [SP, #8]
    // 0x6a06b8: ret
    //     0x6a06b8: ret             
    // 0x6a06bc: ldr             x1, [SP, #8]
    // 0x6a06c0: LoadField: r2 = r1->field_7
    //     0x6a06c0: ldur            x2, [x1, #7]
    // 0x6a06c4: cmp             x2, #1
    // 0x6a06c8: b.gt            #0x6a06ec
    // 0x6a06cc: cmp             x2, #0
    // 0x6a06d0: b.gt            #0x6a06e0
    // 0x6a06d4: r0 = Instance_ScrollDirection
    //     0x6a06d4: add             x0, PP, #0x1f, lsl #12  ; [pp+0x1f8c0] Obj!ScrollDirection@b646f1
    //     0x6a06d8: ldr             x0, [x0, #0x8c0]
    // 0x6a06dc: b               #0x6a06f4
    // 0x6a06e0: r0 = Instance_ScrollDirection
    //     0x6a06e0: add             x0, PP, #0x4a, lsl #12  ; [pp+0x4a938] Obj!ScrollDirection@b646b1
    //     0x6a06e4: ldr             x0, [x0, #0x938]
    // 0x6a06e8: b               #0x6a06f4
    // 0x6a06ec: r0 = Instance_ScrollDirection
    //     0x6a06ec: add             x0, PP, #0x38, lsl #12  ; [pp+0x38f70] Obj!ScrollDirection@b646d1
    //     0x6a06f0: ldr             x0, [x0, #0xf70]
    // 0x6a06f4: ret
    //     0x6a06f4: ret             
  }
}

// class id: 1999, size: 0x8, field offset: 0x8
abstract class RenderSliverHelpers extends Object
    implements RenderSliver {
}

// class id: 2035, size: 0xc, field offset: 0x8
class SliverPhysicalParentData extends ParentData {

  _ applyPaintTransform(/* No info */) {
    // ** addr: 0x62adac, size: 0x8c
    // 0x62adac: EnterFrame
    //     0x62adac: stp             fp, lr, [SP, #-0x10]!
    //     0x62adb0: mov             fp, SP
    // 0x62adb4: CheckStackOverflow
    //     0x62adb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62adb8: cmp             SP, x16
    //     0x62adbc: b.ls            #0x62ae20
    // 0x62adc0: ldr             x0, [fp, #0x18]
    // 0x62adc4: LoadField: r1 = r0->field_7
    //     0x62adc4: ldur            w1, [x0, #7]
    // 0x62adc8: DecompressPointer r1
    //     0x62adc8: add             x1, x1, HEAP, lsl #32
    // 0x62adcc: LoadField: d0 = r1->field_7
    //     0x62adcc: ldur            d0, [x1, #7]
    // 0x62add0: LoadField: d1 = r1->field_f
    //     0x62add0: ldur            d1, [x1, #0xf]
    // 0x62add4: r0 = inline_Allocate_Double()
    //     0x62add4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62add8: add             x0, x0, #0x10
    //     0x62addc: cmp             x1, x0
    //     0x62ade0: b.ls            #0x62ae28
    //     0x62ade4: str             x0, [THR, #0x60]  ; THR::top
    //     0x62ade8: sub             x0, x0, #0xf
    //     0x62adec: mov             x1, #0xd108
    //     0x62adf0: movk            x1, #3, lsl #16
    //     0x62adf4: stur            x1, [x0, #-1]
    // 0x62adf8: StoreField: r0->field_7 = d0
    //     0x62adf8: stur            d0, [x0, #7]
    // 0x62adfc: ldr             x16, [fp, #0x10]
    // 0x62ae00: stp             x0, x16, [SP, #-0x10]!
    // 0x62ae04: SaveReg d1
    //     0x62ae04: str             d1, [SP, #-8]!
    // 0x62ae08: r0 = translate()
    //     0x62ae08: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0x62ae0c: add             SP, SP, #0x18
    // 0x62ae10: r0 = Null
    //     0x62ae10: mov             x0, NULL
    // 0x62ae14: LeaveFrame
    //     0x62ae14: mov             SP, fp
    //     0x62ae18: ldp             fp, lr, [SP], #0x10
    // 0x62ae1c: ret
    //     0x62ae1c: ret             
    // 0x62ae20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62ae20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62ae24: b               #0x62adc0
    // 0x62ae28: stp             q0, q1, [SP, #-0x20]!
    // 0x62ae2c: r0 = AllocateDouble()
    //     0x62ae2c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62ae30: ldp             q0, q1, [SP], #0x20
    // 0x62ae34: b               #0x62adf8
  }
  _ toString(/* No info */) {
    // ** addr: 0xae5490, size: 0x5c
    // 0xae5490: EnterFrame
    //     0xae5490: stp             fp, lr, [SP, #-0x10]!
    //     0xae5494: mov             fp, SP
    // 0xae5498: CheckStackOverflow
    //     0xae5498: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae549c: cmp             SP, x16
    //     0xae54a0: b.ls            #0xae54e4
    // 0xae54a4: r1 = Null
    //     0xae54a4: mov             x1, NULL
    // 0xae54a8: r2 = 4
    //     0xae54a8: mov             x2, #4
    // 0xae54ac: r0 = AllocateArray()
    //     0xae54ac: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae54b0: r17 = "paintOffset="
    //     0xae54b0: add             x17, PP, #0x36, lsl #12  ; [pp+0x36ff8] "paintOffset="
    //     0xae54b4: ldr             x17, [x17, #0xff8]
    // 0xae54b8: StoreField: r0->field_f = r17
    //     0xae54b8: stur            w17, [x0, #0xf]
    // 0xae54bc: ldr             x1, [fp, #0x10]
    // 0xae54c0: LoadField: r2 = r1->field_7
    //     0xae54c0: ldur            w2, [x1, #7]
    // 0xae54c4: DecompressPointer r2
    //     0xae54c4: add             x2, x2, HEAP, lsl #32
    // 0xae54c8: StoreField: r0->field_13 = r2
    //     0xae54c8: stur            w2, [x0, #0x13]
    // 0xae54cc: SaveReg r0
    //     0xae54cc: str             x0, [SP, #-8]!
    // 0xae54d0: r0 = _interpolate()
    //     0xae54d0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae54d4: add             SP, SP, #8
    // 0xae54d8: LeaveFrame
    //     0xae54d8: mov             SP, fp
    //     0xae54dc: ldp             fp, lr, [SP], #0x10
    // 0xae54e0: ret
    //     0xae54e0: ret             
    // 0xae54e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae54e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae54e8: b               #0xae54a4
  }
}

// class id: 2036, size: 0x14, field offset: 0xc
//   transformed mixin,
abstract class _SliverPhysicalContainerParentData&SliverPhysicalParentData&ContainerParentDataMixin extends SliverPhysicalParentData
     with ContainerParentDataMixin<X0 bound RenderObject> {

  set _ nextSibling=(/* No info */) {
    // ** addr: 0xcef4d4, size: 0x78
    // 0xcef4d4: EnterFrame
    //     0xcef4d4: stp             fp, lr, [SP, #-0x10]!
    //     0xcef4d8: mov             fp, SP
    // 0xcef4dc: ldr             x0, [fp, #0x10]
    // 0xcef4e0: r2 = Null
    //     0xcef4e0: mov             x2, NULL
    // 0xcef4e4: r1 = Null
    //     0xcef4e4: mov             x1, NULL
    // 0xcef4e8: r4 = 59
    //     0xcef4e8: mov             x4, #0x3b
    // 0xcef4ec: branchIfSmi(r0, 0xcef4f8)
    //     0xcef4ec: tbz             w0, #0, #0xcef4f8
    // 0xcef4f0: r4 = LoadClassIdInstr(r0)
    //     0xcef4f0: ldur            x4, [x0, #-1]
    //     0xcef4f4: ubfx            x4, x4, #0xc, #0x14
    // 0xcef4f8: sub             x4, x4, #0x9fc
    // 0xcef4fc: cmp             x4, #0x23
    // 0xcef500: b.ls            #0xcef518
    // 0xcef504: r8 = RenderSliver?
    //     0xcef504: add             x8, PP, #0x40, lsl #12  ; [pp+0x40c98] Type: RenderSliver?
    //     0xcef508: ldr             x8, [x8, #0xc98]
    // 0xcef50c: r3 = Null
    //     0xcef50c: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fc80] Null
    //     0xcef510: ldr             x3, [x3, #0xc80]
    // 0xcef514: r0 = DefaultNullableTypeTest()
    //     0xcef514: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xcef518: ldr             x0, [fp, #0x10]
    // 0xcef51c: ldr             x1, [fp, #0x18]
    // 0xcef520: StoreField: r1->field_f = r0
    //     0xcef520: stur            w0, [x1, #0xf]
    //     0xcef524: ldurb           w16, [x1, #-1]
    //     0xcef528: ldurb           w17, [x0, #-1]
    //     0xcef52c: and             x16, x17, x16, lsr #2
    //     0xcef530: tst             x16, HEAP, lsr #32
    //     0xcef534: b.eq            #0xcef53c
    //     0xcef538: bl              #0xd6826c
    // 0xcef53c: r0 = Null
    //     0xcef53c: mov             x0, NULL
    // 0xcef540: LeaveFrame
    //     0xcef540: mov             SP, fp
    //     0xcef544: ldp             fp, lr, [SP], #0x10
    // 0xcef548: ret
    //     0xcef548: ret             
  }
  set _ previousSibling=(/* No info */) {
    // ** addr: 0xcef954, size: 0x78
    // 0xcef954: EnterFrame
    //     0xcef954: stp             fp, lr, [SP, #-0x10]!
    //     0xcef958: mov             fp, SP
    // 0xcef95c: ldr             x0, [fp, #0x10]
    // 0xcef960: r2 = Null
    //     0xcef960: mov             x2, NULL
    // 0xcef964: r1 = Null
    //     0xcef964: mov             x1, NULL
    // 0xcef968: r4 = 59
    //     0xcef968: mov             x4, #0x3b
    // 0xcef96c: branchIfSmi(r0, 0xcef978)
    //     0xcef96c: tbz             w0, #0, #0xcef978
    // 0xcef970: r4 = LoadClassIdInstr(r0)
    //     0xcef970: ldur            x4, [x0, #-1]
    //     0xcef974: ubfx            x4, x4, #0xc, #0x14
    // 0xcef978: sub             x4, x4, #0x9fc
    // 0xcef97c: cmp             x4, #0x23
    // 0xcef980: b.ls            #0xcef998
    // 0xcef984: r8 = RenderSliver?
    //     0xcef984: add             x8, PP, #0x40, lsl #12  ; [pp+0x40c98] Type: RenderSliver?
    //     0xcef988: ldr             x8, [x8, #0xc98]
    // 0xcef98c: r3 = Null
    //     0xcef98c: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fc90] Null
    //     0xcef990: ldr             x3, [x3, #0xc90]
    // 0xcef994: r0 = DefaultNullableTypeTest()
    //     0xcef994: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xcef998: ldr             x0, [fp, #0x10]
    // 0xcef99c: ldr             x1, [fp, #0x18]
    // 0xcef9a0: StoreField: r1->field_b = r0
    //     0xcef9a0: stur            w0, [x1, #0xb]
    //     0xcef9a4: ldurb           w16, [x1, #-1]
    //     0xcef9a8: ldurb           w17, [x0, #-1]
    //     0xcef9ac: and             x16, x17, x16, lsr #2
    //     0xcef9b0: tst             x16, HEAP, lsr #32
    //     0xcef9b4: b.eq            #0xcef9bc
    //     0xcef9b8: bl              #0xd6826c
    // 0xcef9bc: r0 = Null
    //     0xcef9bc: mov             x0, NULL
    // 0xcef9c0: LeaveFrame
    //     0xcef9c0: mov             SP, fp
    //     0xcef9c4: ldp             fp, lr, [SP], #0x10
    // 0xcef9c8: ret
    //     0xcef9c8: ret             
  }
}

// class id: 2037, size: 0x14, field offset: 0x14
class SliverPhysicalContainerParentData extends _SliverPhysicalContainerParentData&SliverPhysicalParentData&ContainerParentDataMixin {
}

// class id: 2038, size: 0xc, field offset: 0x8
abstract class SliverLogicalParentData extends ParentData {

  _ toString(/* No info */) {
    // ** addr: 0xae51c8, size: 0xb0
    // 0xae51c8: EnterFrame
    //     0xae51c8: stp             fp, lr, [SP, #-0x10]!
    //     0xae51cc: mov             fp, SP
    // 0xae51d0: AllocStack(0x8)
    //     0xae51d0: sub             SP, SP, #8
    // 0xae51d4: CheckStackOverflow
    //     0xae51d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae51d8: cmp             SP, x16
    //     0xae51dc: b.ls            #0xae5270
    // 0xae51e0: r1 = Null
    //     0xae51e0: mov             x1, NULL
    // 0xae51e4: r2 = 4
    //     0xae51e4: mov             x2, #4
    // 0xae51e8: r0 = AllocateArray()
    //     0xae51e8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae51ec: stur            x0, [fp, #-8]
    // 0xae51f0: r17 = "layoutOffset="
    //     0xae51f0: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fc38] "layoutOffset="
    //     0xae51f4: ldr             x17, [x17, #0xc38]
    // 0xae51f8: StoreField: r0->field_f = r17
    //     0xae51f8: stur            w17, [x0, #0xf]
    // 0xae51fc: ldr             x1, [fp, #0x10]
    // 0xae5200: LoadField: r2 = r1->field_7
    //     0xae5200: ldur            w2, [x1, #7]
    // 0xae5204: DecompressPointer r2
    //     0xae5204: add             x2, x2, HEAP, lsl #32
    // 0xae5208: cmp             w2, NULL
    // 0xae520c: b.ne            #0xae521c
    // 0xae5210: r0 = "None"
    //     0xae5210: add             x0, PP, #0x4f, lsl #12  ; [pp+0x4fc40] "None"
    //     0xae5214: ldr             x0, [x0, #0xc40]
    // 0xae5218: b               #0xae522c
    // 0xae521c: r1 = 1
    //     0xae521c: mov             x1, #1
    // 0xae5220: stp             x1, x2, [SP, #-0x10]!
    // 0xae5224: r0 = toStringAsFixed()
    //     0xae5224: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae5228: add             SP, SP, #0x10
    // 0xae522c: ldur            x1, [fp, #-8]
    // 0xae5230: ArrayStore: r1[1] = r0  ; List_4
    //     0xae5230: add             x25, x1, #0x13
    //     0xae5234: str             w0, [x25]
    //     0xae5238: tbz             w0, #0, #0xae5254
    //     0xae523c: ldurb           w16, [x1, #-1]
    //     0xae5240: ldurb           w17, [x0, #-1]
    //     0xae5244: and             x16, x17, x16, lsr #2
    //     0xae5248: tst             x16, HEAP, lsr #32
    //     0xae524c: b.eq            #0xae5254
    //     0xae5250: bl              #0xd67e5c
    // 0xae5254: ldur            x16, [fp, #-8]
    // 0xae5258: SaveReg r16
    //     0xae5258: str             x16, [SP, #-8]!
    // 0xae525c: r0 = _interpolate()
    //     0xae525c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae5260: add             SP, SP, #8
    // 0xae5264: LeaveFrame
    //     0xae5264: mov             SP, fp
    //     0xae5268: ldp             fp, lr, [SP], #0x10
    // 0xae526c: ret
    //     0xae526c: ret             
    // 0xae5270: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae5270: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae5274: b               #0xae51e0
  }
}

// class id: 2044, size: 0x14, field offset: 0xc
//   transformed mixin,
abstract class _SliverLogicalContainerParentData&SliverLogicalParentData&ContainerParentDataMixin extends SliverLogicalParentData
     with ContainerParentDataMixin<X0 bound RenderObject> {

  set _ nextSibling=(/* No info */) {
    // ** addr: 0xcef078, size: 0x78
    // 0xcef078: EnterFrame
    //     0xcef078: stp             fp, lr, [SP, #-0x10]!
    //     0xcef07c: mov             fp, SP
    // 0xcef080: ldr             x0, [fp, #0x10]
    // 0xcef084: r2 = Null
    //     0xcef084: mov             x2, NULL
    // 0xcef088: r1 = Null
    //     0xcef088: mov             x1, NULL
    // 0xcef08c: r4 = 59
    //     0xcef08c: mov             x4, #0x3b
    // 0xcef090: branchIfSmi(r0, 0xcef09c)
    //     0xcef090: tbz             w0, #0, #0xcef09c
    // 0xcef094: r4 = LoadClassIdInstr(r0)
    //     0xcef094: ldur            x4, [x0, #-1]
    //     0xcef098: ubfx            x4, x4, #0xc, #0x14
    // 0xcef09c: sub             x4, x4, #0x9fc
    // 0xcef0a0: cmp             x4, #0x23
    // 0xcef0a4: b.ls            #0xcef0bc
    // 0xcef0a8: r8 = RenderSliver?
    //     0xcef0a8: add             x8, PP, #0x40, lsl #12  ; [pp+0x40c98] Type: RenderSliver?
    //     0xcef0ac: ldr             x8, [x8, #0xc98]
    // 0xcef0b0: r3 = Null
    //     0xcef0b0: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fca0] Null
    //     0xcef0b4: ldr             x3, [x3, #0xca0]
    // 0xcef0b8: r0 = DefaultNullableTypeTest()
    //     0xcef0b8: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xcef0bc: ldr             x0, [fp, #0x10]
    // 0xcef0c0: ldr             x1, [fp, #0x18]
    // 0xcef0c4: StoreField: r1->field_f = r0
    //     0xcef0c4: stur            w0, [x1, #0xf]
    //     0xcef0c8: ldurb           w16, [x1, #-1]
    //     0xcef0cc: ldurb           w17, [x0, #-1]
    //     0xcef0d0: and             x16, x17, x16, lsr #2
    //     0xcef0d4: tst             x16, HEAP, lsr #32
    //     0xcef0d8: b.eq            #0xcef0e0
    //     0xcef0dc: bl              #0xd6826c
    // 0xcef0e0: r0 = Null
    //     0xcef0e0: mov             x0, NULL
    // 0xcef0e4: LeaveFrame
    //     0xcef0e4: mov             SP, fp
    //     0xcef0e8: ldp             fp, lr, [SP], #0x10
    // 0xcef0ec: ret
    //     0xcef0ec: ret             
  }
  set _ previousSibling=(/* No info */) {
    // ** addr: 0xcef868, size: 0x78
    // 0xcef868: EnterFrame
    //     0xcef868: stp             fp, lr, [SP, #-0x10]!
    //     0xcef86c: mov             fp, SP
    // 0xcef870: ldr             x0, [fp, #0x10]
    // 0xcef874: r2 = Null
    //     0xcef874: mov             x2, NULL
    // 0xcef878: r1 = Null
    //     0xcef878: mov             x1, NULL
    // 0xcef87c: r4 = 59
    //     0xcef87c: mov             x4, #0x3b
    // 0xcef880: branchIfSmi(r0, 0xcef88c)
    //     0xcef880: tbz             w0, #0, #0xcef88c
    // 0xcef884: r4 = LoadClassIdInstr(r0)
    //     0xcef884: ldur            x4, [x0, #-1]
    //     0xcef888: ubfx            x4, x4, #0xc, #0x14
    // 0xcef88c: sub             x4, x4, #0x9fc
    // 0xcef890: cmp             x4, #0x23
    // 0xcef894: b.ls            #0xcef8ac
    // 0xcef898: r8 = RenderSliver?
    //     0xcef898: add             x8, PP, #0x40, lsl #12  ; [pp+0x40c98] Type: RenderSliver?
    //     0xcef89c: ldr             x8, [x8, #0xc98]
    // 0xcef8a0: r3 = Null
    //     0xcef8a0: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fcb0] Null
    //     0xcef8a4: ldr             x3, [x3, #0xcb0]
    // 0xcef8a8: r0 = DefaultNullableTypeTest()
    //     0xcef8a8: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xcef8ac: ldr             x0, [fp, #0x10]
    // 0xcef8b0: ldr             x1, [fp, #0x18]
    // 0xcef8b4: StoreField: r1->field_b = r0
    //     0xcef8b4: stur            w0, [x1, #0xb]
    //     0xcef8b8: ldurb           w16, [x1, #-1]
    //     0xcef8bc: ldurb           w17, [x0, #-1]
    //     0xcef8c0: and             x16, x17, x16, lsr #2
    //     0xcef8c4: tst             x16, HEAP, lsr #32
    //     0xcef8c8: b.eq            #0xcef8d0
    //     0xcef8cc: bl              #0xd6826c
    // 0xcef8d0: r0 = Null
    //     0xcef8d0: mov             x0, NULL
    // 0xcef8d4: LeaveFrame
    //     0xcef8d4: mov             SP, fp
    //     0xcef8d8: ldp             fp, lr, [SP], #0x10
    // 0xcef8dc: ret
    //     0xcef8dc: ret             
  }
}

// class id: 2045, size: 0x14, field offset: 0x14
class SliverLogicalContainerParentData extends _SliverLogicalContainerParentData&SliverLogicalParentData&ContainerParentDataMixin {
}

// class id: 2060, size: 0x58, field offset: 0x8
//   const constructor, 
class SliverConstraints extends Constraints {

  get _ axis(/* No info */) {
    // ** addr: 0x643150, size: 0x44
    // 0x643150: ldr             x1, [SP]
    // 0x643154: LoadField: r2 = r1->field_7
    //     0x643154: ldur            w2, [x1, #7]
    // 0x643158: DecompressPointer r2
    //     0x643158: add             x2, x2, HEAP, lsl #32
    // 0x64315c: LoadField: r1 = r2->field_7
    //     0x64315c: ldur            x1, [x2, #7]
    // 0x643160: cmp             x1, #1
    // 0x643164: b.gt            #0x643174
    // 0x643168: cmp             x1, #0
    // 0x64316c: b.gt            #0x643188
    // 0x643170: b               #0x64317c
    // 0x643174: cmp             x1, #2
    // 0x643178: b.gt            #0x643188
    // 0x64317c: r0 = Instance_Axis
    //     0x64317c: add             x0, PP, #0xe, lsl #12  ; [pp+0xef00] Obj!Axis@b64ff1
    //     0x643180: ldr             x0, [x0, #0xf00]
    // 0x643184: b               #0x643190
    // 0x643188: r0 = Instance_Axis
    //     0x643188: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x64318c: ldr             x0, [x0, #0x440]
    // 0x643190: ret
    //     0x643190: ret             
  }
  _ asBoxConstraints(/* No info */) {
    // ** addr: 0x67a528, size: 0x1cc
    // 0x67a528: EnterFrame
    //     0x67a528: stp             fp, lr, [SP, #-0x10]!
    //     0x67a52c: mov             fp, SP
    // 0x67a530: AllocStack(0x18)
    //     0x67a530: sub             SP, SP, #0x18
    // 0x67a534: SetupParameters(SliverConstraints this /* r3 */, {dynamic crossAxisExtent = Null /* r4 */, _Double maxExtent = inf /* d0, fp-0x18 */, _Double minExtent = 0.000000 /* d1, fp-0x10 */})
    //     0x67a534: mov             x0, x4
    //     0x67a538: ldur            w1, [x0, #0x13]
    //     0x67a53c: add             x1, x1, HEAP, lsl #32
    //     0x67a540: sub             x2, x1, #2
    //     0x67a544: add             x3, fp, w2, sxtw #2
    //     0x67a548: ldr             x3, [x3, #0x10]
    //     0x67a54c: ldur            w2, [x0, #0x1f]
    //     0x67a550: add             x2, x2, HEAP, lsl #32
    //     0x67a554: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2d630] "crossAxisExtent"
    //     0x67a558: ldr             x16, [x16, #0x630]
    //     0x67a55c: cmp             w2, w16
    //     0x67a560: b.ne            #0x67a584
    //     0x67a564: ldur            w2, [x0, #0x23]
    //     0x67a568: add             x2, x2, HEAP, lsl #32
    //     0x67a56c: sub             w4, w1, w2
    //     0x67a570: add             x2, fp, w4, sxtw #2
    //     0x67a574: ldr             x2, [x2, #8]
    //     0x67a578: mov             x4, x2
    //     0x67a57c: mov             x2, #1
    //     0x67a580: b               #0x67a58c
    //     0x67a584: mov             x4, NULL
    //     0x67a588: mov             x2, #0
    //     0x67a58c: lsl             x5, x2, #1
    //     0x67a590: lsl             w6, w5, #1
    //     0x67a594: add             w7, w6, #8
    //     0x67a598: add             x16, x0, w7, sxtw #1
    //     0x67a59c: ldur            w8, [x16, #0xf]
    //     0x67a5a0: add             x8, x8, HEAP, lsl #32
    //     0x67a5a4: add             x16, PP, #0x21, lsl #12  ; [pp+0x21e70] "maxExtent"
    //     0x67a5a8: ldr             x16, [x16, #0xe70]
    //     0x67a5ac: cmp             w8, w16
    //     0x67a5b0: b.ne            #0x67a5e4
    //     0x67a5b4: add             w2, w6, #0xa
    //     0x67a5b8: add             x16, x0, w2, sxtw #1
    //     0x67a5bc: ldur            w6, [x16, #0xf]
    //     0x67a5c0: add             x6, x6, HEAP, lsl #32
    //     0x67a5c4: sub             w2, w1, w6
    //     0x67a5c8: add             x6, fp, w2, sxtw #2
    //     0x67a5cc: ldr             x6, [x6, #8]
    //     0x67a5d0: add             w2, w5, #2
    //     0x67a5d4: ldur            d0, [x6, #7]
    //     0x67a5d8: sbfx            x5, x2, #1, #0x1f
    //     0x67a5dc: mov             x2, x5
    //     0x67a5e0: b               #0x67a5e8
    //     0x67a5e4: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    //     0x67a5e8: stur            d0, [fp, #-0x18]
    //     0x67a5ec: lsl             x5, x2, #1
    //     0x67a5f0: lsl             w2, w5, #1
    //     0x67a5f4: add             w5, w2, #8
    //     0x67a5f8: add             x16, x0, w5, sxtw #1
    //     0x67a5fc: ldur            w6, [x16, #0xf]
    //     0x67a600: add             x6, x6, HEAP, lsl #32
    //     0x67a604: add             x16, PP, #0x21, lsl #12  ; [pp+0x21e78] "minExtent"
    //     0x67a608: ldr             x16, [x16, #0xe78]
    //     0x67a60c: cmp             w6, w16
    //     0x67a610: b.ne            #0x67a638
    //     0x67a614: add             w5, w2, #0xa
    //     0x67a618: add             x16, x0, w5, sxtw #1
    //     0x67a61c: ldur            w2, [x16, #0xf]
    //     0x67a620: add             x2, x2, HEAP, lsl #32
    //     0x67a624: sub             w0, w1, w2
    //     0x67a628: add             x1, fp, w0, sxtw #2
    //     0x67a62c: ldr             x1, [x1, #8]
    //     0x67a630: ldur            d1, [x1, #7]
    //     0x67a634: b               #0x67a63c
    //     0x67a638: eor             v1.16b, v1.16b, v1.16b
    //     0x67a63c: stur            d1, [fp, #-0x10]
    // 0x67a640: CheckStackOverflow
    //     0x67a640: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67a644: cmp             SP, x16
    //     0x67a648: b.ls            #0x67a6ec
    // 0x67a64c: cmp             w4, NULL
    // 0x67a650: b.ne            #0x67a65c
    // 0x67a654: LoadField: d2 = r3->field_33
    //     0x67a654: ldur            d2, [x3, #0x33]
    // 0x67a658: b               #0x67a660
    // 0x67a65c: LoadField: d2 = r4->field_7
    //     0x67a65c: ldur            d2, [x4, #7]
    // 0x67a660: stur            d2, [fp, #-8]
    // 0x67a664: SaveReg r3
    //     0x67a664: str             x3, [SP, #-8]!
    // 0x67a668: r0 = axis()
    //     0x67a668: bl              #0x643150  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0x67a66c: add             SP, SP, #8
    // 0x67a670: LoadField: r1 = r0->field_7
    //     0x67a670: ldur            x1, [x0, #7]
    // 0x67a674: cmp             x1, #0
    // 0x67a678: b.gt            #0x67a6b4
    // 0x67a67c: ldur            d0, [fp, #-0x18]
    // 0x67a680: ldur            d1, [fp, #-0x10]
    // 0x67a684: ldur            d2, [fp, #-8]
    // 0x67a688: r0 = BoxConstraints()
    //     0x67a688: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x67a68c: ldur            d0, [fp, #-0x10]
    // 0x67a690: StoreField: r0->field_7 = d0
    //     0x67a690: stur            d0, [x0, #7]
    // 0x67a694: ldur            d1, [fp, #-0x18]
    // 0x67a698: StoreField: r0->field_f = d1
    //     0x67a698: stur            d1, [x0, #0xf]
    // 0x67a69c: ldur            d2, [fp, #-8]
    // 0x67a6a0: StoreField: r0->field_17 = d2
    //     0x67a6a0: stur            d2, [x0, #0x17]
    // 0x67a6a4: StoreField: r0->field_1f = d2
    //     0x67a6a4: stur            d2, [x0, #0x1f]
    // 0x67a6a8: LeaveFrame
    //     0x67a6a8: mov             SP, fp
    //     0x67a6ac: ldp             fp, lr, [SP], #0x10
    // 0x67a6b0: ret
    //     0x67a6b0: ret             
    // 0x67a6b4: ldur            d1, [fp, #-0x18]
    // 0x67a6b8: ldur            d0, [fp, #-0x10]
    // 0x67a6bc: ldur            d2, [fp, #-8]
    // 0x67a6c0: r0 = BoxConstraints()
    //     0x67a6c0: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x67a6c4: ldur            d0, [fp, #-8]
    // 0x67a6c8: StoreField: r0->field_7 = d0
    //     0x67a6c8: stur            d0, [x0, #7]
    // 0x67a6cc: StoreField: r0->field_f = d0
    //     0x67a6cc: stur            d0, [x0, #0xf]
    // 0x67a6d0: ldur            d0, [fp, #-0x10]
    // 0x67a6d4: StoreField: r0->field_17 = d0
    //     0x67a6d4: stur            d0, [x0, #0x17]
    // 0x67a6d8: ldur            d0, [fp, #-0x18]
    // 0x67a6dc: StoreField: r0->field_1f = d0
    //     0x67a6dc: stur            d0, [x0, #0x1f]
    // 0x67a6e0: LeaveFrame
    //     0x67a6e0: mov             SP, fp
    //     0x67a6e4: ldp             fp, lr, [SP], #0x10
    // 0x67a6e8: ret
    //     0x67a6e8: ret             
    // 0x67a6ec: r0 = StackOverflowSharedWithFPURegs()
    //     0x67a6ec: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x67a6f0: b               #0x67a64c
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x68431c, size: 0x368
    // 0x68431c: EnterFrame
    //     0x68431c: stp             fp, lr, [SP, #-0x10]!
    //     0x684320: mov             fp, SP
    // 0x684324: AllocStack(0x60)
    //     0x684324: sub             SP, SP, #0x60
    // 0x684328: SetupParameters(SliverConstraints this /* r3 */, dynamic _ /* d0, fp-0x60 */, {dynamic cacheOrigin = Null /* r4 */, dynamic crossAxisExtent = Null /* r5 */, dynamic precedingScrollExtent = Null /* r6 */, dynamic remainingCacheExtent = Null /* r7 */, dynamic remainingPaintExtent = Null /* r8 */, dynamic scrollOffset = Null /* r0 */})
    //     0x684328: mov             x0, x4
    //     0x68432c: ldur            w1, [x0, #0x13]
    //     0x684330: add             x1, x1, HEAP, lsl #32
    //     0x684334: sub             x2, x1, #4
    //     0x684338: add             x3, fp, w2, sxtw #2
    //     0x68433c: ldr             x3, [x3, #0x18]
    //     0x684340: add             x4, fp, w2, sxtw #2
    //     0x684344: ldr             d0, [x4, #0x10]
    //     0x684348: stur            d0, [fp, #-0x60]
    //     0x68434c: ldur            w2, [x0, #0x1f]
    //     0x684350: add             x2, x2, HEAP, lsl #32
    //     0x684354: add             x16, PP, #0x42, lsl #12  ; [pp+0x42b48] "cacheOrigin"
    //     0x684358: ldr             x16, [x16, #0xb48]
    //     0x68435c: cmp             w2, w16
    //     0x684360: b.ne            #0x684384
    //     0x684364: ldur            w2, [x0, #0x23]
    //     0x684368: add             x2, x2, HEAP, lsl #32
    //     0x68436c: sub             w4, w1, w2
    //     0x684370: add             x2, fp, w4, sxtw #2
    //     0x684374: ldr             x2, [x2, #8]
    //     0x684378: mov             x4, x2
    //     0x68437c: mov             x2, #1
    //     0x684380: b               #0x68438c
    //     0x684384: mov             x4, NULL
    //     0x684388: mov             x2, #0
    //     0x68438c: lsl             x5, x2, #1
    //     0x684390: lsl             w6, w5, #1
    //     0x684394: add             w7, w6, #8
    //     0x684398: add             x16, x0, w7, sxtw #1
    //     0x68439c: ldur            w8, [x16, #0xf]
    //     0x6843a0: add             x8, x8, HEAP, lsl #32
    //     0x6843a4: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2d630] "crossAxisExtent"
    //     0x6843a8: ldr             x16, [x16, #0x630]
    //     0x6843ac: cmp             w8, w16
    //     0x6843b0: b.ne            #0x6843e4
    //     0x6843b4: add             w2, w6, #0xa
    //     0x6843b8: add             x16, x0, w2, sxtw #1
    //     0x6843bc: ldur            w6, [x16, #0xf]
    //     0x6843c0: add             x6, x6, HEAP, lsl #32
    //     0x6843c4: sub             w2, w1, w6
    //     0x6843c8: add             x6, fp, w2, sxtw #2
    //     0x6843cc: ldr             x6, [x6, #8]
    //     0x6843d0: add             w2, w5, #2
    //     0x6843d4: sbfx            x5, x2, #1, #0x1f
    //     0x6843d8: mov             x2, x5
    //     0x6843dc: mov             x5, x6
    //     0x6843e0: b               #0x6843e8
    //     0x6843e4: mov             x5, NULL
    //     0x6843e8: lsl             x6, x2, #1
    //     0x6843ec: lsl             w7, w6, #1
    //     0x6843f0: add             w8, w7, #8
    //     0x6843f4: add             x16, x0, w8, sxtw #1
    //     0x6843f8: ldur            w9, [x16, #0xf]
    //     0x6843fc: add             x9, x9, HEAP, lsl #32
    //     0x684400: add             x16, PP, #0x42, lsl #12  ; [pp+0x42b50] "precedingScrollExtent"
    //     0x684404: ldr             x16, [x16, #0xb50]
    //     0x684408: cmp             w9, w16
    //     0x68440c: b.ne            #0x684440
    //     0x684410: add             w2, w7, #0xa
    //     0x684414: add             x16, x0, w2, sxtw #1
    //     0x684418: ldur            w7, [x16, #0xf]
    //     0x68441c: add             x7, x7, HEAP, lsl #32
    //     0x684420: sub             w2, w1, w7
    //     0x684424: add             x7, fp, w2, sxtw #2
    //     0x684428: ldr             x7, [x7, #8]
    //     0x68442c: add             w2, w6, #2
    //     0x684430: sbfx            x6, x2, #1, #0x1f
    //     0x684434: mov             x2, x6
    //     0x684438: mov             x6, x7
    //     0x68443c: b               #0x684444
    //     0x684440: mov             x6, NULL
    //     0x684444: lsl             x7, x2, #1
    //     0x684448: lsl             w8, w7, #1
    //     0x68444c: add             w9, w8, #8
    //     0x684450: add             x16, x0, w9, sxtw #1
    //     0x684454: ldur            w10, [x16, #0xf]
    //     0x684458: add             x10, x10, HEAP, lsl #32
    //     0x68445c: add             x16, PP, #0x42, lsl #12  ; [pp+0x42b58] "remainingCacheExtent"
    //     0x684460: ldr             x16, [x16, #0xb58]
    //     0x684464: cmp             w10, w16
    //     0x684468: b.ne            #0x68449c
    //     0x68446c: add             w2, w8, #0xa
    //     0x684470: add             x16, x0, w2, sxtw #1
    //     0x684474: ldur            w8, [x16, #0xf]
    //     0x684478: add             x8, x8, HEAP, lsl #32
    //     0x68447c: sub             w2, w1, w8
    //     0x684480: add             x8, fp, w2, sxtw #2
    //     0x684484: ldr             x8, [x8, #8]
    //     0x684488: add             w2, w7, #2
    //     0x68448c: sbfx            x7, x2, #1, #0x1f
    //     0x684490: mov             x2, x7
    //     0x684494: mov             x7, x8
    //     0x684498: b               #0x6844a0
    //     0x68449c: mov             x7, NULL
    //     0x6844a0: lsl             x8, x2, #1
    //     0x6844a4: lsl             w9, w8, #1
    //     0x6844a8: add             w10, w9, #8
    //     0x6844ac: add             x16, x0, w10, sxtw #1
    //     0x6844b0: ldur            w11, [x16, #0xf]
    //     0x6844b4: add             x11, x11, HEAP, lsl #32
    //     0x6844b8: add             x16, PP, #0x42, lsl #12  ; [pp+0x42b60] "remainingPaintExtent"
    //     0x6844bc: ldr             x16, [x16, #0xb60]
    //     0x6844c0: cmp             w11, w16
    //     0x6844c4: b.ne            #0x6844f8
    //     0x6844c8: add             w2, w9, #0xa
    //     0x6844cc: add             x16, x0, w2, sxtw #1
    //     0x6844d0: ldur            w9, [x16, #0xf]
    //     0x6844d4: add             x9, x9, HEAP, lsl #32
    //     0x6844d8: sub             w2, w1, w9
    //     0x6844dc: add             x9, fp, w2, sxtw #2
    //     0x6844e0: ldr             x9, [x9, #8]
    //     0x6844e4: add             w2, w8, #2
    //     0x6844e8: sbfx            x8, x2, #1, #0x1f
    //     0x6844ec: mov             x2, x8
    //     0x6844f0: mov             x8, x9
    //     0x6844f4: b               #0x6844fc
    //     0x6844f8: mov             x8, NULL
    //     0x6844fc: lsl             x9, x2, #1
    //     0x684500: lsl             w2, w9, #1
    //     0x684504: add             w9, w2, #8
    //     0x684508: add             x16, x0, w9, sxtw #1
    //     0x68450c: ldur            w10, [x16, #0xf]
    //     0x684510: add             x10, x10, HEAP, lsl #32
    //     0x684514: add             x16, PP, #0x42, lsl #12  ; [pp+0x42b68] "scrollOffset"
    //     0x684518: ldr             x16, [x16, #0xb68]
    //     0x68451c: cmp             w10, w16
    //     0x684520: b.ne            #0x684548
    //     0x684524: add             w9, w2, #0xa
    //     0x684528: add             x16, x0, w9, sxtw #1
    //     0x68452c: ldur            w2, [x16, #0xf]
    //     0x684530: add             x2, x2, HEAP, lsl #32
    //     0x684534: sub             w0, w1, w2
    //     0x684538: add             x1, fp, w0, sxtw #2
    //     0x68453c: ldr             x1, [x1, #8]
    //     0x684540: mov             x0, x1
    //     0x684544: b               #0x68454c
    //     0x684548: mov             x0, NULL
    // 0x68454c: LoadField: r1 = r3->field_7
    //     0x68454c: ldur            w1, [x3, #7]
    // 0x684550: DecompressPointer r1
    //     0x684550: add             x1, x1, HEAP, lsl #32
    // 0x684554: stur            x1, [fp, #-0x20]
    // 0x684558: LoadField: r2 = r3->field_b
    //     0x684558: ldur            w2, [x3, #0xb]
    // 0x68455c: DecompressPointer r2
    //     0x68455c: add             x2, x2, HEAP, lsl #32
    // 0x684560: stur            x2, [fp, #-0x18]
    // 0x684564: LoadField: r9 = r3->field_f
    //     0x684564: ldur            w9, [x3, #0xf]
    // 0x684568: DecompressPointer r9
    //     0x684568: add             x9, x9, HEAP, lsl #32
    // 0x68456c: stur            x9, [fp, #-0x10]
    // 0x684570: cmp             w0, NULL
    // 0x684574: b.ne            #0x684580
    // 0x684578: LoadField: d1 = r3->field_13
    //     0x684578: ldur            d1, [x3, #0x13]
    // 0x68457c: b               #0x684584
    // 0x684580: LoadField: d1 = r0->field_7
    //     0x684580: ldur            d1, [x0, #7]
    // 0x684584: stur            d1, [fp, #-0x58]
    // 0x684588: cmp             w6, NULL
    // 0x68458c: b.ne            #0x684598
    // 0x684590: LoadField: d2 = r3->field_1b
    //     0x684590: ldur            d2, [x3, #0x1b]
    // 0x684594: b               #0x68459c
    // 0x684598: LoadField: d2 = r6->field_7
    //     0x684598: ldur            d2, [x6, #7]
    // 0x68459c: stur            d2, [fp, #-0x50]
    // 0x6845a0: cmp             w8, NULL
    // 0x6845a4: b.ne            #0x6845b0
    // 0x6845a8: LoadField: d3 = r3->field_2b
    //     0x6845a8: ldur            d3, [x3, #0x2b]
    // 0x6845ac: b               #0x6845b4
    // 0x6845b0: LoadField: d3 = r8->field_7
    //     0x6845b0: ldur            d3, [x8, #7]
    // 0x6845b4: stur            d3, [fp, #-0x48]
    // 0x6845b8: cmp             w5, NULL
    // 0x6845bc: b.ne            #0x6845c8
    // 0x6845c0: LoadField: d4 = r3->field_33
    //     0x6845c0: ldur            d4, [x3, #0x33]
    // 0x6845c4: b               #0x6845cc
    // 0x6845c8: LoadField: d4 = r5->field_7
    //     0x6845c8: ldur            d4, [x5, #7]
    // 0x6845cc: stur            d4, [fp, #-0x40]
    // 0x6845d0: LoadField: r0 = r3->field_3b
    //     0x6845d0: ldur            w0, [x3, #0x3b]
    // 0x6845d4: DecompressPointer r0
    //     0x6845d4: add             x0, x0, HEAP, lsl #32
    // 0x6845d8: stur            x0, [fp, #-8]
    // 0x6845dc: LoadField: d5 = r3->field_3f
    //     0x6845dc: ldur            d5, [x3, #0x3f]
    // 0x6845e0: stur            d5, [fp, #-0x38]
    // 0x6845e4: cmp             w7, NULL
    // 0x6845e8: b.ne            #0x6845f4
    // 0x6845ec: LoadField: d6 = r3->field_4f
    //     0x6845ec: ldur            d6, [x3, #0x4f]
    // 0x6845f0: b               #0x6845f8
    // 0x6845f4: LoadField: d6 = r7->field_7
    //     0x6845f4: ldur            d6, [x7, #7]
    // 0x6845f8: stur            d6, [fp, #-0x30]
    // 0x6845fc: cmp             w4, NULL
    // 0x684600: b.ne            #0x68460c
    // 0x684604: LoadField: d7 = r3->field_47
    //     0x684604: ldur            d7, [x3, #0x47]
    // 0x684608: b               #0x684610
    // 0x68460c: LoadField: d7 = r4->field_7
    //     0x68460c: ldur            d7, [x4, #7]
    // 0x684610: stur            d7, [fp, #-0x28]
    // 0x684614: r0 = SliverConstraints()
    //     0x684614: bl              #0x684684  ; AllocateSliverConstraintsStub -> SliverConstraints (size=0x58)
    // 0x684618: ldur            x1, [fp, #-0x20]
    // 0x68461c: StoreField: r0->field_7 = r1
    //     0x68461c: stur            w1, [x0, #7]
    // 0x684620: ldur            x1, [fp, #-0x18]
    // 0x684624: StoreField: r0->field_b = r1
    //     0x684624: stur            w1, [x0, #0xb]
    // 0x684628: ldur            x1, [fp, #-0x10]
    // 0x68462c: StoreField: r0->field_f = r1
    //     0x68462c: stur            w1, [x0, #0xf]
    // 0x684630: ldur            d0, [fp, #-0x58]
    // 0x684634: StoreField: r0->field_13 = d0
    //     0x684634: stur            d0, [x0, #0x13]
    // 0x684638: ldur            d0, [fp, #-0x50]
    // 0x68463c: StoreField: r0->field_1b = d0
    //     0x68463c: stur            d0, [x0, #0x1b]
    // 0x684640: ldur            d0, [fp, #-0x60]
    // 0x684644: StoreField: r0->field_23 = d0
    //     0x684644: stur            d0, [x0, #0x23]
    // 0x684648: ldur            d0, [fp, #-0x48]
    // 0x68464c: StoreField: r0->field_2b = d0
    //     0x68464c: stur            d0, [x0, #0x2b]
    // 0x684650: ldur            d0, [fp, #-0x40]
    // 0x684654: StoreField: r0->field_33 = d0
    //     0x684654: stur            d0, [x0, #0x33]
    // 0x684658: ldur            x1, [fp, #-8]
    // 0x68465c: StoreField: r0->field_3b = r1
    //     0x68465c: stur            w1, [x0, #0x3b]
    // 0x684660: ldur            d0, [fp, #-0x38]
    // 0x684664: StoreField: r0->field_3f = d0
    //     0x684664: stur            d0, [x0, #0x3f]
    // 0x684668: ldur            d0, [fp, #-0x30]
    // 0x68466c: StoreField: r0->field_4f = d0
    //     0x68466c: stur            d0, [x0, #0x4f]
    // 0x684670: ldur            d0, [fp, #-0x28]
    // 0x684674: StoreField: r0->field_47 = d0
    //     0x684674: stur            d0, [x0, #0x47]
    // 0x684678: LeaveFrame
    //     0x684678: mov             SP, fp
    //     0x68467c: ldp             fp, lr, [SP], #0x10
    // 0x684680: ret
    //     0x684680: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0xae3ae4, size: 0xa38
    // 0xae3ae4: EnterFrame
    //     0xae3ae4: stp             fp, lr, [SP, #-0x10]!
    //     0xae3ae8: mov             fp, SP
    // 0xae3aec: AllocStack(0x38)
    //     0xae3aec: sub             SP, SP, #0x38
    // 0xae3af0: CheckStackOverflow
    //     0xae3af0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae3af4: cmp             SP, x16
    //     0xae3af8: b.ls            #0xae4438
    // 0xae3afc: ldr             x0, [fp, #0x10]
    // 0xae3b00: LoadField: r1 = r0->field_7
    //     0xae3b00: ldur            w1, [x0, #7]
    // 0xae3b04: DecompressPointer r1
    //     0xae3b04: add             x1, x1, HEAP, lsl #32
    // 0xae3b08: SaveReg r1
    //     0xae3b08: str             x1, [SP, #-8]!
    // 0xae3b0c: r0 = _interpolateSingle()
    //     0xae3b0c: bl              #0x4bdd98  ; [dart:core] _StringBase::_interpolateSingle
    // 0xae3b10: add             SP, SP, #8
    // 0xae3b14: mov             x1, x0
    // 0xae3b18: ldr             x0, [fp, #0x10]
    // 0xae3b1c: stur            x1, [fp, #-8]
    // 0xae3b20: LoadField: r2 = r0->field_b
    //     0xae3b20: ldur            w2, [x0, #0xb]
    // 0xae3b24: DecompressPointer r2
    //     0xae3b24: add             x2, x2, HEAP, lsl #32
    // 0xae3b28: SaveReg r2
    //     0xae3b28: str             x2, [SP, #-8]!
    // 0xae3b2c: r0 = _interpolateSingle()
    //     0xae3b2c: bl              #0x4bdd98  ; [dart:core] _StringBase::_interpolateSingle
    // 0xae3b30: add             SP, SP, #8
    // 0xae3b34: mov             x1, x0
    // 0xae3b38: ldr             x0, [fp, #0x10]
    // 0xae3b3c: stur            x1, [fp, #-0x10]
    // 0xae3b40: LoadField: r2 = r0->field_f
    //     0xae3b40: ldur            w2, [x0, #0xf]
    // 0xae3b44: DecompressPointer r2
    //     0xae3b44: add             x2, x2, HEAP, lsl #32
    // 0xae3b48: SaveReg r2
    //     0xae3b48: str             x2, [SP, #-8]!
    // 0xae3b4c: r0 = _interpolateSingle()
    //     0xae3b4c: bl              #0x4bdd98  ; [dart:core] _StringBase::_interpolateSingle
    // 0xae3b50: add             SP, SP, #8
    // 0xae3b54: r1 = Null
    //     0xae3b54: mov             x1, NULL
    // 0xae3b58: r2 = 4
    //     0xae3b58: mov             x2, #4
    // 0xae3b5c: stur            x0, [fp, #-0x18]
    // 0xae3b60: r0 = AllocateArray()
    //     0xae3b60: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae3b64: stur            x0, [fp, #-0x20]
    // 0xae3b68: r17 = "scrollOffset: "
    //     0xae3b68: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fbf0] "scrollOffset: "
    //     0xae3b6c: ldr             x17, [x17, #0xbf0]
    // 0xae3b70: StoreField: r0->field_f = r17
    //     0xae3b70: stur            w17, [x0, #0xf]
    // 0xae3b74: ldr             x1, [fp, #0x10]
    // 0xae3b78: LoadField: d0 = r1->field_13
    //     0xae3b78: ldur            d0, [x1, #0x13]
    // 0xae3b7c: r2 = inline_Allocate_Double()
    //     0xae3b7c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xae3b80: add             x2, x2, #0x10
    //     0xae3b84: cmp             x3, x2
    //     0xae3b88: b.ls            #0xae4440
    //     0xae3b8c: str             x2, [THR, #0x60]  ; THR::top
    //     0xae3b90: sub             x2, x2, #0xf
    //     0xae3b94: mov             x3, #0xd108
    //     0xae3b98: movk            x3, #3, lsl #16
    //     0xae3b9c: stur            x3, [x2, #-1]
    // 0xae3ba0: StoreField: r2->field_7 = d0
    //     0xae3ba0: stur            d0, [x2, #7]
    // 0xae3ba4: SaveReg r2
    //     0xae3ba4: str             x2, [SP, #-8]!
    // 0xae3ba8: r2 = 1
    //     0xae3ba8: mov             x2, #1
    // 0xae3bac: SaveReg r2
    //     0xae3bac: str             x2, [SP, #-8]!
    // 0xae3bb0: r0 = toStringAsFixed()
    //     0xae3bb0: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae3bb4: add             SP, SP, #0x10
    // 0xae3bb8: ldur            x1, [fp, #-0x20]
    // 0xae3bbc: ArrayStore: r1[1] = r0  ; List_4
    //     0xae3bbc: add             x25, x1, #0x13
    //     0xae3bc0: str             w0, [x25]
    //     0xae3bc4: tbz             w0, #0, #0xae3be0
    //     0xae3bc8: ldurb           w16, [x1, #-1]
    //     0xae3bcc: ldurb           w17, [x0, #-1]
    //     0xae3bd0: and             x16, x17, x16, lsr #2
    //     0xae3bd4: tst             x16, HEAP, lsr #32
    //     0xae3bd8: b.eq            #0xae3be0
    //     0xae3bdc: bl              #0xd67e5c
    // 0xae3be0: ldur            x16, [fp, #-0x20]
    // 0xae3be4: SaveReg r16
    //     0xae3be4: str             x16, [SP, #-8]!
    // 0xae3be8: r0 = _interpolate()
    //     0xae3be8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae3bec: add             SP, SP, #8
    // 0xae3bf0: r1 = Null
    //     0xae3bf0: mov             x1, NULL
    // 0xae3bf4: r2 = 4
    //     0xae3bf4: mov             x2, #4
    // 0xae3bf8: stur            x0, [fp, #-0x20]
    // 0xae3bfc: r0 = AllocateArray()
    //     0xae3bfc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae3c00: stur            x0, [fp, #-0x28]
    // 0xae3c04: r17 = "remainingPaintExtent: "
    //     0xae3c04: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fc48] "remainingPaintExtent: "
    //     0xae3c08: ldr             x17, [x17, #0xc48]
    // 0xae3c0c: StoreField: r0->field_f = r17
    //     0xae3c0c: stur            w17, [x0, #0xf]
    // 0xae3c10: ldr             x1, [fp, #0x10]
    // 0xae3c14: LoadField: d0 = r1->field_2b
    //     0xae3c14: ldur            d0, [x1, #0x2b]
    // 0xae3c18: r2 = inline_Allocate_Double()
    //     0xae3c18: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xae3c1c: add             x2, x2, #0x10
    //     0xae3c20: cmp             x3, x2
    //     0xae3c24: b.ls            #0xae445c
    //     0xae3c28: str             x2, [THR, #0x60]  ; THR::top
    //     0xae3c2c: sub             x2, x2, #0xf
    //     0xae3c30: mov             x3, #0xd108
    //     0xae3c34: movk            x3, #3, lsl #16
    //     0xae3c38: stur            x3, [x2, #-1]
    // 0xae3c3c: StoreField: r2->field_7 = d0
    //     0xae3c3c: stur            d0, [x2, #7]
    // 0xae3c40: SaveReg r2
    //     0xae3c40: str             x2, [SP, #-8]!
    // 0xae3c44: r2 = 1
    //     0xae3c44: mov             x2, #1
    // 0xae3c48: SaveReg r2
    //     0xae3c48: str             x2, [SP, #-8]!
    // 0xae3c4c: r0 = toStringAsFixed()
    //     0xae3c4c: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae3c50: add             SP, SP, #0x10
    // 0xae3c54: ldur            x1, [fp, #-0x28]
    // 0xae3c58: ArrayStore: r1[1] = r0  ; List_4
    //     0xae3c58: add             x25, x1, #0x13
    //     0xae3c5c: str             w0, [x25]
    //     0xae3c60: tbz             w0, #0, #0xae3c7c
    //     0xae3c64: ldurb           w16, [x1, #-1]
    //     0xae3c68: ldurb           w17, [x0, #-1]
    //     0xae3c6c: and             x16, x17, x16, lsr #2
    //     0xae3c70: tst             x16, HEAP, lsr #32
    //     0xae3c74: b.eq            #0xae3c7c
    //     0xae3c78: bl              #0xd67e5c
    // 0xae3c7c: ldur            x16, [fp, #-0x28]
    // 0xae3c80: SaveReg r16
    //     0xae3c80: str             x16, [SP, #-8]!
    // 0xae3c84: r0 = _interpolate()
    //     0xae3c84: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae3c88: add             SP, SP, #8
    // 0xae3c8c: r1 = Null
    //     0xae3c8c: mov             x1, NULL
    // 0xae3c90: r2 = 10
    //     0xae3c90: mov             x2, #0xa
    // 0xae3c94: stur            x0, [fp, #-0x28]
    // 0xae3c98: r0 = AllocateArray()
    //     0xae3c98: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae3c9c: mov             x2, x0
    // 0xae3ca0: ldur            x0, [fp, #-8]
    // 0xae3ca4: stur            x2, [fp, #-0x30]
    // 0xae3ca8: StoreField: r2->field_f = r0
    //     0xae3ca8: stur            w0, [x2, #0xf]
    // 0xae3cac: ldur            x0, [fp, #-0x10]
    // 0xae3cb0: StoreField: r2->field_13 = r0
    //     0xae3cb0: stur            w0, [x2, #0x13]
    // 0xae3cb4: ldur            x0, [fp, #-0x18]
    // 0xae3cb8: StoreField: r2->field_17 = r0
    //     0xae3cb8: stur            w0, [x2, #0x17]
    // 0xae3cbc: ldur            x0, [fp, #-0x20]
    // 0xae3cc0: StoreField: r2->field_1b = r0
    //     0xae3cc0: stur            w0, [x2, #0x1b]
    // 0xae3cc4: ldur            x0, [fp, #-0x28]
    // 0xae3cc8: StoreField: r2->field_1f = r0
    //     0xae3cc8: stur            w0, [x2, #0x1f]
    // 0xae3ccc: r1 = <String>
    //     0xae3ccc: ldr             x1, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xae3cd0: r0 = AllocateGrowableArray()
    //     0xae3cd0: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xae3cd4: mov             x3, x0
    // 0xae3cd8: ldur            x0, [fp, #-0x30]
    // 0xae3cdc: stur            x3, [fp, #-8]
    // 0xae3ce0: StoreField: r3->field_f = r0
    //     0xae3ce0: stur            w0, [x3, #0xf]
    // 0xae3ce4: r0 = 10
    //     0xae3ce4: mov             x0, #0xa
    // 0xae3ce8: StoreField: r3->field_b = r0
    //     0xae3ce8: stur            w0, [x3, #0xb]
    // 0xae3cec: ldr             x0, [fp, #0x10]
    // 0xae3cf0: LoadField: d0 = r0->field_23
    //     0xae3cf0: ldur            d0, [x0, #0x23]
    // 0xae3cf4: stur            d0, [fp, #-0x38]
    // 0xae3cf8: d1 = 0.000000
    //     0xae3cf8: eor             v1.16b, v1.16b, v1.16b
    // 0xae3cfc: fcmp            d0, d1
    // 0xae3d00: b.eq            #0xae3e2c
    // 0xae3d04: r1 = Null
    //     0xae3d04: mov             x1, NULL
    // 0xae3d08: r2 = 4
    //     0xae3d08: mov             x2, #4
    // 0xae3d0c: r0 = AllocateArray()
    //     0xae3d0c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae3d10: stur            x0, [fp, #-0x10]
    // 0xae3d14: r17 = "overlap: "
    //     0xae3d14: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fc50] "overlap: "
    //     0xae3d18: ldr             x17, [x17, #0xc50]
    // 0xae3d1c: StoreField: r0->field_f = r17
    //     0xae3d1c: stur            w17, [x0, #0xf]
    // 0xae3d20: ldur            d0, [fp, #-0x38]
    // 0xae3d24: r1 = inline_Allocate_Double()
    //     0xae3d24: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xae3d28: add             x1, x1, #0x10
    //     0xae3d2c: cmp             x2, x1
    //     0xae3d30: b.ls            #0xae4478
    //     0xae3d34: str             x1, [THR, #0x60]  ; THR::top
    //     0xae3d38: sub             x1, x1, #0xf
    //     0xae3d3c: mov             x2, #0xd108
    //     0xae3d40: movk            x2, #3, lsl #16
    //     0xae3d44: stur            x2, [x1, #-1]
    // 0xae3d48: StoreField: r1->field_7 = d0
    //     0xae3d48: stur            d0, [x1, #7]
    // 0xae3d4c: SaveReg r1
    //     0xae3d4c: str             x1, [SP, #-8]!
    // 0xae3d50: r1 = 1
    //     0xae3d50: mov             x1, #1
    // 0xae3d54: SaveReg r1
    //     0xae3d54: str             x1, [SP, #-8]!
    // 0xae3d58: r0 = toStringAsFixed()
    //     0xae3d58: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae3d5c: add             SP, SP, #0x10
    // 0xae3d60: ldur            x1, [fp, #-0x10]
    // 0xae3d64: ArrayStore: r1[1] = r0  ; List_4
    //     0xae3d64: add             x25, x1, #0x13
    //     0xae3d68: str             w0, [x25]
    //     0xae3d6c: tbz             w0, #0, #0xae3d88
    //     0xae3d70: ldurb           w16, [x1, #-1]
    //     0xae3d74: ldurb           w17, [x0, #-1]
    //     0xae3d78: and             x16, x17, x16, lsr #2
    //     0xae3d7c: tst             x16, HEAP, lsr #32
    //     0xae3d80: b.eq            #0xae3d88
    //     0xae3d84: bl              #0xd67e5c
    // 0xae3d88: ldur            x16, [fp, #-0x10]
    // 0xae3d8c: SaveReg r16
    //     0xae3d8c: str             x16, [SP, #-8]!
    // 0xae3d90: r0 = _interpolate()
    //     0xae3d90: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae3d94: add             SP, SP, #8
    // 0xae3d98: mov             x1, x0
    // 0xae3d9c: ldur            x0, [fp, #-8]
    // 0xae3da0: stur            x1, [fp, #-0x18]
    // 0xae3da4: LoadField: r2 = r0->field_b
    //     0xae3da4: ldur            w2, [x0, #0xb]
    // 0xae3da8: DecompressPointer r2
    //     0xae3da8: add             x2, x2, HEAP, lsl #32
    // 0xae3dac: stur            x2, [fp, #-0x10]
    // 0xae3db0: LoadField: r3 = r0->field_f
    //     0xae3db0: ldur            w3, [x0, #0xf]
    // 0xae3db4: DecompressPointer r3
    //     0xae3db4: add             x3, x3, HEAP, lsl #32
    // 0xae3db8: LoadField: r4 = r3->field_b
    //     0xae3db8: ldur            w4, [x3, #0xb]
    // 0xae3dbc: DecompressPointer r4
    //     0xae3dbc: add             x4, x4, HEAP, lsl #32
    // 0xae3dc0: cmp             w2, w4
    // 0xae3dc4: b.ne            #0xae3dd4
    // 0xae3dc8: SaveReg r0
    //     0xae3dc8: str             x0, [SP, #-8]!
    // 0xae3dcc: r0 = _growToNextCapacity()
    //     0xae3dcc: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae3dd0: add             SP, SP, #8
    // 0xae3dd4: ldur            x0, [fp, #-0x10]
    // 0xae3dd8: ldur            x3, [fp, #-8]
    // 0xae3ddc: r2 = LoadInt32Instr(r0)
    //     0xae3ddc: sbfx            x2, x0, #1, #0x1f
    // 0xae3de0: add             x0, x2, #1
    // 0xae3de4: lsl             x1, x0, #1
    // 0xae3de8: StoreField: r3->field_b = r1
    //     0xae3de8: stur            w1, [x3, #0xb]
    // 0xae3dec: mov             x1, x2
    // 0xae3df0: cmp             x1, x0
    // 0xae3df4: b.hs            #0xae4494
    // 0xae3df8: LoadField: r1 = r3->field_f
    //     0xae3df8: ldur            w1, [x3, #0xf]
    // 0xae3dfc: DecompressPointer r1
    //     0xae3dfc: add             x1, x1, HEAP, lsl #32
    // 0xae3e00: ldur            x0, [fp, #-0x18]
    // 0xae3e04: ArrayStore: r1[r2] = r0  ; List_4
    //     0xae3e04: add             x25, x1, x2, lsl #2
    //     0xae3e08: add             x25, x25, #0xf
    //     0xae3e0c: str             w0, [x25]
    //     0xae3e10: tbz             w0, #0, #0xae3e2c
    //     0xae3e14: ldurb           w16, [x1, #-1]
    //     0xae3e18: ldurb           w17, [x0, #-1]
    //     0xae3e1c: and             x16, x17, x16, lsr #2
    //     0xae3e20: tst             x16, HEAP, lsr #32
    //     0xae3e24: b.eq            #0xae3e2c
    //     0xae3e28: bl              #0xd67e5c
    // 0xae3e2c: ldr             x0, [fp, #0x10]
    // 0xae3e30: r1 = Null
    //     0xae3e30: mov             x1, NULL
    // 0xae3e34: r2 = 4
    //     0xae3e34: mov             x2, #4
    // 0xae3e38: r0 = AllocateArray()
    //     0xae3e38: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae3e3c: stur            x0, [fp, #-0x10]
    // 0xae3e40: r17 = "crossAxisExtent: "
    //     0xae3e40: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fc08] "crossAxisExtent: "
    //     0xae3e44: ldr             x17, [x17, #0xc08]
    // 0xae3e48: StoreField: r0->field_f = r17
    //     0xae3e48: stur            w17, [x0, #0xf]
    // 0xae3e4c: ldr             x1, [fp, #0x10]
    // 0xae3e50: LoadField: d0 = r1->field_33
    //     0xae3e50: ldur            d0, [x1, #0x33]
    // 0xae3e54: r2 = inline_Allocate_Double()
    //     0xae3e54: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xae3e58: add             x2, x2, #0x10
    //     0xae3e5c: cmp             x3, x2
    //     0xae3e60: b.ls            #0xae4498
    //     0xae3e64: str             x2, [THR, #0x60]  ; THR::top
    //     0xae3e68: sub             x2, x2, #0xf
    //     0xae3e6c: mov             x3, #0xd108
    //     0xae3e70: movk            x3, #3, lsl #16
    //     0xae3e74: stur            x3, [x2, #-1]
    // 0xae3e78: StoreField: r2->field_7 = d0
    //     0xae3e78: stur            d0, [x2, #7]
    // 0xae3e7c: SaveReg r2
    //     0xae3e7c: str             x2, [SP, #-8]!
    // 0xae3e80: r2 = 1
    //     0xae3e80: mov             x2, #1
    // 0xae3e84: SaveReg r2
    //     0xae3e84: str             x2, [SP, #-8]!
    // 0xae3e88: r0 = toStringAsFixed()
    //     0xae3e88: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae3e8c: add             SP, SP, #0x10
    // 0xae3e90: ldur            x1, [fp, #-0x10]
    // 0xae3e94: ArrayStore: r1[1] = r0  ; List_4
    //     0xae3e94: add             x25, x1, #0x13
    //     0xae3e98: str             w0, [x25]
    //     0xae3e9c: tbz             w0, #0, #0xae3eb8
    //     0xae3ea0: ldurb           w16, [x1, #-1]
    //     0xae3ea4: ldurb           w17, [x0, #-1]
    //     0xae3ea8: and             x16, x17, x16, lsr #2
    //     0xae3eac: tst             x16, HEAP, lsr #32
    //     0xae3eb0: b.eq            #0xae3eb8
    //     0xae3eb4: bl              #0xd67e5c
    // 0xae3eb8: ldur            x16, [fp, #-0x10]
    // 0xae3ebc: SaveReg r16
    //     0xae3ebc: str             x16, [SP, #-8]!
    // 0xae3ec0: r0 = _interpolate()
    //     0xae3ec0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae3ec4: add             SP, SP, #8
    // 0xae3ec8: mov             x1, x0
    // 0xae3ecc: ldur            x0, [fp, #-8]
    // 0xae3ed0: stur            x1, [fp, #-0x18]
    // 0xae3ed4: LoadField: r2 = r0->field_b
    //     0xae3ed4: ldur            w2, [x0, #0xb]
    // 0xae3ed8: DecompressPointer r2
    //     0xae3ed8: add             x2, x2, HEAP, lsl #32
    // 0xae3edc: stur            x2, [fp, #-0x10]
    // 0xae3ee0: LoadField: r3 = r0->field_f
    //     0xae3ee0: ldur            w3, [x0, #0xf]
    // 0xae3ee4: DecompressPointer r3
    //     0xae3ee4: add             x3, x3, HEAP, lsl #32
    // 0xae3ee8: LoadField: r4 = r3->field_b
    //     0xae3ee8: ldur            w4, [x3, #0xb]
    // 0xae3eec: DecompressPointer r4
    //     0xae3eec: add             x4, x4, HEAP, lsl #32
    // 0xae3ef0: cmp             w2, w4
    // 0xae3ef4: b.ne            #0xae3f04
    // 0xae3ef8: SaveReg r0
    //     0xae3ef8: str             x0, [SP, #-8]!
    // 0xae3efc: r0 = _growToNextCapacity()
    //     0xae3efc: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae3f00: add             SP, SP, #8
    // 0xae3f04: ldr             x4, [fp, #0x10]
    // 0xae3f08: ldur            x0, [fp, #-0x10]
    // 0xae3f0c: ldur            x3, [fp, #-8]
    // 0xae3f10: r2 = LoadInt32Instr(r0)
    //     0xae3f10: sbfx            x2, x0, #1, #0x1f
    // 0xae3f14: add             x0, x2, #1
    // 0xae3f18: lsl             x1, x0, #1
    // 0xae3f1c: StoreField: r3->field_b = r1
    //     0xae3f1c: stur            w1, [x3, #0xb]
    // 0xae3f20: mov             x1, x2
    // 0xae3f24: cmp             x1, x0
    // 0xae3f28: b.hs            #0xae44b4
    // 0xae3f2c: LoadField: r1 = r3->field_f
    //     0xae3f2c: ldur            w1, [x3, #0xf]
    // 0xae3f30: DecompressPointer r1
    //     0xae3f30: add             x1, x1, HEAP, lsl #32
    // 0xae3f34: ldur            x0, [fp, #-0x18]
    // 0xae3f38: ArrayStore: r1[r2] = r0  ; List_4
    //     0xae3f38: add             x25, x1, x2, lsl #2
    //     0xae3f3c: add             x25, x25, #0xf
    //     0xae3f40: str             w0, [x25]
    //     0xae3f44: tbz             w0, #0, #0xae3f60
    //     0xae3f48: ldurb           w16, [x1, #-1]
    //     0xae3f4c: ldurb           w17, [x0, #-1]
    //     0xae3f50: and             x16, x17, x16, lsr #2
    //     0xae3f54: tst             x16, HEAP, lsr #32
    //     0xae3f58: b.eq            #0xae3f60
    //     0xae3f5c: bl              #0xd67e5c
    // 0xae3f60: r1 = Null
    //     0xae3f60: mov             x1, NULL
    // 0xae3f64: r2 = 4
    //     0xae3f64: mov             x2, #4
    // 0xae3f68: r0 = AllocateArray()
    //     0xae3f68: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae3f6c: r17 = "crossAxisDirection: "
    //     0xae3f6c: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fc58] "crossAxisDirection: "
    //     0xae3f70: ldr             x17, [x17, #0xc58]
    // 0xae3f74: StoreField: r0->field_f = r17
    //     0xae3f74: stur            w17, [x0, #0xf]
    // 0xae3f78: ldr             x1, [fp, #0x10]
    // 0xae3f7c: LoadField: r2 = r1->field_3b
    //     0xae3f7c: ldur            w2, [x1, #0x3b]
    // 0xae3f80: DecompressPointer r2
    //     0xae3f80: add             x2, x2, HEAP, lsl #32
    // 0xae3f84: StoreField: r0->field_13 = r2
    //     0xae3f84: stur            w2, [x0, #0x13]
    // 0xae3f88: SaveReg r0
    //     0xae3f88: str             x0, [SP, #-8]!
    // 0xae3f8c: r0 = _interpolate()
    //     0xae3f8c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae3f90: add             SP, SP, #8
    // 0xae3f94: mov             x1, x0
    // 0xae3f98: ldur            x0, [fp, #-8]
    // 0xae3f9c: stur            x1, [fp, #-0x18]
    // 0xae3fa0: LoadField: r2 = r0->field_b
    //     0xae3fa0: ldur            w2, [x0, #0xb]
    // 0xae3fa4: DecompressPointer r2
    //     0xae3fa4: add             x2, x2, HEAP, lsl #32
    // 0xae3fa8: stur            x2, [fp, #-0x10]
    // 0xae3fac: LoadField: r3 = r0->field_f
    //     0xae3fac: ldur            w3, [x0, #0xf]
    // 0xae3fb0: DecompressPointer r3
    //     0xae3fb0: add             x3, x3, HEAP, lsl #32
    // 0xae3fb4: LoadField: r4 = r3->field_b
    //     0xae3fb4: ldur            w4, [x3, #0xb]
    // 0xae3fb8: DecompressPointer r4
    //     0xae3fb8: add             x4, x4, HEAP, lsl #32
    // 0xae3fbc: cmp             w2, w4
    // 0xae3fc0: b.ne            #0xae3fd0
    // 0xae3fc4: SaveReg r0
    //     0xae3fc4: str             x0, [SP, #-8]!
    // 0xae3fc8: r0 = _growToNextCapacity()
    //     0xae3fc8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae3fcc: add             SP, SP, #8
    // 0xae3fd0: ldr             x4, [fp, #0x10]
    // 0xae3fd4: ldur            x0, [fp, #-0x10]
    // 0xae3fd8: ldur            x3, [fp, #-8]
    // 0xae3fdc: r2 = LoadInt32Instr(r0)
    //     0xae3fdc: sbfx            x2, x0, #1, #0x1f
    // 0xae3fe0: add             x0, x2, #1
    // 0xae3fe4: lsl             x1, x0, #1
    // 0xae3fe8: StoreField: r3->field_b = r1
    //     0xae3fe8: stur            w1, [x3, #0xb]
    // 0xae3fec: mov             x1, x2
    // 0xae3ff0: cmp             x1, x0
    // 0xae3ff4: b.hs            #0xae44b8
    // 0xae3ff8: LoadField: r1 = r3->field_f
    //     0xae3ff8: ldur            w1, [x3, #0xf]
    // 0xae3ffc: DecompressPointer r1
    //     0xae3ffc: add             x1, x1, HEAP, lsl #32
    // 0xae4000: ldur            x0, [fp, #-0x18]
    // 0xae4004: ArrayStore: r1[r2] = r0  ; List_4
    //     0xae4004: add             x25, x1, x2, lsl #2
    //     0xae4008: add             x25, x25, #0xf
    //     0xae400c: str             w0, [x25]
    //     0xae4010: tbz             w0, #0, #0xae402c
    //     0xae4014: ldurb           w16, [x1, #-1]
    //     0xae4018: ldurb           w17, [x0, #-1]
    //     0xae401c: and             x16, x17, x16, lsr #2
    //     0xae4020: tst             x16, HEAP, lsr #32
    //     0xae4024: b.eq            #0xae402c
    //     0xae4028: bl              #0xd67e5c
    // 0xae402c: r1 = Null
    //     0xae402c: mov             x1, NULL
    // 0xae4030: r2 = 4
    //     0xae4030: mov             x2, #4
    // 0xae4034: r0 = AllocateArray()
    //     0xae4034: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae4038: stur            x0, [fp, #-0x10]
    // 0xae403c: r17 = "viewportMainAxisExtent: "
    //     0xae403c: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fc60] "viewportMainAxisExtent: "
    //     0xae4040: ldr             x17, [x17, #0xc60]
    // 0xae4044: StoreField: r0->field_f = r17
    //     0xae4044: stur            w17, [x0, #0xf]
    // 0xae4048: ldr             x1, [fp, #0x10]
    // 0xae404c: LoadField: d0 = r1->field_3f
    //     0xae404c: ldur            d0, [x1, #0x3f]
    // 0xae4050: r2 = inline_Allocate_Double()
    //     0xae4050: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xae4054: add             x2, x2, #0x10
    //     0xae4058: cmp             x3, x2
    //     0xae405c: b.ls            #0xae44bc
    //     0xae4060: str             x2, [THR, #0x60]  ; THR::top
    //     0xae4064: sub             x2, x2, #0xf
    //     0xae4068: mov             x3, #0xd108
    //     0xae406c: movk            x3, #3, lsl #16
    //     0xae4070: stur            x3, [x2, #-1]
    // 0xae4074: StoreField: r2->field_7 = d0
    //     0xae4074: stur            d0, [x2, #7]
    // 0xae4078: SaveReg r2
    //     0xae4078: str             x2, [SP, #-8]!
    // 0xae407c: r2 = 1
    //     0xae407c: mov             x2, #1
    // 0xae4080: SaveReg r2
    //     0xae4080: str             x2, [SP, #-8]!
    // 0xae4084: r0 = toStringAsFixed()
    //     0xae4084: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae4088: add             SP, SP, #0x10
    // 0xae408c: ldur            x1, [fp, #-0x10]
    // 0xae4090: ArrayStore: r1[1] = r0  ; List_4
    //     0xae4090: add             x25, x1, #0x13
    //     0xae4094: str             w0, [x25]
    //     0xae4098: tbz             w0, #0, #0xae40b4
    //     0xae409c: ldurb           w16, [x1, #-1]
    //     0xae40a0: ldurb           w17, [x0, #-1]
    //     0xae40a4: and             x16, x17, x16, lsr #2
    //     0xae40a8: tst             x16, HEAP, lsr #32
    //     0xae40ac: b.eq            #0xae40b4
    //     0xae40b0: bl              #0xd67e5c
    // 0xae40b4: ldur            x16, [fp, #-0x10]
    // 0xae40b8: SaveReg r16
    //     0xae40b8: str             x16, [SP, #-8]!
    // 0xae40bc: r0 = _interpolate()
    //     0xae40bc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae40c0: add             SP, SP, #8
    // 0xae40c4: mov             x1, x0
    // 0xae40c8: ldur            x0, [fp, #-8]
    // 0xae40cc: stur            x1, [fp, #-0x18]
    // 0xae40d0: LoadField: r2 = r0->field_b
    //     0xae40d0: ldur            w2, [x0, #0xb]
    // 0xae40d4: DecompressPointer r2
    //     0xae40d4: add             x2, x2, HEAP, lsl #32
    // 0xae40d8: stur            x2, [fp, #-0x10]
    // 0xae40dc: LoadField: r3 = r0->field_f
    //     0xae40dc: ldur            w3, [x0, #0xf]
    // 0xae40e0: DecompressPointer r3
    //     0xae40e0: add             x3, x3, HEAP, lsl #32
    // 0xae40e4: LoadField: r4 = r3->field_b
    //     0xae40e4: ldur            w4, [x3, #0xb]
    // 0xae40e8: DecompressPointer r4
    //     0xae40e8: add             x4, x4, HEAP, lsl #32
    // 0xae40ec: cmp             w2, w4
    // 0xae40f0: b.ne            #0xae4100
    // 0xae40f4: SaveReg r0
    //     0xae40f4: str             x0, [SP, #-8]!
    // 0xae40f8: r0 = _growToNextCapacity()
    //     0xae40f8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae40fc: add             SP, SP, #8
    // 0xae4100: ldr             x4, [fp, #0x10]
    // 0xae4104: ldur            x0, [fp, #-0x10]
    // 0xae4108: ldur            x3, [fp, #-8]
    // 0xae410c: r2 = LoadInt32Instr(r0)
    //     0xae410c: sbfx            x2, x0, #1, #0x1f
    // 0xae4110: add             x0, x2, #1
    // 0xae4114: lsl             x1, x0, #1
    // 0xae4118: StoreField: r3->field_b = r1
    //     0xae4118: stur            w1, [x3, #0xb]
    // 0xae411c: mov             x1, x2
    // 0xae4120: cmp             x1, x0
    // 0xae4124: b.hs            #0xae44d8
    // 0xae4128: LoadField: r1 = r3->field_f
    //     0xae4128: ldur            w1, [x3, #0xf]
    // 0xae412c: DecompressPointer r1
    //     0xae412c: add             x1, x1, HEAP, lsl #32
    // 0xae4130: ldur            x0, [fp, #-0x18]
    // 0xae4134: ArrayStore: r1[r2] = r0  ; List_4
    //     0xae4134: add             x25, x1, x2, lsl #2
    //     0xae4138: add             x25, x25, #0xf
    //     0xae413c: str             w0, [x25]
    //     0xae4140: tbz             w0, #0, #0xae415c
    //     0xae4144: ldurb           w16, [x1, #-1]
    //     0xae4148: ldurb           w17, [x0, #-1]
    //     0xae414c: and             x16, x17, x16, lsr #2
    //     0xae4150: tst             x16, HEAP, lsr #32
    //     0xae4154: b.eq            #0xae415c
    //     0xae4158: bl              #0xd67e5c
    // 0xae415c: r1 = Null
    //     0xae415c: mov             x1, NULL
    // 0xae4160: r2 = 4
    //     0xae4160: mov             x2, #4
    // 0xae4164: r0 = AllocateArray()
    //     0xae4164: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae4168: stur            x0, [fp, #-0x10]
    // 0xae416c: r17 = "remainingCacheExtent: "
    //     0xae416c: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fc68] "remainingCacheExtent: "
    //     0xae4170: ldr             x17, [x17, #0xc68]
    // 0xae4174: StoreField: r0->field_f = r17
    //     0xae4174: stur            w17, [x0, #0xf]
    // 0xae4178: ldr             x1, [fp, #0x10]
    // 0xae417c: LoadField: d0 = r1->field_4f
    //     0xae417c: ldur            d0, [x1, #0x4f]
    // 0xae4180: r2 = inline_Allocate_Double()
    //     0xae4180: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xae4184: add             x2, x2, #0x10
    //     0xae4188: cmp             x3, x2
    //     0xae418c: b.ls            #0xae44dc
    //     0xae4190: str             x2, [THR, #0x60]  ; THR::top
    //     0xae4194: sub             x2, x2, #0xf
    //     0xae4198: mov             x3, #0xd108
    //     0xae419c: movk            x3, #3, lsl #16
    //     0xae41a0: stur            x3, [x2, #-1]
    // 0xae41a4: StoreField: r2->field_7 = d0
    //     0xae41a4: stur            d0, [x2, #7]
    // 0xae41a8: SaveReg r2
    //     0xae41a8: str             x2, [SP, #-8]!
    // 0xae41ac: r2 = 1
    //     0xae41ac: mov             x2, #1
    // 0xae41b0: SaveReg r2
    //     0xae41b0: str             x2, [SP, #-8]!
    // 0xae41b4: r0 = toStringAsFixed()
    //     0xae41b4: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae41b8: add             SP, SP, #0x10
    // 0xae41bc: ldur            x1, [fp, #-0x10]
    // 0xae41c0: ArrayStore: r1[1] = r0  ; List_4
    //     0xae41c0: add             x25, x1, #0x13
    //     0xae41c4: str             w0, [x25]
    //     0xae41c8: tbz             w0, #0, #0xae41e4
    //     0xae41cc: ldurb           w16, [x1, #-1]
    //     0xae41d0: ldurb           w17, [x0, #-1]
    //     0xae41d4: and             x16, x17, x16, lsr #2
    //     0xae41d8: tst             x16, HEAP, lsr #32
    //     0xae41dc: b.eq            #0xae41e4
    //     0xae41e0: bl              #0xd67e5c
    // 0xae41e4: ldur            x16, [fp, #-0x10]
    // 0xae41e8: SaveReg r16
    //     0xae41e8: str             x16, [SP, #-8]!
    // 0xae41ec: r0 = _interpolate()
    //     0xae41ec: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae41f0: add             SP, SP, #8
    // 0xae41f4: mov             x1, x0
    // 0xae41f8: ldur            x0, [fp, #-8]
    // 0xae41fc: stur            x1, [fp, #-0x18]
    // 0xae4200: LoadField: r2 = r0->field_b
    //     0xae4200: ldur            w2, [x0, #0xb]
    // 0xae4204: DecompressPointer r2
    //     0xae4204: add             x2, x2, HEAP, lsl #32
    // 0xae4208: stur            x2, [fp, #-0x10]
    // 0xae420c: LoadField: r3 = r0->field_f
    //     0xae420c: ldur            w3, [x0, #0xf]
    // 0xae4210: DecompressPointer r3
    //     0xae4210: add             x3, x3, HEAP, lsl #32
    // 0xae4214: LoadField: r4 = r3->field_b
    //     0xae4214: ldur            w4, [x3, #0xb]
    // 0xae4218: DecompressPointer r4
    //     0xae4218: add             x4, x4, HEAP, lsl #32
    // 0xae421c: cmp             w2, w4
    // 0xae4220: b.ne            #0xae4230
    // 0xae4224: SaveReg r0
    //     0xae4224: str             x0, [SP, #-8]!
    // 0xae4228: r0 = _growToNextCapacity()
    //     0xae4228: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae422c: add             SP, SP, #8
    // 0xae4230: ldr             x4, [fp, #0x10]
    // 0xae4234: ldur            x0, [fp, #-0x10]
    // 0xae4238: ldur            x3, [fp, #-8]
    // 0xae423c: r2 = LoadInt32Instr(r0)
    //     0xae423c: sbfx            x2, x0, #1, #0x1f
    // 0xae4240: add             x0, x2, #1
    // 0xae4244: lsl             x1, x0, #1
    // 0xae4248: StoreField: r3->field_b = r1
    //     0xae4248: stur            w1, [x3, #0xb]
    // 0xae424c: mov             x1, x2
    // 0xae4250: cmp             x1, x0
    // 0xae4254: b.hs            #0xae44f8
    // 0xae4258: LoadField: r1 = r3->field_f
    //     0xae4258: ldur            w1, [x3, #0xf]
    // 0xae425c: DecompressPointer r1
    //     0xae425c: add             x1, x1, HEAP, lsl #32
    // 0xae4260: ldur            x0, [fp, #-0x18]
    // 0xae4264: ArrayStore: r1[r2] = r0  ; List_4
    //     0xae4264: add             x25, x1, x2, lsl #2
    //     0xae4268: add             x25, x25, #0xf
    //     0xae426c: str             w0, [x25]
    //     0xae4270: tbz             w0, #0, #0xae428c
    //     0xae4274: ldurb           w16, [x1, #-1]
    //     0xae4278: ldurb           w17, [x0, #-1]
    //     0xae427c: and             x16, x17, x16, lsr #2
    //     0xae4280: tst             x16, HEAP, lsr #32
    //     0xae4284: b.eq            #0xae428c
    //     0xae4288: bl              #0xd67e5c
    // 0xae428c: r1 = Null
    //     0xae428c: mov             x1, NULL
    // 0xae4290: r2 = 4
    //     0xae4290: mov             x2, #4
    // 0xae4294: r0 = AllocateArray()
    //     0xae4294: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae4298: stur            x0, [fp, #-0x10]
    // 0xae429c: r17 = "cacheOrigin: "
    //     0xae429c: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fc70] "cacheOrigin: "
    //     0xae42a0: ldr             x17, [x17, #0xc70]
    // 0xae42a4: StoreField: r0->field_f = r17
    //     0xae42a4: stur            w17, [x0, #0xf]
    // 0xae42a8: ldr             x1, [fp, #0x10]
    // 0xae42ac: LoadField: d0 = r1->field_47
    //     0xae42ac: ldur            d0, [x1, #0x47]
    // 0xae42b0: r1 = inline_Allocate_Double()
    //     0xae42b0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xae42b4: add             x1, x1, #0x10
    //     0xae42b8: cmp             x2, x1
    //     0xae42bc: b.ls            #0xae44fc
    //     0xae42c0: str             x1, [THR, #0x60]  ; THR::top
    //     0xae42c4: sub             x1, x1, #0xf
    //     0xae42c8: mov             x2, #0xd108
    //     0xae42cc: movk            x2, #3, lsl #16
    //     0xae42d0: stur            x2, [x1, #-1]
    // 0xae42d4: StoreField: r1->field_7 = d0
    //     0xae42d4: stur            d0, [x1, #7]
    // 0xae42d8: SaveReg r1
    //     0xae42d8: str             x1, [SP, #-8]!
    // 0xae42dc: r1 = 1
    //     0xae42dc: mov             x1, #1
    // 0xae42e0: SaveReg r1
    //     0xae42e0: str             x1, [SP, #-8]!
    // 0xae42e4: r0 = toStringAsFixed()
    //     0xae42e4: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae42e8: add             SP, SP, #0x10
    // 0xae42ec: ldur            x1, [fp, #-0x10]
    // 0xae42f0: ArrayStore: r1[1] = r0  ; List_4
    //     0xae42f0: add             x25, x1, #0x13
    //     0xae42f4: str             w0, [x25]
    //     0xae42f8: tbz             w0, #0, #0xae4314
    //     0xae42fc: ldurb           w16, [x1, #-1]
    //     0xae4300: ldurb           w17, [x0, #-1]
    //     0xae4304: and             x16, x17, x16, lsr #2
    //     0xae4308: tst             x16, HEAP, lsr #32
    //     0xae430c: b.eq            #0xae4314
    //     0xae4310: bl              #0xd67e5c
    // 0xae4314: ldur            x16, [fp, #-0x10]
    // 0xae4318: SaveReg r16
    //     0xae4318: str             x16, [SP, #-8]!
    // 0xae431c: r0 = _interpolate()
    //     0xae431c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae4320: add             SP, SP, #8
    // 0xae4324: mov             x1, x0
    // 0xae4328: ldur            x0, [fp, #-8]
    // 0xae432c: stur            x1, [fp, #-0x18]
    // 0xae4330: LoadField: r2 = r0->field_b
    //     0xae4330: ldur            w2, [x0, #0xb]
    // 0xae4334: DecompressPointer r2
    //     0xae4334: add             x2, x2, HEAP, lsl #32
    // 0xae4338: stur            x2, [fp, #-0x10]
    // 0xae433c: LoadField: r3 = r0->field_f
    //     0xae433c: ldur            w3, [x0, #0xf]
    // 0xae4340: DecompressPointer r3
    //     0xae4340: add             x3, x3, HEAP, lsl #32
    // 0xae4344: LoadField: r4 = r3->field_b
    //     0xae4344: ldur            w4, [x3, #0xb]
    // 0xae4348: DecompressPointer r4
    //     0xae4348: add             x4, x4, HEAP, lsl #32
    // 0xae434c: cmp             w2, w4
    // 0xae4350: b.ne            #0xae4360
    // 0xae4354: SaveReg r0
    //     0xae4354: str             x0, [SP, #-8]!
    // 0xae4358: r0 = _growToNextCapacity()
    //     0xae4358: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae435c: add             SP, SP, #8
    // 0xae4360: ldur            x0, [fp, #-0x10]
    // 0xae4364: ldur            x3, [fp, #-8]
    // 0xae4368: r2 = LoadInt32Instr(r0)
    //     0xae4368: sbfx            x2, x0, #1, #0x1f
    // 0xae436c: add             x0, x2, #1
    // 0xae4370: lsl             x1, x0, #1
    // 0xae4374: StoreField: r3->field_b = r1
    //     0xae4374: stur            w1, [x3, #0xb]
    // 0xae4378: mov             x1, x2
    // 0xae437c: cmp             x1, x0
    // 0xae4380: b.hs            #0xae4518
    // 0xae4384: LoadField: r1 = r3->field_f
    //     0xae4384: ldur            w1, [x3, #0xf]
    // 0xae4388: DecompressPointer r1
    //     0xae4388: add             x1, x1, HEAP, lsl #32
    // 0xae438c: ldur            x0, [fp, #-0x18]
    // 0xae4390: ArrayStore: r1[r2] = r0  ; List_4
    //     0xae4390: add             x25, x1, x2, lsl #2
    //     0xae4394: add             x25, x25, #0xf
    //     0xae4398: str             w0, [x25]
    //     0xae439c: tbz             w0, #0, #0xae43b8
    //     0xae43a0: ldurb           w16, [x1, #-1]
    //     0xae43a4: ldurb           w17, [x0, #-1]
    //     0xae43a8: and             x16, x17, x16, lsr #2
    //     0xae43ac: tst             x16, HEAP, lsr #32
    //     0xae43b0: b.eq            #0xae43b8
    //     0xae43b4: bl              #0xd67e5c
    // 0xae43b8: r1 = Null
    //     0xae43b8: mov             x1, NULL
    // 0xae43bc: r2 = 6
    //     0xae43bc: mov             x2, #6
    // 0xae43c0: r0 = AllocateArray()
    //     0xae43c0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae43c4: stur            x0, [fp, #-0x10]
    // 0xae43c8: r17 = "SliverConstraints("
    //     0xae43c8: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fc78] "SliverConstraints("
    //     0xae43cc: ldr             x17, [x17, #0xc78]
    // 0xae43d0: StoreField: r0->field_f = r17
    //     0xae43d0: stur            w17, [x0, #0xf]
    // 0xae43d4: ldur            x16, [fp, #-8]
    // 0xae43d8: r30 = ", "
    //     0xae43d8: ldr             lr, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae43dc: stp             lr, x16, [SP, #-0x10]!
    // 0xae43e0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xae43e0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xae43e4: r0 = join()
    //     0xae43e4: bl              #0x6fddb0  ; [dart:core] _GrowableList::join
    // 0xae43e8: add             SP, SP, #0x10
    // 0xae43ec: ldur            x1, [fp, #-0x10]
    // 0xae43f0: ArrayStore: r1[1] = r0  ; List_4
    //     0xae43f0: add             x25, x1, #0x13
    //     0xae43f4: str             w0, [x25]
    //     0xae43f8: tbz             w0, #0, #0xae4414
    //     0xae43fc: ldurb           w16, [x1, #-1]
    //     0xae4400: ldurb           w17, [x0, #-1]
    //     0xae4404: and             x16, x17, x16, lsr #2
    //     0xae4408: tst             x16, HEAP, lsr #32
    //     0xae440c: b.eq            #0xae4414
    //     0xae4410: bl              #0xd67e5c
    // 0xae4414: ldur            x0, [fp, #-0x10]
    // 0xae4418: r17 = ")"
    //     0xae4418: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae441c: StoreField: r0->field_17 = r17
    //     0xae441c: stur            w17, [x0, #0x17]
    // 0xae4420: SaveReg r0
    //     0xae4420: str             x0, [SP, #-8]!
    // 0xae4424: r0 = _interpolate()
    //     0xae4424: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae4428: add             SP, SP, #8
    // 0xae442c: LeaveFrame
    //     0xae442c: mov             SP, fp
    //     0xae4430: ldp             fp, lr, [SP], #0x10
    // 0xae4434: ret
    //     0xae4434: ret             
    // 0xae4438: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae4438: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae443c: b               #0xae3afc
    // 0xae4440: SaveReg d0
    //     0xae4440: str             q0, [SP, #-0x10]!
    // 0xae4444: stp             x0, x1, [SP, #-0x10]!
    // 0xae4448: r0 = AllocateDouble()
    //     0xae4448: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae444c: mov             x2, x0
    // 0xae4450: ldp             x0, x1, [SP], #0x10
    // 0xae4454: RestoreReg d0
    //     0xae4454: ldr             q0, [SP], #0x10
    // 0xae4458: b               #0xae3ba0
    // 0xae445c: SaveReg d0
    //     0xae445c: str             q0, [SP, #-0x10]!
    // 0xae4460: stp             x0, x1, [SP, #-0x10]!
    // 0xae4464: r0 = AllocateDouble()
    //     0xae4464: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae4468: mov             x2, x0
    // 0xae446c: ldp             x0, x1, [SP], #0x10
    // 0xae4470: RestoreReg d0
    //     0xae4470: ldr             q0, [SP], #0x10
    // 0xae4474: b               #0xae3c3c
    // 0xae4478: SaveReg d0
    //     0xae4478: str             q0, [SP, #-0x10]!
    // 0xae447c: SaveReg r0
    //     0xae447c: str             x0, [SP, #-8]!
    // 0xae4480: r0 = AllocateDouble()
    //     0xae4480: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae4484: mov             x1, x0
    // 0xae4488: RestoreReg r0
    //     0xae4488: ldr             x0, [SP], #8
    // 0xae448c: RestoreReg d0
    //     0xae448c: ldr             q0, [SP], #0x10
    // 0xae4490: b               #0xae3d48
    // 0xae4494: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae4494: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xae4498: SaveReg d0
    //     0xae4498: str             q0, [SP, #-0x10]!
    // 0xae449c: stp             x0, x1, [SP, #-0x10]!
    // 0xae44a0: r0 = AllocateDouble()
    //     0xae44a0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae44a4: mov             x2, x0
    // 0xae44a8: ldp             x0, x1, [SP], #0x10
    // 0xae44ac: RestoreReg d0
    //     0xae44ac: ldr             q0, [SP], #0x10
    // 0xae44b0: b               #0xae3e78
    // 0xae44b4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae44b4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xae44b8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae44b8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xae44bc: SaveReg d0
    //     0xae44bc: str             q0, [SP, #-0x10]!
    // 0xae44c0: stp             x0, x1, [SP, #-0x10]!
    // 0xae44c4: r0 = AllocateDouble()
    //     0xae44c4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae44c8: mov             x2, x0
    // 0xae44cc: ldp             x0, x1, [SP], #0x10
    // 0xae44d0: RestoreReg d0
    //     0xae44d0: ldr             q0, [SP], #0x10
    // 0xae44d4: b               #0xae4074
    // 0xae44d8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae44d8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xae44dc: SaveReg d0
    //     0xae44dc: str             q0, [SP, #-0x10]!
    // 0xae44e0: stp             x0, x1, [SP, #-0x10]!
    // 0xae44e4: r0 = AllocateDouble()
    //     0xae44e4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae44e8: mov             x2, x0
    // 0xae44ec: ldp             x0, x1, [SP], #0x10
    // 0xae44f0: RestoreReg d0
    //     0xae44f0: ldr             q0, [SP], #0x10
    // 0xae44f4: b               #0xae41a4
    // 0xae44f8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae44f8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xae44fc: SaveReg d0
    //     0xae44fc: str             q0, [SP, #-0x10]!
    // 0xae4500: SaveReg r0
    //     0xae4500: str             x0, [SP, #-8]!
    // 0xae4504: r0 = AllocateDouble()
    //     0xae4504: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae4508: mov             x1, x0
    // 0xae450c: RestoreReg r0
    //     0xae450c: ldr             x0, [SP], #8
    // 0xae4510: RestoreReg d0
    //     0xae4510: ldr             q0, [SP], #0x10
    // 0xae4514: b               #0xae42d4
    // 0xae4518: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae4518: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb0ee30, size: 0x338
    // 0xb0ee30: EnterFrame
    //     0xb0ee30: stp             fp, lr, [SP, #-0x10]!
    //     0xb0ee34: mov             fp, SP
    // 0xb0ee38: CheckStackOverflow
    //     0xb0ee38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0ee3c: cmp             SP, x16
    //     0xb0ee40: b.ls            #0xb0efd8
    // 0xb0ee44: ldr             x0, [fp, #0x10]
    // 0xb0ee48: LoadField: r1 = r0->field_7
    //     0xb0ee48: ldur            w1, [x0, #7]
    // 0xb0ee4c: DecompressPointer r1
    //     0xb0ee4c: add             x1, x1, HEAP, lsl #32
    // 0xb0ee50: LoadField: r2 = r0->field_b
    //     0xb0ee50: ldur            w2, [x0, #0xb]
    // 0xb0ee54: DecompressPointer r2
    //     0xb0ee54: add             x2, x2, HEAP, lsl #32
    // 0xb0ee58: LoadField: d0 = r0->field_13
    //     0xb0ee58: ldur            d0, [x0, #0x13]
    // 0xb0ee5c: LoadField: d1 = r0->field_23
    //     0xb0ee5c: ldur            d1, [x0, #0x23]
    // 0xb0ee60: LoadField: d2 = r0->field_2b
    //     0xb0ee60: ldur            d2, [x0, #0x2b]
    // 0xb0ee64: LoadField: d3 = r0->field_33
    //     0xb0ee64: ldur            d3, [x0, #0x33]
    // 0xb0ee68: LoadField: r3 = r0->field_3b
    //     0xb0ee68: ldur            w3, [x0, #0x3b]
    // 0xb0ee6c: DecompressPointer r3
    //     0xb0ee6c: add             x3, x3, HEAP, lsl #32
    // 0xb0ee70: LoadField: d4 = r0->field_3f
    //     0xb0ee70: ldur            d4, [x0, #0x3f]
    // 0xb0ee74: LoadField: d5 = r0->field_4f
    //     0xb0ee74: ldur            d5, [x0, #0x4f]
    // 0xb0ee78: LoadField: d6 = r0->field_47
    //     0xb0ee78: ldur            d6, [x0, #0x47]
    // 0xb0ee7c: r0 = inline_Allocate_Double()
    //     0xb0ee7c: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0xb0ee80: add             x0, x0, #0x10
    //     0xb0ee84: cmp             x4, x0
    //     0xb0ee88: b.ls            #0xb0efe0
    //     0xb0ee8c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb0ee90: sub             x0, x0, #0xf
    //     0xb0ee94: mov             x4, #0xd108
    //     0xb0ee98: movk            x4, #3, lsl #16
    //     0xb0ee9c: stur            x4, [x0, #-1]
    // 0xb0eea0: StoreField: r0->field_7 = d0
    //     0xb0eea0: stur            d0, [x0, #7]
    // 0xb0eea4: r4 = inline_Allocate_Double()
    //     0xb0eea4: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xb0eea8: add             x4, x4, #0x10
    //     0xb0eeac: cmp             x5, x4
    //     0xb0eeb0: b.ls            #0xb0f018
    //     0xb0eeb4: str             x4, [THR, #0x60]  ; THR::top
    //     0xb0eeb8: sub             x4, x4, #0xf
    //     0xb0eebc: mov             x5, #0xd108
    //     0xb0eec0: movk            x5, #3, lsl #16
    //     0xb0eec4: stur            x5, [x4, #-1]
    // 0xb0eec8: StoreField: r4->field_7 = d1
    //     0xb0eec8: stur            d1, [x4, #7]
    // 0xb0eecc: r5 = inline_Allocate_Double()
    //     0xb0eecc: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0xb0eed0: add             x5, x5, #0x10
    //     0xb0eed4: cmp             x6, x5
    //     0xb0eed8: b.ls            #0xb0f04c
    //     0xb0eedc: str             x5, [THR, #0x60]  ; THR::top
    //     0xb0eee0: sub             x5, x5, #0xf
    //     0xb0eee4: mov             x6, #0xd108
    //     0xb0eee8: movk            x6, #3, lsl #16
    //     0xb0eeec: stur            x6, [x5, #-1]
    // 0xb0eef0: StoreField: r5->field_7 = d2
    //     0xb0eef0: stur            d2, [x5, #7]
    // 0xb0eef4: r6 = inline_Allocate_Double()
    //     0xb0eef4: ldp             x6, x7, [THR, #0x60]  ; THR::top
    //     0xb0eef8: add             x6, x6, #0x10
    //     0xb0eefc: cmp             x7, x6
    //     0xb0ef00: b.ls            #0xb0f088
    //     0xb0ef04: str             x6, [THR, #0x60]  ; THR::top
    //     0xb0ef08: sub             x6, x6, #0xf
    //     0xb0ef0c: mov             x7, #0xd108
    //     0xb0ef10: movk            x7, #3, lsl #16
    //     0xb0ef14: stur            x7, [x6, #-1]
    // 0xb0ef18: StoreField: r6->field_7 = d3
    //     0xb0ef18: stur            d3, [x6, #7]
    // 0xb0ef1c: r7 = inline_Allocate_Double()
    //     0xb0ef1c: ldp             x7, x8, [THR, #0x60]  ; THR::top
    //     0xb0ef20: add             x7, x7, #0x10
    //     0xb0ef24: cmp             x8, x7
    //     0xb0ef28: b.ls            #0xb0f0bc
    //     0xb0ef2c: str             x7, [THR, #0x60]  ; THR::top
    //     0xb0ef30: sub             x7, x7, #0xf
    //     0xb0ef34: mov             x8, #0xd108
    //     0xb0ef38: movk            x8, #3, lsl #16
    //     0xb0ef3c: stur            x8, [x7, #-1]
    // 0xb0ef40: StoreField: r7->field_7 = d4
    //     0xb0ef40: stur            d4, [x7, #7]
    // 0xb0ef44: r8 = inline_Allocate_Double()
    //     0xb0ef44: ldp             x8, x9, [THR, #0x60]  ; THR::top
    //     0xb0ef48: add             x8, x8, #0x10
    //     0xb0ef4c: cmp             x9, x8
    //     0xb0ef50: b.ls            #0xb0f0f8
    //     0xb0ef54: str             x8, [THR, #0x60]  ; THR::top
    //     0xb0ef58: sub             x8, x8, #0xf
    //     0xb0ef5c: mov             x9, #0xd108
    //     0xb0ef60: movk            x9, #3, lsl #16
    //     0xb0ef64: stur            x9, [x8, #-1]
    // 0xb0ef68: StoreField: r8->field_7 = d5
    //     0xb0ef68: stur            d5, [x8, #7]
    // 0xb0ef6c: r9 = inline_Allocate_Double()
    //     0xb0ef6c: ldp             x9, x10, [THR, #0x60]  ; THR::top
    //     0xb0ef70: add             x9, x9, #0x10
    //     0xb0ef74: cmp             x10, x9
    //     0xb0ef78: b.ls            #0xb0f12c
    //     0xb0ef7c: str             x9, [THR, #0x60]  ; THR::top
    //     0xb0ef80: sub             x9, x9, #0xf
    //     0xb0ef84: mov             x10, #0xd108
    //     0xb0ef88: movk            x10, #3, lsl #16
    //     0xb0ef8c: stur            x10, [x9, #-1]
    // 0xb0ef90: StoreField: r9->field_7 = d6
    //     0xb0ef90: stur            d6, [x9, #7]
    // 0xb0ef94: stp             x2, x1, [SP, #-0x10]!
    // 0xb0ef98: stp             x4, x0, [SP, #-0x10]!
    // 0xb0ef9c: stp             x6, x5, [SP, #-0x10]!
    // 0xb0efa0: stp             x7, x3, [SP, #-0x10]!
    // 0xb0efa4: stp             x9, x8, [SP, #-0x10]!
    // 0xb0efa8: r4 = const [0, 0xa, 0xa, 0xa, null]
    //     0xb0efa8: ldr             x4, [PP, #0x2558]  ; [pp+0x2558] List(5) [0, 0xa, 0xa, 0xa, Null]
    // 0xb0efac: r0 = hash()
    //     0xb0efac: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0efb0: add             SP, SP, #0x50
    // 0xb0efb4: mov             x2, x0
    // 0xb0efb8: r0 = BoxInt64Instr(r2)
    //     0xb0efb8: sbfiz           x0, x2, #1, #0x1f
    //     0xb0efbc: cmp             x2, x0, asr #1
    //     0xb0efc0: b.eq            #0xb0efcc
    //     0xb0efc4: bl              #0xd69bb8
    //     0xb0efc8: stur            x2, [x0, #7]
    // 0xb0efcc: LeaveFrame
    //     0xb0efcc: mov             SP, fp
    //     0xb0efd0: ldp             fp, lr, [SP], #0x10
    // 0xb0efd4: ret
    //     0xb0efd4: ret             
    // 0xb0efd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0efd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0efdc: b               #0xb0ee44
    // 0xb0efe0: stp             q5, q6, [SP, #-0x20]!
    // 0xb0efe4: stp             q3, q4, [SP, #-0x20]!
    // 0xb0efe8: stp             q1, q2, [SP, #-0x20]!
    // 0xb0efec: SaveReg d0
    //     0xb0efec: str             q0, [SP, #-0x10]!
    // 0xb0eff0: stp             x2, x3, [SP, #-0x10]!
    // 0xb0eff4: SaveReg r1
    //     0xb0eff4: str             x1, [SP, #-8]!
    // 0xb0eff8: r0 = AllocateDouble()
    //     0xb0eff8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0effc: RestoreReg r1
    //     0xb0effc: ldr             x1, [SP], #8
    // 0xb0f000: ldp             x2, x3, [SP], #0x10
    // 0xb0f004: RestoreReg d0
    //     0xb0f004: ldr             q0, [SP], #0x10
    // 0xb0f008: ldp             q1, q2, [SP], #0x20
    // 0xb0f00c: ldp             q3, q4, [SP], #0x20
    // 0xb0f010: ldp             q5, q6, [SP], #0x20
    // 0xb0f014: b               #0xb0eea0
    // 0xb0f018: stp             q5, q6, [SP, #-0x20]!
    // 0xb0f01c: stp             q3, q4, [SP, #-0x20]!
    // 0xb0f020: stp             q1, q2, [SP, #-0x20]!
    // 0xb0f024: stp             x2, x3, [SP, #-0x10]!
    // 0xb0f028: stp             x0, x1, [SP, #-0x10]!
    // 0xb0f02c: r0 = AllocateDouble()
    //     0xb0f02c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0f030: mov             x4, x0
    // 0xb0f034: ldp             x0, x1, [SP], #0x10
    // 0xb0f038: ldp             x2, x3, [SP], #0x10
    // 0xb0f03c: ldp             q1, q2, [SP], #0x20
    // 0xb0f040: ldp             q3, q4, [SP], #0x20
    // 0xb0f044: ldp             q5, q6, [SP], #0x20
    // 0xb0f048: b               #0xb0eec8
    // 0xb0f04c: stp             q5, q6, [SP, #-0x20]!
    // 0xb0f050: stp             q3, q4, [SP, #-0x20]!
    // 0xb0f054: SaveReg d2
    //     0xb0f054: str             q2, [SP, #-0x10]!
    // 0xb0f058: stp             x3, x4, [SP, #-0x10]!
    // 0xb0f05c: stp             x1, x2, [SP, #-0x10]!
    // 0xb0f060: SaveReg r0
    //     0xb0f060: str             x0, [SP, #-8]!
    // 0xb0f064: r0 = AllocateDouble()
    //     0xb0f064: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0f068: mov             x5, x0
    // 0xb0f06c: RestoreReg r0
    //     0xb0f06c: ldr             x0, [SP], #8
    // 0xb0f070: ldp             x1, x2, [SP], #0x10
    // 0xb0f074: ldp             x3, x4, [SP], #0x10
    // 0xb0f078: RestoreReg d2
    //     0xb0f078: ldr             q2, [SP], #0x10
    // 0xb0f07c: ldp             q3, q4, [SP], #0x20
    // 0xb0f080: ldp             q5, q6, [SP], #0x20
    // 0xb0f084: b               #0xb0eef0
    // 0xb0f088: stp             q5, q6, [SP, #-0x20]!
    // 0xb0f08c: stp             q3, q4, [SP, #-0x20]!
    // 0xb0f090: stp             x4, x5, [SP, #-0x10]!
    // 0xb0f094: stp             x2, x3, [SP, #-0x10]!
    // 0xb0f098: stp             x0, x1, [SP, #-0x10]!
    // 0xb0f09c: r0 = AllocateDouble()
    //     0xb0f09c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0f0a0: mov             x6, x0
    // 0xb0f0a4: ldp             x0, x1, [SP], #0x10
    // 0xb0f0a8: ldp             x2, x3, [SP], #0x10
    // 0xb0f0ac: ldp             x4, x5, [SP], #0x10
    // 0xb0f0b0: ldp             q3, q4, [SP], #0x20
    // 0xb0f0b4: ldp             q5, q6, [SP], #0x20
    // 0xb0f0b8: b               #0xb0ef18
    // 0xb0f0bc: stp             q5, q6, [SP, #-0x20]!
    // 0xb0f0c0: SaveReg d4
    //     0xb0f0c0: str             q4, [SP, #-0x10]!
    // 0xb0f0c4: stp             x5, x6, [SP, #-0x10]!
    // 0xb0f0c8: stp             x3, x4, [SP, #-0x10]!
    // 0xb0f0cc: stp             x1, x2, [SP, #-0x10]!
    // 0xb0f0d0: SaveReg r0
    //     0xb0f0d0: str             x0, [SP, #-8]!
    // 0xb0f0d4: r0 = AllocateDouble()
    //     0xb0f0d4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0f0d8: mov             x7, x0
    // 0xb0f0dc: RestoreReg r0
    //     0xb0f0dc: ldr             x0, [SP], #8
    // 0xb0f0e0: ldp             x1, x2, [SP], #0x10
    // 0xb0f0e4: ldp             x3, x4, [SP], #0x10
    // 0xb0f0e8: ldp             x5, x6, [SP], #0x10
    // 0xb0f0ec: RestoreReg d4
    //     0xb0f0ec: ldr             q4, [SP], #0x10
    // 0xb0f0f0: ldp             q5, q6, [SP], #0x20
    // 0xb0f0f4: b               #0xb0ef40
    // 0xb0f0f8: stp             q5, q6, [SP, #-0x20]!
    // 0xb0f0fc: stp             x6, x7, [SP, #-0x10]!
    // 0xb0f100: stp             x4, x5, [SP, #-0x10]!
    // 0xb0f104: stp             x2, x3, [SP, #-0x10]!
    // 0xb0f108: stp             x0, x1, [SP, #-0x10]!
    // 0xb0f10c: r0 = AllocateDouble()
    //     0xb0f10c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0f110: mov             x8, x0
    // 0xb0f114: ldp             x0, x1, [SP], #0x10
    // 0xb0f118: ldp             x2, x3, [SP], #0x10
    // 0xb0f11c: ldp             x4, x5, [SP], #0x10
    // 0xb0f120: ldp             x6, x7, [SP], #0x10
    // 0xb0f124: ldp             q5, q6, [SP], #0x20
    // 0xb0f128: b               #0xb0ef68
    // 0xb0f12c: SaveReg d6
    //     0xb0f12c: str             q6, [SP, #-0x10]!
    // 0xb0f130: stp             x7, x8, [SP, #-0x10]!
    // 0xb0f134: stp             x5, x6, [SP, #-0x10]!
    // 0xb0f138: stp             x3, x4, [SP, #-0x10]!
    // 0xb0f13c: stp             x1, x2, [SP, #-0x10]!
    // 0xb0f140: SaveReg r0
    //     0xb0f140: str             x0, [SP, #-8]!
    // 0xb0f144: r0 = AllocateDouble()
    //     0xb0f144: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0f148: mov             x9, x0
    // 0xb0f14c: RestoreReg r0
    //     0xb0f14c: ldr             x0, [SP], #8
    // 0xb0f150: ldp             x1, x2, [SP], #0x10
    // 0xb0f154: ldp             x3, x4, [SP], #0x10
    // 0xb0f158: ldp             x5, x6, [SP], #0x10
    // 0xb0f15c: ldp             x7, x8, [SP], #0x10
    // 0xb0f160: RestoreReg d6
    //     0xb0f160: ldr             q6, [SP], #0x10
    // 0xb0f164: b               #0xb0ef90
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9ea20, size: 0x140
    // 0xc9ea20: ldr             x1, [SP]
    // 0xc9ea24: cmp             w1, NULL
    // 0xc9ea28: b.ne            #0xc9ea34
    // 0xc9ea2c: r0 = false
    //     0xc9ea2c: add             x0, NULL, #0x30  ; false
    // 0xc9ea30: ret
    //     0xc9ea30: ret             
    // 0xc9ea34: ldr             x2, [SP, #8]
    // 0xc9ea38: cmp             w2, w1
    // 0xc9ea3c: b.ne            #0xc9ea48
    // 0xc9ea40: r0 = true
    //     0xc9ea40: add             x0, NULL, #0x20  ; true
    // 0xc9ea44: ret
    //     0xc9ea44: ret             
    // 0xc9ea48: r3 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc9ea48: mov             x3, #0x76
    //     0xc9ea4c: tbz             w1, #0, #0xc9ea5c
    //     0xc9ea50: ldur            x3, [x1, #-1]
    //     0xc9ea54: ubfx            x3, x3, #0xc, #0x14
    //     0xc9ea58: lsl             x3, x3, #1
    // 0xc9ea5c: r17 = 4120
    //     0xc9ea5c: mov             x17, #0x1018
    // 0xc9ea60: cmp             w3, w17
    // 0xc9ea64: b.eq            #0xc9ea70
    // 0xc9ea68: r0 = false
    //     0xc9ea68: add             x0, NULL, #0x30  ; false
    // 0xc9ea6c: ret
    //     0xc9ea6c: ret             
    // 0xc9ea70: LoadField: r3 = r1->field_7
    //     0xc9ea70: ldur            w3, [x1, #7]
    // 0xc9ea74: DecompressPointer r3
    //     0xc9ea74: add             x3, x3, HEAP, lsl #32
    // 0xc9ea78: LoadField: r4 = r2->field_7
    //     0xc9ea78: ldur            w4, [x2, #7]
    // 0xc9ea7c: DecompressPointer r4
    //     0xc9ea7c: add             x4, x4, HEAP, lsl #32
    // 0xc9ea80: cmp             w3, w4
    // 0xc9ea84: b.ne            #0xc9eb58
    // 0xc9ea88: LoadField: r3 = r1->field_b
    //     0xc9ea88: ldur            w3, [x1, #0xb]
    // 0xc9ea8c: DecompressPointer r3
    //     0xc9ea8c: add             x3, x3, HEAP, lsl #32
    // 0xc9ea90: LoadField: r4 = r2->field_b
    //     0xc9ea90: ldur            w4, [x2, #0xb]
    // 0xc9ea94: DecompressPointer r4
    //     0xc9ea94: add             x4, x4, HEAP, lsl #32
    // 0xc9ea98: cmp             w3, w4
    // 0xc9ea9c: b.ne            #0xc9eb58
    // 0xc9eaa0: LoadField: d0 = r1->field_13
    //     0xc9eaa0: ldur            d0, [x1, #0x13]
    // 0xc9eaa4: LoadField: d1 = r2->field_13
    //     0xc9eaa4: ldur            d1, [x2, #0x13]
    // 0xc9eaa8: fcmp            d0, d1
    // 0xc9eaac: b.vs            #0xc9eb58
    // 0xc9eab0: b.ne            #0xc9eb58
    // 0xc9eab4: LoadField: d0 = r1->field_23
    //     0xc9eab4: ldur            d0, [x1, #0x23]
    // 0xc9eab8: LoadField: d1 = r2->field_23
    //     0xc9eab8: ldur            d1, [x2, #0x23]
    // 0xc9eabc: fcmp            d0, d1
    // 0xc9eac0: b.vs            #0xc9eb58
    // 0xc9eac4: b.ne            #0xc9eb58
    // 0xc9eac8: LoadField: d0 = r1->field_2b
    //     0xc9eac8: ldur            d0, [x1, #0x2b]
    // 0xc9eacc: LoadField: d1 = r2->field_2b
    //     0xc9eacc: ldur            d1, [x2, #0x2b]
    // 0xc9ead0: fcmp            d0, d1
    // 0xc9ead4: b.vs            #0xc9eb58
    // 0xc9ead8: b.ne            #0xc9eb58
    // 0xc9eadc: LoadField: d0 = r1->field_33
    //     0xc9eadc: ldur            d0, [x1, #0x33]
    // 0xc9eae0: LoadField: d1 = r2->field_33
    //     0xc9eae0: ldur            d1, [x2, #0x33]
    // 0xc9eae4: fcmp            d0, d1
    // 0xc9eae8: b.vs            #0xc9eb58
    // 0xc9eaec: b.ne            #0xc9eb58
    // 0xc9eaf0: LoadField: r3 = r1->field_3b
    //     0xc9eaf0: ldur            w3, [x1, #0x3b]
    // 0xc9eaf4: DecompressPointer r3
    //     0xc9eaf4: add             x3, x3, HEAP, lsl #32
    // 0xc9eaf8: LoadField: r4 = r2->field_3b
    //     0xc9eaf8: ldur            w4, [x2, #0x3b]
    // 0xc9eafc: DecompressPointer r4
    //     0xc9eafc: add             x4, x4, HEAP, lsl #32
    // 0xc9eb00: cmp             w3, w4
    // 0xc9eb04: b.ne            #0xc9eb58
    // 0xc9eb08: LoadField: d0 = r1->field_3f
    //     0xc9eb08: ldur            d0, [x1, #0x3f]
    // 0xc9eb0c: LoadField: d1 = r2->field_3f
    //     0xc9eb0c: ldur            d1, [x2, #0x3f]
    // 0xc9eb10: fcmp            d0, d1
    // 0xc9eb14: b.vs            #0xc9eb58
    // 0xc9eb18: b.ne            #0xc9eb58
    // 0xc9eb1c: LoadField: d0 = r1->field_4f
    //     0xc9eb1c: ldur            d0, [x1, #0x4f]
    // 0xc9eb20: LoadField: d1 = r2->field_4f
    //     0xc9eb20: ldur            d1, [x2, #0x4f]
    // 0xc9eb24: fcmp            d0, d1
    // 0xc9eb28: b.vs            #0xc9eb58
    // 0xc9eb2c: b.ne            #0xc9eb58
    // 0xc9eb30: LoadField: d0 = r1->field_47
    //     0xc9eb30: ldur            d0, [x1, #0x47]
    // 0xc9eb34: LoadField: d1 = r2->field_47
    //     0xc9eb34: ldur            d1, [x2, #0x47]
    // 0xc9eb38: fcmp            d0, d1
    // 0xc9eb3c: b.vs            #0xc9eb44
    // 0xc9eb40: b.eq            #0xc9eb4c
    // 0xc9eb44: r1 = false
    //     0xc9eb44: add             x1, NULL, #0x30  ; false
    // 0xc9eb48: b               #0xc9eb50
    // 0xc9eb4c: r1 = true
    //     0xc9eb4c: add             x1, NULL, #0x20  ; true
    // 0xc9eb50: mov             x0, x1
    // 0xc9eb54: b               #0xc9eb5c
    // 0xc9eb58: r0 = false
    //     0xc9eb58: add             x0, NULL, #0x30  ; false
    // 0xc9eb5c: ret
    //     0xc9eb5c: ret             
  }
}

// class id: 2281, size: 0x14, field offset: 0x14
class SliverHitTestResult extends HitTestResult {

  _ addWithAxisOffset(/* No info */) {
    // ** addr: 0xa8be54, size: 0x138
    // 0xa8be54: EnterFrame
    //     0xa8be54: stp             fp, lr, [SP, #-0x10]!
    //     0xa8be58: mov             fp, SP
    // 0xa8be5c: AllocStack(0x8)
    //     0xa8be5c: sub             SP, SP, #8
    // 0xa8be60: CheckStackOverflow
    //     0xa8be60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8be64: cmp             SP, x16
    //     0xa8be68: b.ls            #0xa8bf54
    // 0xa8be6c: ldr             x16, [fp, #0x10]
    // 0xa8be70: SaveReg r16
    //     0xa8be70: str             x16, [SP, #-8]!
    // 0xa8be74: r0 = unary-()
    //     0xa8be74: bl              #0x622a88  ; [dart:ui] Offset::unary-
    // 0xa8be78: add             SP, SP, #8
    // 0xa8be7c: ldr             x16, [fp, #0x40]
    // 0xa8be80: stp             x0, x16, [SP, #-0x10]!
    // 0xa8be84: r0 = pushOffset()
    //     0xa8be84: bl              #0x622998  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::pushOffset
    // 0xa8be88: add             SP, SP, #0x10
    // 0xa8be8c: ldr             x0, [fp, #0x20]
    // 0xa8be90: LoadField: d0 = r0->field_7
    //     0xa8be90: ldur            d0, [x0, #7]
    // 0xa8be94: ldr             d1, [fp, #0x18]
    // 0xa8be98: fsub            d2, d1, d0
    // 0xa8be9c: ldr             x0, [fp, #0x38]
    // 0xa8bea0: cmp             w0, NULL
    // 0xa8bea4: b.eq            #0xa8bf5c
    // 0xa8bea8: ldr             x1, [fp, #0x30]
    // 0xa8beac: LoadField: d0 = r1->field_7
    //     0xa8beac: ldur            d0, [x1, #7]
    // 0xa8beb0: LoadField: d1 = r0->field_7
    //     0xa8beb0: ldur            d1, [x0, #7]
    // 0xa8beb4: fsub            d3, d0, d1
    // 0xa8beb8: r0 = inline_Allocate_Double()
    //     0xa8beb8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa8bebc: add             x0, x0, #0x10
    //     0xa8bec0: cmp             x1, x0
    //     0xa8bec4: b.ls            #0xa8bf60
    //     0xa8bec8: str             x0, [THR, #0x60]  ; THR::top
    //     0xa8becc: sub             x0, x0, #0xf
    //     0xa8bed0: mov             x1, #0xd108
    //     0xa8bed4: movk            x1, #3, lsl #16
    //     0xa8bed8: stur            x1, [x0, #-1]
    // 0xa8bedc: StoreField: r0->field_7 = d2
    //     0xa8bedc: stur            d2, [x0, #7]
    // 0xa8bee0: r1 = inline_Allocate_Double()
    //     0xa8bee0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xa8bee4: add             x1, x1, #0x10
    //     0xa8bee8: cmp             x2, x1
    //     0xa8beec: b.ls            #0xa8bf70
    //     0xa8bef0: str             x1, [THR, #0x60]  ; THR::top
    //     0xa8bef4: sub             x1, x1, #0xf
    //     0xa8bef8: mov             x2, #0xd108
    //     0xa8befc: movk            x2, #3, lsl #16
    //     0xa8bf00: stur            x2, [x1, #-1]
    // 0xa8bf04: StoreField: r1->field_7 = d3
    //     0xa8bf04: stur            d3, [x1, #7]
    // 0xa8bf08: ldr             x16, [fp, #0x28]
    // 0xa8bf0c: ldr             lr, [fp, #0x40]
    // 0xa8bf10: stp             lr, x16, [SP, #-0x10]!
    // 0xa8bf14: stp             x1, x0, [SP, #-0x10]!
    // 0xa8bf18: ldr             x0, [fp, #0x28]
    // 0xa8bf1c: ClosureCall
    //     0xa8bf1c: add             x4, PP, #0x4a, lsl #12  ; [pp+0x4ab98] List(9) [0, 0x4, 0x4, 0x2, "crossAxisPosition", 0x3, "mainAxisPosition", 0x2, Null]
    //     0xa8bf20: ldr             x4, [x4, #0xb98]
    //     0xa8bf24: ldur            x2, [x0, #0x1f]
    //     0xa8bf28: blr             x2
    // 0xa8bf2c: add             SP, SP, #0x20
    // 0xa8bf30: stur            x0, [fp, #-8]
    // 0xa8bf34: ldr             x16, [fp, #0x40]
    // 0xa8bf38: SaveReg r16
    //     0xa8bf38: str             x16, [SP, #-8]!
    // 0xa8bf3c: r0 = popTransform()
    //     0xa8bf3c: bl              #0x6228f4  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::popTransform
    // 0xa8bf40: add             SP, SP, #8
    // 0xa8bf44: ldur            x0, [fp, #-8]
    // 0xa8bf48: LeaveFrame
    //     0xa8bf48: mov             SP, fp
    //     0xa8bf4c: ldp             fp, lr, [SP], #0x10
    // 0xa8bf50: ret
    //     0xa8bf50: ret             
    // 0xa8bf54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8bf54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8bf58: b               #0xa8be6c
    // 0xa8bf5c: r0 = NullErrorSharedWithFPURegs()
    //     0xa8bf5c: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0xa8bf60: stp             q2, q3, [SP, #-0x20]!
    // 0xa8bf64: r0 = AllocateDouble()
    //     0xa8bf64: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa8bf68: ldp             q2, q3, [SP], #0x20
    // 0xa8bf6c: b               #0xa8bedc
    // 0xa8bf70: SaveReg d3
    //     0xa8bf70: str             q3, [SP, #-0x10]!
    // 0xa8bf74: SaveReg r0
    //     0xa8bf74: str             x0, [SP, #-8]!
    // 0xa8bf78: r0 = AllocateDouble()
    //     0xa8bf78: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa8bf7c: mov             x1, x0
    // 0xa8bf80: RestoreReg r0
    //     0xa8bf80: ldr             x0, [SP], #8
    // 0xa8bf84: RestoreReg d3
    //     0xa8bf84: ldr             q3, [SP], #0x10
    // 0xa8bf88: b               #0xa8bf04
  }
}

// class id: 2287, size: 0x24, field offset: 0x14
class SliverHitTestEntry extends HitTestEntry<RenderSliver> {

  _ toString(/* No info */) {
    // ** addr: 0xad95a8, size: 0x124
    // 0xad95a8: EnterFrame
    //     0xad95a8: stp             fp, lr, [SP, #-0x10]!
    //     0xad95ac: mov             fp, SP
    // 0xad95b0: AllocStack(0x8)
    //     0xad95b0: sub             SP, SP, #8
    // 0xad95b4: CheckStackOverflow
    //     0xad95b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad95b8: cmp             SP, x16
    //     0xad95bc: b.ls            #0xad9690
    // 0xad95c0: ldr             x0, [fp, #0x10]
    // 0xad95c4: LoadField: r1 = r0->field_b
    //     0xad95c4: ldur            w1, [x0, #0xb]
    // 0xad95c8: DecompressPointer r1
    //     0xad95c8: add             x1, x1, HEAP, lsl #32
    // 0xad95cc: SaveReg r1
    //     0xad95cc: str             x1, [SP, #-8]!
    // 0xad95d0: r0 = runtimeType()
    //     0xad95d0: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xad95d4: add             SP, SP, #8
    // 0xad95d8: r1 = Null
    //     0xad95d8: mov             x1, NULL
    // 0xad95dc: r2 = 12
    //     0xad95dc: mov             x2, #0xc
    // 0xad95e0: stur            x0, [fp, #-8]
    // 0xad95e4: r0 = AllocateArray()
    //     0xad95e4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad95e8: mov             x1, x0
    // 0xad95ec: ldur            x0, [fp, #-8]
    // 0xad95f0: StoreField: r1->field_f = r0
    //     0xad95f0: stur            w0, [x1, #0xf]
    // 0xad95f4: r17 = "@(mainAxis: "
    //     0xad95f4: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fcc0] "@(mainAxis: "
    //     0xad95f8: ldr             x17, [x17, #0xcc0]
    // 0xad95fc: StoreField: r1->field_13 = r17
    //     0xad95fc: stur            w17, [x1, #0x13]
    // 0xad9600: ldr             x0, [fp, #0x10]
    // 0xad9604: LoadField: d0 = r0->field_13
    //     0xad9604: ldur            d0, [x0, #0x13]
    // 0xad9608: r2 = inline_Allocate_Double()
    //     0xad9608: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xad960c: add             x2, x2, #0x10
    //     0xad9610: cmp             x3, x2
    //     0xad9614: b.ls            #0xad9698
    //     0xad9618: str             x2, [THR, #0x60]  ; THR::top
    //     0xad961c: sub             x2, x2, #0xf
    //     0xad9620: mov             x3, #0xd108
    //     0xad9624: movk            x3, #3, lsl #16
    //     0xad9628: stur            x3, [x2, #-1]
    // 0xad962c: StoreField: r2->field_7 = d0
    //     0xad962c: stur            d0, [x2, #7]
    // 0xad9630: StoreField: r1->field_17 = r2
    //     0xad9630: stur            w2, [x1, #0x17]
    // 0xad9634: r17 = ", crossAxis: "
    //     0xad9634: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fcc8] ", crossAxis: "
    //     0xad9638: ldr             x17, [x17, #0xcc8]
    // 0xad963c: StoreField: r1->field_1b = r17
    //     0xad963c: stur            w17, [x1, #0x1b]
    // 0xad9640: LoadField: d0 = r0->field_1b
    //     0xad9640: ldur            d0, [x0, #0x1b]
    // 0xad9644: r0 = inline_Allocate_Double()
    //     0xad9644: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xad9648: add             x0, x0, #0x10
    //     0xad964c: cmp             x2, x0
    //     0xad9650: b.ls            #0xad96b4
    //     0xad9654: str             x0, [THR, #0x60]  ; THR::top
    //     0xad9658: sub             x0, x0, #0xf
    //     0xad965c: mov             x2, #0xd108
    //     0xad9660: movk            x2, #3, lsl #16
    //     0xad9664: stur            x2, [x0, #-1]
    // 0xad9668: StoreField: r0->field_7 = d0
    //     0xad9668: stur            d0, [x0, #7]
    // 0xad966c: StoreField: r1->field_1f = r0
    //     0xad966c: stur            w0, [x1, #0x1f]
    // 0xad9670: r17 = ")"
    //     0xad9670: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad9674: StoreField: r1->field_23 = r17
    //     0xad9674: stur            w17, [x1, #0x23]
    // 0xad9678: SaveReg r1
    //     0xad9678: str             x1, [SP, #-8]!
    // 0xad967c: r0 = _interpolate()
    //     0xad967c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad9680: add             SP, SP, #8
    // 0xad9684: LeaveFrame
    //     0xad9684: mov             SP, fp
    //     0xad9688: ldp             fp, lr, [SP], #0x10
    // 0xad968c: ret
    //     0xad968c: ret             
    // 0xad9690: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad9690: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad9694: b               #0xad95c0
    // 0xad9698: SaveReg d0
    //     0xad9698: str             q0, [SP, #-0x10]!
    // 0xad969c: stp             x0, x1, [SP, #-0x10]!
    // 0xad96a0: r0 = AllocateDouble()
    //     0xad96a0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad96a4: mov             x2, x0
    // 0xad96a8: ldp             x0, x1, [SP], #0x10
    // 0xad96ac: RestoreReg d0
    //     0xad96ac: ldr             q0, [SP], #0x10
    // 0xad96b0: b               #0xad962c
    // 0xad96b4: SaveReg d0
    //     0xad96b4: str             q0, [SP, #-0x10]!
    // 0xad96b8: SaveReg r1
    //     0xad96b8: str             x1, [SP, #-8]!
    // 0xad96bc: r0 = AllocateDouble()
    //     0xad96bc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad96c0: RestoreReg r1
    //     0xad96c0: ldr             x1, [SP], #8
    // 0xad96c4: RestoreReg d0
    //     0xad96c4: ldr             q0, [SP], #0x10
    // 0xad96c8: b               #0xad9668
  }
}

// class id: 2549, size: 0x54, field offset: 0x50
abstract class RenderSliver extends RenderObject {

  bool hitTest(RenderSliver, SliverHitTestResult, {required double mainAxisPosition, required double crossAxisPosition}) {
    // ** addr: 0x62ab2c, size: 0x1dc
    // 0x62ab2c: EnterFrame
    //     0x62ab2c: stp             fp, lr, [SP, #-0x10]!
    //     0x62ab30: mov             fp, SP
    // 0x62ab34: AllocStack(0x30)
    //     0x62ab34: sub             SP, SP, #0x30
    // 0x62ab38: d0 = 0.000000
    //     0x62ab38: eor             v0.16b, v0.16b, v0.16b
    // 0x62ab3c: mov             x0, x4
    // 0x62ab40: LoadField: r1 = r0->field_13
    //     0x62ab40: ldur            w1, [x0, #0x13]
    // 0x62ab44: DecompressPointer r1
    //     0x62ab44: add             x1, x1, HEAP, lsl #32
    // 0x62ab48: sub             x2, x1, #4
    // 0x62ab4c: add             x3, fp, w2, sxtw #2
    // 0x62ab50: ldr             x3, [x3, #0x18]
    // 0x62ab54: stur            x3, [fp, #-0x20]
    // 0x62ab58: add             x4, fp, w2, sxtw #2
    // 0x62ab5c: ldr             x4, [x4, #0x10]
    // 0x62ab60: stur            x4, [fp, #-0x18]
    // 0x62ab64: LoadField: r2 = r0->field_23
    //     0x62ab64: ldur            w2, [x0, #0x23]
    // 0x62ab68: DecompressPointer r2
    //     0x62ab68: add             x2, x2, HEAP, lsl #32
    // 0x62ab6c: sub             w5, w1, w2
    // 0x62ab70: add             x6, fp, w5, sxtw #2
    // 0x62ab74: ldr             x6, [x6, #8]
    // 0x62ab78: stur            x6, [fp, #-0x10]
    // 0x62ab7c: LoadField: r2 = r0->field_2b
    //     0x62ab7c: ldur            w2, [x0, #0x2b]
    // 0x62ab80: DecompressPointer r2
    //     0x62ab80: add             x2, x2, HEAP, lsl #32
    // 0x62ab84: sub             w0, w1, w2
    // 0x62ab88: add             x1, fp, w0, sxtw #2
    // 0x62ab8c: ldr             x1, [x1, #8]
    // 0x62ab90: CheckStackOverflow
    //     0x62ab90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62ab94: cmp             SP, x16
    //     0x62ab98: b.ls            #0x62acfc
    // 0x62ab9c: LoadField: d1 = r1->field_7
    //     0x62ab9c: ldur            d1, [x1, #7]
    // 0x62aba0: stur            d1, [fp, #-0x30]
    // 0x62aba4: fcmp            d1, d0
    // 0x62aba8: b.vs            #0x62accc
    // 0x62abac: b.lt            #0x62accc
    // 0x62abb0: LoadField: r0 = r3->field_4f
    //     0x62abb0: ldur            w0, [x3, #0x4f]
    // 0x62abb4: DecompressPointer r0
    //     0x62abb4: add             x0, x0, HEAP, lsl #32
    // 0x62abb8: cmp             w0, NULL
    // 0x62abbc: b.eq            #0x62ad04
    // 0x62abc0: LoadField: d2 = r0->field_37
    //     0x62abc0: ldur            d2, [x0, #0x37]
    // 0x62abc4: fcmp            d1, d2
    // 0x62abc8: b.vs            #0x62accc
    // 0x62abcc: b.ge            #0x62accc
    // 0x62abd0: LoadField: d2 = r6->field_7
    //     0x62abd0: ldur            d2, [x6, #7]
    // 0x62abd4: stur            d2, [fp, #-0x28]
    // 0x62abd8: fcmp            d2, d0
    // 0x62abdc: b.vs            #0x62accc
    // 0x62abe0: b.lt            #0x62accc
    // 0x62abe4: LoadField: r5 = r3->field_27
    //     0x62abe4: ldur            w5, [x3, #0x27]
    // 0x62abe8: DecompressPointer r5
    //     0x62abe8: add             x5, x5, HEAP, lsl #32
    // 0x62abec: stur            x5, [fp, #-8]
    // 0x62abf0: cmp             w5, NULL
    // 0x62abf4: b.eq            #0x62acdc
    // 0x62abf8: mov             x0, x5
    // 0x62abfc: r2 = Null
    //     0x62abfc: mov             x2, NULL
    // 0x62ac00: r1 = Null
    //     0x62ac00: mov             x1, NULL
    // 0x62ac04: r4 = LoadClassIdInstr(r0)
    //     0x62ac04: ldur            x4, [x0, #-1]
    //     0x62ac08: ubfx            x4, x4, #0xc, #0x14
    // 0x62ac0c: cmp             x4, #0x80c
    // 0x62ac10: b.eq            #0x62ac28
    // 0x62ac14: r8 = SliverConstraints
    //     0x62ac14: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x62ac18: ldr             x8, [x8, #0x5a8]
    // 0x62ac1c: r3 = Null
    //     0x62ac1c: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4aba0] Null
    //     0x62ac20: ldr             x3, [x3, #0xba0]
    // 0x62ac24: r0 = DefaultTypeTest()
    //     0x62ac24: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x62ac28: ldur            x0, [fp, #-8]
    // 0x62ac2c: LoadField: d0 = r0->field_33
    //     0x62ac2c: ldur            d0, [x0, #0x33]
    // 0x62ac30: ldur            d1, [fp, #-0x28]
    // 0x62ac34: fcmp            d1, d0
    // 0x62ac38: b.vs            #0x62accc
    // 0x62ac3c: b.ge            #0x62accc
    // 0x62ac40: ldur            x1, [fp, #-0x20]
    // 0x62ac44: ldur            d0, [fp, #-0x30]
    // 0x62ac48: r0 = LoadClassIdInstr(r1)
    //     0x62ac48: ldur            x0, [x1, #-1]
    //     0x62ac4c: ubfx            x0, x0, #0xc, #0x14
    // 0x62ac50: ldur            x16, [fp, #-0x18]
    // 0x62ac54: stp             x16, x1, [SP, #-0x10]!
    // 0x62ac58: ldur            x16, [fp, #-0x10]
    // 0x62ac5c: SaveReg r16
    //     0x62ac5c: str             x16, [SP, #-8]!
    // 0x62ac60: SaveReg d0
    //     0x62ac60: str             d0, [SP, #-8]!
    // 0x62ac64: r0 = GDT[cid_x0 + 0x66cc]()
    //     0x62ac64: mov             x17, #0x66cc
    //     0x62ac68: add             lr, x0, x17
    //     0x62ac6c: ldr             lr, [x21, lr, lsl #3]
    //     0x62ac70: blr             lr
    // 0x62ac74: add             SP, SP, #0x20
    // 0x62ac78: tbnz            w0, #4, #0x62accc
    // 0x62ac7c: ldur            x0, [fp, #-0x20]
    // 0x62ac80: ldur            d0, [fp, #-0x28]
    // 0x62ac84: ldur            d1, [fp, #-0x30]
    // 0x62ac88: r1 = <RenderSliver>
    //     0x62ac88: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2ef20] TypeArguments: <RenderSliver>
    //     0x62ac8c: ldr             x1, [x1, #0xf20]
    // 0x62ac90: r0 = SliverHitTestEntry()
    //     0x62ac90: bl              #0x62ada0  ; AllocateSliverHitTestEntryStub -> SliverHitTestEntry (size=0x24)
    // 0x62ac94: ldur            d0, [fp, #-0x30]
    // 0x62ac98: StoreField: r0->field_13 = d0
    //     0x62ac98: stur            d0, [x0, #0x13]
    // 0x62ac9c: ldur            d0, [fp, #-0x28]
    // 0x62aca0: StoreField: r0->field_1b = d0
    //     0x62aca0: stur            d0, [x0, #0x1b]
    // 0x62aca4: ldur            x1, [fp, #-0x20]
    // 0x62aca8: StoreField: r0->field_b = r1
    //     0x62aca8: stur            w1, [x0, #0xb]
    // 0x62acac: ldur            x16, [fp, #-0x18]
    // 0x62acb0: stp             x0, x16, [SP, #-0x10]!
    // 0x62acb4: r0 = add()
    //     0x62acb4: bl              #0x50ea24  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::add
    // 0x62acb8: add             SP, SP, #0x10
    // 0x62acbc: r0 = true
    //     0x62acbc: add             x0, NULL, #0x20  ; true
    // 0x62acc0: LeaveFrame
    //     0x62acc0: mov             SP, fp
    //     0x62acc4: ldp             fp, lr, [SP], #0x10
    // 0x62acc8: ret
    //     0x62acc8: ret             
    // 0x62accc: r0 = false
    //     0x62accc: add             x0, NULL, #0x30  ; false
    // 0x62acd0: LeaveFrame
    //     0x62acd0: mov             SP, fp
    //     0x62acd4: ldp             fp, lr, [SP], #0x10
    // 0x62acd8: ret
    //     0x62acd8: ret             
    // 0x62acdc: r0 = StateError()
    //     0x62acdc: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x62ace0: mov             x1, x0
    // 0x62ace4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x62ace4: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x62ace8: ldr             x0, [x0, #0x1e8]
    // 0x62acec: StoreField: r1->field_b = r0
    //     0x62acec: stur            w0, [x1, #0xb]
    // 0x62acf0: mov             x0, x1
    // 0x62acf4: r0 = Throw()
    //     0x62acf4: bl              #0xd67e38  ; ThrowStub
    // 0x62acf8: brk             #0
    // 0x62acfc: r0 = StackOverflowSharedWithFPURegs()
    //     0x62acfc: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x62ad00: b               #0x62ab9c
    // 0x62ad04: r0 = NullCastErrorSharedWithFPURegs()
    //     0x62ad04: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] bool hitTest(dynamic, SliverHitTestResult, {required double mainAxisPosition, required double crossAxisPosition}) {
    // ** addr: 0x62ad08, size: 0x98
    // 0x62ad08: EnterFrame
    //     0x62ad08: stp             fp, lr, [SP, #-0x10]!
    //     0x62ad0c: mov             fp, SP
    // 0x62ad10: mov             x0, x4
    // 0x62ad14: LoadField: r1 = r0->field_13
    //     0x62ad14: ldur            w1, [x0, #0x13]
    // 0x62ad18: DecompressPointer r1
    //     0x62ad18: add             x1, x1, HEAP, lsl #32
    // 0x62ad1c: sub             x2, x1, #4
    // 0x62ad20: add             x3, fp, w2, sxtw #2
    // 0x62ad24: ldr             x3, [x3, #0x18]
    // 0x62ad28: add             x4, fp, w2, sxtw #2
    // 0x62ad2c: ldr             x4, [x4, #0x10]
    // 0x62ad30: LoadField: r2 = r0->field_23
    //     0x62ad30: ldur            w2, [x0, #0x23]
    // 0x62ad34: DecompressPointer r2
    //     0x62ad34: add             x2, x2, HEAP, lsl #32
    // 0x62ad38: sub             w5, w1, w2
    // 0x62ad3c: add             x2, fp, w5, sxtw #2
    // 0x62ad40: ldr             x2, [x2, #8]
    // 0x62ad44: LoadField: r5 = r0->field_2b
    //     0x62ad44: ldur            w5, [x0, #0x2b]
    // 0x62ad48: DecompressPointer r5
    //     0x62ad48: add             x5, x5, HEAP, lsl #32
    // 0x62ad4c: sub             w0, w1, w5
    // 0x62ad50: add             x1, fp, w0, sxtw #2
    // 0x62ad54: ldr             x1, [x1, #8]
    // 0x62ad58: LoadField: r0 = r3->field_17
    //     0x62ad58: ldur            w0, [x3, #0x17]
    // 0x62ad5c: DecompressPointer r0
    //     0x62ad5c: add             x0, x0, HEAP, lsl #32
    // 0x62ad60: CheckStackOverflow
    //     0x62ad60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62ad64: cmp             SP, x16
    //     0x62ad68: b.ls            #0x62ad98
    // 0x62ad6c: LoadField: r3 = r0->field_f
    //     0x62ad6c: ldur            w3, [x0, #0xf]
    // 0x62ad70: DecompressPointer r3
    //     0x62ad70: add             x3, x3, HEAP, lsl #32
    // 0x62ad74: stp             x4, x3, [SP, #-0x10]!
    // 0x62ad78: stp             x2, x1, [SP, #-0x10]!
    // 0x62ad7c: r4 = const [0, 0x4, 0x4, 0x2, crossAxisPosition, 0x3, mainAxisPosition, 0x2, null]
    //     0x62ad7c: add             x4, PP, #0x4a, lsl #12  ; [pp+0x4ab98] List(9) [0, 0x4, 0x4, 0x2, "crossAxisPosition", 0x3, "mainAxisPosition", 0x2, Null]
    //     0x62ad80: ldr             x4, [x4, #0xb98]
    // 0x62ad84: r0 = hitTest()
    //     0x62ad84: bl              #0x62ab2c  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::hitTest
    // 0x62ad88: add             SP, SP, #0x20
    // 0x62ad8c: LeaveFrame
    //     0x62ad8c: mov             SP, fp
    //     0x62ad90: ldp             fp, lr, [SP], #0x10
    // 0x62ad94: ret
    //     0x62ad94: ret             
    // 0x62ad98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62ad98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62ad9c: b               #0x62ad6c
  }
  get _ constraints(/* No info */) {
    // ** addr: 0x6419d4, size: 0x84
    // 0x6419d4: EnterFrame
    //     0x6419d4: stp             fp, lr, [SP, #-0x10]!
    //     0x6419d8: mov             fp, SP
    // 0x6419dc: AllocStack(0x8)
    //     0x6419dc: sub             SP, SP, #8
    // 0x6419e0: ldr             x0, [fp, #0x10]
    // 0x6419e4: LoadField: r3 = r0->field_27
    //     0x6419e4: ldur            w3, [x0, #0x27]
    // 0x6419e8: DecompressPointer r3
    //     0x6419e8: add             x3, x3, HEAP, lsl #32
    // 0x6419ec: stur            x3, [fp, #-8]
    // 0x6419f0: cmp             w3, NULL
    // 0x6419f4: b.eq            #0x641a38
    // 0x6419f8: mov             x0, x3
    // 0x6419fc: r2 = Null
    //     0x6419fc: mov             x2, NULL
    // 0x641a00: r1 = Null
    //     0x641a00: mov             x1, NULL
    // 0x641a04: r4 = LoadClassIdInstr(r0)
    //     0x641a04: ldur            x4, [x0, #-1]
    //     0x641a08: ubfx            x4, x4, #0xc, #0x14
    // 0x641a0c: cmp             x4, #0x80c
    // 0x641a10: b.eq            #0x641a28
    // 0x641a14: r8 = SliverConstraints
    //     0x641a14: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x641a18: ldr             x8, [x8, #0x5a8]
    // 0x641a1c: r3 = Null
    //     0x641a1c: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2d5d0] Null
    //     0x641a20: ldr             x3, [x3, #0x5d0]
    // 0x641a24: r0 = DefaultTypeTest()
    //     0x641a24: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x641a28: ldur            x0, [fp, #-8]
    // 0x641a2c: LeaveFrame
    //     0x641a2c: mov             SP, fp
    //     0x641a30: ldp             fp, lr, [SP], #0x10
    // 0x641a34: ret
    //     0x641a34: ret             
    // 0x641a38: r0 = StateError()
    //     0x641a38: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x641a3c: mov             x1, x0
    // 0x641a40: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x641a40: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x641a44: ldr             x0, [x0, #0x1e8]
    // 0x641a48: StoreField: r1->field_b = r0
    //     0x641a48: stur            w0, [x1, #0xb]
    // 0x641a4c: mov             x0, x1
    // 0x641a50: r0 = Throw()
    //     0x641a50: bl              #0xd67e38  ; ThrowStub
    // 0x641a54: brk             #0
  }
  _ calculateCacheOffset(/* No info */) {
    // ** addr: 0x677aa4, size: 0xfc
    // 0x677aa4: EnterFrame
    //     0x677aa4: stp             fp, lr, [SP, #-0x10]!
    //     0x677aa8: mov             fp, SP
    // 0x677aac: ldr             x0, [fp, #0x20]
    // 0x677ab0: LoadField: d1 = r0->field_13
    //     0x677ab0: ldur            d1, [x0, #0x13]
    // 0x677ab4: LoadField: d2 = r0->field_47
    //     0x677ab4: ldur            d2, [x0, #0x47]
    // 0x677ab8: fadd            d3, d1, d2
    // 0x677abc: LoadField: d2 = r0->field_4f
    //     0x677abc: ldur            d2, [x0, #0x4f]
    // 0x677ac0: fadd            d4, d1, d2
    // 0x677ac4: ldr             x0, [fp, #0x10]
    // 0x677ac8: cmp             w0, NULL
    // 0x677acc: b.eq            #0x677b9c
    // 0x677ad0: LoadField: d1 = r0->field_7
    //     0x677ad0: ldur            d1, [x0, #7]
    // 0x677ad4: fcmp            d1, d3
    // 0x677ad8: b.vs            #0x677ae8
    // 0x677adc: b.ge            #0x677ae8
    // 0x677ae0: mov             v5.16b, v3.16b
    // 0x677ae4: b               #0x677b14
    // 0x677ae8: fcmp            d1, d4
    // 0x677aec: b.vs            #0x677afc
    // 0x677af0: b.le            #0x677afc
    // 0x677af4: mov             v5.16b, v4.16b
    // 0x677af8: b               #0x677b14
    // 0x677afc: LoadField: d5 = r0->field_7
    //     0x677afc: ldur            d5, [x0, #7]
    // 0x677b00: fcmp            d5, d5
    // 0x677b04: b.vc            #0x677b10
    // 0x677b08: mov             v5.16b, v4.16b
    // 0x677b0c: b               #0x677b14
    // 0x677b10: mov             v5.16b, v1.16b
    // 0x677b14: ldr             d1, [fp, #0x18]
    // 0x677b18: fcmp            d1, d3
    // 0x677b1c: b.vs            #0x677b24
    // 0x677b20: b.lt            #0x677b4c
    // 0x677b24: fcmp            d1, d4
    // 0x677b28: b.vs            #0x677b38
    // 0x677b2c: b.le            #0x677b38
    // 0x677b30: mov             v3.16b, v4.16b
    // 0x677b34: b               #0x677b4c
    // 0x677b38: fcmp            d1, d1
    // 0x677b3c: b.vc            #0x677b48
    // 0x677b40: mov             v3.16b, v4.16b
    // 0x677b44: b               #0x677b4c
    // 0x677b48: mov             v3.16b, v1.16b
    // 0x677b4c: d1 = 0.000000
    //     0x677b4c: eor             v1.16b, v1.16b, v1.16b
    // 0x677b50: fsub            d4, d5, d3
    // 0x677b54: fcmp            d4, d1
    // 0x677b58: b.vs            #0x677b68
    // 0x677b5c: b.ge            #0x677b68
    // 0x677b60: d0 = 0.000000
    //     0x677b60: eor             v0.16b, v0.16b, v0.16b
    // 0x677b64: b               #0x677b90
    // 0x677b68: fcmp            d4, d2
    // 0x677b6c: b.vs            #0x677b7c
    // 0x677b70: b.le            #0x677b7c
    // 0x677b74: mov             v0.16b, v2.16b
    // 0x677b78: b               #0x677b90
    // 0x677b7c: fcmp            d4, d4
    // 0x677b80: b.vc            #0x677b8c
    // 0x677b84: mov             v0.16b, v2.16b
    // 0x677b88: b               #0x677b90
    // 0x677b8c: mov             v0.16b, v4.16b
    // 0x677b90: LeaveFrame
    //     0x677b90: mov             SP, fp
    //     0x677b94: ldp             fp, lr, [SP], #0x10
    // 0x677b98: ret
    //     0x677b98: ret             
    // 0x677b9c: r0 = NullErrorSharedWithFPURegs()
    //     0x677b9c: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
  }
  _ calculatePaintOffset(/* No info */) {
    // ** addr: 0x677ba0, size: 0xec
    // 0x677ba0: EnterFrame
    //     0x677ba0: stp             fp, lr, [SP, #-0x10]!
    //     0x677ba4: mov             fp, SP
    // 0x677ba8: ldr             x0, [fp, #0x20]
    // 0x677bac: LoadField: d1 = r0->field_13
    //     0x677bac: ldur            d1, [x0, #0x13]
    // 0x677bb0: LoadField: d2 = r0->field_2b
    //     0x677bb0: ldur            d2, [x0, #0x2b]
    // 0x677bb4: fadd            d3, d1, d2
    // 0x677bb8: ldr             x0, [fp, #0x10]
    // 0x677bbc: cmp             w0, NULL
    // 0x677bc0: b.eq            #0x677c88
    // 0x677bc4: LoadField: d4 = r0->field_7
    //     0x677bc4: ldur            d4, [x0, #7]
    // 0x677bc8: fcmp            d4, d1
    // 0x677bcc: b.vs            #0x677bdc
    // 0x677bd0: b.ge            #0x677bdc
    // 0x677bd4: mov             v5.16b, v1.16b
    // 0x677bd8: b               #0x677c08
    // 0x677bdc: fcmp            d4, d3
    // 0x677be0: b.vs            #0x677bf0
    // 0x677be4: b.le            #0x677bf0
    // 0x677be8: mov             v5.16b, v3.16b
    // 0x677bec: b               #0x677c08
    // 0x677bf0: LoadField: d5 = r0->field_7
    //     0x677bf0: ldur            d5, [x0, #7]
    // 0x677bf4: fcmp            d5, d5
    // 0x677bf8: b.vc            #0x677c04
    // 0x677bfc: mov             v5.16b, v3.16b
    // 0x677c00: b               #0x677c08
    // 0x677c04: mov             v5.16b, v4.16b
    // 0x677c08: ldr             d4, [fp, #0x18]
    // 0x677c0c: fcmp            d4, d1
    // 0x677c10: b.vs            #0x677c20
    // 0x677c14: b.ge            #0x677c20
    // 0x677c18: mov             v3.16b, v1.16b
    // 0x677c1c: b               #0x677c38
    // 0x677c20: fcmp            d4, d3
    // 0x677c24: b.vs            #0x677c2c
    // 0x677c28: b.gt            #0x677c38
    // 0x677c2c: fcmp            d4, d4
    // 0x677c30: b.vs            #0x677c38
    // 0x677c34: mov             v3.16b, v4.16b
    // 0x677c38: d1 = 0.000000
    //     0x677c38: eor             v1.16b, v1.16b, v1.16b
    // 0x677c3c: fsub            d4, d5, d3
    // 0x677c40: fcmp            d4, d1
    // 0x677c44: b.vs            #0x677c54
    // 0x677c48: b.ge            #0x677c54
    // 0x677c4c: d0 = 0.000000
    //     0x677c4c: eor             v0.16b, v0.16b, v0.16b
    // 0x677c50: b               #0x677c7c
    // 0x677c54: fcmp            d4, d2
    // 0x677c58: b.vs            #0x677c68
    // 0x677c5c: b.le            #0x677c68
    // 0x677c60: mov             v0.16b, v2.16b
    // 0x677c64: b               #0x677c7c
    // 0x677c68: fcmp            d4, d4
    // 0x677c6c: b.vc            #0x677c78
    // 0x677c70: mov             v0.16b, v2.16b
    // 0x677c74: b               #0x677c7c
    // 0x677c78: mov             v0.16b, v4.16b
    // 0x677c7c: LeaveFrame
    //     0x677c7c: mov             SP, fp
    //     0x677c80: ldp             fp, lr, [SP], #0x10
    // 0x677c84: ret
    //     0x677c84: ret             
    // 0x677c88: r0 = NullErrorSharedWithFPURegs()
    //     0x677c88: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
  }
  get _ semanticBounds(/* No info */) {
    // ** addr: 0x6b7828, size: 0x38
    // 0x6b7828: EnterFrame
    //     0x6b7828: stp             fp, lr, [SP, #-0x10]!
    //     0x6b782c: mov             fp, SP
    // 0x6b7830: CheckStackOverflow
    //     0x6b7830: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6b7834: cmp             SP, x16
    //     0x6b7838: b.ls            #0x6b7858
    // 0x6b783c: ldr             x16, [fp, #0x10]
    // 0x6b7840: SaveReg r16
    //     0x6b7840: str             x16, [SP, #-8]!
    // 0x6b7844: r0 = paintBounds()
    //     0x6b7844: bl              #0x6c05a0  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::paintBounds
    // 0x6b7848: add             SP, SP, #8
    // 0x6b784c: LeaveFrame
    //     0x6b784c: mov             SP, fp
    //     0x6b7850: ldp             fp, lr, [SP], #0x10
    // 0x6b7854: ret
    //     0x6b7854: ret             
    // 0x6b7858: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b7858: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b785c: b               #0x6b783c
  }
  get _ paintBounds(/* No info */) {
    // ** addr: 0x6c05a0, size: 0x1e8
    // 0x6c05a0: EnterFrame
    //     0x6c05a0: stp             fp, lr, [SP, #-0x10]!
    //     0x6c05a4: mov             fp, SP
    // 0x6c05a8: AllocStack(0x18)
    //     0x6c05a8: sub             SP, SP, #0x18
    // 0x6c05ac: CheckStackOverflow
    //     0x6c05ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c05b0: cmp             SP, x16
    //     0x6c05b4: b.ls            #0x6c0778
    // 0x6c05b8: ldr             x3, [fp, #0x10]
    // 0x6c05bc: LoadField: r4 = r3->field_27
    //     0x6c05bc: ldur            w4, [x3, #0x27]
    // 0x6c05c0: DecompressPointer r4
    //     0x6c05c0: add             x4, x4, HEAP, lsl #32
    // 0x6c05c4: stur            x4, [fp, #-8]
    // 0x6c05c8: cmp             w4, NULL
    // 0x6c05cc: b.eq            #0x6c0740
    // 0x6c05d0: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6c05d0: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6c05d4: ldr             x5, [x5, #0x1e8]
    // 0x6c05d8: mov             x0, x4
    // 0x6c05dc: r2 = Null
    //     0x6c05dc: mov             x2, NULL
    // 0x6c05e0: r1 = Null
    //     0x6c05e0: mov             x1, NULL
    // 0x6c05e4: r4 = LoadClassIdInstr(r0)
    //     0x6c05e4: ldur            x4, [x0, #-1]
    //     0x6c05e8: ubfx            x4, x4, #0xc, #0x14
    // 0x6c05ec: cmp             x4, #0x80c
    // 0x6c05f0: b.eq            #0x6c0608
    // 0x6c05f4: r8 = SliverConstraints
    //     0x6c05f4: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x6c05f8: ldr             x8, [x8, #0x5a8]
    // 0x6c05fc: r3 = Null
    //     0x6c05fc: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2d5b0] Null
    //     0x6c0600: ldr             x3, [x3, #0x5b0]
    // 0x6c0604: r0 = DefaultTypeTest()
    //     0x6c0604: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6c0608: ldur            x16, [fp, #-8]
    // 0x6c060c: SaveReg r16
    //     0x6c060c: str             x16, [SP, #-8]!
    // 0x6c0610: r0 = axis()
    //     0x6c0610: bl              #0x643150  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0x6c0614: add             SP, SP, #8
    // 0x6c0618: LoadField: r1 = r0->field_7
    //     0x6c0618: ldur            x1, [x0, #7]
    // 0x6c061c: cmp             x1, #0
    // 0x6c0620: b.gt            #0x6c06d0
    // 0x6c0624: ldr             x0, [fp, #0x10]
    // 0x6c0628: LoadField: r1 = r0->field_4f
    //     0x6c0628: ldur            w1, [x0, #0x4f]
    // 0x6c062c: DecompressPointer r1
    //     0x6c062c: add             x1, x1, HEAP, lsl #32
    // 0x6c0630: cmp             w1, NULL
    // 0x6c0634: b.eq            #0x6c0780
    // 0x6c0638: LoadField: d0 = r1->field_17
    //     0x6c0638: ldur            d0, [x1, #0x17]
    // 0x6c063c: stur            d0, [fp, #-0x10]
    // 0x6c0640: LoadField: r3 = r0->field_27
    //     0x6c0640: ldur            w3, [x0, #0x27]
    // 0x6c0644: DecompressPointer r3
    //     0x6c0644: add             x3, x3, HEAP, lsl #32
    // 0x6c0648: stur            x3, [fp, #-8]
    // 0x6c064c: cmp             w3, NULL
    // 0x6c0650: b.eq            #0x6c0758
    // 0x6c0654: mov             x0, x3
    // 0x6c0658: r2 = Null
    //     0x6c0658: mov             x2, NULL
    // 0x6c065c: r1 = Null
    //     0x6c065c: mov             x1, NULL
    // 0x6c0660: r4 = LoadClassIdInstr(r0)
    //     0x6c0660: ldur            x4, [x0, #-1]
    //     0x6c0664: ubfx            x4, x4, #0xc, #0x14
    // 0x6c0668: cmp             x4, #0x80c
    // 0x6c066c: b.eq            #0x6c0684
    // 0x6c0670: r8 = SliverConstraints
    //     0x6c0670: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x6c0674: ldr             x8, [x8, #0x5a8]
    // 0x6c0678: r3 = Null
    //     0x6c0678: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2d5c0] Null
    //     0x6c067c: ldr             x3, [x3, #0x5c0]
    // 0x6c0680: r0 = DefaultTypeTest()
    //     0x6c0680: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6c0684: ldur            x0, [fp, #-8]
    // 0x6c0688: LoadField: d0 = r0->field_33
    //     0x6c0688: ldur            d0, [x0, #0x33]
    // 0x6c068c: ldur            d1, [fp, #-0x10]
    // 0x6c0690: d2 = 0.000000
    //     0x6c0690: eor             v2.16b, v2.16b, v2.16b
    // 0x6c0694: fadd            d3, d2, d1
    // 0x6c0698: stur            d3, [fp, #-0x18]
    // 0x6c069c: fadd            d1, d2, d0
    // 0x6c06a0: stur            d1, [fp, #-0x10]
    // 0x6c06a4: r0 = Rect()
    //     0x6c06a4: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x6c06a8: d0 = 0.000000
    //     0x6c06a8: eor             v0.16b, v0.16b, v0.16b
    // 0x6c06ac: StoreField: r0->field_7 = d0
    //     0x6c06ac: stur            d0, [x0, #7]
    // 0x6c06b0: StoreField: r0->field_f = d0
    //     0x6c06b0: stur            d0, [x0, #0xf]
    // 0x6c06b4: ldur            d0, [fp, #-0x18]
    // 0x6c06b8: StoreField: r0->field_17 = d0
    //     0x6c06b8: stur            d0, [x0, #0x17]
    // 0x6c06bc: ldur            d0, [fp, #-0x10]
    // 0x6c06c0: StoreField: r0->field_1f = d0
    //     0x6c06c0: stur            d0, [x0, #0x1f]
    // 0x6c06c4: LeaveFrame
    //     0x6c06c4: mov             SP, fp
    //     0x6c06c8: ldp             fp, lr, [SP], #0x10
    // 0x6c06cc: ret
    //     0x6c06cc: ret             
    // 0x6c06d0: ldr             x0, [fp, #0x10]
    // 0x6c06d4: d0 = 0.000000
    //     0x6c06d4: eor             v0.16b, v0.16b, v0.16b
    // 0x6c06d8: SaveReg r0
    //     0x6c06d8: str             x0, [SP, #-8]!
    // 0x6c06dc: r0 = constraints()
    //     0x6c06dc: bl              #0x6419d4  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::constraints
    // 0x6c06e0: add             SP, SP, #8
    // 0x6c06e4: LoadField: d0 = r0->field_33
    //     0x6c06e4: ldur            d0, [x0, #0x33]
    // 0x6c06e8: ldr             x0, [fp, #0x10]
    // 0x6c06ec: LoadField: r1 = r0->field_4f
    //     0x6c06ec: ldur            w1, [x0, #0x4f]
    // 0x6c06f0: DecompressPointer r1
    //     0x6c06f0: add             x1, x1, HEAP, lsl #32
    // 0x6c06f4: cmp             w1, NULL
    // 0x6c06f8: b.eq            #0x6c0784
    // 0x6c06fc: LoadField: d1 = r1->field_17
    //     0x6c06fc: ldur            d1, [x1, #0x17]
    // 0x6c0700: d2 = 0.000000
    //     0x6c0700: eor             v2.16b, v2.16b, v2.16b
    // 0x6c0704: fadd            d3, d2, d0
    // 0x6c0708: stur            d3, [fp, #-0x18]
    // 0x6c070c: fadd            d0, d2, d1
    // 0x6c0710: stur            d0, [fp, #-0x10]
    // 0x6c0714: r0 = Rect()
    //     0x6c0714: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x6c0718: d0 = 0.000000
    //     0x6c0718: eor             v0.16b, v0.16b, v0.16b
    // 0x6c071c: StoreField: r0->field_7 = d0
    //     0x6c071c: stur            d0, [x0, #7]
    // 0x6c0720: StoreField: r0->field_f = d0
    //     0x6c0720: stur            d0, [x0, #0xf]
    // 0x6c0724: ldur            d0, [fp, #-0x18]
    // 0x6c0728: StoreField: r0->field_17 = d0
    //     0x6c0728: stur            d0, [x0, #0x17]
    // 0x6c072c: ldur            d0, [fp, #-0x10]
    // 0x6c0730: StoreField: r0->field_1f = d0
    //     0x6c0730: stur            d0, [x0, #0x1f]
    // 0x6c0734: LeaveFrame
    //     0x6c0734: mov             SP, fp
    //     0x6c0738: ldp             fp, lr, [SP], #0x10
    // 0x6c073c: ret
    //     0x6c073c: ret             
    // 0x6c0740: r0 = StateError()
    //     0x6c0740: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6c0744: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6c0744: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6c0748: ldr             x5, [x5, #0x1e8]
    // 0x6c074c: StoreField: r0->field_b = r5
    //     0x6c074c: stur            w5, [x0, #0xb]
    // 0x6c0750: r0 = Throw()
    //     0x6c0750: bl              #0xd67e38  ; ThrowStub
    // 0x6c0754: brk             #0
    // 0x6c0758: r0 = StateError()
    //     0x6c0758: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6c075c: mov             x1, x0
    // 0x6c0760: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6c0760: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6c0764: ldr             x0, [x0, #0x1e8]
    // 0x6c0768: StoreField: r1->field_b = r0
    //     0x6c0768: stur            w0, [x1, #0xb]
    // 0x6c076c: mov             x0, x1
    // 0x6c0770: r0 = Throw()
    //     0x6c0770: bl              #0xd67e38  ; ThrowStub
    // 0x6c0774: brk             #0
    // 0x6c0778: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c0778: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c077c: b               #0x6c05b8
    // 0x6c0780: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6c0780: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6c0784: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6c0784: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0x715958, size: 0x50
    // 0x715958: EnterFrame
    //     0x715958: stp             fp, lr, [SP, #-0x10]!
    //     0x71595c: mov             fp, SP
    // 0x715960: ldr             x0, [fp, #0x10]
    // 0x715964: r2 = Null
    //     0x715964: mov             x2, NULL
    // 0x715968: r1 = Null
    //     0x715968: mov             x1, NULL
    // 0x71596c: r4 = 59
    //     0x71596c: mov             x4, #0x3b
    // 0x715970: branchIfSmi(r0, 0x71597c)
    //     0x715970: tbz             w0, #0, #0x71597c
    // 0x715974: r4 = LoadClassIdInstr(r0)
    //     0x715974: ldur            x4, [x0, #-1]
    //     0x715978: ubfx            x4, x4, #0xc, #0x14
    // 0x71597c: cmp             x4, #0x8ef
    // 0x715980: b.eq            #0x715998
    // 0x715984: r8 = SliverHitTestEntry<RenderSliver>
    //     0x715984: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d590] Type: SliverHitTestEntry<RenderSliver>
    //     0x715988: ldr             x8, [x8, #0x590]
    // 0x71598c: r3 = Null
    //     0x71598c: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2d598] Null
    //     0x715990: ldr             x3, [x3, #0x598]
    // 0x715994: r0 = DefaultTypeTest()
    //     0x715994: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x715998: r0 = Null
    //     0x715998: mov             x0, NULL
    // 0x71599c: LeaveFrame
    //     0x71599c: mov             SP, fp
    //     0x7159a0: ldp             fp, lr, [SP], #0x10
    // 0x7159a4: ret
    //     0x7159a4: ret             
  }
  dynamic hitTest(dynamic) {
    // ** addr: 0xab3e98, size: 0x18
    // 0xab3e98: r4 = 0
    //     0xab3e98: mov             x4, #0
    // 0xab3e9c: r1 = Function 'hitTest':.
    //     0xab3e9c: add             x17, PP, #0x52, lsl #12  ; [pp+0x52e48] AnonymousClosure: (0x62ad08), in [package:flutter/src/rendering/sliver.dart] RenderSliver::hitTest (0x62ab2c)
    //     0xab3ea0: ldr             x1, [x17, #0xe48]
    // 0xab3ea4: r24 = BuildNonGenericMethodExtractorStub
    //     0xab3ea4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xab3ea8: LoadField: r0 = r24->field_17
    //     0xab3ea8: ldur            x0, [x24, #0x17]
    // 0xab3eac: br              x0
  }
}

// class id: 2566, size: 0x58, field offset: 0x58
abstract class RenderSliverSingleBoxAdapter extends _RenderSliverPersistentHeader&RenderSliver&RenderObjectWithChildMixin&RenderSliverHelpers {

  _ setupParentData(/* No info */) {
    // ** addr: 0x64b7c0, size: 0x70
    // 0x64b7c0: EnterFrame
    //     0x64b7c0: stp             fp, lr, [SP, #-0x10]!
    //     0x64b7c4: mov             fp, SP
    // 0x64b7c8: ldr             x0, [fp, #0x10]
    // 0x64b7cc: LoadField: r1 = r0->field_17
    //     0x64b7cc: ldur            w1, [x0, #0x17]
    // 0x64b7d0: DecompressPointer r1
    //     0x64b7d0: add             x1, x1, HEAP, lsl #32
    // 0x64b7d4: r2 = LoadClassIdInstr(r1)
    //     0x64b7d4: ldur            x2, [x1, #-1]
    //     0x64b7d8: ubfx            x2, x2, #0xc, #0x14
    // 0x64b7dc: lsl             x2, x2, #1
    // 0x64b7e0: r1 = LoadInt32Instr(r2)
    //     0x64b7e0: sbfx            x1, x2, #1, #0x1f
    // 0x64b7e4: cmp             x1, #0x7f3
    // 0x64b7e8: b.lt            #0x64b7f4
    // 0x64b7ec: cmp             x1, #0x7f5
    // 0x64b7f0: b.le            #0x64b820
    // 0x64b7f4: r0 = SliverPhysicalParentData()
    //     0x64b7f4: bl              #0x64b830  ; AllocateSliverPhysicalParentDataStub -> SliverPhysicalParentData (size=0xc)
    // 0x64b7f8: r1 = Instance_Offset
    //     0x64b7f8: ldr             x1, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x64b7fc: StoreField: r0->field_7 = r1
    //     0x64b7fc: stur            w1, [x0, #7]
    // 0x64b800: ldr             x1, [fp, #0x10]
    // 0x64b804: StoreField: r1->field_17 = r0
    //     0x64b804: stur            w0, [x1, #0x17]
    //     0x64b808: ldurb           w16, [x1, #-1]
    //     0x64b80c: ldurb           w17, [x0, #-1]
    //     0x64b810: and             x16, x17, x16, lsr #2
    //     0x64b814: tst             x16, HEAP, lsr #32
    //     0x64b818: b.eq            #0x64b820
    //     0x64b81c: bl              #0xd6826c
    // 0x64b820: r0 = Null
    //     0x64b820: mov             x0, NULL
    // 0x64b824: LeaveFrame
    //     0x64b824: mov             SP, fp
    //     0x64b828: ldp             fp, lr, [SP], #0x10
    // 0x64b82c: ret
    //     0x64b82c: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0x654758, size: 0xe8
    // 0x654758: EnterFrame
    //     0x654758: stp             fp, lr, [SP, #-0x10]!
    //     0x65475c: mov             fp, SP
    // 0x654760: AllocStack(0x10)
    //     0x654760: sub             SP, SP, #0x10
    // 0x654764: CheckStackOverflow
    //     0x654764: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x654768: cmp             SP, x16
    //     0x65476c: b.ls            #0x654830
    // 0x654770: ldr             x0, [fp, #0x20]
    // 0x654774: LoadField: r3 = r0->field_53
    //     0x654774: ldur            w3, [x0, #0x53]
    // 0x654778: DecompressPointer r3
    //     0x654778: add             x3, x3, HEAP, lsl #32
    // 0x65477c: stur            x3, [fp, #-0x10]
    // 0x654780: cmp             w3, NULL
    // 0x654784: b.eq            #0x654820
    // 0x654788: LoadField: r1 = r0->field_4f
    //     0x654788: ldur            w1, [x0, #0x4f]
    // 0x65478c: DecompressPointer r1
    //     0x65478c: add             x1, x1, HEAP, lsl #32
    // 0x654790: cmp             w1, NULL
    // 0x654794: b.eq            #0x654838
    // 0x654798: LoadField: r0 = r1->field_3f
    //     0x654798: ldur            w0, [x1, #0x3f]
    // 0x65479c: DecompressPointer r0
    //     0x65479c: add             x0, x0, HEAP, lsl #32
    // 0x6547a0: tbnz            w0, #4, #0x654820
    // 0x6547a4: LoadField: r4 = r3->field_17
    //     0x6547a4: ldur            w4, [x3, #0x17]
    // 0x6547a8: DecompressPointer r4
    //     0x6547a8: add             x4, x4, HEAP, lsl #32
    // 0x6547ac: stur            x4, [fp, #-8]
    // 0x6547b0: cmp             w4, NULL
    // 0x6547b4: b.eq            #0x65483c
    // 0x6547b8: mov             x0, x4
    // 0x6547bc: r2 = Null
    //     0x6547bc: mov             x2, NULL
    // 0x6547c0: r1 = Null
    //     0x6547c0: mov             x1, NULL
    // 0x6547c4: r4 = LoadClassIdInstr(r0)
    //     0x6547c4: ldur            x4, [x0, #-1]
    //     0x6547c8: ubfx            x4, x4, #0xc, #0x14
    // 0x6547cc: sub             x4, x4, #0x7f3
    // 0x6547d0: cmp             x4, #2
    // 0x6547d4: b.ls            #0x6547ec
    // 0x6547d8: r8 = SliverPhysicalParentData
    //     0x6547d8: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5e0] Type: SliverPhysicalParentData
    //     0x6547dc: ldr             x8, [x8, #0x5e0]
    // 0x6547e0: r3 = Null
    //     0x6547e0: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2d5e8] Null
    //     0x6547e4: ldr             x3, [x3, #0x5e8]
    // 0x6547e8: r0 = DefaultTypeTest()
    //     0x6547e8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6547ec: ldur            x0, [fp, #-8]
    // 0x6547f0: LoadField: r1 = r0->field_7
    //     0x6547f0: ldur            w1, [x0, #7]
    // 0x6547f4: DecompressPointer r1
    //     0x6547f4: add             x1, x1, HEAP, lsl #32
    // 0x6547f8: ldr             x16, [fp, #0x10]
    // 0x6547fc: stp             x1, x16, [SP, #-0x10]!
    // 0x654800: r0 = +()
    //     0x654800: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x654804: add             SP, SP, #0x10
    // 0x654808: ldr             x16, [fp, #0x18]
    // 0x65480c: ldur            lr, [fp, #-0x10]
    // 0x654810: stp             lr, x16, [SP, #-0x10]!
    // 0x654814: SaveReg r0
    //     0x654814: str             x0, [SP, #-8]!
    // 0x654818: r0 = paintChild()
    //     0x654818: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x65481c: add             SP, SP, #0x18
    // 0x654820: r0 = Null
    //     0x654820: mov             x0, NULL
    // 0x654824: LeaveFrame
    //     0x654824: mov             SP, fp
    //     0x654828: ldp             fp, lr, [SP], #0x10
    // 0x65482c: ret
    //     0x65482c: ret             
    // 0x654830: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x654830: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x654834: b               #0x654770
    // 0x654838: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x654838: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x65483c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65483c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ setChildParentData(/* No info */) {
    // ** addr: 0x685a08, size: 0x214
    // 0x685a08: EnterFrame
    //     0x685a08: stp             fp, lr, [SP, #-0x10]!
    //     0x685a0c: mov             fp, SP
    // 0x685a10: AllocStack(0x10)
    //     0x685a10: sub             SP, SP, #0x10
    // 0x685a14: CheckStackOverflow
    //     0x685a14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x685a18: cmp             SP, x16
    //     0x685a1c: b.ls            #0x685c10
    // 0x685a20: ldr             x0, [fp, #0x20]
    // 0x685a24: LoadField: r3 = r0->field_17
    //     0x685a24: ldur            w3, [x0, #0x17]
    // 0x685a28: DecompressPointer r3
    //     0x685a28: add             x3, x3, HEAP, lsl #32
    // 0x685a2c: stur            x3, [fp, #-8]
    // 0x685a30: cmp             w3, NULL
    // 0x685a34: b.eq            #0x685c18
    // 0x685a38: mov             x0, x3
    // 0x685a3c: r2 = Null
    //     0x685a3c: mov             x2, NULL
    // 0x685a40: r1 = Null
    //     0x685a40: mov             x1, NULL
    // 0x685a44: r4 = LoadClassIdInstr(r0)
    //     0x685a44: ldur            x4, [x0, #-1]
    //     0x685a48: ubfx            x4, x4, #0xc, #0x14
    // 0x685a4c: sub             x4, x4, #0x7f3
    // 0x685a50: cmp             x4, #2
    // 0x685a54: b.ls            #0x685a6c
    // 0x685a58: r8 = SliverPhysicalParentData
    //     0x685a58: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5e0] Type: SliverPhysicalParentData
    //     0x685a5c: ldr             x8, [x8, #0x5e0]
    // 0x685a60: r3 = Null
    //     0x685a60: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2d620] Null
    //     0x685a64: ldr             x3, [x3, #0x620]
    // 0x685a68: r0 = DefaultTypeTest()
    //     0x685a68: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x685a6c: ldr             x0, [fp, #0x18]
    // 0x685a70: LoadField: r1 = r0->field_7
    //     0x685a70: ldur            w1, [x0, #7]
    // 0x685a74: DecompressPointer r1
    //     0x685a74: add             x1, x1, HEAP, lsl #32
    // 0x685a78: LoadField: r2 = r0->field_b
    //     0x685a78: ldur            w2, [x0, #0xb]
    // 0x685a7c: DecompressPointer r2
    //     0x685a7c: add             x2, x2, HEAP, lsl #32
    // 0x685a80: stp             x2, x1, [SP, #-0x10]!
    // 0x685a84: r0 = applyGrowthDirectionToAxisDirection()
    //     0x685a84: bl              #0x643194  ; [package:flutter/src/rendering/sliver.dart] ::applyGrowthDirectionToAxisDirection
    // 0x685a88: add             SP, SP, #0x10
    // 0x685a8c: LoadField: r1 = r0->field_7
    //     0x685a8c: ldur            x1, [x0, #7]
    // 0x685a90: cmp             x1, #1
    // 0x685a94: b.gt            #0x685b50
    // 0x685a98: cmp             x1, #0
    // 0x685a9c: b.gt            #0x685b00
    // 0x685aa0: ldr             x0, [fp, #0x18]
    // 0x685aa4: ldr             x2, [fp, #0x10]
    // 0x685aa8: ldur            x1, [fp, #-8]
    // 0x685aac: LoadField: d0 = r2->field_7
    //     0x685aac: ldur            d0, [x2, #7]
    // 0x685ab0: LoadField: d1 = r2->field_17
    //     0x685ab0: ldur            d1, [x2, #0x17]
    // 0x685ab4: LoadField: d2 = r0->field_13
    //     0x685ab4: ldur            d2, [x0, #0x13]
    // 0x685ab8: fadd            d3, d1, d2
    // 0x685abc: fsub            d1, d0, d3
    // 0x685ac0: fneg            d0, d1
    // 0x685ac4: stur            d0, [fp, #-0x10]
    // 0x685ac8: r0 = Offset()
    //     0x685ac8: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x685acc: d0 = 0.000000
    //     0x685acc: eor             v0.16b, v0.16b, v0.16b
    // 0x685ad0: StoreField: r0->field_7 = d0
    //     0x685ad0: stur            d0, [x0, #7]
    // 0x685ad4: ldur            d0, [fp, #-0x10]
    // 0x685ad8: StoreField: r0->field_f = d0
    //     0x685ad8: stur            d0, [x0, #0xf]
    // 0x685adc: ldur            x1, [fp, #-8]
    // 0x685ae0: StoreField: r1->field_7 = r0
    //     0x685ae0: stur            w0, [x1, #7]
    //     0x685ae4: ldurb           w16, [x1, #-1]
    //     0x685ae8: ldurb           w17, [x0, #-1]
    //     0x685aec: and             x16, x17, x16, lsr #2
    //     0x685af0: tst             x16, HEAP, lsr #32
    //     0x685af4: b.eq            #0x685afc
    //     0x685af8: bl              #0xd6826c
    // 0x685afc: b               #0x685c00
    // 0x685b00: ldr             x0, [fp, #0x18]
    // 0x685b04: ldur            x1, [fp, #-8]
    // 0x685b08: d0 = 0.000000
    //     0x685b08: eor             v0.16b, v0.16b, v0.16b
    // 0x685b0c: LoadField: d1 = r0->field_13
    //     0x685b0c: ldur            d1, [x0, #0x13]
    // 0x685b10: fneg            d2, d1
    // 0x685b14: stur            d2, [fp, #-0x10]
    // 0x685b18: r0 = Offset()
    //     0x685b18: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x685b1c: ldur            d0, [fp, #-0x10]
    // 0x685b20: StoreField: r0->field_7 = d0
    //     0x685b20: stur            d0, [x0, #7]
    // 0x685b24: d0 = 0.000000
    //     0x685b24: eor             v0.16b, v0.16b, v0.16b
    // 0x685b28: StoreField: r0->field_f = d0
    //     0x685b28: stur            d0, [x0, #0xf]
    // 0x685b2c: ldur            x3, [fp, #-8]
    // 0x685b30: StoreField: r3->field_7 = r0
    //     0x685b30: stur            w0, [x3, #7]
    //     0x685b34: ldurb           w16, [x3, #-1]
    //     0x685b38: ldurb           w17, [x0, #-1]
    //     0x685b3c: and             x16, x17, x16, lsr #2
    //     0x685b40: tst             x16, HEAP, lsr #32
    //     0x685b44: b.eq            #0x685b4c
    //     0x685b48: bl              #0xd682ac
    // 0x685b4c: b               #0x685c00
    // 0x685b50: ldr             x0, [fp, #0x18]
    // 0x685b54: ldr             x2, [fp, #0x10]
    // 0x685b58: ldur            x3, [fp, #-8]
    // 0x685b5c: d0 = 0.000000
    //     0x685b5c: eor             v0.16b, v0.16b, v0.16b
    // 0x685b60: cmp             x1, #2
    // 0x685b64: b.gt            #0x685bac
    // 0x685b68: LoadField: d1 = r0->field_13
    //     0x685b68: ldur            d1, [x0, #0x13]
    // 0x685b6c: fneg            d2, d1
    // 0x685b70: stur            d2, [fp, #-0x10]
    // 0x685b74: r0 = Offset()
    //     0x685b74: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x685b78: d0 = 0.000000
    //     0x685b78: eor             v0.16b, v0.16b, v0.16b
    // 0x685b7c: StoreField: r0->field_7 = d0
    //     0x685b7c: stur            d0, [x0, #7]
    // 0x685b80: ldur            d0, [fp, #-0x10]
    // 0x685b84: StoreField: r0->field_f = d0
    //     0x685b84: stur            d0, [x0, #0xf]
    // 0x685b88: ldur            x1, [fp, #-8]
    // 0x685b8c: StoreField: r1->field_7 = r0
    //     0x685b8c: stur            w0, [x1, #7]
    //     0x685b90: ldurb           w16, [x1, #-1]
    //     0x685b94: ldurb           w17, [x0, #-1]
    //     0x685b98: and             x16, x17, x16, lsr #2
    //     0x685b9c: tst             x16, HEAP, lsr #32
    //     0x685ba0: b.eq            #0x685ba8
    //     0x685ba4: bl              #0xd6826c
    // 0x685ba8: b               #0x685c00
    // 0x685bac: mov             x1, x3
    // 0x685bb0: LoadField: d1 = r2->field_7
    //     0x685bb0: ldur            d1, [x2, #7]
    // 0x685bb4: LoadField: d2 = r2->field_17
    //     0x685bb4: ldur            d2, [x2, #0x17]
    // 0x685bb8: LoadField: d3 = r0->field_13
    //     0x685bb8: ldur            d3, [x0, #0x13]
    // 0x685bbc: fadd            d4, d2, d3
    // 0x685bc0: fsub            d2, d1, d4
    // 0x685bc4: fneg            d1, d2
    // 0x685bc8: stur            d1, [fp, #-0x10]
    // 0x685bcc: r0 = Offset()
    //     0x685bcc: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x685bd0: ldur            d0, [fp, #-0x10]
    // 0x685bd4: StoreField: r0->field_7 = d0
    //     0x685bd4: stur            d0, [x0, #7]
    // 0x685bd8: d0 = 0.000000
    //     0x685bd8: eor             v0.16b, v0.16b, v0.16b
    // 0x685bdc: StoreField: r0->field_f = d0
    //     0x685bdc: stur            d0, [x0, #0xf]
    // 0x685be0: ldur            x1, [fp, #-8]
    // 0x685be4: StoreField: r1->field_7 = r0
    //     0x685be4: stur            w0, [x1, #7]
    //     0x685be8: ldurb           w16, [x1, #-1]
    //     0x685bec: ldurb           w17, [x0, #-1]
    //     0x685bf0: and             x16, x17, x16, lsr #2
    //     0x685bf4: tst             x16, HEAP, lsr #32
    //     0x685bf8: b.eq            #0x685c00
    //     0x685bfc: bl              #0xd6826c
    // 0x685c00: r0 = Null
    //     0x685c00: mov             x0, NULL
    // 0x685c04: LeaveFrame
    //     0x685c04: mov             SP, fp
    //     0x685c08: ldp             fp, lr, [SP], #0x10
    // 0x685c0c: ret
    //     0x685c0c: ret             
    // 0x685c10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x685c10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x685c14: b               #0x685a20
    // 0x685c18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x685c18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0x6bbe68, size: 0x94
    // 0x6bbe68: EnterFrame
    //     0x6bbe68: stp             fp, lr, [SP, #-0x10]!
    //     0x6bbe6c: mov             fp, SP
    // 0x6bbe70: AllocStack(0x8)
    //     0x6bbe70: sub             SP, SP, #8
    // 0x6bbe74: CheckStackOverflow
    //     0x6bbe74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bbe78: cmp             SP, x16
    //     0x6bbe7c: b.ls            #0x6bbef0
    // 0x6bbe80: ldr             x0, [fp, #0x18]
    // 0x6bbe84: LoadField: r3 = r0->field_17
    //     0x6bbe84: ldur            w3, [x0, #0x17]
    // 0x6bbe88: DecompressPointer r3
    //     0x6bbe88: add             x3, x3, HEAP, lsl #32
    // 0x6bbe8c: stur            x3, [fp, #-8]
    // 0x6bbe90: cmp             w3, NULL
    // 0x6bbe94: b.eq            #0x6bbef8
    // 0x6bbe98: mov             x0, x3
    // 0x6bbe9c: r2 = Null
    //     0x6bbe9c: mov             x2, NULL
    // 0x6bbea0: r1 = Null
    //     0x6bbea0: mov             x1, NULL
    // 0x6bbea4: r4 = LoadClassIdInstr(r0)
    //     0x6bbea4: ldur            x4, [x0, #-1]
    //     0x6bbea8: ubfx            x4, x4, #0xc, #0x14
    // 0x6bbeac: sub             x4, x4, #0x7f3
    // 0x6bbeb0: cmp             x4, #2
    // 0x6bbeb4: b.ls            #0x6bbecc
    // 0x6bbeb8: r8 = SliverPhysicalParentData
    //     0x6bbeb8: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5e0] Type: SliverPhysicalParentData
    //     0x6bbebc: ldr             x8, [x8, #0x5e0]
    // 0x6bbec0: r3 = Null
    //     0x6bbec0: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2d5f8] Null
    //     0x6bbec4: ldr             x3, [x3, #0x5f8]
    // 0x6bbec8: r0 = DefaultTypeTest()
    //     0x6bbec8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6bbecc: ldur            x16, [fp, #-8]
    // 0x6bbed0: ldr             lr, [fp, #0x10]
    // 0x6bbed4: stp             lr, x16, [SP, #-0x10]!
    // 0x6bbed8: r0 = applyPaintTransform()
    //     0x6bbed8: bl              #0x62adac  ; [package:flutter/src/rendering/sliver.dart] SliverPhysicalParentData::applyPaintTransform
    // 0x6bbedc: add             SP, SP, #0x10
    // 0x6bbee0: r0 = Null
    //     0x6bbee0: mov             x0, NULL
    // 0x6bbee4: LeaveFrame
    //     0x6bbee4: mov             SP, fp
    //     0x6bbee8: ldp             fp, lr, [SP], #0x10
    // 0x6bbeec: ret
    //     0x6bbeec: ret             
    // 0x6bbef0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bbef0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bbef4: b               #0x6bbe80
    // 0x6bbef8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6bbef8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ childMainAxisPosition(/* No info */) {
    // ** addr: 0xbcde18, size: 0x8c
    // 0xbcde18: EnterFrame
    //     0xbcde18: stp             fp, lr, [SP, #-0x10]!
    //     0xbcde1c: mov             fp, SP
    // 0xbcde20: AllocStack(0x8)
    //     0xbcde20: sub             SP, SP, #8
    // 0xbcde24: ldr             x0, [fp, #0x18]
    // 0xbcde28: LoadField: r3 = r0->field_27
    //     0xbcde28: ldur            w3, [x0, #0x27]
    // 0xbcde2c: DecompressPointer r3
    //     0xbcde2c: add             x3, x3, HEAP, lsl #32
    // 0xbcde30: stur            x3, [fp, #-8]
    // 0xbcde34: cmp             w3, NULL
    // 0xbcde38: b.eq            #0xbcde84
    // 0xbcde3c: mov             x0, x3
    // 0xbcde40: r2 = Null
    //     0xbcde40: mov             x2, NULL
    // 0xbcde44: r1 = Null
    //     0xbcde44: mov             x1, NULL
    // 0xbcde48: r4 = LoadClassIdInstr(r0)
    //     0xbcde48: ldur            x4, [x0, #-1]
    //     0xbcde4c: ubfx            x4, x4, #0xc, #0x14
    // 0xbcde50: cmp             x4, #0x80c
    // 0xbcde54: b.eq            #0xbcde6c
    // 0xbcde58: r8 = SliverConstraints
    //     0xbcde58: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0xbcde5c: ldr             x8, [x8, #0x5a8]
    // 0xbcde60: r3 = Null
    //     0xbcde60: add             x3, PP, #0x52, lsl #12  ; [pp+0x52e50] Null
    //     0xbcde64: ldr             x3, [x3, #0xe50]
    // 0xbcde68: r0 = DefaultTypeTest()
    //     0xbcde68: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xbcde6c: ldur            x0, [fp, #-8]
    // 0xbcde70: LoadField: d1 = r0->field_13
    //     0xbcde70: ldur            d1, [x0, #0x13]
    // 0xbcde74: fneg            d0, d1
    // 0xbcde78: LeaveFrame
    //     0xbcde78: mov             SP, fp
    //     0xbcde7c: ldp             fp, lr, [SP], #0x10
    // 0xbcde80: ret
    //     0xbcde80: ret             
    // 0xbcde84: r0 = StateError()
    //     0xbcde84: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbcde88: mov             x1, x0
    // 0xbcde8c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbcde8c: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0xbcde90: ldr             x0, [x0, #0x1e8]
    // 0xbcde94: StoreField: r1->field_b = r0
    //     0xbcde94: stur            w0, [x1, #0xb]
    // 0xbcde98: mov             x0, x1
    // 0xbcde9c: r0 = Throw()
    //     0xbcde9c: bl              #0xd67e38  ; ThrowStub
    // 0xbcdea0: brk             #0
  }
}

// class id: 2572, size: 0x58, field offset: 0x58
class RenderSliverToBoxAdapter extends RenderSliverSingleBoxAdapter {

  _ performLayout(/* No info */) {
    // ** addr: 0x685c1c, size: 0x318
    // 0x685c1c: EnterFrame
    //     0x685c1c: stp             fp, lr, [SP, #-0x10]!
    //     0x685c20: mov             fp, SP
    // 0x685c24: AllocStack(0x28)
    //     0x685c24: sub             SP, SP, #0x28
    // 0x685c28: CheckStackOverflow
    //     0x685c28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x685c2c: cmp             SP, x16
    //     0x685c30: b.ls            #0x685efc
    // 0x685c34: ldr             x3, [fp, #0x10]
    // 0x685c38: LoadField: r4 = r3->field_53
    //     0x685c38: ldur            w4, [x3, #0x53]
    // 0x685c3c: DecompressPointer r4
    //     0x685c3c: add             x4, x4, HEAP, lsl #32
    // 0x685c40: stur            x4, [fp, #-0x10]
    // 0x685c44: cmp             w4, NULL
    // 0x685c48: b.ne            #0x685c68
    // 0x685c4c: r0 = Instance_SliverGeometry
    //     0x685c4c: add             x0, PP, #0x2d, lsl #12  ; [pp+0x2d608] Obj!SliverGeometry@b3bed1
    //     0x685c50: ldr             x0, [x0, #0x608]
    // 0x685c54: StoreField: r3->field_4f = r0
    //     0x685c54: stur            w0, [x3, #0x4f]
    // 0x685c58: r0 = Null
    //     0x685c58: mov             x0, NULL
    // 0x685c5c: LeaveFrame
    //     0x685c5c: mov             SP, fp
    //     0x685c60: ldp             fp, lr, [SP], #0x10
    // 0x685c64: ret
    //     0x685c64: ret             
    // 0x685c68: LoadField: r5 = r3->field_27
    //     0x685c68: ldur            w5, [x3, #0x27]
    // 0x685c6c: DecompressPointer r5
    //     0x685c6c: add             x5, x5, HEAP, lsl #32
    // 0x685c70: stur            x5, [fp, #-8]
    // 0x685c74: cmp             w5, NULL
    // 0x685c78: b.eq            #0x685edc
    // 0x685c7c: mov             x0, x5
    // 0x685c80: r2 = Null
    //     0x685c80: mov             x2, NULL
    // 0x685c84: r1 = Null
    //     0x685c84: mov             x1, NULL
    // 0x685c88: r4 = LoadClassIdInstr(r0)
    //     0x685c88: ldur            x4, [x0, #-1]
    //     0x685c8c: ubfx            x4, x4, #0xc, #0x14
    // 0x685c90: cmp             x4, #0x80c
    // 0x685c94: b.eq            #0x685cac
    // 0x685c98: r8 = SliverConstraints
    //     0x685c98: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x685c9c: ldr             x8, [x8, #0x5a8]
    // 0x685ca0: r3 = Null
    //     0x685ca0: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2d610] Null
    //     0x685ca4: ldr             x3, [x3, #0x610]
    // 0x685ca8: r0 = DefaultTypeTest()
    //     0x685ca8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x685cac: ldur            x16, [fp, #-8]
    // 0x685cb0: SaveReg r16
    //     0x685cb0: str             x16, [SP, #-8]!
    // 0x685cb4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x685cb4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x685cb8: r0 = asBoxConstraints()
    //     0x685cb8: bl              #0x67a528  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::asBoxConstraints
    // 0x685cbc: add             SP, SP, #8
    // 0x685cc0: mov             x1, x0
    // 0x685cc4: ldur            x0, [fp, #-0x10]
    // 0x685cc8: r2 = LoadClassIdInstr(r0)
    //     0x685cc8: ldur            x2, [x0, #-1]
    //     0x685ccc: ubfx            x2, x2, #0xc, #0x14
    // 0x685cd0: stp             x1, x0, [SP, #-0x10]!
    // 0x685cd4: r16 = true
    //     0x685cd4: add             x16, NULL, #0x20  ; true
    // 0x685cd8: SaveReg r16
    //     0x685cd8: str             x16, [SP, #-8]!
    // 0x685cdc: mov             x0, x2
    // 0x685ce0: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x685ce0: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x685ce4: ldr             x4, [x4, #0x1c8]
    // 0x685ce8: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x685ce8: mov             x17, #0xcdfb
    //     0x685cec: add             lr, x0, x17
    //     0x685cf0: ldr             lr, [x21, lr, lsl #3]
    //     0x685cf4: blr             lr
    // 0x685cf8: add             SP, SP, #0x18
    // 0x685cfc: ldur            x16, [fp, #-8]
    // 0x685d00: SaveReg r16
    //     0x685d00: str             x16, [SP, #-8]!
    // 0x685d04: r0 = axis()
    //     0x685d04: bl              #0x643150  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0x685d08: add             SP, SP, #8
    // 0x685d0c: LoadField: r1 = r0->field_7
    //     0x685d0c: ldur            x1, [x0, #7]
    // 0x685d10: cmp             x1, #0
    // 0x685d14: b.gt            #0x685d44
    // 0x685d18: ldr             x0, [fp, #0x10]
    // 0x685d1c: LoadField: r1 = r0->field_53
    //     0x685d1c: ldur            w1, [x0, #0x53]
    // 0x685d20: DecompressPointer r1
    //     0x685d20: add             x1, x1, HEAP, lsl #32
    // 0x685d24: cmp             w1, NULL
    // 0x685d28: b.eq            #0x685f04
    // 0x685d2c: LoadField: r2 = r1->field_57
    //     0x685d2c: ldur            w2, [x1, #0x57]
    // 0x685d30: DecompressPointer r2
    //     0x685d30: add             x2, x2, HEAP, lsl #32
    // 0x685d34: cmp             w2, NULL
    // 0x685d38: b.eq            #0x685f08
    // 0x685d3c: LoadField: d0 = r2->field_7
    //     0x685d3c: ldur            d0, [x2, #7]
    // 0x685d40: b               #0x685d6c
    // 0x685d44: ldr             x0, [fp, #0x10]
    // 0x685d48: LoadField: r1 = r0->field_53
    //     0x685d48: ldur            w1, [x0, #0x53]
    // 0x685d4c: DecompressPointer r1
    //     0x685d4c: add             x1, x1, HEAP, lsl #32
    // 0x685d50: cmp             w1, NULL
    // 0x685d54: b.eq            #0x685f0c
    // 0x685d58: LoadField: r2 = r1->field_57
    //     0x685d58: ldur            w2, [x1, #0x57]
    // 0x685d5c: DecompressPointer r2
    //     0x685d5c: add             x2, x2, HEAP, lsl #32
    // 0x685d60: cmp             w2, NULL
    // 0x685d64: b.eq            #0x685f10
    // 0x685d68: LoadField: d0 = r2->field_f
    //     0x685d68: ldur            d0, [x2, #0xf]
    // 0x685d6c: ldur            x1, [fp, #-8]
    // 0x685d70: stur            d0, [fp, #-0x18]
    // 0x685d74: r2 = inline_Allocate_Double()
    //     0x685d74: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x685d78: add             x2, x2, #0x10
    //     0x685d7c: cmp             x3, x2
    //     0x685d80: b.ls            #0x685f14
    //     0x685d84: str             x2, [THR, #0x60]  ; THR::top
    //     0x685d88: sub             x2, x2, #0xf
    //     0x685d8c: mov             x3, #0xd108
    //     0x685d90: movk            x3, #3, lsl #16
    //     0x685d94: stur            x3, [x2, #-1]
    // 0x685d98: StoreField: r2->field_7 = d0
    //     0x685d98: stur            d0, [x2, #7]
    // 0x685d9c: stur            x2, [fp, #-0x10]
    // 0x685da0: stp             x1, x0, [SP, #-0x10]!
    // 0x685da4: stp             x2, xzr, [SP, #-0x10]!
    // 0x685da8: r0 = calculatePaintOffset()
    //     0x685da8: bl              #0x677ba0  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0x685dac: add             SP, SP, #0x20
    // 0x685db0: stur            d0, [fp, #-0x20]
    // 0x685db4: ldr             x16, [fp, #0x10]
    // 0x685db8: ldur            lr, [fp, #-8]
    // 0x685dbc: stp             lr, x16, [SP, #-0x10]!
    // 0x685dc0: ldur            x16, [fp, #-0x10]
    // 0x685dc4: stp             x16, xzr, [SP, #-0x10]!
    // 0x685dc8: r0 = calculateCacheOffset()
    //     0x685dc8: bl              #0x677aa4  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculateCacheOffset
    // 0x685dcc: add             SP, SP, #0x20
    // 0x685dd0: ldur            x0, [fp, #-8]
    // 0x685dd4: stur            d0, [fp, #-0x28]
    // 0x685dd8: LoadField: d1 = r0->field_2b
    //     0x685dd8: ldur            d1, [x0, #0x2b]
    // 0x685ddc: ldur            d2, [fp, #-0x18]
    // 0x685de0: fcmp            d2, d1
    // 0x685de4: b.vs            #0x685df8
    // 0x685de8: b.le            #0x685df8
    // 0x685dec: r2 = true
    //     0x685dec: add             x2, NULL, #0x20  ; true
    // 0x685df0: d1 = 0.000000
    //     0x685df0: eor             v1.16b, v1.16b, v1.16b
    // 0x685df4: b               #0x685e1c
    // 0x685df8: d1 = 0.000000
    //     0x685df8: eor             v1.16b, v1.16b, v1.16b
    // 0x685dfc: LoadField: d3 = r0->field_13
    //     0x685dfc: ldur            d3, [x0, #0x13]
    // 0x685e00: fcmp            d3, d1
    // 0x685e04: b.vs            #0x685e0c
    // 0x685e08: b.gt            #0x685e14
    // 0x685e0c: r1 = false
    //     0x685e0c: add             x1, NULL, #0x30  ; false
    // 0x685e10: b               #0x685e18
    // 0x685e14: r1 = true
    //     0x685e14: add             x1, NULL, #0x20  ; true
    // 0x685e18: mov             x2, x1
    // 0x685e1c: ldr             x1, [fp, #0x10]
    // 0x685e20: ldur            d3, [fp, #-0x20]
    // 0x685e24: stur            x2, [fp, #-0x10]
    // 0x685e28: r0 = SliverGeometry()
    //     0x685e28: bl              #0x679334  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x54)
    // 0x685e2c: mov             x1, x0
    // 0x685e30: ldur            d0, [fp, #-0x18]
    // 0x685e34: StoreField: r1->field_7 = d0
    //     0x685e34: stur            d0, [x1, #7]
    // 0x685e38: ldur            d1, [fp, #-0x20]
    // 0x685e3c: StoreField: r1->field_17 = d1
    //     0x685e3c: stur            d1, [x1, #0x17]
    // 0x685e40: d2 = 0.000000
    //     0x685e40: eor             v2.16b, v2.16b, v2.16b
    // 0x685e44: StoreField: r1->field_f = d2
    //     0x685e44: stur            d2, [x1, #0xf]
    // 0x685e48: StoreField: r1->field_27 = d0
    //     0x685e48: stur            d0, [x1, #0x27]
    // 0x685e4c: StoreField: r1->field_2f = d2
    //     0x685e4c: stur            d2, [x1, #0x2f]
    // 0x685e50: ldur            x0, [fp, #-0x10]
    // 0x685e54: StoreField: r1->field_43 = r0
    //     0x685e54: stur            w0, [x1, #0x43]
    // 0x685e58: StoreField: r1->field_1f = d1
    //     0x685e58: stur            d1, [x1, #0x1f]
    // 0x685e5c: StoreField: r1->field_37 = d1
    //     0x685e5c: stur            d1, [x1, #0x37]
    // 0x685e60: ldur            d0, [fp, #-0x28]
    // 0x685e64: StoreField: r1->field_4b = d0
    //     0x685e64: stur            d0, [x1, #0x4b]
    // 0x685e68: fcmp            d1, d2
    // 0x685e6c: b.vs            #0x685e74
    // 0x685e70: b.gt            #0x685e7c
    // 0x685e74: r0 = false
    //     0x685e74: add             x0, NULL, #0x30  ; false
    // 0x685e78: b               #0x685e80
    // 0x685e7c: r0 = true
    //     0x685e7c: add             x0, NULL, #0x20  ; true
    // 0x685e80: StoreField: r1->field_3f = r0
    //     0x685e80: stur            w0, [x1, #0x3f]
    // 0x685e84: mov             x0, x1
    // 0x685e88: ldr             x2, [fp, #0x10]
    // 0x685e8c: StoreField: r2->field_4f = r0
    //     0x685e8c: stur            w0, [x2, #0x4f]
    //     0x685e90: ldurb           w16, [x2, #-1]
    //     0x685e94: ldurb           w17, [x0, #-1]
    //     0x685e98: and             x16, x17, x16, lsr #2
    //     0x685e9c: tst             x16, HEAP, lsr #32
    //     0x685ea0: b.eq            #0x685ea8
    //     0x685ea4: bl              #0xd6828c
    // 0x685ea8: LoadField: r0 = r2->field_53
    //     0x685ea8: ldur            w0, [x2, #0x53]
    // 0x685eac: DecompressPointer r0
    //     0x685eac: add             x0, x0, HEAP, lsl #32
    // 0x685eb0: cmp             w0, NULL
    // 0x685eb4: b.eq            #0x685f30
    // 0x685eb8: stp             x0, x2, [SP, #-0x10]!
    // 0x685ebc: ldur            x16, [fp, #-8]
    // 0x685ec0: stp             x1, x16, [SP, #-0x10]!
    // 0x685ec4: r0 = setChildParentData()
    //     0x685ec4: bl              #0x685a08  ; [package:flutter/src/rendering/sliver.dart] RenderSliverSingleBoxAdapter::setChildParentData
    // 0x685ec8: add             SP, SP, #0x20
    // 0x685ecc: r0 = Null
    //     0x685ecc: mov             x0, NULL
    // 0x685ed0: LeaveFrame
    //     0x685ed0: mov             SP, fp
    //     0x685ed4: ldp             fp, lr, [SP], #0x10
    // 0x685ed8: ret
    //     0x685ed8: ret             
    // 0x685edc: r0 = StateError()
    //     0x685edc: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x685ee0: mov             x1, x0
    // 0x685ee4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x685ee4: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x685ee8: ldr             x0, [x0, #0x1e8]
    // 0x685eec: StoreField: r1->field_b = r0
    //     0x685eec: stur            w0, [x1, #0xb]
    // 0x685ef0: mov             x0, x1
    // 0x685ef4: r0 = Throw()
    //     0x685ef4: bl              #0xd67e38  ; ThrowStub
    // 0x685ef8: brk             #0
    // 0x685efc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x685efc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x685f00: b               #0x685c34
    // 0x685f04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x685f04: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x685f08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x685f08: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x685f0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x685f0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x685f10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x685f10: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x685f14: SaveReg d0
    //     0x685f14: str             q0, [SP, #-0x10]!
    // 0x685f18: stp             x0, x1, [SP, #-0x10]!
    // 0x685f1c: r0 = AllocateDouble()
    //     0x685f1c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x685f20: mov             x2, x0
    // 0x685f24: ldp             x0, x1, [SP], #0x10
    // 0x685f28: RestoreReg d0
    //     0x685f28: ldr             q0, [SP], #0x10
    // 0x685f2c: b               #0x685d98
    // 0x685f30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x685f30: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2705, size: 0x54, field offset: 0x8
//   const constructor, 
class SliverGeometry extends _DiagnosticableTree&Object&Diagnosticable {

  _Mint field_8;
  _Mint field_10;
  _Mint field_18;
  _Mint field_20;
  _Mint field_28;
  _Mint field_30;
  _Mint field_38;
  bool field_40;
  bool field_44;
  _Mint field_4c;

  _ toStringShort(/* No info */) {
    // ** addr: 0xa78014, size: 0xc
    // 0xa78014: r0 = "SliverGeometry"
    //     0xa78014: add             x0, PP, #0x37, lsl #12  ; [pp+0x37000] "SliverGeometry"
    //     0xa78018: ldr             x0, [x0]
    // 0xa7801c: ret
    //     0xa7801c: ret             
  }
}

// class id: 5911, size: 0x14, field offset: 0x14
enum GrowthDirection extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16f98, size: 0x5c
    // 0xb16f98: EnterFrame
    //     0xb16f98: stp             fp, lr, [SP, #-0x10]!
    //     0xb16f9c: mov             fp, SP
    // 0xb16fa0: CheckStackOverflow
    //     0xb16fa0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16fa4: cmp             SP, x16
    //     0xb16fa8: b.ls            #0xb16fec
    // 0xb16fac: r1 = Null
    //     0xb16fac: mov             x1, NULL
    // 0xb16fb0: r2 = 4
    //     0xb16fb0: mov             x2, #4
    // 0xb16fb4: r0 = AllocateArray()
    //     0xb16fb4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16fb8: r17 = "GrowthDirection."
    //     0xb16fb8: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fc30] "GrowthDirection."
    //     0xb16fbc: ldr             x17, [x17, #0xc30]
    // 0xb16fc0: StoreField: r0->field_f = r17
    //     0xb16fc0: stur            w17, [x0, #0xf]
    // 0xb16fc4: ldr             x1, [fp, #0x10]
    // 0xb16fc8: LoadField: r2 = r1->field_f
    //     0xb16fc8: ldur            w2, [x1, #0xf]
    // 0xb16fcc: DecompressPointer r2
    //     0xb16fcc: add             x2, x2, HEAP, lsl #32
    // 0xb16fd0: StoreField: r0->field_13 = r2
    //     0xb16fd0: stur            w2, [x0, #0x13]
    // 0xb16fd4: SaveReg r0
    //     0xb16fd4: str             x0, [SP, #-8]!
    // 0xb16fd8: r0 = _interpolate()
    //     0xb16fd8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16fdc: add             SP, SP, #8
    // 0xb16fe0: LeaveFrame
    //     0xb16fe0: mov             SP, fp
    //     0xb16fe4: ldp             fp, lr, [SP], #0x10
    // 0xb16fe8: ret
    //     0xb16fe8: ret             
    // 0xb16fec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16fec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16ff0: b               #0xb16fac
  }
}

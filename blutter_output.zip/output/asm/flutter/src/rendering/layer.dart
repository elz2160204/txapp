// lib: , url: package:flutter/src/rendering/layer.dart

// class id: 1049405, size: 0x8
class :: {
}

// class id: 2026, size: 0x10, field offset: 0x8
class LayerLink extends Object {

  _ _unregisterLeader(/* No info */) {
    // ** addr: 0x666420, size: 0x24
    // 0x666420: ldr             x1, [SP, #8]
    // 0x666424: LoadField: r2 = r1->field_7
    //     0x666424: ldur            w2, [x1, #7]
    // 0x666428: DecompressPointer r2
    //     0x666428: add             x2, x2, HEAP, lsl #32
    // 0x66642c: ldr             x3, [SP]
    // 0x666430: cmp             w2, w3
    // 0x666434: b.ne            #0x66643c
    // 0x666438: StoreField: r1->field_7 = rNULL
    //     0x666438: stur            NULL, [x1, #7]
    // 0x66643c: r0 = Null
    //     0x66643c: mov             x0, NULL
    // 0x666440: ret
    //     0x666440: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0xae5754, size: 0xb8
    // 0xae5754: EnterFrame
    //     0xae5754: stp             fp, lr, [SP, #-0x10]!
    //     0xae5758: mov             fp, SP
    // 0xae575c: AllocStack(0x10)
    //     0xae575c: sub             SP, SP, #0x10
    // 0xae5760: SetupParameters(LayerLink this /* r1, fp-0x8 */)
    //     0xae5760: mov             x0, x4
    //     0xae5764: ldur            w1, [x0, #0x13]
    //     0xae5768: add             x1, x1, HEAP, lsl #32
    //     0xae576c: sub             x0, x1, #2
    //     0xae5770: add             x1, fp, w0, sxtw #2
    //     0xae5774: ldr             x1, [x1, #0x10]
    //     0xae5778: stur            x1, [fp, #-8]
    // 0xae577c: CheckStackOverflow
    //     0xae577c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae5780: cmp             SP, x16
    //     0xae5784: b.ls            #0xae5804
    // 0xae5788: SaveReg r1
    //     0xae5788: str             x1, [SP, #-8]!
    // 0xae578c: r0 = describeIdentity()
    //     0xae578c: bl              #0xa77c6c  ; [package:flutter/src/foundation/diagnostics.dart] ::describeIdentity
    // 0xae5790: add             SP, SP, #8
    // 0xae5794: r1 = Null
    //     0xae5794: mov             x1, NULL
    // 0xae5798: r2 = 8
    //     0xae5798: mov             x2, #8
    // 0xae579c: stur            x0, [fp, #-0x10]
    // 0xae57a0: r0 = AllocateArray()
    //     0xae57a0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae57a4: mov             x1, x0
    // 0xae57a8: ldur            x0, [fp, #-0x10]
    // 0xae57ac: StoreField: r1->field_f = r0
    //     0xae57ac: stur            w0, [x1, #0xf]
    // 0xae57b0: r17 = "("
    //     0xae57b0: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xae57b4: StoreField: r1->field_13 = r17
    //     0xae57b4: stur            w17, [x1, #0x13]
    // 0xae57b8: ldur            x0, [fp, #-8]
    // 0xae57bc: LoadField: r2 = r0->field_7
    //     0xae57bc: ldur            w2, [x0, #7]
    // 0xae57c0: DecompressPointer r2
    //     0xae57c0: add             x2, x2, HEAP, lsl #32
    // 0xae57c4: cmp             w2, NULL
    // 0xae57c8: b.eq            #0xae57d8
    // 0xae57cc: r0 = "<linked>"
    //     0xae57cc: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3fcf0] "<linked>"
    //     0xae57d0: ldr             x0, [x0, #0xcf0]
    // 0xae57d4: b               #0xae57e0
    // 0xae57d8: r0 = "<dangling>"
    //     0xae57d8: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3fcf8] "<dangling>"
    //     0xae57dc: ldr             x0, [x0, #0xcf8]
    // 0xae57e0: StoreField: r1->field_17 = r0
    //     0xae57e0: stur            w0, [x1, #0x17]
    // 0xae57e4: r17 = ")"
    //     0xae57e4: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae57e8: StoreField: r1->field_1b = r17
    //     0xae57e8: stur            w17, [x1, #0x1b]
    // 0xae57ec: SaveReg r1
    //     0xae57ec: str             x1, [SP, #-8]!
    // 0xae57f0: r0 = _interpolate()
    //     0xae57f0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae57f4: add             SP, SP, #8
    // 0xae57f8: LeaveFrame
    //     0xae57f8: mov             SP, fp
    //     0xae57fc: ldp             fp, lr, [SP], #0x10
    // 0xae5800: ret
    //     0xae5800: ret             
    // 0xae5804: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae5804: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae5808: b               #0xae5788
  }
}

// class id: 2027, size: 0x10, field offset: 0x8
class LayerHandle<X0 bound Layer> extends Object {

  set _ layer=(/* No info */) {
    // ** addr: 0x5bbc7c, size: 0xc4
    // 0x5bbc7c: EnterFrame
    //     0x5bbc7c: stp             fp, lr, [SP, #-0x10]!
    //     0x5bbc80: mov             fp, SP
    // 0x5bbc84: AllocStack(0x8)
    //     0x5bbc84: sub             SP, SP, #8
    // 0x5bbc88: CheckStackOverflow
    //     0x5bbc88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5bbc8c: cmp             SP, x16
    //     0x5bbc90: b.ls            #0x5bbd38
    // 0x5bbc94: ldr             x2, [fp, #0x18]
    // 0x5bbc98: LoadField: r3 = r2->field_b
    //     0x5bbc98: ldur            w3, [x2, #0xb]
    // 0x5bbc9c: DecompressPointer r3
    //     0x5bbc9c: add             x3, x3, HEAP, lsl #32
    // 0x5bbca0: ldr             x0, [fp, #0x10]
    // 0x5bbca4: mov             x1, x3
    // 0x5bbca8: stur            x3, [fp, #-8]
    // 0x5bbcac: stp             x1, x0, [SP, #-0x10]!
    // 0x5bbcb0: r24 = OptimizedIdenticalWithNumberCheckStub
    //     0x5bbcb0: ldr             x24, [PP, #0x198]  ; [pp+0x198] Stub: OptimizedIdenticalWithNumberCheck (0x4ae5e4)
    // 0x5bbcb4: LoadField: r30 = r24->field_7
    //     0x5bbcb4: ldur            lr, [x24, #7]
    // 0x5bbcb8: blr             lr
    // 0x5bbcbc: ldp             x1, x0, [SP], #0x10
    // 0x5bbcc0: b.ne            #0x5bbcd4
    // 0x5bbcc4: r0 = Null
    //     0x5bbcc4: mov             x0, NULL
    // 0x5bbcc8: LeaveFrame
    //     0x5bbcc8: mov             SP, fp
    //     0x5bbccc: ldp             fp, lr, [SP], #0x10
    // 0x5bbcd0: ret
    //     0x5bbcd0: ret             
    // 0x5bbcd4: ldur            x0, [fp, #-8]
    // 0x5bbcd8: cmp             w0, NULL
    // 0x5bbcdc: b.eq            #0x5bbcec
    // 0x5bbce0: SaveReg r0
    //     0x5bbce0: str             x0, [SP, #-8]!
    // 0x5bbce4: r0 = _unref()
    //     0x5bbce4: bl              #0x5bbd64  ; [package:flutter/src/rendering/layer.dart] Layer::_unref
    // 0x5bbce8: add             SP, SP, #8
    // 0x5bbcec: ldr             x1, [fp, #0x18]
    // 0x5bbcf0: ldr             x2, [fp, #0x10]
    // 0x5bbcf4: mov             x0, x2
    // 0x5bbcf8: StoreField: r1->field_b = r0
    //     0x5bbcf8: stur            w0, [x1, #0xb]
    //     0x5bbcfc: ldurb           w16, [x1, #-1]
    //     0x5bbd00: ldurb           w17, [x0, #-1]
    //     0x5bbd04: and             x16, x17, x16, lsr #2
    //     0x5bbd08: tst             x16, HEAP, lsr #32
    //     0x5bbd0c: b.eq            #0x5bbd14
    //     0x5bbd10: bl              #0xd6826c
    // 0x5bbd14: cmp             w2, NULL
    // 0x5bbd18: b.eq            #0x5bbd28
    // 0x5bbd1c: LoadField: r1 = r2->field_27
    //     0x5bbd1c: ldur            x1, [x2, #0x27]
    // 0x5bbd20: add             x3, x1, #1
    // 0x5bbd24: StoreField: r2->field_27 = r3
    //     0x5bbd24: stur            x3, [x2, #0x27]
    // 0x5bbd28: r0 = Null
    //     0x5bbd28: mov             x0, NULL
    // 0x5bbd2c: LeaveFrame
    //     0x5bbd2c: mov             SP, fp
    //     0x5bbd30: ldp             fp, lr, [SP], #0x10
    // 0x5bbd34: ret
    //     0x5bbd34: ret             
    // 0x5bbd38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5bbd38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5bbd3c: b               #0x5bbc94
  }
  _ toString(/* No info */) {
    // ** addr: 0xae568c, size: 0xc8
    // 0xae568c: EnterFrame
    //     0xae568c: stp             fp, lr, [SP, #-0x10]!
    //     0xae5690: mov             fp, SP
    // 0xae5694: AllocStack(0x8)
    //     0xae5694: sub             SP, SP, #8
    // 0xae5698: CheckStackOverflow
    //     0xae5698: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae569c: cmp             SP, x16
    //     0xae56a0: b.ls            #0xae574c
    // 0xae56a4: r1 = Null
    //     0xae56a4: mov             x1, NULL
    // 0xae56a8: r2 = 6
    //     0xae56a8: mov             x2, #6
    // 0xae56ac: r0 = AllocateArray()
    //     0xae56ac: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae56b0: mov             x1, x0
    // 0xae56b4: stur            x1, [fp, #-8]
    // 0xae56b8: r17 = "LayerHandle("
    //     0xae56b8: ldr             x17, [PP, #0x7490]  ; [pp+0x7490] "LayerHandle("
    // 0xae56bc: StoreField: r1->field_f = r17
    //     0xae56bc: stur            w17, [x1, #0xf]
    // 0xae56c0: ldr             x0, [fp, #0x10]
    // 0xae56c4: LoadField: r2 = r0->field_b
    //     0xae56c4: ldur            w2, [x0, #0xb]
    // 0xae56c8: DecompressPointer r2
    //     0xae56c8: add             x2, x2, HEAP, lsl #32
    // 0xae56cc: cmp             w2, NULL
    // 0xae56d0: b.eq            #0xae56fc
    // 0xae56d4: r0 = LoadClassIdInstr(r2)
    //     0xae56d4: ldur            x0, [x2, #-1]
    //     0xae56d8: ubfx            x0, x0, #0xc, #0x14
    // 0xae56dc: SaveReg r2
    //     0xae56dc: str             x2, [SP, #-8]!
    // 0xae56e0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xae56e0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xae56e4: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xae56e4: mov             x17, #0x3f73
    //     0xae56e8: add             lr, x0, x17
    //     0xae56ec: ldr             lr, [x21, lr, lsl #3]
    //     0xae56f0: blr             lr
    // 0xae56f4: add             SP, SP, #8
    // 0xae56f8: b               #0xae5700
    // 0xae56fc: r0 = "DISPOSED"
    //     0xae56fc: ldr             x0, [PP, #0x7498]  ; [pp+0x7498] "DISPOSED"
    // 0xae5700: ldur            x2, [fp, #-8]
    // 0xae5704: mov             x1, x2
    // 0xae5708: ArrayStore: r1[1] = r0  ; List_4
    //     0xae5708: add             x25, x1, #0x13
    //     0xae570c: str             w0, [x25]
    //     0xae5710: tbz             w0, #0, #0xae572c
    //     0xae5714: ldurb           w16, [x1, #-1]
    //     0xae5718: ldurb           w17, [x0, #-1]
    //     0xae571c: and             x16, x17, x16, lsr #2
    //     0xae5720: tst             x16, HEAP, lsr #32
    //     0xae5724: b.eq            #0xae572c
    //     0xae5728: bl              #0xd67e5c
    // 0xae572c: r17 = ")"
    //     0xae572c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae5730: StoreField: r2->field_17 = r17
    //     0xae5730: stur            w17, [x2, #0x17]
    // 0xae5734: SaveReg r2
    //     0xae5734: str             x2, [SP, #-8]!
    // 0xae5738: r0 = _interpolate()
    //     0xae5738: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae573c: add             SP, SP, #8
    // 0xae5740: LeaveFrame
    //     0xae5740: mov             SP, fp
    //     0xae5744: ldp             fp, lr, [SP], #0x10
    // 0xae5748: ret
    //     0xae5748: ret             
    // 0xae574c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae574c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae5750: b               #0xae56a4
  }
}

// class id: 2028, size: 0x10, field offset: 0x8
class AnnotationResult<X0> extends Object {
}

// class id: 2029, size: 0x14, field offset: 0x8
//   const constructor, 
class AnnotationEntry<X0> extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xae5604, size: 0x88
    // 0xae5604: EnterFrame
    //     0xae5604: stp             fp, lr, [SP, #-0x10]!
    //     0xae5608: mov             fp, SP
    // 0xae560c: CheckStackOverflow
    //     0xae560c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae5610: cmp             SP, x16
    //     0xae5614: b.ls            #0xae5684
    // 0xae5618: r1 = Null
    //     0xae5618: mov             x1, NULL
    // 0xae561c: r2 = 12
    //     0xae561c: mov             x2, #0xc
    // 0xae5620: r0 = AllocateArray()
    //     0xae5620: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae5624: r17 = "AnnotationEntry"
    //     0xae5624: add             x17, PP, #0x52, lsl #12  ; [pp+0x52ef8] "AnnotationEntry"
    //     0xae5628: ldr             x17, [x17, #0xef8]
    // 0xae562c: StoreField: r0->field_f = r17
    //     0xae562c: stur            w17, [x0, #0xf]
    // 0xae5630: r17 = "(annotation: "
    //     0xae5630: add             x17, PP, #0x52, lsl #12  ; [pp+0x52f00] "(annotation: "
    //     0xae5634: ldr             x17, [x17, #0xf00]
    // 0xae5638: StoreField: r0->field_13 = r17
    //     0xae5638: stur            w17, [x0, #0x13]
    // 0xae563c: ldr             x1, [fp, #0x10]
    // 0xae5640: LoadField: r2 = r1->field_b
    //     0xae5640: ldur            w2, [x1, #0xb]
    // 0xae5644: DecompressPointer r2
    //     0xae5644: add             x2, x2, HEAP, lsl #32
    // 0xae5648: StoreField: r0->field_17 = r2
    //     0xae5648: stur            w2, [x0, #0x17]
    // 0xae564c: r17 = ", localPosition: "
    //     0xae564c: add             x17, PP, #0x52, lsl #12  ; [pp+0x52f08] ", localPosition: "
    //     0xae5650: ldr             x17, [x17, #0xf08]
    // 0xae5654: StoreField: r0->field_1b = r17
    //     0xae5654: stur            w17, [x0, #0x1b]
    // 0xae5658: LoadField: r2 = r1->field_f
    //     0xae5658: ldur            w2, [x1, #0xf]
    // 0xae565c: DecompressPointer r2
    //     0xae565c: add             x2, x2, HEAP, lsl #32
    // 0xae5660: StoreField: r0->field_1f = r2
    //     0xae5660: stur            w2, [x0, #0x1f]
    // 0xae5664: r17 = ")"
    //     0xae5664: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae5668: StoreField: r0->field_23 = r17
    //     0xae5668: stur            w17, [x0, #0x23]
    // 0xae566c: SaveReg r0
    //     0xae566c: str             x0, [SP, #-8]!
    // 0xae5670: r0 = _interpolate()
    //     0xae5670: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae5674: add             SP, SP, #8
    // 0xae5678: LeaveFrame
    //     0xae5678: mov             SP, fp
    //     0xae567c: ldp             fp, lr, [SP], #0x10
    // 0xae5680: ret
    //     0xae5680: ret             
    // 0xae5684: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae5684: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae5688: b               #0xae5618
  }
}

// class id: 2380, size: 0x40, field offset: 0x18
abstract class Layer extends _RenderObject&AbstractNode&DiagnosticableTreeMixin {

  _ _unref(/* No info */) {
    // ** addr: 0x5bbd64, size: 0x64
    // 0x5bbd64: EnterFrame
    //     0x5bbd64: stp             fp, lr, [SP, #-0x10]!
    //     0x5bbd68: mov             fp, SP
    // 0x5bbd6c: CheckStackOverflow
    //     0x5bbd6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5bbd70: cmp             SP, x16
    //     0x5bbd74: b.ls            #0x5bbdc0
    // 0x5bbd78: ldr             x0, [fp, #0x10]
    // 0x5bbd7c: LoadField: r1 = r0->field_27
    //     0x5bbd7c: ldur            x1, [x0, #0x27]
    // 0x5bbd80: sub             x2, x1, #1
    // 0x5bbd84: StoreField: r0->field_27 = r2
    //     0x5bbd84: stur            x2, [x0, #0x27]
    // 0x5bbd88: cbnz            x2, #0x5bbdb0
    // 0x5bbd8c: r1 = LoadClassIdInstr(r0)
    //     0x5bbd8c: ldur            x1, [x0, #-1]
    //     0x5bbd90: ubfx            x1, x1, #0xc, #0x14
    // 0x5bbd94: SaveReg r0
    //     0x5bbd94: str             x0, [SP, #-8]!
    // 0x5bbd98: mov             x0, x1
    // 0x5bbd9c: r0 = GDT[cid_x0 + 0x9998]()
    //     0x5bbd9c: mov             x17, #0x9998
    //     0x5bbda0: add             lr, x0, x17
    //     0x5bbda4: ldr             lr, [x21, lr, lsl #3]
    //     0x5bbda8: blr             lr
    // 0x5bbdac: add             SP, SP, #8
    // 0x5bbdb0: r0 = Null
    //     0x5bbdb0: mov             x0, NULL
    // 0x5bbdb4: LeaveFrame
    //     0x5bbdb4: mov             SP, fp
    //     0x5bbdb8: ldp             fp, lr, [SP], #0x10
    // 0x5bbdbc: ret
    //     0x5bbdbc: ret             
    // 0x5bbdc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5bbdc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5bbdc4: b               #0x5bbd78
  }
  _ Layer(/* No info */) {
    // ** addr: 0x5bbe7c, size: 0xac
    // 0x5bbe7c: EnterFrame
    //     0x5bbe7c: stp             fp, lr, [SP, #-0x10]!
    //     0x5bbe80: mov             fp, SP
    // 0x5bbe84: r1 = true
    //     0x5bbe84: add             x1, NULL, #0x20  ; true
    // 0x5bbe88: r0 = 0
    //     0x5bbe88: mov             x0, #0
    // 0x5bbe8c: CheckStackOverflow
    //     0x5bbe8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5bbe90: cmp             SP, x16
    //     0x5bbe94: b.ls            #0x5bbf20
    // 0x5bbe98: ldr             x2, [fp, #0x10]
    // 0x5bbe9c: StoreField: r2->field_1b = r0
    //     0x5bbe9c: stur            x0, [x2, #0x1b]
    // 0x5bbea0: StoreField: r2->field_27 = r0
    //     0x5bbea0: stur            x0, [x2, #0x27]
    // 0x5bbea4: StoreField: r2->field_2f = r1
    //     0x5bbea4: stur            w1, [x2, #0x2f]
    // 0x5bbea8: r16 = <int, (dynamic this) => void?>
    //     0x5bbea8: ldr             x16, [PP, #0x4ca0]  ; [pp+0x4ca0] TypeArguments: <int, (dynamic this) => void?>
    // 0x5bbeac: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x5bbeb0: stp             lr, x16, [SP, #-0x10]!
    // 0x5bbeb4: r0 = Map._fromLiteral()
    //     0x5bbeb4: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x5bbeb8: add             SP, SP, #0x10
    // 0x5bbebc: ldr             x2, [fp, #0x10]
    // 0x5bbec0: StoreField: r2->field_17 = r0
    //     0x5bbec0: stur            w0, [x2, #0x17]
    //     0x5bbec4: tbz             w0, #0, #0x5bbee0
    //     0x5bbec8: ldurb           w16, [x2, #-1]
    //     0x5bbecc: ldurb           w17, [x0, #-1]
    //     0x5bbed0: and             x16, x17, x16, lsr #2
    //     0x5bbed4: tst             x16, HEAP, lsr #32
    //     0x5bbed8: b.eq            #0x5bbee0
    //     0x5bbedc: bl              #0xd6828c
    // 0x5bbee0: r1 = <Layer>
    //     0x5bbee0: ldr             x1, [PP, #0x4ca8]  ; [pp+0x4ca8] TypeArguments: <Layer>
    // 0x5bbee4: r0 = LayerHandle()
    //     0x5bbee4: bl              #0x5bbf28  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x5bbee8: ldr             x1, [fp, #0x10]
    // 0x5bbeec: StoreField: r1->field_23 = r0
    //     0x5bbeec: stur            w0, [x1, #0x23]
    //     0x5bbef0: ldurb           w16, [x1, #-1]
    //     0x5bbef4: ldurb           w17, [x0, #-1]
    //     0x5bbef8: and             x16, x17, x16, lsr #2
    //     0x5bbefc: tst             x16, HEAP, lsr #32
    //     0x5bbf00: b.eq            #0x5bbf08
    //     0x5bbf04: bl              #0xd6826c
    // 0x5bbf08: r2 = 0
    //     0x5bbf08: mov             x2, #0
    // 0x5bbf0c: StoreField: r1->field_7 = r2
    //     0x5bbf0c: stur            x2, [x1, #7]
    // 0x5bbf10: r0 = Null
    //     0x5bbf10: mov             x0, NULL
    // 0x5bbf14: LeaveFrame
    //     0x5bbf14: mov             SP, fp
    //     0x5bbf18: ldp             fp, lr, [SP], #0x10
    // 0x5bbf1c: ret
    //     0x5bbf1c: ret             
    // 0x5bbf20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5bbf20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5bbf24: b               #0x5bbe98
  }
  _ find(/* No info */) {
    // ** addr: 0x5ddd04, size: 0x10c
    // 0x5ddd04: EnterFrame
    //     0x5ddd04: stp             fp, lr, [SP, #-0x10]!
    //     0x5ddd08: mov             fp, SP
    // 0x5ddd0c: AllocStack(0x10)
    //     0x5ddd0c: sub             SP, SP, #0x10
    // 0x5ddd10: SetupParameters()
    //     0x5ddd10: mov             x0, x4
    //     0x5ddd14: ldur            w1, [x0, #0xf]
    //     0x5ddd18: add             x1, x1, HEAP, lsl #32
    //     0x5ddd1c: cbnz            w1, #0x5ddd28
    //     0x5ddd20: mov             x0, NULL
    //     0x5ddd24: b               #0x5ddd38
    //     0x5ddd28: ldur            w2, [x0, #0x17]
    //     0x5ddd2c: add             x2, x2, HEAP, lsl #32
    //     0x5ddd30: add             x0, fp, w2, sxtw #2
    //     0x5ddd34: ldr             x0, [x0, #0x10]
    // 0x5ddd38: CheckStackOverflow
    //     0x5ddd38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5ddd3c: cmp             SP, x16
    //     0x5ddd40: b.ls            #0x5dde08
    // 0x5ddd44: cbnz            w1, #0x5ddd50
    // 0x5ddd48: r4 = <Object>
    //     0x5ddd48: ldr             x4, [PP, #0x1d8]  ; [pp+0x1d8] TypeArguments: <Object>
    // 0x5ddd4c: b               #0x5ddd54
    // 0x5ddd50: mov             x4, x0
    // 0x5ddd54: ldr             x0, [fp, #0x18]
    // 0x5ddd58: mov             x2, x4
    // 0x5ddd5c: stur            x4, [fp, #-8]
    // 0x5ddd60: r1 = Null
    //     0x5ddd60: mov             x1, NULL
    // 0x5ddd64: r3 = <AnnotationEntry<X0>>
    //     0x5ddd64: ldr             x3, [PP, #0x49d8]  ; [pp+0x49d8] TypeArguments: <AnnotationEntry<X0>>
    // 0x5ddd68: r24 = InstantiateTypeArgumentsStub
    //     0x5ddd68: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0x5ddd6c: LoadField: r30 = r24->field_7
    //     0x5ddd6c: ldur            lr, [x24, #7]
    // 0x5ddd70: blr             lr
    // 0x5ddd74: stp             xzr, x0, [SP, #-0x10]!
    // 0x5ddd78: r0 = _GrowableList()
    //     0x5ddd78: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x5ddd7c: add             SP, SP, #0x10
    // 0x5ddd80: ldur            x1, [fp, #-8]
    // 0x5ddd84: stur            x0, [fp, #-0x10]
    // 0x5ddd88: r0 = AnnotationResult()
    //     0x5ddd88: bl              #0x5dde10  ; AllocateAnnotationResultStub -> AnnotationResult<X0> (size=0x10)
    // 0x5ddd8c: ldur            x1, [fp, #-0x10]
    // 0x5ddd90: StoreField: r0->field_b = r1
    //     0x5ddd90: stur            w1, [x0, #0xb]
    // 0x5ddd94: ldr             x2, [fp, #0x18]
    // 0x5ddd98: r3 = LoadClassIdInstr(r2)
    //     0x5ddd98: ldur            x3, [x2, #-1]
    //     0x5ddd9c: ubfx            x3, x3, #0xc, #0x14
    // 0x5ddda0: ldur            x16, [fp, #-8]
    // 0x5ddda4: stp             x2, x16, [SP, #-0x10]!
    // 0x5ddda8: ldr             x16, [fp, #0x10]
    // 0x5dddac: stp             x16, x0, [SP, #-0x10]!
    // 0x5dddb0: mov             x0, x3
    // 0x5dddb4: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x5dddb4: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x5dddb8: r0 = GDT[cid_x0 + 0x631f]()
    //     0x5dddb8: mov             x17, #0x631f
    //     0x5dddbc: add             lr, x0, x17
    //     0x5dddc0: ldr             lr, [x21, lr, lsl #3]
    //     0x5dddc4: blr             lr
    // 0x5dddc8: add             SP, SP, #0x20
    // 0x5dddcc: ldur            x0, [fp, #-0x10]
    // 0x5dddd0: LoadField: r1 = r0->field_b
    //     0x5dddd0: ldur            w1, [x0, #0xb]
    // 0x5dddd4: DecompressPointer r1
    //     0x5dddd4: add             x1, x1, HEAP, lsl #32
    // 0x5dddd8: cbnz            w1, #0x5ddde4
    // 0x5ddddc: r0 = Null
    //     0x5ddddc: mov             x0, NULL
    // 0x5ddde0: b               #0x5dddfc
    // 0x5ddde4: SaveReg r0
    //     0x5ddde4: str             x0, [SP, #-8]!
    // 0x5ddde8: r0 = first()
    //     0x5ddde8: bl              #0x7192e8  ; [dart:core] _GrowableList::first
    // 0x5dddec: add             SP, SP, #8
    // 0x5dddf0: LoadField: r1 = r0->field_b
    //     0x5dddf0: ldur            w1, [x0, #0xb]
    // 0x5dddf4: DecompressPointer r1
    //     0x5dddf4: add             x1, x1, HEAP, lsl #32
    // 0x5dddf8: mov             x0, x1
    // 0x5dddfc: LeaveFrame
    //     0x5dddfc: mov             SP, fp
    //     0x5dde00: ldp             fp, lr, [SP], #0x10
    // 0x5dde04: ret
    //     0x5dde04: ret             
    // 0x5dde08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5dde08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5dde0c: b               #0x5ddd44
  }
  _ markNeedsAddToScene(/* No info */) {
    // ** addr: 0x5dec74, size: 0x28
    // 0x5dec74: ldr             x1, [SP]
    // 0x5dec78: LoadField: r2 = r1->field_2f
    //     0x5dec78: ldur            w2, [x1, #0x2f]
    // 0x5dec7c: DecompressPointer r2
    //     0x5dec7c: add             x2, x2, HEAP, lsl #32
    // 0x5dec80: tbnz            w2, #4, #0x5dec8c
    // 0x5dec84: r0 = Null
    //     0x5dec84: mov             x0, NULL
    // 0x5dec88: ret
    //     0x5dec88: ret             
    // 0x5dec8c: r2 = true
    //     0x5dec8c: add             x2, NULL, #0x20  ; true
    // 0x5dec90: StoreField: r1->field_2f = r2
    //     0x5dec90: stur            w2, [x1, #0x2f]
    // 0x5dec94: r0 = Null
    //     0x5dec94: mov             x0, NULL
    // 0x5dec98: ret
    //     0x5dec98: ret             
  }
  _ dropChild(/* No info */) {
    // ** addr: 0x5df51c, size: 0x98
    // 0x5df51c: EnterFrame
    //     0x5df51c: stp             fp, lr, [SP, #-0x10]!
    //     0x5df520: mov             fp, SP
    // 0x5df524: CheckStackOverflow
    //     0x5df524: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5df528: cmp             SP, x16
    //     0x5df52c: b.ls            #0x5df5ac
    // 0x5df530: ldr             x1, [fp, #0x18]
    // 0x5df534: r0 = LoadClassIdInstr(r1)
    //     0x5df534: ldur            x0, [x1, #-1]
    //     0x5df538: ubfx            x0, x0, #0xc, #0x14
    // 0x5df53c: SaveReg r1
    //     0x5df53c: str             x1, [SP, #-8]!
    // 0x5df540: r0 = GDT[cid_x0 + 0x19b9]()
    //     0x5df540: mov             x17, #0x19b9
    //     0x5df544: add             lr, x0, x17
    //     0x5df548: ldr             lr, [x21, lr, lsl #3]
    //     0x5df54c: blr             lr
    // 0x5df550: add             SP, SP, #8
    // 0x5df554: tbz             w0, #4, #0x5df568
    // 0x5df558: ldr             x16, [fp, #0x18]
    // 0x5df55c: SaveReg r16
    //     0x5df55c: str             x16, [SP, #-8]!
    // 0x5df560: r0 = markNeedsAddToScene()
    //     0x5df560: bl              #0x5dec74  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0x5df564: add             SP, SP, #8
    // 0x5df568: ldr             x0, [fp, #0x10]
    // 0x5df56c: LoadField: r1 = r0->field_1b
    //     0x5df56c: ldur            x1, [x0, #0x1b]
    // 0x5df570: cbz             x1, #0x5df588
    // 0x5df574: neg             x2, x1
    // 0x5df578: ldr             x16, [fp, #0x18]
    // 0x5df57c: stp             x2, x16, [SP, #-0x10]!
    // 0x5df580: r0 = _updateSubtreeCompositionObserverCount()
    //     0x5df580: bl              #0x5df620  ; [package:flutter/src/rendering/layer.dart] Layer::_updateSubtreeCompositionObserverCount
    // 0x5df584: add             SP, SP, #0x10
    // 0x5df588: ldr             x16, [fp, #0x18]
    // 0x5df58c: ldr             lr, [fp, #0x10]
    // 0x5df590: stp             lr, x16, [SP, #-0x10]!
    // 0x5df594: r0 = dropChild()
    //     0x5df594: bl              #0x5df5b4  ; [package:flutter/src/foundation/node.dart] AbstractNode::dropChild
    // 0x5df598: add             SP, SP, #0x10
    // 0x5df59c: r0 = Null
    //     0x5df59c: mov             x0, NULL
    // 0x5df5a0: LeaveFrame
    //     0x5df5a0: mov             SP, fp
    //     0x5df5a4: ldp             fp, lr, [SP], #0x10
    // 0x5df5a8: ret
    //     0x5df5a8: ret             
    // 0x5df5ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5df5ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5df5b0: b               #0x5df530
  }
  _ _updateSubtreeCompositionObserverCount(/* No info */) {
    // ** addr: 0x5df620, size: 0xbc
    // 0x5df620: EnterFrame
    //     0x5df620: stp             fp, lr, [SP, #-0x10]!
    //     0x5df624: mov             fp, SP
    // 0x5df628: AllocStack(0x8)
    //     0x5df628: sub             SP, SP, #8
    // 0x5df62c: CheckStackOverflow
    //     0x5df62c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5df630: cmp             SP, x16
    //     0x5df634: b.ls            #0x5df6d0
    // 0x5df638: ldr             x3, [fp, #0x18]
    // 0x5df63c: LoadField: r0 = r3->field_1b
    //     0x5df63c: ldur            x0, [x3, #0x1b]
    // 0x5df640: ldr             x4, [fp, #0x10]
    // 0x5df644: add             x1, x0, x4
    // 0x5df648: StoreField: r3->field_1b = r1
    //     0x5df648: stur            x1, [x3, #0x1b]
    // 0x5df64c: LoadField: r5 = r3->field_13
    //     0x5df64c: ldur            w5, [x3, #0x13]
    // 0x5df650: DecompressPointer r5
    //     0x5df650: add             x5, x5, HEAP, lsl #32
    // 0x5df654: mov             x0, x5
    // 0x5df658: stur            x5, [fp, #-8]
    // 0x5df65c: r2 = Null
    //     0x5df65c: mov             x2, NULL
    // 0x5df660: r1 = Null
    //     0x5df660: mov             x1, NULL
    // 0x5df664: r4 = LoadClassIdInstr(r0)
    //     0x5df664: ldur            x4, [x0, #-1]
    //     0x5df668: ubfx            x4, x4, #0xc, #0x14
    // 0x5df66c: sub             x4, x4, #0x94e
    // 0x5df670: cmp             x4, #0xb
    // 0x5df674: b.ls            #0x5df684
    // 0x5df678: r8 = ContainerLayer?
    //     0x5df678: ldr             x8, [PP, #0x4ac0]  ; [pp+0x4ac0] Type: ContainerLayer?
    // 0x5df67c: r3 = Null
    //     0x5df67c: ldr             x3, [PP, #0x4ac8]  ; [pp+0x4ac8] Null
    // 0x5df680: r0 = DefaultNullableTypeTest()
    //     0x5df680: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x5df684: ldur            x0, [fp, #-8]
    // 0x5df688: cmp             w0, NULL
    // 0x5df68c: b.eq            #0x5df6c0
    // 0x5df690: ldr             x0, [fp, #0x10]
    // 0x5df694: ldr             x16, [fp, #0x18]
    // 0x5df698: SaveReg r16
    //     0x5df698: str             x16, [SP, #-8]!
    // 0x5df69c: r0 = parent()
    //     0x5df69c: bl              #0xa6b30c  ; [package:flutter/src/rendering/layer.dart] Layer::parent
    // 0x5df6a0: add             SP, SP, #8
    // 0x5df6a4: cmp             w0, NULL
    // 0x5df6a8: b.eq            #0x5df6d8
    // 0x5df6ac: SaveReg r0
    //     0x5df6ac: str             x0, [SP, #-8]!
    // 0x5df6b0: ldr             x0, [fp, #0x10]
    // 0x5df6b4: SaveReg r0
    //     0x5df6b4: str             x0, [SP, #-8]!
    // 0x5df6b8: r0 = _updateSubtreeCompositionObserverCount()
    //     0x5df6b8: bl              #0x5df620  ; [package:flutter/src/rendering/layer.dart] Layer::_updateSubtreeCompositionObserverCount
    // 0x5df6bc: add             SP, SP, #0x10
    // 0x5df6c0: r0 = Null
    //     0x5df6c0: mov             x0, NULL
    // 0x5df6c4: LeaveFrame
    //     0x5df6c4: mov             SP, fp
    //     0x5df6c8: ldp             fp, lr, [SP], #0x10
    // 0x5df6cc: ret
    //     0x5df6cc: ret             
    // 0x5df6d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5df6d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5df6d4: b               #0x5df638
    // 0x5df6d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5df6d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ adoptChild(/* No info */) {
    // ** addr: 0x65432c, size: 0x94
    // 0x65432c: EnterFrame
    //     0x65432c: stp             fp, lr, [SP, #-0x10]!
    //     0x654330: mov             fp, SP
    // 0x654334: CheckStackOverflow
    //     0x654334: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x654338: cmp             SP, x16
    //     0x65433c: b.ls            #0x6543b8
    // 0x654340: ldr             x1, [fp, #0x18]
    // 0x654344: r0 = LoadClassIdInstr(r1)
    //     0x654344: ldur            x0, [x1, #-1]
    //     0x654348: ubfx            x0, x0, #0xc, #0x14
    // 0x65434c: SaveReg r1
    //     0x65434c: str             x1, [SP, #-8]!
    // 0x654350: r0 = GDT[cid_x0 + 0x19b9]()
    //     0x654350: mov             x17, #0x19b9
    //     0x654354: add             lr, x0, x17
    //     0x654358: ldr             lr, [x21, lr, lsl #3]
    //     0x65435c: blr             lr
    // 0x654360: add             SP, SP, #8
    // 0x654364: tbz             w0, #4, #0x654378
    // 0x654368: ldr             x16, [fp, #0x18]
    // 0x65436c: SaveReg r16
    //     0x65436c: str             x16, [SP, #-8]!
    // 0x654370: r0 = markNeedsAddToScene()
    //     0x654370: bl              #0x5dec74  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0x654374: add             SP, SP, #8
    // 0x654378: ldr             x0, [fp, #0x10]
    // 0x65437c: LoadField: r1 = r0->field_1b
    //     0x65437c: ldur            x1, [x0, #0x1b]
    // 0x654380: cbz             x1, #0x654394
    // 0x654384: ldr             x16, [fp, #0x18]
    // 0x654388: stp             x1, x16, [SP, #-0x10]!
    // 0x65438c: r0 = _updateSubtreeCompositionObserverCount()
    //     0x65438c: bl              #0x5df620  ; [package:flutter/src/rendering/layer.dart] Layer::_updateSubtreeCompositionObserverCount
    // 0x654390: add             SP, SP, #0x10
    // 0x654394: ldr             x16, [fp, #0x18]
    // 0x654398: ldr             lr, [fp, #0x10]
    // 0x65439c: stp             lr, x16, [SP, #-0x10]!
    // 0x6543a0: r0 = adoptChild()
    //     0x6543a0: bl              #0x5e6280  ; [package:flutter/src/foundation/node.dart] AbstractNode::adoptChild
    // 0x6543a4: add             SP, SP, #0x10
    // 0x6543a8: r0 = Null
    //     0x6543a8: mov             x0, NULL
    // 0x6543ac: LeaveFrame
    //     0x6543ac: mov             SP, fp
    //     0x6543b0: ldp             fp, lr, [SP], #0x10
    // 0x6543b4: ret
    //     0x6543b4: ret             
    // 0x6543b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6543b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6543bc: b               #0x654340
  }
  _ remove(/* No info */) {
    // ** addr: 0x6543c0, size: 0x88
    // 0x6543c0: EnterFrame
    //     0x6543c0: stp             fp, lr, [SP, #-0x10]!
    //     0x6543c4: mov             fp, SP
    // 0x6543c8: AllocStack(0x8)
    //     0x6543c8: sub             SP, SP, #8
    // 0x6543cc: CheckStackOverflow
    //     0x6543cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6543d0: cmp             SP, x16
    //     0x6543d4: b.ls            #0x654440
    // 0x6543d8: ldr             x3, [fp, #0x10]
    // 0x6543dc: LoadField: r4 = r3->field_13
    //     0x6543dc: ldur            w4, [x3, #0x13]
    // 0x6543e0: DecompressPointer r4
    //     0x6543e0: add             x4, x4, HEAP, lsl #32
    // 0x6543e4: mov             x0, x4
    // 0x6543e8: stur            x4, [fp, #-8]
    // 0x6543ec: r2 = Null
    //     0x6543ec: mov             x2, NULL
    // 0x6543f0: r1 = Null
    //     0x6543f0: mov             x1, NULL
    // 0x6543f4: r4 = LoadClassIdInstr(r0)
    //     0x6543f4: ldur            x4, [x0, #-1]
    //     0x6543f8: ubfx            x4, x4, #0xc, #0x14
    // 0x6543fc: sub             x4, x4, #0x94e
    // 0x654400: cmp             x4, #0xb
    // 0x654404: b.ls            #0x654414
    // 0x654408: r8 = ContainerLayer?
    //     0x654408: ldr             x8, [PP, #0x4ac0]  ; [pp+0x4ac0] Type: ContainerLayer?
    // 0x65440c: r3 = Null
    //     0x65440c: ldr             x3, [PP, #0x71a0]  ; [pp+0x71a0] Null
    // 0x654410: r0 = DefaultNullableTypeTest()
    //     0x654410: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x654414: ldur            x0, [fp, #-8]
    // 0x654418: cmp             w0, NULL
    // 0x65441c: b.eq            #0x654430
    // 0x654420: ldr             x16, [fp, #0x10]
    // 0x654424: stp             x16, x0, [SP, #-0x10]!
    // 0x654428: r0 = _removeChild()
    //     0x654428: bl              #0x654448  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::_removeChild
    // 0x65442c: add             SP, SP, #0x10
    // 0x654430: r0 = Null
    //     0x654430: mov             x0, NULL
    // 0x654434: LeaveFrame
    //     0x654434: mov             SP, fp
    //     0x654438: ldp             fp, lr, [SP], #0x10
    // 0x65443c: ret
    //     0x65443c: ret             
    // 0x654440: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x654440: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x654444: b               #0x6543d8
  }
  set _ engineLayer=(/* No info */) {
    // ** addr: 0x661300, size: 0x168
    // 0x661300: EnterFrame
    //     0x661300: stp             fp, lr, [SP, #-0x10]!
    //     0x661304: mov             fp, SP
    // 0x661308: AllocStack(0x8)
    //     0x661308: sub             SP, SP, #8
    // 0x66130c: CheckStackOverflow
    //     0x66130c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x661310: cmp             SP, x16
    //     0x661314: b.ls            #0x66145c
    // 0x661318: ldr             x0, [fp, #0x18]
    // 0x66131c: LoadField: r1 = r0->field_33
    //     0x66131c: ldur            w1, [x0, #0x33]
    // 0x661320: DecompressPointer r1
    //     0x661320: add             x1, x1, HEAP, lsl #32
    // 0x661324: cmp             w1, NULL
    // 0x661328: b.ne            #0x661334
    // 0x66132c: mov             x1, x0
    // 0x661330: b               #0x661344
    // 0x661334: SaveReg r1
    //     0x661334: str             x1, [SP, #-8]!
    // 0x661338: r0 = dispose()
    //     0x661338: bl              #0x661468  ; [dart:ui] _EngineLayerWrapper::dispose
    // 0x66133c: add             SP, SP, #8
    // 0x661340: ldr             x1, [fp, #0x18]
    // 0x661344: ldr             x0, [fp, #0x10]
    // 0x661348: StoreField: r1->field_33 = r0
    //     0x661348: stur            w0, [x1, #0x33]
    //     0x66134c: ldurb           w16, [x1, #-1]
    //     0x661350: ldurb           w17, [x0, #-1]
    //     0x661354: and             x16, x17, x16, lsr #2
    //     0x661358: tst             x16, HEAP, lsr #32
    //     0x66135c: b.eq            #0x661364
    //     0x661360: bl              #0xd6826c
    // 0x661364: r0 = LoadClassIdInstr(r1)
    //     0x661364: ldur            x0, [x1, #-1]
    //     0x661368: ubfx            x0, x0, #0xc, #0x14
    // 0x66136c: SaveReg r1
    //     0x66136c: str             x1, [SP, #-8]!
    // 0x661370: r0 = GDT[cid_x0 + 0x19b9]()
    //     0x661370: mov             x17, #0x19b9
    //     0x661374: add             lr, x0, x17
    //     0x661378: ldr             lr, [x21, lr, lsl #3]
    //     0x66137c: blr             lr
    // 0x661380: add             SP, SP, #8
    // 0x661384: tbz             w0, #4, #0x66144c
    // 0x661388: ldr             x3, [fp, #0x18]
    // 0x66138c: LoadField: r4 = r3->field_13
    //     0x66138c: ldur            w4, [x3, #0x13]
    // 0x661390: DecompressPointer r4
    //     0x661390: add             x4, x4, HEAP, lsl #32
    // 0x661394: mov             x0, x4
    // 0x661398: stur            x4, [fp, #-8]
    // 0x66139c: r2 = Null
    //     0x66139c: mov             x2, NULL
    // 0x6613a0: r1 = Null
    //     0x6613a0: mov             x1, NULL
    // 0x6613a4: r4 = LoadClassIdInstr(r0)
    //     0x6613a4: ldur            x4, [x0, #-1]
    //     0x6613a8: ubfx            x4, x4, #0xc, #0x14
    // 0x6613ac: sub             x4, x4, #0x94e
    // 0x6613b0: cmp             x4, #0xb
    // 0x6613b4: b.ls            #0x6613c4
    // 0x6613b8: r8 = ContainerLayer?
    //     0x6613b8: ldr             x8, [PP, #0x4ac0]  ; [pp+0x4ac0] Type: ContainerLayer?
    // 0x6613bc: r3 = Null
    //     0x6613bc: ldr             x3, [PP, #0x73f0]  ; [pp+0x73f0] Null
    // 0x6613c0: r0 = DefaultNullableTypeTest()
    //     0x6613c0: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x6613c4: ldur            x0, [fp, #-8]
    // 0x6613c8: cmp             w0, NULL
    // 0x6613cc: b.eq            #0x66144c
    // 0x6613d0: r1 = LoadClassIdInstr(r0)
    //     0x6613d0: ldur            x1, [x0, #-1]
    //     0x6613d4: ubfx            x1, x1, #0xc, #0x14
    // 0x6613d8: SaveReg r0
    //     0x6613d8: str             x0, [SP, #-8]!
    // 0x6613dc: mov             x0, x1
    // 0x6613e0: r0 = GDT[cid_x0 + 0x19b9]()
    //     0x6613e0: mov             x17, #0x19b9
    //     0x6613e4: add             lr, x0, x17
    //     0x6613e8: ldr             lr, [x21, lr, lsl #3]
    //     0x6613ec: blr             lr
    // 0x6613f0: add             SP, SP, #8
    // 0x6613f4: tbz             w0, #4, #0x66144c
    // 0x6613f8: ldr             x0, [fp, #0x18]
    // 0x6613fc: LoadField: r3 = r0->field_13
    //     0x6613fc: ldur            w3, [x0, #0x13]
    // 0x661400: DecompressPointer r3
    //     0x661400: add             x3, x3, HEAP, lsl #32
    // 0x661404: mov             x0, x3
    // 0x661408: stur            x3, [fp, #-8]
    // 0x66140c: r2 = Null
    //     0x66140c: mov             x2, NULL
    // 0x661410: r1 = Null
    //     0x661410: mov             x1, NULL
    // 0x661414: r4 = LoadClassIdInstr(r0)
    //     0x661414: ldur            x4, [x0, #-1]
    //     0x661418: ubfx            x4, x4, #0xc, #0x14
    // 0x66141c: sub             x4, x4, #0x94e
    // 0x661420: cmp             x4, #0xb
    // 0x661424: b.ls            #0x661434
    // 0x661428: r8 = ContainerLayer?
    //     0x661428: ldr             x8, [PP, #0x4ac0]  ; [pp+0x4ac0] Type: ContainerLayer?
    // 0x66142c: r3 = Null
    //     0x66142c: ldr             x3, [PP, #0x7400]  ; [pp+0x7400] Null
    // 0x661430: r0 = DefaultNullableTypeTest()
    //     0x661430: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x661434: ldur            x0, [fp, #-8]
    // 0x661438: cmp             w0, NULL
    // 0x66143c: b.eq            #0x661464
    // 0x661440: SaveReg r0
    //     0x661440: str             x0, [SP, #-8]!
    // 0x661444: r0 = markNeedsAddToScene()
    //     0x661444: bl              #0x5dec74  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0x661448: add             SP, SP, #8
    // 0x66144c: r0 = Null
    //     0x66144c: mov             x0, NULL
    // 0x661450: LeaveFrame
    //     0x661450: mov             SP, fp
    //     0x661454: ldp             fp, lr, [SP], #0x10
    // 0x661458: ret
    //     0x661458: ret             
    // 0x66145c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66145c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x661460: b               #0x661318
    // 0x661464: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x661464: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ updateSubtreeNeedsAddToScene(/* No info */) {
    // ** addr: 0x792390, size: 0x70
    // 0x792390: EnterFrame
    //     0x792390: stp             fp, lr, [SP, #-0x10]!
    //     0x792394: mov             fp, SP
    // 0x792398: CheckStackOverflow
    //     0x792398: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79239c: cmp             SP, x16
    //     0x7923a0: b.ls            #0x7923f8
    // 0x7923a4: ldr             x1, [fp, #0x10]
    // 0x7923a8: LoadField: r0 = r1->field_2f
    //     0x7923a8: ldur            w0, [x1, #0x2f]
    // 0x7923ac: DecompressPointer r0
    //     0x7923ac: add             x0, x0, HEAP, lsl #32
    // 0x7923b0: tbnz            w0, #4, #0x7923bc
    // 0x7923b4: r2 = true
    //     0x7923b4: add             x2, NULL, #0x20  ; true
    // 0x7923b8: b               #0x7923e4
    // 0x7923bc: r0 = LoadClassIdInstr(r1)
    //     0x7923bc: ldur            x0, [x1, #-1]
    //     0x7923c0: ubfx            x0, x0, #0xc, #0x14
    // 0x7923c4: SaveReg r1
    //     0x7923c4: str             x1, [SP, #-8]!
    // 0x7923c8: r0 = GDT[cid_x0 + 0x19b9]()
    //     0x7923c8: mov             x17, #0x19b9
    //     0x7923cc: add             lr, x0, x17
    //     0x7923d0: ldr             lr, [x21, lr, lsl #3]
    //     0x7923d4: blr             lr
    // 0x7923d8: add             SP, SP, #8
    // 0x7923dc: mov             x2, x0
    // 0x7923e0: ldr             x1, [fp, #0x10]
    // 0x7923e4: StoreField: r1->field_2f = r2
    //     0x7923e4: stur            w2, [x1, #0x2f]
    // 0x7923e8: r0 = Null
    //     0x7923e8: mov             x0, NULL
    // 0x7923ec: LeaveFrame
    //     0x7923ec: mov             SP, fp
    //     0x7923f0: ldp             fp, lr, [SP], #0x10
    // 0x7923f4: ret
    //     0x7923f4: ret             
    // 0x7923f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7923f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7923fc: b               #0x7923a4
  }
  get _ parent(/* No info */) {
    // ** addr: 0xa6b30c, size: 0x58
    // 0xa6b30c: EnterFrame
    //     0xa6b30c: stp             fp, lr, [SP, #-0x10]!
    //     0xa6b310: mov             fp, SP
    // 0xa6b314: AllocStack(0x8)
    //     0xa6b314: sub             SP, SP, #8
    // 0xa6b318: ldr             x0, [fp, #0x10]
    // 0xa6b31c: LoadField: r3 = r0->field_13
    //     0xa6b31c: ldur            w3, [x0, #0x13]
    // 0xa6b320: DecompressPointer r3
    //     0xa6b320: add             x3, x3, HEAP, lsl #32
    // 0xa6b324: mov             x0, x3
    // 0xa6b328: stur            x3, [fp, #-8]
    // 0xa6b32c: r2 = Null
    //     0xa6b32c: mov             x2, NULL
    // 0xa6b330: r1 = Null
    //     0xa6b330: mov             x1, NULL
    // 0xa6b334: r4 = LoadClassIdInstr(r0)
    //     0xa6b334: ldur            x4, [x0, #-1]
    //     0xa6b338: ubfx            x4, x4, #0xc, #0x14
    // 0xa6b33c: sub             x4, x4, #0x94e
    // 0xa6b340: cmp             x4, #0xb
    // 0xa6b344: b.ls            #0xa6b354
    // 0xa6b348: r8 = ContainerLayer?
    //     0xa6b348: ldr             x8, [PP, #0x4ac0]  ; [pp+0x4ac0] Type: ContainerLayer?
    // 0xa6b34c: r3 = Null
    //     0xa6b34c: ldr             x3, [PP, #0x4ad8]  ; [pp+0x4ad8] Null
    // 0xa6b350: r0 = DefaultNullableTypeTest()
    //     0xa6b350: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xa6b354: ldur            x0, [fp, #-8]
    // 0xa6b358: LeaveFrame
    //     0xa6b358: mov             SP, fp
    //     0xa6b35c: ldp             fp, lr, [SP], #0x10
    // 0xa6b360: ret
    //     0xa6b360: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa78078, size: 0x5c
    // 0xa78078: EnterFrame
    //     0xa78078: stp             fp, lr, [SP, #-0x10]!
    //     0xa7807c: mov             fp, SP
    // 0xa78080: CheckStackOverflow
    //     0xa78080: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa78084: cmp             SP, x16
    //     0xa78088: b.ls            #0xa780cc
    // 0xa7808c: ldr             x0, [fp, #0x10]
    // 0xa78090: LoadField: r1 = r0->field_33
    //     0xa78090: ldur            w1, [x0, #0x33]
    // 0xa78094: DecompressPointer r1
    //     0xa78094: add             x1, x1, HEAP, lsl #32
    // 0xa78098: cmp             w1, NULL
    // 0xa7809c: b.ne            #0xa780a8
    // 0xa780a0: mov             x1, x0
    // 0xa780a4: b               #0xa780b8
    // 0xa780a8: SaveReg r1
    //     0xa780a8: str             x1, [SP, #-8]!
    // 0xa780ac: r0 = dispose()
    //     0xa780ac: bl              #0x661468  ; [dart:ui] _EngineLayerWrapper::dispose
    // 0xa780b0: add             SP, SP, #8
    // 0xa780b4: ldr             x1, [fp, #0x10]
    // 0xa780b8: StoreField: r1->field_33 = rNULL
    //     0xa780b8: stur            NULL, [x1, #0x33]
    // 0xa780bc: r0 = Null
    //     0xa780bc: mov             x0, NULL
    // 0xa780c0: LeaveFrame
    //     0xa780c0: mov             SP, fp
    //     0xa780c4: ldp             fp, lr, [SP], #0x10
    // 0xa780c8: ret
    //     0xa780c8: ret             
    // 0xa780cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa780cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa780d0: b               #0xa7808c
  }
  _ toStringShort(/* No info */) {
    // ** addr: 0xa789d8, size: 0x8c
    // 0xa789d8: EnterFrame
    //     0xa789d8: stp             fp, lr, [SP, #-0x10]!
    //     0xa789dc: mov             fp, SP
    // 0xa789e0: AllocStack(0x8)
    //     0xa789e0: sub             SP, SP, #8
    // 0xa789e4: CheckStackOverflow
    //     0xa789e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa789e8: cmp             SP, x16
    //     0xa789ec: b.ls            #0xa78a5c
    // 0xa789f0: ldr             x16, [fp, #0x10]
    // 0xa789f4: SaveReg r16
    //     0xa789f4: str             x16, [SP, #-8]!
    // 0xa789f8: r0 = describeIdentity()
    //     0xa789f8: bl              #0xa77c6c  ; [package:flutter/src/foundation/diagnostics.dart] ::describeIdentity
    // 0xa789fc: add             SP, SP, #8
    // 0xa78a00: r1 = Null
    //     0xa78a00: mov             x1, NULL
    // 0xa78a04: r2 = 4
    //     0xa78a04: mov             x2, #4
    // 0xa78a08: stur            x0, [fp, #-8]
    // 0xa78a0c: r0 = AllocateArray()
    //     0xa78a0c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa78a10: mov             x1, x0
    // 0xa78a14: ldur            x0, [fp, #-8]
    // 0xa78a18: StoreField: r1->field_f = r0
    //     0xa78a18: stur            w0, [x1, #0xf]
    // 0xa78a1c: ldr             x0, [fp, #0x10]
    // 0xa78a20: LoadField: r2 = r0->field_f
    //     0xa78a20: ldur            w2, [x0, #0xf]
    // 0xa78a24: DecompressPointer r2
    //     0xa78a24: add             x2, x2, HEAP, lsl #32
    // 0xa78a28: cmp             w2, NULL
    // 0xa78a2c: b.ne            #0xa78a3c
    // 0xa78a30: r0 = " DETACHED"
    //     0xa78a30: add             x0, PP, #0xb, lsl #12  ; [pp+0xb040] " DETACHED"
    //     0xa78a34: ldr             x0, [x0, #0x40]
    // 0xa78a38: b               #0xa78a40
    // 0xa78a3c: r0 = ""
    //     0xa78a3c: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xa78a40: StoreField: r1->field_13 = r0
    //     0xa78a40: stur            w0, [x1, #0x13]
    // 0xa78a44: SaveReg r1
    //     0xa78a44: str             x1, [SP, #-8]!
    // 0xa78a48: r0 = _interpolate()
    //     0xa78a48: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa78a4c: add             SP, SP, #8
    // 0xa78a50: LeaveFrame
    //     0xa78a50: mov             SP, fp
    //     0xa78a54: ldp             fp, lr, [SP], #0x10
    // 0xa78a58: ret
    //     0xa78a58: ret             
    // 0xa78a5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa78a5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa78a60: b               #0xa789f0
  }
  _ _fireCompositionCallbacks(/* No info */) {
    // ** addr: 0xa78bd8, size: 0xe8
    // 0xa78bd8: EnterFrame
    //     0xa78bd8: stp             fp, lr, [SP, #-0x10]!
    //     0xa78bdc: mov             fp, SP
    // 0xa78be0: AllocStack(0x8)
    //     0xa78be0: sub             SP, SP, #8
    // 0xa78be4: CheckStackOverflow
    //     0xa78be4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa78be8: cmp             SP, x16
    //     0xa78bec: b.ls            #0xa78cac
    // 0xa78bf0: ldr             x0, [fp, #0x18]
    // 0xa78bf4: LoadField: r1 = r0->field_17
    //     0xa78bf4: ldur            w1, [x0, #0x17]
    // 0xa78bf8: DecompressPointer r1
    //     0xa78bf8: add             x1, x1, HEAP, lsl #32
    // 0xa78bfc: SaveReg r1
    //     0xa78bfc: str             x1, [SP, #-8]!
    // 0xa78c00: r0 = values()
    //     0xa78c00: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0xa78c04: add             SP, SP, #8
    // 0xa78c08: r16 = <(dynamic this) => void?>
    //     0xa78c08: ldr             x16, [PP, #0x49f8]  ; [pp+0x49f8] TypeArguments: <(dynamic this) => void?>
    // 0xa78c0c: stp             x0, x16, [SP, #-0x10]!
    // 0xa78c10: r0 = _GrowableList.of()
    //     0xa78c10: bl              #0x4bfaf0  ; [dart:core] _GrowableList::_GrowableList.of
    // 0xa78c14: add             SP, SP, #0x10
    // 0xa78c18: SaveReg r0
    //     0xa78c18: str             x0, [SP, #-8]!
    // 0xa78c1c: r0 = iterator()
    //     0xa78c1c: bl              #0x9bb07c  ; [dart:core] _GrowableList::iterator
    // 0xa78c20: add             SP, SP, #8
    // 0xa78c24: mov             x1, x0
    // 0xa78c28: stur            x1, [fp, #-8]
    // 0xa78c2c: CheckStackOverflow
    //     0xa78c2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa78c30: cmp             SP, x16
    //     0xa78c34: b.ls            #0xa78cb4
    // 0xa78c38: r0 = LoadClassIdInstr(r1)
    //     0xa78c38: ldur            x0, [x1, #-1]
    //     0xa78c3c: ubfx            x0, x0, #0xc, #0x14
    // 0xa78c40: SaveReg r1
    //     0xa78c40: str             x1, [SP, #-8]!
    // 0xa78c44: r0 = GDT[cid_x0 + 0x541]()
    //     0xa78c44: add             lr, x0, #0x541
    //     0xa78c48: ldr             lr, [x21, lr, lsl #3]
    //     0xa78c4c: blr             lr
    // 0xa78c50: add             SP, SP, #8
    // 0xa78c54: tbnz            w0, #4, #0xa78c9c
    // 0xa78c58: ldur            x1, [fp, #-8]
    // 0xa78c5c: r0 = LoadClassIdInstr(r1)
    //     0xa78c5c: ldur            x0, [x1, #-1]
    //     0xa78c60: ubfx            x0, x0, #0xc, #0x14
    // 0xa78c64: SaveReg r1
    //     0xa78c64: str             x1, [SP, #-8]!
    // 0xa78c68: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xa78c68: add             lr, x0, #0x5ca
    //     0xa78c6c: ldr             lr, [x21, lr, lsl #3]
    //     0xa78c70: blr             lr
    // 0xa78c74: add             SP, SP, #8
    // 0xa78c78: cmp             w0, NULL
    // 0xa78c7c: b.eq            #0xa78cbc
    // 0xa78c80: SaveReg r0
    //     0xa78c80: str             x0, [SP, #-8]!
    // 0xa78c84: ClosureCall
    //     0xa78c84: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xa78c88: ldur            x2, [x0, #0x1f]
    //     0xa78c8c: blr             x2
    // 0xa78c90: add             SP, SP, #8
    // 0xa78c94: ldur            x1, [fp, #-8]
    // 0xa78c98: b               #0xa78c2c
    // 0xa78c9c: r0 = Null
    //     0xa78c9c: mov             x0, NULL
    // 0xa78ca0: LeaveFrame
    //     0xa78ca0: mov             SP, fp
    //     0xa78ca4: ldp             fp, lr, [SP], #0x10
    // 0xa78ca8: ret
    //     0xa78ca8: ret             
    // 0xa78cac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa78cac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa78cb0: b               #0xa78bf0
    // 0xa78cb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa78cb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa78cb8: b               #0xa78c38
    // 0xa78cbc: r0 = NullErrorSharedWithoutFPURegs()
    //     0xa78cbc: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 2381, size: 0x48, field offset: 0x40
abstract class ContainerLayer extends Layer {

  _ buildScene(/* No info */) {
    // ** addr: 0x5ddf2c, size: 0x9c
    // 0x5ddf2c: EnterFrame
    //     0x5ddf2c: stp             fp, lr, [SP, #-0x10]!
    //     0x5ddf30: mov             fp, SP
    // 0x5ddf34: CheckStackOverflow
    //     0x5ddf34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5ddf38: cmp             SP, x16
    //     0x5ddf3c: b.ls            #0x5ddfc0
    // 0x5ddf40: ldr             x16, [fp, #0x18]
    // 0x5ddf44: SaveReg r16
    //     0x5ddf44: str             x16, [SP, #-8]!
    // 0x5ddf48: r0 = updateSubtreeNeedsAddToScene()
    //     0x5ddf48: bl              #0x792400  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::updateSubtreeNeedsAddToScene
    // 0x5ddf4c: add             SP, SP, #8
    // 0x5ddf50: ldr             x1, [fp, #0x18]
    // 0x5ddf54: r0 = LoadClassIdInstr(r1)
    //     0x5ddf54: ldur            x0, [x1, #-1]
    //     0x5ddf58: ubfx            x0, x0, #0xc, #0x14
    // 0x5ddf5c: ldr             x16, [fp, #0x10]
    // 0x5ddf60: stp             x16, x1, [SP, #-0x10]!
    // 0x5ddf64: r0 = GDT[cid_x0 + 0x7b71]()
    //     0x5ddf64: mov             x17, #0x7b71
    //     0x5ddf68: add             lr, x0, x17
    //     0x5ddf6c: ldr             lr, [x21, lr, lsl #3]
    //     0x5ddf70: blr             lr
    // 0x5ddf74: add             SP, SP, #0x10
    // 0x5ddf78: ldr             x0, [fp, #0x18]
    // 0x5ddf7c: LoadField: r1 = r0->field_1b
    //     0x5ddf7c: ldur            x1, [x0, #0x1b]
    // 0x5ddf80: cmp             x1, #0
    // 0x5ddf84: b.le            #0x5ddf98
    // 0x5ddf88: r16 = true
    //     0x5ddf88: add             x16, NULL, #0x20  ; true
    // 0x5ddf8c: stp             x16, x0, [SP, #-0x10]!
    // 0x5ddf90: r0 = _fireCompositionCallbacks()
    //     0x5ddf90: bl              #0xa78cc0  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::_fireCompositionCallbacks
    // 0x5ddf94: add             SP, SP, #0x10
    // 0x5ddf98: ldr             x0, [fp, #0x18]
    // 0x5ddf9c: r1 = false
    //     0x5ddf9c: add             x1, NULL, #0x30  ; false
    // 0x5ddfa0: StoreField: r0->field_2f = r1
    //     0x5ddfa0: stur            w1, [x0, #0x2f]
    // 0x5ddfa4: ldr             x16, [fp, #0x10]
    // 0x5ddfa8: SaveReg r16
    //     0x5ddfa8: str             x16, [SP, #-8]!
    // 0x5ddfac: r0 = build()
    //     0x5ddfac: bl              #0x5ddfc8  ; [dart:ui] SceneBuilder::build
    // 0x5ddfb0: add             SP, SP, #8
    // 0x5ddfb4: LeaveFrame
    //     0x5ddfb4: mov             SP, fp
    //     0x5ddfb8: ldp             fp, lr, [SP], #0x10
    // 0x5ddfbc: ret
    //     0x5ddfbc: ret             
    // 0x5ddfc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5ddfc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5ddfc4: b               #0x5ddf40
  }
  _ removeAllChildren(/* No info */) {
    // ** addr: 0x5df3f8, size: 0x124
    // 0x5df3f8: EnterFrame
    //     0x5df3f8: stp             fp, lr, [SP, #-0x10]!
    //     0x5df3fc: mov             fp, SP
    // 0x5df400: AllocStack(0x18)
    //     0x5df400: sub             SP, SP, #0x18
    // 0x5df404: CheckStackOverflow
    //     0x5df404: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5df408: cmp             SP, x16
    //     0x5df40c: b.ls            #0x5df50c
    // 0x5df410: ldr             x1, [fp, #0x10]
    // 0x5df414: LoadField: r0 = r1->field_3f
    //     0x5df414: ldur            w0, [x1, #0x3f]
    // 0x5df418: DecompressPointer r0
    //     0x5df418: add             x0, x0, HEAP, lsl #32
    // 0x5df41c: mov             x2, x0
    // 0x5df420: stur            x2, [fp, #-0x10]
    // 0x5df424: CheckStackOverflow
    //     0x5df424: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5df428: cmp             SP, x16
    //     0x5df42c: b.ls            #0x5df514
    // 0x5df430: cmp             w2, NULL
    // 0x5df434: b.eq            #0x5df4f4
    // 0x5df438: LoadField: r3 = r2->field_37
    //     0x5df438: ldur            w3, [x2, #0x37]
    // 0x5df43c: DecompressPointer r3
    //     0x5df43c: add             x3, x3, HEAP, lsl #32
    // 0x5df440: stur            x3, [fp, #-8]
    // 0x5df444: StoreField: r2->field_3b = rNULL
    //     0x5df444: stur            NULL, [x2, #0x3b]
    // 0x5df448: StoreField: r2->field_37 = rNULL
    //     0x5df448: stur            NULL, [x2, #0x37]
    // 0x5df44c: r0 = LoadClassIdInstr(r1)
    //     0x5df44c: ldur            x0, [x1, #-1]
    //     0x5df450: ubfx            x0, x0, #0xc, #0x14
    // 0x5df454: SaveReg r1
    //     0x5df454: str             x1, [SP, #-8]!
    // 0x5df458: r0 = GDT[cid_x0 + 0x19b9]()
    //     0x5df458: mov             x17, #0x19b9
    //     0x5df45c: add             lr, x0, x17
    //     0x5df460: ldr             lr, [x21, lr, lsl #3]
    //     0x5df464: blr             lr
    // 0x5df468: add             SP, SP, #8
    // 0x5df46c: tbz             w0, #4, #0x5df480
    // 0x5df470: ldr             x16, [fp, #0x10]
    // 0x5df474: SaveReg r16
    //     0x5df474: str             x16, [SP, #-8]!
    // 0x5df478: r0 = markNeedsAddToScene()
    //     0x5df478: bl              #0x5dec74  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0x5df47c: add             SP, SP, #8
    // 0x5df480: ldur            x0, [fp, #-0x10]
    // 0x5df484: LoadField: r1 = r0->field_1b
    //     0x5df484: ldur            x1, [x0, #0x1b]
    // 0x5df488: cbz             x1, #0x5df4a0
    // 0x5df48c: neg             x2, x1
    // 0x5df490: ldr             x16, [fp, #0x10]
    // 0x5df494: stp             x2, x16, [SP, #-0x10]!
    // 0x5df498: r0 = _updateSubtreeCompositionObserverCount()
    //     0x5df498: bl              #0x5df620  ; [package:flutter/src/rendering/layer.dart] Layer::_updateSubtreeCompositionObserverCount
    // 0x5df49c: add             SP, SP, #0x10
    // 0x5df4a0: ldur            x0, [fp, #-0x10]
    // 0x5df4a4: ldr             x16, [fp, #0x10]
    // 0x5df4a8: stp             x0, x16, [SP, #-0x10]!
    // 0x5df4ac: r0 = dropChild()
    //     0x5df4ac: bl              #0x5df5b4  ; [package:flutter/src/foundation/node.dart] AbstractNode::dropChild
    // 0x5df4b0: add             SP, SP, #0x10
    // 0x5df4b4: ldur            x0, [fp, #-0x10]
    // 0x5df4b8: LoadField: r1 = r0->field_23
    //     0x5df4b8: ldur            w1, [x0, #0x23]
    // 0x5df4bc: DecompressPointer r1
    //     0x5df4bc: add             x1, x1, HEAP, lsl #32
    // 0x5df4c0: stur            x1, [fp, #-0x18]
    // 0x5df4c4: LoadField: r0 = r1->field_b
    //     0x5df4c4: ldur            w0, [x1, #0xb]
    // 0x5df4c8: DecompressPointer r0
    //     0x5df4c8: add             x0, x0, HEAP, lsl #32
    // 0x5df4cc: cmp             w0, NULL
    // 0x5df4d0: b.eq            #0x5df4e8
    // 0x5df4d4: SaveReg r0
    //     0x5df4d4: str             x0, [SP, #-8]!
    // 0x5df4d8: r0 = _unref()
    //     0x5df4d8: bl              #0x5bbd64  ; [package:flutter/src/rendering/layer.dart] Layer::_unref
    // 0x5df4dc: add             SP, SP, #8
    // 0x5df4e0: ldur            x1, [fp, #-0x18]
    // 0x5df4e4: StoreField: r1->field_b = rNULL
    //     0x5df4e4: stur            NULL, [x1, #0xb]
    // 0x5df4e8: ldur            x2, [fp, #-8]
    // 0x5df4ec: ldr             x1, [fp, #0x10]
    // 0x5df4f0: b               #0x5df420
    // 0x5df4f4: StoreField: r1->field_3f = rNULL
    //     0x5df4f4: stur            NULL, [x1, #0x3f]
    // 0x5df4f8: StoreField: r1->field_43 = rNULL
    //     0x5df4f8: stur            NULL, [x1, #0x43]
    // 0x5df4fc: r0 = Null
    //     0x5df4fc: mov             x0, NULL
    // 0x5df500: LeaveFrame
    //     0x5df500: mov             SP, fp
    //     0x5df504: ldp             fp, lr, [SP], #0x10
    // 0x5df508: ret
    //     0x5df508: ret             
    // 0x5df50c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5df50c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5df510: b               #0x5df410
    // 0x5df514: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5df514: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5df518: b               #0x5df430
  }
  _ append(/* No info */) {
    // ** addr: 0x654230, size: 0xfc
    // 0x654230: EnterFrame
    //     0x654230: stp             fp, lr, [SP, #-0x10]!
    //     0x654234: mov             fp, SP
    // 0x654238: CheckStackOverflow
    //     0x654238: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65423c: cmp             SP, x16
    //     0x654240: b.ls            #0x654324
    // 0x654244: ldr             x16, [fp, #0x18]
    // 0x654248: ldr             lr, [fp, #0x10]
    // 0x65424c: stp             lr, x16, [SP, #-0x10]!
    // 0x654250: r0 = adoptChild()
    //     0x654250: bl              #0x65432c  ; [package:flutter/src/rendering/layer.dart] Layer::adoptChild
    // 0x654254: add             SP, SP, #0x10
    // 0x654258: ldr             x1, [fp, #0x18]
    // 0x65425c: LoadField: r2 = r1->field_43
    //     0x65425c: ldur            w2, [x1, #0x43]
    // 0x654260: DecompressPointer r2
    //     0x654260: add             x2, x2, HEAP, lsl #32
    // 0x654264: mov             x0, x2
    // 0x654268: ldr             x3, [fp, #0x10]
    // 0x65426c: StoreField: r3->field_3b = r0
    //     0x65426c: stur            w0, [x3, #0x3b]
    //     0x654270: ldurb           w16, [x3, #-1]
    //     0x654274: ldurb           w17, [x0, #-1]
    //     0x654278: and             x16, x17, x16, lsr #2
    //     0x65427c: tst             x16, HEAP, lsr #32
    //     0x654280: b.eq            #0x654288
    //     0x654284: bl              #0xd682ac
    // 0x654288: cmp             w2, NULL
    // 0x65428c: b.eq            #0x6542b0
    // 0x654290: mov             x0, x3
    // 0x654294: StoreField: r2->field_37 = r0
    //     0x654294: stur            w0, [x2, #0x37]
    //     0x654298: ldurb           w16, [x2, #-1]
    //     0x65429c: ldurb           w17, [x0, #-1]
    //     0x6542a0: and             x16, x17, x16, lsr #2
    //     0x6542a4: tst             x16, HEAP, lsr #32
    //     0x6542a8: b.eq            #0x6542b0
    //     0x6542ac: bl              #0xd6828c
    // 0x6542b0: mov             x0, x3
    // 0x6542b4: StoreField: r1->field_43 = r0
    //     0x6542b4: stur            w0, [x1, #0x43]
    //     0x6542b8: ldurb           w16, [x1, #-1]
    //     0x6542bc: ldurb           w17, [x0, #-1]
    //     0x6542c0: and             x16, x17, x16, lsr #2
    //     0x6542c4: tst             x16, HEAP, lsr #32
    //     0x6542c8: b.eq            #0x6542d0
    //     0x6542cc: bl              #0xd6826c
    // 0x6542d0: LoadField: r0 = r1->field_3f
    //     0x6542d0: ldur            w0, [x1, #0x3f]
    // 0x6542d4: DecompressPointer r0
    //     0x6542d4: add             x0, x0, HEAP, lsl #32
    // 0x6542d8: cmp             w0, NULL
    // 0x6542dc: b.ne            #0x654300
    // 0x6542e0: mov             x0, x3
    // 0x6542e4: StoreField: r1->field_3f = r0
    //     0x6542e4: stur            w0, [x1, #0x3f]
    //     0x6542e8: ldurb           w16, [x1, #-1]
    //     0x6542ec: ldurb           w17, [x0, #-1]
    //     0x6542f0: and             x16, x17, x16, lsr #2
    //     0x6542f4: tst             x16, HEAP, lsr #32
    //     0x6542f8: b.eq            #0x654300
    //     0x6542fc: bl              #0xd6826c
    // 0x654300: LoadField: r0 = r3->field_23
    //     0x654300: ldur            w0, [x3, #0x23]
    // 0x654304: DecompressPointer r0
    //     0x654304: add             x0, x0, HEAP, lsl #32
    // 0x654308: stp             x3, x0, [SP, #-0x10]!
    // 0x65430c: r0 = layer=()
    //     0x65430c: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x654310: add             SP, SP, #0x10
    // 0x654314: r0 = Null
    //     0x654314: mov             x0, NULL
    // 0x654318: LeaveFrame
    //     0x654318: mov             SP, fp
    //     0x65431c: ldp             fp, lr, [SP], #0x10
    // 0x654320: ret
    //     0x654320: ret             
    // 0x654324: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x654324: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x654328: b               #0x654244
  }
  _ _removeChild(/* No info */) {
    // ** addr: 0x654448, size: 0x114
    // 0x654448: EnterFrame
    //     0x654448: stp             fp, lr, [SP, #-0x10]!
    //     0x65444c: mov             fp, SP
    // 0x654450: CheckStackOverflow
    //     0x654450: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x654454: cmp             SP, x16
    //     0x654458: b.ls            #0x654554
    // 0x65445c: ldr             x1, [fp, #0x10]
    // 0x654460: LoadField: r2 = r1->field_3b
    //     0x654460: ldur            w2, [x1, #0x3b]
    // 0x654464: DecompressPointer r2
    //     0x654464: add             x2, x2, HEAP, lsl #32
    // 0x654468: cmp             w2, NULL
    // 0x65446c: b.ne            #0x65449c
    // 0x654470: ldr             x3, [fp, #0x18]
    // 0x654474: LoadField: r0 = r1->field_37
    //     0x654474: ldur            w0, [x1, #0x37]
    // 0x654478: DecompressPointer r0
    //     0x654478: add             x0, x0, HEAP, lsl #32
    // 0x65447c: StoreField: r3->field_3f = r0
    //     0x65447c: stur            w0, [x3, #0x3f]
    //     0x654480: ldurb           w16, [x3, #-1]
    //     0x654484: ldurb           w17, [x0, #-1]
    //     0x654488: and             x16, x17, x16, lsr #2
    //     0x65448c: tst             x16, HEAP, lsr #32
    //     0x654490: b.eq            #0x654498
    //     0x654494: bl              #0xd682ac
    // 0x654498: b               #0x6544c4
    // 0x65449c: ldr             x3, [fp, #0x18]
    // 0x6544a0: LoadField: r0 = r1->field_37
    //     0x6544a0: ldur            w0, [x1, #0x37]
    // 0x6544a4: DecompressPointer r0
    //     0x6544a4: add             x0, x0, HEAP, lsl #32
    // 0x6544a8: StoreField: r2->field_37 = r0
    //     0x6544a8: stur            w0, [x2, #0x37]
    //     0x6544ac: ldurb           w16, [x2, #-1]
    //     0x6544b0: ldurb           w17, [x0, #-1]
    //     0x6544b4: and             x16, x17, x16, lsr #2
    //     0x6544b8: tst             x16, HEAP, lsr #32
    //     0x6544bc: b.eq            #0x6544c4
    //     0x6544c0: bl              #0xd6828c
    // 0x6544c4: LoadField: r4 = r1->field_37
    //     0x6544c4: ldur            w4, [x1, #0x37]
    // 0x6544c8: DecompressPointer r4
    //     0x6544c8: add             x4, x4, HEAP, lsl #32
    // 0x6544cc: cmp             w4, NULL
    // 0x6544d0: b.ne            #0x6544f8
    // 0x6544d4: mov             x0, x2
    // 0x6544d8: StoreField: r3->field_43 = r0
    //     0x6544d8: stur            w0, [x3, #0x43]
    //     0x6544dc: ldurb           w16, [x3, #-1]
    //     0x6544e0: ldurb           w17, [x0, #-1]
    //     0x6544e4: and             x16, x17, x16, lsr #2
    //     0x6544e8: tst             x16, HEAP, lsr #32
    //     0x6544ec: b.eq            #0x6544f4
    //     0x6544f0: bl              #0xd682ac
    // 0x6544f4: b               #0x654518
    // 0x6544f8: mov             x0, x2
    // 0x6544fc: StoreField: r4->field_3b = r0
    //     0x6544fc: stur            w0, [x4, #0x3b]
    //     0x654500: ldurb           w16, [x4, #-1]
    //     0x654504: ldurb           w17, [x0, #-1]
    //     0x654508: and             x16, x17, x16, lsr #2
    //     0x65450c: tst             x16, HEAP, lsr #32
    //     0x654510: b.eq            #0x654518
    //     0x654514: bl              #0xd682cc
    // 0x654518: StoreField: r1->field_3b = rNULL
    //     0x654518: stur            NULL, [x1, #0x3b]
    // 0x65451c: StoreField: r1->field_37 = rNULL
    //     0x65451c: stur            NULL, [x1, #0x37]
    // 0x654520: stp             x1, x3, [SP, #-0x10]!
    // 0x654524: r0 = dropChild()
    //     0x654524: bl              #0x5df51c  ; [package:flutter/src/rendering/layer.dart] Layer::dropChild
    // 0x654528: add             SP, SP, #0x10
    // 0x65452c: ldr             x0, [fp, #0x10]
    // 0x654530: LoadField: r1 = r0->field_23
    //     0x654530: ldur            w1, [x0, #0x23]
    // 0x654534: DecompressPointer r1
    //     0x654534: add             x1, x1, HEAP, lsl #32
    // 0x654538: stp             NULL, x1, [SP, #-0x10]!
    // 0x65453c: r0 = layer=()
    //     0x65453c: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x654540: add             SP, SP, #0x10
    // 0x654544: r0 = Null
    //     0x654544: mov             x0, NULL
    // 0x654548: LeaveFrame
    //     0x654548: mov             SP, fp
    //     0x65454c: ldp             fp, lr, [SP], #0x10
    // 0x654550: ret
    //     0x654550: ret             
    // 0x654554: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x654554: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x654558: b               #0x65445c
  }
  _ updateSubtreeNeedsAddToScene(/* No info */) {
    // ** addr: 0x792400, size: 0xcc
    // 0x792400: EnterFrame
    //     0x792400: stp             fp, lr, [SP, #-0x10]!
    //     0x792404: mov             fp, SP
    // 0x792408: AllocStack(0x8)
    //     0x792408: sub             SP, SP, #8
    // 0x79240c: CheckStackOverflow
    //     0x79240c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x792410: cmp             SP, x16
    //     0x792414: b.ls            #0x7924bc
    // 0x792418: ldr             x16, [fp, #0x10]
    // 0x79241c: SaveReg r16
    //     0x79241c: str             x16, [SP, #-8]!
    // 0x792420: r0 = updateSubtreeNeedsAddToScene()
    //     0x792420: bl              #0x792390  ; [package:flutter/src/rendering/layer.dart] Layer::updateSubtreeNeedsAddToScene
    // 0x792424: add             SP, SP, #8
    // 0x792428: ldr             x1, [fp, #0x10]
    // 0x79242c: LoadField: r0 = r1->field_3f
    //     0x79242c: ldur            w0, [x1, #0x3f]
    // 0x792430: DecompressPointer r0
    //     0x792430: add             x0, x0, HEAP, lsl #32
    // 0x792434: mov             x2, x0
    // 0x792438: stur            x2, [fp, #-8]
    // 0x79243c: CheckStackOverflow
    //     0x79243c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x792440: cmp             SP, x16
    //     0x792444: b.ls            #0x7924c4
    // 0x792448: cmp             w2, NULL
    // 0x79244c: b.eq            #0x7924ac
    // 0x792450: r0 = LoadClassIdInstr(r2)
    //     0x792450: ldur            x0, [x2, #-1]
    //     0x792454: ubfx            x0, x0, #0xc, #0x14
    // 0x792458: SaveReg r2
    //     0x792458: str             x2, [SP, #-8]!
    // 0x79245c: r0 = GDT[cid_x0 + 0xbf98]()
    //     0x79245c: mov             x17, #0xbf98
    //     0x792460: add             lr, x0, x17
    //     0x792464: ldr             lr, [x21, lr, lsl #3]
    //     0x792468: blr             lr
    // 0x79246c: add             SP, SP, #8
    // 0x792470: ldr             x1, [fp, #0x10]
    // 0x792474: LoadField: r2 = r1->field_2f
    //     0x792474: ldur            w2, [x1, #0x2f]
    // 0x792478: DecompressPointer r2
    //     0x792478: add             x2, x2, HEAP, lsl #32
    // 0x79247c: tbnz            w2, #4, #0x79248c
    // 0x792480: ldur            x2, [fp, #-8]
    // 0x792484: r3 = true
    //     0x792484: add             x3, NULL, #0x20  ; true
    // 0x792488: b               #0x792498
    // 0x79248c: ldur            x2, [fp, #-8]
    // 0x792490: LoadField: r3 = r2->field_2f
    //     0x792490: ldur            w3, [x2, #0x2f]
    // 0x792494: DecompressPointer r3
    //     0x792494: add             x3, x3, HEAP, lsl #32
    // 0x792498: StoreField: r1->field_2f = r3
    //     0x792498: stur            w3, [x1, #0x2f]
    // 0x79249c: LoadField: r0 = r2->field_37
    //     0x79249c: ldur            w0, [x2, #0x37]
    // 0x7924a0: DecompressPointer r0
    //     0x7924a0: add             x0, x0, HEAP, lsl #32
    // 0x7924a4: mov             x2, x0
    // 0x7924a8: b               #0x792438
    // 0x7924ac: r0 = Null
    //     0x7924ac: mov             x0, NULL
    // 0x7924b0: LeaveFrame
    //     0x7924b0: mov             SP, fp
    //     0x7924b4: ldp             fp, lr, [SP], #0x10
    // 0x7924b8: ret
    //     0x7924b8: ret             
    // 0x7924bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7924bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7924c0: b               #0x792418
    // 0x7924c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7924c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7924c8: b               #0x792448
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bfa24, size: 0xbc
    // 0x9bfa24: EnterFrame
    //     0x9bfa24: stp             fp, lr, [SP, #-0x10]!
    //     0x9bfa28: mov             fp, SP
    // 0x9bfa2c: AllocStack(0x8)
    //     0x9bfa2c: sub             SP, SP, #8
    // 0x9bfa30: CheckStackOverflow
    //     0x9bfa30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bfa34: cmp             SP, x16
    //     0x9bfa38: b.ls            #0x9bfad0
    // 0x9bfa3c: ldr             x0, [fp, #0x10]
    // 0x9bfa40: ldr             x1, [fp, #0x18]
    // 0x9bfa44: StoreField: r1->field_f = r0
    //     0x9bfa44: stur            w0, [x1, #0xf]
    //     0x9bfa48: tbz             w0, #0, #0x9bfa64
    //     0x9bfa4c: ldurb           w16, [x1, #-1]
    //     0x9bfa50: ldurb           w17, [x0, #-1]
    //     0x9bfa54: and             x16, x17, x16, lsr #2
    //     0x9bfa58: tst             x16, HEAP, lsr #32
    //     0x9bfa5c: b.eq            #0x9bfa64
    //     0x9bfa60: bl              #0xd6826c
    // 0x9bfa64: LoadField: r0 = r1->field_3f
    //     0x9bfa64: ldur            w0, [x1, #0x3f]
    // 0x9bfa68: DecompressPointer r0
    //     0x9bfa68: add             x0, x0, HEAP, lsl #32
    // 0x9bfa6c: mov             x1, x0
    // 0x9bfa70: stur            x1, [fp, #-8]
    // 0x9bfa74: CheckStackOverflow
    //     0x9bfa74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bfa78: cmp             SP, x16
    //     0x9bfa7c: b.ls            #0x9bfad8
    // 0x9bfa80: cmp             w1, NULL
    // 0x9bfa84: b.eq            #0x9bfac0
    // 0x9bfa88: r0 = LoadClassIdInstr(r1)
    //     0x9bfa88: ldur            x0, [x1, #-1]
    //     0x9bfa8c: ubfx            x0, x0, #0xc, #0x14
    // 0x9bfa90: ldr             x16, [fp, #0x10]
    // 0x9bfa94: stp             x16, x1, [SP, #-0x10]!
    // 0x9bfa98: r0 = GDT[cid_x0 + 0xaf1f]()
    //     0x9bfa98: mov             x17, #0xaf1f
    //     0x9bfa9c: add             lr, x0, x17
    //     0x9bfaa0: ldr             lr, [x21, lr, lsl #3]
    //     0x9bfaa4: blr             lr
    // 0x9bfaa8: add             SP, SP, #0x10
    // 0x9bfaac: ldur            x1, [fp, #-8]
    // 0x9bfab0: LoadField: r0 = r1->field_37
    //     0x9bfab0: ldur            w0, [x1, #0x37]
    // 0x9bfab4: DecompressPointer r0
    //     0x9bfab4: add             x0, x0, HEAP, lsl #32
    // 0x9bfab8: mov             x1, x0
    // 0x9bfabc: b               #0x9bfa70
    // 0x9bfac0: r0 = Null
    //     0x9bfac0: mov             x0, NULL
    // 0x9bfac4: LeaveFrame
    //     0x9bfac4: mov             SP, fp
    //     0x9bfac8: ldp             fp, lr, [SP], #0x10
    // 0x9bfacc: ret
    //     0x9bfacc: ret             
    // 0x9bfad0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bfad0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bfad4: b               #0x9bfa3c
    // 0x9bfad8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bfad8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bfadc: b               #0x9bfa80
  }
  _ detach(/* No info */) {
    // ** addr: 0xa6ae44, size: 0xb8
    // 0xa6ae44: EnterFrame
    //     0xa6ae44: stp             fp, lr, [SP, #-0x10]!
    //     0xa6ae48: mov             fp, SP
    // 0xa6ae4c: AllocStack(0x8)
    //     0xa6ae4c: sub             SP, SP, #8
    // 0xa6ae50: CheckStackOverflow
    //     0xa6ae50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6ae54: cmp             SP, x16
    //     0xa6ae58: b.ls            #0xa6aeec
    // 0xa6ae5c: ldr             x16, [fp, #0x10]
    // 0xa6ae60: SaveReg r16
    //     0xa6ae60: str             x16, [SP, #-8]!
    // 0xa6ae64: r0 = detach()
    //     0xa6ae64: bl              #0xa6ade0  ; [package:flutter/src/foundation/node.dart] AbstractNode::detach
    // 0xa6ae68: add             SP, SP, #8
    // 0xa6ae6c: ldr             x1, [fp, #0x10]
    // 0xa6ae70: LoadField: r0 = r1->field_3f
    //     0xa6ae70: ldur            w0, [x1, #0x3f]
    // 0xa6ae74: DecompressPointer r0
    //     0xa6ae74: add             x0, x0, HEAP, lsl #32
    // 0xa6ae78: mov             x2, x0
    // 0xa6ae7c: stur            x2, [fp, #-8]
    // 0xa6ae80: CheckStackOverflow
    //     0xa6ae80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6ae84: cmp             SP, x16
    //     0xa6ae88: b.ls            #0xa6aef4
    // 0xa6ae8c: cmp             w2, NULL
    // 0xa6ae90: b.eq            #0xa6aec8
    // 0xa6ae94: r0 = LoadClassIdInstr(r2)
    //     0xa6ae94: ldur            x0, [x2, #-1]
    //     0xa6ae98: ubfx            x0, x0, #0xc, #0x14
    // 0xa6ae9c: SaveReg r2
    //     0xa6ae9c: str             x2, [SP, #-8]!
    // 0xa6aea0: r0 = GDT[cid_x0 + 0xa3cc]()
    //     0xa6aea0: mov             x17, #0xa3cc
    //     0xa6aea4: add             lr, x0, x17
    //     0xa6aea8: ldr             lr, [x21, lr, lsl #3]
    //     0xa6aeac: blr             lr
    // 0xa6aeb0: add             SP, SP, #8
    // 0xa6aeb4: ldur            x0, [fp, #-8]
    // 0xa6aeb8: LoadField: r2 = r0->field_37
    //     0xa6aeb8: ldur            w2, [x0, #0x37]
    // 0xa6aebc: DecompressPointer r2
    //     0xa6aebc: add             x2, x2, HEAP, lsl #32
    // 0xa6aec0: ldr             x1, [fp, #0x10]
    // 0xa6aec4: b               #0xa6ae7c
    // 0xa6aec8: ldr             x16, [fp, #0x10]
    // 0xa6aecc: r30 = false
    //     0xa6aecc: add             lr, NULL, #0x30  ; false
    // 0xa6aed0: stp             lr, x16, [SP, #-0x10]!
    // 0xa6aed4: r0 = _fireCompositionCallbacks()
    //     0xa6aed4: bl              #0xa78bd8  ; [package:flutter/src/rendering/layer.dart] Layer::_fireCompositionCallbacks
    // 0xa6aed8: add             SP, SP, #0x10
    // 0xa6aedc: r0 = Null
    //     0xa6aedc: mov             x0, NULL
    // 0xa6aee0: LeaveFrame
    //     0xa6aee0: mov             SP, fp
    //     0xa6aee4: ldp             fp, lr, [SP], #0x10
    // 0xa6aee8: ret
    //     0xa6aee8: ret             
    // 0xa6aeec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6aeec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6aef0: b               #0xa6ae5c
    // 0xa6aef4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6aef4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6aef8: b               #0xa6ae8c
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa780d4, size: 0x64
    // 0xa780d4: EnterFrame
    //     0xa780d4: stp             fp, lr, [SP, #-0x10]!
    //     0xa780d8: mov             fp, SP
    // 0xa780dc: CheckStackOverflow
    //     0xa780dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa780e0: cmp             SP, x16
    //     0xa780e4: b.ls            #0xa78130
    // 0xa780e8: ldr             x16, [fp, #0x10]
    // 0xa780ec: SaveReg r16
    //     0xa780ec: str             x16, [SP, #-8]!
    // 0xa780f0: r0 = removeAllChildren()
    //     0xa780f0: bl              #0x5df3f8  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::removeAllChildren
    // 0xa780f4: add             SP, SP, #8
    // 0xa780f8: ldr             x0, [fp, #0x10]
    // 0xa780fc: LoadField: r1 = r0->field_17
    //     0xa780fc: ldur            w1, [x0, #0x17]
    // 0xa78100: DecompressPointer r1
    //     0xa78100: add             x1, x1, HEAP, lsl #32
    // 0xa78104: SaveReg r1
    //     0xa78104: str             x1, [SP, #-8]!
    // 0xa78108: r0 = clear()
    //     0xa78108: bl              #0x4e32e4  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0xa7810c: add             SP, SP, #8
    // 0xa78110: ldr             x16, [fp, #0x10]
    // 0xa78114: SaveReg r16
    //     0xa78114: str             x16, [SP, #-8]!
    // 0xa78118: r0 = dispose()
    //     0xa78118: bl              #0xa78078  ; [package:flutter/src/rendering/layer.dart] Layer::dispose
    // 0xa7811c: add             SP, SP, #8
    // 0xa78120: r0 = Null
    //     0xa78120: mov             x0, NULL
    // 0xa78124: LeaveFrame
    //     0xa78124: mov             SP, fp
    //     0xa78128: ldp             fp, lr, [SP], #0x10
    // 0xa7812c: ret
    //     0xa7812c: ret             
    // 0xa78130: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa78130: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa78134: b               #0xa780e8
  }
  _ supportsRasterization(/* No info */) {
    // ** addr: 0xa78adc, size: 0xa4
    // 0xa78adc: EnterFrame
    //     0xa78adc: stp             fp, lr, [SP, #-0x10]!
    //     0xa78ae0: mov             fp, SP
    // 0xa78ae4: AllocStack(0x8)
    //     0xa78ae4: sub             SP, SP, #8
    // 0xa78ae8: CheckStackOverflow
    //     0xa78ae8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa78aec: cmp             SP, x16
    //     0xa78af0: b.ls            #0xa78b70
    // 0xa78af4: ldr             x0, [fp, #0x10]
    // 0xa78af8: LoadField: r1 = r0->field_43
    //     0xa78af8: ldur            w1, [x0, #0x43]
    // 0xa78afc: DecompressPointer r1
    //     0xa78afc: add             x1, x1, HEAP, lsl #32
    // 0xa78b00: stur            x1, [fp, #-8]
    // 0xa78b04: CheckStackOverflow
    //     0xa78b04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa78b08: cmp             SP, x16
    //     0xa78b0c: b.ls            #0xa78b78
    // 0xa78b10: cmp             w1, NULL
    // 0xa78b14: b.eq            #0xa78b60
    // 0xa78b18: r0 = LoadClassIdInstr(r1)
    //     0xa78b18: ldur            x0, [x1, #-1]
    //     0xa78b1c: ubfx            x0, x0, #0xc, #0x14
    // 0xa78b20: SaveReg r1
    //     0xa78b20: str             x1, [SP, #-8]!
    // 0xa78b24: r0 = GDT[cid_x0 + 0x9859]()
    //     0xa78b24: mov             x17, #0x9859
    //     0xa78b28: add             lr, x0, x17
    //     0xa78b2c: ldr             lr, [x21, lr, lsl #3]
    //     0xa78b30: blr             lr
    // 0xa78b34: add             SP, SP, #8
    // 0xa78b38: tbz             w0, #4, #0xa78b4c
    // 0xa78b3c: r0 = false
    //     0xa78b3c: add             x0, NULL, #0x30  ; false
    // 0xa78b40: LeaveFrame
    //     0xa78b40: mov             SP, fp
    //     0xa78b44: ldp             fp, lr, [SP], #0x10
    // 0xa78b48: ret
    //     0xa78b48: ret             
    // 0xa78b4c: ldur            x1, [fp, #-8]
    // 0xa78b50: LoadField: r0 = r1->field_3b
    //     0xa78b50: ldur            w0, [x1, #0x3b]
    // 0xa78b54: DecompressPointer r0
    //     0xa78b54: add             x0, x0, HEAP, lsl #32
    // 0xa78b58: mov             x1, x0
    // 0xa78b5c: b               #0xa78b00
    // 0xa78b60: r0 = true
    //     0xa78b60: add             x0, NULL, #0x20  ; true
    // 0xa78b64: LeaveFrame
    //     0xa78b64: mov             SP, fp
    //     0xa78b68: ldp             fp, lr, [SP], #0x10
    // 0xa78b6c: ret
    //     0xa78b6c: ret             
    // 0xa78b70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa78b70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa78b74: b               #0xa78af4
    // 0xa78b78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa78b78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa78b7c: b               #0xa78b10
  }
  _ _fireCompositionCallbacks(/* No info */) {
    // ** addr: 0xa78cc0, size: 0xbc
    // 0xa78cc0: EnterFrame
    //     0xa78cc0: stp             fp, lr, [SP, #-0x10]!
    //     0xa78cc4: mov             fp, SP
    // 0xa78cc8: AllocStack(0x8)
    //     0xa78cc8: sub             SP, SP, #8
    // 0xa78ccc: CheckStackOverflow
    //     0xa78ccc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa78cd0: cmp             SP, x16
    //     0xa78cd4: b.ls            #0xa78d6c
    // 0xa78cd8: ldr             x16, [fp, #0x18]
    // 0xa78cdc: ldr             lr, [fp, #0x10]
    // 0xa78ce0: stp             lr, x16, [SP, #-0x10]!
    // 0xa78ce4: r0 = _fireCompositionCallbacks()
    //     0xa78ce4: bl              #0xa78bd8  ; [package:flutter/src/rendering/layer.dart] Layer::_fireCompositionCallbacks
    // 0xa78ce8: add             SP, SP, #0x10
    // 0xa78cec: ldr             x1, [fp, #0x10]
    // 0xa78cf0: tbz             w1, #4, #0xa78d04
    // 0xa78cf4: r0 = Null
    //     0xa78cf4: mov             x0, NULL
    // 0xa78cf8: LeaveFrame
    //     0xa78cf8: mov             SP, fp
    //     0xa78cfc: ldp             fp, lr, [SP], #0x10
    // 0xa78d00: ret
    //     0xa78d00: ret             
    // 0xa78d04: ldr             x0, [fp, #0x18]
    // 0xa78d08: LoadField: r2 = r0->field_3f
    //     0xa78d08: ldur            w2, [x0, #0x3f]
    // 0xa78d0c: DecompressPointer r2
    //     0xa78d0c: add             x2, x2, HEAP, lsl #32
    // 0xa78d10: stur            x2, [fp, #-8]
    // 0xa78d14: CheckStackOverflow
    //     0xa78d14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa78d18: cmp             SP, x16
    //     0xa78d1c: b.ls            #0xa78d74
    // 0xa78d20: cmp             w2, NULL
    // 0xa78d24: b.eq            #0xa78d5c
    // 0xa78d28: r0 = LoadClassIdInstr(r2)
    //     0xa78d28: ldur            x0, [x2, #-1]
    //     0xa78d2c: ubfx            x0, x0, #0xc, #0x14
    // 0xa78d30: stp             x1, x2, [SP, #-0x10]!
    // 0xa78d34: r0 = GDT[cid_x0 + 0x981f]()
    //     0xa78d34: mov             x17, #0x981f
    //     0xa78d38: add             lr, x0, x17
    //     0xa78d3c: ldr             lr, [x21, lr, lsl #3]
    //     0xa78d40: blr             lr
    // 0xa78d44: add             SP, SP, #0x10
    // 0xa78d48: ldur            x1, [fp, #-8]
    // 0xa78d4c: LoadField: r2 = r1->field_37
    //     0xa78d4c: ldur            w2, [x1, #0x37]
    // 0xa78d50: DecompressPointer r2
    //     0xa78d50: add             x2, x2, HEAP, lsl #32
    // 0xa78d54: ldr             x1, [fp, #0x10]
    // 0xa78d58: b               #0xa78d10
    // 0xa78d5c: r0 = Null
    //     0xa78d5c: mov             x0, NULL
    // 0xa78d60: LeaveFrame
    //     0xa78d60: mov             SP, fp
    //     0xa78d64: ldp             fp, lr, [SP], #0x10
    // 0xa78d68: ret
    //     0xa78d68: ret             
    // 0xa78d6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa78d6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa78d70: b               #0xa78cd8
    // 0xa78d74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa78d74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa78d78: b               #0xa78d20
  }
  _ addChildrenToScene(/* No info */) {
    // ** addr: 0xa84130, size: 0xd8
    // 0xa84130: EnterFrame
    //     0xa84130: stp             fp, lr, [SP, #-0x10]!
    //     0xa84134: mov             fp, SP
    // 0xa84138: AllocStack(0x8)
    //     0xa84138: sub             SP, SP, #8
    // 0xa8413c: CheckStackOverflow
    //     0xa8413c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa84140: cmp             SP, x16
    //     0xa84144: b.ls            #0xa841f8
    // 0xa84148: ldr             x0, [fp, #0x18]
    // 0xa8414c: LoadField: r1 = r0->field_3f
    //     0xa8414c: ldur            w1, [x0, #0x3f]
    // 0xa84150: DecompressPointer r1
    //     0xa84150: add             x1, x1, HEAP, lsl #32
    // 0xa84154: mov             x0, x1
    // 0xa84158: stur            x0, [fp, #-8]
    // 0xa8415c: CheckStackOverflow
    //     0xa8415c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa84160: cmp             SP, x16
    //     0xa84164: b.ls            #0xa84200
    // 0xa84168: cmp             w0, NULL
    // 0xa8416c: b.eq            #0xa841e8
    // 0xa84170: LoadField: r1 = r0->field_2f
    //     0xa84170: ldur            w1, [x0, #0x2f]
    // 0xa84174: DecompressPointer r1
    //     0xa84174: add             x1, x1, HEAP, lsl #32
    // 0xa84178: tbz             w1, #4, #0xa841a8
    // 0xa8417c: LoadField: r1 = r0->field_33
    //     0xa8417c: ldur            w1, [x0, #0x33]
    // 0xa84180: DecompressPointer r1
    //     0xa84180: add             x1, x1, HEAP, lsl #32
    // 0xa84184: cmp             w1, NULL
    // 0xa84188: b.eq            #0xa841a8
    // 0xa8418c: ldr             x16, [fp, #0x10]
    // 0xa84190: stp             x1, x16, [SP, #-0x10]!
    // 0xa84194: r0 = addRetained()
    //     0xa84194: bl              #0xa84208  ; [dart:ui] SceneBuilder::addRetained
    // 0xa84198: add             SP, SP, #0x10
    // 0xa8419c: ldur            x2, [fp, #-8]
    // 0xa841a0: r1 = false
    //     0xa841a0: add             x1, NULL, #0x30  ; false
    // 0xa841a4: b               #0xa841dc
    // 0xa841a8: ldur            x1, [fp, #-8]
    // 0xa841ac: r0 = LoadClassIdInstr(r1)
    //     0xa841ac: ldur            x0, [x1, #-1]
    //     0xa841b0: ubfx            x0, x0, #0xc, #0x14
    // 0xa841b4: ldr             x16, [fp, #0x10]
    // 0xa841b8: stp             x16, x1, [SP, #-0x10]!
    // 0xa841bc: r0 = GDT[cid_x0 + 0x7b71]()
    //     0xa841bc: mov             x17, #0x7b71
    //     0xa841c0: add             lr, x0, x17
    //     0xa841c4: ldr             lr, [x21, lr, lsl #3]
    //     0xa841c8: blr             lr
    // 0xa841cc: add             SP, SP, #0x10
    // 0xa841d0: ldur            x2, [fp, #-8]
    // 0xa841d4: r1 = false
    //     0xa841d4: add             x1, NULL, #0x30  ; false
    // 0xa841d8: StoreField: r2->field_2f = r1
    //     0xa841d8: stur            w1, [x2, #0x2f]
    // 0xa841dc: LoadField: r0 = r2->field_37
    //     0xa841dc: ldur            w0, [x2, #0x37]
    // 0xa841e0: DecompressPointer r0
    //     0xa841e0: add             x0, x0, HEAP, lsl #32
    // 0xa841e4: b               #0xa84158
    // 0xa841e8: r0 = Null
    //     0xa841e8: mov             x0, NULL
    // 0xa841ec: LeaveFrame
    //     0xa841ec: mov             SP, fp
    //     0xa841f0: ldp             fp, lr, [SP], #0x10
    // 0xa841f4: ret
    //     0xa841f4: ret             
    // 0xa841f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa841f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa841fc: b               #0xa84148
    // 0xa84200: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa84200: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa84204: b               #0xa84168
  }
  _ addToScene(/* No info */) {
    // ** addr: 0xa87604, size: 0x40
    // 0xa87604: EnterFrame
    //     0xa87604: stp             fp, lr, [SP, #-0x10]!
    //     0xa87608: mov             fp, SP
    // 0xa8760c: CheckStackOverflow
    //     0xa8760c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa87610: cmp             SP, x16
    //     0xa87614: b.ls            #0xa8763c
    // 0xa87618: ldr             x16, [fp, #0x18]
    // 0xa8761c: ldr             lr, [fp, #0x10]
    // 0xa87620: stp             lr, x16, [SP, #-0x10]!
    // 0xa87624: r0 = addChildrenToScene()
    //     0xa87624: bl              #0xa84130  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0xa87628: add             SP, SP, #0x10
    // 0xa8762c: r0 = Null
    //     0xa8762c: mov             x0, NULL
    // 0xa87630: LeaveFrame
    //     0xa87630: mov             SP, fp
    //     0xa87634: ldp             fp, lr, [SP], #0x10
    // 0xa87638: ret
    //     0xa87638: ret             
    // 0xa8763c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8763c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa87640: b               #0xa87618
  }
  _ findAnnotations(/* No info */) {
    // ** addr: 0xa8d380, size: 0x120
    // 0xa8d380: EnterFrame
    //     0xa8d380: stp             fp, lr, [SP, #-0x10]!
    //     0xa8d384: mov             fp, SP
    // 0xa8d388: AllocStack(0x18)
    //     0xa8d388: sub             SP, SP, #0x18
    // 0xa8d38c: SetupParameters()
    //     0xa8d38c: mov             x0, x4
    //     0xa8d390: ldur            w1, [x0, #0xf]
    //     0xa8d394: add             x1, x1, HEAP, lsl #32
    //     0xa8d398: cbnz            w1, #0xa8d3a4
    //     0xa8d39c: mov             x0, NULL
    //     0xa8d3a0: b               #0xa8d3b4
    //     0xa8d3a4: ldur            w2, [x0, #0x17]
    //     0xa8d3a8: add             x2, x2, HEAP, lsl #32
    //     0xa8d3ac: add             x0, fp, w2, sxtw #2
    //     0xa8d3b0: ldr             x0, [x0, #0x10]
    // 0xa8d3b4: CheckStackOverflow
    //     0xa8d3b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8d3b8: cmp             SP, x16
    //     0xa8d3bc: b.ls            #0xa8d490
    // 0xa8d3c0: cbnz            w1, #0xa8d3cc
    // 0xa8d3c4: r2 = <Object>
    //     0xa8d3c4: ldr             x2, [PP, #0x1d8]  ; [pp+0x1d8] TypeArguments: <Object>
    // 0xa8d3c8: b               #0xa8d3d0
    // 0xa8d3cc: mov             x2, x0
    // 0xa8d3d0: ldr             x0, [fp, #0x20]
    // 0xa8d3d4: ldr             x1, [fp, #0x18]
    // 0xa8d3d8: stur            x2, [fp, #-0x18]
    // 0xa8d3dc: LoadField: r3 = r0->field_43
    //     0xa8d3dc: ldur            w3, [x0, #0x43]
    // 0xa8d3e0: DecompressPointer r3
    //     0xa8d3e0: add             x3, x3, HEAP, lsl #32
    // 0xa8d3e4: LoadField: r4 = r1->field_b
    //     0xa8d3e4: ldur            w4, [x1, #0xb]
    // 0xa8d3e8: DecompressPointer r4
    //     0xa8d3e8: add             x4, x4, HEAP, lsl #32
    // 0xa8d3ec: stur            x4, [fp, #-0x10]
    // 0xa8d3f0: stur            x3, [fp, #-8]
    // 0xa8d3f4: CheckStackOverflow
    //     0xa8d3f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8d3f8: cmp             SP, x16
    //     0xa8d3fc: b.ls            #0xa8d498
    // 0xa8d400: cmp             w3, NULL
    // 0xa8d404: b.eq            #0xa8d480
    // 0xa8d408: r0 = LoadClassIdInstr(r3)
    //     0xa8d408: ldur            x0, [x3, #-1]
    //     0xa8d40c: ubfx            x0, x0, #0xc, #0x14
    // 0xa8d410: stp             x3, x2, [SP, #-0x10]!
    // 0xa8d414: ldr             x16, [fp, #0x10]
    // 0xa8d418: stp             x16, x1, [SP, #-0x10]!
    // 0xa8d41c: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xa8d41c: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xa8d420: r0 = GDT[cid_x0 + 0x631f]()
    //     0xa8d420: mov             x17, #0x631f
    //     0xa8d424: add             lr, x0, x17
    //     0xa8d428: ldr             lr, [x21, lr, lsl #3]
    //     0xa8d42c: blr             lr
    // 0xa8d430: add             SP, SP, #0x20
    // 0xa8d434: tbnz            w0, #4, #0xa8d448
    // 0xa8d438: r0 = true
    //     0xa8d438: add             x0, NULL, #0x20  ; true
    // 0xa8d43c: LeaveFrame
    //     0xa8d43c: mov             SP, fp
    //     0xa8d440: ldp             fp, lr, [SP], #0x10
    // 0xa8d444: ret
    //     0xa8d444: ret             
    // 0xa8d448: ldur            x1, [fp, #-0x10]
    // 0xa8d44c: LoadField: r2 = r1->field_b
    //     0xa8d44c: ldur            w2, [x1, #0xb]
    // 0xa8d450: DecompressPointer r2
    //     0xa8d450: add             x2, x2, HEAP, lsl #32
    // 0xa8d454: cbz             w2, #0xa8d464
    // 0xa8d458: LeaveFrame
    //     0xa8d458: mov             SP, fp
    //     0xa8d45c: ldp             fp, lr, [SP], #0x10
    // 0xa8d460: ret
    //     0xa8d460: ret             
    // 0xa8d464: ldur            x2, [fp, #-8]
    // 0xa8d468: LoadField: r3 = r2->field_3b
    //     0xa8d468: ldur            w3, [x2, #0x3b]
    // 0xa8d46c: DecompressPointer r3
    //     0xa8d46c: add             x3, x3, HEAP, lsl #32
    // 0xa8d470: mov             x4, x1
    // 0xa8d474: ldr             x1, [fp, #0x18]
    // 0xa8d478: ldur            x2, [fp, #-0x18]
    // 0xa8d47c: b               #0xa8d3f0
    // 0xa8d480: r0 = false
    //     0xa8d480: add             x0, NULL, #0x30  ; false
    // 0xa8d484: LeaveFrame
    //     0xa8d484: mov             SP, fp
    //     0xa8d488: ldp             fp, lr, [SP], #0x10
    // 0xa8d48c: ret
    //     0xa8d48c: ret             
    // 0xa8d490: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8d490: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8d494: b               #0xa8d3c0
    // 0xa8d498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8d498: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8d49c: b               #0xa8d400
  }
}

// class id: 2383, size: 0x5c, field offset: 0x48
class AnnotatedRegionLayer<X0> extends ContainerLayer {

  _ AnnotatedRegionLayer(/* No info */) {
    // ** addr: 0x6668fc, size: 0xb0
    // 0x6668fc: EnterFrame
    //     0x6668fc: stp             fp, lr, [SP, #-0x10]!
    //     0x666900: mov             fp, SP
    // 0x666904: r1 = false
    //     0x666904: add             x1, NULL, #0x30  ; false
    // 0x666908: CheckStackOverflow
    //     0x666908: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66690c: cmp             SP, x16
    //     0x666910: b.ls            #0x6669a4
    // 0x666914: ldr             x0, [fp, #0x20]
    // 0x666918: ldr             x2, [fp, #0x28]
    // 0x66691c: StoreField: r2->field_4b = r0
    //     0x66691c: stur            w0, [x2, #0x4b]
    //     0x666920: ldurb           w16, [x2, #-1]
    //     0x666924: ldurb           w17, [x0, #-1]
    //     0x666928: and             x16, x17, x16, lsr #2
    //     0x66692c: tst             x16, HEAP, lsr #32
    //     0x666930: b.eq            #0x666938
    //     0x666934: bl              #0xd6828c
    // 0x666938: ldr             x0, [fp, #0x10]
    // 0x66693c: StoreField: r2->field_4f = r0
    //     0x66693c: stur            w0, [x2, #0x4f]
    //     0x666940: ldurb           w16, [x2, #-1]
    //     0x666944: ldurb           w17, [x0, #-1]
    //     0x666948: and             x16, x17, x16, lsr #2
    //     0x66694c: tst             x16, HEAP, lsr #32
    //     0x666950: b.eq            #0x666958
    //     0x666954: bl              #0xd6828c
    // 0x666958: StoreField: r2->field_57 = r1
    //     0x666958: stur            w1, [x2, #0x57]
    // 0x66695c: ldr             x0, [fp, #0x18]
    // 0x666960: cmp             w0, NULL
    // 0x666964: b.ne            #0x66696c
    // 0x666968: r0 = Instance_Offset
    //     0x666968: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x66696c: StoreField: r2->field_53 = r0
    //     0x66696c: stur            w0, [x2, #0x53]
    //     0x666970: ldurb           w16, [x2, #-1]
    //     0x666974: ldurb           w17, [x0, #-1]
    //     0x666978: and             x16, x17, x16, lsr #2
    //     0x66697c: tst             x16, HEAP, lsr #32
    //     0x666980: b.eq            #0x666988
    //     0x666984: bl              #0xd6828c
    // 0x666988: SaveReg r2
    //     0x666988: str             x2, [SP, #-8]!
    // 0x66698c: r0 = Layer()
    //     0x66698c: bl              #0x5bbe7c  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0x666990: add             SP, SP, #8
    // 0x666994: r0 = Null
    //     0x666994: mov             x0, NULL
    // 0x666998: LeaveFrame
    //     0x666998: mov             SP, fp
    //     0x66699c: ldp             fp, lr, [SP], #0x10
    // 0x6669a0: ret
    //     0x6669a0: ret             
    // 0x6669a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6669a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6669a8: b               #0x666914
  }
  _ findAnnotations(/* No info */) {
    // ** addr: 0xa8d050, size: 0x324
    // 0xa8d050: EnterFrame
    //     0xa8d050: stp             fp, lr, [SP, #-0x10]!
    //     0xa8d054: mov             fp, SP
    // 0xa8d058: AllocStack(0x30)
    //     0xa8d058: sub             SP, SP, #0x30
    // 0xa8d05c: SetupParameters()
    //     0xa8d05c: mov             x0, x4
    //     0xa8d060: ldur            w1, [x0, #0xf]
    //     0xa8d064: add             x1, x1, HEAP, lsl #32
    //     0xa8d068: cbnz            w1, #0xa8d074
    //     0xa8d06c: mov             x0, NULL
    //     0xa8d070: b               #0xa8d084
    //     0xa8d074: ldur            w2, [x0, #0x17]
    //     0xa8d078: add             x2, x2, HEAP, lsl #32
    //     0xa8d07c: add             x0, fp, w2, sxtw #2
    //     0xa8d080: ldr             x0, [x0, #0x10]
    // 0xa8d084: CheckStackOverflow
    //     0xa8d084: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8d088: cmp             SP, x16
    //     0xa8d08c: b.ls            #0xa8d368
    // 0xa8d090: cbnz            w1, #0xa8d09c
    // 0xa8d094: r1 = <Object>
    //     0xa8d094: ldr             x1, [PP, #0x1d8]  ; [pp+0x1d8] TypeArguments: <Object>
    // 0xa8d098: b               #0xa8d0a0
    // 0xa8d09c: mov             x1, x0
    // 0xa8d0a0: ldr             x0, [fp, #0x18]
    // 0xa8d0a4: stur            x1, [fp, #-8]
    // 0xa8d0a8: ldr             x16, [fp, #0x20]
    // 0xa8d0ac: stp             x16, x1, [SP, #-0x10]!
    // 0xa8d0b0: ldr             x16, [fp, #0x10]
    // 0xa8d0b4: stp             x16, x0, [SP, #-0x10]!
    // 0xa8d0b8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xa8d0b8: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xa8d0bc: r0 = findAnnotations()
    //     0xa8d0bc: bl              #0xa8d380  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::findAnnotations
    // 0xa8d0c0: add             SP, SP, #0x20
    // 0xa8d0c4: mov             x1, x0
    // 0xa8d0c8: ldr             x0, [fp, #0x18]
    // 0xa8d0cc: stur            x1, [fp, #-0x18]
    // 0xa8d0d0: LoadField: r2 = r0->field_b
    //     0xa8d0d0: ldur            w2, [x0, #0xb]
    // 0xa8d0d4: DecompressPointer r2
    //     0xa8d0d4: add             x2, x2, HEAP, lsl #32
    // 0xa8d0d8: stur            x2, [fp, #-0x10]
    // 0xa8d0dc: LoadField: r3 = r2->field_b
    //     0xa8d0dc: ldur            w3, [x2, #0xb]
    // 0xa8d0e0: DecompressPointer r3
    //     0xa8d0e0: add             x3, x3, HEAP, lsl #32
    // 0xa8d0e4: cbz             w3, #0xa8d0f8
    // 0xa8d0e8: mov             x0, x1
    // 0xa8d0ec: LeaveFrame
    //     0xa8d0ec: mov             SP, fp
    //     0xa8d0f0: ldp             fp, lr, [SP], #0x10
    // 0xa8d0f4: ret
    //     0xa8d0f4: ret             
    // 0xa8d0f8: ldr             x3, [fp, #0x20]
    // 0xa8d0fc: LoadField: r4 = r3->field_4f
    //     0xa8d0fc: ldur            w4, [x3, #0x4f]
    // 0xa8d100: DecompressPointer r4
    //     0xa8d100: add             x4, x4, HEAP, lsl #32
    // 0xa8d104: cmp             w4, NULL
    // 0xa8d108: b.eq            #0xa8d144
    // 0xa8d10c: LoadField: r5 = r3->field_53
    //     0xa8d10c: ldur            w5, [x3, #0x53]
    // 0xa8d110: DecompressPointer r5
    //     0xa8d110: add             x5, x5, HEAP, lsl #32
    // 0xa8d114: stp             x4, x5, [SP, #-0x10]!
    // 0xa8d118: r0 = &()
    //     0xa8d118: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0xa8d11c: add             SP, SP, #0x10
    // 0xa8d120: ldr             x16, [fp, #0x10]
    // 0xa8d124: stp             x16, x0, [SP, #-0x10]!
    // 0xa8d128: r0 = contains()
    //     0xa8d128: bl              #0x627548  ; [dart:ui] Rect::contains
    // 0xa8d12c: add             SP, SP, #0x10
    // 0xa8d130: tbz             w0, #4, #0xa8d144
    // 0xa8d134: ldur            x0, [fp, #-0x18]
    // 0xa8d138: LeaveFrame
    //     0xa8d138: mov             SP, fp
    //     0xa8d13c: ldp             fp, lr, [SP], #0x10
    // 0xa8d140: ret
    //     0xa8d140: ret             
    // 0xa8d144: ldr             x0, [fp, #0x20]
    // 0xa8d148: LoadField: r2 = r0->field_47
    //     0xa8d148: ldur            w2, [x0, #0x47]
    // 0xa8d14c: DecompressPointer r2
    //     0xa8d14c: add             x2, x2, HEAP, lsl #32
    // 0xa8d150: r1 = Null
    //     0xa8d150: mov             x1, NULL
    // 0xa8d154: r3 = X0
    //     0xa8d154: add             x3, PP, #0xe, lsl #12  ; [pp+0xe0c0] TypeParameter: X0
    //     0xa8d158: ldr             x3, [x3, #0xc0]
    // 0xa8d15c: r24 = InstantiateTypeNonNullableClassTypeParameterStub
    //     0xa8d15c: add             x24, PP, #0xd, lsl #12  ; [pp+0xd4a8] Stub: InstantiateTypeNonNullableClassTypeParameter (0x4ace18)
    //     0xa8d160: ldr             x24, [x24, #0x4a8]
    // 0xa8d164: LoadField: r30 = r24->field_7
    //     0xa8d164: ldur            lr, [x24, #7]
    // 0xa8d168: blr             lr
    // 0xa8d16c: ldur            x1, [fp, #-8]
    // 0xa8d170: r2 = Null
    //     0xa8d170: mov             x2, NULL
    // 0xa8d174: stur            x0, [fp, #-0x20]
    // 0xa8d178: r3 = Y0
    //     0xa8d178: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fe98] TypeParameter: Y0
    //     0xa8d17c: ldr             x3, [x3, #0xe98]
    // 0xa8d180: r24 = InstantiateTypeNonNullableFunctionTypeParameterStub
    //     0xa8d180: add             x24, PP, #0xd, lsl #12  ; [pp+0xd440] Stub: InstantiateTypeNonNullableFunctionTypeParameter (0x4accb4)
    //     0xa8d184: ldr             x24, [x24, #0x440]
    // 0xa8d188: LoadField: r30 = r24->field_7
    //     0xa8d188: ldur            lr, [x24, #7]
    // 0xa8d18c: blr             lr
    // 0xa8d190: mov             x1, x0
    // 0xa8d194: ldur            x0, [fp, #-0x20]
    // 0xa8d198: r2 = LoadClassIdInstr(r0)
    //     0xa8d198: ldur            x2, [x0, #-1]
    //     0xa8d19c: ubfx            x2, x2, #0xc, #0x14
    // 0xa8d1a0: stp             x1, x0, [SP, #-0x10]!
    // 0xa8d1a4: mov             x0, x2
    // 0xa8d1a8: mov             lr, x0
    // 0xa8d1ac: ldr             lr, [x21, lr, lsl #3]
    // 0xa8d1b0: blr             lr
    // 0xa8d1b4: add             SP, SP, #0x10
    // 0xa8d1b8: tbnz            w0, #4, #0xa8d358
    // 0xa8d1bc: ldur            x0, [fp, #-0x18]
    // 0xa8d1c0: tbnz            w0, #4, #0xa8d1cc
    // 0xa8d1c4: r6 = true
    //     0xa8d1c4: add             x6, NULL, #0x20  ; true
    // 0xa8d1c8: b               #0xa8d1d0
    // 0xa8d1cc: r6 = false
    //     0xa8d1cc: add             x6, NULL, #0x30  ; false
    // 0xa8d1d0: ldr             x3, [fp, #0x20]
    // 0xa8d1d4: ldr             x4, [fp, #0x18]
    // 0xa8d1d8: ldur            x5, [fp, #-0x10]
    // 0xa8d1dc: stur            x6, [fp, #-0x28]
    // 0xa8d1e0: LoadField: r7 = r3->field_4b
    //     0xa8d1e0: ldur            w7, [x3, #0x4b]
    // 0xa8d1e4: DecompressPointer r7
    //     0xa8d1e4: add             x7, x7, HEAP, lsl #32
    // 0xa8d1e8: mov             x0, x7
    // 0xa8d1ec: ldur            x1, [fp, #-8]
    // 0xa8d1f0: stur            x7, [fp, #-0x20]
    // 0xa8d1f4: r2 = Null
    //     0xa8d1f4: mov             x2, NULL
    // 0xa8d1f8: cmp             w1, NULL
    // 0xa8d1fc: b.eq            #0xa8d220
    // 0xa8d200: LoadField: r4 = r1->field_17
    //     0xa8d200: ldur            w4, [x1, #0x17]
    // 0xa8d204: DecompressPointer r4
    //     0xa8d204: add             x4, x4, HEAP, lsl #32
    // 0xa8d208: r8 = Y0
    //     0xa8d208: add             x8, PP, #0x4f, lsl #12  ; [pp+0x4fe98] TypeParameter: Y0
    //     0xa8d20c: ldr             x8, [x8, #0xe98]
    // 0xa8d210: LoadField: r9 = r4->field_7
    //     0xa8d210: ldur            x9, [x4, #7]
    // 0xa8d214: r3 = Null
    //     0xa8d214: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fea0] Null
    //     0xa8d218: ldr             x3, [x3, #0xea0]
    // 0xa8d21c: blr             x9
    // 0xa8d220: ldr             x0, [fp, #0x20]
    // 0xa8d224: LoadField: r1 = r0->field_53
    //     0xa8d224: ldur            w1, [x0, #0x53]
    // 0xa8d228: DecompressPointer r1
    //     0xa8d228: add             x1, x1, HEAP, lsl #32
    // 0xa8d22c: ldr             x16, [fp, #0x10]
    // 0xa8d230: stp             x1, x16, [SP, #-0x10]!
    // 0xa8d234: r0 = -()
    //     0xa8d234: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xa8d238: add             SP, SP, #0x10
    // 0xa8d23c: ldur            x1, [fp, #-8]
    // 0xa8d240: stur            x0, [fp, #-8]
    // 0xa8d244: r0 = AnnotationEntry()
    //     0xa8d244: bl              #0xa8d374  ; AllocateAnnotationEntryStub -> AnnotationEntry<X0> (size=0x14)
    // 0xa8d248: mov             x3, x0
    // 0xa8d24c: ldur            x0, [fp, #-0x20]
    // 0xa8d250: stur            x3, [fp, #-0x30]
    // 0xa8d254: StoreField: r3->field_b = r0
    //     0xa8d254: stur            w0, [x3, #0xb]
    // 0xa8d258: ldur            x0, [fp, #-8]
    // 0xa8d25c: StoreField: r3->field_f = r0
    //     0xa8d25c: stur            w0, [x3, #0xf]
    // 0xa8d260: ldr             x0, [fp, #0x18]
    // 0xa8d264: LoadField: r2 = r0->field_7
    //     0xa8d264: ldur            w2, [x0, #7]
    // 0xa8d268: DecompressPointer r2
    //     0xa8d268: add             x2, x2, HEAP, lsl #32
    // 0xa8d26c: mov             x0, x3
    // 0xa8d270: r1 = Null
    //     0xa8d270: mov             x1, NULL
    // 0xa8d274: r8 = AnnotationEntry<X0>
    //     0xa8d274: add             x8, PP, #0x4f, lsl #12  ; [pp+0x4feb0] Type: AnnotationEntry<X0>
    //     0xa8d278: ldr             x8, [x8, #0xeb0]
    // 0xa8d27c: LoadField: r9 = r8->field_7
    //     0xa8d27c: ldur            x9, [x8, #7]
    // 0xa8d280: r3 = Null
    //     0xa8d280: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4feb8] Null
    //     0xa8d284: ldr             x3, [x3, #0xeb8]
    // 0xa8d288: blr             x9
    // 0xa8d28c: ldur            x3, [fp, #-0x10]
    // 0xa8d290: LoadField: r2 = r3->field_7
    //     0xa8d290: ldur            w2, [x3, #7]
    // 0xa8d294: DecompressPointer r2
    //     0xa8d294: add             x2, x2, HEAP, lsl #32
    // 0xa8d298: ldur            x0, [fp, #-0x30]
    // 0xa8d29c: r1 = Null
    //     0xa8d29c: mov             x1, NULL
    // 0xa8d2a0: cmp             w2, NULL
    // 0xa8d2a4: b.eq            #0xa8d2c4
    // 0xa8d2a8: LoadField: r4 = r2->field_17
    //     0xa8d2a8: ldur            w4, [x2, #0x17]
    // 0xa8d2ac: DecompressPointer r4
    //     0xa8d2ac: add             x4, x4, HEAP, lsl #32
    // 0xa8d2b0: r8 = X0
    //     0xa8d2b0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa8d2b4: LoadField: r9 = r4->field_7
    //     0xa8d2b4: ldur            x9, [x4, #7]
    // 0xa8d2b8: r3 = Null
    //     0xa8d2b8: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fec8] Null
    //     0xa8d2bc: ldr             x3, [x3, #0xec8]
    // 0xa8d2c0: blr             x9
    // 0xa8d2c4: ldur            x0, [fp, #-0x10]
    // 0xa8d2c8: LoadField: r1 = r0->field_b
    //     0xa8d2c8: ldur            w1, [x0, #0xb]
    // 0xa8d2cc: DecompressPointer r1
    //     0xa8d2cc: add             x1, x1, HEAP, lsl #32
    // 0xa8d2d0: stur            x1, [fp, #-8]
    // 0xa8d2d4: LoadField: r2 = r0->field_f
    //     0xa8d2d4: ldur            w2, [x0, #0xf]
    // 0xa8d2d8: DecompressPointer r2
    //     0xa8d2d8: add             x2, x2, HEAP, lsl #32
    // 0xa8d2dc: LoadField: r3 = r2->field_b
    //     0xa8d2dc: ldur            w3, [x2, #0xb]
    // 0xa8d2e0: DecompressPointer r3
    //     0xa8d2e0: add             x3, x3, HEAP, lsl #32
    // 0xa8d2e4: cmp             w1, w3
    // 0xa8d2e8: b.ne            #0xa8d2f8
    // 0xa8d2ec: SaveReg r0
    //     0xa8d2ec: str             x0, [SP, #-8]!
    // 0xa8d2f0: r0 = _growToNextCapacity()
    //     0xa8d2f0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa8d2f4: add             SP, SP, #8
    // 0xa8d2f8: ldur            x2, [fp, #-0x10]
    // 0xa8d2fc: ldur            x3, [fp, #-8]
    // 0xa8d300: r4 = LoadInt32Instr(r3)
    //     0xa8d300: sbfx            x4, x3, #1, #0x1f
    // 0xa8d304: add             x0, x4, #1
    // 0xa8d308: lsl             x3, x0, #1
    // 0xa8d30c: StoreField: r2->field_b = r3
    //     0xa8d30c: stur            w3, [x2, #0xb]
    // 0xa8d310: mov             x1, x4
    // 0xa8d314: cmp             x1, x0
    // 0xa8d318: b.hs            #0xa8d370
    // 0xa8d31c: LoadField: r1 = r2->field_f
    //     0xa8d31c: ldur            w1, [x2, #0xf]
    // 0xa8d320: DecompressPointer r1
    //     0xa8d320: add             x1, x1, HEAP, lsl #32
    // 0xa8d324: ldur            x0, [fp, #-0x30]
    // 0xa8d328: ArrayStore: r1[r4] = r0  ; List_4
    //     0xa8d328: add             x25, x1, x4, lsl #2
    //     0xa8d32c: add             x25, x25, #0xf
    //     0xa8d330: str             w0, [x25]
    //     0xa8d334: tbz             w0, #0, #0xa8d350
    //     0xa8d338: ldurb           w16, [x1, #-1]
    //     0xa8d33c: ldurb           w17, [x0, #-1]
    //     0xa8d340: and             x16, x17, x16, lsr #2
    //     0xa8d344: tst             x16, HEAP, lsr #32
    //     0xa8d348: b.eq            #0xa8d350
    //     0xa8d34c: bl              #0xd67e5c
    // 0xa8d350: ldur            x0, [fp, #-0x28]
    // 0xa8d354: b               #0xa8d35c
    // 0xa8d358: ldur            x0, [fp, #-0x18]
    // 0xa8d35c: LeaveFrame
    //     0xa8d35c: mov             SP, fp
    //     0xa8d360: ldp             fp, lr, [SP], #0x10
    // 0xa8d364: ret
    //     0xa8d364: ret             
    // 0xa8d368: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8d368: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8d36c: b               #0xa8d090
    // 0xa8d370: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa8d370: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 2384, size: 0x68, field offset: 0x48
class FollowerLayer extends ContainerLayer {

  _ getLastTransform(/* No info */) {
    // ** addr: 0x627290, size: 0xf8
    // 0x627290: EnterFrame
    //     0x627290: stp             fp, lr, [SP, #-0x10]!
    //     0x627294: mov             fp, SP
    // 0x627298: AllocStack(0x8)
    //     0x627298: sub             SP, SP, #8
    // 0x62729c: CheckStackOverflow
    //     0x62729c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6272a0: cmp             SP, x16
    //     0x6272a4: b.ls            #0x62735c
    // 0x6272a8: ldr             x0, [fp, #0x10]
    // 0x6272ac: LoadField: r1 = r0->field_5b
    //     0x6272ac: ldur            w1, [x0, #0x5b]
    // 0x6272b0: DecompressPointer r1
    //     0x6272b0: add             x1, x1, HEAP, lsl #32
    // 0x6272b4: cmp             w1, NULL
    // 0x6272b8: b.ne            #0x6272cc
    // 0x6272bc: r0 = Null
    //     0x6272bc: mov             x0, NULL
    // 0x6272c0: LeaveFrame
    //     0x6272c0: mov             SP, fp
    //     0x6272c4: ldp             fp, lr, [SP], #0x10
    // 0x6272c8: ret
    //     0x6272c8: ret             
    // 0x6272cc: LoadField: r1 = r0->field_57
    //     0x6272cc: ldur            w1, [x0, #0x57]
    // 0x6272d0: DecompressPointer r1
    //     0x6272d0: add             x1, x1, HEAP, lsl #32
    // 0x6272d4: cmp             w1, NULL
    // 0x6272d8: b.eq            #0x627364
    // 0x6272dc: LoadField: d0 = r1->field_7
    //     0x6272dc: ldur            d0, [x1, #7]
    // 0x6272e0: fneg            d1, d0
    // 0x6272e4: LoadField: d0 = r1->field_f
    //     0x6272e4: ldur            d0, [x1, #0xf]
    // 0x6272e8: fneg            d2, d0
    // 0x6272ec: r1 = inline_Allocate_Double()
    //     0x6272ec: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x6272f0: add             x1, x1, #0x10
    //     0x6272f4: cmp             x2, x1
    //     0x6272f8: b.ls            #0x627368
    //     0x6272fc: str             x1, [THR, #0x60]  ; THR::top
    //     0x627300: sub             x1, x1, #0xf
    //     0x627304: mov             x2, #0xd108
    //     0x627308: movk            x2, #3, lsl #16
    //     0x62730c: stur            x2, [x1, #-1]
    // 0x627310: StoreField: r1->field_7 = d1
    //     0x627310: stur            d1, [x1, #7]
    // 0x627314: stp             x1, NULL, [SP, #-0x10]!
    // 0x627318: SaveReg d2
    //     0x627318: str             d2, [SP, #-8]!
    // 0x62731c: r0 = Matrix4.translationValues()
    //     0x62731c: bl              #0x6245d8  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.translationValues
    // 0x627320: add             SP, SP, #0x18
    // 0x627324: mov             x1, x0
    // 0x627328: ldr             x0, [fp, #0x10]
    // 0x62732c: stur            x1, [fp, #-8]
    // 0x627330: LoadField: r2 = r0->field_5b
    //     0x627330: ldur            w2, [x0, #0x5b]
    // 0x627334: DecompressPointer r2
    //     0x627334: add             x2, x2, HEAP, lsl #32
    // 0x627338: cmp             w2, NULL
    // 0x62733c: b.eq            #0x627384
    // 0x627340: stp             x2, x1, [SP, #-0x10]!
    // 0x627344: r0 = multiply()
    //     0x627344: bl              #0x625d1c  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0x627348: add             SP, SP, #0x10
    // 0x62734c: ldur            x0, [fp, #-8]
    // 0x627350: LeaveFrame
    //     0x627350: mov             SP, fp
    //     0x627354: ldp             fp, lr, [SP], #0x10
    // 0x627358: ret
    //     0x627358: ret             
    // 0x62735c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62735c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x627360: b               #0x6272a8
    // 0x627364: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x627364: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x627368: stp             q1, q2, [SP, #-0x20]!
    // 0x62736c: SaveReg r0
    //     0x62736c: str             x0, [SP, #-8]!
    // 0x627370: r0 = AllocateDouble()
    //     0x627370: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x627374: mov             x1, x0
    // 0x627378: RestoreReg r0
    //     0x627378: ldr             x0, [SP], #8
    // 0x62737c: ldp             q1, q2, [SP], #0x20
    // 0x627380: b               #0x627310
    // 0x627384: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x627384: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ addToScene(/* No info */) {
    // ** addr: 0xa86a2c, size: 0x28c
    // 0xa86a2c: EnterFrame
    //     0xa86a2c: stp             fp, lr, [SP, #-0x10]!
    //     0xa86a30: mov             fp, SP
    // 0xa86a34: AllocStack(0x10)
    //     0xa86a34: sub             SP, SP, #0x10
    // 0xa86a38: CheckStackOverflow
    //     0xa86a38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa86a3c: cmp             SP, x16
    //     0xa86a40: b.ls            #0xa86c94
    // 0xa86a44: ldr             x0, [fp, #0x18]
    // 0xa86a48: LoadField: r1 = r0->field_47
    //     0xa86a48: ldur            w1, [x0, #0x47]
    // 0xa86a4c: DecompressPointer r1
    //     0xa86a4c: add             x1, x1, HEAP, lsl #32
    // 0xa86a50: LoadField: r2 = r1->field_7
    //     0xa86a50: ldur            w2, [x1, #7]
    // 0xa86a54: DecompressPointer r2
    //     0xa86a54: add             x2, x2, HEAP, lsl #32
    // 0xa86a58: cmp             w2, NULL
    // 0xa86a5c: b.ne            #0xa86aa0
    // 0xa86a60: LoadField: r1 = r0->field_4b
    //     0xa86a60: ldur            w1, [x0, #0x4b]
    // 0xa86a64: DecompressPointer r1
    //     0xa86a64: add             x1, x1, HEAP, lsl #32
    // 0xa86a68: tbz             w1, #4, #0xa86a98
    // 0xa86a6c: r1 = true
    //     0xa86a6c: add             x1, NULL, #0x20  ; true
    // 0xa86a70: StoreField: r0->field_5b = rNULL
    //     0xa86a70: stur            NULL, [x0, #0x5b]
    // 0xa86a74: StoreField: r0->field_57 = rNULL
    //     0xa86a74: stur            NULL, [x0, #0x57]
    // 0xa86a78: StoreField: r0->field_63 = r1
    //     0xa86a78: stur            w1, [x0, #0x63]
    // 0xa86a7c: stp             NULL, x0, [SP, #-0x10]!
    // 0xa86a80: r0 = engineLayer=()
    //     0xa86a80: bl              #0x661300  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0xa86a84: add             SP, SP, #0x10
    // 0xa86a88: r0 = Null
    //     0xa86a88: mov             x0, NULL
    // 0xa86a8c: LeaveFrame
    //     0xa86a8c: mov             SP, fp
    //     0xa86a90: ldp             fp, lr, [SP], #0x10
    // 0xa86a94: ret
    //     0xa86a94: ret             
    // 0xa86a98: r1 = true
    //     0xa86a98: add             x1, NULL, #0x20  ; true
    // 0xa86a9c: b               #0xa86aa4
    // 0xa86aa0: r1 = true
    //     0xa86aa0: add             x1, NULL, #0x20  ; true
    // 0xa86aa4: SaveReg r0
    //     0xa86aa4: str             x0, [SP, #-8]!
    // 0xa86aa8: r0 = _establishTransform()
    //     0xa86aa8: bl              #0xa86cb8  ; [package:flutter/src/rendering/layer.dart] FollowerLayer::_establishTransform
    // 0xa86aac: add             SP, SP, #8
    // 0xa86ab0: ldr             x3, [fp, #0x18]
    // 0xa86ab4: LoadField: r1 = r3->field_5b
    //     0xa86ab4: ldur            w1, [x3, #0x5b]
    // 0xa86ab8: DecompressPointer r1
    //     0xa86ab8: add             x1, x1, HEAP, lsl #32
    // 0xa86abc: cmp             w1, NULL
    // 0xa86ac0: b.eq            #0xa86b88
    // 0xa86ac4: LoadField: r0 = r3->field_4f
    //     0xa86ac4: ldur            w0, [x3, #0x4f]
    // 0xa86ac8: DecompressPointer r0
    //     0xa86ac8: add             x0, x0, HEAP, lsl #32
    // 0xa86acc: StoreField: r3->field_57 = r0
    //     0xa86acc: stur            w0, [x3, #0x57]
    //     0xa86ad0: ldurb           w16, [x3, #-1]
    //     0xa86ad4: ldurb           w17, [x0, #-1]
    //     0xa86ad8: and             x16, x17, x16, lsr #2
    //     0xa86adc: tst             x16, HEAP, lsr #32
    //     0xa86ae0: b.eq            #0xa86ae8
    //     0xa86ae4: bl              #0xd682ac
    // 0xa86ae8: LoadField: r4 = r1->field_7
    //     0xa86ae8: ldur            w4, [x1, #7]
    // 0xa86aec: DecompressPointer r4
    //     0xa86aec: add             x4, x4, HEAP, lsl #32
    // 0xa86af0: stur            x4, [fp, #-0x10]
    // 0xa86af4: LoadField: r5 = r3->field_33
    //     0xa86af4: ldur            w5, [x3, #0x33]
    // 0xa86af8: DecompressPointer r5
    //     0xa86af8: add             x5, x5, HEAP, lsl #32
    // 0xa86afc: mov             x0, x5
    // 0xa86b00: stur            x5, [fp, #-8]
    // 0xa86b04: r2 = Null
    //     0xa86b04: mov             x2, NULL
    // 0xa86b08: r1 = Null
    //     0xa86b08: mov             x1, NULL
    // 0xa86b0c: r4 = LoadClassIdInstr(r0)
    //     0xa86b0c: ldur            x4, [x0, #-1]
    //     0xa86b10: ubfx            x4, x4, #0xc, #0x14
    // 0xa86b14: r17 = 5084
    //     0xa86b14: mov             x17, #0x13dc
    // 0xa86b18: cmp             x4, x17
    // 0xa86b1c: b.eq            #0xa86b30
    // 0xa86b20: r8 = TransformEngineLayer?
    //     0xa86b20: ldr             x8, [PP, #0x7450]  ; [pp+0x7450] Type: TransformEngineLayer?
    // 0xa86b24: r3 = Null
    //     0xa86b24: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b2a0] Null
    //     0xa86b28: ldr             x3, [x3, #0x2a0]
    // 0xa86b2c: r0 = DefaultNullableTypeTest()
    //     0xa86b2c: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xa86b30: ldr             x16, [fp, #0x10]
    // 0xa86b34: ldur            lr, [fp, #-0x10]
    // 0xa86b38: stp             lr, x16, [SP, #-0x10]!
    // 0xa86b3c: ldur            x16, [fp, #-8]
    // 0xa86b40: SaveReg r16
    //     0xa86b40: str             x16, [SP, #-8]!
    // 0xa86b44: r4 = const [0, 0x3, 0x3, 0x2, oldLayer, 0x2, null]
    //     0xa86b44: ldr             x4, [PP, #0x7468]  ; [pp+0x7468] List(7) [0, 0x3, 0x3, 0x2, "oldLayer", 0x2, Null]
    // 0xa86b48: r0 = pushTransform()
    //     0xa86b48: bl              #0x667fd4  ; [dart:ui] SceneBuilder::pushTransform
    // 0xa86b4c: add             SP, SP, #0x18
    // 0xa86b50: ldr             x16, [fp, #0x18]
    // 0xa86b54: stp             x0, x16, [SP, #-0x10]!
    // 0xa86b58: r0 = engineLayer=()
    //     0xa86b58: bl              #0x661300  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0xa86b5c: add             SP, SP, #0x10
    // 0xa86b60: ldr             x16, [fp, #0x18]
    // 0xa86b64: ldr             lr, [fp, #0x10]
    // 0xa86b68: stp             lr, x16, [SP, #-0x10]!
    // 0xa86b6c: r0 = addChildrenToScene()
    //     0xa86b6c: bl              #0xa84130  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0xa86b70: add             SP, SP, #0x10
    // 0xa86b74: ldr             x16, [fp, #0x10]
    // 0xa86b78: SaveReg r16
    //     0xa86b78: str             x16, [SP, #-8]!
    // 0xa86b7c: r0 = pop()
    //     0xa86b7c: bl              #0xa83f3c  ; [dart:ui] SceneBuilder::pop
    // 0xa86b80: add             SP, SP, #8
    // 0xa86b84: b               #0xa86c78
    // 0xa86b88: mov             x0, x3
    // 0xa86b8c: StoreField: r0->field_57 = rNULL
    //     0xa86b8c: stur            NULL, [x0, #0x57]
    // 0xa86b90: LoadField: r1 = r0->field_4f
    //     0xa86b90: ldur            w1, [x0, #0x4f]
    // 0xa86b94: DecompressPointer r1
    //     0xa86b94: add             x1, x1, HEAP, lsl #32
    // 0xa86b98: LoadField: d0 = r1->field_7
    //     0xa86b98: ldur            d0, [x1, #7]
    // 0xa86b9c: LoadField: d1 = r1->field_f
    //     0xa86b9c: ldur            d1, [x1, #0xf]
    // 0xa86ba0: r1 = inline_Allocate_Double()
    //     0xa86ba0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xa86ba4: add             x1, x1, #0x10
    //     0xa86ba8: cmp             x2, x1
    //     0xa86bac: b.ls            #0xa86c9c
    //     0xa86bb0: str             x1, [THR, #0x60]  ; THR::top
    //     0xa86bb4: sub             x1, x1, #0xf
    //     0xa86bb8: mov             x2, #0xd108
    //     0xa86bbc: movk            x2, #3, lsl #16
    //     0xa86bc0: stur            x2, [x1, #-1]
    // 0xa86bc4: StoreField: r1->field_7 = d0
    //     0xa86bc4: stur            d0, [x1, #7]
    // 0xa86bc8: stp             x1, NULL, [SP, #-0x10]!
    // 0xa86bcc: SaveReg d1
    //     0xa86bcc: str             d1, [SP, #-8]!
    // 0xa86bd0: r0 = Matrix4.translationValues()
    //     0xa86bd0: bl              #0x6245d8  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.translationValues
    // 0xa86bd4: add             SP, SP, #0x18
    // 0xa86bd8: LoadField: r3 = r0->field_7
    //     0xa86bd8: ldur            w3, [x0, #7]
    // 0xa86bdc: DecompressPointer r3
    //     0xa86bdc: add             x3, x3, HEAP, lsl #32
    // 0xa86be0: ldr             x4, [fp, #0x18]
    // 0xa86be4: stur            x3, [fp, #-0x10]
    // 0xa86be8: LoadField: r5 = r4->field_33
    //     0xa86be8: ldur            w5, [x4, #0x33]
    // 0xa86bec: DecompressPointer r5
    //     0xa86bec: add             x5, x5, HEAP, lsl #32
    // 0xa86bf0: mov             x0, x5
    // 0xa86bf4: stur            x5, [fp, #-8]
    // 0xa86bf8: r2 = Null
    //     0xa86bf8: mov             x2, NULL
    // 0xa86bfc: r1 = Null
    //     0xa86bfc: mov             x1, NULL
    // 0xa86c00: r4 = LoadClassIdInstr(r0)
    //     0xa86c00: ldur            x4, [x0, #-1]
    //     0xa86c04: ubfx            x4, x4, #0xc, #0x14
    // 0xa86c08: r17 = 5084
    //     0xa86c08: mov             x17, #0x13dc
    // 0xa86c0c: cmp             x4, x17
    // 0xa86c10: b.eq            #0xa86c24
    // 0xa86c14: r8 = TransformEngineLayer?
    //     0xa86c14: ldr             x8, [PP, #0x7450]  ; [pp+0x7450] Type: TransformEngineLayer?
    // 0xa86c18: r3 = Null
    //     0xa86c18: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b2b0] Null
    //     0xa86c1c: ldr             x3, [x3, #0x2b0]
    // 0xa86c20: r0 = DefaultNullableTypeTest()
    //     0xa86c20: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xa86c24: ldr             x16, [fp, #0x10]
    // 0xa86c28: ldur            lr, [fp, #-0x10]
    // 0xa86c2c: stp             lr, x16, [SP, #-0x10]!
    // 0xa86c30: ldur            x16, [fp, #-8]
    // 0xa86c34: SaveReg r16
    //     0xa86c34: str             x16, [SP, #-8]!
    // 0xa86c38: r4 = const [0, 0x3, 0x3, 0x2, oldLayer, 0x2, null]
    //     0xa86c38: ldr             x4, [PP, #0x7468]  ; [pp+0x7468] List(7) [0, 0x3, 0x3, 0x2, "oldLayer", 0x2, Null]
    // 0xa86c3c: r0 = pushTransform()
    //     0xa86c3c: bl              #0x667fd4  ; [dart:ui] SceneBuilder::pushTransform
    // 0xa86c40: add             SP, SP, #0x18
    // 0xa86c44: ldr             x16, [fp, #0x18]
    // 0xa86c48: stp             x0, x16, [SP, #-0x10]!
    // 0xa86c4c: r0 = engineLayer=()
    //     0xa86c4c: bl              #0x661300  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0xa86c50: add             SP, SP, #0x10
    // 0xa86c54: ldr             x16, [fp, #0x18]
    // 0xa86c58: ldr             lr, [fp, #0x10]
    // 0xa86c5c: stp             lr, x16, [SP, #-0x10]!
    // 0xa86c60: r0 = addChildrenToScene()
    //     0xa86c60: bl              #0xa84130  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0xa86c64: add             SP, SP, #0x10
    // 0xa86c68: ldr             x16, [fp, #0x10]
    // 0xa86c6c: SaveReg r16
    //     0xa86c6c: str             x16, [SP, #-8]!
    // 0xa86c70: r0 = pop()
    //     0xa86c70: bl              #0xa83f3c  ; [dart:ui] SceneBuilder::pop
    // 0xa86c74: add             SP, SP, #8
    // 0xa86c78: ldr             x1, [fp, #0x18]
    // 0xa86c7c: r2 = true
    //     0xa86c7c: add             x2, NULL, #0x20  ; true
    // 0xa86c80: StoreField: r1->field_63 = r2
    //     0xa86c80: stur            w2, [x1, #0x63]
    // 0xa86c84: r0 = Null
    //     0xa86c84: mov             x0, NULL
    // 0xa86c88: LeaveFrame
    //     0xa86c88: mov             SP, fp
    //     0xa86c8c: ldp             fp, lr, [SP], #0x10
    // 0xa86c90: ret
    //     0xa86c90: ret             
    // 0xa86c94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa86c94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa86c98: b               #0xa86a44
    // 0xa86c9c: stp             q0, q1, [SP, #-0x20]!
    // 0xa86ca0: SaveReg r0
    //     0xa86ca0: str             x0, [SP, #-8]!
    // 0xa86ca4: r0 = AllocateDouble()
    //     0xa86ca4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa86ca8: mov             x1, x0
    // 0xa86cac: RestoreReg r0
    //     0xa86cac: ldr             x0, [SP], #8
    // 0xa86cb0: ldp             q0, q1, [SP], #0x20
    // 0xa86cb4: b               #0xa86bc4
  }
  _ _establishTransform(/* No info */) {
    // ** addr: 0xa86cb8, size: 0x214
    // 0xa86cb8: EnterFrame
    //     0xa86cb8: stp             fp, lr, [SP, #-0x10]!
    //     0xa86cbc: mov             fp, SP
    // 0xa86cc0: AllocStack(0x20)
    //     0xa86cc0: sub             SP, SP, #0x20
    // 0xa86cc4: CheckStackOverflow
    //     0xa86cc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa86cc8: cmp             SP, x16
    //     0xa86ccc: b.ls            #0xa86ea8
    // 0xa86cd0: ldr             x0, [fp, #0x10]
    // 0xa86cd4: StoreField: r0->field_5b = rNULL
    //     0xa86cd4: stur            NULL, [x0, #0x5b]
    // 0xa86cd8: LoadField: r1 = r0->field_47
    //     0xa86cd8: ldur            w1, [x0, #0x47]
    // 0xa86cdc: DecompressPointer r1
    //     0xa86cdc: add             x1, x1, HEAP, lsl #32
    // 0xa86ce0: LoadField: r3 = r1->field_7
    //     0xa86ce0: ldur            w3, [x1, #7]
    // 0xa86ce4: DecompressPointer r3
    //     0xa86ce4: add             x3, x3, HEAP, lsl #32
    // 0xa86ce8: stur            x3, [fp, #-8]
    // 0xa86cec: cmp             w3, NULL
    // 0xa86cf0: b.ne            #0xa86d04
    // 0xa86cf4: r0 = Null
    //     0xa86cf4: mov             x0, NULL
    // 0xa86cf8: LeaveFrame
    //     0xa86cf8: mov             SP, fp
    //     0xa86cfc: ldp             fp, lr, [SP], #0x10
    // 0xa86d00: ret
    //     0xa86d00: ret             
    // 0xa86d04: r4 = 2
    //     0xa86d04: mov             x4, #2
    // 0xa86d08: mov             x2, x4
    // 0xa86d0c: r1 = Null
    //     0xa86d0c: mov             x1, NULL
    // 0xa86d10: r0 = AllocateArray()
    //     0xa86d10: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa86d14: mov             x2, x0
    // 0xa86d18: ldur            x0, [fp, #-8]
    // 0xa86d1c: stur            x2, [fp, #-0x10]
    // 0xa86d20: StoreField: r2->field_f = r0
    //     0xa86d20: stur            w0, [x2, #0xf]
    // 0xa86d24: r1 = <ContainerLayer>
    //     0xa86d24: ldr             x1, [PP, #0x4e18]  ; [pp+0x4e18] TypeArguments: <ContainerLayer>
    // 0xa86d28: r0 = AllocateGrowableArray()
    //     0xa86d28: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xa86d2c: mov             x3, x0
    // 0xa86d30: ldur            x0, [fp, #-0x10]
    // 0xa86d34: stur            x3, [fp, #-0x18]
    // 0xa86d38: StoreField: r3->field_f = r0
    //     0xa86d38: stur            w0, [x3, #0xf]
    // 0xa86d3c: r0 = 2
    //     0xa86d3c: mov             x0, #2
    // 0xa86d40: StoreField: r3->field_b = r0
    //     0xa86d40: stur            w0, [x3, #0xb]
    // 0xa86d44: mov             x2, x0
    // 0xa86d48: r1 = Null
    //     0xa86d48: mov             x1, NULL
    // 0xa86d4c: r0 = AllocateArray()
    //     0xa86d4c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa86d50: mov             x2, x0
    // 0xa86d54: ldr             x0, [fp, #0x10]
    // 0xa86d58: stur            x2, [fp, #-0x10]
    // 0xa86d5c: StoreField: r2->field_f = r0
    //     0xa86d5c: stur            w0, [x2, #0xf]
    // 0xa86d60: r1 = <ContainerLayer>
    //     0xa86d60: ldr             x1, [PP, #0x4e18]  ; [pp+0x4e18] TypeArguments: <ContainerLayer>
    // 0xa86d64: r0 = AllocateGrowableArray()
    //     0xa86d64: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xa86d68: mov             x1, x0
    // 0xa86d6c: ldur            x0, [fp, #-0x10]
    // 0xa86d70: stur            x1, [fp, #-0x20]
    // 0xa86d74: StoreField: r1->field_f = r0
    //     0xa86d74: stur            w0, [x1, #0xf]
    // 0xa86d78: r0 = 2
    //     0xa86d78: mov             x0, #2
    // 0xa86d7c: StoreField: r1->field_b = r0
    //     0xa86d7c: stur            w0, [x1, #0xb]
    // 0xa86d80: ldur            x16, [fp, #-8]
    // 0xa86d84: ldr             lr, [fp, #0x10]
    // 0xa86d88: stp             lr, x16, [SP, #-0x10]!
    // 0xa86d8c: ldur            x16, [fp, #-0x18]
    // 0xa86d90: stp             x1, x16, [SP, #-0x10]!
    // 0xa86d94: r0 = _pathsToCommonAncestor()
    //     0xa86d94: bl              #0xa86fd8  ; [package:flutter/src/rendering/layer.dart] FollowerLayer::_pathsToCommonAncestor
    // 0xa86d98: add             SP, SP, #0x20
    // 0xa86d9c: ldur            x16, [fp, #-0x18]
    // 0xa86da0: SaveReg r16
    //     0xa86da0: str             x16, [SP, #-8]!
    // 0xa86da4: r0 = _collectTransformForLayerChain()
    //     0xa86da4: bl              #0xa86ecc  ; [package:flutter/src/rendering/layer.dart] FollowerLayer::_collectTransformForLayerChain
    // 0xa86da8: add             SP, SP, #8
    // 0xa86dac: stur            x0, [fp, #-0x10]
    // 0xa86db0: ldur            x16, [fp, #-8]
    // 0xa86db4: stp             x0, x16, [SP, #-0x10]!
    // 0xa86db8: r0 = applyTransform()
    //     0xa86db8: bl              #0xbd4984  ; [package:flutter/src/rendering/layer.dart] LeaderLayer::applyTransform
    // 0xa86dbc: add             SP, SP, #0x10
    // 0xa86dc0: ldr             x0, [fp, #0x10]
    // 0xa86dc4: LoadField: r1 = r0->field_53
    //     0xa86dc4: ldur            w1, [x0, #0x53]
    // 0xa86dc8: DecompressPointer r1
    //     0xa86dc8: add             x1, x1, HEAP, lsl #32
    // 0xa86dcc: LoadField: d0 = r1->field_7
    //     0xa86dcc: ldur            d0, [x1, #7]
    // 0xa86dd0: LoadField: d1 = r1->field_f
    //     0xa86dd0: ldur            d1, [x1, #0xf]
    // 0xa86dd4: r1 = inline_Allocate_Double()
    //     0xa86dd4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xa86dd8: add             x1, x1, #0x10
    //     0xa86ddc: cmp             x2, x1
    //     0xa86de0: b.ls            #0xa86eb0
    //     0xa86de4: str             x1, [THR, #0x60]  ; THR::top
    //     0xa86de8: sub             x1, x1, #0xf
    //     0xa86dec: mov             x2, #0xd108
    //     0xa86df0: movk            x2, #3, lsl #16
    //     0xa86df4: stur            x2, [x1, #-1]
    // 0xa86df8: StoreField: r1->field_7 = d0
    //     0xa86df8: stur            d0, [x1, #7]
    // 0xa86dfc: ldur            x16, [fp, #-0x10]
    // 0xa86e00: stp             x1, x16, [SP, #-0x10]!
    // 0xa86e04: SaveReg d1
    //     0xa86e04: str             d1, [SP, #-8]!
    // 0xa86e08: r0 = translate()
    //     0xa86e08: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0xa86e0c: add             SP, SP, #0x18
    // 0xa86e10: ldur            x16, [fp, #-0x20]
    // 0xa86e14: SaveReg r16
    //     0xa86e14: str             x16, [SP, #-8]!
    // 0xa86e18: r0 = _collectTransformForLayerChain()
    //     0xa86e18: bl              #0xa86ecc  ; [package:flutter/src/rendering/layer.dart] FollowerLayer::_collectTransformForLayerChain
    // 0xa86e1c: add             SP, SP, #8
    // 0xa86e20: stur            x0, [fp, #-8]
    // 0xa86e24: SaveReg r0
    //     0xa86e24: str             x0, [SP, #-8]!
    // 0xa86e28: r0 = invert()
    //     0xa86e28: bl              #0x65d460  ; [package:vector_math/vector_math_64.dart] Matrix4::invert
    // 0xa86e2c: add             SP, SP, #8
    // 0xa86e30: mov             v1.16b, v0.16b
    // 0xa86e34: d0 = 0.000000
    //     0xa86e34: eor             v0.16b, v0.16b, v0.16b
    // 0xa86e38: fcmp            d1, d0
    // 0xa86e3c: b.vs            #0xa86e54
    // 0xa86e40: b.ne            #0xa86e54
    // 0xa86e44: r0 = Null
    //     0xa86e44: mov             x0, NULL
    // 0xa86e48: LeaveFrame
    //     0xa86e48: mov             SP, fp
    //     0xa86e4c: ldp             fp, lr, [SP], #0x10
    // 0xa86e50: ret
    //     0xa86e50: ret             
    // 0xa86e54: ldr             x0, [fp, #0x10]
    // 0xa86e58: ldur            x16, [fp, #-8]
    // 0xa86e5c: ldur            lr, [fp, #-0x10]
    // 0xa86e60: stp             lr, x16, [SP, #-0x10]!
    // 0xa86e64: r0 = multiply()
    //     0xa86e64: bl              #0x625d1c  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0xa86e68: add             SP, SP, #0x10
    // 0xa86e6c: ldur            x0, [fp, #-8]
    // 0xa86e70: ldr             x1, [fp, #0x10]
    // 0xa86e74: StoreField: r1->field_5b = r0
    //     0xa86e74: stur            w0, [x1, #0x5b]
    //     0xa86e78: ldurb           w16, [x1, #-1]
    //     0xa86e7c: ldurb           w17, [x0, #-1]
    //     0xa86e80: and             x16, x17, x16, lsr #2
    //     0xa86e84: tst             x16, HEAP, lsr #32
    //     0xa86e88: b.eq            #0xa86e90
    //     0xa86e8c: bl              #0xd6826c
    // 0xa86e90: r2 = true
    //     0xa86e90: add             x2, NULL, #0x20  ; true
    // 0xa86e94: StoreField: r1->field_63 = r2
    //     0xa86e94: stur            w2, [x1, #0x63]
    // 0xa86e98: r0 = Null
    //     0xa86e98: mov             x0, NULL
    // 0xa86e9c: LeaveFrame
    //     0xa86e9c: mov             SP, fp
    //     0xa86ea0: ldp             fp, lr, [SP], #0x10
    // 0xa86ea4: ret
    //     0xa86ea4: ret             
    // 0xa86ea8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa86ea8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa86eac: b               #0xa86cd0
    // 0xa86eb0: stp             q0, q1, [SP, #-0x20]!
    // 0xa86eb4: SaveReg r0
    //     0xa86eb4: str             x0, [SP, #-8]!
    // 0xa86eb8: r0 = AllocateDouble()
    //     0xa86eb8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa86ebc: mov             x1, x0
    // 0xa86ec0: RestoreReg r0
    //     0xa86ec0: ldr             x0, [SP], #8
    // 0xa86ec4: ldp             q0, q1, [SP], #0x20
    // 0xa86ec8: b               #0xa86df8
  }
  static _ _collectTransformForLayerChain(/* No info */) {
    // ** addr: 0xa86ecc, size: 0x10c
    // 0xa86ecc: EnterFrame
    //     0xa86ecc: stp             fp, lr, [SP, #-0x10]!
    //     0xa86ed0: mov             fp, SP
    // 0xa86ed4: AllocStack(0x10)
    //     0xa86ed4: sub             SP, SP, #0x10
    // 0xa86ed8: CheckStackOverflow
    //     0xa86ed8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa86edc: cmp             SP, x16
    //     0xa86ee0: b.ls            #0xa86fc0
    // 0xa86ee4: r0 = Matrix4()
    //     0xa86ee4: bl              #0x50ace8  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0xa86ee8: r4 = 32
    //     0xa86ee8: mov             x4, #0x20
    // 0xa86eec: stur            x0, [fp, #-8]
    // 0xa86ef0: r0 = AllocateFloat64Array()
    //     0xa86ef0: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0xa86ef4: mov             x1, x0
    // 0xa86ef8: ldur            x0, [fp, #-8]
    // 0xa86efc: StoreField: r0->field_7 = r1
    //     0xa86efc: stur            w1, [x0, #7]
    // 0xa86f00: SaveReg r0
    //     0xa86f00: str             x0, [SP, #-8]!
    // 0xa86f04: r0 = setIdentity()
    //     0xa86f04: bl              #0x50f090  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0xa86f08: add             SP, SP, #8
    // 0xa86f0c: ldr             x2, [fp, #0x10]
    // 0xa86f10: LoadField: r0 = r2->field_b
    //     0xa86f10: ldur            w0, [x2, #0xb]
    // 0xa86f14: DecompressPointer r0
    //     0xa86f14: add             x0, x0, HEAP, lsl #32
    // 0xa86f18: r1 = LoadInt32Instr(r0)
    //     0xa86f18: sbfx            x1, x0, #1, #0x1f
    // 0xa86f1c: sub             x0, x1, #1
    // 0xa86f20: mov             x3, x0
    // 0xa86f24: CheckStackOverflow
    //     0xa86f24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa86f28: cmp             SP, x16
    //     0xa86f2c: b.ls            #0xa86fc8
    // 0xa86f30: cmp             x3, #0
    // 0xa86f34: b.le            #0xa86fb0
    // 0xa86f38: LoadField: r0 = r2->field_b
    //     0xa86f38: ldur            w0, [x2, #0xb]
    // 0xa86f3c: DecompressPointer r0
    //     0xa86f3c: add             x0, x0, HEAP, lsl #32
    // 0xa86f40: r4 = LoadInt32Instr(r0)
    //     0xa86f40: sbfx            x4, x0, #1, #0x1f
    // 0xa86f44: mov             x0, x4
    // 0xa86f48: mov             x1, x3
    // 0xa86f4c: cmp             x1, x0
    // 0xa86f50: b.hs            #0xa86fd0
    // 0xa86f54: LoadField: r0 = r2->field_f
    //     0xa86f54: ldur            w0, [x2, #0xf]
    // 0xa86f58: DecompressPointer r0
    //     0xa86f58: add             x0, x0, HEAP, lsl #32
    // 0xa86f5c: ArrayLoad: r5 = r0[r3]  ; Unknown_4
    //     0xa86f5c: add             x16, x0, x3, lsl #2
    //     0xa86f60: ldur            w5, [x16, #0xf]
    // 0xa86f64: DecompressPointer r5
    //     0xa86f64: add             x5, x5, HEAP, lsl #32
    // 0xa86f68: sub             x6, x3, #1
    // 0xa86f6c: mov             x0, x4
    // 0xa86f70: mov             x1, x6
    // 0xa86f74: stur            x6, [fp, #-0x10]
    // 0xa86f78: cmp             x1, x0
    // 0xa86f7c: b.hs            #0xa86fd4
    // 0xa86f80: r0 = LoadClassIdInstr(r5)
    //     0xa86f80: ldur            x0, [x5, #-1]
    //     0xa86f84: ubfx            x0, x0, #0xc, #0x14
    // 0xa86f88: ldur            x16, [fp, #-8]
    // 0xa86f8c: stp             x16, x5, [SP, #-0x10]!
    // 0xa86f90: r0 = GDT[cid_x0 + 0x19a6]()
    //     0xa86f90: mov             x17, #0x19a6
    //     0xa86f94: add             lr, x0, x17
    //     0xa86f98: ldr             lr, [x21, lr, lsl #3]
    //     0xa86f9c: blr             lr
    // 0xa86fa0: add             SP, SP, #0x10
    // 0xa86fa4: ldur            x3, [fp, #-0x10]
    // 0xa86fa8: ldr             x2, [fp, #0x10]
    // 0xa86fac: b               #0xa86f24
    // 0xa86fb0: ldur            x0, [fp, #-8]
    // 0xa86fb4: LeaveFrame
    //     0xa86fb4: mov             SP, fp
    //     0xa86fb8: ldp             fp, lr, [SP], #0x10
    // 0xa86fbc: ret
    //     0xa86fbc: ret             
    // 0xa86fc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa86fc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa86fc4: b               #0xa86ee4
    // 0xa86fc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa86fc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa86fcc: b               #0xa86f30
    // 0xa86fd0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa86fd0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa86fd4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa86fd4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ _pathsToCommonAncestor(/* No info */) {
    // ** addr: 0xa86fd8, size: 0x62c
    // 0xa86fd8: EnterFrame
    //     0xa86fd8: stp             fp, lr, [SP, #-0x10]!
    //     0xa86fdc: mov             fp, SP
    // 0xa86fe0: AllocStack(0x10)
    //     0xa86fe0: sub             SP, SP, #0x10
    // 0xa86fe4: CheckStackOverflow
    //     0xa86fe4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa86fe8: cmp             SP, x16
    //     0xa86fec: b.ls            #0xa875ec
    // 0xa86ff0: ldr             x3, [fp, #0x28]
    // 0xa86ff4: cmp             w3, NULL
    // 0xa86ff8: b.eq            #0xa87008
    // 0xa86ffc: ldr             x4, [fp, #0x20]
    // 0xa87000: cmp             w4, NULL
    // 0xa87004: b.ne            #0xa87018
    // 0xa87008: r0 = Null
    //     0xa87008: mov             x0, NULL
    // 0xa8700c: LeaveFrame
    //     0xa8700c: mov             SP, fp
    //     0xa87010: ldp             fp, lr, [SP], #0x10
    // 0xa87014: ret
    //     0xa87014: ret             
    // 0xa87018: cmp             w3, w4
    // 0xa8701c: b.ne            #0xa87030
    // 0xa87020: mov             x0, x3
    // 0xa87024: LeaveFrame
    //     0xa87024: mov             SP, fp
    //     0xa87028: ldp             fp, lr, [SP], #0x10
    // 0xa8702c: ret
    //     0xa8702c: ret             
    // 0xa87030: LoadField: r0 = r3->field_7
    //     0xa87030: ldur            x0, [x3, #7]
    // 0xa87034: LoadField: r1 = r4->field_7
    //     0xa87034: ldur            x1, [x4, #7]
    // 0xa87038: cmp             x0, x1
    // 0xa8703c: b.ge            #0xa871b0
    // 0xa87040: ldr             x5, [fp, #0x10]
    // 0xa87044: LoadField: r6 = r4->field_13
    //     0xa87044: ldur            w6, [x4, #0x13]
    // 0xa87048: DecompressPointer r6
    //     0xa87048: add             x6, x6, HEAP, lsl #32
    // 0xa8704c: mov             x0, x6
    // 0xa87050: stur            x6, [fp, #-8]
    // 0xa87054: r2 = Null
    //     0xa87054: mov             x2, NULL
    // 0xa87058: r1 = Null
    //     0xa87058: mov             x1, NULL
    // 0xa8705c: r4 = LoadClassIdInstr(r0)
    //     0xa8705c: ldur            x4, [x0, #-1]
    //     0xa87060: ubfx            x4, x4, #0xc, #0x14
    // 0xa87064: sub             x4, x4, #0x94e
    // 0xa87068: cmp             x4, #0xb
    // 0xa8706c: b.ls            #0xa87080
    // 0xa87070: r8 = ContainerLayer?
    //     0xa87070: ldr             x8, [PP, #0x4ac0]  ; [pp+0x4ac0] Type: ContainerLayer?
    // 0xa87074: r3 = Null
    //     0xa87074: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b2c0] Null
    //     0xa87078: ldr             x3, [x3, #0x2c0]
    // 0xa8707c: r0 = DefaultNullableTypeTest()
    //     0xa8707c: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xa87080: ldr             x3, [fp, #0x10]
    // 0xa87084: LoadField: r2 = r3->field_7
    //     0xa87084: ldur            w2, [x3, #7]
    // 0xa87088: DecompressPointer r2
    //     0xa87088: add             x2, x2, HEAP, lsl #32
    // 0xa8708c: ldur            x0, [fp, #-8]
    // 0xa87090: r1 = Null
    //     0xa87090: mov             x1, NULL
    // 0xa87094: cmp             w2, NULL
    // 0xa87098: b.eq            #0xa870b8
    // 0xa8709c: LoadField: r4 = r2->field_17
    //     0xa8709c: ldur            w4, [x2, #0x17]
    // 0xa870a0: DecompressPointer r4
    //     0xa870a0: add             x4, x4, HEAP, lsl #32
    // 0xa870a4: r8 = X0
    //     0xa870a4: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa870a8: LoadField: r9 = r4->field_7
    //     0xa870a8: ldur            x9, [x4, #7]
    // 0xa870ac: r3 = Null
    //     0xa870ac: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b2d0] Null
    //     0xa870b0: ldr             x3, [x3, #0x2d0]
    // 0xa870b4: blr             x9
    // 0xa870b8: ldr             x0, [fp, #0x10]
    // 0xa870bc: LoadField: r1 = r0->field_b
    //     0xa870bc: ldur            w1, [x0, #0xb]
    // 0xa870c0: DecompressPointer r1
    //     0xa870c0: add             x1, x1, HEAP, lsl #32
    // 0xa870c4: stur            x1, [fp, #-0x10]
    // 0xa870c8: LoadField: r2 = r0->field_f
    //     0xa870c8: ldur            w2, [x0, #0xf]
    // 0xa870cc: DecompressPointer r2
    //     0xa870cc: add             x2, x2, HEAP, lsl #32
    // 0xa870d0: LoadField: r3 = r2->field_b
    //     0xa870d0: ldur            w3, [x2, #0xb]
    // 0xa870d4: DecompressPointer r3
    //     0xa870d4: add             x3, x3, HEAP, lsl #32
    // 0xa870d8: cmp             w1, w3
    // 0xa870dc: b.ne            #0xa870ec
    // 0xa870e0: SaveReg r0
    //     0xa870e0: str             x0, [SP, #-8]!
    // 0xa870e4: r0 = _growToNextCapacity()
    //     0xa870e4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa870e8: add             SP, SP, #8
    // 0xa870ec: ldr             x4, [fp, #0x20]
    // 0xa870f0: ldr             x3, [fp, #0x10]
    // 0xa870f4: ldur            x0, [fp, #-0x10]
    // 0xa870f8: r2 = LoadInt32Instr(r0)
    //     0xa870f8: sbfx            x2, x0, #1, #0x1f
    // 0xa870fc: add             x0, x2, #1
    // 0xa87100: lsl             x1, x0, #1
    // 0xa87104: StoreField: r3->field_b = r1
    //     0xa87104: stur            w1, [x3, #0xb]
    // 0xa87108: mov             x1, x2
    // 0xa8710c: cmp             x1, x0
    // 0xa87110: b.hs            #0xa875f4
    // 0xa87114: LoadField: r1 = r3->field_f
    //     0xa87114: ldur            w1, [x3, #0xf]
    // 0xa87118: DecompressPointer r1
    //     0xa87118: add             x1, x1, HEAP, lsl #32
    // 0xa8711c: ldur            x0, [fp, #-8]
    // 0xa87120: ArrayStore: r1[r2] = r0  ; List_4
    //     0xa87120: add             x25, x1, x2, lsl #2
    //     0xa87124: add             x25, x25, #0xf
    //     0xa87128: str             w0, [x25]
    //     0xa8712c: tbz             w0, #0, #0xa87148
    //     0xa87130: ldurb           w16, [x1, #-1]
    //     0xa87134: ldurb           w17, [x0, #-1]
    //     0xa87138: and             x16, x17, x16, lsr #2
    //     0xa8713c: tst             x16, HEAP, lsr #32
    //     0xa87140: b.eq            #0xa87148
    //     0xa87144: bl              #0xd67e5c
    // 0xa87148: LoadField: r5 = r4->field_13
    //     0xa87148: ldur            w5, [x4, #0x13]
    // 0xa8714c: DecompressPointer r5
    //     0xa8714c: add             x5, x5, HEAP, lsl #32
    // 0xa87150: mov             x0, x5
    // 0xa87154: stur            x5, [fp, #-8]
    // 0xa87158: r2 = Null
    //     0xa87158: mov             x2, NULL
    // 0xa8715c: r1 = Null
    //     0xa8715c: mov             x1, NULL
    // 0xa87160: r4 = LoadClassIdInstr(r0)
    //     0xa87160: ldur            x4, [x0, #-1]
    //     0xa87164: ubfx            x4, x4, #0xc, #0x14
    // 0xa87168: sub             x4, x4, #0x94e
    // 0xa8716c: cmp             x4, #0xb
    // 0xa87170: b.ls            #0xa87184
    // 0xa87174: r8 = ContainerLayer?
    //     0xa87174: ldr             x8, [PP, #0x4ac0]  ; [pp+0x4ac0] Type: ContainerLayer?
    // 0xa87178: r3 = Null
    //     0xa87178: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b2e0] Null
    //     0xa8717c: ldr             x3, [x3, #0x2e0]
    // 0xa87180: r0 = DefaultNullableTypeTest()
    //     0xa87180: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xa87184: ldr             x16, [fp, #0x28]
    // 0xa87188: ldur            lr, [fp, #-8]
    // 0xa8718c: stp             lr, x16, [SP, #-0x10]!
    // 0xa87190: ldr             x16, [fp, #0x18]
    // 0xa87194: ldr             lr, [fp, #0x10]
    // 0xa87198: stp             lr, x16, [SP, #-0x10]!
    // 0xa8719c: r0 = _pathsToCommonAncestor()
    //     0xa8719c: bl              #0xa86fd8  ; [package:flutter/src/rendering/layer.dart] FollowerLayer::_pathsToCommonAncestor
    // 0xa871a0: add             SP, SP, #0x20
    // 0xa871a4: LeaveFrame
    //     0xa871a4: mov             SP, fp
    //     0xa871a8: ldp             fp, lr, [SP], #0x10
    // 0xa871ac: ret
    //     0xa871ac: ret             
    // 0xa871b0: cmp             x0, x1
    // 0xa871b4: b.le            #0xa8732c
    // 0xa871b8: ldr             x3, [fp, #0x28]
    // 0xa871bc: ldr             x5, [fp, #0x18]
    // 0xa871c0: LoadField: r6 = r3->field_13
    //     0xa871c0: ldur            w6, [x3, #0x13]
    // 0xa871c4: DecompressPointer r6
    //     0xa871c4: add             x6, x6, HEAP, lsl #32
    // 0xa871c8: mov             x0, x6
    // 0xa871cc: stur            x6, [fp, #-8]
    // 0xa871d0: r2 = Null
    //     0xa871d0: mov             x2, NULL
    // 0xa871d4: r1 = Null
    //     0xa871d4: mov             x1, NULL
    // 0xa871d8: r4 = LoadClassIdInstr(r0)
    //     0xa871d8: ldur            x4, [x0, #-1]
    //     0xa871dc: ubfx            x4, x4, #0xc, #0x14
    // 0xa871e0: sub             x4, x4, #0x94e
    // 0xa871e4: cmp             x4, #0xb
    // 0xa871e8: b.ls            #0xa871fc
    // 0xa871ec: r8 = ContainerLayer?
    //     0xa871ec: ldr             x8, [PP, #0x4ac0]  ; [pp+0x4ac0] Type: ContainerLayer?
    // 0xa871f0: r3 = Null
    //     0xa871f0: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b2f0] Null
    //     0xa871f4: ldr             x3, [x3, #0x2f0]
    // 0xa871f8: r0 = DefaultNullableTypeTest()
    //     0xa871f8: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xa871fc: ldr             x3, [fp, #0x18]
    // 0xa87200: LoadField: r2 = r3->field_7
    //     0xa87200: ldur            w2, [x3, #7]
    // 0xa87204: DecompressPointer r2
    //     0xa87204: add             x2, x2, HEAP, lsl #32
    // 0xa87208: ldur            x0, [fp, #-8]
    // 0xa8720c: r1 = Null
    //     0xa8720c: mov             x1, NULL
    // 0xa87210: cmp             w2, NULL
    // 0xa87214: b.eq            #0xa87234
    // 0xa87218: LoadField: r4 = r2->field_17
    //     0xa87218: ldur            w4, [x2, #0x17]
    // 0xa8721c: DecompressPointer r4
    //     0xa8721c: add             x4, x4, HEAP, lsl #32
    // 0xa87220: r8 = X0
    //     0xa87220: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa87224: LoadField: r9 = r4->field_7
    //     0xa87224: ldur            x9, [x4, #7]
    // 0xa87228: r3 = Null
    //     0xa87228: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b300] Null
    //     0xa8722c: ldr             x3, [x3, #0x300]
    // 0xa87230: blr             x9
    // 0xa87234: ldr             x0, [fp, #0x18]
    // 0xa87238: LoadField: r1 = r0->field_b
    //     0xa87238: ldur            w1, [x0, #0xb]
    // 0xa8723c: DecompressPointer r1
    //     0xa8723c: add             x1, x1, HEAP, lsl #32
    // 0xa87240: stur            x1, [fp, #-0x10]
    // 0xa87244: LoadField: r2 = r0->field_f
    //     0xa87244: ldur            w2, [x0, #0xf]
    // 0xa87248: DecompressPointer r2
    //     0xa87248: add             x2, x2, HEAP, lsl #32
    // 0xa8724c: LoadField: r3 = r2->field_b
    //     0xa8724c: ldur            w3, [x2, #0xb]
    // 0xa87250: DecompressPointer r3
    //     0xa87250: add             x3, x3, HEAP, lsl #32
    // 0xa87254: cmp             w1, w3
    // 0xa87258: b.ne            #0xa87268
    // 0xa8725c: SaveReg r0
    //     0xa8725c: str             x0, [SP, #-8]!
    // 0xa87260: r0 = _growToNextCapacity()
    //     0xa87260: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa87264: add             SP, SP, #8
    // 0xa87268: ldr             x4, [fp, #0x28]
    // 0xa8726c: ldr             x3, [fp, #0x18]
    // 0xa87270: ldur            x0, [fp, #-0x10]
    // 0xa87274: r2 = LoadInt32Instr(r0)
    //     0xa87274: sbfx            x2, x0, #1, #0x1f
    // 0xa87278: add             x0, x2, #1
    // 0xa8727c: lsl             x1, x0, #1
    // 0xa87280: StoreField: r3->field_b = r1
    //     0xa87280: stur            w1, [x3, #0xb]
    // 0xa87284: mov             x1, x2
    // 0xa87288: cmp             x1, x0
    // 0xa8728c: b.hs            #0xa875f8
    // 0xa87290: LoadField: r1 = r3->field_f
    //     0xa87290: ldur            w1, [x3, #0xf]
    // 0xa87294: DecompressPointer r1
    //     0xa87294: add             x1, x1, HEAP, lsl #32
    // 0xa87298: ldur            x0, [fp, #-8]
    // 0xa8729c: ArrayStore: r1[r2] = r0  ; List_4
    //     0xa8729c: add             x25, x1, x2, lsl #2
    //     0xa872a0: add             x25, x25, #0xf
    //     0xa872a4: str             w0, [x25]
    //     0xa872a8: tbz             w0, #0, #0xa872c4
    //     0xa872ac: ldurb           w16, [x1, #-1]
    //     0xa872b0: ldurb           w17, [x0, #-1]
    //     0xa872b4: and             x16, x17, x16, lsr #2
    //     0xa872b8: tst             x16, HEAP, lsr #32
    //     0xa872bc: b.eq            #0xa872c4
    //     0xa872c0: bl              #0xd67e5c
    // 0xa872c4: LoadField: r5 = r4->field_13
    //     0xa872c4: ldur            w5, [x4, #0x13]
    // 0xa872c8: DecompressPointer r5
    //     0xa872c8: add             x5, x5, HEAP, lsl #32
    // 0xa872cc: mov             x0, x5
    // 0xa872d0: stur            x5, [fp, #-8]
    // 0xa872d4: r2 = Null
    //     0xa872d4: mov             x2, NULL
    // 0xa872d8: r1 = Null
    //     0xa872d8: mov             x1, NULL
    // 0xa872dc: r4 = LoadClassIdInstr(r0)
    //     0xa872dc: ldur            x4, [x0, #-1]
    //     0xa872e0: ubfx            x4, x4, #0xc, #0x14
    // 0xa872e4: sub             x4, x4, #0x94e
    // 0xa872e8: cmp             x4, #0xb
    // 0xa872ec: b.ls            #0xa87300
    // 0xa872f0: r8 = ContainerLayer?
    //     0xa872f0: ldr             x8, [PP, #0x4ac0]  ; [pp+0x4ac0] Type: ContainerLayer?
    // 0xa872f4: r3 = Null
    //     0xa872f4: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b310] Null
    //     0xa872f8: ldr             x3, [x3, #0x310]
    // 0xa872fc: r0 = DefaultNullableTypeTest()
    //     0xa872fc: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xa87300: ldur            x16, [fp, #-8]
    // 0xa87304: ldr             lr, [fp, #0x20]
    // 0xa87308: stp             lr, x16, [SP, #-0x10]!
    // 0xa8730c: ldr             x16, [fp, #0x18]
    // 0xa87310: ldr             lr, [fp, #0x10]
    // 0xa87314: stp             lr, x16, [SP, #-0x10]!
    // 0xa87318: r0 = _pathsToCommonAncestor()
    //     0xa87318: bl              #0xa86fd8  ; [package:flutter/src/rendering/layer.dart] FollowerLayer::_pathsToCommonAncestor
    // 0xa8731c: add             SP, SP, #0x20
    // 0xa87320: LeaveFrame
    //     0xa87320: mov             SP, fp
    //     0xa87324: ldp             fp, lr, [SP], #0x10
    // 0xa87328: ret
    //     0xa87328: ret             
    // 0xa8732c: ldr             x4, [fp, #0x28]
    // 0xa87330: ldr             x3, [fp, #0x18]
    // 0xa87334: LoadField: r5 = r4->field_13
    //     0xa87334: ldur            w5, [x4, #0x13]
    // 0xa87338: DecompressPointer r5
    //     0xa87338: add             x5, x5, HEAP, lsl #32
    // 0xa8733c: mov             x0, x5
    // 0xa87340: stur            x5, [fp, #-8]
    // 0xa87344: r2 = Null
    //     0xa87344: mov             x2, NULL
    // 0xa87348: r1 = Null
    //     0xa87348: mov             x1, NULL
    // 0xa8734c: r4 = LoadClassIdInstr(r0)
    //     0xa8734c: ldur            x4, [x0, #-1]
    //     0xa87350: ubfx            x4, x4, #0xc, #0x14
    // 0xa87354: sub             x4, x4, #0x94e
    // 0xa87358: cmp             x4, #0xb
    // 0xa8735c: b.ls            #0xa87370
    // 0xa87360: r8 = ContainerLayer?
    //     0xa87360: ldr             x8, [PP, #0x4ac0]  ; [pp+0x4ac0] Type: ContainerLayer?
    // 0xa87364: r3 = Null
    //     0xa87364: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b320] Null
    //     0xa87368: ldr             x3, [x3, #0x320]
    // 0xa8736c: r0 = DefaultNullableTypeTest()
    //     0xa8736c: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xa87370: ldr             x3, [fp, #0x18]
    // 0xa87374: LoadField: r2 = r3->field_7
    //     0xa87374: ldur            w2, [x3, #7]
    // 0xa87378: DecompressPointer r2
    //     0xa87378: add             x2, x2, HEAP, lsl #32
    // 0xa8737c: ldur            x0, [fp, #-8]
    // 0xa87380: r1 = Null
    //     0xa87380: mov             x1, NULL
    // 0xa87384: cmp             w2, NULL
    // 0xa87388: b.eq            #0xa873a8
    // 0xa8738c: LoadField: r4 = r2->field_17
    //     0xa8738c: ldur            w4, [x2, #0x17]
    // 0xa87390: DecompressPointer r4
    //     0xa87390: add             x4, x4, HEAP, lsl #32
    // 0xa87394: r8 = X0
    //     0xa87394: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa87398: LoadField: r9 = r4->field_7
    //     0xa87398: ldur            x9, [x4, #7]
    // 0xa8739c: r3 = Null
    //     0xa8739c: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b330] Null
    //     0xa873a0: ldr             x3, [x3, #0x330]
    // 0xa873a4: blr             x9
    // 0xa873a8: ldr             x0, [fp, #0x18]
    // 0xa873ac: LoadField: r1 = r0->field_b
    //     0xa873ac: ldur            w1, [x0, #0xb]
    // 0xa873b0: DecompressPointer r1
    //     0xa873b0: add             x1, x1, HEAP, lsl #32
    // 0xa873b4: stur            x1, [fp, #-0x10]
    // 0xa873b8: LoadField: r2 = r0->field_f
    //     0xa873b8: ldur            w2, [x0, #0xf]
    // 0xa873bc: DecompressPointer r2
    //     0xa873bc: add             x2, x2, HEAP, lsl #32
    // 0xa873c0: LoadField: r3 = r2->field_b
    //     0xa873c0: ldur            w3, [x2, #0xb]
    // 0xa873c4: DecompressPointer r3
    //     0xa873c4: add             x3, x3, HEAP, lsl #32
    // 0xa873c8: cmp             w1, w3
    // 0xa873cc: b.ne            #0xa873dc
    // 0xa873d0: SaveReg r0
    //     0xa873d0: str             x0, [SP, #-8]!
    // 0xa873d4: r0 = _growToNextCapacity()
    //     0xa873d4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa873d8: add             SP, SP, #8
    // 0xa873dc: ldr             x4, [fp, #0x20]
    // 0xa873e0: ldr             x3, [fp, #0x18]
    // 0xa873e4: ldr             x5, [fp, #0x10]
    // 0xa873e8: ldur            x0, [fp, #-0x10]
    // 0xa873ec: r2 = LoadInt32Instr(r0)
    //     0xa873ec: sbfx            x2, x0, #1, #0x1f
    // 0xa873f0: add             x0, x2, #1
    // 0xa873f4: lsl             x1, x0, #1
    // 0xa873f8: StoreField: r3->field_b = r1
    //     0xa873f8: stur            w1, [x3, #0xb]
    // 0xa873fc: mov             x1, x2
    // 0xa87400: cmp             x1, x0
    // 0xa87404: b.hs            #0xa875fc
    // 0xa87408: LoadField: r1 = r3->field_f
    //     0xa87408: ldur            w1, [x3, #0xf]
    // 0xa8740c: DecompressPointer r1
    //     0xa8740c: add             x1, x1, HEAP, lsl #32
    // 0xa87410: ldur            x0, [fp, #-8]
    // 0xa87414: ArrayStore: r1[r2] = r0  ; List_4
    //     0xa87414: add             x25, x1, x2, lsl #2
    //     0xa87418: add             x25, x25, #0xf
    //     0xa8741c: str             w0, [x25]
    //     0xa87420: tbz             w0, #0, #0xa8743c
    //     0xa87424: ldurb           w16, [x1, #-1]
    //     0xa87428: ldurb           w17, [x0, #-1]
    //     0xa8742c: and             x16, x17, x16, lsr #2
    //     0xa87430: tst             x16, HEAP, lsr #32
    //     0xa87434: b.eq            #0xa8743c
    //     0xa87438: bl              #0xd67e5c
    // 0xa8743c: LoadField: r6 = r4->field_13
    //     0xa8743c: ldur            w6, [x4, #0x13]
    // 0xa87440: DecompressPointer r6
    //     0xa87440: add             x6, x6, HEAP, lsl #32
    // 0xa87444: mov             x0, x6
    // 0xa87448: stur            x6, [fp, #-8]
    // 0xa8744c: r2 = Null
    //     0xa8744c: mov             x2, NULL
    // 0xa87450: r1 = Null
    //     0xa87450: mov             x1, NULL
    // 0xa87454: r4 = LoadClassIdInstr(r0)
    //     0xa87454: ldur            x4, [x0, #-1]
    //     0xa87458: ubfx            x4, x4, #0xc, #0x14
    // 0xa8745c: sub             x4, x4, #0x94e
    // 0xa87460: cmp             x4, #0xb
    // 0xa87464: b.ls            #0xa87478
    // 0xa87468: r8 = ContainerLayer?
    //     0xa87468: ldr             x8, [PP, #0x4ac0]  ; [pp+0x4ac0] Type: ContainerLayer?
    // 0xa8746c: r3 = Null
    //     0xa8746c: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b340] Null
    //     0xa87470: ldr             x3, [x3, #0x340]
    // 0xa87474: r0 = DefaultNullableTypeTest()
    //     0xa87474: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xa87478: ldr             x3, [fp, #0x10]
    // 0xa8747c: LoadField: r2 = r3->field_7
    //     0xa8747c: ldur            w2, [x3, #7]
    // 0xa87480: DecompressPointer r2
    //     0xa87480: add             x2, x2, HEAP, lsl #32
    // 0xa87484: ldur            x0, [fp, #-8]
    // 0xa87488: r1 = Null
    //     0xa87488: mov             x1, NULL
    // 0xa8748c: cmp             w2, NULL
    // 0xa87490: b.eq            #0xa874b0
    // 0xa87494: LoadField: r4 = r2->field_17
    //     0xa87494: ldur            w4, [x2, #0x17]
    // 0xa87498: DecompressPointer r4
    //     0xa87498: add             x4, x4, HEAP, lsl #32
    // 0xa8749c: r8 = X0
    //     0xa8749c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa874a0: LoadField: r9 = r4->field_7
    //     0xa874a0: ldur            x9, [x4, #7]
    // 0xa874a4: r3 = Null
    //     0xa874a4: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b350] Null
    //     0xa874a8: ldr             x3, [x3, #0x350]
    // 0xa874ac: blr             x9
    // 0xa874b0: ldr             x0, [fp, #0x10]
    // 0xa874b4: LoadField: r1 = r0->field_b
    //     0xa874b4: ldur            w1, [x0, #0xb]
    // 0xa874b8: DecompressPointer r1
    //     0xa874b8: add             x1, x1, HEAP, lsl #32
    // 0xa874bc: stur            x1, [fp, #-0x10]
    // 0xa874c0: LoadField: r2 = r0->field_f
    //     0xa874c0: ldur            w2, [x0, #0xf]
    // 0xa874c4: DecompressPointer r2
    //     0xa874c4: add             x2, x2, HEAP, lsl #32
    // 0xa874c8: LoadField: r3 = r2->field_b
    //     0xa874c8: ldur            w3, [x2, #0xb]
    // 0xa874cc: DecompressPointer r3
    //     0xa874cc: add             x3, x3, HEAP, lsl #32
    // 0xa874d0: cmp             w1, w3
    // 0xa874d4: b.ne            #0xa874e4
    // 0xa874d8: SaveReg r0
    //     0xa874d8: str             x0, [SP, #-8]!
    // 0xa874dc: r0 = _growToNextCapacity()
    //     0xa874dc: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xa874e0: add             SP, SP, #8
    // 0xa874e4: ldr             x2, [fp, #0x28]
    // 0xa874e8: ldr             x4, [fp, #0x20]
    // 0xa874ec: ldr             x3, [fp, #0x10]
    // 0xa874f0: ldur            x0, [fp, #-0x10]
    // 0xa874f4: r5 = LoadInt32Instr(r0)
    //     0xa874f4: sbfx            x5, x0, #1, #0x1f
    // 0xa874f8: add             x0, x5, #1
    // 0xa874fc: lsl             x1, x0, #1
    // 0xa87500: StoreField: r3->field_b = r1
    //     0xa87500: stur            w1, [x3, #0xb]
    // 0xa87504: mov             x1, x5
    // 0xa87508: cmp             x1, x0
    // 0xa8750c: b.hs            #0xa87600
    // 0xa87510: LoadField: r1 = r3->field_f
    //     0xa87510: ldur            w1, [x3, #0xf]
    // 0xa87514: DecompressPointer r1
    //     0xa87514: add             x1, x1, HEAP, lsl #32
    // 0xa87518: ldur            x0, [fp, #-8]
    // 0xa8751c: ArrayStore: r1[r5] = r0  ; List_4
    //     0xa8751c: add             x25, x1, x5, lsl #2
    //     0xa87520: add             x25, x25, #0xf
    //     0xa87524: str             w0, [x25]
    //     0xa87528: tbz             w0, #0, #0xa87544
    //     0xa8752c: ldurb           w16, [x1, #-1]
    //     0xa87530: ldurb           w17, [x0, #-1]
    //     0xa87534: and             x16, x17, x16, lsr #2
    //     0xa87538: tst             x16, HEAP, lsr #32
    //     0xa8753c: b.eq            #0xa87544
    //     0xa87540: bl              #0xd67e5c
    // 0xa87544: LoadField: r5 = r2->field_13
    //     0xa87544: ldur            w5, [x2, #0x13]
    // 0xa87548: DecompressPointer r5
    //     0xa87548: add             x5, x5, HEAP, lsl #32
    // 0xa8754c: mov             x0, x5
    // 0xa87550: stur            x5, [fp, #-8]
    // 0xa87554: r2 = Null
    //     0xa87554: mov             x2, NULL
    // 0xa87558: r1 = Null
    //     0xa87558: mov             x1, NULL
    // 0xa8755c: r4 = LoadClassIdInstr(r0)
    //     0xa8755c: ldur            x4, [x0, #-1]
    //     0xa87560: ubfx            x4, x4, #0xc, #0x14
    // 0xa87564: sub             x4, x4, #0x94e
    // 0xa87568: cmp             x4, #0xb
    // 0xa8756c: b.ls            #0xa87580
    // 0xa87570: r8 = ContainerLayer?
    //     0xa87570: ldr             x8, [PP, #0x4ac0]  ; [pp+0x4ac0] Type: ContainerLayer?
    // 0xa87574: r3 = Null
    //     0xa87574: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b360] Null
    //     0xa87578: ldr             x3, [x3, #0x360]
    // 0xa8757c: r0 = DefaultNullableTypeTest()
    //     0xa8757c: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xa87580: ldr             x0, [fp, #0x20]
    // 0xa87584: LoadField: r3 = r0->field_13
    //     0xa87584: ldur            w3, [x0, #0x13]
    // 0xa87588: DecompressPointer r3
    //     0xa87588: add             x3, x3, HEAP, lsl #32
    // 0xa8758c: mov             x0, x3
    // 0xa87590: stur            x3, [fp, #-0x10]
    // 0xa87594: r2 = Null
    //     0xa87594: mov             x2, NULL
    // 0xa87598: r1 = Null
    //     0xa87598: mov             x1, NULL
    // 0xa8759c: r4 = LoadClassIdInstr(r0)
    //     0xa8759c: ldur            x4, [x0, #-1]
    //     0xa875a0: ubfx            x4, x4, #0xc, #0x14
    // 0xa875a4: sub             x4, x4, #0x94e
    // 0xa875a8: cmp             x4, #0xb
    // 0xa875ac: b.ls            #0xa875c0
    // 0xa875b0: r8 = ContainerLayer?
    //     0xa875b0: ldr             x8, [PP, #0x4ac0]  ; [pp+0x4ac0] Type: ContainerLayer?
    // 0xa875b4: r3 = Null
    //     0xa875b4: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b370] Null
    //     0xa875b8: ldr             x3, [x3, #0x370]
    // 0xa875bc: r0 = DefaultNullableTypeTest()
    //     0xa875bc: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xa875c0: ldur            x16, [fp, #-8]
    // 0xa875c4: ldur            lr, [fp, #-0x10]
    // 0xa875c8: stp             lr, x16, [SP, #-0x10]!
    // 0xa875cc: ldr             x16, [fp, #0x18]
    // 0xa875d0: ldr             lr, [fp, #0x10]
    // 0xa875d4: stp             lr, x16, [SP, #-0x10]!
    // 0xa875d8: r0 = _pathsToCommonAncestor()
    //     0xa875d8: bl              #0xa86fd8  ; [package:flutter/src/rendering/layer.dart] FollowerLayer::_pathsToCommonAncestor
    // 0xa875dc: add             SP, SP, #0x20
    // 0xa875e0: LeaveFrame
    //     0xa875e0: mov             SP, fp
    //     0xa875e4: ldp             fp, lr, [SP], #0x10
    // 0xa875e8: ret
    //     0xa875e8: ret             
    // 0xa875ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa875ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa875f0: b               #0xa86ff0
    // 0xa875f4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa875f4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa875f8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa875f8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa875fc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa875fc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa87600: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa87600: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ findAnnotations(/* No info */) {
    // ** addr: 0xa8cae8, size: 0x130
    // 0xa8cae8: EnterFrame
    //     0xa8cae8: stp             fp, lr, [SP, #-0x10]!
    //     0xa8caec: mov             fp, SP
    // 0xa8caf0: AllocStack(0x8)
    //     0xa8caf0: sub             SP, SP, #8
    // 0xa8caf4: SetupParameters()
    //     0xa8caf4: mov             x0, x4
    //     0xa8caf8: ldur            w1, [x0, #0xf]
    //     0xa8cafc: add             x1, x1, HEAP, lsl #32
    //     0xa8cb00: cbnz            w1, #0xa8cb0c
    //     0xa8cb04: mov             x0, NULL
    //     0xa8cb08: b               #0xa8cb1c
    //     0xa8cb0c: ldur            w2, [x0, #0x17]
    //     0xa8cb10: add             x2, x2, HEAP, lsl #32
    //     0xa8cb14: add             x0, fp, w2, sxtw #2
    //     0xa8cb18: ldr             x0, [x0, #0x10]
    // 0xa8cb1c: CheckStackOverflow
    //     0xa8cb1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8cb20: cmp             SP, x16
    //     0xa8cb24: b.ls            #0xa8cc10
    // 0xa8cb28: cbnz            w1, #0xa8cb34
    // 0xa8cb2c: r1 = <Object>
    //     0xa8cb2c: ldr             x1, [PP, #0x1d8]  ; [pp+0x1d8] TypeArguments: <Object>
    // 0xa8cb30: b               #0xa8cb38
    // 0xa8cb34: mov             x1, x0
    // 0xa8cb38: ldr             x0, [fp, #0x20]
    // 0xa8cb3c: stur            x1, [fp, #-8]
    // 0xa8cb40: LoadField: r2 = r0->field_47
    //     0xa8cb40: ldur            w2, [x0, #0x47]
    // 0xa8cb44: DecompressPointer r2
    //     0xa8cb44: add             x2, x2, HEAP, lsl #32
    // 0xa8cb48: LoadField: r3 = r2->field_7
    //     0xa8cb48: ldur            w3, [x2, #7]
    // 0xa8cb4c: DecompressPointer r3
    //     0xa8cb4c: add             x3, x3, HEAP, lsl #32
    // 0xa8cb50: cmp             w3, NULL
    // 0xa8cb54: b.ne            #0xa8cbb8
    // 0xa8cb58: LoadField: r2 = r0->field_4b
    //     0xa8cb58: ldur            w2, [x0, #0x4b]
    // 0xa8cb5c: DecompressPointer r2
    //     0xa8cb5c: add             x2, x2, HEAP, lsl #32
    // 0xa8cb60: tbnz            w2, #4, #0xa8cba8
    // 0xa8cb64: LoadField: r2 = r0->field_4f
    //     0xa8cb64: ldur            w2, [x0, #0x4f]
    // 0xa8cb68: DecompressPointer r2
    //     0xa8cb68: add             x2, x2, HEAP, lsl #32
    // 0xa8cb6c: ldr             x16, [fp, #0x10]
    // 0xa8cb70: stp             x2, x16, [SP, #-0x10]!
    // 0xa8cb74: r0 = -()
    //     0xa8cb74: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xa8cb78: add             SP, SP, #0x10
    // 0xa8cb7c: ldur            x16, [fp, #-8]
    // 0xa8cb80: ldr             lr, [fp, #0x20]
    // 0xa8cb84: stp             lr, x16, [SP, #-0x10]!
    // 0xa8cb88: ldr             x16, [fp, #0x18]
    // 0xa8cb8c: stp             x0, x16, [SP, #-0x10]!
    // 0xa8cb90: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xa8cb90: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xa8cb94: r0 = findAnnotations()
    //     0xa8cb94: bl              #0xa8d380  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::findAnnotations
    // 0xa8cb98: add             SP, SP, #0x20
    // 0xa8cb9c: LeaveFrame
    //     0xa8cb9c: mov             SP, fp
    //     0xa8cba0: ldp             fp, lr, [SP], #0x10
    // 0xa8cba4: ret
    //     0xa8cba4: ret             
    // 0xa8cba8: r0 = false
    //     0xa8cba8: add             x0, NULL, #0x30  ; false
    // 0xa8cbac: LeaveFrame
    //     0xa8cbac: mov             SP, fp
    //     0xa8cbb0: ldp             fp, lr, [SP], #0x10
    // 0xa8cbb4: ret
    //     0xa8cbb4: ret             
    // 0xa8cbb8: ldr             x16, [fp, #0x20]
    // 0xa8cbbc: ldr             lr, [fp, #0x10]
    // 0xa8cbc0: stp             lr, x16, [SP, #-0x10]!
    // 0xa8cbc4: r0 = _transformOffset()
    //     0xa8cbc4: bl              #0xa8cc18  ; [package:flutter/src/rendering/layer.dart] FollowerLayer::_transformOffset
    // 0xa8cbc8: add             SP, SP, #0x10
    // 0xa8cbcc: cmp             w0, NULL
    // 0xa8cbd0: b.ne            #0xa8cbe4
    // 0xa8cbd4: r0 = false
    //     0xa8cbd4: add             x0, NULL, #0x30  ; false
    // 0xa8cbd8: LeaveFrame
    //     0xa8cbd8: mov             SP, fp
    //     0xa8cbdc: ldp             fp, lr, [SP], #0x10
    // 0xa8cbe0: ret
    //     0xa8cbe0: ret             
    // 0xa8cbe4: ldur            x16, [fp, #-8]
    // 0xa8cbe8: ldr             lr, [fp, #0x20]
    // 0xa8cbec: stp             lr, x16, [SP, #-0x10]!
    // 0xa8cbf0: ldr             x16, [fp, #0x18]
    // 0xa8cbf4: stp             x0, x16, [SP, #-0x10]!
    // 0xa8cbf8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xa8cbf8: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xa8cbfc: r0 = findAnnotations()
    //     0xa8cbfc: bl              #0xa8d380  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::findAnnotations
    // 0xa8cc00: add             SP, SP, #0x20
    // 0xa8cc04: LeaveFrame
    //     0xa8cc04: mov             SP, fp
    //     0xa8cc08: ldp             fp, lr, [SP], #0x10
    // 0xa8cc0c: ret
    //     0xa8cc0c: ret             
    // 0xa8cc10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8cc10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8cc14: b               #0xa8cb28
  }
  _ _transformOffset(/* No info */) {
    // ** addr: 0xa8cc18, size: 0x208
    // 0xa8cc18: EnterFrame
    //     0xa8cc18: stp             fp, lr, [SP, #-0x10]!
    //     0xa8cc1c: mov             fp, SP
    // 0xa8cc20: AllocStack(0x10)
    //     0xa8cc20: sub             SP, SP, #0x10
    // 0xa8cc24: CheckStackOverflow
    //     0xa8cc24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8cc28: cmp             SP, x16
    //     0xa8cc2c: b.ls            #0xa8cdcc
    // 0xa8cc30: ldr             x0, [fp, #0x18]
    // 0xa8cc34: LoadField: r1 = r0->field_63
    //     0xa8cc34: ldur            w1, [x0, #0x63]
    // 0xa8cc38: DecompressPointer r1
    //     0xa8cc38: add             x1, x1, HEAP, lsl #32
    // 0xa8cc3c: tbnz            w1, #4, #0xa8cc8c
    // 0xa8cc40: SaveReg r0
    //     0xa8cc40: str             x0, [SP, #-8]!
    // 0xa8cc44: r0 = getLastTransform()
    //     0xa8cc44: bl              #0x627290  ; [package:flutter/src/rendering/layer.dart] FollowerLayer::getLastTransform
    // 0xa8cc48: add             SP, SP, #8
    // 0xa8cc4c: cmp             w0, NULL
    // 0xa8cc50: b.eq            #0xa8cdd4
    // 0xa8cc54: SaveReg r0
    //     0xa8cc54: str             x0, [SP, #-8]!
    // 0xa8cc58: r0 = tryInvert()
    //     0xa8cc58: bl              #0x623294  ; [package:vector_math/vector_math_64.dart] Matrix4::tryInvert
    // 0xa8cc5c: add             SP, SP, #8
    // 0xa8cc60: ldr             x1, [fp, #0x18]
    // 0xa8cc64: StoreField: r1->field_5f = r0
    //     0xa8cc64: stur            w0, [x1, #0x5f]
    //     0xa8cc68: ldurb           w16, [x1, #-1]
    //     0xa8cc6c: ldurb           w17, [x0, #-1]
    //     0xa8cc70: and             x16, x17, x16, lsr #2
    //     0xa8cc74: tst             x16, HEAP, lsr #32
    //     0xa8cc78: b.eq            #0xa8cc80
    //     0xa8cc7c: bl              #0xd6826c
    // 0xa8cc80: r0 = false
    //     0xa8cc80: add             x0, NULL, #0x30  ; false
    // 0xa8cc84: StoreField: r1->field_63 = r0
    //     0xa8cc84: stur            w0, [x1, #0x63]
    // 0xa8cc88: b               #0xa8cc90
    // 0xa8cc8c: mov             x1, x0
    // 0xa8cc90: LoadField: r0 = r1->field_5f
    //     0xa8cc90: ldur            w0, [x1, #0x5f]
    // 0xa8cc94: DecompressPointer r0
    //     0xa8cc94: add             x0, x0, HEAP, lsl #32
    // 0xa8cc98: cmp             w0, NULL
    // 0xa8cc9c: b.ne            #0xa8ccb0
    // 0xa8cca0: r0 = Null
    //     0xa8cca0: mov             x0, NULL
    // 0xa8cca4: LeaveFrame
    //     0xa8cca4: mov             SP, fp
    //     0xa8cca8: ldp             fp, lr, [SP], #0x10
    // 0xa8ccac: ret
    //     0xa8ccac: ret             
    // 0xa8ccb0: ldr             x0, [fp, #0x10]
    // 0xa8ccb4: d0 = 1.000000
    //     0xa8ccb4: fmov            d0, #1.00000000
    // 0xa8ccb8: LoadField: d1 = r0->field_7
    //     0xa8ccb8: ldur            d1, [x0, #7]
    // 0xa8ccbc: LoadField: d2 = r0->field_f
    //     0xa8ccbc: ldur            d2, [x0, #0xf]
    // 0xa8ccc0: r0 = inline_Allocate_Double()
    //     0xa8ccc0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xa8ccc4: add             x0, x0, #0x10
    //     0xa8ccc8: cmp             x2, x0
    //     0xa8cccc: b.ls            #0xa8cdd8
    //     0xa8ccd0: str             x0, [THR, #0x60]  ; THR::top
    //     0xa8ccd4: sub             x0, x0, #0xf
    //     0xa8ccd8: mov             x2, #0xd108
    //     0xa8ccdc: movk            x2, #3, lsl #16
    //     0xa8cce0: stur            x2, [x0, #-1]
    // 0xa8cce4: StoreField: r0->field_7 = d1
    //     0xa8cce4: stur            d1, [x0, #7]
    // 0xa8cce8: r2 = inline_Allocate_Double()
    //     0xa8cce8: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xa8ccec: add             x2, x2, #0x10
    //     0xa8ccf0: cmp             x3, x2
    //     0xa8ccf4: b.ls            #0xa8cdf8
    //     0xa8ccf8: str             x2, [THR, #0x60]  ; THR::top
    //     0xa8ccfc: sub             x2, x2, #0xf
    //     0xa8cd00: mov             x3, #0xd108
    //     0xa8cd04: movk            x3, #3, lsl #16
    //     0xa8cd08: stur            x3, [x2, #-1]
    // 0xa8cd0c: StoreField: r2->field_7 = d2
    //     0xa8cd0c: stur            d2, [x2, #7]
    // 0xa8cd10: stp             x0, NULL, [SP, #-0x10]!
    // 0xa8cd14: r16 = 0.000000
    //     0xa8cd14: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xa8cd18: stp             x16, x2, [SP, #-0x10]!
    // 0xa8cd1c: SaveReg d0
    //     0xa8cd1c: str             d0, [SP, #-8]!
    // 0xa8cd20: r0 = Vector4()
    //     0xa8cd20: bl              #0x623b34  ; [package:vector_math/vector_math_64.dart] Vector4::Vector4
    // 0xa8cd24: add             SP, SP, #0x28
    // 0xa8cd28: mov             x1, x0
    // 0xa8cd2c: ldr             x0, [fp, #0x18]
    // 0xa8cd30: LoadField: r2 = r0->field_5f
    //     0xa8cd30: ldur            w2, [x0, #0x5f]
    // 0xa8cd34: DecompressPointer r2
    //     0xa8cd34: add             x2, x2, HEAP, lsl #32
    // 0xa8cd38: cmp             w2, NULL
    // 0xa8cd3c: b.eq            #0xa8ce14
    // 0xa8cd40: stp             x1, x2, [SP, #-0x10]!
    // 0xa8cd44: r0 = transform()
    //     0xa8cd44: bl              #0xa8ce20  ; [package:vector_math/vector_math_64.dart] Matrix4::transform
    // 0xa8cd48: add             SP, SP, #0x10
    // 0xa8cd4c: LoadField: r2 = r0->field_7
    //     0xa8cd4c: ldur            w2, [x0, #7]
    // 0xa8cd50: DecompressPointer r2
    //     0xa8cd50: add             x2, x2, HEAP, lsl #32
    // 0xa8cd54: LoadField: r0 = r2->field_13
    //     0xa8cd54: ldur            w0, [x2, #0x13]
    // 0xa8cd58: DecompressPointer r0
    //     0xa8cd58: add             x0, x0, HEAP, lsl #32
    // 0xa8cd5c: r3 = LoadInt32Instr(r0)
    //     0xa8cd5c: sbfx            x3, x0, #1, #0x1f
    // 0xa8cd60: mov             x0, x3
    // 0xa8cd64: r1 = 0
    //     0xa8cd64: mov             x1, #0
    // 0xa8cd68: cmp             x1, x0
    // 0xa8cd6c: b.hs            #0xa8ce18
    // 0xa8cd70: LoadField: d0 = r2->field_17
    //     0xa8cd70: ldur            d0, [x2, #0x17]
    // 0xa8cd74: ldr             x0, [fp, #0x18]
    // 0xa8cd78: LoadField: r4 = r0->field_53
    //     0xa8cd78: ldur            w4, [x0, #0x53]
    // 0xa8cd7c: DecompressPointer r4
    //     0xa8cd7c: add             x4, x4, HEAP, lsl #32
    // 0xa8cd80: LoadField: d1 = r4->field_7
    //     0xa8cd80: ldur            d1, [x4, #7]
    // 0xa8cd84: fsub            d2, d0, d1
    // 0xa8cd88: mov             x0, x3
    // 0xa8cd8c: stur            d2, [fp, #-0x10]
    // 0xa8cd90: r1 = 1
    //     0xa8cd90: mov             x1, #1
    // 0xa8cd94: cmp             x1, x0
    // 0xa8cd98: b.hs            #0xa8ce1c
    // 0xa8cd9c: LoadField: d0 = r2->field_1f
    //     0xa8cd9c: ldur            d0, [x2, #0x1f]
    // 0xa8cda0: LoadField: d1 = r4->field_f
    //     0xa8cda0: ldur            d1, [x4, #0xf]
    // 0xa8cda4: fsub            d3, d0, d1
    // 0xa8cda8: stur            d3, [fp, #-8]
    // 0xa8cdac: r0 = Offset()
    //     0xa8cdac: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa8cdb0: ldur            d0, [fp, #-0x10]
    // 0xa8cdb4: StoreField: r0->field_7 = d0
    //     0xa8cdb4: stur            d0, [x0, #7]
    // 0xa8cdb8: ldur            d0, [fp, #-8]
    // 0xa8cdbc: StoreField: r0->field_f = d0
    //     0xa8cdbc: stur            d0, [x0, #0xf]
    // 0xa8cdc0: LeaveFrame
    //     0xa8cdc0: mov             SP, fp
    //     0xa8cdc4: ldp             fp, lr, [SP], #0x10
    // 0xa8cdc8: ret
    //     0xa8cdc8: ret             
    // 0xa8cdcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8cdcc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8cdd0: b               #0xa8cc30
    // 0xa8cdd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa8cdd4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa8cdd8: stp             q1, q2, [SP, #-0x20]!
    // 0xa8cddc: SaveReg d0
    //     0xa8cddc: str             q0, [SP, #-0x10]!
    // 0xa8cde0: SaveReg r1
    //     0xa8cde0: str             x1, [SP, #-8]!
    // 0xa8cde4: r0 = AllocateDouble()
    //     0xa8cde4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa8cde8: RestoreReg r1
    //     0xa8cde8: ldr             x1, [SP], #8
    // 0xa8cdec: RestoreReg d0
    //     0xa8cdec: ldr             q0, [SP], #0x10
    // 0xa8cdf0: ldp             q1, q2, [SP], #0x20
    // 0xa8cdf4: b               #0xa8cce4
    // 0xa8cdf8: stp             q0, q2, [SP, #-0x20]!
    // 0xa8cdfc: stp             x0, x1, [SP, #-0x10]!
    // 0xa8ce00: r0 = AllocateDouble()
    //     0xa8ce00: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa8ce04: mov             x2, x0
    // 0xa8ce08: ldp             x0, x1, [SP], #0x10
    // 0xa8ce0c: ldp             q0, q2, [SP], #0x20
    // 0xa8ce10: b               #0xa8cd0c
    // 0xa8ce14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa8ce14: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa8ce18: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa8ce18: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa8ce1c: r0 = RangeErrorSharedWithFPURegs()
    //     0xa8ce1c: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
  }
  _ applyTransform(/* No info */) {
    // ** addr: 0xbd4a30, size: 0xbc
    // 0xbd4a30: EnterFrame
    //     0xbd4a30: stp             fp, lr, [SP, #-0x10]!
    //     0xbd4a34: mov             fp, SP
    // 0xbd4a38: CheckStackOverflow
    //     0xbd4a38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd4a3c: cmp             SP, x16
    //     0xbd4a40: b.ls            #0xbd4ad4
    // 0xbd4a44: ldr             x0, [fp, #0x18]
    // 0xbd4a48: LoadField: r1 = r0->field_5b
    //     0xbd4a48: ldur            w1, [x0, #0x5b]
    // 0xbd4a4c: DecompressPointer r1
    //     0xbd4a4c: add             x1, x1, HEAP, lsl #32
    // 0xbd4a50: cmp             w1, NULL
    // 0xbd4a54: b.eq            #0xbd4a6c
    // 0xbd4a58: ldr             x16, [fp, #0x10]
    // 0xbd4a5c: stp             x1, x16, [SP, #-0x10]!
    // 0xbd4a60: r0 = multiply()
    //     0xbd4a60: bl              #0x625d1c  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0xbd4a64: add             SP, SP, #0x10
    // 0xbd4a68: b               #0xbd4ac4
    // 0xbd4a6c: LoadField: r1 = r0->field_4f
    //     0xbd4a6c: ldur            w1, [x0, #0x4f]
    // 0xbd4a70: DecompressPointer r1
    //     0xbd4a70: add             x1, x1, HEAP, lsl #32
    // 0xbd4a74: LoadField: d0 = r1->field_7
    //     0xbd4a74: ldur            d0, [x1, #7]
    // 0xbd4a78: LoadField: d1 = r1->field_f
    //     0xbd4a78: ldur            d1, [x1, #0xf]
    // 0xbd4a7c: r0 = inline_Allocate_Double()
    //     0xbd4a7c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbd4a80: add             x0, x0, #0x10
    //     0xbd4a84: cmp             x1, x0
    //     0xbd4a88: b.ls            #0xbd4adc
    //     0xbd4a8c: str             x0, [THR, #0x60]  ; THR::top
    //     0xbd4a90: sub             x0, x0, #0xf
    //     0xbd4a94: mov             x1, #0xd108
    //     0xbd4a98: movk            x1, #3, lsl #16
    //     0xbd4a9c: stur            x1, [x0, #-1]
    // 0xbd4aa0: StoreField: r0->field_7 = d0
    //     0xbd4aa0: stur            d0, [x0, #7]
    // 0xbd4aa4: stp             x0, NULL, [SP, #-0x10]!
    // 0xbd4aa8: SaveReg d1
    //     0xbd4aa8: str             d1, [SP, #-8]!
    // 0xbd4aac: r0 = Matrix4.translationValues()
    //     0xbd4aac: bl              #0x6245d8  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.translationValues
    // 0xbd4ab0: add             SP, SP, #0x18
    // 0xbd4ab4: ldr             x16, [fp, #0x10]
    // 0xbd4ab8: stp             x0, x16, [SP, #-0x10]!
    // 0xbd4abc: r0 = multiply()
    //     0xbd4abc: bl              #0x625d1c  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0xbd4ac0: add             SP, SP, #0x10
    // 0xbd4ac4: r0 = Null
    //     0xbd4ac4: mov             x0, NULL
    // 0xbd4ac8: LeaveFrame
    //     0xbd4ac8: mov             SP, fp
    //     0xbd4acc: ldp             fp, lr, [SP], #0x10
    // 0xbd4ad0: ret
    //     0xbd4ad0: ret             
    // 0xbd4ad4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd4ad4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd4ad8: b               #0xbd4a44
    // 0xbd4adc: stp             q0, q1, [SP, #-0x20]!
    // 0xbd4ae0: r0 = AllocateDouble()
    //     0xbd4ae0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbd4ae4: ldp             q0, q1, [SP], #0x20
    // 0xbd4ae8: b               #0xbd4aa0
  }
}

// class id: 2385, size: 0x50, field offset: 0x48
class LeaderLayer extends ContainerLayer {

  set _ offset=(/* No info */) {
    // ** addr: 0x6662d4, size: 0x8c
    // 0x6662d4: EnterFrame
    //     0x6662d4: stp             fp, lr, [SP, #-0x10]!
    //     0x6662d8: mov             fp, SP
    // 0x6662dc: CheckStackOverflow
    //     0x6662dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6662e0: cmp             SP, x16
    //     0x6662e4: b.ls            #0x666358
    // 0x6662e8: ldr             x0, [fp, #0x18]
    // 0x6662ec: LoadField: r1 = r0->field_4b
    //     0x6662ec: ldur            w1, [x0, #0x4b]
    // 0x6662f0: DecompressPointer r1
    //     0x6662f0: add             x1, x1, HEAP, lsl #32
    // 0x6662f4: ldr             x16, [fp, #0x10]
    // 0x6662f8: stp             x1, x16, [SP, #-0x10]!
    // 0x6662fc: r0 = ==()
    //     0x6662fc: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0x666300: add             SP, SP, #0x10
    // 0x666304: tbnz            w0, #4, #0x666318
    // 0x666308: r0 = Null
    //     0x666308: mov             x0, NULL
    // 0x66630c: LeaveFrame
    //     0x66630c: mov             SP, fp
    //     0x666310: ldp             fp, lr, [SP], #0x10
    // 0x666314: ret
    //     0x666314: ret             
    // 0x666318: ldr             x1, [fp, #0x18]
    // 0x66631c: ldr             x0, [fp, #0x10]
    // 0x666320: StoreField: r1->field_4b = r0
    //     0x666320: stur            w0, [x1, #0x4b]
    //     0x666324: ldurb           w16, [x1, #-1]
    //     0x666328: ldurb           w17, [x0, #-1]
    //     0x66632c: and             x16, x17, x16, lsr #2
    //     0x666330: tst             x16, HEAP, lsr #32
    //     0x666334: b.eq            #0x66633c
    //     0x666338: bl              #0xd6826c
    // 0x66633c: SaveReg r1
    //     0x66633c: str             x1, [SP, #-8]!
    // 0x666340: r0 = markNeedsAddToScene()
    //     0x666340: bl              #0x5dec74  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0x666344: add             SP, SP, #8
    // 0x666348: r0 = Null
    //     0x666348: mov             x0, NULL
    // 0x66634c: LeaveFrame
    //     0x66634c: mov             SP, fp
    //     0x666350: ldp             fp, lr, [SP], #0x10
    // 0x666354: ret
    //     0x666354: ret             
    // 0x666358: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x666358: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66635c: b               #0x6662e8
  }
  set _ link=(/* No info */) {
    // ** addr: 0x666360, size: 0xc0
    // 0x666360: EnterFrame
    //     0x666360: stp             fp, lr, [SP, #-0x10]!
    //     0x666364: mov             fp, SP
    // 0x666368: CheckStackOverflow
    //     0x666368: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66636c: cmp             SP, x16
    //     0x666370: b.ls            #0x666418
    // 0x666374: ldr             x0, [fp, #0x18]
    // 0x666378: LoadField: r1 = r0->field_47
    //     0x666378: ldur            w1, [x0, #0x47]
    // 0x66637c: DecompressPointer r1
    //     0x66637c: add             x1, x1, HEAP, lsl #32
    // 0x666380: ldr             x2, [fp, #0x10]
    // 0x666384: cmp             w1, w2
    // 0x666388: b.ne            #0x66639c
    // 0x66638c: r0 = Null
    //     0x66638c: mov             x0, NULL
    // 0x666390: LeaveFrame
    //     0x666390: mov             SP, fp
    //     0x666394: ldp             fp, lr, [SP], #0x10
    // 0x666398: ret
    //     0x666398: ret             
    // 0x66639c: LoadField: r3 = r0->field_f
    //     0x66639c: ldur            w3, [x0, #0xf]
    // 0x6663a0: DecompressPointer r3
    //     0x6663a0: add             x3, x3, HEAP, lsl #32
    // 0x6663a4: cmp             w3, NULL
    // 0x6663a8: b.eq            #0x6663e0
    // 0x6663ac: stp             x0, x1, [SP, #-0x10]!
    // 0x6663b0: r0 = _unregisterLeader()
    //     0x6663b0: bl              #0x666420  ; [package:flutter/src/rendering/layer.dart] LayerLink::_unregisterLeader
    // 0x6663b4: add             SP, SP, #0x10
    // 0x6663b8: ldr             x0, [fp, #0x18]
    // 0x6663bc: ldr             x1, [fp, #0x10]
    // 0x6663c0: StoreField: r1->field_7 = r0
    //     0x6663c0: stur            w0, [x1, #7]
    //     0x6663c4: ldurb           w16, [x1, #-1]
    //     0x6663c8: ldurb           w17, [x0, #-1]
    //     0x6663cc: and             x16, x17, x16, lsr #2
    //     0x6663d0: tst             x16, HEAP, lsr #32
    //     0x6663d4: b.eq            #0x6663dc
    //     0x6663d8: bl              #0xd6826c
    // 0x6663dc: b               #0x6663e4
    // 0x6663e0: mov             x1, x2
    // 0x6663e4: ldr             x2, [fp, #0x18]
    // 0x6663e8: mov             x0, x1
    // 0x6663ec: StoreField: r2->field_47 = r0
    //     0x6663ec: stur            w0, [x2, #0x47]
    //     0x6663f0: ldurb           w16, [x2, #-1]
    //     0x6663f4: ldurb           w17, [x0, #-1]
    //     0x6663f8: and             x16, x17, x16, lsr #2
    //     0x6663fc: tst             x16, HEAP, lsr #32
    //     0x666400: b.eq            #0x666408
    //     0x666404: bl              #0xd6828c
    // 0x666408: r0 = Null
    //     0x666408: mov             x0, NULL
    // 0x66640c: LeaveFrame
    //     0x66640c: mov             SP, fp
    //     0x666410: ldp             fp, lr, [SP], #0x10
    // 0x666414: ret
    //     0x666414: ret             
    // 0x666418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x666418: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66641c: b               #0x666374
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bf9bc, size: 0x68
    // 0x9bf9bc: EnterFrame
    //     0x9bf9bc: stp             fp, lr, [SP, #-0x10]!
    //     0x9bf9c0: mov             fp, SP
    // 0x9bf9c4: CheckStackOverflow
    //     0x9bf9c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bf9c8: cmp             SP, x16
    //     0x9bf9cc: b.ls            #0x9bfa1c
    // 0x9bf9d0: ldr             x16, [fp, #0x18]
    // 0x9bf9d4: ldr             lr, [fp, #0x10]
    // 0x9bf9d8: stp             lr, x16, [SP, #-0x10]!
    // 0x9bf9dc: r0 = attach()
    //     0x9bf9dc: bl              #0x9bfa24  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::attach
    // 0x9bf9e0: add             SP, SP, #0x10
    // 0x9bf9e4: ldr             x0, [fp, #0x18]
    // 0x9bf9e8: LoadField: r1 = r0->field_47
    //     0x9bf9e8: ldur            w1, [x0, #0x47]
    // 0x9bf9ec: DecompressPointer r1
    //     0x9bf9ec: add             x1, x1, HEAP, lsl #32
    // 0x9bf9f0: StoreField: r1->field_7 = r0
    //     0x9bf9f0: stur            w0, [x1, #7]
    //     0x9bf9f4: ldurb           w16, [x1, #-1]
    //     0x9bf9f8: ldurb           w17, [x0, #-1]
    //     0x9bf9fc: and             x16, x17, x16, lsr #2
    //     0x9bfa00: tst             x16, HEAP, lsr #32
    //     0x9bfa04: b.eq            #0x9bfa0c
    //     0x9bfa08: bl              #0xd6826c
    // 0x9bfa0c: r0 = Null
    //     0x9bfa0c: mov             x0, NULL
    // 0x9bfa10: LeaveFrame
    //     0x9bfa10: mov             SP, fp
    //     0x9bfa14: ldp             fp, lr, [SP], #0x10
    // 0x9bfa18: ret
    //     0x9bfa18: ret             
    // 0x9bfa1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bfa1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bfa20: b               #0x9bf9d0
  }
  _ detach(/* No info */) {
    // ** addr: 0xa6adf0, size: 0x54
    // 0xa6adf0: EnterFrame
    //     0xa6adf0: stp             fp, lr, [SP, #-0x10]!
    //     0xa6adf4: mov             fp, SP
    // 0xa6adf8: CheckStackOverflow
    //     0xa6adf8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6adfc: cmp             SP, x16
    //     0xa6ae00: b.ls            #0xa6ae3c
    // 0xa6ae04: ldr             x0, [fp, #0x10]
    // 0xa6ae08: LoadField: r1 = r0->field_47
    //     0xa6ae08: ldur            w1, [x0, #0x47]
    // 0xa6ae0c: DecompressPointer r1
    //     0xa6ae0c: add             x1, x1, HEAP, lsl #32
    // 0xa6ae10: stp             x0, x1, [SP, #-0x10]!
    // 0xa6ae14: r0 = _unregisterLeader()
    //     0xa6ae14: bl              #0x666420  ; [package:flutter/src/rendering/layer.dart] LayerLink::_unregisterLeader
    // 0xa6ae18: add             SP, SP, #0x10
    // 0xa6ae1c: ldr             x16, [fp, #0x10]
    // 0xa6ae20: SaveReg r16
    //     0xa6ae20: str             x16, [SP, #-8]!
    // 0xa6ae24: r0 = detach()
    //     0xa6ae24: bl              #0xa6ae44  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::detach
    // 0xa6ae28: add             SP, SP, #8
    // 0xa6ae2c: r0 = Null
    //     0xa6ae2c: mov             x0, NULL
    // 0xa6ae30: LeaveFrame
    //     0xa6ae30: mov             SP, fp
    //     0xa6ae34: ldp             fp, lr, [SP], #0x10
    // 0xa6ae38: ret
    //     0xa6ae38: ret             
    // 0xa6ae3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6ae3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6ae40: b               #0xa6ae04
  }
  _ addToScene(/* No info */) {
    // ** addr: 0xa868a0, size: 0x18c
    // 0xa868a0: EnterFrame
    //     0xa868a0: stp             fp, lr, [SP, #-0x10]!
    //     0xa868a4: mov             fp, SP
    // 0xa868a8: AllocStack(0x10)
    //     0xa868a8: sub             SP, SP, #0x10
    // 0xa868ac: CheckStackOverflow
    //     0xa868ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa868b0: cmp             SP, x16
    //     0xa868b4: b.ls            #0xa86a08
    // 0xa868b8: ldr             x0, [fp, #0x18]
    // 0xa868bc: LoadField: r1 = r0->field_4b
    //     0xa868bc: ldur            w1, [x0, #0x4b]
    // 0xa868c0: DecompressPointer r1
    //     0xa868c0: add             x1, x1, HEAP, lsl #32
    // 0xa868c4: r16 = Instance_Offset
    //     0xa868c4: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xa868c8: stp             x16, x1, [SP, #-0x10]!
    // 0xa868cc: r0 = ==()
    //     0xa868cc: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0xa868d0: add             SP, SP, #0x10
    // 0xa868d4: tbz             w0, #4, #0xa869a4
    // 0xa868d8: ldr             x0, [fp, #0x18]
    // 0xa868dc: LoadField: r1 = r0->field_4b
    //     0xa868dc: ldur            w1, [x0, #0x4b]
    // 0xa868e0: DecompressPointer r1
    //     0xa868e0: add             x1, x1, HEAP, lsl #32
    // 0xa868e4: LoadField: d0 = r1->field_7
    //     0xa868e4: ldur            d0, [x1, #7]
    // 0xa868e8: LoadField: d1 = r1->field_f
    //     0xa868e8: ldur            d1, [x1, #0xf]
    // 0xa868ec: r1 = inline_Allocate_Double()
    //     0xa868ec: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xa868f0: add             x1, x1, #0x10
    //     0xa868f4: cmp             x2, x1
    //     0xa868f8: b.ls            #0xa86a10
    //     0xa868fc: str             x1, [THR, #0x60]  ; THR::top
    //     0xa86900: sub             x1, x1, #0xf
    //     0xa86904: mov             x2, #0xd108
    //     0xa86908: movk            x2, #3, lsl #16
    //     0xa8690c: stur            x2, [x1, #-1]
    // 0xa86910: StoreField: r1->field_7 = d0
    //     0xa86910: stur            d0, [x1, #7]
    // 0xa86914: stp             x1, NULL, [SP, #-0x10]!
    // 0xa86918: SaveReg d1
    //     0xa86918: str             d1, [SP, #-8]!
    // 0xa8691c: r0 = Matrix4.translationValues()
    //     0xa8691c: bl              #0x6245d8  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.translationValues
    // 0xa86920: add             SP, SP, #0x18
    // 0xa86924: LoadField: r3 = r0->field_7
    //     0xa86924: ldur            w3, [x0, #7]
    // 0xa86928: DecompressPointer r3
    //     0xa86928: add             x3, x3, HEAP, lsl #32
    // 0xa8692c: ldr             x4, [fp, #0x18]
    // 0xa86930: stur            x3, [fp, #-0x10]
    // 0xa86934: LoadField: r5 = r4->field_33
    //     0xa86934: ldur            w5, [x4, #0x33]
    // 0xa86938: DecompressPointer r5
    //     0xa86938: add             x5, x5, HEAP, lsl #32
    // 0xa8693c: mov             x0, x5
    // 0xa86940: stur            x5, [fp, #-8]
    // 0xa86944: r2 = Null
    //     0xa86944: mov             x2, NULL
    // 0xa86948: r1 = Null
    //     0xa86948: mov             x1, NULL
    // 0xa8694c: r4 = LoadClassIdInstr(r0)
    //     0xa8694c: ldur            x4, [x0, #-1]
    //     0xa86950: ubfx            x4, x4, #0xc, #0x14
    // 0xa86954: r17 = 5084
    //     0xa86954: mov             x17, #0x13dc
    // 0xa86958: cmp             x4, x17
    // 0xa8695c: b.eq            #0xa86970
    // 0xa86960: r8 = TransformEngineLayer?
    //     0xa86960: ldr             x8, [PP, #0x7450]  ; [pp+0x7450] Type: TransformEngineLayer?
    // 0xa86964: r3 = Null
    //     0xa86964: add             x3, PP, #0x52, lsl #12  ; [pp+0x52ee8] Null
    //     0xa86968: ldr             x3, [x3, #0xee8]
    // 0xa8696c: r0 = DefaultNullableTypeTest()
    //     0xa8696c: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xa86970: ldr             x16, [fp, #0x10]
    // 0xa86974: ldur            lr, [fp, #-0x10]
    // 0xa86978: stp             lr, x16, [SP, #-0x10]!
    // 0xa8697c: ldur            x16, [fp, #-8]
    // 0xa86980: SaveReg r16
    //     0xa86980: str             x16, [SP, #-8]!
    // 0xa86984: r4 = const [0, 0x3, 0x3, 0x2, oldLayer, 0x2, null]
    //     0xa86984: ldr             x4, [PP, #0x7468]  ; [pp+0x7468] List(7) [0, 0x3, 0x3, 0x2, "oldLayer", 0x2, Null]
    // 0xa86988: r0 = pushTransform()
    //     0xa86988: bl              #0x667fd4  ; [dart:ui] SceneBuilder::pushTransform
    // 0xa8698c: add             SP, SP, #0x18
    // 0xa86990: ldr             x16, [fp, #0x18]
    // 0xa86994: stp             x0, x16, [SP, #-0x10]!
    // 0xa86998: r0 = engineLayer=()
    //     0xa86998: bl              #0x661300  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0xa8699c: add             SP, SP, #0x10
    // 0xa869a0: b               #0xa869b4
    // 0xa869a4: ldr             x16, [fp, #0x18]
    // 0xa869a8: stp             NULL, x16, [SP, #-0x10]!
    // 0xa869ac: r0 = engineLayer=()
    //     0xa869ac: bl              #0x661300  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0xa869b0: add             SP, SP, #0x10
    // 0xa869b4: ldr             x0, [fp, #0x18]
    // 0xa869b8: ldr             x16, [fp, #0x10]
    // 0xa869bc: stp             x16, x0, [SP, #-0x10]!
    // 0xa869c0: r0 = addChildrenToScene()
    //     0xa869c0: bl              #0xa84130  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0xa869c4: add             SP, SP, #0x10
    // 0xa869c8: ldr             x0, [fp, #0x18]
    // 0xa869cc: LoadField: r1 = r0->field_4b
    //     0xa869cc: ldur            w1, [x0, #0x4b]
    // 0xa869d0: DecompressPointer r1
    //     0xa869d0: add             x1, x1, HEAP, lsl #32
    // 0xa869d4: r16 = Instance_Offset
    //     0xa869d4: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xa869d8: stp             x16, x1, [SP, #-0x10]!
    // 0xa869dc: r0 = ==()
    //     0xa869dc: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0xa869e0: add             SP, SP, #0x10
    // 0xa869e4: tbz             w0, #4, #0xa869f8
    // 0xa869e8: ldr             x16, [fp, #0x10]
    // 0xa869ec: SaveReg r16
    //     0xa869ec: str             x16, [SP, #-8]!
    // 0xa869f0: r0 = pop()
    //     0xa869f0: bl              #0xa83f3c  ; [dart:ui] SceneBuilder::pop
    // 0xa869f4: add             SP, SP, #8
    // 0xa869f8: r0 = Null
    //     0xa869f8: mov             x0, NULL
    // 0xa869fc: LeaveFrame
    //     0xa869fc: mov             SP, fp
    //     0xa86a00: ldp             fp, lr, [SP], #0x10
    // 0xa86a04: ret
    //     0xa86a04: ret             
    // 0xa86a08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa86a08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa86a0c: b               #0xa868b8
    // 0xa86a10: stp             q0, q1, [SP, #-0x20]!
    // 0xa86a14: SaveReg r0
    //     0xa86a14: str             x0, [SP, #-8]!
    // 0xa86a18: r0 = AllocateDouble()
    //     0xa86a18: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa86a1c: mov             x1, x0
    // 0xa86a20: RestoreReg r0
    //     0xa86a20: ldr             x0, [SP], #8
    // 0xa86a24: ldp             q0, q1, [SP], #0x20
    // 0xa86a28: b               #0xa86910
  }
  _ findAnnotations(/* No info */) {
    // ** addr: 0xa8ca44, size: 0xa4
    // 0xa8ca44: EnterFrame
    //     0xa8ca44: stp             fp, lr, [SP, #-0x10]!
    //     0xa8ca48: mov             fp, SP
    // 0xa8ca4c: AllocStack(0x8)
    //     0xa8ca4c: sub             SP, SP, #8
    // 0xa8ca50: SetupParameters()
    //     0xa8ca50: mov             x0, x4
    //     0xa8ca54: ldur            w1, [x0, #0xf]
    //     0xa8ca58: add             x1, x1, HEAP, lsl #32
    //     0xa8ca5c: cbnz            w1, #0xa8ca68
    //     0xa8ca60: mov             x0, NULL
    //     0xa8ca64: b               #0xa8ca78
    //     0xa8ca68: ldur            w2, [x0, #0x17]
    //     0xa8ca6c: add             x2, x2, HEAP, lsl #32
    //     0xa8ca70: add             x0, fp, w2, sxtw #2
    //     0xa8ca74: ldr             x0, [x0, #0x10]
    // 0xa8ca78: CheckStackOverflow
    //     0xa8ca78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8ca7c: cmp             SP, x16
    //     0xa8ca80: b.ls            #0xa8cae0
    // 0xa8ca84: cbnz            w1, #0xa8ca90
    // 0xa8ca88: r1 = <Object>
    //     0xa8ca88: ldr             x1, [PP, #0x1d8]  ; [pp+0x1d8] TypeArguments: <Object>
    // 0xa8ca8c: b               #0xa8ca94
    // 0xa8ca90: mov             x1, x0
    // 0xa8ca94: ldr             x0, [fp, #0x20]
    // 0xa8ca98: stur            x1, [fp, #-8]
    // 0xa8ca9c: LoadField: r2 = r0->field_4b
    //     0xa8ca9c: ldur            w2, [x0, #0x4b]
    // 0xa8caa0: DecompressPointer r2
    //     0xa8caa0: add             x2, x2, HEAP, lsl #32
    // 0xa8caa4: ldr             x16, [fp, #0x10]
    // 0xa8caa8: stp             x2, x16, [SP, #-0x10]!
    // 0xa8caac: r0 = -()
    //     0xa8caac: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xa8cab0: add             SP, SP, #0x10
    // 0xa8cab4: ldur            x16, [fp, #-8]
    // 0xa8cab8: ldr             lr, [fp, #0x20]
    // 0xa8cabc: stp             lr, x16, [SP, #-0x10]!
    // 0xa8cac0: ldr             x16, [fp, #0x18]
    // 0xa8cac4: stp             x0, x16, [SP, #-0x10]!
    // 0xa8cac8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xa8cac8: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xa8cacc: r0 = findAnnotations()
    //     0xa8cacc: bl              #0xa8d380  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::findAnnotations
    // 0xa8cad0: add             SP, SP, #0x20
    // 0xa8cad4: LeaveFrame
    //     0xa8cad4: mov             SP, fp
    //     0xa8cad8: ldp             fp, lr, [SP], #0x10
    // 0xa8cadc: ret
    //     0xa8cadc: ret             
    // 0xa8cae0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8cae0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8cae4: b               #0xa8ca84
  }
  _ applyTransform(/* No info */) {
    // ** addr: 0xbd4984, size: 0xac
    // 0xbd4984: EnterFrame
    //     0xbd4984: stp             fp, lr, [SP, #-0x10]!
    //     0xbd4988: mov             fp, SP
    // 0xbd498c: CheckStackOverflow
    //     0xbd498c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd4990: cmp             SP, x16
    //     0xbd4994: b.ls            #0xbd4a18
    // 0xbd4998: ldr             x0, [fp, #0x18]
    // 0xbd499c: LoadField: r1 = r0->field_4b
    //     0xbd499c: ldur            w1, [x0, #0x4b]
    // 0xbd49a0: DecompressPointer r1
    //     0xbd49a0: add             x1, x1, HEAP, lsl #32
    // 0xbd49a4: r16 = Instance_Offset
    //     0xbd49a4: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xbd49a8: stp             x16, x1, [SP, #-0x10]!
    // 0xbd49ac: r0 = ==()
    //     0xbd49ac: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0xbd49b0: add             SP, SP, #0x10
    // 0xbd49b4: tbz             w0, #4, #0xbd4a08
    // 0xbd49b8: ldr             x0, [fp, #0x18]
    // 0xbd49bc: LoadField: r1 = r0->field_4b
    //     0xbd49bc: ldur            w1, [x0, #0x4b]
    // 0xbd49c0: DecompressPointer r1
    //     0xbd49c0: add             x1, x1, HEAP, lsl #32
    // 0xbd49c4: LoadField: d0 = r1->field_7
    //     0xbd49c4: ldur            d0, [x1, #7]
    // 0xbd49c8: LoadField: d1 = r1->field_f
    //     0xbd49c8: ldur            d1, [x1, #0xf]
    // 0xbd49cc: r0 = inline_Allocate_Double()
    //     0xbd49cc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbd49d0: add             x0, x0, #0x10
    //     0xbd49d4: cmp             x1, x0
    //     0xbd49d8: b.ls            #0xbd4a20
    //     0xbd49dc: str             x0, [THR, #0x60]  ; THR::top
    //     0xbd49e0: sub             x0, x0, #0xf
    //     0xbd49e4: mov             x1, #0xd108
    //     0xbd49e8: movk            x1, #3, lsl #16
    //     0xbd49ec: stur            x1, [x0, #-1]
    // 0xbd49f0: StoreField: r0->field_7 = d0
    //     0xbd49f0: stur            d0, [x0, #7]
    // 0xbd49f4: ldr             x16, [fp, #0x10]
    // 0xbd49f8: stp             x0, x16, [SP, #-0x10]!
    // 0xbd49fc: SaveReg d1
    //     0xbd49fc: str             d1, [SP, #-8]!
    // 0xbd4a00: r0 = translate()
    //     0xbd4a00: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0xbd4a04: add             SP, SP, #0x18
    // 0xbd4a08: r0 = Null
    //     0xbd4a08: mov             x0, NULL
    // 0xbd4a0c: LeaveFrame
    //     0xbd4a0c: mov             SP, fp
    //     0xbd4a10: ldp             fp, lr, [SP], #0x10
    // 0xbd4a14: ret
    //     0xbd4a14: ret             
    // 0xbd4a18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd4a18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd4a1c: b               #0xbd4998
    // 0xbd4a20: stp             q0, q1, [SP, #-0x20]!
    // 0xbd4a24: r0 = AllocateDouble()
    //     0xbd4a24: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbd4a28: ldp             q0, q1, [SP], #0x20
    // 0xbd4a2c: b               #0xbd49f0
  }
}

// class id: 2386, size: 0x50, field offset: 0x48
class BackdropFilterLayer extends ContainerLayer {

  set _ filter=(/* No info */) {
    // ** addr: 0x661904, size: 0x90
    // 0x661904: EnterFrame
    //     0x661904: stp             fp, lr, [SP, #-0x10]!
    //     0x661908: mov             fp, SP
    // 0x66190c: CheckStackOverflow
    //     0x66190c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x661910: cmp             SP, x16
    //     0x661914: b.ls            #0x66198c
    // 0x661918: ldr             x1, [fp, #0x18]
    // 0x66191c: LoadField: r0 = r1->field_47
    //     0x66191c: ldur            w0, [x1, #0x47]
    // 0x661920: DecompressPointer r0
    //     0x661920: add             x0, x0, HEAP, lsl #32
    // 0x661924: ldr             x2, [fp, #0x10]
    // 0x661928: r3 = LoadClassIdInstr(r2)
    //     0x661928: ldur            x3, [x2, #-1]
    //     0x66192c: ubfx            x3, x3, #0xc, #0x14
    // 0x661930: stp             x0, x2, [SP, #-0x10]!
    // 0x661934: mov             x0, x3
    // 0x661938: mov             lr, x0
    // 0x66193c: ldr             lr, [x21, lr, lsl #3]
    // 0x661940: blr             lr
    // 0x661944: add             SP, SP, #0x10
    // 0x661948: tbz             w0, #4, #0x66197c
    // 0x66194c: ldr             x1, [fp, #0x18]
    // 0x661950: ldr             x0, [fp, #0x10]
    // 0x661954: StoreField: r1->field_47 = r0
    //     0x661954: stur            w0, [x1, #0x47]
    //     0x661958: ldurb           w16, [x1, #-1]
    //     0x66195c: ldurb           w17, [x0, #-1]
    //     0x661960: and             x16, x17, x16, lsr #2
    //     0x661964: tst             x16, HEAP, lsr #32
    //     0x661968: b.eq            #0x661970
    //     0x66196c: bl              #0xd6826c
    // 0x661970: SaveReg r1
    //     0x661970: str             x1, [SP, #-8]!
    // 0x661974: r0 = markNeedsAddToScene()
    //     0x661974: bl              #0x5dec74  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0x661978: add             SP, SP, #8
    // 0x66197c: r0 = Null
    //     0x66197c: mov             x0, NULL
    // 0x661980: LeaveFrame
    //     0x661980: mov             SP, fp
    //     0x661984: ldp             fp, lr, [SP], #0x10
    // 0x661988: ret
    //     0x661988: ret             
    // 0x66198c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66198c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x661990: b               #0x661918
  }
  _ addToScene(/* No info */) {
    // ** addr: 0xa8633c, size: 0xdc
    // 0xa8633c: EnterFrame
    //     0xa8633c: stp             fp, lr, [SP, #-0x10]!
    //     0xa86340: mov             fp, SP
    // 0xa86344: AllocStack(0x10)
    //     0xa86344: sub             SP, SP, #0x10
    // 0xa86348: CheckStackOverflow
    //     0xa86348: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8634c: cmp             SP, x16
    //     0xa86350: b.ls            #0xa8640c
    // 0xa86354: ldr             x3, [fp, #0x18]
    // 0xa86358: LoadField: r4 = r3->field_47
    //     0xa86358: ldur            w4, [x3, #0x47]
    // 0xa8635c: DecompressPointer r4
    //     0xa8635c: add             x4, x4, HEAP, lsl #32
    // 0xa86360: stur            x4, [fp, #-0x10]
    // 0xa86364: cmp             w4, NULL
    // 0xa86368: b.eq            #0xa86414
    // 0xa8636c: LoadField: r5 = r3->field_33
    //     0xa8636c: ldur            w5, [x3, #0x33]
    // 0xa86370: DecompressPointer r5
    //     0xa86370: add             x5, x5, HEAP, lsl #32
    // 0xa86374: mov             x0, x5
    // 0xa86378: stur            x5, [fp, #-8]
    // 0xa8637c: r2 = Null
    //     0xa8637c: mov             x2, NULL
    // 0xa86380: r1 = Null
    //     0xa86380: mov             x1, NULL
    // 0xa86384: r4 = LoadClassIdInstr(r0)
    //     0xa86384: ldur            x4, [x0, #-1]
    //     0xa86388: ubfx            x4, x4, #0xc, #0x14
    // 0xa8638c: r17 = 5077
    //     0xa8638c: mov             x17, #0x13d5
    // 0xa86390: cmp             x4, x17
    // 0xa86394: b.eq            #0xa863ac
    // 0xa86398: r8 = BackdropFilterEngineLayer?
    //     0xa86398: add             x8, PP, #0x3f, lsl #12  ; [pp+0x3fd00] Type: BackdropFilterEngineLayer?
    //     0xa8639c: ldr             x8, [x8, #0xd00]
    // 0xa863a0: r3 = Null
    //     0xa863a0: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3fd08] Null
    //     0xa863a4: ldr             x3, [x3, #0xd08]
    // 0xa863a8: r0 = DefaultNullableTypeTest()
    //     0xa863a8: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xa863ac: ldr             x16, [fp, #0x10]
    // 0xa863b0: ldur            lr, [fp, #-0x10]
    // 0xa863b4: stp             lr, x16, [SP, #-0x10]!
    // 0xa863b8: ldur            x16, [fp, #-8]
    // 0xa863bc: SaveReg r16
    //     0xa863bc: str             x16, [SP, #-8]!
    // 0xa863c0: r0 = pushBackdropFilter()
    //     0xa863c0: bl              #0xa86418  ; [dart:ui] SceneBuilder::pushBackdropFilter
    // 0xa863c4: add             SP, SP, #0x18
    // 0xa863c8: ldr             x16, [fp, #0x18]
    // 0xa863cc: stp             x0, x16, [SP, #-0x10]!
    // 0xa863d0: r0 = engineLayer=()
    //     0xa863d0: bl              #0x661300  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0xa863d4: add             SP, SP, #0x10
    // 0xa863d8: ldr             x16, [fp, #0x18]
    // 0xa863dc: ldr             lr, [fp, #0x10]
    // 0xa863e0: stp             lr, x16, [SP, #-0x10]!
    // 0xa863e4: r0 = addChildrenToScene()
    //     0xa863e4: bl              #0xa84130  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0xa863e8: add             SP, SP, #0x10
    // 0xa863ec: ldr             x16, [fp, #0x10]
    // 0xa863f0: SaveReg r16
    //     0xa863f0: str             x16, [SP, #-8]!
    // 0xa863f4: r0 = pop()
    //     0xa863f4: bl              #0xa83f3c  ; [dart:ui] SceneBuilder::pop
    // 0xa863f8: add             SP, SP, #8
    // 0xa863fc: r0 = Null
    //     0xa863fc: mov             x0, NULL
    // 0xa86400: LeaveFrame
    //     0xa86400: mov             SP, fp
    //     0xa86404: ldp             fp, lr, [SP], #0x10
    // 0xa86408: ret
    //     0xa86408: ret             
    // 0xa8640c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8640c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa86410: b               #0xa86354
    // 0xa86414: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa86414: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2387, size: 0x50, field offset: 0x48
class ClipPathLayer extends ContainerLayer {

  set _ clipBehavior=(/* No info */) {
    // ** addr: 0x65bd50, size: 0x70
    // 0x65bd50: EnterFrame
    //     0x65bd50: stp             fp, lr, [SP, #-0x10]!
    //     0x65bd54: mov             fp, SP
    // 0x65bd58: CheckStackOverflow
    //     0x65bd58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65bd5c: cmp             SP, x16
    //     0x65bd60: b.ls            #0x65bdb8
    // 0x65bd64: ldr             x1, [fp, #0x18]
    // 0x65bd68: LoadField: r0 = r1->field_4b
    //     0x65bd68: ldur            w0, [x1, #0x4b]
    // 0x65bd6c: DecompressPointer r0
    //     0x65bd6c: add             x0, x0, HEAP, lsl #32
    // 0x65bd70: ldr             x2, [fp, #0x10]
    // 0x65bd74: cmp             w2, w0
    // 0x65bd78: b.eq            #0x65bda8
    // 0x65bd7c: mov             x0, x2
    // 0x65bd80: StoreField: r1->field_4b = r0
    //     0x65bd80: stur            w0, [x1, #0x4b]
    //     0x65bd84: ldurb           w16, [x1, #-1]
    //     0x65bd88: ldurb           w17, [x0, #-1]
    //     0x65bd8c: and             x16, x17, x16, lsr #2
    //     0x65bd90: tst             x16, HEAP, lsr #32
    //     0x65bd94: b.eq            #0x65bd9c
    //     0x65bd98: bl              #0xd6826c
    // 0x65bd9c: SaveReg r1
    //     0x65bd9c: str             x1, [SP, #-8]!
    // 0x65bda0: r0 = markNeedsAddToScene()
    //     0x65bda0: bl              #0x5dec74  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0x65bda4: add             SP, SP, #8
    // 0x65bda8: r0 = Null
    //     0x65bda8: mov             x0, NULL
    // 0x65bdac: LeaveFrame
    //     0x65bdac: mov             SP, fp
    //     0x65bdb0: ldp             fp, lr, [SP], #0x10
    // 0x65bdb4: ret
    //     0x65bdb4: ret             
    // 0x65bdb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65bdb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65bdbc: b               #0x65bd64
  }
  set _ clipPath=(/* No info */) {
    // ** addr: 0x662d4c, size: 0x70
    // 0x662d4c: EnterFrame
    //     0x662d4c: stp             fp, lr, [SP, #-0x10]!
    //     0x662d50: mov             fp, SP
    // 0x662d54: CheckStackOverflow
    //     0x662d54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x662d58: cmp             SP, x16
    //     0x662d5c: b.ls            #0x662db4
    // 0x662d60: ldr             x1, [fp, #0x18]
    // 0x662d64: LoadField: r0 = r1->field_47
    //     0x662d64: ldur            w0, [x1, #0x47]
    // 0x662d68: DecompressPointer r0
    //     0x662d68: add             x0, x0, HEAP, lsl #32
    // 0x662d6c: ldr             x2, [fp, #0x10]
    // 0x662d70: cmp             w2, w0
    // 0x662d74: b.eq            #0x662da4
    // 0x662d78: mov             x0, x2
    // 0x662d7c: StoreField: r1->field_47 = r0
    //     0x662d7c: stur            w0, [x1, #0x47]
    //     0x662d80: ldurb           w16, [x1, #-1]
    //     0x662d84: ldurb           w17, [x0, #-1]
    //     0x662d88: and             x16, x17, x16, lsr #2
    //     0x662d8c: tst             x16, HEAP, lsr #32
    //     0x662d90: b.eq            #0x662d98
    //     0x662d94: bl              #0xd6826c
    // 0x662d98: SaveReg r1
    //     0x662d98: str             x1, [SP, #-8]!
    // 0x662d9c: r0 = markNeedsAddToScene()
    //     0x662d9c: bl              #0x5dec74  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0x662da0: add             SP, SP, #8
    // 0x662da4: r0 = Null
    //     0x662da4: mov             x0, NULL
    // 0x662da8: LeaveFrame
    //     0x662da8: mov             SP, fp
    //     0x662dac: ldp             fp, lr, [SP], #0x10
    // 0x662db0: ret
    //     0x662db0: ret             
    // 0x662db4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x662db4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x662db8: b               #0x662d60
  }
  _ addToScene(/* No info */) {
    // ** addr: 0xa85de8, size: 0xec
    // 0xa85de8: EnterFrame
    //     0xa85de8: stp             fp, lr, [SP, #-0x10]!
    //     0xa85dec: mov             fp, SP
    // 0xa85df0: AllocStack(0x18)
    //     0xa85df0: sub             SP, SP, #0x18
    // 0xa85df4: CheckStackOverflow
    //     0xa85df4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa85df8: cmp             SP, x16
    //     0xa85dfc: b.ls            #0xa85ec8
    // 0xa85e00: ldr             x3, [fp, #0x18]
    // 0xa85e04: LoadField: r4 = r3->field_47
    //     0xa85e04: ldur            w4, [x3, #0x47]
    // 0xa85e08: DecompressPointer r4
    //     0xa85e08: add             x4, x4, HEAP, lsl #32
    // 0xa85e0c: stur            x4, [fp, #-0x18]
    // 0xa85e10: cmp             w4, NULL
    // 0xa85e14: b.eq            #0xa85ed0
    // 0xa85e18: LoadField: r5 = r3->field_4b
    //     0xa85e18: ldur            w5, [x3, #0x4b]
    // 0xa85e1c: DecompressPointer r5
    //     0xa85e1c: add             x5, x5, HEAP, lsl #32
    // 0xa85e20: stur            x5, [fp, #-0x10]
    // 0xa85e24: LoadField: r6 = r3->field_33
    //     0xa85e24: ldur            w6, [x3, #0x33]
    // 0xa85e28: DecompressPointer r6
    //     0xa85e28: add             x6, x6, HEAP, lsl #32
    // 0xa85e2c: mov             x0, x6
    // 0xa85e30: stur            x6, [fp, #-8]
    // 0xa85e34: r2 = Null
    //     0xa85e34: mov             x2, NULL
    // 0xa85e38: r1 = Null
    //     0xa85e38: mov             x1, NULL
    // 0xa85e3c: r4 = LoadClassIdInstr(r0)
    //     0xa85e3c: ldur            x4, [x0, #-1]
    //     0xa85e40: ubfx            x4, x4, #0xc, #0x14
    // 0xa85e44: r17 = 5080
    //     0xa85e44: mov             x17, #0x13d8
    // 0xa85e48: cmp             x4, x17
    // 0xa85e4c: b.eq            #0xa85e64
    // 0xa85e50: r8 = ClipPathEngineLayer?
    //     0xa85e50: add             x8, PP, #0x28, lsl #12  ; [pp+0x285c0] Type: ClipPathEngineLayer?
    //     0xa85e54: ldr             x8, [x8, #0x5c0]
    // 0xa85e58: r3 = Null
    //     0xa85e58: add             x3, PP, #0x28, lsl #12  ; [pp+0x285c8] Null
    //     0xa85e5c: ldr             x3, [x3, #0x5c8]
    // 0xa85e60: r0 = DefaultNullableTypeTest()
    //     0xa85e60: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xa85e64: ldr             x16, [fp, #0x10]
    // 0xa85e68: ldur            lr, [fp, #-0x18]
    // 0xa85e6c: stp             lr, x16, [SP, #-0x10]!
    // 0xa85e70: ldur            x16, [fp, #-0x10]
    // 0xa85e74: ldur            lr, [fp, #-8]
    // 0xa85e78: stp             lr, x16, [SP, #-0x10]!
    // 0xa85e7c: r0 = pushClipPath()
    //     0xa85e7c: bl              #0xa85ed4  ; [dart:ui] SceneBuilder::pushClipPath
    // 0xa85e80: add             SP, SP, #0x20
    // 0xa85e84: ldr             x16, [fp, #0x18]
    // 0xa85e88: stp             x0, x16, [SP, #-0x10]!
    // 0xa85e8c: r0 = engineLayer=()
    //     0xa85e8c: bl              #0x661300  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0xa85e90: add             SP, SP, #0x10
    // 0xa85e94: ldr             x16, [fp, #0x18]
    // 0xa85e98: ldr             lr, [fp, #0x10]
    // 0xa85e9c: stp             lr, x16, [SP, #-0x10]!
    // 0xa85ea0: r0 = addChildrenToScene()
    //     0xa85ea0: bl              #0xa84130  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0xa85ea4: add             SP, SP, #0x10
    // 0xa85ea8: ldr             x16, [fp, #0x10]
    // 0xa85eac: SaveReg r16
    //     0xa85eac: str             x16, [SP, #-8]!
    // 0xa85eb0: r0 = pop()
    //     0xa85eb0: bl              #0xa83f3c  ; [dart:ui] SceneBuilder::pop
    // 0xa85eb4: add             SP, SP, #8
    // 0xa85eb8: r0 = Null
    //     0xa85eb8: mov             x0, NULL
    // 0xa85ebc: LeaveFrame
    //     0xa85ebc: mov             SP, fp
    //     0xa85ec0: ldp             fp, lr, [SP], #0x10
    // 0xa85ec4: ret
    //     0xa85ec4: ret             
    // 0xa85ec8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa85ec8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa85ecc: b               #0xa85e00
    // 0xa85ed0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa85ed0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ findAnnotations(/* No info */) {
    // ** addr: 0xa8c97c, size: 0xc8
    // 0xa8c97c: EnterFrame
    //     0xa8c97c: stp             fp, lr, [SP, #-0x10]!
    //     0xa8c980: mov             fp, SP
    // 0xa8c984: AllocStack(0x8)
    //     0xa8c984: sub             SP, SP, #8
    // 0xa8c988: SetupParameters()
    //     0xa8c988: mov             x0, x4
    //     0xa8c98c: ldur            w1, [x0, #0xf]
    //     0xa8c990: add             x1, x1, HEAP, lsl #32
    //     0xa8c994: cbnz            w1, #0xa8c9a0
    //     0xa8c998: mov             x0, NULL
    //     0xa8c99c: b               #0xa8c9b0
    //     0xa8c9a0: ldur            w2, [x0, #0x17]
    //     0xa8c9a4: add             x2, x2, HEAP, lsl #32
    //     0xa8c9a8: add             x0, fp, w2, sxtw #2
    //     0xa8c9ac: ldr             x0, [x0, #0x10]
    // 0xa8c9b0: CheckStackOverflow
    //     0xa8c9b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8c9b4: cmp             SP, x16
    //     0xa8c9b8: b.ls            #0xa8ca38
    // 0xa8c9bc: cbnz            w1, #0xa8c9c8
    // 0xa8c9c0: r1 = <Object>
    //     0xa8c9c0: ldr             x1, [PP, #0x1d8]  ; [pp+0x1d8] TypeArguments: <Object>
    // 0xa8c9c4: b               #0xa8c9cc
    // 0xa8c9c8: mov             x1, x0
    // 0xa8c9cc: ldr             x0, [fp, #0x20]
    // 0xa8c9d0: stur            x1, [fp, #-8]
    // 0xa8c9d4: LoadField: r2 = r0->field_47
    //     0xa8c9d4: ldur            w2, [x0, #0x47]
    // 0xa8c9d8: DecompressPointer r2
    //     0xa8c9d8: add             x2, x2, HEAP, lsl #32
    // 0xa8c9dc: cmp             w2, NULL
    // 0xa8c9e0: b.eq            #0xa8ca40
    // 0xa8c9e4: ldr             x16, [fp, #0x10]
    // 0xa8c9e8: stp             x16, x2, [SP, #-0x10]!
    // 0xa8c9ec: r0 = contains()
    //     0xa8c9ec: bl              #0x640124  ; [dart:ui] Path::contains
    // 0xa8c9f0: add             SP, SP, #0x10
    // 0xa8c9f4: tbz             w0, #4, #0xa8ca08
    // 0xa8c9f8: r0 = false
    //     0xa8c9f8: add             x0, NULL, #0x30  ; false
    // 0xa8c9fc: LeaveFrame
    //     0xa8c9fc: mov             SP, fp
    //     0xa8ca00: ldp             fp, lr, [SP], #0x10
    // 0xa8ca04: ret
    //     0xa8ca04: ret             
    // 0xa8ca08: ldur            x16, [fp, #-8]
    // 0xa8ca0c: ldr             lr, [fp, #0x20]
    // 0xa8ca10: stp             lr, x16, [SP, #-0x10]!
    // 0xa8ca14: ldr             x16, [fp, #0x18]
    // 0xa8ca18: ldr             lr, [fp, #0x10]
    // 0xa8ca1c: stp             lr, x16, [SP, #-0x10]!
    // 0xa8ca20: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xa8ca20: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xa8ca24: r0 = findAnnotations()
    //     0xa8ca24: bl              #0xa8d380  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::findAnnotations
    // 0xa8ca28: add             SP, SP, #0x20
    // 0xa8ca2c: LeaveFrame
    //     0xa8ca2c: mov             SP, fp
    //     0xa8ca30: ldp             fp, lr, [SP], #0x10
    // 0xa8ca34: ret
    //     0xa8ca34: ret             
    // 0xa8ca38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8ca38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8ca3c: b               #0xa8c9bc
    // 0xa8ca40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa8ca40: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2388, size: 0x50, field offset: 0x48
class ClipRRectLayer extends ContainerLayer {

  set _ clipRRect=(/* No info */) {
    // ** addr: 0x662450, size: 0x7c
    // 0x662450: EnterFrame
    //     0x662450: stp             fp, lr, [SP, #-0x10]!
    //     0x662454: mov             fp, SP
    // 0x662458: CheckStackOverflow
    //     0x662458: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66245c: cmp             SP, x16
    //     0x662460: b.ls            #0x6624c4
    // 0x662464: ldr             x0, [fp, #0x18]
    // 0x662468: LoadField: r1 = r0->field_47
    //     0x662468: ldur            w1, [x0, #0x47]
    // 0x66246c: DecompressPointer r1
    //     0x66246c: add             x1, x1, HEAP, lsl #32
    // 0x662470: ldr             x16, [fp, #0x10]
    // 0x662474: stp             x1, x16, [SP, #-0x10]!
    // 0x662478: r0 = ==()
    //     0x662478: bl              #0xc662ec  ; [dart:ui] RRect::==
    // 0x66247c: add             SP, SP, #0x10
    // 0x662480: tbz             w0, #4, #0x6624b4
    // 0x662484: ldr             x1, [fp, #0x18]
    // 0x662488: ldr             x0, [fp, #0x10]
    // 0x66248c: StoreField: r1->field_47 = r0
    //     0x66248c: stur            w0, [x1, #0x47]
    //     0x662490: ldurb           w16, [x1, #-1]
    //     0x662494: ldurb           w17, [x0, #-1]
    //     0x662498: and             x16, x17, x16, lsr #2
    //     0x66249c: tst             x16, HEAP, lsr #32
    //     0x6624a0: b.eq            #0x6624a8
    //     0x6624a4: bl              #0xd6826c
    // 0x6624a8: SaveReg r1
    //     0x6624a8: str             x1, [SP, #-8]!
    // 0x6624ac: r0 = markNeedsAddToScene()
    //     0x6624ac: bl              #0x5dec74  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0x6624b0: add             SP, SP, #8
    // 0x6624b4: r0 = Null
    //     0x6624b4: mov             x0, NULL
    // 0x6624b8: LeaveFrame
    //     0x6624b8: mov             SP, fp
    //     0x6624bc: ldp             fp, lr, [SP], #0x10
    // 0x6624c0: ret
    //     0x6624c0: ret             
    // 0x6624c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6624c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6624c8: b               #0x662464
  }
  _ addToScene(/* No info */) {
    // ** addr: 0xa858d4, size: 0xec
    // 0xa858d4: EnterFrame
    //     0xa858d4: stp             fp, lr, [SP, #-0x10]!
    //     0xa858d8: mov             fp, SP
    // 0xa858dc: AllocStack(0x18)
    //     0xa858dc: sub             SP, SP, #0x18
    // 0xa858e0: CheckStackOverflow
    //     0xa858e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa858e4: cmp             SP, x16
    //     0xa858e8: b.ls            #0xa859b4
    // 0xa858ec: ldr             x3, [fp, #0x18]
    // 0xa858f0: LoadField: r4 = r3->field_47
    //     0xa858f0: ldur            w4, [x3, #0x47]
    // 0xa858f4: DecompressPointer r4
    //     0xa858f4: add             x4, x4, HEAP, lsl #32
    // 0xa858f8: stur            x4, [fp, #-0x18]
    // 0xa858fc: cmp             w4, NULL
    // 0xa85900: b.eq            #0xa859bc
    // 0xa85904: LoadField: r5 = r3->field_4b
    //     0xa85904: ldur            w5, [x3, #0x4b]
    // 0xa85908: DecompressPointer r5
    //     0xa85908: add             x5, x5, HEAP, lsl #32
    // 0xa8590c: stur            x5, [fp, #-0x10]
    // 0xa85910: LoadField: r6 = r3->field_33
    //     0xa85910: ldur            w6, [x3, #0x33]
    // 0xa85914: DecompressPointer r6
    //     0xa85914: add             x6, x6, HEAP, lsl #32
    // 0xa85918: mov             x0, x6
    // 0xa8591c: stur            x6, [fp, #-8]
    // 0xa85920: r2 = Null
    //     0xa85920: mov             x2, NULL
    // 0xa85924: r1 = Null
    //     0xa85924: mov             x1, NULL
    // 0xa85928: r4 = LoadClassIdInstr(r0)
    //     0xa85928: ldur            x4, [x0, #-1]
    //     0xa8592c: ubfx            x4, x4, #0xc, #0x14
    // 0xa85930: r17 = 5081
    //     0xa85930: mov             x17, #0x13d9
    // 0xa85934: cmp             x4, x17
    // 0xa85938: b.eq            #0xa85950
    // 0xa8593c: r8 = ClipRRectEngineLayer?
    //     0xa8593c: add             x8, PP, #0x37, lsl #12  ; [pp+0x370e8] Type: ClipRRectEngineLayer?
    //     0xa85940: ldr             x8, [x8, #0xe8]
    // 0xa85944: r3 = Null
    //     0xa85944: add             x3, PP, #0x37, lsl #12  ; [pp+0x370f0] Null
    //     0xa85948: ldr             x3, [x3, #0xf0]
    // 0xa8594c: r0 = DefaultNullableTypeTest()
    //     0xa8594c: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xa85950: ldr             x16, [fp, #0x10]
    // 0xa85954: ldur            lr, [fp, #-0x18]
    // 0xa85958: stp             lr, x16, [SP, #-0x10]!
    // 0xa8595c: ldur            x16, [fp, #-0x10]
    // 0xa85960: ldur            lr, [fp, #-8]
    // 0xa85964: stp             lr, x16, [SP, #-0x10]!
    // 0xa85968: r0 = pushClipRRect()
    //     0xa85968: bl              #0xa859c0  ; [dart:ui] SceneBuilder::pushClipRRect
    // 0xa8596c: add             SP, SP, #0x20
    // 0xa85970: ldr             x16, [fp, #0x18]
    // 0xa85974: stp             x0, x16, [SP, #-0x10]!
    // 0xa85978: r0 = engineLayer=()
    //     0xa85978: bl              #0x661300  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0xa8597c: add             SP, SP, #0x10
    // 0xa85980: ldr             x16, [fp, #0x18]
    // 0xa85984: ldr             lr, [fp, #0x10]
    // 0xa85988: stp             lr, x16, [SP, #-0x10]!
    // 0xa8598c: r0 = addChildrenToScene()
    //     0xa8598c: bl              #0xa84130  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0xa85990: add             SP, SP, #0x10
    // 0xa85994: ldr             x16, [fp, #0x10]
    // 0xa85998: SaveReg r16
    //     0xa85998: str             x16, [SP, #-8]!
    // 0xa8599c: r0 = pop()
    //     0xa8599c: bl              #0xa83f3c  ; [dart:ui] SceneBuilder::pop
    // 0xa859a0: add             SP, SP, #8
    // 0xa859a4: r0 = Null
    //     0xa859a4: mov             x0, NULL
    // 0xa859a8: LeaveFrame
    //     0xa859a8: mov             SP, fp
    //     0xa859ac: ldp             fp, lr, [SP], #0x10
    // 0xa859b0: ret
    //     0xa859b0: ret             
    // 0xa859b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa859b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa859b8: b               #0xa858ec
    // 0xa859bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa859bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ findAnnotations(/* No info */) {
    // ** addr: 0xa8c8b4, size: 0xc8
    // 0xa8c8b4: EnterFrame
    //     0xa8c8b4: stp             fp, lr, [SP, #-0x10]!
    //     0xa8c8b8: mov             fp, SP
    // 0xa8c8bc: AllocStack(0x8)
    //     0xa8c8bc: sub             SP, SP, #8
    // 0xa8c8c0: SetupParameters()
    //     0xa8c8c0: mov             x0, x4
    //     0xa8c8c4: ldur            w1, [x0, #0xf]
    //     0xa8c8c8: add             x1, x1, HEAP, lsl #32
    //     0xa8c8cc: cbnz            w1, #0xa8c8d8
    //     0xa8c8d0: mov             x0, NULL
    //     0xa8c8d4: b               #0xa8c8e8
    //     0xa8c8d8: ldur            w2, [x0, #0x17]
    //     0xa8c8dc: add             x2, x2, HEAP, lsl #32
    //     0xa8c8e0: add             x0, fp, w2, sxtw #2
    //     0xa8c8e4: ldr             x0, [x0, #0x10]
    // 0xa8c8e8: CheckStackOverflow
    //     0xa8c8e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8c8ec: cmp             SP, x16
    //     0xa8c8f0: b.ls            #0xa8c970
    // 0xa8c8f4: cbnz            w1, #0xa8c900
    // 0xa8c8f8: r1 = <Object>
    //     0xa8c8f8: ldr             x1, [PP, #0x1d8]  ; [pp+0x1d8] TypeArguments: <Object>
    // 0xa8c8fc: b               #0xa8c904
    // 0xa8c900: mov             x1, x0
    // 0xa8c904: ldr             x0, [fp, #0x20]
    // 0xa8c908: stur            x1, [fp, #-8]
    // 0xa8c90c: LoadField: r2 = r0->field_47
    //     0xa8c90c: ldur            w2, [x0, #0x47]
    // 0xa8c910: DecompressPointer r2
    //     0xa8c910: add             x2, x2, HEAP, lsl #32
    // 0xa8c914: cmp             w2, NULL
    // 0xa8c918: b.eq            #0xa8c978
    // 0xa8c91c: ldr             x16, [fp, #0x10]
    // 0xa8c920: stp             x16, x2, [SP, #-0x10]!
    // 0xa8c924: r0 = contains()
    //     0xa8c924: bl              #0x63f7dc  ; [dart:ui] RRect::contains
    // 0xa8c928: add             SP, SP, #0x10
    // 0xa8c92c: tbz             w0, #4, #0xa8c940
    // 0xa8c930: r0 = false
    //     0xa8c930: add             x0, NULL, #0x30  ; false
    // 0xa8c934: LeaveFrame
    //     0xa8c934: mov             SP, fp
    //     0xa8c938: ldp             fp, lr, [SP], #0x10
    // 0xa8c93c: ret
    //     0xa8c93c: ret             
    // 0xa8c940: ldur            x16, [fp, #-8]
    // 0xa8c944: ldr             lr, [fp, #0x20]
    // 0xa8c948: stp             lr, x16, [SP, #-0x10]!
    // 0xa8c94c: ldr             x16, [fp, #0x18]
    // 0xa8c950: ldr             lr, [fp, #0x10]
    // 0xa8c954: stp             lr, x16, [SP, #-0x10]!
    // 0xa8c958: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xa8c958: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xa8c95c: r0 = findAnnotations()
    //     0xa8c95c: bl              #0xa8d380  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::findAnnotations
    // 0xa8c960: add             SP, SP, #0x20
    // 0xa8c964: LeaveFrame
    //     0xa8c964: mov             SP, fp
    //     0xa8c968: ldp             fp, lr, [SP], #0x10
    // 0xa8c96c: ret
    //     0xa8c96c: ret             
    // 0xa8c970: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8c970: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8c974: b               #0xa8c8f4
    // 0xa8c978: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa8c978: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2389, size: 0x50, field offset: 0x48
class ClipRectLayer extends ContainerLayer {

  set _ clipRect=(/* No info */) {
    // ** addr: 0x65bdc0, size: 0x108
    // 0x65bdc0: EnterFrame
    //     0x65bdc0: stp             fp, lr, [SP, #-0x10]!
    //     0x65bdc4: mov             fp, SP
    // 0x65bdc8: AllocStack(0x8)
    //     0x65bdc8: sub             SP, SP, #8
    // 0x65bdcc: CheckStackOverflow
    //     0x65bdcc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65bdd0: cmp             SP, x16
    //     0x65bdd4: b.ls            #0x65bec0
    // 0x65bdd8: ldr             x0, [fp, #0x18]
    // 0x65bddc: LoadField: r1 = r0->field_47
    //     0x65bddc: ldur            w1, [x0, #0x47]
    // 0x65bde0: DecompressPointer r1
    //     0x65bde0: add             x1, x1, HEAP, lsl #32
    // 0x65bde4: stur            x1, [fp, #-8]
    // 0x65bde8: cmp             w1, NULL
    // 0x65bdec: b.ne            #0x65bdfc
    // 0x65bdf0: mov             x2, x0
    // 0x65bdf4: ldr             x1, [fp, #0x10]
    // 0x65bdf8: b               #0x65be84
    // 0x65bdfc: ldr             x2, [fp, #0x10]
    // 0x65be00: cmp             w2, w1
    // 0x65be04: b.eq            #0x65beb0
    // 0x65be08: r16 = Rect
    //     0x65be08: ldr             x16, [PP, #0x5e50]  ; [pp+0x5e50] Type: Rect
    // 0x65be0c: r30 = Rect
    //     0x65be0c: ldr             lr, [PP, #0x5e50]  ; [pp+0x5e50] Type: Rect
    // 0x65be10: stp             lr, x16, [SP, #-0x10]!
    // 0x65be14: r0 = ==()
    //     0x65be14: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x65be18: add             SP, SP, #0x10
    // 0x65be1c: tbz             w0, #4, #0x65be2c
    // 0x65be20: ldr             x2, [fp, #0x18]
    // 0x65be24: ldr             x1, [fp, #0x10]
    // 0x65be28: b               #0x65be84
    // 0x65be2c: ldr             x1, [fp, #0x10]
    // 0x65be30: ldur            x0, [fp, #-8]
    // 0x65be34: LoadField: d0 = r0->field_7
    //     0x65be34: ldur            d0, [x0, #7]
    // 0x65be38: LoadField: d1 = r1->field_7
    //     0x65be38: ldur            d1, [x1, #7]
    // 0x65be3c: fcmp            d0, d1
    // 0x65be40: b.vs            #0x65be80
    // 0x65be44: b.ne            #0x65be80
    // 0x65be48: LoadField: d0 = r0->field_f
    //     0x65be48: ldur            d0, [x0, #0xf]
    // 0x65be4c: LoadField: d1 = r1->field_f
    //     0x65be4c: ldur            d1, [x1, #0xf]
    // 0x65be50: fcmp            d0, d1
    // 0x65be54: b.vs            #0x65be80
    // 0x65be58: b.ne            #0x65be80
    // 0x65be5c: LoadField: d0 = r0->field_17
    //     0x65be5c: ldur            d0, [x0, #0x17]
    // 0x65be60: LoadField: d1 = r1->field_17
    //     0x65be60: ldur            d1, [x1, #0x17]
    // 0x65be64: fcmp            d0, d1
    // 0x65be68: b.vs            #0x65be80
    // 0x65be6c: b.ne            #0x65be80
    // 0x65be70: LoadField: d0 = r0->field_1f
    //     0x65be70: ldur            d0, [x0, #0x1f]
    // 0x65be74: LoadField: d1 = r1->field_1f
    //     0x65be74: ldur            d1, [x1, #0x1f]
    // 0x65be78: fcmp            d0, d1
    // 0x65be7c: b.eq            #0x65beb0
    // 0x65be80: ldr             x2, [fp, #0x18]
    // 0x65be84: mov             x0, x1
    // 0x65be88: StoreField: r2->field_47 = r0
    //     0x65be88: stur            w0, [x2, #0x47]
    //     0x65be8c: ldurb           w16, [x2, #-1]
    //     0x65be90: ldurb           w17, [x0, #-1]
    //     0x65be94: and             x16, x17, x16, lsr #2
    //     0x65be98: tst             x16, HEAP, lsr #32
    //     0x65be9c: b.eq            #0x65bea4
    //     0x65bea0: bl              #0xd6828c
    // 0x65bea4: SaveReg r2
    //     0x65bea4: str             x2, [SP, #-8]!
    // 0x65bea8: r0 = markNeedsAddToScene()
    //     0x65bea8: bl              #0x5dec74  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0x65beac: add             SP, SP, #8
    // 0x65beb0: r0 = Null
    //     0x65beb0: mov             x0, NULL
    // 0x65beb4: LeaveFrame
    //     0x65beb4: mov             SP, fp
    //     0x65beb8: ldp             fp, lr, [SP], #0x10
    // 0x65bebc: ret
    //     0x65bebc: ret             
    // 0x65bec0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65bec0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65bec4: b               #0x65bdd8
  }
  _ addToScene(/* No info */) {
    // ** addr: 0xa851d4, size: 0xec
    // 0xa851d4: EnterFrame
    //     0xa851d4: stp             fp, lr, [SP, #-0x10]!
    //     0xa851d8: mov             fp, SP
    // 0xa851dc: AllocStack(0x18)
    //     0xa851dc: sub             SP, SP, #0x18
    // 0xa851e0: CheckStackOverflow
    //     0xa851e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa851e4: cmp             SP, x16
    //     0xa851e8: b.ls            #0xa852b4
    // 0xa851ec: ldr             x3, [fp, #0x18]
    // 0xa851f0: LoadField: r4 = r3->field_47
    //     0xa851f0: ldur            w4, [x3, #0x47]
    // 0xa851f4: DecompressPointer r4
    //     0xa851f4: add             x4, x4, HEAP, lsl #32
    // 0xa851f8: stur            x4, [fp, #-0x18]
    // 0xa851fc: cmp             w4, NULL
    // 0xa85200: b.eq            #0xa852bc
    // 0xa85204: LoadField: r5 = r3->field_4b
    //     0xa85204: ldur            w5, [x3, #0x4b]
    // 0xa85208: DecompressPointer r5
    //     0xa85208: add             x5, x5, HEAP, lsl #32
    // 0xa8520c: stur            x5, [fp, #-0x10]
    // 0xa85210: LoadField: r6 = r3->field_33
    //     0xa85210: ldur            w6, [x3, #0x33]
    // 0xa85214: DecompressPointer r6
    //     0xa85214: add             x6, x6, HEAP, lsl #32
    // 0xa85218: mov             x0, x6
    // 0xa8521c: stur            x6, [fp, #-8]
    // 0xa85220: r2 = Null
    //     0xa85220: mov             x2, NULL
    // 0xa85224: r1 = Null
    //     0xa85224: mov             x1, NULL
    // 0xa85228: r4 = LoadClassIdInstr(r0)
    //     0xa85228: ldur            x4, [x0, #-1]
    //     0xa8522c: ubfx            x4, x4, #0xc, #0x14
    // 0xa85230: r17 = 5082
    //     0xa85230: mov             x17, #0x13da
    // 0xa85234: cmp             x4, x17
    // 0xa85238: b.eq            #0xa85250
    // 0xa8523c: r8 = ClipRectEngineLayer?
    //     0xa8523c: add             x8, PP, #0x21, lsl #12  ; [pp+0x21c70] Type: ClipRectEngineLayer?
    //     0xa85240: ldr             x8, [x8, #0xc70]
    // 0xa85244: r3 = Null
    //     0xa85244: add             x3, PP, #0x21, lsl #12  ; [pp+0x21c78] Null
    //     0xa85248: ldr             x3, [x3, #0xc78]
    // 0xa8524c: r0 = DefaultNullableTypeTest()
    //     0xa8524c: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xa85250: ldr             x16, [fp, #0x10]
    // 0xa85254: ldur            lr, [fp, #-0x18]
    // 0xa85258: stp             lr, x16, [SP, #-0x10]!
    // 0xa8525c: ldur            x16, [fp, #-0x10]
    // 0xa85260: ldur            lr, [fp, #-8]
    // 0xa85264: stp             lr, x16, [SP, #-0x10]!
    // 0xa85268: r0 = pushClipRect()
    //     0xa85268: bl              #0xa852c0  ; [dart:ui] SceneBuilder::pushClipRect
    // 0xa8526c: add             SP, SP, #0x20
    // 0xa85270: ldr             x16, [fp, #0x18]
    // 0xa85274: stp             x0, x16, [SP, #-0x10]!
    // 0xa85278: r0 = engineLayer=()
    //     0xa85278: bl              #0x661300  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0xa8527c: add             SP, SP, #0x10
    // 0xa85280: ldr             x16, [fp, #0x18]
    // 0xa85284: ldr             lr, [fp, #0x10]
    // 0xa85288: stp             lr, x16, [SP, #-0x10]!
    // 0xa8528c: r0 = addChildrenToScene()
    //     0xa8528c: bl              #0xa84130  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0xa85290: add             SP, SP, #0x10
    // 0xa85294: ldr             x16, [fp, #0x10]
    // 0xa85298: SaveReg r16
    //     0xa85298: str             x16, [SP, #-8]!
    // 0xa8529c: r0 = pop()
    //     0xa8529c: bl              #0xa83f3c  ; [dart:ui] SceneBuilder::pop
    // 0xa852a0: add             SP, SP, #8
    // 0xa852a4: r0 = Null
    //     0xa852a4: mov             x0, NULL
    // 0xa852a8: LeaveFrame
    //     0xa852a8: mov             SP, fp
    //     0xa852ac: ldp             fp, lr, [SP], #0x10
    // 0xa852b0: ret
    //     0xa852b0: ret             
    // 0xa852b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa852b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa852b8: b               #0xa851ec
    // 0xa852bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa852bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ findAnnotations(/* No info */) {
    // ** addr: 0xa8c7ec, size: 0xc8
    // 0xa8c7ec: EnterFrame
    //     0xa8c7ec: stp             fp, lr, [SP, #-0x10]!
    //     0xa8c7f0: mov             fp, SP
    // 0xa8c7f4: AllocStack(0x8)
    //     0xa8c7f4: sub             SP, SP, #8
    // 0xa8c7f8: SetupParameters()
    //     0xa8c7f8: mov             x0, x4
    //     0xa8c7fc: ldur            w1, [x0, #0xf]
    //     0xa8c800: add             x1, x1, HEAP, lsl #32
    //     0xa8c804: cbnz            w1, #0xa8c810
    //     0xa8c808: mov             x0, NULL
    //     0xa8c80c: b               #0xa8c820
    //     0xa8c810: ldur            w2, [x0, #0x17]
    //     0xa8c814: add             x2, x2, HEAP, lsl #32
    //     0xa8c818: add             x0, fp, w2, sxtw #2
    //     0xa8c81c: ldr             x0, [x0, #0x10]
    // 0xa8c820: CheckStackOverflow
    //     0xa8c820: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8c824: cmp             SP, x16
    //     0xa8c828: b.ls            #0xa8c8a8
    // 0xa8c82c: cbnz            w1, #0xa8c838
    // 0xa8c830: r1 = <Object>
    //     0xa8c830: ldr             x1, [PP, #0x1d8]  ; [pp+0x1d8] TypeArguments: <Object>
    // 0xa8c834: b               #0xa8c83c
    // 0xa8c838: mov             x1, x0
    // 0xa8c83c: ldr             x0, [fp, #0x20]
    // 0xa8c840: stur            x1, [fp, #-8]
    // 0xa8c844: LoadField: r2 = r0->field_47
    //     0xa8c844: ldur            w2, [x0, #0x47]
    // 0xa8c848: DecompressPointer r2
    //     0xa8c848: add             x2, x2, HEAP, lsl #32
    // 0xa8c84c: cmp             w2, NULL
    // 0xa8c850: b.eq            #0xa8c8b0
    // 0xa8c854: ldr             x16, [fp, #0x10]
    // 0xa8c858: stp             x16, x2, [SP, #-0x10]!
    // 0xa8c85c: r0 = contains()
    //     0xa8c85c: bl              #0x627548  ; [dart:ui] Rect::contains
    // 0xa8c860: add             SP, SP, #0x10
    // 0xa8c864: tbz             w0, #4, #0xa8c878
    // 0xa8c868: r0 = false
    //     0xa8c868: add             x0, NULL, #0x30  ; false
    // 0xa8c86c: LeaveFrame
    //     0xa8c86c: mov             SP, fp
    //     0xa8c870: ldp             fp, lr, [SP], #0x10
    // 0xa8c874: ret
    //     0xa8c874: ret             
    // 0xa8c878: ldur            x16, [fp, #-8]
    // 0xa8c87c: ldr             lr, [fp, #0x20]
    // 0xa8c880: stp             lr, x16, [SP, #-0x10]!
    // 0xa8c884: ldr             x16, [fp, #0x18]
    // 0xa8c888: ldr             lr, [fp, #0x10]
    // 0xa8c88c: stp             lr, x16, [SP, #-0x10]!
    // 0xa8c890: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xa8c890: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xa8c894: r0 = findAnnotations()
    //     0xa8c894: bl              #0xa8d380  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::findAnnotations
    // 0xa8c898: add             SP, SP, #0x20
    // 0xa8c89c: LeaveFrame
    //     0xa8c89c: mov             SP, fp
    //     0xa8c8a0: ldp             fp, lr, [SP], #0x10
    // 0xa8c8a4: ret
    //     0xa8c8a4: ret             
    // 0xa8c8a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8c8a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8c8ac: b               #0xa8c82c
    // 0xa8c8b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa8c8b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2390, size: 0x4c, field offset: 0x48
class OffsetLayer extends ContainerLayer {

  set _ offset=(/* No info */) {
    // ** addr: 0x65455c, size: 0x80
    // 0x65455c: EnterFrame
    //     0x65455c: stp             fp, lr, [SP, #-0x10]!
    //     0x654560: mov             fp, SP
    // 0x654564: CheckStackOverflow
    //     0x654564: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x654568: cmp             SP, x16
    //     0x65456c: b.ls            #0x6545d4
    // 0x654570: ldr             x0, [fp, #0x18]
    // 0x654574: LoadField: r1 = r0->field_47
    //     0x654574: ldur            w1, [x0, #0x47]
    // 0x654578: DecompressPointer r1
    //     0x654578: add             x1, x1, HEAP, lsl #32
    // 0x65457c: ldr             x16, [fp, #0x10]
    // 0x654580: stp             x1, x16, [SP, #-0x10]!
    // 0x654584: r0 = ==()
    //     0x654584: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0x654588: add             SP, SP, #0x10
    // 0x65458c: tbz             w0, #4, #0x6545a0
    // 0x654590: ldr             x16, [fp, #0x18]
    // 0x654594: SaveReg r16
    //     0x654594: str             x16, [SP, #-8]!
    // 0x654598: r0 = markNeedsAddToScene()
    //     0x654598: bl              #0x5dec74  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0x65459c: add             SP, SP, #8
    // 0x6545a0: ldr             x1, [fp, #0x18]
    // 0x6545a4: ldr             x0, [fp, #0x10]
    // 0x6545a8: StoreField: r1->field_47 = r0
    //     0x6545a8: stur            w0, [x1, #0x47]
    //     0x6545ac: ldurb           w16, [x1, #-1]
    //     0x6545b0: ldurb           w17, [x0, #-1]
    //     0x6545b4: and             x16, x17, x16, lsr #2
    //     0x6545b8: tst             x16, HEAP, lsr #32
    //     0x6545bc: b.eq            #0x6545c4
    //     0x6545c0: bl              #0xd6826c
    // 0x6545c4: r0 = Null
    //     0x6545c4: mov             x0, NULL
    // 0x6545c8: LeaveFrame
    //     0x6545c8: mov             SP, fp
    //     0x6545cc: ldp             fp, lr, [SP], #0x10
    // 0x6545d0: ret
    //     0x6545d0: ret             
    // 0x6545d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6545d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6545d8: b               #0x654570
  }
  _ toImageSync(/* No info */) {
    // ** addr: 0x667380, size: 0x164
    // 0x667380: EnterFrame
    //     0x667380: stp             fp, lr, [SP, #-0x10]!
    //     0x667384: mov             fp, SP
    // 0x667388: AllocStack(0x48)
    //     0x667388: sub             SP, SP, #0x48
    // 0x66738c: CheckStackOverflow
    //     0x66738c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x667390: cmp             SP, x16
    //     0x667394: b.ls            #0x667484
    // 0x667398: ldr             x16, [fp, #0x20]
    // 0x66739c: ldr             lr, [fp, #0x18]
    // 0x6673a0: stp             lr, x16, [SP, #-0x10]!
    // 0x6673a4: ldr             d0, [fp, #0x10]
    // 0x6673a8: SaveReg d0
    //     0x6673a8: str             d0, [SP, #-8]!
    // 0x6673ac: r0 = _createSceneForImage()
    //     0x6673ac: bl              #0x667e84  ; [package:flutter/src/rendering/layer.dart] OffsetLayer::_createSceneForImage
    // 0x6673b0: add             SP, SP, #0x18
    // 0x6673b4: stur            x0, [fp, #-0x40]
    // 0x6673b8: ldr             x1, [fp, #0x18]
    // 0x6673bc: ldr             d0, [fp, #0x10]
    // 0x6673c0: LoadField: d1 = r1->field_17
    //     0x6673c0: ldur            d1, [x1, #0x17]
    // 0x6673c4: LoadField: d2 = r1->field_7
    //     0x6673c4: ldur            d2, [x1, #7]
    // 0x6673c8: fsub            d3, d1, d2
    // 0x6673cc: fmul            d1, d0, d3
    // 0x6673d0: fcmp            d1, d1
    // 0x6673d4: b.vs            #0x66748c
    // 0x6673d8: fcvtps          x2, d1
    // 0x6673dc: asr             x16, x2, #0x1e
    // 0x6673e0: cmp             x16, x2, asr #63
    // 0x6673e4: b.ne            #0x66748c
    // 0x6673e8: lsl             x2, x2, #1
    // 0x6673ec: LoadField: d1 = r1->field_1f
    //     0x6673ec: ldur            d1, [x1, #0x1f]
    // 0x6673f0: LoadField: d2 = r1->field_f
    //     0x6673f0: ldur            d2, [x1, #0xf]
    // 0x6673f4: fsub            d3, d1, d2
    // 0x6673f8: fmul            d1, d0, d3
    // 0x6673fc: fcmp            d1, d1
    // 0x667400: b.vs            #0x6674b8
    // 0x667404: fcvtps          x1, d1
    // 0x667408: asr             x16, x1, #0x1e
    // 0x66740c: cmp             x16, x1, asr #63
    // 0x667410: b.ne            #0x6674b8
    // 0x667414: lsl             x1, x1, #1
    // 0x667418: r3 = LoadInt32Instr(r1)
    //     0x667418: sbfx            x3, x1, #1, #0x1f
    //     0x66741c: tbz             w1, #0, #0x667424
    //     0x667420: ldur            x3, [x1, #7]
    // 0x667424: stp             x2, x0, [SP, #-0x10]!
    // 0x667428: SaveReg r3
    //     0x667428: str             x3, [SP, #-8]!
    // 0x66742c: r0 = toImageSync()
    //     0x66742c: bl              #0x6674e4  ; [dart:ui] Scene::toImageSync
    // 0x667430: add             SP, SP, #0x18
    // 0x667434: stur            x0, [fp, #-0x48]
    // 0x667438: ldur            x16, [fp, #-0x40]
    // 0x66743c: SaveReg r16
    //     0x66743c: str             x16, [SP, #-8]!
    // 0x667440: r0 = dispose()
    //     0x667440: bl              #0x5dd184  ; [dart:ui] Scene::dispose
    // 0x667444: add             SP, SP, #8
    // 0x667448: ldur            x0, [fp, #-0x48]
    // 0x66744c: LeaveFrame
    //     0x66744c: mov             SP, fp
    //     0x667450: ldp             fp, lr, [SP], #0x10
    // 0x667454: ret
    //     0x667454: ret             
    // 0x667458: sub             SP, fp, #0x48
    // 0x66745c: stur            x0, [fp, #-0x40]
    // 0x667460: stur            x1, [fp, #-0x48]
    // 0x667464: ldur            x16, [fp, #-0x38]
    // 0x667468: SaveReg r16
    //     0x667468: str             x16, [SP, #-8]!
    // 0x66746c: r0 = dispose()
    //     0x66746c: bl              #0x5dd184  ; [dart:ui] Scene::dispose
    // 0x667470: add             SP, SP, #8
    // 0x667474: ldur            x0, [fp, #-0x40]
    // 0x667478: ldur            x1, [fp, #-0x48]
    // 0x66747c: r0 = ReThrow()
    //     0x66747c: bl              #0xd67e14  ; ReThrowStub
    // 0x667480: brk             #0
    // 0x667484: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x667484: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x667488: b               #0x667398
    // 0x66748c: stp             q0, q1, [SP, #-0x20]!
    // 0x667490: stp             x0, x1, [SP, #-0x10]!
    // 0x667494: d0 = 0.000000
    //     0x667494: fmov            d0, d1
    // 0x667498: r0 = 208
    //     0x667498: mov             x0, #0xd0
    // 0x66749c: r24 = DoubleToIntegerStub
    //     0x66749c: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x6674a0: LoadField: r30 = r24->field_7
    //     0x6674a0: ldur            lr, [x24, #7]
    // 0x6674a4: blr             lr
    // 0x6674a8: mov             x2, x0
    // 0x6674ac: ldp             x0, x1, [SP], #0x10
    // 0x6674b0: ldp             q0, q1, [SP], #0x20
    // 0x6674b4: b               #0x6673ec
    // 0x6674b8: SaveReg d1
    //     0x6674b8: str             q1, [SP, #-0x10]!
    // 0x6674bc: stp             x0, x2, [SP, #-0x10]!
    // 0x6674c0: d0 = 0.000000
    //     0x6674c0: fmov            d0, d1
    // 0x6674c4: r0 = 208
    //     0x6674c4: mov             x0, #0xd0
    // 0x6674c8: r24 = DoubleToIntegerStub
    //     0x6674c8: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x6674cc: LoadField: r30 = r24->field_7
    //     0x6674cc: ldur            lr, [x24, #7]
    // 0x6674d0: blr             lr
    // 0x6674d4: mov             x1, x0
    // 0x6674d8: ldp             x0, x2, [SP], #0x10
    // 0x6674dc: RestoreReg d1
    //     0x6674dc: ldr             q1, [SP], #0x10
    // 0x6674e0: b               #0x667418
  }
  _ _createSceneForImage(/* No info */) {
    // ** addr: 0x667e84, size: 0x150
    // 0x667e84: EnterFrame
    //     0x667e84: stp             fp, lr, [SP, #-0x10]!
    //     0x667e88: mov             fp, SP
    // 0x667e8c: AllocStack(0x10)
    //     0x667e8c: sub             SP, SP, #0x10
    // 0x667e90: CheckStackOverflow
    //     0x667e90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x667e94: cmp             SP, x16
    //     0x667e98: b.ls            #0x667fa4
    // 0x667e9c: r0 = SceneBuilder()
    //     0x667e9c: bl              #0x5de354  ; AllocateSceneBuilderStub -> SceneBuilder (size=0x10)
    // 0x667ea0: stur            x0, [fp, #-8]
    // 0x667ea4: SaveReg r0
    //     0x667ea4: str             x0, [SP, #-8]!
    // 0x667ea8: r0 = SceneBuilder()
    //     0x667ea8: bl              #0x4f79fc  ; [dart:ui] SceneBuilder::SceneBuilder
    // 0x667eac: add             SP, SP, #8
    // 0x667eb0: ldr             d0, [fp, #0x10]
    // 0x667eb4: r0 = inline_Allocate_Double()
    //     0x667eb4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x667eb8: add             x0, x0, #0x10
    //     0x667ebc: cmp             x1, x0
    //     0x667ec0: b.ls            #0x667fac
    //     0x667ec4: str             x0, [THR, #0x60]  ; THR::top
    //     0x667ec8: sub             x0, x0, #0xf
    //     0x667ecc: mov             x1, #0xd108
    //     0x667ed0: movk            x1, #3, lsl #16
    //     0x667ed4: stur            x1, [x0, #-1]
    // 0x667ed8: StoreField: r0->field_7 = d0
    //     0x667ed8: stur            d0, [x0, #7]
    // 0x667edc: stp             x0, NULL, [SP, #-0x10]!
    // 0x667ee0: SaveReg r0
    //     0x667ee0: str             x0, [SP, #-8]!
    // 0x667ee4: d0 = 1.000000
    //     0x667ee4: fmov            d0, #1.00000000
    // 0x667ee8: SaveReg d0
    //     0x667ee8: str             d0, [SP, #-8]!
    // 0x667eec: r0 = Matrix4.diagonal3Values()
    //     0x667eec: bl              #0x5bbfe4  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.diagonal3Values
    // 0x667ef0: add             SP, SP, #0x20
    // 0x667ef4: mov             x1, x0
    // 0x667ef8: ldr             x0, [fp, #0x18]
    // 0x667efc: stur            x1, [fp, #-0x10]
    // 0x667f00: LoadField: d0 = r0->field_7
    //     0x667f00: ldur            d0, [x0, #7]
    // 0x667f04: ldr             x2, [fp, #0x20]
    // 0x667f08: LoadField: r3 = r2->field_47
    //     0x667f08: ldur            w3, [x2, #0x47]
    // 0x667f0c: DecompressPointer r3
    //     0x667f0c: add             x3, x3, HEAP, lsl #32
    // 0x667f10: LoadField: d1 = r3->field_7
    //     0x667f10: ldur            d1, [x3, #7]
    // 0x667f14: fadd            d2, d0, d1
    // 0x667f18: fneg            d0, d2
    // 0x667f1c: LoadField: d1 = r0->field_f
    //     0x667f1c: ldur            d1, [x0, #0xf]
    // 0x667f20: LoadField: d2 = r3->field_f
    //     0x667f20: ldur            d2, [x3, #0xf]
    // 0x667f24: fadd            d3, d1, d2
    // 0x667f28: fneg            d1, d3
    // 0x667f2c: r0 = inline_Allocate_Double()
    //     0x667f2c: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x667f30: add             x0, x0, #0x10
    //     0x667f34: cmp             x3, x0
    //     0x667f38: b.ls            #0x667fbc
    //     0x667f3c: str             x0, [THR, #0x60]  ; THR::top
    //     0x667f40: sub             x0, x0, #0xf
    //     0x667f44: mov             x3, #0xd108
    //     0x667f48: movk            x3, #3, lsl #16
    //     0x667f4c: stur            x3, [x0, #-1]
    // 0x667f50: StoreField: r0->field_7 = d0
    //     0x667f50: stur            d0, [x0, #7]
    // 0x667f54: stp             x0, x1, [SP, #-0x10]!
    // 0x667f58: SaveReg d1
    //     0x667f58: str             d1, [SP, #-8]!
    // 0x667f5c: r0 = translate()
    //     0x667f5c: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0x667f60: add             SP, SP, #0x18
    // 0x667f64: ldur            x0, [fp, #-0x10]
    // 0x667f68: LoadField: r1 = r0->field_7
    //     0x667f68: ldur            w1, [x0, #7]
    // 0x667f6c: DecompressPointer r1
    //     0x667f6c: add             x1, x1, HEAP, lsl #32
    // 0x667f70: ldur            x16, [fp, #-8]
    // 0x667f74: stp             x1, x16, [SP, #-0x10]!
    // 0x667f78: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x667f78: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x667f7c: r0 = pushTransform()
    //     0x667f7c: bl              #0x667fd4  ; [dart:ui] SceneBuilder::pushTransform
    // 0x667f80: add             SP, SP, #0x10
    // 0x667f84: ldr             x16, [fp, #0x20]
    // 0x667f88: ldur            lr, [fp, #-8]
    // 0x667f8c: stp             lr, x16, [SP, #-0x10]!
    // 0x667f90: r0 = buildScene()
    //     0x667f90: bl              #0x5ddf2c  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::buildScene
    // 0x667f94: add             SP, SP, #0x10
    // 0x667f98: LeaveFrame
    //     0x667f98: mov             SP, fp
    //     0x667f9c: ldp             fp, lr, [SP], #0x10
    // 0x667fa0: ret
    //     0x667fa0: ret             
    // 0x667fa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x667fa4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x667fa8: b               #0x667e9c
    // 0x667fac: SaveReg d0
    //     0x667fac: str             q0, [SP, #-0x10]!
    // 0x667fb0: r0 = AllocateDouble()
    //     0x667fb0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x667fb4: RestoreReg d0
    //     0x667fb4: ldr             q0, [SP], #0x10
    // 0x667fb8: b               #0x667ed8
    // 0x667fbc: stp             q0, q1, [SP, #-0x20]!
    // 0x667fc0: stp             x1, x2, [SP, #-0x10]!
    // 0x667fc4: r0 = AllocateDouble()
    //     0x667fc4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x667fc8: ldp             x1, x2, [SP], #0x10
    // 0x667fcc: ldp             q0, q1, [SP], #0x20
    // 0x667fd0: b               #0x667f50
  }
  _ toImage(/* No info */) async {
    // ** addr: 0x912b2c, size: 0x19c
    // 0x912b2c: EnterFrame
    //     0x912b2c: stp             fp, lr, [SP, #-0x10]!
    //     0x912b30: mov             fp, SP
    // 0x912b34: AllocStack(0x70)
    //     0x912b34: sub             SP, SP, #0x70
    // 0x912b38: SetupParameters(OffsetLayer this /* r1, fp-0x68 */, dynamic _ /* r2, fp-0x60 */, dynamic _ /* d0, fp-0x70 */)
    //     0x912b38: stur            NULL, [fp, #-8]
    //     0x912b3c: mov             x0, #0
    //     0x912b40: add             x1, fp, w0, sxtw #2
    //     0x912b44: ldr             x1, [x1, #0x20]
    //     0x912b48: stur            x1, [fp, #-0x68]
    //     0x912b4c: add             x2, fp, w0, sxtw #2
    //     0x912b50: ldr             x2, [x2, #0x18]
    //     0x912b54: stur            x2, [fp, #-0x60]
    //     0x912b58: add             x3, fp, w0, sxtw #2
    //     0x912b5c: ldr             d0, [x3, #0x10]
    //     0x912b60: stur            d0, [fp, #-0x70]
    // 0x912b64: CheckStackOverflow
    //     0x912b64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x912b68: cmp             SP, x16
    //     0x912b6c: b.ls            #0x912c68
    // 0x912b70: InitAsync() -> Future<Image>
    //     0x912b70: ldr             x0, [PP, #0x2608]  ; [pp+0x2608] TypeArguments: <Image>
    //     0x912b74: bl              #0x4b92e4
    // 0x912b78: ldur            x16, [fp, #-0x68]
    // 0x912b7c: ldur            lr, [fp, #-0x60]
    // 0x912b80: stp             lr, x16, [SP, #-0x10]!
    // 0x912b84: ldur            d0, [fp, #-0x70]
    // 0x912b88: SaveReg d0
    //     0x912b88: str             d0, [SP, #-8]!
    // 0x912b8c: r0 = _createSceneForImage()
    //     0x912b8c: bl              #0x667e84  ; [package:flutter/src/rendering/layer.dart] OffsetLayer::_createSceneForImage
    // 0x912b90: add             SP, SP, #0x18
    // 0x912b94: stur            x0, [fp, #-0x68]
    // 0x912b98: ldur            x1, [fp, #-0x60]
    // 0x912b9c: ldur            d0, [fp, #-0x70]
    // 0x912ba0: LoadField: d1 = r1->field_17
    //     0x912ba0: ldur            d1, [x1, #0x17]
    // 0x912ba4: LoadField: d2 = r1->field_7
    //     0x912ba4: ldur            d2, [x1, #7]
    // 0x912ba8: fsub            d3, d1, d2
    // 0x912bac: fmul            d1, d0, d3
    // 0x912bb0: fcmp            d1, d1
    // 0x912bb4: b.vs            #0x912c70
    // 0x912bb8: fcvtps          x2, d1
    // 0x912bbc: asr             x16, x2, #0x1e
    // 0x912bc0: cmp             x16, x2, asr #63
    // 0x912bc4: b.ne            #0x912c70
    // 0x912bc8: lsl             x2, x2, #1
    // 0x912bcc: LoadField: d1 = r1->field_1f
    //     0x912bcc: ldur            d1, [x1, #0x1f]
    // 0x912bd0: LoadField: d2 = r1->field_f
    //     0x912bd0: ldur            d2, [x1, #0xf]
    // 0x912bd4: fsub            d3, d1, d2
    // 0x912bd8: fmul            d1, d0, d3
    // 0x912bdc: fcmp            d1, d1
    // 0x912be0: b.vs            #0x912c9c
    // 0x912be4: fcvtps          x1, d1
    // 0x912be8: asr             x16, x1, #0x1e
    // 0x912bec: cmp             x16, x1, asr #63
    // 0x912bf0: b.ne            #0x912c9c
    // 0x912bf4: lsl             x1, x1, #1
    // 0x912bf8: r3 = LoadInt32Instr(r1)
    //     0x912bf8: sbfx            x3, x1, #1, #0x1f
    //     0x912bfc: tbz             w1, #0, #0x912c04
    //     0x912c00: ldur            x3, [x1, #7]
    // 0x912c04: stp             x2, x0, [SP, #-0x10]!
    // 0x912c08: SaveReg r3
    //     0x912c08: str             x3, [SP, #-8]!
    // 0x912c0c: r0 = toImage()
    //     0x912c0c: bl              #0x912cc8  ; [dart:ui] Scene::toImage
    // 0x912c10: add             SP, SP, #0x18
    // 0x912c14: mov             x1, x0
    // 0x912c18: stur            x1, [fp, #-0x60]
    // 0x912c1c: r0 = Await()
    //     0x912c1c: bl              #0x4b8e6c  ; AwaitStub
    // 0x912c20: stur            x0, [fp, #-0x60]
    // 0x912c24: ldur            x16, [fp, #-0x68]
    // 0x912c28: SaveReg r16
    //     0x912c28: str             x16, [SP, #-8]!
    // 0x912c2c: r0 = dispose()
    //     0x912c2c: bl              #0x5dd184  ; [dart:ui] Scene::dispose
    // 0x912c30: add             SP, SP, #8
    // 0x912c34: ldur            x0, [fp, #-0x60]
    // 0x912c38: r0 = ReturnAsync()
    //     0x912c38: b               #0x501858  ; ReturnAsyncStub
    // 0x912c3c: sub             SP, fp, #0x70
    // 0x912c40: stur            x0, [fp, #-0x60]
    // 0x912c44: stur            x1, [fp, #-0x68]
    // 0x912c48: ldur            x16, [fp, #-0x58]
    // 0x912c4c: SaveReg r16
    //     0x912c4c: str             x16, [SP, #-8]!
    // 0x912c50: r0 = dispose()
    //     0x912c50: bl              #0x5dd184  ; [dart:ui] Scene::dispose
    // 0x912c54: add             SP, SP, #8
    // 0x912c58: ldur            x0, [fp, #-0x60]
    // 0x912c5c: ldur            x1, [fp, #-0x68]
    // 0x912c60: r0 = ReThrow()
    //     0x912c60: bl              #0xd67e14  ; ReThrowStub
    // 0x912c64: brk             #0
    // 0x912c68: r0 = StackOverflowSharedWithFPURegs()
    //     0x912c68: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x912c6c: b               #0x912b70
    // 0x912c70: stp             q0, q1, [SP, #-0x20]!
    // 0x912c74: stp             x0, x1, [SP, #-0x10]!
    // 0x912c78: d0 = 0.000000
    //     0x912c78: fmov            d0, d1
    // 0x912c7c: r0 = 208
    //     0x912c7c: mov             x0, #0xd0
    // 0x912c80: r24 = DoubleToIntegerStub
    //     0x912c80: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x912c84: LoadField: r30 = r24->field_7
    //     0x912c84: ldur            lr, [x24, #7]
    // 0x912c88: blr             lr
    // 0x912c8c: mov             x2, x0
    // 0x912c90: ldp             x0, x1, [SP], #0x10
    // 0x912c94: ldp             q0, q1, [SP], #0x20
    // 0x912c98: b               #0x912bcc
    // 0x912c9c: SaveReg d1
    //     0x912c9c: str             q1, [SP, #-0x10]!
    // 0x912ca0: stp             x0, x2, [SP, #-0x10]!
    // 0x912ca4: d0 = 0.000000
    //     0x912ca4: fmov            d0, d1
    // 0x912ca8: r0 = 208
    //     0x912ca8: mov             x0, #0xd0
    // 0x912cac: r24 = DoubleToIntegerStub
    //     0x912cac: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x912cb0: LoadField: r30 = r24->field_7
    //     0x912cb0: ldur            lr, [x24, #7]
    // 0x912cb4: blr             lr
    // 0x912cb8: mov             x1, x0
    // 0x912cbc: ldp             x0, x2, [SP], #0x10
    // 0x912cc0: RestoreReg d1
    //     0x912cc0: ldr             q1, [SP], #0x10
    // 0x912cc4: b               #0x912bf8
  }
  _ addToScene(/* No info */) {
    // ** addr: 0xa850c0, size: 0x114
    // 0xa850c0: EnterFrame
    //     0xa850c0: stp             fp, lr, [SP, #-0x10]!
    //     0xa850c4: mov             fp, SP
    // 0xa850c8: AllocStack(0x18)
    //     0xa850c8: sub             SP, SP, #0x18
    // 0xa850cc: CheckStackOverflow
    //     0xa850cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa850d0: cmp             SP, x16
    //     0xa850d4: b.ls            #0xa851bc
    // 0xa850d8: ldr             x3, [fp, #0x18]
    // 0xa850dc: LoadField: r0 = r3->field_47
    //     0xa850dc: ldur            w0, [x3, #0x47]
    // 0xa850e0: DecompressPointer r0
    //     0xa850e0: add             x0, x0, HEAP, lsl #32
    // 0xa850e4: LoadField: d0 = r0->field_7
    //     0xa850e4: ldur            d0, [x0, #7]
    // 0xa850e8: stur            d0, [fp, #-0x18]
    // 0xa850ec: LoadField: d1 = r0->field_f
    //     0xa850ec: ldur            d1, [x0, #0xf]
    // 0xa850f0: stur            d1, [fp, #-0x10]
    // 0xa850f4: LoadField: r4 = r3->field_33
    //     0xa850f4: ldur            w4, [x3, #0x33]
    // 0xa850f8: DecompressPointer r4
    //     0xa850f8: add             x4, x4, HEAP, lsl #32
    // 0xa850fc: mov             x0, x4
    // 0xa85100: stur            x4, [fp, #-8]
    // 0xa85104: r2 = Null
    //     0xa85104: mov             x2, NULL
    // 0xa85108: r1 = Null
    //     0xa85108: mov             x1, NULL
    // 0xa8510c: r4 = LoadClassIdInstr(r0)
    //     0xa8510c: ldur            x4, [x0, #-1]
    //     0xa85110: ubfx            x4, x4, #0xc, #0x14
    // 0xa85114: r17 = 5083
    //     0xa85114: mov             x17, #0x13db
    // 0xa85118: cmp             x4, x17
    // 0xa8511c: b.eq            #0xa8512c
    // 0xa85120: r8 = OffsetEngineLayer?
    //     0xa85120: ldr             x8, [PP, #0x73a8]  ; [pp+0x73a8] Type: OffsetEngineLayer?
    // 0xa85124: r3 = Null
    //     0xa85124: ldr             x3, [PP, #0x73b0]  ; [pp+0x73b0] Null
    // 0xa85128: r0 = DefaultNullableTypeTest()
    //     0xa85128: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xa8512c: ldur            d0, [fp, #-0x18]
    // 0xa85130: r0 = inline_Allocate_Double()
    //     0xa85130: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa85134: add             x0, x0, #0x10
    //     0xa85138: cmp             x1, x0
    //     0xa8513c: b.ls            #0xa851c4
    //     0xa85140: str             x0, [THR, #0x60]  ; THR::top
    //     0xa85144: sub             x0, x0, #0xf
    //     0xa85148: mov             x1, #0xd108
    //     0xa8514c: movk            x1, #3, lsl #16
    //     0xa85150: stur            x1, [x0, #-1]
    // 0xa85154: StoreField: r0->field_7 = d0
    //     0xa85154: stur            d0, [x0, #7]
    // 0xa85158: ldr             x16, [fp, #0x10]
    // 0xa8515c: stp             x0, x16, [SP, #-0x10]!
    // 0xa85160: ldur            d0, [fp, #-0x10]
    // 0xa85164: SaveReg d0
    //     0xa85164: str             d0, [SP, #-8]!
    // 0xa85168: ldur            x16, [fp, #-8]
    // 0xa8516c: SaveReg r16
    //     0xa8516c: str             x16, [SP, #-8]!
    // 0xa85170: r0 = pushOffset()
    //     0xa85170: bl              #0xa84778  ; [dart:ui] SceneBuilder::pushOffset
    // 0xa85174: add             SP, SP, #0x20
    // 0xa85178: ldr             x16, [fp, #0x18]
    // 0xa8517c: stp             x0, x16, [SP, #-0x10]!
    // 0xa85180: r0 = engineLayer=()
    //     0xa85180: bl              #0x661300  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0xa85184: add             SP, SP, #0x10
    // 0xa85188: ldr             x16, [fp, #0x18]
    // 0xa8518c: ldr             lr, [fp, #0x10]
    // 0xa85190: stp             lr, x16, [SP, #-0x10]!
    // 0xa85194: r0 = addChildrenToScene()
    //     0xa85194: bl              #0xa84130  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0xa85198: add             SP, SP, #0x10
    // 0xa8519c: ldr             x16, [fp, #0x10]
    // 0xa851a0: SaveReg r16
    //     0xa851a0: str             x16, [SP, #-8]!
    // 0xa851a4: r0 = pop()
    //     0xa851a4: bl              #0xa83f3c  ; [dart:ui] SceneBuilder::pop
    // 0xa851a8: add             SP, SP, #8
    // 0xa851ac: r0 = Null
    //     0xa851ac: mov             x0, NULL
    // 0xa851b0: LeaveFrame
    //     0xa851b0: mov             SP, fp
    //     0xa851b4: ldp             fp, lr, [SP], #0x10
    // 0xa851b8: ret
    //     0xa851b8: ret             
    // 0xa851bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa851bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa851c0: b               #0xa850d8
    // 0xa851c4: SaveReg d0
    //     0xa851c4: str             q0, [SP, #-0x10]!
    // 0xa851c8: r0 = AllocateDouble()
    //     0xa851c8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa851cc: RestoreReg d0
    //     0xa851cc: ldr             q0, [SP], #0x10
    // 0xa851d0: b               #0xa85154
  }
  _ findAnnotations(/* No info */) {
    // ** addr: 0xa8c748, size: 0xa4
    // 0xa8c748: EnterFrame
    //     0xa8c748: stp             fp, lr, [SP, #-0x10]!
    //     0xa8c74c: mov             fp, SP
    // 0xa8c750: AllocStack(0x8)
    //     0xa8c750: sub             SP, SP, #8
    // 0xa8c754: SetupParameters()
    //     0xa8c754: mov             x0, x4
    //     0xa8c758: ldur            w1, [x0, #0xf]
    //     0xa8c75c: add             x1, x1, HEAP, lsl #32
    //     0xa8c760: cbnz            w1, #0xa8c76c
    //     0xa8c764: mov             x0, NULL
    //     0xa8c768: b               #0xa8c77c
    //     0xa8c76c: ldur            w2, [x0, #0x17]
    //     0xa8c770: add             x2, x2, HEAP, lsl #32
    //     0xa8c774: add             x0, fp, w2, sxtw #2
    //     0xa8c778: ldr             x0, [x0, #0x10]
    // 0xa8c77c: CheckStackOverflow
    //     0xa8c77c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8c780: cmp             SP, x16
    //     0xa8c784: b.ls            #0xa8c7e4
    // 0xa8c788: cbnz            w1, #0xa8c794
    // 0xa8c78c: r1 = <Object>
    //     0xa8c78c: ldr             x1, [PP, #0x1d8]  ; [pp+0x1d8] TypeArguments: <Object>
    // 0xa8c790: b               #0xa8c798
    // 0xa8c794: mov             x1, x0
    // 0xa8c798: ldr             x0, [fp, #0x20]
    // 0xa8c79c: stur            x1, [fp, #-8]
    // 0xa8c7a0: LoadField: r2 = r0->field_47
    //     0xa8c7a0: ldur            w2, [x0, #0x47]
    // 0xa8c7a4: DecompressPointer r2
    //     0xa8c7a4: add             x2, x2, HEAP, lsl #32
    // 0xa8c7a8: ldr             x16, [fp, #0x10]
    // 0xa8c7ac: stp             x2, x16, [SP, #-0x10]!
    // 0xa8c7b0: r0 = -()
    //     0xa8c7b0: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xa8c7b4: add             SP, SP, #0x10
    // 0xa8c7b8: ldur            x16, [fp, #-8]
    // 0xa8c7bc: ldr             lr, [fp, #0x20]
    // 0xa8c7c0: stp             lr, x16, [SP, #-0x10]!
    // 0xa8c7c4: ldr             x16, [fp, #0x18]
    // 0xa8c7c8: stp             x0, x16, [SP, #-0x10]!
    // 0xa8c7cc: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xa8c7cc: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xa8c7d0: r0 = findAnnotations()
    //     0xa8c7d0: bl              #0xa8d380  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::findAnnotations
    // 0xa8c7d4: add             SP, SP, #0x20
    // 0xa8c7d8: LeaveFrame
    //     0xa8c7d8: mov             SP, fp
    //     0xa8c7dc: ldp             fp, lr, [SP], #0x10
    // 0xa8c7e0: ret
    //     0xa8c7e0: ret             
    // 0xa8c7e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8c7e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8c7e8: b               #0xa8c788
  }
  _ applyTransform(/* No info */) {
    // ** addr: 0xbd48f8, size: 0x8c
    // 0xbd48f8: EnterFrame
    //     0xbd48f8: stp             fp, lr, [SP, #-0x10]!
    //     0xbd48fc: mov             fp, SP
    // 0xbd4900: CheckStackOverflow
    //     0xbd4900: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd4904: cmp             SP, x16
    //     0xbd4908: b.ls            #0xbd496c
    // 0xbd490c: ldr             x0, [fp, #0x18]
    // 0xbd4910: LoadField: r1 = r0->field_47
    //     0xbd4910: ldur            w1, [x0, #0x47]
    // 0xbd4914: DecompressPointer r1
    //     0xbd4914: add             x1, x1, HEAP, lsl #32
    // 0xbd4918: LoadField: d0 = r1->field_7
    //     0xbd4918: ldur            d0, [x1, #7]
    // 0xbd491c: LoadField: d1 = r1->field_f
    //     0xbd491c: ldur            d1, [x1, #0xf]
    // 0xbd4920: r0 = inline_Allocate_Double()
    //     0xbd4920: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbd4924: add             x0, x0, #0x10
    //     0xbd4928: cmp             x1, x0
    //     0xbd492c: b.ls            #0xbd4974
    //     0xbd4930: str             x0, [THR, #0x60]  ; THR::top
    //     0xbd4934: sub             x0, x0, #0xf
    //     0xbd4938: mov             x1, #0xd108
    //     0xbd493c: movk            x1, #3, lsl #16
    //     0xbd4940: stur            x1, [x0, #-1]
    // 0xbd4944: StoreField: r0->field_7 = d0
    //     0xbd4944: stur            d0, [x0, #7]
    // 0xbd4948: ldr             x16, [fp, #0x10]
    // 0xbd494c: stp             x0, x16, [SP, #-0x10]!
    // 0xbd4950: SaveReg d1
    //     0xbd4950: str             d1, [SP, #-8]!
    // 0xbd4954: r0 = translate()
    //     0xbd4954: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0xbd4958: add             SP, SP, #0x18
    // 0xbd495c: r0 = Null
    //     0xbd495c: mov             x0, NULL
    // 0xbd4960: LeaveFrame
    //     0xbd4960: mov             SP, fp
    //     0xbd4964: ldp             fp, lr, [SP], #0x10
    // 0xbd4968: ret
    //     0xbd4968: ret             
    // 0xbd496c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd496c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd4970: b               #0xbd490c
    // 0xbd4974: stp             q0, q1, [SP, #-0x20]!
    // 0xbd4978: r0 = AllocateDouble()
    //     0xbd4978: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbd497c: ldp             q0, q1, [SP], #0x20
    // 0xbd4980: b               #0xbd4944
  }
}

// class id: 2391, size: 0x50, field offset: 0x4c
class OpacityLayer extends OffsetLayer {

  set _ alpha=(/* No info */) {
    // ** addr: 0x661234, size: 0xcc
    // 0x661234: EnterFrame
    //     0x661234: stp             fp, lr, [SP, #-0x10]!
    //     0x661238: mov             fp, SP
    // 0x66123c: CheckStackOverflow
    //     0x66123c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x661240: cmp             SP, x16
    //     0x661244: b.ls            #0x6612f8
    // 0x661248: ldr             x0, [fp, #0x18]
    // 0x66124c: LoadField: r1 = r0->field_4b
    //     0x66124c: ldur            w1, [x0, #0x4b]
    // 0x661250: DecompressPointer r1
    //     0x661250: add             x1, x1, HEAP, lsl #32
    // 0x661254: ldr             x2, [fp, #0x10]
    // 0x661258: cmp             w2, w1
    // 0x66125c: b.eq            #0x6612e8
    // 0x661260: and             w16, w2, w1
    // 0x661264: branchIfSmi(r16, 0x661298)
    //     0x661264: tbz             w16, #0, #0x661298
    // 0x661268: r16 = LoadClassIdInstr(r2)
    //     0x661268: ldur            x16, [x2, #-1]
    //     0x66126c: ubfx            x16, x16, #0xc, #0x14
    // 0x661270: cmp             x16, #0x3c
    // 0x661274: b.ne            #0x661298
    // 0x661278: r16 = LoadClassIdInstr(r1)
    //     0x661278: ldur            x16, [x1, #-1]
    //     0x66127c: ubfx            x16, x16, #0xc, #0x14
    // 0x661280: cmp             x16, #0x3c
    // 0x661284: b.ne            #0x661298
    // 0x661288: LoadField: r16 = r2->field_7
    //     0x661288: ldur            x16, [x2, #7]
    // 0x66128c: LoadField: r17 = r1->field_7
    //     0x66128c: ldur            x17, [x1, #7]
    // 0x661290: cmp             x16, x17
    // 0x661294: b.eq            #0x6612e8
    // 0x661298: cmp             w2, #0x1fe
    // 0x66129c: b.eq            #0x6612a8
    // 0x6612a0: cmp             w1, #0x1fe
    // 0x6612a4: b.ne            #0x6612b4
    // 0x6612a8: stp             NULL, x0, [SP, #-0x10]!
    // 0x6612ac: r0 = engineLayer=()
    //     0x6612ac: bl              #0x661300  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0x6612b0: add             SP, SP, #0x10
    // 0x6612b4: ldr             x1, [fp, #0x18]
    // 0x6612b8: ldr             x0, [fp, #0x10]
    // 0x6612bc: StoreField: r1->field_4b = r0
    //     0x6612bc: stur            w0, [x1, #0x4b]
    //     0x6612c0: tbz             w0, #0, #0x6612dc
    //     0x6612c4: ldurb           w16, [x1, #-1]
    //     0x6612c8: ldurb           w17, [x0, #-1]
    //     0x6612cc: and             x16, x17, x16, lsr #2
    //     0x6612d0: tst             x16, HEAP, lsr #32
    //     0x6612d4: b.eq            #0x6612dc
    //     0x6612d8: bl              #0xd6826c
    // 0x6612dc: SaveReg r1
    //     0x6612dc: str             x1, [SP, #-8]!
    // 0x6612e0: r0 = markNeedsAddToScene()
    //     0x6612e0: bl              #0x5dec74  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0x6612e4: add             SP, SP, #8
    // 0x6612e8: r0 = Null
    //     0x6612e8: mov             x0, NULL
    // 0x6612ec: LeaveFrame
    //     0x6612ec: mov             SP, fp
    //     0x6612f0: ldp             fp, lr, [SP], #0x10
    // 0x6612f4: ret
    //     0x6612f4: ret             
    // 0x6612f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6612f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6612fc: b               #0x661248
  }
  _ addToScene(/* No info */) {
    // ** addr: 0xa84570, size: 0x208
    // 0xa84570: EnterFrame
    //     0xa84570: stp             fp, lr, [SP, #-0x10]!
    //     0xa84574: mov             fp, SP
    // 0xa84578: AllocStack(0x28)
    //     0xa84578: sub             SP, SP, #0x28
    // 0xa8457c: CheckStackOverflow
    //     0xa8457c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa84580: cmp             SP, x16
    //     0xa84584: b.ls            #0xa8475c
    // 0xa84588: ldr             x3, [fp, #0x18]
    // 0xa8458c: LoadField: r0 = r3->field_3f
    //     0xa8458c: ldur            w0, [x3, #0x3f]
    // 0xa84590: DecompressPointer r0
    //     0xa84590: add             x0, x0, HEAP, lsl #32
    // 0xa84594: cmp             w0, NULL
    // 0xa84598: r16 = true
    //     0xa84598: add             x16, NULL, #0x20  ; true
    // 0xa8459c: r17 = false
    //     0xa8459c: add             x17, NULL, #0x30  ; false
    // 0xa845a0: csel            x1, x16, x17, ne
    // 0xa845a4: tbz             w1, #4, #0xa845c4
    // 0xa845a8: stp             NULL, x3, [SP, #-0x10]!
    // 0xa845ac: r0 = engineLayer=()
    //     0xa845ac: bl              #0x661300  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0xa845b0: add             SP, SP, #0x10
    // 0xa845b4: r0 = Null
    //     0xa845b4: mov             x0, NULL
    // 0xa845b8: LeaveFrame
    //     0xa845b8: mov             SP, fp
    //     0xa845bc: ldp             fp, lr, [SP], #0x10
    // 0xa845c0: ret
    //     0xa845c0: ret             
    // 0xa845c4: LoadField: r0 = r3->field_4b
    //     0xa845c4: ldur            w0, [x3, #0x4b]
    // 0xa845c8: DecompressPointer r0
    //     0xa845c8: add             x0, x0, HEAP, lsl #32
    // 0xa845cc: cmp             w0, NULL
    // 0xa845d0: b.eq            #0xa84764
    // 0xa845d4: tbnz            w1, #4, #0xa84674
    // 0xa845d8: r4 = LoadInt32Instr(r0)
    //     0xa845d8: sbfx            x4, x0, #1, #0x1f
    //     0xa845dc: tbz             w0, #0, #0xa845e4
    //     0xa845e0: ldur            x4, [x0, #7]
    // 0xa845e4: stur            x4, [fp, #-0x18]
    // 0xa845e8: cmp             x4, #0xff
    // 0xa845ec: b.ge            #0xa84674
    // 0xa845f0: LoadField: r5 = r3->field_47
    //     0xa845f0: ldur            w5, [x3, #0x47]
    // 0xa845f4: DecompressPointer r5
    //     0xa845f4: add             x5, x5, HEAP, lsl #32
    // 0xa845f8: stur            x5, [fp, #-0x10]
    // 0xa845fc: LoadField: r6 = r3->field_33
    //     0xa845fc: ldur            w6, [x3, #0x33]
    // 0xa84600: DecompressPointer r6
    //     0xa84600: add             x6, x6, HEAP, lsl #32
    // 0xa84604: mov             x0, x6
    // 0xa84608: stur            x6, [fp, #-8]
    // 0xa8460c: r2 = Null
    //     0xa8460c: mov             x2, NULL
    // 0xa84610: r1 = Null
    //     0xa84610: mov             x1, NULL
    // 0xa84614: r4 = LoadClassIdInstr(r0)
    //     0xa84614: ldur            x4, [x0, #-1]
    //     0xa84618: ubfx            x4, x4, #0xc, #0x14
    // 0xa8461c: r17 = 5079
    //     0xa8461c: mov             x17, #0x13d7
    // 0xa84620: cmp             x4, x17
    // 0xa84624: b.eq            #0xa8463c
    // 0xa84628: r8 = OpacityEngineLayer?
    //     0xa84628: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d6d0] Type: OpacityEngineLayer?
    //     0xa8462c: ldr             x8, [x8, #0x6d0]
    // 0xa84630: r3 = Null
    //     0xa84630: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2d6d8] Null
    //     0xa84634: ldr             x3, [x3, #0x6d8]
    // 0xa84638: r0 = DefaultNullableTypeTest()
    //     0xa84638: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xa8463c: ldr             x16, [fp, #0x10]
    // 0xa84640: SaveReg r16
    //     0xa84640: str             x16, [SP, #-8]!
    // 0xa84644: ldur            x0, [fp, #-0x18]
    // 0xa84648: ldur            x16, [fp, #-0x10]
    // 0xa8464c: stp             x16, x0, [SP, #-0x10]!
    // 0xa84650: ldur            x16, [fp, #-8]
    // 0xa84654: SaveReg r16
    //     0xa84654: str             x16, [SP, #-8]!
    // 0xa84658: r0 = pushOpacity()
    //     0xa84658: bl              #0xa84bc4  ; [dart:ui] SceneBuilder::pushOpacity
    // 0xa8465c: add             SP, SP, #0x20
    // 0xa84660: ldr             x16, [fp, #0x18]
    // 0xa84664: stp             x0, x16, [SP, #-0x10]!
    // 0xa84668: r0 = engineLayer=()
    //     0xa84668: bl              #0x661300  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0xa8466c: add             SP, SP, #0x10
    // 0xa84670: b               #0xa84728
    // 0xa84674: ldr             x3, [fp, #0x18]
    // 0xa84678: LoadField: r0 = r3->field_47
    //     0xa84678: ldur            w0, [x3, #0x47]
    // 0xa8467c: DecompressPointer r0
    //     0xa8467c: add             x0, x0, HEAP, lsl #32
    // 0xa84680: LoadField: d0 = r0->field_7
    //     0xa84680: ldur            d0, [x0, #7]
    // 0xa84684: stur            d0, [fp, #-0x28]
    // 0xa84688: LoadField: d1 = r0->field_f
    //     0xa84688: ldur            d1, [x0, #0xf]
    // 0xa8468c: stur            d1, [fp, #-0x20]
    // 0xa84690: LoadField: r4 = r3->field_33
    //     0xa84690: ldur            w4, [x3, #0x33]
    // 0xa84694: DecompressPointer r4
    //     0xa84694: add             x4, x4, HEAP, lsl #32
    // 0xa84698: mov             x0, x4
    // 0xa8469c: stur            x4, [fp, #-8]
    // 0xa846a0: r2 = Null
    //     0xa846a0: mov             x2, NULL
    // 0xa846a4: r1 = Null
    //     0xa846a4: mov             x1, NULL
    // 0xa846a8: r4 = LoadClassIdInstr(r0)
    //     0xa846a8: ldur            x4, [x0, #-1]
    //     0xa846ac: ubfx            x4, x4, #0xc, #0x14
    // 0xa846b0: r17 = 5083
    //     0xa846b0: mov             x17, #0x13db
    // 0xa846b4: cmp             x4, x17
    // 0xa846b8: b.eq            #0xa846cc
    // 0xa846bc: r8 = OffsetEngineLayer?
    //     0xa846bc: ldr             x8, [PP, #0x73a8]  ; [pp+0x73a8] Type: OffsetEngineLayer?
    // 0xa846c0: r3 = Null
    //     0xa846c0: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2d6e8] Null
    //     0xa846c4: ldr             x3, [x3, #0x6e8]
    // 0xa846c8: r0 = DefaultNullableTypeTest()
    //     0xa846c8: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xa846cc: ldur            d0, [fp, #-0x28]
    // 0xa846d0: r0 = inline_Allocate_Double()
    //     0xa846d0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa846d4: add             x0, x0, #0x10
    //     0xa846d8: cmp             x1, x0
    //     0xa846dc: b.ls            #0xa84768
    //     0xa846e0: str             x0, [THR, #0x60]  ; THR::top
    //     0xa846e4: sub             x0, x0, #0xf
    //     0xa846e8: mov             x1, #0xd108
    //     0xa846ec: movk            x1, #3, lsl #16
    //     0xa846f0: stur            x1, [x0, #-1]
    // 0xa846f4: StoreField: r0->field_7 = d0
    //     0xa846f4: stur            d0, [x0, #7]
    // 0xa846f8: ldr             x16, [fp, #0x10]
    // 0xa846fc: stp             x0, x16, [SP, #-0x10]!
    // 0xa84700: ldur            d0, [fp, #-0x20]
    // 0xa84704: SaveReg d0
    //     0xa84704: str             d0, [SP, #-8]!
    // 0xa84708: ldur            x16, [fp, #-8]
    // 0xa8470c: SaveReg r16
    //     0xa8470c: str             x16, [SP, #-8]!
    // 0xa84710: r0 = pushOffset()
    //     0xa84710: bl              #0xa84778  ; [dart:ui] SceneBuilder::pushOffset
    // 0xa84714: add             SP, SP, #0x20
    // 0xa84718: ldr             x16, [fp, #0x18]
    // 0xa8471c: stp             x0, x16, [SP, #-0x10]!
    // 0xa84720: r0 = engineLayer=()
    //     0xa84720: bl              #0x661300  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0xa84724: add             SP, SP, #0x10
    // 0xa84728: ldr             x16, [fp, #0x18]
    // 0xa8472c: ldr             lr, [fp, #0x10]
    // 0xa84730: stp             lr, x16, [SP, #-0x10]!
    // 0xa84734: r0 = addChildrenToScene()
    //     0xa84734: bl              #0xa84130  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0xa84738: add             SP, SP, #0x10
    // 0xa8473c: ldr             x16, [fp, #0x10]
    // 0xa84740: SaveReg r16
    //     0xa84740: str             x16, [SP, #-8]!
    // 0xa84744: r0 = pop()
    //     0xa84744: bl              #0xa83f3c  ; [dart:ui] SceneBuilder::pop
    // 0xa84748: add             SP, SP, #8
    // 0xa8474c: r0 = Null
    //     0xa8474c: mov             x0, NULL
    // 0xa84750: LeaveFrame
    //     0xa84750: mov             SP, fp
    //     0xa84754: ldp             fp, lr, [SP], #0x10
    // 0xa84758: ret
    //     0xa84758: ret             
    // 0xa8475c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8475c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa84760: b               #0xa84588
    // 0xa84764: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa84764: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa84768: SaveReg d0
    //     0xa84768: str             q0, [SP, #-0x10]!
    // 0xa8476c: r0 = AllocateDouble()
    //     0xa8476c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa84770: RestoreReg d0
    //     0xa84770: ldr             q0, [SP], #0x10
    // 0xa84774: b               #0xa846f4
  }
}

// class id: 2392, size: 0x5c, field offset: 0x4c
class TransformLayer extends OffsetLayer {

  set _ transform=(/* No info */) {
    // ** addr: 0x65d728, size: 0x94
    // 0x65d728: EnterFrame
    //     0x65d728: stp             fp, lr, [SP, #-0x10]!
    //     0x65d72c: mov             fp, SP
    // 0x65d730: CheckStackOverflow
    //     0x65d730: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65d734: cmp             SP, x16
    //     0x65d738: b.ls            #0x65d7b4
    // 0x65d73c: ldr             x0, [fp, #0x18]
    // 0x65d740: LoadField: r1 = r0->field_4b
    //     0x65d740: ldur            w1, [x0, #0x4b]
    // 0x65d744: DecompressPointer r1
    //     0x65d744: add             x1, x1, HEAP, lsl #32
    // 0x65d748: ldr             x16, [fp, #0x10]
    // 0x65d74c: stp             x1, x16, [SP, #-0x10]!
    // 0x65d750: r0 = ==()
    //     0x65d750: bl              #0xc9e014  ; [package:vector_math/vector_math_64.dart] Matrix4::==
    // 0x65d754: add             SP, SP, #0x10
    // 0x65d758: tbnz            w0, #4, #0x65d76c
    // 0x65d75c: r0 = Null
    //     0x65d75c: mov             x0, NULL
    // 0x65d760: LeaveFrame
    //     0x65d760: mov             SP, fp
    //     0x65d764: ldp             fp, lr, [SP], #0x10
    // 0x65d768: ret
    //     0x65d768: ret             
    // 0x65d76c: ldr             x1, [fp, #0x18]
    // 0x65d770: r2 = true
    //     0x65d770: add             x2, NULL, #0x20  ; true
    // 0x65d774: ldr             x0, [fp, #0x10]
    // 0x65d778: StoreField: r1->field_4b = r0
    //     0x65d778: stur            w0, [x1, #0x4b]
    //     0x65d77c: ldurb           w16, [x1, #-1]
    //     0x65d780: ldurb           w17, [x0, #-1]
    //     0x65d784: and             x16, x17, x16, lsr #2
    //     0x65d788: tst             x16, HEAP, lsr #32
    //     0x65d78c: b.eq            #0x65d794
    //     0x65d790: bl              #0xd6826c
    // 0x65d794: StoreField: r1->field_57 = r2
    //     0x65d794: stur            w2, [x1, #0x57]
    // 0x65d798: SaveReg r1
    //     0x65d798: str             x1, [SP, #-8]!
    // 0x65d79c: r0 = markNeedsAddToScene()
    //     0x65d79c: bl              #0x5dec74  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0x65d7a0: add             SP, SP, #8
    // 0x65d7a4: r0 = Null
    //     0x65d7a4: mov             x0, NULL
    // 0x65d7a8: LeaveFrame
    //     0x65d7a8: mov             SP, fp
    //     0x65d7ac: ldp             fp, lr, [SP], #0x10
    // 0x65d7b0: ret
    //     0x65d7b0: ret             
    // 0x65d7b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65d7b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65d7b8: b               #0x65d73c
  }
  _ addToScene(/* No info */) {
    // ** addr: 0xa83d5c, size: 0x1e0
    // 0xa83d5c: EnterFrame
    //     0xa83d5c: stp             fp, lr, [SP, #-0x10]!
    //     0xa83d60: mov             fp, SP
    // 0xa83d64: AllocStack(0x10)
    //     0xa83d64: sub             SP, SP, #0x10
    // 0xa83d68: CheckStackOverflow
    //     0xa83d68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa83d6c: cmp             SP, x16
    //     0xa83d70: b.ls            #0xa83f10
    // 0xa83d74: ldr             x1, [fp, #0x18]
    // 0xa83d78: LoadField: r0 = r1->field_4b
    //     0xa83d78: ldur            w0, [x1, #0x4b]
    // 0xa83d7c: DecompressPointer r0
    //     0xa83d7c: add             x0, x0, HEAP, lsl #32
    // 0xa83d80: StoreField: r1->field_4f = r0
    //     0xa83d80: stur            w0, [x1, #0x4f]
    //     0xa83d84: ldurb           w16, [x1, #-1]
    //     0xa83d88: ldurb           w17, [x0, #-1]
    //     0xa83d8c: and             x16, x17, x16, lsr #2
    //     0xa83d90: tst             x16, HEAP, lsr #32
    //     0xa83d94: b.eq            #0xa83d9c
    //     0xa83d98: bl              #0xd6826c
    // 0xa83d9c: LoadField: r0 = r1->field_47
    //     0xa83d9c: ldur            w0, [x1, #0x47]
    // 0xa83da0: DecompressPointer r0
    //     0xa83da0: add             x0, x0, HEAP, lsl #32
    // 0xa83da4: r16 = Instance_Offset
    //     0xa83da4: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xa83da8: stp             x16, x0, [SP, #-0x10]!
    // 0xa83dac: r0 = ==()
    //     0xa83dac: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0xa83db0: add             SP, SP, #0x10
    // 0xa83db4: tbz             w0, #4, #0xa83e54
    // 0xa83db8: ldr             x0, [fp, #0x18]
    // 0xa83dbc: LoadField: r1 = r0->field_47
    //     0xa83dbc: ldur            w1, [x0, #0x47]
    // 0xa83dc0: DecompressPointer r1
    //     0xa83dc0: add             x1, x1, HEAP, lsl #32
    // 0xa83dc4: LoadField: d0 = r1->field_7
    //     0xa83dc4: ldur            d0, [x1, #7]
    // 0xa83dc8: LoadField: d1 = r1->field_f
    //     0xa83dc8: ldur            d1, [x1, #0xf]
    // 0xa83dcc: r1 = inline_Allocate_Double()
    //     0xa83dcc: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xa83dd0: add             x1, x1, #0x10
    //     0xa83dd4: cmp             x2, x1
    //     0xa83dd8: b.ls            #0xa83f18
    //     0xa83ddc: str             x1, [THR, #0x60]  ; THR::top
    //     0xa83de0: sub             x1, x1, #0xf
    //     0xa83de4: mov             x2, #0xd108
    //     0xa83de8: movk            x2, #3, lsl #16
    //     0xa83dec: stur            x2, [x1, #-1]
    // 0xa83df0: StoreField: r1->field_7 = d0
    //     0xa83df0: stur            d0, [x1, #7]
    // 0xa83df4: stp             x1, NULL, [SP, #-0x10]!
    // 0xa83df8: SaveReg d1
    //     0xa83df8: str             d1, [SP, #-8]!
    // 0xa83dfc: r0 = Matrix4.translationValues()
    //     0xa83dfc: bl              #0x6245d8  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.translationValues
    // 0xa83e00: add             SP, SP, #0x18
    // 0xa83e04: mov             x1, x0
    // 0xa83e08: ldr             x0, [fp, #0x18]
    // 0xa83e0c: stur            x1, [fp, #-8]
    // 0xa83e10: LoadField: r2 = r0->field_4f
    //     0xa83e10: ldur            w2, [x0, #0x4f]
    // 0xa83e14: DecompressPointer r2
    //     0xa83e14: add             x2, x2, HEAP, lsl #32
    // 0xa83e18: cmp             w2, NULL
    // 0xa83e1c: b.eq            #0xa83f34
    // 0xa83e20: stp             x2, x1, [SP, #-0x10]!
    // 0xa83e24: r0 = multiply()
    //     0xa83e24: bl              #0x625d1c  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0xa83e28: add             SP, SP, #0x10
    // 0xa83e2c: ldur            x0, [fp, #-8]
    // 0xa83e30: ldr             x3, [fp, #0x18]
    // 0xa83e34: StoreField: r3->field_4f = r0
    //     0xa83e34: stur            w0, [x3, #0x4f]
    //     0xa83e38: ldurb           w16, [x3, #-1]
    //     0xa83e3c: ldurb           w17, [x0, #-1]
    //     0xa83e40: and             x16, x17, x16, lsr #2
    //     0xa83e44: tst             x16, HEAP, lsr #32
    //     0xa83e48: b.eq            #0xa83e50
    //     0xa83e4c: bl              #0xd682ac
    // 0xa83e50: b               #0xa83e58
    // 0xa83e54: ldr             x3, [fp, #0x18]
    // 0xa83e58: LoadField: r0 = r3->field_4f
    //     0xa83e58: ldur            w0, [x3, #0x4f]
    // 0xa83e5c: DecompressPointer r0
    //     0xa83e5c: add             x0, x0, HEAP, lsl #32
    // 0xa83e60: cmp             w0, NULL
    // 0xa83e64: b.eq            #0xa83f38
    // 0xa83e68: LoadField: r4 = r0->field_7
    //     0xa83e68: ldur            w4, [x0, #7]
    // 0xa83e6c: DecompressPointer r4
    //     0xa83e6c: add             x4, x4, HEAP, lsl #32
    // 0xa83e70: stur            x4, [fp, #-0x10]
    // 0xa83e74: LoadField: r5 = r3->field_33
    //     0xa83e74: ldur            w5, [x3, #0x33]
    // 0xa83e78: DecompressPointer r5
    //     0xa83e78: add             x5, x5, HEAP, lsl #32
    // 0xa83e7c: mov             x0, x5
    // 0xa83e80: stur            x5, [fp, #-8]
    // 0xa83e84: r2 = Null
    //     0xa83e84: mov             x2, NULL
    // 0xa83e88: r1 = Null
    //     0xa83e88: mov             x1, NULL
    // 0xa83e8c: r4 = LoadClassIdInstr(r0)
    //     0xa83e8c: ldur            x4, [x0, #-1]
    //     0xa83e90: ubfx            x4, x4, #0xc, #0x14
    // 0xa83e94: r17 = 5084
    //     0xa83e94: mov             x17, #0x13dc
    // 0xa83e98: cmp             x4, x17
    // 0xa83e9c: b.eq            #0xa83eac
    // 0xa83ea0: r8 = TransformEngineLayer?
    //     0xa83ea0: ldr             x8, [PP, #0x7450]  ; [pp+0x7450] Type: TransformEngineLayer?
    // 0xa83ea4: r3 = Null
    //     0xa83ea4: ldr             x3, [PP, #0x7458]  ; [pp+0x7458] Null
    // 0xa83ea8: r0 = DefaultNullableTypeTest()
    //     0xa83ea8: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xa83eac: ldr             x16, [fp, #0x10]
    // 0xa83eb0: ldur            lr, [fp, #-0x10]
    // 0xa83eb4: stp             lr, x16, [SP, #-0x10]!
    // 0xa83eb8: ldur            x16, [fp, #-8]
    // 0xa83ebc: SaveReg r16
    //     0xa83ebc: str             x16, [SP, #-8]!
    // 0xa83ec0: r4 = const [0, 0x3, 0x3, 0x2, oldLayer, 0x2, null]
    //     0xa83ec0: ldr             x4, [PP, #0x7468]  ; [pp+0x7468] List(7) [0, 0x3, 0x3, 0x2, "oldLayer", 0x2, Null]
    // 0xa83ec4: r0 = pushTransform()
    //     0xa83ec4: bl              #0x667fd4  ; [dart:ui] SceneBuilder::pushTransform
    // 0xa83ec8: add             SP, SP, #0x18
    // 0xa83ecc: ldr             x16, [fp, #0x18]
    // 0xa83ed0: stp             x0, x16, [SP, #-0x10]!
    // 0xa83ed4: r0 = engineLayer=()
    //     0xa83ed4: bl              #0x661300  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0xa83ed8: add             SP, SP, #0x10
    // 0xa83edc: ldr             x16, [fp, #0x18]
    // 0xa83ee0: ldr             lr, [fp, #0x10]
    // 0xa83ee4: stp             lr, x16, [SP, #-0x10]!
    // 0xa83ee8: r0 = addChildrenToScene()
    //     0xa83ee8: bl              #0xa84130  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0xa83eec: add             SP, SP, #0x10
    // 0xa83ef0: ldr             x16, [fp, #0x10]
    // 0xa83ef4: SaveReg r16
    //     0xa83ef4: str             x16, [SP, #-8]!
    // 0xa83ef8: r0 = pop()
    //     0xa83ef8: bl              #0xa83f3c  ; [dart:ui] SceneBuilder::pop
    // 0xa83efc: add             SP, SP, #8
    // 0xa83f00: r0 = Null
    //     0xa83f00: mov             x0, NULL
    // 0xa83f04: LeaveFrame
    //     0xa83f04: mov             SP, fp
    //     0xa83f08: ldp             fp, lr, [SP], #0x10
    // 0xa83f0c: ret
    //     0xa83f0c: ret             
    // 0xa83f10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa83f10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa83f14: b               #0xa83d74
    // 0xa83f18: stp             q0, q1, [SP, #-0x20]!
    // 0xa83f1c: SaveReg r0
    //     0xa83f1c: str             x0, [SP, #-8]!
    // 0xa83f20: r0 = AllocateDouble()
    //     0xa83f20: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa83f24: mov             x1, x0
    // 0xa83f28: RestoreReg r0
    //     0xa83f28: ldr             x0, [SP], #8
    // 0xa83f2c: ldp             q0, q1, [SP], #0x20
    // 0xa83f30: b               #0xa83df0
    // 0xa83f34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa83f34: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa83f38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa83f38: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ findAnnotations(/* No info */) {
    // ** addr: 0xa8c5d8, size: 0xac
    // 0xa8c5d8: EnterFrame
    //     0xa8c5d8: stp             fp, lr, [SP, #-0x10]!
    //     0xa8c5dc: mov             fp, SP
    // 0xa8c5e0: AllocStack(0x8)
    //     0xa8c5e0: sub             SP, SP, #8
    // 0xa8c5e4: SetupParameters()
    //     0xa8c5e4: mov             x0, x4
    //     0xa8c5e8: ldur            w1, [x0, #0xf]
    //     0xa8c5ec: add             x1, x1, HEAP, lsl #32
    //     0xa8c5f0: cbnz            w1, #0xa8c5fc
    //     0xa8c5f4: mov             x0, NULL
    //     0xa8c5f8: b               #0xa8c60c
    //     0xa8c5fc: ldur            w2, [x0, #0x17]
    //     0xa8c600: add             x2, x2, HEAP, lsl #32
    //     0xa8c604: add             x0, fp, w2, sxtw #2
    //     0xa8c608: ldr             x0, [x0, #0x10]
    // 0xa8c60c: CheckStackOverflow
    //     0xa8c60c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8c610: cmp             SP, x16
    //     0xa8c614: b.ls            #0xa8c67c
    // 0xa8c618: cbnz            w1, #0xa8c620
    // 0xa8c61c: r0 = <Object>
    //     0xa8c61c: ldr             x0, [PP, #0x1d8]  ; [pp+0x1d8] TypeArguments: <Object>
    // 0xa8c620: stur            x0, [fp, #-8]
    // 0xa8c624: ldr             x16, [fp, #0x20]
    // 0xa8c628: ldr             lr, [fp, #0x10]
    // 0xa8c62c: stp             lr, x16, [SP, #-0x10]!
    // 0xa8c630: r0 = _transformOffset()
    //     0xa8c630: bl              #0xa8c684  ; [package:flutter/src/rendering/layer.dart] TransformLayer::_transformOffset
    // 0xa8c634: add             SP, SP, #0x10
    // 0xa8c638: cmp             w0, NULL
    // 0xa8c63c: b.ne            #0xa8c650
    // 0xa8c640: r0 = false
    //     0xa8c640: add             x0, NULL, #0x30  ; false
    // 0xa8c644: LeaveFrame
    //     0xa8c644: mov             SP, fp
    //     0xa8c648: ldp             fp, lr, [SP], #0x10
    // 0xa8c64c: ret
    //     0xa8c64c: ret             
    // 0xa8c650: ldur            x16, [fp, #-8]
    // 0xa8c654: ldr             lr, [fp, #0x20]
    // 0xa8c658: stp             lr, x16, [SP, #-0x10]!
    // 0xa8c65c: ldr             x16, [fp, #0x18]
    // 0xa8c660: stp             x0, x16, [SP, #-0x10]!
    // 0xa8c664: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xa8c664: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xa8c668: r0 = findAnnotations()
    //     0xa8c668: bl              #0xa8c748  ; [package:flutter/src/rendering/layer.dart] OffsetLayer::findAnnotations
    // 0xa8c66c: add             SP, SP, #0x20
    // 0xa8c670: LeaveFrame
    //     0xa8c670: mov             SP, fp
    //     0xa8c674: ldp             fp, lr, [SP], #0x10
    // 0xa8c678: ret
    //     0xa8c678: ret             
    // 0xa8c67c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8c67c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8c680: b               #0xa8c618
  }
  _ _transformOffset(/* No info */) {
    // ** addr: 0xa8c684, size: 0xc4
    // 0xa8c684: EnterFrame
    //     0xa8c684: stp             fp, lr, [SP, #-0x10]!
    //     0xa8c688: mov             fp, SP
    // 0xa8c68c: CheckStackOverflow
    //     0xa8c68c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8c690: cmp             SP, x16
    //     0xa8c694: b.ls            #0xa8c73c
    // 0xa8c698: ldr             x0, [fp, #0x18]
    // 0xa8c69c: LoadField: r1 = r0->field_57
    //     0xa8c69c: ldur            w1, [x0, #0x57]
    // 0xa8c6a0: DecompressPointer r1
    //     0xa8c6a0: add             x1, x1, HEAP, lsl #32
    // 0xa8c6a4: tbnz            w1, #4, #0xa8c6fc
    // 0xa8c6a8: LoadField: r1 = r0->field_4b
    //     0xa8c6a8: ldur            w1, [x0, #0x4b]
    // 0xa8c6ac: DecompressPointer r1
    //     0xa8c6ac: add             x1, x1, HEAP, lsl #32
    // 0xa8c6b0: cmp             w1, NULL
    // 0xa8c6b4: b.eq            #0xa8c744
    // 0xa8c6b8: SaveReg r1
    //     0xa8c6b8: str             x1, [SP, #-8]!
    // 0xa8c6bc: r0 = removePerspectiveTransform()
    //     0xa8c6bc: bl              #0x623918  ; [package:flutter/src/gestures/events.dart] PointerEvent::removePerspectiveTransform
    // 0xa8c6c0: add             SP, SP, #8
    // 0xa8c6c4: SaveReg r0
    //     0xa8c6c4: str             x0, [SP, #-8]!
    // 0xa8c6c8: r0 = tryInvert()
    //     0xa8c6c8: bl              #0x623294  ; [package:vector_math/vector_math_64.dart] Matrix4::tryInvert
    // 0xa8c6cc: add             SP, SP, #8
    // 0xa8c6d0: ldr             x1, [fp, #0x18]
    // 0xa8c6d4: StoreField: r1->field_53 = r0
    //     0xa8c6d4: stur            w0, [x1, #0x53]
    //     0xa8c6d8: ldurb           w16, [x1, #-1]
    //     0xa8c6dc: ldurb           w17, [x0, #-1]
    //     0xa8c6e0: and             x16, x17, x16, lsr #2
    //     0xa8c6e4: tst             x16, HEAP, lsr #32
    //     0xa8c6e8: b.eq            #0xa8c6f0
    //     0xa8c6ec: bl              #0xd6826c
    // 0xa8c6f0: r0 = false
    //     0xa8c6f0: add             x0, NULL, #0x30  ; false
    // 0xa8c6f4: StoreField: r1->field_57 = r0
    //     0xa8c6f4: stur            w0, [x1, #0x57]
    // 0xa8c6f8: b               #0xa8c700
    // 0xa8c6fc: mov             x1, x0
    // 0xa8c700: LoadField: r0 = r1->field_53
    //     0xa8c700: ldur            w0, [x1, #0x53]
    // 0xa8c704: DecompressPointer r0
    //     0xa8c704: add             x0, x0, HEAP, lsl #32
    // 0xa8c708: cmp             w0, NULL
    // 0xa8c70c: b.ne            #0xa8c720
    // 0xa8c710: r0 = Null
    //     0xa8c710: mov             x0, NULL
    // 0xa8c714: LeaveFrame
    //     0xa8c714: mov             SP, fp
    //     0xa8c718: ldp             fp, lr, [SP], #0x10
    // 0xa8c71c: ret
    //     0xa8c71c: ret             
    // 0xa8c720: ldr             x16, [fp, #0x10]
    // 0xa8c724: stp             x16, x0, [SP, #-0x10]!
    // 0xa8c728: r0 = transformPoint()
    //     0xa8c728: bl              #0x62313c  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::transformPoint
    // 0xa8c72c: add             SP, SP, #0x10
    // 0xa8c730: LeaveFrame
    //     0xa8c730: mov             SP, fp
    //     0xa8c734: ldp             fp, lr, [SP], #0x10
    // 0xa8c738: ret
    //     0xa8c738: ret             
    // 0xa8c73c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8c73c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8c740: b               #0xa8c698
    // 0xa8c744: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa8c744: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ applyTransform(/* No info */) {
    // ** addr: 0xbd4880, size: 0x78
    // 0xbd4880: EnterFrame
    //     0xbd4880: stp             fp, lr, [SP, #-0x10]!
    //     0xbd4884: mov             fp, SP
    // 0xbd4888: CheckStackOverflow
    //     0xbd4888: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd488c: cmp             SP, x16
    //     0xbd4890: b.ls            #0xbd48ec
    // 0xbd4894: ldr             x0, [fp, #0x18]
    // 0xbd4898: LoadField: r1 = r0->field_4f
    //     0xbd4898: ldur            w1, [x0, #0x4f]
    // 0xbd489c: DecompressPointer r1
    //     0xbd489c: add             x1, x1, HEAP, lsl #32
    // 0xbd48a0: cmp             w1, NULL
    // 0xbd48a4: b.ne            #0xbd48cc
    // 0xbd48a8: LoadField: r1 = r0->field_4b
    //     0xbd48a8: ldur            w1, [x0, #0x4b]
    // 0xbd48ac: DecompressPointer r1
    //     0xbd48ac: add             x1, x1, HEAP, lsl #32
    // 0xbd48b0: cmp             w1, NULL
    // 0xbd48b4: b.eq            #0xbd48f4
    // 0xbd48b8: ldr             x16, [fp, #0x10]
    // 0xbd48bc: stp             x1, x16, [SP, #-0x10]!
    // 0xbd48c0: r0 = multiply()
    //     0xbd48c0: bl              #0x625d1c  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0xbd48c4: add             SP, SP, #0x10
    // 0xbd48c8: b               #0xbd48dc
    // 0xbd48cc: ldr             x16, [fp, #0x10]
    // 0xbd48d0: stp             x1, x16, [SP, #-0x10]!
    // 0xbd48d4: r0 = multiply()
    //     0xbd48d4: bl              #0x625d1c  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0xbd48d8: add             SP, SP, #0x10
    // 0xbd48dc: r0 = Null
    //     0xbd48dc: mov             x0, NULL
    // 0xbd48e0: LeaveFrame
    //     0xbd48e0: mov             SP, fp
    //     0xbd48e4: ldp             fp, lr, [SP], #0x10
    // 0xbd48e8: ret
    //     0xbd48e8: ret             
    // 0xbd48ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd48ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd48f0: b               #0xbd4894
    // 0xbd48f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd48f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2395, size: 0x4c, field offset: 0x40
class PlatformViewLayer extends Layer {

  _ addToScene(/* No info */) {
    // ** addr: 0xa8387c, size: 0xf8
    // 0xa8387c: EnterFrame
    //     0xa8387c: stp             fp, lr, [SP, #-0x10]!
    //     0xa83880: mov             fp, SP
    // 0xa83884: AllocStack(0x20)
    //     0xa83884: sub             SP, SP, #0x20
    // 0xa83888: CheckStackOverflow
    //     0xa83888: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8388c: cmp             SP, x16
    //     0xa83890: b.ls            #0xa83950
    // 0xa83894: ldr             x0, [fp, #0x18]
    // 0xa83898: LoadField: r1 = r0->field_43
    //     0xa83898: ldur            x1, [x0, #0x43]
    // 0xa8389c: stur            x1, [fp, #-0x10]
    // 0xa838a0: LoadField: r2 = r0->field_3f
    //     0xa838a0: ldur            w2, [x0, #0x3f]
    // 0xa838a4: DecompressPointer r2
    //     0xa838a4: add             x2, x2, HEAP, lsl #32
    // 0xa838a8: stur            x2, [fp, #-8]
    // 0xa838ac: LoadField: d0 = r2->field_7
    //     0xa838ac: ldur            d0, [x2, #7]
    // 0xa838b0: stur            d0, [fp, #-0x20]
    // 0xa838b4: LoadField: d1 = r2->field_f
    //     0xa838b4: ldur            d1, [x2, #0xf]
    // 0xa838b8: stur            d1, [fp, #-0x18]
    // 0xa838bc: r0 = Offset()
    //     0xa838bc: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa838c0: mov             x2, x0
    // 0xa838c4: ldur            d0, [fp, #-0x20]
    // 0xa838c8: StoreField: r2->field_7 = d0
    //     0xa838c8: stur            d0, [x2, #7]
    // 0xa838cc: ldur            d1, [fp, #-0x18]
    // 0xa838d0: StoreField: r2->field_f = d1
    //     0xa838d0: stur            d1, [x2, #0xf]
    // 0xa838d4: ldur            x0, [fp, #-8]
    // 0xa838d8: LoadField: d2 = r0->field_17
    //     0xa838d8: ldur            d2, [x0, #0x17]
    // 0xa838dc: fsub            d3, d2, d0
    // 0xa838e0: LoadField: d0 = r0->field_1f
    //     0xa838e0: ldur            d0, [x0, #0x1f]
    // 0xa838e4: fsub            d2, d0, d1
    // 0xa838e8: ldur            x3, [fp, #-0x10]
    // 0xa838ec: r0 = BoxInt64Instr(r3)
    //     0xa838ec: sbfiz           x0, x3, #1, #0x1f
    //     0xa838f0: cmp             x3, x0, asr #1
    //     0xa838f4: b.eq            #0xa83900
    //     0xa838f8: bl              #0xd69c6c
    //     0xa838fc: stur            x3, [x0, #7]
    // 0xa83900: r1 = inline_Allocate_Double()
    //     0xa83900: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0xa83904: add             x1, x1, #0x10
    //     0xa83908: cmp             x3, x1
    //     0xa8390c: b.ls            #0xa83958
    //     0xa83910: str             x1, [THR, #0x60]  ; THR::top
    //     0xa83914: sub             x1, x1, #0xf
    //     0xa83918: mov             x3, #0xd108
    //     0xa8391c: movk            x3, #3, lsl #16
    //     0xa83920: stur            x3, [x1, #-1]
    // 0xa83924: StoreField: r1->field_7 = d2
    //     0xa83924: stur            d2, [x1, #7]
    // 0xa83928: ldr             x16, [fp, #0x10]
    // 0xa8392c: stp             x0, x16, [SP, #-0x10]!
    // 0xa83930: stp             x2, x1, [SP, #-0x10]!
    // 0xa83934: SaveReg d3
    //     0xa83934: str             d3, [SP, #-8]!
    // 0xa83938: r0 = addPlatformView()
    //     0xa83938: bl              #0xa83974  ; [dart:ui] SceneBuilder::addPlatformView
    // 0xa8393c: add             SP, SP, #0x28
    // 0xa83940: r0 = Null
    //     0xa83940: mov             x0, NULL
    // 0xa83944: LeaveFrame
    //     0xa83944: mov             SP, fp
    //     0xa83948: ldp             fp, lr, [SP], #0x10
    // 0xa8394c: ret
    //     0xa8394c: ret             
    // 0xa83950: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa83950: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa83954: b               #0xa83894
    // 0xa83958: stp             q2, q3, [SP, #-0x20]!
    // 0xa8395c: stp             x0, x2, [SP, #-0x10]!
    // 0xa83960: r0 = AllocateDouble()
    //     0xa83960: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa83964: mov             x1, x0
    // 0xa83968: ldp             x0, x2, [SP], #0x10
    // 0xa8396c: ldp             q2, q3, [SP], #0x20
    // 0xa83970: b               #0xa83924
  }
}

// class id: 2396, size: 0x54, field offset: 0x40
class TextureLayer extends Layer {

  _ addToScene(/* No info */) {
    // ** addr: 0xa8335c, size: 0xf8
    // 0xa8335c: EnterFrame
    //     0xa8335c: stp             fp, lr, [SP, #-0x10]!
    //     0xa83360: mov             fp, SP
    // 0xa83364: AllocStack(0x20)
    //     0xa83364: sub             SP, SP, #0x20
    // 0xa83368: CheckStackOverflow
    //     0xa83368: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8336c: cmp             SP, x16
    //     0xa83370: b.ls            #0xa83430
    // 0xa83374: ldr             x0, [fp, #0x18]
    // 0xa83378: LoadField: r1 = r0->field_43
    //     0xa83378: ldur            x1, [x0, #0x43]
    // 0xa8337c: stur            x1, [fp, #-0x10]
    // 0xa83380: LoadField: r2 = r0->field_3f
    //     0xa83380: ldur            w2, [x0, #0x3f]
    // 0xa83384: DecompressPointer r2
    //     0xa83384: add             x2, x2, HEAP, lsl #32
    // 0xa83388: stur            x2, [fp, #-8]
    // 0xa8338c: LoadField: d0 = r2->field_7
    //     0xa8338c: ldur            d0, [x2, #7]
    // 0xa83390: stur            d0, [fp, #-0x20]
    // 0xa83394: LoadField: d1 = r2->field_f
    //     0xa83394: ldur            d1, [x2, #0xf]
    // 0xa83398: stur            d1, [fp, #-0x18]
    // 0xa8339c: r0 = Offset()
    //     0xa8339c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa833a0: mov             x2, x0
    // 0xa833a4: ldur            d0, [fp, #-0x20]
    // 0xa833a8: StoreField: r2->field_7 = d0
    //     0xa833a8: stur            d0, [x2, #7]
    // 0xa833ac: ldur            d1, [fp, #-0x18]
    // 0xa833b0: StoreField: r2->field_f = d1
    //     0xa833b0: stur            d1, [x2, #0xf]
    // 0xa833b4: ldur            x0, [fp, #-8]
    // 0xa833b8: LoadField: d2 = r0->field_17
    //     0xa833b8: ldur            d2, [x0, #0x17]
    // 0xa833bc: fsub            d3, d2, d0
    // 0xa833c0: LoadField: d0 = r0->field_1f
    //     0xa833c0: ldur            d0, [x0, #0x1f]
    // 0xa833c4: fsub            d2, d0, d1
    // 0xa833c8: ldur            x3, [fp, #-0x10]
    // 0xa833cc: r0 = BoxInt64Instr(r3)
    //     0xa833cc: sbfiz           x0, x3, #1, #0x1f
    //     0xa833d0: cmp             x3, x0, asr #1
    //     0xa833d4: b.eq            #0xa833e0
    //     0xa833d8: bl              #0xd69c6c
    //     0xa833dc: stur            x3, [x0, #7]
    // 0xa833e0: r1 = inline_Allocate_Double()
    //     0xa833e0: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0xa833e4: add             x1, x1, #0x10
    //     0xa833e8: cmp             x3, x1
    //     0xa833ec: b.ls            #0xa83438
    //     0xa833f0: str             x1, [THR, #0x60]  ; THR::top
    //     0xa833f4: sub             x1, x1, #0xf
    //     0xa833f8: mov             x3, #0xd108
    //     0xa833fc: movk            x3, #3, lsl #16
    //     0xa83400: stur            x3, [x1, #-1]
    // 0xa83404: StoreField: r1->field_7 = d2
    //     0xa83404: stur            d2, [x1, #7]
    // 0xa83408: ldr             x16, [fp, #0x10]
    // 0xa8340c: stp             x0, x16, [SP, #-0x10]!
    // 0xa83410: stp             x2, x1, [SP, #-0x10]!
    // 0xa83414: SaveReg d3
    //     0xa83414: str             d3, [SP, #-8]!
    // 0xa83418: r0 = addTexture()
    //     0xa83418: bl              #0xa83454  ; [dart:ui] SceneBuilder::addTexture
    // 0xa8341c: add             SP, SP, #0x28
    // 0xa83420: r0 = Null
    //     0xa83420: mov             x0, NULL
    // 0xa83424: LeaveFrame
    //     0xa83424: mov             SP, fp
    //     0xa83428: ldp             fp, lr, [SP], #0x10
    // 0xa8342c: ret
    //     0xa8342c: ret             
    // 0xa83430: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa83430: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa83434: b               #0xa83374
    // 0xa83438: stp             q2, q3, [SP, #-0x20]!
    // 0xa8343c: stp             x0, x2, [SP, #-0x10]!
    // 0xa83440: r0 = AllocateDouble()
    //     0xa83440: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa83444: mov             x1, x0
    // 0xa83448: ldp             x0, x2, [SP], #0x10
    // 0xa8344c: ldp             q2, q3, [SP], #0x20
    // 0xa83450: b               #0xa83404
  }
}

// class id: 2397, size: 0x4c, field offset: 0x40
class PictureLayer extends Layer {

  set _ picture=(/* No info */) {
    // ** addr: 0x5dea74, size: 0x88
    // 0x5dea74: EnterFrame
    //     0x5dea74: stp             fp, lr, [SP, #-0x10]!
    //     0x5dea78: mov             fp, SP
    // 0x5dea7c: CheckStackOverflow
    //     0x5dea7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5dea80: cmp             SP, x16
    //     0x5dea84: b.ls            #0x5deaf4
    // 0x5dea88: ldr             x16, [fp, #0x18]
    // 0x5dea8c: SaveReg r16
    //     0x5dea8c: str             x16, [SP, #-8]!
    // 0x5dea90: r0 = markNeedsAddToScene()
    //     0x5dea90: bl              #0x5dec74  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0x5dea94: add             SP, SP, #8
    // 0x5dea98: ldr             x0, [fp, #0x18]
    // 0x5dea9c: LoadField: r1 = r0->field_3f
    //     0x5dea9c: ldur            w1, [x0, #0x3f]
    // 0x5deaa0: DecompressPointer r1
    //     0x5deaa0: add             x1, x1, HEAP, lsl #32
    // 0x5deaa4: cmp             w1, NULL
    // 0x5deaa8: b.ne            #0x5deab4
    // 0x5deaac: mov             x1, x0
    // 0x5deab0: b               #0x5deac4
    // 0x5deab4: SaveReg r1
    //     0x5deab4: str             x1, [SP, #-8]!
    // 0x5deab8: r0 = _dispose()
    //     0x5deab8: bl              #0x5deafc  ; [dart:ui] Picture::_dispose
    // 0x5deabc: add             SP, SP, #8
    // 0x5deac0: ldr             x1, [fp, #0x18]
    // 0x5deac4: ldr             x0, [fp, #0x10]
    // 0x5deac8: StoreField: r1->field_3f = r0
    //     0x5deac8: stur            w0, [x1, #0x3f]
    //     0x5deacc: ldurb           w16, [x1, #-1]
    //     0x5dead0: ldurb           w17, [x0, #-1]
    //     0x5dead4: and             x16, x17, x16, lsr #2
    //     0x5dead8: tst             x16, HEAP, lsr #32
    //     0x5deadc: b.eq            #0x5deae4
    //     0x5deae0: bl              #0xd6826c
    // 0x5deae4: r0 = Null
    //     0x5deae4: mov             x0, NULL
    // 0x5deae8: LeaveFrame
    //     0x5deae8: mov             SP, fp
    //     0x5deaec: ldp             fp, lr, [SP], #0x10
    // 0x5deaf0: ret
    //     0x5deaf0: ret             
    // 0x5deaf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5deaf4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5deaf8: b               #0x5dea88
  }
  set _ isComplexHint=(/* No info */) {
    // ** addr: 0x665534, size: 0x50
    // 0x665534: EnterFrame
    //     0x665534: stp             fp, lr, [SP, #-0x10]!
    //     0x665538: mov             fp, SP
    // 0x66553c: CheckStackOverflow
    //     0x66553c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x665540: cmp             SP, x16
    //     0x665544: b.ls            #0x66557c
    // 0x665548: ldr             x0, [fp, #0x18]
    // 0x66554c: LoadField: r1 = r0->field_43
    //     0x66554c: ldur            w1, [x0, #0x43]
    // 0x665550: DecompressPointer r1
    //     0x665550: add             x1, x1, HEAP, lsl #32
    // 0x665554: tbz             w1, #4, #0x66556c
    // 0x665558: r1 = true
    //     0x665558: add             x1, NULL, #0x20  ; true
    // 0x66555c: StoreField: r0->field_43 = r1
    //     0x66555c: stur            w1, [x0, #0x43]
    // 0x665560: SaveReg r0
    //     0x665560: str             x0, [SP, #-8]!
    // 0x665564: r0 = markNeedsAddToScene()
    //     0x665564: bl              #0x5dec74  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0x665568: add             SP, SP, #8
    // 0x66556c: r0 = Null
    //     0x66556c: mov             x0, NULL
    // 0x665570: LeaveFrame
    //     0x665570: mov             SP, fp
    //     0x665574: ldp             fp, lr, [SP], #0x10
    // 0x665578: ret
    //     0x665578: ret             
    // 0x66557c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66557c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x665580: b               #0x665548
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa7802c, size: 0x4c
    // 0xa7802c: EnterFrame
    //     0xa7802c: stp             fp, lr, [SP, #-0x10]!
    //     0xa78030: mov             fp, SP
    // 0xa78034: CheckStackOverflow
    //     0xa78034: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa78038: cmp             SP, x16
    //     0xa7803c: b.ls            #0xa78070
    // 0xa78040: ldr             x16, [fp, #0x10]
    // 0xa78044: stp             NULL, x16, [SP, #-0x10]!
    // 0xa78048: r0 = picture=()
    //     0xa78048: bl              #0x5dea74  ; [package:flutter/src/rendering/layer.dart] PictureLayer::picture=
    // 0xa7804c: add             SP, SP, #0x10
    // 0xa78050: ldr             x16, [fp, #0x10]
    // 0xa78054: SaveReg r16
    //     0xa78054: str             x16, [SP, #-8]!
    // 0xa78058: r0 = dispose()
    //     0xa78058: bl              #0xa78078  ; [package:flutter/src/rendering/layer.dart] Layer::dispose
    // 0xa7805c: add             SP, SP, #8
    // 0xa78060: r0 = Null
    //     0xa78060: mov             x0, NULL
    // 0xa78064: LeaveFrame
    //     0xa78064: mov             SP, fp
    //     0xa78068: ldp             fp, lr, [SP], #0x10
    // 0xa7806c: ret
    //     0xa7806c: ret             
    // 0xa78070: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa78070: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa78074: b               #0xa78040
  }
  _ addToScene(/* No info */) {
    // ** addr: 0xa82ef4, size: 0x68
    // 0xa82ef4: EnterFrame
    //     0xa82ef4: stp             fp, lr, [SP, #-0x10]!
    //     0xa82ef8: mov             fp, SP
    // 0xa82efc: CheckStackOverflow
    //     0xa82efc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa82f00: cmp             SP, x16
    //     0xa82f04: b.ls            #0xa82f50
    // 0xa82f08: ldr             x0, [fp, #0x18]
    // 0xa82f0c: LoadField: r1 = r0->field_3f
    //     0xa82f0c: ldur            w1, [x0, #0x3f]
    // 0xa82f10: DecompressPointer r1
    //     0xa82f10: add             x1, x1, HEAP, lsl #32
    // 0xa82f14: cmp             w1, NULL
    // 0xa82f18: b.eq            #0xa82f58
    // 0xa82f1c: LoadField: r2 = r0->field_43
    //     0xa82f1c: ldur            w2, [x0, #0x43]
    // 0xa82f20: DecompressPointer r2
    //     0xa82f20: add             x2, x2, HEAP, lsl #32
    // 0xa82f24: LoadField: r3 = r0->field_47
    //     0xa82f24: ldur            w3, [x0, #0x47]
    // 0xa82f28: DecompressPointer r3
    //     0xa82f28: add             x3, x3, HEAP, lsl #32
    // 0xa82f2c: ldr             x16, [fp, #0x10]
    // 0xa82f30: stp             x1, x16, [SP, #-0x10]!
    // 0xa82f34: stp             x3, x2, [SP, #-0x10]!
    // 0xa82f38: r0 = addPicture()
    //     0xa82f38: bl              #0xa82f5c  ; [dart:ui] SceneBuilder::addPicture
    // 0xa82f3c: add             SP, SP, #0x20
    // 0xa82f40: r0 = Null
    //     0xa82f40: mov             x0, NULL
    // 0xa82f44: LeaveFrame
    //     0xa82f44: mov             SP, fp
    //     0xa82f48: ldp             fp, lr, [SP], #0x10
    // 0xa82f4c: ret
    //     0xa82f4c: ret             
    // 0xa82f50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa82f50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa82f54: b               #0xa82f08
    // 0xa82f58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa82f58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

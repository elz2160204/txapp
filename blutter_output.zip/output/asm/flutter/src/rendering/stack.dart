// lib: , url: package:flutter/src/rendering/stack.dart

// class id: 1049428, size: 0x8
class :: {
}

// class id: 1987, size: 0x28, field offset: 0x8
//   const constructor, 
class RelativeRect extends Object {

  factory _ RelativeRect.fromRect(/* No info */) {
    // ** addr: 0x692470, size: 0x84
    // 0x692470: EnterFrame
    //     0x692470: stp             fp, lr, [SP, #-0x10]!
    //     0x692474: mov             fp, SP
    // 0x692478: AllocStack(0x20)
    //     0x692478: sub             SP, SP, #0x20
    // 0x69247c: ldr             x0, [fp, #0x18]
    // 0x692480: LoadField: d0 = r0->field_7
    //     0x692480: ldur            d0, [x0, #7]
    // 0x692484: ldr             x1, [fp, #0x10]
    // 0x692488: LoadField: d1 = r1->field_7
    //     0x692488: ldur            d1, [x1, #7]
    // 0x69248c: fsub            d2, d0, d1
    // 0x692490: stur            d2, [fp, #-0x20]
    // 0x692494: LoadField: d0 = r0->field_f
    //     0x692494: ldur            d0, [x0, #0xf]
    // 0x692498: LoadField: d1 = r1->field_f
    //     0x692498: ldur            d1, [x1, #0xf]
    // 0x69249c: fsub            d3, d0, d1
    // 0x6924a0: stur            d3, [fp, #-0x18]
    // 0x6924a4: LoadField: d0 = r1->field_17
    //     0x6924a4: ldur            d0, [x1, #0x17]
    // 0x6924a8: LoadField: d1 = r0->field_17
    //     0x6924a8: ldur            d1, [x0, #0x17]
    // 0x6924ac: fsub            d4, d0, d1
    // 0x6924b0: stur            d4, [fp, #-0x10]
    // 0x6924b4: LoadField: d0 = r1->field_1f
    //     0x6924b4: ldur            d0, [x1, #0x1f]
    // 0x6924b8: LoadField: d1 = r0->field_1f
    //     0x6924b8: ldur            d1, [x0, #0x1f]
    // 0x6924bc: fsub            d5, d0, d1
    // 0x6924c0: stur            d5, [fp, #-8]
    // 0x6924c4: r0 = RelativeRect()
    //     0x6924c4: bl              #0x6924f4  ; AllocateRelativeRectStub -> RelativeRect (size=0x28)
    // 0x6924c8: ldur            d0, [fp, #-0x20]
    // 0x6924cc: StoreField: r0->field_7 = d0
    //     0x6924cc: stur            d0, [x0, #7]
    // 0x6924d0: ldur            d0, [fp, #-0x18]
    // 0x6924d4: StoreField: r0->field_f = d0
    //     0x6924d4: stur            d0, [x0, #0xf]
    // 0x6924d8: ldur            d0, [fp, #-0x10]
    // 0x6924dc: StoreField: r0->field_17 = d0
    //     0x6924dc: stur            d0, [x0, #0x17]
    // 0x6924e0: ldur            d0, [fp, #-8]
    // 0x6924e4: StoreField: r0->field_1f = d0
    //     0x6924e4: stur            d0, [x0, #0x1f]
    // 0x6924e8: LeaveFrame
    //     0x6924e8: mov             SP, fp
    //     0x6924ec: ldp             fp, lr, [SP], #0x10
    // 0x6924f0: ret
    //     0x6924f0: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0xae5ca4, size: 0x2a0
    // 0xae5ca4: EnterFrame
    //     0xae5ca4: stp             fp, lr, [SP, #-0x10]!
    //     0xae5ca8: mov             fp, SP
    // 0xae5cac: AllocStack(0x8)
    //     0xae5cac: sub             SP, SP, #8
    // 0xae5cb0: CheckStackOverflow
    //     0xae5cb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae5cb4: cmp             SP, x16
    //     0xae5cb8: b.ls            #0xae5ed0
    // 0xae5cbc: r1 = Null
    //     0xae5cbc: mov             x1, NULL
    // 0xae5cc0: r2 = 18
    //     0xae5cc0: mov             x2, #0x12
    // 0xae5cc4: r0 = AllocateArray()
    //     0xae5cc4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae5cc8: stur            x0, [fp, #-8]
    // 0xae5ccc: r17 = "RelativeRect.fromLTRB("
    //     0xae5ccc: add             x17, PP, #0x21, lsl #12  ; [pp+0x21a80] "RelativeRect.fromLTRB("
    //     0xae5cd0: ldr             x17, [x17, #0xa80]
    // 0xae5cd4: StoreField: r0->field_f = r17
    //     0xae5cd4: stur            w17, [x0, #0xf]
    // 0xae5cd8: ldr             x1, [fp, #0x10]
    // 0xae5cdc: LoadField: d0 = r1->field_7
    //     0xae5cdc: ldur            d0, [x1, #7]
    // 0xae5ce0: r2 = inline_Allocate_Double()
    //     0xae5ce0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xae5ce4: add             x2, x2, #0x10
    //     0xae5ce8: cmp             x3, x2
    //     0xae5cec: b.ls            #0xae5ed8
    //     0xae5cf0: str             x2, [THR, #0x60]  ; THR::top
    //     0xae5cf4: sub             x2, x2, #0xf
    //     0xae5cf8: mov             x3, #0xd108
    //     0xae5cfc: movk            x3, #3, lsl #16
    //     0xae5d00: stur            x3, [x2, #-1]
    // 0xae5d04: StoreField: r2->field_7 = d0
    //     0xae5d04: stur            d0, [x2, #7]
    // 0xae5d08: SaveReg r2
    //     0xae5d08: str             x2, [SP, #-8]!
    // 0xae5d0c: r2 = 1
    //     0xae5d0c: mov             x2, #1
    // 0xae5d10: SaveReg r2
    //     0xae5d10: str             x2, [SP, #-8]!
    // 0xae5d14: r0 = toStringAsFixed()
    //     0xae5d14: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae5d18: add             SP, SP, #0x10
    // 0xae5d1c: ldur            x1, [fp, #-8]
    // 0xae5d20: ArrayStore: r1[1] = r0  ; List_4
    //     0xae5d20: add             x25, x1, #0x13
    //     0xae5d24: str             w0, [x25]
    //     0xae5d28: tbz             w0, #0, #0xae5d44
    //     0xae5d2c: ldurb           w16, [x1, #-1]
    //     0xae5d30: ldurb           w17, [x0, #-1]
    //     0xae5d34: and             x16, x17, x16, lsr #2
    //     0xae5d38: tst             x16, HEAP, lsr #32
    //     0xae5d3c: b.eq            #0xae5d44
    //     0xae5d40: bl              #0xd67e5c
    // 0xae5d44: ldur            x1, [fp, #-8]
    // 0xae5d48: r17 = ", "
    //     0xae5d48: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae5d4c: StoreField: r1->field_17 = r17
    //     0xae5d4c: stur            w17, [x1, #0x17]
    // 0xae5d50: ldr             x0, [fp, #0x10]
    // 0xae5d54: LoadField: d0 = r0->field_f
    //     0xae5d54: ldur            d0, [x0, #0xf]
    // 0xae5d58: r2 = inline_Allocate_Double()
    //     0xae5d58: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xae5d5c: add             x2, x2, #0x10
    //     0xae5d60: cmp             x3, x2
    //     0xae5d64: b.ls            #0xae5ef4
    //     0xae5d68: str             x2, [THR, #0x60]  ; THR::top
    //     0xae5d6c: sub             x2, x2, #0xf
    //     0xae5d70: mov             x3, #0xd108
    //     0xae5d74: movk            x3, #3, lsl #16
    //     0xae5d78: stur            x3, [x2, #-1]
    // 0xae5d7c: StoreField: r2->field_7 = d0
    //     0xae5d7c: stur            d0, [x2, #7]
    // 0xae5d80: SaveReg r2
    //     0xae5d80: str             x2, [SP, #-8]!
    // 0xae5d84: r2 = 1
    //     0xae5d84: mov             x2, #1
    // 0xae5d88: SaveReg r2
    //     0xae5d88: str             x2, [SP, #-8]!
    // 0xae5d8c: r0 = toStringAsFixed()
    //     0xae5d8c: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae5d90: add             SP, SP, #0x10
    // 0xae5d94: ldur            x1, [fp, #-8]
    // 0xae5d98: ArrayStore: r1[3] = r0  ; List_4
    //     0xae5d98: add             x25, x1, #0x1b
    //     0xae5d9c: str             w0, [x25]
    //     0xae5da0: tbz             w0, #0, #0xae5dbc
    //     0xae5da4: ldurb           w16, [x1, #-1]
    //     0xae5da8: ldurb           w17, [x0, #-1]
    //     0xae5dac: and             x16, x17, x16, lsr #2
    //     0xae5db0: tst             x16, HEAP, lsr #32
    //     0xae5db4: b.eq            #0xae5dbc
    //     0xae5db8: bl              #0xd67e5c
    // 0xae5dbc: ldur            x1, [fp, #-8]
    // 0xae5dc0: r17 = ", "
    //     0xae5dc0: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae5dc4: StoreField: r1->field_1f = r17
    //     0xae5dc4: stur            w17, [x1, #0x1f]
    // 0xae5dc8: ldr             x0, [fp, #0x10]
    // 0xae5dcc: LoadField: d0 = r0->field_17
    //     0xae5dcc: ldur            d0, [x0, #0x17]
    // 0xae5dd0: r2 = inline_Allocate_Double()
    //     0xae5dd0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xae5dd4: add             x2, x2, #0x10
    //     0xae5dd8: cmp             x3, x2
    //     0xae5ddc: b.ls            #0xae5f10
    //     0xae5de0: str             x2, [THR, #0x60]  ; THR::top
    //     0xae5de4: sub             x2, x2, #0xf
    //     0xae5de8: mov             x3, #0xd108
    //     0xae5dec: movk            x3, #3, lsl #16
    //     0xae5df0: stur            x3, [x2, #-1]
    // 0xae5df4: StoreField: r2->field_7 = d0
    //     0xae5df4: stur            d0, [x2, #7]
    // 0xae5df8: SaveReg r2
    //     0xae5df8: str             x2, [SP, #-8]!
    // 0xae5dfc: r2 = 1
    //     0xae5dfc: mov             x2, #1
    // 0xae5e00: SaveReg r2
    //     0xae5e00: str             x2, [SP, #-8]!
    // 0xae5e04: r0 = toStringAsFixed()
    //     0xae5e04: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae5e08: add             SP, SP, #0x10
    // 0xae5e0c: ldur            x1, [fp, #-8]
    // 0xae5e10: ArrayStore: r1[5] = r0  ; List_4
    //     0xae5e10: add             x25, x1, #0x23
    //     0xae5e14: str             w0, [x25]
    //     0xae5e18: tbz             w0, #0, #0xae5e34
    //     0xae5e1c: ldurb           w16, [x1, #-1]
    //     0xae5e20: ldurb           w17, [x0, #-1]
    //     0xae5e24: and             x16, x17, x16, lsr #2
    //     0xae5e28: tst             x16, HEAP, lsr #32
    //     0xae5e2c: b.eq            #0xae5e34
    //     0xae5e30: bl              #0xd67e5c
    // 0xae5e34: ldur            x1, [fp, #-8]
    // 0xae5e38: r17 = ", "
    //     0xae5e38: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae5e3c: StoreField: r1->field_27 = r17
    //     0xae5e3c: stur            w17, [x1, #0x27]
    // 0xae5e40: ldr             x0, [fp, #0x10]
    // 0xae5e44: LoadField: d0 = r0->field_1f
    //     0xae5e44: ldur            d0, [x0, #0x1f]
    // 0xae5e48: r0 = inline_Allocate_Double()
    //     0xae5e48: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xae5e4c: add             x0, x0, #0x10
    //     0xae5e50: cmp             x2, x0
    //     0xae5e54: b.ls            #0xae5f2c
    //     0xae5e58: str             x0, [THR, #0x60]  ; THR::top
    //     0xae5e5c: sub             x0, x0, #0xf
    //     0xae5e60: mov             x2, #0xd108
    //     0xae5e64: movk            x2, #3, lsl #16
    //     0xae5e68: stur            x2, [x0, #-1]
    // 0xae5e6c: StoreField: r0->field_7 = d0
    //     0xae5e6c: stur            d0, [x0, #7]
    // 0xae5e70: SaveReg r0
    //     0xae5e70: str             x0, [SP, #-8]!
    // 0xae5e74: r0 = 1
    //     0xae5e74: mov             x0, #1
    // 0xae5e78: SaveReg r0
    //     0xae5e78: str             x0, [SP, #-8]!
    // 0xae5e7c: r0 = toStringAsFixed()
    //     0xae5e7c: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae5e80: add             SP, SP, #0x10
    // 0xae5e84: ldur            x1, [fp, #-8]
    // 0xae5e88: ArrayStore: r1[7] = r0  ; List_4
    //     0xae5e88: add             x25, x1, #0x2b
    //     0xae5e8c: str             w0, [x25]
    //     0xae5e90: tbz             w0, #0, #0xae5eac
    //     0xae5e94: ldurb           w16, [x1, #-1]
    //     0xae5e98: ldurb           w17, [x0, #-1]
    //     0xae5e9c: and             x16, x17, x16, lsr #2
    //     0xae5ea0: tst             x16, HEAP, lsr #32
    //     0xae5ea4: b.eq            #0xae5eac
    //     0xae5ea8: bl              #0xd67e5c
    // 0xae5eac: ldur            x0, [fp, #-8]
    // 0xae5eb0: r17 = ")"
    //     0xae5eb0: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae5eb4: StoreField: r0->field_2f = r17
    //     0xae5eb4: stur            w17, [x0, #0x2f]
    // 0xae5eb8: SaveReg r0
    //     0xae5eb8: str             x0, [SP, #-8]!
    // 0xae5ebc: r0 = _interpolate()
    //     0xae5ebc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae5ec0: add             SP, SP, #8
    // 0xae5ec4: LeaveFrame
    //     0xae5ec4: mov             SP, fp
    //     0xae5ec8: ldp             fp, lr, [SP], #0x10
    // 0xae5ecc: ret
    //     0xae5ecc: ret             
    // 0xae5ed0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae5ed0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae5ed4: b               #0xae5cbc
    // 0xae5ed8: SaveReg d0
    //     0xae5ed8: str             q0, [SP, #-0x10]!
    // 0xae5edc: stp             x0, x1, [SP, #-0x10]!
    // 0xae5ee0: r0 = AllocateDouble()
    //     0xae5ee0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae5ee4: mov             x2, x0
    // 0xae5ee8: ldp             x0, x1, [SP], #0x10
    // 0xae5eec: RestoreReg d0
    //     0xae5eec: ldr             q0, [SP], #0x10
    // 0xae5ef0: b               #0xae5d04
    // 0xae5ef4: SaveReg d0
    //     0xae5ef4: str             q0, [SP, #-0x10]!
    // 0xae5ef8: stp             x0, x1, [SP, #-0x10]!
    // 0xae5efc: r0 = AllocateDouble()
    //     0xae5efc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae5f00: mov             x2, x0
    // 0xae5f04: ldp             x0, x1, [SP], #0x10
    // 0xae5f08: RestoreReg d0
    //     0xae5f08: ldr             q0, [SP], #0x10
    // 0xae5f0c: b               #0xae5d7c
    // 0xae5f10: SaveReg d0
    //     0xae5f10: str             q0, [SP, #-0x10]!
    // 0xae5f14: stp             x0, x1, [SP, #-0x10]!
    // 0xae5f18: r0 = AllocateDouble()
    //     0xae5f18: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae5f1c: mov             x2, x0
    // 0xae5f20: ldp             x0, x1, [SP], #0x10
    // 0xae5f24: RestoreReg d0
    //     0xae5f24: ldr             q0, [SP], #0x10
    // 0xae5f28: b               #0xae5df4
    // 0xae5f2c: SaveReg d0
    //     0xae5f2c: str             q0, [SP, #-0x10]!
    // 0xae5f30: SaveReg r1
    //     0xae5f30: str             x1, [SP, #-8]!
    // 0xae5f34: r0 = AllocateDouble()
    //     0xae5f34: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae5f38: RestoreReg r1
    //     0xae5f38: ldr             x1, [SP], #8
    // 0xae5f3c: RestoreReg d0
    //     0xae5f3c: ldr             q0, [SP], #0x10
    // 0xae5f40: b               #0xae5e6c
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb0f528, size: 0x184
    // 0xb0f528: EnterFrame
    //     0xb0f528: stp             fp, lr, [SP, #-0x10]!
    //     0xb0f52c: mov             fp, SP
    // 0xb0f530: CheckStackOverflow
    //     0xb0f530: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0f534: cmp             SP, x16
    //     0xb0f538: b.ls            #0xb0f628
    // 0xb0f53c: ldr             x0, [fp, #0x10]
    // 0xb0f540: LoadField: d0 = r0->field_7
    //     0xb0f540: ldur            d0, [x0, #7]
    // 0xb0f544: LoadField: d1 = r0->field_f
    //     0xb0f544: ldur            d1, [x0, #0xf]
    // 0xb0f548: LoadField: d2 = r0->field_17
    //     0xb0f548: ldur            d2, [x0, #0x17]
    // 0xb0f54c: LoadField: d3 = r0->field_1f
    //     0xb0f54c: ldur            d3, [x0, #0x1f]
    // 0xb0f550: r0 = inline_Allocate_Double()
    //     0xb0f550: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb0f554: add             x0, x0, #0x10
    //     0xb0f558: cmp             x1, x0
    //     0xb0f55c: b.ls            #0xb0f630
    //     0xb0f560: str             x0, [THR, #0x60]  ; THR::top
    //     0xb0f564: sub             x0, x0, #0xf
    //     0xb0f568: mov             x1, #0xd108
    //     0xb0f56c: movk            x1, #3, lsl #16
    //     0xb0f570: stur            x1, [x0, #-1]
    // 0xb0f574: StoreField: r0->field_7 = d0
    //     0xb0f574: stur            d0, [x0, #7]
    // 0xb0f578: r1 = inline_Allocate_Double()
    //     0xb0f578: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb0f57c: add             x1, x1, #0x10
    //     0xb0f580: cmp             x2, x1
    //     0xb0f584: b.ls            #0xb0f648
    //     0xb0f588: str             x1, [THR, #0x60]  ; THR::top
    //     0xb0f58c: sub             x1, x1, #0xf
    //     0xb0f590: mov             x2, #0xd108
    //     0xb0f594: movk            x2, #3, lsl #16
    //     0xb0f598: stur            x2, [x1, #-1]
    // 0xb0f59c: StoreField: r1->field_7 = d1
    //     0xb0f59c: stur            d1, [x1, #7]
    // 0xb0f5a0: r2 = inline_Allocate_Double()
    //     0xb0f5a0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xb0f5a4: add             x2, x2, #0x10
    //     0xb0f5a8: cmp             x3, x2
    //     0xb0f5ac: b.ls            #0xb0f66c
    //     0xb0f5b0: str             x2, [THR, #0x60]  ; THR::top
    //     0xb0f5b4: sub             x2, x2, #0xf
    //     0xb0f5b8: mov             x3, #0xd108
    //     0xb0f5bc: movk            x3, #3, lsl #16
    //     0xb0f5c0: stur            x3, [x2, #-1]
    // 0xb0f5c4: StoreField: r2->field_7 = d2
    //     0xb0f5c4: stur            d2, [x2, #7]
    // 0xb0f5c8: r3 = inline_Allocate_Double()
    //     0xb0f5c8: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xb0f5cc: add             x3, x3, #0x10
    //     0xb0f5d0: cmp             x4, x3
    //     0xb0f5d4: b.ls            #0xb0f688
    //     0xb0f5d8: str             x3, [THR, #0x60]  ; THR::top
    //     0xb0f5dc: sub             x3, x3, #0xf
    //     0xb0f5e0: mov             x4, #0xd108
    //     0xb0f5e4: movk            x4, #3, lsl #16
    //     0xb0f5e8: stur            x4, [x3, #-1]
    // 0xb0f5ec: StoreField: r3->field_7 = d3
    //     0xb0f5ec: stur            d3, [x3, #7]
    // 0xb0f5f0: stp             x1, x0, [SP, #-0x10]!
    // 0xb0f5f4: stp             x3, x2, [SP, #-0x10]!
    // 0xb0f5f8: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0xb0f5f8: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0xb0f5fc: r0 = hash()
    //     0xb0f5fc: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0f600: add             SP, SP, #0x20
    // 0xb0f604: mov             x2, x0
    // 0xb0f608: r0 = BoxInt64Instr(r2)
    //     0xb0f608: sbfiz           x0, x2, #1, #0x1f
    //     0xb0f60c: cmp             x2, x0, asr #1
    //     0xb0f610: b.eq            #0xb0f61c
    //     0xb0f614: bl              #0xd69bb8
    //     0xb0f618: stur            x2, [x0, #7]
    // 0xb0f61c: LeaveFrame
    //     0xb0f61c: mov             SP, fp
    //     0xb0f620: ldp             fp, lr, [SP], #0x10
    // 0xb0f624: ret
    //     0xb0f624: ret             
    // 0xb0f628: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0f628: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0f62c: b               #0xb0f53c
    // 0xb0f630: stp             q2, q3, [SP, #-0x20]!
    // 0xb0f634: stp             q0, q1, [SP, #-0x20]!
    // 0xb0f638: r0 = AllocateDouble()
    //     0xb0f638: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0f63c: ldp             q0, q1, [SP], #0x20
    // 0xb0f640: ldp             q2, q3, [SP], #0x20
    // 0xb0f644: b               #0xb0f574
    // 0xb0f648: stp             q2, q3, [SP, #-0x20]!
    // 0xb0f64c: SaveReg d1
    //     0xb0f64c: str             q1, [SP, #-0x10]!
    // 0xb0f650: SaveReg r0
    //     0xb0f650: str             x0, [SP, #-8]!
    // 0xb0f654: r0 = AllocateDouble()
    //     0xb0f654: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0f658: mov             x1, x0
    // 0xb0f65c: RestoreReg r0
    //     0xb0f65c: ldr             x0, [SP], #8
    // 0xb0f660: RestoreReg d1
    //     0xb0f660: ldr             q1, [SP], #0x10
    // 0xb0f664: ldp             q2, q3, [SP], #0x20
    // 0xb0f668: b               #0xb0f59c
    // 0xb0f66c: stp             q2, q3, [SP, #-0x20]!
    // 0xb0f670: stp             x0, x1, [SP, #-0x10]!
    // 0xb0f674: r0 = AllocateDouble()
    //     0xb0f674: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0f678: mov             x2, x0
    // 0xb0f67c: ldp             x0, x1, [SP], #0x10
    // 0xb0f680: ldp             q2, q3, [SP], #0x20
    // 0xb0f684: b               #0xb0f5c4
    // 0xb0f688: SaveReg d3
    //     0xb0f688: str             q3, [SP, #-0x10]!
    // 0xb0f68c: stp             x1, x2, [SP, #-0x10]!
    // 0xb0f690: SaveReg r0
    //     0xb0f690: str             x0, [SP, #-8]!
    // 0xb0f694: r0 = AllocateDouble()
    //     0xb0f694: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0f698: mov             x3, x0
    // 0xb0f69c: RestoreReg r0
    //     0xb0f69c: ldr             x0, [SP], #8
    // 0xb0f6a0: ldp             x1, x2, [SP], #0x10
    // 0xb0f6a4: RestoreReg d3
    //     0xb0f6a4: ldr             q3, [SP], #0x10
    // 0xb0f6a8: b               #0xb0f5ec
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9f4d4, size: 0xb0
    // 0xc9f4d4: ldr             x1, [SP]
    // 0xc9f4d8: cmp             w1, NULL
    // 0xc9f4dc: b.ne            #0xc9f4e8
    // 0xc9f4e0: r0 = false
    //     0xc9f4e0: add             x0, NULL, #0x30  ; false
    // 0xc9f4e4: ret
    //     0xc9f4e4: ret             
    // 0xc9f4e8: ldr             x2, [SP, #8]
    // 0xc9f4ec: cmp             w2, w1
    // 0xc9f4f0: b.ne            #0xc9f4fc
    // 0xc9f4f4: r0 = true
    //     0xc9f4f4: add             x0, NULL, #0x20  ; true
    // 0xc9f4f8: ret
    //     0xc9f4f8: ret             
    // 0xc9f4fc: r3 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc9f4fc: mov             x3, #0x76
    //     0xc9f500: tbz             w1, #0, #0xc9f510
    //     0xc9f504: ldur            x3, [x1, #-1]
    //     0xc9f508: ubfx            x3, x3, #0xc, #0x14
    //     0xc9f50c: lsl             x3, x3, #1
    // 0xc9f510: cmp             w3, #0xf86
    // 0xc9f514: b.ne            #0xc9f57c
    // 0xc9f518: LoadField: d0 = r1->field_7
    //     0xc9f518: ldur            d0, [x1, #7]
    // 0xc9f51c: LoadField: d1 = r2->field_7
    //     0xc9f51c: ldur            d1, [x2, #7]
    // 0xc9f520: fcmp            d0, d1
    // 0xc9f524: b.vs            #0xc9f57c
    // 0xc9f528: b.ne            #0xc9f57c
    // 0xc9f52c: LoadField: d0 = r1->field_f
    //     0xc9f52c: ldur            d0, [x1, #0xf]
    // 0xc9f530: LoadField: d1 = r2->field_f
    //     0xc9f530: ldur            d1, [x2, #0xf]
    // 0xc9f534: fcmp            d0, d1
    // 0xc9f538: b.vs            #0xc9f57c
    // 0xc9f53c: b.ne            #0xc9f57c
    // 0xc9f540: LoadField: d0 = r1->field_17
    //     0xc9f540: ldur            d0, [x1, #0x17]
    // 0xc9f544: LoadField: d1 = r2->field_17
    //     0xc9f544: ldur            d1, [x2, #0x17]
    // 0xc9f548: fcmp            d0, d1
    // 0xc9f54c: b.vs            #0xc9f57c
    // 0xc9f550: b.ne            #0xc9f57c
    // 0xc9f554: LoadField: d0 = r1->field_1f
    //     0xc9f554: ldur            d0, [x1, #0x1f]
    // 0xc9f558: LoadField: d1 = r2->field_1f
    //     0xc9f558: ldur            d1, [x2, #0x1f]
    // 0xc9f55c: fcmp            d0, d1
    // 0xc9f560: b.vs            #0xc9f568
    // 0xc9f564: b.eq            #0xc9f570
    // 0xc9f568: r1 = false
    //     0xc9f568: add             x1, NULL, #0x30  ; false
    // 0xc9f56c: b               #0xc9f574
    // 0xc9f570: r1 = true
    //     0xc9f570: add             x1, NULL, #0x20  ; true
    // 0xc9f574: mov             x0, x1
    // 0xc9f578: b               #0xc9f580
    // 0xc9f57c: r0 = false
    //     0xc9f57c: add             x0, NULL, #0x30  ; false
    // 0xc9f580: ret
    //     0xc9f580: ret             
  }
  factory _ RelativeRect.fromSize(/* No info */) {
    // ** addr: 0xcff810, size: 0x74
    // 0xcff810: EnterFrame
    //     0xcff810: stp             fp, lr, [SP, #-0x10]!
    //     0xcff814: mov             fp, SP
    // 0xcff818: AllocStack(0x20)
    //     0xcff818: sub             SP, SP, #0x20
    // 0xcff81c: ldr             x0, [fp, #0x18]
    // 0xcff820: LoadField: d0 = r0->field_7
    //     0xcff820: ldur            d0, [x0, #7]
    // 0xcff824: stur            d0, [fp, #-0x20]
    // 0xcff828: LoadField: d1 = r0->field_f
    //     0xcff828: ldur            d1, [x0, #0xf]
    // 0xcff82c: ldr             x1, [fp, #0x10]
    // 0xcff830: stur            d1, [fp, #-0x18]
    // 0xcff834: LoadField: d2 = r1->field_7
    //     0xcff834: ldur            d2, [x1, #7]
    // 0xcff838: LoadField: d3 = r0->field_17
    //     0xcff838: ldur            d3, [x0, #0x17]
    // 0xcff83c: fsub            d4, d2, d3
    // 0xcff840: stur            d4, [fp, #-0x10]
    // 0xcff844: LoadField: d2 = r1->field_f
    //     0xcff844: ldur            d2, [x1, #0xf]
    // 0xcff848: LoadField: d3 = r0->field_1f
    //     0xcff848: ldur            d3, [x0, #0x1f]
    // 0xcff84c: fsub            d5, d2, d3
    // 0xcff850: stur            d5, [fp, #-8]
    // 0xcff854: r0 = RelativeRect()
    //     0xcff854: bl              #0x6924f4  ; AllocateRelativeRectStub -> RelativeRect (size=0x28)
    // 0xcff858: ldur            d0, [fp, #-0x20]
    // 0xcff85c: StoreField: r0->field_7 = d0
    //     0xcff85c: stur            d0, [x0, #7]
    // 0xcff860: ldur            d0, [fp, #-0x18]
    // 0xcff864: StoreField: r0->field_f = d0
    //     0xcff864: stur            d0, [x0, #0xf]
    // 0xcff868: ldur            d0, [fp, #-0x10]
    // 0xcff86c: StoreField: r0->field_17 = d0
    //     0xcff86c: stur            d0, [x0, #0x17]
    // 0xcff870: ldur            d0, [fp, #-8]
    // 0xcff874: StoreField: r0->field_1f = d0
    //     0xcff874: stur            d0, [x0, #0x1f]
    // 0xcff878: LeaveFrame
    //     0xcff878: mov             SP, fp
    //     0xcff87c: ldp             fp, lr, [SP], #0x10
    // 0xcff880: ret
    //     0xcff880: ret             
  }
}

// class id: 2055, size: 0x30, field offset: 0x18
class StackParentData extends ContainerBoxParentData<RenderBox> {

  _ toString(/* No info */) {
    // ** addr: 0xae4878, size: 0x7f8
    // 0xae4878: EnterFrame
    //     0xae4878: stp             fp, lr, [SP, #-0x10]!
    //     0xae487c: mov             fp, SP
    // 0xae4880: AllocStack(0x18)
    //     0xae4880: sub             SP, SP, #0x18
    // 0xae4884: CheckStackOverflow
    //     0xae4884: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae4888: cmp             SP, x16
    //     0xae488c: b.ls            #0xae5048
    // 0xae4890: r16 = <String>
    //     0xae4890: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xae4894: stp             xzr, x16, [SP, #-0x10]!
    // 0xae4898: r0 = _GrowableList()
    //     0xae4898: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xae489c: add             SP, SP, #0x10
    // 0xae48a0: mov             x3, x0
    // 0xae48a4: ldr             x0, [fp, #0x10]
    // 0xae48a8: stur            x3, [fp, #-0x10]
    // 0xae48ac: LoadField: r4 = r0->field_17
    //     0xae48ac: ldur            w4, [x0, #0x17]
    // 0xae48b0: DecompressPointer r4
    //     0xae48b0: add             x4, x4, HEAP, lsl #32
    // 0xae48b4: stur            x4, [fp, #-8]
    // 0xae48b8: cmp             w4, NULL
    // 0xae48bc: b.eq            #0xae49b8
    // 0xae48c0: r1 = Null
    //     0xae48c0: mov             x1, NULL
    // 0xae48c4: r2 = 4
    //     0xae48c4: mov             x2, #4
    // 0xae48c8: r0 = AllocateArray()
    //     0xae48c8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae48cc: stur            x0, [fp, #-0x18]
    // 0xae48d0: r17 = "top="
    //     0xae48d0: add             x17, PP, #0x28, lsl #12  ; [pp+0x28508] "top="
    //     0xae48d4: ldr             x17, [x17, #0x508]
    // 0xae48d8: StoreField: r0->field_f = r17
    //     0xae48d8: stur            w17, [x0, #0xf]
    // 0xae48dc: ldur            x16, [fp, #-8]
    // 0xae48e0: SaveReg r16
    //     0xae48e0: str             x16, [SP, #-8]!
    // 0xae48e4: r0 = debugFormatDouble()
    //     0xae48e4: bl              #0xa77fb4  ; [package:flutter/src/foundation/debug.dart] ::debugFormatDouble
    // 0xae48e8: add             SP, SP, #8
    // 0xae48ec: ldur            x1, [fp, #-0x18]
    // 0xae48f0: ArrayStore: r1[1] = r0  ; List_4
    //     0xae48f0: add             x25, x1, #0x13
    //     0xae48f4: str             w0, [x25]
    //     0xae48f8: tbz             w0, #0, #0xae4914
    //     0xae48fc: ldurb           w16, [x1, #-1]
    //     0xae4900: ldurb           w17, [x0, #-1]
    //     0xae4904: and             x16, x17, x16, lsr #2
    //     0xae4908: tst             x16, HEAP, lsr #32
    //     0xae490c: b.eq            #0xae4914
    //     0xae4910: bl              #0xd67e5c
    // 0xae4914: ldur            x16, [fp, #-0x18]
    // 0xae4918: SaveReg r16
    //     0xae4918: str             x16, [SP, #-8]!
    // 0xae491c: r0 = _interpolate()
    //     0xae491c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae4920: add             SP, SP, #8
    // 0xae4924: mov             x1, x0
    // 0xae4928: ldur            x0, [fp, #-0x10]
    // 0xae492c: stur            x1, [fp, #-0x18]
    // 0xae4930: LoadField: r2 = r0->field_b
    //     0xae4930: ldur            w2, [x0, #0xb]
    // 0xae4934: DecompressPointer r2
    //     0xae4934: add             x2, x2, HEAP, lsl #32
    // 0xae4938: stur            x2, [fp, #-8]
    // 0xae493c: LoadField: r3 = r0->field_f
    //     0xae493c: ldur            w3, [x0, #0xf]
    // 0xae4940: DecompressPointer r3
    //     0xae4940: add             x3, x3, HEAP, lsl #32
    // 0xae4944: LoadField: r4 = r3->field_b
    //     0xae4944: ldur            w4, [x3, #0xb]
    // 0xae4948: DecompressPointer r4
    //     0xae4948: add             x4, x4, HEAP, lsl #32
    // 0xae494c: cmp             w2, w4
    // 0xae4950: b.ne            #0xae4960
    // 0xae4954: SaveReg r0
    //     0xae4954: str             x0, [SP, #-8]!
    // 0xae4958: r0 = _growToNextCapacity()
    //     0xae4958: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae495c: add             SP, SP, #8
    // 0xae4960: ldur            x3, [fp, #-0x10]
    // 0xae4964: ldur            x0, [fp, #-8]
    // 0xae4968: r2 = LoadInt32Instr(r0)
    //     0xae4968: sbfx            x2, x0, #1, #0x1f
    // 0xae496c: add             x0, x2, #1
    // 0xae4970: lsl             x1, x0, #1
    // 0xae4974: StoreField: r3->field_b = r1
    //     0xae4974: stur            w1, [x3, #0xb]
    // 0xae4978: mov             x1, x2
    // 0xae497c: cmp             x1, x0
    // 0xae4980: b.hs            #0xae5050
    // 0xae4984: LoadField: r1 = r3->field_f
    //     0xae4984: ldur            w1, [x3, #0xf]
    // 0xae4988: DecompressPointer r1
    //     0xae4988: add             x1, x1, HEAP, lsl #32
    // 0xae498c: ldur            x0, [fp, #-0x18]
    // 0xae4990: ArrayStore: r1[r2] = r0  ; List_4
    //     0xae4990: add             x25, x1, x2, lsl #2
    //     0xae4994: add             x25, x25, #0xf
    //     0xae4998: str             w0, [x25]
    //     0xae499c: tbz             w0, #0, #0xae49b8
    //     0xae49a0: ldurb           w16, [x1, #-1]
    //     0xae49a4: ldurb           w17, [x0, #-1]
    //     0xae49a8: and             x16, x17, x16, lsr #2
    //     0xae49ac: tst             x16, HEAP, lsr #32
    //     0xae49b0: b.eq            #0xae49b8
    //     0xae49b4: bl              #0xd67e5c
    // 0xae49b8: ldr             x0, [fp, #0x10]
    // 0xae49bc: LoadField: r4 = r0->field_1b
    //     0xae49bc: ldur            w4, [x0, #0x1b]
    // 0xae49c0: DecompressPointer r4
    //     0xae49c0: add             x4, x4, HEAP, lsl #32
    // 0xae49c4: stur            x4, [fp, #-8]
    // 0xae49c8: cmp             w4, NULL
    // 0xae49cc: b.eq            #0xae4ac8
    // 0xae49d0: r1 = Null
    //     0xae49d0: mov             x1, NULL
    // 0xae49d4: r2 = 4
    //     0xae49d4: mov             x2, #4
    // 0xae49d8: r0 = AllocateArray()
    //     0xae49d8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae49dc: stur            x0, [fp, #-0x18]
    // 0xae49e0: r17 = "right="
    //     0xae49e0: add             x17, PP, #0x28, lsl #12  ; [pp+0x28510] "right="
    //     0xae49e4: ldr             x17, [x17, #0x510]
    // 0xae49e8: StoreField: r0->field_f = r17
    //     0xae49e8: stur            w17, [x0, #0xf]
    // 0xae49ec: ldur            x16, [fp, #-8]
    // 0xae49f0: SaveReg r16
    //     0xae49f0: str             x16, [SP, #-8]!
    // 0xae49f4: r0 = debugFormatDouble()
    //     0xae49f4: bl              #0xa77fb4  ; [package:flutter/src/foundation/debug.dart] ::debugFormatDouble
    // 0xae49f8: add             SP, SP, #8
    // 0xae49fc: ldur            x1, [fp, #-0x18]
    // 0xae4a00: ArrayStore: r1[1] = r0  ; List_4
    //     0xae4a00: add             x25, x1, #0x13
    //     0xae4a04: str             w0, [x25]
    //     0xae4a08: tbz             w0, #0, #0xae4a24
    //     0xae4a0c: ldurb           w16, [x1, #-1]
    //     0xae4a10: ldurb           w17, [x0, #-1]
    //     0xae4a14: and             x16, x17, x16, lsr #2
    //     0xae4a18: tst             x16, HEAP, lsr #32
    //     0xae4a1c: b.eq            #0xae4a24
    //     0xae4a20: bl              #0xd67e5c
    // 0xae4a24: ldur            x16, [fp, #-0x18]
    // 0xae4a28: SaveReg r16
    //     0xae4a28: str             x16, [SP, #-8]!
    // 0xae4a2c: r0 = _interpolate()
    //     0xae4a2c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae4a30: add             SP, SP, #8
    // 0xae4a34: mov             x1, x0
    // 0xae4a38: ldur            x0, [fp, #-0x10]
    // 0xae4a3c: stur            x1, [fp, #-0x18]
    // 0xae4a40: LoadField: r2 = r0->field_b
    //     0xae4a40: ldur            w2, [x0, #0xb]
    // 0xae4a44: DecompressPointer r2
    //     0xae4a44: add             x2, x2, HEAP, lsl #32
    // 0xae4a48: stur            x2, [fp, #-8]
    // 0xae4a4c: LoadField: r3 = r0->field_f
    //     0xae4a4c: ldur            w3, [x0, #0xf]
    // 0xae4a50: DecompressPointer r3
    //     0xae4a50: add             x3, x3, HEAP, lsl #32
    // 0xae4a54: LoadField: r4 = r3->field_b
    //     0xae4a54: ldur            w4, [x3, #0xb]
    // 0xae4a58: DecompressPointer r4
    //     0xae4a58: add             x4, x4, HEAP, lsl #32
    // 0xae4a5c: cmp             w2, w4
    // 0xae4a60: b.ne            #0xae4a70
    // 0xae4a64: SaveReg r0
    //     0xae4a64: str             x0, [SP, #-8]!
    // 0xae4a68: r0 = _growToNextCapacity()
    //     0xae4a68: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae4a6c: add             SP, SP, #8
    // 0xae4a70: ldur            x3, [fp, #-0x10]
    // 0xae4a74: ldur            x0, [fp, #-8]
    // 0xae4a78: r2 = LoadInt32Instr(r0)
    //     0xae4a78: sbfx            x2, x0, #1, #0x1f
    // 0xae4a7c: add             x0, x2, #1
    // 0xae4a80: lsl             x1, x0, #1
    // 0xae4a84: StoreField: r3->field_b = r1
    //     0xae4a84: stur            w1, [x3, #0xb]
    // 0xae4a88: mov             x1, x2
    // 0xae4a8c: cmp             x1, x0
    // 0xae4a90: b.hs            #0xae5054
    // 0xae4a94: LoadField: r1 = r3->field_f
    //     0xae4a94: ldur            w1, [x3, #0xf]
    // 0xae4a98: DecompressPointer r1
    //     0xae4a98: add             x1, x1, HEAP, lsl #32
    // 0xae4a9c: ldur            x0, [fp, #-0x18]
    // 0xae4aa0: ArrayStore: r1[r2] = r0  ; List_4
    //     0xae4aa0: add             x25, x1, x2, lsl #2
    //     0xae4aa4: add             x25, x25, #0xf
    //     0xae4aa8: str             w0, [x25]
    //     0xae4aac: tbz             w0, #0, #0xae4ac8
    //     0xae4ab0: ldurb           w16, [x1, #-1]
    //     0xae4ab4: ldurb           w17, [x0, #-1]
    //     0xae4ab8: and             x16, x17, x16, lsr #2
    //     0xae4abc: tst             x16, HEAP, lsr #32
    //     0xae4ac0: b.eq            #0xae4ac8
    //     0xae4ac4: bl              #0xd67e5c
    // 0xae4ac8: ldr             x0, [fp, #0x10]
    // 0xae4acc: LoadField: r4 = r0->field_1f
    //     0xae4acc: ldur            w4, [x0, #0x1f]
    // 0xae4ad0: DecompressPointer r4
    //     0xae4ad0: add             x4, x4, HEAP, lsl #32
    // 0xae4ad4: stur            x4, [fp, #-8]
    // 0xae4ad8: cmp             w4, NULL
    // 0xae4adc: b.eq            #0xae4bd8
    // 0xae4ae0: r1 = Null
    //     0xae4ae0: mov             x1, NULL
    // 0xae4ae4: r2 = 4
    //     0xae4ae4: mov             x2, #4
    // 0xae4ae8: r0 = AllocateArray()
    //     0xae4ae8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae4aec: stur            x0, [fp, #-0x18]
    // 0xae4af0: r17 = "bottom="
    //     0xae4af0: add             x17, PP, #0x28, lsl #12  ; [pp+0x28518] "bottom="
    //     0xae4af4: ldr             x17, [x17, #0x518]
    // 0xae4af8: StoreField: r0->field_f = r17
    //     0xae4af8: stur            w17, [x0, #0xf]
    // 0xae4afc: ldur            x16, [fp, #-8]
    // 0xae4b00: SaveReg r16
    //     0xae4b00: str             x16, [SP, #-8]!
    // 0xae4b04: r0 = debugFormatDouble()
    //     0xae4b04: bl              #0xa77fb4  ; [package:flutter/src/foundation/debug.dart] ::debugFormatDouble
    // 0xae4b08: add             SP, SP, #8
    // 0xae4b0c: ldur            x1, [fp, #-0x18]
    // 0xae4b10: ArrayStore: r1[1] = r0  ; List_4
    //     0xae4b10: add             x25, x1, #0x13
    //     0xae4b14: str             w0, [x25]
    //     0xae4b18: tbz             w0, #0, #0xae4b34
    //     0xae4b1c: ldurb           w16, [x1, #-1]
    //     0xae4b20: ldurb           w17, [x0, #-1]
    //     0xae4b24: and             x16, x17, x16, lsr #2
    //     0xae4b28: tst             x16, HEAP, lsr #32
    //     0xae4b2c: b.eq            #0xae4b34
    //     0xae4b30: bl              #0xd67e5c
    // 0xae4b34: ldur            x16, [fp, #-0x18]
    // 0xae4b38: SaveReg r16
    //     0xae4b38: str             x16, [SP, #-8]!
    // 0xae4b3c: r0 = _interpolate()
    //     0xae4b3c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae4b40: add             SP, SP, #8
    // 0xae4b44: mov             x1, x0
    // 0xae4b48: ldur            x0, [fp, #-0x10]
    // 0xae4b4c: stur            x1, [fp, #-0x18]
    // 0xae4b50: LoadField: r2 = r0->field_b
    //     0xae4b50: ldur            w2, [x0, #0xb]
    // 0xae4b54: DecompressPointer r2
    //     0xae4b54: add             x2, x2, HEAP, lsl #32
    // 0xae4b58: stur            x2, [fp, #-8]
    // 0xae4b5c: LoadField: r3 = r0->field_f
    //     0xae4b5c: ldur            w3, [x0, #0xf]
    // 0xae4b60: DecompressPointer r3
    //     0xae4b60: add             x3, x3, HEAP, lsl #32
    // 0xae4b64: LoadField: r4 = r3->field_b
    //     0xae4b64: ldur            w4, [x3, #0xb]
    // 0xae4b68: DecompressPointer r4
    //     0xae4b68: add             x4, x4, HEAP, lsl #32
    // 0xae4b6c: cmp             w2, w4
    // 0xae4b70: b.ne            #0xae4b80
    // 0xae4b74: SaveReg r0
    //     0xae4b74: str             x0, [SP, #-8]!
    // 0xae4b78: r0 = _growToNextCapacity()
    //     0xae4b78: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae4b7c: add             SP, SP, #8
    // 0xae4b80: ldur            x3, [fp, #-0x10]
    // 0xae4b84: ldur            x0, [fp, #-8]
    // 0xae4b88: r2 = LoadInt32Instr(r0)
    //     0xae4b88: sbfx            x2, x0, #1, #0x1f
    // 0xae4b8c: add             x0, x2, #1
    // 0xae4b90: lsl             x1, x0, #1
    // 0xae4b94: StoreField: r3->field_b = r1
    //     0xae4b94: stur            w1, [x3, #0xb]
    // 0xae4b98: mov             x1, x2
    // 0xae4b9c: cmp             x1, x0
    // 0xae4ba0: b.hs            #0xae5058
    // 0xae4ba4: LoadField: r1 = r3->field_f
    //     0xae4ba4: ldur            w1, [x3, #0xf]
    // 0xae4ba8: DecompressPointer r1
    //     0xae4ba8: add             x1, x1, HEAP, lsl #32
    // 0xae4bac: ldur            x0, [fp, #-0x18]
    // 0xae4bb0: ArrayStore: r1[r2] = r0  ; List_4
    //     0xae4bb0: add             x25, x1, x2, lsl #2
    //     0xae4bb4: add             x25, x25, #0xf
    //     0xae4bb8: str             w0, [x25]
    //     0xae4bbc: tbz             w0, #0, #0xae4bd8
    //     0xae4bc0: ldurb           w16, [x1, #-1]
    //     0xae4bc4: ldurb           w17, [x0, #-1]
    //     0xae4bc8: and             x16, x17, x16, lsr #2
    //     0xae4bcc: tst             x16, HEAP, lsr #32
    //     0xae4bd0: b.eq            #0xae4bd8
    //     0xae4bd4: bl              #0xd67e5c
    // 0xae4bd8: ldr             x0, [fp, #0x10]
    // 0xae4bdc: LoadField: r4 = r0->field_23
    //     0xae4bdc: ldur            w4, [x0, #0x23]
    // 0xae4be0: DecompressPointer r4
    //     0xae4be0: add             x4, x4, HEAP, lsl #32
    // 0xae4be4: stur            x4, [fp, #-8]
    // 0xae4be8: cmp             w4, NULL
    // 0xae4bec: b.eq            #0xae4ce8
    // 0xae4bf0: r1 = Null
    //     0xae4bf0: mov             x1, NULL
    // 0xae4bf4: r2 = 4
    //     0xae4bf4: mov             x2, #4
    // 0xae4bf8: r0 = AllocateArray()
    //     0xae4bf8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae4bfc: stur            x0, [fp, #-0x18]
    // 0xae4c00: r17 = "left="
    //     0xae4c00: add             x17, PP, #0x28, lsl #12  ; [pp+0x28520] "left="
    //     0xae4c04: ldr             x17, [x17, #0x520]
    // 0xae4c08: StoreField: r0->field_f = r17
    //     0xae4c08: stur            w17, [x0, #0xf]
    // 0xae4c0c: ldur            x16, [fp, #-8]
    // 0xae4c10: SaveReg r16
    //     0xae4c10: str             x16, [SP, #-8]!
    // 0xae4c14: r0 = debugFormatDouble()
    //     0xae4c14: bl              #0xa77fb4  ; [package:flutter/src/foundation/debug.dart] ::debugFormatDouble
    // 0xae4c18: add             SP, SP, #8
    // 0xae4c1c: ldur            x1, [fp, #-0x18]
    // 0xae4c20: ArrayStore: r1[1] = r0  ; List_4
    //     0xae4c20: add             x25, x1, #0x13
    //     0xae4c24: str             w0, [x25]
    //     0xae4c28: tbz             w0, #0, #0xae4c44
    //     0xae4c2c: ldurb           w16, [x1, #-1]
    //     0xae4c30: ldurb           w17, [x0, #-1]
    //     0xae4c34: and             x16, x17, x16, lsr #2
    //     0xae4c38: tst             x16, HEAP, lsr #32
    //     0xae4c3c: b.eq            #0xae4c44
    //     0xae4c40: bl              #0xd67e5c
    // 0xae4c44: ldur            x16, [fp, #-0x18]
    // 0xae4c48: SaveReg r16
    //     0xae4c48: str             x16, [SP, #-8]!
    // 0xae4c4c: r0 = _interpolate()
    //     0xae4c4c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae4c50: add             SP, SP, #8
    // 0xae4c54: mov             x1, x0
    // 0xae4c58: ldur            x0, [fp, #-0x10]
    // 0xae4c5c: stur            x1, [fp, #-0x18]
    // 0xae4c60: LoadField: r2 = r0->field_b
    //     0xae4c60: ldur            w2, [x0, #0xb]
    // 0xae4c64: DecompressPointer r2
    //     0xae4c64: add             x2, x2, HEAP, lsl #32
    // 0xae4c68: stur            x2, [fp, #-8]
    // 0xae4c6c: LoadField: r3 = r0->field_f
    //     0xae4c6c: ldur            w3, [x0, #0xf]
    // 0xae4c70: DecompressPointer r3
    //     0xae4c70: add             x3, x3, HEAP, lsl #32
    // 0xae4c74: LoadField: r4 = r3->field_b
    //     0xae4c74: ldur            w4, [x3, #0xb]
    // 0xae4c78: DecompressPointer r4
    //     0xae4c78: add             x4, x4, HEAP, lsl #32
    // 0xae4c7c: cmp             w2, w4
    // 0xae4c80: b.ne            #0xae4c90
    // 0xae4c84: SaveReg r0
    //     0xae4c84: str             x0, [SP, #-8]!
    // 0xae4c88: r0 = _growToNextCapacity()
    //     0xae4c88: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae4c8c: add             SP, SP, #8
    // 0xae4c90: ldur            x3, [fp, #-0x10]
    // 0xae4c94: ldur            x0, [fp, #-8]
    // 0xae4c98: r2 = LoadInt32Instr(r0)
    //     0xae4c98: sbfx            x2, x0, #1, #0x1f
    // 0xae4c9c: add             x0, x2, #1
    // 0xae4ca0: lsl             x1, x0, #1
    // 0xae4ca4: StoreField: r3->field_b = r1
    //     0xae4ca4: stur            w1, [x3, #0xb]
    // 0xae4ca8: mov             x1, x2
    // 0xae4cac: cmp             x1, x0
    // 0xae4cb0: b.hs            #0xae505c
    // 0xae4cb4: LoadField: r1 = r3->field_f
    //     0xae4cb4: ldur            w1, [x3, #0xf]
    // 0xae4cb8: DecompressPointer r1
    //     0xae4cb8: add             x1, x1, HEAP, lsl #32
    // 0xae4cbc: ldur            x0, [fp, #-0x18]
    // 0xae4cc0: ArrayStore: r1[r2] = r0  ; List_4
    //     0xae4cc0: add             x25, x1, x2, lsl #2
    //     0xae4cc4: add             x25, x25, #0xf
    //     0xae4cc8: str             w0, [x25]
    //     0xae4ccc: tbz             w0, #0, #0xae4ce8
    //     0xae4cd0: ldurb           w16, [x1, #-1]
    //     0xae4cd4: ldurb           w17, [x0, #-1]
    //     0xae4cd8: and             x16, x17, x16, lsr #2
    //     0xae4cdc: tst             x16, HEAP, lsr #32
    //     0xae4ce0: b.eq            #0xae4ce8
    //     0xae4ce4: bl              #0xd67e5c
    // 0xae4ce8: ldr             x0, [fp, #0x10]
    // 0xae4cec: LoadField: r4 = r0->field_27
    //     0xae4cec: ldur            w4, [x0, #0x27]
    // 0xae4cf0: DecompressPointer r4
    //     0xae4cf0: add             x4, x4, HEAP, lsl #32
    // 0xae4cf4: stur            x4, [fp, #-8]
    // 0xae4cf8: cmp             w4, NULL
    // 0xae4cfc: b.eq            #0xae4df8
    // 0xae4d00: r1 = Null
    //     0xae4d00: mov             x1, NULL
    // 0xae4d04: r2 = 4
    //     0xae4d04: mov             x2, #4
    // 0xae4d08: r0 = AllocateArray()
    //     0xae4d08: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae4d0c: stur            x0, [fp, #-0x18]
    // 0xae4d10: r17 = "width="
    //     0xae4d10: add             x17, PP, #0x28, lsl #12  ; [pp+0x28528] "width="
    //     0xae4d14: ldr             x17, [x17, #0x528]
    // 0xae4d18: StoreField: r0->field_f = r17
    //     0xae4d18: stur            w17, [x0, #0xf]
    // 0xae4d1c: ldur            x16, [fp, #-8]
    // 0xae4d20: SaveReg r16
    //     0xae4d20: str             x16, [SP, #-8]!
    // 0xae4d24: r0 = debugFormatDouble()
    //     0xae4d24: bl              #0xa77fb4  ; [package:flutter/src/foundation/debug.dart] ::debugFormatDouble
    // 0xae4d28: add             SP, SP, #8
    // 0xae4d2c: ldur            x1, [fp, #-0x18]
    // 0xae4d30: ArrayStore: r1[1] = r0  ; List_4
    //     0xae4d30: add             x25, x1, #0x13
    //     0xae4d34: str             w0, [x25]
    //     0xae4d38: tbz             w0, #0, #0xae4d54
    //     0xae4d3c: ldurb           w16, [x1, #-1]
    //     0xae4d40: ldurb           w17, [x0, #-1]
    //     0xae4d44: and             x16, x17, x16, lsr #2
    //     0xae4d48: tst             x16, HEAP, lsr #32
    //     0xae4d4c: b.eq            #0xae4d54
    //     0xae4d50: bl              #0xd67e5c
    // 0xae4d54: ldur            x16, [fp, #-0x18]
    // 0xae4d58: SaveReg r16
    //     0xae4d58: str             x16, [SP, #-8]!
    // 0xae4d5c: r0 = _interpolate()
    //     0xae4d5c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae4d60: add             SP, SP, #8
    // 0xae4d64: mov             x1, x0
    // 0xae4d68: ldur            x0, [fp, #-0x10]
    // 0xae4d6c: stur            x1, [fp, #-0x18]
    // 0xae4d70: LoadField: r2 = r0->field_b
    //     0xae4d70: ldur            w2, [x0, #0xb]
    // 0xae4d74: DecompressPointer r2
    //     0xae4d74: add             x2, x2, HEAP, lsl #32
    // 0xae4d78: stur            x2, [fp, #-8]
    // 0xae4d7c: LoadField: r3 = r0->field_f
    //     0xae4d7c: ldur            w3, [x0, #0xf]
    // 0xae4d80: DecompressPointer r3
    //     0xae4d80: add             x3, x3, HEAP, lsl #32
    // 0xae4d84: LoadField: r4 = r3->field_b
    //     0xae4d84: ldur            w4, [x3, #0xb]
    // 0xae4d88: DecompressPointer r4
    //     0xae4d88: add             x4, x4, HEAP, lsl #32
    // 0xae4d8c: cmp             w2, w4
    // 0xae4d90: b.ne            #0xae4da0
    // 0xae4d94: SaveReg r0
    //     0xae4d94: str             x0, [SP, #-8]!
    // 0xae4d98: r0 = _growToNextCapacity()
    //     0xae4d98: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae4d9c: add             SP, SP, #8
    // 0xae4da0: ldur            x3, [fp, #-0x10]
    // 0xae4da4: ldur            x0, [fp, #-8]
    // 0xae4da8: r2 = LoadInt32Instr(r0)
    //     0xae4da8: sbfx            x2, x0, #1, #0x1f
    // 0xae4dac: add             x0, x2, #1
    // 0xae4db0: lsl             x1, x0, #1
    // 0xae4db4: StoreField: r3->field_b = r1
    //     0xae4db4: stur            w1, [x3, #0xb]
    // 0xae4db8: mov             x1, x2
    // 0xae4dbc: cmp             x1, x0
    // 0xae4dc0: b.hs            #0xae5060
    // 0xae4dc4: LoadField: r1 = r3->field_f
    //     0xae4dc4: ldur            w1, [x3, #0xf]
    // 0xae4dc8: DecompressPointer r1
    //     0xae4dc8: add             x1, x1, HEAP, lsl #32
    // 0xae4dcc: ldur            x0, [fp, #-0x18]
    // 0xae4dd0: ArrayStore: r1[r2] = r0  ; List_4
    //     0xae4dd0: add             x25, x1, x2, lsl #2
    //     0xae4dd4: add             x25, x25, #0xf
    //     0xae4dd8: str             w0, [x25]
    //     0xae4ddc: tbz             w0, #0, #0xae4df8
    //     0xae4de0: ldurb           w16, [x1, #-1]
    //     0xae4de4: ldurb           w17, [x0, #-1]
    //     0xae4de8: and             x16, x17, x16, lsr #2
    //     0xae4dec: tst             x16, HEAP, lsr #32
    //     0xae4df0: b.eq            #0xae4df8
    //     0xae4df4: bl              #0xd67e5c
    // 0xae4df8: ldr             x0, [fp, #0x10]
    // 0xae4dfc: LoadField: r4 = r0->field_2b
    //     0xae4dfc: ldur            w4, [x0, #0x2b]
    // 0xae4e00: DecompressPointer r4
    //     0xae4e00: add             x4, x4, HEAP, lsl #32
    // 0xae4e04: stur            x4, [fp, #-8]
    // 0xae4e08: cmp             w4, NULL
    // 0xae4e0c: b.eq            #0xae4f0c
    // 0xae4e10: r1 = Null
    //     0xae4e10: mov             x1, NULL
    // 0xae4e14: r2 = 4
    //     0xae4e14: mov             x2, #4
    // 0xae4e18: r0 = AllocateArray()
    //     0xae4e18: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae4e1c: stur            x0, [fp, #-0x18]
    // 0xae4e20: r17 = "height="
    //     0xae4e20: add             x17, PP, #0x28, lsl #12  ; [pp+0x28530] "height="
    //     0xae4e24: ldr             x17, [x17, #0x530]
    // 0xae4e28: StoreField: r0->field_f = r17
    //     0xae4e28: stur            w17, [x0, #0xf]
    // 0xae4e2c: ldur            x16, [fp, #-8]
    // 0xae4e30: SaveReg r16
    //     0xae4e30: str             x16, [SP, #-8]!
    // 0xae4e34: r0 = debugFormatDouble()
    //     0xae4e34: bl              #0xa77fb4  ; [package:flutter/src/foundation/debug.dart] ::debugFormatDouble
    // 0xae4e38: add             SP, SP, #8
    // 0xae4e3c: ldur            x1, [fp, #-0x18]
    // 0xae4e40: ArrayStore: r1[1] = r0  ; List_4
    //     0xae4e40: add             x25, x1, #0x13
    //     0xae4e44: str             w0, [x25]
    //     0xae4e48: tbz             w0, #0, #0xae4e64
    //     0xae4e4c: ldurb           w16, [x1, #-1]
    //     0xae4e50: ldurb           w17, [x0, #-1]
    //     0xae4e54: and             x16, x17, x16, lsr #2
    //     0xae4e58: tst             x16, HEAP, lsr #32
    //     0xae4e5c: b.eq            #0xae4e64
    //     0xae4e60: bl              #0xd67e5c
    // 0xae4e64: ldur            x16, [fp, #-0x18]
    // 0xae4e68: SaveReg r16
    //     0xae4e68: str             x16, [SP, #-8]!
    // 0xae4e6c: r0 = _interpolate()
    //     0xae4e6c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae4e70: add             SP, SP, #8
    // 0xae4e74: mov             x1, x0
    // 0xae4e78: ldur            x0, [fp, #-0x10]
    // 0xae4e7c: stur            x1, [fp, #-0x18]
    // 0xae4e80: LoadField: r2 = r0->field_b
    //     0xae4e80: ldur            w2, [x0, #0xb]
    // 0xae4e84: DecompressPointer r2
    //     0xae4e84: add             x2, x2, HEAP, lsl #32
    // 0xae4e88: stur            x2, [fp, #-8]
    // 0xae4e8c: LoadField: r3 = r0->field_f
    //     0xae4e8c: ldur            w3, [x0, #0xf]
    // 0xae4e90: DecompressPointer r3
    //     0xae4e90: add             x3, x3, HEAP, lsl #32
    // 0xae4e94: LoadField: r4 = r3->field_b
    //     0xae4e94: ldur            w4, [x3, #0xb]
    // 0xae4e98: DecompressPointer r4
    //     0xae4e98: add             x4, x4, HEAP, lsl #32
    // 0xae4e9c: cmp             w2, w4
    // 0xae4ea0: b.ne            #0xae4eb0
    // 0xae4ea4: SaveReg r0
    //     0xae4ea4: str             x0, [SP, #-8]!
    // 0xae4ea8: r0 = _growToNextCapacity()
    //     0xae4ea8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae4eac: add             SP, SP, #8
    // 0xae4eb0: ldur            x2, [fp, #-0x10]
    // 0xae4eb4: ldur            x0, [fp, #-8]
    // 0xae4eb8: r3 = LoadInt32Instr(r0)
    //     0xae4eb8: sbfx            x3, x0, #1, #0x1f
    // 0xae4ebc: add             x0, x3, #1
    // 0xae4ec0: lsl             x1, x0, #1
    // 0xae4ec4: StoreField: r2->field_b = r1
    //     0xae4ec4: stur            w1, [x2, #0xb]
    // 0xae4ec8: mov             x1, x3
    // 0xae4ecc: cmp             x1, x0
    // 0xae4ed0: b.hs            #0xae5064
    // 0xae4ed4: LoadField: r1 = r2->field_f
    //     0xae4ed4: ldur            w1, [x2, #0xf]
    // 0xae4ed8: DecompressPointer r1
    //     0xae4ed8: add             x1, x1, HEAP, lsl #32
    // 0xae4edc: ldur            x0, [fp, #-0x18]
    // 0xae4ee0: ArrayStore: r1[r3] = r0  ; List_4
    //     0xae4ee0: add             x25, x1, x3, lsl #2
    //     0xae4ee4: add             x25, x25, #0xf
    //     0xae4ee8: str             w0, [x25]
    //     0xae4eec: tbz             w0, #0, #0xae4f08
    //     0xae4ef0: ldurb           w16, [x1, #-1]
    //     0xae4ef4: ldurb           w17, [x0, #-1]
    //     0xae4ef8: and             x16, x17, x16, lsr #2
    //     0xae4efc: tst             x16, HEAP, lsr #32
    //     0xae4f00: b.eq            #0xae4f08
    //     0xae4f04: bl              #0xd67e5c
    // 0xae4f08: b               #0xae4f10
    // 0xae4f0c: mov             x2, x3
    // 0xae4f10: LoadField: r0 = r2->field_b
    //     0xae4f10: ldur            w0, [x2, #0xb]
    // 0xae4f14: DecompressPointer r0
    //     0xae4f14: add             x0, x0, HEAP, lsl #32
    // 0xae4f18: stur            x0, [fp, #-8]
    // 0xae4f1c: cbnz            w0, #0xae4f80
    // 0xae4f20: LoadField: r1 = r2->field_f
    //     0xae4f20: ldur            w1, [x2, #0xf]
    // 0xae4f24: DecompressPointer r1
    //     0xae4f24: add             x1, x1, HEAP, lsl #32
    // 0xae4f28: LoadField: r3 = r1->field_b
    //     0xae4f28: ldur            w3, [x1, #0xb]
    // 0xae4f2c: DecompressPointer r3
    //     0xae4f2c: add             x3, x3, HEAP, lsl #32
    // 0xae4f30: cmp             w0, w3
    // 0xae4f34: b.ne            #0xae4f44
    // 0xae4f38: SaveReg r2
    //     0xae4f38: str             x2, [SP, #-8]!
    // 0xae4f3c: r0 = _growToNextCapacity()
    //     0xae4f3c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae4f40: add             SP, SP, #8
    // 0xae4f44: ldur            x2, [fp, #-0x10]
    // 0xae4f48: ldur            x0, [fp, #-8]
    // 0xae4f4c: r3 = LoadInt32Instr(r0)
    //     0xae4f4c: sbfx            x3, x0, #1, #0x1f
    // 0xae4f50: add             x0, x3, #1
    // 0xae4f54: lsl             x1, x0, #1
    // 0xae4f58: StoreField: r2->field_b = r1
    //     0xae4f58: stur            w1, [x2, #0xb]
    // 0xae4f5c: mov             x1, x3
    // 0xae4f60: cmp             x1, x0
    // 0xae4f64: b.hs            #0xae5068
    // 0xae4f68: LoadField: r0 = r2->field_f
    //     0xae4f68: ldur            w0, [x2, #0xf]
    // 0xae4f6c: DecompressPointer r0
    //     0xae4f6c: add             x0, x0, HEAP, lsl #32
    // 0xae4f70: add             x1, x0, x3, lsl #2
    // 0xae4f74: r17 = "not positioned"
    //     0xae4f74: add             x17, PP, #0x28, lsl #12  ; [pp+0x28538] "not positioned"
    //     0xae4f78: ldr             x17, [x17, #0x538]
    // 0xae4f7c: StoreField: r1->field_f = r17
    //     0xae4f7c: stur            w17, [x1, #0xf]
    // 0xae4f80: ldr             x16, [fp, #0x10]
    // 0xae4f84: SaveReg r16
    //     0xae4f84: str             x16, [SP, #-8]!
    // 0xae4f88: r0 = toString()
    //     0xae4f88: bl              #0xae516c  ; [package:flutter/src/rendering/box.dart] BoxParentData::toString
    // 0xae4f8c: add             SP, SP, #8
    // 0xae4f90: mov             x1, x0
    // 0xae4f94: ldur            x0, [fp, #-0x10]
    // 0xae4f98: stur            x1, [fp, #-0x18]
    // 0xae4f9c: LoadField: r2 = r0->field_b
    //     0xae4f9c: ldur            w2, [x0, #0xb]
    // 0xae4fa0: DecompressPointer r2
    //     0xae4fa0: add             x2, x2, HEAP, lsl #32
    // 0xae4fa4: stur            x2, [fp, #-8]
    // 0xae4fa8: LoadField: r3 = r0->field_f
    //     0xae4fa8: ldur            w3, [x0, #0xf]
    // 0xae4fac: DecompressPointer r3
    //     0xae4fac: add             x3, x3, HEAP, lsl #32
    // 0xae4fb0: LoadField: r4 = r3->field_b
    //     0xae4fb0: ldur            w4, [x3, #0xb]
    // 0xae4fb4: DecompressPointer r4
    //     0xae4fb4: add             x4, x4, HEAP, lsl #32
    // 0xae4fb8: cmp             w2, w4
    // 0xae4fbc: b.ne            #0xae4fcc
    // 0xae4fc0: SaveReg r0
    //     0xae4fc0: str             x0, [SP, #-8]!
    // 0xae4fc4: r0 = _growToNextCapacity()
    //     0xae4fc4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae4fc8: add             SP, SP, #8
    // 0xae4fcc: ldur            x2, [fp, #-0x10]
    // 0xae4fd0: ldur            x0, [fp, #-8]
    // 0xae4fd4: r3 = LoadInt32Instr(r0)
    //     0xae4fd4: sbfx            x3, x0, #1, #0x1f
    // 0xae4fd8: add             x0, x3, #1
    // 0xae4fdc: lsl             x1, x0, #1
    // 0xae4fe0: StoreField: r2->field_b = r1
    //     0xae4fe0: stur            w1, [x2, #0xb]
    // 0xae4fe4: mov             x1, x3
    // 0xae4fe8: cmp             x1, x0
    // 0xae4fec: b.hs            #0xae506c
    // 0xae4ff0: LoadField: r1 = r2->field_f
    //     0xae4ff0: ldur            w1, [x2, #0xf]
    // 0xae4ff4: DecompressPointer r1
    //     0xae4ff4: add             x1, x1, HEAP, lsl #32
    // 0xae4ff8: ldur            x0, [fp, #-0x18]
    // 0xae4ffc: ArrayStore: r1[r3] = r0  ; List_4
    //     0xae4ffc: add             x25, x1, x3, lsl #2
    //     0xae5000: add             x25, x25, #0xf
    //     0xae5004: str             w0, [x25]
    //     0xae5008: tbz             w0, #0, #0xae5024
    //     0xae500c: ldurb           w16, [x1, #-1]
    //     0xae5010: ldurb           w17, [x0, #-1]
    //     0xae5014: and             x16, x17, x16, lsr #2
    //     0xae5018: tst             x16, HEAP, lsr #32
    //     0xae501c: b.eq            #0xae5024
    //     0xae5020: bl              #0xd67e5c
    // 0xae5024: r16 = "; "
    //     0xae5024: add             x16, PP, #0x1b, lsl #12  ; [pp+0x1bca8] "; "
    //     0xae5028: ldr             x16, [x16, #0xca8]
    // 0xae502c: stp             x16, x2, [SP, #-0x10]!
    // 0xae5030: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xae5030: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xae5034: r0 = join()
    //     0xae5034: bl              #0x6fddb0  ; [dart:core] _GrowableList::join
    // 0xae5038: add             SP, SP, #0x10
    // 0xae503c: LeaveFrame
    //     0xae503c: mov             SP, fp
    //     0xae5040: ldp             fp, lr, [SP], #0x10
    // 0xae5044: ret
    //     0xae5044: ret             
    // 0xae5048: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae5048: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae504c: b               #0xae4890
    // 0xae5050: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae5050: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xae5054: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae5054: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xae5058: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae5058: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xae505c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae505c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xae5060: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae5060: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xae5064: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae5064: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xae5068: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae5068: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xae506c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae506c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 2426, size: 0x70, field offset: 0x70
//   transformed mixin,
abstract class _RenderStack&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin extends __RenderTheatre&RenderBox&ContainerRenderObjectMixin
     with RenderBoxContainerDefaultsMixin<X0 bound RenderBox, X1 bound ContainerBoxParentData<X0 bound RenderBox>> {

  _ defaultHitTestChildren(/* No info */) {
    // ** addr: 0x629bc8, size: 0x15c
    // 0x629bc8: EnterFrame
    //     0x629bc8: stp             fp, lr, [SP, #-0x10]!
    //     0x629bcc: mov             fp, SP
    // 0x629bd0: AllocStack(0x20)
    //     0x629bd0: sub             SP, SP, #0x20
    // 0x629bd4: CheckStackOverflow
    //     0x629bd4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x629bd8: cmp             SP, x16
    //     0x629bdc: b.ls            #0x629d10
    // 0x629be0: ldr             x0, [fp, #0x20]
    // 0x629be4: LoadField: r1 = r0->field_6b
    //     0x629be4: ldur            w1, [x0, #0x6b]
    // 0x629be8: DecompressPointer r1
    //     0x629be8: add             x1, x1, HEAP, lsl #32
    // 0x629bec: mov             x3, x1
    // 0x629bf0: stur            x3, [fp, #-0x10]
    // 0x629bf4: CheckStackOverflow
    //     0x629bf4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x629bf8: cmp             SP, x16
    //     0x629bfc: b.ls            #0x629d18
    // 0x629c00: cmp             w3, NULL
    // 0x629c04: b.eq            #0x629d00
    // 0x629c08: LoadField: r4 = r3->field_17
    //     0x629c08: ldur            w4, [x3, #0x17]
    // 0x629c0c: DecompressPointer r4
    //     0x629c0c: add             x4, x4, HEAP, lsl #32
    // 0x629c10: stur            x4, [fp, #-8]
    // 0x629c14: cmp             w4, NULL
    // 0x629c18: b.eq            #0x629d20
    // 0x629c1c: mov             x0, x4
    // 0x629c20: r2 = Null
    //     0x629c20: mov             x2, NULL
    // 0x629c24: r1 = Null
    //     0x629c24: mov             x1, NULL
    // 0x629c28: r4 = LoadClassIdInstr(r0)
    //     0x629c28: ldur            x4, [x0, #-1]
    //     0x629c2c: ubfx            x4, x4, #0xc, #0x14
    // 0x629c30: cmp             x4, #0x807
    // 0x629c34: b.eq            #0x629c4c
    // 0x629c38: r8 = StackParentData<RenderBox>
    //     0x629c38: add             x8, PP, #0x21, lsl #12  ; [pp+0x215a0] Type: StackParentData<RenderBox>
    //     0x629c3c: ldr             x8, [x8, #0x5a0]
    // 0x629c40: r3 = Null
    //     0x629c40: add             x3, PP, #0x21, lsl #12  ; [pp+0x21a30] Null
    //     0x629c44: ldr             x3, [x3, #0xa30]
    // 0x629c48: r0 = DefaultTypeTest()
    //     0x629c48: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x629c4c: ldur            x0, [fp, #-8]
    // 0x629c50: LoadField: r1 = r0->field_7
    //     0x629c50: ldur            w1, [x0, #7]
    // 0x629c54: DecompressPointer r1
    //     0x629c54: add             x1, x1, HEAP, lsl #32
    // 0x629c58: stur            x1, [fp, #-0x18]
    // 0x629c5c: ldr             x16, [fp, #0x10]
    // 0x629c60: stp             x1, x16, [SP, #-0x10]!
    // 0x629c64: r0 = -()
    //     0x629c64: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x629c68: add             SP, SP, #0x10
    // 0x629c6c: stur            x0, [fp, #-0x20]
    // 0x629c70: ldur            x16, [fp, #-0x18]
    // 0x629c74: SaveReg r16
    //     0x629c74: str             x16, [SP, #-8]!
    // 0x629c78: r0 = unary-()
    //     0x629c78: bl              #0x622a88  ; [dart:ui] Offset::unary-
    // 0x629c7c: add             SP, SP, #8
    // 0x629c80: ldr             x16, [fp, #0x18]
    // 0x629c84: stp             x0, x16, [SP, #-0x10]!
    // 0x629c88: r0 = pushOffset()
    //     0x629c88: bl              #0x622998  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::pushOffset
    // 0x629c8c: add             SP, SP, #0x10
    // 0x629c90: ldur            x0, [fp, #-0x10]
    // 0x629c94: r1 = LoadClassIdInstr(r0)
    //     0x629c94: ldur            x1, [x0, #-1]
    //     0x629c98: ubfx            x1, x1, #0xc, #0x14
    // 0x629c9c: ldr             x16, [fp, #0x18]
    // 0x629ca0: stp             x16, x0, [SP, #-0x10]!
    // 0x629ca4: ldur            x16, [fp, #-0x20]
    // 0x629ca8: SaveReg r16
    //     0x629ca8: str             x16, [SP, #-8]!
    // 0x629cac: mov             x0, x1
    // 0x629cb0: r0 = GDT[cid_x0 + 0xefa2]()
    //     0x629cb0: mov             x17, #0xefa2
    //     0x629cb4: add             lr, x0, x17
    //     0x629cb8: ldr             lr, [x21, lr, lsl #3]
    //     0x629cbc: blr             lr
    // 0x629cc0: add             SP, SP, #0x18
    // 0x629cc4: stur            x0, [fp, #-0x10]
    // 0x629cc8: ldr             x16, [fp, #0x18]
    // 0x629ccc: SaveReg r16
    //     0x629ccc: str             x16, [SP, #-8]!
    // 0x629cd0: r0 = popTransform()
    //     0x629cd0: bl              #0x6228f4  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::popTransform
    // 0x629cd4: add             SP, SP, #8
    // 0x629cd8: ldur            x1, [fp, #-0x10]
    // 0x629cdc: tbnz            w1, #4, #0x629cf0
    // 0x629ce0: r0 = true
    //     0x629ce0: add             x0, NULL, #0x20  ; true
    // 0x629ce4: LeaveFrame
    //     0x629ce4: mov             SP, fp
    //     0x629ce8: ldp             fp, lr, [SP], #0x10
    // 0x629cec: ret
    //     0x629cec: ret             
    // 0x629cf0: ldur            x1, [fp, #-8]
    // 0x629cf4: LoadField: r3 = r1->field_f
    //     0x629cf4: ldur            w3, [x1, #0xf]
    // 0x629cf8: DecompressPointer r3
    //     0x629cf8: add             x3, x3, HEAP, lsl #32
    // 0x629cfc: b               #0x629bf0
    // 0x629d00: r0 = false
    //     0x629d00: add             x0, NULL, #0x30  ; false
    // 0x629d04: LeaveFrame
    //     0x629d04: mov             SP, fp
    //     0x629d08: ldp             fp, lr, [SP], #0x10
    // 0x629d0c: ret
    //     0x629d0c: ret             
    // 0x629d10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x629d10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x629d14: b               #0x629be0
    // 0x629d18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x629d18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x629d1c: b               #0x629c00
    // 0x629d20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x629d20: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ defaultComputeDistanceToHighestActualBaseline(/* No info */) {
    // ** addr: 0x63e7f4, size: 0x23c
    // 0x63e7f4: EnterFrame
    //     0x63e7f4: stp             fp, lr, [SP, #-0x10]!
    //     0x63e7f8: mov             fp, SP
    // 0x63e7fc: AllocStack(0x20)
    //     0x63e7fc: sub             SP, SP, #0x20
    // 0x63e800: CheckStackOverflow
    //     0x63e800: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63e804: cmp             SP, x16
    //     0x63e808: b.ls            #0x63e9f0
    // 0x63e80c: ldr             x0, [fp, #0x18]
    // 0x63e810: LoadField: r1 = r0->field_67
    //     0x63e810: ldur            w1, [x0, #0x67]
    // 0x63e814: DecompressPointer r1
    //     0x63e814: add             x1, x1, HEAP, lsl #32
    // 0x63e818: mov             x3, x1
    // 0x63e81c: r4 = Null
    //     0x63e81c: mov             x4, NULL
    // 0x63e820: stur            x4, [fp, #-0x10]
    // 0x63e824: stur            x3, [fp, #-0x18]
    // 0x63e828: CheckStackOverflow
    //     0x63e828: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63e82c: cmp             SP, x16
    //     0x63e830: b.ls            #0x63e9f8
    // 0x63e834: cmp             w3, NULL
    // 0x63e838: b.eq            #0x63e9dc
    // 0x63e83c: LoadField: r5 = r3->field_17
    //     0x63e83c: ldur            w5, [x3, #0x17]
    // 0x63e840: DecompressPointer r5
    //     0x63e840: add             x5, x5, HEAP, lsl #32
    // 0x63e844: stur            x5, [fp, #-8]
    // 0x63e848: cmp             w5, NULL
    // 0x63e84c: b.eq            #0x63ea00
    // 0x63e850: mov             x0, x5
    // 0x63e854: r2 = Null
    //     0x63e854: mov             x2, NULL
    // 0x63e858: r1 = Null
    //     0x63e858: mov             x1, NULL
    // 0x63e85c: r4 = LoadClassIdInstr(r0)
    //     0x63e85c: ldur            x4, [x0, #-1]
    //     0x63e860: ubfx            x4, x4, #0xc, #0x14
    // 0x63e864: cmp             x4, #0x807
    // 0x63e868: b.eq            #0x63e880
    // 0x63e86c: r8 = StackParentData<RenderBox>
    //     0x63e86c: add             x8, PP, #0x21, lsl #12  ; [pp+0x215a0] Type: StackParentData<RenderBox>
    //     0x63e870: ldr             x8, [x8, #0x5a0]
    // 0x63e874: r3 = Null
    //     0x63e874: add             x3, PP, #0x21, lsl #12  ; [pp+0x21a70] Null
    //     0x63e878: ldr             x3, [x3, #0xa70]
    // 0x63e87c: r0 = DefaultTypeTest()
    //     0x63e87c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x63e880: ldur            x16, [fp, #-0x18]
    // 0x63e884: ldr             lr, [fp, #0x10]
    // 0x63e888: stp             lr, x16, [SP, #-0x10]!
    // 0x63e88c: r0 = getDistanceToActualBaseline()
    //     0x63e88c: bl              #0x63d634  ; [package:flutter/src/rendering/box.dart] RenderBox::getDistanceToActualBaseline
    // 0x63e890: add             SP, SP, #0x10
    // 0x63e894: cmp             w0, NULL
    // 0x63e898: b.eq            #0x63e9c4
    // 0x63e89c: ldur            x1, [fp, #-0x10]
    // 0x63e8a0: ldur            x2, [fp, #-8]
    // 0x63e8a4: LoadField: r3 = r2->field_7
    //     0x63e8a4: ldur            w3, [x2, #7]
    // 0x63e8a8: DecompressPointer r3
    //     0x63e8a8: add             x3, x3, HEAP, lsl #32
    // 0x63e8ac: LoadField: d0 = r3->field_f
    //     0x63e8ac: ldur            d0, [x3, #0xf]
    // 0x63e8b0: LoadField: d1 = r0->field_7
    //     0x63e8b0: ldur            d1, [x0, #7]
    // 0x63e8b4: fadd            d2, d1, d0
    // 0x63e8b8: stur            d2, [fp, #-0x20]
    // 0x63e8bc: cmp             w1, NULL
    // 0x63e8c0: b.eq            #0x63e990
    // 0x63e8c4: LoadField: d0 = r1->field_7
    //     0x63e8c4: ldur            d0, [x1, #7]
    // 0x63e8c8: fcmp            d0, d2
    // 0x63e8cc: b.vs            #0x63e8dc
    // 0x63e8d0: b.le            #0x63e8dc
    // 0x63e8d4: mov             v1.16b, v2.16b
    // 0x63e8d8: b               #0x63e988
    // 0x63e8dc: fcmp            d0, d2
    // 0x63e8e0: b.vs            #0x63e8f4
    // 0x63e8e4: b.ge            #0x63e8f4
    // 0x63e8e8: LoadField: d0 = r1->field_7
    //     0x63e8e8: ldur            d0, [x1, #7]
    // 0x63e8ec: mov             v1.16b, v0.16b
    // 0x63e8f0: b               #0x63e988
    // 0x63e8f4: d1 = 0.000000
    //     0x63e8f4: eor             v1.16b, v1.16b, v1.16b
    // 0x63e8f8: fcmp            d0, d1
    // 0x63e8fc: b.vs            #0x63e904
    // 0x63e900: b.eq            #0x63e90c
    // 0x63e904: r0 = false
    //     0x63e904: add             x0, NULL, #0x30  ; false
    // 0x63e908: b               #0x63e910
    // 0x63e90c: r0 = true
    //     0x63e90c: add             x0, NULL, #0x20  ; true
    // 0x63e910: tbnz            w0, #4, #0x63e928
    // 0x63e914: fadd            d3, d0, d2
    // 0x63e918: fmul            d4, d3, d0
    // 0x63e91c: fmul            d0, d4, d2
    // 0x63e920: mov             v1.16b, v0.16b
    // 0x63e924: b               #0x63e988
    // 0x63e928: tbnz            w0, #4, #0x63e96c
    // 0x63e92c: r0 = inline_Allocate_Double()
    //     0x63e92c: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x63e930: add             x0, x0, #0x10
    //     0x63e934: cmp             x3, x0
    //     0x63e938: b.ls            #0x63ea04
    //     0x63e93c: str             x0, [THR, #0x60]  ; THR::top
    //     0x63e940: sub             x0, x0, #0xf
    //     0x63e944: mov             x3, #0xd108
    //     0x63e948: movk            x3, #3, lsl #16
    //     0x63e94c: stur            x3, [x0, #-1]
    // 0x63e950: StoreField: r0->field_7 = d2
    //     0x63e950: stur            d2, [x0, #7]
    // 0x63e954: SaveReg r0
    //     0x63e954: str             x0, [SP, #-8]!
    // 0x63e958: r0 = isNegative()
    //     0x63e958: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x63e95c: add             SP, SP, #8
    // 0x63e960: tbnz            w0, #4, #0x63e96c
    // 0x63e964: ldur            d0, [fp, #-0x20]
    // 0x63e968: b               #0x63e978
    // 0x63e96c: ldur            d0, [fp, #-0x20]
    // 0x63e970: fcmp            d0, d0
    // 0x63e974: b.vc            #0x63e980
    // 0x63e978: mov             v1.16b, v0.16b
    // 0x63e97c: b               #0x63e988
    // 0x63e980: ldur            x1, [fp, #-0x10]
    // 0x63e984: LoadField: d1 = r1->field_7
    //     0x63e984: ldur            d1, [x1, #7]
    // 0x63e988: mov             v0.16b, v1.16b
    // 0x63e98c: b               #0x63e994
    // 0x63e990: mov             v0.16b, v2.16b
    // 0x63e994: r2 = inline_Allocate_Double()
    //     0x63e994: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x63e998: add             x2, x2, #0x10
    //     0x63e99c: cmp             x3, x2
    //     0x63e9a0: b.ls            #0x63ea1c
    //     0x63e9a4: str             x2, [THR, #0x60]  ; THR::top
    //     0x63e9a8: sub             x2, x2, #0xf
    //     0x63e9ac: mov             x3, #0xd108
    //     0x63e9b0: movk            x3, #3, lsl #16
    //     0x63e9b4: stur            x3, [x2, #-1]
    // 0x63e9b8: StoreField: r2->field_7 = d0
    //     0x63e9b8: stur            d0, [x2, #7]
    // 0x63e9bc: mov             x4, x2
    // 0x63e9c0: b               #0x63e9cc
    // 0x63e9c4: ldur            x1, [fp, #-0x10]
    // 0x63e9c8: mov             x4, x1
    // 0x63e9cc: ldur            x2, [fp, #-8]
    // 0x63e9d0: LoadField: r3 = r2->field_13
    //     0x63e9d0: ldur            w3, [x2, #0x13]
    // 0x63e9d4: DecompressPointer r3
    //     0x63e9d4: add             x3, x3, HEAP, lsl #32
    // 0x63e9d8: b               #0x63e820
    // 0x63e9dc: mov             x1, x4
    // 0x63e9e0: mov             x0, x1
    // 0x63e9e4: LeaveFrame
    //     0x63e9e4: mov             SP, fp
    //     0x63e9e8: ldp             fp, lr, [SP], #0x10
    // 0x63e9ec: ret
    //     0x63e9ec: ret             
    // 0x63e9f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63e9f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63e9f4: b               #0x63e80c
    // 0x63e9f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63e9f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63e9fc: b               #0x63e834
    // 0x63ea00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63ea00: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x63ea04: stp             q1, q2, [SP, #-0x20]!
    // 0x63ea08: stp             x1, x2, [SP, #-0x10]!
    // 0x63ea0c: r0 = AllocateDouble()
    //     0x63ea0c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63ea10: ldp             x1, x2, [SP], #0x10
    // 0x63ea14: ldp             q1, q2, [SP], #0x20
    // 0x63ea18: b               #0x63e950
    // 0x63ea1c: SaveReg d0
    //     0x63ea1c: str             q0, [SP, #-0x10]!
    // 0x63ea20: r0 = AllocateDouble()
    //     0x63ea20: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63ea24: mov             x2, x0
    // 0x63ea28: RestoreReg d0
    //     0x63ea28: ldr             q0, [SP], #0x10
    // 0x63ea2c: b               #0x63e9b8
  }
  _ defaultPaint(/* No info */) {
    // ** addr: 0x66f340, size: 0x12c
    // 0x66f340: EnterFrame
    //     0x66f340: stp             fp, lr, [SP, #-0x10]!
    //     0x66f344: mov             fp, SP
    // 0x66f348: AllocStack(0x30)
    //     0x66f348: sub             SP, SP, #0x30
    // 0x66f34c: CheckStackOverflow
    //     0x66f34c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66f350: cmp             SP, x16
    //     0x66f354: b.ls            #0x66f458
    // 0x66f358: ldr             x0, [fp, #0x20]
    // 0x66f35c: LoadField: r1 = r0->field_67
    //     0x66f35c: ldur            w1, [x0, #0x67]
    // 0x66f360: DecompressPointer r1
    //     0x66f360: add             x1, x1, HEAP, lsl #32
    // 0x66f364: ldr             x0, [fp, #0x10]
    // 0x66f368: LoadField: d0 = r0->field_7
    //     0x66f368: ldur            d0, [x0, #7]
    // 0x66f36c: stur            d0, [fp, #-0x20]
    // 0x66f370: LoadField: d1 = r0->field_f
    //     0x66f370: ldur            d1, [x0, #0xf]
    // 0x66f374: stur            d1, [fp, #-0x18]
    // 0x66f378: mov             x3, x1
    // 0x66f37c: stur            x3, [fp, #-0x10]
    // 0x66f380: CheckStackOverflow
    //     0x66f380: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66f384: cmp             SP, x16
    //     0x66f388: b.ls            #0x66f460
    // 0x66f38c: cmp             w3, NULL
    // 0x66f390: b.eq            #0x66f448
    // 0x66f394: LoadField: r4 = r3->field_17
    //     0x66f394: ldur            w4, [x3, #0x17]
    // 0x66f398: DecompressPointer r4
    //     0x66f398: add             x4, x4, HEAP, lsl #32
    // 0x66f39c: stur            x4, [fp, #-8]
    // 0x66f3a0: cmp             w4, NULL
    // 0x66f3a4: b.eq            #0x66f468
    // 0x66f3a8: mov             x0, x4
    // 0x66f3ac: r2 = Null
    //     0x66f3ac: mov             x2, NULL
    // 0x66f3b0: r1 = Null
    //     0x66f3b0: mov             x1, NULL
    // 0x66f3b4: r4 = LoadClassIdInstr(r0)
    //     0x66f3b4: ldur            x4, [x0, #-1]
    //     0x66f3b8: ubfx            x4, x4, #0xc, #0x14
    // 0x66f3bc: cmp             x4, #0x807
    // 0x66f3c0: b.eq            #0x66f3d8
    // 0x66f3c4: r8 = StackParentData<RenderBox>
    //     0x66f3c4: add             x8, PP, #0x21, lsl #12  ; [pp+0x215a0] Type: StackParentData<RenderBox>
    //     0x66f3c8: ldr             x8, [x8, #0x5a0]
    // 0x66f3cc: r3 = Null
    //     0x66f3cc: add             x3, PP, #0x21, lsl #12  ; [pp+0x21a20] Null
    //     0x66f3d0: ldr             x3, [x3, #0xa20]
    // 0x66f3d4: r0 = DefaultTypeTest()
    //     0x66f3d4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x66f3d8: ldur            x0, [fp, #-8]
    // 0x66f3dc: LoadField: r1 = r0->field_7
    //     0x66f3dc: ldur            w1, [x0, #7]
    // 0x66f3e0: DecompressPointer r1
    //     0x66f3e0: add             x1, x1, HEAP, lsl #32
    // 0x66f3e4: LoadField: d0 = r1->field_7
    //     0x66f3e4: ldur            d0, [x1, #7]
    // 0x66f3e8: ldur            d1, [fp, #-0x20]
    // 0x66f3ec: fadd            d2, d0, d1
    // 0x66f3f0: stur            d2, [fp, #-0x30]
    // 0x66f3f4: LoadField: d0 = r1->field_f
    //     0x66f3f4: ldur            d0, [x1, #0xf]
    // 0x66f3f8: ldur            d3, [fp, #-0x18]
    // 0x66f3fc: fadd            d4, d0, d3
    // 0x66f400: stur            d4, [fp, #-0x28]
    // 0x66f404: r0 = Offset()
    //     0x66f404: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x66f408: ldur            d0, [fp, #-0x30]
    // 0x66f40c: StoreField: r0->field_7 = d0
    //     0x66f40c: stur            d0, [x0, #7]
    // 0x66f410: ldur            d0, [fp, #-0x28]
    // 0x66f414: StoreField: r0->field_f = d0
    //     0x66f414: stur            d0, [x0, #0xf]
    // 0x66f418: ldr             x16, [fp, #0x18]
    // 0x66f41c: ldur            lr, [fp, #-0x10]
    // 0x66f420: stp             lr, x16, [SP, #-0x10]!
    // 0x66f424: SaveReg r0
    //     0x66f424: str             x0, [SP, #-8]!
    // 0x66f428: r0 = paintChild()
    //     0x66f428: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x66f42c: add             SP, SP, #0x18
    // 0x66f430: ldur            x1, [fp, #-8]
    // 0x66f434: LoadField: r3 = r1->field_13
    //     0x66f434: ldur            w3, [x1, #0x13]
    // 0x66f438: DecompressPointer r3
    //     0x66f438: add             x3, x3, HEAP, lsl #32
    // 0x66f43c: ldur            d0, [fp, #-0x20]
    // 0x66f440: ldur            d1, [fp, #-0x18]
    // 0x66f444: b               #0x66f37c
    // 0x66f448: r0 = Null
    //     0x66f448: mov             x0, NULL
    // 0x66f44c: LeaveFrame
    //     0x66f44c: mov             SP, fp
    //     0x66f450: ldp             fp, lr, [SP], #0x10
    // 0x66f454: ret
    //     0x66f454: ret             
    // 0x66f458: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66f458: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66f45c: b               #0x66f358
    // 0x66f460: r0 = StackOverflowSharedWithFPURegs()
    //     0x66f460: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x66f464: b               #0x66f38c
    // 0x66f468: r0 = NullCastErrorSharedWithFPURegs()
    //     0x66f468: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
}

// class id: 2427, size: 0x8c, field offset: 0x70
class RenderStack extends _RenderStack&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin {

  _ hitTestChildren(/* No info */) {
    // ** addr: 0x629b84, size: 0x44
    // 0x629b84: EnterFrame
    //     0x629b84: stp             fp, lr, [SP, #-0x10]!
    //     0x629b88: mov             fp, SP
    // 0x629b8c: CheckStackOverflow
    //     0x629b8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x629b90: cmp             SP, x16
    //     0x629b94: b.ls            #0x629bc0
    // 0x629b98: ldr             x16, [fp, #0x20]
    // 0x629b9c: ldr             lr, [fp, #0x18]
    // 0x629ba0: stp             lr, x16, [SP, #-0x10]!
    // 0x629ba4: ldr             x16, [fp, #0x10]
    // 0x629ba8: SaveReg r16
    //     0x629ba8: str             x16, [SP, #-8]!
    // 0x629bac: r0 = defaultHitTestChildren()
    //     0x629bac: bl              #0x629bc8  ; [package:flutter/src/rendering/stack.dart] _RenderStack&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultHitTestChildren
    // 0x629bb0: add             SP, SP, #0x18
    // 0x629bb4: LeaveFrame
    //     0x629bb4: mov             SP, fp
    //     0x629bb8: ldp             fp, lr, [SP], #0x10
    // 0x629bbc: ret
    //     0x629bbc: ret             
    // 0x629bc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x629bc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x629bc4: b               #0x629b98
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x632248, size: 0x18
    // 0x632248: r4 = 0
    //     0x632248: mov             x4, #0
    // 0x63224c: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x63224c: add             x17, PP, #0x4a, lsl #12  ; [pp+0x4ac60] AnonymousClosure: (0x632260), in [package:flutter/src/rendering/stack.dart] RenderStack::computeMaxIntrinsicHeight (0x6322ac)
    //     0x632250: ldr             x1, [x17, #0xc60]
    // 0x632254: r24 = BuildNonGenericMethodExtractorStub
    //     0x632254: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x632258: LoadField: r0 = r24->field_17
    //     0x632258: ldur            x0, [x24, #0x17]
    // 0x63225c: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x632260, size: 0x4c
    // 0x632260: EnterFrame
    //     0x632260: stp             fp, lr, [SP, #-0x10]!
    //     0x632264: mov             fp, SP
    // 0x632268: ldr             x0, [fp, #0x18]
    // 0x63226c: LoadField: r1 = r0->field_17
    //     0x63226c: ldur            w1, [x0, #0x17]
    // 0x632270: DecompressPointer r1
    //     0x632270: add             x1, x1, HEAP, lsl #32
    // 0x632274: CheckStackOverflow
    //     0x632274: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x632278: cmp             SP, x16
    //     0x63227c: b.ls            #0x6322a4
    // 0x632280: LoadField: r0 = r1->field_f
    //     0x632280: ldur            w0, [x1, #0xf]
    // 0x632284: DecompressPointer r0
    //     0x632284: add             x0, x0, HEAP, lsl #32
    // 0x632288: ldr             x16, [fp, #0x10]
    // 0x63228c: stp             x16, x0, [SP, #-0x10]!
    // 0x632290: r0 = computeMaxIntrinsicHeight()
    //     0x632290: bl              #0x6322ac  ; [package:flutter/src/rendering/stack.dart] RenderStack::computeMaxIntrinsicHeight
    // 0x632294: add             SP, SP, #0x10
    // 0x632298: LeaveFrame
    //     0x632298: mov             SP, fp
    //     0x63229c: ldp             fp, lr, [SP], #0x10
    // 0x6322a0: ret
    //     0x6322a0: ret             
    // 0x6322a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6322a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6322a8: b               #0x632280
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0x6322ac, size: 0xa8
    // 0x6322ac: EnterFrame
    //     0x6322ac: stp             fp, lr, [SP, #-0x10]!
    //     0x6322b0: mov             fp, SP
    // 0x6322b4: AllocStack(0x8)
    //     0x6322b4: sub             SP, SP, #8
    // 0x6322b8: CheckStackOverflow
    //     0x6322b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6322bc: cmp             SP, x16
    //     0x6322c0: b.ls            #0x63233c
    // 0x6322c4: r1 = 1
    //     0x6322c4: mov             x1, #1
    // 0x6322c8: r0 = AllocateContext()
    //     0x6322c8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6322cc: mov             x1, x0
    // 0x6322d0: ldr             x0, [fp, #0x10]
    // 0x6322d4: StoreField: r1->field_f = r0
    //     0x6322d4: stur            w0, [x1, #0xf]
    // 0x6322d8: ldr             x0, [fp, #0x18]
    // 0x6322dc: LoadField: r3 = r0->field_67
    //     0x6322dc: ldur            w3, [x0, #0x67]
    // 0x6322e0: DecompressPointer r3
    //     0x6322e0: add             x3, x3, HEAP, lsl #32
    // 0x6322e4: mov             x2, x1
    // 0x6322e8: stur            x3, [fp, #-8]
    // 0x6322ec: r1 = Function '<anonymous closure>':.
    //     0x6322ec: add             x1, PP, #0x4a, lsl #12  ; [pp+0x4ac68] AnonymousClosure: (0x6325c8), in [package:flutter/src/widgets/overlay.dart] _RenderTheatre::computeMaxIntrinsicHeight (0x632654)
    //     0x6322f0: ldr             x1, [x1, #0xc68]
    // 0x6322f4: r0 = AllocateClosure()
    //     0x6322f4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6322f8: ldur            x16, [fp, #-8]
    // 0x6322fc: stp             x0, x16, [SP, #-0x10]!
    // 0x632300: r0 = getIntrinsicDimension()
    //     0x632300: bl              #0x632354  ; [package:flutter/src/rendering/stack.dart] RenderStack::getIntrinsicDimension
    // 0x632304: add             SP, SP, #0x10
    // 0x632308: r0 = inline_Allocate_Double()
    //     0x632308: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63230c: add             x0, x0, #0x10
    //     0x632310: cmp             x1, x0
    //     0x632314: b.ls            #0x632344
    //     0x632318: str             x0, [THR, #0x60]  ; THR::top
    //     0x63231c: sub             x0, x0, #0xf
    //     0x632320: mov             x1, #0xd108
    //     0x632324: movk            x1, #3, lsl #16
    //     0x632328: stur            x1, [x0, #-1]
    // 0x63232c: StoreField: r0->field_7 = d0
    //     0x63232c: stur            d0, [x0, #7]
    // 0x632330: LeaveFrame
    //     0x632330: mov             SP, fp
    //     0x632334: ldp             fp, lr, [SP], #0x10
    // 0x632338: ret
    //     0x632338: ret             
    // 0x63233c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63233c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x632340: b               #0x6322c4
    // 0x632344: SaveReg d0
    //     0x632344: str             q0, [SP, #-0x10]!
    // 0x632348: r0 = AllocateDouble()
    //     0x632348: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63234c: RestoreReg d0
    //     0x63234c: ldr             q0, [SP], #0x10
    // 0x632350: b               #0x63232c
  }
  static _ getIntrinsicDimension(/* No info */) {
    // ** addr: 0x632354, size: 0x274
    // 0x632354: EnterFrame
    //     0x632354: stp             fp, lr, [SP, #-0x10]!
    //     0x632358: mov             fp, SP
    // 0x63235c: AllocStack(0x18)
    //     0x63235c: sub             SP, SP, #0x18
    // 0x632360: CheckStackOverflow
    //     0x632360: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x632364: cmp             SP, x16
    //     0x632368: b.ls            #0x6325a4
    // 0x63236c: ldr             x0, [fp, #0x18]
    // 0x632370: mov             x3, x0
    // 0x632374: r4 = 0.000000
    //     0x632374: ldr             x4, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x632378: stur            x4, [fp, #-0x10]
    // 0x63237c: stur            x3, [fp, #-0x18]
    // 0x632380: CheckStackOverflow
    //     0x632380: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x632384: cmp             SP, x16
    //     0x632388: b.ls            #0x6325ac
    // 0x63238c: cmp             w3, NULL
    // 0x632390: b.eq            #0x632590
    // 0x632394: LoadField: r5 = r3->field_17
    //     0x632394: ldur            w5, [x3, #0x17]
    // 0x632398: DecompressPointer r5
    //     0x632398: add             x5, x5, HEAP, lsl #32
    // 0x63239c: stur            x5, [fp, #-8]
    // 0x6323a0: cmp             w5, NULL
    // 0x6323a4: b.eq            #0x6325b4
    // 0x6323a8: mov             x0, x5
    // 0x6323ac: r2 = Null
    //     0x6323ac: mov             x2, NULL
    // 0x6323b0: r1 = Null
    //     0x6323b0: mov             x1, NULL
    // 0x6323b4: r4 = LoadClassIdInstr(r0)
    //     0x6323b4: ldur            x4, [x0, #-1]
    //     0x6323b8: ubfx            x4, x4, #0xc, #0x14
    // 0x6323bc: cmp             x4, #0x807
    // 0x6323c0: b.eq            #0x6323d8
    // 0x6323c4: r8 = StackParentData<RenderBox>
    //     0x6323c4: add             x8, PP, #0x21, lsl #12  ; [pp+0x215a0] Type: StackParentData<RenderBox>
    //     0x6323c8: ldr             x8, [x8, #0x5a0]
    // 0x6323cc: r3 = Null
    //     0x6323cc: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f580] Null
    //     0x6323d0: ldr             x3, [x3, #0x580]
    // 0x6323d4: r0 = DefaultTypeTest()
    //     0x6323d4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6323d8: ldur            x1, [fp, #-8]
    // 0x6323dc: LoadField: r0 = r1->field_17
    //     0x6323dc: ldur            w0, [x1, #0x17]
    // 0x6323e0: DecompressPointer r0
    //     0x6323e0: add             x0, x0, HEAP, lsl #32
    // 0x6323e4: cmp             w0, NULL
    // 0x6323e8: b.ne            #0x63257c
    // 0x6323ec: LoadField: r0 = r1->field_1b
    //     0x6323ec: ldur            w0, [x1, #0x1b]
    // 0x6323f0: DecompressPointer r0
    //     0x6323f0: add             x0, x0, HEAP, lsl #32
    // 0x6323f4: cmp             w0, NULL
    // 0x6323f8: b.ne            #0x63257c
    // 0x6323fc: LoadField: r0 = r1->field_1f
    //     0x6323fc: ldur            w0, [x1, #0x1f]
    // 0x632400: DecompressPointer r0
    //     0x632400: add             x0, x0, HEAP, lsl #32
    // 0x632404: cmp             w0, NULL
    // 0x632408: b.ne            #0x63257c
    // 0x63240c: LoadField: r0 = r1->field_23
    //     0x63240c: ldur            w0, [x1, #0x23]
    // 0x632410: DecompressPointer r0
    //     0x632410: add             x0, x0, HEAP, lsl #32
    // 0x632414: cmp             w0, NULL
    // 0x632418: b.ne            #0x63257c
    // 0x63241c: LoadField: r0 = r1->field_27
    //     0x63241c: ldur            w0, [x1, #0x27]
    // 0x632420: DecompressPointer r0
    //     0x632420: add             x0, x0, HEAP, lsl #32
    // 0x632424: cmp             w0, NULL
    // 0x632428: b.ne            #0x63257c
    // 0x63242c: LoadField: r0 = r1->field_2b
    //     0x63242c: ldur            w0, [x1, #0x2b]
    // 0x632430: DecompressPointer r0
    //     0x632430: add             x0, x0, HEAP, lsl #32
    // 0x632434: cmp             w0, NULL
    // 0x632438: b.ne            #0x63257c
    // 0x63243c: ldr             x16, [fp, #0x10]
    // 0x632440: ldur            lr, [fp, #-0x18]
    // 0x632444: stp             lr, x16, [SP, #-0x10]!
    // 0x632448: ldr             x0, [fp, #0x10]
    // 0x63244c: ClosureCall
    //     0x63244c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x632450: ldur            x2, [x0, #0x1f]
    //     0x632454: blr             x2
    // 0x632458: add             SP, SP, #0x10
    // 0x63245c: stur            x0, [fp, #-0x18]
    // 0x632460: ldur            x16, [fp, #-0x10]
    // 0x632464: stp             x0, x16, [SP, #-0x10]!
    // 0x632468: r0 = >()
    //     0x632468: bl              #0xd6719c  ; [dart:core] _Double::>
    // 0x63246c: add             SP, SP, #0x10
    // 0x632470: tbnz            w0, #4, #0x63247c
    // 0x632474: ldur            x0, [fp, #-0x10]
    // 0x632478: b               #0x632574
    // 0x63247c: ldur            x16, [fp, #-0x10]
    // 0x632480: ldur            lr, [fp, #-0x18]
    // 0x632484: stp             lr, x16, [SP, #-0x10]!
    // 0x632488: r0 = <()
    //     0x632488: bl              #0xd64ef8  ; [dart:core] _Double::<
    // 0x63248c: add             SP, SP, #0x10
    // 0x632490: tbnz            w0, #4, #0x63249c
    // 0x632494: ldur            x0, [fp, #-0x18]
    // 0x632498: b               #0x632574
    // 0x63249c: ldur            x1, [fp, #-0x18]
    // 0x6324a0: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0x6324a0: mov             x0, #0x76
    //     0x6324a4: tbz             w1, #0, #0x6324b4
    //     0x6324a8: ldur            x0, [x1, #-1]
    //     0x6324ac: ubfx            x0, x0, #0xc, #0x14
    //     0x6324b0: lsl             x0, x0, #1
    // 0x6324b4: cmp             w0, #0x7a
    // 0x6324b8: b.ne            #0x632524
    // 0x6324bc: ldur            x2, [fp, #-0x10]
    // 0x6324c0: d0 = 0.000000
    //     0x6324c0: eor             v0.16b, v0.16b, v0.16b
    // 0x6324c4: LoadField: d1 = r2->field_7
    //     0x6324c4: ldur            d1, [x2, #7]
    // 0x6324c8: fcmp            d1, d0
    // 0x6324cc: b.vs            #0x632508
    // 0x6324d0: b.ne            #0x632508
    // 0x6324d4: LoadField: d2 = r1->field_7
    //     0x6324d4: ldur            d2, [x1, #7]
    // 0x6324d8: fadd            d3, d1, d2
    // 0x6324dc: r0 = inline_Allocate_Double()
    //     0x6324dc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6324e0: add             x0, x0, #0x10
    //     0x6324e4: cmp             x1, x0
    //     0x6324e8: b.ls            #0x6325b8
    //     0x6324ec: str             x0, [THR, #0x60]  ; THR::top
    //     0x6324f0: sub             x0, x0, #0xf
    //     0x6324f4: mov             x1, #0xd108
    //     0x6324f8: movk            x1, #3, lsl #16
    //     0x6324fc: stur            x1, [x0, #-1]
    // 0x632500: StoreField: r0->field_7 = d3
    //     0x632500: stur            d3, [x0, #7]
    // 0x632504: b               #0x632574
    // 0x632508: LoadField: d1 = r1->field_7
    //     0x632508: ldur            d1, [x1, #7]
    // 0x63250c: fcmp            d1, d1
    // 0x632510: b.vc            #0x63251c
    // 0x632514: mov             x0, x1
    // 0x632518: b               #0x632574
    // 0x63251c: mov             x0, x2
    // 0x632520: b               #0x632574
    // 0x632524: ldur            x2, [fp, #-0x10]
    // 0x632528: d0 = 0.000000
    //     0x632528: eor             v0.16b, v0.16b, v0.16b
    // 0x63252c: r0 = 59
    //     0x63252c: mov             x0, #0x3b
    // 0x632530: branchIfSmi(r1, 0x63253c)
    //     0x632530: tbz             w1, #0, #0x63253c
    // 0x632534: r0 = LoadClassIdInstr(r1)
    //     0x632534: ldur            x0, [x1, #-1]
    //     0x632538: ubfx            x0, x0, #0xc, #0x14
    // 0x63253c: stp             xzr, x1, [SP, #-0x10]!
    // 0x632540: mov             lr, x0
    // 0x632544: ldr             lr, [x21, lr, lsl #3]
    // 0x632548: blr             lr
    // 0x63254c: add             SP, SP, #0x10
    // 0x632550: tbnz            w0, #4, #0x632570
    // 0x632554: ldur            x16, [fp, #-0x10]
    // 0x632558: SaveReg r16
    //     0x632558: str             x16, [SP, #-8]!
    // 0x63255c: r0 = isNegative()
    //     0x63255c: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x632560: add             SP, SP, #8
    // 0x632564: tbnz            w0, #4, #0x632570
    // 0x632568: ldur            x0, [fp, #-0x18]
    // 0x63256c: b               #0x632574
    // 0x632570: ldur            x0, [fp, #-0x10]
    // 0x632574: mov             x4, x0
    // 0x632578: b               #0x632580
    // 0x63257c: ldur            x4, [fp, #-0x10]
    // 0x632580: ldur            x0, [fp, #-8]
    // 0x632584: LoadField: r3 = r0->field_13
    //     0x632584: ldur            w3, [x0, #0x13]
    // 0x632588: DecompressPointer r3
    //     0x632588: add             x3, x3, HEAP, lsl #32
    // 0x63258c: b               #0x632378
    // 0x632590: mov             x0, x4
    // 0x632594: LoadField: d0 = r0->field_7
    //     0x632594: ldur            d0, [x0, #7]
    // 0x632598: LeaveFrame
    //     0x632598: mov             SP, fp
    //     0x63259c: ldp             fp, lr, [SP], #0x10
    // 0x6325a0: ret
    //     0x6325a0: ret             
    // 0x6325a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6325a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6325a8: b               #0x63236c
    // 0x6325ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6325ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6325b0: b               #0x63238c
    // 0x6325b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6325b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6325b8: stp             q0, q3, [SP, #-0x20]!
    // 0x6325bc: r0 = AllocateDouble()
    //     0x6325bc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6325c0: ldp             q0, q3, [SP], #0x20
    // 0x6325c4: b               #0x632500
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x636edc, size: 0x18
    // 0x636edc: r4 = 0
    //     0x636edc: mov             x4, #0
    // 0x636ee0: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x636ee0: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fb90] AnonymousClosure: (0x636ef4), in [package:flutter/src/rendering/stack.dart] RenderStack::computeMaxIntrinsicWidth (0x636f40)
    //     0x636ee4: ldr             x1, [x17, #0xb90]
    // 0x636ee8: r24 = BuildNonGenericMethodExtractorStub
    //     0x636ee8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x636eec: LoadField: r0 = r24->field_17
    //     0x636eec: ldur            x0, [x24, #0x17]
    // 0x636ef0: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x636ef4, size: 0x4c
    // 0x636ef4: EnterFrame
    //     0x636ef4: stp             fp, lr, [SP, #-0x10]!
    //     0x636ef8: mov             fp, SP
    // 0x636efc: ldr             x0, [fp, #0x18]
    // 0x636f00: LoadField: r1 = r0->field_17
    //     0x636f00: ldur            w1, [x0, #0x17]
    // 0x636f04: DecompressPointer r1
    //     0x636f04: add             x1, x1, HEAP, lsl #32
    // 0x636f08: CheckStackOverflow
    //     0x636f08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x636f0c: cmp             SP, x16
    //     0x636f10: b.ls            #0x636f38
    // 0x636f14: LoadField: r0 = r1->field_f
    //     0x636f14: ldur            w0, [x1, #0xf]
    // 0x636f18: DecompressPointer r0
    //     0x636f18: add             x0, x0, HEAP, lsl #32
    // 0x636f1c: ldr             x16, [fp, #0x10]
    // 0x636f20: stp             x16, x0, [SP, #-0x10]!
    // 0x636f24: r0 = computeMaxIntrinsicWidth()
    //     0x636f24: bl              #0x636f40  ; [package:flutter/src/rendering/stack.dart] RenderStack::computeMaxIntrinsicWidth
    // 0x636f28: add             SP, SP, #0x10
    // 0x636f2c: LeaveFrame
    //     0x636f2c: mov             SP, fp
    //     0x636f30: ldp             fp, lr, [SP], #0x10
    // 0x636f34: ret
    //     0x636f34: ret             
    // 0x636f38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x636f38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x636f3c: b               #0x636f14
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0x636f40, size: 0xa8
    // 0x636f40: EnterFrame
    //     0x636f40: stp             fp, lr, [SP, #-0x10]!
    //     0x636f44: mov             fp, SP
    // 0x636f48: AllocStack(0x8)
    //     0x636f48: sub             SP, SP, #8
    // 0x636f4c: CheckStackOverflow
    //     0x636f4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x636f50: cmp             SP, x16
    //     0x636f54: b.ls            #0x636fd0
    // 0x636f58: r1 = 1
    //     0x636f58: mov             x1, #1
    // 0x636f5c: r0 = AllocateContext()
    //     0x636f5c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x636f60: mov             x1, x0
    // 0x636f64: ldr             x0, [fp, #0x10]
    // 0x636f68: StoreField: r1->field_f = r0
    //     0x636f68: stur            w0, [x1, #0xf]
    // 0x636f6c: ldr             x0, [fp, #0x18]
    // 0x636f70: LoadField: r3 = r0->field_67
    //     0x636f70: ldur            w3, [x0, #0x67]
    // 0x636f74: DecompressPointer r3
    //     0x636f74: add             x3, x3, HEAP, lsl #32
    // 0x636f78: mov             x2, x1
    // 0x636f7c: stur            x3, [fp, #-8]
    // 0x636f80: r1 = Function '<anonymous closure>':.
    //     0x636f80: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fb98] AnonymousClosure: (0x636fe8), in [package:flutter/src/widgets/overlay.dart] _RenderTheatre::computeMaxIntrinsicWidth (0x637074)
    //     0x636f84: ldr             x1, [x1, #0xb98]
    // 0x636f88: r0 = AllocateClosure()
    //     0x636f88: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x636f8c: ldur            x16, [fp, #-8]
    // 0x636f90: stp             x0, x16, [SP, #-0x10]!
    // 0x636f94: r0 = getIntrinsicDimension()
    //     0x636f94: bl              #0x632354  ; [package:flutter/src/rendering/stack.dart] RenderStack::getIntrinsicDimension
    // 0x636f98: add             SP, SP, #0x10
    // 0x636f9c: r0 = inline_Allocate_Double()
    //     0x636f9c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x636fa0: add             x0, x0, #0x10
    //     0x636fa4: cmp             x1, x0
    //     0x636fa8: b.ls            #0x636fd8
    //     0x636fac: str             x0, [THR, #0x60]  ; THR::top
    //     0x636fb0: sub             x0, x0, #0xf
    //     0x636fb4: mov             x1, #0xd108
    //     0x636fb8: movk            x1, #3, lsl #16
    //     0x636fbc: stur            x1, [x0, #-1]
    // 0x636fc0: StoreField: r0->field_7 = d0
    //     0x636fc0: stur            d0, [x0, #7]
    // 0x636fc4: LeaveFrame
    //     0x636fc4: mov             SP, fp
    //     0x636fc8: ldp             fp, lr, [SP], #0x10
    // 0x636fcc: ret
    //     0x636fcc: ret             
    // 0x636fd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x636fd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x636fd4: b               #0x636f58
    // 0x636fd8: SaveReg d0
    //     0x636fd8: str             q0, [SP, #-0x10]!
    // 0x636fdc: r0 = AllocateDouble()
    //     0x636fdc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x636fe0: RestoreReg d0
    //     0x636fe0: ldr             q0, [SP], #0x10
    // 0x636fe4: b               #0x636fc0
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x63975c, size: 0x18
    // 0x63975c: r4 = 0
    //     0x63975c: mov             x4, #0
    // 0x639760: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x639760: add             x17, PP, #0x52, lsl #12  ; [pp+0x52e38] AnonymousClosure: (0x639774), in [package:flutter/src/rendering/stack.dart] RenderStack::computeMinIntrinsicHeight (0x6397c0)
    //     0x639764: ldr             x1, [x17, #0xe38]
    // 0x639768: r24 = BuildNonGenericMethodExtractorStub
    //     0x639768: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63976c: LoadField: r0 = r24->field_17
    //     0x63976c: ldur            x0, [x24, #0x17]
    // 0x639770: br              x0
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x639774, size: 0x4c
    // 0x639774: EnterFrame
    //     0x639774: stp             fp, lr, [SP, #-0x10]!
    //     0x639778: mov             fp, SP
    // 0x63977c: ldr             x0, [fp, #0x18]
    // 0x639780: LoadField: r1 = r0->field_17
    //     0x639780: ldur            w1, [x0, #0x17]
    // 0x639784: DecompressPointer r1
    //     0x639784: add             x1, x1, HEAP, lsl #32
    // 0x639788: CheckStackOverflow
    //     0x639788: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63978c: cmp             SP, x16
    //     0x639790: b.ls            #0x6397b8
    // 0x639794: LoadField: r0 = r1->field_f
    //     0x639794: ldur            w0, [x1, #0xf]
    // 0x639798: DecompressPointer r0
    //     0x639798: add             x0, x0, HEAP, lsl #32
    // 0x63979c: ldr             x16, [fp, #0x10]
    // 0x6397a0: stp             x16, x0, [SP, #-0x10]!
    // 0x6397a4: r0 = computeMinIntrinsicHeight()
    //     0x6397a4: bl              #0x6397c0  ; [package:flutter/src/rendering/stack.dart] RenderStack::computeMinIntrinsicHeight
    // 0x6397a8: add             SP, SP, #0x10
    // 0x6397ac: LeaveFrame
    //     0x6397ac: mov             SP, fp
    //     0x6397b0: ldp             fp, lr, [SP], #0x10
    // 0x6397b4: ret
    //     0x6397b4: ret             
    // 0x6397b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6397b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6397bc: b               #0x639794
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0x6397c0, size: 0xa8
    // 0x6397c0: EnterFrame
    //     0x6397c0: stp             fp, lr, [SP, #-0x10]!
    //     0x6397c4: mov             fp, SP
    // 0x6397c8: AllocStack(0x8)
    //     0x6397c8: sub             SP, SP, #8
    // 0x6397cc: CheckStackOverflow
    //     0x6397cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6397d0: cmp             SP, x16
    //     0x6397d4: b.ls            #0x639850
    // 0x6397d8: r1 = 1
    //     0x6397d8: mov             x1, #1
    // 0x6397dc: r0 = AllocateContext()
    //     0x6397dc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6397e0: mov             x1, x0
    // 0x6397e4: ldr             x0, [fp, #0x10]
    // 0x6397e8: StoreField: r1->field_f = r0
    //     0x6397e8: stur            w0, [x1, #0xf]
    // 0x6397ec: ldr             x0, [fp, #0x18]
    // 0x6397f0: LoadField: r3 = r0->field_67
    //     0x6397f0: ldur            w3, [x0, #0x67]
    // 0x6397f4: DecompressPointer r3
    //     0x6397f4: add             x3, x3, HEAP, lsl #32
    // 0x6397f8: mov             x2, x1
    // 0x6397fc: stur            x3, [fp, #-8]
    // 0x639800: r1 = Function '<anonymous closure>':.
    //     0x639800: add             x1, PP, #0x52, lsl #12  ; [pp+0x52e40] AnonymousClosure: (0x639868), in [package:flutter_html/src/css_box_widget.dart] _RenderCSSBox::computeMinIntrinsicHeight (0x6398f4)
    //     0x639804: ldr             x1, [x1, #0xe40]
    // 0x639808: r0 = AllocateClosure()
    //     0x639808: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x63980c: ldur            x16, [fp, #-8]
    // 0x639810: stp             x0, x16, [SP, #-0x10]!
    // 0x639814: r0 = getIntrinsicDimension()
    //     0x639814: bl              #0x632354  ; [package:flutter/src/rendering/stack.dart] RenderStack::getIntrinsicDimension
    // 0x639818: add             SP, SP, #0x10
    // 0x63981c: r0 = inline_Allocate_Double()
    //     0x63981c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x639820: add             x0, x0, #0x10
    //     0x639824: cmp             x1, x0
    //     0x639828: b.ls            #0x639858
    //     0x63982c: str             x0, [THR, #0x60]  ; THR::top
    //     0x639830: sub             x0, x0, #0xf
    //     0x639834: mov             x1, #0xd108
    //     0x639838: movk            x1, #3, lsl #16
    //     0x63983c: stur            x1, [x0, #-1]
    // 0x639840: StoreField: r0->field_7 = d0
    //     0x639840: stur            d0, [x0, #7]
    // 0x639844: LeaveFrame
    //     0x639844: mov             SP, fp
    //     0x639848: ldp             fp, lr, [SP], #0x10
    // 0x63984c: ret
    //     0x63984c: ret             
    // 0x639850: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x639850: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x639854: b               #0x6397d8
    // 0x639858: SaveReg d0
    //     0x639858: str             q0, [SP, #-0x10]!
    // 0x63985c: r0 = AllocateDouble()
    //     0x63985c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x639860: RestoreReg d0
    //     0x639860: ldr             q0, [SP], #0x10
    // 0x639864: b               #0x639840
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63ca5c, size: 0x18
    // 0x63ca5c: r4 = 0
    //     0x63ca5c: mov             x4, #0
    // 0x63ca60: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63ca60: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fa50] AnonymousClosure: (0x63ca74), in [package:flutter/src/rendering/stack.dart] RenderStack::computeMinIntrinsicWidth (0x63cac0)
    //     0x63ca64: ldr             x1, [x17, #0xa50]
    // 0x63ca68: r24 = BuildNonGenericMethodExtractorStub
    //     0x63ca68: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63ca6c: LoadField: r0 = r24->field_17
    //     0x63ca6c: ldur            x0, [x24, #0x17]
    // 0x63ca70: br              x0
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63ca74, size: 0x4c
    // 0x63ca74: EnterFrame
    //     0x63ca74: stp             fp, lr, [SP, #-0x10]!
    //     0x63ca78: mov             fp, SP
    // 0x63ca7c: ldr             x0, [fp, #0x18]
    // 0x63ca80: LoadField: r1 = r0->field_17
    //     0x63ca80: ldur            w1, [x0, #0x17]
    // 0x63ca84: DecompressPointer r1
    //     0x63ca84: add             x1, x1, HEAP, lsl #32
    // 0x63ca88: CheckStackOverflow
    //     0x63ca88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63ca8c: cmp             SP, x16
    //     0x63ca90: b.ls            #0x63cab8
    // 0x63ca94: LoadField: r0 = r1->field_f
    //     0x63ca94: ldur            w0, [x1, #0xf]
    // 0x63ca98: DecompressPointer r0
    //     0x63ca98: add             x0, x0, HEAP, lsl #32
    // 0x63ca9c: ldr             x16, [fp, #0x10]
    // 0x63caa0: stp             x16, x0, [SP, #-0x10]!
    // 0x63caa4: r0 = computeMinIntrinsicWidth()
    //     0x63caa4: bl              #0x63cac0  ; [package:flutter/src/rendering/stack.dart] RenderStack::computeMinIntrinsicWidth
    // 0x63caa8: add             SP, SP, #0x10
    // 0x63caac: LeaveFrame
    //     0x63caac: mov             SP, fp
    //     0x63cab0: ldp             fp, lr, [SP], #0x10
    // 0x63cab4: ret
    //     0x63cab4: ret             
    // 0x63cab8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63cab8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63cabc: b               #0x63ca94
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0x63cac0, size: 0xa8
    // 0x63cac0: EnterFrame
    //     0x63cac0: stp             fp, lr, [SP, #-0x10]!
    //     0x63cac4: mov             fp, SP
    // 0x63cac8: AllocStack(0x8)
    //     0x63cac8: sub             SP, SP, #8
    // 0x63cacc: CheckStackOverflow
    //     0x63cacc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63cad0: cmp             SP, x16
    //     0x63cad4: b.ls            #0x63cb50
    // 0x63cad8: r1 = 1
    //     0x63cad8: mov             x1, #1
    // 0x63cadc: r0 = AllocateContext()
    //     0x63cadc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x63cae0: mov             x1, x0
    // 0x63cae4: ldr             x0, [fp, #0x10]
    // 0x63cae8: StoreField: r1->field_f = r0
    //     0x63cae8: stur            w0, [x1, #0xf]
    // 0x63caec: ldr             x0, [fp, #0x18]
    // 0x63caf0: LoadField: r3 = r0->field_67
    //     0x63caf0: ldur            w3, [x0, #0x67]
    // 0x63caf4: DecompressPointer r3
    //     0x63caf4: add             x3, x3, HEAP, lsl #32
    // 0x63caf8: mov             x2, x1
    // 0x63cafc: stur            x3, [fp, #-8]
    // 0x63cb00: r1 = Function '<anonymous closure>':.
    //     0x63cb00: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4fa58] AnonymousClosure: (0x63cb68), in [package:flutter_html/src/css_box_widget.dart] _RenderCSSBox::computeMinIntrinsicWidth (0x63cbf4)
    //     0x63cb04: ldr             x1, [x1, #0xa58]
    // 0x63cb08: r0 = AllocateClosure()
    //     0x63cb08: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x63cb0c: ldur            x16, [fp, #-8]
    // 0x63cb10: stp             x0, x16, [SP, #-0x10]!
    // 0x63cb14: r0 = getIntrinsicDimension()
    //     0x63cb14: bl              #0x632354  ; [package:flutter/src/rendering/stack.dart] RenderStack::getIntrinsicDimension
    // 0x63cb18: add             SP, SP, #0x10
    // 0x63cb1c: r0 = inline_Allocate_Double()
    //     0x63cb1c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63cb20: add             x0, x0, #0x10
    //     0x63cb24: cmp             x1, x0
    //     0x63cb28: b.ls            #0x63cb58
    //     0x63cb2c: str             x0, [THR, #0x60]  ; THR::top
    //     0x63cb30: sub             x0, x0, #0xf
    //     0x63cb34: mov             x1, #0xd108
    //     0x63cb38: movk            x1, #3, lsl #16
    //     0x63cb3c: stur            x1, [x0, #-1]
    // 0x63cb40: StoreField: r0->field_7 = d0
    //     0x63cb40: stur            d0, [x0, #7]
    // 0x63cb44: LeaveFrame
    //     0x63cb44: mov             SP, fp
    //     0x63cb48: ldp             fp, lr, [SP], #0x10
    // 0x63cb4c: ret
    //     0x63cb4c: ret             
    // 0x63cb50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63cb50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63cb54: b               #0x63cad8
    // 0x63cb58: SaveReg d0
    //     0x63cb58: str             q0, [SP, #-0x10]!
    // 0x63cb5c: r0 = AllocateDouble()
    //     0x63cb5c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63cb60: RestoreReg d0
    //     0x63cb60: ldr             q0, [SP], #0x10
    // 0x63cb64: b               #0x63cb40
  }
  _ computeDistanceToActualBaseline(/* No info */) {
    // ** addr: 0x63e7b8, size: 0x3c
    // 0x63e7b8: EnterFrame
    //     0x63e7b8: stp             fp, lr, [SP, #-0x10]!
    //     0x63e7bc: mov             fp, SP
    // 0x63e7c0: CheckStackOverflow
    //     0x63e7c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63e7c4: cmp             SP, x16
    //     0x63e7c8: b.ls            #0x63e7ec
    // 0x63e7cc: ldr             x16, [fp, #0x18]
    // 0x63e7d0: ldr             lr, [fp, #0x10]
    // 0x63e7d4: stp             lr, x16, [SP, #-0x10]!
    // 0x63e7d8: r0 = defaultComputeDistanceToHighestActualBaseline()
    //     0x63e7d8: bl              #0x63e7f4  ; [package:flutter/src/rendering/stack.dart] _RenderStack&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultComputeDistanceToHighestActualBaseline
    // 0x63e7dc: add             SP, SP, #0x10
    // 0x63e7e0: LeaveFrame
    //     0x63e7e0: mov             SP, fp
    //     0x63e7e4: ldp             fp, lr, [SP], #0x10
    // 0x63e7e8: ret
    //     0x63e7e8: ret             
    // 0x63e7ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63e7ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63e7f0: b               #0x63e7cc
  }
  _ paint(/* No info */) {
    // ** addr: 0x66f0e0, size: 0x260
    // 0x66f0e0: EnterFrame
    //     0x66f0e0: stp             fp, lr, [SP, #-0x10]!
    //     0x66f0e4: mov             fp, SP
    // 0x66f0e8: AllocStack(0x18)
    //     0x66f0e8: sub             SP, SP, #0x18
    // 0x66f0ec: CheckStackOverflow
    //     0x66f0ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66f0f0: cmp             SP, x16
    //     0x66f0f4: b.ls            #0x66f328
    // 0x66f0f8: ldr             x0, [fp, #0x20]
    // 0x66f0fc: LoadField: r1 = r0->field_83
    //     0x66f0fc: ldur            w1, [x0, #0x83]
    // 0x66f100: DecompressPointer r1
    //     0x66f100: add             x1, x1, HEAP, lsl #32
    // 0x66f104: r16 = Instance_Clip
    //     0x66f104: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x66f108: ldr             x16, [x16, #0xb38]
    // 0x66f10c: cmp             w1, w16
    // 0x66f110: b.eq            #0x66f230
    // 0x66f114: LoadField: r1 = r0->field_6f
    //     0x66f114: ldur            w1, [x0, #0x6f]
    // 0x66f118: DecompressPointer r1
    //     0x66f118: add             x1, x1, HEAP, lsl #32
    // 0x66f11c: tbnz            w1, #4, #0x66f230
    // 0x66f120: LoadField: r1 = r0->field_87
    //     0x66f120: ldur            w1, [x0, #0x87]
    // 0x66f124: DecompressPointer r1
    //     0x66f124: add             x1, x1, HEAP, lsl #32
    // 0x66f128: stur            x1, [fp, #-0x10]
    // 0x66f12c: LoadField: r2 = r0->field_37
    //     0x66f12c: ldur            w2, [x0, #0x37]
    // 0x66f130: DecompressPointer r2
    //     0x66f130: add             x2, x2, HEAP, lsl #32
    // 0x66f134: r16 = Sentinel
    //     0x66f134: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x66f138: cmp             w2, w16
    // 0x66f13c: b.eq            #0x66f330
    // 0x66f140: stur            x2, [fp, #-8]
    // 0x66f144: LoadField: r3 = r0->field_57
    //     0x66f144: ldur            w3, [x0, #0x57]
    // 0x66f148: DecompressPointer r3
    //     0x66f148: add             x3, x3, HEAP, lsl #32
    // 0x66f14c: cmp             w3, NULL
    // 0x66f150: b.eq            #0x66f338
    // 0x66f154: r16 = Instance_Offset
    //     0x66f154: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x66f158: stp             x3, x16, [SP, #-0x10]!
    // 0x66f15c: r0 = &()
    //     0x66f15c: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x66f160: add             SP, SP, #0x10
    // 0x66f164: mov             x1, x0
    // 0x66f168: ldr             x0, [fp, #0x20]
    // 0x66f16c: stur            x1, [fp, #-0x18]
    // 0x66f170: r2 = LoadClassIdInstr(r0)
    //     0x66f170: ldur            x2, [x0, #-1]
    //     0x66f174: ubfx            x2, x2, #0xc, #0x14
    // 0x66f178: lsl             x2, x2, #1
    // 0x66f17c: r17 = 4854
    //     0x66f17c: mov             x17, #0x12f6
    // 0x66f180: cmp             w2, w17
    // 0x66f184: b.ne            #0x66f1b4
    // 0x66f188: r1 = 1
    //     0x66f188: mov             x1, #1
    // 0x66f18c: r0 = AllocateContext()
    //     0x66f18c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x66f190: mov             x1, x0
    // 0x66f194: ldr             x0, [fp, #0x20]
    // 0x66f198: StoreField: r1->field_f = r0
    //     0x66f198: stur            w0, [x1, #0xf]
    // 0x66f19c: mov             x2, x1
    // 0x66f1a0: r1 = Function 'paintStack':.
    //     0x66f1a0: add             x1, PP, #0x21, lsl #12  ; [pp+0x219e0] AnonymousClosure: (0x66f4c0), of [package:flutter/src/rendering/stack.dart] RenderStack
    //     0x66f1a4: ldr             x1, [x1, #0x9e0]
    // 0x66f1a8: r0 = AllocateClosure()
    //     0x66f1a8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x66f1ac: mov             x2, x0
    // 0x66f1b0: b               #0x66f1dc
    // 0x66f1b4: r1 = 1
    //     0x66f1b4: mov             x1, #1
    // 0x66f1b8: r0 = AllocateContext()
    //     0x66f1b8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x66f1bc: mov             x1, x0
    // 0x66f1c0: ldr             x0, [fp, #0x20]
    // 0x66f1c4: StoreField: r1->field_f = r0
    //     0x66f1c4: stur            w0, [x1, #0xf]
    // 0x66f1c8: mov             x2, x1
    // 0x66f1cc: r1 = Function 'paintStack':.
    //     0x66f1cc: add             x1, PP, #0x21, lsl #12  ; [pp+0x219e8] AnonymousClosure: (0x66f46c), in [package:flutter/src/rendering/stack.dart] RenderIndexedStack::paintStack (0xcf1e3c)
    //     0x66f1d0: ldr             x1, [x1, #0x9e8]
    // 0x66f1d4: r0 = AllocateClosure()
    //     0x66f1d4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x66f1d8: mov             x2, x0
    // 0x66f1dc: ldr             x0, [fp, #0x20]
    // 0x66f1e0: ldur            x1, [fp, #-0x10]
    // 0x66f1e4: LoadField: r3 = r0->field_83
    //     0x66f1e4: ldur            w3, [x0, #0x83]
    // 0x66f1e8: DecompressPointer r3
    //     0x66f1e8: add             x3, x3, HEAP, lsl #32
    // 0x66f1ec: LoadField: r0 = r1->field_b
    //     0x66f1ec: ldur            w0, [x1, #0xb]
    // 0x66f1f0: DecompressPointer r0
    //     0x66f1f0: add             x0, x0, HEAP, lsl #32
    // 0x66f1f4: ldr             x16, [fp, #0x18]
    // 0x66f1f8: ldur            lr, [fp, #-8]
    // 0x66f1fc: stp             lr, x16, [SP, #-0x10]!
    // 0x66f200: ldr             x16, [fp, #0x10]
    // 0x66f204: ldur            lr, [fp, #-0x18]
    // 0x66f208: stp             lr, x16, [SP, #-0x10]!
    // 0x66f20c: stp             x3, x2, [SP, #-0x10]!
    // 0x66f210: SaveReg r0
    //     0x66f210: str             x0, [SP, #-8]!
    // 0x66f214: r0 = pushClipRect()
    //     0x66f214: bl              #0x65b240  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRect
    // 0x66f218: add             SP, SP, #0x38
    // 0x66f21c: ldur            x16, [fp, #-0x10]
    // 0x66f220: stp             x0, x16, [SP, #-0x10]!
    // 0x66f224: r0 = layer=()
    //     0x66f224: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x66f228: add             SP, SP, #0x10
    // 0x66f22c: b               #0x66f318
    // 0x66f230: LoadField: r1 = r0->field_87
    //     0x66f230: ldur            w1, [x0, #0x87]
    // 0x66f234: DecompressPointer r1
    //     0x66f234: add             x1, x1, HEAP, lsl #32
    // 0x66f238: stp             NULL, x1, [SP, #-0x10]!
    // 0x66f23c: r0 = layer=()
    //     0x66f23c: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x66f240: add             SP, SP, #0x10
    // 0x66f244: ldr             x0, [fp, #0x20]
    // 0x66f248: r1 = LoadClassIdInstr(r0)
    //     0x66f248: ldur            x1, [x0, #-1]
    //     0x66f24c: ubfx            x1, x1, #0xc, #0x14
    // 0x66f250: lsl             x1, x1, #1
    // 0x66f254: r17 = 4854
    //     0x66f254: mov             x17, #0x12f6
    // 0x66f258: cmp             w1, w17
    // 0x66f25c: b.ne            #0x66f27c
    // 0x66f260: ldr             x16, [fp, #0x18]
    // 0x66f264: stp             x16, x0, [SP, #-0x10]!
    // 0x66f268: ldr             x16, [fp, #0x10]
    // 0x66f26c: SaveReg r16
    //     0x66f26c: str             x16, [SP, #-8]!
    // 0x66f270: r0 = defaultPaint()
    //     0x66f270: bl              #0x66f340  ; [package:flutter/src/rendering/stack.dart] _RenderStack&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultPaint
    // 0x66f274: add             SP, SP, #0x18
    // 0x66f278: b               #0x66f318
    // 0x66f27c: LoadField: r1 = r0->field_67
    //     0x66f27c: ldur            w1, [x0, #0x67]
    // 0x66f280: DecompressPointer r1
    //     0x66f280: add             x1, x1, HEAP, lsl #32
    // 0x66f284: cmp             w1, NULL
    // 0x66f288: b.eq            #0x66f318
    // 0x66f28c: SaveReg r0
    //     0x66f28c: str             x0, [SP, #-8]!
    // 0x66f290: r0 = _childAtIndex()
    //     0x66f290: bl              #0x629ab8  ; [package:flutter/src/rendering/stack.dart] RenderIndexedStack::_childAtIndex
    // 0x66f294: add             SP, SP, #8
    // 0x66f298: mov             x3, x0
    // 0x66f29c: stur            x3, [fp, #-0x10]
    // 0x66f2a0: LoadField: r4 = r3->field_17
    //     0x66f2a0: ldur            w4, [x3, #0x17]
    // 0x66f2a4: DecompressPointer r4
    //     0x66f2a4: add             x4, x4, HEAP, lsl #32
    // 0x66f2a8: stur            x4, [fp, #-8]
    // 0x66f2ac: cmp             w4, NULL
    // 0x66f2b0: b.eq            #0x66f33c
    // 0x66f2b4: mov             x0, x4
    // 0x66f2b8: r2 = Null
    //     0x66f2b8: mov             x2, NULL
    // 0x66f2bc: r1 = Null
    //     0x66f2bc: mov             x1, NULL
    // 0x66f2c0: r4 = LoadClassIdInstr(r0)
    //     0x66f2c0: ldur            x4, [x0, #-1]
    //     0x66f2c4: ubfx            x4, x4, #0xc, #0x14
    // 0x66f2c8: cmp             x4, #0x807
    // 0x66f2cc: b.eq            #0x66f2e4
    // 0x66f2d0: r8 = StackParentData<RenderBox>
    //     0x66f2d0: add             x8, PP, #0x21, lsl #12  ; [pp+0x215a0] Type: StackParentData<RenderBox>
    //     0x66f2d4: ldr             x8, [x8, #0x5a0]
    // 0x66f2d8: r3 = Null
    //     0x66f2d8: add             x3, PP, #0x21, lsl #12  ; [pp+0x219f0] Null
    //     0x66f2dc: ldr             x3, [x3, #0x9f0]
    // 0x66f2e0: r0 = DefaultTypeTest()
    //     0x66f2e0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x66f2e4: ldur            x0, [fp, #-8]
    // 0x66f2e8: LoadField: r1 = r0->field_7
    //     0x66f2e8: ldur            w1, [x0, #7]
    // 0x66f2ec: DecompressPointer r1
    //     0x66f2ec: add             x1, x1, HEAP, lsl #32
    // 0x66f2f0: ldr             x16, [fp, #0x10]
    // 0x66f2f4: stp             x16, x1, [SP, #-0x10]!
    // 0x66f2f8: r0 = +()
    //     0x66f2f8: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x66f2fc: add             SP, SP, #0x10
    // 0x66f300: ldr             x16, [fp, #0x18]
    // 0x66f304: ldur            lr, [fp, #-0x10]
    // 0x66f308: stp             lr, x16, [SP, #-0x10]!
    // 0x66f30c: SaveReg r0
    //     0x66f30c: str             x0, [SP, #-8]!
    // 0x66f310: r0 = paintChild()
    //     0x66f310: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x66f314: add             SP, SP, #0x18
    // 0x66f318: r0 = Null
    //     0x66f318: mov             x0, NULL
    // 0x66f31c: LeaveFrame
    //     0x66f31c: mov             SP, fp
    //     0x66f320: ldp             fp, lr, [SP], #0x10
    // 0x66f324: ret
    //     0x66f324: ret             
    // 0x66f328: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66f328: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66f32c: b               #0x66f0f8
    // 0x66f330: r9 = _needsCompositing
    //     0x66f330: ldr             x9, [PP, #0x4b28]  ; [pp+0x4b28] Field <RenderObject._needsCompositing@904266271>: late (offset: 0x38)
    // 0x66f334: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x66f334: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x66f338: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66f338: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x66f33c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66f33c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void paintStack(dynamic, PaintingContext, Offset) {
    // ** addr: 0x66f4c0, size: 0x58
    // 0x66f4c0: EnterFrame
    //     0x66f4c0: stp             fp, lr, [SP, #-0x10]!
    //     0x66f4c4: mov             fp, SP
    // 0x66f4c8: ldr             x0, [fp, #0x20]
    // 0x66f4cc: LoadField: r1 = r0->field_17
    //     0x66f4cc: ldur            w1, [x0, #0x17]
    // 0x66f4d0: DecompressPointer r1
    //     0x66f4d0: add             x1, x1, HEAP, lsl #32
    // 0x66f4d4: CheckStackOverflow
    //     0x66f4d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66f4d8: cmp             SP, x16
    //     0x66f4dc: b.ls            #0x66f510
    // 0x66f4e0: LoadField: r0 = r1->field_f
    //     0x66f4e0: ldur            w0, [x1, #0xf]
    // 0x66f4e4: DecompressPointer r0
    //     0x66f4e4: add             x0, x0, HEAP, lsl #32
    // 0x66f4e8: ldr             x16, [fp, #0x18]
    // 0x66f4ec: stp             x16, x0, [SP, #-0x10]!
    // 0x66f4f0: ldr             x16, [fp, #0x10]
    // 0x66f4f4: SaveReg r16
    //     0x66f4f4: str             x16, [SP, #-8]!
    // 0x66f4f8: r0 = defaultPaint()
    //     0x66f4f8: bl              #0x66f340  ; [package:flutter/src/rendering/stack.dart] _RenderStack&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultPaint
    // 0x66f4fc: add             SP, SP, #0x18
    // 0x66f500: r0 = Null
    //     0x66f500: mov             x0, NULL
    // 0x66f504: LeaveFrame
    //     0x66f504: mov             SP, fp
    //     0x66f508: ldp             fp, lr, [SP], #0x10
    // 0x66f50c: ret
    //     0x66f50c: ret             
    // 0x66f510: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66f510: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66f514: b               #0x66f4e0
  }
  _ describeApproximatePaintClip(/* No info */) {
    // ** addr: 0x675760, size: 0x90
    // 0x675760: EnterFrame
    //     0x675760: stp             fp, lr, [SP, #-0x10]!
    //     0x675764: mov             fp, SP
    // 0x675768: CheckStackOverflow
    //     0x675768: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67576c: cmp             SP, x16
    //     0x675770: b.ls            #0x6757e4
    // 0x675774: ldr             x0, [fp, #0x18]
    // 0x675778: LoadField: r1 = r0->field_83
    //     0x675778: ldur            w1, [x0, #0x83]
    // 0x67577c: DecompressPointer r1
    //     0x67577c: add             x1, x1, HEAP, lsl #32
    // 0x675780: LoadField: r2 = r1->field_7
    //     0x675780: ldur            x2, [x1, #7]
    // 0x675784: cmp             x2, #1
    // 0x675788: b.gt            #0x6757a4
    // 0x67578c: cmp             x2, #0
    // 0x675790: b.gt            #0x6757a4
    // 0x675794: r0 = Null
    //     0x675794: mov             x0, NULL
    // 0x675798: LeaveFrame
    //     0x675798: mov             SP, fp
    //     0x67579c: ldp             fp, lr, [SP], #0x10
    // 0x6757a0: ret
    //     0x6757a0: ret             
    // 0x6757a4: LoadField: r1 = r0->field_6f
    //     0x6757a4: ldur            w1, [x0, #0x6f]
    // 0x6757a8: DecompressPointer r1
    //     0x6757a8: add             x1, x1, HEAP, lsl #32
    // 0x6757ac: tbnz            w1, #4, #0x6757d4
    // 0x6757b0: LoadField: r1 = r0->field_57
    //     0x6757b0: ldur            w1, [x0, #0x57]
    // 0x6757b4: DecompressPointer r1
    //     0x6757b4: add             x1, x1, HEAP, lsl #32
    // 0x6757b8: cmp             w1, NULL
    // 0x6757bc: b.eq            #0x6757ec
    // 0x6757c0: r16 = Instance_Offset
    //     0x6757c0: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x6757c4: stp             x1, x16, [SP, #-0x10]!
    // 0x6757c8: r0 = &()
    //     0x6757c8: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x6757cc: add             SP, SP, #0x10
    // 0x6757d0: b               #0x6757d8
    // 0x6757d4: r0 = Null
    //     0x6757d4: mov             x0, NULL
    // 0x6757d8: LeaveFrame
    //     0x6757d8: mov             SP, fp
    //     0x6757dc: ldp             fp, lr, [SP], #0x10
    // 0x6757e0: ret
    //     0x6757e0: ret             
    // 0x6757e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6757e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6757e8: b               #0x675774
    // 0x6757ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6757ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x69cd24, size: 0x308
    // 0x69cd24: EnterFrame
    //     0x69cd24: stp             fp, lr, [SP, #-0x10]!
    //     0x69cd28: mov             fp, SP
    // 0x69cd2c: AllocStack(0x20)
    //     0x69cd2c: sub             SP, SP, #0x20
    // 0x69cd30: CheckStackOverflow
    //     0x69cd30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x69cd34: cmp             SP, x16
    //     0x69cd38: b.ls            #0x69d004
    // 0x69cd3c: ldr             x3, [fp, #0x10]
    // 0x69cd40: LoadField: r4 = r3->field_27
    //     0x69cd40: ldur            w4, [x3, #0x27]
    // 0x69cd44: DecompressPointer r4
    //     0x69cd44: add             x4, x4, HEAP, lsl #32
    // 0x69cd48: stur            x4, [fp, #-8]
    // 0x69cd4c: cmp             w4, NULL
    // 0x69cd50: b.eq            #0x69cfe4
    // 0x69cd54: mov             x0, x4
    // 0x69cd58: r2 = Null
    //     0x69cd58: mov             x2, NULL
    // 0x69cd5c: r1 = Null
    //     0x69cd5c: mov             x1, NULL
    // 0x69cd60: r4 = LoadClassIdInstr(r0)
    //     0x69cd60: ldur            x4, [x0, #-1]
    //     0x69cd64: ubfx            x4, x4, #0xc, #0x14
    // 0x69cd68: sub             x4, x4, #0x80d
    // 0x69cd6c: cmp             x4, #1
    // 0x69cd70: b.ls            #0x69cd88
    // 0x69cd74: r8 = BoxConstraints
    //     0x69cd74: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x69cd78: ldr             x8, [x8, #0x1d0]
    // 0x69cd7c: r3 = Null
    //     0x69cd7c: add             x3, PP, #0x21, lsl #12  ; [pp+0x21a40] Null
    //     0x69cd80: ldr             x3, [x3, #0xa40]
    // 0x69cd84: r0 = BoxConstraints()
    //     0x69cd84: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x69cd88: ldr             x0, [fp, #0x10]
    // 0x69cd8c: r1 = false
    //     0x69cd8c: add             x1, NULL, #0x30  ; false
    // 0x69cd90: StoreField: r0->field_6f = r1
    //     0x69cd90: stur            w1, [x0, #0x6f]
    // 0x69cd94: ldur            x16, [fp, #-8]
    // 0x69cd98: stp             x16, x0, [SP, #-0x10]!
    // 0x69cd9c: r16 = Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static.
    //     0x69cd9c: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cf80] Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static. (0x7fe6e1e8aefc)
    //     0x69cda0: ldr             x16, [x16, #0xf80]
    // 0x69cda4: SaveReg r16
    //     0x69cda4: str             x16, [SP, #-8]!
    // 0x69cda8: r0 = _computeSize()
    //     0x69cda8: bl              #0x69d484  ; [package:flutter/src/rendering/stack.dart] RenderStack::_computeSize
    // 0x69cdac: add             SP, SP, #0x18
    // 0x69cdb0: ldr             x3, [fp, #0x10]
    // 0x69cdb4: StoreField: r3->field_57 = r0
    //     0x69cdb4: stur            w0, [x3, #0x57]
    //     0x69cdb8: ldurb           w16, [x3, #-1]
    //     0x69cdbc: ldurb           w17, [x0, #-1]
    //     0x69cdc0: and             x16, x17, x16, lsr #2
    //     0x69cdc4: tst             x16, HEAP, lsr #32
    //     0x69cdc8: b.eq            #0x69cdd0
    //     0x69cdcc: bl              #0xd682ac
    // 0x69cdd0: LoadField: r0 = r3->field_67
    //     0x69cdd0: ldur            w0, [x3, #0x67]
    // 0x69cdd4: DecompressPointer r0
    //     0x69cdd4: add             x0, x0, HEAP, lsl #32
    // 0x69cdd8: mov             x4, x0
    // 0x69cddc: stur            x4, [fp, #-0x10]
    // 0x69cde0: CheckStackOverflow
    //     0x69cde0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x69cde4: cmp             SP, x16
    //     0x69cde8: b.ls            #0x69d00c
    // 0x69cdec: cmp             w4, NULL
    // 0x69cdf0: b.eq            #0x69cfd4
    // 0x69cdf4: LoadField: r5 = r4->field_17
    //     0x69cdf4: ldur            w5, [x4, #0x17]
    // 0x69cdf8: DecompressPointer r5
    //     0x69cdf8: add             x5, x5, HEAP, lsl #32
    // 0x69cdfc: stur            x5, [fp, #-8]
    // 0x69ce00: cmp             w5, NULL
    // 0x69ce04: b.eq            #0x69d014
    // 0x69ce08: mov             x0, x5
    // 0x69ce0c: r2 = Null
    //     0x69ce0c: mov             x2, NULL
    // 0x69ce10: r1 = Null
    //     0x69ce10: mov             x1, NULL
    // 0x69ce14: r4 = LoadClassIdInstr(r0)
    //     0x69ce14: ldur            x4, [x0, #-1]
    //     0x69ce18: ubfx            x4, x4, #0xc, #0x14
    // 0x69ce1c: cmp             x4, #0x807
    // 0x69ce20: b.eq            #0x69ce38
    // 0x69ce24: r8 = StackParentData<RenderBox>
    //     0x69ce24: add             x8, PP, #0x21, lsl #12  ; [pp+0x215a0] Type: StackParentData<RenderBox>
    //     0x69ce28: ldr             x8, [x8, #0x5a0]
    // 0x69ce2c: r3 = Null
    //     0x69ce2c: add             x3, PP, #0x21, lsl #12  ; [pp+0x21a50] Null
    //     0x69ce30: ldr             x3, [x3, #0xa50]
    // 0x69ce34: r0 = DefaultTypeTest()
    //     0x69ce34: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x69ce38: ldur            x0, [fp, #-8]
    // 0x69ce3c: LoadField: r1 = r0->field_17
    //     0x69ce3c: ldur            w1, [x0, #0x17]
    // 0x69ce40: DecompressPointer r1
    //     0x69ce40: add             x1, x1, HEAP, lsl #32
    // 0x69ce44: cmp             w1, NULL
    // 0x69ce48: b.ne            #0x69ce8c
    // 0x69ce4c: LoadField: r1 = r0->field_1b
    //     0x69ce4c: ldur            w1, [x0, #0x1b]
    // 0x69ce50: DecompressPointer r1
    //     0x69ce50: add             x1, x1, HEAP, lsl #32
    // 0x69ce54: cmp             w1, NULL
    // 0x69ce58: b.ne            #0x69ce8c
    // 0x69ce5c: LoadField: r1 = r0->field_1f
    //     0x69ce5c: ldur            w1, [x0, #0x1f]
    // 0x69ce60: DecompressPointer r1
    //     0x69ce60: add             x1, x1, HEAP, lsl #32
    // 0x69ce64: cmp             w1, NULL
    // 0x69ce68: b.ne            #0x69ce8c
    // 0x69ce6c: LoadField: r1 = r0->field_23
    //     0x69ce6c: ldur            w1, [x0, #0x23]
    // 0x69ce70: DecompressPointer r1
    //     0x69ce70: add             x1, x1, HEAP, lsl #32
    // 0x69ce74: cmp             w1, NULL
    // 0x69ce78: b.ne            #0x69ce8c
    // 0x69ce7c: LoadField: r1 = r0->field_27
    //     0x69ce7c: ldur            w1, [x0, #0x27]
    // 0x69ce80: DecompressPointer r1
    //     0x69ce80: add             x1, x1, HEAP, lsl #32
    // 0x69ce84: cmp             w1, NULL
    // 0x69ce88: b.eq            #0x69ce98
    // 0x69ce8c: ldur            x2, [fp, #-0x10]
    // 0x69ce90: mov             x1, x0
    // 0x69ce94: b               #0x69cf6c
    // 0x69ce98: LoadField: r1 = r0->field_2b
    //     0x69ce98: ldur            w1, [x0, #0x2b]
    // 0x69ce9c: DecompressPointer r1
    //     0x69ce9c: add             x1, x1, HEAP, lsl #32
    // 0x69cea0: cmp             w1, NULL
    // 0x69cea4: b.ne            #0x69cf64
    // 0x69cea8: ldr             x1, [fp, #0x10]
    // 0x69ceac: ldur            x2, [fp, #-0x10]
    // 0x69ceb0: d0 = 2.000000
    //     0x69ceb0: fmov            d0, #2.00000000
    // 0x69ceb4: LoadField: r3 = r1->field_73
    //     0x69ceb4: ldur            w3, [x1, #0x73]
    // 0x69ceb8: DecompressPointer r3
    //     0x69ceb8: add             x3, x3, HEAP, lsl #32
    // 0x69cebc: cmp             w3, NULL
    // 0x69cec0: b.eq            #0x69d018
    // 0x69cec4: LoadField: r4 = r1->field_57
    //     0x69cec4: ldur            w4, [x1, #0x57]
    // 0x69cec8: DecompressPointer r4
    //     0x69cec8: add             x4, x4, HEAP, lsl #32
    // 0x69cecc: cmp             w4, NULL
    // 0x69ced0: b.eq            #0x69d01c
    // 0x69ced4: LoadField: r5 = r2->field_57
    //     0x69ced4: ldur            w5, [x2, #0x57]
    // 0x69ced8: DecompressPointer r5
    //     0x69ced8: add             x5, x5, HEAP, lsl #32
    // 0x69cedc: cmp             w5, NULL
    // 0x69cee0: b.eq            #0x69d020
    // 0x69cee4: LoadField: d1 = r4->field_7
    //     0x69cee4: ldur            d1, [x4, #7]
    // 0x69cee8: LoadField: d2 = r5->field_7
    //     0x69cee8: ldur            d2, [x5, #7]
    // 0x69ceec: fsub            d3, d1, d2
    // 0x69cef0: LoadField: d1 = r4->field_f
    //     0x69cef0: ldur            d1, [x4, #0xf]
    // 0x69cef4: LoadField: d2 = r5->field_f
    //     0x69cef4: ldur            d2, [x5, #0xf]
    // 0x69cef8: fsub            d4, d1, d2
    // 0x69cefc: fdiv            d1, d3, d0
    // 0x69cf00: fdiv            d2, d4, d0
    // 0x69cf04: LoadField: d3 = r3->field_7
    //     0x69cf04: ldur            d3, [x3, #7]
    // 0x69cf08: fmul            d4, d3, d1
    // 0x69cf0c: fadd            d3, d1, d4
    // 0x69cf10: stur            d3, [fp, #-0x20]
    // 0x69cf14: LoadField: d1 = r3->field_f
    //     0x69cf14: ldur            d1, [x3, #0xf]
    // 0x69cf18: fmul            d4, d1, d2
    // 0x69cf1c: fadd            d1, d2, d4
    // 0x69cf20: stur            d1, [fp, #-0x18]
    // 0x69cf24: r0 = Offset()
    //     0x69cf24: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x69cf28: ldur            d0, [fp, #-0x20]
    // 0x69cf2c: StoreField: r0->field_7 = d0
    //     0x69cf2c: stur            d0, [x0, #7]
    // 0x69cf30: ldur            d0, [fp, #-0x18]
    // 0x69cf34: StoreField: r0->field_f = d0
    //     0x69cf34: stur            d0, [x0, #0xf]
    // 0x69cf38: ldur            x1, [fp, #-8]
    // 0x69cf3c: StoreField: r1->field_7 = r0
    //     0x69cf3c: stur            w0, [x1, #7]
    //     0x69cf40: ldurb           w16, [x1, #-1]
    //     0x69cf44: ldurb           w17, [x0, #-1]
    //     0x69cf48: and             x16, x17, x16, lsr #2
    //     0x69cf4c: tst             x16, HEAP, lsr #32
    //     0x69cf50: b.eq            #0x69cf58
    //     0x69cf54: bl              #0xd6826c
    // 0x69cf58: mov             x2, x1
    // 0x69cf5c: ldr             x1, [fp, #0x10]
    // 0x69cf60: b               #0x69cfc4
    // 0x69cf64: ldur            x2, [fp, #-0x10]
    // 0x69cf68: mov             x1, x0
    // 0x69cf6c: ldr             x0, [fp, #0x10]
    // 0x69cf70: LoadField: r3 = r0->field_57
    //     0x69cf70: ldur            w3, [x0, #0x57]
    // 0x69cf74: DecompressPointer r3
    //     0x69cf74: add             x3, x3, HEAP, lsl #32
    // 0x69cf78: cmp             w3, NULL
    // 0x69cf7c: b.eq            #0x69d024
    // 0x69cf80: LoadField: r4 = r0->field_73
    //     0x69cf80: ldur            w4, [x0, #0x73]
    // 0x69cf84: DecompressPointer r4
    //     0x69cf84: add             x4, x4, HEAP, lsl #32
    // 0x69cf88: cmp             w4, NULL
    // 0x69cf8c: b.eq            #0x69d028
    // 0x69cf90: stp             x1, x2, [SP, #-0x10]!
    // 0x69cf94: stp             x4, x3, [SP, #-0x10]!
    // 0x69cf98: r0 = layoutPositionedChild()
    //     0x69cf98: bl              #0x69d02c  ; [package:flutter/src/rendering/stack.dart] RenderStack::layoutPositionedChild
    // 0x69cf9c: add             SP, SP, #0x20
    // 0x69cfa0: tbnz            w0, #4, #0x69cfb0
    // 0x69cfa4: ldr             x1, [fp, #0x10]
    // 0x69cfa8: r2 = true
    //     0x69cfa8: add             x2, NULL, #0x20  ; true
    // 0x69cfac: b               #0x69cfbc
    // 0x69cfb0: ldr             x1, [fp, #0x10]
    // 0x69cfb4: LoadField: r2 = r1->field_6f
    //     0x69cfb4: ldur            w2, [x1, #0x6f]
    // 0x69cfb8: DecompressPointer r2
    //     0x69cfb8: add             x2, x2, HEAP, lsl #32
    // 0x69cfbc: StoreField: r1->field_6f = r2
    //     0x69cfbc: stur            w2, [x1, #0x6f]
    // 0x69cfc0: ldur            x2, [fp, #-8]
    // 0x69cfc4: LoadField: r4 = r2->field_13
    //     0x69cfc4: ldur            w4, [x2, #0x13]
    // 0x69cfc8: DecompressPointer r4
    //     0x69cfc8: add             x4, x4, HEAP, lsl #32
    // 0x69cfcc: mov             x3, x1
    // 0x69cfd0: b               #0x69cddc
    // 0x69cfd4: r0 = Null
    //     0x69cfd4: mov             x0, NULL
    // 0x69cfd8: LeaveFrame
    //     0x69cfd8: mov             SP, fp
    //     0x69cfdc: ldp             fp, lr, [SP], #0x10
    // 0x69cfe0: ret
    //     0x69cfe0: ret             
    // 0x69cfe4: r0 = StateError()
    //     0x69cfe4: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x69cfe8: mov             x1, x0
    // 0x69cfec: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x69cfec: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x69cff0: ldr             x0, [x0, #0x1e8]
    // 0x69cff4: StoreField: r1->field_b = r0
    //     0x69cff4: stur            w0, [x1, #0xb]
    // 0x69cff8: mov             x0, x1
    // 0x69cffc: r0 = Throw()
    //     0x69cffc: bl              #0xd67e38  ; ThrowStub
    // 0x69d000: brk             #0
    // 0x69d004: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69d004: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69d008: b               #0x69cd3c
    // 0x69d00c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69d00c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69d010: b               #0x69cdec
    // 0x69d014: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69d014: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69d018: r0 = NullCastErrorSharedWithFPURegs()
    //     0x69d018: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x69d01c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x69d01c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x69d020: r0 = NullCastErrorSharedWithFPURegs()
    //     0x69d020: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x69d024: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69d024: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69d028: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69d028: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ layoutPositionedChild(/* No info */) {
    // ** addr: 0x69d02c, size: 0x458
    // 0x69d02c: EnterFrame
    //     0x69d02c: stp             fp, lr, [SP, #-0x10]!
    //     0x69d030: mov             fp, SP
    // 0x69d034: AllocStack(0x18)
    //     0x69d034: sub             SP, SP, #0x18
    // 0x69d038: CheckStackOverflow
    //     0x69d038: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x69d03c: cmp             SP, x16
    //     0x69d040: b.ls            #0x69d424
    // 0x69d044: ldr             x0, [fp, #0x20]
    // 0x69d048: LoadField: r1 = r0->field_23
    //     0x69d048: ldur            w1, [x0, #0x23]
    // 0x69d04c: DecompressPointer r1
    //     0x69d04c: add             x1, x1, HEAP, lsl #32
    // 0x69d050: cmp             w1, NULL
    // 0x69d054: b.eq            #0x69d0cc
    // 0x69d058: LoadField: r2 = r0->field_1b
    //     0x69d058: ldur            w2, [x0, #0x1b]
    // 0x69d05c: DecompressPointer r2
    //     0x69d05c: add             x2, x2, HEAP, lsl #32
    // 0x69d060: cmp             w2, NULL
    // 0x69d064: b.eq            #0x69d0cc
    // 0x69d068: ldr             x3, [fp, #0x18]
    // 0x69d06c: LoadField: d0 = r3->field_7
    //     0x69d06c: ldur            d0, [x3, #7]
    // 0x69d070: LoadField: d1 = r2->field_7
    //     0x69d070: ldur            d1, [x2, #7]
    // 0x69d074: fsub            d2, d0, d1
    // 0x69d078: LoadField: d0 = r1->field_7
    //     0x69d078: ldur            d0, [x1, #7]
    // 0x69d07c: fsub            d1, d2, d0
    // 0x69d080: r1 = inline_Allocate_Double()
    //     0x69d080: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x69d084: add             x1, x1, #0x10
    //     0x69d088: cmp             x2, x1
    //     0x69d08c: b.ls            #0x69d42c
    //     0x69d090: str             x1, [THR, #0x60]  ; THR::top
    //     0x69d094: sub             x1, x1, #0xf
    //     0x69d098: mov             x2, #0xd108
    //     0x69d09c: movk            x2, #3, lsl #16
    //     0x69d0a0: stur            x2, [x1, #-1]
    // 0x69d0a4: StoreField: r1->field_7 = d1
    //     0x69d0a4: stur            d1, [x1, #7]
    // 0x69d0a8: r16 = Instance_BoxConstraints
    //     0x69d0a8: add             x16, PP, #0x21, lsl #12  ; [pp+0x21610] Obj!BoxConstraints@b35351
    //     0x69d0ac: ldr             x16, [x16, #0x610]
    // 0x69d0b0: stp             x1, x16, [SP, #-0x10]!
    // 0x69d0b4: r4 = const [0, 0x2, 0x2, 0x1, width, 0x1, null]
    //     0x69d0b4: add             x4, PP, #0x21, lsl #12  ; [pp+0x21618] List(7) [0, 0x2, 0x2, 0x1, "width", 0x1, Null]
    //     0x69d0b8: ldr             x4, [x4, #0x618]
    // 0x69d0bc: r0 = tighten()
    //     0x69d0bc: bl              #0x590b84  ; [package:flutter/src/rendering/box.dart] BoxConstraints::tighten
    // 0x69d0c0: add             SP, SP, #0x10
    // 0x69d0c4: mov             x1, x0
    // 0x69d0c8: b               #0x69d10c
    // 0x69d0cc: ldr             x0, [fp, #0x20]
    // 0x69d0d0: LoadField: r1 = r0->field_27
    //     0x69d0d0: ldur            w1, [x0, #0x27]
    // 0x69d0d4: DecompressPointer r1
    //     0x69d0d4: add             x1, x1, HEAP, lsl #32
    // 0x69d0d8: cmp             w1, NULL
    // 0x69d0dc: b.eq            #0x69d100
    // 0x69d0e0: r16 = Instance_BoxConstraints
    //     0x69d0e0: add             x16, PP, #0x21, lsl #12  ; [pp+0x21610] Obj!BoxConstraints@b35351
    //     0x69d0e4: ldr             x16, [x16, #0x610]
    // 0x69d0e8: stp             x1, x16, [SP, #-0x10]!
    // 0x69d0ec: r4 = const [0, 0x2, 0x2, 0x1, width, 0x1, null]
    //     0x69d0ec: add             x4, PP, #0x21, lsl #12  ; [pp+0x21618] List(7) [0, 0x2, 0x2, 0x1, "width", 0x1, Null]
    //     0x69d0f0: ldr             x4, [x4, #0x618]
    // 0x69d0f4: r0 = tighten()
    //     0x69d0f4: bl              #0x590b84  ; [package:flutter/src/rendering/box.dart] BoxConstraints::tighten
    // 0x69d0f8: add             SP, SP, #0x10
    // 0x69d0fc: b               #0x69d108
    // 0x69d100: r0 = Instance_BoxConstraints
    //     0x69d100: add             x0, PP, #0x21, lsl #12  ; [pp+0x21610] Obj!BoxConstraints@b35351
    //     0x69d104: ldr             x0, [x0, #0x610]
    // 0x69d108: mov             x1, x0
    // 0x69d10c: ldr             x0, [fp, #0x20]
    // 0x69d110: LoadField: r2 = r0->field_17
    //     0x69d110: ldur            w2, [x0, #0x17]
    // 0x69d114: DecompressPointer r2
    //     0x69d114: add             x2, x2, HEAP, lsl #32
    // 0x69d118: cmp             w2, NULL
    // 0x69d11c: b.eq            #0x69d188
    // 0x69d120: LoadField: r3 = r0->field_1f
    //     0x69d120: ldur            w3, [x0, #0x1f]
    // 0x69d124: DecompressPointer r3
    //     0x69d124: add             x3, x3, HEAP, lsl #32
    // 0x69d128: cmp             w3, NULL
    // 0x69d12c: b.eq            #0x69d188
    // 0x69d130: ldr             x4, [fp, #0x18]
    // 0x69d134: LoadField: d0 = r4->field_f
    //     0x69d134: ldur            d0, [x4, #0xf]
    // 0x69d138: LoadField: d1 = r3->field_7
    //     0x69d138: ldur            d1, [x3, #7]
    // 0x69d13c: fsub            d2, d0, d1
    // 0x69d140: LoadField: d0 = r2->field_7
    //     0x69d140: ldur            d0, [x2, #7]
    // 0x69d144: fsub            d1, d2, d0
    // 0x69d148: r2 = inline_Allocate_Double()
    //     0x69d148: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x69d14c: add             x2, x2, #0x10
    //     0x69d150: cmp             x3, x2
    //     0x69d154: b.ls            #0x69d448
    //     0x69d158: str             x2, [THR, #0x60]  ; THR::top
    //     0x69d15c: sub             x2, x2, #0xf
    //     0x69d160: mov             x3, #0xd108
    //     0x69d164: movk            x3, #3, lsl #16
    //     0x69d168: stur            x3, [x2, #-1]
    // 0x69d16c: StoreField: r2->field_7 = d1
    //     0x69d16c: stur            d1, [x2, #7]
    // 0x69d170: stp             x2, x1, [SP, #-0x10]!
    // 0x69d174: r4 = const [0, 0x2, 0x2, 0x1, height, 0x1, null]
    //     0x69d174: add             x4, PP, #0x21, lsl #12  ; [pp+0x21620] List(7) [0, 0x2, 0x2, 0x1, "height", 0x1, Null]
    //     0x69d178: ldr             x4, [x4, #0x620]
    // 0x69d17c: r0 = tighten()
    //     0x69d17c: bl              #0x590b84  ; [package:flutter/src/rendering/box.dart] BoxConstraints::tighten
    // 0x69d180: add             SP, SP, #0x10
    // 0x69d184: b               #0x69d1b8
    // 0x69d188: ldr             x0, [fp, #0x20]
    // 0x69d18c: LoadField: r2 = r0->field_2b
    //     0x69d18c: ldur            w2, [x0, #0x2b]
    // 0x69d190: DecompressPointer r2
    //     0x69d190: add             x2, x2, HEAP, lsl #32
    // 0x69d194: cmp             w2, NULL
    // 0x69d198: b.eq            #0x69d1b4
    // 0x69d19c: stp             x2, x1, [SP, #-0x10]!
    // 0x69d1a0: r4 = const [0, 0x2, 0x2, 0x1, height, 0x1, null]
    //     0x69d1a0: add             x4, PP, #0x21, lsl #12  ; [pp+0x21620] List(7) [0, 0x2, 0x2, 0x1, "height", 0x1, Null]
    //     0x69d1a4: ldr             x4, [x4, #0x620]
    // 0x69d1a8: r0 = tighten()
    //     0x69d1a8: bl              #0x590b84  ; [package:flutter/src/rendering/box.dart] BoxConstraints::tighten
    // 0x69d1ac: add             SP, SP, #0x10
    // 0x69d1b0: b               #0x69d1b8
    // 0x69d1b4: mov             x0, x1
    // 0x69d1b8: ldr             x2, [fp, #0x28]
    // 0x69d1bc: ldr             x1, [fp, #0x20]
    // 0x69d1c0: r3 = LoadClassIdInstr(r2)
    //     0x69d1c0: ldur            x3, [x2, #-1]
    //     0x69d1c4: ubfx            x3, x3, #0xc, #0x14
    // 0x69d1c8: stp             x0, x2, [SP, #-0x10]!
    // 0x69d1cc: r16 = true
    //     0x69d1cc: add             x16, NULL, #0x20  ; true
    // 0x69d1d0: SaveReg r16
    //     0x69d1d0: str             x16, [SP, #-8]!
    // 0x69d1d4: mov             x0, x3
    // 0x69d1d8: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x69d1d8: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x69d1dc: ldr             x4, [x4, #0x1c8]
    // 0x69d1e0: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x69d1e0: mov             x17, #0xcdfb
    //     0x69d1e4: add             lr, x0, x17
    //     0x69d1e8: ldr             lr, [x21, lr, lsl #3]
    //     0x69d1ec: blr             lr
    // 0x69d1f0: add             SP, SP, #0x18
    // 0x69d1f4: ldr             x0, [fp, #0x20]
    // 0x69d1f8: LoadField: r1 = r0->field_23
    //     0x69d1f8: ldur            w1, [x0, #0x23]
    // 0x69d1fc: DecompressPointer r1
    //     0x69d1fc: add             x1, x1, HEAP, lsl #32
    // 0x69d200: cmp             w1, NULL
    // 0x69d204: b.eq            #0x69d214
    // 0x69d208: LoadField: d0 = r1->field_7
    //     0x69d208: ldur            d0, [x1, #7]
    // 0x69d20c: mov             v1.16b, v0.16b
    // 0x69d210: b               #0x69d294
    // 0x69d214: LoadField: r1 = r0->field_1b
    //     0x69d214: ldur            w1, [x0, #0x1b]
    // 0x69d218: DecompressPointer r1
    //     0x69d218: add             x1, x1, HEAP, lsl #32
    // 0x69d21c: cmp             w1, NULL
    // 0x69d220: b.eq            #0x69d258
    // 0x69d224: ldr             x2, [fp, #0x28]
    // 0x69d228: ldr             x3, [fp, #0x18]
    // 0x69d22c: LoadField: d0 = r3->field_7
    //     0x69d22c: ldur            d0, [x3, #7]
    // 0x69d230: LoadField: d1 = r1->field_7
    //     0x69d230: ldur            d1, [x1, #7]
    // 0x69d234: fsub            d2, d0, d1
    // 0x69d238: LoadField: r1 = r2->field_57
    //     0x69d238: ldur            w1, [x2, #0x57]
    // 0x69d23c: DecompressPointer r1
    //     0x69d23c: add             x1, x1, HEAP, lsl #32
    // 0x69d240: cmp             w1, NULL
    // 0x69d244: b.eq            #0x69d46c
    // 0x69d248: LoadField: d0 = r1->field_7
    //     0x69d248: ldur            d0, [x1, #7]
    // 0x69d24c: fsub            d1, d2, d0
    // 0x69d250: mov             v0.16b, v1.16b
    // 0x69d254: b               #0x69d290
    // 0x69d258: ldr             x2, [fp, #0x28]
    // 0x69d25c: ldr             x3, [fp, #0x18]
    // 0x69d260: LoadField: r1 = r2->field_57
    //     0x69d260: ldur            w1, [x2, #0x57]
    // 0x69d264: DecompressPointer r1
    //     0x69d264: add             x1, x1, HEAP, lsl #32
    // 0x69d268: cmp             w1, NULL
    // 0x69d26c: b.eq            #0x69d470
    // 0x69d270: stp             x1, x3, [SP, #-0x10]!
    // 0x69d274: r0 = -()
    //     0x69d274: bl              #0x50e344  ; [dart:ui] Size::-
    // 0x69d278: add             SP, SP, #0x10
    // 0x69d27c: ldr             x16, [fp, #0x10]
    // 0x69d280: stp             x0, x16, [SP, #-0x10]!
    // 0x69d284: r0 = alongOffset()
    //     0x69d284: bl              #0x626350  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0x69d288: add             SP, SP, #0x10
    // 0x69d28c: LoadField: d0 = r0->field_7
    //     0x69d28c: ldur            d0, [x0, #7]
    // 0x69d290: mov             v1.16b, v0.16b
    // 0x69d294: d0 = 0.000000
    //     0x69d294: eor             v0.16b, v0.16b, v0.16b
    // 0x69d298: stur            d1, [fp, #-0x10]
    // 0x69d29c: fcmp            d1, d0
    // 0x69d2a0: b.vs            #0x69d2b4
    // 0x69d2a4: b.ge            #0x69d2b4
    // 0x69d2a8: ldr             x0, [fp, #0x28]
    // 0x69d2ac: ldr             x1, [fp, #0x18]
    // 0x69d2b0: b               #0x69d2e4
    // 0x69d2b4: ldr             x0, [fp, #0x28]
    // 0x69d2b8: ldr             x1, [fp, #0x18]
    // 0x69d2bc: LoadField: r2 = r0->field_57
    //     0x69d2bc: ldur            w2, [x0, #0x57]
    // 0x69d2c0: DecompressPointer r2
    //     0x69d2c0: add             x2, x2, HEAP, lsl #32
    // 0x69d2c4: cmp             w2, NULL
    // 0x69d2c8: b.eq            #0x69d474
    // 0x69d2cc: LoadField: d2 = r2->field_7
    //     0x69d2cc: ldur            d2, [x2, #7]
    // 0x69d2d0: fadd            d3, d1, d2
    // 0x69d2d4: LoadField: d2 = r1->field_7
    //     0x69d2d4: ldur            d2, [x1, #7]
    // 0x69d2d8: fcmp            d3, d2
    // 0x69d2dc: b.vs            #0x69d2ec
    // 0x69d2e0: b.le            #0x69d2ec
    // 0x69d2e4: r3 = true
    //     0x69d2e4: add             x3, NULL, #0x20  ; true
    // 0x69d2e8: b               #0x69d2f0
    // 0x69d2ec: r3 = false
    //     0x69d2ec: add             x3, NULL, #0x30  ; false
    // 0x69d2f0: ldr             x2, [fp, #0x20]
    // 0x69d2f4: stur            x3, [fp, #-8]
    // 0x69d2f8: LoadField: r4 = r2->field_17
    //     0x69d2f8: ldur            w4, [x2, #0x17]
    // 0x69d2fc: DecompressPointer r4
    //     0x69d2fc: add             x4, x4, HEAP, lsl #32
    // 0x69d300: cmp             w4, NULL
    // 0x69d304: b.eq            #0x69d314
    // 0x69d308: LoadField: d2 = r4->field_7
    //     0x69d308: ldur            d2, [x4, #7]
    // 0x69d30c: mov             v1.16b, v2.16b
    // 0x69d310: b               #0x69d388
    // 0x69d314: LoadField: r4 = r2->field_1f
    //     0x69d314: ldur            w4, [x2, #0x1f]
    // 0x69d318: DecompressPointer r4
    //     0x69d318: add             x4, x4, HEAP, lsl #32
    // 0x69d31c: cmp             w4, NULL
    // 0x69d320: b.eq            #0x69d350
    // 0x69d324: LoadField: d2 = r1->field_f
    //     0x69d324: ldur            d2, [x1, #0xf]
    // 0x69d328: LoadField: d3 = r4->field_7
    //     0x69d328: ldur            d3, [x4, #7]
    // 0x69d32c: fsub            d4, d2, d3
    // 0x69d330: LoadField: r4 = r0->field_57
    //     0x69d330: ldur            w4, [x0, #0x57]
    // 0x69d334: DecompressPointer r4
    //     0x69d334: add             x4, x4, HEAP, lsl #32
    // 0x69d338: cmp             w4, NULL
    // 0x69d33c: b.eq            #0x69d478
    // 0x69d340: LoadField: d2 = r4->field_f
    //     0x69d340: ldur            d2, [x4, #0xf]
    // 0x69d344: fsub            d3, d4, d2
    // 0x69d348: mov             v0.16b, v3.16b
    // 0x69d34c: b               #0x69d380
    // 0x69d350: LoadField: r4 = r0->field_57
    //     0x69d350: ldur            w4, [x0, #0x57]
    // 0x69d354: DecompressPointer r4
    //     0x69d354: add             x4, x4, HEAP, lsl #32
    // 0x69d358: cmp             w4, NULL
    // 0x69d35c: b.eq            #0x69d47c
    // 0x69d360: stp             x4, x1, [SP, #-0x10]!
    // 0x69d364: r0 = -()
    //     0x69d364: bl              #0x50e344  ; [dart:ui] Size::-
    // 0x69d368: add             SP, SP, #0x10
    // 0x69d36c: ldr             x16, [fp, #0x10]
    // 0x69d370: stp             x0, x16, [SP, #-0x10]!
    // 0x69d374: r0 = alongOffset()
    //     0x69d374: bl              #0x626350  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0x69d378: add             SP, SP, #0x10
    // 0x69d37c: LoadField: d0 = r0->field_f
    //     0x69d37c: ldur            d0, [x0, #0xf]
    // 0x69d380: mov             v1.16b, v0.16b
    // 0x69d384: d0 = 0.000000
    //     0x69d384: eor             v0.16b, v0.16b, v0.16b
    // 0x69d388: stur            d1, [fp, #-0x18]
    // 0x69d38c: fcmp            d1, d0
    // 0x69d390: b.vs            #0x69d398
    // 0x69d394: b.lt            #0x69d3c8
    // 0x69d398: ldr             x0, [fp, #0x28]
    // 0x69d39c: ldr             x1, [fp, #0x18]
    // 0x69d3a0: LoadField: r2 = r0->field_57
    //     0x69d3a0: ldur            w2, [x0, #0x57]
    // 0x69d3a4: DecompressPointer r2
    //     0x69d3a4: add             x2, x2, HEAP, lsl #32
    // 0x69d3a8: cmp             w2, NULL
    // 0x69d3ac: b.eq            #0x69d480
    // 0x69d3b0: LoadField: d0 = r2->field_f
    //     0x69d3b0: ldur            d0, [x2, #0xf]
    // 0x69d3b4: fadd            d2, d1, d0
    // 0x69d3b8: LoadField: d0 = r1->field_f
    //     0x69d3b8: ldur            d0, [x1, #0xf]
    // 0x69d3bc: fcmp            d2, d0
    // 0x69d3c0: b.vs            #0x69d3d0
    // 0x69d3c4: b.le            #0x69d3d0
    // 0x69d3c8: r1 = true
    //     0x69d3c8: add             x1, NULL, #0x20  ; true
    // 0x69d3cc: b               #0x69d3d4
    // 0x69d3d0: ldur            x1, [fp, #-8]
    // 0x69d3d4: ldr             x0, [fp, #0x20]
    // 0x69d3d8: ldur            d0, [fp, #-0x10]
    // 0x69d3dc: stur            x1, [fp, #-8]
    // 0x69d3e0: r0 = Offset()
    //     0x69d3e0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x69d3e4: ldur            d0, [fp, #-0x10]
    // 0x69d3e8: StoreField: r0->field_7 = d0
    //     0x69d3e8: stur            d0, [x0, #7]
    // 0x69d3ec: ldur            d0, [fp, #-0x18]
    // 0x69d3f0: StoreField: r0->field_f = d0
    //     0x69d3f0: stur            d0, [x0, #0xf]
    // 0x69d3f4: ldr             x1, [fp, #0x20]
    // 0x69d3f8: StoreField: r1->field_7 = r0
    //     0x69d3f8: stur            w0, [x1, #7]
    //     0x69d3fc: ldurb           w16, [x1, #-1]
    //     0x69d400: ldurb           w17, [x0, #-1]
    //     0x69d404: and             x16, x17, x16, lsr #2
    //     0x69d408: tst             x16, HEAP, lsr #32
    //     0x69d40c: b.eq            #0x69d414
    //     0x69d410: bl              #0xd6826c
    // 0x69d414: ldur            x0, [fp, #-8]
    // 0x69d418: LeaveFrame
    //     0x69d418: mov             SP, fp
    //     0x69d41c: ldp             fp, lr, [SP], #0x10
    // 0x69d420: ret
    //     0x69d420: ret             
    // 0x69d424: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69d424: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69d428: b               #0x69d044
    // 0x69d42c: SaveReg d1
    //     0x69d42c: str             q1, [SP, #-0x10]!
    // 0x69d430: stp             x0, x3, [SP, #-0x10]!
    // 0x69d434: r0 = AllocateDouble()
    //     0x69d434: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x69d438: mov             x1, x0
    // 0x69d43c: ldp             x0, x3, [SP], #0x10
    // 0x69d440: RestoreReg d1
    //     0x69d440: ldr             q1, [SP], #0x10
    // 0x69d444: b               #0x69d0a4
    // 0x69d448: SaveReg d1
    //     0x69d448: str             q1, [SP, #-0x10]!
    // 0x69d44c: stp             x1, x4, [SP, #-0x10]!
    // 0x69d450: SaveReg r0
    //     0x69d450: str             x0, [SP, #-8]!
    // 0x69d454: r0 = AllocateDouble()
    //     0x69d454: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x69d458: mov             x2, x0
    // 0x69d45c: RestoreReg r0
    //     0x69d45c: ldr             x0, [SP], #8
    // 0x69d460: ldp             x1, x4, [SP], #0x10
    // 0x69d464: RestoreReg d1
    //     0x69d464: ldr             q1, [SP], #0x10
    // 0x69d468: b               #0x69d16c
    // 0x69d46c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x69d46c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x69d470: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69d470: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69d474: r0 = NullCastErrorSharedWithFPURegs()
    //     0x69d474: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x69d478: r0 = NullCastErrorSharedWithFPURegs()
    //     0x69d478: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x69d47c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x69d47c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x69d480: r0 = NullCastErrorSharedWithFPURegs()
    //     0x69d480: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _computeSize(/* No info */) {
    // ** addr: 0x69d484, size: 0x410
    // 0x69d484: EnterFrame
    //     0x69d484: stp             fp, lr, [SP, #-0x10]!
    //     0x69d488: mov             fp, SP
    // 0x69d48c: AllocStack(0x40)
    //     0x69d48c: sub             SP, SP, #0x40
    // 0x69d490: CheckStackOverflow
    //     0x69d490: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x69d494: cmp             SP, x16
    //     0x69d498: b.ls            #0x69d880
    // 0x69d49c: ldr             x16, [fp, #0x20]
    // 0x69d4a0: SaveReg r16
    //     0x69d4a0: str             x16, [SP, #-8]!
    // 0x69d4a4: r0 = _resolve()
    //     0x69d4a4: bl              #0x69d8f8  ; [package:flutter/src/rendering/stack.dart] RenderStack::_resolve
    // 0x69d4a8: add             SP, SP, #8
    // 0x69d4ac: ldr             x0, [fp, #0x20]
    // 0x69d4b0: LoadField: r1 = r0->field_5f
    //     0x69d4b0: ldur            x1, [x0, #0x5f]
    // 0x69d4b4: cbnz            x1, #0x69d570
    // 0x69d4b8: ldr             x16, [fp, #0x18]
    // 0x69d4bc: SaveReg r16
    //     0x69d4bc: str             x16, [SP, #-8]!
    // 0x69d4c0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x69d4c0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x69d4c4: r0 = constrainWidth()
    //     0x69d4c4: bl              #0x62bc8c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0x69d4c8: add             SP, SP, #8
    // 0x69d4cc: stur            d0, [fp, #-0x28]
    // 0x69d4d0: ldr             x16, [fp, #0x18]
    // 0x69d4d4: SaveReg r16
    //     0x69d4d4: str             x16, [SP, #-8]!
    // 0x69d4d8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x69d4d8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x69d4dc: r0 = constrainHeight()
    //     0x69d4dc: bl              #0x62bc00  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0x69d4e0: add             SP, SP, #8
    // 0x69d4e4: stur            d0, [fp, #-0x30]
    // 0x69d4e8: r0 = Size()
    //     0x69d4e8: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x69d4ec: ldur            d0, [fp, #-0x28]
    // 0x69d4f0: StoreField: r0->field_7 = d0
    //     0x69d4f0: stur            d0, [x0, #7]
    // 0x69d4f4: ldur            d0, [fp, #-0x30]
    // 0x69d4f8: StoreField: r0->field_f = d0
    //     0x69d4f8: stur            d0, [x0, #0xf]
    // 0x69d4fc: SaveReg r0
    //     0x69d4fc: str             x0, [SP, #-8]!
    // 0x69d500: r0 = isFinite()
    //     0x69d500: bl              #0x69d894  ; [dart:ui] OffsetBase::isFinite
    // 0x69d504: add             SP, SP, #8
    // 0x69d508: tbnz            w0, #4, #0x69d554
    // 0x69d50c: ldr             x16, [fp, #0x18]
    // 0x69d510: SaveReg r16
    //     0x69d510: str             x16, [SP, #-8]!
    // 0x69d514: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x69d514: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x69d518: r0 = constrainWidth()
    //     0x69d518: bl              #0x62bc8c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0x69d51c: add             SP, SP, #8
    // 0x69d520: stur            d0, [fp, #-0x28]
    // 0x69d524: ldr             x16, [fp, #0x18]
    // 0x69d528: SaveReg r16
    //     0x69d528: str             x16, [SP, #-8]!
    // 0x69d52c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x69d52c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x69d530: r0 = constrainHeight()
    //     0x69d530: bl              #0x62bc00  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0x69d534: add             SP, SP, #8
    // 0x69d538: stur            d0, [fp, #-0x30]
    // 0x69d53c: r0 = Size()
    //     0x69d53c: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x69d540: ldur            d0, [fp, #-0x28]
    // 0x69d544: StoreField: r0->field_7 = d0
    //     0x69d544: stur            d0, [x0, #7]
    // 0x69d548: ldur            d0, [fp, #-0x30]
    // 0x69d54c: StoreField: r0->field_f = d0
    //     0x69d54c: stur            d0, [x0, #0xf]
    // 0x69d550: b               #0x69d564
    // 0x69d554: ldr             x16, [fp, #0x18]
    // 0x69d558: SaveReg r16
    //     0x69d558: str             x16, [SP, #-8]!
    // 0x69d55c: r0 = smallest()
    //     0x69d55c: bl              #0x62bd18  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0x69d560: add             SP, SP, #8
    // 0x69d564: LeaveFrame
    //     0x69d564: mov             SP, fp
    //     0x69d568: ldp             fp, lr, [SP], #0x10
    // 0x69d56c: ret
    //     0x69d56c: ret             
    // 0x69d570: ldr             x1, [fp, #0x18]
    // 0x69d574: LoadField: d0 = r1->field_7
    //     0x69d574: ldur            d0, [x1, #7]
    // 0x69d578: stur            d0, [fp, #-0x30]
    // 0x69d57c: LoadField: d1 = r1->field_17
    //     0x69d57c: ldur            d1, [x1, #0x17]
    // 0x69d580: stur            d1, [fp, #-0x28]
    // 0x69d584: LoadField: r2 = r0->field_7f
    //     0x69d584: ldur            w2, [x0, #0x7f]
    // 0x69d588: DecompressPointer r2
    //     0x69d588: add             x2, x2, HEAP, lsl #32
    // 0x69d58c: LoadField: r3 = r2->field_7
    //     0x69d58c: ldur            x3, [x2, #7]
    // 0x69d590: cmp             x3, #1
    // 0x69d594: b.gt            #0x69d608
    // 0x69d598: cmp             x3, #0
    // 0x69d59c: b.gt            #0x69d5b4
    // 0x69d5a0: SaveReg r1
    //     0x69d5a0: str             x1, [SP, #-8]!
    // 0x69d5a4: r0 = loosen()
    //     0x69d5a4: bl              #0x68f088  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0x69d5a8: add             SP, SP, #8
    // 0x69d5ac: mov             x3, x0
    // 0x69d5b0: b               #0x69d60c
    // 0x69d5b4: ldr             x16, [fp, #0x18]
    // 0x69d5b8: SaveReg r16
    //     0x69d5b8: str             x16, [SP, #-8]!
    // 0x69d5bc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x69d5bc: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x69d5c0: r0 = constrainWidth()
    //     0x69d5c0: bl              #0x62bc8c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0x69d5c4: add             SP, SP, #8
    // 0x69d5c8: stur            d0, [fp, #-0x38]
    // 0x69d5cc: ldr             x16, [fp, #0x18]
    // 0x69d5d0: SaveReg r16
    //     0x69d5d0: str             x16, [SP, #-8]!
    // 0x69d5d4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x69d5d4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x69d5d8: r0 = constrainHeight()
    //     0x69d5d8: bl              #0x62bc00  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0x69d5dc: add             SP, SP, #8
    // 0x69d5e0: stur            d0, [fp, #-0x40]
    // 0x69d5e4: r0 = BoxConstraints()
    //     0x69d5e4: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x69d5e8: ldur            d0, [fp, #-0x38]
    // 0x69d5ec: StoreField: r0->field_7 = d0
    //     0x69d5ec: stur            d0, [x0, #7]
    // 0x69d5f0: StoreField: r0->field_f = d0
    //     0x69d5f0: stur            d0, [x0, #0xf]
    // 0x69d5f4: ldur            d0, [fp, #-0x40]
    // 0x69d5f8: StoreField: r0->field_17 = d0
    //     0x69d5f8: stur            d0, [x0, #0x17]
    // 0x69d5fc: StoreField: r0->field_1f = d0
    //     0x69d5fc: stur            d0, [x0, #0x1f]
    // 0x69d600: mov             x3, x0
    // 0x69d604: b               #0x69d60c
    // 0x69d608: ldr             x3, [fp, #0x18]
    // 0x69d60c: ldr             x0, [fp, #0x20]
    // 0x69d610: stur            x3, [fp, #-0x20]
    // 0x69d614: LoadField: r1 = r0->field_67
    //     0x69d614: ldur            w1, [x0, #0x67]
    // 0x69d618: DecompressPointer r1
    //     0x69d618: add             x1, x1, HEAP, lsl #32
    // 0x69d61c: ldur            d1, [fp, #-0x30]
    // 0x69d620: ldur            d0, [fp, #-0x28]
    // 0x69d624: mov             x4, x1
    // 0x69d628: r5 = false
    //     0x69d628: add             x5, NULL, #0x30  ; false
    // 0x69d62c: stur            x5, [fp, #-0x10]
    // 0x69d630: stur            x4, [fp, #-0x18]
    // 0x69d634: stur            d1, [fp, #-0x28]
    // 0x69d638: stur            d0, [fp, #-0x30]
    // 0x69d63c: CheckStackOverflow
    //     0x69d63c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x69d640: cmp             SP, x16
    //     0x69d644: b.ls            #0x69d888
    // 0x69d648: cmp             w4, NULL
    // 0x69d64c: b.eq            #0x69d80c
    // 0x69d650: LoadField: r6 = r4->field_17
    //     0x69d650: ldur            w6, [x4, #0x17]
    // 0x69d654: DecompressPointer r6
    //     0x69d654: add             x6, x6, HEAP, lsl #32
    // 0x69d658: stur            x6, [fp, #-8]
    // 0x69d65c: cmp             w6, NULL
    // 0x69d660: b.eq            #0x69d890
    // 0x69d664: mov             x0, x6
    // 0x69d668: r2 = Null
    //     0x69d668: mov             x2, NULL
    // 0x69d66c: r1 = Null
    //     0x69d66c: mov             x1, NULL
    // 0x69d670: r4 = LoadClassIdInstr(r0)
    //     0x69d670: ldur            x4, [x0, #-1]
    //     0x69d674: ubfx            x4, x4, #0xc, #0x14
    // 0x69d678: cmp             x4, #0x807
    // 0x69d67c: b.eq            #0x69d694
    // 0x69d680: r8 = StackParentData<RenderBox>
    //     0x69d680: add             x8, PP, #0x21, lsl #12  ; [pp+0x215a0] Type: StackParentData<RenderBox>
    //     0x69d684: ldr             x8, [x8, #0x5a0]
    // 0x69d688: r3 = Null
    //     0x69d688: add             x3, PP, #0x21, lsl #12  ; [pp+0x21a60] Null
    //     0x69d68c: ldr             x3, [x3, #0xa60]
    // 0x69d690: r0 = DefaultTypeTest()
    //     0x69d690: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x69d694: ldur            x1, [fp, #-8]
    // 0x69d698: LoadField: r0 = r1->field_17
    //     0x69d698: ldur            w0, [x1, #0x17]
    // 0x69d69c: DecompressPointer r0
    //     0x69d69c: add             x0, x0, HEAP, lsl #32
    // 0x69d6a0: cmp             w0, NULL
    // 0x69d6a4: b.ne            #0x69d6e8
    // 0x69d6a8: LoadField: r0 = r1->field_1b
    //     0x69d6a8: ldur            w0, [x1, #0x1b]
    // 0x69d6ac: DecompressPointer r0
    //     0x69d6ac: add             x0, x0, HEAP, lsl #32
    // 0x69d6b0: cmp             w0, NULL
    // 0x69d6b4: b.ne            #0x69d6e8
    // 0x69d6b8: LoadField: r0 = r1->field_1f
    //     0x69d6b8: ldur            w0, [x1, #0x1f]
    // 0x69d6bc: DecompressPointer r0
    //     0x69d6bc: add             x0, x0, HEAP, lsl #32
    // 0x69d6c0: cmp             w0, NULL
    // 0x69d6c4: b.ne            #0x69d6e8
    // 0x69d6c8: LoadField: r0 = r1->field_23
    //     0x69d6c8: ldur            w0, [x1, #0x23]
    // 0x69d6cc: DecompressPointer r0
    //     0x69d6cc: add             x0, x0, HEAP, lsl #32
    // 0x69d6d0: cmp             w0, NULL
    // 0x69d6d4: b.ne            #0x69d6e8
    // 0x69d6d8: LoadField: r0 = r1->field_27
    //     0x69d6d8: ldur            w0, [x1, #0x27]
    // 0x69d6dc: DecompressPointer r0
    //     0x69d6dc: add             x0, x0, HEAP, lsl #32
    // 0x69d6e0: cmp             w0, NULL
    // 0x69d6e4: b.eq            #0x69d6f8
    // 0x69d6e8: ldur            d2, [fp, #-0x28]
    // 0x69d6ec: ldur            d0, [fp, #-0x30]
    // 0x69d6f0: d3 = 0.000000
    //     0x69d6f0: eor             v3.16b, v3.16b, v3.16b
    // 0x69d6f4: b               #0x69d7f0
    // 0x69d6f8: LoadField: r0 = r1->field_2b
    //     0x69d6f8: ldur            w0, [x1, #0x2b]
    // 0x69d6fc: DecompressPointer r0
    //     0x69d6fc: add             x0, x0, HEAP, lsl #32
    // 0x69d700: cmp             w0, NULL
    // 0x69d704: b.ne            #0x69d7e4
    // 0x69d708: ldur            d0, [fp, #-0x28]
    // 0x69d70c: ldr             x16, [fp, #0x10]
    // 0x69d710: ldur            lr, [fp, #-0x18]
    // 0x69d714: stp             lr, x16, [SP, #-0x10]!
    // 0x69d718: ldur            x16, [fp, #-0x20]
    // 0x69d71c: SaveReg r16
    //     0x69d71c: str             x16, [SP, #-8]!
    // 0x69d720: ldr             x0, [fp, #0x10]
    // 0x69d724: ClosureCall
    //     0x69d724: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x69d728: ldur            x2, [x0, #0x1f]
    //     0x69d72c: blr             x2
    // 0x69d730: add             SP, SP, #0x18
    // 0x69d734: LoadField: d1 = r0->field_7
    //     0x69d734: ldur            d1, [x0, #7]
    // 0x69d738: ldur            d2, [fp, #-0x28]
    // 0x69d73c: fcmp            d2, d1
    // 0x69d740: b.vs            #0x69d754
    // 0x69d744: b.le            #0x69d754
    // 0x69d748: mov             v1.16b, v2.16b
    // 0x69d74c: d3 = 0.000000
    //     0x69d74c: eor             v3.16b, v3.16b, v3.16b
    // 0x69d750: b               #0x69d790
    // 0x69d754: fcmp            d2, d1
    // 0x69d758: b.vs            #0x69d768
    // 0x69d75c: b.ge            #0x69d768
    // 0x69d760: d3 = 0.000000
    //     0x69d760: eor             v3.16b, v3.16b, v3.16b
    // 0x69d764: b               #0x69d790
    // 0x69d768: d3 = 0.000000
    //     0x69d768: eor             v3.16b, v3.16b, v3.16b
    // 0x69d76c: fcmp            d2, d3
    // 0x69d770: b.vs            #0x69d784
    // 0x69d774: b.ne            #0x69d784
    // 0x69d778: fadd            d4, d2, d1
    // 0x69d77c: mov             v1.16b, v4.16b
    // 0x69d780: b               #0x69d790
    // 0x69d784: fcmp            d1, d1
    // 0x69d788: b.vs            #0x69d790
    // 0x69d78c: mov             v1.16b, v2.16b
    // 0x69d790: ldur            d0, [fp, #-0x30]
    // 0x69d794: LoadField: d2 = r0->field_f
    //     0x69d794: ldur            d2, [x0, #0xf]
    // 0x69d798: fcmp            d0, d2
    // 0x69d79c: b.vs            #0x69d7a4
    // 0x69d7a0: b.gt            #0x69d7dc
    // 0x69d7a4: fcmp            d0, d2
    // 0x69d7a8: b.vs            #0x69d7b8
    // 0x69d7ac: b.ge            #0x69d7b8
    // 0x69d7b0: mov             v0.16b, v2.16b
    // 0x69d7b4: b               #0x69d7dc
    // 0x69d7b8: fcmp            d0, d3
    // 0x69d7bc: b.vs            #0x69d7d0
    // 0x69d7c0: b.ne            #0x69d7d0
    // 0x69d7c4: fadd            d4, d0, d2
    // 0x69d7c8: mov             v0.16b, v4.16b
    // 0x69d7cc: b               #0x69d7dc
    // 0x69d7d0: fcmp            d2, d2
    // 0x69d7d4: b.vc            #0x69d7dc
    // 0x69d7d8: mov             v0.16b, v2.16b
    // 0x69d7dc: r5 = true
    //     0x69d7dc: add             x5, NULL, #0x20  ; true
    // 0x69d7e0: b               #0x69d7f8
    // 0x69d7e4: ldur            d2, [fp, #-0x28]
    // 0x69d7e8: ldur            d0, [fp, #-0x30]
    // 0x69d7ec: d3 = 0.000000
    //     0x69d7ec: eor             v3.16b, v3.16b, v3.16b
    // 0x69d7f0: ldur            x5, [fp, #-0x10]
    // 0x69d7f4: mov             v1.16b, v2.16b
    // 0x69d7f8: ldur            x0, [fp, #-8]
    // 0x69d7fc: LoadField: r4 = r0->field_13
    //     0x69d7fc: ldur            w4, [x0, #0x13]
    // 0x69d800: DecompressPointer r4
    //     0x69d800: add             x4, x4, HEAP, lsl #32
    // 0x69d804: ldur            x3, [fp, #-0x20]
    // 0x69d808: b               #0x69d62c
    // 0x69d80c: mov             x0, x5
    // 0x69d810: mov             v2.16b, v1.16b
    // 0x69d814: tbnz            w0, #4, #0x69d830
    // 0x69d818: r0 = Size()
    //     0x69d818: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x69d81c: ldur            d0, [fp, #-0x28]
    // 0x69d820: StoreField: r0->field_7 = d0
    //     0x69d820: stur            d0, [x0, #7]
    // 0x69d824: ldur            d0, [fp, #-0x30]
    // 0x69d828: StoreField: r0->field_f = d0
    //     0x69d828: stur            d0, [x0, #0xf]
    // 0x69d82c: b               #0x69d874
    // 0x69d830: ldr             x16, [fp, #0x18]
    // 0x69d834: SaveReg r16
    //     0x69d834: str             x16, [SP, #-8]!
    // 0x69d838: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x69d838: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x69d83c: r0 = constrainWidth()
    //     0x69d83c: bl              #0x62bc8c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0x69d840: add             SP, SP, #8
    // 0x69d844: stur            d0, [fp, #-0x28]
    // 0x69d848: ldr             x16, [fp, #0x18]
    // 0x69d84c: SaveReg r16
    //     0x69d84c: str             x16, [SP, #-8]!
    // 0x69d850: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x69d850: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x69d854: r0 = constrainHeight()
    //     0x69d854: bl              #0x62bc00  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0x69d858: add             SP, SP, #8
    // 0x69d85c: stur            d0, [fp, #-0x30]
    // 0x69d860: r0 = Size()
    //     0x69d860: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x69d864: ldur            d0, [fp, #-0x28]
    // 0x69d868: StoreField: r0->field_7 = d0
    //     0x69d868: stur            d0, [x0, #7]
    // 0x69d86c: ldur            d0, [fp, #-0x30]
    // 0x69d870: StoreField: r0->field_f = d0
    //     0x69d870: stur            d0, [x0, #0xf]
    // 0x69d874: LeaveFrame
    //     0x69d874: mov             SP, fp
    //     0x69d878: ldp             fp, lr, [SP], #0x10
    // 0x69d87c: ret
    //     0x69d87c: ret             
    // 0x69d880: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69d880: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69d884: b               #0x69d49c
    // 0x69d888: r0 = StackOverflowSharedWithFPURegs()
    //     0x69d888: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x69d88c: b               #0x69d648
    // 0x69d890: r0 = NullCastErrorSharedWithFPURegs()
    //     0x69d890: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _resolve(/* No info */) {
    // ** addr: 0x69d8f8, size: 0x19c
    // 0x69d8f8: EnterFrame
    //     0x69d8f8: stp             fp, lr, [SP, #-0x10]!
    //     0x69d8fc: mov             fp, SP
    // 0x69d900: AllocStack(0x10)
    //     0x69d900: sub             SP, SP, #0x10
    // 0x69d904: ldr             x0, [fp, #0x10]
    // 0x69d908: LoadField: r1 = r0->field_73
    //     0x69d908: ldur            w1, [x0, #0x73]
    // 0x69d90c: DecompressPointer r1
    //     0x69d90c: add             x1, x1, HEAP, lsl #32
    // 0x69d910: cmp             w1, NULL
    // 0x69d914: b.eq            #0x69d928
    // 0x69d918: r0 = Null
    //     0x69d918: mov             x0, NULL
    // 0x69d91c: LeaveFrame
    //     0x69d91c: mov             SP, fp
    //     0x69d920: ldp             fp, lr, [SP], #0x10
    // 0x69d924: ret
    //     0x69d924: ret             
    // 0x69d928: LoadField: r1 = r0->field_77
    //     0x69d928: ldur            w1, [x0, #0x77]
    // 0x69d92c: DecompressPointer r1
    //     0x69d92c: add             x1, x1, HEAP, lsl #32
    // 0x69d930: LoadField: r2 = r0->field_7b
    //     0x69d930: ldur            w2, [x0, #0x7b]
    // 0x69d934: DecompressPointer r2
    //     0x69d934: add             x2, x2, HEAP, lsl #32
    // 0x69d938: r3 = LoadClassIdInstr(r1)
    //     0x69d938: ldur            x3, [x1, #-1]
    //     0x69d93c: ubfx            x3, x3, #0xc, #0x14
    // 0x69d940: lsl             x3, x3, #1
    // 0x69d944: r17 = 4240
    //     0x69d944: mov             x17, #0x1090
    // 0x69d948: cmp             w3, w17
    // 0x69d94c: b.gt            #0x69d96c
    // 0x69d950: r17 = 4238
    //     0x69d950: mov             x17, #0x108e
    // 0x69d954: cmp             w3, w17
    // 0x69d958: b.lt            #0x69d96c
    // 0x69d95c: mov             x16, x0
    // 0x69d960: mov             x0, x1
    // 0x69d964: mov             x1, x16
    // 0x69d968: b               #0x69da60
    // 0x69d96c: r17 = 4234
    //     0x69d96c: mov             x17, #0x108a
    // 0x69d970: cmp             w3, w17
    // 0x69d974: b.ne            #0x69d9f4
    // 0x69d978: cmp             w2, NULL
    // 0x69d97c: b.eq            #0x69da8c
    // 0x69d980: LoadField: r3 = r2->field_7
    //     0x69d980: ldur            x3, [x2, #7]
    // 0x69d984: cmp             x3, #0
    // 0x69d988: b.gt            #0x69d9c0
    // 0x69d98c: LoadField: d0 = r1->field_7
    //     0x69d98c: ldur            d0, [x1, #7]
    // 0x69d990: LoadField: d1 = r1->field_f
    //     0x69d990: ldur            d1, [x1, #0xf]
    // 0x69d994: fsub            d2, d0, d1
    // 0x69d998: stur            d2, [fp, #-0x10]
    // 0x69d99c: LoadField: d0 = r1->field_17
    //     0x69d99c: ldur            d0, [x1, #0x17]
    // 0x69d9a0: stur            d0, [fp, #-8]
    // 0x69d9a4: r0 = Alignment()
    //     0x69d9a4: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x69d9a8: ldur            d0, [fp, #-0x10]
    // 0x69d9ac: StoreField: r0->field_7 = d0
    //     0x69d9ac: stur            d0, [x0, #7]
    // 0x69d9b0: ldur            d0, [fp, #-8]
    // 0x69d9b4: StoreField: r0->field_f = d0
    //     0x69d9b4: stur            d0, [x0, #0xf]
    // 0x69d9b8: ldr             x1, [fp, #0x10]
    // 0x69d9bc: b               #0x69da60
    // 0x69d9c0: LoadField: d0 = r1->field_7
    //     0x69d9c0: ldur            d0, [x1, #7]
    // 0x69d9c4: LoadField: d1 = r1->field_f
    //     0x69d9c4: ldur            d1, [x1, #0xf]
    // 0x69d9c8: fadd            d2, d0, d1
    // 0x69d9cc: stur            d2, [fp, #-0x10]
    // 0x69d9d0: LoadField: d0 = r1->field_17
    //     0x69d9d0: ldur            d0, [x1, #0x17]
    // 0x69d9d4: stur            d0, [fp, #-8]
    // 0x69d9d8: r0 = Alignment()
    //     0x69d9d8: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x69d9dc: ldur            d0, [fp, #-0x10]
    // 0x69d9e0: StoreField: r0->field_7 = d0
    //     0x69d9e0: stur            d0, [x0, #7]
    // 0x69d9e4: ldur            d0, [fp, #-8]
    // 0x69d9e8: StoreField: r0->field_f = d0
    //     0x69d9e8: stur            d0, [x0, #0xf]
    // 0x69d9ec: ldr             x1, [fp, #0x10]
    // 0x69d9f0: b               #0x69da60
    // 0x69d9f4: cmp             w2, NULL
    // 0x69d9f8: b.eq            #0x69da90
    // 0x69d9fc: LoadField: r0 = r2->field_7
    //     0x69d9fc: ldur            x0, [x2, #7]
    // 0x69da00: cmp             x0, #0
    // 0x69da04: b.gt            #0x69da38
    // 0x69da08: LoadField: d0 = r1->field_7
    //     0x69da08: ldur            d0, [x1, #7]
    // 0x69da0c: fneg            d1, d0
    // 0x69da10: stur            d1, [fp, #-0x10]
    // 0x69da14: LoadField: d0 = r1->field_f
    //     0x69da14: ldur            d0, [x1, #0xf]
    // 0x69da18: stur            d0, [fp, #-8]
    // 0x69da1c: r0 = Alignment()
    //     0x69da1c: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x69da20: ldur            d0, [fp, #-0x10]
    // 0x69da24: StoreField: r0->field_7 = d0
    //     0x69da24: stur            d0, [x0, #7]
    // 0x69da28: ldur            d0, [fp, #-8]
    // 0x69da2c: StoreField: r0->field_f = d0
    //     0x69da2c: stur            d0, [x0, #0xf]
    // 0x69da30: ldr             x1, [fp, #0x10]
    // 0x69da34: b               #0x69da60
    // 0x69da38: LoadField: d0 = r1->field_7
    //     0x69da38: ldur            d0, [x1, #7]
    // 0x69da3c: stur            d0, [fp, #-0x10]
    // 0x69da40: LoadField: d1 = r1->field_f
    //     0x69da40: ldur            d1, [x1, #0xf]
    // 0x69da44: stur            d1, [fp, #-8]
    // 0x69da48: r0 = Alignment()
    //     0x69da48: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x69da4c: ldur            d0, [fp, #-0x10]
    // 0x69da50: StoreField: r0->field_7 = d0
    //     0x69da50: stur            d0, [x0, #7]
    // 0x69da54: ldur            d0, [fp, #-8]
    // 0x69da58: StoreField: r0->field_f = d0
    //     0x69da58: stur            d0, [x0, #0xf]
    // 0x69da5c: ldr             x1, [fp, #0x10]
    // 0x69da60: StoreField: r1->field_73 = r0
    //     0x69da60: stur            w0, [x1, #0x73]
    //     0x69da64: ldurb           w16, [x1, #-1]
    //     0x69da68: ldurb           w17, [x0, #-1]
    //     0x69da6c: and             x16, x17, x16, lsr #2
    //     0x69da70: tst             x16, HEAP, lsr #32
    //     0x69da74: b.eq            #0x69da7c
    //     0x69da78: bl              #0xd6826c
    // 0x69da7c: r0 = Null
    //     0x69da7c: mov             x0, NULL
    // 0x69da80: LeaveFrame
    //     0x69da80: mov             SP, fp
    //     0x69da84: ldp             fp, lr, [SP], #0x10
    // 0x69da88: ret
    //     0x69da88: ret             
    // 0x69da8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69da8c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69da90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69da90: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0x6e06f8, size: 0x80
    // 0x6e06f8: EnterFrame
    //     0x6e06f8: stp             fp, lr, [SP, #-0x10]!
    //     0x6e06fc: mov             fp, SP
    // 0x6e0700: CheckStackOverflow
    //     0x6e0700: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e0704: cmp             SP, x16
    //     0x6e0708: b.ls            #0x6e0770
    // 0x6e070c: ldr             x1, [fp, #0x18]
    // 0x6e0710: LoadField: r0 = r1->field_7b
    //     0x6e0710: ldur            w0, [x1, #0x7b]
    // 0x6e0714: DecompressPointer r0
    //     0x6e0714: add             x0, x0, HEAP, lsl #32
    // 0x6e0718: ldr             x2, [fp, #0x10]
    // 0x6e071c: cmp             w0, w2
    // 0x6e0720: b.ne            #0x6e0734
    // 0x6e0724: r0 = Null
    //     0x6e0724: mov             x0, NULL
    // 0x6e0728: LeaveFrame
    //     0x6e0728: mov             SP, fp
    //     0x6e072c: ldp             fp, lr, [SP], #0x10
    // 0x6e0730: ret
    //     0x6e0730: ret             
    // 0x6e0734: mov             x0, x2
    // 0x6e0738: StoreField: r1->field_7b = r0
    //     0x6e0738: stur            w0, [x1, #0x7b]
    //     0x6e073c: ldurb           w16, [x1, #-1]
    //     0x6e0740: ldurb           w17, [x0, #-1]
    //     0x6e0744: and             x16, x17, x16, lsr #2
    //     0x6e0748: tst             x16, HEAP, lsr #32
    //     0x6e074c: b.eq            #0x6e0754
    //     0x6e0750: bl              #0xd6826c
    // 0x6e0754: SaveReg r1
    //     0x6e0754: str             x1, [SP, #-8]!
    // 0x6e0758: r0 = _markNeedResolution()
    //     0x6e0758: bl              #0x6e0778  ; [package:flutter/src/rendering/stack.dart] RenderStack::_markNeedResolution
    // 0x6e075c: add             SP, SP, #8
    // 0x6e0760: r0 = Null
    //     0x6e0760: mov             x0, NULL
    // 0x6e0764: LeaveFrame
    //     0x6e0764: mov             SP, fp
    //     0x6e0768: ldp             fp, lr, [SP], #0x10
    // 0x6e076c: ret
    //     0x6e076c: ret             
    // 0x6e0770: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e0770: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e0774: b               #0x6e070c
  }
  _ _markNeedResolution(/* No info */) {
    // ** addr: 0x6e0778, size: 0x40
    // 0x6e0778: EnterFrame
    //     0x6e0778: stp             fp, lr, [SP, #-0x10]!
    //     0x6e077c: mov             fp, SP
    // 0x6e0780: CheckStackOverflow
    //     0x6e0780: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e0784: cmp             SP, x16
    //     0x6e0788: b.ls            #0x6e07b0
    // 0x6e078c: ldr             x0, [fp, #0x10]
    // 0x6e0790: StoreField: r0->field_73 = rNULL
    //     0x6e0790: stur            NULL, [x0, #0x73]
    // 0x6e0794: SaveReg r0
    //     0x6e0794: str             x0, [SP, #-8]!
    // 0x6e0798: r0 = markNeedsLayout()
    //     0x6e0798: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6e079c: add             SP, SP, #8
    // 0x6e07a0: r0 = Null
    //     0x6e07a0: mov             x0, NULL
    // 0x6e07a4: LeaveFrame
    //     0x6e07a4: mov             SP, fp
    //     0x6e07a8: ldp             fp, lr, [SP], #0x10
    // 0x6e07ac: ret
    //     0x6e07ac: ret             
    // 0x6e07b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e07b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e07b4: b               #0x6e078c
  }
  set _ alignment=(/* No info */) {
    // ** addr: 0x6e07b8, size: 0x8c
    // 0x6e07b8: EnterFrame
    //     0x6e07b8: stp             fp, lr, [SP, #-0x10]!
    //     0x6e07bc: mov             fp, SP
    // 0x6e07c0: CheckStackOverflow
    //     0x6e07c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e07c4: cmp             SP, x16
    //     0x6e07c8: b.ls            #0x6e083c
    // 0x6e07cc: ldr             x0, [fp, #0x18]
    // 0x6e07d0: LoadField: r1 = r0->field_77
    //     0x6e07d0: ldur            w1, [x0, #0x77]
    // 0x6e07d4: DecompressPointer r1
    //     0x6e07d4: add             x1, x1, HEAP, lsl #32
    // 0x6e07d8: ldr             x16, [fp, #0x10]
    // 0x6e07dc: stp             x16, x1, [SP, #-0x10]!
    // 0x6e07e0: r0 = ==()
    //     0x6e07e0: bl              #0xc9c720  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::==
    // 0x6e07e4: add             SP, SP, #0x10
    // 0x6e07e8: tbnz            w0, #4, #0x6e07fc
    // 0x6e07ec: r0 = Null
    //     0x6e07ec: mov             x0, NULL
    // 0x6e07f0: LeaveFrame
    //     0x6e07f0: mov             SP, fp
    //     0x6e07f4: ldp             fp, lr, [SP], #0x10
    // 0x6e07f8: ret
    //     0x6e07f8: ret             
    // 0x6e07fc: ldr             x1, [fp, #0x18]
    // 0x6e0800: ldr             x0, [fp, #0x10]
    // 0x6e0804: StoreField: r1->field_77 = r0
    //     0x6e0804: stur            w0, [x1, #0x77]
    //     0x6e0808: ldurb           w16, [x1, #-1]
    //     0x6e080c: ldurb           w17, [x0, #-1]
    //     0x6e0810: and             x16, x17, x16, lsr #2
    //     0x6e0814: tst             x16, HEAP, lsr #32
    //     0x6e0818: b.eq            #0x6e0820
    //     0x6e081c: bl              #0xd6826c
    // 0x6e0820: SaveReg r1
    //     0x6e0820: str             x1, [SP, #-8]!
    // 0x6e0824: r0 = _markNeedResolution()
    //     0x6e0824: bl              #0x6e0778  ; [package:flutter/src/rendering/stack.dart] RenderStack::_markNeedResolution
    // 0x6e0828: add             SP, SP, #8
    // 0x6e082c: r0 = Null
    //     0x6e082c: mov             x0, NULL
    // 0x6e0830: LeaveFrame
    //     0x6e0830: mov             SP, fp
    //     0x6e0834: ldp             fp, lr, [SP], #0x10
    // 0x6e0838: ret
    //     0x6e0838: ret             
    // 0x6e083c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e083c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e0840: b               #0x6e07cc
  }
  set _ clipBehavior=(/* No info */) {
    // ** addr: 0x6e0844, size: 0x80
    // 0x6e0844: EnterFrame
    //     0x6e0844: stp             fp, lr, [SP, #-0x10]!
    //     0x6e0848: mov             fp, SP
    // 0x6e084c: CheckStackOverflow
    //     0x6e084c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e0850: cmp             SP, x16
    //     0x6e0854: b.ls            #0x6e08bc
    // 0x6e0858: ldr             x1, [fp, #0x18]
    // 0x6e085c: LoadField: r0 = r1->field_83
    //     0x6e085c: ldur            w0, [x1, #0x83]
    // 0x6e0860: DecompressPointer r0
    //     0x6e0860: add             x0, x0, HEAP, lsl #32
    // 0x6e0864: ldr             x2, [fp, #0x10]
    // 0x6e0868: cmp             w2, w0
    // 0x6e086c: b.eq            #0x6e08ac
    // 0x6e0870: mov             x0, x2
    // 0x6e0874: StoreField: r1->field_83 = r0
    //     0x6e0874: stur            w0, [x1, #0x83]
    //     0x6e0878: ldurb           w16, [x1, #-1]
    //     0x6e087c: ldurb           w17, [x0, #-1]
    //     0x6e0880: and             x16, x17, x16, lsr #2
    //     0x6e0884: tst             x16, HEAP, lsr #32
    //     0x6e0888: b.eq            #0x6e0890
    //     0x6e088c: bl              #0xd6826c
    // 0x6e0890: SaveReg r1
    //     0x6e0890: str             x1, [SP, #-8]!
    // 0x6e0894: r0 = markNeedsPaint()
    //     0x6e0894: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6e0898: add             SP, SP, #8
    // 0x6e089c: ldr             x16, [fp, #0x18]
    // 0x6e08a0: SaveReg r16
    //     0x6e08a0: str             x16, [SP, #-8]!
    // 0x6e08a4: r0 = markNeedsSemanticsUpdate()
    //     0x6e08a4: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6e08a8: add             SP, SP, #8
    // 0x6e08ac: r0 = Null
    //     0x6e08ac: mov             x0, NULL
    // 0x6e08b0: LeaveFrame
    //     0x6e08b0: mov             SP, fp
    //     0x6e08b4: ldp             fp, lr, [SP], #0x10
    // 0x6e08b8: ret
    //     0x6e08b8: ret             
    // 0x6e08bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e08bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e08c0: b               #0x6e0858
  }
  _ RenderStack(/* No info */) {
    // ** addr: 0x6f38bc, size: 0xf8
    // 0x6f38bc: EnterFrame
    //     0x6f38bc: stp             fp, lr, [SP, #-0x10]!
    //     0x6f38c0: mov             fp, SP
    // 0x6f38c4: r0 = false
    //     0x6f38c4: add             x0, NULL, #0x30  ; false
    // 0x6f38c8: CheckStackOverflow
    //     0x6f38c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f38cc: cmp             SP, x16
    //     0x6f38d0: b.ls            #0x6f39ac
    // 0x6f38d4: ldr             x2, [fp, #0x30]
    // 0x6f38d8: StoreField: r2->field_6f = r0
    //     0x6f38d8: stur            w0, [x2, #0x6f]
    // 0x6f38dc: r1 = <ClipRectLayer>
    //     0x6f38dc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15388] TypeArguments: <ClipRectLayer>
    //     0x6f38e0: ldr             x1, [x1, #0x388]
    // 0x6f38e4: r0 = LayerHandle()
    //     0x6f38e4: bl              #0x5bbf28  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x6f38e8: ldr             x1, [fp, #0x30]
    // 0x6f38ec: StoreField: r1->field_87 = r0
    //     0x6f38ec: stur            w0, [x1, #0x87]
    //     0x6f38f0: ldurb           w16, [x1, #-1]
    //     0x6f38f4: ldurb           w17, [x0, #-1]
    //     0x6f38f8: and             x16, x17, x16, lsr #2
    //     0x6f38fc: tst             x16, HEAP, lsr #32
    //     0x6f3900: b.eq            #0x6f3908
    //     0x6f3904: bl              #0xd6826c
    // 0x6f3908: ldr             x0, [fp, #0x28]
    // 0x6f390c: StoreField: r1->field_77 = r0
    //     0x6f390c: stur            w0, [x1, #0x77]
    //     0x6f3910: ldurb           w16, [x1, #-1]
    //     0x6f3914: ldurb           w17, [x0, #-1]
    //     0x6f3918: and             x16, x17, x16, lsr #2
    //     0x6f391c: tst             x16, HEAP, lsr #32
    //     0x6f3920: b.eq            #0x6f3928
    //     0x6f3924: bl              #0xd6826c
    // 0x6f3928: ldr             x0, [fp, #0x10]
    // 0x6f392c: StoreField: r1->field_7b = r0
    //     0x6f392c: stur            w0, [x1, #0x7b]
    //     0x6f3930: ldurb           w16, [x1, #-1]
    //     0x6f3934: ldurb           w17, [x0, #-1]
    //     0x6f3938: and             x16, x17, x16, lsr #2
    //     0x6f393c: tst             x16, HEAP, lsr #32
    //     0x6f3940: b.eq            #0x6f3948
    //     0x6f3944: bl              #0xd6826c
    // 0x6f3948: ldr             x0, [fp, #0x18]
    // 0x6f394c: StoreField: r1->field_7f = r0
    //     0x6f394c: stur            w0, [x1, #0x7f]
    //     0x6f3950: ldurb           w16, [x1, #-1]
    //     0x6f3954: ldurb           w17, [x0, #-1]
    //     0x6f3958: and             x16, x17, x16, lsr #2
    //     0x6f395c: tst             x16, HEAP, lsr #32
    //     0x6f3960: b.eq            #0x6f3968
    //     0x6f3964: bl              #0xd6826c
    // 0x6f3968: ldr             x0, [fp, #0x20]
    // 0x6f396c: StoreField: r1->field_83 = r0
    //     0x6f396c: stur            w0, [x1, #0x83]
    //     0x6f3970: ldurb           w16, [x1, #-1]
    //     0x6f3974: ldurb           w17, [x0, #-1]
    //     0x6f3978: and             x16, x17, x16, lsr #2
    //     0x6f397c: tst             x16, HEAP, lsr #32
    //     0x6f3980: b.eq            #0x6f3988
    //     0x6f3984: bl              #0xd6826c
    // 0x6f3988: r0 = 0
    //     0x6f3988: mov             x0, #0
    // 0x6f398c: StoreField: r1->field_5f = r0
    //     0x6f398c: stur            x0, [x1, #0x5f]
    // 0x6f3990: SaveReg r1
    //     0x6f3990: str             x1, [SP, #-8]!
    // 0x6f3994: r0 = RenderObject()
    //     0x6f3994: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6f3998: add             SP, SP, #8
    // 0x6f399c: r0 = Null
    //     0x6f399c: mov             x0, NULL
    // 0x6f39a0: LeaveFrame
    //     0x6f39a0: mov             SP, fp
    //     0x6f39a4: ldp             fp, lr, [SP], #0x10
    // 0x6f39a8: ret
    //     0x6f39a8: ret             
    // 0x6f39ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f39ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f39b0: b               #0x6f38d4
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5ed3c, size: 0x48
    // 0xa5ed3c: EnterFrame
    //     0xa5ed3c: stp             fp, lr, [SP, #-0x10]!
    //     0xa5ed40: mov             fp, SP
    // 0xa5ed44: CheckStackOverflow
    //     0xa5ed44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5ed48: cmp             SP, x16
    //     0xa5ed4c: b.ls            #0xa5ed7c
    // 0xa5ed50: ldr             x16, [fp, #0x18]
    // 0xa5ed54: ldr             lr, [fp, #0x10]
    // 0xa5ed58: stp             lr, x16, [SP, #-0x10]!
    // 0xa5ed5c: r16 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xa5ed5c: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cf88] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7fe6e1e33c20)
    //     0xa5ed60: ldr             x16, [x16, #0xf88]
    // 0xa5ed64: SaveReg r16
    //     0xa5ed64: str             x16, [SP, #-8]!
    // 0xa5ed68: r0 = _computeSize()
    //     0xa5ed68: bl              #0x69d484  ; [package:flutter/src/rendering/stack.dart] RenderStack::_computeSize
    // 0xa5ed6c: add             SP, SP, #0x18
    // 0xa5ed70: LeaveFrame
    //     0xa5ed70: mov             SP, fp
    //     0xa5ed74: ldp             fp, lr, [SP], #0x10
    // 0xa5ed78: ret
    //     0xa5ed78: ret             
    // 0xa5ed7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5ed7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5ed80: b               #0xa5ed50
  }
}

// class id: 2428, size: 0x94, field offset: 0x8c
class RenderIndexedStack extends RenderStack {

  _ hitTestChildren(/* No info */) {
    // ** addr: 0x6299bc, size: 0xfc
    // 0x6299bc: EnterFrame
    //     0x6299bc: stp             fp, lr, [SP, #-0x10]!
    //     0x6299c0: mov             fp, SP
    // 0x6299c4: AllocStack(0x18)
    //     0x6299c4: sub             SP, SP, #0x18
    // 0x6299c8: CheckStackOverflow
    //     0x6299c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6299cc: cmp             SP, x16
    //     0x6299d0: b.ls            #0x629aac
    // 0x6299d4: ldr             x0, [fp, #0x20]
    // 0x6299d8: LoadField: r1 = r0->field_67
    //     0x6299d8: ldur            w1, [x0, #0x67]
    // 0x6299dc: DecompressPointer r1
    //     0x6299dc: add             x1, x1, HEAP, lsl #32
    // 0x6299e0: cmp             w1, NULL
    // 0x6299e4: b.ne            #0x6299f8
    // 0x6299e8: r0 = false
    //     0x6299e8: add             x0, NULL, #0x30  ; false
    // 0x6299ec: LeaveFrame
    //     0x6299ec: mov             SP, fp
    //     0x6299f0: ldp             fp, lr, [SP], #0x10
    // 0x6299f4: ret
    //     0x6299f4: ret             
    // 0x6299f8: SaveReg r0
    //     0x6299f8: str             x0, [SP, #-8]!
    // 0x6299fc: r0 = _childAtIndex()
    //     0x6299fc: bl              #0x629ab8  ; [package:flutter/src/rendering/stack.dart] RenderIndexedStack::_childAtIndex
    // 0x629a00: add             SP, SP, #8
    // 0x629a04: stur            x0, [fp, #-8]
    // 0x629a08: r1 = 1
    //     0x629a08: mov             x1, #1
    // 0x629a0c: r0 = AllocateContext()
    //     0x629a0c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x629a10: mov             x3, x0
    // 0x629a14: ldur            x0, [fp, #-8]
    // 0x629a18: stur            x3, [fp, #-0x18]
    // 0x629a1c: StoreField: r3->field_f = r0
    //     0x629a1c: stur            w0, [x3, #0xf]
    // 0x629a20: LoadField: r4 = r0->field_17
    //     0x629a20: ldur            w4, [x0, #0x17]
    // 0x629a24: DecompressPointer r4
    //     0x629a24: add             x4, x4, HEAP, lsl #32
    // 0x629a28: stur            x4, [fp, #-0x10]
    // 0x629a2c: cmp             w4, NULL
    // 0x629a30: b.eq            #0x629ab4
    // 0x629a34: mov             x0, x4
    // 0x629a38: r2 = Null
    //     0x629a38: mov             x2, NULL
    // 0x629a3c: r1 = Null
    //     0x629a3c: mov             x1, NULL
    // 0x629a40: r4 = LoadClassIdInstr(r0)
    //     0x629a40: ldur            x4, [x0, #-1]
    //     0x629a44: ubfx            x4, x4, #0xc, #0x14
    // 0x629a48: cmp             x4, #0x807
    // 0x629a4c: b.eq            #0x629a64
    // 0x629a50: r8 = StackParentData<RenderBox>
    //     0x629a50: add             x8, PP, #0x21, lsl #12  ; [pp+0x215a0] Type: StackParentData<RenderBox>
    //     0x629a54: ldr             x8, [x8, #0x5a0]
    // 0x629a58: r3 = Null
    //     0x629a58: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2d568] Null
    //     0x629a5c: ldr             x3, [x3, #0x568]
    // 0x629a60: r0 = DefaultTypeTest()
    //     0x629a60: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x629a64: ldur            x0, [fp, #-0x10]
    // 0x629a68: LoadField: r3 = r0->field_7
    //     0x629a68: ldur            w3, [x0, #7]
    // 0x629a6c: DecompressPointer r3
    //     0x629a6c: add             x3, x3, HEAP, lsl #32
    // 0x629a70: ldur            x2, [fp, #-0x18]
    // 0x629a74: stur            x3, [fp, #-8]
    // 0x629a78: r1 = Function '<anonymous closure>':.
    //     0x629a78: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2d578] AnonymousClosure: (0x624650), in [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::hitTestChildren (0x6275b4)
    //     0x629a7c: ldr             x1, [x1, #0x578]
    // 0x629a80: r0 = AllocateClosure()
    //     0x629a80: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x629a84: ldr             x16, [fp, #0x18]
    // 0x629a88: stp             x0, x16, [SP, #-0x10]!
    // 0x629a8c: ldur            x16, [fp, #-8]
    // 0x629a90: ldr             lr, [fp, #0x10]
    // 0x629a94: stp             lr, x16, [SP, #-0x10]!
    // 0x629a98: r0 = addWithPaintOffset()
    //     0x629a98: bl              #0x622820  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithPaintOffset
    // 0x629a9c: add             SP, SP, #0x20
    // 0x629aa0: LeaveFrame
    //     0x629aa0: mov             SP, fp
    //     0x629aa4: ldp             fp, lr, [SP], #0x10
    // 0x629aa8: ret
    //     0x629aa8: ret             
    // 0x629aac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x629aac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x629ab0: b               #0x6299d4
    // 0x629ab4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x629ab4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _childAtIndex(/* No info */) {
    // ** addr: 0x629ab8, size: 0xcc
    // 0x629ab8: EnterFrame
    //     0x629ab8: stp             fp, lr, [SP, #-0x10]!
    //     0x629abc: mov             fp, SP
    // 0x629ac0: AllocStack(0x18)
    //     0x629ac0: sub             SP, SP, #0x18
    // 0x629ac4: ldr             x0, [fp, #0x10]
    // 0x629ac8: LoadField: r1 = r0->field_67
    //     0x629ac8: ldur            w1, [x0, #0x67]
    // 0x629acc: DecompressPointer r1
    //     0x629acc: add             x1, x1, HEAP, lsl #32
    // 0x629ad0: LoadField: r3 = r0->field_8b
    //     0x629ad0: ldur            x3, [x0, #0x8b]
    // 0x629ad4: stur            x3, [fp, #-0x18]
    // 0x629ad8: mov             x0, x1
    // 0x629adc: r4 = 0
    //     0x629adc: mov             x4, #0
    // 0x629ae0: stur            x4, [fp, #-0x10]
    // 0x629ae4: CheckStackOverflow
    //     0x629ae4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x629ae8: cmp             SP, x16
    //     0x629aec: b.ls            #0x629b74
    // 0x629af0: cmp             w0, NULL
    // 0x629af4: b.eq            #0x629b60
    // 0x629af8: cmp             x4, x3
    // 0x629afc: b.ge            #0x629b60
    // 0x629b00: LoadField: r5 = r0->field_17
    //     0x629b00: ldur            w5, [x0, #0x17]
    // 0x629b04: DecompressPointer r5
    //     0x629b04: add             x5, x5, HEAP, lsl #32
    // 0x629b08: stur            x5, [fp, #-8]
    // 0x629b0c: cmp             w5, NULL
    // 0x629b10: b.eq            #0x629b7c
    // 0x629b14: mov             x0, x5
    // 0x629b18: r2 = Null
    //     0x629b18: mov             x2, NULL
    // 0x629b1c: r1 = Null
    //     0x629b1c: mov             x1, NULL
    // 0x629b20: r4 = LoadClassIdInstr(r0)
    //     0x629b20: ldur            x4, [x0, #-1]
    //     0x629b24: ubfx            x4, x4, #0xc, #0x14
    // 0x629b28: cmp             x4, #0x807
    // 0x629b2c: b.eq            #0x629b44
    // 0x629b30: r8 = StackParentData<RenderBox>
    //     0x629b30: add             x8, PP, #0x21, lsl #12  ; [pp+0x215a0] Type: StackParentData<RenderBox>
    //     0x629b34: ldr             x8, [x8, #0x5a0]
    // 0x629b38: r3 = Null
    //     0x629b38: add             x3, PP, #0x21, lsl #12  ; [pp+0x21a10] Null
    //     0x629b3c: ldr             x3, [x3, #0xa10]
    // 0x629b40: r0 = DefaultTypeTest()
    //     0x629b40: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x629b44: ldur            x1, [fp, #-8]
    // 0x629b48: LoadField: r0 = r1->field_13
    //     0x629b48: ldur            w0, [x1, #0x13]
    // 0x629b4c: DecompressPointer r0
    //     0x629b4c: add             x0, x0, HEAP, lsl #32
    // 0x629b50: ldur            x1, [fp, #-0x10]
    // 0x629b54: add             x4, x1, #1
    // 0x629b58: ldur            x3, [fp, #-0x18]
    // 0x629b5c: b               #0x629ae0
    // 0x629b60: cmp             w0, NULL
    // 0x629b64: b.eq            #0x629b80
    // 0x629b68: LeaveFrame
    //     0x629b68: mov             SP, fp
    //     0x629b6c: ldp             fp, lr, [SP], #0x10
    // 0x629b70: ret
    //     0x629b70: ret             
    // 0x629b74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x629b74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x629b78: b               #0x629af0
    // 0x629b7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x629b7c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x629b80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x629b80: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void paintStack(dynamic, PaintingContext, Offset) {
    // ** addr: 0x66f46c, size: 0x54
    // 0x66f46c: EnterFrame
    //     0x66f46c: stp             fp, lr, [SP, #-0x10]!
    //     0x66f470: mov             fp, SP
    // 0x66f474: ldr             x0, [fp, #0x20]
    // 0x66f478: LoadField: r1 = r0->field_17
    //     0x66f478: ldur            w1, [x0, #0x17]
    // 0x66f47c: DecompressPointer r1
    //     0x66f47c: add             x1, x1, HEAP, lsl #32
    // 0x66f480: CheckStackOverflow
    //     0x66f480: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66f484: cmp             SP, x16
    //     0x66f488: b.ls            #0x66f4b8
    // 0x66f48c: LoadField: r0 = r1->field_f
    //     0x66f48c: ldur            w0, [x1, #0xf]
    // 0x66f490: DecompressPointer r0
    //     0x66f490: add             x0, x0, HEAP, lsl #32
    // 0x66f494: ldr             x16, [fp, #0x18]
    // 0x66f498: stp             x16, x0, [SP, #-0x10]!
    // 0x66f49c: ldr             x16, [fp, #0x10]
    // 0x66f4a0: SaveReg r16
    //     0x66f4a0: str             x16, [SP, #-8]!
    // 0x66f4a4: r0 = paintStack()
    //     0x66f4a4: bl              #0xcf1e3c  ; [package:flutter/src/rendering/stack.dart] RenderIndexedStack::paintStack
    // 0x66f4a8: add             SP, SP, #0x18
    // 0x66f4ac: LeaveFrame
    //     0x66f4ac: mov             SP, fp
    //     0x66f4b0: ldp             fp, lr, [SP], #0x10
    // 0x66f4b4: ret
    //     0x66f4b4: ret             
    // 0x66f4b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66f4b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66f4bc: b               #0x66f48c
  }
  _ visitChildrenForSemantics(/* No info */) {
    // ** addr: 0x676664, size: 0x68
    // 0x676664: EnterFrame
    //     0x676664: stp             fp, lr, [SP, #-0x10]!
    //     0x676668: mov             fp, SP
    // 0x67666c: CheckStackOverflow
    //     0x67666c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x676670: cmp             SP, x16
    //     0x676674: b.ls            #0x6766c4
    // 0x676678: ldr             x0, [fp, #0x18]
    // 0x67667c: LoadField: r1 = r0->field_67
    //     0x67667c: ldur            w1, [x0, #0x67]
    // 0x676680: DecompressPointer r1
    //     0x676680: add             x1, x1, HEAP, lsl #32
    // 0x676684: cmp             w1, NULL
    // 0x676688: b.eq            #0x6766b4
    // 0x67668c: SaveReg r0
    //     0x67668c: str             x0, [SP, #-8]!
    // 0x676690: r0 = _childAtIndex()
    //     0x676690: bl              #0x629ab8  ; [package:flutter/src/rendering/stack.dart] RenderIndexedStack::_childAtIndex
    // 0x676694: add             SP, SP, #8
    // 0x676698: ldr             x16, [fp, #0x10]
    // 0x67669c: stp             x0, x16, [SP, #-0x10]!
    // 0x6766a0: ldr             x0, [fp, #0x10]
    // 0x6766a4: ClosureCall
    //     0x6766a4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6766a8: ldur            x2, [x0, #0x1f]
    //     0x6766ac: blr             x2
    // 0x6766b0: add             SP, SP, #0x10
    // 0x6766b4: r0 = Null
    //     0x6766b4: mov             x0, NULL
    // 0x6766b8: LeaveFrame
    //     0x6766b8: mov             SP, fp
    //     0x6766bc: ldp             fp, lr, [SP], #0x10
    // 0x6766c0: ret
    //     0x6766c0: ret             
    // 0x6766c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6766c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6766c8: b               #0x676678
  }
  set _ index=(/* No info */) {
    // ** addr: 0x6e08c4, size: 0x50
    // 0x6e08c4: EnterFrame
    //     0x6e08c4: stp             fp, lr, [SP, #-0x10]!
    //     0x6e08c8: mov             fp, SP
    // 0x6e08cc: CheckStackOverflow
    //     0x6e08cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e08d0: cmp             SP, x16
    //     0x6e08d4: b.ls            #0x6e090c
    // 0x6e08d8: ldr             x0, [fp, #0x18]
    // 0x6e08dc: LoadField: r1 = r0->field_8b
    //     0x6e08dc: ldur            x1, [x0, #0x8b]
    // 0x6e08e0: ldr             x2, [fp, #0x10]
    // 0x6e08e4: cmp             x1, x2
    // 0x6e08e8: b.eq            #0x6e08fc
    // 0x6e08ec: StoreField: r0->field_8b = r2
    //     0x6e08ec: stur            x2, [x0, #0x8b]
    // 0x6e08f0: SaveReg r0
    //     0x6e08f0: str             x0, [SP, #-8]!
    // 0x6e08f4: r0 = markNeedsLayout()
    //     0x6e08f4: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6e08f8: add             SP, SP, #8
    // 0x6e08fc: r0 = Null
    //     0x6e08fc: mov             x0, NULL
    // 0x6e0900: LeaveFrame
    //     0x6e0900: mov             SP, fp
    //     0x6e0904: ldp             fp, lr, [SP], #0x10
    // 0x6e0908: ret
    //     0x6e0908: ret             
    // 0x6e090c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e090c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e0910: b               #0x6e08d8
  }
  _ paintStack(/* No info */) {
    // ** addr: 0xcf1e3c, size: 0xe4
    // 0xcf1e3c: EnterFrame
    //     0xcf1e3c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf1e40: mov             fp, SP
    // 0xcf1e44: AllocStack(0x10)
    //     0xcf1e44: sub             SP, SP, #0x10
    // 0xcf1e48: CheckStackOverflow
    //     0xcf1e48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf1e4c: cmp             SP, x16
    //     0xcf1e50: b.ls            #0xcf1f14
    // 0xcf1e54: ldr             x0, [fp, #0x20]
    // 0xcf1e58: LoadField: r1 = r0->field_67
    //     0xcf1e58: ldur            w1, [x0, #0x67]
    // 0xcf1e5c: DecompressPointer r1
    //     0xcf1e5c: add             x1, x1, HEAP, lsl #32
    // 0xcf1e60: cmp             w1, NULL
    // 0xcf1e64: b.ne            #0xcf1e78
    // 0xcf1e68: r0 = Null
    //     0xcf1e68: mov             x0, NULL
    // 0xcf1e6c: LeaveFrame
    //     0xcf1e6c: mov             SP, fp
    //     0xcf1e70: ldp             fp, lr, [SP], #0x10
    // 0xcf1e74: ret
    //     0xcf1e74: ret             
    // 0xcf1e78: SaveReg r0
    //     0xcf1e78: str             x0, [SP, #-8]!
    // 0xcf1e7c: r0 = _childAtIndex()
    //     0xcf1e7c: bl              #0x629ab8  ; [package:flutter/src/rendering/stack.dart] RenderIndexedStack::_childAtIndex
    // 0xcf1e80: add             SP, SP, #8
    // 0xcf1e84: mov             x3, x0
    // 0xcf1e88: stur            x3, [fp, #-0x10]
    // 0xcf1e8c: LoadField: r4 = r3->field_17
    //     0xcf1e8c: ldur            w4, [x3, #0x17]
    // 0xcf1e90: DecompressPointer r4
    //     0xcf1e90: add             x4, x4, HEAP, lsl #32
    // 0xcf1e94: stur            x4, [fp, #-8]
    // 0xcf1e98: cmp             w4, NULL
    // 0xcf1e9c: b.eq            #0xcf1f1c
    // 0xcf1ea0: mov             x0, x4
    // 0xcf1ea4: r2 = Null
    //     0xcf1ea4: mov             x2, NULL
    // 0xcf1ea8: r1 = Null
    //     0xcf1ea8: mov             x1, NULL
    // 0xcf1eac: r4 = LoadClassIdInstr(r0)
    //     0xcf1eac: ldur            x4, [x0, #-1]
    //     0xcf1eb0: ubfx            x4, x4, #0xc, #0x14
    // 0xcf1eb4: cmp             x4, #0x807
    // 0xcf1eb8: b.eq            #0xcf1ed0
    // 0xcf1ebc: r8 = StackParentData<RenderBox>
    //     0xcf1ebc: add             x8, PP, #0x21, lsl #12  ; [pp+0x215a0] Type: StackParentData<RenderBox>
    //     0xcf1ec0: ldr             x8, [x8, #0x5a0]
    // 0xcf1ec4: r3 = Null
    //     0xcf1ec4: add             x3, PP, #0x21, lsl #12  ; [pp+0x21a00] Null
    //     0xcf1ec8: ldr             x3, [x3, #0xa00]
    // 0xcf1ecc: r0 = DefaultTypeTest()
    //     0xcf1ecc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xcf1ed0: ldur            x0, [fp, #-8]
    // 0xcf1ed4: LoadField: r1 = r0->field_7
    //     0xcf1ed4: ldur            w1, [x0, #7]
    // 0xcf1ed8: DecompressPointer r1
    //     0xcf1ed8: add             x1, x1, HEAP, lsl #32
    // 0xcf1edc: ldr             x16, [fp, #0x10]
    // 0xcf1ee0: stp             x16, x1, [SP, #-0x10]!
    // 0xcf1ee4: r0 = +()
    //     0xcf1ee4: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0xcf1ee8: add             SP, SP, #0x10
    // 0xcf1eec: ldr             x16, [fp, #0x18]
    // 0xcf1ef0: ldur            lr, [fp, #-0x10]
    // 0xcf1ef4: stp             lr, x16, [SP, #-0x10]!
    // 0xcf1ef8: SaveReg r0
    //     0xcf1ef8: str             x0, [SP, #-8]!
    // 0xcf1efc: r0 = paintChild()
    //     0xcf1efc: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xcf1f00: add             SP, SP, #0x18
    // 0xcf1f04: r0 = Null
    //     0xcf1f04: mov             x0, NULL
    // 0xcf1f08: LeaveFrame
    //     0xcf1f08: mov             SP, fp
    //     0xcf1f0c: ldp             fp, lr, [SP], #0x10
    // 0xcf1f10: ret
    //     0xcf1f10: ret             
    // 0xcf1f14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf1f14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf1f18: b               #0xcf1e54
    // 0xcf1f1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcf1f1c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5910, size: 0x14, field offset: 0x14
enum StackFit extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16ff4, size: 0x5c
    // 0xb16ff4: EnterFrame
    //     0xb16ff4: stp             fp, lr, [SP, #-0x10]!
    //     0xb16ff8: mov             fp, SP
    // 0xb16ffc: CheckStackOverflow
    //     0xb16ffc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb17000: cmp             SP, x16
    //     0xb17004: b.ls            #0xb17048
    // 0xb17008: r1 = Null
    //     0xb17008: mov             x1, NULL
    // 0xb1700c: r2 = 4
    //     0xb1700c: mov             x2, #4
    // 0xb17010: r0 = AllocateArray()
    //     0xb17010: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb17014: r17 = "StackFit."
    //     0xb17014: add             x17, PP, #0x1c, lsl #12  ; [pp+0x1ce58] "StackFit."
    //     0xb17018: ldr             x17, [x17, #0xe58]
    // 0xb1701c: StoreField: r0->field_f = r17
    //     0xb1701c: stur            w17, [x0, #0xf]
    // 0xb17020: ldr             x1, [fp, #0x10]
    // 0xb17024: LoadField: r2 = r1->field_f
    //     0xb17024: ldur            w2, [x1, #0xf]
    // 0xb17028: DecompressPointer r2
    //     0xb17028: add             x2, x2, HEAP, lsl #32
    // 0xb1702c: StoreField: r0->field_13 = r2
    //     0xb1702c: stur            w2, [x0, #0x13]
    // 0xb17030: SaveReg r0
    //     0xb17030: str             x0, [SP, #-8]!
    // 0xb17034: r0 = _interpolate()
    //     0xb17034: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb17038: add             SP, SP, #8
    // 0xb1703c: LeaveFrame
    //     0xb1703c: mov             SP, fp
    //     0xb17040: ldp             fp, lr, [SP], #0x10
    // 0xb17044: ret
    //     0xb17044: ret             
    // 0xb17048: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb17048: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1704c: b               #0xb17008
  }
}

// lib: , url: package:flutter/src/rendering/table.dart

// class id: 1049429, size: 0x8
class :: {
}

// class id: 1985, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class TableColumnWidth extends Object {
}

// class id: 1986, size: 0x10, field offset: 0x8
//   const constructor, 
class FlexColumnWidth extends TableColumnWidth {

  _Double field_8;

  _ toString(/* No info */) {
    // ** addr: 0xae5f44, size: 0xa0
    // 0xae5f44: EnterFrame
    //     0xae5f44: stp             fp, lr, [SP, #-0x10]!
    //     0xae5f48: mov             fp, SP
    // 0xae5f4c: AllocStack(0x8)
    //     0xae5f4c: sub             SP, SP, #8
    // 0xae5f50: CheckStackOverflow
    //     0xae5f50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae5f54: cmp             SP, x16
    //     0xae5f58: b.ls            #0xae5fdc
    // 0xae5f5c: r1 = Null
    //     0xae5f5c: mov             x1, NULL
    // 0xae5f60: r2 = 8
    //     0xae5f60: mov             x2, #8
    // 0xae5f64: r0 = AllocateArray()
    //     0xae5f64: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae5f68: stur            x0, [fp, #-8]
    // 0xae5f6c: r17 = "FlexColumnWidth"
    //     0xae5f6c: add             x17, PP, #0x57, lsl #12  ; [pp+0x574d0] "FlexColumnWidth"
    //     0xae5f70: ldr             x17, [x17, #0x4d0]
    // 0xae5f74: StoreField: r0->field_f = r17
    //     0xae5f74: stur            w17, [x0, #0xf]
    // 0xae5f78: r17 = "("
    //     0xae5f78: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xae5f7c: StoreField: r0->field_13 = r17
    //     0xae5f7c: stur            w17, [x0, #0x13]
    // 0xae5f80: r16 = 1.000000
    //     0xae5f80: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xae5f84: SaveReg r16
    //     0xae5f84: str             x16, [SP, #-8]!
    // 0xae5f88: r0 = debugFormatDouble()
    //     0xae5f88: bl              #0xa77fb4  ; [package:flutter/src/foundation/debug.dart] ::debugFormatDouble
    // 0xae5f8c: add             SP, SP, #8
    // 0xae5f90: ldur            x1, [fp, #-8]
    // 0xae5f94: ArrayStore: r1[2] = r0  ; List_4
    //     0xae5f94: add             x25, x1, #0x17
    //     0xae5f98: str             w0, [x25]
    //     0xae5f9c: tbz             w0, #0, #0xae5fb8
    //     0xae5fa0: ldurb           w16, [x1, #-1]
    //     0xae5fa4: ldurb           w17, [x0, #-1]
    //     0xae5fa8: and             x16, x17, x16, lsr #2
    //     0xae5fac: tst             x16, HEAP, lsr #32
    //     0xae5fb0: b.eq            #0xae5fb8
    //     0xae5fb4: bl              #0xd67e5c
    // 0xae5fb8: ldur            x0, [fp, #-8]
    // 0xae5fbc: r17 = ")"
    //     0xae5fbc: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae5fc0: StoreField: r0->field_1b = r17
    //     0xae5fc0: stur            w17, [x0, #0x1b]
    // 0xae5fc4: SaveReg r0
    //     0xae5fc4: str             x0, [SP, #-8]!
    // 0xae5fc8: r0 = _interpolate()
    //     0xae5fc8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae5fcc: add             SP, SP, #8
    // 0xae5fd0: LeaveFrame
    //     0xae5fd0: mov             SP, fp
    //     0xae5fd4: ldp             fp, lr, [SP], #0x10
    // 0xae5fd8: ret
    //     0xae5fd8: ret             
    // 0xae5fdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae5fdc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae5fe0: b               #0xae5f5c
  }
}

// class id: 2048, size: 0x10, field offset: 0xc
class TableCellParentData extends BoxParentData {

  _ toString(/* No info */) {
    // ** addr: 0xae50f0, size: 0x7c
    // 0xae50f0: EnterFrame
    //     0xae50f0: stp             fp, lr, [SP, #-0x10]!
    //     0xae50f4: mov             fp, SP
    // 0xae50f8: AllocStack(0x8)
    //     0xae50f8: sub             SP, SP, #8
    // 0xae50fc: CheckStackOverflow
    //     0xae50fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae5100: cmp             SP, x16
    //     0xae5104: b.ls            #0xae5164
    // 0xae5108: ldr             x16, [fp, #0x10]
    // 0xae510c: SaveReg r16
    //     0xae510c: str             x16, [SP, #-8]!
    // 0xae5110: r0 = toString()
    //     0xae5110: bl              #0xae516c  ; [package:flutter/src/rendering/box.dart] BoxParentData::toString
    // 0xae5114: add             SP, SP, #8
    // 0xae5118: r1 = Null
    //     0xae5118: mov             x1, NULL
    // 0xae511c: r2 = 6
    //     0xae511c: mov             x2, #6
    // 0xae5120: stur            x0, [fp, #-8]
    // 0xae5124: r0 = AllocateArray()
    //     0xae5124: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae5128: mov             x1, x0
    // 0xae512c: ldur            x0, [fp, #-8]
    // 0xae5130: StoreField: r1->field_f = r0
    //     0xae5130: stur            w0, [x1, #0xf]
    // 0xae5134: r17 = "; "
    //     0xae5134: add             x17, PP, #0x1b, lsl #12  ; [pp+0x1bca8] "; "
    //     0xae5138: ldr             x17, [x17, #0xca8]
    // 0xae513c: StoreField: r1->field_13 = r17
    //     0xae513c: stur            w17, [x1, #0x13]
    // 0xae5140: r17 = "default vertical alignment"
    //     0xae5140: add             x17, PP, #0x57, lsl #12  ; [pp+0x57790] "default vertical alignment"
    //     0xae5144: ldr             x17, [x17, #0x790]
    // 0xae5148: StoreField: r1->field_17 = r17
    //     0xae5148: stur            w17, [x1, #0x17]
    // 0xae514c: SaveReg r1
    //     0xae514c: str             x1, [SP, #-8]!
    // 0xae5150: r0 = _interpolate()
    //     0xae5150: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae5154: add             SP, SP, #8
    // 0xae5158: LeaveFrame
    //     0xae5158: mov             SP, fp
    //     0xae515c: ldp             fp, lr, [SP], #0x10
    // 0xae5160: ret
    //     0xae5160: ret             
    // 0xae5164: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae5164: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae5168: b               #0xae5108
  }
}

// class id: 2423, size: 0xa8, field offset: 0x60
class RenderTable extends RenderBox {

  late double _tableWidth; // offset: 0xa4

  _ hitTestChildren(/* No info */) {
    // ** addr: 0x629edc, size: 0x1d4
    // 0x629edc: EnterFrame
    //     0x629edc: stp             fp, lr, [SP, #-0x10]!
    //     0x629ee0: mov             fp, SP
    // 0x629ee4: AllocStack(0x20)
    //     0x629ee4: sub             SP, SP, #0x20
    // 0x629ee8: CheckStackOverflow
    //     0x629ee8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x629eec: cmp             SP, x16
    //     0x629ef0: b.ls            #0x62a09c
    // 0x629ef4: ldr             x1, [fp, #0x20]
    // 0x629ef8: LoadField: r0 = r1->field_5f
    //     0x629ef8: ldur            w0, [x1, #0x5f]
    // 0x629efc: DecompressPointer r0
    //     0x629efc: add             x0, x0, HEAP, lsl #32
    // 0x629f00: r2 = LoadClassIdInstr(r0)
    //     0x629f00: ldur            x2, [x0, #-1]
    //     0x629f04: ubfx            x2, x2, #0xc, #0x14
    // 0x629f08: SaveReg r0
    //     0x629f08: str             x0, [SP, #-8]!
    // 0x629f0c: mov             x0, x2
    // 0x629f10: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x629f10: mov             x17, #0xb8ea
    //     0x629f14: add             lr, x0, x17
    //     0x629f18: ldr             lr, [x21, lr, lsl #3]
    //     0x629f1c: blr             lr
    // 0x629f20: add             SP, SP, #8
    // 0x629f24: r1 = LoadInt32Instr(r0)
    //     0x629f24: sbfx            x1, x0, #1, #0x1f
    // 0x629f28: sub             x0, x1, #1
    // 0x629f2c: mov             x3, x0
    // 0x629f30: ldr             x2, [fp, #0x20]
    // 0x629f34: stur            x3, [fp, #-8]
    // 0x629f38: CheckStackOverflow
    //     0x629f38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x629f3c: cmp             SP, x16
    //     0x629f40: b.ls            #0x62a0a4
    // 0x629f44: tbnz            x3, #0x3f, #0x62a08c
    // 0x629f48: LoadField: r4 = r2->field_5f
    //     0x629f48: ldur            w4, [x2, #0x5f]
    // 0x629f4c: DecompressPointer r4
    //     0x629f4c: add             x4, x4, HEAP, lsl #32
    // 0x629f50: r0 = BoxInt64Instr(r3)
    //     0x629f50: sbfiz           x0, x3, #1, #0x1f
    //     0x629f54: cmp             x3, x0, asr #1
    //     0x629f58: b.eq            #0x629f64
    //     0x629f5c: bl              #0xd69bb8
    //     0x629f60: stur            x3, [x0, #7]
    // 0x629f64: r1 = LoadClassIdInstr(r4)
    //     0x629f64: ldur            x1, [x4, #-1]
    //     0x629f68: ubfx            x1, x1, #0xc, #0x14
    // 0x629f6c: stp             x0, x4, [SP, #-0x10]!
    // 0x629f70: mov             x0, x1
    // 0x629f74: r0 = GDT[cid_x0 + -0xd83]()
    //     0x629f74: sub             lr, x0, #0xd83
    //     0x629f78: ldr             lr, [x21, lr, lsl #3]
    //     0x629f7c: blr             lr
    // 0x629f80: add             SP, SP, #0x10
    // 0x629f84: mov             x3, x0
    // 0x629f88: stur            x3, [fp, #-0x18]
    // 0x629f8c: cmp             w3, NULL
    // 0x629f90: b.eq            #0x62a080
    // 0x629f94: LoadField: r4 = r3->field_17
    //     0x629f94: ldur            w4, [x3, #0x17]
    // 0x629f98: DecompressPointer r4
    //     0x629f98: add             x4, x4, HEAP, lsl #32
    // 0x629f9c: stur            x4, [fp, #-0x10]
    // 0x629fa0: cmp             w4, NULL
    // 0x629fa4: b.eq            #0x62a0ac
    // 0x629fa8: mov             x0, x4
    // 0x629fac: r2 = Null
    //     0x629fac: mov             x2, NULL
    // 0x629fb0: r1 = Null
    //     0x629fb0: mov             x1, NULL
    // 0x629fb4: r4 = LoadClassIdInstr(r0)
    //     0x629fb4: ldur            x4, [x0, #-1]
    //     0x629fb8: ubfx            x4, x4, #0xc, #0x14
    // 0x629fbc: sub             x4, x4, #0x7ff
    // 0x629fc0: cmp             x4, #0xb
    // 0x629fc4: b.ls            #0x629fdc
    // 0x629fc8: r8 = BoxParentData
    //     0x629fc8: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x629fcc: ldr             x8, [x8, #0x1b0]
    // 0x629fd0: r3 = Null
    //     0x629fd0: add             x3, PP, #0x57, lsl #12  ; [pp+0x57710] Null
    //     0x629fd4: ldr             x3, [x3, #0x710]
    // 0x629fd8: r0 = DefaultTypeTest()
    //     0x629fd8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x629fdc: ldur            x0, [fp, #-0x10]
    // 0x629fe0: LoadField: r1 = r0->field_7
    //     0x629fe0: ldur            w1, [x0, #7]
    // 0x629fe4: DecompressPointer r1
    //     0x629fe4: add             x1, x1, HEAP, lsl #32
    // 0x629fe8: stur            x1, [fp, #-0x20]
    // 0x629fec: ldr             x16, [fp, #0x10]
    // 0x629ff0: stp             x1, x16, [SP, #-0x10]!
    // 0x629ff4: r0 = -()
    //     0x629ff4: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x629ff8: add             SP, SP, #0x10
    // 0x629ffc: stur            x0, [fp, #-0x10]
    // 0x62a000: ldur            x16, [fp, #-0x20]
    // 0x62a004: SaveReg r16
    //     0x62a004: str             x16, [SP, #-8]!
    // 0x62a008: r0 = unary-()
    //     0x62a008: bl              #0x622a88  ; [dart:ui] Offset::unary-
    // 0x62a00c: add             SP, SP, #8
    // 0x62a010: ldr             x16, [fp, #0x18]
    // 0x62a014: stp             x0, x16, [SP, #-0x10]!
    // 0x62a018: r0 = pushOffset()
    //     0x62a018: bl              #0x622998  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::pushOffset
    // 0x62a01c: add             SP, SP, #0x10
    // 0x62a020: ldur            x0, [fp, #-0x18]
    // 0x62a024: r1 = LoadClassIdInstr(r0)
    //     0x62a024: ldur            x1, [x0, #-1]
    //     0x62a028: ubfx            x1, x1, #0xc, #0x14
    // 0x62a02c: ldr             x16, [fp, #0x18]
    // 0x62a030: stp             x16, x0, [SP, #-0x10]!
    // 0x62a034: ldur            x16, [fp, #-0x10]
    // 0x62a038: SaveReg r16
    //     0x62a038: str             x16, [SP, #-8]!
    // 0x62a03c: mov             x0, x1
    // 0x62a040: r0 = GDT[cid_x0 + 0xefa2]()
    //     0x62a040: mov             x17, #0xefa2
    //     0x62a044: add             lr, x0, x17
    //     0x62a048: ldr             lr, [x21, lr, lsl #3]
    //     0x62a04c: blr             lr
    // 0x62a050: add             SP, SP, #0x18
    // 0x62a054: stur            x0, [fp, #-0x10]
    // 0x62a058: ldr             x16, [fp, #0x18]
    // 0x62a05c: SaveReg r16
    //     0x62a05c: str             x16, [SP, #-8]!
    // 0x62a060: r0 = popTransform()
    //     0x62a060: bl              #0x6228f4  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::popTransform
    // 0x62a064: add             SP, SP, #8
    // 0x62a068: ldur            x1, [fp, #-0x10]
    // 0x62a06c: tbnz            w1, #4, #0x62a080
    // 0x62a070: r0 = true
    //     0x62a070: add             x0, NULL, #0x20  ; true
    // 0x62a074: LeaveFrame
    //     0x62a074: mov             SP, fp
    //     0x62a078: ldp             fp, lr, [SP], #0x10
    // 0x62a07c: ret
    //     0x62a07c: ret             
    // 0x62a080: ldur            x1, [fp, #-8]
    // 0x62a084: sub             x3, x1, #1
    // 0x62a088: b               #0x629f30
    // 0x62a08c: r0 = false
    //     0x62a08c: add             x0, NULL, #0x30  ; false
    // 0x62a090: LeaveFrame
    //     0x62a090: mov             SP, fp
    //     0x62a094: ldp             fp, lr, [SP], #0x10
    // 0x62a098: ret
    //     0x62a098: ret             
    // 0x62a09c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62a09c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62a0a0: b               #0x629ef4
    // 0x62a0a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62a0a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62a0a8: b               #0x629f44
    // 0x62a0ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x62a0ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x632840, size: 0x18
    // 0x632840: r4 = 0
    //     0x632840: mov             x4, #0
    // 0x632844: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x632844: add             x17, PP, #0x57, lsl #12  ; [pp+0x576d0] AnonymousClosure: (0x632858), of [package:flutter/src/rendering/table.dart] RenderTable
    //     0x632848: ldr             x1, [x17, #0x6d0]
    // 0x63284c: r24 = BuildNonGenericMethodExtractorStub
    //     0x63284c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x632850: LoadField: r0 = r24->field_17
    //     0x632850: ldur            x0, [x24, #0x17]
    // 0x632854: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x632858, size: 0x4c
    // 0x632858: EnterFrame
    //     0x632858: stp             fp, lr, [SP, #-0x10]!
    //     0x63285c: mov             fp, SP
    // 0x632860: ldr             x0, [fp, #0x18]
    // 0x632864: LoadField: r1 = r0->field_17
    //     0x632864: ldur            w1, [x0, #0x17]
    // 0x632868: DecompressPointer r1
    //     0x632868: add             x1, x1, HEAP, lsl #32
    // 0x63286c: CheckStackOverflow
    //     0x63286c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x632870: cmp             SP, x16
    //     0x632874: b.ls            #0x63289c
    // 0x632878: LoadField: r0 = r1->field_f
    //     0x632878: ldur            w0, [x1, #0xf]
    // 0x63287c: DecompressPointer r0
    //     0x63287c: add             x0, x0, HEAP, lsl #32
    // 0x632880: ldr             x16, [fp, #0x10]
    // 0x632884: stp             x16, x0, [SP, #-0x10]!
    // 0x632888: r0 = computeMinIntrinsicHeight()
    //     0x632888: bl              #0x6328a4  ; [package:flutter/src/rendering/table.dart] RenderTable::computeMinIntrinsicHeight
    // 0x63288c: add             SP, SP, #0x10
    // 0x632890: LeaveFrame
    //     0x632890: mov             SP, fp
    //     0x632894: ldp             fp, lr, [SP], #0x10
    // 0x632898: ret
    //     0x632898: ret             
    // 0x63289c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63289c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6328a0: b               #0x632878
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0x6328a4, size: 0x308
    // 0x6328a4: EnterFrame
    //     0x6328a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6328a8: mov             fp, SP
    // 0x6328ac: AllocStack(0x40)
    //     0x6328ac: sub             SP, SP, #0x40
    // 0x6328b0: d0 = inf
    //     0x6328b0: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x6328b4: CheckStackOverflow
    //     0x6328b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6328b8: cmp             SP, x16
    //     0x6328bc: b.ls            #0x632b80
    // 0x6328c0: ldr             x0, [fp, #0x10]
    // 0x6328c4: LoadField: d1 = r0->field_7
    //     0x6328c4: ldur            d1, [x0, #7]
    // 0x6328c8: stur            d1, [fp, #-0x40]
    // 0x6328cc: fcmp            d1, d0
    // 0x6328d0: b.vs            #0x6328d8
    // 0x6328d4: b.eq            #0x6328e0
    // 0x6328d8: r0 = false
    //     0x6328d8: add             x0, NULL, #0x30  ; false
    // 0x6328dc: b               #0x6328e4
    // 0x6328e0: r0 = true
    //     0x6328e0: add             x0, NULL, #0x20  ; true
    // 0x6328e4: stur            x0, [fp, #-8]
    // 0x6328e8: tbz             w0, #4, #0x6328f4
    // 0x6328ec: mov             v2.16b, v1.16b
    // 0x6328f0: b               #0x6328f8
    // 0x6328f4: d2 = 0.000000
    //     0x6328f4: eor             v2.16b, v2.16b, v2.16b
    // 0x6328f8: stur            d2, [fp, #-0x38]
    // 0x6328fc: r0 = BoxConstraints()
    //     0x6328fc: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x632900: ldur            d0, [fp, #-0x38]
    // 0x632904: StoreField: r0->field_7 = d0
    //     0x632904: stur            d0, [x0, #7]
    // 0x632908: ldur            x1, [fp, #-8]
    // 0x63290c: tbz             w1, #4, #0x632918
    // 0x632910: ldur            d1, [fp, #-0x40]
    // 0x632914: b               #0x63291c
    // 0x632918: d1 = inf
    //     0x632918: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x63291c: d0 = inf
    //     0x63291c: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x632920: StoreField: r0->field_f = d1
    //     0x632920: stur            d1, [x0, #0xf]
    // 0x632924: fcmp            d0, d0
    // 0x632928: b.eq            #0x632934
    // 0x63292c: d1 = inf
    //     0x63292c: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x632930: b               #0x632938
    // 0x632934: d1 = 0.000000
    //     0x632934: eor             v1.16b, v1.16b, v1.16b
    // 0x632938: StoreField: r0->field_17 = d1
    //     0x632938: stur            d1, [x0, #0x17]
    // 0x63293c: StoreField: r0->field_1f = d0
    //     0x63293c: stur            d0, [x0, #0x1f]
    // 0x632940: ldr             x16, [fp, #0x18]
    // 0x632944: stp             x0, x16, [SP, #-0x10]!
    // 0x632948: r0 = _computeColumnWidths()
    //     0x632948: bl              #0x632bf8  ; [package:flutter/src/rendering/table.dart] RenderTable::_computeColumnWidths
    // 0x63294c: add             SP, SP, #0x10
    // 0x632950: mov             x2, x0
    // 0x632954: stur            x2, [fp, #-8]
    // 0x632958: LoadField: r0 = r2->field_b
    //     0x632958: ldur            w0, [x2, #0xb]
    // 0x63295c: DecompressPointer r0
    //     0x63295c: add             x0, x0, HEAP, lsl #32
    // 0x632960: r3 = LoadInt32Instr(r0)
    //     0x632960: sbfx            x3, x0, #1, #0x1f
    // 0x632964: stur            x3, [fp, #-0x20]
    // 0x632968: d0 = 0.000000
    //     0x632968: eor             v0.16b, v0.16b, v0.16b
    // 0x63296c: r5 = 0
    //     0x63296c: mov             x5, #0
    // 0x632970: ldr             x4, [fp, #0x18]
    // 0x632974: stur            x5, [fp, #-0x18]
    // 0x632978: stur            d0, [fp, #-0x40]
    // 0x63297c: CheckStackOverflow
    //     0x63297c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x632980: cmp             SP, x16
    //     0x632984: b.ls            #0x632b88
    // 0x632988: LoadField: r0 = r4->field_6b
    //     0x632988: ldur            x0, [x4, #0x6b]
    // 0x63298c: cmp             x5, x0
    // 0x632990: b.ge            #0x632b48
    // 0x632994: d1 = 0.000000
    //     0x632994: eor             v1.16b, v1.16b, v1.16b
    // 0x632998: r6 = 0
    //     0x632998: mov             x6, #0
    // 0x63299c: stur            x6, [fp, #-0x10]
    // 0x6329a0: stur            d1, [fp, #-0x38]
    // 0x6329a4: CheckStackOverflow
    //     0x6329a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6329a8: cmp             SP, x16
    //     0x6329ac: b.ls            #0x632b90
    // 0x6329b0: LoadField: r0 = r4->field_63
    //     0x6329b0: ldur            x0, [x4, #0x63]
    // 0x6329b4: cmp             x6, x0
    // 0x6329b8: b.ge            #0x632b1c
    // 0x6329bc: mul             x1, x5, x0
    // 0x6329c0: add             x7, x6, x1
    // 0x6329c4: LoadField: r8 = r4->field_5f
    //     0x6329c4: ldur            w8, [x4, #0x5f]
    // 0x6329c8: DecompressPointer r8
    //     0x6329c8: add             x8, x8, HEAP, lsl #32
    // 0x6329cc: r0 = BoxInt64Instr(r7)
    //     0x6329cc: sbfiz           x0, x7, #1, #0x1f
    //     0x6329d0: cmp             x7, x0, asr #1
    //     0x6329d4: b.eq            #0x6329e0
    //     0x6329d8: bl              #0xd69c6c
    //     0x6329dc: stur            x7, [x0, #7]
    // 0x6329e0: r1 = LoadClassIdInstr(r8)
    //     0x6329e0: ldur            x1, [x8, #-1]
    //     0x6329e4: ubfx            x1, x1, #0xc, #0x14
    // 0x6329e8: stp             x0, x8, [SP, #-0x10]!
    // 0x6329ec: mov             x0, x1
    // 0x6329f0: r0 = GDT[cid_x0 + -0xd83]()
    //     0x6329f0: sub             lr, x0, #0xd83
    //     0x6329f4: ldr             lr, [x21, lr, lsl #3]
    //     0x6329f8: blr             lr
    // 0x6329fc: add             SP, SP, #0x10
    // 0x632a00: mov             x2, x0
    // 0x632a04: stur            x2, [fp, #-0x30]
    // 0x632a08: cmp             w2, NULL
    // 0x632a0c: b.eq            #0x632af0
    // 0x632a10: ldur            x3, [fp, #-8]
    // 0x632a14: ldur            d0, [fp, #-0x38]
    // 0x632a18: ldur            x4, [fp, #-0x10]
    // 0x632a1c: ldur            x0, [fp, #-0x20]
    // 0x632a20: mov             x1, x4
    // 0x632a24: cmp             x1, x0
    // 0x632a28: b.hs            #0x632b98
    // 0x632a2c: ArrayLoad: r1 = r3[r4]  ; Unknown_4
    //     0x632a2c: add             x16, x3, x4, lsl #2
    //     0x632a30: ldur            w1, [x16, #0xf]
    // 0x632a34: DecompressPointer r1
    //     0x632a34: add             x1, x1, HEAP, lsl #32
    // 0x632a38: stur            x1, [fp, #-0x28]
    // 0x632a3c: r0 = 59
    //     0x632a3c: mov             x0, #0x3b
    // 0x632a40: branchIfSmi(r2, 0x632a4c)
    //     0x632a40: tbz             w2, #0, #0x632a4c
    // 0x632a44: r0 = LoadClassIdInstr(r2)
    //     0x632a44: ldur            x0, [x2, #-1]
    //     0x632a48: ubfx            x0, x0, #0xc, #0x14
    // 0x632a4c: SaveReg r2
    //     0x632a4c: str             x2, [SP, #-8]!
    // 0x632a50: r0 = GDT[cid_x0 + 0xf291]()
    //     0x632a50: mov             x17, #0xf291
    //     0x632a54: add             lr, x0, x17
    //     0x632a58: ldr             lr, [x21, lr, lsl #3]
    //     0x632a5c: blr             lr
    // 0x632a60: add             SP, SP, #8
    // 0x632a64: mov             x1, x0
    // 0x632a68: ldur            x0, [fp, #-0x28]
    // 0x632a6c: LoadField: d0 = r0->field_7
    //     0x632a6c: ldur            d0, [x0, #7]
    // 0x632a70: ldur            x16, [fp, #-0x30]
    // 0x632a74: r30 = Instance__IntrinsicDimension
    //     0x632a74: add             lr, PP, #0x40, lsl #12  ; [pp+0x40bd0] Obj!_IntrinsicDimension@b64bd1
    //     0x632a78: ldr             lr, [lr, #0xbd0]
    // 0x632a7c: stp             lr, x16, [SP, #-0x10]!
    // 0x632a80: SaveReg d0
    //     0x632a80: str             d0, [SP, #-8]!
    // 0x632a84: SaveReg r1
    //     0x632a84: str             x1, [SP, #-8]!
    // 0x632a88: r0 = _computeIntrinsicDimension()
    //     0x632a88: bl              #0x62cc04  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsicDimension
    // 0x632a8c: add             SP, SP, #0x20
    // 0x632a90: mov             v1.16b, v0.16b
    // 0x632a94: ldur            d0, [fp, #-0x38]
    // 0x632a98: fcmp            d0, d1
    // 0x632a9c: b.vs            #0x632ab0
    // 0x632aa0: b.le            #0x632ab0
    // 0x632aa4: mov             v1.16b, v0.16b
    // 0x632aa8: d2 = 0.000000
    //     0x632aa8: eor             v2.16b, v2.16b, v2.16b
    // 0x632aac: b               #0x632afc
    // 0x632ab0: fcmp            d0, d1
    // 0x632ab4: b.vs            #0x632ac4
    // 0x632ab8: b.ge            #0x632ac4
    // 0x632abc: d2 = 0.000000
    //     0x632abc: eor             v2.16b, v2.16b, v2.16b
    // 0x632ac0: b               #0x632afc
    // 0x632ac4: d2 = 0.000000
    //     0x632ac4: eor             v2.16b, v2.16b, v2.16b
    // 0x632ac8: fcmp            d0, d2
    // 0x632acc: b.vs            #0x632ae0
    // 0x632ad0: b.ne            #0x632ae0
    // 0x632ad4: fadd            d3, d0, d1
    // 0x632ad8: mov             v1.16b, v3.16b
    // 0x632adc: b               #0x632afc
    // 0x632ae0: fcmp            d1, d1
    // 0x632ae4: b.vs            #0x632afc
    // 0x632ae8: mov             v1.16b, v0.16b
    // 0x632aec: b               #0x632afc
    // 0x632af0: ldur            d0, [fp, #-0x38]
    // 0x632af4: d2 = 0.000000
    //     0x632af4: eor             v2.16b, v2.16b, v2.16b
    // 0x632af8: mov             v1.16b, v0.16b
    // 0x632afc: ldur            x1, [fp, #-0x10]
    // 0x632b00: add             x6, x1, #1
    // 0x632b04: ldr             x4, [fp, #0x18]
    // 0x632b08: ldur            x2, [fp, #-8]
    // 0x632b0c: ldur            d0, [fp, #-0x40]
    // 0x632b10: ldur            x5, [fp, #-0x18]
    // 0x632b14: ldur            x3, [fp, #-0x20]
    // 0x632b18: b               #0x63299c
    // 0x632b1c: mov             v31.16b, v1.16b
    // 0x632b20: mov             v1.16b, v0.16b
    // 0x632b24: mov             v0.16b, v31.16b
    // 0x632b28: mov             x1, x5
    // 0x632b2c: d2 = 0.000000
    //     0x632b2c: eor             v2.16b, v2.16b, v2.16b
    // 0x632b30: fadd            d3, d1, d0
    // 0x632b34: add             x5, x1, #1
    // 0x632b38: mov             v0.16b, v3.16b
    // 0x632b3c: ldur            x2, [fp, #-8]
    // 0x632b40: ldur            x3, [fp, #-0x20]
    // 0x632b44: b               #0x632970
    // 0x632b48: mov             v1.16b, v0.16b
    // 0x632b4c: r0 = inline_Allocate_Double()
    //     0x632b4c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x632b50: add             x0, x0, #0x10
    //     0x632b54: cmp             x1, x0
    //     0x632b58: b.ls            #0x632b9c
    //     0x632b5c: str             x0, [THR, #0x60]  ; THR::top
    //     0x632b60: sub             x0, x0, #0xf
    //     0x632b64: mov             x1, #0xd108
    //     0x632b68: movk            x1, #3, lsl #16
    //     0x632b6c: stur            x1, [x0, #-1]
    // 0x632b70: StoreField: r0->field_7 = d1
    //     0x632b70: stur            d1, [x0, #7]
    // 0x632b74: LeaveFrame
    //     0x632b74: mov             SP, fp
    //     0x632b78: ldp             fp, lr, [SP], #0x10
    // 0x632b7c: ret
    //     0x632b7c: ret             
    // 0x632b80: r0 = StackOverflowSharedWithFPURegs()
    //     0x632b80: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x632b84: b               #0x6328c0
    // 0x632b88: r0 = StackOverflowSharedWithFPURegs()
    //     0x632b88: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x632b8c: b               #0x632988
    // 0x632b90: r0 = StackOverflowSharedWithFPURegs()
    //     0x632b90: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x632b94: b               #0x6329b0
    // 0x632b98: r0 = RangeErrorSharedWithFPURegs()
    //     0x632b98: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x632b9c: SaveReg d1
    //     0x632b9c: str             q1, [SP, #-0x10]!
    // 0x632ba0: r0 = AllocateDouble()
    //     0x632ba0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x632ba4: RestoreReg d1
    //     0x632ba4: ldr             q1, [SP], #0x10
    // 0x632ba8: b               #0x632b70
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x632bac, size: 0x4c
    // 0x632bac: EnterFrame
    //     0x632bac: stp             fp, lr, [SP, #-0x10]!
    //     0x632bb0: mov             fp, SP
    // 0x632bb4: ldr             x0, [fp, #0x18]
    // 0x632bb8: LoadField: r1 = r0->field_17
    //     0x632bb8: ldur            w1, [x0, #0x17]
    // 0x632bbc: DecompressPointer r1
    //     0x632bbc: add             x1, x1, HEAP, lsl #32
    // 0x632bc0: CheckStackOverflow
    //     0x632bc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x632bc4: cmp             SP, x16
    //     0x632bc8: b.ls            #0x632bf0
    // 0x632bcc: LoadField: r0 = r1->field_f
    //     0x632bcc: ldur            w0, [x1, #0xf]
    // 0x632bd0: DecompressPointer r0
    //     0x632bd0: add             x0, x0, HEAP, lsl #32
    // 0x632bd4: ldr             x16, [fp, #0x10]
    // 0x632bd8: stp             x16, x0, [SP, #-0x10]!
    // 0x632bdc: r0 = computeMinIntrinsicHeight()
    //     0x632bdc: bl              #0x6328a4  ; [package:flutter/src/rendering/table.dart] RenderTable::computeMinIntrinsicHeight
    // 0x632be0: add             SP, SP, #0x10
    // 0x632be4: LeaveFrame
    //     0x632be4: mov             SP, fp
    //     0x632be8: ldp             fp, lr, [SP], #0x10
    // 0x632bec: ret
    //     0x632bec: ret             
    // 0x632bf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x632bf0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x632bf4: b               #0x632bcc
  }
  _ _computeColumnWidths(/* No info */) {
    // ** addr: 0x632bf8, size: 0x84c
    // 0x632bf8: EnterFrame
    //     0x632bf8: stp             fp, lr, [SP, #-0x10]!
    //     0x632bfc: mov             fp, SP
    // 0x632c00: AllocStack(0x40)
    //     0x632c00: sub             SP, SP, #0x40
    // 0x632c04: CheckStackOverflow
    //     0x632c04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x632c08: cmp             SP, x16
    //     0x632c0c: b.ls            #0x6332f0
    // 0x632c10: ldr             x0, [fp, #0x18]
    // 0x632c14: LoadField: r1 = r0->field_63
    //     0x632c14: ldur            x1, [x0, #0x63]
    // 0x632c18: stur            x1, [fp, #-8]
    // 0x632c1c: r16 = <double>
    //     0x632c1c: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x632c20: stp             x1, x16, [SP, #-0x10]!
    // 0x632c24: r16 = 0.000000
    //     0x632c24: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x632c28: SaveReg r16
    //     0x632c28: str             x16, [SP, #-8]!
    // 0x632c2c: r0 = _List.filled()
    //     0x632c2c: bl              #0x4db0d4  ; [dart:core] _List::_List.filled
    // 0x632c30: add             SP, SP, #0x18
    // 0x632c34: mov             x1, x0
    // 0x632c38: ldr             x0, [fp, #0x18]
    // 0x632c3c: stur            x1, [fp, #-0x18]
    // 0x632c40: LoadField: r2 = r0->field_63
    //     0x632c40: ldur            x2, [x0, #0x63]
    // 0x632c44: stur            x2, [fp, #-0x10]
    // 0x632c48: r16 = <double>
    //     0x632c48: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x632c4c: stp             x2, x16, [SP, #-0x10]!
    // 0x632c50: r16 = 0.000000
    //     0x632c50: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x632c54: SaveReg r16
    //     0x632c54: str             x16, [SP, #-8]!
    // 0x632c58: r0 = _List.filled()
    //     0x632c58: bl              #0x4db0d4  ; [dart:core] _List::_List.filled
    // 0x632c5c: add             SP, SP, #0x18
    // 0x632c60: mov             x4, x0
    // 0x632c64: ldr             x3, [fp, #0x18]
    // 0x632c68: stur            x4, [fp, #-0x28]
    // 0x632c6c: LoadField: r5 = r3->field_63
    //     0x632c6c: ldur            x5, [x3, #0x63]
    // 0x632c70: stur            x5, [fp, #-0x20]
    // 0x632c74: r0 = BoxInt64Instr(r5)
    //     0x632c74: sbfiz           x0, x5, #1, #0x1f
    //     0x632c78: cmp             x5, x0, asr #1
    //     0x632c7c: b.eq            #0x632c88
    //     0x632c80: bl              #0xd69bb8
    //     0x632c84: stur            x5, [x0, #7]
    // 0x632c88: mov             x2, x0
    // 0x632c8c: r1 = <double?>
    //     0x632c8c: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2db88] TypeArguments: <double?>
    //     0x632c90: ldr             x1, [x1, #0xb88]
    // 0x632c94: r0 = AllocateArray()
    //     0x632c94: bl              #0xd6987c  ; AllocateArrayStub
    // 0x632c98: mov             x2, x0
    // 0x632c9c: stur            x2, [fp, #-0x38]
    // 0x632ca0: ldur            x5, [fp, #-0x18]
    // 0x632ca4: ldur            x4, [fp, #-0x28]
    // 0x632ca8: r6 = 0
    //     0x632ca8: mov             x6, #0
    // 0x632cac: d0 = 0.000000
    //     0x632cac: eor             v0.16b, v0.16b, v0.16b
    // 0x632cb0: ldr             x3, [fp, #0x18]
    // 0x632cb4: stur            x6, [fp, #-0x30]
    // 0x632cb8: stur            d0, [fp, #-0x40]
    // 0x632cbc: CheckStackOverflow
    //     0x632cbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x632cc0: cmp             SP, x16
    //     0x632cc4: b.ls            #0x6332f8
    // 0x632cc8: LoadField: r7 = r3->field_63
    //     0x632cc8: ldur            x7, [x3, #0x63]
    // 0x632ccc: cmp             x6, x7
    // 0x632cd0: b.ge            #0x632dac
    // 0x632cd4: LoadField: r7 = r3->field_73
    //     0x632cd4: ldur            w7, [x3, #0x73]
    // 0x632cd8: DecompressPointer r7
    //     0x632cd8: add             x7, x7, HEAP, lsl #32
    // 0x632cdc: r0 = BoxInt64Instr(r6)
    //     0x632cdc: sbfiz           x0, x6, #1, #0x1f
    //     0x632ce0: cmp             x6, x0, asr #1
    //     0x632ce4: b.eq            #0x632cf0
    //     0x632ce8: bl              #0xd69c6c
    //     0x632cec: stur            x6, [x0, #7]
    // 0x632cf0: r1 = LoadClassIdInstr(r7)
    //     0x632cf0: ldur            x1, [x7, #-1]
    //     0x632cf4: ubfx            x1, x1, #0xc, #0x14
    // 0x632cf8: stp             x0, x7, [SP, #-0x10]!
    // 0x632cfc: mov             x0, x1
    // 0x632d00: r0 = GDT[cid_x0 + -0xef]()
    //     0x632d00: sub             lr, x0, #0xef
    //     0x632d04: ldr             lr, [x21, lr, lsl #3]
    //     0x632d08: blr             lr
    // 0x632d0c: add             SP, SP, #0x10
    // 0x632d10: ldr             x16, [fp, #0x18]
    // 0x632d14: SaveReg r16
    //     0x632d14: str             x16, [SP, #-8]!
    // 0x632d18: ldur            x1, [fp, #-0x30]
    // 0x632d1c: SaveReg r1
    //     0x632d1c: str             x1, [SP, #-8]!
    // 0x632d20: r0 = column()
    //     0x632d20: bl              #0x633444  ; [package:flutter/src/rendering/table.dart] RenderTable::column
    // 0x632d24: add             SP, SP, #0x10
    // 0x632d28: ldur            x0, [fp, #-8]
    // 0x632d2c: ldur            x1, [fp, #-0x30]
    // 0x632d30: cmp             x1, x0
    // 0x632d34: b.hs            #0x633300
    // 0x632d38: ldur            x3, [fp, #-0x18]
    // 0x632d3c: ldur            x2, [fp, #-0x30]
    // 0x632d40: add             x4, x3, x2, lsl #2
    // 0x632d44: r17 = 0.000000
    //     0x632d44: ldr             x17, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x632d48: StoreField: r4->field_f = r17
    //     0x632d48: stur            w17, [x4, #0xf]
    // 0x632d4c: ldur            x0, [fp, #-0x10]
    // 0x632d50: mov             x1, x2
    // 0x632d54: cmp             x1, x0
    // 0x632d58: b.hs            #0x633304
    // 0x632d5c: ldur            x4, [fp, #-0x28]
    // 0x632d60: add             x5, x4, x2, lsl #2
    // 0x632d64: r17 = 0.000000
    //     0x632d64: ldr             x17, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x632d68: StoreField: r5->field_f = r17
    //     0x632d68: stur            w17, [x5, #0xf]
    // 0x632d6c: ldur            x0, [fp, #-0x20]
    // 0x632d70: mov             x1, x2
    // 0x632d74: cmp             x1, x0
    // 0x632d78: b.hs            #0x633308
    // 0x632d7c: ldur            x5, [fp, #-0x38]
    // 0x632d80: add             x6, x5, x2, lsl #2
    // 0x632d84: r17 = 1.000000
    //     0x632d84: ldr             x17, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x632d88: StoreField: r6->field_f = r17
    //     0x632d88: stur            w17, [x6, #0xf]
    // 0x632d8c: ldur            d0, [fp, #-0x40]
    // 0x632d90: d1 = 1.000000
    //     0x632d90: fmov            d1, #1.00000000
    // 0x632d94: fadd            d2, d0, d1
    // 0x632d98: add             x6, x2, #1
    // 0x632d9c: mov             v0.16b, v2.16b
    // 0x632da0: mov             x2, x5
    // 0x632da4: mov             x5, x3
    // 0x632da8: b               #0x632cb0
    // 0x632dac: mov             x3, x5
    // 0x632db0: mov             x5, x2
    // 0x632db4: ldr             x2, [fp, #0x10]
    // 0x632db8: d1 = 0.000000
    //     0x632db8: eor             v1.16b, v1.16b, v1.16b
    // 0x632dbc: LoadField: d2 = r2->field_f
    //     0x632dbc: ldur            d2, [x2, #0xf]
    // 0x632dc0: LoadField: d3 = r2->field_7
    //     0x632dc0: ldur            d3, [x2, #7]
    // 0x632dc4: fcmp            d0, d1
    // 0x632dc8: b.vs            #0x632f04
    // 0x632dcc: b.le            #0x632f04
    // 0x632dd0: mov             x2, v2.d[0]
    // 0x632dd4: and             x2, x2, #0x7fffffffffffffff
    // 0x632dd8: r17 = 9218868437227405312
    //     0x632dd8: mov             x17, #0x7ff0000000000000
    // 0x632ddc: cmp             x2, x17
    // 0x632de0: b.eq            #0x632df4
    // 0x632de4: fcmp            d2, d2
    // 0x632de8: b.vs            #0x632df4
    // 0x632dec: mov             v4.16b, v2.16b
    // 0x632df0: b               #0x632df8
    // 0x632df4: mov             v4.16b, v3.16b
    // 0x632df8: fcmp            d1, d4
    // 0x632dfc: b.vs            #0x632ef8
    // 0x632e00: b.ge            #0x632ef8
    // 0x632e04: fsub            d5, d4, d1
    // 0x632e08: d4 = 0.000000
    //     0x632e08: eor             v4.16b, v4.16b, v4.16b
    // 0x632e0c: r2 = 0
    //     0x632e0c: mov             x2, #0
    // 0x632e10: CheckStackOverflow
    //     0x632e10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x632e14: cmp             SP, x16
    //     0x632e18: b.ls            #0x63330c
    // 0x632e1c: cmp             x2, x7
    // 0x632e20: b.ge            #0x632efc
    // 0x632e24: ldur            x0, [fp, #-0x20]
    // 0x632e28: mov             x1, x2
    // 0x632e2c: cmp             x1, x0
    // 0x632e30: b.hs            #0x633314
    // 0x632e34: ArrayLoad: r6 = r5[r2]  ; Unknown_4
    //     0x632e34: add             x16, x5, x2, lsl #2
    //     0x632e38: ldur            w6, [x16, #0xf]
    // 0x632e3c: DecompressPointer r6
    //     0x632e3c: add             x6, x6, HEAP, lsl #32
    // 0x632e40: cmp             w6, NULL
    // 0x632e44: b.eq            #0x632eec
    // 0x632e48: LoadField: d6 = r6->field_7
    //     0x632e48: ldur            d6, [x6, #7]
    // 0x632e4c: fmul            d7, d5, d6
    // 0x632e50: fdiv            d6, d7, d0
    // 0x632e54: ldur            x0, [fp, #-8]
    // 0x632e58: mov             x1, x2
    // 0x632e5c: cmp             x1, x0
    // 0x632e60: b.hs            #0x633318
    // 0x632e64: ArrayLoad: r6 = r3[r2]  ; Unknown_4
    //     0x632e64: add             x16, x3, x2, lsl #2
    //     0x632e68: ldur            w6, [x16, #0xf]
    // 0x632e6c: DecompressPointer r6
    //     0x632e6c: add             x6, x6, HEAP, lsl #32
    // 0x632e70: LoadField: d7 = r6->field_7
    //     0x632e70: ldur            d7, [x6, #7]
    // 0x632e74: fcmp            d7, d6
    // 0x632e78: b.vs            #0x632ee4
    // 0x632e7c: b.ge            #0x632ee4
    // 0x632e80: fsub            d8, d6, d7
    // 0x632e84: fadd            d7, d4, d8
    // 0x632e88: r0 = inline_Allocate_Double()
    //     0x632e88: ldp             x0, x6, [THR, #0x60]  ; THR::top
    //     0x632e8c: add             x0, x0, #0x10
    //     0x632e90: cmp             x6, x0
    //     0x632e94: b.ls            #0x63331c
    //     0x632e98: str             x0, [THR, #0x60]  ; THR::top
    //     0x632e9c: sub             x0, x0, #0xf
    //     0x632ea0: mov             x6, #0xd108
    //     0x632ea4: movk            x6, #3, lsl #16
    //     0x632ea8: stur            x6, [x0, #-1]
    // 0x632eac: StoreField: r0->field_7 = d6
    //     0x632eac: stur            d6, [x0, #7]
    // 0x632eb0: mov             x1, x3
    // 0x632eb4: ArrayStore: r1[r2] = r0  ; List_4
    //     0x632eb4: add             x25, x1, x2, lsl #2
    //     0x632eb8: add             x25, x25, #0xf
    //     0x632ebc: str             w0, [x25]
    //     0x632ec0: tbz             w0, #0, #0x632edc
    //     0x632ec4: ldurb           w16, [x1, #-1]
    //     0x632ec8: ldurb           w17, [x0, #-1]
    //     0x632ecc: and             x16, x17, x16, lsr #2
    //     0x632ed0: tst             x16, HEAP, lsr #32
    //     0x632ed4: b.eq            #0x632edc
    //     0x632ed8: bl              #0xd67e5c
    // 0x632edc: mov             v6.16b, v7.16b
    // 0x632ee0: b               #0x632ee8
    // 0x632ee4: mov             v6.16b, v4.16b
    // 0x632ee8: mov             v4.16b, v6.16b
    // 0x632eec: add             x0, x2, #1
    // 0x632ef0: mov             x2, x0
    // 0x632ef4: b               #0x632e10
    // 0x632ef8: d4 = 0.000000
    //     0x632ef8: eor             v4.16b, v4.16b, v4.16b
    // 0x632efc: mov             v3.16b, v4.16b
    // 0x632f00: b               #0x632fbc
    // 0x632f04: fcmp            d1, d3
    // 0x632f08: b.vs            #0x632fb8
    // 0x632f0c: b.ge            #0x632fb8
    // 0x632f10: fsub            d4, d3, d1
    // 0x632f14: scvtf           d5, x7
    // 0x632f18: fdiv            d6, d4, d5
    // 0x632f1c: r2 = 0
    //     0x632f1c: mov             x2, #0
    // 0x632f20: CheckStackOverflow
    //     0x632f20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x632f24: cmp             SP, x16
    //     0x632f28: b.ls            #0x633354
    // 0x632f2c: cmp             x2, x7
    // 0x632f30: b.ge            #0x632fbc
    // 0x632f34: ldur            x0, [fp, #-8]
    // 0x632f38: mov             x1, x2
    // 0x632f3c: cmp             x1, x0
    // 0x632f40: b.hs            #0x63335c
    // 0x632f44: ArrayLoad: r6 = r3[r2]  ; Unknown_4
    //     0x632f44: add             x16, x3, x2, lsl #2
    //     0x632f48: ldur            w6, [x16, #0xf]
    // 0x632f4c: DecompressPointer r6
    //     0x632f4c: add             x6, x6, HEAP, lsl #32
    // 0x632f50: LoadField: d4 = r6->field_7
    //     0x632f50: ldur            d4, [x6, #7]
    // 0x632f54: fadd            d5, d4, d6
    // 0x632f58: r0 = inline_Allocate_Double()
    //     0x632f58: ldp             x0, x6, [THR, #0x60]  ; THR::top
    //     0x632f5c: add             x0, x0, #0x10
    //     0x632f60: cmp             x6, x0
    //     0x632f64: b.ls            #0x633360
    //     0x632f68: str             x0, [THR, #0x60]  ; THR::top
    //     0x632f6c: sub             x0, x0, #0xf
    //     0x632f70: mov             x6, #0xd108
    //     0x632f74: movk            x6, #3, lsl #16
    //     0x632f78: stur            x6, [x0, #-1]
    // 0x632f7c: StoreField: r0->field_7 = d5
    //     0x632f7c: stur            d5, [x0, #7]
    // 0x632f80: mov             x1, x3
    // 0x632f84: ArrayStore: r1[r2] = r0  ; List_4
    //     0x632f84: add             x25, x1, x2, lsl #2
    //     0x632f88: add             x25, x25, #0xf
    //     0x632f8c: str             w0, [x25]
    //     0x632f90: tbz             w0, #0, #0x632fac
    //     0x632f94: ldurb           w16, [x1, #-1]
    //     0x632f98: ldurb           w17, [x0, #-1]
    //     0x632f9c: and             x16, x17, x16, lsr #2
    //     0x632fa0: tst             x16, HEAP, lsr #32
    //     0x632fa4: b.eq            #0x632fac
    //     0x632fa8: bl              #0xd67e5c
    // 0x632fac: add             x0, x2, #1
    // 0x632fb0: mov             x2, x0
    // 0x632fb4: b               #0x632f20
    // 0x632fb8: d3 = 0.000000
    //     0x632fb8: eor             v3.16b, v3.16b, v3.16b
    // 0x632fbc: fcmp            d3, d2
    // 0x632fc0: b.vs            #0x6332e0
    // 0x632fc4: b.le            #0x6332e0
    // 0x632fc8: fsub            d4, d3, d2
    // 0x632fcc: mov             v3.16b, v0.16b
    // 0x632fd0: mov             v2.16b, v4.16b
    // 0x632fd4: mov             x2, x7
    // 0x632fd8: d0 = 0.000000
    //     0x632fd8: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1e0] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    //     0x632fdc: ldr             d0, [x17, #0x1e0]
    // 0x632fe0: CheckStackOverflow
    //     0x632fe0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x632fe4: cmp             SP, x16
    //     0x632fe8: b.ls            #0x633398
    // 0x632fec: fcmp            d2, d0
    // 0x632ff0: b.vs            #0x633184
    // 0x632ff4: b.le            #0x633184
    // 0x632ff8: fcmp            d3, d0
    // 0x632ffc: b.vs            #0x633184
    // 0x633000: b.le            #0x633184
    // 0x633004: mov             v5.16b, v2.16b
    // 0x633008: mov             x6, x2
    // 0x63300c: d4 = 0.000000
    //     0x63300c: eor             v4.16b, v4.16b, v4.16b
    // 0x633010: r2 = 0
    //     0x633010: mov             x2, #0
    // 0x633014: CheckStackOverflow
    //     0x633014: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x633018: cmp             SP, x16
    //     0x63301c: b.ls            #0x6333a0
    // 0x633020: cmp             x2, x7
    // 0x633024: b.ge            #0x633174
    // 0x633028: ldur            x0, [fp, #-0x20]
    // 0x63302c: mov             x1, x2
    // 0x633030: cmp             x1, x0
    // 0x633034: b.hs            #0x6333a8
    // 0x633038: ArrayLoad: r8 = r5[r2]  ; Unknown_4
    //     0x633038: add             x16, x5, x2, lsl #2
    //     0x63303c: ldur            w8, [x16, #0xf]
    // 0x633040: DecompressPointer r8
    //     0x633040: add             x8, x8, HEAP, lsl #32
    // 0x633044: cmp             w8, NULL
    // 0x633048: b.eq            #0x633168
    // 0x63304c: ldur            x0, [fp, #-8]
    // 0x633050: mov             x1, x2
    // 0x633054: cmp             x1, x0
    // 0x633058: b.hs            #0x6333ac
    // 0x63305c: ArrayLoad: r9 = r3[r2]  ; Unknown_4
    //     0x63305c: add             x16, x3, x2, lsl #2
    //     0x633060: ldur            w9, [x16, #0xf]
    // 0x633064: DecompressPointer r9
    //     0x633064: add             x9, x9, HEAP, lsl #32
    // 0x633068: LoadField: d6 = r8->field_7
    //     0x633068: ldur            d6, [x8, #7]
    // 0x63306c: fmul            d7, d5, d6
    // 0x633070: fdiv            d8, d7, d3
    // 0x633074: LoadField: d7 = r9->field_7
    //     0x633074: ldur            d7, [x9, #7]
    // 0x633078: fsub            d9, d7, d8
    // 0x63307c: ldur            x0, [fp, #-0x10]
    // 0x633080: mov             x1, x2
    // 0x633084: cmp             x1, x0
    // 0x633088: b.hs            #0x6333b0
    // 0x63308c: ArrayLoad: r0 = r4[r2]  ; Unknown_4
    //     0x63308c: add             x16, x4, x2, lsl #2
    //     0x633090: ldur            w0, [x16, #0xf]
    // 0x633094: DecompressPointer r0
    //     0x633094: add             x0, x0, HEAP, lsl #32
    // 0x633098: LoadField: d8 = r0->field_7
    //     0x633098: ldur            d8, [x0, #7]
    // 0x63309c: fcmp            d9, d8
    // 0x6330a0: b.vs            #0x6330f4
    // 0x6330a4: b.gt            #0x6330f4
    // 0x6330a8: fsub            d10, d7, d8
    // 0x6330ac: fsub            d8, d5, d10
    // 0x6330b0: mov             x1, x3
    // 0x6330b4: ArrayStore: r1[r2] = r0  ; List_4
    //     0x6330b4: add             x25, x1, x2, lsl #2
    //     0x6330b8: add             x25, x25, #0xf
    //     0x6330bc: str             w0, [x25]
    //     0x6330c0: tbz             w0, #0, #0x6330dc
    //     0x6330c4: ldurb           w16, [x1, #-1]
    //     0x6330c8: ldurb           w17, [x0, #-1]
    //     0x6330cc: and             x16, x17, x16, lsr #2
    //     0x6330d0: tst             x16, HEAP, lsr #32
    //     0x6330d4: b.eq            #0x6330dc
    //     0x6330d8: bl              #0xd67e5c
    // 0x6330dc: ArrayStore: r5[r2] = rNULL  ; Unknown_4
    //     0x6330dc: add             x8, x5, x2, lsl #2
    //     0x6330e0: stur            NULL, [x8, #0xf]
    // 0x6330e4: sub             x8, x6, #1
    // 0x6330e8: mov             v7.16b, v8.16b
    // 0x6330ec: mov             v6.16b, v4.16b
    // 0x6330f0: b               #0x63315c
    // 0x6330f4: fsub            d8, d7, d9
    // 0x6330f8: fsub            d7, d5, d8
    // 0x6330fc: r0 = inline_Allocate_Double()
    //     0x6330fc: ldp             x0, x8, [THR, #0x60]  ; THR::top
    //     0x633100: add             x0, x0, #0x10
    //     0x633104: cmp             x8, x0
    //     0x633108: b.ls            #0x6333b4
    //     0x63310c: str             x0, [THR, #0x60]  ; THR::top
    //     0x633110: sub             x0, x0, #0xf
    //     0x633114: mov             x8, #0xd108
    //     0x633118: movk            x8, #3, lsl #16
    //     0x63311c: stur            x8, [x0, #-1]
    // 0x633120: StoreField: r0->field_7 = d9
    //     0x633120: stur            d9, [x0, #7]
    // 0x633124: mov             x1, x3
    // 0x633128: ArrayStore: r1[r2] = r0  ; List_4
    //     0x633128: add             x25, x1, x2, lsl #2
    //     0x63312c: add             x25, x25, #0xf
    //     0x633130: str             w0, [x25]
    //     0x633134: tbz             w0, #0, #0x633150
    //     0x633138: ldurb           w16, [x1, #-1]
    //     0x63313c: ldurb           w17, [x0, #-1]
    //     0x633140: and             x16, x17, x16, lsr #2
    //     0x633144: tst             x16, HEAP, lsr #32
    //     0x633148: b.eq            #0x633150
    //     0x63314c: bl              #0xd67e5c
    // 0x633150: fadd            d8, d4, d6
    // 0x633154: mov             x8, x6
    // 0x633158: mov             v6.16b, v8.16b
    // 0x63315c: mov             v5.16b, v7.16b
    // 0x633160: mov             x6, x8
    // 0x633164: mov             v4.16b, v6.16b
    // 0x633168: add             x0, x2, #1
    // 0x63316c: mov             x2, x0
    // 0x633170: b               #0x633014
    // 0x633174: mov             v3.16b, v4.16b
    // 0x633178: mov             v2.16b, v5.16b
    // 0x63317c: mov             x2, x6
    // 0x633180: b               #0x632fe0
    // 0x633184: CheckStackOverflow
    //     0x633184: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x633188: cmp             SP, x16
    //     0x63318c: b.ls            #0x6333f4
    // 0x633190: fcmp            d2, d0
    // 0x633194: b.vs            #0x6332e0
    // 0x633198: b.le            #0x6332e0
    // 0x63319c: cmp             x2, #0
    // 0x6331a0: b.le            #0x6332e0
    // 0x6331a4: scvtf           d3, x2
    // 0x6331a8: fdiv            d4, d2, d3
    // 0x6331ac: r5 = 0
    //     0x6331ac: mov             x5, #0
    // 0x6331b0: r2 = 0
    //     0x6331b0: mov             x2, #0
    // 0x6331b4: CheckStackOverflow
    //     0x6331b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6331b8: cmp             SP, x16
    //     0x6331bc: b.ls            #0x6333fc
    // 0x6331c0: cmp             x2, x7
    // 0x6331c4: b.ge            #0x6332d8
    // 0x6331c8: ldur            x0, [fp, #-8]
    // 0x6331cc: mov             x1, x2
    // 0x6331d0: cmp             x1, x0
    // 0x6331d4: b.hs            #0x633404
    // 0x6331d8: ArrayLoad: r6 = r3[r2]  ; Unknown_4
    //     0x6331d8: add             x16, x3, x2, lsl #2
    //     0x6331dc: ldur            w6, [x16, #0xf]
    // 0x6331e0: DecompressPointer r6
    //     0x6331e0: add             x6, x6, HEAP, lsl #32
    // 0x6331e4: ldur            x0, [fp, #-0x10]
    // 0x6331e8: mov             x1, x2
    // 0x6331ec: cmp             x1, x0
    // 0x6331f0: b.hs            #0x633408
    // 0x6331f4: ArrayLoad: r0 = r4[r2]  ; Unknown_4
    //     0x6331f4: add             x16, x4, x2, lsl #2
    //     0x6331f8: ldur            w0, [x16, #0xf]
    // 0x6331fc: DecompressPointer r0
    //     0x6331fc: add             x0, x0, HEAP, lsl #32
    // 0x633200: LoadField: d3 = r6->field_7
    //     0x633200: ldur            d3, [x6, #7]
    // 0x633204: LoadField: d5 = r0->field_7
    //     0x633204: ldur            d5, [x0, #7]
    // 0x633208: fsub            d6, d3, d5
    // 0x63320c: fcmp            d6, d1
    // 0x633210: b.vs            #0x6332cc
    // 0x633214: b.le            #0x6332cc
    // 0x633218: fcmp            d6, d4
    // 0x63321c: b.vs            #0x633260
    // 0x633220: b.gt            #0x633260
    // 0x633224: fsub            d5, d2, d6
    // 0x633228: mov             x1, x3
    // 0x63322c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x63322c: add             x25, x1, x2, lsl #2
    //     0x633230: add             x25, x25, #0xf
    //     0x633234: str             w0, [x25]
    //     0x633238: tbz             w0, #0, #0x633254
    //     0x63323c: ldurb           w16, [x1, #-1]
    //     0x633240: ldurb           w17, [x0, #-1]
    //     0x633244: and             x16, x17, x16, lsr #2
    //     0x633248: tst             x16, HEAP, lsr #32
    //     0x63324c: b.eq            #0x633254
    //     0x633250: bl              #0xd67e5c
    // 0x633254: mov             v3.16b, v5.16b
    // 0x633258: mov             x1, x5
    // 0x63325c: b               #0x6332c4
    // 0x633260: fsub            d5, d2, d4
    // 0x633264: fsub            d6, d3, d4
    // 0x633268: r0 = inline_Allocate_Double()
    //     0x633268: ldp             x0, x6, [THR, #0x60]  ; THR::top
    //     0x63326c: add             x0, x0, #0x10
    //     0x633270: cmp             x6, x0
    //     0x633274: b.ls            #0x63340c
    //     0x633278: str             x0, [THR, #0x60]  ; THR::top
    //     0x63327c: sub             x0, x0, #0xf
    //     0x633280: mov             x6, #0xd108
    //     0x633284: movk            x6, #3, lsl #16
    //     0x633288: stur            x6, [x0, #-1]
    // 0x63328c: StoreField: r0->field_7 = d6
    //     0x63328c: stur            d6, [x0, #7]
    // 0x633290: mov             x1, x3
    // 0x633294: ArrayStore: r1[r2] = r0  ; List_4
    //     0x633294: add             x25, x1, x2, lsl #2
    //     0x633298: add             x25, x25, #0xf
    //     0x63329c: str             w0, [x25]
    //     0x6332a0: tbz             w0, #0, #0x6332bc
    //     0x6332a4: ldurb           w16, [x1, #-1]
    //     0x6332a8: ldurb           w17, [x0, #-1]
    //     0x6332ac: and             x16, x17, x16, lsr #2
    //     0x6332b0: tst             x16, HEAP, lsr #32
    //     0x6332b4: b.eq            #0x6332bc
    //     0x6332b8: bl              #0xd67e5c
    // 0x6332bc: add             x1, x5, #1
    // 0x6332c0: mov             v3.16b, v5.16b
    // 0x6332c4: mov             v2.16b, v3.16b
    // 0x6332c8: mov             x5, x1
    // 0x6332cc: add             x0, x2, #1
    // 0x6332d0: mov             x2, x0
    // 0x6332d4: b               #0x6331b4
    // 0x6332d8: mov             x2, x5
    // 0x6332dc: b               #0x633184
    // 0x6332e0: mov             x0, x3
    // 0x6332e4: LeaveFrame
    //     0x6332e4: mov             SP, fp
    //     0x6332e8: ldp             fp, lr, [SP], #0x10
    // 0x6332ec: ret
    //     0x6332ec: ret             
    // 0x6332f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6332f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6332f4: b               #0x632c10
    // 0x6332f8: r0 = StackOverflowSharedWithFPURegs()
    //     0x6332f8: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x6332fc: b               #0x632cc8
    // 0x633300: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x633300: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x633304: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x633304: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x633308: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x633308: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x63330c: r0 = StackOverflowSharedWithFPURegs()
    //     0x63330c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x633310: b               #0x632e1c
    // 0x633314: r0 = RangeErrorSharedWithFPURegs()
    //     0x633314: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x633318: r0 = RangeErrorSharedWithFPURegs()
    //     0x633318: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x63331c: stp             q6, q7, [SP, #-0x20]!
    // 0x633320: stp             q2, q5, [SP, #-0x20]!
    // 0x633324: stp             q0, q1, [SP, #-0x20]!
    // 0x633328: stp             x5, x7, [SP, #-0x10]!
    // 0x63332c: stp             x3, x4, [SP, #-0x10]!
    // 0x633330: SaveReg r2
    //     0x633330: str             x2, [SP, #-8]!
    // 0x633334: r0 = AllocateDouble()
    //     0x633334: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x633338: RestoreReg r2
    //     0x633338: ldr             x2, [SP], #8
    // 0x63333c: ldp             x3, x4, [SP], #0x10
    // 0x633340: ldp             x5, x7, [SP], #0x10
    // 0x633344: ldp             q0, q1, [SP], #0x20
    // 0x633348: ldp             q2, q5, [SP], #0x20
    // 0x63334c: ldp             q6, q7, [SP], #0x20
    // 0x633350: b               #0x632eac
    // 0x633354: r0 = StackOverflowSharedWithFPURegs()
    //     0x633354: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x633358: b               #0x632f2c
    // 0x63335c: r0 = RangeErrorSharedWithFPURegs()
    //     0x63335c: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x633360: stp             q5, q6, [SP, #-0x20]!
    // 0x633364: stp             q2, q3, [SP, #-0x20]!
    // 0x633368: stp             q0, q1, [SP, #-0x20]!
    // 0x63336c: stp             x5, x7, [SP, #-0x10]!
    // 0x633370: stp             x3, x4, [SP, #-0x10]!
    // 0x633374: SaveReg r2
    //     0x633374: str             x2, [SP, #-8]!
    // 0x633378: r0 = AllocateDouble()
    //     0x633378: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63337c: RestoreReg r2
    //     0x63337c: ldr             x2, [SP], #8
    // 0x633380: ldp             x3, x4, [SP], #0x10
    // 0x633384: ldp             x5, x7, [SP], #0x10
    // 0x633388: ldp             q0, q1, [SP], #0x20
    // 0x63338c: ldp             q2, q3, [SP], #0x20
    // 0x633390: ldp             q5, q6, [SP], #0x20
    // 0x633394: b               #0x632f7c
    // 0x633398: r0 = StackOverflowSharedWithFPURegs()
    //     0x633398: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x63339c: b               #0x632fec
    // 0x6333a0: r0 = StackOverflowSharedWithFPURegs()
    //     0x6333a0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x6333a4: b               #0x633020
    // 0x6333a8: r0 = RangeErrorSharedWithFPURegs()
    //     0x6333a8: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x6333ac: r0 = RangeErrorSharedWithFPURegs()
    //     0x6333ac: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x6333b0: r0 = RangeErrorSharedWithFPURegs()
    //     0x6333b0: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x6333b4: stp             q7, q9, [SP, #-0x20]!
    // 0x6333b8: stp             q4, q6, [SP, #-0x20]!
    // 0x6333bc: stp             q1, q3, [SP, #-0x20]!
    // 0x6333c0: SaveReg d0
    //     0x6333c0: str             q0, [SP, #-0x10]!
    // 0x6333c4: stp             x6, x7, [SP, #-0x10]!
    // 0x6333c8: stp             x4, x5, [SP, #-0x10]!
    // 0x6333cc: stp             x2, x3, [SP, #-0x10]!
    // 0x6333d0: r0 = AllocateDouble()
    //     0x6333d0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6333d4: ldp             x2, x3, [SP], #0x10
    // 0x6333d8: ldp             x4, x5, [SP], #0x10
    // 0x6333dc: ldp             x6, x7, [SP], #0x10
    // 0x6333e0: RestoreReg d0
    //     0x6333e0: ldr             q0, [SP], #0x10
    // 0x6333e4: ldp             q1, q3, [SP], #0x20
    // 0x6333e8: ldp             q4, q6, [SP], #0x20
    // 0x6333ec: ldp             q7, q9, [SP], #0x20
    // 0x6333f0: b               #0x633120
    // 0x6333f4: r0 = StackOverflowSharedWithFPURegs()
    //     0x6333f4: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x6333f8: b               #0x633190
    // 0x6333fc: r0 = StackOverflowSharedWithFPURegs()
    //     0x6333fc: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x633400: b               #0x6331c0
    // 0x633404: r0 = RangeErrorSharedWithFPURegs()
    //     0x633404: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x633408: r0 = RangeErrorSharedWithFPURegs()
    //     0x633408: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x63340c: stp             q5, q6, [SP, #-0x20]!
    // 0x633410: stp             q1, q4, [SP, #-0x20]!
    // 0x633414: SaveReg d0
    //     0x633414: str             q0, [SP, #-0x10]!
    // 0x633418: stp             x5, x7, [SP, #-0x10]!
    // 0x63341c: stp             x3, x4, [SP, #-0x10]!
    // 0x633420: SaveReg r2
    //     0x633420: str             x2, [SP, #-8]!
    // 0x633424: r0 = AllocateDouble()
    //     0x633424: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x633428: RestoreReg r2
    //     0x633428: ldr             x2, [SP], #8
    // 0x63342c: ldp             x3, x4, [SP], #0x10
    // 0x633430: ldp             x5, x7, [SP], #0x10
    // 0x633434: RestoreReg d0
    //     0x633434: ldr             q0, [SP], #0x10
    // 0x633438: ldp             q1, q4, [SP], #0x20
    // 0x63343c: ldp             q5, q6, [SP], #0x20
    // 0x633440: b               #0x63328c
  }
  _ column(/* No info */) {
    // ** addr: 0x633444, size: 0x128
    // 0x633444: EnterFrame
    //     0x633444: stp             fp, lr, [SP, #-0x10]!
    //     0x633448: mov             fp, SP
    // 0x63344c: AllocStack(0x20)
    //     0x63344c: sub             SP, SP, #0x20
    // 0x633450: SetupParameters(RenderTable this /* r2, fp-0x18 */, dynamic _ /* r3, fp-0x10 */)
    //     0x633450: stur            NULL, [fp, #-8]
    //     0x633454: mov             x1, #0
    //     0x633458: add             x2, fp, w1, sxtw #2
    //     0x63345c: ldr             x2, [x2, #0x18]
    //     0x633460: stur            x2, [fp, #-0x18]
    //     0x633464: add             x3, fp, w1, sxtw #2
    //     0x633468: ldr             x3, [x3, #0x10]
    //     0x63346c: stur            x3, [fp, #-0x10]
    // 0x633470: CheckStackOverflow
    //     0x633470: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x633474: cmp             SP, x16
    //     0x633478: b.ls            #0x63355c
    // 0x63347c: InitAsync() -> Future<RenderBox>
    //     0x63347c: ldr             x0, [PP, #0x3b20]  ; [pp+0x3b20] TypeArguments: <RenderBox>
    //     0x633480: bl              #0x505ad0
    // 0x633484: r0 = Null
    //     0x633484: mov             x0, NULL
    // 0x633488: r0 = SuspendSyncStarAtStart()
    //     0x633488: bl              #0x505954  ; SuspendSyncStarAtStartStub
    // 0x63348c: r4 = 0
    //     0x63348c: mov             x4, #0
    // 0x633490: ldur            x2, [fp, #-0x18]
    // 0x633494: ldur            x3, [fp, #-0x10]
    // 0x633498: stur            x4, [fp, #-0x20]
    // 0x63349c: CheckStackOverflow
    //     0x63349c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6334a0: cmp             SP, x16
    //     0x6334a4: b.ls            #0x633564
    // 0x6334a8: LoadField: r0 = r2->field_6b
    //     0x6334a8: ldur            x0, [x2, #0x6b]
    // 0x6334ac: cmp             x4, x0
    // 0x6334b0: b.ge            #0x63354c
    // 0x6334b4: LoadField: r0 = r2->field_63
    //     0x6334b4: ldur            x0, [x2, #0x63]
    // 0x6334b8: mul             x1, x4, x0
    // 0x6334bc: add             x5, x3, x1
    // 0x6334c0: LoadField: r6 = r2->field_5f
    //     0x6334c0: ldur            w6, [x2, #0x5f]
    // 0x6334c4: DecompressPointer r6
    //     0x6334c4: add             x6, x6, HEAP, lsl #32
    // 0x6334c8: r0 = BoxInt64Instr(r5)
    //     0x6334c8: sbfiz           x0, x5, #1, #0x1f
    //     0x6334cc: cmp             x5, x0, asr #1
    //     0x6334d0: b.eq            #0x6334dc
    //     0x6334d4: bl              #0xd69bb8
    //     0x6334d8: stur            x5, [x0, #7]
    // 0x6334dc: r1 = LoadClassIdInstr(r6)
    //     0x6334dc: ldur            x1, [x6, #-1]
    //     0x6334e0: ubfx            x1, x1, #0xc, #0x14
    // 0x6334e4: stp             x0, x6, [SP, #-0x10]!
    // 0x6334e8: mov             x0, x1
    // 0x6334ec: r0 = GDT[cid_x0 + -0xd83]()
    //     0x6334ec: sub             lr, x0, #0xd83
    //     0x6334f0: ldr             lr, [x21, lr, lsl #3]
    //     0x6334f4: blr             lr
    // 0x6334f8: add             SP, SP, #0x10
    // 0x6334fc: cmp             w0, NULL
    // 0x633500: b.eq            #0x633540
    // 0x633504: r1 = 0
    //     0x633504: mov             x1, #0
    // 0x633508: add             x2, fp, w1, sxtw #2
    // 0x63350c: LoadField: r2 = r2->field_fffffff8
    //     0x63350c: ldur            x2, [x2, #-8]
    // 0x633510: LoadField: r3 = r2->field_17
    //     0x633510: ldur            w3, [x2, #0x17]
    // 0x633514: DecompressPointer r3
    //     0x633514: add             x3, x3, HEAP, lsl #32
    // 0x633518: StoreField: r3->field_17 = r0
    //     0x633518: stur            w0, [x3, #0x17]
    //     0x63351c: tbz             w0, #0, #0x633538
    //     0x633520: ldurb           w16, [x3, #-1]
    //     0x633524: ldurb           w17, [x0, #-1]
    //     0x633528: and             x16, x17, x16, lsr #2
    //     0x63352c: tst             x16, HEAP, lsr #32
    //     0x633530: b.eq            #0x633538
    //     0x633534: bl              #0xd682ac
    // 0x633538: r0 = true
    //     0x633538: add             x0, NULL, #0x20  ; true
    // 0x63353c: r0 = SuspendSyncStarAtYield()
    //     0x63353c: bl              #0x5057dc  ; SuspendSyncStarAtYieldStub
    // 0x633540: ldur            x1, [fp, #-0x20]
    // 0x633544: add             x4, x1, #1
    // 0x633548: b               #0x633490
    // 0x63354c: r0 = false
    //     0x63354c: add             x0, NULL, #0x30  ; false
    // 0x633550: LeaveFrame
    //     0x633550: mov             SP, fp
    //     0x633554: ldp             fp, lr, [SP], #0x10
    // 0x633558: ret
    //     0x633558: ret             
    // 0x63355c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63355c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x633560: b               #0x63347c
    // 0x633564: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x633564: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x633568: b               #0x6334a8
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x637188, size: 0x18
    // 0x637188: r4 = 0
    //     0x637188: mov             x4, #0
    // 0x63718c: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x63718c: add             x17, PP, #0x57, lsl #12  ; [pp+0x576e0] AnonymousClosure: (0x6371a0), in [package:flutter/src/rendering/table.dart] RenderTable::computeMinIntrinsicWidth (0x6371ec)
    //     0x637190: ldr             x1, [x17, #0x6e0]
    // 0x637194: r24 = BuildNonGenericMethodExtractorStub
    //     0x637194: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x637198: LoadField: r0 = r24->field_17
    //     0x637198: ldur            x0, [x24, #0x17]
    // 0x63719c: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x6371a0, size: 0x4c
    // 0x6371a0: EnterFrame
    //     0x6371a0: stp             fp, lr, [SP, #-0x10]!
    //     0x6371a4: mov             fp, SP
    // 0x6371a8: ldr             x0, [fp, #0x18]
    // 0x6371ac: LoadField: r1 = r0->field_17
    //     0x6371ac: ldur            w1, [x0, #0x17]
    // 0x6371b0: DecompressPointer r1
    //     0x6371b0: add             x1, x1, HEAP, lsl #32
    // 0x6371b4: CheckStackOverflow
    //     0x6371b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6371b8: cmp             SP, x16
    //     0x6371bc: b.ls            #0x6371e4
    // 0x6371c0: LoadField: r0 = r1->field_f
    //     0x6371c0: ldur            w0, [x1, #0xf]
    // 0x6371c4: DecompressPointer r0
    //     0x6371c4: add             x0, x0, HEAP, lsl #32
    // 0x6371c8: ldr             x16, [fp, #0x10]
    // 0x6371cc: stp             x16, x0, [SP, #-0x10]!
    // 0x6371d0: r0 = computeMinIntrinsicWidth()
    //     0x6371d0: bl              #0x6371ec  ; [package:flutter/src/rendering/table.dart] RenderTable::computeMinIntrinsicWidth
    // 0x6371d4: add             SP, SP, #0x10
    // 0x6371d8: LeaveFrame
    //     0x6371d8: mov             SP, fp
    //     0x6371dc: ldp             fp, lr, [SP], #0x10
    // 0x6371e0: ret
    //     0x6371e0: ret             
    // 0x6371e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6371e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6371e8: b               #0x6371c0
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0x6371ec, size: 0xbc
    // 0x6371ec: EnterFrame
    //     0x6371ec: stp             fp, lr, [SP, #-0x10]!
    //     0x6371f0: mov             fp, SP
    // 0x6371f4: AllocStack(0x8)
    //     0x6371f4: sub             SP, SP, #8
    // 0x6371f8: CheckStackOverflow
    //     0x6371f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6371fc: cmp             SP, x16
    //     0x637200: b.ls            #0x637298
    // 0x637204: r3 = 0
    //     0x637204: mov             x3, #0
    // 0x637208: ldr             x2, [fp, #0x18]
    // 0x63720c: stur            x3, [fp, #-8]
    // 0x637210: CheckStackOverflow
    //     0x637210: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x637214: cmp             SP, x16
    //     0x637218: b.ls            #0x6372a0
    // 0x63721c: LoadField: r0 = r2->field_63
    //     0x63721c: ldur            x0, [x2, #0x63]
    // 0x637220: cmp             x3, x0
    // 0x637224: b.ge            #0x637288
    // 0x637228: LoadField: r4 = r2->field_73
    //     0x637228: ldur            w4, [x2, #0x73]
    // 0x63722c: DecompressPointer r4
    //     0x63722c: add             x4, x4, HEAP, lsl #32
    // 0x637230: r0 = BoxInt64Instr(r3)
    //     0x637230: sbfiz           x0, x3, #1, #0x1f
    //     0x637234: cmp             x3, x0, asr #1
    //     0x637238: b.eq            #0x637244
    //     0x63723c: bl              #0xd69bb8
    //     0x637240: stur            x3, [x0, #7]
    // 0x637244: r1 = LoadClassIdInstr(r4)
    //     0x637244: ldur            x1, [x4, #-1]
    //     0x637248: ubfx            x1, x1, #0xc, #0x14
    // 0x63724c: stp             x0, x4, [SP, #-0x10]!
    // 0x637250: mov             x0, x1
    // 0x637254: r0 = GDT[cid_x0 + -0xef]()
    //     0x637254: sub             lr, x0, #0xef
    //     0x637258: ldr             lr, [x21, lr, lsl #3]
    //     0x63725c: blr             lr
    // 0x637260: add             SP, SP, #0x10
    // 0x637264: ldr             x16, [fp, #0x18]
    // 0x637268: SaveReg r16
    //     0x637268: str             x16, [SP, #-8]!
    // 0x63726c: ldur            x0, [fp, #-8]
    // 0x637270: SaveReg r0
    //     0x637270: str             x0, [SP, #-8]!
    // 0x637274: r0 = column()
    //     0x637274: bl              #0x633444  ; [package:flutter/src/rendering/table.dart] RenderTable::column
    // 0x637278: add             SP, SP, #0x10
    // 0x63727c: ldur            x1, [fp, #-8]
    // 0x637280: add             x3, x1, #1
    // 0x637284: b               #0x637208
    // 0x637288: r0 = 0.000000
    //     0x637288: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x63728c: LeaveFrame
    //     0x63728c: mov             SP, fp
    //     0x637290: ldp             fp, lr, [SP], #0x10
    // 0x637294: ret
    //     0x637294: ret             
    // 0x637298: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x637298: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63729c: b               #0x637204
    // 0x6372a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6372a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6372a4: b               #0x63721c
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x6372a8, size: 0x4c
    // 0x6372a8: EnterFrame
    //     0x6372a8: stp             fp, lr, [SP, #-0x10]!
    //     0x6372ac: mov             fp, SP
    // 0x6372b0: ldr             x0, [fp, #0x18]
    // 0x6372b4: LoadField: r1 = r0->field_17
    //     0x6372b4: ldur            w1, [x0, #0x17]
    // 0x6372b8: DecompressPointer r1
    //     0x6372b8: add             x1, x1, HEAP, lsl #32
    // 0x6372bc: CheckStackOverflow
    //     0x6372bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6372c0: cmp             SP, x16
    //     0x6372c4: b.ls            #0x6372ec
    // 0x6372c8: LoadField: r0 = r1->field_f
    //     0x6372c8: ldur            w0, [x1, #0xf]
    // 0x6372cc: DecompressPointer r0
    //     0x6372cc: add             x0, x0, HEAP, lsl #32
    // 0x6372d0: ldr             x16, [fp, #0x10]
    // 0x6372d4: stp             x16, x0, [SP, #-0x10]!
    // 0x6372d8: r0 = computeMinIntrinsicWidth()
    //     0x6372d8: bl              #0x6371ec  ; [package:flutter/src/rendering/table.dart] RenderTable::computeMinIntrinsicWidth
    // 0x6372dc: add             SP, SP, #0x10
    // 0x6372e0: LeaveFrame
    //     0x6372e0: mov             SP, fp
    //     0x6372e4: ldp             fp, lr, [SP], #0x10
    // 0x6372e8: ret
    //     0x6372e8: ret             
    // 0x6372ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6372ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6372f0: b               #0x6372c8
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x639afc, size: 0x18
    // 0x639afc: r4 = 0
    //     0x639afc: mov             x4, #0
    // 0x639b00: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x639b00: add             x17, PP, #0x57, lsl #12  ; [pp+0x576d8] AnonymousClosure: (0x632bac), in [package:flutter/src/rendering/table.dart] RenderTable::computeMinIntrinsicHeight (0x6328a4)
    //     0x639b04: ldr             x1, [x17, #0x6d8]
    // 0x639b08: r24 = BuildNonGenericMethodExtractorStub
    //     0x639b08: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x639b0c: LoadField: r0 = r24->field_17
    //     0x639b0c: ldur            x0, [x24, #0x17]
    // 0x639b10: br              x0
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63cdfc, size: 0x18
    // 0x63cdfc: r4 = 0
    //     0x63cdfc: mov             x4, #0
    // 0x63ce00: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63ce00: add             x17, PP, #0x57, lsl #12  ; [pp+0x576e8] AnonymousClosure: (0x6372a8), in [package:flutter/src/rendering/table.dart] RenderTable::computeMinIntrinsicWidth (0x6371ec)
    //     0x63ce04: ldr             x1, [x17, #0x6e8]
    // 0x63ce08: r24 = BuildNonGenericMethodExtractorStub
    //     0x63ce08: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63ce0c: LoadField: r0 = r24->field_17
    //     0x63ce0c: ldur            x0, [x24, #0x17]
    // 0x63ce10: br              x0
  }
  _ computeDistanceToActualBaseline(/* No info */) {
    // ** addr: 0x63ec70, size: 0x10
    // 0x63ec70: ldr             x1, [SP, #8]
    // 0x63ec74: LoadField: r0 = r1->field_97
    //     0x63ec74: ldur            w0, [x1, #0x97]
    // 0x63ec78: DecompressPointer r0
    //     0x63ec78: add             x0, x0, HEAP, lsl #32
    // 0x63ec7c: ret
    //     0x63ec7c: ret             
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0x64ba9c, size: 0x64
    // 0x64ba9c: EnterFrame
    //     0x64ba9c: stp             fp, lr, [SP, #-0x10]!
    //     0x64baa0: mov             fp, SP
    // 0x64baa4: ldr             x0, [fp, #0x10]
    // 0x64baa8: LoadField: r1 = r0->field_17
    //     0x64baa8: ldur            w1, [x0, #0x17]
    // 0x64baac: DecompressPointer r1
    //     0x64baac: add             x1, x1, HEAP, lsl #32
    // 0x64bab0: r2 = LoadClassIdInstr(r1)
    //     0x64bab0: ldur            x2, [x1, #-1]
    //     0x64bab4: ubfx            x2, x2, #0xc, #0x14
    // 0x64bab8: lsl             x2, x2, #1
    // 0x64babc: cmp             w2, #1, lsl #12
    // 0x64bac0: b.eq            #0x64baf0
    // 0x64bac4: r0 = TableCellParentData()
    //     0x64bac4: bl              #0x64bb00  ; AllocateTableCellParentDataStub -> TableCellParentData (size=0x10)
    // 0x64bac8: r1 = Instance_Offset
    //     0x64bac8: ldr             x1, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x64bacc: StoreField: r0->field_7 = r1
    //     0x64bacc: stur            w1, [x0, #7]
    // 0x64bad0: ldr             x1, [fp, #0x10]
    // 0x64bad4: StoreField: r1->field_17 = r0
    //     0x64bad4: stur            w0, [x1, #0x17]
    //     0x64bad8: ldurb           w16, [x1, #-1]
    //     0x64badc: ldurb           w17, [x0, #-1]
    //     0x64bae0: and             x16, x17, x16, lsr #2
    //     0x64bae4: tst             x16, HEAP, lsr #32
    //     0x64bae8: b.eq            #0x64baf0
    //     0x64baec: bl              #0xd6826c
    // 0x64baf0: r0 = Null
    //     0x64baf0: mov             x0, NULL
    // 0x64baf4: LeaveFrame
    //     0x64baf4: mov             SP, fp
    //     0x64baf8: ldp             fp, lr, [SP], #0x10
    // 0x64bafc: ret
    //     0x64bafc: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0x66f7e0, size: 0x810
    // 0x66f7e0: EnterFrame
    //     0x66f7e0: stp             fp, lr, [SP, #-0x10]!
    //     0x66f7e4: mov             fp, SP
    // 0x66f7e8: AllocStack(0x90)
    //     0x66f7e8: sub             SP, SP, #0x90
    // 0x66f7ec: CheckStackOverflow
    //     0x66f7ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66f7f0: cmp             SP, x16
    //     0x66f7f4: b.ls            #0x66ff88
    // 0x66f7f8: ldr             x0, [fp, #0x20]
    // 0x66f7fc: LoadField: r1 = r0->field_6b
    //     0x66f7fc: ldur            x1, [x0, #0x6b]
    // 0x66f800: LoadField: r2 = r0->field_63
    //     0x66f800: ldur            x2, [x0, #0x63]
    // 0x66f804: mul             x3, x1, x2
    // 0x66f808: cbnz            x3, #0x66f8c4
    // 0x66f80c: ldr             x1, [fp, #0x10]
    // 0x66f810: d0 = 0.000000
    //     0x66f810: eor             v0.16b, v0.16b, v0.16b
    // 0x66f814: LoadField: d1 = r1->field_7
    //     0x66f814: ldur            d1, [x1, #7]
    // 0x66f818: stur            d1, [fp, #-0x88]
    // 0x66f81c: LoadField: d2 = r1->field_f
    //     0x66f81c: ldur            d2, [x1, #0xf]
    // 0x66f820: stur            d2, [fp, #-0x80]
    // 0x66f824: LoadField: r1 = r0->field_a3
    //     0x66f824: ldur            w1, [x0, #0xa3]
    // 0x66f828: DecompressPointer r1
    //     0x66f828: add             x1, x1, HEAP, lsl #32
    // 0x66f82c: r16 = Sentinel
    //     0x66f82c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x66f830: cmp             w1, w16
    // 0x66f834: b.eq            #0x66ff90
    // 0x66f838: LoadField: d3 = r1->field_7
    //     0x66f838: ldur            d3, [x1, #7]
    // 0x66f83c: fadd            d4, d1, d3
    // 0x66f840: stur            d4, [fp, #-0x78]
    // 0x66f844: fadd            d3, d2, d0
    // 0x66f848: stur            d3, [fp, #-0x70]
    // 0x66f84c: r0 = Rect()
    //     0x66f84c: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x66f850: ldur            d0, [fp, #-0x88]
    // 0x66f854: stur            x0, [fp, #-8]
    // 0x66f858: StoreField: r0->field_7 = d0
    //     0x66f858: stur            d0, [x0, #7]
    // 0x66f85c: ldur            d0, [fp, #-0x80]
    // 0x66f860: StoreField: r0->field_f = d0
    //     0x66f860: stur            d0, [x0, #0xf]
    // 0x66f864: ldur            d0, [fp, #-0x78]
    // 0x66f868: StoreField: r0->field_17 = d0
    //     0x66f868: stur            d0, [x0, #0x17]
    // 0x66f86c: ldur            d0, [fp, #-0x70]
    // 0x66f870: StoreField: r0->field_1f = d0
    //     0x66f870: stur            d0, [x0, #0x1f]
    // 0x66f874: ldr             x16, [fp, #0x18]
    // 0x66f878: SaveReg r16
    //     0x66f878: str             x16, [SP, #-8]!
    // 0x66f87c: r0 = canvas()
    //     0x66f87c: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x66f880: add             SP, SP, #8
    // 0x66f884: r16 = Instance_TableBorder
    //     0x66f884: add             x16, PP, #0x46, lsl #12  ; [pp+0x46e98] Obj!TableBorder@b35221
    //     0x66f888: ldr             x16, [x16, #0xe98]
    // 0x66f88c: stp             x0, x16, [SP, #-0x10]!
    // 0x66f890: ldur            x16, [fp, #-8]
    // 0x66f894: r30 = const []
    //     0x66f894: add             lr, PP, #0x57, lsl #12  ; [pp+0x576f0] List<double>(0)
    //     0x66f898: ldr             lr, [lr, #0x6f0]
    // 0x66f89c: stp             lr, x16, [SP, #-0x10]!
    // 0x66f8a0: r16 = const []
    //     0x66f8a0: add             x16, PP, #0x57, lsl #12  ; [pp+0x576f0] List<double>(0)
    //     0x66f8a4: ldr             x16, [x16, #0x6f0]
    // 0x66f8a8: SaveReg r16
    //     0x66f8a8: str             x16, [SP, #-8]!
    // 0x66f8ac: r0 = paint()
    //     0x66f8ac: bl              #0x66fff0  ; [package:flutter/src/rendering/table_border.dart] TableBorder::paint
    // 0x66f8b0: add             SP, SP, #0x28
    // 0x66f8b4: r0 = Null
    //     0x66f8b4: mov             x0, NULL
    // 0x66f8b8: LeaveFrame
    //     0x66f8b8: mov             SP, fp
    //     0x66f8bc: ldp             fp, lr, [SP], #0x10
    // 0x66f8c0: ret
    //     0x66f8c0: ret             
    // 0x66f8c4: ldr             x1, [fp, #0x10]
    // 0x66f8c8: LoadField: r2 = r0->field_83
    //     0x66f8c8: ldur            w2, [x0, #0x83]
    // 0x66f8cc: DecompressPointer r2
    //     0x66f8cc: add             x2, x2, HEAP, lsl #32
    // 0x66f8d0: cmp             w2, NULL
    // 0x66f8d4: b.eq            #0x66fcd0
    // 0x66f8d8: ldr             x16, [fp, #0x18]
    // 0x66f8dc: SaveReg r16
    //     0x66f8dc: str             x16, [SP, #-8]!
    // 0x66f8e0: r0 = canvas()
    //     0x66f8e0: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x66f8e4: add             SP, SP, #8
    // 0x66f8e8: mov             x2, x0
    // 0x66f8ec: ldr             x1, [fp, #0x10]
    // 0x66f8f0: stur            x2, [fp, #-0x18]
    // 0x66f8f4: LoadField: d0 = r1->field_7
    //     0x66f8f4: ldur            d0, [x1, #7]
    // 0x66f8f8: stur            d0, [fp, #-0x78]
    // 0x66f8fc: LoadField: d1 = r1->field_f
    //     0x66f8fc: ldur            d1, [x1, #0xf]
    // 0x66f900: ldr             x3, [fp, #0x20]
    // 0x66f904: stur            d1, [fp, #-0x70]
    // 0x66f908: LoadField: r4 = r3->field_9b
    //     0x66f908: ldur            w4, [x3, #0x9b]
    // 0x66f90c: DecompressPointer r4
    //     0x66f90c: add             x4, x4, HEAP, lsl #32
    // 0x66f910: stur            x4, [fp, #-8]
    // 0x66f914: r5 = 0
    //     0x66f914: mov             x5, #0
    // 0x66f918: stur            x5, [fp, #-0x10]
    // 0x66f91c: CheckStackOverflow
    //     0x66f91c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66f920: cmp             SP, x16
    //     0x66f924: b.ls            #0x66ff9c
    // 0x66f928: LoadField: r0 = r3->field_6b
    //     0x66f928: ldur            x0, [x3, #0x6b]
    // 0x66f92c: cmp             x5, x0
    // 0x66f930: b.ge            #0x66fcd0
    // 0x66f934: LoadField: r0 = r3->field_83
    //     0x66f934: ldur            w0, [x3, #0x83]
    // 0x66f938: DecompressPointer r0
    //     0x66f938: add             x0, x0, HEAP, lsl #32
    // 0x66f93c: cmp             w0, NULL
    // 0x66f940: b.eq            #0x66ffa4
    // 0x66f944: r6 = LoadClassIdInstr(r0)
    //     0x66f944: ldur            x6, [x0, #-1]
    //     0x66f948: ubfx            x6, x6, #0xc, #0x14
    // 0x66f94c: SaveReg r0
    //     0x66f94c: str             x0, [SP, #-8]!
    // 0x66f950: mov             x0, x6
    // 0x66f954: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x66f954: mov             x17, #0xb8ea
    //     0x66f958: add             lr, x0, x17
    //     0x66f95c: ldr             lr, [x21, lr, lsl #3]
    //     0x66f960: blr             lr
    // 0x66f964: add             SP, SP, #8
    // 0x66f968: r1 = LoadInt32Instr(r0)
    //     0x66f968: sbfx            x1, x0, #1, #0x1f
    // 0x66f96c: ldur            x2, [fp, #-0x10]
    // 0x66f970: cmp             x1, x2
    // 0x66f974: b.le            #0x66fcd0
    // 0x66f978: ldr             x3, [fp, #0x20]
    // 0x66f97c: LoadField: r4 = r3->field_83
    //     0x66f97c: ldur            w4, [x3, #0x83]
    // 0x66f980: DecompressPointer r4
    //     0x66f980: add             x4, x4, HEAP, lsl #32
    // 0x66f984: cmp             w4, NULL
    // 0x66f988: b.eq            #0x66ffa8
    // 0x66f98c: r0 = BoxInt64Instr(r2)
    //     0x66f98c: sbfiz           x0, x2, #1, #0x1f
    //     0x66f990: cmp             x2, x0, asr #1
    //     0x66f994: b.eq            #0x66f9a0
    //     0x66f998: bl              #0xd69bb8
    //     0x66f99c: stur            x2, [x0, #7]
    // 0x66f9a0: mov             x1, x0
    // 0x66f9a4: stur            x1, [fp, #-0x20]
    // 0x66f9a8: r0 = LoadClassIdInstr(r4)
    //     0x66f9a8: ldur            x0, [x4, #-1]
    //     0x66f9ac: ubfx            x0, x0, #0xc, #0x14
    // 0x66f9b0: stp             x1, x4, [SP, #-0x10]!
    // 0x66f9b4: r0 = GDT[cid_x0 + -0xd83]()
    //     0x66f9b4: sub             lr, x0, #0xd83
    //     0x66f9b8: ldr             lr, [x21, lr, lsl #3]
    //     0x66f9bc: blr             lr
    // 0x66f9c0: add             SP, SP, #0x10
    // 0x66f9c4: cmp             w0, NULL
    // 0x66f9c8: b.eq            #0x66fcac
    // 0x66f9cc: ldr             x3, [fp, #0x20]
    // 0x66f9d0: ldur            x2, [fp, #-0x10]
    // 0x66f9d4: LoadField: r4 = r3->field_87
    //     0x66f9d4: ldur            w4, [x3, #0x87]
    // 0x66f9d8: DecompressPointer r4
    //     0x66f9d8: add             x4, x4, HEAP, lsl #32
    // 0x66f9dc: stur            x4, [fp, #-0x28]
    // 0x66f9e0: cmp             w4, NULL
    // 0x66f9e4: b.eq            #0x66ffac
    // 0x66f9e8: LoadField: r0 = r4->field_b
    //     0x66f9e8: ldur            w0, [x4, #0xb]
    // 0x66f9ec: DecompressPointer r0
    //     0x66f9ec: add             x0, x0, HEAP, lsl #32
    // 0x66f9f0: r1 = LoadInt32Instr(r0)
    //     0x66f9f0: sbfx            x1, x0, #1, #0x1f
    // 0x66f9f4: mov             x0, x1
    // 0x66f9f8: mov             x1, x2
    // 0x66f9fc: cmp             x1, x0
    // 0x66fa00: b.hs            #0x66ffb0
    // 0x66fa04: ArrayLoad: r0 = r4[r2]  ; Unknown_4
    //     0x66fa04: add             x16, x4, x2, lsl #2
    //     0x66fa08: ldur            w0, [x16, #0xf]
    // 0x66fa0c: DecompressPointer r0
    //     0x66fa0c: add             x0, x0, HEAP, lsl #32
    // 0x66fa10: cmp             w0, NULL
    // 0x66fa14: b.ne            #0x66fad4
    // 0x66fa18: LoadField: r0 = r3->field_83
    //     0x66fa18: ldur            w0, [x3, #0x83]
    // 0x66fa1c: DecompressPointer r0
    //     0x66fa1c: add             x0, x0, HEAP, lsl #32
    // 0x66fa20: cmp             w0, NULL
    // 0x66fa24: b.eq            #0x66ffb4
    // 0x66fa28: r1 = LoadClassIdInstr(r0)
    //     0x66fa28: ldur            x1, [x0, #-1]
    //     0x66fa2c: ubfx            x1, x1, #0xc, #0x14
    // 0x66fa30: ldur            x16, [fp, #-0x20]
    // 0x66fa34: stp             x16, x0, [SP, #-0x10]!
    // 0x66fa38: mov             x0, x1
    // 0x66fa3c: r0 = GDT[cid_x0 + -0xd83]()
    //     0x66fa3c: sub             lr, x0, #0xd83
    //     0x66fa40: ldr             lr, [x21, lr, lsl #3]
    //     0x66fa44: blr             lr
    // 0x66fa48: add             SP, SP, #0x10
    // 0x66fa4c: stur            x0, [fp, #-0x20]
    // 0x66fa50: cmp             w0, NULL
    // 0x66fa54: b.eq            #0x66ffb8
    // 0x66fa58: r1 = 1
    //     0x66fa58: mov             x1, #1
    // 0x66fa5c: r0 = AllocateContext()
    //     0x66fa5c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x66fa60: mov             x1, x0
    // 0x66fa64: ldr             x0, [fp, #0x20]
    // 0x66fa68: StoreField: r1->field_f = r0
    //     0x66fa68: stur            w0, [x1, #0xf]
    // 0x66fa6c: mov             x2, x1
    // 0x66fa70: r1 = Function 'markNeedsPaint':.
    //     0x66fa70: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x66fa74: ldr             x1, [x1, #0xf60]
    // 0x66fa78: r0 = AllocateClosure()
    //     0x66fa78: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x66fa7c: mov             x1, x0
    // 0x66fa80: ldur            x0, [fp, #-0x20]
    // 0x66fa84: r2 = LoadClassIdInstr(r0)
    //     0x66fa84: ldur            x2, [x0, #-1]
    //     0x66fa88: ubfx            x2, x2, #0xc, #0x14
    // 0x66fa8c: stp             x1, x0, [SP, #-0x10]!
    // 0x66fa90: mov             x0, x2
    // 0x66fa94: r0 = GDT[cid_x0 + -0xc50]()
    //     0x66fa94: sub             lr, x0, #0xc50
    //     0x66fa98: ldr             lr, [x21, lr, lsl #3]
    //     0x66fa9c: blr             lr
    // 0x66faa0: add             SP, SP, #0x10
    // 0x66faa4: ldur            x1, [fp, #-0x28]
    // 0x66faa8: ldur            x2, [fp, #-0x10]
    // 0x66faac: ArrayStore: r1[r2] = r0  ; List_4
    //     0x66faac: add             x25, x1, x2, lsl #2
    //     0x66fab0: add             x25, x25, #0xf
    //     0x66fab4: str             w0, [x25]
    //     0x66fab8: tbz             w0, #0, #0x66fad4
    //     0x66fabc: ldurb           w16, [x1, #-1]
    //     0x66fac0: ldurb           w17, [x0, #-1]
    //     0x66fac4: and             x16, x17, x16, lsr #2
    //     0x66fac8: tst             x16, HEAP, lsr #32
    //     0x66facc: b.eq            #0x66fad4
    //     0x66fad0: bl              #0xd67e5c
    // 0x66fad4: ldr             x3, [fp, #0x20]
    // 0x66fad8: ldur            x4, [fp, #-8]
    // 0x66fadc: ldur            d0, [fp, #-0x78]
    // 0x66fae0: ldur            d1, [fp, #-0x70]
    // 0x66fae4: LoadField: r5 = r3->field_87
    //     0x66fae4: ldur            w5, [x3, #0x87]
    // 0x66fae8: DecompressPointer r5
    //     0x66fae8: add             x5, x5, HEAP, lsl #32
    // 0x66faec: cmp             w5, NULL
    // 0x66faf0: b.eq            #0x66ffbc
    // 0x66faf4: LoadField: r0 = r5->field_b
    //     0x66faf4: ldur            w0, [x5, #0xb]
    // 0x66faf8: DecompressPointer r0
    //     0x66faf8: add             x0, x0, HEAP, lsl #32
    // 0x66fafc: r1 = LoadInt32Instr(r0)
    //     0x66fafc: sbfx            x1, x0, #1, #0x1f
    // 0x66fb00: mov             x0, x1
    // 0x66fb04: mov             x1, x2
    // 0x66fb08: cmp             x1, x0
    // 0x66fb0c: b.hs            #0x66ffc0
    // 0x66fb10: ArrayLoad: r6 = r5[r2]  ; Unknown_4
    //     0x66fb10: add             x16, x5, x2, lsl #2
    //     0x66fb14: ldur            w6, [x16, #0xf]
    // 0x66fb18: DecompressPointer r6
    //     0x66fb18: add             x6, x6, HEAP, lsl #32
    // 0x66fb1c: stur            x6, [fp, #-0x28]
    // 0x66fb20: cmp             w6, NULL
    // 0x66fb24: b.eq            #0x66ffc4
    // 0x66fb28: LoadField: r0 = r4->field_b
    //     0x66fb28: ldur            w0, [x4, #0xb]
    // 0x66fb2c: DecompressPointer r0
    //     0x66fb2c: add             x0, x0, HEAP, lsl #32
    // 0x66fb30: r5 = LoadInt32Instr(r0)
    //     0x66fb30: sbfx            x5, x0, #1, #0x1f
    // 0x66fb34: mov             x0, x5
    // 0x66fb38: mov             x1, x2
    // 0x66fb3c: stur            x5, [fp, #-0x30]
    // 0x66fb40: cmp             x1, x0
    // 0x66fb44: b.hs            #0x66ffc8
    // 0x66fb48: LoadField: r0 = r4->field_f
    //     0x66fb48: ldur            w0, [x4, #0xf]
    // 0x66fb4c: DecompressPointer r0
    //     0x66fb4c: add             x0, x0, HEAP, lsl #32
    // 0x66fb50: stur            x0, [fp, #-0x20]
    // 0x66fb54: ArrayLoad: r1 = r0[r2]  ; Unknown_4
    //     0x66fb54: add             x16, x0, x2, lsl #2
    //     0x66fb58: ldur            w1, [x16, #0xf]
    // 0x66fb5c: DecompressPointer r1
    //     0x66fb5c: add             x1, x1, HEAP, lsl #32
    // 0x66fb60: LoadField: d2 = r1->field_7
    //     0x66fb60: ldur            d2, [x1, #7]
    // 0x66fb64: stur            d2, [fp, #-0x88]
    // 0x66fb68: fadd            d3, d1, d2
    // 0x66fb6c: stur            d3, [fp, #-0x80]
    // 0x66fb70: r0 = Offset()
    //     0x66fb70: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x66fb74: mov             x2, x0
    // 0x66fb78: ldur            d0, [fp, #-0x78]
    // 0x66fb7c: stur            x2, [fp, #-0x40]
    // 0x66fb80: StoreField: r2->field_7 = d0
    //     0x66fb80: stur            d0, [x2, #7]
    // 0x66fb84: ldur            d1, [fp, #-0x80]
    // 0x66fb88: StoreField: r2->field_f = d1
    //     0x66fb88: stur            d1, [x2, #0xf]
    // 0x66fb8c: ldr             x3, [fp, #0x20]
    // 0x66fb90: LoadField: r4 = r3->field_8b
    //     0x66fb90: ldur            w4, [x3, #0x8b]
    // 0x66fb94: DecompressPointer r4
    //     0x66fb94: add             x4, x4, HEAP, lsl #32
    // 0x66fb98: stur            x4, [fp, #-0x38]
    // 0x66fb9c: LoadField: r0 = r3->field_57
    //     0x66fb9c: ldur            w0, [x3, #0x57]
    // 0x66fba0: DecompressPointer r0
    //     0x66fba0: add             x0, x0, HEAP, lsl #32
    // 0x66fba4: cmp             w0, NULL
    // 0x66fba8: b.eq            #0x66ffcc
    // 0x66fbac: LoadField: d1 = r0->field_7
    //     0x66fbac: ldur            d1, [x0, #7]
    // 0x66fbb0: ldur            x5, [fp, #-0x10]
    // 0x66fbb4: stur            d1, [fp, #-0x90]
    // 0x66fbb8: add             x6, x5, #1
    // 0x66fbbc: ldur            x0, [fp, #-0x30]
    // 0x66fbc0: mov             x1, x6
    // 0x66fbc4: cmp             x1, x0
    // 0x66fbc8: b.hs            #0x66ffd0
    // 0x66fbcc: ldur            x0, [fp, #-0x20]
    // 0x66fbd0: ArrayLoad: r1 = r0[r6]  ; Unknown_4
    //     0x66fbd0: add             x16, x0, x6, lsl #2
    //     0x66fbd4: ldur            w1, [x16, #0xf]
    // 0x66fbd8: DecompressPointer r1
    //     0x66fbd8: add             x1, x1, HEAP, lsl #32
    // 0x66fbdc: LoadField: d2 = r1->field_7
    //     0x66fbdc: ldur            d2, [x1, #7]
    // 0x66fbe0: ldur            d3, [fp, #-0x88]
    // 0x66fbe4: fsub            d4, d2, d3
    // 0x66fbe8: stur            d4, [fp, #-0x80]
    // 0x66fbec: r0 = Size()
    //     0x66fbec: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x66fbf0: ldur            d0, [fp, #-0x90]
    // 0x66fbf4: stur            x0, [fp, #-0x68]
    // 0x66fbf8: StoreField: r0->field_7 = d0
    //     0x66fbf8: stur            d0, [x0, #7]
    // 0x66fbfc: ldur            d0, [fp, #-0x80]
    // 0x66fc00: StoreField: r0->field_f = d0
    //     0x66fc00: stur            d0, [x0, #0xf]
    // 0x66fc04: ldur            x1, [fp, #-0x38]
    // 0x66fc08: LoadField: r2 = r1->field_7
    //     0x66fc08: ldur            w2, [x1, #7]
    // 0x66fc0c: DecompressPointer r2
    //     0x66fc0c: add             x2, x2, HEAP, lsl #32
    // 0x66fc10: stur            x2, [fp, #-0x60]
    // 0x66fc14: LoadField: r3 = r1->field_b
    //     0x66fc14: ldur            w3, [x1, #0xb]
    // 0x66fc18: DecompressPointer r3
    //     0x66fc18: add             x3, x3, HEAP, lsl #32
    // 0x66fc1c: stur            x3, [fp, #-0x58]
    // 0x66fc20: LoadField: r4 = r1->field_f
    //     0x66fc20: ldur            w4, [x1, #0xf]
    // 0x66fc24: DecompressPointer r4
    //     0x66fc24: add             x4, x4, HEAP, lsl #32
    // 0x66fc28: stur            x4, [fp, #-0x50]
    // 0x66fc2c: LoadField: r5 = r1->field_13
    //     0x66fc2c: ldur            w5, [x1, #0x13]
    // 0x66fc30: DecompressPointer r5
    //     0x66fc30: add             x5, x5, HEAP, lsl #32
    // 0x66fc34: stur            x5, [fp, #-0x48]
    // 0x66fc38: LoadField: r6 = r1->field_1b
    //     0x66fc38: ldur            w6, [x1, #0x1b]
    // 0x66fc3c: DecompressPointer r6
    //     0x66fc3c: add             x6, x6, HEAP, lsl #32
    // 0x66fc40: stur            x6, [fp, #-0x20]
    // 0x66fc44: r0 = ImageConfiguration()
    //     0x66fc44: bl              #0x665610  ; AllocateImageConfigurationStub -> ImageConfiguration (size=0x20)
    // 0x66fc48: mov             x1, x0
    // 0x66fc4c: ldur            x0, [fp, #-0x60]
    // 0x66fc50: StoreField: r1->field_7 = r0
    //     0x66fc50: stur            w0, [x1, #7]
    // 0x66fc54: ldur            x0, [fp, #-0x58]
    // 0x66fc58: StoreField: r1->field_b = r0
    //     0x66fc58: stur            w0, [x1, #0xb]
    // 0x66fc5c: ldur            x0, [fp, #-0x50]
    // 0x66fc60: StoreField: r1->field_f = r0
    //     0x66fc60: stur            w0, [x1, #0xf]
    // 0x66fc64: ldur            x0, [fp, #-0x48]
    // 0x66fc68: StoreField: r1->field_13 = r0
    //     0x66fc68: stur            w0, [x1, #0x13]
    // 0x66fc6c: ldur            x0, [fp, #-0x68]
    // 0x66fc70: StoreField: r1->field_17 = r0
    //     0x66fc70: stur            w0, [x1, #0x17]
    // 0x66fc74: ldur            x0, [fp, #-0x20]
    // 0x66fc78: StoreField: r1->field_1b = r0
    //     0x66fc78: stur            w0, [x1, #0x1b]
    // 0x66fc7c: ldur            x0, [fp, #-0x28]
    // 0x66fc80: r2 = LoadClassIdInstr(r0)
    //     0x66fc80: ldur            x2, [x0, #-1]
    //     0x66fc84: ubfx            x2, x2, #0xc, #0x14
    // 0x66fc88: ldur            x16, [fp, #-0x18]
    // 0x66fc8c: stp             x16, x0, [SP, #-0x10]!
    // 0x66fc90: ldur            x16, [fp, #-0x40]
    // 0x66fc94: stp             x1, x16, [SP, #-0x10]!
    // 0x66fc98: mov             x0, x2
    // 0x66fc9c: r0 = GDT[cid_x0 + -0x3e]()
    //     0x66fc9c: sub             lr, x0, #0x3e
    //     0x66fca0: ldr             lr, [x21, lr, lsl #3]
    //     0x66fca4: blr             lr
    // 0x66fca8: add             SP, SP, #0x20
    // 0x66fcac: ldur            x0, [fp, #-0x10]
    // 0x66fcb0: add             x5, x0, #1
    // 0x66fcb4: ldr             x3, [fp, #0x20]
    // 0x66fcb8: ldr             x1, [fp, #0x10]
    // 0x66fcbc: ldur            x2, [fp, #-0x18]
    // 0x66fcc0: ldur            x4, [fp, #-8]
    // 0x66fcc4: ldur            d0, [fp, #-0x78]
    // 0x66fcc8: ldur            d1, [fp, #-0x70]
    // 0x66fccc: b               #0x66f918
    // 0x66fcd0: ldr             x0, [fp, #0x10]
    // 0x66fcd4: LoadField: d0 = r0->field_7
    //     0x66fcd4: ldur            d0, [x0, #7]
    // 0x66fcd8: stur            d0, [fp, #-0x78]
    // 0x66fcdc: LoadField: d1 = r0->field_f
    //     0x66fcdc: ldur            d1, [x0, #0xf]
    // 0x66fce0: stur            d1, [fp, #-0x70]
    // 0x66fce4: r2 = 0
    //     0x66fce4: mov             x2, #0
    // 0x66fce8: ldr             x1, [fp, #0x20]
    // 0x66fcec: stur            x2, [fp, #-0x10]
    // 0x66fcf0: CheckStackOverflow
    //     0x66fcf0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66fcf4: cmp             SP, x16
    //     0x66fcf8: b.ls            #0x66ffd4
    // 0x66fcfc: LoadField: r0 = r1->field_5f
    //     0x66fcfc: ldur            w0, [x1, #0x5f]
    // 0x66fd00: DecompressPointer r0
    //     0x66fd00: add             x0, x0, HEAP, lsl #32
    // 0x66fd04: r3 = LoadClassIdInstr(r0)
    //     0x66fd04: ldur            x3, [x0, #-1]
    //     0x66fd08: ubfx            x3, x3, #0xc, #0x14
    // 0x66fd0c: SaveReg r0
    //     0x66fd0c: str             x0, [SP, #-8]!
    // 0x66fd10: mov             x0, x3
    // 0x66fd14: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x66fd14: mov             x17, #0xb8ea
    //     0x66fd18: add             lr, x0, x17
    //     0x66fd1c: ldr             lr, [x21, lr, lsl #3]
    //     0x66fd20: blr             lr
    // 0x66fd24: add             SP, SP, #8
    // 0x66fd28: r1 = LoadInt32Instr(r0)
    //     0x66fd28: sbfx            x1, x0, #1, #0x1f
    // 0x66fd2c: ldur            x2, [fp, #-0x10]
    // 0x66fd30: cmp             x2, x1
    // 0x66fd34: b.ge            #0x66fe44
    // 0x66fd38: ldr             x3, [fp, #0x20]
    // 0x66fd3c: LoadField: r4 = r3->field_5f
    //     0x66fd3c: ldur            w4, [x3, #0x5f]
    // 0x66fd40: DecompressPointer r4
    //     0x66fd40: add             x4, x4, HEAP, lsl #32
    // 0x66fd44: r0 = BoxInt64Instr(r2)
    //     0x66fd44: sbfiz           x0, x2, #1, #0x1f
    //     0x66fd48: cmp             x2, x0, asr #1
    //     0x66fd4c: b.eq            #0x66fd58
    //     0x66fd50: bl              #0xd69bb8
    //     0x66fd54: stur            x2, [x0, #7]
    // 0x66fd58: r1 = LoadClassIdInstr(r4)
    //     0x66fd58: ldur            x1, [x4, #-1]
    //     0x66fd5c: ubfx            x1, x1, #0xc, #0x14
    // 0x66fd60: stp             x0, x4, [SP, #-0x10]!
    // 0x66fd64: mov             x0, x1
    // 0x66fd68: r0 = GDT[cid_x0 + -0xd83]()
    //     0x66fd68: sub             lr, x0, #0xd83
    //     0x66fd6c: ldr             lr, [x21, lr, lsl #3]
    //     0x66fd70: blr             lr
    // 0x66fd74: add             SP, SP, #0x10
    // 0x66fd78: mov             x3, x0
    // 0x66fd7c: stur            x3, [fp, #-0x18]
    // 0x66fd80: cmp             w3, NULL
    // 0x66fd84: b.eq            #0x66fe30
    // 0x66fd88: ldur            d0, [fp, #-0x78]
    // 0x66fd8c: ldur            d1, [fp, #-0x70]
    // 0x66fd90: LoadField: r4 = r3->field_17
    //     0x66fd90: ldur            w4, [x3, #0x17]
    // 0x66fd94: DecompressPointer r4
    //     0x66fd94: add             x4, x4, HEAP, lsl #32
    // 0x66fd98: stur            x4, [fp, #-8]
    // 0x66fd9c: cmp             w4, NULL
    // 0x66fda0: b.eq            #0x66ffdc
    // 0x66fda4: mov             x0, x4
    // 0x66fda8: r2 = Null
    //     0x66fda8: mov             x2, NULL
    // 0x66fdac: r1 = Null
    //     0x66fdac: mov             x1, NULL
    // 0x66fdb0: r4 = LoadClassIdInstr(r0)
    //     0x66fdb0: ldur            x4, [x0, #-1]
    //     0x66fdb4: ubfx            x4, x4, #0xc, #0x14
    // 0x66fdb8: sub             x4, x4, #0x7ff
    // 0x66fdbc: cmp             x4, #0xb
    // 0x66fdc0: b.ls            #0x66fdd8
    // 0x66fdc4: r8 = BoxParentData
    //     0x66fdc4: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x66fdc8: ldr             x8, [x8, #0x1b0]
    // 0x66fdcc: r3 = Null
    //     0x66fdcc: add             x3, PP, #0x57, lsl #12  ; [pp+0x576f8] Null
    //     0x66fdd0: ldr             x3, [x3, #0x6f8]
    // 0x66fdd4: r0 = DefaultTypeTest()
    //     0x66fdd4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x66fdd8: ldur            x0, [fp, #-8]
    // 0x66fddc: LoadField: r1 = r0->field_7
    //     0x66fddc: ldur            w1, [x0, #7]
    // 0x66fde0: DecompressPointer r1
    //     0x66fde0: add             x1, x1, HEAP, lsl #32
    // 0x66fde4: LoadField: d0 = r1->field_7
    //     0x66fde4: ldur            d0, [x1, #7]
    // 0x66fde8: ldur            d1, [fp, #-0x78]
    // 0x66fdec: fadd            d2, d0, d1
    // 0x66fdf0: stur            d2, [fp, #-0x88]
    // 0x66fdf4: LoadField: d0 = r1->field_f
    //     0x66fdf4: ldur            d0, [x1, #0xf]
    // 0x66fdf8: ldur            d3, [fp, #-0x70]
    // 0x66fdfc: fadd            d4, d0, d3
    // 0x66fe00: stur            d4, [fp, #-0x80]
    // 0x66fe04: r0 = Offset()
    //     0x66fe04: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x66fe08: ldur            d0, [fp, #-0x88]
    // 0x66fe0c: StoreField: r0->field_7 = d0
    //     0x66fe0c: stur            d0, [x0, #7]
    // 0x66fe10: ldur            d0, [fp, #-0x80]
    // 0x66fe14: StoreField: r0->field_f = d0
    //     0x66fe14: stur            d0, [x0, #0xf]
    // 0x66fe18: ldr             x16, [fp, #0x18]
    // 0x66fe1c: ldur            lr, [fp, #-0x18]
    // 0x66fe20: stp             lr, x16, [SP, #-0x10]!
    // 0x66fe24: SaveReg r0
    //     0x66fe24: str             x0, [SP, #-8]!
    // 0x66fe28: r0 = paintChild()
    //     0x66fe28: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x66fe2c: add             SP, SP, #0x18
    // 0x66fe30: ldur            x0, [fp, #-0x10]
    // 0x66fe34: add             x2, x0, #1
    // 0x66fe38: ldur            d0, [fp, #-0x78]
    // 0x66fe3c: ldur            d1, [fp, #-0x70]
    // 0x66fe40: b               #0x66fce8
    // 0x66fe44: ldr             x0, [fp, #0x20]
    // 0x66fe48: ldur            d0, [fp, #-0x78]
    // 0x66fe4c: ldur            d1, [fp, #-0x70]
    // 0x66fe50: LoadField: r1 = r0->field_a3
    //     0x66fe50: ldur            w1, [x0, #0xa3]
    // 0x66fe54: DecompressPointer r1
    //     0x66fe54: add             x1, x1, HEAP, lsl #32
    // 0x66fe58: r16 = Sentinel
    //     0x66fe58: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x66fe5c: cmp             w1, w16
    // 0x66fe60: b.eq            #0x66ffe0
    // 0x66fe64: stur            x1, [fp, #-0x18]
    // 0x66fe68: LoadField: r2 = r0->field_9b
    //     0x66fe68: ldur            w2, [x0, #0x9b]
    // 0x66fe6c: DecompressPointer r2
    //     0x66fe6c: add             x2, x2, HEAP, lsl #32
    // 0x66fe70: stur            x2, [fp, #-8]
    // 0x66fe74: SaveReg r2
    //     0x66fe74: str             x2, [SP, #-8]!
    // 0x66fe78: r0 = last()
    //     0x66fe78: bl              #0x621d20  ; [dart:core] _GrowableList::last
    // 0x66fe7c: add             SP, SP, #8
    // 0x66fe80: mov             x1, x0
    // 0x66fe84: ldur            x0, [fp, #-0x18]
    // 0x66fe88: LoadField: d0 = r0->field_7
    //     0x66fe88: ldur            d0, [x0, #7]
    // 0x66fe8c: ldur            d1, [fp, #-0x78]
    // 0x66fe90: fadd            d2, d1, d0
    // 0x66fe94: stur            d2, [fp, #-0x88]
    // 0x66fe98: LoadField: d0 = r1->field_7
    //     0x66fe98: ldur            d0, [x1, #7]
    // 0x66fe9c: ldur            d3, [fp, #-0x70]
    // 0x66fea0: fadd            d4, d3, d0
    // 0x66fea4: stur            d4, [fp, #-0x80]
    // 0x66fea8: r0 = Rect()
    //     0x66fea8: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x66feac: ldur            d0, [fp, #-0x78]
    // 0x66feb0: stur            x0, [fp, #-0x18]
    // 0x66feb4: StoreField: r0->field_7 = d0
    //     0x66feb4: stur            d0, [x0, #7]
    // 0x66feb8: ldur            d0, [fp, #-0x70]
    // 0x66febc: StoreField: r0->field_f = d0
    //     0x66febc: stur            d0, [x0, #0xf]
    // 0x66fec0: ldur            d0, [fp, #-0x88]
    // 0x66fec4: StoreField: r0->field_17 = d0
    //     0x66fec4: stur            d0, [x0, #0x17]
    // 0x66fec8: ldur            d0, [fp, #-0x80]
    // 0x66fecc: StoreField: r0->field_1f = d0
    //     0x66fecc: stur            d0, [x0, #0x1f]
    // 0x66fed0: ldur            x1, [fp, #-8]
    // 0x66fed4: LoadField: r2 = r1->field_b
    //     0x66fed4: ldur            w2, [x1, #0xb]
    // 0x66fed8: DecompressPointer r2
    //     0x66fed8: add             x2, x2, HEAP, lsl #32
    // 0x66fedc: r3 = LoadInt32Instr(r2)
    //     0x66fedc: sbfx            x3, x2, #1, #0x1f
    // 0x66fee0: sub             x2, x3, #1
    // 0x66fee4: r16 = 2
    //     0x66fee4: mov             x16, #2
    // 0x66fee8: stp             x16, x1, [SP, #-0x10]!
    // 0x66feec: SaveReg r2
    //     0x66feec: str             x2, [SP, #-8]!
    // 0x66fef0: r0 = getRange()
    //     0x66fef0: bl              #0x5eb468  ; [dart:collection] _ListBase&Object&ListMixin::getRange
    // 0x66fef4: add             SP, SP, #0x18
    // 0x66fef8: mov             x1, x0
    // 0x66fefc: ldr             x0, [fp, #0x20]
    // 0x66ff00: stur            x1, [fp, #-8]
    // 0x66ff04: LoadField: r2 = r0->field_9f
    //     0x66ff04: ldur            w2, [x0, #0x9f]
    // 0x66ff08: DecompressPointer r2
    //     0x66ff08: add             x2, x2, HEAP, lsl #32
    // 0x66ff0c: cmp             w2, NULL
    // 0x66ff10: b.eq            #0x66ffec
    // 0x66ff14: r0 = LoadClassIdInstr(r2)
    //     0x66ff14: ldur            x0, [x2, #-1]
    //     0x66ff18: ubfx            x0, x0, #0xc, #0x14
    // 0x66ff1c: SaveReg r2
    //     0x66ff1c: str             x2, [SP, #-8]!
    // 0x66ff20: r2 = 1
    //     0x66ff20: mov             x2, #1
    // 0x66ff24: SaveReg r2
    //     0x66ff24: str             x2, [SP, #-8]!
    // 0x66ff28: r0 = GDT[cid_x0 + 0xcd65]()
    //     0x66ff28: mov             x17, #0xcd65
    //     0x66ff2c: add             lr, x0, x17
    //     0x66ff30: ldr             lr, [x21, lr, lsl #3]
    //     0x66ff34: blr             lr
    // 0x66ff38: add             SP, SP, #0x10
    // 0x66ff3c: stur            x0, [fp, #-0x20]
    // 0x66ff40: ldr             x16, [fp, #0x18]
    // 0x66ff44: SaveReg r16
    //     0x66ff44: str             x16, [SP, #-8]!
    // 0x66ff48: r0 = canvas()
    //     0x66ff48: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x66ff4c: add             SP, SP, #8
    // 0x66ff50: r16 = Instance_TableBorder
    //     0x66ff50: add             x16, PP, #0x46, lsl #12  ; [pp+0x46e98] Obj!TableBorder@b35221
    //     0x66ff54: ldr             x16, [x16, #0xe98]
    // 0x66ff58: stp             x0, x16, [SP, #-0x10]!
    // 0x66ff5c: ldur            x16, [fp, #-0x18]
    // 0x66ff60: ldur            lr, [fp, #-0x20]
    // 0x66ff64: stp             lr, x16, [SP, #-0x10]!
    // 0x66ff68: ldur            x16, [fp, #-8]
    // 0x66ff6c: SaveReg r16
    //     0x66ff6c: str             x16, [SP, #-8]!
    // 0x66ff70: r0 = paint()
    //     0x66ff70: bl              #0x66fff0  ; [package:flutter/src/rendering/table_border.dart] TableBorder::paint
    // 0x66ff74: add             SP, SP, #0x28
    // 0x66ff78: r0 = Null
    //     0x66ff78: mov             x0, NULL
    // 0x66ff7c: LeaveFrame
    //     0x66ff7c: mov             SP, fp
    //     0x66ff80: ldp             fp, lr, [SP], #0x10
    // 0x66ff84: ret
    //     0x66ff84: ret             
    // 0x66ff88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66ff88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66ff8c: b               #0x66f7f8
    // 0x66ff90: r9 = _tableWidth
    //     0x66ff90: add             x9, PP, #0x57, lsl #12  ; [pp+0x57708] Field <RenderTable._tableWidth@919148626>: late (offset: 0xa4)
    //     0x66ff94: ldr             x9, [x9, #0x708]
    // 0x66ff98: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x66ff98: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x66ff9c: r0 = StackOverflowSharedWithFPURegs()
    //     0x66ff9c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x66ffa0: b               #0x66f928
    // 0x66ffa4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x66ffa4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x66ffa8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66ffa8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x66ffac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66ffac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x66ffb0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x66ffb0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x66ffb4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66ffb4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x66ffb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66ffb8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x66ffbc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x66ffbc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x66ffc0: r0 = RangeErrorSharedWithFPURegs()
    //     0x66ffc0: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x66ffc4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x66ffc4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x66ffc8: r0 = RangeErrorSharedWithFPURegs()
    //     0x66ffc8: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x66ffcc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x66ffcc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x66ffd0: r0 = RangeErrorSharedWithFPURegs()
    //     0x66ffd0: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x66ffd4: r0 = StackOverflowSharedWithFPURegs()
    //     0x66ffd4: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x66ffd8: b               #0x66fcfc
    // 0x66ffdc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x66ffdc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x66ffe0: r9 = _tableWidth
    //     0x66ffe0: add             x9, PP, #0x57, lsl #12  ; [pp+0x57708] Field <RenderTable._tableWidth@919148626>: late (offset: 0xa4)
    //     0x66ffe4: ldr             x9, [x9, #0x708]
    // 0x66ffe8: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x66ffe8: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x66ffec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66ffec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x69de98, size: 0xcd8
    // 0x69de98: EnterFrame
    //     0x69de98: stp             fp, lr, [SP, #-0x10]!
    //     0x69de9c: mov             fp, SP
    // 0x69dea0: AllocStack(0x78)
    //     0x69dea0: sub             SP, SP, #0x78
    // 0x69dea4: CheckStackOverflow
    //     0x69dea4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x69dea8: cmp             SP, x16
    //     0x69deac: b.ls            #0x69e9f0
    // 0x69deb0: ldr             x3, [fp, #0x10]
    // 0x69deb4: LoadField: r4 = r3->field_27
    //     0x69deb4: ldur            w4, [x3, #0x27]
    // 0x69deb8: DecompressPointer r4
    //     0x69deb8: add             x4, x4, HEAP, lsl #32
    // 0x69debc: stur            x4, [fp, #-8]
    // 0x69dec0: cmp             w4, NULL
    // 0x69dec4: b.eq            #0x69e9b8
    // 0x69dec8: mov             x0, x4
    // 0x69decc: r2 = Null
    //     0x69decc: mov             x2, NULL
    // 0x69ded0: r1 = Null
    //     0x69ded0: mov             x1, NULL
    // 0x69ded4: r4 = LoadClassIdInstr(r0)
    //     0x69ded4: ldur            x4, [x0, #-1]
    //     0x69ded8: ubfx            x4, x4, #0xc, #0x14
    // 0x69dedc: sub             x4, x4, #0x80d
    // 0x69dee0: cmp             x4, #1
    // 0x69dee4: b.ls            #0x69defc
    // 0x69dee8: r8 = BoxConstraints
    //     0x69dee8: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x69deec: ldr             x8, [x8, #0x1d0]
    // 0x69def0: r3 = Null
    //     0x69def0: add             x3, PP, #0x57, lsl #12  ; [pp+0x57720] Null
    //     0x69def4: ldr             x3, [x3, #0x720]
    // 0x69def8: r0 = BoxConstraints()
    //     0x69def8: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x69defc: ldr             x0, [fp, #0x10]
    // 0x69df00: LoadField: r1 = r0->field_6b
    //     0x69df00: ldur            x1, [x0, #0x6b]
    // 0x69df04: stur            x1, [fp, #-0x18]
    // 0x69df08: LoadField: r2 = r0->field_63
    //     0x69df08: ldur            x2, [x0, #0x63]
    // 0x69df0c: stur            x2, [fp, #-0x10]
    // 0x69df10: mul             x3, x1, x2
    // 0x69df14: cbnz            x3, #0x69df64
    // 0x69df18: r1 = 0.000000
    //     0x69df18: ldr             x1, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x69df1c: StoreField: r0->field_a3 = r1
    //     0x69df1c: stur            w1, [x0, #0xa3]
    // 0x69df20: ldur            x16, [fp, #-8]
    // 0x69df24: r30 = Instance_Size
    //     0x69df24: ldr             lr, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0x69df28: stp             lr, x16, [SP, #-0x10]!
    // 0x69df2c: r0 = constrain()
    //     0x69df2c: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x69df30: add             SP, SP, #0x10
    // 0x69df34: ldr             x3, [fp, #0x10]
    // 0x69df38: StoreField: r3->field_57 = r0
    //     0x69df38: stur            w0, [x3, #0x57]
    //     0x69df3c: ldurb           w16, [x3, #-1]
    //     0x69df40: ldurb           w17, [x0, #-1]
    //     0x69df44: and             x16, x17, x16, lsr #2
    //     0x69df48: tst             x16, HEAP, lsr #32
    //     0x69df4c: b.eq            #0x69df54
    //     0x69df50: bl              #0xd682ac
    // 0x69df54: r0 = Null
    //     0x69df54: mov             x0, NULL
    // 0x69df58: LeaveFrame
    //     0x69df58: mov             SP, fp
    //     0x69df5c: ldp             fp, lr, [SP], #0x10
    // 0x69df60: ret
    //     0x69df60: ret             
    // 0x69df64: mov             x3, x0
    // 0x69df68: ldur            x16, [fp, #-8]
    // 0x69df6c: stp             x16, x3, [SP, #-0x10]!
    // 0x69df70: r0 = _computeColumnWidths()
    //     0x69df70: bl              #0x632bf8  ; [package:flutter/src/rendering/table.dart] RenderTable::_computeColumnWidths
    // 0x69df74: add             SP, SP, #0x10
    // 0x69df78: stur            x0, [fp, #-0x20]
    // 0x69df7c: r16 = <double>
    //     0x69df7c: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x69df80: SaveReg r16
    //     0x69df80: str             x16, [SP, #-8]!
    // 0x69df84: ldur            x1, [fp, #-0x10]
    // 0x69df88: r16 = 0.000000
    //     0x69df88: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x69df8c: stp             x16, x1, [SP, #-0x10]!
    // 0x69df90: r0 = _List.filled()
    //     0x69df90: bl              #0x4db0d4  ; [dart:core] _List::_List.filled
    // 0x69df94: add             SP, SP, #0x18
    // 0x69df98: stur            x0, [fp, #-0x28]
    // 0x69df9c: ldr             x16, [fp, #0x10]
    // 0x69dfa0: SaveReg r16
    //     0x69dfa0: str             x16, [SP, #-8]!
    // 0x69dfa4: r0 = validForMouseTracker()
    //     0x69dfa4: bl              #0xc6f300  ; [package:flutter/src/rendering/proxy_box.dart] RenderMouseRegion::validForMouseTracker
    // 0x69dfa8: add             SP, SP, #8
    // 0x69dfac: LoadField: r1 = r0->field_7
    //     0x69dfac: ldur            x1, [x0, #7]
    // 0x69dfb0: cmp             x1, #0
    // 0x69dfb4: b.gt            #0x69e1a8
    // 0x69dfb8: ldur            x3, [fp, #-0x20]
    // 0x69dfbc: ldur            x2, [fp, #-0x28]
    // 0x69dfc0: ldur            x4, [fp, #-0x10]
    // 0x69dfc4: sub             x5, x4, #1
    // 0x69dfc8: mov             x0, x4
    // 0x69dfcc: mov             x1, x5
    // 0x69dfd0: cmp             x1, x0
    // 0x69dfd4: b.hs            #0x69e9f8
    // 0x69dfd8: add             x0, x2, x5, lsl #2
    // 0x69dfdc: r17 = 0.000000
    //     0x69dfdc: ldr             x17, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x69dfe0: StoreField: r0->field_f = r17
    //     0x69dfe0: stur            w17, [x0, #0xf]
    // 0x69dfe4: sub             x0, x4, #2
    // 0x69dfe8: LoadField: r5 = r3->field_b
    //     0x69dfe8: ldur            w5, [x3, #0xb]
    // 0x69dfec: DecompressPointer r5
    //     0x69dfec: add             x5, x5, HEAP, lsl #32
    // 0x69dff0: stur            x5, [fp, #-0x30]
    // 0x69dff4: r6 = LoadInt32Instr(r5)
    //     0x69dff4: sbfx            x6, x5, #1, #0x1f
    // 0x69dff8: mov             x7, x0
    // 0x69dffc: CheckStackOverflow
    //     0x69dffc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x69e000: cmp             SP, x16
    //     0x69e004: b.ls            #0x69e9fc
    // 0x69e008: tbnz            x7, #0x3f, #0x69e0c4
    // 0x69e00c: add             x8, x7, #1
    // 0x69e010: mov             x0, x4
    // 0x69e014: mov             x1, x8
    // 0x69e018: cmp             x1, x0
    // 0x69e01c: b.hs            #0x69ea04
    // 0x69e020: ArrayLoad: r9 = r2[r8]  ; Unknown_4
    //     0x69e020: add             x16, x2, x8, lsl #2
    //     0x69e024: ldur            w9, [x16, #0xf]
    // 0x69e028: DecompressPointer r9
    //     0x69e028: add             x9, x9, HEAP, lsl #32
    // 0x69e02c: mov             x0, x6
    // 0x69e030: mov             x1, x8
    // 0x69e034: cmp             x1, x0
    // 0x69e038: b.hs            #0x69ea08
    // 0x69e03c: ArrayLoad: r0 = r3[r8]  ; Unknown_4
    //     0x69e03c: add             x16, x3, x8, lsl #2
    //     0x69e040: ldur            w0, [x16, #0xf]
    // 0x69e044: DecompressPointer r0
    //     0x69e044: add             x0, x0, HEAP, lsl #32
    // 0x69e048: LoadField: d0 = r9->field_7
    //     0x69e048: ldur            d0, [x9, #7]
    // 0x69e04c: LoadField: d1 = r0->field_7
    //     0x69e04c: ldur            d1, [x0, #7]
    // 0x69e050: fadd            d2, d0, d1
    // 0x69e054: mov             x0, x4
    // 0x69e058: mov             x1, x7
    // 0x69e05c: cmp             x1, x0
    // 0x69e060: b.hs            #0x69ea0c
    // 0x69e064: r0 = inline_Allocate_Double()
    //     0x69e064: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x69e068: add             x0, x0, #0x10
    //     0x69e06c: cmp             x1, x0
    //     0x69e070: b.ls            #0x69ea10
    //     0x69e074: str             x0, [THR, #0x60]  ; THR::top
    //     0x69e078: sub             x0, x0, #0xf
    //     0x69e07c: mov             x1, #0xd108
    //     0x69e080: movk            x1, #3, lsl #16
    //     0x69e084: stur            x1, [x0, #-1]
    // 0x69e088: StoreField: r0->field_7 = d2
    //     0x69e088: stur            d2, [x0, #7]
    // 0x69e08c: mov             x1, x2
    // 0x69e090: ArrayStore: r1[r7] = r0  ; List_4
    //     0x69e090: add             x25, x1, x7, lsl #2
    //     0x69e094: add             x25, x25, #0xf
    //     0x69e098: str             w0, [x25]
    //     0x69e09c: tbz             w0, #0, #0x69e0b8
    //     0x69e0a0: ldurb           w16, [x1, #-1]
    //     0x69e0a4: ldurb           w17, [x0, #-1]
    //     0x69e0a8: and             x16, x17, x16, lsr #2
    //     0x69e0ac: tst             x16, HEAP, lsr #32
    //     0x69e0b0: b.eq            #0x69e0b8
    //     0x69e0b4: bl              #0xd67e5c
    // 0x69e0b8: sub             x0, x7, #1
    // 0x69e0bc: mov             x7, x0
    // 0x69e0c0: b               #0x69dffc
    // 0x69e0c4: ldr             x0, [fp, #0x10]
    // 0x69e0c8: r1 = <double>
    //     0x69e0c8: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x69e0cc: r0 = ReversedListIterable()
    //     0x69e0cc: bl              #0x4c1784  ; AllocateReversedListIterableStub -> ReversedListIterable<X0> (size=0x10)
    // 0x69e0d0: ldur            x2, [fp, #-0x28]
    // 0x69e0d4: StoreField: r0->field_b = r2
    //     0x69e0d4: stur            w2, [x0, #0xb]
    // 0x69e0d8: ldr             x3, [fp, #0x10]
    // 0x69e0dc: StoreField: r3->field_9f = r0
    //     0x69e0dc: stur            w0, [x3, #0x9f]
    //     0x69e0e0: ldurb           w16, [x3, #-1]
    //     0x69e0e4: ldurb           w17, [x0, #-1]
    //     0x69e0e8: and             x16, x17, x16, lsr #2
    //     0x69e0ec: tst             x16, HEAP, lsr #32
    //     0x69e0f0: b.eq            #0x69e0f8
    //     0x69e0f4: bl              #0xd682ac
    // 0x69e0f8: ldur            x4, [fp, #-0x10]
    // 0x69e0fc: cmp             x4, #0
    // 0x69e100: b.le            #0x69e9e4
    // 0x69e104: ldur            x5, [fp, #-0x30]
    // 0x69e108: mov             x0, x4
    // 0x69e10c: r1 = 0
    //     0x69e10c: mov             x1, #0
    // 0x69e110: cmp             x1, x0
    // 0x69e114: b.hs            #0x69ea38
    // 0x69e118: LoadField: r6 = r2->field_f
    //     0x69e118: ldur            w6, [x2, #0xf]
    // 0x69e11c: DecompressPointer r6
    //     0x69e11c: add             x6, x6, HEAP, lsl #32
    // 0x69e120: r0 = LoadInt32Instr(r5)
    //     0x69e120: sbfx            x0, x5, #1, #0x1f
    // 0x69e124: cmp             x0, #0
    // 0x69e128: b.le            #0x69e9d8
    // 0x69e12c: ldur            x7, [fp, #-0x20]
    // 0x69e130: r1 = 0
    //     0x69e130: mov             x1, #0
    // 0x69e134: cmp             x1, x0
    // 0x69e138: b.hs            #0x69ea3c
    // 0x69e13c: LoadField: r0 = r7->field_f
    //     0x69e13c: ldur            w0, [x7, #0xf]
    // 0x69e140: DecompressPointer r0
    //     0x69e140: add             x0, x0, HEAP, lsl #32
    // 0x69e144: LoadField: d0 = r6->field_7
    //     0x69e144: ldur            d0, [x6, #7]
    // 0x69e148: LoadField: d1 = r0->field_7
    //     0x69e148: ldur            d1, [x0, #7]
    // 0x69e14c: fadd            d2, d0, d1
    // 0x69e150: r0 = inline_Allocate_Double()
    //     0x69e150: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x69e154: add             x0, x0, #0x10
    //     0x69e158: cmp             x1, x0
    //     0x69e15c: b.ls            #0x69ea40
    //     0x69e160: str             x0, [THR, #0x60]  ; THR::top
    //     0x69e164: sub             x0, x0, #0xf
    //     0x69e168: mov             x1, #0xd108
    //     0x69e16c: movk            x1, #3, lsl #16
    //     0x69e170: stur            x1, [x0, #-1]
    // 0x69e174: StoreField: r0->field_7 = d2
    //     0x69e174: stur            d2, [x0, #7]
    // 0x69e178: StoreField: r3->field_a3 = r0
    //     0x69e178: stur            w0, [x3, #0xa3]
    //     0x69e17c: ldurb           w16, [x3, #-1]
    //     0x69e180: ldurb           w17, [x0, #-1]
    //     0x69e184: and             x16, x17, x16, lsr #2
    //     0x69e188: tst             x16, HEAP, lsr #32
    //     0x69e18c: b.eq            #0x69e194
    //     0x69e190: bl              #0xd682ac
    // 0x69e194: r0 = LoadInt32Instr(r5)
    //     0x69e194: sbfx            x0, x5, #1, #0x1f
    // 0x69e198: mov             x2, x0
    // 0x69e19c: mov             x1, x3
    // 0x69e1a0: mov             x0, x4
    // 0x69e1a4: b               #0x69e348
    // 0x69e1a8: ldr             x3, [fp, #0x10]
    // 0x69e1ac: ldur            x7, [fp, #-0x20]
    // 0x69e1b0: ldur            x2, [fp, #-0x28]
    // 0x69e1b4: ldur            x4, [fp, #-0x10]
    // 0x69e1b8: mov             x0, x4
    // 0x69e1bc: r1 = 0
    //     0x69e1bc: mov             x1, #0
    // 0x69e1c0: cmp             x1, x0
    // 0x69e1c4: b.hs            #0x69ea68
    // 0x69e1c8: r17 = 0.000000
    //     0x69e1c8: ldr             x17, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x69e1cc: StoreField: r2->field_f = r17
    //     0x69e1cc: stur            w17, [x2, #0xf]
    // 0x69e1d0: LoadField: r5 = r7->field_b
    //     0x69e1d0: ldur            w5, [x7, #0xb]
    // 0x69e1d4: DecompressPointer r5
    //     0x69e1d4: add             x5, x5, HEAP, lsl #32
    // 0x69e1d8: stur            x5, [fp, #-0x30]
    // 0x69e1dc: r6 = LoadInt32Instr(r5)
    //     0x69e1dc: sbfx            x6, x5, #1, #0x1f
    // 0x69e1e0: r8 = 1
    //     0x69e1e0: mov             x8, #1
    // 0x69e1e4: CheckStackOverflow
    //     0x69e1e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x69e1e8: cmp             SP, x16
    //     0x69e1ec: b.ls            #0x69ea6c
    // 0x69e1f0: cmp             x8, x4
    // 0x69e1f4: b.ge            #0x69e2a0
    // 0x69e1f8: sub             x9, x8, #1
    // 0x69e1fc: mov             x0, x4
    // 0x69e200: mov             x1, x9
    // 0x69e204: cmp             x1, x0
    // 0x69e208: b.hs            #0x69ea74
    // 0x69e20c: ArrayLoad: r10 = r2[r9]  ; Unknown_4
    //     0x69e20c: add             x16, x2, x9, lsl #2
    //     0x69e210: ldur            w10, [x16, #0xf]
    // 0x69e214: DecompressPointer r10
    //     0x69e214: add             x10, x10, HEAP, lsl #32
    // 0x69e218: mov             x0, x6
    // 0x69e21c: mov             x1, x9
    // 0x69e220: cmp             x1, x0
    // 0x69e224: b.hs            #0x69ea78
    // 0x69e228: ArrayLoad: r0 = r7[r9]  ; Unknown_4
    //     0x69e228: add             x16, x7, x9, lsl #2
    //     0x69e22c: ldur            w0, [x16, #0xf]
    // 0x69e230: DecompressPointer r0
    //     0x69e230: add             x0, x0, HEAP, lsl #32
    // 0x69e234: LoadField: d0 = r10->field_7
    //     0x69e234: ldur            d0, [x10, #7]
    // 0x69e238: LoadField: d1 = r0->field_7
    //     0x69e238: ldur            d1, [x0, #7]
    // 0x69e23c: fadd            d2, d0, d1
    // 0x69e240: r0 = inline_Allocate_Double()
    //     0x69e240: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x69e244: add             x0, x0, #0x10
    //     0x69e248: cmp             x1, x0
    //     0x69e24c: b.ls            #0x69ea7c
    //     0x69e250: str             x0, [THR, #0x60]  ; THR::top
    //     0x69e254: sub             x0, x0, #0xf
    //     0x69e258: mov             x1, #0xd108
    //     0x69e25c: movk            x1, #3, lsl #16
    //     0x69e260: stur            x1, [x0, #-1]
    // 0x69e264: StoreField: r0->field_7 = d2
    //     0x69e264: stur            d2, [x0, #7]
    // 0x69e268: mov             x1, x2
    // 0x69e26c: ArrayStore: r1[r8] = r0  ; List_4
    //     0x69e26c: add             x25, x1, x8, lsl #2
    //     0x69e270: add             x25, x25, #0xf
    //     0x69e274: str             w0, [x25]
    //     0x69e278: tbz             w0, #0, #0x69e294
    //     0x69e27c: ldurb           w16, [x1, #-1]
    //     0x69e280: ldurb           w17, [x0, #-1]
    //     0x69e284: and             x16, x17, x16, lsr #2
    //     0x69e288: tst             x16, HEAP, lsr #32
    //     0x69e28c: b.eq            #0x69e294
    //     0x69e290: bl              #0xd67e5c
    // 0x69e294: add             x0, x8, #1
    // 0x69e298: mov             x8, x0
    // 0x69e29c: b               #0x69e1e4
    // 0x69e2a0: mov             x0, x2
    // 0x69e2a4: StoreField: r3->field_9f = r0
    //     0x69e2a4: stur            w0, [x3, #0x9f]
    //     0x69e2a8: ldurb           w16, [x3, #-1]
    //     0x69e2ac: ldurb           w17, [x0, #-1]
    //     0x69e2b0: and             x16, x17, x16, lsr #2
    //     0x69e2b4: tst             x16, HEAP, lsr #32
    //     0x69e2b8: b.eq            #0x69e2c0
    //     0x69e2bc: bl              #0xd682ac
    // 0x69e2c0: SaveReg r2
    //     0x69e2c0: str             x2, [SP, #-8]!
    // 0x69e2c4: r0 = last()
    //     0x69e2c4: bl              #0x621d9c  ; [dart:core] _Array::last
    // 0x69e2c8: add             SP, SP, #8
    // 0x69e2cc: stur            x0, [fp, #-0x38]
    // 0x69e2d0: ldur            x16, [fp, #-0x20]
    // 0x69e2d4: SaveReg r16
    //     0x69e2d4: str             x16, [SP, #-8]!
    // 0x69e2d8: r0 = last()
    //     0x69e2d8: bl              #0x621d9c  ; [dart:core] _Array::last
    // 0x69e2dc: add             SP, SP, #8
    // 0x69e2e0: mov             x1, x0
    // 0x69e2e4: ldur            x0, [fp, #-0x38]
    // 0x69e2e8: LoadField: d0 = r0->field_7
    //     0x69e2e8: ldur            d0, [x0, #7]
    // 0x69e2ec: LoadField: d1 = r1->field_7
    //     0x69e2ec: ldur            d1, [x1, #7]
    // 0x69e2f0: fadd            d2, d0, d1
    // 0x69e2f4: r0 = inline_Allocate_Double()
    //     0x69e2f4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x69e2f8: add             x0, x0, #0x10
    //     0x69e2fc: cmp             x1, x0
    //     0x69e300: b.ls            #0x69eaac
    //     0x69e304: str             x0, [THR, #0x60]  ; THR::top
    //     0x69e308: sub             x0, x0, #0xf
    //     0x69e30c: mov             x1, #0xd108
    //     0x69e310: movk            x1, #3, lsl #16
    //     0x69e314: stur            x1, [x0, #-1]
    // 0x69e318: StoreField: r0->field_7 = d2
    //     0x69e318: stur            d2, [x0, #7]
    // 0x69e31c: ldr             x1, [fp, #0x10]
    // 0x69e320: StoreField: r1->field_a3 = r0
    //     0x69e320: stur            w0, [x1, #0xa3]
    //     0x69e324: ldurb           w16, [x1, #-1]
    //     0x69e328: ldurb           w17, [x0, #-1]
    //     0x69e32c: and             x16, x17, x16, lsr #2
    //     0x69e330: tst             x16, HEAP, lsr #32
    //     0x69e334: b.eq            #0x69e33c
    //     0x69e338: bl              #0xd6826c
    // 0x69e33c: ldur            x0, [fp, #-0x30]
    // 0x69e340: r2 = LoadInt32Instr(r0)
    //     0x69e340: sbfx            x2, x0, #1, #0x1f
    // 0x69e344: ldur            x0, [fp, #-0x10]
    // 0x69e348: stur            x2, [fp, #-0x40]
    // 0x69e34c: LoadField: r3 = r1->field_9b
    //     0x69e34c: ldur            w3, [x1, #0x9b]
    // 0x69e350: DecompressPointer r3
    //     0x69e350: add             x3, x3, HEAP, lsl #32
    // 0x69e354: stur            x3, [fp, #-0x30]
    // 0x69e358: SaveReg r3
    //     0x69e358: str             x3, [SP, #-8]!
    // 0x69e35c: r0 = clear()
    //     0x69e35c: bl              #0xd281bc  ; [dart:core] _GrowableList::clear
    // 0x69e360: add             SP, SP, #8
    // 0x69e364: ldr             x2, [fp, #0x10]
    // 0x69e368: StoreField: r2->field_97 = rNULL
    //     0x69e368: stur            NULL, [x2, #0x97]
    // 0x69e36c: ldur            x3, [fp, #-0x10]
    // 0x69e370: r0 = BoxInt64Instr(r3)
    //     0x69e370: sbfiz           x0, x3, #1, #0x1f
    //     0x69e374: cmp             x3, x0, asr #1
    //     0x69e378: b.eq            #0x69e384
    //     0x69e37c: bl              #0xd69bb8
    //     0x69e380: stur            x3, [x0, #7]
    // 0x69e384: stur            x0, [fp, #-0x50]
    // 0x69e388: d0 = 0.000000
    //     0x69e388: eor             v0.16b, v0.16b, v0.16b
    // 0x69e38c: r7 = 0
    //     0x69e38c: mov             x7, #0
    // 0x69e390: ldur            x5, [fp, #-0x20]
    // 0x69e394: ldur            x4, [fp, #-0x28]
    // 0x69e398: ldur            x1, [fp, #-0x30]
    // 0x69e39c: ldur            x6, [fp, #-0x18]
    // 0x69e3a0: stur            x7, [fp, #-0x48]
    // 0x69e3a4: stur            d0, [fp, #-0x70]
    // 0x69e3a8: CheckStackOverflow
    //     0x69e3a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x69e3ac: cmp             SP, x16
    //     0x69e3b0: b.ls            #0x69eabc
    // 0x69e3b4: cmp             x7, x6
    // 0x69e3b8: b.ge            #0x69e890
    // 0x69e3bc: LoadField: r8 = r1->field_b
    //     0x69e3bc: ldur            w8, [x1, #0xb]
    // 0x69e3c0: DecompressPointer r8
    //     0x69e3c0: add             x8, x8, HEAP, lsl #32
    // 0x69e3c4: stur            x8, [fp, #-0x38]
    // 0x69e3c8: LoadField: r9 = r1->field_f
    //     0x69e3c8: ldur            w9, [x1, #0xf]
    // 0x69e3cc: DecompressPointer r9
    //     0x69e3cc: add             x9, x9, HEAP, lsl #32
    // 0x69e3d0: LoadField: r10 = r9->field_b
    //     0x69e3d0: ldur            w10, [x9, #0xb]
    // 0x69e3d4: DecompressPointer r10
    //     0x69e3d4: add             x10, x10, HEAP, lsl #32
    // 0x69e3d8: cmp             w8, w10
    // 0x69e3dc: b.ne            #0x69e3ec
    // 0x69e3e0: SaveReg r1
    //     0x69e3e0: str             x1, [SP, #-8]!
    // 0x69e3e4: r0 = _growToNextCapacity()
    //     0x69e3e4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x69e3e8: add             SP, SP, #8
    // 0x69e3ec: ldur            x3, [fp, #-0x30]
    // 0x69e3f0: ldur            d0, [fp, #-0x70]
    // 0x69e3f4: ldur            x0, [fp, #-0x38]
    // 0x69e3f8: r2 = LoadInt32Instr(r0)
    //     0x69e3f8: sbfx            x2, x0, #1, #0x1f
    // 0x69e3fc: add             x0, x2, #1
    // 0x69e400: lsl             x1, x0, #1
    // 0x69e404: StoreField: r3->field_b = r1
    //     0x69e404: stur            w1, [x3, #0xb]
    // 0x69e408: mov             x1, x2
    // 0x69e40c: cmp             x1, x0
    // 0x69e410: b.hs            #0x69eac4
    // 0x69e414: LoadField: r1 = r3->field_f
    //     0x69e414: ldur            w1, [x3, #0xf]
    // 0x69e418: DecompressPointer r1
    //     0x69e418: add             x1, x1, HEAP, lsl #32
    // 0x69e41c: r0 = inline_Allocate_Double()
    //     0x69e41c: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0x69e420: add             x0, x0, #0x10
    //     0x69e424: cmp             x4, x0
    //     0x69e428: b.ls            #0x69eac8
    //     0x69e42c: str             x0, [THR, #0x60]  ; THR::top
    //     0x69e430: sub             x0, x0, #0xf
    //     0x69e434: mov             x4, #0xd108
    //     0x69e438: movk            x4, #3, lsl #16
    //     0x69e43c: stur            x4, [x0, #-1]
    // 0x69e440: StoreField: r0->field_7 = d0
    //     0x69e440: stur            d0, [x0, #7]
    // 0x69e444: ArrayStore: r1[r2] = r0  ; List_4
    //     0x69e444: add             x25, x1, x2, lsl #2
    //     0x69e448: add             x25, x25, #0xf
    //     0x69e44c: str             w0, [x25]
    //     0x69e450: tbz             w0, #0, #0x69e46c
    //     0x69e454: ldurb           w16, [x1, #-1]
    //     0x69e458: ldurb           w17, [x0, #-1]
    //     0x69e45c: and             x16, x17, x16, lsr #2
    //     0x69e460: tst             x16, HEAP, lsr #32
    //     0x69e464: b.eq            #0x69e46c
    //     0x69e468: bl              #0xd67e5c
    // 0x69e46c: ldur            x2, [fp, #-0x50]
    // 0x69e470: r1 = <double>
    //     0x69e470: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x69e474: r0 = AllocateArray()
    //     0x69e474: bl              #0xd6987c  ; AllocateArrayStub
    // 0x69e478: ldur            x2, [fp, #-0x10]
    // 0x69e47c: r1 = 0
    //     0x69e47c: mov             x1, #0
    // 0x69e480: CheckStackOverflow
    //     0x69e480: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x69e484: cmp             SP, x16
    //     0x69e488: b.ls            #0x69eae8
    // 0x69e48c: cmp             x1, x2
    // 0x69e490: b.ge            #0x69e4ac
    // 0x69e494: add             x3, x0, x1, lsl #2
    // 0x69e498: r17 = 0.000000
    //     0x69e498: ldr             x17, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x69e49c: StoreField: r3->field_f = r17
    //     0x69e49c: stur            w17, [x3, #0xf]
    // 0x69e4a0: add             x3, x1, #1
    // 0x69e4a4: mov             x1, x3
    // 0x69e4a8: b               #0x69e480
    // 0x69e4ac: ldur            x3, [fp, #-0x48]
    // 0x69e4b0: mul             x4, x3, x2
    // 0x69e4b4: stur            x4, [fp, #-0x60]
    // 0x69e4b8: r8 = 0.000000
    //     0x69e4b8: ldr             x8, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x69e4bc: r7 = 0
    //     0x69e4bc: mov             x7, #0
    // 0x69e4c0: ldr             x5, [fp, #0x10]
    // 0x69e4c4: ldur            x6, [fp, #-0x20]
    // 0x69e4c8: stur            x8, [fp, #-0x38]
    // 0x69e4cc: stur            x7, [fp, #-0x58]
    // 0x69e4d0: CheckStackOverflow
    //     0x69e4d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x69e4d4: cmp             SP, x16
    //     0x69e4d8: b.ls            #0x69eaf0
    // 0x69e4dc: cmp             x7, x2
    // 0x69e4e0: b.ge            #0x69e718
    // 0x69e4e4: add             x9, x7, x4
    // 0x69e4e8: LoadField: r10 = r5->field_5f
    //     0x69e4e8: ldur            w10, [x5, #0x5f]
    // 0x69e4ec: DecompressPointer r10
    //     0x69e4ec: add             x10, x10, HEAP, lsl #32
    // 0x69e4f0: r0 = BoxInt64Instr(r9)
    //     0x69e4f0: sbfiz           x0, x9, #1, #0x1f
    //     0x69e4f4: cmp             x9, x0, asr #1
    //     0x69e4f8: b.eq            #0x69e504
    //     0x69e4fc: bl              #0xd69bb8
    //     0x69e500: stur            x9, [x0, #7]
    // 0x69e504: r1 = LoadClassIdInstr(r10)
    //     0x69e504: ldur            x1, [x10, #-1]
    //     0x69e508: ubfx            x1, x1, #0xc, #0x14
    // 0x69e50c: stp             x0, x10, [SP, #-0x10]!
    // 0x69e510: mov             x0, x1
    // 0x69e514: r0 = GDT[cid_x0 + -0xd83]()
    //     0x69e514: sub             lr, x0, #0xd83
    //     0x69e518: ldr             lr, [x21, lr, lsl #3]
    //     0x69e51c: blr             lr
    // 0x69e520: add             SP, SP, #0x10
    // 0x69e524: mov             x3, x0
    // 0x69e528: stur            x3, [fp, #-0x68]
    // 0x69e52c: cmp             w3, NULL
    // 0x69e530: b.eq            #0x69e6f4
    // 0x69e534: ldur            x4, [fp, #-0x20]
    // 0x69e538: ldur            x6, [fp, #-0x38]
    // 0x69e53c: ldur            x5, [fp, #-0x58]
    // 0x69e540: LoadField: r0 = r3->field_17
    //     0x69e540: ldur            w0, [x3, #0x17]
    // 0x69e544: DecompressPointer r0
    //     0x69e544: add             x0, x0, HEAP, lsl #32
    // 0x69e548: cmp             w0, NULL
    // 0x69e54c: b.eq            #0x69eaf8
    // 0x69e550: r2 = Null
    //     0x69e550: mov             x2, NULL
    // 0x69e554: r1 = Null
    //     0x69e554: mov             x1, NULL
    // 0x69e558: r4 = LoadClassIdInstr(r0)
    //     0x69e558: ldur            x4, [x0, #-1]
    //     0x69e55c: ubfx            x4, x4, #0xc, #0x14
    // 0x69e560: cmp             x4, #0x800
    // 0x69e564: b.eq            #0x69e57c
    // 0x69e568: r8 = TableCellParentData
    //     0x69e568: add             x8, PP, #0x57, lsl #12  ; [pp+0x57730] Type: TableCellParentData
    //     0x69e56c: ldr             x8, [x8, #0x730]
    // 0x69e570: r3 = Null
    //     0x69e570: add             x3, PP, #0x57, lsl #12  ; [pp+0x57738] Null
    //     0x69e574: ldr             x3, [x3, #0x738]
    // 0x69e578: r0 = DefaultTypeTest()
    //     0x69e578: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x69e57c: ldur            x0, [fp, #-0x40]
    // 0x69e580: ldur            x1, [fp, #-0x58]
    // 0x69e584: cmp             x1, x0
    // 0x69e588: b.hs            #0x69eafc
    // 0x69e58c: ldur            x0, [fp, #-0x20]
    // 0x69e590: ldur            x1, [fp, #-0x58]
    // 0x69e594: ArrayLoad: r2 = r0[r1]  ; Unknown_4
    //     0x69e594: add             x16, x0, x1, lsl #2
    //     0x69e598: ldur            w2, [x16, #0xf]
    // 0x69e59c: DecompressPointer r2
    //     0x69e59c: add             x2, x2, HEAP, lsl #32
    // 0x69e5a0: LoadField: d0 = r2->field_7
    //     0x69e5a0: ldur            d0, [x2, #7]
    // 0x69e5a4: stur            d0, [fp, #-0x78]
    // 0x69e5a8: r0 = BoxConstraints()
    //     0x69e5a8: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x69e5ac: ldur            d0, [fp, #-0x78]
    // 0x69e5b0: StoreField: r0->field_7 = d0
    //     0x69e5b0: stur            d0, [x0, #7]
    // 0x69e5b4: StoreField: r0->field_f = d0
    //     0x69e5b4: stur            d0, [x0, #0xf]
    // 0x69e5b8: d0 = 0.000000
    //     0x69e5b8: eor             v0.16b, v0.16b, v0.16b
    // 0x69e5bc: StoreField: r0->field_17 = d0
    //     0x69e5bc: stur            d0, [x0, #0x17]
    // 0x69e5c0: d1 = inf
    //     0x69e5c0: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x69e5c4: StoreField: r0->field_1f = d1
    //     0x69e5c4: stur            d1, [x0, #0x1f]
    // 0x69e5c8: ldur            x1, [fp, #-0x68]
    // 0x69e5cc: r2 = LoadClassIdInstr(r1)
    //     0x69e5cc: ldur            x2, [x1, #-1]
    //     0x69e5d0: ubfx            x2, x2, #0xc, #0x14
    // 0x69e5d4: stp             x0, x1, [SP, #-0x10]!
    // 0x69e5d8: r16 = true
    //     0x69e5d8: add             x16, NULL, #0x20  ; true
    // 0x69e5dc: SaveReg r16
    //     0x69e5dc: str             x16, [SP, #-8]!
    // 0x69e5e0: mov             x0, x2
    // 0x69e5e4: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x69e5e4: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x69e5e8: ldr             x4, [x4, #0x1c8]
    // 0x69e5ec: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x69e5ec: mov             x17, #0xcdfb
    //     0x69e5f0: add             lr, x0, x17
    //     0x69e5f4: ldr             lr, [x21, lr, lsl #3]
    //     0x69e5f8: blr             lr
    // 0x69e5fc: add             SP, SP, #0x18
    // 0x69e600: ldur            x0, [fp, #-0x68]
    // 0x69e604: LoadField: r1 = r0->field_57
    //     0x69e604: ldur            w1, [x0, #0x57]
    // 0x69e608: DecompressPointer r1
    //     0x69e608: add             x1, x1, HEAP, lsl #32
    // 0x69e60c: cmp             w1, NULL
    // 0x69e610: b.eq            #0x69eb00
    // 0x69e614: LoadField: d0 = r1->field_f
    //     0x69e614: ldur            d0, [x1, #0xf]
    // 0x69e618: ldur            x2, [fp, #-0x38]
    // 0x69e61c: LoadField: d1 = r2->field_7
    //     0x69e61c: ldur            d1, [x2, #7]
    // 0x69e620: fcmp            d1, d0
    // 0x69e624: b.vs            #0x69e638
    // 0x69e628: b.le            #0x69e638
    // 0x69e62c: mov             x0, x2
    // 0x69e630: d2 = 0.000000
    //     0x69e630: eor             v2.16b, v2.16b, v2.16b
    // 0x69e634: b               #0x69e6ec
    // 0x69e638: fcmp            d1, d0
    // 0x69e63c: b.vs            #0x69e674
    // 0x69e640: b.ge            #0x69e674
    // 0x69e644: r0 = inline_Allocate_Double()
    //     0x69e644: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x69e648: add             x0, x0, #0x10
    //     0x69e64c: cmp             x1, x0
    //     0x69e650: b.ls            #0x69eb04
    //     0x69e654: str             x0, [THR, #0x60]  ; THR::top
    //     0x69e658: sub             x0, x0, #0xf
    //     0x69e65c: mov             x1, #0xd108
    //     0x69e660: movk            x1, #3, lsl #16
    //     0x69e664: stur            x1, [x0, #-1]
    // 0x69e668: StoreField: r0->field_7 = d0
    //     0x69e668: stur            d0, [x0, #7]
    // 0x69e66c: d2 = 0.000000
    //     0x69e66c: eor             v2.16b, v2.16b, v2.16b
    // 0x69e670: b               #0x69e6ec
    // 0x69e674: d2 = 0.000000
    //     0x69e674: eor             v2.16b, v2.16b, v2.16b
    // 0x69e678: fcmp            d1, d2
    // 0x69e67c: b.vs            #0x69e6b4
    // 0x69e680: b.ne            #0x69e6b4
    // 0x69e684: fadd            d3, d1, d0
    // 0x69e688: r0 = inline_Allocate_Double()
    //     0x69e688: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x69e68c: add             x0, x0, #0x10
    //     0x69e690: cmp             x1, x0
    //     0x69e694: b.ls            #0x69eb14
    //     0x69e698: str             x0, [THR, #0x60]  ; THR::top
    //     0x69e69c: sub             x0, x0, #0xf
    //     0x69e6a0: mov             x1, #0xd108
    //     0x69e6a4: movk            x1, #3, lsl #16
    //     0x69e6a8: stur            x1, [x0, #-1]
    // 0x69e6ac: StoreField: r0->field_7 = d3
    //     0x69e6ac: stur            d3, [x0, #7]
    // 0x69e6b0: b               #0x69e6ec
    // 0x69e6b4: fcmp            d0, d0
    // 0x69e6b8: b.vc            #0x69e6e8
    // 0x69e6bc: r0 = inline_Allocate_Double()
    //     0x69e6bc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x69e6c0: add             x0, x0, #0x10
    //     0x69e6c4: cmp             x1, x0
    //     0x69e6c8: b.ls            #0x69eb24
    //     0x69e6cc: str             x0, [THR, #0x60]  ; THR::top
    //     0x69e6d0: sub             x0, x0, #0xf
    //     0x69e6d4: mov             x1, #0xd108
    //     0x69e6d8: movk            x1, #3, lsl #16
    //     0x69e6dc: stur            x1, [x0, #-1]
    // 0x69e6e0: StoreField: r0->field_7 = d0
    //     0x69e6e0: stur            d0, [x0, #7]
    // 0x69e6e4: b               #0x69e6ec
    // 0x69e6e8: mov             x0, x2
    // 0x69e6ec: mov             x8, x0
    // 0x69e6f0: b               #0x69e700
    // 0x69e6f4: ldur            x2, [fp, #-0x38]
    // 0x69e6f8: d2 = 0.000000
    //     0x69e6f8: eor             v2.16b, v2.16b, v2.16b
    // 0x69e6fc: mov             x8, x2
    // 0x69e700: ldur            x0, [fp, #-0x58]
    // 0x69e704: add             x7, x0, #1
    // 0x69e708: ldur            x3, [fp, #-0x48]
    // 0x69e70c: ldur            x4, [fp, #-0x60]
    // 0x69e710: ldur            x2, [fp, #-0x10]
    // 0x69e714: b               #0x69e4c0
    // 0x69e718: mov             x4, x3
    // 0x69e71c: mov             x3, x2
    // 0x69e720: mov             x2, x8
    // 0x69e724: d2 = 0.000000
    //     0x69e724: eor             v2.16b, v2.16b, v2.16b
    // 0x69e728: mul             x5, x4, x3
    // 0x69e72c: stur            x5, [fp, #-0x60]
    // 0x69e730: ldur            d0, [fp, #-0x70]
    // 0x69e734: r8 = 0
    //     0x69e734: mov             x8, #0
    // 0x69e738: ldr             x6, [fp, #0x10]
    // 0x69e73c: ldur            x7, [fp, #-0x28]
    // 0x69e740: stur            x8, [fp, #-0x58]
    // 0x69e744: CheckStackOverflow
    //     0x69e744: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x69e748: cmp             SP, x16
    //     0x69e74c: b.ls            #0x69eb34
    // 0x69e750: cmp             x8, x3
    // 0x69e754: b.ge            #0x69e868
    // 0x69e758: add             x9, x8, x5
    // 0x69e75c: LoadField: r10 = r6->field_5f
    //     0x69e75c: ldur            w10, [x6, #0x5f]
    // 0x69e760: DecompressPointer r10
    //     0x69e760: add             x10, x10, HEAP, lsl #32
    // 0x69e764: r0 = BoxInt64Instr(r9)
    //     0x69e764: sbfiz           x0, x9, #1, #0x1f
    //     0x69e768: cmp             x9, x0, asr #1
    //     0x69e76c: b.eq            #0x69e778
    //     0x69e770: bl              #0xd69c6c
    //     0x69e774: stur            x9, [x0, #7]
    // 0x69e778: r1 = LoadClassIdInstr(r10)
    //     0x69e778: ldur            x1, [x10, #-1]
    //     0x69e77c: ubfx            x1, x1, #0xc, #0x14
    // 0x69e780: stp             x0, x10, [SP, #-0x10]!
    // 0x69e784: mov             x0, x1
    // 0x69e788: r0 = GDT[cid_x0 + -0xd83]()
    //     0x69e788: sub             lr, x0, #0xd83
    //     0x69e78c: ldr             lr, [x21, lr, lsl #3]
    //     0x69e790: blr             lr
    // 0x69e794: add             SP, SP, #0x10
    // 0x69e798: cmp             w0, NULL
    // 0x69e79c: b.eq            #0x69e844
    // 0x69e7a0: ldur            x3, [fp, #-0x28]
    // 0x69e7a4: ldur            d0, [fp, #-0x70]
    // 0x69e7a8: ldur            x4, [fp, #-0x58]
    // 0x69e7ac: LoadField: r5 = r0->field_17
    //     0x69e7ac: ldur            w5, [x0, #0x17]
    // 0x69e7b0: DecompressPointer r5
    //     0x69e7b0: add             x5, x5, HEAP, lsl #32
    // 0x69e7b4: stur            x5, [fp, #-0x68]
    // 0x69e7b8: cmp             w5, NULL
    // 0x69e7bc: b.eq            #0x69eb3c
    // 0x69e7c0: mov             x0, x5
    // 0x69e7c4: r2 = Null
    //     0x69e7c4: mov             x2, NULL
    // 0x69e7c8: r1 = Null
    //     0x69e7c8: mov             x1, NULL
    // 0x69e7cc: r4 = LoadClassIdInstr(r0)
    //     0x69e7cc: ldur            x4, [x0, #-1]
    //     0x69e7d0: ubfx            x4, x4, #0xc, #0x14
    // 0x69e7d4: cmp             x4, #0x800
    // 0x69e7d8: b.eq            #0x69e7f0
    // 0x69e7dc: r8 = TableCellParentData
    //     0x69e7dc: add             x8, PP, #0x57, lsl #12  ; [pp+0x57730] Type: TableCellParentData
    //     0x69e7e0: ldr             x8, [x8, #0x730]
    // 0x69e7e4: r3 = Null
    //     0x69e7e4: add             x3, PP, #0x57, lsl #12  ; [pp+0x57748] Null
    //     0x69e7e8: ldr             x3, [x3, #0x748]
    // 0x69e7ec: r0 = DefaultTypeTest()
    //     0x69e7ec: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x69e7f0: ldur            x0, [fp, #-0x28]
    // 0x69e7f4: ldur            x1, [fp, #-0x58]
    // 0x69e7f8: ArrayLoad: r2 = r0[r1]  ; Unknown_4
    //     0x69e7f8: add             x16, x0, x1, lsl #2
    //     0x69e7fc: ldur            w2, [x16, #0xf]
    // 0x69e800: DecompressPointer r2
    //     0x69e800: add             x2, x2, HEAP, lsl #32
    // 0x69e804: LoadField: d0 = r2->field_7
    //     0x69e804: ldur            d0, [x2, #7]
    // 0x69e808: stur            d0, [fp, #-0x78]
    // 0x69e80c: r0 = Offset()
    //     0x69e80c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x69e810: ldur            d0, [fp, #-0x78]
    // 0x69e814: StoreField: r0->field_7 = d0
    //     0x69e814: stur            d0, [x0, #7]
    // 0x69e818: ldur            d0, [fp, #-0x70]
    // 0x69e81c: StoreField: r0->field_f = d0
    //     0x69e81c: stur            d0, [x0, #0xf]
    // 0x69e820: ldur            x1, [fp, #-0x68]
    // 0x69e824: StoreField: r1->field_7 = r0
    //     0x69e824: stur            w0, [x1, #7]
    //     0x69e828: ldurb           w16, [x1, #-1]
    //     0x69e82c: ldurb           w17, [x0, #-1]
    //     0x69e830: and             x16, x17, x16, lsr #2
    //     0x69e834: tst             x16, HEAP, lsr #32
    //     0x69e838: b.eq            #0x69e840
    //     0x69e83c: bl              #0xd6826c
    // 0x69e840: b               #0x69e848
    // 0x69e844: ldur            d0, [fp, #-0x70]
    // 0x69e848: ldur            x0, [fp, #-0x58]
    // 0x69e84c: add             x8, x0, #1
    // 0x69e850: ldur            x4, [fp, #-0x48]
    // 0x69e854: ldur            x2, [fp, #-0x38]
    // 0x69e858: ldur            x5, [fp, #-0x60]
    // 0x69e85c: ldur            x3, [fp, #-0x10]
    // 0x69e860: d2 = 0.000000
    //     0x69e860: eor             v2.16b, v2.16b, v2.16b
    // 0x69e864: b               #0x69e738
    // 0x69e868: mov             x1, x4
    // 0x69e86c: mov             x0, x2
    // 0x69e870: LoadField: d1 = r0->field_7
    //     0x69e870: ldur            d1, [x0, #7]
    // 0x69e874: fadd            d2, d0, d1
    // 0x69e878: add             x7, x1, #1
    // 0x69e87c: mov             v0.16b, v2.16b
    // 0x69e880: ldr             x2, [fp, #0x10]
    // 0x69e884: ldur            x3, [fp, #-0x10]
    // 0x69e888: ldur            x0, [fp, #-0x50]
    // 0x69e88c: b               #0x69e390
    // 0x69e890: mov             x0, x1
    // 0x69e894: LoadField: r1 = r0->field_b
    //     0x69e894: ldur            w1, [x0, #0xb]
    // 0x69e898: DecompressPointer r1
    //     0x69e898: add             x1, x1, HEAP, lsl #32
    // 0x69e89c: stur            x1, [fp, #-0x20]
    // 0x69e8a0: LoadField: r2 = r0->field_f
    //     0x69e8a0: ldur            w2, [x0, #0xf]
    // 0x69e8a4: DecompressPointer r2
    //     0x69e8a4: add             x2, x2, HEAP, lsl #32
    // 0x69e8a8: LoadField: r3 = r2->field_b
    //     0x69e8a8: ldur            w3, [x2, #0xb]
    // 0x69e8ac: DecompressPointer r3
    //     0x69e8ac: add             x3, x3, HEAP, lsl #32
    // 0x69e8b0: cmp             w1, w3
    // 0x69e8b4: b.ne            #0x69e8c4
    // 0x69e8b8: SaveReg r0
    //     0x69e8b8: str             x0, [SP, #-8]!
    // 0x69e8bc: r0 = _growToNextCapacity()
    //     0x69e8bc: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x69e8c0: add             SP, SP, #8
    // 0x69e8c4: ldr             x3, [fp, #0x10]
    // 0x69e8c8: ldur            x2, [fp, #-0x30]
    // 0x69e8cc: ldur            d0, [fp, #-0x70]
    // 0x69e8d0: ldur            x0, [fp, #-0x20]
    // 0x69e8d4: r4 = LoadInt32Instr(r0)
    //     0x69e8d4: sbfx            x4, x0, #1, #0x1f
    // 0x69e8d8: add             x0, x4, #1
    // 0x69e8dc: lsl             x1, x0, #1
    // 0x69e8e0: StoreField: r2->field_b = r1
    //     0x69e8e0: stur            w1, [x2, #0xb]
    // 0x69e8e4: mov             x1, x4
    // 0x69e8e8: cmp             x1, x0
    // 0x69e8ec: b.hs            #0x69eb40
    // 0x69e8f0: LoadField: r1 = r2->field_f
    //     0x69e8f0: ldur            w1, [x2, #0xf]
    // 0x69e8f4: DecompressPointer r1
    //     0x69e8f4: add             x1, x1, HEAP, lsl #32
    // 0x69e8f8: r0 = inline_Allocate_Double()
    //     0x69e8f8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x69e8fc: add             x0, x0, #0x10
    //     0x69e900: cmp             x2, x0
    //     0x69e904: b.ls            #0x69eb44
    //     0x69e908: str             x0, [THR, #0x60]  ; THR::top
    //     0x69e90c: sub             x0, x0, #0xf
    //     0x69e910: mov             x2, #0xd108
    //     0x69e914: movk            x2, #3, lsl #16
    //     0x69e918: stur            x2, [x0, #-1]
    // 0x69e91c: StoreField: r0->field_7 = d0
    //     0x69e91c: stur            d0, [x0, #7]
    // 0x69e920: ArrayStore: r1[r4] = r0  ; List_4
    //     0x69e920: add             x25, x1, x4, lsl #2
    //     0x69e924: add             x25, x25, #0xf
    //     0x69e928: str             w0, [x25]
    //     0x69e92c: tbz             w0, #0, #0x69e948
    //     0x69e930: ldurb           w16, [x1, #-1]
    //     0x69e934: ldurb           w17, [x0, #-1]
    //     0x69e938: and             x16, x17, x16, lsr #2
    //     0x69e93c: tst             x16, HEAP, lsr #32
    //     0x69e940: b.eq            #0x69e948
    //     0x69e944: bl              #0xd67e5c
    // 0x69e948: LoadField: r0 = r3->field_a3
    //     0x69e948: ldur            w0, [x3, #0xa3]
    // 0x69e94c: DecompressPointer r0
    //     0x69e94c: add             x0, x0, HEAP, lsl #32
    // 0x69e950: r16 = Sentinel
    //     0x69e950: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x69e954: cmp             w0, w16
    // 0x69e958: b.eq            #0x69eb64
    // 0x69e95c: LoadField: d1 = r0->field_7
    //     0x69e95c: ldur            d1, [x0, #7]
    // 0x69e960: stur            d1, [fp, #-0x78]
    // 0x69e964: r0 = Size()
    //     0x69e964: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x69e968: ldur            d0, [fp, #-0x78]
    // 0x69e96c: StoreField: r0->field_7 = d0
    //     0x69e96c: stur            d0, [x0, #7]
    // 0x69e970: ldur            d0, [fp, #-0x70]
    // 0x69e974: StoreField: r0->field_f = d0
    //     0x69e974: stur            d0, [x0, #0xf]
    // 0x69e978: ldur            x16, [fp, #-8]
    // 0x69e97c: stp             x0, x16, [SP, #-0x10]!
    // 0x69e980: r0 = constrain()
    //     0x69e980: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x69e984: add             SP, SP, #0x10
    // 0x69e988: ldr             x1, [fp, #0x10]
    // 0x69e98c: StoreField: r1->field_57 = r0
    //     0x69e98c: stur            w0, [x1, #0x57]
    //     0x69e990: ldurb           w16, [x1, #-1]
    //     0x69e994: ldurb           w17, [x0, #-1]
    //     0x69e998: and             x16, x17, x16, lsr #2
    //     0x69e99c: tst             x16, HEAP, lsr #32
    //     0x69e9a0: b.eq            #0x69e9a8
    //     0x69e9a4: bl              #0xd6826c
    // 0x69e9a8: r0 = Null
    //     0x69e9a8: mov             x0, NULL
    // 0x69e9ac: LeaveFrame
    //     0x69e9ac: mov             SP, fp
    //     0x69e9b0: ldp             fp, lr, [SP], #0x10
    // 0x69e9b4: ret
    //     0x69e9b4: ret             
    // 0x69e9b8: r0 = StateError()
    //     0x69e9b8: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x69e9bc: mov             x1, x0
    // 0x69e9c0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x69e9c0: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x69e9c4: ldr             x0, [x0, #0x1e8]
    // 0x69e9c8: StoreField: r1->field_b = r0
    //     0x69e9c8: stur            w0, [x1, #0xb]
    // 0x69e9cc: mov             x0, x1
    // 0x69e9d0: r0 = Throw()
    //     0x69e9d0: bl              #0xd67e38  ; ThrowStub
    // 0x69e9d4: brk             #0
    // 0x69e9d8: r0 = noElement()
    //     0x69e9d8: bl              #0x4c8048  ; [dart:_internal] IterableElementError::noElement
    // 0x69e9dc: r0 = Throw()
    //     0x69e9dc: bl              #0xd67e38  ; ThrowStub
    // 0x69e9e0: brk             #0
    // 0x69e9e4: r0 = noElement()
    //     0x69e9e4: bl              #0x4c8048  ; [dart:_internal] IterableElementError::noElement
    // 0x69e9e8: r0 = Throw()
    //     0x69e9e8: bl              #0xd67e38  ; ThrowStub
    // 0x69e9ec: brk             #0
    // 0x69e9f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69e9f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69e9f4: b               #0x69deb0
    // 0x69e9f8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x69e9f8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x69e9fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69e9fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69ea00: b               #0x69e008
    // 0x69ea04: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x69ea04: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x69ea08: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x69ea08: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x69ea0c: r0 = RangeErrorSharedWithFPURegs()
    //     0x69ea0c: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x69ea10: SaveReg d2
    //     0x69ea10: str             q2, [SP, #-0x10]!
    // 0x69ea14: stp             x6, x7, [SP, #-0x10]!
    // 0x69ea18: stp             x4, x5, [SP, #-0x10]!
    // 0x69ea1c: stp             x2, x3, [SP, #-0x10]!
    // 0x69ea20: r0 = AllocateDouble()
    //     0x69ea20: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x69ea24: ldp             x2, x3, [SP], #0x10
    // 0x69ea28: ldp             x4, x5, [SP], #0x10
    // 0x69ea2c: ldp             x6, x7, [SP], #0x10
    // 0x69ea30: RestoreReg d2
    //     0x69ea30: ldr             q2, [SP], #0x10
    // 0x69ea34: b               #0x69e088
    // 0x69ea38: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x69ea38: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x69ea3c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x69ea3c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x69ea40: SaveReg d2
    //     0x69ea40: str             q2, [SP, #-0x10]!
    // 0x69ea44: stp             x5, x7, [SP, #-0x10]!
    // 0x69ea48: stp             x3, x4, [SP, #-0x10]!
    // 0x69ea4c: SaveReg r2
    //     0x69ea4c: str             x2, [SP, #-8]!
    // 0x69ea50: r0 = AllocateDouble()
    //     0x69ea50: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x69ea54: RestoreReg r2
    //     0x69ea54: ldr             x2, [SP], #8
    // 0x69ea58: ldp             x3, x4, [SP], #0x10
    // 0x69ea5c: ldp             x5, x7, [SP], #0x10
    // 0x69ea60: RestoreReg d2
    //     0x69ea60: ldr             q2, [SP], #0x10
    // 0x69ea64: b               #0x69e174
    // 0x69ea68: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x69ea68: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x69ea6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69ea6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69ea70: b               #0x69e1f0
    // 0x69ea74: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x69ea74: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x69ea78: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x69ea78: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x69ea7c: SaveReg d2
    //     0x69ea7c: str             q2, [SP, #-0x10]!
    // 0x69ea80: stp             x7, x8, [SP, #-0x10]!
    // 0x69ea84: stp             x5, x6, [SP, #-0x10]!
    // 0x69ea88: stp             x3, x4, [SP, #-0x10]!
    // 0x69ea8c: SaveReg r2
    //     0x69ea8c: str             x2, [SP, #-8]!
    // 0x69ea90: r0 = AllocateDouble()
    //     0x69ea90: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x69ea94: RestoreReg r2
    //     0x69ea94: ldr             x2, [SP], #8
    // 0x69ea98: ldp             x3, x4, [SP], #0x10
    // 0x69ea9c: ldp             x5, x6, [SP], #0x10
    // 0x69eaa0: ldp             x7, x8, [SP], #0x10
    // 0x69eaa4: RestoreReg d2
    //     0x69eaa4: ldr             q2, [SP], #0x10
    // 0x69eaa8: b               #0x69e264
    // 0x69eaac: SaveReg d2
    //     0x69eaac: str             q2, [SP, #-0x10]!
    // 0x69eab0: r0 = AllocateDouble()
    //     0x69eab0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x69eab4: RestoreReg d2
    //     0x69eab4: ldr             q2, [SP], #0x10
    // 0x69eab8: b               #0x69e318
    // 0x69eabc: r0 = StackOverflowSharedWithFPURegs()
    //     0x69eabc: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x69eac0: b               #0x69e3b4
    // 0x69eac4: r0 = RangeErrorSharedWithFPURegs()
    //     0x69eac4: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x69eac8: SaveReg d0
    //     0x69eac8: str             q0, [SP, #-0x10]!
    // 0x69eacc: stp             x2, x3, [SP, #-0x10]!
    // 0x69ead0: SaveReg r1
    //     0x69ead0: str             x1, [SP, #-8]!
    // 0x69ead4: r0 = AllocateDouble()
    //     0x69ead4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x69ead8: RestoreReg r1
    //     0x69ead8: ldr             x1, [SP], #8
    // 0x69eadc: ldp             x2, x3, [SP], #0x10
    // 0x69eae0: RestoreReg d0
    //     0x69eae0: ldr             q0, [SP], #0x10
    // 0x69eae4: b               #0x69e440
    // 0x69eae8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69eae8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69eaec: b               #0x69e48c
    // 0x69eaf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69eaf0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69eaf4: b               #0x69e4dc
    // 0x69eaf8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69eaf8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69eafc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x69eafc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x69eb00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69eb00: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69eb04: SaveReg d0
    //     0x69eb04: str             q0, [SP, #-0x10]!
    // 0x69eb08: r0 = AllocateDouble()
    //     0x69eb08: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x69eb0c: RestoreReg d0
    //     0x69eb0c: ldr             q0, [SP], #0x10
    // 0x69eb10: b               #0x69e668
    // 0x69eb14: stp             q2, q3, [SP, #-0x20]!
    // 0x69eb18: r0 = AllocateDouble()
    //     0x69eb18: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x69eb1c: ldp             q2, q3, [SP], #0x20
    // 0x69eb20: b               #0x69e6ac
    // 0x69eb24: stp             q0, q2, [SP, #-0x20]!
    // 0x69eb28: r0 = AllocateDouble()
    //     0x69eb28: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x69eb2c: ldp             q0, q2, [SP], #0x20
    // 0x69eb30: b               #0x69e6e0
    // 0x69eb34: r0 = StackOverflowSharedWithFPURegs()
    //     0x69eb34: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x69eb38: b               #0x69e750
    // 0x69eb3c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x69eb3c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x69eb40: r0 = RangeErrorSharedWithFPURegs()
    //     0x69eb40: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x69eb44: SaveReg d0
    //     0x69eb44: str             q0, [SP, #-0x10]!
    // 0x69eb48: stp             x3, x4, [SP, #-0x10]!
    // 0x69eb4c: SaveReg r1
    //     0x69eb4c: str             x1, [SP, #-8]!
    // 0x69eb50: r0 = AllocateDouble()
    //     0x69eb50: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x69eb54: RestoreReg r1
    //     0x69eb54: ldr             x1, [SP], #8
    // 0x69eb58: ldp             x3, x4, [SP], #0x10
    // 0x69eb5c: RestoreReg d0
    //     0x69eb5c: ldr             q0, [SP], #0x10
    // 0x69eb60: b               #0x69e91c
    // 0x69eb64: r9 = _tableWidth
    //     0x69eb64: add             x9, PP, #0x57, lsl #12  ; [pp+0x57708] Field <RenderTable._tableWidth@919148626>: late (offset: 0xa4)
    //     0x69eb68: ldr             x9, [x9, #0x708]
    // 0x69eb6c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x69eb6c: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
  }
  _ setFlatChildren(/* No info */) {
    // ** addr: 0x6b65cc, size: 0x8a4
    // 0x6b65cc: EnterFrame
    //     0x6b65cc: stp             fp, lr, [SP, #-0x10]!
    //     0x6b65d0: mov             fp, SP
    // 0x6b65d4: AllocStack(0x38)
    //     0x6b65d4: sub             SP, SP, #0x38
    // 0x6b65d8: CheckStackOverflow
    //     0x6b65d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6b65dc: cmp             SP, x16
    //     0x6b65e0: b.ls            #0x6b6e1c
    // 0x6b65e4: ldr             x1, [fp, #0x20]
    // 0x6b65e8: LoadField: r0 = r1->field_5f
    //     0x6b65e8: ldur            w0, [x1, #0x5f]
    // 0x6b65ec: DecompressPointer r0
    //     0x6b65ec: add             x0, x0, HEAP, lsl #32
    // 0x6b65f0: ldr             x2, [fp, #0x10]
    // 0x6b65f4: r3 = LoadClassIdInstr(r2)
    //     0x6b65f4: ldur            x3, [x2, #-1]
    //     0x6b65f8: ubfx            x3, x3, #0xc, #0x14
    // 0x6b65fc: stp             x0, x2, [SP, #-0x10]!
    // 0x6b6600: mov             x0, x3
    // 0x6b6604: mov             lr, x0
    // 0x6b6608: ldr             lr, [x21, lr, lsl #3]
    // 0x6b660c: blr             lr
    // 0x6b6610: add             SP, SP, #0x10
    // 0x6b6614: tbnz            w0, #4, #0x6b663c
    // 0x6b6618: ldr             x1, [fp, #0x20]
    // 0x6b661c: ldr             x2, [fp, #0x18]
    // 0x6b6620: LoadField: r0 = r1->field_63
    //     0x6b6620: ldur            x0, [x1, #0x63]
    // 0x6b6624: cmp             x2, x0
    // 0x6b6628: b.ne            #0x6b6644
    // 0x6b662c: r0 = Null
    //     0x6b662c: mov             x0, NULL
    // 0x6b6630: LeaveFrame
    //     0x6b6630: mov             SP, fp
    //     0x6b6634: ldp             fp, lr, [SP], #0x10
    // 0x6b6638: ret
    //     0x6b6638: ret             
    // 0x6b663c: ldr             x1, [fp, #0x20]
    // 0x6b6640: ldr             x2, [fp, #0x18]
    // 0x6b6644: cbnz            x2, #0x6b6650
    // 0x6b6648: mov             x0, x2
    // 0x6b664c: b               #0x6b6680
    // 0x6b6650: ldr             x3, [fp, #0x10]
    // 0x6b6654: r0 = LoadClassIdInstr(r3)
    //     0x6b6654: ldur            x0, [x3, #-1]
    //     0x6b6658: ubfx            x0, x0, #0xc, #0x14
    // 0x6b665c: SaveReg r3
    //     0x6b665c: str             x3, [SP, #-8]!
    // 0x6b6660: r0 = GDT[cid_x0 + 0xccd1]()
    //     0x6b6660: mov             x17, #0xccd1
    //     0x6b6664: add             lr, x0, x17
    //     0x6b6668: ldr             lr, [x21, lr, lsl #3]
    //     0x6b666c: blr             lr
    // 0x6b6670: add             SP, SP, #8
    // 0x6b6674: tbnz            w0, #4, #0x6b687c
    // 0x6b6678: ldr             x1, [fp, #0x20]
    // 0x6b667c: ldr             x0, [fp, #0x18]
    // 0x6b6680: StoreField: r1->field_63 = r0
    //     0x6b6680: stur            x0, [x1, #0x63]
    // 0x6b6684: LoadField: r0 = r1->field_5f
    //     0x6b6684: ldur            w0, [x1, #0x5f]
    // 0x6b6688: DecompressPointer r0
    //     0x6b6688: add             x0, x0, HEAP, lsl #32
    // 0x6b668c: r2 = LoadClassIdInstr(r0)
    //     0x6b668c: ldur            x2, [x0, #-1]
    //     0x6b6690: ubfx            x2, x2, #0xc, #0x14
    // 0x6b6694: SaveReg r0
    //     0x6b6694: str             x0, [SP, #-8]!
    // 0x6b6698: mov             x0, x2
    // 0x6b669c: r0 = GDT[cid_x0 + 0xccd1]()
    //     0x6b669c: mov             x17, #0xccd1
    //     0x6b66a0: add             lr, x0, x17
    //     0x6b66a4: ldr             lr, [x21, lr, lsl #3]
    //     0x6b66a8: blr             lr
    // 0x6b66ac: add             SP, SP, #8
    // 0x6b66b0: tbnz            w0, #4, #0x6b66c4
    // 0x6b66b4: r0 = Null
    //     0x6b66b4: mov             x0, NULL
    // 0x6b66b8: LeaveFrame
    //     0x6b66b8: mov             SP, fp
    //     0x6b66bc: ldp             fp, lr, [SP], #0x10
    // 0x6b66c0: ret
    //     0x6b66c0: ret             
    // 0x6b66c4: ldr             x1, [fp, #0x20]
    // 0x6b66c8: LoadField: r0 = r1->field_5f
    //     0x6b66c8: ldur            w0, [x1, #0x5f]
    // 0x6b66cc: DecompressPointer r0
    //     0x6b66cc: add             x0, x0, HEAP, lsl #32
    // 0x6b66d0: r2 = LoadClassIdInstr(r0)
    //     0x6b66d0: ldur            x2, [x0, #-1]
    //     0x6b66d4: ubfx            x2, x2, #0xc, #0x14
    // 0x6b66d8: SaveReg r0
    //     0x6b66d8: str             x0, [SP, #-8]!
    // 0x6b66dc: mov             x0, x2
    // 0x6b66e0: r0 = GDT[cid_x0 + 0xb940]()
    //     0x6b66e0: mov             x17, #0xb940
    //     0x6b66e4: add             lr, x0, x17
    //     0x6b66e8: ldr             lr, [x21, lr, lsl #3]
    //     0x6b66ec: blr             lr
    // 0x6b66f0: add             SP, SP, #8
    // 0x6b66f4: mov             x1, x0
    // 0x6b66f8: stur            x1, [fp, #-8]
    // 0x6b66fc: CheckStackOverflow
    //     0x6b66fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6b6700: cmp             SP, x16
    //     0x6b6704: b.ls            #0x6b6e24
    // 0x6b6708: r0 = LoadClassIdInstr(r1)
    //     0x6b6708: ldur            x0, [x1, #-1]
    //     0x6b670c: ubfx            x0, x0, #0xc, #0x14
    // 0x6b6710: SaveReg r1
    //     0x6b6710: str             x1, [SP, #-8]!
    // 0x6b6714: r0 = GDT[cid_x0 + 0x541]()
    //     0x6b6714: add             lr, x0, #0x541
    //     0x6b6718: ldr             lr, [x21, lr, lsl #3]
    //     0x6b671c: blr             lr
    // 0x6b6720: add             SP, SP, #8
    // 0x6b6724: tbnz            w0, #4, #0x6b6828
    // 0x6b6728: ldur            x1, [fp, #-8]
    // 0x6b672c: r0 = LoadClassIdInstr(r1)
    //     0x6b672c: ldur            x0, [x1, #-1]
    //     0x6b6730: ubfx            x0, x0, #0xc, #0x14
    // 0x6b6734: SaveReg r1
    //     0x6b6734: str             x1, [SP, #-8]!
    // 0x6b6738: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x6b6738: add             lr, x0, #0x5ca
    //     0x6b673c: ldr             lr, [x21, lr, lsl #3]
    //     0x6b6740: blr             lr
    // 0x6b6744: add             SP, SP, #8
    // 0x6b6748: mov             x3, x0
    // 0x6b674c: stur            x3, [fp, #-0x10]
    // 0x6b6750: cmp             w3, NULL
    // 0x6b6754: b.eq            #0x6b6820
    // 0x6b6758: mov             x0, x3
    // 0x6b675c: r2 = Null
    //     0x6b675c: mov             x2, NULL
    // 0x6b6760: r1 = Null
    //     0x6b6760: mov             x1, NULL
    // 0x6b6764: r4 = 59
    //     0x6b6764: mov             x4, #0x3b
    // 0x6b6768: branchIfSmi(r0, 0x6b6774)
    //     0x6b6768: tbz             w0, #0, #0x6b6774
    // 0x6b676c: r4 = LoadClassIdInstr(r0)
    //     0x6b676c: ldur            x4, [x0, #-1]
    //     0x6b6770: ubfx            x4, x4, #0xc, #0x14
    // 0x6b6774: sub             x4, x4, #0x961
    // 0x6b6778: cmp             x4, #0xbe
    // 0x6b677c: b.ls            #0x6b6790
    // 0x6b6780: r8 = RenderObject
    //     0x6b6780: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x6b6784: r3 = Null
    //     0x6b6784: add             x3, PP, #0x57, lsl #12  ; [pp+0x575e0] Null
    //     0x6b6788: ldr             x3, [x3, #0x5e0]
    // 0x6b678c: r0 = RenderObject()
    //     0x6b678c: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x6b6790: ldur            x16, [fp, #-0x10]
    // 0x6b6794: SaveReg r16
    //     0x6b6794: str             x16, [SP, #-8]!
    // 0x6b6798: r0 = _cleanRelayoutBoundary()
    //     0x6b6798: bl              #0x5e5ed0  ; [package:flutter/src/rendering/object.dart] RenderObject::_cleanRelayoutBoundary
    // 0x6b679c: add             SP, SP, #8
    // 0x6b67a0: ldur            x1, [fp, #-0x10]
    // 0x6b67a4: LoadField: r0 = r1->field_17
    //     0x6b67a4: ldur            w0, [x1, #0x17]
    // 0x6b67a8: DecompressPointer r0
    //     0x6b67a8: add             x0, x0, HEAP, lsl #32
    // 0x6b67ac: cmp             w0, NULL
    // 0x6b67b0: b.eq            #0x6b6e2c
    // 0x6b67b4: r2 = LoadClassIdInstr(r0)
    //     0x6b67b4: ldur            x2, [x0, #-1]
    //     0x6b67b8: ubfx            x2, x2, #0xc, #0x14
    // 0x6b67bc: SaveReg r0
    //     0x6b67bc: str             x0, [SP, #-8]!
    // 0x6b67c0: mov             x0, x2
    // 0x6b67c4: r0 = GDT[cid_x0 + 0x1c36]()
    //     0x6b67c4: mov             x17, #0x1c36
    //     0x6b67c8: add             lr, x0, x17
    //     0x6b67cc: ldr             lr, [x21, lr, lsl #3]
    //     0x6b67d0: blr             lr
    // 0x6b67d4: add             SP, SP, #8
    // 0x6b67d8: ldur            x0, [fp, #-0x10]
    // 0x6b67dc: StoreField: r0->field_17 = rNULL
    //     0x6b67dc: stur            NULL, [x0, #0x17]
    // 0x6b67e0: ldr             x16, [fp, #0x20]
    // 0x6b67e4: stp             x0, x16, [SP, #-0x10]!
    // 0x6b67e8: r0 = dropChild()
    //     0x6b67e8: bl              #0x5df5b4  ; [package:flutter/src/foundation/node.dart] AbstractNode::dropChild
    // 0x6b67ec: add             SP, SP, #0x10
    // 0x6b67f0: ldr             x16, [fp, #0x20]
    // 0x6b67f4: SaveReg r16
    //     0x6b67f4: str             x16, [SP, #-8]!
    // 0x6b67f8: r0 = markNeedsLayout()
    //     0x6b67f8: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6b67fc: add             SP, SP, #8
    // 0x6b6800: ldr             x16, [fp, #0x20]
    // 0x6b6804: SaveReg r16
    //     0x6b6804: str             x16, [SP, #-8]!
    // 0x6b6808: r0 = markNeedsCompositingBitsUpdate()
    //     0x6b6808: bl              #0x5e5c40  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsCompositingBitsUpdate
    // 0x6b680c: add             SP, SP, #8
    // 0x6b6810: ldr             x16, [fp, #0x20]
    // 0x6b6814: SaveReg r16
    //     0x6b6814: str             x16, [SP, #-8]!
    // 0x6b6818: r0 = markNeedsSemanticsUpdate()
    //     0x6b6818: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6b681c: add             SP, SP, #8
    // 0x6b6820: ldur            x1, [fp, #-8]
    // 0x6b6824: b               #0x6b66fc
    // 0x6b6828: ldr             x1, [fp, #0x20]
    // 0x6b682c: r0 = 0
    //     0x6b682c: mov             x0, #0
    // 0x6b6830: StoreField: r1->field_6b = r0
    //     0x6b6830: stur            x0, [x1, #0x6b]
    // 0x6b6834: LoadField: r0 = r1->field_5f
    //     0x6b6834: ldur            w0, [x1, #0x5f]
    // 0x6b6838: DecompressPointer r0
    //     0x6b6838: add             x0, x0, HEAP, lsl #32
    // 0x6b683c: r2 = LoadClassIdInstr(r0)
    //     0x6b683c: ldur            x2, [x0, #-1]
    //     0x6b6840: ubfx            x2, x2, #0xc, #0x14
    // 0x6b6844: SaveReg r0
    //     0x6b6844: str             x0, [SP, #-8]!
    // 0x6b6848: mov             x0, x2
    // 0x6b684c: r0 = GDT[cid_x0 + -0xb75]()
    //     0x6b684c: sub             lr, x0, #0xb75
    //     0x6b6850: ldr             lr, [x21, lr, lsl #3]
    //     0x6b6854: blr             lr
    // 0x6b6858: add             SP, SP, #8
    // 0x6b685c: ldr             x16, [fp, #0x20]
    // 0x6b6860: SaveReg r16
    //     0x6b6860: str             x16, [SP, #-8]!
    // 0x6b6864: r0 = markNeedsLayout()
    //     0x6b6864: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6b6868: add             SP, SP, #8
    // 0x6b686c: r0 = Null
    //     0x6b686c: mov             x0, NULL
    // 0x6b6870: LeaveFrame
    //     0x6b6870: mov             SP, fp
    //     0x6b6874: ldp             fp, lr, [SP], #0x10
    // 0x6b6878: ret
    //     0x6b6878: ret             
    // 0x6b687c: ldr             x0, [fp, #0x18]
    // 0x6b6880: r16 = <RenderBox>
    //     0x6b6880: ldr             x16, [PP, #0x3b20]  ; [pp+0x3b20] TypeArguments: <RenderBox>
    // 0x6b6884: SaveReg r16
    //     0x6b6884: str             x16, [SP, #-8]!
    // 0x6b6888: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6b6888: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6b688c: r0 = HashSet()
    //     0x6b688c: bl              #0x5519d0  ; [dart:collection] HashSet::HashSet
    // 0x6b6890: add             SP, SP, #8
    // 0x6b6894: mov             x2, x0
    // 0x6b6898: stur            x2, [fp, #-0x10]
    // 0x6b689c: r6 = 0
    //     0x6b689c: mov             x6, #0
    // 0x6b68a0: ldr             x4, [fp, #0x20]
    // 0x6b68a4: ldr             x3, [fp, #0x18]
    // 0x6b68a8: ldr             x5, [fp, #0x10]
    // 0x6b68ac: stur            x6, [fp, #-0x30]
    // 0x6b68b0: CheckStackOverflow
    //     0x6b68b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6b68b4: cmp             SP, x16
    //     0x6b68b8: b.ls            #0x6b6e30
    // 0x6b68bc: LoadField: r0 = r4->field_6b
    //     0x6b68bc: ldur            x0, [x4, #0x6b]
    // 0x6b68c0: cmp             x6, x0
    // 0x6b68c4: b.ge            #0x6b6ab8
    // 0x6b68c8: mul             x7, x6, x3
    // 0x6b68cc: stur            x7, [fp, #-0x28]
    // 0x6b68d0: r8 = 0
    //     0x6b68d0: mov             x8, #0
    // 0x6b68d4: stur            x8, [fp, #-0x20]
    // 0x6b68d8: CheckStackOverflow
    //     0x6b68d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6b68dc: cmp             SP, x16
    //     0x6b68e0: b.ls            #0x6b6e38
    // 0x6b68e4: LoadField: r0 = r4->field_63
    //     0x6b68e4: ldur            x0, [x4, #0x63]
    // 0x6b68e8: cmp             x8, x0
    // 0x6b68ec: b.ge            #0x6b6aa8
    // 0x6b68f0: mul             x1, x6, x0
    // 0x6b68f4: add             x9, x8, x1
    // 0x6b68f8: add             x10, x8, x7
    // 0x6b68fc: stur            x10, [fp, #-0x18]
    // 0x6b6900: LoadField: r11 = r4->field_5f
    //     0x6b6900: ldur            w11, [x4, #0x5f]
    // 0x6b6904: DecompressPointer r11
    //     0x6b6904: add             x11, x11, HEAP, lsl #32
    // 0x6b6908: r0 = BoxInt64Instr(r9)
    //     0x6b6908: sbfiz           x0, x9, #1, #0x1f
    //     0x6b690c: cmp             x9, x0, asr #1
    //     0x6b6910: b.eq            #0x6b691c
    //     0x6b6914: bl              #0xd69bb8
    //     0x6b6918: stur            x9, [x0, #7]
    // 0x6b691c: mov             x1, x0
    // 0x6b6920: stur            x1, [fp, #-8]
    // 0x6b6924: r0 = LoadClassIdInstr(r11)
    //     0x6b6924: ldur            x0, [x11, #-1]
    //     0x6b6928: ubfx            x0, x0, #0xc, #0x14
    // 0x6b692c: stp             x1, x11, [SP, #-0x10]!
    // 0x6b6930: r0 = GDT[cid_x0 + -0xd83]()
    //     0x6b6930: sub             lr, x0, #0xd83
    //     0x6b6934: ldr             lr, [x21, lr, lsl #3]
    //     0x6b6938: blr             lr
    // 0x6b693c: add             SP, SP, #0x10
    // 0x6b6940: cmp             w0, NULL
    // 0x6b6944: b.eq            #0x6b6a84
    // 0x6b6948: ldr             x1, [fp, #0x18]
    // 0x6b694c: ldur            x2, [fp, #-0x20]
    // 0x6b6950: cmp             x2, x1
    // 0x6b6954: b.ge            #0x6b6a3c
    // 0x6b6958: ldr             x3, [fp, #0x10]
    // 0x6b695c: ldur            x4, [fp, #-0x18]
    // 0x6b6960: r0 = LoadClassIdInstr(r3)
    //     0x6b6960: ldur            x0, [x3, #-1]
    //     0x6b6964: ubfx            x0, x0, #0xc, #0x14
    // 0x6b6968: SaveReg r3
    //     0x6b6968: str             x3, [SP, #-8]!
    // 0x6b696c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x6b696c: mov             x17, #0xb8ea
    //     0x6b6970: add             lr, x0, x17
    //     0x6b6974: ldr             lr, [x21, lr, lsl #3]
    //     0x6b6978: blr             lr
    // 0x6b697c: add             SP, SP, #8
    // 0x6b6980: r1 = LoadInt32Instr(r0)
    //     0x6b6980: sbfx            x1, x0, #1, #0x1f
    // 0x6b6984: ldur            x2, [fp, #-0x18]
    // 0x6b6988: cmp             x2, x1
    // 0x6b698c: b.ge            #0x6b6a3c
    // 0x6b6990: ldr             x3, [fp, #0x20]
    // 0x6b6994: ldr             x1, [fp, #0x10]
    // 0x6b6998: LoadField: r0 = r3->field_5f
    //     0x6b6998: ldur            w0, [x3, #0x5f]
    // 0x6b699c: DecompressPointer r0
    //     0x6b699c: add             x0, x0, HEAP, lsl #32
    // 0x6b69a0: r4 = LoadClassIdInstr(r0)
    //     0x6b69a0: ldur            x4, [x0, #-1]
    //     0x6b69a4: ubfx            x4, x4, #0xc, #0x14
    // 0x6b69a8: ldur            x16, [fp, #-8]
    // 0x6b69ac: stp             x16, x0, [SP, #-0x10]!
    // 0x6b69b0: mov             x0, x4
    // 0x6b69b4: r0 = GDT[cid_x0 + -0xd83]()
    //     0x6b69b4: sub             lr, x0, #0xd83
    //     0x6b69b8: ldr             lr, [x21, lr, lsl #3]
    //     0x6b69bc: blr             lr
    // 0x6b69c0: add             SP, SP, #0x10
    // 0x6b69c4: mov             x3, x0
    // 0x6b69c8: ldur            x2, [fp, #-0x18]
    // 0x6b69cc: stur            x3, [fp, #-0x38]
    // 0x6b69d0: r0 = BoxInt64Instr(r2)
    //     0x6b69d0: sbfiz           x0, x2, #1, #0x1f
    //     0x6b69d4: cmp             x2, x0, asr #1
    //     0x6b69d8: b.eq            #0x6b69e4
    //     0x6b69dc: bl              #0xd69bb8
    //     0x6b69e0: stur            x2, [x0, #7]
    // 0x6b69e4: ldr             x1, [fp, #0x10]
    // 0x6b69e8: r2 = LoadClassIdInstr(r1)
    //     0x6b69e8: ldur            x2, [x1, #-1]
    //     0x6b69ec: ubfx            x2, x2, #0xc, #0x14
    // 0x6b69f0: stp             x0, x1, [SP, #-0x10]!
    // 0x6b69f4: mov             x0, x2
    // 0x6b69f8: r0 = GDT[cid_x0 + -0xd83]()
    //     0x6b69f8: sub             lr, x0, #0xd83
    //     0x6b69fc: ldr             lr, [x21, lr, lsl #3]
    //     0x6b6a00: blr             lr
    // 0x6b6a04: add             SP, SP, #0x10
    // 0x6b6a08: mov             x1, x0
    // 0x6b6a0c: ldur            x0, [fp, #-0x38]
    // 0x6b6a10: r2 = 59
    //     0x6b6a10: mov             x2, #0x3b
    // 0x6b6a14: branchIfSmi(r0, 0x6b6a20)
    //     0x6b6a14: tbz             w0, #0, #0x6b6a20
    // 0x6b6a18: r2 = LoadClassIdInstr(r0)
    //     0x6b6a18: ldur            x2, [x0, #-1]
    //     0x6b6a1c: ubfx            x2, x2, #0xc, #0x14
    // 0x6b6a20: stp             x1, x0, [SP, #-0x10]!
    // 0x6b6a24: mov             x0, x2
    // 0x6b6a28: mov             lr, x0
    // 0x6b6a2c: ldr             lr, [x21, lr, lsl #3]
    // 0x6b6a30: blr             lr
    // 0x6b6a34: add             SP, SP, #0x10
    // 0x6b6a38: tbz             w0, #4, #0x6b6a84
    // 0x6b6a3c: ldr             x1, [fp, #0x20]
    // 0x6b6a40: LoadField: r0 = r1->field_5f
    //     0x6b6a40: ldur            w0, [x1, #0x5f]
    // 0x6b6a44: DecompressPointer r0
    //     0x6b6a44: add             x0, x0, HEAP, lsl #32
    // 0x6b6a48: r2 = LoadClassIdInstr(r0)
    //     0x6b6a48: ldur            x2, [x0, #-1]
    //     0x6b6a4c: ubfx            x2, x2, #0xc, #0x14
    // 0x6b6a50: ldur            x16, [fp, #-8]
    // 0x6b6a54: stp             x16, x0, [SP, #-0x10]!
    // 0x6b6a58: mov             x0, x2
    // 0x6b6a5c: r0 = GDT[cid_x0 + -0xd83]()
    //     0x6b6a5c: sub             lr, x0, #0xd83
    //     0x6b6a60: ldr             lr, [x21, lr, lsl #3]
    //     0x6b6a64: blr             lr
    // 0x6b6a68: add             SP, SP, #0x10
    // 0x6b6a6c: cmp             w0, NULL
    // 0x6b6a70: b.eq            #0x6b6e40
    // 0x6b6a74: ldur            x16, [fp, #-0x10]
    // 0x6b6a78: stp             x0, x16, [SP, #-0x10]!
    // 0x6b6a7c: r0 = add()
    //     0x6b6a7c: bl              #0xc4af80  ; [dart:collection] _HashSet::add
    // 0x6b6a80: add             SP, SP, #0x10
    // 0x6b6a84: ldur            x0, [fp, #-0x20]
    // 0x6b6a88: add             x8, x0, #1
    // 0x6b6a8c: ldr             x4, [fp, #0x20]
    // 0x6b6a90: ldr             x3, [fp, #0x18]
    // 0x6b6a94: ldr             x5, [fp, #0x10]
    // 0x6b6a98: ldur            x2, [fp, #-0x10]
    // 0x6b6a9c: ldur            x6, [fp, #-0x30]
    // 0x6b6aa0: ldur            x7, [fp, #-0x28]
    // 0x6b6aa4: b               #0x6b68d4
    // 0x6b6aa8: mov             x0, x6
    // 0x6b6aac: add             x6, x0, #1
    // 0x6b6ab0: ldur            x2, [fp, #-0x10]
    // 0x6b6ab4: b               #0x6b68a0
    // 0x6b6ab8: r5 = 0
    //     0x6b6ab8: mov             x5, #0
    // 0x6b6abc: ldr             x1, [fp, #0x20]
    // 0x6b6ac0: ldr             x3, [fp, #0x18]
    // 0x6b6ac4: ldr             x2, [fp, #0x10]
    // 0x6b6ac8: ldur            x4, [fp, #-0x10]
    // 0x6b6acc: stur            x5, [fp, #-0x20]
    // 0x6b6ad0: CheckStackOverflow
    //     0x6b6ad0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6b6ad4: cmp             SP, x16
    //     0x6b6ad8: b.ls            #0x6b6e44
    // 0x6b6adc: mul             x6, x5, x3
    // 0x6b6ae0: stur            x6, [fp, #-0x18]
    // 0x6b6ae4: r0 = LoadClassIdInstr(r2)
    //     0x6b6ae4: ldur            x0, [x2, #-1]
    //     0x6b6ae8: ubfx            x0, x0, #0xc, #0x14
    // 0x6b6aec: SaveReg r2
    //     0x6b6aec: str             x2, [SP, #-8]!
    // 0x6b6af0: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x6b6af0: mov             x17, #0xb8ea
    //     0x6b6af4: add             lr, x0, x17
    //     0x6b6af8: ldr             lr, [x21, lr, lsl #3]
    //     0x6b6afc: blr             lr
    // 0x6b6b00: add             SP, SP, #8
    // 0x6b6b04: r1 = LoadInt32Instr(r0)
    //     0x6b6b04: sbfx            x1, x0, #1, #0x1f
    // 0x6b6b08: ldur            x2, [fp, #-0x18]
    // 0x6b6b0c: cmp             x2, x1
    // 0x6b6b10: b.ge            #0x6b6d50
    // 0x6b6b14: r8 = 0
    //     0x6b6b14: mov             x8, #0
    // 0x6b6b18: ldr             x3, [fp, #0x20]
    // 0x6b6b1c: ldr             x5, [fp, #0x18]
    // 0x6b6b20: ldr             x4, [fp, #0x10]
    // 0x6b6b24: ldur            x6, [fp, #-0x10]
    // 0x6b6b28: ldur            x7, [fp, #-0x20]
    // 0x6b6b2c: stur            x8, [fp, #-0x30]
    // 0x6b6b30: CheckStackOverflow
    //     0x6b6b30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6b6b34: cmp             SP, x16
    //     0x6b6b38: b.ls            #0x6b6e4c
    // 0x6b6b3c: cmp             x8, x5
    // 0x6b6b40: b.ge            #0x6b6d44
    // 0x6b6b44: add             x9, x8, x2
    // 0x6b6b48: LoadField: r0 = r3->field_63
    //     0x6b6b48: ldur            x0, [x3, #0x63]
    // 0x6b6b4c: mul             x1, x7, x0
    // 0x6b6b50: add             x10, x8, x1
    // 0x6b6b54: stur            x10, [fp, #-0x28]
    // 0x6b6b58: r0 = BoxInt64Instr(r9)
    //     0x6b6b58: sbfiz           x0, x9, #1, #0x1f
    //     0x6b6b5c: cmp             x9, x0, asr #1
    //     0x6b6b60: b.eq            #0x6b6b6c
    //     0x6b6b64: bl              #0xd69bb8
    //     0x6b6b68: stur            x9, [x0, #7]
    // 0x6b6b6c: mov             x1, x0
    // 0x6b6b70: stur            x1, [fp, #-8]
    // 0x6b6b74: r0 = LoadClassIdInstr(r4)
    //     0x6b6b74: ldur            x0, [x4, #-1]
    //     0x6b6b78: ubfx            x0, x0, #0xc, #0x14
    // 0x6b6b7c: stp             x1, x4, [SP, #-0x10]!
    // 0x6b6b80: r0 = GDT[cid_x0 + -0xd83]()
    //     0x6b6b80: sub             lr, x0, #0xd83
    //     0x6b6b84: ldr             lr, [x21, lr, lsl #3]
    //     0x6b6b88: blr             lr
    // 0x6b6b8c: add             SP, SP, #0x10
    // 0x6b6b90: cmp             w0, NULL
    // 0x6b6b94: b.eq            #0x6b6d34
    // 0x6b6b98: ldr             x2, [fp, #0x20]
    // 0x6b6b9c: ldur            x3, [fp, #-0x30]
    // 0x6b6ba0: LoadField: r0 = r2->field_63
    //     0x6b6ba0: ldur            x0, [x2, #0x63]
    // 0x6b6ba4: cmp             x3, x0
    // 0x6b6ba8: b.ge            #0x6b6c60
    // 0x6b6bac: ldur            x4, [fp, #-0x20]
    // 0x6b6bb0: LoadField: r0 = r2->field_6b
    //     0x6b6bb0: ldur            x0, [x2, #0x6b]
    // 0x6b6bb4: cmp             x4, x0
    // 0x6b6bb8: b.ge            #0x6b6c60
    // 0x6b6bbc: ldr             x5, [fp, #0x10]
    // 0x6b6bc0: ldur            x6, [fp, #-0x28]
    // 0x6b6bc4: LoadField: r7 = r2->field_5f
    //     0x6b6bc4: ldur            w7, [x2, #0x5f]
    // 0x6b6bc8: DecompressPointer r7
    //     0x6b6bc8: add             x7, x7, HEAP, lsl #32
    // 0x6b6bcc: r0 = BoxInt64Instr(r6)
    //     0x6b6bcc: sbfiz           x0, x6, #1, #0x1f
    //     0x6b6bd0: cmp             x6, x0, asr #1
    //     0x6b6bd4: b.eq            #0x6b6be0
    //     0x6b6bd8: bl              #0xd69bb8
    //     0x6b6bdc: stur            x6, [x0, #7]
    // 0x6b6be0: r1 = LoadClassIdInstr(r7)
    //     0x6b6be0: ldur            x1, [x7, #-1]
    //     0x6b6be4: ubfx            x1, x1, #0xc, #0x14
    // 0x6b6be8: stp             x0, x7, [SP, #-0x10]!
    // 0x6b6bec: mov             x0, x1
    // 0x6b6bf0: r0 = GDT[cid_x0 + -0xd83]()
    //     0x6b6bf0: sub             lr, x0, #0xd83
    //     0x6b6bf4: ldr             lr, [x21, lr, lsl #3]
    //     0x6b6bf8: blr             lr
    // 0x6b6bfc: add             SP, SP, #0x10
    // 0x6b6c00: mov             x2, x0
    // 0x6b6c04: ldr             x1, [fp, #0x10]
    // 0x6b6c08: stur            x2, [fp, #-0x38]
    // 0x6b6c0c: r0 = LoadClassIdInstr(r1)
    //     0x6b6c0c: ldur            x0, [x1, #-1]
    //     0x6b6c10: ubfx            x0, x0, #0xc, #0x14
    // 0x6b6c14: ldur            x16, [fp, #-8]
    // 0x6b6c18: stp             x16, x1, [SP, #-0x10]!
    // 0x6b6c1c: r0 = GDT[cid_x0 + -0xd83]()
    //     0x6b6c1c: sub             lr, x0, #0xd83
    //     0x6b6c20: ldr             lr, [x21, lr, lsl #3]
    //     0x6b6c24: blr             lr
    // 0x6b6c28: add             SP, SP, #0x10
    // 0x6b6c2c: mov             x1, x0
    // 0x6b6c30: ldur            x0, [fp, #-0x38]
    // 0x6b6c34: r2 = 59
    //     0x6b6c34: mov             x2, #0x3b
    // 0x6b6c38: branchIfSmi(r0, 0x6b6c44)
    //     0x6b6c38: tbz             w0, #0, #0x6b6c44
    // 0x6b6c3c: r2 = LoadClassIdInstr(r0)
    //     0x6b6c3c: ldur            x2, [x0, #-1]
    //     0x6b6c40: ubfx            x2, x2, #0xc, #0x14
    // 0x6b6c44: stp             x1, x0, [SP, #-0x10]!
    // 0x6b6c48: mov             x0, x2
    // 0x6b6c4c: mov             lr, x0
    // 0x6b6c50: ldr             lr, [x21, lr, lsl #3]
    // 0x6b6c54: blr             lr
    // 0x6b6c58: add             SP, SP, #0x10
    // 0x6b6c5c: tbz             w0, #4, #0x6b6d34
    // 0x6b6c60: ldr             x1, [fp, #0x10]
    // 0x6b6c64: ldur            x2, [fp, #-0x10]
    // 0x6b6c68: r0 = LoadClassIdInstr(r1)
    //     0x6b6c68: ldur            x0, [x1, #-1]
    //     0x6b6c6c: ubfx            x0, x0, #0xc, #0x14
    // 0x6b6c70: ldur            x16, [fp, #-8]
    // 0x6b6c74: stp             x16, x1, [SP, #-0x10]!
    // 0x6b6c78: r0 = GDT[cid_x0 + -0xd83]()
    //     0x6b6c78: sub             lr, x0, #0xd83
    //     0x6b6c7c: ldr             lr, [x21, lr, lsl #3]
    //     0x6b6c80: blr             lr
    // 0x6b6c84: add             SP, SP, #0x10
    // 0x6b6c88: ldur            x1, [fp, #-0x10]
    // 0x6b6c8c: r2 = LoadClassIdInstr(r1)
    //     0x6b6c8c: ldur            x2, [x1, #-1]
    //     0x6b6c90: ubfx            x2, x2, #0xc, #0x14
    // 0x6b6c94: stp             x0, x1, [SP, #-0x10]!
    // 0x6b6c98: mov             x0, x2
    // 0x6b6c9c: r0 = GDT[cid_x0 + 0x56]()
    //     0x6b6c9c: add             lr, x0, #0x56
    //     0x6b6ca0: ldr             lr, [x21, lr, lsl #3]
    //     0x6b6ca4: blr             lr
    // 0x6b6ca8: add             SP, SP, #0x10
    // 0x6b6cac: tbz             w0, #4, #0x6b6d34
    // 0x6b6cb0: ldr             x1, [fp, #0x10]
    // 0x6b6cb4: r0 = LoadClassIdInstr(r1)
    //     0x6b6cb4: ldur            x0, [x1, #-1]
    //     0x6b6cb8: ubfx            x0, x0, #0xc, #0x14
    // 0x6b6cbc: ldur            x16, [fp, #-8]
    // 0x6b6cc0: stp             x16, x1, [SP, #-0x10]!
    // 0x6b6cc4: r0 = GDT[cid_x0 + -0xd83]()
    //     0x6b6cc4: sub             lr, x0, #0xd83
    //     0x6b6cc8: ldr             lr, [x21, lr, lsl #3]
    //     0x6b6ccc: blr             lr
    // 0x6b6cd0: add             SP, SP, #0x10
    // 0x6b6cd4: stur            x0, [fp, #-8]
    // 0x6b6cd8: cmp             w0, NULL
    // 0x6b6cdc: b.eq            #0x6b6e54
    // 0x6b6ce0: ldr             x16, [fp, #0x20]
    // 0x6b6ce4: stp             x0, x16, [SP, #-0x10]!
    // 0x6b6ce8: r0 = setupParentData()
    //     0x6b6ce8: bl              #0x64ba9c  ; [package:flutter/src/rendering/table.dart] RenderTable::setupParentData
    // 0x6b6cec: add             SP, SP, #0x10
    // 0x6b6cf0: ldr             x16, [fp, #0x20]
    // 0x6b6cf4: SaveReg r16
    //     0x6b6cf4: str             x16, [SP, #-8]!
    // 0x6b6cf8: r0 = markNeedsLayout()
    //     0x6b6cf8: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6b6cfc: add             SP, SP, #8
    // 0x6b6d00: ldr             x16, [fp, #0x20]
    // 0x6b6d04: SaveReg r16
    //     0x6b6d04: str             x16, [SP, #-8]!
    // 0x6b6d08: r0 = markNeedsCompositingBitsUpdate()
    //     0x6b6d08: bl              #0x5e5c40  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsCompositingBitsUpdate
    // 0x6b6d0c: add             SP, SP, #8
    // 0x6b6d10: ldr             x16, [fp, #0x20]
    // 0x6b6d14: SaveReg r16
    //     0x6b6d14: str             x16, [SP, #-8]!
    // 0x6b6d18: r0 = markNeedsSemanticsUpdate()
    //     0x6b6d18: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6b6d1c: add             SP, SP, #8
    // 0x6b6d20: ldr             x16, [fp, #0x20]
    // 0x6b6d24: ldur            lr, [fp, #-8]
    // 0x6b6d28: stp             lr, x16, [SP, #-0x10]!
    // 0x6b6d2c: r0 = adoptChild()
    //     0x6b6d2c: bl              #0x5e6280  ; [package:flutter/src/foundation/node.dart] AbstractNode::adoptChild
    // 0x6b6d30: add             SP, SP, #0x10
    // 0x6b6d34: ldur            x0, [fp, #-0x30]
    // 0x6b6d38: add             x8, x0, #1
    // 0x6b6d3c: ldur            x2, [fp, #-0x18]
    // 0x6b6d40: b               #0x6b6b18
    // 0x6b6d44: mov             x0, x7
    // 0x6b6d48: add             x5, x0, #1
    // 0x6b6d4c: b               #0x6b6abc
    // 0x6b6d50: ldr             x1, [fp, #0x20]
    // 0x6b6d54: ldr             x2, [fp, #0x18]
    // 0x6b6d58: ldr             x0, [fp, #0x10]
    // 0x6b6d5c: SaveReg r1
    //     0x6b6d5c: str             x1, [SP, #-8]!
    // 0x6b6d60: r0 = dropChild()
    //     0x6b6d60: bl              #0x792650  ; [package:flutter/src/rendering/object.dart] RenderObject::dropChild
    // 0x6b6d64: add             SP, SP, #8
    // 0x6b6d68: ldur            x16, [fp, #-0x10]
    // 0x6b6d6c: stp             x0, x16, [SP, #-0x10]!
    // 0x6b6d70: r0 = forEach()
    //     0x6b6d70: bl              #0x6b1a10  ; [dart:collection] __SetBase&Object&SetMixin::forEach
    // 0x6b6d74: add             SP, SP, #0x10
    // 0x6b6d78: ldr             x1, [fp, #0x20]
    // 0x6b6d7c: ldr             x2, [fp, #0x18]
    // 0x6b6d80: StoreField: r1->field_63 = r2
    //     0x6b6d80: stur            x2, [x1, #0x63]
    // 0x6b6d84: ldr             x3, [fp, #0x10]
    // 0x6b6d88: r0 = LoadClassIdInstr(r3)
    //     0x6b6d88: ldur            x0, [x3, #-1]
    //     0x6b6d8c: ubfx            x0, x0, #0xc, #0x14
    // 0x6b6d90: SaveReg r3
    //     0x6b6d90: str             x3, [SP, #-8]!
    // 0x6b6d94: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x6b6d94: mov             x17, #0xb8ea
    //     0x6b6d98: add             lr, x0, x17
    //     0x6b6d9c: ldr             lr, [x21, lr, lsl #3]
    //     0x6b6da0: blr             lr
    // 0x6b6da4: add             SP, SP, #8
    // 0x6b6da8: r1 = LoadInt32Instr(r0)
    //     0x6b6da8: sbfx            x1, x0, #1, #0x1f
    // 0x6b6dac: ldr             x0, [fp, #0x18]
    // 0x6b6db0: cbz             x0, #0x6b6e58
    // 0x6b6db4: sdiv            x2, x1, x0
    // 0x6b6db8: ldr             x0, [fp, #0x20]
    // 0x6b6dbc: StoreField: r0->field_6b = r2
    //     0x6b6dbc: stur            x2, [x0, #0x6b]
    // 0x6b6dc0: r16 = <RenderBox?>
    //     0x6b6dc0: add             x16, PP, #0x50, lsl #12  ; [pp+0x50a08] TypeArguments: <RenderBox?>
    //     0x6b6dc4: ldr             x16, [x16, #0xa08]
    // 0x6b6dc8: ldr             lr, [fp, #0x10]
    // 0x6b6dcc: stp             lr, x16, [SP, #-0x10]!
    // 0x6b6dd0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x6b6dd0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x6b6dd4: r0 = List.of()
    //     0x6b6dd4: bl              #0x4bf194  ; [dart:core] List::List.of
    // 0x6b6dd8: add             SP, SP, #0x10
    // 0x6b6ddc: ldr             x1, [fp, #0x20]
    // 0x6b6de0: StoreField: r1->field_5f = r0
    //     0x6b6de0: stur            w0, [x1, #0x5f]
    //     0x6b6de4: tbz             w0, #0, #0x6b6e00
    //     0x6b6de8: ldurb           w16, [x1, #-1]
    //     0x6b6dec: ldurb           w17, [x0, #-1]
    //     0x6b6df0: and             x16, x17, x16, lsr #2
    //     0x6b6df4: tst             x16, HEAP, lsr #32
    //     0x6b6df8: b.eq            #0x6b6e00
    //     0x6b6dfc: bl              #0xd6826c
    // 0x6b6e00: SaveReg r1
    //     0x6b6e00: str             x1, [SP, #-8]!
    // 0x6b6e04: r0 = markNeedsLayout()
    //     0x6b6e04: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6b6e08: add             SP, SP, #8
    // 0x6b6e0c: r0 = Null
    //     0x6b6e0c: mov             x0, NULL
    // 0x6b6e10: LeaveFrame
    //     0x6b6e10: mov             SP, fp
    //     0x6b6e14: ldp             fp, lr, [SP], #0x10
    // 0x6b6e18: ret
    //     0x6b6e18: ret             
    // 0x6b6e1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b6e1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b6e20: b               #0x6b65e4
    // 0x6b6e24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b6e24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b6e28: b               #0x6b6708
    // 0x6b6e2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6b6e2c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6b6e30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b6e30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b6e34: b               #0x6b68bc
    // 0x6b6e38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b6e38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b6e3c: b               #0x6b68e4
    // 0x6b6e40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6b6e40: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6b6e44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b6e44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b6e48: b               #0x6b6adc
    // 0x6b6e4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b6e4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b6e50: b               #0x6b6b3c
    // 0x6b6e54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6b6e54: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6b6e58: stp             x0, x1, [SP, #-0x10]!
    // 0x6b6e5c: ldr             x5, [THR, #0x4a8]  ; THR::IntegerDivisionByZeroException
    // 0x6b6e60: r4 = 0
    //     0x6b6e60: mov             x4, #0
    // 0x6b6e64: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0x6b6e68: blr             lr
    // 0x6b6e6c: brk             #0
  }
  _ visitChildren(/* No info */) {
    // ** addr: 0x6bff98, size: 0xe4
    // 0x6bff98: EnterFrame
    //     0x6bff98: stp             fp, lr, [SP, #-0x10]!
    //     0x6bff9c: mov             fp, SP
    // 0x6bffa0: AllocStack(0x8)
    //     0x6bffa0: sub             SP, SP, #8
    // 0x6bffa4: CheckStackOverflow
    //     0x6bffa4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bffa8: cmp             SP, x16
    //     0x6bffac: b.ls            #0x6c006c
    // 0x6bffb0: ldr             x0, [fp, #0x18]
    // 0x6bffb4: LoadField: r1 = r0->field_5f
    //     0x6bffb4: ldur            w1, [x0, #0x5f]
    // 0x6bffb8: DecompressPointer r1
    //     0x6bffb8: add             x1, x1, HEAP, lsl #32
    // 0x6bffbc: r0 = LoadClassIdInstr(r1)
    //     0x6bffbc: ldur            x0, [x1, #-1]
    //     0x6bffc0: ubfx            x0, x0, #0xc, #0x14
    // 0x6bffc4: SaveReg r1
    //     0x6bffc4: str             x1, [SP, #-8]!
    // 0x6bffc8: r0 = GDT[cid_x0 + 0xb940]()
    //     0x6bffc8: mov             x17, #0xb940
    //     0x6bffcc: add             lr, x0, x17
    //     0x6bffd0: ldr             lr, [x21, lr, lsl #3]
    //     0x6bffd4: blr             lr
    // 0x6bffd8: add             SP, SP, #8
    // 0x6bffdc: mov             x1, x0
    // 0x6bffe0: stur            x1, [fp, #-8]
    // 0x6bffe4: CheckStackOverflow
    //     0x6bffe4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bffe8: cmp             SP, x16
    //     0x6bffec: b.ls            #0x6c0074
    // 0x6bfff0: r0 = LoadClassIdInstr(r1)
    //     0x6bfff0: ldur            x0, [x1, #-1]
    //     0x6bfff4: ubfx            x0, x0, #0xc, #0x14
    // 0x6bfff8: SaveReg r1
    //     0x6bfff8: str             x1, [SP, #-8]!
    // 0x6bfffc: r0 = GDT[cid_x0 + 0x541]()
    //     0x6bfffc: add             lr, x0, #0x541
    //     0x6c0000: ldr             lr, [x21, lr, lsl #3]
    //     0x6c0004: blr             lr
    // 0x6c0008: add             SP, SP, #8
    // 0x6c000c: tbnz            w0, #4, #0x6c005c
    // 0x6c0010: ldur            x1, [fp, #-8]
    // 0x6c0014: r0 = LoadClassIdInstr(r1)
    //     0x6c0014: ldur            x0, [x1, #-1]
    //     0x6c0018: ubfx            x0, x0, #0xc, #0x14
    // 0x6c001c: SaveReg r1
    //     0x6c001c: str             x1, [SP, #-8]!
    // 0x6c0020: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x6c0020: add             lr, x0, #0x5ca
    //     0x6c0024: ldr             lr, [x21, lr, lsl #3]
    //     0x6c0028: blr             lr
    // 0x6c002c: add             SP, SP, #8
    // 0x6c0030: cmp             w0, NULL
    // 0x6c0034: b.eq            #0x6c0054
    // 0x6c0038: ldr             x16, [fp, #0x10]
    // 0x6c003c: stp             x0, x16, [SP, #-0x10]!
    // 0x6c0040: ldr             x0, [fp, #0x10]
    // 0x6c0044: ClosureCall
    //     0x6c0044: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6c0048: ldur            x2, [x0, #0x1f]
    //     0x6c004c: blr             x2
    // 0x6c0050: add             SP, SP, #0x10
    // 0x6c0054: ldur            x1, [fp, #-8]
    // 0x6c0058: b               #0x6bffe4
    // 0x6c005c: r0 = Null
    //     0x6c005c: mov             x0, NULL
    // 0x6c0060: LeaveFrame
    //     0x6c0060: mov             SP, fp
    //     0x6c0064: ldp             fp, lr, [SP], #0x10
    // 0x6c0068: ret
    //     0x6c0068: ret             
    // 0x6c006c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c006c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c0070: b               #0x6bffb0
    // 0x6c0074: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c0074: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c0078: b               #0x6bfff0
  }
  set _ configuration=(/* No info */) {
    // ** addr: 0x6e6338, size: 0x8c
    // 0x6e6338: EnterFrame
    //     0x6e6338: stp             fp, lr, [SP, #-0x10]!
    //     0x6e633c: mov             fp, SP
    // 0x6e6340: CheckStackOverflow
    //     0x6e6340: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e6344: cmp             SP, x16
    //     0x6e6348: b.ls            #0x6e63bc
    // 0x6e634c: ldr             x0, [fp, #0x18]
    // 0x6e6350: LoadField: r1 = r0->field_8b
    //     0x6e6350: ldur            w1, [x0, #0x8b]
    // 0x6e6354: DecompressPointer r1
    //     0x6e6354: add             x1, x1, HEAP, lsl #32
    // 0x6e6358: ldr             x16, [fp, #0x10]
    // 0x6e635c: stp             x1, x16, [SP, #-0x10]!
    // 0x6e6360: r0 = ==()
    //     0x6e6360: bl              #0xc9d8f4  ; [package:flutter/src/painting/image_provider.dart] ImageConfiguration::==
    // 0x6e6364: add             SP, SP, #0x10
    // 0x6e6368: tbnz            w0, #4, #0x6e637c
    // 0x6e636c: r0 = Null
    //     0x6e636c: mov             x0, NULL
    // 0x6e6370: LeaveFrame
    //     0x6e6370: mov             SP, fp
    //     0x6e6374: ldp             fp, lr, [SP], #0x10
    // 0x6e6378: ret
    //     0x6e6378: ret             
    // 0x6e637c: ldr             x1, [fp, #0x18]
    // 0x6e6380: ldr             x0, [fp, #0x10]
    // 0x6e6384: StoreField: r1->field_8b = r0
    //     0x6e6384: stur            w0, [x1, #0x8b]
    //     0x6e6388: ldurb           w16, [x1, #-1]
    //     0x6e638c: ldurb           w17, [x0, #-1]
    //     0x6e6390: and             x16, x17, x16, lsr #2
    //     0x6e6394: tst             x16, HEAP, lsr #32
    //     0x6e6398: b.eq            #0x6e63a0
    //     0x6e639c: bl              #0xd6826c
    // 0x6e63a0: SaveReg r1
    //     0x6e63a0: str             x1, [SP, #-8]!
    // 0x6e63a4: r0 = markNeedsPaint()
    //     0x6e63a4: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6e63a8: add             SP, SP, #8
    // 0x6e63ac: r0 = Null
    //     0x6e63ac: mov             x0, NULL
    // 0x6e63b0: LeaveFrame
    //     0x6e63b0: mov             SP, fp
    //     0x6e63b4: ldp             fp, lr, [SP], #0x10
    // 0x6e63b8: ret
    //     0x6e63b8: ret             
    // 0x6e63bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e63bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e63c0: b               #0x6e634c
  }
  set _ rowDecorations=(/* No info */) {
    // ** addr: 0x6e63c4, size: 0x1f4
    // 0x6e63c4: EnterFrame
    //     0x6e63c4: stp             fp, lr, [SP, #-0x10]!
    //     0x6e63c8: mov             fp, SP
    // 0x6e63cc: AllocStack(0x28)
    //     0x6e63cc: sub             SP, SP, #0x28
    // 0x6e63d0: CheckStackOverflow
    //     0x6e63d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e63d4: cmp             SP, x16
    //     0x6e63d8: b.ls            #0x6e65a8
    // 0x6e63dc: ldr             x1, [fp, #0x18]
    // 0x6e63e0: LoadField: r0 = r1->field_83
    //     0x6e63e0: ldur            w0, [x1, #0x83]
    // 0x6e63e4: DecompressPointer r0
    //     0x6e63e4: add             x0, x0, HEAP, lsl #32
    // 0x6e63e8: r2 = LoadClassIdInstr(r0)
    //     0x6e63e8: ldur            x2, [x0, #-1]
    //     0x6e63ec: ubfx            x2, x2, #0xc, #0x14
    // 0x6e63f0: ldr             x16, [fp, #0x10]
    // 0x6e63f4: stp             x16, x0, [SP, #-0x10]!
    // 0x6e63f8: mov             x0, x2
    // 0x6e63fc: mov             lr, x0
    // 0x6e6400: ldr             lr, [x21, lr, lsl #3]
    // 0x6e6404: blr             lr
    // 0x6e6408: add             SP, SP, #0x10
    // 0x6e640c: tbnz            w0, #4, #0x6e6420
    // 0x6e6410: r0 = Null
    //     0x6e6410: mov             x0, NULL
    // 0x6e6414: LeaveFrame
    //     0x6e6414: mov             SP, fp
    //     0x6e6418: ldp             fp, lr, [SP], #0x10
    // 0x6e641c: ret
    //     0x6e641c: ret             
    // 0x6e6420: ldr             x3, [fp, #0x18]
    // 0x6e6424: ldr             x0, [fp, #0x10]
    // 0x6e6428: StoreField: r3->field_83 = r0
    //     0x6e6428: stur            w0, [x3, #0x83]
    //     0x6e642c: ldurb           w16, [x3, #-1]
    //     0x6e6430: ldurb           w17, [x0, #-1]
    //     0x6e6434: and             x16, x17, x16, lsr #2
    //     0x6e6438: tst             x16, HEAP, lsr #32
    //     0x6e643c: b.eq            #0x6e6444
    //     0x6e6440: bl              #0xd682ac
    // 0x6e6444: LoadField: r4 = r3->field_87
    //     0x6e6444: ldur            w4, [x3, #0x87]
    // 0x6e6448: DecompressPointer r4
    //     0x6e6448: add             x4, x4, HEAP, lsl #32
    // 0x6e644c: stur            x4, [fp, #-0x28]
    // 0x6e6450: cmp             w4, NULL
    // 0x6e6454: b.eq            #0x6e6528
    // 0x6e6458: LoadField: r5 = r4->field_7
    //     0x6e6458: ldur            w5, [x4, #7]
    // 0x6e645c: DecompressPointer r5
    //     0x6e645c: add             x5, x5, HEAP, lsl #32
    // 0x6e6460: stur            x5, [fp, #-0x20]
    // 0x6e6464: LoadField: r0 = r4->field_b
    //     0x6e6464: ldur            w0, [x4, #0xb]
    // 0x6e6468: DecompressPointer r0
    //     0x6e6468: add             x0, x0, HEAP, lsl #32
    // 0x6e646c: r6 = LoadInt32Instr(r0)
    //     0x6e646c: sbfx            x6, x0, #1, #0x1f
    // 0x6e6470: stur            x6, [fp, #-0x18]
    // 0x6e6474: r0 = 0
    //     0x6e6474: mov             x0, #0
    // 0x6e6478: CheckStackOverflow
    //     0x6e6478: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e647c: cmp             SP, x16
    //     0x6e6480: b.ls            #0x6e65b0
    // 0x6e6484: cmp             x0, x6
    // 0x6e6488: b.lt            #0x6e6494
    // 0x6e648c: mov             x1, x3
    // 0x6e6490: b               #0x6e652c
    // 0x6e6494: ArrayLoad: r7 = r4[r0]  ; Unknown_4
    //     0x6e6494: add             x16, x4, x0, lsl #2
    //     0x6e6498: ldur            w7, [x16, #0xf]
    // 0x6e649c: DecompressPointer r7
    //     0x6e649c: add             x7, x7, HEAP, lsl #32
    // 0x6e64a0: stur            x7, [fp, #-0x10]
    // 0x6e64a4: add             x8, x0, #1
    // 0x6e64a8: stur            x8, [fp, #-8]
    // 0x6e64ac: cmp             w7, NULL
    // 0x6e64b0: b.ne            #0x6e64e4
    // 0x6e64b4: mov             x0, x7
    // 0x6e64b8: mov             x2, x5
    // 0x6e64bc: r1 = Null
    //     0x6e64bc: mov             x1, NULL
    // 0x6e64c0: cmp             w2, NULL
    // 0x6e64c4: b.eq            #0x6e64e4
    // 0x6e64c8: LoadField: r4 = r2->field_17
    //     0x6e64c8: ldur            w4, [x2, #0x17]
    // 0x6e64cc: DecompressPointer r4
    //     0x6e64cc: add             x4, x4, HEAP, lsl #32
    // 0x6e64d0: r8 = X0
    //     0x6e64d0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6e64d4: LoadField: r9 = r4->field_7
    //     0x6e64d4: ldur            x9, [x4, #7]
    // 0x6e64d8: r3 = Null
    //     0x6e64d8: add             x3, PP, #0x57, lsl #12  ; [pp+0x57488] Null
    //     0x6e64dc: ldr             x3, [x3, #0x488]
    // 0x6e64e0: blr             x9
    // 0x6e64e4: ldur            x0, [fp, #-0x10]
    // 0x6e64e8: cmp             w0, NULL
    // 0x6e64ec: b.eq            #0x6e6510
    // 0x6e64f0: r1 = LoadClassIdInstr(r0)
    //     0x6e64f0: ldur            x1, [x0, #-1]
    //     0x6e64f4: ubfx            x1, x1, #0xc, #0x14
    // 0x6e64f8: SaveReg r0
    //     0x6e64f8: str             x0, [SP, #-8]!
    // 0x6e64fc: mov             x0, x1
    // 0x6e6500: r0 = GDT[cid_x0 + -0x3c5]()
    //     0x6e6500: sub             lr, x0, #0x3c5
    //     0x6e6504: ldr             lr, [x21, lr, lsl #3]
    //     0x6e6508: blr             lr
    // 0x6e650c: add             SP, SP, #8
    // 0x6e6510: ldur            x0, [fp, #-8]
    // 0x6e6514: ldr             x3, [fp, #0x18]
    // 0x6e6518: ldur            x4, [fp, #-0x28]
    // 0x6e651c: ldur            x5, [fp, #-0x20]
    // 0x6e6520: ldur            x6, [fp, #-0x18]
    // 0x6e6524: b               #0x6e6478
    // 0x6e6528: ldr             x1, [fp, #0x18]
    // 0x6e652c: LoadField: r0 = r1->field_83
    //     0x6e652c: ldur            w0, [x1, #0x83]
    // 0x6e6530: DecompressPointer r0
    //     0x6e6530: add             x0, x0, HEAP, lsl #32
    // 0x6e6534: cmp             w0, NULL
    // 0x6e6538: b.eq            #0x6e6574
    // 0x6e653c: r2 = LoadClassIdInstr(r0)
    //     0x6e653c: ldur            x2, [x0, #-1]
    //     0x6e6540: ubfx            x2, x2, #0xc, #0x14
    // 0x6e6544: SaveReg r0
    //     0x6e6544: str             x0, [SP, #-8]!
    // 0x6e6548: mov             x0, x2
    // 0x6e654c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x6e654c: mov             x17, #0xb8ea
    //     0x6e6550: add             lr, x0, x17
    //     0x6e6554: ldr             lr, [x21, lr, lsl #3]
    //     0x6e6558: blr             lr
    // 0x6e655c: add             SP, SP, #8
    // 0x6e6560: mov             x2, x0
    // 0x6e6564: r1 = <BoxPainter?>
    //     0x6e6564: add             x1, PP, #0x57, lsl #12  ; [pp+0x57498] TypeArguments: <BoxPainter?>
    //     0x6e6568: ldr             x1, [x1, #0x498]
    // 0x6e656c: r0 = AllocateArray()
    //     0x6e656c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x6e6570: b               #0x6e6578
    // 0x6e6574: r0 = Null
    //     0x6e6574: mov             x0, NULL
    // 0x6e6578: ldr             x1, [fp, #0x18]
    // 0x6e657c: StoreField: r1->field_87 = r0
    //     0x6e657c: stur            w0, [x1, #0x87]
    //     0x6e6580: ldurb           w16, [x1, #-1]
    //     0x6e6584: ldurb           w17, [x0, #-1]
    //     0x6e6588: and             x16, x17, x16, lsr #2
    //     0x6e658c: tst             x16, HEAP, lsr #32
    //     0x6e6590: b.eq            #0x6e6598
    //     0x6e6594: bl              #0xd6826c
    // 0x6e6598: r0 = Null
    //     0x6e6598: mov             x0, NULL
    // 0x6e659c: LeaveFrame
    //     0x6e659c: mov             SP, fp
    //     0x6e65a0: ldp             fp, lr, [SP], #0x10
    // 0x6e65a4: ret
    //     0x6e65a4: ret             
    // 0x6e65a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e65a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e65ac: b               #0x6e63dc
    // 0x6e65b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e65b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e65b4: b               #0x6e6484
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0x6e65ec, size: 0x80
    // 0x6e65ec: EnterFrame
    //     0x6e65ec: stp             fp, lr, [SP, #-0x10]!
    //     0x6e65f0: mov             fp, SP
    // 0x6e65f4: CheckStackOverflow
    //     0x6e65f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e65f8: cmp             SP, x16
    //     0x6e65fc: b.ls            #0x6e6664
    // 0x6e6600: ldr             x1, [fp, #0x18]
    // 0x6e6604: LoadField: r0 = r1->field_7b
    //     0x6e6604: ldur            w0, [x1, #0x7b]
    // 0x6e6608: DecompressPointer r0
    //     0x6e6608: add             x0, x0, HEAP, lsl #32
    // 0x6e660c: ldr             x2, [fp, #0x10]
    // 0x6e6610: cmp             w0, w2
    // 0x6e6614: b.ne            #0x6e6628
    // 0x6e6618: r0 = Null
    //     0x6e6618: mov             x0, NULL
    // 0x6e661c: LeaveFrame
    //     0x6e661c: mov             SP, fp
    //     0x6e6620: ldp             fp, lr, [SP], #0x10
    // 0x6e6624: ret
    //     0x6e6624: ret             
    // 0x6e6628: mov             x0, x2
    // 0x6e662c: StoreField: r1->field_7b = r0
    //     0x6e662c: stur            w0, [x1, #0x7b]
    //     0x6e6630: ldurb           w16, [x1, #-1]
    //     0x6e6634: ldurb           w17, [x0, #-1]
    //     0x6e6638: and             x16, x17, x16, lsr #2
    //     0x6e663c: tst             x16, HEAP, lsr #32
    //     0x6e6640: b.eq            #0x6e6648
    //     0x6e6644: bl              #0xd6826c
    // 0x6e6648: SaveReg r1
    //     0x6e6648: str             x1, [SP, #-8]!
    // 0x6e664c: r0 = markNeedsLayout()
    //     0x6e664c: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6e6650: add             SP, SP, #8
    // 0x6e6654: r0 = Null
    //     0x6e6654: mov             x0, NULL
    // 0x6e6658: LeaveFrame
    //     0x6e6658: mov             SP, fp
    //     0x6e665c: ldp             fp, lr, [SP], #0x10
    // 0x6e6660: ret
    //     0x6e6660: ret             
    // 0x6e6664: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e6664: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e6668: b               #0x6e6600
  }
  set _ columnWidths=(/* No info */) {
    // ** addr: 0x6e666c, size: 0xbc
    // 0x6e666c: EnterFrame
    //     0x6e666c: stp             fp, lr, [SP, #-0x10]!
    //     0x6e6670: mov             fp, SP
    // 0x6e6674: AllocStack(0x8)
    //     0x6e6674: sub             SP, SP, #8
    // 0x6e6678: CheckStackOverflow
    //     0x6e6678: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e667c: cmp             SP, x16
    //     0x6e6680: b.ls            #0x6e6720
    // 0x6e6684: ldr             x0, [fp, #0x18]
    // 0x6e6688: LoadField: r1 = r0->field_73
    //     0x6e6688: ldur            w1, [x0, #0x73]
    // 0x6e668c: DecompressPointer r1
    //     0x6e668c: add             x1, x1, HEAP, lsl #32
    // 0x6e6690: LoadField: r2 = r1->field_b
    //     0x6e6690: ldur            x2, [x1, #0xb]
    // 0x6e6694: cbnz            x2, #0x6e66a8
    // 0x6e6698: r0 = Null
    //     0x6e6698: mov             x0, NULL
    // 0x6e669c: LeaveFrame
    //     0x6e669c: mov             SP, fp
    //     0x6e66a0: ldp             fp, lr, [SP], #0x10
    // 0x6e66a4: ret
    //     0x6e66a4: ret             
    // 0x6e66a8: r1 = <int, TableColumnWidth>
    //     0x6e66a8: add             x1, PP, #0x57, lsl #12  ; [pp+0x574a0] TypeArguments: <int, TableColumnWidth>
    //     0x6e66ac: ldr             x1, [x1, #0x4a0]
    // 0x6e66b0: r0 = _HashMap()
    //     0x6e66b0: bl              #0x4d9d7c  ; Allocate_HashMapStub -> _HashMap<X0, X1> (size=0x20)
    // 0x6e66b4: mov             x3, x0
    // 0x6e66b8: r0 = 0
    //     0x6e66b8: mov             x0, #0
    // 0x6e66bc: stur            x3, [fp, #-8]
    // 0x6e66c0: StoreField: r3->field_b = r0
    //     0x6e66c0: stur            x0, [x3, #0xb]
    // 0x6e66c4: StoreField: r3->field_17 = r0
    //     0x6e66c4: stur            x0, [x3, #0x17]
    // 0x6e66c8: r1 = <_HashMapEntry<int, TableColumnWidth>?>
    //     0x6e66c8: add             x1, PP, #0x57, lsl #12  ; [pp+0x574a8] TypeArguments: <_HashMapEntry<int, TableColumnWidth>?>
    //     0x6e66cc: ldr             x1, [x1, #0x4a8]
    // 0x6e66d0: r2 = 16
    //     0x6e66d0: mov             x2, #0x10
    // 0x6e66d4: r0 = AllocateArray()
    //     0x6e66d4: bl              #0xd6987c  ; AllocateArrayStub
    // 0x6e66d8: mov             x1, x0
    // 0x6e66dc: ldur            x0, [fp, #-8]
    // 0x6e66e0: StoreField: r0->field_13 = r1
    //     0x6e66e0: stur            w1, [x0, #0x13]
    // 0x6e66e4: ldr             x1, [fp, #0x18]
    // 0x6e66e8: StoreField: r1->field_73 = r0
    //     0x6e66e8: stur            w0, [x1, #0x73]
    //     0x6e66ec: ldurb           w16, [x1, #-1]
    //     0x6e66f0: ldurb           w17, [x0, #-1]
    //     0x6e66f4: and             x16, x17, x16, lsr #2
    //     0x6e66f8: tst             x16, HEAP, lsr #32
    //     0x6e66fc: b.eq            #0x6e6704
    //     0x6e6700: bl              #0xd6826c
    // 0x6e6704: SaveReg r1
    //     0x6e6704: str             x1, [SP, #-8]!
    // 0x6e6708: r0 = markNeedsLayout()
    //     0x6e6708: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6e670c: add             SP, SP, #8
    // 0x6e6710: r0 = Null
    //     0x6e6710: mov             x0, NULL
    // 0x6e6714: LeaveFrame
    //     0x6e6714: mov             SP, fp
    //     0x6e6718: ldp             fp, lr, [SP], #0x10
    // 0x6e671c: ret
    //     0x6e671c: ret             
    // 0x6e6720: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e6720: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e6724: b               #0x6e6684
  }
  _ RenderTable(/* No info */) {
    // ** addr: 0x6f5b30, size: 0x1c4
    // 0x6f5b30: EnterFrame
    //     0x6f5b30: stp             fp, lr, [SP, #-0x10]!
    //     0x6f5b34: mov             fp, SP
    // 0x6f5b38: AllocStack(0x8)
    //     0x6f5b38: sub             SP, SP, #8
    // 0x6f5b3c: r1 = const []
    //     0x6f5b3c: add             x1, PP, #0x57, lsl #12  ; [pp+0x574b0] List<RenderBox?>(0)
    //     0x6f5b40: ldr             x1, [x1, #0x4b0]
    // 0x6f5b44: r0 = Sentinel
    //     0x6f5b44: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6f5b48: CheckStackOverflow
    //     0x6f5b48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f5b4c: cmp             SP, x16
    //     0x6f5b50: b.ls            #0x6f5cec
    // 0x6f5b54: ldr             x2, [fp, #0x38]
    // 0x6f5b58: StoreField: r2->field_5f = r1
    //     0x6f5b58: stur            w1, [x2, #0x5f]
    // 0x6f5b5c: StoreField: r2->field_a3 = r0
    //     0x6f5b5c: stur            w0, [x2, #0xa3]
    // 0x6f5b60: r16 = <double>
    //     0x6f5b60: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x6f5b64: stp             xzr, x16, [SP, #-0x10]!
    // 0x6f5b68: r0 = _GrowableList()
    //     0x6f5b68: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x6f5b6c: add             SP, SP, #0x10
    // 0x6f5b70: ldr             x2, [fp, #0x38]
    // 0x6f5b74: StoreField: r2->field_9b = r0
    //     0x6f5b74: stur            w0, [x2, #0x9b]
    //     0x6f5b78: ldurb           w16, [x2, #-1]
    //     0x6f5b7c: ldurb           w17, [x0, #-1]
    //     0x6f5b80: and             x16, x17, x16, lsr #2
    //     0x6f5b84: tst             x16, HEAP, lsr #32
    //     0x6f5b88: b.eq            #0x6f5b90
    //     0x6f5b8c: bl              #0xd6828c
    // 0x6f5b90: ldr             x0, [fp, #0x10]
    // 0x6f5b94: StoreField: r2->field_7b = r0
    //     0x6f5b94: stur            w0, [x2, #0x7b]
    //     0x6f5b98: ldurb           w16, [x2, #-1]
    //     0x6f5b9c: ldurb           w17, [x0, #-1]
    //     0x6f5ba0: and             x16, x17, x16, lsr #2
    //     0x6f5ba4: tst             x16, HEAP, lsr #32
    //     0x6f5ba8: b.eq            #0x6f5bb0
    //     0x6f5bac: bl              #0xd6828c
    // 0x6f5bb0: ldr             x0, [fp, #0x30]
    // 0x6f5bb4: r1 = LoadInt32Instr(r0)
    //     0x6f5bb4: sbfx            x1, x0, #1, #0x1f
    // 0x6f5bb8: StoreField: r2->field_63 = r1
    //     0x6f5bb8: stur            x1, [x2, #0x63]
    // 0x6f5bbc: ldr             x0, [fp, #0x18]
    // 0x6f5bc0: StoreField: r2->field_6b = r0
    //     0x6f5bc0: stur            x0, [x2, #0x6b]
    // 0x6f5bc4: r1 = <int, TableColumnWidth>
    //     0x6f5bc4: add             x1, PP, #0x57, lsl #12  ; [pp+0x574a0] TypeArguments: <int, TableColumnWidth>
    //     0x6f5bc8: ldr             x1, [x1, #0x4a0]
    // 0x6f5bcc: r0 = _HashMap()
    //     0x6f5bcc: bl              #0x4d9d7c  ; Allocate_HashMapStub -> _HashMap<X0, X1> (size=0x20)
    // 0x6f5bd0: mov             x3, x0
    // 0x6f5bd4: r0 = 0
    //     0x6f5bd4: mov             x0, #0
    // 0x6f5bd8: stur            x3, [fp, #-8]
    // 0x6f5bdc: StoreField: r3->field_b = r0
    //     0x6f5bdc: stur            x0, [x3, #0xb]
    // 0x6f5be0: StoreField: r3->field_17 = r0
    //     0x6f5be0: stur            x0, [x3, #0x17]
    // 0x6f5be4: r1 = <_HashMapEntry<int, TableColumnWidth>?>
    //     0x6f5be4: add             x1, PP, #0x57, lsl #12  ; [pp+0x574a8] TypeArguments: <_HashMapEntry<int, TableColumnWidth>?>
    //     0x6f5be8: ldr             x1, [x1, #0x4a8]
    // 0x6f5bec: r2 = 16
    //     0x6f5bec: mov             x2, #0x10
    // 0x6f5bf0: r0 = AllocateArray()
    //     0x6f5bf0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x6f5bf4: mov             x1, x0
    // 0x6f5bf8: ldur            x0, [fp, #-8]
    // 0x6f5bfc: StoreField: r0->field_13 = r1
    //     0x6f5bfc: stur            w1, [x0, #0x13]
    // 0x6f5c00: ldr             x1, [fp, #0x38]
    // 0x6f5c04: StoreField: r1->field_73 = r0
    //     0x6f5c04: stur            w0, [x1, #0x73]
    //     0x6f5c08: ldurb           w16, [x1, #-1]
    //     0x6f5c0c: ldurb           w17, [x0, #-1]
    //     0x6f5c10: and             x16, x17, x16, lsr #2
    //     0x6f5c14: tst             x16, HEAP, lsr #32
    //     0x6f5c18: b.eq            #0x6f5c20
    //     0x6f5c1c: bl              #0xd6826c
    // 0x6f5c20: r0 = Instance_FlexColumnWidth
    //     0x6f5c20: add             x0, PP, #0x57, lsl #12  ; [pp+0x570e0] Obj!FlexColumnWidth@b35251
    //     0x6f5c24: ldr             x0, [x0, #0xe0]
    // 0x6f5c28: StoreField: r1->field_77 = r0
    //     0x6f5c28: stur            w0, [x1, #0x77]
    // 0x6f5c2c: r0 = Instance_TableBorder
    //     0x6f5c2c: add             x0, PP, #0x46, lsl #12  ; [pp+0x46e98] Obj!TableBorder@b35221
    //     0x6f5c30: ldr             x0, [x0, #0xe98]
    // 0x6f5c34: StoreField: r1->field_7f = r0
    //     0x6f5c34: stur            w0, [x1, #0x7f]
    // 0x6f5c38: r0 = Instance_TableCellVerticalAlignment
    //     0x6f5c38: add             x0, PP, #0x57, lsl #12  ; [pp+0x570e8] Obj!TableCellVerticalAlignment@b64751
    //     0x6f5c3c: ldr             x0, [x0, #0xe8]
    // 0x6f5c40: StoreField: r1->field_8f = r0
    //     0x6f5c40: stur            w0, [x1, #0x8f]
    // 0x6f5c44: ldr             x0, [fp, #0x28]
    // 0x6f5c48: StoreField: r1->field_8b = r0
    //     0x6f5c48: stur            w0, [x1, #0x8b]
    //     0x6f5c4c: ldurb           w16, [x1, #-1]
    //     0x6f5c50: ldurb           w17, [x0, #-1]
    //     0x6f5c54: and             x16, x17, x16, lsr #2
    //     0x6f5c58: tst             x16, HEAP, lsr #32
    //     0x6f5c5c: b.eq            #0x6f5c64
    //     0x6f5c60: bl              #0xd6826c
    // 0x6f5c64: SaveReg r1
    //     0x6f5c64: str             x1, [SP, #-8]!
    // 0x6f5c68: r0 = RenderObject()
    //     0x6f5c68: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6f5c6c: add             SP, SP, #8
    // 0x6f5c70: r16 = <RenderBox?>
    //     0x6f5c70: add             x16, PP, #0x50, lsl #12  ; [pp+0x50a08] TypeArguments: <RenderBox?>
    //     0x6f5c74: ldr             x16, [x16, #0xa08]
    // 0x6f5c78: stp             xzr, x16, [SP, #-0x10]!
    // 0x6f5c7c: r0 = _GrowableList()
    //     0x6f5c7c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x6f5c80: add             SP, SP, #0x10
    // 0x6f5c84: mov             x1, x0
    // 0x6f5c88: ldr             x0, [fp, #0x38]
    // 0x6f5c8c: stur            x1, [fp, #-8]
    // 0x6f5c90: LoadField: r2 = r0->field_63
    //     0x6f5c90: ldur            x2, [x0, #0x63]
    // 0x6f5c94: LoadField: r3 = r0->field_6b
    //     0x6f5c94: ldur            x3, [x0, #0x6b]
    // 0x6f5c98: mul             x4, x2, x3
    // 0x6f5c9c: stp             x4, x1, [SP, #-0x10]!
    // 0x6f5ca0: r0 = length=()
    //     0x6f5ca0: bl              #0x5efc5c  ; [dart:core] _GrowableList::length=
    // 0x6f5ca4: add             SP, SP, #0x10
    // 0x6f5ca8: ldur            x0, [fp, #-8]
    // 0x6f5cac: ldr             x1, [fp, #0x38]
    // 0x6f5cb0: StoreField: r1->field_5f = r0
    //     0x6f5cb0: stur            w0, [x1, #0x5f]
    //     0x6f5cb4: ldurb           w16, [x1, #-1]
    //     0x6f5cb8: ldurb           w17, [x0, #-1]
    //     0x6f5cbc: and             x16, x17, x16, lsr #2
    //     0x6f5cc0: tst             x16, HEAP, lsr #32
    //     0x6f5cc4: b.eq            #0x6f5ccc
    //     0x6f5cc8: bl              #0xd6826c
    // 0x6f5ccc: ldr             x16, [fp, #0x20]
    // 0x6f5cd0: stp             x16, x1, [SP, #-0x10]!
    // 0x6f5cd4: r0 = rowDecorations=()
    //     0x6f5cd4: bl              #0x6e63c4  ; [package:flutter/src/rendering/table.dart] RenderTable::rowDecorations=
    // 0x6f5cd8: add             SP, SP, #0x10
    // 0x6f5cdc: r0 = Null
    //     0x6f5cdc: mov             x0, NULL
    // 0x6f5ce0: LeaveFrame
    //     0x6f5ce0: mov             SP, fp
    //     0x6f5ce4: ldp             fp, lr, [SP], #0x10
    // 0x6f5ce8: ret
    //     0x6f5ce8: ret             
    // 0x6f5cec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f5cec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f5cf0: b               #0x6f5b54
  }
  _ setChild(/* No info */) {
    // ** addr: 0x7128f8, size: 0x150
    // 0x7128f8: EnterFrame
    //     0x7128f8: stp             fp, lr, [SP, #-0x10]!
    //     0x7128fc: mov             fp, SP
    // 0x712900: AllocStack(0x10)
    //     0x712900: sub             SP, SP, #0x10
    // 0x712904: CheckStackOverflow
    //     0x712904: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x712908: cmp             SP, x16
    //     0x71290c: b.ls            #0x712a40
    // 0x712910: ldr             x2, [fp, #0x28]
    // 0x712914: LoadField: r0 = r2->field_63
    //     0x712914: ldur            x0, [x2, #0x63]
    // 0x712918: ldr             x1, [fp, #0x18]
    // 0x71291c: mul             x3, x1, x0
    // 0x712920: ldr             x0, [fp, #0x20]
    // 0x712924: r1 = LoadInt32Instr(r0)
    //     0x712924: sbfx            x1, x0, #1, #0x1f
    //     0x712928: tbz             w0, #0, #0x712930
    //     0x71292c: ldur            x1, [x0, #7]
    // 0x712930: add             x4, x1, x3
    // 0x712934: LoadField: r3 = r2->field_5f
    //     0x712934: ldur            w3, [x2, #0x5f]
    // 0x712938: DecompressPointer r3
    //     0x712938: add             x3, x3, HEAP, lsl #32
    // 0x71293c: r0 = BoxInt64Instr(r4)
    //     0x71293c: sbfiz           x0, x4, #1, #0x1f
    //     0x712940: cmp             x4, x0, asr #1
    //     0x712944: b.eq            #0x712950
    //     0x712948: bl              #0xd69bb8
    //     0x71294c: stur            x4, [x0, #7]
    // 0x712950: mov             x1, x0
    // 0x712954: stur            x1, [fp, #-8]
    // 0x712958: r0 = LoadClassIdInstr(r3)
    //     0x712958: ldur            x0, [x3, #-1]
    //     0x71295c: ubfx            x0, x0, #0xc, #0x14
    // 0x712960: stp             x1, x3, [SP, #-0x10]!
    // 0x712964: r0 = GDT[cid_x0 + -0xd83]()
    //     0x712964: sub             lr, x0, #0xd83
    //     0x712968: ldr             lr, [x21, lr, lsl #3]
    //     0x71296c: blr             lr
    // 0x712970: add             SP, SP, #0x10
    // 0x712974: mov             x1, x0
    // 0x712978: stur            x1, [fp, #-0x10]
    // 0x71297c: r0 = 59
    //     0x71297c: mov             x0, #0x3b
    // 0x712980: branchIfSmi(r1, 0x71298c)
    //     0x712980: tbz             w1, #0, #0x71298c
    // 0x712984: r0 = LoadClassIdInstr(r1)
    //     0x712984: ldur            x0, [x1, #-1]
    //     0x712988: ubfx            x0, x0, #0xc, #0x14
    // 0x71298c: ldr             x16, [fp, #0x10]
    // 0x712990: stp             x16, x1, [SP, #-0x10]!
    // 0x712994: mov             lr, x0
    // 0x712998: ldr             lr, [x21, lr, lsl #3]
    // 0x71299c: blr             lr
    // 0x7129a0: add             SP, SP, #0x10
    // 0x7129a4: tbnz            w0, #4, #0x7129b8
    // 0x7129a8: r0 = Null
    //     0x7129a8: mov             x0, NULL
    // 0x7129ac: LeaveFrame
    //     0x7129ac: mov             SP, fp
    //     0x7129b0: ldp             fp, lr, [SP], #0x10
    // 0x7129b4: ret
    //     0x7129b4: ret             
    // 0x7129b8: ldur            x0, [fp, #-0x10]
    // 0x7129bc: cmp             w0, NULL
    // 0x7129c0: b.eq            #0x7129d4
    // 0x7129c4: ldr             x16, [fp, #0x28]
    // 0x7129c8: stp             x0, x16, [SP, #-0x10]!
    // 0x7129cc: r0 = dropChild()
    //     0x7129cc: bl              #0x5e5aec  ; [package:flutter/src/rendering/object.dart] RenderObject::dropChild
    // 0x7129d0: add             SP, SP, #0x10
    // 0x7129d4: ldr             x1, [fp, #0x28]
    // 0x7129d8: ldr             x2, [fp, #0x10]
    // 0x7129dc: LoadField: r0 = r1->field_5f
    //     0x7129dc: ldur            w0, [x1, #0x5f]
    // 0x7129e0: DecompressPointer r0
    //     0x7129e0: add             x0, x0, HEAP, lsl #32
    // 0x7129e4: r3 = LoadClassIdInstr(r0)
    //     0x7129e4: ldur            x3, [x0, #-1]
    //     0x7129e8: ubfx            x3, x3, #0xc, #0x14
    // 0x7129ec: ldur            x16, [fp, #-8]
    // 0x7129f0: stp             x16, x0, [SP, #-0x10]!
    // 0x7129f4: SaveReg r2
    //     0x7129f4: str             x2, [SP, #-8]!
    // 0x7129f8: mov             x0, x3
    // 0x7129fc: r0 = GDT[cid_x0 + 0x1015e]()
    //     0x7129fc: mov             x17, #0x15e
    //     0x712a00: movk            x17, #1, lsl #16
    //     0x712a04: add             lr, x0, x17
    //     0x712a08: ldr             lr, [x21, lr, lsl #3]
    //     0x712a0c: blr             lr
    // 0x712a10: add             SP, SP, #0x18
    // 0x712a14: ldr             x0, [fp, #0x10]
    // 0x712a18: cmp             w0, NULL
    // 0x712a1c: b.eq            #0x712a30
    // 0x712a20: ldr             x16, [fp, #0x28]
    // 0x712a24: stp             x0, x16, [SP, #-0x10]!
    // 0x712a28: r0 = adoptChild()
    //     0x712a28: bl              #0x5e61d4  ; [package:flutter/src/rendering/object.dart] RenderObject::adoptChild
    // 0x712a2c: add             SP, SP, #0x10
    // 0x712a30: r0 = Null
    //     0x712a30: mov             x0, NULL
    // 0x712a34: LeaveFrame
    //     0x712a34: mov             SP, fp
    //     0x712a38: ldp             fp, lr, [SP], #0x10
    // 0x712a3c: ret
    //     0x712a3c: ret             
    // 0x712a40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x712a40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x712a44: b               #0x712910
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bee98, size: 0x138
    // 0x9bee98: EnterFrame
    //     0x9bee98: stp             fp, lr, [SP, #-0x10]!
    //     0x9bee9c: mov             fp, SP
    // 0x9beea0: AllocStack(0x8)
    //     0x9beea0: sub             SP, SP, #8
    // 0x9beea4: CheckStackOverflow
    //     0x9beea4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9beea8: cmp             SP, x16
    //     0x9beeac: b.ls            #0x9befc0
    // 0x9beeb0: ldr             x0, [fp, #0x10]
    // 0x9beeb4: r2 = Null
    //     0x9beeb4: mov             x2, NULL
    // 0x9beeb8: r1 = Null
    //     0x9beeb8: mov             x1, NULL
    // 0x9beebc: r4 = 59
    //     0x9beebc: mov             x4, #0x3b
    // 0x9beec0: branchIfSmi(r0, 0x9beecc)
    //     0x9beec0: tbz             w0, #0, #0x9beecc
    // 0x9beec4: r4 = LoadClassIdInstr(r0)
    //     0x9beec4: ldur            x4, [x0, #-1]
    //     0x9beec8: ubfx            x4, x4, #0xc, #0x14
    // 0x9beecc: cmp             x4, #0x7e6
    // 0x9beed0: b.eq            #0x9beee4
    // 0x9beed4: r8 = PipelineOwner
    //     0x9beed4: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9beed8: r3 = Null
    //     0x9beed8: add             x3, PP, #0x57, lsl #12  ; [pp+0x57780] Null
    //     0x9beedc: ldr             x3, [x3, #0x780]
    // 0x9beee0: r0 = DefaultTypeTest()
    //     0x9beee0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9beee4: ldr             x16, [fp, #0x18]
    // 0x9beee8: ldr             lr, [fp, #0x10]
    // 0x9beeec: stp             lr, x16, [SP, #-0x10]!
    // 0x9beef0: r0 = attach()
    //     0x9beef0: bl              #0x9bf794  ; [package:flutter/src/rendering/object.dart] RenderObject::attach
    // 0x9beef4: add             SP, SP, #0x10
    // 0x9beef8: ldr             x0, [fp, #0x18]
    // 0x9beefc: LoadField: r1 = r0->field_5f
    //     0x9beefc: ldur            w1, [x0, #0x5f]
    // 0x9bef00: DecompressPointer r1
    //     0x9bef00: add             x1, x1, HEAP, lsl #32
    // 0x9bef04: r0 = LoadClassIdInstr(r1)
    //     0x9bef04: ldur            x0, [x1, #-1]
    //     0x9bef08: ubfx            x0, x0, #0xc, #0x14
    // 0x9bef0c: SaveReg r1
    //     0x9bef0c: str             x1, [SP, #-8]!
    // 0x9bef10: r0 = GDT[cid_x0 + 0xb940]()
    //     0x9bef10: mov             x17, #0xb940
    //     0x9bef14: add             lr, x0, x17
    //     0x9bef18: ldr             lr, [x21, lr, lsl #3]
    //     0x9bef1c: blr             lr
    // 0x9bef20: add             SP, SP, #8
    // 0x9bef24: mov             x1, x0
    // 0x9bef28: stur            x1, [fp, #-8]
    // 0x9bef2c: CheckStackOverflow
    //     0x9bef2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bef30: cmp             SP, x16
    //     0x9bef34: b.ls            #0x9befc8
    // 0x9bef38: r0 = LoadClassIdInstr(r1)
    //     0x9bef38: ldur            x0, [x1, #-1]
    //     0x9bef3c: ubfx            x0, x0, #0xc, #0x14
    // 0x9bef40: SaveReg r1
    //     0x9bef40: str             x1, [SP, #-8]!
    // 0x9bef44: r0 = GDT[cid_x0 + 0x541]()
    //     0x9bef44: add             lr, x0, #0x541
    //     0x9bef48: ldr             lr, [x21, lr, lsl #3]
    //     0x9bef4c: blr             lr
    // 0x9bef50: add             SP, SP, #8
    // 0x9bef54: tbnz            w0, #4, #0x9befb0
    // 0x9bef58: ldur            x1, [fp, #-8]
    // 0x9bef5c: r0 = LoadClassIdInstr(r1)
    //     0x9bef5c: ldur            x0, [x1, #-1]
    //     0x9bef60: ubfx            x0, x0, #0xc, #0x14
    // 0x9bef64: SaveReg r1
    //     0x9bef64: str             x1, [SP, #-8]!
    // 0x9bef68: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x9bef68: add             lr, x0, #0x5ca
    //     0x9bef6c: ldr             lr, [x21, lr, lsl #3]
    //     0x9bef70: blr             lr
    // 0x9bef74: add             SP, SP, #8
    // 0x9bef78: cmp             w0, NULL
    // 0x9bef7c: b.eq            #0x9befa8
    // 0x9bef80: r1 = LoadClassIdInstr(r0)
    //     0x9bef80: ldur            x1, [x0, #-1]
    //     0x9bef84: ubfx            x1, x1, #0xc, #0x14
    // 0x9bef88: ldr             x16, [fp, #0x10]
    // 0x9bef8c: stp             x16, x0, [SP, #-0x10]!
    // 0x9bef90: mov             x0, x1
    // 0x9bef94: r0 = GDT[cid_x0 + 0xaf1f]()
    //     0x9bef94: mov             x17, #0xaf1f
    //     0x9bef98: add             lr, x0, x17
    //     0x9bef9c: ldr             lr, [x21, lr, lsl #3]
    //     0x9befa0: blr             lr
    // 0x9befa4: add             SP, SP, #0x10
    // 0x9befa8: ldur            x1, [fp, #-8]
    // 0x9befac: b               #0x9bef2c
    // 0x9befb0: r0 = Null
    //     0x9befb0: mov             x0, NULL
    // 0x9befb4: LeaveFrame
    //     0x9befb4: mov             SP, fp
    //     0x9befb8: ldp             fp, lr, [SP], #0x10
    // 0x9befbc: ret
    //     0x9befbc: ret             
    // 0x9befc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9befc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9befc4: b               #0x9beeb0
    // 0x9befc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9befc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9befcc: b               #0x9bef38
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5ed84, size: 0x468
    // 0xa5ed84: EnterFrame
    //     0xa5ed84: stp             fp, lr, [SP, #-0x10]!
    //     0xa5ed88: mov             fp, SP
    // 0xa5ed8c: AllocStack(0x58)
    //     0xa5ed8c: sub             SP, SP, #0x58
    // 0xa5ed90: CheckStackOverflow
    //     0xa5ed90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5ed94: cmp             SP, x16
    //     0xa5ed98: b.ls            #0xa5f198
    // 0xa5ed9c: ldr             x0, [fp, #0x18]
    // 0xa5eda0: LoadField: r1 = r0->field_6b
    //     0xa5eda0: ldur            x1, [x0, #0x6b]
    // 0xa5eda4: LoadField: r2 = r0->field_63
    //     0xa5eda4: ldur            x2, [x0, #0x63]
    // 0xa5eda8: mul             x3, x1, x2
    // 0xa5edac: cbnz            x3, #0xa5edd0
    // 0xa5edb0: ldr             x16, [fp, #0x10]
    // 0xa5edb4: r30 = Instance_Size
    //     0xa5edb4: ldr             lr, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0xa5edb8: stp             lr, x16, [SP, #-0x10]!
    // 0xa5edbc: r0 = constrain()
    //     0xa5edbc: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xa5edc0: add             SP, SP, #0x10
    // 0xa5edc4: LeaveFrame
    //     0xa5edc4: mov             SP, fp
    //     0xa5edc8: ldp             fp, lr, [SP], #0x10
    // 0xa5edcc: ret
    //     0xa5edcc: ret             
    // 0xa5edd0: ldr             x16, [fp, #0x10]
    // 0xa5edd4: stp             x16, x0, [SP, #-0x10]!
    // 0xa5edd8: r0 = _computeColumnWidths()
    //     0xa5edd8: bl              #0x632bf8  ; [package:flutter/src/rendering/table.dart] RenderTable::_computeColumnWidths
    // 0xa5eddc: add             SP, SP, #0x10
    // 0xa5ede0: r1 = Function '<anonymous closure>':.
    //     0xa5ede0: add             x1, PP, #0x57, lsl #12  ; [pp+0x57758] AnonymousClosure: (0x70410c), in [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::acceptGesture (0xbdbe38)
    //     0xa5ede4: ldr             x1, [x1, #0x758]
    // 0xa5ede8: r2 = Null
    //     0xa5ede8: mov             x2, NULL
    // 0xa5edec: stur            x0, [fp, #-8]
    // 0xa5edf0: r0 = AllocateClosure()
    //     0xa5edf0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa5edf4: r16 = <double>
    //     0xa5edf4: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xa5edf8: ldur            lr, [fp, #-8]
    // 0xa5edfc: stp             lr, x16, [SP, #-0x10]!
    // 0xa5ee00: r16 = 0.000000
    //     0xa5ee00: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xa5ee04: stp             x0, x16, [SP, #-0x10]!
    // 0xa5ee08: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xa5ee08: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xa5ee0c: r0 = fold()
    //     0xa5ee0c: bl              #0x5247b8  ; [dart:collection] _ListBase&Object&ListMixin::fold
    // 0xa5ee10: add             SP, SP, #0x20
    // 0xa5ee14: mov             x3, x0
    // 0xa5ee18: ldur            x2, [fp, #-8]
    // 0xa5ee1c: stur            x3, [fp, #-0x30]
    // 0xa5ee20: LoadField: r0 = r2->field_b
    //     0xa5ee20: ldur            w0, [x2, #0xb]
    // 0xa5ee24: DecompressPointer r0
    //     0xa5ee24: add             x0, x0, HEAP, lsl #32
    // 0xa5ee28: r4 = LoadInt32Instr(r0)
    //     0xa5ee28: sbfx            x4, x0, #1, #0x1f
    // 0xa5ee2c: stur            x4, [fp, #-0x28]
    // 0xa5ee30: d0 = 0.000000
    //     0xa5ee30: eor             v0.16b, v0.16b, v0.16b
    // 0xa5ee34: r6 = 0
    //     0xa5ee34: mov             x6, #0
    // 0xa5ee38: ldr             x5, [fp, #0x18]
    // 0xa5ee3c: stur            x6, [fp, #-0x20]
    // 0xa5ee40: stur            d0, [fp, #-0x50]
    // 0xa5ee44: CheckStackOverflow
    //     0xa5ee44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5ee48: cmp             SP, x16
    //     0xa5ee4c: b.ls            #0xa5f1a0
    // 0xa5ee50: LoadField: r0 = r5->field_6b
    //     0xa5ee50: ldur            x0, [x5, #0x6b]
    // 0xa5ee54: cmp             x6, x0
    // 0xa5ee58: b.ge            #0xa5f15c
    // 0xa5ee5c: r8 = 0.000000
    //     0xa5ee5c: ldr             x8, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xa5ee60: r7 = 0
    //     0xa5ee60: mov             x7, #0
    // 0xa5ee64: stur            x8, [fp, #-0x10]
    // 0xa5ee68: stur            x7, [fp, #-0x18]
    // 0xa5ee6c: CheckStackOverflow
    //     0xa5ee6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5ee70: cmp             SP, x16
    //     0xa5ee74: b.ls            #0xa5f1a8
    // 0xa5ee78: LoadField: r0 = r5->field_63
    //     0xa5ee78: ldur            x0, [x5, #0x63]
    // 0xa5ee7c: cmp             x7, x0
    // 0xa5ee80: b.ge            #0xa5f130
    // 0xa5ee84: mul             x1, x6, x0
    // 0xa5ee88: add             x9, x7, x1
    // 0xa5ee8c: LoadField: r10 = r5->field_5f
    //     0xa5ee8c: ldur            w10, [x5, #0x5f]
    // 0xa5ee90: DecompressPointer r10
    //     0xa5ee90: add             x10, x10, HEAP, lsl #32
    // 0xa5ee94: r0 = BoxInt64Instr(r9)
    //     0xa5ee94: sbfiz           x0, x9, #1, #0x1f
    //     0xa5ee98: cmp             x9, x0, asr #1
    //     0xa5ee9c: b.eq            #0xa5eea8
    //     0xa5eea0: bl              #0xd69c6c
    //     0xa5eea4: stur            x9, [x0, #7]
    // 0xa5eea8: r1 = LoadClassIdInstr(r10)
    //     0xa5eea8: ldur            x1, [x10, #-1]
    //     0xa5eeac: ubfx            x1, x1, #0xc, #0x14
    // 0xa5eeb0: stp             x0, x10, [SP, #-0x10]!
    // 0xa5eeb4: mov             x0, x1
    // 0xa5eeb8: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa5eeb8: sub             lr, x0, #0xd83
    //     0xa5eebc: ldr             lr, [x21, lr, lsl #3]
    //     0xa5eec0: blr             lr
    // 0xa5eec4: add             SP, SP, #0x10
    // 0xa5eec8: mov             x3, x0
    // 0xa5eecc: stur            x3, [fp, #-0x38]
    // 0xa5eed0: cmp             w3, NULL
    // 0xa5eed4: b.eq            #0xa5f100
    // 0xa5eed8: ldur            x4, [fp, #-8]
    // 0xa5eedc: ldur            x5, [fp, #-0x18]
    // 0xa5eee0: LoadField: r0 = r3->field_17
    //     0xa5eee0: ldur            w0, [x3, #0x17]
    // 0xa5eee4: DecompressPointer r0
    //     0xa5eee4: add             x0, x0, HEAP, lsl #32
    // 0xa5eee8: cmp             w0, NULL
    // 0xa5eeec: b.eq            #0xa5f1b0
    // 0xa5eef0: r2 = Null
    //     0xa5eef0: mov             x2, NULL
    // 0xa5eef4: r1 = Null
    //     0xa5eef4: mov             x1, NULL
    // 0xa5eef8: r4 = LoadClassIdInstr(r0)
    //     0xa5eef8: ldur            x4, [x0, #-1]
    //     0xa5eefc: ubfx            x4, x4, #0xc, #0x14
    // 0xa5ef00: cmp             x4, #0x800
    // 0xa5ef04: b.eq            #0xa5ef1c
    // 0xa5ef08: r8 = TableCellParentData
    //     0xa5ef08: add             x8, PP, #0x57, lsl #12  ; [pp+0x57730] Type: TableCellParentData
    //     0xa5ef0c: ldr             x8, [x8, #0x730]
    // 0xa5ef10: r3 = Null
    //     0xa5ef10: add             x3, PP, #0x57, lsl #12  ; [pp+0x57760] Null
    //     0xa5ef14: ldr             x3, [x3, #0x760]
    // 0xa5ef18: r0 = DefaultTypeTest()
    //     0xa5ef18: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa5ef1c: ldur            x0, [fp, #-0x28]
    // 0xa5ef20: ldur            x1, [fp, #-0x18]
    // 0xa5ef24: cmp             x1, x0
    // 0xa5ef28: b.hs            #0xa5f1b4
    // 0xa5ef2c: ldur            x0, [fp, #-8]
    // 0xa5ef30: ldur            x1, [fp, #-0x18]
    // 0xa5ef34: ArrayLoad: r2 = r0[r1]  ; Unknown_4
    //     0xa5ef34: add             x16, x0, x1, lsl #2
    //     0xa5ef38: ldur            w2, [x16, #0xf]
    // 0xa5ef3c: DecompressPointer r2
    //     0xa5ef3c: add             x2, x2, HEAP, lsl #32
    // 0xa5ef40: LoadField: d0 = r2->field_7
    //     0xa5ef40: ldur            d0, [x2, #7]
    // 0xa5ef44: stur            d0, [fp, #-0x58]
    // 0xa5ef48: r0 = BoxConstraints()
    //     0xa5ef48: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xa5ef4c: ldur            d0, [fp, #-0x58]
    // 0xa5ef50: stur            x0, [fp, #-0x40]
    // 0xa5ef54: StoreField: r0->field_7 = d0
    //     0xa5ef54: stur            d0, [x0, #7]
    // 0xa5ef58: StoreField: r0->field_f = d0
    //     0xa5ef58: stur            d0, [x0, #0xf]
    // 0xa5ef5c: d0 = 0.000000
    //     0xa5ef5c: eor             v0.16b, v0.16b, v0.16b
    // 0xa5ef60: StoreField: r0->field_17 = d0
    //     0xa5ef60: stur            d0, [x0, #0x17]
    // 0xa5ef64: d1 = inf
    //     0xa5ef64: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xa5ef68: StoreField: r0->field_1f = d1
    //     0xa5ef68: stur            d1, [x0, #0x1f]
    // 0xa5ef6c: r1 = 2
    //     0xa5ef6c: mov             x1, #2
    // 0xa5ef70: r0 = AllocateContext()
    //     0xa5ef70: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa5ef74: mov             x1, x0
    // 0xa5ef78: ldur            x0, [fp, #-0x38]
    // 0xa5ef7c: stur            x1, [fp, #-0x48]
    // 0xa5ef80: StoreField: r1->field_f = r0
    //     0xa5ef80: stur            w0, [x1, #0xf]
    // 0xa5ef84: ldur            x2, [fp, #-0x40]
    // 0xa5ef88: StoreField: r1->field_13 = r2
    //     0xa5ef88: stur            w2, [x1, #0x13]
    // 0xa5ef8c: LoadField: r2 = r0->field_53
    //     0xa5ef8c: ldur            w2, [x0, #0x53]
    // 0xa5ef90: DecompressPointer r2
    //     0xa5ef90: add             x2, x2, HEAP, lsl #32
    // 0xa5ef94: cmp             w2, NULL
    // 0xa5ef98: b.ne            #0xa5efe4
    // 0xa5ef9c: r16 = <BoxConstraints, Size>
    //     0xa5ef9c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15208] TypeArguments: <BoxConstraints, Size>
    //     0xa5efa0: ldr             x16, [x16, #0x208]
    // 0xa5efa4: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xa5efa8: stp             lr, x16, [SP, #-0x10]!
    // 0xa5efac: r0 = Map._fromLiteral()
    //     0xa5efac: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xa5efb0: add             SP, SP, #0x10
    // 0xa5efb4: mov             x2, x0
    // 0xa5efb8: ldur            x1, [fp, #-0x38]
    // 0xa5efbc: StoreField: r1->field_53 = r0
    //     0xa5efbc: stur            w0, [x1, #0x53]
    //     0xa5efc0: tbz             w0, #0, #0xa5efdc
    //     0xa5efc4: ldurb           w16, [x1, #-1]
    //     0xa5efc8: ldurb           w17, [x0, #-1]
    //     0xa5efcc: and             x16, x17, x16, lsr #2
    //     0xa5efd0: tst             x16, HEAP, lsr #32
    //     0xa5efd4: b.eq            #0xa5efdc
    //     0xa5efd8: bl              #0xd6826c
    // 0xa5efdc: mov             x3, x2
    // 0xa5efe0: b               #0xa5efe8
    // 0xa5efe4: mov             x3, x2
    // 0xa5efe8: ldur            x0, [fp, #-0x10]
    // 0xa5efec: ldur            x2, [fp, #-0x48]
    // 0xa5eff0: stur            x3, [fp, #-0x40]
    // 0xa5eff4: cmp             w3, NULL
    // 0xa5eff8: b.eq            #0xa5f1b8
    // 0xa5effc: LoadField: r4 = r2->field_13
    //     0xa5effc: ldur            w4, [x2, #0x13]
    // 0xa5f000: DecompressPointer r4
    //     0xa5f000: add             x4, x4, HEAP, lsl #32
    // 0xa5f004: stur            x4, [fp, #-0x38]
    // 0xa5f008: r1 = Function '<anonymous closure>':.
    //     0xa5f008: add             x1, PP, #0x15, lsl #12  ; [pp+0x15210] AnonymousClosure: (0x62d778), in [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout (0x62d394)
    //     0xa5f00c: ldr             x1, [x1, #0x210]
    // 0xa5f010: r0 = AllocateClosure()
    //     0xa5f010: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa5f014: ldur            x16, [fp, #-0x40]
    // 0xa5f018: ldur            lr, [fp, #-0x38]
    // 0xa5f01c: stp             lr, x16, [SP, #-0x10]!
    // 0xa5f020: SaveReg r0
    //     0xa5f020: str             x0, [SP, #-8]!
    // 0xa5f024: r0 = putIfAbsent()
    //     0xa5f024: bl              #0xc7a83c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0xa5f028: add             SP, SP, #0x18
    // 0xa5f02c: LoadField: d0 = r0->field_f
    //     0xa5f02c: ldur            d0, [x0, #0xf]
    // 0xa5f030: ldur            x0, [fp, #-0x10]
    // 0xa5f034: LoadField: d1 = r0->field_7
    //     0xa5f034: ldur            d1, [x0, #7]
    // 0xa5f038: fcmp            d1, d0
    // 0xa5f03c: b.vs            #0xa5f04c
    // 0xa5f040: b.le            #0xa5f04c
    // 0xa5f044: d2 = 0.000000
    //     0xa5f044: eor             v2.16b, v2.16b, v2.16b
    // 0xa5f048: b               #0xa5f0f8
    // 0xa5f04c: fcmp            d1, d0
    // 0xa5f050: b.vs            #0xa5f088
    // 0xa5f054: b.ge            #0xa5f088
    // 0xa5f058: r0 = inline_Allocate_Double()
    //     0xa5f058: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa5f05c: add             x0, x0, #0x10
    //     0xa5f060: cmp             x1, x0
    //     0xa5f064: b.ls            #0xa5f1bc
    //     0xa5f068: str             x0, [THR, #0x60]  ; THR::top
    //     0xa5f06c: sub             x0, x0, #0xf
    //     0xa5f070: mov             x1, #0xd108
    //     0xa5f074: movk            x1, #3, lsl #16
    //     0xa5f078: stur            x1, [x0, #-1]
    // 0xa5f07c: StoreField: r0->field_7 = d0
    //     0xa5f07c: stur            d0, [x0, #7]
    // 0xa5f080: d2 = 0.000000
    //     0xa5f080: eor             v2.16b, v2.16b, v2.16b
    // 0xa5f084: b               #0xa5f0f8
    // 0xa5f088: d2 = 0.000000
    //     0xa5f088: eor             v2.16b, v2.16b, v2.16b
    // 0xa5f08c: fcmp            d1, d2
    // 0xa5f090: b.vs            #0xa5f0c8
    // 0xa5f094: b.ne            #0xa5f0c8
    // 0xa5f098: fadd            d3, d1, d0
    // 0xa5f09c: r0 = inline_Allocate_Double()
    //     0xa5f09c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa5f0a0: add             x0, x0, #0x10
    //     0xa5f0a4: cmp             x1, x0
    //     0xa5f0a8: b.ls            #0xa5f1cc
    //     0xa5f0ac: str             x0, [THR, #0x60]  ; THR::top
    //     0xa5f0b0: sub             x0, x0, #0xf
    //     0xa5f0b4: mov             x1, #0xd108
    //     0xa5f0b8: movk            x1, #3, lsl #16
    //     0xa5f0bc: stur            x1, [x0, #-1]
    // 0xa5f0c0: StoreField: r0->field_7 = d3
    //     0xa5f0c0: stur            d3, [x0, #7]
    // 0xa5f0c4: b               #0xa5f0f8
    // 0xa5f0c8: fcmp            d0, d0
    // 0xa5f0cc: b.vc            #0xa5f0f8
    // 0xa5f0d0: r0 = inline_Allocate_Double()
    //     0xa5f0d0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa5f0d4: add             x0, x0, #0x10
    //     0xa5f0d8: cmp             x1, x0
    //     0xa5f0dc: b.ls            #0xa5f1dc
    //     0xa5f0e0: str             x0, [THR, #0x60]  ; THR::top
    //     0xa5f0e4: sub             x0, x0, #0xf
    //     0xa5f0e8: mov             x1, #0xd108
    //     0xa5f0ec: movk            x1, #3, lsl #16
    //     0xa5f0f0: stur            x1, [x0, #-1]
    // 0xa5f0f4: StoreField: r0->field_7 = d0
    //     0xa5f0f4: stur            d0, [x0, #7]
    // 0xa5f0f8: mov             x8, x0
    // 0xa5f0fc: b               #0xa5f10c
    // 0xa5f100: ldur            x0, [fp, #-0x10]
    // 0xa5f104: d2 = 0.000000
    //     0xa5f104: eor             v2.16b, v2.16b, v2.16b
    // 0xa5f108: mov             x8, x0
    // 0xa5f10c: ldur            x0, [fp, #-0x18]
    // 0xa5f110: add             x7, x0, #1
    // 0xa5f114: ldr             x5, [fp, #0x18]
    // 0xa5f118: ldur            x2, [fp, #-8]
    // 0xa5f11c: ldur            x3, [fp, #-0x30]
    // 0xa5f120: ldur            d0, [fp, #-0x50]
    // 0xa5f124: ldur            x6, [fp, #-0x20]
    // 0xa5f128: ldur            x4, [fp, #-0x28]
    // 0xa5f12c: b               #0xa5ee64
    // 0xa5f130: mov             x1, x6
    // 0xa5f134: mov             x0, x8
    // 0xa5f138: d2 = 0.000000
    //     0xa5f138: eor             v2.16b, v2.16b, v2.16b
    // 0xa5f13c: LoadField: d1 = r0->field_7
    //     0xa5f13c: ldur            d1, [x0, #7]
    // 0xa5f140: fadd            d3, d0, d1
    // 0xa5f144: add             x6, x1, #1
    // 0xa5f148: mov             v0.16b, v3.16b
    // 0xa5f14c: ldur            x2, [fp, #-8]
    // 0xa5f150: ldur            x3, [fp, #-0x30]
    // 0xa5f154: ldur            x4, [fp, #-0x28]
    // 0xa5f158: b               #0xa5ee38
    // 0xa5f15c: mov             x0, x3
    // 0xa5f160: LoadField: d1 = r0->field_7
    //     0xa5f160: ldur            d1, [x0, #7]
    // 0xa5f164: stur            d1, [fp, #-0x58]
    // 0xa5f168: r0 = Size()
    //     0xa5f168: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xa5f16c: ldur            d0, [fp, #-0x58]
    // 0xa5f170: StoreField: r0->field_7 = d0
    //     0xa5f170: stur            d0, [x0, #7]
    // 0xa5f174: ldur            d0, [fp, #-0x50]
    // 0xa5f178: StoreField: r0->field_f = d0
    //     0xa5f178: stur            d0, [x0, #0xf]
    // 0xa5f17c: ldr             x16, [fp, #0x10]
    // 0xa5f180: stp             x0, x16, [SP, #-0x10]!
    // 0xa5f184: r0 = constrain()
    //     0xa5f184: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xa5f188: add             SP, SP, #0x10
    // 0xa5f18c: LeaveFrame
    //     0xa5f18c: mov             SP, fp
    //     0xa5f190: ldp             fp, lr, [SP], #0x10
    // 0xa5f194: ret
    //     0xa5f194: ret             
    // 0xa5f198: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5f198: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5f19c: b               #0xa5ed9c
    // 0xa5f1a0: r0 = StackOverflowSharedWithFPURegs()
    //     0xa5f1a0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xa5f1a4: b               #0xa5ee50
    // 0xa5f1a8: r0 = StackOverflowSharedWithFPURegs()
    //     0xa5f1a8: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xa5f1ac: b               #0xa5ee78
    // 0xa5f1b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa5f1b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa5f1b4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa5f1b4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa5f1b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa5f1b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa5f1bc: SaveReg d0
    //     0xa5f1bc: str             q0, [SP, #-0x10]!
    // 0xa5f1c0: r0 = AllocateDouble()
    //     0xa5f1c0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa5f1c4: RestoreReg d0
    //     0xa5f1c4: ldr             q0, [SP], #0x10
    // 0xa5f1c8: b               #0xa5f07c
    // 0xa5f1cc: stp             q2, q3, [SP, #-0x20]!
    // 0xa5f1d0: r0 = AllocateDouble()
    //     0xa5f1d0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa5f1d4: ldp             q2, q3, [SP], #0x20
    // 0xa5f1d8: b               #0xa5f0c0
    // 0xa5f1dc: stp             q0, q2, [SP, #-0x20]!
    // 0xa5f1e0: r0 = AllocateDouble()
    //     0xa5f1e0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa5f1e4: ldp             q0, q2, [SP], #0x20
    // 0xa5f1e8: b               #0xa5f0f4
  }
  _ detach(/* No info */) {
    // ** addr: 0xa6a4b4, size: 0x258
    // 0xa6a4b4: EnterFrame
    //     0xa6a4b4: stp             fp, lr, [SP, #-0x10]!
    //     0xa6a4b8: mov             fp, SP
    // 0xa6a4bc: AllocStack(0x28)
    //     0xa6a4bc: sub             SP, SP, #0x28
    // 0xa6a4c0: CheckStackOverflow
    //     0xa6a4c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6a4c4: cmp             SP, x16
    //     0xa6a4c8: b.ls            #0xa6a6f0
    // 0xa6a4cc: ldr             x16, [fp, #0x10]
    // 0xa6a4d0: SaveReg r16
    //     0xa6a4d0: str             x16, [SP, #-8]!
    // 0xa6a4d4: r0 = detach()
    //     0xa6a4d4: bl              #0xa6ade0  ; [package:flutter/src/foundation/node.dart] AbstractNode::detach
    // 0xa6a4d8: add             SP, SP, #8
    // 0xa6a4dc: ldr             x1, [fp, #0x10]
    // 0xa6a4e0: LoadField: r3 = r1->field_87
    //     0xa6a4e0: ldur            w3, [x1, #0x87]
    // 0xa6a4e4: DecompressPointer r3
    //     0xa6a4e4: add             x3, x3, HEAP, lsl #32
    // 0xa6a4e8: stur            x3, [fp, #-0x28]
    // 0xa6a4ec: cmp             w3, NULL
    // 0xa6a4f0: b.eq            #0xa6a62c
    // 0xa6a4f4: LoadField: r4 = r3->field_7
    //     0xa6a4f4: ldur            w4, [x3, #7]
    // 0xa6a4f8: DecompressPointer r4
    //     0xa6a4f8: add             x4, x4, HEAP, lsl #32
    // 0xa6a4fc: stur            x4, [fp, #-0x20]
    // 0xa6a500: LoadField: r0 = r3->field_b
    //     0xa6a500: ldur            w0, [x3, #0xb]
    // 0xa6a504: DecompressPointer r0
    //     0xa6a504: add             x0, x0, HEAP, lsl #32
    // 0xa6a508: r5 = LoadInt32Instr(r0)
    //     0xa6a508: sbfx            x5, x0, #1, #0x1f
    // 0xa6a50c: stur            x5, [fp, #-0x18]
    // 0xa6a510: r0 = 0
    //     0xa6a510: mov             x0, #0
    // 0xa6a514: CheckStackOverflow
    //     0xa6a514: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6a518: cmp             SP, x16
    //     0xa6a51c: b.ls            #0xa6a6f8
    // 0xa6a520: cmp             x0, x5
    // 0xa6a524: b.lt            #0xa6a594
    // 0xa6a528: LoadField: r0 = r1->field_83
    //     0xa6a528: ldur            w0, [x1, #0x83]
    // 0xa6a52c: DecompressPointer r0
    //     0xa6a52c: add             x0, x0, HEAP, lsl #32
    // 0xa6a530: cmp             w0, NULL
    // 0xa6a534: b.eq            #0xa6a700
    // 0xa6a538: r2 = LoadClassIdInstr(r0)
    //     0xa6a538: ldur            x2, [x0, #-1]
    //     0xa6a53c: ubfx            x2, x2, #0xc, #0x14
    // 0xa6a540: SaveReg r0
    //     0xa6a540: str             x0, [SP, #-8]!
    // 0xa6a544: mov             x0, x2
    // 0xa6a548: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa6a548: mov             x17, #0xb8ea
    //     0xa6a54c: add             lr, x0, x17
    //     0xa6a550: ldr             lr, [x21, lr, lsl #3]
    //     0xa6a554: blr             lr
    // 0xa6a558: add             SP, SP, #8
    // 0xa6a55c: mov             x2, x0
    // 0xa6a560: r1 = <BoxPainter?>
    //     0xa6a560: add             x1, PP, #0x57, lsl #12  ; [pp+0x57498] TypeArguments: <BoxPainter?>
    //     0xa6a564: ldr             x1, [x1, #0x498]
    // 0xa6a568: r0 = AllocateArray()
    //     0xa6a568: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa6a56c: ldr             x6, [fp, #0x10]
    // 0xa6a570: StoreField: r6->field_87 = r0
    //     0xa6a570: stur            w0, [x6, #0x87]
    //     0xa6a574: ldurb           w16, [x6, #-1]
    //     0xa6a578: ldurb           w17, [x0, #-1]
    //     0xa6a57c: and             x16, x17, x16, lsr #2
    //     0xa6a580: tst             x16, HEAP, lsr #32
    //     0xa6a584: b.eq            #0xa6a58c
    //     0xa6a588: bl              #0xd6830c
    // 0xa6a58c: mov             x0, x6
    // 0xa6a590: b               #0xa6a630
    // 0xa6a594: mov             x6, x1
    // 0xa6a598: ArrayLoad: r7 = r3[r0]  ; Unknown_4
    //     0xa6a598: add             x16, x3, x0, lsl #2
    //     0xa6a59c: ldur            w7, [x16, #0xf]
    // 0xa6a5a0: DecompressPointer r7
    //     0xa6a5a0: add             x7, x7, HEAP, lsl #32
    // 0xa6a5a4: stur            x7, [fp, #-0x10]
    // 0xa6a5a8: add             x8, x0, #1
    // 0xa6a5ac: stur            x8, [fp, #-8]
    // 0xa6a5b0: cmp             w7, NULL
    // 0xa6a5b4: b.ne            #0xa6a5e8
    // 0xa6a5b8: mov             x0, x7
    // 0xa6a5bc: mov             x2, x4
    // 0xa6a5c0: r1 = Null
    //     0xa6a5c0: mov             x1, NULL
    // 0xa6a5c4: cmp             w2, NULL
    // 0xa6a5c8: b.eq            #0xa6a5e8
    // 0xa6a5cc: LoadField: r4 = r2->field_17
    //     0xa6a5cc: ldur            w4, [x2, #0x17]
    // 0xa6a5d0: DecompressPointer r4
    //     0xa6a5d0: add             x4, x4, HEAP, lsl #32
    // 0xa6a5d4: r8 = X0
    //     0xa6a5d4: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa6a5d8: LoadField: r9 = r4->field_7
    //     0xa6a5d8: ldur            x9, [x4, #7]
    // 0xa6a5dc: r3 = Null
    //     0xa6a5dc: add             x3, PP, #0x57, lsl #12  ; [pp+0x57770] Null
    //     0xa6a5e0: ldr             x3, [x3, #0x770]
    // 0xa6a5e4: blr             x9
    // 0xa6a5e8: ldur            x0, [fp, #-0x10]
    // 0xa6a5ec: cmp             w0, NULL
    // 0xa6a5f0: b.eq            #0xa6a614
    // 0xa6a5f4: r1 = LoadClassIdInstr(r0)
    //     0xa6a5f4: ldur            x1, [x0, #-1]
    //     0xa6a5f8: ubfx            x1, x1, #0xc, #0x14
    // 0xa6a5fc: SaveReg r0
    //     0xa6a5fc: str             x0, [SP, #-8]!
    // 0xa6a600: mov             x0, x1
    // 0xa6a604: r0 = GDT[cid_x0 + -0x3c5]()
    //     0xa6a604: sub             lr, x0, #0x3c5
    //     0xa6a608: ldr             lr, [x21, lr, lsl #3]
    //     0xa6a60c: blr             lr
    // 0xa6a610: add             SP, SP, #8
    // 0xa6a614: ldur            x0, [fp, #-8]
    // 0xa6a618: ldr             x1, [fp, #0x10]
    // 0xa6a61c: ldur            x3, [fp, #-0x28]
    // 0xa6a620: ldur            x4, [fp, #-0x20]
    // 0xa6a624: ldur            x5, [fp, #-0x18]
    // 0xa6a628: b               #0xa6a514
    // 0xa6a62c: ldr             x0, [fp, #0x10]
    // 0xa6a630: LoadField: r1 = r0->field_5f
    //     0xa6a630: ldur            w1, [x0, #0x5f]
    // 0xa6a634: DecompressPointer r1
    //     0xa6a634: add             x1, x1, HEAP, lsl #32
    // 0xa6a638: r0 = LoadClassIdInstr(r1)
    //     0xa6a638: ldur            x0, [x1, #-1]
    //     0xa6a63c: ubfx            x0, x0, #0xc, #0x14
    // 0xa6a640: SaveReg r1
    //     0xa6a640: str             x1, [SP, #-8]!
    // 0xa6a644: r0 = GDT[cid_x0 + 0xb940]()
    //     0xa6a644: mov             x17, #0xb940
    //     0xa6a648: add             lr, x0, x17
    //     0xa6a64c: ldr             lr, [x21, lr, lsl #3]
    //     0xa6a650: blr             lr
    // 0xa6a654: add             SP, SP, #8
    // 0xa6a658: mov             x1, x0
    // 0xa6a65c: stur            x1, [fp, #-0x10]
    // 0xa6a660: CheckStackOverflow
    //     0xa6a660: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6a664: cmp             SP, x16
    //     0xa6a668: b.ls            #0xa6a704
    // 0xa6a66c: r0 = LoadClassIdInstr(r1)
    //     0xa6a66c: ldur            x0, [x1, #-1]
    //     0xa6a670: ubfx            x0, x0, #0xc, #0x14
    // 0xa6a674: SaveReg r1
    //     0xa6a674: str             x1, [SP, #-8]!
    // 0xa6a678: r0 = GDT[cid_x0 + 0x541]()
    //     0xa6a678: add             lr, x0, #0x541
    //     0xa6a67c: ldr             lr, [x21, lr, lsl #3]
    //     0xa6a680: blr             lr
    // 0xa6a684: add             SP, SP, #8
    // 0xa6a688: tbnz            w0, #4, #0xa6a6e0
    // 0xa6a68c: ldur            x1, [fp, #-0x10]
    // 0xa6a690: r0 = LoadClassIdInstr(r1)
    //     0xa6a690: ldur            x0, [x1, #-1]
    //     0xa6a694: ubfx            x0, x0, #0xc, #0x14
    // 0xa6a698: SaveReg r1
    //     0xa6a698: str             x1, [SP, #-8]!
    // 0xa6a69c: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xa6a69c: add             lr, x0, #0x5ca
    //     0xa6a6a0: ldr             lr, [x21, lr, lsl #3]
    //     0xa6a6a4: blr             lr
    // 0xa6a6a8: add             SP, SP, #8
    // 0xa6a6ac: cmp             w0, NULL
    // 0xa6a6b0: b.eq            #0xa6a6d8
    // 0xa6a6b4: r1 = LoadClassIdInstr(r0)
    //     0xa6a6b4: ldur            x1, [x0, #-1]
    //     0xa6a6b8: ubfx            x1, x1, #0xc, #0x14
    // 0xa6a6bc: SaveReg r0
    //     0xa6a6bc: str             x0, [SP, #-8]!
    // 0xa6a6c0: mov             x0, x1
    // 0xa6a6c4: r0 = GDT[cid_x0 + 0xa3cc]()
    //     0xa6a6c4: mov             x17, #0xa3cc
    //     0xa6a6c8: add             lr, x0, x17
    //     0xa6a6cc: ldr             lr, [x21, lr, lsl #3]
    //     0xa6a6d0: blr             lr
    // 0xa6a6d4: add             SP, SP, #8
    // 0xa6a6d8: ldur            x1, [fp, #-0x10]
    // 0xa6a6dc: b               #0xa6a660
    // 0xa6a6e0: r0 = Null
    //     0xa6a6e0: mov             x0, NULL
    // 0xa6a6e4: LeaveFrame
    //     0xa6a6e4: mov             SP, fp
    //     0xa6a6e8: ldp             fp, lr, [SP], #0x10
    // 0xa6a6ec: ret
    //     0xa6a6ec: ret             
    // 0xa6a6f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6a6f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6a6f4: b               #0xa6a4cc
    // 0xa6a6f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6a6f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6a6fc: b               #0xa6a520
    // 0xa6a700: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6a700: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa6a704: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6a704: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6a708: b               #0xa6a66c
  }
}

// class id: 5909, size: 0x14, field offset: 0x14
enum TableCellVerticalAlignment extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb17050, size: 0x5c
    // 0xb17050: EnterFrame
    //     0xb17050: stp             fp, lr, [SP, #-0x10]!
    //     0xb17054: mov             fp, SP
    // 0xb17058: CheckStackOverflow
    //     0xb17058: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1705c: cmp             SP, x16
    //     0xb17060: b.ls            #0xb170a4
    // 0xb17064: r1 = Null
    //     0xb17064: mov             x1, NULL
    // 0xb17068: r2 = 4
    //     0xb17068: mov             x2, #4
    // 0xb1706c: r0 = AllocateArray()
    //     0xb1706c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb17070: r17 = "TableCellVerticalAlignment."
    //     0xb17070: add             x17, PP, #0x57, lsl #12  ; [pp+0x574d8] "TableCellVerticalAlignment."
    //     0xb17074: ldr             x17, [x17, #0x4d8]
    // 0xb17078: StoreField: r0->field_f = r17
    //     0xb17078: stur            w17, [x0, #0xf]
    // 0xb1707c: ldr             x1, [fp, #0x10]
    // 0xb17080: LoadField: r2 = r1->field_f
    //     0xb17080: ldur            w2, [x1, #0xf]
    // 0xb17084: DecompressPointer r2
    //     0xb17084: add             x2, x2, HEAP, lsl #32
    // 0xb17088: StoreField: r0->field_13 = r2
    //     0xb17088: stur            w2, [x0, #0x13]
    // 0xb1708c: SaveReg r0
    //     0xb1708c: str             x0, [SP, #-8]!
    // 0xb17090: r0 = _interpolate()
    //     0xb17090: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb17094: add             SP, SP, #8
    // 0xb17098: LeaveFrame
    //     0xb17098: mov             SP, fp
    //     0xb1709c: ldp             fp, lr, [SP], #0x10
    // 0xb170a0: ret
    //     0xb170a0: ret             
    // 0xb170a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb170a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb170a8: b               #0xb17064
  }
}

// lib: , url: package:flutter/src/rendering/rotated_box.dart

// class id: 1049416, size: 0x8
class :: {
}

// class id: 2457, size: 0x74, field offset: 0x64
class RenderRotatedBox extends _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin {

  _ hitTestChildren(/* No info */) {
    // ** addr: 0x6276a8, size: 0xa0
    // 0x6276a8: EnterFrame
    //     0x6276a8: stp             fp, lr, [SP, #-0x10]!
    //     0x6276ac: mov             fp, SP
    // 0x6276b0: AllocStack(0x8)
    //     0x6276b0: sub             SP, SP, #8
    // 0x6276b4: CheckStackOverflow
    //     0x6276b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6276b8: cmp             SP, x16
    //     0x6276bc: b.ls            #0x627740
    // 0x6276c0: r1 = 1
    //     0x6276c0: mov             x1, #1
    // 0x6276c4: r0 = AllocateContext()
    //     0x6276c4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6276c8: mov             x1, x0
    // 0x6276cc: ldr             x0, [fp, #0x20]
    // 0x6276d0: StoreField: r1->field_f = r0
    //     0x6276d0: stur            w0, [x1, #0xf]
    // 0x6276d4: LoadField: r2 = r0->field_5f
    //     0x6276d4: ldur            w2, [x0, #0x5f]
    // 0x6276d8: DecompressPointer r2
    //     0x6276d8: add             x2, x2, HEAP, lsl #32
    // 0x6276dc: cmp             w2, NULL
    // 0x6276e0: b.eq            #0x6276f8
    // 0x6276e4: LoadField: r3 = r0->field_6b
    //     0x6276e4: ldur            w3, [x0, #0x6b]
    // 0x6276e8: DecompressPointer r3
    //     0x6276e8: add             x3, x3, HEAP, lsl #32
    // 0x6276ec: stur            x3, [fp, #-8]
    // 0x6276f0: cmp             w3, NULL
    // 0x6276f4: b.ne            #0x627708
    // 0x6276f8: r0 = false
    //     0x6276f8: add             x0, NULL, #0x30  ; false
    // 0x6276fc: LeaveFrame
    //     0x6276fc: mov             SP, fp
    //     0x627700: ldp             fp, lr, [SP], #0x10
    // 0x627704: ret
    //     0x627704: ret             
    // 0x627708: mov             x2, x1
    // 0x62770c: r1 = Function '<anonymous closure>':.
    //     0x62770c: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b220] AnonymousClosure: (0x625400), in [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::hitTestChildren (0x6277d0)
    //     0x627710: ldr             x1, [x1, #0x220]
    // 0x627714: r0 = AllocateClosure()
    //     0x627714: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x627718: ldr             x16, [fp, #0x18]
    // 0x62771c: stp             x0, x16, [SP, #-0x10]!
    // 0x627720: ldr             x16, [fp, #0x10]
    // 0x627724: ldur            lr, [fp, #-8]
    // 0x627728: stp             lr, x16, [SP, #-0x10]!
    // 0x62772c: r0 = addWithPaintTransform()
    //     0x62772c: bl              #0x622f04  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithPaintTransform
    // 0x627730: add             SP, SP, #0x20
    // 0x627734: LeaveFrame
    //     0x627734: mov             SP, fp
    //     0x627738: ldp             fp, lr, [SP], #0x10
    // 0x62773c: ret
    //     0x62773c: ret             
    // 0x627740: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x627740: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x627744: b               #0x6276c0
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x62fa34, size: 0x18
    // 0x62fa34: r4 = 0
    //     0x62fa34: mov             x4, #0
    // 0x62fa38: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x62fa38: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b1f8] AnonymousClosure: (0x62fa4c), in [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::computeMaxIntrinsicHeight (0x62fa98)
    //     0x62fa3c: ldr             x1, [x17, #0x1f8]
    // 0x62fa40: r24 = BuildNonGenericMethodExtractorStub
    //     0x62fa40: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x62fa44: LoadField: r0 = r24->field_17
    //     0x62fa44: ldur            x0, [x24, #0x17]
    // 0x62fa48: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x62fa4c, size: 0x4c
    // 0x62fa4c: EnterFrame
    //     0x62fa4c: stp             fp, lr, [SP, #-0x10]!
    //     0x62fa50: mov             fp, SP
    // 0x62fa54: ldr             x0, [fp, #0x18]
    // 0x62fa58: LoadField: r1 = r0->field_17
    //     0x62fa58: ldur            w1, [x0, #0x17]
    // 0x62fa5c: DecompressPointer r1
    //     0x62fa5c: add             x1, x1, HEAP, lsl #32
    // 0x62fa60: CheckStackOverflow
    //     0x62fa60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62fa64: cmp             SP, x16
    //     0x62fa68: b.ls            #0x62fa90
    // 0x62fa6c: LoadField: r0 = r1->field_f
    //     0x62fa6c: ldur            w0, [x1, #0xf]
    // 0x62fa70: DecompressPointer r0
    //     0x62fa70: add             x0, x0, HEAP, lsl #32
    // 0x62fa74: ldr             x16, [fp, #0x10]
    // 0x62fa78: stp             x16, x0, [SP, #-0x10]!
    // 0x62fa7c: r0 = computeMaxIntrinsicHeight()
    //     0x62fa7c: bl              #0x62fa98  ; [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::computeMaxIntrinsicHeight
    // 0x62fa80: add             SP, SP, #0x10
    // 0x62fa84: LeaveFrame
    //     0x62fa84: mov             SP, fp
    //     0x62fa88: ldp             fp, lr, [SP], #0x10
    // 0x62fa8c: ret
    //     0x62fa8c: ret             
    // 0x62fa90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62fa90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62fa94: b               #0x62fa6c
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0x62fa98, size: 0xf8
    // 0x62fa98: EnterFrame
    //     0x62fa98: stp             fp, lr, [SP, #-0x10]!
    //     0x62fa9c: mov             fp, SP
    // 0x62faa0: CheckStackOverflow
    //     0x62faa0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62faa4: cmp             SP, x16
    //     0x62faa8: b.ls            #0x62fb70
    // 0x62faac: ldr             x0, [fp, #0x18]
    // 0x62fab0: LoadField: r1 = r0->field_5f
    //     0x62fab0: ldur            w1, [x0, #0x5f]
    // 0x62fab4: DecompressPointer r1
    //     0x62fab4: add             x1, x1, HEAP, lsl #32
    // 0x62fab8: cmp             w1, NULL
    // 0x62fabc: b.ne            #0x62fad0
    // 0x62fac0: r0 = 0.000000
    //     0x62fac0: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x62fac4: LeaveFrame
    //     0x62fac4: mov             SP, fp
    //     0x62fac8: ldp             fp, lr, [SP], #0x10
    // 0x62facc: ret
    //     0x62facc: ret             
    // 0x62fad0: SaveReg r0
    //     0x62fad0: str             x0, [SP, #-8]!
    // 0x62fad4: r0 = _isVertical()
    //     0x62fad4: bl              #0x62fb90  ; [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::_isVertical
    // 0x62fad8: add             SP, SP, #8
    // 0x62fadc: tbnz            w0, #4, #0x62fb10
    // 0x62fae0: ldr             x0, [fp, #0x18]
    // 0x62fae4: ldr             x1, [fp, #0x10]
    // 0x62fae8: LoadField: r2 = r0->field_5f
    //     0x62fae8: ldur            w2, [x0, #0x5f]
    // 0x62faec: DecompressPointer r2
    //     0x62faec: add             x2, x2, HEAP, lsl #32
    // 0x62faf0: cmp             w2, NULL
    // 0x62faf4: b.eq            #0x62fb78
    // 0x62faf8: LoadField: d0 = r1->field_7
    //     0x62faf8: ldur            d0, [x1, #7]
    // 0x62fafc: SaveReg r2
    //     0x62fafc: str             x2, [SP, #-8]!
    // 0x62fb00: SaveReg d0
    //     0x62fb00: str             d0, [SP, #-8]!
    // 0x62fb04: r0 = getMaxIntrinsicWidth()
    //     0x62fb04: bl              #0x62cb94  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0x62fb08: add             SP, SP, #0x10
    // 0x62fb0c: b               #0x62fb3c
    // 0x62fb10: ldr             x0, [fp, #0x18]
    // 0x62fb14: ldr             x1, [fp, #0x10]
    // 0x62fb18: LoadField: r2 = r0->field_5f
    //     0x62fb18: ldur            w2, [x0, #0x5f]
    // 0x62fb1c: DecompressPointer r2
    //     0x62fb1c: add             x2, x2, HEAP, lsl #32
    // 0x62fb20: cmp             w2, NULL
    // 0x62fb24: b.eq            #0x62fb7c
    // 0x62fb28: LoadField: d0 = r1->field_7
    //     0x62fb28: ldur            d0, [x1, #7]
    // 0x62fb2c: SaveReg r2
    //     0x62fb2c: str             x2, [SP, #-8]!
    // 0x62fb30: SaveReg d0
    //     0x62fb30: str             d0, [SP, #-8]!
    // 0x62fb34: r0 = getMaxIntrinsicHeight()
    //     0x62fb34: bl              #0x62cb24  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0x62fb38: add             SP, SP, #0x10
    // 0x62fb3c: r0 = inline_Allocate_Double()
    //     0x62fb3c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62fb40: add             x0, x0, #0x10
    //     0x62fb44: cmp             x1, x0
    //     0x62fb48: b.ls            #0x62fb80
    //     0x62fb4c: str             x0, [THR, #0x60]  ; THR::top
    //     0x62fb50: sub             x0, x0, #0xf
    //     0x62fb54: mov             x1, #0xd108
    //     0x62fb58: movk            x1, #3, lsl #16
    //     0x62fb5c: stur            x1, [x0, #-1]
    // 0x62fb60: StoreField: r0->field_7 = d0
    //     0x62fb60: stur            d0, [x0, #7]
    // 0x62fb64: LeaveFrame
    //     0x62fb64: mov             SP, fp
    //     0x62fb68: ldp             fp, lr, [SP], #0x10
    // 0x62fb6c: ret
    //     0x62fb6c: ret             
    // 0x62fb70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62fb70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62fb74: b               #0x62faac
    // 0x62fb78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x62fb78: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x62fb7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x62fb7c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x62fb80: SaveReg d0
    //     0x62fb80: str             q0, [SP, #-0x10]!
    // 0x62fb84: r0 = AllocateDouble()
    //     0x62fb84: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62fb88: RestoreReg d0
    //     0x62fb88: ldr             q0, [SP], #0x10
    // 0x62fb8c: b               #0x62fb60
  }
  get _ _isVertical(/* No info */) {
    // ** addr: 0x62fb90, size: 0x2c
    // 0x62fb90: r1 = 1
    //     0x62fb90: mov             x1, #1
    // 0x62fb94: ldr             x2, [SP]
    // 0x62fb98: LoadField: r3 = r2->field_63
    //     0x62fb98: ldur            x3, [x2, #0x63]
    // 0x62fb9c: ubfx            x3, x3, #0, #0x20
    // 0x62fba0: and             x2, x3, x1
    // 0x62fba4: ubfx            x2, x2, #0, #0x20
    // 0x62fba8: cbnz            x2, #0x62fbb4
    // 0x62fbac: r0 = false
    //     0x62fbac: add             x0, NULL, #0x30  ; false
    // 0x62fbb0: b               #0x62fbb8
    // 0x62fbb4: r0 = true
    //     0x62fbb4: add             x0, NULL, #0x20  ; true
    // 0x62fbb8: ret
    //     0x62fbb8: ret             
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x636324, size: 0x18
    // 0x636324: r4 = 0
    //     0x636324: mov             x4, #0
    // 0x636328: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x636328: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b200] AnonymousClosure: (0x63633c), in [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::computeMaxIntrinsicWidth (0x636388)
    //     0x63632c: ldr             x1, [x17, #0x200]
    // 0x636330: r24 = BuildNonGenericMethodExtractorStub
    //     0x636330: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x636334: LoadField: r0 = r24->field_17
    //     0x636334: ldur            x0, [x24, #0x17]
    // 0x636338: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63633c, size: 0x4c
    // 0x63633c: EnterFrame
    //     0x63633c: stp             fp, lr, [SP, #-0x10]!
    //     0x636340: mov             fp, SP
    // 0x636344: ldr             x0, [fp, #0x18]
    // 0x636348: LoadField: r1 = r0->field_17
    //     0x636348: ldur            w1, [x0, #0x17]
    // 0x63634c: DecompressPointer r1
    //     0x63634c: add             x1, x1, HEAP, lsl #32
    // 0x636350: CheckStackOverflow
    //     0x636350: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x636354: cmp             SP, x16
    //     0x636358: b.ls            #0x636380
    // 0x63635c: LoadField: r0 = r1->field_f
    //     0x63635c: ldur            w0, [x1, #0xf]
    // 0x636360: DecompressPointer r0
    //     0x636360: add             x0, x0, HEAP, lsl #32
    // 0x636364: ldr             x16, [fp, #0x10]
    // 0x636368: stp             x16, x0, [SP, #-0x10]!
    // 0x63636c: r0 = computeMaxIntrinsicWidth()
    //     0x63636c: bl              #0x636388  ; [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::computeMaxIntrinsicWidth
    // 0x636370: add             SP, SP, #0x10
    // 0x636374: LeaveFrame
    //     0x636374: mov             SP, fp
    //     0x636378: ldp             fp, lr, [SP], #0x10
    // 0x63637c: ret
    //     0x63637c: ret             
    // 0x636380: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x636380: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x636384: b               #0x63635c
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0x636388, size: 0xd0
    // 0x636388: EnterFrame
    //     0x636388: stp             fp, lr, [SP, #-0x10]!
    //     0x63638c: mov             fp, SP
    // 0x636390: CheckStackOverflow
    //     0x636390: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x636394: cmp             SP, x16
    //     0x636398: b.ls            #0x636440
    // 0x63639c: ldr             x0, [fp, #0x18]
    // 0x6363a0: LoadField: r1 = r0->field_5f
    //     0x6363a0: ldur            w1, [x0, #0x5f]
    // 0x6363a4: DecompressPointer r1
    //     0x6363a4: add             x1, x1, HEAP, lsl #32
    // 0x6363a8: cmp             w1, NULL
    // 0x6363ac: b.ne            #0x6363c0
    // 0x6363b0: r0 = 0.000000
    //     0x6363b0: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x6363b4: LeaveFrame
    //     0x6363b4: mov             SP, fp
    //     0x6363b8: ldp             fp, lr, [SP], #0x10
    // 0x6363bc: ret
    //     0x6363bc: ret             
    // 0x6363c0: r2 = 1
    //     0x6363c0: mov             x2, #1
    // 0x6363c4: LoadField: r3 = r0->field_63
    //     0x6363c4: ldur            x3, [x0, #0x63]
    // 0x6363c8: ubfx            x3, x3, #0, #0x20
    // 0x6363cc: and             x0, x3, x2
    // 0x6363d0: ubfx            x0, x0, #0, #0x20
    // 0x6363d4: cbz             x0, #0x6363f4
    // 0x6363d8: ldr             x0, [fp, #0x10]
    // 0x6363dc: LoadField: d0 = r0->field_7
    //     0x6363dc: ldur            d0, [x0, #7]
    // 0x6363e0: SaveReg r1
    //     0x6363e0: str             x1, [SP, #-8]!
    // 0x6363e4: SaveReg d0
    //     0x6363e4: str             d0, [SP, #-8]!
    // 0x6363e8: r0 = getMaxIntrinsicHeight()
    //     0x6363e8: bl              #0x62cb24  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0x6363ec: add             SP, SP, #0x10
    // 0x6363f0: b               #0x63640c
    // 0x6363f4: ldr             x0, [fp, #0x10]
    // 0x6363f8: LoadField: d0 = r0->field_7
    //     0x6363f8: ldur            d0, [x0, #7]
    // 0x6363fc: SaveReg r1
    //     0x6363fc: str             x1, [SP, #-8]!
    // 0x636400: SaveReg d0
    //     0x636400: str             d0, [SP, #-8]!
    // 0x636404: r0 = getMaxIntrinsicWidth()
    //     0x636404: bl              #0x62cb94  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0x636408: add             SP, SP, #0x10
    // 0x63640c: r0 = inline_Allocate_Double()
    //     0x63640c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x636410: add             x0, x0, #0x10
    //     0x636414: cmp             x1, x0
    //     0x636418: b.ls            #0x636448
    //     0x63641c: str             x0, [THR, #0x60]  ; THR::top
    //     0x636420: sub             x0, x0, #0xf
    //     0x636424: mov             x1, #0xd108
    //     0x636428: movk            x1, #3, lsl #16
    //     0x63642c: stur            x1, [x0, #-1]
    // 0x636430: StoreField: r0->field_7 = d0
    //     0x636430: stur            d0, [x0, #7]
    // 0x636434: LeaveFrame
    //     0x636434: mov             SP, fp
    //     0x636438: ldp             fp, lr, [SP], #0x10
    // 0x63643c: ret
    //     0x63643c: ret             
    // 0x636440: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x636440: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x636444: b               #0x63639c
    // 0x636448: SaveReg d0
    //     0x636448: str             q0, [SP, #-0x10]!
    // 0x63644c: r0 = AllocateDouble()
    //     0x63644c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x636450: RestoreReg d0
    //     0x636450: ldr             q0, [SP], #0x10
    // 0x636454: b               #0x636430
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x6393b8, size: 0x18
    // 0x6393b8: r4 = 0
    //     0x6393b8: mov             x4, #0
    // 0x6393bc: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x6393bc: add             x17, PP, #0x52, lsl #12  ; [pp+0x52e80] AnonymousClosure: (0x6393d0), in [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::computeMinIntrinsicHeight (0x63941c)
    //     0x6393c0: ldr             x1, [x17, #0xe80]
    // 0x6393c4: r24 = BuildNonGenericMethodExtractorStub
    //     0x6393c4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x6393c8: LoadField: r0 = r24->field_17
    //     0x6393c8: ldur            x0, [x24, #0x17]
    // 0x6393cc: br              x0
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x6393d0, size: 0x4c
    // 0x6393d0: EnterFrame
    //     0x6393d0: stp             fp, lr, [SP, #-0x10]!
    //     0x6393d4: mov             fp, SP
    // 0x6393d8: ldr             x0, [fp, #0x18]
    // 0x6393dc: LoadField: r1 = r0->field_17
    //     0x6393dc: ldur            w1, [x0, #0x17]
    // 0x6393e0: DecompressPointer r1
    //     0x6393e0: add             x1, x1, HEAP, lsl #32
    // 0x6393e4: CheckStackOverflow
    //     0x6393e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6393e8: cmp             SP, x16
    //     0x6393ec: b.ls            #0x639414
    // 0x6393f0: LoadField: r0 = r1->field_f
    //     0x6393f0: ldur            w0, [x1, #0xf]
    // 0x6393f4: DecompressPointer r0
    //     0x6393f4: add             x0, x0, HEAP, lsl #32
    // 0x6393f8: ldr             x16, [fp, #0x10]
    // 0x6393fc: stp             x16, x0, [SP, #-0x10]!
    // 0x639400: r0 = computeMinIntrinsicHeight()
    //     0x639400: bl              #0x63941c  ; [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::computeMinIntrinsicHeight
    // 0x639404: add             SP, SP, #0x10
    // 0x639408: LeaveFrame
    //     0x639408: mov             SP, fp
    //     0x63940c: ldp             fp, lr, [SP], #0x10
    // 0x639410: ret
    //     0x639410: ret             
    // 0x639414: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x639414: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x639418: b               #0x6393f0
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0x63941c, size: 0xd0
    // 0x63941c: EnterFrame
    //     0x63941c: stp             fp, lr, [SP, #-0x10]!
    //     0x639420: mov             fp, SP
    // 0x639424: CheckStackOverflow
    //     0x639424: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x639428: cmp             SP, x16
    //     0x63942c: b.ls            #0x6394d4
    // 0x639430: ldr             x0, [fp, #0x18]
    // 0x639434: LoadField: r1 = r0->field_5f
    //     0x639434: ldur            w1, [x0, #0x5f]
    // 0x639438: DecompressPointer r1
    //     0x639438: add             x1, x1, HEAP, lsl #32
    // 0x63943c: cmp             w1, NULL
    // 0x639440: b.ne            #0x639454
    // 0x639444: r0 = 0.000000
    //     0x639444: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x639448: LeaveFrame
    //     0x639448: mov             SP, fp
    //     0x63944c: ldp             fp, lr, [SP], #0x10
    // 0x639450: ret
    //     0x639450: ret             
    // 0x639454: r2 = 1
    //     0x639454: mov             x2, #1
    // 0x639458: LoadField: r3 = r0->field_63
    //     0x639458: ldur            x3, [x0, #0x63]
    // 0x63945c: ubfx            x3, x3, #0, #0x20
    // 0x639460: and             x0, x3, x2
    // 0x639464: ubfx            x0, x0, #0, #0x20
    // 0x639468: cbz             x0, #0x639488
    // 0x63946c: ldr             x0, [fp, #0x10]
    // 0x639470: LoadField: d0 = r0->field_7
    //     0x639470: ldur            d0, [x0, #7]
    // 0x639474: SaveReg r1
    //     0x639474: str             x1, [SP, #-8]!
    // 0x639478: SaveReg d0
    //     0x639478: str             d0, [SP, #-8]!
    // 0x63947c: r0 = getMinIntrinsicWidth()
    //     0x63947c: bl              #0x630b18  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicWidth
    // 0x639480: add             SP, SP, #0x10
    // 0x639484: b               #0x6394a0
    // 0x639488: ldr             x0, [fp, #0x10]
    // 0x63948c: LoadField: d0 = r0->field_7
    //     0x63948c: ldur            d0, [x0, #7]
    // 0x639490: SaveReg r1
    //     0x639490: str             x1, [SP, #-8]!
    // 0x639494: SaveReg d0
    //     0x639494: str             d0, [SP, #-8]!
    // 0x639498: r0 = getMinIntrinsicHeight()
    //     0x639498: bl              #0x630a58  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0x63949c: add             SP, SP, #0x10
    // 0x6394a0: r0 = inline_Allocate_Double()
    //     0x6394a0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6394a4: add             x0, x0, #0x10
    //     0x6394a8: cmp             x1, x0
    //     0x6394ac: b.ls            #0x6394dc
    //     0x6394b0: str             x0, [THR, #0x60]  ; THR::top
    //     0x6394b4: sub             x0, x0, #0xf
    //     0x6394b8: mov             x1, #0xd108
    //     0x6394bc: movk            x1, #3, lsl #16
    //     0x6394c0: stur            x1, [x0, #-1]
    // 0x6394c4: StoreField: r0->field_7 = d0
    //     0x6394c4: stur            d0, [x0, #7]
    // 0x6394c8: LeaveFrame
    //     0x6394c8: mov             SP, fp
    //     0x6394cc: ldp             fp, lr, [SP], #0x10
    // 0x6394d0: ret
    //     0x6394d0: ret             
    // 0x6394d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6394d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6394d8: b               #0x639430
    // 0x6394dc: SaveReg d0
    //     0x6394dc: str             q0, [SP, #-0x10]!
    // 0x6394e0: r0 = AllocateDouble()
    //     0x6394e0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6394e4: RestoreReg d0
    //     0x6394e4: ldr             q0, [SP], #0x10
    // 0x6394e8: b               #0x6394c4
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63c064, size: 0x18
    // 0x63c064: r4 = 0
    //     0x63c064: mov             x4, #0
    // 0x63c068: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63c068: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fcf0] AnonymousClosure: (0x63c07c), in [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::computeMinIntrinsicWidth (0x63c0c8)
    //     0x63c06c: ldr             x1, [x17, #0xcf0]
    // 0x63c070: r24 = BuildNonGenericMethodExtractorStub
    //     0x63c070: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63c074: LoadField: r0 = r24->field_17
    //     0x63c074: ldur            x0, [x24, #0x17]
    // 0x63c078: br              x0
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63c07c, size: 0x4c
    // 0x63c07c: EnterFrame
    //     0x63c07c: stp             fp, lr, [SP, #-0x10]!
    //     0x63c080: mov             fp, SP
    // 0x63c084: ldr             x0, [fp, #0x18]
    // 0x63c088: LoadField: r1 = r0->field_17
    //     0x63c088: ldur            w1, [x0, #0x17]
    // 0x63c08c: DecompressPointer r1
    //     0x63c08c: add             x1, x1, HEAP, lsl #32
    // 0x63c090: CheckStackOverflow
    //     0x63c090: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63c094: cmp             SP, x16
    //     0x63c098: b.ls            #0x63c0c0
    // 0x63c09c: LoadField: r0 = r1->field_f
    //     0x63c09c: ldur            w0, [x1, #0xf]
    // 0x63c0a0: DecompressPointer r0
    //     0x63c0a0: add             x0, x0, HEAP, lsl #32
    // 0x63c0a4: ldr             x16, [fp, #0x10]
    // 0x63c0a8: stp             x16, x0, [SP, #-0x10]!
    // 0x63c0ac: r0 = computeMinIntrinsicWidth()
    //     0x63c0ac: bl              #0x63c0c8  ; [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::computeMinIntrinsicWidth
    // 0x63c0b0: add             SP, SP, #0x10
    // 0x63c0b4: LeaveFrame
    //     0x63c0b4: mov             SP, fp
    //     0x63c0b8: ldp             fp, lr, [SP], #0x10
    // 0x63c0bc: ret
    //     0x63c0bc: ret             
    // 0x63c0c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63c0c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63c0c4: b               #0x63c09c
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0x63c0c8, size: 0xd0
    // 0x63c0c8: EnterFrame
    //     0x63c0c8: stp             fp, lr, [SP, #-0x10]!
    //     0x63c0cc: mov             fp, SP
    // 0x63c0d0: CheckStackOverflow
    //     0x63c0d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63c0d4: cmp             SP, x16
    //     0x63c0d8: b.ls            #0x63c180
    // 0x63c0dc: ldr             x0, [fp, #0x18]
    // 0x63c0e0: LoadField: r1 = r0->field_5f
    //     0x63c0e0: ldur            w1, [x0, #0x5f]
    // 0x63c0e4: DecompressPointer r1
    //     0x63c0e4: add             x1, x1, HEAP, lsl #32
    // 0x63c0e8: cmp             w1, NULL
    // 0x63c0ec: b.ne            #0x63c100
    // 0x63c0f0: r0 = 0.000000
    //     0x63c0f0: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x63c0f4: LeaveFrame
    //     0x63c0f4: mov             SP, fp
    //     0x63c0f8: ldp             fp, lr, [SP], #0x10
    // 0x63c0fc: ret
    //     0x63c0fc: ret             
    // 0x63c100: r2 = 1
    //     0x63c100: mov             x2, #1
    // 0x63c104: LoadField: r3 = r0->field_63
    //     0x63c104: ldur            x3, [x0, #0x63]
    // 0x63c108: ubfx            x3, x3, #0, #0x20
    // 0x63c10c: and             x0, x3, x2
    // 0x63c110: ubfx            x0, x0, #0, #0x20
    // 0x63c114: cbz             x0, #0x63c134
    // 0x63c118: ldr             x0, [fp, #0x10]
    // 0x63c11c: LoadField: d0 = r0->field_7
    //     0x63c11c: ldur            d0, [x0, #7]
    // 0x63c120: SaveReg r1
    //     0x63c120: str             x1, [SP, #-8]!
    // 0x63c124: SaveReg d0
    //     0x63c124: str             d0, [SP, #-8]!
    // 0x63c128: r0 = getMinIntrinsicHeight()
    //     0x63c128: bl              #0x630a58  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0x63c12c: add             SP, SP, #0x10
    // 0x63c130: b               #0x63c14c
    // 0x63c134: ldr             x0, [fp, #0x10]
    // 0x63c138: LoadField: d0 = r0->field_7
    //     0x63c138: ldur            d0, [x0, #7]
    // 0x63c13c: SaveReg r1
    //     0x63c13c: str             x1, [SP, #-8]!
    // 0x63c140: SaveReg d0
    //     0x63c140: str             d0, [SP, #-8]!
    // 0x63c144: r0 = getMinIntrinsicWidth()
    //     0x63c144: bl              #0x630b18  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicWidth
    // 0x63c148: add             SP, SP, #0x10
    // 0x63c14c: r0 = inline_Allocate_Double()
    //     0x63c14c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63c150: add             x0, x0, #0x10
    //     0x63c154: cmp             x1, x0
    //     0x63c158: b.ls            #0x63c188
    //     0x63c15c: str             x0, [THR, #0x60]  ; THR::top
    //     0x63c160: sub             x0, x0, #0xf
    //     0x63c164: mov             x1, #0xd108
    //     0x63c168: movk            x1, #3, lsl #16
    //     0x63c16c: stur            x1, [x0, #-1]
    // 0x63c170: StoreField: r0->field_7 = d0
    //     0x63c170: stur            d0, [x0, #7]
    // 0x63c174: LeaveFrame
    //     0x63c174: mov             SP, fp
    //     0x63c178: ldp             fp, lr, [SP], #0x10
    // 0x63c17c: ret
    //     0x63c17c: ret             
    // 0x63c180: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63c180: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63c184: b               #0x63c0dc
    // 0x63c188: SaveReg d0
    //     0x63c188: str             q0, [SP, #-0x10]!
    // 0x63c18c: r0 = AllocateDouble()
    //     0x63c18c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63c190: RestoreReg d0
    //     0x63c190: ldr             q0, [SP], #0x10
    // 0x63c194: b               #0x63c170
  }
  _ paint(/* No info */) {
    // ** addr: 0x669c18, size: 0x114
    // 0x669c18: EnterFrame
    //     0x669c18: stp             fp, lr, [SP, #-0x10]!
    //     0x669c1c: mov             fp, SP
    // 0x669c20: AllocStack(0x20)
    //     0x669c20: sub             SP, SP, #0x20
    // 0x669c24: CheckStackOverflow
    //     0x669c24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x669c28: cmp             SP, x16
    //     0x669c2c: b.ls            #0x669d18
    // 0x669c30: ldr             x0, [fp, #0x20]
    // 0x669c34: LoadField: r1 = r0->field_5f
    //     0x669c34: ldur            w1, [x0, #0x5f]
    // 0x669c38: DecompressPointer r1
    //     0x669c38: add             x1, x1, HEAP, lsl #32
    // 0x669c3c: cmp             w1, NULL
    // 0x669c40: b.eq            #0x669cf4
    // 0x669c44: LoadField: r1 = r0->field_6f
    //     0x669c44: ldur            w1, [x0, #0x6f]
    // 0x669c48: DecompressPointer r1
    //     0x669c48: add             x1, x1, HEAP, lsl #32
    // 0x669c4c: stur            x1, [fp, #-0x18]
    // 0x669c50: LoadField: r2 = r0->field_37
    //     0x669c50: ldur            w2, [x0, #0x37]
    // 0x669c54: DecompressPointer r2
    //     0x669c54: add             x2, x2, HEAP, lsl #32
    // 0x669c58: r16 = Sentinel
    //     0x669c58: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x669c5c: cmp             w2, w16
    // 0x669c60: b.eq            #0x669d20
    // 0x669c64: stur            x2, [fp, #-0x10]
    // 0x669c68: LoadField: r3 = r0->field_6b
    //     0x669c68: ldur            w3, [x0, #0x6b]
    // 0x669c6c: DecompressPointer r3
    //     0x669c6c: add             x3, x3, HEAP, lsl #32
    // 0x669c70: stur            x3, [fp, #-8]
    // 0x669c74: cmp             w3, NULL
    // 0x669c78: b.eq            #0x669d28
    // 0x669c7c: r1 = 1
    //     0x669c7c: mov             x1, #1
    // 0x669c80: r0 = AllocateContext()
    //     0x669c80: bl              #0xd68aa4  ; AllocateContextStub
    // 0x669c84: mov             x1, x0
    // 0x669c88: ldr             x0, [fp, #0x20]
    // 0x669c8c: StoreField: r1->field_f = r0
    //     0x669c8c: stur            w0, [x1, #0xf]
    // 0x669c90: ldur            x0, [fp, #-0x18]
    // 0x669c94: LoadField: r3 = r0->field_b
    //     0x669c94: ldur            w3, [x0, #0xb]
    // 0x669c98: DecompressPointer r3
    //     0x669c98: add             x3, x3, HEAP, lsl #32
    // 0x669c9c: mov             x2, x1
    // 0x669ca0: stur            x3, [fp, #-0x20]
    // 0x669ca4: r1 = Function '_paintChild@909134774':.
    //     0x669ca4: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b218] AnonymousClosure: (0x669d2c), in [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::_paintChild (0x669d80)
    //     0x669ca8: ldr             x1, [x1, #0x218]
    // 0x669cac: r0 = AllocateClosure()
    //     0x669cac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x669cb0: ldr             x16, [fp, #0x18]
    // 0x669cb4: ldur            lr, [fp, #-0x10]
    // 0x669cb8: stp             lr, x16, [SP, #-0x10]!
    // 0x669cbc: ldr             x16, [fp, #0x10]
    // 0x669cc0: ldur            lr, [fp, #-8]
    // 0x669cc4: stp             lr, x16, [SP, #-0x10]!
    // 0x669cc8: ldur            x16, [fp, #-0x20]
    // 0x669ccc: stp             x16, x0, [SP, #-0x10]!
    // 0x669cd0: r4 = const [0, 0x6, 0x6, 0x5, oldLayer, 0x5, null]
    //     0x669cd0: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1cef8] List(7) [0, 0x6, 0x6, 0x5, "oldLayer", 0x5, Null]
    //     0x669cd4: ldr             x4, [x4, #0xef8]
    // 0x669cd8: r0 = pushTransform()
    //     0x669cd8: bl              #0x65d108  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushTransform
    // 0x669cdc: add             SP, SP, #0x30
    // 0x669ce0: ldur            x16, [fp, #-0x18]
    // 0x669ce4: stp             x0, x16, [SP, #-0x10]!
    // 0x669ce8: r0 = layer=()
    //     0x669ce8: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x669cec: add             SP, SP, #0x10
    // 0x669cf0: b               #0x669d08
    // 0x669cf4: LoadField: r1 = r0->field_6f
    //     0x669cf4: ldur            w1, [x0, #0x6f]
    // 0x669cf8: DecompressPointer r1
    //     0x669cf8: add             x1, x1, HEAP, lsl #32
    // 0x669cfc: stp             NULL, x1, [SP, #-0x10]!
    // 0x669d00: r0 = layer=()
    //     0x669d00: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x669d04: add             SP, SP, #0x10
    // 0x669d08: r0 = Null
    //     0x669d08: mov             x0, NULL
    // 0x669d0c: LeaveFrame
    //     0x669d0c: mov             SP, fp
    //     0x669d10: ldp             fp, lr, [SP], #0x10
    // 0x669d14: ret
    //     0x669d14: ret             
    // 0x669d18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x669d18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x669d1c: b               #0x669c30
    // 0x669d20: r9 = _needsCompositing
    //     0x669d20: ldr             x9, [PP, #0x4b28]  ; [pp+0x4b28] Field <RenderObject._needsCompositing@904266271>: late (offset: 0x38)
    // 0x669d24: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x669d24: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x669d28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x669d28: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _paintChild(dynamic, PaintingContext, Offset) {
    // ** addr: 0x669d2c, size: 0x54
    // 0x669d2c: EnterFrame
    //     0x669d2c: stp             fp, lr, [SP, #-0x10]!
    //     0x669d30: mov             fp, SP
    // 0x669d34: ldr             x0, [fp, #0x20]
    // 0x669d38: LoadField: r1 = r0->field_17
    //     0x669d38: ldur            w1, [x0, #0x17]
    // 0x669d3c: DecompressPointer r1
    //     0x669d3c: add             x1, x1, HEAP, lsl #32
    // 0x669d40: CheckStackOverflow
    //     0x669d40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x669d44: cmp             SP, x16
    //     0x669d48: b.ls            #0x669d78
    // 0x669d4c: LoadField: r0 = r1->field_f
    //     0x669d4c: ldur            w0, [x1, #0xf]
    // 0x669d50: DecompressPointer r0
    //     0x669d50: add             x0, x0, HEAP, lsl #32
    // 0x669d54: ldr             x16, [fp, #0x18]
    // 0x669d58: stp             x16, x0, [SP, #-0x10]!
    // 0x669d5c: ldr             x16, [fp, #0x10]
    // 0x669d60: SaveReg r16
    //     0x669d60: str             x16, [SP, #-8]!
    // 0x669d64: r0 = _paintChild()
    //     0x669d64: bl              #0x669d80  ; [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::_paintChild
    // 0x669d68: add             SP, SP, #0x18
    // 0x669d6c: LeaveFrame
    //     0x669d6c: mov             SP, fp
    //     0x669d70: ldp             fp, lr, [SP], #0x10
    // 0x669d74: ret
    //     0x669d74: ret             
    // 0x669d78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x669d78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x669d7c: b               #0x669d4c
  }
  _ _paintChild(/* No info */) {
    // ** addr: 0x669d80, size: 0x5c
    // 0x669d80: EnterFrame
    //     0x669d80: stp             fp, lr, [SP, #-0x10]!
    //     0x669d84: mov             fp, SP
    // 0x669d88: CheckStackOverflow
    //     0x669d88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x669d8c: cmp             SP, x16
    //     0x669d90: b.ls            #0x669dd0
    // 0x669d94: ldr             x0, [fp, #0x20]
    // 0x669d98: LoadField: r1 = r0->field_5f
    //     0x669d98: ldur            w1, [x0, #0x5f]
    // 0x669d9c: DecompressPointer r1
    //     0x669d9c: add             x1, x1, HEAP, lsl #32
    // 0x669da0: cmp             w1, NULL
    // 0x669da4: b.eq            #0x669dd8
    // 0x669da8: ldr             x16, [fp, #0x18]
    // 0x669dac: stp             x1, x16, [SP, #-0x10]!
    // 0x669db0: ldr             x16, [fp, #0x10]
    // 0x669db4: SaveReg r16
    //     0x669db4: str             x16, [SP, #-8]!
    // 0x669db8: r0 = paintChild()
    //     0x669db8: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x669dbc: add             SP, SP, #0x18
    // 0x669dc0: r0 = Null
    //     0x669dc0: mov             x0, NULL
    // 0x669dc4: LeaveFrame
    //     0x669dc4: mov             SP, fp
    //     0x669dc8: ldp             fp, lr, [SP], #0x10
    // 0x669dcc: ret
    //     0x669dcc: ret             
    // 0x669dd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x669dd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x669dd4: b               #0x669d94
    // 0x669dd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x669dd8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x69353c, size: 0x4a8
    // 0x69353c: EnterFrame
    //     0x69353c: stp             fp, lr, [SP, #-0x10]!
    //     0x693540: mov             fp, SP
    // 0x693544: AllocStack(0x20)
    //     0x693544: sub             SP, SP, #0x20
    // 0x693548: CheckStackOverflow
    //     0x693548: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x69354c: cmp             SP, x16
    //     0x693550: b.ls            #0x693980
    // 0x693554: ldr             x3, [fp, #0x10]
    // 0x693558: StoreField: r3->field_6b = rNULL
    //     0x693558: stur            NULL, [x3, #0x6b]
    // 0x69355c: LoadField: r4 = r3->field_5f
    //     0x69355c: ldur            w4, [x3, #0x5f]
    // 0x693560: DecompressPointer r4
    //     0x693560: add             x4, x4, HEAP, lsl #32
    // 0x693564: stur            x4, [fp, #-0x10]
    // 0x693568: cmp             w4, NULL
    // 0x69356c: b.eq            #0x693890
    // 0x693570: r5 = 1
    //     0x693570: mov             x5, #1
    // 0x693574: LoadField: r0 = r3->field_63
    //     0x693574: ldur            x0, [x3, #0x63]
    // 0x693578: ubfx            x0, x0, #0, #0x20
    // 0x69357c: and             x1, x0, x5
    // 0x693580: ubfx            x1, x1, #0, #0x20
    // 0x693584: cbz             x1, #0x6935e8
    // 0x693588: LoadField: r6 = r3->field_27
    //     0x693588: ldur            w6, [x3, #0x27]
    // 0x69358c: DecompressPointer r6
    //     0x69358c: add             x6, x6, HEAP, lsl #32
    // 0x693590: stur            x6, [fp, #-8]
    // 0x693594: cmp             w6, NULL
    // 0x693598: b.eq            #0x693920
    // 0x69359c: mov             x0, x6
    // 0x6935a0: r2 = Null
    //     0x6935a0: mov             x2, NULL
    // 0x6935a4: r1 = Null
    //     0x6935a4: mov             x1, NULL
    // 0x6935a8: r4 = LoadClassIdInstr(r0)
    //     0x6935a8: ldur            x4, [x0, #-1]
    //     0x6935ac: ubfx            x4, x4, #0xc, #0x14
    // 0x6935b0: sub             x4, x4, #0x80d
    // 0x6935b4: cmp             x4, #1
    // 0x6935b8: b.ls            #0x6935d0
    // 0x6935bc: r8 = BoxConstraints
    //     0x6935bc: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x6935c0: ldr             x8, [x8, #0x1d0]
    // 0x6935c4: r3 = Null
    //     0x6935c4: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b228] Null
    //     0x6935c8: ldr             x3, [x3, #0x228]
    // 0x6935cc: r0 = BoxConstraints()
    //     0x6935cc: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x6935d0: ldur            x16, [fp, #-8]
    // 0x6935d4: SaveReg r16
    //     0x6935d4: str             x16, [SP, #-8]!
    // 0x6935d8: r0 = flipped()
    //     0x6935d8: bl              #0x693b9c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::flipped
    // 0x6935dc: add             SP, SP, #8
    // 0x6935e0: mov             x2, x0
    // 0x6935e4: b               #0x69363c
    // 0x6935e8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6935e8: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6935ec: ldr             x0, [x0, #0x1e8]
    // 0x6935f0: LoadField: r4 = r3->field_27
    //     0x6935f0: ldur            w4, [x3, #0x27]
    // 0x6935f4: DecompressPointer r4
    //     0x6935f4: add             x4, x4, HEAP, lsl #32
    // 0x6935f8: stur            x4, [fp, #-8]
    // 0x6935fc: cmp             w4, NULL
    // 0x693600: b.eq            #0x693940
    // 0x693604: mov             x0, x4
    // 0x693608: r2 = Null
    //     0x693608: mov             x2, NULL
    // 0x69360c: r1 = Null
    //     0x69360c: mov             x1, NULL
    // 0x693610: r4 = LoadClassIdInstr(r0)
    //     0x693610: ldur            x4, [x0, #-1]
    //     0x693614: ubfx            x4, x4, #0xc, #0x14
    // 0x693618: sub             x4, x4, #0x80d
    // 0x69361c: cmp             x4, #1
    // 0x693620: b.ls            #0x693638
    // 0x693624: r8 = BoxConstraints
    //     0x693624: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x693628: ldr             x8, [x8, #0x1d0]
    // 0x69362c: r3 = Null
    //     0x69362c: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b238] Null
    //     0x693630: ldr             x3, [x3, #0x238]
    // 0x693634: r0 = BoxConstraints()
    //     0x693634: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x693638: ldur            x2, [fp, #-8]
    // 0x69363c: ldr             x1, [fp, #0x10]
    // 0x693640: ldur            x0, [fp, #-0x10]
    // 0x693644: r3 = LoadClassIdInstr(r0)
    //     0x693644: ldur            x3, [x0, #-1]
    //     0x693648: ubfx            x3, x3, #0xc, #0x14
    // 0x69364c: stp             x2, x0, [SP, #-0x10]!
    // 0x693650: r16 = true
    //     0x693650: add             x16, NULL, #0x20  ; true
    // 0x693654: SaveReg r16
    //     0x693654: str             x16, [SP, #-8]!
    // 0x693658: mov             x0, x3
    // 0x69365c: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x69365c: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x693660: ldr             x4, [x4, #0x1c8]
    // 0x693664: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x693664: mov             x17, #0xcdfb
    //     0x693668: add             lr, x0, x17
    //     0x69366c: ldr             lr, [x21, lr, lsl #3]
    //     0x693670: blr             lr
    // 0x693674: add             SP, SP, #0x18
    // 0x693678: ldr             x0, [fp, #0x10]
    // 0x69367c: LoadField: r1 = r0->field_63
    //     0x69367c: ldur            x1, [x0, #0x63]
    // 0x693680: ubfx            x1, x1, #0, #0x20
    // 0x693684: r2 = 1
    //     0x693684: mov             x2, #1
    // 0x693688: and             x3, x1, x2
    // 0x69368c: ubfx            x3, x3, #0, #0x20
    // 0x693690: cbz             x3, #0x6936e0
    // 0x693694: LoadField: r1 = r0->field_5f
    //     0x693694: ldur            w1, [x0, #0x5f]
    // 0x693698: DecompressPointer r1
    //     0x693698: add             x1, x1, HEAP, lsl #32
    // 0x69369c: cmp             w1, NULL
    // 0x6936a0: b.eq            #0x693988
    // 0x6936a4: LoadField: r2 = r1->field_57
    //     0x6936a4: ldur            w2, [x1, #0x57]
    // 0x6936a8: DecompressPointer r2
    //     0x6936a8: add             x2, x2, HEAP, lsl #32
    // 0x6936ac: cmp             w2, NULL
    // 0x6936b0: b.eq            #0x69398c
    // 0x6936b4: LoadField: d0 = r2->field_f
    //     0x6936b4: ldur            d0, [x2, #0xf]
    // 0x6936b8: stur            d0, [fp, #-0x20]
    // 0x6936bc: LoadField: d1 = r2->field_7
    //     0x6936bc: ldur            d1, [x2, #7]
    // 0x6936c0: stur            d1, [fp, #-0x18]
    // 0x6936c4: r0 = Size()
    //     0x6936c4: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x6936c8: ldur            d0, [fp, #-0x20]
    // 0x6936cc: StoreField: r0->field_7 = d0
    //     0x6936cc: stur            d0, [x0, #7]
    // 0x6936d0: ldur            d0, [fp, #-0x18]
    // 0x6936d4: StoreField: r0->field_f = d0
    //     0x6936d4: stur            d0, [x0, #0xf]
    // 0x6936d8: ldr             x1, [fp, #0x10]
    // 0x6936dc: b               #0x693708
    // 0x6936e0: mov             x1, x0
    // 0x6936e4: LoadField: r0 = r1->field_5f
    //     0x6936e4: ldur            w0, [x1, #0x5f]
    // 0x6936e8: DecompressPointer r0
    //     0x6936e8: add             x0, x0, HEAP, lsl #32
    // 0x6936ec: cmp             w0, NULL
    // 0x6936f0: b.eq            #0x693990
    // 0x6936f4: LoadField: r2 = r0->field_57
    //     0x6936f4: ldur            w2, [x0, #0x57]
    // 0x6936f8: DecompressPointer r2
    //     0x6936f8: add             x2, x2, HEAP, lsl #32
    // 0x6936fc: cmp             w2, NULL
    // 0x693700: b.eq            #0x693994
    // 0x693704: mov             x0, x2
    // 0x693708: StoreField: r1->field_57 = r0
    //     0x693708: stur            w0, [x1, #0x57]
    //     0x69370c: ldurb           w16, [x1, #-1]
    //     0x693710: ldurb           w17, [x0, #-1]
    //     0x693714: and             x16, x17, x16, lsr #2
    //     0x693718: tst             x16, HEAP, lsr #32
    //     0x69371c: b.eq            #0x693724
    //     0x693720: bl              #0xd6826c
    // 0x693724: r0 = Matrix4()
    //     0x693724: bl              #0x50ace8  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x693728: r4 = 32
    //     0x693728: mov             x4, #0x20
    // 0x69372c: stur            x0, [fp, #-8]
    // 0x693730: r0 = AllocateFloat64Array()
    //     0x693730: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0x693734: mov             x1, x0
    // 0x693738: ldur            x0, [fp, #-8]
    // 0x69373c: StoreField: r0->field_7 = r1
    //     0x69373c: stur            w1, [x0, #7]
    // 0x693740: SaveReg r0
    //     0x693740: str             x0, [SP, #-8]!
    // 0x693744: r0 = setIdentity()
    //     0x693744: bl              #0x50f090  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0x693748: add             SP, SP, #8
    // 0x69374c: ldr             x0, [fp, #0x10]
    // 0x693750: LoadField: r1 = r0->field_57
    //     0x693750: ldur            w1, [x0, #0x57]
    // 0x693754: DecompressPointer r1
    //     0x693754: add             x1, x1, HEAP, lsl #32
    // 0x693758: cmp             w1, NULL
    // 0x69375c: b.eq            #0x693998
    // 0x693760: LoadField: d0 = r1->field_7
    //     0x693760: ldur            d0, [x1, #7]
    // 0x693764: d1 = 2.000000
    //     0x693764: fmov            d1, #2.00000000
    // 0x693768: fdiv            d2, d0, d1
    // 0x69376c: LoadField: d0 = r1->field_f
    //     0x69376c: ldur            d0, [x1, #0xf]
    // 0x693770: fdiv            d3, d0, d1
    // 0x693774: r1 = inline_Allocate_Double()
    //     0x693774: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x693778: add             x1, x1, #0x10
    //     0x69377c: cmp             x2, x1
    //     0x693780: b.ls            #0x69399c
    //     0x693784: str             x1, [THR, #0x60]  ; THR::top
    //     0x693788: sub             x1, x1, #0xf
    //     0x69378c: mov             x2, #0xd108
    //     0x693790: movk            x2, #3, lsl #16
    //     0x693794: stur            x2, [x1, #-1]
    // 0x693798: StoreField: r1->field_7 = d2
    //     0x693798: stur            d2, [x1, #7]
    // 0x69379c: ldur            x16, [fp, #-8]
    // 0x6937a0: stp             x1, x16, [SP, #-0x10]!
    // 0x6937a4: SaveReg d3
    //     0x6937a4: str             d3, [SP, #-8]!
    // 0x6937a8: r0 = translate()
    //     0x6937a8: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0x6937ac: add             SP, SP, #0x18
    // 0x6937b0: ldr             x0, [fp, #0x10]
    // 0x6937b4: LoadField: r1 = r0->field_63
    //     0x6937b4: ldur            x1, [x0, #0x63]
    // 0x6937b8: ubfx            x1, x1, #0, #0x20
    // 0x6937bc: r2 = 3
    //     0x6937bc: mov             x2, #3
    // 0x6937c0: and             x3, x1, x2
    // 0x6937c4: ubfx            x3, x3, #0, #0x20
    // 0x6937c8: scvtf           d0, x3
    // 0x6937cc: d1 = 1.570796
    //     0x6937cc: add             x17, PP, #0x28, lsl #12  ; [pp+0x28d00] IMM: double(1.5707963267948966) from 0x3ff921fb54442d18
    //     0x6937d0: ldr             d1, [x17, #0xd00]
    // 0x6937d4: fmul            d2, d1, d0
    // 0x6937d8: ldur            x16, [fp, #-8]
    // 0x6937dc: SaveReg r16
    //     0x6937dc: str             x16, [SP, #-8]!
    // 0x6937e0: SaveReg d2
    //     0x6937e0: str             d2, [SP, #-8]!
    // 0x6937e4: r0 = rotateZ()
    //     0x6937e4: bl              #0x6939e4  ; [package:vector_math/vector_math_64.dart] Matrix4::rotateZ
    // 0x6937e8: add             SP, SP, #0x10
    // 0x6937ec: ldr             x0, [fp, #0x10]
    // 0x6937f0: LoadField: r1 = r0->field_5f
    //     0x6937f0: ldur            w1, [x0, #0x5f]
    // 0x6937f4: DecompressPointer r1
    //     0x6937f4: add             x1, x1, HEAP, lsl #32
    // 0x6937f8: cmp             w1, NULL
    // 0x6937fc: b.eq            #0x6939c0
    // 0x693800: LoadField: r2 = r1->field_57
    //     0x693800: ldur            w2, [x1, #0x57]
    // 0x693804: DecompressPointer r2
    //     0x693804: add             x2, x2, HEAP, lsl #32
    // 0x693808: cmp             w2, NULL
    // 0x69380c: b.eq            #0x6939c4
    // 0x693810: LoadField: d0 = r2->field_7
    //     0x693810: ldur            d0, [x2, #7]
    // 0x693814: fneg            d1, d0
    // 0x693818: d0 = 2.000000
    //     0x693818: fmov            d0, #2.00000000
    // 0x69381c: fdiv            d2, d1, d0
    // 0x693820: LoadField: d1 = r2->field_f
    //     0x693820: ldur            d1, [x2, #0xf]
    // 0x693824: fneg            d3, d1
    // 0x693828: fdiv            d1, d3, d0
    // 0x69382c: r1 = inline_Allocate_Double()
    //     0x69382c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x693830: add             x1, x1, #0x10
    //     0x693834: cmp             x2, x1
    //     0x693838: b.ls            #0x6939c8
    //     0x69383c: str             x1, [THR, #0x60]  ; THR::top
    //     0x693840: sub             x1, x1, #0xf
    //     0x693844: mov             x2, #0xd108
    //     0x693848: movk            x2, #3, lsl #16
    //     0x69384c: stur            x2, [x1, #-1]
    // 0x693850: StoreField: r1->field_7 = d2
    //     0x693850: stur            d2, [x1, #7]
    // 0x693854: ldur            x16, [fp, #-8]
    // 0x693858: stp             x1, x16, [SP, #-0x10]!
    // 0x69385c: SaveReg d1
    //     0x69385c: str             d1, [SP, #-8]!
    // 0x693860: r0 = translate()
    //     0x693860: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0x693864: add             SP, SP, #0x18
    // 0x693868: ldur            x0, [fp, #-8]
    // 0x69386c: ldr             x3, [fp, #0x10]
    // 0x693870: StoreField: r3->field_6b = r0
    //     0x693870: stur            w0, [x3, #0x6b]
    //     0x693874: ldurb           w16, [x3, #-1]
    //     0x693878: ldurb           w17, [x0, #-1]
    //     0x69387c: and             x16, x17, x16, lsr #2
    //     0x693880: tst             x16, HEAP, lsr #32
    //     0x693884: b.eq            #0x69388c
    //     0x693888: bl              #0xd682ac
    // 0x69388c: b               #0x693910
    // 0x693890: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x693890: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x693894: ldr             x0, [x0, #0x1e8]
    // 0x693898: LoadField: r4 = r3->field_27
    //     0x693898: ldur            w4, [x3, #0x27]
    // 0x69389c: DecompressPointer r4
    //     0x69389c: add             x4, x4, HEAP, lsl #32
    // 0x6938a0: stur            x4, [fp, #-8]
    // 0x6938a4: cmp             w4, NULL
    // 0x6938a8: b.eq            #0x693960
    // 0x6938ac: mov             x0, x4
    // 0x6938b0: r2 = Null
    //     0x6938b0: mov             x2, NULL
    // 0x6938b4: r1 = Null
    //     0x6938b4: mov             x1, NULL
    // 0x6938b8: r4 = LoadClassIdInstr(r0)
    //     0x6938b8: ldur            x4, [x0, #-1]
    //     0x6938bc: ubfx            x4, x4, #0xc, #0x14
    // 0x6938c0: sub             x4, x4, #0x80d
    // 0x6938c4: cmp             x4, #1
    // 0x6938c8: b.ls            #0x6938e0
    // 0x6938cc: r8 = BoxConstraints
    //     0x6938cc: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x6938d0: ldr             x8, [x8, #0x1d0]
    // 0x6938d4: r3 = Null
    //     0x6938d4: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b248] Null
    //     0x6938d8: ldr             x3, [x3, #0x248]
    // 0x6938dc: r0 = BoxConstraints()
    //     0x6938dc: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x6938e0: ldur            x16, [fp, #-8]
    // 0x6938e4: SaveReg r16
    //     0x6938e4: str             x16, [SP, #-8]!
    // 0x6938e8: r0 = smallest()
    //     0x6938e8: bl              #0x62bd18  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0x6938ec: add             SP, SP, #8
    // 0x6938f0: ldr             x1, [fp, #0x10]
    // 0x6938f4: StoreField: r1->field_57 = r0
    //     0x6938f4: stur            w0, [x1, #0x57]
    //     0x6938f8: ldurb           w16, [x1, #-1]
    //     0x6938fc: ldurb           w17, [x0, #-1]
    //     0x693900: and             x16, x17, x16, lsr #2
    //     0x693904: tst             x16, HEAP, lsr #32
    //     0x693908: b.eq            #0x693910
    //     0x69390c: bl              #0xd6826c
    // 0x693910: r0 = Null
    //     0x693910: mov             x0, NULL
    // 0x693914: LeaveFrame
    //     0x693914: mov             SP, fp
    //     0x693918: ldp             fp, lr, [SP], #0x10
    // 0x69391c: ret
    //     0x69391c: ret             
    // 0x693920: r0 = StateError()
    //     0x693920: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x693924: mov             x1, x0
    // 0x693928: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x693928: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x69392c: ldr             x0, [x0, #0x1e8]
    // 0x693930: StoreField: r1->field_b = r0
    //     0x693930: stur            w0, [x1, #0xb]
    // 0x693934: mov             x0, x1
    // 0x693938: r0 = Throw()
    //     0x693938: bl              #0xd67e38  ; ThrowStub
    // 0x69393c: brk             #0
    // 0x693940: r0 = StateError()
    //     0x693940: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x693944: mov             x1, x0
    // 0x693948: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x693948: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x69394c: ldr             x0, [x0, #0x1e8]
    // 0x693950: StoreField: r1->field_b = r0
    //     0x693950: stur            w0, [x1, #0xb]
    // 0x693954: mov             x0, x1
    // 0x693958: r0 = Throw()
    //     0x693958: bl              #0xd67e38  ; ThrowStub
    // 0x69395c: brk             #0
    // 0x693960: r0 = StateError()
    //     0x693960: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x693964: mov             x1, x0
    // 0x693968: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x693968: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x69396c: ldr             x0, [x0, #0x1e8]
    // 0x693970: StoreField: r1->field_b = r0
    //     0x693970: stur            w0, [x1, #0xb]
    // 0x693974: mov             x0, x1
    // 0x693978: r0 = Throw()
    //     0x693978: bl              #0xd67e38  ; ThrowStub
    // 0x69397c: brk             #0
    // 0x693980: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x693980: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x693984: b               #0x693554
    // 0x693988: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x693988: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69398c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69398c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x693990: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x693990: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x693994: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x693994: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x693998: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x693998: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69399c: stp             q2, q3, [SP, #-0x20]!
    // 0x6939a0: SaveReg d1
    //     0x6939a0: str             q1, [SP, #-0x10]!
    // 0x6939a4: SaveReg r0
    //     0x6939a4: str             x0, [SP, #-8]!
    // 0x6939a8: r0 = AllocateDouble()
    //     0x6939a8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6939ac: mov             x1, x0
    // 0x6939b0: RestoreReg r0
    //     0x6939b0: ldr             x0, [SP], #8
    // 0x6939b4: RestoreReg d1
    //     0x6939b4: ldr             q1, [SP], #0x10
    // 0x6939b8: ldp             q2, q3, [SP], #0x20
    // 0x6939bc: b               #0x693798
    // 0x6939c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6939c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6939c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6939c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6939c8: stp             q1, q2, [SP, #-0x20]!
    // 0x6939cc: SaveReg r0
    //     0x6939cc: str             x0, [SP, #-8]!
    // 0x6939d0: r0 = AllocateDouble()
    //     0x6939d0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6939d4: mov             x1, x0
    // 0x6939d8: RestoreReg r0
    //     0x6939d8: ldr             x0, [SP], #8
    // 0x6939dc: ldp             q1, q2, [SP], #0x20
    // 0x6939e0: b               #0x693850
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0x6bc620, size: 0xa8
    // 0x6bc620: EnterFrame
    //     0x6bc620: stp             fp, lr, [SP, #-0x10]!
    //     0x6bc624: mov             fp, SP
    // 0x6bc628: CheckStackOverflow
    //     0x6bc628: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bc62c: cmp             SP, x16
    //     0x6bc630: b.ls            #0x6bc6c0
    // 0x6bc634: ldr             x0, [fp, #0x18]
    // 0x6bc638: r2 = Null
    //     0x6bc638: mov             x2, NULL
    // 0x6bc63c: r1 = Null
    //     0x6bc63c: mov             x1, NULL
    // 0x6bc640: r4 = 59
    //     0x6bc640: mov             x4, #0x3b
    // 0x6bc644: branchIfSmi(r0, 0x6bc650)
    //     0x6bc644: tbz             w0, #0, #0x6bc650
    // 0x6bc648: r4 = LoadClassIdInstr(r0)
    //     0x6bc648: ldur            x4, [x0, #-1]
    //     0x6bc64c: ubfx            x4, x4, #0xc, #0x14
    // 0x6bc650: sub             x4, x4, #0x965
    // 0x6bc654: cmp             x4, #0x8b
    // 0x6bc658: b.ls            #0x6bc670
    // 0x6bc65c: r8 = RenderBox
    //     0x6bc65c: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x6bc660: ldr             x8, [x8, #0xfa0]
    // 0x6bc664: r3 = Null
    //     0x6bc664: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b208] Null
    //     0x6bc668: ldr             x3, [x3, #0x208]
    // 0x6bc66c: r0 = RenderBox()
    //     0x6bc66c: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x6bc670: ldr             x0, [fp, #0x20]
    // 0x6bc674: LoadField: r1 = r0->field_6b
    //     0x6bc674: ldur            w1, [x0, #0x6b]
    // 0x6bc678: DecompressPointer r1
    //     0x6bc678: add             x1, x1, HEAP, lsl #32
    // 0x6bc67c: cmp             w1, NULL
    // 0x6bc680: b.eq            #0x6bc694
    // 0x6bc684: ldr             x16, [fp, #0x10]
    // 0x6bc688: stp             x1, x16, [SP, #-0x10]!
    // 0x6bc68c: r0 = multiply()
    //     0x6bc68c: bl              #0x625d1c  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0x6bc690: add             SP, SP, #0x10
    // 0x6bc694: ldr             x16, [fp, #0x20]
    // 0x6bc698: ldr             lr, [fp, #0x18]
    // 0x6bc69c: stp             lr, x16, [SP, #-0x10]!
    // 0x6bc6a0: ldr             x16, [fp, #0x10]
    // 0x6bc6a4: SaveReg r16
    //     0x6bc6a4: str             x16, [SP, #-8]!
    // 0x6bc6a8: r0 = applyPaintTransform()
    //     0x6bc6a8: bl              #0x6bcaf8  ; [package:flutter/src/rendering/box.dart] RenderBox::applyPaintTransform
    // 0x6bc6ac: add             SP, SP, #0x18
    // 0x6bc6b0: r0 = Null
    //     0x6bc6b0: mov             x0, NULL
    // 0x6bc6b4: LeaveFrame
    //     0x6bc6b4: mov             SP, fp
    //     0x6bc6b8: ldp             fp, lr, [SP], #0x10
    // 0x6bc6bc: ret
    //     0x6bc6bc: ret             
    // 0x6bc6c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bc6c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bc6c4: b               #0x6bc634
  }
  set _ quarterTurns=(/* No info */) {
    // ** addr: 0x6c5378, size: 0x60
    // 0x6c5378: EnterFrame
    //     0x6c5378: stp             fp, lr, [SP, #-0x10]!
    //     0x6c537c: mov             fp, SP
    // 0x6c5380: CheckStackOverflow
    //     0x6c5380: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c5384: cmp             SP, x16
    //     0x6c5388: b.ls            #0x6c53d0
    // 0x6c538c: ldr             x0, [fp, #0x18]
    // 0x6c5390: LoadField: r1 = r0->field_63
    //     0x6c5390: ldur            x1, [x0, #0x63]
    // 0x6c5394: ldr             x2, [fp, #0x10]
    // 0x6c5398: cmp             x1, x2
    // 0x6c539c: b.ne            #0x6c53b0
    // 0x6c53a0: r0 = Null
    //     0x6c53a0: mov             x0, NULL
    // 0x6c53a4: LeaveFrame
    //     0x6c53a4: mov             SP, fp
    //     0x6c53a8: ldp             fp, lr, [SP], #0x10
    // 0x6c53ac: ret
    //     0x6c53ac: ret             
    // 0x6c53b0: StoreField: r0->field_63 = r2
    //     0x6c53b0: stur            x2, [x0, #0x63]
    // 0x6c53b4: SaveReg r0
    //     0x6c53b4: str             x0, [SP, #-8]!
    // 0x6c53b8: r0 = markNeedsLayout()
    //     0x6c53b8: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c53bc: add             SP, SP, #8
    // 0x6c53c0: r0 = Null
    //     0x6c53c0: mov             x0, NULL
    // 0x6c53c4: LeaveFrame
    //     0x6c53c4: mov             SP, fp
    //     0x6c53c8: ldp             fp, lr, [SP], #0x10
    // 0x6c53cc: ret
    //     0x6c53cc: ret             
    // 0x6c53d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c53d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c53d4: b               #0x6c538c
  }
  _ RenderRotatedBox(/* No info */) {
    // ** addr: 0x6eb980, size: 0x7c
    // 0x6eb980: EnterFrame
    //     0x6eb980: stp             fp, lr, [SP, #-0x10]!
    //     0x6eb984: mov             fp, SP
    // 0x6eb988: CheckStackOverflow
    //     0x6eb988: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6eb98c: cmp             SP, x16
    //     0x6eb990: b.ls            #0x6eb9f4
    // 0x6eb994: r1 = <TransformLayer>
    //     0x6eb994: add             x1, PP, #0x40, lsl #12  ; [pp+0x40c20] TypeArguments: <TransformLayer>
    //     0x6eb998: ldr             x1, [x1, #0xc20]
    // 0x6eb99c: r0 = LayerHandle()
    //     0x6eb99c: bl              #0x5bbf28  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x6eb9a0: ldr             x1, [fp, #0x18]
    // 0x6eb9a4: StoreField: r1->field_6f = r0
    //     0x6eb9a4: stur            w0, [x1, #0x6f]
    //     0x6eb9a8: ldurb           w16, [x1, #-1]
    //     0x6eb9ac: ldurb           w17, [x0, #-1]
    //     0x6eb9b0: and             x16, x17, x16, lsr #2
    //     0x6eb9b4: tst             x16, HEAP, lsr #32
    //     0x6eb9b8: b.eq            #0x6eb9c0
    //     0x6eb9bc: bl              #0xd6826c
    // 0x6eb9c0: ldr             x0, [fp, #0x10]
    // 0x6eb9c4: StoreField: r1->field_63 = r0
    //     0x6eb9c4: stur            x0, [x1, #0x63]
    // 0x6eb9c8: SaveReg r1
    //     0x6eb9c8: str             x1, [SP, #-8]!
    // 0x6eb9cc: r0 = RenderObject()
    //     0x6eb9cc: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6eb9d0: add             SP, SP, #8
    // 0x6eb9d4: ldr             x16, [fp, #0x18]
    // 0x6eb9d8: stp             NULL, x16, [SP, #-0x10]!
    // 0x6eb9dc: r0 = child=()
    //     0x6eb9dc: bl              #0x6e7da0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::child=
    // 0x6eb9e0: add             SP, SP, #0x10
    // 0x6eb9e4: r0 = Null
    //     0x6eb9e4: mov             x0, NULL
    // 0x6eb9e8: LeaveFrame
    //     0x6eb9e8: mov             SP, fp
    //     0x6eb9ec: ldp             fp, lr, [SP], #0x10
    // 0x6eb9f0: ret
    //     0x6eb9f0: ret             
    // 0x6eb9f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6eb9f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6eb9f8: b               #0x6eb994
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5e588, size: 0xf8
    // 0xa5e588: EnterFrame
    //     0xa5e588: stp             fp, lr, [SP, #-0x10]!
    //     0xa5e58c: mov             fp, SP
    // 0xa5e590: AllocStack(0x18)
    //     0xa5e590: sub             SP, SP, #0x18
    // 0xa5e594: CheckStackOverflow
    //     0xa5e594: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5e598: cmp             SP, x16
    //     0xa5e59c: b.ls            #0xa5e678
    // 0xa5e5a0: ldr             x0, [fp, #0x18]
    // 0xa5e5a4: LoadField: r1 = r0->field_5f
    //     0xa5e5a4: ldur            w1, [x0, #0x5f]
    // 0xa5e5a8: DecompressPointer r1
    //     0xa5e5a8: add             x1, x1, HEAP, lsl #32
    // 0xa5e5ac: stur            x1, [fp, #-8]
    // 0xa5e5b0: cmp             w1, NULL
    // 0xa5e5b4: b.ne            #0xa5e5d4
    // 0xa5e5b8: ldr             x16, [fp, #0x10]
    // 0xa5e5bc: SaveReg r16
    //     0xa5e5bc: str             x16, [SP, #-8]!
    // 0xa5e5c0: r0 = smallest()
    //     0xa5e5c0: bl              #0x62bd18  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xa5e5c4: add             SP, SP, #8
    // 0xa5e5c8: LeaveFrame
    //     0xa5e5c8: mov             SP, fp
    //     0xa5e5cc: ldp             fp, lr, [SP], #0x10
    // 0xa5e5d0: ret
    //     0xa5e5d0: ret             
    // 0xa5e5d4: r2 = 1
    //     0xa5e5d4: mov             x2, #1
    // 0xa5e5d8: LoadField: r3 = r0->field_63
    //     0xa5e5d8: ldur            x3, [x0, #0x63]
    // 0xa5e5dc: ubfx            x3, x3, #0, #0x20
    // 0xa5e5e0: and             x4, x3, x2
    // 0xa5e5e4: ubfx            x4, x4, #0, #0x20
    // 0xa5e5e8: cbz             x4, #0xa5e604
    // 0xa5e5ec: ldr             x16, [fp, #0x10]
    // 0xa5e5f0: SaveReg r16
    //     0xa5e5f0: str             x16, [SP, #-8]!
    // 0xa5e5f4: r0 = flipped()
    //     0xa5e5f4: bl              #0x693b9c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::flipped
    // 0xa5e5f8: add             SP, SP, #8
    // 0xa5e5fc: mov             x1, x0
    // 0xa5e600: b               #0xa5e60c
    // 0xa5e604: ldr             x0, [fp, #0x10]
    // 0xa5e608: mov             x1, x0
    // 0xa5e60c: ldr             x0, [fp, #0x18]
    // 0xa5e610: ldur            x16, [fp, #-8]
    // 0xa5e614: stp             x1, x16, [SP, #-0x10]!
    // 0xa5e618: r0 = getDryLayout()
    //     0xa5e618: bl              #0x62d394  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xa5e61c: add             SP, SP, #0x10
    // 0xa5e620: mov             x1, x0
    // 0xa5e624: ldr             x0, [fp, #0x18]
    // 0xa5e628: LoadField: r2 = r0->field_63
    //     0xa5e628: ldur            x2, [x0, #0x63]
    // 0xa5e62c: ubfx            x2, x2, #0, #0x20
    // 0xa5e630: r0 = 1
    //     0xa5e630: mov             x0, #1
    // 0xa5e634: and             x3, x2, x0
    // 0xa5e638: ubfx            x3, x3, #0, #0x20
    // 0xa5e63c: cbz             x3, #0xa5e668
    // 0xa5e640: LoadField: d0 = r1->field_f
    //     0xa5e640: ldur            d0, [x1, #0xf]
    // 0xa5e644: stur            d0, [fp, #-0x18]
    // 0xa5e648: LoadField: d1 = r1->field_7
    //     0xa5e648: ldur            d1, [x1, #7]
    // 0xa5e64c: stur            d1, [fp, #-0x10]
    // 0xa5e650: r0 = Size()
    //     0xa5e650: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xa5e654: ldur            d0, [fp, #-0x18]
    // 0xa5e658: StoreField: r0->field_7 = d0
    //     0xa5e658: stur            d0, [x0, #7]
    // 0xa5e65c: ldur            d0, [fp, #-0x10]
    // 0xa5e660: StoreField: r0->field_f = d0
    //     0xa5e660: stur            d0, [x0, #0xf]
    // 0xa5e664: b               #0xa5e66c
    // 0xa5e668: mov             x0, x1
    // 0xa5e66c: LeaveFrame
    //     0xa5e66c: mov             SP, fp
    //     0xa5e670: ldp             fp, lr, [SP], #0x10
    // 0xa5e674: ret
    //     0xa5e674: ret             
    // 0xa5e678: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5e678: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5e67c: b               #0xa5e5a0
  }
}

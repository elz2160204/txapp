// lib: , url: package:flutter/src/rendering/sliver_multi_box_adaptor.dart

// class id: 1049425, size: 0x8
class :: {
}

// class id: 1991, size: 0x8, field offset: 0x8
abstract class RenderSliverWithKeepAliveMixin extends Object
    implements RenderSliver {
}

// class id: 1992, size: 0x8, field offset: 0x8
abstract class KeepAliveParentDataMixin extends Object
    implements ParentData {
}

// class id: 1993, size: 0x8, field offset: 0x8
abstract class RenderSliverBoxChildManager extends Object {
}

// class id: 2039, size: 0x14, field offset: 0xc
//   transformed mixin,
abstract class _SliverMultiBoxAdaptorParentData&SliverLogicalParentData&ContainerParentDataMixin extends SliverLogicalParentData
     with ContainerParentDataMixin<X0 bound RenderObject> {

  set _ nextSibling=(/* No info */) {
    // ** addr: 0xcef0f0, size: 0x74
    // 0xcef0f0: EnterFrame
    //     0xcef0f0: stp             fp, lr, [SP, #-0x10]!
    //     0xcef0f4: mov             fp, SP
    // 0xcef0f8: ldr             x0, [fp, #0x10]
    // 0xcef0fc: r2 = Null
    //     0xcef0fc: mov             x2, NULL
    // 0xcef100: r1 = Null
    //     0xcef100: mov             x1, NULL
    // 0xcef104: r4 = 59
    //     0xcef104: mov             x4, #0x3b
    // 0xcef108: branchIfSmi(r0, 0xcef114)
    //     0xcef108: tbz             w0, #0, #0xcef114
    // 0xcef10c: r4 = LoadClassIdInstr(r0)
    //     0xcef10c: ldur            x4, [x0, #-1]
    //     0xcef110: ubfx            x4, x4, #0xc, #0x14
    // 0xcef114: sub             x4, x4, #0x965
    // 0xcef118: cmp             x4, #0x8b
    // 0xcef11c: b.ls            #0xcef130
    // 0xcef120: r8 = RenderBox?
    //     0xcef120: ldr             x8, [PP, #0x4de8]  ; [pp+0x4de8] Type: RenderBox?
    // 0xcef124: r3 = Null
    //     0xcef124: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fb68] Null
    //     0xcef128: ldr             x3, [x3, #0xb68]
    // 0xcef12c: r0 = RenderBox?()
    //     0xcef12c: bl              #0x5ad534  ; IsType_RenderBox?_Stub
    // 0xcef130: ldr             x0, [fp, #0x10]
    // 0xcef134: ldr             x1, [fp, #0x18]
    // 0xcef138: StoreField: r1->field_f = r0
    //     0xcef138: stur            w0, [x1, #0xf]
    //     0xcef13c: ldurb           w16, [x1, #-1]
    //     0xcef140: ldurb           w17, [x0, #-1]
    //     0xcef144: and             x16, x17, x16, lsr #2
    //     0xcef148: tst             x16, HEAP, lsr #32
    //     0xcef14c: b.eq            #0xcef154
    //     0xcef150: bl              #0xd6826c
    // 0xcef154: r0 = Null
    //     0xcef154: mov             x0, NULL
    // 0xcef158: LeaveFrame
    //     0xcef158: mov             SP, fp
    //     0xcef15c: ldp             fp, lr, [SP], #0x10
    // 0xcef160: ret
    //     0xcef160: ret             
  }
  set _ previousSibling=(/* No info */) {
    // ** addr: 0xcef8e0, size: 0x74
    // 0xcef8e0: EnterFrame
    //     0xcef8e0: stp             fp, lr, [SP, #-0x10]!
    //     0xcef8e4: mov             fp, SP
    // 0xcef8e8: ldr             x0, [fp, #0x10]
    // 0xcef8ec: r2 = Null
    //     0xcef8ec: mov             x2, NULL
    // 0xcef8f0: r1 = Null
    //     0xcef8f0: mov             x1, NULL
    // 0xcef8f4: r4 = 59
    //     0xcef8f4: mov             x4, #0x3b
    // 0xcef8f8: branchIfSmi(r0, 0xcef904)
    //     0xcef8f8: tbz             w0, #0, #0xcef904
    // 0xcef8fc: r4 = LoadClassIdInstr(r0)
    //     0xcef8fc: ldur            x4, [x0, #-1]
    //     0xcef900: ubfx            x4, x4, #0xc, #0x14
    // 0xcef904: sub             x4, x4, #0x965
    // 0xcef908: cmp             x4, #0x8b
    // 0xcef90c: b.ls            #0xcef920
    // 0xcef910: r8 = RenderBox?
    //     0xcef910: ldr             x8, [PP, #0x4de8]  ; [pp+0x4de8] Type: RenderBox?
    // 0xcef914: r3 = Null
    //     0xcef914: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fb78] Null
    //     0xcef918: ldr             x3, [x3, #0xb78]
    // 0xcef91c: r0 = RenderBox?()
    //     0xcef91c: bl              #0x5ad534  ; IsType_RenderBox?_Stub
    // 0xcef920: ldr             x0, [fp, #0x10]
    // 0xcef924: ldr             x1, [fp, #0x18]
    // 0xcef928: StoreField: r1->field_b = r0
    //     0xcef928: stur            w0, [x1, #0xb]
    //     0xcef92c: ldurb           w16, [x1, #-1]
    //     0xcef930: ldurb           w17, [x0, #-1]
    //     0xcef934: and             x16, x17, x16, lsr #2
    //     0xcef938: tst             x16, HEAP, lsr #32
    //     0xcef93c: b.eq            #0xcef944
    //     0xcef940: bl              #0xd6826c
    // 0xcef944: r0 = Null
    //     0xcef944: mov             x0, NULL
    // 0xcef948: LeaveFrame
    //     0xcef948: mov             SP, fp
    //     0xcef94c: ldp             fp, lr, [SP], #0x10
    // 0xcef950: ret
    //     0xcef950: ret             
  }
}

// class id: 2040, size: 0x18, field offset: 0x14
//   transformed mixin,
abstract class _SliverMultiBoxAdaptorParentData&SliverLogicalParentData&ContainerParentDataMixin&KeepAliveParentDataMixin extends _SliverMultiBoxAdaptorParentData&SliverLogicalParentData&ContainerParentDataMixin
     with KeepAliveParentDataMixin {
}

// class id: 2041, size: 0x20, field offset: 0x18
class SliverMultiBoxAdaptorParentData extends _SliverMultiBoxAdaptorParentData&SliverLogicalParentData&ContainerParentDataMixin&KeepAliveParentDataMixin {

  _ toString(/* No info */) {
    // ** addr: 0xae53c8, size: 0xc8
    // 0xae53c8: EnterFrame
    //     0xae53c8: stp             fp, lr, [SP, #-0x10]!
    //     0xae53cc: mov             fp, SP
    // 0xae53d0: AllocStack(0x8)
    //     0xae53d0: sub             SP, SP, #8
    // 0xae53d4: CheckStackOverflow
    //     0xae53d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae53d8: cmp             SP, x16
    //     0xae53dc: b.ls            #0xae5488
    // 0xae53e0: r1 = Null
    //     0xae53e0: mov             x1, NULL
    // 0xae53e4: r2 = 10
    //     0xae53e4: mov             x2, #0xa
    // 0xae53e8: r0 = AllocateArray()
    //     0xae53e8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae53ec: stur            x0, [fp, #-8]
    // 0xae53f0: r17 = "index="
    //     0xae53f0: add             x17, PP, #0x4f, lsl #12  ; [pp+0x4fbe0] "index="
    //     0xae53f4: ldr             x17, [x17, #0xbe0]
    // 0xae53f8: StoreField: r0->field_f = r17
    //     0xae53f8: stur            w17, [x0, #0xf]
    // 0xae53fc: ldr             x1, [fp, #0x10]
    // 0xae5400: LoadField: r2 = r1->field_17
    //     0xae5400: ldur            w2, [x1, #0x17]
    // 0xae5404: DecompressPointer r2
    //     0xae5404: add             x2, x2, HEAP, lsl #32
    // 0xae5408: StoreField: r0->field_13 = r2
    //     0xae5408: stur            w2, [x0, #0x13]
    // 0xae540c: r17 = "; "
    //     0xae540c: add             x17, PP, #0x1b, lsl #12  ; [pp+0x1bca8] "; "
    //     0xae5410: ldr             x17, [x17, #0xca8]
    // 0xae5414: StoreField: r0->field_17 = r17
    //     0xae5414: stur            w17, [x0, #0x17]
    // 0xae5418: LoadField: r2 = r1->field_13
    //     0xae5418: ldur            w2, [x1, #0x13]
    // 0xae541c: DecompressPointer r2
    //     0xae541c: add             x2, x2, HEAP, lsl #32
    // 0xae5420: tbnz            w2, #4, #0xae5430
    // 0xae5424: r2 = "keepAlive; "
    //     0xae5424: add             x2, PP, #0x4f, lsl #12  ; [pp+0x4fbe8] "keepAlive; "
    //     0xae5428: ldr             x2, [x2, #0xbe8]
    // 0xae542c: b               #0xae5434
    // 0xae5430: r2 = ""
    //     0xae5430: ldr             x2, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xae5434: StoreField: r0->field_1b = r2
    //     0xae5434: stur            w2, [x0, #0x1b]
    // 0xae5438: SaveReg r1
    //     0xae5438: str             x1, [SP, #-8]!
    // 0xae543c: r0 = toString()
    //     0xae543c: bl              #0xae51c8  ; [package:flutter/src/rendering/sliver.dart] SliverLogicalParentData::toString
    // 0xae5440: add             SP, SP, #8
    // 0xae5444: ldur            x1, [fp, #-8]
    // 0xae5448: ArrayStore: r1[4] = r0  ; List_4
    //     0xae5448: add             x25, x1, #0x1f
    //     0xae544c: str             w0, [x25]
    //     0xae5450: tbz             w0, #0, #0xae546c
    //     0xae5454: ldurb           w16, [x1, #-1]
    //     0xae5458: ldurb           w17, [x0, #-1]
    //     0xae545c: and             x16, x17, x16, lsr #2
    //     0xae5460: tst             x16, HEAP, lsr #32
    //     0xae5464: b.eq            #0xae546c
    //     0xae5468: bl              #0xd67e5c
    // 0xae546c: ldur            x16, [fp, #-8]
    // 0xae5470: SaveReg r16
    //     0xae5470: str             x16, [SP, #-8]!
    // 0xae5474: r0 = _interpolate()
    //     0xae5474: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae5478: add             SP, SP, #8
    // 0xae547c: LeaveFrame
    //     0xae547c: mov             SP, fp
    //     0xae5480: ldp             fp, lr, [SP], #0x10
    // 0xae5484: ret
    //     0xae5484: ret             
    // 0xae5488: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae5488: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae548c: b               #0xae53e0
  }
}

// class id: 2580, size: 0x64, field offset: 0x54
//   transformed mixin,
abstract class _RenderSliverMultiBoxAdaptor&RenderSliver&ContainerRenderObjectMixin extends RenderSliver
     with ContainerRenderObjectMixin<X0 bound RenderObject, X1 bound ContainerParentDataMixin<X0 bound RenderObject>> {

  _ move(/* No info */) {
    // ** addr: 0x5acf0c, size: 0x100
    // 0x5acf0c: EnterFrame
    //     0x5acf0c: stp             fp, lr, [SP, #-0x10]!
    //     0x5acf10: mov             fp, SP
    // 0x5acf14: AllocStack(0x8)
    //     0x5acf14: sub             SP, SP, #8
    // 0x5acf18: CheckStackOverflow
    //     0x5acf18: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5acf1c: cmp             SP, x16
    //     0x5acf20: b.ls            #0x5ad000
    // 0x5acf24: ldr             x3, [fp, #0x18]
    // 0x5acf28: LoadField: r4 = r3->field_17
    //     0x5acf28: ldur            w4, [x3, #0x17]
    // 0x5acf2c: DecompressPointer r4
    //     0x5acf2c: add             x4, x4, HEAP, lsl #32
    // 0x5acf30: stur            x4, [fp, #-8]
    // 0x5acf34: cmp             w4, NULL
    // 0x5acf38: b.eq            #0x5ad008
    // 0x5acf3c: mov             x0, x4
    // 0x5acf40: r2 = Null
    //     0x5acf40: mov             x2, NULL
    // 0x5acf44: r1 = Null
    //     0x5acf44: mov             x1, NULL
    // 0x5acf48: r4 = LoadClassIdInstr(r0)
    //     0x5acf48: ldur            x4, [x0, #-1]
    //     0x5acf4c: ubfx            x4, x4, #0xc, #0x14
    // 0x5acf50: sub             x4, x4, #0x7f9
    // 0x5acf54: cmp             x4, #2
    // 0x5acf58: b.ls            #0x5acf70
    // 0x5acf5c: r8 = SliverMultiBoxAdaptorParentData
    //     0x5acf5c: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x5acf60: ldr             x8, [x8, #0x120]
    // 0x5acf64: r3 = Null
    //     0x5acf64: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ace0] Null
    //     0x5acf68: ldr             x3, [x3, #0xce0]
    // 0x5acf6c: r0 = DefaultTypeTest()
    //     0x5acf6c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5acf70: ldur            x0, [fp, #-8]
    // 0x5acf74: LoadField: r1 = r0->field_b
    //     0x5acf74: ldur            w1, [x0, #0xb]
    // 0x5acf78: DecompressPointer r1
    //     0x5acf78: add             x1, x1, HEAP, lsl #32
    // 0x5acf7c: r0 = LoadClassIdInstr(r1)
    //     0x5acf7c: ldur            x0, [x1, #-1]
    //     0x5acf80: ubfx            x0, x0, #0xc, #0x14
    // 0x5acf84: ldr             x16, [fp, #0x10]
    // 0x5acf88: stp             x16, x1, [SP, #-0x10]!
    // 0x5acf8c: mov             lr, x0
    // 0x5acf90: ldr             lr, [x21, lr, lsl #3]
    // 0x5acf94: blr             lr
    // 0x5acf98: add             SP, SP, #0x10
    // 0x5acf9c: tbnz            w0, #4, #0x5acfb0
    // 0x5acfa0: r0 = Null
    //     0x5acfa0: mov             x0, NULL
    // 0x5acfa4: LeaveFrame
    //     0x5acfa4: mov             SP, fp
    //     0x5acfa8: ldp             fp, lr, [SP], #0x10
    // 0x5acfac: ret
    //     0x5acfac: ret             
    // 0x5acfb0: ldr             x16, [fp, #0x20]
    // 0x5acfb4: ldr             lr, [fp, #0x18]
    // 0x5acfb8: stp             lr, x16, [SP, #-0x10]!
    // 0x5acfbc: r0 = _removeFromChildList()
    //     0x5acfbc: bl              #0x5ad338  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] _RenderSliverMultiBoxAdaptor&RenderSliver&ContainerRenderObjectMixin::_removeFromChildList
    // 0x5acfc0: add             SP, SP, #0x10
    // 0x5acfc4: ldr             x16, [fp, #0x20]
    // 0x5acfc8: ldr             lr, [fp, #0x18]
    // 0x5acfcc: stp             lr, x16, [SP, #-0x10]!
    // 0x5acfd0: ldr             x16, [fp, #0x10]
    // 0x5acfd4: SaveReg r16
    //     0x5acfd4: str             x16, [SP, #-8]!
    // 0x5acfd8: r0 = _insertIntoChildList()
    //     0x5acfd8: bl              #0x5ad00c  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] _RenderSliverMultiBoxAdaptor&RenderSliver&ContainerRenderObjectMixin::_insertIntoChildList
    // 0x5acfdc: add             SP, SP, #0x18
    // 0x5acfe0: ldr             x16, [fp, #0x20]
    // 0x5acfe4: SaveReg r16
    //     0x5acfe4: str             x16, [SP, #-8]!
    // 0x5acfe8: r0 = markNeedsLayout()
    //     0x5acfe8: bl              #0x6c0ee8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsLayout
    // 0x5acfec: add             SP, SP, #8
    // 0x5acff0: r0 = Null
    //     0x5acff0: mov             x0, NULL
    // 0x5acff4: LeaveFrame
    //     0x5acff4: mov             SP, fp
    //     0x5acff8: ldp             fp, lr, [SP], #0x10
    // 0x5acffc: ret
    //     0x5acffc: ret             
    // 0x5ad000: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5ad000: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5ad004: b               #0x5acf24
    // 0x5ad008: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5ad008: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _insertIntoChildList(/* No info */) {
    // ** addr: 0x5ad00c, size: 0x32c
    // 0x5ad00c: EnterFrame
    //     0x5ad00c: stp             fp, lr, [SP, #-0x10]!
    //     0x5ad010: mov             fp, SP
    // 0x5ad014: AllocStack(0x10)
    //     0x5ad014: sub             SP, SP, #0x10
    // 0x5ad018: ldr             x3, [fp, #0x18]
    // 0x5ad01c: LoadField: r4 = r3->field_17
    //     0x5ad01c: ldur            w4, [x3, #0x17]
    // 0x5ad020: DecompressPointer r4
    //     0x5ad020: add             x4, x4, HEAP, lsl #32
    // 0x5ad024: stur            x4, [fp, #-8]
    // 0x5ad028: cmp             w4, NULL
    // 0x5ad02c: b.eq            #0x5ad328
    // 0x5ad030: mov             x0, x4
    // 0x5ad034: r2 = Null
    //     0x5ad034: mov             x2, NULL
    // 0x5ad038: r1 = Null
    //     0x5ad038: mov             x1, NULL
    // 0x5ad03c: r4 = LoadClassIdInstr(r0)
    //     0x5ad03c: ldur            x4, [x0, #-1]
    //     0x5ad040: ubfx            x4, x4, #0xc, #0x14
    // 0x5ad044: sub             x4, x4, #0x7f9
    // 0x5ad048: cmp             x4, #2
    // 0x5ad04c: b.ls            #0x5ad064
    // 0x5ad050: r8 = SliverMultiBoxAdaptorParentData
    //     0x5ad050: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x5ad054: ldr             x8, [x8, #0x120]
    // 0x5ad058: r3 = Null
    //     0x5ad058: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4acf0] Null
    //     0x5ad05c: ldr             x3, [x3, #0xcf0]
    // 0x5ad060: r0 = DefaultTypeTest()
    //     0x5ad060: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5ad064: ldr             x3, [fp, #0x20]
    // 0x5ad068: LoadField: r0 = r3->field_53
    //     0x5ad068: ldur            x0, [x3, #0x53]
    // 0x5ad06c: add             x1, x0, #1
    // 0x5ad070: StoreField: r3->field_53 = r1
    //     0x5ad070: stur            x1, [x3, #0x53]
    // 0x5ad074: ldr             x4, [fp, #0x10]
    // 0x5ad078: cmp             w4, NULL
    // 0x5ad07c: b.ne            #0x5ad178
    // 0x5ad080: ldur            x5, [fp, #-8]
    // 0x5ad084: LoadField: r1 = r3->field_5b
    //     0x5ad084: ldur            w1, [x3, #0x5b]
    // 0x5ad088: DecompressPointer r1
    //     0x5ad088: add             x1, x1, HEAP, lsl #32
    // 0x5ad08c: mov             x0, x1
    // 0x5ad090: StoreField: r5->field_f = r0
    //     0x5ad090: stur            w0, [x5, #0xf]
    //     0x5ad094: ldurb           w16, [x5, #-1]
    //     0x5ad098: ldurb           w17, [x0, #-1]
    //     0x5ad09c: and             x16, x17, x16, lsr #2
    //     0x5ad0a0: tst             x16, HEAP, lsr #32
    //     0x5ad0a4: b.eq            #0x5ad0ac
    //     0x5ad0a8: bl              #0xd682ec
    // 0x5ad0ac: cmp             w1, NULL
    // 0x5ad0b0: b.eq            #0x5ad120
    // 0x5ad0b4: LoadField: r4 = r1->field_17
    //     0x5ad0b4: ldur            w4, [x1, #0x17]
    // 0x5ad0b8: DecompressPointer r4
    //     0x5ad0b8: add             x4, x4, HEAP, lsl #32
    // 0x5ad0bc: stur            x4, [fp, #-0x10]
    // 0x5ad0c0: cmp             w4, NULL
    // 0x5ad0c4: b.eq            #0x5ad32c
    // 0x5ad0c8: mov             x0, x4
    // 0x5ad0cc: r2 = Null
    //     0x5ad0cc: mov             x2, NULL
    // 0x5ad0d0: r1 = Null
    //     0x5ad0d0: mov             x1, NULL
    // 0x5ad0d4: r4 = LoadClassIdInstr(r0)
    //     0x5ad0d4: ldur            x4, [x0, #-1]
    //     0x5ad0d8: ubfx            x4, x4, #0xc, #0x14
    // 0x5ad0dc: sub             x4, x4, #0x7f9
    // 0x5ad0e0: cmp             x4, #2
    // 0x5ad0e4: b.ls            #0x5ad0fc
    // 0x5ad0e8: r8 = SliverMultiBoxAdaptorParentData
    //     0x5ad0e8: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x5ad0ec: ldr             x8, [x8, #0x120]
    // 0x5ad0f0: r3 = Null
    //     0x5ad0f0: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ad00] Null
    //     0x5ad0f4: ldr             x3, [x3, #0xd00]
    // 0x5ad0f8: r0 = DefaultTypeTest()
    //     0x5ad0f8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5ad0fc: ldr             x0, [fp, #0x18]
    // 0x5ad100: ldur            x1, [fp, #-0x10]
    // 0x5ad104: StoreField: r1->field_b = r0
    //     0x5ad104: stur            w0, [x1, #0xb]
    //     0x5ad108: ldurb           w16, [x1, #-1]
    //     0x5ad10c: ldurb           w17, [x0, #-1]
    //     0x5ad110: and             x16, x17, x16, lsr #2
    //     0x5ad114: tst             x16, HEAP, lsr #32
    //     0x5ad118: b.eq            #0x5ad120
    //     0x5ad11c: bl              #0xd6826c
    // 0x5ad120: ldr             x3, [fp, #0x20]
    // 0x5ad124: ldr             x0, [fp, #0x18]
    // 0x5ad128: StoreField: r3->field_5b = r0
    //     0x5ad128: stur            w0, [x3, #0x5b]
    //     0x5ad12c: ldurb           w16, [x3, #-1]
    //     0x5ad130: ldurb           w17, [x0, #-1]
    //     0x5ad134: and             x16, x17, x16, lsr #2
    //     0x5ad138: tst             x16, HEAP, lsr #32
    //     0x5ad13c: b.eq            #0x5ad144
    //     0x5ad140: bl              #0xd682ac
    // 0x5ad144: LoadField: r0 = r3->field_5f
    //     0x5ad144: ldur            w0, [x3, #0x5f]
    // 0x5ad148: DecompressPointer r0
    //     0x5ad148: add             x0, x0, HEAP, lsl #32
    // 0x5ad14c: cmp             w0, NULL
    // 0x5ad150: b.ne            #0x5ad318
    // 0x5ad154: ldr             x0, [fp, #0x18]
    // 0x5ad158: StoreField: r3->field_5f = r0
    //     0x5ad158: stur            w0, [x3, #0x5f]
    //     0x5ad15c: ldurb           w16, [x3, #-1]
    //     0x5ad160: ldurb           w17, [x0, #-1]
    //     0x5ad164: and             x16, x17, x16, lsr #2
    //     0x5ad168: tst             x16, HEAP, lsr #32
    //     0x5ad16c: b.eq            #0x5ad174
    //     0x5ad170: bl              #0xd682ac
    // 0x5ad174: b               #0x5ad318
    // 0x5ad178: ldur            x5, [fp, #-8]
    // 0x5ad17c: LoadField: r6 = r4->field_17
    //     0x5ad17c: ldur            w6, [x4, #0x17]
    // 0x5ad180: DecompressPointer r6
    //     0x5ad180: add             x6, x6, HEAP, lsl #32
    // 0x5ad184: stur            x6, [fp, #-0x10]
    // 0x5ad188: cmp             w6, NULL
    // 0x5ad18c: b.eq            #0x5ad330
    // 0x5ad190: mov             x0, x6
    // 0x5ad194: r2 = Null
    //     0x5ad194: mov             x2, NULL
    // 0x5ad198: r1 = Null
    //     0x5ad198: mov             x1, NULL
    // 0x5ad19c: r4 = LoadClassIdInstr(r0)
    //     0x5ad19c: ldur            x4, [x0, #-1]
    //     0x5ad1a0: ubfx            x4, x4, #0xc, #0x14
    // 0x5ad1a4: sub             x4, x4, #0x7f9
    // 0x5ad1a8: cmp             x4, #2
    // 0x5ad1ac: b.ls            #0x5ad1c4
    // 0x5ad1b0: r8 = SliverMultiBoxAdaptorParentData
    //     0x5ad1b0: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x5ad1b4: ldr             x8, [x8, #0x120]
    // 0x5ad1b8: r3 = Null
    //     0x5ad1b8: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ad10] Null
    //     0x5ad1bc: ldr             x3, [x3, #0xd10]
    // 0x5ad1c0: r0 = DefaultTypeTest()
    //     0x5ad1c0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5ad1c4: ldur            x3, [fp, #-0x10]
    // 0x5ad1c8: LoadField: r1 = r3->field_f
    //     0x5ad1c8: ldur            w1, [x3, #0xf]
    // 0x5ad1cc: DecompressPointer r1
    //     0x5ad1cc: add             x1, x1, HEAP, lsl #32
    // 0x5ad1d0: cmp             w1, NULL
    // 0x5ad1d4: b.ne            #0x5ad244
    // 0x5ad1d8: ldr             x1, [fp, #0x20]
    // 0x5ad1dc: ldur            x2, [fp, #-8]
    // 0x5ad1e0: ldr             x0, [fp, #0x10]
    // 0x5ad1e4: StoreField: r2->field_b = r0
    //     0x5ad1e4: stur            w0, [x2, #0xb]
    //     0x5ad1e8: ldurb           w16, [x2, #-1]
    //     0x5ad1ec: ldurb           w17, [x0, #-1]
    //     0x5ad1f0: and             x16, x17, x16, lsr #2
    //     0x5ad1f4: tst             x16, HEAP, lsr #32
    //     0x5ad1f8: b.eq            #0x5ad200
    //     0x5ad1fc: bl              #0xd6828c
    // 0x5ad200: ldr             x0, [fp, #0x18]
    // 0x5ad204: StoreField: r3->field_f = r0
    //     0x5ad204: stur            w0, [x3, #0xf]
    //     0x5ad208: ldurb           w16, [x3, #-1]
    //     0x5ad20c: ldurb           w17, [x0, #-1]
    //     0x5ad210: and             x16, x17, x16, lsr #2
    //     0x5ad214: tst             x16, HEAP, lsr #32
    //     0x5ad218: b.eq            #0x5ad220
    //     0x5ad21c: bl              #0xd682ac
    // 0x5ad220: ldr             x0, [fp, #0x18]
    // 0x5ad224: StoreField: r1->field_5f = r0
    //     0x5ad224: stur            w0, [x1, #0x5f]
    //     0x5ad228: ldurb           w16, [x1, #-1]
    //     0x5ad22c: ldurb           w17, [x0, #-1]
    //     0x5ad230: and             x16, x17, x16, lsr #2
    //     0x5ad234: tst             x16, HEAP, lsr #32
    //     0x5ad238: b.eq            #0x5ad240
    //     0x5ad23c: bl              #0xd6826c
    // 0x5ad240: b               #0x5ad318
    // 0x5ad244: ldur            x2, [fp, #-8]
    // 0x5ad248: mov             x0, x1
    // 0x5ad24c: StoreField: r2->field_f = r0
    //     0x5ad24c: stur            w0, [x2, #0xf]
    //     0x5ad250: ldurb           w16, [x2, #-1]
    //     0x5ad254: ldurb           w17, [x0, #-1]
    //     0x5ad258: and             x16, x17, x16, lsr #2
    //     0x5ad25c: tst             x16, HEAP, lsr #32
    //     0x5ad260: b.eq            #0x5ad268
    //     0x5ad264: bl              #0xd6828c
    // 0x5ad268: ldr             x0, [fp, #0x10]
    // 0x5ad26c: StoreField: r2->field_b = r0
    //     0x5ad26c: stur            w0, [x2, #0xb]
    //     0x5ad270: ldurb           w16, [x2, #-1]
    //     0x5ad274: ldurb           w17, [x0, #-1]
    //     0x5ad278: and             x16, x17, x16, lsr #2
    //     0x5ad27c: tst             x16, HEAP, lsr #32
    //     0x5ad280: b.eq            #0x5ad288
    //     0x5ad284: bl              #0xd6828c
    // 0x5ad288: LoadField: r4 = r1->field_17
    //     0x5ad288: ldur            w4, [x1, #0x17]
    // 0x5ad28c: DecompressPointer r4
    //     0x5ad28c: add             x4, x4, HEAP, lsl #32
    // 0x5ad290: stur            x4, [fp, #-8]
    // 0x5ad294: cmp             w4, NULL
    // 0x5ad298: b.eq            #0x5ad334
    // 0x5ad29c: mov             x0, x4
    // 0x5ad2a0: r2 = Null
    //     0x5ad2a0: mov             x2, NULL
    // 0x5ad2a4: r1 = Null
    //     0x5ad2a4: mov             x1, NULL
    // 0x5ad2a8: r4 = LoadClassIdInstr(r0)
    //     0x5ad2a8: ldur            x4, [x0, #-1]
    //     0x5ad2ac: ubfx            x4, x4, #0xc, #0x14
    // 0x5ad2b0: sub             x4, x4, #0x7f9
    // 0x5ad2b4: cmp             x4, #2
    // 0x5ad2b8: b.ls            #0x5ad2d0
    // 0x5ad2bc: r8 = SliverMultiBoxAdaptorParentData
    //     0x5ad2bc: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x5ad2c0: ldr             x8, [x8, #0x120]
    // 0x5ad2c4: r3 = Null
    //     0x5ad2c4: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ad20] Null
    //     0x5ad2c8: ldr             x3, [x3, #0xd20]
    // 0x5ad2cc: r0 = DefaultTypeTest()
    //     0x5ad2cc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5ad2d0: ldr             x0, [fp, #0x18]
    // 0x5ad2d4: ldur            x1, [fp, #-0x10]
    // 0x5ad2d8: StoreField: r1->field_f = r0
    //     0x5ad2d8: stur            w0, [x1, #0xf]
    //     0x5ad2dc: ldurb           w16, [x1, #-1]
    //     0x5ad2e0: ldurb           w17, [x0, #-1]
    //     0x5ad2e4: and             x16, x17, x16, lsr #2
    //     0x5ad2e8: tst             x16, HEAP, lsr #32
    //     0x5ad2ec: b.eq            #0x5ad2f4
    //     0x5ad2f0: bl              #0xd6826c
    // 0x5ad2f4: ldr             x0, [fp, #0x18]
    // 0x5ad2f8: ldur            x1, [fp, #-8]
    // 0x5ad2fc: StoreField: r1->field_b = r0
    //     0x5ad2fc: stur            w0, [x1, #0xb]
    //     0x5ad300: ldurb           w16, [x1, #-1]
    //     0x5ad304: ldurb           w17, [x0, #-1]
    //     0x5ad308: and             x16, x17, x16, lsr #2
    //     0x5ad30c: tst             x16, HEAP, lsr #32
    //     0x5ad310: b.eq            #0x5ad318
    //     0x5ad314: bl              #0xd6826c
    // 0x5ad318: r0 = Null
    //     0x5ad318: mov             x0, NULL
    // 0x5ad31c: LeaveFrame
    //     0x5ad31c: mov             SP, fp
    //     0x5ad320: ldp             fp, lr, [SP], #0x10
    // 0x5ad324: ret
    //     0x5ad324: ret             
    // 0x5ad328: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5ad328: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5ad32c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5ad32c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5ad330: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5ad330: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5ad334: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5ad334: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _removeFromChildList(/* No info */) {
    // ** addr: 0x5ad338, size: 0x1fc
    // 0x5ad338: EnterFrame
    //     0x5ad338: stp             fp, lr, [SP, #-0x10]!
    //     0x5ad33c: mov             fp, SP
    // 0x5ad340: AllocStack(0x18)
    //     0x5ad340: sub             SP, SP, #0x18
    // 0x5ad344: ldr             x0, [fp, #0x10]
    // 0x5ad348: LoadField: r3 = r0->field_17
    //     0x5ad348: ldur            w3, [x0, #0x17]
    // 0x5ad34c: DecompressPointer r3
    //     0x5ad34c: add             x3, x3, HEAP, lsl #32
    // 0x5ad350: stur            x3, [fp, #-8]
    // 0x5ad354: cmp             w3, NULL
    // 0x5ad358: b.eq            #0x5ad528
    // 0x5ad35c: mov             x0, x3
    // 0x5ad360: r2 = Null
    //     0x5ad360: mov             x2, NULL
    // 0x5ad364: r1 = Null
    //     0x5ad364: mov             x1, NULL
    // 0x5ad368: r4 = LoadClassIdInstr(r0)
    //     0x5ad368: ldur            x4, [x0, #-1]
    //     0x5ad36c: ubfx            x4, x4, #0xc, #0x14
    // 0x5ad370: sub             x4, x4, #0x7f9
    // 0x5ad374: cmp             x4, #2
    // 0x5ad378: b.ls            #0x5ad390
    // 0x5ad37c: r8 = SliverMultiBoxAdaptorParentData
    //     0x5ad37c: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x5ad380: ldr             x8, [x8, #0x120]
    // 0x5ad384: r3 = Null
    //     0x5ad384: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4acb0] Null
    //     0x5ad388: ldr             x3, [x3, #0xcb0]
    // 0x5ad38c: r0 = DefaultTypeTest()
    //     0x5ad38c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5ad390: ldur            x3, [fp, #-8]
    // 0x5ad394: LoadField: r4 = r3->field_b
    //     0x5ad394: ldur            w4, [x3, #0xb]
    // 0x5ad398: DecompressPointer r4
    //     0x5ad398: add             x4, x4, HEAP, lsl #32
    // 0x5ad39c: stur            x4, [fp, #-0x18]
    // 0x5ad3a0: cmp             w4, NULL
    // 0x5ad3a4: b.ne            #0x5ad3d4
    // 0x5ad3a8: ldr             x5, [fp, #0x18]
    // 0x5ad3ac: LoadField: r0 = r3->field_f
    //     0x5ad3ac: ldur            w0, [x3, #0xf]
    // 0x5ad3b0: DecompressPointer r0
    //     0x5ad3b0: add             x0, x0, HEAP, lsl #32
    // 0x5ad3b4: StoreField: r5->field_5b = r0
    //     0x5ad3b4: stur            w0, [x5, #0x5b]
    //     0x5ad3b8: ldurb           w16, [x5, #-1]
    //     0x5ad3bc: ldurb           w17, [x0, #-1]
    //     0x5ad3c0: and             x16, x17, x16, lsr #2
    //     0x5ad3c4: tst             x16, HEAP, lsr #32
    //     0x5ad3c8: b.eq            #0x5ad3d0
    //     0x5ad3cc: bl              #0xd682ec
    // 0x5ad3d0: b               #0x5ad44c
    // 0x5ad3d4: ldr             x5, [fp, #0x18]
    // 0x5ad3d8: LoadField: r6 = r4->field_17
    //     0x5ad3d8: ldur            w6, [x4, #0x17]
    // 0x5ad3dc: DecompressPointer r6
    //     0x5ad3dc: add             x6, x6, HEAP, lsl #32
    // 0x5ad3e0: stur            x6, [fp, #-0x10]
    // 0x5ad3e4: cmp             w6, NULL
    // 0x5ad3e8: b.eq            #0x5ad52c
    // 0x5ad3ec: mov             x0, x6
    // 0x5ad3f0: r2 = Null
    //     0x5ad3f0: mov             x2, NULL
    // 0x5ad3f4: r1 = Null
    //     0x5ad3f4: mov             x1, NULL
    // 0x5ad3f8: r4 = LoadClassIdInstr(r0)
    //     0x5ad3f8: ldur            x4, [x0, #-1]
    //     0x5ad3fc: ubfx            x4, x4, #0xc, #0x14
    // 0x5ad400: sub             x4, x4, #0x7f9
    // 0x5ad404: cmp             x4, #2
    // 0x5ad408: b.ls            #0x5ad420
    // 0x5ad40c: r8 = SliverMultiBoxAdaptorParentData
    //     0x5ad40c: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x5ad410: ldr             x8, [x8, #0x120]
    // 0x5ad414: r3 = Null
    //     0x5ad414: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4acc0] Null
    //     0x5ad418: ldr             x3, [x3, #0xcc0]
    // 0x5ad41c: r0 = DefaultTypeTest()
    //     0x5ad41c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5ad420: ldur            x3, [fp, #-8]
    // 0x5ad424: LoadField: r0 = r3->field_f
    //     0x5ad424: ldur            w0, [x3, #0xf]
    // 0x5ad428: DecompressPointer r0
    //     0x5ad428: add             x0, x0, HEAP, lsl #32
    // 0x5ad42c: ldur            x1, [fp, #-0x10]
    // 0x5ad430: StoreField: r1->field_f = r0
    //     0x5ad430: stur            w0, [x1, #0xf]
    //     0x5ad434: ldurb           w16, [x1, #-1]
    //     0x5ad438: ldurb           w17, [x0, #-1]
    //     0x5ad43c: and             x16, x17, x16, lsr #2
    //     0x5ad440: tst             x16, HEAP, lsr #32
    //     0x5ad444: b.eq            #0x5ad44c
    //     0x5ad448: bl              #0xd6826c
    // 0x5ad44c: LoadField: r0 = r3->field_f
    //     0x5ad44c: ldur            w0, [x3, #0xf]
    // 0x5ad450: DecompressPointer r0
    //     0x5ad450: add             x0, x0, HEAP, lsl #32
    // 0x5ad454: cmp             w0, NULL
    // 0x5ad458: b.ne            #0x5ad48c
    // 0x5ad45c: ldr             x4, [fp, #0x18]
    // 0x5ad460: ldur            x0, [fp, #-0x18]
    // 0x5ad464: StoreField: r4->field_5f = r0
    //     0x5ad464: stur            w0, [x4, #0x5f]
    //     0x5ad468: ldurb           w16, [x4, #-1]
    //     0x5ad46c: ldurb           w17, [x0, #-1]
    //     0x5ad470: and             x16, x17, x16, lsr #2
    //     0x5ad474: tst             x16, HEAP, lsr #32
    //     0x5ad478: b.eq            #0x5ad480
    //     0x5ad47c: bl              #0xd682cc
    // 0x5ad480: mov             x2, x4
    // 0x5ad484: mov             x1, x3
    // 0x5ad488: b               #0x5ad504
    // 0x5ad48c: ldr             x4, [fp, #0x18]
    // 0x5ad490: LoadField: r5 = r0->field_17
    //     0x5ad490: ldur            w5, [x0, #0x17]
    // 0x5ad494: DecompressPointer r5
    //     0x5ad494: add             x5, x5, HEAP, lsl #32
    // 0x5ad498: stur            x5, [fp, #-0x10]
    // 0x5ad49c: cmp             w5, NULL
    // 0x5ad4a0: b.eq            #0x5ad530
    // 0x5ad4a4: mov             x0, x5
    // 0x5ad4a8: r2 = Null
    //     0x5ad4a8: mov             x2, NULL
    // 0x5ad4ac: r1 = Null
    //     0x5ad4ac: mov             x1, NULL
    // 0x5ad4b0: r4 = LoadClassIdInstr(r0)
    //     0x5ad4b0: ldur            x4, [x0, #-1]
    //     0x5ad4b4: ubfx            x4, x4, #0xc, #0x14
    // 0x5ad4b8: sub             x4, x4, #0x7f9
    // 0x5ad4bc: cmp             x4, #2
    // 0x5ad4c0: b.ls            #0x5ad4d8
    // 0x5ad4c4: r8 = SliverMultiBoxAdaptorParentData
    //     0x5ad4c4: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x5ad4c8: ldr             x8, [x8, #0x120]
    // 0x5ad4cc: r3 = Null
    //     0x5ad4cc: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4acd0] Null
    //     0x5ad4d0: ldr             x3, [x3, #0xcd0]
    // 0x5ad4d4: r0 = DefaultTypeTest()
    //     0x5ad4d4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5ad4d8: ldur            x0, [fp, #-0x18]
    // 0x5ad4dc: ldur            x1, [fp, #-0x10]
    // 0x5ad4e0: StoreField: r1->field_b = r0
    //     0x5ad4e0: stur            w0, [x1, #0xb]
    //     0x5ad4e4: ldurb           w16, [x1, #-1]
    //     0x5ad4e8: ldurb           w17, [x0, #-1]
    //     0x5ad4ec: and             x16, x17, x16, lsr #2
    //     0x5ad4f0: tst             x16, HEAP, lsr #32
    //     0x5ad4f4: b.eq            #0x5ad4fc
    //     0x5ad4f8: bl              #0xd6826c
    // 0x5ad4fc: ldr             x2, [fp, #0x18]
    // 0x5ad500: ldur            x1, [fp, #-8]
    // 0x5ad504: StoreField: r1->field_b = rNULL
    //     0x5ad504: stur            NULL, [x1, #0xb]
    // 0x5ad508: StoreField: r1->field_f = rNULL
    //     0x5ad508: stur            NULL, [x1, #0xf]
    // 0x5ad50c: LoadField: r1 = r2->field_53
    //     0x5ad50c: ldur            x1, [x2, #0x53]
    // 0x5ad510: sub             x3, x1, #1
    // 0x5ad514: StoreField: r2->field_53 = r3
    //     0x5ad514: stur            x3, [x2, #0x53]
    // 0x5ad518: r0 = Null
    //     0x5ad518: mov             x0, NULL
    // 0x5ad51c: LeaveFrame
    //     0x5ad51c: mov             SP, fp
    //     0x5ad520: ldp             fp, lr, [SP], #0x10
    // 0x5ad524: ret
    //     0x5ad524: ret             
    // 0x5ad528: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5ad528: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5ad52c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5ad52c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5ad530: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5ad530: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ remove(/* No info */) {
    // ** addr: 0x5e5f98, size: 0x54
    // 0x5e5f98: EnterFrame
    //     0x5e5f98: stp             fp, lr, [SP, #-0x10]!
    //     0x5e5f9c: mov             fp, SP
    // 0x5e5fa0: CheckStackOverflow
    //     0x5e5fa0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e5fa4: cmp             SP, x16
    //     0x5e5fa8: b.ls            #0x5e5fe4
    // 0x5e5fac: ldr             x16, [fp, #0x18]
    // 0x5e5fb0: ldr             lr, [fp, #0x10]
    // 0x5e5fb4: stp             lr, x16, [SP, #-0x10]!
    // 0x5e5fb8: r0 = _removeFromChildList()
    //     0x5e5fb8: bl              #0x5ad338  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] _RenderSliverMultiBoxAdaptor&RenderSliver&ContainerRenderObjectMixin::_removeFromChildList
    // 0x5e5fbc: add             SP, SP, #0x10
    // 0x5e5fc0: ldr             x16, [fp, #0x18]
    // 0x5e5fc4: ldr             lr, [fp, #0x10]
    // 0x5e5fc8: stp             lr, x16, [SP, #-0x10]!
    // 0x5e5fcc: r0 = dropChild()
    //     0x5e5fcc: bl              #0x5e5aec  ; [package:flutter/src/rendering/object.dart] RenderObject::dropChild
    // 0x5e5fd0: add             SP, SP, #0x10
    // 0x5e5fd4: r0 = Null
    //     0x5e5fd4: mov             x0, NULL
    // 0x5e5fd8: LeaveFrame
    //     0x5e5fd8: mov             SP, fp
    //     0x5e5fdc: ldp             fp, lr, [SP], #0x10
    // 0x5e5fe0: ret
    //     0x5e5fe0: ret             
    // 0x5e5fe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e5fe4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e5fe8: b               #0x5e5fac
  }
  _ insert(/* No info */) {
    // ** addr: 0x5e60a8, size: 0x5c
    // 0x5e60a8: EnterFrame
    //     0x5e60a8: stp             fp, lr, [SP, #-0x10]!
    //     0x5e60ac: mov             fp, SP
    // 0x5e60b0: CheckStackOverflow
    //     0x5e60b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e60b4: cmp             SP, x16
    //     0x5e60b8: b.ls            #0x5e60fc
    // 0x5e60bc: ldr             x16, [fp, #0x20]
    // 0x5e60c0: ldr             lr, [fp, #0x18]
    // 0x5e60c4: stp             lr, x16, [SP, #-0x10]!
    // 0x5e60c8: r0 = adoptChild()
    //     0x5e60c8: bl              #0x5e6104  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::adoptChild
    // 0x5e60cc: add             SP, SP, #0x10
    // 0x5e60d0: ldr             x16, [fp, #0x20]
    // 0x5e60d4: ldr             lr, [fp, #0x18]
    // 0x5e60d8: stp             lr, x16, [SP, #-0x10]!
    // 0x5e60dc: ldr             x16, [fp, #0x10]
    // 0x5e60e0: SaveReg r16
    //     0x5e60e0: str             x16, [SP, #-8]!
    // 0x5e60e4: r0 = _insertIntoChildList()
    //     0x5e60e4: bl              #0x5ad00c  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] _RenderSliverMultiBoxAdaptor&RenderSliver&ContainerRenderObjectMixin::_insertIntoChildList
    // 0x5e60e8: add             SP, SP, #0x18
    // 0x5e60ec: r0 = Null
    //     0x5e60ec: mov             x0, NULL
    // 0x5e60f0: LeaveFrame
    //     0x5e60f0: mov             SP, fp
    //     0x5e60f4: ldp             fp, lr, [SP], #0x10
    // 0x5e60f8: ret
    //     0x5e60f8: ret             
    // 0x5e60fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e60fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e6100: b               #0x5e60bc
  }
  _ visitChildren(/* No info */) {
    // ** addr: 0x675b74, size: 0xdc
    // 0x675b74: EnterFrame
    //     0x675b74: stp             fp, lr, [SP, #-0x10]!
    //     0x675b78: mov             fp, SP
    // 0x675b7c: AllocStack(0x10)
    //     0x675b7c: sub             SP, SP, #0x10
    // 0x675b80: CheckStackOverflow
    //     0x675b80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x675b84: cmp             SP, x16
    //     0x675b88: b.ls            #0x675c3c
    // 0x675b8c: ldr             x0, [fp, #0x18]
    // 0x675b90: LoadField: r1 = r0->field_5b
    //     0x675b90: ldur            w1, [x0, #0x5b]
    // 0x675b94: DecompressPointer r1
    //     0x675b94: add             x1, x1, HEAP, lsl #32
    // 0x675b98: stur            x1, [fp, #-8]
    // 0x675b9c: CheckStackOverflow
    //     0x675b9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x675ba0: cmp             SP, x16
    //     0x675ba4: b.ls            #0x675c44
    // 0x675ba8: cmp             w1, NULL
    // 0x675bac: b.eq            #0x675c2c
    // 0x675bb0: ldr             x16, [fp, #0x10]
    // 0x675bb4: stp             x1, x16, [SP, #-0x10]!
    // 0x675bb8: ldr             x0, [fp, #0x10]
    // 0x675bbc: ClosureCall
    //     0x675bbc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x675bc0: ldur            x2, [x0, #0x1f]
    //     0x675bc4: blr             x2
    // 0x675bc8: add             SP, SP, #0x10
    // 0x675bcc: ldur            x0, [fp, #-8]
    // 0x675bd0: LoadField: r3 = r0->field_17
    //     0x675bd0: ldur            w3, [x0, #0x17]
    // 0x675bd4: DecompressPointer r3
    //     0x675bd4: add             x3, x3, HEAP, lsl #32
    // 0x675bd8: stur            x3, [fp, #-0x10]
    // 0x675bdc: cmp             w3, NULL
    // 0x675be0: b.eq            #0x675c4c
    // 0x675be4: mov             x0, x3
    // 0x675be8: r2 = Null
    //     0x675be8: mov             x2, NULL
    // 0x675bec: r1 = Null
    //     0x675bec: mov             x1, NULL
    // 0x675bf0: r4 = LoadClassIdInstr(r0)
    //     0x675bf0: ldur            x4, [x0, #-1]
    //     0x675bf4: ubfx            x4, x4, #0xc, #0x14
    // 0x675bf8: sub             x4, x4, #0x7f9
    // 0x675bfc: cmp             x4, #2
    // 0x675c00: b.ls            #0x675c18
    // 0x675c04: r8 = SliverMultiBoxAdaptorParentData
    //     0x675c04: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x675c08: ldr             x8, [x8, #0x120]
    // 0x675c0c: r3 = Null
    //     0x675c0c: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ac70] Null
    //     0x675c10: ldr             x3, [x3, #0xc70]
    // 0x675c14: r0 = DefaultTypeTest()
    //     0x675c14: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x675c18: ldur            x1, [fp, #-0x10]
    // 0x675c1c: LoadField: r0 = r1->field_f
    //     0x675c1c: ldur            w0, [x1, #0xf]
    // 0x675c20: DecompressPointer r0
    //     0x675c20: add             x0, x0, HEAP, lsl #32
    // 0x675c24: mov             x1, x0
    // 0x675c28: b               #0x675b98
    // 0x675c2c: r0 = Null
    //     0x675c2c: mov             x0, NULL
    // 0x675c30: LeaveFrame
    //     0x675c30: mov             SP, fp
    //     0x675c34: ldp             fp, lr, [SP], #0x10
    // 0x675c38: ret
    //     0x675c38: ret             
    // 0x675c3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x675c3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x675c40: b               #0x675b8c
    // 0x675c44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x675c44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x675c48: b               #0x675ba8
    // 0x675c4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x675c4c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ redepthChildren(/* No info */) {
    // ** addr: 0x7926f8, size: 0xfc
    // 0x7926f8: EnterFrame
    //     0x7926f8: stp             fp, lr, [SP, #-0x10]!
    //     0x7926fc: mov             fp, SP
    // 0x792700: AllocStack(0x10)
    //     0x792700: sub             SP, SP, #0x10
    // 0x792704: CheckStackOverflow
    //     0x792704: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x792708: cmp             SP, x16
    //     0x79270c: b.ls            #0x7927e0
    // 0x792710: ldr             x1, [fp, #0x10]
    // 0x792714: LoadField: r0 = r1->field_5b
    //     0x792714: ldur            w0, [x1, #0x5b]
    // 0x792718: DecompressPointer r0
    //     0x792718: add             x0, x0, HEAP, lsl #32
    // 0x79271c: mov             x2, x0
    // 0x792720: stur            x2, [fp, #-8]
    // 0x792724: CheckStackOverflow
    //     0x792724: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x792728: cmp             SP, x16
    //     0x79272c: b.ls            #0x7927e8
    // 0x792730: cmp             w2, NULL
    // 0x792734: b.eq            #0x7927d0
    // 0x792738: LoadField: r0 = r2->field_7
    //     0x792738: ldur            x0, [x2, #7]
    // 0x79273c: LoadField: r3 = r1->field_7
    //     0x79273c: ldur            x3, [x1, #7]
    // 0x792740: cmp             x0, x3
    // 0x792744: b.gt            #0x792770
    // 0x792748: add             x0, x3, #1
    // 0x79274c: StoreField: r2->field_7 = r0
    //     0x79274c: stur            x0, [x2, #7]
    // 0x792750: r0 = LoadClassIdInstr(r2)
    //     0x792750: ldur            x0, [x2, #-1]
    //     0x792754: ubfx            x0, x0, #0xc, #0x14
    // 0x792758: SaveReg r2
    //     0x792758: str             x2, [SP, #-8]!
    // 0x79275c: r0 = GDT[cid_x0 + 0xbdf1]()
    //     0x79275c: mov             x17, #0xbdf1
    //     0x792760: add             lr, x0, x17
    //     0x792764: ldr             lr, [x21, lr, lsl #3]
    //     0x792768: blr             lr
    // 0x79276c: add             SP, SP, #8
    // 0x792770: ldur            x0, [fp, #-8]
    // 0x792774: LoadField: r3 = r0->field_17
    //     0x792774: ldur            w3, [x0, #0x17]
    // 0x792778: DecompressPointer r3
    //     0x792778: add             x3, x3, HEAP, lsl #32
    // 0x79277c: stur            x3, [fp, #-0x10]
    // 0x792780: cmp             w3, NULL
    // 0x792784: b.eq            #0x7927f0
    // 0x792788: mov             x0, x3
    // 0x79278c: r2 = Null
    //     0x79278c: mov             x2, NULL
    // 0x792790: r1 = Null
    //     0x792790: mov             x1, NULL
    // 0x792794: r4 = LoadClassIdInstr(r0)
    //     0x792794: ldur            x4, [x0, #-1]
    //     0x792798: ubfx            x4, x4, #0xc, #0x14
    // 0x79279c: sub             x4, x4, #0x7f9
    // 0x7927a0: cmp             x4, #2
    // 0x7927a4: b.ls            #0x7927bc
    // 0x7927a8: r8 = SliverMultiBoxAdaptorParentData
    //     0x7927a8: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x7927ac: ldr             x8, [x8, #0x120]
    // 0x7927b0: r3 = Null
    //     0x7927b0: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ac80] Null
    //     0x7927b4: ldr             x3, [x3, #0xc80]
    // 0x7927b8: r0 = DefaultTypeTest()
    //     0x7927b8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x7927bc: ldur            x1, [fp, #-0x10]
    // 0x7927c0: LoadField: r2 = r1->field_f
    //     0x7927c0: ldur            w2, [x1, #0xf]
    // 0x7927c4: DecompressPointer r2
    //     0x7927c4: add             x2, x2, HEAP, lsl #32
    // 0x7927c8: ldr             x1, [fp, #0x10]
    // 0x7927cc: b               #0x792720
    // 0x7927d0: r0 = Null
    //     0x7927d0: mov             x0, NULL
    // 0x7927d4: LeaveFrame
    //     0x7927d4: mov             SP, fp
    //     0x7927d8: ldp             fp, lr, [SP], #0x10
    // 0x7927dc: ret
    //     0x7927dc: ret             
    // 0x7927e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7927e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7927e4: b               #0x792710
    // 0x7927e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7927e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7927ec: b               #0x792730
    // 0x7927f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7927f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bc128, size: 0xf8
    // 0x9bc128: EnterFrame
    //     0x9bc128: stp             fp, lr, [SP, #-0x10]!
    //     0x9bc12c: mov             fp, SP
    // 0x9bc130: AllocStack(0x10)
    //     0x9bc130: sub             SP, SP, #0x10
    // 0x9bc134: CheckStackOverflow
    //     0x9bc134: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bc138: cmp             SP, x16
    //     0x9bc13c: b.ls            #0x9bc20c
    // 0x9bc140: ldr             x16, [fp, #0x18]
    // 0x9bc144: ldr             lr, [fp, #0x10]
    // 0x9bc148: stp             lr, x16, [SP, #-0x10]!
    // 0x9bc14c: r0 = attach()
    //     0x9bc14c: bl              #0x9bf794  ; [package:flutter/src/rendering/object.dart] RenderObject::attach
    // 0x9bc150: add             SP, SP, #0x10
    // 0x9bc154: ldr             x0, [fp, #0x18]
    // 0x9bc158: LoadField: r1 = r0->field_5b
    //     0x9bc158: ldur            w1, [x0, #0x5b]
    // 0x9bc15c: DecompressPointer r1
    //     0x9bc15c: add             x1, x1, HEAP, lsl #32
    // 0x9bc160: stur            x1, [fp, #-8]
    // 0x9bc164: CheckStackOverflow
    //     0x9bc164: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bc168: cmp             SP, x16
    //     0x9bc16c: b.ls            #0x9bc214
    // 0x9bc170: cmp             w1, NULL
    // 0x9bc174: b.eq            #0x9bc1fc
    // 0x9bc178: r0 = LoadClassIdInstr(r1)
    //     0x9bc178: ldur            x0, [x1, #-1]
    //     0x9bc17c: ubfx            x0, x0, #0xc, #0x14
    // 0x9bc180: ldr             x16, [fp, #0x10]
    // 0x9bc184: stp             x16, x1, [SP, #-0x10]!
    // 0x9bc188: r0 = GDT[cid_x0 + 0xaf1f]()
    //     0x9bc188: mov             x17, #0xaf1f
    //     0x9bc18c: add             lr, x0, x17
    //     0x9bc190: ldr             lr, [x21, lr, lsl #3]
    //     0x9bc194: blr             lr
    // 0x9bc198: add             SP, SP, #0x10
    // 0x9bc19c: ldur            x0, [fp, #-8]
    // 0x9bc1a0: LoadField: r3 = r0->field_17
    //     0x9bc1a0: ldur            w3, [x0, #0x17]
    // 0x9bc1a4: DecompressPointer r3
    //     0x9bc1a4: add             x3, x3, HEAP, lsl #32
    // 0x9bc1a8: stur            x3, [fp, #-0x10]
    // 0x9bc1ac: cmp             w3, NULL
    // 0x9bc1b0: b.eq            #0x9bc21c
    // 0x9bc1b4: mov             x0, x3
    // 0x9bc1b8: r2 = Null
    //     0x9bc1b8: mov             x2, NULL
    // 0x9bc1bc: r1 = Null
    //     0x9bc1bc: mov             x1, NULL
    // 0x9bc1c0: r4 = LoadClassIdInstr(r0)
    //     0x9bc1c0: ldur            x4, [x0, #-1]
    //     0x9bc1c4: ubfx            x4, x4, #0xc, #0x14
    // 0x9bc1c8: sub             x4, x4, #0x7f9
    // 0x9bc1cc: cmp             x4, #2
    // 0x9bc1d0: b.ls            #0x9bc1e8
    // 0x9bc1d4: r8 = SliverMultiBoxAdaptorParentData
    //     0x9bc1d4: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x9bc1d8: ldr             x8, [x8, #0x120]
    // 0x9bc1dc: r3 = Null
    //     0x9bc1dc: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4aca0] Null
    //     0x9bc1e0: ldr             x3, [x3, #0xca0]
    // 0x9bc1e4: r0 = DefaultTypeTest()
    //     0x9bc1e4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bc1e8: ldur            x1, [fp, #-0x10]
    // 0x9bc1ec: LoadField: r0 = r1->field_f
    //     0x9bc1ec: ldur            w0, [x1, #0xf]
    // 0x9bc1f0: DecompressPointer r0
    //     0x9bc1f0: add             x0, x0, HEAP, lsl #32
    // 0x9bc1f4: mov             x1, x0
    // 0x9bc1f8: b               #0x9bc160
    // 0x9bc1fc: r0 = Null
    //     0x9bc1fc: mov             x0, NULL
    // 0x9bc200: LeaveFrame
    //     0x9bc200: mov             SP, fp
    //     0x9bc204: ldp             fp, lr, [SP], #0x10
    // 0x9bc208: ret
    //     0x9bc208: ret             
    // 0x9bc20c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bc20c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bc210: b               #0x9bc140
    // 0x9bc214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bc214: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bc218: b               #0x9bc170
    // 0x9bc21c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9bc21c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ detach(/* No info */) {
    // ** addr: 0xa65800, size: 0xf0
    // 0xa65800: EnterFrame
    //     0xa65800: stp             fp, lr, [SP, #-0x10]!
    //     0xa65804: mov             fp, SP
    // 0xa65808: AllocStack(0x10)
    //     0xa65808: sub             SP, SP, #0x10
    // 0xa6580c: CheckStackOverflow
    //     0xa6580c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa65810: cmp             SP, x16
    //     0xa65814: b.ls            #0xa658dc
    // 0xa65818: ldr             x16, [fp, #0x10]
    // 0xa6581c: SaveReg r16
    //     0xa6581c: str             x16, [SP, #-8]!
    // 0xa65820: r0 = detach()
    //     0xa65820: bl              #0xa6ade0  ; [package:flutter/src/foundation/node.dart] AbstractNode::detach
    // 0xa65824: add             SP, SP, #8
    // 0xa65828: ldr             x0, [fp, #0x10]
    // 0xa6582c: LoadField: r1 = r0->field_5b
    //     0xa6582c: ldur            w1, [x0, #0x5b]
    // 0xa65830: DecompressPointer r1
    //     0xa65830: add             x1, x1, HEAP, lsl #32
    // 0xa65834: stur            x1, [fp, #-8]
    // 0xa65838: CheckStackOverflow
    //     0xa65838: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6583c: cmp             SP, x16
    //     0xa65840: b.ls            #0xa658e4
    // 0xa65844: cmp             w1, NULL
    // 0xa65848: b.eq            #0xa658cc
    // 0xa6584c: r0 = LoadClassIdInstr(r1)
    //     0xa6584c: ldur            x0, [x1, #-1]
    //     0xa65850: ubfx            x0, x0, #0xc, #0x14
    // 0xa65854: SaveReg r1
    //     0xa65854: str             x1, [SP, #-8]!
    // 0xa65858: r0 = GDT[cid_x0 + 0xa3cc]()
    //     0xa65858: mov             x17, #0xa3cc
    //     0xa6585c: add             lr, x0, x17
    //     0xa65860: ldr             lr, [x21, lr, lsl #3]
    //     0xa65864: blr             lr
    // 0xa65868: add             SP, SP, #8
    // 0xa6586c: ldur            x0, [fp, #-8]
    // 0xa65870: LoadField: r3 = r0->field_17
    //     0xa65870: ldur            w3, [x0, #0x17]
    // 0xa65874: DecompressPointer r3
    //     0xa65874: add             x3, x3, HEAP, lsl #32
    // 0xa65878: stur            x3, [fp, #-0x10]
    // 0xa6587c: cmp             w3, NULL
    // 0xa65880: b.eq            #0xa658ec
    // 0xa65884: mov             x0, x3
    // 0xa65888: r2 = Null
    //     0xa65888: mov             x2, NULL
    // 0xa6588c: r1 = Null
    //     0xa6588c: mov             x1, NULL
    // 0xa65890: r4 = LoadClassIdInstr(r0)
    //     0xa65890: ldur            x4, [x0, #-1]
    //     0xa65894: ubfx            x4, x4, #0xc, #0x14
    // 0xa65898: sub             x4, x4, #0x7f9
    // 0xa6589c: cmp             x4, #2
    // 0xa658a0: b.ls            #0xa658b8
    // 0xa658a4: r8 = SliverMultiBoxAdaptorParentData
    //     0xa658a4: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0xa658a8: ldr             x8, [x8, #0x120]
    // 0xa658ac: r3 = Null
    //     0xa658ac: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ac90] Null
    //     0xa658b0: ldr             x3, [x3, #0xc90]
    // 0xa658b4: r0 = DefaultTypeTest()
    //     0xa658b4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa658b8: ldur            x1, [fp, #-0x10]
    // 0xa658bc: LoadField: r0 = r1->field_f
    //     0xa658bc: ldur            w0, [x1, #0xf]
    // 0xa658c0: DecompressPointer r0
    //     0xa658c0: add             x0, x0, HEAP, lsl #32
    // 0xa658c4: mov             x1, x0
    // 0xa658c8: b               #0xa65834
    // 0xa658cc: r0 = Null
    //     0xa658cc: mov             x0, NULL
    // 0xa658d0: LeaveFrame
    //     0xa658d0: mov             SP, fp
    //     0xa658d4: ldp             fp, lr, [SP], #0x10
    // 0xa658d8: ret
    //     0xa658d8: ret             
    // 0xa658dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa658dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa658e0: b               #0xa65818
    // 0xa658e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa658e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa658e8: b               #0xa65844
    // 0xa658ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa658ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2581, size: 0x64, field offset: 0x64
//   transformed mixin,
abstract class _RenderSliverMultiBoxAdaptor&RenderSliver&ContainerRenderObjectMixin&RenderSliverHelpers extends _RenderSliverMultiBoxAdaptor&RenderSliver&ContainerRenderObjectMixin
     with RenderSliverHelpers {

  _ applyPaintTransformForBoxChild(/* No info */) {
    // ** addr: 0x6bb950, size: 0x2d4
    // 0x6bb950: EnterFrame
    //     0x6bb950: stp             fp, lr, [SP, #-0x10]!
    //     0x6bb954: mov             fp, SP
    // 0x6bb958: AllocStack(0x20)
    //     0x6bb958: sub             SP, SP, #0x20
    // 0x6bb95c: CheckStackOverflow
    //     0x6bb95c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bb960: cmp             SP, x16
    //     0x6bb964: b.ls            #0x6bbbfc
    // 0x6bb968: ldr             x3, [fp, #0x20]
    // 0x6bb96c: LoadField: r4 = r3->field_27
    //     0x6bb96c: ldur            w4, [x3, #0x27]
    // 0x6bb970: DecompressPointer r4
    //     0x6bb970: add             x4, x4, HEAP, lsl #32
    // 0x6bb974: stur            x4, [fp, #-8]
    // 0x6bb978: cmp             w4, NULL
    // 0x6bb97c: b.eq            #0x6bbbc4
    // 0x6bb980: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6bb980: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6bb984: ldr             x5, [x5, #0x1e8]
    // 0x6bb988: mov             x0, x4
    // 0x6bb98c: r2 = Null
    //     0x6bb98c: mov             x2, NULL
    // 0x6bb990: r1 = Null
    //     0x6bb990: mov             x1, NULL
    // 0x6bb994: r4 = LoadClassIdInstr(r0)
    //     0x6bb994: ldur            x4, [x0, #-1]
    //     0x6bb998: ubfx            x4, x4, #0xc, #0x14
    // 0x6bb99c: cmp             x4, #0x80c
    // 0x6bb9a0: b.eq            #0x6bb9b8
    // 0x6bb9a4: r8 = SliverConstraints
    //     0x6bb9a4: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x6bb9a8: ldr             x8, [x8, #0x5a8]
    // 0x6bb9ac: r3 = Null
    //     0x6bb9ac: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4adc0] Null
    //     0x6bb9b0: ldr             x3, [x3, #0xdc0]
    // 0x6bb9b4: r0 = DefaultTypeTest()
    //     0x6bb9b4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6bb9b8: ldur            x0, [fp, #-8]
    // 0x6bb9bc: LoadField: r1 = r0->field_7
    //     0x6bb9bc: ldur            w1, [x0, #7]
    // 0x6bb9c0: DecompressPointer r1
    //     0x6bb9c0: add             x1, x1, HEAP, lsl #32
    // 0x6bb9c4: LoadField: r2 = r1->field_7
    //     0x6bb9c4: ldur            x2, [x1, #7]
    // 0x6bb9c8: cmp             x2, #1
    // 0x6bb9cc: b.gt            #0x6bb9dc
    // 0x6bb9d0: cmp             x2, #0
    // 0x6bb9d4: b.gt            #0x6bb9e4
    // 0x6bb9d8: b               #0x6bb9ec
    // 0x6bb9dc: cmp             x2, #2
    // 0x6bb9e0: b.gt            #0x6bb9ec
    // 0x6bb9e4: r1 = true
    //     0x6bb9e4: add             x1, NULL, #0x20  ; true
    // 0x6bb9e8: b               #0x6bb9f0
    // 0x6bb9ec: r1 = false
    //     0x6bb9ec: add             x1, NULL, #0x30  ; false
    // 0x6bb9f0: LoadField: r2 = r0->field_b
    //     0x6bb9f0: ldur            w2, [x0, #0xb]
    // 0x6bb9f4: DecompressPointer r2
    //     0x6bb9f4: add             x2, x2, HEAP, lsl #32
    // 0x6bb9f8: LoadField: r0 = r2->field_7
    //     0x6bb9f8: ldur            x0, [x2, #7]
    // 0x6bb9fc: cmp             x0, #0
    // 0x6bba00: b.le            #0x6bba0c
    // 0x6bba04: eor             x0, x1, #0x10
    // 0x6bba08: mov             x1, x0
    // 0x6bba0c: ldr             x0, [fp, #0x20]
    // 0x6bba10: stur            x1, [fp, #-8]
    // 0x6bba14: ldr             x16, [fp, #0x18]
    // 0x6bba18: stp             x16, x0, [SP, #-0x10]!
    // 0x6bba1c: r0 = childMainAxisPosition()
    //     0x6bba1c: bl              #0xbcdb94  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::childMainAxisPosition
    // 0x6bba20: add             SP, SP, #0x10
    // 0x6bba24: ldr             x1, [fp, #0x20]
    // 0x6bba28: stur            d0, [fp, #-0x20]
    // 0x6bba2c: r0 = LoadClassIdInstr(r1)
    //     0x6bba2c: ldur            x0, [x1, #-1]
    //     0x6bba30: ubfx            x0, x0, #0xc, #0x14
    // 0x6bba34: ldr             x16, [fp, #0x18]
    // 0x6bba38: stp             x16, x1, [SP, #-0x10]!
    // 0x6bba3c: r0 = GDT[cid_x0 + 0x1dd6]()
    //     0x6bba3c: mov             x17, #0x1dd6
    //     0x6bba40: add             lr, x0, x17
    //     0x6bba44: ldr             lr, [x21, lr, lsl #3]
    //     0x6bba48: blr             lr
    // 0x6bba4c: add             SP, SP, #0x10
    // 0x6bba50: mov             x4, x0
    // 0x6bba54: ldr             x3, [fp, #0x20]
    // 0x6bba58: stur            x4, [fp, #-0x18]
    // 0x6bba5c: LoadField: r5 = r3->field_27
    //     0x6bba5c: ldur            w5, [x3, #0x27]
    // 0x6bba60: DecompressPointer r5
    //     0x6bba60: add             x5, x5, HEAP, lsl #32
    // 0x6bba64: stur            x5, [fp, #-0x10]
    // 0x6bba68: cmp             w5, NULL
    // 0x6bba6c: b.eq            #0x6bbbdc
    // 0x6bba70: mov             x0, x5
    // 0x6bba74: r2 = Null
    //     0x6bba74: mov             x2, NULL
    // 0x6bba78: r1 = Null
    //     0x6bba78: mov             x1, NULL
    // 0x6bba7c: r4 = LoadClassIdInstr(r0)
    //     0x6bba7c: ldur            x4, [x0, #-1]
    //     0x6bba80: ubfx            x4, x4, #0xc, #0x14
    // 0x6bba84: cmp             x4, #0x80c
    // 0x6bba88: b.eq            #0x6bbaa0
    // 0x6bba8c: r8 = SliverConstraints
    //     0x6bba8c: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x6bba90: ldr             x8, [x8, #0x5a8]
    // 0x6bba94: r3 = Null
    //     0x6bba94: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4add0] Null
    //     0x6bba98: ldr             x3, [x3, #0xdd0]
    // 0x6bba9c: r0 = DefaultTypeTest()
    //     0x6bba9c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6bbaa0: ldur            x16, [fp, #-0x10]
    // 0x6bbaa4: SaveReg r16
    //     0x6bbaa4: str             x16, [SP, #-8]!
    // 0x6bbaa8: r0 = axis()
    //     0x6bbaa8: bl              #0x643150  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0x6bbaac: add             SP, SP, #8
    // 0x6bbab0: LoadField: r1 = r0->field_7
    //     0x6bbab0: ldur            x1, [x0, #7]
    // 0x6bbab4: cmp             x1, #0
    // 0x6bbab8: b.gt            #0x6bbb54
    // 0x6bbabc: ldur            x0, [fp, #-8]
    // 0x6bbac0: tbz             w0, #4, #0x6bbb08
    // 0x6bbac4: ldr             x1, [fp, #0x20]
    // 0x6bbac8: ldr             x2, [fp, #0x18]
    // 0x6bbacc: ldur            d0, [fp, #-0x20]
    // 0x6bbad0: LoadField: r0 = r1->field_4f
    //     0x6bbad0: ldur            w0, [x1, #0x4f]
    // 0x6bbad4: DecompressPointer r0
    //     0x6bbad4: add             x0, x0, HEAP, lsl #32
    // 0x6bbad8: cmp             w0, NULL
    // 0x6bbadc: b.eq            #0x6bbc04
    // 0x6bbae0: LoadField: d1 = r0->field_17
    //     0x6bbae0: ldur            d1, [x0, #0x17]
    // 0x6bbae4: LoadField: r0 = r2->field_57
    //     0x6bbae4: ldur            w0, [x2, #0x57]
    // 0x6bbae8: DecompressPointer r0
    //     0x6bbae8: add             x0, x0, HEAP, lsl #32
    // 0x6bbaec: cmp             w0, NULL
    // 0x6bbaf0: b.eq            #0x6bbc08
    // 0x6bbaf4: LoadField: d2 = r0->field_7
    //     0x6bbaf4: ldur            d2, [x0, #7]
    // 0x6bbaf8: fsub            d3, d1, d2
    // 0x6bbafc: fsub            d1, d3, d0
    // 0x6bbb00: mov             v0.16b, v1.16b
    // 0x6bbb04: b               #0x6bbb0c
    // 0x6bbb08: ldur            d0, [fp, #-0x20]
    // 0x6bbb0c: ldur            x3, [fp, #-0x18]
    // 0x6bbb10: LoadField: d1 = r3->field_7
    //     0x6bbb10: ldur            d1, [x3, #7]
    // 0x6bbb14: r0 = inline_Allocate_Double()
    //     0x6bbb14: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6bbb18: add             x0, x0, #0x10
    //     0x6bbb1c: cmp             x1, x0
    //     0x6bbb20: b.ls            #0x6bbc0c
    //     0x6bbb24: str             x0, [THR, #0x60]  ; THR::top
    //     0x6bbb28: sub             x0, x0, #0xf
    //     0x6bbb2c: mov             x1, #0xd108
    //     0x6bbb30: movk            x1, #3, lsl #16
    //     0x6bbb34: stur            x1, [x0, #-1]
    // 0x6bbb38: StoreField: r0->field_7 = d0
    //     0x6bbb38: stur            d0, [x0, #7]
    // 0x6bbb3c: ldr             x16, [fp, #0x10]
    // 0x6bbb40: stp             x0, x16, [SP, #-0x10]!
    // 0x6bbb44: SaveReg d1
    //     0x6bbb44: str             d1, [SP, #-8]!
    // 0x6bbb48: r0 = translate()
    //     0x6bbb48: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0x6bbb4c: add             SP, SP, #0x18
    // 0x6bbb50: b               #0x6bbbb4
    // 0x6bbb54: ldr             x1, [fp, #0x20]
    // 0x6bbb58: ldr             x2, [fp, #0x18]
    // 0x6bbb5c: ldur            d0, [fp, #-0x20]
    // 0x6bbb60: ldur            x3, [fp, #-0x18]
    // 0x6bbb64: ldur            x0, [fp, #-8]
    // 0x6bbb68: tbz             w0, #4, #0x6bbba0
    // 0x6bbb6c: LoadField: r0 = r1->field_4f
    //     0x6bbb6c: ldur            w0, [x1, #0x4f]
    // 0x6bbb70: DecompressPointer r0
    //     0x6bbb70: add             x0, x0, HEAP, lsl #32
    // 0x6bbb74: cmp             w0, NULL
    // 0x6bbb78: b.eq            #0x6bbc1c
    // 0x6bbb7c: LoadField: d1 = r0->field_17
    //     0x6bbb7c: ldur            d1, [x0, #0x17]
    // 0x6bbb80: LoadField: r0 = r2->field_57
    //     0x6bbb80: ldur            w0, [x2, #0x57]
    // 0x6bbb84: DecompressPointer r0
    //     0x6bbb84: add             x0, x0, HEAP, lsl #32
    // 0x6bbb88: cmp             w0, NULL
    // 0x6bbb8c: b.eq            #0x6bbc20
    // 0x6bbb90: LoadField: d2 = r0->field_f
    //     0x6bbb90: ldur            d2, [x0, #0xf]
    // 0x6bbb94: fsub            d3, d1, d2
    // 0x6bbb98: fsub            d1, d3, d0
    // 0x6bbb9c: mov             v0.16b, v1.16b
    // 0x6bbba0: ldr             x16, [fp, #0x10]
    // 0x6bbba4: stp             x3, x16, [SP, #-0x10]!
    // 0x6bbba8: SaveReg d0
    //     0x6bbba8: str             d0, [SP, #-8]!
    // 0x6bbbac: r0 = translate()
    //     0x6bbbac: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0x6bbbb0: add             SP, SP, #0x18
    // 0x6bbbb4: r0 = Null
    //     0x6bbbb4: mov             x0, NULL
    // 0x6bbbb8: LeaveFrame
    //     0x6bbbb8: mov             SP, fp
    //     0x6bbbbc: ldp             fp, lr, [SP], #0x10
    // 0x6bbbc0: ret
    //     0x6bbbc0: ret             
    // 0x6bbbc4: r0 = StateError()
    //     0x6bbbc4: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6bbbc8: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6bbbc8: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6bbbcc: ldr             x5, [x5, #0x1e8]
    // 0x6bbbd0: StoreField: r0->field_b = r5
    //     0x6bbbd0: stur            w5, [x0, #0xb]
    // 0x6bbbd4: r0 = Throw()
    //     0x6bbbd4: bl              #0xd67e38  ; ThrowStub
    // 0x6bbbd8: brk             #0
    // 0x6bbbdc: r0 = StateError()
    //     0x6bbbdc: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6bbbe0: mov             x1, x0
    // 0x6bbbe4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6bbbe4: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6bbbe8: ldr             x0, [x0, #0x1e8]
    // 0x6bbbec: StoreField: r1->field_b = r0
    //     0x6bbbec: stur            w0, [x1, #0xb]
    // 0x6bbbf0: mov             x0, x1
    // 0x6bbbf4: r0 = Throw()
    //     0x6bbbf4: bl              #0xd67e38  ; ThrowStub
    // 0x6bbbf8: brk             #0
    // 0x6bbbfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bbbfc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bbc00: b               #0x6bb968
    // 0x6bbc04: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6bbc04: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6bbc08: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6bbc08: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6bbc0c: stp             q0, q1, [SP, #-0x20]!
    // 0x6bbc10: r0 = AllocateDouble()
    //     0x6bbc10: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6bbc14: ldp             q0, q1, [SP], #0x20
    // 0x6bbc18: b               #0x6bbb38
    // 0x6bbc1c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6bbc1c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6bbc20: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6bbc20: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ hitTestBoxChild(/* No info */) {
    // ** addr: 0xa8b45c, size: 0x3f8
    // 0xa8b45c: EnterFrame
    //     0xa8b45c: stp             fp, lr, [SP, #-0x10]!
    //     0xa8b460: mov             fp, SP
    // 0xa8b464: AllocStack(0x48)
    //     0xa8b464: sub             SP, SP, #0x48
    // 0xa8b468: CheckStackOverflow
    //     0xa8b468: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8b46c: cmp             SP, x16
    //     0xa8b470: b.ls            #0xa8b83c
    // 0xa8b474: r1 = 2
    //     0xa8b474: mov             x1, #2
    // 0xa8b478: r0 = AllocateContext()
    //     0xa8b478: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa8b47c: mov             x4, x0
    // 0xa8b480: ldr             x3, [fp, #0x20]
    // 0xa8b484: stur            x4, [fp, #-0x10]
    // 0xa8b488: StoreField: r4->field_f = r3
    //     0xa8b488: stur            w3, [x4, #0xf]
    // 0xa8b48c: ldr             x5, [fp, #0x30]
    // 0xa8b490: LoadField: r6 = r5->field_27
    //     0xa8b490: ldur            w6, [x5, #0x27]
    // 0xa8b494: DecompressPointer r6
    //     0xa8b494: add             x6, x6, HEAP, lsl #32
    // 0xa8b498: stur            x6, [fp, #-8]
    // 0xa8b49c: cmp             w6, NULL
    // 0xa8b4a0: b.eq            #0xa8b804
    // 0xa8b4a4: r7 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xa8b4a4: add             x7, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0xa8b4a8: ldr             x7, [x7, #0x1e8]
    // 0xa8b4ac: mov             x0, x6
    // 0xa8b4b0: r2 = Null
    //     0xa8b4b0: mov             x2, NULL
    // 0xa8b4b4: r1 = Null
    //     0xa8b4b4: mov             x1, NULL
    // 0xa8b4b8: r4 = LoadClassIdInstr(r0)
    //     0xa8b4b8: ldur            x4, [x0, #-1]
    //     0xa8b4bc: ubfx            x4, x4, #0xc, #0x14
    // 0xa8b4c0: cmp             x4, #0x80c
    // 0xa8b4c4: b.eq            #0xa8b4dc
    // 0xa8b4c8: r8 = SliverConstraints
    //     0xa8b4c8: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0xa8b4cc: ldr             x8, [x8, #0x5a8]
    // 0xa8b4d0: r3 = Null
    //     0xa8b4d0: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fbb8] Null
    //     0xa8b4d4: ldr             x3, [x3, #0xbb8]
    // 0xa8b4d8: r0 = DefaultTypeTest()
    //     0xa8b4d8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa8b4dc: ldur            x0, [fp, #-8]
    // 0xa8b4e0: LoadField: r1 = r0->field_7
    //     0xa8b4e0: ldur            w1, [x0, #7]
    // 0xa8b4e4: DecompressPointer r1
    //     0xa8b4e4: add             x1, x1, HEAP, lsl #32
    // 0xa8b4e8: LoadField: r2 = r1->field_7
    //     0xa8b4e8: ldur            x2, [x1, #7]
    // 0xa8b4ec: cmp             x2, #1
    // 0xa8b4f0: b.gt            #0xa8b500
    // 0xa8b4f4: cmp             x2, #0
    // 0xa8b4f8: b.gt            #0xa8b508
    // 0xa8b4fc: b               #0xa8b510
    // 0xa8b500: cmp             x2, #2
    // 0xa8b504: b.gt            #0xa8b510
    // 0xa8b508: r1 = true
    //     0xa8b508: add             x1, NULL, #0x20  ; true
    // 0xa8b50c: b               #0xa8b514
    // 0xa8b510: r1 = false
    //     0xa8b510: add             x1, NULL, #0x30  ; false
    // 0xa8b514: LoadField: r2 = r0->field_b
    //     0xa8b514: ldur            w2, [x0, #0xb]
    // 0xa8b518: DecompressPointer r2
    //     0xa8b518: add             x2, x2, HEAP, lsl #32
    // 0xa8b51c: LoadField: r0 = r2->field_7
    //     0xa8b51c: ldur            x0, [x2, #7]
    // 0xa8b520: cmp             x0, #0
    // 0xa8b524: b.gt            #0xa8b530
    // 0xa8b528: mov             x3, x1
    // 0xa8b52c: b               #0xa8b538
    // 0xa8b530: eor             x0, x1, #0x10
    // 0xa8b534: mov             x3, x0
    // 0xa8b538: ldr             x0, [fp, #0x30]
    // 0xa8b53c: ldr             x1, [fp, #0x18]
    // 0xa8b540: ldr             d0, [fp, #0x10]
    // 0xa8b544: ldur            x2, [fp, #-0x10]
    // 0xa8b548: stur            x3, [fp, #-8]
    // 0xa8b54c: ldr             x16, [fp, #0x20]
    // 0xa8b550: stp             x16, x0, [SP, #-0x10]!
    // 0xa8b554: r0 = childMainAxisPosition()
    //     0xa8b554: bl              #0xbcdb94  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::childMainAxisPosition
    // 0xa8b558: add             SP, SP, #0x10
    // 0xa8b55c: ldur            x2, [fp, #-0x10]
    // 0xa8b560: stur            d0, [fp, #-0x20]
    // 0xa8b564: LoadField: r0 = r2->field_f
    //     0xa8b564: ldur            w0, [x2, #0xf]
    // 0xa8b568: DecompressPointer r0
    //     0xa8b568: add             x0, x0, HEAP, lsl #32
    // 0xa8b56c: ldr             x1, [fp, #0x30]
    // 0xa8b570: r3 = LoadClassIdInstr(r1)
    //     0xa8b570: ldur            x3, [x1, #-1]
    //     0xa8b574: ubfx            x3, x3, #0xc, #0x14
    // 0xa8b578: stp             x0, x1, [SP, #-0x10]!
    // 0xa8b57c: mov             x0, x3
    // 0xa8b580: r0 = GDT[cid_x0 + 0x1dd6]()
    //     0xa8b580: mov             x17, #0x1dd6
    //     0xa8b584: add             lr, x0, x17
    //     0xa8b588: ldr             lr, [x21, lr, lsl #3]
    //     0xa8b58c: blr             lr
    // 0xa8b590: add             SP, SP, #0x10
    // 0xa8b594: ldr             d1, [fp, #0x10]
    // 0xa8b598: ldur            d0, [fp, #-0x20]
    // 0xa8b59c: fsub            d2, d1, d0
    // 0xa8b5a0: ldr             x1, [fp, #0x18]
    // 0xa8b5a4: stur            d2, [fp, #-0x38]
    // 0xa8b5a8: LoadField: d1 = r1->field_7
    //     0xa8b5a8: ldur            d1, [x1, #7]
    // 0xa8b5ac: LoadField: d3 = r0->field_7
    //     0xa8b5ac: ldur            d3, [x0, #7]
    // 0xa8b5b0: stur            d3, [fp, #-0x30]
    // 0xa8b5b4: fsub            d4, d1, d3
    // 0xa8b5b8: ldur            x3, [fp, #-0x10]
    // 0xa8b5bc: stur            d4, [fp, #-0x28]
    // 0xa8b5c0: StoreField: r3->field_13 = rNULL
    //     0xa8b5c0: stur            NULL, [x3, #0x13]
    // 0xa8b5c4: ldr             x4, [fp, #0x30]
    // 0xa8b5c8: LoadField: r5 = r4->field_27
    //     0xa8b5c8: ldur            w5, [x4, #0x27]
    // 0xa8b5cc: DecompressPointer r5
    //     0xa8b5cc: add             x5, x5, HEAP, lsl #32
    // 0xa8b5d0: stur            x5, [fp, #-0x18]
    // 0xa8b5d4: cmp             w5, NULL
    // 0xa8b5d8: b.eq            #0xa8b81c
    // 0xa8b5dc: mov             x0, x5
    // 0xa8b5e0: r2 = Null
    //     0xa8b5e0: mov             x2, NULL
    // 0xa8b5e4: r1 = Null
    //     0xa8b5e4: mov             x1, NULL
    // 0xa8b5e8: r4 = LoadClassIdInstr(r0)
    //     0xa8b5e8: ldur            x4, [x0, #-1]
    //     0xa8b5ec: ubfx            x4, x4, #0xc, #0x14
    // 0xa8b5f0: cmp             x4, #0x80c
    // 0xa8b5f4: b.eq            #0xa8b60c
    // 0xa8b5f8: r8 = SliverConstraints
    //     0xa8b5f8: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0xa8b5fc: ldr             x8, [x8, #0x5a8]
    // 0xa8b600: r3 = Null
    //     0xa8b600: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fbc8] Null
    //     0xa8b604: ldr             x3, [x3, #0xbc8]
    // 0xa8b608: r0 = DefaultTypeTest()
    //     0xa8b608: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa8b60c: ldur            x16, [fp, #-0x18]
    // 0xa8b610: SaveReg r16
    //     0xa8b610: str             x16, [SP, #-8]!
    // 0xa8b614: r0 = axis()
    //     0xa8b614: bl              #0x643150  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0xa8b618: add             SP, SP, #8
    // 0xa8b61c: LoadField: r1 = r0->field_7
    //     0xa8b61c: ldur            x1, [x0, #7]
    // 0xa8b620: cmp             x1, #0
    // 0xa8b624: b.gt            #0xa8b700
    // 0xa8b628: ldur            x0, [fp, #-8]
    // 0xa8b62c: tbz             w0, #4, #0xa8b688
    // 0xa8b630: ldr             x1, [fp, #0x30]
    // 0xa8b634: ldur            x2, [fp, #-0x10]
    // 0xa8b638: ldur            d0, [fp, #-0x20]
    // 0xa8b63c: ldur            d1, [fp, #-0x38]
    // 0xa8b640: LoadField: r0 = r2->field_f
    //     0xa8b640: ldur            w0, [x2, #0xf]
    // 0xa8b644: DecompressPointer r0
    //     0xa8b644: add             x0, x0, HEAP, lsl #32
    // 0xa8b648: LoadField: r3 = r0->field_57
    //     0xa8b648: ldur            w3, [x0, #0x57]
    // 0xa8b64c: DecompressPointer r3
    //     0xa8b64c: add             x3, x3, HEAP, lsl #32
    // 0xa8b650: cmp             w3, NULL
    // 0xa8b654: b.eq            #0xa8b844
    // 0xa8b658: LoadField: d2 = r3->field_7
    //     0xa8b658: ldur            d2, [x3, #7]
    // 0xa8b65c: fsub            d3, d2, d1
    // 0xa8b660: LoadField: r0 = r1->field_4f
    //     0xa8b660: ldur            w0, [x1, #0x4f]
    // 0xa8b664: DecompressPointer r0
    //     0xa8b664: add             x0, x0, HEAP, lsl #32
    // 0xa8b668: cmp             w0, NULL
    // 0xa8b66c: b.eq            #0xa8b848
    // 0xa8b670: LoadField: d1 = r0->field_17
    //     0xa8b670: ldur            d1, [x0, #0x17]
    // 0xa8b674: fsub            d4, d1, d2
    // 0xa8b678: fsub            d1, d4, d0
    // 0xa8b67c: mov             v2.16b, v3.16b
    // 0xa8b680: mov             v3.16b, v1.16b
    // 0xa8b684: b               #0xa8b69c
    // 0xa8b688: ldur            x2, [fp, #-0x10]
    // 0xa8b68c: ldur            d0, [fp, #-0x20]
    // 0xa8b690: ldur            d1, [fp, #-0x38]
    // 0xa8b694: mov             v3.16b, v0.16b
    // 0xa8b698: mov             v2.16b, v1.16b
    // 0xa8b69c: ldur            d1, [fp, #-0x28]
    // 0xa8b6a0: ldur            d0, [fp, #-0x30]
    // 0xa8b6a4: stur            d3, [fp, #-0x40]
    // 0xa8b6a8: stur            d2, [fp, #-0x48]
    // 0xa8b6ac: r0 = Offset()
    //     0xa8b6ac: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa8b6b0: ldur            d0, [fp, #-0x40]
    // 0xa8b6b4: stur            x0, [fp, #-0x18]
    // 0xa8b6b8: StoreField: r0->field_7 = d0
    //     0xa8b6b8: stur            d0, [x0, #7]
    // 0xa8b6bc: ldur            d2, [fp, #-0x30]
    // 0xa8b6c0: StoreField: r0->field_f = d2
    //     0xa8b6c0: stur            d2, [x0, #0xf]
    // 0xa8b6c4: r0 = Offset()
    //     0xa8b6c4: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa8b6c8: ldur            d0, [fp, #-0x48]
    // 0xa8b6cc: StoreField: r0->field_7 = d0
    //     0xa8b6cc: stur            d0, [x0, #7]
    // 0xa8b6d0: ldur            d3, [fp, #-0x28]
    // 0xa8b6d4: StoreField: r0->field_f = d3
    //     0xa8b6d4: stur            d3, [x0, #0xf]
    // 0xa8b6d8: ldur            x2, [fp, #-0x10]
    // 0xa8b6dc: StoreField: r2->field_13 = r0
    //     0xa8b6dc: stur            w0, [x2, #0x13]
    //     0xa8b6e0: ldurb           w16, [x2, #-1]
    //     0xa8b6e4: ldurb           w17, [x0, #-1]
    //     0xa8b6e8: and             x16, x17, x16, lsr #2
    //     0xa8b6ec: tst             x16, HEAP, lsr #32
    //     0xa8b6f0: b.eq            #0xa8b6f8
    //     0xa8b6f4: bl              #0xd6828c
    // 0xa8b6f8: ldur            x0, [fp, #-0x18]
    // 0xa8b6fc: b               #0xa8b7c8
    // 0xa8b700: ldr             x1, [fp, #0x30]
    // 0xa8b704: ldur            x2, [fp, #-0x10]
    // 0xa8b708: ldur            d0, [fp, #-0x20]
    // 0xa8b70c: ldur            d1, [fp, #-0x38]
    // 0xa8b710: ldur            d3, [fp, #-0x28]
    // 0xa8b714: ldur            x0, [fp, #-8]
    // 0xa8b718: ldur            d2, [fp, #-0x30]
    // 0xa8b71c: tbz             w0, #4, #0xa8b764
    // 0xa8b720: LoadField: r0 = r2->field_f
    //     0xa8b720: ldur            w0, [x2, #0xf]
    // 0xa8b724: DecompressPointer r0
    //     0xa8b724: add             x0, x0, HEAP, lsl #32
    // 0xa8b728: LoadField: r3 = r0->field_57
    //     0xa8b728: ldur            w3, [x0, #0x57]
    // 0xa8b72c: DecompressPointer r3
    //     0xa8b72c: add             x3, x3, HEAP, lsl #32
    // 0xa8b730: cmp             w3, NULL
    // 0xa8b734: b.eq            #0xa8b84c
    // 0xa8b738: LoadField: d4 = r3->field_f
    //     0xa8b738: ldur            d4, [x3, #0xf]
    // 0xa8b73c: fsub            d5, d4, d1
    // 0xa8b740: LoadField: r0 = r1->field_4f
    //     0xa8b740: ldur            w0, [x1, #0x4f]
    // 0xa8b744: DecompressPointer r0
    //     0xa8b744: add             x0, x0, HEAP, lsl #32
    // 0xa8b748: cmp             w0, NULL
    // 0xa8b74c: b.eq            #0xa8b850
    // 0xa8b750: LoadField: d1 = r0->field_17
    //     0xa8b750: ldur            d1, [x0, #0x17]
    // 0xa8b754: fsub            d6, d1, d4
    // 0xa8b758: fsub            d1, d6, d0
    // 0xa8b75c: mov             v0.16b, v5.16b
    // 0xa8b760: b               #0xa8b770
    // 0xa8b764: mov             v31.16b, v1.16b
    // 0xa8b768: mov             v1.16b, v0.16b
    // 0xa8b76c: mov             v0.16b, v31.16b
    // 0xa8b770: stur            d1, [fp, #-0x20]
    // 0xa8b774: stur            d0, [fp, #-0x38]
    // 0xa8b778: r0 = Offset()
    //     0xa8b778: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa8b77c: ldur            d0, [fp, #-0x30]
    // 0xa8b780: stur            x0, [fp, #-8]
    // 0xa8b784: StoreField: r0->field_7 = d0
    //     0xa8b784: stur            d0, [x0, #7]
    // 0xa8b788: ldur            d0, [fp, #-0x20]
    // 0xa8b78c: StoreField: r0->field_f = d0
    //     0xa8b78c: stur            d0, [x0, #0xf]
    // 0xa8b790: r0 = Offset()
    //     0xa8b790: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa8b794: ldur            d0, [fp, #-0x28]
    // 0xa8b798: StoreField: r0->field_7 = d0
    //     0xa8b798: stur            d0, [x0, #7]
    // 0xa8b79c: ldur            d0, [fp, #-0x38]
    // 0xa8b7a0: StoreField: r0->field_f = d0
    //     0xa8b7a0: stur            d0, [x0, #0xf]
    // 0xa8b7a4: ldur            x2, [fp, #-0x10]
    // 0xa8b7a8: StoreField: r2->field_13 = r0
    //     0xa8b7a8: stur            w0, [x2, #0x13]
    //     0xa8b7ac: ldurb           w16, [x2, #-1]
    //     0xa8b7b0: ldurb           w17, [x0, #-1]
    //     0xa8b7b4: and             x16, x17, x16, lsr #2
    //     0xa8b7b8: tst             x16, HEAP, lsr #32
    //     0xa8b7bc: b.eq            #0xa8b7c4
    //     0xa8b7c0: bl              #0xd6828c
    // 0xa8b7c4: ldur            x0, [fp, #-8]
    // 0xa8b7c8: stur            x0, [fp, #-8]
    // 0xa8b7cc: r1 = Function '<anonymous closure>':.
    //     0xa8b7cc: add             x1, PP, #0x4f, lsl #12  ; [pp+0x4fbd8] AnonymousClosure: (0xa8b854), in [package:flutter/src/rendering/sliver_persistent_header.dart] _RenderSliverPersistentHeader&RenderSliver&RenderObjectWithChildMixin&RenderSliverHelpers::hitTestBoxChild (0xa8b8c4)
    //     0xa8b7d0: ldr             x1, [x1, #0xbd8]
    // 0xa8b7d4: r0 = AllocateClosure()
    //     0xa8b7d4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa8b7d8: ldr             x16, [fp, #0x28]
    // 0xa8b7dc: stp             x0, x16, [SP, #-0x10]!
    // 0xa8b7e0: ldur            x16, [fp, #-8]
    // 0xa8b7e4: SaveReg r16
    //     0xa8b7e4: str             x16, [SP, #-8]!
    // 0xa8b7e8: r4 = const [0, 0x3, 0x3, 0x2, paintOffset, 0x2, null]
    //     0xa8b7e8: add             x4, PP, #0x4f, lsl #12  ; [pp+0x4fb50] List(7) [0, 0x3, 0x3, 0x2, "paintOffset", 0x2, Null]
    //     0xa8b7ec: ldr             x4, [x4, #0xb50]
    // 0xa8b7f0: r0 = addWithOutOfBandPosition()
    //     0xa8b7f0: bl              #0x62a858  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithOutOfBandPosition
    // 0xa8b7f4: add             SP, SP, #0x18
    // 0xa8b7f8: LeaveFrame
    //     0xa8b7f8: mov             SP, fp
    //     0xa8b7fc: ldp             fp, lr, [SP], #0x10
    // 0xa8b800: ret
    //     0xa8b800: ret             
    // 0xa8b804: r0 = StateError()
    //     0xa8b804: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xa8b808: r7 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xa8b808: add             x7, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0xa8b80c: ldr             x7, [x7, #0x1e8]
    // 0xa8b810: StoreField: r0->field_b = r7
    //     0xa8b810: stur            w7, [x0, #0xb]
    // 0xa8b814: r0 = Throw()
    //     0xa8b814: bl              #0xd67e38  ; ThrowStub
    // 0xa8b818: brk             #0
    // 0xa8b81c: r0 = StateError()
    //     0xa8b81c: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xa8b820: mov             x1, x0
    // 0xa8b824: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xa8b824: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0xa8b828: ldr             x0, [x0, #0x1e8]
    // 0xa8b82c: StoreField: r1->field_b = r0
    //     0xa8b82c: stur            w0, [x1, #0xb]
    // 0xa8b830: mov             x0, x1
    // 0xa8b834: r0 = Throw()
    //     0xa8b834: bl              #0xd67e38  ; ThrowStub
    // 0xa8b838: brk             #0
    // 0xa8b83c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8b83c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8b840: b               #0xa8b474
    // 0xa8b844: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa8b844: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa8b848: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa8b848: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa8b84c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa8b84c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa8b850: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa8b850: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
}

// class id: 2582, size: 0x64, field offset: 0x64
//   transformed mixin,
abstract class _RenderSliverMultiBoxAdaptor&RenderSliver&ContainerRenderObjectMixin&RenderSliverHelpers&RenderSliverWithKeepAliveMixin extends _RenderSliverMultiBoxAdaptor&RenderSliver&ContainerRenderObjectMixin&RenderSliverHelpers
     with RenderSliverWithKeepAliveMixin {
}

// class id: 2583, size: 0x6c, field offset: 0x64
abstract class RenderSliverMultiBoxAdaptor extends _RenderSliverMultiBoxAdaptor&RenderSliver&ContainerRenderObjectMixin&RenderSliverHelpers&RenderSliverWithKeepAliveMixin {

  _ move(/* No info */) {
    // ** addr: 0x5acc9c, size: 0x24c
    // 0x5acc9c: EnterFrame
    //     0x5acc9c: stp             fp, lr, [SP, #-0x10]!
    //     0x5acca0: mov             fp, SP
    // 0x5acca4: AllocStack(0x10)
    //     0x5acca4: sub             SP, SP, #0x10
    // 0x5acca8: CheckStackOverflow
    //     0x5acca8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5accac: cmp             SP, x16
    //     0x5accb0: b.ls            #0x5aced8
    // 0x5accb4: ldr             x0, [fp, #0x18]
    // 0x5accb8: r2 = Null
    //     0x5accb8: mov             x2, NULL
    // 0x5accbc: r1 = Null
    //     0x5accbc: mov             x1, NULL
    // 0x5accc0: r4 = 59
    //     0x5accc0: mov             x4, #0x3b
    // 0x5accc4: branchIfSmi(r0, 0x5accd0)
    //     0x5accc4: tbz             w0, #0, #0x5accd0
    // 0x5accc8: r4 = LoadClassIdInstr(r0)
    //     0x5accc8: ldur            x4, [x0, #-1]
    //     0x5acccc: ubfx            x4, x4, #0xc, #0x14
    // 0x5accd0: sub             x4, x4, #0x965
    // 0x5accd4: cmp             x4, #0x8b
    // 0x5accd8: b.ls            #0x5accf0
    // 0x5accdc: r8 = RenderBox
    //     0x5accdc: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x5acce0: ldr             x8, [x8, #0xfa0]
    // 0x5acce4: r3 = Null
    //     0x5acce4: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ae78] Null
    //     0x5acce8: ldr             x3, [x3, #0xe78]
    // 0x5accec: r0 = RenderBox()
    //     0x5accec: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x5accf0: ldr             x0, [fp, #0x10]
    // 0x5accf4: r2 = Null
    //     0x5accf4: mov             x2, NULL
    // 0x5accf8: r1 = Null
    //     0x5accf8: mov             x1, NULL
    // 0x5accfc: r4 = 59
    //     0x5accfc: mov             x4, #0x3b
    // 0x5acd00: branchIfSmi(r0, 0x5acd0c)
    //     0x5acd00: tbz             w0, #0, #0x5acd0c
    // 0x5acd04: r4 = LoadClassIdInstr(r0)
    //     0x5acd04: ldur            x4, [x0, #-1]
    //     0x5acd08: ubfx            x4, x4, #0xc, #0x14
    // 0x5acd0c: sub             x4, x4, #0x965
    // 0x5acd10: cmp             x4, #0x8b
    // 0x5acd14: b.ls            #0x5acd28
    // 0x5acd18: r8 = RenderBox?
    //     0x5acd18: ldr             x8, [PP, #0x4de8]  ; [pp+0x4de8] Type: RenderBox?
    // 0x5acd1c: r3 = Null
    //     0x5acd1c: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ae88] Null
    //     0x5acd20: ldr             x3, [x3, #0xe88]
    // 0x5acd24: r0 = RenderBox?()
    //     0x5acd24: bl              #0x5ad534  ; IsType_RenderBox?_Stub
    // 0x5acd28: ldr             x3, [fp, #0x18]
    // 0x5acd2c: LoadField: r4 = r3->field_17
    //     0x5acd2c: ldur            w4, [x3, #0x17]
    // 0x5acd30: DecompressPointer r4
    //     0x5acd30: add             x4, x4, HEAP, lsl #32
    // 0x5acd34: stur            x4, [fp, #-8]
    // 0x5acd38: cmp             w4, NULL
    // 0x5acd3c: b.eq            #0x5acee0
    // 0x5acd40: mov             x0, x4
    // 0x5acd44: r2 = Null
    //     0x5acd44: mov             x2, NULL
    // 0x5acd48: r1 = Null
    //     0x5acd48: mov             x1, NULL
    // 0x5acd4c: r4 = LoadClassIdInstr(r0)
    //     0x5acd4c: ldur            x4, [x0, #-1]
    //     0x5acd50: ubfx            x4, x4, #0xc, #0x14
    // 0x5acd54: sub             x4, x4, #0x7f9
    // 0x5acd58: cmp             x4, #2
    // 0x5acd5c: b.ls            #0x5acd74
    // 0x5acd60: r8 = SliverMultiBoxAdaptorParentData
    //     0x5acd60: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x5acd64: ldr             x8, [x8, #0x120]
    // 0x5acd68: r3 = Null
    //     0x5acd68: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ae98] Null
    //     0x5acd6c: ldr             x3, [x3, #0xe98]
    // 0x5acd70: r0 = DefaultTypeTest()
    //     0x5acd70: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5acd74: ldur            x0, [fp, #-8]
    // 0x5acd78: LoadField: r1 = r0->field_1b
    //     0x5acd78: ldur            w1, [x0, #0x1b]
    // 0x5acd7c: DecompressPointer r1
    //     0x5acd7c: add             x1, x1, HEAP, lsl #32
    // 0x5acd80: tbz             w1, #4, #0x5acde4
    // 0x5acd84: ldr             x0, [fp, #0x20]
    // 0x5acd88: ldr             x16, [fp, #0x18]
    // 0x5acd8c: stp             x16, x0, [SP, #-0x10]!
    // 0x5acd90: ldr             x16, [fp, #0x10]
    // 0x5acd94: SaveReg r16
    //     0x5acd94: str             x16, [SP, #-8]!
    // 0x5acd98: r0 = move()
    //     0x5acd98: bl              #0x5acf0c  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] _RenderSliverMultiBoxAdaptor&RenderSliver&ContainerRenderObjectMixin::move
    // 0x5acd9c: add             SP, SP, #0x18
    // 0x5acda0: ldr             x1, [fp, #0x20]
    // 0x5acda4: LoadField: r0 = r1->field_63
    //     0x5acda4: ldur            w0, [x1, #0x63]
    // 0x5acda8: DecompressPointer r0
    //     0x5acda8: add             x0, x0, HEAP, lsl #32
    // 0x5acdac: r2 = LoadClassIdInstr(r0)
    //     0x5acdac: ldur            x2, [x0, #-1]
    //     0x5acdb0: ubfx            x2, x2, #0xc, #0x14
    // 0x5acdb4: ldr             x16, [fp, #0x18]
    // 0x5acdb8: stp             x16, x0, [SP, #-0x10]!
    // 0x5acdbc: mov             x0, x2
    // 0x5acdc0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x5acdc0: sub             lr, x0, #1, lsl #12
    //     0x5acdc4: ldr             lr, [x21, lr, lsl #3]
    //     0x5acdc8: blr             lr
    // 0x5acdcc: add             SP, SP, #0x10
    // 0x5acdd0: ldr             x16, [fp, #0x20]
    // 0x5acdd4: SaveReg r16
    //     0x5acdd4: str             x16, [SP, #-8]!
    // 0x5acdd8: r0 = markNeedsLayout()
    //     0x5acdd8: bl              #0x6c0ee8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsLayout
    // 0x5acddc: add             SP, SP, #8
    // 0x5acde0: b               #0x5acec8
    // 0x5acde4: ldr             x1, [fp, #0x20]
    // 0x5acde8: LoadField: r2 = r1->field_67
    //     0x5acde8: ldur            w2, [x1, #0x67]
    // 0x5acdec: DecompressPointer r2
    //     0x5acdec: add             x2, x2, HEAP, lsl #32
    // 0x5acdf0: stur            x2, [fp, #-0x10]
    // 0x5acdf4: LoadField: r3 = r0->field_17
    //     0x5acdf4: ldur            w3, [x0, #0x17]
    // 0x5acdf8: DecompressPointer r3
    //     0x5acdf8: add             x3, x3, HEAP, lsl #32
    // 0x5acdfc: stp             x3, x2, [SP, #-0x10]!
    // 0x5ace00: r0 = _getValueOrData()
    //     0x5ace00: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5ace04: add             SP, SP, #0x10
    // 0x5ace08: ldur            x1, [fp, #-0x10]
    // 0x5ace0c: LoadField: r2 = r1->field_f
    //     0x5ace0c: ldur            w2, [x1, #0xf]
    // 0x5ace10: DecompressPointer r2
    //     0x5ace10: add             x2, x2, HEAP, lsl #32
    // 0x5ace14: cmp             w2, w0
    // 0x5ace18: b.ne            #0x5ace20
    // 0x5ace1c: r0 = Null
    //     0x5ace1c: mov             x0, NULL
    // 0x5ace20: r2 = 59
    //     0x5ace20: mov             x2, #0x3b
    // 0x5ace24: branchIfSmi(r0, 0x5ace30)
    //     0x5ace24: tbz             w0, #0, #0x5ace30
    // 0x5ace28: r2 = LoadClassIdInstr(r0)
    //     0x5ace28: ldur            x2, [x0, #-1]
    //     0x5ace2c: ubfx            x2, x2, #0xc, #0x14
    // 0x5ace30: ldr             x16, [fp, #0x18]
    // 0x5ace34: stp             x16, x0, [SP, #-0x10]!
    // 0x5ace38: mov             x0, x2
    // 0x5ace3c: mov             lr, x0
    // 0x5ace40: ldr             lr, [x21, lr, lsl #3]
    // 0x5ace44: blr             lr
    // 0x5ace48: add             SP, SP, #0x10
    // 0x5ace4c: tbnz            w0, #4, #0x5ace6c
    // 0x5ace50: ldur            x0, [fp, #-8]
    // 0x5ace54: LoadField: r1 = r0->field_17
    //     0x5ace54: ldur            w1, [x0, #0x17]
    // 0x5ace58: DecompressPointer r1
    //     0x5ace58: add             x1, x1, HEAP, lsl #32
    // 0x5ace5c: ldur            x16, [fp, #-0x10]
    // 0x5ace60: stp             x1, x16, [SP, #-0x10]!
    // 0x5ace64: r0 = remove()
    //     0x5ace64: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x5ace68: add             SP, SP, #0x10
    // 0x5ace6c: ldr             x0, [fp, #0x20]
    // 0x5ace70: ldur            x1, [fp, #-8]
    // 0x5ace74: LoadField: r2 = r0->field_63
    //     0x5ace74: ldur            w2, [x0, #0x63]
    // 0x5ace78: DecompressPointer r2
    //     0x5ace78: add             x2, x2, HEAP, lsl #32
    // 0x5ace7c: r0 = LoadClassIdInstr(r2)
    //     0x5ace7c: ldur            x0, [x2, #-1]
    //     0x5ace80: ubfx            x0, x0, #0xc, #0x14
    // 0x5ace84: ldr             x16, [fp, #0x18]
    // 0x5ace88: stp             x16, x2, [SP, #-0x10]!
    // 0x5ace8c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x5ace8c: sub             lr, x0, #1, lsl #12
    //     0x5ace90: ldr             lr, [x21, lr, lsl #3]
    //     0x5ace94: blr             lr
    // 0x5ace98: add             SP, SP, #0x10
    // 0x5ace9c: ldur            x0, [fp, #-8]
    // 0x5acea0: LoadField: r1 = r0->field_17
    //     0x5acea0: ldur            w1, [x0, #0x17]
    // 0x5acea4: DecompressPointer r1
    //     0x5acea4: add             x1, x1, HEAP, lsl #32
    // 0x5acea8: cmp             w1, NULL
    // 0x5aceac: b.eq            #0x5acee4
    // 0x5aceb0: ldur            x16, [fp, #-0x10]
    // 0x5aceb4: stp             x1, x16, [SP, #-0x10]!
    // 0x5aceb8: ldr             x16, [fp, #0x18]
    // 0x5acebc: SaveReg r16
    //     0x5acebc: str             x16, [SP, #-8]!
    // 0x5acec0: r0 = []=()
    //     0x5acec0: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5acec4: add             SP, SP, #0x18
    // 0x5acec8: r0 = Null
    //     0x5acec8: mov             x0, NULL
    // 0x5acecc: LeaveFrame
    //     0x5acecc: mov             SP, fp
    //     0x5aced0: ldp             fp, lr, [SP], #0x10
    // 0x5aced4: ret
    //     0x5aced4: ret             
    // 0x5aced8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5aced8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5acedc: b               #0x5accb4
    // 0x5acee0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5acee0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5acee4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5acee4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ remove(/* No info */) {
    // ** addr: 0x5e59c8, size: 0x124
    // 0x5e59c8: EnterFrame
    //     0x5e59c8: stp             fp, lr, [SP, #-0x10]!
    //     0x5e59cc: mov             fp, SP
    // 0x5e59d0: AllocStack(0x8)
    //     0x5e59d0: sub             SP, SP, #8
    // 0x5e59d4: CheckStackOverflow
    //     0x5e59d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e59d8: cmp             SP, x16
    //     0x5e59dc: b.ls            #0x5e5ae0
    // 0x5e59e0: ldr             x0, [fp, #0x10]
    // 0x5e59e4: r2 = Null
    //     0x5e59e4: mov             x2, NULL
    // 0x5e59e8: r1 = Null
    //     0x5e59e8: mov             x1, NULL
    // 0x5e59ec: r4 = 59
    //     0x5e59ec: mov             x4, #0x3b
    // 0x5e59f0: branchIfSmi(r0, 0x5e59fc)
    //     0x5e59f0: tbz             w0, #0, #0x5e59fc
    // 0x5e59f4: r4 = LoadClassIdInstr(r0)
    //     0x5e59f4: ldur            x4, [x0, #-1]
    //     0x5e59f8: ubfx            x4, x4, #0xc, #0x14
    // 0x5e59fc: sub             x4, x4, #0x965
    // 0x5e5a00: cmp             x4, #0x8b
    // 0x5e5a04: b.ls            #0x5e5a1c
    // 0x5e5a08: r8 = RenderBox
    //     0x5e5a08: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x5e5a0c: ldr             x8, [x8, #0xfa0]
    // 0x5e5a10: r3 = Null
    //     0x5e5a10: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ae58] Null
    //     0x5e5a14: ldr             x3, [x3, #0xe58]
    // 0x5e5a18: r0 = RenderBox()
    //     0x5e5a18: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x5e5a1c: ldr             x3, [fp, #0x10]
    // 0x5e5a20: LoadField: r4 = r3->field_17
    //     0x5e5a20: ldur            w4, [x3, #0x17]
    // 0x5e5a24: DecompressPointer r4
    //     0x5e5a24: add             x4, x4, HEAP, lsl #32
    // 0x5e5a28: stur            x4, [fp, #-8]
    // 0x5e5a2c: cmp             w4, NULL
    // 0x5e5a30: b.eq            #0x5e5ae8
    // 0x5e5a34: mov             x0, x4
    // 0x5e5a38: r2 = Null
    //     0x5e5a38: mov             x2, NULL
    // 0x5e5a3c: r1 = Null
    //     0x5e5a3c: mov             x1, NULL
    // 0x5e5a40: r4 = LoadClassIdInstr(r0)
    //     0x5e5a40: ldur            x4, [x0, #-1]
    //     0x5e5a44: ubfx            x4, x4, #0xc, #0x14
    // 0x5e5a48: sub             x4, x4, #0x7f9
    // 0x5e5a4c: cmp             x4, #2
    // 0x5e5a50: b.ls            #0x5e5a68
    // 0x5e5a54: r8 = SliverMultiBoxAdaptorParentData
    //     0x5e5a54: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x5e5a58: ldr             x8, [x8, #0x120]
    // 0x5e5a5c: r3 = Null
    //     0x5e5a5c: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ae68] Null
    //     0x5e5a60: ldr             x3, [x3, #0xe68]
    // 0x5e5a64: r0 = DefaultTypeTest()
    //     0x5e5a64: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5e5a68: ldur            x0, [fp, #-8]
    // 0x5e5a6c: LoadField: r1 = r0->field_1b
    //     0x5e5a6c: ldur            w1, [x0, #0x1b]
    // 0x5e5a70: DecompressPointer r1
    //     0x5e5a70: add             x1, x1, HEAP, lsl #32
    // 0x5e5a74: tbz             w1, #4, #0x5e5a9c
    // 0x5e5a78: ldr             x16, [fp, #0x18]
    // 0x5e5a7c: ldr             lr, [fp, #0x10]
    // 0x5e5a80: stp             lr, x16, [SP, #-0x10]!
    // 0x5e5a84: r0 = remove()
    //     0x5e5a84: bl              #0x5e5f98  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] _RenderSliverMultiBoxAdaptor&RenderSliver&ContainerRenderObjectMixin::remove
    // 0x5e5a88: add             SP, SP, #0x10
    // 0x5e5a8c: r0 = Null
    //     0x5e5a8c: mov             x0, NULL
    // 0x5e5a90: LeaveFrame
    //     0x5e5a90: mov             SP, fp
    //     0x5e5a94: ldp             fp, lr, [SP], #0x10
    // 0x5e5a98: ret
    //     0x5e5a98: ret             
    // 0x5e5a9c: ldr             x1, [fp, #0x18]
    // 0x5e5aa0: LoadField: r2 = r1->field_67
    //     0x5e5aa0: ldur            w2, [x1, #0x67]
    // 0x5e5aa4: DecompressPointer r2
    //     0x5e5aa4: add             x2, x2, HEAP, lsl #32
    // 0x5e5aa8: LoadField: r3 = r0->field_17
    //     0x5e5aa8: ldur            w3, [x0, #0x17]
    // 0x5e5aac: DecompressPointer r3
    //     0x5e5aac: add             x3, x3, HEAP, lsl #32
    // 0x5e5ab0: stp             x3, x2, [SP, #-0x10]!
    // 0x5e5ab4: r0 = remove()
    //     0x5e5ab4: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x5e5ab8: add             SP, SP, #0x10
    // 0x5e5abc: ldr             x16, [fp, #0x18]
    // 0x5e5ac0: ldr             lr, [fp, #0x10]
    // 0x5e5ac4: stp             lr, x16, [SP, #-0x10]!
    // 0x5e5ac8: r0 = dropChild()
    //     0x5e5ac8: bl              #0x5e5aec  ; [package:flutter/src/rendering/object.dart] RenderObject::dropChild
    // 0x5e5acc: add             SP, SP, #0x10
    // 0x5e5ad0: r0 = Null
    //     0x5e5ad0: mov             x0, NULL
    // 0x5e5ad4: LeaveFrame
    //     0x5e5ad4: mov             SP, fp
    //     0x5e5ad8: ldp             fp, lr, [SP], #0x10
    // 0x5e5adc: ret
    //     0x5e5adc: ret             
    // 0x5e5ae0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e5ae0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e5ae4: b               #0x5e59e0
    // 0x5e5ae8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5e5ae8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ insert(/* No info */) {
    // ** addr: 0x5e5fec, size: 0xbc
    // 0x5e5fec: EnterFrame
    //     0x5e5fec: stp             fp, lr, [SP, #-0x10]!
    //     0x5e5ff0: mov             fp, SP
    // 0x5e5ff4: CheckStackOverflow
    //     0x5e5ff4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e5ff8: cmp             SP, x16
    //     0x5e5ffc: b.ls            #0x5e60a0
    // 0x5e6000: ldr             x0, [fp, #0x18]
    // 0x5e6004: r2 = Null
    //     0x5e6004: mov             x2, NULL
    // 0x5e6008: r1 = Null
    //     0x5e6008: mov             x1, NULL
    // 0x5e600c: r4 = 59
    //     0x5e600c: mov             x4, #0x3b
    // 0x5e6010: branchIfSmi(r0, 0x5e601c)
    //     0x5e6010: tbz             w0, #0, #0x5e601c
    // 0x5e6014: r4 = LoadClassIdInstr(r0)
    //     0x5e6014: ldur            x4, [x0, #-1]
    //     0x5e6018: ubfx            x4, x4, #0xc, #0x14
    // 0x5e601c: sub             x4, x4, #0x965
    // 0x5e6020: cmp             x4, #0x8b
    // 0x5e6024: b.ls            #0x5e603c
    // 0x5e6028: r8 = RenderBox
    //     0x5e6028: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x5e602c: ldr             x8, [x8, #0xfa0]
    // 0x5e6030: r3 = Null
    //     0x5e6030: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4aea8] Null
    //     0x5e6034: ldr             x3, [x3, #0xea8]
    // 0x5e6038: r0 = RenderBox()
    //     0x5e6038: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x5e603c: ldr             x0, [fp, #0x10]
    // 0x5e6040: r2 = Null
    //     0x5e6040: mov             x2, NULL
    // 0x5e6044: r1 = Null
    //     0x5e6044: mov             x1, NULL
    // 0x5e6048: r4 = 59
    //     0x5e6048: mov             x4, #0x3b
    // 0x5e604c: branchIfSmi(r0, 0x5e6058)
    //     0x5e604c: tbz             w0, #0, #0x5e6058
    // 0x5e6050: r4 = LoadClassIdInstr(r0)
    //     0x5e6050: ldur            x4, [x0, #-1]
    //     0x5e6054: ubfx            x4, x4, #0xc, #0x14
    // 0x5e6058: sub             x4, x4, #0x965
    // 0x5e605c: cmp             x4, #0x8b
    // 0x5e6060: b.ls            #0x5e6074
    // 0x5e6064: r8 = RenderBox?
    //     0x5e6064: ldr             x8, [PP, #0x4de8]  ; [pp+0x4de8] Type: RenderBox?
    // 0x5e6068: r3 = Null
    //     0x5e6068: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4aeb8] Null
    //     0x5e606c: ldr             x3, [x3, #0xeb8]
    // 0x5e6070: r0 = RenderBox?()
    //     0x5e6070: bl              #0x5ad534  ; IsType_RenderBox?_Stub
    // 0x5e6074: ldr             x16, [fp, #0x20]
    // 0x5e6078: ldr             lr, [fp, #0x18]
    // 0x5e607c: stp             lr, x16, [SP, #-0x10]!
    // 0x5e6080: ldr             x16, [fp, #0x10]
    // 0x5e6084: SaveReg r16
    //     0x5e6084: str             x16, [SP, #-8]!
    // 0x5e6088: r0 = insert()
    //     0x5e6088: bl              #0x5e60a8  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] _RenderSliverMultiBoxAdaptor&RenderSliver&ContainerRenderObjectMixin::insert
    // 0x5e608c: add             SP, SP, #0x18
    // 0x5e6090: r0 = Null
    //     0x5e6090: mov             x0, NULL
    // 0x5e6094: LeaveFrame
    //     0x5e6094: mov             SP, fp
    //     0x5e6098: ldp             fp, lr, [SP], #0x10
    // 0x5e609c: ret
    //     0x5e609c: ret             
    // 0x5e60a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e60a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e60a4: b               #0x5e6000
  }
  _ adoptChild(/* No info */) {
    // ** addr: 0x5e6104, size: 0xd0
    // 0x5e6104: EnterFrame
    //     0x5e6104: stp             fp, lr, [SP, #-0x10]!
    //     0x5e6108: mov             fp, SP
    // 0x5e610c: AllocStack(0x8)
    //     0x5e610c: sub             SP, SP, #8
    // 0x5e6110: CheckStackOverflow
    //     0x5e6110: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e6114: cmp             SP, x16
    //     0x5e6118: b.ls            #0x5e61c8
    // 0x5e611c: ldr             x16, [fp, #0x18]
    // 0x5e6120: ldr             lr, [fp, #0x10]
    // 0x5e6124: stp             lr, x16, [SP, #-0x10]!
    // 0x5e6128: r0 = adoptChild()
    //     0x5e6128: bl              #0x5e61d4  ; [package:flutter/src/rendering/object.dart] RenderObject::adoptChild
    // 0x5e612c: add             SP, SP, #0x10
    // 0x5e6130: ldr             x3, [fp, #0x10]
    // 0x5e6134: LoadField: r4 = r3->field_17
    //     0x5e6134: ldur            w4, [x3, #0x17]
    // 0x5e6138: DecompressPointer r4
    //     0x5e6138: add             x4, x4, HEAP, lsl #32
    // 0x5e613c: stur            x4, [fp, #-8]
    // 0x5e6140: cmp             w4, NULL
    // 0x5e6144: b.eq            #0x5e61d0
    // 0x5e6148: mov             x0, x4
    // 0x5e614c: r2 = Null
    //     0x5e614c: mov             x2, NULL
    // 0x5e6150: r1 = Null
    //     0x5e6150: mov             x1, NULL
    // 0x5e6154: r4 = LoadClassIdInstr(r0)
    //     0x5e6154: ldur            x4, [x0, #-1]
    //     0x5e6158: ubfx            x4, x4, #0xc, #0x14
    // 0x5e615c: sub             x4, x4, #0x7f9
    // 0x5e6160: cmp             x4, #2
    // 0x5e6164: b.ls            #0x5e617c
    // 0x5e6168: r8 = SliverMultiBoxAdaptorParentData
    //     0x5e6168: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x5e616c: ldr             x8, [x8, #0x120]
    // 0x5e6170: r3 = Null
    //     0x5e6170: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ad30] Null
    //     0x5e6174: ldr             x3, [x3, #0xd30]
    // 0x5e6178: r0 = DefaultTypeTest()
    //     0x5e6178: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5e617c: ldur            x0, [fp, #-8]
    // 0x5e6180: LoadField: r1 = r0->field_1b
    //     0x5e6180: ldur            w1, [x0, #0x1b]
    // 0x5e6184: DecompressPointer r1
    //     0x5e6184: add             x1, x1, HEAP, lsl #32
    // 0x5e6188: tbz             w1, #4, #0x5e61b8
    // 0x5e618c: ldr             x0, [fp, #0x18]
    // 0x5e6190: LoadField: r1 = r0->field_63
    //     0x5e6190: ldur            w1, [x0, #0x63]
    // 0x5e6194: DecompressPointer r1
    //     0x5e6194: add             x1, x1, HEAP, lsl #32
    // 0x5e6198: r0 = LoadClassIdInstr(r1)
    //     0x5e6198: ldur            x0, [x1, #-1]
    //     0x5e619c: ubfx            x0, x0, #0xc, #0x14
    // 0x5e61a0: ldr             x16, [fp, #0x10]
    // 0x5e61a4: stp             x16, x1, [SP, #-0x10]!
    // 0x5e61a8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x5e61a8: sub             lr, x0, #1, lsl #12
    //     0x5e61ac: ldr             lr, [x21, lr, lsl #3]
    //     0x5e61b0: blr             lr
    // 0x5e61b4: add             SP, SP, #0x10
    // 0x5e61b8: r0 = Null
    //     0x5e61b8: mov             x0, NULL
    // 0x5e61bc: LeaveFrame
    //     0x5e61bc: mov             SP, fp
    //     0x5e61c0: ldp             fp, lr, [SP], #0x10
    // 0x5e61c4: ret
    //     0x5e61c4: ret             
    // 0x5e61c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e61c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e61cc: b               #0x5e611c
    // 0x5e61d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5e61d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paintsChild(/* No info */) {
    // ** addr: 0x641548, size: 0xf0
    // 0x641548: EnterFrame
    //     0x641548: stp             fp, lr, [SP, #-0x10]!
    //     0x64154c: mov             fp, SP
    // 0x641550: AllocStack(0x8)
    //     0x641550: sub             SP, SP, #8
    // 0x641554: CheckStackOverflow
    //     0x641554: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x641558: cmp             SP, x16
    //     0x64155c: b.ls            #0x641630
    // 0x641560: ldr             x0, [fp, #0x10]
    // 0x641564: r2 = Null
    //     0x641564: mov             x2, NULL
    // 0x641568: r1 = Null
    //     0x641568: mov             x1, NULL
    // 0x64156c: r4 = 59
    //     0x64156c: mov             x4, #0x3b
    // 0x641570: branchIfSmi(r0, 0x64157c)
    //     0x641570: tbz             w0, #0, #0x64157c
    // 0x641574: r4 = LoadClassIdInstr(r0)
    //     0x641574: ldur            x4, [x0, #-1]
    //     0x641578: ubfx            x4, x4, #0xc, #0x14
    // 0x64157c: sub             x4, x4, #0x965
    // 0x641580: cmp             x4, #0x8b
    // 0x641584: b.ls            #0x64159c
    // 0x641588: r8 = RenderBox
    //     0x641588: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x64158c: ldr             x8, [x8, #0xfa0]
    // 0x641590: r3 = Null
    //     0x641590: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ae00] Null
    //     0x641594: ldr             x3, [x3, #0xe00]
    // 0x641598: r0 = RenderBox()
    //     0x641598: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x64159c: ldr             x0, [fp, #0x10]
    // 0x6415a0: LoadField: r3 = r0->field_17
    //     0x6415a0: ldur            w3, [x0, #0x17]
    // 0x6415a4: DecompressPointer r3
    //     0x6415a4: add             x3, x3, HEAP, lsl #32
    // 0x6415a8: mov             x0, x3
    // 0x6415ac: stur            x3, [fp, #-8]
    // 0x6415b0: r2 = Null
    //     0x6415b0: mov             x2, NULL
    // 0x6415b4: r1 = Null
    //     0x6415b4: mov             x1, NULL
    // 0x6415b8: r4 = LoadClassIdInstr(r0)
    //     0x6415b8: ldur            x4, [x0, #-1]
    //     0x6415bc: ubfx            x4, x4, #0xc, #0x14
    // 0x6415c0: sub             x4, x4, #0x7f9
    // 0x6415c4: cmp             x4, #2
    // 0x6415c8: b.ls            #0x6415e0
    // 0x6415cc: r8 = SliverMultiBoxAdaptorParentData?
    //     0x6415cc: add             x8, PP, #0x4a, lsl #12  ; [pp+0x4ae10] Type: SliverMultiBoxAdaptorParentData?
    //     0x6415d0: ldr             x8, [x8, #0xe10]
    // 0x6415d4: r3 = Null
    //     0x6415d4: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ae18] Null
    //     0x6415d8: ldr             x3, [x3, #0xe18]
    // 0x6415dc: r0 = DefaultNullableTypeTest()
    //     0x6415dc: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x6415e0: ldur            x0, [fp, #-8]
    // 0x6415e4: cmp             w0, NULL
    // 0x6415e8: b.eq            #0x641620
    // 0x6415ec: LoadField: r1 = r0->field_17
    //     0x6415ec: ldur            w1, [x0, #0x17]
    // 0x6415f0: DecompressPointer r1
    //     0x6415f0: add             x1, x1, HEAP, lsl #32
    // 0x6415f4: cmp             w1, NULL
    // 0x6415f8: b.eq            #0x641620
    // 0x6415fc: ldr             x0, [fp, #0x18]
    // 0x641600: LoadField: r2 = r0->field_67
    //     0x641600: ldur            w2, [x0, #0x67]
    // 0x641604: DecompressPointer r2
    //     0x641604: add             x2, x2, HEAP, lsl #32
    // 0x641608: stp             x1, x2, [SP, #-0x10]!
    // 0x64160c: r0 = containsKey()
    //     0x64160c: bl              #0xca679c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x641610: add             SP, SP, #0x10
    // 0x641614: eor             x1, x0, #0x10
    // 0x641618: mov             x0, x1
    // 0x64161c: b               #0x641624
    // 0x641620: r0 = false
    //     0x641620: add             x0, NULL, #0x30  ; false
    // 0x641624: LeaveFrame
    //     0x641624: mov             SP, fp
    //     0x641628: ldp             fp, lr, [SP], #0x10
    // 0x64162c: ret
    //     0x64162c: ret             
    // 0x641630: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x641630: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x641634: b               #0x641560
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0x64b6cc, size: 0x74
    // 0x64b6cc: EnterFrame
    //     0x64b6cc: stp             fp, lr, [SP, #-0x10]!
    //     0x64b6d0: mov             fp, SP
    // 0x64b6d4: ldr             x0, [fp, #0x10]
    // 0x64b6d8: LoadField: r1 = r0->field_17
    //     0x64b6d8: ldur            w1, [x0, #0x17]
    // 0x64b6dc: DecompressPointer r1
    //     0x64b6dc: add             x1, x1, HEAP, lsl #32
    // 0x64b6e0: r2 = LoadClassIdInstr(r1)
    //     0x64b6e0: ldur            x2, [x1, #-1]
    //     0x64b6e4: ubfx            x2, x2, #0xc, #0x14
    // 0x64b6e8: lsl             x2, x2, #1
    // 0x64b6ec: r1 = LoadInt32Instr(r2)
    //     0x64b6ec: sbfx            x1, x2, #1, #0x1f
    // 0x64b6f0: cmp             x1, #0x7f9
    // 0x64b6f4: b.lt            #0x64b700
    // 0x64b6f8: cmp             x1, #0x7fb
    // 0x64b6fc: b.le            #0x64b730
    // 0x64b700: r0 = SliverMultiBoxAdaptorParentData()
    //     0x64b700: bl              #0x64b740  ; AllocateSliverMultiBoxAdaptorParentDataStub -> SliverMultiBoxAdaptorParentData (size=0x20)
    // 0x64b704: r1 = false
    //     0x64b704: add             x1, NULL, #0x30  ; false
    // 0x64b708: StoreField: r0->field_1b = r1
    //     0x64b708: stur            w1, [x0, #0x1b]
    // 0x64b70c: StoreField: r0->field_13 = r1
    //     0x64b70c: stur            w1, [x0, #0x13]
    // 0x64b710: ldr             x1, [fp, #0x10]
    // 0x64b714: StoreField: r1->field_17 = r0
    //     0x64b714: stur            w0, [x1, #0x17]
    //     0x64b718: ldurb           w16, [x1, #-1]
    //     0x64b71c: ldurb           w17, [x0, #-1]
    //     0x64b720: and             x16, x17, x16, lsr #2
    //     0x64b724: tst             x16, HEAP, lsr #32
    //     0x64b728: b.eq            #0x64b730
    //     0x64b72c: bl              #0xd6826c
    // 0x64b730: r0 = Null
    //     0x64b730: mov             x0, NULL
    // 0x64b734: LeaveFrame
    //     0x64b734: mov             SP, fp
    //     0x64b738: ldp             fp, lr, [SP], #0x10
    // 0x64b73c: ret
    //     0x64b73c: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0x6537d0, size: 0x6a8
    // 0x6537d0: EnterFrame
    //     0x6537d0: stp             fp, lr, [SP, #-0x10]!
    //     0x6537d4: mov             fp, SP
    // 0x6537d8: AllocStack(0x70)
    //     0x6537d8: sub             SP, SP, #0x70
    // 0x6537dc: CheckStackOverflow
    //     0x6537dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6537e0: cmp             SP, x16
    //     0x6537e4: b.ls            #0x653e44
    // 0x6537e8: ldr             x3, [fp, #0x20]
    // 0x6537ec: LoadField: r0 = r3->field_5b
    //     0x6537ec: ldur            w0, [x3, #0x5b]
    // 0x6537f0: DecompressPointer r0
    //     0x6537f0: add             x0, x0, HEAP, lsl #32
    // 0x6537f4: cmp             w0, NULL
    // 0x6537f8: b.ne            #0x65380c
    // 0x6537fc: r0 = Null
    //     0x6537fc: mov             x0, NULL
    // 0x653800: LeaveFrame
    //     0x653800: mov             SP, fp
    //     0x653804: ldp             fp, lr, [SP], #0x10
    // 0x653808: ret
    //     0x653808: ret             
    // 0x65380c: LoadField: r4 = r3->field_27
    //     0x65380c: ldur            w4, [x3, #0x27]
    // 0x653810: DecompressPointer r4
    //     0x653810: add             x4, x4, HEAP, lsl #32
    // 0x653814: stur            x4, [fp, #-8]
    // 0x653818: cmp             w4, NULL
    // 0x65381c: b.eq            #0x653de4
    // 0x653820: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x653820: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x653824: ldr             x5, [x5, #0x1e8]
    // 0x653828: mov             x0, x4
    // 0x65382c: r2 = Null
    //     0x65382c: mov             x2, NULL
    // 0x653830: r1 = Null
    //     0x653830: mov             x1, NULL
    // 0x653834: r4 = LoadClassIdInstr(r0)
    //     0x653834: ldur            x4, [x0, #-1]
    //     0x653838: ubfx            x4, x4, #0xc, #0x14
    // 0x65383c: cmp             x4, #0x80c
    // 0x653840: b.eq            #0x653858
    // 0x653844: r8 = SliverConstraints
    //     0x653844: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x653848: ldr             x8, [x8, #0x5a8]
    // 0x65384c: r3 = Null
    //     0x65384c: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ad40] Null
    //     0x653850: ldr             x3, [x3, #0xd40]
    // 0x653854: r0 = DefaultTypeTest()
    //     0x653854: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x653858: ldur            x0, [fp, #-8]
    // 0x65385c: LoadField: r1 = r0->field_7
    //     0x65385c: ldur            w1, [x0, #7]
    // 0x653860: DecompressPointer r1
    //     0x653860: add             x1, x1, HEAP, lsl #32
    // 0x653864: LoadField: r2 = r0->field_b
    //     0x653864: ldur            w2, [x0, #0xb]
    // 0x653868: DecompressPointer r2
    //     0x653868: add             x2, x2, HEAP, lsl #32
    // 0x65386c: stp             x2, x1, [SP, #-0x10]!
    // 0x653870: r0 = applyGrowthDirectionToAxisDirection()
    //     0x653870: bl              #0x643194  ; [package:flutter/src/rendering/sliver.dart] ::applyGrowthDirectionToAxisDirection
    // 0x653874: add             SP, SP, #0x10
    // 0x653878: LoadField: r1 = r0->field_7
    //     0x653878: ldur            x1, [x0, #7]
    // 0x65387c: cmp             x1, #1
    // 0x653880: b.gt            #0x653900
    // 0x653884: cmp             x1, #0
    // 0x653888: b.gt            #0x6538e4
    // 0x65388c: ldr             x0, [fp, #0x20]
    // 0x653890: LoadField: r1 = r0->field_4f
    //     0x653890: ldur            w1, [x0, #0x4f]
    // 0x653894: DecompressPointer r1
    //     0x653894: add             x1, x1, HEAP, lsl #32
    // 0x653898: cmp             w1, NULL
    // 0x65389c: b.eq            #0x653e4c
    // 0x6538a0: LoadField: d0 = r1->field_17
    //     0x6538a0: ldur            d0, [x1, #0x17]
    // 0x6538a4: stur            d0, [fp, #-0x28]
    // 0x6538a8: r0 = Offset()
    //     0x6538a8: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x6538ac: d0 = 0.000000
    //     0x6538ac: eor             v0.16b, v0.16b, v0.16b
    // 0x6538b0: StoreField: r0->field_7 = d0
    //     0x6538b0: stur            d0, [x0, #7]
    // 0x6538b4: ldur            d1, [fp, #-0x28]
    // 0x6538b8: StoreField: r0->field_f = d1
    //     0x6538b8: stur            d1, [x0, #0xf]
    // 0x6538bc: ldr             x16, [fp, #0x10]
    // 0x6538c0: stp             x0, x16, [SP, #-0x10]!
    // 0x6538c4: r0 = +()
    //     0x6538c4: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x6538c8: add             SP, SP, #0x10
    // 0x6538cc: r2 = Instance_Offset
    //     0x6538cc: add             x2, PP, #0x2a, lsl #12  ; [pp+0x2abe0] Obj!Offset@b5efb1
    //     0x6538d0: ldr             x2, [x2, #0xbe0]
    // 0x6538d4: r1 = Instance_Offset
    //     0x6538d4: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f660] Obj!Offset@b5ef71
    //     0x6538d8: ldr             x1, [x1, #0x660]
    // 0x6538dc: r4 = true
    //     0x6538dc: add             x4, NULL, #0x20  ; true
    // 0x6538e0: b               #0x653978
    // 0x6538e4: ldr             x0, [fp, #0x10]
    // 0x6538e8: r2 = Instance_Offset
    //     0x6538e8: add             x2, PP, #0x1f, lsl #12  ; [pp+0x1f660] Obj!Offset@b5ef71
    //     0x6538ec: ldr             x2, [x2, #0x660]
    // 0x6538f0: r1 = Instance_Offset
    //     0x6538f0: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f668] Obj!Offset@b5ef51
    //     0x6538f4: ldr             x1, [x1, #0x668]
    // 0x6538f8: r4 = false
    //     0x6538f8: add             x4, NULL, #0x30  ; false
    // 0x6538fc: b               #0x653978
    // 0x653900: ldr             x0, [fp, #0x10]
    // 0x653904: cmp             x1, #2
    // 0x653908: b.gt            #0x653924
    // 0x65390c: r2 = Instance_Offset
    //     0x65390c: add             x2, PP, #0x1f, lsl #12  ; [pp+0x1f668] Obj!Offset@b5ef51
    //     0x653910: ldr             x2, [x2, #0x668]
    // 0x653914: r1 = Instance_Offset
    //     0x653914: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f660] Obj!Offset@b5ef71
    //     0x653918: ldr             x1, [x1, #0x660]
    // 0x65391c: r4 = false
    //     0x65391c: add             x4, NULL, #0x30  ; false
    // 0x653920: b               #0x653978
    // 0x653924: ldr             x1, [fp, #0x20]
    // 0x653928: LoadField: r2 = r1->field_4f
    //     0x653928: ldur            w2, [x1, #0x4f]
    // 0x65392c: DecompressPointer r2
    //     0x65392c: add             x2, x2, HEAP, lsl #32
    // 0x653930: cmp             w2, NULL
    // 0x653934: b.eq            #0x653e50
    // 0x653938: LoadField: d0 = r2->field_17
    //     0x653938: ldur            d0, [x2, #0x17]
    // 0x65393c: stur            d0, [fp, #-0x28]
    // 0x653940: r0 = Offset()
    //     0x653940: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x653944: ldur            d0, [fp, #-0x28]
    // 0x653948: StoreField: r0->field_7 = d0
    //     0x653948: stur            d0, [x0, #7]
    // 0x65394c: d0 = 0.000000
    //     0x65394c: eor             v0.16b, v0.16b, v0.16b
    // 0x653950: StoreField: r0->field_f = d0
    //     0x653950: stur            d0, [x0, #0xf]
    // 0x653954: ldr             x16, [fp, #0x10]
    // 0x653958: stp             x0, x16, [SP, #-0x10]!
    // 0x65395c: r0 = +()
    //     0x65395c: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x653960: add             SP, SP, #0x10
    // 0x653964: r2 = Instance_Offset
    //     0x653964: add             x2, PP, #0x2a, lsl #12  ; [pp+0x2aaf0] Obj!Offset@b5ef91
    //     0x653968: ldr             x2, [x2, #0xaf0]
    // 0x65396c: r1 = Instance_Offset
    //     0x65396c: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f668] Obj!Offset@b5ef51
    //     0x653970: ldr             x1, [x1, #0x668]
    // 0x653974: r4 = true
    //     0x653974: add             x4, NULL, #0x20  ; true
    // 0x653978: ldr             x3, [fp, #0x20]
    // 0x65397c: stur            x4, [fp, #-0x10]
    // 0x653980: LoadField: r5 = r3->field_5b
    //     0x653980: ldur            w5, [x3, #0x5b]
    // 0x653984: DecompressPointer r5
    //     0x653984: add             x5, x5, HEAP, lsl #32
    // 0x653988: LoadField: d0 = r0->field_7
    //     0x653988: ldur            d0, [x0, #7]
    // 0x65398c: stur            d0, [fp, #-0x50]
    // 0x653990: LoadField: d1 = r2->field_7
    //     0x653990: ldur            d1, [x2, #7]
    // 0x653994: stur            d1, [fp, #-0x48]
    // 0x653998: LoadField: d2 = r1->field_7
    //     0x653998: ldur            d2, [x1, #7]
    // 0x65399c: stur            d2, [fp, #-0x40]
    // 0x6539a0: LoadField: d3 = r0->field_f
    //     0x6539a0: ldur            d3, [x0, #0xf]
    // 0x6539a4: stur            d3, [fp, #-0x38]
    // 0x6539a8: LoadField: d4 = r2->field_f
    //     0x6539a8: ldur            d4, [x2, #0xf]
    // 0x6539ac: stur            d4, [fp, #-0x30]
    // 0x6539b0: LoadField: d5 = r1->field_f
    //     0x6539b0: ldur            d5, [x1, #0xf]
    // 0x6539b4: stur            d5, [fp, #-0x28]
    // 0x6539b8: stur            x5, [fp, #-8]
    // 0x6539bc: CheckStackOverflow
    //     0x6539bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6539c0: cmp             SP, x16
    //     0x6539c4: b.ls            #0x653e54
    // 0x6539c8: cmp             w5, NULL
    // 0x6539cc: b.eq            #0x653dd4
    // 0x6539d0: mov             x0, x5
    // 0x6539d4: r2 = Null
    //     0x6539d4: mov             x2, NULL
    // 0x6539d8: r1 = Null
    //     0x6539d8: mov             x1, NULL
    // 0x6539dc: r4 = LoadClassIdInstr(r0)
    //     0x6539dc: ldur            x4, [x0, #-1]
    //     0x6539e0: ubfx            x4, x4, #0xc, #0x14
    // 0x6539e4: sub             x4, x4, #0x961
    // 0x6539e8: cmp             x4, #0xbe
    // 0x6539ec: b.ls            #0x653a00
    // 0x6539f0: r8 = RenderObject
    //     0x6539f0: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x6539f4: r3 = Null
    //     0x6539f4: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ad50] Null
    //     0x6539f8: ldr             x3, [x3, #0xd50]
    // 0x6539fc: r0 = RenderObject()
    //     0x6539fc: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x653a00: ldur            x3, [fp, #-8]
    // 0x653a04: LoadField: r4 = r3->field_17
    //     0x653a04: ldur            w4, [x3, #0x17]
    // 0x653a08: DecompressPointer r4
    //     0x653a08: add             x4, x4, HEAP, lsl #32
    // 0x653a0c: stur            x4, [fp, #-0x18]
    // 0x653a10: cmp             w4, NULL
    // 0x653a14: b.eq            #0x653e5c
    // 0x653a18: mov             x0, x4
    // 0x653a1c: r2 = Null
    //     0x653a1c: mov             x2, NULL
    // 0x653a20: r1 = Null
    //     0x653a20: mov             x1, NULL
    // 0x653a24: r4 = LoadClassIdInstr(r0)
    //     0x653a24: ldur            x4, [x0, #-1]
    //     0x653a28: ubfx            x4, x4, #0xc, #0x14
    // 0x653a2c: sub             x4, x4, #0x7f9
    // 0x653a30: cmp             x4, #2
    // 0x653a34: b.ls            #0x653a4c
    // 0x653a38: r8 = SliverMultiBoxAdaptorParentData
    //     0x653a38: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x653a3c: ldr             x8, [x8, #0x120]
    // 0x653a40: r3 = Null
    //     0x653a40: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ad60] Null
    //     0x653a44: ldr             x3, [x3, #0xd60]
    // 0x653a48: r0 = DefaultTypeTest()
    //     0x653a48: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x653a4c: ldur            x0, [fp, #-0x18]
    // 0x653a50: LoadField: r3 = r0->field_7
    //     0x653a50: ldur            w3, [x0, #7]
    // 0x653a54: DecompressPointer r3
    //     0x653a54: add             x3, x3, HEAP, lsl #32
    // 0x653a58: stur            x3, [fp, #-0x20]
    // 0x653a5c: cmp             w3, NULL
    // 0x653a60: b.eq            #0x653e60
    // 0x653a64: ldr             x4, [fp, #0x20]
    // 0x653a68: LoadField: r5 = r4->field_27
    //     0x653a68: ldur            w5, [x4, #0x27]
    // 0x653a6c: DecompressPointer r5
    //     0x653a6c: add             x5, x5, HEAP, lsl #32
    // 0x653a70: stur            x5, [fp, #-0x18]
    // 0x653a74: cmp             w5, NULL
    // 0x653a78: b.eq            #0x653dfc
    // 0x653a7c: ldur            x7, [fp, #-0x10]
    // 0x653a80: ldur            d0, [fp, #-0x50]
    // 0x653a84: ldur            d1, [fp, #-0x48]
    // 0x653a88: ldur            d2, [fp, #-0x40]
    // 0x653a8c: ldur            d3, [fp, #-0x38]
    // 0x653a90: ldur            d4, [fp, #-0x30]
    // 0x653a94: ldur            d5, [fp, #-0x28]
    // 0x653a98: r6 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x653a98: add             x6, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x653a9c: ldr             x6, [x6, #0x1e8]
    // 0x653aa0: mov             x0, x5
    // 0x653aa4: r2 = Null
    //     0x653aa4: mov             x2, NULL
    // 0x653aa8: r1 = Null
    //     0x653aa8: mov             x1, NULL
    // 0x653aac: r4 = LoadClassIdInstr(r0)
    //     0x653aac: ldur            x4, [x0, #-1]
    //     0x653ab0: ubfx            x4, x4, #0xc, #0x14
    // 0x653ab4: cmp             x4, #0x80c
    // 0x653ab8: b.eq            #0x653ad0
    // 0x653abc: r8 = SliverConstraints
    //     0x653abc: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x653ac0: ldr             x8, [x8, #0x5a8]
    // 0x653ac4: r3 = Null
    //     0x653ac4: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ad70] Null
    //     0x653ac8: ldr             x3, [x3, #0xd70]
    // 0x653acc: r0 = DefaultTypeTest()
    //     0x653acc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x653ad0: ldur            x0, [fp, #-0x18]
    // 0x653ad4: LoadField: d0 = r0->field_13
    //     0x653ad4: ldur            d0, [x0, #0x13]
    // 0x653ad8: ldur            x0, [fp, #-0x20]
    // 0x653adc: LoadField: d1 = r0->field_7
    //     0x653adc: ldur            d1, [x0, #7]
    // 0x653ae0: fsub            d2, d1, d0
    // 0x653ae4: ldr             x1, [fp, #0x20]
    // 0x653ae8: stur            d2, [fp, #-0x58]
    // 0x653aec: r0 = LoadClassIdInstr(r1)
    //     0x653aec: ldur            x0, [x1, #-1]
    //     0x653af0: ubfx            x0, x0, #0xc, #0x14
    // 0x653af4: ldur            x16, [fp, #-8]
    // 0x653af8: stp             x16, x1, [SP, #-0x10]!
    // 0x653afc: r0 = GDT[cid_x0 + 0x1dd6]()
    //     0x653afc: mov             x17, #0x1dd6
    //     0x653b00: add             lr, x0, x17
    //     0x653b04: ldr             lr, [x21, lr, lsl #3]
    //     0x653b08: blr             lr
    // 0x653b0c: add             SP, SP, #0x10
    // 0x653b10: ldur            d0, [fp, #-0x58]
    // 0x653b14: ldur            d1, [fp, #-0x48]
    // 0x653b18: fmul            d2, d1, d0
    // 0x653b1c: ldur            d3, [fp, #-0x50]
    // 0x653b20: fadd            d4, d3, d2
    // 0x653b24: LoadField: d2 = r0->field_7
    //     0x653b24: ldur            d2, [x0, #7]
    // 0x653b28: ldur            d5, [fp, #-0x40]
    // 0x653b2c: fmul            d6, d5, d2
    // 0x653b30: fadd            d7, d4, d6
    // 0x653b34: ldur            d4, [fp, #-0x30]
    // 0x653b38: stur            d7, [fp, #-0x68]
    // 0x653b3c: fmul            d6, d4, d0
    // 0x653b40: ldur            d8, [fp, #-0x38]
    // 0x653b44: fadd            d9, d8, d6
    // 0x653b48: ldur            d6, [fp, #-0x28]
    // 0x653b4c: fmul            d10, d6, d2
    // 0x653b50: fadd            d2, d9, d10
    // 0x653b54: stur            d2, [fp, #-0x60]
    // 0x653b58: r0 = Offset()
    //     0x653b58: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x653b5c: ldur            d0, [fp, #-0x68]
    // 0x653b60: StoreField: r0->field_7 = d0
    //     0x653b60: stur            d0, [x0, #7]
    // 0x653b64: ldur            d1, [fp, #-0x60]
    // 0x653b68: StoreField: r0->field_f = d1
    //     0x653b68: stur            d1, [x0, #0xf]
    // 0x653b6c: ldur            x3, [fp, #-0x10]
    // 0x653b70: tbnz            w3, #4, #0x653c60
    // 0x653b74: ldr             x4, [fp, #0x20]
    // 0x653b78: LoadField: r5 = r4->field_27
    //     0x653b78: ldur            w5, [x4, #0x27]
    // 0x653b7c: DecompressPointer r5
    //     0x653b7c: add             x5, x5, HEAP, lsl #32
    // 0x653b80: stur            x5, [fp, #-0x18]
    // 0x653b84: cmp             w5, NULL
    // 0x653b88: b.eq            #0x653e14
    // 0x653b8c: r6 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x653b8c: add             x6, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x653b90: ldr             x6, [x6, #0x1e8]
    // 0x653b94: mov             x0, x5
    // 0x653b98: r2 = Null
    //     0x653b98: mov             x2, NULL
    // 0x653b9c: r1 = Null
    //     0x653b9c: mov             x1, NULL
    // 0x653ba0: r4 = LoadClassIdInstr(r0)
    //     0x653ba0: ldur            x4, [x0, #-1]
    //     0x653ba4: ubfx            x4, x4, #0xc, #0x14
    // 0x653ba8: cmp             x4, #0x80c
    // 0x653bac: b.eq            #0x653bc4
    // 0x653bb0: r8 = SliverConstraints
    //     0x653bb0: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x653bb4: ldr             x8, [x8, #0x5a8]
    // 0x653bb8: r3 = Null
    //     0x653bb8: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ad80] Null
    //     0x653bbc: ldr             x3, [x3, #0xd80]
    // 0x653bc0: r0 = DefaultTypeTest()
    //     0x653bc0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x653bc4: ldur            x16, [fp, #-0x18]
    // 0x653bc8: SaveReg r16
    //     0x653bc8: str             x16, [SP, #-8]!
    // 0x653bcc: r0 = axis()
    //     0x653bcc: bl              #0x643150  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0x653bd0: add             SP, SP, #8
    // 0x653bd4: LoadField: r1 = r0->field_7
    //     0x653bd4: ldur            x1, [x0, #7]
    // 0x653bd8: cmp             x1, #0
    // 0x653bdc: b.gt            #0x653c00
    // 0x653be0: ldur            x0, [fp, #-8]
    // 0x653be4: LoadField: r1 = r0->field_57
    //     0x653be4: ldur            w1, [x0, #0x57]
    // 0x653be8: DecompressPointer r1
    //     0x653be8: add             x1, x1, HEAP, lsl #32
    // 0x653bec: cmp             w1, NULL
    // 0x653bf0: b.eq            #0x653e64
    // 0x653bf4: LoadField: d0 = r1->field_7
    //     0x653bf4: ldur            d0, [x1, #7]
    // 0x653bf8: mov             v4.16b, v0.16b
    // 0x653bfc: b               #0x653c1c
    // 0x653c00: ldur            x0, [fp, #-8]
    // 0x653c04: LoadField: r1 = r0->field_57
    //     0x653c04: ldur            w1, [x0, #0x57]
    // 0x653c08: DecompressPointer r1
    //     0x653c08: add             x1, x1, HEAP, lsl #32
    // 0x653c0c: cmp             w1, NULL
    // 0x653c10: b.eq            #0x653e68
    // 0x653c14: LoadField: d0 = r1->field_f
    //     0x653c14: ldur            d0, [x1, #0xf]
    // 0x653c18: mov             v4.16b, v0.16b
    // 0x653c1c: ldur            d0, [fp, #-0x68]
    // 0x653c20: ldur            d1, [fp, #-0x60]
    // 0x653c24: ldur            d2, [fp, #-0x48]
    // 0x653c28: ldur            d3, [fp, #-0x30]
    // 0x653c2c: fmul            d5, d2, d4
    // 0x653c30: fmul            d6, d3, d4
    // 0x653c34: fadd            d4, d0, d5
    // 0x653c38: stur            d4, [fp, #-0x70]
    // 0x653c3c: fadd            d0, d1, d6
    // 0x653c40: stur            d0, [fp, #-0x68]
    // 0x653c44: r0 = Offset()
    //     0x653c44: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x653c48: ldur            d0, [fp, #-0x70]
    // 0x653c4c: StoreField: r0->field_7 = d0
    //     0x653c4c: stur            d0, [x0, #7]
    // 0x653c50: ldur            d0, [fp, #-0x68]
    // 0x653c54: StoreField: r0->field_f = d0
    //     0x653c54: stur            d0, [x0, #0xf]
    // 0x653c58: mov             x4, x0
    // 0x653c5c: b               #0x653c64
    // 0x653c60: mov             x4, x0
    // 0x653c64: ldr             x3, [fp, #0x20]
    // 0x653c68: stur            x4, [fp, #-0x20]
    // 0x653c6c: LoadField: r5 = r3->field_27
    //     0x653c6c: ldur            w5, [x3, #0x27]
    // 0x653c70: DecompressPointer r5
    //     0x653c70: add             x5, x5, HEAP, lsl #32
    // 0x653c74: stur            x5, [fp, #-0x18]
    // 0x653c78: cmp             w5, NULL
    // 0x653c7c: b.eq            #0x653e2c
    // 0x653c80: ldur            d0, [fp, #-0x58]
    // 0x653c84: r6 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x653c84: add             x6, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x653c88: ldr             x6, [x6, #0x1e8]
    // 0x653c8c: mov             x0, x5
    // 0x653c90: r2 = Null
    //     0x653c90: mov             x2, NULL
    // 0x653c94: r1 = Null
    //     0x653c94: mov             x1, NULL
    // 0x653c98: r4 = LoadClassIdInstr(r0)
    //     0x653c98: ldur            x4, [x0, #-1]
    //     0x653c9c: ubfx            x4, x4, #0xc, #0x14
    // 0x653ca0: cmp             x4, #0x80c
    // 0x653ca4: b.eq            #0x653cbc
    // 0x653ca8: r8 = SliverConstraints
    //     0x653ca8: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x653cac: ldr             x8, [x8, #0x5a8]
    // 0x653cb0: r3 = Null
    //     0x653cb0: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ad90] Null
    //     0x653cb4: ldr             x3, [x3, #0xd90]
    // 0x653cb8: r0 = DefaultTypeTest()
    //     0x653cb8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x653cbc: ldur            x0, [fp, #-0x18]
    // 0x653cc0: LoadField: d0 = r0->field_2b
    //     0x653cc0: ldur            d0, [x0, #0x2b]
    // 0x653cc4: ldur            d1, [fp, #-0x58]
    // 0x653cc8: fcmp            d1, d0
    // 0x653ccc: b.vs            #0x653d58
    // 0x653cd0: b.ge            #0x653d58
    // 0x653cd4: SaveReg r0
    //     0x653cd4: str             x0, [SP, #-8]!
    // 0x653cd8: r0 = axis()
    //     0x653cd8: bl              #0x643150  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0x653cdc: add             SP, SP, #8
    // 0x653ce0: LoadField: r1 = r0->field_7
    //     0x653ce0: ldur            x1, [x0, #7]
    // 0x653ce4: cmp             x1, #0
    // 0x653ce8: b.gt            #0x653d0c
    // 0x653cec: ldur            x0, [fp, #-8]
    // 0x653cf0: LoadField: r1 = r0->field_57
    //     0x653cf0: ldur            w1, [x0, #0x57]
    // 0x653cf4: DecompressPointer r1
    //     0x653cf4: add             x1, x1, HEAP, lsl #32
    // 0x653cf8: cmp             w1, NULL
    // 0x653cfc: b.eq            #0x653e6c
    // 0x653d00: LoadField: d0 = r1->field_7
    //     0x653d00: ldur            d0, [x1, #7]
    // 0x653d04: mov             v2.16b, v0.16b
    // 0x653d08: b               #0x653d28
    // 0x653d0c: ldur            x0, [fp, #-8]
    // 0x653d10: LoadField: r1 = r0->field_57
    //     0x653d10: ldur            w1, [x0, #0x57]
    // 0x653d14: DecompressPointer r1
    //     0x653d14: add             x1, x1, HEAP, lsl #32
    // 0x653d18: cmp             w1, NULL
    // 0x653d1c: b.eq            #0x653e70
    // 0x653d20: LoadField: d0 = r1->field_f
    //     0x653d20: ldur            d0, [x1, #0xf]
    // 0x653d24: mov             v2.16b, v0.16b
    // 0x653d28: ldur            d0, [fp, #-0x58]
    // 0x653d2c: d1 = 0.000000
    //     0x653d2c: eor             v1.16b, v1.16b, v1.16b
    // 0x653d30: fadd            d3, d0, d2
    // 0x653d34: fcmp            d3, d1
    // 0x653d38: b.vs            #0x653d58
    // 0x653d3c: b.le            #0x653d58
    // 0x653d40: ldr             x16, [fp, #0x18]
    // 0x653d44: stp             x0, x16, [SP, #-0x10]!
    // 0x653d48: ldur            x16, [fp, #-0x20]
    // 0x653d4c: SaveReg r16
    //     0x653d4c: str             x16, [SP, #-8]!
    // 0x653d50: r0 = paintChild()
    //     0x653d50: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x653d54: add             SP, SP, #0x18
    // 0x653d58: ldur            x0, [fp, #-8]
    // 0x653d5c: LoadField: r3 = r0->field_17
    //     0x653d5c: ldur            w3, [x0, #0x17]
    // 0x653d60: DecompressPointer r3
    //     0x653d60: add             x3, x3, HEAP, lsl #32
    // 0x653d64: stur            x3, [fp, #-0x18]
    // 0x653d68: cmp             w3, NULL
    // 0x653d6c: b.eq            #0x653e74
    // 0x653d70: mov             x0, x3
    // 0x653d74: r2 = Null
    //     0x653d74: mov             x2, NULL
    // 0x653d78: r1 = Null
    //     0x653d78: mov             x1, NULL
    // 0x653d7c: r4 = LoadClassIdInstr(r0)
    //     0x653d7c: ldur            x4, [x0, #-1]
    //     0x653d80: ubfx            x4, x4, #0xc, #0x14
    // 0x653d84: sub             x4, x4, #0x7f9
    // 0x653d88: cmp             x4, #2
    // 0x653d8c: b.ls            #0x653da4
    // 0x653d90: r8 = SliverMultiBoxAdaptorParentData
    //     0x653d90: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x653d94: ldr             x8, [x8, #0x120]
    // 0x653d98: r3 = Null
    //     0x653d98: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ada0] Null
    //     0x653d9c: ldr             x3, [x3, #0xda0]
    // 0x653da0: r0 = DefaultTypeTest()
    //     0x653da0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x653da4: ldur            x1, [fp, #-0x18]
    // 0x653da8: LoadField: r5 = r1->field_f
    //     0x653da8: ldur            w5, [x1, #0xf]
    // 0x653dac: DecompressPointer r5
    //     0x653dac: add             x5, x5, HEAP, lsl #32
    // 0x653db0: ldr             x3, [fp, #0x20]
    // 0x653db4: ldur            x4, [fp, #-0x10]
    // 0x653db8: ldur            d0, [fp, #-0x50]
    // 0x653dbc: ldur            d1, [fp, #-0x48]
    // 0x653dc0: ldur            d2, [fp, #-0x40]
    // 0x653dc4: ldur            d3, [fp, #-0x38]
    // 0x653dc8: ldur            d4, [fp, #-0x30]
    // 0x653dcc: ldur            d5, [fp, #-0x28]
    // 0x653dd0: b               #0x6539b8
    // 0x653dd4: r0 = Null
    //     0x653dd4: mov             x0, NULL
    // 0x653dd8: LeaveFrame
    //     0x653dd8: mov             SP, fp
    //     0x653ddc: ldp             fp, lr, [SP], #0x10
    // 0x653de0: ret
    //     0x653de0: ret             
    // 0x653de4: r0 = StateError()
    //     0x653de4: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x653de8: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x653de8: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x653dec: ldr             x5, [x5, #0x1e8]
    // 0x653df0: StoreField: r0->field_b = r5
    //     0x653df0: stur            w5, [x0, #0xb]
    // 0x653df4: r0 = Throw()
    //     0x653df4: bl              #0xd67e38  ; ThrowStub
    // 0x653df8: brk             #0
    // 0x653dfc: r0 = StateError()
    //     0x653dfc: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x653e00: r6 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x653e00: add             x6, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x653e04: ldr             x6, [x6, #0x1e8]
    // 0x653e08: StoreField: r0->field_b = r6
    //     0x653e08: stur            w6, [x0, #0xb]
    // 0x653e0c: r0 = Throw()
    //     0x653e0c: bl              #0xd67e38  ; ThrowStub
    // 0x653e10: brk             #0
    // 0x653e14: r0 = StateError()
    //     0x653e14: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x653e18: r6 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x653e18: add             x6, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x653e1c: ldr             x6, [x6, #0x1e8]
    // 0x653e20: StoreField: r0->field_b = r6
    //     0x653e20: stur            w6, [x0, #0xb]
    // 0x653e24: r0 = Throw()
    //     0x653e24: bl              #0xd67e38  ; ThrowStub
    // 0x653e28: brk             #0
    // 0x653e2c: r0 = StateError()
    //     0x653e2c: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x653e30: r6 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x653e30: add             x6, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x653e34: ldr             x6, [x6, #0x1e8]
    // 0x653e38: StoreField: r0->field_b = r6
    //     0x653e38: stur            w6, [x0, #0xb]
    // 0x653e3c: r0 = Throw()
    //     0x653e3c: bl              #0xd67e38  ; ThrowStub
    // 0x653e40: brk             #0
    // 0x653e44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x653e44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x653e48: b               #0x6537e8
    // 0x653e4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x653e4c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x653e50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x653e50: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x653e54: r0 = StackOverflowSharedWithFPURegs()
    //     0x653e54: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x653e58: b               #0x6539c8
    // 0x653e5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x653e5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x653e60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x653e60: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x653e64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x653e64: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x653e68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x653e68: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x653e6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x653e6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x653e70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x653e70: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x653e74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x653e74: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paintExtentOf(/* No info */) {
    // ** addr: 0x653e78, size: 0x164
    // 0x653e78: EnterFrame
    //     0x653e78: stp             fp, lr, [SP, #-0x10]!
    //     0x653e7c: mov             fp, SP
    // 0x653e80: AllocStack(0x8)
    //     0x653e80: sub             SP, SP, #8
    // 0x653e84: CheckStackOverflow
    //     0x653e84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x653e88: cmp             SP, x16
    //     0x653e8c: b.ls            #0x653fac
    // 0x653e90: ldr             x0, [fp, #0x18]
    // 0x653e94: LoadField: r3 = r0->field_27
    //     0x653e94: ldur            w3, [x0, #0x27]
    // 0x653e98: DecompressPointer r3
    //     0x653e98: add             x3, x3, HEAP, lsl #32
    // 0x653e9c: stur            x3, [fp, #-8]
    // 0x653ea0: cmp             w3, NULL
    // 0x653ea4: b.eq            #0x653f8c
    // 0x653ea8: mov             x0, x3
    // 0x653eac: r2 = Null
    //     0x653eac: mov             x2, NULL
    // 0x653eb0: r1 = Null
    //     0x653eb0: mov             x1, NULL
    // 0x653eb4: r4 = LoadClassIdInstr(r0)
    //     0x653eb4: ldur            x4, [x0, #-1]
    //     0x653eb8: ubfx            x4, x4, #0xc, #0x14
    // 0x653ebc: cmp             x4, #0x80c
    // 0x653ec0: b.eq            #0x653ed8
    // 0x653ec4: r8 = SliverConstraints
    //     0x653ec4: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0x653ec8: ldr             x8, [x8, #0x5a8]
    // 0x653ecc: r3 = Null
    //     0x653ecc: add             x3, PP, #0x43, lsl #12  ; [pp+0x43410] Null
    //     0x653ed0: ldr             x3, [x3, #0x410]
    // 0x653ed4: r0 = DefaultTypeTest()
    //     0x653ed4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x653ed8: ldur            x16, [fp, #-8]
    // 0x653edc: SaveReg r16
    //     0x653edc: str             x16, [SP, #-8]!
    // 0x653ee0: r0 = axis()
    //     0x653ee0: bl              #0x643150  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0x653ee4: add             SP, SP, #8
    // 0x653ee8: LoadField: r1 = r0->field_7
    //     0x653ee8: ldur            x1, [x0, #7]
    // 0x653eec: cmp             x1, #0
    // 0x653ef0: b.gt            #0x653f40
    // 0x653ef4: ldr             x1, [fp, #0x10]
    // 0x653ef8: LoadField: r2 = r1->field_57
    //     0x653ef8: ldur            w2, [x1, #0x57]
    // 0x653efc: DecompressPointer r2
    //     0x653efc: add             x2, x2, HEAP, lsl #32
    // 0x653f00: cmp             w2, NULL
    // 0x653f04: b.eq            #0x653fb4
    // 0x653f08: LoadField: d0 = r2->field_7
    //     0x653f08: ldur            d0, [x2, #7]
    // 0x653f0c: r0 = inline_Allocate_Double()
    //     0x653f0c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x653f10: add             x0, x0, #0x10
    //     0x653f14: cmp             x2, x0
    //     0x653f18: b.ls            #0x653fb8
    //     0x653f1c: str             x0, [THR, #0x60]  ; THR::top
    //     0x653f20: sub             x0, x0, #0xf
    //     0x653f24: mov             x2, #0xd108
    //     0x653f28: movk            x2, #3, lsl #16
    //     0x653f2c: stur            x2, [x0, #-1]
    // 0x653f30: StoreField: r0->field_7 = d0
    //     0x653f30: stur            d0, [x0, #7]
    // 0x653f34: LeaveFrame
    //     0x653f34: mov             SP, fp
    //     0x653f38: ldp             fp, lr, [SP], #0x10
    // 0x653f3c: ret
    //     0x653f3c: ret             
    // 0x653f40: ldr             x1, [fp, #0x10]
    // 0x653f44: LoadField: r2 = r1->field_57
    //     0x653f44: ldur            w2, [x1, #0x57]
    // 0x653f48: DecompressPointer r2
    //     0x653f48: add             x2, x2, HEAP, lsl #32
    // 0x653f4c: cmp             w2, NULL
    // 0x653f50: b.eq            #0x653fc8
    // 0x653f54: LoadField: d0 = r2->field_f
    //     0x653f54: ldur            d0, [x2, #0xf]
    // 0x653f58: r0 = inline_Allocate_Double()
    //     0x653f58: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x653f5c: add             x0, x0, #0x10
    //     0x653f60: cmp             x1, x0
    //     0x653f64: b.ls            #0x653fcc
    //     0x653f68: str             x0, [THR, #0x60]  ; THR::top
    //     0x653f6c: sub             x0, x0, #0xf
    //     0x653f70: mov             x1, #0xd108
    //     0x653f74: movk            x1, #3, lsl #16
    //     0x653f78: stur            x1, [x0, #-1]
    // 0x653f7c: StoreField: r0->field_7 = d0
    //     0x653f7c: stur            d0, [x0, #7]
    // 0x653f80: LeaveFrame
    //     0x653f80: mov             SP, fp
    //     0x653f84: ldp             fp, lr, [SP], #0x10
    // 0x653f88: ret
    //     0x653f88: ret             
    // 0x653f8c: r0 = StateError()
    //     0x653f8c: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x653f90: mov             x1, x0
    // 0x653f94: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x653f94: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x653f98: ldr             x0, [x0, #0x1e8]
    // 0x653f9c: StoreField: r1->field_b = r0
    //     0x653f9c: stur            w0, [x1, #0xb]
    // 0x653fa0: mov             x0, x1
    // 0x653fa4: r0 = Throw()
    //     0x653fa4: bl              #0xd67e38  ; ThrowStub
    // 0x653fa8: brk             #0
    // 0x653fac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x653fac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x653fb0: b               #0x653e90
    // 0x653fb4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x653fb4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x653fb8: SaveReg d0
    //     0x653fb8: str             q0, [SP, #-0x10]!
    // 0x653fbc: r0 = AllocateDouble()
    //     0x653fbc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x653fc0: RestoreReg d0
    //     0x653fc0: ldr             q0, [SP], #0x10
    // 0x653fc4: b               #0x653f30
    // 0x653fc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x653fc8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x653fcc: SaveReg d0
    //     0x653fcc: str             q0, [SP, #-0x10]!
    // 0x653fd0: r0 = AllocateDouble()
    //     0x653fd0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x653fd4: RestoreReg d0
    //     0x653fd4: ldr             q0, [SP], #0x10
    // 0x653fd8: b               #0x653f7c
  }
  _ visitChildrenForSemantics(/* No info */) {
    // ** addr: 0x675b34, size: 0x40
    // 0x675b34: EnterFrame
    //     0x675b34: stp             fp, lr, [SP, #-0x10]!
    //     0x675b38: mov             fp, SP
    // 0x675b3c: CheckStackOverflow
    //     0x675b3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x675b40: cmp             SP, x16
    //     0x675b44: b.ls            #0x675b6c
    // 0x675b48: ldr             x16, [fp, #0x18]
    // 0x675b4c: ldr             lr, [fp, #0x10]
    // 0x675b50: stp             lr, x16, [SP, #-0x10]!
    // 0x675b54: r0 = visitChildren()
    //     0x675b54: bl              #0x675b74  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] _RenderSliverMultiBoxAdaptor&RenderSliver&ContainerRenderObjectMixin::visitChildren
    // 0x675b58: add             SP, SP, #0x10
    // 0x675b5c: r0 = Null
    //     0x675b5c: mov             x0, NULL
    // 0x675b60: LeaveFrame
    //     0x675b60: mov             SP, fp
    //     0x675b64: ldp             fp, lr, [SP], #0x10
    // 0x675b68: ret
    //     0x675b68: ret             
    // 0x675b6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x675b6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x675b70: b               #0x675b48
  }
  _ insertAndLayoutChild(/* No info */) {
    // ** addr: 0x677f44, size: 0x280
    // 0x677f44: EnterFrame
    //     0x677f44: stp             fp, lr, [SP, #-0x10]!
    //     0x677f48: mov             fp, SP
    // 0x677f4c: AllocStack(0x30)
    //     0x677f4c: sub             SP, SP, #0x30
    // 0x677f50: SetupParameters(RenderSliverMultiBoxAdaptor this /* r3, fp-0x28 */, dynamic _ /* r4, fp-0x20 */, dynamic _ /* r5, fp-0x18 */, {dynamic parentUsesSize = false /* r6, fp-0x10 */})
    //     0x677f50: mov             x0, x4
    //     0x677f54: ldur            w1, [x0, #0x13]
    //     0x677f58: add             x1, x1, HEAP, lsl #32
    //     0x677f5c: sub             x2, x1, #6
    //     0x677f60: add             x3, fp, w2, sxtw #2
    //     0x677f64: ldr             x3, [x3, #0x20]
    //     0x677f68: stur            x3, [fp, #-0x28]
    //     0x677f6c: add             x4, fp, w2, sxtw #2
    //     0x677f70: ldr             x4, [x4, #0x18]
    //     0x677f74: stur            x4, [fp, #-0x20]
    //     0x677f78: add             x5, fp, w2, sxtw #2
    //     0x677f7c: ldr             x5, [x5, #0x10]
    //     0x677f80: stur            x5, [fp, #-0x18]
    //     0x677f84: ldur            w2, [x0, #0x1f]
    //     0x677f88: add             x2, x2, HEAP, lsl #32
    //     0x677f8c: add             x16, PP, #0xb, lsl #12  ; [pp+0xb000] "parentUsesSize"
    //     0x677f90: ldr             x16, [x16]
    //     0x677f94: cmp             w2, w16
    //     0x677f98: b.ne            #0x677fb8
    //     0x677f9c: ldur            w2, [x0, #0x23]
    //     0x677fa0: add             x2, x2, HEAP, lsl #32
    //     0x677fa4: sub             w0, w1, w2
    //     0x677fa8: add             x1, fp, w0, sxtw #2
    //     0x677fac: ldr             x1, [x1, #8]
    //     0x677fb0: mov             x6, x1
    //     0x677fb4: b               #0x677fbc
    //     0x677fb8: add             x6, NULL, #0x30  ; false
    //     0x677fbc: stur            x6, [fp, #-0x10]
    // 0x677fc0: CheckStackOverflow
    //     0x677fc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x677fc4: cmp             SP, x16
    //     0x677fc8: b.ls            #0x6781a4
    // 0x677fcc: cmp             w5, NULL
    // 0x677fd0: b.eq            #0x6781ac
    // 0x677fd4: LoadField: r7 = r5->field_17
    //     0x677fd4: ldur            w7, [x5, #0x17]
    // 0x677fd8: DecompressPointer r7
    //     0x677fd8: add             x7, x7, HEAP, lsl #32
    // 0x677fdc: stur            x7, [fp, #-8]
    // 0x677fe0: cmp             w7, NULL
    // 0x677fe4: b.eq            #0x6781b0
    // 0x677fe8: mov             x0, x7
    // 0x677fec: r2 = Null
    //     0x677fec: mov             x2, NULL
    // 0x677ff0: r1 = Null
    //     0x677ff0: mov             x1, NULL
    // 0x677ff4: r4 = LoadClassIdInstr(r0)
    //     0x677ff4: ldur            x4, [x0, #-1]
    //     0x677ff8: ubfx            x4, x4, #0xc, #0x14
    // 0x677ffc: sub             x4, x4, #0x7f9
    // 0x678000: cmp             x4, #2
    // 0x678004: b.ls            #0x67801c
    // 0x678008: r8 = SliverMultiBoxAdaptorParentData
    //     0x678008: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x67800c: ldr             x8, [x8, #0x120]
    // 0x678010: r3 = Null
    //     0x678010: add             x3, PP, #0x43, lsl #12  ; [pp+0x43500] Null
    //     0x678014: ldr             x3, [x3, #0x500]
    // 0x678018: r0 = DefaultTypeTest()
    //     0x678018: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67801c: ldur            x0, [fp, #-8]
    // 0x678020: LoadField: r1 = r0->field_17
    //     0x678020: ldur            w1, [x0, #0x17]
    // 0x678024: DecompressPointer r1
    //     0x678024: add             x1, x1, HEAP, lsl #32
    // 0x678028: cmp             w1, NULL
    // 0x67802c: b.eq            #0x6781b4
    // 0x678030: r0 = LoadInt32Instr(r1)
    //     0x678030: sbfx            x0, x1, #1, #0x1f
    //     0x678034: tbz             w1, #0, #0x67803c
    //     0x678038: ldur            x0, [x1, #7]
    // 0x67803c: add             x1, x0, #1
    // 0x678040: stur            x1, [fp, #-0x30]
    // 0x678044: ldur            x16, [fp, #-0x28]
    // 0x678048: stp             x1, x16, [SP, #-0x10]!
    // 0x67804c: ldur            x16, [fp, #-0x18]
    // 0x678050: SaveReg r16
    //     0x678050: str             x16, [SP, #-8]!
    // 0x678054: r0 = _createOrObtainChild()
    //     0x678054: bl              #0x6781c4  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::_createOrObtainChild
    // 0x678058: add             SP, SP, #0x18
    // 0x67805c: ldur            x0, [fp, #-0x18]
    // 0x678060: LoadField: r3 = r0->field_17
    //     0x678060: ldur            w3, [x0, #0x17]
    // 0x678064: DecompressPointer r3
    //     0x678064: add             x3, x3, HEAP, lsl #32
    // 0x678068: stur            x3, [fp, #-8]
    // 0x67806c: cmp             w3, NULL
    // 0x678070: b.eq            #0x6781b8
    // 0x678074: mov             x0, x3
    // 0x678078: r2 = Null
    //     0x678078: mov             x2, NULL
    // 0x67807c: r1 = Null
    //     0x67807c: mov             x1, NULL
    // 0x678080: r4 = LoadClassIdInstr(r0)
    //     0x678080: ldur            x4, [x0, #-1]
    //     0x678084: ubfx            x4, x4, #0xc, #0x14
    // 0x678088: sub             x4, x4, #0x7f9
    // 0x67808c: cmp             x4, #2
    // 0x678090: b.ls            #0x6780a8
    // 0x678094: r8 = SliverMultiBoxAdaptorParentData
    //     0x678094: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x678098: ldr             x8, [x8, #0x120]
    // 0x67809c: r3 = Null
    //     0x67809c: add             x3, PP, #0x43, lsl #12  ; [pp+0x43510] Null
    //     0x6780a0: ldr             x3, [x3, #0x510]
    // 0x6780a4: r0 = DefaultTypeTest()
    //     0x6780a4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6780a8: ldur            x0, [fp, #-8]
    // 0x6780ac: LoadField: r3 = r0->field_f
    //     0x6780ac: ldur            w3, [x0, #0xf]
    // 0x6780b0: DecompressPointer r3
    //     0x6780b0: add             x3, x3, HEAP, lsl #32
    // 0x6780b4: stur            x3, [fp, #-0x18]
    // 0x6780b8: cmp             w3, NULL
    // 0x6780bc: b.eq            #0x678180
    // 0x6780c0: ldur            x4, [fp, #-0x30]
    // 0x6780c4: LoadField: r5 = r3->field_17
    //     0x6780c4: ldur            w5, [x3, #0x17]
    // 0x6780c8: DecompressPointer r5
    //     0x6780c8: add             x5, x5, HEAP, lsl #32
    // 0x6780cc: stur            x5, [fp, #-8]
    // 0x6780d0: cmp             w5, NULL
    // 0x6780d4: b.eq            #0x6781bc
    // 0x6780d8: mov             x0, x5
    // 0x6780dc: r2 = Null
    //     0x6780dc: mov             x2, NULL
    // 0x6780e0: r1 = Null
    //     0x6780e0: mov             x1, NULL
    // 0x6780e4: r4 = LoadClassIdInstr(r0)
    //     0x6780e4: ldur            x4, [x0, #-1]
    //     0x6780e8: ubfx            x4, x4, #0xc, #0x14
    // 0x6780ec: sub             x4, x4, #0x7f9
    // 0x6780f0: cmp             x4, #2
    // 0x6780f4: b.ls            #0x67810c
    // 0x6780f8: r8 = SliverMultiBoxAdaptorParentData
    //     0x6780f8: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x6780fc: ldr             x8, [x8, #0x120]
    // 0x678100: r3 = Null
    //     0x678100: add             x3, PP, #0x43, lsl #12  ; [pp+0x43520] Null
    //     0x678104: ldr             x3, [x3, #0x520]
    // 0x678108: r0 = DefaultTypeTest()
    //     0x678108: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x67810c: ldur            x0, [fp, #-8]
    // 0x678110: LoadField: r1 = r0->field_17
    //     0x678110: ldur            w1, [x0, #0x17]
    // 0x678114: DecompressPointer r1
    //     0x678114: add             x1, x1, HEAP, lsl #32
    // 0x678118: cmp             w1, NULL
    // 0x67811c: b.eq            #0x6781c0
    // 0x678120: r0 = LoadInt32Instr(r1)
    //     0x678120: sbfx            x0, x1, #1, #0x1f
    //     0x678124: tbz             w1, #0, #0x67812c
    //     0x678128: ldur            x0, [x1, #7]
    // 0x67812c: ldur            x1, [fp, #-0x30]
    // 0x678130: cmp             x0, x1
    // 0x678134: b.ne            #0x678180
    // 0x678138: ldur            x1, [fp, #-0x18]
    // 0x67813c: r0 = LoadClassIdInstr(r1)
    //     0x67813c: ldur            x0, [x1, #-1]
    //     0x678140: ubfx            x0, x0, #0xc, #0x14
    // 0x678144: ldur            x16, [fp, #-0x20]
    // 0x678148: stp             x16, x1, [SP, #-0x10]!
    // 0x67814c: ldur            x16, [fp, #-0x10]
    // 0x678150: SaveReg r16
    //     0x678150: str             x16, [SP, #-8]!
    // 0x678154: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x678154: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x678158: ldr             x4, [x4, #0x1c8]
    // 0x67815c: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x67815c: mov             x17, #0xcdfb
    //     0x678160: add             lr, x0, x17
    //     0x678164: ldr             lr, [x21, lr, lsl #3]
    //     0x678168: blr             lr
    // 0x67816c: add             SP, SP, #0x18
    // 0x678170: ldur            x0, [fp, #-0x18]
    // 0x678174: LeaveFrame
    //     0x678174: mov             SP, fp
    //     0x678178: ldp             fp, lr, [SP], #0x10
    // 0x67817c: ret
    //     0x67817c: ret             
    // 0x678180: ldur            x1, [fp, #-0x28]
    // 0x678184: r2 = true
    //     0x678184: add             x2, NULL, #0x20  ; true
    // 0x678188: LoadField: r3 = r1->field_63
    //     0x678188: ldur            w3, [x1, #0x63]
    // 0x67818c: DecompressPointer r3
    //     0x67818c: add             x3, x3, HEAP, lsl #32
    // 0x678190: StoreField: r3->field_53 = r2
    //     0x678190: stur            w2, [x3, #0x53]
    // 0x678194: r0 = Null
    //     0x678194: mov             x0, NULL
    // 0x678198: LeaveFrame
    //     0x678198: mov             SP, fp
    //     0x67819c: ldp             fp, lr, [SP], #0x10
    // 0x6781a0: ret
    //     0x6781a0: ret             
    // 0x6781a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6781a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6781a8: b               #0x677fcc
    // 0x6781ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6781ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6781b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6781b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6781b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6781b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6781b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6781b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6781bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6781bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6781c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6781c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _createOrObtainChild(/* No info */) {
    // ** addr: 0x6781c4, size: 0x90
    // 0x6781c4: EnterFrame
    //     0x6781c4: stp             fp, lr, [SP, #-0x10]!
    //     0x6781c8: mov             fp, SP
    // 0x6781cc: CheckStackOverflow
    //     0x6781cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6781d0: cmp             SP, x16
    //     0x6781d4: b.ls            #0x67824c
    // 0x6781d8: r1 = 3
    //     0x6781d8: mov             x1, #3
    // 0x6781dc: r0 = AllocateContext()
    //     0x6781dc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6781e0: mov             x2, x0
    // 0x6781e4: ldr             x3, [fp, #0x20]
    // 0x6781e8: StoreField: r2->field_f = r3
    //     0x6781e8: stur            w3, [x2, #0xf]
    // 0x6781ec: ldr             x4, [fp, #0x18]
    // 0x6781f0: r0 = BoxInt64Instr(r4)
    //     0x6781f0: sbfiz           x0, x4, #1, #0x1f
    //     0x6781f4: cmp             x4, x0, asr #1
    //     0x6781f8: b.eq            #0x678204
    //     0x6781fc: bl              #0xd69bb8
    //     0x678200: stur            x4, [x0, #7]
    // 0x678204: StoreField: r2->field_13 = r0
    //     0x678204: stur            w0, [x2, #0x13]
    // 0x678208: ldr             x0, [fp, #0x10]
    // 0x67820c: StoreField: r2->field_17 = r0
    //     0x67820c: stur            w0, [x2, #0x17]
    // 0x678210: r1 = Function '<anonymous closure>':.
    //     0x678210: add             x1, PP, #0x43, lsl #12  ; [pp+0x43470] AnonymousClosure: (0x6784f4), in [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::_createOrObtainChild (0x6781c4)
    //     0x678214: ldr             x1, [x1, #0x470]
    // 0x678218: r0 = AllocateClosure()
    //     0x678218: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x67821c: r16 = <SliverConstraints>
    //     0x67821c: add             x16, PP, #0x43, lsl #12  ; [pp+0x43478] TypeArguments: <SliverConstraints>
    //     0x678220: ldr             x16, [x16, #0x478]
    // 0x678224: ldr             lr, [fp, #0x20]
    // 0x678228: stp             lr, x16, [SP, #-0x10]!
    // 0x67822c: SaveReg r0
    //     0x67822c: str             x0, [SP, #-8]!
    // 0x678230: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x678230: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x678234: r0 = invokeLayoutCallback()
    //     0x678234: bl              #0x678254  ; [package:flutter/src/rendering/object.dart] RenderObject::invokeLayoutCallback
    // 0x678238: add             SP, SP, #0x18
    // 0x67823c: r0 = Null
    //     0x67823c: mov             x0, NULL
    // 0x678240: LeaveFrame
    //     0x678240: mov             SP, fp
    //     0x678244: ldp             fp, lr, [SP], #0x10
    // 0x678248: ret
    //     0x678248: ret             
    // 0x67824c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x67824c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x678250: b               #0x6781d8
  }
  [closure] void <anonymous closure>(dynamic, SliverConstraints) {
    // ** addr: 0x6784f4, size: 0x1a4
    // 0x6784f4: EnterFrame
    //     0x6784f4: stp             fp, lr, [SP, #-0x10]!
    //     0x6784f8: mov             fp, SP
    // 0x6784fc: AllocStack(0x18)
    //     0x6784fc: sub             SP, SP, #0x18
    // 0x678500: SetupParameters()
    //     0x678500: ldr             x0, [fp, #0x18]
    //     0x678504: ldur            w1, [x0, #0x17]
    //     0x678508: add             x1, x1, HEAP, lsl #32
    //     0x67850c: stur            x1, [fp, #-8]
    // 0x678510: CheckStackOverflow
    //     0x678510: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x678514: cmp             SP, x16
    //     0x678518: b.ls            #0x678688
    // 0x67851c: LoadField: r0 = r1->field_f
    //     0x67851c: ldur            w0, [x1, #0xf]
    // 0x678520: DecompressPointer r0
    //     0x678520: add             x0, x0, HEAP, lsl #32
    // 0x678524: LoadField: r2 = r0->field_67
    //     0x678524: ldur            w2, [x0, #0x67]
    // 0x678528: DecompressPointer r2
    //     0x678528: add             x2, x2, HEAP, lsl #32
    // 0x67852c: LoadField: r0 = r1->field_13
    //     0x67852c: ldur            w0, [x1, #0x13]
    // 0x678530: DecompressPointer r0
    //     0x678530: add             x0, x0, HEAP, lsl #32
    // 0x678534: stp             x0, x2, [SP, #-0x10]!
    // 0x678538: r0 = containsKey()
    //     0x678538: bl              #0xca679c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x67853c: add             SP, SP, #0x10
    // 0x678540: tbnz            w0, #4, #0x678638
    // 0x678544: ldur            x0, [fp, #-8]
    // 0x678548: LoadField: r1 = r0->field_f
    //     0x678548: ldur            w1, [x0, #0xf]
    // 0x67854c: DecompressPointer r1
    //     0x67854c: add             x1, x1, HEAP, lsl #32
    // 0x678550: LoadField: r2 = r1->field_67
    //     0x678550: ldur            w2, [x1, #0x67]
    // 0x678554: DecompressPointer r2
    //     0x678554: add             x2, x2, HEAP, lsl #32
    // 0x678558: LoadField: r1 = r0->field_13
    //     0x678558: ldur            w1, [x0, #0x13]
    // 0x67855c: DecompressPointer r1
    //     0x67855c: add             x1, x1, HEAP, lsl #32
    // 0x678560: stp             x1, x2, [SP, #-0x10]!
    // 0x678564: r0 = remove()
    //     0x678564: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x678568: add             SP, SP, #0x10
    // 0x67856c: mov             x3, x0
    // 0x678570: stur            x3, [fp, #-0x18]
    // 0x678574: cmp             w3, NULL
    // 0x678578: b.eq            #0x678690
    // 0x67857c: LoadField: r4 = r3->field_17
    //     0x67857c: ldur            w4, [x3, #0x17]
    // 0x678580: DecompressPointer r4
    //     0x678580: add             x4, x4, HEAP, lsl #32
    // 0x678584: stur            x4, [fp, #-0x10]
    // 0x678588: cmp             w4, NULL
    // 0x67858c: b.eq            #0x678694
    // 0x678590: mov             x0, x4
    // 0x678594: r2 = Null
    //     0x678594: mov             x2, NULL
    // 0x678598: r1 = Null
    //     0x678598: mov             x1, NULL
    // 0x67859c: r4 = LoadClassIdInstr(r0)
    //     0x67859c: ldur            x4, [x0, #-1]
    //     0x6785a0: ubfx            x4, x4, #0xc, #0x14
    // 0x6785a4: sub             x4, x4, #0x7f9
    // 0x6785a8: cmp             x4, #2
    // 0x6785ac: b.ls            #0x6785c4
    // 0x6785b0: r8 = SliverMultiBoxAdaptorParentData
    //     0x6785b0: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x6785b4: ldr             x8, [x8, #0x120]
    // 0x6785b8: r3 = Null
    //     0x6785b8: add             x3, PP, #0x43, lsl #12  ; [pp+0x43480] Null
    //     0x6785bc: ldr             x3, [x3, #0x480]
    // 0x6785c0: r0 = DefaultTypeTest()
    //     0x6785c0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6785c4: ldur            x0, [fp, #-8]
    // 0x6785c8: LoadField: r1 = r0->field_f
    //     0x6785c8: ldur            w1, [x0, #0xf]
    // 0x6785cc: DecompressPointer r1
    //     0x6785cc: add             x1, x1, HEAP, lsl #32
    // 0x6785d0: ldur            x16, [fp, #-0x18]
    // 0x6785d4: stp             x16, x1, [SP, #-0x10]!
    // 0x6785d8: r0 = dropChild()
    //     0x6785d8: bl              #0x5e5aec  ; [package:flutter/src/rendering/object.dart] RenderObject::dropChild
    // 0x6785dc: add             SP, SP, #0x10
    // 0x6785e0: ldur            x0, [fp, #-0x10]
    // 0x6785e4: ldur            x1, [fp, #-0x18]
    // 0x6785e8: StoreField: r1->field_17 = r0
    //     0x6785e8: stur            w0, [x1, #0x17]
    //     0x6785ec: ldurb           w16, [x1, #-1]
    //     0x6785f0: ldurb           w17, [x0, #-1]
    //     0x6785f4: and             x16, x17, x16, lsr #2
    //     0x6785f8: tst             x16, HEAP, lsr #32
    //     0x6785fc: b.eq            #0x678604
    //     0x678600: bl              #0xd6826c
    // 0x678604: ldur            x0, [fp, #-8]
    // 0x678608: LoadField: r2 = r0->field_f
    //     0x678608: ldur            w2, [x0, #0xf]
    // 0x67860c: DecompressPointer r2
    //     0x67860c: add             x2, x2, HEAP, lsl #32
    // 0x678610: LoadField: r3 = r0->field_17
    //     0x678610: ldur            w3, [x0, #0x17]
    // 0x678614: DecompressPointer r3
    //     0x678614: add             x3, x3, HEAP, lsl #32
    // 0x678618: stp             x1, x2, [SP, #-0x10]!
    // 0x67861c: SaveReg r3
    //     0x67861c: str             x3, [SP, #-8]!
    // 0x678620: r0 = insert()
    //     0x678620: bl              #0x5e60a8  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] _RenderSliverMultiBoxAdaptor&RenderSliver&ContainerRenderObjectMixin::insert
    // 0x678624: add             SP, SP, #0x18
    // 0x678628: ldur            x0, [fp, #-0x10]
    // 0x67862c: r1 = false
    //     0x67862c: add             x1, NULL, #0x30  ; false
    // 0x678630: StoreField: r0->field_1b = r1
    //     0x678630: stur            w1, [x0, #0x1b]
    // 0x678634: b               #0x678678
    // 0x678638: ldur            x0, [fp, #-8]
    // 0x67863c: LoadField: r1 = r0->field_f
    //     0x67863c: ldur            w1, [x0, #0xf]
    // 0x678640: DecompressPointer r1
    //     0x678640: add             x1, x1, HEAP, lsl #32
    // 0x678644: LoadField: r2 = r1->field_63
    //     0x678644: ldur            w2, [x1, #0x63]
    // 0x678648: DecompressPointer r2
    //     0x678648: add             x2, x2, HEAP, lsl #32
    // 0x67864c: LoadField: r1 = r0->field_13
    //     0x67864c: ldur            w1, [x0, #0x13]
    // 0x678650: DecompressPointer r1
    //     0x678650: add             x1, x1, HEAP, lsl #32
    // 0x678654: LoadField: r3 = r0->field_17
    //     0x678654: ldur            w3, [x0, #0x17]
    // 0x678658: DecompressPointer r3
    //     0x678658: add             x3, x3, HEAP, lsl #32
    // 0x67865c: r0 = LoadInt32Instr(r1)
    //     0x67865c: sbfx            x0, x1, #1, #0x1f
    //     0x678660: tbz             w1, #0, #0x678668
    //     0x678664: ldur            x0, [x1, #7]
    // 0x678668: stp             x0, x2, [SP, #-0x10]!
    // 0x67866c: SaveReg r3
    //     0x67866c: str             x3, [SP, #-8]!
    // 0x678670: r0 = createChild()
    //     0x678670: bl              #0x678698  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::createChild
    // 0x678674: add             SP, SP, #0x18
    // 0x678678: r0 = Null
    //     0x678678: mov             x0, NULL
    // 0x67867c: LeaveFrame
    //     0x67867c: mov             SP, fp
    //     0x678680: ldp             fp, lr, [SP], #0x10
    // 0x678684: ret
    //     0x678684: ret             
    // 0x678688: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x678688: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x67868c: b               #0x67851c
    // 0x678690: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x678690: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x678694: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x678694: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ insertAndLayoutLeadingChild(/* No info */) {
    // ** addr: 0x678a4c, size: 0x238
    // 0x678a4c: EnterFrame
    //     0x678a4c: stp             fp, lr, [SP, #-0x10]!
    //     0x678a50: mov             fp, SP
    // 0x678a54: AllocStack(0x30)
    //     0x678a54: sub             SP, SP, #0x30
    // 0x678a58: SetupParameters(RenderSliverMultiBoxAdaptor this /* r3, fp-0x20 */, dynamic _ /* r4, fp-0x18 */, {dynamic parentUsesSize = false /* r5, fp-0x10 */})
    //     0x678a58: mov             x0, x4
    //     0x678a5c: ldur            w1, [x0, #0x13]
    //     0x678a60: add             x1, x1, HEAP, lsl #32
    //     0x678a64: sub             x2, x1, #4
    //     0x678a68: add             x3, fp, w2, sxtw #2
    //     0x678a6c: ldr             x3, [x3, #0x18]
    //     0x678a70: stur            x3, [fp, #-0x20]
    //     0x678a74: add             x4, fp, w2, sxtw #2
    //     0x678a78: ldr             x4, [x4, #0x10]
    //     0x678a7c: stur            x4, [fp, #-0x18]
    //     0x678a80: ldur            w2, [x0, #0x1f]
    //     0x678a84: add             x2, x2, HEAP, lsl #32
    //     0x678a88: add             x16, PP, #0xb, lsl #12  ; [pp+0xb000] "parentUsesSize"
    //     0x678a8c: ldr             x16, [x16]
    //     0x678a90: cmp             w2, w16
    //     0x678a94: b.ne            #0x678ab4
    //     0x678a98: ldur            w2, [x0, #0x23]
    //     0x678a9c: add             x2, x2, HEAP, lsl #32
    //     0x678aa0: sub             w0, w1, w2
    //     0x678aa4: add             x1, fp, w0, sxtw #2
    //     0x678aa8: ldr             x1, [x1, #8]
    //     0x678aac: mov             x5, x1
    //     0x678ab0: b               #0x678ab8
    //     0x678ab4: add             x5, NULL, #0x30  ; false
    //     0x678ab8: stur            x5, [fp, #-0x10]
    // 0x678abc: CheckStackOverflow
    //     0x678abc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x678ac0: cmp             SP, x16
    //     0x678ac4: b.ls            #0x678c64
    // 0x678ac8: LoadField: r0 = r3->field_5b
    //     0x678ac8: ldur            w0, [x3, #0x5b]
    // 0x678acc: DecompressPointer r0
    //     0x678acc: add             x0, x0, HEAP, lsl #32
    // 0x678ad0: cmp             w0, NULL
    // 0x678ad4: b.eq            #0x678c6c
    // 0x678ad8: LoadField: r6 = r0->field_17
    //     0x678ad8: ldur            w6, [x0, #0x17]
    // 0x678adc: DecompressPointer r6
    //     0x678adc: add             x6, x6, HEAP, lsl #32
    // 0x678ae0: stur            x6, [fp, #-8]
    // 0x678ae4: cmp             w6, NULL
    // 0x678ae8: b.eq            #0x678c70
    // 0x678aec: mov             x0, x6
    // 0x678af0: r2 = Null
    //     0x678af0: mov             x2, NULL
    // 0x678af4: r1 = Null
    //     0x678af4: mov             x1, NULL
    // 0x678af8: r4 = LoadClassIdInstr(r0)
    //     0x678af8: ldur            x4, [x0, #-1]
    //     0x678afc: ubfx            x4, x4, #0xc, #0x14
    // 0x678b00: sub             x4, x4, #0x7f9
    // 0x678b04: cmp             x4, #2
    // 0x678b08: b.ls            #0x678b20
    // 0x678b0c: r8 = SliverMultiBoxAdaptorParentData
    //     0x678b0c: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x678b10: ldr             x8, [x8, #0x120]
    // 0x678b14: r3 = Null
    //     0x678b14: add             x3, PP, #0x43, lsl #12  ; [pp+0x43450] Null
    //     0x678b18: ldr             x3, [x3, #0x450]
    // 0x678b1c: r0 = DefaultTypeTest()
    //     0x678b1c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x678b20: ldur            x0, [fp, #-8]
    // 0x678b24: LoadField: r1 = r0->field_17
    //     0x678b24: ldur            w1, [x0, #0x17]
    // 0x678b28: DecompressPointer r1
    //     0x678b28: add             x1, x1, HEAP, lsl #32
    // 0x678b2c: cmp             w1, NULL
    // 0x678b30: b.eq            #0x678c74
    // 0x678b34: r0 = LoadInt32Instr(r1)
    //     0x678b34: sbfx            x0, x1, #1, #0x1f
    //     0x678b38: tbz             w1, #0, #0x678b40
    //     0x678b3c: ldur            x0, [x1, #7]
    // 0x678b40: sub             x1, x0, #1
    // 0x678b44: stur            x1, [fp, #-0x28]
    // 0x678b48: ldur            x16, [fp, #-0x20]
    // 0x678b4c: stp             x1, x16, [SP, #-0x10]!
    // 0x678b50: SaveReg rNULL
    //     0x678b50: str             NULL, [SP, #-8]!
    // 0x678b54: r0 = _createOrObtainChild()
    //     0x678b54: bl              #0x6781c4  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::_createOrObtainChild
    // 0x678b58: add             SP, SP, #0x18
    // 0x678b5c: ldur            x3, [fp, #-0x20]
    // 0x678b60: LoadField: r4 = r3->field_5b
    //     0x678b60: ldur            w4, [x3, #0x5b]
    // 0x678b64: DecompressPointer r4
    //     0x678b64: add             x4, x4, HEAP, lsl #32
    // 0x678b68: stur            x4, [fp, #-0x30]
    // 0x678b6c: cmp             w4, NULL
    // 0x678b70: b.eq            #0x678c78
    // 0x678b74: LoadField: r5 = r4->field_17
    //     0x678b74: ldur            w5, [x4, #0x17]
    // 0x678b78: DecompressPointer r5
    //     0x678b78: add             x5, x5, HEAP, lsl #32
    // 0x678b7c: stur            x5, [fp, #-8]
    // 0x678b80: cmp             w5, NULL
    // 0x678b84: b.eq            #0x678c7c
    // 0x678b88: mov             x0, x5
    // 0x678b8c: r2 = Null
    //     0x678b8c: mov             x2, NULL
    // 0x678b90: r1 = Null
    //     0x678b90: mov             x1, NULL
    // 0x678b94: r4 = LoadClassIdInstr(r0)
    //     0x678b94: ldur            x4, [x0, #-1]
    //     0x678b98: ubfx            x4, x4, #0xc, #0x14
    // 0x678b9c: sub             x4, x4, #0x7f9
    // 0x678ba0: cmp             x4, #2
    // 0x678ba4: b.ls            #0x678bbc
    // 0x678ba8: r8 = SliverMultiBoxAdaptorParentData
    //     0x678ba8: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x678bac: ldr             x8, [x8, #0x120]
    // 0x678bb0: r3 = Null
    //     0x678bb0: add             x3, PP, #0x43, lsl #12  ; [pp+0x43460] Null
    //     0x678bb4: ldr             x3, [x3, #0x460]
    // 0x678bb8: r0 = DefaultTypeTest()
    //     0x678bb8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x678bbc: ldur            x0, [fp, #-8]
    // 0x678bc0: LoadField: r1 = r0->field_17
    //     0x678bc0: ldur            w1, [x0, #0x17]
    // 0x678bc4: DecompressPointer r1
    //     0x678bc4: add             x1, x1, HEAP, lsl #32
    // 0x678bc8: cmp             w1, NULL
    // 0x678bcc: b.eq            #0x678c80
    // 0x678bd0: r0 = LoadInt32Instr(r1)
    //     0x678bd0: sbfx            x0, x1, #1, #0x1f
    //     0x678bd4: tbz             w1, #0, #0x678bdc
    //     0x678bd8: ldur            x0, [x1, #7]
    // 0x678bdc: ldur            x1, [fp, #-0x28]
    // 0x678be0: cmp             x0, x1
    // 0x678be4: b.ne            #0x678c40
    // 0x678be8: ldur            x1, [fp, #-0x20]
    // 0x678bec: ldur            x0, [fp, #-0x30]
    // 0x678bf0: r2 = LoadClassIdInstr(r0)
    //     0x678bf0: ldur            x2, [x0, #-1]
    //     0x678bf4: ubfx            x2, x2, #0xc, #0x14
    // 0x678bf8: ldur            x16, [fp, #-0x18]
    // 0x678bfc: stp             x16, x0, [SP, #-0x10]!
    // 0x678c00: ldur            x16, [fp, #-0x10]
    // 0x678c04: SaveReg r16
    //     0x678c04: str             x16, [SP, #-8]!
    // 0x678c08: mov             x0, x2
    // 0x678c0c: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x678c0c: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x678c10: ldr             x4, [x4, #0x1c8]
    // 0x678c14: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x678c14: mov             x17, #0xcdfb
    //     0x678c18: add             lr, x0, x17
    //     0x678c1c: ldr             lr, [x21, lr, lsl #3]
    //     0x678c20: blr             lr
    // 0x678c24: add             SP, SP, #0x18
    // 0x678c28: ldur            x1, [fp, #-0x20]
    // 0x678c2c: LoadField: r0 = r1->field_5b
    //     0x678c2c: ldur            w0, [x1, #0x5b]
    // 0x678c30: DecompressPointer r0
    //     0x678c30: add             x0, x0, HEAP, lsl #32
    // 0x678c34: LeaveFrame
    //     0x678c34: mov             SP, fp
    //     0x678c38: ldp             fp, lr, [SP], #0x10
    // 0x678c3c: ret
    //     0x678c3c: ret             
    // 0x678c40: ldur            x1, [fp, #-0x20]
    // 0x678c44: r2 = true
    //     0x678c44: add             x2, NULL, #0x20  ; true
    // 0x678c48: LoadField: r3 = r1->field_63
    //     0x678c48: ldur            w3, [x1, #0x63]
    // 0x678c4c: DecompressPointer r3
    //     0x678c4c: add             x3, x3, HEAP, lsl #32
    // 0x678c50: StoreField: r3->field_53 = r2
    //     0x678c50: stur            w2, [x3, #0x53]
    // 0x678c54: r0 = Null
    //     0x678c54: mov             x0, NULL
    // 0x678c58: LeaveFrame
    //     0x678c58: mov             SP, fp
    //     0x678c5c: ldp             fp, lr, [SP], #0x10
    // 0x678c60: ret
    //     0x678c60: ret             
    // 0x678c64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x678c64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x678c68: b               #0x678ac8
    // 0x678c6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x678c6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x678c70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x678c70: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x678c74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x678c74: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x678c78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x678c78: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x678c7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x678c7c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x678c80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x678c80: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ addInitialChild(/* No info */) {
    // ** addr: 0x6795e8, size: 0x1d4
    // 0x6795e8: EnterFrame
    //     0x6795e8: stp             fp, lr, [SP, #-0x10]!
    //     0x6795ec: mov             fp, SP
    // 0x6795f0: AllocStack(0x18)
    //     0x6795f0: sub             SP, SP, #0x18
    // 0x6795f4: SetupParameters(RenderSliverMultiBoxAdaptor this /* r3, fp-0x8 */, {int index = 0 /* r4 */, _Double layoutOffset = 0.000000 /* d0, fp-0x18 */})
    //     0x6795f4: mov             x0, x4
    //     0x6795f8: ldur            w1, [x0, #0x13]
    //     0x6795fc: add             x1, x1, HEAP, lsl #32
    //     0x679600: sub             x2, x1, #2
    //     0x679604: add             x3, fp, w2, sxtw #2
    //     0x679608: ldr             x3, [x3, #0x10]
    //     0x67960c: stur            x3, [fp, #-8]
    //     0x679610: ldur            w2, [x0, #0x1f]
    //     0x679614: add             x2, x2, HEAP, lsl #32
    //     0x679618: ldr             x16, [PP, #0xd38]  ; [pp+0xd38] "index"
    //     0x67961c: cmp             w2, w16
    //     0x679620: b.ne            #0x67964c
    //     0x679624: ldur            w2, [x0, #0x23]
    //     0x679628: add             x2, x2, HEAP, lsl #32
    //     0x67962c: sub             w4, w1, w2
    //     0x679630: add             x2, fp, w4, sxtw #2
    //     0x679634: ldr             x2, [x2, #8]
    //     0x679638: sbfx            x4, x2, #1, #0x1f
    //     0x67963c: tbz             w2, #0, #0x679644
    //     0x679640: ldur            x4, [x2, #7]
    //     0x679644: mov             x2, #1
    //     0x679648: b               #0x679654
    //     0x67964c: mov             x4, #0
    //     0x679650: mov             x2, #0
    //     0x679654: lsl             x5, x2, #1
    //     0x679658: lsl             w2, w5, #1
    //     0x67965c: add             w5, w2, #8
    //     0x679660: add             x16, x0, w5, sxtw #1
    //     0x679664: ldur            w6, [x16, #0xf]
    //     0x679668: add             x6, x6, HEAP, lsl #32
    //     0x67966c: add             x16, PP, #0x43, lsl #12  ; [pp+0x43548] "layoutOffset"
    //     0x679670: ldr             x16, [x16, #0x548]
    //     0x679674: cmp             w6, w16
    //     0x679678: b.ne            #0x6796a0
    //     0x67967c: add             w5, w2, #0xa
    //     0x679680: add             x16, x0, w5, sxtw #1
    //     0x679684: ldur            w2, [x16, #0xf]
    //     0x679688: add             x2, x2, HEAP, lsl #32
    //     0x67968c: sub             w0, w1, w2
    //     0x679690: add             x1, fp, w0, sxtw #2
    //     0x679694: ldr             x1, [x1, #8]
    //     0x679698: ldur            d0, [x1, #7]
    //     0x67969c: b               #0x6796a4
    //     0x6796a0: eor             v0.16b, v0.16b, v0.16b
    //     0x6796a4: stur            d0, [fp, #-0x18]
    // 0x6796a8: CheckStackOverflow
    //     0x6796a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6796ac: cmp             SP, x16
    //     0x6796b0: b.ls            #0x6797a0
    // 0x6796b4: stp             x4, x3, [SP, #-0x10]!
    // 0x6796b8: SaveReg rNULL
    //     0x6796b8: str             NULL, [SP, #-8]!
    // 0x6796bc: r0 = _createOrObtainChild()
    //     0x6796bc: bl              #0x6781c4  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::_createOrObtainChild
    // 0x6796c0: add             SP, SP, #0x18
    // 0x6796c4: ldur            x0, [fp, #-8]
    // 0x6796c8: LoadField: r1 = r0->field_5b
    //     0x6796c8: ldur            w1, [x0, #0x5b]
    // 0x6796cc: DecompressPointer r1
    //     0x6796cc: add             x1, x1, HEAP, lsl #32
    // 0x6796d0: cmp             w1, NULL
    // 0x6796d4: b.eq            #0x679780
    // 0x6796d8: ldur            d0, [fp, #-0x18]
    // 0x6796dc: LoadField: r3 = r1->field_17
    //     0x6796dc: ldur            w3, [x1, #0x17]
    // 0x6796e0: DecompressPointer r3
    //     0x6796e0: add             x3, x3, HEAP, lsl #32
    // 0x6796e4: stur            x3, [fp, #-0x10]
    // 0x6796e8: cmp             w3, NULL
    // 0x6796ec: b.eq            #0x6797a8
    // 0x6796f0: mov             x0, x3
    // 0x6796f4: r2 = Null
    //     0x6796f4: mov             x2, NULL
    // 0x6796f8: r1 = Null
    //     0x6796f8: mov             x1, NULL
    // 0x6796fc: r4 = LoadClassIdInstr(r0)
    //     0x6796fc: ldur            x4, [x0, #-1]
    //     0x679700: ubfx            x4, x4, #0xc, #0x14
    // 0x679704: sub             x4, x4, #0x7f9
    // 0x679708: cmp             x4, #2
    // 0x67970c: b.ls            #0x679724
    // 0x679710: r8 = SliverMultiBoxAdaptorParentData
    //     0x679710: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x679714: ldr             x8, [x8, #0x120]
    // 0x679718: r3 = Null
    //     0x679718: add             x3, PP, #0x43, lsl #12  ; [pp+0x43550] Null
    //     0x67971c: ldr             x3, [x3, #0x550]
    // 0x679720: r0 = DefaultTypeTest()
    //     0x679720: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x679724: ldur            d0, [fp, #-0x18]
    // 0x679728: r0 = inline_Allocate_Double()
    //     0x679728: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x67972c: add             x0, x0, #0x10
    //     0x679730: cmp             x1, x0
    //     0x679734: b.ls            #0x6797ac
    //     0x679738: str             x0, [THR, #0x60]  ; THR::top
    //     0x67973c: sub             x0, x0, #0xf
    //     0x679740: mov             x1, #0xd108
    //     0x679744: movk            x1, #3, lsl #16
    //     0x679748: stur            x1, [x0, #-1]
    // 0x67974c: StoreField: r0->field_7 = d0
    //     0x67974c: stur            d0, [x0, #7]
    // 0x679750: ldur            x1, [fp, #-0x10]
    // 0x679754: StoreField: r1->field_7 = r0
    //     0x679754: stur            w0, [x1, #7]
    //     0x679758: ldurb           w16, [x1, #-1]
    //     0x67975c: ldurb           w17, [x0, #-1]
    //     0x679760: and             x16, x17, x16, lsr #2
    //     0x679764: tst             x16, HEAP, lsr #32
    //     0x679768: b.eq            #0x679770
    //     0x67976c: bl              #0xd6826c
    // 0x679770: r0 = true
    //     0x679770: add             x0, NULL, #0x20  ; true
    // 0x679774: LeaveFrame
    //     0x679774: mov             SP, fp
    //     0x679778: ldp             fp, lr, [SP], #0x10
    // 0x67977c: ret
    //     0x67977c: ret             
    // 0x679780: r1 = true
    //     0x679780: add             x1, NULL, #0x20  ; true
    // 0x679784: LoadField: r2 = r0->field_63
    //     0x679784: ldur            w2, [x0, #0x63]
    // 0x679788: DecompressPointer r2
    //     0x679788: add             x2, x2, HEAP, lsl #32
    // 0x67978c: StoreField: r2->field_53 = r1
    //     0x67978c: stur            w1, [x2, #0x53]
    // 0x679790: r0 = false
    //     0x679790: add             x0, NULL, #0x30  ; false
    // 0x679794: LeaveFrame
    //     0x679794: mov             SP, fp
    //     0x679798: ldp             fp, lr, [SP], #0x10
    // 0x67979c: ret
    //     0x67979c: ret             
    // 0x6797a0: r0 = StackOverflowSharedWithFPURegs()
    //     0x6797a0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x6797a4: b               #0x6796b4
    // 0x6797a8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6797a8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6797ac: SaveReg d0
    //     0x6797ac: str             q0, [SP, #-0x10]!
    // 0x6797b0: r0 = AllocateDouble()
    //     0x6797b0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6797b4: RestoreReg d0
    //     0x6797b4: ldr             q0, [SP], #0x10
    // 0x6797b8: b               #0x67974c
  }
  _ collectGarbage(/* No info */) {
    // ** addr: 0x6797bc, size: 0x90
    // 0x6797bc: EnterFrame
    //     0x6797bc: stp             fp, lr, [SP, #-0x10]!
    //     0x6797c0: mov             fp, SP
    // 0x6797c4: CheckStackOverflow
    //     0x6797c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6797c8: cmp             SP, x16
    //     0x6797cc: b.ls            #0x679844
    // 0x6797d0: r1 = 3
    //     0x6797d0: mov             x1, #3
    // 0x6797d4: r0 = AllocateContext()
    //     0x6797d4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6797d8: mov             x2, x0
    // 0x6797dc: ldr             x3, [fp, #0x20]
    // 0x6797e0: StoreField: r2->field_f = r3
    //     0x6797e0: stur            w3, [x2, #0xf]
    // 0x6797e4: ldr             x0, [fp, #0x18]
    // 0x6797e8: StoreField: r2->field_13 = r0
    //     0x6797e8: stur            w0, [x2, #0x13]
    // 0x6797ec: ldr             x4, [fp, #0x10]
    // 0x6797f0: r0 = BoxInt64Instr(r4)
    //     0x6797f0: sbfiz           x0, x4, #1, #0x1f
    //     0x6797f4: cmp             x4, x0, asr #1
    //     0x6797f8: b.eq            #0x679804
    //     0x6797fc: bl              #0xd69bb8
    //     0x679800: stur            x4, [x0, #7]
    // 0x679804: StoreField: r2->field_17 = r0
    //     0x679804: stur            w0, [x2, #0x17]
    // 0x679808: r1 = Function '<anonymous closure>':.
    //     0x679808: add             x1, PP, #0x43, lsl #12  ; [pp+0x435a0] AnonymousClosure: (0x67984c), in [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::collectGarbage (0x6797bc)
    //     0x67980c: ldr             x1, [x1, #0x5a0]
    // 0x679810: r0 = AllocateClosure()
    //     0x679810: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x679814: r16 = <SliverConstraints>
    //     0x679814: add             x16, PP, #0x43, lsl #12  ; [pp+0x43478] TypeArguments: <SliverConstraints>
    //     0x679818: ldr             x16, [x16, #0x478]
    // 0x67981c: ldr             lr, [fp, #0x20]
    // 0x679820: stp             lr, x16, [SP, #-0x10]!
    // 0x679824: SaveReg r0
    //     0x679824: str             x0, [SP, #-8]!
    // 0x679828: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x679828: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x67982c: r0 = invokeLayoutCallback()
    //     0x67982c: bl              #0x678254  ; [package:flutter/src/rendering/object.dart] RenderObject::invokeLayoutCallback
    // 0x679830: add             SP, SP, #0x18
    // 0x679834: r0 = Null
    //     0x679834: mov             x0, NULL
    // 0x679838: LeaveFrame
    //     0x679838: mov             SP, fp
    //     0x67983c: ldp             fp, lr, [SP], #0x10
    // 0x679840: ret
    //     0x679840: ret             
    // 0x679844: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x679844: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x679848: b               #0x6797d0
  }
  [closure] void <anonymous closure>(dynamic, SliverConstraints) {
    // ** addr: 0x67984c, size: 0x288
    // 0x67984c: EnterFrame
    //     0x67984c: stp             fp, lr, [SP, #-0x10]!
    //     0x679850: mov             fp, SP
    // 0x679854: AllocStack(0x10)
    //     0x679854: sub             SP, SP, #0x10
    // 0x679858: SetupParameters()
    //     0x679858: ldr             x0, [fp, #0x18]
    //     0x67985c: ldur            w1, [x0, #0x17]
    //     0x679860: add             x1, x1, HEAP, lsl #32
    //     0x679864: stur            x1, [fp, #-8]
    // 0x679868: CheckStackOverflow
    //     0x679868: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67986c: cmp             SP, x16
    //     0x679870: b.ls            #0x679aa4
    // 0x679874: CheckStackOverflow
    //     0x679874: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x679878: cmp             SP, x16
    //     0x67987c: b.ls            #0x679aac
    // 0x679880: LoadField: r0 = r1->field_13
    //     0x679880: ldur            w0, [x1, #0x13]
    // 0x679884: DecompressPointer r0
    //     0x679884: add             x0, x0, HEAP, lsl #32
    // 0x679888: cmp             w0, NULL
    // 0x67988c: b.eq            #0x679ab4
    // 0x679890: r2 = LoadInt32Instr(r0)
    //     0x679890: sbfx            x2, x0, #1, #0x1f
    //     0x679894: tbz             w0, #0, #0x67989c
    //     0x679898: ldur            x2, [x0, #7]
    // 0x67989c: cmp             x2, #0
    // 0x6798a0: b.le            #0x679928
    // 0x6798a4: LoadField: r0 = r1->field_f
    //     0x6798a4: ldur            w0, [x1, #0xf]
    // 0x6798a8: DecompressPointer r0
    //     0x6798a8: add             x0, x0, HEAP, lsl #32
    // 0x6798ac: LoadField: r2 = r0->field_5b
    //     0x6798ac: ldur            w2, [x0, #0x5b]
    // 0x6798b0: DecompressPointer r2
    //     0x6798b0: add             x2, x2, HEAP, lsl #32
    // 0x6798b4: cmp             w2, NULL
    // 0x6798b8: b.eq            #0x679ab8
    // 0x6798bc: stp             x2, x0, [SP, #-0x10]!
    // 0x6798c0: r0 = _destroyOrCacheChild()
    //     0x6798c0: bl              #0x679ad4  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::_destroyOrCacheChild
    // 0x6798c4: add             SP, SP, #0x10
    // 0x6798c8: ldur            x2, [fp, #-8]
    // 0x6798cc: LoadField: r0 = r2->field_13
    //     0x6798cc: ldur            w0, [x2, #0x13]
    // 0x6798d0: DecompressPointer r0
    //     0x6798d0: add             x0, x0, HEAP, lsl #32
    // 0x6798d4: cmp             w0, NULL
    // 0x6798d8: b.eq            #0x679abc
    // 0x6798dc: r1 = LoadInt32Instr(r0)
    //     0x6798dc: sbfx            x1, x0, #1, #0x1f
    //     0x6798e0: tbz             w0, #0, #0x6798e8
    //     0x6798e4: ldur            x1, [x0, #7]
    // 0x6798e8: sub             x3, x1, #1
    // 0x6798ec: r0 = BoxInt64Instr(r3)
    //     0x6798ec: sbfiz           x0, x3, #1, #0x1f
    //     0x6798f0: cmp             x3, x0, asr #1
    //     0x6798f4: b.eq            #0x679900
    //     0x6798f8: bl              #0xd69bb8
    //     0x6798fc: stur            x3, [x0, #7]
    // 0x679900: StoreField: r2->field_13 = r0
    //     0x679900: stur            w0, [x2, #0x13]
    //     0x679904: tbz             w0, #0, #0x679920
    //     0x679908: ldurb           w16, [x2, #-1]
    //     0x67990c: ldurb           w17, [x0, #-1]
    //     0x679910: and             x16, x17, x16, lsr #2
    //     0x679914: tst             x16, HEAP, lsr #32
    //     0x679918: b.eq            #0x679920
    //     0x67991c: bl              #0xd6828c
    // 0x679920: mov             x1, x2
    // 0x679924: b               #0x679874
    // 0x679928: mov             x2, x1
    // 0x67992c: CheckStackOverflow
    //     0x67992c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x679930: cmp             SP, x16
    //     0x679934: b.ls            #0x679ac0
    // 0x679938: LoadField: r0 = r2->field_17
    //     0x679938: ldur            w0, [x2, #0x17]
    // 0x67993c: DecompressPointer r0
    //     0x67993c: add             x0, x0, HEAP, lsl #32
    // 0x679940: cmp             w0, NULL
    // 0x679944: b.eq            #0x679ac8
    // 0x679948: r1 = LoadInt32Instr(r0)
    //     0x679948: sbfx            x1, x0, #1, #0x1f
    //     0x67994c: tbz             w0, #0, #0x679954
    //     0x679950: ldur            x1, [x0, #7]
    // 0x679954: cmp             x1, #0
    // 0x679958: b.le            #0x6799dc
    // 0x67995c: LoadField: r0 = r2->field_f
    //     0x67995c: ldur            w0, [x2, #0xf]
    // 0x679960: DecompressPointer r0
    //     0x679960: add             x0, x0, HEAP, lsl #32
    // 0x679964: LoadField: r1 = r0->field_5f
    //     0x679964: ldur            w1, [x0, #0x5f]
    // 0x679968: DecompressPointer r1
    //     0x679968: add             x1, x1, HEAP, lsl #32
    // 0x67996c: cmp             w1, NULL
    // 0x679970: b.eq            #0x679acc
    // 0x679974: stp             x1, x0, [SP, #-0x10]!
    // 0x679978: r0 = _destroyOrCacheChild()
    //     0x679978: bl              #0x679ad4  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::_destroyOrCacheChild
    // 0x67997c: add             SP, SP, #0x10
    // 0x679980: ldur            x2, [fp, #-8]
    // 0x679984: LoadField: r0 = r2->field_17
    //     0x679984: ldur            w0, [x2, #0x17]
    // 0x679988: DecompressPointer r0
    //     0x679988: add             x0, x0, HEAP, lsl #32
    // 0x67998c: cmp             w0, NULL
    // 0x679990: b.eq            #0x679ad0
    // 0x679994: r1 = LoadInt32Instr(r0)
    //     0x679994: sbfx            x1, x0, #1, #0x1f
    //     0x679998: tbz             w0, #0, #0x6799a0
    //     0x67999c: ldur            x1, [x0, #7]
    // 0x6799a0: sub             x3, x1, #1
    // 0x6799a4: r0 = BoxInt64Instr(r3)
    //     0x6799a4: sbfiz           x0, x3, #1, #0x1f
    //     0x6799a8: cmp             x3, x0, asr #1
    //     0x6799ac: b.eq            #0x6799b8
    //     0x6799b0: bl              #0xd69bb8
    //     0x6799b4: stur            x3, [x0, #7]
    // 0x6799b8: StoreField: r2->field_17 = r0
    //     0x6799b8: stur            w0, [x2, #0x17]
    //     0x6799bc: tbz             w0, #0, #0x6799d8
    //     0x6799c0: ldurb           w16, [x2, #-1]
    //     0x6799c4: ldurb           w17, [x0, #-1]
    //     0x6799c8: and             x16, x17, x16, lsr #2
    //     0x6799cc: tst             x16, HEAP, lsr #32
    //     0x6799d0: b.eq            #0x6799d8
    //     0x6799d4: bl              #0xd6828c
    // 0x6799d8: b               #0x67992c
    // 0x6799dc: LoadField: r0 = r2->field_f
    //     0x6799dc: ldur            w0, [x2, #0xf]
    // 0x6799e0: DecompressPointer r0
    //     0x6799e0: add             x0, x0, HEAP, lsl #32
    // 0x6799e4: LoadField: r1 = r0->field_67
    //     0x6799e4: ldur            w1, [x0, #0x67]
    // 0x6799e8: DecompressPointer r1
    //     0x6799e8: add             x1, x1, HEAP, lsl #32
    // 0x6799ec: SaveReg r1
    //     0x6799ec: str             x1, [SP, #-8]!
    // 0x6799f0: r0 = values()
    //     0x6799f0: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0x6799f4: add             SP, SP, #8
    // 0x6799f8: r1 = Function '<anonymous closure>':.
    //     0x6799f8: add             x1, PP, #0x43, lsl #12  ; [pp+0x435a8] AnonymousClosure: (0x679f20), in [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::collectGarbage (0x6797bc)
    //     0x6799fc: ldr             x1, [x1, #0x5a8]
    // 0x679a00: r2 = Null
    //     0x679a00: mov             x2, NULL
    // 0x679a04: stur            x0, [fp, #-0x10]
    // 0x679a08: r0 = AllocateClosure()
    //     0x679a08: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x679a0c: ldur            x16, [fp, #-0x10]
    // 0x679a10: stp             x0, x16, [SP, #-0x10]!
    // 0x679a14: r0 = where()
    //     0x679a14: bl              #0x6fa13c  ; [dart:collection] __Set&_HashVMBase&SetMixin::where
    // 0x679a18: add             SP, SP, #0x10
    // 0x679a1c: SaveReg r0
    //     0x679a1c: str             x0, [SP, #-8]!
    // 0x679a20: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x679a20: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x679a24: r0 = toList()
    //     0x679a24: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0x679a28: add             SP, SP, #8
    // 0x679a2c: mov             x1, x0
    // 0x679a30: ldur            x0, [fp, #-8]
    // 0x679a34: stur            x1, [fp, #-0x10]
    // 0x679a38: LoadField: r2 = r0->field_f
    //     0x679a38: ldur            w2, [x0, #0xf]
    // 0x679a3c: DecompressPointer r2
    //     0x679a3c: add             x2, x2, HEAP, lsl #32
    // 0x679a40: LoadField: r0 = r2->field_63
    //     0x679a40: ldur            w0, [x2, #0x63]
    // 0x679a44: DecompressPointer r0
    //     0x679a44: add             x0, x0, HEAP, lsl #32
    // 0x679a48: r2 = LoadClassIdInstr(r0)
    //     0x679a48: ldur            x2, [x0, #-1]
    //     0x679a4c: ubfx            x2, x2, #0xc, #0x14
    // 0x679a50: SaveReg r0
    //     0x679a50: str             x0, [SP, #-8]!
    // 0x679a54: mov             x0, x2
    // 0x679a58: r0 = GDT[cid_x0 + -0xf5e]()
    //     0x679a58: sub             lr, x0, #0xf5e
    //     0x679a5c: ldr             lr, [x21, lr, lsl #3]
    //     0x679a60: blr             lr
    // 0x679a64: add             SP, SP, #8
    // 0x679a68: mov             x1, x0
    // 0x679a6c: ldur            x0, [fp, #-0x10]
    // 0x679a70: r2 = LoadClassIdInstr(r0)
    //     0x679a70: ldur            x2, [x0, #-1]
    //     0x679a74: ubfx            x2, x2, #0xc, #0x14
    // 0x679a78: stp             x1, x0, [SP, #-0x10]!
    // 0x679a7c: mov             x0, x2
    // 0x679a80: r0 = GDT[cid_x0 + 0xce6e]()
    //     0x679a80: mov             x17, #0xce6e
    //     0x679a84: add             lr, x0, x17
    //     0x679a88: ldr             lr, [x21, lr, lsl #3]
    //     0x679a8c: blr             lr
    // 0x679a90: add             SP, SP, #0x10
    // 0x679a94: r0 = Null
    //     0x679a94: mov             x0, NULL
    // 0x679a98: LeaveFrame
    //     0x679a98: mov             SP, fp
    //     0x679a9c: ldp             fp, lr, [SP], #0x10
    // 0x679aa0: ret
    //     0x679aa0: ret             
    // 0x679aa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x679aa4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x679aa8: b               #0x679874
    // 0x679aac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x679aac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x679ab0: b               #0x679880
    // 0x679ab4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x679ab4: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x679ab8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x679ab8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x679abc: r0 = NullErrorSharedWithoutFPURegs()
    //     0x679abc: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x679ac0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x679ac0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x679ac4: b               #0x679938
    // 0x679ac8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x679ac8: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x679acc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x679acc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x679ad0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x679ad0: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _destroyOrCacheChild(/* No info */) {
    // ** addr: 0x679ad4, size: 0x13c
    // 0x679ad4: EnterFrame
    //     0x679ad4: stp             fp, lr, [SP, #-0x10]!
    //     0x679ad8: mov             fp, SP
    // 0x679adc: AllocStack(0x8)
    //     0x679adc: sub             SP, SP, #8
    // 0x679ae0: CheckStackOverflow
    //     0x679ae0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x679ae4: cmp             SP, x16
    //     0x679ae8: b.ls            #0x679c00
    // 0x679aec: ldr             x3, [fp, #0x10]
    // 0x679af0: LoadField: r4 = r3->field_17
    //     0x679af0: ldur            w4, [x3, #0x17]
    // 0x679af4: DecompressPointer r4
    //     0x679af4: add             x4, x4, HEAP, lsl #32
    // 0x679af8: stur            x4, [fp, #-8]
    // 0x679afc: cmp             w4, NULL
    // 0x679b00: b.eq            #0x679c08
    // 0x679b04: mov             x0, x4
    // 0x679b08: r2 = Null
    //     0x679b08: mov             x2, NULL
    // 0x679b0c: r1 = Null
    //     0x679b0c: mov             x1, NULL
    // 0x679b10: r4 = LoadClassIdInstr(r0)
    //     0x679b10: ldur            x4, [x0, #-1]
    //     0x679b14: ubfx            x4, x4, #0xc, #0x14
    // 0x679b18: sub             x4, x4, #0x7f9
    // 0x679b1c: cmp             x4, #2
    // 0x679b20: b.ls            #0x679b38
    // 0x679b24: r8 = SliverMultiBoxAdaptorParentData
    //     0x679b24: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x679b28: ldr             x8, [x8, #0x120]
    // 0x679b2c: r3 = Null
    //     0x679b2c: add             x3, PP, #0x43, lsl #12  ; [pp+0x435c0] Null
    //     0x679b30: ldr             x3, [x3, #0x5c0]
    // 0x679b34: r0 = DefaultTypeTest()
    //     0x679b34: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x679b38: ldur            x0, [fp, #-8]
    // 0x679b3c: LoadField: r1 = r0->field_13
    //     0x679b3c: ldur            w1, [x0, #0x13]
    // 0x679b40: DecompressPointer r1
    //     0x679b40: add             x1, x1, HEAP, lsl #32
    // 0x679b44: tbnz            w1, #4, #0x679bd4
    // 0x679b48: ldr             x2, [fp, #0x18]
    // 0x679b4c: ldr             x1, [fp, #0x10]
    // 0x679b50: stp             x1, x2, [SP, #-0x10]!
    // 0x679b54: r0 = remove()
    //     0x679b54: bl              #0x5e59c8  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::remove
    // 0x679b58: add             SP, SP, #0x10
    // 0x679b5c: ldr             x0, [fp, #0x18]
    // 0x679b60: LoadField: r1 = r0->field_67
    //     0x679b60: ldur            w1, [x0, #0x67]
    // 0x679b64: DecompressPointer r1
    //     0x679b64: add             x1, x1, HEAP, lsl #32
    // 0x679b68: ldur            x2, [fp, #-8]
    // 0x679b6c: LoadField: r3 = r2->field_17
    //     0x679b6c: ldur            w3, [x2, #0x17]
    // 0x679b70: DecompressPointer r3
    //     0x679b70: add             x3, x3, HEAP, lsl #32
    // 0x679b74: cmp             w3, NULL
    // 0x679b78: b.eq            #0x679c0c
    // 0x679b7c: stp             x3, x1, [SP, #-0x10]!
    // 0x679b80: ldr             x16, [fp, #0x10]
    // 0x679b84: SaveReg r16
    //     0x679b84: str             x16, [SP, #-8]!
    // 0x679b88: r0 = []=()
    //     0x679b88: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x679b8c: add             SP, SP, #0x18
    // 0x679b90: ldur            x0, [fp, #-8]
    // 0x679b94: ldr             x1, [fp, #0x10]
    // 0x679b98: StoreField: r1->field_17 = r0
    //     0x679b98: stur            w0, [x1, #0x17]
    //     0x679b9c: ldurb           w16, [x1, #-1]
    //     0x679ba0: ldurb           w17, [x0, #-1]
    //     0x679ba4: and             x16, x17, x16, lsr #2
    //     0x679ba8: tst             x16, HEAP, lsr #32
    //     0x679bac: b.eq            #0x679bb4
    //     0x679bb0: bl              #0xd6826c
    // 0x679bb4: ldr             x16, [fp, #0x18]
    // 0x679bb8: stp             x1, x16, [SP, #-0x10]!
    // 0x679bbc: r0 = adoptChild()
    //     0x679bbc: bl              #0x5e61d4  ; [package:flutter/src/rendering/object.dart] RenderObject::adoptChild
    // 0x679bc0: add             SP, SP, #0x10
    // 0x679bc4: ldur            x0, [fp, #-8]
    // 0x679bc8: r1 = true
    //     0x679bc8: add             x1, NULL, #0x20  ; true
    // 0x679bcc: StoreField: r0->field_1b = r1
    //     0x679bcc: stur            w1, [x0, #0x1b]
    // 0x679bd0: b               #0x679bf0
    // 0x679bd4: ldr             x0, [fp, #0x18]
    // 0x679bd8: ldr             x1, [fp, #0x10]
    // 0x679bdc: LoadField: r2 = r0->field_63
    //     0x679bdc: ldur            w2, [x0, #0x63]
    // 0x679be0: DecompressPointer r2
    //     0x679be0: add             x2, x2, HEAP, lsl #32
    // 0x679be4: stp             x1, x2, [SP, #-0x10]!
    // 0x679be8: r0 = removeChild()
    //     0x679be8: bl              #0x679c10  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::removeChild
    // 0x679bec: add             SP, SP, #0x10
    // 0x679bf0: r0 = Null
    //     0x679bf0: mov             x0, NULL
    // 0x679bf4: LeaveFrame
    //     0x679bf4: mov             SP, fp
    //     0x679bf8: ldp             fp, lr, [SP], #0x10
    // 0x679bfc: ret
    //     0x679bfc: ret             
    // 0x679c00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x679c00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x679c04: b               #0x679aec
    // 0x679c08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x679c08: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x679c0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x679c0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, RenderBox) {
    // ** addr: 0x679f20, size: 0x78
    // 0x679f20: EnterFrame
    //     0x679f20: stp             fp, lr, [SP, #-0x10]!
    //     0x679f24: mov             fp, SP
    // 0x679f28: AllocStack(0x8)
    //     0x679f28: sub             SP, SP, #8
    // 0x679f2c: ldr             x0, [fp, #0x10]
    // 0x679f30: LoadField: r3 = r0->field_17
    //     0x679f30: ldur            w3, [x0, #0x17]
    // 0x679f34: DecompressPointer r3
    //     0x679f34: add             x3, x3, HEAP, lsl #32
    // 0x679f38: stur            x3, [fp, #-8]
    // 0x679f3c: cmp             w3, NULL
    // 0x679f40: b.eq            #0x679f94
    // 0x679f44: mov             x0, x3
    // 0x679f48: r2 = Null
    //     0x679f48: mov             x2, NULL
    // 0x679f4c: r1 = Null
    //     0x679f4c: mov             x1, NULL
    // 0x679f50: r4 = LoadClassIdInstr(r0)
    //     0x679f50: ldur            x4, [x0, #-1]
    //     0x679f54: ubfx            x4, x4, #0xc, #0x14
    // 0x679f58: sub             x4, x4, #0x7f9
    // 0x679f5c: cmp             x4, #2
    // 0x679f60: b.ls            #0x679f78
    // 0x679f64: r8 = SliverMultiBoxAdaptorParentData
    //     0x679f64: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0x679f68: ldr             x8, [x8, #0x120]
    // 0x679f6c: r3 = Null
    //     0x679f6c: add             x3, PP, #0x43, lsl #12  ; [pp+0x435b0] Null
    //     0x679f70: ldr             x3, [x3, #0x5b0]
    // 0x679f74: r0 = DefaultTypeTest()
    //     0x679f74: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x679f78: ldur            x1, [fp, #-8]
    // 0x679f7c: LoadField: r2 = r1->field_13
    //     0x679f7c: ldur            w2, [x1, #0x13]
    // 0x679f80: DecompressPointer r2
    //     0x679f80: add             x2, x2, HEAP, lsl #32
    // 0x679f84: eor             x0, x2, #0x10
    // 0x679f88: LeaveFrame
    //     0x679f88: mov             SP, fp
    //     0x679f8c: ldp             fp, lr, [SP], #0x10
    // 0x679f90: ret
    //     0x679f90: ret             
    // 0x679f94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x679f94: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0x6bb8a0, size: 0xb0
    // 0x6bb8a0: EnterFrame
    //     0x6bb8a0: stp             fp, lr, [SP, #-0x10]!
    //     0x6bb8a4: mov             fp, SP
    // 0x6bb8a8: CheckStackOverflow
    //     0x6bb8a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bb8ac: cmp             SP, x16
    //     0x6bb8b0: b.ls            #0x6bb948
    // 0x6bb8b4: ldr             x0, [fp, #0x18]
    // 0x6bb8b8: r2 = Null
    //     0x6bb8b8: mov             x2, NULL
    // 0x6bb8bc: r1 = Null
    //     0x6bb8bc: mov             x1, NULL
    // 0x6bb8c0: r4 = 59
    //     0x6bb8c0: mov             x4, #0x3b
    // 0x6bb8c4: branchIfSmi(r0, 0x6bb8d0)
    //     0x6bb8c4: tbz             w0, #0, #0x6bb8d0
    // 0x6bb8c8: r4 = LoadClassIdInstr(r0)
    //     0x6bb8c8: ldur            x4, [x0, #-1]
    //     0x6bb8cc: ubfx            x4, x4, #0xc, #0x14
    // 0x6bb8d0: sub             x4, x4, #0x965
    // 0x6bb8d4: cmp             x4, #0x8b
    // 0x6bb8d8: b.ls            #0x6bb8f0
    // 0x6bb8dc: r8 = RenderBox
    //     0x6bb8dc: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x6bb8e0: ldr             x8, [x8, #0xfa0]
    // 0x6bb8e4: r3 = Null
    //     0x6bb8e4: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4adb0] Null
    //     0x6bb8e8: ldr             x3, [x3, #0xdb0]
    // 0x6bb8ec: r0 = RenderBox()
    //     0x6bb8ec: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x6bb8f0: ldr             x16, [fp, #0x20]
    // 0x6bb8f4: ldr             lr, [fp, #0x18]
    // 0x6bb8f8: stp             lr, x16, [SP, #-0x10]!
    // 0x6bb8fc: r0 = paintsChild()
    //     0x6bb8fc: bl              #0x641548  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::paintsChild
    // 0x6bb900: add             SP, SP, #0x10
    // 0x6bb904: tbz             w0, #4, #0x6bb91c
    // 0x6bb908: ldr             x16, [fp, #0x10]
    // 0x6bb90c: SaveReg r16
    //     0x6bb90c: str             x16, [SP, #-8]!
    // 0x6bb910: r0 = setZero()
    //     0x6bb910: bl              #0x6bbc24  ; [package:vector_math/vector_math_64.dart] Matrix4::setZero
    // 0x6bb914: add             SP, SP, #8
    // 0x6bb918: b               #0x6bb938
    // 0x6bb91c: ldr             x16, [fp, #0x20]
    // 0x6bb920: ldr             lr, [fp, #0x18]
    // 0x6bb924: stp             lr, x16, [SP, #-0x10]!
    // 0x6bb928: ldr             x16, [fp, #0x10]
    // 0x6bb92c: SaveReg r16
    //     0x6bb92c: str             x16, [SP, #-8]!
    // 0x6bb930: r0 = applyPaintTransformForBoxChild()
    //     0x6bb930: bl              #0x6bb950  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] _RenderSliverMultiBoxAdaptor&RenderSliver&ContainerRenderObjectMixin&RenderSliverHelpers::applyPaintTransformForBoxChild
    // 0x6bb934: add             SP, SP, #0x18
    // 0x6bb938: r0 = Null
    //     0x6bb938: mov             x0, NULL
    // 0x6bb93c: LeaveFrame
    //     0x6bb93c: mov             SP, fp
    //     0x6bb940: ldp             fp, lr, [SP], #0x10
    // 0x6bb944: ret
    //     0x6bb944: ret             
    // 0x6bb948: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bb948: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bb94c: b               #0x6bb8b4
  }
  _ visitChildren(/* No info */) {
    // ** addr: 0x6bf518, size: 0x68
    // 0x6bf518: EnterFrame
    //     0x6bf518: stp             fp, lr, [SP, #-0x10]!
    //     0x6bf51c: mov             fp, SP
    // 0x6bf520: CheckStackOverflow
    //     0x6bf520: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bf524: cmp             SP, x16
    //     0x6bf528: b.ls            #0x6bf578
    // 0x6bf52c: ldr             x16, [fp, #0x18]
    // 0x6bf530: ldr             lr, [fp, #0x10]
    // 0x6bf534: stp             lr, x16, [SP, #-0x10]!
    // 0x6bf538: r0 = visitChildren()
    //     0x6bf538: bl              #0x675b74  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] _RenderSliverMultiBoxAdaptor&RenderSliver&ContainerRenderObjectMixin::visitChildren
    // 0x6bf53c: add             SP, SP, #0x10
    // 0x6bf540: ldr             x0, [fp, #0x18]
    // 0x6bf544: LoadField: r1 = r0->field_67
    //     0x6bf544: ldur            w1, [x0, #0x67]
    // 0x6bf548: DecompressPointer r1
    //     0x6bf548: add             x1, x1, HEAP, lsl #32
    // 0x6bf54c: SaveReg r1
    //     0x6bf54c: str             x1, [SP, #-8]!
    // 0x6bf550: r0 = values()
    //     0x6bf550: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0x6bf554: add             SP, SP, #8
    // 0x6bf558: ldr             x16, [fp, #0x10]
    // 0x6bf55c: stp             x16, x0, [SP, #-0x10]!
    // 0x6bf560: r0 = forEach()
    //     0x6bf560: bl              #0x6ab958  ; [dart:core] Iterable::forEach
    // 0x6bf564: add             SP, SP, #0x10
    // 0x6bf568: r0 = Null
    //     0x6bf568: mov             x0, NULL
    // 0x6bf56c: LeaveFrame
    //     0x6bf56c: mov             SP, fp
    //     0x6bf570: ldp             fp, lr, [SP], #0x10
    // 0x6bf574: ret
    //     0x6bf574: ret             
    // 0x6bf578: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bf578: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bf57c: b               #0x6bf52c
  }
  _ RenderSliverMultiBoxAdaptor(/* No info */) {
    // ** addr: 0x6e9998, size: 0x9c
    // 0x6e9998: EnterFrame
    //     0x6e9998: stp             fp, lr, [SP, #-0x10]!
    //     0x6e999c: mov             fp, SP
    // 0x6e99a0: CheckStackOverflow
    //     0x6e99a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e99a4: cmp             SP, x16
    //     0x6e99a8: b.ls            #0x6e9a2c
    // 0x6e99ac: r16 = <int, RenderBox>
    //     0x6e99ac: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bcb8] TypeArguments: <int, RenderBox>
    //     0x6e99b0: ldr             x16, [x16, #0xcb8]
    // 0x6e99b4: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x6e99b8: stp             lr, x16, [SP, #-0x10]!
    // 0x6e99bc: r0 = Map._fromLiteral()
    //     0x6e99bc: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x6e99c0: add             SP, SP, #0x10
    // 0x6e99c4: ldr             x1, [fp, #0x18]
    // 0x6e99c8: StoreField: r1->field_67 = r0
    //     0x6e99c8: stur            w0, [x1, #0x67]
    //     0x6e99cc: tbz             w0, #0, #0x6e99e8
    //     0x6e99d0: ldurb           w16, [x1, #-1]
    //     0x6e99d4: ldurb           w17, [x0, #-1]
    //     0x6e99d8: and             x16, x17, x16, lsr #2
    //     0x6e99dc: tst             x16, HEAP, lsr #32
    //     0x6e99e0: b.eq            #0x6e99e8
    //     0x6e99e4: bl              #0xd6826c
    // 0x6e99e8: ldr             x0, [fp, #0x10]
    // 0x6e99ec: StoreField: r1->field_63 = r0
    //     0x6e99ec: stur            w0, [x1, #0x63]
    //     0x6e99f0: ldurb           w16, [x1, #-1]
    //     0x6e99f4: ldurb           w17, [x0, #-1]
    //     0x6e99f8: and             x16, x17, x16, lsr #2
    //     0x6e99fc: tst             x16, HEAP, lsr #32
    //     0x6e9a00: b.eq            #0x6e9a08
    //     0x6e9a04: bl              #0xd6826c
    // 0x6e9a08: r0 = 0
    //     0x6e9a08: mov             x0, #0
    // 0x6e9a0c: StoreField: r1->field_53 = r0
    //     0x6e9a0c: stur            x0, [x1, #0x53]
    // 0x6e9a10: SaveReg r1
    //     0x6e9a10: str             x1, [SP, #-8]!
    // 0x6e9a14: r0 = RenderObject()
    //     0x6e9a14: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6e9a18: add             SP, SP, #8
    // 0x6e9a1c: r0 = Null
    //     0x6e9a1c: mov             x0, NULL
    // 0x6e9a20: LeaveFrame
    //     0x6e9a20: mov             SP, fp
    //     0x6e9a24: ldp             fp, lr, [SP], #0x10
    // 0x6e9a28: ret
    //     0x6e9a28: ret             
    // 0x6e9a2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e9a2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e9a30: b               #0x6e99ac
  }
  _ redepthChildren(/* No info */) {
    // ** addr: 0x792668, size: 0x90
    // 0x792668: EnterFrame
    //     0x792668: stp             fp, lr, [SP, #-0x10]!
    //     0x79266c: mov             fp, SP
    // 0x792670: AllocStack(0x8)
    //     0x792670: sub             SP, SP, #8
    // 0x792674: CheckStackOverflow
    //     0x792674: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x792678: cmp             SP, x16
    //     0x79267c: b.ls            #0x7926f0
    // 0x792680: ldr             x16, [fp, #0x10]
    // 0x792684: SaveReg r16
    //     0x792684: str             x16, [SP, #-8]!
    // 0x792688: r0 = redepthChildren()
    //     0x792688: bl              #0x7926f8  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] _RenderSliverMultiBoxAdaptor&RenderSliver&ContainerRenderObjectMixin::redepthChildren
    // 0x79268c: add             SP, SP, #8
    // 0x792690: ldr             x0, [fp, #0x10]
    // 0x792694: LoadField: r1 = r0->field_67
    //     0x792694: ldur            w1, [x0, #0x67]
    // 0x792698: DecompressPointer r1
    //     0x792698: add             x1, x1, HEAP, lsl #32
    // 0x79269c: SaveReg r1
    //     0x79269c: str             x1, [SP, #-8]!
    // 0x7926a0: r0 = values()
    //     0x7926a0: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0x7926a4: add             SP, SP, #8
    // 0x7926a8: stur            x0, [fp, #-8]
    // 0x7926ac: r1 = 1
    //     0x7926ac: mov             x1, #1
    // 0x7926b0: r0 = AllocateContext()
    //     0x7926b0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7926b4: mov             x1, x0
    // 0x7926b8: ldr             x0, [fp, #0x10]
    // 0x7926bc: StoreField: r1->field_f = r0
    //     0x7926bc: stur            w0, [x1, #0xf]
    // 0x7926c0: mov             x2, x1
    // 0x7926c4: r1 = Function 'redepthChild':.
    //     0x7926c4: add             x1, PP, #0xa, lsl #12  ; [pp+0xaf78] AnonymousClosure: (0x5e638c), in [package:flutter/src/foundation/node.dart] AbstractNode::redepthChild (0x5e631c)
    //     0x7926c8: ldr             x1, [x1, #0xf78]
    // 0x7926cc: r0 = AllocateClosure()
    //     0x7926cc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7926d0: ldur            x16, [fp, #-8]
    // 0x7926d4: stp             x0, x16, [SP, #-0x10]!
    // 0x7926d8: r0 = forEach()
    //     0x7926d8: bl              #0x6ab958  ; [dart:core] Iterable::forEach
    // 0x7926dc: add             SP, SP, #0x10
    // 0x7926e0: r0 = Null
    //     0x7926e0: mov             x0, NULL
    // 0x7926e4: LeaveFrame
    //     0x7926e4: mov             SP, fp
    //     0x7926e8: ldp             fp, lr, [SP], #0x10
    // 0x7926ec: ret
    //     0x7926ec: ret             
    // 0x7926f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7926f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7926f4: b               #0x792680
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bbfd8, size: 0x150
    // 0x9bbfd8: EnterFrame
    //     0x9bbfd8: stp             fp, lr, [SP, #-0x10]!
    //     0x9bbfdc: mov             fp, SP
    // 0x9bbfe0: AllocStack(0x18)
    //     0x9bbfe0: sub             SP, SP, #0x18
    // 0x9bbfe4: CheckStackOverflow
    //     0x9bbfe4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bbfe8: cmp             SP, x16
    //     0x9bbfec: b.ls            #0x9bc118
    // 0x9bbff0: ldr             x0, [fp, #0x10]
    // 0x9bbff4: r2 = Null
    //     0x9bbff4: mov             x2, NULL
    // 0x9bbff8: r1 = Null
    //     0x9bbff8: mov             x1, NULL
    // 0x9bbffc: r4 = 59
    //     0x9bbffc: mov             x4, #0x3b
    // 0x9bc000: branchIfSmi(r0, 0x9bc00c)
    //     0x9bc000: tbz             w0, #0, #0x9bc00c
    // 0x9bc004: r4 = LoadClassIdInstr(r0)
    //     0x9bc004: ldur            x4, [x0, #-1]
    //     0x9bc008: ubfx            x4, x4, #0xc, #0x14
    // 0x9bc00c: cmp             x4, #0x7e6
    // 0x9bc010: b.eq            #0x9bc024
    // 0x9bc014: r8 = PipelineOwner
    //     0x9bc014: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9bc018: r3 = Null
    //     0x9bc018: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ae38] Null
    //     0x9bc01c: ldr             x3, [x3, #0xe38]
    // 0x9bc020: r0 = DefaultTypeTest()
    //     0x9bc020: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bc024: ldr             x16, [fp, #0x18]
    // 0x9bc028: ldr             lr, [fp, #0x10]
    // 0x9bc02c: stp             lr, x16, [SP, #-0x10]!
    // 0x9bc030: r0 = attach()
    //     0x9bc030: bl              #0x9bc128  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] _RenderSliverMultiBoxAdaptor&RenderSliver&ContainerRenderObjectMixin::attach
    // 0x9bc034: add             SP, SP, #0x10
    // 0x9bc038: ldr             x0, [fp, #0x18]
    // 0x9bc03c: LoadField: r1 = r0->field_67
    //     0x9bc03c: ldur            w1, [x0, #0x67]
    // 0x9bc040: DecompressPointer r1
    //     0x9bc040: add             x1, x1, HEAP, lsl #32
    // 0x9bc044: SaveReg r1
    //     0x9bc044: str             x1, [SP, #-8]!
    // 0x9bc048: r0 = values()
    //     0x9bc048: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0x9bc04c: add             SP, SP, #8
    // 0x9bc050: SaveReg r0
    //     0x9bc050: str             x0, [SP, #-8]!
    // 0x9bc054: r0 = iterator()
    //     0x9bc054: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0x9bc058: add             SP, SP, #8
    // 0x9bc05c: stur            x0, [fp, #-0x10]
    // 0x9bc060: LoadField: r2 = r0->field_7
    //     0x9bc060: ldur            w2, [x0, #7]
    // 0x9bc064: DecompressPointer r2
    //     0x9bc064: add             x2, x2, HEAP, lsl #32
    // 0x9bc068: stur            x2, [fp, #-8]
    // 0x9bc06c: CheckStackOverflow
    //     0x9bc06c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bc070: cmp             SP, x16
    //     0x9bc074: b.ls            #0x9bc120
    // 0x9bc078: SaveReg r0
    //     0x9bc078: str             x0, [SP, #-8]!
    // 0x9bc07c: r0 = moveNext()
    //     0x9bc07c: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x9bc080: add             SP, SP, #8
    // 0x9bc084: tbnz            w0, #4, #0x9bc108
    // 0x9bc088: ldur            x3, [fp, #-0x10]
    // 0x9bc08c: LoadField: r4 = r3->field_33
    //     0x9bc08c: ldur            w4, [x3, #0x33]
    // 0x9bc090: DecompressPointer r4
    //     0x9bc090: add             x4, x4, HEAP, lsl #32
    // 0x9bc094: stur            x4, [fp, #-0x18]
    // 0x9bc098: cmp             w4, NULL
    // 0x9bc09c: b.ne            #0x9bc0d0
    // 0x9bc0a0: mov             x0, x4
    // 0x9bc0a4: ldur            x2, [fp, #-8]
    // 0x9bc0a8: r1 = Null
    //     0x9bc0a8: mov             x1, NULL
    // 0x9bc0ac: cmp             w2, NULL
    // 0x9bc0b0: b.eq            #0x9bc0d0
    // 0x9bc0b4: LoadField: r4 = r2->field_17
    //     0x9bc0b4: ldur            w4, [x2, #0x17]
    // 0x9bc0b8: DecompressPointer r4
    //     0x9bc0b8: add             x4, x4, HEAP, lsl #32
    // 0x9bc0bc: r8 = X0
    //     0x9bc0bc: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x9bc0c0: LoadField: r9 = r4->field_7
    //     0x9bc0c0: ldur            x9, [x4, #7]
    // 0x9bc0c4: r3 = Null
    //     0x9bc0c4: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ae48] Null
    //     0x9bc0c8: ldr             x3, [x3, #0xe48]
    // 0x9bc0cc: blr             x9
    // 0x9bc0d0: ldur            x0, [fp, #-0x18]
    // 0x9bc0d4: r1 = LoadClassIdInstr(r0)
    //     0x9bc0d4: ldur            x1, [x0, #-1]
    //     0x9bc0d8: ubfx            x1, x1, #0xc, #0x14
    // 0x9bc0dc: ldr             x16, [fp, #0x10]
    // 0x9bc0e0: stp             x16, x0, [SP, #-0x10]!
    // 0x9bc0e4: mov             x0, x1
    // 0x9bc0e8: r0 = GDT[cid_x0 + 0xaf1f]()
    //     0x9bc0e8: mov             x17, #0xaf1f
    //     0x9bc0ec: add             lr, x0, x17
    //     0x9bc0f0: ldr             lr, [x21, lr, lsl #3]
    //     0x9bc0f4: blr             lr
    // 0x9bc0f8: add             SP, SP, #0x10
    // 0x9bc0fc: ldur            x0, [fp, #-0x10]
    // 0x9bc100: ldur            x2, [fp, #-8]
    // 0x9bc104: b               #0x9bc06c
    // 0x9bc108: r0 = Null
    //     0x9bc108: mov             x0, NULL
    // 0x9bc10c: LeaveFrame
    //     0x9bc10c: mov             SP, fp
    //     0x9bc110: ldp             fp, lr, [SP], #0x10
    // 0x9bc114: ret
    //     0x9bc114: ret             
    // 0x9bc118: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bc118: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bc11c: b               #0x9bbff0
    // 0x9bc120: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bc120: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bc124: b               #0x9bc078
  }
  _ detach(/* No info */) {
    // ** addr: 0xa656ec, size: 0x114
    // 0xa656ec: EnterFrame
    //     0xa656ec: stp             fp, lr, [SP, #-0x10]!
    //     0xa656f0: mov             fp, SP
    // 0xa656f4: AllocStack(0x18)
    //     0xa656f4: sub             SP, SP, #0x18
    // 0xa656f8: CheckStackOverflow
    //     0xa656f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa656fc: cmp             SP, x16
    //     0xa65700: b.ls            #0xa657f0
    // 0xa65704: ldr             x16, [fp, #0x10]
    // 0xa65708: SaveReg r16
    //     0xa65708: str             x16, [SP, #-8]!
    // 0xa6570c: r0 = detach()
    //     0xa6570c: bl              #0xa65800  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] _RenderSliverMultiBoxAdaptor&RenderSliver&ContainerRenderObjectMixin::detach
    // 0xa65710: add             SP, SP, #8
    // 0xa65714: ldr             x0, [fp, #0x10]
    // 0xa65718: LoadField: r1 = r0->field_67
    //     0xa65718: ldur            w1, [x0, #0x67]
    // 0xa6571c: DecompressPointer r1
    //     0xa6571c: add             x1, x1, HEAP, lsl #32
    // 0xa65720: SaveReg r1
    //     0xa65720: str             x1, [SP, #-8]!
    // 0xa65724: r0 = values()
    //     0xa65724: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0xa65728: add             SP, SP, #8
    // 0xa6572c: SaveReg r0
    //     0xa6572c: str             x0, [SP, #-8]!
    // 0xa65730: r0 = iterator()
    //     0xa65730: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0xa65734: add             SP, SP, #8
    // 0xa65738: stur            x0, [fp, #-0x10]
    // 0xa6573c: LoadField: r2 = r0->field_7
    //     0xa6573c: ldur            w2, [x0, #7]
    // 0xa65740: DecompressPointer r2
    //     0xa65740: add             x2, x2, HEAP, lsl #32
    // 0xa65744: stur            x2, [fp, #-8]
    // 0xa65748: CheckStackOverflow
    //     0xa65748: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6574c: cmp             SP, x16
    //     0xa65750: b.ls            #0xa657f8
    // 0xa65754: SaveReg r0
    //     0xa65754: str             x0, [SP, #-8]!
    // 0xa65758: r0 = moveNext()
    //     0xa65758: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0xa6575c: add             SP, SP, #8
    // 0xa65760: tbnz            w0, #4, #0xa657e0
    // 0xa65764: ldur            x3, [fp, #-0x10]
    // 0xa65768: LoadField: r4 = r3->field_33
    //     0xa65768: ldur            w4, [x3, #0x33]
    // 0xa6576c: DecompressPointer r4
    //     0xa6576c: add             x4, x4, HEAP, lsl #32
    // 0xa65770: stur            x4, [fp, #-0x18]
    // 0xa65774: cmp             w4, NULL
    // 0xa65778: b.ne            #0xa657ac
    // 0xa6577c: mov             x0, x4
    // 0xa65780: ldur            x2, [fp, #-8]
    // 0xa65784: r1 = Null
    //     0xa65784: mov             x1, NULL
    // 0xa65788: cmp             w2, NULL
    // 0xa6578c: b.eq            #0xa657ac
    // 0xa65790: LoadField: r4 = r2->field_17
    //     0xa65790: ldur            w4, [x2, #0x17]
    // 0xa65794: DecompressPointer r4
    //     0xa65794: add             x4, x4, HEAP, lsl #32
    // 0xa65798: r8 = X0
    //     0xa65798: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa6579c: LoadField: r9 = r4->field_7
    //     0xa6579c: ldur            x9, [x4, #7]
    // 0xa657a0: r3 = Null
    //     0xa657a0: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ae28] Null
    //     0xa657a4: ldr             x3, [x3, #0xe28]
    // 0xa657a8: blr             x9
    // 0xa657ac: ldur            x0, [fp, #-0x18]
    // 0xa657b0: r1 = LoadClassIdInstr(r0)
    //     0xa657b0: ldur            x1, [x0, #-1]
    //     0xa657b4: ubfx            x1, x1, #0xc, #0x14
    // 0xa657b8: SaveReg r0
    //     0xa657b8: str             x0, [SP, #-8]!
    // 0xa657bc: mov             x0, x1
    // 0xa657c0: r0 = GDT[cid_x0 + 0xa3cc]()
    //     0xa657c0: mov             x17, #0xa3cc
    //     0xa657c4: add             lr, x0, x17
    //     0xa657c8: ldr             lr, [x21, lr, lsl #3]
    //     0xa657cc: blr             lr
    // 0xa657d0: add             SP, SP, #8
    // 0xa657d4: ldur            x0, [fp, #-0x10]
    // 0xa657d8: ldur            x2, [fp, #-8]
    // 0xa657dc: b               #0xa65748
    // 0xa657e0: r0 = Null
    //     0xa657e0: mov             x0, NULL
    // 0xa657e4: LeaveFrame
    //     0xa657e4: mov             SP, fp
    //     0xa657e8: ldp             fp, lr, [SP], #0x10
    // 0xa657ec: ret
    //     0xa657ec: ret             
    // 0xa657f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa657f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa657f4: b               #0xa65704
    // 0xa657f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa657f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa657fc: b               #0xa65754
  }
  _ childScrollOffset(/* No info */) {
    // ** addr: 0xa82d40, size: 0xac
    // 0xa82d40: EnterFrame
    //     0xa82d40: stp             fp, lr, [SP, #-0x10]!
    //     0xa82d44: mov             fp, SP
    // 0xa82d48: AllocStack(0x8)
    //     0xa82d48: sub             SP, SP, #8
    // 0xa82d4c: ldr             x0, [fp, #0x10]
    // 0xa82d50: r2 = Null
    //     0xa82d50: mov             x2, NULL
    // 0xa82d54: r1 = Null
    //     0xa82d54: mov             x1, NULL
    // 0xa82d58: r4 = 59
    //     0xa82d58: mov             x4, #0x3b
    // 0xa82d5c: branchIfSmi(r0, 0xa82d68)
    //     0xa82d5c: tbz             w0, #0, #0xa82d68
    // 0xa82d60: r4 = LoadClassIdInstr(r0)
    //     0xa82d60: ldur            x4, [x0, #-1]
    //     0xa82d64: ubfx            x4, x4, #0xc, #0x14
    // 0xa82d68: sub             x4, x4, #0x961
    // 0xa82d6c: cmp             x4, #0xbe
    // 0xa82d70: b.ls            #0xa82d84
    // 0xa82d74: r8 = RenderObject
    //     0xa82d74: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0xa82d78: r3 = Null
    //     0xa82d78: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fb88] Null
    //     0xa82d7c: ldr             x3, [x3, #0xb88]
    // 0xa82d80: r0 = RenderObject()
    //     0xa82d80: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0xa82d84: ldr             x0, [fp, #0x10]
    // 0xa82d88: LoadField: r3 = r0->field_17
    //     0xa82d88: ldur            w3, [x0, #0x17]
    // 0xa82d8c: DecompressPointer r3
    //     0xa82d8c: add             x3, x3, HEAP, lsl #32
    // 0xa82d90: stur            x3, [fp, #-8]
    // 0xa82d94: cmp             w3, NULL
    // 0xa82d98: b.eq            #0xa82de8
    // 0xa82d9c: mov             x0, x3
    // 0xa82da0: r2 = Null
    //     0xa82da0: mov             x2, NULL
    // 0xa82da4: r1 = Null
    //     0xa82da4: mov             x1, NULL
    // 0xa82da8: r4 = LoadClassIdInstr(r0)
    //     0xa82da8: ldur            x4, [x0, #-1]
    //     0xa82dac: ubfx            x4, x4, #0xc, #0x14
    // 0xa82db0: sub             x4, x4, #0x7f9
    // 0xa82db4: cmp             x4, #2
    // 0xa82db8: b.ls            #0xa82dd0
    // 0xa82dbc: r8 = SliverMultiBoxAdaptorParentData
    //     0xa82dbc: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0xa82dc0: ldr             x8, [x8, #0x120]
    // 0xa82dc4: r3 = Null
    //     0xa82dc4: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fb98] Null
    //     0xa82dc8: ldr             x3, [x3, #0xb98]
    // 0xa82dcc: r0 = DefaultTypeTest()
    //     0xa82dcc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa82dd0: ldur            x1, [fp, #-8]
    // 0xa82dd4: LoadField: r0 = r1->field_7
    //     0xa82dd4: ldur            w0, [x1, #7]
    // 0xa82dd8: DecompressPointer r0
    //     0xa82dd8: add             x0, x0, HEAP, lsl #32
    // 0xa82ddc: LeaveFrame
    //     0xa82ddc: mov             SP, fp
    //     0xa82de0: ldp             fp, lr, [SP], #0x10
    // 0xa82de4: ret
    //     0xa82de4: ret             
    // 0xa82de8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa82de8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0xa8b320, size: 0x13c
    // 0xa8b320: EnterFrame
    //     0xa8b320: stp             fp, lr, [SP, #-0x10]!
    //     0xa8b324: mov             fp, SP
    // 0xa8b328: AllocStack(0x18)
    //     0xa8b328: sub             SP, SP, #0x18
    // 0xa8b32c: CheckStackOverflow
    //     0xa8b32c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8b330: cmp             SP, x16
    //     0xa8b334: b.ls            #0xa8b448
    // 0xa8b338: ldr             x0, [fp, #0x28]
    // 0xa8b33c: LoadField: r1 = r0->field_5f
    //     0xa8b33c: ldur            w1, [x0, #0x5f]
    // 0xa8b340: DecompressPointer r1
    //     0xa8b340: add             x1, x1, HEAP, lsl #32
    // 0xa8b344: ldr             x2, [fp, #0x20]
    // 0xa8b348: stur            x1, [fp, #-0x10]
    // 0xa8b34c: LoadField: r3 = r2->field_7
    //     0xa8b34c: ldur            w3, [x2, #7]
    // 0xa8b350: DecompressPointer r3
    //     0xa8b350: add             x3, x3, HEAP, lsl #32
    // 0xa8b354: stur            x3, [fp, #-8]
    // 0xa8b358: r0 = BoxHitTestResult()
    //     0xa8b358: bl              #0x50ee04  ; AllocateBoxHitTestResultStub -> BoxHitTestResult (size=0x14)
    // 0xa8b35c: mov             x1, x0
    // 0xa8b360: ldur            x0, [fp, #-8]
    // 0xa8b364: stur            x1, [fp, #-0x18]
    // 0xa8b368: StoreField: r1->field_7 = r0
    //     0xa8b368: stur            w0, [x1, #7]
    // 0xa8b36c: ldr             x0, [fp, #0x20]
    // 0xa8b370: LoadField: r2 = r0->field_b
    //     0xa8b370: ldur            w2, [x0, #0xb]
    // 0xa8b374: DecompressPointer r2
    //     0xa8b374: add             x2, x2, HEAP, lsl #32
    // 0xa8b378: StoreField: r1->field_b = r2
    //     0xa8b378: stur            w2, [x1, #0xb]
    // 0xa8b37c: LoadField: r2 = r0->field_f
    //     0xa8b37c: ldur            w2, [x0, #0xf]
    // 0xa8b380: DecompressPointer r2
    //     0xa8b380: add             x2, x2, HEAP, lsl #32
    // 0xa8b384: StoreField: r1->field_f = r2
    //     0xa8b384: stur            w2, [x1, #0xf]
    // 0xa8b388: ldur            x0, [fp, #-0x10]
    // 0xa8b38c: ldr             d0, [fp, #0x10]
    // 0xa8b390: stur            x0, [fp, #-8]
    // 0xa8b394: CheckStackOverflow
    //     0xa8b394: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8b398: cmp             SP, x16
    //     0xa8b39c: b.ls            #0xa8b450
    // 0xa8b3a0: cmp             w0, NULL
    // 0xa8b3a4: b.eq            #0xa8b438
    // 0xa8b3a8: ldr             x16, [fp, #0x28]
    // 0xa8b3ac: stp             x1, x16, [SP, #-0x10]!
    // 0xa8b3b0: ldr             x16, [fp, #0x18]
    // 0xa8b3b4: stp             x16, x0, [SP, #-0x10]!
    // 0xa8b3b8: SaveReg d0
    //     0xa8b3b8: str             d0, [SP, #-8]!
    // 0xa8b3bc: r0 = hitTestBoxChild()
    //     0xa8b3bc: bl              #0xa8b45c  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] _RenderSliverMultiBoxAdaptor&RenderSliver&ContainerRenderObjectMixin&RenderSliverHelpers::hitTestBoxChild
    // 0xa8b3c0: add             SP, SP, #0x28
    // 0xa8b3c4: tbnz            w0, #4, #0xa8b3d8
    // 0xa8b3c8: r0 = true
    //     0xa8b3c8: add             x0, NULL, #0x20  ; true
    // 0xa8b3cc: LeaveFrame
    //     0xa8b3cc: mov             SP, fp
    //     0xa8b3d0: ldp             fp, lr, [SP], #0x10
    // 0xa8b3d4: ret
    //     0xa8b3d4: ret             
    // 0xa8b3d8: ldur            x0, [fp, #-8]
    // 0xa8b3dc: LoadField: r3 = r0->field_17
    //     0xa8b3dc: ldur            w3, [x0, #0x17]
    // 0xa8b3e0: DecompressPointer r3
    //     0xa8b3e0: add             x3, x3, HEAP, lsl #32
    // 0xa8b3e4: stur            x3, [fp, #-0x10]
    // 0xa8b3e8: cmp             w3, NULL
    // 0xa8b3ec: b.eq            #0xa8b458
    // 0xa8b3f0: mov             x0, x3
    // 0xa8b3f4: r2 = Null
    //     0xa8b3f4: mov             x2, NULL
    // 0xa8b3f8: r1 = Null
    //     0xa8b3f8: mov             x1, NULL
    // 0xa8b3fc: r4 = LoadClassIdInstr(r0)
    //     0xa8b3fc: ldur            x4, [x0, #-1]
    //     0xa8b400: ubfx            x4, x4, #0xc, #0x14
    // 0xa8b404: sub             x4, x4, #0x7f9
    // 0xa8b408: cmp             x4, #2
    // 0xa8b40c: b.ls            #0xa8b424
    // 0xa8b410: r8 = SliverMultiBoxAdaptorParentData
    //     0xa8b410: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0xa8b414: ldr             x8, [x8, #0x120]
    // 0xa8b418: r3 = Null
    //     0xa8b418: add             x3, PP, #0x4f, lsl #12  ; [pp+0x4fba8] Null
    //     0xa8b41c: ldr             x3, [x3, #0xba8]
    // 0xa8b420: r0 = DefaultTypeTest()
    //     0xa8b420: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa8b424: ldur            x1, [fp, #-0x10]
    // 0xa8b428: LoadField: r0 = r1->field_b
    //     0xa8b428: ldur            w0, [x1, #0xb]
    // 0xa8b42c: DecompressPointer r0
    //     0xa8b42c: add             x0, x0, HEAP, lsl #32
    // 0xa8b430: ldur            x1, [fp, #-0x18]
    // 0xa8b434: b               #0xa8b38c
    // 0xa8b438: r0 = false
    //     0xa8b438: add             x0, NULL, #0x30  ; false
    // 0xa8b43c: LeaveFrame
    //     0xa8b43c: mov             SP, fp
    //     0xa8b440: ldp             fp, lr, [SP], #0x10
    // 0xa8b444: ret
    //     0xa8b444: ret             
    // 0xa8b448: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8b448: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8b44c: b               #0xa8b338
    // 0xa8b450: r0 = StackOverflowSharedWithFPURegs()
    //     0xa8b450: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xa8b454: b               #0xa8b3a0
    // 0xa8b458: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa8b458: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ childMainAxisPosition(/* No info */) {
    // ** addr: 0xbcdb94, size: 0x100
    // 0xbcdb94: EnterFrame
    //     0xbcdb94: stp             fp, lr, [SP, #-0x10]!
    //     0xbcdb98: mov             fp, SP
    // 0xbcdb9c: AllocStack(0x10)
    //     0xbcdb9c: sub             SP, SP, #0x10
    // 0xbcdba0: ldr             x0, [fp, #0x10]
    // 0xbcdba4: LoadField: r3 = r0->field_17
    //     0xbcdba4: ldur            w3, [x0, #0x17]
    // 0xbcdba8: DecompressPointer r3
    //     0xbcdba8: add             x3, x3, HEAP, lsl #32
    // 0xbcdbac: stur            x3, [fp, #-8]
    // 0xbcdbb0: cmp             w3, NULL
    // 0xbcdbb4: b.eq            #0xbcdc8c
    // 0xbcdbb8: mov             x0, x3
    // 0xbcdbbc: r2 = Null
    //     0xbcdbbc: mov             x2, NULL
    // 0xbcdbc0: r1 = Null
    //     0xbcdbc0: mov             x1, NULL
    // 0xbcdbc4: r4 = LoadClassIdInstr(r0)
    //     0xbcdbc4: ldur            x4, [x0, #-1]
    //     0xbcdbc8: ubfx            x4, x4, #0xc, #0x14
    // 0xbcdbcc: sub             x4, x4, #0x7f9
    // 0xbcdbd0: cmp             x4, #2
    // 0xbcdbd4: b.ls            #0xbcdbec
    // 0xbcdbd8: r8 = SliverMultiBoxAdaptorParentData
    //     0xbcdbd8: add             x8, PP, #0x43, lsl #12  ; [pp+0x43120] Type: SliverMultiBoxAdaptorParentData
    //     0xbcdbdc: ldr             x8, [x8, #0x120]
    // 0xbcdbe0: r3 = Null
    //     0xbcdbe0: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4ade0] Null
    //     0xbcdbe4: ldr             x3, [x3, #0xde0]
    // 0xbcdbe8: r0 = DefaultTypeTest()
    //     0xbcdbe8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xbcdbec: ldur            x0, [fp, #-8]
    // 0xbcdbf0: LoadField: r3 = r0->field_7
    //     0xbcdbf0: ldur            w3, [x0, #7]
    // 0xbcdbf4: DecompressPointer r3
    //     0xbcdbf4: add             x3, x3, HEAP, lsl #32
    // 0xbcdbf8: stur            x3, [fp, #-0x10]
    // 0xbcdbfc: cmp             w3, NULL
    // 0xbcdc00: b.eq            #0xbcdc90
    // 0xbcdc04: ldr             x0, [fp, #0x18]
    // 0xbcdc08: LoadField: r4 = r0->field_27
    //     0xbcdc08: ldur            w4, [x0, #0x27]
    // 0xbcdc0c: DecompressPointer r4
    //     0xbcdc0c: add             x4, x4, HEAP, lsl #32
    // 0xbcdc10: stur            x4, [fp, #-8]
    // 0xbcdc14: cmp             w4, NULL
    // 0xbcdc18: b.eq            #0xbcdc6c
    // 0xbcdc1c: mov             x0, x4
    // 0xbcdc20: r2 = Null
    //     0xbcdc20: mov             x2, NULL
    // 0xbcdc24: r1 = Null
    //     0xbcdc24: mov             x1, NULL
    // 0xbcdc28: r4 = LoadClassIdInstr(r0)
    //     0xbcdc28: ldur            x4, [x0, #-1]
    //     0xbcdc2c: ubfx            x4, x4, #0xc, #0x14
    // 0xbcdc30: cmp             x4, #0x80c
    // 0xbcdc34: b.eq            #0xbcdc4c
    // 0xbcdc38: r8 = SliverConstraints
    //     0xbcdc38: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2d5a8] Type: SliverConstraints
    //     0xbcdc3c: ldr             x8, [x8, #0x5a8]
    // 0xbcdc40: r3 = Null
    //     0xbcdc40: add             x3, PP, #0x4a, lsl #12  ; [pp+0x4adf0] Null
    //     0xbcdc44: ldr             x3, [x3, #0xdf0]
    // 0xbcdc48: r0 = DefaultTypeTest()
    //     0xbcdc48: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xbcdc4c: ldur            x0, [fp, #-8]
    // 0xbcdc50: LoadField: d1 = r0->field_13
    //     0xbcdc50: ldur            d1, [x0, #0x13]
    // 0xbcdc54: ldur            x0, [fp, #-0x10]
    // 0xbcdc58: LoadField: d2 = r0->field_7
    //     0xbcdc58: ldur            d2, [x0, #7]
    // 0xbcdc5c: fsub            d0, d2, d1
    // 0xbcdc60: LeaveFrame
    //     0xbcdc60: mov             SP, fp
    //     0xbcdc64: ldp             fp, lr, [SP], #0x10
    // 0xbcdc68: ret
    //     0xbcdc68: ret             
    // 0xbcdc6c: r0 = StateError()
    //     0xbcdc6c: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbcdc70: mov             x1, x0
    // 0xbcdc74: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbcdc74: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0xbcdc78: ldr             x0, [x0, #0x1e8]
    // 0xbcdc7c: StoreField: r1->field_b = r0
    //     0xbcdc7c: stur            w0, [x1, #0xb]
    // 0xbcdc80: mov             x0, x1
    // 0xbcdc84: r0 = Throw()
    //     0xbcdc84: bl              #0xd67e38  ; ThrowStub
    // 0xbcdc88: brk             #0
    // 0xbcdc8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbcdc8c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbcdc90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbcdc90: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

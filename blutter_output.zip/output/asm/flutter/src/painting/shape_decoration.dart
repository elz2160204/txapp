// lib: , url: package:flutter/src/painting/shape_decoration.dart

// class id: 1049379, size: 0x8
class :: {
}

// class id: 2935, size: 0x1c, field offset: 0x8
//   const constructor, 
class ShapeDecoration extends Decoration {

  get _ hashCode(/* No info */) {
    // ** addr: 0xafd464, size: 0xdc
    // 0xafd464: EnterFrame
    //     0xafd464: stp             fp, lr, [SP, #-0x10]!
    //     0xafd468: mov             fp, SP
    // 0xafd46c: AllocStack(0x20)
    //     0xafd46c: sub             SP, SP, #0x20
    // 0xafd470: CheckStackOverflow
    //     0xafd470: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafd474: cmp             SP, x16
    //     0xafd478: b.ls            #0xafd538
    // 0xafd47c: ldr             x0, [fp, #0x10]
    // 0xafd480: LoadField: r1 = r0->field_7
    //     0xafd480: ldur            w1, [x0, #7]
    // 0xafd484: DecompressPointer r1
    //     0xafd484: add             x1, x1, HEAP, lsl #32
    // 0xafd488: stur            x1, [fp, #-0x20]
    // 0xafd48c: LoadField: r2 = r0->field_b
    //     0xafd48c: ldur            w2, [x0, #0xb]
    // 0xafd490: DecompressPointer r2
    //     0xafd490: add             x2, x2, HEAP, lsl #32
    // 0xafd494: stur            x2, [fp, #-0x18]
    // 0xafd498: LoadField: r3 = r0->field_f
    //     0xafd498: ldur            w3, [x0, #0xf]
    // 0xafd49c: DecompressPointer r3
    //     0xafd49c: add             x3, x3, HEAP, lsl #32
    // 0xafd4a0: stur            x3, [fp, #-0x10]
    // 0xafd4a4: LoadField: r4 = r0->field_17
    //     0xafd4a4: ldur            w4, [x0, #0x17]
    // 0xafd4a8: DecompressPointer r4
    //     0xafd4a8: add             x4, x4, HEAP, lsl #32
    // 0xafd4ac: stur            x4, [fp, #-8]
    // 0xafd4b0: LoadField: r5 = r0->field_13
    //     0xafd4b0: ldur            w5, [x0, #0x13]
    // 0xafd4b4: DecompressPointer r5
    //     0xafd4b4: add             x5, x5, HEAP, lsl #32
    // 0xafd4b8: cmp             w5, NULL
    // 0xafd4bc: b.ne            #0xafd4c8
    // 0xafd4c0: r0 = Null
    //     0xafd4c0: mov             x0, NULL
    // 0xafd4c4: b               #0xafd4ec
    // 0xafd4c8: SaveReg r5
    //     0xafd4c8: str             x5, [SP, #-8]!
    // 0xafd4cc: r0 = hashAll()
    //     0xafd4cc: bl              #0x707e08  ; [dart:core] Object::hashAll
    // 0xafd4d0: add             SP, SP, #8
    // 0xafd4d4: mov             x2, x0
    // 0xafd4d8: r0 = BoxInt64Instr(r2)
    //     0xafd4d8: sbfiz           x0, x2, #1, #0x1f
    //     0xafd4dc: cmp             x2, x0, asr #1
    //     0xafd4e0: b.eq            #0xafd4ec
    //     0xafd4e4: bl              #0xd69bb8
    //     0xafd4e8: stur            x2, [x0, #7]
    // 0xafd4ec: ldur            x16, [fp, #-0x20]
    // 0xafd4f0: ldur            lr, [fp, #-0x18]
    // 0xafd4f4: stp             lr, x16, [SP, #-0x10]!
    // 0xafd4f8: ldur            x16, [fp, #-0x10]
    // 0xafd4fc: ldur            lr, [fp, #-8]
    // 0xafd500: stp             lr, x16, [SP, #-0x10]!
    // 0xafd504: SaveReg r0
    //     0xafd504: str             x0, [SP, #-8]!
    // 0xafd508: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xafd508: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xafd50c: r0 = hash()
    //     0xafd50c: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafd510: add             SP, SP, #0x28
    // 0xafd514: mov             x2, x0
    // 0xafd518: r0 = BoxInt64Instr(r2)
    //     0xafd518: sbfiz           x0, x2, #1, #0x1f
    //     0xafd51c: cmp             x2, x0, asr #1
    //     0xafd520: b.eq            #0xafd52c
    //     0xafd524: bl              #0xd69bb8
    //     0xafd528: stur            x2, [x0, #7]
    // 0xafd52c: LeaveFrame
    //     0xafd52c: mov             SP, fp
    //     0xafd530: ldp             fp, lr, [SP], #0x10
    // 0xafd534: ret
    //     0xafd534: ret             
    // 0xafd538: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafd538: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafd53c: b               #0xafd47c
  }
  _ hitTest(/* No info */) {
    // ** addr: 0xb0f428, size: 0x98
    // 0xb0f428: EnterFrame
    //     0xb0f428: stp             fp, lr, [SP, #-0x10]!
    //     0xb0f42c: mov             fp, SP
    // 0xb0f430: AllocStack(0x8)
    //     0xb0f430: sub             SP, SP, #8
    // 0xb0f434: CheckStackOverflow
    //     0xb0f434: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0f438: cmp             SP, x16
    //     0xb0f43c: b.ls            #0xb0f4b8
    // 0xb0f440: ldr             x0, [fp, #0x28]
    // 0xb0f444: LoadField: r1 = r0->field_17
    //     0xb0f444: ldur            w1, [x0, #0x17]
    // 0xb0f448: DecompressPointer r1
    //     0xb0f448: add             x1, x1, HEAP, lsl #32
    // 0xb0f44c: stur            x1, [fp, #-8]
    // 0xb0f450: r16 = Instance_Offset
    //     0xb0f450: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xb0f454: ldr             lr, [fp, #0x20]
    // 0xb0f458: stp             lr, x16, [SP, #-0x10]!
    // 0xb0f45c: r0 = &()
    //     0xb0f45c: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0xb0f460: add             SP, SP, #0x10
    // 0xb0f464: mov             x1, x0
    // 0xb0f468: ldur            x0, [fp, #-8]
    // 0xb0f46c: r2 = LoadClassIdInstr(r0)
    //     0xb0f46c: ldur            x2, [x0, #-1]
    //     0xb0f470: ubfx            x2, x2, #0xc, #0x14
    // 0xb0f474: stp             x1, x0, [SP, #-0x10]!
    // 0xb0f478: ldr             x16, [fp, #0x10]
    // 0xb0f47c: SaveReg r16
    //     0xb0f47c: str             x16, [SP, #-8]!
    // 0xb0f480: mov             x0, x2
    // 0xb0f484: r4 = const [0, 0x3, 0x3, 0x2, textDirection, 0x2, null]
    //     0xb0f484: add             x4, PP, #0x28, lsl #12  ; [pp+0x285b8] List(7) [0, 0x3, 0x3, 0x2, "textDirection", 0x2, Null]
    //     0xb0f488: ldr             x4, [x4, #0x5b8]
    // 0xb0f48c: r0 = GDT[cid_x0 + -0xfde]()
    //     0xb0f48c: sub             lr, x0, #0xfde
    //     0xb0f490: ldr             lr, [x21, lr, lsl #3]
    //     0xb0f494: blr             lr
    // 0xb0f498: add             SP, SP, #0x18
    // 0xb0f49c: ldr             x16, [fp, #0x18]
    // 0xb0f4a0: stp             x16, x0, [SP, #-0x10]!
    // 0xb0f4a4: r0 = contains()
    //     0xb0f4a4: bl              #0x640124  ; [dart:ui] Path::contains
    // 0xb0f4a8: add             SP, SP, #0x10
    // 0xb0f4ac: LeaveFrame
    //     0xb0f4ac: mov             SP, fp
    //     0xb0f4b0: ldp             fp, lr, [SP], #0x10
    // 0xb0f4b4: ret
    //     0xb0f4b4: ret             
    // 0xb0f4b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0f4b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0f4bc: b               #0xb0f440
  }
  get _ padding(/* No info */) {
    // ** addr: 0xc43cb4, size: 0x50
    // 0xc43cb4: EnterFrame
    //     0xc43cb4: stp             fp, lr, [SP, #-0x10]!
    //     0xc43cb8: mov             fp, SP
    // 0xc43cbc: CheckStackOverflow
    //     0xc43cbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc43cc0: cmp             SP, x16
    //     0xc43cc4: b.ls            #0xc43cfc
    // 0xc43cc8: ldr             x0, [fp, #0x10]
    // 0xc43ccc: LoadField: r1 = r0->field_17
    //     0xc43ccc: ldur            w1, [x0, #0x17]
    // 0xc43cd0: DecompressPointer r1
    //     0xc43cd0: add             x1, x1, HEAP, lsl #32
    // 0xc43cd4: r0 = LoadClassIdInstr(r1)
    //     0xc43cd4: ldur            x0, [x1, #-1]
    //     0xc43cd8: ubfx            x0, x0, #0xc, #0x14
    // 0xc43cdc: SaveReg r1
    //     0xc43cdc: str             x1, [SP, #-8]!
    // 0xc43ce0: r0 = GDT[cid_x0 + -0xe39]()
    //     0xc43ce0: sub             lr, x0, #0xe39
    //     0xc43ce4: ldr             lr, [x21, lr, lsl #3]
    //     0xc43ce8: blr             lr
    // 0xc43cec: add             SP, SP, #8
    // 0xc43cf0: LeaveFrame
    //     0xc43cf0: mov             SP, fp
    //     0xc43cf4: ldp             fp, lr, [SP], #0x10
    // 0xc43cf8: ret
    //     0xc43cf8: ret             
    // 0xc43cfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc43cfc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc43d00: b               #0xc43cc8
  }
  _ ==(/* No info */) {
    // ** addr: 0xc80d44, size: 0x230
    // 0xc80d44: EnterFrame
    //     0xc80d44: stp             fp, lr, [SP, #-0x10]!
    //     0xc80d48: mov             fp, SP
    // 0xc80d4c: AllocStack(0x8)
    //     0xc80d4c: sub             SP, SP, #8
    // 0xc80d50: CheckStackOverflow
    //     0xc80d50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc80d54: cmp             SP, x16
    //     0xc80d58: b.ls            #0xc80f6c
    // 0xc80d5c: ldr             x1, [fp, #0x10]
    // 0xc80d60: cmp             w1, NULL
    // 0xc80d64: b.ne            #0xc80d78
    // 0xc80d68: r0 = false
    //     0xc80d68: add             x0, NULL, #0x30  ; false
    // 0xc80d6c: LeaveFrame
    //     0xc80d6c: mov             SP, fp
    //     0xc80d70: ldp             fp, lr, [SP], #0x10
    // 0xc80d74: ret
    //     0xc80d74: ret             
    // 0xc80d78: ldr             x2, [fp, #0x18]
    // 0xc80d7c: cmp             w2, w1
    // 0xc80d80: b.ne            #0xc80d94
    // 0xc80d84: r0 = true
    //     0xc80d84: add             x0, NULL, #0x20  ; true
    // 0xc80d88: LeaveFrame
    //     0xc80d88: mov             SP, fp
    //     0xc80d8c: ldp             fp, lr, [SP], #0x10
    // 0xc80d90: ret
    //     0xc80d90: ret             
    // 0xc80d94: r0 = 59
    //     0xc80d94: mov             x0, #0x3b
    // 0xc80d98: branchIfSmi(r1, 0xc80da4)
    //     0xc80d98: tbz             w1, #0, #0xc80da4
    // 0xc80d9c: r0 = LoadClassIdInstr(r1)
    //     0xc80d9c: ldur            x0, [x1, #-1]
    //     0xc80da0: ubfx            x0, x0, #0xc, #0x14
    // 0xc80da4: SaveReg r1
    //     0xc80da4: str             x1, [SP, #-8]!
    // 0xc80da8: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc80da8: mov             x17, #0x57c5
    //     0xc80dac: add             lr, x0, x17
    //     0xc80db0: ldr             lr, [x21, lr, lsl #3]
    //     0xc80db4: blr             lr
    // 0xc80db8: add             SP, SP, #8
    // 0xc80dbc: stur            x0, [fp, #-8]
    // 0xc80dc0: ldr             x16, [fp, #0x18]
    // 0xc80dc4: SaveReg r16
    //     0xc80dc4: str             x16, [SP, #-8]!
    // 0xc80dc8: r0 = runtimeType()
    //     0xc80dc8: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc80dcc: add             SP, SP, #8
    // 0xc80dd0: mov             x1, x0
    // 0xc80dd4: ldur            x0, [fp, #-8]
    // 0xc80dd8: r2 = LoadClassIdInstr(r0)
    //     0xc80dd8: ldur            x2, [x0, #-1]
    //     0xc80ddc: ubfx            x2, x2, #0xc, #0x14
    // 0xc80de0: stp             x1, x0, [SP, #-0x10]!
    // 0xc80de4: mov             x0, x2
    // 0xc80de8: mov             lr, x0
    // 0xc80dec: ldr             lr, [x21, lr, lsl #3]
    // 0xc80df0: blr             lr
    // 0xc80df4: add             SP, SP, #0x10
    // 0xc80df8: tbz             w0, #4, #0xc80e0c
    // 0xc80dfc: r0 = false
    //     0xc80dfc: add             x0, NULL, #0x30  ; false
    // 0xc80e00: LeaveFrame
    //     0xc80e00: mov             SP, fp
    //     0xc80e04: ldp             fp, lr, [SP], #0x10
    // 0xc80e08: ret
    //     0xc80e08: ret             
    // 0xc80e0c: ldr             x1, [fp, #0x10]
    // 0xc80e10: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc80e10: mov             x0, #0x76
    //     0xc80e14: tbz             w1, #0, #0xc80e24
    //     0xc80e18: ldur            x0, [x1, #-1]
    //     0xc80e1c: ubfx            x0, x0, #0xc, #0x14
    //     0xc80e20: lsl             x0, x0, #1
    // 0xc80e24: r2 = LoadInt32Instr(r0)
    //     0xc80e24: sbfx            x2, x0, #1, #0x1f
    // 0xc80e28: cmp             x2, #0xb77
    // 0xc80e2c: b.lt            #0xc80f5c
    // 0xc80e30: cmp             x2, #0xb78
    // 0xc80e34: b.gt            #0xc80f5c
    // 0xc80e38: ldr             x2, [fp, #0x18]
    // 0xc80e3c: LoadField: r0 = r1->field_7
    //     0xc80e3c: ldur            w0, [x1, #7]
    // 0xc80e40: DecompressPointer r0
    //     0xc80e40: add             x0, x0, HEAP, lsl #32
    // 0xc80e44: LoadField: r3 = r2->field_7
    //     0xc80e44: ldur            w3, [x2, #7]
    // 0xc80e48: DecompressPointer r3
    //     0xc80e48: add             x3, x3, HEAP, lsl #32
    // 0xc80e4c: r4 = LoadClassIdInstr(r0)
    //     0xc80e4c: ldur            x4, [x0, #-1]
    //     0xc80e50: ubfx            x4, x4, #0xc, #0x14
    // 0xc80e54: stp             x3, x0, [SP, #-0x10]!
    // 0xc80e58: mov             x0, x4
    // 0xc80e5c: mov             lr, x0
    // 0xc80e60: ldr             lr, [x21, lr, lsl #3]
    // 0xc80e64: blr             lr
    // 0xc80e68: add             SP, SP, #0x10
    // 0xc80e6c: tbnz            w0, #4, #0xc80f5c
    // 0xc80e70: ldr             x2, [fp, #0x18]
    // 0xc80e74: ldr             x1, [fp, #0x10]
    // 0xc80e78: LoadField: r0 = r1->field_b
    //     0xc80e78: ldur            w0, [x1, #0xb]
    // 0xc80e7c: DecompressPointer r0
    //     0xc80e7c: add             x0, x0, HEAP, lsl #32
    // 0xc80e80: LoadField: r3 = r2->field_b
    //     0xc80e80: ldur            w3, [x2, #0xb]
    // 0xc80e84: DecompressPointer r3
    //     0xc80e84: add             x3, x3, HEAP, lsl #32
    // 0xc80e88: r4 = LoadClassIdInstr(r0)
    //     0xc80e88: ldur            x4, [x0, #-1]
    //     0xc80e8c: ubfx            x4, x4, #0xc, #0x14
    // 0xc80e90: stp             x3, x0, [SP, #-0x10]!
    // 0xc80e94: mov             x0, x4
    // 0xc80e98: mov             lr, x0
    // 0xc80e9c: ldr             lr, [x21, lr, lsl #3]
    // 0xc80ea0: blr             lr
    // 0xc80ea4: add             SP, SP, #0x10
    // 0xc80ea8: tbnz            w0, #4, #0xc80f5c
    // 0xc80eac: ldr             x2, [fp, #0x18]
    // 0xc80eb0: ldr             x1, [fp, #0x10]
    // 0xc80eb4: LoadField: r0 = r1->field_f
    //     0xc80eb4: ldur            w0, [x1, #0xf]
    // 0xc80eb8: DecompressPointer r0
    //     0xc80eb8: add             x0, x0, HEAP, lsl #32
    // 0xc80ebc: LoadField: r3 = r2->field_f
    //     0xc80ebc: ldur            w3, [x2, #0xf]
    // 0xc80ec0: DecompressPointer r3
    //     0xc80ec0: add             x3, x3, HEAP, lsl #32
    // 0xc80ec4: r4 = LoadClassIdInstr(r0)
    //     0xc80ec4: ldur            x4, [x0, #-1]
    //     0xc80ec8: ubfx            x4, x4, #0xc, #0x14
    // 0xc80ecc: stp             x3, x0, [SP, #-0x10]!
    // 0xc80ed0: mov             x0, x4
    // 0xc80ed4: mov             lr, x0
    // 0xc80ed8: ldr             lr, [x21, lr, lsl #3]
    // 0xc80edc: blr             lr
    // 0xc80ee0: add             SP, SP, #0x10
    // 0xc80ee4: tbnz            w0, #4, #0xc80f5c
    // 0xc80ee8: ldr             x1, [fp, #0x18]
    // 0xc80eec: ldr             x0, [fp, #0x10]
    // 0xc80ef0: LoadField: r2 = r0->field_13
    //     0xc80ef0: ldur            w2, [x0, #0x13]
    // 0xc80ef4: DecompressPointer r2
    //     0xc80ef4: add             x2, x2, HEAP, lsl #32
    // 0xc80ef8: LoadField: r3 = r1->field_13
    //     0xc80ef8: ldur            w3, [x1, #0x13]
    // 0xc80efc: DecompressPointer r3
    //     0xc80efc: add             x3, x3, HEAP, lsl #32
    // 0xc80f00: r16 = <BoxShadow>
    //     0xc80f00: add             x16, PP, #0x15, lsl #12  ; [pp+0x15268] TypeArguments: <BoxShadow>
    //     0xc80f04: ldr             x16, [x16, #0x268]
    // 0xc80f08: stp             x2, x16, [SP, #-0x10]!
    // 0xc80f0c: SaveReg r3
    //     0xc80f0c: str             x3, [SP, #-8]!
    // 0xc80f10: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc80f10: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc80f14: r0 = listEquals()
    //     0xc80f14: bl              #0x512fbc  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0xc80f18: add             SP, SP, #0x18
    // 0xc80f1c: tbnz            w0, #4, #0xc80f5c
    // 0xc80f20: ldr             x1, [fp, #0x18]
    // 0xc80f24: ldr             x0, [fp, #0x10]
    // 0xc80f28: LoadField: r2 = r0->field_17
    //     0xc80f28: ldur            w2, [x0, #0x17]
    // 0xc80f2c: DecompressPointer r2
    //     0xc80f2c: add             x2, x2, HEAP, lsl #32
    // 0xc80f30: LoadField: r0 = r1->field_17
    //     0xc80f30: ldur            w0, [x1, #0x17]
    // 0xc80f34: DecompressPointer r0
    //     0xc80f34: add             x0, x0, HEAP, lsl #32
    // 0xc80f38: r1 = LoadClassIdInstr(r2)
    //     0xc80f38: ldur            x1, [x2, #-1]
    //     0xc80f3c: ubfx            x1, x1, #0xc, #0x14
    // 0xc80f40: stp             x0, x2, [SP, #-0x10]!
    // 0xc80f44: mov             x0, x1
    // 0xc80f48: mov             lr, x0
    // 0xc80f4c: ldr             lr, [x21, lr, lsl #3]
    // 0xc80f50: blr             lr
    // 0xc80f54: add             SP, SP, #0x10
    // 0xc80f58: b               #0xc80f60
    // 0xc80f5c: r0 = false
    //     0xc80f5c: add             x0, NULL, #0x30  ; false
    // 0xc80f60: LeaveFrame
    //     0xc80f60: mov             SP, fp
    //     0xc80f64: ldp             fp, lr, [SP], #0x10
    // 0xc80f68: ret
    //     0xc80f68: ret             
    // 0xc80f6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc80f6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc80f70: b               #0xc80d5c
  }
  _ createBoxPainter(/* No info */) {
    // ** addr: 0xccf5ac, size: 0x4c
    // 0xccf5ac: EnterFrame
    //     0xccf5ac: stp             fp, lr, [SP, #-0x10]!
    //     0xccf5b0: mov             fp, SP
    // 0xccf5b4: ldr             x0, [fp, #0x10]
    // 0xccf5b8: cmp             w0, NULL
    // 0xccf5bc: b.eq            #0xccf5f4
    // 0xccf5c0: r0 = _ShapeDecorationPainter()
    //     0xccf5c0: bl              #0xccf5f8  ; Allocate_ShapeDecorationPainterStub -> _ShapeDecorationPainter (size=0x38)
    // 0xccf5c4: r1 = Sentinel
    //     0xccf5c4: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xccf5c8: StoreField: r0->field_17 = r1
    //     0xccf5c8: stur            w1, [x0, #0x17]
    // 0xccf5cc: StoreField: r0->field_27 = r1
    //     0xccf5cc: stur            w1, [x0, #0x27]
    // 0xccf5d0: StoreField: r0->field_2b = r1
    //     0xccf5d0: stur            w1, [x0, #0x2b]
    // 0xccf5d4: StoreField: r0->field_2f = r1
    //     0xccf5d4: stur            w1, [x0, #0x2f]
    // 0xccf5d8: ldr             x1, [fp, #0x18]
    // 0xccf5dc: StoreField: r0->field_b = r1
    //     0xccf5dc: stur            w1, [x0, #0xb]
    // 0xccf5e0: ldr             x1, [fp, #0x10]
    // 0xccf5e4: StoreField: r0->field_7 = r1
    //     0xccf5e4: stur            w1, [x0, #7]
    // 0xccf5e8: LeaveFrame
    //     0xccf5e8: mov             SP, fp
    //     0xccf5ec: ldp             fp, lr, [SP], #0x10
    // 0xccf5f0: ret
    //     0xccf5f0: ret             
    // 0xccf5f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xccf5f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ lerpTo(/* No info */) {
    // ** addr: 0xcd6c24, size: 0xbc
    // 0xcd6c24: EnterFrame
    //     0xcd6c24: stp             fp, lr, [SP, #-0x10]!
    //     0xcd6c28: mov             fp, SP
    // 0xcd6c2c: CheckStackOverflow
    //     0xcd6c2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd6c30: cmp             SP, x16
    //     0xcd6c34: b.ls            #0xcd6cd8
    // 0xcd6c38: ldr             x0, [fp, #0x18]
    // 0xcd6c3c: r1 = LoadClassIdInstr(r0)
    //     0xcd6c3c: ldur            x1, [x0, #-1]
    //     0xcd6c40: ubfx            x1, x1, #0xc, #0x14
    // 0xcd6c44: lsl             x1, x1, #1
    // 0xcd6c48: r17 = 5874
    //     0xcd6c48: mov             x17, #0x16f2
    // 0xcd6c4c: cmp             w1, w17
    // 0xcd6c50: b.ne            #0xcd6c88
    // 0xcd6c54: ldr             d0, [fp, #0x10]
    // 0xcd6c58: stp             x0, NULL, [SP, #-0x10]!
    // 0xcd6c5c: r0 = ShapeDecoration.fromBoxDecoration()
    //     0xcd6c5c: bl              #0xcd6fb4  ; [package:flutter/src/painting/shape_decoration.dart] ShapeDecoration::ShapeDecoration.fromBoxDecoration
    // 0xcd6c60: add             SP, SP, #0x10
    // 0xcd6c64: ldr             x16, [fp, #0x20]
    // 0xcd6c68: stp             x0, x16, [SP, #-0x10]!
    // 0xcd6c6c: ldr             d0, [fp, #0x10]
    // 0xcd6c70: SaveReg d0
    //     0xcd6c70: str             d0, [SP, #-8]!
    // 0xcd6c74: r0 = lerp()
    //     0xcd6c74: bl              #0xcd6ce0  ; [package:flutter/src/painting/shape_decoration.dart] ShapeDecoration::lerp
    // 0xcd6c78: add             SP, SP, #0x18
    // 0xcd6c7c: LeaveFrame
    //     0xcd6c7c: mov             SP, fp
    //     0xcd6c80: ldp             fp, lr, [SP], #0x10
    // 0xcd6c84: ret
    //     0xcd6c84: ret             
    // 0xcd6c88: ldr             d0, [fp, #0x10]
    // 0xcd6c8c: cmp             w0, NULL
    // 0xcd6c90: b.eq            #0xcd6ca8
    // 0xcd6c94: r2 = LoadInt32Instr(r1)
    //     0xcd6c94: sbfx            x2, x1, #1, #0x1f
    // 0xcd6c98: cmp             x2, #0xb77
    // 0xcd6c9c: b.lt            #0xcd6cc8
    // 0xcd6ca0: cmp             x2, #0xb78
    // 0xcd6ca4: b.gt            #0xcd6cc8
    // 0xcd6ca8: ldr             x16, [fp, #0x20]
    // 0xcd6cac: stp             x0, x16, [SP, #-0x10]!
    // 0xcd6cb0: SaveReg d0
    //     0xcd6cb0: str             d0, [SP, #-8]!
    // 0xcd6cb4: r0 = lerp()
    //     0xcd6cb4: bl              #0xcd6ce0  ; [package:flutter/src/painting/shape_decoration.dart] ShapeDecoration::lerp
    // 0xcd6cb8: add             SP, SP, #0x18
    // 0xcd6cbc: LeaveFrame
    //     0xcd6cbc: mov             SP, fp
    //     0xcd6cc0: ldp             fp, lr, [SP], #0x10
    // 0xcd6cc4: ret
    //     0xcd6cc4: ret             
    // 0xcd6cc8: r0 = Null
    //     0xcd6cc8: mov             x0, NULL
    // 0xcd6ccc: LeaveFrame
    //     0xcd6ccc: mov             SP, fp
    //     0xcd6cd0: ldp             fp, lr, [SP], #0x10
    // 0xcd6cd4: ret
    //     0xcd6cd4: ret             
    // 0xcd6cd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd6cd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd6cdc: b               #0xcd6c38
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xcd6ce0, size: 0x2d4
    // 0xcd6ce0: EnterFrame
    //     0xcd6ce0: stp             fp, lr, [SP, #-0x10]!
    //     0xcd6ce4: mov             fp, SP
    // 0xcd6ce8: AllocStack(0x28)
    //     0xcd6ce8: sub             SP, SP, #0x28
    // 0xcd6cec: CheckStackOverflow
    //     0xcd6cec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd6cf0: cmp             SP, x16
    //     0xcd6cf4: b.ls            #0xcd6f7c
    // 0xcd6cf8: ldr             x0, [fp, #0x20]
    // 0xcd6cfc: cmp             w0, NULL
    // 0xcd6d00: b.ne            #0xcd6d20
    // 0xcd6d04: ldr             x1, [fp, #0x18]
    // 0xcd6d08: cmp             w1, NULL
    // 0xcd6d0c: b.ne            #0xcd6d24
    // 0xcd6d10: r0 = Null
    //     0xcd6d10: mov             x0, NULL
    // 0xcd6d14: LeaveFrame
    //     0xcd6d14: mov             SP, fp
    //     0xcd6d18: ldp             fp, lr, [SP], #0x10
    // 0xcd6d1c: ret
    //     0xcd6d1c: ret             
    // 0xcd6d20: ldr             x1, [fp, #0x18]
    // 0xcd6d24: cmp             w0, NULL
    // 0xcd6d28: b.eq            #0xcd6d7c
    // 0xcd6d2c: cmp             w1, NULL
    // 0xcd6d30: b.eq            #0xcd6d74
    // 0xcd6d34: ldr             d1, [fp, #0x10]
    // 0xcd6d38: d0 = 0.000000
    //     0xcd6d38: eor             v0.16b, v0.16b, v0.16b
    // 0xcd6d3c: fcmp            d1, d0
    // 0xcd6d40: b.vs            #0xcd6d54
    // 0xcd6d44: b.ne            #0xcd6d54
    // 0xcd6d48: LeaveFrame
    //     0xcd6d48: mov             SP, fp
    //     0xcd6d4c: ldp             fp, lr, [SP], #0x10
    // 0xcd6d50: ret
    //     0xcd6d50: ret             
    // 0xcd6d54: d0 = 1.000000
    //     0xcd6d54: fmov            d0, #1.00000000
    // 0xcd6d58: fcmp            d1, d0
    // 0xcd6d5c: b.vs            #0xcd6d80
    // 0xcd6d60: b.ne            #0xcd6d80
    // 0xcd6d64: mov             x0, x1
    // 0xcd6d68: LeaveFrame
    //     0xcd6d68: mov             SP, fp
    //     0xcd6d6c: ldp             fp, lr, [SP], #0x10
    // 0xcd6d70: ret
    //     0xcd6d70: ret             
    // 0xcd6d74: ldr             d1, [fp, #0x10]
    // 0xcd6d78: b               #0xcd6d80
    // 0xcd6d7c: ldr             d1, [fp, #0x10]
    // 0xcd6d80: cmp             w0, NULL
    // 0xcd6d84: b.ne            #0xcd6d90
    // 0xcd6d88: r2 = Null
    //     0xcd6d88: mov             x2, NULL
    // 0xcd6d8c: b               #0xcd6d98
    // 0xcd6d90: LoadField: r2 = r0->field_7
    //     0xcd6d90: ldur            w2, [x0, #7]
    // 0xcd6d94: DecompressPointer r2
    //     0xcd6d94: add             x2, x2, HEAP, lsl #32
    // 0xcd6d98: cmp             w1, NULL
    // 0xcd6d9c: b.ne            #0xcd6da8
    // 0xcd6da0: r3 = Null
    //     0xcd6da0: mov             x3, NULL
    // 0xcd6da4: b               #0xcd6db0
    // 0xcd6da8: LoadField: r3 = r1->field_7
    //     0xcd6da8: ldur            w3, [x1, #7]
    // 0xcd6dac: DecompressPointer r3
    //     0xcd6dac: add             x3, x3, HEAP, lsl #32
    // 0xcd6db0: r4 = inline_Allocate_Double()
    //     0xcd6db0: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xcd6db4: add             x4, x4, #0x10
    //     0xcd6db8: cmp             x5, x4
    //     0xcd6dbc: b.ls            #0xcd6f84
    //     0xcd6dc0: str             x4, [THR, #0x60]  ; THR::top
    //     0xcd6dc4: sub             x4, x4, #0xf
    //     0xcd6dc8: mov             x5, #0xd108
    //     0xcd6dcc: movk            x5, #3, lsl #16
    //     0xcd6dd0: stur            x5, [x4, #-1]
    // 0xcd6dd4: StoreField: r4->field_7 = d1
    //     0xcd6dd4: stur            d1, [x4, #7]
    // 0xcd6dd8: stp             x3, x2, [SP, #-0x10]!
    // 0xcd6ddc: SaveReg r4
    //     0xcd6ddc: str             x4, [SP, #-8]!
    // 0xcd6de0: r0 = lerp()
    //     0xcd6de0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xcd6de4: add             SP, SP, #0x18
    // 0xcd6de8: mov             x1, x0
    // 0xcd6dec: ldr             x0, [fp, #0x20]
    // 0xcd6df0: stur            x1, [fp, #-8]
    // 0xcd6df4: cmp             w0, NULL
    // 0xcd6df8: b.ne            #0xcd6e04
    // 0xcd6dfc: r3 = Null
    //     0xcd6dfc: mov             x3, NULL
    // 0xcd6e00: b               #0xcd6e10
    // 0xcd6e04: LoadField: r2 = r0->field_b
    //     0xcd6e04: ldur            w2, [x0, #0xb]
    // 0xcd6e08: DecompressPointer r2
    //     0xcd6e08: add             x2, x2, HEAP, lsl #32
    // 0xcd6e0c: mov             x3, x2
    // 0xcd6e10: ldr             x2, [fp, #0x18]
    // 0xcd6e14: cmp             w2, NULL
    // 0xcd6e18: b.ne            #0xcd6e24
    // 0xcd6e1c: r4 = Null
    //     0xcd6e1c: mov             x4, NULL
    // 0xcd6e20: b               #0xcd6e2c
    // 0xcd6e24: LoadField: r4 = r2->field_b
    //     0xcd6e24: ldur            w4, [x2, #0xb]
    // 0xcd6e28: DecompressPointer r4
    //     0xcd6e28: add             x4, x4, HEAP, lsl #32
    // 0xcd6e2c: ldr             d0, [fp, #0x10]
    // 0xcd6e30: stp             x4, x3, [SP, #-0x10]!
    // 0xcd6e34: SaveReg d0
    //     0xcd6e34: str             d0, [SP, #-8]!
    // 0xcd6e38: r0 = lerp()
    //     0xcd6e38: bl              #0xcd5618  ; [package:flutter/src/painting/gradient.dart] Gradient::lerp
    // 0xcd6e3c: add             SP, SP, #0x18
    // 0xcd6e40: ldr             d0, [fp, #0x10]
    // 0xcd6e44: d1 = 0.500000
    //     0xcd6e44: fmov            d1, #0.50000000
    // 0xcd6e48: stur            x0, [fp, #-0x18]
    // 0xcd6e4c: fcmp            d0, d1
    // 0xcd6e50: b.vs            #0xcd6e78
    // 0xcd6e54: b.ge            #0xcd6e78
    // 0xcd6e58: ldr             x1, [fp, #0x20]
    // 0xcd6e5c: cmp             w1, NULL
    // 0xcd6e60: b.eq            #0xcd6fa8
    // 0xcd6e64: LoadField: r2 = r1->field_f
    //     0xcd6e64: ldur            w2, [x1, #0xf]
    // 0xcd6e68: DecompressPointer r2
    //     0xcd6e68: add             x2, x2, HEAP, lsl #32
    // 0xcd6e6c: mov             x3, x2
    // 0xcd6e70: ldr             x2, [fp, #0x18]
    // 0xcd6e74: b               #0xcd6e90
    // 0xcd6e78: ldr             x1, [fp, #0x20]
    // 0xcd6e7c: ldr             x2, [fp, #0x18]
    // 0xcd6e80: cmp             w2, NULL
    // 0xcd6e84: b.eq            #0xcd6fac
    // 0xcd6e88: LoadField: r3 = r2->field_f
    //     0xcd6e88: ldur            w3, [x2, #0xf]
    // 0xcd6e8c: DecompressPointer r3
    //     0xcd6e8c: add             x3, x3, HEAP, lsl #32
    // 0xcd6e90: stur            x3, [fp, #-0x10]
    // 0xcd6e94: cmp             w1, NULL
    // 0xcd6e98: b.ne            #0xcd6ea4
    // 0xcd6e9c: r4 = Null
    //     0xcd6e9c: mov             x4, NULL
    // 0xcd6ea0: b               #0xcd6eac
    // 0xcd6ea4: LoadField: r4 = r1->field_13
    //     0xcd6ea4: ldur            w4, [x1, #0x13]
    // 0xcd6ea8: DecompressPointer r4
    //     0xcd6ea8: add             x4, x4, HEAP, lsl #32
    // 0xcd6eac: cmp             w2, NULL
    // 0xcd6eb0: b.ne            #0xcd6ebc
    // 0xcd6eb4: r5 = Null
    //     0xcd6eb4: mov             x5, NULL
    // 0xcd6eb8: b               #0xcd6ec4
    // 0xcd6ebc: LoadField: r5 = r2->field_13
    //     0xcd6ebc: ldur            w5, [x2, #0x13]
    // 0xcd6ec0: DecompressPointer r5
    //     0xcd6ec0: add             x5, x5, HEAP, lsl #32
    // 0xcd6ec4: stp             x5, x4, [SP, #-0x10]!
    // 0xcd6ec8: SaveReg d0
    //     0xcd6ec8: str             d0, [SP, #-8]!
    // 0xcd6ecc: r0 = lerpList()
    //     0xcd6ecc: bl              #0xcd60ec  ; [package:flutter/src/painting/box_shadow.dart] BoxShadow::lerpList
    // 0xcd6ed0: add             SP, SP, #0x18
    // 0xcd6ed4: mov             x1, x0
    // 0xcd6ed8: ldr             x0, [fp, #0x20]
    // 0xcd6edc: stur            x1, [fp, #-0x20]
    // 0xcd6ee0: cmp             w0, NULL
    // 0xcd6ee4: b.ne            #0xcd6ef0
    // 0xcd6ee8: r2 = Null
    //     0xcd6ee8: mov             x2, NULL
    // 0xcd6eec: b               #0xcd6ef8
    // 0xcd6ef0: LoadField: r2 = r0->field_17
    //     0xcd6ef0: ldur            w2, [x0, #0x17]
    // 0xcd6ef4: DecompressPointer r2
    //     0xcd6ef4: add             x2, x2, HEAP, lsl #32
    // 0xcd6ef8: ldr             x0, [fp, #0x18]
    // 0xcd6efc: cmp             w0, NULL
    // 0xcd6f00: b.ne            #0xcd6f0c
    // 0xcd6f04: r5 = Null
    //     0xcd6f04: mov             x5, NULL
    // 0xcd6f08: b               #0xcd6f18
    // 0xcd6f0c: LoadField: r3 = r0->field_17
    //     0xcd6f0c: ldur            w3, [x0, #0x17]
    // 0xcd6f10: DecompressPointer r3
    //     0xcd6f10: add             x3, x3, HEAP, lsl #32
    // 0xcd6f14: mov             x5, x3
    // 0xcd6f18: ldr             d0, [fp, #0x10]
    // 0xcd6f1c: ldur            x4, [fp, #-8]
    // 0xcd6f20: ldur            x0, [fp, #-0x18]
    // 0xcd6f24: ldur            x3, [fp, #-0x10]
    // 0xcd6f28: stp             x5, x2, [SP, #-0x10]!
    // 0xcd6f2c: SaveReg d0
    //     0xcd6f2c: str             d0, [SP, #-8]!
    // 0xcd6f30: r0 = lerp()
    //     0xcd6f30: bl              #0xbecbbc  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0xcd6f34: add             SP, SP, #0x18
    // 0xcd6f38: stur            x0, [fp, #-0x28]
    // 0xcd6f3c: cmp             w0, NULL
    // 0xcd6f40: b.eq            #0xcd6fb0
    // 0xcd6f44: r0 = ShapeDecoration()
    //     0xcd6f44: bl              #0x85318c  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0xcd6f48: ldur            x1, [fp, #-8]
    // 0xcd6f4c: StoreField: r0->field_7 = r1
    //     0xcd6f4c: stur            w1, [x0, #7]
    // 0xcd6f50: ldur            x1, [fp, #-0x10]
    // 0xcd6f54: StoreField: r0->field_f = r1
    //     0xcd6f54: stur            w1, [x0, #0xf]
    // 0xcd6f58: ldur            x1, [fp, #-0x18]
    // 0xcd6f5c: StoreField: r0->field_b = r1
    //     0xcd6f5c: stur            w1, [x0, #0xb]
    // 0xcd6f60: ldur            x1, [fp, #-0x20]
    // 0xcd6f64: StoreField: r0->field_13 = r1
    //     0xcd6f64: stur            w1, [x0, #0x13]
    // 0xcd6f68: ldur            x1, [fp, #-0x28]
    // 0xcd6f6c: StoreField: r0->field_17 = r1
    //     0xcd6f6c: stur            w1, [x0, #0x17]
    // 0xcd6f70: LeaveFrame
    //     0xcd6f70: mov             SP, fp
    //     0xcd6f74: ldp             fp, lr, [SP], #0x10
    // 0xcd6f78: ret
    //     0xcd6f78: ret             
    // 0xcd6f7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd6f7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd6f80: b               #0xcd6cf8
    // 0xcd6f84: SaveReg d1
    //     0xcd6f84: str             q1, [SP, #-0x10]!
    // 0xcd6f88: stp             x2, x3, [SP, #-0x10]!
    // 0xcd6f8c: stp             x0, x1, [SP, #-0x10]!
    // 0xcd6f90: r0 = AllocateDouble()
    //     0xcd6f90: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcd6f94: mov             x4, x0
    // 0xcd6f98: ldp             x0, x1, [SP], #0x10
    // 0xcd6f9c: ldp             x2, x3, [SP], #0x10
    // 0xcd6fa0: RestoreReg d1
    //     0xcd6fa0: ldr             q1, [SP], #0x10
    // 0xcd6fa4: b               #0xcd6dd4
    // 0xcd6fa8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xcd6fa8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xcd6fac: r0 = NullCastErrorSharedWithFPURegs()
    //     0xcd6fac: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xcd6fb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd6fb0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  factory _ ShapeDecoration.fromBoxDecoration(/* No info */) {
    // ** addr: 0xcd6fb4, size: 0x15c
    // 0xcd6fb4: EnterFrame
    //     0xcd6fb4: stp             fp, lr, [SP, #-0x10]!
    //     0xcd6fb8: mov             fp, SP
    // 0xcd6fbc: AllocStack(0x28)
    //     0xcd6fbc: sub             SP, SP, #0x28
    // 0xcd6fc0: ldr             x0, [fp, #0x10]
    // 0xcd6fc4: LoadField: r1 = r0->field_23
    //     0xcd6fc4: ldur            w1, [x0, #0x23]
    // 0xcd6fc8: DecompressPointer r1
    //     0xcd6fc8: add             x1, x1, HEAP, lsl #32
    // 0xcd6fcc: LoadField: r2 = r1->field_7
    //     0xcd6fcc: ldur            x2, [x1, #7]
    // 0xcd6fd0: cmp             x2, #0
    // 0xcd6fd4: b.gt            #0xcd7060
    // 0xcd6fd8: LoadField: r1 = r0->field_13
    //     0xcd6fd8: ldur            w1, [x0, #0x13]
    // 0xcd6fdc: DecompressPointer r1
    //     0xcd6fdc: add             x1, x1, HEAP, lsl #32
    // 0xcd6fe0: stur            x1, [fp, #-0x10]
    // 0xcd6fe4: cmp             w1, NULL
    // 0xcd6fe8: b.eq            #0xcd7044
    // 0xcd6fec: LoadField: r2 = r0->field_f
    //     0xcd6fec: ldur            w2, [x0, #0xf]
    // 0xcd6ff0: DecompressPointer r2
    //     0xcd6ff0: add             x2, x2, HEAP, lsl #32
    // 0xcd6ff4: cmp             w2, NULL
    // 0xcd6ff8: b.ne            #0xcd7004
    // 0xcd6ffc: r2 = Null
    //     0xcd6ffc: mov             x2, NULL
    // 0xcd7000: b               #0xcd7010
    // 0xcd7004: LoadField: r3 = r2->field_7
    //     0xcd7004: ldur            w3, [x2, #7]
    // 0xcd7008: DecompressPointer r3
    //     0xcd7008: add             x3, x3, HEAP, lsl #32
    // 0xcd700c: mov             x2, x3
    // 0xcd7010: cmp             w2, NULL
    // 0xcd7014: b.ne            #0xcd7020
    // 0xcd7018: r2 = Instance_BorderSide
    //     0xcd7018: add             x2, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xcd701c: ldr             x2, [x2, #0x2f0]
    // 0xcd7020: stur            x2, [fp, #-8]
    // 0xcd7024: r0 = RoundedRectangleBorder()
    //     0xcd7024: bl              #0x70e8f4  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0xcd7028: mov             x1, x0
    // 0xcd702c: ldur            x0, [fp, #-0x10]
    // 0xcd7030: StoreField: r1->field_b = r0
    //     0xcd7030: stur            w0, [x1, #0xb]
    // 0xcd7034: ldur            x0, [fp, #-8]
    // 0xcd7038: StoreField: r1->field_7 = r0
    //     0xcd7038: stur            w0, [x1, #7]
    // 0xcd703c: ldr             x0, [fp, #0x10]
    // 0xcd7040: b               #0xcd70a4
    // 0xcd7044: LoadField: r1 = r0->field_f
    //     0xcd7044: ldur            w1, [x0, #0xf]
    // 0xcd7048: DecompressPointer r1
    //     0xcd7048: add             x1, x1, HEAP, lsl #32
    // 0xcd704c: cmp             w1, NULL
    // 0xcd7050: b.ne            #0xcd70a4
    // 0xcd7054: r1 = Instance_Border
    //     0xcd7054: add             x1, PP, #0x50, lsl #12  ; [pp+0x503a0] Obj!Border@b38531
    //     0xcd7058: ldr             x1, [x1, #0x3a0]
    // 0xcd705c: b               #0xcd70a4
    // 0xcd7060: LoadField: r1 = r0->field_f
    //     0xcd7060: ldur            w1, [x0, #0xf]
    // 0xcd7064: DecompressPointer r1
    //     0xcd7064: add             x1, x1, HEAP, lsl #32
    // 0xcd7068: cmp             w1, NULL
    // 0xcd706c: b.eq            #0xcd7094
    // 0xcd7070: LoadField: r2 = r1->field_7
    //     0xcd7070: ldur            w2, [x1, #7]
    // 0xcd7074: DecompressPointer r2
    //     0xcd7074: add             x2, x2, HEAP, lsl #32
    // 0xcd7078: stur            x2, [fp, #-8]
    // 0xcd707c: r0 = CircleBorder()
    //     0xcd707c: bl              #0x70e75c  ; AllocateCircleBorderStub -> CircleBorder (size=0x14)
    // 0xcd7080: d0 = 0.000000
    //     0xcd7080: eor             v0.16b, v0.16b, v0.16b
    // 0xcd7084: StoreField: r0->field_b = d0
    //     0xcd7084: stur            d0, [x0, #0xb]
    // 0xcd7088: ldur            x1, [fp, #-8]
    // 0xcd708c: StoreField: r0->field_7 = r1
    //     0xcd708c: stur            w1, [x0, #7]
    // 0xcd7090: b               #0xcd709c
    // 0xcd7094: r0 = Instance_CircleBorder
    //     0xcd7094: add             x0, PP, #0xe, lsl #12  ; [pp+0xe358] Obj!CircleBorder@b38441
    //     0xcd7098: ldr             x0, [x0, #0x358]
    // 0xcd709c: mov             x1, x0
    // 0xcd70a0: ldr             x0, [fp, #0x10]
    // 0xcd70a4: stur            x1, [fp, #-0x28]
    // 0xcd70a8: LoadField: r2 = r0->field_7
    //     0xcd70a8: ldur            w2, [x0, #7]
    // 0xcd70ac: DecompressPointer r2
    //     0xcd70ac: add             x2, x2, HEAP, lsl #32
    // 0xcd70b0: stur            x2, [fp, #-0x20]
    // 0xcd70b4: LoadField: r3 = r0->field_b
    //     0xcd70b4: ldur            w3, [x0, #0xb]
    // 0xcd70b8: DecompressPointer r3
    //     0xcd70b8: add             x3, x3, HEAP, lsl #32
    // 0xcd70bc: stur            x3, [fp, #-0x18]
    // 0xcd70c0: LoadField: r4 = r0->field_1b
    //     0xcd70c0: ldur            w4, [x0, #0x1b]
    // 0xcd70c4: DecompressPointer r4
    //     0xcd70c4: add             x4, x4, HEAP, lsl #32
    // 0xcd70c8: stur            x4, [fp, #-0x10]
    // 0xcd70cc: LoadField: r5 = r0->field_17
    //     0xcd70cc: ldur            w5, [x0, #0x17]
    // 0xcd70d0: DecompressPointer r5
    //     0xcd70d0: add             x5, x5, HEAP, lsl #32
    // 0xcd70d4: stur            x5, [fp, #-8]
    // 0xcd70d8: r0 = ShapeDecoration()
    //     0xcd70d8: bl              #0x85318c  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0xcd70dc: ldur            x1, [fp, #-0x20]
    // 0xcd70e0: StoreField: r0->field_7 = r1
    //     0xcd70e0: stur            w1, [x0, #7]
    // 0xcd70e4: ldur            x1, [fp, #-0x18]
    // 0xcd70e8: StoreField: r0->field_f = r1
    //     0xcd70e8: stur            w1, [x0, #0xf]
    // 0xcd70ec: ldur            x1, [fp, #-0x10]
    // 0xcd70f0: StoreField: r0->field_b = r1
    //     0xcd70f0: stur            w1, [x0, #0xb]
    // 0xcd70f4: ldur            x1, [fp, #-8]
    // 0xcd70f8: StoreField: r0->field_13 = r1
    //     0xcd70f8: stur            w1, [x0, #0x13]
    // 0xcd70fc: ldur            x1, [fp, #-0x28]
    // 0xcd7100: StoreField: r0->field_17 = r1
    //     0xcd7100: stur            w1, [x0, #0x17]
    // 0xcd7104: LeaveFrame
    //     0xcd7104: mov             SP, fp
    //     0xcd7108: ldp             fp, lr, [SP], #0x10
    // 0xcd710c: ret
    //     0xcd710c: ret             
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0xcd7360, size: 0xbc
    // 0xcd7360: EnterFrame
    //     0xcd7360: stp             fp, lr, [SP, #-0x10]!
    //     0xcd7364: mov             fp, SP
    // 0xcd7368: CheckStackOverflow
    //     0xcd7368: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd736c: cmp             SP, x16
    //     0xcd7370: b.ls            #0xcd7414
    // 0xcd7374: ldr             x0, [fp, #0x18]
    // 0xcd7378: r1 = LoadClassIdInstr(r0)
    //     0xcd7378: ldur            x1, [x0, #-1]
    //     0xcd737c: ubfx            x1, x1, #0xc, #0x14
    // 0xcd7380: lsl             x1, x1, #1
    // 0xcd7384: r17 = 5874
    //     0xcd7384: mov             x17, #0x16f2
    // 0xcd7388: cmp             w1, w17
    // 0xcd738c: b.ne            #0xcd73c4
    // 0xcd7390: ldr             d0, [fp, #0x10]
    // 0xcd7394: stp             x0, NULL, [SP, #-0x10]!
    // 0xcd7398: r0 = ShapeDecoration.fromBoxDecoration()
    //     0xcd7398: bl              #0xcd6fb4  ; [package:flutter/src/painting/shape_decoration.dart] ShapeDecoration::ShapeDecoration.fromBoxDecoration
    // 0xcd739c: add             SP, SP, #0x10
    // 0xcd73a0: ldr             x16, [fp, #0x20]
    // 0xcd73a4: stp             x16, x0, [SP, #-0x10]!
    // 0xcd73a8: ldr             d0, [fp, #0x10]
    // 0xcd73ac: SaveReg d0
    //     0xcd73ac: str             d0, [SP, #-8]!
    // 0xcd73b0: r0 = lerp()
    //     0xcd73b0: bl              #0xcd6ce0  ; [package:flutter/src/painting/shape_decoration.dart] ShapeDecoration::lerp
    // 0xcd73b4: add             SP, SP, #0x18
    // 0xcd73b8: LeaveFrame
    //     0xcd73b8: mov             SP, fp
    //     0xcd73bc: ldp             fp, lr, [SP], #0x10
    // 0xcd73c0: ret
    //     0xcd73c0: ret             
    // 0xcd73c4: ldr             d0, [fp, #0x10]
    // 0xcd73c8: cmp             w0, NULL
    // 0xcd73cc: b.eq            #0xcd73e4
    // 0xcd73d0: r2 = LoadInt32Instr(r1)
    //     0xcd73d0: sbfx            x2, x1, #1, #0x1f
    // 0xcd73d4: cmp             x2, #0xb77
    // 0xcd73d8: b.lt            #0xcd7404
    // 0xcd73dc: cmp             x2, #0xb78
    // 0xcd73e0: b.gt            #0xcd7404
    // 0xcd73e4: ldr             x16, [fp, #0x20]
    // 0xcd73e8: stp             x16, x0, [SP, #-0x10]!
    // 0xcd73ec: SaveReg d0
    //     0xcd73ec: str             d0, [SP, #-8]!
    // 0xcd73f0: r0 = lerp()
    //     0xcd73f0: bl              #0xcd6ce0  ; [package:flutter/src/painting/shape_decoration.dart] ShapeDecoration::lerp
    // 0xcd73f4: add             SP, SP, #0x18
    // 0xcd73f8: LeaveFrame
    //     0xcd73f8: mov             SP, fp
    //     0xcd73fc: ldp             fp, lr, [SP], #0x10
    // 0xcd7400: ret
    //     0xcd7400: ret             
    // 0xcd7404: r0 = Null
    //     0xcd7404: mov             x0, NULL
    // 0xcd7408: LeaveFrame
    //     0xcd7408: mov             SP, fp
    //     0xcd740c: ldp             fp, lr, [SP], #0x10
    // 0xcd7410: ret
    //     0xcd7410: ret             
    // 0xcd7414: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd7414: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd7418: b               #0xcd7374
  }
}

// class id: 4509, size: 0x38, field offset: 0xc
class _ShapeDecorationPainter extends BoxPainter {

  late List<Rect> _shadowBounds; // offset: 0x28
  late List<Paint> _shadowPaints; // offset: 0x30

  _ paint(/* No info */) {
    // ** addr: 0xc71fa4, size: 0x12c
    // 0xc71fa4: EnterFrame
    //     0xc71fa4: stp             fp, lr, [SP, #-0x10]!
    //     0xc71fa8: mov             fp, SP
    // 0xc71fac: AllocStack(0x10)
    //     0xc71fac: sub             SP, SP, #0x10
    // 0xc71fb0: CheckStackOverflow
    //     0xc71fb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc71fb4: cmp             SP, x16
    //     0xc71fb8: b.ls            #0xc720c4
    // 0xc71fbc: ldr             x0, [fp, #0x10]
    // 0xc71fc0: LoadField: r1 = r0->field_17
    //     0xc71fc0: ldur            w1, [x0, #0x17]
    // 0xc71fc4: DecompressPointer r1
    //     0xc71fc4: add             x1, x1, HEAP, lsl #32
    // 0xc71fc8: cmp             w1, NULL
    // 0xc71fcc: b.eq            #0xc720cc
    // 0xc71fd0: ldr             x16, [fp, #0x18]
    // 0xc71fd4: stp             x1, x16, [SP, #-0x10]!
    // 0xc71fd8: r0 = &()
    //     0xc71fd8: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0xc71fdc: add             SP, SP, #0x10
    // 0xc71fe0: mov             x1, x0
    // 0xc71fe4: ldr             x0, [fp, #0x10]
    // 0xc71fe8: stur            x1, [fp, #-0x10]
    // 0xc71fec: LoadField: r2 = r0->field_13
    //     0xc71fec: ldur            w2, [x0, #0x13]
    // 0xc71ff0: DecompressPointer r2
    //     0xc71ff0: add             x2, x2, HEAP, lsl #32
    // 0xc71ff4: stur            x2, [fp, #-8]
    // 0xc71ff8: ldr             x16, [fp, #0x28]
    // 0xc71ffc: stp             x1, x16, [SP, #-0x10]!
    // 0xc72000: SaveReg r2
    //     0xc72000: str             x2, [SP, #-8]!
    // 0xc72004: r0 = _precache()
    //     0xc72004: bl              #0xc7243c  ; [package:flutter/src/painting/shape_decoration.dart] _ShapeDecorationPainter::_precache
    // 0xc72008: add             SP, SP, #0x18
    // 0xc7200c: ldr             x16, [fp, #0x28]
    // 0xc72010: ldr             lr, [fp, #0x20]
    // 0xc72014: stp             lr, x16, [SP, #-0x10]!
    // 0xc72018: ldur            x16, [fp, #-8]
    // 0xc7201c: SaveReg r16
    //     0xc7201c: str             x16, [SP, #-8]!
    // 0xc72020: r0 = _paintShadows()
    //     0xc72020: bl              #0xc72290  ; [package:flutter/src/painting/shape_decoration.dart] _ShapeDecorationPainter::_paintShadows
    // 0xc72024: add             SP, SP, #0x18
    // 0xc72028: ldr             x16, [fp, #0x28]
    // 0xc7202c: ldr             lr, [fp, #0x20]
    // 0xc72030: stp             lr, x16, [SP, #-0x10]!
    // 0xc72034: ldur            x16, [fp, #-0x10]
    // 0xc72038: ldur            lr, [fp, #-8]
    // 0xc7203c: stp             lr, x16, [SP, #-0x10]!
    // 0xc72040: r0 = _paintInterior()
    //     0xc72040: bl              #0xc721c4  ; [package:flutter/src/painting/shape_decoration.dart] _ShapeDecorationPainter::_paintInterior
    // 0xc72044: add             SP, SP, #0x20
    // 0xc72048: ldr             x16, [fp, #0x28]
    // 0xc7204c: ldr             lr, [fp, #0x20]
    // 0xc72050: stp             lr, x16, [SP, #-0x10]!
    // 0xc72054: ldr             x16, [fp, #0x10]
    // 0xc72058: SaveReg r16
    //     0xc72058: str             x16, [SP, #-8]!
    // 0xc7205c: r0 = _paintImage()
    //     0xc7205c: bl              #0xc720d0  ; [package:flutter/src/painting/shape_decoration.dart] _ShapeDecorationPainter::_paintImage
    // 0xc72060: add             SP, SP, #0x18
    // 0xc72064: ldr             x0, [fp, #0x28]
    // 0xc72068: LoadField: r1 = r0->field_b
    //     0xc72068: ldur            w1, [x0, #0xb]
    // 0xc7206c: DecompressPointer r1
    //     0xc7206c: add             x1, x1, HEAP, lsl #32
    // 0xc72070: LoadField: r0 = r1->field_17
    //     0xc72070: ldur            w0, [x1, #0x17]
    // 0xc72074: DecompressPointer r0
    //     0xc72074: add             x0, x0, HEAP, lsl #32
    // 0xc72078: r1 = LoadClassIdInstr(r0)
    //     0xc72078: ldur            x1, [x0, #-1]
    //     0xc7207c: ubfx            x1, x1, #0xc, #0x14
    // 0xc72080: ldr             x16, [fp, #0x20]
    // 0xc72084: stp             x16, x0, [SP, #-0x10]!
    // 0xc72088: ldur            x16, [fp, #-0x10]
    // 0xc7208c: ldur            lr, [fp, #-8]
    // 0xc72090: stp             lr, x16, [SP, #-0x10]!
    // 0xc72094: mov             x0, x1
    // 0xc72098: r4 = const [0, 0x4, 0x4, 0x3, textDirection, 0x3, null]
    //     0xc72098: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e1e0] List(7) [0, 0x4, 0x4, 0x3, "textDirection", 0x3, Null]
    //     0xc7209c: ldr             x4, [x4, #0x1e0]
    // 0xc720a0: r0 = GDT[cid_x0 + 0x1abc]()
    //     0xc720a0: mov             x17, #0x1abc
    //     0xc720a4: add             lr, x0, x17
    //     0xc720a8: ldr             lr, [x21, lr, lsl #3]
    //     0xc720ac: blr             lr
    // 0xc720b0: add             SP, SP, #0x20
    // 0xc720b4: r0 = Null
    //     0xc720b4: mov             x0, NULL
    // 0xc720b8: LeaveFrame
    //     0xc720b8: mov             SP, fp
    //     0xc720bc: ldp             fp, lr, [SP], #0x10
    // 0xc720c0: ret
    //     0xc720c0: ret             
    // 0xc720c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc720c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc720c8: b               #0xc71fbc
    // 0xc720cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc720cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _paintImage(/* No info */) {
    // ** addr: 0xc720d0, size: 0xf4
    // 0xc720d0: EnterFrame
    //     0xc720d0: stp             fp, lr, [SP, #-0x10]!
    //     0xc720d4: mov             fp, SP
    // 0xc720d8: CheckStackOverflow
    //     0xc720d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc720dc: cmp             SP, x16
    //     0xc720e0: b.ls            #0xc721b4
    // 0xc720e4: ldr             x0, [fp, #0x20]
    // 0xc720e8: LoadField: r1 = r0->field_b
    //     0xc720e8: ldur            w1, [x0, #0xb]
    // 0xc720ec: DecompressPointer r1
    //     0xc720ec: add             x1, x1, HEAP, lsl #32
    // 0xc720f0: LoadField: r2 = r1->field_f
    //     0xc720f0: ldur            w2, [x1, #0xf]
    // 0xc720f4: DecompressPointer r2
    //     0xc720f4: add             x2, x2, HEAP, lsl #32
    // 0xc720f8: cmp             w2, NULL
    // 0xc720fc: b.ne            #0xc72110
    // 0xc72100: r0 = Null
    //     0xc72100: mov             x0, NULL
    // 0xc72104: LeaveFrame
    //     0xc72104: mov             SP, fp
    //     0xc72108: ldp             fp, lr, [SP], #0x10
    // 0xc7210c: ret
    //     0xc7210c: ret             
    // 0xc72110: LoadField: r1 = r0->field_33
    //     0xc72110: ldur            w1, [x0, #0x33]
    // 0xc72114: DecompressPointer r1
    //     0xc72114: add             x1, x1, HEAP, lsl #32
    // 0xc72118: cmp             w1, NULL
    // 0xc7211c: b.ne            #0xc72168
    // 0xc72120: LoadField: r1 = r0->field_7
    //     0xc72120: ldur            w1, [x0, #7]
    // 0xc72124: DecompressPointer r1
    //     0xc72124: add             x1, x1, HEAP, lsl #32
    // 0xc72128: cmp             w1, NULL
    // 0xc7212c: b.eq            #0xc721bc
    // 0xc72130: stp             x1, x2, [SP, #-0x10]!
    // 0xc72134: r0 = createPainter()
    //     0xc72134: bl              #0xc7151c  ; [package:flutter/src/painting/decoration_image.dart] DecorationImage::createPainter
    // 0xc72138: add             SP, SP, #0x10
    // 0xc7213c: mov             x1, x0
    // 0xc72140: ldr             x2, [fp, #0x20]
    // 0xc72144: StoreField: r2->field_33 = r0
    //     0xc72144: stur            w0, [x2, #0x33]
    //     0xc72148: ldurb           w16, [x2, #-1]
    //     0xc7214c: ldurb           w17, [x0, #-1]
    //     0xc72150: and             x16, x17, x16, lsr #2
    //     0xc72154: tst             x16, HEAP, lsr #32
    //     0xc72158: b.eq            #0xc72160
    //     0xc7215c: bl              #0xd6828c
    // 0xc72160: mov             x0, x1
    // 0xc72164: b               #0xc72170
    // 0xc72168: mov             x2, x0
    // 0xc7216c: mov             x0, x1
    // 0xc72170: LoadField: r1 = r2->field_f
    //     0xc72170: ldur            w1, [x2, #0xf]
    // 0xc72174: DecompressPointer r1
    //     0xc72174: add             x1, x1, HEAP, lsl #32
    // 0xc72178: cmp             w1, NULL
    // 0xc7217c: b.eq            #0xc721c0
    // 0xc72180: LoadField: r3 = r2->field_1b
    //     0xc72180: ldur            w3, [x2, #0x1b]
    // 0xc72184: DecompressPointer r3
    //     0xc72184: add             x3, x3, HEAP, lsl #32
    // 0xc72188: ldr             x16, [fp, #0x18]
    // 0xc7218c: stp             x16, x0, [SP, #-0x10]!
    // 0xc72190: stp             x3, x1, [SP, #-0x10]!
    // 0xc72194: ldr             x16, [fp, #0x10]
    // 0xc72198: SaveReg r16
    //     0xc72198: str             x16, [SP, #-8]!
    // 0xc7219c: r0 = paint()
    //     0xc7219c: bl              #0xc710b4  ; [package:flutter/src/painting/decoration_image.dart] DecorationImagePainter::paint
    // 0xc721a0: add             SP, SP, #0x28
    // 0xc721a4: r0 = Null
    //     0xc721a4: mov             x0, NULL
    // 0xc721a8: LeaveFrame
    //     0xc721a8: mov             SP, fp
    //     0xc721ac: ldp             fp, lr, [SP], #0x10
    // 0xc721b0: ret
    //     0xc721b0: ret             
    // 0xc721b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc721b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc721b8: b               #0xc720e4
    // 0xc721bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc721bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc721c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc721c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _paintInterior(/* No info */) {
    // ** addr: 0xc721c4, size: 0xcc
    // 0xc721c4: EnterFrame
    //     0xc721c4: stp             fp, lr, [SP, #-0x10]!
    //     0xc721c8: mov             fp, SP
    // 0xc721cc: AllocStack(0x8)
    //     0xc721cc: sub             SP, SP, #8
    // 0xc721d0: CheckStackOverflow
    //     0xc721d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc721d4: cmp             SP, x16
    //     0xc721d8: b.ls            #0xc72284
    // 0xc721dc: ldr             x1, [fp, #0x28]
    // 0xc721e0: LoadField: r0 = r1->field_1f
    //     0xc721e0: ldur            w0, [x1, #0x1f]
    // 0xc721e4: DecompressPointer r0
    //     0xc721e4: add             x0, x0, HEAP, lsl #32
    // 0xc721e8: cmp             w0, NULL
    // 0xc721ec: b.eq            #0xc72274
    // 0xc721f0: LoadField: r0 = r1->field_b
    //     0xc721f0: ldur            w0, [x1, #0xb]
    // 0xc721f4: DecompressPointer r0
    //     0xc721f4: add             x0, x0, HEAP, lsl #32
    // 0xc721f8: LoadField: r2 = r0->field_17
    //     0xc721f8: ldur            w2, [x0, #0x17]
    // 0xc721fc: DecompressPointer r2
    //     0xc721fc: add             x2, x2, HEAP, lsl #32
    // 0xc72200: stur            x2, [fp, #-8]
    // 0xc72204: r0 = LoadClassIdInstr(r2)
    //     0xc72204: ldur            x0, [x2, #-1]
    //     0xc72208: ubfx            x0, x0, #0xc, #0x14
    // 0xc7220c: SaveReg r2
    //     0xc7220c: str             x2, [SP, #-8]!
    // 0xc72210: r0 = GDT[cid_x0 + 0xc0cf]()
    //     0xc72210: mov             x17, #0xc0cf
    //     0xc72214: add             lr, x0, x17
    //     0xc72218: ldr             lr, [x21, lr, lsl #3]
    //     0xc7221c: blr             lr
    // 0xc72220: add             SP, SP, #8
    // 0xc72224: ldr             x0, [fp, #0x28]
    // 0xc72228: LoadField: r1 = r0->field_1f
    //     0xc72228: ldur            w1, [x0, #0x1f]
    // 0xc7222c: DecompressPointer r1
    //     0xc7222c: add             x1, x1, HEAP, lsl #32
    // 0xc72230: cmp             w1, NULL
    // 0xc72234: b.eq            #0xc7228c
    // 0xc72238: ldur            x0, [fp, #-8]
    // 0xc7223c: r2 = LoadClassIdInstr(r0)
    //     0xc7223c: ldur            x2, [x0, #-1]
    //     0xc72240: ubfx            x2, x2, #0xc, #0x14
    // 0xc72244: ldr             x16, [fp, #0x20]
    // 0xc72248: stp             x16, x0, [SP, #-0x10]!
    // 0xc7224c: ldr             x16, [fp, #0x18]
    // 0xc72250: stp             x1, x16, [SP, #-0x10]!
    // 0xc72254: ldr             x16, [fp, #0x10]
    // 0xc72258: SaveReg r16
    //     0xc72258: str             x16, [SP, #-8]!
    // 0xc7225c: mov             x0, x2
    // 0xc72260: r0 = GDT[cid_x0 + 0xc2da]()
    //     0xc72260: mov             x17, #0xc2da
    //     0xc72264: add             lr, x0, x17
    //     0xc72268: ldr             lr, [x21, lr, lsl #3]
    //     0xc7226c: blr             lr
    // 0xc72270: add             SP, SP, #0x28
    // 0xc72274: r0 = Null
    //     0xc72274: mov             x0, NULL
    // 0xc72278: LeaveFrame
    //     0xc72278: mov             SP, fp
    //     0xc7227c: ldp             fp, lr, [SP], #0x10
    // 0xc72280: ret
    //     0xc72280: ret             
    // 0xc72284: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc72284: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc72288: b               #0xc721dc
    // 0xc7228c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc7228c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _paintShadows(/* No info */) {
    // ** addr: 0xc72290, size: 0x1ac
    // 0xc72290: EnterFrame
    //     0xc72290: stp             fp, lr, [SP, #-0x10]!
    //     0xc72294: mov             fp, SP
    // 0xc72298: AllocStack(0x20)
    //     0xc72298: sub             SP, SP, #0x20
    // 0xc7229c: CheckStackOverflow
    //     0xc7229c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc722a0: cmp             SP, x16
    //     0xc722a4: b.ls            #0xc72410
    // 0xc722a8: ldr             x1, [fp, #0x20]
    // 0xc722ac: LoadField: r0 = r1->field_23
    //     0xc722ac: ldur            w0, [x1, #0x23]
    // 0xc722b0: DecompressPointer r0
    //     0xc722b0: add             x0, x0, HEAP, lsl #32
    // 0xc722b4: cmp             w0, NULL
    // 0xc722b8: b.eq            #0xc72400
    // 0xc722bc: LoadField: r0 = r1->field_b
    //     0xc722bc: ldur            w0, [x1, #0xb]
    // 0xc722c0: DecompressPointer r0
    //     0xc722c0: add             x0, x0, HEAP, lsl #32
    // 0xc722c4: LoadField: r2 = r0->field_17
    //     0xc722c4: ldur            w2, [x0, #0x17]
    // 0xc722c8: DecompressPointer r2
    //     0xc722c8: add             x2, x2, HEAP, lsl #32
    // 0xc722cc: stur            x2, [fp, #-8]
    // 0xc722d0: r0 = LoadClassIdInstr(r2)
    //     0xc722d0: ldur            x0, [x2, #-1]
    //     0xc722d4: ubfx            x0, x0, #0xc, #0x14
    // 0xc722d8: SaveReg r2
    //     0xc722d8: str             x2, [SP, #-8]!
    // 0xc722dc: r0 = GDT[cid_x0 + 0xc0cf]()
    //     0xc722dc: mov             x17, #0xc0cf
    //     0xc722e0: add             lr, x0, x17
    //     0xc722e4: ldr             lr, [x21, lr, lsl #3]
    //     0xc722e8: blr             lr
    // 0xc722ec: add             SP, SP, #8
    // 0xc722f0: r4 = 0
    //     0xc722f0: mov             x4, #0
    // 0xc722f4: ldr             x2, [fp, #0x20]
    // 0xc722f8: ldur            x3, [fp, #-8]
    // 0xc722fc: stur            x4, [fp, #-0x18]
    // 0xc72300: CheckStackOverflow
    //     0xc72300: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc72304: cmp             SP, x16
    //     0xc72308: b.ls            #0xc72418
    // 0xc7230c: LoadField: r0 = r2->field_23
    //     0xc7230c: ldur            w0, [x2, #0x23]
    // 0xc72310: DecompressPointer r0
    //     0xc72310: add             x0, x0, HEAP, lsl #32
    // 0xc72314: cmp             w0, NULL
    // 0xc72318: b.eq            #0xc72420
    // 0xc7231c: r1 = LoadInt32Instr(r0)
    //     0xc7231c: sbfx            x1, x0, #1, #0x1f
    // 0xc72320: cmp             x4, x1
    // 0xc72324: b.ge            #0xc72400
    // 0xc72328: LoadField: r5 = r2->field_27
    //     0xc72328: ldur            w5, [x2, #0x27]
    // 0xc7232c: DecompressPointer r5
    //     0xc7232c: add             x5, x5, HEAP, lsl #32
    // 0xc72330: r16 = Sentinel
    //     0xc72330: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc72334: cmp             w5, w16
    // 0xc72338: b.eq            #0xc72424
    // 0xc7233c: r0 = BoxInt64Instr(r4)
    //     0xc7233c: sbfiz           x0, x4, #1, #0x1f
    //     0xc72340: cmp             x4, x0, asr #1
    //     0xc72344: b.eq            #0xc72350
    //     0xc72348: bl              #0xd69bb8
    //     0xc7234c: stur            x4, [x0, #7]
    // 0xc72350: mov             x1, x0
    // 0xc72354: stur            x1, [fp, #-0x10]
    // 0xc72358: r0 = LoadClassIdInstr(r5)
    //     0xc72358: ldur            x0, [x5, #-1]
    //     0xc7235c: ubfx            x0, x0, #0xc, #0x14
    // 0xc72360: stp             x1, x5, [SP, #-0x10]!
    // 0xc72364: r0 = GDT[cid_x0 + -0xd83]()
    //     0xc72364: sub             lr, x0, #0xd83
    //     0xc72368: ldr             lr, [x21, lr, lsl #3]
    //     0xc7236c: blr             lr
    // 0xc72370: add             SP, SP, #0x10
    // 0xc72374: mov             x2, x0
    // 0xc72378: ldr             x1, [fp, #0x20]
    // 0xc7237c: stur            x2, [fp, #-0x20]
    // 0xc72380: LoadField: r0 = r1->field_2f
    //     0xc72380: ldur            w0, [x1, #0x2f]
    // 0xc72384: DecompressPointer r0
    //     0xc72384: add             x0, x0, HEAP, lsl #32
    // 0xc72388: r16 = Sentinel
    //     0xc72388: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc7238c: cmp             w0, w16
    // 0xc72390: b.eq            #0xc72430
    // 0xc72394: r3 = LoadClassIdInstr(r0)
    //     0xc72394: ldur            x3, [x0, #-1]
    //     0xc72398: ubfx            x3, x3, #0xc, #0x14
    // 0xc7239c: ldur            x16, [fp, #-0x10]
    // 0xc723a0: stp             x16, x0, [SP, #-0x10]!
    // 0xc723a4: mov             x0, x3
    // 0xc723a8: r0 = GDT[cid_x0 + -0xd83]()
    //     0xc723a8: sub             lr, x0, #0xd83
    //     0xc723ac: ldr             lr, [x21, lr, lsl #3]
    //     0xc723b0: blr             lr
    // 0xc723b4: add             SP, SP, #0x10
    // 0xc723b8: ldur            x1, [fp, #-8]
    // 0xc723bc: r2 = LoadClassIdInstr(r1)
    //     0xc723bc: ldur            x2, [x1, #-1]
    //     0xc723c0: ubfx            x2, x2, #0xc, #0x14
    // 0xc723c4: ldr             x16, [fp, #0x18]
    // 0xc723c8: stp             x16, x1, [SP, #-0x10]!
    // 0xc723cc: ldur            x16, [fp, #-0x20]
    // 0xc723d0: stp             x0, x16, [SP, #-0x10]!
    // 0xc723d4: ldr             x16, [fp, #0x10]
    // 0xc723d8: SaveReg r16
    //     0xc723d8: str             x16, [SP, #-8]!
    // 0xc723dc: mov             x0, x2
    // 0xc723e0: r0 = GDT[cid_x0 + 0xc2da]()
    //     0xc723e0: mov             x17, #0xc2da
    //     0xc723e4: add             lr, x0, x17
    //     0xc723e8: ldr             lr, [x21, lr, lsl #3]
    //     0xc723ec: blr             lr
    // 0xc723f0: add             SP, SP, #0x28
    // 0xc723f4: ldur            x1, [fp, #-0x18]
    // 0xc723f8: add             x4, x1, #1
    // 0xc723fc: b               #0xc722f4
    // 0xc72400: r0 = Null
    //     0xc72400: mov             x0, NULL
    // 0xc72404: LeaveFrame
    //     0xc72404: mov             SP, fp
    //     0xc72408: ldp             fp, lr, [SP], #0x10
    // 0xc7240c: ret
    //     0xc7240c: ret             
    // 0xc72410: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc72410: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc72414: b               #0xc722a8
    // 0xc72418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc72418: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc7241c: b               #0xc7230c
    // 0xc72420: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc72420: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc72424: r9 = _shadowBounds
    //     0xc72424: add             x9, PP, #0x53, lsl #12  ; [pp+0x53010] Field <_ShapeDecorationPainter@875037234._shadowBounds@875037234>: late (offset: 0x28)
    //     0xc72428: ldr             x9, [x9, #0x10]
    // 0xc7242c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc7242c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc72430: r9 = _shadowPaints
    //     0xc72430: add             x9, PP, #0x53, lsl #12  ; [pp+0x53018] Field <_ShapeDecorationPainter@875037234._shadowPaints@875037234>: late (offset: 0x30)
    //     0xc72434: ldr             x9, [x9, #0x18]
    // 0xc72438: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc72438: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _precache(/* No info */) {
    // ** addr: 0xc7243c, size: 0x54c
    // 0xc7243c: EnterFrame
    //     0xc7243c: stp             fp, lr, [SP, #-0x10]!
    //     0xc72440: mov             fp, SP
    // 0xc72444: AllocStack(0x20)
    //     0xc72444: sub             SP, SP, #0x20
    // 0xc72448: CheckStackOverflow
    //     0xc72448: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc7244c: cmp             SP, x16
    //     0xc72450: b.ls            #0xc7297c
    // 0xc72454: r1 = 3
    //     0xc72454: mov             x1, #3
    // 0xc72458: r0 = AllocateContext()
    //     0xc72458: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc7245c: mov             x1, x0
    // 0xc72460: ldr             x0, [fp, #0x20]
    // 0xc72464: stur            x1, [fp, #-0x10]
    // 0xc72468: StoreField: r1->field_f = r0
    //     0xc72468: stur            w0, [x1, #0xf]
    // 0xc7246c: ldr             x2, [fp, #0x18]
    // 0xc72470: StoreField: r1->field_13 = r2
    //     0xc72470: stur            w2, [x1, #0x13]
    // 0xc72474: ldr             x3, [fp, #0x10]
    // 0xc72478: StoreField: r1->field_17 = r3
    //     0xc72478: stur            w3, [x1, #0x17]
    // 0xc7247c: LoadField: r3 = r0->field_f
    //     0xc7247c: ldur            w3, [x0, #0xf]
    // 0xc72480: DecompressPointer r3
    //     0xc72480: add             x3, x3, HEAP, lsl #32
    // 0xc72484: stur            x3, [fp, #-8]
    // 0xc72488: cmp             w3, NULL
    // 0xc7248c: b.eq            #0xc72558
    // 0xc72490: cmp             w2, w3
    // 0xc72494: b.ne            #0xc724a4
    // 0xc72498: mov             x2, x1
    // 0xc7249c: mov             x1, x0
    // 0xc724a0: b               #0xc72514
    // 0xc724a4: stp             x3, x2, [SP, #-0x10]!
    // 0xc724a8: r0 = _haveSameRuntimeType()
    //     0xc724a8: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc724ac: add             SP, SP, #0x10
    // 0xc724b0: tbnz            w0, #4, #0xc72558
    // 0xc724b4: ldr             x0, [fp, #0x18]
    // 0xc724b8: ldur            x1, [fp, #-8]
    // 0xc724bc: LoadField: d0 = r1->field_7
    //     0xc724bc: ldur            d0, [x1, #7]
    // 0xc724c0: LoadField: d1 = r0->field_7
    //     0xc724c0: ldur            d1, [x0, #7]
    // 0xc724c4: fcmp            d0, d1
    // 0xc724c8: b.vs            #0xc72558
    // 0xc724cc: b.ne            #0xc72558
    // 0xc724d0: LoadField: d0 = r1->field_f
    //     0xc724d0: ldur            d0, [x1, #0xf]
    // 0xc724d4: LoadField: d1 = r0->field_f
    //     0xc724d4: ldur            d1, [x0, #0xf]
    // 0xc724d8: fcmp            d0, d1
    // 0xc724dc: b.vs            #0xc72558
    // 0xc724e0: b.ne            #0xc72558
    // 0xc724e4: LoadField: d0 = r1->field_17
    //     0xc724e4: ldur            d0, [x1, #0x17]
    // 0xc724e8: LoadField: d1 = r0->field_17
    //     0xc724e8: ldur            d1, [x0, #0x17]
    // 0xc724ec: fcmp            d0, d1
    // 0xc724f0: b.vs            #0xc72558
    // 0xc724f4: b.ne            #0xc72558
    // 0xc724f8: LoadField: d0 = r1->field_1f
    //     0xc724f8: ldur            d0, [x1, #0x1f]
    // 0xc724fc: LoadField: d1 = r0->field_1f
    //     0xc724fc: ldur            d1, [x0, #0x1f]
    // 0xc72500: fcmp            d0, d1
    // 0xc72504: b.vs            #0xc72558
    // 0xc72508: b.ne            #0xc72558
    // 0xc7250c: ldr             x1, [fp, #0x20]
    // 0xc72510: ldur            x2, [fp, #-0x10]
    // 0xc72514: LoadField: r0 = r2->field_17
    //     0xc72514: ldur            w0, [x2, #0x17]
    // 0xc72518: DecompressPointer r0
    //     0xc72518: add             x0, x0, HEAP, lsl #32
    // 0xc7251c: LoadField: r3 = r1->field_13
    //     0xc7251c: ldur            w3, [x1, #0x13]
    // 0xc72520: DecompressPointer r3
    //     0xc72520: add             x3, x3, HEAP, lsl #32
    // 0xc72524: r4 = LoadClassIdInstr(r0)
    //     0xc72524: ldur            x4, [x0, #-1]
    //     0xc72528: ubfx            x4, x4, #0xc, #0x14
    // 0xc7252c: stp             x3, x0, [SP, #-0x10]!
    // 0xc72530: mov             x0, x4
    // 0xc72534: mov             lr, x0
    // 0xc72538: ldr             lr, [x21, lr, lsl #3]
    // 0xc7253c: blr             lr
    // 0xc72540: add             SP, SP, #0x10
    // 0xc72544: tbnz            w0, #4, #0xc72558
    // 0xc72548: r0 = Null
    //     0xc72548: mov             x0, NULL
    // 0xc7254c: LeaveFrame
    //     0xc7254c: mov             SP, fp
    //     0xc72550: ldp             fp, lr, [SP], #0x10
    // 0xc72554: ret
    //     0xc72554: ret             
    // 0xc72558: ldr             x0, [fp, #0x20]
    // 0xc7255c: LoadField: r1 = r0->field_1f
    //     0xc7255c: ldur            w1, [x0, #0x1f]
    // 0xc72560: DecompressPointer r1
    //     0xc72560: add             x1, x1, HEAP, lsl #32
    // 0xc72564: cmp             w1, NULL
    // 0xc72568: b.ne            #0xc72668
    // 0xc7256c: LoadField: r2 = r0->field_b
    //     0xc7256c: ldur            w2, [x0, #0xb]
    // 0xc72570: DecompressPointer r2
    //     0xc72570: add             x2, x2, HEAP, lsl #32
    // 0xc72574: LoadField: r3 = r2->field_7
    //     0xc72574: ldur            w3, [x2, #7]
    // 0xc72578: DecompressPointer r3
    //     0xc72578: add             x3, x3, HEAP, lsl #32
    // 0xc7257c: stur            x3, [fp, #-8]
    // 0xc72580: cmp             w3, NULL
    // 0xc72584: b.ne            #0xc72598
    // 0xc72588: LoadField: r4 = r2->field_b
    //     0xc72588: ldur            w4, [x2, #0xb]
    // 0xc7258c: DecompressPointer r4
    //     0xc7258c: add             x4, x4, HEAP, lsl #32
    // 0xc72590: cmp             w4, NULL
    // 0xc72594: b.eq            #0xc72660
    // 0xc72598: r16 = 112
    //     0xc72598: mov             x16, #0x70
    // 0xc7259c: stp             x16, NULL, [SP, #-0x10]!
    // 0xc725a0: r0 = ByteData()
    //     0xc725a0: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xc725a4: add             SP, SP, #0x10
    // 0xc725a8: stur            x0, [fp, #-0x18]
    // 0xc725ac: r0 = Paint()
    //     0xc725ac: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xc725b0: mov             x2, x0
    // 0xc725b4: ldur            x1, [fp, #-0x18]
    // 0xc725b8: StoreField: r2->field_7 = r1
    //     0xc725b8: stur            w1, [x2, #7]
    // 0xc725bc: mov             x0, x2
    // 0xc725c0: ldr             x3, [fp, #0x20]
    // 0xc725c4: StoreField: r3->field_1f = r0
    //     0xc725c4: stur            w0, [x3, #0x1f]
    //     0xc725c8: ldurb           w16, [x3, #-1]
    //     0xc725cc: ldurb           w17, [x0, #-1]
    //     0xc725d0: and             x16, x17, x16, lsr #2
    //     0xc725d4: tst             x16, HEAP, lsr #32
    //     0xc725d8: b.eq            #0xc725e0
    //     0xc725dc: bl              #0xd682ac
    // 0xc725e0: ldur            x0, [fp, #-8]
    // 0xc725e4: cmp             w0, NULL
    // 0xc725e8: b.eq            #0xc72658
    // 0xc725ec: r4 = LoadClassIdInstr(r0)
    //     0xc725ec: ldur            x4, [x0, #-1]
    //     0xc725f0: ubfx            x4, x4, #0xc, #0x14
    // 0xc725f4: lsl             x4, x4, #1
    // 0xc725f8: r17 = 10124
    //     0xc725f8: mov             x17, #0x278c
    // 0xc725fc: cmp             w4, w17
    // 0xc72600: b.gt            #0xc72610
    // 0xc72604: r17 = 10122
    //     0xc72604: mov             x17, #0x278a
    // 0xc72608: cmp             w4, w17
    // 0xc7260c: b.ge            #0xc72628
    // 0xc72610: r17 = 10114
    //     0xc72610: mov             x17, #0x2782
    // 0xc72614: cmp             w4, w17
    // 0xc72618: b.eq            #0xc72628
    // 0xc7261c: r17 = 10118
    //     0xc7261c: mov             x17, #0x2786
    // 0xc72620: cmp             w4, w17
    // 0xc72624: b.ne            #0xc72634
    // 0xc72628: LoadField: r4 = r0->field_7
    //     0xc72628: ldur            x4, [x0, #7]
    // 0xc7262c: mov             x0, x4
    // 0xc72630: b               #0xc72640
    // 0xc72634: LoadField: r4 = r0->field_f
    //     0xc72634: ldur            w4, [x0, #0xf]
    // 0xc72638: DecompressPointer r4
    //     0xc72638: add             x4, x4, HEAP, lsl #32
    // 0xc7263c: LoadField: r0 = r4->field_7
    //     0xc7263c: ldur            x0, [x4, #7]
    // 0xc72640: eor             x4, x0, #0xff000000
    // 0xc72644: LoadField: r0 = r1->field_17
    //     0xc72644: ldur            w0, [x1, #0x17]
    // 0xc72648: DecompressPointer r0
    //     0xc72648: add             x0, x0, HEAP, lsl #32
    // 0xc7264c: sxtw            x4, w4
    // 0xc72650: LoadField: r1 = r0->field_7
    //     0xc72650: ldur            x1, [x0, #7]
    // 0xc72654: str             w4, [x1, #4]
    // 0xc72658: mov             x0, x2
    // 0xc7265c: b               #0xc72670
    // 0xc72660: mov             x3, x0
    // 0xc72664: b               #0xc7266c
    // 0xc72668: mov             x3, x0
    // 0xc7266c: mov             x0, x1
    // 0xc72670: stur            x0, [fp, #-0x18]
    // 0xc72674: LoadField: r1 = r3->field_b
    //     0xc72674: ldur            w1, [x3, #0xb]
    // 0xc72678: DecompressPointer r1
    //     0xc72678: add             x1, x1, HEAP, lsl #32
    // 0xc7267c: stur            x1, [fp, #-8]
    // 0xc72680: LoadField: r2 = r1->field_b
    //     0xc72680: ldur            w2, [x1, #0xb]
    // 0xc72684: DecompressPointer r2
    //     0xc72684: add             x2, x2, HEAP, lsl #32
    // 0xc72688: cmp             w2, NULL
    // 0xc7268c: b.eq            #0xc72708
    // 0xc72690: ldur            x4, [fp, #-0x10]
    // 0xc72694: cmp             w0, NULL
    // 0xc72698: b.eq            #0xc72984
    // 0xc7269c: LoadField: r5 = r4->field_13
    //     0xc7269c: ldur            w5, [x4, #0x13]
    // 0xc726a0: DecompressPointer r5
    //     0xc726a0: add             x5, x5, HEAP, lsl #32
    // 0xc726a4: LoadField: r6 = r4->field_17
    //     0xc726a4: ldur            w6, [x4, #0x17]
    // 0xc726a8: DecompressPointer r6
    //     0xc726a8: add             x6, x6, HEAP, lsl #32
    // 0xc726ac: stp             x5, x2, [SP, #-0x10]!
    // 0xc726b0: SaveReg r6
    //     0xc726b0: str             x6, [SP, #-8]!
    // 0xc726b4: r4 = const [0, 0x3, 0x3, 0x2, textDirection, 0x2, null]
    //     0xc726b4: add             x4, PP, #0x28, lsl #12  ; [pp+0x285b8] List(7) [0, 0x3, 0x3, 0x2, "textDirection", 0x2, Null]
    //     0xc726b8: ldr             x4, [x4, #0x5b8]
    // 0xc726bc: r0 = createShader()
    //     0xc726bc: bl              #0xc71978  ; [package:flutter/src/painting/gradient.dart] LinearGradient::createShader
    // 0xc726c0: add             SP, SP, #0x18
    // 0xc726c4: stur            x0, [fp, #-0x20]
    // 0xc726c8: ldur            x16, [fp, #-0x18]
    // 0xc726cc: SaveReg r16
    //     0xc726cc: str             x16, [SP, #-8]!
    // 0xc726d0: r0 = _ensureObjectsInitialized()
    //     0xc726d0: bl              #0x65ebd8  ; [dart:ui] Paint::_ensureObjectsInitialized
    // 0xc726d4: add             SP, SP, #8
    // 0xc726d8: r1 = LoadClassIdInstr(r0)
    //     0xc726d8: ldur            x1, [x0, #-1]
    //     0xc726dc: ubfx            x1, x1, #0xc, #0x14
    // 0xc726e0: stp             xzr, x0, [SP, #-0x10]!
    // 0xc726e4: ldur            x16, [fp, #-0x20]
    // 0xc726e8: SaveReg r16
    //     0xc726e8: str             x16, [SP, #-8]!
    // 0xc726ec: mov             x0, x1
    // 0xc726f0: r0 = GDT[cid_x0 + 0x1015e]()
    //     0xc726f0: mov             x17, #0x15e
    //     0xc726f4: movk            x17, #1, lsl #16
    //     0xc726f8: add             lr, x0, x17
    //     0xc726fc: ldr             lr, [x21, lr, lsl #3]
    //     0xc72700: blr             lr
    // 0xc72704: add             SP, SP, #0x18
    // 0xc72708: ldur            x1, [fp, #-8]
    // 0xc7270c: LoadField: r2 = r1->field_13
    //     0xc7270c: ldur            w2, [x1, #0x13]
    // 0xc72710: DecompressPointer r2
    //     0xc72710: add             x2, x2, HEAP, lsl #32
    // 0xc72714: stur            x2, [fp, #-0x18]
    // 0xc72718: cmp             w2, NULL
    // 0xc7271c: b.eq            #0xc72864
    // 0xc72720: ldr             x3, [fp, #0x20]
    // 0xc72724: LoadField: r0 = r3->field_23
    //     0xc72724: ldur            w0, [x3, #0x23]
    // 0xc72728: DecompressPointer r0
    //     0xc72728: add             x0, x0, HEAP, lsl #32
    // 0xc7272c: cmp             w0, NULL
    // 0xc72730: b.ne            #0xc727c8
    // 0xc72734: r0 = LoadClassIdInstr(r2)
    //     0xc72734: ldur            x0, [x2, #-1]
    //     0xc72738: ubfx            x0, x0, #0xc, #0x14
    // 0xc7273c: SaveReg r2
    //     0xc7273c: str             x2, [SP, #-8]!
    // 0xc72740: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xc72740: mov             x17, #0xb8ea
    //     0xc72744: add             lr, x0, x17
    //     0xc72748: ldr             lr, [x21, lr, lsl #3]
    //     0xc7274c: blr             lr
    // 0xc72750: add             SP, SP, #8
    // 0xc72754: mov             x1, x0
    // 0xc72758: ldr             x0, [fp, #0x20]
    // 0xc7275c: StoreField: r0->field_23 = r1
    //     0xc7275c: stur            w1, [x0, #0x23]
    // 0xc72760: r1 = Function '<anonymous closure>':.
    //     0xc72760: add             x1, PP, #0x53, lsl #12  ; [pp+0x53020] AnonymousClosure: (0xc729f8), in [package:flutter/src/painting/shape_decoration.dart] _ShapeDecorationPainter::_precache (0xc7243c)
    //     0xc72764: ldr             x1, [x1, #0x20]
    // 0xc72768: r2 = Null
    //     0xc72768: mov             x2, NULL
    // 0xc7276c: r0 = AllocateClosure()
    //     0xc7276c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc72770: r16 = <Paint>
    //     0xc72770: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2f520] TypeArguments: <Paint>
    //     0xc72774: ldr             x16, [x16, #0x520]
    // 0xc72778: ldur            lr, [fp, #-0x18]
    // 0xc7277c: stp             lr, x16, [SP, #-0x10]!
    // 0xc72780: SaveReg r0
    //     0xc72780: str             x0, [SP, #-8]!
    // 0xc72784: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc72784: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc72788: r0 = map()
    //     0xc72788: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xc7278c: add             SP, SP, #0x18
    // 0xc72790: r16 = <Paint>
    //     0xc72790: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2f520] TypeArguments: <Paint>
    //     0xc72794: ldr             x16, [x16, #0x520]
    // 0xc72798: stp             x0, x16, [SP, #-0x10]!
    // 0xc7279c: r0 = _GrowableList.of()
    //     0xc7279c: bl              #0x4bfaf0  ; [dart:core] _GrowableList::_GrowableList.of
    // 0xc727a0: add             SP, SP, #0x10
    // 0xc727a4: ldr             x1, [fp, #0x20]
    // 0xc727a8: StoreField: r1->field_2f = r0
    //     0xc727a8: stur            w0, [x1, #0x2f]
    //     0xc727ac: ldurb           w16, [x1, #-1]
    //     0xc727b0: ldurb           w17, [x0, #-1]
    //     0xc727b4: and             x16, x17, x16, lsr #2
    //     0xc727b8: tst             x16, HEAP, lsr #32
    //     0xc727bc: b.eq            #0xc727c4
    //     0xc727c0: bl              #0xd6826c
    // 0xc727c4: b               #0xc727cc
    // 0xc727c8: mov             x1, x3
    // 0xc727cc: ldur            x2, [fp, #-8]
    // 0xc727d0: LoadField: r0 = r2->field_17
    //     0xc727d0: ldur            w0, [x2, #0x17]
    // 0xc727d4: DecompressPointer r0
    //     0xc727d4: add             x0, x0, HEAP, lsl #32
    // 0xc727d8: r3 = LoadClassIdInstr(r0)
    //     0xc727d8: ldur            x3, [x0, #-1]
    //     0xc727dc: ubfx            x3, x3, #0xc, #0x14
    // 0xc727e0: SaveReg r0
    //     0xc727e0: str             x0, [SP, #-8]!
    // 0xc727e4: mov             x0, x3
    // 0xc727e8: r0 = GDT[cid_x0 + 0xc0cf]()
    //     0xc727e8: mov             x17, #0xc0cf
    //     0xc727ec: add             lr, x0, x17
    //     0xc727f0: ldr             lr, [x21, lr, lsl #3]
    //     0xc727f4: blr             lr
    // 0xc727f8: add             SP, SP, #8
    // 0xc727fc: ldur            x2, [fp, #-0x10]
    // 0xc72800: r1 = Function '<anonymous closure>':.
    //     0xc72800: add             x1, PP, #0x53, lsl #12  ; [pp+0x53028] AnonymousClosure: (0xc72988), in [package:flutter/src/painting/shape_decoration.dart] _ShapeDecorationPainter::_precache (0xc7243c)
    //     0xc72804: ldr             x1, [x1, #0x28]
    // 0xc72808: r0 = AllocateClosure()
    //     0xc72808: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc7280c: r16 = <Rect>
    //     0xc7280c: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f8e8] TypeArguments: <Rect>
    //     0xc72810: ldr             x16, [x16, #0x8e8]
    // 0xc72814: ldur            lr, [fp, #-0x18]
    // 0xc72818: stp             lr, x16, [SP, #-0x10]!
    // 0xc7281c: SaveReg r0
    //     0xc7281c: str             x0, [SP, #-8]!
    // 0xc72820: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc72820: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc72824: r0 = map()
    //     0xc72824: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xc72828: add             SP, SP, #0x18
    // 0xc7282c: r16 = <Rect>
    //     0xc7282c: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f8e8] TypeArguments: <Rect>
    //     0xc72830: ldr             x16, [x16, #0x8e8]
    // 0xc72834: stp             x0, x16, [SP, #-0x10]!
    // 0xc72838: r0 = _GrowableList.of()
    //     0xc72838: bl              #0x4bfaf0  ; [dart:core] _GrowableList::_GrowableList.of
    // 0xc7283c: add             SP, SP, #0x10
    // 0xc72840: ldr             x1, [fp, #0x20]
    // 0xc72844: StoreField: r1->field_27 = r0
    //     0xc72844: stur            w0, [x1, #0x27]
    //     0xc72848: ldurb           w16, [x1, #-1]
    //     0xc7284c: ldurb           w17, [x0, #-1]
    //     0xc72850: and             x16, x17, x16, lsr #2
    //     0xc72854: tst             x16, HEAP, lsr #32
    //     0xc72858: b.eq            #0xc72860
    //     0xc7285c: bl              #0xd6826c
    // 0xc72860: b               #0xc72868
    // 0xc72864: ldr             x1, [fp, #0x20]
    // 0xc72868: ldur            x2, [fp, #-8]
    // 0xc7286c: LoadField: r3 = r2->field_17
    //     0xc7286c: ldur            w3, [x2, #0x17]
    // 0xc72870: DecompressPointer r3
    //     0xc72870: add             x3, x3, HEAP, lsl #32
    // 0xc72874: stur            x3, [fp, #-0x18]
    // 0xc72878: r0 = LoadClassIdInstr(r3)
    //     0xc72878: ldur            x0, [x3, #-1]
    //     0xc7287c: ubfx            x0, x0, #0xc, #0x14
    // 0xc72880: SaveReg r3
    //     0xc72880: str             x3, [SP, #-8]!
    // 0xc72884: r0 = GDT[cid_x0 + 0xc0cf]()
    //     0xc72884: mov             x17, #0xc0cf
    //     0xc72888: add             lr, x0, x17
    //     0xc7288c: ldr             lr, [x21, lr, lsl #3]
    //     0xc72890: blr             lr
    // 0xc72894: add             SP, SP, #8
    // 0xc72898: ldur            x0, [fp, #-8]
    // 0xc7289c: LoadField: r1 = r0->field_f
    //     0xc7289c: ldur            w1, [x0, #0xf]
    // 0xc728a0: DecompressPointer r1
    //     0xc728a0: add             x1, x1, HEAP, lsl #32
    // 0xc728a4: cmp             w1, NULL
    // 0xc728a8: b.eq            #0xc7291c
    // 0xc728ac: ldr             x1, [fp, #0x20]
    // 0xc728b0: ldur            x2, [fp, #-0x10]
    // 0xc728b4: ldur            x0, [fp, #-0x18]
    // 0xc728b8: LoadField: r3 = r2->field_13
    //     0xc728b8: ldur            w3, [x2, #0x13]
    // 0xc728bc: DecompressPointer r3
    //     0xc728bc: add             x3, x3, HEAP, lsl #32
    // 0xc728c0: LoadField: r4 = r2->field_17
    //     0xc728c0: ldur            w4, [x2, #0x17]
    // 0xc728c4: DecompressPointer r4
    //     0xc728c4: add             x4, x4, HEAP, lsl #32
    // 0xc728c8: r5 = LoadClassIdInstr(r0)
    //     0xc728c8: ldur            x5, [x0, #-1]
    //     0xc728cc: ubfx            x5, x5, #0xc, #0x14
    // 0xc728d0: stp             x3, x0, [SP, #-0x10]!
    // 0xc728d4: SaveReg r4
    //     0xc728d4: str             x4, [SP, #-8]!
    // 0xc728d8: mov             x0, x5
    // 0xc728dc: r4 = const [0, 0x3, 0x3, 0x2, textDirection, 0x2, null]
    //     0xc728dc: add             x4, PP, #0x28, lsl #12  ; [pp+0x285b8] List(7) [0, 0x3, 0x3, 0x2, "textDirection", 0x2, Null]
    //     0xc728e0: ldr             x4, [x4, #0x5b8]
    // 0xc728e4: r0 = GDT[cid_x0 + 0xc237]()
    //     0xc728e4: mov             x17, #0xc237
    //     0xc728e8: add             lr, x0, x17
    //     0xc728ec: ldr             lr, [x21, lr, lsl #3]
    //     0xc728f0: blr             lr
    // 0xc728f4: add             SP, SP, #0x18
    // 0xc728f8: ldr             x1, [fp, #0x20]
    // 0xc728fc: StoreField: r1->field_1b = r0
    //     0xc728fc: stur            w0, [x1, #0x1b]
    //     0xc72900: ldurb           w16, [x1, #-1]
    //     0xc72904: ldurb           w17, [x0, #-1]
    //     0xc72908: and             x16, x17, x16, lsr #2
    //     0xc7290c: tst             x16, HEAP, lsr #32
    //     0xc72910: b.eq            #0xc72918
    //     0xc72914: bl              #0xd6826c
    // 0xc72918: b               #0xc72920
    // 0xc7291c: ldr             x1, [fp, #0x20]
    // 0xc72920: ldur            x2, [fp, #-0x10]
    // 0xc72924: LoadField: r0 = r2->field_13
    //     0xc72924: ldur            w0, [x2, #0x13]
    // 0xc72928: DecompressPointer r0
    //     0xc72928: add             x0, x0, HEAP, lsl #32
    // 0xc7292c: StoreField: r1->field_f = r0
    //     0xc7292c: stur            w0, [x1, #0xf]
    //     0xc72930: ldurb           w16, [x1, #-1]
    //     0xc72934: ldurb           w17, [x0, #-1]
    //     0xc72938: and             x16, x17, x16, lsr #2
    //     0xc7293c: tst             x16, HEAP, lsr #32
    //     0xc72940: b.eq            #0xc72948
    //     0xc72944: bl              #0xd6826c
    // 0xc72948: LoadField: r0 = r2->field_17
    //     0xc72948: ldur            w0, [x2, #0x17]
    // 0xc7294c: DecompressPointer r0
    //     0xc7294c: add             x0, x0, HEAP, lsl #32
    // 0xc72950: StoreField: r1->field_13 = r0
    //     0xc72950: stur            w0, [x1, #0x13]
    //     0xc72954: ldurb           w16, [x1, #-1]
    //     0xc72958: ldurb           w17, [x0, #-1]
    //     0xc7295c: and             x16, x17, x16, lsr #2
    //     0xc72960: tst             x16, HEAP, lsr #32
    //     0xc72964: b.eq            #0xc7296c
    //     0xc72968: bl              #0xd6826c
    // 0xc7296c: r0 = Null
    //     0xc7296c: mov             x0, NULL
    // 0xc72970: LeaveFrame
    //     0xc72970: mov             SP, fp
    //     0xc72974: ldp             fp, lr, [SP], #0x10
    // 0xc72978: ret
    //     0xc72978: ret             
    // 0xc7297c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc7297c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc72980: b               #0xc72454
    // 0xc72984: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc72984: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Rect <anonymous closure>(dynamic, BoxShadow) {
    // ** addr: 0xc72988, size: 0x70
    // 0xc72988: EnterFrame
    //     0xc72988: stp             fp, lr, [SP, #-0x10]!
    //     0xc7298c: mov             fp, SP
    // 0xc72990: ldr             x0, [fp, #0x18]
    // 0xc72994: LoadField: r1 = r0->field_17
    //     0xc72994: ldur            w1, [x0, #0x17]
    // 0xc72998: DecompressPointer r1
    //     0xc72998: add             x1, x1, HEAP, lsl #32
    // 0xc7299c: CheckStackOverflow
    //     0xc7299c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc729a0: cmp             SP, x16
    //     0xc729a4: b.ls            #0xc729f0
    // 0xc729a8: LoadField: r0 = r1->field_13
    //     0xc729a8: ldur            w0, [x1, #0x13]
    // 0xc729ac: DecompressPointer r0
    //     0xc729ac: add             x0, x0, HEAP, lsl #32
    // 0xc729b0: ldr             x1, [fp, #0x10]
    // 0xc729b4: LoadField: r2 = r1->field_b
    //     0xc729b4: ldur            w2, [x1, #0xb]
    // 0xc729b8: DecompressPointer r2
    //     0xc729b8: add             x2, x2, HEAP, lsl #32
    // 0xc729bc: stp             x2, x0, [SP, #-0x10]!
    // 0xc729c0: r0 = shift()
    //     0xc729c0: bl              #0x51a0bc  ; [dart:ui] Rect::shift
    // 0xc729c4: add             SP, SP, #0x10
    // 0xc729c8: mov             x1, x0
    // 0xc729cc: ldr             x0, [fp, #0x10]
    // 0xc729d0: LoadField: d0 = r0->field_17
    //     0xc729d0: ldur            d0, [x0, #0x17]
    // 0xc729d4: SaveReg r1
    //     0xc729d4: str             x1, [SP, #-8]!
    // 0xc729d8: SaveReg d0
    //     0xc729d8: str             d0, [SP, #-8]!
    // 0xc729dc: r0 = inflate()
    //     0xc729dc: bl              #0x5d1480  ; [dart:ui] Rect::inflate
    // 0xc729e0: add             SP, SP, #0x10
    // 0xc729e4: LeaveFrame
    //     0xc729e4: mov             SP, fp
    //     0xc729e8: ldp             fp, lr, [SP], #0x10
    // 0xc729ec: ret
    //     0xc729ec: ret             
    // 0xc729f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc729f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc729f4: b               #0xc729a8
  }
  [closure] Paint <anonymous closure>(dynamic, BoxShadow) {
    // ** addr: 0xc729f8, size: 0x38
    // 0xc729f8: EnterFrame
    //     0xc729f8: stp             fp, lr, [SP, #-0x10]!
    //     0xc729fc: mov             fp, SP
    // 0xc72a00: CheckStackOverflow
    //     0xc72a00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc72a04: cmp             SP, x16
    //     0xc72a08: b.ls            #0xc72a28
    // 0xc72a0c: ldr             x16, [fp, #0x10]
    // 0xc72a10: SaveReg r16
    //     0xc72a10: str             x16, [SP, #-8]!
    // 0xc72a14: r0 = toPaint()
    //     0xc72a14: bl              #0x65f6d0  ; [package:flutter/src/painting/box_shadow.dart] BoxShadow::toPaint
    // 0xc72a18: add             SP, SP, #8
    // 0xc72a1c: LeaveFrame
    //     0xc72a1c: mov             SP, fp
    //     0xc72a20: ldp             fp, lr, [SP], #0x10
    // 0xc72a24: ret
    //     0xc72a24: ret             
    // 0xc72a28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc72a28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc72a2c: b               #0xc72a0c
  }
  _ dispose(/* No info */) {
    // ** addr: 0xc75830, size: 0x4c
    // 0xc75830: EnterFrame
    //     0xc75830: stp             fp, lr, [SP, #-0x10]!
    //     0xc75834: mov             fp, SP
    // 0xc75838: CheckStackOverflow
    //     0xc75838: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc7583c: cmp             SP, x16
    //     0xc75840: b.ls            #0xc75874
    // 0xc75844: ldr             x0, [fp, #0x10]
    // 0xc75848: LoadField: r1 = r0->field_33
    //     0xc75848: ldur            w1, [x0, #0x33]
    // 0xc7584c: DecompressPointer r1
    //     0xc7584c: add             x1, x1, HEAP, lsl #32
    // 0xc75850: cmp             w1, NULL
    // 0xc75854: b.eq            #0xc75864
    // 0xc75858: SaveReg r1
    //     0xc75858: str             x1, [SP, #-8]!
    // 0xc7585c: r0 = dispose()
    //     0xc7585c: bl              #0xc7576c  ; [package:flutter/src/painting/decoration_image.dart] DecorationImagePainter::dispose
    // 0xc75860: add             SP, SP, #8
    // 0xc75864: r0 = Null
    //     0xc75864: mov             x0, NULL
    // 0xc75868: LeaveFrame
    //     0xc75868: mov             SP, fp
    //     0xc7586c: ldp             fp, lr, [SP], #0x10
    // 0xc75870: ret
    //     0xc75870: ret             
    // 0xc75874: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc75874: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc75878: b               #0xc75844
  }
}

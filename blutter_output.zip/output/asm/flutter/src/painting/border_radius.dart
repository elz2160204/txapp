// lib: , url: package:flutter/src/painting/border_radius.dart

// class id: 1049348, size: 0x8
class :: {
}

// class id: 2110, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class BorderRadiusGeometry extends Object {

  static _ lerp(/* No info */) {
    // ** addr: 0x70e900, size: 0x2e8
    // 0x70e900: EnterFrame
    //     0x70e900: stp             fp, lr, [SP, #-0x10]!
    //     0x70e904: mov             fp, SP
    // 0x70e908: AllocStack(0x30)
    //     0x70e908: sub             SP, SP, #0x30
    // 0x70e90c: CheckStackOverflow
    //     0x70e90c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x70e910: cmp             SP, x16
    //     0x70e914: b.ls            #0x70eba8
    // 0x70e918: ldr             x0, [fp, #0x20]
    // 0x70e91c: cmp             w0, NULL
    // 0x70e920: b.ne            #0x70e940
    // 0x70e924: ldr             x1, [fp, #0x18]
    // 0x70e928: cmp             w1, NULL
    // 0x70e92c: b.ne            #0x70e944
    // 0x70e930: r0 = Null
    //     0x70e930: mov             x0, NULL
    // 0x70e934: LeaveFrame
    //     0x70e934: mov             SP, fp
    //     0x70e938: ldp             fp, lr, [SP], #0x10
    // 0x70e93c: ret
    //     0x70e93c: ret             
    // 0x70e940: ldr             x1, [fp, #0x18]
    // 0x70e944: cmp             w0, NULL
    // 0x70e948: b.ne            #0x70e954
    // 0x70e94c: r0 = Instance_BorderRadius
    //     0x70e94c: add             x0, PP, #0x15, lsl #12  ; [pp+0x152c0] Obj!BorderRadius@b37471
    //     0x70e950: ldr             x0, [x0, #0x2c0]
    // 0x70e954: stur            x0, [fp, #-8]
    // 0x70e958: cmp             w1, NULL
    // 0x70e95c: b.ne            #0x70e968
    // 0x70e960: r1 = Instance_BorderRadius
    //     0x70e960: add             x1, PP, #0x15, lsl #12  ; [pp+0x152c0] Obj!BorderRadius@b37471
    //     0x70e964: ldr             x1, [x1, #0x2c0]
    // 0x70e968: r2 = LoadClassIdInstr(r1)
    //     0x70e968: ldur            x2, [x1, #-1]
    //     0x70e96c: ubfx            x2, x2, #0xc, #0x14
    // 0x70e970: lsl             x2, x2, #1
    // 0x70e974: r17 = 4224
    //     0x70e974: mov             x17, #0x1080
    // 0x70e978: cmp             w2, w17
    // 0x70e97c: b.ne            #0x70e9bc
    // 0x70e980: r2 = LoadClassIdInstr(r0)
    //     0x70e980: ldur            x2, [x0, #-1]
    //     0x70e984: ubfx            x2, x2, #0xc, #0x14
    // 0x70e988: lsl             x2, x2, #1
    // 0x70e98c: r17 = 4224
    //     0x70e98c: mov             x17, #0x1080
    // 0x70e990: cmp             w2, w17
    // 0x70e994: b.ne            #0x70e9a8
    // 0x70e998: stp             x0, x1, [SP, #-0x10]!
    // 0x70e99c: r0 = -()
    //     0x70e99c: bl              #0x596118  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::-
    // 0x70e9a0: add             SP, SP, #0x10
    // 0x70e9a4: b               #0x70e9dc
    // 0x70e9a8: ldur            x16, [fp, #-8]
    // 0x70e9ac: stp             x16, x1, [SP, #-0x10]!
    // 0x70e9b0: r0 = subtract()
    //     0x70e9b0: bl              #0xcf9dcc  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::subtract
    // 0x70e9b4: add             SP, SP, #0x10
    // 0x70e9b8: b               #0x70e9dc
    // 0x70e9bc: r0 = LoadClassIdInstr(r1)
    //     0x70e9bc: ldur            x0, [x1, #-1]
    //     0x70e9c0: ubfx            x0, x0, #0xc, #0x14
    // 0x70e9c4: ldur            x16, [fp, #-8]
    // 0x70e9c8: stp             x16, x1, [SP, #-0x10]!
    // 0x70e9cc: r0 = GDT[cid_x0 + -0xf82]()
    //     0x70e9cc: sub             lr, x0, #0xf82
    //     0x70e9d0: ldr             lr, [x21, lr, lsl #3]
    //     0x70e9d4: blr             lr
    // 0x70e9d8: add             SP, SP, #0x10
    // 0x70e9dc: stur            x0, [fp, #-0x18]
    // 0x70e9e0: r1 = LoadClassIdInstr(r0)
    //     0x70e9e0: ldur            x1, [x0, #-1]
    //     0x70e9e4: ubfx            x1, x1, #0xc, #0x14
    // 0x70e9e8: lsl             x1, x1, #1
    // 0x70e9ec: r17 = 4224
    //     0x70e9ec: mov             x17, #0x1080
    // 0x70e9f0: cmp             w1, w17
    // 0x70e9f4: b.ne            #0x70ead8
    // 0x70e9f8: ldr             d0, [fp, #0x10]
    // 0x70e9fc: LoadField: r1 = r0->field_7
    //     0x70e9fc: ldur            w1, [x0, #7]
    // 0x70ea00: DecompressPointer r1
    //     0x70ea00: add             x1, x1, HEAP, lsl #32
    // 0x70ea04: r2 = inline_Allocate_Double()
    //     0x70ea04: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x70ea08: add             x2, x2, #0x10
    //     0x70ea0c: cmp             x3, x2
    //     0x70ea10: b.ls            #0x70ebb0
    //     0x70ea14: str             x2, [THR, #0x60]  ; THR::top
    //     0x70ea18: sub             x2, x2, #0xf
    //     0x70ea1c: mov             x3, #0xd108
    //     0x70ea20: movk            x3, #3, lsl #16
    //     0x70ea24: stur            x3, [x2, #-1]
    // 0x70ea28: StoreField: r2->field_7 = d0
    //     0x70ea28: stur            d0, [x2, #7]
    // 0x70ea2c: stur            x2, [fp, #-0x10]
    // 0x70ea30: stp             x2, x1, [SP, #-0x10]!
    // 0x70ea34: r0 = *()
    //     0x70ea34: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0x70ea38: add             SP, SP, #0x10
    // 0x70ea3c: mov             x1, x0
    // 0x70ea40: ldur            x0, [fp, #-0x18]
    // 0x70ea44: stur            x1, [fp, #-0x20]
    // 0x70ea48: LoadField: r2 = r0->field_b
    //     0x70ea48: ldur            w2, [x0, #0xb]
    // 0x70ea4c: DecompressPointer r2
    //     0x70ea4c: add             x2, x2, HEAP, lsl #32
    // 0x70ea50: ldur            x16, [fp, #-0x10]
    // 0x70ea54: stp             x16, x2, [SP, #-0x10]!
    // 0x70ea58: r0 = *()
    //     0x70ea58: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0x70ea5c: add             SP, SP, #0x10
    // 0x70ea60: mov             x1, x0
    // 0x70ea64: ldur            x0, [fp, #-0x18]
    // 0x70ea68: stur            x1, [fp, #-0x28]
    // 0x70ea6c: LoadField: r2 = r0->field_f
    //     0x70ea6c: ldur            w2, [x0, #0xf]
    // 0x70ea70: DecompressPointer r2
    //     0x70ea70: add             x2, x2, HEAP, lsl #32
    // 0x70ea74: ldur            x16, [fp, #-0x10]
    // 0x70ea78: stp             x16, x2, [SP, #-0x10]!
    // 0x70ea7c: r0 = *()
    //     0x70ea7c: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0x70ea80: add             SP, SP, #0x10
    // 0x70ea84: mov             x1, x0
    // 0x70ea88: ldur            x0, [fp, #-0x18]
    // 0x70ea8c: stur            x1, [fp, #-0x30]
    // 0x70ea90: LoadField: r2 = r0->field_13
    //     0x70ea90: ldur            w2, [x0, #0x13]
    // 0x70ea94: DecompressPointer r2
    //     0x70ea94: add             x2, x2, HEAP, lsl #32
    // 0x70ea98: ldur            x16, [fp, #-0x10]
    // 0x70ea9c: stp             x16, x2, [SP, #-0x10]!
    // 0x70eaa0: r0 = *()
    //     0x70eaa0: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0x70eaa4: add             SP, SP, #0x10
    // 0x70eaa8: stur            x0, [fp, #-0x10]
    // 0x70eaac: r0 = BorderRadius()
    //     0x70eaac: bl              #0x596250  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x70eab0: mov             x1, x0
    // 0x70eab4: ldur            x0, [fp, #-0x20]
    // 0x70eab8: StoreField: r1->field_7 = r0
    //     0x70eab8: stur            w0, [x1, #7]
    // 0x70eabc: ldur            x0, [fp, #-0x28]
    // 0x70eac0: StoreField: r1->field_b = r0
    //     0x70eac0: stur            w0, [x1, #0xb]
    // 0x70eac4: ldur            x0, [fp, #-0x30]
    // 0x70eac8: StoreField: r1->field_f = r0
    //     0x70eac8: stur            w0, [x1, #0xf]
    // 0x70eacc: ldur            x0, [fp, #-0x10]
    // 0x70ead0: StoreField: r1->field_13 = r0
    //     0x70ead0: stur            w0, [x1, #0x13]
    // 0x70ead4: b               #0x70eb28
    // 0x70ead8: ldr             d0, [fp, #0x10]
    // 0x70eadc: r1 = inline_Allocate_Double()
    //     0x70eadc: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x70eae0: add             x1, x1, #0x10
    //     0x70eae4: cmp             x2, x1
    //     0x70eae8: b.ls            #0x70ebcc
    //     0x70eaec: str             x1, [THR, #0x60]  ; THR::top
    //     0x70eaf0: sub             x1, x1, #0xf
    //     0x70eaf4: mov             x2, #0xd108
    //     0x70eaf8: movk            x2, #3, lsl #16
    //     0x70eafc: stur            x2, [x1, #-1]
    // 0x70eb00: StoreField: r1->field_7 = d0
    //     0x70eb00: stur            d0, [x1, #7]
    // 0x70eb04: r2 = LoadClassIdInstr(r0)
    //     0x70eb04: ldur            x2, [x0, #-1]
    //     0x70eb08: ubfx            x2, x2, #0xc, #0x14
    // 0x70eb0c: stp             x1, x0, [SP, #-0x10]!
    // 0x70eb10: mov             x0, x2
    // 0x70eb14: r0 = GDT[cid_x0 + -0xfd3]()
    //     0x70eb14: sub             lr, x0, #0xfd3
    //     0x70eb18: ldr             lr, [x21, lr, lsl #3]
    //     0x70eb1c: blr             lr
    // 0x70eb20: add             SP, SP, #0x10
    // 0x70eb24: mov             x1, x0
    // 0x70eb28: ldur            x0, [fp, #-8]
    // 0x70eb2c: r2 = LoadClassIdInstr(r0)
    //     0x70eb2c: ldur            x2, [x0, #-1]
    //     0x70eb30: ubfx            x2, x2, #0xc, #0x14
    // 0x70eb34: lsl             x2, x2, #1
    // 0x70eb38: r17 = 4224
    //     0x70eb38: mov             x17, #0x1080
    // 0x70eb3c: cmp             w2, w17
    // 0x70eb40: b.ne            #0x70eb7c
    // 0x70eb44: r2 = LoadClassIdInstr(r1)
    //     0x70eb44: ldur            x2, [x1, #-1]
    //     0x70eb48: ubfx            x2, x2, #0xc, #0x14
    // 0x70eb4c: lsl             x2, x2, #1
    // 0x70eb50: r17 = 4224
    //     0x70eb50: mov             x17, #0x1080
    // 0x70eb54: cmp             w2, w17
    // 0x70eb58: b.ne            #0x70eb6c
    // 0x70eb5c: stp             x1, x0, [SP, #-0x10]!
    // 0x70eb60: r0 = +()
    //     0x70eb60: bl              #0x595f90  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::+
    // 0x70eb64: add             SP, SP, #0x10
    // 0x70eb68: b               #0x70eb9c
    // 0x70eb6c: stp             x1, x0, [SP, #-0x10]!
    // 0x70eb70: r0 = add()
    //     0x70eb70: bl              #0xcf8f7c  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::add
    // 0x70eb74: add             SP, SP, #0x10
    // 0x70eb78: b               #0x70eb9c
    // 0x70eb7c: r2 = LoadClassIdInstr(r0)
    //     0x70eb7c: ldur            x2, [x0, #-1]
    //     0x70eb80: ubfx            x2, x2, #0xc, #0x14
    // 0x70eb84: stp             x1, x0, [SP, #-0x10]!
    // 0x70eb88: mov             x0, x2
    // 0x70eb8c: r0 = GDT[cid_x0 + -0xf6c]()
    //     0x70eb8c: sub             lr, x0, #0xf6c
    //     0x70eb90: ldr             lr, [x21, lr, lsl #3]
    //     0x70eb94: blr             lr
    // 0x70eb98: add             SP, SP, #0x10
    // 0x70eb9c: LeaveFrame
    //     0x70eb9c: mov             SP, fp
    //     0x70eba0: ldp             fp, lr, [SP], #0x10
    // 0x70eba4: ret
    //     0x70eba4: ret             
    // 0x70eba8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x70eba8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x70ebac: b               #0x70e918
    // 0x70ebb0: SaveReg d0
    //     0x70ebb0: str             q0, [SP, #-0x10]!
    // 0x70ebb4: stp             x0, x1, [SP, #-0x10]!
    // 0x70ebb8: r0 = AllocateDouble()
    //     0x70ebb8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x70ebbc: mov             x2, x0
    // 0x70ebc0: ldp             x0, x1, [SP], #0x10
    // 0x70ebc4: RestoreReg d0
    //     0x70ebc4: ldr             q0, [SP], #0x10
    // 0x70ebc8: b               #0x70ea28
    // 0x70ebcc: SaveReg d0
    //     0x70ebcc: str             q0, [SP, #-0x10]!
    // 0x70ebd0: SaveReg r0
    //     0x70ebd0: str             x0, [SP, #-8]!
    // 0x70ebd4: r0 = AllocateDouble()
    //     0x70ebd4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x70ebd8: mov             x1, x0
    // 0x70ebdc: RestoreReg r0
    //     0x70ebdc: ldr             x0, [SP], #8
    // 0x70ebe0: RestoreReg d0
    //     0x70ebe0: ldr             q0, [SP], #0x10
    // 0x70ebe4: b               #0x70eb00
  }
  _ toString(/* No info */) {
    // ** addr: 0xadf530, size: 0x1464
    // 0xadf530: EnterFrame
    //     0xadf530: stp             fp, lr, [SP, #-0x10]!
    //     0xadf534: mov             fp, SP
    // 0xadf538: AllocStack(0x28)
    //     0xadf538: sub             SP, SP, #0x28
    // 0xadf53c: CheckStackOverflow
    //     0xadf53c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xadf540: cmp             SP, x16
    //     0xadf544: b.ls            #0xae094c
    // 0xadf548: ldr             x0, [fp, #0x10]
    // 0xadf54c: r1 = LoadClassIdInstr(r0)
    //     0xadf54c: ldur            x1, [x0, #-1]
    //     0xadf550: ubfx            x1, x1, #0xc, #0x14
    // 0xadf554: lsl             x1, x1, #1
    // 0xadf558: stur            x1, [fp, #-0x18]
    // 0xadf55c: r17 = 4222
    //     0xadf55c: mov             x17, #0x107e
    // 0xadf560: cmp             w1, w17
    // 0xadf564: b.ne            #0xadf574
    // 0xadf568: LoadField: r2 = r0->field_7
    //     0xadf568: ldur            w2, [x0, #7]
    // 0xadf56c: DecompressPointer r2
    //     0xadf56c: add             x2, x2, HEAP, lsl #32
    // 0xadf570: b               #0xadf57c
    // 0xadf574: LoadField: r2 = r0->field_7
    //     0xadf574: ldur            w2, [x0, #7]
    // 0xadf578: DecompressPointer r2
    //     0xadf578: add             x2, x2, HEAP, lsl #32
    // 0xadf57c: stur            x2, [fp, #-0x10]
    // 0xadf580: r17 = 4222
    //     0xadf580: mov             x17, #0x107e
    // 0xadf584: cmp             w1, w17
    // 0xadf588: b.ne            #0xadf598
    // 0xadf58c: LoadField: r3 = r0->field_b
    //     0xadf58c: ldur            w3, [x0, #0xb]
    // 0xadf590: DecompressPointer r3
    //     0xadf590: add             x3, x3, HEAP, lsl #32
    // 0xadf594: b               #0xadf5a0
    // 0xadf598: LoadField: r3 = r0->field_b
    //     0xadf598: ldur            w3, [x0, #0xb]
    // 0xadf59c: DecompressPointer r3
    //     0xadf59c: add             x3, x3, HEAP, lsl #32
    // 0xadf5a0: stur            x3, [fp, #-8]
    // 0xadf5a4: cmp             w2, w3
    // 0xadf5a8: b.ne            #0xadf5b4
    // 0xadf5ac: mov             x0, x1
    // 0xadf5b0: b               #0xadf608
    // 0xadf5b4: r16 = Radius
    //     0xadf5b4: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xadf5b8: ldr             x16, [x16, #0x470]
    // 0xadf5bc: r30 = Radius
    //     0xadf5bc: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xadf5c0: ldr             lr, [lr, #0x470]
    // 0xadf5c4: stp             lr, x16, [SP, #-0x10]!
    // 0xadf5c8: r0 = ==()
    //     0xadf5c8: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xadf5cc: add             SP, SP, #0x10
    // 0xadf5d0: tbnz            w0, #4, #0xadf9a0
    // 0xadf5d4: ldur            x0, [fp, #-0x10]
    // 0xadf5d8: ldur            x1, [fp, #-8]
    // 0xadf5dc: LoadField: d0 = r1->field_7
    //     0xadf5dc: ldur            d0, [x1, #7]
    // 0xadf5e0: LoadField: d1 = r0->field_7
    //     0xadf5e0: ldur            d1, [x0, #7]
    // 0xadf5e4: fcmp            d0, d1
    // 0xadf5e8: b.vs            #0xadf9a0
    // 0xadf5ec: b.ne            #0xadf9a0
    // 0xadf5f0: LoadField: d0 = r1->field_f
    //     0xadf5f0: ldur            d0, [x1, #0xf]
    // 0xadf5f4: LoadField: d1 = r0->field_f
    //     0xadf5f4: ldur            d1, [x0, #0xf]
    // 0xadf5f8: fcmp            d0, d1
    // 0xadf5fc: b.vs            #0xadf9a0
    // 0xadf600: b.ne            #0xadf9a0
    // 0xadf604: ldur            x0, [fp, #-0x18]
    // 0xadf608: r17 = 4222
    //     0xadf608: mov             x17, #0x107e
    // 0xadf60c: cmp             w0, w17
    // 0xadf610: b.ne            #0xadf624
    // 0xadf614: ldr             x1, [fp, #0x10]
    // 0xadf618: LoadField: r2 = r1->field_b
    //     0xadf618: ldur            w2, [x1, #0xb]
    // 0xadf61c: DecompressPointer r2
    //     0xadf61c: add             x2, x2, HEAP, lsl #32
    // 0xadf620: b               #0xadf630
    // 0xadf624: ldr             x1, [fp, #0x10]
    // 0xadf628: LoadField: r2 = r1->field_b
    //     0xadf628: ldur            w2, [x1, #0xb]
    // 0xadf62c: DecompressPointer r2
    //     0xadf62c: add             x2, x2, HEAP, lsl #32
    // 0xadf630: stur            x2, [fp, #-0x10]
    // 0xadf634: r17 = 4222
    //     0xadf634: mov             x17, #0x107e
    // 0xadf638: cmp             w0, w17
    // 0xadf63c: b.ne            #0xadf64c
    // 0xadf640: LoadField: r3 = r1->field_f
    //     0xadf640: ldur            w3, [x1, #0xf]
    // 0xadf644: DecompressPointer r3
    //     0xadf644: add             x3, x3, HEAP, lsl #32
    // 0xadf648: b               #0xadf654
    // 0xadf64c: LoadField: r3 = r1->field_f
    //     0xadf64c: ldur            w3, [x1, #0xf]
    // 0xadf650: DecompressPointer r3
    //     0xadf650: add             x3, x3, HEAP, lsl #32
    // 0xadf654: stur            x3, [fp, #-8]
    // 0xadf658: cmp             w2, w3
    // 0xadf65c: b.eq            #0xadf6b4
    // 0xadf660: r16 = Radius
    //     0xadf660: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xadf664: ldr             x16, [x16, #0x470]
    // 0xadf668: r30 = Radius
    //     0xadf668: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xadf66c: ldr             lr, [lr, #0x470]
    // 0xadf670: stp             lr, x16, [SP, #-0x10]!
    // 0xadf674: r0 = ==()
    //     0xadf674: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xadf678: add             SP, SP, #0x10
    // 0xadf67c: tbnz            w0, #4, #0xadf9a0
    // 0xadf680: ldur            x0, [fp, #-0x10]
    // 0xadf684: ldur            x1, [fp, #-8]
    // 0xadf688: LoadField: d0 = r1->field_7
    //     0xadf688: ldur            d0, [x1, #7]
    // 0xadf68c: LoadField: d1 = r0->field_7
    //     0xadf68c: ldur            d1, [x0, #7]
    // 0xadf690: fcmp            d0, d1
    // 0xadf694: b.vs            #0xadf9a0
    // 0xadf698: b.ne            #0xadf9a0
    // 0xadf69c: LoadField: d0 = r1->field_f
    //     0xadf69c: ldur            d0, [x1, #0xf]
    // 0xadf6a0: LoadField: d1 = r0->field_f
    //     0xadf6a0: ldur            d1, [x0, #0xf]
    // 0xadf6a4: fcmp            d0, d1
    // 0xadf6a8: b.vs            #0xadf9a0
    // 0xadf6ac: b.ne            #0xadf9a0
    // 0xadf6b0: ldur            x0, [fp, #-0x18]
    // 0xadf6b4: r17 = 4222
    //     0xadf6b4: mov             x17, #0x107e
    // 0xadf6b8: cmp             w0, w17
    // 0xadf6bc: b.ne            #0xadf6d0
    // 0xadf6c0: ldr             x1, [fp, #0x10]
    // 0xadf6c4: LoadField: r2 = r1->field_f
    //     0xadf6c4: ldur            w2, [x1, #0xf]
    // 0xadf6c8: DecompressPointer r2
    //     0xadf6c8: add             x2, x2, HEAP, lsl #32
    // 0xadf6cc: b               #0xadf6dc
    // 0xadf6d0: ldr             x1, [fp, #0x10]
    // 0xadf6d4: LoadField: r2 = r1->field_f
    //     0xadf6d4: ldur            w2, [x1, #0xf]
    // 0xadf6d8: DecompressPointer r2
    //     0xadf6d8: add             x2, x2, HEAP, lsl #32
    // 0xadf6dc: stur            x2, [fp, #-0x10]
    // 0xadf6e0: r17 = 4222
    //     0xadf6e0: mov             x17, #0x107e
    // 0xadf6e4: cmp             w0, w17
    // 0xadf6e8: b.ne            #0xadf6f8
    // 0xadf6ec: LoadField: r3 = r1->field_13
    //     0xadf6ec: ldur            w3, [x1, #0x13]
    // 0xadf6f0: DecompressPointer r3
    //     0xadf6f0: add             x3, x3, HEAP, lsl #32
    // 0xadf6f4: b               #0xadf700
    // 0xadf6f8: LoadField: r3 = r1->field_13
    //     0xadf6f8: ldur            w3, [x1, #0x13]
    // 0xadf6fc: DecompressPointer r3
    //     0xadf6fc: add             x3, x3, HEAP, lsl #32
    // 0xadf700: stur            x3, [fp, #-8]
    // 0xadf704: cmp             w2, w3
    // 0xadf708: b.eq            #0xadf760
    // 0xadf70c: r16 = Radius
    //     0xadf70c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xadf710: ldr             x16, [x16, #0x470]
    // 0xadf714: r30 = Radius
    //     0xadf714: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xadf718: ldr             lr, [lr, #0x470]
    // 0xadf71c: stp             lr, x16, [SP, #-0x10]!
    // 0xadf720: r0 = ==()
    //     0xadf720: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xadf724: add             SP, SP, #0x10
    // 0xadf728: tbnz            w0, #4, #0xadf9a0
    // 0xadf72c: ldur            x0, [fp, #-0x10]
    // 0xadf730: ldur            x1, [fp, #-8]
    // 0xadf734: LoadField: d0 = r1->field_7
    //     0xadf734: ldur            d0, [x1, #7]
    // 0xadf738: LoadField: d1 = r0->field_7
    //     0xadf738: ldur            d1, [x0, #7]
    // 0xadf73c: fcmp            d0, d1
    // 0xadf740: b.vs            #0xadf9a0
    // 0xadf744: b.ne            #0xadf9a0
    // 0xadf748: LoadField: d0 = r1->field_f
    //     0xadf748: ldur            d0, [x1, #0xf]
    // 0xadf74c: LoadField: d1 = r0->field_f
    //     0xadf74c: ldur            d1, [x0, #0xf]
    // 0xadf750: fcmp            d0, d1
    // 0xadf754: b.vs            #0xadf9a0
    // 0xadf758: b.ne            #0xadf9a0
    // 0xadf75c: ldur            x0, [fp, #-0x18]
    // 0xadf760: r17 = 4222
    //     0xadf760: mov             x17, #0x107e
    // 0xadf764: cmp             w0, w17
    // 0xadf768: b.ne            #0xadf77c
    // 0xadf76c: ldr             x1, [fp, #0x10]
    // 0xadf770: LoadField: r2 = r1->field_7
    //     0xadf770: ldur            w2, [x1, #7]
    // 0xadf774: DecompressPointer r2
    //     0xadf774: add             x2, x2, HEAP, lsl #32
    // 0xadf778: b               #0xadf788
    // 0xadf77c: ldr             x1, [fp, #0x10]
    // 0xadf780: LoadField: r2 = r1->field_7
    //     0xadf780: ldur            w2, [x1, #7]
    // 0xadf784: DecompressPointer r2
    //     0xadf784: add             x2, x2, HEAP, lsl #32
    // 0xadf788: stur            x2, [fp, #-8]
    // 0xadf78c: r16 = Instance_Radius
    //     0xadf78c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadf790: ldr             x16, [x16, #0x478]
    // 0xadf794: cmp             w2, w16
    // 0xadf798: b.ne            #0xadf7a8
    // 0xadf79c: r3 = Instance_Radius
    //     0xadf79c: add             x3, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadf7a0: ldr             x3, [x3, #0x478]
    // 0xadf7a4: b               #0xadf804
    // 0xadf7a8: r16 = Radius
    //     0xadf7a8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xadf7ac: ldr             x16, [x16, #0x470]
    // 0xadf7b0: r30 = Radius
    //     0xadf7b0: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xadf7b4: ldr             lr, [lr, #0x470]
    // 0xadf7b8: stp             lr, x16, [SP, #-0x10]!
    // 0xadf7bc: r0 = ==()
    //     0xadf7bc: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xadf7c0: add             SP, SP, #0x10
    // 0xadf7c4: tbz             w0, #4, #0xadf7d4
    // 0xadf7c8: r3 = Instance_Radius
    //     0xadf7c8: add             x3, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadf7cc: ldr             x3, [x3, #0x478]
    // 0xadf7d0: b               #0xadf80c
    // 0xadf7d4: ldur            x0, [fp, #-8]
    // 0xadf7d8: r3 = Instance_Radius
    //     0xadf7d8: add             x3, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadf7dc: ldr             x3, [x3, #0x478]
    // 0xadf7e0: LoadField: d0 = r3->field_7
    //     0xadf7e0: ldur            d0, [x3, #7]
    // 0xadf7e4: LoadField: d1 = r0->field_7
    //     0xadf7e4: ldur            d1, [x0, #7]
    // 0xadf7e8: fcmp            d0, d1
    // 0xadf7ec: b.vs            #0xadf80c
    // 0xadf7f0: b.ne            #0xadf80c
    // 0xadf7f4: LoadField: d0 = r3->field_f
    //     0xadf7f4: ldur            d0, [x3, #0xf]
    // 0xadf7f8: LoadField: d1 = r0->field_f
    //     0xadf7f8: ldur            d1, [x0, #0xf]
    // 0xadf7fc: fcmp            d0, d1
    // 0xadf800: b.ne            #0xadf80c
    // 0xadf804: r0 = Null
    //     0xadf804: mov             x0, NULL
    // 0xadf808: b               #0xadf998
    // 0xadf80c: ldur            x0, [fp, #-0x18]
    // 0xadf810: r17 = 4222
    //     0xadf810: mov             x17, #0x107e
    // 0xadf814: cmp             w0, w17
    // 0xadf818: b.ne            #0xadf82c
    // 0xadf81c: ldr             x4, [fp, #0x10]
    // 0xadf820: LoadField: r1 = r4->field_7
    //     0xadf820: ldur            w1, [x4, #7]
    // 0xadf824: DecompressPointer r1
    //     0xadf824: add             x1, x1, HEAP, lsl #32
    // 0xadf828: b               #0xadf838
    // 0xadf82c: ldr             x4, [fp, #0x10]
    // 0xadf830: LoadField: r1 = r4->field_7
    //     0xadf830: ldur            w1, [x4, #7]
    // 0xadf834: DecompressPointer r1
    //     0xadf834: add             x1, x1, HEAP, lsl #32
    // 0xadf838: LoadField: d0 = r1->field_7
    //     0xadf838: ldur            d0, [x1, #7]
    // 0xadf83c: r17 = 4222
    //     0xadf83c: mov             x17, #0x107e
    // 0xadf840: cmp             w0, w17
    // 0xadf844: b.ne            #0xadf854
    // 0xadf848: LoadField: r1 = r4->field_7
    //     0xadf848: ldur            w1, [x4, #7]
    // 0xadf84c: DecompressPointer r1
    //     0xadf84c: add             x1, x1, HEAP, lsl #32
    // 0xadf850: b               #0xadf85c
    // 0xadf854: LoadField: r1 = r4->field_7
    //     0xadf854: ldur            w1, [x4, #7]
    // 0xadf858: DecompressPointer r1
    //     0xadf858: add             x1, x1, HEAP, lsl #32
    // 0xadf85c: LoadField: d1 = r1->field_f
    //     0xadf85c: ldur            d1, [x1, #0xf]
    // 0xadf860: fcmp            d0, d1
    // 0xadf864: b.vs            #0xadf93c
    // 0xadf868: b.ne            #0xadf93c
    // 0xadf86c: r1 = Null
    //     0xadf86c: mov             x1, NULL
    // 0xadf870: r2 = 6
    //     0xadf870: mov             x2, #6
    // 0xadf874: r0 = AllocateArray()
    //     0xadf874: bl              #0xd6987c  ; AllocateArrayStub
    // 0xadf878: stur            x0, [fp, #-8]
    // 0xadf87c: r17 = "BorderRadius.circular("
    //     0xadf87c: add             x17, PP, #0xe, lsl #12  ; [pp+0xe7f0] "BorderRadius.circular("
    //     0xadf880: ldr             x17, [x17, #0x7f0]
    // 0xadf884: StoreField: r0->field_f = r17
    //     0xadf884: stur            w17, [x0, #0xf]
    // 0xadf888: ldur            x1, [fp, #-0x18]
    // 0xadf88c: r17 = 4222
    //     0xadf88c: mov             x17, #0x107e
    // 0xadf890: cmp             w1, w17
    // 0xadf894: b.ne            #0xadf8ac
    // 0xadf898: ldr             x2, [fp, #0x10]
    // 0xadf89c: LoadField: r3 = r2->field_7
    //     0xadf89c: ldur            w3, [x2, #7]
    // 0xadf8a0: DecompressPointer r3
    //     0xadf8a0: add             x3, x3, HEAP, lsl #32
    // 0xadf8a4: mov             x4, x3
    // 0xadf8a8: b               #0xadf8bc
    // 0xadf8ac: ldr             x2, [fp, #0x10]
    // 0xadf8b0: LoadField: r3 = r2->field_7
    //     0xadf8b0: ldur            w3, [x2, #7]
    // 0xadf8b4: DecompressPointer r3
    //     0xadf8b4: add             x3, x3, HEAP, lsl #32
    // 0xadf8b8: mov             x4, x3
    // 0xadf8bc: r3 = 1
    //     0xadf8bc: mov             x3, #1
    // 0xadf8c0: LoadField: d0 = r4->field_7
    //     0xadf8c0: ldur            d0, [x4, #7]
    // 0xadf8c4: r4 = inline_Allocate_Double()
    //     0xadf8c4: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xadf8c8: add             x4, x4, #0x10
    //     0xadf8cc: cmp             x5, x4
    //     0xadf8d0: b.ls            #0xae0954
    //     0xadf8d4: str             x4, [THR, #0x60]  ; THR::top
    //     0xadf8d8: sub             x4, x4, #0xf
    //     0xadf8dc: mov             x5, #0xd108
    //     0xadf8e0: movk            x5, #3, lsl #16
    //     0xadf8e4: stur            x5, [x4, #-1]
    // 0xadf8e8: StoreField: r4->field_7 = d0
    //     0xadf8e8: stur            d0, [x4, #7]
    // 0xadf8ec: stp             x3, x4, [SP, #-0x10]!
    // 0xadf8f0: r0 = toStringAsFixed()
    //     0xadf8f0: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xadf8f4: add             SP, SP, #0x10
    // 0xadf8f8: ldur            x1, [fp, #-8]
    // 0xadf8fc: ArrayStore: r1[1] = r0  ; List_4
    //     0xadf8fc: add             x25, x1, #0x13
    //     0xadf900: str             w0, [x25]
    //     0xadf904: tbz             w0, #0, #0xadf920
    //     0xadf908: ldurb           w16, [x1, #-1]
    //     0xadf90c: ldurb           w17, [x0, #-1]
    //     0xadf910: and             x16, x17, x16, lsr #2
    //     0xadf914: tst             x16, HEAP, lsr #32
    //     0xadf918: b.eq            #0xadf920
    //     0xadf91c: bl              #0xd67e5c
    // 0xadf920: ldur            x0, [fp, #-8]
    // 0xadf924: r17 = ")"
    //     0xadf924: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xadf928: StoreField: r0->field_17 = r17
    //     0xadf928: stur            w17, [x0, #0x17]
    // 0xadf92c: SaveReg r0
    //     0xadf92c: str             x0, [SP, #-8]!
    // 0xadf930: r0 = _interpolate()
    //     0xadf930: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xadf934: add             SP, SP, #8
    // 0xadf938: b               #0xadf998
    // 0xadf93c: r1 = Null
    //     0xadf93c: mov             x1, NULL
    // 0xadf940: r2 = 6
    //     0xadf940: mov             x2, #6
    // 0xadf944: r0 = AllocateArray()
    //     0xadf944: bl              #0xd6987c  ; AllocateArrayStub
    // 0xadf948: r17 = "BorderRadius.all("
    //     0xadf948: add             x17, PP, #0xe, lsl #12  ; [pp+0xe7f8] "BorderRadius.all("
    //     0xadf94c: ldr             x17, [x17, #0x7f8]
    // 0xadf950: StoreField: r0->field_f = r17
    //     0xadf950: stur            w17, [x0, #0xf]
    // 0xadf954: ldur            x1, [fp, #-0x18]
    // 0xadf958: r17 = 4222
    //     0xadf958: mov             x17, #0x107e
    // 0xadf95c: cmp             w1, w17
    // 0xadf960: b.ne            #0xadf974
    // 0xadf964: ldr             x2, [fp, #0x10]
    // 0xadf968: LoadField: r3 = r2->field_7
    //     0xadf968: ldur            w3, [x2, #7]
    // 0xadf96c: DecompressPointer r3
    //     0xadf96c: add             x3, x3, HEAP, lsl #32
    // 0xadf970: b               #0xadf980
    // 0xadf974: ldr             x2, [fp, #0x10]
    // 0xadf978: LoadField: r3 = r2->field_7
    //     0xadf978: ldur            w3, [x2, #7]
    // 0xadf97c: DecompressPointer r3
    //     0xadf97c: add             x3, x3, HEAP, lsl #32
    // 0xadf980: StoreField: r0->field_13 = r3
    //     0xadf980: stur            w3, [x0, #0x13]
    // 0xadf984: r17 = ")"
    //     0xadf984: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xadf988: StoreField: r0->field_17 = r17
    //     0xadf988: stur            w17, [x0, #0x17]
    // 0xadf98c: SaveReg r0
    //     0xadf98c: str             x0, [SP, #-8]!
    // 0xadf990: r0 = _interpolate()
    //     0xadf990: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xadf994: add             SP, SP, #8
    // 0xadf998: mov             x1, x0
    // 0xadf99c: b               #0xadfec0
    // 0xadf9a0: ldur            x0, [fp, #-0x18]
    // 0xadf9a4: r0 = StringBuffer()
    //     0xadf9a4: bl              #0x4d1e30  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0xadf9a8: stur            x0, [fp, #-8]
    // 0xadf9ac: SaveReg r0
    //     0xadf9ac: str             x0, [SP, #-8]!
    // 0xadf9b0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xadf9b0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xadf9b4: r0 = StringBuffer()
    //     0xadf9b4: bl              #0x4d16e0  ; [dart:core] StringBuffer::StringBuffer
    // 0xadf9b8: add             SP, SP, #8
    // 0xadf9bc: ldur            x16, [fp, #-8]
    // 0xadf9c0: r30 = "BorderRadius.only("
    //     0xadf9c0: add             lr, PP, #0xe, lsl #12  ; [pp+0xe800] "BorderRadius.only("
    //     0xadf9c4: ldr             lr, [lr, #0x800]
    // 0xadf9c8: stp             lr, x16, [SP, #-0x10]!
    // 0xadf9cc: r0 = write()
    //     0xadf9cc: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xadf9d0: add             SP, SP, #0x10
    // 0xadf9d4: ldur            x0, [fp, #-0x18]
    // 0xadf9d8: r17 = 4222
    //     0xadf9d8: mov             x17, #0x107e
    // 0xadf9dc: cmp             w0, w17
    // 0xadf9e0: b.ne            #0xadf9f4
    // 0xadf9e4: ldr             x1, [fp, #0x10]
    // 0xadf9e8: LoadField: r2 = r1->field_7
    //     0xadf9e8: ldur            w2, [x1, #7]
    // 0xadf9ec: DecompressPointer r2
    //     0xadf9ec: add             x2, x2, HEAP, lsl #32
    // 0xadf9f0: b               #0xadfa00
    // 0xadf9f4: ldr             x1, [fp, #0x10]
    // 0xadf9f8: LoadField: r2 = r1->field_7
    //     0xadf9f8: ldur            w2, [x1, #7]
    // 0xadf9fc: DecompressPointer r2
    //     0xadf9fc: add             x2, x2, HEAP, lsl #32
    // 0xadfa00: stur            x2, [fp, #-0x10]
    // 0xadfa04: r16 = Instance_Radius
    //     0xadfa04: add             x16, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadfa08: ldr             x16, [x16, #0x478]
    // 0xadfa0c: cmp             w2, w16
    // 0xadfa10: b.ne            #0xadfa20
    // 0xadfa14: r3 = Instance_Radius
    //     0xadfa14: add             x3, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadfa18: ldr             x3, [x3, #0x478]
    // 0xadfa1c: b               #0xadfa7c
    // 0xadfa20: r16 = Radius
    //     0xadfa20: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xadfa24: ldr             x16, [x16, #0x470]
    // 0xadfa28: r30 = Radius
    //     0xadfa28: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xadfa2c: ldr             lr, [lr, #0x470]
    // 0xadfa30: stp             lr, x16, [SP, #-0x10]!
    // 0xadfa34: r0 = ==()
    //     0xadfa34: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xadfa38: add             SP, SP, #0x10
    // 0xadfa3c: tbz             w0, #4, #0xadfa4c
    // 0xadfa40: r3 = Instance_Radius
    //     0xadfa40: add             x3, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadfa44: ldr             x3, [x3, #0x478]
    // 0xadfa48: b               #0xadfa84
    // 0xadfa4c: ldur            x0, [fp, #-0x10]
    // 0xadfa50: r3 = Instance_Radius
    //     0xadfa50: add             x3, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadfa54: ldr             x3, [x3, #0x478]
    // 0xadfa58: LoadField: d0 = r3->field_7
    //     0xadfa58: ldur            d0, [x3, #7]
    // 0xadfa5c: LoadField: d1 = r0->field_7
    //     0xadfa5c: ldur            d1, [x0, #7]
    // 0xadfa60: fcmp            d0, d1
    // 0xadfa64: b.vs            #0xadfa84
    // 0xadfa68: b.ne            #0xadfa84
    // 0xadfa6c: LoadField: d0 = r3->field_f
    //     0xadfa6c: ldur            d0, [x3, #0xf]
    // 0xadfa70: LoadField: d1 = r0->field_f
    //     0xadfa70: ldur            d1, [x0, #0xf]
    // 0xadfa74: fcmp            d0, d1
    // 0xadfa78: b.ne            #0xadfa84
    // 0xadfa7c: r1 = false
    //     0xadfa7c: add             x1, NULL, #0x30  ; false
    // 0xadfa80: b               #0xadfaf0
    // 0xadfa84: ldur            x0, [fp, #-0x18]
    // 0xadfa88: r1 = Null
    //     0xadfa88: mov             x1, NULL
    // 0xadfa8c: r2 = 4
    //     0xadfa8c: mov             x2, #4
    // 0xadfa90: r0 = AllocateArray()
    //     0xadfa90: bl              #0xd6987c  ; AllocateArrayStub
    // 0xadfa94: r17 = "topLeft: "
    //     0xadfa94: add             x17, PP, #0xe, lsl #12  ; [pp+0xe808] "topLeft: "
    //     0xadfa98: ldr             x17, [x17, #0x808]
    // 0xadfa9c: StoreField: r0->field_f = r17
    //     0xadfa9c: stur            w17, [x0, #0xf]
    // 0xadfaa0: ldur            x1, [fp, #-0x18]
    // 0xadfaa4: r17 = 4222
    //     0xadfaa4: mov             x17, #0x107e
    // 0xadfaa8: cmp             w1, w17
    // 0xadfaac: b.ne            #0xadfac0
    // 0xadfab0: ldr             x2, [fp, #0x10]
    // 0xadfab4: LoadField: r3 = r2->field_7
    //     0xadfab4: ldur            w3, [x2, #7]
    // 0xadfab8: DecompressPointer r3
    //     0xadfab8: add             x3, x3, HEAP, lsl #32
    // 0xadfabc: b               #0xadfacc
    // 0xadfac0: ldr             x2, [fp, #0x10]
    // 0xadfac4: LoadField: r3 = r2->field_7
    //     0xadfac4: ldur            w3, [x2, #7]
    // 0xadfac8: DecompressPointer r3
    //     0xadfac8: add             x3, x3, HEAP, lsl #32
    // 0xadfacc: StoreField: r0->field_13 = r3
    //     0xadfacc: stur            w3, [x0, #0x13]
    // 0xadfad0: SaveReg r0
    //     0xadfad0: str             x0, [SP, #-8]!
    // 0xadfad4: r0 = _interpolate()
    //     0xadfad4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xadfad8: add             SP, SP, #8
    // 0xadfadc: ldur            x16, [fp, #-8]
    // 0xadfae0: stp             x0, x16, [SP, #-0x10]!
    // 0xadfae4: r0 = write()
    //     0xadfae4: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xadfae8: add             SP, SP, #0x10
    // 0xadfaec: r1 = true
    //     0xadfaec: add             x1, NULL, #0x20  ; true
    // 0xadfaf0: ldur            x0, [fp, #-0x18]
    // 0xadfaf4: stur            x1, [fp, #-0x20]
    // 0xadfaf8: r17 = 4222
    //     0xadfaf8: mov             x17, #0x107e
    // 0xadfafc: cmp             w0, w17
    // 0xadfb00: b.ne            #0xadfb14
    // 0xadfb04: ldr             x2, [fp, #0x10]
    // 0xadfb08: LoadField: r3 = r2->field_b
    //     0xadfb08: ldur            w3, [x2, #0xb]
    // 0xadfb0c: DecompressPointer r3
    //     0xadfb0c: add             x3, x3, HEAP, lsl #32
    // 0xadfb10: b               #0xadfb20
    // 0xadfb14: ldr             x2, [fp, #0x10]
    // 0xadfb18: LoadField: r3 = r2->field_b
    //     0xadfb18: ldur            w3, [x2, #0xb]
    // 0xadfb1c: DecompressPointer r3
    //     0xadfb1c: add             x3, x3, HEAP, lsl #32
    // 0xadfb20: stur            x3, [fp, #-0x10]
    // 0xadfb24: r16 = Instance_Radius
    //     0xadfb24: add             x16, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadfb28: ldr             x16, [x16, #0x478]
    // 0xadfb2c: cmp             w3, w16
    // 0xadfb30: b.ne            #0xadfb40
    // 0xadfb34: r1 = Instance_Radius
    //     0xadfb34: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadfb38: ldr             x1, [x1, #0x478]
    // 0xadfb3c: b               #0xadfb9c
    // 0xadfb40: r16 = Radius
    //     0xadfb40: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xadfb44: ldr             x16, [x16, #0x470]
    // 0xadfb48: r30 = Radius
    //     0xadfb48: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xadfb4c: ldr             lr, [lr, #0x470]
    // 0xadfb50: stp             lr, x16, [SP, #-0x10]!
    // 0xadfb54: r0 = ==()
    //     0xadfb54: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xadfb58: add             SP, SP, #0x10
    // 0xadfb5c: tbz             w0, #4, #0xadfb6c
    // 0xadfb60: r1 = Instance_Radius
    //     0xadfb60: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadfb64: ldr             x1, [x1, #0x478]
    // 0xadfb68: b               #0xadfba4
    // 0xadfb6c: ldur            x0, [fp, #-0x10]
    // 0xadfb70: r1 = Instance_Radius
    //     0xadfb70: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadfb74: ldr             x1, [x1, #0x478]
    // 0xadfb78: LoadField: d0 = r1->field_7
    //     0xadfb78: ldur            d0, [x1, #7]
    // 0xadfb7c: LoadField: d1 = r0->field_7
    //     0xadfb7c: ldur            d1, [x0, #7]
    // 0xadfb80: fcmp            d0, d1
    // 0xadfb84: b.vs            #0xadfba4
    // 0xadfb88: b.ne            #0xadfba4
    // 0xadfb8c: LoadField: d0 = r1->field_f
    //     0xadfb8c: ldur            d0, [x1, #0xf]
    // 0xadfb90: LoadField: d1 = r0->field_f
    //     0xadfb90: ldur            d1, [x0, #0xf]
    // 0xadfb94: fcmp            d0, d1
    // 0xadfb98: b.ne            #0xadfba4
    // 0xadfb9c: ldur            x1, [fp, #-0x20]
    // 0xadfba0: b               #0xadfc2c
    // 0xadfba4: ldur            x0, [fp, #-0x20]
    // 0xadfba8: tbnz            w0, #4, #0xadfbc0
    // 0xadfbac: ldur            x16, [fp, #-8]
    // 0xadfbb0: r30 = ", "
    //     0xadfbb0: ldr             lr, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xadfbb4: stp             lr, x16, [SP, #-0x10]!
    // 0xadfbb8: r0 = write()
    //     0xadfbb8: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xadfbbc: add             SP, SP, #0x10
    // 0xadfbc0: ldur            x0, [fp, #-0x18]
    // 0xadfbc4: r1 = Null
    //     0xadfbc4: mov             x1, NULL
    // 0xadfbc8: r2 = 4
    //     0xadfbc8: mov             x2, #4
    // 0xadfbcc: r0 = AllocateArray()
    //     0xadfbcc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xadfbd0: r17 = "topRight: "
    //     0xadfbd0: add             x17, PP, #0xe, lsl #12  ; [pp+0xe810] "topRight: "
    //     0xadfbd4: ldr             x17, [x17, #0x810]
    // 0xadfbd8: StoreField: r0->field_f = r17
    //     0xadfbd8: stur            w17, [x0, #0xf]
    // 0xadfbdc: ldur            x1, [fp, #-0x18]
    // 0xadfbe0: r17 = 4222
    //     0xadfbe0: mov             x17, #0x107e
    // 0xadfbe4: cmp             w1, w17
    // 0xadfbe8: b.ne            #0xadfbfc
    // 0xadfbec: ldr             x2, [fp, #0x10]
    // 0xadfbf0: LoadField: r3 = r2->field_b
    //     0xadfbf0: ldur            w3, [x2, #0xb]
    // 0xadfbf4: DecompressPointer r3
    //     0xadfbf4: add             x3, x3, HEAP, lsl #32
    // 0xadfbf8: b               #0xadfc08
    // 0xadfbfc: ldr             x2, [fp, #0x10]
    // 0xadfc00: LoadField: r3 = r2->field_b
    //     0xadfc00: ldur            w3, [x2, #0xb]
    // 0xadfc04: DecompressPointer r3
    //     0xadfc04: add             x3, x3, HEAP, lsl #32
    // 0xadfc08: StoreField: r0->field_13 = r3
    //     0xadfc08: stur            w3, [x0, #0x13]
    // 0xadfc0c: SaveReg r0
    //     0xadfc0c: str             x0, [SP, #-8]!
    // 0xadfc10: r0 = _interpolate()
    //     0xadfc10: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xadfc14: add             SP, SP, #8
    // 0xadfc18: ldur            x16, [fp, #-8]
    // 0xadfc1c: stp             x0, x16, [SP, #-0x10]!
    // 0xadfc20: r0 = write()
    //     0xadfc20: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xadfc24: add             SP, SP, #0x10
    // 0xadfc28: r1 = true
    //     0xadfc28: add             x1, NULL, #0x20  ; true
    // 0xadfc2c: ldur            x0, [fp, #-0x18]
    // 0xadfc30: stur            x1, [fp, #-0x20]
    // 0xadfc34: r17 = 4222
    //     0xadfc34: mov             x17, #0x107e
    // 0xadfc38: cmp             w0, w17
    // 0xadfc3c: b.ne            #0xadfc50
    // 0xadfc40: ldr             x2, [fp, #0x10]
    // 0xadfc44: LoadField: r3 = r2->field_f
    //     0xadfc44: ldur            w3, [x2, #0xf]
    // 0xadfc48: DecompressPointer r3
    //     0xadfc48: add             x3, x3, HEAP, lsl #32
    // 0xadfc4c: b               #0xadfc5c
    // 0xadfc50: ldr             x2, [fp, #0x10]
    // 0xadfc54: LoadField: r3 = r2->field_f
    //     0xadfc54: ldur            w3, [x2, #0xf]
    // 0xadfc58: DecompressPointer r3
    //     0xadfc58: add             x3, x3, HEAP, lsl #32
    // 0xadfc5c: stur            x3, [fp, #-0x10]
    // 0xadfc60: r16 = Instance_Radius
    //     0xadfc60: add             x16, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadfc64: ldr             x16, [x16, #0x478]
    // 0xadfc68: cmp             w3, w16
    // 0xadfc6c: b.ne            #0xadfc7c
    // 0xadfc70: r1 = Instance_Radius
    //     0xadfc70: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadfc74: ldr             x1, [x1, #0x478]
    // 0xadfc78: b               #0xadfcd8
    // 0xadfc7c: r16 = Radius
    //     0xadfc7c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xadfc80: ldr             x16, [x16, #0x470]
    // 0xadfc84: r30 = Radius
    //     0xadfc84: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xadfc88: ldr             lr, [lr, #0x470]
    // 0xadfc8c: stp             lr, x16, [SP, #-0x10]!
    // 0xadfc90: r0 = ==()
    //     0xadfc90: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xadfc94: add             SP, SP, #0x10
    // 0xadfc98: tbz             w0, #4, #0xadfca8
    // 0xadfc9c: r1 = Instance_Radius
    //     0xadfc9c: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadfca0: ldr             x1, [x1, #0x478]
    // 0xadfca4: b               #0xadfce0
    // 0xadfca8: ldur            x0, [fp, #-0x10]
    // 0xadfcac: r1 = Instance_Radius
    //     0xadfcac: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadfcb0: ldr             x1, [x1, #0x478]
    // 0xadfcb4: LoadField: d0 = r1->field_7
    //     0xadfcb4: ldur            d0, [x1, #7]
    // 0xadfcb8: LoadField: d1 = r0->field_7
    //     0xadfcb8: ldur            d1, [x0, #7]
    // 0xadfcbc: fcmp            d0, d1
    // 0xadfcc0: b.vs            #0xadfce0
    // 0xadfcc4: b.ne            #0xadfce0
    // 0xadfcc8: LoadField: d0 = r1->field_f
    //     0xadfcc8: ldur            d0, [x1, #0xf]
    // 0xadfccc: LoadField: d1 = r0->field_f
    //     0xadfccc: ldur            d1, [x0, #0xf]
    // 0xadfcd0: fcmp            d0, d1
    // 0xadfcd4: b.ne            #0xadfce0
    // 0xadfcd8: ldur            x1, [fp, #-0x20]
    // 0xadfcdc: b               #0xadfd68
    // 0xadfce0: ldur            x0, [fp, #-0x20]
    // 0xadfce4: tbnz            w0, #4, #0xadfcfc
    // 0xadfce8: ldur            x16, [fp, #-8]
    // 0xadfcec: r30 = ", "
    //     0xadfcec: ldr             lr, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xadfcf0: stp             lr, x16, [SP, #-0x10]!
    // 0xadfcf4: r0 = write()
    //     0xadfcf4: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xadfcf8: add             SP, SP, #0x10
    // 0xadfcfc: ldur            x0, [fp, #-0x18]
    // 0xadfd00: r1 = Null
    //     0xadfd00: mov             x1, NULL
    // 0xadfd04: r2 = 4
    //     0xadfd04: mov             x2, #4
    // 0xadfd08: r0 = AllocateArray()
    //     0xadfd08: bl              #0xd6987c  ; AllocateArrayStub
    // 0xadfd0c: r17 = "bottomLeft: "
    //     0xadfd0c: add             x17, PP, #0xe, lsl #12  ; [pp+0xe818] "bottomLeft: "
    //     0xadfd10: ldr             x17, [x17, #0x818]
    // 0xadfd14: StoreField: r0->field_f = r17
    //     0xadfd14: stur            w17, [x0, #0xf]
    // 0xadfd18: ldur            x1, [fp, #-0x18]
    // 0xadfd1c: r17 = 4222
    //     0xadfd1c: mov             x17, #0x107e
    // 0xadfd20: cmp             w1, w17
    // 0xadfd24: b.ne            #0xadfd38
    // 0xadfd28: ldr             x2, [fp, #0x10]
    // 0xadfd2c: LoadField: r3 = r2->field_f
    //     0xadfd2c: ldur            w3, [x2, #0xf]
    // 0xadfd30: DecompressPointer r3
    //     0xadfd30: add             x3, x3, HEAP, lsl #32
    // 0xadfd34: b               #0xadfd44
    // 0xadfd38: ldr             x2, [fp, #0x10]
    // 0xadfd3c: LoadField: r3 = r2->field_f
    //     0xadfd3c: ldur            w3, [x2, #0xf]
    // 0xadfd40: DecompressPointer r3
    //     0xadfd40: add             x3, x3, HEAP, lsl #32
    // 0xadfd44: StoreField: r0->field_13 = r3
    //     0xadfd44: stur            w3, [x0, #0x13]
    // 0xadfd48: SaveReg r0
    //     0xadfd48: str             x0, [SP, #-8]!
    // 0xadfd4c: r0 = _interpolate()
    //     0xadfd4c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xadfd50: add             SP, SP, #8
    // 0xadfd54: ldur            x16, [fp, #-8]
    // 0xadfd58: stp             x0, x16, [SP, #-0x10]!
    // 0xadfd5c: r0 = write()
    //     0xadfd5c: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xadfd60: add             SP, SP, #0x10
    // 0xadfd64: r1 = true
    //     0xadfd64: add             x1, NULL, #0x20  ; true
    // 0xadfd68: ldur            x0, [fp, #-0x18]
    // 0xadfd6c: stur            x1, [fp, #-0x20]
    // 0xadfd70: r17 = 4222
    //     0xadfd70: mov             x17, #0x107e
    // 0xadfd74: cmp             w0, w17
    // 0xadfd78: b.ne            #0xadfd8c
    // 0xadfd7c: ldr             x2, [fp, #0x10]
    // 0xadfd80: LoadField: r3 = r2->field_13
    //     0xadfd80: ldur            w3, [x2, #0x13]
    // 0xadfd84: DecompressPointer r3
    //     0xadfd84: add             x3, x3, HEAP, lsl #32
    // 0xadfd88: b               #0xadfd98
    // 0xadfd8c: ldr             x2, [fp, #0x10]
    // 0xadfd90: LoadField: r3 = r2->field_13
    //     0xadfd90: ldur            w3, [x2, #0x13]
    // 0xadfd94: DecompressPointer r3
    //     0xadfd94: add             x3, x3, HEAP, lsl #32
    // 0xadfd98: stur            x3, [fp, #-0x10]
    // 0xadfd9c: r16 = Instance_Radius
    //     0xadfd9c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadfda0: ldr             x16, [x16, #0x478]
    // 0xadfda4: cmp             w3, w16
    // 0xadfda8: b.ne            #0xadfdb8
    // 0xadfdac: r1 = Instance_Radius
    //     0xadfdac: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadfdb0: ldr             x1, [x1, #0x478]
    // 0xadfdb4: b               #0xadfe98
    // 0xadfdb8: r16 = Radius
    //     0xadfdb8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xadfdbc: ldr             x16, [x16, #0x470]
    // 0xadfdc0: r30 = Radius
    //     0xadfdc0: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xadfdc4: ldr             lr, [lr, #0x470]
    // 0xadfdc8: stp             lr, x16, [SP, #-0x10]!
    // 0xadfdcc: r0 = ==()
    //     0xadfdcc: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xadfdd0: add             SP, SP, #0x10
    // 0xadfdd4: tbz             w0, #4, #0xadfde4
    // 0xadfdd8: r1 = Instance_Radius
    //     0xadfdd8: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadfddc: ldr             x1, [x1, #0x478]
    // 0xadfde0: b               #0xadfe14
    // 0xadfde4: ldur            x0, [fp, #-0x10]
    // 0xadfde8: r1 = Instance_Radius
    //     0xadfde8: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadfdec: ldr             x1, [x1, #0x478]
    // 0xadfdf0: LoadField: d0 = r1->field_7
    //     0xadfdf0: ldur            d0, [x1, #7]
    // 0xadfdf4: LoadField: d1 = r0->field_7
    //     0xadfdf4: ldur            d1, [x0, #7]
    // 0xadfdf8: fcmp            d0, d1
    // 0xadfdfc: b.vs            #0xadfe14
    // 0xadfe00: b.ne            #0xadfe14
    // 0xadfe04: LoadField: d0 = r1->field_f
    //     0xadfe04: ldur            d0, [x1, #0xf]
    // 0xadfe08: LoadField: d1 = r0->field_f
    //     0xadfe08: ldur            d1, [x0, #0xf]
    // 0xadfe0c: fcmp            d0, d1
    // 0xadfe10: b.eq            #0xadfe98
    // 0xadfe14: ldur            x0, [fp, #-0x20]
    // 0xadfe18: tbnz            w0, #4, #0xadfe30
    // 0xadfe1c: ldur            x16, [fp, #-8]
    // 0xadfe20: r30 = ", "
    //     0xadfe20: ldr             lr, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xadfe24: stp             lr, x16, [SP, #-0x10]!
    // 0xadfe28: r0 = write()
    //     0xadfe28: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xadfe2c: add             SP, SP, #0x10
    // 0xadfe30: ldur            x0, [fp, #-0x18]
    // 0xadfe34: r1 = Null
    //     0xadfe34: mov             x1, NULL
    // 0xadfe38: r2 = 4
    //     0xadfe38: mov             x2, #4
    // 0xadfe3c: r0 = AllocateArray()
    //     0xadfe3c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xadfe40: r17 = "bottomRight: "
    //     0xadfe40: add             x17, PP, #0xe, lsl #12  ; [pp+0xe820] "bottomRight: "
    //     0xadfe44: ldr             x17, [x17, #0x820]
    // 0xadfe48: StoreField: r0->field_f = r17
    //     0xadfe48: stur            w17, [x0, #0xf]
    // 0xadfe4c: ldur            x1, [fp, #-0x18]
    // 0xadfe50: r17 = 4222
    //     0xadfe50: mov             x17, #0x107e
    // 0xadfe54: cmp             w1, w17
    // 0xadfe58: b.ne            #0xadfe6c
    // 0xadfe5c: ldr             x2, [fp, #0x10]
    // 0xadfe60: LoadField: r3 = r2->field_13
    //     0xadfe60: ldur            w3, [x2, #0x13]
    // 0xadfe64: DecompressPointer r3
    //     0xadfe64: add             x3, x3, HEAP, lsl #32
    // 0xadfe68: b               #0xadfe78
    // 0xadfe6c: ldr             x2, [fp, #0x10]
    // 0xadfe70: LoadField: r3 = r2->field_13
    //     0xadfe70: ldur            w3, [x2, #0x13]
    // 0xadfe74: DecompressPointer r3
    //     0xadfe74: add             x3, x3, HEAP, lsl #32
    // 0xadfe78: StoreField: r0->field_13 = r3
    //     0xadfe78: stur            w3, [x0, #0x13]
    // 0xadfe7c: SaveReg r0
    //     0xadfe7c: str             x0, [SP, #-8]!
    // 0xadfe80: r0 = _interpolate()
    //     0xadfe80: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xadfe84: add             SP, SP, #8
    // 0xadfe88: ldur            x16, [fp, #-8]
    // 0xadfe8c: stp             x0, x16, [SP, #-0x10]!
    // 0xadfe90: r0 = write()
    //     0xadfe90: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xadfe94: add             SP, SP, #0x10
    // 0xadfe98: ldur            x16, [fp, #-8]
    // 0xadfe9c: r30 = ")"
    //     0xadfe9c: ldr             lr, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xadfea0: stp             lr, x16, [SP, #-0x10]!
    // 0xadfea4: r0 = write()
    //     0xadfea4: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xadfea8: add             SP, SP, #0x10
    // 0xadfeac: ldur            x16, [fp, #-8]
    // 0xadfeb0: SaveReg r16
    //     0xadfeb0: str             x16, [SP, #-8]!
    // 0xadfeb4: r0 = toString()
    //     0xadfeb4: bl              #0xaba59c  ; [dart:core] StringBuffer::toString
    // 0xadfeb8: add             SP, SP, #8
    // 0xadfebc: mov             x1, x0
    // 0xadfec0: ldur            x0, [fp, #-0x18]
    // 0xadfec4: stur            x1, [fp, #-0x20]
    // 0xadfec8: r17 = 4222
    //     0xadfec8: mov             x17, #0x107e
    // 0xadfecc: cmp             w0, w17
    // 0xadfed0: b.ne            #0xadfee4
    // 0xadfed4: ldr             x2, [fp, #0x10]
    // 0xadfed8: LoadField: r3 = r2->field_17
    //     0xadfed8: ldur            w3, [x2, #0x17]
    // 0xadfedc: DecompressPointer r3
    //     0xadfedc: add             x3, x3, HEAP, lsl #32
    // 0xadfee0: b               #0xadfef0
    // 0xadfee4: ldr             x2, [fp, #0x10]
    // 0xadfee8: r3 = Instance_Radius
    //     0xadfee8: add             x3, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadfeec: ldr             x3, [x3, #0x478]
    // 0xadfef0: stur            x3, [fp, #-0x10]
    // 0xadfef4: r17 = 4222
    //     0xadfef4: mov             x17, #0x107e
    // 0xadfef8: cmp             w0, w17
    // 0xadfefc: b.ne            #0xadff0c
    // 0xadff00: LoadField: r4 = r2->field_1b
    //     0xadff00: ldur            w4, [x2, #0x1b]
    // 0xadff04: DecompressPointer r4
    //     0xadff04: add             x4, x4, HEAP, lsl #32
    // 0xadff08: b               #0xadff14
    // 0xadff0c: r4 = Instance_Radius
    //     0xadff0c: add             x4, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadff10: ldr             x4, [x4, #0x478]
    // 0xadff14: stur            x4, [fp, #-8]
    // 0xadff18: cmp             w3, w4
    // 0xadff1c: b.eq            #0xadff88
    // 0xadff20: r16 = Radius
    //     0xadff20: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xadff24: ldr             x16, [x16, #0x470]
    // 0xadff28: r30 = Radius
    //     0xadff28: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xadff2c: ldr             lr, [lr, #0x470]
    // 0xadff30: stp             lr, x16, [SP, #-0x10]!
    // 0xadff34: r0 = ==()
    //     0xadff34: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xadff38: add             SP, SP, #0x10
    // 0xadff3c: tbz             w0, #4, #0xadff54
    // 0xadff40: ldr             x3, [fp, #0x10]
    // 0xadff44: ldur            x2, [fp, #-0x18]
    // 0xadff48: r1 = Instance_Radius
    //     0xadff48: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadff4c: ldr             x1, [x1, #0x478]
    // 0xadff50: b               #0xae03a0
    // 0xadff54: ldur            x0, [fp, #-0x10]
    // 0xadff58: ldur            x1, [fp, #-8]
    // 0xadff5c: LoadField: d0 = r1->field_7
    //     0xadff5c: ldur            d0, [x1, #7]
    // 0xadff60: LoadField: d1 = r0->field_7
    //     0xadff60: ldur            d1, [x0, #7]
    // 0xadff64: fcmp            d0, d1
    // 0xadff68: b.vs            #0xae0390
    // 0xadff6c: b.ne            #0xae0390
    // 0xadff70: LoadField: d0 = r1->field_f
    //     0xadff70: ldur            d0, [x1, #0xf]
    // 0xadff74: LoadField: d1 = r0->field_f
    //     0xadff74: ldur            d1, [x0, #0xf]
    // 0xadff78: fcmp            d0, d1
    // 0xadff7c: b.vs            #0xae037c
    // 0xadff80: b.ne            #0xae037c
    // 0xadff84: ldur            x0, [fp, #-0x18]
    // 0xadff88: r17 = 4222
    //     0xadff88: mov             x17, #0x107e
    // 0xadff8c: cmp             w0, w17
    // 0xadff90: b.ne            #0xadffa4
    // 0xadff94: ldr             x1, [fp, #0x10]
    // 0xadff98: LoadField: r2 = r1->field_1b
    //     0xadff98: ldur            w2, [x1, #0x1b]
    // 0xadff9c: DecompressPointer r2
    //     0xadff9c: add             x2, x2, HEAP, lsl #32
    // 0xadffa0: b               #0xadffb0
    // 0xadffa4: ldr             x1, [fp, #0x10]
    // 0xadffa8: r2 = Instance_Radius
    //     0xadffa8: add             x2, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadffac: ldr             x2, [x2, #0x478]
    // 0xadffb0: stur            x2, [fp, #-0x10]
    // 0xadffb4: r17 = 4222
    //     0xadffb4: mov             x17, #0x107e
    // 0xadffb8: cmp             w0, w17
    // 0xadffbc: b.ne            #0xadffcc
    // 0xadffc0: LoadField: r3 = r1->field_23
    //     0xadffc0: ldur            w3, [x1, #0x23]
    // 0xadffc4: DecompressPointer r3
    //     0xadffc4: add             x3, x3, HEAP, lsl #32
    // 0xadffc8: b               #0xadffd4
    // 0xadffcc: r3 = Instance_Radius
    //     0xadffcc: add             x3, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xadffd0: ldr             x3, [x3, #0x478]
    // 0xadffd4: stur            x3, [fp, #-8]
    // 0xadffd8: cmp             w2, w3
    // 0xadffdc: b.eq            #0xae0048
    // 0xadffe0: r16 = Radius
    //     0xadffe0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xadffe4: ldr             x16, [x16, #0x470]
    // 0xadffe8: r30 = Radius
    //     0xadffe8: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xadffec: ldr             lr, [lr, #0x470]
    // 0xadfff0: stp             lr, x16, [SP, #-0x10]!
    // 0xadfff4: r0 = ==()
    //     0xadfff4: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xadfff8: add             SP, SP, #0x10
    // 0xadfffc: tbz             w0, #4, #0xae0014
    // 0xae0000: ldr             x3, [fp, #0x10]
    // 0xae0004: ldur            x2, [fp, #-0x18]
    // 0xae0008: r1 = Instance_Radius
    //     0xae0008: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae000c: ldr             x1, [x1, #0x478]
    // 0xae0010: b               #0xae03a0
    // 0xae0014: ldur            x0, [fp, #-0x10]
    // 0xae0018: ldur            x1, [fp, #-8]
    // 0xae001c: LoadField: d0 = r1->field_7
    //     0xae001c: ldur            d0, [x1, #7]
    // 0xae0020: LoadField: d1 = r0->field_7
    //     0xae0020: ldur            d1, [x0, #7]
    // 0xae0024: fcmp            d0, d1
    // 0xae0028: b.vs            #0xae0368
    // 0xae002c: b.ne            #0xae0368
    // 0xae0030: LoadField: d0 = r1->field_f
    //     0xae0030: ldur            d0, [x1, #0xf]
    // 0xae0034: LoadField: d1 = r0->field_f
    //     0xae0034: ldur            d1, [x0, #0xf]
    // 0xae0038: fcmp            d0, d1
    // 0xae003c: b.vs            #0xae0354
    // 0xae0040: b.ne            #0xae0354
    // 0xae0044: ldur            x0, [fp, #-0x18]
    // 0xae0048: r17 = 4222
    //     0xae0048: mov             x17, #0x107e
    // 0xae004c: cmp             w0, w17
    // 0xae0050: b.ne            #0xae0064
    // 0xae0054: ldr             x1, [fp, #0x10]
    // 0xae0058: LoadField: r2 = r1->field_23
    //     0xae0058: ldur            w2, [x1, #0x23]
    // 0xae005c: DecompressPointer r2
    //     0xae005c: add             x2, x2, HEAP, lsl #32
    // 0xae0060: b               #0xae0070
    // 0xae0064: ldr             x1, [fp, #0x10]
    // 0xae0068: r2 = Instance_Radius
    //     0xae0068: add             x2, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae006c: ldr             x2, [x2, #0x478]
    // 0xae0070: stur            x2, [fp, #-0x10]
    // 0xae0074: r17 = 4222
    //     0xae0074: mov             x17, #0x107e
    // 0xae0078: cmp             w0, w17
    // 0xae007c: b.ne            #0xae008c
    // 0xae0080: LoadField: r3 = r1->field_1f
    //     0xae0080: ldur            w3, [x1, #0x1f]
    // 0xae0084: DecompressPointer r3
    //     0xae0084: add             x3, x3, HEAP, lsl #32
    // 0xae0088: b               #0xae0094
    // 0xae008c: r3 = Instance_Radius
    //     0xae008c: add             x3, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0090: ldr             x3, [x3, #0x478]
    // 0xae0094: stur            x3, [fp, #-8]
    // 0xae0098: cmp             w2, w3
    // 0xae009c: b.eq            #0xae0108
    // 0xae00a0: r16 = Radius
    //     0xae00a0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xae00a4: ldr             x16, [x16, #0x470]
    // 0xae00a8: r30 = Radius
    //     0xae00a8: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xae00ac: ldr             lr, [lr, #0x470]
    // 0xae00b0: stp             lr, x16, [SP, #-0x10]!
    // 0xae00b4: r0 = ==()
    //     0xae00b4: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xae00b8: add             SP, SP, #0x10
    // 0xae00bc: tbz             w0, #4, #0xae00d4
    // 0xae00c0: ldr             x3, [fp, #0x10]
    // 0xae00c4: ldur            x2, [fp, #-0x18]
    // 0xae00c8: r1 = Instance_Radius
    //     0xae00c8: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae00cc: ldr             x1, [x1, #0x478]
    // 0xae00d0: b               #0xae03a0
    // 0xae00d4: ldur            x0, [fp, #-0x10]
    // 0xae00d8: ldur            x1, [fp, #-8]
    // 0xae00dc: LoadField: d0 = r1->field_7
    //     0xae00dc: ldur            d0, [x1, #7]
    // 0xae00e0: LoadField: d1 = r0->field_7
    //     0xae00e0: ldur            d1, [x0, #7]
    // 0xae00e4: fcmp            d0, d1
    // 0xae00e8: b.vs            #0xae0340
    // 0xae00ec: b.ne            #0xae0340
    // 0xae00f0: LoadField: d0 = r1->field_f
    //     0xae00f0: ldur            d0, [x1, #0xf]
    // 0xae00f4: LoadField: d1 = r0->field_f
    //     0xae00f4: ldur            d1, [x0, #0xf]
    // 0xae00f8: fcmp            d0, d1
    // 0xae00fc: b.vs            #0xae032c
    // 0xae0100: b.ne            #0xae032c
    // 0xae0104: ldur            x0, [fp, #-0x18]
    // 0xae0108: r17 = 4222
    //     0xae0108: mov             x17, #0x107e
    // 0xae010c: cmp             w0, w17
    // 0xae0110: b.ne            #0xae0124
    // 0xae0114: ldr             x1, [fp, #0x10]
    // 0xae0118: LoadField: r2 = r1->field_17
    //     0xae0118: ldur            w2, [x1, #0x17]
    // 0xae011c: DecompressPointer r2
    //     0xae011c: add             x2, x2, HEAP, lsl #32
    // 0xae0120: b               #0xae0130
    // 0xae0124: ldr             x1, [fp, #0x10]
    // 0xae0128: r2 = Instance_Radius
    //     0xae0128: add             x2, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae012c: ldr             x2, [x2, #0x478]
    // 0xae0130: stur            x2, [fp, #-8]
    // 0xae0134: r16 = Instance_Radius
    //     0xae0134: add             x16, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0138: ldr             x16, [x16, #0x478]
    // 0xae013c: cmp             w2, w16
    // 0xae0140: b.eq            #0xae0194
    // 0xae0144: r16 = Radius
    //     0xae0144: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xae0148: ldr             x16, [x16, #0x470]
    // 0xae014c: r30 = Radius
    //     0xae014c: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xae0150: ldr             lr, [lr, #0x470]
    // 0xae0154: stp             lr, x16, [SP, #-0x10]!
    // 0xae0158: r0 = ==()
    //     0xae0158: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xae015c: add             SP, SP, #0x10
    // 0xae0160: tbnz            w0, #4, #0xae019c
    // 0xae0164: ldur            x0, [fp, #-8]
    // 0xae0168: r1 = Instance_Radius
    //     0xae0168: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae016c: ldr             x1, [x1, #0x478]
    // 0xae0170: LoadField: d0 = r1->field_7
    //     0xae0170: ldur            d0, [x1, #7]
    // 0xae0174: LoadField: d1 = r0->field_7
    //     0xae0174: ldur            d1, [x0, #7]
    // 0xae0178: fcmp            d0, d1
    // 0xae017c: b.vs            #0xae019c
    // 0xae0180: b.ne            #0xae019c
    // 0xae0184: LoadField: d0 = r1->field_f
    //     0xae0184: ldur            d0, [x1, #0xf]
    // 0xae0188: LoadField: d1 = r0->field_f
    //     0xae0188: ldur            d1, [x0, #0xf]
    // 0xae018c: fcmp            d0, d1
    // 0xae0190: b.ne            #0xae019c
    // 0xae0194: r0 = Null
    //     0xae0194: mov             x0, NULL
    // 0xae0198: b               #0xae0324
    // 0xae019c: ldur            x0, [fp, #-0x18]
    // 0xae01a0: r17 = 4222
    //     0xae01a0: mov             x17, #0x107e
    // 0xae01a4: cmp             w0, w17
    // 0xae01a8: b.ne            #0xae01bc
    // 0xae01ac: ldr             x3, [fp, #0x10]
    // 0xae01b0: LoadField: r1 = r3->field_17
    //     0xae01b0: ldur            w1, [x3, #0x17]
    // 0xae01b4: DecompressPointer r1
    //     0xae01b4: add             x1, x1, HEAP, lsl #32
    // 0xae01b8: b               #0xae01c8
    // 0xae01bc: ldr             x3, [fp, #0x10]
    // 0xae01c0: r1 = Instance_Radius
    //     0xae01c0: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae01c4: ldr             x1, [x1, #0x478]
    // 0xae01c8: LoadField: d0 = r1->field_7
    //     0xae01c8: ldur            d0, [x1, #7]
    // 0xae01cc: r17 = 4222
    //     0xae01cc: mov             x17, #0x107e
    // 0xae01d0: cmp             w0, w17
    // 0xae01d4: b.ne            #0xae01e4
    // 0xae01d8: LoadField: r1 = r3->field_17
    //     0xae01d8: ldur            w1, [x3, #0x17]
    // 0xae01dc: DecompressPointer r1
    //     0xae01dc: add             x1, x1, HEAP, lsl #32
    // 0xae01e0: b               #0xae01ec
    // 0xae01e4: r1 = Instance_Radius
    //     0xae01e4: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae01e8: ldr             x1, [x1, #0x478]
    // 0xae01ec: LoadField: d1 = r1->field_f
    //     0xae01ec: ldur            d1, [x1, #0xf]
    // 0xae01f0: fcmp            d0, d1
    // 0xae01f4: b.vs            #0xae02c4
    // 0xae01f8: b.ne            #0xae02c4
    // 0xae01fc: r1 = Null
    //     0xae01fc: mov             x1, NULL
    // 0xae0200: r2 = 6
    //     0xae0200: mov             x2, #6
    // 0xae0204: r0 = AllocateArray()
    //     0xae0204: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae0208: stur            x0, [fp, #-8]
    // 0xae020c: r17 = "BorderRadiusDirectional.circular("
    //     0xae020c: add             x17, PP, #0xe, lsl #12  ; [pp+0xe828] "BorderRadiusDirectional.circular("
    //     0xae0210: ldr             x17, [x17, #0x828]
    // 0xae0214: StoreField: r0->field_f = r17
    //     0xae0214: stur            w17, [x0, #0xf]
    // 0xae0218: ldur            x3, [fp, #-0x18]
    // 0xae021c: r17 = 4222
    //     0xae021c: mov             x17, #0x107e
    // 0xae0220: cmp             w3, w17
    // 0xae0224: b.ne            #0xae023c
    // 0xae0228: ldr             x4, [fp, #0x10]
    // 0xae022c: LoadField: r1 = r4->field_17
    //     0xae022c: ldur            w1, [x4, #0x17]
    // 0xae0230: DecompressPointer r1
    //     0xae0230: add             x1, x1, HEAP, lsl #32
    // 0xae0234: mov             x2, x1
    // 0xae0238: b               #0xae0244
    // 0xae023c: r2 = Instance_Radius
    //     0xae023c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0240: ldr             x2, [x2, #0x478]
    // 0xae0244: r1 = 1
    //     0xae0244: mov             x1, #1
    // 0xae0248: LoadField: d0 = r2->field_7
    //     0xae0248: ldur            d0, [x2, #7]
    // 0xae024c: r2 = inline_Allocate_Double()
    //     0xae024c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xae0250: add             x2, x2, #0x10
    //     0xae0254: cmp             x3, x2
    //     0xae0258: b.ls            #0xae0978
    //     0xae025c: str             x2, [THR, #0x60]  ; THR::top
    //     0xae0260: sub             x2, x2, #0xf
    //     0xae0264: mov             x3, #0xd108
    //     0xae0268: movk            x3, #3, lsl #16
    //     0xae026c: stur            x3, [x2, #-1]
    // 0xae0270: StoreField: r2->field_7 = d0
    //     0xae0270: stur            d0, [x2, #7]
    // 0xae0274: stp             x1, x2, [SP, #-0x10]!
    // 0xae0278: r0 = toStringAsFixed()
    //     0xae0278: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae027c: add             SP, SP, #0x10
    // 0xae0280: ldur            x1, [fp, #-8]
    // 0xae0284: ArrayStore: r1[1] = r0  ; List_4
    //     0xae0284: add             x25, x1, #0x13
    //     0xae0288: str             w0, [x25]
    //     0xae028c: tbz             w0, #0, #0xae02a8
    //     0xae0290: ldurb           w16, [x1, #-1]
    //     0xae0294: ldurb           w17, [x0, #-1]
    //     0xae0298: and             x16, x17, x16, lsr #2
    //     0xae029c: tst             x16, HEAP, lsr #32
    //     0xae02a0: b.eq            #0xae02a8
    //     0xae02a4: bl              #0xd67e5c
    // 0xae02a8: ldur            x0, [fp, #-8]
    // 0xae02ac: r17 = ")"
    //     0xae02ac: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae02b0: StoreField: r0->field_17 = r17
    //     0xae02b0: stur            w17, [x0, #0x17]
    // 0xae02b4: SaveReg r0
    //     0xae02b4: str             x0, [SP, #-8]!
    // 0xae02b8: r0 = _interpolate()
    //     0xae02b8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae02bc: add             SP, SP, #8
    // 0xae02c0: b               #0xae0324
    // 0xae02c4: mov             x4, x3
    // 0xae02c8: mov             x3, x0
    // 0xae02cc: r1 = Null
    //     0xae02cc: mov             x1, NULL
    // 0xae02d0: r2 = 6
    //     0xae02d0: mov             x2, #6
    // 0xae02d4: r0 = AllocateArray()
    //     0xae02d4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae02d8: r17 = "BorderRadiusDirectional.all("
    //     0xae02d8: add             x17, PP, #0xe, lsl #12  ; [pp+0xe830] "BorderRadiusDirectional.all("
    //     0xae02dc: ldr             x17, [x17, #0x830]
    // 0xae02e0: StoreField: r0->field_f = r17
    //     0xae02e0: stur            w17, [x0, #0xf]
    // 0xae02e4: ldur            x2, [fp, #-0x18]
    // 0xae02e8: r17 = 4222
    //     0xae02e8: mov             x17, #0x107e
    // 0xae02ec: cmp             w2, w17
    // 0xae02f0: b.ne            #0xae0304
    // 0xae02f4: ldr             x3, [fp, #0x10]
    // 0xae02f8: LoadField: r1 = r3->field_17
    //     0xae02f8: ldur            w1, [x3, #0x17]
    // 0xae02fc: DecompressPointer r1
    //     0xae02fc: add             x1, x1, HEAP, lsl #32
    // 0xae0300: b               #0xae030c
    // 0xae0304: r1 = Instance_Radius
    //     0xae0304: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0308: ldr             x1, [x1, #0x478]
    // 0xae030c: StoreField: r0->field_13 = r1
    //     0xae030c: stur            w1, [x0, #0x13]
    // 0xae0310: r17 = ")"
    //     0xae0310: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae0314: StoreField: r0->field_17 = r17
    //     0xae0314: stur            w17, [x0, #0x17]
    // 0xae0318: SaveReg r0
    //     0xae0318: str             x0, [SP, #-8]!
    // 0xae031c: r0 = _interpolate()
    //     0xae031c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae0320: add             SP, SP, #8
    // 0xae0324: mov             x3, x0
    // 0xae0328: b               #0xae08a4
    // 0xae032c: ldr             x3, [fp, #0x10]
    // 0xae0330: ldur            x2, [fp, #-0x18]
    // 0xae0334: r1 = Instance_Radius
    //     0xae0334: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0338: ldr             x1, [x1, #0x478]
    // 0xae033c: b               #0xae03a0
    // 0xae0340: ldr             x3, [fp, #0x10]
    // 0xae0344: ldur            x2, [fp, #-0x18]
    // 0xae0348: r1 = Instance_Radius
    //     0xae0348: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae034c: ldr             x1, [x1, #0x478]
    // 0xae0350: b               #0xae03a0
    // 0xae0354: ldr             x3, [fp, #0x10]
    // 0xae0358: ldur            x2, [fp, #-0x18]
    // 0xae035c: r1 = Instance_Radius
    //     0xae035c: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0360: ldr             x1, [x1, #0x478]
    // 0xae0364: b               #0xae03a0
    // 0xae0368: ldr             x3, [fp, #0x10]
    // 0xae036c: ldur            x2, [fp, #-0x18]
    // 0xae0370: r1 = Instance_Radius
    //     0xae0370: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0374: ldr             x1, [x1, #0x478]
    // 0xae0378: b               #0xae03a0
    // 0xae037c: ldr             x3, [fp, #0x10]
    // 0xae0380: ldur            x2, [fp, #-0x18]
    // 0xae0384: r1 = Instance_Radius
    //     0xae0384: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0388: ldr             x1, [x1, #0x478]
    // 0xae038c: b               #0xae03a0
    // 0xae0390: ldr             x3, [fp, #0x10]
    // 0xae0394: ldur            x2, [fp, #-0x18]
    // 0xae0398: r1 = Instance_Radius
    //     0xae0398: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae039c: ldr             x1, [x1, #0x478]
    // 0xae03a0: r0 = StringBuffer()
    //     0xae03a0: bl              #0x4d1e30  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0xae03a4: stur            x0, [fp, #-8]
    // 0xae03a8: SaveReg r0
    //     0xae03a8: str             x0, [SP, #-8]!
    // 0xae03ac: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xae03ac: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xae03b0: r0 = StringBuffer()
    //     0xae03b0: bl              #0x4d16e0  ; [dart:core] StringBuffer::StringBuffer
    // 0xae03b4: add             SP, SP, #8
    // 0xae03b8: ldur            x16, [fp, #-8]
    // 0xae03bc: r30 = "BorderRadiusDirectional.only("
    //     0xae03bc: add             lr, PP, #0xe, lsl #12  ; [pp+0xe838] "BorderRadiusDirectional.only("
    //     0xae03c0: ldr             lr, [lr, #0x838]
    // 0xae03c4: stp             lr, x16, [SP, #-0x10]!
    // 0xae03c8: r0 = write()
    //     0xae03c8: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xae03cc: add             SP, SP, #0x10
    // 0xae03d0: ldur            x0, [fp, #-0x18]
    // 0xae03d4: r17 = 4222
    //     0xae03d4: mov             x17, #0x107e
    // 0xae03d8: cmp             w0, w17
    // 0xae03dc: b.ne            #0xae03f0
    // 0xae03e0: ldr             x1, [fp, #0x10]
    // 0xae03e4: LoadField: r2 = r1->field_17
    //     0xae03e4: ldur            w2, [x1, #0x17]
    // 0xae03e8: DecompressPointer r2
    //     0xae03e8: add             x2, x2, HEAP, lsl #32
    // 0xae03ec: b               #0xae03fc
    // 0xae03f0: ldr             x1, [fp, #0x10]
    // 0xae03f4: r2 = Instance_Radius
    //     0xae03f4: add             x2, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae03f8: ldr             x2, [x2, #0x478]
    // 0xae03fc: stur            x2, [fp, #-0x10]
    // 0xae0400: r16 = Instance_Radius
    //     0xae0400: add             x16, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0404: ldr             x16, [x16, #0x478]
    // 0xae0408: cmp             w2, w16
    // 0xae040c: b.ne            #0xae041c
    // 0xae0410: r3 = Instance_Radius
    //     0xae0410: add             x3, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0414: ldr             x3, [x3, #0x478]
    // 0xae0418: b               #0xae0478
    // 0xae041c: r16 = Radius
    //     0xae041c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xae0420: ldr             x16, [x16, #0x470]
    // 0xae0424: r30 = Radius
    //     0xae0424: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xae0428: ldr             lr, [lr, #0x470]
    // 0xae042c: stp             lr, x16, [SP, #-0x10]!
    // 0xae0430: r0 = ==()
    //     0xae0430: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xae0434: add             SP, SP, #0x10
    // 0xae0438: tbz             w0, #4, #0xae0448
    // 0xae043c: r3 = Instance_Radius
    //     0xae043c: add             x3, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0440: ldr             x3, [x3, #0x478]
    // 0xae0444: b               #0xae0480
    // 0xae0448: ldur            x0, [fp, #-0x10]
    // 0xae044c: r3 = Instance_Radius
    //     0xae044c: add             x3, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0450: ldr             x3, [x3, #0x478]
    // 0xae0454: LoadField: d0 = r3->field_7
    //     0xae0454: ldur            d0, [x3, #7]
    // 0xae0458: LoadField: d1 = r0->field_7
    //     0xae0458: ldur            d1, [x0, #7]
    // 0xae045c: fcmp            d0, d1
    // 0xae0460: b.vs            #0xae0480
    // 0xae0464: b.ne            #0xae0480
    // 0xae0468: LoadField: d0 = r3->field_f
    //     0xae0468: ldur            d0, [x3, #0xf]
    // 0xae046c: LoadField: d1 = r0->field_f
    //     0xae046c: ldur            d1, [x0, #0xf]
    // 0xae0470: fcmp            d0, d1
    // 0xae0474: b.ne            #0xae0480
    // 0xae0478: r1 = false
    //     0xae0478: add             x1, NULL, #0x30  ; false
    // 0xae047c: b               #0xae04ec
    // 0xae0480: ldur            x0, [fp, #-0x18]
    // 0xae0484: r1 = Null
    //     0xae0484: mov             x1, NULL
    // 0xae0488: r2 = 4
    //     0xae0488: mov             x2, #4
    // 0xae048c: r0 = AllocateArray()
    //     0xae048c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae0490: r17 = "topStart: "
    //     0xae0490: add             x17, PP, #0xe, lsl #12  ; [pp+0xe840] "topStart: "
    //     0xae0494: ldr             x17, [x17, #0x840]
    // 0xae0498: StoreField: r0->field_f = r17
    //     0xae0498: stur            w17, [x0, #0xf]
    // 0xae049c: ldur            x1, [fp, #-0x18]
    // 0xae04a0: r17 = 4222
    //     0xae04a0: mov             x17, #0x107e
    // 0xae04a4: cmp             w1, w17
    // 0xae04a8: b.ne            #0xae04bc
    // 0xae04ac: ldr             x2, [fp, #0x10]
    // 0xae04b0: LoadField: r3 = r2->field_17
    //     0xae04b0: ldur            w3, [x2, #0x17]
    // 0xae04b4: DecompressPointer r3
    //     0xae04b4: add             x3, x3, HEAP, lsl #32
    // 0xae04b8: b               #0xae04c8
    // 0xae04bc: ldr             x2, [fp, #0x10]
    // 0xae04c0: r3 = Instance_Radius
    //     0xae04c0: add             x3, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae04c4: ldr             x3, [x3, #0x478]
    // 0xae04c8: StoreField: r0->field_13 = r3
    //     0xae04c8: stur            w3, [x0, #0x13]
    // 0xae04cc: SaveReg r0
    //     0xae04cc: str             x0, [SP, #-8]!
    // 0xae04d0: r0 = _interpolate()
    //     0xae04d0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae04d4: add             SP, SP, #8
    // 0xae04d8: ldur            x16, [fp, #-8]
    // 0xae04dc: stp             x0, x16, [SP, #-0x10]!
    // 0xae04e0: r0 = write()
    //     0xae04e0: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xae04e4: add             SP, SP, #0x10
    // 0xae04e8: r1 = true
    //     0xae04e8: add             x1, NULL, #0x20  ; true
    // 0xae04ec: ldur            x0, [fp, #-0x18]
    // 0xae04f0: stur            x1, [fp, #-0x28]
    // 0xae04f4: r17 = 4222
    //     0xae04f4: mov             x17, #0x107e
    // 0xae04f8: cmp             w0, w17
    // 0xae04fc: b.ne            #0xae0510
    // 0xae0500: ldr             x2, [fp, #0x10]
    // 0xae0504: LoadField: r3 = r2->field_1b
    //     0xae0504: ldur            w3, [x2, #0x1b]
    // 0xae0508: DecompressPointer r3
    //     0xae0508: add             x3, x3, HEAP, lsl #32
    // 0xae050c: b               #0xae051c
    // 0xae0510: ldr             x2, [fp, #0x10]
    // 0xae0514: r3 = Instance_Radius
    //     0xae0514: add             x3, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0518: ldr             x3, [x3, #0x478]
    // 0xae051c: stur            x3, [fp, #-0x10]
    // 0xae0520: r16 = Instance_Radius
    //     0xae0520: add             x16, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0524: ldr             x16, [x16, #0x478]
    // 0xae0528: cmp             w3, w16
    // 0xae052c: b.ne            #0xae053c
    // 0xae0530: r1 = Instance_Radius
    //     0xae0530: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0534: ldr             x1, [x1, #0x478]
    // 0xae0538: b               #0xae0598
    // 0xae053c: r16 = Radius
    //     0xae053c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xae0540: ldr             x16, [x16, #0x470]
    // 0xae0544: r30 = Radius
    //     0xae0544: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xae0548: ldr             lr, [lr, #0x470]
    // 0xae054c: stp             lr, x16, [SP, #-0x10]!
    // 0xae0550: r0 = ==()
    //     0xae0550: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xae0554: add             SP, SP, #0x10
    // 0xae0558: tbz             w0, #4, #0xae0568
    // 0xae055c: r1 = Instance_Radius
    //     0xae055c: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0560: ldr             x1, [x1, #0x478]
    // 0xae0564: b               #0xae05a0
    // 0xae0568: ldur            x0, [fp, #-0x10]
    // 0xae056c: r1 = Instance_Radius
    //     0xae056c: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0570: ldr             x1, [x1, #0x478]
    // 0xae0574: LoadField: d0 = r1->field_7
    //     0xae0574: ldur            d0, [x1, #7]
    // 0xae0578: LoadField: d1 = r0->field_7
    //     0xae0578: ldur            d1, [x0, #7]
    // 0xae057c: fcmp            d0, d1
    // 0xae0580: b.vs            #0xae05a0
    // 0xae0584: b.ne            #0xae05a0
    // 0xae0588: LoadField: d0 = r1->field_f
    //     0xae0588: ldur            d0, [x1, #0xf]
    // 0xae058c: LoadField: d1 = r0->field_f
    //     0xae058c: ldur            d1, [x0, #0xf]
    // 0xae0590: fcmp            d0, d1
    // 0xae0594: b.ne            #0xae05a0
    // 0xae0598: ldur            x1, [fp, #-0x28]
    // 0xae059c: b               #0xae0628
    // 0xae05a0: ldur            x0, [fp, #-0x28]
    // 0xae05a4: tbnz            w0, #4, #0xae05bc
    // 0xae05a8: ldur            x16, [fp, #-8]
    // 0xae05ac: r30 = ", "
    //     0xae05ac: ldr             lr, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae05b0: stp             lr, x16, [SP, #-0x10]!
    // 0xae05b4: r0 = write()
    //     0xae05b4: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xae05b8: add             SP, SP, #0x10
    // 0xae05bc: ldur            x0, [fp, #-0x18]
    // 0xae05c0: r1 = Null
    //     0xae05c0: mov             x1, NULL
    // 0xae05c4: r2 = 4
    //     0xae05c4: mov             x2, #4
    // 0xae05c8: r0 = AllocateArray()
    //     0xae05c8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae05cc: r17 = "topEnd: "
    //     0xae05cc: add             x17, PP, #0xe, lsl #12  ; [pp+0xe848] "topEnd: "
    //     0xae05d0: ldr             x17, [x17, #0x848]
    // 0xae05d4: StoreField: r0->field_f = r17
    //     0xae05d4: stur            w17, [x0, #0xf]
    // 0xae05d8: ldur            x1, [fp, #-0x18]
    // 0xae05dc: r17 = 4222
    //     0xae05dc: mov             x17, #0x107e
    // 0xae05e0: cmp             w1, w17
    // 0xae05e4: b.ne            #0xae05f8
    // 0xae05e8: ldr             x2, [fp, #0x10]
    // 0xae05ec: LoadField: r3 = r2->field_1b
    //     0xae05ec: ldur            w3, [x2, #0x1b]
    // 0xae05f0: DecompressPointer r3
    //     0xae05f0: add             x3, x3, HEAP, lsl #32
    // 0xae05f4: b               #0xae0604
    // 0xae05f8: ldr             x2, [fp, #0x10]
    // 0xae05fc: r3 = Instance_Radius
    //     0xae05fc: add             x3, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0600: ldr             x3, [x3, #0x478]
    // 0xae0604: StoreField: r0->field_13 = r3
    //     0xae0604: stur            w3, [x0, #0x13]
    // 0xae0608: SaveReg r0
    //     0xae0608: str             x0, [SP, #-8]!
    // 0xae060c: r0 = _interpolate()
    //     0xae060c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae0610: add             SP, SP, #8
    // 0xae0614: ldur            x16, [fp, #-8]
    // 0xae0618: stp             x0, x16, [SP, #-0x10]!
    // 0xae061c: r0 = write()
    //     0xae061c: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xae0620: add             SP, SP, #0x10
    // 0xae0624: r1 = true
    //     0xae0624: add             x1, NULL, #0x20  ; true
    // 0xae0628: ldur            x0, [fp, #-0x18]
    // 0xae062c: stur            x1, [fp, #-0x28]
    // 0xae0630: r17 = 4222
    //     0xae0630: mov             x17, #0x107e
    // 0xae0634: cmp             w0, w17
    // 0xae0638: b.ne            #0xae064c
    // 0xae063c: ldr             x2, [fp, #0x10]
    // 0xae0640: LoadField: r3 = r2->field_1f
    //     0xae0640: ldur            w3, [x2, #0x1f]
    // 0xae0644: DecompressPointer r3
    //     0xae0644: add             x3, x3, HEAP, lsl #32
    // 0xae0648: b               #0xae0658
    // 0xae064c: ldr             x2, [fp, #0x10]
    // 0xae0650: r3 = Instance_Radius
    //     0xae0650: add             x3, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0654: ldr             x3, [x3, #0x478]
    // 0xae0658: stur            x3, [fp, #-0x10]
    // 0xae065c: r16 = Instance_Radius
    //     0xae065c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0660: ldr             x16, [x16, #0x478]
    // 0xae0664: cmp             w3, w16
    // 0xae0668: b.ne            #0xae0678
    // 0xae066c: r1 = Instance_Radius
    //     0xae066c: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0670: ldr             x1, [x1, #0x478]
    // 0xae0674: b               #0xae06d4
    // 0xae0678: r16 = Radius
    //     0xae0678: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xae067c: ldr             x16, [x16, #0x470]
    // 0xae0680: r30 = Radius
    //     0xae0680: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xae0684: ldr             lr, [lr, #0x470]
    // 0xae0688: stp             lr, x16, [SP, #-0x10]!
    // 0xae068c: r0 = ==()
    //     0xae068c: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xae0690: add             SP, SP, #0x10
    // 0xae0694: tbz             w0, #4, #0xae06a4
    // 0xae0698: r1 = Instance_Radius
    //     0xae0698: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae069c: ldr             x1, [x1, #0x478]
    // 0xae06a0: b               #0xae06dc
    // 0xae06a4: ldur            x0, [fp, #-0x10]
    // 0xae06a8: r1 = Instance_Radius
    //     0xae06a8: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae06ac: ldr             x1, [x1, #0x478]
    // 0xae06b0: LoadField: d0 = r1->field_7
    //     0xae06b0: ldur            d0, [x1, #7]
    // 0xae06b4: LoadField: d1 = r0->field_7
    //     0xae06b4: ldur            d1, [x0, #7]
    // 0xae06b8: fcmp            d0, d1
    // 0xae06bc: b.vs            #0xae06dc
    // 0xae06c0: b.ne            #0xae06dc
    // 0xae06c4: LoadField: d0 = r1->field_f
    //     0xae06c4: ldur            d0, [x1, #0xf]
    // 0xae06c8: LoadField: d1 = r0->field_f
    //     0xae06c8: ldur            d1, [x0, #0xf]
    // 0xae06cc: fcmp            d0, d1
    // 0xae06d0: b.ne            #0xae06dc
    // 0xae06d4: ldur            x1, [fp, #-0x28]
    // 0xae06d8: b               #0xae0764
    // 0xae06dc: ldur            x0, [fp, #-0x28]
    // 0xae06e0: tbnz            w0, #4, #0xae06f8
    // 0xae06e4: ldur            x16, [fp, #-8]
    // 0xae06e8: r30 = ", "
    //     0xae06e8: ldr             lr, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae06ec: stp             lr, x16, [SP, #-0x10]!
    // 0xae06f0: r0 = write()
    //     0xae06f0: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xae06f4: add             SP, SP, #0x10
    // 0xae06f8: ldur            x0, [fp, #-0x18]
    // 0xae06fc: r1 = Null
    //     0xae06fc: mov             x1, NULL
    // 0xae0700: r2 = 4
    //     0xae0700: mov             x2, #4
    // 0xae0704: r0 = AllocateArray()
    //     0xae0704: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae0708: r17 = "bottomStart: "
    //     0xae0708: add             x17, PP, #0xe, lsl #12  ; [pp+0xe850] "bottomStart: "
    //     0xae070c: ldr             x17, [x17, #0x850]
    // 0xae0710: StoreField: r0->field_f = r17
    //     0xae0710: stur            w17, [x0, #0xf]
    // 0xae0714: ldur            x1, [fp, #-0x18]
    // 0xae0718: r17 = 4222
    //     0xae0718: mov             x17, #0x107e
    // 0xae071c: cmp             w1, w17
    // 0xae0720: b.ne            #0xae0734
    // 0xae0724: ldr             x2, [fp, #0x10]
    // 0xae0728: LoadField: r3 = r2->field_1f
    //     0xae0728: ldur            w3, [x2, #0x1f]
    // 0xae072c: DecompressPointer r3
    //     0xae072c: add             x3, x3, HEAP, lsl #32
    // 0xae0730: b               #0xae0740
    // 0xae0734: ldr             x2, [fp, #0x10]
    // 0xae0738: r3 = Instance_Radius
    //     0xae0738: add             x3, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae073c: ldr             x3, [x3, #0x478]
    // 0xae0740: StoreField: r0->field_13 = r3
    //     0xae0740: stur            w3, [x0, #0x13]
    // 0xae0744: SaveReg r0
    //     0xae0744: str             x0, [SP, #-8]!
    // 0xae0748: r0 = _interpolate()
    //     0xae0748: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae074c: add             SP, SP, #8
    // 0xae0750: ldur            x16, [fp, #-8]
    // 0xae0754: stp             x0, x16, [SP, #-0x10]!
    // 0xae0758: r0 = write()
    //     0xae0758: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xae075c: add             SP, SP, #0x10
    // 0xae0760: r1 = true
    //     0xae0760: add             x1, NULL, #0x20  ; true
    // 0xae0764: ldur            x0, [fp, #-0x18]
    // 0xae0768: stur            x1, [fp, #-0x28]
    // 0xae076c: r17 = 4222
    //     0xae076c: mov             x17, #0x107e
    // 0xae0770: cmp             w0, w17
    // 0xae0774: b.ne            #0xae0788
    // 0xae0778: ldr             x2, [fp, #0x10]
    // 0xae077c: LoadField: r3 = r2->field_23
    //     0xae077c: ldur            w3, [x2, #0x23]
    // 0xae0780: DecompressPointer r3
    //     0xae0780: add             x3, x3, HEAP, lsl #32
    // 0xae0784: b               #0xae0794
    // 0xae0788: ldr             x2, [fp, #0x10]
    // 0xae078c: r3 = Instance_Radius
    //     0xae078c: add             x3, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0790: ldr             x3, [x3, #0x478]
    // 0xae0794: stur            x3, [fp, #-0x10]
    // 0xae0798: r16 = Instance_Radius
    //     0xae0798: add             x16, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae079c: ldr             x16, [x16, #0x478]
    // 0xae07a0: cmp             w3, w16
    // 0xae07a4: b.eq            #0xae087c
    // 0xae07a8: r16 = Radius
    //     0xae07a8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xae07ac: ldr             x16, [x16, #0x470]
    // 0xae07b0: r30 = Radius
    //     0xae07b0: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xae07b4: ldr             lr, [lr, #0x470]
    // 0xae07b8: stp             lr, x16, [SP, #-0x10]!
    // 0xae07bc: r0 = ==()
    //     0xae07bc: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xae07c0: add             SP, SP, #0x10
    // 0xae07c4: tbnz            w0, #4, #0xae07f8
    // 0xae07c8: ldur            x0, [fp, #-0x10]
    // 0xae07cc: r1 = Instance_Radius
    //     0xae07cc: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae07d0: ldr             x1, [x1, #0x478]
    // 0xae07d4: LoadField: d0 = r1->field_7
    //     0xae07d4: ldur            d0, [x1, #7]
    // 0xae07d8: LoadField: d1 = r0->field_7
    //     0xae07d8: ldur            d1, [x0, #7]
    // 0xae07dc: fcmp            d0, d1
    // 0xae07e0: b.vs            #0xae07f8
    // 0xae07e4: b.ne            #0xae07f8
    // 0xae07e8: LoadField: d0 = r1->field_f
    //     0xae07e8: ldur            d0, [x1, #0xf]
    // 0xae07ec: LoadField: d1 = r0->field_f
    //     0xae07ec: ldur            d1, [x0, #0xf]
    // 0xae07f0: fcmp            d0, d1
    // 0xae07f4: b.eq            #0xae087c
    // 0xae07f8: ldur            x0, [fp, #-0x28]
    // 0xae07fc: tbnz            w0, #4, #0xae0814
    // 0xae0800: ldur            x16, [fp, #-8]
    // 0xae0804: r30 = ", "
    //     0xae0804: ldr             lr, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae0808: stp             lr, x16, [SP, #-0x10]!
    // 0xae080c: r0 = write()
    //     0xae080c: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xae0810: add             SP, SP, #0x10
    // 0xae0814: ldur            x0, [fp, #-0x18]
    // 0xae0818: r1 = Null
    //     0xae0818: mov             x1, NULL
    // 0xae081c: r2 = 4
    //     0xae081c: mov             x2, #4
    // 0xae0820: r0 = AllocateArray()
    //     0xae0820: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae0824: r17 = "bottomEnd: "
    //     0xae0824: add             x17, PP, #0xe, lsl #12  ; [pp+0xe858] "bottomEnd: "
    //     0xae0828: ldr             x17, [x17, #0x858]
    // 0xae082c: StoreField: r0->field_f = r17
    //     0xae082c: stur            w17, [x0, #0xf]
    // 0xae0830: ldur            x1, [fp, #-0x18]
    // 0xae0834: r17 = 4222
    //     0xae0834: mov             x17, #0x107e
    // 0xae0838: cmp             w1, w17
    // 0xae083c: b.ne            #0xae0854
    // 0xae0840: ldr             x1, [fp, #0x10]
    // 0xae0844: LoadField: r2 = r1->field_23
    //     0xae0844: ldur            w2, [x1, #0x23]
    // 0xae0848: DecompressPointer r2
    //     0xae0848: add             x2, x2, HEAP, lsl #32
    // 0xae084c: mov             x1, x2
    // 0xae0850: b               #0xae085c
    // 0xae0854: r1 = Instance_Radius
    //     0xae0854: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xae0858: ldr             x1, [x1, #0x478]
    // 0xae085c: StoreField: r0->field_13 = r1
    //     0xae085c: stur            w1, [x0, #0x13]
    // 0xae0860: SaveReg r0
    //     0xae0860: str             x0, [SP, #-8]!
    // 0xae0864: r0 = _interpolate()
    //     0xae0864: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae0868: add             SP, SP, #8
    // 0xae086c: ldur            x16, [fp, #-8]
    // 0xae0870: stp             x0, x16, [SP, #-0x10]!
    // 0xae0874: r0 = write()
    //     0xae0874: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xae0878: add             SP, SP, #0x10
    // 0xae087c: ldur            x16, [fp, #-8]
    // 0xae0880: r30 = ")"
    //     0xae0880: ldr             lr, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae0884: stp             lr, x16, [SP, #-0x10]!
    // 0xae0888: r0 = write()
    //     0xae0888: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xae088c: add             SP, SP, #0x10
    // 0xae0890: ldur            x16, [fp, #-8]
    // 0xae0894: SaveReg r16
    //     0xae0894: str             x16, [SP, #-8]!
    // 0xae0898: r0 = toString()
    //     0xae0898: bl              #0xaba59c  ; [dart:core] StringBuffer::toString
    // 0xae089c: add             SP, SP, #8
    // 0xae08a0: mov             x3, x0
    // 0xae08a4: ldur            x0, [fp, #-0x20]
    // 0xae08a8: stur            x3, [fp, #-8]
    // 0xae08ac: cmp             w0, NULL
    // 0xae08b0: b.eq            #0xae0908
    // 0xae08b4: cmp             w3, NULL
    // 0xae08b8: b.eq            #0xae0900
    // 0xae08bc: r1 = Null
    //     0xae08bc: mov             x1, NULL
    // 0xae08c0: r2 = 6
    //     0xae08c0: mov             x2, #6
    // 0xae08c4: r0 = AllocateArray()
    //     0xae08c4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae08c8: mov             x1, x0
    // 0xae08cc: ldur            x0, [fp, #-0x20]
    // 0xae08d0: StoreField: r1->field_f = r0
    //     0xae08d0: stur            w0, [x1, #0xf]
    // 0xae08d4: r17 = " + "
    //     0xae08d4: add             x17, PP, #0xe, lsl #12  ; [pp+0xe860] " + "
    //     0xae08d8: ldr             x17, [x17, #0x860]
    // 0xae08dc: StoreField: r1->field_13 = r17
    //     0xae08dc: stur            w17, [x1, #0x13]
    // 0xae08e0: ldur            x2, [fp, #-8]
    // 0xae08e4: StoreField: r1->field_17 = r2
    //     0xae08e4: stur            w2, [x1, #0x17]
    // 0xae08e8: SaveReg r1
    //     0xae08e8: str             x1, [SP, #-8]!
    // 0xae08ec: r0 = _interpolate()
    //     0xae08ec: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae08f0: add             SP, SP, #8
    // 0xae08f4: LeaveFrame
    //     0xae08f4: mov             SP, fp
    //     0xae08f8: ldp             fp, lr, [SP], #0x10
    // 0xae08fc: ret
    //     0xae08fc: ret             
    // 0xae0900: mov             x2, x3
    // 0xae0904: b               #0xae090c
    // 0xae0908: mov             x2, x3
    // 0xae090c: cmp             w0, NULL
    // 0xae0910: b.eq            #0xae0920
    // 0xae0914: LeaveFrame
    //     0xae0914: mov             SP, fp
    //     0xae0918: ldp             fp, lr, [SP], #0x10
    // 0xae091c: ret
    //     0xae091c: ret             
    // 0xae0920: cmp             w2, NULL
    // 0xae0924: b.eq            #0xae0938
    // 0xae0928: mov             x0, x2
    // 0xae092c: LeaveFrame
    //     0xae092c: mov             SP, fp
    //     0xae0930: ldp             fp, lr, [SP], #0x10
    // 0xae0934: ret
    //     0xae0934: ret             
    // 0xae0938: r0 = "BorderRadius.zero"
    //     0xae0938: add             x0, PP, #0xe, lsl #12  ; [pp+0xe868] "BorderRadius.zero"
    //     0xae093c: ldr             x0, [x0, #0x868]
    // 0xae0940: LeaveFrame
    //     0xae0940: mov             SP, fp
    //     0xae0944: ldp             fp, lr, [SP], #0x10
    // 0xae0948: ret
    //     0xae0948: ret             
    // 0xae094c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae094c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae0950: b               #0xadf548
    // 0xae0954: SaveReg d0
    //     0xae0954: str             q0, [SP, #-0x10]!
    // 0xae0958: stp             x2, x3, [SP, #-0x10]!
    // 0xae095c: stp             x0, x1, [SP, #-0x10]!
    // 0xae0960: r0 = AllocateDouble()
    //     0xae0960: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae0964: mov             x4, x0
    // 0xae0968: ldp             x0, x1, [SP], #0x10
    // 0xae096c: ldp             x2, x3, [SP], #0x10
    // 0xae0970: RestoreReg d0
    //     0xae0970: ldr             q0, [SP], #0x10
    // 0xae0974: b               #0xadf8e8
    // 0xae0978: SaveReg d0
    //     0xae0978: str             q0, [SP, #-0x10]!
    // 0xae097c: stp             x0, x1, [SP, #-0x10]!
    // 0xae0980: r0 = AllocateDouble()
    //     0xae0980: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae0984: mov             x2, x0
    // 0xae0988: ldp             x0, x1, [SP], #0x10
    // 0xae098c: RestoreReg d0
    //     0xae098c: ldr             q0, [SP], #0x10
    // 0xae0990: b               #0xae0270
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb0e240, size: 0x170
    // 0xb0e240: EnterFrame
    //     0xb0e240: stp             fp, lr, [SP, #-0x10]!
    //     0xb0e244: mov             fp, SP
    // 0xb0e248: CheckStackOverflow
    //     0xb0e248: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0e24c: cmp             SP, x16
    //     0xb0e250: b.ls            #0xb0e3a8
    // 0xb0e254: ldr             x0, [fp, #0x10]
    // 0xb0e258: r1 = LoadClassIdInstr(r0)
    //     0xb0e258: ldur            x1, [x0, #-1]
    //     0xb0e25c: ubfx            x1, x1, #0xc, #0x14
    // 0xb0e260: lsl             x1, x1, #1
    // 0xb0e264: r17 = 4222
    //     0xb0e264: mov             x17, #0x107e
    // 0xb0e268: cmp             w1, w17
    // 0xb0e26c: b.ne            #0xb0e27c
    // 0xb0e270: LoadField: r2 = r0->field_7
    //     0xb0e270: ldur            w2, [x0, #7]
    // 0xb0e274: DecompressPointer r2
    //     0xb0e274: add             x2, x2, HEAP, lsl #32
    // 0xb0e278: b               #0xb0e284
    // 0xb0e27c: LoadField: r2 = r0->field_7
    //     0xb0e27c: ldur            w2, [x0, #7]
    // 0xb0e280: DecompressPointer r2
    //     0xb0e280: add             x2, x2, HEAP, lsl #32
    // 0xb0e284: r17 = 4222
    //     0xb0e284: mov             x17, #0x107e
    // 0xb0e288: cmp             w1, w17
    // 0xb0e28c: b.ne            #0xb0e29c
    // 0xb0e290: LoadField: r3 = r0->field_b
    //     0xb0e290: ldur            w3, [x0, #0xb]
    // 0xb0e294: DecompressPointer r3
    //     0xb0e294: add             x3, x3, HEAP, lsl #32
    // 0xb0e298: b               #0xb0e2a4
    // 0xb0e29c: LoadField: r3 = r0->field_b
    //     0xb0e29c: ldur            w3, [x0, #0xb]
    // 0xb0e2a0: DecompressPointer r3
    //     0xb0e2a0: add             x3, x3, HEAP, lsl #32
    // 0xb0e2a4: r17 = 4222
    //     0xb0e2a4: mov             x17, #0x107e
    // 0xb0e2a8: cmp             w1, w17
    // 0xb0e2ac: b.ne            #0xb0e2bc
    // 0xb0e2b0: LoadField: r4 = r0->field_f
    //     0xb0e2b0: ldur            w4, [x0, #0xf]
    // 0xb0e2b4: DecompressPointer r4
    //     0xb0e2b4: add             x4, x4, HEAP, lsl #32
    // 0xb0e2b8: b               #0xb0e2c4
    // 0xb0e2bc: LoadField: r4 = r0->field_f
    //     0xb0e2bc: ldur            w4, [x0, #0xf]
    // 0xb0e2c0: DecompressPointer r4
    //     0xb0e2c0: add             x4, x4, HEAP, lsl #32
    // 0xb0e2c4: r17 = 4222
    //     0xb0e2c4: mov             x17, #0x107e
    // 0xb0e2c8: cmp             w1, w17
    // 0xb0e2cc: b.ne            #0xb0e2dc
    // 0xb0e2d0: LoadField: r5 = r0->field_13
    //     0xb0e2d0: ldur            w5, [x0, #0x13]
    // 0xb0e2d4: DecompressPointer r5
    //     0xb0e2d4: add             x5, x5, HEAP, lsl #32
    // 0xb0e2d8: b               #0xb0e2e4
    // 0xb0e2dc: LoadField: r5 = r0->field_13
    //     0xb0e2dc: ldur            w5, [x0, #0x13]
    // 0xb0e2e0: DecompressPointer r5
    //     0xb0e2e0: add             x5, x5, HEAP, lsl #32
    // 0xb0e2e4: r17 = 4222
    //     0xb0e2e4: mov             x17, #0x107e
    // 0xb0e2e8: cmp             w1, w17
    // 0xb0e2ec: b.ne            #0xb0e2fc
    // 0xb0e2f0: LoadField: r6 = r0->field_17
    //     0xb0e2f0: ldur            w6, [x0, #0x17]
    // 0xb0e2f4: DecompressPointer r6
    //     0xb0e2f4: add             x6, x6, HEAP, lsl #32
    // 0xb0e2f8: b               #0xb0e304
    // 0xb0e2fc: r6 = Instance_Radius
    //     0xb0e2fc: add             x6, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xb0e300: ldr             x6, [x6, #0x478]
    // 0xb0e304: r17 = 4222
    //     0xb0e304: mov             x17, #0x107e
    // 0xb0e308: cmp             w1, w17
    // 0xb0e30c: b.ne            #0xb0e31c
    // 0xb0e310: LoadField: r7 = r0->field_1b
    //     0xb0e310: ldur            w7, [x0, #0x1b]
    // 0xb0e314: DecompressPointer r7
    //     0xb0e314: add             x7, x7, HEAP, lsl #32
    // 0xb0e318: b               #0xb0e324
    // 0xb0e31c: r7 = Instance_Radius
    //     0xb0e31c: add             x7, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xb0e320: ldr             x7, [x7, #0x478]
    // 0xb0e324: r17 = 4222
    //     0xb0e324: mov             x17, #0x107e
    // 0xb0e328: cmp             w1, w17
    // 0xb0e32c: b.ne            #0xb0e33c
    // 0xb0e330: LoadField: r8 = r0->field_1f
    //     0xb0e330: ldur            w8, [x0, #0x1f]
    // 0xb0e334: DecompressPointer r8
    //     0xb0e334: add             x8, x8, HEAP, lsl #32
    // 0xb0e338: b               #0xb0e344
    // 0xb0e33c: r8 = Instance_Radius
    //     0xb0e33c: add             x8, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xb0e340: ldr             x8, [x8, #0x478]
    // 0xb0e344: r17 = 4222
    //     0xb0e344: mov             x17, #0x107e
    // 0xb0e348: cmp             w1, w17
    // 0xb0e34c: b.ne            #0xb0e360
    // 0xb0e350: LoadField: r1 = r0->field_23
    //     0xb0e350: ldur            w1, [x0, #0x23]
    // 0xb0e354: DecompressPointer r1
    //     0xb0e354: add             x1, x1, HEAP, lsl #32
    // 0xb0e358: mov             x0, x1
    // 0xb0e35c: b               #0xb0e368
    // 0xb0e360: r0 = Instance_Radius
    //     0xb0e360: add             x0, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xb0e364: ldr             x0, [x0, #0x478]
    // 0xb0e368: stp             x3, x2, [SP, #-0x10]!
    // 0xb0e36c: stp             x5, x4, [SP, #-0x10]!
    // 0xb0e370: stp             x7, x6, [SP, #-0x10]!
    // 0xb0e374: stp             x0, x8, [SP, #-0x10]!
    // 0xb0e378: r4 = const [0, 0x8, 0x8, 0x8, null]
    //     0xb0e378: ldr             x4, [PP, #0x6da0]  ; [pp+0x6da0] List(5) [0, 0x8, 0x8, 0x8, Null]
    // 0xb0e37c: r0 = hash()
    //     0xb0e37c: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0e380: add             SP, SP, #0x40
    // 0xb0e384: mov             x2, x0
    // 0xb0e388: r0 = BoxInt64Instr(r2)
    //     0xb0e388: sbfiz           x0, x2, #1, #0x1f
    //     0xb0e38c: cmp             x2, x0, asr #1
    //     0xb0e390: b.eq            #0xb0e39c
    //     0xb0e394: bl              #0xd69bb8
    //     0xb0e398: stur            x2, [x0, #7]
    // 0xb0e39c: LeaveFrame
    //     0xb0e39c: mov             SP, fp
    //     0xb0e3a0: ldp             fp, lr, [SP], #0x10
    // 0xb0e3a4: ret
    //     0xb0e3a4: ret             
    // 0xb0e3a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0e3a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0e3ac: b               #0xb0e254
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9c94c, size: 0x728
    // 0xc9c94c: EnterFrame
    //     0xc9c94c: stp             fp, lr, [SP, #-0x10]!
    //     0xc9c950: mov             fp, SP
    // 0xc9c954: AllocStack(0x20)
    //     0xc9c954: sub             SP, SP, #0x20
    // 0xc9c958: CheckStackOverflow
    //     0xc9c958: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc9c95c: cmp             SP, x16
    //     0xc9c960: b.ls            #0xc9d06c
    // 0xc9c964: ldr             x1, [fp, #0x10]
    // 0xc9c968: cmp             w1, NULL
    // 0xc9c96c: b.ne            #0xc9c980
    // 0xc9c970: r0 = false
    //     0xc9c970: add             x0, NULL, #0x30  ; false
    // 0xc9c974: LeaveFrame
    //     0xc9c974: mov             SP, fp
    //     0xc9c978: ldp             fp, lr, [SP], #0x10
    // 0xc9c97c: ret
    //     0xc9c97c: ret             
    // 0xc9c980: ldr             x2, [fp, #0x18]
    // 0xc9c984: cmp             w2, w1
    // 0xc9c988: b.ne            #0xc9c99c
    // 0xc9c98c: r0 = true
    //     0xc9c98c: add             x0, NULL, #0x20  ; true
    // 0xc9c990: LeaveFrame
    //     0xc9c990: mov             SP, fp
    //     0xc9c994: ldp             fp, lr, [SP], #0x10
    // 0xc9c998: ret
    //     0xc9c998: ret             
    // 0xc9c99c: r0 = 59
    //     0xc9c99c: mov             x0, #0x3b
    // 0xc9c9a0: branchIfSmi(r1, 0xc9c9ac)
    //     0xc9c9a0: tbz             w1, #0, #0xc9c9ac
    // 0xc9c9a4: r0 = LoadClassIdInstr(r1)
    //     0xc9c9a4: ldur            x0, [x1, #-1]
    //     0xc9c9a8: ubfx            x0, x0, #0xc, #0x14
    // 0xc9c9ac: SaveReg r1
    //     0xc9c9ac: str             x1, [SP, #-8]!
    // 0xc9c9b0: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc9c9b0: mov             x17, #0x57c5
    //     0xc9c9b4: add             lr, x0, x17
    //     0xc9c9b8: ldr             lr, [x21, lr, lsl #3]
    //     0xc9c9bc: blr             lr
    // 0xc9c9c0: add             SP, SP, #8
    // 0xc9c9c4: stur            x0, [fp, #-8]
    // 0xc9c9c8: ldr             x16, [fp, #0x18]
    // 0xc9c9cc: SaveReg r16
    //     0xc9c9cc: str             x16, [SP, #-8]!
    // 0xc9c9d0: r0 = runtimeType()
    //     0xc9c9d0: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc9c9d4: add             SP, SP, #8
    // 0xc9c9d8: mov             x1, x0
    // 0xc9c9dc: ldur            x0, [fp, #-8]
    // 0xc9c9e0: r2 = LoadClassIdInstr(r0)
    //     0xc9c9e0: ldur            x2, [x0, #-1]
    //     0xc9c9e4: ubfx            x2, x2, #0xc, #0x14
    // 0xc9c9e8: stp             x1, x0, [SP, #-0x10]!
    // 0xc9c9ec: mov             x0, x2
    // 0xc9c9f0: mov             lr, x0
    // 0xc9c9f4: ldr             lr, [x21, lr, lsl #3]
    // 0xc9c9f8: blr             lr
    // 0xc9c9fc: add             SP, SP, #0x10
    // 0xc9ca00: tbz             w0, #4, #0xc9ca14
    // 0xc9ca04: r0 = false
    //     0xc9ca04: add             x0, NULL, #0x30  ; false
    // 0xc9ca08: LeaveFrame
    //     0xc9ca08: mov             SP, fp
    //     0xc9ca0c: ldp             fp, lr, [SP], #0x10
    // 0xc9ca10: ret
    //     0xc9ca10: ret             
    // 0xc9ca14: ldr             x0, [fp, #0x10]
    // 0xc9ca18: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc9ca18: mov             x1, #0x76
    //     0xc9ca1c: tbz             w0, #0, #0xc9ca2c
    //     0xc9ca20: ldur            x1, [x0, #-1]
    //     0xc9ca24: ubfx            x1, x1, #0xc, #0x14
    //     0xc9ca28: lsl             x1, x1, #1
    // 0xc9ca2c: stur            x1, [fp, #-0x20]
    // 0xc9ca30: r2 = LoadInt32Instr(r1)
    //     0xc9ca30: sbfx            x2, x1, #1, #0x1f
    // 0xc9ca34: cmp             x2, #0x83f
    // 0xc9ca38: b.lt            #0xc9d05c
    // 0xc9ca3c: cmp             x2, #0x840
    // 0xc9ca40: b.gt            #0xc9d05c
    // 0xc9ca44: r17 = 4222
    //     0xc9ca44: mov             x17, #0x107e
    // 0xc9ca48: cmp             w1, w17
    // 0xc9ca4c: b.ne            #0xc9ca60
    // 0xc9ca50: LoadField: r2 = r0->field_7
    //     0xc9ca50: ldur            w2, [x0, #7]
    // 0xc9ca54: DecompressPointer r2
    //     0xc9ca54: add             x2, x2, HEAP, lsl #32
    // 0xc9ca58: mov             x3, x2
    // 0xc9ca5c: b               #0xc9ca6c
    // 0xc9ca60: LoadField: r2 = r0->field_7
    //     0xc9ca60: ldur            w2, [x0, #7]
    // 0xc9ca64: DecompressPointer r2
    //     0xc9ca64: add             x2, x2, HEAP, lsl #32
    // 0xc9ca68: mov             x3, x2
    // 0xc9ca6c: ldr             x2, [fp, #0x18]
    // 0xc9ca70: stur            x3, [fp, #-0x18]
    // 0xc9ca74: r4 = LoadClassIdInstr(r2)
    //     0xc9ca74: ldur            x4, [x2, #-1]
    //     0xc9ca78: ubfx            x4, x4, #0xc, #0x14
    // 0xc9ca7c: lsl             x4, x4, #1
    // 0xc9ca80: stur            x4, [fp, #-0x10]
    // 0xc9ca84: r17 = 4222
    //     0xc9ca84: mov             x17, #0x107e
    // 0xc9ca88: cmp             w4, w17
    // 0xc9ca8c: b.ne            #0xc9ca9c
    // 0xc9ca90: LoadField: r5 = r2->field_7
    //     0xc9ca90: ldur            w5, [x2, #7]
    // 0xc9ca94: DecompressPointer r5
    //     0xc9ca94: add             x5, x5, HEAP, lsl #32
    // 0xc9ca98: b               #0xc9caa4
    // 0xc9ca9c: LoadField: r5 = r2->field_7
    //     0xc9ca9c: ldur            w5, [x2, #7]
    // 0xc9caa0: DecompressPointer r5
    //     0xc9caa0: add             x5, x5, HEAP, lsl #32
    // 0xc9caa4: stur            x5, [fp, #-8]
    // 0xc9caa8: cmp             w3, w5
    // 0xc9caac: b.ne            #0xc9cab8
    // 0xc9cab0: mov             x0, x1
    // 0xc9cab4: b               #0xc9cb0c
    // 0xc9cab8: r16 = Radius
    //     0xc9cab8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xc9cabc: ldr             x16, [x16, #0x470]
    // 0xc9cac0: r30 = Radius
    //     0xc9cac0: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xc9cac4: ldr             lr, [lr, #0x470]
    // 0xc9cac8: stp             lr, x16, [SP, #-0x10]!
    // 0xc9cacc: r0 = ==()
    //     0xc9cacc: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc9cad0: add             SP, SP, #0x10
    // 0xc9cad4: tbnz            w0, #4, #0xc9d05c
    // 0xc9cad8: ldur            x0, [fp, #-0x18]
    // 0xc9cadc: ldur            x1, [fp, #-8]
    // 0xc9cae0: LoadField: d0 = r1->field_7
    //     0xc9cae0: ldur            d0, [x1, #7]
    // 0xc9cae4: LoadField: d1 = r0->field_7
    //     0xc9cae4: ldur            d1, [x0, #7]
    // 0xc9cae8: fcmp            d0, d1
    // 0xc9caec: b.vs            #0xc9d05c
    // 0xc9caf0: b.ne            #0xc9d05c
    // 0xc9caf4: LoadField: d0 = r1->field_f
    //     0xc9caf4: ldur            d0, [x1, #0xf]
    // 0xc9caf8: LoadField: d1 = r0->field_f
    //     0xc9caf8: ldur            d1, [x0, #0xf]
    // 0xc9cafc: fcmp            d0, d1
    // 0xc9cb00: b.vs            #0xc9d05c
    // 0xc9cb04: b.ne            #0xc9d05c
    // 0xc9cb08: ldur            x0, [fp, #-0x20]
    // 0xc9cb0c: r17 = 4222
    //     0xc9cb0c: mov             x17, #0x107e
    // 0xc9cb10: cmp             w0, w17
    // 0xc9cb14: b.ne            #0xc9cb2c
    // 0xc9cb18: ldr             x1, [fp, #0x10]
    // 0xc9cb1c: LoadField: r2 = r1->field_b
    //     0xc9cb1c: ldur            w2, [x1, #0xb]
    // 0xc9cb20: DecompressPointer r2
    //     0xc9cb20: add             x2, x2, HEAP, lsl #32
    // 0xc9cb24: mov             x3, x2
    // 0xc9cb28: b               #0xc9cb3c
    // 0xc9cb2c: ldr             x1, [fp, #0x10]
    // 0xc9cb30: LoadField: r2 = r1->field_b
    //     0xc9cb30: ldur            w2, [x1, #0xb]
    // 0xc9cb34: DecompressPointer r2
    //     0xc9cb34: add             x2, x2, HEAP, lsl #32
    // 0xc9cb38: mov             x3, x2
    // 0xc9cb3c: ldur            x2, [fp, #-0x10]
    // 0xc9cb40: stur            x3, [fp, #-0x18]
    // 0xc9cb44: r17 = 4222
    //     0xc9cb44: mov             x17, #0x107e
    // 0xc9cb48: cmp             w2, w17
    // 0xc9cb4c: b.ne            #0xc9cb60
    // 0xc9cb50: ldr             x4, [fp, #0x18]
    // 0xc9cb54: LoadField: r5 = r4->field_b
    //     0xc9cb54: ldur            w5, [x4, #0xb]
    // 0xc9cb58: DecompressPointer r5
    //     0xc9cb58: add             x5, x5, HEAP, lsl #32
    // 0xc9cb5c: b               #0xc9cb6c
    // 0xc9cb60: ldr             x4, [fp, #0x18]
    // 0xc9cb64: LoadField: r5 = r4->field_b
    //     0xc9cb64: ldur            w5, [x4, #0xb]
    // 0xc9cb68: DecompressPointer r5
    //     0xc9cb68: add             x5, x5, HEAP, lsl #32
    // 0xc9cb6c: stur            x5, [fp, #-8]
    // 0xc9cb70: cmp             w3, w5
    // 0xc9cb74: b.eq            #0xc9cbcc
    // 0xc9cb78: r16 = Radius
    //     0xc9cb78: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xc9cb7c: ldr             x16, [x16, #0x470]
    // 0xc9cb80: r30 = Radius
    //     0xc9cb80: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xc9cb84: ldr             lr, [lr, #0x470]
    // 0xc9cb88: stp             lr, x16, [SP, #-0x10]!
    // 0xc9cb8c: r0 = ==()
    //     0xc9cb8c: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc9cb90: add             SP, SP, #0x10
    // 0xc9cb94: tbnz            w0, #4, #0xc9d05c
    // 0xc9cb98: ldur            x0, [fp, #-0x18]
    // 0xc9cb9c: ldur            x1, [fp, #-8]
    // 0xc9cba0: LoadField: d0 = r1->field_7
    //     0xc9cba0: ldur            d0, [x1, #7]
    // 0xc9cba4: LoadField: d1 = r0->field_7
    //     0xc9cba4: ldur            d1, [x0, #7]
    // 0xc9cba8: fcmp            d0, d1
    // 0xc9cbac: b.vs            #0xc9d05c
    // 0xc9cbb0: b.ne            #0xc9d05c
    // 0xc9cbb4: LoadField: d0 = r1->field_f
    //     0xc9cbb4: ldur            d0, [x1, #0xf]
    // 0xc9cbb8: LoadField: d1 = r0->field_f
    //     0xc9cbb8: ldur            d1, [x0, #0xf]
    // 0xc9cbbc: fcmp            d0, d1
    // 0xc9cbc0: b.vs            #0xc9d05c
    // 0xc9cbc4: b.ne            #0xc9d05c
    // 0xc9cbc8: ldur            x0, [fp, #-0x20]
    // 0xc9cbcc: r17 = 4222
    //     0xc9cbcc: mov             x17, #0x107e
    // 0xc9cbd0: cmp             w0, w17
    // 0xc9cbd4: b.ne            #0xc9cbec
    // 0xc9cbd8: ldr             x1, [fp, #0x10]
    // 0xc9cbdc: LoadField: r2 = r1->field_f
    //     0xc9cbdc: ldur            w2, [x1, #0xf]
    // 0xc9cbe0: DecompressPointer r2
    //     0xc9cbe0: add             x2, x2, HEAP, lsl #32
    // 0xc9cbe4: mov             x3, x2
    // 0xc9cbe8: b               #0xc9cbfc
    // 0xc9cbec: ldr             x1, [fp, #0x10]
    // 0xc9cbf0: LoadField: r2 = r1->field_f
    //     0xc9cbf0: ldur            w2, [x1, #0xf]
    // 0xc9cbf4: DecompressPointer r2
    //     0xc9cbf4: add             x2, x2, HEAP, lsl #32
    // 0xc9cbf8: mov             x3, x2
    // 0xc9cbfc: ldur            x2, [fp, #-0x10]
    // 0xc9cc00: stur            x3, [fp, #-0x18]
    // 0xc9cc04: r17 = 4222
    //     0xc9cc04: mov             x17, #0x107e
    // 0xc9cc08: cmp             w2, w17
    // 0xc9cc0c: b.ne            #0xc9cc20
    // 0xc9cc10: ldr             x4, [fp, #0x18]
    // 0xc9cc14: LoadField: r5 = r4->field_f
    //     0xc9cc14: ldur            w5, [x4, #0xf]
    // 0xc9cc18: DecompressPointer r5
    //     0xc9cc18: add             x5, x5, HEAP, lsl #32
    // 0xc9cc1c: b               #0xc9cc2c
    // 0xc9cc20: ldr             x4, [fp, #0x18]
    // 0xc9cc24: LoadField: r5 = r4->field_f
    //     0xc9cc24: ldur            w5, [x4, #0xf]
    // 0xc9cc28: DecompressPointer r5
    //     0xc9cc28: add             x5, x5, HEAP, lsl #32
    // 0xc9cc2c: stur            x5, [fp, #-8]
    // 0xc9cc30: cmp             w3, w5
    // 0xc9cc34: b.eq            #0xc9cc8c
    // 0xc9cc38: r16 = Radius
    //     0xc9cc38: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xc9cc3c: ldr             x16, [x16, #0x470]
    // 0xc9cc40: r30 = Radius
    //     0xc9cc40: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xc9cc44: ldr             lr, [lr, #0x470]
    // 0xc9cc48: stp             lr, x16, [SP, #-0x10]!
    // 0xc9cc4c: r0 = ==()
    //     0xc9cc4c: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc9cc50: add             SP, SP, #0x10
    // 0xc9cc54: tbnz            w0, #4, #0xc9d05c
    // 0xc9cc58: ldur            x0, [fp, #-0x18]
    // 0xc9cc5c: ldur            x1, [fp, #-8]
    // 0xc9cc60: LoadField: d0 = r1->field_7
    //     0xc9cc60: ldur            d0, [x1, #7]
    // 0xc9cc64: LoadField: d1 = r0->field_7
    //     0xc9cc64: ldur            d1, [x0, #7]
    // 0xc9cc68: fcmp            d0, d1
    // 0xc9cc6c: b.vs            #0xc9d05c
    // 0xc9cc70: b.ne            #0xc9d05c
    // 0xc9cc74: LoadField: d0 = r1->field_f
    //     0xc9cc74: ldur            d0, [x1, #0xf]
    // 0xc9cc78: LoadField: d1 = r0->field_f
    //     0xc9cc78: ldur            d1, [x0, #0xf]
    // 0xc9cc7c: fcmp            d0, d1
    // 0xc9cc80: b.vs            #0xc9d05c
    // 0xc9cc84: b.ne            #0xc9d05c
    // 0xc9cc88: ldur            x0, [fp, #-0x20]
    // 0xc9cc8c: r17 = 4222
    //     0xc9cc8c: mov             x17, #0x107e
    // 0xc9cc90: cmp             w0, w17
    // 0xc9cc94: b.ne            #0xc9ccac
    // 0xc9cc98: ldr             x1, [fp, #0x10]
    // 0xc9cc9c: LoadField: r2 = r1->field_13
    //     0xc9cc9c: ldur            w2, [x1, #0x13]
    // 0xc9cca0: DecompressPointer r2
    //     0xc9cca0: add             x2, x2, HEAP, lsl #32
    // 0xc9cca4: mov             x3, x2
    // 0xc9cca8: b               #0xc9ccbc
    // 0xc9ccac: ldr             x1, [fp, #0x10]
    // 0xc9ccb0: LoadField: r2 = r1->field_13
    //     0xc9ccb0: ldur            w2, [x1, #0x13]
    // 0xc9ccb4: DecompressPointer r2
    //     0xc9ccb4: add             x2, x2, HEAP, lsl #32
    // 0xc9ccb8: mov             x3, x2
    // 0xc9ccbc: ldur            x2, [fp, #-0x10]
    // 0xc9ccc0: stur            x3, [fp, #-0x18]
    // 0xc9ccc4: r17 = 4222
    //     0xc9ccc4: mov             x17, #0x107e
    // 0xc9ccc8: cmp             w2, w17
    // 0xc9cccc: b.ne            #0xc9cce0
    // 0xc9ccd0: ldr             x4, [fp, #0x18]
    // 0xc9ccd4: LoadField: r5 = r4->field_13
    //     0xc9ccd4: ldur            w5, [x4, #0x13]
    // 0xc9ccd8: DecompressPointer r5
    //     0xc9ccd8: add             x5, x5, HEAP, lsl #32
    // 0xc9ccdc: b               #0xc9ccec
    // 0xc9cce0: ldr             x4, [fp, #0x18]
    // 0xc9cce4: LoadField: r5 = r4->field_13
    //     0xc9cce4: ldur            w5, [x4, #0x13]
    // 0xc9cce8: DecompressPointer r5
    //     0xc9cce8: add             x5, x5, HEAP, lsl #32
    // 0xc9ccec: stur            x5, [fp, #-8]
    // 0xc9ccf0: cmp             w3, w5
    // 0xc9ccf4: b.eq            #0xc9cd4c
    // 0xc9ccf8: r16 = Radius
    //     0xc9ccf8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xc9ccfc: ldr             x16, [x16, #0x470]
    // 0xc9cd00: r30 = Radius
    //     0xc9cd00: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xc9cd04: ldr             lr, [lr, #0x470]
    // 0xc9cd08: stp             lr, x16, [SP, #-0x10]!
    // 0xc9cd0c: r0 = ==()
    //     0xc9cd0c: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc9cd10: add             SP, SP, #0x10
    // 0xc9cd14: tbnz            w0, #4, #0xc9d05c
    // 0xc9cd18: ldur            x0, [fp, #-0x18]
    // 0xc9cd1c: ldur            x1, [fp, #-8]
    // 0xc9cd20: LoadField: d0 = r1->field_7
    //     0xc9cd20: ldur            d0, [x1, #7]
    // 0xc9cd24: LoadField: d1 = r0->field_7
    //     0xc9cd24: ldur            d1, [x0, #7]
    // 0xc9cd28: fcmp            d0, d1
    // 0xc9cd2c: b.vs            #0xc9d05c
    // 0xc9cd30: b.ne            #0xc9d05c
    // 0xc9cd34: LoadField: d0 = r1->field_f
    //     0xc9cd34: ldur            d0, [x1, #0xf]
    // 0xc9cd38: LoadField: d1 = r0->field_f
    //     0xc9cd38: ldur            d1, [x0, #0xf]
    // 0xc9cd3c: fcmp            d0, d1
    // 0xc9cd40: b.vs            #0xc9d05c
    // 0xc9cd44: b.ne            #0xc9d05c
    // 0xc9cd48: ldur            x0, [fp, #-0x20]
    // 0xc9cd4c: r17 = 4222
    //     0xc9cd4c: mov             x17, #0x107e
    // 0xc9cd50: cmp             w0, w17
    // 0xc9cd54: b.ne            #0xc9cd6c
    // 0xc9cd58: ldr             x1, [fp, #0x10]
    // 0xc9cd5c: LoadField: r2 = r1->field_17
    //     0xc9cd5c: ldur            w2, [x1, #0x17]
    // 0xc9cd60: DecompressPointer r2
    //     0xc9cd60: add             x2, x2, HEAP, lsl #32
    // 0xc9cd64: mov             x3, x2
    // 0xc9cd68: b               #0xc9cd78
    // 0xc9cd6c: ldr             x1, [fp, #0x10]
    // 0xc9cd70: r3 = Instance_Radius
    //     0xc9cd70: add             x3, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xc9cd74: ldr             x3, [x3, #0x478]
    // 0xc9cd78: ldur            x2, [fp, #-0x10]
    // 0xc9cd7c: stur            x3, [fp, #-0x18]
    // 0xc9cd80: r17 = 4222
    //     0xc9cd80: mov             x17, #0x107e
    // 0xc9cd84: cmp             w2, w17
    // 0xc9cd88: b.ne            #0xc9cd9c
    // 0xc9cd8c: ldr             x4, [fp, #0x18]
    // 0xc9cd90: LoadField: r5 = r4->field_17
    //     0xc9cd90: ldur            w5, [x4, #0x17]
    // 0xc9cd94: DecompressPointer r5
    //     0xc9cd94: add             x5, x5, HEAP, lsl #32
    // 0xc9cd98: b               #0xc9cda8
    // 0xc9cd9c: ldr             x4, [fp, #0x18]
    // 0xc9cda0: r5 = Instance_Radius
    //     0xc9cda0: add             x5, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xc9cda4: ldr             x5, [x5, #0x478]
    // 0xc9cda8: stur            x5, [fp, #-8]
    // 0xc9cdac: cmp             w3, w5
    // 0xc9cdb0: b.eq            #0xc9ce08
    // 0xc9cdb4: r16 = Radius
    //     0xc9cdb4: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xc9cdb8: ldr             x16, [x16, #0x470]
    // 0xc9cdbc: r30 = Radius
    //     0xc9cdbc: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xc9cdc0: ldr             lr, [lr, #0x470]
    // 0xc9cdc4: stp             lr, x16, [SP, #-0x10]!
    // 0xc9cdc8: r0 = ==()
    //     0xc9cdc8: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc9cdcc: add             SP, SP, #0x10
    // 0xc9cdd0: tbnz            w0, #4, #0xc9d05c
    // 0xc9cdd4: ldur            x0, [fp, #-0x18]
    // 0xc9cdd8: ldur            x1, [fp, #-8]
    // 0xc9cddc: LoadField: d0 = r1->field_7
    //     0xc9cddc: ldur            d0, [x1, #7]
    // 0xc9cde0: LoadField: d1 = r0->field_7
    //     0xc9cde0: ldur            d1, [x0, #7]
    // 0xc9cde4: fcmp            d0, d1
    // 0xc9cde8: b.vs            #0xc9d05c
    // 0xc9cdec: b.ne            #0xc9d05c
    // 0xc9cdf0: LoadField: d0 = r1->field_f
    //     0xc9cdf0: ldur            d0, [x1, #0xf]
    // 0xc9cdf4: LoadField: d1 = r0->field_f
    //     0xc9cdf4: ldur            d1, [x0, #0xf]
    // 0xc9cdf8: fcmp            d0, d1
    // 0xc9cdfc: b.vs            #0xc9d05c
    // 0xc9ce00: b.ne            #0xc9d05c
    // 0xc9ce04: ldur            x0, [fp, #-0x20]
    // 0xc9ce08: r17 = 4222
    //     0xc9ce08: mov             x17, #0x107e
    // 0xc9ce0c: cmp             w0, w17
    // 0xc9ce10: b.ne            #0xc9ce28
    // 0xc9ce14: ldr             x1, [fp, #0x10]
    // 0xc9ce18: LoadField: r2 = r1->field_1b
    //     0xc9ce18: ldur            w2, [x1, #0x1b]
    // 0xc9ce1c: DecompressPointer r2
    //     0xc9ce1c: add             x2, x2, HEAP, lsl #32
    // 0xc9ce20: mov             x3, x2
    // 0xc9ce24: b               #0xc9ce34
    // 0xc9ce28: ldr             x1, [fp, #0x10]
    // 0xc9ce2c: r3 = Instance_Radius
    //     0xc9ce2c: add             x3, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xc9ce30: ldr             x3, [x3, #0x478]
    // 0xc9ce34: ldur            x2, [fp, #-0x10]
    // 0xc9ce38: stur            x3, [fp, #-0x18]
    // 0xc9ce3c: r17 = 4222
    //     0xc9ce3c: mov             x17, #0x107e
    // 0xc9ce40: cmp             w2, w17
    // 0xc9ce44: b.ne            #0xc9ce58
    // 0xc9ce48: ldr             x4, [fp, #0x18]
    // 0xc9ce4c: LoadField: r5 = r4->field_1b
    //     0xc9ce4c: ldur            w5, [x4, #0x1b]
    // 0xc9ce50: DecompressPointer r5
    //     0xc9ce50: add             x5, x5, HEAP, lsl #32
    // 0xc9ce54: b               #0xc9ce64
    // 0xc9ce58: ldr             x4, [fp, #0x18]
    // 0xc9ce5c: r5 = Instance_Radius
    //     0xc9ce5c: add             x5, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xc9ce60: ldr             x5, [x5, #0x478]
    // 0xc9ce64: stur            x5, [fp, #-8]
    // 0xc9ce68: cmp             w3, w5
    // 0xc9ce6c: b.eq            #0xc9cec4
    // 0xc9ce70: r16 = Radius
    //     0xc9ce70: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xc9ce74: ldr             x16, [x16, #0x470]
    // 0xc9ce78: r30 = Radius
    //     0xc9ce78: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xc9ce7c: ldr             lr, [lr, #0x470]
    // 0xc9ce80: stp             lr, x16, [SP, #-0x10]!
    // 0xc9ce84: r0 = ==()
    //     0xc9ce84: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc9ce88: add             SP, SP, #0x10
    // 0xc9ce8c: tbnz            w0, #4, #0xc9d05c
    // 0xc9ce90: ldur            x0, [fp, #-0x18]
    // 0xc9ce94: ldur            x1, [fp, #-8]
    // 0xc9ce98: LoadField: d0 = r1->field_7
    //     0xc9ce98: ldur            d0, [x1, #7]
    // 0xc9ce9c: LoadField: d1 = r0->field_7
    //     0xc9ce9c: ldur            d1, [x0, #7]
    // 0xc9cea0: fcmp            d0, d1
    // 0xc9cea4: b.vs            #0xc9d05c
    // 0xc9cea8: b.ne            #0xc9d05c
    // 0xc9ceac: LoadField: d0 = r1->field_f
    //     0xc9ceac: ldur            d0, [x1, #0xf]
    // 0xc9ceb0: LoadField: d1 = r0->field_f
    //     0xc9ceb0: ldur            d1, [x0, #0xf]
    // 0xc9ceb4: fcmp            d0, d1
    // 0xc9ceb8: b.vs            #0xc9d05c
    // 0xc9cebc: b.ne            #0xc9d05c
    // 0xc9cec0: ldur            x0, [fp, #-0x20]
    // 0xc9cec4: r17 = 4222
    //     0xc9cec4: mov             x17, #0x107e
    // 0xc9cec8: cmp             w0, w17
    // 0xc9cecc: b.ne            #0xc9cee4
    // 0xc9ced0: ldr             x1, [fp, #0x10]
    // 0xc9ced4: LoadField: r2 = r1->field_1f
    //     0xc9ced4: ldur            w2, [x1, #0x1f]
    // 0xc9ced8: DecompressPointer r2
    //     0xc9ced8: add             x2, x2, HEAP, lsl #32
    // 0xc9cedc: mov             x3, x2
    // 0xc9cee0: b               #0xc9cef0
    // 0xc9cee4: ldr             x1, [fp, #0x10]
    // 0xc9cee8: r3 = Instance_Radius
    //     0xc9cee8: add             x3, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xc9ceec: ldr             x3, [x3, #0x478]
    // 0xc9cef0: ldur            x2, [fp, #-0x10]
    // 0xc9cef4: stur            x3, [fp, #-0x18]
    // 0xc9cef8: r17 = 4222
    //     0xc9cef8: mov             x17, #0x107e
    // 0xc9cefc: cmp             w2, w17
    // 0xc9cf00: b.ne            #0xc9cf14
    // 0xc9cf04: ldr             x4, [fp, #0x18]
    // 0xc9cf08: LoadField: r5 = r4->field_1f
    //     0xc9cf08: ldur            w5, [x4, #0x1f]
    // 0xc9cf0c: DecompressPointer r5
    //     0xc9cf0c: add             x5, x5, HEAP, lsl #32
    // 0xc9cf10: b               #0xc9cf20
    // 0xc9cf14: ldr             x4, [fp, #0x18]
    // 0xc9cf18: r5 = Instance_Radius
    //     0xc9cf18: add             x5, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xc9cf1c: ldr             x5, [x5, #0x478]
    // 0xc9cf20: stur            x5, [fp, #-8]
    // 0xc9cf24: cmp             w3, w5
    // 0xc9cf28: b.eq            #0xc9cf80
    // 0xc9cf2c: r16 = Radius
    //     0xc9cf2c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xc9cf30: ldr             x16, [x16, #0x470]
    // 0xc9cf34: r30 = Radius
    //     0xc9cf34: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xc9cf38: ldr             lr, [lr, #0x470]
    // 0xc9cf3c: stp             lr, x16, [SP, #-0x10]!
    // 0xc9cf40: r0 = ==()
    //     0xc9cf40: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc9cf44: add             SP, SP, #0x10
    // 0xc9cf48: tbnz            w0, #4, #0xc9d05c
    // 0xc9cf4c: ldur            x0, [fp, #-0x18]
    // 0xc9cf50: ldur            x1, [fp, #-8]
    // 0xc9cf54: LoadField: d0 = r1->field_7
    //     0xc9cf54: ldur            d0, [x1, #7]
    // 0xc9cf58: LoadField: d1 = r0->field_7
    //     0xc9cf58: ldur            d1, [x0, #7]
    // 0xc9cf5c: fcmp            d0, d1
    // 0xc9cf60: b.vs            #0xc9d05c
    // 0xc9cf64: b.ne            #0xc9d05c
    // 0xc9cf68: LoadField: d0 = r1->field_f
    //     0xc9cf68: ldur            d0, [x1, #0xf]
    // 0xc9cf6c: LoadField: d1 = r0->field_f
    //     0xc9cf6c: ldur            d1, [x0, #0xf]
    // 0xc9cf70: fcmp            d0, d1
    // 0xc9cf74: b.vs            #0xc9d05c
    // 0xc9cf78: b.ne            #0xc9d05c
    // 0xc9cf7c: ldur            x0, [fp, #-0x20]
    // 0xc9cf80: r17 = 4222
    //     0xc9cf80: mov             x17, #0x107e
    // 0xc9cf84: cmp             w0, w17
    // 0xc9cf88: b.ne            #0xc9cf9c
    // 0xc9cf8c: ldr             x0, [fp, #0x10]
    // 0xc9cf90: LoadField: r1 = r0->field_23
    //     0xc9cf90: ldur            w1, [x0, #0x23]
    // 0xc9cf94: DecompressPointer r1
    //     0xc9cf94: add             x1, x1, HEAP, lsl #32
    // 0xc9cf98: b               #0xc9cfa4
    // 0xc9cf9c: r1 = Instance_Radius
    //     0xc9cf9c: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xc9cfa0: ldr             x1, [x1, #0x478]
    // 0xc9cfa4: ldur            x0, [fp, #-0x10]
    // 0xc9cfa8: stur            x1, [fp, #-0x18]
    // 0xc9cfac: r17 = 4222
    //     0xc9cfac: mov             x17, #0x107e
    // 0xc9cfb0: cmp             w0, w17
    // 0xc9cfb4: b.ne            #0xc9cfcc
    // 0xc9cfb8: ldr             x0, [fp, #0x18]
    // 0xc9cfbc: LoadField: r2 = r0->field_23
    //     0xc9cfbc: ldur            w2, [x0, #0x23]
    // 0xc9cfc0: DecompressPointer r2
    //     0xc9cfc0: add             x2, x2, HEAP, lsl #32
    // 0xc9cfc4: mov             x0, x2
    // 0xc9cfc8: b               #0xc9cfd4
    // 0xc9cfcc: r0 = Instance_Radius
    //     0xc9cfcc: add             x0, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xc9cfd0: ldr             x0, [x0, #0x478]
    // 0xc9cfd4: stur            x0, [fp, #-8]
    // 0xc9cfd8: cmp             w1, w0
    // 0xc9cfdc: b.ne            #0xc9cfe8
    // 0xc9cfe0: r1 = true
    //     0xc9cfe0: add             x1, NULL, #0x20  ; true
    // 0xc9cfe4: b               #0xc9d054
    // 0xc9cfe8: r16 = Radius
    //     0xc9cfe8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xc9cfec: ldr             x16, [x16, #0x470]
    // 0xc9cff0: r30 = Radius
    //     0xc9cff0: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xc9cff4: ldr             lr, [lr, #0x470]
    // 0xc9cff8: stp             lr, x16, [SP, #-0x10]!
    // 0xc9cffc: r0 = ==()
    //     0xc9cffc: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc9d000: add             SP, SP, #0x10
    // 0xc9d004: tbz             w0, #4, #0xc9d010
    // 0xc9d008: r1 = false
    //     0xc9d008: add             x1, NULL, #0x30  ; false
    // 0xc9d00c: b               #0xc9d054
    // 0xc9d010: ldur            x1, [fp, #-0x18]
    // 0xc9d014: ldur            x2, [fp, #-8]
    // 0xc9d018: LoadField: d0 = r2->field_7
    //     0xc9d018: ldur            d0, [x2, #7]
    // 0xc9d01c: LoadField: d1 = r1->field_7
    //     0xc9d01c: ldur            d1, [x1, #7]
    // 0xc9d020: fcmp            d0, d1
    // 0xc9d024: b.vs            #0xc9d050
    // 0xc9d028: b.ne            #0xc9d050
    // 0xc9d02c: LoadField: d0 = r2->field_f
    //     0xc9d02c: ldur            d0, [x2, #0xf]
    // 0xc9d030: LoadField: d1 = r1->field_f
    //     0xc9d030: ldur            d1, [x1, #0xf]
    // 0xc9d034: fcmp            d0, d1
    // 0xc9d038: b.vs            #0xc9d040
    // 0xc9d03c: b.eq            #0xc9d048
    // 0xc9d040: r1 = false
    //     0xc9d040: add             x1, NULL, #0x30  ; false
    // 0xc9d044: b               #0xc9d04c
    // 0xc9d048: r1 = true
    //     0xc9d048: add             x1, NULL, #0x20  ; true
    // 0xc9d04c: b               #0xc9d054
    // 0xc9d050: r1 = false
    //     0xc9d050: add             x1, NULL, #0x30  ; false
    // 0xc9d054: mov             x0, x1
    // 0xc9d058: b               #0xc9d060
    // 0xc9d05c: r0 = false
    //     0xc9d05c: add             x0, NULL, #0x30  ; false
    // 0xc9d060: LeaveFrame
    //     0xc9d060: mov             SP, fp
    //     0xc9d064: ldp             fp, lr, [SP], #0x10
    // 0xc9d068: ret
    //     0xc9d068: ret             
    // 0xc9d06c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc9d06c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc9d070: b               #0xc9c964
  }
  _ add(/* No info */) {
    // ** addr: 0xcf8f7c, size: 0x41c
    // 0xcf8f7c: EnterFrame
    //     0xcf8f7c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8f80: mov             fp, SP
    // 0xcf8f84: AllocStack(0x48)
    //     0xcf8f84: sub             SP, SP, #0x48
    // 0xcf8f88: CheckStackOverflow
    //     0xcf8f88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf8f8c: cmp             SP, x16
    //     0xcf8f90: b.ls            #0xcf9390
    // 0xcf8f94: ldr             x0, [fp, #0x18]
    // 0xcf8f98: r1 = LoadClassIdInstr(r0)
    //     0xcf8f98: ldur            x1, [x0, #-1]
    //     0xcf8f9c: ubfx            x1, x1, #0xc, #0x14
    // 0xcf8fa0: lsl             x1, x1, #1
    // 0xcf8fa4: stur            x1, [fp, #-0x10]
    // 0xcf8fa8: r17 = 4222
    //     0xcf8fa8: mov             x17, #0x107e
    // 0xcf8fac: cmp             w1, w17
    // 0xcf8fb0: b.ne            #0xcf8fc4
    // 0xcf8fb4: LoadField: r2 = r0->field_7
    //     0xcf8fb4: ldur            w2, [x0, #7]
    // 0xcf8fb8: DecompressPointer r2
    //     0xcf8fb8: add             x2, x2, HEAP, lsl #32
    // 0xcf8fbc: mov             x3, x2
    // 0xcf8fc0: b               #0xcf8fd0
    // 0xcf8fc4: LoadField: r2 = r0->field_7
    //     0xcf8fc4: ldur            w2, [x0, #7]
    // 0xcf8fc8: DecompressPointer r2
    //     0xcf8fc8: add             x2, x2, HEAP, lsl #32
    // 0xcf8fcc: mov             x3, x2
    // 0xcf8fd0: ldr             x2, [fp, #0x10]
    // 0xcf8fd4: r4 = LoadClassIdInstr(r2)
    //     0xcf8fd4: ldur            x4, [x2, #-1]
    //     0xcf8fd8: ubfx            x4, x4, #0xc, #0x14
    // 0xcf8fdc: lsl             x4, x4, #1
    // 0xcf8fe0: stur            x4, [fp, #-8]
    // 0xcf8fe4: r17 = 4222
    //     0xcf8fe4: mov             x17, #0x107e
    // 0xcf8fe8: cmp             w4, w17
    // 0xcf8fec: b.ne            #0xcf8ffc
    // 0xcf8ff0: LoadField: r5 = r2->field_7
    //     0xcf8ff0: ldur            w5, [x2, #7]
    // 0xcf8ff4: DecompressPointer r5
    //     0xcf8ff4: add             x5, x5, HEAP, lsl #32
    // 0xcf8ff8: b               #0xcf9004
    // 0xcf8ffc: LoadField: r5 = r2->field_7
    //     0xcf8ffc: ldur            w5, [x2, #7]
    // 0xcf9000: DecompressPointer r5
    //     0xcf9000: add             x5, x5, HEAP, lsl #32
    // 0xcf9004: stp             x5, x3, [SP, #-0x10]!
    // 0xcf9008: r0 = +()
    //     0xcf9008: bl              #0x595d44  ; [dart:ui] Radius::+
    // 0xcf900c: add             SP, SP, #0x10
    // 0xcf9010: mov             x1, x0
    // 0xcf9014: ldur            x0, [fp, #-0x10]
    // 0xcf9018: stur            x1, [fp, #-0x18]
    // 0xcf901c: r17 = 4222
    //     0xcf901c: mov             x17, #0x107e
    // 0xcf9020: cmp             w0, w17
    // 0xcf9024: b.ne            #0xcf903c
    // 0xcf9028: ldr             x2, [fp, #0x18]
    // 0xcf902c: LoadField: r3 = r2->field_b
    //     0xcf902c: ldur            w3, [x2, #0xb]
    // 0xcf9030: DecompressPointer r3
    //     0xcf9030: add             x3, x3, HEAP, lsl #32
    // 0xcf9034: mov             x4, x3
    // 0xcf9038: b               #0xcf904c
    // 0xcf903c: ldr             x2, [fp, #0x18]
    // 0xcf9040: LoadField: r3 = r2->field_b
    //     0xcf9040: ldur            w3, [x2, #0xb]
    // 0xcf9044: DecompressPointer r3
    //     0xcf9044: add             x3, x3, HEAP, lsl #32
    // 0xcf9048: mov             x4, x3
    // 0xcf904c: ldur            x3, [fp, #-8]
    // 0xcf9050: r17 = 4222
    //     0xcf9050: mov             x17, #0x107e
    // 0xcf9054: cmp             w3, w17
    // 0xcf9058: b.ne            #0xcf906c
    // 0xcf905c: ldr             x5, [fp, #0x10]
    // 0xcf9060: LoadField: r6 = r5->field_b
    //     0xcf9060: ldur            w6, [x5, #0xb]
    // 0xcf9064: DecompressPointer r6
    //     0xcf9064: add             x6, x6, HEAP, lsl #32
    // 0xcf9068: b               #0xcf9078
    // 0xcf906c: ldr             x5, [fp, #0x10]
    // 0xcf9070: LoadField: r6 = r5->field_b
    //     0xcf9070: ldur            w6, [x5, #0xb]
    // 0xcf9074: DecompressPointer r6
    //     0xcf9074: add             x6, x6, HEAP, lsl #32
    // 0xcf9078: stp             x6, x4, [SP, #-0x10]!
    // 0xcf907c: r0 = +()
    //     0xcf907c: bl              #0x595d44  ; [dart:ui] Radius::+
    // 0xcf9080: add             SP, SP, #0x10
    // 0xcf9084: mov             x1, x0
    // 0xcf9088: ldur            x0, [fp, #-0x10]
    // 0xcf908c: stur            x1, [fp, #-0x20]
    // 0xcf9090: r17 = 4222
    //     0xcf9090: mov             x17, #0x107e
    // 0xcf9094: cmp             w0, w17
    // 0xcf9098: b.ne            #0xcf90b0
    // 0xcf909c: ldr             x2, [fp, #0x18]
    // 0xcf90a0: LoadField: r3 = r2->field_f
    //     0xcf90a0: ldur            w3, [x2, #0xf]
    // 0xcf90a4: DecompressPointer r3
    //     0xcf90a4: add             x3, x3, HEAP, lsl #32
    // 0xcf90a8: mov             x4, x3
    // 0xcf90ac: b               #0xcf90c0
    // 0xcf90b0: ldr             x2, [fp, #0x18]
    // 0xcf90b4: LoadField: r3 = r2->field_f
    //     0xcf90b4: ldur            w3, [x2, #0xf]
    // 0xcf90b8: DecompressPointer r3
    //     0xcf90b8: add             x3, x3, HEAP, lsl #32
    // 0xcf90bc: mov             x4, x3
    // 0xcf90c0: ldur            x3, [fp, #-8]
    // 0xcf90c4: r17 = 4222
    //     0xcf90c4: mov             x17, #0x107e
    // 0xcf90c8: cmp             w3, w17
    // 0xcf90cc: b.ne            #0xcf90e0
    // 0xcf90d0: ldr             x5, [fp, #0x10]
    // 0xcf90d4: LoadField: r6 = r5->field_f
    //     0xcf90d4: ldur            w6, [x5, #0xf]
    // 0xcf90d8: DecompressPointer r6
    //     0xcf90d8: add             x6, x6, HEAP, lsl #32
    // 0xcf90dc: b               #0xcf90ec
    // 0xcf90e0: ldr             x5, [fp, #0x10]
    // 0xcf90e4: LoadField: r6 = r5->field_f
    //     0xcf90e4: ldur            w6, [x5, #0xf]
    // 0xcf90e8: DecompressPointer r6
    //     0xcf90e8: add             x6, x6, HEAP, lsl #32
    // 0xcf90ec: stp             x6, x4, [SP, #-0x10]!
    // 0xcf90f0: r0 = +()
    //     0xcf90f0: bl              #0x595d44  ; [dart:ui] Radius::+
    // 0xcf90f4: add             SP, SP, #0x10
    // 0xcf90f8: mov             x1, x0
    // 0xcf90fc: ldur            x0, [fp, #-0x10]
    // 0xcf9100: stur            x1, [fp, #-0x28]
    // 0xcf9104: r17 = 4222
    //     0xcf9104: mov             x17, #0x107e
    // 0xcf9108: cmp             w0, w17
    // 0xcf910c: b.ne            #0xcf9124
    // 0xcf9110: ldr             x2, [fp, #0x18]
    // 0xcf9114: LoadField: r3 = r2->field_13
    //     0xcf9114: ldur            w3, [x2, #0x13]
    // 0xcf9118: DecompressPointer r3
    //     0xcf9118: add             x3, x3, HEAP, lsl #32
    // 0xcf911c: mov             x4, x3
    // 0xcf9120: b               #0xcf9134
    // 0xcf9124: ldr             x2, [fp, #0x18]
    // 0xcf9128: LoadField: r3 = r2->field_13
    //     0xcf9128: ldur            w3, [x2, #0x13]
    // 0xcf912c: DecompressPointer r3
    //     0xcf912c: add             x3, x3, HEAP, lsl #32
    // 0xcf9130: mov             x4, x3
    // 0xcf9134: ldur            x3, [fp, #-8]
    // 0xcf9138: r17 = 4222
    //     0xcf9138: mov             x17, #0x107e
    // 0xcf913c: cmp             w3, w17
    // 0xcf9140: b.ne            #0xcf9154
    // 0xcf9144: ldr             x5, [fp, #0x10]
    // 0xcf9148: LoadField: r6 = r5->field_13
    //     0xcf9148: ldur            w6, [x5, #0x13]
    // 0xcf914c: DecompressPointer r6
    //     0xcf914c: add             x6, x6, HEAP, lsl #32
    // 0xcf9150: b               #0xcf9160
    // 0xcf9154: ldr             x5, [fp, #0x10]
    // 0xcf9158: LoadField: r6 = r5->field_13
    //     0xcf9158: ldur            w6, [x5, #0x13]
    // 0xcf915c: DecompressPointer r6
    //     0xcf915c: add             x6, x6, HEAP, lsl #32
    // 0xcf9160: stp             x6, x4, [SP, #-0x10]!
    // 0xcf9164: r0 = +()
    //     0xcf9164: bl              #0x595d44  ; [dart:ui] Radius::+
    // 0xcf9168: add             SP, SP, #0x10
    // 0xcf916c: mov             x1, x0
    // 0xcf9170: ldur            x0, [fp, #-0x10]
    // 0xcf9174: stur            x1, [fp, #-0x30]
    // 0xcf9178: r17 = 4222
    //     0xcf9178: mov             x17, #0x107e
    // 0xcf917c: cmp             w0, w17
    // 0xcf9180: b.ne            #0xcf9198
    // 0xcf9184: ldr             x2, [fp, #0x18]
    // 0xcf9188: LoadField: r3 = r2->field_17
    //     0xcf9188: ldur            w3, [x2, #0x17]
    // 0xcf918c: DecompressPointer r3
    //     0xcf918c: add             x3, x3, HEAP, lsl #32
    // 0xcf9190: mov             x4, x3
    // 0xcf9194: b               #0xcf91a4
    // 0xcf9198: ldr             x2, [fp, #0x18]
    // 0xcf919c: r4 = Instance_Radius
    //     0xcf919c: add             x4, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xcf91a0: ldr             x4, [x4, #0x478]
    // 0xcf91a4: ldur            x3, [fp, #-8]
    // 0xcf91a8: r17 = 4222
    //     0xcf91a8: mov             x17, #0x107e
    // 0xcf91ac: cmp             w3, w17
    // 0xcf91b0: b.ne            #0xcf91c4
    // 0xcf91b4: ldr             x5, [fp, #0x10]
    // 0xcf91b8: LoadField: r6 = r5->field_17
    //     0xcf91b8: ldur            w6, [x5, #0x17]
    // 0xcf91bc: DecompressPointer r6
    //     0xcf91bc: add             x6, x6, HEAP, lsl #32
    // 0xcf91c0: b               #0xcf91d0
    // 0xcf91c4: ldr             x5, [fp, #0x10]
    // 0xcf91c8: r6 = Instance_Radius
    //     0xcf91c8: add             x6, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xcf91cc: ldr             x6, [x6, #0x478]
    // 0xcf91d0: stp             x6, x4, [SP, #-0x10]!
    // 0xcf91d4: r0 = +()
    //     0xcf91d4: bl              #0x595d44  ; [dart:ui] Radius::+
    // 0xcf91d8: add             SP, SP, #0x10
    // 0xcf91dc: mov             x1, x0
    // 0xcf91e0: ldur            x0, [fp, #-0x10]
    // 0xcf91e4: stur            x1, [fp, #-0x38]
    // 0xcf91e8: r17 = 4222
    //     0xcf91e8: mov             x17, #0x107e
    // 0xcf91ec: cmp             w0, w17
    // 0xcf91f0: b.ne            #0xcf9208
    // 0xcf91f4: ldr             x2, [fp, #0x18]
    // 0xcf91f8: LoadField: r3 = r2->field_1b
    //     0xcf91f8: ldur            w3, [x2, #0x1b]
    // 0xcf91fc: DecompressPointer r3
    //     0xcf91fc: add             x3, x3, HEAP, lsl #32
    // 0xcf9200: mov             x4, x3
    // 0xcf9204: b               #0xcf9214
    // 0xcf9208: ldr             x2, [fp, #0x18]
    // 0xcf920c: r4 = Instance_Radius
    //     0xcf920c: add             x4, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xcf9210: ldr             x4, [x4, #0x478]
    // 0xcf9214: ldur            x3, [fp, #-8]
    // 0xcf9218: r17 = 4222
    //     0xcf9218: mov             x17, #0x107e
    // 0xcf921c: cmp             w3, w17
    // 0xcf9220: b.ne            #0xcf9234
    // 0xcf9224: ldr             x5, [fp, #0x10]
    // 0xcf9228: LoadField: r6 = r5->field_1b
    //     0xcf9228: ldur            w6, [x5, #0x1b]
    // 0xcf922c: DecompressPointer r6
    //     0xcf922c: add             x6, x6, HEAP, lsl #32
    // 0xcf9230: b               #0xcf9240
    // 0xcf9234: ldr             x5, [fp, #0x10]
    // 0xcf9238: r6 = Instance_Radius
    //     0xcf9238: add             x6, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xcf923c: ldr             x6, [x6, #0x478]
    // 0xcf9240: stp             x6, x4, [SP, #-0x10]!
    // 0xcf9244: r0 = +()
    //     0xcf9244: bl              #0x595d44  ; [dart:ui] Radius::+
    // 0xcf9248: add             SP, SP, #0x10
    // 0xcf924c: mov             x1, x0
    // 0xcf9250: ldur            x0, [fp, #-0x10]
    // 0xcf9254: stur            x1, [fp, #-0x40]
    // 0xcf9258: r17 = 4222
    //     0xcf9258: mov             x17, #0x107e
    // 0xcf925c: cmp             w0, w17
    // 0xcf9260: b.ne            #0xcf9278
    // 0xcf9264: ldr             x2, [fp, #0x18]
    // 0xcf9268: LoadField: r3 = r2->field_1f
    //     0xcf9268: ldur            w3, [x2, #0x1f]
    // 0xcf926c: DecompressPointer r3
    //     0xcf926c: add             x3, x3, HEAP, lsl #32
    // 0xcf9270: mov             x4, x3
    // 0xcf9274: b               #0xcf9284
    // 0xcf9278: ldr             x2, [fp, #0x18]
    // 0xcf927c: r4 = Instance_Radius
    //     0xcf927c: add             x4, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xcf9280: ldr             x4, [x4, #0x478]
    // 0xcf9284: ldur            x3, [fp, #-8]
    // 0xcf9288: r17 = 4222
    //     0xcf9288: mov             x17, #0x107e
    // 0xcf928c: cmp             w3, w17
    // 0xcf9290: b.ne            #0xcf92a4
    // 0xcf9294: ldr             x5, [fp, #0x10]
    // 0xcf9298: LoadField: r6 = r5->field_1f
    //     0xcf9298: ldur            w6, [x5, #0x1f]
    // 0xcf929c: DecompressPointer r6
    //     0xcf929c: add             x6, x6, HEAP, lsl #32
    // 0xcf92a0: b               #0xcf92b0
    // 0xcf92a4: ldr             x5, [fp, #0x10]
    // 0xcf92a8: r6 = Instance_Radius
    //     0xcf92a8: add             x6, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xcf92ac: ldr             x6, [x6, #0x478]
    // 0xcf92b0: stp             x6, x4, [SP, #-0x10]!
    // 0xcf92b4: r0 = +()
    //     0xcf92b4: bl              #0x595d44  ; [dart:ui] Radius::+
    // 0xcf92b8: add             SP, SP, #0x10
    // 0xcf92bc: mov             x1, x0
    // 0xcf92c0: ldur            x0, [fp, #-0x10]
    // 0xcf92c4: stur            x1, [fp, #-0x48]
    // 0xcf92c8: r17 = 4222
    //     0xcf92c8: mov             x17, #0x107e
    // 0xcf92cc: cmp             w0, w17
    // 0xcf92d0: b.ne            #0xcf92e4
    // 0xcf92d4: ldr             x0, [fp, #0x18]
    // 0xcf92d8: LoadField: r2 = r0->field_23
    //     0xcf92d8: ldur            w2, [x0, #0x23]
    // 0xcf92dc: DecompressPointer r2
    //     0xcf92dc: add             x2, x2, HEAP, lsl #32
    // 0xcf92e0: b               #0xcf92ec
    // 0xcf92e4: r2 = Instance_Radius
    //     0xcf92e4: add             x2, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xcf92e8: ldr             x2, [x2, #0x478]
    // 0xcf92ec: ldur            x0, [fp, #-8]
    // 0xcf92f0: r17 = 4222
    //     0xcf92f0: mov             x17, #0x107e
    // 0xcf92f4: cmp             w0, w17
    // 0xcf92f8: b.ne            #0xcf9310
    // 0xcf92fc: ldr             x0, [fp, #0x10]
    // 0xcf9300: LoadField: r3 = r0->field_23
    //     0xcf9300: ldur            w3, [x0, #0x23]
    // 0xcf9304: DecompressPointer r3
    //     0xcf9304: add             x3, x3, HEAP, lsl #32
    // 0xcf9308: mov             x8, x3
    // 0xcf930c: b               #0xcf9318
    // 0xcf9310: r8 = Instance_Radius
    //     0xcf9310: add             x8, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xcf9314: ldr             x8, [x8, #0x478]
    // 0xcf9318: ldur            x7, [fp, #-0x18]
    // 0xcf931c: ldur            x6, [fp, #-0x20]
    // 0xcf9320: ldur            x5, [fp, #-0x28]
    // 0xcf9324: ldur            x4, [fp, #-0x30]
    // 0xcf9328: ldur            x3, [fp, #-0x38]
    // 0xcf932c: ldur            x0, [fp, #-0x40]
    // 0xcf9330: stp             x8, x2, [SP, #-0x10]!
    // 0xcf9334: r0 = +()
    //     0xcf9334: bl              #0x595d44  ; [dart:ui] Radius::+
    // 0xcf9338: add             SP, SP, #0x10
    // 0xcf933c: stur            x0, [fp, #-8]
    // 0xcf9340: r0 = _MixedBorderRadius()
    //     0xcf9340: bl              #0xcf9398  ; Allocate_MixedBorderRadiusStub -> _MixedBorderRadius (size=0x28)
    // 0xcf9344: ldur            x1, [fp, #-0x18]
    // 0xcf9348: StoreField: r0->field_7 = r1
    //     0xcf9348: stur            w1, [x0, #7]
    // 0xcf934c: ldur            x1, [fp, #-0x20]
    // 0xcf9350: StoreField: r0->field_b = r1
    //     0xcf9350: stur            w1, [x0, #0xb]
    // 0xcf9354: ldur            x1, [fp, #-0x28]
    // 0xcf9358: StoreField: r0->field_f = r1
    //     0xcf9358: stur            w1, [x0, #0xf]
    // 0xcf935c: ldur            x1, [fp, #-0x30]
    // 0xcf9360: StoreField: r0->field_13 = r1
    //     0xcf9360: stur            w1, [x0, #0x13]
    // 0xcf9364: ldur            x1, [fp, #-0x38]
    // 0xcf9368: StoreField: r0->field_17 = r1
    //     0xcf9368: stur            w1, [x0, #0x17]
    // 0xcf936c: ldur            x1, [fp, #-0x40]
    // 0xcf9370: StoreField: r0->field_1b = r1
    //     0xcf9370: stur            w1, [x0, #0x1b]
    // 0xcf9374: ldur            x1, [fp, #-0x48]
    // 0xcf9378: StoreField: r0->field_1f = r1
    //     0xcf9378: stur            w1, [x0, #0x1f]
    // 0xcf937c: ldur            x1, [fp, #-8]
    // 0xcf9380: StoreField: r0->field_23 = r1
    //     0xcf9380: stur            w1, [x0, #0x23]
    // 0xcf9384: LeaveFrame
    //     0xcf9384: mov             SP, fp
    //     0xcf9388: ldp             fp, lr, [SP], #0x10
    // 0xcf938c: ret
    //     0xcf938c: ret             
    // 0xcf9390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf9390: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf9394: b               #0xcf8f94
  }
  _ subtract(/* No info */) {
    // ** addr: 0xcf9dcc, size: 0x41c
    // 0xcf9dcc: EnterFrame
    //     0xcf9dcc: stp             fp, lr, [SP, #-0x10]!
    //     0xcf9dd0: mov             fp, SP
    // 0xcf9dd4: AllocStack(0x48)
    //     0xcf9dd4: sub             SP, SP, #0x48
    // 0xcf9dd8: CheckStackOverflow
    //     0xcf9dd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf9ddc: cmp             SP, x16
    //     0xcf9de0: b.ls            #0xcfa1e0
    // 0xcf9de4: ldr             x0, [fp, #0x18]
    // 0xcf9de8: r1 = LoadClassIdInstr(r0)
    //     0xcf9de8: ldur            x1, [x0, #-1]
    //     0xcf9dec: ubfx            x1, x1, #0xc, #0x14
    // 0xcf9df0: lsl             x1, x1, #1
    // 0xcf9df4: stur            x1, [fp, #-0x10]
    // 0xcf9df8: r17 = 4222
    //     0xcf9df8: mov             x17, #0x107e
    // 0xcf9dfc: cmp             w1, w17
    // 0xcf9e00: b.ne            #0xcf9e14
    // 0xcf9e04: LoadField: r2 = r0->field_7
    //     0xcf9e04: ldur            w2, [x0, #7]
    // 0xcf9e08: DecompressPointer r2
    //     0xcf9e08: add             x2, x2, HEAP, lsl #32
    // 0xcf9e0c: mov             x3, x2
    // 0xcf9e10: b               #0xcf9e20
    // 0xcf9e14: LoadField: r2 = r0->field_7
    //     0xcf9e14: ldur            w2, [x0, #7]
    // 0xcf9e18: DecompressPointer r2
    //     0xcf9e18: add             x2, x2, HEAP, lsl #32
    // 0xcf9e1c: mov             x3, x2
    // 0xcf9e20: ldr             x2, [fp, #0x10]
    // 0xcf9e24: r4 = LoadClassIdInstr(r2)
    //     0xcf9e24: ldur            x4, [x2, #-1]
    //     0xcf9e28: ubfx            x4, x4, #0xc, #0x14
    // 0xcf9e2c: lsl             x4, x4, #1
    // 0xcf9e30: stur            x4, [fp, #-8]
    // 0xcf9e34: r17 = 4222
    //     0xcf9e34: mov             x17, #0x107e
    // 0xcf9e38: cmp             w4, w17
    // 0xcf9e3c: b.ne            #0xcf9e4c
    // 0xcf9e40: LoadField: r5 = r2->field_7
    //     0xcf9e40: ldur            w5, [x2, #7]
    // 0xcf9e44: DecompressPointer r5
    //     0xcf9e44: add             x5, x5, HEAP, lsl #32
    // 0xcf9e48: b               #0xcf9e54
    // 0xcf9e4c: LoadField: r5 = r2->field_7
    //     0xcf9e4c: ldur            w5, [x2, #7]
    // 0xcf9e50: DecompressPointer r5
    //     0xcf9e50: add             x5, x5, HEAP, lsl #32
    // 0xcf9e54: stp             x5, x3, [SP, #-0x10]!
    // 0xcf9e58: r0 = -()
    //     0xcf9e58: bl              #0x595e28  ; [dart:ui] Radius::-
    // 0xcf9e5c: add             SP, SP, #0x10
    // 0xcf9e60: mov             x1, x0
    // 0xcf9e64: ldur            x0, [fp, #-0x10]
    // 0xcf9e68: stur            x1, [fp, #-0x18]
    // 0xcf9e6c: r17 = 4222
    //     0xcf9e6c: mov             x17, #0x107e
    // 0xcf9e70: cmp             w0, w17
    // 0xcf9e74: b.ne            #0xcf9e8c
    // 0xcf9e78: ldr             x2, [fp, #0x18]
    // 0xcf9e7c: LoadField: r3 = r2->field_b
    //     0xcf9e7c: ldur            w3, [x2, #0xb]
    // 0xcf9e80: DecompressPointer r3
    //     0xcf9e80: add             x3, x3, HEAP, lsl #32
    // 0xcf9e84: mov             x4, x3
    // 0xcf9e88: b               #0xcf9e9c
    // 0xcf9e8c: ldr             x2, [fp, #0x18]
    // 0xcf9e90: LoadField: r3 = r2->field_b
    //     0xcf9e90: ldur            w3, [x2, #0xb]
    // 0xcf9e94: DecompressPointer r3
    //     0xcf9e94: add             x3, x3, HEAP, lsl #32
    // 0xcf9e98: mov             x4, x3
    // 0xcf9e9c: ldur            x3, [fp, #-8]
    // 0xcf9ea0: r17 = 4222
    //     0xcf9ea0: mov             x17, #0x107e
    // 0xcf9ea4: cmp             w3, w17
    // 0xcf9ea8: b.ne            #0xcf9ebc
    // 0xcf9eac: ldr             x5, [fp, #0x10]
    // 0xcf9eb0: LoadField: r6 = r5->field_b
    //     0xcf9eb0: ldur            w6, [x5, #0xb]
    // 0xcf9eb4: DecompressPointer r6
    //     0xcf9eb4: add             x6, x6, HEAP, lsl #32
    // 0xcf9eb8: b               #0xcf9ec8
    // 0xcf9ebc: ldr             x5, [fp, #0x10]
    // 0xcf9ec0: LoadField: r6 = r5->field_b
    //     0xcf9ec0: ldur            w6, [x5, #0xb]
    // 0xcf9ec4: DecompressPointer r6
    //     0xcf9ec4: add             x6, x6, HEAP, lsl #32
    // 0xcf9ec8: stp             x6, x4, [SP, #-0x10]!
    // 0xcf9ecc: r0 = -()
    //     0xcf9ecc: bl              #0x595e28  ; [dart:ui] Radius::-
    // 0xcf9ed0: add             SP, SP, #0x10
    // 0xcf9ed4: mov             x1, x0
    // 0xcf9ed8: ldur            x0, [fp, #-0x10]
    // 0xcf9edc: stur            x1, [fp, #-0x20]
    // 0xcf9ee0: r17 = 4222
    //     0xcf9ee0: mov             x17, #0x107e
    // 0xcf9ee4: cmp             w0, w17
    // 0xcf9ee8: b.ne            #0xcf9f00
    // 0xcf9eec: ldr             x2, [fp, #0x18]
    // 0xcf9ef0: LoadField: r3 = r2->field_f
    //     0xcf9ef0: ldur            w3, [x2, #0xf]
    // 0xcf9ef4: DecompressPointer r3
    //     0xcf9ef4: add             x3, x3, HEAP, lsl #32
    // 0xcf9ef8: mov             x4, x3
    // 0xcf9efc: b               #0xcf9f10
    // 0xcf9f00: ldr             x2, [fp, #0x18]
    // 0xcf9f04: LoadField: r3 = r2->field_f
    //     0xcf9f04: ldur            w3, [x2, #0xf]
    // 0xcf9f08: DecompressPointer r3
    //     0xcf9f08: add             x3, x3, HEAP, lsl #32
    // 0xcf9f0c: mov             x4, x3
    // 0xcf9f10: ldur            x3, [fp, #-8]
    // 0xcf9f14: r17 = 4222
    //     0xcf9f14: mov             x17, #0x107e
    // 0xcf9f18: cmp             w3, w17
    // 0xcf9f1c: b.ne            #0xcf9f30
    // 0xcf9f20: ldr             x5, [fp, #0x10]
    // 0xcf9f24: LoadField: r6 = r5->field_f
    //     0xcf9f24: ldur            w6, [x5, #0xf]
    // 0xcf9f28: DecompressPointer r6
    //     0xcf9f28: add             x6, x6, HEAP, lsl #32
    // 0xcf9f2c: b               #0xcf9f3c
    // 0xcf9f30: ldr             x5, [fp, #0x10]
    // 0xcf9f34: LoadField: r6 = r5->field_f
    //     0xcf9f34: ldur            w6, [x5, #0xf]
    // 0xcf9f38: DecompressPointer r6
    //     0xcf9f38: add             x6, x6, HEAP, lsl #32
    // 0xcf9f3c: stp             x6, x4, [SP, #-0x10]!
    // 0xcf9f40: r0 = -()
    //     0xcf9f40: bl              #0x595e28  ; [dart:ui] Radius::-
    // 0xcf9f44: add             SP, SP, #0x10
    // 0xcf9f48: mov             x1, x0
    // 0xcf9f4c: ldur            x0, [fp, #-0x10]
    // 0xcf9f50: stur            x1, [fp, #-0x28]
    // 0xcf9f54: r17 = 4222
    //     0xcf9f54: mov             x17, #0x107e
    // 0xcf9f58: cmp             w0, w17
    // 0xcf9f5c: b.ne            #0xcf9f74
    // 0xcf9f60: ldr             x2, [fp, #0x18]
    // 0xcf9f64: LoadField: r3 = r2->field_13
    //     0xcf9f64: ldur            w3, [x2, #0x13]
    // 0xcf9f68: DecompressPointer r3
    //     0xcf9f68: add             x3, x3, HEAP, lsl #32
    // 0xcf9f6c: mov             x4, x3
    // 0xcf9f70: b               #0xcf9f84
    // 0xcf9f74: ldr             x2, [fp, #0x18]
    // 0xcf9f78: LoadField: r3 = r2->field_13
    //     0xcf9f78: ldur            w3, [x2, #0x13]
    // 0xcf9f7c: DecompressPointer r3
    //     0xcf9f7c: add             x3, x3, HEAP, lsl #32
    // 0xcf9f80: mov             x4, x3
    // 0xcf9f84: ldur            x3, [fp, #-8]
    // 0xcf9f88: r17 = 4222
    //     0xcf9f88: mov             x17, #0x107e
    // 0xcf9f8c: cmp             w3, w17
    // 0xcf9f90: b.ne            #0xcf9fa4
    // 0xcf9f94: ldr             x5, [fp, #0x10]
    // 0xcf9f98: LoadField: r6 = r5->field_13
    //     0xcf9f98: ldur            w6, [x5, #0x13]
    // 0xcf9f9c: DecompressPointer r6
    //     0xcf9f9c: add             x6, x6, HEAP, lsl #32
    // 0xcf9fa0: b               #0xcf9fb0
    // 0xcf9fa4: ldr             x5, [fp, #0x10]
    // 0xcf9fa8: LoadField: r6 = r5->field_13
    //     0xcf9fa8: ldur            w6, [x5, #0x13]
    // 0xcf9fac: DecompressPointer r6
    //     0xcf9fac: add             x6, x6, HEAP, lsl #32
    // 0xcf9fb0: stp             x6, x4, [SP, #-0x10]!
    // 0xcf9fb4: r0 = -()
    //     0xcf9fb4: bl              #0x595e28  ; [dart:ui] Radius::-
    // 0xcf9fb8: add             SP, SP, #0x10
    // 0xcf9fbc: mov             x1, x0
    // 0xcf9fc0: ldur            x0, [fp, #-0x10]
    // 0xcf9fc4: stur            x1, [fp, #-0x30]
    // 0xcf9fc8: r17 = 4222
    //     0xcf9fc8: mov             x17, #0x107e
    // 0xcf9fcc: cmp             w0, w17
    // 0xcf9fd0: b.ne            #0xcf9fe8
    // 0xcf9fd4: ldr             x2, [fp, #0x18]
    // 0xcf9fd8: LoadField: r3 = r2->field_17
    //     0xcf9fd8: ldur            w3, [x2, #0x17]
    // 0xcf9fdc: DecompressPointer r3
    //     0xcf9fdc: add             x3, x3, HEAP, lsl #32
    // 0xcf9fe0: mov             x4, x3
    // 0xcf9fe4: b               #0xcf9ff4
    // 0xcf9fe8: ldr             x2, [fp, #0x18]
    // 0xcf9fec: r4 = Instance_Radius
    //     0xcf9fec: add             x4, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xcf9ff0: ldr             x4, [x4, #0x478]
    // 0xcf9ff4: ldur            x3, [fp, #-8]
    // 0xcf9ff8: r17 = 4222
    //     0xcf9ff8: mov             x17, #0x107e
    // 0xcf9ffc: cmp             w3, w17
    // 0xcfa000: b.ne            #0xcfa014
    // 0xcfa004: ldr             x5, [fp, #0x10]
    // 0xcfa008: LoadField: r6 = r5->field_17
    //     0xcfa008: ldur            w6, [x5, #0x17]
    // 0xcfa00c: DecompressPointer r6
    //     0xcfa00c: add             x6, x6, HEAP, lsl #32
    // 0xcfa010: b               #0xcfa020
    // 0xcfa014: ldr             x5, [fp, #0x10]
    // 0xcfa018: r6 = Instance_Radius
    //     0xcfa018: add             x6, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xcfa01c: ldr             x6, [x6, #0x478]
    // 0xcfa020: stp             x6, x4, [SP, #-0x10]!
    // 0xcfa024: r0 = -()
    //     0xcfa024: bl              #0x595e28  ; [dart:ui] Radius::-
    // 0xcfa028: add             SP, SP, #0x10
    // 0xcfa02c: mov             x1, x0
    // 0xcfa030: ldur            x0, [fp, #-0x10]
    // 0xcfa034: stur            x1, [fp, #-0x38]
    // 0xcfa038: r17 = 4222
    //     0xcfa038: mov             x17, #0x107e
    // 0xcfa03c: cmp             w0, w17
    // 0xcfa040: b.ne            #0xcfa058
    // 0xcfa044: ldr             x2, [fp, #0x18]
    // 0xcfa048: LoadField: r3 = r2->field_1b
    //     0xcfa048: ldur            w3, [x2, #0x1b]
    // 0xcfa04c: DecompressPointer r3
    //     0xcfa04c: add             x3, x3, HEAP, lsl #32
    // 0xcfa050: mov             x4, x3
    // 0xcfa054: b               #0xcfa064
    // 0xcfa058: ldr             x2, [fp, #0x18]
    // 0xcfa05c: r4 = Instance_Radius
    //     0xcfa05c: add             x4, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xcfa060: ldr             x4, [x4, #0x478]
    // 0xcfa064: ldur            x3, [fp, #-8]
    // 0xcfa068: r17 = 4222
    //     0xcfa068: mov             x17, #0x107e
    // 0xcfa06c: cmp             w3, w17
    // 0xcfa070: b.ne            #0xcfa084
    // 0xcfa074: ldr             x5, [fp, #0x10]
    // 0xcfa078: LoadField: r6 = r5->field_1b
    //     0xcfa078: ldur            w6, [x5, #0x1b]
    // 0xcfa07c: DecompressPointer r6
    //     0xcfa07c: add             x6, x6, HEAP, lsl #32
    // 0xcfa080: b               #0xcfa090
    // 0xcfa084: ldr             x5, [fp, #0x10]
    // 0xcfa088: r6 = Instance_Radius
    //     0xcfa088: add             x6, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xcfa08c: ldr             x6, [x6, #0x478]
    // 0xcfa090: stp             x6, x4, [SP, #-0x10]!
    // 0xcfa094: r0 = -()
    //     0xcfa094: bl              #0x595e28  ; [dart:ui] Radius::-
    // 0xcfa098: add             SP, SP, #0x10
    // 0xcfa09c: mov             x1, x0
    // 0xcfa0a0: ldur            x0, [fp, #-0x10]
    // 0xcfa0a4: stur            x1, [fp, #-0x40]
    // 0xcfa0a8: r17 = 4222
    //     0xcfa0a8: mov             x17, #0x107e
    // 0xcfa0ac: cmp             w0, w17
    // 0xcfa0b0: b.ne            #0xcfa0c8
    // 0xcfa0b4: ldr             x2, [fp, #0x18]
    // 0xcfa0b8: LoadField: r3 = r2->field_1f
    //     0xcfa0b8: ldur            w3, [x2, #0x1f]
    // 0xcfa0bc: DecompressPointer r3
    //     0xcfa0bc: add             x3, x3, HEAP, lsl #32
    // 0xcfa0c0: mov             x4, x3
    // 0xcfa0c4: b               #0xcfa0d4
    // 0xcfa0c8: ldr             x2, [fp, #0x18]
    // 0xcfa0cc: r4 = Instance_Radius
    //     0xcfa0cc: add             x4, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xcfa0d0: ldr             x4, [x4, #0x478]
    // 0xcfa0d4: ldur            x3, [fp, #-8]
    // 0xcfa0d8: r17 = 4222
    //     0xcfa0d8: mov             x17, #0x107e
    // 0xcfa0dc: cmp             w3, w17
    // 0xcfa0e0: b.ne            #0xcfa0f4
    // 0xcfa0e4: ldr             x5, [fp, #0x10]
    // 0xcfa0e8: LoadField: r6 = r5->field_1f
    //     0xcfa0e8: ldur            w6, [x5, #0x1f]
    // 0xcfa0ec: DecompressPointer r6
    //     0xcfa0ec: add             x6, x6, HEAP, lsl #32
    // 0xcfa0f0: b               #0xcfa100
    // 0xcfa0f4: ldr             x5, [fp, #0x10]
    // 0xcfa0f8: r6 = Instance_Radius
    //     0xcfa0f8: add             x6, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xcfa0fc: ldr             x6, [x6, #0x478]
    // 0xcfa100: stp             x6, x4, [SP, #-0x10]!
    // 0xcfa104: r0 = -()
    //     0xcfa104: bl              #0x595e28  ; [dart:ui] Radius::-
    // 0xcfa108: add             SP, SP, #0x10
    // 0xcfa10c: mov             x1, x0
    // 0xcfa110: ldur            x0, [fp, #-0x10]
    // 0xcfa114: stur            x1, [fp, #-0x48]
    // 0xcfa118: r17 = 4222
    //     0xcfa118: mov             x17, #0x107e
    // 0xcfa11c: cmp             w0, w17
    // 0xcfa120: b.ne            #0xcfa134
    // 0xcfa124: ldr             x0, [fp, #0x18]
    // 0xcfa128: LoadField: r2 = r0->field_23
    //     0xcfa128: ldur            w2, [x0, #0x23]
    // 0xcfa12c: DecompressPointer r2
    //     0xcfa12c: add             x2, x2, HEAP, lsl #32
    // 0xcfa130: b               #0xcfa13c
    // 0xcfa134: r2 = Instance_Radius
    //     0xcfa134: add             x2, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xcfa138: ldr             x2, [x2, #0x478]
    // 0xcfa13c: ldur            x0, [fp, #-8]
    // 0xcfa140: r17 = 4222
    //     0xcfa140: mov             x17, #0x107e
    // 0xcfa144: cmp             w0, w17
    // 0xcfa148: b.ne            #0xcfa160
    // 0xcfa14c: ldr             x0, [fp, #0x10]
    // 0xcfa150: LoadField: r3 = r0->field_23
    //     0xcfa150: ldur            w3, [x0, #0x23]
    // 0xcfa154: DecompressPointer r3
    //     0xcfa154: add             x3, x3, HEAP, lsl #32
    // 0xcfa158: mov             x8, x3
    // 0xcfa15c: b               #0xcfa168
    // 0xcfa160: r8 = Instance_Radius
    //     0xcfa160: add             x8, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xcfa164: ldr             x8, [x8, #0x478]
    // 0xcfa168: ldur            x7, [fp, #-0x18]
    // 0xcfa16c: ldur            x6, [fp, #-0x20]
    // 0xcfa170: ldur            x5, [fp, #-0x28]
    // 0xcfa174: ldur            x4, [fp, #-0x30]
    // 0xcfa178: ldur            x3, [fp, #-0x38]
    // 0xcfa17c: ldur            x0, [fp, #-0x40]
    // 0xcfa180: stp             x8, x2, [SP, #-0x10]!
    // 0xcfa184: r0 = -()
    //     0xcfa184: bl              #0x595e28  ; [dart:ui] Radius::-
    // 0xcfa188: add             SP, SP, #0x10
    // 0xcfa18c: stur            x0, [fp, #-8]
    // 0xcfa190: r0 = _MixedBorderRadius()
    //     0xcfa190: bl              #0xcf9398  ; Allocate_MixedBorderRadiusStub -> _MixedBorderRadius (size=0x28)
    // 0xcfa194: ldur            x1, [fp, #-0x18]
    // 0xcfa198: StoreField: r0->field_7 = r1
    //     0xcfa198: stur            w1, [x0, #7]
    // 0xcfa19c: ldur            x1, [fp, #-0x20]
    // 0xcfa1a0: StoreField: r0->field_b = r1
    //     0xcfa1a0: stur            w1, [x0, #0xb]
    // 0xcfa1a4: ldur            x1, [fp, #-0x28]
    // 0xcfa1a8: StoreField: r0->field_f = r1
    //     0xcfa1a8: stur            w1, [x0, #0xf]
    // 0xcfa1ac: ldur            x1, [fp, #-0x30]
    // 0xcfa1b0: StoreField: r0->field_13 = r1
    //     0xcfa1b0: stur            w1, [x0, #0x13]
    // 0xcfa1b4: ldur            x1, [fp, #-0x38]
    // 0xcfa1b8: StoreField: r0->field_17 = r1
    //     0xcfa1b8: stur            w1, [x0, #0x17]
    // 0xcfa1bc: ldur            x1, [fp, #-0x40]
    // 0xcfa1c0: StoreField: r0->field_1b = r1
    //     0xcfa1c0: stur            w1, [x0, #0x1b]
    // 0xcfa1c4: ldur            x1, [fp, #-0x48]
    // 0xcfa1c8: StoreField: r0->field_1f = r1
    //     0xcfa1c8: stur            w1, [x0, #0x1f]
    // 0xcfa1cc: ldur            x1, [fp, #-8]
    // 0xcfa1d0: StoreField: r0->field_23 = r1
    //     0xcfa1d0: stur            w1, [x0, #0x23]
    // 0xcfa1d4: LeaveFrame
    //     0xcfa1d4: mov             SP, fp
    //     0xcfa1d8: ldp             fp, lr, [SP], #0x10
    // 0xcfa1dc: ret
    //     0xcfa1dc: ret             
    // 0xcfa1e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfa1e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfa1e4: b               #0xcf9de4
  }
}

// class id: 2111, size: 0x28, field offset: 0x8
//   const constructor, 
class _MixedBorderRadius extends BorderRadiusGeometry {

  _MixedBorderRadius /(_MixedBorderRadius, double) {
    // ** addr: 0xcf93bc, size: 0x88
    // 0xcf93bc: EnterFrame
    //     0xcf93bc: stp             fp, lr, [SP, #-0x10]!
    //     0xcf93c0: mov             fp, SP
    // 0xcf93c4: CheckStackOverflow
    //     0xcf93c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf93c8: cmp             SP, x16
    //     0xcf93cc: b.ls            #0xcf9424
    // 0xcf93d0: ldr             x0, [fp, #0x10]
    // 0xcf93d4: r2 = Null
    //     0xcf93d4: mov             x2, NULL
    // 0xcf93d8: r1 = Null
    //     0xcf93d8: mov             x1, NULL
    // 0xcf93dc: r4 = 59
    //     0xcf93dc: mov             x4, #0x3b
    // 0xcf93e0: branchIfSmi(r0, 0xcf93ec)
    //     0xcf93e0: tbz             w0, #0, #0xcf93ec
    // 0xcf93e4: r4 = LoadClassIdInstr(r0)
    //     0xcf93e4: ldur            x4, [x0, #-1]
    //     0xcf93e8: ubfx            x4, x4, #0xc, #0x14
    // 0xcf93ec: cmp             x4, #0x3d
    // 0xcf93f0: b.eq            #0xcf9404
    // 0xcf93f4: r8 = double
    //     0xcf93f4: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0xcf93f8: r3 = Null
    //     0xcf93f8: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b468] Null
    //     0xcf93fc: ldr             x3, [x3, #0x468]
    // 0xcf9400: r0 = double()
    //     0xcf9400: bl              #0xd72bac  ; IsType_double_Stub
    // 0xcf9404: ldr             x16, [fp, #0x18]
    // 0xcf9408: ldr             lr, [fp, #0x10]
    // 0xcf940c: stp             lr, x16, [SP, #-0x10]!
    // 0xcf9410: r0 = /()
    //     0xcf9410: bl              #0xcf942c  ; [package:flutter/src/painting/border_radius.dart] _MixedBorderRadius::/
    // 0xcf9414: add             SP, SP, #0x10
    // 0xcf9418: LeaveFrame
    //     0xcf9418: mov             SP, fp
    //     0xcf941c: ldp             fp, lr, [SP], #0x10
    // 0xcf9420: ret
    //     0xcf9420: ret             
    // 0xcf9424: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf9424: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf9428: b               #0xcf93d0
  }
  _MixedBorderRadius /(_MixedBorderRadius, double) {
    // ** addr: 0xcf942c, size: 0x18c
    // 0xcf942c: EnterFrame
    //     0xcf942c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf9430: mov             fp, SP
    // 0xcf9434: AllocStack(0x40)
    //     0xcf9434: sub             SP, SP, #0x40
    // 0xcf9438: CheckStackOverflow
    //     0xcf9438: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf943c: cmp             SP, x16
    //     0xcf9440: b.ls            #0xcf95b0
    // 0xcf9444: ldr             x0, [fp, #0x18]
    // 0xcf9448: LoadField: r1 = r0->field_7
    //     0xcf9448: ldur            w1, [x0, #7]
    // 0xcf944c: DecompressPointer r1
    //     0xcf944c: add             x1, x1, HEAP, lsl #32
    // 0xcf9450: ldr             x16, [fp, #0x10]
    // 0xcf9454: stp             x16, x1, [SP, #-0x10]!
    // 0xcf9458: r0 = /()
    //     0xcf9458: bl              #0x595b04  ; [dart:ui] Radius::/
    // 0xcf945c: add             SP, SP, #0x10
    // 0xcf9460: mov             x1, x0
    // 0xcf9464: ldr             x0, [fp, #0x18]
    // 0xcf9468: stur            x1, [fp, #-8]
    // 0xcf946c: LoadField: r2 = r0->field_b
    //     0xcf946c: ldur            w2, [x0, #0xb]
    // 0xcf9470: DecompressPointer r2
    //     0xcf9470: add             x2, x2, HEAP, lsl #32
    // 0xcf9474: ldr             x16, [fp, #0x10]
    // 0xcf9478: stp             x16, x2, [SP, #-0x10]!
    // 0xcf947c: r0 = /()
    //     0xcf947c: bl              #0x595b04  ; [dart:ui] Radius::/
    // 0xcf9480: add             SP, SP, #0x10
    // 0xcf9484: mov             x1, x0
    // 0xcf9488: ldr             x0, [fp, #0x18]
    // 0xcf948c: stur            x1, [fp, #-0x10]
    // 0xcf9490: LoadField: r2 = r0->field_f
    //     0xcf9490: ldur            w2, [x0, #0xf]
    // 0xcf9494: DecompressPointer r2
    //     0xcf9494: add             x2, x2, HEAP, lsl #32
    // 0xcf9498: ldr             x16, [fp, #0x10]
    // 0xcf949c: stp             x16, x2, [SP, #-0x10]!
    // 0xcf94a0: r0 = /()
    //     0xcf94a0: bl              #0x595b04  ; [dart:ui] Radius::/
    // 0xcf94a4: add             SP, SP, #0x10
    // 0xcf94a8: mov             x1, x0
    // 0xcf94ac: ldr             x0, [fp, #0x18]
    // 0xcf94b0: stur            x1, [fp, #-0x18]
    // 0xcf94b4: LoadField: r2 = r0->field_13
    //     0xcf94b4: ldur            w2, [x0, #0x13]
    // 0xcf94b8: DecompressPointer r2
    //     0xcf94b8: add             x2, x2, HEAP, lsl #32
    // 0xcf94bc: ldr             x16, [fp, #0x10]
    // 0xcf94c0: stp             x16, x2, [SP, #-0x10]!
    // 0xcf94c4: r0 = /()
    //     0xcf94c4: bl              #0x595b04  ; [dart:ui] Radius::/
    // 0xcf94c8: add             SP, SP, #0x10
    // 0xcf94cc: mov             x1, x0
    // 0xcf94d0: ldr             x0, [fp, #0x18]
    // 0xcf94d4: stur            x1, [fp, #-0x20]
    // 0xcf94d8: LoadField: r2 = r0->field_17
    //     0xcf94d8: ldur            w2, [x0, #0x17]
    // 0xcf94dc: DecompressPointer r2
    //     0xcf94dc: add             x2, x2, HEAP, lsl #32
    // 0xcf94e0: ldr             x16, [fp, #0x10]
    // 0xcf94e4: stp             x16, x2, [SP, #-0x10]!
    // 0xcf94e8: r0 = /()
    //     0xcf94e8: bl              #0x595b04  ; [dart:ui] Radius::/
    // 0xcf94ec: add             SP, SP, #0x10
    // 0xcf94f0: mov             x1, x0
    // 0xcf94f4: ldr             x0, [fp, #0x18]
    // 0xcf94f8: stur            x1, [fp, #-0x28]
    // 0xcf94fc: LoadField: r2 = r0->field_1b
    //     0xcf94fc: ldur            w2, [x0, #0x1b]
    // 0xcf9500: DecompressPointer r2
    //     0xcf9500: add             x2, x2, HEAP, lsl #32
    // 0xcf9504: ldr             x16, [fp, #0x10]
    // 0xcf9508: stp             x16, x2, [SP, #-0x10]!
    // 0xcf950c: r0 = /()
    //     0xcf950c: bl              #0x595b04  ; [dart:ui] Radius::/
    // 0xcf9510: add             SP, SP, #0x10
    // 0xcf9514: mov             x1, x0
    // 0xcf9518: ldr             x0, [fp, #0x18]
    // 0xcf951c: stur            x1, [fp, #-0x30]
    // 0xcf9520: LoadField: r2 = r0->field_1f
    //     0xcf9520: ldur            w2, [x0, #0x1f]
    // 0xcf9524: DecompressPointer r2
    //     0xcf9524: add             x2, x2, HEAP, lsl #32
    // 0xcf9528: ldr             x16, [fp, #0x10]
    // 0xcf952c: stp             x16, x2, [SP, #-0x10]!
    // 0xcf9530: r0 = /()
    //     0xcf9530: bl              #0x595b04  ; [dart:ui] Radius::/
    // 0xcf9534: add             SP, SP, #0x10
    // 0xcf9538: mov             x1, x0
    // 0xcf953c: ldr             x0, [fp, #0x18]
    // 0xcf9540: stur            x1, [fp, #-0x38]
    // 0xcf9544: LoadField: r2 = r0->field_23
    //     0xcf9544: ldur            w2, [x0, #0x23]
    // 0xcf9548: DecompressPointer r2
    //     0xcf9548: add             x2, x2, HEAP, lsl #32
    // 0xcf954c: ldr             x16, [fp, #0x10]
    // 0xcf9550: stp             x16, x2, [SP, #-0x10]!
    // 0xcf9554: r0 = /()
    //     0xcf9554: bl              #0x595b04  ; [dart:ui] Radius::/
    // 0xcf9558: add             SP, SP, #0x10
    // 0xcf955c: stur            x0, [fp, #-0x40]
    // 0xcf9560: r0 = _MixedBorderRadius()
    //     0xcf9560: bl              #0xcf9398  ; Allocate_MixedBorderRadiusStub -> _MixedBorderRadius (size=0x28)
    // 0xcf9564: ldur            x1, [fp, #-8]
    // 0xcf9568: StoreField: r0->field_7 = r1
    //     0xcf9568: stur            w1, [x0, #7]
    // 0xcf956c: ldur            x1, [fp, #-0x10]
    // 0xcf9570: StoreField: r0->field_b = r1
    //     0xcf9570: stur            w1, [x0, #0xb]
    // 0xcf9574: ldur            x1, [fp, #-0x18]
    // 0xcf9578: StoreField: r0->field_f = r1
    //     0xcf9578: stur            w1, [x0, #0xf]
    // 0xcf957c: ldur            x1, [fp, #-0x20]
    // 0xcf9580: StoreField: r0->field_13 = r1
    //     0xcf9580: stur            w1, [x0, #0x13]
    // 0xcf9584: ldur            x1, [fp, #-0x28]
    // 0xcf9588: StoreField: r0->field_17 = r1
    //     0xcf9588: stur            w1, [x0, #0x17]
    // 0xcf958c: ldur            x1, [fp, #-0x30]
    // 0xcf9590: StoreField: r0->field_1b = r1
    //     0xcf9590: stur            w1, [x0, #0x1b]
    // 0xcf9594: ldur            x1, [fp, #-0x38]
    // 0xcf9598: StoreField: r0->field_1f = r1
    //     0xcf9598: stur            w1, [x0, #0x1f]
    // 0xcf959c: ldur            x1, [fp, #-0x40]
    // 0xcf95a0: StoreField: r0->field_23 = r1
    //     0xcf95a0: stur            w1, [x0, #0x23]
    // 0xcf95a4: LeaveFrame
    //     0xcf95a4: mov             SP, fp
    //     0xcf95a8: ldp             fp, lr, [SP], #0x10
    // 0xcf95ac: ret
    //     0xcf95ac: ret             
    // 0xcf95b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf95b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf95b4: b               #0xcf9444
  }
  _MixedBorderRadius *(_MixedBorderRadius, double) {
    // ** addr: 0xcf95d0, size: 0x88
    // 0xcf95d0: EnterFrame
    //     0xcf95d0: stp             fp, lr, [SP, #-0x10]!
    //     0xcf95d4: mov             fp, SP
    // 0xcf95d8: CheckStackOverflow
    //     0xcf95d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf95dc: cmp             SP, x16
    //     0xcf95e0: b.ls            #0xcf9638
    // 0xcf95e4: ldr             x0, [fp, #0x10]
    // 0xcf95e8: r2 = Null
    //     0xcf95e8: mov             x2, NULL
    // 0xcf95ec: r1 = Null
    //     0xcf95ec: mov             x1, NULL
    // 0xcf95f0: r4 = 59
    //     0xcf95f0: mov             x4, #0x3b
    // 0xcf95f4: branchIfSmi(r0, 0xcf9600)
    //     0xcf95f4: tbz             w0, #0, #0xcf9600
    // 0xcf95f8: r4 = LoadClassIdInstr(r0)
    //     0xcf95f8: ldur            x4, [x0, #-1]
    //     0xcf95fc: ubfx            x4, x4, #0xc, #0x14
    // 0xcf9600: cmp             x4, #0x3d
    // 0xcf9604: b.eq            #0xcf9618
    // 0xcf9608: r8 = double
    //     0xcf9608: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0xcf960c: r3 = Null
    //     0xcf960c: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3fe58] Null
    //     0xcf9610: ldr             x3, [x3, #0xe58]
    // 0xcf9614: r0 = double()
    //     0xcf9614: bl              #0xd72bac  ; IsType_double_Stub
    // 0xcf9618: ldr             x16, [fp, #0x18]
    // 0xcf961c: ldr             lr, [fp, #0x10]
    // 0xcf9620: stp             lr, x16, [SP, #-0x10]!
    // 0xcf9624: r0 = *()
    //     0xcf9624: bl              #0xcfb6cc  ; [package:flutter/src/painting/border_radius.dart] _MixedBorderRadius::*
    // 0xcf9628: add             SP, SP, #0x10
    // 0xcf962c: LeaveFrame
    //     0xcf962c: mov             SP, fp
    //     0xcf9630: ldp             fp, lr, [SP], #0x10
    // 0xcf9634: ret
    //     0xcf9634: ret             
    // 0xcf9638: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf9638: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf963c: b               #0xcf95e4
  }
  _MixedBorderRadius *(_MixedBorderRadius, double) {
    // ** addr: 0xcfb6cc, size: 0x18c
    // 0xcfb6cc: EnterFrame
    //     0xcfb6cc: stp             fp, lr, [SP, #-0x10]!
    //     0xcfb6d0: mov             fp, SP
    // 0xcfb6d4: AllocStack(0x40)
    //     0xcfb6d4: sub             SP, SP, #0x40
    // 0xcfb6d8: CheckStackOverflow
    //     0xcfb6d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcfb6dc: cmp             SP, x16
    //     0xcfb6e0: b.ls            #0xcfb850
    // 0xcfb6e4: ldr             x0, [fp, #0x18]
    // 0xcfb6e8: LoadField: r1 = r0->field_7
    //     0xcfb6e8: ldur            w1, [x0, #7]
    // 0xcfb6ec: DecompressPointer r1
    //     0xcfb6ec: add             x1, x1, HEAP, lsl #32
    // 0xcfb6f0: ldr             x16, [fp, #0x10]
    // 0xcfb6f4: stp             x16, x1, [SP, #-0x10]!
    // 0xcfb6f8: r0 = *()
    //     0xcfb6f8: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcfb6fc: add             SP, SP, #0x10
    // 0xcfb700: mov             x1, x0
    // 0xcfb704: ldr             x0, [fp, #0x18]
    // 0xcfb708: stur            x1, [fp, #-8]
    // 0xcfb70c: LoadField: r2 = r0->field_b
    //     0xcfb70c: ldur            w2, [x0, #0xb]
    // 0xcfb710: DecompressPointer r2
    //     0xcfb710: add             x2, x2, HEAP, lsl #32
    // 0xcfb714: ldr             x16, [fp, #0x10]
    // 0xcfb718: stp             x16, x2, [SP, #-0x10]!
    // 0xcfb71c: r0 = *()
    //     0xcfb71c: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcfb720: add             SP, SP, #0x10
    // 0xcfb724: mov             x1, x0
    // 0xcfb728: ldr             x0, [fp, #0x18]
    // 0xcfb72c: stur            x1, [fp, #-0x10]
    // 0xcfb730: LoadField: r2 = r0->field_f
    //     0xcfb730: ldur            w2, [x0, #0xf]
    // 0xcfb734: DecompressPointer r2
    //     0xcfb734: add             x2, x2, HEAP, lsl #32
    // 0xcfb738: ldr             x16, [fp, #0x10]
    // 0xcfb73c: stp             x16, x2, [SP, #-0x10]!
    // 0xcfb740: r0 = *()
    //     0xcfb740: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcfb744: add             SP, SP, #0x10
    // 0xcfb748: mov             x1, x0
    // 0xcfb74c: ldr             x0, [fp, #0x18]
    // 0xcfb750: stur            x1, [fp, #-0x18]
    // 0xcfb754: LoadField: r2 = r0->field_13
    //     0xcfb754: ldur            w2, [x0, #0x13]
    // 0xcfb758: DecompressPointer r2
    //     0xcfb758: add             x2, x2, HEAP, lsl #32
    // 0xcfb75c: ldr             x16, [fp, #0x10]
    // 0xcfb760: stp             x16, x2, [SP, #-0x10]!
    // 0xcfb764: r0 = *()
    //     0xcfb764: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcfb768: add             SP, SP, #0x10
    // 0xcfb76c: mov             x1, x0
    // 0xcfb770: ldr             x0, [fp, #0x18]
    // 0xcfb774: stur            x1, [fp, #-0x20]
    // 0xcfb778: LoadField: r2 = r0->field_17
    //     0xcfb778: ldur            w2, [x0, #0x17]
    // 0xcfb77c: DecompressPointer r2
    //     0xcfb77c: add             x2, x2, HEAP, lsl #32
    // 0xcfb780: ldr             x16, [fp, #0x10]
    // 0xcfb784: stp             x16, x2, [SP, #-0x10]!
    // 0xcfb788: r0 = *()
    //     0xcfb788: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcfb78c: add             SP, SP, #0x10
    // 0xcfb790: mov             x1, x0
    // 0xcfb794: ldr             x0, [fp, #0x18]
    // 0xcfb798: stur            x1, [fp, #-0x28]
    // 0xcfb79c: LoadField: r2 = r0->field_1b
    //     0xcfb79c: ldur            w2, [x0, #0x1b]
    // 0xcfb7a0: DecompressPointer r2
    //     0xcfb7a0: add             x2, x2, HEAP, lsl #32
    // 0xcfb7a4: ldr             x16, [fp, #0x10]
    // 0xcfb7a8: stp             x16, x2, [SP, #-0x10]!
    // 0xcfb7ac: r0 = *()
    //     0xcfb7ac: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcfb7b0: add             SP, SP, #0x10
    // 0xcfb7b4: mov             x1, x0
    // 0xcfb7b8: ldr             x0, [fp, #0x18]
    // 0xcfb7bc: stur            x1, [fp, #-0x30]
    // 0xcfb7c0: LoadField: r2 = r0->field_1f
    //     0xcfb7c0: ldur            w2, [x0, #0x1f]
    // 0xcfb7c4: DecompressPointer r2
    //     0xcfb7c4: add             x2, x2, HEAP, lsl #32
    // 0xcfb7c8: ldr             x16, [fp, #0x10]
    // 0xcfb7cc: stp             x16, x2, [SP, #-0x10]!
    // 0xcfb7d0: r0 = *()
    //     0xcfb7d0: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcfb7d4: add             SP, SP, #0x10
    // 0xcfb7d8: mov             x1, x0
    // 0xcfb7dc: ldr             x0, [fp, #0x18]
    // 0xcfb7e0: stur            x1, [fp, #-0x38]
    // 0xcfb7e4: LoadField: r2 = r0->field_23
    //     0xcfb7e4: ldur            w2, [x0, #0x23]
    // 0xcfb7e8: DecompressPointer r2
    //     0xcfb7e8: add             x2, x2, HEAP, lsl #32
    // 0xcfb7ec: ldr             x16, [fp, #0x10]
    // 0xcfb7f0: stp             x16, x2, [SP, #-0x10]!
    // 0xcfb7f4: r0 = *()
    //     0xcfb7f4: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcfb7f8: add             SP, SP, #0x10
    // 0xcfb7fc: stur            x0, [fp, #-0x40]
    // 0xcfb800: r0 = _MixedBorderRadius()
    //     0xcfb800: bl              #0xcf9398  ; Allocate_MixedBorderRadiusStub -> _MixedBorderRadius (size=0x28)
    // 0xcfb804: ldur            x1, [fp, #-8]
    // 0xcfb808: StoreField: r0->field_7 = r1
    //     0xcfb808: stur            w1, [x0, #7]
    // 0xcfb80c: ldur            x1, [fp, #-0x10]
    // 0xcfb810: StoreField: r0->field_b = r1
    //     0xcfb810: stur            w1, [x0, #0xb]
    // 0xcfb814: ldur            x1, [fp, #-0x18]
    // 0xcfb818: StoreField: r0->field_f = r1
    //     0xcfb818: stur            w1, [x0, #0xf]
    // 0xcfb81c: ldur            x1, [fp, #-0x20]
    // 0xcfb820: StoreField: r0->field_13 = r1
    //     0xcfb820: stur            w1, [x0, #0x13]
    // 0xcfb824: ldur            x1, [fp, #-0x28]
    // 0xcfb828: StoreField: r0->field_17 = r1
    //     0xcfb828: stur            w1, [x0, #0x17]
    // 0xcfb82c: ldur            x1, [fp, #-0x30]
    // 0xcfb830: StoreField: r0->field_1b = r1
    //     0xcfb830: stur            w1, [x0, #0x1b]
    // 0xcfb834: ldur            x1, [fp, #-0x38]
    // 0xcfb838: StoreField: r0->field_1f = r1
    //     0xcfb838: stur            w1, [x0, #0x1f]
    // 0xcfb83c: ldur            x1, [fp, #-0x40]
    // 0xcfb840: StoreField: r0->field_23 = r1
    //     0xcfb840: stur            w1, [x0, #0x23]
    // 0xcfb844: LeaveFrame
    //     0xcfb844: mov             SP, fp
    //     0xcfb848: ldp             fp, lr, [SP], #0x10
    // 0xcfb84c: ret
    //     0xcfb84c: ret             
    // 0xcfb850: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfb850: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfb854: b               #0xcfb6e4
  }
  _ resolve(/* No info */) {
    // ** addr: 0xcfbdac, size: 0x1dc
    // 0xcfbdac: EnterFrame
    //     0xcfbdac: stp             fp, lr, [SP, #-0x10]!
    //     0xcfbdb0: mov             fp, SP
    // 0xcfbdb4: AllocStack(0x20)
    //     0xcfbdb4: sub             SP, SP, #0x20
    // 0xcfbdb8: CheckStackOverflow
    //     0xcfbdb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcfbdbc: cmp             SP, x16
    //     0xcfbdc0: b.ls            #0xcfbf7c
    // 0xcfbdc4: ldr             x0, [fp, #0x10]
    // 0xcfbdc8: cmp             w0, NULL
    // 0xcfbdcc: b.eq            #0xcfbf84
    // 0xcfbdd0: LoadField: r1 = r0->field_7
    //     0xcfbdd0: ldur            x1, [x0, #7]
    // 0xcfbdd4: cmp             x1, #0
    // 0xcfbdd8: b.gt            #0xcfbeb0
    // 0xcfbddc: ldr             x0, [fp, #0x18]
    // 0xcfbde0: LoadField: r1 = r0->field_7
    //     0xcfbde0: ldur            w1, [x0, #7]
    // 0xcfbde4: DecompressPointer r1
    //     0xcfbde4: add             x1, x1, HEAP, lsl #32
    // 0xcfbde8: LoadField: r2 = r0->field_1b
    //     0xcfbde8: ldur            w2, [x0, #0x1b]
    // 0xcfbdec: DecompressPointer r2
    //     0xcfbdec: add             x2, x2, HEAP, lsl #32
    // 0xcfbdf0: stp             x2, x1, [SP, #-0x10]!
    // 0xcfbdf4: r0 = +()
    //     0xcfbdf4: bl              #0x595d44  ; [dart:ui] Radius::+
    // 0xcfbdf8: add             SP, SP, #0x10
    // 0xcfbdfc: mov             x1, x0
    // 0xcfbe00: ldr             x0, [fp, #0x18]
    // 0xcfbe04: stur            x1, [fp, #-8]
    // 0xcfbe08: LoadField: r2 = r0->field_b
    //     0xcfbe08: ldur            w2, [x0, #0xb]
    // 0xcfbe0c: DecompressPointer r2
    //     0xcfbe0c: add             x2, x2, HEAP, lsl #32
    // 0xcfbe10: LoadField: r3 = r0->field_17
    //     0xcfbe10: ldur            w3, [x0, #0x17]
    // 0xcfbe14: DecompressPointer r3
    //     0xcfbe14: add             x3, x3, HEAP, lsl #32
    // 0xcfbe18: stp             x3, x2, [SP, #-0x10]!
    // 0xcfbe1c: r0 = +()
    //     0xcfbe1c: bl              #0x595d44  ; [dart:ui] Radius::+
    // 0xcfbe20: add             SP, SP, #0x10
    // 0xcfbe24: mov             x1, x0
    // 0xcfbe28: ldr             x0, [fp, #0x18]
    // 0xcfbe2c: stur            x1, [fp, #-0x10]
    // 0xcfbe30: LoadField: r2 = r0->field_f
    //     0xcfbe30: ldur            w2, [x0, #0xf]
    // 0xcfbe34: DecompressPointer r2
    //     0xcfbe34: add             x2, x2, HEAP, lsl #32
    // 0xcfbe38: LoadField: r3 = r0->field_23
    //     0xcfbe38: ldur            w3, [x0, #0x23]
    // 0xcfbe3c: DecompressPointer r3
    //     0xcfbe3c: add             x3, x3, HEAP, lsl #32
    // 0xcfbe40: stp             x3, x2, [SP, #-0x10]!
    // 0xcfbe44: r0 = +()
    //     0xcfbe44: bl              #0x595d44  ; [dart:ui] Radius::+
    // 0xcfbe48: add             SP, SP, #0x10
    // 0xcfbe4c: mov             x1, x0
    // 0xcfbe50: ldr             x0, [fp, #0x18]
    // 0xcfbe54: stur            x1, [fp, #-0x18]
    // 0xcfbe58: LoadField: r2 = r0->field_13
    //     0xcfbe58: ldur            w2, [x0, #0x13]
    // 0xcfbe5c: DecompressPointer r2
    //     0xcfbe5c: add             x2, x2, HEAP, lsl #32
    // 0xcfbe60: LoadField: r3 = r0->field_1f
    //     0xcfbe60: ldur            w3, [x0, #0x1f]
    // 0xcfbe64: DecompressPointer r3
    //     0xcfbe64: add             x3, x3, HEAP, lsl #32
    // 0xcfbe68: stp             x3, x2, [SP, #-0x10]!
    // 0xcfbe6c: r0 = +()
    //     0xcfbe6c: bl              #0x595d44  ; [dart:ui] Radius::+
    // 0xcfbe70: add             SP, SP, #0x10
    // 0xcfbe74: stur            x0, [fp, #-0x20]
    // 0xcfbe78: r0 = BorderRadius()
    //     0xcfbe78: bl              #0x596250  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xcfbe7c: mov             x1, x0
    // 0xcfbe80: ldur            x0, [fp, #-8]
    // 0xcfbe84: StoreField: r1->field_7 = r0
    //     0xcfbe84: stur            w0, [x1, #7]
    // 0xcfbe88: ldur            x0, [fp, #-0x10]
    // 0xcfbe8c: StoreField: r1->field_b = r0
    //     0xcfbe8c: stur            w0, [x1, #0xb]
    // 0xcfbe90: ldur            x0, [fp, #-0x18]
    // 0xcfbe94: StoreField: r1->field_f = r0
    //     0xcfbe94: stur            w0, [x1, #0xf]
    // 0xcfbe98: ldur            x0, [fp, #-0x20]
    // 0xcfbe9c: StoreField: r1->field_13 = r0
    //     0xcfbe9c: stur            w0, [x1, #0x13]
    // 0xcfbea0: mov             x0, x1
    // 0xcfbea4: LeaveFrame
    //     0xcfbea4: mov             SP, fp
    //     0xcfbea8: ldp             fp, lr, [SP], #0x10
    // 0xcfbeac: ret
    //     0xcfbeac: ret             
    // 0xcfbeb0: ldr             x0, [fp, #0x18]
    // 0xcfbeb4: LoadField: r1 = r0->field_7
    //     0xcfbeb4: ldur            w1, [x0, #7]
    // 0xcfbeb8: DecompressPointer r1
    //     0xcfbeb8: add             x1, x1, HEAP, lsl #32
    // 0xcfbebc: LoadField: r2 = r0->field_17
    //     0xcfbebc: ldur            w2, [x0, #0x17]
    // 0xcfbec0: DecompressPointer r2
    //     0xcfbec0: add             x2, x2, HEAP, lsl #32
    // 0xcfbec4: stp             x2, x1, [SP, #-0x10]!
    // 0xcfbec8: r0 = +()
    //     0xcfbec8: bl              #0x595d44  ; [dart:ui] Radius::+
    // 0xcfbecc: add             SP, SP, #0x10
    // 0xcfbed0: mov             x1, x0
    // 0xcfbed4: ldr             x0, [fp, #0x18]
    // 0xcfbed8: stur            x1, [fp, #-8]
    // 0xcfbedc: LoadField: r2 = r0->field_b
    //     0xcfbedc: ldur            w2, [x0, #0xb]
    // 0xcfbee0: DecompressPointer r2
    //     0xcfbee0: add             x2, x2, HEAP, lsl #32
    // 0xcfbee4: LoadField: r3 = r0->field_1b
    //     0xcfbee4: ldur            w3, [x0, #0x1b]
    // 0xcfbee8: DecompressPointer r3
    //     0xcfbee8: add             x3, x3, HEAP, lsl #32
    // 0xcfbeec: stp             x3, x2, [SP, #-0x10]!
    // 0xcfbef0: r0 = +()
    //     0xcfbef0: bl              #0x595d44  ; [dart:ui] Radius::+
    // 0xcfbef4: add             SP, SP, #0x10
    // 0xcfbef8: mov             x1, x0
    // 0xcfbefc: ldr             x0, [fp, #0x18]
    // 0xcfbf00: stur            x1, [fp, #-0x10]
    // 0xcfbf04: LoadField: r2 = r0->field_f
    //     0xcfbf04: ldur            w2, [x0, #0xf]
    // 0xcfbf08: DecompressPointer r2
    //     0xcfbf08: add             x2, x2, HEAP, lsl #32
    // 0xcfbf0c: LoadField: r3 = r0->field_1f
    //     0xcfbf0c: ldur            w3, [x0, #0x1f]
    // 0xcfbf10: DecompressPointer r3
    //     0xcfbf10: add             x3, x3, HEAP, lsl #32
    // 0xcfbf14: stp             x3, x2, [SP, #-0x10]!
    // 0xcfbf18: r0 = +()
    //     0xcfbf18: bl              #0x595d44  ; [dart:ui] Radius::+
    // 0xcfbf1c: add             SP, SP, #0x10
    // 0xcfbf20: mov             x1, x0
    // 0xcfbf24: ldr             x0, [fp, #0x18]
    // 0xcfbf28: stur            x1, [fp, #-0x18]
    // 0xcfbf2c: LoadField: r2 = r0->field_13
    //     0xcfbf2c: ldur            w2, [x0, #0x13]
    // 0xcfbf30: DecompressPointer r2
    //     0xcfbf30: add             x2, x2, HEAP, lsl #32
    // 0xcfbf34: LoadField: r3 = r0->field_23
    //     0xcfbf34: ldur            w3, [x0, #0x23]
    // 0xcfbf38: DecompressPointer r3
    //     0xcfbf38: add             x3, x3, HEAP, lsl #32
    // 0xcfbf3c: stp             x3, x2, [SP, #-0x10]!
    // 0xcfbf40: r0 = +()
    //     0xcfbf40: bl              #0x595d44  ; [dart:ui] Radius::+
    // 0xcfbf44: add             SP, SP, #0x10
    // 0xcfbf48: stur            x0, [fp, #-0x20]
    // 0xcfbf4c: r0 = BorderRadius()
    //     0xcfbf4c: bl              #0x596250  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xcfbf50: ldur            x1, [fp, #-8]
    // 0xcfbf54: StoreField: r0->field_7 = r1
    //     0xcfbf54: stur            w1, [x0, #7]
    // 0xcfbf58: ldur            x1, [fp, #-0x10]
    // 0xcfbf5c: StoreField: r0->field_b = r1
    //     0xcfbf5c: stur            w1, [x0, #0xb]
    // 0xcfbf60: ldur            x1, [fp, #-0x18]
    // 0xcfbf64: StoreField: r0->field_f = r1
    //     0xcfbf64: stur            w1, [x0, #0xf]
    // 0xcfbf68: ldur            x1, [fp, #-0x20]
    // 0xcfbf6c: StoreField: r0->field_13 = r1
    //     0xcfbf6c: stur            w1, [x0, #0x13]
    // 0xcfbf70: LeaveFrame
    //     0xcfbf70: mov             SP, fp
    //     0xcfbf74: ldp             fp, lr, [SP], #0x10
    // 0xcfbf78: ret
    //     0xcfbf78: ret             
    // 0xcfbf7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfbf7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfbf80: b               #0xcfbdc4
    // 0xcfbf84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcfbf84: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2112, size: 0x18, field offset: 0x8
//   const constructor, 
class BorderRadius extends BorderRadiusGeometry {

  Radius field_8;
  Radius field_c;
  Radius field_10;
  Radius field_14;

  BorderRadius /(BorderRadius, double) {
    // ** addr: 0x5959b8, size: 0x88
    // 0x5959b8: EnterFrame
    //     0x5959b8: stp             fp, lr, [SP, #-0x10]!
    //     0x5959bc: mov             fp, SP
    // 0x5959c0: CheckStackOverflow
    //     0x5959c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5959c4: cmp             SP, x16
    //     0x5959c8: b.ls            #0x595a20
    // 0x5959cc: ldr             x0, [fp, #0x10]
    // 0x5959d0: r2 = Null
    //     0x5959d0: mov             x2, NULL
    // 0x5959d4: r1 = Null
    //     0x5959d4: mov             x1, NULL
    // 0x5959d8: r4 = 59
    //     0x5959d8: mov             x4, #0x3b
    // 0x5959dc: branchIfSmi(r0, 0x5959e8)
    //     0x5959dc: tbz             w0, #0, #0x5959e8
    // 0x5959e0: r4 = LoadClassIdInstr(r0)
    //     0x5959e0: ldur            x4, [x0, #-1]
    //     0x5959e4: ubfx            x4, x4, #0xc, #0x14
    // 0x5959e8: cmp             x4, #0x3d
    // 0x5959ec: b.eq            #0x595a00
    // 0x5959f0: r8 = double
    //     0x5959f0: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0x5959f4: r3 = Null
    //     0x5959f4: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b458] Null
    //     0x5959f8: ldr             x3, [x3, #0x458]
    // 0x5959fc: r0 = double()
    //     0x5959fc: bl              #0xd72bac  ; IsType_double_Stub
    // 0x595a00: ldr             x16, [fp, #0x18]
    // 0x595a04: ldr             lr, [fp, #0x10]
    // 0x595a08: stp             lr, x16, [SP, #-0x10]!
    // 0x595a0c: r0 = /()
    //     0x595a0c: bl              #0x595a28  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::/
    // 0x595a10: add             SP, SP, #0x10
    // 0x595a14: LeaveFrame
    //     0x595a14: mov             SP, fp
    //     0x595a18: ldp             fp, lr, [SP], #0x10
    // 0x595a1c: ret
    //     0x595a1c: ret             
    // 0x595a20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x595a20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x595a24: b               #0x5959cc
  }
  BorderRadius /(BorderRadius, double) {
    // ** addr: 0x595a28, size: 0xdc
    // 0x595a28: EnterFrame
    //     0x595a28: stp             fp, lr, [SP, #-0x10]!
    //     0x595a2c: mov             fp, SP
    // 0x595a30: AllocStack(0x20)
    //     0x595a30: sub             SP, SP, #0x20
    // 0x595a34: CheckStackOverflow
    //     0x595a34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x595a38: cmp             SP, x16
    //     0x595a3c: b.ls            #0x595afc
    // 0x595a40: ldr             x0, [fp, #0x18]
    // 0x595a44: LoadField: r1 = r0->field_7
    //     0x595a44: ldur            w1, [x0, #7]
    // 0x595a48: DecompressPointer r1
    //     0x595a48: add             x1, x1, HEAP, lsl #32
    // 0x595a4c: ldr             x16, [fp, #0x10]
    // 0x595a50: stp             x16, x1, [SP, #-0x10]!
    // 0x595a54: r0 = /()
    //     0x595a54: bl              #0x595b04  ; [dart:ui] Radius::/
    // 0x595a58: add             SP, SP, #0x10
    // 0x595a5c: mov             x1, x0
    // 0x595a60: ldr             x0, [fp, #0x18]
    // 0x595a64: stur            x1, [fp, #-8]
    // 0x595a68: LoadField: r2 = r0->field_b
    //     0x595a68: ldur            w2, [x0, #0xb]
    // 0x595a6c: DecompressPointer r2
    //     0x595a6c: add             x2, x2, HEAP, lsl #32
    // 0x595a70: ldr             x16, [fp, #0x10]
    // 0x595a74: stp             x16, x2, [SP, #-0x10]!
    // 0x595a78: r0 = /()
    //     0x595a78: bl              #0x595b04  ; [dart:ui] Radius::/
    // 0x595a7c: add             SP, SP, #0x10
    // 0x595a80: mov             x1, x0
    // 0x595a84: ldr             x0, [fp, #0x18]
    // 0x595a88: stur            x1, [fp, #-0x10]
    // 0x595a8c: LoadField: r2 = r0->field_f
    //     0x595a8c: ldur            w2, [x0, #0xf]
    // 0x595a90: DecompressPointer r2
    //     0x595a90: add             x2, x2, HEAP, lsl #32
    // 0x595a94: ldr             x16, [fp, #0x10]
    // 0x595a98: stp             x16, x2, [SP, #-0x10]!
    // 0x595a9c: r0 = /()
    //     0x595a9c: bl              #0x595b04  ; [dart:ui] Radius::/
    // 0x595aa0: add             SP, SP, #0x10
    // 0x595aa4: mov             x1, x0
    // 0x595aa8: ldr             x0, [fp, #0x18]
    // 0x595aac: stur            x1, [fp, #-0x18]
    // 0x595ab0: LoadField: r2 = r0->field_13
    //     0x595ab0: ldur            w2, [x0, #0x13]
    // 0x595ab4: DecompressPointer r2
    //     0x595ab4: add             x2, x2, HEAP, lsl #32
    // 0x595ab8: ldr             x16, [fp, #0x10]
    // 0x595abc: stp             x16, x2, [SP, #-0x10]!
    // 0x595ac0: r0 = /()
    //     0x595ac0: bl              #0x595b04  ; [dart:ui] Radius::/
    // 0x595ac4: add             SP, SP, #0x10
    // 0x595ac8: stur            x0, [fp, #-0x20]
    // 0x595acc: r0 = BorderRadius()
    //     0x595acc: bl              #0x596250  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x595ad0: ldur            x1, [fp, #-8]
    // 0x595ad4: StoreField: r0->field_7 = r1
    //     0x595ad4: stur            w1, [x0, #7]
    // 0x595ad8: ldur            x1, [fp, #-0x10]
    // 0x595adc: StoreField: r0->field_b = r1
    //     0x595adc: stur            w1, [x0, #0xb]
    // 0x595ae0: ldur            x1, [fp, #-0x18]
    // 0x595ae4: StoreField: r0->field_f = r1
    //     0x595ae4: stur            w1, [x0, #0xf]
    // 0x595ae8: ldur            x1, [fp, #-0x20]
    // 0x595aec: StoreField: r0->field_13 = r1
    //     0x595aec: stur            w1, [x0, #0x13]
    // 0x595af0: LeaveFrame
    //     0x595af0: mov             SP, fp
    //     0x595af4: ldp             fp, lr, [SP], #0x10
    // 0x595af8: ret
    //     0x595af8: ret             
    // 0x595afc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x595afc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x595b00: b               #0x595a40
  }
  BorderRadius *(BorderRadius, double) {
    // ** addr: 0x595e94, size: 0x88
    // 0x595e94: EnterFrame
    //     0x595e94: stp             fp, lr, [SP, #-0x10]!
    //     0x595e98: mov             fp, SP
    // 0x595e9c: CheckStackOverflow
    //     0x595e9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x595ea0: cmp             SP, x16
    //     0x595ea4: b.ls            #0x595efc
    // 0x595ea8: ldr             x0, [fp, #0x10]
    // 0x595eac: r2 = Null
    //     0x595eac: mov             x2, NULL
    // 0x595eb0: r1 = Null
    //     0x595eb0: mov             x1, NULL
    // 0x595eb4: r4 = 59
    //     0x595eb4: mov             x4, #0x3b
    // 0x595eb8: branchIfSmi(r0, 0x595ec4)
    //     0x595eb8: tbz             w0, #0, #0x595ec4
    // 0x595ebc: r4 = LoadClassIdInstr(r0)
    //     0x595ebc: ldur            x4, [x0, #-1]
    //     0x595ec0: ubfx            x4, x4, #0xc, #0x14
    // 0x595ec4: cmp             x4, #0x3d
    // 0x595ec8: b.eq            #0x595edc
    // 0x595ecc: r8 = double
    //     0x595ecc: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0x595ed0: r3 = Null
    //     0x595ed0: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2db08] Null
    //     0x595ed4: ldr             x3, [x3, #0xb08]
    // 0x595ed8: r0 = double()
    //     0x595ed8: bl              #0xd72bac  ; IsType_double_Stub
    // 0x595edc: ldr             x16, [fp, #0x18]
    // 0x595ee0: ldr             lr, [fp, #0x10]
    // 0x595ee4: stp             lr, x16, [SP, #-0x10]!
    // 0x595ee8: r0 = *()
    //     0x595ee8: bl              #0xcfb5f0  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::*
    // 0x595eec: add             SP, SP, #0x10
    // 0x595ef0: LeaveFrame
    //     0x595ef0: mov             SP, fp
    //     0x595ef4: ldp             fp, lr, [SP], #0x10
    // 0x595ef8: ret
    //     0x595ef8: ret             
    // 0x595efc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x595efc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x595f00: b               #0x595ea8
  }
  BorderRadius +(BorderRadius, BorderRadius) {
    // ** addr: 0x595f1c, size: 0x8c
    // 0x595f1c: EnterFrame
    //     0x595f1c: stp             fp, lr, [SP, #-0x10]!
    //     0x595f20: mov             fp, SP
    // 0x595f24: CheckStackOverflow
    //     0x595f24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x595f28: cmp             SP, x16
    //     0x595f2c: b.ls            #0x595f88
    // 0x595f30: ldr             x0, [fp, #0x10]
    // 0x595f34: r2 = Null
    //     0x595f34: mov             x2, NULL
    // 0x595f38: r1 = Null
    //     0x595f38: mov             x1, NULL
    // 0x595f3c: r4 = 59
    //     0x595f3c: mov             x4, #0x3b
    // 0x595f40: branchIfSmi(r0, 0x595f4c)
    //     0x595f40: tbz             w0, #0, #0x595f4c
    // 0x595f44: r4 = LoadClassIdInstr(r0)
    //     0x595f44: ldur            x4, [x0, #-1]
    //     0x595f48: ubfx            x4, x4, #0xc, #0x14
    // 0x595f4c: cmp             x4, #0x840
    // 0x595f50: b.eq            #0x595f68
    // 0x595f54: r8 = BorderRadius
    //     0x595f54: add             x8, PP, #0x28, lsl #12  ; [pp+0x283b8] Type: BorderRadius
    //     0x595f58: ldr             x8, [x8, #0x3b8]
    // 0x595f5c: r3 = Null
    //     0x595f5c: add             x3, PP, #0x28, lsl #12  ; [pp+0x288c8] Null
    //     0x595f60: ldr             x3, [x3, #0x8c8]
    // 0x595f64: r0 = DefaultTypeTest()
    //     0x595f64: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x595f68: ldr             x16, [fp, #0x18]
    // 0x595f6c: ldr             lr, [fp, #0x10]
    // 0x595f70: stp             lr, x16, [SP, #-0x10]!
    // 0x595f74: r0 = +()
    //     0x595f74: bl              #0x595f90  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::+
    // 0x595f78: add             SP, SP, #0x10
    // 0x595f7c: LeaveFrame
    //     0x595f7c: mov             SP, fp
    //     0x595f80: ldp             fp, lr, [SP], #0x10
    // 0x595f84: ret
    //     0x595f84: ret             
    // 0x595f88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x595f88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x595f8c: b               #0x595f30
  }
  BorderRadius +(BorderRadius, BorderRadius) {
    // ** addr: 0x595f90, size: 0xfc
    // 0x595f90: EnterFrame
    //     0x595f90: stp             fp, lr, [SP, #-0x10]!
    //     0x595f94: mov             fp, SP
    // 0x595f98: AllocStack(0x20)
    //     0x595f98: sub             SP, SP, #0x20
    // 0x595f9c: CheckStackOverflow
    //     0x595f9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x595fa0: cmp             SP, x16
    //     0x595fa4: b.ls            #0x596084
    // 0x595fa8: ldr             x0, [fp, #0x18]
    // 0x595fac: LoadField: r1 = r0->field_7
    //     0x595fac: ldur            w1, [x0, #7]
    // 0x595fb0: DecompressPointer r1
    //     0x595fb0: add             x1, x1, HEAP, lsl #32
    // 0x595fb4: ldr             x2, [fp, #0x10]
    // 0x595fb8: LoadField: r3 = r2->field_7
    //     0x595fb8: ldur            w3, [x2, #7]
    // 0x595fbc: DecompressPointer r3
    //     0x595fbc: add             x3, x3, HEAP, lsl #32
    // 0x595fc0: stp             x3, x1, [SP, #-0x10]!
    // 0x595fc4: r0 = +()
    //     0x595fc4: bl              #0x595d44  ; [dart:ui] Radius::+
    // 0x595fc8: add             SP, SP, #0x10
    // 0x595fcc: mov             x1, x0
    // 0x595fd0: ldr             x0, [fp, #0x18]
    // 0x595fd4: stur            x1, [fp, #-8]
    // 0x595fd8: LoadField: r2 = r0->field_b
    //     0x595fd8: ldur            w2, [x0, #0xb]
    // 0x595fdc: DecompressPointer r2
    //     0x595fdc: add             x2, x2, HEAP, lsl #32
    // 0x595fe0: ldr             x3, [fp, #0x10]
    // 0x595fe4: LoadField: r4 = r3->field_b
    //     0x595fe4: ldur            w4, [x3, #0xb]
    // 0x595fe8: DecompressPointer r4
    //     0x595fe8: add             x4, x4, HEAP, lsl #32
    // 0x595fec: stp             x4, x2, [SP, #-0x10]!
    // 0x595ff0: r0 = +()
    //     0x595ff0: bl              #0x595d44  ; [dart:ui] Radius::+
    // 0x595ff4: add             SP, SP, #0x10
    // 0x595ff8: mov             x1, x0
    // 0x595ffc: ldr             x0, [fp, #0x18]
    // 0x596000: stur            x1, [fp, #-0x10]
    // 0x596004: LoadField: r2 = r0->field_f
    //     0x596004: ldur            w2, [x0, #0xf]
    // 0x596008: DecompressPointer r2
    //     0x596008: add             x2, x2, HEAP, lsl #32
    // 0x59600c: ldr             x3, [fp, #0x10]
    // 0x596010: LoadField: r4 = r3->field_f
    //     0x596010: ldur            w4, [x3, #0xf]
    // 0x596014: DecompressPointer r4
    //     0x596014: add             x4, x4, HEAP, lsl #32
    // 0x596018: stp             x4, x2, [SP, #-0x10]!
    // 0x59601c: r0 = +()
    //     0x59601c: bl              #0x595d44  ; [dart:ui] Radius::+
    // 0x596020: add             SP, SP, #0x10
    // 0x596024: mov             x1, x0
    // 0x596028: ldr             x0, [fp, #0x18]
    // 0x59602c: stur            x1, [fp, #-0x18]
    // 0x596030: LoadField: r2 = r0->field_13
    //     0x596030: ldur            w2, [x0, #0x13]
    // 0x596034: DecompressPointer r2
    //     0x596034: add             x2, x2, HEAP, lsl #32
    // 0x596038: ldr             x0, [fp, #0x10]
    // 0x59603c: LoadField: r3 = r0->field_13
    //     0x59603c: ldur            w3, [x0, #0x13]
    // 0x596040: DecompressPointer r3
    //     0x596040: add             x3, x3, HEAP, lsl #32
    // 0x596044: stp             x3, x2, [SP, #-0x10]!
    // 0x596048: r0 = +()
    //     0x596048: bl              #0x595d44  ; [dart:ui] Radius::+
    // 0x59604c: add             SP, SP, #0x10
    // 0x596050: stur            x0, [fp, #-0x20]
    // 0x596054: r0 = BorderRadius()
    //     0x596054: bl              #0x596250  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x596058: ldur            x1, [fp, #-8]
    // 0x59605c: StoreField: r0->field_7 = r1
    //     0x59605c: stur            w1, [x0, #7]
    // 0x596060: ldur            x1, [fp, #-0x10]
    // 0x596064: StoreField: r0->field_b = r1
    //     0x596064: stur            w1, [x0, #0xb]
    // 0x596068: ldur            x1, [fp, #-0x18]
    // 0x59606c: StoreField: r0->field_f = r1
    //     0x59606c: stur            w1, [x0, #0xf]
    // 0x596070: ldur            x1, [fp, #-0x20]
    // 0x596074: StoreField: r0->field_13 = r1
    //     0x596074: stur            w1, [x0, #0x13]
    // 0x596078: LeaveFrame
    //     0x596078: mov             SP, fp
    //     0x59607c: ldp             fp, lr, [SP], #0x10
    // 0x596080: ret
    //     0x596080: ret             
    // 0x596084: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x596084: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x596088: b               #0x595fa8
  }
  BorderRadius -(BorderRadius, BorderRadius) {
    // ** addr: 0x5960a4, size: 0x8c
    // 0x5960a4: EnterFrame
    //     0x5960a4: stp             fp, lr, [SP, #-0x10]!
    //     0x5960a8: mov             fp, SP
    // 0x5960ac: CheckStackOverflow
    //     0x5960ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5960b0: cmp             SP, x16
    //     0x5960b4: b.ls            #0x596110
    // 0x5960b8: ldr             x0, [fp, #0x10]
    // 0x5960bc: r2 = Null
    //     0x5960bc: mov             x2, NULL
    // 0x5960c0: r1 = Null
    //     0x5960c0: mov             x1, NULL
    // 0x5960c4: r4 = 59
    //     0x5960c4: mov             x4, #0x3b
    // 0x5960c8: branchIfSmi(r0, 0x5960d4)
    //     0x5960c8: tbz             w0, #0, #0x5960d4
    // 0x5960cc: r4 = LoadClassIdInstr(r0)
    //     0x5960cc: ldur            x4, [x0, #-1]
    //     0x5960d0: ubfx            x4, x4, #0xc, #0x14
    // 0x5960d4: cmp             x4, #0x840
    // 0x5960d8: b.eq            #0x5960f0
    // 0x5960dc: r8 = BorderRadius
    //     0x5960dc: add             x8, PP, #0x28, lsl #12  ; [pp+0x283b8] Type: BorderRadius
    //     0x5960e0: ldr             x8, [x8, #0x3b8]
    // 0x5960e4: r3 = Null
    //     0x5960e4: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2db18] Null
    //     0x5960e8: ldr             x3, [x3, #0xb18]
    // 0x5960ec: r0 = DefaultTypeTest()
    //     0x5960ec: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5960f0: ldr             x16, [fp, #0x18]
    // 0x5960f4: ldr             lr, [fp, #0x10]
    // 0x5960f8: stp             lr, x16, [SP, #-0x10]!
    // 0x5960fc: r0 = -()
    //     0x5960fc: bl              #0x596118  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::-
    // 0x596100: add             SP, SP, #0x10
    // 0x596104: LeaveFrame
    //     0x596104: mov             SP, fp
    //     0x596108: ldp             fp, lr, [SP], #0x10
    // 0x59610c: ret
    //     0x59610c: ret             
    // 0x596110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x596110: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x596114: b               #0x5960b8
  }
  BorderRadius -(BorderRadius, BorderRadius) {
    // ** addr: 0x596118, size: 0xfc
    // 0x596118: EnterFrame
    //     0x596118: stp             fp, lr, [SP, #-0x10]!
    //     0x59611c: mov             fp, SP
    // 0x596120: AllocStack(0x20)
    //     0x596120: sub             SP, SP, #0x20
    // 0x596124: CheckStackOverflow
    //     0x596124: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x596128: cmp             SP, x16
    //     0x59612c: b.ls            #0x59620c
    // 0x596130: ldr             x0, [fp, #0x18]
    // 0x596134: LoadField: r1 = r0->field_7
    //     0x596134: ldur            w1, [x0, #7]
    // 0x596138: DecompressPointer r1
    //     0x596138: add             x1, x1, HEAP, lsl #32
    // 0x59613c: ldr             x2, [fp, #0x10]
    // 0x596140: LoadField: r3 = r2->field_7
    //     0x596140: ldur            w3, [x2, #7]
    // 0x596144: DecompressPointer r3
    //     0x596144: add             x3, x3, HEAP, lsl #32
    // 0x596148: stp             x3, x1, [SP, #-0x10]!
    // 0x59614c: r0 = -()
    //     0x59614c: bl              #0x595e28  ; [dart:ui] Radius::-
    // 0x596150: add             SP, SP, #0x10
    // 0x596154: mov             x1, x0
    // 0x596158: ldr             x0, [fp, #0x18]
    // 0x59615c: stur            x1, [fp, #-8]
    // 0x596160: LoadField: r2 = r0->field_b
    //     0x596160: ldur            w2, [x0, #0xb]
    // 0x596164: DecompressPointer r2
    //     0x596164: add             x2, x2, HEAP, lsl #32
    // 0x596168: ldr             x3, [fp, #0x10]
    // 0x59616c: LoadField: r4 = r3->field_b
    //     0x59616c: ldur            w4, [x3, #0xb]
    // 0x596170: DecompressPointer r4
    //     0x596170: add             x4, x4, HEAP, lsl #32
    // 0x596174: stp             x4, x2, [SP, #-0x10]!
    // 0x596178: r0 = -()
    //     0x596178: bl              #0x595e28  ; [dart:ui] Radius::-
    // 0x59617c: add             SP, SP, #0x10
    // 0x596180: mov             x1, x0
    // 0x596184: ldr             x0, [fp, #0x18]
    // 0x596188: stur            x1, [fp, #-0x10]
    // 0x59618c: LoadField: r2 = r0->field_f
    //     0x59618c: ldur            w2, [x0, #0xf]
    // 0x596190: DecompressPointer r2
    //     0x596190: add             x2, x2, HEAP, lsl #32
    // 0x596194: ldr             x3, [fp, #0x10]
    // 0x596198: LoadField: r4 = r3->field_f
    //     0x596198: ldur            w4, [x3, #0xf]
    // 0x59619c: DecompressPointer r4
    //     0x59619c: add             x4, x4, HEAP, lsl #32
    // 0x5961a0: stp             x4, x2, [SP, #-0x10]!
    // 0x5961a4: r0 = -()
    //     0x5961a4: bl              #0x595e28  ; [dart:ui] Radius::-
    // 0x5961a8: add             SP, SP, #0x10
    // 0x5961ac: mov             x1, x0
    // 0x5961b0: ldr             x0, [fp, #0x18]
    // 0x5961b4: stur            x1, [fp, #-0x18]
    // 0x5961b8: LoadField: r2 = r0->field_13
    //     0x5961b8: ldur            w2, [x0, #0x13]
    // 0x5961bc: DecompressPointer r2
    //     0x5961bc: add             x2, x2, HEAP, lsl #32
    // 0x5961c0: ldr             x0, [fp, #0x10]
    // 0x5961c4: LoadField: r3 = r0->field_13
    //     0x5961c4: ldur            w3, [x0, #0x13]
    // 0x5961c8: DecompressPointer r3
    //     0x5961c8: add             x3, x3, HEAP, lsl #32
    // 0x5961cc: stp             x3, x2, [SP, #-0x10]!
    // 0x5961d0: r0 = -()
    //     0x5961d0: bl              #0x595e28  ; [dart:ui] Radius::-
    // 0x5961d4: add             SP, SP, #0x10
    // 0x5961d8: stur            x0, [fp, #-0x20]
    // 0x5961dc: r0 = BorderRadius()
    //     0x5961dc: bl              #0x596250  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x5961e0: ldur            x1, [fp, #-8]
    // 0x5961e4: StoreField: r0->field_7 = r1
    //     0x5961e4: stur            w1, [x0, #7]
    // 0x5961e8: ldur            x1, [fp, #-0x10]
    // 0x5961ec: StoreField: r0->field_b = r1
    //     0x5961ec: stur            w1, [x0, #0xb]
    // 0x5961f0: ldur            x1, [fp, #-0x18]
    // 0x5961f4: StoreField: r0->field_f = r1
    //     0x5961f4: stur            w1, [x0, #0xf]
    // 0x5961f8: ldur            x1, [fp, #-0x20]
    // 0x5961fc: StoreField: r0->field_13 = r1
    //     0x5961fc: stur            w1, [x0, #0x13]
    // 0x596200: LeaveFrame
    //     0x596200: mov             SP, fp
    //     0x596204: ldp             fp, lr, [SP], #0x10
    // 0x596208: ret
    //     0x596208: ret             
    // 0x59620c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x59620c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x596210: b               #0x596130
  }
  _ toRRect(/* No info */) {
    // ** addr: 0x670600, size: 0xf4
    // 0x670600: EnterFrame
    //     0x670600: stp             fp, lr, [SP, #-0x10]!
    //     0x670604: mov             fp, SP
    // 0x670608: AllocStack(0x28)
    //     0x670608: sub             SP, SP, #0x28
    // 0x67060c: CheckStackOverflow
    //     0x67060c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x670610: cmp             SP, x16
    //     0x670614: b.ls            #0x6706ec
    // 0x670618: ldr             x0, [fp, #0x18]
    // 0x67061c: LoadField: r1 = r0->field_7
    //     0x67061c: ldur            w1, [x0, #7]
    // 0x670620: DecompressPointer r1
    //     0x670620: add             x1, x1, HEAP, lsl #32
    // 0x670624: SaveReg r1
    //     0x670624: str             x1, [SP, #-8]!
    // 0x670628: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x670628: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x67062c: r0 = clamp()
    //     0x67062c: bl              #0x6708e4  ; [dart:ui] Radius::clamp
    // 0x670630: add             SP, SP, #8
    // 0x670634: mov             x1, x0
    // 0x670638: ldr             x0, [fp, #0x18]
    // 0x67063c: stur            x1, [fp, #-8]
    // 0x670640: LoadField: r2 = r0->field_b
    //     0x670640: ldur            w2, [x0, #0xb]
    // 0x670644: DecompressPointer r2
    //     0x670644: add             x2, x2, HEAP, lsl #32
    // 0x670648: SaveReg r2
    //     0x670648: str             x2, [SP, #-8]!
    // 0x67064c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x67064c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x670650: r0 = clamp()
    //     0x670650: bl              #0x6708e4  ; [dart:ui] Radius::clamp
    // 0x670654: add             SP, SP, #8
    // 0x670658: mov             x1, x0
    // 0x67065c: ldr             x0, [fp, #0x18]
    // 0x670660: stur            x1, [fp, #-0x10]
    // 0x670664: LoadField: r2 = r0->field_f
    //     0x670664: ldur            w2, [x0, #0xf]
    // 0x670668: DecompressPointer r2
    //     0x670668: add             x2, x2, HEAP, lsl #32
    // 0x67066c: SaveReg r2
    //     0x67066c: str             x2, [SP, #-8]!
    // 0x670670: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x670670: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x670674: r0 = clamp()
    //     0x670674: bl              #0x6708e4  ; [dart:ui] Radius::clamp
    // 0x670678: add             SP, SP, #8
    // 0x67067c: mov             x1, x0
    // 0x670680: ldr             x0, [fp, #0x18]
    // 0x670684: stur            x1, [fp, #-0x18]
    // 0x670688: LoadField: r2 = r0->field_13
    //     0x670688: ldur            w2, [x0, #0x13]
    // 0x67068c: DecompressPointer r2
    //     0x67068c: add             x2, x2, HEAP, lsl #32
    // 0x670690: SaveReg r2
    //     0x670690: str             x2, [SP, #-8]!
    // 0x670694: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x670694: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x670698: r0 = clamp()
    //     0x670698: bl              #0x6708e4  ; [dart:ui] Radius::clamp
    // 0x67069c: add             SP, SP, #8
    // 0x6706a0: stur            x0, [fp, #-0x20]
    // 0x6706a4: r0 = RRect()
    //     0x6706a4: bl              #0x640078  ; AllocateRRectStub -> RRect (size=0x68)
    // 0x6706a8: stur            x0, [fp, #-0x28]
    // 0x6706ac: ldr             x16, [fp, #0x10]
    // 0x6706b0: stp             x16, x0, [SP, #-0x10]!
    // 0x6706b4: ldur            x16, [fp, #-8]
    // 0x6706b8: ldur            lr, [fp, #-0x10]
    // 0x6706bc: stp             lr, x16, [SP, #-0x10]!
    // 0x6706c0: ldur            x16, [fp, #-0x18]
    // 0x6706c4: ldur            lr, [fp, #-0x20]
    // 0x6706c8: stp             lr, x16, [SP, #-0x10]!
    // 0x6706cc: r4 = const [0, 0x6, 0x6, 0x2, bottomLeft, 0x4, bottomRight, 0x5, topLeft, 0x2, topRight, 0x3, null]
    //     0x6706cc: add             x4, PP, #0x21, lsl #12  ; [pp+0x21d00] List(13) [0, 0x6, 0x6, 0x2, "bottomLeft", 0x4, "bottomRight", 0x5, "topLeft", 0x2, "topRight", 0x3, Null]
    //     0x6706d0: ldr             x4, [x4, #0xd00]
    // 0x6706d4: r0 = RRect.fromRectAndCorners()
    //     0x6706d4: bl              #0x6706f4  ; [dart:ui] RRect::RRect.fromRectAndCorners
    // 0x6706d8: add             SP, SP, #0x30
    // 0x6706dc: ldur            x0, [fp, #-0x28]
    // 0x6706e0: LeaveFrame
    //     0x6706e0: mov             SP, fp
    //     0x6706e4: ldp             fp, lr, [SP], #0x10
    // 0x6706e8: ret
    //     0x6706e8: ret             
    // 0x6706ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6706ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6706f0: b               #0x670618
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x70e1fc, size: 0x240
    // 0x70e1fc: EnterFrame
    //     0x70e1fc: stp             fp, lr, [SP, #-0x10]!
    //     0x70e200: mov             fp, SP
    // 0x70e204: AllocStack(0x20)
    //     0x70e204: sub             SP, SP, #0x20
    // 0x70e208: CheckStackOverflow
    //     0x70e208: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x70e20c: cmp             SP, x16
    //     0x70e210: b.ls            #0x70e3ec
    // 0x70e214: ldr             x0, [fp, #0x20]
    // 0x70e218: cmp             w0, NULL
    // 0x70e21c: b.ne            #0x70e23c
    // 0x70e220: ldr             x1, [fp, #0x18]
    // 0x70e224: cmp             w1, NULL
    // 0x70e228: b.ne            #0x70e240
    // 0x70e22c: r0 = Null
    //     0x70e22c: mov             x0, NULL
    // 0x70e230: LeaveFrame
    //     0x70e230: mov             SP, fp
    //     0x70e234: ldp             fp, lr, [SP], #0x10
    // 0x70e238: ret
    //     0x70e238: ret             
    // 0x70e23c: ldr             x1, [fp, #0x18]
    // 0x70e240: cmp             w0, NULL
    // 0x70e244: b.ne            #0x70e294
    // 0x70e248: ldr             d0, [fp, #0x10]
    // 0x70e24c: cmp             w1, NULL
    // 0x70e250: b.eq            #0x70e3f4
    // 0x70e254: r0 = inline_Allocate_Double()
    //     0x70e254: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x70e258: add             x0, x0, #0x10
    //     0x70e25c: cmp             x2, x0
    //     0x70e260: b.ls            #0x70e3f8
    //     0x70e264: str             x0, [THR, #0x60]  ; THR::top
    //     0x70e268: sub             x0, x0, #0xf
    //     0x70e26c: mov             x2, #0xd108
    //     0x70e270: movk            x2, #3, lsl #16
    //     0x70e274: stur            x2, [x0, #-1]
    // 0x70e278: StoreField: r0->field_7 = d0
    //     0x70e278: stur            d0, [x0, #7]
    // 0x70e27c: stp             x0, x1, [SP, #-0x10]!
    // 0x70e280: r0 = *()
    //     0x70e280: bl              #0xcfb5f0  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::*
    // 0x70e284: add             SP, SP, #0x10
    // 0x70e288: LeaveFrame
    //     0x70e288: mov             SP, fp
    //     0x70e28c: ldp             fp, lr, [SP], #0x10
    // 0x70e290: ret
    //     0x70e290: ret             
    // 0x70e294: ldr             d0, [fp, #0x10]
    // 0x70e298: cmp             w1, NULL
    // 0x70e29c: b.ne            #0x70e2e8
    // 0x70e2a0: d1 = 1.000000
    //     0x70e2a0: fmov            d1, #1.00000000
    // 0x70e2a4: fsub            d2, d1, d0
    // 0x70e2a8: r1 = inline_Allocate_Double()
    //     0x70e2a8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x70e2ac: add             x1, x1, #0x10
    //     0x70e2b0: cmp             x2, x1
    //     0x70e2b4: b.ls            #0x70e410
    //     0x70e2b8: str             x1, [THR, #0x60]  ; THR::top
    //     0x70e2bc: sub             x1, x1, #0xf
    //     0x70e2c0: mov             x2, #0xd108
    //     0x70e2c4: movk            x2, #3, lsl #16
    //     0x70e2c8: stur            x2, [x1, #-1]
    // 0x70e2cc: StoreField: r1->field_7 = d2
    //     0x70e2cc: stur            d2, [x1, #7]
    // 0x70e2d0: stp             x1, x0, [SP, #-0x10]!
    // 0x70e2d4: r0 = *()
    //     0x70e2d4: bl              #0xcfb5f0  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::*
    // 0x70e2d8: add             SP, SP, #0x10
    // 0x70e2dc: LeaveFrame
    //     0x70e2dc: mov             SP, fp
    //     0x70e2e0: ldp             fp, lr, [SP], #0x10
    // 0x70e2e4: ret
    //     0x70e2e4: ret             
    // 0x70e2e8: LoadField: r2 = r0->field_7
    //     0x70e2e8: ldur            w2, [x0, #7]
    // 0x70e2ec: DecompressPointer r2
    //     0x70e2ec: add             x2, x2, HEAP, lsl #32
    // 0x70e2f0: LoadField: r3 = r1->field_7
    //     0x70e2f0: ldur            w3, [x1, #7]
    // 0x70e2f4: DecompressPointer r3
    //     0x70e2f4: add             x3, x3, HEAP, lsl #32
    // 0x70e2f8: stp             x3, x2, [SP, #-0x10]!
    // 0x70e2fc: SaveReg d0
    //     0x70e2fc: str             d0, [SP, #-8]!
    // 0x70e300: r0 = lerp()
    //     0x70e300: bl              #0x70e43c  ; [dart:ui] Radius::lerp
    // 0x70e304: add             SP, SP, #0x18
    // 0x70e308: stur            x0, [fp, #-8]
    // 0x70e30c: cmp             w0, NULL
    // 0x70e310: b.eq            #0x70e42c
    // 0x70e314: ldr             x1, [fp, #0x20]
    // 0x70e318: LoadField: r2 = r1->field_b
    //     0x70e318: ldur            w2, [x1, #0xb]
    // 0x70e31c: DecompressPointer r2
    //     0x70e31c: add             x2, x2, HEAP, lsl #32
    // 0x70e320: ldr             x3, [fp, #0x18]
    // 0x70e324: LoadField: r4 = r3->field_b
    //     0x70e324: ldur            w4, [x3, #0xb]
    // 0x70e328: DecompressPointer r4
    //     0x70e328: add             x4, x4, HEAP, lsl #32
    // 0x70e32c: stp             x4, x2, [SP, #-0x10]!
    // 0x70e330: ldr             d0, [fp, #0x10]
    // 0x70e334: SaveReg d0
    //     0x70e334: str             d0, [SP, #-8]!
    // 0x70e338: r0 = lerp()
    //     0x70e338: bl              #0x70e43c  ; [dart:ui] Radius::lerp
    // 0x70e33c: add             SP, SP, #0x18
    // 0x70e340: stur            x0, [fp, #-0x10]
    // 0x70e344: cmp             w0, NULL
    // 0x70e348: b.eq            #0x70e430
    // 0x70e34c: ldr             x1, [fp, #0x20]
    // 0x70e350: LoadField: r2 = r1->field_f
    //     0x70e350: ldur            w2, [x1, #0xf]
    // 0x70e354: DecompressPointer r2
    //     0x70e354: add             x2, x2, HEAP, lsl #32
    // 0x70e358: ldr             x3, [fp, #0x18]
    // 0x70e35c: LoadField: r4 = r3->field_f
    //     0x70e35c: ldur            w4, [x3, #0xf]
    // 0x70e360: DecompressPointer r4
    //     0x70e360: add             x4, x4, HEAP, lsl #32
    // 0x70e364: stp             x4, x2, [SP, #-0x10]!
    // 0x70e368: ldr             d0, [fp, #0x10]
    // 0x70e36c: SaveReg d0
    //     0x70e36c: str             d0, [SP, #-8]!
    // 0x70e370: r0 = lerp()
    //     0x70e370: bl              #0x70e43c  ; [dart:ui] Radius::lerp
    // 0x70e374: add             SP, SP, #0x18
    // 0x70e378: stur            x0, [fp, #-0x18]
    // 0x70e37c: cmp             w0, NULL
    // 0x70e380: b.eq            #0x70e434
    // 0x70e384: ldr             x1, [fp, #0x20]
    // 0x70e388: LoadField: r2 = r1->field_13
    //     0x70e388: ldur            w2, [x1, #0x13]
    // 0x70e38c: DecompressPointer r2
    //     0x70e38c: add             x2, x2, HEAP, lsl #32
    // 0x70e390: ldr             x1, [fp, #0x18]
    // 0x70e394: LoadField: r3 = r1->field_13
    //     0x70e394: ldur            w3, [x1, #0x13]
    // 0x70e398: DecompressPointer r3
    //     0x70e398: add             x3, x3, HEAP, lsl #32
    // 0x70e39c: stp             x3, x2, [SP, #-0x10]!
    // 0x70e3a0: ldr             d0, [fp, #0x10]
    // 0x70e3a4: SaveReg d0
    //     0x70e3a4: str             d0, [SP, #-8]!
    // 0x70e3a8: r0 = lerp()
    //     0x70e3a8: bl              #0x70e43c  ; [dart:ui] Radius::lerp
    // 0x70e3ac: add             SP, SP, #0x18
    // 0x70e3b0: stur            x0, [fp, #-0x20]
    // 0x70e3b4: cmp             w0, NULL
    // 0x70e3b8: b.eq            #0x70e438
    // 0x70e3bc: r0 = BorderRadius()
    //     0x70e3bc: bl              #0x596250  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x70e3c0: ldur            x1, [fp, #-8]
    // 0x70e3c4: StoreField: r0->field_7 = r1
    //     0x70e3c4: stur            w1, [x0, #7]
    // 0x70e3c8: ldur            x1, [fp, #-0x10]
    // 0x70e3cc: StoreField: r0->field_b = r1
    //     0x70e3cc: stur            w1, [x0, #0xb]
    // 0x70e3d0: ldur            x1, [fp, #-0x18]
    // 0x70e3d4: StoreField: r0->field_f = r1
    //     0x70e3d4: stur            w1, [x0, #0xf]
    // 0x70e3d8: ldur            x1, [fp, #-0x20]
    // 0x70e3dc: StoreField: r0->field_13 = r1
    //     0x70e3dc: stur            w1, [x0, #0x13]
    // 0x70e3e0: LeaveFrame
    //     0x70e3e0: mov             SP, fp
    //     0x70e3e4: ldp             fp, lr, [SP], #0x10
    // 0x70e3e8: ret
    //     0x70e3e8: ret             
    // 0x70e3ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x70e3ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x70e3f0: b               #0x70e214
    // 0x70e3f4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x70e3f4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x70e3f8: SaveReg d0
    //     0x70e3f8: str             q0, [SP, #-0x10]!
    // 0x70e3fc: SaveReg r1
    //     0x70e3fc: str             x1, [SP, #-8]!
    // 0x70e400: r0 = AllocateDouble()
    //     0x70e400: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x70e404: RestoreReg r1
    //     0x70e404: ldr             x1, [SP], #8
    // 0x70e408: RestoreReg d0
    //     0x70e408: ldr             q0, [SP], #0x10
    // 0x70e40c: b               #0x70e278
    // 0x70e410: SaveReg d2
    //     0x70e410: str             q2, [SP, #-0x10]!
    // 0x70e414: SaveReg r0
    //     0x70e414: str             x0, [SP, #-8]!
    // 0x70e418: r0 = AllocateDouble()
    //     0x70e418: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x70e41c: mov             x1, x0
    // 0x70e420: RestoreReg r0
    //     0x70e420: ldr             x0, [SP], #8
    // 0x70e424: RestoreReg d2
    //     0x70e424: ldr             q2, [SP], #0x10
    // 0x70e428: b               #0x70e2cc
    // 0x70e42c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x70e42c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x70e430: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x70e430: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x70e434: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x70e434: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x70e438: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x70e438: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ add(/* No info */) {
    // ** addr: 0xcf8f0c, size: 0x70
    // 0xcf8f0c: EnterFrame
    //     0xcf8f0c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8f10: mov             fp, SP
    // 0xcf8f14: CheckStackOverflow
    //     0xcf8f14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf8f18: cmp             SP, x16
    //     0xcf8f1c: b.ls            #0xcf8f74
    // 0xcf8f20: ldr             x0, [fp, #0x10]
    // 0xcf8f24: r1 = LoadClassIdInstr(r0)
    //     0xcf8f24: ldur            x1, [x0, #-1]
    //     0xcf8f28: ubfx            x1, x1, #0xc, #0x14
    // 0xcf8f2c: lsl             x1, x1, #1
    // 0xcf8f30: r17 = 4224
    //     0xcf8f30: mov             x17, #0x1080
    // 0xcf8f34: cmp             w1, w17
    // 0xcf8f38: b.ne            #0xcf8f58
    // 0xcf8f3c: ldr             x16, [fp, #0x18]
    // 0xcf8f40: stp             x0, x16, [SP, #-0x10]!
    // 0xcf8f44: r0 = +()
    //     0xcf8f44: bl              #0x595f90  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::+
    // 0xcf8f48: add             SP, SP, #0x10
    // 0xcf8f4c: LeaveFrame
    //     0xcf8f4c: mov             SP, fp
    //     0xcf8f50: ldp             fp, lr, [SP], #0x10
    // 0xcf8f54: ret
    //     0xcf8f54: ret             
    // 0xcf8f58: ldr             x16, [fp, #0x18]
    // 0xcf8f5c: stp             x0, x16, [SP, #-0x10]!
    // 0xcf8f60: r0 = add()
    //     0xcf8f60: bl              #0xcf8f7c  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::add
    // 0xcf8f64: add             SP, SP, #0x10
    // 0xcf8f68: LeaveFrame
    //     0xcf8f68: mov             SP, fp
    //     0xcf8f6c: ldp             fp, lr, [SP], #0x10
    // 0xcf8f70: ret
    //     0xcf8f70: ret             
    // 0xcf8f74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf8f74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8f78: b               #0xcf8f20
  }
  _ subtract(/* No info */) {
    // ** addr: 0xcf9d5c, size: 0x70
    // 0xcf9d5c: EnterFrame
    //     0xcf9d5c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf9d60: mov             fp, SP
    // 0xcf9d64: CheckStackOverflow
    //     0xcf9d64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf9d68: cmp             SP, x16
    //     0xcf9d6c: b.ls            #0xcf9dc4
    // 0xcf9d70: ldr             x0, [fp, #0x10]
    // 0xcf9d74: r1 = LoadClassIdInstr(r0)
    //     0xcf9d74: ldur            x1, [x0, #-1]
    //     0xcf9d78: ubfx            x1, x1, #0xc, #0x14
    // 0xcf9d7c: lsl             x1, x1, #1
    // 0xcf9d80: r17 = 4224
    //     0xcf9d80: mov             x17, #0x1080
    // 0xcf9d84: cmp             w1, w17
    // 0xcf9d88: b.ne            #0xcf9da8
    // 0xcf9d8c: ldr             x16, [fp, #0x18]
    // 0xcf9d90: stp             x0, x16, [SP, #-0x10]!
    // 0xcf9d94: r0 = -()
    //     0xcf9d94: bl              #0x596118  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::-
    // 0xcf9d98: add             SP, SP, #0x10
    // 0xcf9d9c: LeaveFrame
    //     0xcf9d9c: mov             SP, fp
    //     0xcf9da0: ldp             fp, lr, [SP], #0x10
    // 0xcf9da4: ret
    //     0xcf9da4: ret             
    // 0xcf9da8: ldr             x16, [fp, #0x18]
    // 0xcf9dac: stp             x0, x16, [SP, #-0x10]!
    // 0xcf9db0: r0 = subtract()
    //     0xcf9db0: bl              #0xcf9dcc  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::subtract
    // 0xcf9db4: add             SP, SP, #0x10
    // 0xcf9db8: LeaveFrame
    //     0xcf9db8: mov             SP, fp
    //     0xcf9dbc: ldp             fp, lr, [SP], #0x10
    // 0xcf9dc0: ret
    //     0xcf9dc0: ret             
    // 0xcf9dc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf9dc4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf9dc8: b               #0xcf9d70
  }
  BorderRadius *(BorderRadius, double) {
    // ** addr: 0xcfb5f0, size: 0xdc
    // 0xcfb5f0: EnterFrame
    //     0xcfb5f0: stp             fp, lr, [SP, #-0x10]!
    //     0xcfb5f4: mov             fp, SP
    // 0xcfb5f8: AllocStack(0x20)
    //     0xcfb5f8: sub             SP, SP, #0x20
    // 0xcfb5fc: CheckStackOverflow
    //     0xcfb5fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcfb600: cmp             SP, x16
    //     0xcfb604: b.ls            #0xcfb6c4
    // 0xcfb608: ldr             x0, [fp, #0x18]
    // 0xcfb60c: LoadField: r1 = r0->field_7
    //     0xcfb60c: ldur            w1, [x0, #7]
    // 0xcfb610: DecompressPointer r1
    //     0xcfb610: add             x1, x1, HEAP, lsl #32
    // 0xcfb614: ldr             x16, [fp, #0x10]
    // 0xcfb618: stp             x16, x1, [SP, #-0x10]!
    // 0xcfb61c: r0 = *()
    //     0xcfb61c: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcfb620: add             SP, SP, #0x10
    // 0xcfb624: mov             x1, x0
    // 0xcfb628: ldr             x0, [fp, #0x18]
    // 0xcfb62c: stur            x1, [fp, #-8]
    // 0xcfb630: LoadField: r2 = r0->field_b
    //     0xcfb630: ldur            w2, [x0, #0xb]
    // 0xcfb634: DecompressPointer r2
    //     0xcfb634: add             x2, x2, HEAP, lsl #32
    // 0xcfb638: ldr             x16, [fp, #0x10]
    // 0xcfb63c: stp             x16, x2, [SP, #-0x10]!
    // 0xcfb640: r0 = *()
    //     0xcfb640: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcfb644: add             SP, SP, #0x10
    // 0xcfb648: mov             x1, x0
    // 0xcfb64c: ldr             x0, [fp, #0x18]
    // 0xcfb650: stur            x1, [fp, #-0x10]
    // 0xcfb654: LoadField: r2 = r0->field_f
    //     0xcfb654: ldur            w2, [x0, #0xf]
    // 0xcfb658: DecompressPointer r2
    //     0xcfb658: add             x2, x2, HEAP, lsl #32
    // 0xcfb65c: ldr             x16, [fp, #0x10]
    // 0xcfb660: stp             x16, x2, [SP, #-0x10]!
    // 0xcfb664: r0 = *()
    //     0xcfb664: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcfb668: add             SP, SP, #0x10
    // 0xcfb66c: mov             x1, x0
    // 0xcfb670: ldr             x0, [fp, #0x18]
    // 0xcfb674: stur            x1, [fp, #-0x18]
    // 0xcfb678: LoadField: r2 = r0->field_13
    //     0xcfb678: ldur            w2, [x0, #0x13]
    // 0xcfb67c: DecompressPointer r2
    //     0xcfb67c: add             x2, x2, HEAP, lsl #32
    // 0xcfb680: ldr             x16, [fp, #0x10]
    // 0xcfb684: stp             x16, x2, [SP, #-0x10]!
    // 0xcfb688: r0 = *()
    //     0xcfb688: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcfb68c: add             SP, SP, #0x10
    // 0xcfb690: stur            x0, [fp, #-0x20]
    // 0xcfb694: r0 = BorderRadius()
    //     0xcfb694: bl              #0x596250  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xcfb698: ldur            x1, [fp, #-8]
    // 0xcfb69c: StoreField: r0->field_7 = r1
    //     0xcfb69c: stur            w1, [x0, #7]
    // 0xcfb6a0: ldur            x1, [fp, #-0x10]
    // 0xcfb6a4: StoreField: r0->field_b = r1
    //     0xcfb6a4: stur            w1, [x0, #0xb]
    // 0xcfb6a8: ldur            x1, [fp, #-0x18]
    // 0xcfb6ac: StoreField: r0->field_f = r1
    //     0xcfb6ac: stur            w1, [x0, #0xf]
    // 0xcfb6b0: ldur            x1, [fp, #-0x20]
    // 0xcfb6b4: StoreField: r0->field_13 = r1
    //     0xcfb6b4: stur            w1, [x0, #0x13]
    // 0xcfb6b8: LeaveFrame
    //     0xcfb6b8: mov             SP, fp
    //     0xcfb6bc: ldp             fp, lr, [SP], #0x10
    // 0xcfb6c0: ret
    //     0xcfb6c0: ret             
    // 0xcfb6c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfb6c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfb6c8: b               #0xcfb608
  }
  _ resolve(/* No info */) {
    // ** addr: 0xcfbda4, size: 0x8
    // 0xcfbda4: ldr             x0, [SP, #8]
    // 0xcfbda8: ret
    //     0xcfbda8: ret             
  }
}

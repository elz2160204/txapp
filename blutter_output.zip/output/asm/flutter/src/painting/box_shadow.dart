// lib: , url: package:flutter/src/painting/box_shadow.dart

// class id: 1049353, size: 0x8
class :: {
}

// class id: 5045, size: 0x24, field offset: 0x18
//   const constructor, 
class BoxShadow extends Shadow {

  Color field_8;
  Offset field_c;
  _Double field_10;
  _Double field_18;
  BlurStyle field_20;

  _ toPaint(/* No info */) {
    // ** addr: 0x65f6d0, size: 0xc4
    // 0x65f6d0: EnterFrame
    //     0x65f6d0: stp             fp, lr, [SP, #-0x10]!
    //     0x65f6d4: mov             fp, SP
    // 0x65f6d8: AllocStack(0x8)
    //     0x65f6d8: sub             SP, SP, #8
    // 0x65f6dc: CheckStackOverflow
    //     0x65f6dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65f6e0: cmp             SP, x16
    //     0x65f6e4: b.ls            #0x65f78c
    // 0x65f6e8: r16 = 112
    //     0x65f6e8: mov             x16, #0x70
    // 0x65f6ec: stp             x16, NULL, [SP, #-0x10]!
    // 0x65f6f0: r0 = ByteData()
    //     0x65f6f0: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x65f6f4: add             SP, SP, #0x10
    // 0x65f6f8: stur            x0, [fp, #-8]
    // 0x65f6fc: r0 = Paint()
    //     0x65f6fc: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x65f700: ldur            x1, [fp, #-8]
    // 0x65f704: StoreField: r0->field_7 = r1
    //     0x65f704: stur            w1, [x0, #7]
    // 0x65f708: ldr             x2, [fp, #0x10]
    // 0x65f70c: LoadField: r3 = r2->field_7
    //     0x65f70c: ldur            w3, [x2, #7]
    // 0x65f710: DecompressPointer r3
    //     0x65f710: add             x3, x3, HEAP, lsl #32
    // 0x65f714: LoadField: r4 = r3->field_7
    //     0x65f714: ldur            x4, [x3, #7]
    // 0x65f718: eor             x3, x4, #0xff000000
    // 0x65f71c: LoadField: r4 = r1->field_17
    //     0x65f71c: ldur            w4, [x1, #0x17]
    // 0x65f720: DecompressPointer r4
    //     0x65f720: add             x4, x4, HEAP, lsl #32
    // 0x65f724: sxtw            x3, w3
    // 0x65f728: LoadField: r1 = r4->field_7
    //     0x65f728: ldur            x1, [x4, #7]
    // 0x65f72c: str             w3, [x1, #4]
    // 0x65f730: LoadField: d0 = r2->field_f
    //     0x65f730: ldur            d0, [x2, #0xf]
    // 0x65f734: d1 = 0.000000
    //     0x65f734: eor             v1.16b, v1.16b, v1.16b
    // 0x65f738: fcmp            d0, d1
    // 0x65f73c: b.vs            #0x65f75c
    // 0x65f740: b.le            #0x65f75c
    // 0x65f744: d2 = 0.577350
    //     0x65f744: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1f4f0] IMM: double(0.57735) from 0x3fe279a6b50b0f28
    //     0x65f748: ldr             d2, [x17, #0x4f0]
    // 0x65f74c: d1 = 0.500000
    //     0x65f74c: fmov            d1, #0.50000000
    // 0x65f750: fmul            d3, d0, d2
    // 0x65f754: fadd            d0, d3, d1
    // 0x65f758: b               #0x65f760
    // 0x65f75c: d0 = 0.000000
    //     0x65f75c: eor             v0.16b, v0.16b, v0.16b
    // 0x65f760: r1 = 1
    //     0x65f760: mov             x1, #1
    // 0x65f764: LoadField: r2 = r4->field_7
    //     0x65f764: ldur            x2, [x4, #7]
    // 0x65f768: str             w1, [x2, #0x24]
    // 0x65f76c: LoadField: r1 = r4->field_7
    //     0x65f76c: ldur            x1, [x4, #7]
    // 0x65f770: str             wzr, [x1, #0x28]
    // 0x65f774: fcvt            s1, d0
    // 0x65f778: LoadField: r1 = r4->field_7
    //     0x65f778: ldur            x1, [x4, #7]
    // 0x65f77c: str             s1, [x1, #0x2c]
    // 0x65f780: LeaveFrame
    //     0x65f780: mov             SP, fp
    //     0x65f784: ldp             fp, lr, [SP], #0x10
    // 0x65f788: ret
    //     0x65f788: ret             
    // 0x65f78c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65f78c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65f790: b               #0x65f6e8
  }
  _ toString(/* No info */) {
    // ** addr: 0xac0378, size: 0x1d4
    // 0xac0378: EnterFrame
    //     0xac0378: stp             fp, lr, [SP, #-0x10]!
    //     0xac037c: mov             fp, SP
    // 0xac0380: AllocStack(0x8)
    //     0xac0380: sub             SP, SP, #8
    // 0xac0384: CheckStackOverflow
    //     0xac0384: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xac0388: cmp             SP, x16
    //     0xac038c: b.ls            #0xac050c
    // 0xac0390: r1 = Null
    //     0xac0390: mov             x1, NULL
    // 0xac0394: r2 = 22
    //     0xac0394: mov             x2, #0x16
    // 0xac0398: r0 = AllocateArray()
    //     0xac0398: bl              #0xd6987c  ; AllocateArrayStub
    // 0xac039c: stur            x0, [fp, #-8]
    // 0xac03a0: r17 = "BoxShadow("
    //     0xac03a0: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fe48] "BoxShadow("
    //     0xac03a4: ldr             x17, [x17, #0xe48]
    // 0xac03a8: StoreField: r0->field_f = r17
    //     0xac03a8: stur            w17, [x0, #0xf]
    // 0xac03ac: ldr             x1, [fp, #0x10]
    // 0xac03b0: LoadField: r2 = r1->field_7
    //     0xac03b0: ldur            w2, [x1, #7]
    // 0xac03b4: DecompressPointer r2
    //     0xac03b4: add             x2, x2, HEAP, lsl #32
    // 0xac03b8: StoreField: r0->field_13 = r2
    //     0xac03b8: stur            w2, [x0, #0x13]
    // 0xac03bc: r17 = ", "
    //     0xac03bc: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xac03c0: StoreField: r0->field_17 = r17
    //     0xac03c0: stur            w17, [x0, #0x17]
    // 0xac03c4: LoadField: r2 = r1->field_b
    //     0xac03c4: ldur            w2, [x1, #0xb]
    // 0xac03c8: DecompressPointer r2
    //     0xac03c8: add             x2, x2, HEAP, lsl #32
    // 0xac03cc: StoreField: r0->field_1b = r2
    //     0xac03cc: stur            w2, [x0, #0x1b]
    // 0xac03d0: r17 = ", "
    //     0xac03d0: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xac03d4: StoreField: r0->field_1f = r17
    //     0xac03d4: stur            w17, [x0, #0x1f]
    // 0xac03d8: LoadField: d0 = r1->field_f
    //     0xac03d8: ldur            d0, [x1, #0xf]
    // 0xac03dc: r2 = inline_Allocate_Double()
    //     0xac03dc: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xac03e0: add             x2, x2, #0x10
    //     0xac03e4: cmp             x3, x2
    //     0xac03e8: b.ls            #0xac0514
    //     0xac03ec: str             x2, [THR, #0x60]  ; THR::top
    //     0xac03f0: sub             x2, x2, #0xf
    //     0xac03f4: mov             x3, #0xd108
    //     0xac03f8: movk            x3, #3, lsl #16
    //     0xac03fc: stur            x3, [x2, #-1]
    // 0xac0400: StoreField: r2->field_7 = d0
    //     0xac0400: stur            d0, [x2, #7]
    // 0xac0404: SaveReg r2
    //     0xac0404: str             x2, [SP, #-8]!
    // 0xac0408: r0 = debugFormatDouble()
    //     0xac0408: bl              #0xa77fb4  ; [package:flutter/src/foundation/debug.dart] ::debugFormatDouble
    // 0xac040c: add             SP, SP, #8
    // 0xac0410: ldur            x1, [fp, #-8]
    // 0xac0414: ArrayStore: r1[5] = r0  ; List_4
    //     0xac0414: add             x25, x1, #0x23
    //     0xac0418: str             w0, [x25]
    //     0xac041c: tbz             w0, #0, #0xac0438
    //     0xac0420: ldurb           w16, [x1, #-1]
    //     0xac0424: ldurb           w17, [x0, #-1]
    //     0xac0428: and             x16, x17, x16, lsr #2
    //     0xac042c: tst             x16, HEAP, lsr #32
    //     0xac0430: b.eq            #0xac0438
    //     0xac0434: bl              #0xd67e5c
    // 0xac0438: ldur            x1, [fp, #-8]
    // 0xac043c: r17 = ", "
    //     0xac043c: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xac0440: StoreField: r1->field_27 = r17
    //     0xac0440: stur            w17, [x1, #0x27]
    // 0xac0444: ldr             x0, [fp, #0x10]
    // 0xac0448: LoadField: d0 = r0->field_17
    //     0xac0448: ldur            d0, [x0, #0x17]
    // 0xac044c: r2 = inline_Allocate_Double()
    //     0xac044c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xac0450: add             x2, x2, #0x10
    //     0xac0454: cmp             x3, x2
    //     0xac0458: b.ls            #0xac0530
    //     0xac045c: str             x2, [THR, #0x60]  ; THR::top
    //     0xac0460: sub             x2, x2, #0xf
    //     0xac0464: mov             x3, #0xd108
    //     0xac0468: movk            x3, #3, lsl #16
    //     0xac046c: stur            x3, [x2, #-1]
    // 0xac0470: StoreField: r2->field_7 = d0
    //     0xac0470: stur            d0, [x2, #7]
    // 0xac0474: SaveReg r2
    //     0xac0474: str             x2, [SP, #-8]!
    // 0xac0478: r0 = debugFormatDouble()
    //     0xac0478: bl              #0xa77fb4  ; [package:flutter/src/foundation/debug.dart] ::debugFormatDouble
    // 0xac047c: add             SP, SP, #8
    // 0xac0480: ldur            x1, [fp, #-8]
    // 0xac0484: ArrayStore: r1[7] = r0  ; List_4
    //     0xac0484: add             x25, x1, #0x2b
    //     0xac0488: str             w0, [x25]
    //     0xac048c: tbz             w0, #0, #0xac04a8
    //     0xac0490: ldurb           w16, [x1, #-1]
    //     0xac0494: ldurb           w17, [x0, #-1]
    //     0xac0498: and             x16, x17, x16, lsr #2
    //     0xac049c: tst             x16, HEAP, lsr #32
    //     0xac04a0: b.eq            #0xac04a8
    //     0xac04a4: bl              #0xd67e5c
    // 0xac04a8: ldur            x2, [fp, #-8]
    // 0xac04ac: r17 = ", "
    //     0xac04ac: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xac04b0: StoreField: r2->field_2f = r17
    //     0xac04b0: stur            w17, [x2, #0x2f]
    // 0xac04b4: ldr             x0, [fp, #0x10]
    // 0xac04b8: LoadField: r1 = r0->field_1f
    //     0xac04b8: ldur            w1, [x0, #0x1f]
    // 0xac04bc: DecompressPointer r1
    //     0xac04bc: add             x1, x1, HEAP, lsl #32
    // 0xac04c0: mov             x0, x1
    // 0xac04c4: mov             x1, x2
    // 0xac04c8: ArrayStore: r1[9] = r0  ; List_4
    //     0xac04c8: add             x25, x1, #0x33
    //     0xac04cc: str             w0, [x25]
    //     0xac04d0: tbz             w0, #0, #0xac04ec
    //     0xac04d4: ldurb           w16, [x1, #-1]
    //     0xac04d8: ldurb           w17, [x0, #-1]
    //     0xac04dc: and             x16, x17, x16, lsr #2
    //     0xac04e0: tst             x16, HEAP, lsr #32
    //     0xac04e4: b.eq            #0xac04ec
    //     0xac04e8: bl              #0xd67e5c
    // 0xac04ec: r17 = ")"
    //     0xac04ec: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xac04f0: StoreField: r2->field_37 = r17
    //     0xac04f0: stur            w17, [x2, #0x37]
    // 0xac04f4: SaveReg r2
    //     0xac04f4: str             x2, [SP, #-8]!
    // 0xac04f8: r0 = _interpolate()
    //     0xac04f8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xac04fc: add             SP, SP, #8
    // 0xac0500: LeaveFrame
    //     0xac0500: mov             SP, fp
    //     0xac0504: ldp             fp, lr, [SP], #0x10
    // 0xac0508: ret
    //     0xac0508: ret             
    // 0xac050c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xac050c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xac0510: b               #0xac0390
    // 0xac0514: SaveReg d0
    //     0xac0514: str             q0, [SP, #-0x10]!
    // 0xac0518: stp             x0, x1, [SP, #-0x10]!
    // 0xac051c: r0 = AllocateDouble()
    //     0xac051c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xac0520: mov             x2, x0
    // 0xac0524: ldp             x0, x1, [SP], #0x10
    // 0xac0528: RestoreReg d0
    //     0xac0528: ldr             q0, [SP], #0x10
    // 0xac052c: b               #0xac0400
    // 0xac0530: SaveReg d0
    //     0xac0530: str             q0, [SP, #-0x10]!
    // 0xac0534: stp             x0, x1, [SP, #-0x10]!
    // 0xac0538: r0 = AllocateDouble()
    //     0xac0538: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xac053c: mov             x2, x0
    // 0xac0540: ldp             x0, x1, [SP], #0x10
    // 0xac0544: RestoreReg d0
    //     0xac0544: ldr             q0, [SP], #0x10
    // 0xac0548: b               #0xac0470
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xaf8ee0, size: 0x108
    // 0xaf8ee0: EnterFrame
    //     0xaf8ee0: stp             fp, lr, [SP, #-0x10]!
    //     0xaf8ee4: mov             fp, SP
    // 0xaf8ee8: CheckStackOverflow
    //     0xaf8ee8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaf8eec: cmp             SP, x16
    //     0xaf8ef0: b.ls            #0xaf8fa4
    // 0xaf8ef4: ldr             x0, [fp, #0x10]
    // 0xaf8ef8: LoadField: r1 = r0->field_7
    //     0xaf8ef8: ldur            w1, [x0, #7]
    // 0xaf8efc: DecompressPointer r1
    //     0xaf8efc: add             x1, x1, HEAP, lsl #32
    // 0xaf8f00: LoadField: r2 = r0->field_b
    //     0xaf8f00: ldur            w2, [x0, #0xb]
    // 0xaf8f04: DecompressPointer r2
    //     0xaf8f04: add             x2, x2, HEAP, lsl #32
    // 0xaf8f08: LoadField: d0 = r0->field_f
    //     0xaf8f08: ldur            d0, [x0, #0xf]
    // 0xaf8f0c: LoadField: d1 = r0->field_17
    //     0xaf8f0c: ldur            d1, [x0, #0x17]
    // 0xaf8f10: r0 = inline_Allocate_Double()
    //     0xaf8f10: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xaf8f14: add             x0, x0, #0x10
    //     0xaf8f18: cmp             x3, x0
    //     0xaf8f1c: b.ls            #0xaf8fac
    //     0xaf8f20: str             x0, [THR, #0x60]  ; THR::top
    //     0xaf8f24: sub             x0, x0, #0xf
    //     0xaf8f28: mov             x3, #0xd108
    //     0xaf8f2c: movk            x3, #3, lsl #16
    //     0xaf8f30: stur            x3, [x0, #-1]
    // 0xaf8f34: StoreField: r0->field_7 = d0
    //     0xaf8f34: stur            d0, [x0, #7]
    // 0xaf8f38: r3 = inline_Allocate_Double()
    //     0xaf8f38: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xaf8f3c: add             x3, x3, #0x10
    //     0xaf8f40: cmp             x4, x3
    //     0xaf8f44: b.ls            #0xaf8fc4
    //     0xaf8f48: str             x3, [THR, #0x60]  ; THR::top
    //     0xaf8f4c: sub             x3, x3, #0xf
    //     0xaf8f50: mov             x4, #0xd108
    //     0xaf8f54: movk            x4, #3, lsl #16
    //     0xaf8f58: stur            x4, [x3, #-1]
    // 0xaf8f5c: StoreField: r3->field_7 = d1
    //     0xaf8f5c: stur            d1, [x3, #7]
    // 0xaf8f60: stp             x2, x1, [SP, #-0x10]!
    // 0xaf8f64: stp             x3, x0, [SP, #-0x10]!
    // 0xaf8f68: r16 = Instance_BlurStyle
    //     0xaf8f68: add             x16, PP, #0x33, lsl #12  ; [pp+0x33660] Obj!BlurStyle@b675d1
    //     0xaf8f6c: ldr             x16, [x16, #0x660]
    // 0xaf8f70: SaveReg r16
    //     0xaf8f70: str             x16, [SP, #-8]!
    // 0xaf8f74: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xaf8f74: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xaf8f78: r0 = hash()
    //     0xaf8f78: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xaf8f7c: add             SP, SP, #0x28
    // 0xaf8f80: mov             x2, x0
    // 0xaf8f84: r0 = BoxInt64Instr(r2)
    //     0xaf8f84: sbfiz           x0, x2, #1, #0x1f
    //     0xaf8f88: cmp             x2, x0, asr #1
    //     0xaf8f8c: b.eq            #0xaf8f98
    //     0xaf8f90: bl              #0xd69bb8
    //     0xaf8f94: stur            x2, [x0, #7]
    // 0xaf8f98: LeaveFrame
    //     0xaf8f98: mov             SP, fp
    //     0xaf8f9c: ldp             fp, lr, [SP], #0x10
    // 0xaf8fa0: ret
    //     0xaf8fa0: ret             
    // 0xaf8fa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf8fa4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf8fa8: b               #0xaf8ef4
    // 0xaf8fac: stp             q0, q1, [SP, #-0x20]!
    // 0xaf8fb0: stp             x1, x2, [SP, #-0x10]!
    // 0xaf8fb4: r0 = AllocateDouble()
    //     0xaf8fb4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xaf8fb8: ldp             x1, x2, [SP], #0x10
    // 0xaf8fbc: ldp             q0, q1, [SP], #0x20
    // 0xaf8fc0: b               #0xaf8f34
    // 0xaf8fc4: SaveReg d1
    //     0xaf8fc4: str             q1, [SP, #-0x10]!
    // 0xaf8fc8: stp             x1, x2, [SP, #-0x10]!
    // 0xaf8fcc: SaveReg r0
    //     0xaf8fcc: str             x0, [SP, #-8]!
    // 0xaf8fd0: r0 = AllocateDouble()
    //     0xaf8fd0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xaf8fd4: mov             x3, x0
    // 0xaf8fd8: RestoreReg r0
    //     0xaf8fd8: ldr             x0, [SP], #8
    // 0xaf8fdc: ldp             x1, x2, [SP], #0x10
    // 0xaf8fe0: RestoreReg d1
    //     0xaf8fe0: ldr             q1, [SP], #0x10
    // 0xaf8fe4: b               #0xaf8f5c
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6725c, size: 0x1ac
    // 0xc6725c: EnterFrame
    //     0xc6725c: stp             fp, lr, [SP, #-0x10]!
    //     0xc67260: mov             fp, SP
    // 0xc67264: AllocStack(0x10)
    //     0xc67264: sub             SP, SP, #0x10
    // 0xc67268: CheckStackOverflow
    //     0xc67268: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6726c: cmp             SP, x16
    //     0xc67270: b.ls            #0xc67400
    // 0xc67274: ldr             x1, [fp, #0x10]
    // 0xc67278: cmp             w1, NULL
    // 0xc6727c: b.ne            #0xc67290
    // 0xc67280: r0 = false
    //     0xc67280: add             x0, NULL, #0x30  ; false
    // 0xc67284: LeaveFrame
    //     0xc67284: mov             SP, fp
    //     0xc67288: ldp             fp, lr, [SP], #0x10
    // 0xc6728c: ret
    //     0xc6728c: ret             
    // 0xc67290: ldr             x2, [fp, #0x18]
    // 0xc67294: cmp             w2, w1
    // 0xc67298: b.ne            #0xc672ac
    // 0xc6729c: r0 = true
    //     0xc6729c: add             x0, NULL, #0x20  ; true
    // 0xc672a0: LeaveFrame
    //     0xc672a0: mov             SP, fp
    //     0xc672a4: ldp             fp, lr, [SP], #0x10
    // 0xc672a8: ret
    //     0xc672a8: ret             
    // 0xc672ac: r0 = 59
    //     0xc672ac: mov             x0, #0x3b
    // 0xc672b0: branchIfSmi(r1, 0xc672bc)
    //     0xc672b0: tbz             w1, #0, #0xc672bc
    // 0xc672b4: r0 = LoadClassIdInstr(r1)
    //     0xc672b4: ldur            x0, [x1, #-1]
    //     0xc672b8: ubfx            x0, x0, #0xc, #0x14
    // 0xc672bc: SaveReg r1
    //     0xc672bc: str             x1, [SP, #-8]!
    // 0xc672c0: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc672c0: mov             x17, #0x57c5
    //     0xc672c4: add             lr, x0, x17
    //     0xc672c8: ldr             lr, [x21, lr, lsl #3]
    //     0xc672cc: blr             lr
    // 0xc672d0: add             SP, SP, #8
    // 0xc672d4: r1 = LoadClassIdInstr(r0)
    //     0xc672d4: ldur            x1, [x0, #-1]
    //     0xc672d8: ubfx            x1, x1, #0xc, #0x14
    // 0xc672dc: r16 = BoxShadow
    //     0xc672dc: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3fe50] Type: BoxShadow
    //     0xc672e0: ldr             x16, [x16, #0xe50]
    // 0xc672e4: stp             x16, x0, [SP, #-0x10]!
    // 0xc672e8: mov             x0, x1
    // 0xc672ec: mov             lr, x0
    // 0xc672f0: ldr             lr, [x21, lr, lsl #3]
    // 0xc672f4: blr             lr
    // 0xc672f8: add             SP, SP, #0x10
    // 0xc672fc: tbz             w0, #4, #0xc67310
    // 0xc67300: r0 = false
    //     0xc67300: add             x0, NULL, #0x30  ; false
    // 0xc67304: LeaveFrame
    //     0xc67304: mov             SP, fp
    //     0xc67308: ldp             fp, lr, [SP], #0x10
    // 0xc6730c: ret
    //     0xc6730c: ret             
    // 0xc67310: ldr             x0, [fp, #0x10]
    // 0xc67314: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc67314: mov             x1, #0x76
    //     0xc67318: tbz             w0, #0, #0xc67328
    //     0xc6731c: ldur            x1, [x0, #-1]
    //     0xc67320: ubfx            x1, x1, #0xc, #0x14
    //     0xc67324: lsl             x1, x1, #1
    // 0xc67328: r17 = 10090
    //     0xc67328: mov             x17, #0x276a
    // 0xc6732c: cmp             w1, w17
    // 0xc67330: b.ne            #0xc673f0
    // 0xc67334: ldr             x1, [fp, #0x18]
    // 0xc67338: LoadField: r2 = r0->field_7
    //     0xc67338: ldur            w2, [x0, #7]
    // 0xc6733c: DecompressPointer r2
    //     0xc6733c: add             x2, x2, HEAP, lsl #32
    // 0xc67340: stur            x2, [fp, #-0x10]
    // 0xc67344: LoadField: r3 = r1->field_7
    //     0xc67344: ldur            w3, [x1, #7]
    // 0xc67348: DecompressPointer r3
    //     0xc67348: add             x3, x3, HEAP, lsl #32
    // 0xc6734c: stur            x3, [fp, #-8]
    // 0xc67350: cmp             w2, w3
    // 0xc67354: b.eq            #0xc67398
    // 0xc67358: r16 = Color
    //     0xc67358: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc6735c: ldr             x16, [x16, #0xf18]
    // 0xc67360: r30 = Color
    //     0xc67360: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc67364: ldr             lr, [lr, #0xf18]
    // 0xc67368: stp             lr, x16, [SP, #-0x10]!
    // 0xc6736c: r0 = ==()
    //     0xc6736c: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc67370: add             SP, SP, #0x10
    // 0xc67374: tbnz            w0, #4, #0xc673f0
    // 0xc67378: ldur            x0, [fp, #-0x10]
    // 0xc6737c: ldur            x1, [fp, #-8]
    // 0xc67380: LoadField: r2 = r1->field_7
    //     0xc67380: ldur            x2, [x1, #7]
    // 0xc67384: LoadField: r1 = r0->field_7
    //     0xc67384: ldur            x1, [x0, #7]
    // 0xc67388: cmp             x2, x1
    // 0xc6738c: b.ne            #0xc673f0
    // 0xc67390: ldr             x1, [fp, #0x18]
    // 0xc67394: ldr             x0, [fp, #0x10]
    // 0xc67398: LoadField: r2 = r0->field_b
    //     0xc67398: ldur            w2, [x0, #0xb]
    // 0xc6739c: DecompressPointer r2
    //     0xc6739c: add             x2, x2, HEAP, lsl #32
    // 0xc673a0: LoadField: r3 = r1->field_b
    //     0xc673a0: ldur            w3, [x1, #0xb]
    // 0xc673a4: DecompressPointer r3
    //     0xc673a4: add             x3, x3, HEAP, lsl #32
    // 0xc673a8: stp             x3, x2, [SP, #-0x10]!
    // 0xc673ac: r0 = ==()
    //     0xc673ac: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0xc673b0: add             SP, SP, #0x10
    // 0xc673b4: tbnz            w0, #4, #0xc673f0
    // 0xc673b8: ldr             x2, [fp, #0x18]
    // 0xc673bc: ldr             x1, [fp, #0x10]
    // 0xc673c0: LoadField: d0 = r1->field_f
    //     0xc673c0: ldur            d0, [x1, #0xf]
    // 0xc673c4: LoadField: d1 = r2->field_f
    //     0xc673c4: ldur            d1, [x2, #0xf]
    // 0xc673c8: fcmp            d0, d1
    // 0xc673cc: b.vs            #0xc673f0
    // 0xc673d0: b.ne            #0xc673f0
    // 0xc673d4: LoadField: d0 = r1->field_17
    //     0xc673d4: ldur            d0, [x1, #0x17]
    // 0xc673d8: LoadField: d1 = r2->field_17
    //     0xc673d8: ldur            d1, [x2, #0x17]
    // 0xc673dc: fcmp            d0, d1
    // 0xc673e0: b.vs            #0xc673f0
    // 0xc673e4: b.ne            #0xc673f0
    // 0xc673e8: r0 = true
    //     0xc673e8: add             x0, NULL, #0x20  ; true
    // 0xc673ec: b               #0xc673f4
    // 0xc673f0: r0 = false
    //     0xc673f0: add             x0, NULL, #0x30  ; false
    // 0xc673f4: LeaveFrame
    //     0xc673f4: mov             SP, fp
    //     0xc673f8: ldp             fp, lr, [SP], #0x10
    // 0xc673fc: ret
    //     0xc673fc: ret             
    // 0xc67400: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc67400: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc67404: b               #0xc67274
  }
  _ scale(/* No info */) {
    // ** addr: 0xcae454, size: 0xf8
    // 0xcae454: EnterFrame
    //     0xcae454: stp             fp, lr, [SP, #-0x10]!
    //     0xcae458: mov             fp, SP
    // 0xcae45c: AllocStack(0x20)
    //     0xcae45c: sub             SP, SP, #0x20
    // 0xcae460: CheckStackOverflow
    //     0xcae460: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcae464: cmp             SP, x16
    //     0xcae468: b.ls            #0xcae520
    // 0xcae46c: ldr             x0, [fp, #0x18]
    // 0xcae470: LoadField: r1 = r0->field_7
    //     0xcae470: ldur            w1, [x0, #7]
    // 0xcae474: DecompressPointer r1
    //     0xcae474: add             x1, x1, HEAP, lsl #32
    // 0xcae478: stur            x1, [fp, #-8]
    // 0xcae47c: LoadField: r2 = r0->field_b
    //     0xcae47c: ldur            w2, [x0, #0xb]
    // 0xcae480: DecompressPointer r2
    //     0xcae480: add             x2, x2, HEAP, lsl #32
    // 0xcae484: ldr             d0, [fp, #0x10]
    // 0xcae488: r3 = inline_Allocate_Double()
    //     0xcae488: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xcae48c: add             x3, x3, #0x10
    //     0xcae490: cmp             x4, x3
    //     0xcae494: b.ls            #0xcae528
    //     0xcae498: str             x3, [THR, #0x60]  ; THR::top
    //     0xcae49c: sub             x3, x3, #0xf
    //     0xcae4a0: mov             x4, #0xd108
    //     0xcae4a4: movk            x4, #3, lsl #16
    //     0xcae4a8: stur            x4, [x3, #-1]
    // 0xcae4ac: StoreField: r3->field_7 = d0
    //     0xcae4ac: stur            d0, [x3, #7]
    // 0xcae4b0: stp             x3, x2, [SP, #-0x10]!
    // 0xcae4b4: r0 = *()
    //     0xcae4b4: bl              #0x50e62c  ; [dart:ui] Offset::*
    // 0xcae4b8: add             SP, SP, #0x10
    // 0xcae4bc: mov             x1, x0
    // 0xcae4c0: ldr             x0, [fp, #0x18]
    // 0xcae4c4: stur            x1, [fp, #-0x10]
    // 0xcae4c8: LoadField: d0 = r0->field_f
    //     0xcae4c8: ldur            d0, [x0, #0xf]
    // 0xcae4cc: ldr             d1, [fp, #0x10]
    // 0xcae4d0: fmul            d2, d0, d1
    // 0xcae4d4: stur            d2, [fp, #-0x20]
    // 0xcae4d8: LoadField: d0 = r0->field_17
    //     0xcae4d8: ldur            d0, [x0, #0x17]
    // 0xcae4dc: fmul            d3, d0, d1
    // 0xcae4e0: stur            d3, [fp, #-0x18]
    // 0xcae4e4: r0 = BoxShadow()
    //     0xcae4e4: bl              #0x8a3d4c  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0xcae4e8: ldur            d0, [fp, #-0x18]
    // 0xcae4ec: StoreField: r0->field_17 = d0
    //     0xcae4ec: stur            d0, [x0, #0x17]
    // 0xcae4f0: r1 = Instance_BlurStyle
    //     0xcae4f0: add             x1, PP, #0x33, lsl #12  ; [pp+0x33660] Obj!BlurStyle@b675d1
    //     0xcae4f4: ldr             x1, [x1, #0x660]
    // 0xcae4f8: StoreField: r0->field_1f = r1
    //     0xcae4f8: stur            w1, [x0, #0x1f]
    // 0xcae4fc: ldur            x1, [fp, #-8]
    // 0xcae500: StoreField: r0->field_7 = r1
    //     0xcae500: stur            w1, [x0, #7]
    // 0xcae504: ldur            x1, [fp, #-0x10]
    // 0xcae508: StoreField: r0->field_b = r1
    //     0xcae508: stur            w1, [x0, #0xb]
    // 0xcae50c: ldur            d0, [fp, #-0x20]
    // 0xcae510: StoreField: r0->field_f = d0
    //     0xcae510: stur            d0, [x0, #0xf]
    // 0xcae514: LeaveFrame
    //     0xcae514: mov             SP, fp
    //     0xcae518: ldp             fp, lr, [SP], #0x10
    // 0xcae51c: ret
    //     0xcae51c: ret             
    // 0xcae520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcae520: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcae524: b               #0xcae46c
    // 0xcae528: SaveReg d0
    //     0xcae528: str             q0, [SP, #-0x10]!
    // 0xcae52c: stp             x1, x2, [SP, #-0x10]!
    // 0xcae530: SaveReg r0
    //     0xcae530: str             x0, [SP, #-8]!
    // 0xcae534: r0 = AllocateDouble()
    //     0xcae534: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcae538: mov             x3, x0
    // 0xcae53c: RestoreReg r0
    //     0xcae53c: ldr             x0, [SP], #8
    // 0xcae540: ldp             x1, x2, [SP], #0x10
    // 0xcae544: RestoreReg d0
    //     0xcae544: ldr             q0, [SP], #0x10
    // 0xcae548: b               #0xcae4ac
  }
  static _ lerpList(/* No info */) {
    // ** addr: 0xcd60ec, size: 0x6d0
    // 0xcd60ec: EnterFrame
    //     0xcd60ec: stp             fp, lr, [SP, #-0x10]!
    //     0xcd60f0: mov             fp, SP
    // 0xcd60f4: AllocStack(0x60)
    //     0xcd60f4: sub             SP, SP, #0x60
    // 0xcd60f8: CheckStackOverflow
    //     0xcd60f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd60fc: cmp             SP, x16
    //     0xcd6100: b.ls            #0xcd6754
    // 0xcd6104: ldr             x0, [fp, #0x20]
    // 0xcd6108: cmp             w0, NULL
    // 0xcd610c: b.ne            #0xcd612c
    // 0xcd6110: ldr             x1, [fp, #0x18]
    // 0xcd6114: cmp             w1, NULL
    // 0xcd6118: b.ne            #0xcd6130
    // 0xcd611c: r0 = Null
    //     0xcd611c: mov             x0, NULL
    // 0xcd6120: LeaveFrame
    //     0xcd6120: mov             SP, fp
    //     0xcd6124: ldp             fp, lr, [SP], #0x10
    // 0xcd6128: ret
    //     0xcd6128: ret             
    // 0xcd612c: ldr             x1, [fp, #0x18]
    // 0xcd6130: cmp             w0, NULL
    // 0xcd6134: b.ne            #0xcd6154
    // 0xcd6138: r16 = <BoxShadow>
    //     0xcd6138: add             x16, PP, #0x15, lsl #12  ; [pp+0x15268] TypeArguments: <BoxShadow>
    //     0xcd613c: ldr             x16, [x16, #0x268]
    // 0xcd6140: stp             xzr, x16, [SP, #-0x10]!
    // 0xcd6144: r0 = _GrowableList()
    //     0xcd6144: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xcd6148: add             SP, SP, #0x10
    // 0xcd614c: mov             x1, x0
    // 0xcd6150: b               #0xcd6158
    // 0xcd6154: mov             x1, x0
    // 0xcd6158: ldr             x0, [fp, #0x18]
    // 0xcd615c: stur            x1, [fp, #-8]
    // 0xcd6160: cmp             w0, NULL
    // 0xcd6164: b.ne            #0xcd6184
    // 0xcd6168: r16 = <BoxShadow>
    //     0xcd6168: add             x16, PP, #0x15, lsl #12  ; [pp+0x15268] TypeArguments: <BoxShadow>
    //     0xcd616c: ldr             x16, [x16, #0x268]
    // 0xcd6170: stp             xzr, x16, [SP, #-0x10]!
    // 0xcd6174: r0 = _GrowableList()
    //     0xcd6174: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xcd6178: add             SP, SP, #0x10
    // 0xcd617c: mov             x2, x0
    // 0xcd6180: b               #0xcd6188
    // 0xcd6184: mov             x2, x0
    // 0xcd6188: ldur            x1, [fp, #-8]
    // 0xcd618c: stur            x2, [fp, #-0x10]
    // 0xcd6190: r0 = LoadClassIdInstr(r1)
    //     0xcd6190: ldur            x0, [x1, #-1]
    //     0xcd6194: ubfx            x0, x0, #0xc, #0x14
    // 0xcd6198: SaveReg r1
    //     0xcd6198: str             x1, [SP, #-8]!
    // 0xcd619c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xcd619c: mov             x17, #0xb8ea
    //     0xcd61a0: add             lr, x0, x17
    //     0xcd61a4: ldr             lr, [x21, lr, lsl #3]
    //     0xcd61a8: blr             lr
    // 0xcd61ac: add             SP, SP, #8
    // 0xcd61b0: mov             x2, x0
    // 0xcd61b4: ldur            x1, [fp, #-0x10]
    // 0xcd61b8: stur            x2, [fp, #-0x18]
    // 0xcd61bc: r0 = LoadClassIdInstr(r1)
    //     0xcd61bc: ldur            x0, [x1, #-1]
    //     0xcd61c0: ubfx            x0, x0, #0xc, #0x14
    // 0xcd61c4: SaveReg r1
    //     0xcd61c4: str             x1, [SP, #-8]!
    // 0xcd61c8: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xcd61c8: mov             x17, #0xb8ea
    //     0xcd61cc: add             lr, x0, x17
    //     0xcd61d0: ldr             lr, [x21, lr, lsl #3]
    //     0xcd61d4: blr             lr
    // 0xcd61d8: add             SP, SP, #8
    // 0xcd61dc: mov             x1, x0
    // 0xcd61e0: ldur            x0, [fp, #-0x18]
    // 0xcd61e4: r2 = LoadInt32Instr(r0)
    //     0xcd61e4: sbfx            x2, x0, #1, #0x1f
    // 0xcd61e8: r0 = LoadInt32Instr(r1)
    //     0xcd61e8: sbfx            x0, x1, #1, #0x1f
    // 0xcd61ec: cmp             x2, x0
    // 0xcd61f0: b.gt            #0xcd6208
    // 0xcd61f4: cmp             x2, x0
    // 0xcd61f8: b.ge            #0xcd6204
    // 0xcd61fc: mov             x0, x2
    // 0xcd6200: b               #0xcd6208
    // 0xcd6204: mov             x0, x2
    // 0xcd6208: stur            x0, [fp, #-0x20]
    // 0xcd620c: r16 = <BoxShadow>
    //     0xcd620c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15268] TypeArguments: <BoxShadow>
    //     0xcd6210: ldr             x16, [x16, #0x268]
    // 0xcd6214: stp             xzr, x16, [SP, #-0x10]!
    // 0xcd6218: r0 = _GrowableList()
    //     0xcd6218: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xcd621c: add             SP, SP, #0x10
    // 0xcd6220: mov             x2, x0
    // 0xcd6224: stur            x2, [fp, #-0x30]
    // 0xcd6228: r6 = 0
    //     0xcd6228: mov             x6, #0
    // 0xcd622c: ldr             d0, [fp, #0x10]
    // 0xcd6230: ldur            x5, [fp, #-8]
    // 0xcd6234: ldur            x4, [fp, #-0x10]
    // 0xcd6238: ldur            x3, [fp, #-0x20]
    // 0xcd623c: stur            x6, [fp, #-0x28]
    // 0xcd6240: CheckStackOverflow
    //     0xcd6240: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd6244: cmp             SP, x16
    //     0xcd6248: b.ls            #0xcd675c
    // 0xcd624c: cmp             x6, x3
    // 0xcd6250: b.ge            #0xcd6374
    // 0xcd6254: r0 = BoxInt64Instr(r6)
    //     0xcd6254: sbfiz           x0, x6, #1, #0x1f
    //     0xcd6258: cmp             x6, x0, asr #1
    //     0xcd625c: b.eq            #0xcd6268
    //     0xcd6260: bl              #0xd69c6c
    //     0xcd6264: stur            x6, [x0, #7]
    // 0xcd6268: mov             x1, x0
    // 0xcd626c: stur            x1, [fp, #-0x18]
    // 0xcd6270: r0 = LoadClassIdInstr(r5)
    //     0xcd6270: ldur            x0, [x5, #-1]
    //     0xcd6274: ubfx            x0, x0, #0xc, #0x14
    // 0xcd6278: stp             x1, x5, [SP, #-0x10]!
    // 0xcd627c: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcd627c: sub             lr, x0, #0xd83
    //     0xcd6280: ldr             lr, [x21, lr, lsl #3]
    //     0xcd6284: blr             lr
    // 0xcd6288: add             SP, SP, #0x10
    // 0xcd628c: mov             x2, x0
    // 0xcd6290: ldur            x1, [fp, #-0x10]
    // 0xcd6294: stur            x2, [fp, #-0x38]
    // 0xcd6298: r0 = LoadClassIdInstr(r1)
    //     0xcd6298: ldur            x0, [x1, #-1]
    //     0xcd629c: ubfx            x0, x0, #0xc, #0x14
    // 0xcd62a0: ldur            x16, [fp, #-0x18]
    // 0xcd62a4: stp             x16, x1, [SP, #-0x10]!
    // 0xcd62a8: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcd62a8: sub             lr, x0, #0xd83
    //     0xcd62ac: ldr             lr, [x21, lr, lsl #3]
    //     0xcd62b0: blr             lr
    // 0xcd62b4: add             SP, SP, #0x10
    // 0xcd62b8: ldur            x16, [fp, #-0x38]
    // 0xcd62bc: stp             x0, x16, [SP, #-0x10]!
    // 0xcd62c0: ldr             d0, [fp, #0x10]
    // 0xcd62c4: SaveReg d0
    //     0xcd62c4: str             d0, [SP, #-8]!
    // 0xcd62c8: r0 = lerp()
    //     0xcd62c8: bl              #0xcd67bc  ; [package:flutter/src/painting/box_shadow.dart] BoxShadow::lerp
    // 0xcd62cc: add             SP, SP, #0x18
    // 0xcd62d0: stur            x0, [fp, #-0x38]
    // 0xcd62d4: cmp             w0, NULL
    // 0xcd62d8: b.eq            #0xcd6764
    // 0xcd62dc: ldur            x1, [fp, #-0x30]
    // 0xcd62e0: LoadField: r2 = r1->field_b
    //     0xcd62e0: ldur            w2, [x1, #0xb]
    // 0xcd62e4: DecompressPointer r2
    //     0xcd62e4: add             x2, x2, HEAP, lsl #32
    // 0xcd62e8: stur            x2, [fp, #-0x18]
    // 0xcd62ec: LoadField: r3 = r1->field_f
    //     0xcd62ec: ldur            w3, [x1, #0xf]
    // 0xcd62f0: DecompressPointer r3
    //     0xcd62f0: add             x3, x3, HEAP, lsl #32
    // 0xcd62f4: LoadField: r4 = r3->field_b
    //     0xcd62f4: ldur            w4, [x3, #0xb]
    // 0xcd62f8: DecompressPointer r4
    //     0xcd62f8: add             x4, x4, HEAP, lsl #32
    // 0xcd62fc: cmp             w2, w4
    // 0xcd6300: b.ne            #0xcd6310
    // 0xcd6304: SaveReg r1
    //     0xcd6304: str             x1, [SP, #-8]!
    // 0xcd6308: r0 = _growToNextCapacity()
    //     0xcd6308: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xcd630c: add             SP, SP, #8
    // 0xcd6310: ldur            x2, [fp, #-0x30]
    // 0xcd6314: ldur            x3, [fp, #-0x28]
    // 0xcd6318: ldur            x0, [fp, #-0x18]
    // 0xcd631c: r4 = LoadInt32Instr(r0)
    //     0xcd631c: sbfx            x4, x0, #1, #0x1f
    // 0xcd6320: add             x0, x4, #1
    // 0xcd6324: lsl             x1, x0, #1
    // 0xcd6328: StoreField: r2->field_b = r1
    //     0xcd6328: stur            w1, [x2, #0xb]
    // 0xcd632c: mov             x1, x4
    // 0xcd6330: cmp             x1, x0
    // 0xcd6334: b.hs            #0xcd6768
    // 0xcd6338: LoadField: r1 = r2->field_f
    //     0xcd6338: ldur            w1, [x2, #0xf]
    // 0xcd633c: DecompressPointer r1
    //     0xcd633c: add             x1, x1, HEAP, lsl #32
    // 0xcd6340: ldur            x0, [fp, #-0x38]
    // 0xcd6344: ArrayStore: r1[r4] = r0  ; List_4
    //     0xcd6344: add             x25, x1, x4, lsl #2
    //     0xcd6348: add             x25, x25, #0xf
    //     0xcd634c: str             w0, [x25]
    //     0xcd6350: tbz             w0, #0, #0xcd636c
    //     0xcd6354: ldurb           w16, [x1, #-1]
    //     0xcd6358: ldurb           w17, [x0, #-1]
    //     0xcd635c: and             x16, x17, x16, lsr #2
    //     0xcd6360: tst             x16, HEAP, lsr #32
    //     0xcd6364: b.eq            #0xcd636c
    //     0xcd6368: bl              #0xd67e5c
    // 0xcd636c: add             x6, x3, #1
    // 0xcd6370: b               #0xcd622c
    // 0xcd6374: d1 = 1.000000
    //     0xcd6374: fmov            d1, #1.00000000
    // 0xcd6378: fsub            d2, d1, d0
    // 0xcd637c: stur            d2, [fp, #-0x50]
    // 0xcd6380: r1 = inline_Allocate_Double()
    //     0xcd6380: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0xcd6384: add             x1, x1, #0x10
    //     0xcd6388: cmp             x0, x1
    //     0xcd638c: b.ls            #0xcd676c
    //     0xcd6390: str             x1, [THR, #0x60]  ; THR::top
    //     0xcd6394: sub             x1, x1, #0xf
    //     0xcd6398: mov             x0, #0xd108
    //     0xcd639c: movk            x0, #3, lsl #16
    //     0xcd63a0: stur            x0, [x1, #-1]
    // 0xcd63a4: StoreField: r1->field_7 = d2
    //     0xcd63a4: stur            d2, [x1, #7]
    // 0xcd63a8: stur            x1, [fp, #-0x18]
    // 0xcd63ac: ldur            x4, [fp, #-0x20]
    // 0xcd63b0: ldur            x3, [fp, #-8]
    // 0xcd63b4: stur            x4, [fp, #-0x28]
    // 0xcd63b8: CheckStackOverflow
    //     0xcd63b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd63bc: cmp             SP, x16
    //     0xcd63c0: b.ls            #0xcd6788
    // 0xcd63c4: r0 = LoadClassIdInstr(r3)
    //     0xcd63c4: ldur            x0, [x3, #-1]
    //     0xcd63c8: ubfx            x0, x0, #0xc, #0x14
    // 0xcd63cc: SaveReg r3
    //     0xcd63cc: str             x3, [SP, #-8]!
    // 0xcd63d0: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xcd63d0: mov             x17, #0xb8ea
    //     0xcd63d4: add             lr, x0, x17
    //     0xcd63d8: ldr             lr, [x21, lr, lsl #3]
    //     0xcd63dc: blr             lr
    // 0xcd63e0: add             SP, SP, #8
    // 0xcd63e4: r1 = LoadInt32Instr(r0)
    //     0xcd63e4: sbfx            x1, x0, #1, #0x1f
    // 0xcd63e8: ldur            x2, [fp, #-0x28]
    // 0xcd63ec: cmp             x2, x1
    // 0xcd63f0: b.ge            #0xcd655c
    // 0xcd63f4: ldur            x4, [fp, #-8]
    // 0xcd63f8: ldur            x3, [fp, #-0x30]
    // 0xcd63fc: ldur            d0, [fp, #-0x50]
    // 0xcd6400: r0 = BoxInt64Instr(r2)
    //     0xcd6400: sbfiz           x0, x2, #1, #0x1f
    //     0xcd6404: cmp             x2, x0, asr #1
    //     0xcd6408: b.eq            #0xcd6414
    //     0xcd640c: bl              #0xd69c6c
    //     0xcd6410: stur            x2, [x0, #7]
    // 0xcd6414: r1 = LoadClassIdInstr(r4)
    //     0xcd6414: ldur            x1, [x4, #-1]
    //     0xcd6418: ubfx            x1, x1, #0xc, #0x14
    // 0xcd641c: stp             x0, x4, [SP, #-0x10]!
    // 0xcd6420: mov             x0, x1
    // 0xcd6424: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcd6424: sub             lr, x0, #0xd83
    //     0xcd6428: ldr             lr, [x21, lr, lsl #3]
    //     0xcd642c: blr             lr
    // 0xcd6430: add             SP, SP, #0x10
    // 0xcd6434: stur            x0, [fp, #-0x40]
    // 0xcd6438: LoadField: r1 = r0->field_7
    //     0xcd6438: ldur            w1, [x0, #7]
    // 0xcd643c: DecompressPointer r1
    //     0xcd643c: add             x1, x1, HEAP, lsl #32
    // 0xcd6440: stur            x1, [fp, #-0x38]
    // 0xcd6444: LoadField: r2 = r0->field_b
    //     0xcd6444: ldur            w2, [x0, #0xb]
    // 0xcd6448: DecompressPointer r2
    //     0xcd6448: add             x2, x2, HEAP, lsl #32
    // 0xcd644c: ldur            x16, [fp, #-0x18]
    // 0xcd6450: stp             x16, x2, [SP, #-0x10]!
    // 0xcd6454: r0 = *()
    //     0xcd6454: bl              #0x50e62c  ; [dart:ui] Offset::*
    // 0xcd6458: add             SP, SP, #0x10
    // 0xcd645c: mov             x1, x0
    // 0xcd6460: ldur            x0, [fp, #-0x40]
    // 0xcd6464: stur            x1, [fp, #-0x48]
    // 0xcd6468: LoadField: d0 = r0->field_f
    //     0xcd6468: ldur            d0, [x0, #0xf]
    // 0xcd646c: ldur            d1, [fp, #-0x50]
    // 0xcd6470: fmul            d2, d0, d1
    // 0xcd6474: stur            d2, [fp, #-0x60]
    // 0xcd6478: LoadField: d0 = r0->field_17
    //     0xcd6478: ldur            d0, [x0, #0x17]
    // 0xcd647c: fmul            d3, d0, d1
    // 0xcd6480: stur            d3, [fp, #-0x58]
    // 0xcd6484: r0 = BoxShadow()
    //     0xcd6484: bl              #0x8a3d4c  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0xcd6488: ldur            d0, [fp, #-0x58]
    // 0xcd648c: stur            x0, [fp, #-0x40]
    // 0xcd6490: StoreField: r0->field_17 = d0
    //     0xcd6490: stur            d0, [x0, #0x17]
    // 0xcd6494: r1 = Instance_BlurStyle
    //     0xcd6494: add             x1, PP, #0x33, lsl #12  ; [pp+0x33660] Obj!BlurStyle@b675d1
    //     0xcd6498: ldr             x1, [x1, #0x660]
    // 0xcd649c: StoreField: r0->field_1f = r1
    //     0xcd649c: stur            w1, [x0, #0x1f]
    // 0xcd64a0: ldur            x2, [fp, #-0x38]
    // 0xcd64a4: StoreField: r0->field_7 = r2
    //     0xcd64a4: stur            w2, [x0, #7]
    // 0xcd64a8: ldur            x2, [fp, #-0x48]
    // 0xcd64ac: StoreField: r0->field_b = r2
    //     0xcd64ac: stur            w2, [x0, #0xb]
    // 0xcd64b0: ldur            d0, [fp, #-0x60]
    // 0xcd64b4: StoreField: r0->field_f = d0
    //     0xcd64b4: stur            d0, [x0, #0xf]
    // 0xcd64b8: ldur            x2, [fp, #-0x30]
    // 0xcd64bc: LoadField: r3 = r2->field_b
    //     0xcd64bc: ldur            w3, [x2, #0xb]
    // 0xcd64c0: DecompressPointer r3
    //     0xcd64c0: add             x3, x3, HEAP, lsl #32
    // 0xcd64c4: stur            x3, [fp, #-0x38]
    // 0xcd64c8: LoadField: r4 = r2->field_f
    //     0xcd64c8: ldur            w4, [x2, #0xf]
    // 0xcd64cc: DecompressPointer r4
    //     0xcd64cc: add             x4, x4, HEAP, lsl #32
    // 0xcd64d0: LoadField: r5 = r4->field_b
    //     0xcd64d0: ldur            w5, [x4, #0xb]
    // 0xcd64d4: DecompressPointer r5
    //     0xcd64d4: add             x5, x5, HEAP, lsl #32
    // 0xcd64d8: cmp             w3, w5
    // 0xcd64dc: b.ne            #0xcd64ec
    // 0xcd64e0: SaveReg r2
    //     0xcd64e0: str             x2, [SP, #-8]!
    // 0xcd64e4: r0 = _growToNextCapacity()
    //     0xcd64e4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xcd64e8: add             SP, SP, #8
    // 0xcd64ec: ldur            x2, [fp, #-0x30]
    // 0xcd64f0: ldur            x3, [fp, #-0x28]
    // 0xcd64f4: ldur            x0, [fp, #-0x38]
    // 0xcd64f8: r4 = LoadInt32Instr(r0)
    //     0xcd64f8: sbfx            x4, x0, #1, #0x1f
    // 0xcd64fc: add             x0, x4, #1
    // 0xcd6500: lsl             x1, x0, #1
    // 0xcd6504: StoreField: r2->field_b = r1
    //     0xcd6504: stur            w1, [x2, #0xb]
    // 0xcd6508: mov             x1, x4
    // 0xcd650c: cmp             x1, x0
    // 0xcd6510: b.hs            #0xcd6790
    // 0xcd6514: LoadField: r1 = r2->field_f
    //     0xcd6514: ldur            w1, [x2, #0xf]
    // 0xcd6518: DecompressPointer r1
    //     0xcd6518: add             x1, x1, HEAP, lsl #32
    // 0xcd651c: ldur            x0, [fp, #-0x40]
    // 0xcd6520: ArrayStore: r1[r4] = r0  ; List_4
    //     0xcd6520: add             x25, x1, x4, lsl #2
    //     0xcd6524: add             x25, x25, #0xf
    //     0xcd6528: str             w0, [x25]
    //     0xcd652c: tbz             w0, #0, #0xcd6548
    //     0xcd6530: ldurb           w16, [x1, #-1]
    //     0xcd6534: ldurb           w17, [x0, #-1]
    //     0xcd6538: and             x16, x17, x16, lsr #2
    //     0xcd653c: tst             x16, HEAP, lsr #32
    //     0xcd6540: b.eq            #0xcd6548
    //     0xcd6544: bl              #0xd67e5c
    // 0xcd6548: add             x4, x3, #1
    // 0xcd654c: ldr             d0, [fp, #0x10]
    // 0xcd6550: ldur            d2, [fp, #-0x50]
    // 0xcd6554: ldur            x1, [fp, #-0x18]
    // 0xcd6558: b               #0xcd63b0
    // 0xcd655c: ldr             d0, [fp, #0x10]
    // 0xcd6560: ldur            x2, [fp, #-0x30]
    // 0xcd6564: r1 = inline_Allocate_Double()
    //     0xcd6564: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0xcd6568: add             x1, x1, #0x10
    //     0xcd656c: cmp             x0, x1
    //     0xcd6570: b.ls            #0xcd6794
    //     0xcd6574: str             x1, [THR, #0x60]  ; THR::top
    //     0xcd6578: sub             x1, x1, #0xf
    //     0xcd657c: mov             x0, #0xd108
    //     0xcd6580: movk            x0, #3, lsl #16
    //     0xcd6584: stur            x0, [x1, #-1]
    // 0xcd6588: StoreField: r1->field_7 = d0
    //     0xcd6588: stur            d0, [x1, #7]
    // 0xcd658c: stur            x1, [fp, #-8]
    // 0xcd6590: ldur            x4, [fp, #-0x20]
    // 0xcd6594: ldur            x3, [fp, #-0x10]
    // 0xcd6598: stur            x4, [fp, #-0x20]
    // 0xcd659c: CheckStackOverflow
    //     0xcd659c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd65a0: cmp             SP, x16
    //     0xcd65a4: b.ls            #0xcd67b0
    // 0xcd65a8: r0 = LoadClassIdInstr(r3)
    //     0xcd65a8: ldur            x0, [x3, #-1]
    //     0xcd65ac: ubfx            x0, x0, #0xc, #0x14
    // 0xcd65b0: SaveReg r3
    //     0xcd65b0: str             x3, [SP, #-8]!
    // 0xcd65b4: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xcd65b4: mov             x17, #0xb8ea
    //     0xcd65b8: add             lr, x0, x17
    //     0xcd65bc: ldr             lr, [x21, lr, lsl #3]
    //     0xcd65c0: blr             lr
    // 0xcd65c4: add             SP, SP, #8
    // 0xcd65c8: r1 = LoadInt32Instr(r0)
    //     0xcd65c8: sbfx            x1, x0, #1, #0x1f
    // 0xcd65cc: ldur            x2, [fp, #-0x20]
    // 0xcd65d0: cmp             x2, x1
    // 0xcd65d4: b.ge            #0xcd6740
    // 0xcd65d8: ldr             d0, [fp, #0x10]
    // 0xcd65dc: ldur            x4, [fp, #-0x10]
    // 0xcd65e0: ldur            x3, [fp, #-0x30]
    // 0xcd65e4: r0 = BoxInt64Instr(r2)
    //     0xcd65e4: sbfiz           x0, x2, #1, #0x1f
    //     0xcd65e8: cmp             x2, x0, asr #1
    //     0xcd65ec: b.eq            #0xcd65f8
    //     0xcd65f0: bl              #0xd69c6c
    //     0xcd65f4: stur            x2, [x0, #7]
    // 0xcd65f8: r1 = LoadClassIdInstr(r4)
    //     0xcd65f8: ldur            x1, [x4, #-1]
    //     0xcd65fc: ubfx            x1, x1, #0xc, #0x14
    // 0xcd6600: stp             x0, x4, [SP, #-0x10]!
    // 0xcd6604: mov             x0, x1
    // 0xcd6608: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcd6608: sub             lr, x0, #0xd83
    //     0xcd660c: ldr             lr, [x21, lr, lsl #3]
    //     0xcd6610: blr             lr
    // 0xcd6614: add             SP, SP, #0x10
    // 0xcd6618: stur            x0, [fp, #-0x38]
    // 0xcd661c: LoadField: r1 = r0->field_7
    //     0xcd661c: ldur            w1, [x0, #7]
    // 0xcd6620: DecompressPointer r1
    //     0xcd6620: add             x1, x1, HEAP, lsl #32
    // 0xcd6624: stur            x1, [fp, #-0x18]
    // 0xcd6628: LoadField: r2 = r0->field_b
    //     0xcd6628: ldur            w2, [x0, #0xb]
    // 0xcd662c: DecompressPointer r2
    //     0xcd662c: add             x2, x2, HEAP, lsl #32
    // 0xcd6630: ldur            x16, [fp, #-8]
    // 0xcd6634: stp             x16, x2, [SP, #-0x10]!
    // 0xcd6638: r0 = *()
    //     0xcd6638: bl              #0x50e62c  ; [dart:ui] Offset::*
    // 0xcd663c: add             SP, SP, #0x10
    // 0xcd6640: mov             x1, x0
    // 0xcd6644: ldur            x0, [fp, #-0x38]
    // 0xcd6648: stur            x1, [fp, #-0x40]
    // 0xcd664c: LoadField: d0 = r0->field_f
    //     0xcd664c: ldur            d0, [x0, #0xf]
    // 0xcd6650: ldr             d1, [fp, #0x10]
    // 0xcd6654: fmul            d2, d0, d1
    // 0xcd6658: stur            d2, [fp, #-0x58]
    // 0xcd665c: LoadField: d0 = r0->field_17
    //     0xcd665c: ldur            d0, [x0, #0x17]
    // 0xcd6660: fmul            d3, d0, d1
    // 0xcd6664: stur            d3, [fp, #-0x50]
    // 0xcd6668: r0 = BoxShadow()
    //     0xcd6668: bl              #0x8a3d4c  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0xcd666c: ldur            d0, [fp, #-0x50]
    // 0xcd6670: stur            x0, [fp, #-0x38]
    // 0xcd6674: StoreField: r0->field_17 = d0
    //     0xcd6674: stur            d0, [x0, #0x17]
    // 0xcd6678: r1 = Instance_BlurStyle
    //     0xcd6678: add             x1, PP, #0x33, lsl #12  ; [pp+0x33660] Obj!BlurStyle@b675d1
    //     0xcd667c: ldr             x1, [x1, #0x660]
    // 0xcd6680: StoreField: r0->field_1f = r1
    //     0xcd6680: stur            w1, [x0, #0x1f]
    // 0xcd6684: ldur            x2, [fp, #-0x18]
    // 0xcd6688: StoreField: r0->field_7 = r2
    //     0xcd6688: stur            w2, [x0, #7]
    // 0xcd668c: ldur            x2, [fp, #-0x40]
    // 0xcd6690: StoreField: r0->field_b = r2
    //     0xcd6690: stur            w2, [x0, #0xb]
    // 0xcd6694: ldur            d0, [fp, #-0x58]
    // 0xcd6698: StoreField: r0->field_f = d0
    //     0xcd6698: stur            d0, [x0, #0xf]
    // 0xcd669c: ldur            x2, [fp, #-0x30]
    // 0xcd66a0: LoadField: r3 = r2->field_b
    //     0xcd66a0: ldur            w3, [x2, #0xb]
    // 0xcd66a4: DecompressPointer r3
    //     0xcd66a4: add             x3, x3, HEAP, lsl #32
    // 0xcd66a8: stur            x3, [fp, #-0x18]
    // 0xcd66ac: LoadField: r4 = r2->field_f
    //     0xcd66ac: ldur            w4, [x2, #0xf]
    // 0xcd66b0: DecompressPointer r4
    //     0xcd66b0: add             x4, x4, HEAP, lsl #32
    // 0xcd66b4: LoadField: r5 = r4->field_b
    //     0xcd66b4: ldur            w5, [x4, #0xb]
    // 0xcd66b8: DecompressPointer r5
    //     0xcd66b8: add             x5, x5, HEAP, lsl #32
    // 0xcd66bc: cmp             w3, w5
    // 0xcd66c0: b.ne            #0xcd66d0
    // 0xcd66c4: SaveReg r2
    //     0xcd66c4: str             x2, [SP, #-8]!
    // 0xcd66c8: r0 = _growToNextCapacity()
    //     0xcd66c8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xcd66cc: add             SP, SP, #8
    // 0xcd66d0: ldur            x2, [fp, #-0x30]
    // 0xcd66d4: ldur            x4, [fp, #-0x20]
    // 0xcd66d8: ldur            x3, [fp, #-0x18]
    // 0xcd66dc: r5 = LoadInt32Instr(r3)
    //     0xcd66dc: sbfx            x5, x3, #1, #0x1f
    // 0xcd66e0: add             x0, x5, #1
    // 0xcd66e4: lsl             x3, x0, #1
    // 0xcd66e8: StoreField: r2->field_b = r3
    //     0xcd66e8: stur            w3, [x2, #0xb]
    // 0xcd66ec: mov             x1, x5
    // 0xcd66f0: cmp             x1, x0
    // 0xcd66f4: b.hs            #0xcd67b8
    // 0xcd66f8: LoadField: r1 = r2->field_f
    //     0xcd66f8: ldur            w1, [x2, #0xf]
    // 0xcd66fc: DecompressPointer r1
    //     0xcd66fc: add             x1, x1, HEAP, lsl #32
    // 0xcd6700: ldur            x0, [fp, #-0x38]
    // 0xcd6704: ArrayStore: r1[r5] = r0  ; List_4
    //     0xcd6704: add             x25, x1, x5, lsl #2
    //     0xcd6708: add             x25, x25, #0xf
    //     0xcd670c: str             w0, [x25]
    //     0xcd6710: tbz             w0, #0, #0xcd672c
    //     0xcd6714: ldurb           w16, [x1, #-1]
    //     0xcd6718: ldurb           w17, [x0, #-1]
    //     0xcd671c: and             x16, x17, x16, lsr #2
    //     0xcd6720: tst             x16, HEAP, lsr #32
    //     0xcd6724: b.eq            #0xcd672c
    //     0xcd6728: bl              #0xd67e5c
    // 0xcd672c: add             x0, x4, #1
    // 0xcd6730: mov             x4, x0
    // 0xcd6734: ldr             d0, [fp, #0x10]
    // 0xcd6738: ldur            x1, [fp, #-8]
    // 0xcd673c: b               #0xcd6594
    // 0xcd6740: ldur            x2, [fp, #-0x30]
    // 0xcd6744: mov             x0, x2
    // 0xcd6748: LeaveFrame
    //     0xcd6748: mov             SP, fp
    //     0xcd674c: ldp             fp, lr, [SP], #0x10
    // 0xcd6750: ret
    //     0xcd6750: ret             
    // 0xcd6754: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd6754: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd6758: b               #0xcd6104
    // 0xcd675c: r0 = StackOverflowSharedWithFPURegs()
    //     0xcd675c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcd6760: b               #0xcd624c
    // 0xcd6764: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd6764: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd6768: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcd6768: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcd676c: stp             q0, q2, [SP, #-0x20]!
    // 0xcd6770: SaveReg r2
    //     0xcd6770: str             x2, [SP, #-8]!
    // 0xcd6774: r0 = AllocateDouble()
    //     0xcd6774: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcd6778: mov             x1, x0
    // 0xcd677c: RestoreReg r2
    //     0xcd677c: ldr             x2, [SP], #8
    // 0xcd6780: ldp             q0, q2, [SP], #0x20
    // 0xcd6784: b               #0xcd63a4
    // 0xcd6788: r0 = StackOverflowSharedWithFPURegs()
    //     0xcd6788: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcd678c: b               #0xcd63c4
    // 0xcd6790: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcd6790: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcd6794: SaveReg d0
    //     0xcd6794: str             q0, [SP, #-0x10]!
    // 0xcd6798: SaveReg r2
    //     0xcd6798: str             x2, [SP, #-8]!
    // 0xcd679c: r0 = AllocateDouble()
    //     0xcd679c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcd67a0: mov             x1, x0
    // 0xcd67a4: RestoreReg r2
    //     0xcd67a4: ldr             x2, [SP], #8
    // 0xcd67a8: RestoreReg d0
    //     0xcd67a8: ldr             q0, [SP], #0x10
    // 0xcd67ac: b               #0xcd6588
    // 0xcd67b0: r0 = StackOverflowSharedWithFPURegs()
    //     0xcd67b0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcd67b4: b               #0xcd65a8
    // 0xcd67b8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcd67b8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xcd67bc, size: 0x2b4
    // 0xcd67bc: EnterFrame
    //     0xcd67bc: stp             fp, lr, [SP, #-0x10]!
    //     0xcd67c0: mov             fp, SP
    // 0xcd67c4: AllocStack(0x28)
    //     0xcd67c4: sub             SP, SP, #0x28
    // 0xcd67c8: CheckStackOverflow
    //     0xcd67c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd67cc: cmp             SP, x16
    //     0xcd67d0: b.ls            #0xcd69b4
    // 0xcd67d4: ldr             x0, [fp, #0x20]
    // 0xcd67d8: LoadField: r1 = r0->field_7
    //     0xcd67d8: ldur            w1, [x0, #7]
    // 0xcd67dc: DecompressPointer r1
    //     0xcd67dc: add             x1, x1, HEAP, lsl #32
    // 0xcd67e0: ldr             x2, [fp, #0x18]
    // 0xcd67e4: LoadField: r3 = r2->field_7
    //     0xcd67e4: ldur            w3, [x2, #7]
    // 0xcd67e8: DecompressPointer r3
    //     0xcd67e8: add             x3, x3, HEAP, lsl #32
    // 0xcd67ec: ldr             d0, [fp, #0x10]
    // 0xcd67f0: r4 = inline_Allocate_Double()
    //     0xcd67f0: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xcd67f4: add             x4, x4, #0x10
    //     0xcd67f8: cmp             x5, x4
    //     0xcd67fc: b.ls            #0xcd69bc
    //     0xcd6800: str             x4, [THR, #0x60]  ; THR::top
    //     0xcd6804: sub             x4, x4, #0xf
    //     0xcd6808: mov             x5, #0xd108
    //     0xcd680c: movk            x5, #3, lsl #16
    //     0xcd6810: stur            x5, [x4, #-1]
    // 0xcd6814: StoreField: r4->field_7 = d0
    //     0xcd6814: stur            d0, [x4, #7]
    // 0xcd6818: stur            x4, [fp, #-8]
    // 0xcd681c: stp             x3, x1, [SP, #-0x10]!
    // 0xcd6820: SaveReg r4
    //     0xcd6820: str             x4, [SP, #-8]!
    // 0xcd6824: r0 = lerp()
    //     0xcd6824: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xcd6828: add             SP, SP, #0x18
    // 0xcd682c: stur            x0, [fp, #-0x10]
    // 0xcd6830: cmp             w0, NULL
    // 0xcd6834: b.eq            #0xcd69e0
    // 0xcd6838: ldr             x1, [fp, #0x20]
    // 0xcd683c: LoadField: r2 = r1->field_b
    //     0xcd683c: ldur            w2, [x1, #0xb]
    // 0xcd6840: DecompressPointer r2
    //     0xcd6840: add             x2, x2, HEAP, lsl #32
    // 0xcd6844: ldr             x3, [fp, #0x18]
    // 0xcd6848: LoadField: r4 = r3->field_b
    //     0xcd6848: ldur            w4, [x3, #0xb]
    // 0xcd684c: DecompressPointer r4
    //     0xcd684c: add             x4, x4, HEAP, lsl #32
    // 0xcd6850: stp             x4, x2, [SP, #-0x10]!
    // 0xcd6854: ldr             d0, [fp, #0x10]
    // 0xcd6858: SaveReg d0
    //     0xcd6858: str             d0, [SP, #-8]!
    // 0xcd685c: r0 = lerp()
    //     0xcd685c: bl              #0x9963f8  ; [dart:ui] Offset::lerp
    // 0xcd6860: add             SP, SP, #0x18
    // 0xcd6864: stur            x0, [fp, #-0x18]
    // 0xcd6868: cmp             w0, NULL
    // 0xcd686c: b.eq            #0xcd69e4
    // 0xcd6870: ldr             x1, [fp, #0x20]
    // 0xcd6874: LoadField: d0 = r1->field_f
    //     0xcd6874: ldur            d0, [x1, #0xf]
    // 0xcd6878: ldr             x2, [fp, #0x18]
    // 0xcd687c: LoadField: d1 = r2->field_f
    //     0xcd687c: ldur            d1, [x2, #0xf]
    // 0xcd6880: r3 = inline_Allocate_Double()
    //     0xcd6880: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xcd6884: add             x3, x3, #0x10
    //     0xcd6888: cmp             x4, x3
    //     0xcd688c: b.ls            #0xcd69e8
    //     0xcd6890: str             x3, [THR, #0x60]  ; THR::top
    //     0xcd6894: sub             x3, x3, #0xf
    //     0xcd6898: mov             x4, #0xd108
    //     0xcd689c: movk            x4, #3, lsl #16
    //     0xcd68a0: stur            x4, [x3, #-1]
    // 0xcd68a4: StoreField: r3->field_7 = d0
    //     0xcd68a4: stur            d0, [x3, #7]
    // 0xcd68a8: r4 = inline_Allocate_Double()
    //     0xcd68a8: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xcd68ac: add             x4, x4, #0x10
    //     0xcd68b0: cmp             x5, x4
    //     0xcd68b4: b.ls            #0xcd6a0c
    //     0xcd68b8: str             x4, [THR, #0x60]  ; THR::top
    //     0xcd68bc: sub             x4, x4, #0xf
    //     0xcd68c0: mov             x5, #0xd108
    //     0xcd68c4: movk            x5, #3, lsl #16
    //     0xcd68c8: stur            x5, [x4, #-1]
    // 0xcd68cc: StoreField: r4->field_7 = d1
    //     0xcd68cc: stur            d1, [x4, #7]
    // 0xcd68d0: stp             x4, x3, [SP, #-0x10]!
    // 0xcd68d4: ldur            x16, [fp, #-8]
    // 0xcd68d8: SaveReg r16
    //     0xcd68d8: str             x16, [SP, #-8]!
    // 0xcd68dc: r0 = lerpDouble()
    //     0xcd68dc: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xcd68e0: add             SP, SP, #0x18
    // 0xcd68e4: stur            x0, [fp, #-0x20]
    // 0xcd68e8: cmp             w0, NULL
    // 0xcd68ec: b.eq            #0xcd6a30
    // 0xcd68f0: ldr             x1, [fp, #0x20]
    // 0xcd68f4: LoadField: d0 = r1->field_17
    //     0xcd68f4: ldur            d0, [x1, #0x17]
    // 0xcd68f8: ldr             x1, [fp, #0x18]
    // 0xcd68fc: LoadField: d1 = r1->field_17
    //     0xcd68fc: ldur            d1, [x1, #0x17]
    // 0xcd6900: r1 = inline_Allocate_Double()
    //     0xcd6900: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xcd6904: add             x1, x1, #0x10
    //     0xcd6908: cmp             x2, x1
    //     0xcd690c: b.ls            #0xcd6a34
    //     0xcd6910: str             x1, [THR, #0x60]  ; THR::top
    //     0xcd6914: sub             x1, x1, #0xf
    //     0xcd6918: mov             x2, #0xd108
    //     0xcd691c: movk            x2, #3, lsl #16
    //     0xcd6920: stur            x2, [x1, #-1]
    // 0xcd6924: StoreField: r1->field_7 = d0
    //     0xcd6924: stur            d0, [x1, #7]
    // 0xcd6928: r2 = inline_Allocate_Double()
    //     0xcd6928: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xcd692c: add             x2, x2, #0x10
    //     0xcd6930: cmp             x3, x2
    //     0xcd6934: b.ls            #0xcd6a50
    //     0xcd6938: str             x2, [THR, #0x60]  ; THR::top
    //     0xcd693c: sub             x2, x2, #0xf
    //     0xcd6940: mov             x3, #0xd108
    //     0xcd6944: movk            x3, #3, lsl #16
    //     0xcd6948: stur            x3, [x2, #-1]
    // 0xcd694c: StoreField: r2->field_7 = d1
    //     0xcd694c: stur            d1, [x2, #7]
    // 0xcd6950: stp             x2, x1, [SP, #-0x10]!
    // 0xcd6954: ldur            x16, [fp, #-8]
    // 0xcd6958: SaveReg r16
    //     0xcd6958: str             x16, [SP, #-8]!
    // 0xcd695c: r0 = lerpDouble()
    //     0xcd695c: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xcd6960: add             SP, SP, #0x18
    // 0xcd6964: cmp             w0, NULL
    // 0xcd6968: b.eq            #0xcd6a6c
    // 0xcd696c: LoadField: d0 = r0->field_7
    //     0xcd696c: ldur            d0, [x0, #7]
    // 0xcd6970: stur            d0, [fp, #-0x28]
    // 0xcd6974: r0 = BoxShadow()
    //     0xcd6974: bl              #0x8a3d4c  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0xcd6978: ldur            d0, [fp, #-0x28]
    // 0xcd697c: StoreField: r0->field_17 = d0
    //     0xcd697c: stur            d0, [x0, #0x17]
    // 0xcd6980: r1 = Instance_BlurStyle
    //     0xcd6980: add             x1, PP, #0x33, lsl #12  ; [pp+0x33660] Obj!BlurStyle@b675d1
    //     0xcd6984: ldr             x1, [x1, #0x660]
    // 0xcd6988: StoreField: r0->field_1f = r1
    //     0xcd6988: stur            w1, [x0, #0x1f]
    // 0xcd698c: ldur            x1, [fp, #-0x10]
    // 0xcd6990: StoreField: r0->field_7 = r1
    //     0xcd6990: stur            w1, [x0, #7]
    // 0xcd6994: ldur            x1, [fp, #-0x18]
    // 0xcd6998: StoreField: r0->field_b = r1
    //     0xcd6998: stur            w1, [x0, #0xb]
    // 0xcd699c: ldur            x1, [fp, #-0x20]
    // 0xcd69a0: LoadField: d0 = r1->field_7
    //     0xcd69a0: ldur            d0, [x1, #7]
    // 0xcd69a4: StoreField: r0->field_f = d0
    //     0xcd69a4: stur            d0, [x0, #0xf]
    // 0xcd69a8: LeaveFrame
    //     0xcd69a8: mov             SP, fp
    //     0xcd69ac: ldp             fp, lr, [SP], #0x10
    // 0xcd69b0: ret
    //     0xcd69b0: ret             
    // 0xcd69b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd69b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd69b8: b               #0xcd67d4
    // 0xcd69bc: SaveReg d0
    //     0xcd69bc: str             q0, [SP, #-0x10]!
    // 0xcd69c0: stp             x2, x3, [SP, #-0x10]!
    // 0xcd69c4: stp             x0, x1, [SP, #-0x10]!
    // 0xcd69c8: r0 = AllocateDouble()
    //     0xcd69c8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcd69cc: mov             x4, x0
    // 0xcd69d0: ldp             x0, x1, [SP], #0x10
    // 0xcd69d4: ldp             x2, x3, [SP], #0x10
    // 0xcd69d8: RestoreReg d0
    //     0xcd69d8: ldr             q0, [SP], #0x10
    // 0xcd69dc: b               #0xcd6814
    // 0xcd69e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd69e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd69e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd69e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd69e8: stp             q0, q1, [SP, #-0x20]!
    // 0xcd69ec: stp             x1, x2, [SP, #-0x10]!
    // 0xcd69f0: SaveReg r0
    //     0xcd69f0: str             x0, [SP, #-8]!
    // 0xcd69f4: r0 = AllocateDouble()
    //     0xcd69f4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcd69f8: mov             x3, x0
    // 0xcd69fc: RestoreReg r0
    //     0xcd69fc: ldr             x0, [SP], #8
    // 0xcd6a00: ldp             x1, x2, [SP], #0x10
    // 0xcd6a04: ldp             q0, q1, [SP], #0x20
    // 0xcd6a08: b               #0xcd68a4
    // 0xcd6a0c: SaveReg d1
    //     0xcd6a0c: str             q1, [SP, #-0x10]!
    // 0xcd6a10: stp             x2, x3, [SP, #-0x10]!
    // 0xcd6a14: stp             x0, x1, [SP, #-0x10]!
    // 0xcd6a18: r0 = AllocateDouble()
    //     0xcd6a18: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcd6a1c: mov             x4, x0
    // 0xcd6a20: ldp             x0, x1, [SP], #0x10
    // 0xcd6a24: ldp             x2, x3, [SP], #0x10
    // 0xcd6a28: RestoreReg d1
    //     0xcd6a28: ldr             q1, [SP], #0x10
    // 0xcd6a2c: b               #0xcd68cc
    // 0xcd6a30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd6a30: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd6a34: stp             q0, q1, [SP, #-0x20]!
    // 0xcd6a38: SaveReg r0
    //     0xcd6a38: str             x0, [SP, #-8]!
    // 0xcd6a3c: r0 = AllocateDouble()
    //     0xcd6a3c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcd6a40: mov             x1, x0
    // 0xcd6a44: RestoreReg r0
    //     0xcd6a44: ldr             x0, [SP], #8
    // 0xcd6a48: ldp             q0, q1, [SP], #0x20
    // 0xcd6a4c: b               #0xcd6924
    // 0xcd6a50: SaveReg d1
    //     0xcd6a50: str             q1, [SP, #-0x10]!
    // 0xcd6a54: stp             x0, x1, [SP, #-0x10]!
    // 0xcd6a58: r0 = AllocateDouble()
    //     0xcd6a58: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcd6a5c: mov             x2, x0
    // 0xcd6a60: ldp             x0, x1, [SP], #0x10
    // 0xcd6a64: RestoreReg d1
    //     0xcd6a64: ldr             q1, [SP], #0x10
    // 0xcd6a68: b               #0xcd694c
    // 0xcd6a6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd6a6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// lib: , url: package:flutter/src/painting/edge_insets.dart

// class id: 1049361, size: 0x8
class :: {
}

// class id: 2100, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class EdgeInsetsGeometry extends Object {

  _ along(/* No info */) {
    // ** addr: 0x6849ac, size: 0xe4
    // 0x6849ac: EnterFrame
    //     0x6849ac: stp             fp, lr, [SP, #-0x10]!
    //     0x6849b0: mov             fp, SP
    // 0x6849b4: ldr             x1, [fp, #0x10]
    // 0x6849b8: cmp             w1, NULL
    // 0x6849bc: b.eq            #0x684a60
    // 0x6849c0: LoadField: r2 = r1->field_7
    //     0x6849c0: ldur            x2, [x1, #7]
    // 0x6849c4: cmp             x2, #0
    // 0x6849c8: b.gt            #0x684a1c
    // 0x6849cc: ldr             x1, [fp, #0x18]
    // 0x6849d0: d0 = 0.000000
    //     0x6849d0: eor             v0.16b, v0.16b, v0.16b
    // 0x6849d4: LoadField: d1 = r1->field_7
    //     0x6849d4: ldur            d1, [x1, #7]
    // 0x6849d8: LoadField: d2 = r1->field_17
    //     0x6849d8: ldur            d2, [x1, #0x17]
    // 0x6849dc: fadd            d3, d1, d2
    // 0x6849e0: fadd            d1, d3, d0
    // 0x6849e4: fadd            d2, d1, d0
    // 0x6849e8: r0 = inline_Allocate_Double()
    //     0x6849e8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x6849ec: add             x0, x0, #0x10
    //     0x6849f0: cmp             x2, x0
    //     0x6849f4: b.ls            #0x684a70
    //     0x6849f8: str             x0, [THR, #0x60]  ; THR::top
    //     0x6849fc: sub             x0, x0, #0xf
    //     0x684a00: mov             x2, #0xd108
    //     0x684a04: movk            x2, #3, lsl #16
    //     0x684a08: stur            x2, [x0, #-1]
    // 0x684a0c: StoreField: r0->field_7 = d2
    //     0x684a0c: stur            d2, [x0, #7]
    // 0x684a10: LeaveFrame
    //     0x684a10: mov             SP, fp
    //     0x684a14: ldp             fp, lr, [SP], #0x10
    // 0x684a18: ret
    //     0x684a18: ret             
    // 0x684a1c: ldr             x1, [fp, #0x18]
    // 0x684a20: LoadField: d0 = r1->field_f
    //     0x684a20: ldur            d0, [x1, #0xf]
    // 0x684a24: LoadField: d1 = r1->field_1f
    //     0x684a24: ldur            d1, [x1, #0x1f]
    // 0x684a28: fadd            d2, d0, d1
    // 0x684a2c: r0 = inline_Allocate_Double()
    //     0x684a2c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x684a30: add             x0, x0, #0x10
    //     0x684a34: cmp             x1, x0
    //     0x684a38: b.ls            #0x684a80
    //     0x684a3c: str             x0, [THR, #0x60]  ; THR::top
    //     0x684a40: sub             x0, x0, #0xf
    //     0x684a44: mov             x1, #0xd108
    //     0x684a48: movk            x1, #3, lsl #16
    //     0x684a4c: stur            x1, [x0, #-1]
    // 0x684a50: StoreField: r0->field_7 = d2
    //     0x684a50: stur            d2, [x0, #7]
    // 0x684a54: LeaveFrame
    //     0x684a54: mov             SP, fp
    //     0x684a58: ldp             fp, lr, [SP], #0x10
    // 0x684a5c: ret
    //     0x684a5c: ret             
    // 0x684a60: r0 = Null
    //     0x684a60: mov             x0, NULL
    // 0x684a64: LeaveFrame
    //     0x684a64: mov             SP, fp
    //     0x684a68: ldp             fp, lr, [SP], #0x10
    // 0x684a6c: ret
    //     0x684a6c: ret             
    // 0x684a70: SaveReg d2
    //     0x684a70: str             q2, [SP, #-0x10]!
    // 0x684a74: r0 = AllocateDouble()
    //     0x684a74: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x684a78: RestoreReg d2
    //     0x684a78: ldr             q2, [SP], #0x10
    // 0x684a7c: b               #0x684a0c
    // 0x684a80: SaveReg d2
    //     0x684a80: str             q2, [SP, #-0x10]!
    // 0x684a84: r0 = AllocateDouble()
    //     0x684a84: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x684a88: RestoreReg d2
    //     0x684a88: ldr             q2, [SP], #0x10
    // 0x684a8c: b               #0x684a50
  }
  get _ vertical(/* No info */) {
    // ** addr: 0x6931b0, size: 0x14
    // 0x6931b0: ldr             x0, [SP]
    // 0x6931b4: LoadField: d1 = r0->field_f
    //     0x6931b4: ldur            d1, [x0, #0xf]
    // 0x6931b8: LoadField: d2 = r0->field_1f
    //     0x6931b8: ldur            d2, [x0, #0x1f]
    // 0x6931bc: fadd            d0, d1, d2
    // 0x6931c0: ret
    //     0x6931c0: ret             
  }
  get _ horizontal(/* No info */) {
    // ** addr: 0x6931c4, size: 0x20
    // 0x6931c4: d1 = 0.000000
    //     0x6931c4: eor             v1.16b, v1.16b, v1.16b
    // 0x6931c8: ldr             x0, [SP]
    // 0x6931cc: LoadField: d2 = r0->field_7
    //     0x6931cc: ldur            d2, [x0, #7]
    // 0x6931d0: LoadField: d3 = r0->field_17
    //     0x6931d0: ldur            d3, [x0, #0x17]
    // 0x6931d4: fadd            d4, d2, d3
    // 0x6931d8: fadd            d2, d4, d1
    // 0x6931dc: fadd            d0, d2, d1
    // 0x6931e0: ret
    //     0x6931e0: ret             
  }
  get _ collapsedSize(/* No info */) {
    // ** addr: 0xa6e628, size: 0x5c
    // 0xa6e628: EnterFrame
    //     0xa6e628: stp             fp, lr, [SP, #-0x10]!
    //     0xa6e62c: mov             fp, SP
    // 0xa6e630: AllocStack(0x10)
    //     0xa6e630: sub             SP, SP, #0x10
    // 0xa6e634: d0 = 0.000000
    //     0xa6e634: eor             v0.16b, v0.16b, v0.16b
    // 0xa6e638: ldr             x0, [fp, #0x10]
    // 0xa6e63c: LoadField: d1 = r0->field_7
    //     0xa6e63c: ldur            d1, [x0, #7]
    // 0xa6e640: LoadField: d2 = r0->field_17
    //     0xa6e640: ldur            d2, [x0, #0x17]
    // 0xa6e644: fadd            d3, d1, d2
    // 0xa6e648: fadd            d1, d3, d0
    // 0xa6e64c: fadd            d2, d1, d0
    // 0xa6e650: stur            d2, [fp, #-0x10]
    // 0xa6e654: LoadField: d0 = r0->field_f
    //     0xa6e654: ldur            d0, [x0, #0xf]
    // 0xa6e658: LoadField: d1 = r0->field_1f
    //     0xa6e658: ldur            d1, [x0, #0x1f]
    // 0xa6e65c: fadd            d3, d0, d1
    // 0xa6e660: stur            d3, [fp, #-8]
    // 0xa6e664: r0 = Size()
    //     0xa6e664: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xa6e668: ldur            d0, [fp, #-0x10]
    // 0xa6e66c: StoreField: r0->field_7 = d0
    //     0xa6e66c: stur            d0, [x0, #7]
    // 0xa6e670: ldur            d0, [fp, #-8]
    // 0xa6e674: StoreField: r0->field_f = d0
    //     0xa6e674: stur            d0, [x0, #0xf]
    // 0xa6e678: LeaveFrame
    //     0xa6e678: mov             SP, fp
    //     0xa6e67c: ldp             fp, lr, [SP], #0x10
    // 0xa6e680: ret
    //     0xa6e680: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0xae128c, size: 0xff0
    // 0xae128c: EnterFrame
    //     0xae128c: stp             fp, lr, [SP, #-0x10]!
    //     0xae1290: mov             fp, SP
    // 0xae1294: AllocStack(0x10)
    //     0xae1294: sub             SP, SP, #0x10
    // 0xae1298: CheckStackOverflow
    //     0xae1298: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae129c: cmp             SP, x16
    //     0xae12a0: b.ls            #0xae2080
    // 0xae12a4: ldr             x0, [fp, #0x10]
    // 0xae12a8: r3 = LoadClassIdInstr(r0)
    //     0xae12a8: ldur            x3, [x0, #-1]
    //     0xae12ac: ubfx            x3, x3, #0xc, #0x14
    // 0xae12b0: lsl             x3, x3, #1
    // 0xae12b4: stur            x3, [fp, #-8]
    // 0xae12b8: r17 = 4202
    //     0xae12b8: mov             x17, #0x106a
    // 0xae12bc: cmp             w3, w17
    // 0xae12c0: b.ne            #0xae12d0
    // 0xae12c4: LoadField: d0 = r0->field_17
    //     0xae12c4: ldur            d0, [x0, #0x17]
    // 0xae12c8: mov             v1.16b, v0.16b
    // 0xae12cc: b               #0xae12ec
    // 0xae12d0: r17 = 4204
    //     0xae12d0: mov             x17, #0x106c
    // 0xae12d4: cmp             w3, w17
    // 0xae12d8: b.ne            #0xae12e8
    // 0xae12dc: LoadField: d0 = r0->field_7
    //     0xae12dc: ldur            d0, [x0, #7]
    // 0xae12e0: mov             v1.16b, v0.16b
    // 0xae12e4: b               #0xae12ec
    // 0xae12e8: d1 = 0.000000
    //     0xae12e8: eor             v1.16b, v1.16b, v1.16b
    // 0xae12ec: d0 = 0.000000
    //     0xae12ec: eor             v0.16b, v0.16b, v0.16b
    // 0xae12f0: fcmp            d1, d0
    // 0xae12f4: b.vs            #0xae1924
    // 0xae12f8: b.ne            #0xae1924
    // 0xae12fc: r17 = 4202
    //     0xae12fc: mov             x17, #0x106a
    // 0xae1300: cmp             w3, w17
    // 0xae1304: b.ne            #0xae1310
    // 0xae1308: LoadField: d1 = r0->field_1f
    //     0xae1308: ldur            d1, [x0, #0x1f]
    // 0xae130c: b               #0xae1328
    // 0xae1310: r17 = 4204
    //     0xae1310: mov             x17, #0x106c
    // 0xae1314: cmp             w3, w17
    // 0xae1318: b.ne            #0xae1324
    // 0xae131c: LoadField: d1 = r0->field_17
    //     0xae131c: ldur            d1, [x0, #0x17]
    // 0xae1320: b               #0xae1328
    // 0xae1324: d1 = 0.000000
    //     0xae1324: eor             v1.16b, v1.16b, v1.16b
    // 0xae1328: fcmp            d1, d0
    // 0xae132c: b.vs            #0xae1910
    // 0xae1330: b.ne            #0xae1910
    // 0xae1334: r17 = 4202
    //     0xae1334: mov             x17, #0x106a
    // 0xae1338: cmp             w3, w17
    // 0xae133c: b.ne            #0xae1348
    // 0xae1340: LoadField: d1 = r0->field_7
    //     0xae1340: ldur            d1, [x0, #7]
    // 0xae1344: b               #0xae1360
    // 0xae1348: r17 = 4204
    //     0xae1348: mov             x17, #0x106c
    // 0xae134c: cmp             w3, w17
    // 0xae1350: b.ne            #0xae135c
    // 0xae1354: d1 = 0.000000
    //     0xae1354: eor             v1.16b, v1.16b, v1.16b
    // 0xae1358: b               #0xae1360
    // 0xae135c: LoadField: d1 = r0->field_7
    //     0xae135c: ldur            d1, [x0, #7]
    // 0xae1360: fcmp            d1, d0
    // 0xae1364: b.vs            #0xae1428
    // 0xae1368: b.ne            #0xae1428
    // 0xae136c: r17 = 4202
    //     0xae136c: mov             x17, #0x106a
    // 0xae1370: cmp             w3, w17
    // 0xae1374: b.ne            #0xae1380
    // 0xae1378: LoadField: d1 = r0->field_f
    //     0xae1378: ldur            d1, [x0, #0xf]
    // 0xae137c: b               #0xae1398
    // 0xae1380: r17 = 4204
    //     0xae1380: mov             x17, #0x106c
    // 0xae1384: cmp             w3, w17
    // 0xae1388: b.ne            #0xae1394
    // 0xae138c: d1 = 0.000000
    //     0xae138c: eor             v1.16b, v1.16b, v1.16b
    // 0xae1390: b               #0xae1398
    // 0xae1394: LoadField: d1 = r0->field_17
    //     0xae1394: ldur            d1, [x0, #0x17]
    // 0xae1398: fcmp            d1, d0
    // 0xae139c: b.vs            #0xae1428
    // 0xae13a0: b.ne            #0xae1428
    // 0xae13a4: r17 = 4202
    //     0xae13a4: mov             x17, #0x106a
    // 0xae13a8: cmp             w3, w17
    // 0xae13ac: b.ne            #0xae13b8
    // 0xae13b0: LoadField: d1 = r0->field_27
    //     0xae13b0: ldur            d1, [x0, #0x27]
    // 0xae13b4: b               #0xae13d0
    // 0xae13b8: r17 = 4204
    //     0xae13b8: mov             x17, #0x106c
    // 0xae13bc: cmp             w3, w17
    // 0xae13c0: b.ne            #0xae13cc
    // 0xae13c4: LoadField: d1 = r0->field_f
    //     0xae13c4: ldur            d1, [x0, #0xf]
    // 0xae13c8: b               #0xae13d0
    // 0xae13cc: LoadField: d1 = r0->field_f
    //     0xae13cc: ldur            d1, [x0, #0xf]
    // 0xae13d0: fcmp            d1, d0
    // 0xae13d4: b.vs            #0xae1428
    // 0xae13d8: b.ne            #0xae1428
    // 0xae13dc: r17 = 4202
    //     0xae13dc: mov             x17, #0x106a
    // 0xae13e0: cmp             w3, w17
    // 0xae13e4: b.ne            #0xae13f0
    // 0xae13e8: LoadField: d1 = r0->field_2f
    //     0xae13e8: ldur            d1, [x0, #0x2f]
    // 0xae13ec: b               #0xae1408
    // 0xae13f0: r17 = 4204
    //     0xae13f0: mov             x17, #0x106c
    // 0xae13f4: cmp             w3, w17
    // 0xae13f8: b.ne            #0xae1404
    // 0xae13fc: LoadField: d1 = r0->field_1f
    //     0xae13fc: ldur            d1, [x0, #0x1f]
    // 0xae1400: b               #0xae1408
    // 0xae1404: LoadField: d1 = r0->field_1f
    //     0xae1404: ldur            d1, [x0, #0x1f]
    // 0xae1408: fcmp            d1, d0
    // 0xae140c: b.vs            #0xae1428
    // 0xae1410: b.ne            #0xae1428
    // 0xae1414: r0 = "EdgeInsets.zero"
    //     0xae1414: add             x0, PP, #0xc, lsl #12  ; [pp+0xc760] "EdgeInsets.zero"
    //     0xae1418: ldr             x0, [x0, #0x760]
    // 0xae141c: LeaveFrame
    //     0xae141c: mov             SP, fp
    //     0xae1420: ldp             fp, lr, [SP], #0x10
    // 0xae1424: ret
    //     0xae1424: ret             
    // 0xae1428: r17 = 4202
    //     0xae1428: mov             x17, #0x106a
    // 0xae142c: cmp             w3, w17
    // 0xae1430: b.ne            #0xae143c
    // 0xae1434: LoadField: d0 = r0->field_7
    //     0xae1434: ldur            d0, [x0, #7]
    // 0xae1438: b               #0xae1454
    // 0xae143c: r17 = 4204
    //     0xae143c: mov             x17, #0x106c
    // 0xae1440: cmp             w3, w17
    // 0xae1444: b.ne            #0xae1450
    // 0xae1448: d0 = 0.000000
    //     0xae1448: eor             v0.16b, v0.16b, v0.16b
    // 0xae144c: b               #0xae1454
    // 0xae1450: LoadField: d0 = r0->field_7
    //     0xae1450: ldur            d0, [x0, #7]
    // 0xae1454: r17 = 4202
    //     0xae1454: mov             x17, #0x106a
    // 0xae1458: cmp             w3, w17
    // 0xae145c: b.ne            #0xae1468
    // 0xae1460: LoadField: d1 = r0->field_f
    //     0xae1460: ldur            d1, [x0, #0xf]
    // 0xae1464: b               #0xae1480
    // 0xae1468: r17 = 4204
    //     0xae1468: mov             x17, #0x106c
    // 0xae146c: cmp             w3, w17
    // 0xae1470: b.ne            #0xae147c
    // 0xae1474: d1 = 0.000000
    //     0xae1474: eor             v1.16b, v1.16b, v1.16b
    // 0xae1478: b               #0xae1480
    // 0xae147c: LoadField: d1 = r0->field_17
    //     0xae147c: ldur            d1, [x0, #0x17]
    // 0xae1480: fcmp            d0, d1
    // 0xae1484: b.vs            #0xae1644
    // 0xae1488: b.ne            #0xae1644
    // 0xae148c: r17 = 4202
    //     0xae148c: mov             x17, #0x106a
    // 0xae1490: cmp             w3, w17
    // 0xae1494: b.ne            #0xae14a0
    // 0xae1498: LoadField: d0 = r0->field_f
    //     0xae1498: ldur            d0, [x0, #0xf]
    // 0xae149c: b               #0xae14b8
    // 0xae14a0: r17 = 4204
    //     0xae14a0: mov             x17, #0x106c
    // 0xae14a4: cmp             w3, w17
    // 0xae14a8: b.ne            #0xae14b4
    // 0xae14ac: d0 = 0.000000
    //     0xae14ac: eor             v0.16b, v0.16b, v0.16b
    // 0xae14b0: b               #0xae14b8
    // 0xae14b4: LoadField: d0 = r0->field_17
    //     0xae14b4: ldur            d0, [x0, #0x17]
    // 0xae14b8: r17 = 4202
    //     0xae14b8: mov             x17, #0x106a
    // 0xae14bc: cmp             w3, w17
    // 0xae14c0: b.ne            #0xae14cc
    // 0xae14c4: LoadField: d1 = r0->field_27
    //     0xae14c4: ldur            d1, [x0, #0x27]
    // 0xae14c8: b               #0xae14e4
    // 0xae14cc: r17 = 4204
    //     0xae14cc: mov             x17, #0x106c
    // 0xae14d0: cmp             w3, w17
    // 0xae14d4: b.ne            #0xae14e0
    // 0xae14d8: LoadField: d1 = r0->field_f
    //     0xae14d8: ldur            d1, [x0, #0xf]
    // 0xae14dc: b               #0xae14e4
    // 0xae14e0: LoadField: d1 = r0->field_f
    //     0xae14e0: ldur            d1, [x0, #0xf]
    // 0xae14e4: fcmp            d0, d1
    // 0xae14e8: b.vs            #0xae1638
    // 0xae14ec: b.ne            #0xae1638
    // 0xae14f0: r17 = 4202
    //     0xae14f0: mov             x17, #0x106a
    // 0xae14f4: cmp             w3, w17
    // 0xae14f8: b.ne            #0xae1504
    // 0xae14fc: LoadField: d0 = r0->field_27
    //     0xae14fc: ldur            d0, [x0, #0x27]
    // 0xae1500: b               #0xae151c
    // 0xae1504: r17 = 4204
    //     0xae1504: mov             x17, #0x106c
    // 0xae1508: cmp             w3, w17
    // 0xae150c: b.ne            #0xae1518
    // 0xae1510: LoadField: d0 = r0->field_f
    //     0xae1510: ldur            d0, [x0, #0xf]
    // 0xae1514: b               #0xae151c
    // 0xae1518: LoadField: d0 = r0->field_f
    //     0xae1518: ldur            d0, [x0, #0xf]
    // 0xae151c: r17 = 4202
    //     0xae151c: mov             x17, #0x106a
    // 0xae1520: cmp             w3, w17
    // 0xae1524: b.ne            #0xae1530
    // 0xae1528: LoadField: d1 = r0->field_2f
    //     0xae1528: ldur            d1, [x0, #0x2f]
    // 0xae152c: b               #0xae1548
    // 0xae1530: r17 = 4204
    //     0xae1530: mov             x17, #0x106c
    // 0xae1534: cmp             w3, w17
    // 0xae1538: b.ne            #0xae1544
    // 0xae153c: LoadField: d1 = r0->field_1f
    //     0xae153c: ldur            d1, [x0, #0x1f]
    // 0xae1540: b               #0xae1548
    // 0xae1544: LoadField: d1 = r0->field_1f
    //     0xae1544: ldur            d1, [x0, #0x1f]
    // 0xae1548: fcmp            d0, d1
    // 0xae154c: b.vs            #0xae162c
    // 0xae1550: b.ne            #0xae162c
    // 0xae1554: r1 = Null
    //     0xae1554: mov             x1, NULL
    // 0xae1558: r2 = 6
    //     0xae1558: mov             x2, #6
    // 0xae155c: r0 = AllocateArray()
    //     0xae155c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae1560: stur            x0, [fp, #-0x10]
    // 0xae1564: r17 = "EdgeInsets.all("
    //     0xae1564: add             x17, PP, #0xc, lsl #12  ; [pp+0xc768] "EdgeInsets.all("
    //     0xae1568: ldr             x17, [x17, #0x768]
    // 0xae156c: StoreField: r0->field_f = r17
    //     0xae156c: stur            w17, [x0, #0xf]
    // 0xae1570: ldur            x3, [fp, #-8]
    // 0xae1574: r17 = 4202
    //     0xae1574: mov             x17, #0x106a
    // 0xae1578: cmp             w3, w17
    // 0xae157c: b.ne            #0xae158c
    // 0xae1580: ldr             x4, [fp, #0x10]
    // 0xae1584: LoadField: d0 = r4->field_7
    //     0xae1584: ldur            d0, [x4, #7]
    // 0xae1588: b               #0xae15a8
    // 0xae158c: ldr             x4, [fp, #0x10]
    // 0xae1590: r17 = 4204
    //     0xae1590: mov             x17, #0x106c
    // 0xae1594: cmp             w3, w17
    // 0xae1598: b.ne            #0xae15a4
    // 0xae159c: d0 = 0.000000
    //     0xae159c: eor             v0.16b, v0.16b, v0.16b
    // 0xae15a0: b               #0xae15a8
    // 0xae15a4: LoadField: d0 = r4->field_7
    //     0xae15a4: ldur            d0, [x4, #7]
    // 0xae15a8: r5 = 1
    //     0xae15a8: mov             x5, #1
    // 0xae15ac: r1 = inline_Allocate_Double()
    //     0xae15ac: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xae15b0: add             x1, x1, #0x10
    //     0xae15b4: cmp             x2, x1
    //     0xae15b8: b.ls            #0xae2088
    //     0xae15bc: str             x1, [THR, #0x60]  ; THR::top
    //     0xae15c0: sub             x1, x1, #0xf
    //     0xae15c4: mov             x2, #0xd108
    //     0xae15c8: movk            x2, #3, lsl #16
    //     0xae15cc: stur            x2, [x1, #-1]
    // 0xae15d0: StoreField: r1->field_7 = d0
    //     0xae15d0: stur            d0, [x1, #7]
    // 0xae15d4: stp             x5, x1, [SP, #-0x10]!
    // 0xae15d8: r0 = toStringAsFixed()
    //     0xae15d8: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae15dc: add             SP, SP, #0x10
    // 0xae15e0: ldur            x1, [fp, #-0x10]
    // 0xae15e4: ArrayStore: r1[1] = r0  ; List_4
    //     0xae15e4: add             x25, x1, #0x13
    //     0xae15e8: str             w0, [x25]
    //     0xae15ec: tbz             w0, #0, #0xae1608
    //     0xae15f0: ldurb           w16, [x1, #-1]
    //     0xae15f4: ldurb           w17, [x0, #-1]
    //     0xae15f8: and             x16, x17, x16, lsr #2
    //     0xae15fc: tst             x16, HEAP, lsr #32
    //     0xae1600: b.eq            #0xae1608
    //     0xae1604: bl              #0xd67e5c
    // 0xae1608: ldur            x0, [fp, #-0x10]
    // 0xae160c: r17 = ")"
    //     0xae160c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae1610: StoreField: r0->field_17 = r17
    //     0xae1610: stur            w17, [x0, #0x17]
    // 0xae1614: SaveReg r0
    //     0xae1614: str             x0, [SP, #-8]!
    // 0xae1618: r0 = _interpolate()
    //     0xae1618: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae161c: add             SP, SP, #8
    // 0xae1620: LeaveFrame
    //     0xae1620: mov             SP, fp
    //     0xae1624: ldp             fp, lr, [SP], #0x10
    // 0xae1628: ret
    //     0xae1628: ret             
    // 0xae162c: mov             x4, x0
    // 0xae1630: r5 = 1
    //     0xae1630: mov             x5, #1
    // 0xae1634: b               #0xae164c
    // 0xae1638: mov             x4, x0
    // 0xae163c: r5 = 1
    //     0xae163c: mov             x5, #1
    // 0xae1640: b               #0xae164c
    // 0xae1644: mov             x4, x0
    // 0xae1648: r5 = 1
    //     0xae1648: mov             x5, #1
    // 0xae164c: r1 = Null
    //     0xae164c: mov             x1, NULL
    // 0xae1650: r2 = 18
    //     0xae1650: mov             x2, #0x12
    // 0xae1654: r0 = AllocateArray()
    //     0xae1654: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae1658: stur            x0, [fp, #-0x10]
    // 0xae165c: r17 = "EdgeInsets("
    //     0xae165c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc770] "EdgeInsets("
    //     0xae1660: ldr             x17, [x17, #0x770]
    // 0xae1664: StoreField: r0->field_f = r17
    //     0xae1664: stur            w17, [x0, #0xf]
    // 0xae1668: ldur            x1, [fp, #-8]
    // 0xae166c: r17 = 4202
    //     0xae166c: mov             x17, #0x106a
    // 0xae1670: cmp             w1, w17
    // 0xae1674: b.ne            #0xae1684
    // 0xae1678: ldr             x2, [fp, #0x10]
    // 0xae167c: LoadField: d0 = r2->field_7
    //     0xae167c: ldur            d0, [x2, #7]
    // 0xae1680: b               #0xae16a0
    // 0xae1684: ldr             x2, [fp, #0x10]
    // 0xae1688: r17 = 4204
    //     0xae1688: mov             x17, #0x106c
    // 0xae168c: cmp             w1, w17
    // 0xae1690: b.ne            #0xae169c
    // 0xae1694: d0 = 0.000000
    //     0xae1694: eor             v0.16b, v0.16b, v0.16b
    // 0xae1698: b               #0xae16a0
    // 0xae169c: LoadField: d0 = r2->field_7
    //     0xae169c: ldur            d0, [x2, #7]
    // 0xae16a0: r3 = 1
    //     0xae16a0: mov             x3, #1
    // 0xae16a4: r4 = inline_Allocate_Double()
    //     0xae16a4: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xae16a8: add             x4, x4, #0x10
    //     0xae16ac: cmp             x5, x4
    //     0xae16b0: b.ls            #0xae20a4
    //     0xae16b4: str             x4, [THR, #0x60]  ; THR::top
    //     0xae16b8: sub             x4, x4, #0xf
    //     0xae16bc: mov             x5, #0xd108
    //     0xae16c0: movk            x5, #3, lsl #16
    //     0xae16c4: stur            x5, [x4, #-1]
    // 0xae16c8: StoreField: r4->field_7 = d0
    //     0xae16c8: stur            d0, [x4, #7]
    // 0xae16cc: stp             x3, x4, [SP, #-0x10]!
    // 0xae16d0: r0 = toStringAsFixed()
    //     0xae16d0: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae16d4: add             SP, SP, #0x10
    // 0xae16d8: ldur            x1, [fp, #-0x10]
    // 0xae16dc: ArrayStore: r1[1] = r0  ; List_4
    //     0xae16dc: add             x25, x1, #0x13
    //     0xae16e0: str             w0, [x25]
    //     0xae16e4: tbz             w0, #0, #0xae1700
    //     0xae16e8: ldurb           w16, [x1, #-1]
    //     0xae16ec: ldurb           w17, [x0, #-1]
    //     0xae16f0: and             x16, x17, x16, lsr #2
    //     0xae16f4: tst             x16, HEAP, lsr #32
    //     0xae16f8: b.eq            #0xae1700
    //     0xae16fc: bl              #0xd67e5c
    // 0xae1700: ldur            x1, [fp, #-0x10]
    // 0xae1704: r17 = ", "
    //     0xae1704: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae1708: StoreField: r1->field_17 = r17
    //     0xae1708: stur            w17, [x1, #0x17]
    // 0xae170c: ldur            x0, [fp, #-8]
    // 0xae1710: r17 = 4202
    //     0xae1710: mov             x17, #0x106a
    // 0xae1714: cmp             w0, w17
    // 0xae1718: b.ne            #0xae1728
    // 0xae171c: ldr             x2, [fp, #0x10]
    // 0xae1720: LoadField: d0 = r2->field_27
    //     0xae1720: ldur            d0, [x2, #0x27]
    // 0xae1724: b               #0xae1744
    // 0xae1728: ldr             x2, [fp, #0x10]
    // 0xae172c: r17 = 4204
    //     0xae172c: mov             x17, #0x106c
    // 0xae1730: cmp             w0, w17
    // 0xae1734: b.ne            #0xae1740
    // 0xae1738: LoadField: d0 = r2->field_f
    //     0xae1738: ldur            d0, [x2, #0xf]
    // 0xae173c: b               #0xae1744
    // 0xae1740: LoadField: d0 = r2->field_f
    //     0xae1740: ldur            d0, [x2, #0xf]
    // 0xae1744: r3 = 1
    //     0xae1744: mov             x3, #1
    // 0xae1748: r4 = inline_Allocate_Double()
    //     0xae1748: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xae174c: add             x4, x4, #0x10
    //     0xae1750: cmp             x5, x4
    //     0xae1754: b.ls            #0xae20c8
    //     0xae1758: str             x4, [THR, #0x60]  ; THR::top
    //     0xae175c: sub             x4, x4, #0xf
    //     0xae1760: mov             x5, #0xd108
    //     0xae1764: movk            x5, #3, lsl #16
    //     0xae1768: stur            x5, [x4, #-1]
    // 0xae176c: StoreField: r4->field_7 = d0
    //     0xae176c: stur            d0, [x4, #7]
    // 0xae1770: stp             x3, x4, [SP, #-0x10]!
    // 0xae1774: r0 = toStringAsFixed()
    //     0xae1774: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae1778: add             SP, SP, #0x10
    // 0xae177c: ldur            x1, [fp, #-0x10]
    // 0xae1780: ArrayStore: r1[3] = r0  ; List_4
    //     0xae1780: add             x25, x1, #0x1b
    //     0xae1784: str             w0, [x25]
    //     0xae1788: tbz             w0, #0, #0xae17a4
    //     0xae178c: ldurb           w16, [x1, #-1]
    //     0xae1790: ldurb           w17, [x0, #-1]
    //     0xae1794: and             x16, x17, x16, lsr #2
    //     0xae1798: tst             x16, HEAP, lsr #32
    //     0xae179c: b.eq            #0xae17a4
    //     0xae17a0: bl              #0xd67e5c
    // 0xae17a4: ldur            x1, [fp, #-0x10]
    // 0xae17a8: r17 = ", "
    //     0xae17a8: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae17ac: StoreField: r1->field_1f = r17
    //     0xae17ac: stur            w17, [x1, #0x1f]
    // 0xae17b0: ldur            x0, [fp, #-8]
    // 0xae17b4: r17 = 4202
    //     0xae17b4: mov             x17, #0x106a
    // 0xae17b8: cmp             w0, w17
    // 0xae17bc: b.ne            #0xae17cc
    // 0xae17c0: ldr             x2, [fp, #0x10]
    // 0xae17c4: LoadField: d0 = r2->field_f
    //     0xae17c4: ldur            d0, [x2, #0xf]
    // 0xae17c8: b               #0xae17e8
    // 0xae17cc: ldr             x2, [fp, #0x10]
    // 0xae17d0: r17 = 4204
    //     0xae17d0: mov             x17, #0x106c
    // 0xae17d4: cmp             w0, w17
    // 0xae17d8: b.ne            #0xae17e4
    // 0xae17dc: d0 = 0.000000
    //     0xae17dc: eor             v0.16b, v0.16b, v0.16b
    // 0xae17e0: b               #0xae17e8
    // 0xae17e4: LoadField: d0 = r2->field_17
    //     0xae17e4: ldur            d0, [x2, #0x17]
    // 0xae17e8: r3 = 1
    //     0xae17e8: mov             x3, #1
    // 0xae17ec: r4 = inline_Allocate_Double()
    //     0xae17ec: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xae17f0: add             x4, x4, #0x10
    //     0xae17f4: cmp             x5, x4
    //     0xae17f8: b.ls            #0xae20ec
    //     0xae17fc: str             x4, [THR, #0x60]  ; THR::top
    //     0xae1800: sub             x4, x4, #0xf
    //     0xae1804: mov             x5, #0xd108
    //     0xae1808: movk            x5, #3, lsl #16
    //     0xae180c: stur            x5, [x4, #-1]
    // 0xae1810: StoreField: r4->field_7 = d0
    //     0xae1810: stur            d0, [x4, #7]
    // 0xae1814: stp             x3, x4, [SP, #-0x10]!
    // 0xae1818: r0 = toStringAsFixed()
    //     0xae1818: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae181c: add             SP, SP, #0x10
    // 0xae1820: ldur            x1, [fp, #-0x10]
    // 0xae1824: ArrayStore: r1[5] = r0  ; List_4
    //     0xae1824: add             x25, x1, #0x23
    //     0xae1828: str             w0, [x25]
    //     0xae182c: tbz             w0, #0, #0xae1848
    //     0xae1830: ldurb           w16, [x1, #-1]
    //     0xae1834: ldurb           w17, [x0, #-1]
    //     0xae1838: and             x16, x17, x16, lsr #2
    //     0xae183c: tst             x16, HEAP, lsr #32
    //     0xae1840: b.eq            #0xae1848
    //     0xae1844: bl              #0xd67e5c
    // 0xae1848: ldur            x1, [fp, #-0x10]
    // 0xae184c: r17 = ", "
    //     0xae184c: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae1850: StoreField: r1->field_27 = r17
    //     0xae1850: stur            w17, [x1, #0x27]
    // 0xae1854: ldur            x0, [fp, #-8]
    // 0xae1858: r17 = 4202
    //     0xae1858: mov             x17, #0x106a
    // 0xae185c: cmp             w0, w17
    // 0xae1860: b.ne            #0xae1870
    // 0xae1864: ldr             x3, [fp, #0x10]
    // 0xae1868: LoadField: d0 = r3->field_2f
    //     0xae1868: ldur            d0, [x3, #0x2f]
    // 0xae186c: b               #0xae188c
    // 0xae1870: ldr             x3, [fp, #0x10]
    // 0xae1874: r17 = 4204
    //     0xae1874: mov             x17, #0x106c
    // 0xae1878: cmp             w0, w17
    // 0xae187c: b.ne            #0xae1888
    // 0xae1880: LoadField: d0 = r3->field_1f
    //     0xae1880: ldur            d0, [x3, #0x1f]
    // 0xae1884: b               #0xae188c
    // 0xae1888: LoadField: d0 = r3->field_1f
    //     0xae1888: ldur            d0, [x3, #0x1f]
    // 0xae188c: r4 = 1
    //     0xae188c: mov             x4, #1
    // 0xae1890: r0 = inline_Allocate_Double()
    //     0xae1890: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xae1894: add             x0, x0, #0x10
    //     0xae1898: cmp             x2, x0
    //     0xae189c: b.ls            #0xae2110
    //     0xae18a0: str             x0, [THR, #0x60]  ; THR::top
    //     0xae18a4: sub             x0, x0, #0xf
    //     0xae18a8: mov             x2, #0xd108
    //     0xae18ac: movk            x2, #3, lsl #16
    //     0xae18b0: stur            x2, [x0, #-1]
    // 0xae18b4: StoreField: r0->field_7 = d0
    //     0xae18b4: stur            d0, [x0, #7]
    // 0xae18b8: stp             x4, x0, [SP, #-0x10]!
    // 0xae18bc: r0 = toStringAsFixed()
    //     0xae18bc: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae18c0: add             SP, SP, #0x10
    // 0xae18c4: ldur            x1, [fp, #-0x10]
    // 0xae18c8: ArrayStore: r1[7] = r0  ; List_4
    //     0xae18c8: add             x25, x1, #0x2b
    //     0xae18cc: str             w0, [x25]
    //     0xae18d0: tbz             w0, #0, #0xae18ec
    //     0xae18d4: ldurb           w16, [x1, #-1]
    //     0xae18d8: ldurb           w17, [x0, #-1]
    //     0xae18dc: and             x16, x17, x16, lsr #2
    //     0xae18e0: tst             x16, HEAP, lsr #32
    //     0xae18e4: b.eq            #0xae18ec
    //     0xae18e8: bl              #0xd67e5c
    // 0xae18ec: ldur            x0, [fp, #-0x10]
    // 0xae18f0: r17 = ")"
    //     0xae18f0: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae18f4: StoreField: r0->field_2f = r17
    //     0xae18f4: stur            w17, [x0, #0x2f]
    // 0xae18f8: SaveReg r0
    //     0xae18f8: str             x0, [SP, #-8]!
    // 0xae18fc: r0 = _interpolate()
    //     0xae18fc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae1900: add             SP, SP, #8
    // 0xae1904: LeaveFrame
    //     0xae1904: mov             SP, fp
    //     0xae1908: ldp             fp, lr, [SP], #0x10
    // 0xae190c: ret
    //     0xae190c: ret             
    // 0xae1910: mov             x16, x3
    // 0xae1914: mov             x3, x0
    // 0xae1918: mov             x0, x16
    // 0xae191c: r4 = 1
    //     0xae191c: mov             x4, #1
    // 0xae1920: b               #0xae1934
    // 0xae1924: mov             x16, x3
    // 0xae1928: mov             x3, x0
    // 0xae192c: mov             x0, x16
    // 0xae1930: r4 = 1
    //     0xae1930: mov             x4, #1
    // 0xae1934: r17 = 4202
    //     0xae1934: mov             x17, #0x106a
    // 0xae1938: cmp             w0, w17
    // 0xae193c: b.ne            #0xae1948
    // 0xae1940: LoadField: d1 = r3->field_7
    //     0xae1940: ldur            d1, [x3, #7]
    // 0xae1944: b               #0xae1960
    // 0xae1948: r17 = 4204
    //     0xae1948: mov             x17, #0x106c
    // 0xae194c: cmp             w0, w17
    // 0xae1950: b.ne            #0xae195c
    // 0xae1954: d1 = 0.000000
    //     0xae1954: eor             v1.16b, v1.16b, v1.16b
    // 0xae1958: b               #0xae1960
    // 0xae195c: LoadField: d1 = r3->field_7
    //     0xae195c: ldur            d1, [x3, #7]
    // 0xae1960: fcmp            d1, d0
    // 0xae1964: b.vs            #0xae1c68
    // 0xae1968: b.ne            #0xae1c68
    // 0xae196c: r17 = 4202
    //     0xae196c: mov             x17, #0x106a
    // 0xae1970: cmp             w0, w17
    // 0xae1974: b.ne            #0xae1980
    // 0xae1978: LoadField: d1 = r3->field_f
    //     0xae1978: ldur            d1, [x3, #0xf]
    // 0xae197c: b               #0xae1998
    // 0xae1980: r17 = 4204
    //     0xae1980: mov             x17, #0x106c
    // 0xae1984: cmp             w0, w17
    // 0xae1988: b.ne            #0xae1994
    // 0xae198c: d1 = 0.000000
    //     0xae198c: eor             v1.16b, v1.16b, v1.16b
    // 0xae1990: b               #0xae1998
    // 0xae1994: LoadField: d1 = r3->field_17
    //     0xae1994: ldur            d1, [x3, #0x17]
    // 0xae1998: fcmp            d1, d0
    // 0xae199c: b.vs            #0xae1c68
    // 0xae19a0: b.ne            #0xae1c68
    // 0xae19a4: r1 = Null
    //     0xae19a4: mov             x1, NULL
    // 0xae19a8: r2 = 18
    //     0xae19a8: mov             x2, #0x12
    // 0xae19ac: r0 = AllocateArray()
    //     0xae19ac: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae19b0: stur            x0, [fp, #-0x10]
    // 0xae19b4: r17 = "EdgeInsetsDirectional("
    //     0xae19b4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc778] "EdgeInsetsDirectional("
    //     0xae19b8: ldr             x17, [x17, #0x778]
    // 0xae19bc: StoreField: r0->field_f = r17
    //     0xae19bc: stur            w17, [x0, #0xf]
    // 0xae19c0: ldur            x1, [fp, #-8]
    // 0xae19c4: r17 = 4202
    //     0xae19c4: mov             x17, #0x106a
    // 0xae19c8: cmp             w1, w17
    // 0xae19cc: b.ne            #0xae19dc
    // 0xae19d0: ldr             x2, [fp, #0x10]
    // 0xae19d4: LoadField: d0 = r2->field_17
    //     0xae19d4: ldur            d0, [x2, #0x17]
    // 0xae19d8: b               #0xae19f8
    // 0xae19dc: ldr             x2, [fp, #0x10]
    // 0xae19e0: r17 = 4204
    //     0xae19e0: mov             x17, #0x106c
    // 0xae19e4: cmp             w1, w17
    // 0xae19e8: b.ne            #0xae19f4
    // 0xae19ec: LoadField: d0 = r2->field_7
    //     0xae19ec: ldur            d0, [x2, #7]
    // 0xae19f0: b               #0xae19f8
    // 0xae19f4: d0 = 0.000000
    //     0xae19f4: eor             v0.16b, v0.16b, v0.16b
    // 0xae19f8: r3 = 1
    //     0xae19f8: mov             x3, #1
    // 0xae19fc: r4 = inline_Allocate_Double()
    //     0xae19fc: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xae1a00: add             x4, x4, #0x10
    //     0xae1a04: cmp             x5, x4
    //     0xae1a08: b.ls            #0xae2128
    //     0xae1a0c: str             x4, [THR, #0x60]  ; THR::top
    //     0xae1a10: sub             x4, x4, #0xf
    //     0xae1a14: mov             x5, #0xd108
    //     0xae1a18: movk            x5, #3, lsl #16
    //     0xae1a1c: stur            x5, [x4, #-1]
    // 0xae1a20: StoreField: r4->field_7 = d0
    //     0xae1a20: stur            d0, [x4, #7]
    // 0xae1a24: stp             x3, x4, [SP, #-0x10]!
    // 0xae1a28: r0 = toStringAsFixed()
    //     0xae1a28: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae1a2c: add             SP, SP, #0x10
    // 0xae1a30: ldur            x1, [fp, #-0x10]
    // 0xae1a34: ArrayStore: r1[1] = r0  ; List_4
    //     0xae1a34: add             x25, x1, #0x13
    //     0xae1a38: str             w0, [x25]
    //     0xae1a3c: tbz             w0, #0, #0xae1a58
    //     0xae1a40: ldurb           w16, [x1, #-1]
    //     0xae1a44: ldurb           w17, [x0, #-1]
    //     0xae1a48: and             x16, x17, x16, lsr #2
    //     0xae1a4c: tst             x16, HEAP, lsr #32
    //     0xae1a50: b.eq            #0xae1a58
    //     0xae1a54: bl              #0xd67e5c
    // 0xae1a58: ldur            x1, [fp, #-0x10]
    // 0xae1a5c: r17 = ", "
    //     0xae1a5c: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae1a60: StoreField: r1->field_17 = r17
    //     0xae1a60: stur            w17, [x1, #0x17]
    // 0xae1a64: ldur            x0, [fp, #-8]
    // 0xae1a68: r17 = 4202
    //     0xae1a68: mov             x17, #0x106a
    // 0xae1a6c: cmp             w0, w17
    // 0xae1a70: b.ne            #0xae1a80
    // 0xae1a74: ldr             x2, [fp, #0x10]
    // 0xae1a78: LoadField: d0 = r2->field_27
    //     0xae1a78: ldur            d0, [x2, #0x27]
    // 0xae1a7c: b               #0xae1a9c
    // 0xae1a80: ldr             x2, [fp, #0x10]
    // 0xae1a84: r17 = 4204
    //     0xae1a84: mov             x17, #0x106c
    // 0xae1a88: cmp             w0, w17
    // 0xae1a8c: b.ne            #0xae1a98
    // 0xae1a90: LoadField: d0 = r2->field_f
    //     0xae1a90: ldur            d0, [x2, #0xf]
    // 0xae1a94: b               #0xae1a9c
    // 0xae1a98: LoadField: d0 = r2->field_f
    //     0xae1a98: ldur            d0, [x2, #0xf]
    // 0xae1a9c: r3 = 1
    //     0xae1a9c: mov             x3, #1
    // 0xae1aa0: r4 = inline_Allocate_Double()
    //     0xae1aa0: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xae1aa4: add             x4, x4, #0x10
    //     0xae1aa8: cmp             x5, x4
    //     0xae1aac: b.ls            #0xae214c
    //     0xae1ab0: str             x4, [THR, #0x60]  ; THR::top
    //     0xae1ab4: sub             x4, x4, #0xf
    //     0xae1ab8: mov             x5, #0xd108
    //     0xae1abc: movk            x5, #3, lsl #16
    //     0xae1ac0: stur            x5, [x4, #-1]
    // 0xae1ac4: StoreField: r4->field_7 = d0
    //     0xae1ac4: stur            d0, [x4, #7]
    // 0xae1ac8: stp             x3, x4, [SP, #-0x10]!
    // 0xae1acc: r0 = toStringAsFixed()
    //     0xae1acc: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae1ad0: add             SP, SP, #0x10
    // 0xae1ad4: ldur            x1, [fp, #-0x10]
    // 0xae1ad8: ArrayStore: r1[3] = r0  ; List_4
    //     0xae1ad8: add             x25, x1, #0x1b
    //     0xae1adc: str             w0, [x25]
    //     0xae1ae0: tbz             w0, #0, #0xae1afc
    //     0xae1ae4: ldurb           w16, [x1, #-1]
    //     0xae1ae8: ldurb           w17, [x0, #-1]
    //     0xae1aec: and             x16, x17, x16, lsr #2
    //     0xae1af0: tst             x16, HEAP, lsr #32
    //     0xae1af4: b.eq            #0xae1afc
    //     0xae1af8: bl              #0xd67e5c
    // 0xae1afc: ldur            x1, [fp, #-0x10]
    // 0xae1b00: r17 = ", "
    //     0xae1b00: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae1b04: StoreField: r1->field_1f = r17
    //     0xae1b04: stur            w17, [x1, #0x1f]
    // 0xae1b08: ldur            x0, [fp, #-8]
    // 0xae1b0c: r17 = 4202
    //     0xae1b0c: mov             x17, #0x106a
    // 0xae1b10: cmp             w0, w17
    // 0xae1b14: b.ne            #0xae1b24
    // 0xae1b18: ldr             x2, [fp, #0x10]
    // 0xae1b1c: LoadField: d0 = r2->field_1f
    //     0xae1b1c: ldur            d0, [x2, #0x1f]
    // 0xae1b20: b               #0xae1b40
    // 0xae1b24: ldr             x2, [fp, #0x10]
    // 0xae1b28: r17 = 4204
    //     0xae1b28: mov             x17, #0x106c
    // 0xae1b2c: cmp             w0, w17
    // 0xae1b30: b.ne            #0xae1b3c
    // 0xae1b34: LoadField: d0 = r2->field_17
    //     0xae1b34: ldur            d0, [x2, #0x17]
    // 0xae1b38: b               #0xae1b40
    // 0xae1b3c: d0 = 0.000000
    //     0xae1b3c: eor             v0.16b, v0.16b, v0.16b
    // 0xae1b40: r3 = 1
    //     0xae1b40: mov             x3, #1
    // 0xae1b44: r4 = inline_Allocate_Double()
    //     0xae1b44: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xae1b48: add             x4, x4, #0x10
    //     0xae1b4c: cmp             x5, x4
    //     0xae1b50: b.ls            #0xae2170
    //     0xae1b54: str             x4, [THR, #0x60]  ; THR::top
    //     0xae1b58: sub             x4, x4, #0xf
    //     0xae1b5c: mov             x5, #0xd108
    //     0xae1b60: movk            x5, #3, lsl #16
    //     0xae1b64: stur            x5, [x4, #-1]
    // 0xae1b68: StoreField: r4->field_7 = d0
    //     0xae1b68: stur            d0, [x4, #7]
    // 0xae1b6c: stp             x3, x4, [SP, #-0x10]!
    // 0xae1b70: r0 = toStringAsFixed()
    //     0xae1b70: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae1b74: add             SP, SP, #0x10
    // 0xae1b78: ldur            x1, [fp, #-0x10]
    // 0xae1b7c: ArrayStore: r1[5] = r0  ; List_4
    //     0xae1b7c: add             x25, x1, #0x23
    //     0xae1b80: str             w0, [x25]
    //     0xae1b84: tbz             w0, #0, #0xae1ba0
    //     0xae1b88: ldurb           w16, [x1, #-1]
    //     0xae1b8c: ldurb           w17, [x0, #-1]
    //     0xae1b90: and             x16, x17, x16, lsr #2
    //     0xae1b94: tst             x16, HEAP, lsr #32
    //     0xae1b98: b.eq            #0xae1ba0
    //     0xae1b9c: bl              #0xd67e5c
    // 0xae1ba0: ldur            x1, [fp, #-0x10]
    // 0xae1ba4: r17 = ", "
    //     0xae1ba4: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae1ba8: StoreField: r1->field_27 = r17
    //     0xae1ba8: stur            w17, [x1, #0x27]
    // 0xae1bac: ldur            x0, [fp, #-8]
    // 0xae1bb0: r17 = 4202
    //     0xae1bb0: mov             x17, #0x106a
    // 0xae1bb4: cmp             w0, w17
    // 0xae1bb8: b.ne            #0xae1bc8
    // 0xae1bbc: ldr             x3, [fp, #0x10]
    // 0xae1bc0: LoadField: d0 = r3->field_2f
    //     0xae1bc0: ldur            d0, [x3, #0x2f]
    // 0xae1bc4: b               #0xae1be4
    // 0xae1bc8: ldr             x3, [fp, #0x10]
    // 0xae1bcc: r17 = 4204
    //     0xae1bcc: mov             x17, #0x106c
    // 0xae1bd0: cmp             w0, w17
    // 0xae1bd4: b.ne            #0xae1be0
    // 0xae1bd8: LoadField: d0 = r3->field_1f
    //     0xae1bd8: ldur            d0, [x3, #0x1f]
    // 0xae1bdc: b               #0xae1be4
    // 0xae1be0: LoadField: d0 = r3->field_1f
    //     0xae1be0: ldur            d0, [x3, #0x1f]
    // 0xae1be4: r4 = 1
    //     0xae1be4: mov             x4, #1
    // 0xae1be8: r0 = inline_Allocate_Double()
    //     0xae1be8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xae1bec: add             x0, x0, #0x10
    //     0xae1bf0: cmp             x2, x0
    //     0xae1bf4: b.ls            #0xae2194
    //     0xae1bf8: str             x0, [THR, #0x60]  ; THR::top
    //     0xae1bfc: sub             x0, x0, #0xf
    //     0xae1c00: mov             x2, #0xd108
    //     0xae1c04: movk            x2, #3, lsl #16
    //     0xae1c08: stur            x2, [x0, #-1]
    // 0xae1c0c: StoreField: r0->field_7 = d0
    //     0xae1c0c: stur            d0, [x0, #7]
    // 0xae1c10: stp             x4, x0, [SP, #-0x10]!
    // 0xae1c14: r0 = toStringAsFixed()
    //     0xae1c14: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae1c18: add             SP, SP, #0x10
    // 0xae1c1c: ldur            x1, [fp, #-0x10]
    // 0xae1c20: ArrayStore: r1[7] = r0  ; List_4
    //     0xae1c20: add             x25, x1, #0x2b
    //     0xae1c24: str             w0, [x25]
    //     0xae1c28: tbz             w0, #0, #0xae1c44
    //     0xae1c2c: ldurb           w16, [x1, #-1]
    //     0xae1c30: ldurb           w17, [x0, #-1]
    //     0xae1c34: and             x16, x17, x16, lsr #2
    //     0xae1c38: tst             x16, HEAP, lsr #32
    //     0xae1c3c: b.eq            #0xae1c44
    //     0xae1c40: bl              #0xd67e5c
    // 0xae1c44: ldur            x0, [fp, #-0x10]
    // 0xae1c48: r17 = ")"
    //     0xae1c48: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae1c4c: StoreField: r0->field_2f = r17
    //     0xae1c4c: stur            w17, [x0, #0x2f]
    // 0xae1c50: SaveReg r0
    //     0xae1c50: str             x0, [SP, #-8]!
    // 0xae1c54: r0 = _interpolate()
    //     0xae1c54: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae1c58: add             SP, SP, #8
    // 0xae1c5c: LeaveFrame
    //     0xae1c5c: mov             SP, fp
    //     0xae1c60: ldp             fp, lr, [SP], #0x10
    // 0xae1c64: ret
    //     0xae1c64: ret             
    // 0xae1c68: r1 = Null
    //     0xae1c68: mov             x1, NULL
    // 0xae1c6c: r2 = 26
    //     0xae1c6c: mov             x2, #0x1a
    // 0xae1c70: r0 = AllocateArray()
    //     0xae1c70: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae1c74: stur            x0, [fp, #-0x10]
    // 0xae1c78: r17 = "EdgeInsets("
    //     0xae1c78: add             x17, PP, #0xc, lsl #12  ; [pp+0xc770] "EdgeInsets("
    //     0xae1c7c: ldr             x17, [x17, #0x770]
    // 0xae1c80: StoreField: r0->field_f = r17
    //     0xae1c80: stur            w17, [x0, #0xf]
    // 0xae1c84: ldur            x1, [fp, #-8]
    // 0xae1c88: r17 = 4202
    //     0xae1c88: mov             x17, #0x106a
    // 0xae1c8c: cmp             w1, w17
    // 0xae1c90: b.ne            #0xae1ca0
    // 0xae1c94: ldr             x2, [fp, #0x10]
    // 0xae1c98: LoadField: d0 = r2->field_7
    //     0xae1c98: ldur            d0, [x2, #7]
    // 0xae1c9c: b               #0xae1cbc
    // 0xae1ca0: ldr             x2, [fp, #0x10]
    // 0xae1ca4: r17 = 4204
    //     0xae1ca4: mov             x17, #0x106c
    // 0xae1ca8: cmp             w1, w17
    // 0xae1cac: b.ne            #0xae1cb8
    // 0xae1cb0: d0 = 0.000000
    //     0xae1cb0: eor             v0.16b, v0.16b, v0.16b
    // 0xae1cb4: b               #0xae1cbc
    // 0xae1cb8: LoadField: d0 = r2->field_7
    //     0xae1cb8: ldur            d0, [x2, #7]
    // 0xae1cbc: r3 = 1
    //     0xae1cbc: mov             x3, #1
    // 0xae1cc0: r4 = inline_Allocate_Double()
    //     0xae1cc0: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xae1cc4: add             x4, x4, #0x10
    //     0xae1cc8: cmp             x5, x4
    //     0xae1ccc: b.ls            #0xae21ac
    //     0xae1cd0: str             x4, [THR, #0x60]  ; THR::top
    //     0xae1cd4: sub             x4, x4, #0xf
    //     0xae1cd8: mov             x5, #0xd108
    //     0xae1cdc: movk            x5, #3, lsl #16
    //     0xae1ce0: stur            x5, [x4, #-1]
    // 0xae1ce4: StoreField: r4->field_7 = d0
    //     0xae1ce4: stur            d0, [x4, #7]
    // 0xae1ce8: stp             x3, x4, [SP, #-0x10]!
    // 0xae1cec: r0 = toStringAsFixed()
    //     0xae1cec: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae1cf0: add             SP, SP, #0x10
    // 0xae1cf4: ldur            x1, [fp, #-0x10]
    // 0xae1cf8: ArrayStore: r1[1] = r0  ; List_4
    //     0xae1cf8: add             x25, x1, #0x13
    //     0xae1cfc: str             w0, [x25]
    //     0xae1d00: tbz             w0, #0, #0xae1d1c
    //     0xae1d04: ldurb           w16, [x1, #-1]
    //     0xae1d08: ldurb           w17, [x0, #-1]
    //     0xae1d0c: and             x16, x17, x16, lsr #2
    //     0xae1d10: tst             x16, HEAP, lsr #32
    //     0xae1d14: b.eq            #0xae1d1c
    //     0xae1d18: bl              #0xd67e5c
    // 0xae1d1c: ldur            x1, [fp, #-0x10]
    // 0xae1d20: r17 = ", "
    //     0xae1d20: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae1d24: StoreField: r1->field_17 = r17
    //     0xae1d24: stur            w17, [x1, #0x17]
    // 0xae1d28: ldur            x0, [fp, #-8]
    // 0xae1d2c: r17 = 4202
    //     0xae1d2c: mov             x17, #0x106a
    // 0xae1d30: cmp             w0, w17
    // 0xae1d34: b.ne            #0xae1d44
    // 0xae1d38: ldr             x2, [fp, #0x10]
    // 0xae1d3c: LoadField: d0 = r2->field_27
    //     0xae1d3c: ldur            d0, [x2, #0x27]
    // 0xae1d40: b               #0xae1d60
    // 0xae1d44: ldr             x2, [fp, #0x10]
    // 0xae1d48: r17 = 4204
    //     0xae1d48: mov             x17, #0x106c
    // 0xae1d4c: cmp             w0, w17
    // 0xae1d50: b.ne            #0xae1d5c
    // 0xae1d54: LoadField: d0 = r2->field_f
    //     0xae1d54: ldur            d0, [x2, #0xf]
    // 0xae1d58: b               #0xae1d60
    // 0xae1d5c: LoadField: d0 = r2->field_f
    //     0xae1d5c: ldur            d0, [x2, #0xf]
    // 0xae1d60: r3 = 1
    //     0xae1d60: mov             x3, #1
    // 0xae1d64: r4 = inline_Allocate_Double()
    //     0xae1d64: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xae1d68: add             x4, x4, #0x10
    //     0xae1d6c: cmp             x5, x4
    //     0xae1d70: b.ls            #0xae21d0
    //     0xae1d74: str             x4, [THR, #0x60]  ; THR::top
    //     0xae1d78: sub             x4, x4, #0xf
    //     0xae1d7c: mov             x5, #0xd108
    //     0xae1d80: movk            x5, #3, lsl #16
    //     0xae1d84: stur            x5, [x4, #-1]
    // 0xae1d88: StoreField: r4->field_7 = d0
    //     0xae1d88: stur            d0, [x4, #7]
    // 0xae1d8c: stp             x3, x4, [SP, #-0x10]!
    // 0xae1d90: r0 = toStringAsFixed()
    //     0xae1d90: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae1d94: add             SP, SP, #0x10
    // 0xae1d98: ldur            x1, [fp, #-0x10]
    // 0xae1d9c: ArrayStore: r1[3] = r0  ; List_4
    //     0xae1d9c: add             x25, x1, #0x1b
    //     0xae1da0: str             w0, [x25]
    //     0xae1da4: tbz             w0, #0, #0xae1dc0
    //     0xae1da8: ldurb           w16, [x1, #-1]
    //     0xae1dac: ldurb           w17, [x0, #-1]
    //     0xae1db0: and             x16, x17, x16, lsr #2
    //     0xae1db4: tst             x16, HEAP, lsr #32
    //     0xae1db8: b.eq            #0xae1dc0
    //     0xae1dbc: bl              #0xd67e5c
    // 0xae1dc0: ldur            x1, [fp, #-0x10]
    // 0xae1dc4: r17 = ", "
    //     0xae1dc4: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae1dc8: StoreField: r1->field_1f = r17
    //     0xae1dc8: stur            w17, [x1, #0x1f]
    // 0xae1dcc: ldur            x0, [fp, #-8]
    // 0xae1dd0: r17 = 4202
    //     0xae1dd0: mov             x17, #0x106a
    // 0xae1dd4: cmp             w0, w17
    // 0xae1dd8: b.ne            #0xae1de8
    // 0xae1ddc: ldr             x2, [fp, #0x10]
    // 0xae1de0: LoadField: d0 = r2->field_f
    //     0xae1de0: ldur            d0, [x2, #0xf]
    // 0xae1de4: b               #0xae1e04
    // 0xae1de8: ldr             x2, [fp, #0x10]
    // 0xae1dec: r17 = 4204
    //     0xae1dec: mov             x17, #0x106c
    // 0xae1df0: cmp             w0, w17
    // 0xae1df4: b.ne            #0xae1e00
    // 0xae1df8: d0 = 0.000000
    //     0xae1df8: eor             v0.16b, v0.16b, v0.16b
    // 0xae1dfc: b               #0xae1e04
    // 0xae1e00: LoadField: d0 = r2->field_17
    //     0xae1e00: ldur            d0, [x2, #0x17]
    // 0xae1e04: r3 = 1
    //     0xae1e04: mov             x3, #1
    // 0xae1e08: r4 = inline_Allocate_Double()
    //     0xae1e08: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xae1e0c: add             x4, x4, #0x10
    //     0xae1e10: cmp             x5, x4
    //     0xae1e14: b.ls            #0xae21f4
    //     0xae1e18: str             x4, [THR, #0x60]  ; THR::top
    //     0xae1e1c: sub             x4, x4, #0xf
    //     0xae1e20: mov             x5, #0xd108
    //     0xae1e24: movk            x5, #3, lsl #16
    //     0xae1e28: stur            x5, [x4, #-1]
    // 0xae1e2c: StoreField: r4->field_7 = d0
    //     0xae1e2c: stur            d0, [x4, #7]
    // 0xae1e30: stp             x3, x4, [SP, #-0x10]!
    // 0xae1e34: r0 = toStringAsFixed()
    //     0xae1e34: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae1e38: add             SP, SP, #0x10
    // 0xae1e3c: ldur            x1, [fp, #-0x10]
    // 0xae1e40: ArrayStore: r1[5] = r0  ; List_4
    //     0xae1e40: add             x25, x1, #0x23
    //     0xae1e44: str             w0, [x25]
    //     0xae1e48: tbz             w0, #0, #0xae1e64
    //     0xae1e4c: ldurb           w16, [x1, #-1]
    //     0xae1e50: ldurb           w17, [x0, #-1]
    //     0xae1e54: and             x16, x17, x16, lsr #2
    //     0xae1e58: tst             x16, HEAP, lsr #32
    //     0xae1e5c: b.eq            #0xae1e64
    //     0xae1e60: bl              #0xd67e5c
    // 0xae1e64: ldur            x1, [fp, #-0x10]
    // 0xae1e68: r17 = ", "
    //     0xae1e68: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae1e6c: StoreField: r1->field_27 = r17
    //     0xae1e6c: stur            w17, [x1, #0x27]
    // 0xae1e70: ldur            x0, [fp, #-8]
    // 0xae1e74: r17 = 4202
    //     0xae1e74: mov             x17, #0x106a
    // 0xae1e78: cmp             w0, w17
    // 0xae1e7c: b.ne            #0xae1e8c
    // 0xae1e80: ldr             x2, [fp, #0x10]
    // 0xae1e84: LoadField: d0 = r2->field_2f
    //     0xae1e84: ldur            d0, [x2, #0x2f]
    // 0xae1e88: b               #0xae1ea8
    // 0xae1e8c: ldr             x2, [fp, #0x10]
    // 0xae1e90: r17 = 4204
    //     0xae1e90: mov             x17, #0x106c
    // 0xae1e94: cmp             w0, w17
    // 0xae1e98: b.ne            #0xae1ea4
    // 0xae1e9c: LoadField: d0 = r2->field_1f
    //     0xae1e9c: ldur            d0, [x2, #0x1f]
    // 0xae1ea0: b               #0xae1ea8
    // 0xae1ea4: LoadField: d0 = r2->field_1f
    //     0xae1ea4: ldur            d0, [x2, #0x1f]
    // 0xae1ea8: r3 = 1
    //     0xae1ea8: mov             x3, #1
    // 0xae1eac: r4 = inline_Allocate_Double()
    //     0xae1eac: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xae1eb0: add             x4, x4, #0x10
    //     0xae1eb4: cmp             x5, x4
    //     0xae1eb8: b.ls            #0xae2218
    //     0xae1ebc: str             x4, [THR, #0x60]  ; THR::top
    //     0xae1ec0: sub             x4, x4, #0xf
    //     0xae1ec4: mov             x5, #0xd108
    //     0xae1ec8: movk            x5, #3, lsl #16
    //     0xae1ecc: stur            x5, [x4, #-1]
    // 0xae1ed0: StoreField: r4->field_7 = d0
    //     0xae1ed0: stur            d0, [x4, #7]
    // 0xae1ed4: stp             x3, x4, [SP, #-0x10]!
    // 0xae1ed8: r0 = toStringAsFixed()
    //     0xae1ed8: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae1edc: add             SP, SP, #0x10
    // 0xae1ee0: ldur            x1, [fp, #-0x10]
    // 0xae1ee4: ArrayStore: r1[7] = r0  ; List_4
    //     0xae1ee4: add             x25, x1, #0x2b
    //     0xae1ee8: str             w0, [x25]
    //     0xae1eec: tbz             w0, #0, #0xae1f08
    //     0xae1ef0: ldurb           w16, [x1, #-1]
    //     0xae1ef4: ldurb           w17, [x0, #-1]
    //     0xae1ef8: and             x16, x17, x16, lsr #2
    //     0xae1efc: tst             x16, HEAP, lsr #32
    //     0xae1f00: b.eq            #0xae1f08
    //     0xae1f04: bl              #0xd67e5c
    // 0xae1f08: ldur            x1, [fp, #-0x10]
    // 0xae1f0c: r17 = ") + EdgeInsetsDirectional("
    //     0xae1f0c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc780] ") + EdgeInsetsDirectional("
    //     0xae1f10: ldr             x17, [x17, #0x780]
    // 0xae1f14: StoreField: r1->field_2f = r17
    //     0xae1f14: stur            w17, [x1, #0x2f]
    // 0xae1f18: ldur            x0, [fp, #-8]
    // 0xae1f1c: r17 = 4202
    //     0xae1f1c: mov             x17, #0x106a
    // 0xae1f20: cmp             w0, w17
    // 0xae1f24: b.ne            #0xae1f34
    // 0xae1f28: ldr             x2, [fp, #0x10]
    // 0xae1f2c: LoadField: d0 = r2->field_17
    //     0xae1f2c: ldur            d0, [x2, #0x17]
    // 0xae1f30: b               #0xae1f50
    // 0xae1f34: ldr             x2, [fp, #0x10]
    // 0xae1f38: r17 = 4204
    //     0xae1f38: mov             x17, #0x106c
    // 0xae1f3c: cmp             w0, w17
    // 0xae1f40: b.ne            #0xae1f4c
    // 0xae1f44: LoadField: d0 = r2->field_7
    //     0xae1f44: ldur            d0, [x2, #7]
    // 0xae1f48: b               #0xae1f50
    // 0xae1f4c: d0 = 0.000000
    //     0xae1f4c: eor             v0.16b, v0.16b, v0.16b
    // 0xae1f50: r3 = 1
    //     0xae1f50: mov             x3, #1
    // 0xae1f54: r4 = inline_Allocate_Double()
    //     0xae1f54: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xae1f58: add             x4, x4, #0x10
    //     0xae1f5c: cmp             x5, x4
    //     0xae1f60: b.ls            #0xae223c
    //     0xae1f64: str             x4, [THR, #0x60]  ; THR::top
    //     0xae1f68: sub             x4, x4, #0xf
    //     0xae1f6c: mov             x5, #0xd108
    //     0xae1f70: movk            x5, #3, lsl #16
    //     0xae1f74: stur            x5, [x4, #-1]
    // 0xae1f78: StoreField: r4->field_7 = d0
    //     0xae1f78: stur            d0, [x4, #7]
    // 0xae1f7c: stp             x3, x4, [SP, #-0x10]!
    // 0xae1f80: r0 = toStringAsFixed()
    //     0xae1f80: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae1f84: add             SP, SP, #0x10
    // 0xae1f88: ldur            x1, [fp, #-0x10]
    // 0xae1f8c: ArrayStore: r1[9] = r0  ; List_4
    //     0xae1f8c: add             x25, x1, #0x33
    //     0xae1f90: str             w0, [x25]
    //     0xae1f94: tbz             w0, #0, #0xae1fb0
    //     0xae1f98: ldurb           w16, [x1, #-1]
    //     0xae1f9c: ldurb           w17, [x0, #-1]
    //     0xae1fa0: and             x16, x17, x16, lsr #2
    //     0xae1fa4: tst             x16, HEAP, lsr #32
    //     0xae1fa8: b.eq            #0xae1fb0
    //     0xae1fac: bl              #0xd67e5c
    // 0xae1fb0: ldur            x1, [fp, #-0x10]
    // 0xae1fb4: r17 = ", 0.0, "
    //     0xae1fb4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc788] ", 0.0, "
    //     0xae1fb8: ldr             x17, [x17, #0x788]
    // 0xae1fbc: StoreField: r1->field_37 = r17
    //     0xae1fbc: stur            w17, [x1, #0x37]
    // 0xae1fc0: ldur            x0, [fp, #-8]
    // 0xae1fc4: r17 = 4202
    //     0xae1fc4: mov             x17, #0x106a
    // 0xae1fc8: cmp             w0, w17
    // 0xae1fcc: b.ne            #0xae1fdc
    // 0xae1fd0: ldr             x2, [fp, #0x10]
    // 0xae1fd4: LoadField: d0 = r2->field_1f
    //     0xae1fd4: ldur            d0, [x2, #0x1f]
    // 0xae1fd8: b               #0xae1ff8
    // 0xae1fdc: ldr             x2, [fp, #0x10]
    // 0xae1fe0: r17 = 4204
    //     0xae1fe0: mov             x17, #0x106c
    // 0xae1fe4: cmp             w0, w17
    // 0xae1fe8: b.ne            #0xae1ff4
    // 0xae1fec: LoadField: d0 = r2->field_17
    //     0xae1fec: ldur            d0, [x2, #0x17]
    // 0xae1ff0: b               #0xae1ff8
    // 0xae1ff4: d0 = 0.000000
    //     0xae1ff4: eor             v0.16b, v0.16b, v0.16b
    // 0xae1ff8: r0 = 1
    //     0xae1ff8: mov             x0, #1
    // 0xae1ffc: r2 = inline_Allocate_Double()
    //     0xae1ffc: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xae2000: add             x2, x2, #0x10
    //     0xae2004: cmp             x3, x2
    //     0xae2008: b.ls            #0xae2260
    //     0xae200c: str             x2, [THR, #0x60]  ; THR::top
    //     0xae2010: sub             x2, x2, #0xf
    //     0xae2014: mov             x3, #0xd108
    //     0xae2018: movk            x3, #3, lsl #16
    //     0xae201c: stur            x3, [x2, #-1]
    // 0xae2020: StoreField: r2->field_7 = d0
    //     0xae2020: stur            d0, [x2, #7]
    // 0xae2024: stp             x0, x2, [SP, #-0x10]!
    // 0xae2028: r0 = toStringAsFixed()
    //     0xae2028: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae202c: add             SP, SP, #0x10
    // 0xae2030: ldur            x1, [fp, #-0x10]
    // 0xae2034: ArrayStore: r1[11] = r0  ; List_4
    //     0xae2034: add             x25, x1, #0x3b
    //     0xae2038: str             w0, [x25]
    //     0xae203c: tbz             w0, #0, #0xae2058
    //     0xae2040: ldurb           w16, [x1, #-1]
    //     0xae2044: ldurb           w17, [x0, #-1]
    //     0xae2048: and             x16, x17, x16, lsr #2
    //     0xae204c: tst             x16, HEAP, lsr #32
    //     0xae2050: b.eq            #0xae2058
    //     0xae2054: bl              #0xd67e5c
    // 0xae2058: ldur            x0, [fp, #-0x10]
    // 0xae205c: r17 = ", 0.0)"
    //     0xae205c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc790] ", 0.0)"
    //     0xae2060: ldr             x17, [x17, #0x790]
    // 0xae2064: StoreField: r0->field_3f = r17
    //     0xae2064: stur            w17, [x0, #0x3f]
    // 0xae2068: SaveReg r0
    //     0xae2068: str             x0, [SP, #-8]!
    // 0xae206c: r0 = _interpolate()
    //     0xae206c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae2070: add             SP, SP, #8
    // 0xae2074: LeaveFrame
    //     0xae2074: mov             SP, fp
    //     0xae2078: ldp             fp, lr, [SP], #0x10
    // 0xae207c: ret
    //     0xae207c: ret             
    // 0xae2080: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae2080: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae2084: b               #0xae12a4
    // 0xae2088: SaveReg d0
    //     0xae2088: str             q0, [SP, #-0x10]!
    // 0xae208c: stp             x0, x5, [SP, #-0x10]!
    // 0xae2090: r0 = AllocateDouble()
    //     0xae2090: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae2094: mov             x1, x0
    // 0xae2098: ldp             x0, x5, [SP], #0x10
    // 0xae209c: RestoreReg d0
    //     0xae209c: ldr             q0, [SP], #0x10
    // 0xae20a0: b               #0xae15d0
    // 0xae20a4: SaveReg d0
    //     0xae20a4: str             q0, [SP, #-0x10]!
    // 0xae20a8: stp             x2, x3, [SP, #-0x10]!
    // 0xae20ac: stp             x0, x1, [SP, #-0x10]!
    // 0xae20b0: r0 = AllocateDouble()
    //     0xae20b0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae20b4: mov             x4, x0
    // 0xae20b8: ldp             x0, x1, [SP], #0x10
    // 0xae20bc: ldp             x2, x3, [SP], #0x10
    // 0xae20c0: RestoreReg d0
    //     0xae20c0: ldr             q0, [SP], #0x10
    // 0xae20c4: b               #0xae16c8
    // 0xae20c8: SaveReg d0
    //     0xae20c8: str             q0, [SP, #-0x10]!
    // 0xae20cc: stp             x2, x3, [SP, #-0x10]!
    // 0xae20d0: stp             x0, x1, [SP, #-0x10]!
    // 0xae20d4: r0 = AllocateDouble()
    //     0xae20d4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae20d8: mov             x4, x0
    // 0xae20dc: ldp             x0, x1, [SP], #0x10
    // 0xae20e0: ldp             x2, x3, [SP], #0x10
    // 0xae20e4: RestoreReg d0
    //     0xae20e4: ldr             q0, [SP], #0x10
    // 0xae20e8: b               #0xae176c
    // 0xae20ec: SaveReg d0
    //     0xae20ec: str             q0, [SP, #-0x10]!
    // 0xae20f0: stp             x2, x3, [SP, #-0x10]!
    // 0xae20f4: stp             x0, x1, [SP, #-0x10]!
    // 0xae20f8: r0 = AllocateDouble()
    //     0xae20f8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae20fc: mov             x4, x0
    // 0xae2100: ldp             x0, x1, [SP], #0x10
    // 0xae2104: ldp             x2, x3, [SP], #0x10
    // 0xae2108: RestoreReg d0
    //     0xae2108: ldr             q0, [SP], #0x10
    // 0xae210c: b               #0xae1810
    // 0xae2110: SaveReg d0
    //     0xae2110: str             q0, [SP, #-0x10]!
    // 0xae2114: stp             x1, x4, [SP, #-0x10]!
    // 0xae2118: r0 = AllocateDouble()
    //     0xae2118: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae211c: ldp             x1, x4, [SP], #0x10
    // 0xae2120: RestoreReg d0
    //     0xae2120: ldr             q0, [SP], #0x10
    // 0xae2124: b               #0xae18b4
    // 0xae2128: SaveReg d0
    //     0xae2128: str             q0, [SP, #-0x10]!
    // 0xae212c: stp             x2, x3, [SP, #-0x10]!
    // 0xae2130: stp             x0, x1, [SP, #-0x10]!
    // 0xae2134: r0 = AllocateDouble()
    //     0xae2134: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae2138: mov             x4, x0
    // 0xae213c: ldp             x0, x1, [SP], #0x10
    // 0xae2140: ldp             x2, x3, [SP], #0x10
    // 0xae2144: RestoreReg d0
    //     0xae2144: ldr             q0, [SP], #0x10
    // 0xae2148: b               #0xae1a20
    // 0xae214c: SaveReg d0
    //     0xae214c: str             q0, [SP, #-0x10]!
    // 0xae2150: stp             x2, x3, [SP, #-0x10]!
    // 0xae2154: stp             x0, x1, [SP, #-0x10]!
    // 0xae2158: r0 = AllocateDouble()
    //     0xae2158: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae215c: mov             x4, x0
    // 0xae2160: ldp             x0, x1, [SP], #0x10
    // 0xae2164: ldp             x2, x3, [SP], #0x10
    // 0xae2168: RestoreReg d0
    //     0xae2168: ldr             q0, [SP], #0x10
    // 0xae216c: b               #0xae1ac4
    // 0xae2170: SaveReg d0
    //     0xae2170: str             q0, [SP, #-0x10]!
    // 0xae2174: stp             x2, x3, [SP, #-0x10]!
    // 0xae2178: stp             x0, x1, [SP, #-0x10]!
    // 0xae217c: r0 = AllocateDouble()
    //     0xae217c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae2180: mov             x4, x0
    // 0xae2184: ldp             x0, x1, [SP], #0x10
    // 0xae2188: ldp             x2, x3, [SP], #0x10
    // 0xae218c: RestoreReg d0
    //     0xae218c: ldr             q0, [SP], #0x10
    // 0xae2190: b               #0xae1b68
    // 0xae2194: SaveReg d0
    //     0xae2194: str             q0, [SP, #-0x10]!
    // 0xae2198: stp             x1, x4, [SP, #-0x10]!
    // 0xae219c: r0 = AllocateDouble()
    //     0xae219c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae21a0: ldp             x1, x4, [SP], #0x10
    // 0xae21a4: RestoreReg d0
    //     0xae21a4: ldr             q0, [SP], #0x10
    // 0xae21a8: b               #0xae1c0c
    // 0xae21ac: SaveReg d0
    //     0xae21ac: str             q0, [SP, #-0x10]!
    // 0xae21b0: stp             x2, x3, [SP, #-0x10]!
    // 0xae21b4: stp             x0, x1, [SP, #-0x10]!
    // 0xae21b8: r0 = AllocateDouble()
    //     0xae21b8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae21bc: mov             x4, x0
    // 0xae21c0: ldp             x0, x1, [SP], #0x10
    // 0xae21c4: ldp             x2, x3, [SP], #0x10
    // 0xae21c8: RestoreReg d0
    //     0xae21c8: ldr             q0, [SP], #0x10
    // 0xae21cc: b               #0xae1ce4
    // 0xae21d0: SaveReg d0
    //     0xae21d0: str             q0, [SP, #-0x10]!
    // 0xae21d4: stp             x2, x3, [SP, #-0x10]!
    // 0xae21d8: stp             x0, x1, [SP, #-0x10]!
    // 0xae21dc: r0 = AllocateDouble()
    //     0xae21dc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae21e0: mov             x4, x0
    // 0xae21e4: ldp             x0, x1, [SP], #0x10
    // 0xae21e8: ldp             x2, x3, [SP], #0x10
    // 0xae21ec: RestoreReg d0
    //     0xae21ec: ldr             q0, [SP], #0x10
    // 0xae21f0: b               #0xae1d88
    // 0xae21f4: SaveReg d0
    //     0xae21f4: str             q0, [SP, #-0x10]!
    // 0xae21f8: stp             x2, x3, [SP, #-0x10]!
    // 0xae21fc: stp             x0, x1, [SP, #-0x10]!
    // 0xae2200: r0 = AllocateDouble()
    //     0xae2200: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae2204: mov             x4, x0
    // 0xae2208: ldp             x0, x1, [SP], #0x10
    // 0xae220c: ldp             x2, x3, [SP], #0x10
    // 0xae2210: RestoreReg d0
    //     0xae2210: ldr             q0, [SP], #0x10
    // 0xae2214: b               #0xae1e2c
    // 0xae2218: SaveReg d0
    //     0xae2218: str             q0, [SP, #-0x10]!
    // 0xae221c: stp             x2, x3, [SP, #-0x10]!
    // 0xae2220: stp             x0, x1, [SP, #-0x10]!
    // 0xae2224: r0 = AllocateDouble()
    //     0xae2224: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae2228: mov             x4, x0
    // 0xae222c: ldp             x0, x1, [SP], #0x10
    // 0xae2230: ldp             x2, x3, [SP], #0x10
    // 0xae2234: RestoreReg d0
    //     0xae2234: ldr             q0, [SP], #0x10
    // 0xae2238: b               #0xae1ed0
    // 0xae223c: SaveReg d0
    //     0xae223c: str             q0, [SP, #-0x10]!
    // 0xae2240: stp             x2, x3, [SP, #-0x10]!
    // 0xae2244: stp             x0, x1, [SP, #-0x10]!
    // 0xae2248: r0 = AllocateDouble()
    //     0xae2248: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae224c: mov             x4, x0
    // 0xae2250: ldp             x0, x1, [SP], #0x10
    // 0xae2254: ldp             x2, x3, [SP], #0x10
    // 0xae2258: RestoreReg d0
    //     0xae2258: ldr             q0, [SP], #0x10
    // 0xae225c: b               #0xae1f78
    // 0xae2260: SaveReg d0
    //     0xae2260: str             q0, [SP, #-0x10]!
    // 0xae2264: stp             x0, x1, [SP, #-0x10]!
    // 0xae2268: r0 = AllocateDouble()
    //     0xae2268: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae226c: mov             x2, x0
    // 0xae2270: ldp             x0, x1, [SP], #0x10
    // 0xae2274: RestoreReg d0
    //     0xae2274: ldr             q0, [SP], #0x10
    // 0xae2278: b               #0xae2020
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb0e458, size: 0x34c
    // 0xb0e458: EnterFrame
    //     0xb0e458: stp             fp, lr, [SP, #-0x10]!
    //     0xb0e45c: mov             fp, SP
    // 0xb0e460: CheckStackOverflow
    //     0xb0e460: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0e464: cmp             SP, x16
    //     0xb0e468: b.ls            #0xb0e6b0
    // 0xb0e46c: ldr             x0, [fp, #0x10]
    // 0xb0e470: r1 = LoadClassIdInstr(r0)
    //     0xb0e470: ldur            x1, [x0, #-1]
    //     0xb0e474: ubfx            x1, x1, #0xc, #0x14
    // 0xb0e478: lsl             x1, x1, #1
    // 0xb0e47c: r17 = 4202
    //     0xb0e47c: mov             x17, #0x106a
    // 0xb0e480: cmp             w1, w17
    // 0xb0e484: b.ne            #0xb0e490
    // 0xb0e488: LoadField: d0 = r0->field_7
    //     0xb0e488: ldur            d0, [x0, #7]
    // 0xb0e48c: b               #0xb0e4a8
    // 0xb0e490: r17 = 4204
    //     0xb0e490: mov             x17, #0x106c
    // 0xb0e494: cmp             w1, w17
    // 0xb0e498: b.ne            #0xb0e4a4
    // 0xb0e49c: d0 = 0.000000
    //     0xb0e49c: eor             v0.16b, v0.16b, v0.16b
    // 0xb0e4a0: b               #0xb0e4a8
    // 0xb0e4a4: LoadField: d0 = r0->field_7
    //     0xb0e4a4: ldur            d0, [x0, #7]
    // 0xb0e4a8: r17 = 4202
    //     0xb0e4a8: mov             x17, #0x106a
    // 0xb0e4ac: cmp             w1, w17
    // 0xb0e4b0: b.ne            #0xb0e4bc
    // 0xb0e4b4: LoadField: d1 = r0->field_f
    //     0xb0e4b4: ldur            d1, [x0, #0xf]
    // 0xb0e4b8: b               #0xb0e4d4
    // 0xb0e4bc: r17 = 4204
    //     0xb0e4bc: mov             x17, #0x106c
    // 0xb0e4c0: cmp             w1, w17
    // 0xb0e4c4: b.ne            #0xb0e4d0
    // 0xb0e4c8: d1 = 0.000000
    //     0xb0e4c8: eor             v1.16b, v1.16b, v1.16b
    // 0xb0e4cc: b               #0xb0e4d4
    // 0xb0e4d0: LoadField: d1 = r0->field_17
    //     0xb0e4d0: ldur            d1, [x0, #0x17]
    // 0xb0e4d4: r17 = 4202
    //     0xb0e4d4: mov             x17, #0x106a
    // 0xb0e4d8: cmp             w1, w17
    // 0xb0e4dc: b.ne            #0xb0e4e8
    // 0xb0e4e0: LoadField: d2 = r0->field_17
    //     0xb0e4e0: ldur            d2, [x0, #0x17]
    // 0xb0e4e4: b               #0xb0e500
    // 0xb0e4e8: r17 = 4204
    //     0xb0e4e8: mov             x17, #0x106c
    // 0xb0e4ec: cmp             w1, w17
    // 0xb0e4f0: b.ne            #0xb0e4fc
    // 0xb0e4f4: LoadField: d2 = r0->field_7
    //     0xb0e4f4: ldur            d2, [x0, #7]
    // 0xb0e4f8: b               #0xb0e500
    // 0xb0e4fc: d2 = 0.000000
    //     0xb0e4fc: eor             v2.16b, v2.16b, v2.16b
    // 0xb0e500: r17 = 4202
    //     0xb0e500: mov             x17, #0x106a
    // 0xb0e504: cmp             w1, w17
    // 0xb0e508: b.ne            #0xb0e514
    // 0xb0e50c: LoadField: d3 = r0->field_1f
    //     0xb0e50c: ldur            d3, [x0, #0x1f]
    // 0xb0e510: b               #0xb0e52c
    // 0xb0e514: r17 = 4204
    //     0xb0e514: mov             x17, #0x106c
    // 0xb0e518: cmp             w1, w17
    // 0xb0e51c: b.ne            #0xb0e528
    // 0xb0e520: LoadField: d3 = r0->field_17
    //     0xb0e520: ldur            d3, [x0, #0x17]
    // 0xb0e524: b               #0xb0e52c
    // 0xb0e528: d3 = 0.000000
    //     0xb0e528: eor             v3.16b, v3.16b, v3.16b
    // 0xb0e52c: r17 = 4202
    //     0xb0e52c: mov             x17, #0x106a
    // 0xb0e530: cmp             w1, w17
    // 0xb0e534: b.ne            #0xb0e540
    // 0xb0e538: LoadField: d4 = r0->field_27
    //     0xb0e538: ldur            d4, [x0, #0x27]
    // 0xb0e53c: b               #0xb0e558
    // 0xb0e540: r17 = 4204
    //     0xb0e540: mov             x17, #0x106c
    // 0xb0e544: cmp             w1, w17
    // 0xb0e548: b.ne            #0xb0e554
    // 0xb0e54c: LoadField: d4 = r0->field_f
    //     0xb0e54c: ldur            d4, [x0, #0xf]
    // 0xb0e550: b               #0xb0e558
    // 0xb0e554: LoadField: d4 = r0->field_f
    //     0xb0e554: ldur            d4, [x0, #0xf]
    // 0xb0e558: r17 = 4202
    //     0xb0e558: mov             x17, #0x106a
    // 0xb0e55c: cmp             w1, w17
    // 0xb0e560: b.ne            #0xb0e56c
    // 0xb0e564: LoadField: d5 = r0->field_2f
    //     0xb0e564: ldur            d5, [x0, #0x2f]
    // 0xb0e568: b               #0xb0e584
    // 0xb0e56c: r17 = 4204
    //     0xb0e56c: mov             x17, #0x106c
    // 0xb0e570: cmp             w1, w17
    // 0xb0e574: b.ne            #0xb0e580
    // 0xb0e578: LoadField: d5 = r0->field_1f
    //     0xb0e578: ldur            d5, [x0, #0x1f]
    // 0xb0e57c: b               #0xb0e584
    // 0xb0e580: LoadField: d5 = r0->field_1f
    //     0xb0e580: ldur            d5, [x0, #0x1f]
    // 0xb0e584: r0 = inline_Allocate_Double()
    //     0xb0e584: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb0e588: add             x0, x0, #0x10
    //     0xb0e58c: cmp             x1, x0
    //     0xb0e590: b.ls            #0xb0e6b8
    //     0xb0e594: str             x0, [THR, #0x60]  ; THR::top
    //     0xb0e598: sub             x0, x0, #0xf
    //     0xb0e59c: mov             x1, #0xd108
    //     0xb0e5a0: movk            x1, #3, lsl #16
    //     0xb0e5a4: stur            x1, [x0, #-1]
    // 0xb0e5a8: StoreField: r0->field_7 = d0
    //     0xb0e5a8: stur            d0, [x0, #7]
    // 0xb0e5ac: r1 = inline_Allocate_Double()
    //     0xb0e5ac: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb0e5b0: add             x1, x1, #0x10
    //     0xb0e5b4: cmp             x2, x1
    //     0xb0e5b8: b.ls            #0xb0e6d8
    //     0xb0e5bc: str             x1, [THR, #0x60]  ; THR::top
    //     0xb0e5c0: sub             x1, x1, #0xf
    //     0xb0e5c4: mov             x2, #0xd108
    //     0xb0e5c8: movk            x2, #3, lsl #16
    //     0xb0e5cc: stur            x2, [x1, #-1]
    // 0xb0e5d0: StoreField: r1->field_7 = d1
    //     0xb0e5d0: stur            d1, [x1, #7]
    // 0xb0e5d4: r2 = inline_Allocate_Double()
    //     0xb0e5d4: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xb0e5d8: add             x2, x2, #0x10
    //     0xb0e5dc: cmp             x3, x2
    //     0xb0e5e0: b.ls            #0xb0e704
    //     0xb0e5e4: str             x2, [THR, #0x60]  ; THR::top
    //     0xb0e5e8: sub             x2, x2, #0xf
    //     0xb0e5ec: mov             x3, #0xd108
    //     0xb0e5f0: movk            x3, #3, lsl #16
    //     0xb0e5f4: stur            x3, [x2, #-1]
    // 0xb0e5f8: StoreField: r2->field_7 = d2
    //     0xb0e5f8: stur            d2, [x2, #7]
    // 0xb0e5fc: r3 = inline_Allocate_Double()
    //     0xb0e5fc: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xb0e600: add             x3, x3, #0x10
    //     0xb0e604: cmp             x4, x3
    //     0xb0e608: b.ls            #0xb0e728
    //     0xb0e60c: str             x3, [THR, #0x60]  ; THR::top
    //     0xb0e610: sub             x3, x3, #0xf
    //     0xb0e614: mov             x4, #0xd108
    //     0xb0e618: movk            x4, #3, lsl #16
    //     0xb0e61c: stur            x4, [x3, #-1]
    // 0xb0e620: StoreField: r3->field_7 = d3
    //     0xb0e620: stur            d3, [x3, #7]
    // 0xb0e624: r4 = inline_Allocate_Double()
    //     0xb0e624: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xb0e628: add             x4, x4, #0x10
    //     0xb0e62c: cmp             x5, x4
    //     0xb0e630: b.ls            #0xb0e754
    //     0xb0e634: str             x4, [THR, #0x60]  ; THR::top
    //     0xb0e638: sub             x4, x4, #0xf
    //     0xb0e63c: mov             x5, #0xd108
    //     0xb0e640: movk            x5, #3, lsl #16
    //     0xb0e644: stur            x5, [x4, #-1]
    // 0xb0e648: StoreField: r4->field_7 = d4
    //     0xb0e648: stur            d4, [x4, #7]
    // 0xb0e64c: r5 = inline_Allocate_Double()
    //     0xb0e64c: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0xb0e650: add             x5, x5, #0x10
    //     0xb0e654: cmp             x6, x5
    //     0xb0e658: b.ls            #0xb0e778
    //     0xb0e65c: str             x5, [THR, #0x60]  ; THR::top
    //     0xb0e660: sub             x5, x5, #0xf
    //     0xb0e664: mov             x6, #0xd108
    //     0xb0e668: movk            x6, #3, lsl #16
    //     0xb0e66c: stur            x6, [x5, #-1]
    // 0xb0e670: StoreField: r5->field_7 = d5
    //     0xb0e670: stur            d5, [x5, #7]
    // 0xb0e674: stp             x1, x0, [SP, #-0x10]!
    // 0xb0e678: stp             x3, x2, [SP, #-0x10]!
    // 0xb0e67c: stp             x5, x4, [SP, #-0x10]!
    // 0xb0e680: r4 = const [0, 0x6, 0x6, 0x6, null]
    //     0xb0e680: ldr             x4, [PP, #0x1228]  ; [pp+0x1228] List(5) [0, 0x6, 0x6, 0x6, Null]
    // 0xb0e684: r0 = hash()
    //     0xb0e684: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0e688: add             SP, SP, #0x30
    // 0xb0e68c: mov             x2, x0
    // 0xb0e690: r0 = BoxInt64Instr(r2)
    //     0xb0e690: sbfiz           x0, x2, #1, #0x1f
    //     0xb0e694: cmp             x2, x0, asr #1
    //     0xb0e698: b.eq            #0xb0e6a4
    //     0xb0e69c: bl              #0xd69bb8
    //     0xb0e6a0: stur            x2, [x0, #7]
    // 0xb0e6a4: LeaveFrame
    //     0xb0e6a4: mov             SP, fp
    //     0xb0e6a8: ldp             fp, lr, [SP], #0x10
    // 0xb0e6ac: ret
    //     0xb0e6ac: ret             
    // 0xb0e6b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0e6b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0e6b4: b               #0xb0e46c
    // 0xb0e6b8: stp             q4, q5, [SP, #-0x20]!
    // 0xb0e6bc: stp             q2, q3, [SP, #-0x20]!
    // 0xb0e6c0: stp             q0, q1, [SP, #-0x20]!
    // 0xb0e6c4: r0 = AllocateDouble()
    //     0xb0e6c4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0e6c8: ldp             q0, q1, [SP], #0x20
    // 0xb0e6cc: ldp             q2, q3, [SP], #0x20
    // 0xb0e6d0: ldp             q4, q5, [SP], #0x20
    // 0xb0e6d4: b               #0xb0e5a8
    // 0xb0e6d8: stp             q4, q5, [SP, #-0x20]!
    // 0xb0e6dc: stp             q2, q3, [SP, #-0x20]!
    // 0xb0e6e0: SaveReg d1
    //     0xb0e6e0: str             q1, [SP, #-0x10]!
    // 0xb0e6e4: SaveReg r0
    //     0xb0e6e4: str             x0, [SP, #-8]!
    // 0xb0e6e8: r0 = AllocateDouble()
    //     0xb0e6e8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0e6ec: mov             x1, x0
    // 0xb0e6f0: RestoreReg r0
    //     0xb0e6f0: ldr             x0, [SP], #8
    // 0xb0e6f4: RestoreReg d1
    //     0xb0e6f4: ldr             q1, [SP], #0x10
    // 0xb0e6f8: ldp             q2, q3, [SP], #0x20
    // 0xb0e6fc: ldp             q4, q5, [SP], #0x20
    // 0xb0e700: b               #0xb0e5d0
    // 0xb0e704: stp             q4, q5, [SP, #-0x20]!
    // 0xb0e708: stp             q2, q3, [SP, #-0x20]!
    // 0xb0e70c: stp             x0, x1, [SP, #-0x10]!
    // 0xb0e710: r0 = AllocateDouble()
    //     0xb0e710: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0e714: mov             x2, x0
    // 0xb0e718: ldp             x0, x1, [SP], #0x10
    // 0xb0e71c: ldp             q2, q3, [SP], #0x20
    // 0xb0e720: ldp             q4, q5, [SP], #0x20
    // 0xb0e724: b               #0xb0e5f8
    // 0xb0e728: stp             q4, q5, [SP, #-0x20]!
    // 0xb0e72c: SaveReg d3
    //     0xb0e72c: str             q3, [SP, #-0x10]!
    // 0xb0e730: stp             x1, x2, [SP, #-0x10]!
    // 0xb0e734: SaveReg r0
    //     0xb0e734: str             x0, [SP, #-8]!
    // 0xb0e738: r0 = AllocateDouble()
    //     0xb0e738: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0e73c: mov             x3, x0
    // 0xb0e740: RestoreReg r0
    //     0xb0e740: ldr             x0, [SP], #8
    // 0xb0e744: ldp             x1, x2, [SP], #0x10
    // 0xb0e748: RestoreReg d3
    //     0xb0e748: ldr             q3, [SP], #0x10
    // 0xb0e74c: ldp             q4, q5, [SP], #0x20
    // 0xb0e750: b               #0xb0e620
    // 0xb0e754: stp             q4, q5, [SP, #-0x20]!
    // 0xb0e758: stp             x2, x3, [SP, #-0x10]!
    // 0xb0e75c: stp             x0, x1, [SP, #-0x10]!
    // 0xb0e760: r0 = AllocateDouble()
    //     0xb0e760: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0e764: mov             x4, x0
    // 0xb0e768: ldp             x0, x1, [SP], #0x10
    // 0xb0e76c: ldp             x2, x3, [SP], #0x10
    // 0xb0e770: ldp             q4, q5, [SP], #0x20
    // 0xb0e774: b               #0xb0e648
    // 0xb0e778: SaveReg d5
    //     0xb0e778: str             q5, [SP, #-0x10]!
    // 0xb0e77c: stp             x3, x4, [SP, #-0x10]!
    // 0xb0e780: stp             x1, x2, [SP, #-0x10]!
    // 0xb0e784: SaveReg r0
    //     0xb0e784: str             x0, [SP, #-8]!
    // 0xb0e788: r0 = AllocateDouble()
    //     0xb0e788: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0e78c: mov             x5, x0
    // 0xb0e790: RestoreReg r0
    //     0xb0e790: ldr             x0, [SP], #8
    // 0xb0e794: ldp             x1, x2, [SP], #0x10
    // 0xb0e798: ldp             x3, x4, [SP], #0x10
    // 0xb0e79c: RestoreReg d5
    //     0xb0e79c: ldr             q5, [SP], #0x10
    // 0xb0e7a0: b               #0xb0e670
  }
  [closure] static EdgeInsetsGeometry? lerp(dynamic, EdgeInsetsGeometry?, EdgeInsetsGeometry?, double) {
    // ** addr: 0xbf0ed4, size: 0x44
    // 0xbf0ed4: EnterFrame
    //     0xbf0ed4: stp             fp, lr, [SP, #-0x10]!
    //     0xbf0ed8: mov             fp, SP
    // 0xbf0edc: CheckStackOverflow
    //     0xbf0edc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf0ee0: cmp             SP, x16
    //     0xbf0ee4: b.ls            #0xbf0f10
    // 0xbf0ee8: ldr             x16, [fp, #0x20]
    // 0xbf0eec: ldr             lr, [fp, #0x18]
    // 0xbf0ef0: stp             lr, x16, [SP, #-0x10]!
    // 0xbf0ef4: ldr             x16, [fp, #0x10]
    // 0xbf0ef8: SaveReg r16
    //     0xbf0ef8: str             x16, [SP, #-8]!
    // 0xbf0efc: r0 = lerp()
    //     0xbf0efc: bl              #0xbf0f18  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0xbf0f00: add             SP, SP, #0x18
    // 0xbf0f04: LeaveFrame
    //     0xbf0f04: mov             SP, fp
    //     0xbf0f08: ldp             fp, lr, [SP], #0x10
    // 0xbf0f0c: ret
    //     0xbf0f0c: ret             
    // 0xbf0f10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf0f10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf0f14: b               #0xbf0ee8
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf0f18, size: 0xba8
    // 0xbf0f18: EnterFrame
    //     0xbf0f18: stp             fp, lr, [SP, #-0x10]!
    //     0xbf0f1c: mov             fp, SP
    // 0xbf0f20: AllocStack(0x68)
    //     0xbf0f20: sub             SP, SP, #0x68
    // 0xbf0f24: CheckStackOverflow
    //     0xbf0f24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf0f28: cmp             SP, x16
    //     0xbf0f2c: b.ls            #0xbf188c
    // 0xbf0f30: ldr             x0, [fp, #0x20]
    // 0xbf0f34: cmp             w0, NULL
    // 0xbf0f38: b.ne            #0xbf0f58
    // 0xbf0f3c: ldr             x1, [fp, #0x18]
    // 0xbf0f40: cmp             w1, NULL
    // 0xbf0f44: b.ne            #0xbf0f5c
    // 0xbf0f48: r0 = Null
    //     0xbf0f48: mov             x0, NULL
    // 0xbf0f4c: LeaveFrame
    //     0xbf0f4c: mov             SP, fp
    //     0xbf0f50: ldp             fp, lr, [SP], #0x10
    // 0xbf0f54: ret
    //     0xbf0f54: ret             
    // 0xbf0f58: ldr             x1, [fp, #0x18]
    // 0xbf0f5c: cmp             w0, NULL
    // 0xbf0f60: b.ne            #0xbf10dc
    // 0xbf0f64: cmp             w1, NULL
    // 0xbf0f68: b.eq            #0xbf1894
    // 0xbf0f6c: r0 = LoadClassIdInstr(r1)
    //     0xbf0f6c: ldur            x0, [x1, #-1]
    //     0xbf0f70: ubfx            x0, x0, #0xc, #0x14
    // 0xbf0f74: lsl             x0, x0, #1
    // 0xbf0f78: r17 = 4202
    //     0xbf0f78: mov             x17, #0x106a
    // 0xbf0f7c: cmp             w0, w17
    // 0xbf0f80: b.ne            #0xbf100c
    // 0xbf0f84: ldr             x2, [fp, #0x10]
    // 0xbf0f88: LoadField: d0 = r1->field_7
    //     0xbf0f88: ldur            d0, [x1, #7]
    // 0xbf0f8c: LoadField: d1 = r2->field_7
    //     0xbf0f8c: ldur            d1, [x2, #7]
    // 0xbf0f90: fmul            d2, d0, d1
    // 0xbf0f94: stur            d2, [fp, #-0x68]
    // 0xbf0f98: LoadField: d0 = r1->field_f
    //     0xbf0f98: ldur            d0, [x1, #0xf]
    // 0xbf0f9c: fmul            d3, d0, d1
    // 0xbf0fa0: stur            d3, [fp, #-0x60]
    // 0xbf0fa4: LoadField: d0 = r1->field_17
    //     0xbf0fa4: ldur            d0, [x1, #0x17]
    // 0xbf0fa8: fmul            d4, d0, d1
    // 0xbf0fac: stur            d4, [fp, #-0x58]
    // 0xbf0fb0: LoadField: d0 = r1->field_1f
    //     0xbf0fb0: ldur            d0, [x1, #0x1f]
    // 0xbf0fb4: fmul            d5, d0, d1
    // 0xbf0fb8: stur            d5, [fp, #-0x50]
    // 0xbf0fbc: LoadField: d0 = r1->field_27
    //     0xbf0fbc: ldur            d0, [x1, #0x27]
    // 0xbf0fc0: fmul            d6, d0, d1
    // 0xbf0fc4: stur            d6, [fp, #-0x48]
    // 0xbf0fc8: LoadField: d0 = r1->field_2f
    //     0xbf0fc8: ldur            d0, [x1, #0x2f]
    // 0xbf0fcc: fmul            d7, d0, d1
    // 0xbf0fd0: stur            d7, [fp, #-0x40]
    // 0xbf0fd4: r0 = _MixedEdgeInsets()
    //     0xbf0fd4: bl              #0x84bee8  ; Allocate_MixedEdgeInsetsStub -> _MixedEdgeInsets (size=0x38)
    // 0xbf0fd8: ldur            d0, [fp, #-0x68]
    // 0xbf0fdc: StoreField: r0->field_7 = d0
    //     0xbf0fdc: stur            d0, [x0, #7]
    // 0xbf0fe0: ldur            d0, [fp, #-0x60]
    // 0xbf0fe4: StoreField: r0->field_f = d0
    //     0xbf0fe4: stur            d0, [x0, #0xf]
    // 0xbf0fe8: ldur            d0, [fp, #-0x58]
    // 0xbf0fec: StoreField: r0->field_17 = d0
    //     0xbf0fec: stur            d0, [x0, #0x17]
    // 0xbf0ff0: ldur            d0, [fp, #-0x50]
    // 0xbf0ff4: StoreField: r0->field_1f = d0
    //     0xbf0ff4: stur            d0, [x0, #0x1f]
    // 0xbf0ff8: ldur            d0, [fp, #-0x48]
    // 0xbf0ffc: StoreField: r0->field_27 = d0
    //     0xbf0ffc: stur            d0, [x0, #0x27]
    // 0xbf1000: ldur            d0, [fp, #-0x40]
    // 0xbf1004: StoreField: r0->field_2f = d0
    //     0xbf1004: stur            d0, [x0, #0x2f]
    // 0xbf1008: b               #0xbf10d0
    // 0xbf100c: ldr             x2, [fp, #0x10]
    // 0xbf1010: r17 = 4204
    //     0xbf1010: mov             x17, #0x106c
    // 0xbf1014: cmp             w0, w17
    // 0xbf1018: b.ne            #0xbf1078
    // 0xbf101c: LoadField: d0 = r1->field_7
    //     0xbf101c: ldur            d0, [x1, #7]
    // 0xbf1020: LoadField: d1 = r2->field_7
    //     0xbf1020: ldur            d1, [x2, #7]
    // 0xbf1024: fmul            d2, d0, d1
    // 0xbf1028: stur            d2, [fp, #-0x58]
    // 0xbf102c: LoadField: d0 = r1->field_f
    //     0xbf102c: ldur            d0, [x1, #0xf]
    // 0xbf1030: fmul            d3, d0, d1
    // 0xbf1034: stur            d3, [fp, #-0x50]
    // 0xbf1038: LoadField: d0 = r1->field_17
    //     0xbf1038: ldur            d0, [x1, #0x17]
    // 0xbf103c: fmul            d4, d0, d1
    // 0xbf1040: stur            d4, [fp, #-0x48]
    // 0xbf1044: LoadField: d0 = r1->field_1f
    //     0xbf1044: ldur            d0, [x1, #0x1f]
    // 0xbf1048: fmul            d5, d0, d1
    // 0xbf104c: stur            d5, [fp, #-0x40]
    // 0xbf1050: r0 = EdgeInsetsDirectional()
    //     0xbf1050: bl              #0x84b6f4  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xbf1054: ldur            d0, [fp, #-0x58]
    // 0xbf1058: StoreField: r0->field_7 = d0
    //     0xbf1058: stur            d0, [x0, #7]
    // 0xbf105c: ldur            d0, [fp, #-0x50]
    // 0xbf1060: StoreField: r0->field_f = d0
    //     0xbf1060: stur            d0, [x0, #0xf]
    // 0xbf1064: ldur            d0, [fp, #-0x48]
    // 0xbf1068: StoreField: r0->field_17 = d0
    //     0xbf1068: stur            d0, [x0, #0x17]
    // 0xbf106c: ldur            d0, [fp, #-0x40]
    // 0xbf1070: StoreField: r0->field_1f = d0
    //     0xbf1070: stur            d0, [x0, #0x1f]
    // 0xbf1074: b               #0xbf10d0
    // 0xbf1078: LoadField: d0 = r1->field_7
    //     0xbf1078: ldur            d0, [x1, #7]
    // 0xbf107c: LoadField: d1 = r2->field_7
    //     0xbf107c: ldur            d1, [x2, #7]
    // 0xbf1080: fmul            d2, d0, d1
    // 0xbf1084: stur            d2, [fp, #-0x58]
    // 0xbf1088: LoadField: d0 = r1->field_f
    //     0xbf1088: ldur            d0, [x1, #0xf]
    // 0xbf108c: fmul            d3, d0, d1
    // 0xbf1090: stur            d3, [fp, #-0x50]
    // 0xbf1094: LoadField: d0 = r1->field_17
    //     0xbf1094: ldur            d0, [x1, #0x17]
    // 0xbf1098: fmul            d4, d0, d1
    // 0xbf109c: stur            d4, [fp, #-0x48]
    // 0xbf10a0: LoadField: d0 = r1->field_1f
    //     0xbf10a0: ldur            d0, [x1, #0x1f]
    // 0xbf10a4: fmul            d5, d0, d1
    // 0xbf10a8: stur            d5, [fp, #-0x40]
    // 0xbf10ac: r0 = EdgeInsets()
    //     0xbf10ac: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xbf10b0: ldur            d0, [fp, #-0x58]
    // 0xbf10b4: StoreField: r0->field_7 = d0
    //     0xbf10b4: stur            d0, [x0, #7]
    // 0xbf10b8: ldur            d0, [fp, #-0x50]
    // 0xbf10bc: StoreField: r0->field_f = d0
    //     0xbf10bc: stur            d0, [x0, #0xf]
    // 0xbf10c0: ldur            d0, [fp, #-0x48]
    // 0xbf10c4: StoreField: r0->field_17 = d0
    //     0xbf10c4: stur            d0, [x0, #0x17]
    // 0xbf10c8: ldur            d0, [fp, #-0x40]
    // 0xbf10cc: StoreField: r0->field_1f = d0
    //     0xbf10cc: stur            d0, [x0, #0x1f]
    // 0xbf10d0: LeaveFrame
    //     0xbf10d0: mov             SP, fp
    //     0xbf10d4: ldp             fp, lr, [SP], #0x10
    // 0xbf10d8: ret
    //     0xbf10d8: ret             
    // 0xbf10dc: ldr             x2, [fp, #0x10]
    // 0xbf10e0: cmp             w1, NULL
    // 0xbf10e4: b.ne            #0xbf1250
    // 0xbf10e8: d0 = 1.000000
    //     0xbf10e8: fmov            d0, #1.00000000
    // 0xbf10ec: LoadField: d1 = r2->field_7
    //     0xbf10ec: ldur            d1, [x2, #7]
    // 0xbf10f0: fsub            d2, d0, d1
    // 0xbf10f4: r1 = LoadClassIdInstr(r0)
    //     0xbf10f4: ldur            x1, [x0, #-1]
    //     0xbf10f8: ubfx            x1, x1, #0xc, #0x14
    // 0xbf10fc: lsl             x1, x1, #1
    // 0xbf1100: r17 = 4202
    //     0xbf1100: mov             x17, #0x106a
    // 0xbf1104: cmp             w1, w17
    // 0xbf1108: b.ne            #0xbf118c
    // 0xbf110c: LoadField: d0 = r0->field_7
    //     0xbf110c: ldur            d0, [x0, #7]
    // 0xbf1110: fmul            d1, d0, d2
    // 0xbf1114: stur            d1, [fp, #-0x68]
    // 0xbf1118: LoadField: d0 = r0->field_f
    //     0xbf1118: ldur            d0, [x0, #0xf]
    // 0xbf111c: fmul            d3, d0, d2
    // 0xbf1120: stur            d3, [fp, #-0x60]
    // 0xbf1124: LoadField: d0 = r0->field_17
    //     0xbf1124: ldur            d0, [x0, #0x17]
    // 0xbf1128: fmul            d4, d0, d2
    // 0xbf112c: stur            d4, [fp, #-0x58]
    // 0xbf1130: LoadField: d0 = r0->field_1f
    //     0xbf1130: ldur            d0, [x0, #0x1f]
    // 0xbf1134: fmul            d5, d0, d2
    // 0xbf1138: stur            d5, [fp, #-0x50]
    // 0xbf113c: LoadField: d0 = r0->field_27
    //     0xbf113c: ldur            d0, [x0, #0x27]
    // 0xbf1140: fmul            d6, d0, d2
    // 0xbf1144: stur            d6, [fp, #-0x48]
    // 0xbf1148: LoadField: d0 = r0->field_2f
    //     0xbf1148: ldur            d0, [x0, #0x2f]
    // 0xbf114c: fmul            d7, d0, d2
    // 0xbf1150: stur            d7, [fp, #-0x40]
    // 0xbf1154: r0 = _MixedEdgeInsets()
    //     0xbf1154: bl              #0x84bee8  ; Allocate_MixedEdgeInsetsStub -> _MixedEdgeInsets (size=0x38)
    // 0xbf1158: ldur            d0, [fp, #-0x68]
    // 0xbf115c: StoreField: r0->field_7 = d0
    //     0xbf115c: stur            d0, [x0, #7]
    // 0xbf1160: ldur            d0, [fp, #-0x60]
    // 0xbf1164: StoreField: r0->field_f = d0
    //     0xbf1164: stur            d0, [x0, #0xf]
    // 0xbf1168: ldur            d0, [fp, #-0x58]
    // 0xbf116c: StoreField: r0->field_17 = d0
    //     0xbf116c: stur            d0, [x0, #0x17]
    // 0xbf1170: ldur            d0, [fp, #-0x50]
    // 0xbf1174: StoreField: r0->field_1f = d0
    //     0xbf1174: stur            d0, [x0, #0x1f]
    // 0xbf1178: ldur            d0, [fp, #-0x48]
    // 0xbf117c: StoreField: r0->field_27 = d0
    //     0xbf117c: stur            d0, [x0, #0x27]
    // 0xbf1180: ldur            d0, [fp, #-0x40]
    // 0xbf1184: StoreField: r0->field_2f = d0
    //     0xbf1184: stur            d0, [x0, #0x2f]
    // 0xbf1188: b               #0xbf1244
    // 0xbf118c: r17 = 4204
    //     0xbf118c: mov             x17, #0x106c
    // 0xbf1190: cmp             w1, w17
    // 0xbf1194: b.ne            #0xbf11f0
    // 0xbf1198: LoadField: d0 = r0->field_7
    //     0xbf1198: ldur            d0, [x0, #7]
    // 0xbf119c: fmul            d1, d0, d2
    // 0xbf11a0: stur            d1, [fp, #-0x58]
    // 0xbf11a4: LoadField: d0 = r0->field_f
    //     0xbf11a4: ldur            d0, [x0, #0xf]
    // 0xbf11a8: fmul            d3, d0, d2
    // 0xbf11ac: stur            d3, [fp, #-0x50]
    // 0xbf11b0: LoadField: d0 = r0->field_17
    //     0xbf11b0: ldur            d0, [x0, #0x17]
    // 0xbf11b4: fmul            d4, d0, d2
    // 0xbf11b8: stur            d4, [fp, #-0x48]
    // 0xbf11bc: LoadField: d0 = r0->field_1f
    //     0xbf11bc: ldur            d0, [x0, #0x1f]
    // 0xbf11c0: fmul            d5, d0, d2
    // 0xbf11c4: stur            d5, [fp, #-0x40]
    // 0xbf11c8: r0 = EdgeInsetsDirectional()
    //     0xbf11c8: bl              #0x84b6f4  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xbf11cc: ldur            d0, [fp, #-0x58]
    // 0xbf11d0: StoreField: r0->field_7 = d0
    //     0xbf11d0: stur            d0, [x0, #7]
    // 0xbf11d4: ldur            d0, [fp, #-0x50]
    // 0xbf11d8: StoreField: r0->field_f = d0
    //     0xbf11d8: stur            d0, [x0, #0xf]
    // 0xbf11dc: ldur            d0, [fp, #-0x48]
    // 0xbf11e0: StoreField: r0->field_17 = d0
    //     0xbf11e0: stur            d0, [x0, #0x17]
    // 0xbf11e4: ldur            d0, [fp, #-0x40]
    // 0xbf11e8: StoreField: r0->field_1f = d0
    //     0xbf11e8: stur            d0, [x0, #0x1f]
    // 0xbf11ec: b               #0xbf1244
    // 0xbf11f0: LoadField: d0 = r0->field_7
    //     0xbf11f0: ldur            d0, [x0, #7]
    // 0xbf11f4: fmul            d1, d0, d2
    // 0xbf11f8: stur            d1, [fp, #-0x58]
    // 0xbf11fc: LoadField: d0 = r0->field_f
    //     0xbf11fc: ldur            d0, [x0, #0xf]
    // 0xbf1200: fmul            d3, d0, d2
    // 0xbf1204: stur            d3, [fp, #-0x50]
    // 0xbf1208: LoadField: d0 = r0->field_17
    //     0xbf1208: ldur            d0, [x0, #0x17]
    // 0xbf120c: fmul            d4, d0, d2
    // 0xbf1210: stur            d4, [fp, #-0x48]
    // 0xbf1214: LoadField: d0 = r0->field_1f
    //     0xbf1214: ldur            d0, [x0, #0x1f]
    // 0xbf1218: fmul            d5, d0, d2
    // 0xbf121c: stur            d5, [fp, #-0x40]
    // 0xbf1220: r0 = EdgeInsets()
    //     0xbf1220: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xbf1224: ldur            d0, [fp, #-0x58]
    // 0xbf1228: StoreField: r0->field_7 = d0
    //     0xbf1228: stur            d0, [x0, #7]
    // 0xbf122c: ldur            d0, [fp, #-0x50]
    // 0xbf1230: StoreField: r0->field_f = d0
    //     0xbf1230: stur            d0, [x0, #0xf]
    // 0xbf1234: ldur            d0, [fp, #-0x48]
    // 0xbf1238: StoreField: r0->field_17 = d0
    //     0xbf1238: stur            d0, [x0, #0x17]
    // 0xbf123c: ldur            d0, [fp, #-0x40]
    // 0xbf1240: StoreField: r0->field_1f = d0
    //     0xbf1240: stur            d0, [x0, #0x1f]
    // 0xbf1244: LeaveFrame
    //     0xbf1244: mov             SP, fp
    //     0xbf1248: ldp             fp, lr, [SP], #0x10
    // 0xbf124c: ret
    //     0xbf124c: ret             
    // 0xbf1250: r3 = LoadClassIdInstr(r0)
    //     0xbf1250: ldur            x3, [x0, #-1]
    //     0xbf1254: ubfx            x3, x3, #0xc, #0x14
    // 0xbf1258: lsl             x3, x3, #1
    // 0xbf125c: stur            x3, [fp, #-0x10]
    // 0xbf1260: r17 = 4206
    //     0xbf1260: mov             x17, #0x106e
    // 0xbf1264: cmp             w3, w17
    // 0xbf1268: b.ne            #0xbf12a4
    // 0xbf126c: r4 = LoadClassIdInstr(r1)
    //     0xbf126c: ldur            x4, [x1, #-1]
    //     0xbf1270: ubfx            x4, x4, #0xc, #0x14
    // 0xbf1274: lsl             x4, x4, #1
    // 0xbf1278: r17 = 4206
    //     0xbf1278: mov             x17, #0x106e
    // 0xbf127c: cmp             w4, w17
    // 0xbf1280: b.ne            #0xbf12a4
    // 0xbf1284: LoadField: d0 = r2->field_7
    //     0xbf1284: ldur            d0, [x2, #7]
    // 0xbf1288: stp             x1, x0, [SP, #-0x10]!
    // 0xbf128c: SaveReg d0
    //     0xbf128c: str             d0, [SP, #-8]!
    // 0xbf1290: r0 = lerp()
    //     0xbf1290: bl              #0xbf1e98  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::lerp
    // 0xbf1294: add             SP, SP, #0x18
    // 0xbf1298: LeaveFrame
    //     0xbf1298: mov             SP, fp
    //     0xbf129c: ldp             fp, lr, [SP], #0x10
    // 0xbf12a0: ret
    //     0xbf12a0: ret             
    // 0xbf12a4: r17 = 4204
    //     0xbf12a4: mov             x17, #0x106c
    // 0xbf12a8: cmp             w3, w17
    // 0xbf12ac: b.ne            #0xbf12e8
    // 0xbf12b0: r4 = LoadClassIdInstr(r1)
    //     0xbf12b0: ldur            x4, [x1, #-1]
    //     0xbf12b4: ubfx            x4, x4, #0xc, #0x14
    // 0xbf12b8: lsl             x4, x4, #1
    // 0xbf12bc: r17 = 4204
    //     0xbf12bc: mov             x17, #0x106c
    // 0xbf12c0: cmp             w4, w17
    // 0xbf12c4: b.ne            #0xbf12e8
    // 0xbf12c8: LoadField: d0 = r2->field_7
    //     0xbf12c8: ldur            d0, [x2, #7]
    // 0xbf12cc: stp             x1, x0, [SP, #-0x10]!
    // 0xbf12d0: SaveReg d0
    //     0xbf12d0: str             d0, [SP, #-8]!
    // 0xbf12d4: r0 = lerp()
    //     0xbf12d4: bl              #0xbf1ac0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsDirectional::lerp
    // 0xbf12d8: add             SP, SP, #0x18
    // 0xbf12dc: LeaveFrame
    //     0xbf12dc: mov             SP, fp
    //     0xbf12e0: ldp             fp, lr, [SP], #0x10
    // 0xbf12e4: ret
    //     0xbf12e4: ret             
    // 0xbf12e8: r17 = 4202
    //     0xbf12e8: mov             x17, #0x106a
    // 0xbf12ec: cmp             w3, w17
    // 0xbf12f0: b.ne            #0xbf12fc
    // 0xbf12f4: LoadField: d0 = r0->field_7
    //     0xbf12f4: ldur            d0, [x0, #7]
    // 0xbf12f8: b               #0xbf1314
    // 0xbf12fc: r17 = 4204
    //     0xbf12fc: mov             x17, #0x106c
    // 0xbf1300: cmp             w3, w17
    // 0xbf1304: b.ne            #0xbf1310
    // 0xbf1308: d0 = 0.000000
    //     0xbf1308: eor             v0.16b, v0.16b, v0.16b
    // 0xbf130c: b               #0xbf1314
    // 0xbf1310: LoadField: d0 = r0->field_7
    //     0xbf1310: ldur            d0, [x0, #7]
    // 0xbf1314: r4 = LoadClassIdInstr(r1)
    //     0xbf1314: ldur            x4, [x1, #-1]
    //     0xbf1318: ubfx            x4, x4, #0xc, #0x14
    // 0xbf131c: lsl             x4, x4, #1
    // 0xbf1320: stur            x4, [fp, #-8]
    // 0xbf1324: r17 = 4202
    //     0xbf1324: mov             x17, #0x106a
    // 0xbf1328: cmp             w4, w17
    // 0xbf132c: b.ne            #0xbf1338
    // 0xbf1330: LoadField: d1 = r1->field_7
    //     0xbf1330: ldur            d1, [x1, #7]
    // 0xbf1334: b               #0xbf1350
    // 0xbf1338: r17 = 4204
    //     0xbf1338: mov             x17, #0x106c
    // 0xbf133c: cmp             w4, w17
    // 0xbf1340: b.ne            #0xbf134c
    // 0xbf1344: d1 = 0.000000
    //     0xbf1344: eor             v1.16b, v1.16b, v1.16b
    // 0xbf1348: b               #0xbf1350
    // 0xbf134c: LoadField: d1 = r1->field_7
    //     0xbf134c: ldur            d1, [x1, #7]
    // 0xbf1350: r5 = inline_Allocate_Double()
    //     0xbf1350: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0xbf1354: add             x5, x5, #0x10
    //     0xbf1358: cmp             x6, x5
    //     0xbf135c: b.ls            #0xbf1898
    //     0xbf1360: str             x5, [THR, #0x60]  ; THR::top
    //     0xbf1364: sub             x5, x5, #0xf
    //     0xbf1368: mov             x6, #0xd108
    //     0xbf136c: movk            x6, #3, lsl #16
    //     0xbf1370: stur            x6, [x5, #-1]
    // 0xbf1374: StoreField: r5->field_7 = d0
    //     0xbf1374: stur            d0, [x5, #7]
    // 0xbf1378: r6 = inline_Allocate_Double()
    //     0xbf1378: ldp             x6, x7, [THR, #0x60]  ; THR::top
    //     0xbf137c: add             x6, x6, #0x10
    //     0xbf1380: cmp             x7, x6
    //     0xbf1384: b.ls            #0xbf18c4
    //     0xbf1388: str             x6, [THR, #0x60]  ; THR::top
    //     0xbf138c: sub             x6, x6, #0xf
    //     0xbf1390: mov             x7, #0xd108
    //     0xbf1394: movk            x7, #3, lsl #16
    //     0xbf1398: stur            x7, [x6, #-1]
    // 0xbf139c: StoreField: r6->field_7 = d1
    //     0xbf139c: stur            d1, [x6, #7]
    // 0xbf13a0: stp             x6, x5, [SP, #-0x10]!
    // 0xbf13a4: SaveReg r2
    //     0xbf13a4: str             x2, [SP, #-8]!
    // 0xbf13a8: r0 = lerpDouble()
    //     0xbf13a8: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf13ac: add             SP, SP, #0x18
    // 0xbf13b0: stur            x0, [fp, #-0x18]
    // 0xbf13b4: cmp             w0, NULL
    // 0xbf13b8: b.eq            #0xbf18f0
    // 0xbf13bc: ldur            x1, [fp, #-0x10]
    // 0xbf13c0: r17 = 4202
    //     0xbf13c0: mov             x17, #0x106a
    // 0xbf13c4: cmp             w1, w17
    // 0xbf13c8: b.ne            #0xbf13d8
    // 0xbf13cc: ldr             x2, [fp, #0x20]
    // 0xbf13d0: LoadField: d0 = r2->field_f
    //     0xbf13d0: ldur            d0, [x2, #0xf]
    // 0xbf13d4: b               #0xbf13f4
    // 0xbf13d8: ldr             x2, [fp, #0x20]
    // 0xbf13dc: r17 = 4204
    //     0xbf13dc: mov             x17, #0x106c
    // 0xbf13e0: cmp             w1, w17
    // 0xbf13e4: b.ne            #0xbf13f0
    // 0xbf13e8: d0 = 0.000000
    //     0xbf13e8: eor             v0.16b, v0.16b, v0.16b
    // 0xbf13ec: b               #0xbf13f4
    // 0xbf13f0: LoadField: d0 = r2->field_17
    //     0xbf13f0: ldur            d0, [x2, #0x17]
    // 0xbf13f4: ldur            x3, [fp, #-8]
    // 0xbf13f8: r17 = 4202
    //     0xbf13f8: mov             x17, #0x106a
    // 0xbf13fc: cmp             w3, w17
    // 0xbf1400: b.ne            #0xbf1410
    // 0xbf1404: ldr             x4, [fp, #0x18]
    // 0xbf1408: LoadField: d1 = r4->field_f
    //     0xbf1408: ldur            d1, [x4, #0xf]
    // 0xbf140c: b               #0xbf142c
    // 0xbf1410: ldr             x4, [fp, #0x18]
    // 0xbf1414: r17 = 4204
    //     0xbf1414: mov             x17, #0x106c
    // 0xbf1418: cmp             w3, w17
    // 0xbf141c: b.ne            #0xbf1428
    // 0xbf1420: d1 = 0.000000
    //     0xbf1420: eor             v1.16b, v1.16b, v1.16b
    // 0xbf1424: b               #0xbf142c
    // 0xbf1428: LoadField: d1 = r4->field_17
    //     0xbf1428: ldur            d1, [x4, #0x17]
    // 0xbf142c: r5 = inline_Allocate_Double()
    //     0xbf142c: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0xbf1430: add             x5, x5, #0x10
    //     0xbf1434: cmp             x6, x5
    //     0xbf1438: b.ls            #0xbf18f4
    //     0xbf143c: str             x5, [THR, #0x60]  ; THR::top
    //     0xbf1440: sub             x5, x5, #0xf
    //     0xbf1444: mov             x6, #0xd108
    //     0xbf1448: movk            x6, #3, lsl #16
    //     0xbf144c: stur            x6, [x5, #-1]
    // 0xbf1450: StoreField: r5->field_7 = d0
    //     0xbf1450: stur            d0, [x5, #7]
    // 0xbf1454: r6 = inline_Allocate_Double()
    //     0xbf1454: ldp             x6, x7, [THR, #0x60]  ; THR::top
    //     0xbf1458: add             x6, x6, #0x10
    //     0xbf145c: cmp             x7, x6
    //     0xbf1460: b.ls            #0xbf1920
    //     0xbf1464: str             x6, [THR, #0x60]  ; THR::top
    //     0xbf1468: sub             x6, x6, #0xf
    //     0xbf146c: mov             x7, #0xd108
    //     0xbf1470: movk            x7, #3, lsl #16
    //     0xbf1474: stur            x7, [x6, #-1]
    // 0xbf1478: StoreField: r6->field_7 = d1
    //     0xbf1478: stur            d1, [x6, #7]
    // 0xbf147c: stp             x6, x5, [SP, #-0x10]!
    // 0xbf1480: ldr             x16, [fp, #0x10]
    // 0xbf1484: SaveReg r16
    //     0xbf1484: str             x16, [SP, #-8]!
    // 0xbf1488: r0 = lerpDouble()
    //     0xbf1488: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf148c: add             SP, SP, #0x18
    // 0xbf1490: stur            x0, [fp, #-0x20]
    // 0xbf1494: cmp             w0, NULL
    // 0xbf1498: b.eq            #0xbf194c
    // 0xbf149c: ldur            x1, [fp, #-0x10]
    // 0xbf14a0: r17 = 4202
    //     0xbf14a0: mov             x17, #0x106a
    // 0xbf14a4: cmp             w1, w17
    // 0xbf14a8: b.ne            #0xbf14b8
    // 0xbf14ac: ldr             x2, [fp, #0x20]
    // 0xbf14b0: LoadField: d0 = r2->field_17
    //     0xbf14b0: ldur            d0, [x2, #0x17]
    // 0xbf14b4: b               #0xbf14d4
    // 0xbf14b8: ldr             x2, [fp, #0x20]
    // 0xbf14bc: r17 = 4204
    //     0xbf14bc: mov             x17, #0x106c
    // 0xbf14c0: cmp             w1, w17
    // 0xbf14c4: b.ne            #0xbf14d0
    // 0xbf14c8: LoadField: d0 = r2->field_7
    //     0xbf14c8: ldur            d0, [x2, #7]
    // 0xbf14cc: b               #0xbf14d4
    // 0xbf14d0: d0 = 0.000000
    //     0xbf14d0: eor             v0.16b, v0.16b, v0.16b
    // 0xbf14d4: ldur            x3, [fp, #-8]
    // 0xbf14d8: r17 = 4202
    //     0xbf14d8: mov             x17, #0x106a
    // 0xbf14dc: cmp             w3, w17
    // 0xbf14e0: b.ne            #0xbf14f0
    // 0xbf14e4: ldr             x4, [fp, #0x18]
    // 0xbf14e8: LoadField: d1 = r4->field_17
    //     0xbf14e8: ldur            d1, [x4, #0x17]
    // 0xbf14ec: b               #0xbf150c
    // 0xbf14f0: ldr             x4, [fp, #0x18]
    // 0xbf14f4: r17 = 4204
    //     0xbf14f4: mov             x17, #0x106c
    // 0xbf14f8: cmp             w3, w17
    // 0xbf14fc: b.ne            #0xbf1508
    // 0xbf1500: LoadField: d1 = r4->field_7
    //     0xbf1500: ldur            d1, [x4, #7]
    // 0xbf1504: b               #0xbf150c
    // 0xbf1508: d1 = 0.000000
    //     0xbf1508: eor             v1.16b, v1.16b, v1.16b
    // 0xbf150c: r5 = inline_Allocate_Double()
    //     0xbf150c: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0xbf1510: add             x5, x5, #0x10
    //     0xbf1514: cmp             x6, x5
    //     0xbf1518: b.ls            #0xbf1950
    //     0xbf151c: str             x5, [THR, #0x60]  ; THR::top
    //     0xbf1520: sub             x5, x5, #0xf
    //     0xbf1524: mov             x6, #0xd108
    //     0xbf1528: movk            x6, #3, lsl #16
    //     0xbf152c: stur            x6, [x5, #-1]
    // 0xbf1530: StoreField: r5->field_7 = d0
    //     0xbf1530: stur            d0, [x5, #7]
    // 0xbf1534: r6 = inline_Allocate_Double()
    //     0xbf1534: ldp             x6, x7, [THR, #0x60]  ; THR::top
    //     0xbf1538: add             x6, x6, #0x10
    //     0xbf153c: cmp             x7, x6
    //     0xbf1540: b.ls            #0xbf197c
    //     0xbf1544: str             x6, [THR, #0x60]  ; THR::top
    //     0xbf1548: sub             x6, x6, #0xf
    //     0xbf154c: mov             x7, #0xd108
    //     0xbf1550: movk            x7, #3, lsl #16
    //     0xbf1554: stur            x7, [x6, #-1]
    // 0xbf1558: StoreField: r6->field_7 = d1
    //     0xbf1558: stur            d1, [x6, #7]
    // 0xbf155c: stp             x6, x5, [SP, #-0x10]!
    // 0xbf1560: ldr             x16, [fp, #0x10]
    // 0xbf1564: SaveReg r16
    //     0xbf1564: str             x16, [SP, #-8]!
    // 0xbf1568: r0 = lerpDouble()
    //     0xbf1568: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf156c: add             SP, SP, #0x18
    // 0xbf1570: stur            x0, [fp, #-0x28]
    // 0xbf1574: cmp             w0, NULL
    // 0xbf1578: b.eq            #0xbf19a8
    // 0xbf157c: ldur            x1, [fp, #-0x10]
    // 0xbf1580: r17 = 4202
    //     0xbf1580: mov             x17, #0x106a
    // 0xbf1584: cmp             w1, w17
    // 0xbf1588: b.ne            #0xbf1598
    // 0xbf158c: ldr             x2, [fp, #0x20]
    // 0xbf1590: LoadField: d0 = r2->field_1f
    //     0xbf1590: ldur            d0, [x2, #0x1f]
    // 0xbf1594: b               #0xbf15b4
    // 0xbf1598: ldr             x2, [fp, #0x20]
    // 0xbf159c: r17 = 4204
    //     0xbf159c: mov             x17, #0x106c
    // 0xbf15a0: cmp             w1, w17
    // 0xbf15a4: b.ne            #0xbf15b0
    // 0xbf15a8: LoadField: d0 = r2->field_17
    //     0xbf15a8: ldur            d0, [x2, #0x17]
    // 0xbf15ac: b               #0xbf15b4
    // 0xbf15b0: d0 = 0.000000
    //     0xbf15b0: eor             v0.16b, v0.16b, v0.16b
    // 0xbf15b4: ldur            x3, [fp, #-8]
    // 0xbf15b8: r17 = 4202
    //     0xbf15b8: mov             x17, #0x106a
    // 0xbf15bc: cmp             w3, w17
    // 0xbf15c0: b.ne            #0xbf15d0
    // 0xbf15c4: ldr             x4, [fp, #0x18]
    // 0xbf15c8: LoadField: d1 = r4->field_1f
    //     0xbf15c8: ldur            d1, [x4, #0x1f]
    // 0xbf15cc: b               #0xbf15ec
    // 0xbf15d0: ldr             x4, [fp, #0x18]
    // 0xbf15d4: r17 = 4204
    //     0xbf15d4: mov             x17, #0x106c
    // 0xbf15d8: cmp             w3, w17
    // 0xbf15dc: b.ne            #0xbf15e8
    // 0xbf15e0: LoadField: d1 = r4->field_17
    //     0xbf15e0: ldur            d1, [x4, #0x17]
    // 0xbf15e4: b               #0xbf15ec
    // 0xbf15e8: d1 = 0.000000
    //     0xbf15e8: eor             v1.16b, v1.16b, v1.16b
    // 0xbf15ec: r5 = inline_Allocate_Double()
    //     0xbf15ec: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0xbf15f0: add             x5, x5, #0x10
    //     0xbf15f4: cmp             x6, x5
    //     0xbf15f8: b.ls            #0xbf19ac
    //     0xbf15fc: str             x5, [THR, #0x60]  ; THR::top
    //     0xbf1600: sub             x5, x5, #0xf
    //     0xbf1604: mov             x6, #0xd108
    //     0xbf1608: movk            x6, #3, lsl #16
    //     0xbf160c: stur            x6, [x5, #-1]
    // 0xbf1610: StoreField: r5->field_7 = d0
    //     0xbf1610: stur            d0, [x5, #7]
    // 0xbf1614: r6 = inline_Allocate_Double()
    //     0xbf1614: ldp             x6, x7, [THR, #0x60]  ; THR::top
    //     0xbf1618: add             x6, x6, #0x10
    //     0xbf161c: cmp             x7, x6
    //     0xbf1620: b.ls            #0xbf19d8
    //     0xbf1624: str             x6, [THR, #0x60]  ; THR::top
    //     0xbf1628: sub             x6, x6, #0xf
    //     0xbf162c: mov             x7, #0xd108
    //     0xbf1630: movk            x7, #3, lsl #16
    //     0xbf1634: stur            x7, [x6, #-1]
    // 0xbf1638: StoreField: r6->field_7 = d1
    //     0xbf1638: stur            d1, [x6, #7]
    // 0xbf163c: stp             x6, x5, [SP, #-0x10]!
    // 0xbf1640: ldr             x16, [fp, #0x10]
    // 0xbf1644: SaveReg r16
    //     0xbf1644: str             x16, [SP, #-8]!
    // 0xbf1648: r0 = lerpDouble()
    //     0xbf1648: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf164c: add             SP, SP, #0x18
    // 0xbf1650: stur            x0, [fp, #-0x30]
    // 0xbf1654: cmp             w0, NULL
    // 0xbf1658: b.eq            #0xbf1a04
    // 0xbf165c: ldur            x1, [fp, #-0x10]
    // 0xbf1660: r17 = 4202
    //     0xbf1660: mov             x17, #0x106a
    // 0xbf1664: cmp             w1, w17
    // 0xbf1668: b.ne            #0xbf1678
    // 0xbf166c: ldr             x2, [fp, #0x20]
    // 0xbf1670: LoadField: d0 = r2->field_27
    //     0xbf1670: ldur            d0, [x2, #0x27]
    // 0xbf1674: b               #0xbf1694
    // 0xbf1678: ldr             x2, [fp, #0x20]
    // 0xbf167c: r17 = 4204
    //     0xbf167c: mov             x17, #0x106c
    // 0xbf1680: cmp             w1, w17
    // 0xbf1684: b.ne            #0xbf1690
    // 0xbf1688: LoadField: d0 = r2->field_f
    //     0xbf1688: ldur            d0, [x2, #0xf]
    // 0xbf168c: b               #0xbf1694
    // 0xbf1690: LoadField: d0 = r2->field_f
    //     0xbf1690: ldur            d0, [x2, #0xf]
    // 0xbf1694: ldur            x3, [fp, #-8]
    // 0xbf1698: r17 = 4202
    //     0xbf1698: mov             x17, #0x106a
    // 0xbf169c: cmp             w3, w17
    // 0xbf16a0: b.ne            #0xbf16b0
    // 0xbf16a4: ldr             x4, [fp, #0x18]
    // 0xbf16a8: LoadField: d1 = r4->field_27
    //     0xbf16a8: ldur            d1, [x4, #0x27]
    // 0xbf16ac: b               #0xbf16cc
    // 0xbf16b0: ldr             x4, [fp, #0x18]
    // 0xbf16b4: r17 = 4204
    //     0xbf16b4: mov             x17, #0x106c
    // 0xbf16b8: cmp             w3, w17
    // 0xbf16bc: b.ne            #0xbf16c8
    // 0xbf16c0: LoadField: d1 = r4->field_f
    //     0xbf16c0: ldur            d1, [x4, #0xf]
    // 0xbf16c4: b               #0xbf16cc
    // 0xbf16c8: LoadField: d1 = r4->field_f
    //     0xbf16c8: ldur            d1, [x4, #0xf]
    // 0xbf16cc: r5 = inline_Allocate_Double()
    //     0xbf16cc: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0xbf16d0: add             x5, x5, #0x10
    //     0xbf16d4: cmp             x6, x5
    //     0xbf16d8: b.ls            #0xbf1a08
    //     0xbf16dc: str             x5, [THR, #0x60]  ; THR::top
    //     0xbf16e0: sub             x5, x5, #0xf
    //     0xbf16e4: mov             x6, #0xd108
    //     0xbf16e8: movk            x6, #3, lsl #16
    //     0xbf16ec: stur            x6, [x5, #-1]
    // 0xbf16f0: StoreField: r5->field_7 = d0
    //     0xbf16f0: stur            d0, [x5, #7]
    // 0xbf16f4: r6 = inline_Allocate_Double()
    //     0xbf16f4: ldp             x6, x7, [THR, #0x60]  ; THR::top
    //     0xbf16f8: add             x6, x6, #0x10
    //     0xbf16fc: cmp             x7, x6
    //     0xbf1700: b.ls            #0xbf1a34
    //     0xbf1704: str             x6, [THR, #0x60]  ; THR::top
    //     0xbf1708: sub             x6, x6, #0xf
    //     0xbf170c: mov             x7, #0xd108
    //     0xbf1710: movk            x7, #3, lsl #16
    //     0xbf1714: stur            x7, [x6, #-1]
    // 0xbf1718: StoreField: r6->field_7 = d1
    //     0xbf1718: stur            d1, [x6, #7]
    // 0xbf171c: stp             x6, x5, [SP, #-0x10]!
    // 0xbf1720: ldr             x16, [fp, #0x10]
    // 0xbf1724: SaveReg r16
    //     0xbf1724: str             x16, [SP, #-8]!
    // 0xbf1728: r0 = lerpDouble()
    //     0xbf1728: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf172c: add             SP, SP, #0x18
    // 0xbf1730: stur            x0, [fp, #-0x38]
    // 0xbf1734: cmp             w0, NULL
    // 0xbf1738: b.eq            #0xbf1a60
    // 0xbf173c: ldur            x1, [fp, #-0x10]
    // 0xbf1740: r17 = 4202
    //     0xbf1740: mov             x17, #0x106a
    // 0xbf1744: cmp             w1, w17
    // 0xbf1748: b.ne            #0xbf1758
    // 0xbf174c: ldr             x2, [fp, #0x20]
    // 0xbf1750: LoadField: d0 = r2->field_2f
    //     0xbf1750: ldur            d0, [x2, #0x2f]
    // 0xbf1754: b               #0xbf1774
    // 0xbf1758: ldr             x2, [fp, #0x20]
    // 0xbf175c: r17 = 4204
    //     0xbf175c: mov             x17, #0x106c
    // 0xbf1760: cmp             w1, w17
    // 0xbf1764: b.ne            #0xbf1770
    // 0xbf1768: LoadField: d0 = r2->field_1f
    //     0xbf1768: ldur            d0, [x2, #0x1f]
    // 0xbf176c: b               #0xbf1774
    // 0xbf1770: LoadField: d0 = r2->field_1f
    //     0xbf1770: ldur            d0, [x2, #0x1f]
    // 0xbf1774: ldur            x1, [fp, #-8]
    // 0xbf1778: r17 = 4202
    //     0xbf1778: mov             x17, #0x106a
    // 0xbf177c: cmp             w1, w17
    // 0xbf1780: b.ne            #0xbf1790
    // 0xbf1784: ldr             x2, [fp, #0x18]
    // 0xbf1788: LoadField: d1 = r2->field_2f
    //     0xbf1788: ldur            d1, [x2, #0x2f]
    // 0xbf178c: b               #0xbf17ac
    // 0xbf1790: ldr             x2, [fp, #0x18]
    // 0xbf1794: r17 = 4204
    //     0xbf1794: mov             x17, #0x106c
    // 0xbf1798: cmp             w1, w17
    // 0xbf179c: b.ne            #0xbf17a8
    // 0xbf17a0: LoadField: d1 = r2->field_1f
    //     0xbf17a0: ldur            d1, [x2, #0x1f]
    // 0xbf17a4: b               #0xbf17ac
    // 0xbf17a8: LoadField: d1 = r2->field_1f
    //     0xbf17a8: ldur            d1, [x2, #0x1f]
    // 0xbf17ac: ldur            x4, [fp, #-0x18]
    // 0xbf17b0: ldur            x3, [fp, #-0x20]
    // 0xbf17b4: ldur            x2, [fp, #-0x28]
    // 0xbf17b8: ldur            x1, [fp, #-0x30]
    // 0xbf17bc: r5 = inline_Allocate_Double()
    //     0xbf17bc: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0xbf17c0: add             x5, x5, #0x10
    //     0xbf17c4: cmp             x6, x5
    //     0xbf17c8: b.ls            #0xbf1a64
    //     0xbf17cc: str             x5, [THR, #0x60]  ; THR::top
    //     0xbf17d0: sub             x5, x5, #0xf
    //     0xbf17d4: mov             x6, #0xd108
    //     0xbf17d8: movk            x6, #3, lsl #16
    //     0xbf17dc: stur            x6, [x5, #-1]
    // 0xbf17e0: StoreField: r5->field_7 = d0
    //     0xbf17e0: stur            d0, [x5, #7]
    // 0xbf17e4: r6 = inline_Allocate_Double()
    //     0xbf17e4: ldp             x6, x7, [THR, #0x60]  ; THR::top
    //     0xbf17e8: add             x6, x6, #0x10
    //     0xbf17ec: cmp             x7, x6
    //     0xbf17f0: b.ls            #0xbf1a90
    //     0xbf17f4: str             x6, [THR, #0x60]  ; THR::top
    //     0xbf17f8: sub             x6, x6, #0xf
    //     0xbf17fc: mov             x7, #0xd108
    //     0xbf1800: movk            x7, #3, lsl #16
    //     0xbf1804: stur            x7, [x6, #-1]
    // 0xbf1808: StoreField: r6->field_7 = d1
    //     0xbf1808: stur            d1, [x6, #7]
    // 0xbf180c: stp             x6, x5, [SP, #-0x10]!
    // 0xbf1810: ldr             x16, [fp, #0x10]
    // 0xbf1814: SaveReg r16
    //     0xbf1814: str             x16, [SP, #-8]!
    // 0xbf1818: r0 = lerpDouble()
    //     0xbf1818: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf181c: add             SP, SP, #0x18
    // 0xbf1820: stur            x0, [fp, #-8]
    // 0xbf1824: cmp             w0, NULL
    // 0xbf1828: b.eq            #0xbf1abc
    // 0xbf182c: ldur            x1, [fp, #-0x18]
    // 0xbf1830: LoadField: d0 = r1->field_7
    //     0xbf1830: ldur            d0, [x1, #7]
    // 0xbf1834: stur            d0, [fp, #-0x40]
    // 0xbf1838: r0 = _MixedEdgeInsets()
    //     0xbf1838: bl              #0x84bee8  ; Allocate_MixedEdgeInsetsStub -> _MixedEdgeInsets (size=0x38)
    // 0xbf183c: ldur            d0, [fp, #-0x40]
    // 0xbf1840: StoreField: r0->field_7 = d0
    //     0xbf1840: stur            d0, [x0, #7]
    // 0xbf1844: ldur            x1, [fp, #-0x20]
    // 0xbf1848: LoadField: d0 = r1->field_7
    //     0xbf1848: ldur            d0, [x1, #7]
    // 0xbf184c: StoreField: r0->field_f = d0
    //     0xbf184c: stur            d0, [x0, #0xf]
    // 0xbf1850: ldur            x1, [fp, #-0x28]
    // 0xbf1854: LoadField: d0 = r1->field_7
    //     0xbf1854: ldur            d0, [x1, #7]
    // 0xbf1858: StoreField: r0->field_17 = d0
    //     0xbf1858: stur            d0, [x0, #0x17]
    // 0xbf185c: ldur            x1, [fp, #-0x30]
    // 0xbf1860: LoadField: d0 = r1->field_7
    //     0xbf1860: ldur            d0, [x1, #7]
    // 0xbf1864: StoreField: r0->field_1f = d0
    //     0xbf1864: stur            d0, [x0, #0x1f]
    // 0xbf1868: ldur            x1, [fp, #-0x38]
    // 0xbf186c: LoadField: d0 = r1->field_7
    //     0xbf186c: ldur            d0, [x1, #7]
    // 0xbf1870: StoreField: r0->field_27 = d0
    //     0xbf1870: stur            d0, [x0, #0x27]
    // 0xbf1874: ldur            x1, [fp, #-8]
    // 0xbf1878: LoadField: d0 = r1->field_7
    //     0xbf1878: ldur            d0, [x1, #7]
    // 0xbf187c: StoreField: r0->field_2f = d0
    //     0xbf187c: stur            d0, [x0, #0x2f]
    // 0xbf1880: LeaveFrame
    //     0xbf1880: mov             SP, fp
    //     0xbf1884: ldp             fp, lr, [SP], #0x10
    // 0xbf1888: ret
    //     0xbf1888: ret             
    // 0xbf188c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf188c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf1890: b               #0xbf0f30
    // 0xbf1894: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf1894: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf1898: stp             q0, q1, [SP, #-0x20]!
    // 0xbf189c: stp             x3, x4, [SP, #-0x10]!
    // 0xbf18a0: stp             x1, x2, [SP, #-0x10]!
    // 0xbf18a4: SaveReg r0
    //     0xbf18a4: str             x0, [SP, #-8]!
    // 0xbf18a8: r0 = AllocateDouble()
    //     0xbf18a8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf18ac: mov             x5, x0
    // 0xbf18b0: RestoreReg r0
    //     0xbf18b0: ldr             x0, [SP], #8
    // 0xbf18b4: ldp             x1, x2, [SP], #0x10
    // 0xbf18b8: ldp             x3, x4, [SP], #0x10
    // 0xbf18bc: ldp             q0, q1, [SP], #0x20
    // 0xbf18c0: b               #0xbf1374
    // 0xbf18c4: SaveReg d1
    //     0xbf18c4: str             q1, [SP, #-0x10]!
    // 0xbf18c8: stp             x4, x5, [SP, #-0x10]!
    // 0xbf18cc: stp             x2, x3, [SP, #-0x10]!
    // 0xbf18d0: stp             x0, x1, [SP, #-0x10]!
    // 0xbf18d4: r0 = AllocateDouble()
    //     0xbf18d4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf18d8: mov             x6, x0
    // 0xbf18dc: ldp             x0, x1, [SP], #0x10
    // 0xbf18e0: ldp             x2, x3, [SP], #0x10
    // 0xbf18e4: ldp             x4, x5, [SP], #0x10
    // 0xbf18e8: RestoreReg d1
    //     0xbf18e8: ldr             q1, [SP], #0x10
    // 0xbf18ec: b               #0xbf139c
    // 0xbf18f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf18f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf18f4: stp             q0, q1, [SP, #-0x20]!
    // 0xbf18f8: stp             x3, x4, [SP, #-0x10]!
    // 0xbf18fc: stp             x1, x2, [SP, #-0x10]!
    // 0xbf1900: SaveReg r0
    //     0xbf1900: str             x0, [SP, #-8]!
    // 0xbf1904: r0 = AllocateDouble()
    //     0xbf1904: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf1908: mov             x5, x0
    // 0xbf190c: RestoreReg r0
    //     0xbf190c: ldr             x0, [SP], #8
    // 0xbf1910: ldp             x1, x2, [SP], #0x10
    // 0xbf1914: ldp             x3, x4, [SP], #0x10
    // 0xbf1918: ldp             q0, q1, [SP], #0x20
    // 0xbf191c: b               #0xbf1450
    // 0xbf1920: SaveReg d1
    //     0xbf1920: str             q1, [SP, #-0x10]!
    // 0xbf1924: stp             x4, x5, [SP, #-0x10]!
    // 0xbf1928: stp             x2, x3, [SP, #-0x10]!
    // 0xbf192c: stp             x0, x1, [SP, #-0x10]!
    // 0xbf1930: r0 = AllocateDouble()
    //     0xbf1930: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf1934: mov             x6, x0
    // 0xbf1938: ldp             x0, x1, [SP], #0x10
    // 0xbf193c: ldp             x2, x3, [SP], #0x10
    // 0xbf1940: ldp             x4, x5, [SP], #0x10
    // 0xbf1944: RestoreReg d1
    //     0xbf1944: ldr             q1, [SP], #0x10
    // 0xbf1948: b               #0xbf1478
    // 0xbf194c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf194c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf1950: stp             q0, q1, [SP, #-0x20]!
    // 0xbf1954: stp             x3, x4, [SP, #-0x10]!
    // 0xbf1958: stp             x1, x2, [SP, #-0x10]!
    // 0xbf195c: SaveReg r0
    //     0xbf195c: str             x0, [SP, #-8]!
    // 0xbf1960: r0 = AllocateDouble()
    //     0xbf1960: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf1964: mov             x5, x0
    // 0xbf1968: RestoreReg r0
    //     0xbf1968: ldr             x0, [SP], #8
    // 0xbf196c: ldp             x1, x2, [SP], #0x10
    // 0xbf1970: ldp             x3, x4, [SP], #0x10
    // 0xbf1974: ldp             q0, q1, [SP], #0x20
    // 0xbf1978: b               #0xbf1530
    // 0xbf197c: SaveReg d1
    //     0xbf197c: str             q1, [SP, #-0x10]!
    // 0xbf1980: stp             x4, x5, [SP, #-0x10]!
    // 0xbf1984: stp             x2, x3, [SP, #-0x10]!
    // 0xbf1988: stp             x0, x1, [SP, #-0x10]!
    // 0xbf198c: r0 = AllocateDouble()
    //     0xbf198c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf1990: mov             x6, x0
    // 0xbf1994: ldp             x0, x1, [SP], #0x10
    // 0xbf1998: ldp             x2, x3, [SP], #0x10
    // 0xbf199c: ldp             x4, x5, [SP], #0x10
    // 0xbf19a0: RestoreReg d1
    //     0xbf19a0: ldr             q1, [SP], #0x10
    // 0xbf19a4: b               #0xbf1558
    // 0xbf19a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf19a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf19ac: stp             q0, q1, [SP, #-0x20]!
    // 0xbf19b0: stp             x3, x4, [SP, #-0x10]!
    // 0xbf19b4: stp             x1, x2, [SP, #-0x10]!
    // 0xbf19b8: SaveReg r0
    //     0xbf19b8: str             x0, [SP, #-8]!
    // 0xbf19bc: r0 = AllocateDouble()
    //     0xbf19bc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf19c0: mov             x5, x0
    // 0xbf19c4: RestoreReg r0
    //     0xbf19c4: ldr             x0, [SP], #8
    // 0xbf19c8: ldp             x1, x2, [SP], #0x10
    // 0xbf19cc: ldp             x3, x4, [SP], #0x10
    // 0xbf19d0: ldp             q0, q1, [SP], #0x20
    // 0xbf19d4: b               #0xbf1610
    // 0xbf19d8: SaveReg d1
    //     0xbf19d8: str             q1, [SP, #-0x10]!
    // 0xbf19dc: stp             x4, x5, [SP, #-0x10]!
    // 0xbf19e0: stp             x2, x3, [SP, #-0x10]!
    // 0xbf19e4: stp             x0, x1, [SP, #-0x10]!
    // 0xbf19e8: r0 = AllocateDouble()
    //     0xbf19e8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf19ec: mov             x6, x0
    // 0xbf19f0: ldp             x0, x1, [SP], #0x10
    // 0xbf19f4: ldp             x2, x3, [SP], #0x10
    // 0xbf19f8: ldp             x4, x5, [SP], #0x10
    // 0xbf19fc: RestoreReg d1
    //     0xbf19fc: ldr             q1, [SP], #0x10
    // 0xbf1a00: b               #0xbf1638
    // 0xbf1a04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf1a04: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf1a08: stp             q0, q1, [SP, #-0x20]!
    // 0xbf1a0c: stp             x3, x4, [SP, #-0x10]!
    // 0xbf1a10: stp             x1, x2, [SP, #-0x10]!
    // 0xbf1a14: SaveReg r0
    //     0xbf1a14: str             x0, [SP, #-8]!
    // 0xbf1a18: r0 = AllocateDouble()
    //     0xbf1a18: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf1a1c: mov             x5, x0
    // 0xbf1a20: RestoreReg r0
    //     0xbf1a20: ldr             x0, [SP], #8
    // 0xbf1a24: ldp             x1, x2, [SP], #0x10
    // 0xbf1a28: ldp             x3, x4, [SP], #0x10
    // 0xbf1a2c: ldp             q0, q1, [SP], #0x20
    // 0xbf1a30: b               #0xbf16f0
    // 0xbf1a34: SaveReg d1
    //     0xbf1a34: str             q1, [SP, #-0x10]!
    // 0xbf1a38: stp             x4, x5, [SP, #-0x10]!
    // 0xbf1a3c: stp             x2, x3, [SP, #-0x10]!
    // 0xbf1a40: stp             x0, x1, [SP, #-0x10]!
    // 0xbf1a44: r0 = AllocateDouble()
    //     0xbf1a44: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf1a48: mov             x6, x0
    // 0xbf1a4c: ldp             x0, x1, [SP], #0x10
    // 0xbf1a50: ldp             x2, x3, [SP], #0x10
    // 0xbf1a54: ldp             x4, x5, [SP], #0x10
    // 0xbf1a58: RestoreReg d1
    //     0xbf1a58: ldr             q1, [SP], #0x10
    // 0xbf1a5c: b               #0xbf1718
    // 0xbf1a60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf1a60: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf1a64: stp             q0, q1, [SP, #-0x20]!
    // 0xbf1a68: stp             x3, x4, [SP, #-0x10]!
    // 0xbf1a6c: stp             x1, x2, [SP, #-0x10]!
    // 0xbf1a70: SaveReg r0
    //     0xbf1a70: str             x0, [SP, #-8]!
    // 0xbf1a74: r0 = AllocateDouble()
    //     0xbf1a74: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf1a78: mov             x5, x0
    // 0xbf1a7c: RestoreReg r0
    //     0xbf1a7c: ldr             x0, [SP], #8
    // 0xbf1a80: ldp             x1, x2, [SP], #0x10
    // 0xbf1a84: ldp             x3, x4, [SP], #0x10
    // 0xbf1a88: ldp             q0, q1, [SP], #0x20
    // 0xbf1a8c: b               #0xbf17e0
    // 0xbf1a90: SaveReg d1
    //     0xbf1a90: str             q1, [SP, #-0x10]!
    // 0xbf1a94: stp             x4, x5, [SP, #-0x10]!
    // 0xbf1a98: stp             x2, x3, [SP, #-0x10]!
    // 0xbf1a9c: stp             x0, x1, [SP, #-0x10]!
    // 0xbf1aa0: r0 = AllocateDouble()
    //     0xbf1aa0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf1aa4: mov             x6, x0
    // 0xbf1aa8: ldp             x0, x1, [SP], #0x10
    // 0xbf1aac: ldp             x2, x3, [SP], #0x10
    // 0xbf1ab0: ldp             x4, x5, [SP], #0x10
    // 0xbf1ab4: RestoreReg d1
    //     0xbf1ab4: ldr             q1, [SP], #0x10
    // 0xbf1ab8: b               #0xbf1808
    // 0xbf1abc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf1abc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9d2f4, size: 0x2c0
    // 0xc9d2f4: ldr             x1, [SP]
    // 0xc9d2f8: cmp             w1, NULL
    // 0xc9d2fc: b.ne            #0xc9d308
    // 0xc9d300: r0 = false
    //     0xc9d300: add             x0, NULL, #0x30  ; false
    // 0xc9d304: ret
    //     0xc9d304: ret             
    // 0xc9d308: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc9d308: mov             x2, #0x76
    //     0xc9d30c: tbz             w1, #0, #0xc9d31c
    //     0xc9d310: ldur            x2, [x1, #-1]
    //     0xc9d314: ubfx            x2, x2, #0xc, #0x14
    //     0xc9d318: lsl             x2, x2, #1
    // 0xc9d31c: r3 = LoadInt32Instr(r2)
    //     0xc9d31c: sbfx            x3, x2, #1, #0x1f
    // 0xc9d320: cmp             x3, #0x835
    // 0xc9d324: b.lt            #0xc9d5ac
    // 0xc9d328: cmp             x3, #0x837
    // 0xc9d32c: b.gt            #0xc9d5ac
    // 0xc9d330: r17 = 4202
    //     0xc9d330: mov             x17, #0x106a
    // 0xc9d334: cmp             w2, w17
    // 0xc9d338: b.ne            #0xc9d344
    // 0xc9d33c: LoadField: d0 = r1->field_7
    //     0xc9d33c: ldur            d0, [x1, #7]
    // 0xc9d340: b               #0xc9d35c
    // 0xc9d344: r17 = 4204
    //     0xc9d344: mov             x17, #0x106c
    // 0xc9d348: cmp             w2, w17
    // 0xc9d34c: b.ne            #0xc9d358
    // 0xc9d350: d0 = 0.000000
    //     0xc9d350: eor             v0.16b, v0.16b, v0.16b
    // 0xc9d354: b               #0xc9d35c
    // 0xc9d358: LoadField: d0 = r1->field_7
    //     0xc9d358: ldur            d0, [x1, #7]
    // 0xc9d35c: ldr             x3, [SP, #8]
    // 0xc9d360: r4 = LoadClassIdInstr(r3)
    //     0xc9d360: ldur            x4, [x3, #-1]
    //     0xc9d364: ubfx            x4, x4, #0xc, #0x14
    // 0xc9d368: lsl             x4, x4, #1
    // 0xc9d36c: r17 = 4202
    //     0xc9d36c: mov             x17, #0x106a
    // 0xc9d370: cmp             w4, w17
    // 0xc9d374: b.ne            #0xc9d380
    // 0xc9d378: LoadField: d1 = r3->field_7
    //     0xc9d378: ldur            d1, [x3, #7]
    // 0xc9d37c: b               #0xc9d398
    // 0xc9d380: r17 = 4204
    //     0xc9d380: mov             x17, #0x106c
    // 0xc9d384: cmp             w4, w17
    // 0xc9d388: b.ne            #0xc9d394
    // 0xc9d38c: d1 = 0.000000
    //     0xc9d38c: eor             v1.16b, v1.16b, v1.16b
    // 0xc9d390: b               #0xc9d398
    // 0xc9d394: LoadField: d1 = r3->field_7
    //     0xc9d394: ldur            d1, [x3, #7]
    // 0xc9d398: fcmp            d0, d1
    // 0xc9d39c: b.vs            #0xc9d5ac
    // 0xc9d3a0: b.ne            #0xc9d5ac
    // 0xc9d3a4: r17 = 4202
    //     0xc9d3a4: mov             x17, #0x106a
    // 0xc9d3a8: cmp             w2, w17
    // 0xc9d3ac: b.ne            #0xc9d3b8
    // 0xc9d3b0: LoadField: d0 = r1->field_f
    //     0xc9d3b0: ldur            d0, [x1, #0xf]
    // 0xc9d3b4: b               #0xc9d3d0
    // 0xc9d3b8: r17 = 4204
    //     0xc9d3b8: mov             x17, #0x106c
    // 0xc9d3bc: cmp             w2, w17
    // 0xc9d3c0: b.ne            #0xc9d3cc
    // 0xc9d3c4: d0 = 0.000000
    //     0xc9d3c4: eor             v0.16b, v0.16b, v0.16b
    // 0xc9d3c8: b               #0xc9d3d0
    // 0xc9d3cc: LoadField: d0 = r1->field_17
    //     0xc9d3cc: ldur            d0, [x1, #0x17]
    // 0xc9d3d0: r17 = 4202
    //     0xc9d3d0: mov             x17, #0x106a
    // 0xc9d3d4: cmp             w4, w17
    // 0xc9d3d8: b.ne            #0xc9d3e4
    // 0xc9d3dc: LoadField: d1 = r3->field_f
    //     0xc9d3dc: ldur            d1, [x3, #0xf]
    // 0xc9d3e0: b               #0xc9d3fc
    // 0xc9d3e4: r17 = 4204
    //     0xc9d3e4: mov             x17, #0x106c
    // 0xc9d3e8: cmp             w4, w17
    // 0xc9d3ec: b.ne            #0xc9d3f8
    // 0xc9d3f0: d1 = 0.000000
    //     0xc9d3f0: eor             v1.16b, v1.16b, v1.16b
    // 0xc9d3f4: b               #0xc9d3fc
    // 0xc9d3f8: LoadField: d1 = r3->field_17
    //     0xc9d3f8: ldur            d1, [x3, #0x17]
    // 0xc9d3fc: fcmp            d0, d1
    // 0xc9d400: b.vs            #0xc9d5ac
    // 0xc9d404: b.ne            #0xc9d5ac
    // 0xc9d408: r17 = 4202
    //     0xc9d408: mov             x17, #0x106a
    // 0xc9d40c: cmp             w2, w17
    // 0xc9d410: b.ne            #0xc9d41c
    // 0xc9d414: LoadField: d0 = r1->field_17
    //     0xc9d414: ldur            d0, [x1, #0x17]
    // 0xc9d418: b               #0xc9d434
    // 0xc9d41c: r17 = 4204
    //     0xc9d41c: mov             x17, #0x106c
    // 0xc9d420: cmp             w2, w17
    // 0xc9d424: b.ne            #0xc9d430
    // 0xc9d428: LoadField: d0 = r1->field_7
    //     0xc9d428: ldur            d0, [x1, #7]
    // 0xc9d42c: b               #0xc9d434
    // 0xc9d430: d0 = 0.000000
    //     0xc9d430: eor             v0.16b, v0.16b, v0.16b
    // 0xc9d434: r17 = 4202
    //     0xc9d434: mov             x17, #0x106a
    // 0xc9d438: cmp             w4, w17
    // 0xc9d43c: b.ne            #0xc9d448
    // 0xc9d440: LoadField: d1 = r3->field_17
    //     0xc9d440: ldur            d1, [x3, #0x17]
    // 0xc9d444: b               #0xc9d460
    // 0xc9d448: r17 = 4204
    //     0xc9d448: mov             x17, #0x106c
    // 0xc9d44c: cmp             w4, w17
    // 0xc9d450: b.ne            #0xc9d45c
    // 0xc9d454: LoadField: d1 = r3->field_7
    //     0xc9d454: ldur            d1, [x3, #7]
    // 0xc9d458: b               #0xc9d460
    // 0xc9d45c: d1 = 0.000000
    //     0xc9d45c: eor             v1.16b, v1.16b, v1.16b
    // 0xc9d460: fcmp            d0, d1
    // 0xc9d464: b.vs            #0xc9d5ac
    // 0xc9d468: b.ne            #0xc9d5ac
    // 0xc9d46c: r17 = 4202
    //     0xc9d46c: mov             x17, #0x106a
    // 0xc9d470: cmp             w2, w17
    // 0xc9d474: b.ne            #0xc9d480
    // 0xc9d478: LoadField: d0 = r1->field_1f
    //     0xc9d478: ldur            d0, [x1, #0x1f]
    // 0xc9d47c: b               #0xc9d498
    // 0xc9d480: r17 = 4204
    //     0xc9d480: mov             x17, #0x106c
    // 0xc9d484: cmp             w2, w17
    // 0xc9d488: b.ne            #0xc9d494
    // 0xc9d48c: LoadField: d0 = r1->field_17
    //     0xc9d48c: ldur            d0, [x1, #0x17]
    // 0xc9d490: b               #0xc9d498
    // 0xc9d494: d0 = 0.000000
    //     0xc9d494: eor             v0.16b, v0.16b, v0.16b
    // 0xc9d498: r17 = 4202
    //     0xc9d498: mov             x17, #0x106a
    // 0xc9d49c: cmp             w4, w17
    // 0xc9d4a0: b.ne            #0xc9d4ac
    // 0xc9d4a4: LoadField: d1 = r3->field_1f
    //     0xc9d4a4: ldur            d1, [x3, #0x1f]
    // 0xc9d4a8: b               #0xc9d4c4
    // 0xc9d4ac: r17 = 4204
    //     0xc9d4ac: mov             x17, #0x106c
    // 0xc9d4b0: cmp             w4, w17
    // 0xc9d4b4: b.ne            #0xc9d4c0
    // 0xc9d4b8: LoadField: d1 = r3->field_17
    //     0xc9d4b8: ldur            d1, [x3, #0x17]
    // 0xc9d4bc: b               #0xc9d4c4
    // 0xc9d4c0: d1 = 0.000000
    //     0xc9d4c0: eor             v1.16b, v1.16b, v1.16b
    // 0xc9d4c4: fcmp            d0, d1
    // 0xc9d4c8: b.vs            #0xc9d5ac
    // 0xc9d4cc: b.ne            #0xc9d5ac
    // 0xc9d4d0: r17 = 4202
    //     0xc9d4d0: mov             x17, #0x106a
    // 0xc9d4d4: cmp             w2, w17
    // 0xc9d4d8: b.ne            #0xc9d4e4
    // 0xc9d4dc: LoadField: d0 = r1->field_27
    //     0xc9d4dc: ldur            d0, [x1, #0x27]
    // 0xc9d4e0: b               #0xc9d4fc
    // 0xc9d4e4: r17 = 4204
    //     0xc9d4e4: mov             x17, #0x106c
    // 0xc9d4e8: cmp             w2, w17
    // 0xc9d4ec: b.ne            #0xc9d4f8
    // 0xc9d4f0: LoadField: d0 = r1->field_f
    //     0xc9d4f0: ldur            d0, [x1, #0xf]
    // 0xc9d4f4: b               #0xc9d4fc
    // 0xc9d4f8: LoadField: d0 = r1->field_f
    //     0xc9d4f8: ldur            d0, [x1, #0xf]
    // 0xc9d4fc: r17 = 4202
    //     0xc9d4fc: mov             x17, #0x106a
    // 0xc9d500: cmp             w4, w17
    // 0xc9d504: b.ne            #0xc9d510
    // 0xc9d508: LoadField: d1 = r3->field_27
    //     0xc9d508: ldur            d1, [x3, #0x27]
    // 0xc9d50c: b               #0xc9d528
    // 0xc9d510: r17 = 4204
    //     0xc9d510: mov             x17, #0x106c
    // 0xc9d514: cmp             w4, w17
    // 0xc9d518: b.ne            #0xc9d524
    // 0xc9d51c: LoadField: d1 = r3->field_f
    //     0xc9d51c: ldur            d1, [x3, #0xf]
    // 0xc9d520: b               #0xc9d528
    // 0xc9d524: LoadField: d1 = r3->field_f
    //     0xc9d524: ldur            d1, [x3, #0xf]
    // 0xc9d528: fcmp            d0, d1
    // 0xc9d52c: b.vs            #0xc9d5ac
    // 0xc9d530: b.ne            #0xc9d5ac
    // 0xc9d534: r17 = 4202
    //     0xc9d534: mov             x17, #0x106a
    // 0xc9d538: cmp             w2, w17
    // 0xc9d53c: b.ne            #0xc9d548
    // 0xc9d540: LoadField: d0 = r1->field_2f
    //     0xc9d540: ldur            d0, [x1, #0x2f]
    // 0xc9d544: b               #0xc9d560
    // 0xc9d548: r17 = 4204
    //     0xc9d548: mov             x17, #0x106c
    // 0xc9d54c: cmp             w2, w17
    // 0xc9d550: b.ne            #0xc9d55c
    // 0xc9d554: LoadField: d0 = r1->field_1f
    //     0xc9d554: ldur            d0, [x1, #0x1f]
    // 0xc9d558: b               #0xc9d560
    // 0xc9d55c: LoadField: d0 = r1->field_1f
    //     0xc9d55c: ldur            d0, [x1, #0x1f]
    // 0xc9d560: r17 = 4202
    //     0xc9d560: mov             x17, #0x106a
    // 0xc9d564: cmp             w4, w17
    // 0xc9d568: b.ne            #0xc9d574
    // 0xc9d56c: LoadField: d1 = r3->field_2f
    //     0xc9d56c: ldur            d1, [x3, #0x2f]
    // 0xc9d570: b               #0xc9d58c
    // 0xc9d574: r17 = 4204
    //     0xc9d574: mov             x17, #0x106c
    // 0xc9d578: cmp             w4, w17
    // 0xc9d57c: b.ne            #0xc9d588
    // 0xc9d580: LoadField: d1 = r3->field_1f
    //     0xc9d580: ldur            d1, [x3, #0x1f]
    // 0xc9d584: b               #0xc9d58c
    // 0xc9d588: LoadField: d1 = r3->field_1f
    //     0xc9d588: ldur            d1, [x3, #0x1f]
    // 0xc9d58c: fcmp            d0, d1
    // 0xc9d590: b.vs            #0xc9d598
    // 0xc9d594: b.eq            #0xc9d5a0
    // 0xc9d598: r1 = false
    //     0xc9d598: add             x1, NULL, #0x30  ; false
    // 0xc9d59c: b               #0xc9d5a4
    // 0xc9d5a0: r1 = true
    //     0xc9d5a0: add             x1, NULL, #0x20  ; true
    // 0xc9d5a4: mov             x0, x1
    // 0xc9d5a8: b               #0xc9d5b0
    // 0xc9d5ac: r0 = false
    //     0xc9d5ac: add             x0, NULL, #0x30  ; false
    // 0xc9d5b0: ret
    //     0xc9d5b0: ret             
  }
  _ clamp(/* No info */) {
    // ** addr: 0xcfb25c, size: 0x300
    // 0xcfb25c: EnterFrame
    //     0xcfb25c: stp             fp, lr, [SP, #-0x10]!
    //     0xcfb260: mov             fp, SP
    // 0xcfb264: AllocStack(0x30)
    //     0xcfb264: sub             SP, SP, #0x30
    // 0xcfb268: ldr             x0, [fp, #0x18]
    // 0xcfb26c: r1 = LoadClassIdInstr(r0)
    //     0xcfb26c: ldur            x1, [x0, #-1]
    //     0xcfb270: ubfx            x1, x1, #0xc, #0x14
    // 0xcfb274: lsl             x1, x1, #1
    // 0xcfb278: r17 = 4202
    //     0xcfb278: mov             x17, #0x106a
    // 0xcfb27c: cmp             w1, w17
    // 0xcfb280: b.ne            #0xcfb28c
    // 0xcfb284: LoadField: d0 = r0->field_7
    //     0xcfb284: ldur            d0, [x0, #7]
    // 0xcfb288: b               #0xcfb2a4
    // 0xcfb28c: r17 = 4204
    //     0xcfb28c: mov             x17, #0x106c
    // 0xcfb290: cmp             w1, w17
    // 0xcfb294: b.ne            #0xcfb2a0
    // 0xcfb298: d0 = 0.000000
    //     0xcfb298: eor             v0.16b, v0.16b, v0.16b
    // 0xcfb29c: b               #0xcfb2a4
    // 0xcfb2a0: LoadField: d0 = r0->field_7
    //     0xcfb2a0: ldur            d0, [x0, #7]
    // 0xcfb2a4: r3 = Instance__MixedEdgeInsets
    //     0xcfb2a4: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e6a0] Obj!_MixedEdgeInsets@b357d1
    //     0xcfb2a8: ldr             x3, [x3, #0x6a0]
    // 0xcfb2ac: r2 = Instance_EdgeInsets
    //     0xcfb2ac: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0xcfb2b0: ldr             x2, [x2, #0xbd8]
    // 0xcfb2b4: LoadField: d1 = r2->field_7
    //     0xcfb2b4: ldur            d1, [x2, #7]
    // 0xcfb2b8: LoadField: d2 = r3->field_7
    //     0xcfb2b8: ldur            d2, [x3, #7]
    // 0xcfb2bc: fcmp            d0, d1
    // 0xcfb2c0: b.vs            #0xcfb2d0
    // 0xcfb2c4: b.ge            #0xcfb2d0
    // 0xcfb2c8: mov             v0.16b, v1.16b
    // 0xcfb2cc: b               #0xcfb2f0
    // 0xcfb2d0: fcmp            d0, d2
    // 0xcfb2d4: b.vs            #0xcfb2e4
    // 0xcfb2d8: b.le            #0xcfb2e4
    // 0xcfb2dc: mov             v0.16b, v2.16b
    // 0xcfb2e0: b               #0xcfb2f0
    // 0xcfb2e4: fcmp            d0, d0
    // 0xcfb2e8: b.vc            #0xcfb2f0
    // 0xcfb2ec: mov             v0.16b, v2.16b
    // 0xcfb2f0: stur            d0, [fp, #-0x30]
    // 0xcfb2f4: r17 = 4202
    //     0xcfb2f4: mov             x17, #0x106a
    // 0xcfb2f8: cmp             w1, w17
    // 0xcfb2fc: b.ne            #0xcfb308
    // 0xcfb300: LoadField: d1 = r0->field_f
    //     0xcfb300: ldur            d1, [x0, #0xf]
    // 0xcfb304: b               #0xcfb320
    // 0xcfb308: r17 = 4204
    //     0xcfb308: mov             x17, #0x106c
    // 0xcfb30c: cmp             w1, w17
    // 0xcfb310: b.ne            #0xcfb31c
    // 0xcfb314: d1 = 0.000000
    //     0xcfb314: eor             v1.16b, v1.16b, v1.16b
    // 0xcfb318: b               #0xcfb320
    // 0xcfb31c: LoadField: d1 = r0->field_17
    //     0xcfb31c: ldur            d1, [x0, #0x17]
    // 0xcfb320: LoadField: d2 = r2->field_17
    //     0xcfb320: ldur            d2, [x2, #0x17]
    // 0xcfb324: LoadField: d3 = r3->field_f
    //     0xcfb324: ldur            d3, [x3, #0xf]
    // 0xcfb328: fcmp            d1, d2
    // 0xcfb32c: b.vs            #0xcfb33c
    // 0xcfb330: b.ge            #0xcfb33c
    // 0xcfb334: mov             v1.16b, v2.16b
    // 0xcfb338: b               #0xcfb35c
    // 0xcfb33c: fcmp            d1, d3
    // 0xcfb340: b.vs            #0xcfb350
    // 0xcfb344: b.le            #0xcfb350
    // 0xcfb348: mov             v1.16b, v3.16b
    // 0xcfb34c: b               #0xcfb35c
    // 0xcfb350: fcmp            d1, d1
    // 0xcfb354: b.vc            #0xcfb35c
    // 0xcfb358: mov             v1.16b, v3.16b
    // 0xcfb35c: stur            d1, [fp, #-0x28]
    // 0xcfb360: r17 = 4202
    //     0xcfb360: mov             x17, #0x106a
    // 0xcfb364: cmp             w1, w17
    // 0xcfb368: b.ne            #0xcfb378
    // 0xcfb36c: LoadField: d2 = r0->field_17
    //     0xcfb36c: ldur            d2, [x0, #0x17]
    // 0xcfb370: mov             v3.16b, v2.16b
    // 0xcfb374: b               #0xcfb394
    // 0xcfb378: r17 = 4204
    //     0xcfb378: mov             x17, #0x106c
    // 0xcfb37c: cmp             w1, w17
    // 0xcfb380: b.ne            #0xcfb390
    // 0xcfb384: LoadField: d2 = r0->field_7
    //     0xcfb384: ldur            d2, [x0, #7]
    // 0xcfb388: mov             v3.16b, v2.16b
    // 0xcfb38c: b               #0xcfb394
    // 0xcfb390: d3 = 0.000000
    //     0xcfb390: eor             v3.16b, v3.16b, v3.16b
    // 0xcfb394: d2 = 0.000000
    //     0xcfb394: eor             v2.16b, v2.16b, v2.16b
    // 0xcfb398: LoadField: d4 = r3->field_17
    //     0xcfb398: ldur            d4, [x3, #0x17]
    // 0xcfb39c: fcmp            d3, d2
    // 0xcfb3a0: b.vs            #0xcfb3b0
    // 0xcfb3a4: b.ge            #0xcfb3b0
    // 0xcfb3a8: d3 = 0.000000
    //     0xcfb3a8: eor             v3.16b, v3.16b, v3.16b
    // 0xcfb3ac: b               #0xcfb3d0
    // 0xcfb3b0: fcmp            d3, d4
    // 0xcfb3b4: b.vs            #0xcfb3c4
    // 0xcfb3b8: b.le            #0xcfb3c4
    // 0xcfb3bc: mov             v3.16b, v4.16b
    // 0xcfb3c0: b               #0xcfb3d0
    // 0xcfb3c4: fcmp            d3, d3
    // 0xcfb3c8: b.vc            #0xcfb3d0
    // 0xcfb3cc: mov             v3.16b, v4.16b
    // 0xcfb3d0: stur            d3, [fp, #-0x20]
    // 0xcfb3d4: r17 = 4202
    //     0xcfb3d4: mov             x17, #0x106a
    // 0xcfb3d8: cmp             w1, w17
    // 0xcfb3dc: b.ne            #0xcfb3e8
    // 0xcfb3e0: LoadField: d4 = r0->field_1f
    //     0xcfb3e0: ldur            d4, [x0, #0x1f]
    // 0xcfb3e4: b               #0xcfb400
    // 0xcfb3e8: r17 = 4204
    //     0xcfb3e8: mov             x17, #0x106c
    // 0xcfb3ec: cmp             w1, w17
    // 0xcfb3f0: b.ne            #0xcfb3fc
    // 0xcfb3f4: LoadField: d4 = r0->field_17
    //     0xcfb3f4: ldur            d4, [x0, #0x17]
    // 0xcfb3f8: b               #0xcfb400
    // 0xcfb3fc: d4 = 0.000000
    //     0xcfb3fc: eor             v4.16b, v4.16b, v4.16b
    // 0xcfb400: LoadField: d5 = r3->field_1f
    //     0xcfb400: ldur            d5, [x3, #0x1f]
    // 0xcfb404: fcmp            d4, d2
    // 0xcfb408: b.vs            #0xcfb418
    // 0xcfb40c: b.ge            #0xcfb418
    // 0xcfb410: d2 = 0.000000
    //     0xcfb410: eor             v2.16b, v2.16b, v2.16b
    // 0xcfb414: b               #0xcfb440
    // 0xcfb418: fcmp            d4, d5
    // 0xcfb41c: b.vs            #0xcfb42c
    // 0xcfb420: b.le            #0xcfb42c
    // 0xcfb424: mov             v2.16b, v5.16b
    // 0xcfb428: b               #0xcfb440
    // 0xcfb42c: fcmp            d4, d4
    // 0xcfb430: b.vc            #0xcfb43c
    // 0xcfb434: mov             v2.16b, v5.16b
    // 0xcfb438: b               #0xcfb440
    // 0xcfb43c: mov             v2.16b, v4.16b
    // 0xcfb440: stur            d2, [fp, #-0x18]
    // 0xcfb444: r17 = 4202
    //     0xcfb444: mov             x17, #0x106a
    // 0xcfb448: cmp             w1, w17
    // 0xcfb44c: b.ne            #0xcfb458
    // 0xcfb450: LoadField: d4 = r0->field_27
    //     0xcfb450: ldur            d4, [x0, #0x27]
    // 0xcfb454: b               #0xcfb470
    // 0xcfb458: r17 = 4204
    //     0xcfb458: mov             x17, #0x106c
    // 0xcfb45c: cmp             w1, w17
    // 0xcfb460: b.ne            #0xcfb46c
    // 0xcfb464: LoadField: d4 = r0->field_f
    //     0xcfb464: ldur            d4, [x0, #0xf]
    // 0xcfb468: b               #0xcfb470
    // 0xcfb46c: LoadField: d4 = r0->field_f
    //     0xcfb46c: ldur            d4, [x0, #0xf]
    // 0xcfb470: LoadField: d5 = r2->field_f
    //     0xcfb470: ldur            d5, [x2, #0xf]
    // 0xcfb474: LoadField: d6 = r3->field_27
    //     0xcfb474: ldur            d6, [x3, #0x27]
    // 0xcfb478: fcmp            d4, d5
    // 0xcfb47c: b.vs            #0xcfb48c
    // 0xcfb480: b.ge            #0xcfb48c
    // 0xcfb484: mov             v4.16b, v5.16b
    // 0xcfb488: b               #0xcfb4ac
    // 0xcfb48c: fcmp            d4, d6
    // 0xcfb490: b.vs            #0xcfb4a0
    // 0xcfb494: b.le            #0xcfb4a0
    // 0xcfb498: mov             v4.16b, v6.16b
    // 0xcfb49c: b               #0xcfb4ac
    // 0xcfb4a0: fcmp            d4, d4
    // 0xcfb4a4: b.vc            #0xcfb4ac
    // 0xcfb4a8: mov             v4.16b, v6.16b
    // 0xcfb4ac: stur            d4, [fp, #-0x10]
    // 0xcfb4b0: r17 = 4202
    //     0xcfb4b0: mov             x17, #0x106a
    // 0xcfb4b4: cmp             w1, w17
    // 0xcfb4b8: b.ne            #0xcfb4c4
    // 0xcfb4bc: LoadField: d5 = r0->field_2f
    //     0xcfb4bc: ldur            d5, [x0, #0x2f]
    // 0xcfb4c0: b               #0xcfb4dc
    // 0xcfb4c4: r17 = 4204
    //     0xcfb4c4: mov             x17, #0x106c
    // 0xcfb4c8: cmp             w1, w17
    // 0xcfb4cc: b.ne            #0xcfb4d8
    // 0xcfb4d0: LoadField: d5 = r0->field_1f
    //     0xcfb4d0: ldur            d5, [x0, #0x1f]
    // 0xcfb4d4: b               #0xcfb4dc
    // 0xcfb4d8: LoadField: d5 = r0->field_1f
    //     0xcfb4d8: ldur            d5, [x0, #0x1f]
    // 0xcfb4dc: LoadField: d6 = r2->field_1f
    //     0xcfb4dc: ldur            d6, [x2, #0x1f]
    // 0xcfb4e0: LoadField: d7 = r3->field_2f
    //     0xcfb4e0: ldur            d7, [x3, #0x2f]
    // 0xcfb4e4: fcmp            d5, d6
    // 0xcfb4e8: b.vs            #0xcfb4f8
    // 0xcfb4ec: b.ge            #0xcfb4f8
    // 0xcfb4f0: mov             v5.16b, v6.16b
    // 0xcfb4f4: b               #0xcfb518
    // 0xcfb4f8: fcmp            d5, d7
    // 0xcfb4fc: b.vs            #0xcfb50c
    // 0xcfb500: b.le            #0xcfb50c
    // 0xcfb504: mov             v5.16b, v7.16b
    // 0xcfb508: b               #0xcfb518
    // 0xcfb50c: fcmp            d5, d5
    // 0xcfb510: b.vc            #0xcfb518
    // 0xcfb514: mov             v5.16b, v7.16b
    // 0xcfb518: stur            d5, [fp, #-8]
    // 0xcfb51c: r0 = _MixedEdgeInsets()
    //     0xcfb51c: bl              #0x84bee8  ; Allocate_MixedEdgeInsetsStub -> _MixedEdgeInsets (size=0x38)
    // 0xcfb520: ldur            d0, [fp, #-0x30]
    // 0xcfb524: StoreField: r0->field_7 = d0
    //     0xcfb524: stur            d0, [x0, #7]
    // 0xcfb528: ldur            d0, [fp, #-0x28]
    // 0xcfb52c: StoreField: r0->field_f = d0
    //     0xcfb52c: stur            d0, [x0, #0xf]
    // 0xcfb530: ldur            d0, [fp, #-0x20]
    // 0xcfb534: StoreField: r0->field_17 = d0
    //     0xcfb534: stur            d0, [x0, #0x17]
    // 0xcfb538: ldur            d0, [fp, #-0x18]
    // 0xcfb53c: StoreField: r0->field_1f = d0
    //     0xcfb53c: stur            d0, [x0, #0x1f]
    // 0xcfb540: ldur            d0, [fp, #-0x10]
    // 0xcfb544: StoreField: r0->field_27 = d0
    //     0xcfb544: stur            d0, [x0, #0x27]
    // 0xcfb548: ldur            d0, [fp, #-8]
    // 0xcfb54c: StoreField: r0->field_2f = d0
    //     0xcfb54c: stur            d0, [x0, #0x2f]
    // 0xcfb550: LeaveFrame
    //     0xcfb550: mov             SP, fp
    //     0xcfb554: ldp             fp, lr, [SP], #0x10
    // 0xcfb558: ret
    //     0xcfb558: ret             
  }
  _ add(/* No info */) {
    // ** addr: 0xcfb938, size: 0x2ac
    // 0xcfb938: EnterFrame
    //     0xcfb938: stp             fp, lr, [SP, #-0x10]!
    //     0xcfb93c: mov             fp, SP
    // 0xcfb940: AllocStack(0x30)
    //     0xcfb940: sub             SP, SP, #0x30
    // 0xcfb944: ldr             x0, [fp, #0x18]
    // 0xcfb948: r1 = LoadClassIdInstr(r0)
    //     0xcfb948: ldur            x1, [x0, #-1]
    //     0xcfb94c: ubfx            x1, x1, #0xc, #0x14
    // 0xcfb950: lsl             x1, x1, #1
    // 0xcfb954: r17 = 4202
    //     0xcfb954: mov             x17, #0x106a
    // 0xcfb958: cmp             w1, w17
    // 0xcfb95c: b.ne            #0xcfb968
    // 0xcfb960: LoadField: d0 = r0->field_7
    //     0xcfb960: ldur            d0, [x0, #7]
    // 0xcfb964: b               #0xcfb980
    // 0xcfb968: r17 = 4204
    //     0xcfb968: mov             x17, #0x106c
    // 0xcfb96c: cmp             w1, w17
    // 0xcfb970: b.ne            #0xcfb97c
    // 0xcfb974: d0 = 0.000000
    //     0xcfb974: eor             v0.16b, v0.16b, v0.16b
    // 0xcfb978: b               #0xcfb980
    // 0xcfb97c: LoadField: d0 = r0->field_7
    //     0xcfb97c: ldur            d0, [x0, #7]
    // 0xcfb980: ldr             x2, [fp, #0x10]
    // 0xcfb984: r3 = LoadClassIdInstr(r2)
    //     0xcfb984: ldur            x3, [x2, #-1]
    //     0xcfb988: ubfx            x3, x3, #0xc, #0x14
    // 0xcfb98c: lsl             x3, x3, #1
    // 0xcfb990: r17 = 4202
    //     0xcfb990: mov             x17, #0x106a
    // 0xcfb994: cmp             w3, w17
    // 0xcfb998: b.ne            #0xcfb9a4
    // 0xcfb99c: LoadField: d1 = r2->field_7
    //     0xcfb99c: ldur            d1, [x2, #7]
    // 0xcfb9a0: b               #0xcfb9bc
    // 0xcfb9a4: r17 = 4204
    //     0xcfb9a4: mov             x17, #0x106c
    // 0xcfb9a8: cmp             w3, w17
    // 0xcfb9ac: b.ne            #0xcfb9b8
    // 0xcfb9b0: d1 = 0.000000
    //     0xcfb9b0: eor             v1.16b, v1.16b, v1.16b
    // 0xcfb9b4: b               #0xcfb9bc
    // 0xcfb9b8: LoadField: d1 = r2->field_7
    //     0xcfb9b8: ldur            d1, [x2, #7]
    // 0xcfb9bc: fadd            d2, d0, d1
    // 0xcfb9c0: stur            d2, [fp, #-0x30]
    // 0xcfb9c4: r17 = 4202
    //     0xcfb9c4: mov             x17, #0x106a
    // 0xcfb9c8: cmp             w1, w17
    // 0xcfb9cc: b.ne            #0xcfb9d8
    // 0xcfb9d0: LoadField: d0 = r0->field_f
    //     0xcfb9d0: ldur            d0, [x0, #0xf]
    // 0xcfb9d4: b               #0xcfb9f0
    // 0xcfb9d8: r17 = 4204
    //     0xcfb9d8: mov             x17, #0x106c
    // 0xcfb9dc: cmp             w1, w17
    // 0xcfb9e0: b.ne            #0xcfb9ec
    // 0xcfb9e4: d0 = 0.000000
    //     0xcfb9e4: eor             v0.16b, v0.16b, v0.16b
    // 0xcfb9e8: b               #0xcfb9f0
    // 0xcfb9ec: LoadField: d0 = r0->field_17
    //     0xcfb9ec: ldur            d0, [x0, #0x17]
    // 0xcfb9f0: r17 = 4202
    //     0xcfb9f0: mov             x17, #0x106a
    // 0xcfb9f4: cmp             w3, w17
    // 0xcfb9f8: b.ne            #0xcfba04
    // 0xcfb9fc: LoadField: d1 = r2->field_f
    //     0xcfb9fc: ldur            d1, [x2, #0xf]
    // 0xcfba00: b               #0xcfba1c
    // 0xcfba04: r17 = 4204
    //     0xcfba04: mov             x17, #0x106c
    // 0xcfba08: cmp             w3, w17
    // 0xcfba0c: b.ne            #0xcfba18
    // 0xcfba10: d1 = 0.000000
    //     0xcfba10: eor             v1.16b, v1.16b, v1.16b
    // 0xcfba14: b               #0xcfba1c
    // 0xcfba18: LoadField: d1 = r2->field_17
    //     0xcfba18: ldur            d1, [x2, #0x17]
    // 0xcfba1c: fadd            d3, d0, d1
    // 0xcfba20: stur            d3, [fp, #-0x28]
    // 0xcfba24: r17 = 4202
    //     0xcfba24: mov             x17, #0x106a
    // 0xcfba28: cmp             w1, w17
    // 0xcfba2c: b.ne            #0xcfba38
    // 0xcfba30: LoadField: d0 = r0->field_17
    //     0xcfba30: ldur            d0, [x0, #0x17]
    // 0xcfba34: b               #0xcfba50
    // 0xcfba38: r17 = 4204
    //     0xcfba38: mov             x17, #0x106c
    // 0xcfba3c: cmp             w1, w17
    // 0xcfba40: b.ne            #0xcfba4c
    // 0xcfba44: LoadField: d0 = r0->field_7
    //     0xcfba44: ldur            d0, [x0, #7]
    // 0xcfba48: b               #0xcfba50
    // 0xcfba4c: d0 = 0.000000
    //     0xcfba4c: eor             v0.16b, v0.16b, v0.16b
    // 0xcfba50: r17 = 4202
    //     0xcfba50: mov             x17, #0x106a
    // 0xcfba54: cmp             w3, w17
    // 0xcfba58: b.ne            #0xcfba64
    // 0xcfba5c: LoadField: d1 = r2->field_17
    //     0xcfba5c: ldur            d1, [x2, #0x17]
    // 0xcfba60: b               #0xcfba7c
    // 0xcfba64: r17 = 4204
    //     0xcfba64: mov             x17, #0x106c
    // 0xcfba68: cmp             w3, w17
    // 0xcfba6c: b.ne            #0xcfba78
    // 0xcfba70: LoadField: d1 = r2->field_7
    //     0xcfba70: ldur            d1, [x2, #7]
    // 0xcfba74: b               #0xcfba7c
    // 0xcfba78: d1 = 0.000000
    //     0xcfba78: eor             v1.16b, v1.16b, v1.16b
    // 0xcfba7c: fadd            d4, d0, d1
    // 0xcfba80: stur            d4, [fp, #-0x20]
    // 0xcfba84: r17 = 4202
    //     0xcfba84: mov             x17, #0x106a
    // 0xcfba88: cmp             w1, w17
    // 0xcfba8c: b.ne            #0xcfba98
    // 0xcfba90: LoadField: d0 = r0->field_1f
    //     0xcfba90: ldur            d0, [x0, #0x1f]
    // 0xcfba94: b               #0xcfbab0
    // 0xcfba98: r17 = 4204
    //     0xcfba98: mov             x17, #0x106c
    // 0xcfba9c: cmp             w1, w17
    // 0xcfbaa0: b.ne            #0xcfbaac
    // 0xcfbaa4: LoadField: d0 = r0->field_17
    //     0xcfbaa4: ldur            d0, [x0, #0x17]
    // 0xcfbaa8: b               #0xcfbab0
    // 0xcfbaac: d0 = 0.000000
    //     0xcfbaac: eor             v0.16b, v0.16b, v0.16b
    // 0xcfbab0: r17 = 4202
    //     0xcfbab0: mov             x17, #0x106a
    // 0xcfbab4: cmp             w3, w17
    // 0xcfbab8: b.ne            #0xcfbac4
    // 0xcfbabc: LoadField: d1 = r2->field_1f
    //     0xcfbabc: ldur            d1, [x2, #0x1f]
    // 0xcfbac0: b               #0xcfbadc
    // 0xcfbac4: r17 = 4204
    //     0xcfbac4: mov             x17, #0x106c
    // 0xcfbac8: cmp             w3, w17
    // 0xcfbacc: b.ne            #0xcfbad8
    // 0xcfbad0: LoadField: d1 = r2->field_17
    //     0xcfbad0: ldur            d1, [x2, #0x17]
    // 0xcfbad4: b               #0xcfbadc
    // 0xcfbad8: d1 = 0.000000
    //     0xcfbad8: eor             v1.16b, v1.16b, v1.16b
    // 0xcfbadc: fadd            d5, d0, d1
    // 0xcfbae0: stur            d5, [fp, #-0x18]
    // 0xcfbae4: r17 = 4202
    //     0xcfbae4: mov             x17, #0x106a
    // 0xcfbae8: cmp             w1, w17
    // 0xcfbaec: b.ne            #0xcfbaf8
    // 0xcfbaf0: LoadField: d0 = r0->field_27
    //     0xcfbaf0: ldur            d0, [x0, #0x27]
    // 0xcfbaf4: b               #0xcfbb10
    // 0xcfbaf8: r17 = 4204
    //     0xcfbaf8: mov             x17, #0x106c
    // 0xcfbafc: cmp             w1, w17
    // 0xcfbb00: b.ne            #0xcfbb0c
    // 0xcfbb04: LoadField: d0 = r0->field_f
    //     0xcfbb04: ldur            d0, [x0, #0xf]
    // 0xcfbb08: b               #0xcfbb10
    // 0xcfbb0c: LoadField: d0 = r0->field_f
    //     0xcfbb0c: ldur            d0, [x0, #0xf]
    // 0xcfbb10: r17 = 4202
    //     0xcfbb10: mov             x17, #0x106a
    // 0xcfbb14: cmp             w3, w17
    // 0xcfbb18: b.ne            #0xcfbb24
    // 0xcfbb1c: LoadField: d1 = r2->field_27
    //     0xcfbb1c: ldur            d1, [x2, #0x27]
    // 0xcfbb20: b               #0xcfbb3c
    // 0xcfbb24: r17 = 4204
    //     0xcfbb24: mov             x17, #0x106c
    // 0xcfbb28: cmp             w3, w17
    // 0xcfbb2c: b.ne            #0xcfbb38
    // 0xcfbb30: LoadField: d1 = r2->field_f
    //     0xcfbb30: ldur            d1, [x2, #0xf]
    // 0xcfbb34: b               #0xcfbb3c
    // 0xcfbb38: LoadField: d1 = r2->field_f
    //     0xcfbb38: ldur            d1, [x2, #0xf]
    // 0xcfbb3c: fadd            d6, d0, d1
    // 0xcfbb40: stur            d6, [fp, #-0x10]
    // 0xcfbb44: r17 = 4202
    //     0xcfbb44: mov             x17, #0x106a
    // 0xcfbb48: cmp             w1, w17
    // 0xcfbb4c: b.ne            #0xcfbb58
    // 0xcfbb50: LoadField: d0 = r0->field_2f
    //     0xcfbb50: ldur            d0, [x0, #0x2f]
    // 0xcfbb54: b               #0xcfbb70
    // 0xcfbb58: r17 = 4204
    //     0xcfbb58: mov             x17, #0x106c
    // 0xcfbb5c: cmp             w1, w17
    // 0xcfbb60: b.ne            #0xcfbb6c
    // 0xcfbb64: LoadField: d0 = r0->field_1f
    //     0xcfbb64: ldur            d0, [x0, #0x1f]
    // 0xcfbb68: b               #0xcfbb70
    // 0xcfbb6c: LoadField: d0 = r0->field_1f
    //     0xcfbb6c: ldur            d0, [x0, #0x1f]
    // 0xcfbb70: r17 = 4202
    //     0xcfbb70: mov             x17, #0x106a
    // 0xcfbb74: cmp             w3, w17
    // 0xcfbb78: b.ne            #0xcfbb84
    // 0xcfbb7c: LoadField: d1 = r2->field_2f
    //     0xcfbb7c: ldur            d1, [x2, #0x2f]
    // 0xcfbb80: b               #0xcfbb9c
    // 0xcfbb84: r17 = 4204
    //     0xcfbb84: mov             x17, #0x106c
    // 0xcfbb88: cmp             w3, w17
    // 0xcfbb8c: b.ne            #0xcfbb98
    // 0xcfbb90: LoadField: d1 = r2->field_1f
    //     0xcfbb90: ldur            d1, [x2, #0x1f]
    // 0xcfbb94: b               #0xcfbb9c
    // 0xcfbb98: LoadField: d1 = r2->field_1f
    //     0xcfbb98: ldur            d1, [x2, #0x1f]
    // 0xcfbb9c: fadd            d7, d0, d1
    // 0xcfbba0: stur            d7, [fp, #-8]
    // 0xcfbba4: r0 = _MixedEdgeInsets()
    //     0xcfbba4: bl              #0x84bee8  ; Allocate_MixedEdgeInsetsStub -> _MixedEdgeInsets (size=0x38)
    // 0xcfbba8: ldur            d0, [fp, #-0x30]
    // 0xcfbbac: StoreField: r0->field_7 = d0
    //     0xcfbbac: stur            d0, [x0, #7]
    // 0xcfbbb0: ldur            d0, [fp, #-0x28]
    // 0xcfbbb4: StoreField: r0->field_f = d0
    //     0xcfbbb4: stur            d0, [x0, #0xf]
    // 0xcfbbb8: ldur            d0, [fp, #-0x20]
    // 0xcfbbbc: StoreField: r0->field_17 = d0
    //     0xcfbbbc: stur            d0, [x0, #0x17]
    // 0xcfbbc0: ldur            d0, [fp, #-0x18]
    // 0xcfbbc4: StoreField: r0->field_1f = d0
    //     0xcfbbc4: stur            d0, [x0, #0x1f]
    // 0xcfbbc8: ldur            d0, [fp, #-0x10]
    // 0xcfbbcc: StoreField: r0->field_27 = d0
    //     0xcfbbcc: stur            d0, [x0, #0x27]
    // 0xcfbbd0: ldur            d0, [fp, #-8]
    // 0xcfbbd4: StoreField: r0->field_2f = d0
    //     0xcfbbd4: stur            d0, [x0, #0x2f]
    // 0xcfbbd8: LeaveFrame
    //     0xcfbbd8: mov             SP, fp
    //     0xcfbbdc: ldp             fp, lr, [SP], #0x10
    // 0xcfbbe0: ret
    //     0xcfbbe0: ret             
  }
}

// class id: 2101, size: 0x38, field offset: 0x8
//   const constructor, 
class _MixedEdgeInsets extends EdgeInsetsGeometry {

  _Double field_8;
  _Double field_10;
  _Double field_18;
  _Double field_20;
  _Double field_28;
  _Double field_30;

  _MixedEdgeInsets /(_MixedEdgeInsets, double) {
    // ** addr: 0x84bdd8, size: 0x88
    // 0x84bdd8: EnterFrame
    //     0x84bdd8: stp             fp, lr, [SP, #-0x10]!
    //     0x84bddc: mov             fp, SP
    // 0x84bde0: CheckStackOverflow
    //     0x84bde0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84bde4: cmp             SP, x16
    //     0x84bde8: b.ls            #0x84be40
    // 0x84bdec: ldr             x0, [fp, #0x10]
    // 0x84bdf0: r2 = Null
    //     0x84bdf0: mov             x2, NULL
    // 0x84bdf4: r1 = Null
    //     0x84bdf4: mov             x1, NULL
    // 0x84bdf8: r4 = 59
    //     0x84bdf8: mov             x4, #0x3b
    // 0x84bdfc: branchIfSmi(r0, 0x84be08)
    //     0x84bdfc: tbz             w0, #0, #0x84be08
    // 0x84be00: r4 = LoadClassIdInstr(r0)
    //     0x84be00: ldur            x4, [x0, #-1]
    //     0x84be04: ubfx            x4, x4, #0xc, #0x14
    // 0x84be08: cmp             x4, #0x3d
    // 0x84be0c: b.eq            #0x84be20
    // 0x84be10: r8 = double
    //     0x84be10: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0x84be14: r3 = Null
    //     0x84be14: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b430] Null
    //     0x84be18: ldr             x3, [x3, #0x430]
    // 0x84be1c: r0 = double()
    //     0x84be1c: bl              #0xd72bac  ; IsType_double_Stub
    // 0x84be20: ldr             x16, [fp, #0x18]
    // 0x84be24: ldr             lr, [fp, #0x10]
    // 0x84be28: stp             lr, x16, [SP, #-0x10]!
    // 0x84be2c: r0 = /()
    //     0x84be2c: bl              #0x84be48  ; [package:flutter/src/painting/edge_insets.dart] _MixedEdgeInsets::/
    // 0x84be30: add             SP, SP, #0x10
    // 0x84be34: LeaveFrame
    //     0x84be34: mov             SP, fp
    //     0x84be38: ldp             fp, lr, [SP], #0x10
    // 0x84be3c: ret
    //     0x84be3c: ret             
    // 0x84be40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84be40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84be44: b               #0x84bdec
  }
  _MixedEdgeInsets /(_MixedEdgeInsets, double) {
    // ** addr: 0x84be48, size: 0xa0
    // 0x84be48: EnterFrame
    //     0x84be48: stp             fp, lr, [SP, #-0x10]!
    //     0x84be4c: mov             fp, SP
    // 0x84be50: AllocStack(0x30)
    //     0x84be50: sub             SP, SP, #0x30
    // 0x84be54: ldr             x0, [fp, #0x18]
    // 0x84be58: LoadField: d0 = r0->field_7
    //     0x84be58: ldur            d0, [x0, #7]
    // 0x84be5c: ldr             x1, [fp, #0x10]
    // 0x84be60: LoadField: d1 = r1->field_7
    //     0x84be60: ldur            d1, [x1, #7]
    // 0x84be64: fdiv            d2, d0, d1
    // 0x84be68: stur            d2, [fp, #-0x30]
    // 0x84be6c: LoadField: d0 = r0->field_f
    //     0x84be6c: ldur            d0, [x0, #0xf]
    // 0x84be70: fdiv            d3, d0, d1
    // 0x84be74: stur            d3, [fp, #-0x28]
    // 0x84be78: LoadField: d0 = r0->field_17
    //     0x84be78: ldur            d0, [x0, #0x17]
    // 0x84be7c: fdiv            d4, d0, d1
    // 0x84be80: stur            d4, [fp, #-0x20]
    // 0x84be84: LoadField: d0 = r0->field_1f
    //     0x84be84: ldur            d0, [x0, #0x1f]
    // 0x84be88: fdiv            d5, d0, d1
    // 0x84be8c: stur            d5, [fp, #-0x18]
    // 0x84be90: LoadField: d0 = r0->field_27
    //     0x84be90: ldur            d0, [x0, #0x27]
    // 0x84be94: fdiv            d6, d0, d1
    // 0x84be98: stur            d6, [fp, #-0x10]
    // 0x84be9c: LoadField: d0 = r0->field_2f
    //     0x84be9c: ldur            d0, [x0, #0x2f]
    // 0x84bea0: fdiv            d7, d0, d1
    // 0x84bea4: stur            d7, [fp, #-8]
    // 0x84bea8: r0 = _MixedEdgeInsets()
    //     0x84bea8: bl              #0x84bee8  ; Allocate_MixedEdgeInsetsStub -> _MixedEdgeInsets (size=0x38)
    // 0x84beac: ldur            d0, [fp, #-0x30]
    // 0x84beb0: StoreField: r0->field_7 = d0
    //     0x84beb0: stur            d0, [x0, #7]
    // 0x84beb4: ldur            d0, [fp, #-0x28]
    // 0x84beb8: StoreField: r0->field_f = d0
    //     0x84beb8: stur            d0, [x0, #0xf]
    // 0x84bebc: ldur            d0, [fp, #-0x20]
    // 0x84bec0: StoreField: r0->field_17 = d0
    //     0x84bec0: stur            d0, [x0, #0x17]
    // 0x84bec4: ldur            d0, [fp, #-0x18]
    // 0x84bec8: StoreField: r0->field_1f = d0
    //     0x84bec8: stur            d0, [x0, #0x1f]
    // 0x84becc: ldur            d0, [fp, #-0x10]
    // 0x84bed0: StoreField: r0->field_27 = d0
    //     0x84bed0: stur            d0, [x0, #0x27]
    // 0x84bed4: ldur            d0, [fp, #-8]
    // 0x84bed8: StoreField: r0->field_2f = d0
    //     0x84bed8: stur            d0, [x0, #0x2f]
    // 0x84bedc: LeaveFrame
    //     0x84bedc: mov             SP, fp
    //     0x84bee0: ldp             fp, lr, [SP], #0x10
    // 0x84bee4: ret
    //     0x84bee4: ret             
  }
  _MixedEdgeInsets *(_MixedEdgeInsets, double) {
    // ** addr: 0x84bf0c, size: 0x88
    // 0x84bf0c: EnterFrame
    //     0x84bf0c: stp             fp, lr, [SP, #-0x10]!
    //     0x84bf10: mov             fp, SP
    // 0x84bf14: CheckStackOverflow
    //     0x84bf14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84bf18: cmp             SP, x16
    //     0x84bf1c: b.ls            #0x84bf74
    // 0x84bf20: ldr             x0, [fp, #0x10]
    // 0x84bf24: r2 = Null
    //     0x84bf24: mov             x2, NULL
    // 0x84bf28: r1 = Null
    //     0x84bf28: mov             x1, NULL
    // 0x84bf2c: r4 = 59
    //     0x84bf2c: mov             x4, #0x3b
    // 0x84bf30: branchIfSmi(r0, 0x84bf3c)
    //     0x84bf30: tbz             w0, #0, #0x84bf3c
    // 0x84bf34: r4 = LoadClassIdInstr(r0)
    //     0x84bf34: ldur            x4, [x0, #-1]
    //     0x84bf38: ubfx            x4, x4, #0xc, #0x14
    // 0x84bf3c: cmp             x4, #0x3d
    // 0x84bf40: b.eq            #0x84bf54
    // 0x84bf44: r8 = double
    //     0x84bf44: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0x84bf48: r3 = Null
    //     0x84bf48: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2dab8] Null
    //     0x84bf4c: ldr             x3, [x3, #0xab8]
    // 0x84bf50: r0 = double()
    //     0x84bf50: bl              #0xd72bac  ; IsType_double_Stub
    // 0x84bf54: ldr             x16, [fp, #0x18]
    // 0x84bf58: ldr             lr, [fp, #0x10]
    // 0x84bf5c: stp             lr, x16, [SP, #-0x10]!
    // 0x84bf60: r0 = *()
    //     0x84bf60: bl              #0xcfafb4  ; [package:flutter/src/painting/edge_insets.dart] _MixedEdgeInsets::*
    // 0x84bf64: add             SP, SP, #0x10
    // 0x84bf68: LeaveFrame
    //     0x84bf68: mov             SP, fp
    //     0x84bf6c: ldp             fp, lr, [SP], #0x10
    // 0x84bf70: ret
    //     0x84bf70: ret             
    // 0x84bf74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84bf74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84bf78: b               #0x84bf20
  }
  _MixedEdgeInsets *(_MixedEdgeInsets, double) {
    // ** addr: 0xcfafb4, size: 0xa0
    // 0xcfafb4: EnterFrame
    //     0xcfafb4: stp             fp, lr, [SP, #-0x10]!
    //     0xcfafb8: mov             fp, SP
    // 0xcfafbc: AllocStack(0x30)
    //     0xcfafbc: sub             SP, SP, #0x30
    // 0xcfafc0: ldr             x0, [fp, #0x18]
    // 0xcfafc4: LoadField: d0 = r0->field_7
    //     0xcfafc4: ldur            d0, [x0, #7]
    // 0xcfafc8: ldr             x1, [fp, #0x10]
    // 0xcfafcc: LoadField: d1 = r1->field_7
    //     0xcfafcc: ldur            d1, [x1, #7]
    // 0xcfafd0: fmul            d2, d0, d1
    // 0xcfafd4: stur            d2, [fp, #-0x30]
    // 0xcfafd8: LoadField: d0 = r0->field_f
    //     0xcfafd8: ldur            d0, [x0, #0xf]
    // 0xcfafdc: fmul            d3, d0, d1
    // 0xcfafe0: stur            d3, [fp, #-0x28]
    // 0xcfafe4: LoadField: d0 = r0->field_17
    //     0xcfafe4: ldur            d0, [x0, #0x17]
    // 0xcfafe8: fmul            d4, d0, d1
    // 0xcfafec: stur            d4, [fp, #-0x20]
    // 0xcfaff0: LoadField: d0 = r0->field_1f
    //     0xcfaff0: ldur            d0, [x0, #0x1f]
    // 0xcfaff4: fmul            d5, d0, d1
    // 0xcfaff8: stur            d5, [fp, #-0x18]
    // 0xcfaffc: LoadField: d0 = r0->field_27
    //     0xcfaffc: ldur            d0, [x0, #0x27]
    // 0xcfb000: fmul            d6, d0, d1
    // 0xcfb004: stur            d6, [fp, #-0x10]
    // 0xcfb008: LoadField: d0 = r0->field_2f
    //     0xcfb008: ldur            d0, [x0, #0x2f]
    // 0xcfb00c: fmul            d7, d0, d1
    // 0xcfb010: stur            d7, [fp, #-8]
    // 0xcfb014: r0 = _MixedEdgeInsets()
    //     0xcfb014: bl              #0x84bee8  ; Allocate_MixedEdgeInsetsStub -> _MixedEdgeInsets (size=0x38)
    // 0xcfb018: ldur            d0, [fp, #-0x30]
    // 0xcfb01c: StoreField: r0->field_7 = d0
    //     0xcfb01c: stur            d0, [x0, #7]
    // 0xcfb020: ldur            d0, [fp, #-0x28]
    // 0xcfb024: StoreField: r0->field_f = d0
    //     0xcfb024: stur            d0, [x0, #0xf]
    // 0xcfb028: ldur            d0, [fp, #-0x20]
    // 0xcfb02c: StoreField: r0->field_17 = d0
    //     0xcfb02c: stur            d0, [x0, #0x17]
    // 0xcfb030: ldur            d0, [fp, #-0x18]
    // 0xcfb034: StoreField: r0->field_1f = d0
    //     0xcfb034: stur            d0, [x0, #0x1f]
    // 0xcfb038: ldur            d0, [fp, #-0x10]
    // 0xcfb03c: StoreField: r0->field_27 = d0
    //     0xcfb03c: stur            d0, [x0, #0x27]
    // 0xcfb040: ldur            d0, [fp, #-8]
    // 0xcfb044: StoreField: r0->field_2f = d0
    //     0xcfb044: stur            d0, [x0, #0x2f]
    // 0xcfb048: LeaveFrame
    //     0xcfb048: mov             SP, fp
    //     0xcfb04c: ldp             fp, lr, [SP], #0x10
    // 0xcfb050: ret
    //     0xcfb050: ret             
  }
  _ resolve(/* No info */) {
    // ** addr: 0xcfbcb4, size: 0xf0
    // 0xcfbcb4: EnterFrame
    //     0xcfbcb4: stp             fp, lr, [SP, #-0x10]!
    //     0xcfbcb8: mov             fp, SP
    // 0xcfbcbc: AllocStack(0x20)
    //     0xcfbcbc: sub             SP, SP, #0x20
    // 0xcfbcc0: ldr             x0, [fp, #0x10]
    // 0xcfbcc4: cmp             w0, NULL
    // 0xcfbcc8: b.eq            #0xcfbda0
    // 0xcfbccc: LoadField: r1 = r0->field_7
    //     0xcfbccc: ldur            x1, [x0, #7]
    // 0xcfbcd0: cmp             x1, #0
    // 0xcfbcd4: b.gt            #0xcfbd3c
    // 0xcfbcd8: ldr             x0, [fp, #0x18]
    // 0xcfbcdc: LoadField: d0 = r0->field_1f
    //     0xcfbcdc: ldur            d0, [x0, #0x1f]
    // 0xcfbce0: LoadField: d1 = r0->field_7
    //     0xcfbce0: ldur            d1, [x0, #7]
    // 0xcfbce4: fadd            d2, d0, d1
    // 0xcfbce8: stur            d2, [fp, #-0x20]
    // 0xcfbcec: LoadField: d0 = r0->field_27
    //     0xcfbcec: ldur            d0, [x0, #0x27]
    // 0xcfbcf0: stur            d0, [fp, #-0x18]
    // 0xcfbcf4: LoadField: d1 = r0->field_17
    //     0xcfbcf4: ldur            d1, [x0, #0x17]
    // 0xcfbcf8: LoadField: d3 = r0->field_f
    //     0xcfbcf8: ldur            d3, [x0, #0xf]
    // 0xcfbcfc: fadd            d4, d1, d3
    // 0xcfbd00: stur            d4, [fp, #-0x10]
    // 0xcfbd04: LoadField: d1 = r0->field_2f
    //     0xcfbd04: ldur            d1, [x0, #0x2f]
    // 0xcfbd08: stur            d1, [fp, #-8]
    // 0xcfbd0c: r0 = EdgeInsets()
    //     0xcfbd0c: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xcfbd10: ldur            d0, [fp, #-0x20]
    // 0xcfbd14: StoreField: r0->field_7 = d0
    //     0xcfbd14: stur            d0, [x0, #7]
    // 0xcfbd18: ldur            d0, [fp, #-0x18]
    // 0xcfbd1c: StoreField: r0->field_f = d0
    //     0xcfbd1c: stur            d0, [x0, #0xf]
    // 0xcfbd20: ldur            d0, [fp, #-0x10]
    // 0xcfbd24: StoreField: r0->field_17 = d0
    //     0xcfbd24: stur            d0, [x0, #0x17]
    // 0xcfbd28: ldur            d0, [fp, #-8]
    // 0xcfbd2c: StoreField: r0->field_1f = d0
    //     0xcfbd2c: stur            d0, [x0, #0x1f]
    // 0xcfbd30: LeaveFrame
    //     0xcfbd30: mov             SP, fp
    //     0xcfbd34: ldp             fp, lr, [SP], #0x10
    // 0xcfbd38: ret
    //     0xcfbd38: ret             
    // 0xcfbd3c: ldr             x0, [fp, #0x18]
    // 0xcfbd40: LoadField: d0 = r0->field_17
    //     0xcfbd40: ldur            d0, [x0, #0x17]
    // 0xcfbd44: LoadField: d1 = r0->field_7
    //     0xcfbd44: ldur            d1, [x0, #7]
    // 0xcfbd48: fadd            d2, d0, d1
    // 0xcfbd4c: stur            d2, [fp, #-0x20]
    // 0xcfbd50: LoadField: d0 = r0->field_27
    //     0xcfbd50: ldur            d0, [x0, #0x27]
    // 0xcfbd54: stur            d0, [fp, #-0x18]
    // 0xcfbd58: LoadField: d1 = r0->field_1f
    //     0xcfbd58: ldur            d1, [x0, #0x1f]
    // 0xcfbd5c: LoadField: d3 = r0->field_f
    //     0xcfbd5c: ldur            d3, [x0, #0xf]
    // 0xcfbd60: fadd            d4, d1, d3
    // 0xcfbd64: stur            d4, [fp, #-0x10]
    // 0xcfbd68: LoadField: d1 = r0->field_2f
    //     0xcfbd68: ldur            d1, [x0, #0x2f]
    // 0xcfbd6c: stur            d1, [fp, #-8]
    // 0xcfbd70: r0 = EdgeInsets()
    //     0xcfbd70: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xcfbd74: ldur            d0, [fp, #-0x20]
    // 0xcfbd78: StoreField: r0->field_7 = d0
    //     0xcfbd78: stur            d0, [x0, #7]
    // 0xcfbd7c: ldur            d0, [fp, #-0x18]
    // 0xcfbd80: StoreField: r0->field_f = d0
    //     0xcfbd80: stur            d0, [x0, #0xf]
    // 0xcfbd84: ldur            d0, [fp, #-0x10]
    // 0xcfbd88: StoreField: r0->field_17 = d0
    //     0xcfbd88: stur            d0, [x0, #0x17]
    // 0xcfbd8c: ldur            d0, [fp, #-8]
    // 0xcfbd90: StoreField: r0->field_1f = d0
    //     0xcfbd90: stur            d0, [x0, #0x1f]
    // 0xcfbd94: LeaveFrame
    //     0xcfbd94: mov             SP, fp
    //     0xcfbd98: ldp             fp, lr, [SP], #0x10
    // 0xcfbd9c: ret
    //     0xcfbd9c: ret             
    // 0xcfbda0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcfbda0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2102, size: 0x28, field offset: 0x8
//   const constructor, 
class EdgeInsetsDirectional extends EdgeInsetsGeometry {

  _Mint field_8;
  _Mint field_10;
  _Double field_18;
  _Mint field_20;

  EdgeInsetsDirectional /(EdgeInsetsDirectional, double) {
    // ** addr: 0x84b60c, size: 0x88
    // 0x84b60c: EnterFrame
    //     0x84b60c: stp             fp, lr, [SP, #-0x10]!
    //     0x84b610: mov             fp, SP
    // 0x84b614: CheckStackOverflow
    //     0x84b614: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84b618: cmp             SP, x16
    //     0x84b61c: b.ls            #0x84b674
    // 0x84b620: ldr             x0, [fp, #0x10]
    // 0x84b624: r2 = Null
    //     0x84b624: mov             x2, NULL
    // 0x84b628: r1 = Null
    //     0x84b628: mov             x1, NULL
    // 0x84b62c: r4 = 59
    //     0x84b62c: mov             x4, #0x3b
    // 0x84b630: branchIfSmi(r0, 0x84b63c)
    //     0x84b630: tbz             w0, #0, #0x84b63c
    // 0x84b634: r4 = LoadClassIdInstr(r0)
    //     0x84b634: ldur            x4, [x0, #-1]
    //     0x84b638: ubfx            x4, x4, #0xc, #0x14
    // 0x84b63c: cmp             x4, #0x3d
    // 0x84b640: b.eq            #0x84b654
    // 0x84b644: r8 = double
    //     0x84b644: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0x84b648: r3 = Null
    //     0x84b648: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b440] Null
    //     0x84b64c: ldr             x3, [x3, #0x440]
    // 0x84b650: r0 = double()
    //     0x84b650: bl              #0xd72bac  ; IsType_double_Stub
    // 0x84b654: ldr             x16, [fp, #0x18]
    // 0x84b658: ldr             lr, [fp, #0x10]
    // 0x84b65c: stp             lr, x16, [SP, #-0x10]!
    // 0x84b660: r0 = /()
    //     0x84b660: bl              #0x84b67c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsDirectional::/
    // 0x84b664: add             SP, SP, #0x10
    // 0x84b668: LeaveFrame
    //     0x84b668: mov             SP, fp
    //     0x84b66c: ldp             fp, lr, [SP], #0x10
    // 0x84b670: ret
    //     0x84b670: ret             
    // 0x84b674: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84b674: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84b678: b               #0x84b620
  }
  EdgeInsetsDirectional /(EdgeInsetsDirectional, double) {
    // ** addr: 0x84b67c, size: 0x78
    // 0x84b67c: EnterFrame
    //     0x84b67c: stp             fp, lr, [SP, #-0x10]!
    //     0x84b680: mov             fp, SP
    // 0x84b684: AllocStack(0x20)
    //     0x84b684: sub             SP, SP, #0x20
    // 0x84b688: ldr             x0, [fp, #0x18]
    // 0x84b68c: LoadField: d0 = r0->field_7
    //     0x84b68c: ldur            d0, [x0, #7]
    // 0x84b690: ldr             x1, [fp, #0x10]
    // 0x84b694: LoadField: d1 = r1->field_7
    //     0x84b694: ldur            d1, [x1, #7]
    // 0x84b698: fdiv            d2, d0, d1
    // 0x84b69c: stur            d2, [fp, #-0x20]
    // 0x84b6a0: LoadField: d0 = r0->field_f
    //     0x84b6a0: ldur            d0, [x0, #0xf]
    // 0x84b6a4: fdiv            d3, d0, d1
    // 0x84b6a8: stur            d3, [fp, #-0x18]
    // 0x84b6ac: LoadField: d0 = r0->field_17
    //     0x84b6ac: ldur            d0, [x0, #0x17]
    // 0x84b6b0: fdiv            d4, d0, d1
    // 0x84b6b4: stur            d4, [fp, #-0x10]
    // 0x84b6b8: LoadField: d0 = r0->field_1f
    //     0x84b6b8: ldur            d0, [x0, #0x1f]
    // 0x84b6bc: fdiv            d5, d0, d1
    // 0x84b6c0: stur            d5, [fp, #-8]
    // 0x84b6c4: r0 = EdgeInsetsDirectional()
    //     0x84b6c4: bl              #0x84b6f4  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0x84b6c8: ldur            d0, [fp, #-0x20]
    // 0x84b6cc: StoreField: r0->field_7 = d0
    //     0x84b6cc: stur            d0, [x0, #7]
    // 0x84b6d0: ldur            d0, [fp, #-0x18]
    // 0x84b6d4: StoreField: r0->field_f = d0
    //     0x84b6d4: stur            d0, [x0, #0xf]
    // 0x84b6d8: ldur            d0, [fp, #-0x10]
    // 0x84b6dc: StoreField: r0->field_17 = d0
    //     0x84b6dc: stur            d0, [x0, #0x17]
    // 0x84b6e0: ldur            d0, [fp, #-8]
    // 0x84b6e4: StoreField: r0->field_1f = d0
    //     0x84b6e4: stur            d0, [x0, #0x1f]
    // 0x84b6e8: LeaveFrame
    //     0x84b6e8: mov             SP, fp
    //     0x84b6ec: ldp             fp, lr, [SP], #0x10
    // 0x84b6f0: ret
    //     0x84b6f0: ret             
  }
  EdgeInsetsDirectional *(EdgeInsetsDirectional, double) {
    // ** addr: 0x84b718, size: 0x88
    // 0x84b718: EnterFrame
    //     0x84b718: stp             fp, lr, [SP, #-0x10]!
    //     0x84b71c: mov             fp, SP
    // 0x84b720: CheckStackOverflow
    //     0x84b720: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84b724: cmp             SP, x16
    //     0x84b728: b.ls            #0x84b780
    // 0x84b72c: ldr             x0, [fp, #0x10]
    // 0x84b730: r2 = Null
    //     0x84b730: mov             x2, NULL
    // 0x84b734: r1 = Null
    //     0x84b734: mov             x1, NULL
    // 0x84b738: r4 = 59
    //     0x84b738: mov             x4, #0x3b
    // 0x84b73c: branchIfSmi(r0, 0x84b748)
    //     0x84b73c: tbz             w0, #0, #0x84b748
    // 0x84b740: r4 = LoadClassIdInstr(r0)
    //     0x84b740: ldur            x4, [x0, #-1]
    //     0x84b744: ubfx            x4, x4, #0xc, #0x14
    // 0x84b748: cmp             x4, #0x3d
    // 0x84b74c: b.eq            #0x84b760
    // 0x84b750: r8 = double
    //     0x84b750: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0x84b754: r3 = Null
    //     0x84b754: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2dac8] Null
    //     0x84b758: ldr             x3, [x3, #0xac8]
    // 0x84b75c: r0 = double()
    //     0x84b75c: bl              #0xd72bac  ; IsType_double_Stub
    // 0x84b760: ldr             x16, [fp, #0x18]
    // 0x84b764: ldr             lr, [fp, #0x10]
    // 0x84b768: stp             lr, x16, [SP, #-0x10]!
    // 0x84b76c: r0 = *()
    //     0x84b76c: bl              #0xcfaf3c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsDirectional::*
    // 0x84b770: add             SP, SP, #0x10
    // 0x84b774: LeaveFrame
    //     0x84b774: mov             SP, fp
    //     0x84b778: ldp             fp, lr, [SP], #0x10
    // 0x84b77c: ret
    //     0x84b77c: ret             
    // 0x84b780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84b780: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84b784: b               #0x84b72c
  }
  EdgeInsetsDirectional +(EdgeInsetsDirectional, EdgeInsetsDirectional) {
    // ** addr: 0x84b7a0, size: 0x8c
    // 0x84b7a0: EnterFrame
    //     0x84b7a0: stp             fp, lr, [SP, #-0x10]!
    //     0x84b7a4: mov             fp, SP
    // 0x84b7a8: CheckStackOverflow
    //     0x84b7a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84b7ac: cmp             SP, x16
    //     0x84b7b0: b.ls            #0x84b80c
    // 0x84b7b4: ldr             x0, [fp, #0x10]
    // 0x84b7b8: r2 = Null
    //     0x84b7b8: mov             x2, NULL
    // 0x84b7bc: r1 = Null
    //     0x84b7bc: mov             x1, NULL
    // 0x84b7c0: r4 = 59
    //     0x84b7c0: mov             x4, #0x3b
    // 0x84b7c4: branchIfSmi(r0, 0x84b7d0)
    //     0x84b7c4: tbz             w0, #0, #0x84b7d0
    // 0x84b7c8: r4 = LoadClassIdInstr(r0)
    //     0x84b7c8: ldur            x4, [x0, #-1]
    //     0x84b7cc: ubfx            x4, x4, #0xc, #0x14
    // 0x84b7d0: cmp             x4, #0x836
    // 0x84b7d4: b.eq            #0x84b7ec
    // 0x84b7d8: r8 = EdgeInsetsDirectional
    //     0x84b7d8: add             x8, PP, #0x28, lsl #12  ; [pp+0x286c0] Type: EdgeInsetsDirectional
    //     0x84b7dc: ldr             x8, [x8, #0x6c0]
    // 0x84b7e0: r3 = Null
    //     0x84b7e0: add             x3, PP, #0x28, lsl #12  ; [pp+0x286c8] Null
    //     0x84b7e4: ldr             x3, [x3, #0x6c8]
    // 0x84b7e8: r0 = DefaultTypeTest()
    //     0x84b7e8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x84b7ec: ldr             x16, [fp, #0x18]
    // 0x84b7f0: ldr             lr, [fp, #0x10]
    // 0x84b7f4: stp             lr, x16, [SP, #-0x10]!
    // 0x84b7f8: r0 = +()
    //     0x84b7f8: bl              #0x84b814  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsDirectional::+
    // 0x84b7fc: add             SP, SP, #0x10
    // 0x84b800: LeaveFrame
    //     0x84b800: mov             SP, fp
    //     0x84b804: ldp             fp, lr, [SP], #0x10
    // 0x84b808: ret
    //     0x84b808: ret             
    // 0x84b80c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84b80c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84b810: b               #0x84b7b4
  }
  EdgeInsetsDirectional +(EdgeInsetsDirectional, EdgeInsetsDirectional) {
    // ** addr: 0x84b814, size: 0x84
    // 0x84b814: EnterFrame
    //     0x84b814: stp             fp, lr, [SP, #-0x10]!
    //     0x84b818: mov             fp, SP
    // 0x84b81c: AllocStack(0x20)
    //     0x84b81c: sub             SP, SP, #0x20
    // 0x84b820: ldr             x0, [fp, #0x18]
    // 0x84b824: LoadField: d0 = r0->field_7
    //     0x84b824: ldur            d0, [x0, #7]
    // 0x84b828: ldr             x1, [fp, #0x10]
    // 0x84b82c: LoadField: d1 = r1->field_7
    //     0x84b82c: ldur            d1, [x1, #7]
    // 0x84b830: fadd            d2, d0, d1
    // 0x84b834: stur            d2, [fp, #-0x20]
    // 0x84b838: LoadField: d0 = r0->field_f
    //     0x84b838: ldur            d0, [x0, #0xf]
    // 0x84b83c: LoadField: d1 = r1->field_f
    //     0x84b83c: ldur            d1, [x1, #0xf]
    // 0x84b840: fadd            d3, d0, d1
    // 0x84b844: stur            d3, [fp, #-0x18]
    // 0x84b848: LoadField: d0 = r0->field_17
    //     0x84b848: ldur            d0, [x0, #0x17]
    // 0x84b84c: LoadField: d1 = r1->field_17
    //     0x84b84c: ldur            d1, [x1, #0x17]
    // 0x84b850: fadd            d4, d0, d1
    // 0x84b854: stur            d4, [fp, #-0x10]
    // 0x84b858: LoadField: d0 = r0->field_1f
    //     0x84b858: ldur            d0, [x0, #0x1f]
    // 0x84b85c: LoadField: d1 = r1->field_1f
    //     0x84b85c: ldur            d1, [x1, #0x1f]
    // 0x84b860: fadd            d5, d0, d1
    // 0x84b864: stur            d5, [fp, #-8]
    // 0x84b868: r0 = EdgeInsetsDirectional()
    //     0x84b868: bl              #0x84b6f4  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0x84b86c: ldur            d0, [fp, #-0x20]
    // 0x84b870: StoreField: r0->field_7 = d0
    //     0x84b870: stur            d0, [x0, #7]
    // 0x84b874: ldur            d0, [fp, #-0x18]
    // 0x84b878: StoreField: r0->field_f = d0
    //     0x84b878: stur            d0, [x0, #0xf]
    // 0x84b87c: ldur            d0, [fp, #-0x10]
    // 0x84b880: StoreField: r0->field_17 = d0
    //     0x84b880: stur            d0, [x0, #0x17]
    // 0x84b884: ldur            d0, [fp, #-8]
    // 0x84b888: StoreField: r0->field_1f = d0
    //     0x84b888: stur            d0, [x0, #0x1f]
    // 0x84b88c: LeaveFrame
    //     0x84b88c: mov             SP, fp
    //     0x84b890: ldp             fp, lr, [SP], #0x10
    // 0x84b894: ret
    //     0x84b894: ret             
  }
  EdgeInsetsDirectional -(EdgeInsetsDirectional, EdgeInsetsDirectional) {
    // ** addr: 0x84b8b0, size: 0x8c
    // 0x84b8b0: EnterFrame
    //     0x84b8b0: stp             fp, lr, [SP, #-0x10]!
    //     0x84b8b4: mov             fp, SP
    // 0x84b8b8: CheckStackOverflow
    //     0x84b8b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84b8bc: cmp             SP, x16
    //     0x84b8c0: b.ls            #0x84b91c
    // 0x84b8c4: ldr             x0, [fp, #0x10]
    // 0x84b8c8: r2 = Null
    //     0x84b8c8: mov             x2, NULL
    // 0x84b8cc: r1 = Null
    //     0x84b8cc: mov             x1, NULL
    // 0x84b8d0: r4 = 59
    //     0x84b8d0: mov             x4, #0x3b
    // 0x84b8d4: branchIfSmi(r0, 0x84b8e0)
    //     0x84b8d4: tbz             w0, #0, #0x84b8e0
    // 0x84b8d8: r4 = LoadClassIdInstr(r0)
    //     0x84b8d8: ldur            x4, [x0, #-1]
    //     0x84b8dc: ubfx            x4, x4, #0xc, #0x14
    // 0x84b8e0: cmp             x4, #0x836
    // 0x84b8e4: b.eq            #0x84b8fc
    // 0x84b8e8: r8 = EdgeInsetsDirectional
    //     0x84b8e8: add             x8, PP, #0x28, lsl #12  ; [pp+0x286c0] Type: EdgeInsetsDirectional
    //     0x84b8ec: ldr             x8, [x8, #0x6c0]
    // 0x84b8f0: r3 = Null
    //     0x84b8f0: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2dad8] Null
    //     0x84b8f4: ldr             x3, [x3, #0xad8]
    // 0x84b8f8: r0 = DefaultTypeTest()
    //     0x84b8f8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x84b8fc: ldr             x16, [fp, #0x18]
    // 0x84b900: ldr             lr, [fp, #0x10]
    // 0x84b904: stp             lr, x16, [SP, #-0x10]!
    // 0x84b908: r0 = -()
    //     0x84b908: bl              #0x84b924  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsDirectional::-
    // 0x84b90c: add             SP, SP, #0x10
    // 0x84b910: LeaveFrame
    //     0x84b910: mov             SP, fp
    //     0x84b914: ldp             fp, lr, [SP], #0x10
    // 0x84b918: ret
    //     0x84b918: ret             
    // 0x84b91c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84b91c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84b920: b               #0x84b8c4
  }
  EdgeInsetsDirectional -(EdgeInsetsDirectional, EdgeInsetsDirectional) {
    // ** addr: 0x84b924, size: 0x84
    // 0x84b924: EnterFrame
    //     0x84b924: stp             fp, lr, [SP, #-0x10]!
    //     0x84b928: mov             fp, SP
    // 0x84b92c: AllocStack(0x20)
    //     0x84b92c: sub             SP, SP, #0x20
    // 0x84b930: ldr             x0, [fp, #0x18]
    // 0x84b934: LoadField: d0 = r0->field_7
    //     0x84b934: ldur            d0, [x0, #7]
    // 0x84b938: ldr             x1, [fp, #0x10]
    // 0x84b93c: LoadField: d1 = r1->field_7
    //     0x84b93c: ldur            d1, [x1, #7]
    // 0x84b940: fsub            d2, d0, d1
    // 0x84b944: stur            d2, [fp, #-0x20]
    // 0x84b948: LoadField: d0 = r0->field_f
    //     0x84b948: ldur            d0, [x0, #0xf]
    // 0x84b94c: LoadField: d1 = r1->field_f
    //     0x84b94c: ldur            d1, [x1, #0xf]
    // 0x84b950: fsub            d3, d0, d1
    // 0x84b954: stur            d3, [fp, #-0x18]
    // 0x84b958: LoadField: d0 = r0->field_17
    //     0x84b958: ldur            d0, [x0, #0x17]
    // 0x84b95c: LoadField: d1 = r1->field_17
    //     0x84b95c: ldur            d1, [x1, #0x17]
    // 0x84b960: fsub            d4, d0, d1
    // 0x84b964: stur            d4, [fp, #-0x10]
    // 0x84b968: LoadField: d0 = r0->field_1f
    //     0x84b968: ldur            d0, [x0, #0x1f]
    // 0x84b96c: LoadField: d1 = r1->field_1f
    //     0x84b96c: ldur            d1, [x1, #0x1f]
    // 0x84b970: fsub            d5, d0, d1
    // 0x84b974: stur            d5, [fp, #-8]
    // 0x84b978: r0 = EdgeInsetsDirectional()
    //     0x84b978: bl              #0x84b6f4  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0x84b97c: ldur            d0, [fp, #-0x20]
    // 0x84b980: StoreField: r0->field_7 = d0
    //     0x84b980: stur            d0, [x0, #7]
    // 0x84b984: ldur            d0, [fp, #-0x18]
    // 0x84b988: StoreField: r0->field_f = d0
    //     0x84b988: stur            d0, [x0, #0xf]
    // 0x84b98c: ldur            d0, [fp, #-0x10]
    // 0x84b990: StoreField: r0->field_17 = d0
    //     0x84b990: stur            d0, [x0, #0x17]
    // 0x84b994: ldur            d0, [fp, #-8]
    // 0x84b998: StoreField: r0->field_1f = d0
    //     0x84b998: stur            d0, [x0, #0x1f]
    // 0x84b99c: LeaveFrame
    //     0x84b99c: mov             SP, fp
    //     0x84b9a0: ldp             fp, lr, [SP], #0x10
    // 0x84b9a4: ret
    //     0x84b9a4: ret             
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf1ac0, size: 0x3d8
    // 0xbf1ac0: EnterFrame
    //     0xbf1ac0: stp             fp, lr, [SP, #-0x10]!
    //     0xbf1ac4: mov             fp, SP
    // 0xbf1ac8: AllocStack(0x28)
    //     0xbf1ac8: sub             SP, SP, #0x28
    // 0xbf1acc: CheckStackOverflow
    //     0xbf1acc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf1ad0: cmp             SP, x16
    //     0xbf1ad4: b.ls            #0xbf1d4c
    // 0xbf1ad8: ldr             x0, [fp, #0x20]
    // 0xbf1adc: LoadField: d0 = r0->field_7
    //     0xbf1adc: ldur            d0, [x0, #7]
    // 0xbf1ae0: ldr             x1, [fp, #0x18]
    // 0xbf1ae4: LoadField: d1 = r1->field_7
    //     0xbf1ae4: ldur            d1, [x1, #7]
    // 0xbf1ae8: ldr             d2, [fp, #0x10]
    // 0xbf1aec: r2 = inline_Allocate_Double()
    //     0xbf1aec: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbf1af0: add             x2, x2, #0x10
    //     0xbf1af4: cmp             x3, x2
    //     0xbf1af8: b.ls            #0xbf1d54
    //     0xbf1afc: str             x2, [THR, #0x60]  ; THR::top
    //     0xbf1b00: sub             x2, x2, #0xf
    //     0xbf1b04: mov             x3, #0xd108
    //     0xbf1b08: movk            x3, #3, lsl #16
    //     0xbf1b0c: stur            x3, [x2, #-1]
    // 0xbf1b10: StoreField: r2->field_7 = d2
    //     0xbf1b10: stur            d2, [x2, #7]
    // 0xbf1b14: stur            x2, [fp, #-8]
    // 0xbf1b18: r3 = inline_Allocate_Double()
    //     0xbf1b18: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xbf1b1c: add             x3, x3, #0x10
    //     0xbf1b20: cmp             x4, x3
    //     0xbf1b24: b.ls            #0xbf1d78
    //     0xbf1b28: str             x3, [THR, #0x60]  ; THR::top
    //     0xbf1b2c: sub             x3, x3, #0xf
    //     0xbf1b30: mov             x4, #0xd108
    //     0xbf1b34: movk            x4, #3, lsl #16
    //     0xbf1b38: stur            x4, [x3, #-1]
    // 0xbf1b3c: StoreField: r3->field_7 = d0
    //     0xbf1b3c: stur            d0, [x3, #7]
    // 0xbf1b40: r4 = inline_Allocate_Double()
    //     0xbf1b40: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbf1b44: add             x4, x4, #0x10
    //     0xbf1b48: cmp             x5, x4
    //     0xbf1b4c: b.ls            #0xbf1d9c
    //     0xbf1b50: str             x4, [THR, #0x60]  ; THR::top
    //     0xbf1b54: sub             x4, x4, #0xf
    //     0xbf1b58: mov             x5, #0xd108
    //     0xbf1b5c: movk            x5, #3, lsl #16
    //     0xbf1b60: stur            x5, [x4, #-1]
    // 0xbf1b64: StoreField: r4->field_7 = d1
    //     0xbf1b64: stur            d1, [x4, #7]
    // 0xbf1b68: stp             x4, x3, [SP, #-0x10]!
    // 0xbf1b6c: SaveReg r2
    //     0xbf1b6c: str             x2, [SP, #-8]!
    // 0xbf1b70: r0 = lerpDouble()
    //     0xbf1b70: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf1b74: add             SP, SP, #0x18
    // 0xbf1b78: stur            x0, [fp, #-0x10]
    // 0xbf1b7c: cmp             w0, NULL
    // 0xbf1b80: b.eq            #0xbf1dc0
    // 0xbf1b84: ldr             x1, [fp, #0x20]
    // 0xbf1b88: LoadField: d0 = r1->field_f
    //     0xbf1b88: ldur            d0, [x1, #0xf]
    // 0xbf1b8c: ldr             x2, [fp, #0x18]
    // 0xbf1b90: LoadField: d1 = r2->field_f
    //     0xbf1b90: ldur            d1, [x2, #0xf]
    // 0xbf1b94: r3 = inline_Allocate_Double()
    //     0xbf1b94: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xbf1b98: add             x3, x3, #0x10
    //     0xbf1b9c: cmp             x4, x3
    //     0xbf1ba0: b.ls            #0xbf1dc4
    //     0xbf1ba4: str             x3, [THR, #0x60]  ; THR::top
    //     0xbf1ba8: sub             x3, x3, #0xf
    //     0xbf1bac: mov             x4, #0xd108
    //     0xbf1bb0: movk            x4, #3, lsl #16
    //     0xbf1bb4: stur            x4, [x3, #-1]
    // 0xbf1bb8: StoreField: r3->field_7 = d0
    //     0xbf1bb8: stur            d0, [x3, #7]
    // 0xbf1bbc: r4 = inline_Allocate_Double()
    //     0xbf1bbc: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbf1bc0: add             x4, x4, #0x10
    //     0xbf1bc4: cmp             x5, x4
    //     0xbf1bc8: b.ls            #0xbf1de8
    //     0xbf1bcc: str             x4, [THR, #0x60]  ; THR::top
    //     0xbf1bd0: sub             x4, x4, #0xf
    //     0xbf1bd4: mov             x5, #0xd108
    //     0xbf1bd8: movk            x5, #3, lsl #16
    //     0xbf1bdc: stur            x5, [x4, #-1]
    // 0xbf1be0: StoreField: r4->field_7 = d1
    //     0xbf1be0: stur            d1, [x4, #7]
    // 0xbf1be4: stp             x4, x3, [SP, #-0x10]!
    // 0xbf1be8: ldur            x16, [fp, #-8]
    // 0xbf1bec: SaveReg r16
    //     0xbf1bec: str             x16, [SP, #-8]!
    // 0xbf1bf0: r0 = lerpDouble()
    //     0xbf1bf0: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf1bf4: add             SP, SP, #0x18
    // 0xbf1bf8: stur            x0, [fp, #-0x18]
    // 0xbf1bfc: cmp             w0, NULL
    // 0xbf1c00: b.eq            #0xbf1e0c
    // 0xbf1c04: ldr             x1, [fp, #0x20]
    // 0xbf1c08: LoadField: d0 = r1->field_17
    //     0xbf1c08: ldur            d0, [x1, #0x17]
    // 0xbf1c0c: ldr             x2, [fp, #0x18]
    // 0xbf1c10: LoadField: d1 = r2->field_17
    //     0xbf1c10: ldur            d1, [x2, #0x17]
    // 0xbf1c14: r3 = inline_Allocate_Double()
    //     0xbf1c14: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xbf1c18: add             x3, x3, #0x10
    //     0xbf1c1c: cmp             x4, x3
    //     0xbf1c20: b.ls            #0xbf1e10
    //     0xbf1c24: str             x3, [THR, #0x60]  ; THR::top
    //     0xbf1c28: sub             x3, x3, #0xf
    //     0xbf1c2c: mov             x4, #0xd108
    //     0xbf1c30: movk            x4, #3, lsl #16
    //     0xbf1c34: stur            x4, [x3, #-1]
    // 0xbf1c38: StoreField: r3->field_7 = d0
    //     0xbf1c38: stur            d0, [x3, #7]
    // 0xbf1c3c: r4 = inline_Allocate_Double()
    //     0xbf1c3c: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbf1c40: add             x4, x4, #0x10
    //     0xbf1c44: cmp             x5, x4
    //     0xbf1c48: b.ls            #0xbf1e34
    //     0xbf1c4c: str             x4, [THR, #0x60]  ; THR::top
    //     0xbf1c50: sub             x4, x4, #0xf
    //     0xbf1c54: mov             x5, #0xd108
    //     0xbf1c58: movk            x5, #3, lsl #16
    //     0xbf1c5c: stur            x5, [x4, #-1]
    // 0xbf1c60: StoreField: r4->field_7 = d1
    //     0xbf1c60: stur            d1, [x4, #7]
    // 0xbf1c64: stp             x4, x3, [SP, #-0x10]!
    // 0xbf1c68: ldur            x16, [fp, #-8]
    // 0xbf1c6c: SaveReg r16
    //     0xbf1c6c: str             x16, [SP, #-8]!
    // 0xbf1c70: r0 = lerpDouble()
    //     0xbf1c70: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf1c74: add             SP, SP, #0x18
    // 0xbf1c78: stur            x0, [fp, #-0x20]
    // 0xbf1c7c: cmp             w0, NULL
    // 0xbf1c80: b.eq            #0xbf1e58
    // 0xbf1c84: ldr             x1, [fp, #0x20]
    // 0xbf1c88: LoadField: d0 = r1->field_1f
    //     0xbf1c88: ldur            d0, [x1, #0x1f]
    // 0xbf1c8c: ldr             x1, [fp, #0x18]
    // 0xbf1c90: LoadField: d1 = r1->field_1f
    //     0xbf1c90: ldur            d1, [x1, #0x1f]
    // 0xbf1c94: r1 = inline_Allocate_Double()
    //     0xbf1c94: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbf1c98: add             x1, x1, #0x10
    //     0xbf1c9c: cmp             x2, x1
    //     0xbf1ca0: b.ls            #0xbf1e5c
    //     0xbf1ca4: str             x1, [THR, #0x60]  ; THR::top
    //     0xbf1ca8: sub             x1, x1, #0xf
    //     0xbf1cac: mov             x2, #0xd108
    //     0xbf1cb0: movk            x2, #3, lsl #16
    //     0xbf1cb4: stur            x2, [x1, #-1]
    // 0xbf1cb8: StoreField: r1->field_7 = d0
    //     0xbf1cb8: stur            d0, [x1, #7]
    // 0xbf1cbc: r2 = inline_Allocate_Double()
    //     0xbf1cbc: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbf1cc0: add             x2, x2, #0x10
    //     0xbf1cc4: cmp             x3, x2
    //     0xbf1cc8: b.ls            #0xbf1e78
    //     0xbf1ccc: str             x2, [THR, #0x60]  ; THR::top
    //     0xbf1cd0: sub             x2, x2, #0xf
    //     0xbf1cd4: mov             x3, #0xd108
    //     0xbf1cd8: movk            x3, #3, lsl #16
    //     0xbf1cdc: stur            x3, [x2, #-1]
    // 0xbf1ce0: StoreField: r2->field_7 = d1
    //     0xbf1ce0: stur            d1, [x2, #7]
    // 0xbf1ce4: stp             x2, x1, [SP, #-0x10]!
    // 0xbf1ce8: ldur            x16, [fp, #-8]
    // 0xbf1cec: SaveReg r16
    //     0xbf1cec: str             x16, [SP, #-8]!
    // 0xbf1cf0: r0 = lerpDouble()
    //     0xbf1cf0: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf1cf4: add             SP, SP, #0x18
    // 0xbf1cf8: stur            x0, [fp, #-8]
    // 0xbf1cfc: cmp             w0, NULL
    // 0xbf1d00: b.eq            #0xbf1e94
    // 0xbf1d04: ldur            x1, [fp, #-0x10]
    // 0xbf1d08: LoadField: d0 = r1->field_7
    //     0xbf1d08: ldur            d0, [x1, #7]
    // 0xbf1d0c: stur            d0, [fp, #-0x28]
    // 0xbf1d10: r0 = EdgeInsetsDirectional()
    //     0xbf1d10: bl              #0x84b6f4  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xbf1d14: ldur            d0, [fp, #-0x28]
    // 0xbf1d18: StoreField: r0->field_7 = d0
    //     0xbf1d18: stur            d0, [x0, #7]
    // 0xbf1d1c: ldur            x1, [fp, #-0x18]
    // 0xbf1d20: LoadField: d0 = r1->field_7
    //     0xbf1d20: ldur            d0, [x1, #7]
    // 0xbf1d24: StoreField: r0->field_f = d0
    //     0xbf1d24: stur            d0, [x0, #0xf]
    // 0xbf1d28: ldur            x1, [fp, #-0x20]
    // 0xbf1d2c: LoadField: d0 = r1->field_7
    //     0xbf1d2c: ldur            d0, [x1, #7]
    // 0xbf1d30: StoreField: r0->field_17 = d0
    //     0xbf1d30: stur            d0, [x0, #0x17]
    // 0xbf1d34: ldur            x1, [fp, #-8]
    // 0xbf1d38: LoadField: d0 = r1->field_7
    //     0xbf1d38: ldur            d0, [x1, #7]
    // 0xbf1d3c: StoreField: r0->field_1f = d0
    //     0xbf1d3c: stur            d0, [x0, #0x1f]
    // 0xbf1d40: LeaveFrame
    //     0xbf1d40: mov             SP, fp
    //     0xbf1d44: ldp             fp, lr, [SP], #0x10
    // 0xbf1d48: ret
    //     0xbf1d48: ret             
    // 0xbf1d4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf1d4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf1d50: b               #0xbf1ad8
    // 0xbf1d54: stp             q1, q2, [SP, #-0x20]!
    // 0xbf1d58: SaveReg d0
    //     0xbf1d58: str             q0, [SP, #-0x10]!
    // 0xbf1d5c: stp             x0, x1, [SP, #-0x10]!
    // 0xbf1d60: r0 = AllocateDouble()
    //     0xbf1d60: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf1d64: mov             x2, x0
    // 0xbf1d68: ldp             x0, x1, [SP], #0x10
    // 0xbf1d6c: RestoreReg d0
    //     0xbf1d6c: ldr             q0, [SP], #0x10
    // 0xbf1d70: ldp             q1, q2, [SP], #0x20
    // 0xbf1d74: b               #0xbf1b10
    // 0xbf1d78: stp             q0, q1, [SP, #-0x20]!
    // 0xbf1d7c: stp             x1, x2, [SP, #-0x10]!
    // 0xbf1d80: SaveReg r0
    //     0xbf1d80: str             x0, [SP, #-8]!
    // 0xbf1d84: r0 = AllocateDouble()
    //     0xbf1d84: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf1d88: mov             x3, x0
    // 0xbf1d8c: RestoreReg r0
    //     0xbf1d8c: ldr             x0, [SP], #8
    // 0xbf1d90: ldp             x1, x2, [SP], #0x10
    // 0xbf1d94: ldp             q0, q1, [SP], #0x20
    // 0xbf1d98: b               #0xbf1b3c
    // 0xbf1d9c: SaveReg d1
    //     0xbf1d9c: str             q1, [SP, #-0x10]!
    // 0xbf1da0: stp             x2, x3, [SP, #-0x10]!
    // 0xbf1da4: stp             x0, x1, [SP, #-0x10]!
    // 0xbf1da8: r0 = AllocateDouble()
    //     0xbf1da8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf1dac: mov             x4, x0
    // 0xbf1db0: ldp             x0, x1, [SP], #0x10
    // 0xbf1db4: ldp             x2, x3, [SP], #0x10
    // 0xbf1db8: RestoreReg d1
    //     0xbf1db8: ldr             q1, [SP], #0x10
    // 0xbf1dbc: b               #0xbf1b64
    // 0xbf1dc0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf1dc0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf1dc4: stp             q0, q1, [SP, #-0x20]!
    // 0xbf1dc8: stp             x1, x2, [SP, #-0x10]!
    // 0xbf1dcc: SaveReg r0
    //     0xbf1dcc: str             x0, [SP, #-8]!
    // 0xbf1dd0: r0 = AllocateDouble()
    //     0xbf1dd0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf1dd4: mov             x3, x0
    // 0xbf1dd8: RestoreReg r0
    //     0xbf1dd8: ldr             x0, [SP], #8
    // 0xbf1ddc: ldp             x1, x2, [SP], #0x10
    // 0xbf1de0: ldp             q0, q1, [SP], #0x20
    // 0xbf1de4: b               #0xbf1bb8
    // 0xbf1de8: SaveReg d1
    //     0xbf1de8: str             q1, [SP, #-0x10]!
    // 0xbf1dec: stp             x2, x3, [SP, #-0x10]!
    // 0xbf1df0: stp             x0, x1, [SP, #-0x10]!
    // 0xbf1df4: r0 = AllocateDouble()
    //     0xbf1df4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf1df8: mov             x4, x0
    // 0xbf1dfc: ldp             x0, x1, [SP], #0x10
    // 0xbf1e00: ldp             x2, x3, [SP], #0x10
    // 0xbf1e04: RestoreReg d1
    //     0xbf1e04: ldr             q1, [SP], #0x10
    // 0xbf1e08: b               #0xbf1be0
    // 0xbf1e0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf1e0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf1e10: stp             q0, q1, [SP, #-0x20]!
    // 0xbf1e14: stp             x1, x2, [SP, #-0x10]!
    // 0xbf1e18: SaveReg r0
    //     0xbf1e18: str             x0, [SP, #-8]!
    // 0xbf1e1c: r0 = AllocateDouble()
    //     0xbf1e1c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf1e20: mov             x3, x0
    // 0xbf1e24: RestoreReg r0
    //     0xbf1e24: ldr             x0, [SP], #8
    // 0xbf1e28: ldp             x1, x2, [SP], #0x10
    // 0xbf1e2c: ldp             q0, q1, [SP], #0x20
    // 0xbf1e30: b               #0xbf1c38
    // 0xbf1e34: SaveReg d1
    //     0xbf1e34: str             q1, [SP, #-0x10]!
    // 0xbf1e38: stp             x2, x3, [SP, #-0x10]!
    // 0xbf1e3c: stp             x0, x1, [SP, #-0x10]!
    // 0xbf1e40: r0 = AllocateDouble()
    //     0xbf1e40: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf1e44: mov             x4, x0
    // 0xbf1e48: ldp             x0, x1, [SP], #0x10
    // 0xbf1e4c: ldp             x2, x3, [SP], #0x10
    // 0xbf1e50: RestoreReg d1
    //     0xbf1e50: ldr             q1, [SP], #0x10
    // 0xbf1e54: b               #0xbf1c60
    // 0xbf1e58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf1e58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf1e5c: stp             q0, q1, [SP, #-0x20]!
    // 0xbf1e60: SaveReg r0
    //     0xbf1e60: str             x0, [SP, #-8]!
    // 0xbf1e64: r0 = AllocateDouble()
    //     0xbf1e64: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf1e68: mov             x1, x0
    // 0xbf1e6c: RestoreReg r0
    //     0xbf1e6c: ldr             x0, [SP], #8
    // 0xbf1e70: ldp             q0, q1, [SP], #0x20
    // 0xbf1e74: b               #0xbf1cb8
    // 0xbf1e78: SaveReg d1
    //     0xbf1e78: str             q1, [SP, #-0x10]!
    // 0xbf1e7c: stp             x0, x1, [SP, #-0x10]!
    // 0xbf1e80: r0 = AllocateDouble()
    //     0xbf1e80: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf1e84: mov             x2, x0
    // 0xbf1e88: ldp             x0, x1, [SP], #0x10
    // 0xbf1e8c: RestoreReg d1
    //     0xbf1e8c: ldr             q1, [SP], #0x10
    // 0xbf1e90: b               #0xbf1ce0
    // 0xbf1e94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf1e94: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  EdgeInsetsDirectional *(EdgeInsetsDirectional, double) {
    // ** addr: 0xcfaf3c, size: 0x78
    // 0xcfaf3c: EnterFrame
    //     0xcfaf3c: stp             fp, lr, [SP, #-0x10]!
    //     0xcfaf40: mov             fp, SP
    // 0xcfaf44: AllocStack(0x20)
    //     0xcfaf44: sub             SP, SP, #0x20
    // 0xcfaf48: ldr             x0, [fp, #0x18]
    // 0xcfaf4c: LoadField: d0 = r0->field_7
    //     0xcfaf4c: ldur            d0, [x0, #7]
    // 0xcfaf50: ldr             x1, [fp, #0x10]
    // 0xcfaf54: LoadField: d1 = r1->field_7
    //     0xcfaf54: ldur            d1, [x1, #7]
    // 0xcfaf58: fmul            d2, d0, d1
    // 0xcfaf5c: stur            d2, [fp, #-0x20]
    // 0xcfaf60: LoadField: d0 = r0->field_f
    //     0xcfaf60: ldur            d0, [x0, #0xf]
    // 0xcfaf64: fmul            d3, d0, d1
    // 0xcfaf68: stur            d3, [fp, #-0x18]
    // 0xcfaf6c: LoadField: d0 = r0->field_17
    //     0xcfaf6c: ldur            d0, [x0, #0x17]
    // 0xcfaf70: fmul            d4, d0, d1
    // 0xcfaf74: stur            d4, [fp, #-0x10]
    // 0xcfaf78: LoadField: d0 = r0->field_1f
    //     0xcfaf78: ldur            d0, [x0, #0x1f]
    // 0xcfaf7c: fmul            d5, d0, d1
    // 0xcfaf80: stur            d5, [fp, #-8]
    // 0xcfaf84: r0 = EdgeInsetsDirectional()
    //     0xcfaf84: bl              #0x84b6f4  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xcfaf88: ldur            d0, [fp, #-0x20]
    // 0xcfaf8c: StoreField: r0->field_7 = d0
    //     0xcfaf8c: stur            d0, [x0, #7]
    // 0xcfaf90: ldur            d0, [fp, #-0x18]
    // 0xcfaf94: StoreField: r0->field_f = d0
    //     0xcfaf94: stur            d0, [x0, #0xf]
    // 0xcfaf98: ldur            d0, [fp, #-0x10]
    // 0xcfaf9c: StoreField: r0->field_17 = d0
    //     0xcfaf9c: stur            d0, [x0, #0x17]
    // 0xcfafa0: ldur            d0, [fp, #-8]
    // 0xcfafa4: StoreField: r0->field_1f = d0
    //     0xcfafa4: stur            d0, [x0, #0x1f]
    // 0xcfafa8: LeaveFrame
    //     0xcfafa8: mov             SP, fp
    //     0xcfafac: ldp             fp, lr, [SP], #0x10
    // 0xcfafb0: ret
    //     0xcfafb0: ret             
  }
  _ add(/* No info */) {
    // ** addr: 0xcfb8c8, size: 0x70
    // 0xcfb8c8: EnterFrame
    //     0xcfb8c8: stp             fp, lr, [SP, #-0x10]!
    //     0xcfb8cc: mov             fp, SP
    // 0xcfb8d0: CheckStackOverflow
    //     0xcfb8d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcfb8d4: cmp             SP, x16
    //     0xcfb8d8: b.ls            #0xcfb930
    // 0xcfb8dc: ldr             x0, [fp, #0x10]
    // 0xcfb8e0: r1 = LoadClassIdInstr(r0)
    //     0xcfb8e0: ldur            x1, [x0, #-1]
    //     0xcfb8e4: ubfx            x1, x1, #0xc, #0x14
    // 0xcfb8e8: lsl             x1, x1, #1
    // 0xcfb8ec: r17 = 4204
    //     0xcfb8ec: mov             x17, #0x106c
    // 0xcfb8f0: cmp             w1, w17
    // 0xcfb8f4: b.ne            #0xcfb914
    // 0xcfb8f8: ldr             x16, [fp, #0x18]
    // 0xcfb8fc: stp             x0, x16, [SP, #-0x10]!
    // 0xcfb900: r0 = +()
    //     0xcfb900: bl              #0x84b814  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsDirectional::+
    // 0xcfb904: add             SP, SP, #0x10
    // 0xcfb908: LeaveFrame
    //     0xcfb908: mov             SP, fp
    //     0xcfb90c: ldp             fp, lr, [SP], #0x10
    // 0xcfb910: ret
    //     0xcfb910: ret             
    // 0xcfb914: ldr             x16, [fp, #0x18]
    // 0xcfb918: stp             x0, x16, [SP, #-0x10]!
    // 0xcfb91c: r0 = add()
    //     0xcfb91c: bl              #0xcfb938  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::add
    // 0xcfb920: add             SP, SP, #0x10
    // 0xcfb924: LeaveFrame
    //     0xcfb924: mov             SP, fp
    //     0xcfb928: ldp             fp, lr, [SP], #0x10
    // 0xcfb92c: ret
    //     0xcfb92c: ret             
    // 0xcfb930: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfb930: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfb934: b               #0xcfb8dc
  }
  _ resolve(/* No info */) {
    // ** addr: 0xcfbbe4, size: 0xd0
    // 0xcfbbe4: EnterFrame
    //     0xcfbbe4: stp             fp, lr, [SP, #-0x10]!
    //     0xcfbbe8: mov             fp, SP
    // 0xcfbbec: AllocStack(0x20)
    //     0xcfbbec: sub             SP, SP, #0x20
    // 0xcfbbf0: ldr             x0, [fp, #0x10]
    // 0xcfbbf4: cmp             w0, NULL
    // 0xcfbbf8: b.eq            #0xcfbcb0
    // 0xcfbbfc: LoadField: r1 = r0->field_7
    //     0xcfbbfc: ldur            x1, [x0, #7]
    // 0xcfbc00: cmp             x1, #0
    // 0xcfbc04: b.gt            #0xcfbc5c
    // 0xcfbc08: ldr             x0, [fp, #0x18]
    // 0xcfbc0c: LoadField: d0 = r0->field_17
    //     0xcfbc0c: ldur            d0, [x0, #0x17]
    // 0xcfbc10: stur            d0, [fp, #-0x20]
    // 0xcfbc14: LoadField: d1 = r0->field_f
    //     0xcfbc14: ldur            d1, [x0, #0xf]
    // 0xcfbc18: stur            d1, [fp, #-0x18]
    // 0xcfbc1c: LoadField: d2 = r0->field_7
    //     0xcfbc1c: ldur            d2, [x0, #7]
    // 0xcfbc20: stur            d2, [fp, #-0x10]
    // 0xcfbc24: LoadField: d3 = r0->field_1f
    //     0xcfbc24: ldur            d3, [x0, #0x1f]
    // 0xcfbc28: stur            d3, [fp, #-8]
    // 0xcfbc2c: r0 = EdgeInsets()
    //     0xcfbc2c: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xcfbc30: ldur            d0, [fp, #-0x20]
    // 0xcfbc34: StoreField: r0->field_7 = d0
    //     0xcfbc34: stur            d0, [x0, #7]
    // 0xcfbc38: ldur            d0, [fp, #-0x18]
    // 0xcfbc3c: StoreField: r0->field_f = d0
    //     0xcfbc3c: stur            d0, [x0, #0xf]
    // 0xcfbc40: ldur            d0, [fp, #-0x10]
    // 0xcfbc44: StoreField: r0->field_17 = d0
    //     0xcfbc44: stur            d0, [x0, #0x17]
    // 0xcfbc48: ldur            d0, [fp, #-8]
    // 0xcfbc4c: StoreField: r0->field_1f = d0
    //     0xcfbc4c: stur            d0, [x0, #0x1f]
    // 0xcfbc50: LeaveFrame
    //     0xcfbc50: mov             SP, fp
    //     0xcfbc54: ldp             fp, lr, [SP], #0x10
    // 0xcfbc58: ret
    //     0xcfbc58: ret             
    // 0xcfbc5c: ldr             x0, [fp, #0x18]
    // 0xcfbc60: LoadField: d0 = r0->field_7
    //     0xcfbc60: ldur            d0, [x0, #7]
    // 0xcfbc64: stur            d0, [fp, #-0x20]
    // 0xcfbc68: LoadField: d1 = r0->field_f
    //     0xcfbc68: ldur            d1, [x0, #0xf]
    // 0xcfbc6c: stur            d1, [fp, #-0x18]
    // 0xcfbc70: LoadField: d2 = r0->field_17
    //     0xcfbc70: ldur            d2, [x0, #0x17]
    // 0xcfbc74: stur            d2, [fp, #-0x10]
    // 0xcfbc78: LoadField: d3 = r0->field_1f
    //     0xcfbc78: ldur            d3, [x0, #0x1f]
    // 0xcfbc7c: stur            d3, [fp, #-8]
    // 0xcfbc80: r0 = EdgeInsets()
    //     0xcfbc80: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xcfbc84: ldur            d0, [fp, #-0x20]
    // 0xcfbc88: StoreField: r0->field_7 = d0
    //     0xcfbc88: stur            d0, [x0, #7]
    // 0xcfbc8c: ldur            d0, [fp, #-0x18]
    // 0xcfbc90: StoreField: r0->field_f = d0
    //     0xcfbc90: stur            d0, [x0, #0xf]
    // 0xcfbc94: ldur            d0, [fp, #-0x10]
    // 0xcfbc98: StoreField: r0->field_17 = d0
    //     0xcfbc98: stur            d0, [x0, #0x17]
    // 0xcfbc9c: ldur            d0, [fp, #-8]
    // 0xcfbca0: StoreField: r0->field_1f = d0
    //     0xcfbca0: stur            d0, [x0, #0x1f]
    // 0xcfbca4: LeaveFrame
    //     0xcfbca4: mov             SP, fp
    //     0xcfbca8: ldp             fp, lr, [SP], #0x10
    // 0xcfbcac: ret
    //     0xcfbcac: ret             
    // 0xcfbcb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcfbcb0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2103, size: 0x28, field offset: 0x8
//   const constructor, 
class EdgeInsets extends EdgeInsetsGeometry {

  _Double field_8;
  _Double field_10;
  _Double field_18;
  _Double field_20;

  _ inflateRect(/* No info */) {
    // ** addr: 0x518864, size: 0x84
    // 0x518864: EnterFrame
    //     0x518864: stp             fp, lr, [SP, #-0x10]!
    //     0x518868: mov             fp, SP
    // 0x51886c: AllocStack(0x20)
    //     0x51886c: sub             SP, SP, #0x20
    // 0x518870: ldr             x0, [fp, #0x10]
    // 0x518874: LoadField: d0 = r0->field_7
    //     0x518874: ldur            d0, [x0, #7]
    // 0x518878: ldr             x1, [fp, #0x18]
    // 0x51887c: LoadField: d1 = r1->field_7
    //     0x51887c: ldur            d1, [x1, #7]
    // 0x518880: fsub            d2, d0, d1
    // 0x518884: stur            d2, [fp, #-0x20]
    // 0x518888: LoadField: d0 = r0->field_f
    //     0x518888: ldur            d0, [x0, #0xf]
    // 0x51888c: LoadField: d1 = r1->field_f
    //     0x51888c: ldur            d1, [x1, #0xf]
    // 0x518890: fsub            d3, d0, d1
    // 0x518894: stur            d3, [fp, #-0x18]
    // 0x518898: LoadField: d0 = r0->field_17
    //     0x518898: ldur            d0, [x0, #0x17]
    // 0x51889c: LoadField: d1 = r1->field_17
    //     0x51889c: ldur            d1, [x1, #0x17]
    // 0x5188a0: fadd            d4, d0, d1
    // 0x5188a4: stur            d4, [fp, #-0x10]
    // 0x5188a8: LoadField: d0 = r0->field_1f
    //     0x5188a8: ldur            d0, [x0, #0x1f]
    // 0x5188ac: LoadField: d1 = r1->field_1f
    //     0x5188ac: ldur            d1, [x1, #0x1f]
    // 0x5188b0: fadd            d5, d0, d1
    // 0x5188b4: stur            d5, [fp, #-8]
    // 0x5188b8: r0 = Rect()
    //     0x5188b8: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x5188bc: ldur            d0, [fp, #-0x20]
    // 0x5188c0: StoreField: r0->field_7 = d0
    //     0x5188c0: stur            d0, [x0, #7]
    // 0x5188c4: ldur            d0, [fp, #-0x18]
    // 0x5188c8: StoreField: r0->field_f = d0
    //     0x5188c8: stur            d0, [x0, #0xf]
    // 0x5188cc: ldur            d0, [fp, #-0x10]
    // 0x5188d0: StoreField: r0->field_17 = d0
    //     0x5188d0: stur            d0, [x0, #0x17]
    // 0x5188d4: ldur            d0, [fp, #-8]
    // 0x5188d8: StoreField: r0->field_1f = d0
    //     0x5188d8: stur            d0, [x0, #0x1f]
    // 0x5188dc: LeaveFrame
    //     0x5188dc: mov             SP, fp
    //     0x5188e0: ldp             fp, lr, [SP], #0x10
    // 0x5188e4: ret
    //     0x5188e4: ret             
  }
  EdgeInsets /(EdgeInsets, double) {
    // ** addr: 0x518900, size: 0x88
    // 0x518900: EnterFrame
    //     0x518900: stp             fp, lr, [SP, #-0x10]!
    //     0x518904: mov             fp, SP
    // 0x518908: CheckStackOverflow
    //     0x518908: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x51890c: cmp             SP, x16
    //     0x518910: b.ls            #0x518968
    // 0x518914: ldr             x0, [fp, #0x10]
    // 0x518918: r2 = Null
    //     0x518918: mov             x2, NULL
    // 0x51891c: r1 = Null
    //     0x51891c: mov             x1, NULL
    // 0x518920: r4 = 59
    //     0x518920: mov             x4, #0x3b
    // 0x518924: branchIfSmi(r0, 0x518930)
    //     0x518924: tbz             w0, #0, #0x518930
    // 0x518928: r4 = LoadClassIdInstr(r0)
    //     0x518928: ldur            x4, [x0, #-1]
    //     0x51892c: ubfx            x4, x4, #0xc, #0x14
    // 0x518930: cmp             x4, #0x3d
    // 0x518934: b.eq            #0x518948
    // 0x518938: r8 = double
    //     0x518938: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0x51893c: r3 = Null
    //     0x51893c: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b420] Null
    //     0x518940: ldr             x3, [x3, #0x420]
    // 0x518944: r0 = double()
    //     0x518944: bl              #0xd72bac  ; IsType_double_Stub
    // 0x518948: ldr             x16, [fp, #0x18]
    // 0x51894c: ldr             lr, [fp, #0x10]
    // 0x518950: stp             lr, x16, [SP, #-0x10]!
    // 0x518954: r0 = /()
    //     0x518954: bl              #0x518970  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::/
    // 0x518958: add             SP, SP, #0x10
    // 0x51895c: LeaveFrame
    //     0x51895c: mov             SP, fp
    //     0x518960: ldp             fp, lr, [SP], #0x10
    // 0x518964: ret
    //     0x518964: ret             
    // 0x518968: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x518968: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x51896c: b               #0x518914
  }
  EdgeInsets /(EdgeInsets, double) {
    // ** addr: 0x518970, size: 0x78
    // 0x518970: EnterFrame
    //     0x518970: stp             fp, lr, [SP, #-0x10]!
    //     0x518974: mov             fp, SP
    // 0x518978: AllocStack(0x20)
    //     0x518978: sub             SP, SP, #0x20
    // 0x51897c: ldr             x0, [fp, #0x18]
    // 0x518980: LoadField: d0 = r0->field_7
    //     0x518980: ldur            d0, [x0, #7]
    // 0x518984: ldr             x1, [fp, #0x10]
    // 0x518988: LoadField: d1 = r1->field_7
    //     0x518988: ldur            d1, [x1, #7]
    // 0x51898c: fdiv            d2, d0, d1
    // 0x518990: stur            d2, [fp, #-0x20]
    // 0x518994: LoadField: d0 = r0->field_f
    //     0x518994: ldur            d0, [x0, #0xf]
    // 0x518998: fdiv            d3, d0, d1
    // 0x51899c: stur            d3, [fp, #-0x18]
    // 0x5189a0: LoadField: d0 = r0->field_17
    //     0x5189a0: ldur            d0, [x0, #0x17]
    // 0x5189a4: fdiv            d4, d0, d1
    // 0x5189a8: stur            d4, [fp, #-0x10]
    // 0x5189ac: LoadField: d0 = r0->field_1f
    //     0x5189ac: ldur            d0, [x0, #0x1f]
    // 0x5189b0: fdiv            d5, d0, d1
    // 0x5189b4: stur            d5, [fp, #-8]
    // 0x5189b8: r0 = EdgeInsets()
    //     0x5189b8: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x5189bc: ldur            d0, [fp, #-0x20]
    // 0x5189c0: StoreField: r0->field_7 = d0
    //     0x5189c0: stur            d0, [x0, #7]
    // 0x5189c4: ldur            d0, [fp, #-0x18]
    // 0x5189c8: StoreField: r0->field_f = d0
    //     0x5189c8: stur            d0, [x0, #0xf]
    // 0x5189cc: ldur            d0, [fp, #-0x10]
    // 0x5189d0: StoreField: r0->field_17 = d0
    //     0x5189d0: stur            d0, [x0, #0x17]
    // 0x5189d4: ldur            d0, [fp, #-8]
    // 0x5189d8: StoreField: r0->field_1f = d0
    //     0x5189d8: stur            d0, [x0, #0x1f]
    // 0x5189dc: LeaveFrame
    //     0x5189dc: mov             SP, fp
    //     0x5189e0: ldp             fp, lr, [SP], #0x10
    // 0x5189e4: ret
    //     0x5189e4: ret             
  }
  EdgeInsets *(EdgeInsets, double) {
    // ** addr: 0x518a0c, size: 0x88
    // 0x518a0c: EnterFrame
    //     0x518a0c: stp             fp, lr, [SP, #-0x10]!
    //     0x518a10: mov             fp, SP
    // 0x518a14: CheckStackOverflow
    //     0x518a14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x518a18: cmp             SP, x16
    //     0x518a1c: b.ls            #0x518a74
    // 0x518a20: ldr             x0, [fp, #0x10]
    // 0x518a24: r2 = Null
    //     0x518a24: mov             x2, NULL
    // 0x518a28: r1 = Null
    //     0x518a28: mov             x1, NULL
    // 0x518a2c: r4 = 59
    //     0x518a2c: mov             x4, #0x3b
    // 0x518a30: branchIfSmi(r0, 0x518a3c)
    //     0x518a30: tbz             w0, #0, #0x518a3c
    // 0x518a34: r4 = LoadClassIdInstr(r0)
    //     0x518a34: ldur            x4, [x0, #-1]
    //     0x518a38: ubfx            x4, x4, #0xc, #0x14
    // 0x518a3c: cmp             x4, #0x3d
    // 0x518a40: b.eq            #0x518a54
    // 0x518a44: r8 = double
    //     0x518a44: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0x518a48: r3 = Null
    //     0x518a48: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2da98] Null
    //     0x518a4c: ldr             x3, [x3, #0xa98]
    // 0x518a50: r0 = double()
    //     0x518a50: bl              #0xd72bac  ; IsType_double_Stub
    // 0x518a54: ldr             x16, [fp, #0x18]
    // 0x518a58: ldr             lr, [fp, #0x10]
    // 0x518a5c: stp             lr, x16, [SP, #-0x10]!
    // 0x518a60: r0 = *()
    //     0x518a60: bl              #0xcfaec4  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::*
    // 0x518a64: add             SP, SP, #0x10
    // 0x518a68: LeaveFrame
    //     0x518a68: mov             SP, fp
    //     0x518a6c: ldp             fp, lr, [SP], #0x10
    // 0x518a70: ret
    //     0x518a70: ret             
    // 0x518a74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x518a74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x518a78: b               #0x518a20
  }
  EdgeInsets +(EdgeInsets, EdgeInsets) {
    // ** addr: 0x518a94, size: 0x8c
    // 0x518a94: EnterFrame
    //     0x518a94: stp             fp, lr, [SP, #-0x10]!
    //     0x518a98: mov             fp, SP
    // 0x518a9c: CheckStackOverflow
    //     0x518a9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x518aa0: cmp             SP, x16
    //     0x518aa4: b.ls            #0x518b00
    // 0x518aa8: ldr             x0, [fp, #0x10]
    // 0x518aac: r2 = Null
    //     0x518aac: mov             x2, NULL
    // 0x518ab0: r1 = Null
    //     0x518ab0: mov             x1, NULL
    // 0x518ab4: r4 = 59
    //     0x518ab4: mov             x4, #0x3b
    // 0x518ab8: branchIfSmi(r0, 0x518ac4)
    //     0x518ab8: tbz             w0, #0, #0x518ac4
    // 0x518abc: r4 = LoadClassIdInstr(r0)
    //     0x518abc: ldur            x4, [x0, #-1]
    //     0x518ac0: ubfx            x4, x4, #0xc, #0x14
    // 0x518ac4: cmp             x4, #0x837
    // 0x518ac8: b.eq            #0x518ae0
    // 0x518acc: r8 = EdgeInsets
    //     0x518acc: add             x8, PP, #0x28, lsl #12  ; [pp+0x286a8] Type: EdgeInsets
    //     0x518ad0: ldr             x8, [x8, #0x6a8]
    // 0x518ad4: r3 = Null
    //     0x518ad4: add             x3, PP, #0x28, lsl #12  ; [pp+0x286b0] Null
    //     0x518ad8: ldr             x3, [x3, #0x6b0]
    // 0x518adc: r0 = EdgeInsets()
    //     0x518adc: bl              #0x518c9c  ; IsType_EdgeInsets_Stub
    // 0x518ae0: ldr             x16, [fp, #0x18]
    // 0x518ae4: ldr             lr, [fp, #0x10]
    // 0x518ae8: stp             lr, x16, [SP, #-0x10]!
    // 0x518aec: r0 = +()
    //     0x518aec: bl              #0x518b08  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::+
    // 0x518af0: add             SP, SP, #0x10
    // 0x518af4: LeaveFrame
    //     0x518af4: mov             SP, fp
    //     0x518af8: ldp             fp, lr, [SP], #0x10
    // 0x518afc: ret
    //     0x518afc: ret             
    // 0x518b00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x518b00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x518b04: b               #0x518aa8
  }
  EdgeInsets +(EdgeInsets, EdgeInsets) {
    // ** addr: 0x518b08, size: 0x84
    // 0x518b08: EnterFrame
    //     0x518b08: stp             fp, lr, [SP, #-0x10]!
    //     0x518b0c: mov             fp, SP
    // 0x518b10: AllocStack(0x20)
    //     0x518b10: sub             SP, SP, #0x20
    // 0x518b14: ldr             x0, [fp, #0x18]
    // 0x518b18: LoadField: d0 = r0->field_7
    //     0x518b18: ldur            d0, [x0, #7]
    // 0x518b1c: ldr             x1, [fp, #0x10]
    // 0x518b20: LoadField: d1 = r1->field_7
    //     0x518b20: ldur            d1, [x1, #7]
    // 0x518b24: fadd            d2, d0, d1
    // 0x518b28: stur            d2, [fp, #-0x20]
    // 0x518b2c: LoadField: d0 = r0->field_f
    //     0x518b2c: ldur            d0, [x0, #0xf]
    // 0x518b30: LoadField: d1 = r1->field_f
    //     0x518b30: ldur            d1, [x1, #0xf]
    // 0x518b34: fadd            d3, d0, d1
    // 0x518b38: stur            d3, [fp, #-0x18]
    // 0x518b3c: LoadField: d0 = r0->field_17
    //     0x518b3c: ldur            d0, [x0, #0x17]
    // 0x518b40: LoadField: d1 = r1->field_17
    //     0x518b40: ldur            d1, [x1, #0x17]
    // 0x518b44: fadd            d4, d0, d1
    // 0x518b48: stur            d4, [fp, #-0x10]
    // 0x518b4c: LoadField: d0 = r0->field_1f
    //     0x518b4c: ldur            d0, [x0, #0x1f]
    // 0x518b50: LoadField: d1 = r1->field_1f
    //     0x518b50: ldur            d1, [x1, #0x1f]
    // 0x518b54: fadd            d5, d0, d1
    // 0x518b58: stur            d5, [fp, #-8]
    // 0x518b5c: r0 = EdgeInsets()
    //     0x518b5c: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x518b60: ldur            d0, [fp, #-0x20]
    // 0x518b64: StoreField: r0->field_7 = d0
    //     0x518b64: stur            d0, [x0, #7]
    // 0x518b68: ldur            d0, [fp, #-0x18]
    // 0x518b6c: StoreField: r0->field_f = d0
    //     0x518b6c: stur            d0, [x0, #0xf]
    // 0x518b70: ldur            d0, [fp, #-0x10]
    // 0x518b74: StoreField: r0->field_17 = d0
    //     0x518b74: stur            d0, [x0, #0x17]
    // 0x518b78: ldur            d0, [fp, #-8]
    // 0x518b7c: StoreField: r0->field_1f = d0
    //     0x518b7c: stur            d0, [x0, #0x1f]
    // 0x518b80: LeaveFrame
    //     0x518b80: mov             SP, fp
    //     0x518b84: ldp             fp, lr, [SP], #0x10
    // 0x518b88: ret
    //     0x518b88: ret             
  }
  EdgeInsets -(EdgeInsets, EdgeInsets) {
    // ** addr: 0x518ba4, size: 0x8c
    // 0x518ba4: EnterFrame
    //     0x518ba4: stp             fp, lr, [SP, #-0x10]!
    //     0x518ba8: mov             fp, SP
    // 0x518bac: CheckStackOverflow
    //     0x518bac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x518bb0: cmp             SP, x16
    //     0x518bb4: b.ls            #0x518c10
    // 0x518bb8: ldr             x0, [fp, #0x10]
    // 0x518bbc: r2 = Null
    //     0x518bbc: mov             x2, NULL
    // 0x518bc0: r1 = Null
    //     0x518bc0: mov             x1, NULL
    // 0x518bc4: r4 = 59
    //     0x518bc4: mov             x4, #0x3b
    // 0x518bc8: branchIfSmi(r0, 0x518bd4)
    //     0x518bc8: tbz             w0, #0, #0x518bd4
    // 0x518bcc: r4 = LoadClassIdInstr(r0)
    //     0x518bcc: ldur            x4, [x0, #-1]
    //     0x518bd0: ubfx            x4, x4, #0xc, #0x14
    // 0x518bd4: cmp             x4, #0x837
    // 0x518bd8: b.eq            #0x518bf0
    // 0x518bdc: r8 = EdgeInsets
    //     0x518bdc: add             x8, PP, #0x28, lsl #12  ; [pp+0x286a8] Type: EdgeInsets
    //     0x518be0: ldr             x8, [x8, #0x6a8]
    // 0x518be4: r3 = Null
    //     0x518be4: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2daa8] Null
    //     0x518be8: ldr             x3, [x3, #0xaa8]
    // 0x518bec: r0 = EdgeInsets()
    //     0x518bec: bl              #0x518c9c  ; IsType_EdgeInsets_Stub
    // 0x518bf0: ldr             x16, [fp, #0x18]
    // 0x518bf4: ldr             lr, [fp, #0x10]
    // 0x518bf8: stp             lr, x16, [SP, #-0x10]!
    // 0x518bfc: r0 = -()
    //     0x518bfc: bl              #0x518c18  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::-
    // 0x518c00: add             SP, SP, #0x10
    // 0x518c04: LeaveFrame
    //     0x518c04: mov             SP, fp
    //     0x518c08: ldp             fp, lr, [SP], #0x10
    // 0x518c0c: ret
    //     0x518c0c: ret             
    // 0x518c10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x518c10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x518c14: b               #0x518bb8
  }
  EdgeInsets -(EdgeInsets, EdgeInsets) {
    // ** addr: 0x518c18, size: 0x84
    // 0x518c18: EnterFrame
    //     0x518c18: stp             fp, lr, [SP, #-0x10]!
    //     0x518c1c: mov             fp, SP
    // 0x518c20: AllocStack(0x20)
    //     0x518c20: sub             SP, SP, #0x20
    // 0x518c24: ldr             x0, [fp, #0x18]
    // 0x518c28: LoadField: d0 = r0->field_7
    //     0x518c28: ldur            d0, [x0, #7]
    // 0x518c2c: ldr             x1, [fp, #0x10]
    // 0x518c30: LoadField: d1 = r1->field_7
    //     0x518c30: ldur            d1, [x1, #7]
    // 0x518c34: fsub            d2, d0, d1
    // 0x518c38: stur            d2, [fp, #-0x20]
    // 0x518c3c: LoadField: d0 = r0->field_f
    //     0x518c3c: ldur            d0, [x0, #0xf]
    // 0x518c40: LoadField: d1 = r1->field_f
    //     0x518c40: ldur            d1, [x1, #0xf]
    // 0x518c44: fsub            d3, d0, d1
    // 0x518c48: stur            d3, [fp, #-0x18]
    // 0x518c4c: LoadField: d0 = r0->field_17
    //     0x518c4c: ldur            d0, [x0, #0x17]
    // 0x518c50: LoadField: d1 = r1->field_17
    //     0x518c50: ldur            d1, [x1, #0x17]
    // 0x518c54: fsub            d4, d0, d1
    // 0x518c58: stur            d4, [fp, #-0x10]
    // 0x518c5c: LoadField: d0 = r0->field_1f
    //     0x518c5c: ldur            d0, [x0, #0x1f]
    // 0x518c60: LoadField: d1 = r1->field_1f
    //     0x518c60: ldur            d1, [x1, #0x1f]
    // 0x518c64: fsub            d5, d0, d1
    // 0x518c68: stur            d5, [fp, #-8]
    // 0x518c6c: r0 = EdgeInsets()
    //     0x518c6c: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x518c70: ldur            d0, [fp, #-0x20]
    // 0x518c74: StoreField: r0->field_7 = d0
    //     0x518c74: stur            d0, [x0, #7]
    // 0x518c78: ldur            d0, [fp, #-0x18]
    // 0x518c7c: StoreField: r0->field_f = d0
    //     0x518c7c: stur            d0, [x0, #0xf]
    // 0x518c80: ldur            d0, [fp, #-0x10]
    // 0x518c84: StoreField: r0->field_17 = d0
    //     0x518c84: stur            d0, [x0, #0x17]
    // 0x518c88: ldur            d0, [fp, #-8]
    // 0x518c8c: StoreField: r0->field_1f = d0
    //     0x518c8c: stur            d0, [x0, #0x1f]
    // 0x518c90: LeaveFrame
    //     0x518c90: mov             SP, fp
    //     0x518c94: ldp             fp, lr, [SP], #0x10
    // 0x518c98: ret
    //     0x518c98: ret             
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x51a23c, size: 0x1fc
    // 0x51a23c: EnterFrame
    //     0x51a23c: stp             fp, lr, [SP, #-0x10]!
    //     0x51a240: mov             fp, SP
    // 0x51a244: AllocStack(0x20)
    //     0x51a244: sub             SP, SP, #0x20
    // 0x51a248: SetupParameters(EdgeInsets this /* r3 */, {dynamic bottom = Null /* r4 */, dynamic left = Null /* r5 */, dynamic right = Null /* r6 */, dynamic top = Null /* r0 */})
    //     0x51a248: mov             x0, x4
    //     0x51a24c: ldur            w1, [x0, #0x13]
    //     0x51a250: add             x1, x1, HEAP, lsl #32
    //     0x51a254: sub             x2, x1, #2
    //     0x51a258: add             x3, fp, w2, sxtw #2
    //     0x51a25c: ldr             x3, [x3, #0x10]
    //     0x51a260: ldur            w2, [x0, #0x1f]
    //     0x51a264: add             x2, x2, HEAP, lsl #32
    //     0x51a268: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fbe8] "bottom"
    //     0x51a26c: ldr             x16, [x16, #0xbe8]
    //     0x51a270: cmp             w2, w16
    //     0x51a274: b.ne            #0x51a298
    //     0x51a278: ldur            w2, [x0, #0x23]
    //     0x51a27c: add             x2, x2, HEAP, lsl #32
    //     0x51a280: sub             w4, w1, w2
    //     0x51a284: add             x2, fp, w4, sxtw #2
    //     0x51a288: ldr             x2, [x2, #8]
    //     0x51a28c: mov             x4, x2
    //     0x51a290: mov             x2, #1
    //     0x51a294: b               #0x51a2a0
    //     0x51a298: mov             x4, NULL
    //     0x51a29c: mov             x2, #0
    //     0x51a2a0: lsl             x5, x2, #1
    //     0x51a2a4: lsl             w6, w5, #1
    //     0x51a2a8: add             w7, w6, #8
    //     0x51a2ac: add             x16, x0, w7, sxtw #1
    //     0x51a2b0: ldur            w8, [x16, #0xf]
    //     0x51a2b4: add             x8, x8, HEAP, lsl #32
    //     0x51a2b8: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fbf0] "left"
    //     0x51a2bc: ldr             x16, [x16, #0xbf0]
    //     0x51a2c0: cmp             w8, w16
    //     0x51a2c4: b.ne            #0x51a2f8
    //     0x51a2c8: add             w2, w6, #0xa
    //     0x51a2cc: add             x16, x0, w2, sxtw #1
    //     0x51a2d0: ldur            w6, [x16, #0xf]
    //     0x51a2d4: add             x6, x6, HEAP, lsl #32
    //     0x51a2d8: sub             w2, w1, w6
    //     0x51a2dc: add             x6, fp, w2, sxtw #2
    //     0x51a2e0: ldr             x6, [x6, #8]
    //     0x51a2e4: add             w2, w5, #2
    //     0x51a2e8: sbfx            x5, x2, #1, #0x1f
    //     0x51a2ec: mov             x2, x5
    //     0x51a2f0: mov             x5, x6
    //     0x51a2f4: b               #0x51a2fc
    //     0x51a2f8: mov             x5, NULL
    //     0x51a2fc: lsl             x6, x2, #1
    //     0x51a300: lsl             w7, w6, #1
    //     0x51a304: add             w8, w7, #8
    //     0x51a308: add             x16, x0, w8, sxtw #1
    //     0x51a30c: ldur            w9, [x16, #0xf]
    //     0x51a310: add             x9, x9, HEAP, lsl #32
    //     0x51a314: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fbf8] "right"
    //     0x51a318: ldr             x16, [x16, #0xbf8]
    //     0x51a31c: cmp             w9, w16
    //     0x51a320: b.ne            #0x51a354
    //     0x51a324: add             w2, w7, #0xa
    //     0x51a328: add             x16, x0, w2, sxtw #1
    //     0x51a32c: ldur            w7, [x16, #0xf]
    //     0x51a330: add             x7, x7, HEAP, lsl #32
    //     0x51a334: sub             w2, w1, w7
    //     0x51a338: add             x7, fp, w2, sxtw #2
    //     0x51a33c: ldr             x7, [x7, #8]
    //     0x51a340: add             w2, w6, #2
    //     0x51a344: sbfx            x6, x2, #1, #0x1f
    //     0x51a348: mov             x2, x6
    //     0x51a34c: mov             x6, x7
    //     0x51a350: b               #0x51a358
    //     0x51a354: mov             x6, NULL
    //     0x51a358: lsl             x7, x2, #1
    //     0x51a35c: lsl             w2, w7, #1
    //     0x51a360: add             w7, w2, #8
    //     0x51a364: add             x16, x0, w7, sxtw #1
    //     0x51a368: ldur            w8, [x16, #0xf]
    //     0x51a36c: add             x8, x8, HEAP, lsl #32
    //     0x51a370: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fc00] "top"
    //     0x51a374: ldr             x16, [x16, #0xc00]
    //     0x51a378: cmp             w8, w16
    //     0x51a37c: b.ne            #0x51a3a4
    //     0x51a380: add             w7, w2, #0xa
    //     0x51a384: add             x16, x0, w7, sxtw #1
    //     0x51a388: ldur            w2, [x16, #0xf]
    //     0x51a38c: add             x2, x2, HEAP, lsl #32
    //     0x51a390: sub             w0, w1, w2
    //     0x51a394: add             x1, fp, w0, sxtw #2
    //     0x51a398: ldr             x1, [x1, #8]
    //     0x51a39c: mov             x0, x1
    //     0x51a3a0: b               #0x51a3a8
    //     0x51a3a4: mov             x0, NULL
    // 0x51a3a8: cmp             w5, NULL
    // 0x51a3ac: b.ne            #0x51a3b8
    // 0x51a3b0: LoadField: d0 = r3->field_7
    //     0x51a3b0: ldur            d0, [x3, #7]
    // 0x51a3b4: b               #0x51a3bc
    // 0x51a3b8: LoadField: d0 = r5->field_7
    //     0x51a3b8: ldur            d0, [x5, #7]
    // 0x51a3bc: stur            d0, [fp, #-0x20]
    // 0x51a3c0: cmp             w0, NULL
    // 0x51a3c4: b.ne            #0x51a3d0
    // 0x51a3c8: LoadField: d1 = r3->field_f
    //     0x51a3c8: ldur            d1, [x3, #0xf]
    // 0x51a3cc: b               #0x51a3d4
    // 0x51a3d0: LoadField: d1 = r0->field_7
    //     0x51a3d0: ldur            d1, [x0, #7]
    // 0x51a3d4: stur            d1, [fp, #-0x18]
    // 0x51a3d8: cmp             w6, NULL
    // 0x51a3dc: b.ne            #0x51a3e8
    // 0x51a3e0: LoadField: d2 = r3->field_17
    //     0x51a3e0: ldur            d2, [x3, #0x17]
    // 0x51a3e4: b               #0x51a3ec
    // 0x51a3e8: LoadField: d2 = r6->field_7
    //     0x51a3e8: ldur            d2, [x6, #7]
    // 0x51a3ec: stur            d2, [fp, #-0x10]
    // 0x51a3f0: cmp             w4, NULL
    // 0x51a3f4: b.ne            #0x51a400
    // 0x51a3f8: LoadField: d3 = r3->field_1f
    //     0x51a3f8: ldur            d3, [x3, #0x1f]
    // 0x51a3fc: b               #0x51a404
    // 0x51a400: LoadField: d3 = r4->field_7
    //     0x51a400: ldur            d3, [x4, #7]
    // 0x51a404: stur            d3, [fp, #-8]
    // 0x51a408: r0 = EdgeInsets()
    //     0x51a408: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x51a40c: ldur            d0, [fp, #-0x20]
    // 0x51a410: StoreField: r0->field_7 = d0
    //     0x51a410: stur            d0, [x0, #7]
    // 0x51a414: ldur            d0, [fp, #-0x18]
    // 0x51a418: StoreField: r0->field_f = d0
    //     0x51a418: stur            d0, [x0, #0xf]
    // 0x51a41c: ldur            d0, [fp, #-0x10]
    // 0x51a420: StoreField: r0->field_17 = d0
    //     0x51a420: stur            d0, [x0, #0x17]
    // 0x51a424: ldur            d0, [fp, #-8]
    // 0x51a428: StoreField: r0->field_1f = d0
    //     0x51a428: stur            d0, [x0, #0x1f]
    // 0x51a42c: LeaveFrame
    //     0x51a42c: mov             SP, fp
    //     0x51a430: ldp             fp, lr, [SP], #0x10
    // 0x51a434: ret
    //     0x51a434: ret             
  }
  _ deflateRect(/* No info */) {
    // ** addr: 0x65ae60, size: 0x84
    // 0x65ae60: EnterFrame
    //     0x65ae60: stp             fp, lr, [SP, #-0x10]!
    //     0x65ae64: mov             fp, SP
    // 0x65ae68: AllocStack(0x20)
    //     0x65ae68: sub             SP, SP, #0x20
    // 0x65ae6c: ldr             x0, [fp, #0x10]
    // 0x65ae70: LoadField: d0 = r0->field_7
    //     0x65ae70: ldur            d0, [x0, #7]
    // 0x65ae74: ldr             x1, [fp, #0x18]
    // 0x65ae78: LoadField: d1 = r1->field_7
    //     0x65ae78: ldur            d1, [x1, #7]
    // 0x65ae7c: fadd            d2, d0, d1
    // 0x65ae80: stur            d2, [fp, #-0x20]
    // 0x65ae84: LoadField: d0 = r0->field_f
    //     0x65ae84: ldur            d0, [x0, #0xf]
    // 0x65ae88: LoadField: d1 = r1->field_f
    //     0x65ae88: ldur            d1, [x1, #0xf]
    // 0x65ae8c: fadd            d3, d0, d1
    // 0x65ae90: stur            d3, [fp, #-0x18]
    // 0x65ae94: LoadField: d0 = r0->field_17
    //     0x65ae94: ldur            d0, [x0, #0x17]
    // 0x65ae98: LoadField: d1 = r1->field_17
    //     0x65ae98: ldur            d1, [x1, #0x17]
    // 0x65ae9c: fsub            d4, d0, d1
    // 0x65aea0: stur            d4, [fp, #-0x10]
    // 0x65aea4: LoadField: d0 = r0->field_1f
    //     0x65aea4: ldur            d0, [x0, #0x1f]
    // 0x65aea8: LoadField: d1 = r1->field_1f
    //     0x65aea8: ldur            d1, [x1, #0x1f]
    // 0x65aeac: fsub            d5, d0, d1
    // 0x65aeb0: stur            d5, [fp, #-8]
    // 0x65aeb4: r0 = Rect()
    //     0x65aeb4: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x65aeb8: ldur            d0, [fp, #-0x20]
    // 0x65aebc: StoreField: r0->field_7 = d0
    //     0x65aebc: stur            d0, [x0, #7]
    // 0x65aec0: ldur            d0, [fp, #-0x18]
    // 0x65aec4: StoreField: r0->field_f = d0
    //     0x65aec4: stur            d0, [x0, #0xf]
    // 0x65aec8: ldur            d0, [fp, #-0x10]
    // 0x65aecc: StoreField: r0->field_17 = d0
    //     0x65aecc: stur            d0, [x0, #0x17]
    // 0x65aed0: ldur            d0, [fp, #-8]
    // 0x65aed4: StoreField: r0->field_1f = d0
    //     0x65aed4: stur            d0, [x0, #0x1f]
    // 0x65aed8: LeaveFrame
    //     0x65aed8: mov             SP, fp
    //     0x65aedc: ldp             fp, lr, [SP], #0x10
    // 0x65aee0: ret
    //     0x65aee0: ret             
  }
  _ EdgeInsets.fromWindowPadding(/* No info */) {
    // ** addr: 0x87fd40, size: 0x44
    // 0x87fd40: ldr             x1, [SP, #8]
    // 0x87fd44: LoadField: d0 = r1->field_7
    //     0x87fd44: ldur            d0, [x1, #7]
    // 0x87fd48: ldr             d1, [SP]
    // 0x87fd4c: fdiv            d2, d0, d1
    // 0x87fd50: ldr             x2, [SP, #0x10]
    // 0x87fd54: StoreField: r2->field_7 = d2
    //     0x87fd54: stur            d2, [x2, #7]
    // 0x87fd58: LoadField: d0 = r1->field_f
    //     0x87fd58: ldur            d0, [x1, #0xf]
    // 0x87fd5c: fdiv            d2, d0, d1
    // 0x87fd60: StoreField: r2->field_f = d2
    //     0x87fd60: stur            d2, [x2, #0xf]
    // 0x87fd64: LoadField: d0 = r1->field_17
    //     0x87fd64: ldur            d0, [x1, #0x17]
    // 0x87fd68: fdiv            d2, d0, d1
    // 0x87fd6c: StoreField: r2->field_17 = d2
    //     0x87fd6c: stur            d2, [x2, #0x17]
    // 0x87fd70: LoadField: d0 = r1->field_1f
    //     0x87fd70: ldur            d0, [x1, #0x1f]
    // 0x87fd74: fdiv            d2, d0, d1
    // 0x87fd78: StoreField: r2->field_1f = d2
    //     0x87fd78: stur            d2, [x2, #0x1f]
    // 0x87fd7c: r0 = Null
    //     0x87fd7c: mov             x0, NULL
    // 0x87fd80: ret
    //     0x87fd80: ret             
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf1e98, size: 0x4d8
    // 0xbf1e98: EnterFrame
    //     0xbf1e98: stp             fp, lr, [SP, #-0x10]!
    //     0xbf1e9c: mov             fp, SP
    // 0xbf1ea0: AllocStack(0x28)
    //     0xbf1ea0: sub             SP, SP, #0x28
    // 0xbf1ea4: CheckStackOverflow
    //     0xbf1ea4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf1ea8: cmp             SP, x16
    //     0xbf1eac: b.ls            #0xbf21ec
    // 0xbf1eb0: ldr             x0, [fp, #0x20]
    // 0xbf1eb4: cmp             w0, NULL
    // 0xbf1eb8: b.ne            #0xbf1ed8
    // 0xbf1ebc: ldr             x1, [fp, #0x18]
    // 0xbf1ec0: cmp             w1, NULL
    // 0xbf1ec4: b.ne            #0xbf1edc
    // 0xbf1ec8: r0 = Null
    //     0xbf1ec8: mov             x0, NULL
    // 0xbf1ecc: LeaveFrame
    //     0xbf1ecc: mov             SP, fp
    //     0xbf1ed0: ldp             fp, lr, [SP], #0x10
    // 0xbf1ed4: ret
    //     0xbf1ed4: ret             
    // 0xbf1ed8: ldr             x1, [fp, #0x18]
    // 0xbf1edc: cmp             w0, NULL
    // 0xbf1ee0: b.ne            #0xbf1f30
    // 0xbf1ee4: ldr             d0, [fp, #0x10]
    // 0xbf1ee8: cmp             w1, NULL
    // 0xbf1eec: b.eq            #0xbf21f4
    // 0xbf1ef0: r0 = inline_Allocate_Double()
    //     0xbf1ef0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xbf1ef4: add             x0, x0, #0x10
    //     0xbf1ef8: cmp             x2, x0
    //     0xbf1efc: b.ls            #0xbf21f8
    //     0xbf1f00: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf1f04: sub             x0, x0, #0xf
    //     0xbf1f08: mov             x2, #0xd108
    //     0xbf1f0c: movk            x2, #3, lsl #16
    //     0xbf1f10: stur            x2, [x0, #-1]
    // 0xbf1f14: StoreField: r0->field_7 = d0
    //     0xbf1f14: stur            d0, [x0, #7]
    // 0xbf1f18: stp             x0, x1, [SP, #-0x10]!
    // 0xbf1f1c: r0 = *()
    //     0xbf1f1c: bl              #0xcfaec4  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::*
    // 0xbf1f20: add             SP, SP, #0x10
    // 0xbf1f24: LeaveFrame
    //     0xbf1f24: mov             SP, fp
    //     0xbf1f28: ldp             fp, lr, [SP], #0x10
    // 0xbf1f2c: ret
    //     0xbf1f2c: ret             
    // 0xbf1f30: ldr             d0, [fp, #0x10]
    // 0xbf1f34: cmp             w1, NULL
    // 0xbf1f38: b.ne            #0xbf1f84
    // 0xbf1f3c: d1 = 1.000000
    //     0xbf1f3c: fmov            d1, #1.00000000
    // 0xbf1f40: fsub            d2, d1, d0
    // 0xbf1f44: r1 = inline_Allocate_Double()
    //     0xbf1f44: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbf1f48: add             x1, x1, #0x10
    //     0xbf1f4c: cmp             x2, x1
    //     0xbf1f50: b.ls            #0xbf2210
    //     0xbf1f54: str             x1, [THR, #0x60]  ; THR::top
    //     0xbf1f58: sub             x1, x1, #0xf
    //     0xbf1f5c: mov             x2, #0xd108
    //     0xbf1f60: movk            x2, #3, lsl #16
    //     0xbf1f64: stur            x2, [x1, #-1]
    // 0xbf1f68: StoreField: r1->field_7 = d2
    //     0xbf1f68: stur            d2, [x1, #7]
    // 0xbf1f6c: stp             x1, x0, [SP, #-0x10]!
    // 0xbf1f70: r0 = *()
    //     0xbf1f70: bl              #0xcfaec4  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::*
    // 0xbf1f74: add             SP, SP, #0x10
    // 0xbf1f78: LeaveFrame
    //     0xbf1f78: mov             SP, fp
    //     0xbf1f7c: ldp             fp, lr, [SP], #0x10
    // 0xbf1f80: ret
    //     0xbf1f80: ret             
    // 0xbf1f84: LoadField: d1 = r0->field_7
    //     0xbf1f84: ldur            d1, [x0, #7]
    // 0xbf1f88: LoadField: d2 = r1->field_7
    //     0xbf1f88: ldur            d2, [x1, #7]
    // 0xbf1f8c: r2 = inline_Allocate_Double()
    //     0xbf1f8c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbf1f90: add             x2, x2, #0x10
    //     0xbf1f94: cmp             x3, x2
    //     0xbf1f98: b.ls            #0xbf222c
    //     0xbf1f9c: str             x2, [THR, #0x60]  ; THR::top
    //     0xbf1fa0: sub             x2, x2, #0xf
    //     0xbf1fa4: mov             x3, #0xd108
    //     0xbf1fa8: movk            x3, #3, lsl #16
    //     0xbf1fac: stur            x3, [x2, #-1]
    // 0xbf1fb0: StoreField: r2->field_7 = d0
    //     0xbf1fb0: stur            d0, [x2, #7]
    // 0xbf1fb4: stur            x2, [fp, #-8]
    // 0xbf1fb8: r3 = inline_Allocate_Double()
    //     0xbf1fb8: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xbf1fbc: add             x3, x3, #0x10
    //     0xbf1fc0: cmp             x4, x3
    //     0xbf1fc4: b.ls            #0xbf2250
    //     0xbf1fc8: str             x3, [THR, #0x60]  ; THR::top
    //     0xbf1fcc: sub             x3, x3, #0xf
    //     0xbf1fd0: mov             x4, #0xd108
    //     0xbf1fd4: movk            x4, #3, lsl #16
    //     0xbf1fd8: stur            x4, [x3, #-1]
    // 0xbf1fdc: StoreField: r3->field_7 = d1
    //     0xbf1fdc: stur            d1, [x3, #7]
    // 0xbf1fe0: r4 = inline_Allocate_Double()
    //     0xbf1fe0: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbf1fe4: add             x4, x4, #0x10
    //     0xbf1fe8: cmp             x5, x4
    //     0xbf1fec: b.ls            #0xbf2274
    //     0xbf1ff0: str             x4, [THR, #0x60]  ; THR::top
    //     0xbf1ff4: sub             x4, x4, #0xf
    //     0xbf1ff8: mov             x5, #0xd108
    //     0xbf1ffc: movk            x5, #3, lsl #16
    //     0xbf2000: stur            x5, [x4, #-1]
    // 0xbf2004: StoreField: r4->field_7 = d2
    //     0xbf2004: stur            d2, [x4, #7]
    // 0xbf2008: stp             x4, x3, [SP, #-0x10]!
    // 0xbf200c: SaveReg r2
    //     0xbf200c: str             x2, [SP, #-8]!
    // 0xbf2010: r0 = lerpDouble()
    //     0xbf2010: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf2014: add             SP, SP, #0x18
    // 0xbf2018: stur            x0, [fp, #-0x10]
    // 0xbf201c: cmp             w0, NULL
    // 0xbf2020: b.eq            #0xbf2298
    // 0xbf2024: ldr             x1, [fp, #0x20]
    // 0xbf2028: LoadField: d0 = r1->field_f
    //     0xbf2028: ldur            d0, [x1, #0xf]
    // 0xbf202c: ldr             x2, [fp, #0x18]
    // 0xbf2030: LoadField: d1 = r2->field_f
    //     0xbf2030: ldur            d1, [x2, #0xf]
    // 0xbf2034: r3 = inline_Allocate_Double()
    //     0xbf2034: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xbf2038: add             x3, x3, #0x10
    //     0xbf203c: cmp             x4, x3
    //     0xbf2040: b.ls            #0xbf229c
    //     0xbf2044: str             x3, [THR, #0x60]  ; THR::top
    //     0xbf2048: sub             x3, x3, #0xf
    //     0xbf204c: mov             x4, #0xd108
    //     0xbf2050: movk            x4, #3, lsl #16
    //     0xbf2054: stur            x4, [x3, #-1]
    // 0xbf2058: StoreField: r3->field_7 = d0
    //     0xbf2058: stur            d0, [x3, #7]
    // 0xbf205c: r4 = inline_Allocate_Double()
    //     0xbf205c: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbf2060: add             x4, x4, #0x10
    //     0xbf2064: cmp             x5, x4
    //     0xbf2068: b.ls            #0xbf22c0
    //     0xbf206c: str             x4, [THR, #0x60]  ; THR::top
    //     0xbf2070: sub             x4, x4, #0xf
    //     0xbf2074: mov             x5, #0xd108
    //     0xbf2078: movk            x5, #3, lsl #16
    //     0xbf207c: stur            x5, [x4, #-1]
    // 0xbf2080: StoreField: r4->field_7 = d1
    //     0xbf2080: stur            d1, [x4, #7]
    // 0xbf2084: stp             x4, x3, [SP, #-0x10]!
    // 0xbf2088: ldur            x16, [fp, #-8]
    // 0xbf208c: SaveReg r16
    //     0xbf208c: str             x16, [SP, #-8]!
    // 0xbf2090: r0 = lerpDouble()
    //     0xbf2090: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf2094: add             SP, SP, #0x18
    // 0xbf2098: stur            x0, [fp, #-0x18]
    // 0xbf209c: cmp             w0, NULL
    // 0xbf20a0: b.eq            #0xbf22e4
    // 0xbf20a4: ldr             x1, [fp, #0x20]
    // 0xbf20a8: LoadField: d0 = r1->field_17
    //     0xbf20a8: ldur            d0, [x1, #0x17]
    // 0xbf20ac: ldr             x2, [fp, #0x18]
    // 0xbf20b0: LoadField: d1 = r2->field_17
    //     0xbf20b0: ldur            d1, [x2, #0x17]
    // 0xbf20b4: r3 = inline_Allocate_Double()
    //     0xbf20b4: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xbf20b8: add             x3, x3, #0x10
    //     0xbf20bc: cmp             x4, x3
    //     0xbf20c0: b.ls            #0xbf22e8
    //     0xbf20c4: str             x3, [THR, #0x60]  ; THR::top
    //     0xbf20c8: sub             x3, x3, #0xf
    //     0xbf20cc: mov             x4, #0xd108
    //     0xbf20d0: movk            x4, #3, lsl #16
    //     0xbf20d4: stur            x4, [x3, #-1]
    // 0xbf20d8: StoreField: r3->field_7 = d0
    //     0xbf20d8: stur            d0, [x3, #7]
    // 0xbf20dc: r4 = inline_Allocate_Double()
    //     0xbf20dc: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbf20e0: add             x4, x4, #0x10
    //     0xbf20e4: cmp             x5, x4
    //     0xbf20e8: b.ls            #0xbf230c
    //     0xbf20ec: str             x4, [THR, #0x60]  ; THR::top
    //     0xbf20f0: sub             x4, x4, #0xf
    //     0xbf20f4: mov             x5, #0xd108
    //     0xbf20f8: movk            x5, #3, lsl #16
    //     0xbf20fc: stur            x5, [x4, #-1]
    // 0xbf2100: StoreField: r4->field_7 = d1
    //     0xbf2100: stur            d1, [x4, #7]
    // 0xbf2104: stp             x4, x3, [SP, #-0x10]!
    // 0xbf2108: ldur            x16, [fp, #-8]
    // 0xbf210c: SaveReg r16
    //     0xbf210c: str             x16, [SP, #-8]!
    // 0xbf2110: r0 = lerpDouble()
    //     0xbf2110: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf2114: add             SP, SP, #0x18
    // 0xbf2118: stur            x0, [fp, #-0x20]
    // 0xbf211c: cmp             w0, NULL
    // 0xbf2120: b.eq            #0xbf2330
    // 0xbf2124: ldr             x1, [fp, #0x20]
    // 0xbf2128: LoadField: d0 = r1->field_1f
    //     0xbf2128: ldur            d0, [x1, #0x1f]
    // 0xbf212c: ldr             x1, [fp, #0x18]
    // 0xbf2130: LoadField: d1 = r1->field_1f
    //     0xbf2130: ldur            d1, [x1, #0x1f]
    // 0xbf2134: r1 = inline_Allocate_Double()
    //     0xbf2134: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbf2138: add             x1, x1, #0x10
    //     0xbf213c: cmp             x2, x1
    //     0xbf2140: b.ls            #0xbf2334
    //     0xbf2144: str             x1, [THR, #0x60]  ; THR::top
    //     0xbf2148: sub             x1, x1, #0xf
    //     0xbf214c: mov             x2, #0xd108
    //     0xbf2150: movk            x2, #3, lsl #16
    //     0xbf2154: stur            x2, [x1, #-1]
    // 0xbf2158: StoreField: r1->field_7 = d0
    //     0xbf2158: stur            d0, [x1, #7]
    // 0xbf215c: r2 = inline_Allocate_Double()
    //     0xbf215c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbf2160: add             x2, x2, #0x10
    //     0xbf2164: cmp             x3, x2
    //     0xbf2168: b.ls            #0xbf2350
    //     0xbf216c: str             x2, [THR, #0x60]  ; THR::top
    //     0xbf2170: sub             x2, x2, #0xf
    //     0xbf2174: mov             x3, #0xd108
    //     0xbf2178: movk            x3, #3, lsl #16
    //     0xbf217c: stur            x3, [x2, #-1]
    // 0xbf2180: StoreField: r2->field_7 = d1
    //     0xbf2180: stur            d1, [x2, #7]
    // 0xbf2184: stp             x2, x1, [SP, #-0x10]!
    // 0xbf2188: ldur            x16, [fp, #-8]
    // 0xbf218c: SaveReg r16
    //     0xbf218c: str             x16, [SP, #-8]!
    // 0xbf2190: r0 = lerpDouble()
    //     0xbf2190: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf2194: add             SP, SP, #0x18
    // 0xbf2198: stur            x0, [fp, #-8]
    // 0xbf219c: cmp             w0, NULL
    // 0xbf21a0: b.eq            #0xbf236c
    // 0xbf21a4: ldur            x1, [fp, #-0x10]
    // 0xbf21a8: LoadField: d0 = r1->field_7
    //     0xbf21a8: ldur            d0, [x1, #7]
    // 0xbf21ac: stur            d0, [fp, #-0x28]
    // 0xbf21b0: r0 = EdgeInsets()
    //     0xbf21b0: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xbf21b4: ldur            d0, [fp, #-0x28]
    // 0xbf21b8: StoreField: r0->field_7 = d0
    //     0xbf21b8: stur            d0, [x0, #7]
    // 0xbf21bc: ldur            x1, [fp, #-0x18]
    // 0xbf21c0: LoadField: d0 = r1->field_7
    //     0xbf21c0: ldur            d0, [x1, #7]
    // 0xbf21c4: StoreField: r0->field_f = d0
    //     0xbf21c4: stur            d0, [x0, #0xf]
    // 0xbf21c8: ldur            x1, [fp, #-0x20]
    // 0xbf21cc: LoadField: d0 = r1->field_7
    //     0xbf21cc: ldur            d0, [x1, #7]
    // 0xbf21d0: StoreField: r0->field_17 = d0
    //     0xbf21d0: stur            d0, [x0, #0x17]
    // 0xbf21d4: ldur            x1, [fp, #-8]
    // 0xbf21d8: LoadField: d0 = r1->field_7
    //     0xbf21d8: ldur            d0, [x1, #7]
    // 0xbf21dc: StoreField: r0->field_1f = d0
    //     0xbf21dc: stur            d0, [x0, #0x1f]
    // 0xbf21e0: LeaveFrame
    //     0xbf21e0: mov             SP, fp
    //     0xbf21e4: ldp             fp, lr, [SP], #0x10
    // 0xbf21e8: ret
    //     0xbf21e8: ret             
    // 0xbf21ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf21ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf21f0: b               #0xbf1eb0
    // 0xbf21f4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbf21f4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xbf21f8: SaveReg d0
    //     0xbf21f8: str             q0, [SP, #-0x10]!
    // 0xbf21fc: SaveReg r1
    //     0xbf21fc: str             x1, [SP, #-8]!
    // 0xbf2200: r0 = AllocateDouble()
    //     0xbf2200: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf2204: RestoreReg r1
    //     0xbf2204: ldr             x1, [SP], #8
    // 0xbf2208: RestoreReg d0
    //     0xbf2208: ldr             q0, [SP], #0x10
    // 0xbf220c: b               #0xbf1f14
    // 0xbf2210: SaveReg d2
    //     0xbf2210: str             q2, [SP, #-0x10]!
    // 0xbf2214: SaveReg r0
    //     0xbf2214: str             x0, [SP, #-8]!
    // 0xbf2218: r0 = AllocateDouble()
    //     0xbf2218: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf221c: mov             x1, x0
    // 0xbf2220: RestoreReg r0
    //     0xbf2220: ldr             x0, [SP], #8
    // 0xbf2224: RestoreReg d2
    //     0xbf2224: ldr             q2, [SP], #0x10
    // 0xbf2228: b               #0xbf1f68
    // 0xbf222c: stp             q1, q2, [SP, #-0x20]!
    // 0xbf2230: SaveReg d0
    //     0xbf2230: str             q0, [SP, #-0x10]!
    // 0xbf2234: stp             x0, x1, [SP, #-0x10]!
    // 0xbf2238: r0 = AllocateDouble()
    //     0xbf2238: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf223c: mov             x2, x0
    // 0xbf2240: ldp             x0, x1, [SP], #0x10
    // 0xbf2244: RestoreReg d0
    //     0xbf2244: ldr             q0, [SP], #0x10
    // 0xbf2248: ldp             q1, q2, [SP], #0x20
    // 0xbf224c: b               #0xbf1fb0
    // 0xbf2250: stp             q1, q2, [SP, #-0x20]!
    // 0xbf2254: stp             x1, x2, [SP, #-0x10]!
    // 0xbf2258: SaveReg r0
    //     0xbf2258: str             x0, [SP, #-8]!
    // 0xbf225c: r0 = AllocateDouble()
    //     0xbf225c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf2260: mov             x3, x0
    // 0xbf2264: RestoreReg r0
    //     0xbf2264: ldr             x0, [SP], #8
    // 0xbf2268: ldp             x1, x2, [SP], #0x10
    // 0xbf226c: ldp             q1, q2, [SP], #0x20
    // 0xbf2270: b               #0xbf1fdc
    // 0xbf2274: SaveReg d2
    //     0xbf2274: str             q2, [SP, #-0x10]!
    // 0xbf2278: stp             x2, x3, [SP, #-0x10]!
    // 0xbf227c: stp             x0, x1, [SP, #-0x10]!
    // 0xbf2280: r0 = AllocateDouble()
    //     0xbf2280: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf2284: mov             x4, x0
    // 0xbf2288: ldp             x0, x1, [SP], #0x10
    // 0xbf228c: ldp             x2, x3, [SP], #0x10
    // 0xbf2290: RestoreReg d2
    //     0xbf2290: ldr             q2, [SP], #0x10
    // 0xbf2294: b               #0xbf2004
    // 0xbf2298: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf2298: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf229c: stp             q0, q1, [SP, #-0x20]!
    // 0xbf22a0: stp             x1, x2, [SP, #-0x10]!
    // 0xbf22a4: SaveReg r0
    //     0xbf22a4: str             x0, [SP, #-8]!
    // 0xbf22a8: r0 = AllocateDouble()
    //     0xbf22a8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf22ac: mov             x3, x0
    // 0xbf22b0: RestoreReg r0
    //     0xbf22b0: ldr             x0, [SP], #8
    // 0xbf22b4: ldp             x1, x2, [SP], #0x10
    // 0xbf22b8: ldp             q0, q1, [SP], #0x20
    // 0xbf22bc: b               #0xbf2058
    // 0xbf22c0: SaveReg d1
    //     0xbf22c0: str             q1, [SP, #-0x10]!
    // 0xbf22c4: stp             x2, x3, [SP, #-0x10]!
    // 0xbf22c8: stp             x0, x1, [SP, #-0x10]!
    // 0xbf22cc: r0 = AllocateDouble()
    //     0xbf22cc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf22d0: mov             x4, x0
    // 0xbf22d4: ldp             x0, x1, [SP], #0x10
    // 0xbf22d8: ldp             x2, x3, [SP], #0x10
    // 0xbf22dc: RestoreReg d1
    //     0xbf22dc: ldr             q1, [SP], #0x10
    // 0xbf22e0: b               #0xbf2080
    // 0xbf22e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf22e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf22e8: stp             q0, q1, [SP, #-0x20]!
    // 0xbf22ec: stp             x1, x2, [SP, #-0x10]!
    // 0xbf22f0: SaveReg r0
    //     0xbf22f0: str             x0, [SP, #-8]!
    // 0xbf22f4: r0 = AllocateDouble()
    //     0xbf22f4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf22f8: mov             x3, x0
    // 0xbf22fc: RestoreReg r0
    //     0xbf22fc: ldr             x0, [SP], #8
    // 0xbf2300: ldp             x1, x2, [SP], #0x10
    // 0xbf2304: ldp             q0, q1, [SP], #0x20
    // 0xbf2308: b               #0xbf20d8
    // 0xbf230c: SaveReg d1
    //     0xbf230c: str             q1, [SP, #-0x10]!
    // 0xbf2310: stp             x2, x3, [SP, #-0x10]!
    // 0xbf2314: stp             x0, x1, [SP, #-0x10]!
    // 0xbf2318: r0 = AllocateDouble()
    //     0xbf2318: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf231c: mov             x4, x0
    // 0xbf2320: ldp             x0, x1, [SP], #0x10
    // 0xbf2324: ldp             x2, x3, [SP], #0x10
    // 0xbf2328: RestoreReg d1
    //     0xbf2328: ldr             q1, [SP], #0x10
    // 0xbf232c: b               #0xbf2100
    // 0xbf2330: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf2330: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf2334: stp             q0, q1, [SP, #-0x20]!
    // 0xbf2338: SaveReg r0
    //     0xbf2338: str             x0, [SP, #-8]!
    // 0xbf233c: r0 = AllocateDouble()
    //     0xbf233c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf2340: mov             x1, x0
    // 0xbf2344: RestoreReg r0
    //     0xbf2344: ldr             x0, [SP], #8
    // 0xbf2348: ldp             q0, q1, [SP], #0x20
    // 0xbf234c: b               #0xbf2158
    // 0xbf2350: SaveReg d1
    //     0xbf2350: str             q1, [SP, #-0x10]!
    // 0xbf2354: stp             x0, x1, [SP, #-0x10]!
    // 0xbf2358: r0 = AllocateDouble()
    //     0xbf2358: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf235c: mov             x2, x0
    // 0xbf2360: ldp             x0, x1, [SP], #0x10
    // 0xbf2364: RestoreReg d1
    //     0xbf2364: ldr             q1, [SP], #0x10
    // 0xbf2368: b               #0xbf2180
    // 0xbf236c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf236c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  EdgeInsets *(EdgeInsets, double) {
    // ** addr: 0xcfaec4, size: 0x78
    // 0xcfaec4: EnterFrame
    //     0xcfaec4: stp             fp, lr, [SP, #-0x10]!
    //     0xcfaec8: mov             fp, SP
    // 0xcfaecc: AllocStack(0x20)
    //     0xcfaecc: sub             SP, SP, #0x20
    // 0xcfaed0: ldr             x0, [fp, #0x18]
    // 0xcfaed4: LoadField: d0 = r0->field_7
    //     0xcfaed4: ldur            d0, [x0, #7]
    // 0xcfaed8: ldr             x1, [fp, #0x10]
    // 0xcfaedc: LoadField: d1 = r1->field_7
    //     0xcfaedc: ldur            d1, [x1, #7]
    // 0xcfaee0: fmul            d2, d0, d1
    // 0xcfaee4: stur            d2, [fp, #-0x20]
    // 0xcfaee8: LoadField: d0 = r0->field_f
    //     0xcfaee8: ldur            d0, [x0, #0xf]
    // 0xcfaeec: fmul            d3, d0, d1
    // 0xcfaef0: stur            d3, [fp, #-0x18]
    // 0xcfaef4: LoadField: d0 = r0->field_17
    //     0xcfaef4: ldur            d0, [x0, #0x17]
    // 0xcfaef8: fmul            d4, d0, d1
    // 0xcfaefc: stur            d4, [fp, #-0x10]
    // 0xcfaf00: LoadField: d0 = r0->field_1f
    //     0xcfaf00: ldur            d0, [x0, #0x1f]
    // 0xcfaf04: fmul            d5, d0, d1
    // 0xcfaf08: stur            d5, [fp, #-8]
    // 0xcfaf0c: r0 = EdgeInsets()
    //     0xcfaf0c: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xcfaf10: ldur            d0, [fp, #-0x20]
    // 0xcfaf14: StoreField: r0->field_7 = d0
    //     0xcfaf14: stur            d0, [x0, #7]
    // 0xcfaf18: ldur            d0, [fp, #-0x18]
    // 0xcfaf1c: StoreField: r0->field_f = d0
    //     0xcfaf1c: stur            d0, [x0, #0xf]
    // 0xcfaf20: ldur            d0, [fp, #-0x10]
    // 0xcfaf24: StoreField: r0->field_17 = d0
    //     0xcfaf24: stur            d0, [x0, #0x17]
    // 0xcfaf28: ldur            d0, [fp, #-8]
    // 0xcfaf2c: StoreField: r0->field_1f = d0
    //     0xcfaf2c: stur            d0, [x0, #0x1f]
    // 0xcfaf30: LeaveFrame
    //     0xcfaf30: mov             SP, fp
    //     0xcfaf34: ldp             fp, lr, [SP], #0x10
    // 0xcfaf38: ret
    //     0xcfaf38: ret             
  }
  _ clamp(/* No info */) {
    // ** addr: 0xcfb054, size: 0x208
    // 0xcfb054: EnterFrame
    //     0xcfb054: stp             fp, lr, [SP, #-0x10]!
    //     0xcfb058: mov             fp, SP
    // 0xcfb05c: AllocStack(0x20)
    //     0xcfb05c: sub             SP, SP, #0x20
    // 0xcfb060: r0 = Instance_EdgeInsets
    //     0xcfb060: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0xcfb064: ldr             x0, [x0, #0xbd8]
    // 0xcfb068: ldr             x1, [fp, #0x18]
    // 0xcfb06c: LoadField: d0 = r1->field_7
    //     0xcfb06c: ldur            d0, [x1, #7]
    // 0xcfb070: LoadField: d1 = r0->field_7
    //     0xcfb070: ldur            d1, [x0, #7]
    // 0xcfb074: ldr             x2, [fp, #0x10]
    // 0xcfb078: r3 = LoadClassIdInstr(r2)
    //     0xcfb078: ldur            x3, [x2, #-1]
    //     0xcfb07c: ubfx            x3, x3, #0xc, #0x14
    // 0xcfb080: lsl             x3, x3, #1
    // 0xcfb084: r17 = 4202
    //     0xcfb084: mov             x17, #0x106a
    // 0xcfb088: cmp             w3, w17
    // 0xcfb08c: b.ne            #0xcfb098
    // 0xcfb090: LoadField: d2 = r2->field_7
    //     0xcfb090: ldur            d2, [x2, #7]
    // 0xcfb094: b               #0xcfb0b0
    // 0xcfb098: r17 = 4204
    //     0xcfb098: mov             x17, #0x106c
    // 0xcfb09c: cmp             w3, w17
    // 0xcfb0a0: b.ne            #0xcfb0ac
    // 0xcfb0a4: d2 = 0.000000
    //     0xcfb0a4: eor             v2.16b, v2.16b, v2.16b
    // 0xcfb0a8: b               #0xcfb0b0
    // 0xcfb0ac: LoadField: d2 = r2->field_7
    //     0xcfb0ac: ldur            d2, [x2, #7]
    // 0xcfb0b0: fcmp            d0, d1
    // 0xcfb0b4: b.vs            #0xcfb0c4
    // 0xcfb0b8: b.ge            #0xcfb0c4
    // 0xcfb0bc: mov             v0.16b, v1.16b
    // 0xcfb0c0: b               #0xcfb0e4
    // 0xcfb0c4: fcmp            d0, d2
    // 0xcfb0c8: b.vs            #0xcfb0d8
    // 0xcfb0cc: b.le            #0xcfb0d8
    // 0xcfb0d0: mov             v0.16b, v2.16b
    // 0xcfb0d4: b               #0xcfb0e4
    // 0xcfb0d8: fcmp            d0, d0
    // 0xcfb0dc: b.vc            #0xcfb0e4
    // 0xcfb0e0: mov             v0.16b, v2.16b
    // 0xcfb0e4: stur            d0, [fp, #-0x20]
    // 0xcfb0e8: LoadField: d1 = r1->field_f
    //     0xcfb0e8: ldur            d1, [x1, #0xf]
    // 0xcfb0ec: LoadField: d2 = r0->field_f
    //     0xcfb0ec: ldur            d2, [x0, #0xf]
    // 0xcfb0f0: r17 = 4202
    //     0xcfb0f0: mov             x17, #0x106a
    // 0xcfb0f4: cmp             w3, w17
    // 0xcfb0f8: b.ne            #0xcfb104
    // 0xcfb0fc: LoadField: d3 = r2->field_27
    //     0xcfb0fc: ldur            d3, [x2, #0x27]
    // 0xcfb100: b               #0xcfb11c
    // 0xcfb104: r17 = 4204
    //     0xcfb104: mov             x17, #0x106c
    // 0xcfb108: cmp             w3, w17
    // 0xcfb10c: b.ne            #0xcfb118
    // 0xcfb110: LoadField: d3 = r2->field_f
    //     0xcfb110: ldur            d3, [x2, #0xf]
    // 0xcfb114: b               #0xcfb11c
    // 0xcfb118: LoadField: d3 = r2->field_f
    //     0xcfb118: ldur            d3, [x2, #0xf]
    // 0xcfb11c: fcmp            d1, d2
    // 0xcfb120: b.vs            #0xcfb130
    // 0xcfb124: b.ge            #0xcfb130
    // 0xcfb128: mov             v1.16b, v2.16b
    // 0xcfb12c: b               #0xcfb150
    // 0xcfb130: fcmp            d1, d3
    // 0xcfb134: b.vs            #0xcfb144
    // 0xcfb138: b.le            #0xcfb144
    // 0xcfb13c: mov             v1.16b, v3.16b
    // 0xcfb140: b               #0xcfb150
    // 0xcfb144: fcmp            d1, d1
    // 0xcfb148: b.vc            #0xcfb150
    // 0xcfb14c: mov             v1.16b, v3.16b
    // 0xcfb150: stur            d1, [fp, #-0x18]
    // 0xcfb154: LoadField: d2 = r1->field_17
    //     0xcfb154: ldur            d2, [x1, #0x17]
    // 0xcfb158: LoadField: d3 = r0->field_17
    //     0xcfb158: ldur            d3, [x0, #0x17]
    // 0xcfb15c: r17 = 4202
    //     0xcfb15c: mov             x17, #0x106a
    // 0xcfb160: cmp             w3, w17
    // 0xcfb164: b.ne            #0xcfb170
    // 0xcfb168: LoadField: d4 = r2->field_f
    //     0xcfb168: ldur            d4, [x2, #0xf]
    // 0xcfb16c: b               #0xcfb188
    // 0xcfb170: r17 = 4204
    //     0xcfb170: mov             x17, #0x106c
    // 0xcfb174: cmp             w3, w17
    // 0xcfb178: b.ne            #0xcfb184
    // 0xcfb17c: d4 = 0.000000
    //     0xcfb17c: eor             v4.16b, v4.16b, v4.16b
    // 0xcfb180: b               #0xcfb188
    // 0xcfb184: LoadField: d4 = r2->field_17
    //     0xcfb184: ldur            d4, [x2, #0x17]
    // 0xcfb188: fcmp            d2, d3
    // 0xcfb18c: b.vs            #0xcfb19c
    // 0xcfb190: b.ge            #0xcfb19c
    // 0xcfb194: mov             v2.16b, v3.16b
    // 0xcfb198: b               #0xcfb1bc
    // 0xcfb19c: fcmp            d2, d4
    // 0xcfb1a0: b.vs            #0xcfb1b0
    // 0xcfb1a4: b.le            #0xcfb1b0
    // 0xcfb1a8: mov             v2.16b, v4.16b
    // 0xcfb1ac: b               #0xcfb1bc
    // 0xcfb1b0: fcmp            d2, d2
    // 0xcfb1b4: b.vc            #0xcfb1bc
    // 0xcfb1b8: mov             v2.16b, v4.16b
    // 0xcfb1bc: stur            d2, [fp, #-0x10]
    // 0xcfb1c0: LoadField: d3 = r1->field_1f
    //     0xcfb1c0: ldur            d3, [x1, #0x1f]
    // 0xcfb1c4: LoadField: d4 = r0->field_1f
    //     0xcfb1c4: ldur            d4, [x0, #0x1f]
    // 0xcfb1c8: r17 = 4202
    //     0xcfb1c8: mov             x17, #0x106a
    // 0xcfb1cc: cmp             w3, w17
    // 0xcfb1d0: b.ne            #0xcfb1dc
    // 0xcfb1d4: LoadField: d5 = r2->field_2f
    //     0xcfb1d4: ldur            d5, [x2, #0x2f]
    // 0xcfb1d8: b               #0xcfb1f4
    // 0xcfb1dc: r17 = 4204
    //     0xcfb1dc: mov             x17, #0x106c
    // 0xcfb1e0: cmp             w3, w17
    // 0xcfb1e4: b.ne            #0xcfb1f0
    // 0xcfb1e8: LoadField: d5 = r2->field_1f
    //     0xcfb1e8: ldur            d5, [x2, #0x1f]
    // 0xcfb1ec: b               #0xcfb1f4
    // 0xcfb1f0: LoadField: d5 = r2->field_1f
    //     0xcfb1f0: ldur            d5, [x2, #0x1f]
    // 0xcfb1f4: fcmp            d3, d4
    // 0xcfb1f8: b.vs            #0xcfb208
    // 0xcfb1fc: b.ge            #0xcfb208
    // 0xcfb200: mov             v3.16b, v4.16b
    // 0xcfb204: b               #0xcfb228
    // 0xcfb208: fcmp            d3, d5
    // 0xcfb20c: b.vs            #0xcfb21c
    // 0xcfb210: b.le            #0xcfb21c
    // 0xcfb214: mov             v3.16b, v5.16b
    // 0xcfb218: b               #0xcfb228
    // 0xcfb21c: fcmp            d3, d3
    // 0xcfb220: b.vc            #0xcfb228
    // 0xcfb224: mov             v3.16b, v5.16b
    // 0xcfb228: stur            d3, [fp, #-8]
    // 0xcfb22c: r0 = EdgeInsets()
    //     0xcfb22c: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xcfb230: ldur            d0, [fp, #-0x20]
    // 0xcfb234: StoreField: r0->field_7 = d0
    //     0xcfb234: stur            d0, [x0, #7]
    // 0xcfb238: ldur            d0, [fp, #-0x18]
    // 0xcfb23c: StoreField: r0->field_f = d0
    //     0xcfb23c: stur            d0, [x0, #0xf]
    // 0xcfb240: ldur            d0, [fp, #-0x10]
    // 0xcfb244: StoreField: r0->field_17 = d0
    //     0xcfb244: stur            d0, [x0, #0x17]
    // 0xcfb248: ldur            d0, [fp, #-8]
    // 0xcfb24c: StoreField: r0->field_1f = d0
    //     0xcfb24c: stur            d0, [x0, #0x1f]
    // 0xcfb250: LeaveFrame
    //     0xcfb250: mov             SP, fp
    //     0xcfb254: ldp             fp, lr, [SP], #0x10
    // 0xcfb258: ret
    //     0xcfb258: ret             
  }
  _ add(/* No info */) {
    // ** addr: 0xcfb858, size: 0x70
    // 0xcfb858: EnterFrame
    //     0xcfb858: stp             fp, lr, [SP, #-0x10]!
    //     0xcfb85c: mov             fp, SP
    // 0xcfb860: CheckStackOverflow
    //     0xcfb860: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcfb864: cmp             SP, x16
    //     0xcfb868: b.ls            #0xcfb8c0
    // 0xcfb86c: ldr             x0, [fp, #0x10]
    // 0xcfb870: r1 = LoadClassIdInstr(r0)
    //     0xcfb870: ldur            x1, [x0, #-1]
    //     0xcfb874: ubfx            x1, x1, #0xc, #0x14
    // 0xcfb878: lsl             x1, x1, #1
    // 0xcfb87c: r17 = 4206
    //     0xcfb87c: mov             x17, #0x106e
    // 0xcfb880: cmp             w1, w17
    // 0xcfb884: b.ne            #0xcfb8a4
    // 0xcfb888: ldr             x16, [fp, #0x18]
    // 0xcfb88c: stp             x0, x16, [SP, #-0x10]!
    // 0xcfb890: r0 = +()
    //     0xcfb890: bl              #0x518b08  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::+
    // 0xcfb894: add             SP, SP, #0x10
    // 0xcfb898: LeaveFrame
    //     0xcfb898: mov             SP, fp
    //     0xcfb89c: ldp             fp, lr, [SP], #0x10
    // 0xcfb8a0: ret
    //     0xcfb8a0: ret             
    // 0xcfb8a4: ldr             x16, [fp, #0x18]
    // 0xcfb8a8: stp             x0, x16, [SP, #-0x10]!
    // 0xcfb8ac: r0 = add()
    //     0xcfb8ac: bl              #0xcfb938  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::add
    // 0xcfb8b0: add             SP, SP, #0x10
    // 0xcfb8b4: LeaveFrame
    //     0xcfb8b4: mov             SP, fp
    //     0xcfb8b8: ldp             fp, lr, [SP], #0x10
    // 0xcfb8bc: ret
    //     0xcfb8bc: ret             
    // 0xcfb8c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfb8c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfb8c4: b               #0xcfb86c
  }
}
